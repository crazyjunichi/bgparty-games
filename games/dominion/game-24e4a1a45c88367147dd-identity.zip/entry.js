import { randomIntAt as e } from "@bgparty/sdk/core";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { createPortal as a } from "react-dom";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useGameT as s, useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconExpand as u, IconHistory as d, IconLog as f } from "@bgparty/sdk/icons";
import { DeltaNumber as p, PhaseBanner as m, PlayerStrip as h, Texture as g } from "@bgparty/sdk/ui";
import { GameScreen as _ } from "@bgparty/sdk/ui/game-screen";
import { seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { useWakeLock as v } from "@bgparty/sdk/use-wake-lock";
import { gameAssetUrl as y } from "@bgparty/sdk/assets";
import { useFxAnchor as b } from "@bgparty/sdk/fx/anchors";
import { HintRing as te } from "@bgparty/sdk/ui/hint-ring";
import { Fragment as x, jsx as S, jsxs as C } from "react/jsx-runtime";
import { FlySprite as w } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as T } from "@bgparty/sdk/confirm-button";
import { Confetti as ne } from "@bgparty/sdk/ui/confetti";
import { OptionCheckbox as E, OptionRadio as D, OptionSection as O } from "@bgparty/sdk/ui/game-options";
//#region src/games/dominion/data.ts
var k = /* @__PURE__ */ "copper.silver.gold.estate.duchy.province.curse.cellar.chapel.moat.chancellor.village.woodcutter.workshop.bureaucrat.feast.gardens.militia.moneylender.remodel.smithy.spy.thief.throneRoom.councilRoom.festival.laboratory.library.market.mine.witch.adventurer".split("."), A = [
	0,
	3,
	6,
	2,
	5,
	8,
	0,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	5,
	5,
	5,
	6
], j = [
	0,
	1,
	2
], M = [
	3,
	4,
	5,
	16
], N = [
	14,
	17,
	21,
	22,
	30
], P = (e) => e >= 7 && e !== 16, F = [
	[
		7,
		28,
		17,
		29,
		9,
		19,
		20,
		11,
		12,
		13
	],
	[
		31,
		14,
		10,
		8,
		15,
		26,
		28,
		29,
		18,
		23
	],
	[
		14,
		10,
		24,
		25,
		27,
		17,
		9,
		21,
		22,
		11
	],
	[
		7,
		8,
		15,
		16,
		26,
		22,
		11,
		30,
		12,
		13
	],
	[
		14,
		7,
		25,
		27,
		28,
		19,
		20,
		23,
		11,
		12
	]
], re = Array.from({ length: 25 }, (e, t) => t + 7);
function I(e) {
	let t = (t) => e.filter((e) => e === t).length;
	return {
		3: t(3),
		4: 3 * t(4),
		5: 6 * t(5),
		6: -t(6),
		16: t(16) * Math.floor(e.length / 10)
	};
}
var ie = (e) => Object.values(I(e)).reduce((e, t) => e + t, 0), L = {
	id: "dominion",
	tier: "alpha",
	nameKey: "games.dominion.name",
	descKey: "games.dominion.desc",
	rulesKey: "games.dominion.rules",
	icon: "🏰",
	iconImg: "games/dominion.webp",
	accent: "#a57b3e",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	hotseat: "cover",
	search: {
		py: "ling tu huang yu zheng ba",
		init: "lthy zb"
	},
	releasedAt: "2026-10-31T00:06:00+08:00",
	mechanics: [
		"deck-bag-building",
		"hand-management",
		"engine-building"
	],
	interactionTags: [],
	rulesUrl: { en: "https://www.boardgamecapital.com/game_rules/dominion.pdf" }
}, R = t.object({
	set: t.int().min(0).max(5).default(0),
	kingdom: t.array(t.int().min(7).max(31)).max(10).default([])
}).default({
	set: 0,
	kingdom: []
}), z = t.object({
	uid: t.int().nonnegative(),
	id: t.int().min(0).max(31)
}), ae = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		uid: t.int().nonnegative()
	}),
	t.object({ type: t.literal("treasures") }),
	t.object({ type: t.literal("endAction") }),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("buy"),
		id: t.int().min(0).max(31)
	}),
	t.object({
		type: t.literal("gain"),
		id: t.int().min(0).max(31)
	}),
	t.object({
		type: t.literal("choose"),
		uids: t.array(t.int().nonnegative()).max(500)
	}),
	t.object({
		type: t.literal("answer"),
		yes: t.boolean()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), oe = t.object({
	kind: t.enum([
		"cellar",
		"chapel",
		"remodel",
		"mine",
		"throne",
		"militia",
		"bureaucrat",
		"moat",
		"chancellor",
		"spy",
		"thief",
		"loot",
		"library",
		"gain",
		"cleanup"
	]),
	rid: t.string(),
	source: t.int(),
	min: t.int(),
	max: t.int(),
	limit: t.int(),
	treasure: t.boolean()
}), se = t.object({
	phase: t.enum([
		"action",
		"buy",
		"done"
	]),
	turn: t.string(),
	active: t.string(),
	busy: t.boolean(),
	turnNo: t.int(),
	actions: t.int(),
	buys: t.int(),
	coins: t.int(),
	kingdom: t.array(t.int()),
	supply: t.record(t.string(), t.int().nonnegative()),
	play: t.array(z),
	trash: t.array(z),
	aside: t.array(z),
	revealed: t.object({
		rid: t.string(),
		cards: t.array(z)
	}).nullable(),
	prompt: oe.nullable(),
	events: t.array(t.object({
		seq: t.int(),
		kind: t.string(),
		rid: t.string(),
		cards: t.array(t.int())
	})),
	players: t.array(t.object({
		rid: t.string(),
		hand: t.int(),
		deck: t.int(),
		discard: z.nullable(),
		turns: t.int(),
		collection: t.array(z).nullable(),
		score: t.int().nullable()
	}))
}), ce = t.object({
	hand: t.array(z),
	targets: t.array(z),
	gains: t.array(t.int()),
	peek: z.nullable()
}), B = { code: "games.dominion.invalid" }, V = (e) => e.players[e.turnIndex], H = (e, t) => ({
	uid: e.uid++,
	id: t
}), le = (e, t) => [
	...e.p[t].hand,
	...e.p[t].deck,
	...e.p[t].discard,
	...V(e) === t ? e.play : [],
	...e.revealed?.rid === t ? e.revealed.cards : [],
	...V(e) === t ? e.aside : []
];
function U(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function W(e, t) {
	let n = e.p[t];
	return !n.deck.length && n.discard.length && (n.deck = U(e, n.discard), n.discard = []), n.deck.pop();
}
function G(e, t, n, r = []) {
	e.events.push({
		seq: e.eventSeq++,
		kind: t,
		rid: n,
		cards: r.map((e) => e.id)
	});
}
function K(e, t, n, r, i) {
	return {
		kind: "dominionMove",
		rid: e,
		data: {
			from: t,
			to: n,
			n: r.length,
			...i ? {
				cards: r.map((e) => e.id),
				uids: r.map((e) => e.uid)
			} : {}
		},
		...i ? {} : {
			for: [e],
			secret: {
				cards: r.map((e) => e.id),
				uids: r.map((e) => e.uid)
			}
		}
	};
}
var q = (e, ...t) => e.tasks.unshift(...t), J = (e, t, n = {}) => ({
	...n,
	kind: e,
	rid: t
});
function Y(e, t, n, r, i = {}) {
	e.prompt = {
		kind: t,
		rid: n,
		source: r,
		min: 0,
		max: 1,
		limit: 0,
		treasure: !1,
		...i
	};
}
function ue(e, t, n, r = "discard") {
	if (!(e.supply[n] > 0)) return;
	e.supply[n]--;
	let i = H(e, n);
	return e.p[t][r].push(i), G(e, "gain", t, [i]), i;
}
function de(e, t, n, r, i = !1, a = "discard") {
	Object.entries(e.supply).some(([e, t]) => t > 0 && A[+e] <= r && (!i || j.includes(+e))) && Y(e, "gain", t, n, {
		limit: r,
		treasure: i,
		dest: a
	});
}
function X(e, t, n) {
	return e.players.slice(1).map((t, n) => e.players[(e.turnIndex + n + 1) % e.players.length]).filter((t) => !e.blocked.includes(t)).map((e) => J("attack", e, {
		card: n,
		attacker: t
	}));
}
function fe(e, t, n) {
	let r = e.p[t];
	switch (n.id) {
		case 7:
			e.actions++, Y(e, "cellar", t, n.id, { max: r.hand.length });
			break;
		case 8:
			Y(e, "chapel", t, n.id, { max: Math.min(4, r.hand.length) });
			break;
		case 9:
			q(e, J("draw", t, { n: 2 }));
			break;
		case 10:
			e.coins += 2, Y(e, "chancellor", t, n.id);
			break;
		case 11:
			e.actions += 2, q(e, J("draw", t, { n: 1 }));
			break;
		case 12:
			e.coins += 2, e.buys++;
			break;
		case 13:
			de(e, t, n.id, 4);
			break;
		case 14:
			q(e, J("gain", t, {
				n: 1,
				dest: "deck"
			}), ...X(e, t, n));
			break;
		case 15: {
			let r = e.play.findIndex((e) => e.uid === n.uid);
			r >= 0 && (e.trash.push(...e.play.splice(r, 1)), G(e, "trash", t, [n])), de(e, t, n.id, 5);
			break;
		}
		case 17:
			e.coins += 2, q(e, ...X(e, t, n));
			break;
		case 18: {
			let n = r.hand.findIndex((e) => e.id === 0);
			n >= 0 && q(e, J("moneylender", t, { card: r.hand[n] }));
			break;
		}
		case 19:
			r.hand.length && Y(e, "remodel", t, n.id, { min: 1 });
			break;
		case 20:
			q(e, J("draw", t, { n: 3 }));
			break;
		case 21:
			e.actions++, q(e, J("draw", t, { n: 1 }), J("spyReveal", t, { attacker: t }), ...X(e, t, n));
			break;
		case 22:
			e.loot = [], q(e, ...X(e, t, n), J("loot", t));
			break;
		case 23:
			r.hand.some((e) => P(e.id)) && Y(e, "throne", t, n.id, { min: 1 });
			break;
		case 24:
			e.buys++, q(e, J("draw", t, { n: 4 }), ...e.players.filter((e) => e !== t).map((e) => J("draw", e, { n: 1 })));
			break;
		case 25:
			e.actions += 2, e.buys++, e.coins += 2;
			break;
		case 26:
			e.actions++, q(e, J("draw", t, { n: 2 }));
			break;
		case 27:
			e.aside = [], q(e, J("library", t));
			break;
		case 28:
			e.actions++, e.buys++, e.coins++, q(e, J("draw", t, { n: 1 }));
			break;
		case 29:
			r.hand.some((e) => j.includes(e.id)) && Y(e, "mine", t, n.id, { min: 1 });
			break;
		case 30:
			q(e, J("draw", t, { n: 2 }), ...X(e, t, n));
			break;
		case 31: q(e, J("adventurer", t, {
			found: 0,
			held: []
		}));
	}
}
function pe(e, t) {
	let n = e.p[t.rid].hand;
	return t.kind === "cleanup" ? [...n, ...e.play] : t.kind === "mine" ? n.filter((e) => j.includes(e.id)) : t.kind === "throne" ? n.filter((e) => P(e.id)) : t.kind === "bureaucrat" ? n.filter((e) => M.includes(e.id)) : t.kind === "thief" ? e.revealed?.cards.filter((e) => j.includes(e.id)) ?? [] : t.kind === "loot" ? e.loot : [
		"cellar",
		"chapel",
		"remodel",
		"militia"
	].includes(t.kind) ? n : [];
}
function me(e) {
	let t = e.tasks.shift();
	if (!t) return [];
	let n = e.p[t.rid], r = t.rid, i = [];
	switch (t.kind) {
		case "effect": {
			if (N.includes(t.card.id)) {
				e.blocked = [], q(e, ...e.players.slice(1).map((t, n) => e.players[(e.turnIndex + n + 1) % e.players.length]).map((e) => J("reaction", e, {
					card: t.card,
					attacker: r
				})), J("attackEffect", r, { card: t.card }));
				break;
			}
			let n = e.play.some((e) => e.uid === t.card.uid);
			if (fe(e, r, t.card), t.card.id === 15 && n) return [K(r, "play", "trash", [t.card], !0)];
			break;
		}
		case "attackEffect":
			fe(e, r, t.card);
			break;
		case "draw":
			for (let n = 0; n < (t.n ?? 1); n++) {
				let t = W(e, r);
				t && i.push(t);
			}
			if (n.hand.push(...i), i.length) return [K(r, `deck:${r}`, `hand:${r}`, i, !1)];
			break;
		case "gain": {
			let n = ue(e, r, t.n, t.dest);
			if (n) return [K(r, `supply:${n.id}`, `${t.dest === "deck" ? "deck" : t.dest === "hand" ? "hand" : "discard"}:${r}`, [n], !0)];
			break;
		}
		case "moneylender": {
			let a = n.hand.findIndex((e) => e.uid === t.card.uid);
			return i = n.hand.splice(a, 1), e.trash.push(...i), e.coins += 3, G(e, "trash", r, i), [K(r, `hand:${r}`, "trash", i, !0)];
		}
		case "reaction":
			n.hand.some((e) => e.id === 9) && Y(e, "moat", r, t.card.id, {
				card: t.card,
				attacker: t.attacker
			});
			break;
		case "attack":
			switch (t.card.id) {
				case 14:
					if (n.hand.some((e) => M.includes(e.id))) Y(e, "bureaucrat", r, 14, { min: 1 });
					else return e.revealed = {
						rid: r,
						cards: [...n.hand]
					}, G(e, "reveal", r, n.hand), q(e, J("clearReveal", r)), [K(r, `hand:${r}`, "reveal", n.hand, !0)];
					break;
				case 17:
					n.hand.length > 3 && Y(e, "militia", r, 17, {
						min: n.hand.length - 3,
						max: n.hand.length - 3
					});
					break;
				case 21:
					q(e, J("spyReveal", r, { attacker: t.attacker }));
					break;
				case 22:
					q(e, J("thiefReveal", r, { attacker: t.attacker }));
					break;
				case 30: q(e, J("gain", r, { n: 6 }));
			}
			break;
		case "clearReveal":
			e.revealed = null;
			break;
		case "spyReveal": {
			let n = W(e, r);
			if (n) return e.revealed = {
				rid: r,
				cards: [n]
			}, G(e, "reveal", r, [n]), Y(e, "spy", t.attacker, 21, {
				card: n,
				attacker: r
			}), [K(r, `deck:${r}`, "reveal", [n], !0)];
			break;
		}
		case "thiefReveal":
			for (let t = 0; t < 2; t++) {
				let t = W(e, r);
				t && i.push(t);
			}
			if (e.revealed = {
				rid: r,
				cards: i
			}, G(e, "reveal", r, i), i.some((e) => j.includes(e.id)) ? Y(e, "thief", t.attacker, 22, {
				attacker: r,
				min: 1
			}) : q(e, J("discardReveal", r)), i.length) return [K(r, `deck:${r}`, "reveal", i, !0)];
			break;
		case "discardReveal":
			if (i = e.revealed?.cards ?? [], n.discard.push(...i), e.revealed = null, i.length) return [K(r, "reveal", `discard:${r}`, i, !0)];
			break;
		case "loot":
			e.loot.length && Y(e, "loot", r, 22, { max: e.loot.length });
			break;
		case "library":
			if (n.hand.length >= 7) {
				q(e, J("libraryFinish", r));
				break;
			}
			{
				let t = W(e, r);
				if (!t) {
					q(e, J("libraryFinish", r));
					break;
				}
				if (P(t.id)) {
					Y(e, "library", r, 27, { card: t });
					break;
				}
				return n.hand.push(t), q(e, J("library", r)), [K(r, `deck:${r}`, `hand:${r}`, [t], !1)];
			}
		case "libraryFinish":
			if (i = e.aside, e.aside = [], n.discard.push(...i), i.length) return G(e, "discard", r, i), [K(r, "aside", `discard:${r}`, i, !0)];
			break;
		case "adventurer":
			if ((t.found ?? 0) >= 2) {
				if (n.discard.push(...t.held ?? []), t.held?.length) return [K(r, "aside", `discard:${r}`, t.held, !0)];
				break;
			}
			{
				let i = W(e, r);
				if (!i) {
					if (n.discard.push(...t.held ?? []), t.held?.length) return [K(r, "aside", `discard:${r}`, t.held, !0)];
					break;
				}
				return e.revealed = {
					rid: r,
					cards: [i]
				}, G(e, "reveal", r, [i]), q(e, J("adventurerTake", r, {
					...t,
					card: i
				})), [K(r, `deck:${r}`, "reveal", [i], !0)];
			}
		case "adventurerTake": {
			let i = t.card, a = j.includes(i.id);
			return a && n.hand.push(i), e.revealed = null, q(e, J("adventurer", r, {
				found: (t.found ?? 0) + Number(a),
				held: a ? t.held : [...t.held ?? [], i]
			})), [K(r, "reveal", a ? `hand:${r}` : "aside", [i], !0)];
		}
		case "cleanup": {
			let a = [...e.play], o = [...n.hand];
			return i = [...a, ...o], t.card && (i = i.filter((e) => e.uid !== t.card.uid), i.push(t.card)), n.discard.push(...i), e.play = [], n.hand = [], e.revealed = null, q(e, J("draw", r, { n: 5 }), J("advance", r)), [...a.length ? [K(r, "play", `discard:${r}`, a, !0)] : [], ...o.length ? [{
				...K(r, `hand:${r}`, `discard:${r}`, o, !1),
				with: a.length > 0
			}] : []];
		}
		case "advance":
			if (e.supply[5] === 0 || Object.values(e.supply).filter((e) => e === 0).length >= 3) {
				e.phase = "done", G(e, "end", r);
				break;
			}
			e.turnIndex = (e.turnIndex + 1) % e.players.length, e.p[V(e)].turns++, e.phase = "action", e.actions = 1, e.buys = 1, e.coins = 0, G(e, "turn", V(e));
	}
	return [];
}
function he(t, n, r) {
	let i = R.parse(t), a = {
		seed: r,
		cursor: 0,
		uid: 0,
		players: [...n],
		p: {},
		kingdom: [],
		supply: {},
		turnIndex: 0,
		phase: "action",
		actions: 1,
		buys: 1,
		coins: 0,
		play: [],
		trash: [],
		revealed: null,
		tasks: [],
		prompt: null,
		aside: [],
		loot: [],
		blocked: [],
		events: [],
		eventSeq: 0,
		beat: !1
	};
	a.kingdom = i.kingdom.length === 10 && new Set(i.kingdom).size === 10 ? [...i.kingdom] : i.set < 5 ? [...F[i.set]] : U(a, re.map((e) => ({
		uid: e,
		id: e
	}))).slice(0, 10).map((e) => e.id), a.kingdom.sort((e, t) => A[e] - A[t] || e - t), a.supply = {
		0: 60 - 7 * n.length,
		1: 40,
		2: 30,
		3: n.length === 2 ? 8 : 12,
		4: n.length === 2 ? 8 : 12,
		5: n.length === 2 ? 8 : 12,
		6: 10 * (n.length - 1)
	}, a.kingdom.forEach((e) => {
		a.supply[e] = e === 16 ? n.length === 2 ? 8 : 12 : 10;
	}), a.turnIndex = e(a.seed, a.cursor++, n.length);
	for (let e of n) {
		let t = U(a, [...Array.from({ length: 7 }, () => H(a, 0)), ...Array.from({ length: 3 }, () => H(a, 3))]);
		a.p[e] = {
			hand: t.splice(-5),
			deck: t,
			discard: [],
			turns: 0
		};
	}
	return a.p[V(a)].turns = 1, G(a, "turn", V(a)), { state: a };
}
function ge(e, t, n) {
	if (e.phase === "done") return B;
	let r = structuredClone(e), i = n.by, a = r.p[i], o = [];
	if (t.type === "tick") {
		if (n.by !== "$engine") return B;
		if (r.beat) r.beat = !1;
		else if (!r.prompt && r.tasks.length) o = me(r);
		else return B;
		return {
			state: r,
			fx: o
		};
	}
	if (!a || r.beat) return B;
	let s = r.prompt;
	if (s) {
		if (s.rid !== i) return B;
		if (t.type === "gain") {
			if (s.kind !== "gain" || !(r.supply[t.id] > 0) || A[t.id] > s.limit || s.treasure && !j.includes(t.id)) return B;
			let e = ue(r, i, t.id, s.dest);
			r.prompt = null, e && (o = [K(i, `supply:${t.id}`, `${s.dest === "hand" ? "hand" : s.dest === "deck" ? "deck" : "discard"}:${i}`, [e], !0)]);
		} else if (t.type === "answer") {
			if (![
				"moat",
				"chancellor",
				"spy",
				"library"
			].includes(s.kind)) return B;
			if (r.prompt = null, s.kind === "moat" && t.yes && (r.blocked.push(i), G(r, "moat", i, a.hand.filter((e) => e.id === 9).slice(0, 1)), o = [K(i, `hand:${i}`, `seat:${i}`, [a.hand.find((e) => e.id === 9)], !0)]), s.kind === "chancellor" && t.yes) {
				let e = [...a.deck];
				_e(r, i, e), a.deck = [], o = [K(i, `deck:${i}`, `discard:${i}`, e, !1)];
			}
			if (s.kind === "spy") {
				let e = s.attacker;
				r.p[e][t.yes ? "discard" : "deck"].push(s.card), r.revealed = null, o = [K(e, "reveal", `${t.yes ? "discard" : "deck"}:${e}`, [s.card], !0)];
			}
			s.kind === "library" && (t.yes ? (r.aside.push(s.card), G(r, "reveal", i, [s.card])) : a.hand.push(s.card), q(r, J("library", i)), o = [K(i, `deck:${i}`, t.yes ? "aside" : `hand:${i}`, [s.card], t.yes)]);
		} else if (t.type === "choose") {
			if (![
				"cellar",
				"chapel",
				"remodel",
				"mine",
				"throne",
				"militia",
				"bureaucrat",
				"thief",
				"loot",
				"cleanup"
			].includes(s.kind)) return B;
			let e = pe(r, s);
			if (new Set(t.uids).size !== t.uids.length || t.uids.length < s.min || t.uids.length > s.max || t.uids.some((t) => !e.some((e) => e.uid === t))) return B;
			let n = t.uids.map((t) => e.find((e) => e.uid === t));
			r.prompt = null, [
				"cellar",
				"chapel",
				"militia",
				"remodel",
				"mine",
				"bureaucrat",
				"throne"
			].includes(s.kind) && (a.hand = a.hand.filter((e) => !t.uids.includes(e.uid))), (s.kind === "cellar" || s.kind === "militia") && (a.discard.push(...n), G(r, "discardCount", i, []), o = [K(i, `hand:${i}`, `discard:${i}`, n, !1)], s.kind === "cellar" && n.length && q(r, J("draw", i, { n: n.length }))), [
				"chapel",
				"remodel",
				"mine"
			].includes(s.kind) && (r.trash.push(...n), G(r, "trash", i, n), o = [K(i, `hand:${i}`, "trash", n, !0)], s.kind !== "chapel" && de(r, i, s.source, A[n[0].id] + (s.kind === "mine" ? 3 : 2), s.kind === "mine", s.kind === "mine" ? "hand" : "discard")), s.kind === "bureaucrat" && (a.deck.push(...n), G(r, "reveal", i, n), o = [K(i, `hand:${i}`, `deck:${i}`, n, !0)]), s.kind === "throne" && (r.play.push(n[0]), G(r, "play", i, n), q(r, J("effect", i, { card: n[0] }), J("effect", i, { card: n[0] })), o = [K(i, `hand:${i}`, "play", n, !0)]), s.kind === "thief" && (r.trash.push(...n), r.loot.push(...n), G(r, "trash", s.attacker, n), r.revealed.cards = r.revealed.cards.filter((e) => !t.uids.includes(e.uid)), q(r, J("discardReveal", s.attacker)), o = [K(s.attacker, "reveal", "trash", n, !0)]), s.kind === "cleanup" && q(r, J("cleanup", i, { card: n[0] })), s.kind === "loot" && (r.trash = r.trash.filter((e) => !t.uids.includes(e.uid)), a.discard.push(...n), r.loot = [], G(r, "gain", i, n), o = [K(i, "trash", `discard:${i}`, n, !0)]);
		} else return B;
	} else {
		if (r.tasks.length || i !== V(r)) return B;
		if (t.type === "play") {
			let e = a.hand.findIndex((e) => e.uid === t.uid);
			if (e < 0) return B;
			let n = a.hand[e], s = r.phase === "buy" && j.includes(n.id);
			if (!s && (r.phase !== "action" || r.actions < 1 || !P(n.id))) return B;
			a.hand.splice(e, 1), r.play.push(n), G(r, s ? "treasures" : "play", i, [n]), s ? r.coins += n.id + 1 : (r.actions--, q(r, J("effect", i, { card: n }))), o = [K(i, `hand:${i}`, "play", [n], !0)];
		} else if (t.type === "endAction") {
			if (r.phase !== "action") return B;
			r.phase = "buy";
		} else if (t.type === "treasures") {
			if (r.phase !== "buy") return B;
			let e = a.hand.filter((e) => j.includes(e.id));
			if (!e.length) return B;
			a.hand = a.hand.filter((e) => !j.includes(e.id)), r.play.push(...e), r.coins += e.reduce((e, t) => e + t.id + 1, 0), G(r, "treasures", i, e), o = [K(i, `hand:${i}`, "play", e, !0)];
		} else if (t.type === "buy") {
			if (r.phase !== "buy" || r.buys < 1 || !(r.supply[t.id] > 0) || A[t.id] > r.coins) return B;
			r.coins -= A[t.id], r.buys--;
			let e = ue(r, i, t.id);
			o = [K(i, `supply:${t.id}`, `discard:${i}`, [e], !0)];
		} else if (t.type === "endTurn") {
			if (r.phase !== "buy") return B;
			let e = [...a.hand, ...r.play];
			new Set(e.map((e) => e.id)).size > 1 ? Y(r, "cleanup", i, 0, { min: 1 }) : q(r, J("cleanup", i));
		} else return B;
	}
	return r.beat = o.length > 0, {
		state: r,
		fx: o
	};
}
function _e(e, t, n) {
	e.p[t].discard.push(...n);
}
var ve = {
	meta: L,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ae,
		publicView: se,
		privateView: ce,
		config: R
	},
	setup: he,
	reduce: ge,
	viewFor(e, t) {
		let n = e.prompt, { kind: r, rid: i, source: a, min: o, max: s, limit: c, treasure: l } = n ?? {
			kind: "gain",
			rid: "",
			source: 0,
			min: 0,
			max: 0,
			limit: 0,
			treasure: !1
		};
		return {
			public: {
				phase: e.phase,
				turn: V(e),
				active: n?.rid ?? V(e),
				busy: e.beat || e.tasks.length > 0 && !n,
				turnNo: e.p[V(e)].turns,
				actions: e.actions,
				buys: e.buys,
				coins: e.coins,
				kingdom: [...e.kingdom],
				supply: { ...e.supply },
				play: structuredClone(e.play),
				trash: structuredClone(e.trash),
				aside: structuredClone([...e.aside, ...e.tasks.find((e) => e.held)?.held ?? []]),
				revealed: structuredClone(e.revealed),
				prompt: n ? {
					kind: r,
					rid: i,
					source: a,
					min: o,
					max: s,
					limit: c,
					treasure: l
				} : null,
				events: structuredClone(e.events),
				players: e.players.map((t) => {
					let n = e.p[t], r = le(e, t);
					return {
						rid: t,
						hand: n.hand.length,
						deck: n.deck.length,
						discard: n.discard.at(-1) ?? null,
						turns: n.turns,
						collection: e.phase === "done" ? r : null,
						score: e.phase === "done" ? ie(r.map((e) => e.id)) : null
					};
				})
			},
			private: {
				hand: structuredClone(e.p[t]?.hand ?? []),
				targets: n?.rid === t ? structuredClone(pe(e, n)) : [],
				gains: n?.rid === t && n.kind === "gain" ? Object.entries(e.supply).filter(([e, t]) => t > 0 && A[+e] <= n.limit && (!n.treasure || j.includes(+e))).map(([e]) => +e) : [],
				peek: n?.rid === t && n.kind === "library" ? n.card ?? null : null
			}
		};
	},
	nextTickIn(e) {
		return e.phase !== "done" && (e.beat || !e.prompt && e.tasks.length > 0) ? 380 : null;
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((t) => [t, ie(le(e, t).map((e) => e.id))])), n = [...e.players].sort((n, r) => t[r] - t[n] || e.p[n].turns - e.p[r].turns);
		return {
			phase: "done",
			scores: t,
			ranking: n,
			winner: n.filter((r) => t[r] === t[n[0]] && e.p[r].turns === e.p[n[0]].turns)
		};
	}
};
//#endregion
//#region src/games/dominion/card.tsx
function Z({ name: e, children: t, className: n = "" }) {
	let { ref: r, hidden: i } = b(e);
	return /* @__PURE__ */ S("div", {
		ref: r,
		className: n,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function Q({ id: e, compact: t = !1 }) {
	let n = s("dominion");
	if (e === null) return /* @__PURE__ */ S("div", {
		className: "dm-card dm-back",
		children: /* @__PURE__ */ C("svg", {
			viewBox: "0 0 100 130",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ S("path", {
					d: "M8 8H92V122H8ZM16 16H84V114H16Z",
					fill: "none",
					stroke: "currentColor"
				}),
				/* @__PURE__ */ S("path", {
					d: "M27 83V51L35 44V60H44V33L50 25L56 33V60H65V44L73 51V83Z",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ S("path", {
					d: "M44 83V68Q50 61 56 68V83M20 95Q50 112 80 95M20 22L80 108M80 22L20 108",
					fill: "none",
					stroke: "currentColor",
					opacity: ".3"
				})
			]
		})
	});
	let r = k[e], i = e === 6 ? "curseType" : j.includes(e) ? "treasureType" : M.includes(e) ? "victoryType" : e === 9 ? "reactionType" : N.includes(e) ? "attackType" : "actionType";
	return /* @__PURE__ */ C("div", {
		className: "dm-card",
		"data-kind": e === 6 ? "curse" : j.includes(e) ? "treasure" : M.includes(e) ? "victory" : e === 9 ? "reaction" : "action",
		"data-compact": t,
		children: [
			/* @__PURE__ */ S("strong", {
				className: "dm-card-name",
				children: n(`cards.${r}.name`)
			}),
			/* @__PURE__ */ S("img", {
				className: "dm-art",
				src: y(`games/dominion/art-${e}.svg`),
				alt: "",
				draggable: !1
			}),
			!t && /* @__PURE__ */ S("p", {
				className: "dm-card-text",
				children: n(`cards.${r}.text`)
			}),
			/* @__PURE__ */ C("div", {
				className: "dm-card-foot",
				children: [/* @__PURE__ */ S("b", { children: /* @__PURE__ */ S("img", {
					src: y(`games/dominion/cost-${A[e]}.svg`),
					alt: String(A[e])
				}) }), /* @__PURE__ */ S("span", { children: n(i) })]
			})
		]
	});
}
function $({ id: e, count: t, onClick: n, inspect: r, legal: i = !1, selected: a = !1, compact: o = !0, anchor: c }) {
	let l = s("dominion"), { ref: u, hidden: d } = b(c ?? null);
	return /* @__PURE__ */ C("div", {
		className: "dm-card-item",
		ref: u,
		"data-selected": a,
		"data-empty": t === 0,
		children: [
			/* @__PURE__ */ C("button", {
				className: "dm-card-hit",
				onClick: n ?? r,
				"aria-label": l(`cards.${k[e]}.name`),
				"aria-pressed": a,
				style: { visibility: d ? "hidden" : void 0 },
				children: [/* @__PURE__ */ S(Q, {
					id: e,
					compact: o
				}), i && /* @__PURE__ */ S(te, {
					radius: 5,
					flash: !1
				})]
			}),
			t !== void 0 && /* @__PURE__ */ C("span", {
				className: "dm-count",
				"aria-label": l("count", { n: t }),
				children: ["×", t]
			}),
			/* @__PURE__ */ S("button", {
				className: "dm-inspect",
				onClick: r,
				"aria-label": l("inspect", { card: l(`cards.${k[e]}.name`) }),
				children: "i"
			})
		]
	});
}
//#endregion
//#region src/games/dominion/view-player.tsx
function ye(e) {
	v();
	let t = e.public, n = e.private;
	return /* @__PURE__ */ S(be, {
		...e,
		pub: t,
		priv: n ?? {
			hand: [],
			targets: [],
			gains: [],
			peek: null
		}
	});
}
function be({ pub: e, priv: t, myRid: n, members: r, send: l }) {
	let u = s("dominion"), f = c((e) => e.locale), [p, v] = i(null), [y, b] = i(!1), [te, w] = i(!1), [T, ne] = i(n), E = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? ee(t, f) : e;
	}, D = e.active === n && !e.busy && e.phase !== "done", O = e.prompt, j = (t) => D && !O && e.phase === "buy" && e.buys > 0 && e.supply[String(t)] > 0 && A[t] <= e.coins, M = (e) => D && O?.kind === "gain" && t.gains.includes(e), N = (e) => M(e) ? {
		type: "gain",
		id: e
	} : j(e) ? {
		type: "buy",
		id: e
	} : void 0, P = (e) => v(e), F = e.phase === "done" ? e.players.find((e) => e.rid === T) ?? e.players[0] : e.players.find((e) => e.rid === n) ?? e.players[0], re = e.phase === "done" ? u("done") : e.busy ? u("resolving") : D ? O ? u(`prompt.${O.kind}`, {
		n: O.kind === "gain" ? O.limit : O.min,
		type: O.treasure ? u("treasureType") + " " : ""
	}) : u(e.phase) : u("waiting", { name: E(e.active) }), I = e.phase === "done" ? F.collection ?? [] : e.play, ie = e.phase === "done" ? `${E(F.rid)} · ${u("collection")}` : u("play"), L = p === null ? void 0 : N(p);
	return /* @__PURE__ */ C(_, {
		adaptive: !0,
		scroll: !1,
		className: "dm-screen",
		actionsHeight: "dm-actions-height",
		banner: /* @__PURE__ */ C("div", {
			className: "dm-banner",
			children: [/* @__PURE__ */ S(m, {
				tone: e.phase === "done" ? "done" : D ? "accent" : "info",
				accent: "#85602f",
				text: re,
				chip: u("turn", { n: e.turnNo })
			}), /* @__PURE__ */ C("div", {
				className: "dm-banner-row",
				children: [/* @__PURE__ */ S(h, {
					adaptive: !0,
					variant: "mini",
					scroll: !0,
					members: r,
					myRid: n,
					anchorOf: (e) => `seat:${e}`,
					onPick: e.phase === "done" ? ne : void 0,
					picked: (t) => e.phase === "done" && t === T,
					action: (t) => e.phase !== "done" && t === e.active ? "pending" : null,
					status: (t) => /* @__PURE__ */ C("span", { children: [
						u("hand"),
						" ",
						e.players.find((e) => e.rid === t)?.hand ?? 0
					] })
				}), /* @__PURE__ */ S("button", {
					className: "dm-history-btn",
					onClick: () => b(!0),
					"aria-label": u("history"),
					children: /* @__PURE__ */ S(d, { size: 20 })
				})]
			})]
		}),
		actions: /* @__PURE__ */ S(xe, {
			pub: e,
			priv: t,
			myRid: n,
			send: l,
			inspect: P
		}, `${e.turn}:${e.turnNo}:${O?.kind}:${O?.source}:${t.targets.map((e) => e.uid).join(",")}`),
		children: [/* @__PURE__ */ C("div", {
			className: "dm-table",
			children: [/* @__PURE__ */ S(g, {
				kind: "sheen",
				base: "#25423c"
			}), /* @__PURE__ */ C("div", {
				className: "dm-table-content",
				children: [
					/* @__PURE__ */ C("section", {
						className: "dm-basic",
						children: [/* @__PURE__ */ S("h2", { children: u("basic") }), /* @__PURE__ */ S("div", {
							className: "dm-basic-grid",
							children: [
								0,
								1,
								2,
								3,
								4,
								5,
								6
							].map((t) => /* @__PURE__ */ S($, {
								id: t,
								count: e.supply[String(t)],
								anchor: `supply:${t}`,
								legal: j(t) || M(t),
								onClick: () => {
									let e = N(t);
									e ? l(e) : P(t);
								},
								inspect: () => P(t)
							}, t))
						})]
					}),
					/* @__PURE__ */ C("section", {
						className: "dm-kingdom",
						children: [/* @__PURE__ */ S("h2", { children: u("kingdom") }), /* @__PURE__ */ S("div", {
							className: "dm-kingdom-grid",
							children: e.kingdom.map((t) => /* @__PURE__ */ S($, {
								id: t,
								count: e.supply[String(t)],
								anchor: `supply:${t}`,
								legal: j(t) || M(t),
								onClick: () => {
									let e = N(t);
									e ? l(e) : P(t);
								},
								inspect: () => P(t)
							}, t))
						})]
					}),
					/* @__PURE__ */ C("aside", {
						className: "dm-piles",
						children: [
							/* @__PURE__ */ C("div", {
								className: "dm-pile",
								children: [/* @__PURE__ */ S(Z, {
									name: `deck:${F.rid}`,
									children: /* @__PURE__ */ S(Q, { id: null })
								}), /* @__PURE__ */ C("span", { children: [
									u("deck"),
									" ",
									/* @__PURE__ */ S("b", { children: F.deck })
								] })]
							}),
							/* @__PURE__ */ C("div", {
								className: "dm-pile",
								children: [/* @__PURE__ */ S(Z, {
									name: `discard:${F.rid}`,
									children: /* @__PURE__ */ S("button", {
										onClick: () => F.discard && P(F.discard.id),
										"aria-label": u("discard"),
										children: /* @__PURE__ */ S(Z, {
											name: `discard:${F.rid}:${F.discard?.uid ?? "empty"}`,
											children: /* @__PURE__ */ S(Q, {
												id: F.discard?.id ?? null,
												compact: !0
											})
										})
									})
								}), /* @__PURE__ */ S("span", { children: u("discard") })]
							}),
							/* @__PURE__ */ S(Z, {
								name: "trash",
								children: /* @__PURE__ */ C("button", {
									className: "dm-trash",
									onClick: () => w(!0),
									children: [
										u("trash"),
										" · ",
										e.trash.length
									]
								})
							})
						]
					}),
					/* @__PURE__ */ C("section", {
						className: "dm-play",
						children: [/* @__PURE__ */ S("h2", { children: ie }), /* @__PURE__ */ S(Z, {
							name: "play",
							className: "dm-play-cards",
							children: I.length ? I.map((e) => /* @__PURE__ */ S($, {
								id: e.id,
								anchor: `play:${e.uid}`,
								inspect: () => P(e.id)
							}, e.uid)) : /* @__PURE__ */ S("span", {
								className: "dm-empty",
								children: u("empty")
							})
						})]
					}),
					/* @__PURE__ */ S(Z, {
						name: "reveal",
						className: `dm-reveal ${e.revealed?.cards.length ? "dm-reveal-active" : ""}`,
						children: e.revealed?.cards.length ? /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ C("h3", { children: [
							E(e.revealed.rid),
							" · ",
							u("reveal")
						] }), /* @__PURE__ */ S("div", {
							className: "dm-reveal-cards",
							children: e.revealed.cards.map((e) => /* @__PURE__ */ S($, {
								id: e.id,
								anchor: `reveal:${e.uid}`,
								legal: D && t.targets.some((t) => t.uid === e.uid),
								onClick: () => {
									D && O?.kind === "thief" ? l({
										type: "choose",
										uids: [e.uid]
									}) : P(e.id);
								},
								inspect: () => P(e.id)
							}, e.uid))
						})] }) : null
					}),
					/* @__PURE__ */ C(Z, {
						name: "aside",
						className: "dm-aside-anchor",
						children: [/* @__PURE__ */ S("span", { children: u("aside") }), /* @__PURE__ */ S("div", {
							className: "dm-aside-cards",
							children: e.aside.map((e) => /* @__PURE__ */ S($, {
								id: e.id,
								anchor: `aside:${e.uid}`,
								inspect: () => P(e.id)
							}, e.uid))
						})]
					})
				]
			})]
		}), a(/* @__PURE__ */ C("div", {
			className: "dm-sheet",
			children: [
				/* @__PURE__ */ S(o, {
					open: p !== null,
					onClose: () => v(null),
					title: u("detail"),
					label: u("detail"),
					footer: L ? /* @__PURE__ */ S("button", {
						className: "dm-primary w-full",
						onClick: () => {
							l(L), v(null);
						},
						children: u(L.type === "buy" ? "buyCard" : "gainCard")
					}) : void 0,
					children: p !== null && /* @__PURE__ */ S("div", {
						className: "dm-detail",
						children: /* @__PURE__ */ S(Q, { id: p })
					})
				}),
				/* @__PURE__ */ S(o, {
					open: y,
					onClose: () => b(!1),
					title: u("history"),
					label: u("history"),
					children: /* @__PURE__ */ S("ol", {
						className: "dm-history",
						children: e.events.map((e) => /* @__PURE__ */ S("li", { children: u(`event.${e.kind}`, {
							name: E(e.rid),
							cards: e.cards.map((e) => u(`cards.${k[e]}.name`)).join(" · ")
						}) }, e.seq))
					})
				}),
				/* @__PURE__ */ S(o, {
					open: te,
					onClose: () => w(!1),
					title: u("trash"),
					label: u("trash"),
					children: /* @__PURE__ */ S("div", {
						className: "dm-trash-grid",
						children: e.trash.map((e) => /* @__PURE__ */ S($, {
							id: e.id,
							inspect: () => P(e.id)
						}, e.uid))
					})
				})
			]
		}), document.body)]
	});
}
function xe({ pub: e, priv: t, myRid: n, send: r, inspect: a }) {
	let o = s("dominion"), [c, l] = i([]), u = e.prompt, d = e.active === n && !e.busy && e.phase !== "done", f = d && u && [
		"cellar",
		"chapel",
		"remodel",
		"mine",
		"throne",
		"militia",
		"bureaucrat",
		"loot",
		"cleanup"
	].includes(u.kind), m = u?.kind === "loot" || u?.kind === "cleanup" ? t.targets : t.hand, h = (n) => d && (f ? t.targets.some((e) => e.uid === n.uid) : !u && (e.phase === "action" && e.actions > 0 && P(n.id) || e.phase === "buy" && j.includes(n.id))), g = (e) => {
		if (!h(e)) {
			a(e.id);
			return;
		}
		f ? l((t) => t.includes(e.uid) ? t.filter((t) => t !== e.uid) : t.length < u.max ? [...t, e.uid] : u.max === 1 ? [e.uid] : t) : r({
			type: "play",
			uid: e.uid
		});
	}, _ = d && u && [
		"moat",
		"chancellor",
		"spy",
		"library"
	].includes(u.kind);
	return /* @__PURE__ */ C("div", {
		className: "dm-actions",
		children: [/* @__PURE__ */ C("div", {
			className: "dm-hand-row",
			children: [
				/* @__PURE__ */ S("span", {
					className: "dm-hand-label",
					children: o(u?.kind === "loot" ? "trash" : u?.kind === "cleanup" ? "discard" : "hand")
				}),
				/* @__PURE__ */ S(Z, {
					name: `hand:${n}`,
					className: "dm-hand-cards",
					children: m.map((e) => /* @__PURE__ */ S($, {
						id: e.id,
						anchor: `hand:${n}:${e.uid}`,
						inspect: () => a(e.id),
						onClick: () => g(e),
						selected: c.includes(e.uid),
						legal: h(e)
					}, e.uid))
				}),
				d && u?.kind === "library" && t.peek && /* @__PURE__ */ S("div", {
					className: "dm-peek",
					children: /* @__PURE__ */ S($, {
						id: t.peek.id,
						inspect: () => a(t.peek.id)
					})
				})
			]
		}), /* @__PURE__ */ C("div", {
			className: "dm-controls",
			children: [/* @__PURE__ */ S("div", {
				className: "dm-resources",
				children: [
					"actions",
					"buys",
					"coins"
				].map((t) => /* @__PURE__ */ C("span", { children: [/* @__PURE__ */ S("small", { children: o(t) }), /* @__PURE__ */ S(p, { value: e[t] })] }, t))
			}), /* @__PURE__ */ C("div", {
				className: "dm-buttons",
				children: [
					f && /* @__PURE__ */ C("button", {
						className: "dm-primary",
						disabled: c.length < u.min || c.length > u.max,
						onClick: () => r({
							type: "choose",
							uids: c
						}),
						children: [
							o("confirm"),
							" · ",
							c.length
						]
					}),
					_ && /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("button", {
						className: "dm-primary",
						onClick: () => r({
							type: "answer",
							yes: !0
						}),
						children: o("yes")
					}), /* @__PURE__ */ S("button", {
						className: "dm-secondary",
						onClick: () => r({
							type: "answer",
							yes: !1
						}),
						children: o("no")
					})] }),
					d && !u && e.phase === "action" && /* @__PURE__ */ S("button", {
						className: "dm-primary",
						onClick: () => r({ type: "endAction" }),
						children: o("endAction")
					}),
					d && !u && e.phase === "buy" && /* @__PURE__ */ C(x, { children: [t.hand.some((e) => j.includes(e.id)) && /* @__PURE__ */ S("button", {
						className: "dm-primary",
						onClick: () => r({ type: "treasures" }),
						children: o("treasures")
					}), /* @__PURE__ */ S("button", {
						className: "dm-secondary",
						onClick: () => r({ type: "endTurn" }),
						children: o("endTurn")
					})] })
				]
			})]
		})]
	});
}
//#endregion
//#region src/games/dominion/bot.ts
var Se = {
	drawLimit: 2,
	witchValue: 9,
	engineScale: 1,
	greenAt: 4
};
function Ce(e = {}) {
	let t = {
		...Se,
		...e
	};
	return ({ public: e, private: n }, r) => {
		if (!n || e.phase === "done" || e.busy || e.active !== r.rid) return null;
		let i = n.hand, a = e.prompt, o = Array(32).fill(0);
		o[0] = 7, o[3] = 3;
		for (let t of e.events) if (t.rid === r.rid && (t.kind === "gain" || t.kind === "trash")) for (let e of t.cards) o[e] += t.kind === "gain" ? 1 : -1;
		let s = o.reduce((e, t, n) => e + (P(n) && ![
			7,
			11,
			21,
			25,
			26,
			28
		].includes(n) ? t : 0), 0), c = o.reduce((e, t) => e + t, 0), l = e.supply[5] <= t.greenAt, u = (n) => {
			if (n === 6) return -20;
			if (n === 5) return 30;
			if (n === 4) return l ? 14 : 0;
			if (n === 3) return e.supply[5] <= 2 ? 6 : -2;
			if (n === 0) return -1;
			if (n === 1) return 3.5;
			if (n === 2) return 7;
			if (n === 16) return e.supply[5] <= 3 ? 6 : 0;
			if (r.difficulty === "weak") return n === 20 && o[n] < 1 ? 5 : 0;
			let i = 0;
			return n === 30 && (i = e.supply[6] > 0 && o[n] < 2 ? t.witchValue : o[n] < t.drawLimit ? 4 : 0), (n === 20 || n === 17) && (i = o[n] < t.drawLimit && s < t.drawLimit + o[11] + o[25] ? 5.5 : 0), n === 26 && (i = o[n] < t.drawLimit ? 7.2 : 0), n === 28 && (i = o[n] < t.drawLimit ? 5.6 : 0), (n === 11 || n === 25) && (i = s > o[11] + o[25] + 1 ? 5.8 : 0), n === 8 && (i = o[n] === 0 && e.turnNo <= 5 ? 4.6 : 0), n === 18 && (i = o[n] === 0 && o[0] >= 4 && e.turnNo <= 10 ? 5.9 : 0), n === 9 && (i = o[n] === 0 && e.kingdom.some((e) => [17, 30].includes(e)) ? 4.1 : 0), n === 23 && (i = o[n] < 1 && s >= 2 ? 5.9 : 0), n === 27 && (i = o[n] < 1 && s < 3 ? 5.4 : 0), n === 31 && (i = o[n] < 1 && o[2] >= 2 ? 5 : 0), n === 21 && (i = o[n] < 1 ? 3.2 : 0), [
				7,
				10,
				12,
				13,
				14,
				15,
				19,
				22,
				24,
				29
			].includes(n) && (i = o[n] === 0 && s < 2 ? A[n] + .15 : 0), i * t.engineScale * (P(n) && o.filter((e, t) => P(t)).reduce((e, t) => e + t, 0) > c * .3 ? .55 : 1);
		}, d = (e) => [11, 25].includes(e) ? 100 : [
			26,
			28,
			21,
			7
		].includes(e) ? 90 : e === 23 ? 85 : e === 8 ? i.some((e) => [
			0,
			3,
			6
		].includes(e.id)) ? 80 : 1 : e === 18 ? i.some((e) => e.id === 0) ? 75 : 0 : e === 30 ? 70 : e === 20 ? 60 : e === 27 ? 50 : e === 17 ? 45 : P(e) ? 30 : 0, f;
		if (a) {
			if (a.kind === "gain") f = {
				type: "gain",
				id: [...n.gains].sort((e, t) => u(t) - u(e) || A[t] - A[e])[0]
			};
			else if ([
				"moat",
				"chancellor",
				"spy",
				"library"
			].includes(a.kind)) {
				let t = !0;
				if (a.kind === "chancellor" && (t = (e.players.find((e) => e.rid === r.rid)?.deck ?? 0) < 4), a.kind === "library" && (t = e.actions === 0 || !P(n.peek?.id ?? -1)), a.kind === "spy") {
					let n = e.revealed?.cards[0]?.id ?? 6, i = n === 6 || M.includes(n);
					t = e.revealed?.rid === r.rid ? i : !i;
				}
				f = {
					type: "answer",
					yes: t
				};
			} else {
				let t = n.targets.slice();
				if (a.kind === "chapel") {
					let e = t.filter((e) => e.id === 6 || e.id === 3 && !l), n = o[0] + 2 * o[1] + 3 * o[2], r = Math.max(0, Math.min(o[0] - 4, n - 8));
					t = [...e, ...t.filter((e) => e.id === 0).slice(0, r)].slice(0, a.max);
				} else a.kind === "cellar" ? t = t.filter((e) => M.includes(e.id) || e.id === 6) : a.kind === "loot" ? t = t.filter((e) => e.id > 0) : a.kind === "cleanup" ? t.sort((e, t) => Number(i.some((t) => t.uid === e.uid)) - Number(i.some((e) => e.uid === t.uid))) : a.kind === "thief" ? t.sort((e, t) => t.id - e.id) : a.kind === "throne" ? t.sort((e, t) => d(t.id) - d(e.id)) : a.kind === "mine" ? t.sort((e, t) => (e.id === 1 ? -1 : 0) - (t.id === 1 ? -1 : 0)) : t.sort((t, n) => {
					let r = (t) => t === 6 ? -100 : M.includes(t) ? -50 : t === 0 ? -5 : P(t) ? e.actions > 0 ? d(t) : 1 : t + 2;
					return r(t.id) - r(n.id);
				});
				[
					"cellar",
					"chapel",
					"loot"
				].includes(a.kind) || (t = t.slice(0, a.min || 1)), f = {
					type: "choose",
					uids: t.map((e) => e.uid)
				};
			}
		} else if (e.phase === "action") {
			let t = i.filter((e) => P(e.id)).sort((e, t) => d(t.id) - d(e.id));
			f = e.actions > 0 && t.length ? {
				type: "play",
				uid: t[0].uid
			} : { type: "endAction" };
		} else if (i.some((e) => j.includes(e.id))) f = { type: "treasures" };
		else {
			let t = Object.entries(e.supply).filter(([t, n]) => n > 0 && A[+t] <= e.coins && u(+t) > 0).map(([e]) => +e).sort((e, t) => u(t) - u(e) || A[t] - A[e]);
			f = e.buys > 0 && t.length ? {
				type: "buy",
				id: t[0]
			} : { type: "endTurn" };
		}
		return { action: f };
	};
}
var we = Ce(), Te = { dominionMove(e, t) {
	let n = e.data;
	if (!n || !e.rid || n.n === 0) return {
		ms: 0,
		node: null
	};
	let r = t.anchor(n.from) ?? t.anchor(`seat:${e.rid}`), i = t.anchor(n.to) ?? t.anchor(`seat:${e.rid}`);
	if (!r || !i) return null;
	let a = e.secret, o = a?.cards ?? n.cards, s = a?.uids ?? n.uids, c = Math.min(n.n, 5), l = t.queued > 0 ? 160 : 380, u = {
		x: i.x + (i.w - Math.min(i.w, 75)) / 2,
		y: i.y + (i.h - Math.min(i.h, 104)) / 2,
		w: Math.min(i.w, 75),
		h: Math.min(i.h, 104)
	}, d = Array.from({ length: c }, (e, t) => t === c - 1 ? n.n - 1 : t);
	return {
		ms: l,
		hide: t.queued > 0 ? [] : d.flatMap((e) => s?.[e] !== void 0 && t.anchor(`${n.to}:${s[e]}`) ? [`${n.to}:${s[e]}`] : []),
		node: /* @__PURE__ */ S(x, { children: d.map((e, i) => /* @__PURE__ */ S(w, {
			from: {
				x: r.x + (r.w - Math.min(r.w, 75)) / 2 + i * 3,
				y: r.y + (r.h - Math.min(r.h, 104)) / 2,
				w: Math.min(r.w, 75),
				h: Math.min(r.h, 104)
			},
			to: (s?.[e] === void 0 ? null : t.anchor(`${n.to}:${s[e]}`)) ?? {
				...u,
				x: u.x + i * 5
			},
			ms: l - i * 12,
			delay: i * 12,
			children: /* @__PURE__ */ S("div", {
				className: "dm-screen",
				style: {
					width: 75,
					height: 104
				},
				children: /* @__PURE__ */ S(Q, {
					id: o?.[e] ?? null,
					compact: !0
				})
			})
		}, e)) })
	};
} };
//#endregion
//#region src/games/dominion/game-over.tsx
function Ee(e) {
	let t = s("dominion"), a = l(), o = c((e) => e.locale), d = e.public, [p, m] = i(!0), h = r(null), g = r(null), _ = r(null), v = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? ee(n, o) : t;
	}, y = (e) => d.players.find((t) => t.rid === e)?.collection ?? [];
	return n(() => {
		(p ? g : _).current?.focus({ preventScroll: !0 });
	}, [p]), /* @__PURE__ */ C("div", {
		className: "dm-end",
		children: [
			/* @__PURE__ */ S("div", {
				className: "dm-end-board",
				inert: p,
				children: /* @__PURE__ */ S(ye, {
					public: e.public,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {}
				})
			}),
			/* @__PURE__ */ S("div", {
				className: "dm-result-overlay",
				hidden: !p,
				children: /* @__PURE__ */ C("section", {
					className: "dm-result-panel",
					ref: h,
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("result"),
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), m(!1)), e.key === "Tab") {
							let t = h.current?.querySelectorAll("button:not(:disabled),summary,[tabindex=\"0\"]");
							t?.length && (e.shiftKey && document.activeElement === t[0] ? (e.preventDefault(), t[t.length - 1].focus()) : !e.shiftKey && document.activeElement === t[t.length - 1] && (e.preventDefault(), t[0].focus()));
						}
					},
					children: [
						/* @__PURE__ */ C("header", { children: [/* @__PURE__ */ S("span", { children: "DOMINION" }), /* @__PURE__ */ S("button", {
							ref: g,
							onClick: () => m(!1),
							"aria-label": t("review"),
							children: /* @__PURE__ */ S(u, { size: 22 })
						})] }),
						/* @__PURE__ */ C("div", {
							className: "dm-result-scroll",
							children: [
								/* @__PURE__ */ S(ne, {}),
								/* @__PURE__ */ S("div", {
									className: "dm-seal",
									"aria-hidden": "true",
									children: /* @__PURE__ */ C("svg", {
										viewBox: "0 0 100 100",
										children: [
											/* @__PURE__ */ S("path", {
												d: "M50 3L60 10L73 8L80 20L92 27L90 40L97 50L90 60L92 73L80 80L73 92L60 90L50 97L40 90L27 92L20 80L8 73L10 60L3 50L10 40L8 27L20 20L27 8L40 10Z",
												fill: "#8c392f"
											}),
											/* @__PURE__ */ S("circle", {
												cx: "50",
												cy: "50",
												r: "31",
												fill: "none",
												stroke: "#c47c54",
												strokeWidth: "2"
											}),
											/* @__PURE__ */ S("path", {
												d: "M30 62V36L42 47L50 30L58 47L70 36V62ZM30 69H70",
												fill: "none",
												stroke: "#ead9a8",
												strokeWidth: "4"
											})
										]
									})
								}),
								/* @__PURE__ */ S("h1", { children: t("result") }),
								/* @__PURE__ */ S("p", {
									className: "dm-winner",
									children: t(e.result.winner.length > 1 ? "tie" : "winners", { name: e.result.winner.map(v).join(" / ") })
								}),
								e.hintCount !== void 0 && e.hintCount > 0 && /* @__PURE__ */ S("p", { children: t("hint", { n: e.hintCount }) }),
								/* @__PURE__ */ S("div", {
									className: "dm-score-scroll",
									children: /* @__PURE__ */ C("table", {
										"aria-label": t("scoreDetail"),
										children: [
											/* @__PURE__ */ S("thead", { children: /* @__PURE__ */ C("tr", { children: [/* @__PURE__ */ S("th", { children: t("scoreDetail") }), e.result.ranking.map((n) => /* @__PURE__ */ C("th", {
												"data-winner": e.result.winner.includes(n),
												children: [
													e.result.winner.includes(n) && /* @__PURE__ */ S("span", {
														"aria-hidden": "true",
														children: "♛ "
													}),
													v(n),
													(e.result.autopilot?.[n] ?? 0) > 0 && /* @__PURE__ */ S("small", { children: t("autopilot", { n: Math.round(e.result.autopilot[n] * 100) }) })
												]
											}, n))] }) }),
											/* @__PURE__ */ C("tbody", { children: [
												[
													3,
													4,
													5,
													16,
													6
												].map((n) => /* @__PURE__ */ C("tr", { children: [/* @__PURE__ */ S("th", { children: t(`cards.${k[n]}.name`) }), e.result.ranking.map((e) => /* @__PURE__ */ S("td", { children: I(y(e).map((e) => e.id))[n] }, e))] }, n)),
												/* @__PURE__ */ C("tr", { children: [/* @__PURE__ */ S("th", { children: t("totalCards") }), e.result.ranking.map((e) => /* @__PURE__ */ S("td", { children: y(e).length }, e))] }),
												/* @__PURE__ */ C("tr", { children: [/* @__PURE__ */ S("th", { children: t("turns") }), e.result.ranking.map((e) => /* @__PURE__ */ S("td", { children: d.players.find((t) => t.rid === e)?.turns }, e))] })
											] }),
											/* @__PURE__ */ S("tfoot", { children: /* @__PURE__ */ C("tr", { children: [/* @__PURE__ */ S("th", { children: t("score") }), e.result.ranking.map((t) => /* @__PURE__ */ S("td", { children: e.result.scores?.[t] ?? d.players.find((e) => e.rid === t)?.score }, t))] }) })
										]
									})
								})
							]
						}),
						/* @__PURE__ */ C("footer", { children: [
							e.onPlayAgain && /* @__PURE__ */ S(T, {
								label: a("session.result.playAgain"),
								confirmLabel: a("session.result.playAgain"),
								onConfirm: e.onPlayAgain
							}),
							" ",
							e.onBackToLobby && /* @__PURE__ */ S(T, {
								label: a("session.result.backToLobby"),
								confirmLabel: a("session.result.backToLobby"),
								onConfirm: e.onBackToLobby
							}),
							" ",
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ S("p", { children: a("session.result.waitHost") })
						] })
					]
				})
			}),
			/* @__PURE__ */ S("div", {
				className: "dm-result-restore",
				hidden: p,
				children: /* @__PURE__ */ C("button", {
					ref: _,
					className: "dm-primary",
					onClick: () => m(!0),
					children: [/* @__PURE__ */ S(f, { size: 18 }), t("showResult")]
				})
			})
		]
	});
}
//#endregion
//#region src/games/dominion/options.tsx
var De = [
	"first",
	"money",
	"interaction",
	"size",
	"village",
	"random"
];
function Oe({ value: e, onChange: t }) {
	let n = s("dominion"), r = R.safeParse(e), i = r.success ? r.data : R.parse(void 0);
	return /* @__PURE__ */ C("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ S(O, {
				title: n("setTitle"),
				columns: 2,
				children: De.map((e, r) => /* @__PURE__ */ S(D, {
					name: "dominion-set",
					value: String(r),
					checked: i.set === r,
					label: n(`sets.${e}`),
					accent: L.accent,
					onChange: () => t({
						...i,
						set: r,
						kingdom: []
					})
				}, e))
			}),
			/* @__PURE__ */ S(O, {
				title: n("custom"),
				columns: 2,
				children: re.map((e) => /* @__PURE__ */ S(E, {
					name: "dominion-kingdom",
					value: String(e),
					label: n(`cards.${k[e]}.name`),
					checked: i.kingdom.includes(e),
					accent: L.accent,
					onChange: () => t({
						...i,
						kingdom: i.kingdom.includes(e) ? i.kingdom.filter((t) => t !== e) : i.kingdom.length < 10 ? [...i.kingdom, e] : i.kingdom
					})
				}, e))
			}),
			/* @__PURE__ */ S("p", { children: n("customCount", { n: i.kingdom.length }) })
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/dominion/entry.tsx
var ke = {
	definition: ve,
	View: ye,
	bot: we,
	fx: Te,
	OverView: Ee,
	Options: Oe,
	locales: {
		zh: {
			name: "领土（皇舆争霸）",
			desc: "从十张起始牌出发，构筑你的王国。2008 年基础版，25 种王国牌。",
			rules: "目标：\n通过购买与获得卡牌构筑自己的牌库。游戏结束时，将手牌、牌库、弃牌堆和场上所有属于自己的牌合并计分。庄园为 1 分，公国为 3 分，行省为 6 分，诅咒为负 1 分；每张花园的分数等于自己的总牌数除以 10 后向下取整。\n准备：\n本游戏采用 2008 年官方基础版，包含全部 25 种王国牌，每局使用 10 种。可选官方推荐组合、随机组合，或自选恰好 10 种。每人从 7 张铜币和 3 张庄园开始，洗牌后抽 5 张手牌；随机决定先手，依次轮流行动。\n铜币共 60 张，起始牌从中取出；银币 40 张，金币 30 张。两人局的庄园、公国、行省和花园供应堆各 8 张，三至四人局各 12 张，起始庄园另计。其余王国牌每堆 10 张。诅咒在两、三、四人局分别为 10、20、30 张。\n流程：\n每回合依次进行行动、购买与清理。开始时拥有 1 次行动和 1 次购买。行动阶段可打出一张行动牌，按牌面完整结算；牌面增加的行动次数可用于继续出牌。必须完成当前牌的全部效果，才能打出另一张牌。也可直接结束行动阶段。\n购买阶段可打出任意财宝牌：铜币提供 1 金钱，银币提供 2 金钱，金币提供 3 金钱。金钱也可来自行动牌。每买一张供应牌，支付其费用并消耗 1 次购买，将该牌放入自己的弃牌堆。获得牌与购买牌不同：获得牌不花费金钱或购买次数，但必须遵守该效果的费用及类型限制。未用的金钱、行动与购买不保留到下回合。\n结束回合时，将已打出的牌与剩余手牌放入自己的弃牌堆，可选择最后放到弃牌堆顶的牌，再抽 5 张牌。需要抽牌或揭示牌而牌库不足时，先取完现有牌库，再洗混弃牌堆形成新牌库；不要提前洗牌。移除的牌进入公共垃圾区，不回到供应堆。\n卡牌与攻击：\n点击供应牌或手牌上的详情可查看完整效果。民兵、官员、间谍、小偷与女巫属于攻击牌；其他玩家可从手牌展示护城河，选择不受本次攻击影响。未受保护的玩家依次结算，不能代替其他玩家决定弃牌或选择。议事厅让其他玩家抽牌，不属于攻击。\n· 地窖先一次性弃掉所选手牌，再抽同样数量。\n· 礼拜堂可移除至多 4 张手牌。\n· 重建移除一张手牌，获得费用至多高 2 的供应牌。\n· 矿坑移除一张财宝牌，获得1张财宝牌并加入手牌，其费用最多比被移除的财宝牌高3枚金币。\n· 钱庄移除一张手牌中的铜币，提供 3 金钱；没有铜币则不提供金钱。\n· 王座从手牌选择另一张行动牌，完整执行两次，不消耗额外行动；王座作用于王座时，依次选择两张牌各执行两次。\n· 盛宴移除自身后获得费用至多 5 的牌；被王座重复执行时，即使自身已移除，第二次仍可获得牌。\n· 图书馆抽至 7 张手牌，途中抽到的行动牌可以暂置；暂置牌在图书馆结算完毕后才弃掉。\n· 冒险者逐张揭示直到找到 2 张财宝牌，将财宝加入手牌，最后弃掉其他揭示牌；若已无牌可取，则取得能找到的财宝。\n· 间谍在抽牌后让自己及每名未受保护的对手揭示牌库顶牌，由打出间谍者决定弃掉或放回。\n· 小偷让每名未受保护的对手揭示 2 张牌；若其中有财宝，由攻击者选择 1 张移除，其他揭示牌弃掉；所有对手结算后，攻击者可获得任意张本次移除的财宝。\n结束与计分：\n任一玩家回合结束时，若行省供应堆已空，或任意 3 个供应堆已空，立即结束游戏。总分最高者获胜；同分时，进行回合较少者获胜；分数和回合数均相同则共同获胜。",
			invalid: "当前无法执行这个操作，请重新选择。",
			action: "行动阶段",
			buy: "购买阶段",
			done: "王国已建成",
			resolving: "正在结算",
			waiting: "等待 {{name}}",
			turn: "第 {{n}} 回合",
			actions: "行动",
			buys: "购买",
			coins: "金钱",
			hand: "手牌",
			deck: "牌库",
			discard: "弃牌堆",
			trash: "垃圾区",
			supply: "供应区",
			kingdom: "王国牌",
			basic: "基础牌",
			play: "已打出的牌",
			reveal: "揭示区",
			aside: "暂置区",
			empty: "暂无卡牌",
			count: "剩余 {{n}} 张",
			detail: "卡牌详情",
			inspect: "查看 {{card}}",
			playCard: "打出此牌",
			buyCard: "购买此牌",
			gainCard: "获得此牌",
			endAction: "进入购买阶段",
			treasures: "打出全部财宝",
			endTurn: "结束回合",
			confirm: "确认选择",
			selected: "已选 {{n}} 张",
			yes: "是",
			no: "否",
			close: "关闭",
			history: "对局记录",
			cost: "费用",
			actionType: "行动",
			attackType: "行动 · 攻击",
			reactionType: "行动 · 反应",
			treasureType: "财宝",
			victoryType: "胜利",
			curseType: "诅咒",
			score: "总分",
			turns: "进行回合",
			collection: "王国藏牌",
			totalCards: "总牌数",
			result: "王国的荣光",
			winners: "{{name}} 获胜",
			tie: "{{name}} 共同获胜",
			review: "回看王国",
			showResult: "查看结算",
			scoreDetail: "计分明细",
			hint: "本局求助 {{n}} 次",
			autopilot: "托管 {{n}}%",
			setTitle: "王国组合",
			sets: {
				first: "初次游戏",
				money: "财富之路",
				interaction: "互动",
				size: "规模变化",
				village: "村庄广场",
				random: "随机组合"
			},
			custom: "自选王国牌（恰好 10 种）",
			customCount: "已选择 {{n}} 种；选择 10 种后使用自选组合。",
			prompt: {
				cleanup: "选择本回合最后放到弃牌堆顶的牌",
				cellar: "选择要弃掉的手牌，再抽取同样数量",
				chapel: "选择至多 4 张手牌移除",
				remodel: "选择 1 张手牌移除",
				mine: "选择 1 张财宝牌移除",
				throne: "选择 1 张行动牌，完整执行两次",
				militia: "弃掉 {{n}} 张手牌，保留 3 张",
				bureaucrat: "选择 1 张胜利牌放到牌库顶",
				moat: "是否展示护城河，抵挡本次攻击？",
				chancellor: "是否将整副牌库放入弃牌堆？",
				spy: "是否弃掉这张揭示牌？",
				thief: "选择 1 张揭示的财宝牌移除",
				loot: "选择要获得的财宝牌，可不选",
				library: "是否暂置刚抽到的行动牌？",
				gain: "获得费用至多为 {{n}} 的{{type}}牌"
			},
			event: {
				turn: "{{name}} 开始回合",
				play: "{{name}} 打出了 {{cards}}",
				gain: "{{name}} 获得了 {{cards}}",
				trash: "{{name}} 移除了 {{cards}}",
				reveal: "{{name}} 展示了 {{cards}}",
				moat: "{{name}} 展示护城河，抵挡了攻击",
				discard: "{{name}} 弃掉了 {{cards}}",
				discardCount: "{{name}} 弃掉了手牌",
				treasures: "{{name}} 打出了 {{cards}}",
				end: "游戏结束"
			},
			cards: {
				copper: {
					name: "铜币",
					text: "打出时提供 1 金钱。"
				},
				silver: {
					name: "银币",
					text: "打出时提供 2 金钱。"
				},
				gold: {
					name: "金币",
					text: "打出时提供 3 金钱。"
				},
				estate: {
					name: "庄园",
					text: "游戏结束时获得 1 分。"
				},
				duchy: {
					name: "公国",
					text: "游戏结束时获得 3 分。"
				},
				province: {
					name: "行省",
					text: "游戏结束时获得 6 分。"
				},
				curse: {
					name: "诅咒",
					text: "游戏结束时扣除 1 分。"
				},
				cellar: {
					name: "地窖",
					text: "增加 1 次行动。弃掉任意数量的手牌，然后抽取同样数量的牌。"
				},
				chapel: {
					name: "礼拜堂",
					text: "移除至多 4 张手牌。"
				},
				moat: {
					name: "护城河",
					text: "抽 2 张牌。\n反应：其他玩家打出攻击牌时，可以从手牌展示此牌，抵挡该攻击对你的影响。"
				},
				chancellor: {
					name: "大臣",
					text: "提供 2 金钱。可以将整副牌库放入弃牌堆。"
				},
				village: {
					name: "村庄",
					text: "抽 1 张牌。增加 2 次行动。"
				},
				woodcutter: {
					name: "伐木工",
					text: "增加 1 次购买。提供 2 金钱。"
				},
				workshop: {
					name: "工坊",
					text: "获得 1 张费用至多为 4 的供应牌。"
				},
				bureaucrat: {
					name: "官员",
					text: "获得 1 张银币，放到牌库顶。其他玩家各展示 1 张手牌中的胜利牌并放到牌库顶；没有胜利牌者展示手牌。"
				},
				feast: {
					name: "盛宴",
					text: "移除此牌。获得 1 张费用至多为 5 的供应牌。"
				},
				gardens: {
					name: "花园",
					text: "每张花园获得的分数等于自己的总牌数除以 10 后向下取整。"
				},
				militia: {
					name: "民兵",
					text: "提供 2 金钱。其他玩家各弃掉手牌，直至只剩 3 张。"
				},
				moneylender: {
					name: "钱庄",
					text: "移除 1 张手牌中的铜币。若移除了铜币，提供 3 金钱。"
				},
				remodel: {
					name: "重建",
					text: "移除 1 张手牌。获得 1 张费用至多比该牌高 2 的供应牌。"
				},
				smithy: {
					name: "铁匠铺",
					text: "抽 3 张牌。"
				},
				spy: {
					name: "间谍",
					text: "抽 1 张牌。增加 1 次行动。每名玩家（包括自己）各揭示牌库顶的 1 张牌，由你决定将其弃掉或放回牌库顶。"
				},
				thief: {
					name: "小偷",
					text: "其他玩家各揭示牌库顶的 2 张牌。若揭示了财宝牌，由你选择其中 1 张移除，并弃掉其余揭示牌。然后你可以获得任意张本次移除的财宝牌。"
				},
				throneRoom: {
					name: "王座",
					text: "从手牌选择另 1 张行动牌，完整执行两次。"
				},
				councilRoom: {
					name: "议事厅",
					text: "抽 4 张牌。增加 1 次购买。其他玩家各抽 1 张牌。"
				},
				festival: {
					name: "庆典",
					text: "增加 2 次行动和 1 次购买。提供 2 金钱。"
				},
				laboratory: {
					name: "实验室",
					text: "抽 2 张牌。增加 1 次行动。"
				},
				library: {
					name: "图书馆",
					text: "抽牌直至手牌达到 7 张。途中抽到的行动牌可以暂置；完成抽牌后弃掉所有暂置牌。"
				},
				market: {
					name: "市集",
					text: "抽 1 张牌。增加 1 次行动和 1 次购买。提供 1 金钱。"
				},
				mine: {
					name: "矿坑",
					text: "移除 1 张手牌中的财宝牌。获得 1 张费用至多比该牌高 3 的财宝牌，放入手牌。"
				},
				witch: {
					name: "女巫",
					text: "抽 2 张牌。其他玩家各获得 1 张诅咒。"
				},
				adventurer: {
					name: "冒险者",
					text: "逐张揭示牌库顶的牌，直至找到 2 张财宝牌。将揭示的财宝牌加入手牌，再弃掉其他揭示牌。"
				}
			}
		},
		en: {
			name: "Dominion",
			desc: "Build a kingdom from ten starting cards. Complete 2008 base game with 25 Kingdom cards.",
			rules: "Goal:\nBuild your own deck by buying and gaining cards. At game end, combine all your cards from your hand, deck, discard pile and play area. Estates score 1 VP, Duchies 3 VP, Provinces 6 VP and Curses −1 VP. Each Gardens scores 1 VP per 10 cards you own, rounded down.\nSetup:\nThis implementation uses the official 2008 base edition, with all 25 Kingdom cards. Each game uses 10 types. Choose a recommended set, a random set, or exactly 10 custom types. Everyone starts with 7 Coppers and 3 Estates, shuffled, and draws 5 cards. The first player is chosen randomly; play proceeds in seating order.\nThere are 60 Coppers in total, including starting cards, 40 Silvers and 30 Golds. Estate, Duchy, Province and Gardens Supply piles contain 8 cards with 2 players or 12 with 3–4 players; starting Estates are additional. Other Kingdom piles contain 10 cards. Use 10, 20 or 30 Curses with 2, 3 or 4 players respectively.\nTurn:\nEach turn has Action, Buy and Clean-up phases. Start with 1 Action and 1 Buy. You may play an Action card and follow all its instructions. Additional Actions granted by cards allow further plays, after the current card has fully resolved. You may also end your Action phase.\nIn the Buy phase, you may play Treasure cards: Copper provides $1, Silver $2 and Gold $3. Add coins from Action cards. Pay a Supply card's cost and spend 1 Buy to place it in your discard pile. Gaining is different from buying: it spends neither coins nor Buys, but must follow the effect's cost and type limits. Unused coins, Actions and Buys do not carry over.\nTo end your turn, discard your played cards and remaining hand in any order, choosing which card goes on top, then draw 5 cards. When drawing or revealing from an insufficient deck, take existing cards first, then shuffle your discard pile into a new deck and continue. Never shuffle early. Trashed cards go to the shared Trash, not back to the Supply.\nCards and attacks:\nUse a card's details control to read its full text. Militia, Bureaucrat, Spy, Thief and Witch are Attacks. Other players may reveal a Moat from their hand to be unaffected by that Attack. Resolve affected players in turn order, allowing each player to make their own required choices. Council Room is not an Attack.\n· Cellar discards all chosen cards before drawing replacements.\n· Chapel trashes up to 4 cards.\n· Remodel trashes a hand card to gain a Supply card costing up to $2 more.\n· Mine trashes a Treasure from hand to gain a Treasure costing up to $3 more into hand.\n· Moneylender trashes a Copper from hand for $3; without a Copper it provides no coins.\n· Throne Room chooses another Action from hand and fully plays it twice without spending additional Actions. A Throne Room played by a Throne Room chooses two cards in succession and plays each twice.\n· Feast trashes itself and gains a card costing up to $5; when played twice, it gains another card even though Feast has already been trashed.\n· Library draws until you have 7 cards. Action cards drawn may be set aside and are discarded only after Library finishes.\n· Adventurer reveals until it finds 2 Treasures, putting those into hand and discarding other revealed cards afterwards; if cards run out, take all Treasures found.\n· Spy draws first, then makes you and each unprotected opponent reveal their top card. The Spy player chooses to discard or return each one.\n· Thief makes each unprotected opponent reveal 2 cards; the attacker chooses 1 revealed Treasure to trash if possible, and the rest are discarded. After all opponents resolve, the attacker may gain any of the Treasures just trashed.\nEnd and scoring:\nThe game ends at the end of a player's turn if the Province Supply pile is empty or any 3 Supply piles are empty. Highest VP wins. Ties go to the player with fewer turns; equal points and turns produce a shared victory.",
			invalid: "That action is not available. Please choose again.",
			action: "Action phase",
			buy: "Buy phase",
			done: "Kingdom complete",
			resolving: "Resolving",
			waiting: "Waiting for {{name}}",
			turn: "Turn {{n}}",
			actions: "Actions",
			buys: "Buys",
			coins: "Coins",
			hand: "Hand",
			deck: "Deck",
			discard: "Discard",
			trash: "Trash",
			supply: "Supply",
			kingdom: "Kingdom",
			basic: "Basic cards",
			play: "In play",
			reveal: "Revealed",
			aside: "Set aside",
			empty: "No cards",
			count: "{{n}} remaining",
			detail: "Card details",
			inspect: "Inspect {{card}}",
			playCard: "Play this card",
			buyCard: "Buy this card",
			gainCard: "Gain this card",
			endAction: "Go to Buy phase",
			treasures: "Play all Treasures",
			endTurn: "End turn",
			confirm: "Confirm selection",
			selected: "{{n}} selected",
			yes: "Yes",
			no: "No",
			close: "Close",
			history: "History",
			cost: "Cost",
			actionType: "Action",
			attackType: "Action · Attack",
			reactionType: "Action · Reaction",
			treasureType: "Treasure",
			victoryType: "Victory",
			curseType: "Curse",
			score: "Total VP",
			turns: "Turns taken",
			collection: "Kingdom collection",
			totalCards: "Total cards",
			result: "Glory of the kingdom",
			winners: "{{name}} wins",
			tie: "{{name}} share victory",
			review: "Review kingdoms",
			showResult: "Show results",
			scoreDetail: "Score breakdown",
			hint: "Hints used: {{n}}",
			autopilot: "Autopilot {{n}}%",
			setTitle: "Kingdom set",
			sets: {
				first: "First Game",
				money: "Big Money",
				interaction: "Interaction",
				size: "Size Distortion",
				village: "Village Square",
				random: "Random"
			},
			custom: "Custom Kingdom (exactly 10 types)",
			customCount: "{{n}} selected; select 10 types to use a custom Kingdom.",
			prompt: {
				cleanup: "Choose the card to place on top of your discard pile",
				cellar: "Discard any number of hand cards, then draw that many",
				chapel: "Trash up to 4 cards from your hand",
				remodel: "Trash 1 card from your hand",
				mine: "Trash 1 Treasure from your hand",
				throne: "Choose 1 Action to play twice",
				militia: "Discard {{n}} hand cards, keeping 3",
				bureaucrat: "Put 1 Victory card from hand on your deck",
				moat: "Reveal Moat to block this Attack?",
				chancellor: "Put your entire deck into your discard pile?",
				spy: "Discard this revealed card?",
				thief: "Choose 1 revealed Treasure to trash",
				loot: "Choose any Treasures to gain, including none",
				library: "Set aside the Action card just drawn?",
				gain: "Gain a {{type}}card costing up to ${{n}}"
			},
			event: {
				turn: "{{name}} starts a turn",
				play: "{{name}} plays {{cards}}",
				gain: "{{name}} gains {{cards}}",
				trash: "{{name}} trashes {{cards}}",
				reveal: "{{name}} reveals {{cards}}",
				moat: "{{name}} reveals Moat and blocks the Attack",
				discard: "{{name}} discards {{cards}}",
				discardCount: "{{name}} discards hand cards",
				treasures: "{{name}} plays {{cards}}",
				end: "The game ends"
			},
			cards: {
				copper: {
					name: "Copper",
					text: "Provides $1 when played."
				},
				silver: {
					name: "Silver",
					text: "Provides $2 when played."
				},
				gold: {
					name: "Gold",
					text: "Provides $3 when played."
				},
				estate: {
					name: "Estate",
					text: "Worth 1 VP at game end."
				},
				duchy: {
					name: "Duchy",
					text: "Worth 3 VP at game end."
				},
				province: {
					name: "Province",
					text: "Worth 6 VP at game end."
				},
				curse: {
					name: "Curse",
					text: "Worth −1 VP at game end."
				},
				cellar: {
					name: "Cellar",
					text: "+1 Action. Discard any number of cards, then draw that many."
				},
				chapel: {
					name: "Chapel",
					text: "Trash up to 4 cards from your hand."
				},
				moat: {
					name: "Moat",
					text: "+2 Cards.\nReaction: When another player plays an Attack, you may reveal this from your hand to be unaffected by it."
				},
				chancellor: {
					name: "Chancellor",
					text: "+$2. You may immediately put your deck into your discard pile."
				},
				village: {
					name: "Village",
					text: "+1 Card. +2 Actions."
				},
				woodcutter: {
					name: "Woodcutter",
					text: "+1 Buy. +$2."
				},
				workshop: {
					name: "Workshop",
					text: "Gain a card costing up to $4."
				},
				bureaucrat: {
					name: "Bureaucrat",
					text: "Gain a Silver onto your deck. Each other player reveals a Victory card from hand and puts it onto their deck, or reveals a hand with no Victory cards."
				},
				feast: {
					name: "Feast",
					text: "Trash this card. Gain a card costing up to $5."
				},
				gardens: {
					name: "Gardens",
					text: "Worth 1 VP per 10 cards you own, rounded down."
				},
				militia: {
					name: "Militia",
					text: "+$2. Each other player discards down to 3 cards in hand."
				},
				moneylender: {
					name: "Moneylender",
					text: "Trash a Copper from your hand. If you do, +$3."
				},
				remodel: {
					name: "Remodel",
					text: "Trash a card from your hand. Gain a card costing up to $2 more than it."
				},
				smithy: {
					name: "Smithy",
					text: "+3 Cards."
				},
				spy: {
					name: "Spy",
					text: "+1 Card. +1 Action. Each player, including you, reveals their top card. You choose whether each is discarded or put back."
				},
				thief: {
					name: "Thief",
					text: "Each other player reveals their top 2 cards. If they revealed Treasures, trash one you choose; discard the rest. You may then gain any of the Treasures just trashed."
				},
				throneRoom: {
					name: "Throne Room",
					text: "Choose another Action card in your hand. Play it twice."
				},
				councilRoom: {
					name: "Council Room",
					text: "+4 Cards. +1 Buy. Each other player draws a card."
				},
				festival: {
					name: "Festival",
					text: "+2 Actions. +1 Buy. +$2."
				},
				laboratory: {
					name: "Laboratory",
					text: "+2 Cards. +1 Action."
				},
				library: {
					name: "Library",
					text: "Draw until you have 7 cards in hand. You may set aside Action cards as you draw them; discard those set aside after you finish drawing."
				},
				market: {
					name: "Market",
					text: "+1 Card. +1 Action. +1 Buy. +$1."
				},
				mine: {
					name: "Mine",
					text: "Trash a Treasure from your hand. Gain a Treasure costing up to $3 more into your hand."
				},
				witch: {
					name: "Witch",
					text: "+2 Cards. Each other player gains a Curse."
				},
				adventurer: {
					name: "Adventurer",
					text: "Reveal cards until you reveal 2 Treasures. Put those Treasures into your hand and discard the other revealed cards."
				}
			}
		}
	}
};
//#endregion
export { ke as default };
