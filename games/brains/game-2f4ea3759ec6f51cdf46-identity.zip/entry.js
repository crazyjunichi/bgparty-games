import { z as e } from "zod";
import { Component as t, useCallback as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useT as s } from "@bgparty/sdk/i18n";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import * as p from "three";
import { BoxGeometry as m, Vector3 as h } from "three";
import { useFrame as g, useThree as _ } from "@react-three/fiber";
import { ResilientCanvas as v } from "@bgparty/sdk/three/resilient-canvas";
import { usePrefersReducedMotion as y } from "@bgparty/sdk/fx/use-reduced-motion";
//#region src/games/brains/data.ts
var b = {
	1: {
		chords: [
			[
				0,
				7,
				0
			],
			[
				1,
				6,
				0
			],
			[
				2,
				4,
				0
			],
			[
				3,
				5,
				0
			]
		],
		yy: []
	},
	2: {
		chords: [
			[
				0,
				1,
				0
			],
			[
				3,
				4,
				0
			],
			[
				5,
				7,
				0
			]
		],
		yy: [2, 6]
	},
	3: {
		chords: [
			[
				0,
				5,
				1
			],
			[
				1,
				7,
				0
			],
			[
				2,
				3,
				0
			],
			[
				4,
				6,
				0
			]
		],
		yy: []
	},
	4: {
		chords: [
			[
				0,
				5,
				1
			],
			[
				1,
				6,
				0
			],
			[
				2,
				7,
				1
			],
			[
				3,
				4,
				0
			]
		],
		yy: []
	},
	5: {
		chords: [
			[
				0,
				7,
				0
			],
			[
				1,
				2,
				0
			],
			[
				3,
				6,
				1
			],
			[
				4,
				5,
				0
			]
		],
		yy: []
	},
	6: {
		chords: [
			[
				0,
				1,
				0
			],
			[
				2,
				5,
				0
			],
			[
				3,
				6,
				1
			],
			[
				4,
				7,
				0
			]
		],
		yy: []
	},
	7: {
		chords: [
			[
				0,
				2,
				0
			],
			[
				1,
				6,
				0
			],
			[
				3,
				5,
				0
			],
			[
				4,
				7,
				0
			]
		],
		yy: []
	}
}, x = [1, 6], S = [
	{
		cells: [[0, 0]],
		markers: [
			{
				cell: [0, 0],
				port: 1,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 4,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 7,
				type: "bridge",
				n: 1
			}
		],
		solution: { "0,0": [4, 1] }
	},
	{
		cells: [[0, 0]],
		markers: [
			{
				cell: [0, 0],
				port: 2,
				type: "pagoda"
			},
			{
				cell: [0, 0],
				port: 1,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 7,
				type: "pair",
				color: "red"
			}
		],
		solution: { "0,0": [1, 2] }
	},
	{
		cells: [[0, 0], [0, 1]],
		markers: [
			{
				cell: [0, 0],
				port: 3,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 0],
				port: 7,
				type: "pagoda"
			},
			{
				cell: [0, 1],
				port: 3,
				type: "pagoda"
			}
		],
		solution: {
			"0,0": [2, 0],
			"0,1": [1, 1]
		}
	},
	{
		cells: [[0, 0], [0, 1]],
		markers: [
			{
				cell: [0, 0],
				port: 3,
				type: "tiles",
				n: 3
			},
			{
				cell: [0, 0],
				port: 1,
				type: "tiles",
				n: 3
			},
			{
				cell: [0, 1],
				port: 2,
				type: "tiles",
				n: 1
			},
			{
				cell: [0, 1],
				port: 6,
				type: "yinyang"
			}
		],
		solution: {
			"0,0": [3, 2],
			"0,1": [2, 0]
		}
	},
	{
		cells: [[0, 0], [0, 1]],
		markers: [
			{
				cell: [0, 0],
				port: 3,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 0],
				port: 6,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 1],
				port: 2,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 1],
				port: 4,
				type: "tiles",
				n: 2
			}
		],
		solution: {
			"0,0": [5, 2],
			"0,1": [4, 1]
		}
	},
	{
		cells: [[0, 0], [0, 1]],
		markers: [
			{
				cell: [0, 0],
				port: 3,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 0],
				port: 0,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 6,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 1],
				port: 2,
				type: "pagoda"
			}
		],
		solution: {
			"0,0": [1, 2],
			"0,1": [3, 2]
		}
	},
	{
		cells: [[0, 0], [0, 1]],
		markers: [
			{
				cell: [0, 0],
				port: 2,
				type: "pair",
				color: "blue"
			},
			{
				cell: [0, 0],
				port: 3,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [0, 0],
				port: 1,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [0, 0],
				port: 7,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 1],
				port: 2,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 1],
				port: 3,
				type: "pair",
				color: "blue"
			}
		],
		solution: {
			"0,0": [7, 3],
			"0,1": [1, 1]
		}
	},
	{
		cells: [[0, 0], [0, 1]],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 0],
				port: 6,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 1],
				port: 2,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 1],
				port: 6,
				type: "tiles",
				n: 2
			}
		],
		solution: {
			"0,0": [3, 0],
			"0,1": [7, 0]
		}
	},
	{
		cells: [[0, 0], [0, 1]],
		markers: [
			{
				cell: [0, 0],
				port: 2,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 3,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 0,
				type: "tiles",
				n: 3
			},
			{
				cell: [0, 0],
				port: 7,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 1],
				port: 6,
				type: "bridge",
				n: 1
			}
		],
		solution: {
			"0,0": [6, 1],
			"0,1": [3, 3]
		}
	},
	{
		cells: [[0, 0], [0, 1]],
		markers: [
			{
				cell: [0, 0],
				port: 2,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 3,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 0,
				type: "tiles",
				n: 3
			},
			{
				cell: [0, 0],
				port: 7,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 1],
				port: 6,
				type: "bridge",
				n: 1
			}
		],
		solution: {
			"0,0": [6, 1],
			"0,1": [3, 3]
		}
	},
	{
		cells: [
			[0, 1],
			[1, 0],
			[1, 1]
		],
		markers: [
			{
				cell: [0, 1],
				port: 4,
				type: "pair",
				color: "blue"
			},
			{
				cell: [1, 0],
				port: 2,
				type: "pagoda"
			},
			{
				cell: [1, 0],
				port: 3,
				type: "pagoda"
			},
			{
				cell: [1, 1],
				port: 3,
				type: "pair",
				color: "blue"
			},
			{
				cell: [1, 1],
				port: 4,
				type: "yinyang"
			}
		],
		solution: {
			"0,1": [2, 0],
			"1,0": [1, 2],
			"1,1": [6, 0]
		}
	},
	{
		cells: [
			[0, 0],
			[1, 0],
			[2, 0]
		],
		markers: [
			{
				cell: [0, 0],
				port: 4,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 7,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 0,
				type: "tiles",
				n: 5
			},
			{
				cell: [1, 0],
				port: 5,
				type: "tiles",
				n: 1
			},
			{
				cell: [2, 0],
				port: 0,
				type: "bridge",
				n: 1
			}
		],
		solution: {
			"0,0": [6, 1],
			"1,0": [3, 1],
			"2,0": [5, 1]
		}
	},
	{
		cells: [
			[0, 1],
			[1, 0],
			[1, 1]
		],
		markers: [
			{
				cell: [0, 1],
				port: 0,
				type: "pair",
				color: "purple"
			},
			{
				cell: [1, 0],
				port: 6,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 1],
				port: 5,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [0, 1],
				port: 4,
				type: "pair",
				color: "blue"
			},
			{
				cell: [0, 1],
				port: 7,
				type: "pair",
				color: "blue"
			},
			{
				cell: [1, 0],
				port: 3,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 1,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [1, 1],
				port: 2,
				type: "pair",
				color: "purple"
			}
		],
		solution: {
			"0,1": [7, 0],
			"1,0": [4, 2],
			"1,1": [6, 2]
		}
	},
	{
		cells: [
			[0, 0],
			[1, 0],
			[2, 0]
		],
		markers: [
			{
				cell: [0, 0],
				port: 4,
				type: "pagoda"
			},
			{
				cell: [1, 0],
				port: 0,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 0],
				port: 1,
				type: "bridge",
				n: 1
			},
			{
				cell: [2, 0],
				port: 4,
				type: "pagoda"
			}
		],
		solution: {
			"0,0": [3, 3],
			"1,0": [4, 0],
			"2,0": [1, 3]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 1,
				type: "bridge",
				n: 2
			},
			{
				cell: [0, 0],
				port: 2,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 1],
				port: 0,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 1],
				port: 7,
				type: "bridge",
				n: 2
			}
		],
		solution: {
			"0,0": [6, 3],
			"0,1": [4, 1],
			"1,1": [3, 1]
		}
	},
	{
		cells: [
			[0, 0],
			[1, 0],
			[2, 0]
		],
		markers: [
			{
				cell: [0, 0],
				port: 1,
				type: "yinyang"
			},
			{
				cell: [0, 0],
				port: 7,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 0,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 5,
				type: "pair",
				color: "purple"
			},
			{
				cell: [2, 0],
				port: 2,
				type: "yinyang"
			},
			{
				cell: [2, 0],
				port: 0,
				type: "pair",
				color: "purple"
			}
		],
		solution: {
			"0,0": [3, 1],
			"1,0": [4, 2],
			"2,0": [2, 2]
		}
	},
	{
		cells: [
			[0, 0],
			[1, 0],
			[2, 0]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 5,
				type: "pair",
				color: "purple"
			},
			{
				cell: [1, 0],
				port: 0,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [1, 0],
				port: 1,
				type: "pair",
				color: "purple"
			},
			{
				cell: [1, 0],
				port: 5,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 4,
				type: "pair",
				color: "blue"
			},
			{
				cell: [2, 0],
				port: 1,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [2, 0],
				port: 4,
				type: "pair",
				color: "blue"
			}
		],
		solution: {
			"0,0": [3, 2],
			"1,0": [7, 1],
			"2,0": [6, 1]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0]
		],
		markers: [
			{
				cell: [0, 0],
				port: 7,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 1],
				port: 6,
				type: "yinyang"
			},
			{
				cell: [0, 1],
				port: 2,
				type: "pagoda"
			},
			{
				cell: [1, 0],
				port: 5,
				type: "tiles",
				n: 2
			}
		],
		solution: {
			"0,0": [7, 0],
			"0,1": [1, 2],
			"1,0": [2, 0]
		}
	},
	{
		cells: [
			[0, 0],
			[1, 0],
			[2, 0]
		],
		markers: [
			{
				cell: [0, 0],
				port: 1,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [0, 0],
				port: 6,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [1, 0],
				port: 1,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 5,
				type: "pair",
				color: "red"
			},
			{
				cell: [2, 0],
				port: 1,
				type: "pair",
				color: "purple"
			},
			{
				cell: [2, 0],
				port: 5,
				type: "pair",
				color: "purple"
			}
		],
		solution: {
			"0,0": [6, 1],
			"1,0": [2, 1],
			"2,0": [7, 1]
		}
	},
	{
		cells: [
			[0, 1],
			[1, 0],
			[1, 1]
		],
		markers: [
			{
				cell: [0, 1],
				port: 4,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 0],
				port: 3,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 1],
				port: 3,
				type: "bridge",
				n: 2
			},
			{
				cell: [1, 1],
				port: 4,
				type: "tiles",
				n: 4
			}
		],
		solution: {
			"0,1": [3, 3],
			"1,0": [5, 0],
			"1,1": [4, 2]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 1],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 2,
				type: "bridge",
				n: 2
			},
			{
				cell: [0, 0],
				port: 1,
				type: "bridge",
				n: 2
			},
			{
				cell: [0, 1],
				port: 7,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 1],
				port: 0,
				type: "tiles",
				n: 2
			},
			{
				cell: [1, 1],
				port: 1,
				type: "tiles",
				n: 2
			}
		],
		solution: {
			"0,0": [6, 3],
			"0,1": [4, 1],
			"1,1": [5, 0],
			"2,1": [3, 3]
		}
	},
	{
		cells: [
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 1],
				port: 0,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [1, 0],
				port: 6,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 1],
				port: 5,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 3,
				type: "pair",
				color: "purple"
			},
			{
				cell: [2, 1],
				port: 1,
				type: "pair",
				color: "purple"
			},
			{
				cell: [2, 1],
				port: 4,
				type: "pair",
				color: "yellow"
			}
		],
		solution: {
			"0,1": [7, 0],
			"1,0": [5, 2],
			"1,1": [3, 1],
			"2,1": [6, 1]
		}
	},
	{
		cells: [
			[0, 1],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 1],
				port: 0,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [0, 1],
				port: 5,
				type: "tiles",
				n: 2
			},
			{
				cell: [1, 1],
				port: 0,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 1],
				port: 4,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [2, 0],
				port: 2,
				type: "tiles",
				n: 3
			},
			{
				cell: [2, 0],
				port: 3,
				type: "pair",
				color: "purple"
			},
			{
				cell: [2, 1],
				port: 3,
				type: "pair",
				color: "red"
			},
			{
				cell: [2, 1],
				port: 4,
				type: "pair",
				color: "purple"
			}
		],
		solution: {
			"0,1": [6, 3],
			"1,1": [7, 2],
			"2,0": [1, 2],
			"2,1": [4, 2]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 1,
				type: "bridge",
				n: 2
			},
			{
				cell: [0, 0],
				port: 6,
				type: "bridge",
				n: 2
			},
			{
				cell: [0, 1],
				port: 4,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 1],
				port: 6,
				type: "bridge",
				n: 2
			},
			{
				cell: [1, 0],
				port: 2,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 1,
				type: "bridge",
				n: 2
			}
		],
		solution: {
			"0,0": [4, 2],
			"0,1": [3, 3],
			"1,0": [6, 3],
			"1,1": [1, 0]
		}
	},
	{
		cells: [
			[0, 0],
			[1, 0],
			[1, 1],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 0],
				port: 5,
				type: "yinyang"
			},
			{
				cell: [1, 0],
				port: 2,
				type: "tiles",
				n: 2
			},
			{
				cell: [1, 0],
				port: 1,
				type: "tiles",
				n: 2
			},
			{
				cell: [1, 1],
				port: 7,
				type: "tiles",
				n: 2
			},
			{
				cell: [1, 1],
				port: 6,
				type: "yinyang"
			},
			{
				cell: [2, 1],
				port: 4,
				type: "bridge",
				n: 1
			}
		],
		solution: {
			"0,0": [3, 2],
			"1,0": [7, 2],
			"1,1": [2, 2],
			"2,1": [6, 3]
		}
	},
	{
		cells: [
			[0, 0],
			[1, 0],
			[1, 1],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 1,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 0],
				port: 0,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 0],
				port: 1,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 1],
				port: 5,
				type: "pagoda"
			},
			{
				cell: [1, 1],
				port: 4,
				type: "tiles",
				n: 4
			},
			{
				cell: [2, 1],
				port: 5,
				type: "tiles",
				n: 3
			}
		],
		solution: {
			"0,0": [5, 3],
			"1,0": [3, 0],
			"1,1": [6, 3],
			"2,1": [1, 3]
		}
	},
	{
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 0],
				port: 5,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 4,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 0],
				port: 1,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 0],
				port: 5,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 0],
				port: 4,
				type: "pair",
				color: "red"
			},
			{
				cell: [2, 0],
				port: 3,
				type: "pair",
				color: "purple"
			},
			{
				cell: [2, 1],
				port: 5,
				type: "bridge",
				n: 1
			},
			{
				cell: [2, 1],
				port: 7,
				type: "pair",
				color: "purple"
			}
		],
		solution: {
			"0,0": [6, 3],
			"1,0": [4, 3],
			"2,0": [2, 0],
			"2,1": [3, 0]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 1,
				type: "bridge",
				n: 2
			},
			{
				cell: [0, 1],
				port: 5,
				type: "bridge",
				n: 2
			},
			{
				cell: [0, 1],
				port: 4,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 2,
				type: "bridge",
				n: 2
			},
			{
				cell: [1, 0],
				port: 1,
				type: "pair",
				color: "purple"
			},
			{
				cell: [1, 1],
				port: 2,
				type: "bridge",
				n: 2
			},
			{
				cell: [1, 1],
				port: 3,
				type: "pair",
				color: "purple"
			}
		],
		solution: {
			"0,0": [6, 3],
			"0,1": [5, 1],
			"1,0": [4, 1],
			"1,1": [3, 1]
		}
	},
	{
		cells: [
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0]
		],
		markers: [
			{
				cell: [1, 0],
				port: 7,
				type: "tiles",
				n: 7
			},
			{
				cell: [1, 0],
				port: 6,
				type: "pagoda"
			},
			{
				cell: [0, 1],
				port: 1,
				type: "bridge",
				n: 1
			},
			{
				cell: [2, 0],
				port: 0,
				type: "pair",
				color: "red"
			},
			{
				cell: [2, 0],
				port: 3,
				type: "pair",
				color: "red"
			}
		],
		solution: {
			"0,1": [5, 3],
			"1,0": [3, 3],
			"1,1": [1, 0],
			"2,0": [6, 3]
		}
	},
	{
		cells: [
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 1],
				port: 4,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 1],
				port: 7,
				type: "bridge",
				n: 2
			},
			{
				cell: [1, 0],
				port: 2,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 0],
				port: 3,
				type: "bridge",
				n: 1
			},
			{
				cell: [2, 1],
				port: 5,
				type: "bridge",
				n: 2
			}
		],
		solution: {
			"0,1": [5, 2],
			"1,0": [4, 2],
			"1,1": [6, 2],
			"2,1": [3, 3]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 1,
				type: "pagoda"
			},
			{
				cell: [0, 0],
				port: 6,
				type: "tiles",
				n: 5
			},
			{
				cell: [1, 0],
				port: 1,
				type: "tiles",
				n: 3
			},
			{
				cell: [1, 1],
				port: 4,
				type: "tiles",
				n: 3
			}
		],
		solution: {
			"0,0": [5, 3],
			"0,1": [1, 1],
			"1,0": [6, 2],
			"1,1": [3, 2]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "yinyang"
			},
			{
				cell: [0, 0],
				port: 7,
				type: "tiles",
				n: 7
			},
			{
				cell: [0, 1],
				port: 4,
				type: "pagoda"
			},
			{
				cell: [1, 1],
				port: 2,
				type: "bridge",
				n: 2
			}
		],
		solution: {
			"0,0": [6, 2],
			"0,1": [1, 3],
			"1,0": [2, 0],
			"1,1": [3, 1]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 0],
				port: 7,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 1],
				port: 5,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 1],
				port: 7,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 0],
				port: 2,
				type: "tiles",
				n: 3
			},
			{
				cell: [1, 0],
				port: 3,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 0],
				port: 1,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 1],
				port: 2,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 1],
				port: 5,
				type: "bridge",
				n: 1
			}
		],
		solution: {
			"0,0": [6, 2],
			"0,1": [3, 0],
			"1,0": [4, 2],
			"1,1": [5, 2]
		}
	},
	{
		cells: [
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 1],
				port: 1,
				type: "pair",
				color: "purple"
			},
			{
				cell: [0, 1],
				port: 7,
				type: "bridge",
				n: 2
			},
			{
				cell: [1, 0],
				port: 1,
				type: "pagoda"
			},
			{
				cell: [1, 1],
				port: 5,
				type: "pair",
				color: "purple"
			},
			{
				cell: [1, 1],
				port: 4,
				type: "pair",
				color: "yellow"
			},
			{
				cell: [2, 0],
				port: 0,
				type: "yinyang"
			},
			{
				cell: [2, 1],
				port: 3,
				type: "bridge",
				n: 2
			},
			{
				cell: [2, 1],
				port: 4,
				type: "pair",
				color: "yellow"
			}
		],
		solution: {
			"0,1": [3, 1],
			"1,0": [1, 0],
			"1,1": [5, 2],
			"2,0": [2, 2],
			"2,1": [7, 2]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 6,
				type: "pagoda"
			},
			{
				cell: [1, 1],
				port: 5,
				type: "yinyang"
			},
			{
				cell: [1, 1],
				port: 4,
				type: "bridge",
				n: 1
			},
			{
				cell: [2, 0],
				port: 3,
				type: "pagoda"
			},
			{
				cell: [2, 1],
				port: 5,
				type: "bridge",
				n: 2
			}
		],
		solution: {
			"0,0": [2, 1],
			"0,1": [1, 1],
			"1,1": [3, 3],
			"2,0": [5, 1],
			"2,1": [4, 0]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "tiles",
				n: 4
			},
			{
				cell: [0, 1],
				port: 7,
				type: "pagoda"
			},
			{
				cell: [1, 0],
				port: 1,
				type: "pagoda"
			},
			{
				cell: [1, 1],
				port: 4,
				type: "tiles",
				n: 1
			},
			{
				cell: [2, 1],
				port: 0,
				type: "tiles",
				n: 3
			},
			{
				cell: [2, 1],
				port: 5,
				type: "tiles",
				n: 2
			}
		],
		solution: {
			"0,0": [4, 0],
			"0,1": [7, 2],
			"1,0": [1, 0],
			"1,1": [2, 3],
			"2,1": [5, 3]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "pair",
				color: "purple"
			},
			{
				cell: [0, 0],
				port: 3,
				type: "pair",
				color: "purple"
			},
			{
				cell: [0, 1],
				port: 4,
				type: "yinyang"
			},
			{
				cell: [1, 1],
				port: 0,
				type: "pair",
				color: "red"
			},
			{
				cell: [2, 0],
				port: 6,
				type: "tiles",
				n: 6
			},
			{
				cell: [2, 0],
				port: 3,
				type: "pair",
				color: "red"
			}
		],
		solution: {
			"0,0": [6, 2],
			"0,1": [2, 3],
			"1,1": [4, 1],
			"2,0": [5, 2],
			"2,1": [1, 0]
		}
	},
	{
		cells: [
			[0, 0],
			[1, 0],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 1,
				type: "yinyang"
			},
			{
				cell: [0, 0],
				port: 5,
				type: "yinyang"
			},
			{
				cell: [1, 1],
				port: 7,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 1],
				port: 4,
				type: "pagoda"
			},
			{
				cell: [2, 0],
				port: 1,
				type: "pagoda"
			},
			{
				cell: [2, 0],
				port: 3,
				type: "pair",
				color: "red"
			}
		],
		solution: {
			"0,0": [7, 3],
			"1,0": [2, 0],
			"1,1": [5, 2],
			"2,0": [3, 2],
			"2,1": [1, 0]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 1],
				port: 5,
				type: "bridge",
				n: 1
			},
			{
				cell: [0, 1],
				port: 4,
				type: "yinyang"
			},
			{
				cell: [1, 0],
				port: 0,
				type: "pagoda"
			},
			{
				cell: [1, 0],
				port: 1,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 1],
				port: 5,
				type: "bridge",
				n: 3
			},
			{
				cell: [2, 1],
				port: 1,
				type: "tiles",
				n: 2
			}
		],
		solution: {
			"0,0": [1, 2],
			"0,1": [2, 3],
			"1,0": [5, 3],
			"1,1": [4, 0],
			"2,1": [6, 2]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 7,
				type: "pagoda"
			},
			{
				cell: [0, 1],
				port: 5,
				type: "bridge",
				n: 2
			},
			{
				cell: [0, 1],
				port: 6,
				type: "tiles",
				n: 3
			},
			{
				cell: [1, 0],
				port: 1,
				type: "tiles",
				n: 3
			},
			{
				cell: [2, 1],
				port: 3,
				type: "tiles",
				n: 3
			},
			{
				cell: [2, 1],
				port: 6,
				type: "bridge",
				n: 2
			}
		],
		solution: {
			"0,0": [4, 0],
			"0,1": [6, 1],
			"1,0": [3, 1],
			"2,0": [1, 3],
			"2,1": [7, 1]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "tiles",
				n: 4
			},
			{
				cell: [0, 1],
				port: 5,
				type: "tiles",
				n: 4
			},
			{
				cell: [0, 1],
				port: 6,
				type: "pair",
				color: "purple"
			},
			{
				cell: [1, 1],
				port: 2,
				type: "pair",
				color: "purple"
			},
			{
				cell: [1, 1],
				port: 4,
				type: "pair",
				color: "red"
			},
			{
				cell: [2, 0],
				port: 0,
				type: "tiles",
				n: 3
			},
			{
				cell: [2, 0],
				port: 1,
				type: "pair",
				color: "red"
			}
		],
		solution: {
			"0,0": [4, 0],
			"0,1": [7, 0],
			"1,0": [5, 2],
			"1,1": [3, 2],
			"2,0": [1, 0]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 3,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 0],
				port: 7,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 1],
				port: 5,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 1],
				port: 4,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 1],
				port: 7,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 1],
				port: 6,
				type: "tiles",
				n: 2
			},
			{
				cell: [1, 1],
				port: 0,
				type: "pagoda"
			},
			{
				cell: [1, 1],
				port: 1,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 1],
				port: 5,
				type: "tiles",
				n: 2
			},
			{
				cell: [1, 1],
				port: 4,
				type: "tiles",
				n: 2
			},
			{
				cell: [2, 0],
				port: 2,
				type: "tiles",
				n: 2
			},
			{
				cell: [2, 0],
				port: 1,
				type: "tiles",
				n: 2
			},
			{
				cell: [2, 1],
				port: 2,
				type: "tiles",
				n: 2
			},
			{
				cell: [2, 1],
				port: 3,
				type: "tiles",
				n: 2
			},
			{
				cell: [2, 1],
				port: 5,
				type: "tiles",
				n: 2
			},
			{
				cell: [2, 1],
				port: 4,
				type: "tiles",
				n: 2
			}
		],
		solution: {
			"0,0": [2, 0],
			"0,1": [4, 2],
			"1,1": [7, 0],
			"2,0": [6, 3],
			"2,1": [1, 3]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 7,
				type: "tiles",
				n: 5
			},
			{
				cell: [0, 0],
				port: 6,
				type: "tiles",
				n: 5
			},
			{
				cell: [0, 1],
				port: 7,
				type: "tiles",
				n: 5
			},
			{
				cell: [0, 1],
				port: 6,
				type: "tiles",
				n: 5
			},
			{
				cell: [2, 0],
				port: 3,
				type: "yinyang"
			}
		],
		solution: {
			"0,0": [5, 2],
			"0,1": [6, 2],
			"1,0": [1, 1],
			"1,1": [3, 1],
			"2,0": [7, 0],
			"2,1": [2, 1]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 0],
				port: 1,
				type: "bridge",
				n: 2
			},
			{
				cell: [0, 1],
				port: 7,
				type: "bridge",
				n: 3
			},
			{
				cell: [1, 0],
				port: 0,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 1,
				type: "pair",
				color: "purple"
			},
			{
				cell: [2, 0],
				port: 2,
				type: "tiles",
				n: 12
			},
			{
				cell: [2, 0],
				port: 1,
				type: "pair",
				color: "purple"
			},
			{
				cell: [2, 1],
				port: 5,
				type: "pagoda"
			}
		],
		solution: {
			"0,0": [3, 2],
			"0,1": [4, 1],
			"1,0": [5, 0],
			"1,1": [6, 2],
			"2,0": [7, 2],
			"2,1": [1, 2]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 1,
				type: "yinyang"
			},
			{
				cell: [0, 1],
				port: 4,
				type: "yinyang"
			},
			{
				cell: [1, 0],
				port: 0,
				type: "pagoda"
			},
			{
				cell: [1, 0],
				port: 1,
				type: "bridge",
				n: 2
			},
			{
				cell: [1, 1],
				port: 5,
				type: "pagoda"
			},
			{
				cell: [1, 1],
				port: 4,
				type: "bridge",
				n: 2
			},
			{
				cell: [2, 0],
				port: 0,
				type: "tiles",
				n: 1
			},
			{
				cell: [2, 1],
				port: 5,
				type: "tiles",
				n: 1
			}
		],
		solution: {
			"0,0": [7, 3],
			"0,1": [2, 1],
			"1,0": [3, 2],
			"1,1": [5, 3],
			"2,0": [1, 3],
			"2,1": [6, 0]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 1,
				type: "tiles",
				n: 5
			},
			{
				cell: [0, 1],
				port: 6,
				type: "tiles",
				n: 7
			},
			{
				cell: [1, 0],
				port: 0,
				type: "pagoda"
			},
			{
				cell: [1, 0],
				port: 1,
				type: "tiles",
				n: 7
			},
			{
				cell: [2, 1],
				port: 3,
				type: "pagoda"
			}
		],
		solution: {
			"0,0": [5, 1],
			"0,1": [4, 3],
			"1,0": [3, 2],
			"1,1": [6, 0],
			"2,0": [1, 3],
			"2,1": [7, 3]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "pagoda"
			},
			{
				cell: [0, 0],
				port: 1,
				type: "tiles",
				n: 2
			},
			{
				cell: [1, 0],
				port: 0,
				type: "tiles",
				n: 6
			},
			{
				cell: [1, 0],
				port: 1,
				type: "tiles",
				n: 6
			},
			{
				cell: [2, 0],
				port: 0,
				type: "tiles",
				n: 1
			},
			{
				cell: [2, 0],
				port: 1,
				type: "tiles",
				n: 6
			}
		],
		solution: {
			"0,0": [6, 3],
			"0,1": [3, 2],
			"1,0": [4, 2],
			"1,1": [2, 2],
			"2,0": [7, 2],
			"2,1": [1, 0]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 7,
				type: "yinyang"
			},
			{
				cell: [0, 1],
				port: 7,
				type: "pagoda"
			},
			{
				cell: [1, 0],
				port: 0,
				type: "tiles",
				n: 5
			},
			{
				cell: [1, 1],
				port: 5,
				type: "bridge",
				n: 1
			},
			{
				cell: [1, 1],
				port: 4,
				type: "yinyang"
			},
			{
				cell: [2, 1],
				port: 3,
				type: "tiles",
				n: 7
			}
		],
		solution: {
			"0,0": [6, 2],
			"0,1": [5, 0],
			"1,0": [7, 1],
			"1,1": [2, 1],
			"2,0": [1, 3],
			"2,1": [3, 1]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 7,
				type: "pair",
				color: "red"
			},
			{
				cell: [1, 0],
				port: 0,
				type: "tiles",
				n: 4
			},
			{
				cell: [2, 0],
				port: 2,
				type: "pair",
				color: "blue"
			},
			{
				cell: [2, 0],
				port: 3,
				type: "tiles",
				n: 4
			},
			{
				cell: [2, 1],
				port: 3,
				type: "pair",
				color: "red"
			},
			{
				cell: [0, 1],
				port: 6,
				type: "pair",
				color: "blue"
			}
		],
		solution: {
			"0,0": [3, 1],
			"0,1": [7, 0],
			"1,0": [4, 0],
			"1,1": [5, 2],
			"2,0": [6, 0],
			"2,1": [2, 2]
		}
	},
	{
		cells: [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1],
			[2, 0],
			[2, 1]
		],
		markers: [
			{
				cell: [0, 0],
				port: 0,
				type: "tiles",
				n: 2
			},
			{
				cell: [0, 0],
				port: 6,
				type: "pagoda"
			},
			{
				cell: [1, 0],
				port: 0,
				type: "tiles",
				n: 2
			},
			{
				cell: [1, 0],
				port: 1,
				type: "tiles",
				n: 2
			},
			{
				cell: [2, 0],
				port: 2,
				type: "tiles",
				n: 2
			},
			{
				cell: [2, 0],
				port: 3,
				type: "tiles",
				n: 2
			},
			{
				cell: [2, 1],
				port: 3,
				type: "tiles",
				n: 2
			},
			{
				cell: [2, 1],
				port: 4,
				type: "tiles",
				n: 2
			},
			{
				cell: [1, 1],
				port: 5,
				type: "tiles",
				n: 11
			}
		],
		solution: {
			"0,0": [7, 2],
			"0,1": [1, 1],
			"1,0": [6, 2],
			"1,1": [5, 1],
			"2,0": [3, 3],
			"2,1": [4, 2]
		}
	}
], C = {
	id: "brains",
	tier: "released",
	mechanics: ["tile-placement", "route-building"],
	interactionTags: [],
	nameKey: "games.brains.name",
	descKey: "games.brains.desc",
	rulesKey: "games.brains.rules",
	icon: "⛩️",
	iconImg: "games/brains.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/brains/en.pdf" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#5b8c5a",
	releasedAt: "2026-09-16",
	search: {
		py: "si lu he feng ting yuan",
		init: "slhfty"
	},
	hotseat: "cover"
}, w = e.int().min(0).max(2), T = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("place"),
		x: w,
		y: w,
		tile: e.int().min(1).max(7),
		rot: e.int().min(0).max(3).default(0)
	}),
	e.object({
		type: e.literal("rotate"),
		x: w,
		y: w
	}),
	e.object({
		type: e.literal("move"),
		x: w,
		y: w,
		toX: w,
		toY: w
	}),
	e.object({
		type: e.literal("remove"),
		x: w,
		y: w
	}),
	e.object({ type: e.literal("hint") }),
	e.object({ type: e.literal("clear") }),
	e.object({ type: e.literal("next") }),
	e.object({
		type: e.literal("goto"),
		n: e.int().min(0).max(49)
	})
]), E = e.object({
	puzzle: e.int().min(0).max(49),
	placed: e.record(e.string(), e.object({
		tile: e.int().min(1).max(7),
		rot: e.int().min(0).max(3)
	})),
	hintsUsed: e.int().nonnegative(),
	solved: e.boolean(),
	marks: e.array(e.enum([
		"ok",
		"bad",
		"pending"
	]))
}), D = e.object({}), O = (e) => ({ code: e }), k = (e, t) => `${e},${t}`, A = [
	[[0, -1], 5],
	[[0, -1], 4],
	[[1, 0], 7],
	[[1, 0], 6],
	[[0, 1], 1],
	[[0, 1], 0],
	[[-1, 0], 3],
	[[-1, 0], 2]
], j = {};
for (let [e, t] of Object.entries(b)) {
	let n = Number(e);
	for (let e = 0; e < 4; e++) {
		let r = Array.from({ length: 8 }, () => null);
		for (let [n, i, a] of t.chords) {
			let t = (n + 2 * e) % 8, o = (i + 2 * e) % 8;
			r[t] = {
				to: o,
				bridge: a === 1
			}, r[o] = {
				to: t,
				bridge: a === 1
			};
		}
		for (let n of t.yy) r[(n + 2 * e) % 8] = "yy";
		j[`${n}:${e}`] = r;
	}
}
function M(e, t, n, r) {
	let i = new Set(e.cells.map(([e, t]) => k(e, t))), a = n, o = r, s = 0, c = 0, l = !1, u = /* @__PURE__ */ new Set();
	for (;;) {
		let e = `${a}:${o}`;
		if (u.has(e)) return {
			end: "loop",
			visits: s,
			bridges: c,
			pagoda: l
		};
		u.add(e);
		let n = t[a];
		if (!n) return {
			end: "open",
			visits: s,
			bridges: c,
			pagoda: l
		};
		let r = (o - 2 * n.rot + 8) % 8;
		n.tile === 1 && (r === x[0] || r === x[1]) && (l = !0), s += 1;
		let d = j[`${n.tile}:${n.rot}`][o];
		if (d === "yy") return {
			end: "yy",
			visits: s,
			bridges: c,
			pagoda: l
		};
		if (!d) return {
			end: "open",
			visits: s,
			bridges: c,
			pagoda: l
		};
		d.bridge && (c += 1);
		let [f, p] = a.split(",").map(Number), [[m, h], g] = A[d.to], _ = k(f + m, p + h);
		if (!i.has(_)) return {
			end: "border",
			endCell: a,
			endPort: d.to,
			visits: s,
			bridges: c,
			pagoda: l
		};
		a = _, o = g;
	}
}
function ee(e, t) {
	let n = e.cells.every(([e, n]) => t[k(e, n)]), r = [];
	for (let n of e.markers) {
		let i = k(n.cell[0], n.cell[1]);
		if (!t[i]) {
			r.push("pending");
			continue;
		}
		let a = M(e, t, i, n.port);
		r.push(te(e, n, a));
	}
	return {
		marks: r,
		solved: n && r.every((e) => e === "ok")
	};
}
function te(e, t, n) {
	let r = n.end !== "open";
	switch (t.type) {
		case "pagoda": return n.pagoda ? "ok" : r ? "bad" : "pending";
		case "yinyang": return n.end === "yy" ? "ok" : r ? "bad" : "pending";
		case "bridge": return n.bridges > t.n ? "bad" : r ? n.bridges === t.n ? "ok" : "bad" : "pending";
		case "tiles": return n.visits > t.n ? "bad" : r ? n.visits === t.n ? "ok" : "bad" : "pending";
		case "pair": {
			if (n.end === "loop") return "bad";
			if (n.end !== "border") return r ? "bad" : "pending";
			let i = e.markers.find((e) => e.type === "pair" && e.color === t.color && e !== t);
			return i && n.endCell === k(i.cell[0], i.cell[1]) && n.endPort === i.port ? "ok" : "bad";
		}
	}
}
function N(e, t) {
	return { state: {
		host: t[0],
		puzzle: 0,
		placed: {},
		hintsUsed: 0,
		solved: !1
	} };
}
function P(e, t) {
	e.puzzle = t, e.placed = {}, e.hintsUsed = 0, e.solved = !1;
}
function F(e, t) {
	let { solved: n } = ee(S[e.puzzle], e.placed);
	n && !e.solved && t.push({
		kind: "solve",
		data: {}
	}), e.solved = n;
}
function ne(e, t, n) {
	if (n.by !== e.host) return O("games.brains.errNotPlayer");
	let r = structuredClone(e), i = [], a = S[r.puzzle], o = (e, t) => a.cells.some(([n, r]) => n === e && r === t);
	switch (t.type) {
		case "place": {
			let e = k(t.x, t.y);
			return o(t.x, t.y) ? r.placed[e] ? O("games.brains.errCellTaken") : Object.values(r.placed).some((e) => e.tile === t.tile) ? O("games.brains.errTileUsed") : (r.placed[e] = {
				tile: t.tile,
				rot: t.rot
			}, F(r, i), {
				state: r,
				fx: i
			}) : O("games.brains.errCellInvalid");
		}
		case "rotate": {
			let e = r.placed[k(t.x, t.y)];
			return e ? (e.rot = (e.rot + 1) % 4, F(r, i), {
				state: r,
				fx: i
			}) : O("games.brains.errNoTile");
		}
		case "move": {
			let e = k(t.x, t.y), n = k(t.toX, t.toY);
			return o(t.toX, t.toY) ? r.placed[e] ? r.placed[n] ? O("games.brains.errCellTaken") : (r.placed[n] = r.placed[e], delete r.placed[e], F(r, i), {
				state: r,
				fx: i
			}) : O("games.brains.errNoTile") : O("games.brains.errCellInvalid");
		}
		case "remove": {
			let e = k(t.x, t.y);
			return r.placed[e] ? (delete r.placed[e], F(r, i), {
				state: r,
				fx: i
			}) : O("games.brains.errNoTile");
		}
		case "hint":
			for (let [e, t] of a.cells) {
				let n = k(e, t), [i, o] = a.solution[n], s = r.placed[n];
				if (!(s && s.tile === i && s.rot === o)) {
					for (let [e, t] of Object.entries(r.placed)) t.tile === i && delete r.placed[e];
					r.placed[n] = {
						tile: i,
						rot: o
					}, r.hintsUsed += 1;
					break;
				}
			}
			return F(r, i), {
				state: r,
				fx: i
			};
		case "clear": return r.placed = {}, r.solved = !1, {
			state: r,
			fx: i
		};
		case "next": return r.puzzle < S.length - 1 && P(r, r.puzzle + 1), {
			state: r,
			fx: i
		};
		case "goto": return t.n !== r.puzzle && P(r, t.n), {
			state: r,
			fx: i
		};
	}
}
function re(e) {
	let t = S[e.puzzle], { marks: n, solved: r } = ee(t, e.placed);
	return {
		public: {
			puzzle: e.puzzle,
			placed: structuredClone(e.placed),
			hintsUsed: e.hintsUsed,
			solved: r,
			marks: n
		},
		private: {}
	};
}
function ie() {
	return { phase: "play" };
}
var ae = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: C,
	schemas: {
		action: T,
		publicView: E,
		privateView: D
	},
	setup: N,
	reduce: ne,
	viewFor: re,
	status: ie
}, I = [
	[25, 0],
	[75, 0],
	[100, 25],
	[100, 75],
	[75, 100],
	[25, 100],
	[0, 75],
	[0, 25]
], oe = [
	[0, -1],
	[0, -1],
	[1, 0],
	[1, 0],
	[0, 1],
	[0, 1],
	[-1, 0],
	[-1, 0]
], L = {
	red: {
		bg: "#d84545",
		emoji: "🪷"
	},
	purple: {
		bg: "#8e5fc0",
		emoji: "🟣"
	},
	yellow: {
		bg: "#e0a92e",
		emoji: "🦋"
	},
	blue: {
		bg: "#4a90d9",
		emoji: "⛩️"
	}
};
function R(e, t) {
	let [n, r] = I[e], [i, a] = I[t], o = n * .6 + 20, s = r * .6 + 20, c = i * .6 + 20, l = a * .6 + 20, u = `M ${n} ${r} C ${o} ${s}, ${c} ${l}, ${i} ${a}`, d = .125 * n + .375 * o + .375 * c + .125 * i, f = .125 * r + .375 * s + .375 * l + .125 * a, p = .75 * (o - n) + 1.5 * (c - o) + .75 * (i - c), m = .75 * (s - r) + 1.5 * (l - s) + .75 * (a - l);
	return {
		d: u,
		mx: d,
		my: f,
		deg: Math.atan2(m, p) * 180 / Math.PI
	};
}
function se({ a: e, b: t }) {
	let { d: n } = R(e, t);
	return /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", {
		d: n,
		fill: "none",
		stroke: "#a5916d",
		strokeWidth: 9,
		strokeLinecap: "round"
	}), /* @__PURE__ */ d("path", {
		d: n,
		fill: "none",
		stroke: "#eadfc2",
		strokeWidth: 6,
		strokeLinecap: "round"
	})] });
}
function ce({ a: e, b: t }) {
	let { mx: n, my: r, deg: i } = R(e, t);
	return /* @__PURE__ */ f("g", {
		transform: `translate(${n} ${r}) rotate(${i})`,
		children: [
			/* @__PURE__ */ d("rect", {
				x: -6,
				y: -10,
				width: 12,
				height: 20,
				rx: 2,
				fill: "#8d6e63",
				stroke: "#5d4037",
				strokeWidth: 1.5
			}),
			/* @__PURE__ */ d("line", {
				x1: -6,
				y1: -6,
				x2: 6,
				y2: -6,
				stroke: "#5d4037",
				strokeWidth: 1
			}),
			/* @__PURE__ */ d("line", {
				x1: -6,
				y1: 0,
				x2: 6,
				y2: 0,
				stroke: "#5d4037",
				strokeWidth: 1
			}),
			/* @__PURE__ */ d("line", {
				x1: -6,
				y1: 6,
				x2: 6,
				y2: 6,
				stroke: "#5d4037",
				strokeWidth: 1
			})
		]
	});
}
function le() {
	return /* @__PURE__ */ f("g", {
		transform: "translate(62 28)",
		children: [
			/* @__PURE__ */ d("rect", {
				x: -5.5,
				y: 0,
				width: 11,
				height: 11,
				fill: "#8a5a3b"
			}),
			/* @__PURE__ */ d("path", {
				d: "M -13 0 L 13 0 L 8 -5.5 L -8 -5.5 Z",
				fill: "#b3432b"
			}),
			/* @__PURE__ */ d("path", {
				d: "M -10 -6.5 L 10 -6.5 L 6.5 -11 L -6.5 -11 Z",
				fill: "#b3432b"
			}),
			/* @__PURE__ */ d("path", {
				d: "M -7 -12 L 7 -12 L 4.5 -15.5 L -4.5 -15.5 Z",
				fill: "#b3432b"
			}),
			/* @__PURE__ */ d("rect", {
				x: -1.2,
				y: -19,
				width: 2.4,
				height: 4,
				fill: "#6b3a20"
			})
		]
	});
}
function ue() {
	return /* @__PURE__ */ f("g", {
		transform: "translate(50 50)",
		children: [
			/* @__PURE__ */ d("circle", {
				r: 9,
				fill: "#f5f0e6",
				stroke: "#3a3a3a",
				strokeWidth: 1.5
			}),
			/* @__PURE__ */ d("path", {
				d: "M 0 -9 A 9 9 0 0 1 0 9 A 4.5 4.5 0 0 1 0 0 A 4.5 4.5 0 0 0 0 -9 Z",
				fill: "#3a3a3a"
			}),
			/* @__PURE__ */ d("circle", {
				cy: -4.5,
				r: 1.6,
				fill: "#3a3a3a"
			}),
			/* @__PURE__ */ d("circle", {
				cy: 4.5,
				r: 1.6,
				fill: "#f5f0e6"
			})
		]
	});
}
function z({ tile: e, rot: t = 0, className: n, x: r, y: i, width: a, height: o }) {
	let s = b[e], c = s.chords.filter((e) => e[2] === 0), l = s.chords.filter((e) => e[2] === 1);
	return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 100 100",
		className: n,
		x: r,
		y: i,
		width: a,
		height: o,
		children: /* @__PURE__ */ f("g", {
			transform: `rotate(${t * 90} 50 50)`,
			children: [
				/* @__PURE__ */ d("rect", {
					x: 1,
					y: 1,
					width: 98,
					height: 98,
					rx: 10,
					fill: "#8fae6b",
					stroke: "#5f7d43",
					strokeWidth: 2
				}),
				c.map(([e, t]) => /* @__PURE__ */ d(se, {
					a: e,
					b: t
				}, `${e}-${t}`)),
				l.map(([e, t]) => /* @__PURE__ */ d(se, {
					a: e,
					b: t
				}, `${e}-${t}`)),
				l.map(([e, t]) => /* @__PURE__ */ d(ce, {
					a: e,
					b: t
				}, `br-${e}-${t}`)),
				s.yy.map((e) => /* @__PURE__ */ d("path", {
					d: `M ${I[e][0]} ${I[e][1]} L 50 50`,
					fill: "none",
					stroke: "#a5916d",
					strokeWidth: 9,
					strokeLinecap: "round"
				}, `yy-${e}`)),
				s.yy.map((e) => /* @__PURE__ */ d("path", {
					d: `M ${I[e][0]} ${I[e][1]} L 50 50`,
					fill: "none",
					stroke: "#eadfc2",
					strokeWidth: 6,
					strokeLinecap: "round"
				}, `yyi-${e}`)),
				e === 1 && /* @__PURE__ */ d(le, {}),
				s.yy.length > 0 && /* @__PURE__ */ d(ue, {})
			]
		})
	});
}
var de = {
	ok: "#10b981",
	bad: "#f43f5e",
	pending: "#b8a888"
};
function fe({ mk: e, mark: t, x: n, y: r }) {
	let i = de[t], a;
	if (e.type === "pagoda" || e.type === "yinyang") a = /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
		r: 10.5,
		fill: "#fdfaf2",
		stroke: i,
		strokeWidth: 2.5
	}), /* @__PURE__ */ d("text", {
		y: 4.5,
		textAnchor: "middle",
		fontSize: 12,
		children: e.type === "pagoda" ? "🛕" : "☯️"
	})] });
	else if (e.type === "pair") {
		let t = L[e.color];
		a = /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("rect", {
			x: -10,
			y: -10,
			width: 20,
			height: 20,
			rx: 5,
			fill: t.bg,
			stroke: i,
			strokeWidth: 2.5
		}), /* @__PURE__ */ d("text", {
			y: 4.5,
			textAnchor: "middle",
			fontSize: 11,
			children: t.emoji
		})] });
	} else {
		let t = e.type === "bridge" ? "#8d6e63" : "#4e9a51";
		a = /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("rect", {
			x: -10,
			y: -10,
			width: 20,
			height: 20,
			rx: 4,
			fill: t,
			stroke: i,
			strokeWidth: 2.5
		}), /* @__PURE__ */ d("text", {
			y: 4.5,
			textAnchor: "middle",
			fontSize: 12,
			fontWeight: 800,
			fill: "#fff",
			children: e.n
		})] });
	}
	return /* @__PURE__ */ d("g", {
		transform: `translate(${n} ${r})`,
		children: a
	});
}
function pe({ puzzle: e, placed: t, marks: n, selCell: r, onCell: i }) {
	let a = e.cells.map((e) => e[0]), o = e.cells.map((e) => e[1]), s = Math.min(...a), c = Math.max(...a), l = Math.min(...o), u = Math.max(...o), p = (c - s + 1) * 100, m = (u - l + 1) * 100, h = new Set(e.cells.map(([e, t]) => k(e, t))), g = new Set(e.markers.map((e) => `${k(e.cell[0], e.cell[1])}:${e.port}`)), _ = [];
	for (let [t, n] of e.cells) for (let e = 0; e < 8; e++) {
		if (g.has(`${k(t, n)}:${e}`)) continue;
		let [r, i] = oe[e];
		h.has(k(t + r, n + i)) || _.push([(t - s) * 100 + I[e][0], (n - l) * 100 + I[e][1]]);
	}
	return /* @__PURE__ */ f("svg", {
		viewBox: `-24 -24 ${p + 48} ${m + 48}`,
		className: "h-full w-full",
		children: [
			e.cells.map(([e, n]) => {
				let a = k(e, n), o = (e - s) * 100, c = (n - l) * 100, u = t[a];
				return /* @__PURE__ */ f("g", {
					onClick: () => i(e, n),
					className: "cursor-pointer",
					children: [
						/* @__PURE__ */ d("rect", {
							x: o + 1,
							y: c + 1,
							width: 98,
							height: 98,
							rx: 10,
							fill: u ? "transparent" : "#dcd6c3",
							stroke: "#b8a888",
							strokeWidth: u ? 0 : 2,
							strokeDasharray: u ? void 0 : "6 5"
						}),
						u && /* @__PURE__ */ d(z, {
							tile: u.tile,
							rot: u.rot,
							x: o,
							y: c,
							width: 100,
							height: 100
						}),
						r === a && /* @__PURE__ */ d("rect", {
							x: o + 2,
							y: c + 2,
							width: 96,
							height: 96,
							rx: 9,
							fill: "none",
							stroke: "#0ea5e9",
							strokeWidth: 3.5
						})
					]
				}, a);
			}),
			_.map(([e, t], n) => /* @__PURE__ */ d("circle", {
				cx: e,
				cy: t,
				r: 3.2,
				fill: "#c98f4e",
				stroke: "#8a5a2a",
				strokeWidth: 1
			}, n)),
			e.markers.map((e, t) => {
				let r = (e.cell[0] - s) * 100, i = (e.cell[1] - l) * 100, [a, o] = I[e.port], c = a - 50, u = o - 50, f = Math.hypot(c, u) || 1;
				return /* @__PURE__ */ d(fe, {
					mk: e,
					mark: n[t] ?? "pending",
					x: r + a + c / f * 13,
					y: i + o + u / f * 13
				}, t);
			})
		]
	});
}
//#endregion
//#region src/games/brains/progress.ts
var me = "bgparty:brains", B = null;
function V() {
	if (B) return B;
	try {
		let e = localStorage.getItem(me);
		if (e) {
			let t = JSON.parse(e);
			return B = {
				maxUnlocked: t.maxUnlocked ?? 0,
				bestTimes: t.bestTimes ?? {}
			}, B;
		}
	} catch {}
	return B = {
		maxUnlocked: 0,
		bestTimes: {}
	}, B;
}
function he() {
	try {
		localStorage.setItem(me, JSON.stringify(B));
	} catch {}
}
function ge(e, t, n) {
	let r = V();
	r.maxUnlocked = Math.min(Math.max(r.maxUnlocked, e + 1), n - 1);
	let i = r.bestTimes[e], a = i === void 0 || t < i;
	return a && (r.bestTimes[e] = t), he(), a;
}
function _e(e) {
	return V().bestTimes[e];
}
//#endregion
//#region node_modules/three/examples/jsm/geometries/RoundedBoxGeometry.js
var H = new h();
function U(e, t, n, r, i, a) {
	let o = 2 * Math.PI * i / 4, s = Math.max(a - 2 * i, 0), c = Math.PI / 4;
	H.copy(t), H[r] = 0, H.normalize();
	let l = .5 * o / (o + s), u = 1 - H.angleTo(e) / c;
	return Math.sign(H[n]) === 1 ? u * l : s / (o + s) + l + l * (1 - u);
}
var ve = class e extends m {
	constructor(e = 1, t = 1, n = 1, r = 2, i = .1) {
		let a = r * 2 + 1;
		if (i = Math.min(e / 2, t / 2, n / 2, i), super(1, 1, 1, a, a, a), this.type = "RoundedBoxGeometry", this.parameters = {
			width: e,
			height: t,
			depth: n,
			segments: r,
			radius: i
		}, a === 1) return;
		let o = this.toNonIndexed();
		this.index = null, this.attributes.position = o.attributes.position, this.attributes.normal = o.attributes.normal, this.attributes.uv = o.attributes.uv;
		let s = new h(), c = new h(), l = new h(e, t, n).divideScalar(2).subScalar(i), u = this.attributes.position.array, d = this.attributes.normal.array, f = this.attributes.uv.array, p = u.length / 6, m = new h(), g = .5 / a;
		for (let r = 0, a = 0; r < u.length; r += 3, a += 2) switch (s.fromArray(u, r), c.copy(s), c.x -= Math.sign(c.x) * g, c.y -= Math.sign(c.y) * g, c.z -= Math.sign(c.z) * g, c.normalize(), u[r + 0] = l.x * Math.sign(s.x) + c.x * i, u[r + 1] = l.y * Math.sign(s.y) + c.y * i, u[r + 2] = l.z * Math.sign(s.z) + c.z * i, d[r + 0] = c.x, d[r + 1] = c.y, d[r + 2] = c.z, Math.floor(r / p)) {
			case 0:
				m.set(1, 0, 0), f[a + 0] = U(m, c, "z", "y", i, n), f[a + 1] = 1 - U(m, c, "y", "z", i, t);
				break;
			case 1:
				m.set(-1, 0, 0), f[a + 0] = 1 - U(m, c, "z", "y", i, n), f[a + 1] = 1 - U(m, c, "y", "z", i, t);
				break;
			case 2:
				m.set(0, 1, 0), f[a + 0] = 1 - U(m, c, "x", "z", i, e), f[a + 1] = U(m, c, "z", "x", i, n);
				break;
			case 3:
				m.set(0, -1, 0), f[a + 0] = 1 - U(m, c, "x", "z", i, e), f[a + 1] = 1 - U(m, c, "z", "x", i, n);
				break;
			case 4:
				m.set(0, 0, 1), f[a + 0] = 1 - U(m, c, "x", "y", i, e), f[a + 1] = 1 - U(m, c, "y", "x", i, t);
				break;
			case 5: m.set(0, 0, -1), f[a + 0] = U(m, c, "x", "y", i, e), f[a + 1] = 1 - U(m, c, "y", "x", i, t);
		}
	}
	static fromJSON(t) {
		return new e(t.width, t.height, t.depth, t.segments, t.radius);
	}
}, ye = {
	side: 7166269,
	paper: 16050896,
	paperEdge: 13216887,
	slotLine: 9270871,
	grass: 9219437,
	grassLight: 10732673,
	grassDark: 7574609,
	pathEdge: 7761756,
	path: 14997167,
	water: 6461857,
	bank: 9678722,
	wood: 9723709,
	woodTop: 12421208,
	gold: 15316058
}, W = (e, t = {}) => new p.MeshStandardMaterial({
	color: e,
	roughness: 1,
	...t
}), G = Object.fromEntries(Object.entries(ye).map(([e, t]) => [e, W(t)])), K = [
	[25, 0],
	[75, 0],
	[100, 25],
	[100, 75],
	[75, 100],
	[25, 100],
	[0, 75],
	[0, 25]
];
function be(e) {
	let t = e.cells.map(([e]) => e), n = e.cells.map(([, e]) => e), r = Math.min(...t), i = Math.max(...t), a = Math.min(...n), o = Math.max(...n);
	return {
		minX: r,
		maxX: i,
		minY: a,
		maxY: o,
		width: (i - r + 1) * 2,
		depth: (o - a + 1) * 2
	};
}
function q(e, t) {
	return [(e[0] - (t.minX + t.maxX) / 2) * 2, (e[1] - (t.minY + t.maxY) / 2) * 2];
}
function xe(e, t) {
	let [n, r] = q(e.cell, t), [i, a] = K[e.port];
	return new p.Vector3(n + i / 50 - 1, .24, r + a / 50 - 1);
}
function Se(e, t) {
	let n = xe(e, t), [r, i] = K[e.port], a = r / 50 - 1, o = i / 50 - 1, s = Math.hypot(a, o) || 1;
	return n.add(new p.Vector3(a / s * .32, .1, o / s * .32));
}
function J(e, t, n, r, i = 0, a = 0, o = 0) {
	let s = new p.Mesh(new p.BoxGeometry(e, t, n), r);
	return s.position.set(i, a, o), s;
}
function Y(e, t, n, r, i, a = 0, o = 0, s = 0) {
	let c = new p.Mesh(new ve(e, t, n, 2, r), i);
	return c.position.set(a, o, s), c;
}
var X = ([e, t], n = 0) => new p.Vector3(e / 50 - 1, n, t / 50 - 1);
function Ce(e) {
	let [t, n] = K[e];
	return [t + (t === 0 ? 20 : t === 100 ? -20 : 0), n + (n === 0 ? 20 : n === 100 ? -20 : 0)];
}
function we(e, t, n) {
	return new p.CubicBezierCurve3(X(K[e], n), X(Ce(e), n), X(Ce(t), n), X(K[t], n));
}
function Te(e, t) {
	let n = X(K[e], t);
	return new p.CubicBezierCurve3(n, X(Ce(e), t), new p.Vector3(n.x * .25, t, n.z * .25), new p.Vector3(0, t, 0));
}
function Z(e, t, n) {
	let r = [], i = [];
	for (let n = 0; n < e.length; n++) {
		let a = e[Math.max(0, n - 1)], o = e[Math.min(e.length - 1, n + 1)], s = o.x - a.x, c = o.z - a.z;
		(n === 0 || n === e.length - 1) && (Math.abs(Math.abs(e[n].x) - 1) < 1e-6 ? c = 0 : Math.abs(Math.abs(e[n].z) - 1) < 1e-6 && (s = 0));
		let l = Math.hypot(s, c) || 1, u = -c / l * t / 2, d = s / l * t / 2;
		if (r.push(e[n].x + u, e[n].y, e[n].z + d), r.push(e[n].x - u, e[n].y, e[n].z - d), n) {
			let e = (n - 1) * 2;
			i.push(e, e + 2, e + 1, e + 1, e + 2, e + 3);
		}
	}
	let a = new p.BufferGeometry();
	return a.setAttribute("position", new p.Float32BufferAttribute(r, 3)), a.setIndex(i), a.computeVertexNormals(), new p.Mesh(a, n);
}
function Ee(e) {
	let t = e | 0;
	return () => (t = t * 1664525 + 1013904223 | 0, (t >>> 0) / 4294967296);
}
function De(e, t, n, r) {
	let i = new p.Group();
	i.position.set(e, 0, t);
	let a = W(n), o = [
		W(15914712),
		W(15313589),
		W(16312028)
	];
	for (let [e, t, n, r] of [
		[
			0,
			.29,
			0,
			.16
		],
		[
			-.1,
			.3,
			.03,
			.1
		],
		[
			.09,
			.32,
			-.04,
			.11
		]
	]) {
		let o = new p.Mesh(new p.IcosahedronGeometry(r, 0), a);
		o.position.set(e, t, n), i.add(o);
	}
	for (let e = 0; e < r; e++) {
		let t = e * 2.399, n = new p.Mesh(new p.IcosahedronGeometry(.033, 0), o[e % o.length]);
		n.position.set(Math.cos(t) * .105, .38 + e % 2 * .035, Math.sin(t) * .1), i.add(n);
	}
	return i;
}
function Oe(e, t, n) {
	let r = new p.Group();
	r.position.set(e, 0, t), r.scale.setScalar(.52);
	let i = W(7426102), a = W(n ? 14393770 : 4287309), o = W(n ? 15780038 : 6526555), s = new p.Mesh(new p.CircleGeometry(.25, 10), new p.MeshBasicMaterial({
		color: 2376500,
		transparent: !0,
		opacity: .2
	}));
	s.rotation.x = -Math.PI / 2, s.position.y = .225, r.add(s);
	let c = new p.Mesh(new p.CylinderGeometry(.036, .066, .48, 5), i);
	c.position.y = .47, c.rotation.z = .12, r.add(c);
	for (let [e, t, n, i, s] of [
		[
			-.13,
			.74,
			.01,
			.2,
			0
		],
		[
			.1,
			.81,
			-.05,
			.22,
			1
		],
		[
			0,
			.93,
			.04,
			.18,
			0
		]
	]) {
		let c = new p.Mesh(new p.IcosahedronGeometry(i, 1), s ? o : a);
		c.position.set(e, t, n), c.scale.y = .7, r.add(c);
	}
	return r;
}
function ke(e, t) {
	let n = new p.Group();
	n.position.set(e, 0, t);
	let r = W(13945255), i = W(6910564);
	n.add(J(.24, .05, .24, i, 0, .245)), n.add(J(.1, .22, .1, r, 0, .37)), n.add(J(.18, .17, .18, i, 0, .57)), n.add(J(.115, .1, .115, W(15914128), 0, .58));
	let a = new p.Mesh(new p.CylinderGeometry(.11, .19, .095, 4), r);
	return a.rotation.y = Math.PI / 4, a.position.y = .72, n.add(a), n;
}
function Ae(e, t) {
	let n = Ee(t * 8191), r = [...b[t].chords.flatMap(([e, t]) => we(e, t, 0).getPoints(20)), ...b[t].yy.flatMap((e) => Te(e, 0).getPoints(20))], i = (e, n, i) => r.every((t) => Math.hypot(e - t.x, n - t.z) > i) && (t !== 1 || Math.hypot(e - .25, n + .1) > i + .1) && (t !== 2 || Math.hypot(e, n) > i + .08), a = [
		G.grassDark,
		G.grassLight,
		W(10794867)
	], o = [];
	for (let e = 0; e < 120 && o.length < 15; e++) {
		let e = (n() - .5) * 1.68, t = (n() - .5) * 1.68;
		i(e, t, .24) && !o.some(([n, r]) => Math.hypot(e - n, t - r) < .22) && o.push([e, t]);
	}
	let s = 0;
	for (let r = 0; r < o.length; r++) {
		let [c, l] = o[r];
		if (r === 0 && t === 1) e.add(ke(c, l));
		else if (s < 2 && t !== 1 && i(c, l, .32)) e.add(Oe(c, l, t === 6)), s++;
		else if (r < 6) e.add(De(c, l, [
			4684624,
			6523732,
			7575383
		][r % 3], r % 2 ? 5 : 2));
		else {
			let t = new p.Mesh(new p.IcosahedronGeometry(.09 + n() * .05, 0), a[r % a.length]);
			t.position.set(c, .24, l), t.scale.y = .27, e.add(t);
		}
	}
}
function je(e, t) {
	let n = t.getPoint(.5), r = t.getTangent(.5), i = new p.Group();
	i.position.set(n.x, 0, n.z), i.rotation.y = Math.atan2(r.x, r.z);
	let a = new p.Mesh(new p.CircleGeometry(.34, 20), G.bank);
	a.rotation.x = -Math.PI / 2, a.scale.set(1.45, .9, 1), a.position.y = .226;
	let o = new p.Mesh(new p.CircleGeometry(.28, 20), G.water);
	o.rotation.x = -Math.PI / 2, o.scale.set(1.35, .75, 1), o.position.y = .23, i.add(a, o);
	let s = W(12894885);
	for (let e = 0; e < 11; e++) {
		let t = e / 11 * Math.PI * 2, n = new p.Mesh(new p.IcosahedronGeometry(e % 3 ? .047 : .068, 0), s);
		n.position.set(Math.cos(t) * .43, .255, Math.sin(t) * .27), n.scale.y = .45, i.add(n);
	}
	let c = new p.Group();
	c.position.y = .36, c.add(J(.46, .05, .62, G.wood, 0, -.055));
	for (let e = -2; e <= 2; e++) c.add(Y(.43, .04, .102, .014, G.woodTop, 0, .025 + .035 * (1 - Math.abs(e) / 2), e * .115));
	for (let e of [-1, 1]) {
		c.add(J(.035, .045, .67, G.wood, e * .245, .035));
		for (let t of [-.27, .27]) c.add(J(.04, .22, .04, G.wood, e * .245, .16, t));
		c.add(Y(.05, .035, .66, .014, G.woodTop, e * .245, .27));
	}
	i.add(c), e.add(i);
}
function Me(e) {
	let t = new p.Group();
	t.position.set(.25, .23, -.1), t.scale.set(.45, .62, .45);
	let n = W(12007214), r = W(8663085), i = W(16116175), a = W(2704473, {
		side: p.DoubleSide,
		flatShading: !0
	}), o = W(5270393), s = W(14133848);
	t.add(Y(.57, .1, .57, .025, G.paperEdge, 0, .055)), t.add(Y(.48, .04, .48, .015, r, 0, .125));
	for (let e of [
		{
			half: .41,
			eave: .51,
			floor: .15,
			wall: .34
		},
		{
			half: .34,
			eave: .82,
			floor: .57,
			wall: .26
		},
		{
			half: .275,
			eave: 1.095,
			floor: .88,
			wall: .21
		}
	]) {
		let s = e.eave - e.floor - .06, c = e.floor + s / 2;
		t.add(J(e.wall, s, e.wall, i, 0, c)), t.add(J(e.wall + .05, .035, e.wall + .05, r, 0, e.floor + .01));
		for (let r of [-1, 1]) t.add(J(.035, s + .025, .035, n, r * e.wall * .6, c, r * e.wall * .6)), t.add(J(.035, s + .025, .035, n, r * e.wall * .6, c, -r * e.wall * .6)), t.add(J(e.wall + .055, .037, .03, n, 0, e.eave - .09, r * e.wall * .6)), t.add(J(.03, .037, e.wall + .055, n, r * e.wall * .6, e.eave - .09));
		let l = [
			[
				-e.half,
				.04,
				-e.half
			],
			[
				0,
				0,
				-e.half
			],
			[
				e.half,
				.04,
				-e.half
			],
			[
				e.half,
				0,
				0
			],
			[
				e.half,
				.04,
				e.half
			],
			[
				0,
				0,
				e.half
			],
			[
				-e.half,
				.04,
				e.half
			],
			[
				-e.half,
				0,
				0
			]
		], u = [];
		for (let t = 0; t < l.length; t++) {
			let n = l[t], r = l[(t + 1) % l.length];
			u.push(0, e.eave + .16, 0, n[0], e.eave + n[1], n[2], r[0], e.eave + r[1], r[2]);
		}
		let d = new p.BufferGeometry();
		d.setAttribute("position", new p.Float32BufferAttribute(u, 3)), d.computeVertexNormals(), t.add(new p.Mesh(d, a));
		for (let n of [-1, 1]) t.add(J(e.half * 2.07, .025, .037, o, 0, e.eave, n * e.half)), t.add(J(.037, .025, e.half * 2.07, o, n * e.half, e.eave)), t.add(J(e.half * 1.73, .035, .045, r, 0, e.eave - .052, n * e.half * .76)), t.add(J(.045, .035, e.half * 1.73, r, n * e.half * .76, e.eave - .052));
	}
	t.add(J(.035, .27, .035, s, 0, 1.32));
	for (let e of [
		1.23,
		1.31,
		1.39
	]) {
		let n = new p.Mesh(new p.CylinderGeometry(.055, .046, .024, 10), s);
		n.position.y = e, t.add(n);
	}
	let c = new p.Mesh(new p.SphereGeometry(.045, 10, 6), s);
	c.position.y = 1.47, t.add(c), e.add(t);
}
function Ne() {
	let e = document.createElement("canvas");
	e.width = e.height = 128;
	let t = e.getContext("2d");
	return t.fillStyle = "#f7efd8", t.fillRect(0, 0, 128, 128), t.translate(64, 64), t.fillStyle = "#263d37", t.beginPath(), t.arc(0, 0, 54, -Math.PI / 2, Math.PI / 2), t.fill(), t.beginPath(), t.arc(0, -27, 27, 0, Math.PI * 2), t.fill(), t.fillStyle = "#f7efd8", t.beginPath(), t.arc(0, 27, 27, 0, Math.PI * 2), t.fill(), t.beginPath(), t.arc(0, -27, 7, 0, Math.PI * 2), t.fill(), t.fillStyle = "#263d37", t.beginPath(), t.arc(0, 27, 7, 0, Math.PI * 2), t.fill(), new p.CanvasTexture(e);
}
function Pe(e) {
	let t = new p.Mesh(new p.CylinderGeometry(.26, .28, .055, 24), G.pathEdge);
	t.position.set(0, .26, 0);
	let n = Ne();
	n.colorSpace = p.SRGBColorSpace;
	let r = new p.Mesh(new p.CircleGeometry(.225, 32), new p.MeshBasicMaterial({
		map: n,
		side: p.DoubleSide
	}));
	r.rotation.x = -Math.PI / 2, r.position.set(0, .293, 0), e.add(t, r);
}
function Fe(e) {
	let t = new p.Group();
	if (t.add(J(2, .19, 2, G.side, 0, .09)), t.add(J(2, .045, 2, G.grass, 0, .19)), t.add(J(2, .008, 2, G.grassLight, 0, .217)), Ae(t, e), b[e].chords.forEach(([n, r, i], a) => {
		let o = e === 1 && a === 1, s = we(n, r, .24), c = s.getPoints(30).map((e, t) => e.setY(.24 + (o ? .054 * Math.sin(Math.PI * t / 30) ** 2 : 0)));
		t.add(Z(c.map((e) => e.clone().setY(e.y - .008)), .205, G.pathEdge)), t.add(Z(c, .151, G.path));
		let l = [
			G.path,
			W(15787465),
			W(13813672)
		], u = Math.max(10, Math.floor(s.getLength() / .12));
		for (let n = 1; n < u; n++) {
			let r = n / u, i = s.getPoint(r), a = s.getTangent(r), c = o ? .054 * Math.sin(Math.PI * r) ** 2 : 0, d = Y(.143, .028, s.getLength() / u * .82, .014, l[(n + e) % l.length], i.x, i.y + c + .013, i.z);
			d.rotation.y = Math.atan2(a.x, a.z), t.add(d);
		}
		i && je(t, s);
	}), e === 1 && Me(t), b[e].yy.length) {
		for (let n of b[e].yy) {
			let e = Te(n, .24).getPoints(30);
			t.add(Z(e.map((e) => e.clone().setY(.235)), .205, G.pathEdge)), t.add(Z(e, .151, G.path));
		}
		Pe(t);
	}
	return t;
}
var Ie = /* @__PURE__ */ new Map();
function Le(e) {
	let t = Ie.get(e);
	return t || (t = Fe(e), Ie.set(e, t)), t.clone(!0);
}
function Re(e, t) {
	let n = new p.Group(), r = t.width, i = t.depth, a = new Set(e.cells.map(([e, t]) => `${e},${t}`));
	n.add(Y(r + .86, .23, i + .86, .12, G.side, 0, -.21)), n.add(Y(r + .7, .065, i + .7, .07, G.paperEdge, 0, -.07)), n.add(Y(r + .52, .018, i + .52, .035, G.paper, 0, -.025));
	for (let e of [-1, 1]) n.add(Y(r + .72, .075, .095, .028, G.side, 0, -.04, e * (i / 2 + .34))), n.add(Y(.095, .075, i + .72, .028, G.side, e * (r / 2 + .34), -.04));
	for (let r of e.cells) {
		let [e, i] = q(r, t);
		n.add(J(2, .042, 2, G.paperEdge, e, .02, i)), n.add(J(2, .01, 2, G.paper, e, .047, i)), n.add(J(2, .008, .022, G.slotLine, e, .058, i - 1)), n.add(J(.022, .008, 2, G.slotLine, e - 1, .058, i)), a.has(`${r[0] + 1},${r[1]}`) || n.add(J(.022, .008, 2, G.slotLine, e + 1, .058, i)), a.has(`${r[0]},${r[1] + 1}`) || n.add(J(2, .008, .022, G.slotLine, e, .058, i + 1));
	}
	return n;
}
function ze(e, t) {
	let [n, r] = q(e, t), i = new p.Group();
	i.position.set(n, .14, r);
	for (let e of [-.98, .98]) for (let t of [-.98, .98]) i.add(J(.32, .018, .045, G.gold, e + (e < 0 ? .13 : -.13), 0, t)), i.add(J(.045, .018, .32, G.gold, e, 0, t + (t < 0 ? .13 : -.13)));
	return i;
}
//#endregion
//#region src/games/brains/garden3d.tsx
function Be() {
	try {
		let e = document.createElement("canvas");
		return !!(e.getContext("webgl2") ?? e.getContext("webgl"));
	} catch {
		return !1;
	}
}
var Q = (e, t, n) => Math.min(n, Math.max(t, e));
function $(e, t, n, r, i, a) {
	if (!e.length) return;
	e.sort((e, r) => t[e][n] - t[r][n]);
	let o = Math.min(a, (i - r) / Math.max(1, e.length - 1));
	for (let a = 0; a < e.length; a++) {
		let s = t[e[a]];
		s[n] = Q(s[n], r, i), a && (s[n] = Math.max(s[n], t[e[a - 1]][n] + o));
	}
	let s = t[e[e.length - 1]][n] - i;
	if (s > 0) for (let r of e) t[r][n] -= s;
	if (t[e[0]][n] < r) {
		let i = r - t[e[0]][n];
		for (let r of e) t[r][n] += i;
	}
}
function Ve(e, t, n, r, i) {
	let a = (e) => {
		let t = e.project(n);
		return {
			x: (t.x + 1) * r / 2,
			y: (1 - t.y) * i / 2
		};
	}, o = Q(Math.min(r, i) * .06, 34, 62), s = o + 4, c = o / 2, l = {
		left: c + 7,
		right: r - c - 7,
		top: c + 11,
		bottom: i - Math.max(60, o + 26)
	}, u = e.markers.map((e) => {
		let n = a(xe(e, t)), r = a(Se(e, t));
		return {
			x: Q(r.x, l.left, l.right),
			y: Q(r.y, l.top, l.bottom),
			entranceX: n.x,
			entranceY: n.y
		};
	}), d = {
		north: [],
		east: [],
		south: [],
		west: []
	};
	e.markers.forEach((e, t) => {
		e.port <= 1 ? d.north.push(t) : e.port <= 3 ? d.east.push(t) : e.port <= 5 ? d.south.push(t) : d.west.push(t);
	}), $(d.north, u, "x", l.left, l.right, s), $(d.south, u, "x", l.left, l.right, s), $(d.east, u, "y", l.top, l.bottom, s), $(d.west, u, "y", l.top, l.bottom, s);
	let f = [], p = [];
	for (let e of [
		0,
		-1,
		1,
		-2,
		2
	]) for (let t = -10; t <= 10; t++) p.push([t, e]);
	return p.sort((e, t) => Math.abs(e[0]) + Math.abs(e[1]) * 1.7 - Math.abs(t[0]) - Math.abs(t[1]) * 1.7), u.forEach((t, n) => {
		let r = e.markers[n].port, i = r <= 1 || r >= 4 && r <= 5, a = p.find(([e, n]) => {
			let r = t.x + (i ? e : n) * s, a = t.y + (i ? n : e) * s;
			return r >= l.left && r <= l.right && a >= l.top && a <= l.bottom && f.every((e) => Math.abs(r - e.x) >= o + 2 || Math.abs(a - e.y) >= o + 2);
		});
		a && (t.x += (i ? a[0] : a[1]) * s, t.y += (i ? a[1] : a[0]) * s), f.push(t);
	}), u;
}
function He({ puzzle: e, board: t, onRig: n, onMarks: i, onCells: a }) {
	let o = _((e) => e.camera), s = _((e) => e.gl), c = _((e) => e.size), l = _((e) => e.invalidate), { width: u, height: d } = c;
	return r(() => {
		if (!u || !d) return;
		let r = new p.Vector3(0, .2, 0);
		o.position.copy(r).addScaledVector(new p.Vector3(.7, 11.8, 6.3).normalize(), 16.5), o.lookAt(r), o.updateMatrixWorld();
		let c = u / d, f = [];
		for (let e of [-t.width / 2 - .48, t.width / 2 + .48]) for (let n of [-t.depth / 2 - .48, t.depth / 2 + .48]) f.push(new p.Vector3(e, -.35, n), new p.Vector3(e, .12, n));
		for (let n of e.markers) f.push(Se(n, t), xe(n, t));
		for (let n of e.cells) {
			let [e, r] = q(n, t);
			f.push(new p.Vector3(e, 1.25, r));
		}
		let m = f.reduce((e, t) => {
			let n = t.clone().applyMatrix4(o.matrixWorldInverse), r = -n.z;
			return Math.max(e, Math.abs(n.y) / r, Math.abs(n.x) / (r * c));
		}, 0), h = 2 * Math.atan(m * 1.16);
		return o.setFocalLength(o.getFilmHeight() / (2 * Math.tan(h / 2))), o.updateMatrixWorld(), n({
			camera: o,
			canvas: s.domElement
		}), i(Ve(e, t, o, u, d)), a(e.cells.map((e) => {
			let [n, r] = q(e, t), i = new p.Vector3(n, .28, r).project(o);
			return {
				x: (i.x + 1) * u / 2,
				y: (1 - i.y) * d / 2
			};
		})), l(), () => n(null);
	}, [
		t,
		o,
		s,
		d,
		l,
		a,
		i,
		n,
		e,
		u
	]), null;
}
function Ue(e) {
	e.traverse((e) => {
		e instanceof p.Mesh && e.geometry.dispose();
	});
}
function We({ placed: e, drag: t }) {
	let n = _((e) => e.invalidate);
	return r(() => n(), [
		t,
		n,
		e
	]), null;
}
function Ge({ puzzle: e, board: t }) {
	let n = i(() => Re(e, t), [e, t]);
	return r(() => () => Ue(n), [n]), /* @__PURE__ */ d("primitive", { object: n });
}
function Ke({ cell: e, board: t }) {
	let n = i(() => ze(e, t), [e, t]);
	return r(() => () => Ue(n), [n]), /* @__PURE__ */ d("primitive", { object: n });
}
function qe({ tile: e, rot: t, cell: n, board: o, reducedMotion: s }) {
	let c = i(() => Le(e), [e]), l = a(null), u = _((e) => e.invalidate), f = a({
		start: 0,
		fromY: .5,
		fromRot: -t * Math.PI / 2,
		toRot: -t * Math.PI / 2,
		duration: 270
	}), p = a(t), [m, h] = q(n, o);
	return r(() => {
		let e = -t * Math.PI / 2, n = p.current;
		if (l.current && n !== t) {
			let r = l.current.rotation.y, i = (n + 1) % 4 === t, a = f.current.toRot, o = i ? a - Math.PI / 2 : e + Math.round((a - e) / (Math.PI * 2)) * Math.PI * 2;
			f.current = {
				start: performance.now(),
				fromY: .08,
				fromRot: r,
				toRot: o,
				duration: 210
			}, p.current = t, u();
		}
	}, [u, t]), g(() => {
		let e = l.current;
		if (!e) return;
		if (s) {
			e.position.y = .08, e.rotation.y = -t * Math.PI / 2;
			return;
		}
		let n = f.current, r = Math.min(1, (performance.now() - n.start) / n.duration), i = 1 - (1 - Math.max(0, r)) ** 3;
		e.position.y = n.fromY + (.08 - n.fromY) * i, e.rotation.y = n.fromRot + (n.toRot - n.fromRot) * i, r < 1 && u();
	}), r(() => {
		f.current.start = performance.now(), s && l.current && (l.current.position.y = .08), u();
	}, [u, s]), /* @__PURE__ */ d("group", {
		ref: l,
		position: [
			m,
			s ? .08 : .5,
			h
		],
		children: /* @__PURE__ */ d("primitive", { object: c })
	});
}
function Je({ puzzle: e, board: t, placed: n, drag: r, reducedMotion: a }) {
	let o = r?.hover ? e.cells.find((e) => k(...e) === r.hover) : void 0, s = i(() => r && o ? Le(r.tile) : null, [r, o]), c = o ? q(o, t) : null, l = r ? -r.rot * Math.PI / 2 : 0;
	return /* @__PURE__ */ f(u, { children: [
		/* @__PURE__ */ d("ambientLight", { intensity: 1.65 }),
		/* @__PURE__ */ d("directionalLight", {
			position: [
				-3,
				8,
				5
			],
			intensity: 2.1,
			color: "#fff3d7"
		}),
		/* @__PURE__ */ d(Ge, {
			puzzle: e,
			board: t
		}),
		e.cells.map((e) => {
			let i = k(...e), o = n[i], s = r?.hover === i || r?.key === i, [c, l] = q(e, t);
			return /* @__PURE__ */ f("group", { children: [o && r?.key !== i && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ f("mesh", {
				position: [
					c + .055,
					.059,
					l + .07
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ d("circleGeometry", { args: [1.01, 12] }), /* @__PURE__ */ d("meshBasicMaterial", {
					color: "#254333",
					transparent: !0,
					opacity: .23
				})]
			}), /* @__PURE__ */ d(qe, {
				tile: o.tile,
				rot: o.rot,
				cell: e,
				board: t,
				reducedMotion: a
			}, o.tile)] }), s && /* @__PURE__ */ d(Ke, {
				cell: e,
				board: t
			})] }, i);
		}),
		s && c && /* @__PURE__ */ d("group", {
			position: [
				c[0],
				.38,
				c[1]
			],
			rotation: [
				0,
				l,
				0
			],
			children: /* @__PURE__ */ d("primitive", { object: s })
		})
	] });
}
var Ye = (e, t) => `brains-mark brains-mark--${e.type}${e.color ? ` brains-mark--${e.color}` : ""} brains-mark--${t}`, Xe = {
	pending: "M6 10 H14",
	ok: "M5.5 10.4 L8.7 13.4 L14.7 6.7",
	bad: "M6.4 6.4 L13.6 13.6 M13.6 6.4 L6.4 13.6"
};
function Ze({ mark: e }) {
	return /* @__PURE__ */ f("svg", {
		className: "brains-mark-status",
		viewBox: "0 0 20 20",
		"aria-hidden": "true",
		focusable: "false",
		children: [/* @__PURE__ */ d("path", {
			d: "M5 0 H17 Q20 0 20 3 V15 L15 20 H0 V5 Z",
			fill: "currentColor"
		}), /* @__PURE__ */ d("path", {
			d: Xe[e],
			fill: "none",
			stroke: "#fff9e8",
			strokeWidth: "2.9",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})]
	});
}
function Qe(e, t) {
	return e.type === "pagoda" ? t("games.brains.pagodaGlyph") : e.type === "yinyang" ? "☯" : e.type === "pair" ? "◆" : e.n;
}
function $e(e, t) {
	return e.type === "pagoda" ? t("games.brains.markerPagoda") : e.type === "yinyang" ? t("games.brains.markerYinyang") : e.type === "bridge" ? t("games.brains.markerBridges", { n: e.n ?? 0 }) : e.type === "tiles" ? t("games.brains.markerTiles", { n: e.n ?? 0 }) : t("games.brains.markerPair");
}
function et({ puzzle: e, placed: t, marks: r, drag: a, rigRef: c, hint: u, solved: p, onKeyboardCell: m }) {
	let h = s(), { ref: g } = l("brains-board"), _ = y(), b = i(() => be(e), [e]), [x, S] = o([]), [C, w] = o([]), T = n((e) => {
		c.current = e;
	}, [c]), E = n((e) => S(e), []), D = n((e) => w(e), []);
	return /* @__PURE__ */ f("div", {
		ref: g,
		className: "brains-board-area",
		"data-brains-board": !0,
		children: [
			/* @__PURE__ */ f(v, {
				camera: {
					fov: 35,
					near: .1,
					far: 100
				},
				gl: {
					antialias: !0,
					alpha: !0,
					powerPreference: "low-power"
				},
				dpr: [1, 2],
				frameloop: "demand",
				children: [
					/* @__PURE__ */ d(He, {
						puzzle: e,
						board: b,
						onRig: T,
						onMarks: E,
						onCells: D
					}),
					/* @__PURE__ */ d(We, {
						placed: t,
						drag: a
					}),
					/* @__PURE__ */ d(Je, {
						puzzle: e,
						board: b,
						placed: t,
						drag: a,
						reducedMotion: _
					})
				]
			}),
			/* @__PURE__ */ f("div", {
				className: "brains-mark-layer",
				"aria-label": h("games.brains.tasks"),
				children: [/* @__PURE__ */ d("svg", {
					className: "brains-mark-leaders",
					"aria-hidden": "true",
					children: x.map((e, t) => /* @__PURE__ */ d("line", {
						x1: e.entranceX,
						y1: e.entranceY,
						x2: e.x,
						y2: e.y
					}, t))
				}), e.markers.map((e, t) => {
					let n = x[t];
					if (!n) return null;
					let i = r[t] ?? "pending";
					return /* @__PURE__ */ f("div", {
						className: Ye(e, i),
						style: {
							left: n.x,
							top: n.y
						},
						role: "img",
						"aria-label": `${$e(e, h)} · ${h(i === "ok" ? "games.brains.markOk" : i === "bad" ? "games.brains.markBad" : "games.brains.markPending")}`,
						children: [Qe(e, h), /* @__PURE__ */ d(Ze, { mark: i })]
					}, t);
				})]
			}),
			e.cells.map((e, n) => {
				let r = C[n];
				if (!r) return null;
				let i = k(...e), a = t[i];
				return /* @__PURE__ */ d("button", {
					type: "button",
					className: "brains-cell-key",
					"data-empty": !a,
					style: {
						left: r.x,
						top: r.y
					},
					"aria-label": h(a ? "games.brains.occupiedCell" : "games.brains.emptyCell", {
						x: e[0] + 1,
						y: e[1] + 1
					}),
					title: h("games.brains.keyboardCellHelp"),
					onClick: (e) => {
						e.detail === 0 && m(i, "activate");
					},
					onKeyDown: (e) => {
						(e.key === "m" || e.key === "M") && (e.preventDefault(), m(i, "move")), (e.key === "Delete" || e.key === "Backspace") && (e.preventDefault(), m(i, "remove"));
					}
				}, i);
			}),
			/* @__PURE__ */ d("div", {
				className: `brains-board-hint${p ? " brains-board-hint--solved" : ""}`,
				"aria-live": "polite",
				children: u
			})
		]
	});
}
//#endregion
//#region src/games/brains/view-garden.tsx
var tt = [
	"games.brains.tier1",
	"games.brains.tier2",
	"games.brains.tier3",
	"games.brains.tier4",
	"games.brains.tier5"
], nt = new p.Vector2(), rt = new p.Raycaster(), it = new p.Plane(new p.Vector3(0, 1, 0), -.3), at = new p.Vector3();
function ot(e) {
	let t = Math.floor(e / 1e3);
	return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, "0")}`;
}
function st({ pub: e, send: t }) {
	let l = s(), u = S[e.puzzle], p = i(() => be(u), [u]), m = a(null), h = a(null), g = a(null), _ = a(null), v = a(null), y = a(0), [b, x] = o(null), [C, w] = o(() => Array(8).fill(0)), [T, E] = o(!1), [D, O] = o(null), [A, j] = o(null), [M, ee] = o(() => Date.now()), [te, N] = o(() => Date.now()), P = a(!1);
	r(() => {
		if (e.solved) {
			let e = requestAnimationFrame(() => N(Date.now()));
			return () => cancelAnimationFrame(e);
		}
		let t = window.setInterval(() => N(Date.now()), 1e3);
		return () => window.clearInterval(t);
	}, [e.solved]), r(() => {
		e.solved && !P.current && (P.current = !0, ge(e.puzzle, Date.now() - M, S.length));
	}, [
		e.solved,
		e.puzzle,
		M
	]);
	let F = V(), ne = Object.keys(e.placed).length, re = new Set(Object.values(e.placed).map((e) => e.tile)), ie = _e(e.puzzle), ae = ot(te - M), I = n((e, t) => {
		let n = m.current;
		if (!n) return null;
		let r = n.canvas.getBoundingClientRect();
		return e < r.left || e > r.right || t < r.top || t > r.bottom || (nt.set((e - r.left) / r.width * 2 - 1, -(t - r.top) / r.height * 2 + 1), rt.setFromCamera(nt, n.camera), !rt.ray.intersectPlane(it, at)) ? null : u.cells.find((e) => {
			let [t, n] = q(e, p);
			return Math.abs(at.x - t) <= 1.01 && Math.abs(at.z - n) <= 1.01;
		}) ?? null;
	}, [p, u]), oe = (e, t, n) => {
		let r = g.current;
		r && (r.style.display = "block", r.style.left = `${e}px`, r.style.top = `${t - 16}px`, r.classList.toggle("brains-drag-preview--withdraw", n));
	}, L = () => {
		_.current = null, v.current = null, x(null), g.current && (g.current.style.display = "none", g.current.classList.remove("brains-drag-preview--withdraw"));
	}, R = (t) => {
		if (e.solved || _.current || t.pointerType === "mouse" && t.button !== 0 || !(t.target instanceof Element)) return;
		let n = t.target.closest("[data-brains-tile]");
		if (n && !n.disabled) {
			let e = Number(n.dataset.brainsTile);
			_.current = {
				pointerId: t.pointerId,
				source: "tray",
				tile: e,
				rot: C[e],
				x: t.clientX,
				y: t.clientY
			};
		} else if (t.target.closest("[data-brains-board]")) {
			let n = I(t.clientX, t.clientY);
			if (!n) return;
			let r = k(...n), i = e.placed[r];
			if (!i) return;
			_.current = {
				pointerId: t.pointerId,
				source: "board",
				key: r,
				tile: i.tile,
				rot: i.rot,
				x: t.clientX,
				y: t.clientY
			};
		} else return;
		t.currentTarget.setPointerCapture(t.pointerId);
	}, se = (t) => {
		let n = _.current;
		if (!n || n.pointerId !== t.pointerId) return;
		let r = v.current;
		if (!r && Math.hypot(t.clientX - n.x, t.clientY - n.y) >= 8 && (r = {
			source: n.source,
			key: n.key,
			tile: n.tile,
			rot: n.rot,
			hover: null,
			withdraw: !1
		}, v.current = r, x(r)), !r) return;
		t.preventDefault();
		let i = I(t.clientX, t.clientY), a = i ? k(...i) : null, o = r.source === "board" && !i, s = a && !e.placed[a] ? a : null;
		oe(t.clientX, t.clientY, o), (s !== r.hover || o !== r.withdraw) && (r = {
			...r,
			hover: s,
			withdraw: o
		}, v.current = r, x(r));
	}, ce = (n) => {
		let r = _.current;
		if (!r || r.pointerId !== n.pointerId) return;
		let i = v.current;
		if (i) {
			let a = I(n.clientX, n.clientY), o = a ? k(...a) : null;
			if (i.source === "board" && !a && r.key) t({
				type: "remove",
				x: Number(r.key.split(",")[0]),
				y: Number(r.key.split(",")[1])
			}), w((e) => e.map((e, t) => t === r.tile ? r.rot : e));
			else if (a && o && !e.placed[o]) {
				if (i.source === "tray") t({
					type: "place",
					x: a[0],
					y: a[1],
					tile: r.tile,
					rot: r.rot
				});
				else if (r.key) {
					let [e, n] = r.key.split(",").map(Number);
					t({
						type: "move",
						x: e,
						y: n,
						toX: a[0],
						toY: a[1]
					});
				}
			}
			y.current = performance.now() + 100;
		} else if (r.source === "tray") w((e) => e.map((e, t) => t === r.tile ? (e + 1) % 4 : e));
		else if (r.key) {
			let [e, n] = r.key.split(",").map(Number);
			t({
				type: "rotate",
				x: e,
				y: n
			});
		}
		L();
	}, le = (e) => {
		_.current?.pointerId === e.pointerId && L();
	};
	r(() => {
		let e = (e) => {
			e.key === "Escape" && _.current && L();
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, []);
	let ue = () => {
		t({ type: "clear" });
		let e = Date.now();
		P.current = !1, ee(e), N(e), O(null), j(null);
	}, de = (n, r) => {
		if (e.solved) return;
		let [i, a] = n.split(",").map(Number), o = e.placed[n];
		if (r === "remove" && o) {
			t({
				type: "remove",
				x: i,
				y: a
			}), w((e) => e.map((e, t) => t === o.tile ? o.rot : e)), j(null);
			return;
		}
		if (r === "move" && o) {
			j(n), O(null);
			return;
		}
		if (r === "activate") {
			if (A && !o && A !== n) {
				let [e, n] = A.split(",").map(Number);
				t({
					type: "move",
					x: e,
					y: n,
					toX: i,
					toY: a
				}), j(null);
			} else o ? t({
				type: "rotate",
				x: i,
				y: a
			}) : D !== null && (t({
				type: "place",
				x: i,
				y: a,
				tile: D,
				rot: C[D]
			}), O(null));
		}
	}, fe = b?.withdraw ? l("games.brains.gestureWithdraw") : b?.hover ? l(b.source === "tray" ? "games.brains.gestureDrop" : "games.brains.gestureMove") : A ? l("games.brains.keyboardMoveHint") : D === null ? e.solved ? `${l("games.brains.gardenComplete")}${e.hintsUsed ? ` · ${l("games.brains.hintsUsed", { n: e.hintsUsed })}` : ""}` : l("games.brains.gestureDefault") : l("games.brains.keyboardPlaceHint");
	return /* @__PURE__ */ f("div", {
		ref: h,
		className: "brains-game",
		onPointerDown: R,
		onPointerMove: se,
		onPointerUp: ce,
		onPointerCancel: le,
		onClickCapture: (e) => {
			performance.now() < y.current && (e.preventDefault(), e.stopPropagation(), y.current = 0);
		},
		children: [
			/* @__PURE__ */ d(c, {
				adaptive: !0,
				scroll: !1,
				banner: /* @__PURE__ */ f("header", {
					className: "brains-hud",
					children: [
						/* @__PURE__ */ d("div", {
							className: "brains-hud-emblem",
							"aria-hidden": "true",
							children: l("games.brains.gardenSeal")
						}),
						/* @__PURE__ */ f("div", {
							className: "brains-hud-main",
							children: [
								/* @__PURE__ */ d("div", {
									className: "brains-hud-kicker",
									children: l("games.brains.gardenNotes")
								}),
								/* @__PURE__ */ f("div", {
									className: "brains-hud-title",
									children: [/* @__PURE__ */ d("span", {
										title: l("games.brains.name"),
										children: l("games.brains.name")
									}), /* @__PURE__ */ d("b", { children: l("games.brains.puzzleOf", { n: e.puzzle + 1 }) })]
								}),
								/* @__PURE__ */ f("div", {
									className: "brains-hud-meta",
									children: [
										/* @__PURE__ */ d("span", { children: l(tt[Math.floor(e.puzzle / 10)]) }),
										/* @__PURE__ */ d("span", { children: l("games.brains.placedOf", {
											n: ne,
											total: u.cells.length
										}) }),
										/* @__PURE__ */ f("span", {
											className: "brains-clock",
											children: ["◷ ", ae]
										}),
										ie !== void 0 && /* @__PURE__ */ d("span", {
											className: "brains-hud-best",
											children: l("games.brains.best", { t: ot(ie) })
										})
									]
								})
							]
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							className: "brains-level-button",
							onClick: () => E((e) => !e),
							children: l("games.brains.levels")
						})
					]
				}),
				children: /* @__PURE__ */ f("main", {
					className: "brains-layout",
					children: [/* @__PURE__ */ d(et, {
						puzzle: u,
						placed: e.placed,
						marks: e.marks,
						drag: b,
						rigRef: m,
						hint: fe,
						solved: e.solved,
						onKeyboardCell: de
					}), /* @__PURE__ */ f("aside", {
						className: "brains-dock",
						"aria-label": l("games.brains.tray"),
						children: [
							/* @__PURE__ */ f("div", {
								className: "brains-dock-heading",
								children: [
									/* @__PURE__ */ d("span", { children: l("games.brains.tray") }),
									/* @__PURE__ */ d("button", {
										type: "button",
										className: "brains-dock-button",
										disabled: e.solved,
										onClick: () => t({ type: "hint" }),
										children: l("games.brains.hint")
									}),
									/* @__PURE__ */ d("button", {
										type: "button",
										className: "brains-dock-button",
										disabled: e.solved || !ne,
										onClick: () => t({ type: "clear" }),
										children: l("games.brains.clear")
									})
								]
							}),
							/* @__PURE__ */ d("div", {
								className: "brains-tile-tray",
								children: [
									1,
									2,
									3,
									4,
									5,
									6,
									7
								].map((t) => {
									let n = re.has(t);
									return /* @__PURE__ */ f("button", {
										type: "button",
										"data-brains-tile": t,
										disabled: n || e.solved,
										className: `brains-tray-tile${D === t ? " brains-tray-tile--selected" : ""}`,
										"aria-label": l("games.brains.tileLabel", { n: t }),
										title: l("games.brains.trayTileHelp"),
										onClick: (e) => {
											e.detail === 0 && (O(t), j(null), h.current?.querySelector(".brains-cell-key[data-empty=\"true\"]")?.focus());
										},
										onKeyDown: (e) => {
											e.key === " " && (e.preventDefault(), w((e) => e.map((e, n) => n === t ? (e + 1) % 4 : e)));
										},
										children: [/* @__PURE__ */ d(z, {
											tile: t,
											rot: C[t]
										}), n && /* @__PURE__ */ d("span", {
											className: "brains-tray-used",
											children: l("games.brains.used")
										})]
									}, t);
								})
							}),
							/* @__PURE__ */ d("div", {
								className: "brains-dock-footer",
								children: e.solved ? /* @__PURE__ */ f("div", {
									className: "brains-solved-actions",
									children: [/* @__PURE__ */ d("button", {
										type: "button",
										className: "brains-dock-button",
										onClick: ue,
										children: l("games.brains.replay")
									}), /* @__PURE__ */ d("button", {
										type: "button",
										className: "brains-dock-button brains-dock-button--primary",
										disabled: e.puzzle === S.length - 1,
										onClick: () => t({ type: "next" }),
										children: l("games.brains.next")
									})]
								}) : /* @__PURE__ */ d("div", {
									className: "brains-gesture-help",
									children: l("games.brains.gestureHelp")
								})
							})
						]
					})]
				})
			}),
			T && /* @__PURE__ */ f("div", {
				className: "brains-levels",
				role: "dialog",
				"aria-label": l("games.brains.levels"),
				children: [/* @__PURE__ */ f("div", {
					className: "brains-levels-head",
					children: [/* @__PURE__ */ d("span", { children: l("games.brains.levels") }), /* @__PURE__ */ d("button", {
						type: "button",
						className: "brains-dock-button",
						onClick: () => E(!1),
						children: l("games.brains.close")
					})]
				}), /* @__PURE__ */ d("div", {
					className: "brains-levels-grid",
					children: S.map((n, r) => {
						let i = r > F.maxUnlocked;
						return /* @__PURE__ */ d("button", {
							type: "button",
							disabled: i,
							"aria-current": r === e.puzzle,
							"aria-label": l("games.brains.puzzleOf", { n: r + 1 }),
							onClick: () => {
								t({
									type: "goto",
									n: r
								}), E(!1);
							},
							children: i ? "🔒" : r + 1
						}, r);
					})
				})]
			}),
			/* @__PURE__ */ d("div", {
				ref: g,
				className: "brains-drag-preview",
				"aria-hidden": "true",
				children: b && /* @__PURE__ */ d(z, {
					tile: b.tile,
					rot: b.rot
				})
			})
		]
	});
}
//#endregion
//#region src/games/brains/view-player.tsx
function ct(e) {
	let t = e.public, [n] = o(Be), r = /* @__PURE__ */ d(c, {
		adaptive: !0,
		scroll: !1,
		className: "brains-flat-screen",
		children: /* @__PURE__ */ d(pt, {
			pub: t,
			send: e.send
		}, t.puzzle)
	});
	return n ? /* @__PURE__ */ d(lt, {
		fallback: r,
		children: /* @__PURE__ */ d(st, {
			pub: t,
			send: e.send
		}, t.puzzle)
	}) : r;
}
var lt = class extends t {
	state = { failed: !1 };
	static getDerivedStateFromError() {
		return { failed: !0 };
	}
	render() {
		return this.state.failed ? this.props.fallback : this.props.children;
	}
};
function ut(e) {
	let t = Math.floor(e / 1e3);
	return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, "0")}`;
}
var dt = (e) => Math.floor(e / 10) + 1, ft = [
	"games.brains.tier1",
	"games.brains.tier2",
	"games.brains.tier3",
	"games.brains.tier4",
	"games.brains.tier5"
];
function pt({ pub: e, send: t }) {
	let n = s(), { ref: i } = l("brains-board"), c = S[e.puzzle], [u, p] = o(null), [m, h] = o(null), [g, _] = o(!1), [v, y] = o(() => Date.now()), [b, x] = o(() => Date.now()), w = a(!1);
	r(() => {
		if (e.solved) return;
		let t = setInterval(() => x(Date.now()), 1e3);
		return () => clearInterval(t);
	}, [e.solved]), r(() => {
		e.solved && !w.current && (w.current = !0, ge(e.puzzle, Date.now() - v, S.length));
	}, [
		e.solved,
		e.puzzle,
		v
	]);
	let T = b - v, E = V(), D = new Set(Object.values(e.placed).map((e) => e.tile)), O = _e(e.puzzle);
	return /* @__PURE__ */ f("div", {
		className: "brains-flat-game safe-x safe-t flex h-full min-h-0 flex-col gap-1.5 p-2",
		children: [
			/* @__PURE__ */ f("div", {
				className: "brains-flat-hud frame flex flex-none items-center gap-2 px-3 py-1.5 text-xs font-bold",
				children: [
					/* @__PURE__ */ d("span", {
						className: "brains-flat-title font-display text-sm font-extrabold",
						children: n("games.brains.puzzleOf", { n: e.puzzle + 1 })
					}),
					/* @__PURE__ */ d("span", {
						className: "brains-flat-tier opacity-60",
						children: n(ft[dt(e.puzzle) - 1])
					}),
					/* @__PURE__ */ d("span", {
						className: "brains-flat-divider mx-1 opacity-30",
						children: "|"
					}),
					/* @__PURE__ */ f("span", {
						className: "brains-flat-clock font-mono tabular-nums",
						children: ["⏱", ut(T)]
					}),
					O !== void 0 && /* @__PURE__ */ d("span", {
						className: "brains-flat-best opacity-60",
						children: n("games.brains.best", { t: ut(O) })
					}),
					/* @__PURE__ */ d("button", {
						type: "button",
						className: "btn-quiet min-h-11 cursor-pointer px-2 text-xs",
						onClick: () => _((e) => !e),
						children: n("games.brains.levels")
					})
				]
			}),
			g && /* @__PURE__ */ f("div", {
				className: "brains-flat-levels frame p-2",
				role: "dialog",
				"aria-label": n("games.brains.levels"),
				children: [/* @__PURE__ */ f("div", {
					className: "brains-flat-levels-head",
					children: [/* @__PURE__ */ d("span", { children: n("games.brains.levels") }), /* @__PURE__ */ d("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-3",
						onClick: () => _(!1),
						children: n("games.brains.close")
					})]
				}), /* @__PURE__ */ d("div", {
					className: "grid grid-cols-5 gap-1.5",
					children: S.map((r, i) => {
						let a = i > E.maxUnlocked;
						return /* @__PURE__ */ d("button", {
							type: "button",
							disabled: a,
							"aria-label": n("games.brains.puzzleOf", { n: i + 1 }),
							className: "card min-h-11 cursor-pointer font-mono text-sm font-extrabold tabular-nums disabled:cursor-default disabled:opacity-30",
							style: i === e.puzzle ? {
								borderColor: C.accent,
								boxShadow: `3px 3px 0 ${C.accent}`
							} : void 0,
							onClick: () => {
								t({
									type: "goto",
									n: i
								}), _(!1);
							},
							children: a ? "🔒" : i + 1
						}, i);
					})
				})]
			}),
			/* @__PURE__ */ d("div", {
				ref: i,
				className: "brains-flat-board min-h-0 flex-1",
				children: /* @__PURE__ */ d(pe, {
					puzzle: c,
					placed: e.placed,
					marks: e.marks,
					selCell: m,
					onCell: (n, r) => {
						let i = k(n, r);
						e.placed[i] ? m === i ? t({
							type: "rotate",
							x: n,
							y: r
						}) : (h(i), p(null)) : u === null ? h(null) : (t({
							type: "place",
							x: n,
							y: r,
							tile: u,
							rot: 0
						}), p(null));
					}
				})
			}),
			/* @__PURE__ */ d("div", {
				className: "brains-flat-dock",
				children: e.solved ? /* @__PURE__ */ f("div", {
					className: "brains-flat-solved safe-b frame flex flex-none flex-col gap-2 p-3 pb-4",
					children: [/* @__PURE__ */ f("div", {
						className: "brains-flat-result flex items-center gap-2",
						children: [
							/* @__PURE__ */ f("span", {
								className: "font-display text-base font-extrabold",
								children: ["🎉 ", n("games.brains.solvedTitle")]
							}),
							/* @__PURE__ */ d("span", {
								className: "font-mono text-sm font-extrabold tabular-nums",
								children: ut(T)
							}),
							e.hintsUsed > 0 && /* @__PURE__ */ d("span", {
								className: "text-xs opacity-60",
								children: n("games.brains.hintsUsed", { n: e.hintsUsed })
							})
						]
					}), /* @__PURE__ */ f("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ d("button", {
							type: "button",
							className: "btn-quiet min-h-12 flex-1 cursor-pointer",
							onClick: () => {
								t({ type: "clear" });
								let e = Date.now();
								w.current = !1, y(e), x(e), h(null);
							},
							children: n("games.brains.replay")
						}), /* @__PURE__ */ d("button", {
							type: "button",
							className: "btn-base min-h-12 flex-1 cursor-pointer text-white",
							style: { background: C.accent },
							onClick: () => t({ type: "next" }),
							children: n("games.brains.next")
						})]
					})]
				}) : /* @__PURE__ */ f("div", {
					className: "brains-flat-play",
					children: [/* @__PURE__ */ f("div", {
						className: "brains-flat-actions flex flex-none items-center gap-2",
						children: [
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 flex-1 cursor-pointer",
								onClick: () => t({ type: "hint" }),
								children: ["💡 ", n("games.brains.hint")]
							}),
							/* @__PURE__ */ d("button", {
								type: "button",
								className: "btn-quiet min-h-11 flex-1 cursor-pointer",
								onClick: () => t({ type: "clear" }),
								children: n("games.brains.clear")
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 flex-1 cursor-pointer disabled:opacity-30",
								disabled: !m,
								onClick: () => {
									if (!m) return;
									let [e, n] = m.split(",").map(Number);
									t({
										type: "rotate",
										x: e,
										y: n
									});
								},
								children: ["⟳ ", n("games.brains.rotate")]
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 flex-1 cursor-pointer disabled:opacity-30",
								disabled: !m,
								onClick: () => {
									if (!m) return;
									let [e, n] = m.split(",").map(Number);
									t({
										type: "remove",
										x: e,
										y: n
									}), h(null);
								},
								children: ["✕ ", n("games.brains.remove")]
							})
						]
					}), /* @__PURE__ */ d("div", {
						className: "brains-flat-tray safe-b flex flex-none items-center justify-center gap-1.5 pb-1",
						children: [
							1,
							2,
							3,
							4,
							5,
							6,
							7
						].map((e) => {
							let t = D.has(e);
							return /* @__PURE__ */ d("button", {
								type: "button",
								disabled: t,
								"aria-label": `${e}`,
								className: "cursor-pointer rounded-xl disabled:cursor-default disabled:opacity-25",
								style: { outline: u === e ? `3px solid ${C.accent}` : void 0 },
								onClick: () => {
									p(u === e ? null : e), h(null);
								},
								children: /* @__PURE__ */ d(z, {
									tile: e,
									className: "size-11"
								})
							}, e);
						})
					})]
				})
			})
		]
	});
}
//#endregion
//#region src/games/brains/fx.tsx
var mt = [
	0,
	45,
	90,
	135,
	180,
	225,
	270,
	315
], ht = {
	definition: ae,
	View: ct,
	fx: { solve(e, t) {
		let n = t.anchor("brains-board");
		return n ? {
			ms: 1100,
			node: /* @__PURE__ */ f("div", {
				className: "brains-solve-fx",
				style: {
					left: n.x,
					top: n.y,
					width: n.w,
					height: n.h
				},
				children: [/* @__PURE__ */ d("span", { className: "brains-solve-fx__ring" }), mt.map((e) => /* @__PURE__ */ d("span", {
					className: "brains-solve-fx__petal",
					style: { "--brains-petal-angle": `${e}deg` }
				}, e))]
			})
		} : null;
	} },
	locales: {
		zh: {
			name: "思路:和风庭园",
			desc: "单人解谜:旋转摆放庭园板块,让每条小径都完成它的任务",
			rules: "目标:用庭园板块填满谜题纸上的所有格子,让每个任务标记都满足。\n准备:每题给出一个空格阵,格阵边缘标有小径出入口和任务标记;共用 7 块各不相同的庭园板块,每块每题至多用一次,可任意旋转。\n流程:相邻格子的小径会自动对接。\n· 点按托盘板块旋转,拖到空格放置。\n· 已放板块点按旋转,拖到其他空格移动,拖出棋盘撤回。所有格子放满且全部任务标记同时满足即过关。\n任务标记(挂在某个出入口上,约束从该口出发的那条小径):\n· 宝塔:这条小径必须经过宝塔脚边的那一段。\n· 阴阳:这条小径必须通到阴阳标志并在那里终结。\n· 棕色数字:这条小径必须恰好跨过该数目的木桥。\n· 绿色数字:这条小径必须恰好经过该数目的格子(重复穿过同一格要重复计数)。\n· 彩色对子:相同颜色的两个出入口必须由同一条小径连通。\n遇到困难时，可以点击“提示”，自动正确放置一块庭园板块。计时与最佳成绩仅用于自我挑战，并保存在本机。",
			puzzleOf: "第 {{n}} 题",
			tier1: "热身",
			tier2: "入门",
			tier3: "进阶",
			tier4: "困难",
			tier5: "大师",
			best: "最佳 {{t}}",
			levels: "选题",
			solvedTitle: "过关!",
			hintsUsed: "用了 {{n}} 次提示",
			replay: "重玩",
			next: "下一题",
			hint: "提示",
			clear: "清空",
			rotate: "旋转",
			remove: "移除",
			gardenNotes: "庭园手帖 · GARDEN NOTES",
			gardenSeal: "庭",
			pagodaGlyph: "塔",
			placedOf: "已放 {{n}}/{{total}}",
			tray: "庭园板块",
			tileLabel: "板块 {{n}}",
			trayTileHelp: "点按旋转，拖动放置；键盘回车选择，空格旋转",
			used: "已放",
			close: "关闭",
			tasks: "庭园边缘任务",
			markerPagoda: "小径经过宝塔",
			markerYinyang: "小径通向阴阳",
			markerBridges: "经过 {{n}} 座桥",
			markerTiles: "经过 {{n}} 格",
			markerPair: "同色小径配对",
			markOk: "满足",
			markBad: "冲突",
			markPending: "待定",
			emptyCell: "第 {{x}} 列第 {{y}} 行，空格",
			occupiedCell: "第 {{x}} 列第 {{y}} 行，已放板块",
			keyboardCellHelp: "回车放置或旋转，M 移动，Delete 撤回",
			keyboardMoveHint: "已选中板块 · 在空格按回车移动",
			keyboardPlaceHint: "已选中托盘板块 · 在空格按回车放置",
			gestureDefault: "点按板块转向 · 拖动板块拼接庭园",
			gestureDrop: "松手放置 · 小径方向保持不变",
			gestureMove: "松手移动 · 小径方向保持不变",
			gestureWithdraw: "松手撤回 · 板块回到托盘",
			gestureHelp: "点按旋转 · 拖入放置／拖格移动\n拖出棋盘即可撤回",
			gardenComplete: "小径相连 · 庭园完成！",
			errNotPlayer: "你不在这一局里",
			errCellInvalid: "这里不是谜题的格子",
			errCellTaken: "这格已经有板块了",
			errTileUsed: "这块板块已经用过了",
			errNoTile: "这格没有板块"
		},
		en: {
			name: "Brains: Japanese Garden",
			desc: "Solo puzzle: rotate garden tiles so every path fulfills its task",
			rules: "Goal: fill every cell of the puzzle sheet with garden tiles so that all task markers are satisfied.\nSetup: each puzzle shows a grid of empty cells, with path entrances and task markers on its edges; you share a set of 7 distinct garden tiles, each usable at most once per puzzle, freely rotatable.\nPlay: paths connect automatically across adjacent cells.\n· Tap a tray tile to rotate it, then drag it onto an empty cell.\n· Tap a placed tile to rotate it; drag it to another empty cell to move it, or beyond the board to return it. You solve the puzzle when every cell is filled and all markers are satisfied at once.\nTask markers (each hangs on an entrance and constrains the path leaving it):\n· Pagoda: the path must run along the stretch right beside the pagoda.\n· Yin-yang: the path must reach the yin-yang symbol and end there.\n· Brown number: the path must cross exactly that many bridges.\n· Green number: the path must pass through exactly that many cells (re-entering a cell counts again).\n· Colored pair: the two entrances of the same color must be joined by one single path.\nStuck? Use a hint to place one tile correctly; the timer and best times are just a personal challenge, stored on this device.",
			puzzleOf: "Puzzle {{n}}",
			tier1: "Warm-up",
			tier2: "Easy",
			tier3: "Medium",
			tier4: "Hard",
			tier5: "Master",
			best: "Best {{t}}",
			levels: "Levels",
			solvedTitle: "Solved!",
			hintsUsed: "{{n}} hint(s) used",
			replay: "Replay",
			next: "Next",
			hint: "Hint",
			clear: "Clear",
			rotate: "Rotate",
			remove: "Remove",
			gardenNotes: "GARDEN NOTES",
			gardenSeal: "庭",
			pagodaGlyph: "塔",
			placedOf: "Placed {{n}}/{{total}}",
			tray: "Garden Tiles",
			tileLabel: "Tile {{n}}",
			trayTileHelp: "Tap to rotate, drag to place; Enter to select, Space to rotate",
			used: "Used",
			close: "Close",
			tasks: "Garden edge tasks",
			markerPagoda: "Path passes the pagoda",
			markerYinyang: "Path ends at yin-yang",
			markerBridges: "Cross {{n}} bridges",
			markerTiles: "Pass through {{n}} cells",
			markerPair: "Connect the matching entrances",
			markOk: "Satisfied",
			markBad: "Conflict",
			markPending: "Pending",
			emptyCell: "Column {{x}}, row {{y}}, empty",
			occupiedCell: "Column {{x}}, row {{y}}, occupied",
			keyboardCellHelp: "Enter to place or rotate, M to move, Delete to remove",
			keyboardMoveHint: "Tile selected · press Enter on an empty cell to move",
			keyboardPlaceHint: "Tray tile selected · press Enter on an empty cell to place",
			gestureDefault: "Tap to rotate · drag tiles into the garden",
			gestureDrop: "Release to place · orientation stays the same",
			gestureMove: "Release to move · orientation stays the same",
			gestureWithdraw: "Release to return the tile to the tray",
			gestureHelp: "Tap to rotate · drag to place or move\nDrag beyond the board to return a tile",
			gardenComplete: "Paths connected · garden complete!",
			errNotPlayer: "You are not in this game",
			errCellInvalid: "Not a puzzle cell",
			errCellTaken: "That cell already has a tile",
			errTileUsed: "That tile is already in use",
			errNoTile: "No tile on that cell"
		}
	}
};
//#endregion
export { ht as default };
