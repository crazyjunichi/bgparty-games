import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { memo as n, useEffect as r, useId as i, useRef as a, useState as o } from "react";
import { gameAssetUrl as s } from "@bgparty/sdk/assets";
import { AVATARS as c } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { useT as u } from "@bgparty/sdk/i18n";
import { DeltaNumber as d } from "@bgparty/sdk/fx/delta-number";
import { useFxAnchor as f } from "@bgparty/sdk/fx/anchors";
import { IconClose as p } from "@bgparty/sdk/icons";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { SheetFxProbe as v, SheetView as ee } from "@bgparty/sdk/sheet-view";
import { Floater as y, FlySprite as b } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as x } from "@bgparty/sdk/confirm-button";
import { OptionRadio as S, OptionSection as te } from "@bgparty/sdk/ui/game-options";
//#region src/games/natsumemo/data.ts
var C = {
	bbq: "games.natsumemo.events.bbq",
	video: "games.natsumemo.events.video",
	grandparents: "games.natsumemo.events.grandparents",
	family: "games.natsumemo.events.family",
	beach: "games.natsumemo.events.beach",
	zoo: "games.natsumemo.events.zoo",
	pool: "games.natsumemo.events.pool",
	shopping: "games.natsumemo.events.shopping",
	base: "games.natsumemo.events.base",
	abroad: "games.natsumemo.events.abroad",
	bugs: "games.natsumemo.events.bugs",
	camp: "games.natsumemo.events.camp",
	festival: "games.natsumemo.events.festival",
	tabletop: "games.natsumemo.events.tabletop",
	explore: "games.natsumemo.events.explore",
	candy: "games.natsumemo.events.candy",
	fireworks: "games.natsumemo.events.fireworks",
	sleepover: "games.natsumemo.events.sleepover",
	park: "games.natsumemo.events.park",
	study: "games.natsumemo.events.study",
	homework: "games.natsumemo.events.homework"
}, w = {
	caretaker: "games.natsumemo.titles.caretaker",
	lazy: "games.natsumemo.titles.lazy",
	lifeguard: "games.natsumemo.titles.lifeguard",
	vip: "games.natsumemo.titles.vip",
	swimmer: "games.natsumemo.titles.swimmer",
	zoologist: "games.natsumemo.titles.zoologist",
	festival: "games.natsumemo.titles.festival",
	slacker: "games.natsumemo.titles.slacker",
	family: "games.natsumemo.titles.family",
	gamer: "games.natsumemo.titles.gamer",
	firestarter: "games.natsumemo.titles.firestarter",
	entomologist: "games.natsumemo.titles.entomologist",
	fireworks: "games.natsumemo.titles.fireworks",
	scholar: "games.natsumemo.titles.scholar",
	grandchild: "games.natsumemo.titles.grandchild",
	detective: "games.natsumemo.titles.detective",
	survivor: "games.natsumemo.titles.survivor",
	solo: "games.natsumemo.titles.solo",
	peterpan: "games.natsumemo.titles.peterpan",
	regular: "games.natsumemo.titles.regular",
	critic: "games.natsumemo.titles.critic"
}, ne = [
	"#71a244",
	"#e5bd24",
	"#de823a",
	"#bb4345"
], T = [
	"games.natsumemo.monday",
	"games.natsumemo.tuesday",
	"games.natsumemo.wednesday",
	"games.natsumemo.thursday",
	"games.natsumemo.friday",
	"games.natsumemo.saturday",
	"games.natsumemo.sunday"
], E = (e, t, n, r, i, a, o, s, c, l = 0) => ({
	id: e,
	week: t,
	kind: n,
	days: r,
	hearts: i,
	mode: a,
	values: o,
	solo: s,
	title: c,
	pages: l
}), D = [
	E(1, 1, "base", 1, 1, "base", [
		3,
		6,
		10
	], 0, "caretaker"),
	E(2, 1, "video", 1, 1, "video", [
		6,
		8,
		4
	], 2, "gamer"),
	E(3, 1, "pool", 1, 1, "gender", [3, 6], 2, "swimmer"),
	E(4, 1, "shopping", 1, 1, "two", [7, 4], 2, "regular"),
	E(5, 1, "bbq", 1, 1, "parity", [6, 3], 2, "firestarter"),
	E(6, 1, "zoo", 1, 1, "gender", [6, 4], 2, "zoologist"),
	E(7, 1, "beach", 2, 2, "gender", [7, 10], 6, "lifeguard"),
	E(8, 1, "family", 2, 0, "fixed", [8], 8, "family", 2),
	E(9, 1, "grandparents", 3, 0, "fixed", [12], 12, "grandchild", 3),
	E(10, 2, "base", 1, 1, "base", [
		3,
		6,
		10
	], 0, "caretaker"),
	E(11, 2, "tabletop", 1, 1, "tabletop", [
		8,
		4,
		6
	], 2, "solo"),
	E(12, 2, "bugs", 1, 1, "bugs", [
		3,
		5,
		6
	], 0, "entomologist"),
	E(13, 2, "festival", 1, 1, "balanced", [8, 6], 3, "festival"),
	E(14, 2, "bbq", 1, 1, "parity", [7, 3], 2, "firestarter"),
	E(15, 2, "explore", 1, 1, "gender", [7, 5], 2, "detective"),
	E(16, 2, "camp", 2, 2, "parity", [10, 8], 6, "survivor"),
	E(17, 2, "beach", 2, 2, "gender", [7, 12], 6, "lifeguard"),
	E(18, 2, "abroad", 3, 0, "fixed", [18], 18, "family"),
	E(19, 3, "base", 1, 1, "base", [
		3,
		6,
		10
	], 0, "caretaker"),
	E(20, 3, "video", 1, 1, "video", [
		7,
		8,
		4
	], 2, "gamer"),
	E(21, 3, "candy", 1, 1, "candy", [], 2, "critic"),
	E(22, 3, "fireworks", 1, 1, "balanced", [9, 6], 2, "fireworks"),
	E(23, 3, "zoo", 1, 1, "gender", [7, 5], 2, "zoologist"),
	E(24, 3, "camp", 2, 2, "parity", [12, 8], 6, "survivor"),
	E(25, 3, "sleepover", 2, 2, "gender", [12, 10], 6, "peterpan"),
	E(26, 3, "family", 2, 0, "fixed", [8], 8, "family", 2),
	E(27, 3, "grandparents", 3, 0, "fixed", [12], 12, "grandchild", 3),
	E(28, 4, "base", 1, 1, "base", [
		3,
		6,
		10
	], 0, "caretaker"),
	E(29, 4, "tabletop", 1, 1, "tabletop", [
		10,
		4,
		8
	], 2, "solo"),
	E(30, 4, "pool", 1, 1, "gender", [5, 8], 2, "swimmer"),
	E(31, 4, "park", 1, 1, "balanced", [10, 8], 4, "vip"),
	E(32, 4, "explore", 1, 1, "gender", [9, 5], 2, "detective"),
	E(33, 4, "bugs", 1, 1, "bugs", [
		3,
		7,
		10
	], 0, "entomologist"),
	E(34, 4, "shopping", 1, 1, "two", [10, 6], 2, "regular"),
	E(35, 4, "sleepover", 2, 2, "gender", [16, 10], 6, "peterpan"),
	E(36, 4, "abroad", 3, 0, "fixed", [24], 24, "family")
], O = (e) => D[e - 1], k = "$transfer-boy", A = "$transfer-girl", j = [k, A], M = {
	id: "natsumemo",
	tier: "alpha",
	mechanics: [
		"roll-and-write",
		"set-collection",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.natsumemo.name",
	descKey: "games.natsumemo.desc",
	rulesKey: "games.natsumemo.rules",
	icon: "📒",
	iconImg: "games/natsumemo.webp",
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [
		4,
		5,
		6
	],
	playerRange: (e) => ({
		min: e?.transferStudents ? 2 : 3,
		max: e?.transferStudents ? 4 : 6
	}),
	accent: "#367c64",
	releasedAt: "2026-11-10T02:23:19+08:00",
	search: {
		py: "shu jia ri ji",
		init: "sjrj"
	},
	hotseat: "cover"
}, N = t.object({ transferStudents: t.boolean().default(!1) }).default({ transferStudents: !1 }), P = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("character"),
		gender: t.enum(["boy", "girl"])
	}),
	t.object({
		type: t.literal("schedule"),
		start: t.int().min(0).max(6)
	}),
	t.object({ type: t.literal("skip") }),
	t.object({
		type: t.literal("attend"),
		yes: t.boolean(),
		die: t.int().min(1).max(6).optional()
	}),
	t.object({
		type: t.literal("hearts"),
		targets: t.array(t.string()).max(2)
	}),
	t.object({ type: t.literal("homework") }),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), F = t.object({
	card: t.int().min(0).max(36),
	kind: t.string(),
	week: t.int(),
	start: t.int(),
	days: t.int(),
	points: t.int(),
	members: t.array(t.string()),
	die: t.int().nullable()
}), I = t.object({
	rid: t.string(),
	gender: t.enum(["boy", "girl"]).nullable(),
	calendar: t.array(F.nullable()).length(28),
	titles: t.array(t.string()),
	points: t.int(),
	ready: t.boolean()
}), L = t.object({
	activity: t.int(),
	homework: t.int(),
	titles: t.int(),
	friendship: t.int(),
	total: t.int(),
	pages: t.int(),
	hearts: t.record(t.string(), t.int())
}), R = t.object({
	phase: t.enum([
		"characters",
		"schedule",
		"attend",
		"reveal",
		"hearts",
		"settle",
		"study",
		"homework",
		"weekEnd",
		"done"
	]),
	week: t.int().min(1).max(4),
	invitation: t.int().min(0).max(6),
	leader: t.string(),
	proposer: t.string(),
	card: t.int().nullable(),
	start: t.int().nullable(),
	players: t.array(I),
	transferStudents: t.boolean(),
	transferCalendar: t.array(F.nullable()).length(28),
	transferDie: t.int().nullable(),
	participants: t.array(t.string()),
	dice: t.record(t.string(), t.int()),
	gains: t.record(t.string(), t.int()),
	heartReady: t.array(t.string()),
	results: t.record(t.string(), L).nullable()
}), z = t.object({
	pages: t.int().min(0).max(30),
	hearts: t.record(t.string(), t.int()),
	choice: t.object({
		yes: t.boolean(),
		die: t.int().nullable()
	}).nullable(),
	heartCount: t.int().min(0).max(2),
	targets: t.array(t.string()),
	allocated: t.boolean(),
	lastHomework: t.object({
		week: t.int(),
		day: t.int(),
		die: t.int(),
		pages: t.int(),
		points: t.int()
	}).nullable()
}), B = () => ({ code: "games.natsumemo.error" });
function V(e, t, n) {
	return Array.from({ length: 8 - n }, (e, t) => t).filter((r) => Array.from({ length: n }, (n, i) => e[(t - 1) * 7 + r + i]).every((e) => e === null));
}
var H = (t) => e(t.seed, t.cursor++, 6) + 1, re = (e) => e.players[(e.week - 1) % e.players.length].rid, U = (e, t) => {
	e.titles.includes(t) || e.titles.push(t);
}, W = (e, t) => {
	e.pages = Math.min(30, e.pages + t), e.pages === 30 && U(e, "scholar");
}, G = (e, t) => t === "$transfer-boy" ? "boy" : t === "$transfer-girl" ? "girl" : e.players.find((e) => e.rid === t)?.gender;
function K(e, t, n, r, i, a, o, s) {
	if (e.mode === "fixed") return e.values[0];
	if (e.mode === "base") return e.values[Math.min(r, 2)];
	if (e.mode === "bugs") return e.values[e.week === 2 ? a === 1 ? 0 : a <= 4 ? 1 : 2 : a <= 2 ? 0 : a <= 5 ? 1 : 2];
	if (t === 1) return e.solo;
	switch (e.mode) {
		case "parity": return e.values[t % 2 == 0 ? 0 : 1];
		case "gender": return e.values[n === 0 || n === t ? 0 : 1];
		case "balanced": return e.values[n * 2 === t ? 0 : 1];
		case "two": return e.values[t === 2 ? 0 : 1];
		case "candy": return i;
		case "video":
		case "tabletop": return e.values[a === o ? s === 1 ? 0 : 1 : 2];
	}
}
function q(e, t) {
	for (let n = 0; n < t.days; n++) e.calendar[(t.week - 1) * 7 + t.start + n] = { ...t };
	e.points += t.points;
}
function ie(e) {
	return e.calendar.filter((e, t) => e !== null && t % 7 === e.start);
}
function J(e, t) {
	return e.participants.filter((e) => e !== t);
}
function Y(e, t) {
	return e.participants.includes(t.rid) && J(e, t.rid).length > 0 ? e.heartCount : 0;
}
function ae(e, t, n) {
	e.afterHearts = t, e.heartCount = n, e.heartReady = e.players.filter((t) => Y(e, t) === 0).map((e) => e.rid), e.phase = e.heartReady.length === e.players.length ? "settle" : "hearts";
}
function oe(e) {
	e.card = e.decks[e.week - 1][e.invitation], e.start = null, e.choices = {}, e.participants = [], e.dice = {}, e.gains = {}, e.heartReady = [], e.transferDie = null, e.phase = "schedule";
}
function se(e) {
	e.invitation++, e.invitation === 6 || e.players.every((t) => t.calendar.slice((e.week - 1) * 7, e.week * 7).every(Boolean)) ? (e.card = null, e.start = 2, e.phase = "study", e.participants = [], e.dice = {}, e.gains = {}) : (e.proposer = e.players[(e.players.findIndex((t) => t.rid === e.proposer) + 1) % e.players.length].rid, oe(e));
}
function ce(e) {
	let t = O(e.card), n = e.start;
	if (e.participants = e.players.filter((t) => e.choices[t.rid]?.yes).map((e) => e.rid), e.config.transferStudents && e.transferDie !== null && ([
		2,
		3,
		6
	].includes(e.transferDie) && e.participants.push(k), [
		4,
		5,
		6
	].includes(e.transferDie) && e.participants.push(A), e.participants.some((e) => j.includes(e)))) for (let r = 0; r < t.days; r++) e.transferCalendar[(e.week - 1) * 7 + n + r] = {
		card: t.id,
		kind: t.kind,
		week: e.week,
		start: n,
		days: t.days,
		points: 0,
		members: e.participants.filter((e) => j.includes(e)),
		die: null
	};
	e.dice = {};
	for (let n of e.participants) (t.mode === "video" || t.mode === "bugs") && (e.dice[n] = j.includes(n) ? 1 : H(e)), t.mode === "tabletop" && (e.dice[n] = j.includes(n) ? 1 : e.choices[n].die);
	let r = Math.max(0, ...Object.values(e.dice)), i = Object.values(e.dice).filter((e) => e === r).length, a = e.participants.filter((t) => G(e, t) === "boy").length, o = {};
	e.gains = {};
	for (let s of e.players.filter((t) => e.participants.includes(t.rid))) {
		let c = ie(s), l = c.filter((e) => e.kind === "base").length, u = c.filter((e) => e.week <= 2 && e.kind !== "homework").length, d = K(t, e.participants.length, a, l, u, e.dice[s.rid] ?? 0, r, i);
		q(s, {
			card: t.id,
			kind: t.kind,
			week: e.week,
			start: n,
			days: t.days,
			points: d,
			members: [...e.participants],
			die: e.dice[s.rid] ?? null
		});
		let f = s.pages;
		W(s, t.pages ?? 0), o[s.rid] = s.pages - f, (t.mode === "fixed" || e.participants.length === 1) && U(s, t.title), e.gains[s.rid] = d;
	}
	return e.phase = "reveal", [{
		kind: "diaryStamp",
		data: {
			start: n,
			days: t.days,
			week: e.week,
			members: e.participants,
			gains: e.gains
		}
	}, ...e.players.filter((e) => o[e.rid] > 0).map((e) => ({
		kind: "pagesWritten",
		for: [e.rid],
		secret: { pages: o[e.rid] },
		with: !0
	}))];
}
function le(e) {
	e.participants = e.players.filter((t) => t.calendar[(e.week - 1) * 7 + 2] === null).map((e) => e.rid), e.config.transferStudents && !e.transferCalendar[(e.week - 1) * 7 + 2] && (e.participants.push(...j), e.transferCalendar[(e.week - 1) * 7 + 2] = {
		card: 0,
		kind: "study",
		week: e.week,
		start: 2,
		days: 1,
		points: 0,
		members: [...j],
		die: null
	});
	let t = e.participants.length === 1, n = e.week === 4 ? t ? 4 : 3 : t ? 3 : 2, r = t ? 0 : e.week === 4 ? 2 : 3, i = {};
	e.gains = {}, e.dice = {};
	for (let t of e.players.filter((t) => e.participants.includes(t.rid))) {
		q(t, {
			card: 0,
			kind: "study",
			week: e.week,
			start: 2,
			days: 1,
			points: r,
			members: [...e.participants],
			die: null
		});
		let a = t.pages;
		W(t, n), i[t.rid] = t.pages - a, e.gains[t.rid] = r;
	}
	return ae(e, "study", +!t), [{
		kind: "diaryStamp",
		data: {
			start: 2,
			days: 1,
			week: e.week,
			members: e.participants,
			gains: e.gains
		}
	}, ...e.players.filter((e) => i[e.rid] > 0).map((e) => ({
		kind: "pagesWritten",
		for: [e.rid],
		secret: { pages: i[e.rid] },
		with: !0
	}))];
}
function ue(e) {
	e.card = null, e.start = null, e.phase = "homework", e.participants = [], e.gains = {}, e.dice = {}, de(e);
}
function de(e) {
	e.players.every((t) => t.calendar.slice((e.week - 1) * 7, e.week * 7).every(Boolean)) && (e.phase = "weekEnd", e.ready = []);
}
function fe(e) {
	let t = {};
	for (let n of e.players) {
		let e = n.pages < 25 ? (n.pages - 25) * 10 : (n.pages - 25) * 2;
		t[n.rid] = {
			activity: n.points,
			homework: e,
			titles: n.titles.length ** 2,
			friendship: 0,
			total: 0,
			pages: n.pages,
			hearts: { ...n.hearts }
		};
	}
	for (let n of [...e.players.map((e) => e.rid), ...e.config.transferStudents ? j : []]) {
		let r = e.players.filter((e) => e.rid !== n), i = Math.max(...r.map((e) => e.hearts[n] ?? 0)), a = r.filter((e) => (e.hearts[n] ?? 0) === i);
		for (let e of a) t[e.rid].friendship += a.length === 1 ? 10 : 5;
	}
	for (let e of Object.values(t)) e.total = e.activity + e.homework + e.titles + e.friendship;
	return t;
}
var pe = {
	meta: M,
	saveCompatibility: { version: "1" },
	schemas: {
		action: P,
		publicView: R,
		privateView: z,
		config: N
	},
	setup(t, n, r) {
		let i = {
			seed: r,
			cursor: 0,
			config: t,
			phase: "characters",
			week: 1,
			invitation: 0,
			players: n.map((e) => ({
				rid: e,
				gender: null,
				calendar: Array(28).fill(null),
				titles: [],
				points: 0,
				pages: 0,
				hearts: {},
				lastHomework: null
			})),
			decks: [],
			proposer: n[0],
			card: null,
			start: null,
			choices: {},
			participants: [],
			dice: {},
			gains: {},
			heartReady: [],
			heartCount: 0,
			afterHearts: "invite",
			transferCalendar: Array(28).fill(null),
			transferDie: null,
			ready: []
		};
		for (let t = 1; t <= 4; t++) {
			let n = D.filter((e) => e.week === t).map((e) => e.id);
			for (let t = n.length - 1; t > 0; t--) {
				let a = e(r, i.cursor++, t + 1);
				[n[t], n[a]] = [n[a], n[t]];
			}
			i.decks.push(n);
		}
		return { state: i };
	},
	reduce(e, t, { by: n }) {
		if (t.type === "tick") {
			if (![
				"reveal",
				"settle",
				"study"
			].includes(e.phase)) return B();
			let t = structuredClone(e);
			if (t.phase === "reveal") ae(t, "invite", O(t.card).hearts);
			else if (t.phase === "study") return {
				state: t,
				fx: le(t)
			};
			else t.afterHearts === "study" ? ue(t) : se(t);
			return { state: t };
		}
		let r = e.players.findIndex((e) => e.rid === n);
		if (r < 0 || e.phase === "done") return B();
		let i = structuredClone(e), a = i.players[r];
		switch (t.type) {
			case "character":
				if (i.phase !== "characters" || a.gender !== null) return B();
				a.gender = t.gender, i.players.every((e) => e.gender !== null) && oe(i);
				break;
			case "schedule": {
				if (i.phase !== "schedule" || i.proposer !== n || !V(a.calendar, i.week, O(i.card).days).includes(t.start)) return B();
				let e = O(i.card);
				i.start = t.start, i.choices = {}, i.phase = "attend";
				for (let n of i.players) V(n.calendar, i.week, e.days).includes(t.start) || (i.choices[n.rid] = {
					yes: !1,
					die: null
				});
				if (i.config.transferStudents && Array.from({ length: e.days }, (e, n) => i.transferCalendar[(i.week - 1) * 7 + t.start + n]).every((e) => !e) && (i.transferDie = H(i)), i.players.every((e) => i.choices[e.rid])) return {
					state: i,
					fx: ce(i)
				};
				break;
			}
			case "skip":
				if (i.phase !== "schedule" || i.proposer !== n || V(a.calendar, i.week, O(i.card).days).length > 0) return B();
				se(i);
				break;
			case "attend": {
				if (i.phase !== "attend" || i.choices[n]) return B();
				let e = O(i.card);
				if (t.yes && !V(a.calendar, i.week, e.days).includes(i.start) || t.yes && e.mode === "tabletop" && t.die === void 0) return B();
				if (i.choices[n] = {
					yes: t.yes,
					die: t.yes && e.mode === "tabletop" ? t.die : null
				}, i.players.every((e) => i.choices[e.rid])) return {
					state: i,
					fx: ce(i)
				};
				break;
			}
			case "hearts": {
				if (i.phase !== "hearts" || i.heartReady.includes(n) || t.targets.length !== Y(i, a) || t.targets.some((e) => !J(i, n).includes(e))) return B();
				let e = { ...a.hearts };
				for (let e of t.targets) a.hearts[e] = Math.min(10, (a.hearts[e] ?? 0) + 1);
				i.heartReady.push(n), i.heartReady.length === i.players.length && (i.phase = "settle");
				let r = Object.keys(a.hearts).reduce((t, n) => t + a.hearts[n] - (e[n] ?? 0), 0);
				return {
					state: i,
					fx: r ? [{
						kind: "friendshipInk",
						for: [n],
						secret: { count: r }
					}] : []
				};
			}
			case "homework": {
				let e = a.calendar.slice((i.week - 1) * 7, i.week * 7).findIndex((e) => e === null);
				if (i.phase !== "homework" || e < 0) return B();
				let t = H(i), r = i.week === 4 ? t <= 2 : t === 1, o = r ? i.week === 4 ? 5 : 3 : 0, s = r ? 0 : i.week === 4 ? t === 6 ? 4 : 3 : t === 6 ? 3 : 2, c = a.pages;
				return q(a, {
					card: 0,
					kind: "homework",
					week: i.week,
					start: e,
					days: 1,
					points: o,
					members: [n],
					die: null
				}), W(a, s), r && U(a, i.week === 4 ? "slacker" : "lazy"), a.lastHomework = {
					week: i.week,
					day: e,
					die: t,
					pages: s,
					points: o
				}, de(i), {
					state: i,
					fx: [{
						kind: "homeworkRoll",
						for: [n],
						secret: {
							die: t,
							pages: a.pages - c,
							points: o,
							start: e,
							week: i.week
						}
					}]
				};
			}
			case "next":
				if (i.phase !== "weekEnd" || i.ready.includes(n)) return B();
				if (i.ready.push(n), i.ready.length === i.players.length) {
					if (i.week === 4) i.phase = "done";
					else {
						i.week++, i.invitation = 0, i.proposer = re(i), i.ready = [];
						for (let e of i.players) e.lastHomework = null;
						oe(i);
					}
				}
		}
		return { state: i };
	},
	viewFor(e, t) {
		let n = e.players.find((e) => e.rid === t), r = ![
			"schedule",
			"attend",
			"characters"
		].includes(e.phase);
		return {
			public: {
				phase: e.phase,
				week: e.week,
				invitation: e.invitation,
				leader: re(e),
				proposer: e.proposer,
				card: e.card,
				start: e.start,
				players: e.players.map((t) => ({
					rid: t.rid,
					gender: t.gender,
					calendar: structuredClone(t.calendar),
					titles: [...t.titles],
					points: t.points,
					ready: e.phase === "characters" ? t.gender !== null : e.phase === "attend" ? !!e.choices[t.rid] : e.ready.includes(t.rid)
				})),
				transferStudents: e.config.transferStudents,
				transferCalendar: [...e.transferCalendar],
				transferDie: e.transferDie,
				participants: r ? [...e.participants] : [],
				dice: r ? { ...e.dice } : {},
				gains: r ? { ...e.gains } : {},
				heartReady: [...e.heartReady],
				results: e.phase === "done" ? fe(e) : null
			},
			...n ? { private: {
				pages: n.pages,
				hearts: { ...n.hearts },
				choice: e.choices[t] ? { ...e.choices[t] } : null,
				heartCount: Y(e, n),
				targets: J(e, t),
				allocated: e.heartReady.includes(t),
				lastHomework: n.lastHomework ? { ...n.lastHomework } : null
			} } : {}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = fe(e), n = e.players.map((e) => e.rid).sort((e, n) => t[n].total - t[e].total);
		return {
			phase: "done",
			ranking: n,
			winner: n.filter((e) => t[e].total === t[n[0]].total),
			scores: Object.fromEntries(n.map((e) => [e, t[e].total]))
		};
	},
	nextTickIn(e) {
		return [
			"reveal",
			"settle",
			"study"
		].includes(e.phase) ? 850 : null;
	}
}, me = "<pattern id=\"tooth\" width=\"23\" height=\"19\" patternUnits=\"userSpaceOnUse\"><g fill=\"#fffaf0\" opacity=\".35\"><circle cx=\"2\" cy=\"3\" r=\".7\" /><circle cx=\"7\" cy=\"15\" r=\".5\" /><circle cx=\"16\" cy=\"4\" r=\".6\" /><circle cx=\"21\" cy=\"12\" r=\".5\" /><circle cx=\"11\" cy=\"7\" r=\".8\" /><circle cx=\"15\" cy=\"17\" r=\".6\" /><path d=\"m3 10 1.8-.7.6.8-1.6.7Zm10 3 1.1-.5.5 1.3-1.7.4Z\" /></g></pattern>\n<filter id=\"waxgrain\" x=\"0\" y=\"0\" width=\"1\" height=\"1\"><feTurbulence type=\"fractalNoise\" baseFrequency=\".63\" numOctaves=\"3\" seed=\"14\" result=\"noise\" /><feColorMatrix in=\"noise\" type=\"matrix\" values=\"0 0 0 0 .98 0 0 0 0 .96 0 0 0 0 .87 0 0 0 .4 -.15\" result=\"lightgrain\" /><feComposite in=\"lightgrain\" in2=\"SourceGraphic\" operator=\"in\" result=\"clipped\" /><feBlend in=\"SourceGraphic\" in2=\"clipped\" mode=\"screen\" /></filter>\n", he = [
	"<path d=\"M121 281Q75 287 74 311Q98 334 159 321L196 294 230 322Q277 331 284 308Q275 287 222 275Z\" fill=\"#446d91\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M121 281Q75 287 74 311Q98 334 159 321L196 294 230 322Q277 331 284 308Q275 287 222 275Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M114 178Q154 163 202 180L228 267Q174 292 111 266Z\" fill=\"#e9b63e\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M114 178Q154 163 202 180L228 267Q174 292 111 266Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M121 203q43-14 87 0m-90 27q45-12 96 0m-100 25q43-11 104-1\" fill=\"none\" stroke=\"#d88c31\" stroke-width=\"8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M118 184Q100 183 94 202L74 244Q72 255 85 258L133 243 128 225 101 232 123 202Z\" fill=\"#edb96a\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M118 184Q100 183 94 202L74 244Q72 255 85 258L133 243 128 225 101 232 123 202Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g class=\"nm-child-arm\" style=\"transform-origin:212px 195px;--nm-rest:155deg\"><path d=\"M200 187Q221 181 227 162L241 107 261 111 252 180Q247 211 222 222Z\" fill=\"#edb96a\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M200 187Q221 181 227 162L241 107 261 111 252 180Q247 211 222 222Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(244 76) scale(0.8)\"><path d=\"M0 34C-9 26-18 20-16 15C-14 11-9 13-4 17L-7-6Q-7-14-2-13Q2-12 2-5L4 9 6-14Q7-22 11-20Q15-18 13-11L13 10 19-10Q21-17 25-14Q28-11 25-5L21 14 27 2Q30-4 34-1Q37 2 32 9L25 29Q19 42 7 43Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 34C-9 26-18 20-16 15C-14 11-9 13-4 17L-7-6Q-7-14-2-13Q2-12 2-5L4 9 6-14Q7-22 11-20Q15-18 13-11L13 10 19-10Q21-17 25-14Q28-11 25-5L21 14 27 2Q30-4 34-1Q37 2 32 9L25 29Q19 42 7 43Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1 18q7 2 7 13m4-20 0 9m8-5-2 8\" fill=\"none\" stroke=\"#bb8547\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g><ellipse cx=\"160\" cy=\"130\" rx=\"45\" ry=\"47\" fill=\"#efbc65\" stroke=\"#9b6739\" stroke-width=\"1.6\" /><ellipse cx=\"133.0\" cy=\"143\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><ellipse cx=\"184.75\" cy=\"143\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M143 131q4-5 8 0m18 0q4-5 8 0\" fill=\"none\" stroke=\"#513729\" stroke-width=\"2.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M150 146q11 17 22 -1q-10 25-22 1Z\" fill=\"#b94336\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M112 122Q103 73 148 74Q188 54 208 91L208 126 195 109 190 127 178 108 164 120 150 105 136 119 126 108Z\" fill=\"#49382d\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M112 122Q103 73 148 74Q188 54 208 91L208 126 195 109 190 127 178 108 164 120 150 105 136 119 126 108Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M95 311q-28-4-32 13q13 17 47 5l24-12-14-12Z\" fill=\"#645446\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M95 311q-28-4-32 13q13 17 47 5l24-12-14-12Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M243 310q29-4 36 9q-5 18-40 10l-22-12 12-12Z\" fill=\"#645446\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M243 310q29-4 36 9q-5 18-40 10l-22-12 12-12Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"<path d=\"M422 249 420 333Q426 349 441 336L449 250Z\" fill=\"#edb96a\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M422 249 420 333Q426 349 441 336L449 250Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M470 249 479 337Q489 349 500 337L493 247Z\" fill=\"#edb96a\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M470 249 479 337Q489 349 500 337L493 247Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M413 332Q431 327 446 337L447 352 405 352Q399 346 413 332Z\" fill=\"#cf624e\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M413 332Q431 327 446 337L447 352 405 352Q399 346 413 332Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M477 335Q493 327 504 341L512 352 472 352Z\" fill=\"#cf624e\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M477 335Q493 327 504 341L512 352 472 352Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M421 123Q451 114 486 123L505 253Q460 277 407 254Z\" fill=\"#d86b59\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M421 123Q451 114 486 123L505 253Q460 277 407 254Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M420 125 411 167 424 184 438 155 437 122Z\" fill=\"#f5dc93\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M420 125 411 167 424 184 438 155 437 122Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M483 123 508 162 496 180 474 149Z\" fill=\"#f5dc93\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M483 123 508 162 496 180 474 149Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M418 158Q399 165 408 186L450 205 459 188 428 174Z\" fill=\"#edb96a\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M418 158Q399 165 408 186L450 205 459 188 428 174Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g class=\"nm-child-arm\" style=\"transform-origin:485px 157px;--nm-rest:155deg\"><g transform=\"translate(273 -38)\"><path d=\"M200 187Q221 181 227 162L241 107 261 111 252 180Q247 211 222 222Z\" fill=\"#edb96a\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M200 187Q221 181 227 162L241 107 261 111 252 180Q247 211 222 222Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(244 76) scale(0.8)\"><path d=\"M0 34C-9 26-18 20-16 15C-14 11-9 13-4 17L-7-6Q-7-14-2-13Q2-12 2-5L4 9 6-14Q7-22 11-20Q15-18 13-11L13 10 19-10Q21-17 25-14Q28-11 25-5L21 14 27 2Q30-4 34-1Q37 2 32 9L25 29Q19 42 7 43Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 34C-9 26-18 20-16 15C-14 11-9 13-4 17L-7-6Q-7-14-2-13Q2-12 2-5L4 9 6-14Q7-22 11-20Q15-18 13-11L13 10 19-10Q21-17 25-14Q28-11 25-5L21 14 27 2Q30-4 34-1Q37 2 32 9L25 29Q19 42 7 43Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1 18q7 2 7 13m4-20 0 9m8-5-2 8\" fill=\"none\" stroke=\"#bb8547\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g></g><path d=\"M434 172 466 181 496 171 496 219 465 228 431 217Z\" fill=\"#fffbdf\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M434 172 466 181 496 171 496 219 465 228 431 217Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M466 182v46m-27-37 19 4m-19 6 19 4m16-9 15-5m-15 15 15-5\" fill=\"none\" stroke=\"#baa77a\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M408 70Q407 25 452 25Q501 22 504 76L504 118 485 125 476 96 432 100 419 122 403 109Z\" fill=\"#48382d\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M408 70Q407 25 452 25Q501 22 504 76L504 118 485 125 476 96 432 100 419 122 403 109Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"455\" cy=\"79\" rx=\"37\" ry=\"42\" fill=\"#efbc65\" stroke=\"#9b6739\" stroke-width=\"1.6\" /><ellipse cx=\"432.8\" cy=\"92\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><ellipse cx=\"475.35\" cy=\"92\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M438 80q4-5 8 0m18 0q4-5 8 0\" fill=\"none\" stroke=\"#513729\" stroke-width=\"2.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M445 95q11 17 22 -1q-10 25-22 1Z\" fill=\"#b94336\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M415 69Q416 31 452 31Q492 29 495 68L480 56 474 68 461 54 446 65 434 54 426 69Z\" fill=\"#49382d\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M415 69Q416 31 452 31Q492 29 495 68L480 56 474 68 461 54 446 65 434 54 426 69Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"<path d=\"M697 268Q655 291 668 318Q687 333 721 311L753 295 779 318Q809 324 822 306L803 282 763 264Z\" fill=\"#425e7a\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M697 268Q655 291 668 318Q687 333 721 311L753 295 779 318Q809 324 822 306L803 282 763 264Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M699 174Q728 165 767 179L796 265Q748 286 689 263Z\" fill=\"#66a9ba\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M699 174Q728 165 767 179L796 265Q748 286 689 263Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M709 193l56 9m-58 8 60 10\" fill=\"none\" stroke=\"#82c3cb\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g class=\"nm-child-arm\" style=\"transform-origin:684px 190px;--nm-rest:-145deg\"><path d=\"M696 182Q677 180 671 161L647 86 628 93 643 172Q652 205 681 218Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M696 182Q677 180 671 161L647 86 628 93 643 172Q652 205 681 218Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(611 52) scale(0.88)\"><path d=\"M0 34C-9 26-18 20-16 15C-14 11-9 13-4 17L-7-6Q-7-14-2-13Q2-12 2-5L4 9 6-14Q7-22 11-20Q15-18 13-11L13 10 19-10Q21-17 25-14Q28-11 25-5L21 14 27 2Q30-4 34-1Q37 2 32 9L25 29Q19 42 7 43Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 34C-9 26-18 20-16 15C-14 11-9 13-4 17L-7-6Q-7-14-2-13Q2-12 2-5L4 9 6-14Q7-22 11-20Q15-18 13-11L13 10 19-10Q21-17 25-14Q28-11 25-5L21 14 27 2Q30-4 34-1Q37 2 32 9L25 29Q19 42 7 43Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1 18q7 2 7 13m4-20 0 9m8-5-2 8\" fill=\"none\" stroke=\"#bb8547\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g><path d=\"M772 184Q790 184 798 205L817 240 803 250 774 218Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M772 184Q790 184 798 205L817 240 803 250 774 218Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"732\" cy=\"130\" rx=\"44\" ry=\"46\" fill=\"#efbc65\" stroke=\"#9b6739\" stroke-width=\"1.6\" /><ellipse cx=\"705.6\" cy=\"143\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><ellipse cx=\"756.2\" cy=\"143\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M715 131q4-5 8 0m18 0q4-5 8 0\" fill=\"none\" stroke=\"#513729\" stroke-width=\"2.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M722 146q11 17 22 -1q-10 25-22 1Z\" fill=\"#b94336\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M687 119Q677 75 721 72Q753 64 777 90L780 120 765 109 760 123 748 109 733 119 718 105 702 121 697 109Z\" fill=\"#4d372b\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M687 119Q677 75 721 72Q753 64 777 90L780 120 765 109 760 123 748 109 733 119 718 105 702 121 697 109Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M668 312q-21 4-17 17q22 10 47-4l15-11-10-9Z\" fill=\"#b15b3e\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M668 312q-21 4-17 17q22 10 47-4l15-11-10-9Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M795 309q26-6 34 11q-9 16-41 7l-12-11Z\" fill=\"#b15b3e\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M795 309q26-6 34 11q-9 16-41 7l-12-11Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"<path d=\"M975 272Q960 304 978 321L1032 332 1043 316 1004 302 1010 274Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M975 272Q960 304 978 321L1032 332 1043 316 1004 302 1010 274Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1020 274Q1034 294 1062 306L1089 310 1085 331Q1040 332 1002 313Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1020 274Q1034 294 1062 306L1089 310 1085 331Q1040 332 1002 313Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M965 183Q1006 164 1044 187L1072 275Q1011 301 956 273Z\" fill=\"#96ac69\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M965 183Q1006 164 1044 187L1072 275Q1011 301 956 273Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M980 199q23 9 47 0m-51 11q28 8 56-1m-36 35v29\" fill=\"none\" stroke=\"#bed091\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M967 191Q954 192 948 216L955 262Q961 275 972 264L968 221 982 207Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M967 191Q954 192 948 216L955 262Q961 275 972 264L968 221 982 207Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g class=\"nm-child-arm\" style=\"transform-origin:1041px 195px;--nm-rest:155deg\"><g transform=\"translate(829 0)\"><path d=\"M200 187Q221 181 227 162L241 107 261 111 252 180Q247 211 222 222Z\" fill=\"#edb96a\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M200 187Q221 181 227 162L241 107 261 111 252 180Q247 211 222 222Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(244 76) scale(0.8)\"><path d=\"M0 34C-9 26-18 20-16 15C-14 11-9 13-4 17L-7-6Q-7-14-2-13Q2-12 2-5L4 9 6-14Q7-22 11-20Q15-18 13-11L13 10 19-10Q21-17 25-14Q28-11 25-5L21 14 27 2Q30-4 34-1Q37 2 32 9L25 29Q19 42 7 43Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 34C-9 26-18 20-16 15C-14 11-9 13-4 17L-7-6Q-7-14-2-13Q2-12 2-5L4 9 6-14Q7-22 11-20Q15-18 13-11L13 10 19-10Q21-17 25-14Q28-11 25-5L21 14 27 2Q30-4 34-1Q37 2 32 9L25 29Q19 42 7 43Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1 18q7 2 7 13m4-20 0 9m8-5-2 8\" fill=\"none\" stroke=\"#bb8547\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g></g><path d=\"M966 122Q938 81 967 64L977 98Z\" fill=\"#51382d\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M966 122Q938 81 967 64L977 98Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1035 121Q1068 84 1040 66L1022 99Z\" fill=\"#51382d\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1035 121Q1068 84 1040 66L1022 99Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"1004\" cy=\"133\" rx=\"43\" ry=\"46\" fill=\"#efbc65\" stroke=\"#9b6739\" stroke-width=\"1.6\" /><ellipse cx=\"978.2\" cy=\"146\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><ellipse cx=\"1027.65\" cy=\"146\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M987 134q4-5 8 0m18 0q4-5 8 0\" fill=\"none\" stroke=\"#513729\" stroke-width=\"2.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M998 152q7 5 14-1\" fill=\"none\" stroke=\"#86513b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M961 128Q948 83 978 78Q1005 58 1037 84L1050 127 1037 118 1029 103 1018 119 1005 104 990 121 982 107 970 128Z\" fill=\"#51382d\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M961 128Q948 83 978 78Q1005 58 1037 84L1050 127 1037 118 1029 103 1018 119 1005 104 990 121 982 107 970 128Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1034 317q10-10 22-1l-3 23-38-3Z\" fill=\"#b85655\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1034 317q10-10 22-1l-3 23-38-3Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1082 311q13-8 22 6l7 19-34 4Z\" fill=\"#b85655\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1082 311q13-8 22 6l7 19-34 4Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />"
], ge = "<g filter=\"url(#waxgrain)\"><rect x=\"0\" y=\"0\" width=\"800\" height=\"560\" rx=\"0\" fill=\"#8fcbd8\" stroke=\"none\" stroke-width=\"0\" /><path d=\"M0 130Q160 92 310 125L455 140 610 110 800 122V212H0Z\" fill=\"#5f8c67\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 145Q200 138 310 157T800 150V560H0Z\" fill=\"#418bb4\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 244Q172 204 348 243T800 236V560H0Z\" fill=\"#429fc1\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 383Q150 331 359 385T800 347V560H0Z\" fill=\"#64b7c8\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 480Q67 471 142 518L191 560H0Z\" fill=\"#e6cc81\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><circle cx=\"682\" cy=\"63\" r=\"31\" fill=\"#efc957\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M72 69q22-27 47-7q30-22 49 1l31 7q-64 14-127-1m330 23q19-20 33-7 30-24 53 4l39 8q-69 8-125-5\" fill=\"#fffae5\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M214 202 200 245 251 263 272 226Z\" fill=\"#dc9448\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M214 202 200 245 251 263 272 226Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M211 214Q185 204 165 182L153 189Q164 217 198 238Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M211 214Q185 204 165 182L153 189Q164 217 198 238Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M266 209Q282 184 280 166L298 164Q307 194 281 229Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M266 209Q282 184 280 166L298 164Q307 194 281 229Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"245\" cy=\"173\" rx=\"35\" ry=\"37\" fill=\"#efbc65\" stroke=\"#9b6739\" stroke-width=\"1.6\" /><ellipse cx=\"224.0\" cy=\"186\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><ellipse cx=\"264.25\" cy=\"186\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M228 174q4-5 8 0m18 0q4-5 8 0\" fill=\"none\" stroke=\"#513729\" stroke-width=\"2.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M235 189q11 17 22 -1q-10 25-22 1Z\" fill=\"#b94336\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M208 170Q200 135 234 130Q269 122 280 154L278 169 267 156 254 166 245 151 231 163 218 154Z\" fill=\"#47382d\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M208 170Q200 135 234 130Q269 122 280 154L278 169 267 156 254 166 245 151 231 163 218 154Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M139 165l-12-18m29 7-2-23m156 30 18-17m-15 32 24-5\" fill=\"none\" stroke=\"#e5f5e8\" stroke-width=\"6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M172 251q57-17 113 5m-138 12q74 15 162-3\" fill=\"none\" stroke=\"#b9e0dc\" stroke-width=\"7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"rotate(-17 249 437)\"><ellipse cx=\"244\" cy=\"451\" rx=\"143\" ry=\"39\" fill=\"#e8c348\" stroke=\"#a69046\" stroke-width=\"2\" /><ellipse cx=\"244\" cy=\"451\" rx=\"133\" ry=\"27\" fill=\"#f7d766\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M215 353Q181 373 178 412L254 438 287 404 271 365Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M215 353Q181 373 178 412L254 438 287 404 271 365Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M195 393Q161 404 140 433L150 446 200 416Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M195 393Q161 404 140 433L150 446 200 416Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M263 393Q301 397 323 428L313 439 268 417Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M263 393Q301 397 323 428L313 439 268 417Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M253 417 282 411 320 439 302 455Z\" fill=\"#dc7054\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M253 417 282 411 320 439 302 455Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M304 441Q336 451 356 476L345 489 307 469 284 452Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M304 441Q336 451 356 476L345 489 307 469 284 452Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"246\" cy=\"344\" rx=\"39\" ry=\"43\" fill=\"#efbc65\" stroke=\"#9b6739\" stroke-width=\"1.6\" /><ellipse cx=\"222.6\" cy=\"357\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><ellipse cx=\"267.45\" cy=\"357\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M229 345q4-5 8 0m18 0q4-5 8 0\" fill=\"none\" stroke=\"#513729\" stroke-width=\"2.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M236 360q11 17 22 -1q-10 25-22 1Z\" fill=\"#b94336\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M207 339Q195 298 228 295Q265 280 284 315L287 341 272 326 264 340 249 325 232 339 221 324Z\" fill=\"#51382b\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M207 339Q195 298 228 295Q265 280 284 315L287 341 272 326 264 340 249 325 232 339 221 324Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M537 327Q523 281 549 268L613 270Q644 291 626 335Z\" fill=\"#d94f51\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M537 327Q523 281 549 268L613 270Q644 291 626 335Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M541 283Q522 285 511 316L494 352 509 365 541 328 554 304Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M541 283Q522 285 511 316L494 352 509 365 541 328 554 304Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M618 282Q642 287 651 313L674 347 661 360 630 331 610 305Z\" fill=\"#efbc65\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M618 282Q642 287 651 313L674 347 661 360 630 331 610 305Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"580\" cy=\"251\" rx=\"46\" ry=\"48\" fill=\"#efbc65\" stroke=\"#9b6739\" stroke-width=\"1.6\" /><ellipse cx=\"552.4\" cy=\"264\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><ellipse cx=\"605.3\" cy=\"264\" rx=\"8\" ry=\"4\" fill=\"#dc8d65\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M563 252q4-5 8 0m18 0q4-5 8 0\" fill=\"none\" stroke=\"#513729\" stroke-width=\"2.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M570 267q11 17 22 -1q-10 25-22 1Z\" fill=\"#b94336\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M533 250Q511 203 547 196Q575 177 612 203L628 242 618 270 608 236 595 248 583 231 568 248 553 233 545 264Z\" fill=\"#48342b\" stroke=\"#6a482e\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M533 250Q511 203 547 196Q575 177 612 203L628 242 618 270 608 236 595 248 583 231 568 248 553 233 545 264Z\" fill=\"url(#tooth)\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"582\" cy=\"372\" rx=\"139\" ry=\"65\" fill=\"#ca4e52\" stroke=\"#a05a46\" stroke-width=\"2\" /><path d=\"M443 372Q467 317 514 319L533 349Q500 357 490 378Z\" fill=\"#fff4d9\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M562 309Q605 306 639 323L618 351 567 345Z\" fill=\"#fff4d9\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M680 335Q721 366 709 393L665 388 652 364Z\" fill=\"#fff4d9\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M511 416Q545 440 590 434L585 399 536 391Z\" fill=\"#fff4d9\" stroke=\"none\" stroke-width=\"0\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"582\" cy=\"363\" rx=\"79\" ry=\"29\" fill=\"#3f8fae\" stroke=\"#a45d4e\" stroke-width=\"2\" /><path d=\"M520 355q58-22 123 0\" fill=\"none\" stroke=\"#efb595\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"508\" cy=\"352\" rx=\"18\" ry=\"12\" fill=\"#efbc65\" stroke=\"#b17a40\" stroke-width=\"1.3\" /><ellipse cx=\"658\" cy=\"351\" rx=\"18\" ry=\"12\" fill=\"#efbc65\" stroke=\"#b17a40\" stroke-width=\"1.3\" /><path d=\"M42 194q26.333333333333332 14 79 -2m-55.3 11 39.5 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M369 202q29.666666666666668 14 89 -2m-62.3 11 44.5 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M646 201q29.333333333333332 14 88 -2m-61.599999999999994 11 44.0 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M35 305q28.666666666666668 14 86 -2m-60.199999999999996 11 43.0 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M340 308q27.666666666666668 14 83 -2m-58.099999999999994 11 41.5 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M691 286q24.0 14 72 -2m-50.4 11 36.0 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M395 467q33.666666666666664 14 101 -2m-70.69999999999999 11 50.5 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M600 482q29.333333333333332 14 88 -2m-61.599999999999994 11 44.0 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M180 525q35.0 14 105 -2m-73.5 11 52.5 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M513 530q19.0 14 57 -2m-39.9 11 28.5 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M48 416q11.666666666666666 14 35 -2m-24.5 11 17.5 -3\" fill=\"none\" stroke=\"#e7f3df\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>", _e = [
	"#e1ae53",
	"#b95e59",
	"#609fa5",
	"#88a66c",
	"#9c7ca2",
	"#cf8751"
], ve = [
	"#4d372b",
	"#553c2e",
	"#45382f",
	"#50352b",
	"#6b4932",
	"#3e352d"
], ye = [
	"#eab66c",
	"#efc383",
	"#dba568",
	"#ebbb78",
	"#dca16a",
	"#efc58b"
];
function be(e, t) {
	let n = (e % 6 + 6) % 6, r = _e[n], i = ve[n], a = ye[n], o = (e, t, n = "#6a482e", r = 2) => `<path d="${e}" fill="${t}" stroke="${n}" stroke-width="${r}" stroke-linecap="round" stroke-linejoin="round"/>`, s = (e, t, n, r, i) => `<ellipse cx="${e}" cy="${t}" rx="${n}" ry="${r}" fill="${i}"/>`, c = t === "girl", l = c ? n % 3 == 0 ? o("M78 96Q50 100 65 151L79 141ZM152 96Q180 100 165 151L152 140Z", i) : n % 3 == 1 ? o("M78 94Q58 139 73 179L96 166 146 172 159 163Q174 135 150 91Z", i) : o("M78 105Q55 118 63 155L79 145ZM151 105Q174 118 166 155L152 144Z", i) : "", u = [
		"M72 125Q59 80 94 78Q122 59 151 84L161 124 146 113 135 96 124 112 109 97 95 113 86 100Z",
		"M72 124Q61 88 87 80Q118 62 147 79L160 104 157 128 144 108 124 111 123 92 106 111 92 110 83 124Z",
		"M72 126Q60 83 88 76L100 65 110 75 127 64 133 76 151 78 163 122 149 111 137 96 121 112 110 99 92 116 83 104Z",
		"M72 125Q59 84 92 76Q125 62 150 86L162 123 147 111 136 98 120 115 107 99 92 116 83 105Z",
		"M72 126Q57 91 82 81Q104 58 132 75L151 81 162 119 148 114 140 97 121 104 104 95 86 115Z",
		"M72 124Q59 84 88 78Q119 64 149 82L161 124 147 112 137 98 124 114 111 98 96 113 86 101Z"
	][n], d = n === 0 ? o("M83 201 148 201M79 216 153 216M78 232 154 232", "none", "#f0cb73", 5) : n === 1 ? o("M94 183 113 201 133 182M113 201v45", "none", "#f5dfaf", 3) : n === 2 ? o("M89 185v65m51-65v65M88 212h52v38H88Z", "#477f8b", "#d5dc9c", 2) : n === 3 ? o("M98 203v29m7-24v20", "none", "#c1d398", 4) : n === 4 ? `${s(94, 210, 4, 4, "#e0c5c0")}${s(132, 221, 4, 4, "#e0c5c0")}${s(111, 237, 4, 4, "#e0c5c0")}` : o("M91 205h20v20H91Zm29 0h20v20h-20Z", "none", "#edba7c", 2), f = c ? o("M78 238Q114 252 153 238L162 271Q114 285 68 270Z", r) : o("M77 241Q113 251 152 241L157 278 117 280 112 262 105 280 71 277Z", "#557b8a");
	return `<g filter="url(#waxgrain)">${s(115, 365, 81, 8, "#d4d8b0")}
    <g class="nm-child-standing-legs">${o("M85 264 104 265 101 343 82 347Z", a)}${o("M126 265 146 264 150 345 131 347Z", a)}${o("M81 340q13-6 24 2l-2 22-37 0q-4-11 15-24Z", "#a45349")}${o("M130 341q12-6 23 4l12 16q-15 8-37 2Z", "#a45349")}</g>
    <g class="nm-child-seated-legs">${o("M84 323Q63 322 38 341L29 353 80 363 120 345 109 328Z", a)}${o("M140 323Q163 327 190 345L197 357 157 366 107 345 123 328Z", a)}${o("M43 340q17-7 30 5l32 5-13 16-57-1q-17-6 8-25Z", "#557b8a")}${o("M156 340q20-5 31 8l12 11-12 10-45-5-26-14Z", "#557b8a")}${o("M86 351q12-8 23 1l7 13-30 5-13-7Z", "#a45349")}${o("M133 351q-13-6-22 3l-7 11 28 5 14-8Z", "#a45349")}</g>
    <g class="nm-child-upper">${l}${o("M100 162v26h29v-26Z", a)}${o("M79 183Q113 171 150 184L157 250Q115 269 72 249Z", r)}${d}${f}
      ${o("M80 185Q67 185 64 208L70 240Q77 252 88 241L81 211 95 198Z", a)}
      <g transform="translate(148 190)"><g class="nm-child-arm"><g transform="translate(-148 -190)">${o("M140 183Q154 178 158 197L158 229 163 270 147 267 143 229 145 207Z", a)}<g class="nm-child-rest-hand">${o("M148 264Q142 270 145 279L151 288Q155 292 158 286L161 292Q165 295 168 289L172 277 168 265Z", a, "#6a482e", 1.5)}${o("M147 269Q139 269 142 277L149 282M158 279l1 7M164 279l-1 9", "none", "#9f7046", 1.3)}</g><g class="nm-child-raised-hand">${o("M147 264 138 277Q136 281 140 283L145 279 144 301Q144 307 149 307L152 285 154 313Q156 319 160 313L158 285 165 306Q168 312 172 307L165 280 174 290Q178 294 181 290L169 273Q164 264 157 265Z", a, "#6a482e", 1.5)}</g></g></g></g>
      ${s(115, 127, 43, 46, a)}${o(u, i)}${s(88, 141, 8, 4, "#dc8d65")}${s(140, 141, 8, 4, "#dc8d65")}${o("M98 127q4-5 8 0m18 0q4-5 8 0", "none", "#513729", 2.5)}${o("M108 146q8 7 16-1", "none", "#86513b", 2)}
      ${n === 2 ? o("M73 95q41-24 84 0L155 106Q111 92 74 108Z", "#d2ac58") : n === 4 ? o("M82 88l13-9 5 17-17 4Z", "#c17878") : ""}
      ${c ? o("M76 122q-5 15 2 28m77-27q5 15-2 28", "none", i, 6) : ""}
    </g></g>`;
}
//#endregion
//#region src/games/natsumemo/art.tsx
var xe = n(function({ drawing: e, viewBox: t, className: n = "" }) {
	let r = i().replace(/[^a-zA-Z0-9_-]/g, ""), a = (e) => e.replaceAll("id=\"tooth\"", `id="${r}-tooth"`).replaceAll("id=\"waxgrain\"", `id="${r}-waxgrain"`).replaceAll("url(#tooth)", `url(#${r}-tooth)`).replaceAll("url(#waxgrain)", `url(#${r}-waxgrain)`);
	return /* @__PURE__ */ g("svg", {
		viewBox: t,
		className: n,
		"aria-hidden": !0,
		dangerouslySetInnerHTML: { __html: `<defs>${a(me)}</defs>${a(e)}` }
	});
});
function Se({ variant: e = 0, gender: t, raised: n = !1, standing: r = !1 }) {
	return /* @__PURE__ */ g("div", {
		className: "nm-child-art",
		"data-raised": n,
		"data-standing": r,
		children: /* @__PURE__ */ g(xe, {
			drawing: be(e, t),
			viewBox: "0 0 230 390"
		})
	});
}
function X({ size: e = 20 }) {
	return /* @__PURE__ */ g("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		children: /* @__PURE__ */ g("path", {
			d: "M12 21C7 17 2 13 2 8a5 5 0 0 1 10-2 5 5 0 0 1 10 2c0 5-5 9-10 13Z",
			fill: "#c84a79",
			stroke: "#813c57",
			strokeWidth: "1.3"
		})
	});
}
function Ce({ size: e = 20 }) {
	return /* @__PURE__ */ g("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		children: /* @__PURE__ */ g("path", {
			d: "m12 2 3.1 6.3 6.9 1-5 4.8 1.2 6.9-6.2-3.3-6.2 3.3L7 14l-5-4.7 6.9-1Z",
			fill: "#e9bf52",
			stroke: "#8e6746",
			strokeWidth: "1.4"
		})
	});
}
function Z({ size: e = 20 }) {
	return /* @__PURE__ */ _("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ g("path", {
			d: "M12 5Q7 1 2 4v15q5-3 10 1 5-4 10-1V4q-5-3-10 1Z",
			fill: "#fffaf0",
			stroke: "#715c43",
			strokeWidth: "1.7"
		}), /* @__PURE__ */ g("path", {
			d: "M12 5v15",
			stroke: "#715c43",
			strokeWidth: "1.5"
		})]
	});
}
var we = {
	1: [[24, 24]],
	2: [[13, 13], [35, 35]],
	3: [
		[13, 13],
		[24, 24],
		[35, 35]
	],
	4: [
		[13, 13],
		[35, 13],
		[13, 35],
		[35, 35]
	],
	5: [
		[13, 13],
		[35, 13],
		[24, 24],
		[13, 35],
		[35, 35]
	],
	6: [
		[13, 12],
		[35, 12],
		[13, 24],
		[35, 24],
		[13, 36],
		[35, 36]
	]
};
function Q({ value: e, label: t }) {
	return /* @__PURE__ */ _("svg", {
		className: "nm-die",
		viewBox: "0 0 48 48",
		role: "img",
		"aria-label": t,
		children: [/* @__PURE__ */ g("rect", {
			x: "2",
			y: "2",
			width: "44",
			height: "44",
			rx: "8",
			fill: "#fffdf5",
			stroke: "#715c43",
			strokeWidth: "2.5"
		}), (we[e] ?? []).map(([e, t], n) => /* @__PURE__ */ g("circle", {
			cx: e,
			cy: t,
			r: "3.5",
			fill: "#4b4b42"
		}, n))]
	});
}
function Te({ kind: e }) {
	let t = i().replace(/[^a-zA-Z0-9_-]/g, "");
	if (e === "beach") return /* @__PURE__ */ g(xe, {
		drawing: ge,
		viewBox: "0 0 800 560",
		className: "nm-event-art nm-beach-art"
	});
	let n;
	switch (e) {
		case "pool":
			n = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M0 85q30-15 60 0t60 0 60 0 60 0v45H0Z",
					fill: "#5faec1"
				}),
				/* @__PURE__ */ g("path", {
					d: "M0 104q30-12 60 0t60 0 60 0 60 0",
					fill: "none",
					stroke: "#e9f4ec",
					strokeWidth: "4"
				}),
				/* @__PURE__ */ g("path", {
					d: "M75 75V24m-41 0q41-36 82 0Z",
					fill: "#e6ac70",
					stroke: "#6c7a63",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("ellipse", {
					cx: "170",
					cy: "93",
					rx: "32",
					ry: "12",
					fill: "none",
					stroke: "#e5b94e",
					strokeWidth: "12"
				}),
				/* @__PURE__ */ g("path", {
					d: "m24 120 26-4",
					stroke: "#e3c995",
					strokeWidth: "10"
				})
			] });
			break;
		case "camp":
		case "base":
			n = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M0 99 38 58l20 40 29-62 28 63 50-42 45 42Z",
					fill: "#829568"
				}),
				/* @__PURE__ */ g("path", {
					d: "m68 112 49-81 61 81Z",
					fill: e === "base" ? "#a77b55" : "#dc975b",
					stroke: "#6e6651",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "m117 31 9 81H90Z",
					fill: "#525f58"
				}),
				/* @__PURE__ */ g("path", {
					d: "m55 117 13-20 14 20m-21 3 24-6",
					fill: "#e7b849",
					stroke: "#9f7456",
					strokeWidth: "3"
				})
			] });
			break;
		case "grandparents":
		case "family":
		case "abroad":
			n = /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("path", {
				d: "M0 103q58-47 120-11t120 1v37H0Z",
				fill: "#99ad7d"
			}), e === "abroad" ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("path", {
				d: "M136 112 151 30l16 82m-42-30h53m-62 30h70m-44-54h20",
				stroke: "#8e7869",
				strokeWidth: "5",
				fill: "none"
			}), /* @__PURE__ */ g("path", {
				d: "m41 38 55-9-28 20 3 16-8-1-9-16-22-4Z",
				fill: "#e4a35d"
			})] }) : /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M41 108V56h74v52",
					fill: "#f0c794",
					stroke: "#8c765c",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "m29 60 49-35 50 35Z",
					fill: "#a75e47"
				}),
				/* @__PURE__ */ g("path", {
					d: "M71 108V80h21v28m54 2V66h36v44",
					fill: "#9d8b71"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "171",
					cy: "55",
					r: "21",
					fill: "#82a36b"
				})
			] })] });
			break;
		case "video":
		case "tabletop":
			n = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("rect", {
					x: "55",
					y: "17",
					width: "131",
					height: "82",
					rx: "9",
					fill: "#6f786c",
					stroke: "#505b54",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("rect", {
					x: "63",
					y: "25",
					width: "115",
					height: "65",
					rx: "4",
					fill: "#b3ceab"
				}),
				e === "video" ? /* @__PURE__ */ _(h, { children: [
					/* @__PURE__ */ g("path", {
						d: "m82 76 16-25 15 12 24-29 20 42Z",
						fill: "#649789"
					}),
					/* @__PURE__ */ g("path", {
						d: "M65 103h111v16H65Z",
						fill: "#c4ae85"
					}),
					/* @__PURE__ */ g("path", {
						d: "m107 107-15 15m51-15 15 15",
						stroke: "#666956",
						strokeWidth: "5"
					})
				] }) : /* @__PURE__ */ _(h, { children: [
					/* @__PURE__ */ g("path", {
						d: "m79 67 35-31 41 28-39 22Z",
						fill: "#d8b262"
					}),
					/* @__PURE__ */ g("rect", {
						x: "82",
						y: "39",
						width: "28",
						height: "35",
						rx: "3",
						transform: "rotate(-14 82 39)",
						fill: "#f4e7c6",
						stroke: "#8d785b",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ g("circle", {
						cx: "149",
						cy: "51",
						r: "11",
						fill: "#aa654c"
					})
				] })
			] });
			break;
		case "bugs":
		case "explore":
			n = /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("path", {
				d: "M0 115 38 65l13 50 23-35 18 35 29-63 20 63 37-40 20 40Z",
				fill: "#87a467"
			}), e === "bugs" ? /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "m65 117 65-74",
					stroke: "#997351",
					strokeWidth: "6"
				}),
				/* @__PURE__ */ g("ellipse", {
					cx: "146",
					cy: "27",
					rx: "34",
					ry: "21",
					transform: "rotate(-35 146 27)",
					fill: "#e1e6ca",
					fillOpacity: ".7",
					stroke: "#758963",
					strokeWidth: "4"
				}),
				/* @__PURE__ */ g("ellipse", {
					cx: "72",
					cy: "38",
					rx: "8",
					ry: "13",
					fill: "#855c3e"
				}),
				/* @__PURE__ */ g("path", {
					d: "m65 28-8-7m20 8 8-8m-20 20-9 6m21-6 8 6",
					stroke: "#855c3e",
					strokeWidth: "2"
				})
			] }) : /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "m66 30 53 19 52-19v75l-52 16-53-16Z",
					fill: "#e7d09c",
					stroke: "#96815f",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "m119 49v72m17-53 20 26m-11-20-20 16",
					stroke: "#bd7c57",
					strokeWidth: "4"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "82",
					cy: "85",
					r: "21",
					fill: "#d8e8d8",
					fillOpacity: ".65",
					stroke: "#657c6b",
					strokeWidth: "5"
				}),
				/* @__PURE__ */ g("path", {
					d: "m96 100 18 19",
					stroke: "#657c6b",
					strokeWidth: "9"
				})
			] })] });
			break;
		case "fireworks":
		case "festival":
		case "park":
			n = /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("rect", {
				width: "240",
				height: "130",
				rx: "8",
				fill: "#4b5879"
			}), e === "park" ? /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("circle", {
					cx: "137",
					cy: "58",
					r: "44",
					fill: "none",
					stroke: "#e7cf80",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "m137 58-28 63m28-63 28 63m-70-63h84m-42-42v85m-30-72 60 60m0-60-60 60",
					stroke: "#d6c995",
					strokeWidth: "2"
				}),
				[
					0,
					1,
					2,
					3,
					4,
					5,
					6,
					7
				].map((e) => /* @__PURE__ */ g("circle", {
					cx: 137 + Math.cos(e * Math.PI / 4) * 44,
					cy: 58 + Math.sin(e * Math.PI / 4) * 44,
					r: "6",
					fill: e % 2 ? "#dc946c" : "#d4c878"
				}, e))
			] }) : e === "festival" ? /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M12 15q110 45 218 0",
					stroke: "#e5c287",
					strokeWidth: "3"
				}),
				[
					38,
					92,
					146,
					200
				].map((e, t) => /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("path", {
					d: `M${e} 29v12`,
					stroke: "#e5c287",
					strokeWidth: "3"
				}), /* @__PURE__ */ g("ellipse", {
					cx: e,
					cy: t % 2 ? 62 : 52,
					rx: "14",
					ry: "20",
					fill: t % 2 ? "#e6bf67" : "#d9876b"
				})] }, e)),
				/* @__PURE__ */ g("path", {
					d: "M47 119V92h142v27M35 92l20-17h126l20 17",
					fill: "#bc8b68",
					stroke: "#e7c58e",
					strokeWidth: "3"
				})
			] }) : /* @__PURE__ */ _(h, { children: [[
				[
					70,
					44,
					26
				],
				[
					170,
					68,
					34
				],
				[
					131,
					21,
					16
				]
			].map(([e, t, n], r) => /* @__PURE__ */ g("g", {
				stroke: r % 2 ? "#e7bc79" : "#da99a0",
				strokeWidth: "3",
				children: Array.from({ length: 10 }, (r, i) => /* @__PURE__ */ g("path", { d: `M${e + Math.cos(i * Math.PI / 5) * n * .4} ${t + Math.sin(i * Math.PI / 5) * n * .4}l${Math.cos(i * Math.PI / 5) * n * .6} ${Math.sin(i * Math.PI / 5) * n * .6}` }, i))
			}, r)), /* @__PURE__ */ g("path", {
				d: "M0 124V99h32v25H63V109h28v15h48V98h32v26h69",
				fill: "#303b57"
			})] })] });
			break;
		case "zoo":
			n = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M0 112q36-37 78-11t162-4v33H0Z",
					fill: "#96ac77"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "118",
					cy: "66",
					r: "45",
					fill: "#a77a48"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "118",
					cy: "67",
					r: "31",
					fill: "#dfb967"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "107",
					cy: "62",
					r: "3",
					fill: "#695d44"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "129",
					cy: "62",
					r: "3",
					fill: "#695d44"
				}),
				/* @__PURE__ */ g("path", {
					d: "m112 74 6 5 6-5m-6 5v9",
					fill: "none",
					stroke: "#695d44",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "M41 26v86m158-86v86M25 42h187",
					stroke: "#b8a784",
					strokeWidth: "6"
				})
			] });
			break;
		case "bbq":
			n = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "m75 115 17-43m74 43-19-43",
					stroke: "#686957",
					strokeWidth: "6"
				}),
				/* @__PURE__ */ g("path", {
					d: "M64 70h114q-4 40-57 40T64 70Z",
					fill: "#8b7961"
				}),
				/* @__PURE__ */ g("ellipse", {
					cx: "121",
					cy: "68",
					rx: "58",
					ry: "15",
					fill: "#c7b692",
					stroke: "#766e58",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "m79 62 8 12m11-19 9 24m10-25 9 26m10-25 8 23m10-19 8 14",
					stroke: "#827255",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ g("path", {
					d: "m90 35 4-14m26 17-3-25m28 22 5-15",
					stroke: "#b9ae93",
					strokeWidth: "3",
					strokeLinecap: "round"
				})
			] });
			break;
		case "sleepover":
			n = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("rect", {
					width: "240",
					height: "130",
					fill: "#555d7b",
					rx: "8"
				}),
				/* @__PURE__ */ g("path", {
					d: "M180 18a21 21 0 1 0 22 27 25 25 0 0 1-22-27Z",
					fill: "#e7d591"
				}),
				/* @__PURE__ */ g("path", {
					d: "M33 63h174v54H33Z",
					fill: "#e6d8bb",
					stroke: "#b6a989",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("rect", {
					x: "44",
					y: "70",
					width: "45",
					height: "22",
					rx: "8",
					fill: "#fff2d6"
				}),
				/* @__PURE__ */ g("rect", {
					x: "144",
					y: "70",
					width: "45",
					height: "22",
					rx: "8",
					fill: "#fff2d6"
				}),
				/* @__PURE__ */ g("path", {
					d: "M33 93h174v29H33Z",
					fill: "#a9b19a"
				})
			] });
			break;
		case "shopping":
		case "candy":
			n = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M47 48h146v72H47Z",
					fill: "#e6bf87",
					stroke: "#8e785e",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "M35 50 51 22h138l16 28Z",
					fill: "#bc7161"
				}),
				[
					59,
					99,
					139,
					179
				].map((e) => /* @__PURE__ */ g("path", {
					d: `M${e} 22v28`,
					stroke: "#f2dba8",
					strokeWidth: "18"
				}, e)),
				/* @__PURE__ */ g("rect", {
					x: "66",
					y: "67",
					width: "50",
					height: "35",
					fill: "#91aa91"
				}),
				/* @__PURE__ */ g("rect", {
					x: "137",
					y: "64",
					width: "33",
					height: "56",
					fill: "#967d65"
				}),
				e === "candy" && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("circle", {
					cx: "90",
					cy: "82",
					r: "11",
					fill: "#d4a9a0"
				}), /* @__PURE__ */ g("path", {
					d: "m76 82-9-8v16Zm28 0 9-8v16Z",
					fill: "#d4a9a0"
				})] })
			] });
			break;
		default: n = /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "m43 39 78 8 78-8v70l-78 9-78-9Z",
				fill: "#f6edcf",
				stroke: "#8c795f",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M121 47v71m-62-56 47 5m-47 12 47 5m30-17 47-5m-47 22 47-5",
				stroke: "#bbc4ac",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "m150 108 49-74 7 5-49 74Z",
				fill: "#d5a34a",
				stroke: "#8d7657",
				strokeWidth: "2"
			})
		] });
	}
	let r = [
		"fireworks",
		"festival",
		"sleepover",
		"park"
	].includes(e);
	return /* @__PURE__ */ _("svg", {
		className: "nm-event-art",
		viewBox: "0 0 240 168",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ g("pattern", {
				id: `${t}-wax`,
				width: "13",
				height: "11",
				patternUnits: "userSpaceOnUse",
				children: /* @__PURE__ */ _("g", {
					fill: "#fff8e4",
					opacity: ".35",
					children: [
						/* @__PURE__ */ g("circle", {
							cx: "2",
							cy: "3",
							r: ".6"
						}),
						/* @__PURE__ */ g("circle", {
							cx: "9",
							cy: "8",
							r: ".7"
						}),
						/* @__PURE__ */ g("path", {
							d: "m5 5 2-1m-5 5 2-1",
							stroke: "#fff8e4",
							strokeWidth: ".5"
						})
					]
				})
			}) }),
			/* @__PURE__ */ g("rect", {
				width: "240",
				height: "168",
				fill: r ? "#4b5879" : "#c8dbc3"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "203",
				cy: "26",
				r: "16",
				fill: "#e7c873"
			}),
			n,
			/* @__PURE__ */ g("path", {
				d: "M0 135q60-17 120 0t120 0v33H0Z",
				fill: r ? "#384761" : "#baca8f"
			}),
			/* @__PURE__ */ _("g", {
				transform: "translate(3 77) scale(.235)",
				children: [/* @__PURE__ */ g("path", {
					d: "m82 330 170 0",
					stroke: "#9eac6e",
					strokeWidth: "10"
				}), /* @__PURE__ */ g("g", { dangerouslySetInnerHTML: { __html: he[0].replaceAll("url(#tooth)", `url(#${t}-wax)`) } })]
			}),
			/* @__PURE__ */ g("g", {
				transform: "translate(210 78) scale(.225) translate(-1004 0)",
				dangerouslySetInnerHTML: { __html: he[3].replaceAll("url(#tooth)", `url(#${t}-wax)`) }
			}),
			/* @__PURE__ */ g("rect", {
				width: "240",
				height: "168",
				fill: `url(#${t}-wax)`
			})
		]
	});
}
//#endregion
//#region src/games/natsumemo/calendar.tsx
function Ee(e, t) {
	if (e.length <= t) return [e];
	let n = e.includes(" ") ? e.split(" ").flatMap((e) => e.length > t ? Array.from({ length: Math.ceil(e.length / t) }, (n, r) => e.slice(r * t, (r + 1) * t)) : [e]) : Array.from(e), r = [], i = "";
	for (let a of n) {
		let n = i + (i && e.includes(" ") ? " " : "") + a;
		n.length > t && i ? (r.push(i), i = a) : i = n;
	}
	return i && r.push(i), r;
}
function De({ calendar: e, week: t, viewingWeek: n, onWeek: i, legal: l, selected: d, proposed: f = null, days: p, onDay: m, rid: h, members: y }) {
	let b = u(), x = a(null), [S, te] = o({
		layout: "month",
		height: 710
	});
	r(() => {
		let e = x.current, t = e.closest(".nm-root"), n = new ResizeObserver(() => {
			let n = t.clientHeight < 610 || e.clientWidth < 680 ? "week" : "month", r = n === "week" ? 350 : Math.max(420, Math.min(710, 1260 * e.clientHeight / Math.max(1, e.clientWidth)));
			te((e) => e.layout === n && Math.abs(e.height - r) < 1 ? e : {
				layout: n,
				height: r
			});
		});
		return n.observe(e), n.observe(t), () => n.disconnect();
	}, []);
	let w = S.layout, E = w === "week", D = S.height, O = E ? 260 : (D - 103) / 4, k = O + 6, A = (e, t) => ({
		x: 83 + t * 158,
		y: 75 + (E ? 0 : e - 1) * k,
		w: 153,
		h: O
	}), j = Array.from({ length: E ? 7 : 28 }, (e, t) => ({
		week: E ? n : Math.floor(t / 7) + 1,
		day: t % 7
	}));
	return /* @__PURE__ */ _("div", {
		className: "nm-calendar-shell",
		children: [/* @__PURE__ */ g("nav", {
			className: "nm-week-tabs",
			"aria-label": b("games.natsumemo.calendar"),
			children: [
				1,
				2,
				3,
				4
			].map((e) => /* @__PURE__ */ g("button", {
				className: "nm-week-tab",
				type: "button",
				"aria-pressed": n === e,
				"data-current": t === e,
				style: { borderColor: ne[e - 1] },
				onClick: () => i(e),
				children: b("games.natsumemo.week", { n: e })
			}, e))
		}), /* @__PURE__ */ g("div", {
			className: "nm-calendar-canvas",
			ref: x,
			children: /* @__PURE__ */ _(ee, {
				sheetW: 1260,
				sheetH: D,
				fitKey: `${h}:${w}:${n}`,
				clampToSheet: !0,
				eligible: j.map(({ week: e, day: t }) => ({
					key: `${e}:${t}`,
					rect: A(e, t)
				})),
				highlight: "off",
				onTapEligible: (e) => {
					let [t, n] = e.split(":").map(Number);
					m(t, n);
				},
				children: [
					/* @__PURE__ */ g("rect", {
						x: "1",
						y: "1",
						width: 1258,
						height: D - 2,
						fill: "#fffcf3",
						stroke: "#beab8d",
						strokeWidth: "2"
					}),
					T.map((e, t) => /* @__PURE__ */ g("text", {
						x: 160 + t * 158,
						y: "49",
						textAnchor: "middle",
						fill: "#7b674e",
						fontSize: E ? 34 : 25,
						children: b(e)
					}, e)),
					(E ? [n] : [
						1,
						2,
						3,
						4
					]).map((e) => /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("path", {
						d: `M18 ${A(e, 0).y}l54 3v${O - 5}l-54 2Z`,
						fill: ne[e - 1]
					}), /* @__PURE__ */ g("text", {
						x: "45",
						y: A(e, 0).y + O / 2 + 16,
						fontSize: "43",
						fill: "#fff9e9",
						textAnchor: "middle",
						children: e
					})] }, e)),
					j.map(({ week: t, day: n }) => {
						let r = A(t, n), i = e[(t - 1) * 7 + n], a = b(i ? C[i.kind] : n === 2 ? "games.natsumemo.events.study" : "games.natsumemo.empty"), o = Ee(a, a.includes(" ") ? 11 : E ? 4 : 9), s = Math.min(E ? 32 : 23, (r.h - 20) / (o.length * 1.2));
						return /* @__PURE__ */ _("g", { children: [
							/* @__PURE__ */ g("rect", {
								x: r.x,
								y: r.y,
								width: r.w,
								height: r.h,
								rx: "2",
								fill: n === 2 ? "#eff3e9" : "#fffdf6",
								stroke: "#bbaa8a",
								strokeWidth: "1.5"
							}),
							!i && n === 2 && o.map((e, t) => /* @__PURE__ */ g("text", {
								x: r.x + r.w / 2,
								y: r.y + r.h / 2 + (t - (o.length - 1) / 2) * s * 1.2 + s * .35,
								textAnchor: "middle",
								fontSize: s,
								fill: "#a3ad93",
								children: e
							}, t)),
							/* @__PURE__ */ g(v, {
								name: `day:${h}:${t}:${n}`,
								r
							})
						] }, `${t}:${n}`);
					}),
					j.map(({ week: t, day: n }) => {
						let r = e[(t - 1) * 7 + n];
						if (!r || n !== r.start) return null;
						let i = A(t, n), a = 158 * r.days - 5, o = b(C[r.kind]), l = Ee(o, o.includes(" ") ? r.days > 1 ? 30 : 11 : r.days > 1 ? E ? 10 : 20 : E ? 4 : 8), u = Math.min(E ? 35 : 23, (i.h - (E ? 110 : 42)) / (l.length * 1.1)), d = r.kind === "homework" ? "#85704e" : "#397e80", f = r.kind === "homework" ? "#eee7cb" : "#d7e9df";
						return /* @__PURE__ */ _("g", {
							pointerEvents: "none",
							children: [
								/* @__PURE__ */ g("rect", {
									x: i.x + 5,
									y: i.y + 7,
									width: a - 10,
									height: i.h - 14,
									fill: f,
									stroke: d,
									strokeWidth: "2"
								}),
								/* @__PURE__ */ g("path", {
									d: `M${i.x + 14} ${i.y + i.h - 13}q${a * .35} -4 ${a - 28} 0`,
									fill: "none",
									stroke: d,
									strokeWidth: "5",
									opacity: ".55"
								}),
								l.map((e, t) => /* @__PURE__ */ g("text", {
									x: i.x + a / 2,
									y: i.y + (E ? 22 : 14) + u + t * u * 1.1,
									textAnchor: "middle",
									fontSize: u,
									fill: d,
									children: e
								}, t)),
								(i.h > 110 || l.length === 1) && r.members.slice(0, Math.min(r.days * 2, 4)).map((e, t) => /* @__PURE__ */ g("image", {
									href: s(c[(y.find((t) => t.rid === e)?.avatar ?? 6) % c.length]),
									x: i.x + 14 + t * (E ? 40 : 27),
									y: i.y + i.h - (E ? 97 : i.h > 110 ? 62 : 35),
									width: E ? 36 : 23,
									height: E ? 36 : 23
								}, e)),
								/* @__PURE__ */ g("text", {
									x: i.x + a - 16,
									y: i.y + i.h - (E ? 25 : i.h > 110 ? 17 : 10),
									fontSize: E ? 44 : i.h > 110 ? 28 : 18,
									fill: d,
									textAnchor: "end",
									children: r.points
								})
							]
						}, `entry:${t}:${n}`);
					}),
					d !== null && (!E || n === t) && /* @__PURE__ */ g("rect", {
						x: A(t, d).x + 4,
						y: A(t, d).y + 5,
						width: p * 158 - 13,
						height: O - 10,
						fill: "#90c5be",
						fillOpacity: ".3",
						stroke: "#397c73",
						strokeWidth: "4",
						pointerEvents: "none"
					}),
					f !== null && (!E || n === t) && /* @__PURE__ */ _("g", {
						className: "nm-proposal-range",
						pointerEvents: "none",
						children: [/* @__PURE__ */ g("rect", {
							x: A(t, f).x + 4,
							y: A(t, f).y + 5,
							width: p * 158 - 13,
							height: O - 10,
							fill: "#e7c873",
							fillOpacity: ".15",
							stroke: "#9e712c",
							strokeWidth: "5",
							strokeDasharray: "12 6"
						}), /* @__PURE__ */ g("path", {
							d: `M${A(t, f).x + 12} ${A(t, f).y + 12}h${p * 158 - 29}`,
							stroke: "#9e712c",
							strokeWidth: "8"
						})]
					}),
					j.map(({ week: n, day: r }) => {
						let i = A(n, r), a = e[(n - 1) * 7 + r], o = b(a ? C[a.kind] : "games.natsumemo.empty"), s = n === t && l.includes(r);
						return /* @__PURE__ */ _("g", { children: [s && /* @__PURE__ */ g("rect", {
							x: i.x + 5,
							y: i.y + 5,
							width: i.w - 10,
							height: i.h - 10,
							fill: "none",
							stroke: "#397c73",
							strokeWidth: "3",
							strokeDasharray: "12 9",
							pointerEvents: "none",
							children: /* @__PURE__ */ g("animate", {
								attributeName: "stroke-dashoffset",
								from: "0",
								to: "-42",
								dur: "1s",
								repeatCount: "indefinite"
							})
						}), /* @__PURE__ */ g("rect", {
							x: i.x,
							y: i.y,
							width: i.w,
							height: i.h,
							fill: "transparent",
							role: "button",
							tabIndex: 0,
							"aria-label": `${b("games.natsumemo.week", { n })} ${b(T[r])}: ${a ? b("games.natsumemo.entry", {
								name: o,
								n: a.points
							}) : o}${f !== null && n === t && r >= f && r < f + p ? `, ${b("games.natsumemo.proposedDay")}` : ""}`,
							onKeyDown: (e) => {
								(e.key === "Enter" || e.key === " ") && (e.preventDefault(), m(n, r));
							}
						})] }, `hit:${n}:${r}`);
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/games/natsumemo/card.tsx
var Oe = {
	parity: "games.natsumemo.parity",
	gender: "games.natsumemo.gender",
	balanced: "games.natsumemo.balanced",
	two: "games.natsumemo.two"
};
function ke({ card: e }) {
	let t = u(), { ref: n } = f("event-card"), r, i = Oe[e.mode];
	r = i ? t(i, {
		a: e.values[0],
		b: e.values[1]
	}) : e.mode === "fixed" ? e.pages ? t("games.natsumemo.fixedPages", {
		n: e.values[0],
		pages: e.pages
	}) : t("games.natsumemo.fixed", { n: e.values[0] }) : e.mode === "base" ? t("games.natsumemo.baseScore") : e.mode === "candy" ? t("games.natsumemo.candyScore") : e.mode === "bugs" ? t(e.week === 2 ? "games.natsumemo.bugs2" : "games.natsumemo.bugs4") : t("games.natsumemo.contest", {
		a: e.values[0],
		b: e.values[1],
		c: e.values[2]
	});
	let a = e.mode === "gender" ? ["sameGender", "mixedGender"] : e.mode === "parity" ? ["evenGroup", "oddGroup"] : e.mode === "balanced" ? ["balancedGroup", "unbalancedGroup"] : e.mode === "two" ? ["twoGroup", "largerGroup"] : e.mode === "video" || e.mode === "tabletop" ? [
		"uniqueFirst",
		"tiedFirst",
		"remaining"
	] : null;
	return /* @__PURE__ */ _("article", {
		ref: n,
		className: "nm-event-card",
		children: [
			/* @__PURE__ */ _("header", { children: [
				/* @__PURE__ */ g("span", {
					style: { background: ne[e.week - 1] },
					children: t("games.natsumemo.week", { n: e.week })
				}),
				/* @__PURE__ */ g("b", { children: t("games.natsumemo.day", { n: e.days }) }),
				/* @__PURE__ */ g("span", {
					className: "nm-card-hearts",
					children: Array.from({ length: e.hearts }, (e, t) => /* @__PURE__ */ g(X, {}, t))
				})
			] }),
			/* @__PURE__ */ g("h2", { children: t(C[e.kind]) }),
			/* @__PURE__ */ g(Te, { kind: e.kind }),
			/* @__PURE__ */ _("div", {
				className: "nm-card-rules",
				children: [
					a ? /* @__PURE__ */ g("dl", {
						className: "nm-score-rows",
						children: a.map((n, r) => /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: t(`games.natsumemo.${n}`) }), /* @__PURE__ */ g("dd", { children: t("games.natsumemo.points", { n: e.values[r] }) })] }, n))
					}) : /* @__PURE__ */ g("p", { children: r }),
					(e.mode === "video" || e.mode === "tabletop") && /* @__PURE__ */ g("p", {
						className: "nm-card-note",
						children: t(e.mode === "video" ? "games.natsumemo.randomDice" : "games.natsumemo.secretDice")
					}),
					e.mode === "fixed" ? /* @__PURE__ */ _("p", {
						className: "nm-card-title",
						children: [/* @__PURE__ */ g(Ce, {}), t("games.natsumemo.titleAward", { title: t(w[e.title]) })]
					}) : /* @__PURE__ */ _("div", {
						className: "nm-card-solo",
						children: [/* @__PURE__ */ g("span", { children: t("games.natsumemo.solo") }), /* @__PURE__ */ _("p", { children: [/* @__PURE__ */ g(Ce, {}), t(e.mode === "base" || e.mode === "bugs" ? "games.natsumemo.soloSame" : "games.natsumemo.soloScore", {
							n: e.solo,
							title: t(w[e.title])
						})] })]
					}),
					!!e.pages && /* @__PURE__ */ _("span", {
						className: "nm-card-pages",
						children: [/* @__PURE__ */ g(Z, {}), /* @__PURE__ */ _("b", { children: ["+", e.pages] })]
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/natsumemo/view-player.tsx
function Ae(e) {
	return /* @__PURE__ */ g(je, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function je({ pub: e, priv: t, members: n, myRid: r, send: i, readOnly: a = !1 }) {
	let { ref: s } = f("secret-paper"), { ref: d } = f("homework-die"), v = u(), [ee, y] = o(r), [b, x] = o({
		current: e.week,
		view: e.week
	}), [S, te] = o({
		scope: "",
		start: null,
		die: 1,
		hearts: []
	}), [E, D] = o(null), [k, A] = o(null), j = E === r, M = k?.owner === r ? k.entry : null, N = (e) => D(e ? r : null), P = (e) => A(e ? {
		owner: r,
		entry: e
	} : null), F = `${r}:${e.week}:${e.invitation}:${e.phase}`, I = S.scope === F ? S : {
		scope: F,
		start: null,
		die: 1,
		hearts: []
	}, L = (e) => te({
		...I,
		...e,
		scope: F
	}), R = e.players.some((e) => e.rid === ee) || ee === "$transfer" ? ee : r, z = e.players.find((e) => e.rid === r), B = R === "$transfer" ? {
		rid: "$transfer",
		calendar: e.transferCalendar,
		titles: [],
		points: 0
	} : e.players.find((e) => e.rid === R) ?? e.players[0], H = e.card ? O(e.card) : null, re = b.current === e.week ? b.view : e.week, U = B.rid === r, W = !a && e.phase === "schedule" && e.proposer === r && U, G = W && H ? V(B.calendar, e.week, H.days) : [], K = I.start !== null && G.includes(I.start) ? I.start : null, q = (t) => t === "$transfer" ? v("games.natsumemo.transferDiary") : t === "$transfer-boy" ? v("games.natsumemo.transferBoy") : t === "$transfer-girl" ? v("games.natsumemo.transferGirl") : n.find((e) => e.rid === t)?.name.trim() || v(l[(e.players.findIndex((e) => e.rid === t) + l.length) % l.length].nameKey), ie = z?.calendar.slice((e.week - 1) * 7, e.week * 7).findIndex((e) => e === null) ?? -1, J;
	J = a ? v("games.natsumemo.review") : e.phase === "characters" ? z?.gender === null ? v("games.natsumemo.characterPrompt") : v("games.natsumemo.waiting") : e.phase === "schedule" ? e.proposer === r ? v("games.natsumemo.schedulePrompt") : v("games.natsumemo.scheduleWait", { name: q(e.proposer) }) : e.phase === "attend" ? z?.ready ? t?.choice?.yes === !1 && H && e.start !== null && !V(z.calendar, e.week, H.days).includes(e.start) ? v("games.natsumemo.busy") : v("games.natsumemo.waiting") : v("games.natsumemo.attendPrompt") : e.phase === "reveal" ? v("games.natsumemo.revealPrompt") : e.phase === "hearts" ? t && !t.allocated ? v("games.natsumemo.heartsPrompt", { n: t.heartCount }) : v("games.natsumemo.heartsWait") : e.phase === "homework" ? v(ie >= 0 ? "games.natsumemo.homeworkPrompt" : "games.natsumemo.homeworkWait") : e.phase === "weekEnd" ? v("games.natsumemo.weekEndPrompt") : v(e.phase === "study" ? "games.natsumemo.studyPrompt" : "games.natsumemo.settlePrompt");
	let Y = I.hearts.filter((e) => t?.targets.includes(e));
	return /* @__PURE__ */ _("div", {
		className: "nm-root",
		style: { "--nm-week": ne[e.week - 1] },
		children: [
			/* @__PURE__ */ g(m, {
				adaptive: !0,
				scroll: !1,
				className: "nm-screen",
				banner: /* @__PURE__ */ g("div", {
					className: "nm-top",
					children: /* @__PURE__ */ _("header", {
						className: "nm-masthead",
						children: [
							/* @__PURE__ */ g("strong", { children: v("games.natsumemo.diary") }),
							/* @__PURE__ */ g("span", {
								className: "nm-current-week",
								children: v("games.natsumemo.week", { n: e.week })
							}, e.week),
							/* @__PURE__ */ g("span", { children: v("games.natsumemo.invitation", { n: Math.min(e.invitation + 1, 6) }) }),
							!a && /* @__PURE__ */ _("button", {
								ref: s,
								className: "nm-secret-tab",
								onClick: () => N(!j),
								children: [/* @__PURE__ */ g(Z, {}), v("games.natsumemo.secret")]
							})
						]
					})
				}),
				children: /* @__PURE__ */ _("div", {
					className: "nm-desk",
					children: [/* @__PURE__ */ _("div", {
						className: "nm-main-scene",
						children: [/* @__PURE__ */ _("section", {
							className: "nm-gathering",
							"aria-label": v("games.natsumemo.gathering"),
							children: [
								/* @__PURE__ */ g("div", {
									className: "nm-invitation-note",
									children: H ? /* @__PURE__ */ _(h, { children: [
										/* @__PURE__ */ g("strong", {
											title: v("games.natsumemo.proposalBy", { name: q(e.proposer) }),
											children: v("games.natsumemo.proposalBy", { name: q(e.proposer) })
										}),
										/* @__PURE__ */ g("span", { children: v(C[H.kind]) }),
										e.start !== null && /* @__PURE__ */ g("span", {
											className: "nm-proposal-date",
											children: v("games.natsumemo.dates", {
												from: v(T[e.start]),
												to: v(T[e.start + H.days - 1])
											})
										})
									] }) : /* @__PURE__ */ g("span", { children: v(a ? "games.natsumemo.review" : e.phase === "characters" ? "games.natsumemo.characterPrompt" : e.phase === "weekEnd" ? "games.natsumemo.weekEndPrompt" : e.phase === "homework" ? "games.natsumemo.events.homework" : "games.natsumemo.events.study") })
								}),
								/* @__PURE__ */ g("div", {
									className: "nm-children",
									children: e.players.map((t, o) => {
										let s = ![
											"characters",
											"schedule",
											"attend"
										].includes(e.phase), c = s && e.participants.includes(t.rid), u = !a && e.phase === "attend" && t.rid === r && !t.ready, d = e.phase === "attend" ? t.ready ? v("games.natsumemo.sealed") : v("games.natsumemo.considering") : s && e.participants.length ? v(c ? "games.natsumemo.attending" : "games.natsumemo.notAttending") : t.rid === e.proposer && H ? v("games.natsumemo.proposer") : t.gender ? v(t.gender === "boy" ? "games.natsumemo.boy" : "games.natsumemo.girl") : "";
										return /* @__PURE__ */ _("div", {
											className: "nm-child-seat",
											"data-attended": c,
											children: [/* @__PURE__ */ _("button", {
												className: "nm-child-choice",
												"aria-label": u ? v("games.natsumemo.attend") : v("games.natsumemo.viewCalendar", { name: q(t.rid) }),
												onClick: () => {
													u ? i({
														type: "attend",
														yes: !0,
														die: I.die
													}) : (y(t.rid), P(null));
												},
												children: [/* @__PURE__ */ g(Se, {
													variant: o,
													gender: t.gender,
													raised: c,
													standing: !!H && e.proposer === t.rid
												}), e.phase === "attend" && t.ready && /* @__PURE__ */ g("span", {
													className: "nm-sealed-note",
													children: /* @__PURE__ */ g(Z, { size: 17 })
												})]
											}), /* @__PURE__ */ g(Me, {
												rid: t.rid,
												avatar: n.find((e) => e.rid === t.rid)?.avatar ?? o,
												name: q(t.rid),
												color: l[(n.find((e) => e.rid === t.rid)?.colorIndex ?? o) % l.length].hex,
												points: t.points,
												status: d,
												selected: t.rid === R,
												onClick: () => {
													y(t.rid), P(null);
												}
											})]
										}, t.rid);
									})
								}),
								e.transferStudents && /* @__PURE__ */ _("button", {
									className: "nm-transfer-diary",
									"aria-pressed": R === "$transfer",
									onClick: () => {
										y("$transfer"), P(null);
									},
									children: [
										/* @__PURE__ */ g(Z, { size: 17 }),
										v("games.natsumemo.transferDiary"),
										e.transferDie !== null && /* @__PURE__ */ g(Q, {
											value: e.transferDie,
											label: v("games.natsumemo.die", { n: e.transferDie })
										})
									]
								})
							]
						}), /* @__PURE__ */ _("section", {
							className: "nm-diary-page",
							children: [
								/* @__PURE__ */ _("div", {
									className: "nm-page-label",
									children: [/* @__PURE__ */ _("span", { children: [
										q(B.rid),
										" · ",
										v("games.natsumemo.calendar")
									] }), !U && !a && /* @__PURE__ */ g("button", {
										onClick: () => y(r),
										children: v("games.natsumemo.viewMine")
									})]
								}),
								/* @__PURE__ */ g(De, {
									calendar: B.calendar,
									week: e.week,
									viewingWeek: re,
									onWeek: (t) => x({
										current: e.week,
										view: t
									}),
									legal: G,
									selected: K,
									proposed: H ? e.start : null,
									days: H?.days ?? 1,
									rid: B.rid,
									members: n,
									onDay: (t, n) => {
										if (t === e.week && G.includes(n)) {
											L({ start: n });
											return;
										}
										let r = B.calendar[(t - 1) * 7 + n];
										r && P(r);
									}
								}),
								/* @__PURE__ */ g("div", {
									className: "nm-calendar-confirm",
									children: !a && W && K !== null && H ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", { children: v("games.natsumemo.dates", {
										from: v(T[K]),
										to: v(T[K + H.days - 1])
									}) }), /* @__PURE__ */ g("button", {
										className: "nm-button",
										onClick: () => i({
											type: "schedule",
											start: K
										}),
										children: v("games.natsumemo.confirmSchedule")
									})] }) : H && e.start !== null && /* @__PURE__ */ g("span", {
										className: "nm-proposed-dates",
										children: v("games.natsumemo.proposedDates", {
											week: e.week,
											from: v(T[e.start]),
											to: v(T[e.start + H.days - 1])
										})
									})
								}),
								/* @__PURE__ */ _("div", {
									className: "nm-title-ribbon",
									children: [/* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Ce, {}), v("games.natsumemo.titleCount", { n: B.titles.length })] }), /* @__PURE__ */ g("div", {
										tabIndex: 0,
										role: "region",
										"aria-label": v("games.natsumemo.titleCount", { n: B.titles.length }),
										children: B.titles.length ? B.titles.map((e) => /* @__PURE__ */ g("span", { children: v(w[e]) }, e)) : /* @__PURE__ */ g("span", {
											className: "nm-muted",
											children: v("games.natsumemo.noTitles")
										})
									})]
								})
							]
						})]
					}), /* @__PURE__ */ g("aside", {
						className: "nm-current",
						children: /* @__PURE__ */ _("div", {
							className: "nm-current-scroll",
							children: [H ? /* @__PURE__ */ g(ke, { card: H }) : e.phase === "characters" ? /* @__PURE__ */ _("div", {
								className: "nm-study-card nm-character-card",
								children: [/* @__PURE__ */ g(Se, { gender: "girl" }), /* @__PURE__ */ g(Se, { gender: "boy" })]
							}) : /* @__PURE__ */ _("div", {
								className: "nm-study-card",
								children: [
									/* @__PURE__ */ g(Te, { kind: e.phase === "homework" ? "homework" : "study" }),
									/* @__PURE__ */ g("h2", { children: v(e.phase === "homework" ? "games.natsumemo.events.homework" : "games.natsumemo.events.study") }),
									t && /* @__PURE__ */ _("p", { children: [/* @__PURE__ */ g(Z, {}), v("games.natsumemo.pages", { n: t.pages })] })
								]
							}), /* @__PURE__ */ _("div", {
								className: "nm-decision",
								"aria-live": "polite",
								children: [
									/* @__PURE__ */ g("p", {
										className: "nm-prompt",
										children: J
									}),
									!a && e.phase === "characters" && z?.gender === null && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("div", {
										className: "nm-choice-row",
										children: ["boy", "girl"].map((e) => /* @__PURE__ */ g("button", {
											className: "nm-button",
											onClick: () => i({
												type: "character",
												gender: e
											}),
											children: v(e === "boy" ? "games.natsumemo.boy" : "games.natsumemo.girl")
										}, e))
									}), /* @__PURE__ */ g("small", { children: v("games.natsumemo.characterNote") })] }),
									!a && e.phase === "schedule" && e.proposer === r && /* @__PURE__ */ g(h, { children: U && G.length === 0 ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("p", { children: v("games.natsumemo.noSpace") }), /* @__PURE__ */ g("button", {
										className: "nm-button",
										onClick: () => i({ type: "skip" }),
										children: v("games.natsumemo.skip")
									})] }) : U ? null : /* @__PURE__ */ g("button", {
										className: "nm-button",
										onClick: () => y(r),
										children: v("games.natsumemo.viewMine")
									}) }),
									!a && e.phase === "attend" && !z?.ready && /* @__PURE__ */ _(h, { children: [H?.mode === "tabletop" && /* @__PURE__ */ _("fieldset", {
										className: "nm-dice-choices",
										children: [/* @__PURE__ */ g("legend", { children: v("games.natsumemo.chooseDie") }), [
											1,
											2,
											3,
											4,
											5,
											6
										].map((e) => /* @__PURE__ */ g("button", {
											"aria-pressed": I.die === e,
											onClick: () => L({ die: e }),
											children: /* @__PURE__ */ g(Q, {
												value: e,
												label: v("games.natsumemo.die", { n: e })
											})
										}, e))]
									}), /* @__PURE__ */ _("div", {
										className: "nm-choice-row",
										children: [/* @__PURE__ */ g("button", {
											className: "nm-button",
											onClick: () => i({
												type: "attend",
												yes: !0,
												die: I.die
											}),
											children: v("games.natsumemo.attend")
										}), /* @__PURE__ */ g("button", {
											className: "nm-button nm-quiet",
											onClick: () => i({
												type: "attend",
												yes: !1
											}),
											children: v("games.natsumemo.decline")
										})]
									})] }),
									!!e.transferDie && /* @__PURE__ */ g("p", {
										className: "nm-transfer-note",
										children: v("games.natsumemo.transferRoll", { n: e.transferDie })
									}),
									e.participants.length > 0 && /* @__PURE__ */ g("div", {
										className: "nm-attendees",
										children: e.participants.map((t) => /* @__PURE__ */ _("span", { children: [
											q(t),
											" ",
											e.dice[t] && /* @__PURE__ */ g(Q, {
												value: e.dice[t],
												label: v("games.natsumemo.die", { n: e.dice[t] })
											}),
											" ",
											e.gains[t] !== void 0 && /* @__PURE__ */ _("b", { children: ["+", e.gains[t]] })
										] }, t))
									}),
									!a && e.phase === "hearts" && t && !t.allocated && /* @__PURE__ */ _(h, { children: [
										/* @__PURE__ */ g("div", {
											className: "nm-heart-targets",
											children: t.targets.map((r) => /* @__PURE__ */ g(Ne, {
												rid: r,
												avatar: (n.find((e) => e.rid === r)?.avatar ?? Math.max(0, e.players.findIndex((e) => e.rid === r))) % c.length,
												name: q(r),
												count: Y.filter((e) => e === r).length,
												onClick: () => {
													Y.length < t.heartCount && L({ hearts: [...Y, r] });
												}
											}, r))
										}),
										/* @__PURE__ */ g("p", { children: v("games.natsumemo.heartCount", {
											n: Y.length,
											total: t.heartCount
										}) }),
										/* @__PURE__ */ _("div", {
											className: "nm-choice-row",
											children: [/* @__PURE__ */ g("button", {
												className: "nm-button",
												disabled: Y.length !== t.heartCount,
												onClick: () => i({
													type: "hearts",
													targets: Y
												}),
												children: v("games.natsumemo.sendHearts")
											}), /* @__PURE__ */ g("button", {
												className: "nm-button nm-quiet",
												onClick: () => L({ hearts: [] }),
												children: v("games.natsumemo.reset")
											})]
										})
									] }),
									!a && e.phase === "homework" && ie >= 0 && /* @__PURE__ */ _("button", {
										ref: d,
										className: "nm-roll-button",
										onClick: () => i({ type: "homework" }),
										children: [/* @__PURE__ */ g(Q, {
											value: t?.lastHomework?.die ?? 1,
											label: v("games.natsumemo.roll")
										}), /* @__PURE__ */ g("span", { children: v("games.natsumemo.roll") })]
									}),
									!a && t?.lastHomework && e.phase === "homework" && /* @__PURE__ */ g("p", {
										className: "nm-roll-result",
										children: v("games.natsumemo.homeworkResult", {
											day: v(T[t.lastHomework.day]),
											die: t.lastHomework.die,
											pages: t.lastHomework.pages,
											points: t.lastHomework.points
										})
									}),
									!a && e.phase === "weekEnd" && !z?.ready && /* @__PURE__ */ g("button", {
										className: "nm-button",
										onClick: () => i({ type: "next" }),
										children: v(e.week === 4 ? "games.natsumemo.finish" : "games.natsumemo.nextWeek")
									})
								]
							})]
						})
					})]
				})
			}),
			j && t && /* @__PURE__ */ g("div", {
				className: "nm-modal-backdrop",
				onClick: () => N(!1),
				children: /* @__PURE__ */ _("section", {
					className: "nm-secret-sheet",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": v("games.natsumemo.secret"),
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ _("header", { children: [/* @__PURE__ */ g("h2", { children: v("games.natsumemo.secret") }), /* @__PURE__ */ g("button", {
							onClick: () => N(!1),
							"aria-label": v("games.natsumemo.close"),
							children: /* @__PURE__ */ g(p, { size: 24 })
						})] }),
						/* @__PURE__ */ _("h3", { children: [/* @__PURE__ */ g(Z, {}), v("games.natsumemo.pages", { n: t.pages })] }),
						/* @__PURE__ */ g("div", {
							className: "nm-homework-track",
							children: Array.from({ length: 30 }, (e, n) => /* @__PURE__ */ g("span", {
								"data-filled": n < t.pages,
								"data-bonus": n >= 25,
								title: v("games.natsumemo.pageLabel", { n: n + 1 }),
								children: n < t.pages ? "✓" : n + 1
							}, n))
						}),
						/* @__PURE__ */ _("h3", { children: [/* @__PURE__ */ g(X, {}), v("games.natsumemo.friendship")] }),
						[...e.players.map((e) => e.rid), ...e.transferStudents ? ["$transfer-boy", "$transfer-girl"] : []].filter((e) => e !== r).map((e) => /* @__PURE__ */ _("p", {
							className: "nm-affection-row",
							children: [/* @__PURE__ */ g("span", { children: q(e) }), /* @__PURE__ */ g("span", { children: Array.from({ length: 10 }, (n, r) => /* @__PURE__ */ g("i", {
								"data-filled": r < (t.hearts[e] ?? 0),
								children: /* @__PURE__ */ g(X, { size: 16 })
							}, r)) })]
						}, e))
					]
				})
			}),
			M && /* @__PURE__ */ g("div", {
				className: "nm-modal-backdrop",
				onClick: () => P(null),
				children: /* @__PURE__ */ _("section", {
					className: "nm-detail-sheet",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": v("games.natsumemo.detail"),
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ _("header", { children: [/* @__PURE__ */ g("h2", { children: v(C[M.kind]) }), /* @__PURE__ */ g("button", {
							onClick: () => P(null),
							"aria-label": v("games.natsumemo.close"),
							children: /* @__PURE__ */ g(p, { size: 24 })
						})] }),
						/* @__PURE__ */ g(Te, { kind: M.kind }),
						/* @__PURE__ */ _("p", { children: [
							v("games.natsumemo.week", { n: M.week }),
							" · ",
							v("games.natsumemo.dates", {
								from: v(T[M.start]),
								to: v(T[M.start + M.days - 1])
							})
						] }),
						/* @__PURE__ */ g("strong", { children: v("games.natsumemo.points", { n: M.points }) }),
						/* @__PURE__ */ g("p", { children: M.members.map(q).join(" · ") })
					]
				})
			})
		]
	});
}
function Me({ rid: e, avatar: t, name: n, color: r, points: i, status: a, selected: o, onClick: l }) {
	let { ref: u } = f(`seat:${e}`);
	return /* @__PURE__ */ _("button", {
		ref: u,
		className: "nm-player-tab",
		"aria-pressed": o,
		onClick: l,
		style: { "--nm-player": r },
		children: [
			/* @__PURE__ */ g("img", {
				src: s(c[t % c.length]),
				alt: ""
			}),
			/* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g("strong", { children: n }), /* @__PURE__ */ g("small", { children: a })] }),
			/* @__PURE__ */ g("b", { children: /* @__PURE__ */ g(d, { value: i }) })
		]
	});
}
function Ne({ rid: e, avatar: t, name: n, count: r, onClick: i }) {
	let { ref: a } = f(`heart:${e}`);
	return /* @__PURE__ */ _("button", {
		ref: a,
		className: "nm-heart-target",
		onClick: i,
		children: [
			/* @__PURE__ */ g("img", {
				src: s(c[t]),
				alt: ""
			}),
			/* @__PURE__ */ g("span", { children: n }),
			/* @__PURE__ */ g(X, {}),
			/* @__PURE__ */ g("b", { children: /* @__PURE__ */ g(d, { value: r }) })
		]
	});
}
//#endregion
//#region src/games/natsumemo/bot.ts
var Pe = {
	homework: 1,
	titles: 1,
	friendship: 1,
	fragmentation: .35,
	futureEvents: .4,
	attendance: .62,
	rivals: 2,
	exactGroups: !0,
	forecast: !0,
	contest: !0,
	dice: !0,
	opportunities: 1
}, Fe = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967296, $ = (e) => e.filter((e, t) => !!e && t % 7 === e.start), Ie = (e, t, n) => Math.max(t, Math.min(n, e)), Le = (e, t) => (1 << t) - 1 << e;
function Re(e, t, n, r) {
	let i = D.filter((t) => t.week === e.week && !n.has(t.id)), a = 5 - e.invitation;
	if (!i.length || a <= 0) return () => 0;
	let o = e.players.findIndex((t) => t.rid === e.proposer), s = e.players.find((e) => e.rid === t), c = Array.from({ length: a }, (t, n) => e.players[(o + n + 1) % e.players.length]), l = i.map((t) => ({
		placements: V(s.calendar, e.week, t.days).map((e) => ({
			start: e,
			mask: Le(e, t.days),
			value: r(t, e)
		})),
		hostStarts: c.map((n) => V(n.calendar, e.week, t.days))
	})), u = /* @__PURE__ */ new Map(), d = (e, n) => {
		if (n === a) return 0;
		let r = n * 128 + e, i = u.get(r);
		if (i !== void 0) return i;
		let o = d(e, n + 1), s = c[n], f = 0;
		for (let r of l) {
			let i = s.rid === t ? r.placements.filter((t) => !(e & t.mask)) : r.placements.filter((e) => r.hostStarts[n].includes(e.start)), a = s.rid === t ? i.length : r.hostStarts[n].length;
			if (!a) {
				f += o;
				continue;
			}
			let c = i.map((t) => e & t.mask ? o : Math.max(o, t.value + d(e | t.mask, n + 1)));
			f += s.rid === t ? Math.max(...c) : (c.reduce((e, t) => e + t, 0) + (a - i.length) * o) / a;
		}
		let p = f / l.length;
		return u.set(r, p), p;
	};
	return (e) => d(e, 0);
}
function ze(e, t, n, r, i, a) {
	let o = e.public, s = e.private, c = o.players.find((e) => e.rid === t), l = /* @__PURE__ */ new Float64Array(124);
	l[Math.min(30, s.pages + (r?.pages ?? 0)) * 4] = 1;
	let u = 0;
	for (let e = o.week; e <= 4; e++) for (let a = 0; a < 7; a++) {
		if (c.calendar[(e - 1) * 7 + a] || e === o.week && n !== null && r && a >= n && a < n + r.days) continue;
		let s = e === o.week ? Math.min(1, Math.max(0, 5 - o.invitation) / 3) : 1, d = 1 - i.futureEvents * s, f;
		if (a === 2) {
			let n = o.players.some((n) => n.rid !== t && !n.calendar[(e - 1) * 7 + 2]) || o.transferStudents && !o.transferCalendar[(e - 1) * 7 + 2];
			f = [[
				n ? e === 4 ? 3 : 2 : e === 4 ? 4 : 3,
				d,
				0
			], [
				0,
				1 - d,
				0
			]], u += n ? d * (e === 4 ? 2 : 3) : 0;
		} else f = e === 4 ? [
			[
				0,
				1 - d,
				0
			],
			[
				0,
				d / 3,
				2
			],
			[
				3,
				d / 2,
				0
			],
			[
				4,
				d / 6,
				0
			]
		] : [
			[
				0,
				1 - d,
				0
			],
			[
				0,
				d / 6,
				1
			],
			[
				2,
				d * 2 / 3,
				0
			],
			[
				3,
				d / 6,
				0
			]
		], u += d * (e === 4 ? 5 / 3 : .5);
		let p = /* @__PURE__ */ new Float64Array(124);
		for (let e = 0; e <= 30; e++) for (let t = 0; t < 4; t++) if (l[e * 4 + t]) for (let [n, r, i] of f) p[Math.min(30, e + n) * 4 + (t | i)] += l[e * 4 + t] * r;
		l = p;
	}
	let d = u;
	for (let e = 0; e <= 30; e++) for (let t = 0; t < 4; t++) {
		let n = c.titles.length + (a && !c.titles.includes(a) ? 1 : 0) + (!c.titles.includes("lazy") && t & 1 ? 1 : 0) + (!c.titles.includes("slacker") && t & 2 ? 1 : 0) + +(!c.titles.includes("scholar") && e === 30);
		d += l[e * 4 + t] * (i.homework * (e < 25 ? (e - 25) * 10 : (e - 25) * 2) + i.titles * (n ** 2 - c.titles.length ** 2));
	}
	return d;
}
function Be(e, t, n, r) {
	let i = $(t.calendar), a = i.reduce((e, t) => e + (t.kind === "homework" ? t.week === 4 ? 13 / 6 : 11 / 6 : t.kind === "study" ? t.week === 4 ? 3 : 2 : O(t.card)?.pages ?? 0), 0), o = t.calendar.slice((e.week - 1) * 7).filter((e) => !e).length, s = Ie((25 - a) / Math.max(1, o * 1.8), 0, 1), c = n.mode === "candy" ? i.filter((e) => e.week <= 2 && e.kind !== "homework").length : Math.max(...n.values);
	return Ie([
		1,
		.88,
		.5,
		.22
	][e.week - 1] + r.attendance - .62 + (c / n.days - 5) * .035 + (t.titles.includes(n.title) ? 0 : .05) - s * .22, .08, .94);
}
function Ve(e, t) {
	let n = [
		,
		,
		,
		,
		,
		,
	].fill(1);
	for (let r of $(e.players.find((e) => e.rid === t).calendar)) r.kind === "tabletop" && r.die && (n[r.die - 1] += 4);
	let r = n.reduce((e, t) => e + t, 0);
	return n.map((e) => e / r);
}
function He(e, t, n, r, i) {
	let a = 1, o = 1;
	for (let n of t) {
		let t = e.mode === "tabletop" ? Ve(i, n) : [
			,
			,
			,
			,
			,
			,
		].fill(1 / 6);
		a *= t.slice(0, r - 1).reduce((e, t) => e + t, 0), o *= t.slice(0, r).reduce((e, t) => e + t, 0);
	}
	return n && r === 1 && (a = 0), a * e.values[0] + (o - a) * e.values[1] + (1 - o) * e.values[2];
}
function Ue(e, t, n, r, i) {
	let a = e.public, o = a.players.find((e) => e.rid === t), s = a.players.filter((e) => e.rid !== t && V(e.calendar, a.week, n.days).includes(r)), c = $(o.calendar), l = c.filter((e) => e.kind === "base").length, u = c.filter((e) => e.week <= 2 && e.kind !== "homework").length, d = a.transferStudents && V(a.transferCalendar, a.week, n.days).includes(r) ? a.transferDie === null ? [
		[
			0,
			0,
			1 / 6
		],
		[
			1,
			1,
			1 / 3
		],
		[
			1,
			0,
			1 / 3
		],
		[
			2,
			1,
			1 / 6
		]
	] : a.transferDie === 1 ? [[
		0,
		0,
		1
	]] : a.transferDie === 6 ? [[
		2,
		1,
		1
	]] : [[
		1,
		+(a.transferDie < 4),
		1
	]] : [[
		0,
		0,
		1
	]], f = new Map([...a.players.map((e) => e.rid), ...a.transferStudents ? j : []].filter((e) => e !== t).map((e) => [e, a.players.filter((n) => n.rid !== t && n.rid !== e).map((t) => We(a, t.rid, e, i))])), p = new Map([...f].map(([t, r]) => [t, Array.from({ length: n.hearts + 1 }, (n, i) => Ge(Math.min(10, (e.private.hearts[t] ?? 0) + i), r) - Ge(e.private.hearts[t] ?? 0, r))])), m = {
		points: 0,
		solo: 0,
		friendship: 0,
		dice: [
			,
			,
			,
			,
			,
			,
		].fill(0)
	};
	for (let e = 0; e < 2 ** s.length; e++) {
		let t = 1, r = +(o.gender === "boy"), c = [];
		for (let o = 0; o < s.length; o++) {
			let l = i.exactGroups ? Be(a, s[o], n, i) : .58;
			e & 1 << o ? (t *= l, r += +(s[o].gender === "boy"), c.push(s[o].rid)) : t *= 1 - l;
		}
		for (let [e, i, o] of d) {
			let s = t * o, d = 1 + c.length + e;
			if (d === 1 && (m.solo += s), d > 1 && n.hearts) {
				let t = [...c, ...e === 2 ? j : e === 1 ? [i ? j[0] : j[1]] : []], r = 0;
				for (let e of t) if (r = Math.max(r, p.get(e)[n.hearts]), n.hearts === 2) for (let n of t) n !== e && (r = Math.max(r, p.get(e)[1] + p.get(n)[1]));
				m.friendship += s * r;
			}
			let f = 0;
			for (let t = 1; t <= 6; t++) {
				let o = d > 1 && (n.mode === "video" || n.mode === "tabletop") ? He(n, c, e, t, a) : K(n, d, r + i, l, u, t, t, 1);
				m.dice[t - 1] += s * o, f += o / 6;
			}
			m.points += s * f;
		}
	}
	return n.mode === "tabletop" && i.dice && (m.points = Math.max(...m.dice)), m;
}
function We(e, t, n, r) {
	let i = Array(11).fill(0);
	i[0] = 1;
	for (let a of $(e.players.find((e) => e.rid === t).calendar)) {
		if (!a.members.includes(n) || a.members.length < 2 || a.kind === "homework") continue;
		let e = a.kind === "study" ? 1 : O(a.card).hearts, t = Ie(r.rivals / (a.members.length - 1), 0, 1);
		for (let n = 0; n < e; n++) {
			let e = Array(11).fill(0);
			for (let n = 0; n <= 10; n++) e[n] += i[n] * (1 - t), e[Math.min(10, n + 1)] += i[n] * t;
			i = e;
		}
	}
	return i;
}
function Ge(e, t) {
	let n = 1, r = 1;
	for (let i of t) n *= i.slice(0, e).reduce((e, t) => e + t, 0), r *= i.slice(0, e + 1).reduce((e, t) => e + t, 0);
	return 10 * n + 5 * (r - n);
}
function Ke(e = Pe, t = Fe) {
	let n = qe(void 0, t);
	return (r, i) => {
		let a = r.public, o = r.private, s = a.players.find((e) => e.rid === i.rid);
		if (!s || !o || i.difficulty === "weak") return n(r, i);
		let c = i.memory, l = new Set(c?.week === a.week && Array.isArray(c.seen) ? c.seen : []);
		for (let e of a.players) for (let t of $(e.calendar)) t.week === a.week && t.card && l.add(t.card);
		a.card !== null && l.add(a.card);
		let u = (e) => ({
			action: e,
			memory: {
				week: a.week,
				seen: [...l]
			}
		}), d = /* @__PURE__ */ new Map(), f = () => {
			let t = "decline";
			return d.has(t) || d.set(t, ze(r, i.rid, null, null, e)), d.get(t);
		}, p = /* @__PURE__ */ new Map(), m = (t, n) => {
			let o = `${t.id}:${n}`, c = p.get(o);
			if (c) return c;
			let l = Ue(t.id === a.card ? r : {
				...r,
				public: {
					...a,
					transferDie: null
				}
			}, i.rid, t, n, e), u = s.titles.includes(t.title) ? 0 : (2 * s.titles.length + 1) * e.titles * (t.mode === "fixed" ? 1 : l.solo), d = e.forecast ? ze(r, i.rid, n, t, e) : 0, m = s.titles.includes(t.title) ? 0 : t.mode === "fixed" ? 1 : l.solo, h = e.forecast ? d + m * (ze(r, i.rid, n, t, e, t.title) - d) - f() : -(t.days * (a.week === 4 ? 13 / 6 : 11 / 6) - (t.pages ?? 0)) * e.homework * 3, g = {
				value: l.points + (e.forecast ? 0 : u) + h + l.friendship * e.friendship,
				dice: l.dice
			};
			return p.set(o, g), g;
		}, h, g = s.calendar.slice((a.week - 1) * 7, a.week * 7).reduce((e, t, n) => t ? e | 1 << n : e, 0), _ = (t, n) => {
			let r = m(t, n).value;
			return !(e.opportunities ?? 1) || a.invitation >= 5 ? r : (h ??= Re(a, i.rid, l, (e, t) => m(e, t).value), r - (e.opportunities ?? 1) * (h(g) - h(g | Le(n, t.days))));
		};
		if (a.phase === "schedule" && a.proposer === i.rid) {
			let n = O(a.card), r = V(s.calendar, a.week, n.days);
			if (!r.length) return u({ type: "skip" });
			let i = r.map((t) => {
				let r = _(n, t), i = [...s.calendar];
				for (let e = 0; e < n.days; e++) i[(a.week - 1) * 7 + t + e] = {
					card: n.id,
					kind: n.kind,
					week: a.week,
					start: t,
					days: n.days,
					points: 0,
					members: [],
					die: null
				};
				return Math.max(0, r + e.fragmentation * (V(i, a.week, 2).length - V(s.calendar, a.week, 2).length));
			}), o = Math.max(...i), c = r.filter((e, t) => i[t] >= o - 1e-8);
			return u({
				type: "schedule",
				start: c[Math.floor(t() * c.length)]
			});
		}
		if (a.phase === "attend" && !s.ready) {
			let n = O(a.card), r = m(n, a.start), i = _(n, a.start) >= 0, o = Math.max(...r.dice), s = r.dice.map((e, t) => e >= o - 1e-8 ? t + 1 : 0).filter(Boolean);
			return u({
				type: "attend",
				yes: i,
				...i && n.mode === "tabletop" ? { die: e.dice ? s[Math.floor(t() * s.length)] : 1 + Math.floor(t() * 6) } : {}
			});
		}
		if (a.phase === "hearts" && !o.allocated && e.contest) {
			let n = { ...o.hearts }, r = new Map(o.targets.map((t) => [t, a.players.filter((e) => e.rid !== i.rid && e.rid !== t).map((n) => We(a, n.rid, t, e))])), s = -Infinity, c = [], l = (e) => {
				if (e.length < o.heartCount) {
					for (let t of o.targets) l([...e, t]);
					return;
				}
				let t = 0;
				for (let i of o.targets) {
					let a = n[i] ?? 0, o = Math.min(10, a + e.filter((e) => e === i).length);
					t += Ge(o, r.get(i)) - Ge(a, r.get(i));
				}
				t > s + 1e-8 && (s = t, c.length = 0), t >= s - 1e-8 && c.push(e);
			};
			return l([]), u({
				type: "hearts",
				targets: c[Math.floor(t() * c.length)]
			});
		}
		let v = n(r, i);
		return v ? u(v.action) : null;
	};
}
function qe(e, t) {
	return (e, n) => {
		let r = e.public, i = e.private, a = r.players.find((e) => e.rid === n.rid);
		if (!a || !i) return null;
		let o = n.difficulty === "weak", s = (e) => e[Math.floor(t() * e.length)];
		if (r.phase === "characters" && a.gender === null) return { action: {
			type: "character",
			gender: r.players.indexOf(a) % 2 == 0 ? "boy" : "girl"
		} };
		if (r.phase === "schedule" && r.proposer === n.rid) {
			let e = V(a.calendar, r.week, O(r.card).days);
			return { action: e.length ? {
				type: "schedule",
				start: s(e)
			} : { type: "skip" } };
		}
		if (r.phase === "attend" && !a.ready) {
			let e = O(r.card), n = t() < .65;
			return { action: {
				type: "attend",
				yes: n,
				...n && e.mode === "tabletop" ? { die: 1 + Math.floor(t() * 6) } : {}
			} };
		}
		if (r.phase === "hearts" && !i.allocated) {
			let e = [], t = { ...i.hearts };
			for (let n = 0; n < i.heartCount; n++) {
				let n = (e) => {
					let n = t[e] ?? 0;
					return n >= 10 ? -100 : (n === 0 ? 3 : n < 5 ? 2 : n < 8 ? 1 : .2) + (j.includes(e) ? .1 : 0);
				}, r = o ? s(i.targets) : i.targets.reduce((e, t) => n(t) > n(e) ? t : e);
				e.push(r), t[r] = (t[r] ?? 0) + 1;
			}
			return { action: {
				type: "hearts",
				targets: e
			} };
		}
		return r.phase === "homework" && a.calendar.slice((r.week - 1) * 7, r.week * 7).some((e) => e === null) ? { action: { type: "homework" } } : r.phase === "weekEnd" && !a.ready ? { action: { type: "next" } } : null;
	};
}
var Je = Ke(), Ye = (e, t, n) => e.type === "schedule" ? n("games.natsumemo.hintSchedule", { day: n(T[e.start]) }) : e.type === "attend" ? n(e.yes ? "games.natsumemo.hintAttend" : "games.natsumemo.hintDecline") : e.type === "homework" ? n("games.natsumemo.roll") : e.type === "character" ? n(e.gender === "boy" ? "games.natsumemo.boy" : "games.natsumemo.girl") : e.type === "skip" ? n("games.natsumemo.skip") : e.type === "hearts" ? n("games.natsumemo.sendHearts") : e.type === "next" ? n("games.natsumemo.nextWeek") : "", Xe = {
	diaryStamp(e, t) {
		let n = e.data;
		if (!n) return null;
		let r = [...new Set(n.members.map((e) => e.startsWith("$transfer-") ? "$transfer" : e))].flatMap((e) => {
			let r = t.anchor(`day:${e}:${n.week}:${n.start}`), i = t.anchor(`day:${e}:${n.week}:${n.start + (n.days ?? 1) - 1}`);
			return r && i ? [{
				...r,
				w: i.x + i.w - r.x
			}] : [];
		});
		return {
			ms: t.queued ? 300 : 850,
			node: /* @__PURE__ */ _(h, { children: [r.map((e, t) => /* @__PURE__ */ _("div", {
				className: "nm-ink-writing",
				style: {
					left: e.x + 4,
					top: e.y + 4,
					width: e.w - 8,
					height: e.h - 8
				},
				children: [/* @__PURE__ */ g("span", {
					className: "nm-writing-pencil",
					children: "✎"
				}), /* @__PURE__ */ g("i", {})]
			}, t)), Object.entries(n.gains ?? {}).map(([e, n]) => {
				let r = t.anchor(`seat:${e}`);
				return r ? /* @__PURE__ */ g(y, {
					at: r,
					ms: 850,
					children: /* @__PURE__ */ _("span", {
						className: "nm-gain-note",
						children: ["+", n]
					})
				}, e) : null;
			})] })
		};
	},
	homeworkRoll(e, t) {
		let n = e.secret, r = t.anchor("homework-die") ?? t.anchor(`seat:${t.myRid}`);
		if (!n || !r) return null;
		let i = t.anchor(`day:${t.myRid}:${n.week}:${n.start}`), a = t.anchor("secret-paper");
		return {
			ms: t.queued ? 300 : 850,
			node: /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("div", {
					className: "nm-fx-die",
					style: {
						position: "absolute",
						left: r.x + r.w / 2 - 25,
						top: r.y - 52
					},
					children: /* @__PURE__ */ g(Q, {
						value: n.die,
						label: ""
					})
				}),
				i && /* @__PURE__ */ _("div", {
					className: "nm-ink-writing",
					style: {
						left: i.x + 4,
						top: i.y + 4,
						width: i.w - 8,
						height: i.h - 8
					},
					children: [/* @__PURE__ */ g("span", {
						className: "nm-writing-pencil",
						children: "✎"
					}), /* @__PURE__ */ g("i", {})]
				}),
				a && n.pages > 0 && /* @__PURE__ */ g(y, {
					at: a,
					ms: 850,
					children: /* @__PURE__ */ _("span", {
						className: "nm-pages-written",
						children: [/* @__PURE__ */ g(Z, { size: 22 }), Array.from({ length: n.pages }, (e, t) => /* @__PURE__ */ g("i", {
							style: { animationDelay: `${t * 110}ms` },
							children: "✓"
						}, t))]
					})
				}),
				n.points > 0 && /* @__PURE__ */ g(y, {
					at: r,
					ms: 850,
					children: /* @__PURE__ */ _("span", {
						className: "nm-gain-note",
						children: ["+", n.points]
					})
				})
			] })
		};
	},
	friendshipInk(e, t) {
		let n = e.secret, r = t.anchor("event-card") ?? t.anchor(`seat:${t.myRid}`), i = t.anchor("secret-paper");
		return !n || !r || !i ? null : {
			ms: t.queued ? 300 : 850,
			node: /* @__PURE__ */ g(h, { children: Array.from({ length: n.count }, (e, n) => /* @__PURE__ */ g(b, {
				from: {
					...r,
					w: 32,
					h: 32,
					x: r.x + r.w / 2 - 16,
					y: r.y + r.h / 2 - 16
				},
				to: {
					...i,
					w: 26,
					h: 26,
					x: i.x + i.w / 2 - 13
				},
				ms: t.queued ? 250 : 650,
				delay: n * 90,
				children: /* @__PURE__ */ g(X, { size: 28 })
			}, n)) })
		};
	},
	pagesWritten(e, t) {
		let n = e.secret, r = t.anchor("secret-paper");
		return !n || !r ? null : {
			ms: t.queued ? 300 : 850,
			node: /* @__PURE__ */ g(y, {
				at: r,
				ms: 850,
				children: /* @__PURE__ */ _("span", {
					className: "nm-pages-written",
					children: [/* @__PURE__ */ g(Z, { size: 22 }), Array.from({ length: n.pages }, (e, t) => /* @__PURE__ */ g("i", {
						style: { animationDelay: `${t * 110}ms` },
						children: "✓"
					}, t))]
				})
			})
		};
	}
};
//#endregion
//#region src/games/natsumemo/game-over.tsx
function Ze(e) {
	let t = u(), [n, r] = o(!1), i = e.public, a = (n) => n === "$transfer-boy" ? t("games.natsumemo.transferBoy") : n === "$transfer-girl" ? t("games.natsumemo.transferGirl") : e.members.find((e) => e.rid === n)?.name.trim() || t(l[Math.max(0, i.players.findIndex((e) => e.rid === n)) % l.length].nameKey);
	if (n) return /* @__PURE__ */ _("div", {
		className: "nm-review",
		children: [/* @__PURE__ */ g(je, {
			pub: i,
			members: e.members,
			myRid: e.myRid,
			send: () => {},
			readOnly: !0
		}), /* @__PURE__ */ g("button", {
			className: "nm-button nm-review-back",
			onClick: () => r(!1),
			children: t("games.natsumemo.results")
		})]
	});
	let d = e.result.winner ?? [];
	return /* @__PURE__ */ _("div", {
		className: "nm-over",
		children: [
			/* @__PURE__ */ _("header", { children: [/* @__PURE__ */ g("h1", { children: t("games.natsumemo.ending") }), /* @__PURE__ */ g("p", { children: d.length === 1 ? t("games.natsumemo.winner", { name: a(d[0]) }) : t("games.natsumemo.tie", { names: d.map(a).join(" · ") }) })] }),
			/* @__PURE__ */ g("div", {
				className: "nm-result-list",
				children: e.result.ranking.map((n) => {
					let r = i.results?.[n], o = e.members.find((e) => e.rid === n);
					return r ? /* @__PURE__ */ _("article", {
						className: "nm-result-card",
						children: [
							/* @__PURE__ */ _("header", { children: [
								/* @__PURE__ */ g("img", {
									src: s(c[(o?.avatar ?? 0) % c.length]),
									alt: ""
								}),
								/* @__PURE__ */ g("strong", { children: a(n) }),
								/* @__PURE__ */ g("b", { children: r.total })
							] }),
							/* @__PURE__ */ _("dl", { children: [
								/* @__PURE__ */ g("dt", { children: t("games.natsumemo.activityScore") }),
								/* @__PURE__ */ g("dd", { children: r.activity }),
								/* @__PURE__ */ _("dt", { children: [/* @__PURE__ */ g(Z, { size: 16 }), t("games.natsumemo.homeworkScore")] }),
								/* @__PURE__ */ g("dd", { children: r.homework }),
								/* @__PURE__ */ _("dt", { children: [/* @__PURE__ */ g(Ce, { size: 16 }), t("games.natsumemo.titleScore")] }),
								/* @__PURE__ */ g("dd", { children: r.titles }),
								/* @__PURE__ */ _("dt", { children: [/* @__PURE__ */ g(X, { size: 16 }), t("games.natsumemo.friendshipScore")] }),
								/* @__PURE__ */ g("dd", { children: r.friendship })
							] }),
							/* @__PURE__ */ _("details", { children: [
								/* @__PURE__ */ g("summary", { children: t("games.natsumemo.details") }),
								/* @__PURE__ */ g("p", { children: t("games.natsumemo.pages", { n: r.pages }) }),
								/* @__PURE__ */ g("p", { children: t("games.natsumemo.titleCount", { n: i.players.find((e) => e.rid === n)?.titles.length ?? 0 }) }),
								Object.entries(r.hearts).map(([e, n]) => /* @__PURE__ */ g("p", { children: t("games.natsumemo.given", {
									name: a(e),
									n
								}) }, e))
							] }),
							e.result.autopilot?.[n] !== void 0 && /* @__PURE__ */ g("p", { children: t("session.autopilot.share", { n: Math.round(e.result.autopilot[n] * 100) }) })
						]
					}, n) : null;
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "nm-over-actions",
				children: [
					/* @__PURE__ */ g("button", {
						className: "nm-button",
						onClick: () => r(!0),
						children: t("games.natsumemo.review")
					}),
					e.onPlayAgain && /* @__PURE__ */ g(x, {
						className: "nm-button",
						confirmLabel: t("games.natsumemo.confirmAgain"),
						onConfirm: e.onPlayAgain,
						label: t("session.result.playAgain")
					}),
					e.onBackToLobby && /* @__PURE__ */ g(x, {
						className: "nm-button nm-quiet",
						confirmLabel: t("games.natsumemo.confirmLobby"),
						onConfirm: e.onBackToLobby,
						label: t("session.result.backToLobby")
					}),
					!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ g("p", { children: t("session.result.waitHost") }),
					e.hintCount !== void 0 && e.hintCount > 0 && /* @__PURE__ */ g("p", { children: t("session.hint.usedCount", { n: e.hintCount }) })
				]
			})
		]
	});
}
//#endregion
//#region src/games/natsumemo/options.tsx
function Qe({ value: e, onChange: t }) {
	let n = u(), r = N.safeParse(e), i = r.success ? r.data : N.parse(void 0);
	return /* @__PURE__ */ g(te, {
		title: n("games.natsumemo.transferOption"),
		children: [!1, !0].map((e) => /* @__PURE__ */ g(S, {
			name: "natsumemo-transfer",
			value: String(e),
			checked: i.transferStudents === e,
			label: n(e ? "games.natsumemo.transferOn" : "games.natsumemo.transferOff"),
			accent: M.accent,
			onChange: () => t({
				...i,
				transferStudents: e
			})
		}, String(e)))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/natsumemo/entry.tsx
var $e = {
	definition: pe,
	View: Ae,
	bot: Je,
	describe: Ye,
	fx: Xe,
	OverView: Ze,
	Options: Qe,
	locales: {
		zh: {
			name: "暑假日记",
			desc: "安排最后四周的暑假，和朋友出游、交换心意，也别忘了写作业。",
			rules: "目标:\n在四周暑假中安排活动，收集称号和友谊，并完成作业。第四周结束后，总分最高的玩家获胜；总分相同时并列获胜。\n准备:\n每位玩家选择本局扮演的男孩或女孩。这只是游戏角色，与真实身份无关，建议尽量均衡。每人有一张公开日历和一张秘密记录纸。活动、活动分数和称号公开，作业进度及送给别人的爱心在终局前保密。\n36 张活动牌按周次分为四组，每组 9 张，分别洗匀。每周最多翻开 6 张，其余不使用。第一席先担任带头的人，每周结束后顺时针移动一席。\n邀请与安排:\n· 由带头的人开始，顺时针轮流翻开本周的一张活动牌。提议者从自己空闲的日期中选择活动开始日。需要 2 天或 3 天的活动必须连续安排，不能拆开或跨周。如果提议者没有足够的连续空档，本次活动弃置并计入邀约次数。\n· 玩家可以先讨论日期。日期确定后，所有有空的玩家同时秘密选择参加或不参加。提议者也可以不参加，日程冲突的玩家不能参加。所有决定提交后一起公开。\n· 参加者在日历上登记活动，并按实际参加的人数与角色性别获得牌面分数、作业页数及称号。跨多天活动只计算一次分数。红色单人结果替代普通多人结果；家庭旅游、出国旅游及回祖父母家无论人数都获得固定结果。\n· 打电动时，每位参加者随机掷一次骰子。玩桌游时，每位参加者秘密选择 1 至 6 的一个点数，然后同时公开。最高点数独占第一时按第一名得分；最高点数并列时，所有并列者按并列第一得分，其余人按第二名及以下得分。只有一人参加时使用单人结果。\n· 抓虫时，每位参加者独立掷骰，按牌面区间获得分数。盖秘密基地按本人参加该活动的累计次数得分。第三周的糖果店按本人第一、二周参加的活动次数计分，包含周三读书会，不包含在家写作业。\n· 活动提供的每颗爱心都秘密分给本次一起参加的其他角色。可以把多颗爱心给同一角色，不能给自己。独自参加时没有可送出的爱心。每个目标最多记录 10 颗爱心，超出部分不再增加。\n写作业与周末小结:\n进行过 6 次邀约，或者所有人的本周日历都已排满后，进入写作业阶段。\n· 周三仍空闲的角色必须参加读书会。第一至三周有多人参加时，每人获得 3 分、完成 2 页作业并送出 1 颗爱心；只有一人参加时，只完成 3 页作业。第四周有多人参加时，每人获得 2 分、完成 3 页作业并送出 1 颗爱心；只有一人参加时，只完成 4 页作业。\n· 除周三以外，每个空白日都必须在家写作业，每天独立掷一次骰子。第一至三周掷出 1 时获得 3 分和“小懒虫”称号，掷出 2 至 5 时完成 2 页作业，掷出 6 时完成 3 页作业。第四周掷出 1 或 2 时获得 5 分和“懒鬼”称号，掷出 3 至 5 时完成 3 页作业，掷出 6 时完成 4 页作业。\n· 作业从第 1 页连续完成，最多 30 页。相同称号只收集一次。所有人填满本周日历并确认小结后，开始下一周。\n终局计分:\n· 活动分数：将四周日历上所有分数相加。\n· 作业分数：前 25 页每少完成 1 页扣 10 分。第 26 至 30 页每完成 1 页获得 2 分。完成全部 30 页时获得“学霸”称号。\n· 称号分数：不同称号的数量乘以自身。例如，收集 5 个称号得到 25 分。\n· 友谊分数：依次以每个角色为目标，比较其他玩家送给该角色的爱心数。送出最多爱心的玩家独自获得 10 分；并列最多的玩家各获得 5 分。爱心为零的记录也参与最高值比较。转学生只作为爱心目标，不作为得分者。\n转学生追加规则:\n开局可启用官方的 2 至 4 人追加规则，加入一男一女两名转学生。两名转学生共用一张日历，不参加胜负排名。\n· 每次确定活动日期后，如果他们的共用日历在这些日期都空闲，先掷骰并向所有玩家公开。掷出 1 时两人都不来；2 或 3 时男孩来；4 或 5 时女孩来；6 时两人都来。之后真人才秘密决定是否参加。只要一名转学生参加，就在共用日历上占用全部活动日期。\n· 转学生计入参加人数与性别，可以接收爱心。打电动或玩桌游时，他们的骰点固定为 1。周三共用日历空闲时，两名转学生都参加读书会；否则都不参加。",
			events: {
				bbq: "烧烤",
				video: "打电动",
				grandparents: "回祖父母家",
				family: "家庭旅游",
				beach: "海水浴场",
				zoo: "动物园",
				pool: "游泳池",
				shopping: "买东西",
				base: "盖秘密基地",
				abroad: "出国旅游",
				bugs: "抓虫",
				camp: "露营",
				festival: "夜市",
				tabletop: "玩桌游",
				explore: "街头探险",
				candy: "糖果店",
				fireworks: "烟火大会",
				sleepover: "隔宿悄悄话",
				park: "游乐园",
				study: "周三读书会",
				homework: "在家写作业"
			},
			titles: {
				caretaker: "管理员",
				lazy: "小懒虫",
				lifeguard: "自称救生员",
				vip: "年票 VIP",
				swimmer: "游泳健将",
				zoologist: "动物博士",
				festival: "夜市通",
				slacker: "懒鬼",
				family: "和睦的家庭",
				gamer: "单人游戏高手",
				firestarter: "生火专家",
				entomologist: "昆虫博士",
				fireworks: "烟火师",
				scholar: "学霸",
				grandchild: "祖父母的乖孙",
				detective: "少年侦探",
				survivor: "求生大师",
				solo: "左右互搏",
				peterpan: "彼得潘",
				regular: "常客",
				critic: "零食评论家"
			},
			monday: "周一",
			tuesday: "周二",
			wednesday: "周三",
			thursday: "周四",
			friday: "周五",
			saturday: "周六",
			sunday: "周日",
			week: "第 {{n}} 周",
			invitation: "邀约 {{n}} / 6",
			diary: "暑假日记",
			secret: "秘密记录纸",
			calendar: "公开日历",
			boy: "男孩",
			girl: "女孩",
			characterPrompt: "选择本局扮演的角色。",
			characterNote: "角色性别与真实身份无关。",
			gathering: "暑假的小伙伴",
			proposalBy: "{{name}} 提议",
			proposer: "提议人",
			sealed: "决定已封好",
			considering: "正在考虑",
			attending: "参加",
			notAttending: "不参加",
			viewCalendar: "查看 {{name}} 的日历",
			sameGender: "全为同性参加",
			mixedGender: "男女混合参加",
			evenGroup: "偶数人参加",
			oddGroup: "奇数人参加",
			balancedGroup: "男女数量相等",
			unbalancedGroup: "男女数量不等",
			twoGroup: "两人参加",
			largerGroup: "三人以上参加",
			uniqueFirst: "独占第一",
			tiedFirst: "并列第一",
			remaining: "第二名及以下",
			schedulePrompt: "由你提议，请在自己的日历上选择活动开始日。",
			scheduleWait: "{{name}} 正在决定活动日期。",
			scheduleOther: "正在查看 {{name}} 的日历。",
			viewMine: "回到我的日历",
			noSpace: "没有足够的连续空档，本次活动将弃置。",
			skip: "弃置活动",
			confirmSchedule: "确定日期",
			dates: "{{from}} 至 {{to}}",
			day: "{{n}} 天",
			attendPrompt: "日期已由提议人确定。你要一起去吗？",
			attend: "举手参加",
			decline: "这次不参加",
			waiting: "已封好决定，等待一起揭晓。",
			busy: "行程冲突，无法参加本次活动。",
			revealPrompt: "大家的决定揭晓了。",
			settlePrompt: "正在记录这段回忆。",
			studyPrompt: "周三读书会开始了。",
			heartsPrompt: "将 {{n}} 颗爱心送给同场的朋友。",
			heartsWait: "等待朋友记录心意。",
			sendHearts: "封存心意",
			heartCount: "已选 {{n}} / {{total}}",
			reset: "重新选择",
			homeworkPrompt: "点击骰子，为下一个空白日写作业。",
			homeworkWait: "本周日历已填满，等待其他人。",
			roll: "掷骰写作业",
			homeworkResult: "{{day}} · 掷出 {{die}}，完成 {{pages}} 页作业，获得 {{points}} 分。",
			weekEndPrompt: "本周结束，查看日历后确认。",
			nextWeek: "开始下一周",
			finish: "查看暑假总评",
			ready: "已确认",
			pages: "作业 {{n}} / 30 页",
			pageLabel: "第 {{n}} 页",
			points: "{{n}} 分",
			titleCount: "称号 {{n}} 个",
			noTitles: "还没有获得称号。",
			friendship: "友谊",
			transferOption: "转学生追加规则",
			transferOn: "加入转学生（2 至 4 人）",
			transferOff: "基础版（3 至 6 人）",
			transferBoy: "转学生男孩",
			transferGirl: "转学生女孩",
			transferDiary: "转学生共用日历",
			transferRoll: "转学生掷出 {{n}}",
			transferNone: "转学生不参加",
			chooseDie: "秘密选择骰点",
			die: "骰子 {{n}} 点",
			randomDice: "参加者各掷一次骰子。",
			secretDice: "参加者秘密选点，随后一起公开。",
			fixed: "获得 {{n}} 分。",
			fixedPages: "获得 {{n}} 分，完成 {{pages}} 页作业。",
			parity: "偶数人 {{a}} 分；奇数人 {{b}} 分。",
			gender: "全同性 {{a}} 分；男女混合 {{b}} 分。",
			balanced: "男女数量相等 {{a}} 分；不等 {{b}} 分。",
			two: "两人 {{a}} 分；三人以上 {{b}} 分。",
			baseScore: "本人第 1 次 3 分，第 2 次 6 分，第 3、4 次 10 分。",
			candyScore: "本人前两周每参加一次活动得 1 分，包含读书会。",
			contest: "独占第一 {{a}} 分；并列第一 {{b}} 分；其余 {{c}} 分。",
			bugs2: "骰点 1：3 分；2 至 4：5 分；5 或 6：6 分。",
			bugs4: "骰点 1 或 2：3 分；3 至 5：7 分；6：10 分。",
			solo: "独自参加",
			soloScore: "{{n}} 分，并获得“{{title}}”称号。",
			soloSame: "按上述规则得分，并获得“{{title}}”称号。",
			titleAward: "获得“{{title}}”称号。",
			heartAward: "可送出 {{n}} 颗爱心。",
			empty: "空闲",
			selected: "拟安排",
			proposedDates: "提议日期：第 {{week}} 周，{{from}} 至 {{to}}",
			proposedDay: "本次提议日期",
			entry: "{{name}}，{{n}} 分",
			detail: "日记详情",
			close: "关闭",
			legend: "活动日期连续占用，分数只计一次。",
			ending: "暑假总评",
			winner: "{{name}} 的暑假最精彩",
			tie: "并列第一：{{names}}",
			activityScore: "活动",
			homeworkScore: "作业",
			titleScore: "称号",
			friendshipScore: "友谊",
			total: "总分",
			details: "计分明细",
			review: "回看日历",
			results: "返回总评",
			given: "送给 {{name}}：{{n}} 颗爱心",
			noHearts: "尚未送出爱心。",
			confirmAgain: "确定重新开始？",
			confirmLobby: "确定返回大厅？",
			error: "这个操作现在无法进行，请按当前提示操作。",
			hintSchedule: "将活动安排在 {{day}} 开始。",
			hintAttend: "参加这次活动。",
			hintDecline: "保留日期，留出写作业的时间。",
			hintHeart: "把爱心送给 {{names}}。"
		},
		en: {
			name: "Natsumemo",
			desc: "Plan four summer weeks with friends, collect memories and affection, and finish your homework.",
			rules: "Goal:\nPlan four weeks of summer activities, collect titles and friendship, and finish your homework. The highest total wins after week four. Tied totals share the victory.\nPreparation:\nEach player chooses to play a boy or a girl. This fictional character does not represent your real identity; a balanced mix is recommended. Your calendar, activity points and titles are public. Homework progress and affection you give remain private until the end.\nSeparate the 36 event cards into four shuffled decks of 9 cards. At most 6 cards are used each week. The first seated player is the initial leader. Pass this role clockwise by one seat after each week.\nInvitations and events:\n· Starting with the leader, players take turns clockwise to reveal an event for the current week. The proposer chooses a start day in their own free time. Events lasting 2 or 3 days require consecutive dates within one week. If the proposer has no suitable consecutive space, discard the event; it still counts as one invitation.\n· Players may discuss dates before they are confirmed. Everyone with those dates free then secretly chooses whether to attend. The proposer may decline too. Conflicting plans prevent attendance. Reveal all decisions together once everyone has submitted.\n· Attendees record the event and receive its points, homework pages and titles according to the actual number and genders attending. Score a multi-day event only once. The separate solo result replaces the multiplayer result. Family trips, overseas trips and visits to grandparents have the same fixed result regardless of attendance.\n· For video games, every attendee rolls a random die. For tabletop games, each attendee secretly chooses a die value from 1 to 6, then reveals it together with the others. A unique highest value scores the first-place amount. If the highest value is tied, all tied players score the tied-first amount. Everyone below them scores the remaining amount. Use the solo result when only one character attends.\n· Bug catching uses an independent die roll per attendee and the printed scoring bands. Secret-base points depend on your own number of visits. The week-three candy shop scores 1 point for each event you attended in weeks one and two, including study groups but excluding homework at home.\n· Secretly assign every affection heart from the event to another character attending it. You may give multiple hearts to one recipient, but never to yourself. A solo attendee has nobody to give hearts to. Each recipient has 10 spaces; additional hearts do not increase that total.\nHomework and weekly review:\nAfter 6 invitations, or when every player has filled the week, resolve homework.\n· All characters whose Wednesday is free must attend the study group. In weeks one to three, a group gives each attendee 3 points, 2 homework pages and 1 heart to give. A solo attendee only completes 3 pages. In week four, a group gives 2 points, 3 pages and 1 heart; a solo attendee only completes 4 pages.\n· Every other empty day must be spent on homework at home. Roll once per day. In weeks one to three, a 1 gives 3 points and the Little Slacker title; a 2–5 completes 2 pages; a 6 completes 3 pages. In week four, a 1 or 2 gives 5 points and the Master Slacker title; a 3–5 completes 3 pages; a 6 completes 4 pages.\n· Complete homework in order, starting at page 1, up to 30 pages. Collect each title only once. When everyone has filled the week and confirmed the review, begin the next week.\nFinal scoring:\n· Activity points: Add all points recorded on the four-week calendar.\n· Homework: Lose 10 points for each unfinished page among pages 1–25. Gain 2 points for each completed page among pages 26–30. Completing all 30 pages also gives the Star Student title.\n· Titles: Square the number of distinct titles collected. Five titles, for example, score 25 points.\n· Friendship: For each character, compare the hearts other players gave that character. The unique highest giver scores 10 points; tied highest givers score 5 points each. Zero-heart records also count when comparing the highest amount. Transfer students receive hearts but never score themselves.\nTransfer students:\nThe official optional rules for 2–4 players add one boy and one girl. These transfer students share one calendar and do not compete to win.\n· After dates are confirmed, if their shared calendar is free for the entire event, roll and reveal a die before humans make their attendance decisions. A 1 brings neither; 2 or 3 brings the boy; 4 or 5 brings the girl; 6 brings both. If either attends, mark the full event on their shared calendar.\n· They count toward attendance and gender conditions and may receive hearts. Their die value in video or tabletop games is always 1. If the shared Wednesday is free, both attend the study group; otherwise neither does.",
			events: {
				bbq: "Barbecue",
				video: "Video games",
				grandparents: "Visit grandparents",
				family: "Family trip",
				beach: "Beach",
				zoo: "Zoo",
				pool: "Swimming pool",
				shopping: "Shopping",
				base: "Secret base",
				abroad: "Overseas trip",
				bugs: "Bug catching",
				camp: "Camping",
				festival: "Night festival",
				tabletop: "Tabletop games",
				explore: "Street adventure",
				candy: "Candy shop",
				fireworks: "Fireworks",
				sleepover: "Sleepover",
				park: "Amusement park",
				study: "Wednesday study group",
				homework: "Homework at home"
			},
			titles: {
				caretaker: "Caretaker",
				lazy: "Little Slacker",
				lifeguard: "Self-styled Lifeguard",
				vip: "Season-pass VIP",
				swimmer: "Swimmer",
				zoologist: "Animal Expert",
				festival: "Festival Regular",
				slacker: "Master Slacker",
				family: "Happy Family",
				gamer: "Solo Gamer",
				firestarter: "Fire Starter",
				entomologist: "Bug Expert",
				fireworks: "Pyrotechnician",
				scholar: "Star Student",
				grandchild: "Beloved Grandchild",
				detective: "Young Detective",
				survivor: "Survival Expert",
				solo: "Playing Both Sides",
				peterpan: "Peter Pan",
				regular: "Regular Customer",
				critic: "Snack Critic"
			},
			monday: "Mon",
			tuesday: "Tue",
			wednesday: "Wed",
			thursday: "Thu",
			friday: "Fri",
			saturday: "Sat",
			sunday: "Sun",
			week: "Week {{n}}",
			invitation: "Invite {{n}} / 6",
			diary: "Summer diary",
			secret: "Secret sheet",
			calendar: "Public calendar",
			boy: "Boy",
			girl: "Girl",
			characterPrompt: "Choose your character for this summer.",
			characterNote: "Your fictional character is independent of your real identity.",
			gathering: "Summer friends",
			proposalBy: "{{name}} proposes",
			proposer: "Proposer",
			sealed: "Decision sealed",
			considering: "Thinking",
			attending: "Joining",
			notAttending: "Sitting out",
			viewCalendar: "View {{name}}’s calendar",
			sameGender: "Same gender",
			mixedGender: "Mixed genders",
			evenGroup: "Even group",
			oddGroup: "Odd group",
			balancedGroup: "Equal boys and girls",
			unbalancedGroup: "Unequal boys and girls",
			twoGroup: "Two attendees",
			largerGroup: "Three or more",
			uniqueFirst: "Unique highest",
			tiedFirst: "Tied highest",
			remaining: "Below the highest",
			schedulePrompt: "You are proposing. Choose a start day on your calendar.",
			scheduleWait: "{{name}} is choosing the event dates.",
			scheduleOther: "Viewing {{name}}’s calendar.",
			viewMine: "My calendar",
			noSpace: "No consecutive space fits this event. Discard it.",
			skip: "Discard event",
			confirmSchedule: "Confirm dates",
			dates: "{{from}} – {{to}}",
			day: "{{n}} days",
			attendPrompt: "The proposer has set the dates. Will you join?",
			attend: "Raise my hand",
			decline: "Sit this one out",
			waiting: "Decision sealed. Waiting to reveal together.",
			busy: "Your plans conflict with this event.",
			revealPrompt: "Everyone’s decisions are revealed.",
			settlePrompt: "Recording this memory.",
			studyPrompt: "Time for Wednesday’s study group.",
			heartsPrompt: "Give {{n}} hearts to friends who attended.",
			heartsWait: "Waiting for friends to record their affection.",
			sendHearts: "Seal affection",
			heartCount: "Selected {{n}} / {{total}}",
			reset: "Clear selection",
			homeworkPrompt: "Roll the die for your next empty day.",
			homeworkWait: "Your week is full. Waiting for friends.",
			roll: "Roll for homework",
			homeworkResult: "{{day}} · Rolled {{die}}: {{pages}} pages and {{points}} points.",
			weekEndPrompt: "Review your week, then confirm.",
			nextWeek: "Next week",
			finish: "Summer report",
			ready: "Confirmed",
			pages: "Homework {{n}} / 30 pages",
			pageLabel: "Page {{n}}",
			points: "{{n}} pts",
			titleCount: "{{n}} titles",
			noTitles: "No titles collected yet.",
			friendship: "Friendship",
			transferOption: "Transfer students",
			transferOn: "Add students (2–4 players)",
			transferOff: "Base game (3–6 players)",
			transferBoy: "Transfer boy",
			transferGirl: "Transfer girl",
			transferDiary: "Shared student calendar",
			transferRoll: "Students rolled {{n}}",
			transferNone: "No transfer students attend",
			chooseDie: "Choose a secret die value",
			die: "Die value {{n}}",
			randomDice: "Each attendee rolls a die.",
			secretDice: "Attendees secretly choose a value, then reveal together.",
			fixed: "Gain {{n}} points.",
			fixedPages: "Gain {{n}} points and complete {{pages}} pages.",
			parity: "Even group: {{a}} pts. Odd group: {{b}} pts.",
			gender: "Same gender: {{a}} pts. Mixed: {{b}} pts.",
			balanced: "Equal boys and girls: {{a}} pts. Otherwise: {{b}} pts.",
			two: "Two attendees: {{a}} pts. Three or more: {{b}} pts.",
			baseScore: "Your first visit: 3 pts. Second: 6 pts. Third or fourth: 10 pts.",
			candyScore: "Gain 1 point per event you attended in weeks 1–2, including study groups.",
			contest: "Unique highest: {{a}} pts. Tied highest: {{b}} pts. Others: {{c}} pts.",
			bugs2: "Die 1: 3 pts. Die 2–4: 5 pts. Die 5–6: 6 pts.",
			bugs4: "Die 1–2: 3 pts. Die 3–5: 7 pts. Die 6: 10 pts.",
			solo: "Attending alone",
			soloScore: "{{n}} points and the {{title}} title.",
			soloSame: "Score as above and gain the {{title}} title.",
			titleAward: "Gain the {{title}} title.",
			heartAward: "Give {{n}} affection hearts.",
			empty: "Free",
			selected: "Planned",
			proposedDates: "Proposed: Week {{week}}, {{from}} to {{to}}",
			proposedDay: "Proposed event date",
			entry: "{{name}}, {{n}} points",
			detail: "Diary detail",
			close: "Close",
			legend: "Consecutive days share one event score.",
			ending: "Summer report",
			winner: "{{name}} had the best summer",
			tie: "Shared victory: {{names}}",
			activityScore: "Events",
			homeworkScore: "Homework",
			titleScore: "Titles",
			friendshipScore: "Friendship",
			total: "Total",
			details: "Score details",
			review: "Review calendar",
			results: "Back to report",
			given: "To {{name}}: {{n}} hearts",
			noHearts: "No affection given yet.",
			confirmAgain: "Start a new summer?",
			confirmLobby: "Return to the lobby?",
			error: "That action is unavailable now. Follow the current prompt.",
			hintSchedule: "Start the event on {{day}}.",
			hintAttend: "Join this event.",
			hintDecline: "Keep the dates free for homework.",
			hintHeart: "Give affection to {{names}}."
		}
	}
};
//#endregion
export { $e as default };
