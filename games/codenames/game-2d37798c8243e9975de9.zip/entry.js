import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import n from "@bgparty/sdk/word-list";
import { useRef as r, useState as i } from "react";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { ConfirmButton as o } from "@bgparty/sdk/confirm-button";
import { useT as s } from "@bgparty/sdk/i18n";
import { IconShuffle as c } from "@bgparty/sdk/icons";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { AVATARS as u } from "@bgparty/sdk/avatars";
import { useFxAnchor as d } from "@bgparty/sdk/fx/anchors";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { TeamMedal as h } from "@bgparty/sdk/team-medal";
import { playTurn as g, useSoundEdge as _ } from "@bgparty/sdk/sfx";
import { Floater as v } from "@bgparty/sdk/fx/primitives";
import { Confetti as y } from "@bgparty/sdk/ui/confetti";
//#region src/games/codenames/meta.ts
var b = {
	id: "codenames",
	tier: "released",
	mechanics: ["word-association"],
	interactionTags: ["team-based"],
	nameKey: "games.codenames.name",
	descKey: "games.codenames.desc",
	rulesKey: "games.codenames.rules",
	icon: "🕵️",
	iconImg: "games/codenames.webp",
	rulesUrl: { en: "https://filemanager.czechgames.com/storage/files/codenames/rules/CN%20rulebook%20EN%2030.pdf" },
	minPlayers: 4,
	maxPlayers: 10,
	bestPlayers: [6, 8],
	accent: "#7c3aed",
	releasedAt: "2026-09-10",
	search: {
		py: "xing dong dai hao",
		init: "xddh"
	},
	hotseat: "cover"
}, x = t.string(), S = t.enum(["red", "blue"]), C = t.enum([
	"red",
	"blue",
	"neutral",
	"assassin"
]), w = t.int().min(0).max(24), T = t.string().trim().min(1).max(12), E = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("teams:set"),
		teams: t.object({
			red: t.array(x),
			blue: t.array(x)
		}),
		captains: t.object({
			red: x.nullable(),
			blue: x.nullable()
		})
	}),
	t.object({ type: t.literal("teams:shuffle") }),
	t.object({ type: t.literal("teams:start") }),
	t.object({
		type: t.literal("clue:give"),
		word: T,
		count: t.int().min(0).max(9)
	}),
	t.object({
		type: t.literal("guess:tap"),
		index: w
	}),
	t.object({ type: t.literal("guess:pass") })
]), D = t.object({
	red: t.array(x),
	blue: t.array(x)
}), O = t.object({
	red: x.nullable(),
	blue: x.nullable()
}), k = t.object({
	word: t.string(),
	count: t.int().nonnegative()
}), A = t.object({
	rid: x,
	index: w,
	cell: C
}), j = k.extend({
	team: S,
	by: x,
	guesses: t.array(A)
}), M = t.object({
	phase: t.enum([
		"teams",
		"clue",
		"guess",
		"done"
	]),
	players: t.array(x),
	teams: D,
	captains: O,
	words: t.array(t.string()),
	revealed: t.array(C.nullable()),
	starting: S.nullable(),
	turn: S.nullable(),
	clue: k.nullable(),
	guessesLeft: t.int().nonnegative(),
	proposal: t.object({
		rid: x,
		index: w
	}).nullable(),
	clueLog: t.array(j),
	winner: S.nullable(),
	byAssassin: t.boolean(),
	finalKey: t.array(C).nullable()
}), ee = t.object({ key: t.array(C) }), N = n;
function P(e) {
	return e === "red" ? "blue" : "red";
}
function F(t, n, r) {
	let i = [...r];
	for (let r = i.length - 1; r > 0; --r) {
		let a = e(t, n, r + 1);
		n += 1, [i[r], i[a]] = [i[a], i[r]];
	}
	return {
		out: i,
		cursor: n
	};
}
function I(e, t, n) {
	let { out: r, cursor: i } = F(e, t, n), a = Math.ceil(r.length / 2), o = {
		red: r.slice(0, a),
		blue: r.slice(a)
	};
	return {
		teams: o,
		captains: {
			red: o.red[0] ?? null,
			blue: o.blue[0] ?? null
		},
		cursor: i
	};
}
function L(e, t, n) {
	let r = I(n, 0, t);
	return { state: {
		players: t,
		phase: "teams",
		teams: r.teams,
		captains: r.captains,
		seed: n,
		rngCursor: r.cursor,
		words: [],
		key: [],
		revealed: [],
		starting: null,
		turn: null,
		clue: null,
		guessesLeft: 0,
		proposal: null,
		clueLog: [],
		winner: null,
		byAssassin: !1
	} };
}
function R(t) {
	let n = t.seed, r = t.rngCursor, i = F(n, r, N);
	r = i.cursor, t.words = i.out.slice(0, 25);
	let a = e(n, r, 2) === 0 ? "red" : "blue";
	r += 1;
	let o = F(n, r, [
		...Array(9).fill(a),
		...Array(8).fill(P(a)),
		...Array(7).fill("neutral"),
		"assassin"
	]);
	r = o.cursor, t.key = o.out, t.starting = a, t.turn = a, t.revealed = Array(25).fill(null), t.rngCursor = r;
}
function z(e, t) {
	let n = 0;
	for (let r = 0; r < e.key.length; r += 1) e.key[r] === t && !e.revealed[r] && (n += 1);
	return n;
}
function B(e) {
	e.clue = null, e.guessesLeft = 0, e.proposal = null, e.turn = P(e.turn), e.phase = "clue";
}
function V(e, t, n) {
	e.winner = t, e.byAssassin = n, e.phase = "done", e.proposal = null;
}
function te(e) {
	let t = [...e.teams.red, ...e.teams.blue];
	return new Set(t).size === t.length && t.every((t) => e.players.includes(t));
}
function ne(e, t, n) {
	let r = n.by === e.players[0];
	if (t.type === "teams:set") {
		if (e.phase !== "teams" || !r) return { code: "games.codenames.errNotHost" };
		let n = [...t.teams.red, ...t.teams.blue];
		if (new Set(n).size !== n.length || !n.every((t) => e.players.includes(t)) || t.captains.red !== null && !t.teams.red.includes(t.captains.red) || t.captains.blue !== null && !t.teams.blue.includes(t.captains.blue)) return { code: "games.codenames.errBadTeams" };
		let i = structuredClone(e);
		return i.teams = {
			red: [...t.teams.red],
			blue: [...t.teams.blue]
		}, i.captains = { ...t.captains }, { state: i };
	}
	if (t.type === "teams:shuffle") {
		if (e.phase !== "teams" || !r) return { code: "games.codenames.errNotHost" };
		let t = structuredClone(e), n = I(t.seed, t.rngCursor, t.players);
		return t.teams = n.teams, t.captains = n.captains, t.rngCursor = n.cursor, { state: t };
	}
	if (t.type === "teams:start") {
		if (e.phase !== "teams" || !r) return { code: "games.codenames.errNotHost" };
		if (!te(e)) return { code: "games.codenames.errBadTeams" };
		if (!([...e.teams.red, ...e.teams.blue].length === e.players.length && e.teams.red.length >= 2 && e.teams.blue.length >= 2 && e.captains.red !== null && e.captains.blue !== null)) return { code: "games.codenames.errTeamsNotReady" };
		let t = structuredClone(e);
		return R(t), t.phase = "clue", { state: t };
	}
	if (t.type === "clue:give") {
		if (e.phase !== "clue" || e.turn === null || e.captains[e.turn] !== n.by) return { code: "games.codenames.errNotCaptain" };
		let r = t.word;
		for (let t = 0; t < e.words.length; t += 1) {
			if (e.revealed[t]) continue;
			let n = e.words[t];
			if (r === n || r.includes(n) || n.includes(r)) return { code: "games.codenames.errClueWord" };
		}
		let i = structuredClone(e);
		return i.clue = {
			word: r,
			count: t.count
		}, i.guessesLeft = t.count + 1, i.proposal = null, i.clueLog = [...i.clueLog, {
			team: e.turn,
			word: r,
			count: t.count,
			by: n.by,
			guesses: []
		}], i.phase = "guess", { state: i };
	}
	if (t.type === "guess:tap") {
		let r = e.turn;
		if (e.phase !== "guess" || r === null || !e.teams[r].includes(n.by) || e.captains[r] === n.by) return { code: "games.codenames.errNotGuesser" };
		if (e.revealed[t.index] !== null) return { code: "games.codenames.errBadCell" };
		let i = e.proposal;
		if (!i || i.rid !== n.by || i.index !== t.index) {
			let r = structuredClone(e);
			return r.proposal = {
				rid: n.by,
				index: t.index
			}, { state: r };
		}
		let a = structuredClone(e), o = a.key[t.index];
		return a.revealed[t.index] = o, a.proposal = null, a.clueLog[a.clueLog.length - 1].guesses.push({
			rid: n.by,
			index: t.index,
			cell: o
		}), o === "assassin" ? (V(a, P(r), !0), {
			state: a,
			fx: [{
				kind: "assassin",
				rid: n.by,
				data: { index: t.index }
			}]
		}) : z(a, "red") === 0 || z(a, "blue") === 0 ? (V(a, z(a, "red") === 0 ? "red" : "blue", !1), {
			state: a,
			fx: [{
				kind: "reveal",
				rid: n.by,
				data: {
					index: t.index,
					cell: o
				}
			}]
		}) : (o === r ? (--a.guessesLeft, a.guessesLeft <= 0 && B(a)) : B(a), {
			state: a,
			fx: [{
				kind: "reveal",
				rid: n.by,
				data: {
					index: t.index,
					cell: o
				}
			}]
		});
	}
	let i = e.turn;
	if (e.phase !== "guess" || i === null || !e.teams[i].includes(n.by) || e.captains[i] === n.by) return { code: "games.codenames.errNotGuesser" };
	let a = structuredClone(e);
	return B(a), { state: a };
}
function H(e, t) {
	let n = e.captains.red === t || e.captains.blue === t;
	return {
		public: {
			phase: e.phase,
			players: e.players,
			teams: e.teams,
			captains: e.captains,
			words: e.words,
			revealed: e.revealed,
			starting: e.starting,
			turn: e.turn,
			clue: e.clue,
			guessesLeft: e.guessesLeft,
			proposal: e.proposal,
			clueLog: e.clueLog,
			winner: e.winner,
			byAssassin: e.byAssassin,
			finalKey: e.phase === "done" ? e.key : null
		},
		private: n && e.phase !== "teams" ? { key: e.key } : void 0
	};
}
function U(e) {
	if (e.phase !== "done" || e.winner === null) return { phase: e.phase };
	let t = e.winner, n = P(t), r = (t) => {
		let n = e.captains[t];
		return n ? [n, ...e.teams[t].filter((e) => e !== n)] : e.teams[t];
	};
	return {
		phase: "done",
		winner: [...e.teams[t]],
		ranking: [...r(t), ...r(n)]
	};
}
var W = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: b,
	schemas: {
		action: E,
		publicView: M,
		privateView: ee
	},
	setup: L,
	reduce: ne,
	viewFor: H,
	status: U
}, G = [
	{
		max: 2,
		cls: "cn-word-short"
	},
	{
		max: 4,
		cls: "cn-word-medium"
	},
	{
		max: Infinity,
		cls: "cn-word-long"
	}
];
function K(e) {
	let t = Math.max(0, ...e.map((e) => [...e].reduce((e, t) => e + (/[⺀-鿿！-･]/.test(t) ? 1 : .55), 0)));
	return G.find((e) => t <= e.max)?.cls ?? "cn-word-long";
}
function q({ kind: e, className: t = "" }) {
	return /* @__PURE__ */ m("svg", {
		className: t,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: [
			e === "red" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "m12 2 8 3v7c0 5-3 8-8 10-5-2-8-5-8-10V5z" }), /* @__PURE__ */ p("path", { d: "m12 7 4 5-4 5-4-5z" })] }),
			e === "blue" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12",
				r: "9"
			}), /* @__PURE__ */ p("path", { d: "m12 4 1.9 6.1L20 12l-6.1 1.9L12 20l-1.9-6.1L4 12l6.1-1.9z" })] }),
			e === "neutral" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12",
				r: "8"
			}), /* @__PURE__ */ p("path", { d: "M12 7v10M7 12h10" })] }),
			e === "assassin" && /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("circle", {
					cx: "12",
					cy: "12",
					r: "7"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "12",
					cy: "12",
					r: "2",
					fill: "currentColor",
					stroke: "none"
				}),
				/* @__PURE__ */ p("path", { d: "M12 1v5M12 18v5M1 12h5M18 12h5" })
			] })
		]
	});
}
function J({ words: e, revealed: t, captainKey: n, finalKey: r, proposal: i = null, members: a = [], myRid: o, canGuess: s = !1, onTap: c }) {
	return /* @__PURE__ */ p("div", {
		className: "cn-board-grid",
		children: e.map((e, l) => /* @__PURE__ */ p(Y, {
			index: l,
			word: e,
			revealed: t[l] ?? null,
			secretKind: n?.[l],
			finalKind: r?.[l],
			proposer: i?.index === l ? a.find((e) => e.rid === i.rid) : void 0,
			proposedBy: i?.index === l ? i.rid : void 0,
			myRid: o,
			canGuess: s,
			onTap: c
		}, l))
	});
}
function Y({ index: e, word: t, revealed: n, secretKind: r, finalKind: i, proposer: a, proposedBy: o, myRid: c, canGuess: l, onTap: h }) {
	let g = s(), { ref: _, hidden: v } = d(`cell:${e}`), y = i !== void 0, b = n ?? i ?? r, x = r !== void 0 && !y, S = n !== null || y, C = !S && o !== void 0, w = C && o === c, T = l && !S && h !== void 0, E = x && n !== null ? "captain-revealed" : S ? "revealed" : x ? "secret" : "hidden", D = g(b === "red" ? "games.codenames.red" : b === "blue" ? "games.codenames.blue" : b === "neutral" ? "games.codenames.neutral" : "games.codenames.assassin"), O = S || x ? g("games.codenames.cardIdentity", {
		word: t,
		identity: D
	}) : C && a ? g("games.codenames.cardProposal", {
		word: t,
		name: a.name
	}) : t, k = `cn-card ${K([t])} ${v ? "cn-card-hidden-fx" : ""}`, A = y && n === null ? { animationDelay: `${e * 45}ms` } : void 0, j = /* @__PURE__ */ m(f, { children: [
		!S && /* @__PURE__ */ p("span", {
			className: "cn-card-index",
			"aria-hidden": "true",
			children: String(e + 1).padStart(2, "0")
		}),
		b && S && !x && /* @__PURE__ */ p(q, {
			kind: b,
			className: "cn-card-mark"
		}),
		b && x && n !== null && /* @__PURE__ */ p("span", {
			className: "cn-card-small-mark",
			children: /* @__PURE__ */ p(q, { kind: b })
		}),
		b && x && n === null && /* @__PURE__ */ p("span", {
			className: "cn-card-key-mark",
			children: /* @__PURE__ */ p(q, { kind: b })
		}),
		/* @__PURE__ */ p("span", {
			className: "cn-card-word",
			children: t
		}),
		C && /* @__PURE__ */ p("span", {
			className: "cn-card-pin",
			"aria-hidden": "true"
		}),
		C && a && /* @__PURE__ */ p("img", {
			className: "cn-card-proposer",
			src: u[a.avatar % u.length],
			alt: "",
			draggable: !1
		}),
		x && n !== null && /* @__PURE__ */ p("span", {
			className: "cn-card-check",
			"aria-hidden": "true",
			children: "✓"
		})
	] });
	return y ? /* @__PURE__ */ p("div", {
		className: `${k} ${n === null ? "cn-card-final-enter" : ""}`,
		"data-state": "revealed",
		"data-kind": b,
		style: A,
		"aria-label": O,
		children: j
	}) : /* @__PURE__ */ p("button", {
		ref: _,
		type: "button",
		className: k,
		"data-state": E,
		"data-kind": b,
		"data-proposed": C ? "true" : void 0,
		"data-own-proposal": w ? "true" : void 0,
		"aria-label": O,
		disabled: !T,
		onClick: () => h?.(e),
		children: j
	});
}
//#endregion
//#region src/games/codenames/teams.ts
var X = {
	red: "#d74747",
	blue: "#367fbe"
}, Z = {
	red: "games.codenames.red",
	blue: "games.codenames.blue"
};
//#endregion
//#region src/games/codenames/history-sheet.tsx
function re({ word: e, cell: t }) {
	return /* @__PURE__ */ m("span", {
		className: "cn-log-chip",
		"data-kind": t,
		children: [/* @__PURE__ */ p(q, { kind: t }), e]
	});
}
function Q({ open: e, onClose: t, pub: n, members: r }) {
	let i = s(), o = (e) => r.find((t) => t.rid === e)?.name ?? e;
	return /* @__PURE__ */ p(a, {
		open: e,
		onClose: t,
		label: i("games.codenames.historyTitle"),
		children: /* @__PURE__ */ p("ol", {
			className: "cn-history-list",
			children: [...n.clueLog].reverse().map((e, t) => /* @__PURE__ */ m("li", {
				className: "cn-history-round",
				"data-team": e.team,
				children: [/* @__PURE__ */ m("p", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ p(q, {
						kind: e.team,
						className: "size-5 flex-none"
					}), /* @__PURE__ */ p("span", {
						className: "min-w-0 flex-1 truncate",
						children: i("games.codenames.historyClue", {
							name: o(e.by),
							word: e.word,
							count: e.count
						})
					})]
				}), e.guesses.map((e, t) => /* @__PURE__ */ m("p", {
					className: "flex items-center gap-1.5 pl-5 text-xs font-bold",
					children: [/* @__PURE__ */ p("span", {
						className: "min-w-0 truncate",
						children: i("games.codenames.historyGuess", { name: o(e.rid) })
					}), /* @__PURE__ */ p(re, {
						word: n.words[e.index] ?? "",
						cell: e.cell
					})]
				}, t))]
			}, t))
		})
	});
}
//#endregion
//#region src/games/codenames/play-view.tsx
function ie(e, t) {
	return e.teams.red.includes(t) ? "red" : e.teams.blue.includes(t) ? "blue" : null;
}
function ae({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let o = s(), [c, u] = i(!1), [d, f] = i(""), [h, v] = i(1), y = ie(e, r), b = e.captains.red === r || e.captains.blue === r, x = e.turn !== null && y === e.turn, S = e.phase === "clue" && x && e.captains[e.turn] === r, C = e.phase === "guess" && x && !b, w = e.turn ?? "red", T = o(Z[w]), E = e.phase === "clue" ? o("games.codenames.turnClue", { team: T }) : o("games.codenames.turnGuess", { team: T }), D = X[w], O = () => {
		let e = d.trim();
		e && (a({
			type: "clue:give",
			word: e,
			count: h
		}), f(""));
	};
	_(S || C, g);
	let k = /* @__PURE__ */ p(ce, {
		pub: e,
		members: n,
		myRid: r,
		canGuess: C,
		givingClue: S,
		word: d,
		setWord: f,
		count: h,
		setCount: v,
		submit: O,
		send: a
	});
	return /* @__PURE__ */ m("div", {
		className: "cn-screen",
		style: { "--cn-turn-color": D },
		children: [/* @__PURE__ */ p(l, {
			adaptive: !0,
			className: "cn-play-layout",
			banner: /* @__PURE__ */ m("div", {
				className: "cn-header",
				role: "status",
				children: [/* @__PURE__ */ m("div", {
					className: "cn-header-title",
					children: [/* @__PURE__ */ p("strong", { children: o("games.codenames.name") }), /* @__PURE__ */ p("small", { children: o("games.codenames.round", { n: e.clueLog.length + +(e.phase === "clue") }) })]
				}), /* @__PURE__ */ p("span", {
					className: "cn-header-state",
					children: E
				})]
			}),
			actionsHeight: "h-36 short:h-0",
			actions: /* @__PURE__ */ p("div", {
				className: "cn-actions",
				children: k
			}),
			children: /* @__PURE__ */ m("div", {
				className: "cn-content",
				children: [/* @__PURE__ */ m("div", {
					className: "cn-board-stage",
					children: [/* @__PURE__ */ m("div", {
						className: "cn-board-top",
						children: [/* @__PURE__ */ p("strong", { children: o(b ? "games.codenames.keyBoard" : "games.codenames.wordBoard") }), e.clueLog.length > 0 && /* @__PURE__ */ p("button", {
							type: "button",
							className: "cn-history",
							onClick: () => u(!0),
							children: o("games.codenames.history", { n: e.clueLog.length })
						})]
					}), /* @__PURE__ */ p(J, {
						words: e.words,
						revealed: e.revealed,
						captainKey: t?.key,
						proposal: e.proposal,
						members: n,
						myRid: r,
						canGuess: C,
						onTap: (e) => a({
							type: "guess:tap",
							index: e
						})
					})]
				}), /* @__PURE__ */ m("div", {
					className: "cn-side",
					children: [
						/* @__PURE__ */ p(oe, { pub: e }),
						/* @__PURE__ */ p(se, {
							pub: e,
							givingClue: S,
							turnColor: D
						}),
						/* @__PURE__ */ p("div", {
							className: "cn-landscape-actions",
							children: k
						})
					]
				})]
			})
		}), /* @__PURE__ */ p(Q, {
			open: c,
			onClose: () => u(!1),
			pub: e,
			members: n
		})]
	});
}
function oe({ pub: e }) {
	let t = s();
	return /* @__PURE__ */ p("div", {
		className: "cn-scores",
		children: ["red", "blue"].map((n) => {
			let r = e.starting === n ? 9 : 8, i = r - e.revealed.filter((e) => e === n).length;
			return /* @__PURE__ */ m("div", {
				className: "cn-score",
				"data-team": n,
				"data-active": e.turn === n,
				children: [
					/* @__PURE__ */ p("span", {
						className: "cn-score-emblem",
						children: /* @__PURE__ */ p(q, { kind: n })
					}),
					/* @__PURE__ */ p("span", {
						className: "cn-score-name",
						children: t(Z[n])
					}),
					/* @__PURE__ */ p("span", {
						className: "cn-score-dots",
						"aria-hidden": "true",
						children: Array.from({ length: r }, (e, t) => /* @__PURE__ */ p("i", { "data-empty": t >= i }, t))
					}),
					/* @__PURE__ */ m("span", {
						className: "cn-score-count font-mono tabular-nums",
						"aria-label": t("games.codenames.remaining", {
							n: i,
							total: r
						}),
						children: [i, /* @__PURE__ */ m("small", { children: ["/", r] })]
					})
				]
			}, n);
		})
	});
}
function se({ pub: e, givingClue: t, turnColor: n }) {
	let r = s(), i = e.phase === "clue";
	return /* @__PURE__ */ p("div", {
		className: "cn-telegram",
		style: { "--cn-turn-color": n },
		children: /* @__PURE__ */ m("div", {
			className: "cn-telegram-inner",
			children: [/* @__PURE__ */ m("div", {
				className: "cn-telegram-copy",
				children: [/* @__PURE__ */ p("span", {
					className: "cn-telegram-label",
					children: r("games.codenames.clueLabel")
				}), /* @__PURE__ */ p("span", {
					className: "cn-telegram-word",
					"data-pending": i,
					children: i ? r(t ? "games.codenames.cluePending" : "games.codenames.clueWaiting") : e.clue?.word
				})]
			}), i ? /* @__PURE__ */ p(q, {
				kind: e.turn ?? "red",
				className: "cn-telegram-pending-mark"
			}) : /* @__PURE__ */ m("div", {
				className: "cn-telegram-right",
				children: [/* @__PURE__ */ m("span", {
					className: "cn-telegram-count font-mono tabular-nums",
					children: ["×", e.clue?.count ?? 0]
				}), /* @__PURE__ */ p("span", {
					className: "cn-telegram-left",
					children: r("games.codenames.guessesLeft", { n: e.guessesLeft })
				})]
			})]
		})
	});
}
function ce({ pub: e, members: t, myRid: n, canGuess: r, givingClue: i, word: a, setWord: c, count: l, setCount: d, submit: h, send: g }) {
	let _ = s();
	if (i) return /* @__PURE__ */ p(le, {
		word: a,
		setWord: c,
		count: l,
		setCount: d,
		submit: h
	});
	if (r) {
		let r = e.proposal, i = r ? t.find((e) => e.rid === r.rid) : void 0, a = r?.rid === n;
		return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("div", {
			className: "cn-proposal",
			"data-active": r !== null,
			"data-own": a,
			children: [
				i && /* @__PURE__ */ p("img", {
					className: "cn-proposal-avatar",
					src: u[i.avatar % u.length],
					alt: ""
				}),
				/* @__PURE__ */ p("span", {
					className: "cn-proposal-text",
					children: r ? _(a ? "games.codenames.proposalMine" : "games.codenames.proposalOther", {
						word: e.words[r.index] ?? "",
						name: i?.name ?? ""
					}) : _("games.codenames.tapToPropose")
				}),
				a && /* @__PURE__ */ p("span", {
					className: "cn-proposal-next",
					children: _("games.codenames.tapToReveal")
				})
			]
		}), /* @__PURE__ */ p(o, {
			className: "cn-pass",
			label: _("games.codenames.pass"),
			confirmLabel: _("games.codenames.passConfirm"),
			ariaLabel: _("games.codenames.pass"),
			onConfirm: () => g({ type: "guess:pass" })
		})] });
	}
	return /* @__PURE__ */ p("div", {
		className: "cn-proposal",
		children: e.phase === "clue" ? _("games.codenames.clueWaiting") : _("games.codenames.waitGuessers")
	});
}
function le({ word: e, setWord: t, count: n, setCount: r, submit: i }) {
	let a = s();
	return /* @__PURE__ */ m("div", {
		className: "cn-clue-form",
		children: [
			/* @__PURE__ */ m("div", {
				className: "cn-clue-labels",
				children: [/* @__PURE__ */ p("span", { children: a("games.codenames.cluePlaceholder") }), /* @__PURE__ */ p("span", { children: a("games.codenames.clueCount") })]
			}),
			/* @__PURE__ */ m("div", {
				className: "cn-clue-controls",
				children: [/* @__PURE__ */ p("input", {
					className: "cn-clue-input",
					value: e,
					maxLength: 12,
					placeholder: a("games.codenames.cluePlaceholder"),
					"aria-label": a("games.codenames.cluePlaceholder"),
					onChange: (e) => t(e.target.value),
					onKeyDown: (e) => {
						e.key === "Enter" && i();
					}
				}), /* @__PURE__ */ m("div", {
					className: "cn-stepper",
					children: [
						/* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": a("games.codenames.countDecrease"),
							disabled: n <= 0,
							onClick: () => r(n - 1),
							children: "−"
						}),
						/* @__PURE__ */ p("output", {
							"aria-label": a("games.codenames.clueCountAria", { n }),
							children: n
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": a("games.codenames.countIncrease"),
							disabled: n >= 9,
							onClick: () => r(n + 1),
							children: "+"
						})
					]
				})]
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: "cn-submit",
				disabled: !e.trim(),
				onClick: i,
				children: [a("games.codenames.clueGive"), " ›"]
			})
		]
	});
}
//#endregion
//#region src/games/codenames/view-player.tsx
function ue(e) {
	let t = e.public, n = e.private;
	return t.phase === "teams" ? /* @__PURE__ */ p(fe, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	}) : /* @__PURE__ */ p(ae, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function de(e, t) {
	return e.teams.red.includes(t) ? "red" : e.teams.blue.includes(t) ? "blue" : null;
}
function $(e, t, n) {
	let r = {
		red: e.teams.red.filter((e) => e !== t),
		blue: e.teams.blue.filter((e) => e !== t)
	}, i = {
		red: e.captains.red === t ? null : e.captains.red,
		blue: e.captains.blue === t ? null : e.captains.blue
	};
	return (n === "red" || n === "red-captain") && r.red.push(t), (n === "blue" || n === "blue-captain") && r.blue.push(t), n === "red-captain" && (i.red = t), n === "blue-captain" && (i.blue = t), {
		teams: r,
		captains: i
	};
}
function fe({ pub: e, members: t, myRid: n, send: u }) {
	let d = s(), f = e.players[0] === n, [g, _] = i(null), [v, y] = i(null), [b, x] = i(null), S = r(!1), C = r(/* @__PURE__ */ new Map()), w = (e, t) => {
		for (let n of [
			"red-captain",
			"blue-captain",
			"red",
			"blue",
			"pool"
		]) {
			let r = C.current.get(n);
			if (!r) continue;
			let i = r.getBoundingClientRect();
			if (e >= i.left && e <= i.right && t >= i.top && t <= i.bottom) return n;
		}
		return null;
	}, T = (t, n) => {
		if (!f) return;
		let r = n.clientX, i = n.clientY, a = !1, o = (e) => {
			!a && Math.hypot(e.clientX - r, e.clientY - i) < 8 || (a = !0, S.current = !0, _({
				rid: t,
				x: e.clientX,
				y: e.clientY
			}), y(w(e.clientX, e.clientY)));
		}, s = (n) => {
			if (window.removeEventListener("pointermove", o), window.removeEventListener("pointercancel", s), a) {
				let r = w(n.clientX, n.clientY);
				if (r) {
					let n = $(e, t, r);
					u({
						type: "teams:set",
						teams: n.teams,
						captains: n.captains
					});
				}
			}
			_(null), y(null), window.setTimeout(() => {
				S.current = !1;
			}, 0);
		};
		window.addEventListener("pointermove", o), window.addEventListener("pointerup", s, { once: !0 }), window.addEventListener("pointercancel", s, { once: !0 });
	}, E = e.players.filter((t) => de(e, t) === null), D = (e) => t.find((t) => t.rid === e), O = (e) => {
		S.current || x(e);
	}, k = (t) => {
		if (!b) return;
		let n = $(e, b, t);
		u({
			type: "teams:set",
			teams: n.teams,
			captains: n.captains
		}), x(null);
	};
	return /* @__PURE__ */ p(l, {
		adaptive: !0,
		className: "cn-teams-layout",
		banner: /* @__PURE__ */ p("div", {
			className: "cn-teams-banner",
			children: d(f ? "games.codenames.teamsTitle" : "games.codenames.teamsWait")
		}),
		actionsHeight: f ? "h-14" : void 0,
		actions: f && /* @__PURE__ */ m("div", {
			className: "cn-team-buttons",
			children: [/* @__PURE__ */ m("button", {
				type: "button",
				className: "btn-quiet flex-1 cursor-pointer",
				onClick: () => u({ type: "teams:shuffle" }),
				children: [/* @__PURE__ */ p(c, { size: 16 }), d("games.codenames.shuffle")]
			}), /* @__PURE__ */ p(o, {
				className: "flex-1",
				label: d("games.codenames.startGame"),
				confirmLabel: d("games.codenames.startGameConfirm"),
				ariaLabel: d("games.codenames.startGame"),
				onConfirm: () => u({ type: "teams:start" })
			})]
		}),
		scroll: !1,
		children: /* @__PURE__ */ m("div", {
			className: "cn-teams",
			children: [
				/* @__PURE__ */ p("div", {
					className: "cn-team-columns",
					children: ["red", "blue"].map((t) => /* @__PURE__ */ p(pe, {
						team: t,
						rids: e.teams[t],
						captain: e.captains[t],
						memberOf: D,
						editable: f,
						draggingRid: g?.rid ?? null,
						hover: v,
						zoneRef: (e, t) => {
							t ? C.current.set(e, t) : C.current.delete(e);
						},
						onStartDrag: T,
						onSelect: O
					}, t))
				}),
				E.length > 0 && /* @__PURE__ */ m("div", {
					ref: (e) => {
						e ? C.current.set("pool", e) : C.current.delete("pool");
					},
					className: "cn-team-pool",
					"data-hover": v === "pool",
					children: [/* @__PURE__ */ p("span", {
						className: "section-label",
						children: d("games.codenames.unassigned")
					}), E.map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "cn-team-choice",
						disabled: !f,
						onClick: () => O(e),
						children: /* @__PURE__ */ p(h, {
							member: D(e),
							rid: e,
							editable: f,
							dragging: g?.rid === e,
							onStartDrag: T
						})
					}, e))]
				}),
				g && /* @__PURE__ */ p("div", {
					className: "cn-team-drag pointer-events-none fixed z-50",
					style: {
						left: g.x,
						top: g.y,
						transform: "translate(-50%, -70%)"
					},
					children: /* @__PURE__ */ p(h, {
						member: D(g.rid),
						rid: g.rid,
						floating: !0
					})
				}),
				/* @__PURE__ */ p(a, {
					open: b !== null,
					onClose: () => x(null),
					label: d("games.codenames.assignMember", { name: D(b ?? "")?.name ?? "" }),
					children: /* @__PURE__ */ m("div", {
						className: "cn-team-assignment grid grid-cols-2 gap-2",
						children: [[
							"red",
							"red-captain",
							"blue",
							"blue-captain"
						].map((e) => /* @__PURE__ */ p("button", {
							type: "button",
							className: "btn-base bg-surface text-sm",
							onClick: () => k(e),
							children: d(e === "red" ? "games.codenames.red" : e === "blue" ? "games.codenames.blue" : e === "red-captain" ? "games.codenames.redCaptain" : "games.codenames.blueCaptain")
						}, e)), /* @__PURE__ */ p("button", {
							type: "button",
							className: "btn-quiet col-span-2",
							onClick: () => k("pool"),
							children: d("games.codenames.unassigned")
						})]
					})
				})
			]
		})
	});
}
function pe({ team: e, rids: t, captain: n, memberOf: r, editable: i, draggingRid: a, hover: o, zoneRef: c, onStartDrag: l, onSelect: u }) {
	let d = s(), f = e === "red" ? "red-captain" : "blue-captain";
	return /* @__PURE__ */ m("section", {
		ref: (t) => c(e, t),
		className: "cn-team-column",
		style: { "--cn-team-size": Math.max(2, t.length) },
		"data-team": e,
		"data-hover": o === e,
		children: [
			/* @__PURE__ */ m("h3", {
				className: "cn-team-heading",
				children: [
					/* @__PURE__ */ p(q, { kind: e }),
					d(Z[e]),
					/* @__PURE__ */ p("span", {
						className: "font-mono tabular-nums",
						children: t.length
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				ref: (e) => c(f, e),
				className: "cn-team-captain",
				"data-hover": o === f,
				role: "group",
				"aria-label": d("games.codenames.captain"),
				children: [/* @__PURE__ */ p("span", {
					className: "cn-team-captain-label",
					"aria-hidden": !0,
					children: "👑"
				}), n ? /* @__PURE__ */ p("button", {
					type: "button",
					className: "cn-team-choice",
					disabled: !i,
					onClick: () => u(n),
					children: /* @__PURE__ */ p(h, {
						member: r(n),
						rid: n,
						editable: i,
						dragging: a === n,
						onStartDrag: l
					})
				}) : /* @__PURE__ */ p("span", {
					className: "text-xs font-bold opacity-60",
					children: i ? d("games.codenames.captainEmpty") : ""
				})]
			}),
			/* @__PURE__ */ p("div", {
				className: "cn-team-members",
				children: t.filter((e) => e !== n).map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "cn-team-choice",
					disabled: !i,
					onClick: () => u(e),
					children: /* @__PURE__ */ p(h, {
						member: r(e),
						rid: e,
						editable: i,
						dragging: a === e,
						onStartDrag: l
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region src/games/codenames/bot.ts
var me = (e, t) => {
	let n = e.public;
	if (n.phase === "clue" && n.turn && n.captains[n.turn] === t.rid) return { action: {
		type: "clue:give",
		word: `X${crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 900 + 100}`,
		count: 1
	} };
	if (n.phase === "guess" && n.turn) {
		let e = n.teams[n.turn].includes(t.rid), r = n.captains[n.turn] === t.rid;
		if (!e || r) return null;
		if (n.guessesLeft <= 1) return { action: { type: "guess:pass" } };
		if (n.proposal?.rid === t.rid) return { action: {
			type: "guess:tap",
			index: n.proposal.index
		} };
		let i = [];
		for (let e = 0; e < n.revealed.length; e += 1) n.revealed[e] === null && i.push(e);
		return i.length === 0 ? null : { action: {
			type: "guess:tap",
			index: i[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % i.length]
		} };
	}
	return null;
}, he = {
	reveal(e, t) {
		let n = e.data, r = typeof n?.index == "number" ? t.anchor(`cell:${n.index}`) : null;
		if (!r) return null;
		let i = n?.cell === "red" || n?.cell === "blue" || n?.cell === "neutral" || n?.cell === "assassin" ? n.cell : "neutral";
		return {
			ms: 550,
			node: /* @__PURE__ */ p(v, {
				at: r,
				ms: 550,
				children: /* @__PURE__ */ p("span", {
					className: "cn-fx-stamp",
					"data-kind": i,
					style: { "--cn-fx-size": `${Math.max(42, Math.min(r.w, r.h) * .55)}px` },
					children: /* @__PURE__ */ p(q, { kind: i })
				})
			})
		};
	},
	assassin(e, t) {
		let n = e.data, r = typeof n?.index == "number" ? t.anchor(`cell:${n.index}`) : null;
		return r ? {
			ms: 1050,
			node: /* @__PURE__ */ p(v, {
				at: r,
				ms: 1050,
				children: /* @__PURE__ */ p("span", {
					className: "cn-fx-stamp",
					"data-kind": "assassin",
					style: { "--cn-fx-size": `${Math.max(42, Math.min(r.w, r.h) * .55)}px` },
					children: /* @__PURE__ */ p(q, { kind: "assassin" })
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/codenames/game-over.tsx
function ge({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: a }) {
	let o = s(), c = t, [u, d] = i(!1), f = ["red", "blue"].find((t) => c.teams[t].length > 0 && e.winner.length === c.teams[t].length && c.teams[t].every((t) => e.winner.includes(t))) ?? null, g = c.phase === "done" && f !== null && c.winner === f, _ = g && c.byAssassin, v = f === null ? null : f === "red" ? "blue" : "red", x = r ?? a, S = c.phase === "done" ? c.finalKey : null, C = (e) => n.find((t) => t.rid === e), w = (t) => e.ranking.filter((e) => c.teams[t].includes(e));
	return /* @__PURE__ */ p(l, {
		adaptive: !0,
		className: "cn-over-layout",
		scroll: !1,
		children: /* @__PURE__ */ m("div", {
			className: "cn-game-over",
			children: [
				g && !_ && /* @__PURE__ */ p(y, {}),
				/* @__PURE__ */ m("h1", {
					className: "cn-game-over-heading",
					children: [/* @__PURE__ */ m("span", {
						"aria-hidden": "true",
						children: [_ ? "☠️" : "🏆", " "]
					}), f && v && g ? _ ? o("games.codenames.endByAssassin", {
						loser: o(Z[v]),
						winner: o(Z[f])
					}) : o("games.codenames.endBySweep", { team: o(Z[f]) }) : o("session.result.title")]
				}),
				/* @__PURE__ */ p("div", {
					className: "cn-game-over-board",
					children: /* @__PURE__ */ m("div", {
						className: "cn-board-stage",
						children: [/* @__PURE__ */ m("div", {
							className: "cn-board-top",
							children: [/* @__PURE__ */ p("strong", { children: o("games.codenames.endBoard") }), c.clueLog.length > 0 && /* @__PURE__ */ p("button", {
								type: "button",
								className: "cn-history",
								onClick: () => d(!0),
								children: o("games.codenames.history", { n: c.clueLog.length })
							})]
						}), /* @__PURE__ */ p(J, {
							words: c.words,
							revealed: c.revealed,
							finalKey: S
						})]
					})
				}),
				/* @__PURE__ */ m("div", {
					className: "cn-game-over-side",
					children: [f && v && /* @__PURE__ */ p("div", {
						className: "cn-game-over-teams",
						children: [f, v].map((e) => /* @__PURE__ */ m("div", {
							className: "cn-game-over-team",
							children: [/* @__PURE__ */ m("span", {
								className: "cn-game-over-team-name",
								style: { color: X[e] },
								children: [/* @__PURE__ */ p("span", {
									"aria-hidden": "true",
									children: e === f ? "🏆" : "  "
								}), o(Z[e])]
							}), /* @__PURE__ */ p("div", {
								className: "cn-game-over-team-list",
								children: w(e).map((t) => /* @__PURE__ */ p(h, {
									member: C(t),
									rid: t,
									crowned: c.captains[e] === t
								}, t))
							})]
						}, e))
					}), x ? /* @__PURE__ */ m("div", {
						className: "cn-game-over-actions safe-b mt-2 flex w-full flex-col gap-2 pb-1",
						children: [r && /* @__PURE__ */ p("button", {
							type: "button",
							className: "btn-base w-full cursor-pointer text-white",
							style: { background: b.accent },
							onClick: r,
							children: o("session.result.playAgain")
						}), a && /* @__PURE__ */ p("button", {
							type: "button",
							className: "btn-quiet w-full cursor-pointer",
							onClick: a,
							children: o("session.result.backToLobby")
						})]
					}) : /* @__PURE__ */ p("p", {
						className: "cn-game-over-wait safe-b mt-2 pb-1 text-center text-sm font-bold",
						children: o("session.result.waitHost")
					})]
				}),
				/* @__PURE__ */ p(Q, {
					open: u,
					onClose: () => d(!1),
					pub: c,
					members: n
				})
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/codenames/entry.tsx
var _e = {
	definition: W,
	View: ue,
	bot: me,
	fx: he,
	OverView: ge,
	locales: {
		zh: {
			name: "行动代号",
			desc: "红蓝对抗:队长一句话,队员猜词板",
			rules: "目标:按身份翻开词语,先找齐己方全部词的一队获胜。\n准备:\n· 全员分红蓝两队,每队至少 2 人,并各选一名队长。\n· 词板共 25 个词:先手队 9 个、后手队 8 个、中立 7 个、刺客 1 个;归属只有两名队长能看到。\n流程:\n· 两队轮流行动。轮到的一方由队长给出线索:一个词加一个数字,数字表示该线索指向几个己方的词。\n· 线索不能是词板上尚未翻开的词,也不能把它包含在内。\n· 队员在词板上点词:点一下提出候选,再点一下确认翻开;每回合最多翻「线索数字加 1」个,可随时主动结束回合。\n翻牌结果:\n· 己方词:可以继续猜。\n· 对方词:等于替对方翻开,回合结束。\n· 中立词:回合结束。\n· 刺客:本队立即落败。",
			red: "红队",
			blue: "蓝队",
			neutral: "路人",
			assassin: "刺客",
			teamsTitle: "分配队伍",
			teamsWait: "等待主机分组",
			captain: "队长",
			captainEmpty: "待任命",
			assignMember: "分配 {{name}}",
			redCaptain: "红队队长",
			blueCaptain: "蓝队队长",
			unassigned: "待分配",
			shuffle: "随机分组",
			startGame: "开始游戏",
			startGameConfirm: "确认分组,开局",
			clueYourTurn: "轮到你给线索",
			clueWait: "等{{team}}队长给线索…",
			cluePlaceholder: "线索词",
			clueGive: "发送线索",
			clueCount: "关联数",
			countDecrease: "减少关联数",
			countIncrease: "增加关联数",
			clueCountAria: "关联 {{n}} 个词",
			clueLabel: "本轮线索",
			cluePending: "待发送",
			clueWaiting: "等待线索",
			turnClue: "{{team}} · 给线索",
			turnGuess: "{{team}} · 猜词",
			round: "第 {{n}} 回合",
			remaining: "剩余 {{n}} / {{total}}",
			wordBoard: "代号词板",
			keyBoard: "队长密钥",
			cardIdentity: "{{word}}，{{identity}}",
			cardProposal: "{{word}}，{{name}}已提案",
			proposalMine: "提案 · {{word}}",
			proposalOther: "{{name}}提案 · {{word}}",
			tapToPropose: "点词提案",
			tapToReveal: "再点翻开",
			guessPrompt: "「{{word}}」× {{count}}",
			guessesLeft: "还可猜 {{n}} 个",
			guessHint: "点词提案,再点一次确认翻出",
			waitGuessers: "等待队员猜词",
			pass: "结束回合",
			passConfirm: "确认结束回合",
			history: "记录 {{n}}",
			historyTitle: "回合记录",
			historyClue: "{{name}}:「{{word}}」× {{count}}",
			historyGuess: "{{name}} 翻了",
			endBySweep: "{{team}}找齐全部线索,赢下本局!",
			endByAssassin: "{{loser}}翻到刺客,{{winner}}获胜!",
			endBoard: "最终局面",
			proposedBy: "{{name}} 提议",
			errNotHost: "只有主机能操作分组",
			errBadTeams: "分组里有重复或不在场的人",
			errTeamsNotReady: "全员都要入队,每队至少 2 人且有队长",
			errNotCaptain: "现在等队长给线索",
			errClueWord: "线索不能是板上没翻的词,也不能包含它",
			errNotGuesser: "现在轮不到你猜",
			errBadCell: "这张牌已经翻了"
		},
		en: {
			name: "Codenames",
			desc: "Red vs blue: one-word clues, team guesses",
			rules: "Goal: reveal words by identity; the first team to find all of its words wins.\nSetup:\n· Split into red and blue teams of at least 2 players each, with one captain per team.\n· The board holds 25 words: 9 for the starting team, 8 for the other team, 7 neutral, 1 assassin. Only the two captains can see the assignments.\nPlay:\n· Teams alternate. On your team’s turn the captain gives a clue: one word plus a number — the number is how many of your team’s words the clue points to.\n· The clue may not be a word still hidden on the board, nor contain one.\n· Teammates guess on the board: tap a word to propose it, tap again to confirm the reveal. At most the clue number plus one words may be revealed per turn, and the turn may be ended at any time.\nReveal results:\n· Your team’s word: keep guessing.\n· A rival word: revealed for their benefit; the turn ends.\n· A neutral word: the turn ends.\n· The assassin: your team loses immediately.",
			red: "Red",
			blue: "Blue",
			neutral: "Bystander",
			assassin: "Assassin",
			teamsTitle: "Assign teams",
			teamsWait: "Waiting for the host",
			captain: "Captain",
			captainEmpty: "Unassigned",
			assignMember: "Assign {{name}}",
			redCaptain: "Red captain",
			blueCaptain: "Blue captain",
			unassigned: "Unassigned",
			shuffle: "Shuffle",
			startGame: "Start game",
			startGameConfirm: "Confirm teams and start",
			clueYourTurn: "Your turn to give a clue",
			clueWait: "Waiting for the {{team}} captain…",
			cluePlaceholder: "Clue word",
			clueGive: "Send clue",
			clueCount: "Number",
			countDecrease: "Decrease clue number",
			countIncrease: "Increase clue number",
			clueCountAria: "Links {{n}} words",
			clueLabel: "Current clue",
			cluePending: "Not sent",
			clueWaiting: "Waiting for clue",
			turnClue: "{{team}} · clue",
			turnGuess: "{{team}} · guess",
			round: "Round {{n}}",
			remaining: "{{n}} / {{total}} left",
			wordBoard: "Codeword board",
			keyBoard: "Spymaster key",
			cardIdentity: "{{word}}, {{identity}}",
			cardProposal: "{{word}}, proposed by {{name}}",
			proposalMine: "Proposed · {{word}}",
			proposalOther: "{{name}} proposed · {{word}}",
			tapToPropose: "Tap a word to propose",
			tapToReveal: "Tap again",
			guessPrompt: "\"{{word}}\" × {{count}}",
			guessesLeft: "{{n}} guesses left",
			guessHint: "Tap a word to propose, tap again to reveal",
			waitGuessers: "Waiting for guesses",
			pass: "End turn",
			passConfirm: "Confirm end turn",
			history: "Log {{n}}",
			historyTitle: "Round log",
			historyClue: "{{name}}: \"{{word}}\" × {{count}}",
			historyGuess: "{{name}} flipped",
			endBySweep: "{{team}} found all their words and win!",
			endByAssassin: "{{loser}} hit the assassin — {{winner}} win!",
			endBoard: "Final board",
			proposedBy: "Proposed by {{name}}",
			errNotHost: "Only the host can edit teams",
			errBadTeams: "Duplicate or unknown player in teams",
			errTeamsNotReady: "Everyone must be on a team: 2+ players and a captain each",
			errNotCaptain: "Waiting for the captain to give a clue",
			errClueWord: "The clue cannot be or contain an unrevealed board word",
			errNotGuesser: "Not your turn to guess",
			errBadCell: "That card is already revealed"
		}
	}
};
//#endregion
export { _e as default };
