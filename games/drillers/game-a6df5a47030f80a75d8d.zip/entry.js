import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useId as i, useLayoutEffect as a, useMemo as o, useRef as s, useState as c } from "react";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { useFxAnchor as d, useFxAnchorsMaybe as f } from "@bgparty/sdk/fx/anchors";
import { IconBack as p, IconBot as m, IconCheck as h, IconClose as g, IconExpand as _, IconLog as ee, IconOptions as v, IconPile as y, IconSettings as te } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as b } from "@bgparty/sdk/player-colors";
import { useWakeLock as x } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as S } from "@bgparty/sdk/ui/game-screen";
import { Fragment as C, jsx as w, jsxs as T } from "react/jsx-runtime";
import { DeltaNumber as E } from "@bgparty/sdk/fx/delta-number";
import { seatName as D } from "@bgparty/sdk/ui/player-strip";
import { Confetti as ne } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as re, OptionSection as O } from "@bgparty/sdk/ui/game-options";
//#region src/games/drillers/data.ts
var k = [
	"silver",
	"gold",
	"sapphire",
	"emerald",
	"ruby"
], A = [
	"drilling",
	"movement",
	"utility",
	"advanced"
], j = {
	burner_drill: {
		id: "burner_drill",
		type: "drilling",
		cost: 0,
		fuel: 3,
		price: 6,
		vp: 0,
		solid: !0,
		permanent: !1,
		battery: !1
	},
	superior_soaker: {
		id: "superior_soaker",
		type: "drilling",
		cost: 1,
		fuel: 3,
		price: 4,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	all_in_one_tire: {
		id: "all_in_one_tire",
		type: "drilling",
		cost: 3,
		fuel: 4,
		price: 7,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	careless_drilling: {
		id: "careless_drilling",
		type: "drilling",
		cost: 3,
		fuel: 4,
		price: 9,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	mining_drone: {
		id: "mining_drone",
		type: "drilling",
		cost: 3,
		fuel: 3,
		price: 6,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	laser_cutter: {
		id: "laser_cutter",
		type: "drilling",
		cost: 3,
		fuel: 4,
		price: 7,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	reckless_drilling: {
		id: "reckless_drilling",
		type: "drilling",
		cost: 1,
		fuel: 3,
		price: 2,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	auto_drill: {
		id: "auto_drill",
		type: "drilling",
		cost: 1,
		fuel: 3,
		price: 5,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	dynamite_launcher: {
		id: "dynamite_launcher",
		type: "drilling",
		cost: 5,
		fuel: 3,
		price: 11,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	harpoon_drill: {
		id: "harpoon_drill",
		type: "drilling",
		cost: 3,
		fuel: 3,
		price: 9,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	jackhammer: {
		id: "jackhammer",
		type: "drilling",
		cost: 3,
		fuel: 3,
		price: 9,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	wrecking_ball: {
		id: "wrecking_ball",
		type: "drilling",
		cost: 0,
		fuel: 0,
		price: 11,
		vp: 0,
		solid: !1,
		permanent: !0,
		battery: !1
	},
	hover_pads: {
		id: "hover_pads",
		type: "movement",
		cost: 0,
		fuel: 0,
		price: 8,
		vp: 0,
		solid: !1,
		permanent: !0,
		battery: !1
	},
	rocket_engine: {
		id: "rocket_engine",
		type: "movement",
		cost: 2,
		fuel: 4,
		price: 7,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	panic_button: {
		id: "panic_button",
		type: "movement",
		cost: 0,
		fuel: 3,
		price: 0,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	wheels_on_heels: {
		id: "wheels_on_heels",
		type: "movement",
		cost: 1,
		fuel: 3,
		price: 5,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	rocket_drone: {
		id: "rocket_drone",
		type: "movement",
		cost: 1,
		fuel: 3,
		price: 4,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	rocket_drone_plus: {
		id: "rocket_drone_plus",
		type: "movement",
		cost: 1,
		fuel: 4,
		price: 9,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	footless_treads: {
		id: "footless_treads",
		type: "movement",
		cost: 1,
		fuel: 3,
		price: 5,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	flywheel: {
		id: "flywheel",
		type: "movement",
		cost: 1,
		fuel: 4,
		price: 3,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	atm_drone: {
		id: "atm_drone",
		type: "movement",
		cost: 1,
		fuel: 3,
		price: 3,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	suction_engine: {
		id: "suction_engine",
		type: "movement",
		cost: 2,
		fuel: 4,
		price: 6,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	adaptive_engine: {
		id: "adaptive_engine",
		type: "movement",
		cost: 0,
		fuel: 3,
		price: 2,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	proper_propeller: {
		id: "proper_propeller",
		type: "movement",
		cost: 0,
		fuel: 3,
		price: 5,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	nuclear_reactor: {
		id: "nuclear_reactor",
		type: "utility",
		cost: 0,
		fuel: 0,
		price: 7,
		vp: 0,
		solid: !1,
		permanent: !0,
		battery: !1
	},
	water_cooling: {
		id: "water_cooling",
		type: "utility",
		cost: 2,
		fuel: 4,
		price: 9,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	swiss_arm: {
		id: "swiss_arm",
		type: "utility",
		cost: 3,
		fuel: 4,
		price: 8,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	pit_stop: {
		id: "pit_stop",
		type: "utility",
		cost: 0,
		fuel: 5,
		price: 8,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	coffee_break: {
		id: "coffee_break",
		type: "utility",
		cost: 2,
		fuel: 4,
		price: 7,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	sentient_drone: {
		id: "sentient_drone",
		type: "utility",
		cost: 1,
		fuel: 3,
		price: 6,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	cleaning_break: {
		id: "cleaning_break",
		type: "utility",
		cost: 0,
		fuel: 3,
		price: 4,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	refuelling_drone: {
		id: "refuelling_drone",
		type: "utility",
		cost: 0,
		fuel: 5,
		price: 6,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	utility_bot: {
		id: "utility_bot",
		type: "utility",
		cost: 0,
		fuel: 3,
		price: 2,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	current_miner: {
		id: "current_miner",
		type: "utility",
		cost: 1,
		fuel: 3,
		price: 7,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	refuelling_break: {
		id: "refuelling_break",
		type: "utility",
		cost: 0,
		fuel: 5,
		price: 8,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	repair_drone: {
		id: "repair_drone",
		type: "utility",
		cost: 1,
		fuel: 4,
		price: 5,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	recoil_capacitor: {
		id: "recoil_capacitor",
		type: "advanced",
		cost: 0,
		fuel: 0,
		price: 8,
		vp: 0,
		solid: !1,
		permanent: !0,
		battery: !0
	},
	deep_neural_network: {
		id: "deep_neural_network",
		type: "advanced",
		cost: 0,
		fuel: 0,
		price: 9,
		vp: 0,
		solid: !1,
		permanent: !0,
		battery: !0
	},
	surgeon: {
		id: "surgeon",
		type: "advanced",
		cost: 0,
		fuel: 0,
		price: 8,
		vp: 0,
		solid: !1,
		permanent: !0,
		battery: !0
	},
	printer_3d: {
		id: "printer_3d",
		type: "advanced",
		cost: 0,
		fuel: 0,
		price: 7,
		vp: 0,
		solid: !1,
		permanent: !0,
		battery: !0
	},
	atomic_dislocator: {
		id: "atomic_dislocator",
		type: "advanced",
		cost: 0,
		fuel: 5,
		price: 16,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	supercharged_drilling: {
		id: "supercharged_drilling",
		type: "advanced",
		cost: 6,
		fuel: 5,
		price: 12,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	ultrahot_furnace: {
		id: "ultrahot_furnace",
		type: "advanced",
		cost: 0,
		fuel: 3,
		price: 3,
		vp: 0,
		solid: !0,
		permanent: !1,
		battery: !0
	},
	repair_bots: {
		id: "repair_bots",
		type: "advanced",
		cost: 2,
		fuel: 4,
		price: 5,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	auto_drill_ultra: {
		id: "auto_drill_ultra",
		type: "advanced",
		cost: 2,
		fuel: 4,
		price: 8,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	rocket_engine_pro: {
		id: "rocket_engine_pro",
		type: "advanced",
		cost: 2,
		fuel: 4,
		price: 9,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	antigravity_drive: {
		id: "antigravity_drive",
		type: "advanced",
		cost: 0,
		fuel: 5,
		price: 11,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	super_heavy_drill: {
		id: "super_heavy_drill",
		type: "advanced",
		cost: 4,
		fuel: 5,
		price: 17,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	reckless_descent: {
		id: "reckless_descent",
		type: "advanced",
		cost: 0,
		fuel: 4,
		price: 0,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	laser_cutter_pro: {
		id: "laser_cutter_pro",
		type: "advanced",
		cost: 4,
		fuel: 5,
		price: 18,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	mining_drone_pro: {
		id: "mining_drone_pro",
		type: "advanced",
		cost: 3,
		fuel: 4,
		price: 6,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	transformer_drill: {
		id: "transformer_drill",
		type: "advanced",
		cost: 1,
		fuel: 4,
		price: 2,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !0
	},
	damage: {
		id: "damage",
		type: "damage",
		cost: 2,
		fuel: 2,
		price: 0,
		vp: -3,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	torso: {
		id: "torso",
		type: "starting",
		cost: 1,
		fuel: 2,
		price: 0,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	stock_propeller: {
		id: "stock_propeller",
		type: "starting",
		cost: 2,
		fuel: 3,
		price: 0,
		vp: -1,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	claw: {
		id: "claw",
		type: "starting",
		cost: 1,
		fuel: 2,
		price: 0,
		vp: -2,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	mining_arm: {
		id: "mining_arm",
		type: "starting",
		cost: 6,
		fuel: 3,
		price: 0,
		vp: -1,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	crutch: {
		id: "crutch",
		type: "starting",
		cost: 0,
		fuel: 2,
		price: 0,
		vp: -2,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	vintage_drill: {
		id: "vintage_drill",
		type: "starting",
		cost: 0,
		fuel: 3,
		price: 0,
		vp: 0,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	spider_leg: {
		id: "spider_leg",
		type: "starting",
		cost: 1,
		fuel: 2,
		price: 0,
		vp: -1,
		solid: !1,
		permanent: !1,
		battery: !1
	},
	grabber: {
		id: "grabber",
		type: "starting",
		cost: 4,
		fuel: 2,
		price: 0,
		vp: -1,
		solid: !1,
		permanent: !1,
		battery: !1
	}
}, M = {
	B3: {
		id: "B3",
		floor: 3,
		kind: "barrier",
		vp: 10,
		back: 8,
		units: 3,
		minerals: [],
		exhaust: { battery: !0 },
		cost: 3
	},
	B4: {
		id: "B4",
		floor: 4,
		kind: "barrier",
		vp: 15,
		back: 14,
		units: 4,
		minerals: [],
		exhaust: { battery: !0 },
		cost: 4
	},
	B5: {
		id: "B5",
		floor: 5,
		kind: "barrier",
		vp: 20,
		back: 19,
		units: 5,
		minerals: [],
		exhaust: { battery: !0 },
		cost: 5
	},
	B6: {
		id: "B6",
		floor: 6,
		kind: "barrier",
		vp: 25,
		back: 24,
		units: 6,
		minerals: [],
		exhaust: { battery: !0 },
		cost: 6
	},
	C2_1: {
		id: "C2_1",
		floor: 2,
		kind: "corridor",
		vp: 4,
		back: 3,
		units: 2,
		minerals: ["silver", "gold"],
		exhaust: { fuel: 1 }
	},
	C2_2: {
		id: "C2_2",
		floor: 2,
		kind: "corridor",
		vp: 4,
		back: 1,
		units: 2,
		minerals: ["silver", "gold"],
		exhaust: { draw: 1 }
	},
	C2_3: {
		id: "C2_3",
		floor: 2,
		kind: "corridor",
		vp: 4,
		back: 2,
		units: 2,
		minerals: ["silver", "gold"],
		exhaust: { fuel: 2 }
	},
	C2_4: {
		id: "C2_4",
		floor: 2,
		kind: "corridor",
		vp: 4,
		back: 3,
		units: 2,
		minerals: ["silver", "gold"],
		exhaust: { credits: 2 }
	},
	C2_5: {
		id: "C2_5",
		floor: 2,
		kind: "corridor",
		vp: 4,
		back: 2,
		units: 2,
		minerals: ["silver", "gold"],
		exhaust: { credits: 3 }
	},
	C3_1: {
		id: "C3_1",
		floor: 3,
		kind: "corridor",
		vp: 6,
		back: 4,
		units: 2,
		minerals: ["silver", "sapphire"],
		exhaust: { battery: !0 }
	},
	C3_2: {
		id: "C3_2",
		floor: 3,
		kind: "corridor",
		vp: 6,
		back: 4,
		units: 2,
		minerals: [
			"gold",
			"gold",
			"sapphire"
		],
		exhaust: { battery: !0 }
	},
	C3_3: {
		id: "C3_3",
		floor: 3,
		kind: "corridor",
		vp: 6,
		back: 4,
		units: 2,
		minerals: [
			"silver",
			"gold",
			"gold"
		],
		exhaust: { battery: !0 }
	},
	C3_4: {
		id: "C3_4",
		floor: 3,
		kind: "corridor",
		vp: 6,
		back: 4,
		units: 2,
		minerals: [
			"silver",
			"gold",
			"sapphire"
		],
		exhaust: { battery: !0 }
	},
	C3_5: {
		id: "C3_5",
		floor: 3,
		kind: "corridor",
		vp: 6,
		back: 4,
		units: 2,
		minerals: ["gold", "sapphire"],
		exhaust: { battery: !0 }
	},
	C3_6: {
		id: "C3_6",
		floor: 3,
		kind: "corridor",
		vp: 6,
		back: 4,
		units: 2,
		minerals: [
			"gold",
			"gold",
			"gold"
		],
		exhaust: { battery: !0 }
	},
	C4_1: {
		id: "C4_1",
		floor: 4,
		kind: "corridor",
		vp: 10,
		back: 8,
		units: 3,
		minerals: ["sapphire", "emerald"],
		exhaust: { move: 1 }
	},
	C4_2: {
		id: "C4_2",
		floor: 4,
		kind: "corridor",
		vp: 10,
		back: 9,
		units: 3,
		minerals: [
			"sapphire",
			"sapphire",
			"emerald"
		],
		exhaust: { droneRefresh: 1 }
	},
	C4_3: {
		id: "C4_3",
		floor: 4,
		kind: "corridor",
		vp: 10,
		back: 8,
		units: 3,
		minerals: [
			"gold",
			"sapphire",
			"emerald"
		],
		exhaust: { move: 1 }
	},
	C4_4: {
		id: "C4_4",
		floor: 4,
		kind: "corridor",
		vp: 10,
		back: 9,
		units: 3,
		minerals: [
			"sapphire",
			"sapphire",
			"sapphire"
		],
		exhaust: { fuel: 2 }
	},
	C4_5: {
		id: "C4_5",
		floor: 4,
		kind: "corridor",
		vp: 10,
		back: 8,
		units: 3,
		minerals: [
			"sapphire",
			"sapphire",
			"emerald"
		],
		exhaust: { credits: 5 }
	},
	C4_6: {
		id: "C4_6",
		floor: 4,
		kind: "corridor",
		vp: 10,
		back: 9,
		units: 3,
		minerals: [
			"gold",
			"sapphire",
			"emerald"
		],
		exhaust: { fuel: 2 }
	},
	C4_7: {
		id: "C4_7",
		floor: 4,
		kind: "corridor",
		vp: 10,
		back: 7,
		units: 3,
		minerals: [
			"gold",
			"sapphire",
			"sapphire"
		],
		exhaust: { draw: 1 }
	},
	C5_1: {
		id: "C5_1",
		floor: 5,
		kind: "corridor",
		vp: 15,
		back: 14,
		units: 4,
		minerals: [
			"sapphire",
			"sapphire",
			"ruby"
		],
		exhaust: { battery: !0 }
	},
	C5_2: {
		id: "C5_2",
		floor: 5,
		kind: "corridor",
		vp: 15,
		back: 14,
		units: 4,
		minerals: [
			"sapphire",
			"sapphire",
			"sapphire",
			"ruby"
		],
		exhaust: { battery: !0 }
	},
	C5_3: {
		id: "C5_3",
		floor: 5,
		kind: "corridor",
		vp: 15,
		back: 14,
		units: 4,
		minerals: [
			"sapphire",
			"emerald",
			"ruby"
		],
		exhaust: { battery: !0 }
	},
	C5_4: {
		id: "C5_4",
		floor: 5,
		kind: "corridor",
		vp: 15,
		back: 14,
		units: 4,
		minerals: [
			"sapphire",
			"emerald",
			"emerald"
		],
		exhaust: { battery: !0 }
	},
	C5_5: {
		id: "C5_5",
		floor: 5,
		kind: "corridor",
		vp: 15,
		back: 14,
		units: 4,
		minerals: [
			"emerald",
			"emerald",
			"emerald"
		],
		exhaust: { battery: !0 }
	},
	C5_6: {
		id: "C5_6",
		floor: 5,
		kind: "corridor",
		vp: 15,
		back: 14,
		units: 4,
		minerals: [
			"emerald",
			"emerald",
			"ruby"
		],
		exhaust: { battery: !0 }
	},
	C6_1: {
		id: "C6_1",
		floor: 6,
		kind: "corridor",
		vp: 21,
		back: 20,
		units: 5,
		minerals: [
			"emerald",
			"emerald",
			"emerald",
			"ruby"
		],
		exhaust: { fuel: 1 }
	},
	C6_2: {
		id: "C6_2",
		floor: 6,
		kind: "corridor",
		vp: 21,
		back: 20,
		units: 5,
		minerals: [
			"emerald",
			"ruby",
			"ruby"
		],
		exhaust: { droneRefresh: 1 }
	},
	C6_3: {
		id: "C6_3",
		floor: 6,
		kind: "corridor",
		vp: 21,
		back: 19,
		units: 5,
		minerals: [
			"emerald",
			"emerald",
			"ruby",
			"ruby"
		],
		exhaust: { fuel: 2 }
	},
	C6_4: {
		id: "C6_4",
		floor: 6,
		kind: "corridor",
		vp: 21,
		back: 20,
		units: 5,
		minerals: ["ruby", "ruby"],
		exhaust: { droneRefresh: 1 }
	},
	C6_5: {
		id: "C6_5",
		floor: 6,
		kind: "corridor",
		vp: 21,
		back: 18,
		units: 5,
		minerals: [
			"emerald",
			"ruby",
			"ruby"
		],
		exhaust: { draw: 1 }
	}
}, ie = {
	silver: [
		4,
		3,
		2
	],
	gold: [
		5,
		4,
		3
	],
	sapphire: [
		6,
		6,
		5
	],
	emerald: [
		8,
		8,
		7
	],
	ruby: [
		10,
		10,
		9
	]
}, ae = {
	silver: 0,
	gold: 0,
	sapphire: 4,
	emerald: 6,
	ruby: 8
}, N = {
	2: ["silver", "silver"],
	3: ["gold", "sapphire"],
	4: [
		"gold",
		"sapphire",
		"emerald"
	],
	5: [
		"sapphire",
		"emerald",
		"ruby"
	],
	6: [
		"gold",
		"sapphire",
		"emerald",
		"ruby"
	]
}, oe = {
	1: [[2, 3]],
	2: [[2, 3], [4, 4]],
	3: [
		[2, 3],
		[3, 4],
		[5, 4]
	],
	4: [
		[2, 3],
		[5, 3],
		[4, 4],
		[7, 4]
	]
}, P = [
	0,
	0,
	2,
	2,
	3,
	4,
	5
], F = [
	0,
	0,
	3,
	5,
	7,
	9,
	11
], se = [
	5,
	10,
	15
], ce = [
	4,
	5,
	6,
	18
], le = [
	2,
	2,
	3,
	3,
	3,
	4,
	4,
	4
], ue = [
	"torso",
	"stock_propeller",
	"claw",
	"mining_arm",
	"crutch",
	"vintage_drill",
	"spider_leg",
	"grabber"
], de = [
	"brewery",
	"the_ritz",
	"pileup"
], fe = [
	"cave_with_no_ceiling",
	"rad_bath",
	"chill_out_zone",
	"jackpot",
	"the_squeeze",
	"toys_r_rust",
	"lobby",
	"hot_tub",
	"dispatch"
], pe = [
	{
		stars: 1,
		slots: [
			4,
			3,
			3,
			4
		],
		rows: {
			0: [
				{
					drills: 0,
					move: !1
				},
				{
					drills: 0,
					move: !1
				},
				{
					drills: 0,
					move: !1
				},
				{
					drills: 0,
					move: !1
				},
				{
					drills: 1,
					move: !1
				}
			],
			1: [
				{
					drills: 1,
					move: !0
				},
				{
					drills: 2,
					move: !0
				},
				{
					drills: 2,
					move: !0
				},
				{
					drills: 2,
					move: !0
				},
				{
					drills: 3,
					move: !0
				}
			],
			2: [
				{
					drills: 2,
					move: !0
				},
				{
					drills: 3,
					move: !0
				},
				{
					drills: 3,
					move: !0
				},
				{
					drills: 3,
					move: !0
				},
				{
					drills: 4,
					move: !0
				}
			],
			3: [
				{
					drills: 3,
					move: !0
				},
				{
					drills: 3,
					move: !0
				},
				{
					drills: 4,
					move: !0
				},
				{
					drills: 5,
					move: !0
				},
				{
					drills: 6,
					move: !0
				}
			]
		}
	},
	{
		stars: 2,
		slots: [
			3,
			3,
			3,
			4
		],
		rows: {
			0: [
				{
					drills: 0,
					move: !1
				},
				{
					drills: 0,
					move: !1
				},
				{
					drills: 1,
					move: !1
				},
				{
					drills: 1,
					move: !1
				},
				{
					drills: 1,
					move: !1
				}
			],
			1: [
				{
					drills: 1,
					move: !0
				},
				{
					drills: 2,
					move: !0
				},
				{
					drills: 2,
					move: !0
				},
				{
					drills: 2,
					move: !0
				},
				{
					drills: 3,
					move: !0
				}
			],
			2: [
				{
					drills: 3,
					move: !0
				},
				{
					drills: 3,
					move: !0
				},
				{
					drills: 4,
					move: !0
				},
				{
					drills: 4,
					move: !0
				},
				{
					drills: 5,
					move: !0
				}
			],
			3: [
				{
					drills: 3,
					move: !0
				},
				{
					drills: 4,
					move: !0
				},
				{
					drills: 4,
					move: !0
				},
				{
					drills: 5,
					move: !0
				},
				{
					drills: 6,
					move: !0
				}
			]
		}
	},
	{
		stars: 3,
		slots: [
			3,
			3,
			3,
			4
		],
		rows: {
			0: [
				{
					drills: 0,
					move: !1
				},
				{
					drills: 1,
					move: !1
				},
				{
					drills: 1,
					move: !1
				},
				{
					drills: 1,
					move: !1
				},
				{
					drills: 1,
					move: !1
				}
			],
			1: [
				{
					drills: 1,
					move: !1
				},
				{
					drills: 2,
					move: !1
				},
				{
					drills: 2,
					move: !1
				},
				{
					drills: 3,
					move: !1
				},
				{
					drills: 3,
					move: !1
				}
			],
			2: [
				{
					drills: 3,
					move: !0
				},
				{
					drills: 3,
					move: !0
				},
				{
					drills: 4,
					move: !0
				},
				{
					drills: 5,
					move: !0
				},
				{
					drills: 6,
					move: !0
				}
			],
			3: [
				{
					drills: 3,
					move: !0
				},
				{
					drills: 4,
					move: !0
				},
				{
					drills: 5,
					move: !0
				},
				{
					drills: 6,
					move: !0
				},
				{
					drills: 6,
					move: !0
				}
			]
		}
	},
	{
		stars: 4,
		slots: [
			3,
			3,
			3,
			4
		],
		rows: {
			0: [
				{
					drills: 1,
					move: !1
				},
				{
					drills: 2,
					move: !1
				},
				{
					drills: 2,
					move: !1
				},
				{
					drills: 2,
					move: !1
				},
				{
					drills: 3,
					move: !1
				}
			],
			1: [
				{
					drills: 2,
					move: !1
				},
				{
					drills: 3,
					move: !1
				},
				{
					drills: 3,
					move: !1
				},
				{
					drills: 3,
					move: !1
				},
				{
					drills: 4,
					move: !1
				}
			],
			2: [
				{
					drills: 4,
					move: !0
				},
				{
					drills: 4,
					move: !0
				},
				{
					drills: 5,
					move: !0
				},
				{
					drills: 5,
					move: !0
				},
				{
					drills: 6,
					move: !0
				}
			],
			3: [
				{
					drills: 4,
					move: !0
				},
				{
					drills: 5,
					move: !0
				},
				{
					drills: 5,
					move: !0
				},
				{
					drills: 6,
					move: !0
				},
				{
					drills: 6,
					move: !0
				}
			]
		}
	}
], I = (e, t = 1) => ({
	kind: e,
	amount: t
}), L = {
	torso: [I("drill"), I("move", 2)],
	stock_propeller: [I("move", 3)],
	claw: [I("drill")],
	mining_arm: [I("drill", 3)],
	crutch: [I("move")],
	vintage_drill: [I("drill"), I("scrapSelf")],
	spider_leg: [I("move", 2)],
	grabber: [I("drill", 2)],
	damage: [I("draw")],
	burner_drill: [I("drill", 3)],
	superior_soaker: [I("drill")],
	all_in_one_tire: [I("move", 2), I("drill")],
	careless_drilling: [I("drill", 3), I("damage")],
	mining_drone: [
		I("drill"),
		I("refresh"),
		I("storage")
	],
	laser_cutter: [I("drill", 2), I("repair")],
	reckless_drilling: [I("drill"), I("damageTop")],
	auto_drill: [I("drill"), I("draw")],
	dynamite_launcher: [I("drill", 4), I("damage")],
	harpoon_drill: [I("drill", 2)],
	jackhammer: [I("drill")],
	rocket_engine: [I("move", 3), I("repair")],
	panic_button: [I("move", 4), I("damage")],
	wheels_on_heels: [I("move", 2), I("draw")],
	rocket_drone: [I("move", 3), I("refresh")],
	rocket_drone_plus: [I("move", 2), I("refresh", 2)],
	footless_treads: [I("move", 3), I("choice")],
	flywheel: [I("move", 2)],
	atm_drone: [
		I("move"),
		I("refresh"),
		I("credits", 7)
	],
	suction_engine: [I("move", 3)],
	adaptive_engine: [I("move", 2)],
	proper_propeller: [I("move", 3)],
	water_cooling: [
		I("move"),
		I("drill"),
		I("draw"),
		I("repair")
	],
	swiss_arm: [
		I("move"),
		I("drill"),
		I("refresh"),
		I("draw")
	],
	pit_stop: [I("fuel", 3), I("repair")],
	coffee_break: [I("draw"), I("draw")],
	sentient_drone: [
		I("move"),
		I("refresh"),
		I("draw")
	],
	cleaning_break: [I("draw"), I("storage")],
	refuelling_drone: [
		I("fuel", 4),
		I("refresh"),
		I("tank")
	],
	utility_bot: [I("refresh", 2), I("repair")],
	current_miner: [
		I("credits", 5),
		I("draw"),
		I("marketMineral")
	],
	refuelling_break: [
		I("draw"),
		I("draw"),
		I("draw")
	],
	repair_drone: [I("refresh"), I("repair")],
	atomic_dislocator: [I("drill", 2), I("fuel")],
	supercharged_drilling: [I("drill", 4), I("damageHand")],
	ultrahot_furnace: [I("fuel", 6), I("tank")],
	repair_bots: [
		I("move"),
		I("repair"),
		I("repair")
	],
	auto_drill_ultra: [I("drill", 2), I("draw")],
	rocket_engine_pro: [I("move", 4), I("repair")],
	antigravity_drive: [I("teleport")],
	super_heavy_drill: [I("drill", 6)],
	reckless_descent: [I("move", 5), I("damage")],
	laser_cutter_pro: [I("drill", 4), I("repair")],
	mining_drone_pro: [I("drill", 3), I("refresh")],
	transformer_drill: [I("choice", 3), I("choice", 3)]
}, me = {
	wrecking_ball: [I("drill")],
	hover_pads: [I("move")],
	nuclear_reactor: [I("fuel")],
	recoil_capacitor: [I("fuel", 2)],
	deep_neural_network: [I("draw")],
	surgeon: [I("drill")],
	printer_3d: [I("refresh")]
}, he = {
	id: "drillers",
	tier: "beta",
	mechanics: ["deck-bag-building"],
	interactionTags: [],
	nameKey: "games.drillers.name",
	descKey: "games.drillers.desc",
	rulesKey: "games.drillers.rules",
	icon: "⛏️",
	iconImg: "games/drillers.webp",
	minPlayers: 1,
	maxPlayers: 4,
	rulesUrl: { en: "https://filemanager.czechgames.com/storage/files/drillers/rules/drillers-rulebook-english.pdf" },
	bestPlayers: [2],
	accent: "#c87522",
	releasedAt: "2026-10-17T02:31:26+08:00",
	search: {
		py: "zuan tan zhe",
		init: "ztz"
	},
	hotseat: "cover"
}, R = (e, t) => e.filter((e) => e === t).length;
function ge(e, t, n, r) {
	let i = [], a = [], o = (e, t, n, r = {}) => {
		n && i.push({
			rid: e,
			kind: t,
			n,
			...r
		});
	};
	for (let n of e.players) {
		let i = e.people[n], s = t.people[n];
		i.floor !== s.floor && a.push({
			rid: n,
			to: s.floor
		});
		for (let [e, t] of [
			["fuel", "fuel"],
			["credits", "coin"],
			["move", "move"],
			["drill", "drill"],
			["drones", "drone"]
		]) o(n, t, s[e] - i[e]);
		o(n, "fuel", s.fuelCap - i.fuelCap, { capacity: !0 }), o(n, "cargo", s.storageCap - i.storageCap, { capacity: !0 });
		let c = (e) => [
			...e.hand,
			...e.deck,
			...e.play,
			...e.discard
		], l = c(i), u = c(s), d = l.filter((e) => !u.some((t) => t.uid === e.uid)).length;
		o(n, "repair", d), o(n, "damage", u.filter((e) => e.id === "damage" && !l.some((t) => t.uid === e.uid)).length), o(n, "draw", s.hand.filter((e) => !i.hand.some((t) => t.uid === e.uid) && l.some((t) => t.uid === e.uid)).length);
		let f = (e) => e.tiles.filter((e) => !e.exhausted && M[e.id].exhaust.battery).length;
		o(n, "battery", f(s) - f(i));
		for (let e of k) {
			let t = k.indexOf(e);
			o(n, e, R(s.storage, e) - R(i.storage, e)), o(n, e, s.market[t] - i.market[t], { zone: "market" }), o(n, e, R(s.overflow, e) - R(i.overflow, e), { zone: "overflow" });
		}
		o(n, "score", r(t, n) - r(e, n));
	}
	let s = e.corporation, c = t.corporation;
	if (s && c) {
		s.floor !== c.floor && a.push({
			rid: "$corporation",
			to: c.floor
		}), o("$corporation", "drill", c.drills - s.drills);
		for (let e of k) o("$corporation", e, R(c.minerals, e) - R(s.minerals, e));
		o("$corporation", "score", r(t, "$corporation") - r(e, "$corporation"));
	}
	t.floors.forEach((t, n) => {
		let r = e.floors[n];
		for (let i of k) o(e.active, i, R(t.minerals, i) - R(r.minerals, i), { floor: n });
	});
	let l;
	if (n.type === "play") {
		let t = e.people[e.active].hand.find((e) => e.uid === n.n);
		t && (l = {
			rid: e.active,
			id: t.id,
			mode: n.mode ?? "main"
		});
	} else n.type === "tick" && e.phase === "corporate" && s?.step === "start" && c?.revealed && c.deck.length < s.deck.length && (l = {
		rid: "$corporation",
		id: c.revealed,
		mode: "main"
	});
	return !i.length && !l && !a.length ? [] : [{
		kind: "drillers-feedback",
		rid: e.active,
		ephemeral: !0,
		data: {
			changes: i,
			moves: a,
			...l ? { card: l } : {},
			automatic: n.type === "tick"
		}
	}];
}
//#endregion
//#region src/games/drillers/schema.ts
var _e = t.object({ soloDifficulty: t.int().min(1).max(4).default(1) }).prefault({}), ve = t.object({
	type: t.enum([
		"play",
		"move",
		"collect",
		"dig",
		"exhaust",
		"buy",
		"sell",
		"function",
		"ability",
		"resolve",
		"surface",
		"discard",
		"upgrade",
		"repair",
		"refreshShop",
		"refuel",
		"upkeep",
		"keep",
		"tick"
	]),
	id: t.string().max(100).optional(),
	target: t.string().max(100).optional(),
	n: t.int().min(0).max(1e6).optional(),
	mode: t.string().max(30).optional(),
	now: t.number().optional()
}), ye = t.object({
	uid: t.int().nonnegative(),
	id: t.string()
}), be = t.object({
	id: t.string(),
	exhausted: t.boolean()
}), xe = t.object({
	rid: t.string(),
	floor: t.int().min(0).max(6),
	fuel: t.int().nonnegative(),
	fuelCap: t.int().min(10).max(18),
	storageCap: t.int().min(2).max(7),
	credits: t.int().nonnegative(),
	move: t.int().nonnegative(),
	drill: t.int().nonnegative(),
	drones: t.int().min(0).max(3),
	storage: t.array(t.enum([
		"silver",
		"gold",
		"sapphire",
		"emerald",
		"ruby"
	])),
	market: t.array(t.int().min(0).max(3)).length(5),
	overflow: t.array(t.enum([
		"silver",
		"gold",
		"sapphire",
		"emerald",
		"ruby"
	])),
	tiles: t.array(be),
	permanent: t.array(t.string()),
	main: t.array(t.string()),
	refreshAvailable: t.boolean(),
	handCount: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	discard: t.array(ye),
	play: t.array(ye),
	score: t.object({
		tiles: t.int(),
		minerals: t.int(),
		credits: t.int(),
		milestones: t.int(),
		refresh: t.int(),
		depth: t.int(),
		cards: t.int(),
		total: t.int()
	})
}), Se = t.object({
	phase: t.enum([
		"operations",
		"floorEnd",
		"surfacing",
		"keep",
		"upkeep",
		"corporate",
		"done"
	]),
	active: t.string(),
	turn: t.int().positive(),
	players: t.array(xe),
	floors: t.array(t.object({
		floor: t.int(),
		open: t.boolean(),
		minerals: t.array(t.string()),
		corridors: t.array(t.string()),
		remaining: t.int(),
		card: t.string().nullable(),
		jackpot: t.array(t.string())
	})),
	shops: t.array(t.object({
		id: t.string(),
		cards: t.array(t.string()),
		remaining: t.int().nonnegative()
	})),
	milestones: t.array(t.string().nullable()).length(4),
	endTriggeredBy: t.string().nullable(),
	pending: t.array(t.object({
		kind: t.string(),
		amount: t.int()
	})),
	corporation: t.object({
		difficulty: t.int(),
		floor: t.int(),
		minerals: t.array(t.string()),
		overflow: t.array(t.string()),
		tiles: t.array(be),
		remaining: t.int(),
		revealed: t.string().nullable(),
		score: t.int(),
		step: t.string()
	}).nullable(),
	damageRemaining: t.int().nonnegative(),
	log: t.array(t.object({
		rid: t.string(),
		type: t.string(),
		id: t.string().optional(),
		n: t.int().optional(),
		target: t.string().optional(),
		mode: t.string().optional()
	}))
}), Ce = t.object({
	hand: t.array(ye),
	top: ye.nullable(),
	legal: t.array(ve),
	kept: t.array(t.int()),
	keepFree: t.int(),
	firstCorridor: t.array(t.int())
}), z = "$corporation";
function B(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function we(e, t) {
	return {
		uid: e.uid++,
		id: t
	};
}
function Te(e, t) {
	!t.deck.length && t.discard.length && (t.deck = B(e, t.discard), t.discard = []);
}
function Ee(e, t, n = 1) {
	for (let r = 0; r < n; r++) {
		Te(e, t);
		let n = t.deck.shift();
		n && t.hand.push(n), Te(e, t);
	}
}
function V(e, t) {
	e.fuel = Math.min(e.fuelCap, e.fuel + t);
}
function De(e, t, n) {
	e[t] += n, t === "move" ? e.gainedMove += n : e.gainedDrill += n;
}
function Oe(e, t, n = "discard") {
	if (e.damageRemaining > 0) {
		e.damageRemaining--;
		let r = we(e, "damage");
		n === "deck" ? t.deck.unshift(r) : t[n].push(r);
	} else for (let e = 4; e >= 0; e--) if (t.market[e]) {
		t.market[e]--;
		break;
	}
}
function ke(e) {
	return e.reduce((e, t) => e + M[t.id].units, 0);
}
function Ae(e) {
	let t = [...e.minerals];
	for (let n of e.overflow) t.splice(t.indexOf(n), 1);
	let n = t.filter((e) => e === "silver" || e === "gold").length;
	return t.length - n + Math.floor(n / 2);
}
function je(e) {
	return e.overflow.length;
}
function Me(e, t) {
	Ae(e) >= pe[e.difficulty - 1].slots.reduce((e, t) => e + t, 0) && e.overflow.push(t), e.minerals.push(t);
}
function Ne(e, t, n) {
	if (e.milestones[n] === null) {
		e.milestones[n] = t, e.log.push({
			rid: t,
			type: "milestone",
			n
		});
		for (let r of e.players) r !== t && (n === 3 ? Ee(e, e.people[r]) : e.people[r].credits += n + 3);
		e.corporation && t !== "$corporation" && Me(e.corporation, "silver");
	}
}
function Pe(e, t, n) {
	e.endTriggeredBy || (e.endTriggeredBy = t, e.finalWaiting = [...e.players, ...e.corporation ? [z] : []].filter((e) => e !== t), n && Ne(e, t, 3), e.log.push({
		rid: t,
		type: "collapse"
	}));
}
function Fe(e) {
	let t = [...e.players.map((t) => ({
		rid: t,
		tiles: e.people[t].tiles,
		overflow: e.people[t].overflow.length
	})), ...e.corporation ? [{
		rid: z,
		tiles: e.corporation.tiles,
		overflow: je(e.corporation)
	}] : []];
	for (let n of t) {
		let t = ke(n.tiles);
		se.forEach((r, i) => {
			t >= r && Ne(e, n.rid, i);
		}), t + Math.min(10, n.overflow) >= 26 && Pe(e, n.rid, !0);
	}
}
function Ie(e) {
	for (let t of A) {
		let n = t === "advanced" && e.floors[4].open ? 4 : 2;
		for (; e.shopCards[t].length < n && e.shopDecks[t].length;) e.shopCards[t].push(e.shopDecks[t].shift());
	}
}
function Le(e, t, n) {
	let r = e.floors[t];
	r.open = !0, r.card === "jackpot" && (r.jackpot = [...e.players]), n && r.card === "chill_out_zone" && V(n, 2), n && r.card === "lobby" && (n.credits += 2), t === 4 && (e.shopCards.advanced.push(...e.expansion), e.expansion = []);
}
function Re(e) {
	e.main = [], e.used = [], e.fuelCards = 0, e.gainedMove = 0, e.gainedDrill = 0, e.firstCorridor = [], e.keepFree = 1, e.kept = [], e.repaired = !1, e.refuelled = !1;
}
function ze(e) {
	if (e.endTriggeredBy && (e.finalWaiting = e.finalWaiting.filter((t) => t !== e.active), !e.finalWaiting.length)) {
		e.phase = "done";
		return;
	}
	if (e.corporation) e.active === "$corporation" ? (e.active = e.players[0], e.phase = "operations", Re(e.people[e.active])) : (e.active = z, e.phase = "corporate", e.corporation.step = "start");
	else {
		let t = e.players.indexOf(e.active);
		e.active = e.players[(t + 1) % e.players.length], e.phase = "operations", Re(e.people[e.active]);
	}
	e.turn++;
}
function Be(e, t) {
	e.phase = "keep", t.kept = t.hand.slice(0, t.keepFree).map((e) => e.uid);
}
function Ve(e, t) {
	e.pending.length || (e.source = null, e.phase === "floorEnd" && (t.floor === 0 ? e.phase = "surfacing" : Be(e, t)));
}
function He(e) {
	return [...[
		"hand",
		"play",
		"discard"
	].flatMap((t) => e[t].map((e) => `${t}:${e.uid}`)), ...e.deck[0] ? [`deck:${e.deck[0].uid}`] : []];
}
function Ue(e, t, n) {
	let [r, i] = n.split(":");
	if (![
		"hand",
		"play",
		"discard",
		"deck"
	].includes(r)) return !1;
	let a = r, o = t[a].findIndex((e) => e.uid === Number(i));
	if (o < 0 || a === "deck" && o !== 0) return !1;
	let [s] = t[a].splice(o, 1);
	return s.id === "damage" && e.damageRemaining++, a === "hand" && Ee(e, t), Te(e, t), !0;
}
function We(e, t) {
	return e.storage.length >= e.storageCap ? !1 : (e.storage.push(t), !0);
}
function Ge(e, t, n, r, i = !1, a = !1) {
	let o = e.floors[n], s = o.minerals.indexOf(r), c = i || !a && r === "silver" && t.main.includes("suction_engine") ? 0 : 1;
	return !o.open || s < 0 || t.drill < c || !We(t, r) ? !1 : (o.minerals.splice(s, 1), t.drill -= c, o.card === "the_squeeze" && (t.credits += 2), o.card === "lobby" && e.pending.push({
		kind: "fuelTrade",
		amount: 1
	}), !0);
}
function Ke(e, t) {
	let n = e.storage.indexOf(t);
	if (n < 0) return !1;
	e.storage.splice(n, 1);
	let r = k.indexOf(t);
	return e.market[r] < 3 ? (e.credits += ie[t][2 - e.market[r]], e.market[r]++) : (e.credits += ae[t], e.overflow.push(t)), !0;
}
function qe(e, t, n) {
	switch (n.kind) {
		case "repair": return [...He(t), "skip"];
		case "teleport": return e.floors.filter((e) => e.open).map((e) => String(e.floor));
		case "upgradeMineral": {
			let n = t.storage.flatMap((e, t) => e === "ruby" ? [] : [String(t)]);
			return e.phase === "floorEnd" && n.length ? n : [...n, "skip"];
		}
		case "marketMineral": {
			let e = k.filter((e, n) => t.market[n] > 0);
			return e.length ? e : ["skip"];
		}
		case "choice": return n.amount === 3 ? ["drill", "move"] : n.amount === 2 ? [
			"move",
			"refresh",
			...He(t).map((e) => `repair:${e}`),
			"skip"
		] : [
			"move",
			"refresh",
			"fuel"
		];
		case "floorSilver": return ["take", "skip"];
		case "floorCave": return [
			"1",
			"2",
			"3",
			"skip"
		];
		case "floorRust": return [...new Set(t.storage)].flatMap((e) => He(t).map((t) => `${e}|${t}`)).concat("skip");
		case "floorDispatch": return ["credits", "refresh"];
		case "fuelTrade": return ["pay", "skip"];
		case "payFuelOrDamage": return ["pay", "damage"];
		case "draw": return ["take", "skip"];
		default: return ["take"];
	}
}
function Je(e, t, n, r) {
	let i = e.pending[n];
	if (!i || !qe(e, t, i).includes(r)) return !1;
	if (r !== "skip") switch (i.kind) {
		case "fuel":
			V(t, i.amount);
			break;
		case "credits":
			t.credits += i.amount;
			break;
		case "move":
		case "drill":
			De(t, i.kind, i.amount);
			break;
		case "draw":
			Ee(e, t, i.amount);
			break;
		case "refresh":
			t.drones = Math.min(3, t.drones + i.amount);
			break;
		case "repair":
			if (!Ue(e, t, r)) return !1;
			break;
		case "damage":
			Oe(e, t);
			break;
		case "damageTop":
			Oe(e, t, "deck");
			break;
		case "damageHand":
			Oe(e, t, "hand");
			break;
		case "storage":
			t.storageCap = Math.min(7, t.storageCap + 1);
			break;
		case "tank":
			t.fuelCap = Math.min(18, t.fuelCap + 1);
			break;
		case "teleport":
			t.floor = Number(r);
			break;
		case "scrapSelf":
			t.play = t.play.filter((t) => t.uid !== e.source);
			break;
		case "upgradeMineral": {
			let e = Number(r), n = t.storage[e];
			if (!n || n === "ruby") return !1;
			t.storage[e] = k[k.indexOf(n) + 1];
			break;
		}
		case "marketMineral": {
			let e = k.indexOf(r);
			if (!t.market[e]) return !1;
			t.market[e]--, t.overflow.push(k[e]);
			break;
		}
		case "choice":
			if (r.startsWith("repair:")) {
				if (!Ue(e, t, r.slice(7))) return !1;
			} else r === "refresh" ? t.drones = Math.min(3, t.drones + 1) : r === "fuel" ? V(t, 1) : De(t, r, 1);
			break;
		case "floorSilver":
			if (!Ge(e, t, t.floor, "silver", !0)) return !1;
			break;
		case "floorCave": {
			let e = Number(r);
			if (t.move < e || !We(t, k[e + 1])) return !1;
			t.move -= e;
			break;
		}
		case "floorRust": {
			let [n, i] = r.split("|"), a = t.storage.indexOf(n);
			if (t.fuel < 1 || a < 0 || !Ue(e, t, i)) return !1;
			t.fuel--, t.overflow.push(t.storage.splice(a, 1)[0]);
			break;
		}
		case "floorDispatch":
			if (r === "credits") t.credits += 2 * t.drones;
			else {
				if (t.fuel < 1) return !1;
				t.fuel--, t.drones = Math.min(3, t.drones + 1);
			}
			break;
		case "fuelTrade":
			if (t.credits < 1) return !1;
			t.credits--, V(t, 1);
			break;
		case "payFuelOrDamage": if (r === "pay") {
			if (t.fuel < 1) return !1;
			t.fuel--;
		} else Oe(e, t);
	}
	return e.pending.splice(n, 1), Ve(e, t), !0;
}
function Ye(e, t) {
	e.phase = "floorEnd";
	let n = e.floors[t.floor].card, r = (t) => e.pending.push({
		kind: t,
		amount: 1
	});
	if (n === "brewery" && r("fuel"), n === "pileup" && r("floorSilver"), n === "cave_with_no_ceiling" && r("floorCave"), n === "chill_out_zone" && r("payFuelOrDamage"), n === "jackpot" && r("upgradeMineral"), n === "the_squeeze") for (let n of e.players) n !== t.rid && e.people[n].floor === t.floor && r("payFuelOrDamage");
	n === "the_squeeze" && e.corporation?.floor === t.floor && r("payFuelOrDamage"), n === "toys_r_rust" && r("floorRust"), n === "lobby" && (t.keepFree = 3), n === "dispatch" && r("floorDispatch"), Ve(e, t);
}
function H(e, t) {
	let n = e.people[e.active];
	if (!n || e.phase === "done") return !1;
	let r = e.phase === "operations", i = e.phase === "surfacing";
	if (t.type === "resolve") {
		let r = Je(e, n, t.n ?? -1, t.target ?? "");
		return r && Fe(e), r;
	}
	if (e.pending.length) return !1;
	switch (t.type) {
		case "play": {
			if (!r) return !1;
			let i = n.hand.findIndex((e) => e.uid === t.n), a = n.hand[i];
			if (!a) return !1;
			let o = j[a.id];
			if (o.permanent) return !1;
			if (t.mode === "fuel") V(n, o.fuel + +!!n.main.includes("flywheel")), n.fuelCards++;
			else if (t.mode === "main") {
				if (n.fuel < o.cost) return !1;
				if (o.solid) {
					let e = n.storage.indexOf(t.target);
					if (e < 0) return !1;
					n.overflow.push(n.storage.splice(e, 1)[0]);
				}
				n.fuel -= o.cost, n.main.push(a.id), a.id === "flywheel" && V(n, n.fuelCards), e.pending = (L[a.id] ?? []).map((e) => ({ ...e })), e.source = a.uid;
			} else return !1;
			n.hand.splice(i, 1), n.play.push(a);
			break;
		}
		case "move":
			if (!r || n.move < 1 || Math.abs(n.floor - (t.n ?? -10)) !== 1 || !e.floors[t.n]?.open) return !1;
			n.move--, n.floor = t.n;
			break;
		case "collect": {
			if (!r || !k.includes(t.id)) return !1;
			let i = t.n ?? n.floor;
			if (i !== n.floor) {
				if (!n.main.includes("harpoon_drill") || n.used.includes("harpoon_drill") || Math.abs(i - n.floor) !== 1) return !1;
				n.used.push("harpoon_drill");
			}
			if (t.mode === "jackpot") {
				let t = e.floors[i];
				if (i !== n.floor || !t.jackpot.includes(n.rid) || n.drill < 1 || !We(n, "emerald")) return !1;
				n.drill--, t.jackpot = t.jackpot.filter((e) => e !== n.rid);
			} else if (!Ge(e, n, i, t.id, !1, i !== n.floor)) return !1;
			break;
		}
		case "dig": {
			if (!r) return !1;
			let i = t.mode === "barrier" ? n.floor + 1 : n.floor, a = e.floors[i];
			if (!a || i < 2) return !1;
			if (t.mode === "barrier") {
				if (a.open || n.drill < i) return !1;
				n.drill -= i, n.tiles.push({
					id: `B${i}`,
					exhausted: !1
				}), Le(e, i, n), n.floor = i;
			} else {
				let t = !n.firstCorridor.includes(i), r = t && a.card === "hot_tub", o = P[i] - +!!r;
				if (!a.open || !a.corridors.length || n.drill < o) return !1;
				n.drill -= o;
				let s = a.corridors.shift();
				n.tiles.push({
					id: s,
					exhausted: !1
				}), a.minerals.push(...M[s].minerals), n.firstCorridor.push(i), a.card === "the_ritz" && (n.credits += 2), a.card === "chill_out_zone" && V(n, 2), t && a.card === "rad_bath" && (V(n, 5), e.pending.push({
					kind: "damage",
					amount: 1
				})), r && e.pending.push({
					kind: "damageHand",
					amount: 1
				});
			}
			n.main.includes("jackhammer") && V(n, 1);
			break;
		}
		case "function":
			if (!r) return !1;
			if (t.id === "move" || t.id === "drill") {
				let e = t.id === "move" ? 3 : 4;
				if (n.fuel < e) return !1;
				n.fuel -= e, De(n, t.id, 1);
			} else if (t.id === "damage") {
				if (n.used.includes("damage")) return !1;
				n.used.push("damage"), Oe(e, n), V(n, 3);
			} else return !1;
			break;
		case "exhaust": {
			if (!r && !i) return !1;
			let a = n.tiles[t.n ?? -1];
			if (!a || a.exhausted || M[a.id].exhaust.battery) return !1;
			a.exhausted = !0;
			let o = M[a.id].exhaust;
			e.pending = [
				...o.fuel ? [{
					kind: "fuel",
					amount: o.fuel
				}] : [],
				...o.draw ? [{
					kind: "draw",
					amount: o.draw
				}] : [],
				...o.credits ? [{
					kind: "credits",
					amount: o.credits
				}] : [],
				...o.move ? [{
					kind: "move",
					amount: o.move
				}] : [],
				...o.droneRefresh ? [{
					kind: "refresh",
					amount: o.droneRefresh
				}] : []
			];
			break;
		}
		case "ability": {
			if (!r || !t.id) return !1;
			let i = t.id;
			if (n.permanent.includes(i)) {
				if (n.used.includes(i) || i === "wrecking_ball" && n.gainedMove < 3 || i === "recoil_capacitor" && n.gainedDrill < 3) return !1;
				let t = i === "surgeon" ? 1 : i === "deep_neural_network" ? 2 : 0;
				if (n.fuel < t) return !1;
				n.fuel -= t, n.used.push(i), e.pending = me[i].map((e) => ({ ...e }));
			} else if (n.main.includes(i)) {
				if (i === "adaptive_engine") {
					if (n.fuel < 2) return !1;
					n.fuel -= 2, De(n, "move", 1);
				} else if (i === "repair_drone") {
					if (!n.drones) return !1;
					n.drones--, V(n, 2);
				} else if (i === "superior_soaker" || i === "burner_drill") {
					if (n.used.includes(i)) return !1;
					n.used.push(i), e.pending = [{
						kind: i === "superior_soaker" ? "upgradeMineral" : "fuel",
						amount: i === "burner_drill" ? 2 : 1
					}];
				} else return !1;
			} else return !1;
			break;
		}
		case "sell":
			if (!i && (!r || n.drones < 1) || !Ke(n, t.id)) return !1;
			r && n.drones--;
			break;
		case "buy": {
			if (!i && (!r || n.drones < 1)) return !1;
			let a = A.find((n) => e.shopCards[n].includes(t.id ?? "")), o = j[t.id ?? ""];
			if (!a || !o || n.credits < o.price) return !1;
			if (o.battery) {
				let e = n.tiles[t.n ?? -1];
				if (!e || e.exhausted || !M[e.id].exhaust.battery) return !1;
				e.exhausted = !0;
			}
			n.credits -= o.price, r && n.drones--, e.shopCards[a] = e.shopCards[a].filter((e) => e !== t.id), o.permanent ? n.permanent.push(o.id) : n.deck.unshift(we(e, o.id));
			break;
		}
		case "surface":
			if (!r) return !1;
			Ye(e, n);
			break;
		case "discard": {
			if (!i) return !1;
			let r = n.hand.findIndex((e) => e.uid === t.n);
			if (r < 0) return !1;
			n.discard.push(n.hand.splice(r, 1)[0]), n.credits += 2, Te(e, n);
			break;
		}
		case "upgrade":
			if (!i) return !1;
			if (t.id === "storage") {
				if (n.storageCap >= 7 || n.credits < 3) return !1;
				n.credits -= 3, n.storageCap++;
			} else if (t.id === "fuel") {
				let e = le[n.fuelCap - 10];
				if (!e || n.credits < e) return !1;
				n.credits -= e, n.fuelCap++;
			} else return !1;
			break;
		case "repair":
			if (!i || n.repaired || n.credits < 5 || !Ue(e, n, t.target ?? "")) return !1;
			n.credits -= 5, n.repaired = !0;
			break;
		case "refreshShop": {
			if (!i || !n.refreshAvailable || !A.includes(t.id)) return !1;
			let r = t.id;
			e.shopDecks[r].push(...B(e, e.shopCards[r])), e.shopCards[r] = [], n.refreshAvailable = !1;
			let a = r === "advanced" && e.floors[4].open ? 4 : 2;
			e.shopCards[r] = e.shopDecks[r].splice(0, a);
			break;
		}
		case "refuel":
			if (!i || n.fuel === n.fuelCap) return !1;
			n.fuel = n.fuelCap, n.refuelled = !0;
			break;
		case "keep":
			if (e.phase !== "keep" || !n.hand.some((e) => e.uid === t.n)) return !1;
			n.kept = n.kept.includes(t.n) ? n.kept.filter((e) => e !== t.n) : [...n.kept, t.n];
			break;
		case "upkeep":
			if (i) {
				if (n.storage.length || n.fuel !== n.fuelCap) return !1;
				Be(e, n);
			} else if (e.phase === "keep") {
				let t = Math.max(0, n.kept.length - n.keepFree);
				if (n.fuel < t) return !1;
				n.fuel -= t, n.discard.push(...n.hand.filter((e) => !n.kept.includes(e.uid))), n.hand = n.hand.filter((e) => n.kept.includes(e.uid)), Te(e, n), e.phase = "upkeep", e.upkeepStep = 0;
			} else return !1;
			break;
		default: return !1;
	}
	return Fe(e), !0;
}
function Xe(e) {
	let t = e.people[e.active];
	if (!t || e.phase === "corporate" || e.phase === "upkeep" || e.phase === "done") return [];
	if (e.pending.length) return e.pending.flatMap((n, r) => qe(e, t, n).map((e) => ({
		type: "resolve",
		n: r,
		target: e
	})));
	let n = [];
	if (e.phase === "keep") return [{ type: "upkeep" }, ...t.hand.map((e) => ({
		type: "keep",
		n: e.uid
	}))];
	let r = e.phase === "operations", i = e.phase === "surfacing";
	if (r) {
		for (let e of t.hand) if (n.push({
			type: "play",
			n: e.uid,
			mode: "fuel"
		}), j[e.id].solid) for (let r of new Set(t.storage)) n.push({
			type: "play",
			n: e.uid,
			mode: "main",
			target: r
		});
		else n.push({
			type: "play",
			n: e.uid,
			mode: "main"
		});
		n.push({
			type: "move",
			n: t.floor - 1
		}, {
			type: "move",
			n: t.floor + 1
		}, {
			type: "dig",
			mode: "corridor"
		}, {
			type: "dig",
			mode: "barrier"
		}, { type: "surface" });
		for (let e of [
			"move",
			"drill",
			"damage"
		]) n.push({
			type: "function",
			id: e
		});
		for (let e of [...t.main, ...t.permanent]) n.push({
			type: "ability",
			id: e
		});
		for (let r of e.floors) if (Math.abs(r.floor - t.floor) <= 1 && r.open) for (let e of new Set(r.minerals)) n.push({
			type: "collect",
			id: e,
			n: r.floor
		});
		e.floors[t.floor].jackpot.includes(t.rid) && n.push({
			type: "collect",
			id: "emerald",
			n: t.floor,
			mode: "jackpot"
		});
	}
	if (r || i) {
		t.tiles.forEach((e, t) => n.push({
			type: "exhaust",
			n: t
		}));
		for (let e of new Set(t.storage)) n.push({
			type: "sell",
			id: e
		});
		for (let r of A) for (let i of e.shopCards[r]) t.credits >= j[i].price && (j[i].battery ? t.tiles.forEach((e, t) => {
			!e.exhausted && M[e.id].exhaust.battery && n.push({
				type: "buy",
				id: i,
				n: t
			});
		}) : n.push({
			type: "buy",
			id: i
		}));
	}
	return i && (n.push({
		type: "upgrade",
		id: "storage"
	}, {
		type: "upgrade",
		id: "fuel"
	}, { type: "refuel" }, { type: "upkeep" }), t.hand.forEach((e) => n.push({
		type: "discard",
		n: e.uid
	})), He(t).forEach((e) => n.push({
		type: "repair",
		target: e
	})), A.forEach((e) => n.push({
		type: "refreshShop",
		id: e
	}))), n;
}
function Ze(e, t) {
	return t === e.active ? Xe(e).filter((t) => H(structuredClone(e), t)) : [];
}
function Qe(e, t) {
	for (let n of [...k].reverse()) for (let r of e.floors) if (r.open && (t === void 0 || r.floor === t) && r.minerals.includes(n)) return {
		floor: r.floor,
		mineral: n
	};
	return null;
}
function U(e, t, n) {
	if (n !== void 0) {
		let r = e.floors[n];
		r.minerals.splice(r.minerals.indexOf(t), 1);
	}
	Me(e.corporation, t), e.log.push({
		rid: z,
		type: "collect",
		id: t,
		n
	});
}
function $e(e) {
	let t = e.corporation, n = pe[t.difficulty - 1];
	if (t.step === "start") {
		if (t.floor > 0) {
			t.step = "resetCollect", t.collected = [];
			return;
		}
		let r = t.deck.shift();
		if (!r) {
			ze(e);
			return;
		}
		t.revealed = r;
		let i = 0, a = Ae(t);
		for (; i < n.slots.length && a >= n.slots[i];) a -= n.slots[i], i++;
		let o = n.rows[String(Math.min(3, j[r].cost))][i];
		t.drills = o.drills, t.shouldMove = o.move, t.step = "drill", t.deck.length || Pe(e, z, !1), e.log.push({
			rid: z,
			type: "play",
			id: r,
			n: o.drills
		});
		return;
	}
	if (t.step === "drill") {
		if (t.drills <= 0) {
			t.step = "bonus";
			return;
		}
		let n = e.floors.find((e) => e.floor >= 3 && !e.open);
		if (n && t.drills >= n.floor) {
			t.drills -= n.floor, t.tiles.push({
				id: `B${n.floor}`,
				exhausted: !1
			}), Le(e, n.floor), e.log.push({
				rid: z,
				type: "dig",
				n: n.floor,
				mode: "barrier"
			});
			return;
		}
		for (let n = 6; n >= 2; n--) {
			let r = e.floors[n];
			if (r.open && r.corridors.length && t.drills >= P[n]) {
				let i = r.corridors.shift();
				t.tiles.push({
					id: i,
					exhausted: !1
				}), r.minerals.push(...M[i].minerals), t.drills -= P[n], e.log.push({
					rid: z,
					type: "dig",
					n,
					mode: "corridor"
				});
				return;
			}
			if (k[n - 2] && n <= 6) {
				let r = n === 6 ? "ruby" : n === 5 ? "emerald" : n === 4 ? "sapphire" : null, i = r && e.floors.find((e) => e.open && e.minerals.includes(r));
				if (i && r) {
					t.drills--, U(e, r, i.floor);
					return;
				}
			}
		}
		for (let n of ["gold", "silver"]) {
			let r = e.floors.find((e) => e.open && e.minerals.includes(n));
			if (r) {
				t.drills--, U(e, n, r.floor);
				return;
			}
		}
		t.drills--, U(e, "silver");
		return;
	}
	if (t.step === "bonus") {
		let n = Qe(e);
		n ? U(e, n.mineral, n.floor) : U(e, "silver"), t.step = "move";
		return;
	}
	if (t.step === "move") {
		if (t.shouldMove) {
			let n = e.floors.filter((e) => e.open && e.floor > 0);
			n.sort((e, t) => {
				for (let n of [...k].reverse()) {
					let r = t.minerals.filter((e) => e === n).length - e.minerals.filter((e) => e === n).length;
					if (r) return r;
				}
				return t.floor - e.floor;
			}), t.floor = n[0].floor;
		}
		t.step = "finish";
		return;
	}
	if (t.step === "resetCollect") {
		let n = Qe(e, t.floor);
		n ? (U(e, n.mineral, n.floor), t.collected.push(n.mineral)) : (U(e, "silver"), t.collected.push("silver")), t.collected.length === 2 && (t.floor = 0, t.step = "resetShop");
		return;
	}
	if (t.step === "resetShop") {
		let n = t.collected.shift();
		if (!n) {
			Ie(e), t.step = "finish";
			return;
		}
		let r = A.flatMap((t) => e.shopCards[t]).map((e) => j[e].price), i = n === "gold" || n === "silver" ? Math.min(...r) : Math.max(...r);
		for (let t of A) {
			let n = e.shopCards[t].filter((e) => j[e].price === i);
			e.shopCards[t] = e.shopCards[t].filter((e) => j[e].price !== i), e.shopDecks[t].push(...n);
		}
		e.log.push({
			rid: z,
			type: "refreshShop",
			id: n
		});
		return;
	}
	ze(e);
}
function et(e) {
	if (e.phase === "corporate") $e(e);
	else if (e.phase === "upkeep") {
		let t = e.people[e.active];
		e.upkeepStep === 0 ? (t.discard.push(...t.play), t.play = [], Te(e, t), t.move = 0, t.drill = 0) : e.upkeepStep === 1 ? Ee(e, t, 3) : e.upkeepStep === 2 ? Ie(e) : ze(e), e.upkeepStep++;
	}
	Fe(e);
}
function W(e, t) {
	let n = e.people[t], r = n.tiles.reduce((e, t) => e + (t.exhausted ? M[t.id].back : M[t.id].vp), 0), i = [...n.storage, ...n.overflow].reduce((e, t) => e + k.indexOf(t) + 2, 0) + n.market.reduce((e, t, n) => e + t * (n + 2), 0), a = Math.floor(n.credits / 5), o = e.milestones.reduce((e, n, r) => e + (n === t ? ce[r] : 0), 0), s = +!!n.refreshAvailable, c = -F[n.floor], l = [
		...n.deck,
		...n.hand,
		...n.play,
		...n.discard
	].reduce((e, t) => e + j[t.id].vp, 0);
	return {
		tiles: r,
		minerals: i,
		credits: a,
		milestones: o,
		refresh: s,
		depth: c,
		cards: l,
		total: r + i + a + o + s + c + l
	};
}
function tt(e) {
	let t = e.corporation;
	return t ? t.minerals.reduce((e, t) => e + k.indexOf(t) + 2, 0) + t.tiles.reduce((e, t) => e + M[t.id].vp, 0) + e.milestones.reduce((e, t, n) => e + (t === "$corporation" ? ce[n] : 0), 0) : 0;
}
function nt(e, t, n) {
	let r = {
		seed: n,
		cursor: 0,
		uid: 0,
		players: [...t],
		people: {},
		active: t[0],
		turn: 1,
		phase: "operations",
		floors: [],
		shopDecks: {
			drilling: [],
			movement: [],
			utility: [],
			advanced: []
		},
		shopCards: {
			drilling: [],
			movement: [],
			utility: [],
			advanced: []
		},
		expansion: [],
		milestones: [
			null,
			null,
			null,
			null
		],
		endTriggeredBy: null,
		finalWaiting: [],
		pending: [],
		source: null,
		upkeepStep: 0,
		corporation: null,
		damageRemaining: 14,
		log: []
	};
	r.players = B(r, t), r.active = r.players[0];
	let i = B(r, de), a = B(r, fe);
	r.floors = Array.from({ length: 7 }, (e, t) => ({
		floor: t,
		open: t <= 2,
		minerals: [...N[t] ?? []],
		corridors: B(r, Object.keys(M).filter((e) => M[e].kind === "corridor" && M[e].floor === t)),
		card: t < 2 ? null : t === 2 ? i[0] : a[t - 3],
		jackpot: []
	}));
	for (let e of A) r.shopDecks[e] = B(r, Object.keys(j).filter((t) => j[t].type === e));
	Ie(r), r.expansion = r.shopDecks.advanced.splice(0, 2);
	for (let [e, n] of r.players.entries()) {
		let i = oe[t.length][e], a = {
			rid: n,
			floor: 0,
			fuel: 10,
			fuelCap: 10,
			storageCap: 2,
			credits: i[0],
			move: 0,
			drill: 0,
			drones: 1,
			storage: [],
			market: [
				0,
				0,
				0,
				0,
				0
			],
			overflow: [],
			tiles: [],
			permanent: [],
			refreshAvailable: !0,
			hand: [],
			deck: [],
			discard: [],
			play: [],
			main: [],
			fuelCards: 0,
			gainedMove: 0,
			gainedDrill: 0,
			used: [],
			firstCorridor: [],
			keepFree: 1,
			kept: [],
			repaired: !1,
			refuelled: !1
		};
		a.deck = [we(r, "torso"), ...B(r, [...ue.slice(1), "damage"]).map((e) => we(r, e))], r.damageRemaining--, r.people[n] = a, Ee(r, a, i[1]);
	}
	return t.length === 1 && (r.damageRemaining--, r.corporation = {
		difficulty: e.soloDifficulty,
		floor: 0,
		minerals: [],
		overflow: [],
		tiles: [],
		deck: B(r, [...ue, "damage"]),
		revealed: null,
		step: "start",
		drills: 0,
		shouldMove: !1,
		collected: []
	}), { state: r };
}
var rt = (e) => JSON.stringify([
	e.type,
	e.id,
	e.target,
	e.n,
	e.mode
]), it = (e, t) => t === "$corporation" ? tt(e) : W(e, t).total, at = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: he,
	schemas: {
		action: ve,
		publicView: Se,
		privateView: Ce,
		config: _e
	},
	setup: nt,
	reduce(e, t, n) {
		if (t.type === "tick") {
			if (n.by !== "$engine" || !["corporate", "upkeep"].includes(e.phase)) return { code: "games.drillers.errAction" };
			let r = structuredClone(e);
			return et(r), {
				state: r,
				fx: ge(e, r, t, it)
			};
		}
		if (n.by !== e.active) return { code: "games.drillers.errTurn" };
		let r = Ze(e, n.by).find((e) => rt(e) === rt(t));
		if (!r) return { code: "games.drillers.errAction" };
		let i = structuredClone(e);
		if (H(i, r), r.type !== "keep") {
			let t = r.type === "play" ? e.people[e.active].hand.find((e) => e.uid === r.n)?.id : void 0;
			i.log.push({
				rid: n.by,
				type: r.type,
				...r.id ? { id: r.id } : {},
				...t ? { id: t } : {},
				...r.n === void 0 ? {} : { n: r.n },
				...r.mode ? { mode: r.mode } : {}
			});
		}
		return i.log = i.log.slice(-200), {
			state: i,
			fx: ge(e, i, r, it)
		};
	},
	viewFor(e, t) {
		let n = e.people[t], r = e.corporation;
		return {
			public: {
				phase: e.phase,
				active: e.active,
				turn: e.turn,
				players: e.players.map((t) => {
					let n = e.people[t];
					return {
						rid: t,
						floor: n.floor,
						fuel: n.fuel,
						fuelCap: n.fuelCap,
						storageCap: n.storageCap,
						credits: n.credits,
						move: n.move,
						drill: n.drill,
						drones: n.drones,
						storage: n.storage,
						market: n.market,
						overflow: n.overflow,
						tiles: n.tiles,
						permanent: n.permanent,
						main: n.main,
						refreshAvailable: n.refreshAvailable,
						handCount: n.hand.length,
						deckCount: n.deck.length,
						discard: n.discard,
						play: n.play,
						score: W(e, t)
					};
				}),
				floors: e.floors.map((e) => ({
					...e,
					minerals: e.open ? e.minerals : [],
					corridors: e.corridors.slice(0, 1),
					remaining: e.corridors.length,
					card: e.open ? e.card : null
				})),
				shops: A.map((t) => ({
					id: t,
					cards: e.shopCards[t],
					remaining: e.shopDecks[t].length
				})),
				milestones: e.milestones,
				endTriggeredBy: e.endTriggeredBy,
				pending: e.pending,
				corporation: r ? {
					difficulty: r.difficulty,
					floor: r.floor,
					minerals: r.minerals,
					overflow: r.overflow,
					tiles: r.tiles,
					remaining: r.deck.length,
					revealed: r.revealed,
					score: tt(e),
					step: r.step
				} : null,
				damageRemaining: e.damageRemaining,
				log: e.log.slice(-100)
			},
			private: {
				hand: n?.hand ?? [],
				top: n?.deck[0] ?? null,
				legal: n ? Ze(e, t) : [],
				kept: n?.kept ?? [],
				keepFree: n?.keepFree ?? 1,
				firstCorridor: n?.firstCorridor ?? []
			}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => W(e, n).total - W(e, t).total || e.people[n].credits - e.people[t].credits || e.people[n].fuel - e.people[t].fuel), n = t[0];
		return {
			phase: "done",
			winner: e.corporation ? W(e, n).total > tt(e) ? [n] : [] : t.filter((t) => W(e, t).total === W(e, n).total && e.people[t].credits === e.people[n].credits && e.people[t].fuel === e.people[n].fuel),
			ranking: t,
			scores: Object.fromEntries(t.map((t) => [t, W(e, t).total]))
		};
	},
	nextTickIn: (e) => e.phase === "corporate" || e.phase === "upkeep" ? 450 : null
}, G = {
	burner_drill: "games.drillers.names.burner_drill",
	superior_soaker: "games.drillers.names.superior_soaker",
	all_in_one_tire: "games.drillers.names.all_in_one_tire",
	careless_drilling: "games.drillers.names.careless_drilling",
	mining_drone: "games.drillers.names.mining_drone",
	laser_cutter: "games.drillers.names.laser_cutter",
	reckless_drilling: "games.drillers.names.reckless_drilling",
	auto_drill: "games.drillers.names.auto_drill",
	dynamite_launcher: "games.drillers.names.dynamite_launcher",
	harpoon_drill: "games.drillers.names.harpoon_drill",
	jackhammer: "games.drillers.names.jackhammer",
	wrecking_ball: "games.drillers.names.wrecking_ball",
	hover_pads: "games.drillers.names.hover_pads",
	rocket_engine: "games.drillers.names.rocket_engine",
	panic_button: "games.drillers.names.panic_button",
	wheels_on_heels: "games.drillers.names.wheels_on_heels",
	rocket_drone: "games.drillers.names.rocket_drone",
	rocket_drone_plus: "games.drillers.names.rocket_drone_plus",
	footless_treads: "games.drillers.names.footless_treads",
	flywheel: "games.drillers.names.flywheel",
	atm_drone: "games.drillers.names.atm_drone",
	suction_engine: "games.drillers.names.suction_engine",
	adaptive_engine: "games.drillers.names.adaptive_engine",
	proper_propeller: "games.drillers.names.proper_propeller",
	nuclear_reactor: "games.drillers.names.nuclear_reactor",
	water_cooling: "games.drillers.names.water_cooling",
	swiss_arm: "games.drillers.names.swiss_arm",
	pit_stop: "games.drillers.names.pit_stop",
	coffee_break: "games.drillers.names.coffee_break",
	sentient_drone: "games.drillers.names.sentient_drone",
	cleaning_break: "games.drillers.names.cleaning_break",
	refuelling_drone: "games.drillers.names.refuelling_drone",
	utility_bot: "games.drillers.names.utility_bot",
	current_miner: "games.drillers.names.current_miner",
	refuelling_break: "games.drillers.names.refuelling_break",
	repair_drone: "games.drillers.names.repair_drone",
	recoil_capacitor: "games.drillers.names.recoil_capacitor",
	deep_neural_network: "games.drillers.names.deep_neural_network",
	surgeon: "games.drillers.names.surgeon",
	printer_3d: "games.drillers.names.printer_3d",
	atomic_dislocator: "games.drillers.names.atomic_dislocator",
	supercharged_drilling: "games.drillers.names.supercharged_drilling",
	ultrahot_furnace: "games.drillers.names.ultrahot_furnace",
	repair_bots: "games.drillers.names.repair_bots",
	auto_drill_ultra: "games.drillers.names.auto_drill_ultra",
	rocket_engine_pro: "games.drillers.names.rocket_engine_pro",
	antigravity_drive: "games.drillers.names.antigravity_drive",
	super_heavy_drill: "games.drillers.names.super_heavy_drill",
	reckless_descent: "games.drillers.names.reckless_descent",
	laser_cutter_pro: "games.drillers.names.laser_cutter_pro",
	mining_drone_pro: "games.drillers.names.mining_drone_pro",
	transformer_drill: "games.drillers.names.transformer_drill",
	damage: "games.drillers.names.damage",
	brewery: "games.drillers.names.brewery",
	the_ritz: "games.drillers.names.the_ritz",
	pileup: "games.drillers.names.pileup",
	cave_with_no_ceiling: "games.drillers.names.cave_with_no_ceiling",
	rad_bath: "games.drillers.names.rad_bath",
	chill_out_zone: "games.drillers.names.chill_out_zone",
	jackpot: "games.drillers.names.jackpot",
	the_squeeze: "games.drillers.names.the_squeeze",
	toys_r_rust: "games.drillers.names.toys_r_rust",
	lobby: "games.drillers.names.lobby",
	hot_tub: "games.drillers.names.hot_tub",
	dispatch: "games.drillers.names.dispatch",
	torso: "games.drillers.names.torso",
	stock_propeller: "games.drillers.names.stock_propeller",
	claw: "games.drillers.names.claw",
	mining_arm: "games.drillers.names.mining_arm",
	crutch: "games.drillers.names.crutch",
	vintage_drill: "games.drillers.names.vintage_drill",
	spider_leg: "games.drillers.names.spider_leg",
	grabber: "games.drillers.names.grabber"
}, K = {
	silver: "games.drillers.mineral.silver",
	gold: "games.drillers.mineral.gold",
	sapphire: "games.drillers.mineral.sapphire",
	emerald: "games.drillers.mineral.emerald",
	ruby: "games.drillers.mineral.ruby"
}, ot = {
	operations: "games.drillers.phase.operations",
	floorEnd: "games.drillers.phase.floorEnd",
	surfacing: "games.drillers.phase.surfacing",
	keep: "games.drillers.phase.keep",
	upkeep: "games.drillers.phase.upkeep",
	corporate: "games.drillers.phase.corporate",
	done: "games.drillers.phase.done"
}, st = {
	hand: "games.drillers.zone.hand",
	play: "games.drillers.zone.play",
	discard: "games.drillers.zone.discard",
	deck: "games.drillers.zone.deck"
}, ct = {
	drilling: "games.drillers.shop.drilling",
	movement: "games.drillers.shop.movement",
	utility: "games.drillers.shop.utility",
	advanced: "games.drillers.shop.advanced"
}, lt = {
	tiles: "games.drillers.score.tiles",
	minerals: "games.drillers.score.minerals",
	credits: "games.drillers.score.credits",
	milestones: "games.drillers.score.milestones",
	refresh: "games.drillers.score.refresh",
	depth: "games.drillers.score.depth",
	cards: "games.drillers.score.cards",
	total: "games.drillers.score.total"
}, ut = {
	fuel: "games.drillers.effect.fuel",
	move: "games.drillers.effect.move",
	drill: "games.drillers.effect.drill",
	draw: "games.drillers.effect.draw",
	refresh: "games.drillers.effect.refresh",
	repair: "games.drillers.effect.repair",
	damage: "games.drillers.effect.damage",
	damageTop: "games.drillers.effect.damageTop",
	damageHand: "games.drillers.effect.damageHand",
	credits: "games.drillers.effect.credits",
	storage: "games.drillers.effect.storage",
	tank: "games.drillers.effect.tank",
	teleport: "games.drillers.effect.teleport",
	upgradeMineral: "games.drillers.effect.upgradeMineral",
	marketMineral: "games.drillers.effect.marketMineral",
	choice: "games.drillers.effect.choice",
	scrapSelf: "games.drillers.effect.scrapSelf",
	floorSilver: "games.drillers.effect.floorSilver",
	floorCave: "games.drillers.effect.floorCave",
	floorRust: "games.drillers.effect.floorRust",
	floorDispatch: "games.drillers.effect.floorDispatch",
	fuelTrade: "games.drillers.effect.fuelTrade",
	payFuelOrDamage: "games.drillers.effect.payFuelOrDamage"
}, q = {
	play: "games.drillers.actions.play",
	move: "games.drillers.actions.move",
	collect: "games.drillers.actions.collect",
	dig: "games.drillers.actions.dig",
	exhaust: "games.drillers.actions.exhaust",
	buy: "games.drillers.actions.buy",
	sell: "games.drillers.actions.sell",
	function: "games.drillers.actions.function",
	ability: "games.drillers.actions.ability",
	resolve: "games.drillers.actions.resolve",
	surface: "games.drillers.actions.surface",
	discard: "games.drillers.actions.discard",
	upgrade: "games.drillers.actions.upgrade",
	repair: "games.drillers.actions.repair",
	refreshShop: "games.drillers.actions.refreshShop",
	refuel: "games.drillers.actions.refuel",
	upkeep: "games.drillers.actions.upkeep",
	keep: "games.drillers.actions.keep",
	tick: "games.drillers.actions.tick",
	milestone: "games.drillers.actions.milestone",
	collapse: "games.drillers.actions.collapse"
}, dt = {
	burner_drill: "games.drillers.abilities.burner_drill",
	superior_soaker: "games.drillers.abilities.superior_soaker",
	harpoon_drill: "games.drillers.abilities.harpoon_drill",
	jackhammer: "games.drillers.abilities.jackhammer",
	flywheel: "games.drillers.abilities.flywheel",
	suction_engine: "games.drillers.abilities.suction_engine",
	adaptive_engine: "games.drillers.abilities.adaptive_engine",
	repair_drone: "games.drillers.abilities.repair_drone",
	wrecking_ball: "games.drillers.abilities.wrecking_ball",
	hover_pads: "games.drillers.abilities.hover_pads",
	nuclear_reactor: "games.drillers.abilities.nuclear_reactor",
	recoil_capacitor: "games.drillers.abilities.recoil_capacitor",
	deep_neural_network: "games.drillers.abilities.deep_neural_network",
	surgeon: "games.drillers.abilities.surgeon",
	printer_3d: "games.drillers.abilities.printer_3d"
}, ft = {
	fuel: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M11 2h10l9 11h-7v16H9V13H2Z",
			fill: "#acc259",
			stroke: "#465b2c",
			strokeWidth: "1.4",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ w("path", {
			d: "M11 5h9l6 7h-6v14H12V12H6Z",
			fill: "#cbdc7d"
		}),
		/* @__PURE__ */ w("path", {
			d: "M12 15v11h8",
			fill: "none",
			stroke: "#758f3c",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ w("path", {
			d: "m12 7-4 5h5",
			fill: "none",
			stroke: "#ecf4ae",
			strokeWidth: "1.5"
		})
	] }),
	"fuel-pay": /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M9 3h14v16h7L20 30H12L2 19h7Z",
			fill: "#d96b32",
			stroke: "#843e2c",
			strokeWidth: "1.4",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ w("path", {
			d: "M12 5h8v17h6l-9 7-10-8h5Z",
			fill: "#f5a460"
		}),
		/* @__PURE__ */ w("path", {
			d: "M12 6h8M8 21l7 6",
			fill: "none",
			stroke: "#ffd09c",
			strokeWidth: "1.5"
		})
	] }),
	move: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "m5 12 8-8 16-1-1 16-8 8-5-5-7 7-6-6 7-7Z",
			fill: "#398fc3",
			stroke: "#205577",
			strokeWidth: "1.4",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ w("path", {
			d: "m7 12 7-6 12-1-1 12-6 7-5-5-7 7-3-3 8-8Z",
			fill: "#58b9e1"
		}),
		/* @__PURE__ */ w("path", {
			d: "m14 7 10-1-1 9",
			fill: "none",
			stroke: "#b0e8f2",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ w("path", {
			d: "m7 25 7-7 5 5",
			fill: "none",
			stroke: "#2779a7",
			strokeWidth: "1.2"
		})
	] }),
	drill: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M3 5C7-1 13 1 17 8L30 30 8 18C1 14 0 9 3 5Z",
			fill: "var(--drillers-glyph-steel)",
			stroke: "#304655",
			strokeWidth: "1.25"
		}),
		/* @__PURE__ */ w("path", {
			d: "M6 3C1 8 4 14 9 18m2-15c-6 5-4 13 2 18m2-15c-5 6-3 13 2 17m2-13c-4 6-2 10 2 15m2-10c-3 5-1 7 2 11m1-6-1 7",
			fill: "none",
			stroke: "#354c61",
			strokeWidth: "2.1"
		}),
		/* @__PURE__ */ w("path", {
			d: "m9 3 4 3M5 11l3 5m4 1 3 4m5 1 4 4",
			fill: "none",
			stroke: "#eff7f5",
			strokeWidth: "1.3"
		})
	] }),
	coin: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M9 2h14l8 14-8 14H9L1 16Z",
			fill: "var(--drillers-glyph-gold)",
			stroke: "#855520",
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ w("path", {
			d: "M10 5h12l6 11-6 11H10L4 16Z",
			fill: "none",
			stroke: "#ffeb9f",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ w("path", {
			d: "M23 10H13l-4 6 4 6h10l3-5h-6l-1 2h-4l-2-3 2-3h8Z",
			fill: "#fff3c6",
			stroke: "#a97027",
			strokeWidth: ".8"
		})
	] }),
	drone: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M10 2h12l8 7v14l-8 7H10l-8-7V9Z",
			fill: "#bed777",
			stroke: "#627c3e",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ w("path", {
			d: "M11 5h10l6 6v10l-6 6H11l-6-6V11Z",
			fill: "#8dab50"
		}),
		/* @__PURE__ */ w("path", {
			d: "m8 22 4 5m12-5-4 5",
			fill: "none",
			stroke: "#354945",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ w("rect", {
			x: "6",
			y: "8",
			width: "20",
			height: "14",
			rx: "5",
			transform: "rotate(8 16 15)",
			fill: "#38514c",
			stroke: "#1c3838",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ w("rect", {
			x: "8",
			y: "10",
			width: "16",
			height: "10",
			rx: "4",
			transform: "rotate(8 16 15)",
			fill: "#a7c96b"
		}),
		/* @__PURE__ */ w("ellipse", {
			cx: "12",
			cy: "14",
			rx: "2.1",
			ry: "3",
			fill: "#263f3b"
		}),
		/* @__PURE__ */ w("ellipse", {
			cx: "20",
			cy: "15",
			rx: "2.1",
			ry: "3",
			fill: "#263f3b"
		}),
		/* @__PURE__ */ w("path", {
			d: "m10 24 4 1m5 0 3-1",
			stroke: "#e4efb7",
			strokeWidth: "1.1"
		})
	] }),
	cargo: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "m3 10 13-6 13 6-3 18H7Z",
			fill: "#e2b945",
			stroke: "#73542a",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ w("path", {
			d: "m3 10 13 4 13-4-3 18-10 3L7 28Z",
			fill: "#efc24c",
			stroke: "#73542a",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ w("path", {
			d: "M16 14v17m-9-6 9 3 10-3",
			fill: "none",
			stroke: "#9e7528",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ w("path", {
			d: "m8 5 7-2 4 7-8 3Z",
			fill: "#7bc8dc",
			stroke: "#367e98",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ w("path", {
			d: "m18 4 8 2-2 8-8-3Z",
			fill: "#8dbc56",
			stroke: "#4e783e",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ w("path", {
			d: "m7 9 5-1 3 6-8-1Z",
			fill: "#ed8b4a"
		}),
		/* @__PURE__ */ w("path", {
			d: "m20 10 7 1-5 4-7-1Z",
			fill: "#fff1ad"
		})
	] }),
	draw: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "m10 3 19 4-5 24-19-4Z",
			fill: "#273d46",
			stroke: "#152f36",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ w("path", {
			d: "m13 6 12 3-3 16-12-3Z",
			fill: "#3c5560"
		}),
		/* @__PURE__ */ w("path", {
			d: "M3 7h6v6h6v6H9v6H3v-6H0v-6h3Z",
			fill: "#accb61",
			stroke: "#5e7f3b",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ w("path", {
			d: "M4 9h3v6h6v2H7v6H5v-6H1v-2h3Z",
			fill: "#d0e391"
		})
	] }),
	repair: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "m13 1 7 1 1 4 4 2 4-1 3 7-3 3-1 5 1 4-6 4-4-2-4 1-4 3-6-5 1-5-3-4-3-2 3-7 5 1 4-3Z",
			fill: "#334d59",
			stroke: "#193640",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ w("path", {
			d: "M24 22a10 10 0 1 1-1-13",
			fill: "none",
			stroke: "#f2bf47",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ w("path", {
			d: "M11 9c-1 4 2 8 7 8l7 6 3-3-8-6c1-4-2-7-6-7l2 3-1 2-3-1Z",
			fill: "#f4ba51",
			stroke: "#334d59",
			strokeWidth: ".8"
		})
	] }),
	damage: /* @__PURE__ */ T("g", { children: [/* @__PURE__ */ w("path", {
		d: "m16 1 3 8 8-5-3 10 7 2-8 5 3 9-10-5-7 6 1-10-9-2 8-6-2-9 7 6Z",
		fill: "#db6335",
		stroke: "#803d2b",
		strokeWidth: "1.2"
	}), /* @__PURE__ */ w("path", {
		d: "m17 6-7 11 5-1-2 10 11-14-6 2Z",
		fill: "#ffd764",
		stroke: "#9c5329",
		strokeWidth: ".7"
	})] }),
	battery: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M11 1h10v4h5v25H6V5h5Z",
			fill: "#465964",
			stroke: "#243b45",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ w("path", {
			d: "M9 8h14v19H9Z",
			fill: "#84958b"
		}),
		/* @__PURE__ */ w("path", {
			d: "m18 8-7 12h5l-2 8 8-13h-5Z",
			fill: "#f5d45a"
		}),
		/* @__PURE__ */ w("path", {
			d: "M12 3h8",
			stroke: "#c5d0b7",
			strokeWidth: "1.5"
		})
	] }),
	score: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M3 4h26v9L16 30 3 13Z",
			fill: "#725095",
			stroke: "#452f64",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ w("path", {
			d: "M6 7h20v5L16 25 6 12Z",
			fill: "#ab7bb5"
		}),
		/* @__PURE__ */ w("path", {
			d: "M8 9h16v3L16 22 8 12Z",
			fill: "none",
			stroke: "#d4b3d5",
			strokeWidth: "1"
		})
	] }),
	silver: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "m4 10 7-7 14 1 6 10-7 13-15 3-8-9Z",
			fill: "#abb7b8",
			stroke: "#48545a",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ w("path", {
			d: "m11 3 5 8-8 9-7 1 3-11Z",
			fill: "#e4e9e2"
		}),
		/* @__PURE__ */ w("path", {
			d: "m16 11 9-7 6 10-9 4Z",
			fill: "#cad5cf"
		}),
		/* @__PURE__ */ w("path", {
			d: "m8 20 8-9 6 7 2 9-15 3Z",
			fill: "#7f8e90"
		}),
		/* @__PURE__ */ w("path", {
			d: "m8 20 8-9 6 7m-6-7-5-8m11 15 9-4",
			fill: "none",
			stroke: "#647777",
			strokeWidth: "1"
		})
	] }),
	gold: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "m7 5 16-3 8 12-5 14-17 3-8-13Z",
			fill: "#e8b326",
			stroke: "#956a24",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ w("path", {
			d: "m7 5 9 5-7 11-8-3Z",
			fill: "#ffe480"
		}),
		/* @__PURE__ */ w("path", {
			d: "m16 10 7-8 8 12-10 4Z",
			fill: "#f7d04c"
		}),
		/* @__PURE__ */ w("path", {
			d: "m9 21 7-11 5 8 5 10-17 3Z",
			fill: "#c78e20"
		}),
		/* @__PURE__ */ w("path", {
			d: "m7 5 9 5 7-8m-7 8-7 11 12-3 5 10",
			fill: "none",
			stroke: "#c08b29",
			strokeWidth: "1"
		})
	] }),
	sapphire: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "m9 2 16 2 6 9-6 16-15 2-9-11Z",
			fill: "#4dc4d6",
			stroke: "#22798e",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ w("path", {
			d: "m9 2 7 9 9-7-11 1-12 15Z",
			fill: "#c6f7ec"
		}),
		/* @__PURE__ */ w("path", {
			d: "m16 11 15 2-6 16-8-2Z",
			fill: "#65d6de"
		}),
		/* @__PURE__ */ w("path", {
			d: "M16 11 10 31 1 20Z",
			fill: "#2da9bd"
		}),
		/* @__PURE__ */ w("path", {
			d: "m9 2 7 9 9-7m-9 7L10 31m6-20 15 2",
			fill: "none",
			stroke: "#258c9c",
			strokeWidth: "1"
		})
	] }),
	emerald: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "m7 3 16-2 7 8-1 18-20 4-8-12Z",
			fill: "#8dca3d",
			stroke: "#557d28",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ w("path", {
			d: "m7 3 7 6-5 22-8-12Z",
			fill: "#b4e557"
		}),
		/* @__PURE__ */ w("path", {
			d: "m14 9 9-8 3 12-8 17-9 1Z",
			fill: "#78b52e"
		}),
		/* @__PURE__ */ w("path", {
			d: "m14 9 4 21 11-3 1-18-7-8 3 12Z",
			fill: "#9bd746"
		}),
		/* @__PURE__ */ w("path", {
			d: "m7 3 7 6 9-8m-9 8L9 31m5-22 12 4m-8 17 8-17",
			fill: "none",
			stroke: "#689b2d",
			strokeWidth: "1"
		})
	] }),
	ruby: /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "m8 7 15-6 8 15-6 13-16 2-8-11Z",
			fill: "#df4a29",
			stroke: "#923c2b",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ w("path", {
			d: "m8 7 9 5 6-11-4 1-9 3-9 15Z",
			fill: "#ff9d6a"
		}),
		/* @__PURE__ */ w("path", {
			d: "m17 12 14 4-6 13-8-5Z",
			fill: "#ec5b35"
		}),
		/* @__PURE__ */ w("path", {
			d: "M17 12 9 31 1 20Z",
			fill: "#bf3428"
		}),
		/* @__PURE__ */ w("path", {
			d: "m8 7 9 5 6-11m-6 11L9 31m8-19 14 4m-14 8 8 5",
			fill: "none",
			stroke: "#aa3c2c",
			strokeWidth: "1"
		})
	] })
};
function pt(e) {
	return Object.hasOwn(ft, e);
}
function mt({ kind: e, style: t, ...n }) {
	let r = i();
	return /* @__PURE__ */ T("svg", {
		"aria-hidden": "true",
		focusable: "false",
		viewBox: "0 0 32 32",
		...n,
		style: {
			"--drillers-glyph-steel": `url(#${r}-steel)`,
			"--drillers-glyph-gold": `url(#${r}-gold)`,
			...t
		},
		children: [
			e === "drill" && /* @__PURE__ */ w("defs", { children: /* @__PURE__ */ T("linearGradient", {
				id: `${r}-steel`,
				x1: "0",
				y1: "0",
				x2: "1",
				y2: "1",
				children: [
					/* @__PURE__ */ w("stop", { stopColor: "#e8f0ef" }),
					/* @__PURE__ */ w("stop", {
						offset: ".35",
						stopColor: "#b1c3cd"
					}),
					/* @__PURE__ */ w("stop", {
						offset: ".65",
						stopColor: "#4d6476"
					}),
					/* @__PURE__ */ w("stop", {
						offset: "1",
						stopColor: "#ccd8dc"
					})
				]
			}) }),
			e === "coin" && /* @__PURE__ */ w("defs", { children: /* @__PURE__ */ T("linearGradient", {
				id: `${r}-gold`,
				x1: "0",
				y1: "0",
				x2: "0",
				y2: "1",
				children: [
					/* @__PURE__ */ w("stop", { stopColor: "#ffe29a" }),
					/* @__PURE__ */ w("stop", {
						offset: ".48",
						stopColor: "#f4bc36"
					}),
					/* @__PURE__ */ w("stop", {
						offset: "1",
						stopColor: "#bf7723"
					})
				]
			}) }),
			ft[e]
		]
	});
}
//#endregion
//#region src/games/drillers/art.tsx
var ht = {
	fuel: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M7 5h9v15H5V7h2V5Z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M9 2h5v4H9z",
				fill: "#fff2d6",
				stroke: "#24343a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M8 10h5v4H8z",
				fill: "#fff2d6"
			}),
			/* @__PURE__ */ w("path", {
				d: "m17 5 4 4v8a2 2 0 0 1-4 0v-4",
				fill: "none",
				stroke: "#24343a",
				strokeWidth: "1.5"
			})
		] })
	},
	drill: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M3 7h6v10H3z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "m9 7 12 5-12 5z",
				fill: "#fff2d6",
				stroke: "#24343a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "m12 9 1 6m3-5v4M5 4v3m0 10v3",
				stroke: "#24343a",
				strokeWidth: "1.5"
			})
		] })
	},
	move: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ w("g", { children: /* @__PURE__ */ w("path", {
			d: "M8 4v16M4 8l4-4 4 4m4 12V4m-4 12 4 4 4-4",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}) })
	},
	drone: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("ellipse", {
				cx: "12",
				cy: "7",
				rx: "9",
				ry: "2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M12 7v4m-6 6-2 4m14-4 2 4",
				stroke: "currentColor",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("rect", {
				x: "6",
				y: "11",
				width: "12",
				height: "8",
				rx: "3",
				fill: "currentColor"
			}),
			/* @__PURE__ */ w("path", {
				d: "M9 15h6",
				stroke: "#24343a",
				strokeWidth: "1.5"
			})
		] })
	},
	coin: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [/* @__PURE__ */ w("path", {
			d: "m12 2 9 5v10l-9 5-9-5V7z",
			fill: "#f4ba51",
			stroke: "#24343a",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ w("path", {
			d: "M15 8H9v8h6M7 11h9M7 14h9",
			fill: "none",
			stroke: "#24343a",
			strokeWidth: "1.5"
		})] })
	},
	cargo: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [/* @__PURE__ */ w("path", {
			d: "m3 7 9-4 9 4v13H3z",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.7"
		}), /* @__PURE__ */ w("path", {
			d: "M3 9h18M8 12v5m8-5v5",
			stroke: "currentColor",
			strokeWidth: "1.5"
		})] })
	},
	lock: {
		viewBox: "0 0 20 20",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M6 9V6a4 4 0 0 1 8 0v3",
				stroke: "currentColor",
				strokeWidth: "1.5",
				fill: "none"
			}),
			/* @__PURE__ */ w("rect", {
				x: "4",
				y: "9",
				width: "12",
				height: "9",
				rx: "2",
				fill: "currentColor"
			}),
			/* @__PURE__ */ w("path", {
				d: "M10 12v3",
				stroke: "#30414b",
				strokeWidth: "1.5"
			})
		] })
	},
	shop: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M4 10h16v11H4z",
				fill: "#fff2d6",
				stroke: "#24343a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "m4 3-2 7h20l-2-7z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M9 21v-7h6v7M7 3l-1 7m6-7v7m5-7 1 7",
				fill: "none",
				stroke: "#24343a",
				strokeWidth: "1.5"
			})
		] })
	},
	gauge: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M3 18a9 9 0 1 1 18 0z",
				fill: "#fff2d6",
				stroke: "#24343a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "m12 14 5-6M6 12l2 1m4-8v3m6 4-2 1",
				stroke: "#24343a",
				strokeWidth: "1.7"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "12",
				cy: "14",
				r: "2",
				fill: "currentColor"
			})
		] })
	},
	silver: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m5 6 12-2 5 7-6 10-13-4z",
				fill: "#bfcbd0",
				stroke: "#24343a",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ w("path", {
				d: "m5 6 6 5 6-7m-6 7 5 10m-5-10 11 0",
				fill: "none",
				stroke: "#738995",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ w("path", {
				d: "m5 6-2 11 8-6z",
				fill: "#e4eded"
			})
		] })
	},
	gold: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m6 4 13 2 3 10-10 6L2 14z",
				fill: "#e7ab37",
				stroke: "#24343a",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ w("path", {
				d: "m6 4 4 8 9-6m-9 6 2 10m-2-10 12 4",
				fill: "none",
				stroke: "#a8702b",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ w("path", {
				d: "m6 4-4 10 8-2z",
				fill: "#ffe09a"
			})
		] })
	},
	sapphire: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m12 1 9 7-3 12H7L3 8z",
				fill: "#63c8ed",
				stroke: "#24343a",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ w("path", {
				d: "m12 1 1 9 8-2m-8 2 5 10m-5-10L7 20 3 8z",
				fill: "none",
				stroke: "#2b7dba",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ w("path", {
				d: "m12 1-9 7 10 2z",
				fill: "#d7f9ff"
			})
		] })
	},
	emerald: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m7 2 12 3 2 13-14 4L2 10z",
				fill: "#70c995",
				stroke: "#24343a",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ w("path", {
				d: "m7 2 3 8 9-5m-9 5-3 12m3-12 11 8",
				fill: "none",
				stroke: "#287a65",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ w("path", {
				d: "m7 2-5 8 8 0z",
				fill: "#c7f6cc"
			})
		] })
	},
	ruby: {
		viewBox: "0 0 24 24",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m7 3 12 1 3 11-9 8L2 12z",
				fill: "#e98b8e",
				stroke: "#24343a",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ w("path", {
				d: "m7 3 4 8 8-7m-8 7 2 12m-2-12 11 4",
				fill: "none",
				stroke: "#9c4e64",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ w("path", {
				d: "m7 3-5 9 9-1z",
				fill: "#ffcfb7"
			})
		] })
	},
	mech: {
		viewBox: "0 0 100 78",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("ellipse", {
				cx: "46",
				cy: "72",
				rx: "39",
				ry: "4",
				fill: "#071d23",
				opacity: ".32"
			}),
			/* @__PURE__ */ w("path", {
				d: "M23 48 10 60H3l-1 9h24l13-16m22-5 12 12h13l4 9H65L52 54",
				fill: "#314b54",
				stroke: "#24343a",
				strokeWidth: "2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ w("path", {
				d: "m25 45 7 12-10 6M58 44l7 13 13 4",
				fill: "none",
				stroke: "#c3d0ca",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ w("rect", {
				x: "26",
				y: "21",
				width: "38",
				height: "34",
				rx: "8",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m33 21 4-10h18l6 10",
				fill: "#d4d8c7",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("rect", {
				x: "32",
				y: "25",
				width: "28",
				height: "12",
				rx: "4",
				fill: "#173d4b",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m36 28 4 6m2-6 4 6",
				stroke: "#9bdfdf",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "M35 43h13m-13 5h13",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "56",
				cy: "45",
				r: "3",
				fill: "#fff3b7",
				stroke: "#24343a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "m64 32 12 8-4 10-14-6",
				fill: "#8faaa9",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m74 35 23 12-26 11z",
				fill: "#d1ddcf",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m79 38-3 15m9-12-2 10m9-7-1 5",
				fill: "none",
				stroke: "#54717b",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m26 32-10-3-6 13 11 5 6-9",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "17",
				cy: "37",
				r: "3",
				fill: "#ceddd7",
				stroke: "#24343a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M39 11V6h13",
				fill: "none",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "54",
				cy: "6",
				r: "3",
				fill: "#fff0ad",
				stroke: "#24343a",
				strokeWidth: "1.5"
			})
		] })
	},
	"torso-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M13 71h94M21 78h78",
				stroke: "#82b3b9",
				strokeWidth: "1",
				opacity: ".6"
			}),
			/* @__PURE__ */ w("path", {
				d: "m32 59-6 16h14l8-19m30 3 6 16H70l-8-19",
				fill: "#597680",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m33 16 43 0 11 14-5 35H29l-7-35z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ w("path", {
				d: "M33 19v-8h38v8",
				fill: "#e0d8b6",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m32 26 44 0 3 15H29z",
				fill: "#244e60",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m38 29 5 9m5-9 5 9",
				stroke: "#a2e6e2",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M40 49h20m-20 6h20",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "72",
				cy: "54",
				r: "5",
				fill: "#fff5c1",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m22 33-11 5 2 20 15-2m58-23 13 5-3 20-14-2",
				fill: "#c7d0bd",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "19",
				cy: "45",
				r: "4",
				fill: "#597680",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "91",
				cy: "45",
				r: "4",
				fill: "#597680",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "M57 10V4h12",
				stroke: "#24343a",
				fill: "none",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "71",
				cy: "4",
				r: "3",
				fill: "#e2b359",
				stroke: "#24343a",
				strokeWidth: "1.5"
			})
		] })
	},
	"arm-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M12 74h96",
				stroke: "#82b3b9",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ w("path", {
				d: "m22 63 12-31 30-9 28 18-9 12-23-13-16 4-7 25z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ w("path", {
				d: "m34 57 6-18 23-8 22 16",
				fill: "none",
				stroke: "#e6e6c8",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "39",
				cy: "40",
				r: "7",
				fill: "#e5d8ba",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "63",
				cy: "28",
				r: "7",
				fill: "#e5d8ba",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m84 42 27 12-32 14z",
				fill: "#c7d5c4",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m88 46-3 15m10-11-2 8m8-6-1 4",
				stroke: "#597680",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("rect", {
				x: "13",
				y: "62",
				width: "31",
				height: "11",
				rx: "3",
				fill: "#587582",
				stroke: "#24343a",
				strokeWidth: "2"
			})
		] })
	},
	"prop-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("ellipse", {
				cx: "60",
				cy: "71",
				rx: "38",
				ry: "3",
				fill: "#3f5c66",
				opacity: ".2"
			}),
			/* @__PURE__ */ w("path", {
				d: "M46 51h29v21H46z",
				fill: "#66878e",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m61 41-11-29q1-8 15-5l8 31m-7 9 30-8q11 2 6 15l-33 3m-13-5-17 21q-10 6-14-8l26-22",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "61",
				cy: "45",
				r: "12",
				fill: "#efdc9d",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "61",
				cy: "45",
				r: "5",
				fill: "#537a87",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "M52 61h16m-16 5h16",
				stroke: "#24343a",
				strokeWidth: "2"
			})
		] })
	},
	screw: {
		viewBox: "0 0 8 8",
		drawing: /* @__PURE__ */ T("g", { children: [/* @__PURE__ */ w("circle", {
			cx: "4",
			cy: "4",
			r: "2.3",
			fill: "#acb7aa",
			stroke: "#24343a",
			strokeWidth: ".8"
		}), /* @__PURE__ */ w("path", {
			d: "m2.7 5.3 2.6-2.6",
			stroke: "#24343a",
			strokeWidth: ".8"
		})] })
	},
	"drone-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("ellipse", {
				cx: "60",
				cy: "18",
				rx: "43",
				ry: "6",
				fill: "none",
				stroke: "#24343a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ w("path", {
				d: "M60 18v14M40 64l-10 14m50-14 10 14",
				stroke: "#24343a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ w("path", {
				d: "m31 36 17-8h25l16 8-3 27H35z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("rect", {
				x: "41",
				y: "38",
				width: "38",
				height: "13",
				rx: "4",
				fill: "#244e60",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "M49 42h6m10 0h6",
				stroke: "#a2e6e2",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ w("path", {
				d: "M50 57h20M57 66v12h9v-12",
				stroke: "#24343a",
				strokeWidth: "2",
				fill: "#c7d5c4"
			})
		] })
	},
	"wheel-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M20 73h81M28 32l18-12h30l17 13-5 28H31z",
				stroke: "#24343a",
				strokeWidth: "2.5",
				fill: "currentColor"
			}),
			/* @__PURE__ */ w("path", {
				d: "M44 29h29l9 12H37z",
				fill: "#244e60",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("rect", {
				x: "22",
				y: "49",
				width: "76",
				height: "27",
				rx: "13",
				fill: "#3b535d",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M35 53h50m-50 19h50",
				stroke: "#93a9a9",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "36",
				cy: "63",
				r: "7",
				fill: "#c7d5c4",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "60",
				cy: "63",
				r: "7",
				fill: "#c7d5c4",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "84",
				cy: "63",
				r: "7",
				fill: "#c7d5c4",
				stroke: "#24343a",
				strokeWidth: "2"
			})
		] })
	},
	"reactor-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M29 73h63M37 21h45v47H37z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M43 13h33v10H43zM42 68h36v7H42z",
				fill: "#c7d5c4",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "60",
				cy: "44",
				r: "17",
				fill: "#2d5b67",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "60",
				cy: "44",
				rx: "13",
				ry: "5",
				fill: "none",
				stroke: "#b8e9d3",
				strokeWidth: "1.5",
				transform: "rotate(60 60 44)"
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "60",
				cy: "44",
				rx: "13",
				ry: "5",
				fill: "none",
				stroke: "#b8e9d3",
				strokeWidth: "1.5",
				transform: "rotate(-60 60 44)"
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "60",
				cy: "44",
				rx: "13",
				ry: "5",
				fill: "none",
				stroke: "#b8e9d3",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "60",
				cy: "44",
				r: "3",
				fill: "#fff2d6"
			}),
			/* @__PURE__ */ w("path", {
				d: "M30 30h7m45 0h9v17h-9M30 56h7",
				fill: "none",
				stroke: "#24343a",
				strokeWidth: "3"
			})
		] })
	},
	"tool-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m35 14 15 17-4 13 33 29 10-10-34-29 6-14-6-11-3 17-10 2-9-10z",
				fill: "#c7d5c4",
				stroke: "#24343a",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ w("path", {
				d: "m82 17-13 5-2 17-38 33 10 9 38-35 17-3 5-11-16 5-7-9z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "36",
				cy: "73",
				r: "3",
				fill: "#24343a"
			})
		] })
	},
	"coffee-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M29 33h52v29q-2 13-25 13T29 62z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M81 38h12q15 20-13 20M23 77h64",
				fill: "none",
				stroke: "#24343a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ w("path", {
				d: "M41 26q-9-8 0-17m14 17q-9-8 0-17m14 17q-9-8 0-17",
				fill: "none",
				stroke: "#c7d5c4",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ w("path", {
				d: "M39 42h32v15H39z",
				fill: "#244e60",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m48 45 6 9 9-9",
				fill: "none",
				stroke: "#a2e6e2",
				strokeWidth: "2"
			})
		] })
	},
	"claw-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m49 11 23 0 5 26-8 15 15 18 13-11-1 17-15 7-23-25-23 25-15-7-1-17 13 11 15-18-8-15z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ w("path", {
				d: "M49 18h16v22H49z",
				fill: "#c7d5c4",
				stroke: "#24343a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "57",
				cy: "51",
				r: "8",
				fill: "#597680",
				stroke: "#24343a",
				strokeWidth: "2"
			})
		] })
	},
	"legs-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m40 25 19-10 20 10v23L66 58H51L40 48z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "m40 34-21 9-7 28h16l7-18 11-4m33-15 21 9 7 28H91l-7-18-11-4M49 57l-7 18h13l5-16 7 16h14l-10-19",
				fill: "#c7d5c4",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M50 28h18v13H50z",
				fill: "#244e60",
				stroke: "#24343a",
				strokeWidth: "2"
			})
		] })
	},
	"damage-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m22 14 35 4 32-4 9 24-9 35-35 5-32-5-8-35z",
				fill: "#ab7762",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "m57 18-12 22 17 2-8 36",
				fill: "none",
				stroke: "#24343a",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ w("path", {
				d: "m35 23-9 15m50 23 7-17M19 45l13-4m47-12 11 4",
				stroke: "#e6c59a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m82 4-5 9m19 2-8 5M26 78l-6 8",
				stroke: "#f4ba51",
				strokeWidth: "3"
			})
		] })
	},
	"gear-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m51 10 18 0 3 12 10 5 13-3 9 17-9 8-1 10 8 9-9 15-12-5-10 4-5 10H49l-4-12-10-5-12 2-8-16 9-8 0-11-8-9 10-14 12 4 9-5z",
				transform: "translate(0 -6) scale(1 .95)",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "59",
				cy: "45",
				r: "22",
				fill: "#c7d5c4",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "59",
				cy: "45",
				r: "11",
				fill: "#244e60",
				stroke: "#24343a",
				strokeWidth: "2"
			})
		] })
	},
	"engine-art": {
		viewBox: "0 0 120 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M23 27h63v38H23zM35 17h35v10H35z",
				fill: "currentColor",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M17 34h6v22H13V40h4m69-1h18v20H86M36 65v10h40V65",
				fill: "#c7d5c4",
				stroke: "#24343a",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M35 37h32m-32 8h32m-32 8h32",
				stroke: "#24343a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "76",
				cy: "46",
				r: "5",
				fill: "#a2e6e2",
				stroke: "#24343a",
				strokeWidth: "2"
			})
		] })
	},
	"surface-art": {
		viewBox: "0 0 375 90",
		drawing: /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "m0 32 24-11 24 8 22-15 29 18 26-10 28 10 23-17 26 15 29-11 27 14 22-11 28 9 27-14 40 15v47H0z",
				fill: "#66847c"
			}),
			/* @__PURE__ */ w("path", {
				d: "M20 79V33h65v46M27 41h51M27 50h51M27 60h51",
				fill: "none",
				stroke: "#30484a",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ w("path", {
				d: "M100 79V48h55v31m10 0V56h39v23",
				fill: "#dbc9a0",
				stroke: "#30484a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m95 48 32-15 33 15m1 8 23-11 25 11",
				fill: "#d59150",
				stroke: "#30484a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "M111 58h13v21h-13z",
				fill: "#30484a"
			}),
			/* @__PURE__ */ w("rect", {
				x: "133",
				y: "57",
				width: "15",
				height: "13",
				rx: "2",
				fill: "#70c6c8",
				stroke: "#30484a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("rect", {
				x: "172",
				y: "63",
				width: "9",
				height: "16",
				fill: "#30484a"
			}),
			/* @__PURE__ */ w("path", {
				d: "M229 79V55h21v24h-21m5-30h11v6h-11",
				fill: "#f4ba51",
				stroke: "#30484a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "M250 59h9v17h-5V65",
				fill: "none",
				stroke: "#30484a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "M275 79V61h40v18z",
				fill: "#c8c9a8",
				stroke: "#30484a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ w("path", {
				d: "m279 65 8 8 10-8 10 8",
				fill: "none",
				stroke: "#81937e",
				strokeWidth: "2"
			})
		] })
	}
};
function J({ kind: e, ...t }) {
	if (pt(e)) return /* @__PURE__ */ w(mt, {
		kind: e,
		...t
	});
	let n = ht[e];
	return /* @__PURE__ */ w("svg", {
		"aria-hidden": "true",
		focusable: "false",
		viewBox: n.viewBox,
		...t,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: n.drawing
	});
}
function gt({ mineral: e, ...t }) {
	return /* @__PURE__ */ w(J, {
		kind: e,
		...t
	});
}
var _t = {
	torso: "torso-art",
	stock_propeller: "prop-art",
	claw: "claw-art",
	mining_arm: "arm-art",
	crutch: "legs-art",
	vintage_drill: "arm-art",
	spider_leg: "legs-art",
	grabber: "claw-art",
	damage: "damage-art",
	burner_drill: "arm-art",
	superior_soaker: "engine-art",
	all_in_one_tire: "wheel-art",
	careless_drilling: "arm-art",
	mining_drone: "drone-art",
	laser_cutter: "arm-art",
	reckless_drilling: "arm-art",
	auto_drill: "arm-art",
	dynamite_launcher: "engine-art",
	harpoon_drill: "arm-art",
	jackhammer: "arm-art",
	wrecking_ball: "gear-art",
	hover_pads: "prop-art",
	rocket_engine: "engine-art",
	panic_button: "reactor-art",
	wheels_on_heels: "wheel-art",
	rocket_drone: "drone-art",
	rocket_drone_plus: "drone-art",
	footless_treads: "wheel-art",
	flywheel: "gear-art",
	atm_drone: "drone-art",
	suction_engine: "engine-art",
	adaptive_engine: "engine-art",
	proper_propeller: "prop-art",
	nuclear_reactor: "reactor-art",
	water_cooling: "engine-art",
	swiss_arm: "claw-art",
	pit_stop: "tool-art",
	coffee_break: "coffee-art",
	sentient_drone: "drone-art",
	cleaning_break: "tool-art",
	refuelling_drone: "drone-art",
	utility_bot: "torso-art",
	current_miner: "reactor-art",
	refuelling_break: "fuel",
	repair_drone: "drone-art",
	recoil_capacitor: "reactor-art",
	deep_neural_network: "reactor-art",
	surgeon: "tool-art",
	printer_3d: "torso-art",
	atomic_dislocator: "reactor-art",
	supercharged_drilling: "arm-art",
	ultrahot_furnace: "engine-art",
	repair_bots: "drone-art",
	auto_drill_ultra: "arm-art",
	rocket_engine_pro: "engine-art",
	antigravity_drive: "reactor-art",
	super_heavy_drill: "arm-art",
	reckless_descent: "legs-art",
	laser_cutter_pro: "arm-art",
	mining_drone_pro: "drone-art",
	transformer_drill: "arm-art"
};
function vt({ id: e }) {
	return /* @__PURE__ */ T("div", {
		className: "drillers-equipment",
		"data-equipment": e,
		children: [
			/* @__PURE__ */ w(J, { kind: _t[e] }),
			e.includes("laser") && /* @__PURE__ */ w("svg", {
				className: "drillers-equipment-detail",
				viewBox: "0 0 120 90",
				"aria-hidden": "true",
				children: /* @__PURE__ */ w("path", {
					d: "m91 54 24 7m-20-2 13 10",
					stroke: "#b7e7da",
					strokeWidth: "3"
				})
			}),
			e.includes("burner") && /* @__PURE__ */ w("svg", {
				className: "drillers-equipment-detail",
				viewBox: "0 0 120 90",
				"aria-hidden": "true",
				children: /* @__PURE__ */ w("path", {
					d: "m91 53 15-12-4 11 14 4-14 5 5 12-18-9z",
					fill: "#f4ba51",
					stroke: "#24343a",
					strokeWidth: "1.5"
				})
			})
		]
	});
}
//#endregion
//#region src/games/drillers/resources.tsx
var yt = {
	fuel: "games.drillers.fuel",
	"fuel-pay": "games.drillers.fuel",
	move: "games.drillers.movement",
	drill: "games.drillers.drilling",
	coin: "games.drillers.credits",
	drone: "games.drillers.drones",
	cargo: "games.drillers.storage",
	draw: "games.drillers.score.cards",
	repair: "games.drillers.actions.repair",
	damage: "games.drillers.names.damage",
	battery: "games.drillers.battery",
	score: "games.drillers.pointsLabel",
	silver: K.silver,
	gold: K.gold,
	sapphire: K.sapphire,
	emerald: K.emerald,
	ruby: K.ruby
};
function Y({ kind: e, value: t, signed: n = !1, capacity: r = !1, label: i }) {
	let a = u(), o = i ?? `${a(yt[e])}${r ? ` · ${a("games.drillers.capacity")}` : ""}${t === void 0 ? "" : ` ${n && t > 0 ? "+" : ""}${t}`}`;
	return /* @__PURE__ */ T("span", {
		className: "drillers-resource",
		title: o,
		"aria-label": o,
		children: [
			/* @__PURE__ */ w(mt, { kind: e }),
			t !== void 0 && /* @__PURE__ */ T("b", {
				"aria-hidden": "true",
				children: [n && t > 0 ? "+" : t < 0 ? "−" : "", Math.abs(t)]
			}),
			r && /* @__PURE__ */ w("small", {
				"aria-hidden": "true",
				children: "↑"
			})
		]
	});
}
var bt = {
	fuel: "fuel",
	move: "move",
	drill: "drill",
	refresh: "drone",
	credits: "coin",
	draw: "draw",
	repair: "repair",
	damage: "damage",
	storage: "cargo",
	tank: "fuel"
};
function xt({ kind: e, amount: t }) {
	let n = u(), r = bt[e];
	return r ? /* @__PURE__ */ w(Y, {
		kind: r,
		value: t,
		capacity: e === "storage" || e === "tank",
		label: n(ut[e], { n: t })
	}) : e === "damageTop" || e === "damageHand" ? /* @__PURE__ */ T(C, { children: [
		/* @__PURE__ */ w(Y, {
			kind: "damage",
			value: t
		}),
		" · ",
		n(e === "damageTop" ? "games.drillers.zone.deck" : "games.drillers.zone.hand")
	] }) : e === "floorSilver" ? /* @__PURE__ */ w(Y, {
		kind: "silver",
		value: 1,
		label: n(ut[e])
	}) : e === "fuelTrade" ? /* @__PURE__ */ T(C, { children: [
		/* @__PURE__ */ w(Y, {
			kind: "coin",
			value: 1
		}),
		" → ",
		/* @__PURE__ */ w(Y, {
			kind: "fuel",
			value: 1
		})
	] }) : e === "floorRust" ? /* @__PURE__ */ T(C, { children: [
		/* @__PURE__ */ w(Y, {
			kind: "fuel-pay",
			value: 1
		}),
		/* @__PURE__ */ w(Y, {
			kind: "cargo",
			value: 1
		}),
		" → ",
		/* @__PURE__ */ w(Y, {
			kind: "repair",
			value: 1
		})
	] }) : e === "payFuelOrDamage" ? /* @__PURE__ */ T(C, { children: [
		/* @__PURE__ */ w(Y, {
			kind: "fuel-pay",
			value: 1
		}),
		" / ",
		/* @__PURE__ */ w(Y, {
			kind: "damage",
			value: 1
		})
	] }) : /* @__PURE__ */ w(St, { text: n(ut[e], { n: t }) });
}
function St({ text: e }) {
	return /* @__PURE__ */ w(C, { children: e.split(/(\{[a-z-]+:-?\d+\})/).map((e, t) => {
		let r = /^\{([a-z-]+):(-?\d+)\}$/.exec(e);
		return r && pt(r[1]) ? /* @__PURE__ */ w(Y, {
			kind: r[1],
			value: Number(r[2])
		}, t) : /* @__PURE__ */ w(n, { children: e }, t);
	}) });
}
//#endregion
//#region src/games/drillers/card.tsx
function Ct(e) {
	let t = [];
	for (let n of L[e] ?? []) {
		let e = [
			"fuel",
			"move",
			"drill",
			"draw",
			"refresh",
			"credits"
		].includes(n.kind) && t.find((e) => e.kind === n.kind);
		e ? e.amount += n.amount : t.push({ ...n });
	}
	return t;
}
var wt = /* @__PURE__ */ new Set([
	"choice",
	"scrapSelf",
	"teleport",
	"marketMineral",
	"damageTop",
	"damageHand"
]);
function Tt({ effect: e }) {
	let t = u(), { kind: n, amount: r } = e, i = t(ut[n], { n: r });
	return n === "choice" || n === "scrapSelf" ? /* @__PURE__ */ w("span", {
		className: "drillers-card-symbol",
		title: i,
		"aria-label": i,
		children: w(n === "choice" ? v : g, { size: 18 })
	}) : n === "teleport" || n === "marketMineral" ? /* @__PURE__ */ T("span", {
		className: "drillers-card-symbol",
		title: i,
		"aria-label": i,
		children: [/* @__PURE__ */ w(Y, { kind: n === "teleport" ? "move" : "cargo" }), /* @__PURE__ */ w("sup", {
			"aria-hidden": "true",
			children: n === "teleport" ? "↕" : "↗"
		})]
	}) : n === "damageTop" || n === "damageHand" ? /* @__PURE__ */ T("span", {
		className: "drillers-card-symbol",
		title: i,
		"aria-label": i,
		children: [/* @__PURE__ */ w(Y, {
			kind: "damage",
			value: r
		}), /* @__PURE__ */ w("sup", {
			"aria-hidden": "true",
			children: n === "damageTop" ? "↑" : "↓"
		})]
	}) : /* @__PURE__ */ w(xt, {
		kind: n,
		amount: r
	});
}
function Et({ id: e, showName: t = !0, top: n, deckCount: r, kept: i }) {
	let a = u(), o = j[e], s = Ct(e);
	return /* @__PURE__ */ T("div", {
		className: "drillers-card-layout",
		"data-name": t,
		children: [
			t && /* @__PURE__ */ w("strong", {
				className: "drillers-card-name",
				title: a(G[e]),
				children: a(G[e])
			}),
			/* @__PURE__ */ T("div", {
				className: "drillers-card-values",
				children: [
					/* @__PURE__ */ w("span", {
						className: "drillers-card-fuel",
						children: /* @__PURE__ */ w(Y, {
							kind: "fuel",
							value: o.fuel
						})
					}),
					o.vp !== 0 && /* @__PURE__ */ w(Y, {
						kind: "score",
						value: o.vp
					}),
					i && /* @__PURE__ */ w("span", {
						className: "drillers-kept-mark",
						children: "✓"
					})
				]
			}),
			/* @__PURE__ */ w(vt, { id: e }),
			/* @__PURE__ */ w("div", {
				className: "drillers-card-main",
				"data-many": s.length > 2 || o.solid,
				"aria-label": a(o.permanent ? "games.drillers.permanent" : "games.drillers.useMain"),
				children: o.permanent ? /* @__PURE__ */ T("span", {
					className: "drillers-card-permanent",
					children: [/* @__PURE__ */ w(te, { size: 18 }), a("games.drillers.permanent")]
				}) : /* @__PURE__ */ T(C, { children: [
					/* @__PURE__ */ T("span", {
						className: "drillers-card-cost",
						children: [/* @__PURE__ */ w(Y, {
							kind: "fuel-pay",
							value: o.cost
						}), o.solid && /* @__PURE__ */ w(Y, {
							kind: "cargo",
							value: 1,
							label: a("games.drillers.solidCost")
						})]
					}),
					/* @__PURE__ */ w("span", {
						className: "drillers-card-arrow",
						"aria-hidden": "true",
						children: "›"
					}),
					/* @__PURE__ */ w("span", {
						className: "drillers-card-gains",
						"data-count": s.length,
						children: s.map((e, t) => /* @__PURE__ */ w("span", { children: /* @__PURE__ */ w(Tt, { effect: e }) }, t))
					})
				] })
			}),
			n && /* @__PURE__ */ T("span", {
				className: "drillers-card-top",
				children: [/* @__PURE__ */ w("span", { children: a("games.drillers.topTitle") }), /* @__PURE__ */ w("b", { children: r })]
			})
		]
	});
}
function Dt({ id: e }) {
	let t = u(), n = j[e], r = (L[e] ?? []).filter((e) => wt.has(e.kind));
	return (n.solid || r.length > 0 || dt[e]) && /* @__PURE__ */ T("div", {
		className: "drillers-card-notes",
		children: [
			n.solid && /* @__PURE__ */ T("p", { children: [
				/* @__PURE__ */ w(Y, {
					kind: "cargo",
					value: 1,
					label: t("games.drillers.solidCost")
				}),
				" ",
				t("games.drillers.solidCost")
			] }),
			r.map((e, t) => /* @__PURE__ */ w("p", { children: /* @__PURE__ */ w(xt, {
				kind: e.kind,
				amount: e.amount
			}) }, t)),
			dt[e] && /* @__PURE__ */ w("p", {
				className: "drillers-card-ability",
				children: /* @__PURE__ */ w(St, { text: t(dt[e]) })
			})
		]
	});
}
function Ot({ id: e, showName: t = !0, actionPreview: n = !1, showNotes: r = !0 }) {
	return /* @__PURE__ */ T("div", {
		className: "drillers-card-face",
		"data-type": j[e].type,
		"data-preview": n,
		children: [/* @__PURE__ */ w(Et, {
			id: e,
			showName: t
		}), r && /* @__PURE__ */ w(Dt, { id: e })]
	});
}
function kt({ id: e, top: t, deckCount: n, kept: r }) {
	return /* @__PURE__ */ w("div", {
		className: "drillers-card-mini",
		"data-type": j[e].type,
		"data-top": t,
		children: /* @__PURE__ */ w(Et, {
			id: e,
			top: t,
			deckCount: n,
			kept: r
		})
	});
}
//#endregion
//#region src/games/drillers/dashboard.tsx
function At({ player: e, animate: t = !1 }) {
	let n = u(), r = e, i = (e) => t ? `resource:${r.rid}:${e}` : null, { ref: a } = d(i("fuel")), { ref: o } = d(i("coin")), { ref: s } = d(i("drone")), { ref: c } = d(i("cargo")), { ref: l } = d(i("move")), { ref: f } = d(i("drill"));
	return /* @__PURE__ */ T("div", {
		className: "drillers-dashboard",
		children: [
			/* @__PURE__ */ T("div", {
				ref: a,
				className: "drillers-fuel-meter",
				"aria-label": `${n("games.drillers.fuel")} ${r.fuel}/${r.fuelCap}`,
				children: [
					/* @__PURE__ */ w(J, { kind: "fuel" }),
					/* @__PURE__ */ w("small", { children: n("games.drillers.fuel") }),
					/* @__PURE__ */ T("b", { children: [
						/* @__PURE__ */ w(E, { value: r.fuel }),
						" / ",
						r.fuelCap
					] }),
					/* @__PURE__ */ w("div", {
						className: "drillers-fuel-ticks",
						"aria-hidden": "true",
						children: Array.from({ length: r.fuelCap }, (e, t) => /* @__PURE__ */ w("i", { "data-filled": t < r.fuel }, t))
					})
				]
			}),
			/* @__PURE__ */ T("div", {
				ref: o,
				className: "drillers-credit-meter",
				"aria-label": `${n("games.drillers.credits")} ${r.credits}`,
				children: [
					/* @__PURE__ */ w(J, { kind: "coin" }),
					/* @__PURE__ */ w("small", { children: n("games.drillers.credits") }),
					/* @__PURE__ */ w("b", { children: /* @__PURE__ */ w(E, { value: r.credits }) })
				]
			}),
			/* @__PURE__ */ T("div", {
				ref: s,
				className: "drillers-drone-meter",
				title: `${n("games.drillers.drones")} ${r.drones}/3`,
				"aria-label": `${n("games.drillers.drones")} ${r.drones}/3`,
				children: [/* @__PURE__ */ w(J, { kind: "drone" }), /* @__PURE__ */ T("b", { children: [/* @__PURE__ */ w(E, { value: r.drones }), " / 3"] })]
			}),
			/* @__PURE__ */ T("div", {
				ref: c,
				className: "drillers-cargo-meter",
				title: `${n("games.drillers.storage")} ${r.storage.length}/${r.storageCap}`,
				"aria-label": `${n("games.drillers.storage")} ${r.storage.length}/${r.storageCap}`,
				children: [
					/* @__PURE__ */ w("span", {
						className: "drillers-cargo-symbol",
						children: r.storage[0] ? /* @__PURE__ */ w(gt, { mineral: r.storage[0] }) : /* @__PURE__ */ w(J, { kind: "cargo" })
					}),
					/* @__PURE__ */ w("small", { children: n("games.drillers.storage") }),
					/* @__PURE__ */ T("b", { children: [
						r.storage.length,
						" / ",
						r.storageCap
					] })
				]
			}),
			/* @__PURE__ */ T("div", {
				className: "drillers-power-meter",
				children: [/* @__PURE__ */ T("span", {
					ref: l,
					title: n("games.drillers.movement"),
					"aria-label": `${n("games.drillers.movement")} ${r.move}`,
					children: [/* @__PURE__ */ w(J, { kind: "move" }), /* @__PURE__ */ w("b", { children: /* @__PURE__ */ w(E, { value: r.move }) })]
				}), /* @__PURE__ */ T("span", {
					ref: f,
					title: n("games.drillers.drilling"),
					"aria-label": `${n("games.drillers.drilling")} ${r.drill}`,
					children: [/* @__PURE__ */ w(J, { kind: "drill" }), /* @__PURE__ */ w("b", { children: /* @__PURE__ */ w(E, { value: r.drill }) })]
				})]
			})
		]
	});
}
//#endregion
//#region src/games/drillers/floor-card.tsx
var jt = {
	brewery: {
		art: "fuel",
		effects: [{
			when: "games.drillers.floorTiming.end",
			effect: "games.drillers.floorEffects.brewery"
		}]
	},
	the_ritz: {
		art: "coin",
		effects: [{
			when: "games.drillers.floorTiming.excavate",
			effect: "games.drillers.floorEffects.the_ritz"
		}]
	},
	pileup: {
		art: "cargo",
		effects: [{
			when: "games.drillers.floorTiming.end",
			effect: "games.drillers.floorEffects.pileup"
		}]
	},
	cave_with_no_ceiling: {
		art: "move",
		effects: [{
			when: "games.drillers.floorTiming.end",
			effect: "games.drillers.floorEffects.cave_with_no_ceiling"
		}]
	},
	rad_bath: {
		art: "fuel",
		effects: [{
			when: "games.drillers.floorTiming.firstExcavation",
			effect: "games.drillers.floorEffects.rad_bath"
		}]
	},
	chill_out_zone: {
		art: "fuel",
		effects: [{
			when: "games.drillers.floorTiming.revealOrExcavate",
			effect: "games.drillers.floorEffects.chillFuel"
		}, {
			when: "games.drillers.floorTiming.end",
			effect: "games.drillers.floorEffects.chillPayment"
		}]
	},
	jackpot: {
		art: "drill",
		effects: [{
			when: "games.drillers.floorTiming.operations",
			effect: "games.drillers.floorEffects.jackpotMineral"
		}, {
			when: "games.drillers.floorTiming.end",
			effect: "games.drillers.floorEffects.jackpotUpgrade"
		}]
	},
	the_squeeze: {
		art: "coin",
		effects: [{
			when: "games.drillers.floorTiming.collect",
			effect: "games.drillers.floorEffects.squeezeCredits"
		}, {
			when: "games.drillers.floorTiming.end",
			effect: "games.drillers.floorEffects.squeezePayment"
		}]
	},
	toys_r_rust: {
		art: "arm-art",
		effects: [{
			when: "games.drillers.floorTiming.end",
			effect: "games.drillers.floorEffects.toys_r_rust"
		}]
	},
	lobby: {
		art: "coin",
		effects: [
			{
				when: "games.drillers.floorTiming.reveal",
				effect: "games.drillers.floorEffects.lobbyCredits"
			},
			{
				when: "games.drillers.floorTiming.collect",
				effect: "games.drillers.floorEffects.lobbyFuel"
			},
			{
				when: "games.drillers.floorTiming.upkeep",
				effect: "games.drillers.floorEffects.lobbyKeep"
			}
		]
	},
	hot_tub: {
		art: "drill",
		effects: [{
			when: "games.drillers.floorTiming.firstExcavation",
			effect: "games.drillers.floorEffects.hot_tub"
		}]
	},
	dispatch: {
		art: "drone",
		effects: [{
			when: "games.drillers.floorTiming.end",
			effect: "games.drillers.floorEffects.dispatch"
		}]
	}
};
function Mt() {
	return /* @__PURE__ */ w("span", {
		className: "drillers-floor-card-back",
		"aria-hidden": "true",
		children: /* @__PURE__ */ w("svg", {
			viewBox: "0 0 24 32",
			children: /* @__PURE__ */ w("path", {
				d: "m12 6 7 10-7 10-7-10Z",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2"
			})
		})
	});
}
function Nt() {
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 130 90",
		"aria-hidden": "true",
		stroke: "#24343a",
		strokeWidth: "2",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ w("path", {
				d: "M9 79h112",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ w("path", {
				d: "M27 79V27h76v52",
				fill: "#ebce90"
			}),
			/* @__PURE__ */ w("path", {
				d: "m18 28 47-20 47 20Z",
				fill: "#bb7251"
			}),
			/* @__PURE__ */ w("path", {
				d: "M55 79V58h21v21",
				fill: "#2d545d"
			}),
			/* @__PURE__ */ w("path", {
				d: "M36 37h12v12H36zm47 0h12v12H83zM36 58h12v12H36zm47 0h12v12H83zM59 33h12v14H59z",
				fill: "#8dd2d2",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M65 8V1h23v10H65",
				fill: "#f4ba51",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ w("path", { d: "M15 79V62m-5 0h10m93 17V62m-5 0h10" })
		]
	});
}
function Pt({ id: e }) {
	let t = u(), n = jt[e];
	return /* @__PURE__ */ T("article", {
		className: "drillers-floor-card-face",
		children: [/* @__PURE__ */ T("div", {
			className: "drillers-floor-card-hero",
			children: [/* @__PURE__ */ w("div", {
				className: "drillers-floor-card-art",
				children: e === "the_ritz" ? /* @__PURE__ */ w(Nt, {}) : /* @__PURE__ */ w(J, { kind: n.art })
			}), /* @__PURE__ */ w("h3", { children: t(G[e]) })]
		}), /* @__PURE__ */ w("dl", { children: n.effects.map(({ when: e, effect: n }) => /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("dt", { children: t(e) }), /* @__PURE__ */ w("dd", { children: /* @__PURE__ */ w(St, { text: t(n) }) })] }, n)) })]
	});
}
//#endregion
//#region src/games/drillers/presentation.ts
function X(e, t) {
	return e === 0 ? t("games.drillers.surface") : t("games.drillers.floor", { n: e });
}
function Ft(e, t, n, r, i) {
	let [a, o] = e.split(":"), s = t.players.find((e) => e.rid === r), c = [
		...n?.hand ?? [],
		...s?.play ?? [],
		...s?.discard ?? [],
		...n?.top ? [n.top] : []
	].find((e) => e.uid === Number(o));
	return i("games.drillers.atZone", {
		zone: i(st[a]),
		name: i(c ? G[c.id] : "games.drillers.empty")
	});
}
function It(e, t, n, r, i) {
	let a = t.players.find((e) => e.rid === r);
	if (e.type === "play") {
		let t = n?.hand.find((t) => t.uid === e.n);
		if (!t) return i(q.play);
		let r = j[t.id], o = e.mode === "fuel" ? i("games.drillers.fuelMode", { n: r.fuel + +!!a?.main.includes("flywheel") }) : i("games.drillers.mainMode", { n: r.cost });
		return `${i(G[t.id])} · ${o}${e.target ? ` · ${i(K[e.target])}` : ""}`;
	}
	if (e.type === "move") return i("games.drillers.moveTo", { floor: X(e.n, i) });
	if (e.type === "collect") return i("games.drillers.collectAt", {
		mineral: i(K[e.id]),
		floor: X(e.n ?? a?.floor ?? 0, i)
	});
	if (e.type === "dig") return i(e.mode === "barrier" ? "games.drillers.digBarrier" : "games.drillers.digCorridor", { n: e.mode === "barrier" ? (a?.floor ?? 0) + 1 : P[a?.floor ?? 0] - +(t.floors[a?.floor ?? 0].card === "hot_tub" && !n?.firstCorridor.includes(a?.floor ?? 0)) });
	if (e.type === "function") return i(e.id === "move" ? "games.drillers.defaultMove" : e.id === "drill" ? "games.drillers.defaultDrill" : "games.drillers.defaultDamage");
	if (e.type === "ability") return i(G[e.id]);
	if (e.type === "buy") return `${i(q.buy)} ${i(G[e.id])} · ${i("games.drillers.price", { n: j[e.id].price })}${e.n === void 0 ? "" : ` · ${i("games.drillers.buyWith", { n: e.n + 1 })}`}`;
	if (e.type === "sell") return `${i(q.sell)} ${i(K[e.id])}`;
	if (e.type === "exhaust") {
		let t = a?.tiles[e.n];
		return `${i(q.exhaust)} ${e.n + 1} · ${i("games.drillers.tileFlip", { n: t ? M[t.id].back : 0 })}`;
	}
	if (e.type === "upgrade") return i(e.id === "fuel" ? "games.drillers.upgradeFuel" : "games.drillers.upgradeStorage", { n: le[(a?.fuelCap ?? 10) - 10] });
	if (e.type === "repair") return `${i("games.drillers.repairCost")} · ${Ft(e.target, t, n, r, i)}`;
	if (e.type === "refreshShop") return `${i(q.refreshShop)} · ${i(ct[e.id])}`;
	if (e.type === "keep" || e.type === "discard") {
		let t = n?.hand.find((t) => t.uid === e.n);
		return `${i(q[e.type])} ${t ? i(G[t.id]) : ""}`;
	}
	if (e.type === "resolve") {
		let o = t.pending[e.n], s = e.target;
		if (s === "skip") return i("games.drillers.skip");
		let c = i(ut[o.kind], { n: o.amount });
		if (o.kind === "repair") return `${c} · ${Ft(s, t, n, r, i)}`;
		if (o.kind === "floorRust") {
			let [e, a] = s.split("|");
			return i("games.drillers.paidMineral", {
				mineral: i(K[e]),
				action: Ft(a, t, n, r, i)
			});
		}
		if (o.kind === "teleport") return i("games.drillers.moveTo", { floor: X(Number(s), i) });
		if (o.kind === "upgradeMineral") {
			let e = a.storage[Number(s)];
			return i("games.drillers.mineralTo", {
				from: i(K[e]),
				to: i(K[k[k.indexOf(e) + 1]])
			});
		}
		return o.kind === "marketMineral" ? `${c} · ${i(K[s])}` : o.kind === "floorCave" ? `${s} → ${i(K[k[Number(s) + 1]])}` : o.kind === "choice" ? i(ut[s], { n: 1 }) : o.kind === "floorDispatch" ? i(s === "credits" ? "games.drillers.effect.credits" : "games.drillers.effect.refresh", { n: s === "credits" ? 2 * (a?.drones ?? 0) : 1 }) : o.kind === "payFuelOrDamage" ? i(s === "pay" ? "games.drillers.payFuel" : "games.drillers.effect.damage") : c;
	}
	return i(q[e.type]);
}
//#endregion
//#region src/games/drillers/mine.tsx
function Lt({ pub: e, priv: t, me: n, myRid: r, name: i, color: a, act: o, openFloor: s, label: c }) {
	let l = u(), p = e.phase === "done" ? [] : t?.legal ?? [], { ref: m } = d("drillers-mine"), h = f(), g = [...e.players.map((e) => ({
		rid: e.rid,
		floor: e.floor
	})), ...e.corporation ? [{
		rid: "$corporation",
		floor: e.corporation.floor
	}] : []], _ = e.floors.map((e) => g.filter((t) => t.floor === e.floor).sort((e, t) => Number(t.rid === r) - Number(e.rid === r)));
	return /* @__PURE__ */ w("div", {
		ref: m,
		className: "drillers-mine-wrap",
		children: /* @__PURE__ */ w("div", {
			className: "drillers-mine-viewport",
			children: /* @__PURE__ */ T("div", {
				className: "drillers-mine",
				children: [
					e.floors.map((e) => {
						let a = p.find((t) => t.type === "move" && t.n === e.floor), u = p.find((t) => t.type === "dig" && (t.mode === "barrier" ? (n?.floor ?? 0) + 1 : n?.floor) === e.floor), d = e.open ? Math.max(0, P[e.floor] - +(e.card === "hot_tub" && !t?.firstCorridor.includes(e.floor))) : e.floor, f = u ?? a;
						return /* @__PURE__ */ T("section", {
							ref: (t) => {
								h?.register(`floor:${e.floor}`, t);
							},
							className: "drillers-floor",
							"data-floor": e.floor,
							"data-open": e.open,
							"data-here": n?.floor === e.floor,
							children: [
								/* @__PURE__ */ T("svg", {
									className: "drillers-stratum",
									viewBox: "0 0 375 60",
									preserveAspectRatio: "none",
									"aria-hidden": "true",
									children: [/* @__PURE__ */ w("path", {
										d: "M0 6 34 2 74 8 112 2 154 7 196 1 236 8 280 2 326 7 375 3V60H0Z",
										fill: "currentColor"
									}), /* @__PURE__ */ w("path", {
										d: "m8 27 15-4 18 5m281 13 18-6 25 5M12 50l20-6m297-24 12 8-6 15",
										fill: "none",
										stroke: "var(--drillers-paper)",
										strokeWidth: "1.3",
										opacity: ".15"
									})]
								}),
								/* @__PURE__ */ T("button", {
									className: "drillers-depth",
									"aria-label": `${X(e.floor, l)}${e.floor > 1 ? ` · ${l("games.drillers.score.depth")} ${F[e.floor]}` : ""}`,
									onClick: () => s(e.floor),
									children: [e.floor > 0 && /* @__PURE__ */ w("b", { children: e.floor }), e.floor > 1 && /* @__PURE__ */ T("small", { children: ["−", F[e.floor]] })]
								}),
								/* @__PURE__ */ w("button", {
									className: "drillers-shaft-stop",
									onClick: () => s(e.floor),
									"aria-label": l("games.drillers.floorOccupants", {
										floor: X(e.floor, l),
										names: _[e.floor].map((e) => i(e.rid)).join(" · ") || l("games.drillers.empty")
									})
								}),
								/* @__PURE__ */ w("div", {
									className: "drillers-cavity",
									"data-surface": e.floor === 0,
									children: e.floor === 0 ? /* @__PURE__ */ w("button", {
										className: "drillers-surface-buildings",
										onClick: () => s(0),
										"aria-label": l("games.drillers.surface"),
										children: /* @__PURE__ */ w(J, { kind: "surface-art" })
									}) : e.open ? /* @__PURE__ */ T(C, { children: [
										e.card && /* @__PURE__ */ T("button", {
											className: "drillers-floor-card",
											onClick: () => s(e.floor),
											"aria-label": l("games.drillers.viewFloorCard", {
												name: l(G[e.card]),
												floor: X(e.floor, l)
											}),
											children: [/* @__PURE__ */ w("span", { children: l(G[e.card]) }), /* @__PURE__ */ w("b", {
												"aria-hidden": "true",
												children: "›"
											})]
										}),
										/* @__PURE__ */ T("div", {
											className: "drillers-floor-minerals",
											"aria-label": l("games.drillers.score.minerals"),
											children: [k.filter((t) => e.minerals.includes(t)).map((t) => {
												let n = p.find((n) => n.type === "collect" && n.id === t && n.n === e.floor && !n.mode), r = e.minerals.filter((e) => e === t).length;
												return /* @__PURE__ */ T("button", {
													disabled: !n,
													className: "drillers-mineral-target",
													"aria-label": n ? c(n) : `${l(K[t])} ${r}`,
													onClick: () => n && o(n),
													children: [
														/* @__PURE__ */ w(gt, { mineral: t }),
														/* @__PURE__ */ w("b", { children: r }),
														n && /* @__PURE__ */ w("span", {
															className: "drillers-collect-mark",
															"aria-hidden": "true",
															children: "+"
														})
													]
												}, t);
											}), e.jackpot.includes(r) && /* @__PURE__ */ T("button", {
												className: "drillers-mineral-target",
												disabled: !p.some((e) => e.type === "collect" && e.mode === "jackpot"),
												"aria-label": l("games.drillers.jackpotMineral"),
												onClick: () => {
													let e = p.find((e) => e.type === "collect" && e.mode === "jackpot");
													e && o(e);
												},
												children: [/* @__PURE__ */ w(gt, { mineral: "emerald" }), /* @__PURE__ */ w("b", { children: "★" })]
											})]
										}),
										e.floor > 1 && /* @__PURE__ */ w("span", {
											className: "drillers-tile-count",
											title: l("games.drillers.remaining", { n: e.remaining }),
											children: l("games.drillers.tileCount", { n: e.remaining })
										})
									] }) : /* @__PURE__ */ T("div", {
										className: "drillers-barrier",
										children: [
											e.floor > 1 && /* @__PURE__ */ w(Mt, {}),
											/* @__PURE__ */ w(J, { kind: "lock" }),
											/* @__PURE__ */ w("span", { children: l("games.drillers.barrier") })
										]
									})
								}),
								/* @__PURE__ */ w("div", {
									className: "drillers-floor-edge",
									children: e.floor > 1 || f ? /* @__PURE__ */ T("button", {
										className: "drillers-target",
										disabled: !f,
										"data-legal": !!f,
										"aria-label": f ? c(f) : `${l(e.open ? "games.drillers.corridor" : "games.drillers.barrier")} · ${l("games.drillers.drillCost", { n: d })}`,
										onClick: () => f && o(f),
										children: [/* @__PURE__ */ T("span", { children: [/* @__PURE__ */ w(J, { kind: a ? "move" : "drill" }), /* @__PURE__ */ w("b", { children: a ? 1 : d })] }), /* @__PURE__ */ w("small", { children: l(a ? "games.drillers.actions.move" : f ? e.open ? "games.drillers.corridorButton" : "games.drillers.barrierButton" : e.open ? "games.drillers.corridor" : "games.drillers.barrier") })]
									}) : null
								})
							]
						}, e.floor);
					}),
					/* @__PURE__ */ w("div", {
						className: "drillers-shaft-rails",
						"aria-hidden": "true"
					}),
					_.map((t, n) => {
						let o = t[0];
						return o && /* @__PURE__ */ T("div", {
							className: "drillers-rig-position",
							"data-here": o.rid === r,
							style: {
								top: `${(n + .5) / e.floors.length * 100}%`,
								"--drillers-player": a(o.rid)
							},
							children: [
								/* @__PURE__ */ w(J, { kind: "mech" }),
								/* @__PURE__ */ w("span", { children: i(o.rid) }),
								t.length > 1 && /* @__PURE__ */ T("b", {
									className: "drillers-occupant-count",
									children: ["+", t.length - 1]
								})
							]
						}, o.rid);
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/drillers/action-label.tsx
function Rt({ action: e, pub: t, priv: n, rid: r }) {
	let i = u(), a = t.players.find((e) => e.rid === r), o = e.type === "play" ? n?.hand.find((t) => t.uid === e.n) : void 0;
	if (o) return e.mode === "fuel" ? /* @__PURE__ */ T(C, { children: [
		i("games.drillers.fuelModeLabel"),
		" ",
		/* @__PURE__ */ w(Y, {
			kind: "fuel",
			value: j[o.id].fuel + +!!a?.main.includes("flywheel")
		})
	] }) : /* @__PURE__ */ T(C, { children: [
		i("games.drillers.useMain"),
		" ",
		/* @__PURE__ */ w(Y, {
			kind: "fuel-pay",
			value: j[o.id].cost
		}),
		e.target && /* @__PURE__ */ w(Y, {
			kind: e.target,
			value: 1
		})
	] });
	if (e.type === "function") return /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("span", {
		className: "drillers-action-caption",
		children: i(e.id === "damage" ? "games.drillers.panel.takeDamage" : e.id === "move" ? "games.drillers.panel.gainMove" : "games.drillers.panel.gainDrill")
	}), /* @__PURE__ */ w("span", {
		className: "drillers-action-values",
		children: e.id === "damage" ? /* @__PURE__ */ T(C, { children: [
			/* @__PURE__ */ w(Y, {
				kind: "damage",
				value: 1
			}),
			" → ",
			/* @__PURE__ */ w(Y, {
				kind: "fuel",
				value: 3
			})
		] }) : /* @__PURE__ */ T(C, { children: [
			/* @__PURE__ */ w(Y, {
				kind: "fuel-pay",
				value: e.id === "move" ? 3 : 4
			}),
			" → ",
			/* @__PURE__ */ w(Y, {
				kind: e.id === "move" ? "move" : "drill",
				value: 1
			})
		] })
	})] });
	if (e.type === "move") return /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("span", {
		className: "drillers-action-caption",
		children: i("games.drillers.moveTo", { floor: X(e.n, i) })
	}), /* @__PURE__ */ w(Y, {
		kind: "move",
		value: 1
	})] });
	if (e.type === "dig") return /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("span", {
		className: "drillers-action-caption",
		children: i(e.mode === "barrier" ? "games.drillers.barrierButton" : "games.drillers.corridorButton")
	}), /* @__PURE__ */ w(Y, {
		kind: "drill",
		value: e.mode === "barrier" ? (a?.floor ?? 0) + 1 : P[a?.floor ?? 0] - +(t.floors[a?.floor ?? 0].card === "hot_tub" && !n?.firstCorridor.includes(a?.floor ?? 0))
	})] });
	if (e.type === "sell" || e.type === "collect") return /* @__PURE__ */ T(C, { children: [
		i(q[e.type]),
		" ",
		/* @__PURE__ */ w(Y, {
			kind: e.id,
			value: 1
		}),
		e.type === "collect" && /* @__PURE__ */ w("small", { children: X(e.n ?? a?.floor ?? 0, i) })
	] });
	if (e.type === "buy") return /* @__PURE__ */ T(C, { children: [
		i(q.buy),
		" ",
		i(G[e.id]),
		/* @__PURE__ */ w(Y, {
			kind: "coin",
			value: j[e.id].price
		}),
		e.n !== void 0 && /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w(Y, {
			kind: "battery",
			value: 1
		}), /* @__PURE__ */ w("small", { children: i("games.drillers.tileNumber", { n: e.n + 1 }) })] })
	] });
	if (e.type === "upgrade") return /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("span", {
		className: "drillers-action-caption",
		children: i(e.id === "fuel" ? "games.drillers.panel.fuelUpgrade" : "games.drillers.panel.storageUpgrade")
	}), /* @__PURE__ */ w(Y, {
		kind: "coin",
		value: e.id === "fuel" ? le[(a?.fuelCap ?? 10) - 10] : 3
	})] });
	if (e.type === "repair") return /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ T("span", {
		className: "drillers-action-caption",
		children: [
			i(q.repair),
			" ",
			Ft(e.target, t, n, r, i)
		]
	}), /* @__PURE__ */ w(Y, {
		kind: "coin",
		value: 5
	})] });
	if (e.type === "exhaust") {
		let t = a?.tiles[e.n];
		return /* @__PURE__ */ T(C, { children: [
			i(q.exhaust),
			" ",
			e.n + 1,
			" · ",
			/* @__PURE__ */ w(Y, {
				kind: "score",
				value: t ? M[t.id].back : 0
			})
		] });
	}
	if (e.type === "refuel") return /* @__PURE__ */ T(C, { children: [
		i(q.refuel),
		" ",
		/* @__PURE__ */ w(Y, {
			kind: "fuel",
			value: (a?.fuelCap ?? 0) - (a?.fuel ?? 0)
		})
	] });
	if (e.type === "discard") {
		let t = n?.hand.find((t) => t.uid === e.n);
		return /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ T("span", {
			className: "drillers-action-caption",
			children: [i(q.discard), t && /* @__PURE__ */ T(C, { children: [" ", i(G[t.id])] })]
		}), /* @__PURE__ */ w(Y, {
			kind: "coin",
			value: 2
		})] });
	}
	if (e.type === "resolve" && e.target !== "skip") {
		let o = t.pending[e.n], s = e.target;
		if (o.kind === "choice") return /* @__PURE__ */ w(xt, {
			kind: s,
			amount: 1
		});
		if (o.kind === "payFuelOrDamage") return /* @__PURE__ */ w(Y, {
			kind: s === "pay" ? "fuel-pay" : "damage",
			value: 1
		});
		if (o.kind === "floorDispatch") return s === "credits" ? /* @__PURE__ */ w(Y, {
			kind: "coin",
			value: 2 * (a?.drones ?? 0)
		}) : /* @__PURE__ */ T(C, { children: [
			/* @__PURE__ */ w(Y, {
				kind: "fuel-pay",
				value: 1
			}),
			" → ",
			/* @__PURE__ */ w(Y, {
				kind: "drone",
				value: 1
			})
		] });
		if (o.kind === "floorCave") return /* @__PURE__ */ T(C, { children: [
			/* @__PURE__ */ w(Y, {
				kind: "move",
				value: Number(s)
			}),
			" → ",
			/* @__PURE__ */ w(Y, {
				kind: k[Number(s) + 1],
				value: 1
			})
		] });
		if (o.kind === "upgradeMineral") {
			let e = a.storage[Number(s)];
			return /* @__PURE__ */ T(C, { children: [
				/* @__PURE__ */ w(Y, {
					kind: e,
					value: 1
				}),
				" → ",
				/* @__PURE__ */ w(Y, {
					kind: k[k.indexOf(e) + 1],
					value: 1
				})
			] });
		}
		if (o.kind === "marketMineral") return /* @__PURE__ */ T(C, { children: [
			/* @__PURE__ */ w(Y, {
				kind: s,
				value: 1
			}),
			" → ",
			i("games.drillers.overflow")
		] });
		if (o.kind === "floorRust") {
			let [e, a] = s.split("|");
			return /* @__PURE__ */ T(C, { children: [
				/* @__PURE__ */ w(Y, {
					kind: "fuel-pay",
					value: 1
				}),
				/* @__PURE__ */ w(Y, {
					kind: e,
					value: 1
				}),
				" → ",
				/* @__PURE__ */ w(Y, {
					kind: "repair",
					value: 1
				}),
				/* @__PURE__ */ w("small", { children: Ft(a, t, n, r, i) })
			] });
		}
		if (o.kind === "fuelTrade") return /* @__PURE__ */ T(C, { children: [
			/* @__PURE__ */ w(Y, {
				kind: "coin",
				value: 1
			}),
			" → ",
			/* @__PURE__ */ w(Y, {
				kind: "fuel",
				value: 1
			})
		] });
		if ([
			"fuel",
			"move",
			"drill",
			"draw",
			"refresh",
			"credits",
			"damage",
			"damageTop",
			"damageHand",
			"repair",
			"storage",
			"tank",
			"floorSilver"
		].includes(o.kind)) return /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w(xt, {
			kind: o.kind,
			amount: o.amount
		}), o.kind === "repair" && /* @__PURE__ */ w("small", { children: Ft(s, t, n, r, i) })] });
	}
	return /* @__PURE__ */ w(C, { children: It(e, t, n, r, i) });
}
//#endregion
//#region src/games/drillers/progress.tsx
function zt(e) {
	return e.reduce((e, t) => e + M[t.id].units, 0);
}
function Bt(e, t) {
	return Math.max(0, 26 - zt(e) - Math.min(10, t.length));
}
function Vt({ tiles: e, overflow: t, compact: n = !1, triggerName: r, triggered: i = !1 }) {
	let a = u(), o = zt(e), s = Math.min(10, t.length), c = Bt(e, t), l = 26 - s, d = /* @__PURE__ */ new Set(), f = 0;
	for (let t of e) d.add(f), f += M[t.id].units;
	let p = r ? a(i ? "games.drillers.endTriggered" : "games.drillers.lastRound") : a("games.drillers.endDistance", { n: c });
	return /* @__PURE__ */ T("div", {
		className: "drillers-end-track",
		"data-compact": n,
		"data-met": c === 0,
		children: [
			!n && /* @__PURE__ */ w("h3", { children: a("games.drillers.endProgress") }),
			/* @__PURE__ */ T("div", {
				className: "drillers-end-track-labels",
				children: [
					/* @__PURE__ */ T("span", { children: [a("games.drillers.trackTiles", { n: o }), " →"] }),
					/* @__PURE__ */ w("strong", { children: n && p }),
					/* @__PURE__ */ T("span", { children: ["← ", a("games.drillers.trackOverflow", { n: t.length })] })
				]
			}),
			/* @__PURE__ */ w("div", {
				className: "drillers-end-track-cells",
				role: "img",
				"aria-label": a("games.drillers.trackDescription", {
					tiles: o,
					overflow: s,
					n: c
				}),
				children: Array.from({ length: 26 }, (e, n) => /* @__PURE__ */ w("span", {
					"aria-hidden": "true",
					"data-kind": n >= l ? "mineral" : n < o ? "tile" : "empty",
					"data-start": d.has(n),
					"data-contact": c === 0 && n === l - 1,
					children: n >= l && /* @__PURE__ */ w(gt, { mineral: t[25 - n] })
				}, n))
			}),
			!n && /* @__PURE__ */ T(C, { children: [
				/* @__PURE__ */ w("div", {
					className: "drillers-end-track-markers",
					"aria-hidden": "true",
					children: [...se, 26].map((e) => /* @__PURE__ */ w("span", {
						style: { gridColumn: e },
						children: e
					}, e))
				}),
				/* @__PURE__ */ T("div", {
					className: "drillers-end-track-status",
					children: [/* @__PURE__ */ w("strong", { children: p }), /* @__PURE__ */ w("p", { children: r ? a("games.drillers.endTriggeredBy", { name: r }) : a("games.drillers.trackMeeting") })]
				}),
				r && /* @__PURE__ */ w("p", {
					className: "drillers-end-track-note",
					children: a("games.drillers.finalTurns")
				}),
				t.length > 10 && /* @__PURE__ */ w("p", {
					className: "drillers-end-track-note",
					children: a("games.drillers.overflowTrackLimit")
				})
			] })
		]
	});
}
//#endregion
//#region src/games/drillers/panels.tsx
function Ht({ title: e, kind: t, children: n, footer: i, onClose: a }) {
	let o = u(), c = s(null);
	return r(() => {
		let e = document.activeElement;
		return c.current?.querySelector("header button")?.focus(), () => {
			e?.isConnected && e.focus();
		};
	}, []), /* @__PURE__ */ w("div", {
		className: "drillers-modal-shade",
		"data-kind": t,
		onClick: a,
		children: /* @__PURE__ */ T("section", {
			ref: c,
			className: "drillers-modal",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onClick: (e) => e.stopPropagation(),
			onKeyDown: (e) => {
				if (e.key === "Escape" && (e.stopPropagation(), a()), e.key !== "Tab") return;
				let t = c.current?.querySelectorAll("button:not(:disabled), summary, [href], [tabindex=\"0\"]");
				if (!t?.length) return;
				let n = t[0], r = t[t.length - 1];
				e.shiftKey && document.activeElement === n ? (e.preventDefault(), r.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n.focus());
			},
			children: [
				/* @__PURE__ */ T("header", { children: [/* @__PURE__ */ w("h2", { children: e }), /* @__PURE__ */ w("button", {
					"aria-label": o("games.drillers.close"),
					onClick: a,
					children: /* @__PURE__ */ w(g, { size: 20 })
				})] }),
				/* @__PURE__ */ w("div", {
					className: "drillers-modal-body",
					children: n
				}),
				i && /* @__PURE__ */ w("footer", {
					className: "drillers-modal-footer",
					children: i
				})
			]
		})
	});
}
function Ut({ actions: e, pub: t, priv: n, rid: r, act: i }) {
	let a = u();
	return /* @__PURE__ */ w("div", {
		className: "drillers-choices",
		children: e.map((e, o) => /* @__PURE__ */ w("button", {
			className: "drillers-action",
			"aria-label": It(e, t, n, r, a),
			onClick: () => i(e),
			children: /* @__PURE__ */ w(Rt, {
				action: e,
				pub: t,
				priv: n,
				rid: r
			})
		}, o))
	});
}
function Z({ title: e, extra: t, children: n }) {
	return /* @__PURE__ */ T("section", {
		className: "drillers-panel-section",
		children: [/* @__PURE__ */ T("h3", { children: [e, t != null && /* @__PURE__ */ w("small", { children: t })] }), n]
	});
}
function Wt({ minerals: e, all: t = !1 }) {
	let n = u();
	return /* @__PURE__ */ w("div", {
		className: "drillers-mineral-list",
		children: k.filter((n) => t || e.includes(n)).map((t) => /* @__PURE__ */ w("span", { children: /* @__PURE__ */ w(Y, {
			kind: t,
			value: e.filter((e) => e === t).length,
			label: `${n(K[t])} ${e.filter((e) => e === t).length}`
		}) }, t))
	});
}
function Gt({ player: e }) {
	let t = u();
	return /* @__PURE__ */ w("dl", {
		className: "drillers-score",
		children: Object.entries(e.score).map(([e, n]) => /* @__PURE__ */ T("div", {
			"data-total": e === "total",
			children: [/* @__PURE__ */ w("dt", { children: t(lt[e]) }), /* @__PURE__ */ w("dd", { children: n })]
		}, e))
	});
}
function Kt({ pub: e, name: t }) {
	let n = u(), i = s(null);
	r(() => {
		i.current?.scrollIntoView({ block: "end" });
	}, [e.log.length]);
	let a = [];
	for (let t of e.log) {
		let e = a.at(-1);
		t.type === "resolve" && e?.rid === t.rid ? e.entries.push(t) : a.push({
			rid: t.rid,
			entries: [t]
		});
	}
	return a.length ? /* @__PURE__ */ w("ol", {
		className: "drillers-log-list",
		children: a.map((e, r) => /* @__PURE__ */ T("li", {
			ref: r === a.length - 1 ? i : void 0,
			children: [/* @__PURE__ */ w("b", { children: t(e.rid) }), e.entries.map((e, t) => /* @__PURE__ */ T("p", {
				"data-result": t > 0,
				children: [
					n(e.type === "dig" && e.mode === "barrier" ? "games.drillers.logBarrier" : e.type === "dig" && e.mode === "corridor" ? "games.drillers.logCorridor" : q[e.type] ?? q.resolve),
					e.id && (G[e.id] || K[e.id]) && /* @__PURE__ */ T(C, { children: [" · ", n(G[e.id] ?? K[e.id])] }),
					e.type === "move" && e.n !== void 0 && /* @__PURE__ */ T(C, { children: [" · ", X(e.n, n)] }),
					e.mode && e.type === "play" && /* @__PURE__ */ T(C, { children: [" · ", n(e.mode === "fuel" ? "games.drillers.fuelModeLabel" : "games.drillers.useMain")] })
				]
			}, t))]
		}, r))
	}) : /* @__PURE__ */ w("p", {
		className: "drillers-panel-empty",
		children: n("common.log.empty")
	});
}
function qt(e) {
	let t = u(), { sheet: n, pub: r, priv: i, rid: a, legal: o, name: s, color: c, act: l, open: d } = e, f = r.players.find((e) => e.rid === a), m = (e) => /* @__PURE__ */ w(Ut, {
		actions: e,
		pub: r,
		priv: i,
		rid: a,
		act: l
	});
	if (n.kind === "logs") return /* @__PURE__ */ w(Kt, {
		pub: r,
		name: s
	});
	if (n.kind === "score") {
		let e = r.players.find((e) => e.rid === (n.rid ?? a));
		return e && /* @__PURE__ */ w(Z, {
			title: t("games.drillers.panel.currentScore"),
			children: /* @__PURE__ */ w(Gt, { player: e })
		});
	}
	if (n.kind === "zone") {
		let e = r.players.find((e) => e.rid === n.rid);
		return /* @__PURE__ */ w("div", {
			className: "drillers-zone-cards",
			children: e?.[n.zone].map((e) => /* @__PURE__ */ w("button", {
				onClick: () => d({
					kind: "card",
					id: e.id
				}),
				"aria-label": t(G[e.id]),
				children: /* @__PURE__ */ w(Ot, { id: e.id })
			}, e.uid))
		});
	}
	if (n.kind === "card") return /* @__PURE__ */ T("div", {
		className: "drillers-card-detail",
		children: [/* @__PURE__ */ w(Ot, {
			id: n.id,
			showNotes: !1
		}), /* @__PURE__ */ T("div", {
			className: "drillers-card-detail-actions",
			children: [/* @__PURE__ */ w(Dt, { id: n.id }), m(o.filter((e) => (e.type === "play" || e.type === "discard") && e.n === n.uid || n.uid !== void 0 && e.type === "repair" && e.target === `${n.zone ?? "hand"}:${n.uid}`))]
		})]
	});
	if (n.kind === "shop") return /* @__PURE__ */ T(C, { children: [f && /* @__PURE__ */ T("div", {
		className: "drillers-shop-ledger",
		children: [/* @__PURE__ */ w(Y, {
			kind: "coin",
			value: f.credits
		}), /* @__PURE__ */ T("span", { children: [/* @__PURE__ */ w(Y, {
			kind: "drone",
			value: f.drones
		}), /* @__PURE__ */ w("small", { children: "/ 3" })] })]
	}), /* @__PURE__ */ w("div", {
		className: "drillers-shops",
		children: r.shops.map((e) => /* @__PURE__ */ T(Z, {
			title: t(ct[e.id]),
			extra: t("games.drillers.panel.cardsRemaining", { n: e.remaining }),
			children: [/* @__PURE__ */ w("div", {
				className: "drillers-shop-cards",
				children: e.cards.map((e) => {
					let n = o.filter((t) => t.type === "buy" && t.id === e);
					return /* @__PURE__ */ T("article", {
						className: "drillers-market-card",
						children: [
							/* @__PURE__ */ w(Ot, { id: e }),
							/* @__PURE__ */ T("div", {
								className: "drillers-shop-price",
								children: [
									/* @__PURE__ */ w(Y, {
										kind: "coin",
										value: j[e].price
									}),
									/* @__PURE__ */ w(Y, {
										kind: "drone",
										value: 1
									}),
									j[e].battery && /* @__PURE__ */ w(Y, {
										kind: "battery",
										value: 1
									})
								]
							}),
							/* @__PURE__ */ w("div", {
								className: "drillers-purchase",
								children: n.length ? n.map((e, n) => /* @__PURE__ */ T("button", {
									className: "drillers-action drillers-primary",
									"aria-label": It(e, r, i, a, t),
									onClick: () => l(e),
									children: [t("games.drillers.actions.buy"), e.n !== void 0 && /* @__PURE__ */ w("small", { children: t("games.drillers.tileNumber", { n: e.n + 1 }) })]
								}, n)) : /* @__PURE__ */ w("button", {
									className: "drillers-action",
									disabled: !0,
									children: t("games.drillers.actions.buy")
								})
							})
						]
					}, e);
				})
			}), m(o.filter((t) => t.type === "refreshShop" && t.id === e.id))]
		}, e.id))
	})] });
	if (n.kind === "actions") {
		let e = r.phase === "surfacing", n = o.filter((e) => ![
			"play",
			"keep",
			"surface",
			"upkeep",
			"refuel",
			"buy",
			"resolve",
			"refreshShop"
		].includes(e.type)), i = e ? [
			{
				title: t("games.drillers.panel.discardBuy"),
				actions: n.filter((e) => e.type === "discard"),
				shop: !0
			},
			{
				title: t("games.drillers.panel.upgradeRepair"),
				actions: n.filter((e) => e.type === "upgrade" || e.type === "repair")
			},
			{
				title: t("games.drillers.tilesTitle"),
				actions: n.filter((e) => e.type === "exhaust")
			},
			{
				title: t("games.drillers.storage"),
				actions: n.filter((e) => e.type === "sell")
			}
		] : [
			{
				title: t("games.drillers.panel.basic"),
				actions: n.filter((e) => e.type === "function")
			},
			{
				title: t("games.drillers.panel.currentFloor"),
				actions: n.filter((e) => [
					"move",
					"collect",
					"dig"
				].includes(e.type))
			},
			{
				title: t("games.drillers.abilityTitle"),
				actions: n.filter((e) => e.type === "ability")
			},
			{
				title: t("games.drillers.tilesTitle"),
				actions: n.filter((e) => e.type === "exhaust")
			},
			{
				title: t("games.drillers.storage"),
				actions: n.filter((e) => e.type === "sell")
			},
			{
				title: t("games.drillers.panel.other"),
				actions: n.filter((e) => ![
					"function",
					"move",
					"collect",
					"dig",
					"ability",
					"exhaust",
					"sell"
				].includes(e.type))
			}
		];
		return /* @__PURE__ */ T(C, { children: [
			f && /* @__PURE__ */ w(At, { player: f }),
			/* @__PURE__ */ w("div", {
				className: "drillers-panel-columns",
				children: i.filter((e) => e.actions.length || e.shop).map((e) => /* @__PURE__ */ T(Z, {
					title: e.title,
					children: [m(e.actions), e.shop && /* @__PURE__ */ T("button", {
						className: "drillers-panel-link",
						onClick: () => d({ kind: "shop" }),
						children: [t("games.drillers.panel.visitShop"), /* @__PURE__ */ w(p, { size: 15 })]
					})]
				}, e.title))
			}),
			!n.length && !e && /* @__PURE__ */ w("p", {
				className: "drillers-panel-empty",
				children: t("games.drillers.empty")
			})
		] });
	}
	if (n.kind === "floor") {
		let e = r.floors[n.n], i = e.open && e.corridors[0] ? M[e.corridors[0]] : null;
		return e.open ? /* @__PURE__ */ T("div", {
			className: "drillers-floor-details",
			children: [
				/* @__PURE__ */ T("div", { children: [
					e.card && /* @__PURE__ */ w(Pt, { id: e.card }),
					e.floor > 1 && /* @__PURE__ */ T("div", {
						className: "drillers-depth-summary",
						children: [/* @__PURE__ */ w("span", { children: t("games.drillers.score.depth") }), /* @__PURE__ */ w(Y, {
							kind: "score",
							value: -F[e.floor]
						})]
					}),
					e.minerals.length > 0 && /* @__PURE__ */ w(Z, {
						title: t("games.drillers.panel.floorMinerals"),
						children: /* @__PURE__ */ w(Wt, { minerals: e.minerals })
					})
				] }),
				/* @__PURE__ */ T("div", { children: [i && /* @__PURE__ */ w(Z, {
					title: t("games.drillers.panel.nextCorridor"),
					extra: t("games.drillers.remaining", { n: e.remaining }),
					children: /* @__PURE__ */ T("div", {
						className: "drillers-tile-preview",
						children: [/* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w(Y, {
							kind: "score",
							value: i.vp
						}), /* @__PURE__ */ w("small", { children: t("games.drillers.progressUnits", { n: i.units }) })] }), /* @__PURE__ */ w("div", {
							className: "drillers-minerals",
							children: i.minerals.map((e, n) => /* @__PURE__ */ w(gt, {
								mineral: e,
								role: "img",
								"aria-hidden": !1,
								"aria-label": t(K[e])
							}, n))
						})]
					})
				}), m(o.filter((t) => t.type === "move" && t.n === e.floor || t.type === "collect" && t.n === e.floor || t.type === "dig" && (t.mode === "barrier" ? (f?.floor ?? 0) + 1 : f?.floor) === e.floor))] }),
				(r.players.some((t) => t.floor === e.floor) || r.corporation?.floor === e.floor) && /* @__PURE__ */ w(Z, {
					title: t("games.drillers.panel.occupants"),
					children: /* @__PURE__ */ w("div", {
						className: "drillers-floor-visitors",
						children: [...r.players.filter((t) => t.floor === e.floor).map((e) => e.rid), ...r.corporation?.floor === e.floor ? ["$corporation"] : []].map((e) => /* @__PURE__ */ T("button", {
							className: "drillers-visitor",
							onClick: () => d({
								kind: "rig",
								rid: e
							}),
							style: { "--drillers-player": c(e) },
							children: [/* @__PURE__ */ w(J, { kind: "mech" }), s(e)]
						}, e))
					})
				})
			]
		}) : /* @__PURE__ */ T("div", {
			className: "drillers-floor-unrevealed",
			children: [
				/* @__PURE__ */ w(Mt, {}),
				/* @__PURE__ */ w("p", { children: t("games.drillers.locked") }),
				/* @__PURE__ */ w(Y, {
					kind: "drill",
					value: e.floor
				})
			]
		});
	}
	if (n.kind !== "rig") return null;
	let h = r.players.find((e) => e.rid === (n.rid ?? a));
	if (h) return /* @__PURE__ */ T("div", {
		className: "drillers-rig-content",
		children: [
			/* @__PURE__ */ w(At, { player: h }),
			/* @__PURE__ */ T("div", {
				className: "drillers-panel-columns",
				children: [/* @__PURE__ */ T("div", {
					className: "drillers-panel-stack",
					children: [/* @__PURE__ */ T(Z, {
						title: t("games.drillers.endProgress"),
						children: [/* @__PURE__ */ w(Vt, {
							compact: !0,
							tiles: h.tiles,
							overflow: h.overflow,
							triggerName: r.endTriggeredBy ? s(r.endTriggeredBy) : void 0,
							triggered: r.endTriggeredBy === h.rid
						}), /* @__PURE__ */ w("div", {
							className: "drillers-milestones",
							children: r.milestones.map((e, n) => /* @__PURE__ */ T("div", {
								"data-owned": e === h.rid,
								children: [
									/* @__PURE__ */ w("small", { children: n === 3 ? t("games.drillers.panel.finalMilestone") : t("games.drillers.panel.milestoneAt", { n: se[n] }) }),
									/* @__PURE__ */ w("b", { children: t("games.drillers.points", { n: ce[n] }) }),
									/* @__PURE__ */ w("span", { children: e ? s(e) : t("games.drillers.unclaimed") })
								]
							}, n))
						})]
					}), /* @__PURE__ */ w(Z, {
						title: t("games.drillers.storage"),
						extra: `${h.storage.length} / ${h.storageCap}`,
						children: /* @__PURE__ */ w("div", {
							className: "drillers-storage-slots",
							children: Array.from({ length: h.storageCap }, (e, n) => {
								let s = h.storage[n], c = h.rid === a ? o.find((e) => e.type === "sell" && e.id === s) : void 0;
								return /* @__PURE__ */ T("button", {
									className: "drillers-storage-slot",
									disabled: !c,
									onClick: () => c && l(c),
									"aria-label": c ? It(c, r, i, a, t) : t(s ? K[s] : "games.drillers.emptyStorage"),
									children: [
										/* @__PURE__ */ w("span", { children: s ? /* @__PURE__ */ w(gt, { mineral: s }) : /* @__PURE__ */ w(J, { kind: "cargo" }) }),
										s && /* @__PURE__ */ w("small", { children: t(K[s]) }),
										c && /* @__PURE__ */ w("b", { children: t("games.drillers.actions.sell") })
									]
								}, n);
							})
						})
					})]
				}), /* @__PURE__ */ T("div", {
					className: "drillers-panel-stack",
					children: [/* @__PURE__ */ w(Z, {
						title: t("games.drillers.market"),
						children: /* @__PURE__ */ w("div", {
							className: "drillers-market-grid",
							children: k.map((e, n) => /* @__PURE__ */ T("div", { children: [
								/* @__PURE__ */ T("span", {
									className: "drillers-mineral",
									children: [/* @__PURE__ */ w(gt, { mineral: e }), /* @__PURE__ */ w("span", { children: t(K[e]) })]
								}),
								[...ie[e]].reverse().map((e, t) => /* @__PURE__ */ w("span", {
									className: "drillers-market-slot",
									"data-filled": t < h.market[n],
									children: /* @__PURE__ */ w("b", { children: e })
								}, t)),
								/* @__PURE__ */ w("small", { children: t("games.drillers.panel.overflowValue", { n: ae[e] }) })
							] }, e))
						})
					}), h.overflow.length > 0 && /* @__PURE__ */ w(Z, {
						title: t("games.drillers.overflow"),
						extra: h.overflow.length,
						children: /* @__PURE__ */ w(Wt, { minerals: h.overflow })
					})]
				})]
			}),
			/* @__PURE__ */ T("div", {
				className: "drillers-panel-columns",
				children: [h.tiles.length > 0 && /* @__PURE__ */ w(Z, {
					title: t("games.drillers.tilesTitle"),
					extra: h.tiles.length,
					children: /* @__PURE__ */ w("div", {
						className: "drillers-tiles",
						children: h.tiles.map((e, n) => {
							let r = M[e.id], i = h.rid === a ? o.find((e) => e.type === "exhaust" && e.n === n) : void 0;
							return /* @__PURE__ */ T("article", {
								className: "drillers-owned-tile",
								"data-exhausted": e.exhausted,
								children: [
									/* @__PURE__ */ T("b", { children: [
										n + 1,
										" · ",
										X(r.floor, t),
										t(r.kind === "barrier" ? "games.drillers.barrier" : "games.drillers.corridor")
									] }),
									/* @__PURE__ */ w("span", {
										className: "drillers-tile-units",
										children: t("games.drillers.progressUnits", { n: r.units })
									}),
									/* @__PURE__ */ w("span", {
										className: "drillers-tile-points",
										children: /* @__PURE__ */ w(Y, {
											kind: "score",
											value: e.exhausted ? r.back : r.vp
										})
									}),
									/* @__PURE__ */ w("div", {
										className: "drillers-tile-reward",
										children: Object.entries(r.exhaust).map(([e, n]) => /* @__PURE__ */ w("span", { children: e === "battery" ? /* @__PURE__ */ w(Y, {
											kind: "battery",
											value: 1,
											label: t("games.drillers.tileBattery")
										}) : /* @__PURE__ */ w(xt, {
											kind: e === "droneRefresh" ? "refresh" : e,
											amount: Number(n)
										}) }, e))
									}),
									/* @__PURE__ */ w("small", { children: t("games.drillers.tileFlip", { n: r.back }) }),
									/* @__PURE__ */ w("button", {
										disabled: !i,
										onClick: () => i && l(i),
										children: t(e.exhausted ? "games.drillers.panel.flipped" : "games.drillers.actions.exhaust")
									})
								]
							}, n);
						})
					})
				}), /* @__PURE__ */ T("div", {
					className: "drillers-panel-stack",
					children: [
						(h.permanent.length > 0 || h.main.some((e) => dt[e])) && /* @__PURE__ */ w(Z, {
							title: t("games.drillers.abilityTitle"),
							children: [...h.permanent, ...new Set(h.main.filter((e) => dt[e]))].map((e, n) => /* @__PURE__ */ T("article", {
								className: "drillers-device",
								children: [
									/* @__PURE__ */ w("b", { children: t(G[e]) }),
									/* @__PURE__ */ w("p", { children: /* @__PURE__ */ w(St, { text: t(dt[e]) }) }),
									h.rid === a && m(o.filter((t) => t.type === "ability" && t.id === e))
								]
							}, `${e}:${n}`))
						}),
						/* @__PURE__ */ w(Z, {
							title: t("games.drillers.panel.deck"),
							children: ["play", "discard"].map((e) => /* @__PURE__ */ T("button", {
								className: "drillers-panel-link",
								onClick: () => d({
									kind: "zone",
									rid: h.rid,
									zone: e
								}),
								children: [
									t(st[e]),
									/* @__PURE__ */ w("small", { children: h[e].length }),
									/* @__PURE__ */ w(p, { size: 15 })
								]
							}, e))
						}),
						/* @__PURE__ */ T("button", {
							className: "drillers-panel-link",
							onClick: () => d({
								kind: "score",
								rid: h.rid
							}),
							children: [t("games.drillers.panel.scoreDetails"), /* @__PURE__ */ w(p, { size: 15 })]
						})
					]
				})]
			})
		]
	});
	let g = r.corporation;
	return !g || n.rid !== "$corporation" ? null : /* @__PURE__ */ T("div", {
		className: "drillers-panel-columns",
		children: [
			/* @__PURE__ */ T("div", {
				className: "drillers-panel-stack",
				children: [
					/* @__PURE__ */ T("div", {
						className: "drillers-corp-status",
						children: [/* @__PURE__ */ T("span", { children: [
							"★".repeat(g.difficulty),
							" · ",
							X(g.floor, t)
						] }), /* @__PURE__ */ w(Y, {
							kind: "score",
							value: g.score
						})]
					}),
					/* @__PURE__ */ w("p", { children: t("games.drillers.corpDeck", { n: g.remaining }) }),
					g.revealed && /* @__PURE__ */ T("div", {
						className: "drillers-corp-revealed",
						children: [/* @__PURE__ */ T("span", { children: [
							t("games.drillers.panel.currentCard"),
							" · ",
							t(G[g.revealed])
						] }), /* @__PURE__ */ w(Y, {
							kind: "fuel-pay",
							value: j[g.revealed].cost
						})]
					}),
					/* @__PURE__ */ w(Z, {
						title: t("games.drillers.endProgress"),
						children: /* @__PURE__ */ w(Vt, {
							compact: !0,
							tiles: g.tiles,
							overflow: g.overflow,
							triggerName: r.endTriggeredBy ? s(r.endTriggeredBy) : void 0,
							triggered: r.endTriggeredBy === "$corporation"
						})
					}),
					/* @__PURE__ */ w(Z, {
						title: t("games.drillers.score.minerals"),
						children: /* @__PURE__ */ w(Wt, {
							minerals: g.minerals,
							all: !0
						})
					})
				]
			}),
			/* @__PURE__ */ T("div", {
				className: "drillers-panel-stack",
				children: [/* @__PURE__ */ w(Z, {
					title: t("games.drillers.corpBoard"),
					children: /* @__PURE__ */ w("div", {
						className: "drillers-corp-table-wrap",
						children: /* @__PURE__ */ T("table", {
							className: "drillers-corp-table",
							children: [/* @__PURE__ */ w("thead", { children: /* @__PURE__ */ T("tr", { children: [/* @__PURE__ */ w("th", { children: /* @__PURE__ */ w(Y, { kind: "fuel-pay" }) }), [...pe[g.difficulty - 1].slots, "∞"].map((e, n) => /* @__PURE__ */ T("th", { children: [e, /* @__PURE__ */ w("small", { children: t("games.drillers.corpSlots") })] }, n))] }) }), /* @__PURE__ */ w("tbody", { children: [
								"3",
								"2",
								"1",
								"0"
							].map((e) => /* @__PURE__ */ T("tr", { children: [/* @__PURE__ */ w("th", { children: e === "3" ? "3+" : e }), pe[g.difficulty - 1].rows[e].map((e, n) => /* @__PURE__ */ T("td", { children: [/* @__PURE__ */ w(Y, {
								kind: "drill",
								value: e.drills
							}), e.move && /* @__PURE__ */ w(Y, {
								kind: "move",
								label: t("games.drillers.corpMove")
							})] }, n))] }, e)) })]
						})
					})
				}), /* @__PURE__ */ w(Z, {
					title: t("games.drillers.overflow"),
					extra: g.overflow.length,
					children: /* @__PURE__ */ w(Wt, { minerals: g.overflow })
				})]
			}),
			/* @__PURE__ */ w(Z, {
				title: t("games.drillers.tilesTitle"),
				extra: g.tiles.length,
				children: /* @__PURE__ */ w("div", {
					className: "drillers-corp-tiles",
					children: g.tiles.map((e, n) => /* @__PURE__ */ T("p", { children: [
						/* @__PURE__ */ w(y, { size: 15 }),
						X(M[e.id].floor, t),
						" · ",
						t(M[e.id].kind === "barrier" ? "games.drillers.barrier" : "games.drillers.corridor"),
						/* @__PURE__ */ w(Y, {
							kind: "score",
							value: M[e.id].vp
						})
					] }, n))
				})
			})
		]
	});
}
//#endregion
//#region src/games/drillers/view-player.tsx
function Jt(e) {
	x();
	let t = u(), n = e.public, r = e.private, [i, a] = c(null), { ref: o } = d("drillers-board"), { ref: s } = d("drillers-hand"), l = f(), p = n.players.find((t) => t.rid === e.myRid), m = n.phase === "done" ? [] : r?.legal ?? [], g = n.phase !== "done" && n.active === e.myRid, _ = (n) => n === "$corporation" ? t("games.drillers.corp") : e.members.find((e) => e.rid === n)?.name ?? n, C = (t) => t === "$corporation" ? "#aab9a4" : b[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % b.length].hex, E = (i) => It(i, n, r, e.myRid, t), D = (t) => {
		e.send(t), a(null);
	}, ne = (t) => /* @__PURE__ */ w(Ut, {
		actions: t,
		pub: n,
		priv: r,
		rid: e.myRid,
		act: D
	}), re = i?.kind === "card" ? t(G[i.id]) : i?.kind === "floor" ? X(i.n, t) : i?.kind === "shop" ? t("games.drillers.shopTitle") : i?.kind === "logs" ? t("common.log.title") : i?.kind === "score" ? t("games.drillers.panel.scoreDetails") : i?.kind === "zone" ? t(st[i.zone]) : i?.kind === "rig" ? _(i.rid ?? e.myRid) : t(n.phase === "surfacing" ? "games.drillers.phase.surfacing" : "games.drillers.phase.operations"), O = i?.kind === "actions" ? m.filter((e) => e.type === "surface" || e.type === "refuel" || e.type === "upkeep") : [], k = g && n.pending.length > 0, A = m.find((e) => e.type === (n.phase === "surfacing" ? "refuel" : n.phase === "keep" ? "upkeep" : "surface")) ?? (n.phase === "surfacing" ? m.find((e) => e.type === "upkeep") : void 0);
	return /* @__PURE__ */ T("div", {
		ref: o,
		className: "drillers-root",
		style: { "--drillers-player-rows": Math.ceil((n.players.length + Number(!!n.corporation)) / 2) },
		children: [/* @__PURE__ */ w("div", {
			className: "drillers-game-surface",
			inert: i !== null,
			children: /* @__PURE__ */ w(S, {
				adaptive: !0,
				scroll: !1,
				className: "drillers-screen",
				overlay: k ? /* @__PURE__ */ w("div", {
					className: "drillers-phase-overlay",
					children: /* @__PURE__ */ w("section", {
						className: "drillers-pending",
						"aria-label": t("games.drillers.actions.resolve"),
						children: /* @__PURE__ */ w("div", {
							className: "drillers-pending-scroll",
							children: n.pending.map((e, t) => /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("strong", { children: /* @__PURE__ */ w(xt, {
								kind: e.kind,
								amount: e.amount
							}) }), ne(m.filter((e) => e.type === "resolve" && e.n === t))] }, t))
						})
					})
				}) : n.phase === "keep" && g ? /* @__PURE__ */ w("div", {
					className: "drillers-phase-overlay",
					children: /* @__PURE__ */ T("div", {
						className: "drillers-keep-hint",
						children: [/* @__PURE__ */ w(h, { size: 18 }), /* @__PURE__ */ T("span", { children: [
							t("games.drillers.keepAllowance", { n: r?.keepFree ?? 1 }),
							" ",
							/* @__PURE__ */ w(Y, {
								kind: "fuel-pay",
								value: 1
							}),
							/* @__PURE__ */ T("b", { children: [
								t("games.drillers.keepSelection", { n: r?.kept.length ?? 0 }),
								" · ",
								/* @__PURE__ */ w(Y, {
									kind: "fuel-pay",
									value: Math.max(0, (r?.kept.length ?? 0) - (r?.keepFree ?? 1))
								})
							] })
						] })]
					})
				}) : void 0,
				children: /* @__PURE__ */ T("div", {
					className: "drillers-workspace",
					children: [/* @__PURE__ */ w(Lt, {
						pub: n,
						priv: r,
						me: p,
						myRid: e.myRid,
						name: _,
						color: C,
						act: D,
						openFloor: (e) => a({
							kind: "floor",
							n: e
						}),
						label: E
					}), /* @__PURE__ */ T("div", {
						className: "drillers-console",
						children: [/* @__PURE__ */ T("div", {
							className: "drillers-banner",
							children: [
								/* @__PURE__ */ T("header", {
									className: "drillers-phase",
									"data-waiting": !g && n.phase !== "done",
									children: [/* @__PURE__ */ w("span", { children: n.phase === "done" ? t("games.drillers.name") : n.endTriggeredBy ? t("games.drillers.lastRound") : t("games.drillers.turn", { n: n.turn }) }), /* @__PURE__ */ w("strong", { children: n.phase === "done" ? t("games.drillers.panel.finalScore") : g ? t(ot[n.phase]) : t("games.drillers.wait", { name: _(n.active) }) })]
								}),
								/* @__PURE__ */ T("div", {
									className: "drillers-players",
									children: [n.players.map((r) => /* @__PURE__ */ T("button", {
										ref: (e) => {
											l?.register(`seat:${r.rid}`, e);
										},
										className: "drillers-player",
										"data-active": r.rid === n.active,
										onClick: () => a({
											kind: "rig",
											rid: r.rid
										}),
										style: { "--drillers-player": C(r.rid) },
										children: [
											/* @__PURE__ */ w("span", {
												className: "drillers-player-mech",
												children: /* @__PURE__ */ w(J, { kind: "mech" })
											}),
											/* @__PURE__ */ T("span", {
												className: "drillers-player-name",
												children: [/* @__PURE__ */ w("b", { children: _(r.rid) }), /* @__PURE__ */ w("small", { children: X(r.floor, t) })]
											}),
											r.rid !== e.myRid && /* @__PURE__ */ w("span", {
												className: "drillers-progress",
												children: t("games.drillers.endDistanceShort", { n: Bt(r.tiles, r.overflow) })
											})
										]
									}, r.rid)), n.corporation && /* @__PURE__ */ T("button", {
										ref: (e) => {
											l?.register("seat:$corporation", e);
										},
										className: "drillers-player drillers-corp",
										"data-active": n.active === "$corporation",
										onClick: () => a({
											kind: "rig",
											rid: "$corporation"
										}),
										children: [
											/* @__PURE__ */ w("span", {
												className: "drillers-player-mech",
												children: /* @__PURE__ */ w(J, { kind: "mech" })
											}),
											/* @__PURE__ */ T("span", {
												className: "drillers-player-name",
												children: [/* @__PURE__ */ w("b", { children: t("games.drillers.corp") }), /* @__PURE__ */ T("small", { children: [
													X(n.corporation.floor, t),
													" · ",
													"★".repeat(n.corporation.difficulty)
												] })]
											}),
											/* @__PURE__ */ w("span", {
												className: "drillers-progress",
												children: /* @__PURE__ */ w(Y, {
													kind: "score",
													value: n.corporation.score
												})
											})
										]
									})]
								}),
								p ? /* @__PURE__ */ w("button", {
									className: "drillers-track-button",
									onClick: () => a({ kind: "rig" }),
									"aria-label": `${t("games.drillers.rig")} · ${n.endTriggeredBy ? t("games.drillers.lastRound") : t("games.drillers.endDistance", { n: Bt(p.tiles, p.overflow) })}`,
									children: /* @__PURE__ */ w(Vt, {
										compact: !0,
										tiles: p.tiles,
										overflow: p.overflow,
										triggerName: n.endTriggeredBy ? _(n.endTriggeredBy) : void 0,
										triggered: n.endTriggeredBy === p.rid
									})
								}) : /* @__PURE__ */ w("div", {}),
								p ? /* @__PURE__ */ w(At, {
									player: p,
									animate: !0
								}) : /* @__PURE__ */ w("div", { className: "drillers-dashboard" })
							]
						}), /* @__PURE__ */ T("div", {
							className: "drillers-controls",
							children: [
								/* @__PURE__ */ T("div", {
									className: "drillers-hand-heading",
									children: [/* @__PURE__ */ T("span", { children: [
										t("games.drillers.zone.hand"),
										" ",
										/* @__PURE__ */ w("b", { children: r?.hand.length ?? 0 })
									] }), /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ T("button", {
										className: "drillers-top-link",
										disabled: !r?.top,
										onClick: () => r?.top && a({
											kind: "card",
											id: r.top.id,
											uid: r.top.uid,
											zone: "deck"
										}),
										children: [
											t("games.drillers.zone.deck"),
											" ",
											p?.deckCount ?? 0
										]
									}), /* @__PURE__ */ w("button", {
										className: "drillers-log-entry",
										onClick: () => a({ kind: "logs" }),
										"aria-label": t("common.log.title"),
										children: /* @__PURE__ */ w(ee, { size: 17 })
									})] })]
								}),
								/* @__PURE__ */ w("div", {
									ref: s,
									className: "drillers-hand",
									children: r?.hand.map((o) => /* @__PURE__ */ w("button", {
										className: "drillers-hand-card",
										"data-selected": i?.kind === "card" && i.uid === o.uid && i.zone !== "deck",
										"data-kept": r.kept.includes(o.uid),
										"aria-pressed": n.phase === "keep" ? r.kept.includes(o.uid) : i?.kind === "card" && i.uid === o.uid,
										"aria-label": n.phase === "keep" && g ? `${t("games.drillers.actions.keep")} ${t(G[o.id])}${r.kept.includes(o.uid) ? ` · ${t("games.drillers.selected")}` : ""}` : t(G[o.id]),
										onClick: () => n.phase === "keep" && m.some((e) => e.type === "keep" && e.n === o.uid) ? e.send({
											type: "keep",
											n: o.uid
										}) : a({
											kind: "card",
											id: o.id,
											uid: o.uid,
											zone: "hand"
										}),
										children: /* @__PURE__ */ w(kt, {
											id: o.id,
											kept: n.phase === "keep" && r.kept.includes(o.uid)
										})
									}, o.uid))
								}),
								/* @__PURE__ */ T("div", {
									className: "drillers-public-cards",
									children: [/* @__PURE__ */ T("div", { children: [
										/* @__PURE__ */ T("button", {
											className: "drillers-zone-heading",
											onClick: () => a({
												kind: "zone",
												rid: e.myRid,
												zone: "play"
											}),
											children: [
												t("games.drillers.zone.play"),
												" ",
												p?.play.length ?? 0
											]
										}),
										/* @__PURE__ */ w("div", {
											className: "drillers-played-cards",
											children: p?.play.map((e) => /* @__PURE__ */ w("button", {
												onClick: () => a({
													kind: "card",
													id: e.id
												}),
												"aria-label": t(G[e.id]),
												children: /* @__PURE__ */ w(kt, { id: e.id })
											}, e.uid))
										}),
										/* @__PURE__ */ T("button", {
											className: "drillers-zone-heading",
											onClick: () => a({
												kind: "zone",
												rid: e.myRid,
												zone: "discard"
											}),
											children: [
												t("games.drillers.zone.discard"),
												" ",
												p?.discard.length ?? 0,
												" ›"
											]
										})
									] }), /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ T("span", {
										className: "drillers-zone-heading",
										children: [
											t("games.drillers.topTitle"),
											" · ",
											p?.deckCount ?? 0
										]
									}), r?.top && /* @__PURE__ */ w("button", {
										className: "drillers-deck-top",
										onClick: () => a({
											kind: "card",
											id: r.top.id,
											uid: r.top.uid,
											zone: "deck"
										}),
										"aria-label": `${t("games.drillers.topTitle")} · ${t(G[r.top.id])}`,
										children: /* @__PURE__ */ w(kt, { id: r.top.id })
									})] })]
								}),
								/* @__PURE__ */ T("nav", {
									className: "drillers-toolbar",
									children: [
										/* @__PURE__ */ T("button", {
											onClick: () => a({ kind: "shop" }),
											children: [/* @__PURE__ */ w(y, { size: 18 }), /* @__PURE__ */ w("span", { children: t("games.drillers.shopTitle") })]
										}),
										/* @__PURE__ */ T("button", {
											onClick: () => a({ kind: "rig" }),
											children: [/* @__PURE__ */ w(te, { size: 18 }), /* @__PURE__ */ w("span", { children: t("games.drillers.rig") })]
										}),
										/* @__PURE__ */ T("button", {
											onClick: () => a({ kind: "actions" }),
											children: [/* @__PURE__ */ w(v, { size: 18 }), /* @__PURE__ */ w("span", { children: t("games.drillers.actionsMenu") })]
										}),
										/* @__PURE__ */ w("button", {
											className: "drillers-primary",
											disabled: !A,
											onClick: () => A && D(A),
											children: t(n.phase === "operations" ? "games.drillers.actions.surface" : "games.drillers.confirm")
										})
									]
								})
							]
						})]
					})]
				})
			})
		}), i && /* @__PURE__ */ w(Ht, {
			title: re,
			kind: i.kind,
			footer: O.length > 0 ? ne(O) : void 0,
			onClose: () => a(null),
			children: /* @__PURE__ */ w(qt, {
				sheet: i,
				pub: n,
				priv: r,
				rid: e.myRid,
				legal: m,
				name: _,
				color: C,
				act: D,
				open: a
			})
		}, i.kind + (i.kind === "card" ? i.id : ""))]
	});
}
//#endregion
//#region src/games/drillers/bot-belief.ts
function Yt(e, t) {
	let n = e.public.players[0], r = e.private, i = e.public.corporation, a = t?.turn !== e.public.turn, o = t ? {
		...t,
		catalog: [...t.catalog],
		retired: [...t.retired],
		corpSeen: [...t.corpSeen],
		used: [...t.used]
	} : {
		turn: e.public.turn,
		catalog: [],
		retired: [],
		corpSeen: [],
		corpRemaining: 9,
		used: [],
		fuelCards: 0,
		gainedMove: 0,
		gainedDrill: 0,
		repaired: !1,
		source: null
	};
	a && Object.assign(o, {
		turn: e.public.turn,
		used: [],
		fuelCards: 0,
		gainedMove: 0,
		gainedDrill: 0,
		repaired: !1,
		source: null
	});
	for (let e of [
		...r.hand,
		...n.play,
		...n.discard,
		...r.top ? [r.top] : []
	]) o.catalog.some((t) => t.uid === e.uid) || o.catalog.push(e);
	return i.remaining < o.corpRemaining && i.revealed && o.corpSeen.push(i.revealed), o.corpRemaining = i.remaining, o;
}
function Xt(e, t, n) {
	let r = {
		...e,
		used: [...e.used],
		retired: [...e.retired]
	}, i = n.public.players[0];
	t.type === "play" && (t.mode === "fuel" ? r.fuelCards++ : r.source = t.n), t.type === "function" && (t.id === "damage" && r.used.push("damage"), t.id === "move" && r.gainedMove++, t.id === "drill" && r.gainedDrill++), t.type === "ability" && (t.id === "adaptive_engine" ? r.gainedMove++ : t.id !== "repair_drone" && r.used.push(t.id)), t.type === "collect" && t.n !== i.floor && r.used.push("harpoon_drill");
	let a = t.type === "repair" ? t.target : void 0;
	if (t.type === "repair" && (r.repaired = !0), t.type === "resolve") {
		let e = n.public.pending[t.n];
		t.target !== "skip" && (e.kind === "move" && (r.gainedMove += e.amount), e.kind === "drill" && (r.gainedDrill += e.amount), e.kind === "choice" && (t.target === "move" && r.gainedMove++, t.target === "drill" && r.gainedDrill++, t.target?.startsWith("repair:") && (a = t.target.slice(7))), e.kind === "repair" && (a = t.target), e.kind === "floorRust" && (a = t.target.split("|")[1]), e.kind === "scrapSelf" && r.source !== null && r.retired.push(r.source));
	}
	return a && a !== "skip" && r.retired.push(Number(a.split(":").at(-1))), r;
}
function Zt(e, t, n) {
	let r = e.public, i = e.private, a = r.players[0], o = r.corporation, s = (r.turn * 2654435761 ^ n * 2246822519 ^ a.fuel * 397 ^ a.credits * 7919) >>> 0, c = () => (s ^= s << 13, s ^= s >>> 17, s ^= s << 5, (s >>> 0) / 4294967296), l = (e) => {
		e = [...e];
		for (let t = e.length - 1; t > 0; t--) {
			let n = Math.floor(c() * (t + 1));
			[e[t], e[n]] = [e[n], e[t]];
		}
		return e;
	}, u = [
		...i.hand,
		...a.play,
		...a.discard,
		...i.top ? [i.top] : []
	], d = t.catalog.filter((e) => !t.retired.includes(e.uid)), f = new Set(u.map((e) => e.uid)), p = 1e5, m = [...ue, "damage"].filter((e) => !t.catalog.some((t) => t.uid < 9 && t.id === e)).map((e) => ({
		id: e,
		uid: p++
	})), h = l([...d.filter((e) => !f.has(e.uid)), ...m]), g = [...i.top ? [i.top] : [], ...h].slice(0, a.deckCount);
	for (; g.length < a.deckCount;) g.push({
		id: "damage",
		uid: p++
	});
	let _ = {
		...a,
		hand: [...i.hand],
		deck: g,
		discard: [...a.discard],
		play: [...a.play],
		storage: [...a.storage],
		overflow: [...a.overflow],
		market: [...a.market],
		tiles: a.tiles.map((e) => ({ ...e })),
		permanent: [...a.permanent],
		main: [...a.main],
		used: [...t.used],
		gainedMove: t.gainedMove,
		gainedDrill: t.gainedDrill,
		fuelCards: t.fuelCards,
		firstCorridor: [...i.firstCorridor],
		keepFree: i.keepFree,
		kept: [...i.kept],
		repaired: t.repaired,
		refuelled: !1
	}, ee = [...a.tiles, ...o.tiles].map((e) => e.id), v = l(fe.filter((e) => !r.floors.some((t) => t.card === e))), y = r.floors.map((e) => {
		let t = e.corridors[0], n = l(Object.values(M).filter((n) => n.floor === e.floor && n.kind === "corridor" && n.id !== t && !ee.includes(n.id)).map((e) => e.id));
		return {
			...e,
			minerals: e.open ? [...e.minerals] : [...N[e.floor] ?? []],
			corridors: [...t ? [t] : [], ...n].slice(0, e.remaining),
			card: e.card ?? (e.floor >= 3 ? v.shift() : null),
			jackpot: [...e.jackpot]
		};
	}), te = [...t.catalog.map((e) => e.id), ...a.permanent], b = {}, x = {}, S = [];
	for (let e of A) {
		let t = r.shops.find((t) => t.id === e), n = l(Object.values(j).filter((n) => n.type === e && !t.cards.includes(n.id) && !te.includes(n.id)).map((e) => e.id));
		x[e] = [...t.cards], e === "advanced" && !y[4].open && (S = n.splice(0, 2)), b[e] = n.slice(0, t.remaining);
	}
	let C = [...ue, "damage"];
	for (let e of t.corpSeen) {
		let t = C.indexOf(e);
		t >= 0 && C.splice(t, 1);
	}
	return {
		seed: Math.floor(c() * 2147483647),
		cursor: 0,
		uid: p,
		players: [a.rid],
		people: { [a.rid]: _ },
		active: r.active,
		turn: r.turn,
		phase: r.phase,
		floors: y,
		shopDecks: b,
		shopCards: x,
		expansion: S,
		milestones: [...r.milestones],
		endTriggeredBy: r.endTriggeredBy,
		finalWaiting: r.endTriggeredBy ? r.endTriggeredBy === a.rid ? ["$corporation"] : [a.rid] : [],
		pending: r.pending.map((e) => ({ ...e })),
		source: t.source,
		upkeepStep: 0,
		corporation: {
			...o,
			deck: l(C).slice(0, o.remaining),
			minerals: [...o.minerals],
			overflow: [...o.overflow],
			tiles: o.tiles.map((e) => ({ ...e })),
			step: o.step,
			drills: 0,
			shouldMove: !1,
			collected: []
		},
		damageRemaining: r.damageRemaining,
		log: []
	};
}
function Q(e) {
	let t = e.players[0], n = e.people[t], r = e.corporation;
	return {
		...e,
		people: { [t]: {
			...n,
			hand: [...n.hand],
			deck: [...n.deck],
			discard: [...n.discard],
			play: [...n.play],
			storage: [...n.storage],
			market: [...n.market],
			overflow: [...n.overflow],
			tiles: n.tiles.map((e) => ({ ...e })),
			permanent: [...n.permanent],
			main: [...n.main],
			used: [...n.used],
			firstCorridor: [...n.firstCorridor],
			kept: [...n.kept]
		} },
		floors: e.floors.map((e) => ({
			...e,
			minerals: [...e.minerals],
			corridors: [...e.corridors],
			jackpot: [...e.jackpot]
		})),
		shopCards: Object.fromEntries(A.map((t) => [t, [...e.shopCards[t]]])),
		shopDecks: Object.fromEntries(A.map((t) => [t, [...e.shopDecks[t]]])),
		expansion: [...e.expansion],
		milestones: [...e.milestones],
		finalWaiting: [...e.finalWaiting],
		pending: [...e.pending],
		corporation: {
			...r,
			deck: [...r.deck],
			minerals: [...r.minerals],
			overflow: [...r.overflow],
			tiles: r.tiles.map((e) => ({ ...e })),
			collected: [...r.collected]
		},
		log: []
	};
}
//#endregion
//#region src/games/drillers/bot-moves.ts
var Qt = (e) => e.people[e.players[0]];
function $t(e, t) {
	return H(e.s, t) ? (e.actions.push(t), !0) : !1;
}
function en(e) {
	let t = [e], n = [];
	for (let e = 0; e < 16 && t.length; e++) {
		let e = [];
		for (let r of t) {
			if (!r.s.pending.length) {
				n.push(r);
				continue;
			}
			let t = r.s, i = t.pending[0], a = Qt(t), o = Xe(t).filter((e) => e.n === 0);
			i.kind === "repair" && (o = o.filter((e) => e.target === "skip" || [
				...a.hand,
				...a.play,
				...a.discard,
				...a.deck.slice(0, 1)
			].some((t) => t.uid === Number(e.target.split(":")[1]) && (t.id === "damage" || j[t.id].vp < 0))), o = o.slice(0, 4).concat(o.filter((e) => e.target === "skip"))), i.kind === "floorRust" && (o = o.filter((e) => e.target === "skip" || [
				...a.hand,
				...a.play,
				...a.discard,
				...a.deck.slice(0, 1)
			].some((t) => t.uid === Number(e.target.split(":").at(-1)) && t.id === "damage")));
			for (let n of o) {
				let i = {
					s: Q(t),
					actions: [...r.actions]
				};
				$t(i, n) && e.push(i);
			}
		}
		t = e;
	}
	return n;
}
function tn(e, t) {
	let n = {
		s: Q(e),
		actions: []
	}, r = Qt(n.s), i = Math.abs(t - r.floor), a = r.main.includes("adaptive_engine") ? 2 : 3;
	if (!(r.fuel < Math.max(0, i - r.move) * a)) {
		for (; r.move < i;) if (!$t(n, {
			type: r.main.includes("adaptive_engine") ? "ability" : "function",
			id: r.main.includes("adaptive_engine") ? "adaptive_engine" : "move"
		})) return;
		for (; r.floor !== t;) if (!$t(n, {
			type: "move",
			n: r.floor + Math.sign(t - r.floor)
		})) return;
		return n;
	}
}
function nn(e, t, n) {
	let r = {
		s: Q(e.s),
		actions: [...e.actions]
	}, i = Qt(r.s);
	if (i.fuel < Math.max(0, n - i.drill) * 4) return [];
	for (; i.drill < n;) if (!$t(r, {
		type: "function",
		id: "drill"
	})) return [];
	return $t(r, t) ? en(r) : [];
}
function rn(e) {
	if (e.pending.length) return en({
		s: Q(e),
		actions: []
	});
	let t = [], n = Qt(e);
	for (let r of Xe(e)) {
		if ([
			"move",
			"dig",
			"collect",
			"keep"
		].includes(r.type) || r.type === "function" && r.id !== "damage" || r.type === "refreshShop" || r.type === "ability" && r.id === "adaptive_engine" || r.type === "upgrade" && (e.endTriggeredBy || (r.id === "storage" ? n.storageCap >= 4 : n.fuelCap >= 13)) || r.type === "repair" && ![
			...n.hand,
			...n.play,
			...n.discard,
			...n.deck.slice(0, 1)
		].some((e) => e.uid === Number(r.target.split(":")[1]) && j[e.id].vp <= -2)) continue;
		if (r.type === "buy" && r.n !== void 0) {
			let e = n.tiles.flatMap((e, t) => !e.exhausted && M[e.id].exhaust.battery ? [{
				i: t,
				loss: M[e.id].vp - M[e.id].back
			}] : []).sort((e, t) => e.loss - t.loss)[0];
			if (r.n !== e?.i) continue;
		}
		let i = {
			s: Q(e),
			actions: []
		};
		$t(i, r) && t.push(...en(i));
	}
	if (e.phase !== "operations") return t;
	for (let r of e.floors) if (r.open) {
		let i = tn(e, r.floor);
		if (!i) continue;
		if (i.actions.length && t.push(i), r.floor >= 2 && r.corridors.length && t.push(...nn(i, {
			type: "dig",
			mode: "corridor"
		}, P[r.floor] - Number(r.card === "hot_tub" && !n.firstCorridor.includes(r.floor)))), r.floor >= 2 && r.floor < 6 && !e.floors[r.floor + 1].open && t.push(...nn(i, {
			type: "dig",
			mode: "barrier"
		}, r.floor + 1)), n.storage.length < n.storageCap) {
			for (let e of new Set(r.minerals)) t.push(...nn(i, {
				type: "collect",
				id: e,
				n: r.floor
			}, e === "silver" && n.main.includes("suction_engine") ? 0 : 1));
			r.jackpot.includes(n.rid) && t.push(...nn(i, {
				type: "collect",
				id: "emerald",
				n: r.floor,
				mode: "jackpot"
			}, 1));
		}
	}
	if (n.main.includes("harpoon_drill") && !n.used.includes("harpoon_drill")) {
		for (let r of e.floors) if (r.open && Math.abs(r.floor - n.floor) === 1) for (let n of new Set(r.minerals)) t.push(...nn({
			s: e,
			actions: []
		}, {
			type: "collect",
			id: n,
			n: r.floor
		}, 1));
	}
	return t;
}
//#endregion
//#region src/games/drillers/bot-power.ts
var an = (e) => {
	let t = {
		fuel: -j[e].cost,
		utility: 0,
		draw: 0
	};
	for (let n of L[e] ?? me[e] ?? []) n.kind === "drill" && (t.utility += n.amount * 3), n.kind === "move" && (t.utility += n.amount * .7), n.kind === "fuel" && (t.fuel += n.amount), n.kind === "draw" && (t.draw += n.amount), n.kind === "credits" && (t.utility += n.amount * .2), n.kind === "refresh" && (t.utility += n.amount * 2), n.kind === "repair" && (t.utility += 2), n.kind === "teleport" && (t.utility += 3), n.kind === "choice" && (t.utility += n.amount === 3 ? 3 : 1.5), (n.kind === "damage" || n.kind === "damageTop" || n.kind === "damageHand") && (t.utility -= 3);
	return e === "burner_drill" && (t.fuel += 2), e === "surgeon" && t.fuel--, e === "deep_neural_network" && (t.fuel -= 2), t;
}, on = /* @__PURE__ */ new Map();
function sn(e, t) {
	let n = e.slice().sort().join(",") + "|" + t.slice().sort().join(","), r = on.get(n);
	if (r !== void 0) return r;
	let i = e.map(an), a = e.map((e) => j[e].fuel), o = t.map(an).reduce((e, t) => ({
		fuel: e.fuel + t.fuel,
		utility: e.utility + t.utility,
		draw: e.draw + t.draw
	}), {
		fuel: 0,
		utility: 0,
		draw: 0
	}), s = -10;
	for (let t of [
		.25,
		.5,
		.75,
		1,
		1.5,
		2,
		3
	]) {
		let n = 1;
		for (let r = 0; r < 5; r++) {
			let r = 0, c = 0, l = 0;
			for (let o = 0; o < e.length; o++) {
				let e = i[o];
				e.utility + e.fuel * t + e.draw * n > a[o] * t ? (r += e.fuel, c += e.utility, l += e.draw) : r += a[o];
			}
			let u = (3 + o.draw) / Math.max(1, e.length - l), d = r * u + o.fuel + 3, f = c * u + o.utility + d * .75 - Math.max(0, -d) * 3;
			s = Math.max(s, f), n = Math.max(0, (c + r * t) / Math.max(1, e.length - l));
		}
	}
	return on.size > 2e4 && on.clear(), on.set(n, s), s;
}
var cn = sn([...ue, "damage"], []), ln = {
	beam: 32,
	steps: 20,
	turns: 2,
	samples: 3,
	engine: 1,
	fuel: .5,
	hand: .6,
	drill: 2,
	move: .9,
	discount: .85,
	endings: 20,
	diversity: 4,
	position: 1,
	ownership: .5,
	progress: 0,
	release: 0,
	logistics: 1,
	mineral: 0,
	power: 0
}, un = (e) => {
	let t = j[e], n = Math.max(.3, t.fuel * .5), r = -t.cost * .5;
	for (let t of L[e] ?? me[e] ?? []) t.kind === "drill" && (r += t.amount * 2), t.kind === "move" && (r += t.amount * .9), t.kind === "fuel" && (r += t.amount * .5), t.kind === "draw" && (r += t.amount * 2.2), t.kind === "repair" && (r += 1.2), t.kind === "refresh" && (r += t.amount * 1.2), t.kind === "credits" && (r += t.amount * .2), t.kind === "teleport" && (r += 5), t.kind === "choice" && (r += t.amount === 3 ? 2 : 1.5), (t.kind === "damage" || t.kind === "damageTop" || t.kind === "damageHand") && (r -= 3);
	return e === "suction_engine" && (r += 2), e === "jackhammer" && (r += 2), e === "burner_drill" && (r += 1), e === "flywheel" && (r += 1), Math.max(n, r);
};
function dn(e, t, n = !1) {
	let r = e.people[e.players[0]], i = e.corporation, a = W(e, r.rid), o = a.total - tt(e);
	if (o += (a.tiles + a.minerals + a.milestones) * t.ownership, o += r.tiles.reduce((e, t) => e + M[t.id].units, 0) * t.progress, o += a.minerals * t.mineral, e.phase === "done") return o;
	let s = r.tiles.reduce((e, t) => e + M[t.id].units, 0), c = i.tiles.reduce((e, t) => e + M[t.id].units, 0) + Math.min(10, i.overflow.length), l = e.endTriggeredBy ? 0 : Math.min(i.deck.length * 1.5, Math.max(1, (26 - Math.max(c, s)) / 1.7)), u = Math.min(1, l / 4), d = e.floors.filter((e) => e.open).flatMap((e) => e.minerals).map((e) => k.indexOf(e) + 2).sort((e, t) => t - e);
	o -= d.slice(0, Math.ceil(l * 2.5)).reduce((e, t) => e + t, 0) * t.release, o += F[r.floor] * u, o += r.credits / 5 - a.credits, o += r.fuel * t.fuel * u;
	let f = [
		...r.hand,
		...r.deck,
		...r.discard,
		...r.play
	], p = f.reduce((e, t) => e + un(t.id), 0) / Math.max(1, f.length);
	if (t.power ? o += (sn(f.map((e) => e.id), r.permanent) - cn) * Math.min(6, l) * t.engine : (o += (p - 2.2) * Math.min(6, l) * t.engine, o += r.permanent.reduce((e, t) => e + un(t), 0) * Math.min(6, l) * t.engine), o += r.hand.reduce((e, t) => e + un(t.id), 0) * t.hand * u, o += Math.min(r.storageCap - 2, 4) * u * 1.2 * t.logistics, o += (r.fuelCap - 10) * u * .6, o += r.drones * u * .5 * t.logistics, n && e.phase === "operations") {
		let n = e.floors.find((e) => e.floor >= 3 && !e.open), i = Math.max(n?.floor ?? 0, P[r.floor], 2);
		o += Math.min(i + 1, r.drill) * t.drill;
		let a = r.floor === 0 ? Math.min(5, e.floors.filter((e) => e.open).length - 1) : r.floor;
		o += Math.min(a, r.move) * t.move;
	}
	if (r.floor > 0 && u) {
		let n = e.floors[r.floor], i = n.corridors.length || n.minerals.length || fn(e, r.floor), a = n.corridors[0] ? M[n.corridors[0]] : void 0, s = a ? a.vp / P[r.floor] * 3 : 0, c = Math.min(1, (r.fuel + r.hand.reduce((e, t) => e + j[t.id].fuel, 0) + 5) / 12);
		o += i ? Math.max(s - 5, 0) * c * u * t.position : -1;
	}
	return o;
}
var fn = (e, t) => t < 6 && !e.floors[t + 1].open, pn = (e) => JSON.stringify([
	e.type,
	e.id,
	e.n,
	e.mode,
	e.target
]), mn = (e) => [
	e.floor,
	e.fuel,
	e.fuelCap,
	e.storageCap,
	e.credits,
	e.move,
	e.drill,
	e.drones,
	e.storage,
	e.market,
	e.overflow,
	e.tiles,
	e.permanent,
	e.main,
	e.refreshAvailable,
	e.discard,
	e.play
], hn = (e) => JSON.stringify([
	e.public.turn,
	e.public.phase,
	mn(e.public.players[0]),
	e.private?.hand,
	e.private?.top,
	e.private?.kept,
	e.public.pending,
	e.public.floors,
	e.public.shops
]), gn = (e) => {
	let t = e.people[e.players[0]];
	return JSON.stringify([
		e.turn,
		e.phase,
		mn({
			...t,
			handCount: t.hand.length,
			deckCount: t.deck.length,
			score: W(e, t.rid)
		}),
		t.hand,
		t.deck[0] ?? null,
		t.kept,
		e.pending,
		e.floors.map((e) => ({
			...e,
			minerals: e.open ? e.minerals : [],
			corridors: e.corridors.slice(0, 1),
			remaining: e.corridors.length,
			card: e.open ? e.card : null
		})),
		A.map((t) => ({
			id: t,
			cards: e.shopCards[t],
			remaining: e.shopDecks[t].length
		}))
	]);
};
function _n(e) {
	let t = e.people[e.players[0]], n = (e) => [...e].sort();
	return JSON.stringify([
		e.phase,
		t.floor,
		t.fuel,
		t.fuelCap,
		t.storageCap,
		t.credits,
		t.move,
		t.drill,
		t.drones,
		n(t.hand.map((e) => e.uid)),
		t.deck.map((e) => e.uid),
		n(t.discard.map((e) => e.uid)),
		n(t.play.map((e) => e.uid)),
		n(t.main),
		n(t.used),
		n(t.storage),
		t.market,
		n(t.overflow),
		t.tiles.map((e) => [e.id, e.exhausted]).sort(),
		n(t.permanent),
		n(t.kept),
		t.gainedDrill,
		t.gainedMove,
		t.fuelCards,
		n([...new Set(t.firstCorridor)]),
		t.repaired,
		e.pending.some((e) => e.kind === "scrapSelf") ? e.source : null,
		e.pending,
		e.cursor,
		e.floors.map((e) => [
			e.open,
			e.corridors.length,
			n(e.minerals),
			e.jackpot
		]),
		e.shopCards,
		e.milestones
	]);
}
function vn(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) {
		let e = t.s.people[t.s.players[0]], r = JSON.stringify([
			t.first,
			t.s.phase,
			e.floor,
			e.fuel,
			e.fuelCap,
			e.storageCap,
			e.credits,
			e.drones,
			e.hand.map((e) => e.id).sort(),
			e.tiles.map((e) => [e.id, e.exhausted]).sort(),
			e.permanent.slice().sort(),
			e.storage.slice().sort(),
			e.market,
			e.overflow.slice().sort(),
			e.discard.map((e) => e.id).sort(),
			e.deck.map((e) => e.id),
			t.s.corporation,
			t.s.milestones
		]);
		(!n.has(r) || n.get(r).value < t.value) && n.set(r, t);
	}
	let r = [...n.values()].sort((e, t) => t.value - e.value), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
	for (let e of r) a.has(e.first) || a.set(e.first, e);
	let o = r.filter((e) => {
		let t = e.s.people[e.s.players[0]], n = `${t.floor}/${t.permanent.length}/${t.hand.length}/${t.tiles.length}`, r = i.get(n) ?? 0;
		return i.set(n, r + 1), r < 2;
	});
	return [...a.values(), ...o.filter((e) => ![...a.values()].includes(e))].slice(0, t);
}
function yn(e) {
	let t = 0;
	for (; e.phase === "upkeep" || e.phase === "corporate";) if (et(e), ++t > 120) throw Error("MODEL_TICK_LOOP");
}
function bn(e) {
	let t = e.s.people[e.s.players[0]], n = [...t.hand].sort((e, t) => un(t.id) - un(e.id));
	return [.../* @__PURE__ */ new Set([
		0,
		1,
		t.keepFree,
		2,
		3,
		4,
		t.hand.length
	])].filter((e) => e <= t.hand.length && Math.max(0, e - t.keepFree) <= t.fuel).map((t) => {
		let r = Q(e.s), i = r.people[r.players[0]], a = [...e.actions], o = n.slice(0, t).map((e) => e.uid);
		for (let t of i.hand) if (i.kept.includes(t.uid) !== o.includes(t.uid)) {
			let n = {
				type: "keep",
				n: t.uid
			};
			H(r, n), r.turn === e.rootTurn && a.push(n);
		}
		let s = { type: "upkeep" };
		if (!H(r, s)) throw Error("MODEL_KEEP");
		return r.turn === e.rootTurn && a.push(s), yn(r), {
			...e,
			s: r,
			actions: a
		};
	});
}
function xn(e, t, n) {
	let r = e, i = [], a = t.discount ** n, o = (e, n) => e.prior + dn(e.s, t, n) * a;
	for (let n = 0; n < t.steps && r.length; n++) {
		let n = /* @__PURE__ */ new Map();
		for (let t of r) {
			if (t.s.phase === "keep") {
				for (let e of bn(t)) e.value = o(e, !1), i.push(e);
				continue;
			}
			if (t.s.phase === "done" || t.s.turn !== e[0].s.turn) {
				t.value = o(t, !1), i.push(t);
				continue;
			}
			for (let e of rn(t.s)) {
				let r = e.s;
				yn(r);
				let i = {
					...t,
					s: r,
					actions: r.turn === t.rootTurn || t.s.turn === t.rootTurn ? [...t.actions, ...e.actions] : t.actions,
					first: t.first || pn(e.actions[0]),
					value: 0
				};
				i.value = o(i, !0);
				let a = i.first + _n(r), s = n.get(a);
				(!s || i.value > s.value) && n.set(a, i);
			}
		}
		let a = [...n.values()].sort((e, t) => t.value - e.value);
		if (t.diversity) {
			let e = /* @__PURE__ */ new Map();
			r = a.filter((n) => {
				let r = n.first, i = e.get(r) ?? 0;
				return e.set(r, i + 1), i < t.diversity;
			}).slice(0, t.beam);
		} else r = a.slice(0, t.beam);
		i.length > t.endings * 10 && (i = vn(i, t.endings * 3));
	}
	return vn(i, t.endings);
}
function Sn(e, t) {
	let n = [{
		s: e,
		actions: [],
		first: "",
		value: 0,
		prior: 0,
		rootTurn: e.turn
	}];
	for (let e = 0; e < t.turns; e++) {
		let r = xn(n, t, e);
		if (!r.length || (n = r, n.every((e) => e.s.phase === "done"))) break;
		e + 1 < t.turns && (n = n.map((n) => ({
			...n,
			prior: n.prior + dn(n.s, t) * t.discount ** e * (1 - t.discount)
		})));
	}
	return n.sort((e, t) => t.value - e.value);
}
function Cn(e, t = {}) {
	let n = {
		...ln,
		...t
	};
	return (t, r) => {
		if (!t.public.corporation || !t.private?.legal.length) return e(t, r);
		let i = r.memory, a = Yt(t, i?.knowledge), o = (e, n = []) => ({
			action: e,
			memory: {
				knowledge: Xt(a, e, t),
				queue: n,
				steps: i?.knowledge.turn === t.public.turn ? (i.steps ?? 0) + 1 : 0
			}
		});
		if (i?.queue?.[0]?.key === hn(t)) return o(i.queue[0].action, i.queue.slice(1));
		let s = r.difficulty === "weak" ? {
			...n,
			beam: 6,
			turns: 1,
			samples: 1
		} : n, c = [];
		for (let e = 0; e < s.samples; e++) {
			let n = Sn(Zt(t, a, e + 1), s), r = /* @__PURE__ */ new Set();
			for (let e of n) e.actions.length && !r.has(pn(e.actions[0])) && (c.push(e), r.add(pn(e.actions[0])));
		}
		let l = /* @__PURE__ */ new Map();
		for (let e of c) {
			let t = pn(e.actions[0]), n = l.get(t);
			n ? (n.sum += e.value, n.count++) : l.set(t, {
				sum: e.value,
				count: 1,
				plan: e
			});
		}
		let u = [...l.values()].filter((e) => e.count === s.samples).sort((e, t) => t.sum / t.count - e.sum / e.count)[0]?.plan, d = u?.actions[0];
		if (d && t.private.legal.some((e) => pn(e) === pn(d))) {
			let e = [], n = Zt(t, a, 1);
			for (let r of u.actions) {
				if (n.turn !== t.public.turn || (e.push({
					key: gn(n),
					action: r
				}), !H(n, r))) break;
				yn(n);
			}
			return o(d, e.slice(1));
		}
		let f = e(t, {
			...r,
			memory: void 0
		});
		return f && !("then" in f) ? o(f.action) : f;
	};
}
var wn = {
	...ln,
	samples: 2,
	beam: 48,
	endings: 24,
	turns: 2,
	steps: 32,
	diversity: 0,
	position: 0,
	ownership: 0,
	engine: 1,
	power: 1,
	discount: 1
}, Tn = {
	samples: 2,
	remaining: 2
}, En = () => ({
	calls: 0,
	considered: 0,
	worlds: 0,
	edits: 0,
	stale: 0,
	maxMs: 0,
	gains: []
}), Dn = (e) => JSON.stringify([
	e.type,
	e.id,
	e.n,
	e.mode,
	e.target
]), On = (e) => [
	e.floor,
	e.fuel,
	e.fuelCap,
	e.storageCap,
	e.credits,
	e.move,
	e.drill,
	e.drones,
	e.storage,
	e.market,
	e.overflow,
	e.tiles,
	e.permanent,
	e.main,
	e.refreshAvailable,
	e.discard,
	e.play
], kn = (e) => JSON.stringify([
	e.public.turn,
	e.public.phase,
	On(e.public.players[0]),
	e.private?.hand,
	e.private?.top,
	e.private?.kept,
	e.public.pending,
	e.public.floors,
	e.public.shops
]), An = (e) => {
	let t = e.public.corporation, n = e.public.players[0];
	return JSON.stringify([
		e.public.endTriggeredBy,
		e.public.milestones,
		e.public.damageRemaining,
		n.deckCount,
		n.handCount,
		t && [
			t.floor,
			t.minerals,
			t.overflow,
			t.tiles,
			t.remaining,
			t.revealed,
			t.step
		]
	]);
};
function jn(e) {
	let t = e.people[e.players[0]], n = e.corporation;
	return {
		key: JSON.stringify([
			e.turn,
			e.phase,
			On({
				...t,
				handCount: t.hand.length,
				deckCount: t.deck.length,
				score: W(e, t.rid)
			}),
			t.hand,
			t.deck[0] ?? null,
			t.kept,
			e.pending,
			e.floors.map((e) => ({
				...e,
				minerals: e.open ? e.minerals : [],
				corridors: e.corridors.slice(0, 1),
				remaining: e.corridors.length,
				card: e.open ? e.card : null
			})),
			A.map((t) => ({
				id: t,
				cards: e.shopCards[t],
				remaining: e.shopDecks[t].length
			}))
		]),
		context: JSON.stringify([
			e.endTriggeredBy,
			e.milestones,
			e.damageRemaining,
			t.deck.length,
			t.hand.length,
			[
				n.floor,
				n.minerals,
				n.overflow,
				n.tiles,
				n.deck.length,
				n.revealed,
				n.step
			]
		])
	};
}
function Mn(e) {
	let t = 0;
	for (; e.phase === "upkeep" || e.phase === "corporate";) if (et(e), ++t > 120) throw Error("ENDGAME_TICK_LOOP");
}
function Nn(e, t) {
	let n = Q(e), r = [], i = n.turn;
	for (let e of t) {
		if (n.phase === "done") break;
		if (n.turn !== i) return;
		let t = jn(n);
		if (!H(n, e)) return;
		r.push({
			...t,
			action: e
		}), Mn(n);
	}
	if (n.phase === "done") return {
		margin: W(n, n.players[0]).total - tt(n),
		queue: r
	};
}
function Pn(e, t, n, r = Tn, i = En()) {
	let a = e.public.players[0], o = e.public.corporation;
	if (!o || o.remaining > r.remaining || e.public.phase !== "operations" || e.public.pending.length || a.drill < 2 || !n.length || n.some((e) => e.type === "dig")) return;
	let s = performance.now();
	i.considered++;
	try {
		let a = [];
		for (let i = 1; i <= r.samples; i++) {
			let r = Zt(e, t, i), o = r.corporation.deck, s = o.length ? o.map((e, t) => [e, ...o.filter((e, n) => n !== t)]) : [[]];
			for (let e of s) {
				let t = Q(r);
				t.corporation.deck = e;
				let i = Nn(t, n);
				if (!i) return;
				a.push({
					root: t,
					incumbent: i
				});
			}
		}
		if (i.worlds += a.length, !a.length) return;
		let o = Q(a[0].root), s = {
			type: "dig",
			mode: "corridor"
		}, c;
		for (let t = 0; t < n.length; t++) {
			let r = Q(o);
			if (H(r, s) && !r.pending.length) {
				let e = [
					...n.slice(0, t),
					s,
					...n.slice(t)
				], r, i = Infinity, o = 0, l = !0;
				for (let { root: t, incumbent: n } of a) {
					let a = Nn(t, e);
					if (!a || a.margin < n.margin) {
						l = !1;
						break;
					}
					let s = a.margin - n.margin;
					i = Math.min(i, s), o += s, r ??= a.queue;
				}
				let u = o / a.length;
				l && r && i > 0 && (!c || i > c.worst || i === c.worst && u > c.mean) && (c = {
					queue: r,
					worst: i,
					mean: u,
					at: t
				});
			}
			if (o.phase === "done" || !H(o, n[t]) || (Mn(o), o.turn !== e.public.turn)) break;
		}
		return c && (i.edits++, i.gains.push({
			turn: e.public.turn,
			at: c.at,
			worst: c.worst,
			mean: c.mean
		})), c;
	} finally {
		i.maxMs = Math.max(i.maxMs, performance.now() - s);
	}
}
function Fn(e, t = {}, n = En()) {
	let r = {
		...Tn,
		...t
	};
	return async (t, i) => {
		if (!t.public.corporation || !t.private?.legal.length) return e(t, i);
		n.calls++;
		let a = i.memory, o = a?.queue?.[0], s = !o || o.key === kn(t) && (!o.context || o.context === An(t)) && t.private.legal.some((e) => Dn(e) === Dn(o.action)), c = Yt(t, a?.knowledge);
		s || n.stale++;
		let l = s ? a : {
			...a,
			knowledge: c,
			queue: []
		}, u = await e(t, {
			...i,
			memory: l
		});
		if (!u) return u;
		if (!t.private.legal.some((e) => Dn(e) === Dn(u.action))) throw Error(`ENDGAME_ILLEGAL_BASE ${JSON.stringify(u.action)}`);
		let d = u.memory, f = Pn(t, c, [u.action, ...(d?.queue ?? []).map((e) => e.action)], r, n);
		if (!f) return u;
		let [p, ...m] = f.queue;
		if (!p || !t.private.legal.some((e) => Dn(e) === Dn(p.action))) throw Error("ENDGAME_ILLEGAL_EDIT");
		return {
			action: p.action,
			memory: {
				...d,
				knowledge: Xt(c, p.action, t),
				queue: m
			}
		};
	};
}
//#endregion
//#region src/games/drillers/bot.ts
var In = {
	fuelValue: .3,
	effort: .14,
	future: 1,
	mineralValue: 1,
	milestoneValue: 1,
	returnValue: .6,
	buildValue: 1,
	beam: 32,
	depth: 2
}, Ln = (e) => k.indexOf(e), Rn = (e, t) => e.type === t.type && e.id === t.id && e.n === t.n && e.mode === t.mode && e.target === t.target;
function zn(e = {}) {
	let t = {
		...In,
		...e
	};
	return (e, n) => {
		let r = e.public, i = e.private, a = r.players.find((e) => e.rid === n.rid);
		if (!a || !i?.legal.length || r.active !== n.rid) return null;
		let o = n.memory, s = o?.turn === r.turn ? {
			turn: r.turn,
			steps: (o.steps ?? 0) + 1,
			returning: o.returning ?? !1,
			floor: o.floor ?? a.floor,
			drills: o.drills ?? 0
		} : {
			turn: r.turn,
			steps: 0,
			returning: !!o?.returning && a.floor > 0,
			floor: o?.returning && a.floor > 0 ? 0 : a.floor,
			drills: 0
		}, c = (e) => ({
			action: e,
			memory: s
		}), l = (e) => i.legal.find((t) => Rn(t, e)), u = [
			...i.hand,
			...a.play,
			...a.discard,
			...i.top ? [i.top] : []
		], d = !!r.endTriggeredBy, f = d ? 0 : t.future, p = r.damageRemaining > 0 ? 3 + f : Math.max(0, ...a.market.map((e, t) => e ? t + 2 : 0)), m = (e) => a.market[Ln(e)] < 3 ? ie[e][2 - a.market[Ln(e)]] : ae[e], h = a.handCount + a.deckCount + a.play.length + a.discard.length, g = (e) => {
			let t = j[e], n = t.fuel * .35 - t.cost * .3 + t.vp * .15;
			for (let t of L[e] ?? me[e] ?? []) t.kind === "drill" && (n += t.amount * 1.4), t.kind === "move" && (n += t.amount * .8), t.kind === "draw" && (n += t.amount * 1.8), t.kind === "fuel" && (n += t.amount * .5), t.kind === "repair" && (n += 1.5), t.kind === "choice" && (n += 1.5), t.kind === "teleport" && (n += 4), t.kind === "refresh" && (n += t.amount * .9), t.kind === "credits" && (n += t.amount * .25), (t.kind === "damage" || t.kind === "damageTop" || t.kind === "damageHand") && (n -= 2.5);
			return n;
		}, _ = (e) => {
			let t = Number(e.split(":").at(-1)), n = u.find((e) => e.uid === t);
			return n ? n.id === "damage" ? 3 + 2 * f : -j[n.id].vp + (ue.includes(n.id) && h >= 12 ? 1.8 * f : 0) - Math.max(1, g(n.id) * .5) * f : -10;
		}, ee = (e) => {
			let n = j[e], i = u.filter((e) => e.id !== "damage").reduce((e, t) => e + g(t.id), 0) / Math.max(1, u.filter((e) => e.id !== "damage").length), o = n.battery ? Math.min(...a.tiles.filter((e) => !e.exhausted && M[e.id].exhaust.battery).map((e) => M[e.id].vp - M[e.id].back)) : 0, s = Math.max(0, g(e) - i + 1) * (n.permanent ? 2.5 : Math.max(.5, 3 - h / 9));
			return n.vp - n.price / 5 - o + s * f * t.buildValue - (a.drones === 1 && a.storage.length > 0 && r.phase === "operations" ? 4 : 0);
		};
		if (r.pending.length) {
			let e = (e) => {
				let n = r.pending[e.n], i = e.target;
				if (i === "skip") return 0;
				if (n.kind === "repair") return _(i) > 0 ? 100 + _(i) : -10;
				if (n.kind === "floorRust") {
					let [e, n] = i.split("|");
					return _(n) - t.fuelValue - m(e) / 5;
				}
				return n.kind === "teleport" ? Number(i) === s.floor ? 100 : -Math.abs(Number(i) - s.floor) : n.kind === "choice" ? i.startsWith("repair:") ? _(i.slice(7)) : i === "move" ? Math.abs(s.floor - a.floor) > a.move ? 25 : .1 : i === "drill" ? a.drill < s.drills ? 30 : .2 : i === "refresh" ? (3 - a.drones) * 2 : Math.min(n.amount, a.fuelCap - a.fuel) * 2 : n.kind === "floorDispatch" ? i === "credits" ? a.drones * .5 : f * (a.drones === 0 ? 1.5 : .3) - t.fuelValue : n.kind === "fuelTrade" ? a.fuel < a.fuelCap ? t.fuelValue - .2 : -1 : n.kind === "payFuelOrDamage" ? i === "pay" ? 10 : -10 : n.kind === "floorCave" ? Number(i) + 2 : n.kind === "marketMineral" ? 10 - Ln(i) : n.kind === "upgradeMineral" ? 10 + +(a.storage[Number(i)] === "gold") : n.kind === "damage" || n.kind === "damageTop" || n.kind === "damageHand" ? 150 : n.kind === "draw" ? 80 : 50;
			};
			return c([...i.legal].sort((t, n) => e(n) - e(t))[0]);
		}
		if (r.phase === "keep") {
			let e = (e) => g(e) + (s.returning ? (L[e] ?? []).reduce((e, t) => e + (t.kind === "move" ? t.amount * 1.5 : t.kind === "teleport" ? 10 : 0), 0) : 0), t = [...i.hand].sort((t, n) => e(n.id) - e(t.id)).filter((e, t) => t < i.keepFree || !d && t < i.keepFree + Math.max(0, a.fuel - 3) && g(e.id) >= 4).map((e) => e.uid);
			return c(i.legal.find((e) => e.type === "keep" && i.kept.includes(e.n) !== t.includes(e.n)) ?? i.legal.find((e) => e.type === "upkeep"));
		}
		if (r.phase === "surfacing") {
			let e = (e) => {
				if (e.type === "sell") return 100 + m(e.id);
				if (e.type === "refuel") return 90;
				if (e.type === "repair") return _(e.target) - 1 > 0 ? 50 + _(e.target) : -10;
				if (e.type === "discard") {
					let t = i.hand.find((t) => t.uid === e.n);
					return t.id === "damage" || d || g(t.id) < 2 ? 20 : -1;
				}
				return e.type === "buy" ? ee(e.id) : e.type === "upgrade" ? f && (e.id === "storage" ? a.storageCap < 4 : a.fuelCap < 13) && a.credits >= 5 ? 2 : -1 : e.type === "upkeep" ? 0 : -10;
			};
			return c([...i.legal].sort((t, n) => e(n) - e(t))[0]);
		}
		let v = i.legal.find((e) => e.type === "surface");
		if (s.steps > 120 || s.returning && a.floor === 0) return c(v);
		let y = a.tiles.reduce((e, t) => e + M[t.id].units, 0), te = (e = 0, t = a.overflow.length) => !r.endTriggeredBy && y + e + Math.min(10, t) >= 26 ? ce[3] : 0, b = (e) => (se.reduce((t, n, i) => t + (r.milestones[i] === null && y < n && y + e >= n ? ce[i] : 0), 0) + te(e)) * t.milestoneValue, x = [];
		if (!s.returning) {
			let e = r.floors.find((e) => e.floor >= 3 && !e.open);
			if (e) {
				let t = M[`B${e.floor}`];
				x.push({
					kind: "barrier",
					floor: e.floor - 1,
					drills: e.floor,
					reward: t.vp + b(t.units) + 2 * f - (d ? F[e.floor] - F[a.floor] : 0)
				});
			}
			for (let e of r.floors) if (e.open && e.floor >= 1) {
				if (e.remaining && e.corridors[0]) {
					let t = M[e.corridors[0]], n = P[e.floor] - +(e.card === "hot_tub" && !i.firstCorridor.includes(e.floor));
					x.push({
						kind: "corridor",
						floor: e.floor,
						drills: n,
						reward: t.vp + b(t.units) + f - (d ? F[e.floor] - F[a.floor] : 0)
					});
				}
				for (let n of new Set(e.minerals)) x.push({
					kind: "collect",
					floor: e.floor,
					drills: n === "silver" && a.main.includes("suction_engine") ? 0 : 1,
					mineral: n,
					reward: (Ln(n) + 2) * t.mineralValue + m(n) * .25 * f - (d ? F[e.floor] - F[a.floor] : 0)
				});
				e.jackpot.includes(n.rid) && x.push({
					kind: "collect",
					floor: e.floor,
					drills: 1,
					mineral: "emerald",
					mode: "jackpot",
					reward: 5 * t.mineralValue + m("emerald") * .25 * f
				});
			}
		}
		if (a.floor > 0) {
			let e = f * ((a.fuelCap - a.fuel) * .45 + a.storage.reduce((e, t) => e + m(t) * .4, 0) + 2 + a.floor * .6);
			for (let n = 0; n < a.floor; n++) x.push({
				kind: "home",
				floor: n,
				drills: 0,
				reward: t.returnValue * (e * (a.floor - n) / a.floor + (d ? F[a.floor] - F[n] : 0))
			});
		}
		let S = [], C = 0, w = (e, t, n, r, i) => {
			let o = [{
				fuel: 0,
				move: 0,
				drill: 0,
				cap: 0,
				teleport: !1,
				bonus: 0
			}];
			for (let e of t) {
				if (e.kind === "choice") {
					o = o.flatMap((t) => [{
						...t,
						move: t.move + 1
					}, ...e.amount === 3 ? [{
						...t,
						drill: t.drill + 1
					}] : [{
						...t,
						fuel: t.fuel + 1
					}]]);
					continue;
				}
				for (let t of o) (e.kind === "fuel" || e.kind === "move" || e.kind === "drill") && (t[e.kind] += e.amount), e.kind === "storage" && (t.cap += e.amount), e.kind === "teleport" && (t.teleport = !0), e.kind === "draw" && (t.bonus += e.amount * 1.6), e.kind === "credits" && (t.bonus += e.amount / 5), e.kind === "refresh" && (t.bonus += Math.min(e.amount, 3 - a.drones) * f * (a.storage.length ? 1.5 : .5)), e.kind === "tank" && (t.bonus += a.fuelCap < 18 ? f * .6 : 0), e.kind === "repair" && (t.bonus += Math.max(0, ...u.map((e) => _(`hand:${e.uid}`)))), (e.kind === "damage" || e.kind === "damageTop" || e.kind === "damageHand") && (t.bonus -= p), e.kind === "scrapSelf" && (t.bonus += 1 + f), e.kind === "upgradeMineral" && (t.bonus += +!!a.storage.some((e) => e !== "ruby")), e.kind === "marketMineral" && (t.bonus += y + Math.min(10, a.overflow.length) >= 22 ? 2 : .2);
			}
			for (let t of o) S.push({
				action: e,
				bit: i,
				cost: n,
				...t,
				loss: r
			});
		};
		for (let e of i.hand) {
			let t = j[e.id], n = 1n << BigInt(C++);
			S.push({
				action: {
					type: "play",
					n: e.uid,
					mode: "fuel"
				},
				bit: n,
				cost: 0,
				fuel: t.fuel + Number(a.main.includes("flywheel")),
				move: 0,
				drill: 0,
				cap: 0,
				teleport: !1,
				loss: .25,
				bonus: 0
			}), (!t.solid || a.storage.length) && w({
				type: "play",
				n: e.uid,
				mode: "main",
				...t.solid ? { target: [...a.storage].sort((e, t) => m(e) - m(t))[0] } : {}
			}, L[e.id] ?? [], t.cost, .25 + (t.solid ? Math.min(...a.storage.map(m)) / 5 : 0), n);
		}
		for (let e of i.legal) {
			let t = 1n << BigInt(C++);
			if (e.type === "ability" && w(e, me[e.id] ?? (e.id === "adaptive_engine" ? [{
				kind: "move",
				amount: 1
			}] : e.id === "repair_drone" ? [{
				kind: "fuel",
				amount: 2
			}] : [{
				kind: e.id === "superior_soaker" ? "upgradeMineral" : "fuel",
				amount: e.id === "burner_drill" ? 2 : 1
			}]), e.id === "surgeon" ? 1 : e.id === "adaptive_engine" || e.id === "deep_neural_network" ? 2 : 0, e.id === "repair_drone" ? .8 : 0, t), e.type === "function" && e.id === "damage" && w(e, [{
				kind: "fuel",
				amount: 3
			}], 0, p, t), e.type === "exhaust") {
				let n = M[a.tiles[e.n].id], r = n.exhaust;
				w(e, [
					...r.fuel ? [{
						kind: "fuel",
						amount: r.fuel
					}] : [],
					...r.draw ? [{
						kind: "draw",
						amount: r.draw
					}] : [],
					...r.move ? [{
						kind: "move",
						amount: r.move
					}] : [],
					...r.credits ? [{
						kind: "credits",
						amount: r.credits
					}] : [],
					...r.droneRefresh ? [{
						kind: "refresh",
						amount: r.droneRefresh
					}] : []
				], 0, n.vp - n.back, t);
			}
		}
		let T = {
			mask: 0n,
			fuel: a.fuel,
			move: a.move,
			drill: a.drill,
			cap: a.storageCap,
			teleport: !1,
			cost: 0,
			bonus: 0,
			steps: 0
		}, E = [T], D = [T], ne = n.difficulty === "weak" ? s.returning ? 8 : 2 : t.beam, re = n.difficulty === "weak" ? 1 : t.depth, O = (e) => Math.min(8, e.drill) * (s.returning ? 0 : 1.5) + Math.min(6, e.move) * (s.returning ? 2 : 1) + e.fuel * .3 + e.bonus - e.cost;
		for (let e = 0; e < re; e++) {
			let e = /* @__PURE__ */ new Map();
			for (let n of D) for (let r of S) {
				if (n.mask & r.bit || n.fuel < r.cost || !n.first && !l(r.action)) continue;
				let i = Math.min(a.fuelCap, n.fuel - r.cost + r.fuel), o = {
					mask: n.mask | r.bit,
					fuel: i,
					move: n.move + r.move,
					drill: n.drill + r.drill,
					cap: Math.min(7, n.cap + r.cap),
					teleport: n.teleport || r.teleport,
					cost: n.cost + r.loss + r.cost * t.fuelValue,
					bonus: n.bonus + r.bonus,
					steps: n.steps + 1,
					first: n.first ?? r.action
				};
				if (i === n.fuel && o.move === n.move && o.drill === n.drill && o.cap === n.cap && o.teleport === n.teleport && o.bonus <= n.bonus) continue;
				let s = `${o.mask}/${i}/${o.move}/${o.drill}/${o.cap}/${Number(o.teleport)}`;
				(!e.has(s) || e.get(s).cost - e.get(s).bonus > o.cost - o.bonus) && e.set(s, o);
			}
			if (D = [...e.values()].sort((e, t) => O(t) - O(e)).slice(0, ne), E.push(...D), !D.length) break;
		}
		let k = 0, A = v, N;
		for (let e of x) for (let n of E) {
			if (e.kind === "collect" && a.storage.length >= n.cap) continue;
			let r = n.teleport ? 0 : Math.abs(e.floor - a.floor), i = Math.max(0, r - n.move), o = Math.max(0, e.drills - n.drill), s = i * (a.main.includes("adaptive_engine") ? 2 : 3) + o * 4;
			if (n.fuel < s) continue;
			let c = (e.reward + n.bonus - n.cost - s * t.fuelValue) / (1 + t.effort * (n.steps + r + i + o));
			if (c <= k) continue;
			let u = n.first;
			u ||= e.floor === a.floor ? e.kind === "home" ? v : a.drill < e.drills ? l({
				type: "function",
				id: "drill"
			}) : l(e.kind === "collect" ? {
				type: "collect",
				id: e.mineral,
				n: e.floor,
				...e.mode ? { mode: e.mode } : {}
			} : {
				type: "dig",
				mode: e.kind
			}) : l({
				type: "move",
				n: a.floor + Math.sign(e.floor - a.floor)
			}) ?? l({
				type: a.main.includes("adaptive_engine") ? "ability" : "function",
				id: a.main.includes("adaptive_engine") ? "adaptive_engine" : "move"
			}), u && (k = c, A = u, N = e);
		}
		for (let e of i.legal) {
			let t = -1;
			e.type === "sell" && (t = 3 + m(e.id) / 5 + (a.storage.length >= a.storageCap ? 3 : 0) + (a.market[Ln(e.id)] === 3 ? te(0, a.overflow.length + 1) : 0)), e.type === "buy" && (t = ee(e.id)), t > k && (k = t, A = e, N = void 0);
		}
		return N ? (s.floor = N.floor, s.drills = N.drills, N.kind === "home" && (s.returning = !0)) : A === v && a.floor > 0 && (s.returning = !0), c(A);
	};
}
function Bn(e = {}) {
	let t = zn(e), n = Fn(Cn(t, wn));
	return (e, r) => {
		if (!e.public.corporation || r.difficulty === "weak" || e.public.active !== r.rid || !e.private?.legal.length) return t(e, r);
		let i = r.memory;
		return n(e, i?.knowledge ? r : {
			...r,
			memory: void 0
		});
	};
}
var Vn = Bn(), Hn = (e, t, n) => It(e, t.public, t.private, t.public.active, n), Un = 1e3, Wn = 1200;
function Gn({ children: e, x: t, y: n, ms: r, card: i = !1, from: o }) {
	let c = s(null);
	return a(() => {
		let e = c.current?.animate(i ? [
			{
				opacity: 0,
				transform: `translate(calc(-50% + ${(o?.x ?? t) - t}px), ${(o?.y ?? n + 16) - n}px) rotate(-5deg) scale(.88)`
			},
			{
				opacity: 1,
				transform: "translate(-50%, 0) rotate(-1deg) scale(1)",
				offset: .18
			},
			{
				opacity: 1,
				transform: "translate(-50%, 0) rotate(-1deg) scale(1)",
				offset: .84
			},
			{
				opacity: 0,
				transform: "translate(-50%, -12px) rotate(1deg) scale(.97)"
			}
		] : [
			{
				opacity: 0,
				transform: "translate(-50%, 8px) scale(.9)"
			},
			{
				opacity: 1,
				transform: "translate(-50%, -2px) scale(1.03)",
				offset: .12
			},
			{
				opacity: 1,
				transform: "translate(-50%, -7px) scale(1)",
				offset: .75
			},
			{
				opacity: 0,
				transform: "translate(-50%, -25px) scale(1)"
			}
		], {
			duration: r,
			easing: "linear",
			fill: "both"
		});
		return () => e?.cancel();
	}, [
		r,
		i,
		t,
		n,
		o?.x,
		o?.y
	]), /* @__PURE__ */ w("div", {
		ref: c,
		className: i ? "drillers-fx-card" : "drillers-fx-floater",
		style: {
			left: t,
			top: n
		},
		children: e
	});
}
function Kn({ card: e, owner: t }) {
	let n = u();
	return /* @__PURE__ */ T(C, { children: [
		t && /* @__PURE__ */ w("small", {
			className: "drillers-fx-owner",
			children: t === "$corporation" ? n("games.drillers.corp") : t
		}),
		/* @__PURE__ */ w("strong", { children: n(G[e.id]) }),
		/* @__PURE__ */ w(vt, { id: e.id }),
		/* @__PURE__ */ T("span", { children: [n(e.rid === "$corporation" ? "games.drillers.actions.play" : e.mode === "fuel" ? "games.drillers.fuelModeLabel" : "games.drillers.useMain"), /* @__PURE__ */ w(Y, {
			kind: e.mode === "fuel" ? "fuel" : "fuel-pay",
			value: e.mode === "fuel" ? j[e.id].fuel : j[e.id].cost
		})] })
	] });
}
function qn({ changes: e, name: t }) {
	let n = u();
	return /* @__PURE__ */ T(C, { children: [t && /* @__PURE__ */ w("small", {
		className: "drillers-fx-owner",
		children: t === "$corporation" ? n("games.drillers.corp") : t
	}), /* @__PURE__ */ w("span", {
		className: "drillers-fx-values",
		children: e.map((e, t) => /* @__PURE__ */ T("span", {
			"data-loss": e.n < 0,
			children: [/* @__PURE__ */ w(Y, {
				kind: e.kind === "fuel" && e.n < 0 && !e.capacity ? "fuel-pay" : e.kind,
				value: e.n,
				signed: !0,
				capacity: e.capacity
			}), e.zone && /* @__PURE__ */ w("small", { children: n(e.zone === "market" ? "games.drillers.market" : "games.drillers.overflow") })]
		}, t))
	})] });
}
function Jn({ to: e }) {
	let t = u();
	return /* @__PURE__ */ T("span", {
		className: "drillers-fx-values",
		children: [/* @__PURE__ */ w(Y, { kind: "move" }), X(e, t)]
	});
}
var Yn = (e, t, n) => Math.max(t, Math.min(e, n)), $ = (e, t) => !!e && e.w > 0 && e.h > 0 && e.x + e.w > t.x && e.x < t.x + t.w && e.y + e.h > t.y && e.y < t.y + t.h, Xn = { "drillers-feedback": (e, t) => {
	let n = e.data, r = t.anchor("drillers-board");
	if (!n || !r || t.queued > 1) return null;
	let i = Yn(Math.min(r.w, r.h) / 700, 1, 1.6), a = n.automatic ? 420 : t.queued ? 360 : Wn, o = Math.min(Un, a), s = /* @__PURE__ */ new Map();
	for (let e of n.changes) {
		let n = e.rid === t.myRid, i = [
			"silver",
			"gold",
			"sapphire",
			"emerald",
			"ruby"
		].includes(e.kind) ? "cargo" : e.kind, a = e.floor !== void 0 && e.floor >= 0 ? `floor:${e.floor}` : n ? `resource:${e.rid}:${i}` : `seat:${e.rid}`, o = t.anchor(a), c = t.anchor(`seat:${e.rid}`), l = e.floor === void 0 || $(o, t.anchor("drillers-mine") ?? r), u = $(o, r) && l ? o : $(c, r) ? c : {
			x: r.x + r.w / 2 - 30,
			y: r.y + 35,
			w: 60,
			h: 30
		}, d = `${u.x}:${u.y}:${e.rid}`, f = s.get(d) ?? {
			anchor: u,
			changes: [],
			name: !n && e.floor === void 0 ? t.member(e.rid)?.name ?? e.rid : void 0
		};
		f.changes.push(e), s.set(d, f);
	}
	let c = [];
	for (let e of n.moves) {
		let n = t.anchor(`floor:${e.to}`);
		$(n, r) && $(n, t.anchor("drillers-mine") ?? r) && c.push(/* @__PURE__ */ w(Gn, {
			x: Yn(n.x + 70, r.x + 65, r.x + r.w - 65),
			y: Yn(n.y + 8, r.y + 28, r.y + r.h - 70),
			ms: a,
			children: /* @__PURE__ */ w(Jn, { to: e.to })
		}, `move:${e.rid}`));
	}
	for (let [e, o] of s) {
		let s = Math.min(r.w - 16, Math.max(76, o.changes.length * 55) * i), l = Yn(o.anchor.x + o.anchor.w / 2, r.x + s / 2 + 8, r.x + r.w - s / 2 - 8), u = n.card?.rid !== t.myRid && n.card?.rid === o.changes[0]?.rid && o.changes.every((e) => e.floor === void 0), d = Yn(u ? o.anchor.y - 8 : o.anchor.y + o.anchor.h / 2, r.y + (u ? 14 : 28), r.y + r.h - 70 * i);
		c.push(/* @__PURE__ */ w(Gn, {
			x: l,
			y: d,
			ms: a,
			children: /* @__PURE__ */ w(qn, {
				changes: o.changes,
				name: o.name
			})
		}, e));
	}
	if (n.card && !t.queued) {
		let e = t.anchor("drillers-mine") ?? r, a = n.card.rid === t.myRid, s = t.anchor(a ? "drillers-hand" : `seat:${n.card.rid}`), l = Yn(!a && $(s, r) ? s.x + s.w / 2 : e.x + e.w * .65, r.x + 100 * i, r.x + r.w - 100 * i), u = Yn(!a && $(s, r) ? s.y + s.h + 8 : e.y + e.h * .35, r.y + 28, r.y + r.h - 145 * i), d = $(s, r) ? {
			x: s.x + s.w / 2,
			y: s.y + s.h / 2
		} : void 0;
		c.push(/* @__PURE__ */ w(Gn, {
			x: l,
			y: u,
			from: d,
			ms: o,
			card: !0,
			children: /* @__PURE__ */ w(Kn, {
				card: n.card,
				owner: a ? void 0 : t.member(n.card.rid)?.name ?? n.card.rid
			})
		}, "card"));
	}
	return {
		ms: a,
		node: /* @__PURE__ */ w("div", {
			className: "drillers-fx-layer",
			style: { "--drillers-fx-scale": i },
			children: c
		})
	};
} };
//#endregion
//#region src/games/drillers/endgame-review.tsx
function Zn({ board: e, renderResult: t, ...n }) {
	let i = u(), [a, l] = c(!0), [d, f] = c(null), m = s(null), h = s(null), g = s(null);
	r(() => {
		m.current?.focus({ preventScroll: !0 });
	}, []), r(() => {
		if (!d) return;
		g.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let v = (e) => {
		f(null), l(e), requestAnimationFrame(() => (e ? m : h).current?.focus({ preventScroll: !0 }));
	}, y = o(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), te = {
		...n,
		...y
	};
	return /* @__PURE__ */ T("div", {
		className: "drillers-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ w("div", {
				className: "drillers-endgame-board",
				inert: a,
				children: e
			}),
			/* @__PURE__ */ w("div", {
				className: "drillers-endgame-overlay",
				hidden: !a,
				children: /* @__PURE__ */ T("section", {
					role: "dialog",
					"aria-modal": "true",
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), v(!1)), e.key !== "Tab") return;
						let t = [...e.currentTarget.querySelectorAll("button:not(:disabled)")].filter((e) => !e.closest("[inert]")), n = t[0], r = t.at(-1);
						e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
					},
					className: "drillers-endgame-panel",
					"aria-label": i("session.result.title"),
					children: [
						/* @__PURE__ */ T("header", {
							className: "drillers-endgame-heading",
							children: [/* @__PURE__ */ T("div", {
								className: "drillers-endgame-brand",
								children: [/* @__PURE__ */ w("span", {
									"aria-hidden": "true",
									children: he.icon
								}), i(he.nameKey)]
							}), /* @__PURE__ */ w("button", {
								type: "button",
								ref: m,
								className: "btn-quiet",
								"aria-label": i("games.drillers.reviewHide"),
								title: i("games.drillers.reviewHide"),
								onClick: () => v(!1),
								children: /* @__PURE__ */ w(_, { size: 19 })
							})]
						}),
						/* @__PURE__ */ w("div", {
							className: "drillers-endgame-result",
							inert: d !== null,
							children: t(te)
						}),
						d && /* @__PURE__ */ T("div", {
							className: "drillers-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ w("button", {
								type: "button",
								ref: g,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: i(d.label === "again" ? "games.drillers.reviewConfirmAgain" : "games.drillers.reviewConfirmLobby")
							}), /* @__PURE__ */ w("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), m.current?.focus({ preventScroll: !0 });
								},
								children: i("games.drillers.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ w("div", {
				className: "drillers-endgame-toolbar",
				hidden: a,
				children: /* @__PURE__ */ T("button", {
					type: "button",
					className: "btn-base",
					ref: h,
					onClick: () => v(!0),
					children: [
						/* @__PURE__ */ w(ee, { size: 18 }),
						i("games.drillers.reviewShow"),
						/* @__PURE__ */ w(p, { size: 18 })
					]
				})
			})
		]
	});
}
function Qn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: s, renderRowExtra: d, summary: f, navigation: p, content: h, afterRanking: g, scoreUnit: ee, rankOf: v }) {
	let y = u(), te = l((e) => e.locale), [b, x] = c({}), S = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? D(n, te) : e;
	}, E = (t, n) => v?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), re = e.ranking.some((t) => e.scores?.[t] !== void 0), O = (t, n) => /* @__PURE__ */ T("div", {
		className: "drillers-score-identity",
		children: [
			/* @__PURE__ */ T("span", {
				className: "drillers-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ w("span", {
					"aria-label": y("games.drillers.reviewWinner"),
					children: "♛ "
				}), re && E(t, n)]
			}),
			/* @__PURE__ */ T("span", {
				className: "drillers-score-name",
				children: [S(t), t === r && /* @__PURE__ */ w("small", { children: y("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ T("small", {
				className: "drillers-score-autopilot",
				children: [
					/* @__PURE__ */ w(m, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), k = (t) => e.ranking.map((n) => /* @__PURE__ */ w("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ T("div", {
		className: "drillers-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ w(ne, {}),
			p,
			/* @__PURE__ */ T("div", {
				className: "drillers-score-body",
				children: [
					/* @__PURE__ */ w("h2", {
						className: "drillers-score-title",
						children: y("games.drillers.panel.finalScore")
					}),
					f && /* @__PURE__ */ w("div", {
						className: "drillers-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ w("p", {
						className: "drillers-score-hints",
						children: y("session.hint.usedCount", { n: i })
					}),
					h ?? (s?.length ? /* @__PURE__ */ w("div", {
						className: "drillers-score-table-scroll",
						children: /* @__PURE__ */ T("table", {
							className: "drillers-score-table",
							"aria-label": y(he.nameKey),
							children: [
								/* @__PURE__ */ w("thead", { children: /* @__PURE__ */ T("tr", { children: [/* @__PURE__ */ w("th", { scope: "col" }), /* @__PURE__ */ w(C, { children: e.ranking.map((t, n) => /* @__PURE__ */ w("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: O(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ w("tbody", { children: s.map((e, t) => /* @__PURE__ */ T(n, { children: [/* @__PURE__ */ T("tr", { children: [/* @__PURE__ */ w("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ T("button", {
										type: "button",
										"aria-expanded": !!b[t],
										onClick: () => x((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ w(_, { size: 15 }), e.label]
									}) : e.label
								}), k(e)] }), b[t] && e.details?.map((e, t) => /* @__PURE__ */ T("tr", {
									className: "drillers-score-sub",
									children: [/* @__PURE__ */ w("th", {
										scope: "row",
										children: e.label
									}), k(e)]
								}, t))] }, t)) }),
								re && /* @__PURE__ */ w("tfoot", { children: /* @__PURE__ */ T("tr", { children: [/* @__PURE__ */ w("th", {
									scope: "row",
									children: y("games.drillers.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ w("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ w("ol", {
						className: "drillers-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ T("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ T("div", {
								className: "drillers-score-rankline",
								children: [O(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ T("strong", {
									className: "drillers-score-points",
									children: [e.scores[t], ee && /* @__PURE__ */ w("small", { children: ee })]
								})]
							}), d?.(t)]
						}, t))
					})),
					g,
					!!s?.length && d && /* @__PURE__ */ w("div", {
						className: "drillers-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ T("details", { children: [/* @__PURE__ */ w("summary", { children: S(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ T("footer", {
				className: "drillers-score-actions",
				children: [
					o && /* @__PURE__ */ w("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: y("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ w("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: y("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ w("p", { children: y("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/drillers/endgame-scores.tsx
function $n(e) {
	let t = u(), n = l((e) => e.locale), r = e.public, i = [
		"tiles",
		"minerals",
		"credits",
		"milestones",
		"refresh",
		"depth",
		"cards"
	].map((e) => ({
		label: t(lt[e]),
		value: (t) => r.players.find((e) => e.rid === t)?.score[e] ?? "—"
	})), a = e.result.winner.map((t) => {
		let r = e.members.find((e) => e.rid === t);
		return r ? D(r, n) : t;
	}).join(" · ");
	return /* @__PURE__ */ w(Qn, {
		...e,
		renderRowExtra: void 0,
		rows: i,
		summary: r.corporation ? /* @__PURE__ */ T("p", { children: [
			t((r.players.find((t) => t.rid === e.myRid)?.score.total ?? 0) > r.corporation.score ? "games.drillers.soloWin" : "games.drillers.soloLoss"),
			" · ",
			t("games.drillers.soloScore", { n: r.corporation.score })
		] }) : a && /* @__PURE__ */ w("p", { children: t("games.drillers.panel.winner", { names: a }) })
	});
}
//#endregion
//#region src/games/drillers/game-over.tsx
function er(e) {
	return /* @__PURE__ */ w($n, { ...e });
}
function tr(e) {
	return /* @__PURE__ */ w(Zn, {
		...e,
		board: /* @__PURE__ */ w(Jt, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ w(er, { ...e })
	});
}
//#endregion
//#region src/games/drillers/game-over-row.tsx
function nr({ public: e, rid: t }) {
	let n = u(), r = e, i = r.players.find((e) => e.rid === t);
	return i ? /* @__PURE__ */ T("div", {
		className: "drillers-result-breakdown mt-2 text-xs",
		children: [r.corporation && /* @__PURE__ */ T("p", {
			className: "mb-2 font-bold",
			children: [
				n(i.score.total > r.corporation.score ? "games.drillers.soloWin" : "games.drillers.soloLoss"),
				" · ",
				n("games.drillers.soloScore", { n: r.corporation.score })
			]
		}), /* @__PURE__ */ w("dl", {
			className: "grid grid-cols-2 gap-x-3 gap-y-1",
			children: Object.entries(i.score).filter(([e]) => e !== "total").map(([e, t]) => /* @__PURE__ */ T("div", {
				className: "flex justify-between gap-2",
				children: [/* @__PURE__ */ w("dt", { children: n(lt[e]) }), /* @__PURE__ */ w("dd", {
					className: "font-mono",
					children: t
				})]
			}, e))
		})]
	}) : null;
}
//#endregion
//#region src/games/drillers/options.tsx
function rr({ value: e, onChange: t }) {
	let n = u(), r = _e.safeParse(e), i = r.success ? r.data : _e.parse(void 0);
	return /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w(O, {
		title: n("games.drillers.soloDifficulty"),
		children: [
			1,
			2,
			3,
			4
		].map((e) => /* @__PURE__ */ w(re, {
			name: "drillers-difficulty",
			value: String(e),
			checked: i.soloDifficulty === e,
			label: "★".repeat(e),
			accent: he.accent,
			onChange: () => t({ soloDifficulty: e })
		}, e))
	}), /* @__PURE__ */ w("p", {
		className: "mt-2 text-xs",
		children: n("games.drillers.soloHint")
	})] });
}
//#endregion
//#region .bgparty/cache/pack-entry/drillers/entry.tsx
var ir = {
	definition: at,
	View: Jt,
	bot: Vn,
	describe: Hn,
	fx: Xn,
	OverView: tr,
	RowView: nr,
	Options: rr,
	locales: {
		zh: {
			panel: {
				finalMilestone: "终局",
				basic: "基础功能",
				currentFloor: "当前楼层",
				discardBuy: "弃牌与购牌",
				upgradeRepair: "升级与维修",
				other: "其他行动",
				visitShop: "前往商店",
				currentScore: "当前计分",
				scoreDetails: "计分详情",
				deck: "牌组",
				floorMinerals: "本层矿物",
				nextCorridor: "下一块通道",
				occupants: "同层机甲",
				currentCard: "当前行动牌",
				cardsRemaining: "剩余 {{n}} 张",
				milestoneAt: "{{n}} 格",
				overflowValue: "溢出 {{n}}",
				flipped: "已翻转",
				gainMove: "获得移动力",
				gainDrill: "获得钻探力",
				takeDamage: "承受伤害",
				fuelUpgrade: "燃料上限 +1",
				storageUpgrade: "储存上限 +1",
				winner: "{{names}}获胜",
				finalScore: "最终计分"
			},
			battery: "电池",
			capacity: "容量",
			fuelModeLabel: "补充燃料",
			tileNumber: "板块 {{n}}",
			pointsLabel: "分数",
			keepAllowance: "免费保留 {{n}} 张，其余每张支付",
			keepSelection: "本次保留 {{n}} 张",
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "钻探者",
			desc: "驾驶采矿机甲深入矿井，改装牌组并争夺地下财富。",
			rules: "目标:\n· 通过矿物、矿井板块和里程碑获得最多分数。\n准备:\n· 每人获得 8 张起始牌及 1 张伤害牌。\n· 燃料上限为 10，储存上限为 2，无人机为 3 架。\n· 开局只有 1 架无人机处于可用状态。\n行动:\n· 每张手牌可以补充燃料，或支付费用使用主效果。\n· 每 1 点移动力可以移动到相邻的已开放楼层。\n· 每 1 点钻探力可以收集本层 1 个矿物。\n· 支付本层费用可以挖掘通道，获得板块并发现矿物。\n· 支付下一层屏障费用可以开放该层，并立即下潜。\n· 用无人机出售 1 个矿物，或购买 1 张牌。\n· 购买的牌放在本人牌库顶，牌库顶始终对本人可见。\n· 每回合可承受 1 次伤害，获得 3 燃料。\n· 支付 3 或 4 燃料，分别获得 1 移动力或钻探力。\n· 翻转矿井板块可使用其背面效果，但会减少分数。\n地表:\n· 在地表结束行动后，出售所有储存中的矿物。\n· 可以弃置手牌，每张获得 2 资金；可以购买新牌。\n· 可以升级机甲，并支付 5 资金维修 1 张牌。\n· 维修会移除牌；维修手牌后立即抽 1 张牌。\n· 补满燃料后进入整备。\n整备:\n· 可免费保留 1 张手牌，每多留 1 张支付 1 燃料。\n· 弃置其他手牌及已打出的牌，然后抽 3 张牌。\n· 牌库一旦为空，立即洗混弃牌组成新牌库。\n· 补齐商店后，轮到下一位玩家。\n结束:\n· 进度达到 5、10、15 格时，争夺对应里程碑。\n· 进度达到 26 格触发终局，溢出矿物最多抵消 10 格。\n· 其余玩家各行动最后一回合，然后计算分数。\n· 矿物按种类获得 2 至 6 分，每 5 资金获得 1 分。\n· 加上板块、里程碑和牌的分数，并扣除深度罚分。\n· 同分时依次比较剩余资金和燃料。\n单人:\n· 与企业机器人轮流行动，可选择 4 档难度。\n· 在地表时，按行动牌费用和首个未满的矿物列选择行动。\n· 每次使用钻探力时，优先移除可负担的下一道屏障。\n· 其次依次考虑第 6 层通道、红宝石、第 5 层通道、祖母绿。\n· 再考虑第 4 层通道、蓝宝石、第 3、2 层通道、金和银。\n· 花完钻探力后，额外收集开放楼层中最贵的 1 个矿物。\n· 有移动标记时，前往红宝石最多的开放楼层。\n· 同量时依次比较其他矿物数量，再选择最深的楼层。\n· 在地下时收集本层最贵的 2 个矿物，随后返回地表。\n· 银、金使商店移除最低价牌，其他矿物移除最高价牌。\n· 同价牌全部移除；两次移除结束后补齐商店。\n· 两个银或金共占 1 个矿物槽，其他矿物各占 1 槽。\n· 槽位填满后，新收集的每个矿物分别进入溢出区。\n· 企业机器人翻完牌库也会触发终局。\n· 总分必须严格超过企业机器人才算获胜。",
			errAction: "当前无法执行这个操作。",
			errTurn: "请等待轮到你行动。",
			names: {
				burner_drill: "燃烧钻机",
				superior_soaker: "强力浸泡器",
				all_in_one_tire: "全能轮胎",
				careless_drilling: "粗心钻探",
				mining_drone: "采矿无人机",
				laser_cutter: "激光切割器",
				reckless_drilling: "鲁莽钻探",
				auto_drill: "自动钻机",
				dynamite_launcher: "炸药发射器",
				harpoon_drill: "鱼叉钻机",
				jackhammer: "冲击钻",
				wrecking_ball: "破碎球",
				hover_pads: "悬浮垫",
				rocket_engine: "火箭引擎",
				panic_button: "紧急按钮",
				wheels_on_heels: "脚跟轮",
				rocket_drone: "火箭无人机",
				rocket_drone_plus: "增强火箭无人机",
				footless_treads: "无足履带",
				flywheel: "飞轮",
				atm_drone: "提款无人机",
				suction_engine: "吸力引擎",
				adaptive_engine: "自适应引擎",
				proper_propeller: "高效螺旋桨",
				nuclear_reactor: "核反应堆",
				water_cooling: "水冷系统",
				swiss_arm: "多用机械臂",
				pit_stop: "维修站",
				coffee_break: "咖啡休息",
				sentient_drone: "智能无人机",
				cleaning_break: "清扫休息",
				refuelling_drone: "加油无人机",
				utility_bot: "多用机器人",
				current_miner: "电流采矿机",
				refuelling_break: "补给休息",
				repair_drone: "维修无人机",
				recoil_capacitor: "反冲电容器",
				deep_neural_network: "深度神经网络",
				surgeon: "外科医生",
				printer_3d: "3D 打印机",
				atomic_dislocator: "原子移位器",
				supercharged_drilling: "增压钻探",
				ultrahot_furnace: "超热熔炉",
				repair_bots: "维修机器人",
				auto_drill_ultra: "超级自动钻机",
				rocket_engine_pro: "专业火箭引擎",
				antigravity_drive: "反重力驱动",
				super_heavy_drill: "超重型钻机",
				reckless_descent: "鲁莽下潜",
				laser_cutter_pro: "专业激光切割器",
				mining_drone_pro: "专业采矿无人机",
				transformer_drill: "变形钻机",
				damage: "伤害",
				brewery: "酿酒厂",
				the_ritz: "豪华酒店",
				pileup: "堆积",
				cave_with_no_ceiling: "无顶洞窟",
				rad_bath: "辐射浴",
				chill_out_zone: "休憩区",
				jackpot: "大奖",
				the_squeeze: "狭缝",
				toys_r_rust: "锈玩具店",
				lobby: "大厅",
				hot_tub: "热水池",
				dispatch: "调度",
				torso: "机甲躯干",
				stock_propeller: "标准螺旋桨",
				claw: "利爪",
				mining_arm: "采矿臂",
				crutch: "支撑架",
				vintage_drill: "老式钻机",
				spider_leg: "蜘蛛腿",
				grabber: "抓取器"
			},
			mineral: {
				silver: "银",
				gold: "金",
				sapphire: "蓝宝石",
				emerald: "祖母绿",
				ruby: "红宝石"
			},
			phase: {
				operations: "行动",
				floorEnd: "楼层效果",
				surfacing: "地表补给",
				keep: "保留手牌",
				upkeep: "整备",
				corporate: "企业机器人行动",
				done: "对局结束"
			},
			zone: {
				hand: "手牌",
				play: "已打出的牌",
				discard: "弃牌",
				deck: "牌库顶"
			},
			shop: {
				drilling: "钻探商店",
				movement: "移动商店",
				utility: "通用商店",
				advanced: "高级商店"
			},
			score: {
				tiles: "矿井板块",
				minerals: "矿物",
				credits: "资金",
				milestones: "里程碑",
				refresh: "刷新标记",
				depth: "深度罚分",
				cards: "卡牌",
				total: "总分"
			},
			effect: {
				fuel: "获得 {{n}} 燃料",
				move: "获得 {{n}} 移动力",
				drill: "获得 {{n}} 钻探力",
				draw: "抽 {{n}} 张牌",
				refresh: "恢复 {{n}} 架无人机",
				repair: "维修 1 张牌",
				damage: "获得 1 张伤害牌",
				damageTop: "将伤害牌放在牌库顶",
				damageHand: "将伤害牌加入手牌",
				credits: "获得 {{n}} 资金",
				storage: "储存上限提高 1",
				tank: "燃料上限提高 1",
				teleport: "移动到任意已开放楼层",
				upgradeMineral: "升级 1 个储存中的矿物",
				marketMineral: "将市场中的 1 个矿物移至溢出区",
				choice: "选择 1 项效果",
				scrapSelf: "移除此牌",
				floorSilver: "免费收集本层 1 个银",
				floorCave: "支付移动力，从供应区获得矿物",
				floorRust: "支付 1 燃料及 1 个储存矿物，维修 1 张牌",
				floorDispatch: "获得资金或恢复无人机",
				fuelTrade: "支付 1 资金，获得 1 燃料",
				payFuelOrDamage: "支付 1 燃料或获得 1 张伤害牌"
			},
			actions: {
				play: "打出",
				move: "移动",
				collect: "收集",
				dig: "挖掘",
				exhaust: "翻转板块",
				buy: "购买",
				sell: "出售",
				function: "基础功能",
				ability: "使用能力",
				resolve: "执行",
				surface: "结束行动",
				discard: "弃置",
				upgrade: "升级",
				repair: "维修",
				refreshShop: "刷新商店",
				refuel: "补满燃料",
				upkeep: "确认",
				keep: "保留",
				tick: "整备",
				milestone: "获得里程碑",
				collapse: "触发终局"
			},
			fuel: "燃料",
			storage: "储存",
			credits: "资金",
			drones: "无人机",
			movement: "移动力",
			drilling: "钻探力",
			progress: "进度",
			endProgress: "终局进度",
			endDistance: "距终局 {{n}} 格",
			endDistanceShort: "余 {{n}} 格",
			endTriggered: "已触发终局",
			endTriggeredBy: "{{name}}已触发终局。",
			finalTurns: "触发者完成当前回合后，其他玩家各进行最后一回合。",
			trackTiles: "板块 {{n}}",
			trackOverflow: "溢出 {{n}}",
			trackDescription: "矿井板块占 {{tiles}} 格，溢出矿物占 {{overflow}} 格，距相接还剩 {{n}} 格。",
			trackMeeting: "板块与溢出矿物相接时触发终局。",
			overflowTrackLimit: "溢出区在进度轨道上最多占 10 格。",
			viewFloorCard: "查看{{name}} · {{floor}}",
			floorTiming: {
				end: "行动结束时",
				excavate: "每次挖掘本层通道后",
				firstExcavation: "每回合首次挖掘本层通道时",
				revealOrExcavate: "开放本层及每次挖掘本层通道时",
				operations: "行动阶段",
				collect: "每次收集本层矿物后",
				reveal: "开放本层时",
				upkeep: "在本层结束行动后整备时"
			},
			floorEffects: {
				brewery: "获得 {fuel:1}。",
				the_ritz: "获得 {coin:2}。",
				pileup: "可免费收集本层 {silver:1}。",
				cave_with_no_ceiling: "可支付 {move:1}/{move:2}/{move:3}，获得 {sapphire:1}/{emerald:1}/{ruby:1}。",
				rad_bath: "获得 {fuel:5}及 {damage:1}。",
				chillFuel: "获得 {fuel:2}。",
				chillPayment: "支付 {fuel-pay:1}或承受伤害。",
				jackpotMineral: "每位玩家有 {emerald:1} 专属矿物，可用 {drill:1}收集。",
				jackpotUpgrade: "升级 {cargo:1}。",
				squeezeCredits: "获得 {coin:2}。",
				squeezePayment: "本层每有一台其他机甲，支付 {fuel-pay:1}或承受伤害。",
				toys_r_rust: "可支付 {fuel-pay:1}及 {cargo:1}，{repair:1}。",
				lobbyCredits: "获得 {coin:2}。",
				lobbyFuel: "可支付 {coin:1}获得 {fuel:1}。",
				lobbyKeep: "可免费保留 3 张牌。",
				hot_tub: "少付 {drill:1}，并将 {damage:1}加入手牌。",
				dispatch: "每架可用无人机获得 {coin:2}，或支付 {fuel-pay:1}恢复 {drone:1}。"
			},
			market: "市场",
			overflow: "溢出区",
			shopTitle: "商店",
			rig: "控制板",
			actionsMenu: "行动",
			close: "关闭",
			confirm: "确认",
			skip: "跳过",
			take: "执行",
			pay: "支付",
			refresh: "恢复无人机",
			damage: "获得伤害牌",
			fuelMode: "补充 {{n}} 燃料",
			mainMode: "主效果 · {{n}} 燃料",
			solidCost: "另付 1 个储存矿物",
			batteryCost: "另付 1 个电池",
			tileBattery: "购买高级牌时，可翻转此板块支付 1 个电池。",
			logBarrier: "打通屏障",
			logCorridor: "挖掘通道",
			permanent: "永久装置",
			once: "每回合一次",
			floor: "第 {{n}} 层",
			surface: "地表",
			locked: "尚未开放",
			corridor: "通道",
			barrier: "屏障",
			remaining: "剩余 {{n}} 块",
			points: "{{n}} 分",
			price: "{{n}} 资金",
			wait: "等待 {{name}}",
			turn: "回合 {{n}}",
			corp: "企业机器人",
			lastRound: "最后一轮",
			selected: "已保留",
			keepHint: "免费保留 {{n}} 张，其余每张支付 1 燃料。",
			abilityTitle: "机甲能力",
			tilesTitle: "矿井板块",
			topTitle: "牌库顶",
			empty: "暂无",
			buyWith: "使用第 {{n}} 块板块的电池",
			upgradeFuel: "提高燃料上限 · {{n}} 资金",
			upgradeStorage: "提高储存上限 · 3 资金",
			repairCost: "维修 · 5 资金",
			defaultMove: "支付 3 燃料，获得 1 移动力",
			defaultDrill: "支付 4 燃料，获得 1 钻探力",
			defaultDamage: "承受伤害，获得 3 燃料",
			tileFlip: "翻转后 {{n}} 分",
			mineralTo: "{{from}} → {{to}}",
			atZone: "{{zone}} · {{name}}",
			moveTo: "移动至 {{floor}}",
			collectAt: "收集 {{mineral}} · {{floor}}",
			digCorridor: "挖掘通道 · {{n}} 钻探力",
			digBarrier: "打通屏障 · {{n}} 钻探力",
			paidMineral: "支付 {{mineral}} · {{action}}",
			logLine: "{{name}}：{{action}}",
			soloDifficulty: "单人难度",
			soloHint: "仅在 1 人游戏中使用企业机器人。",
			soloWin: "你击败了企业机器人",
			soloLoss: "企业机器人获胜",
			soloScore: "企业机器人：{{n}} 分",
			floorsText: {
				brewery: "行动结束时获得 {fuel:1}。",
				the_ritz: "每次挖掘通道后获得 {coin:2}。",
				pileup: "行动结束时可免费收集本层 {silver:1}。",
				cave_with_no_ceiling: "行动结束时可支付 {move:1}/{move:2}/{move:3}，获得 {sapphire:1}/{emerald:1}/{ruby:1}。",
				rad_bath: "每回合首次挖掘本层通道后，获得 {fuel:5}及 {damage:1}。",
				chill_out_zone: "开放本层及每次挖掘本层通道时获得 {fuel:2}；行动结束时支付 {fuel-pay:1}或承受伤害。",
				jackpot: "每位玩家有 1 个专属祖母绿，可用 {drill:1}收集；行动结束时升级 {cargo:1}。",
				the_squeeze: "每次收集本层矿物后获得 {coin:2}；行动结束时，本层每有一台其他机甲，支付 {fuel-pay:1}或承受伤害。",
				toys_r_rust: "行动结束时可支付 {fuel-pay:1}及 {cargo:1}，{repair:1}。",
				lobby: "开放本层时获得 {coin:2}；每次收矿后可支付 {coin:1}获得 {fuel:1}；可免费保留 3 张牌。",
				hot_tub: "每回合首次挖掘本层通道少付 {drill:1}，并将 {damage:1}加入手牌。",
				dispatch: "行动结束时每架可用无人机获得 {coin:2}，或支付 {fuel-pay:1}恢复 {drone:1}。"
			},
			abilities: {
				burner_drill: "本回合可获得 {fuel:2}，限一次。",
				superior_soaker: "本回合可升级 {cargo:1}，限一次。",
				harpoon_drill: "本回合可支付 {drill:1}收集相邻已开放楼层的 1 个矿物，限一次。",
				jackhammer: "本回合每次挖掘板块后获得 {fuel:1}。",
				flywheel: "本回合每张用于补充燃料的牌额外获得 {fuel:1}，包含此前打出的牌。",
				suction_engine: "本回合收集本层银无需支付钻探力。",
				adaptive_engine: "本回合可反复支付 {fuel-pay:2}获得 {move:1}。",
				repair_drone: "本回合可反复消耗 {drone:1}获得 {fuel:2}。",
				wrecking_ball: "每回合获得至少 {move:3}后，可获得 {drill:1}一次。",
				hover_pads: "每回合可获得 {move:1}一次。",
				nuclear_reactor: "每回合可获得 {fuel:1}一次。",
				recoil_capacitor: "每回合获得至少 {drill:3}后，可获得 {fuel:2}一次。",
				deep_neural_network: "每回合可支付 {fuel-pay:2}{draw:1}一次。",
				surgeon: "每回合可支付 {fuel-pay:1}获得 {drill:1}一次。",
				printer_3d: "每回合可恢复 {drone:1}一次。"
			},
			payFuel: "支付 1 燃料",
			milestone: "{{n}} 格里程碑 · {{vp}} 分",
			finalMilestone: "终局里程碑 · 18 分",
			unclaimed: "尚未获得",
			keepCost: "本次保留 {{n}} 张，支付 {{cost}} 燃料。",
			corpDeck: "行动牌剩余 {{n}} 张",
			corpRevealed: "行动牌 · 主效果费用 {{n}} 燃料",
			corpBoard: "企业行动表",
			corpMove: "移动机甲",
			corpSlots: "矿物槽",
			costBadge: "费用{{n}}",
			floorOccupants: "{{floor}} · {{names}}",
			jackpotMineral: "收集专属祖母绿",
			tileCount: "{{n}} 块",
			solidPayment: "另付 1 个{{mineral}}",
			emptyStorage: "空储存槽",
			progressUnits: "{{n}} 格进度",
			drillCost: "支付 {{n}} 钻探力",
			corridorButton: "挖掘通道",
			barrierButton: "打通屏障",
			useMain: "使用主效果",
			payMain: "支付 {{n}} 燃料"
		},
		en: {
			panel: {
				finalMilestone: "Endgame",
				basic: "Basic functions",
				currentFloor: "Current floor",
				discardBuy: "Discard and buy",
				upgradeRepair: "Upgrade and repair",
				other: "Other actions",
				visitShop: "Visit shop",
				currentScore: "Current score",
				scoreDetails: "Score details",
				deck: "Card zones",
				floorMinerals: "Floor minerals",
				nextCorridor: "Next corridor",
				occupants: "Mechs on this floor",
				currentCard: "Current action card",
				cardsRemaining: "{{n}} cards left",
				milestoneAt: "{{n}} spaces",
				overflowValue: "Overflow {{n}}",
				flipped: "Flipped",
				gainMove: "Gain movement",
				gainDrill: "Gain drilling",
				takeDamage: "Take damage",
				fuelUpgrade: "Fuel capacity +1",
				storageUpgrade: "Storage capacity +1",
				winner: "{{names}} wins",
				finalScore: "Final scores"
			},
			battery: "Battery",
			capacity: "Capacity",
			fuelModeLabel: "Refuel",
			tileNumber: "Tile {{n}}",
			pointsLabel: "Points",
			keepAllowance: "Keep {{n}} cards free; each additional card costs",
			keepSelection: "Keeping {{n}} cards",
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Drillers",
			desc: "Pilot a mining mech, improve your deck, and compete for underground riches.",
			rules: "Goal:\n· Earn the most points from minerals, mine tiles, and milestones.\nSetup:\n· Each player starts with 8 starting cards and 1 Damage card.\n· Start with fuel capacity 10, storage capacity 2, and 3 drones.\n· Only 1 drone starts active.\nOperations:\n· Play a card for fuel, or pay its cost to use its main effect.\n· Spend 1 movement to reach an adjacent open floor.\n· Spend 1 drill to collect 1 mineral from your floor.\n· Pay the floor cost to excavate a corridor and reveal minerals.\n· Pay the next barrier cost to open that floor and descend.\n· Exhaust a drone to sell 1 mineral or buy 1 card.\n· Put purchases on your deck; you may always see your top card.\n· Once per turn, take damage to gain 3 fuel.\n· Spend 3 or 4 fuel to gain 1 movement or 1 drill respectively.\n· Flip a mine tile to use its effect, reducing its point value.\nSurfacing:\n· If you end Operations on the surface, sell all stored minerals.\n· You may discard hand cards for 2 credits each and buy cards.\n· You may upgrade your mech and pay 5 credits to repair 1 card.\n· Repair removes a card; repairing a hand card draws a replacement.\n· Fill your fuel tank before Upkeep.\nUpkeep:\n· Keep 1 hand card free; pay 1 fuel for each additional card.\n· Discard other hand cards and played cards, then draw 3 cards.\n· Immediately shuffle discards into a new deck when it empties.\n· Refill the shops, then pass the turn.\nEnd:\n· First to reach 5, 10, or 15 progress earns that milestone.\n· Reach 26 progress to trigger the end; overflow shortens it by up to 10.\n· Every other player takes one final turn before scoring.\n· Minerals score 2–6 points by type; every 5 credits scores 1 point.\n· Add tile, milestone, and card points; subtract the depth penalty.\n· Break ties by remaining credits, then fuel.\nSolo:\n· Alternate turns with a corporate bot at one of 4 difficulties.\n· On the surface, use the action-card cost and first unfilled mineral column.\n· For each drill expenditure, first try the next affordable barrier.\n· Next consider floor 6 corridors, ruby, floor 5 corridors, and emerald.\n· Then floor 4 corridors, sapphire, floor 3 and 2 corridors, gold, and silver.\n· After spending all drills, collect the best mineral on an open floor.\n· A movement symbol sends the bot to the open floor with the most rubies.\n· Break ties by counts of successively cheaper minerals, then deepest floor.\n· Underground, collect the 2 best minerals there and return to the surface.\n· Silver or gold removes the cheapest shop cards; other minerals the costliest.\n· Remove all ties; refill only after both removals are complete.\n· A pair of silver or gold fills 1 slot; each other mineral fills 1 slot.\n· After the track fills, each new mineral goes separately into overflow.\n· Emptying the corporate deck also triggers the end.\n· You must strictly outscore the corporate bot to win.",
			errAction: "That action is unavailable now.",
			errTurn: "Please wait for your turn.",
			names: {
				burner_drill: "Burner Drill",
				superior_soaker: "Superior Soaker",
				all_in_one_tire: "All In One Tire",
				careless_drilling: "Careless Drilling",
				mining_drone: "Mining Drone",
				laser_cutter: "Laser Cutter",
				reckless_drilling: "Reckless Drilling",
				auto_drill: "Auto Drill",
				dynamite_launcher: "Dynamite Launcher",
				harpoon_drill: "Harpoon Drill",
				jackhammer: "Jackhammer",
				wrecking_ball: "Wrecking Ball",
				hover_pads: "Hover Pads",
				rocket_engine: "Rocket Engine",
				panic_button: "Panic Button",
				wheels_on_heels: "Wheels On Heels",
				rocket_drone: "Rocket Drone",
				rocket_drone_plus: "Rocket Drone Plus",
				footless_treads: "Footless Treads",
				flywheel: "Flywheel",
				atm_drone: "Atm Drone",
				suction_engine: "Suction Engine",
				adaptive_engine: "Adaptive Engine",
				proper_propeller: "Proper Propeller",
				nuclear_reactor: "Nuclear Reactor",
				water_cooling: "Water Cooling",
				swiss_arm: "Swiss Arm",
				pit_stop: "Pit Stop",
				coffee_break: "Coffee Break",
				sentient_drone: "Sentient Drone",
				cleaning_break: "Cleaning Break",
				refuelling_drone: "Refuelling Drone",
				utility_bot: "Utility Bot",
				current_miner: "Current-₡ Miner",
				refuelling_break: "Refuelling Break",
				repair_drone: "Repair Drone",
				recoil_capacitor: "Recoil Capacitor",
				deep_neural_network: "Deep Neural Network",
				surgeon: "Surgeon",
				printer_3d: "3D Printer",
				atomic_dislocator: "Atomic Dislocator",
				supercharged_drilling: "Supercharged Drilling",
				ultrahot_furnace: "Ultrahot Furnace",
				repair_bots: "Repair Bots",
				auto_drill_ultra: "Auto Drill Ultra",
				rocket_engine_pro: "Rocket Engine Pro",
				antigravity_drive: "Antigravity Drive",
				super_heavy_drill: "Super Heavy Drill",
				reckless_descent: "Reckless Descent",
				laser_cutter_pro: "Laser Cutter Pro",
				mining_drone_pro: "Mining Drone Pro",
				transformer_drill: "Transformer Drill",
				damage: "Damage",
				brewery: "Brewery",
				the_ritz: "The Ritz",
				pileup: "Pileup",
				cave_with_no_ceiling: "Cave With No Ceiling",
				rad_bath: "Rad Bath",
				chill_out_zone: "Chill Out Zone",
				jackpot: "Jackpot",
				the_squeeze: "The Squeeze",
				toys_r_rust: "Toys R Rust",
				lobby: "Lobby",
				hot_tub: "Hot Tub",
				dispatch: "Dispatch",
				torso: "Torso",
				stock_propeller: "Stock Propeller",
				claw: "Claw",
				mining_arm: "Mining Arm",
				crutch: "Crutch",
				vintage_drill: "Vintage Drill",
				spider_leg: "Spider Leg",
				grabber: "Grabber"
			},
			mineral: {
				silver: "Silver",
				gold: "Gold",
				sapphire: "Sapphire",
				emerald: "Emerald",
				ruby: "Ruby"
			},
			phase: {
				operations: "Operations",
				floorEnd: "Floor effect",
				surfacing: "Surfacing",
				keep: "Keep cards",
				upkeep: "Upkeep",
				corporate: "Corporate turn",
				done: "Game over"
			},
			zone: {
				hand: "Hand",
				play: "Played",
				discard: "Discard",
				deck: "Deck top"
			},
			shop: {
				drilling: "Drilling",
				movement: "Movement",
				utility: "Utility",
				advanced: "Advanced"
			},
			score: {
				tiles: "Mine tiles",
				minerals: "Minerals",
				credits: "Credits",
				milestones: "Milestones",
				refresh: "Refresh tile",
				depth: "Depth penalty",
				cards: "Cards",
				total: "Total"
			},
			effect: {
				fuel: "Gain {{n}} fuel",
				move: "Gain {{n}} movement",
				drill: "Gain {{n}} drills",
				draw: "Draw {{n}} cards",
				refresh: "Refresh {{n}} drones",
				repair: "Repair 1 card",
				damage: "Take 1 Damage card",
				damageTop: "Put Damage on your deck",
				damageHand: "Add Damage to your hand",
				credits: "Gain {{n}} credits",
				storage: "Increase storage capacity by 1",
				tank: "Increase fuel capacity by 1",
				teleport: "Move to any open floor",
				upgradeMineral: "Upgrade 1 stored mineral",
				marketMineral: "Move 1 market mineral to overflow",
				choice: "Choose an effect",
				scrapSelf: "Remove this card",
				floorSilver: "Collect 1 silver here for free",
				floorCave: "Spend movement for a supply mineral",
				floorRust: "Pay 1 fuel and 1 stored mineral to repair",
				floorDispatch: "Gain credits or refresh a drone",
				fuelTrade: "Pay 1 credit to gain 1 fuel",
				payFuelOrDamage: "Pay 1 fuel or take Damage"
			},
			actions: {
				play: "Play",
				move: "Move",
				collect: "Collect",
				dig: "Excavate",
				exhaust: "Flip tile",
				buy: "Buy",
				sell: "Sell",
				function: "Default function",
				ability: "Use ability",
				resolve: "Resolve",
				surface: "End Operations",
				discard: "Discard",
				upgrade: "Upgrade",
				repair: "Repair",
				refreshShop: "Refresh shop",
				refuel: "Fill fuel tank",
				upkeep: "Confirm",
				keep: "Keep",
				tick: "Upkeep",
				milestone: "Claim milestone",
				collapse: "Trigger the end"
			},
			fuel: "Fuel",
			storage: "Storage",
			credits: "Credits",
			drones: "Drones",
			movement: "Movement",
			drilling: "Drills",
			progress: "Progress",
			endProgress: "Endgame progress",
			endDistance: "{{n}} to the end",
			endDistanceShort: "{{n}} left",
			endTriggered: "End triggered",
			endTriggeredBy: "{{name}} has triggered the end.",
			finalTurns: "After the triggering player finishes their current turn, every other player takes one final turn.",
			trackTiles: "Tiles {{n}}",
			trackOverflow: "Overflow {{n}}",
			trackDescription: "Mine tiles occupy {{tiles}} spaces and overflow minerals occupy {{overflow}} spaces, leaving {{n}} spaces between them.",
			trackMeeting: "The end is triggered when mine tiles meet overflow minerals.",
			overflowTrackLimit: "Overflow occupies at most 10 spaces on the progress track.",
			viewFloorCard: "View {{name}} · {{floor}}",
			floorTiming: {
				end: "At the end of Operations",
				excavate: "After each corridor excavation here",
				firstExcavation: "On your first corridor excavation here each turn",
				revealOrExcavate: "When revealing this floor or excavating a corridor here",
				operations: "During Operations",
				collect: "After each mineral collected here",
				reveal: "When revealing this floor",
				upkeep: "During Upkeep after ending Operations here"
			},
			floorEffects: {
				brewery: "Gain {fuel:1}.",
				the_ritz: "Gain {coin:2}.",
				pileup: "You may collect {silver:1} here for free.",
				cave_with_no_ceiling: "You may spend {move:1}/{move:2}/{move:3} for {sapphire:1}/{emerald:1}/{ruby:1}.",
				rad_bath: "Gain {fuel:5} and {damage:1}.",
				chillFuel: "Gain {fuel:2}.",
				chillPayment: "Pay {fuel-pay:1} or take Damage.",
				jackpotMineral: "Each player may collect their reserved {emerald:1} for {drill:1}.",
				jackpotUpgrade: "Upgrade {cargo:1}.",
				squeezeCredits: "Gain {coin:2}.",
				squeezePayment: "For each other mech here, pay {fuel-pay:1} or take Damage.",
				toys_r_rust: "You may pay {fuel-pay:1} and {cargo:1} to repair {repair:1}.",
				lobbyCredits: "Gain {coin:2}.",
				lobbyFuel: "You may pay {coin:1} to gain {fuel:1}.",
				lobbyKeep: "Keep up to 3 cards for free.",
				hot_tub: "Pay 1 fewer drill and add {damage:1} to your hand.",
				dispatch: "Gain {coin:2} per active drone, or pay {fuel-pay:1} to refresh {drone:1}."
			},
			market: "Market",
			overflow: "Overflow",
			shopTitle: "Shops",
			rig: "Rig",
			actionsMenu: "Actions",
			close: "Close",
			confirm: "Confirm",
			skip: "Skip",
			take: "Resolve",
			pay: "Pay",
			refresh: "Refresh a drone",
			damage: "Take Damage",
			fuelMode: "Gain {{n}} fuel",
			mainMode: "Main effect · {{n}} fuel",
			solidCost: "Also pay 1 stored mineral",
			batteryCost: "Also pay 1 battery",
			tileBattery: "Flip this tile to pay 1 battery when buying an advanced card.",
			logBarrier: "Removed a barrier",
			logCorridor: "Excavated a corridor",
			permanent: "Permanent",
			once: "Once per turn",
			floor: "Floor {{n}}",
			surface: "Surface",
			locked: "Unopened",
			corridor: "Corridor",
			barrier: "Barrier",
			remaining: "{{n}} remaining",
			points: "{{n}} points",
			price: "{{n}} credits",
			wait: "Waiting for {{name}}",
			turn: "Turn {{n}}",
			corp: "Corporation",
			lastRound: "Final round",
			selected: "Kept",
			keepHint: "Keep {{n}} free; pay 1 fuel for each extra card.",
			abilityTitle: "Mech abilities",
			tilesTitle: "Mine tiles",
			topTitle: "Deck top",
			empty: "None",
			buyWith: "Use battery from tile {{n}}",
			upgradeFuel: "Increase fuel capacity · {{n}} credits",
			upgradeStorage: "Increase storage capacity · 3 credits",
			repairCost: "Repair · 5 credits",
			defaultMove: "Pay 3 fuel for 1 movement",
			defaultDrill: "Pay 4 fuel for 1 drill",
			defaultDamage: "Take Damage for 3 fuel",
			tileFlip: "{{n}} points after flipping",
			mineralTo: "{{from}} → {{to}}",
			atZone: "{{zone}} · {{name}}",
			moveTo: "Move to {{floor}}",
			collectAt: "Collect {{mineral}} · {{floor}}",
			digCorridor: "Excavate corridor · {{n}} drills",
			digBarrier: "Remove barrier · {{n}} drills",
			paidMineral: "Pay {{mineral}} · {{action}}",
			logLine: "{{name}}: {{action}}",
			soloDifficulty: "Solo difficulty",
			soloHint: "The corporate bot is used only in a 1-player game.",
			soloWin: "You defeated the corporation",
			soloLoss: "The corporation wins",
			soloScore: "Corporation: {{n}} points",
			floorsText: {
				brewery: "Gain {fuel:1} at the end of Operations.",
				the_ritz: "Gain {coin:2} whenever you excavate a corridor here.",
				pileup: "At the end of Operations, you may collect {silver:1} here for free.",
				cave_with_no_ceiling: "At the end of Operations, you may spend {move:1}/{move:2}/{move:3} for {sapphire:1}/{emerald:1}/{ruby:1}.",
				rad_bath: "The first corridor you excavate here each turn gives {fuel:5} and {damage:1}.",
				chill_out_zone: "Gain {fuel:2} on reveal and each corridor excavation; pay {fuel-pay:1} or take Damage at the end of Operations.",
				jackpot: "Each player may collect their own emerald for {drill:1}; upgrade {cargo:1} at the end of Operations.",
				the_squeeze: "Gain {coin:2} per mineral collected here; at the end of Operations pay {fuel-pay:1} or take Damage for each other mech here.",
				toys_r_rust: "At the end of Operations, you may pay {fuel-pay:1} and {cargo:1} to repair {repair:1}.",
				lobby: "Gain {coin:2} on reveal; after collecting, you may pay {coin:1} for {fuel:1}; keep up to 3 cards for free.",
				hot_tub: "Your first corridor here each turn costs 1 fewer drill and adds {damage:1} to your hand.",
				dispatch: "At the end of Operations, gain {coin:2} per active drone or spend {fuel-pay:1} to refresh {drone:1}."
			},
			abilities: {
				burner_drill: "Once this turn, gain {fuel:2}.",
				superior_soaker: "Once this turn, upgrade {cargo:1}.",
				harpoon_drill: "Once this turn, pay {drill:1} to collect 1 mineral from an adjacent open floor.",
				jackhammer: "Gain {fuel:1} whenever you excavate a mine tile this turn.",
				flywheel: "Each fuel card played this turn gives an extra {fuel:1}, including earlier cards.",
				suction_engine: "Collect silver on your floor without paying drills this turn.",
				adaptive_engine: "This turn, repeatedly pay {fuel-pay:2} for {move:1}.",
				repair_drone: "This turn, repeatedly exhaust {drone:1} for {fuel:2}.",
				wrecking_ball: "Once per turn after gaining at least {move:3}, gain {drill:1}.",
				hover_pads: "Once per turn, gain {move:1}.",
				nuclear_reactor: "Once per turn, gain {fuel:1}.",
				recoil_capacitor: "Once per turn after gaining at least {drill:3}, gain {fuel:2}.",
				deep_neural_network: "Once per turn, pay {fuel-pay:2} to draw {draw:1}.",
				surgeon: "Once per turn, pay {fuel-pay:1} to gain {drill:1}.",
				printer_3d: "Once per turn, refresh {drone:1}."
			},
			payFuel: "Pay 1 fuel",
			milestone: "{{n}} progress · {{vp}} points",
			finalMilestone: "Final milestone · 18 points",
			unclaimed: "Unclaimed",
			keepCost: "Keep {{n}} cards for {{cost}} fuel.",
			corpDeck: "{{n}} action cards remaining",
			corpRevealed: "Action card · main cost {{n}} fuel",
			corpBoard: "Corporate action board",
			corpMove: "Move mech",
			corpSlots: "Mineral slots",
			costBadge: "Cost{{n}}",
			floorOccupants: "{{floor}} · {{names}}",
			jackpotMineral: "Collect your reserved emerald",
			tileCount: "{{n}} tiles",
			solidPayment: "Also pay 1 {{mineral}}",
			emptyStorage: "Empty storage slot",
			progressUnits: "{{n}} progress",
			drillCost: "Pay {{n}} drills",
			corridorButton: "Excavate",
			barrierButton: "Open",
			useMain: "Use effect",
			payMain: "Pay {{n}} fuel"
		}
	}
};
//#endregion
export { ir as default };
