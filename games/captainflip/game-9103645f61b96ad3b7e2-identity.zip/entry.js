import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useT as r } from "@bgparty/sdk/i18n";
import { Texture as i } from "@bgparty/sdk/texture";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as s } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as c } from "@bgparty/sdk/ui/player-strip";
import { LogTicker as l } from "@bgparty/sdk/ui/log-sheet";
import { DeltaNumber as u } from "@bgparty/sdk/fx/delta-number";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { ConfirmButton as m } from "@bgparty/sdk/confirm-button";
import { IconClose as h } from "@bgparty/sdk/icons";
import { Confetti as g } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as _, OptionSection as v, OptionSwitch as y } from "@bgparty/sdk/ui/game-options";
//#region src/games/captainflip/data.ts
var b = [
	"cartographer",
	"navigator",
	"cook",
	"gunner",
	"monkey",
	"parrot",
	"lookout",
	"carpenter",
	"swabby"
], x = [
	"base",
	"cursed",
	"burning",
	"gambler",
	"kraken",
	"winds"
], S = (e, t = "none") => ({
	rows: e,
	bonus: t
}), C = {
	A: {
		columns: [
			S([0, 1]),
			S([
				0,
				1,
				2
			], "map"),
			S([
				0,
				1,
				2,
				3,
				4
			], "coins5"),
			S([2, 3]),
			S([
				0,
				1,
				2
			], "coins3")
		],
		sea: "#167f99",
		sky: "#c4e8ed",
		scenery: "ship"
	},
	B: {
		columns: [
			S([0, 1], "race1"),
			S([
				0,
				1,
				2
			], "race2"),
			S([
				0,
				1,
				2,
				3,
				4
			], "race6"),
			S([0], "race0"),
			S([
				0,
				1,
				2,
				3
			], "race4")
		],
		sea: "#346d76",
		sky: "#a9ccc1",
		scenery: "kraken"
	},
	C: {
		columns: [
			S([
				0,
				1,
				2
			], "map"),
			S([
				0,
				1,
				2
			], "same6"),
			S([0, 1]),
			S([
				0,
				1,
				2,
				3,
				4
			], "different4"),
			S([0, 1])
		],
		sea: "#38598b",
		sky: "#a1b3d9",
		scenery: "raft"
	},
	D: {
		columns: [
			S([
				1,
				2,
				3
			], "coins3"),
			S([
				0,
				1,
				2,
				3
			], "completed2"),
			S([
				0,
				1,
				2,
				3,
				4
			], "diversity"),
			S([2, 3]),
			S([2], "pay1")
		],
		sea: "#b57089",
		sky: "#f9c6a7",
		scenery: "island"
	},
	E: {
		columns: [
			S([
				0,
				1,
				2,
				3
			], "coins4"),
			S([0, 1], "sameMap"),
			S([
				0,
				1,
				2
			], "differentFlip"),
			S([
				0,
				1,
				2
			], "sameDraw"),
			S([
				1,
				2,
				3
			], "coins3")
		],
		sea: "#704777",
		sky: "#eeb7b3",
		scenery: "kraken"
	},
	F: {
		columns: [
			S([0, 1]),
			S([
				1,
				2,
				3
			], "map"),
			S([
				0,
				1,
				2
			], "neighbors"),
			S([
				1,
				2,
				3,
				4
			], "differentDraw"),
			S([
				0,
				1,
				2
			], "coins3")
		],
		sea: "#248b8c",
		sky: "#a8d7ce",
		scenery: "submarine"
	},
	G: {
		columns: [
			S([3, 4], "cellFlip"),
			S([
				1,
				2,
				3
			], "map"),
			S([
				0,
				1,
				2,
				3
			], "race5"),
			S([
				0,
				1,
				2
			], "cellPlay"),
			S([
				0,
				1,
				2
			], "cellPlay")
		],
		sea: "#376b95",
		sky: "#bdcee4",
		scenery: "prison"
	},
	H: {
		columns: [
			S([
				0,
				1,
				2
			], "map"),
			S([
				1,
				2,
				3,
				4
			], "coins3map"),
			S([1, 2], "passMaps"),
			S([
				1,
				2,
				3
			], "firstFlip"),
			S([
				0,
				1,
				2
			], "coins3")
		],
		sea: "#85624d",
		sky: "#e6c79f",
		scenery: "observatory"
	},
	I: {
		columns: [
			S([0, 1]),
			S([
				1,
				2,
				3
			], "map"),
			S([
				0,
				1,
				2,
				3,
				4
			], "coins3"),
			S([
				0,
				1,
				2,
				3
			], "bombs2"),
			S([2], "mapBomb")
		],
		sea: "#d96c4c",
		sky: "#ffe0a0",
		scenery: "skull"
	}
}, ee = {
	cartographer: "#83c2d7",
	navigator: "#d99dcd",
	cook: "#f4c97b",
	gunner: "#e5a09b",
	monkey: "#c1d495",
	parrot: "#ebc660",
	lookout: "#92b4da",
	carpenter: "#d3b193",
	swabby: "#99cfc2"
}, w = {
	cartographer: "games.captainflip.role.cartographer",
	navigator: "games.captainflip.role.navigator",
	cook: "games.captainflip.role.cook",
	gunner: "games.captainflip.role.gunner",
	monkey: "games.captainflip.role.monkey",
	parrot: "games.captainflip.role.parrot",
	lookout: "games.captainflip.role.lookout",
	carpenter: "games.captainflip.role.carpenter",
	swabby: "games.captainflip.role.swabby"
}, T = {
	base: "games.captainflip.map.base",
	cursed: "games.captainflip.map.cursed",
	burning: "games.captainflip.map.burning",
	gambler: "games.captainflip.map.gambler",
	kraken: "games.captainflip.map.kraken",
	winds: "games.captainflip.map.winds"
}, E = {
	A: "games.captainflip.board.A",
	B: "games.captainflip.board.B",
	C: "games.captainflip.board.C",
	D: "games.captainflip.board.D",
	E: "games.captainflip.board.E",
	F: "games.captainflip.board.F",
	G: "games.captainflip.board.G",
	H: "games.captainflip.board.H",
	I: "games.captainflip.board.I"
}, D = {
	id: "captainflip",
	tier: "alpha",
	mechanics: [
		"tile-placement",
		"push-your-luck",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.captainflip.name",
	descKey: "games.captainflip.desc",
	rulesKey: "games.captainflip.rules",
	icon: "🏴‍☠️",
	iconImg: "games/captainflip.webp",
	rulesUrl: { en: "https://playpunk.com/src/downloads/RGB/CF_Rules_EN.pdf" },
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	playerRange: (e) => ({
		min: e && typeof e == "object" && "board" in e && "FGHI".includes(String(e.board)) ? 2 : 1,
		max: 5
	}),
	accent: "#087f8c",
	releasedAt: "2026-10-29T18:55:14+08:00",
	search: {
		py: "yang fan duo bao",
		init: "yfdb"
	},
	hotseat: "open",
	botDelayMs: 650
}, O = t.object({
	board: t.enum([
		"A",
		"B",
		"C",
		"D",
		"E",
		"F",
		"G",
		"H",
		"I"
	]).default("A"),
	map: t.enum(x).default("base"),
	secondMap: t.enum(x).default("base"),
	dolphin: t.boolean().default(!1),
	bottle: t.boolean().default(!1)
}).default({
	board: "A",
	map: "base",
	secondMap: "base",
	dolphin: !1,
	bottle: !1
}), te = t.discriminatedUnion("type", [
	t.object({ type: t.literal("draw") }),
	t.object({ type: t.literal("flipDraw") }),
	t.object({
		type: t.literal("place"),
		column: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("flipTile"),
		id: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("selectMap"),
		id: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("mapOrder"),
		id: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("steal"),
		target: t.string()
	}),
	t.object({
		type: t.literal("direction"),
		direction: t.union([t.literal(-1), t.literal(1)])
	}),
	t.object({
		type: t.literal("cell"),
		id: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), k = t.object({
	id: t.int(),
	face: t.enum(b),
	back: t.enum(b).nullable(),
	column: t.int(),
	row: t.int()
}), A = t.object({
	coins: t.number(),
	swabbies: t.number(),
	lookouts: t.number(),
	carpenters: t.number(),
	parrots: t.number(),
	board: t.number(),
	maps: t.number(),
	total: t.number(),
	bombs: t.int(),
	eliminated: t.boolean()
}), j = t.object({
	config: O,
	phase: t.enum([
		"draw",
		"choose",
		"resolve",
		"flip",
		"map",
		"direction",
		"cellFlip",
		"cellPlay",
		"mapOrder",
		"steal",
		"done"
	]),
	players: t.array(t.object({
		rid: t.string(),
		coins: t.int(),
		tiles: t.array(k),
		cells: t.array(k),
		extraBomb: t.boolean()
	})),
	turn: t.string(),
	actor: t.string(),
	first: t.string(),
	round: t.int(),
	lastRound: t.boolean(),
	bagCount: t.int(),
	drawn: k.nullable(),
	canFlip: t.boolean(),
	legalColumns: t.array(t.int()),
	targets: t.array(t.int()),
	stealTargets: t.array(t.string()),
	maps: t.array(t.object({
		id: t.int(),
		kind: t.enum(x),
		owner: t.string().nullable(),
		rotation: t.int()
	})),
	scores: t.record(t.string(), A),
	log: t.array(t.object({
		n: t.int(),
		rid: t.string(),
		kind: t.enum([
			"draw",
			"flip",
			"place",
			"coins",
			"map",
			"dolphin",
			"bottle",
			"pass",
			"end"
		]),
		role: t.enum(b).optional(),
		amount: t.number().optional()
	}))
}), M = t.object({}), N = (e, t) => e.players.find((e) => e.rid === t), P = (t, n) => e(t.seed, t.cursor++, n), F = (e, ...t) => {
	e.tasks.unshift(...t), e.phase = "resolve";
}, I = (e, t, n, r, i) => {
	e.log.push({
		n: e.serial++,
		rid: t,
		kind: n,
		...r ? { role: r } : {},
		...i === void 0 ? {} : { amount: i }
	}), e.log = e.log.slice(-100);
}, L = (e, t, n) => {
	n <= 0 || (N(e, t).coins += n, e.gained[t] = (e.gained[t] ?? 0) + n, I(e, t, "coins", void 0, n));
}, R = (e, t, n) => e.maps.some((e) => e.owner === t && e.kind === n), z = (e, t) => C[t].columns.filter((t, n) => e.filter((e) => e.column === n).length === t.rows.length).length, B = (e, t) => e.tiles.filter((e) => e.column === t), V = (e) => e.length > 0 && e.every((t) => t.face === e[0].face), H = (e) => new Set(e.map((e) => e.face)).size === e.length, U = (e, t, n) => !e.tiles.some((e) => e.column === t && e.row === n);
function ne(e, t) {
	return e.tiles.filter((e) => e.face === "cartographer").length + (t === "H" && U(e, 2, 1) ? 1 : 0) + (t === "I" ? Number(U(e, 0, 0)) + Number(U(e, 2, 0)) : 0);
}
function W(e, t, n) {
	return e.tiles.filter((e) => e.face === "gunner").length + Number(e.extraBomb) + (t === "I" && U(e, 2, 3) ? 1 : 0) + n.filter((t) => t.owner === e.rid && t.kind === "burning").length;
}
function G(e, t, n) {
	let r = e.tiles, i = new Set(r.filter((e) => e.face === "swabby").map((e) => e.column)).size ** 2, a = r.filter((e) => e.face === "lookout" && !r.some((t) => t.column === e.column && t.row > e.row)).length * 4, o = r.filter((n) => n.face === "carpenter" && !r.some((e) => e.face === "gunner" && (e.column === n.column || e.row === n.row)) && (t.board !== "I" || !U(e, 2, 3) || n.column !== 2 && n.row !== 3)).length * 3, s = -r.filter((e) => e.face === "parrot").length, c = t.board === "C" ? (r.filter((e) => e.column === 1).length === 3 && V(r.filter((e) => e.column === 1)) ? 6 : 0) + (r.filter((e) => e.column === 3).length === 5 && H(r.filter((e) => e.column === 3)) ? 4 : 0) : 0, l = n.filter((t) => t.owner === e.rid && t.kind === "burning").length * 5, u = W(e, t.board, n);
	return {
		coins: e.coins,
		swabbies: i,
		lookouts: a,
		carpenters: o,
		parrots: s,
		board: c,
		maps: l,
		total: e.coins + i + a + o + s + c + l,
		bombs: u,
		eliminated: u >= 3
	};
}
function K(e, t) {
	let n = N(e, t);
	return C[e.config.board].columns.flatMap((e, t) => B(n, t).length < e.rows.length && (e.bonus !== "pay1" || n.coins !== 0) ? [t] : []);
}
function re(e, t) {
	let n = P(e, 2) === 1;
	return {
		id: e.nextId++,
		face: n ? t.back : t.front,
		back: n ? t.front : t.back,
		known: !1,
		column: -1,
		row: -1
	};
}
function ie(e, t, n) {
	let r = {
		config: O.parse(e),
		players: t.map((e) => ({
			rid: e,
			coins: 0,
			tiles: [],
			cells: [],
			extraBomb: !1,
			awarded: []
		})),
		seed: n,
		cursor: 0,
		nextId: 0,
		bag: [],
		phase: "draw",
		turn: 0,
		first: 0,
		round: 1,
		lastRound: !1,
		actor: "",
		drawn: null,
		flipped: !1,
		tasks: [],
		pending: null,
		targets: [],
		stealTargets: [],
		maps: [],
		races: [],
		gained: {},
		log: [],
		serial: 0
	};
	for (let e = 0; e < b.length; e++) for (let t = e + 1; t < b.length; t++) for (let n = 0; n < 2; n++) r.bag.push({
		front: b[e],
		back: b[t]
	});
	for (let e = r.bag.length - 1; e > 0; e--) {
		let t = P(r, e + 1);
		[r.bag[e], r.bag[t]] = [r.bag[t], r.bag[e]];
	}
	if (r.first = P(r, t.length), r.turn = r.first, r.actor = t[r.turn], r.maps.push({
		id: 0,
		kind: r.config.map,
		owner: null,
		rotation: 0
	}), r.config.board === "H" && r.maps.push({
		id: 1,
		kind: r.config.secondMap,
		owner: null,
		rotation: 0
	}), r.config.board === "G") for (let e of r.players) for (let t = 0; t < 2; t++) e.cells.push(re(r, r.bag.pop()));
	return r.config.dolphin && r.bag.splice(P(r, r.bag.length + 1), 0, "dolphin"), r.config.bottle && r.bag.splice(P(r, r.bag.length + 1), 0, "bottle"), { state: r };
}
function q(e, t, n, r) {
	r.length && (e.pending = t, e.actor = t.by, e.phase = n, e.targets = r);
}
function ae(e, t, n) {
	let r = e.maps.find((e) => e.id === n);
	r.owner = e.players.length === 1 && r.owner === t ? null : t, r.rotation = 0, I(e, t, "map");
}
function oe(e, t, n, r = !1) {
	let i = (r ? N(e, t).cells : N(e, t).tiles).find((e) => e.id === n);
	[i.face, i.back] = [i.back, i.face], i.known = !0, I(e, t, "flip", i.face), r || F(e, {
		kind: "character",
		by: t,
		id: n
	});
}
function se(e, t) {
	if (!K(e, t).length) return;
	let n = e.bag.pop();
	if (!n) {
		e.lastRound = !0;
		return;
	}
	if (typeof n != "string") {
		e.drawn = re(e, n), e.flipped = !1, e.actor = t, e.phase = "choose", I(e, t, "draw", e.drawn.face);
		return;
	}
	if (I(e, t, n), n === "dolphin") {
		let n = e.players.findIndex((e) => e.rid === t);
		F(e, ...e.players.map((t, r) => ({
			kind: "flip",
			by: e.players[(n + r) % e.players.length].rid
		})), {
			kind: "draw",
			by: t
		});
	} else {
		let n = x.filter((t) => t !== "base" && !e.maps.some((e) => e.kind === t));
		n.length && e.maps.push({
			id: e.maps.length,
			kind: n[P(e, n.length)],
			owner: t,
			rotation: 0
		}), F(e, {
			kind: "draw",
			by: t
		});
	}
}
function ce(e, t, n) {
	let r = N(e, t), i = r.tiles.find((e) => e.id === n);
	switch (i.face) {
		case "cartographer":
			F(e, {
				kind: "takeMap",
				by: t
			});
			break;
		case "navigator":
			L(e, t, 2 * ne(r, e.config.board));
			break;
		case "cook":
			L(e, t, r.tiles.filter((e) => e.row === i.row).length);
			break;
		case "gunner":
			L(e, t, 5);
			break;
		case "parrot":
			F(e, {
				kind: "draw",
				by: t
			});
			break;
		case "monkey": L(e, t, 1), F(e, {
			kind: "flip",
			by: t,
			targets: r.tiles.filter((e) => Math.abs(e.column - i.column) + Math.abs(e.row - i.row) === 1).map((e) => e.id)
		});
	}
}
function le(e, t) {
	let { by: n, column: r = 0 } = t, i = N(e, n), a = B(i, r), o = C[e.config.board].columns[r].bonus, s = `column:${r}`;
	if (a.length !== C[e.config.board].columns[r].rows.length || i.awarded.includes(s)) return;
	i.awarded.push(s);
	let c = !e.races.includes(s);
	e.races.push(s);
	let l = e.players.length === 1 && e.config.board === "B" ? i.awarded.filter((e) => e.startsWith("column:")).length <= 2 : c;
	if ((o === "map" || o === "sameMap" && V(a)) && F(e, {
		kind: "takeMap",
		by: n
	}), (o === "coins3" || o === "coins4" || o === "coins5") && L(e, n, Number(o.slice(-1))), o.startsWith("race")) {
		let t = Number(o.slice(4));
		L(e, n, l ? t : {
			0: 2,
			1: 0,
			2: 1,
			4: 2,
			5: 2,
			6: 3
		}[t]);
	}
	if (o === "completed2" && L(e, n, 2 * z(i.tiles, e.config.board)), o === "diversity" && L(e, n, new Set(a.map((e) => e.face)).size), o === "differentFlip" && H(a) && F(e, {
		kind: "flip",
		by: n
	}), (o === "sameDraw" && V(a) || o === "differentDraw" && H(a)) && F(e, {
		kind: "draw",
		by: n
	}), o === "neighbors") {
		let r = i.tiles.find((e) => e.id === t.id);
		L(e, n, new Set(i.tiles.filter((e) => e.id !== r.id && Math.abs(e.column - r.column) <= 1 && Math.abs(e.row - r.row) <= 1).map((e) => e.face)).size);
	}
	(o === "cellFlip" || o === "cellPlay") && F(e, {
		kind: o,
		by: n
	}), o === "coins3map" && (L(e, n, 3), F(e, {
		kind: "takeMap",
		by: n
	})), o === "passMaps" && F(e, {
		kind: "pass",
		by: n
	}), o === "firstFlip" && (l ? F(e, {
		kind: "flip",
		by: n
	}) : L(e, n, 2)), o === "bombs2" && L(e, n, 2 * W(i, e.config.board, e.maps)), o === "mapBomb" && (i.extraBomb = !0, F(e, {
		kind: "takeMap",
		by: n
	}));
}
function ue(e, t) {
	let n = N(e, t.by), r = e.config.board;
	if (r === "F") for (let t of [0, 1]) {
		let r = `row:${t}`, i = n.tiles.filter((e) => e.row === t);
		n.awarded.includes(r) || i.length !== (t === 0 ? 3 : 5) || (n.awarded.push(r), t === 0 ? V(i) && L(e, n.rid, 5) : (L(e, n.rid, e.races.includes(r) ? 2 : 5), e.races.push(r)));
	}
	if (r === "H" && n.tiles.filter((e) => e.row === 1).length === 5 && !n.awarded.includes("row:1") && (n.awarded.push("row:1"), L(e, n.rid, 2 * e.maps.filter((e) => e.owner === n.rid).length)), r === "I") {
		let r = n.tiles.find((e) => e.id === t.id);
		if (r.row === 2 && (r.column === 1 || r.column === 2) && e.players.length > 1) {
			let t = e.players.indexOf(n), i = e.players[(t + (r.column === 1 ? 1 : e.players.length - 1)) % e.players.length], a = Math.min(i.coins, i.tiles.filter((e) => e.face === r.face).length);
			i.coins -= a, L(e, n.rid, a);
		}
	}
}
function de(e, t) {
	let n = e.maps.find((e) => e.id === t.id);
	if (n.owner === t.by && ((n.kind === "base" || n.kind === "burning") && L(e, t.by, 1), n.kind === "cursed" && L(e, t.by, 2), n.kind === "gambler" && !e.gained[t.by] && L(e, t.by, 2), n.kind === "winds" && (L(e, t.by, [
		1,
		2,
		1,
		3
	][n.rotation]), n.rotation = (n.rotation + 1) % 4), n.kind === "kraken")) {
		let n = Math.max(...e.players.map((e) => e.coins)), r = e.players.filter((e) => e.rid !== t.by && e.coins === n && e.coins > 0);
		r.length && (e.pending = t, e.stealTargets = r.map((e) => e.rid), e.phase = "steal", e.actor = t.by);
	}
}
function fe(e) {
	e.phase = "resolve", e.pending = null, e.targets = [], e.stealTargets = [];
	let t = e.tasks.shift();
	if (!t) return;
	let { by: n } = t, r = N(e, n);
	switch (t.kind) {
		case "draw":
			se(e, n);
			break;
		case "character":
			ce(e, n, t.id);
			break;
		case "bonus":
			le(e, t);
			break;
		case "rows":
			ue(e, t);
			break;
		case "flip":
			R(e, n, "cursed") || q(e, t, "flip", t.targets ?? r.tiles.map((e) => e.id));
			break;
		case "takeMap": {
			let r = e.maps.filter((e) => e.owner === null), i = e.maps.filter((e) => e.owner !== n), a = r.length ? r : i.length ? i : e.players.length === 1 ? e.maps : [];
			a.length === 1 ? ae(e, n, a[0].id) : q(e, t, "map", a.map((e) => e.id));
			break;
		}
		case "cellFlip":
			R(e, n, "cursed") || q(e, t, "cellFlip", r.cells.map((e) => e.id));
			break;
		case "cellPlay":
			q(e, t, "cellPlay", r.cells.map((e) => e.id));
			break;
		case "pass":
			e.maps.some((e) => e.owner !== null) && (e.pending = t, e.phase = "direction", e.actor = n);
			break;
		case "endMaps": {
			let r = (t.remaining ?? e.maps.filter((e) => e.owner === n).map((e) => e.id)).filter((t) => e.maps.some((e) => e.id === t && e.owner === n));
			r.length === 1 ? F(e, {
				kind: "mapEffect",
				by: n,
				id: r[0]
			}) : r.length > 1 && q(e, {
				...t,
				remaining: r
			}, "mapOrder", r);
			break;
		}
		case "mapEffect":
			de(e, t);
			break;
		case "advance":
			if (e.players.some((t) => z(t.tiles, e.config.board) >= 4) && (e.lastRound = !0), e.lastRound && (e.turn + 1) % e.players.length === e.first) {
				e.phase = "done", I(e, n, "end");
				break;
			}
			e.turn = (e.turn + 1) % e.players.length, e.turn === e.first && e.round++, e.actor = e.players[e.turn].rid, e.phase = "draw", e.gained = {};
	}
	e.phase === "resolve" && (e.actor = e.players[e.turn].rid);
}
function pe(e, t, n) {
	let r = { code: "games.captainflip.errAction" };
	if (t.type === "tick") {
		if (e.phase !== "resolve") return { state: e };
		let t = structuredClone(e);
		do {
			let e = t.serial;
			if (fe(t), t.serial !== e) break;
		} while (t.phase === "resolve" && t.tasks.length);
		return { state: t };
	}
	if (e.phase === "done" || e.phase === "resolve" || e.actor !== n.by) return r;
	let i = structuredClone(e), a = N(i, n.by);
	if (t.type === "draw" && i.phase === "draw") i.tasks = [{
		kind: "endMaps",
		by: n.by
	}, {
		kind: "advance",
		by: n.by
	}], i.phase = "resolve", se(i, n.by);
	else if (t.type === "flipDraw" && i.phase === "choose" && i.drawn && !i.flipped && !R(i, n.by, "cursed")) [i.drawn.face, i.drawn.back] = [i.drawn.back, i.drawn.face], i.drawn.known = !0, i.flipped = !0, I(i, n.by, "flip", i.drawn.face);
	else if (t.type === "place" && i.phase === "choose" && i.drawn && K(i, n.by).includes(t.column)) {
		let e = t.column, r = C[i.config.board].columns[e], o = i.drawn;
		o.column = e, o.row = r.rows[B(a, e).length], a.tiles.push(o), i.drawn = null, r.bonus === "pay1" && a.coins--, I(i, n.by, "place", o.face), F(i, {
			kind: "character",
			by: n.by,
			id: o.id
		}, {
			kind: "bonus",
			by: n.by,
			column: e,
			id: o.id
		}, {
			kind: "rows",
			by: n.by,
			id: o.id
		});
	} else if (t.type === "flipTile" && i.phase === "flip" && i.targets.includes(t.id) && !R(i, n.by, "cursed")) i.phase = "resolve", i.pending = null, i.targets = [], oe(i, n.by, t.id);
	else if (t.type === "selectMap" && i.phase === "map" && i.targets.includes(t.id)) ae(i, n.by, t.id), i.phase = "resolve", i.pending = null, i.targets = [];
	else if (t.type === "cell" && (i.phase === "cellFlip" || i.phase === "cellPlay") && i.targets.includes(t.id)) {
		let e = i.phase === "cellFlip";
		if (i.phase = "resolve", i.pending = null, i.targets = [], e) oe(i, n.by, t.id, !0);
		else {
			let e = a.cells.findIndex((e) => e.id === t.id);
			i.drawn = a.cells.splice(e, 1)[0], i.flipped = !0, K(i, n.by).length ? i.phase = "choose" : a.cells.push(i.drawn), i.phase !== "choose" && (i.drawn = null);
		}
	} else if (t.type === "direction" && i.phase === "direction") {
		for (let e of i.maps) if (e.owner !== null) {
			let n = i.players.findIndex((t) => t.rid === e.owner);
			e.owner = i.players[(n + t.direction + i.players.length) % i.players.length].rid;
		}
		I(i, n.by, "pass"), i.phase = "resolve", i.pending = null;
	} else if (t.type === "mapOrder" && i.phase === "mapOrder" && i.targets.includes(t.id)) {
		let e = i.pending.remaining.filter((e) => e !== t.id);
		i.pending = null, i.targets = [], F(i, {
			kind: "mapEffect",
			by: n.by,
			id: t.id
		}, {
			kind: "endMaps",
			by: n.by,
			remaining: e
		});
	} else if (t.type === "steal" && i.phase === "steal" && i.stealTargets.includes(t.target)) N(i, t.target).coins--, L(i, n.by, 1), i.phase = "resolve", i.pending = null, i.stealTargets = [];
	else return r;
	return { state: i };
}
var J = (e) => ({
	id: e.id,
	face: e.face,
	back: e.known ? e.back : null,
	column: e.column,
	row: e.row
});
function me(e) {
	return {
		public: {
			config: e.config,
			phase: e.phase,
			players: e.players.map((e) => ({
				rid: e.rid,
				coins: e.coins,
				tiles: e.tiles.map(J),
				cells: e.cells.map(J),
				extraBomb: e.extraBomb
			})),
			turn: e.players[e.turn].rid,
			actor: e.actor,
			first: e.players[e.first].rid,
			round: e.round,
			lastRound: e.lastRound,
			bagCount: e.bag.length,
			drawn: e.drawn ? J(e.drawn) : null,
			canFlip: e.phase === "choose" && !e.flipped && !R(e, e.actor, "cursed"),
			legalColumns: e.phase === "choose" ? K(e, e.actor) : [],
			targets: e.targets,
			stealTargets: e.stealTargets,
			maps: e.maps.map((e) => ({ ...e })),
			scores: Object.fromEntries(e.players.map((t) => [t.rid, G(t, e.config, e.maps)])),
			log: e.log
		},
		private: {}
	};
}
function he(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t.rid, G(t, e.config, e.maps)])), n = (t) => Number(e.maps.some((e) => e.owner === t)), r = e.players.map((e) => e.rid).sort((e, r) => Number(t[e].eliminated) - Number(t[r].eliminated) || t[r].total - t[e].total || n(r) - n(e)), i = r.find((e) => !t[e].eliminated);
	return {
		phase: "done",
		ranking: r,
		winner: i ? r.filter((e) => !t[e].eliminated && t[e].total === t[i].total && n(e) === n(i)) : [],
		scores: Object.fromEntries(r.map((e) => [e, t[e].total]))
	};
}
var ge = {
	meta: D,
	saveCompatibility: { version: "1" },
	schemas: {
		action: te,
		publicView: j,
		privateView: M,
		config: O
	},
	setup: ie,
	reduce: pe,
	viewFor: me,
	status: he,
	nextTickIn: (e) => e.phase === "resolve" ? 380 : null
}, Y = "#243c42";
function X({ x: e = 0, y: t = 0, r: n = 12, n: r }) {
	return /* @__PURE__ */ p("g", {
		transform: `translate(${e} ${t})`,
		children: [
			/* @__PURE__ */ f("circle", {
				cy: "1",
				r: n,
				fill: "#a88324",
				stroke: "#252b29",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ f("circle", {
				r: n,
				fill: "#f8d539",
				stroke: "#252b29",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ f("circle", {
				r: n - 2,
				fill: "none",
				stroke: "#fff19a",
				strokeWidth: "1"
			}),
			r === void 0 ? /* @__PURE__ */ f("path", {
				d: "M-3 -5 3 -5 -1 0 3 0 -3 6",
				fill: "none",
				stroke: "#9b7922",
				strokeWidth: "2"
			}) : /* @__PURE__ */ f("text", {
				y: "4",
				textAnchor: "middle",
				fontWeight: "900",
				fontSize: "13",
				fill: "#252b29",
				children: r
			})
		]
	});
}
function _e({ kind: e, x: t = 0, y: n = 0, size: r = 24 }) {
	let i = /* @__PURE__ */ f("path", {
		d: "M8 2H24V24H8Z",
		fill: "#fffdf1",
		stroke: "#222b29",
		strokeWidth: "1.5"
	});
	return /* @__PURE__ */ p("g", {
		transform: `translate(${t} ${n}) scale(${r / 32})`,
		children: [
			(e === "map" || e === "maps") && /* @__PURE__ */ p("g", {
				stroke: "#38372b",
				strokeWidth: "1.5",
				strokeLinejoin: "round",
				fill: "#fff0b5",
				children: [
					e === "maps" && /* @__PURE__ */ f("path", { d: "M10 3H28Q32 5 28 9L26 29H11L9 24Z" }),
					/* @__PURE__ */ f("path", { d: "M5 3Q1 3 3 9L6 12 8 26Q3 23 3 28Q3 31 9 30H22Q27 29 25 23L22 9Q29 10 28 5Q27 1 22 3Z" }),
					/* @__PURE__ */ f("path", {
						d: "M5 3Q3 8 7 9H23M8 26Q10 28 8 30",
						fill: "none"
					}),
					/* @__PURE__ */ f("path", {
						d: "M12 12q12 3 5 9t-2 6M9 11l5 4m0 -4-5 4",
						fill: "none",
						stroke: "#b96445",
						strokeDasharray: "1.5 1"
					})
				]
			}),
			(e === "flip" || e === "cellFlip") && /* @__PURE__ */ p("g", {
				stroke: "#222b29",
				fill: "#fffdf1",
				children: [
					e === "cellFlip" && /* @__PURE__ */ f("path", {
						d: "M12 9V5Q16 -2 21 5V9M8 9H25V30H8Z",
						strokeWidth: "2"
					}),
					e === "flip" && /* @__PURE__ */ f("rect", {
						x: "3",
						y: "3",
						width: "26",
						height: "26",
						rx: "2",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ p("g", {
						transform: e === "cellFlip" ? "translate(6 10) scale(.6)" : void 0,
						children: [/* @__PURE__ */ f("path", {
							d: "M8 13Q16 2 25 13M24 19Q16 30 7 19",
							fill: "none",
							strokeWidth: "3"
						}), /* @__PURE__ */ f("path", {
							d: "m7 7 0 9 9 -4m9 13 0 -9 -9 4",
							fill: "#222b29",
							stroke: "none"
						})]
					})
				]
			}),
			e === "recruit" && /* @__PURE__ */ p("g", {
				fill: "#222b29",
				children: [/* @__PURE__ */ f("path", { d: "m10 2 4 2 5 -3 4 3 -4 6Q29 18 28 25Q27 31 16 31T4 25Q3 18 12 10Z" }), /* @__PURE__ */ f("path", {
					d: "M7 16h18m-9 -9v20",
					stroke: "#fffdf1",
					strokeWidth: "3"
				})]
			}),
			(e === "same" || e === "different") && /* @__PURE__ */ p("g", { children: [
				i,
				/* @__PURE__ */ f("path", {
					d: "m5 7 11 -7 11 7-11 -3Z M5 24l11 8 11-8-11 4Z",
					fill: "#222b29"
				}),
				/* @__PURE__ */ f("path", {
					d: "M11 11h10m-10 6h10",
					stroke: "#222b29",
					strokeWidth: "2.2"
				}),
				e === "different" && /* @__PURE__ */ f("path", {
					d: "m19 8 -7 12",
					stroke: "#222b29",
					strokeWidth: "2"
				})
			] }),
			e === "column" && /* @__PURE__ */ p("g", {
				fill: "#fffdf1",
				stroke: "#222b29",
				strokeWidth: "1.3",
				children: [
					/* @__PURE__ */ f("rect", {
						x: "7",
						y: "1",
						width: "18",
						height: "30",
						rx: "1"
					}),
					[
						4,
						11,
						18
					].map((e) => /* @__PURE__ */ f("rect", {
						x: "10",
						y: e,
						width: "12",
						height: "5",
						fill: "#9a9e91"
					}, e)),
					/* @__PURE__ */ f("path", {
						d: "m11 29 5-5 5 5",
						fill: "#222b29"
					})
				]
			}),
			e === "neighbors" && /* @__PURE__ */ p("g", { children: [i, /* @__PURE__ */ f("path", {
				d: "M12 11h8m-8 6h8m-2-9-5 12M4 2v28m24-28v28M1 5l3-4 3 4m18 0 3-4 3 4M1 27l3 4 3-4m18 0 3 4 3-4",
				fill: "none",
				stroke: "#222b29",
				strokeWidth: "1.6"
			})] }),
			e === "cellPlay" && /* @__PURE__ */ p("g", {
				fill: "none",
				stroke: "#222b29",
				strokeWidth: "2.5",
				strokeLinecap: "round",
				children: [/* @__PURE__ */ f("circle", {
					cx: "11",
					cy: "7",
					r: "5"
				}), /* @__PURE__ */ f("path", { d: "m14 12 10 16m-7-11 5-3m-1 10 4-2M8 5l5 4M9 3l5 4" })]
			}),
			e === "pass" && /* @__PURE__ */ f("g", {
				fill: "#222b29",
				children: /* @__PURE__ */ f("path", { d: "m2 16 10-8v5h6v6h-6v5Zm28 0-10-8v5h-6v6h6v5Z" })
			}),
			e === "bomb" && /* @__PURE__ */ f(Z, {
				x: 15,
				y: 20,
				size: 1.1
			}),
			e === "sextant" && /* @__PURE__ */ f(Q, {
				x: 16,
				y: 17
			}),
			e === "row" && /* @__PURE__ */ p("g", {
				fill: "#fffdf1",
				stroke: "#222b29",
				strokeWidth: "1.4",
				children: [/* @__PURE__ */ f("rect", {
					x: "7",
					y: "7",
					width: "18",
					height: "18"
				}), /* @__PURE__ */ f("path", {
					d: "M1 16h6m18 0h6M5 12l-4 4 4 4m22-8 4 4-4 4",
					fill: "none"
				})]
			}),
			e === "clearAbove" && /* @__PURE__ */ p("g", {
				stroke: "#222b29",
				strokeWidth: "2.5",
				children: [
					/* @__PURE__ */ f("rect", {
						x: "6",
						y: "1",
						width: "20",
						height: "15",
						rx: "1",
						fill: "#fffdf1"
					}),
					/* @__PURE__ */ f("path", {
						d: "m10 4 12 9m0-9-12 9",
						stroke: "#c82e22"
					}),
					/* @__PURE__ */ f("path", {
						d: "m7 29 9-10 9 10m-9-10v13",
						fill: "none"
					})
				]
			}),
			e === "safeCross" && /* @__PURE__ */ p("g", {
				stroke: "#222b29",
				strokeWidth: "1.8",
				children: [
					/* @__PURE__ */ f("path", { d: "M3 16h26M16 3v26" }),
					/* @__PURE__ */ f("circle", {
						cx: "16",
						cy: "16",
						r: "8",
						fill: "#fffdf1"
					}),
					/* @__PURE__ */ f("path", {
						d: "m11 11 10 10m0-10-10 10",
						stroke: "#c82e22",
						strokeWidth: "2.5"
					})
				]
			})
		]
	});
}
function Z({ x: e = 0, y: t = 0, size: n = 1 }) {
	return /* @__PURE__ */ p("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ f("path", {
				d: "M2 -9 5 -14 10 -13 12 -17",
				stroke: Y,
				fill: "none",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("path", {
				d: "m11 -18 3 -3m0 4 4 -1m-7 -3 -1 -3",
				stroke: "#e1a330",
				strokeWidth: "1.7"
			}),
			/* @__PURE__ */ f("circle", {
				r: "10",
				fill: Y
			}),
			/* @__PURE__ */ f("path", {
				d: "M-6 -3q2 -4 6 -3",
				fill: "none",
				stroke: "#80939a",
				strokeWidth: "2"
			})
		]
	});
}
function Q({ x: e = 0, y: t = 0 }) {
	return /* @__PURE__ */ p("g", {
		transform: `translate(${e} ${t})`,
		stroke: Y,
		strokeWidth: "2.3",
		fill: "none",
		children: [/* @__PURE__ */ f("path", { d: "M0 -13 -13 11Q0 18 13 11Z M0 -13 0 14 M-10 6Q0 11 10 6 M0 -9 11 -9" }), /* @__PURE__ */ f("circle", {
			cy: "-13",
			r: "2.8",
			fill: "#d3ae59"
		})]
	});
}
function ve({ role: e }) {
	if (e === "monkey") return /* @__PURE__ */ p("g", {
		stroke: Y,
		strokeWidth: "1.8",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M72 79C92 88 95 60 82 58C70 54 69 68 80 68",
				fill: "none",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ f("path", {
				d: "M24 82C25 64 42 61 58 65L74 85",
				fill: "#865438"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "23",
				cy: "41",
				r: "11",
				fill: "#ae7751"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "75",
				cy: "41",
				r: "11",
				fill: "#ae7751"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "23",
				cy: "41",
				r: "6",
				fill: "#e7b487"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "75",
				cy: "41",
				r: "6",
				fill: "#e7b487"
			}),
			/* @__PURE__ */ f("path", {
				d: "M25 50C15 24 33 10 48 14C65 6 85 30 72 55L64 65 35 65Z",
				fill: "#855536"
			}),
			/* @__PURE__ */ f("path", {
				d: "M31 31C39 25 46 31 49 36C55 25 68 28 69 41L65 60Q49 73 32 58Z",
				fill: "#efc194"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "48",
				cy: "51",
				rx: "19",
				ry: "12",
				fill: "#f6caa0"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "48",
				cy: "45",
				rx: "5",
				ry: "3",
				fill: Y
			}),
			/* @__PURE__ */ f("path", {
				d: "M36 39q3 -5 6 0m13 0q3 -5 6 0 M38 54q10 10 19 -1",
				fill: "none",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M28 24Q49 5 72 23L72 30Q50 19 26 32Z",
				fill: "#d57859"
			}),
			/* @__PURE__ */ f("path", {
				d: "m66 24 15 -4 -3 13 -9 -6",
				fill: "#d57859"
			}),
			/* @__PURE__ */ f("path", {
				d: "M29 79Q38 65 48 76L51 87 M58 74l5 12",
				fill: "none",
				stroke: "#cf9c6c",
				strokeWidth: "7"
			}),
			/* @__PURE__ */ f("path", {
				d: "m29 68 5 4m-8-1 5 4m39-9-5 6M31 35q5-5 10 1m13-1q6-5 12 0M26 43l-4-3m51 2 4-3",
				fill: "none",
				stroke: "#654630",
				strokeWidth: "1.1",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f(X, {
				x: 57,
				y: 78,
				r: 10
			}),
			/* @__PURE__ */ f("path", {
				d: "M42 77q5-4 8 0l2 7-3 3m-4-11 2 7m-3-6 1 6m17-9 3 6-2 4m-2-9 2 6",
				fill: "#e8b585",
				strokeWidth: "1",
				strokeLinecap: "round"
			})
		]
	});
	if (e === "parrot") return /* @__PURE__ */ p("g", {
		stroke: Y,
		strokeWidth: "1.8",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ f("path", {
				d: "m45 70 -9 26 14 -11 5 11 9 -28",
				fill: "#e9a04e"
			}),
			/* @__PURE__ */ f("path", {
				d: "M29 62C18 44 27 28 40 28C41 8 73 8 76 33L74 58C71 80 39 89 29 62Z",
				fill: "#3b9c8e"
			}),
			/* @__PURE__ */ f("path", {
				d: "M37 29C39 12 66 9 74 25L72 44C60 54 47 47 37 29Z",
				fill: "#d65b4f"
			}),
			/* @__PURE__ */ f("path", {
				d: "M38 42Q17 48 27 70Q37 81 53 68Q42 65 44 54",
				fill: "#53b4a4"
			}),
			/* @__PURE__ */ f("path", {
				d: "M56 60Q65 53 73 50Q72 72 56 77",
				fill: "#e8bc5e"
			}),
			/* @__PURE__ */ f("path", {
				d: "M70 30Q91 27 88 47L74 44Z",
				fill: "#f3c86e"
			}),
			/* @__PURE__ */ f("path", {
				d: "M87 43 75 48 75 39Z",
				fill: Y
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "64",
				cy: "30",
				rx: "7",
				ry: "9",
				fill: "#fff0ce"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "67",
				cy: "30",
				r: "2.2",
				fill: Y
			}),
			/* @__PURE__ */ f("path", {
				d: "M33 19Q51 0 68 13L70 17 45 20 34 26Z",
				fill: "#2a4e55"
			}),
			/* @__PURE__ */ f("path", {
				d: "m48 12 6 -2 5 4 -8 3Z",
				fill: "#f2dfb5"
			}),
			/* @__PURE__ */ f("path", {
				d: "m43 80 -1 6m15 -6 2 6M22 86 78 86",
				fill: "none",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M29 49q-4 9 4 14m-2-13q-1 9 6 13m-1-9q1 7 6 10M57 61q5 2 11-5m-11 11q6 0 11-6m-11 12q5-1 8-4M44 22q8-5 15-4",
				fill: "none",
				stroke: "#266659",
				strokeWidth: "1.2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M77 32q6 0 7 5M42 83l-5 3m20-3 5 3",
				fill: "none",
				stroke: "#fae2a0",
				strokeWidth: "1.1"
			})
		]
	});
	let t = {
		cartographer: "#2e7d96",
		navigator: "#805c91",
		cook: "#f8edd3",
		gunner: "#b45047",
		lookout: "#4d7391",
		carpenter: "#a27a51",
		swabby: "#398b7c"
	}, n = e === "navigator" ? "#b87d57" : e === "swabby" ? "#d49b70" : "#f2c59b", r, i;
	return e === "gunner" ? (i = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "M26 30 19 19 34 18 42 9 64 13 72 20 83 22 73 36Z",
			fill: "#303c44"
		}),
		/* @__PURE__ */ f("path", {
			d: "m42 20 15 -2 7 6 -5 5 -13 -1Z",
			fill: "#f8e6c3"
		}),
		/* @__PURE__ */ f("path", {
			d: "m46 22 10 4m0 -5 -8 6",
			stroke: Y
		})
	] }), r = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "m20 79 4 -22 11 3 6 22",
			fill: "#344f56"
		}),
		/* @__PURE__ */ f(Z, {
			x: 70,
			y: 78,
			size: 1.1
		}),
		/* @__PURE__ */ f("path", {
			d: "m33 65 12 16m21 -8 -9 10",
			stroke: n,
			strokeWidth: "8",
			strokeLinecap: "round"
		})
	] })) : e === "cartographer" ? (i = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "M27 31Q24 16 42 13L63 15 73 32",
			fill: "#764f36"
		}),
		/* @__PURE__ */ f("path", {
			d: "M22 32Q48 22 78 33L73 39 29 38Z",
			fill: "#aa7e51"
		}),
		/* @__PURE__ */ f("path", {
			d: "m62 19 4 -10 4 2 -3 12",
			fill: "#d8e7dd"
		})
	] }), r = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "M22 69 58 64 70 88 29 93Z",
			fill: "#f9e5af"
		}),
		/* @__PURE__ */ f("path", {
			d: "M26 69q-11 -9 -9 1l4 8m42 5q13 -5 9 4l-7 3",
			fill: "#f5dfa0"
		}),
		/* @__PURE__ */ f("path", {
			d: "M30 76q17 -9 21 3t10 4",
			fill: "none",
			stroke: "#c57856",
			strokeDasharray: "2 2"
		}),
		/* @__PURE__ */ f("path", {
			d: "m49 74 6 6m0 -6 -6 6",
			stroke: "#a94738"
		}),
		/* @__PURE__ */ f("path", {
			d: "m64 61 15 18",
			stroke: n,
			strokeWidth: "8",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ f(Q, {
			x: 76,
			y: 70
		})
	] })) : e === "navigator" ? (i = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "M26 32 23 18Q48 6 76 21L73 34Z",
			fill: "#784f72"
		}),
		/* @__PURE__ */ f("path", {
			d: "M27 24Q46 15 73 26",
			fill: "none",
			stroke: "#cfa85c",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "50",
			cy: "21",
			r: "4",
			fill: "#f0d185"
		})
	] }), r = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "M33 66 22 84 32 90 51 75",
			stroke: n,
			strokeWidth: "7",
			fill: "none",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ f("path", {
			d: "m29 77 43 -14 4 10 -44 15Z",
			fill: "#e3b85e"
		}),
		/* @__PURE__ */ f("path", {
			d: "m30 76 7 12m28 -25 4 13",
			stroke: "#705e45",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "74",
			cy: "68",
			r: "7",
			fill: "#77b7c1"
		})
	] })) : e === "cook" ? (i = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
		d: "M27 31 26 22C9 17 19 -1 33 8C42 -7 56 -4 60 6C76 -2 90 16 75 24L73 34Z",
		fill: "#fff5dc"
	}), /* @__PURE__ */ f("path", {
		d: "M27 26Q49 21 73 29L73 35 28 34Z",
		fill: "#ded5bc"
	})] }), r = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "M22 75Q37 67 53 76L51 86 28 86Z",
			fill: "#5c6a66"
		}),
		/* @__PURE__ */ f("path", {
			d: "M22 75Q37 85 53 76",
			fill: "none"
		}),
		/* @__PURE__ */ f("path", {
			d: "m24 80 -11 -5",
			strokeWidth: "5",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ f("path", {
			d: "m67 84 7 -28",
			stroke: "#927145",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ f("ellipse", {
			cx: "75",
			cy: "51",
			rx: "4",
			ry: "8",
			fill: "#ad8654"
		}),
		/* @__PURE__ */ f("path", {
			d: "m58 71 8 5 9 -2",
			stroke: n,
			strokeWidth: "7",
			fill: "none",
			strokeLinecap: "round"
		})
	] })) : e === "carpenter" ? (i = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "M26 31Q27 7 51 12Q72 9 77 33Z",
			fill: "#a57645"
		}),
		/* @__PURE__ */ f("path", {
			d: "M22 31Q47 26 80 32L75 36 26 36Z",
			fill: "#c59b59"
		}),
		/* @__PURE__ */ f("path", {
			d: "m40 16 2 12m15 -13 -2 12",
			stroke: "#7e5c38"
		})
	] }), r = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "m23 91 12 -35 6 3 -10 35",
			fill: "#cda169"
		}),
		/* @__PURE__ */ f("path", {
			d: "m23 53 21 3 4 10 -11 -4 -18 1Z",
			fill: "#8b9a98"
		}),
		/* @__PURE__ */ f("path", {
			d: "m61 68 14 6 -12 17 -13 -7Z",
			fill: "#d7b97c"
		}),
		/* @__PURE__ */ f("path", {
			d: "m65 73 4 4 -4 2 1 4 -6 1",
			fill: "none"
		}),
		/* @__PURE__ */ f("path", {
			d: "m34 74 15 10m14 -14 -6 6",
			stroke: n,
			strokeWidth: "8",
			strokeLinecap: "round"
		})
	] })) : e === "lookout" ? (i = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
		d: "M30 31 32 14 18 7 27 3 43 15 69 14 73 34Z",
		fill: "#4d6980"
	}), /* @__PURE__ */ f("path", {
		d: "M28 31 73 30 77 36 28 36Z",
		fill: "#d3ae68"
	})] }), r = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "m24 72 14 -10m22 1 14 -13",
			fill: "none",
			stroke: n,
			strokeWidth: "8",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ f("path", {
			d: "m48 48 33 -15 4 10 -31 16Z",
			fill: "#c9994d"
		}),
		/* @__PURE__ */ f("path", {
			d: "m73 35 5 12m-24 -4 6 12",
			stroke: "#f4d180",
			strokeWidth: "4"
		}),
		/* @__PURE__ */ f("ellipse", {
			cx: "82",
			cy: "38",
			rx: "4",
			ry: "7",
			fill: "#83bfce",
			transform: "rotate(-24 82 38)"
		})
	] })) : (i = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "M24 31Q38 10 62 15L75 31",
			fill: "#e3c59c"
		}),
		/* @__PURE__ */ f("path", {
			d: "M21 29 78 29 75 37 27 37Z",
			fill: "#f9ebc8"
		}),
		/* @__PURE__ */ f("path", {
			d: "M30 29Q47 22 65 27",
			fill: "none",
			stroke: "#358d84",
			strokeWidth: "3"
		})
	] }), r = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", {
			d: "m30 91 37 -45",
			stroke: "#9c703c",
			strokeWidth: "4"
		}),
		/* @__PURE__ */ f("path", {
			d: "m60 48 14 -13 10 9 -18 11Z",
			fill: "#d9bf8b"
		}),
		/* @__PURE__ */ f("path", {
			d: "m66 42 10 8m-5 -13 8 8",
			stroke: "#a38b60"
		}),
		/* @__PURE__ */ f("path", {
			d: "m28 71 12 7m22 -8 -10 12",
			stroke: n,
			strokeWidth: "8",
			strokeLinecap: "round"
		})
	] })), /* @__PURE__ */ p("g", {
		stroke: Y,
		strokeWidth: "1.7",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M20 91 23 72Q26 61 42 60L60 60Q76 62 80 78L82 92Z",
				fill: t[e]
			}),
			/* @__PURE__ */ f("path", {
				d: "M64 63Q75 67 77 79L79 91H65L61 72Z",
				fill: "#172f37",
				opacity: ".17",
				stroke: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "M31 66 34 89m36-19-3 19M23 79l11 3m33-3 11-3",
				fill: "none",
				strokeWidth: "1",
				strokeOpacity: ".6"
			}),
			e === "swabby" && /* @__PURE__ */ f("path", {
				d: "M24 76 75 76m-51 9 53 0",
				stroke: "#f5ebd2",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ f("path", {
				d: "M42 55 40 66Q49 74 59 65L57 53",
				fill: n
			}),
			/* @__PURE__ */ f("path", {
				d: "M43 57q5 8 14 4l1-7",
				fill: "#704b35",
				opacity: ".2",
				stroke: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "m39 62-7 7 12 7 6-7 7 7 10-9-8-5",
				fill: e === "cook" ? "#fff9e6" : e === "gunner" ? "#dbc6a0" : "#ead7ad",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ f("path", {
				d: "M50 72v17",
				fill: "none",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "54",
				cy: "78",
				r: "1",
				fill: "#e6c16d",
				strokeWidth: ".5"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "54",
				cy: "85",
				r: "1",
				fill: "#e6c16d",
				strokeWidth: ".5"
			}),
			/* @__PURE__ */ f("path", {
				d: "M28 33C23 22 36 14 51 17C73 16 79 34 71 52L65 60 34 53Z",
				fill: e === "navigator" ? "#343a3b" : "#73523b"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "29",
				cy: "42",
				rx: "4",
				ry: "7",
				fill: n
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "72",
				cy: "42",
				rx: "4",
				ry: "7",
				fill: n
			}),
			/* @__PURE__ */ f("path", {
				d: "M29 39q-3 0 0 7m43-7q3 0 0 6",
				fill: "none",
				stroke: "#986948",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ f("path", {
				d: "M31 31Q49 21 69 32L68 48Q66 64 51 65Q35 62 32 51Z",
				fill: n
			}),
			/* @__PURE__ */ f("path", {
				d: "M32 32q17-8 36 1l-1 4q-16-7-34 0ZM65 38q3 16-11 25l9-3 5-11Z",
				fill: "#734b32",
				opacity: ".14",
				stroke: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "m35 37 9 -1m13 0 8 2",
				strokeWidth: "2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "41",
				cy: "42",
				r: "1.8",
				fill: Y
			}),
			/* @__PURE__ */ f("circle", {
				cx: "60",
				cy: "42",
				r: "1.8",
				fill: Y
			}),
			/* @__PURE__ */ f("path", {
				d: "m51 41 -3 9 6 0 M44 55q7 4 13 -1",
				fill: "none",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "m35 47 6 1m19 0 5-1M47 59q5 2 9-1M46 52l3 1",
				fill: "none",
				stroke: "#b4825d",
				strokeWidth: ".7",
				strokeLinecap: "round"
			}),
			e === "navigator" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
				d: "m33 31 3 14-4 7m34-20-1 16 4 5",
				fill: "none",
				stroke: "#343a3b",
				strokeWidth: "3"
			}), /* @__PURE__ */ f("circle", {
				cx: "29",
				cy: "48",
				r: "2",
				fill: "#efcb66",
				strokeWidth: ".8"
			})] }),
			e === "swabby" && /* @__PURE__ */ f("path", {
				d: "m31 32 4 6m28-7 4 7m-25 26 7 8-4 8-5-9-4 3",
				fill: "#d4ab6a",
				strokeWidth: "1"
			}),
			e === "gunner" && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("path", {
					d: "m54 39 13 -2 -2 11 -10 -2Z",
					fill: Y
				}),
				/* @__PURE__ */ f("path", {
					d: "M33 50q7 7 17 3q10 6 17 -3L63 62 48 68 37 61Z",
					fill: "#5c4334"
				}),
				/* @__PURE__ */ f("path", {
					d: "m38 54 5 7m15 -6 -3 8",
					stroke: "#8c6547"
				})
			] }),
			e === "cook" && /* @__PURE__ */ f("path", {
				d: "M43 51q4 -5 8 0q5 -5 10 0q-11 8 -18 0",
				fill: "#695042"
			}),
			e === "cartographer" && /* @__PURE__ */ p("g", {
				fill: "none",
				strokeWidth: "1.3",
				children: [
					/* @__PURE__ */ f("circle", {
						cx: "40",
						cy: "42",
						r: "7"
					}),
					/* @__PURE__ */ f("circle", {
						cx: "61",
						cy: "42",
						r: "7"
					}),
					/* @__PURE__ */ f("path", { d: "M47 41h7" })
				]
			}),
			i,
			/* @__PURE__ */ f("path", {
				d: "M29 32q21-6 43 2",
				fill: "none",
				stroke: "#3b3630",
				strokeOpacity: ".35",
				strokeWidth: "1"
			}),
			r,
			e === "gunner" && /* @__PURE__ */ f("path", {
				d: "m42 76 4 2-2 6m17-6 3-2 3 3m-23-1-2 3m21-5 2 3",
				fill: n,
				strokeWidth: ".8",
				strokeLinecap: "round"
			}),
			e === "cartographer" && /* @__PURE__ */ f("path", {
				d: "m66 67 5 2-2 5m0-6 2 2m-1-1 2 2",
				fill: n,
				strokeWidth: ".8",
				strokeLinecap: "round"
			}),
			e === "navigator" && /* @__PURE__ */ f("path", {
				d: "m30 79 6-2 3 4-1 6m-5-7 1 5m2-6 1 5",
				fill: n,
				strokeWidth: ".8",
				strokeLinecap: "round"
			}),
			e === "cook" && /* @__PURE__ */ f("path", {
				d: "m64 72 6-2 4 3-2 5m-4-7 1 5m1-5 1 4",
				fill: n,
				strokeWidth: ".8",
				strokeLinecap: "round"
			}),
			e === "carpenter" && /* @__PURE__ */ f("path", {
				d: "m38 76 5-1 6 5-2 5m-7-8 4 5m-2-6 4 5m12-8 4-2 3 3-3 4",
				fill: n,
				strokeWidth: ".8",
				strokeLinecap: "round"
			}),
			e === "lookout" && /* @__PURE__ */ f("path", {
				d: "m67 54 3-4 5 1-1 5m-5-5 3 3m-1-4 3 3",
				fill: n,
				strokeWidth: ".8",
				strokeLinecap: "round"
			}),
			e === "swabby" && /* @__PURE__ */ f("path", {
				d: "m40 74 5-1 4 4-2 5m-4-7 2 4m-1-5 3 4m11-3 3-4 4 2-2 5",
				fill: n,
				strokeWidth: ".8",
				strokeLinecap: "round"
			})
		]
	});
}
function $({ role: e }) {
	let t = e === "lookout" || e === "carpenter" || e === "swabby";
	return /* @__PURE__ */ p("svg", {
		viewBox: "0 0 100 100",
		className: "cf-crew-art",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("rect", {
				x: "1.5",
				y: "1.5",
				width: "97",
				height: "97",
				rx: "7",
				fill: ee[e],
				stroke: Y,
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M7 36Q23 3 70 7M7 40V17Q7 8 18 8",
				fill: "none",
				stroke: "#fff9df",
				strokeOpacity: ".4",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f(ve, { role: e }),
			/* @__PURE__ */ f("path", {
				d: "M3 81h94v10q0 7 -7 7H10q-7 0 -7 -7Z",
				fill: t ? "#e0e3d8" : "#ffe3a0",
				stroke: Y,
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ f(ye, { role: e })
		]
	});
}
function ye({ role: e }) {
	let t = (e, t) => /* @__PURE__ */ f(_e, {
		kind: e,
		x: t,
		y: 82,
		size: 15
	}), n = (e, t) => /* @__PURE__ */ f("g", {
		transform: `translate(${t} 89) scale(.6)`,
		children: /* @__PURE__ */ f(X, {
			r: 10,
			n: e
		})
	}), r = (e, t) => /* @__PURE__ */ f("text", {
		x: t,
		y: "93",
		textAnchor: "middle",
		fontSize: "11",
		fontWeight: "900",
		fill: "#222b29",
		children: e
	});
	return e === "cartographer" ? t("map", 42) : e === "gunner" ? /* @__PURE__ */ p(d, { children: [n(5, 38), t("bomb", 57)] }) : e === "navigator" ? /* @__PURE__ */ p(d, { children: [
		n(2, 32),
		r("×", 47),
		t("sextant", 54)
	] }) : e === "cook" ? /* @__PURE__ */ p(d, { children: [
		n(1, 32),
		r("×", 47),
		t("row", 54)
	] }) : e === "monkey" ? /* @__PURE__ */ p(d, { children: [
		n(1, 32),
		r("+", 47),
		t("flip", 54)
	] }) : e === "parrot" ? /* @__PURE__ */ p(d, { children: [t("recruit", 30), n(-1, 61)] }) : e === "lookout" ? /* @__PURE__ */ p(d, { children: [t("clearAbove", 30), n(4, 61)] }) : e === "carpenter" ? /* @__PURE__ */ p(d, { children: [t("safeCross", 30), n(3, 61)] }) : /* @__PURE__ */ f("text", {
		x: "50",
		y: "94",
		textAnchor: "middle",
		fill: Y,
		fontWeight: "900",
		fontSize: "13",
		children: "1·4·9·16·25"
	});
}
function be({ kind: e, rotation: t = 0 }) {
	return /* @__PURE__ */ p("svg", {
		viewBox: "0 0 100 110",
		"aria-hidden": !0,
		className: "cf-map-art",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M18 8Q8 8 9 20L16 27 13 88Q7 88 8 96Q9 102 19 101L82 98Q91 97 90 88L83 80 87 20Q92 5 78 6Z",
				fill: "#f3dfaa",
				stroke: Y,
				strokeWidth: "2.4"
			}),
			/* @__PURE__ */ f("path", {
				d: "M18 8q-4 11 2 14h65M16 90l63 -2q-5 9 1 10",
				fill: "none",
				stroke: "#b99558",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("g", {
				transform: `rotate(${t * 90} 50 53)`,
				children: e === "burning" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
					d: "M20 34 26 20 32 29 40 12 48 28 60 15 66 33 77 20 82 39",
					fill: "#dc7150",
					stroke: Y,
					strokeWidth: "1.5"
				}), /* @__PURE__ */ f(Z, {
					x: 51,
					y: 56,
					size: 1.7
				})] }) : e === "kraken" ? /* @__PURE__ */ p("g", {
					fill: "none",
					stroke: "#6c6b87",
					strokeWidth: "9",
					strokeLinecap: "round",
					children: [/* @__PURE__ */ f("path", { d: "M26 69C68 86 76 48 62 39S28 56 49 59 66 42 47 37 20 48 28 58" }), /* @__PURE__ */ f("path", { d: "M68 71q21 -1 14 -17" })]
				}) : e === "cursed" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
					d: "M30 40q19 -20 39 0M69 59q-19 20 -39 0m0 -9V35m39 13v16",
					fill: "none",
					stroke: Y,
					strokeWidth: "4"
				}), /* @__PURE__ */ f("path", {
					d: "M26 30 77 77M75 29 27 78",
					stroke: "#b94e3e",
					strokeWidth: "6"
				})] }) : e === "gambler" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("rect", {
					x: "29",
					y: "32",
					width: "42",
					height: "42",
					rx: "6",
					fill: "#f8efda",
					stroke: Y,
					strokeWidth: "2",
					transform: "rotate(12 50 53)"
				}), /* @__PURE__ */ p("g", {
					fill: Y,
					children: [
						/* @__PURE__ */ f("circle", {
							cx: "39",
							cy: "43",
							r: "3"
						}),
						/* @__PURE__ */ f("circle", {
							cx: "60",
							cy: "49",
							r: "3"
						}),
						/* @__PURE__ */ f("circle", {
							cx: "49",
							cy: "54",
							r: "3"
						}),
						/* @__PURE__ */ f("circle", {
							cx: "36",
							cy: "64",
							r: "3"
						}),
						/* @__PURE__ */ f("circle", {
							cx: "58",
							cy: "68",
							r: "3"
						})
					]
				})] }) : e === "winds" ? /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ f("path", {
						d: "M50 26 56 47 78 53 57 59 50 80 44 59 22 53 43 47Z",
						fill: "#497f8a",
						stroke: Y,
						strokeWidth: "1.6"
					}),
					/* @__PURE__ */ f("path", {
						d: "m50 26 0 27 7 -6Z",
						fill: "#f4cf78"
					}),
					/* @__PURE__ */ f("circle", {
						cx: "50",
						cy: "53",
						r: "6",
						fill: "#e1b65b"
					})
				] }) : /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ f("path", {
						d: "M26 64q11 -24 23 -12t22 -16",
						fill: "none",
						stroke: "#a9704b",
						strokeWidth: "3",
						strokeDasharray: "4 3"
					}),
					/* @__PURE__ */ f("path", {
						d: "m57 35 17 13m-1 -15 -14 18",
						stroke: "#b45440",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ f("path", {
						d: "m25 36 8 -7 9 8 -8 9Z",
						fill: "#b7c6a0"
					})
				] })
			})
		]
	});
}
function xe() {
	return /* @__PURE__ */ p("svg", {
		viewBox: "0 0 140 145",
		"aria-hidden": !0,
		className: "cf-bag-art",
		children: [
			/* @__PURE__ */ f("ellipse", {
				cx: "71",
				cy: "132",
				rx: "51",
				ry: "8",
				fill: "#102f3c",
				opacity: ".15"
			}),
			/* @__PURE__ */ f("path", {
				d: "M49 32 38 7 63 16 77 4 87 21 109 16 93 40C130 86 128 128 91 133L44 131C9 127 9 86 49 32Z",
				fill: "#d4b381",
				stroke: Y,
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M43 29q23 14 53 1L94 43Q66 51 43 40Z",
				fill: "#986b47",
				stroke: Y,
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("path", {
				d: "M47 44Q33 72 34 103m57 -58q14 20 17 47M46 18l10 14m20 -17 -4 18m19 -8 -8 11",
				fill: "none",
				stroke: "#ac875c",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M45 42q24 4 52 -5l16 16m-21 -17 13 -10",
				stroke: "#5c6250",
				strokeWidth: "3",
				fill: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "m50 91 19 -32 19 32 -19 17Z",
				fill: "#faf0cd",
				stroke: Y,
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("path", {
				d: "m58 80 22 15m-2 -17 -19 16",
				stroke: Y,
				strokeWidth: "3"
			})
		]
	});
}
function Se({ raft: e = !1 }) {
	return /* @__PURE__ */ p("g", {
		stroke: Y,
		strokeWidth: "3",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ f("path", {
				d: e ? "M18 419 520 412 501 476 40 479Z" : "M23 347Q83 391 494 346L472 450Q286 535 84 466Z",
				fill: "#a67448"
			}),
			/* @__PURE__ */ f("path", {
				d: "M48 393Q280 436 488 389M64 421Q280 467 480 420M80 450Q282 493 466 446",
				fill: "none",
				stroke: "#684e39",
				strokeWidth: "3"
			}),
			!e && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("path", {
					d: "M271 403 271 55M429 374V138M124 389V193",
					stroke: "#7c5b3b",
					strokeWidth: "9"
				}),
				/* @__PURE__ */ f("path", {
					d: "M264 77Q196 119 180 218Q222 233 266 219Z",
					fill: "#ffefd2"
				}),
				/* @__PURE__ */ f("path", {
					d: "M278 78Q323 139 361 205Q322 223 278 221Z",
					fill: "#f5dfb5"
				}),
				/* @__PURE__ */ f("path", {
					d: "M422 154Q369 202 357 283L424 282Z M117 208 67 293 117 300Z",
					fill: "#e7cda4"
				}),
				/* @__PURE__ */ f("path", {
					d: "M269 57Q300 42 327 55L319 76 273 76Z",
					fill: "#2d525e"
				}),
				/* @__PURE__ */ f("path", {
					d: "m290 55 11 12m-1 -12 -11 12",
					stroke: "#fae6b9",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ f("path", {
					d: "M144 208 430 154M269 79 70 386M429 157 478 395",
					fill: "none",
					stroke: "#957854",
					strokeWidth: "1.5"
				}),
				[
					120,
					218,
					337,
					430
				].map((e) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("circle", {
					cx: e,
					cy: "430",
					r: "15",
					fill: "#e5be6b"
				}), /* @__PURE__ */ f("circle", {
					cx: e,
					cy: "430",
					r: "10",
					fill: "#385e66"
				})] }, e))
			] }),
			e && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("path", {
					d: "M84 437 480 443M90 460 471 464",
					stroke: "#775538",
					strokeWidth: "5"
				}),
				/* @__PURE__ */ f("path", {
					d: "M398 427V84",
					stroke: "#765638",
					strokeWidth: "10"
				}),
				/* @__PURE__ */ f("path", {
					d: "M395 100Q334 132 317 291L395 279Z",
					fill: "#f1dfb5"
				}),
				/* @__PURE__ */ f("path", {
					d: "M398 97Q424 89 451 105L445 123 399 120Z",
					fill: "#304c63"
				}),
				/* @__PURE__ */ f("path", {
					d: "M177 420V343Q213 318 253 341V421Z",
					fill: "#ad8051"
				}),
				/* @__PURE__ */ f("path", {
					d: "M177 366h76m-60 -32v87m45 -87v87",
					fill: "none",
					stroke: "#604b36"
				}),
				/* @__PURE__ */ f(X, {
					x: 317,
					y: 404,
					r: 16
				})
			] })
		]
	});
}
function Ce({ board: e }) {
	let t = C[e];
	return /* @__PURE__ */ p("g", { children: [
		/* @__PURE__ */ f("rect", {
			width: "540",
			height: "560",
			rx: "22",
			fill: t.sky
		}),
		/* @__PURE__ */ f("circle", {
			cx: "440",
			cy: "76",
			r: "42",
			fill: "#fff2be",
			opacity: ".65"
		}),
		/* @__PURE__ */ f("path", {
			d: "M0 63Q85 24 147 65T298 65M319 115Q383 90 454 117T560 109",
			fill: "none",
			stroke: "#fff1d2",
			strokeWidth: "20",
			opacity: ".45"
		}),
		(t.scenery === "ship" || t.scenery === "raft") && /* @__PURE__ */ f(Se, { raft: t.scenery === "raft" }),
		t.scenery === "kraken" && /* @__PURE__ */ p("g", {
			stroke: Y,
			strokeWidth: "3",
			fill: "#867496",
			children: [
				/* @__PURE__ */ f("path", {
					d: "M113 440C36 359 14 240 54 152C83 105 130 151 98 192C75 231 106 331 147 353M238 458C134 344 169 147 235 66C264 37 300 66 274 96C222 164 224 286 268 363M339 470C374 347 492 263 457 157C443 112 493 103 507 145C548 300 425 354 424 456",
					fill: "none",
					stroke: "#7e6a8b",
					strokeWidth: "38",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ f("path", { d: "M198 462Q188 321 295 291Q399 303 393 455Z" }),
				/* @__PURE__ */ f("path", {
					d: "M240 336q23 -11 33 13m30 -1q17 -17 36 -4",
					stroke: "#f5cb76",
					strokeWidth: "12",
					fill: "none"
				}),
				/* @__PURE__ */ f("path", {
					d: "M268 384Q296 406 330 379L320 415 283 422Z",
					fill: "#ead5ad"
				}),
				[
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ p("g", {
					fill: "#c3adc8",
					children: [
						/* @__PURE__ */ f("ellipse", {
							cx: 65 + e * 9,
							cy: 190 + e * 40,
							rx: "8",
							ry: "13"
						}),
						/* @__PURE__ */ f("ellipse", {
							cx: 255 - e * 9,
							cy: 111 + e * 46,
							rx: "8",
							ry: "14"
						}),
						/* @__PURE__ */ f("ellipse", {
							cx: 482 - e * 7,
							cy: 187 + e * 44,
							rx: "8",
							ry: "14"
						})
					]
				}, e))
			]
		}),
		(t.scenery === "island" || t.scenery === "skull") && /* @__PURE__ */ p("g", {
			stroke: Y,
			strokeWidth: "2.5",
			children: [
				/* @__PURE__ */ f("path", {
					d: "M40 483Q62 427 168 414L226 171 304 127 371 202 418 414Q478 410 515 480Z",
					fill: "#e9c48a"
				}),
				/* @__PURE__ */ f("path", {
					d: "m222 207 56 -46 64 45 36 211 -94 47 -85 -62Z",
					fill: "#f9dda4"
				}),
				t.scenery === "skull" ? /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ f("path", {
						d: "M171 304Q154 142 275 116Q400 130 399 300L367 341 355 401 196 401 186 348Z",
						fill: "#f2dfb3"
					}),
					/* @__PURE__ */ f("path", {
						d: "M201 278q20 -42 50 -19l-4 47 -44 8Zm102 -22q27 -24 52 13l-4 46 -41 -6Z",
						fill: "#526669"
					}),
					/* @__PURE__ */ f("path", {
						d: "m274 298 -12 39 27 0Z",
						fill: "#657573"
					}),
					/* @__PURE__ */ f("path", {
						d: "M225 356v37m35 -34v41m32 -41v41m31 -42v35",
						stroke: "#b19167",
						strokeWidth: "7"
					})
				] }) : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
					d: "M300 391V180M201 411V264",
					stroke: "#856c43",
					strokeWidth: "10"
				}), /* @__PURE__ */ f("path", {
					d: "M300 181Q251 151 216 187L286 187Q336 142 375 183L311 187Q354 190 378 225L304 193Q285 212 266 239Z M201 264Q166 230 133 258L191 268Q225 225 264 251L210 270 252 299 203 276 179 313Z",
					fill: "#398a75"
				})] }),
				/* @__PURE__ */ f("path", {
					d: "m134 417 272 -9 29 32 -308 9Z",
					fill: "#b98d56"
				}),
				/* @__PURE__ */ f("path", {
					d: "M142 426h273",
					stroke: "#70583c"
				})
			]
		}),
		t.scenery === "submarine" && /* @__PURE__ */ p("g", {
			stroke: Y,
			strokeWidth: "3",
			children: [
				/* @__PURE__ */ f("path", {
					d: "M65 313Q26 327 34 423Q50 476 133 476H450Q516 448 506 368Q497 315 446 313Z",
					fill: "#b99560"
				}),
				/* @__PURE__ */ f("path", {
					d: "M218 313V229Q269 199 331 228V313",
					fill: "#c1b17f"
				}),
				/* @__PURE__ */ f("path", {
					d: "M310 227V92Q324 72 360 86L353 106 332 108V228",
					fill: "#c9b784"
				}),
				/* @__PURE__ */ f("path", {
					d: "M83 337H463M82 450H462",
					stroke: "#806e51",
					strokeWidth: "4"
				}),
				[
					101,
					201,
					301,
					401
				].map((e) => /* @__PURE__ */ p("g", { children: [
					/* @__PURE__ */ f("circle", {
						cx: e,
						cy: "388",
						r: "30",
						fill: "#d2b776"
					}),
					/* @__PURE__ */ f("circle", {
						cx: e,
						cy: "388",
						r: "20",
						fill: "#589ba3"
					}),
					/* @__PURE__ */ f("path", {
						d: `M${e - 13} 382q9 -14 21 -6`,
						stroke: "#b8dada",
						fill: "none",
						strokeWidth: "3"
					})
				] }, e)),
				/* @__PURE__ */ f("path", {
					d: "M40 365 10 351 12 433 46 412",
					fill: "#c4ad77"
				})
			]
		}),
		t.scenery === "prison" && /* @__PURE__ */ p("g", {
			stroke: Y,
			strokeWidth: "3",
			children: [
				/* @__PURE__ */ f("path", {
					d: "M47 462V130L77 105 108 130V462M159 459V207L204 182 244 207V459M350 463V112L390 83 432 111V463",
					fill: "#9aa9ad"
				}),
				/* @__PURE__ */ f("path", {
					d: "m35 133 44 -43 43 43Zm302 -20 53 -53 56 53Z",
					fill: "#426a7e"
				}),
				/* @__PURE__ */ f("path", {
					d: "M93 266H382V444H92Z",
					fill: "#a5b3ae"
				}),
				/* @__PURE__ */ f("path", {
					d: "M254 440V301Q291 273 320 301V440Z",
					fill: "#4a6571"
				}),
				/* @__PURE__ */ f("path", {
					d: "M268 303v136m17 -148v149m20 -145v145",
					stroke: "#d0c8a5",
					strokeWidth: "4"
				}),
				[
					177,
					222,
					347,
					402
				].map((e) => /* @__PURE__ */ f("path", {
					d: `M${e} 180v40m-8 -23h16`,
					stroke: "#526e7a"
				}, e)),
				/* @__PURE__ */ f("path", {
					d: "M17 475Q100 421 159 475T316 469 535 454",
					fill: "#bdc0a1"
				})
			]
		}),
		t.scenery === "observatory" && /* @__PURE__ */ p("g", {
			stroke: Y,
			strokeWidth: "3",
			children: [
				/* @__PURE__ */ f("path", {
					d: "M16 50H524V488H16Z",
					fill: "#c29262"
				}),
				/* @__PURE__ */ f("path", {
					d: "M28 65H510M28 454H510M81 50V485M468 50V485",
					stroke: "#805e43",
					strokeWidth: "13"
				}),
				[
					110,
					181,
					252,
					323,
					394
				].map((e) => /* @__PURE__ */ f("path", {
					d: `M20 ${e}H520`,
					stroke: "#af7c52",
					strokeWidth: "1.5"
				}, e)),
				/* @__PURE__ */ f("path", {
					d: "M235 419 326 171 371 189 279 433Z",
					fill: "#7e9b9b"
				}),
				/* @__PURE__ */ f("path", {
					d: "m306 171 17 -36 70 27 -17 37Z",
					fill: "#d4b277"
				}),
				/* @__PURE__ */ f("ellipse", {
					cx: "358",
					cy: "155",
					rx: "35",
					ry: "15",
					fill: "#accacf",
					transform: "rotate(23 358 155)"
				}),
				/* @__PURE__ */ f("path", {
					d: "m263 401 -64 79m65 -78 74 78m-72 -64V490",
					stroke: "#c9b385",
					strokeWidth: "10"
				}),
				/* @__PURE__ */ f("path", {
					d: "M129 349h64v80h-64Z",
					fill: "#b9a374"
				}),
				/* @__PURE__ */ f("path", {
					d: "M143 349v80m38 -80v80",
					stroke: "#756f54"
				})
			]
		}),
		/* @__PURE__ */ f("path", {
			d: "M0 493Q42 474 82 494T166 493 250 494 334 492 418 494 540 482V560H0Z",
			fill: t.sea
		}),
		/* @__PURE__ */ f("path", {
			d: "M13 517q32 -10 65 0m35 18q36 -10 74 -2m60 -19q31 -8 59 1m31 21q42 -12 79 -2m38 -20q27 -7 54 0",
			fill: "none",
			stroke: "#e7efcd",
			strokeWidth: "3",
			opacity: ".65"
		}),
		/* @__PURE__ */ f("rect", {
			x: "2",
			y: "2",
			width: "536",
			height: "556",
			rx: "20",
			fill: "none",
			stroke: Y,
			strokeWidth: "4"
		})
	] });
}
//#endregion
//#region src/games/captainflip/view-player.tsx
var we = {
	cartographer: "games.captainflip.effect.cartographer",
	navigator: "games.captainflip.effect.navigator",
	cook: "games.captainflip.effect.cook",
	gunner: "games.captainflip.effect.gunner",
	monkey: "games.captainflip.effect.monkey",
	parrot: "games.captainflip.effect.parrot",
	lookout: "games.captainflip.effect.lookout",
	carpenter: "games.captainflip.effect.carpenter",
	swabby: "games.captainflip.effect.swabby"
}, Te = {
	none: "games.captainflip.bonus.none",
	map: "games.captainflip.bonus.map",
	coins3: "games.captainflip.bonus.coins3",
	coins4: "games.captainflip.bonus.coins4",
	coins5: "games.captainflip.bonus.coins5",
	race1: "games.captainflip.bonus.race1",
	race2: "games.captainflip.bonus.race2",
	race6: "games.captainflip.bonus.race6",
	race0: "games.captainflip.bonus.race0",
	race4: "games.captainflip.bonus.race4",
	race5: "games.captainflip.bonus.race5",
	same6: "games.captainflip.bonus.same6",
	different4: "games.captainflip.bonus.different4",
	completed2: "games.captainflip.bonus.completed2",
	diversity: "games.captainflip.bonus.diversity",
	sameMap: "games.captainflip.bonus.sameMap",
	differentFlip: "games.captainflip.bonus.differentFlip",
	sameDraw: "games.captainflip.bonus.sameDraw",
	differentDraw: "games.captainflip.bonus.differentDraw",
	neighbors: "games.captainflip.bonus.neighbors",
	cellFlip: "games.captainflip.bonus.cellFlip",
	cellPlay: "games.captainflip.bonus.cellPlay",
	coins3map: "games.captainflip.bonus.coins3map",
	passMaps: "games.captainflip.bonus.passMaps",
	firstFlip: "games.captainflip.bonus.firstFlip",
	bombs2: "games.captainflip.bonus.bombs2",
	mapBomb: "games.captainflip.bonus.mapBomb",
	pay1: "games.captainflip.bonus.pay1"
}, Ee = {
	base: "games.captainflip.mapEffect.base",
	cursed: "games.captainflip.mapEffect.cursed",
	burning: "games.captainflip.mapEffect.burning",
	gambler: "games.captainflip.mapEffect.gambler",
	kraken: "games.captainflip.mapEffect.kraken",
	winds: "games.captainflip.mapEffect.winds"
}, De = {
	draw: "games.captainflip.drawPrompt",
	choose: "games.captainflip.choosePrompt",
	resolve: "games.captainflip.resolving",
	flip: "games.captainflip.flipPrompt",
	map: "games.captainflip.mapPrompt",
	direction: "games.captainflip.directionPrompt",
	cellFlip: "games.captainflip.cellFlipPrompt",
	cellPlay: "games.captainflip.cellPlayPrompt",
	mapOrder: "games.captainflip.orderPrompt",
	steal: "games.captainflip.stealPrompt",
	done: "games.captainflip.resultTitle"
}, Oe = {
	draw: "games.captainflip.log.draw",
	flip: "games.captainflip.log.flip",
	place: "games.captainflip.log.place",
	coins: "games.captainflip.log.coins",
	map: "games.captainflip.log.map",
	dolphin: "games.captainflip.log.dolphin",
	bottle: "games.captainflip.log.bottle",
	pass: "games.captainflip.log.pass",
	end: "games.captainflip.log.end"
};
function ke({ x: e, y: t, size: n = 86 }) {
	return /* @__PURE__ */ p("g", {
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ f("rect", {
				x: e - 2,
				y: t - 2,
				width: n + 4,
				height: n + 4,
				rx: "9",
				fill: "#fff7cb",
				fillOpacity: ".2",
				stroke: "#fff7ce",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ f("rect", {
				x: e - 2,
				y: t - 2,
				width: n + 4,
				height: n + 4,
				rx: "9",
				fill: "none",
				stroke: "#145e69",
				strokeWidth: "2.5",
				strokeDasharray: "8 5"
			}),
			/* @__PURE__ */ f("rect", {
				className: "cf-march",
				x: e - 2,
				y: t - 2,
				width: n + 4,
				height: n + 4,
				rx: "9",
				fill: "none",
				stroke: "#fff4b8",
				strokeWidth: "3",
				strokeDasharray: "8 5",
				children: /* @__PURE__ */ f("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: "-26",
					dur: "1.1s",
					repeatCount: "indefinite"
				})
			})
		]
	});
}
function Ae() {
	return /* @__PURE__ */ p("svg", {
		className: "cf-choice-outline",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("rect", {
				x: "3",
				y: "3",
				width: "94",
				height: "94",
				rx: "10",
				fill: "none",
				stroke: "#fff7ce",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ f("rect", {
				x: "3",
				y: "3",
				width: "94",
				height: "94",
				rx: "10",
				fill: "none",
				stroke: "#145e69",
				strokeWidth: "2",
				strokeDasharray: "8 5"
			}),
			/* @__PURE__ */ f("rect", {
				className: "cf-march",
				x: "3",
				y: "3",
				width: "94",
				height: "94",
				rx: "10",
				fill: "none",
				stroke: "#fff4b8",
				strokeWidth: "2",
				strokeDasharray: "8 5",
				children: /* @__PURE__ */ f("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: "-26",
					dur: "1.1s",
					repeatCount: "indefinite"
				})
			})
		]
	});
}
function je({ bonus: e }) {
	if (e === "coins3" || e === "coins4" || e === "coins5") return /* @__PURE__ */ f(X, {
		x: 43,
		y: 12,
		r: 10,
		n: Number(e.slice(-1))
	});
	if (e.startsWith("race")) {
		let t = Number(e.slice(4));
		return /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(X, {
			x: 30,
			y: 11,
			r: 10,
			n: t
		}), /* @__PURE__ */ f(X, {
			x: 57,
			y: 12,
			r: 7,
			n: {
				0: 2,
				1: 0,
				2: 1,
				4: 2,
				5: 2,
				6: 3
			}[t]
		})] });
	}
	let t = (e, t, n = 22) => /* @__PURE__ */ f(_e, {
		kind: e,
		x: t,
		y: 1,
		size: n
	}), n = (e, t) => /* @__PURE__ */ f("text", {
		x: t,
		y: "17",
		textAnchor: "middle",
		fontSize: "15",
		fontWeight: "900",
		fill: "#222b29",
		children: e
	});
	return e === "map" ? t("map", 32) : e === "same6" || e === "different4" ? /* @__PURE__ */ p(d, { children: [t(e === "same6" ? "same" : "different", 19), /* @__PURE__ */ f(X, {
		x: 57,
		y: 12,
		r: 10,
		n: e === "same6" ? 6 : 4
	})] }) : e === "completed2" || e === "diversity" ? /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f(X, {
			x: 19,
			y: 12,
			r: 10,
			n: e === "completed2" ? 2 : 1
		}),
		n("×", 39),
		t(e === "completed2" ? "column" : "different", 49)
	] }) : e === "sameMap" || e === "differentFlip" || e === "sameDraw" || e === "differentDraw" ? /* @__PURE__ */ p(d, { children: [t(e.startsWith("same") ? "same" : "different", 18), t(e === "sameMap" ? "map" : e === "differentFlip" ? "flip" : "recruit", 47)] }) : e === "neighbors" ? /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f(X, {
			x: 20,
			y: 12,
			r: 10,
			n: 1
		}),
		n("×", 40),
		t("neighbors", 50)
	] }) : e === "cellFlip" || e === "cellPlay" ? t(e, 32) : e === "coins3map" ? /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f(X, {
			x: 19,
			y: 12,
			r: 10,
			n: 3
		}),
		n("+", 39),
		t("map", 49)
	] }) : e === "passMaps" ? /* @__PURE__ */ p(d, { children: [t("pass", 17), t("maps", 45)] }) : e === "firstFlip" ? /* @__PURE__ */ p(d, { children: [t("flip", 18), /* @__PURE__ */ f(X, {
		x: 57,
		y: 12,
		r: 8,
		n: 2
	})] }) : e === "bombs2" ? /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f(X, {
			x: 19,
			y: 12,
			r: 10,
			n: 2
		}),
		n("×", 39),
		t("bomb", 49)
	] }) : e === "mapBomb" ? /* @__PURE__ */ p(d, { children: [t("map", 18), t("bomb", 47)] }) : e === "pay1" ? /* @__PURE__ */ f(X, {
		x: 43,
		y: 12,
		r: 10,
		n: -1
	}) : null;
}
function Me({ pub: e, rid: t, interactive: n = !1, send: i, onInspect: a, selected: o, onBonus: s }) {
	let c = r(), l = e.players.find((e) => e.rid === t), u = C[e.config.board], m = (e, t) => {
		(e.key === "Enter" || e.key === " ") && (e.preventDefault(), t());
	};
	return /* @__PURE__ */ p("svg", {
		viewBox: "0 0 540 560",
		className: "cf-board",
		role: "group",
		"aria-label": c(E[e.config.board]),
		children: [
			/* @__PURE__ */ f(Ce, { board: e.config.board }),
			/* @__PURE__ */ f("text", {
				x: "25",
				y: "29",
				fontSize: "16",
				fontWeight: "900",
				fill: "#243c42",
				children: c(E[e.config.board])
			}),
			u.columns.flatMap((t, r) => t.rows.map((u, d) => {
				let h = l.tiles.find((e) => e.column === r && e.row === u), g = 31 + r * 98, _ = 440 - u * 98, v = n && e.phase === "choose" && e.legalColumns.includes(r) && !h && d === l.tiles.filter((e) => e.column === r).length, y = n && e.phase === "flip" && h && e.targets.includes(h.id), b = () => {
					v ? i?.({
						type: "place",
						column: r
					}) : y ? i?.({
						type: "flipTile",
						id: h.id
					}) : h && a?.(h);
				}, x = v ? c("games.captainflip.placeLabel", { n: r + 1 }) : h ? c(w[h.face]) : "", S = e.config.board === "H" && r === 2 && u === 1 || e.config.board === "I" && (r === 0 || r === 2) && u === 0;
				return /* @__PURE__ */ p("g", { children: [
					/* @__PURE__ */ f("rect", {
						x: g,
						y: _,
						width: "86",
						height: "86",
						rx: "7",
						fill: "#fff4d7",
						fillOpacity: ".36",
						stroke: "#2d5155",
						strokeOpacity: ".58",
						strokeWidth: "1.5"
					}),
					S && !h && /* @__PURE__ */ f(Q, {
						x: g + 43,
						y: _ + 46
					}),
					e.config.board === "I" && r === 2 && u === 3 && !h && /* @__PURE__ */ f(Z, {
						x: g + 43,
						y: _ + 46,
						size: 1.8
					}),
					h && /* @__PURE__ */ f("g", {
						className: "cf-land",
						transform: `translate(${g} ${_})`,
						children: /* @__PURE__ */ f("svg", {
							width: "86",
							height: "86",
							viewBox: "0 0 100 100",
							children: /* @__PURE__ */ f($, { role: h.face })
						})
					}, `${h.id}:${h.face}`),
					o !== void 0 && o === h?.id && /* @__PURE__ */ f("rect", {
						x: g - 1,
						y: _ - 1,
						width: "88",
						height: "88",
						rx: "8",
						fill: "none",
						stroke: "#ffdf74",
						strokeWidth: "4"
					}),
					(v || y) && /* @__PURE__ */ f(ke, {
						x: g,
						y: _
					}),
					(h || v) && /* @__PURE__ */ p("g", {
						role: "button",
						tabIndex: 0,
						"aria-label": y ? c("games.captainflip.flipLabel", { role: x }) : x,
						onKeyDown: (e) => m(e, b),
						onClick: b,
						className: "cf-slot-hit",
						children: [/* @__PURE__ */ f("title", { children: x }), /* @__PURE__ */ f("rect", {
							x: g - 2,
							y: _ - 2,
							width: "90",
							height: "90",
							rx: "8",
							fill: "transparent"
						})]
					}),
					d === t.rows.length - 1 && t.bonus !== "none" && /* @__PURE__ */ p("g", {
						className: "cf-slot-hit",
						role: "button",
						tabIndex: 0,
						"aria-label": c(Te[t.bonus]),
						onClick: () => s?.(t.bonus),
						onKeyDown: (e) => m(e, () => s?.(t.bonus)),
						children: [
							/* @__PURE__ */ f("title", { children: c(Te[t.bonus]) }),
							/* @__PURE__ */ f("rect", {
								x: g - 1,
								y: _ - 20,
								width: "88",
								height: "24",
								rx: "5",
								fill: "#ffe1a0",
								stroke: "#725a3b",
								strokeWidth: "1"
							}),
							/* @__PURE__ */ f("g", {
								transform: `translate(${g} ${_ - 20})`,
								children: /* @__PURE__ */ f(je, { bonus: t.bonus })
							})
						]
					}),
					d === 0 && /* @__PURE__ */ f("path", {
						d: `m${g + 37} ${_ + 90} 6 -5 6 5`,
						fill: "none",
						stroke: "#edf0ce",
						strokeWidth: "2"
					})
				] }, `${r}:${u}`);
			})),
			e.config.board === "I" && l.extraBomb && /* @__PURE__ */ f(Z, {
				x: 503,
				y: 120,
				size: 1.2
			}),
			e.config.board === "F" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("g", {
				transform: "translate(441 490)",
				children: [/* @__PURE__ */ f(_e, {
					kind: "same",
					size: 22
				}), /* @__PURE__ */ f(X, {
					x: 38,
					y: 12,
					r: 10,
					n: 5
				})]
			}), /* @__PURE__ */ p("g", {
				transform: "translate(475 365)",
				children: [/* @__PURE__ */ f(X, {
					x: 0,
					y: 0,
					r: 10,
					n: 5
				}), /* @__PURE__ */ f(X, {
					x: 20,
					y: 1,
					r: 7,
					n: 2
				})]
			})] })
		]
	});
}
function Ne() {
	let e = r();
	return /* @__PURE__ */ f("div", {
		className: "cf-guide",
		children: b.map((t) => /* @__PURE__ */ p("div", {
			className: "cf-guide-row",
			children: [/* @__PURE__ */ f($, { role: t }), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("strong", { children: e(w[t]) }), /* @__PURE__ */ f("p", { children: e(we[t]) })] })]
		}, t))
	});
}
function Pe(e) {
	return /* @__PURE__ */ f(Fe, {
		...e,
		pub: e.public
	});
}
function Fe({ pub: e, members: t, myRid: d, send: m, review: h = !1 }) {
	let g = r(), [_, v] = n(null), [y, b] = n(null), [x, S] = n(!1), [ee, O] = n(!1), [te, k] = n(null), [A, j] = n(null), M = e.actor === d && !h, N = _ ?? (M ? e.actor : d), P = e.players.some((e) => e.rid === N) ? N : e.players[0].rid, F = e.players.find((e) => e.rid === P), I = (e) => t.find((t) => t.rid === e)?.name ?? e, L = [...F.tiles, ...F.cells].find((e) => e.id === y) ?? (e.drawn && e.actor === P ? e.drawn : null), R = e.maps.find((e) => e.id === te), B = e.scores[P], V = h ? g(E[e.config.board]) : e.phase === "resolve" ? g(De.resolve) : M ? g(De[e.phase]) : g("games.captainflip.waiting", { name: I(e.actor) }), H = M && P === e.actor;
	return /* @__PURE__ */ p(o, {
		adaptive: !0,
		scroll: !1,
		className: "cf-screen",
		actionsHeight: "cf-actions-slot",
		banner: /* @__PURE__ */ p("div", {
			className: "cf-banner",
			children: [/* @__PURE__ */ f(s, {
				text: V,
				chip: e.lastRound ? g("games.captainflip.finalRound") : g("games.captainflip.round", { n: e.round }),
				tone: M ? "accent" : "info",
				accent: D.accent
			}), /* @__PURE__ */ f(c, {
				members: t,
				myRid: d,
				variant: "medal",
				scroll: !0,
				adaptive: !0,
				onPick: (e) => {
					v(e), b(null);
				},
				picked: (e) => e === P,
				status: (t) => /* @__PURE__ */ p("span", {
					className: "cf-seat-value",
					children: [
						e.players.find((e) => e.rid === t)?.coins ?? 0,
						" ",
						/* @__PURE__ */ f("span", {
							"aria-hidden": !0,
							children: "◉"
						}),
						e.actor === t && !h ? " ◀" : ""
					]
				})
			})]
		}),
		actions: /* @__PURE__ */ p("div", {
			className: "cf-actions",
			children: [
				/* @__PURE__ */ f("div", {
					className: "cf-held",
					children: e.drawn ? /* @__PURE__ */ f("button", {
						"aria-label": g("games.captainflip.inspect"),
						onClick: () => {
							v(e.actor), b(null), O(!0);
						},
						className: "cf-held-tile",
						children: /* @__PURE__ */ f($, { role: e.drawn.face })
					}, `${e.drawn.id}:${e.drawn.face}`) : /* @__PURE__ */ f(xe, {})
				}),
				/* @__PURE__ */ p("div", {
					className: "cf-action-copy",
					children: [
						e.drawn && /* @__PURE__ */ f("strong", { children: g(w[e.drawn.face]) }),
						e.phase === "draw" && /* @__PURE__ */ f("button", {
							className: "btn-base cf-primary",
							disabled: !M,
							onClick: () => {
								v(e.actor), b(null), m({ type: "draw" });
							},
							children: g("games.captainflip.draw")
						}),
						e.phase === "choose" && /* @__PURE__ */ f("button", {
							className: "btn-base cf-primary",
							disabled: !M || !e.canFlip,
							onClick: () => {
								b(null), v(e.actor), m({ type: "flipDraw" });
							},
							children: g(e.canFlip ? "games.captainflip.flipDraw" : "games.captainflip.forced")
						}),
						e.phase === "direction" && /* @__PURE__ */ p("div", {
							className: "cf-choice-row",
							children: [/* @__PURE__ */ f("button", {
								className: "btn-base",
								disabled: !M,
								onClick: () => m({
									type: "direction",
									direction: 1
								}),
								children: g("games.captainflip.left")
							}), /* @__PURE__ */ f("button", {
								className: "btn-base",
								disabled: !M,
								onClick: () => m({
									type: "direction",
									direction: -1
								}),
								children: g("games.captainflip.right")
							})]
						}),
						e.phase === "steal" && /* @__PURE__ */ f("div", {
							className: "cf-choice-row",
							children: e.stealTargets.map((e) => /* @__PURE__ */ f("button", {
								className: "btn-base",
								disabled: !M,
								onClick: () => m({
									type: "steal",
									target: e
								}),
								children: I(e)
							}, e))
						}),
						![
							"draw",
							"choose",
							"direction",
							"steal"
						].includes(e.phase) && /* @__PURE__ */ f("span", {
							className: "cf-action-status",
							children: V
						})
					]
				}),
				/* @__PURE__ */ f("span", {
					className: "cf-bag-count",
					children: g("games.captainflip.bag", { n: e.bagCount })
				})
			]
		}),
		children: [
			/* @__PURE__ */ p("div", {
				className: "cf-table",
				"data-board": e.config.board,
				style: { "--cf-sea": C[e.config.board].sea },
				children: [
					/* @__PURE__ */ f(i, {
						kind: "sheen",
						base: "#e8e2ca",
						className: "absolute inset-0"
					}),
					/* @__PURE__ */ p("div", {
						className: "cf-board-area",
						children: [/* @__PURE__ */ p("div", {
							className: "cf-board-label",
							children: [
								/* @__PURE__ */ f("span", { children: I(P) }),
								/* @__PURE__ */ f("button", {
									onClick: () => S(!0),
									children: g("games.captainflip.crew")
								}),
								/* @__PURE__ */ f("span", { children: g("games.captainflip.columns", { n: z(F.tiles, e.config.board) }) })
							]
						}), /* @__PURE__ */ f("div", {
							className: "cf-board-frame",
							children: /* @__PURE__ */ f(Me, {
								pub: e,
								rid: P,
								interactive: H,
								send: m,
								onInspect: (e) => {
									b(e.id), O(!0);
								},
								selected: y ?? void 0,
								onBonus: j
							})
						})]
					}),
					/* @__PURE__ */ p("aside", {
						className: "cf-cockpit",
						children: [
							/* @__PURE__ */ p("div", {
								className: "cf-treasure",
								children: [
									/* @__PURE__ */ f("svg", {
										viewBox: "0 0 36 36",
										"aria-hidden": !0,
										children: /* @__PURE__ */ f(X, {
											x: 17,
											y: 16,
											r: 14
										})
									}),
									/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("span", { children: g("games.captainflip.coins") }), /* @__PURE__ */ f("b", { children: /* @__PURE__ */ f(u, { value: F.coins }) })] }),
									/* @__PURE__ */ p("div", {
										className: "cf-bombs",
										children: [/* @__PURE__ */ f("svg", {
											viewBox: "0 0 32 32",
											"aria-hidden": !0,
											children: /* @__PURE__ */ f(Z, {
												x: 14,
												y: 20
											})
										}), /* @__PURE__ */ p("span", {
											"aria-label": g("games.captainflip.bombs"),
											children: [B.bombs, "/3"]
										})]
									})
								]
							}),
							/* @__PURE__ */ p("div", {
								className: "cf-inspector",
								children: [/* @__PURE__ */ f("button", {
									className: "cf-guide-button",
									onClick: () => S(!0),
									children: g("games.captainflip.crew")
								}), L ? /* @__PURE__ */ p("div", {
									className: "cf-inspector-body",
									children: [/* @__PURE__ */ f("div", {
										className: "cf-inspector-art",
										children: /* @__PURE__ */ f($, { role: L.face })
									}), /* @__PURE__ */ p("div", { children: [
										/* @__PURE__ */ f("strong", { children: g(w[L.face]) }),
										/* @__PURE__ */ f("p", { children: g(we[L.face]) }),
										/* @__PURE__ */ f("small", { children: L.back ? g("games.captainflip.backKnown", { role: g(w[L.back]) }) : g("games.captainflip.backUnknown") })
									] })]
								}) : /* @__PURE__ */ p("div", {
									className: "cf-inspector-body",
									children: [/* @__PURE__ */ f(xe, {}), !h && /* @__PURE__ */ f("p", { children: g("games.captainflip.drawPrompt") })]
								})]
							}),
							F.cells.length > 0 && /* @__PURE__ */ p("div", {
								className: "cf-cells",
								children: [/* @__PURE__ */ f("span", { children: g("games.captainflip.cell") }), F.cells.map((t) => {
									let n = H && ["cellFlip", "cellPlay"].includes(e.phase) && e.targets.includes(t.id);
									return /* @__PURE__ */ p("button", {
										className: n ? "cf-cell cf-selectable" : "cf-cell",
										onClick: () => {
											n ? m({
												type: "cell",
												id: t.id
											}) : (b(t.id), O(!0));
										},
										"aria-label": g(w[t.face]),
										children: [/* @__PURE__ */ f($, { role: t.face }), n && /* @__PURE__ */ f(Ae, {})]
									}, t.id);
								})]
							}),
							/* @__PURE__ */ f("div", {
								className: "cf-map-row",
								children: e.maps.map((t) => {
									let n = M && (e.phase === "map" || e.phase === "mapOrder") && e.targets.includes(t.id);
									return /* @__PURE__ */ p("button", {
										className: `cf-map${n ? " cf-selectable" : ""}`,
										onClick: () => n ? m({
											type: e.phase === "mapOrder" ? "mapOrder" : "selectMap",
											id: t.id
										}) : k(t.id),
										title: `${g(T[t.kind])} · ${g(Ee[t.kind])}`,
										children: [
											/* @__PURE__ */ f(be, {
												kind: t.kind,
												rotation: t.rotation
											}),
											/* @__PURE__ */ f("span", { children: g(T[t.kind]) }),
											/* @__PURE__ */ f("small", { children: t.owner ? I(t.owner) : g("games.captainflip.center") }),
											n && /* @__PURE__ */ f(Ae, {})
										]
									}, t.id);
								})
							}),
							/* @__PURE__ */ f("div", {
								className: "cf-log",
								children: /* @__PURE__ */ f(l, {
									log: e.log,
									line: (e) => g(Oe[e.kind], {
										name: I(e.rid),
										role: e.role ? g(w[e.role]) : "",
										n: e.amount ?? 0
									})
								})
							})
						]
					})
				]
			}),
			/* @__PURE__ */ f(a, {
				open: x,
				onClose: () => S(!1),
				label: g("games.captainflip.crew"),
				title: g("games.captainflip.crew"),
				children: /* @__PURE__ */ f(Ne, {})
			}),
			/* @__PURE__ */ f(a, {
				open: ee && !!L,
				onClose: () => O(!1),
				label: g("games.captainflip.inspect"),
				title: L ? g(w[L.face]) : "",
				children: L && /* @__PURE__ */ p("div", {
					className: "cf-detail",
					children: [
						/* @__PURE__ */ f($, { role: L.face }),
						/* @__PURE__ */ f("p", { children: g(we[L.face]) }),
						/* @__PURE__ */ f("small", { children: L.back ? g("games.captainflip.backKnown", { role: g(w[L.back]) }) : g("games.captainflip.backUnknown") })
					]
				})
			}),
			/* @__PURE__ */ f(a, {
				open: !!R,
				onClose: () => k(null),
				label: g("games.captainflip.mapPrompt"),
				title: R ? g(T[R.kind]) : "",
				children: R && /* @__PURE__ */ p("div", {
					className: "cf-detail",
					children: [/* @__PURE__ */ f(be, {
						kind: R.kind,
						rotation: R.rotation
					}), /* @__PURE__ */ f("p", { children: g(Ee[R.kind]) })]
				})
			}),
			/* @__PURE__ */ f(a, {
				open: A !== null,
				onClose: () => j(null),
				label: g(E[e.config.board]),
				title: g(E[e.config.board]),
				children: A && /* @__PURE__ */ f("div", {
					className: "cf-detail",
					children: /* @__PURE__ */ f("p", { children: g(Te[A]) })
				})
			})
		]
	});
}
//#endregion
//#region src/games/captainflip/bot.ts
var Ie = {
	immediate: 1,
	future: 0,
	risk: 12,
	flipMargin: .3,
	mapValue: 3
};
function Le(e, t, n, r) {
	return n.face === "gunner" ? 5 : n.face === "cook" ? t.tiles.filter((e) => e.row === n.row).length : n.face === "navigator" ? 2 * ne(t, e.config.board) : n.face === "cartographer" ? e.maps.some((e) => e.owner === t.rid) && e.maps.length === 1 ? 0 : r.mapValue : n.face === "monkey" ? 1.4 : n.face === "parrot" ? 3.8 : 0;
}
function Re(e, t, n, r, i) {
	let a = C[e.config.board].columns[r], o = t.tiles.filter((e) => e.column === r).length, s = a.rows[o];
	if (s === void 0) return -Infinity;
	let c = {
		id: -99,
		face: n,
		back: null,
		column: r,
		row: s
	}, l = {
		...t,
		tiles: [...t.tiles, c]
	}, u = G(t, e.config, e.maps), d = G(l, e.config, e.maps).total - u.total + i.immediate * Le(e, l, c, i), f = W(l, e.config.board, e.maps);
	if (f >= 3 ? d -= 60 : f === 2 && n === "gunner" && (d -= i.risk), a.bonus === "pay1" && --d, o + 1 === a.rows.length) {
		let t = a.bonus;
		(t === "coins3" || t === "coins4" || t === "coins5") && (d += Number(t.slice(-1))), t.startsWith("race") && (d += Number(t.slice(4)) / 2), (t === "map" || t === "coins3map" || t === "mapBomb") && (d += i.mapValue + (t === "coins3map" ? 3 : 0)), t === "mapBomb" && f >= 2 && (d -= 60), t === "completed2" && (d += 2 * z(l.tiles, e.config.board)), t === "diversity" && (d += new Set(l.tiles.filter((e) => e.column === r).map((e) => e.face)).size), (t === "differentDraw" || t === "sameDraw") && (d += 1.5), t === "bombs2" && (d += f * 2), t === "neighbors" && (d += new Set(l.tiles.filter((e) => e.id !== c.id && Math.abs(e.column - r) <= 1 && Math.abs(e.row - s) <= 1).map((e) => e.face)).size), t === "cellPlay" && (d += 3);
	}
	if (i.future) {
		let s = a.rows.length - o - 1;
		n === "lookout" && (d -= i.future * Math.min(3.6, s * 1.1)), n === "gunner" && (d -= i.future * (l.tiles.filter((e) => e.face === "carpenter" && e.column === r).length + (f === 2 ? 2 : 0))), n === "swabby" && !t.tiles.some((e) => e.column === r && e.face === "swabby") && (d += i.future * 1.5), n === "cartographer" && (d += i.future * .5), n === "parrot" && (d += i.future * 1.1), z(l.tiles, e.config.board) >= 4 && !e.lastRound && u.total < 25 && (d -= i.future * 3);
	}
	return d;
}
function ze(e = Ie) {
	return ({ public: t }, n) => {
		if (t.actor !== n.rid || t.phase === "resolve" || t.phase === "done") return null;
		let r = t.players.find((e) => e.rid === n.rid), i = n.difficulty === "weak", a = (e, t) => e.reduce((e, n) => t(n) > t(e) ? n : e);
		if (t.phase === "draw") return { action: { type: "draw" } };
		if (t.phase === "choose" && t.drawn && t.legalColumns.length) {
			let n = i ? t.legalColumns[0] : a(t.legalColumns, (n) => Re(t, r, t.drawn.face, n, e));
			return !i && t.canFlip && b.filter((e) => e !== t.drawn.face).reduce((n, i) => n + Math.max(...t.legalColumns.map((n) => Re(t, r, i, n, e))), 0) / 8 > Re(t, r, t.drawn.face, n, e) + e.flipMargin ? { action: { type: "flipDraw" } } : { action: {
				type: "place",
				column: n
			} };
		}
		return t.phase === "flip" && t.targets.length ? { action: {
			type: "flipTile",
			id: i ? t.targets[0] : a(t.targets, (n) => {
				let i = r.tiles.find((e) => e.id === n), a = i.back ? [i.back] : b.filter((e) => e !== i.face);
				return a.reduce((a, o) => {
					let s = {
						...r,
						tiles: r.tiles.map((e) => e.id === n ? {
							...e,
							face: o
						} : e)
					};
					return a + G(s, t.config, t.maps).total - G(r, t.config, t.maps).total + Le(t, s, {
						...i,
						face: o
					}, e) - (W(s, t.config.board, t.maps) >= 3 ? 80 : 0);
				}, 0) / a.length;
			})
		} } : t.phase === "map" && t.targets.length ? { action: {
			type: "selectMap",
			id: a(t.targets, (e) => {
				let n = t.maps.find((t) => t.id === e);
				return n.kind === "burning" ? W(r, t.config.board, t.maps) >= 2 ? -50 : 5 : n.kind === "winds" ? 4.5 : n.kind === "cursed" ? 2 : 3;
			})
		} } : t.phase === "mapOrder" && t.targets.length ? { action: {
			type: "mapOrder",
			id: t.targets.find((e) => t.maps.find((t) => t.id === e)?.kind === "gambler") ?? t.targets[0]
		} } : t.phase === "cellFlip" || t.phase === "cellPlay" ? t.targets.length ? { action: {
			type: "cell",
			id: t.targets[0]
		} } : null : t.phase === "direction" ? { action: {
			type: "direction",
			direction: 1
		} } : t.phase === "steal" && t.stealTargets.length ? { action: {
			type: "steal",
			target: t.stealTargets[0]
		} } : null;
	};
}
var Be = ze(), Ve = [
	["coins", "games.captainflip.score.coins"],
	["swabbies", "games.captainflip.score.swabbies"],
	["lookouts", "games.captainflip.score.lookouts"],
	["carpenters", "games.captainflip.score.carpenters"],
	["parrots", "games.captainflip.score.parrots"],
	["board", "games.captainflip.score.board"],
	["maps", "games.captainflip.score.maps"]
];
function He({ result: e, public: t, members: i, myRid: a, onPlayAgain: o, onBackToLobby: s, hintCount: c }) {
	let l = t, u = r(), [d, _] = n(!0), v = (e) => i.find((t) => t.rid === e)?.name ?? e, y = e.ranking.length === 1, b = l.scores[e.ranking[0]].total, x = b <= 30 ? 0 : b <= 40 ? 1 : b <= 50 ? 2 : b <= 55 ? 3 : b <= 60 ? 4 : 5, S = e.winner.length === 0 ? u("games.captainflip.noWinner") : u("games.captainflip.victory", { name: e.winner.map(v).join(" · ") });
	return /* @__PURE__ */ p("div", {
		className: "cf-result",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ f(g, {}),
			/* @__PURE__ */ p("div", {
				className: "h-full",
				inert: d,
				children: [/* @__PURE__ */ f(Fe, {
					pub: l,
					members: i,
					myRid: a,
					send: () => {},
					review: !0
				}), /* @__PURE__ */ f("button", {
					className: "btn-base cf-reopen",
					onClick: () => _(!0),
					children: u("games.captainflip.showResult")
				})]
			}),
			/* @__PURE__ */ f("div", {
				className: "cf-result-shade",
				hidden: !d,
				children: /* @__PURE__ */ p("section", {
					className: "cf-result-paper",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": u("games.captainflip.resultTitle"),
					children: [
						/* @__PURE__ */ p("header", {
							className: "cf-result-header",
							children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("p", { children: u("games.captainflip.resultTitle") }), /* @__PURE__ */ f("h1", { children: y && e.winner.length ? /* @__PURE__ */ f(Ue, { rank: x }) : S })] }), /* @__PURE__ */ f("button", {
								"aria-label": u("games.captainflip.close"),
								onClick: () => _(!1),
								className: "cf-result-close",
								children: /* @__PURE__ */ f(h, { size: 23 })
							})]
						}),
						/* @__PURE__ */ p("div", {
							className: "cf-result-content",
							children: [
								/* @__PURE__ */ p("div", {
									className: "cf-result-emblem",
									children: [/* @__PURE__ */ f(xe, {}), /* @__PURE__ */ p("strong", { children: [e.scores?.[e.winner[0] ?? e.ranking[0]] ?? 0, /* @__PURE__ */ f("span", { children: u("games.captainflip.coins") })] })]
								}),
								c !== void 0 && /* @__PURE__ */ f("p", {
									className: "cf-result-note",
									children: u("session.hint.usedCount", { n: c })
								}),
								/* @__PURE__ */ f("div", {
									className: "cf-score-scroll",
									children: /* @__PURE__ */ p("table", {
										className: "cf-score-table",
										children: [/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {}), e.ranking.map((t) => /* @__PURE__ */ p("th", {
											"data-winner": e.winner.includes(t) || void 0,
											children: [/* @__PURE__ */ p("span", { children: [e.winner.includes(t) ? "⚑ " : "", v(t)] }), e.autopilot?.[t] ? /* @__PURE__ */ f("small", { children: u("session.autopilot.share", { n: Math.round(e.autopilot[t] * 100) }) }) : null]
										}, t))] }) }), /* @__PURE__ */ p("tbody", { children: [
											Ve.map(([t, n]) => /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: u(n) }), e.ranking.map((e) => /* @__PURE__ */ f("td", { children: Number(l.scores[e][t]) }, e))] }, t)),
											/* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: u("games.captainflip.bombs") }), e.ranking.map((e) => /* @__PURE__ */ p("td", {
												"data-eliminated": l.scores[e].eliminated || void 0,
												children: [l.scores[e].bombs, "/3"]
											}, e))] }),
											/* @__PURE__ */ p("tr", {
												className: "cf-score-total",
												children: [/* @__PURE__ */ f("th", { children: u("games.captainflip.total") }), e.ranking.map((e) => /* @__PURE__ */ f("td", { children: l.scores[e].eliminated ? /* @__PURE__ */ p("span", {
													className: "cf-exploded",
													children: [u("games.captainflip.eliminated"), /* @__PURE__ */ f("small", { children: l.scores[e].total })]
												}) : l.scores[e].total }, e))]
											})
										] })]
									})
								})
							]
						}),
						/* @__PURE__ */ p("footer", {
							className: "cf-result-footer",
							children: [/* @__PURE__ */ f("button", {
								className: "btn-quiet",
								onClick: () => _(!1),
								children: u("games.captainflip.review")
							}), o || s ? /* @__PURE__ */ p("div", {
								className: "cf-result-host",
								children: [o && /* @__PURE__ */ f(m, {
									label: u("session.result.playAgain"),
									confirmLabel: u("games.captainflip.confirmAgain"),
									onConfirm: o,
									className: "cf-result-again"
								}), s && /* @__PURE__ */ f(m, {
									label: u("session.result.backToLobby"),
									confirmLabel: u("games.captainflip.confirmLobby"),
									onConfirm: s
								})]
							}) : /* @__PURE__ */ f("p", { children: u("session.result.waitHost") })]
						})
					]
				})
			})
		]
	});
}
function Ue({ rank: e }) {
	let t = r();
	return /* @__PURE__ */ p(d, { children: [
		t("games.captainflip.solo"),
		" · ",
		t([
			"games.captainflip.soloRank0",
			"games.captainflip.soloRank1",
			"games.captainflip.soloRank2",
			"games.captainflip.soloRank3",
			"games.captainflip.soloRank4",
			"games.captainflip.soloRank5"
		][e])
	] });
}
//#endregion
//#region src/games/captainflip/options.tsx
function We({ value: e, onChange: t }) {
	let n = r(), i = O.safeParse(e), a = i.success ? i.data : O.parse(void 0);
	return /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ f(v, {
				title: n("games.captainflip.optBoard"),
				columns: 3,
				children: Object.keys(E).map((e) => /* @__PURE__ */ f(_, {
					name: "captainflip-board",
					value: e,
					checked: a.board === e,
					label: n(E[e]),
					accent: D.accent,
					onChange: () => t({
						...a,
						board: e
					})
				}, e))
			}),
			/* @__PURE__ */ f(v, {
				title: n("games.captainflip.optMap"),
				children: x.map((e) => /* @__PURE__ */ f(_, {
					name: "captainflip-map",
					value: e,
					checked: a.map === e,
					label: n(T[e]),
					accent: D.accent,
					onChange: () => t({
						...a,
						map: e
					})
				}, e))
			}),
			a.board === "H" && /* @__PURE__ */ f(v, {
				title: n("games.captainflip.optSecondMap"),
				children: x.map((e) => /* @__PURE__ */ f(_, {
					name: "captainflip-map2",
					value: e,
					checked: a.secondMap === e,
					label: n(T[e]),
					accent: D.accent,
					onChange: () => t({
						...a,
						secondMap: e
					})
				}, e))
			}),
			/* @__PURE__ */ p("fieldset", { children: [
				/* @__PURE__ */ f("legend", {
					className: "section-label",
					children: n("games.captainflip.optEvents")
				}),
				/* @__PURE__ */ f(y, {
					checked: a.dolphin,
					label: n("games.captainflip.dolphin"),
					accent: D.accent,
					onChange: () => t({
						...a,
						dolphin: !a.dolphin
					})
				}),
				/* @__PURE__ */ f(y, {
					checked: a.bottle,
					label: n("games.captainflip.bottle"),
					accent: D.accent,
					onChange: () => t({
						...a,
						bottle: !a.bottle
					})
				})
			] })
		]
	});
}
//#endregion
//#region src/games/captainflip/guide.tsx
function Ge() {
	return /* @__PURE__ */ f(Ne, {});
}
//#endregion
//#region .bgparty/cache/pack-entry/captainflip/entry.tsx
var Ke = {
	definition: ge,
	View: Pe,
	bot: Be,
	OverView: He,
	Options: We,
	Guide: Ge,
	locales: {
		zh: {
			name: "扬翻夺宝",
			desc: "招募海盗船员，翻面赌运，满载金币扬帆归航。",
			rules: "目标：\n你是海盗船长。轮流抽取双面角色板块，把船员放入冒险板，争取获得最多金币。所有人使用同一种冒险板。基础版适合2–5人；Kraken的官方单人规则适用于A–E板。\n准备：\n基础版使用A–D冒险板、72枚双面角色板块和基础藏宝图。九种角色在板块两面各出现16次，同一板块两面不同。每对角色有两枚板块。随机决定起始船长，之后按座位顺序行动。所有金币和已露出的板块公开，未翻开的背面不得查看。\n流程：\n抽取一枚板块，只看朝上的角色。可以保留，或者翻面一次；翻面后必须接受新角色。把它放入任一列最低的空格，不能越过本列空格。角色效果先结算，再结算该位置的板面奖励。缺格两边不相邻，斜角也不相邻。每个普通回合结束时，依次结算自己拥有的藏宝图。\n· 制图师：取得一张藏宝图。\n· 领航员：你的冒险板上每有一位制图师，获得2枚金币。\n· 厨师：此厨师所在行中每有一名角色，获得1枚金币，包括此厨师自己。\n· 炮手：立即获得5枚金币。终局时，你有至少3枚炸弹便被淘汰。\n· 猴子：获得1枚金币，然后翻转一枚与此猴子正交相邻的板块，并结算新角色的效果。没有相邻板块时，只获得金币。\n· 鹦鹉：立即再抽取并放置一枚船员板块，仍可选择翻面。终局时，每只鹦鹉扣除1枚金币。追加招募属于当前回合。追加招募不额外结算藏宝图。\n· 瞭望员：终局时，若此瞭望员在本列上方没有其他角色，获得4枚金币。\n· 木匠：终局时，若此木匠所在行和列均无炮手，获得3枚金币。爆弹岛上尚未被覆盖的板面炸弹也按炮手处理；其他额外炸弹不影响木匠。\n· 水手：终局时，统计至少有一名水手的列数，将该列数的平方作为金币奖励。此项按所有水手统一计分，不逐枚水手计分。\n· 翻转已放置板块只结算角色效果，不重新触发已领取的板面奖励；角色效果引发的额外招募和翻面先完成，再继续原板面奖励。\n冒险板：\n· A海盗船：完成第二列时，取得一张藏宝图；完成第三列时，获得5枚金币；完成第五列时，获得3枚金币。\n· B克拉肯：从左至右，最先完成第一至第五列的玩家，分别获得1、2、6、0、4枚金币；之后完成对应列的玩家，分别获得0、1、3、2、2枚金币。\n· C木筏：完成第一列时，取得一张藏宝图。终局时，若第二列已填满且所有角色相同，获得6枚金币；若第四列已填满且所有角色均不同，获得4枚金币。\n· D荒岛：完成第一列时，获得3枚金币。完成第二列时，冒险板上每有1列已经完成，就获得2枚金币；刚完成的第二列也计入。完成第三列时，按该列中每种不同角色获得1枚金币。在第五列放置板块前，须支付1枚金币；没有金币时，不能在该列放置板块。\n· E巨口之中（Kraken）：完成第一列和第五列时，分别获得4枚和3枚金币。完成第二列时，若该列角色全相同，取得一张藏宝图。完成第三列时，若该列角色全不同，翻转自己冒险板上的任一角色。完成第四列时，若该列角色全相同，追加招募一名船员。单人游戏中，再次取得已经持有的藏宝图时，将它放回中央；使用B板时，前两次完成列领取最先完成者的奖励，其余完成列领取后来完成者的奖励。\nIsla Bomba扩展：\nF–I板、五种新藏宝图及事件可分别组合，默认关闭。所有板面效果均在角色效果之后结算。\n· F潜艇：底行的3名角色全相同时，获得5枚金币。其上一行的5格最先填满时，获得5枚金币；后来填满时，获得2枚金币。完成第二列时，取得一张藏宝图。完成第三列时，按该格周围7格中每种不同角色获得1枚金币。完成第四列时，若该列4名角色全不同，追加招募一名船员。完成第五列时，获得3枚金币。\n· G监狱：准备阶段，每人抽取2枚板块放入牢房，不结算角色效果，也不查看背面。完成第一列时，可以翻转一枚牢房板块，不结算角色效果。完成第二列时，取得一张藏宝图。最先完成第三列的玩家获得5枚金币，后来完成者获得2枚金币。完成第四列或第五列时，释放一枚牢房板块，必须按当前朝向放入冒险板并结算角色效果。\n· H天文台：使用两张藏宝图。取得藏宝图时，优先拿取中央的图；中央没有图时，从其他玩家处取得一张。玩家可以持有多张图。未被覆盖的六分仪视为额外一位制图师。完成第一列时，取得一张藏宝图。完成第二列时，获得3枚金币并取得一张藏宝图。完成第三列时，决定将所有图向左或向右传递。最先完成第四列的玩家，可以翻转自己冒险板上的任一角色；后来完成者获得2枚金币。完成第五列时，获得3枚金币。填满五格所在行时，按每张持有的藏宝图获得2枚金币。\n· I爆弹岛：未被覆盖的两个六分仪视为额外制图师；未被覆盖的板面炸弹计入爆炸判定，也影响同行或同列木匠的计分。完成第二列时，取得一张藏宝图。完成第三列时，获得3枚金币。完成第四列时，按每枚可见炸弹获得2枚金币。完成第五列时，取得一张藏宝图，并永久增加一枚炸弹。两个眼窝位置分别从左侧和右侧邻座处偷取金币，数量等于对方冒险板上与本次所放角色相同的角色数量，最多取至对方金币用尽。藏宝图和第五列带来的额外炸弹不影响木匠。\n· 基础藏宝图：在你的回合结束时，获得1枚金币。\n· 诅咒图：持有此图时，不能翻转任何板块。在你的回合结束时，获得2枚金币。\n· 燃烧图：持有此图时，增加1枚炸弹。在你的回合结束时，获得1枚金币；终局时，额外获得5枚金币。此图的炸弹不影响木匠。\n· 赌徒图：在你的回合结束时，若你本回合尚未获得金币，获得2枚金币。\n· 克拉肯图：在你的回合结束时，从最富有的其他船长处偷取1枚金币。有多人并列最富有时，由你选择其中一人；若你严格比其他所有人都富有，则不偷取金币。\n· 四风图：在你的回合结束时，按此图当前朝向获得金币，然后将它顺时针旋转四分之一圈。四个朝向依次奖励1、2、1、3枚金币；取得此图时，将朝向重置为第一项。持有多张藏宝图时，可以选择它们的结算顺序。\n· 海豚事件：抽到后，从抽到者起，每人翻转自己一枚板块并结算效果；随后移除海豚，原抽取者继续招募。其他玩家此时不结算藏宝图。\n· 瓶中信：抽到者随机取得一张尚未使用的官方扩展藏宝图，移除瓶子，然后继续招募。空白自定义图不使用。诅咒图禁止的翻面效果跳过，其他效果照常。\n结束：\n有人完成至少4列时，完成本轮，使所有船长得到相同普通回合数；追加招募和角色效果仍结算完毕。终局按金币、船员、板面和藏宝图计算总分。至少3枚炸弹者淘汰，其余最高分者获胜；同分时持有藏宝图者优先，否则共享胜利。所有人均爆炸时，无人获胜。单人游戏根据最终金币数量确定评级：\n· 不超过30枚金币时，评级为见习船长。\n· 获得31至40枚金币时，评级为水手。\n· 获得41至50枚金币时，评级为老练水手。\n· 获得51至55枚金币时，评级为军官。\n· 获得56至60枚金币时，评级为海军上将。\n· 获得至少61枚金币时，评级为海上传奇。",
			role: {
				cartographer: "制图师",
				navigator: "领航员",
				cook: "厨师",
				gunner: "炮手",
				monkey: "猴子",
				parrot: "鹦鹉",
				lookout: "瞭望员",
				carpenter: "木匠",
				swabby: "水手"
			},
			effect: {
				cartographer: "取得一张藏宝图。",
				navigator: "你的冒险板上每有一位制图师，获得2枚金币。",
				cook: "此厨师所在行中每有一名角色，获得1枚金币，包括此厨师自己。",
				gunner: "立即获得5枚金币。终局时，你有至少3枚炸弹便被淘汰。",
				monkey: "获得1枚金币，然后翻转一枚与此猴子正交相邻的板块，并结算新角色的效果。没有相邻板块时，只获得金币。",
				parrot: "立即再抽取并放置一枚船员板块，仍可选择翻面。终局时，每只鹦鹉扣除1枚金币。追加招募属于当前回合。",
				lookout: "终局时，若此瞭望员在本列上方没有其他角色，获得4枚金币。",
				carpenter: "终局时，若此木匠所在行和列均无炮手，获得3枚金币。爆弹岛上尚未被覆盖的板面炸弹也按炮手处理；其他额外炸弹不影响木匠。",
				swabby: "终局时，统计至少有一名水手的列数，将该列数的平方作为金币奖励。此项按所有水手统一计分，不逐枚水手计分。"
			},
			board: {
				A: "A · 海盗船",
				B: "B · 克拉肯",
				C: "C · 木筏",
				D: "D · 荒岛",
				E: "E · 巨口之中",
				F: "F · 潜艇",
				G: "G · 监狱",
				H: "H · 天文台",
				I: "I · 爆弹岛"
			},
			map: {
				base: "基础图",
				cursed: "诅咒图",
				burning: "燃烧图",
				gambler: "赌徒图",
				kraken: "克拉肯图",
				winds: "四风图"
			},
			mapEffect: {
				base: "在你的回合结束时，获得1枚金币。",
				cursed: "持有此图时，不能翻转任何板块。在你的回合结束时，获得2枚金币。",
				burning: "持有此图时，增加1枚炸弹。在你的回合结束时，获得1枚金币；终局时，额外获得5枚金币。此图的炸弹不影响木匠。",
				gambler: "在你的回合结束时，若你本回合尚未获得金币，获得2枚金币。",
				kraken: "在你的回合结束时，从最富有的其他船长处偷取1枚金币。有多人并列最富有时，由你选择其中一人；若你严格比其他所有人都富有，则不偷取金币。",
				winds: "在你的回合结束时，按此图当前朝向获得金币，然后将它顺时针旋转四分之一圈。四个朝向依次奖励1、2、1、3枚金币；取得此图时，将朝向重置为第一项。"
			},
			optBoard: "冒险板",
			optMap: "藏宝图",
			optSecondMap: "第二张藏宝图（天文台）",
			optEvents: "事件板块",
			dolphin: "海豚",
			bottle: "瓶中信",
			draw: "抽取船员",
			flipDraw: "翻面",
			forced: "必须使用此面",
			choosePrompt: "选择一个登船位置",
			drawPrompt: "从袋中招募船员",
			resolving: "船员正在行动",
			flipPrompt: "选择要翻转的船员",
			mapPrompt: "选择一张藏宝图",
			cellFlipPrompt: "翻转一名牢房船员",
			cellPlayPrompt: "选择释放的船员",
			directionPrompt: "选择藏宝图传递方向",
			orderPrompt: "选择先结算的藏宝图",
			stealPrompt: "选择要偷取金币的船长",
			waiting: "等待{{name}}行动",
			round: "第{{n}}轮",
			finalRound: "最后一轮",
			left: "向左传递",
			right: "向右传递",
			bag: "袋中{{n}}枚",
			coins: "金币",
			bombs: "炸弹",
			columns: "完成{{n}}列",
			inspect: "查看船员",
			crew: "船员图鉴",
			backUnknown: "背面尚未揭晓",
			backKnown: "背面：{{role}}",
			placeLabel: "放入第{{n}}列",
			flipLabel: "翻转{{role}}",
			seat: "查看{{name}}的冒险板",
			cell: "牢房",
			mapOwner: "{{name}}持有",
			center: "桌面中央",
			errAction: "当前不能执行这个操作。",
			bonus: {
				none: "",
				map: "完成此列后取得藏宝图。",
				coins3: "完成此列后获得3金币。",
				coins4: "完成此列后获得4金币。",
				coins5: "完成此列后获得5金币。",
				race1: "最先完成此列获得1金币，后来完成者没有奖励。",
				race2: "最先完成此列获得2金币，后来完成者获得1金币。",
				race6: "最先完成此列获得6金币，后来完成者获得3金币。",
				race0: "最先完成此列没有奖励，后来完成者获得2金币。",
				race4: "最先完成此列获得4金币，后来完成者获得2金币。",
				race5: "最先完成此列获得5金币，后来完成者获得2金币。",
				same6: "终局时此列填满且角色全相同，获得6金币。",
				different4: "终局时此列填满且角色全不同，获得4金币。",
				completed2: "完成此列后，每列已完成的列奖励2金币，包括此列。",
				diversity: "完成此列后，每种不同角色奖励1金币。",
				sameMap: "完成此列时角色全相同，取得藏宝图。",
				differentFlip: "完成此列时角色全不同，翻转自己任一角色并结算效果。",
				sameDraw: "完成此列时角色全相同，追加招募一名船员。",
				differentDraw: "完成此列时角色全不同，追加招募一名船员。",
				neighbors: "完成此列后，按周围7格中不同角色数量获得金币，不计此格。",
				cellFlip: "完成此列后翻转一枚牢房板块，不结算角色效果。",
				cellPlay: "完成此列后释放一枚牢房板块，按当前朝向放置并结算效果。",
				coins3map: "完成此列后获得3金币并取得藏宝图。",
				passMaps: "完成此列后决定所有藏宝图向左或向右传递。",
				firstFlip: "最先完成此列可以翻转自己任一角色并结算效果，后来完成者获得2金币。",
				bombs2: "完成此列后，每枚可见炸弹奖励2金币。",
				mapBomb: "完成此列后取得藏宝图，并永久增加一枚炸弹；这枚炸弹不影响木匠。",
				pay1: "放置到此格前支付1金币，没有金币不能放置。"
			},
			log: {
				draw: "{{name}}抽到{{role}}",
				flip: "{{name}}翻出{{role}}",
				place: "{{name}}招募{{role}}",
				coins: "{{name}}获得{{n}}金币",
				map: "{{name}}取得藏宝图",
				dolphin: "{{name}}遇到海豚",
				bottle: "{{name}}发现瓶中信",
				pass: "{{name}}传递了藏宝图",
				end: "航程结束"
			},
			resultTitle: "金库清点",
			victory: "{{name}}满载而归",
			noWinner: "全体船长遭遇爆炸",
			review: "回看甲板",
			showResult: "查看结算",
			close: "收起结算",
			total: "总分",
			eliminated: "爆炸淘汰",
			score: {
				coins: "已有金币",
				swabbies: "水手",
				lookouts: "瞭望员",
				carpenters: "木匠",
				parrots: "鹦鹉",
				board: "冒险板",
				maps: "藏宝图"
			},
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			solo: "独自远航",
			soloRanks: [
				"见习船长",
				"水手",
				"老练水手",
				"军官",
				"海军上将",
				"海上传奇"
			],
			hintDraw: "抽取一枚船员板块。",
			hintFlip: "翻转这枚板块，尝试另一位船员。",
			hintPlace: "把{{role}}放入第{{n}}列。",
			hintTile: "翻转一枚船员板块。",
			hintMap: "选择藏宝图。",
			hintOther: "完成当前选择。",
			soloRank0: "见习船长",
			soloRank1: "水手",
			soloRank2: "老练水手",
			soloRank3: "军官",
			soloRank4: "海军上将",
			soloRank5: "海上传奇"
		},
		en: {
			name: "Captain Flip",
			desc: "Recruit a pirate crew, flip your luck, and sail home with a hold full of gold.",
			rules: "Goal:\nRecruit a pirate crew and collect the most coins. Everyone uses the same Adventure board. The base game supports 2–5 players; the official Kraken solo rules apply to boards A–E.\nSetup:\nUse boards A–D, 72 double-sided Character tiles, and the basic Treasure Map. Each of the nine Characters appears 16 times, with different Characters on the two sides of each tile. Each pair appears twice. Choose a random first Captain, then play in seat order. Coins and exposed faces are public; unseen reverse sides remain hidden.\nTurn:\nDraw a tile and look at its face. Keep it or flip it once; after flipping, you must use the new Character. Place it on the lowest empty space of a column. Resolve its Character effect before the board bonus. Gaps and diagonals are not adjacent. At the end of an ordinary turn, resolve your Treasure Maps in your chosen order.\n· Cartographer: Take a Treasure Map.\n· Navigator: Gain 2 coins for each Cartographer on your Adventure board.\n· Cook: Gain 1 coin for each Character in this Cook’s row, including the Cook itself.\n· Gunner: Immediately gain 5 coins. At game end, you are eliminated if you have at least 3 Bombs.\n· Monkey: Gain 1 coin, then flip a tile orthogonally adjacent to this Monkey and resolve the revealed Character’s effect. If there is no adjacent tile, gain only the coin.\n· Parrot: Immediately draw and play another Character tile, which may still be flipped. At game end, lose 1 coin for each Parrot. The extra recruitment remains part of the current turn. Extra recruitment does not trigger additional Map income.\n· Lookout: At game end, gain 4 coins if there is no Character above this Lookout in its column.\n· Carpenter: At game end, gain 3 coins if no Gunner shares this Carpenter’s row or column. On Isla Bomba, an uncovered printed board Bomb also counts as a Gunner; other extra Bombs do not affect Carpenters.\n· Swabby: At game end, count the columns containing at least one Swabby and gain that number squared in coins. Score all Swabbies together rather than scoring each tile separately.\n· Flipping a placed tile only applies its Character effect, never a previously earned board bonus. Complete nested recruitment and flips before returning to the original board bonus.\nAdventure boards:\n· A, Pirate Ship: completing column 2 grants a Map; columns 3 and 5 grant 5 and 3 coins.\n· B, Kraken: from left to right, the first Captain to complete each column gains 1, 2, 6, 0 or 4 coins respectively. Later Captains completing those columns gain 0, 1, 3, 2 or 2 coins respectively.\n· C, Raft: Completing column 1 grants a Treasure Map. At game end, gain 6 coins if column 2 is full and all its Characters match; gain 4 coins if column 4 is full and all its Characters differ.\n· D, Desert Island: Completing column 1 grants 3 coins. When you complete column 2, gain 2 coins for each completed column, including column 2 itself. When you complete column 3, gain 1 coin for each different Character in that column. Pay 1 coin before placing a tile in column 5; if you have no coins, you cannot place a tile there.\n· E, In the Jaws of the Kraken: Completing columns 1 and 5 grants 4 and 3 coins respectively. Completing column 2 grants a Treasure Map if all its Characters match. Completing column 3 allows you to flip any tile on your board if all its Characters differ. Completing column 4 grants extra recruitment if all its Characters match. In solo play, taking a Map you already hold returns it to the center. On board B, your first two completed columns receive the first-completer reward; later completed columns receive the later-completer reward.\nIsla Bomba expansion:\nBoards F–I, the five new Maps, and events can be combined independently and are off by default. Resolve board effects after Character effects.\n· F, Submarine: Filling the bottom row with 3 identical Characters grants 5 coins. Filling the next row of 5 spaces grants 5 coins to the first completer and 2 coins to later completers. Completing column 2 grants a Treasure Map. Completing column 3 grants 1 coin for each different Character in the 7 surrounding spaces, excluding the bonus space itself. Completing column 4 grants extra recruitment if its 4 Characters differ. Completing column 5 grants 3 coins.\n· G, Prison: During preparation, each Captain draws 2 tiles into Cells without resolving their effects or looking at their reverse sides. Completing column 1 allows you to flip a Cell tile without resolving its effect. Completing column 2 grants a Treasure Map. The first Captain to complete column 3 gains 5 coins; later completers gain 2 coins. Completing column 4 or 5 releases a Cell tile; place it without flipping and resolve its effect.\n· H, Observatory: Use two Treasure Maps. When taking a Map, take one from the center if possible; otherwise, take one from another Captain. You may hold multiple Maps. The uncovered Sextant counts as an additional Cartographer. Completing column 1 grants a Map. Completing column 2 grants 3 coins and a Map. Completing column 3 passes all Maps left or right, as you choose. The first Captain to complete column 4 may flip any tile on their board; later completers gain 2 coins. Completing column 5 grants 3 coins. Completing the row of 5 spaces grants 2 coins for each Map you hold.\n· I, Isla Bomba: The two uncovered Sextants count as additional Cartographers. The uncovered printed board Bomb counts toward elimination and affects Carpenter scoring in its row or column. Completing column 2 grants a Map. Completing column 3 grants 3 coins. Completing column 4 grants 2 coins for each visible Bomb. Completing column 5 grants a Map and a permanent Bomb. The eye spaces steal coins from the left and right neighbors respectively, equal to the number of Characters on that neighbor’s board matching the Character just placed, up to the coins that neighbor holds. Bombs from Maps and column 5 do not affect Carpenters.\n· Basic Map: At the end of your turn, gain 1 coin.\n· Cursed Map: While you hold this Map, you cannot flip any tile. At the end of your turn, gain 2 coins.\n· Burning Map: While you hold this Map, add 1 Bomb. Gain 1 coin at the end of your turn and 5 additional coins at game end. This Map’s Bomb does not affect Carpenters.\n· Gambler's Map: At the end of your turn, gain 2 coins if you have gained no coins during this turn.\n· Kraken's Map: At the end of your turn, steal 1 coin from the richest other Captain. Choose among Captains tied for richest. If you are strictly richer than every other Captain, steal no coins.\n· 4 Winds Map: At the end of your turn, gain the coins shown by this Map’s current orientation, then rotate it a quarter turn clockwise. The four orientations award 1, 2, 1 and 3 coins in order. Reset it to the first orientation when you acquire the Map. If you hold multiple Maps, choose the order in which they resolve.\n· Dolphin event: starting with the drawer, each Captain flips a tile on their board and resolves its effect. Remove the Dolphin, then the drawer recruits again. Other Captains do not receive end-turn Map income.\n· Message in a Bottle: randomly gain an unused official expansion Map, remove the Bottle, and recruit again. The custom blank Map is excluded. The Cursed Map skips prohibited flips while other effects still apply.\nEnd:\nWhen anyone completes at least 4 columns, finish the round so all Captains receive the same number of ordinary turns. Finish all extra recruitment and Character effects. Add coins, Characters, board, and Map rewards. Captains with at least 3 Bombs are eliminated; the highest remaining total wins. Map holders win score ties over non-holders; otherwise share victory. If all Captains explode, nobody wins. In solo play, your final coin total determines your rank:\n· With 30 coins or fewer, your rank is Landlubber.\n· With 31–40 coins, your rank is Deckhand.\n· With 41–50 coins, your rank is Sailor.\n· With 51–55 coins, your rank is Lieutenant.\n· With 56–60 coins, your rank is Admiral.\n· With at least 61 coins, your rank is Legend of the Sea.",
			role: {
				cartographer: "Cartographer",
				navigator: "Navigator",
				cook: "Cook",
				gunner: "Gunner",
				monkey: "Monkey",
				parrot: "Parrot",
				lookout: "Lookout",
				carpenter: "Carpenter",
				swabby: "Swabby"
			},
			effect: {
				cartographer: "Take a Treasure Map.",
				navigator: "Gain 2 coins for each Cartographer on your Adventure board.",
				cook: "Gain 1 coin for each Character in this Cook’s row, including the Cook itself.",
				gunner: "Immediately gain 5 coins. At game end, you are eliminated if you have at least 3 Bombs.",
				monkey: "Gain 1 coin, then flip a tile orthogonally adjacent to this Monkey and resolve the revealed Character’s effect. If there is no adjacent tile, gain only the coin.",
				parrot: "Immediately draw and play another Character tile, which may still be flipped. At game end, lose 1 coin for each Parrot. The extra recruitment remains part of the current turn.",
				lookout: "At game end, gain 4 coins if there is no Character above this Lookout in its column.",
				carpenter: "At game end, gain 3 coins if no Gunner shares this Carpenter’s row or column. On Isla Bomba, an uncovered printed board Bomb also counts as a Gunner; other extra Bombs do not affect Carpenters.",
				swabby: "At game end, count the columns containing at least one Swabby and gain that number squared in coins. Score all Swabbies together rather than scoring each tile separately."
			},
			board: {
				A: "A · Pirate Ship",
				B: "B · Kraken",
				C: "C · Raft",
				D: "D · Desert Island",
				E: "E · Jaws of the Kraken",
				F: "F · Submarine",
				G: "G · Prison",
				H: "H · Observatory",
				I: "I · Isla Bomba"
			},
			map: {
				base: "Basic Map",
				cursed: "Cursed Map",
				burning: "Burning Map",
				gambler: "Gambler's Map",
				kraken: "Kraken's Map",
				winds: "4 Winds Map"
			},
			mapEffect: {
				base: "At the end of your turn, gain 1 coin.",
				cursed: "While you hold this Map, you cannot flip any tile. At the end of your turn, gain 2 coins.",
				burning: "While you hold this Map, add 1 Bomb. Gain 1 coin at the end of your turn and 5 additional coins at game end. This Map’s Bomb does not affect Carpenters.",
				gambler: "At the end of your turn, gain 2 coins if you have gained no coins during this turn.",
				kraken: "At the end of your turn, steal 1 coin from the richest other Captain. Choose among Captains tied for richest. If you are strictly richer than every other Captain, steal no coins.",
				winds: "At the end of your turn, gain the coins shown by this Map’s current orientation, then rotate it a quarter turn clockwise. The four orientations award 1, 2, 1 and 3 coins in order. Reset it to the first orientation when you acquire the Map."
			},
			optBoard: "Adventure board",
			optMap: "Treasure Map",
			optSecondMap: "Second Map (Observatory)",
			optEvents: "Event tiles",
			dolphin: "Dolphin",
			bottle: "Message in a Bottle",
			draw: "Recruit a Character",
			flipDraw: "Flip tile",
			forced: "Use this face",
			choosePrompt: "Choose a boarding space",
			drawPrompt: "Recruit from the bag",
			resolving: "The crew is taking action",
			flipPrompt: "Choose a Character to flip",
			mapPrompt: "Choose a Treasure Map",
			cellFlipPrompt: "Flip a Character in a Cell",
			cellPlayPrompt: "Choose a Character to release",
			directionPrompt: "Choose which way Maps pass",
			orderPrompt: "Choose a Map to resolve first",
			stealPrompt: "Choose a Captain to steal from",
			waiting: "Waiting for {{name}}",
			round: "Round {{n}}",
			finalRound: "Final round",
			left: "Pass left",
			right: "Pass right",
			bag: "{{n}} tiles in bag",
			coins: "Coins",
			bombs: "Bombs",
			columns: "{{n}} columns complete",
			inspect: "Inspect Character",
			crew: "Crew reference",
			backUnknown: "Reverse side unknown",
			backKnown: "Reverse: {{role}}",
			placeLabel: "Place in column {{n}}",
			flipLabel: "Flip {{role}}",
			seat: "View {{name}}'s Adventure board",
			cell: "Cells",
			mapOwner: "Held by {{name}}",
			center: "Center of the table",
			errAction: "That action is unavailable right now.",
			bonus: {
				none: "",
				map: "Complete this column to take a Treasure Map.",
				coins3: "Complete this column to gain 3 coins.",
				coins4: "Complete this column to gain 4 coins.",
				coins5: "Complete this column to gain 5 coins.",
				race1: "First to complete: gain 1 coin. Later Captains gain nothing.",
				race2: "First to complete: gain 2 coins. Later Captains gain 1.",
				race6: "First to complete: gain 6 coins. Later Captains gain 3.",
				race0: "First to complete: no reward. Later Captains gain 2 coins.",
				race4: "First to complete: gain 4 coins. Later Captains gain 2.",
				race5: "First to complete: gain 5 coins. Later Captains gain 2.",
				same6: "At game end, gain 6 coins if this column is full and all Characters match.",
				different4: "At game end, gain 4 coins if this column is full and all Characters differ.",
				completed2: "Complete this column to gain 2 per completed column, including this one.",
				diversity: "Complete this column to gain 1 per different Character in it.",
				sameMap: "Complete this column with identical Characters to take a Map.",
				differentFlip: "Complete this column with all different Characters to flip any of your board tiles and resolve its effect.",
				sameDraw: "Complete this column with identical Characters to recruit again.",
				differentDraw: "Complete this column with all different Characters to recruit again.",
				neighbors: "Complete this column to gain 1 per different Character in the 7 surrounding spaces, excluding this space.",
				cellFlip: "Complete this column to flip a Cell tile without resolving its effect.",
				cellPlay: "Complete this column to release a Cell tile. Place it without flipping and resolve its effect.",
				coins3map: "Complete this column to gain 3 coins and a Treasure Map.",
				passMaps: "Complete this column to pass all Maps left or right, as you choose.",
				firstFlip: "First to complete: flip any of your board tiles and resolve its effect. Later Captains gain 2 coins.",
				bombs2: "Complete this column to gain 2 per visible Bomb.",
				mapBomb: "Complete this column to take a Map and gain a permanent Bomb. This Bomb does not affect Carpenters.",
				pay1: "Pay 1 coin before placing here. Without coins, you cannot place here."
			},
			log: {
				draw: "{{name}} drew {{role}}",
				flip: "{{name}} revealed {{role}}",
				place: "{{name}} recruited {{role}}",
				coins: "{{name}} gained {{n}} coins",
				map: "{{name}} took a Treasure Map",
				dolphin: "{{name}} encountered the Dolphin",
				bottle: "{{name}} found a Message in a Bottle",
				pass: "{{name}} passed the Maps",
				end: "The voyage has ended"
			},
			resultTitle: "Counting the treasure",
			victory: "{{name}} sails home victorious",
			noWinner: "Every Captain exploded",
			review: "Review the deck",
			showResult: "Show results",
			close: "Hide results",
			total: "Total",
			eliminated: "Exploded",
			score: {
				coins: "Coins collected",
				swabbies: "Swabbies",
				lookouts: "Lookouts",
				carpenters: "Carpenters",
				parrots: "Parrots",
				board: "Adventure board",
				maps: "Treasure Maps"
			},
			confirmAgain: "Confirm another game",
			confirmLobby: "Confirm return to lobby",
			solo: "A solo voyage",
			soloRanks: [
				"Landlubber",
				"Deckhand",
				"Sailor",
				"Lieutenant",
				"Admiral",
				"Legend of the Sea"
			],
			hintDraw: "Draw a Character tile.",
			hintFlip: "Flip this tile to try another Character.",
			hintPlace: "Place {{role}} in column {{n}}.",
			hintTile: "Flip a Character tile.",
			hintMap: "Choose a Treasure Map.",
			hintOther: "Complete the current choice.",
			soloRank0: "Landlubber",
			soloRank1: "Deckhand",
			soloRank2: "Sailor",
			soloRank3: "Lieutenant",
			soloRank4: "Admiral",
			soloRank5: "Legend of the Sea"
		}
	}
};
//#endregion
export { Ke as default };
