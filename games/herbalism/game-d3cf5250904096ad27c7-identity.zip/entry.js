import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { AVATARS as n } from "@bgparty/sdk/avatars";
import { useState as r } from "react";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as c } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u } from "@bgparty/sdk/ui/player-strip";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Floater as m, FlySprite as h, PulseBox as g } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as _ } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as v, OptionSection as y, OptionSwitch as ee } from "@bgparty/sdk/ui/game-options";
//#region src/games/herbalism/meta.ts
var b = {
	id: "herbalism",
	tier: "beta",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.herbalism.name",
	descKey: "games.herbalism.desc",
	rulesKey: "games.herbalism.rules",
	icon: "🌿",
	iconImg: "games/herbalism.webp",
	rulesUrl: {
		zh: "https://rules.bgparty.uuppi.com/herbalism/zh.pdf",
		en: "https://rules.bgparty.uuppi.com/herbalism/en.pdf"
	},
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#16a34a",
	releasedAt: "2026-09-28",
	search: {
		py: "ben cao",
		init: "bc"
	},
	hotseat: "cover"
}, x = t.enum([
	"r",
	"y",
	"g",
	"b"
]), S = t.string(), C = t.int().min(0).max(6), w = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("move"),
		card: C
	}),
	t.object({
		type: t.literal("ask"),
		target: S,
		color: x
	}),
	t.object({
		type: t.literal("feed"),
		target: S,
		color: x
	}),
	t.object({
		type: t.literal("brew"),
		target: S
	}),
	t.object({
		type: t.literal("appeal"),
		target: S
	}),
	t.object({
		type: t.literal("respond"),
		color: x
	}),
	t.object({ type: t.literal("taste") }),
	t.object({
		type: t.literal("tasteMove"),
		card: C
	}),
	t.object({
		type: t.literal("pass"),
		color: x
	}),
	t.object({
		type: t.literal("cure"),
		card: C
	}),
	t.object({
		type: t.literal("cureJoin"),
		card: C.nullable(),
		follow: t.boolean().optional(),
		predict: x.optional()
	}),
	t.object({
		type: t.literal("predict"),
		color: x
	}),
	t.object({ type: t.literal("noPredict") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), T = t.object({
	k: t.string(),
	p: t.record(t.string(), t.union([t.string(), t.number()])).optional()
}), E = t.object({
	card: C,
	follow: t.boolean()
}), D = t.object({
	cure: t.tuple([x, x]),
	solver: S.nullable(),
	deltas: t.record(S, t.int()),
	wrongCards: t.array(C)
}), te = t.object({
	mode: t.enum([
		"base",
		"duo",
		"teams"
	]),
	actions: t.array(t.enum([
		"ask",
		"feed",
		"brew",
		"appeal",
		"pass",
		"cure",
		"taste"
	])),
	target: t.int(),
	round: t.int().min(1),
	players: t.array(S),
	teams: t.array(t.tuple([S, S])).nullable(),
	turn: S,
	moved: t.boolean(),
	scores: t.record(S, t.int()),
	handCounts: t.record(S, t.int().nonnegative()),
	neutralCount: t.int().nonnegative().nullable(),
	pharmacist: t.record(S, C.nullable()),
	markers: t.record(S, t.union([E, t.literal("lost")])),
	predictions: t.record(S, t.array(x)),
	supply: t.record(x, t.int().nonnegative()),
	phase: t.enum([
		"play",
		"predict",
		"respond",
		"cureChoose",
		"peek",
		"settle",
		"done"
	]),
	pending: t.object({
		kind: t.enum([
			"brewSame",
			"appeal",
			"tasteMove"
		]),
		actor: S,
		target: S
	}).nullable(),
	cureFlow: t.object({
		actor: S,
		waiting: S.nullable(),
		peekOrder: t.array(S),
		peekIdx: t.int().nonnegative()
	}).nullable(),
	lastSettle: D.nullable(),
	log: t.array(T)
}), ne = t.object({
	hand: t.array(x),
	myPeeks: t.array(t.object({
		round: t.int(),
		cure: t.tuple([x, x]),
		ok: t.boolean()
	})),
	tasteDrawn: x.nullable()
}), O = t.object({
	actions: t.enum([
		"simple",
		"normal",
		"advanced"
	]).default("normal"),
	prediction: t.boolean().default(!1),
	teams: t.boolean().default(!1)
}).default({
	actions: "normal",
	prediction: !1,
	teams: !1
}), k = {
	action: w,
	publicView: te,
	privateView: ne,
	config: O
}, A = 2600, re = 3800, j = [
	"r",
	"y",
	"g",
	"b"
], M = [
	"r",
	"r",
	"y",
	"y",
	"y",
	"g",
	"g",
	"g",
	"g",
	"b",
	"b",
	"b",
	"b",
	"b"
], N = [
	["g", "y"],
	["r", "g"],
	["r", "b"],
	["y", "r"],
	["g", "b"],
	["y", "b"]
], P = {
	simple: ["ask", "cure"],
	normal: [
		"feed",
		"appeal",
		"cure"
	],
	advanced: [
		"ask",
		"feed",
		"brew",
		"appeal",
		"cure"
	]
}, F = (e) => ({ code: e });
function I(e, t, n) {
	e.log.push({
		k: t,
		p: n
	}), e.log.length > 200 && e.log.splice(0, e.log.length - 200);
}
function ie(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.rngCursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
var L = (e, t) => e.filter((e) => e === t).length;
function R(e, t, n) {
	let r = [], i = [];
	for (let a of e) a === t && r.length < n ? r.push(a) : i.push(a);
	return e.length = 0, e.push(...i), r;
}
function z(e) {
	return e === 6 ? null : N[e];
}
function B(e, t) {
	if (e === 6) return t[0] === t[1];
	let [n, r] = N[e];
	return t[0] === n && t[1] === r || t[0] === r && t[1] === n;
}
var V = (e, t) => e.teams?.findIndex((e) => e.includes(t)) ?? -1;
function H(e, t) {
	return e.markers[t] ? !1 : e.mode !== "teams" || !e.teamMarkerUsed[V(e, t)];
}
function U(e, t) {
	let n = e.players.filter((e) => e !== t);
	if (e.mode !== "teams") return n;
	let r = V(e, t);
	return n.filter((t) => V(e, t) !== r);
}
function ae(e, t) {
	if (e.mode === "teams") {
		let n = e.teams.map((e, t) => t).filter((t) => !e.teamMarkerUsed[t]);
		if (n.length === 1 && n[0] === V(e, t)) return !0;
	} else {
		let n = e.players.filter((t) => H(e, t));
		if (n.length === 1 && n[0] === t) return !0;
	}
	let n = e.hands[t], r = e.actions.some((e) => e === "ask" || e === "feed"), i = e.actions.some((e) => e === "brew" || e === "appeal" || e === "pass") || e.mode === "duo";
	return !(n.length !== 0 || !r || i);
}
function oe(e, t) {
	if (e.phase !== "play" || e.players[e.turn] !== t || !e.moved) return [];
	if (ae(e, t)) return ["cure"];
	let n = e.hands[t], r = e.pharmacist[t], i = r === null ? null : z(r), a = [];
	for (let r of e.actions) r === "ask" || r === "feed" ? n.length > 0 && (i === null || i.some((e) => n.includes(e))) && U(e, t).length > 0 && a.push(r) : r === "brew" || r === "appeal" ? U(e, t).length > 0 && a.push(r) : r === "cure" && H(e, t) && a.push(r);
	return e.mode === "teams" && i !== null && !a.includes("pass") && a.splice(a.length - +!!a.includes("cure"), 0, "pass"), e.mode === "duo" && e.neutral.length > 0 && a.push("taste"), a;
}
var se = (e) => e.config.prediction || e.mode === "teams";
function ce(e) {
	let t = ie(e, [...M]);
	e.cure = [t[0], t[1]];
	let n = t.slice(2), r = e.players.length <= 3 ? 4 : 3, i = [];
	return e.players.forEach((t, a) => {
		e.hands[t] = n.slice(a * r, (a + 1) * r), i.push({
			kind: "deal",
			rid: t,
			data: { count: r }
		}), i.push({
			kind: "deal",
			rid: t,
			for: [t],
			secret: { cards: e.hands[t] }
		});
	}), e.mode === "duo" && (e.neutral = n.slice(2 * r, 2 * r + 4), i.push({
		kind: "dealNeutral",
		data: { count: 4 }
	})), i;
}
function le(t, n, r) {
	let i = n.length === 2 ? "duo" : t.teams && n.length === 4 ? "teams" : "base", a = {
		seed: r,
		rngCursor: 0,
		config: t,
		mode: i,
		actions: i === "teams" ? [
			...P[t.actions].filter((e) => e !== "cure"),
			"pass",
			"cure"
		] : P[t.actions],
		target: i === "base" ? 6 : 7,
		players: n,
		teams: i === "teams" ? [[n[0], n[2]], [n[1], n[3]]] : null,
		round: 1,
		turn: 0,
		moved: !1,
		hands: {},
		neutral: null,
		cure: ["r", "r"],
		pharmacist: Object.fromEntries(n.map((e) => [e, null])),
		markers: {},
		teamMarkerUsed: i === "teams" ? [!1, !1] : null,
		predictions: Object.fromEntries(n.map((e) => [e, []])),
		supply: {
			r: 2,
			y: 2,
			g: 2,
			b: 2
		},
		scores: Object.fromEntries(n.map((e) => [e, 0])),
		phase: "play",
		pending: null,
		cureFlow: null,
		peeksBook: {},
		lastSettle: null,
		winner: null,
		log: []
	}, o = ce(a);
	return a.turn = e(r, a.rngCursor++, n.length), I(a, "games.herbalism.logRound", { n: 1 }), {
		state: a,
		fx: o
	};
}
function W(e) {
	for (let t = 0; t < e.players.length && (e.turn = (e.turn + 1) % e.players.length, e.markers[e.players[e.turn]] === "lost"); t++);
	e.moved = !1, e.phase = "play", e.pending = null;
}
function G(e, t) {
	se(e) && e.mode !== "teams" && j.some((n) => !e.predictions[t].includes(n) && e.supply[n] > 0) ? e.phase = "predict" : W(e);
}
function ue(e, t, n, r) {
	return R(e.hands[t], r, 1), e.hands[n].push(r), [{
		kind: "give",
		rid: t,
		data: {
			to: n,
			n: 1
		}
	}, {
		kind: "give",
		rid: t,
		for: [n],
		secret: { cards: [r] }
	}];
}
function de(e, t, n, r) {
	let i = ue(e, t, n, r), a = z(e.pharmacist[t]), o = a === null ? r : a[0] === r ? a[1] : a[0];
	return I(e, "games.herbalism.logAsk", {
		a: t,
		b: n,
		n: L(e.hands[n], o)
	}), G(e, t), {
		state: e,
		fx: i
	};
}
function fe(e, t, n, r) {
	let i = ue(e, t, n, r), a = z(e.pharmacist[t]), o = a === null ? r : a[0] === r ? a[1] : a[0], s = R(e.hands[n], o, Infinity);
	return e.hands[t].push(...s), I(e, "games.herbalism.logFeed", {
		a: t,
		b: n,
		n: s.length
	}), s.length && i.push({
		kind: "take",
		rid: n,
		data: {
			to: t,
			n: s.length
		}
	}), G(e, t), {
		state: e,
		fx: i
	};
}
function pe(e, t, n) {
	let r = e.pharmacist[t], i = e.hands[n];
	if (r === 6) {
		let r = j.filter((e) => L(i, e) >= 2);
		if (r.length === 0) return I(e, "games.herbalism.logBrew", {
			a: t,
			b: n,
			n: 0
		}), [];
		if (r.length > 1) return e.pending = {
			kind: "brewSame",
			actor: t,
			target: n
		}, e.phase = "respond", null;
		let a = R(i, r[0], 2);
		return e.hands[t].push(...a), I(e, "games.herbalism.logBrew", {
			a: t,
			b: n,
			n: 2
		}), [{
			kind: "take",
			rid: n,
			data: {
				to: t,
				n: 2
			}
		}];
	}
	let a = [];
	for (let e of N[r]) a.push(...R(i, e, 1));
	return e.hands[t].push(...a), I(e, "games.herbalism.logBrew", {
		a: t,
		b: n,
		n: a.length
	}), a.length ? [{
		kind: "take",
		rid: n,
		data: {
			to: t,
			n: a.length
		}
	}] : [];
}
function me(e, t, n) {
	let r = e.pharmacist[t], i = e.hands[n], a = r === 6 ? j.filter((e) => i.includes(e)) : N[r].filter((e) => i.includes(e));
	if (a.length === 0) return I(e, "games.herbalism.logAppeal", {
		a: t,
		b: n,
		n: 0
	}), [];
	if (a.length > 1) return e.pending = {
		kind: "appeal",
		actor: t,
		target: n,
		colors: [...a]
	}, e.phase = "respond", null;
	let o = R(i, a[0], Infinity);
	return e.hands[t].push(...o), I(e, "games.herbalism.logAppeal", {
		a: t,
		b: n,
		n: o.length
	}), [{
		kind: "take",
		rid: n,
		data: {
			to: t,
			n: o.length
		}
	}];
}
function he(e, t, n) {
	e.markers[t] = {
		card: n,
		follow: !1
	}, e.mode === "teams" && (e.teamMarkerUsed[V(e, t)] = !0);
	let r = [];
	for (let n = 1; n < e.players.length; n++) {
		let i = e.players[(e.players.indexOf(t) + n) % e.players.length];
		e.markers[i] !== "lost" && r.push(i);
	}
	e.cureFlow = {
		actor: t,
		queue: r,
		peekOrder: [t],
		peekIdx: 0,
		results: {},
		cards: { [t]: n }
	}, e.phase = "cureChoose", I(e, "games.herbalism.logCure", {
		a: t,
		card: n
	}), r.length === 0 && ge(e);
}
function ge(e) {
	e.phase = "peek", e.cureFlow.peekIdx = 0;
}
function _e(e) {
	let t = e.cureFlow, n = t.peekOrder[t.peekIdx], r = B(t.cards[n], e.cure);
	t.results[n] = r, (e.peeksBook[n] ??= []).push({
		round: e.round,
		cure: [...e.cure],
		ok: r
	});
	let i = [{
		kind: "peek",
		rid: n,
		data: { ok: r }
	}, {
		kind: "peek",
		rid: n,
		for: [n],
		secret: {
			cure: e.cure,
			ok: r
		}
	}];
	if (r) return I(e, "games.herbalism.logPeekOk", { a: n }), [...i, ...ve(e, n)];
	if (I(e, "games.herbalism.logPeekNo", { a: n }), e.markers[n] = "lost", e.mode === "teams") for (let t of e.teams[V(e, n)]) t !== n && (e.markers[t] = "lost");
	return t.peekIdx++, t.peekIdx >= t.peekOrder.length && (e.players.some((t) => H(e, t)) ? (e.turn = e.players.indexOf(t.actor), e.cureFlow = null, W(e)) : i.push(...ve(e, null))), i;
}
function ve(e, t) {
	let n = {}, r = [];
	if (t) {
		n[t] = (n[t] ?? 0) + 3, I(e, "games.herbalism.logSolve", { a: t });
		for (let [r, i] of Object.entries(e.markers)) i !== "lost" && r !== t && i.follow && B(i.card, e.cure) && (n[r] = (n[r] ?? 0) + 1);
	} else I(e, "games.herbalism.logNoSolver");
	let i = e.cureFlow;
	if (i) {
		for (let [e, t] of Object.entries(i.results)) t || r.push(i.cards[e]);
		for (let [t, i] of Object.entries(e.markers)) i !== "lost" && i.follow && !B(i.card, e.cure) && r.includes(i.card) && (n[t] = (n[t] ?? 0) - 1);
	}
	if (se(e)) for (let t of e.players) {
		let r = e.predictions[t];
		if (!r.length) continue;
		let i = r.filter((t) => e.cure.includes(t)).length;
		n[t] = (n[t] ?? 0) + i - (r.length - i);
	}
	let a = [{
		kind: "reveal",
		data: { cure: e.cure }
	}];
	for (let t of e.players) {
		let r = n[t] ?? 0;
		r !== 0 && (e.scores[t] = Math.max(0, e.scores[t] + r), a.push({
			kind: "score",
			rid: t,
			data: { delta: r }
		}));
	}
	return e.lastSettle = {
		cure: [...e.cure],
		solver: t,
		deltas: n,
		wrongCards: r
	}, e.phase = "settle", e.winner = ye(e), a;
}
function ye(e) {
	if (e.mode === "teams") {
		let t = e.teams.map((t) => t.reduce((t, n) => t + e.scores[n], 0)), n = Math.max(...t);
		return n < e.target || t.filter((e) => e === n).length > 1 ? null : [...e.teams[t.indexOf(n)]];
	}
	let t = Math.max(...e.players.map((t) => e.scores[t]));
	return t < e.target || e.players.filter((n) => e.scores[n] === t).length > 1 ? null : [e.players.find((n) => e.scores[n] === t)];
}
function be(e) {
	let t = e.lastSettle, n = e.cureFlow?.actor;
	e.round++, e.markers = {}, e.teamMarkerUsed = e.mode === "teams" ? [!1, !1] : null, e.predictions = Object.fromEntries(e.players.map((e) => [e, []])), e.supply = {
		r: 2,
		y: 2,
		g: 2,
		b: 2
	}, e.cureFlow = null, e.pending = null;
	let r = ce(e), i = t?.solver ?? n ?? e.players[e.turn];
	return e.turn = (e.players.indexOf(i) + 1) % e.players.length, e.moved = !1, e.phase = "play", I(e, "games.herbalism.logRound", { n: e.round }), r.push({
		kind: "round",
		data: { n: e.round }
	}), r;
}
function xe(t, n, r) {
	let i = structuredClone(t);
	if (n.type === "tick") return i.phase === "peek" ? {
		state: i,
		fx: _e(i)
	} : i.phase === "settle" ? i.winner ? (i.phase = "done", { state: i }) : {
		state: i,
		fx: be(i)
	} : { state: i };
	if (i.phase === "done") return F("games.herbalism.errBadPhase");
	if (n.type === "respond") {
		let e = i.pending;
		if (i.phase !== "respond" || !e || e.kind === "tasteMove") return F("games.herbalism.errNotPending");
		if (r !== e.target) return F("games.herbalism.errNotYourTurn");
		if (e.kind === "brewSame") {
			if (L(i.hands[r], n.color) < 2) return F("games.herbalism.errNoCard");
			let t = R(i.hands[r], n.color, 2);
			return i.hands[e.actor].push(...t), I(i, "games.herbalism.logBrew", {
				a: e.actor,
				b: r,
				n: 2
			}), i.pending = null, G(i, e.actor), {
				state: i,
				fx: [{
					kind: "take",
					rid: r,
					data: {
						to: e.actor,
						n: 2
					}
				}]
			};
		}
		if (!e.colors.includes(n.color)) return F("games.herbalism.errBadColor");
		let t = R(i.hands[r], n.color, Infinity);
		return i.hands[e.actor].push(...t), I(i, "games.herbalism.logAppeal", {
			a: e.actor,
			b: r,
			n: t.length
		}), i.pending = null, G(i, e.actor), {
			state: i,
			fx: [{
				kind: "take",
				rid: r,
				data: {
					to: e.actor,
					n: t.length
				}
			}]
		};
	}
	if (n.type === "tasteMove") {
		let e = i.pending;
		if (i.phase !== "respond" || e?.kind !== "tasteMove") return F("games.herbalism.errNotPending");
		if (r !== e.actor) return F("games.herbalism.errNotYourTurn");
		let t = z(n.card);
		if (t !== null && !t.includes(e.drawn)) return F("games.herbalism.errBadColor");
		i.pharmacist[r] = n.card, i.pending = null;
		let a = t === null ? null : t[0] === e.drawn ? t[1] : t[0], o = [];
		return a && (o = R(i.hands[r], a, Infinity), i.neutral.push(...o)), I(i, "games.herbalism.logTasteMove", {
			a: r,
			n: o.length
		}), W(i), {
			state: i,
			fx: o.length ? [{
				kind: "take",
				rid: r,
				data: {
					to: "neutral",
					n: o.length
				}
			}] : []
		};
	}
	if (n.type === "cureJoin") {
		let e = i.cureFlow;
		if (i.phase !== "cureChoose" || !e) return F("games.herbalism.errBadPhase");
		if (e.queue[0] !== r) return F("games.herbalism.errNotYourTurn");
		if (e.queue.shift(), n.card === null) {
			if (n.predict !== void 0) {
				let e = n.predict;
				if (!se(i)) return F("games.herbalism.errBadPhase");
				if (i.supply[e] <= 0) return F("games.herbalism.errSupply");
				if (i.predictions[r].includes(e)) return F("games.herbalism.errPredicted");
				if (i.mode === "teams" && i.teams[V(i, r)].some((t) => t !== r && i.predictions[t].includes(e))) return F("games.herbalism.errTeamColor");
				i.supply[e]--, i.predictions[r].push(e), I(i, "games.herbalism.logPredict", {
					a: r,
					color: e
				});
			} else I(i, "games.herbalism.logCurePass", { a: r });
		} else {
			if (!H(i, r)) return F("games.herbalism.errNoMarker");
			let t = Object.values(i.markers).some((e) => e !== "lost" && e.card === n.card);
			if (i.mode === "teams") {
				if (t) return F("games.herbalism.errCardOccupied");
				i.teamMarkerUsed[V(i, r)] = !0, i.markers[r] = {
					card: n.card,
					follow: !1
				};
			} else {
				let e = n.follow === !0;
				if (e && !t) return F("games.herbalism.errCardEmpty");
				if (!e && t) return F("games.herbalism.errCardOccupied");
				i.markers[r] = {
					card: n.card,
					follow: e
				};
			}
			e.cards[r] = n.card, e.peekOrder.push(r), I(i, "games.herbalism.logCureJoin", {
				a: r,
				card: n.card,
				follow: +!!n.follow
			});
		}
		return e.queue.length === 0 && ge(i), { state: i };
	}
	if (n.type === "predict" || n.type === "noPredict") {
		if (i.phase !== "predict") return F("games.herbalism.errBadPhase");
		if (i.players[i.turn] !== r) return F("games.herbalism.errNotYourTurn");
		if (n.type === "predict") {
			if (i.supply[n.color] <= 0) return F("games.herbalism.errSupply");
			if (i.predictions[r].includes(n.color)) return F("games.herbalism.errPredicted");
			i.supply[n.color]--, i.predictions[r].push(n.color), I(i, "games.herbalism.logPredict", {
				a: r,
				color: n.color
			});
		}
		return W(i), { state: i };
	}
	if (i.phase !== "play") return F("games.herbalism.errBadPhase");
	if (i.players[i.turn] !== r) return F("games.herbalism.errNotYourTurn");
	if (n.type === "move") return i.moved ? F("games.herbalism.errAlreadyMoved") : i.pharmacist[r] === n.card ? F("games.herbalism.errMustMove") : (i.pharmacist[r] = n.card, i.moved = !0, { state: i });
	if (!i.moved) return F("games.herbalism.errMustMoveFirst");
	let a = oe(i, r), o = i.pharmacist[r], s = z(o);
	if (n.type === "cure") return a.includes("cure") ? (he(i, r, n.card), { state: i }) : F("games.herbalism.errNoMarker");
	if (n.type === "taste") {
		if (i.mode !== "duo" || !a.includes("taste")) return F("games.herbalism.errBadPhase");
		let t = e(i.seed, i.rngCursor++, i.neutral.length), n = i.neutral.splice(t, 1)[0];
		return i.hands[r].push(n), I(i, "games.herbalism.logTaste", { a: r }), i.pending = {
			kind: "tasteMove",
			actor: r,
			target: r,
			drawn: n
		}, i.phase = "respond", {
			state: i,
			fx: [{
				kind: "taste",
				rid: r,
				data: { n: i.neutral.length }
			}, {
				kind: "taste",
				rid: r,
				for: [r],
				secret: { cards: [n] }
			}]
		};
	}
	if (n.type === "pass") {
		if (!a.includes("pass")) return F("games.herbalism.errBadTarget");
		if (s === null) return F("games.herbalism.errPassSame");
		if (!s.includes(n.color)) return F("games.herbalism.errBadColor");
		let e = i.teams[V(i, r)].find((e) => e !== r), t = R(i.hands[r], n.color, Infinity), o = s[0] === n.color ? s[1] : s[0], c = R(i.hands[e], o, Infinity);
		i.hands[e].push(...t), i.hands[r].push(...c), I(i, "games.herbalism.logPass", {
			a: r,
			b: e,
			n: t.length,
			m: c.length
		}), W(i);
		let l = [];
		return t.length && l.push({
			kind: "give",
			rid: r,
			data: {
				to: e,
				n: t.length
			}
		}), c.length && l.push({
			kind: "give",
			rid: e,
			data: {
				to: r,
				n: c.length
			}
		}), {
			state: i,
			fx: l
		};
	}
	if (n.type === "ask" || n.type === "feed") return a.includes(n.type) ? U(i, r).includes(n.target) ? s !== null && !s.includes(n.color) ? F("games.herbalism.errBadColor") : i.hands[r].includes(n.color) ? n.type === "ask" ? de(i, r, n.target, n.color) : fe(i, r, n.target, n.color) : F("games.herbalism.errNoCard") : F("games.herbalism.errBadTarget") : F("games.herbalism.errNoCard");
	if (n.type === "brew" || n.type === "appeal") {
		if (!a.includes(n.type)) return F("games.herbalism.errBadPhase");
		if (!U(i, r).includes(n.target)) return F("games.herbalism.errBadTarget");
		let e = n.type === "brew" ? pe(i, r, n.target) : me(i, r, n.target);
		return e === null ? { state: i } : (G(i, r), {
			state: i,
			fx: e
		});
	}
	return F("games.herbalism.errBadPhase");
}
function Se(e, t) {
	let n = e.cureFlow;
	return {
		public: {
			mode: e.mode,
			actions: e.mode === "duo" ? [...e.actions, "taste"] : e.actions,
			target: e.target,
			round: e.round,
			players: [...e.players],
			teams: e.teams ? e.teams.map((e) => [...e]) : null,
			turn: e.players[e.turn],
			moved: e.moved,
			scores: { ...e.scores },
			handCounts: Object.fromEntries(e.players.map((t) => [t, e.hands[t].length])),
			neutralCount: e.neutral ? e.neutral.length : null,
			pharmacist: { ...e.pharmacist },
			markers: structuredClone(e.markers),
			predictions: structuredClone(e.predictions),
			supply: { ...e.supply },
			phase: e.phase,
			pending: e.pending ? {
				kind: e.pending.kind,
				actor: e.pending.actor,
				target: e.pending.target
			} : null,
			cureFlow: n ? {
				actor: n.actor,
				waiting: n.queue[0] ?? null,
				peekOrder: [...n.peekOrder],
				peekIdx: n.peekIdx
			} : null,
			lastSettle: e.lastSettle ? structuredClone(e.lastSettle) : null,
			log: e.log.slice(-30)
		},
		private: {
			hand: [...e.hands[t] ?? []].sort(),
			myPeeks: structuredClone(e.peeksBook[t] ?? []),
			tasteDrawn: e.pending?.kind === "tasteMove" && e.pending.actor === t ? e.pending.drawn : null
		}
	};
}
function Ce(e) {
	if (e.phase !== "done" || !e.winner) return { phase: e.phase };
	let t;
	if (e.mode === "teams") {
		let n = (t) => t.reduce((t, n) => t + e.scores[n], 0);
		t = [...e.teams].sort((e, t) => n(t) - n(e)).flatMap((t) => [...t].sort((t, n) => e.scores[n] - e.scores[t]));
	} else t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t] || e.players.indexOf(t) - e.players.indexOf(n));
	return {
		phase: "done",
		winner: e.winner,
		ranking: t,
		scores: { ...e.scores }
	};
}
function we(e) {
	return e.phase === "peek" ? A : e.phase === "settle" ? re : null;
}
var Te = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: b,
	schemas: k,
	setup: le,
	reduce: (e, t, n) => xe(e, t, n.by),
	viewFor: Se,
	status: Ce,
	nextTickIn: we
}, Ee = {
	r: "games/herbalism/r.webp",
	y: "games/herbalism/y.webp",
	g: "games/herbalism/g.webp",
	b: "games/herbalism/b.webp"
}, K = {
	r: "games.herbalism.colorR",
	y: "games.herbalism.colorY",
	g: "games.herbalism.colorG",
	b: "games.herbalism.colorB"
}, De = {
	r: "hb-tone-red",
	y: "hb-tone-yellow",
	g: "hb-tone-green",
	b: "hb-tone-blue"
};
function Oe({ c: e }) {
	return /* @__PURE__ */ f("img", {
		className: "hb-herb-art",
		src: Ee[e],
		alt: "",
		draggable: !1
	});
}
function q({ c: e, compact: t = !1 }) {
	let n = a();
	return /* @__PURE__ */ p("span", {
		className: `hb-color ${De[e]} ${t ? "hb-color--compact" : ""}`,
		"aria-label": n(K[e]),
		children: [/* @__PURE__ */ f("span", {
			className: "hb-color-full",
			children: n(K[e])
		}), /* @__PURE__ */ f("span", {
			className: "hb-color-code",
			"aria-hidden": !0,
			children: e.toUpperCase()
		})]
	});
}
function J({ c: e, small: t = !1 }) {
	let n = a();
	return /* @__PURE__ */ p("span", {
		className: `hb-herb-card ${t ? "hb-herb-card--small" : ""} ${De[e]}`,
		"aria-label": n(K[e]),
		children: [/* @__PURE__ */ f(Oe, { c: e }), /* @__PURE__ */ f(q, {
			c: e,
			compact: t
		})]
	});
}
function ke({ small: e = !1 }) {
	return /* @__PURE__ */ f("span", {
		className: `hb-herb-back ${e ? "hb-herb-back--small" : ""}`,
		"aria-hidden": !0,
		children: "✦"
	});
}
function Ae() {
	return /* @__PURE__ */ p("span", {
		className: "hb-same-emblem",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("span", { className: "hb-same-petal hb-tone-red" }),
			/* @__PURE__ */ f("span", { className: "hb-same-petal hb-tone-yellow" }),
			/* @__PURE__ */ f("span", { className: "hb-same-petal hb-tone-green" }),
			/* @__PURE__ */ f("span", { className: "hb-same-petal hb-tone-blue" }),
			/* @__PURE__ */ f("span", {
				className: "hb-same-center",
				children: "="
			})
		]
	});
}
//#endregion
//#region src/games/herbalism/view-player.tsx
var je = {
	ask: "games.herbalism.actAsk",
	feed: "games.herbalism.actFeed",
	brew: "games.herbalism.actBrew",
	appeal: "games.herbalism.actAppeal",
	cure: "games.herbalism.actCure",
	pass: "games.herbalism.actPass",
	taste: "games.herbalism.actTaste"
}, Me = {
	ask: "games.herbalism.actAskDesc",
	feed: "games.herbalism.actFeedDesc",
	brew: "games.herbalism.actBrewDesc",
	appeal: "games.herbalism.actAppealDesc",
	cure: "games.herbalism.actCureDesc",
	pass: "games.herbalism.actPassDesc",
	taste: "games.herbalism.actTasteDesc"
};
function Ne({ i: e, tappable: t, blocked: r, correct: o, wrong: s, pharmacists: c, markers: l, onTap: u }) {
	let { ref: d } = i(`med:${e}`), m = a(), h = e === 6 ? null : N[e], g = h ? h.map((e) => m(K[e])).join(" + ") : m("games.herbalism.medSame");
	return /* @__PURE__ */ p("button", {
		ref: d,
		type: "button",
		onClick: () => u(e),
		disabled: !t,
		"aria-label": `${g}${t ? ` · ${m("games.herbalism.selectCard")}` : ""}`,
		className: `hb-medicine ${e === 6 ? "hb-medicine--same" : ""} ${t ? "is-legal" : ""} ${r ? "is-blocked" : ""} ${o ? "is-correct" : ""} ${s ? "is-wrong" : ""} ${l.length ? "has-markers" : ""}`,
		children: [
			/* @__PURE__ */ f("span", {
				className: "hb-med-index",
				"aria-hidden": !0,
				children: String(e + 1).padStart(2, "0")
			}),
			o && /* @__PURE__ */ f("span", {
				className: "hb-result-stamp",
				children: m("games.herbalism.resultRight")
			}),
			s && !o && /* @__PURE__ */ f("span", {
				className: "hb-result-stamp hb-result-stamp--wrong",
				children: m("games.herbalism.resultWrong")
			}),
			/* @__PURE__ */ f("span", {
				className: "hb-med-art",
				"aria-hidden": !0,
				children: h ? h.map((e) => /* @__PURE__ */ f(Oe, { c: e }, e)) : /* @__PURE__ */ f(Ae, {})
			}),
			/* @__PURE__ */ f("span", {
				className: "hb-med-colors",
				children: h ? h.map((e) => /* @__PURE__ */ f(q, {
					c: e,
					compact: !0
				}, e)) : m("games.herbalism.medSame")
			}),
			/* @__PURE__ */ f("span", {
				className: "hb-med-pharmacists",
				children: c.map((e) => /* @__PURE__ */ f("span", {
					className: "hb-pharmacist",
					style: { "--player-color": e.hex },
					title: e.name,
					children: /* @__PURE__ */ f("img", {
						src: n[e.avatar % n.length],
						alt: "",
						draggable: !1,
						style: {
							width: "1.75em",
							height: "1.75em",
							maxWidth: "100%",
							maxHeight: "100%",
							display: "block",
							objectFit: "contain",
							pointerEvents: "none",
							borderRadius: "inherit"
						}
					})
				}, e.rid))
			}),
			/* @__PURE__ */ f("span", {
				className: "hb-med-markers",
				children: l.map((e) => /* @__PURE__ */ f("span", {
					className: `hb-marker ${e.follow ? "hb-marker--follow" : "hb-marker--answer"}`,
					style: { "--player-color": e.hex },
					title: `${e.name} · ${m(e.follow ? "games.herbalism.joinFollow" : "games.herbalism.joinAnswer")}`,
					children: e.follow ? "F" : "A"
				}, e.rid))
			})
		]
	});
}
function Pe({ pub: e }) {
	let { ref: t } = i("cure"), { ref: n } = i("cure-card"), r = a(), o = e.phase === "settle" || e.phase === "done" ? e.lastSettle : null;
	return /* @__PURE__ */ p("div", {
		className: "hb-vault",
		ref: t,
		children: [/* @__PURE__ */ p("span", {
			className: "hb-vault-copy",
			children: [/* @__PURE__ */ f("b", { children: r("games.herbalism.cureVault") }), /* @__PURE__ */ f("small", { children: r(o ? "games.herbalism.cureRevealed" : "games.herbalism.cureSealed") })]
		}), /* @__PURE__ */ f("span", {
			className: "hb-vault-cards",
			children: [0, 1].map((e) => /* @__PURE__ */ f("span", {
				className: "hb-card-piece",
				ref: e === 0 ? n : void 0,
				children: o ? /* @__PURE__ */ f(J, {
					c: o.cure[e],
					small: !0
				}) : /* @__PURE__ */ f(ke, { small: !0 })
			}, e))
		})]
	});
}
function Fe({ count: e }) {
	let { ref: t } = i("neutral"), n = a();
	return /* @__PURE__ */ p("div", {
		className: "hb-side-tray",
		ref: t,
		children: [/* @__PURE__ */ f("b", { children: n("games.herbalism.neutral") }), /* @__PURE__ */ p("span", {
			className: "hb-neutral-stack",
			children: [/* @__PURE__ */ f(ke, { small: !0 }), /* @__PURE__ */ p("small", { children: ["×", e] })]
		})]
	});
}
function Ie({ hand: e, choices: t, onChoose: n, hint: r }) {
	let { ref: o } = i("hand"), { ref: s } = i("hand-card"), c = a();
	return /* @__PURE__ */ p("div", {
		className: "hb-hand",
		children: [/* @__PURE__ */ p("div", {
			className: "hb-hand-head",
			children: [/* @__PURE__ */ p("span", { children: [
				c("games.herbalism.handMine"),
				" · ",
				e.length
			] }), r && /* @__PURE__ */ f("small", { children: r })]
		}), /* @__PURE__ */ f("div", {
			className: "hb-hand-cards",
			ref: o,
			children: e.length ? e.map((e, r) => /* @__PURE__ */ f("span", {
				className: "hb-card-piece",
				ref: r === 0 ? s : void 0,
				children: t.includes(e) ? /* @__PURE__ */ f("button", {
					type: "button",
					className: "hb-hand-choice",
					"aria-label": c("games.herbalism.selectColor", { color: c(K[e]) }),
					onClick: () => n(e),
					children: /* @__PURE__ */ f(J, { c: e })
				}) : /* @__PURE__ */ f(J, { c: e })
			}, r)) : /* @__PURE__ */ f("span", {
				className: "hb-hand-empty",
				children: c("games.herbalism.handEmpty")
			})
		})]
	});
}
function Le(e) {
	let t = e.public, n = e.private, { members: i, myRid: m, send: h } = e, g = a(), [_, v] = r(null), y = (e) => i.find((t) => t.rid === e)?.name ?? e, ee = (e) => o[(i.find((t) => t.rid === e)?.colorIndex ?? 0) % o.length].hex, x = n?.hand ?? [], S = t.pharmacist[m] ?? null, C = S === null || S === 6 ? null : N[S], w = t.phase === "play" && t.turn === m, T = new Set(Object.values(t.markers).flatMap((e) => e === "lost" ? [] : [e.card])), E = t.teams?.find((e) => e.includes(m)) ?? null, D = t.teams ? !E.some((e) => t.markers[e]) : !t.markers[m], te = t.players.filter((e) => !t.markers[e]), ne = t.teams?.filter((e) => !e.some((e) => t.markers[e])) ?? [], O = D && ((t.teams ? ne.length === 1 && ne[0].includes(m) : te.length === 1) || x.length === 0 && !t.actions.some((e) => e === "brew" || e === "appeal" || e === "pass" || e === "taste")), k = t.teams ? t.players.filter((e) => e !== m && !E.includes(e)) : t.players.filter((e) => e !== m), A = () => {
		if (!w || !t.moved) return [];
		if (O) return ["cure"];
		let e = [];
		for (let n of t.actions) n === "ask" || n === "feed" ? x.length > 0 && (C === null || C.some((e) => x.includes(e))) && e.push(n) : n === "brew" || n === "appeal" ? e.push(n) : n === "cure" ? D && e.push(n) : n === "taste" ? (t.neutralCount ?? 0) > 0 && e.push(n) : n === "pass" && C !== null && e.push(n);
		return e;
	}, re = (e) => {
		if (w && !t.moved) {
			e !== S && h({
				type: "move",
				card: e
			});
			return;
		}
		if (w && _?.kind === "cureCard") {
			h({
				type: "cure",
				card: e
			}), v(null);
			return;
		}
		if (t.phase === "cureChoose" && t.cureFlow?.waiting === m && _?.kind === "join") {
			if (_.follow && !T.has(e) || !_.follow && T.has(e)) return;
			h({
				type: "cureJoin",
				card: e,
				follow: _.follow
			}), v(null);
			return;
		}
		if (t.phase === "respond" && t.pending?.kind === "tasteMove" && t.pending.actor === m && n?.tasteDrawn) {
			let t = e === 6 ? null : N[e];
			(t === null || t.includes(n.tasteDrawn)) && h({
				type: "tasteMove",
				card: e
			});
		}
	}, M = "info", P = "";
	if (t.phase === "play") w ? (M = "accent", P = t.moved ? g(O ? "games.herbalism.forcedCure" : "games.herbalism.movedHint") : g("games.herbalism.movePrompt")) : P = g("games.herbalism.waitTurn", { name: y(t.turn) });
	else if (t.phase === "respond" && t.pending) {
		let e = t.pending;
		e.kind === "tasteMove" ? (M = e.actor === m ? "accent" : "info", P = e.actor === m ? g("games.herbalism.tasteMovePrompt") : g("games.herbalism.respondWait", { name: y(e.actor) })) : e.target === m ? (M = "accent", P = g(e.kind === "brewSame" ? "games.herbalism.respondBrew" : "games.herbalism.respondAppeal", { name: y(e.actor) })) : P = g("games.herbalism.respondWait", { name: y(e.target) });
	} else if (t.phase === "predict") t.turn === m ? (M = "accent", P = g("games.herbalism.predictPrompt")) : P = g("games.herbalism.waitTurn", { name: y(t.turn) });
	else if (t.phase === "cureChoose" && t.cureFlow) t.cureFlow.waiting === m ? (M = "accent", P = g("games.herbalism.cureJoinPrompt", { name: y(t.cureFlow.actor) })) : P = g("games.herbalism.cureWait", { name: y(t.cureFlow.waiting ?? t.cureFlow.actor) });
	else if (t.phase === "peek" && t.cureFlow) {
		let e = t.cureFlow.peekOrder[t.cureFlow.peekIdx];
		P = e === m ? g("games.herbalism.peekYou") : g("games.herbalism.peekWait", { name: y(e) }), e === m && (M = "warn");
	} else t.phase === "settle" && (M = "done", P = g("games.herbalism.settleTitle", { n: t.round }));
	let F = n?.myPeeks.filter((e) => e.round === t.round).at(-1) ?? null, I = (e) => {
		let t = { ...e.p };
		for (let e of ["a", "b"]) typeof t[e] == "string" && (t[e] = y(t[e]));
		return typeof t.color == "string" && (t.color = g(K[t.color])), g(e.k, t);
	}, ie = (e) => {
		_?.kind === "target" && k.includes(e) && (_.action === "ask" || _.action === "feed" ? v({
			kind: "color",
			action: _.action,
			target: e
		}) : (h({
			type: _.action,
			target: e
		}), v(null)));
	}, L = _?.kind === "color" ? C === null ? [...new Set(x)] : C.filter((e) => x.includes(e)) : t.phase === "respond" && t.pending?.target === m && t.pending.kind !== "tasteMove" ? j.filter((e) => t.pending.kind === "brewSame" ? x.filter((t) => t === e).length >= 2 : x.includes(e)) : [], R = (e) => {
		L.includes(e) && (_?.kind === "color" ? (h({
			type: _.action,
			target: _.target,
			color: e
		}), v(null)) : t.phase === "respond" && h({
			type: "respond",
			color: e
		}));
	}, z = (e, t = !1) => /* @__PURE__ */ p("div", {
		className: "hb-step",
		children: [/* @__PURE__ */ p("span", {
			className: "hb-step-text",
			children: [/* @__PURE__ */ f("span", {
				className: "hb-step-icon",
				"aria-hidden": !0,
				children: "✦"
			}), /* @__PURE__ */ f("span", { children: e })]
		}), t && /* @__PURE__ */ f("button", {
			type: "button",
			onClick: () => v(null),
			children: g("games.herbalism.cancel")
		})]
	}), V = (e, t) => /* @__PURE__ */ p("button", {
		type: "button",
		className: "hb-action-card",
		onClick: t,
		children: [/* @__PURE__ */ f(q, { c: e }), /* @__PURE__ */ f("strong", { children: g(K[e]) })]
	}, e), H;
	if (w && t.moved && _ === null) H = /* @__PURE__ */ f("div", {
		className: "hb-actions",
		children: A().map((e) => /* @__PURE__ */ p("button", {
			type: "button",
			className: e === "cure" ? "hb-action-card hb-action-card--cure" : "hb-action-card",
			onClick: () => {
				e === "cure" ? v({ kind: "cureCard" }) : e === "taste" ? h({ type: "taste" }) : v(e === "pass" ? { kind: "passColor" } : {
					kind: "target",
					action: e
				});
			},
			children: [/* @__PURE__ */ f("strong", { children: g(je[e]) }), /* @__PURE__ */ f("small", { children: g(Me[e]) })]
		}, e))
	});
	else if (_?.kind === "target") H = /* @__PURE__ */ p("div", {
		className: "hb-choice-row",
		children: [k.map((e) => /* @__PURE__ */ f("button", {
			type: "button",
			className: "hb-action-card",
			onClick: () => ie(e),
			children: /* @__PURE__ */ f("strong", { children: y(e) })
		}, e)), /* @__PURE__ */ f("button", {
			type: "button",
			className: "hb-action-card",
			onClick: () => v(null),
			children: /* @__PURE__ */ f("strong", { children: g("games.herbalism.cancel") })
		})]
	});
	else if (_?.kind === "color") H = z(g("games.herbalism.chooseColor"), !0);
	else if (_?.kind === "passColor" && C) H = /* @__PURE__ */ p("div", {
		className: "hb-choice-row",
		children: [C.map((e) => V(e, () => {
			h({
				type: "pass",
				color: e
			}), v(null);
		})), /* @__PURE__ */ f("button", {
			type: "button",
			className: "hb-action-card",
			onClick: () => v(null),
			children: /* @__PURE__ */ f("strong", { children: g("games.herbalism.cancel") })
		})]
	});
	else if (_?.kind === "cureCard" || _?.kind === "join") H = z(_.kind === "join" ? g(_.follow ? "games.herbalism.joinFollow" : "games.herbalism.joinAnswer") : g("games.herbalism.curePlace"), !0);
	else if (t.phase === "respond" && t.pending?.target === m && t.pending.kind !== "tasteMove") H = z(g("games.herbalism.chooseColor"));
	else if (t.phase === "predict" && t.turn === m) {
		let e = t.predictions[m] ?? [], n = j.filter((n) => !e.includes(n) && (t.supply[n] ?? 0) > 0);
		H = /* @__PURE__ */ p("div", {
			className: "hb-choice-row",
			children: [n.map((e) => V(e, () => h({
				type: "predict",
				color: e
			}))), /* @__PURE__ */ f("button", {
				type: "button",
				className: "hb-action-card",
				onClick: () => h({ type: "noPredict" }),
				children: /* @__PURE__ */ f("strong", { children: g("games.herbalism.predictSkip") })
			})]
		});
	} else if (t.phase === "cureChoose" && t.cureFlow?.waiting === m) {
		let e = t.predictions[m] ?? [], n = E ? E.filter((e) => e !== m).flatMap((e) => t.predictions[e] ?? []) : [], r = t.teams ? j.filter((r) => !e.includes(r) && !n.includes(r) && (t.supply[r] ?? 0) > 0) : [];
		H = /* @__PURE__ */ p("div", {
			className: "hb-choice-row",
			children: [
				D && !t.teams && /* @__PURE__ */ f("button", {
					type: "button",
					className: "hb-action-card",
					onClick: () => v({
						kind: "join",
						follow: !0
					}),
					children: /* @__PURE__ */ f("strong", { children: g("games.herbalism.joinFollow") })
				}),
				D && /* @__PURE__ */ f("button", {
					type: "button",
					className: "hb-action-card",
					onClick: () => v({
						kind: "join",
						follow: !1
					}),
					children: /* @__PURE__ */ f("strong", { children: g("games.herbalism.joinAnswer") })
				}),
				r.map((e) => V(e, () => h({
					type: "cureJoin",
					card: null,
					predict: e
				}))),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "hb-action-card",
					onClick: () => h({
						type: "cureJoin",
						card: null
					}),
					children: /* @__PURE__ */ f("strong", { children: g("games.herbalism.joinPass") })
				})
			]
		});
	} else H = z(P || g("games.herbalism.waiting"));
	return /* @__PURE__ */ f(s, {
		adaptive: !0,
		className: "hb-game",
		banner: /* @__PURE__ */ p("div", {
			className: "hb-banner",
			children: [/* @__PURE__ */ f(l, {
				tone: M,
				text: P || g("games.herbalism.waiting"),
				chip: g("games.herbalism.round", { n: t.round }),
				accent: b.accent
			}), /* @__PURE__ */ f("div", {
				className: "hb-players",
				style: { "--hb-players": t.players.length },
				children: /* @__PURE__ */ f(u, {
					members: i,
					myRid: m,
					variant: "plate",
					anchorOf: (e) => `seat:${e}`,
					onPick: _?.kind === "target" ? ie : void 0,
					dimmed: _?.kind === "target" ? (e) => !k.includes(e) : void 0,
					action: (e) => t.phase === "play" || t.phase === "predict" ? e === t.turn ? "pending" : null : t.phase === "respond" && t.pending ? e === t.pending.target ? "pending" : null : t.phase === "cureChoose" && t.cureFlow && e === t.cureFlow.waiting ? "pending" : null,
					status: (e) => {
						if (!t.players.includes(e)) return null;
						let n = t.markers[e], r = t.phase === "settle" ? t.lastSettle?.deltas[e] : void 0;
						return /* @__PURE__ */ p("span", {
							className: "hb-player-status",
							children: [
								/* @__PURE__ */ f("span", {
									className: "hb-player-score",
									children: g("games.herbalism.scoreShort", { n: t.scores[e] ?? 0 })
								}),
								/* @__PURE__ */ p("span", {
									className: "hb-player-count",
									children: ["🂠", t.handCounts[e] ?? 0]
								}),
								n === "lost" && /* @__PURE__ */ f("span", {
									title: g("games.herbalism.markerLost"),
									children: "✖"
								}),
								n && n !== "lost" && /* @__PURE__ */ f("span", {
									className: "hb-player-marker",
									children: n.follow ? "F" : "A"
								}),
								(t.predictions[e] ?? []).map((e) => /* @__PURE__ */ f(q, {
									c: e,
									compact: !0
								}, e)),
								r !== void 0 && r !== 0 && /* @__PURE__ */ f("span", {
									className: r > 0 ? "hb-delta hb-delta--up" : "hb-delta hb-delta--down",
									children: r > 0 ? `+${r}` : r
								})
							]
						});
					}
				})
			})]
		}),
		actionsHeight: "hb-action-slot",
		actions: H,
		scroll: !1,
		overlay: /* @__PURE__ */ p(d, { children: [t.phase === "settle" && t.lastSettle && /* @__PURE__ */ f("div", {
			className: "hb-overlay",
			children: /* @__PURE__ */ f("strong", { children: t.lastSettle.solver ? g("games.herbalism.solverIs", { name: y(t.lastSettle.solver) }) : g("games.herbalism.noSolver") })
		}), t.phase === "peek" && F && /* @__PURE__ */ p("div", {
			className: "hb-overlay",
			children: [/* @__PURE__ */ f("strong", { children: g(F.ok ? "games.herbalism.peekOk" : "games.herbalism.peekNo") }), /* @__PURE__ */ p("div", {
				className: "hb-overlay-cards",
				children: [g("games.herbalism.myCure"), F.cure.map((e, t) => /* @__PURE__ */ f(J, {
					c: e,
					small: !0
				}, t))]
			})]
		})] }),
		children: /* @__PURE__ */ f("div", {
			className: "hb-desk",
			children: /* @__PURE__ */ f("div", {
				className: "hb-desk-scroll",
				children: /* @__PURE__ */ p("div", {
					className: "hb-desk-inner",
					children: [
						/* @__PURE__ */ p("div", {
							className: "hb-desk-title",
							children: [/* @__PURE__ */ f("strong", { children: g("games.herbalism.deskTitle") }), /* @__PURE__ */ f("small", { children: g("games.herbalism.targetWin", { n: t.target }) })]
						}),
						/* @__PURE__ */ p("div", {
							className: "hb-vault-row",
							children: [/* @__PURE__ */ f(Pe, { pub: t }), t.neutralCount !== null && /* @__PURE__ */ f(Fe, { count: t.neutralCount })]
						}),
						/* @__PURE__ */ f("div", {
							className: "hb-med-grid",
							children: [...N.keys(), 6].map((e) => {
								let r = e === 6 ? null : N[e], a = w && !t.moved && e !== S || w && _?.kind === "cureCard" || t.phase === "cureChoose" && t.cureFlow?.waiting === m && _?.kind === "join" && (_.follow ? T.has(e) : !T.has(e)) || t.phase === "respond" && t.pending?.kind === "tasteMove" && t.pending.actor === m && !!n?.tasteDrawn && (r === null || r.includes(n.tasteDrawn));
								return /* @__PURE__ */ f(Ne, {
									i: e,
									tappable: a,
									blocked: !!_ && !a && (_.kind === "cureCard" || _.kind === "join"),
									correct: t.phase === "settle" && !!t.lastSettle && B(e, t.lastSettle.cure),
									wrong: t.phase === "settle" && !!t.lastSettle?.wrongCards.includes(e),
									pharmacists: t.players.filter((n) => t.pharmacist[n] === e).map((e) => ({
										rid: e,
										hex: ee(e),
										name: y(e),
										avatar: i.find((t) => t.rid === e)?.avatar ?? 0
									})),
									markers: Object.entries(t.markers).flatMap(([t, n]) => n !== "lost" && n.card === e ? [{
										rid: t,
										follow: n.follow,
										hex: ee(t),
										name: y(t)
									}] : []),
									onTap: re
								}, e);
							})
						}),
						/* @__PURE__ */ f(Ie, {
							hand: x,
							choices: L,
							onChoose: R,
							hint: n?.tasteDrawn ? g("games.herbalism.tasteDrawn", { color: g(K[n.tasteDrawn]) }) : L.length ? g("games.herbalism.tapHand") : null
						}),
						/* @__PURE__ */ f("div", {
							className: "hb-log",
							children: /* @__PURE__ */ f(c, {
								log: t.log,
								line: I
							})
						})
					]
				})
			})
		})
	});
}
//#endregion
//#region src/games/herbalism/bot.ts
function Y(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
}
var X = (e) => e[Y(e.length)];
function Re(e) {
	let t = [
		"r",
		"r",
		"y",
		"y",
		"y",
		"g",
		"g",
		"g",
		"g",
		"b",
		"b",
		"b",
		"b",
		"b"
	];
	for (let n of e?.hand ?? []) t.splice(t.indexOf(n), 1);
	let n = [];
	return N.forEach(([e, r], i) => {
		t.includes(e) && t.includes(r) && n.push(i);
	}), j.some((e) => t.filter((t) => t === e).length >= 2) && n.push(6), n;
}
function ze(e) {
	let t = e?.myPeeks.at(-1);
	if (!t) return null;
	let [n, r] = t.cure;
	if (n === r) return 6;
	let i = N.findIndex(([e, t]) => e === n && t === r || e === r && t === n);
	return i >= 0 ? i : null;
}
function Be(e, t) {
	let n = e.public, r = e.private, i = r?.hand ?? [], a = n.pharmacist[t] ?? null, o = a === null || a === 6 ? null : N[a], s = n.teams?.find((e) => e.includes(t)) ?? null, c = n.teams ? !s.some((e) => n.markers[e]) : !n.markers[t], l = n.players.filter((e) => !n.markers[e]), u = n.teams?.filter((e) => !e.some((e) => n.markers[e])) ?? [];
	return {
		pub: n,
		priv: r,
		hand: i,
		myMed: a,
		myPair: o,
		myTeam: s,
		markerAlive: c,
		forced: c && ((n.teams ? u.length === 1 && u[0].includes(t) : l.length === 1) || i.length === 0 && !n.actions.some((e) => e === "brew" || e === "appeal" || e === "pass" || e === "taste")),
		targets: n.teams ? n.players.filter((e) => e !== t && !s.includes(e)) : n.players.filter((e) => e !== t)
	};
}
function Ve(e, t) {
	let { pub: n, hand: r, myPair: i, targets: a } = Be(e, t), o = [...a].sort((e, t) => (n.handCounts[t] ?? 0) - (n.handCounts[e] ?? 0))[0];
	if (!o) return null;
	let s = i === null ? [...new Set(r)] : i.filter((e) => r.includes(e));
	for (let e of n.actions) {
		if ((e === "ask" || e === "feed") && s.length > 0) return {
			type: e,
			target: o,
			color: s[0]
		};
		if (e === "appeal") return {
			type: "appeal",
			target: o
		};
		if (e === "brew") return {
			type: "brew",
			target: o
		};
	}
	return n.mode === "duo" && (n.neutralCount ?? 0) > 0 ? { type: "taste" } : null;
}
var He = (e, t) => {
	let { rid: n, difficulty: r } = t, { pub: i, priv: a, hand: o, myMed: s, myPair: c, markerAlive: l, forced: u } = Be(e, n), d = r === "weak";
	if (i.phase === "respond" && i.pending && i.pending.target === n && i.pending.kind !== "tasteMove") {
		let e = i.pending.kind === "brewSame" ? j.filter((e) => o.filter((t) => t === e).length >= 2) : j.filter((e) => o.includes(e));
		if (!e.length) return null;
		let t = [...e].sort((e, t) => o.filter((t) => t === e).length - o.filter((e) => e === t).length);
		return { action: {
			type: "respond",
			color: d ? X(e) : t[0]
		} };
	}
	if (i.phase === "respond" && i.pending?.kind === "tasteMove" && i.pending.actor === n && a?.tasteDrawn) return { action: {
		type: "tasteMove",
		card: X([
			0,
			1,
			2,
			3,
			4,
			5,
			6
		].filter((e) => e === 6 || N[e].includes(a.tasteDrawn)))
	} };
	if (i.phase === "cureChoose" && i.cureFlow?.waiting === n) {
		let t = ze(a), r = new Set(Object.values(i.markers).flatMap((e) => e === "lost" ? [] : [e.card]));
		if (t !== null && l) {
			if (!r.has(t)) return { action: {
				type: "cureJoin",
				card: t,
				follow: !1
			} };
			if (!i.teams) return { action: {
				type: "cureJoin",
				card: t,
				follow: !0
			} };
		}
		if (!d && l && !i.teams && r.size > 0 && Y(4) === 0) return { action: {
			type: "cureJoin",
			card: X([...r]),
			follow: !0
		} };
		if (i.teams && !d) {
			let t = i.predictions[n] ?? [], r = Be(e, n).myTeam?.filter((e) => e !== n).flatMap((e) => i.predictions[e] ?? []) ?? [], a = j.filter((e) => !t.includes(e) && !r.includes(e) && (i.supply[e] ?? 0) > 0);
			if (a.length && Y(2) === 0) return { action: {
				type: "cureJoin",
				card: null,
				predict: X(a)
			} };
		}
		return { action: {
			type: "cureJoin",
			card: null
		} };
	}
	if (i.phase === "predict" && i.turn === n) {
		let e = i.predictions[n] ?? [], t = ze(a), r = null;
		if (a?.myPeeks.length) r = a.myPeeks.at(-1).cure.find((t) => !e.includes(t) && (i.supply[t] ?? 0) > 0) ?? null;
		else if (!d && !t) {
			let t = Re(a), n = /* @__PURE__ */ new Map();
			for (let e of t) if (e !== 6) for (let t of N[e]) n.set(t, (n.get(t) ?? 0) + 1);
			r = [...n.entries()].filter(([t]) => !e.includes(t) && (i.supply[t] ?? 0) > 0).sort((e, t) => t[1] - e[1])[0]?.[0] ?? null;
		}
		return { action: r ? {
			type: "predict",
			color: r
		} : { type: "noPredict" } };
	}
	if (i.phase !== "play" || i.turn !== n) return null;
	if (!i.moved) {
		let e = [
			0,
			1,
			2,
			3,
			4,
			5,
			6
		].filter((e) => e !== s);
		if (!e.length) return null;
		if (d) return { action: {
			type: "move",
			card: X(e)
		} };
		let t = Re(a);
		return { action: {
			type: "move",
			card: e.map((e) => {
				let n = 0;
				return t.includes(e) && (n += 2), e !== 6 && N[e].some((e) => o.includes(e)) && (n += 1), {
					i: e,
					score: n
				};
			}).sort((e, t) => t.score - e.score)[0].i
		} };
	}
	if (l) {
		let e = ze(a), t = Re(a), r = !d && (t.length <= 2 || (i.scores[n] ?? 0) < i.target - 3) && Y(3) === 0;
		if (u || e !== null || t.length === 1 || r) return { action: {
			type: "cure",
			card: e ?? (t.length ? X(t) : Y(7))
		} };
	}
	if (i.mode === "teams" && c && !d && Y(3) === 0) {
		let e = c.filter((e) => o.includes(e));
		if (e.length) return { action: {
			type: "pass",
			color: X(e)
		} };
	}
	let f = d && l && Y(6) === 0 ? {
		type: "cure",
		card: Y(7)
	} : Ve(e, n);
	return f ? { action: f } : l ? { action: {
		type: "cure",
		card: Y(7)
	} } : null;
};
//#endregion
//#region src/games/herbalism/fx.tsx
function Z(e) {
	return e.anchor("cure-card") ?? {
		w: 30,
		h: 42
	};
}
function Q({ c: e, back: t = !1, size: n }) {
	return /* @__PURE__ */ f("span", {
		className: "hb-fx-card",
		style: {
			width: n.w,
			height: n.h,
			fontSize: n.w * 8 / 30
		},
		children: t ? /* @__PURE__ */ f(ke, { small: !0 }) : /* @__PURE__ */ f(J, {
			c: e ?? "g",
			small: !0
		})
	});
}
function Ue(e, t, n, r) {
	let i = t ?? {
		...e,
		...r
	}, a = Math.max(4, i.w * 6 / 44), o = Math.max(1, Math.floor((e.w + a) / (i.w + a))), s = Math.max(1, Math.floor((e.h + a) / (i.h + a))), c = Math.min(n, o * s - 1);
	return {
		x: Math.max(e.x, Math.min(e.x + e.w - i.w, i.x + c % o * (i.w + a))),
		y: Math.max(e.y, Math.min(e.y + e.h - i.h, i.y + Math.floor(c / o) * (i.h + a))),
		w: i.w,
		h: i.h
	};
}
function $(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
var We = {
	deal(e, t) {
		let n = e.secret;
		if (n && Array.isArray(n.cards)) {
			let e = t.anchor("cure"), r = t.anchor("hand");
			if (!e || !r) return null;
			let i = n.cards, a = Z(t), o = t.anchor("hand-card");
			return {
				ms: 320 + i.length * 60,
				node: i.map((t, n) => /* @__PURE__ */ f(h, {
					from: e,
					to: Ue(r, o, n, a),
					ms: 320,
					delay: n * 60,
					children: /* @__PURE__ */ f(Q, {
						c: t,
						size: a
					})
				}, n))
			};
		}
		let r = t.anchor("cure"), i = $(t, e.rid);
		if (!r || !i) return null;
		let a = e.data?.count, o = typeof a == "number" ? a : 3;
		return {
			ms: 320 + o * 60,
			node: Array.from({ length: o }, (e, n) => /* @__PURE__ */ f(h, {
				from: r,
				to: i,
				ms: 320,
				delay: n * 60,
				children: /* @__PURE__ */ f(Q, {
					back: !0,
					size: Z(t)
				})
			}, n))
		};
	},
	dealNeutral(e, t) {
		let n = t.anchor("cure"), r = t.anchor("neutral");
		return !n || !r ? null : {
			ms: 600,
			node: Array.from({ length: 4 }, (e, i) => /* @__PURE__ */ f(h, {
				from: n,
				to: r,
				ms: 320,
				delay: i * 60,
				children: /* @__PURE__ */ f(Q, {
					back: !0,
					size: Z(t)
				})
			}, i))
		};
	},
	give(e, t) {
		let n = e.data, r = $(t, e.rid), i = typeof n?.to == "string" ? $(t, n.to) : null;
		if (!r || !i) return null;
		let a = e.secret, o = a && Array.isArray(a.cards) ? a.cards : null, s = o ? o.length : typeof n?.n == "number" ? n.n : 1;
		return {
			ms: 500,
			node: Array.from({ length: s }, (e, n) => /* @__PURE__ */ f(h, {
				from: r,
				to: i,
				ms: 420,
				delay: n * 60,
				children: /* @__PURE__ */ f(Q, {
					c: o?.[n],
					back: !o,
					size: Z(t)
				})
			}, n))
		};
	},
	take(e, t) {
		let n = e.data, r = $(t, e.rid), i = typeof n?.to == "string" ? n.to === "neutral" ? t.anchor("neutral") : $(t, n.to) : null;
		if (!r || !i) return null;
		let a = typeof n?.n == "number" ? n.n : 1;
		return {
			ms: 500,
			node: Array.from({ length: a }, (e, n) => /* @__PURE__ */ f(h, {
				from: r,
				to: i,
				ms: 420,
				delay: n * 50,
				children: /* @__PURE__ */ f(Q, {
					back: !0,
					size: Z(t)
				})
			}, n))
		};
	},
	taste(e, t) {
		let n = t.anchor("neutral"), r = $(t, e.rid);
		if (!n || !r) return null;
		let i = e.secret, a = i && Array.isArray(i.cards) ? i.cards[0] : void 0;
		return {
			ms: 600,
			node: /* @__PURE__ */ f(h, {
				from: n,
				to: r,
				ms: 480,
				children: /* @__PURE__ */ f(Q, {
					c: a,
					back: !a,
					size: Z(t)
				})
			})
		};
	},
	peek(e, t) {
		let n = t.anchor("cure");
		if (!n) return {
			ms: A,
			node: null
		};
		let r = e.secret;
		return r && Array.isArray(r.cure) ? {
			ms: A,
			node: /* @__PURE__ */ f(m, {
				at: n,
				ms: A,
				children: /* @__PURE__ */ p("span", {
					className: "flex items-center gap-1",
					children: [r.cure.map((e, n) => /* @__PURE__ */ f(Q, {
						c: e,
						size: Z(t)
					}, n)), /* @__PURE__ */ f("span", {
						className: "font-black",
						children: r.ok ? "✓" : "✗"
					})]
				})
			})
		} : {
			ms: A,
			node: /* @__PURE__ */ f(g, {
				at: n,
				ms: 900
			})
		};
	},
	reveal() {
		return {
			ms: re,
			node: null
		};
	},
	score(e, t) {
		let n = e.data, r = $(t, e.rid);
		return !r || typeof n?.delta != "number" || n.delta === 0 ? null : {
			ms: 900,
			node: /* @__PURE__ */ f(m, {
				at: r,
				ms: 900,
				children: /* @__PURE__ */ f("span", {
					className: `font-mono font-black tabular-nums ${n.delta > 0 ? "text-done-ink" : "text-danger-ink"}`,
					children: n.delta > 0 ? `+${n.delta}` : n.delta
				})
			})
		};
	},
	round() {
		return {
			ms: 900,
			node: null
		};
	}
};
//#endregion
//#region src/games/herbalism/game-over.tsx
function Ge({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ f("div", {
		className: "hb-over",
		children: /* @__PURE__ */ f(_, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: b.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region src/games/herbalism/options.tsx
function Ke({ value: e, onChange: t }) {
	let n = a(), r = O.safeParse(e), i = r.success ? r.data : O.parse(void 0), o = (e, n) => /* @__PURE__ */ f(v, {
		name: "herbalism-actions",
		value: e,
		checked: i.actions === e,
		label: n,
		accent: b.accent,
		onChange: () => t({
			...i,
			actions: e
		})
	}, e), s = (e, n, r) => /* @__PURE__ */ f(ee, {
		checked: i[e],
		label: n,
		hint: r,
		accent: b.accent,
		onChange: () => t({
			...i,
			[e]: !i[e]
		})
	}, e);
	return /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-2",
		children: [
			/* @__PURE__ */ p(y, {
				title: n("games.herbalism.optActions"),
				columns: 3,
				children: [
					o("simple", n("games.herbalism.optActionsSimple")),
					o("normal", n("games.herbalism.optActionsNormal")),
					o("advanced", n("games.herbalism.optActionsAdvanced"))
				]
			}),
			s("prediction", n("games.herbalism.optPrediction"), n("games.herbalism.optPredictionDesc")),
			s("teams", n("games.herbalism.optTeams"), n("games.herbalism.optTeamsDesc"))
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/herbalism/entry.tsx
var qe = {
	definition: Te,
	View: Le,
	bot: He,
	fx: We,
	OverView: Ge,
	Options: Ke,
	locales: {
		zh: {
			name: "本草",
			desc: "秘密交换药材信息,抢先推导出平息瘟疫的两味解药",
			rules: "目标:抢先猜出本局解药(两味药材)得分,先积 6 分者获胜(2 人与 2v2 为 7 分)。\n准备:\n· 将 2 张药材卡面朝下放在解药行动卡下，作为本局解药；所有玩家均不得查看。\n· 其余药材卡平均发作手牌,内容保密、数量公开。\n· 药引卡共 7 张：6 张分别对应六种双色组合，另有 1 张为同色药引卡。\n流程:\n· 每回合必须先把药师移到另一张药引卡,再执行一个行动。\n· 问药:秘密交给对方 1 张药引卡上其中一色的药材卡,对方公开说明自己手中另一种颜色的药材卡数量。\n· 喂药:给药方式与问药相同,对方再归还手上全部另一色的卡。\n· 组药:向对方索取药引卡两色各 1 张;站在同色药引卡上时,对方任选 2 张同色卡交出。\n· 求药:对方选药引卡两色之一,把手上该色的卡全部给你;同色卡则任选一种颜色。\n· 解药:把 Answer 标记放到一张药引卡上,宣告解答。\n· 其他人顺次选择:放到另一张空药引卡、跟随放置到同一张药引卡上（Follow）,或放弃。\n· 放置标记者依次秘密查看解药:自己所选药引颜色与解药一致的玩家成为解答者；猜错的玩家失去所放置的标记,且其下个回合被跳过。\n结算:\n· 解答者获得 3 分;跟随放置且猜中解药颜色的玩家获得 1 分，猜错的玩家扣除 1 分;放置 Answer 标记但猜错的玩家不扣分。\n· 猜测标记(进阶):试药行动后可获得 1 枚,用于预测解药成分。\n· 局末结算时预测命中获得 1 分、落空扣 1 分,分数不会低于 0。\n变体:\n· 2 人游戏中，增设一名持有 4 张手牌的中立玩家；对中立玩家只能执行试药行动。\n· 试药:随机抽中立玩家的 1 张手牌,查看后收入自己手牌。\n· 随后把药师移到含该色的药引卡,再把手上另一色的卡全部交给中立玩家。\n· 2v2(4 人)游戏中，坐在对面的玩家互为队友，试药只能指定对手。每队共用 1 枚解药标记，不使用 Follow 标记。\n· 传药(仅 2v2):与队友按药引卡两色互换全部手牌;站在同色药引卡上时不能传药。",
			colorR: "红",
			colorY: "黄",
			colorG: "绿",
			colorB: "蓝",
			medSame: "同色",
			actAsk: "问药",
			actFeed: "喂药",
			actBrew: "组药",
			actAppeal: "求药",
			actCure: "解药",
			actPass: "传药",
			actTaste: "试药",
			actAskDesc: "给对方 1 张,对方公开另一色数量",
			actFeedDesc: "给对方 1 张,对方归还全部另一色",
			actBrewDesc: "向对方索取两色各 1 张",
			actAppealDesc: "索取对方一色的全部",
			actCureDesc: "在药引卡上落下 Answer 印章",
			actPassDesc: "与队友按药引两色互换",
			actTasteDesc: "抽中立玩家 1 张手牌,再交还另一色",
			round: "第 {{n}} 局",
			targetWin: "{{n}} 分获胜",
			movePrompt: "先把药师移到另一张药引卡",
			movedHint: "再选一个行动",
			yourTurn: "轮到你了",
			waitTurn: "等 {{name}} 行动…",
			chooseTarget: "选择目标",
			chooseColor: "选择给出的颜色",
			forcedCure: "只能执行解药",
			curePlace: "把 Answer 标记放到一张药引卡上",
			cureWait: "等 {{name}} 表态是否解答…",
			cureJoinPrompt: "{{name}} 发起解药,你要放置标记吗?",
			joinAnswer: "Answer(放空卡)",
			joinFollow: "Follow(放占卡)",
			joinPass: "放弃",
			joinPredict: "拿猜测标记",
			peekYou: "正在查看解药…",
			peekWait: "等 {{name}} 查看解药…",
			peekOk: "颜色符合,解答正确!",
			peekNo: "颜色不符,失去解药标记",
			myCure: "解药是:",
			respondBrew: "{{name}} 向你组药:选 2 张同色卡交出",
			respondAppeal: "{{name}} 向你求药:选一色全部交出",
			respondWait: "等 {{name}} 回应…",
			tasteDrawn: "抽到了 {{color}} 药材",
			tasteMovePrompt: "把药师移到含该色的药引卡(或同色卡)",
			predictPrompt: "要拿 1 枚猜测标记预测解药成分吗?",
			predictSkip: "不预测",
			predicted: "已预测:",
			handMine: "我的手牌",
			handEmpty: "空手",
			tapHand: "点选要交出的药材",
			selectColor: "选择{{color}}药材",
			selectCard: "选择这张药引卡",
			cancel: "返回",
			waiting: "等待下一步…",
			deskTitle: "本草药案",
			cureVault: "封存解药",
			cureSealed: "两味药材 · 尚未揭示",
			cureRevealed: "真相已揭示",
			resultRight: "命中",
			resultWrong: "失误",
			markerLost: "解药标记已失去",
			neutral: "中立玩家",
			settleTitle: "第 {{n}} 局结算",
			solverIs: "{{name}} 解出解药",
			noSolver: "本局无人解出",
			cureWas: "解药是",
			scoreShort: "{{n}} 分",
			teamA: "A 队",
			teamB: "B 队",
			optActions: "行动卡组合",
			optActionsSimple: "简单(问药+解药)",
			optActionsNormal: "普通(喂药+求药+解药)",
			optActionsAdvanced: "进阶(全部五种)",
			optPrediction: "猜测标记",
			optPredictionDesc: "进阶规则:试药行动后可预测解药成分,局末命中获得 1 分、落空扣 1 分",
			optTeams: "2v2 组队(4 人)",
			optTeamsDesc: "对座为队友,新增传药行动,每队共用 1 枚解药标记,启用猜测标记,先到 7 分",
			logRound: "—— 第 {{n}} 局开始 ——",
			logAsk: "{{a}} 问药 {{b}}:{{b}} 声明另一色有 {{n}} 张",
			logFeed: "{{a}} 喂药 {{b}}:收回 {{n}} 张",
			logBrew: "{{a}} 向 {{b}} 组药:获得 {{n}} 张",
			logAppeal: "{{a}} 向 {{b}} 求药:获得 {{n}} 张",
			logPass: "{{a}} 与 {{b}} 传药:给出 {{n}} 张,换回 {{m}} 张",
			logTaste: "{{a}} 与中立玩家试药",
			logTasteMove: "{{a}} 交还 {{n}} 张给中立玩家",
			logCure: "{{a}} 发起解药",
			logCureJoin: "{{a}} 放置了解药标记",
			logCurePass: "{{a}} 放弃解答",
			logPredict: "{{a}} 预测解药含 {{color}}",
			logPeekOk: "{{a}} 查看解药:解答正确!",
			logPeekNo: "{{a}} 查看解药:颜色不符",
			logSolve: "{{a}} 成为解答者,获得 3 分",
			logNoSolver: "所有玩家均解答失败,本局流局",
			errNotYourTurn: "还没轮到你",
			errBadPhase: "现在不能这么做",
			errMustMove: "药师必须移到另一张药引卡",
			errMustMoveFirst: "先移动药师",
			errAlreadyMoved: "本回合已经移动过药师",
			errBadTarget: "不能指定这个目标",
			errNoCard: "手上没有对应的药材卡",
			errBadColor: "颜色不符合药引卡",
			errNoMarker: "没有可用的解药标记",
			errCardOccupied: "这张药引卡已有解药标记",
			errCardEmpty: "这张药引卡上没有可跟的标记",
			errNotPending: "没有等待你回应的请求",
			errSupply: "该颜色的猜测标记已拿完",
			errPredicted: "你已经拿过这个颜色的猜测标记",
			errTeamColor: "同队不能拿相同颜色的猜测标记",
			errPassSame: "站在同色药引卡上不能传药"
		},
		en: {
			name: "Herbalism",
			desc: "Trade ingredient clues in secret and be first to deduce the two-card cure",
			rules: "Goal: be the first to name the cure (two ingredients) to score; first to 6 points wins (7 in 2-player and 2v2).\nSetup:\n· Two ingredient cards go face-down under the Curing card as this round’s cure; nobody may look at them.\n· Deal the remaining ingredient cards evenly to the players. Keep their contents secret, but make the number of cards in each hand public.\n· Use seven medicine cards: one for each of the six two-color pairs and one same-color card.\nPlay:\n· Each turn you must first move your pharmacist to a different medicine card, then take one action.\n· Inquiring: secretly give the receiver 1 card of one of the medicine card’s colors; they publicly announce how many of the other color they hold.\n· Feeding: give a card the same way as Inquiring; the receiver then returns every card of the other color.\n· Brewing: demand 1 card of each of the medicine card’s two colors; on the same-color card they choose any 2 same-color cards to hand over.\n· Appealing: the receiver picks one of the medicine card’s two colors and gives you every card of it; on the same-color card they pick any one color.\n· Curing: place your Answer marker on a medicine card to declare your solution.\n· The others in turn choose: place on a different empty medicine card, Follow onto the same card, or pass.\n· Marked players then secretly peek at the cure in order: if the colors on your chosen medicine card match the cure, you become the solver. Otherwise, you lose your placed marker and your next turn is skipped.\nScoring:\n· The solver gains 3 points; a correct Follow gains 1 point, a wrong Follow loses 1 point; an incorrect Answer does not lose points.\n· Prediction markers (advanced): after a tasting action you may take 1 to bet on a cure ingredient.\n· At game end a correct prediction gains 1 point and a wrong one loses 1 point; scores never drop below 0.\nVariants:\n· 2 players: a neutral player holds 4 cards; you may only take the tasting action with them.\n· Tasting: draw 1 card at random from the neutral player’s hand, look at it, and add it to your hand.\n· Then move your pharmacist to a medicine card of that color and hand all your cards of the other color to the neutral player.\n· In 2v2 with four players, partners sit opposite each other and tasting actions can target only opponents. Each team shares one cure marker, and Follow markers are not used.\n· Communicating (2v2 only): swap all cards of the medicine card’s two colors with your partner; not allowed while standing on the same-color card.",
			colorR: "red",
			colorY: "yellow",
			colorG: "green",
			colorB: "blue",
			medSame: "same",
			actAsk: "Inquire",
			actFeed: "Feed",
			actBrew: "Brew",
			actAppeal: "Appeal",
			actCure: "Cure",
			actPass: "Swap",
			actTaste: "Taste",
			actAskDesc: "Give them 1 card; they announce the other color count",
			actFeedDesc: "Give them 1 card; they return all of the other color",
			actBrewDesc: "Demand 1 of each medicine color from them",
			actAppealDesc: "Demand all of one color from them",
			actCureDesc: "Place your Answer marker on a medicine card",
			actPassDesc: "Swap colors with your partner",
			actTasteDesc: "Draw 1 from the neutral player, return the other color",
			round: "Round {{n}}",
			targetWin: "{{n}} points to win",
			movePrompt: "Move your pharmacist to another medicine card first",
			movedHint: "Now pick an action",
			yourTurn: "Your turn",
			waitTurn: "Waiting for {{name}}…",
			chooseTarget: "Choose a target",
			chooseColor: "Choose the color to give",
			forcedCure: "Curing is your only option",
			curePlace: "Place your Answer marker on a medicine card",
			cureWait: "Waiting for {{name}} to decide…",
			cureJoinPrompt: "{{name}} started curing — place your marker?",
			joinAnswer: "Answer (empty card)",
			joinFollow: "Follow (occupied card)",
			joinPass: "Pass",
			joinPredict: "Take a prediction",
			peekYou: "Peeking at the cure…",
			peekWait: "Waiting for {{name}} to peek…",
			peekOk: "Colors match — correct!",
			peekNo: "No match — cure marker lost",
			myCure: "The cure is:",
			respondBrew: "{{name}} brews from you: give 2 cards of one color",
			respondAppeal: "{{name}} appeals to you: give all of one color",
			respondWait: "Waiting for {{name}} to respond…",
			tasteDrawn: "You drew a {{color}} ingredient",
			tasteMovePrompt: "Move your pharmacist to a medicine card with that color (or the same-color card)",
			predictPrompt: "Take a prediction marker on the cure?",
			predictSkip: "Skip",
			predicted: "Predictions:",
			handMine: "My hand",
			handEmpty: "empty",
			tapHand: "Tap an ingredient to give",
			selectColor: "Select a {{color}} ingredient",
			selectCard: "Select this medicine card",
			cancel: "Back",
			waiting: "Waiting for the next step…",
			deskTitle: "Herbalist desk",
			cureVault: "Sealed cure",
			cureSealed: "Two ingredients · hidden",
			cureRevealed: "Cure revealed",
			resultRight: "Match",
			resultWrong: "Miss",
			markerLost: "Cure marker lost",
			neutral: "Neutral player",
			settleTitle: "Round {{n}} results",
			solverIs: "{{name}} found the cure",
			noSolver: "Nobody solved this round",
			cureWas: "The cure was",
			scoreShort: "{{n}} pts",
			teamA: "Team A",
			teamB: "Team B",
			optActions: "Action cards",
			optActionsSimple: "Easy (Inquire + Cure)",
			optActionsNormal: "Normal (Feed + Appeal + Cure)",
			optActionsAdvanced: "Advanced (all five)",
			optPrediction: "Prediction markers",
			optPredictionDesc: "Advanced rule: bet on cure colors after tasting actions; +1 point if right, −1 if wrong",
			optTeams: "2v2 teams (4 players)",
			optTeamsDesc: "Partners sit opposite, adds the Swap action, one shared cure marker per team, predictions on, first to 7",
			logRound: "—— Round {{n}} begins ——",
			logAsk: "{{a}} asks {{b}}: {{b}} announces {{n}} of the other color",
			logFeed: "{{a}} feeds {{b}}: {{n}} returned",
			logBrew: "{{a}} brews from {{b}}: got {{n}}",
			logAppeal: "{{a}} appeals to {{b}}: got {{n}}",
			logPass: "{{a}} swaps with {{b}}: gave {{n}}, got {{m}}",
			logTaste: "{{a}} tastes with the neutral player",
			logTasteMove: "{{a}} returned {{n}} to the neutral player",
			logCure: "{{a}} starts curing",
			logCureJoin: "{{a}} placed a cure marker",
			logCurePass: "{{a}} passed",
			logPredict: "{{a}} predicts the cure holds {{color}}",
			logPeekOk: "{{a}} peeked: correct!",
			logPeekNo: "{{a}} peeked: no match",
			logSolve: "{{a}} is the solver, gaining 3 points",
			logNoSolver: "Everyone failed — round is a wash",
			errNotYourTurn: "Not your turn",
			errBadPhase: "Not allowed right now",
			errMustMove: "The pharmacist must move to a different card",
			errMustMoveFirst: "Move your pharmacist first",
			errAlreadyMoved: "Pharmacist already moved this turn",
			errBadTarget: "Invalid target",
			errNoCard: "You hold no matching ingredient card",
			errBadColor: "Color does not match the medicine card",
			errNoMarker: "No cure marker available",
			errCardOccupied: "That medicine card already has a marker",
			errCardEmpty: "No marker to follow on that card",
			errNotPending: "Nothing is waiting for your response",
			errSupply: "That prediction color is gone",
			errPredicted: "You already took that color",
			errTeamColor: "Teammates cannot take the same prediction color",
			errPassSame: "Cannot swap from the same-color medicine card"
		}
	}
};
//#endregion
export { qe as default };
