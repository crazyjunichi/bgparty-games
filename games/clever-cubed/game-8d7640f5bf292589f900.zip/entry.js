import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as ee } from "@bgparty/sdk/ui/player-strip";
import { gridCell as te } from "@bgparty/sdk/sheet-geometry";
import { SheetMark as u } from "@bgparty/sdk/sheet-mark";
import { SheetText as d, SheetView as ne } from "@bgparty/sdk/sheet-view";
import { Fragment as re, jsx as f, jsxs as p } from "react/jsx-runtime";
import { GameOverScreen as m } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/clever-cubed/meta.ts
var h = {
	id: "clever-cubed",
	tier: "beta",
	mechanics: [
		"roll-and-write",
		"drafting",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.clever-cubed.name",
	descKey: "games.clever-cubed.desc",
	rulesKey: "games.clever-cubed.rules",
	icon: "🦊",
	iconImg: "games/clever-cubed.webp",
	rulesUrl: { de: "https://rules.bgparty.uuppi.com/clever-cubed/de.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#e8590c",
	releasedAt: "2026-09-28",
	search: {
		py: "li fang cong ming",
		init: "lfcm"
	},
	hotseat: "open"
}, g = t.enum([
	"yellow",
	"turq",
	"blue",
	"brown",
	"pink",
	"white"
]), _ = t.enum([
	"yellow",
	"turq",
	"blue",
	"brown",
	"pink"
]), ie = t.enum([
	"reroll",
	"joker",
	"extra"
]), v = t.discriminatedUnion("area", [
	t.object({
		area: t.literal("yellow"),
		cell: t.int().min(0).max(17)
	}),
	t.object({
		area: t.literal("turq"),
		cells: t.array(t.int().min(0).max(29)).min(1).max(5)
	}),
	t.object({
		area: t.literal("blue"),
		side: t.enum(["left", "right"])
	}),
	t.object({
		area: t.literal("brown"),
		cell: t.int().min(0).max(11)
	}),
	t.object({
		area: t.literal("pink"),
		mode: t.enum(["half", "mult"])
	})
]), y = t.discriminatedUnion("area", [
	t.object({
		area: t.literal("yellow"),
		cell: t.int().min(0).max(17)
	}),
	t.object({
		area: t.literal("turq"),
		cell: t.int().min(0).max(29)
	}),
	t.object({
		area: t.literal("blue"),
		value: t.int().min(1).max(6),
		side: t.enum(["left", "right"])
	}),
	t.object({
		area: t.literal("brown"),
		cell: t.int().min(0).max(11)
	}),
	t.object({
		area: t.literal("pink"),
		value: t.int().min(1).max(6),
		mode: t.enum(["half", "mult"])
	})
]), b = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({ type: t.literal("reroll") }),
	t.object({
		type: t.literal("pick"),
		die: g,
		target: v,
		joker: t.int().min(1).max(6).optional()
	}),
	t.object({ type: t.literal("forfeit") }),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("bonus"),
		color: _,
		target: y
	}),
	t.object({
		type: t.literal("tiePick"),
		die: g
	})
]), x = t.object({
	yellow: t.array(t.boolean()).length(18),
	turq: t.array(t.boolean()).length(30),
	blue: t.array(t.int().min(0).max(12)).length(13),
	brown: t.array(t.boolean()).length(12),
	pink: t.array(t.int().min(0).max(18)).length(12),
	pinkHalf: t.array(t.boolean()).length(12),
	actions: t.record(ie, t.array(t.int().min(0).max(2)).length(7))
}), ae = t.object({ color: t.union([_, t.literal("any")]) }), oe = t.object({
	players: t.array(t.string()).min(1).max(4),
	active: t.string(),
	phase: t.enum([
		"roundStart",
		"roll",
		"pick",
		"passive",
		"extra",
		"done"
	]),
	round: t.int().min(1).max(6),
	roundsTotal: t.int().min(4).max(6),
	dice: t.record(g, t.int().min(0).max(6)),
	pool: t.array(g),
	platter: t.array(g),
	slots: t.tuple([
		g.nullable(),
		g.nullable(),
		g.nullable()
	]),
	rollCount: t.int().min(0).max(3),
	passivePending: t.array(t.string()),
	extraQueue: t.array(t.string()),
	extraUsed: t.record(t.string(), t.array(g)),
	sheets: t.record(t.string(), x),
	pending: t.record(t.string(), t.array(ae)),
	bonusFor: t.string().nullable(),
	soloTie: t.object({
		candidates: t.array(g).min(2),
		need: t.int().min(1)
	}).nullable()
}), S = t.object({}), C = [
	"yellow",
	"turq",
	"blue",
	"brown",
	"pink",
	"white"
], w = [
	"yellow",
	"turq",
	"blue",
	"brown",
	"pink"
], T = [
	3,
	4,
	5,
	6,
	0,
	0,
	0
], E = /* @__PURE__ */ new Set([
	4,
	5,
	8,
	9,
	12,
	13
]), se = [
	0,
	2,
	6,
	12,
	20,
	30,
	42
], D = /* @__PURE__ */ new Set([
	0,
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	12,
	13,
	14,
	18,
	19,
	24
]), ce = [
	0,
	1,
	3,
	6,
	10,
	15,
	21
], le = [
	22,
	17,
	13,
	9,
	6,
	3,
	7,
	3,
	6,
	9,
	13,
	17,
	22
], ue = [
	1,
	5,
	3,
	4,
	2,
	6,
	4,
	5,
	2,
	1,
	6,
	3
], de = [
	0,
	2,
	5,
	9,
	14,
	20,
	27,
	35,
	44,
	54,
	65,
	77,
	90
], O = [
	0,
	1,
	2,
	2,
	1,
	2,
	2,
	1,
	3,
	2,
	2,
	3
], k = {
	reroll: {
		kind: "action",
		action: "reroll"
	},
	joker: {
		kind: "action",
		action: "joker"
	},
	plus1: {
		kind: "action",
		action: "extra"
	},
	fox: { kind: "fox" },
	y: {
		kind: "bonus",
		color: "yellow"
	},
	t: {
		kind: "bonus",
		color: "turq"
	},
	b: {
		kind: "bonus",
		color: "blue"
	},
	br: {
		kind: "bonus",
		color: "brown"
	},
	p: {
		kind: "bonus",
		color: "pink"
	},
	any: {
		kind: "bonus",
		color: "any"
	}
}, fe = [[
	k.reroll,
	k.joker,
	k.p,
	k.plus1,
	k.t,
	k.fox
], [
	k.joker,
	k.t,
	k.b,
	k.br,
	k.y,
	k.plus1
]], pe = [
	k.fox,
	k.plus1,
	k.br,
	k.t,
	null
], me = [
	k.br,
	k.p,
	k.y,
	k.joker,
	k.b,
	k.reroll
], he = [
	k.plus1,
	k.p,
	null,
	k.y,
	k.joker,
	null,
	k.reroll,
	null,
	k.reroll,
	k.br,
	null,
	k.t,
	k.fox
], A = [
	k.joker,
	k.p,
	null,
	k.reroll,
	k.t,
	null,
	k.plus1,
	k.b,
	null,
	k.y,
	k.fox
], j = [
	null,
	k.reroll,
	k.b,
	k.plus1,
	k.joker,
	k.y,
	k.br,
	k.reroll,
	k.fox,
	k.b,
	k.t,
	k.any
], ge = {
	reroll: k.fox,
	joker: k.p,
	extra: k.br
}, _e = [
	{
		kind: "action",
		action: "reroll"
	},
	{
		kind: "action",
		action: "extra"
	},
	{
		kind: "action",
		action: "joker"
	},
	{ kind: "any" }
], ve = [
	450,
	420,
	390,
	360,
	330,
	300,
	270,
	240,
	210,
	180
];
function ye() {
	let e = Array(13).fill(0);
	return e[6] = 7, {
		yellow: Array(18).fill(!1),
		turq: Array(30).fill(!1),
		blue: e,
		brown: Array(12).fill(!1),
		pink: Array(12).fill(0),
		pinkHalf: Array(12).fill(!1),
		actions: {
			reroll: Array(7).fill(0),
			joker: Array(7).fill(0),
			extra: Array(7).fill(0)
		}
	};
}
function be(e, t) {
	return e.area === t.area ? e.area === "yellow" && t.area === "yellow" || e.area === "brown" && t.area === "brown" ? e.cell === t.cell : e.area === "blue" && t.area === "blue" ? e.side === t.side : e.area === "pink" && t.area === "pink" ? e.mode === t.mode : e.area === "turq" && t.area === "turq" && e.cells.length === t.cells.length && e.cells.every((e) => t.cells.includes(e)) : !1;
}
function xe(e) {
	let t;
	if (e.origin === "pool") t = e.slots.filter((e) => e !== null);
	else if (e.origin === "slot") t = e.slots.filter((t, n) => t !== null && n !== e.slotIdx);
	else {
		t = [...e.platter];
		let n = t.indexOf(e.die);
		n >= 0 && t.splice(n, 1);
	}
	return 1 + t.filter((t) => e.dice[t] === e.face).length;
}
function M(e) {
	for (let t = 11; t >= 0; t--) if (e.brown[t]) return t;
	return -1;
}
function N(e, t) {
	if (t === "left") {
		for (let t = 5; t >= 0; t--) if (e.blue[t] > 0) return t - 1;
		return 5;
	}
	for (let t = 7; t < 13; t++) if (e.blue[t] > 0) return t + 1;
	return 7;
}
function P(e, t, n) {
	if (t < 1 || t > 12) return !1;
	let r = N(e, n);
	if (r < 0 || r >= 13) return !1;
	let i = n === "left" ? r + 1 : r - 1, a = e.blue[i];
	return t === 7 ? a !== 7 : a === t + 1 || a === t - 1;
}
function Se(e) {
	let t = e.joker ?? e.face;
	return (e.die === "blue" ? t : e.dice.blue) + (e.die === "white" ? t : e.dice.white);
}
function F(e, t) {
	let n = [], r = t.joker ?? t.face;
	if (r < 1 || r > 6) return n;
	let i = t.die === "white" ? [...w] : t.die === "blue" ? ["blue"] : [t.die];
	for (let a of i) if (a === "yellow") {
		let i;
		i = t.origin === "platter" ? [...E].filter((e) => e % 6 == r - 1) : [(t.origin === "slot" ? t.slotIdx : t.rollCount - 1) * 6 + (r - 1)];
		for (let t of i) t >= 0 && t < 18 && !e.yellow[t] && n.push({
			area: "yellow",
			cell: t
		});
	} else if (a === "turq") for (let t = 0; t < 5; t++) {
		let i = t * 6 + (r - 1);
		e.turq[i] || n.push({
			area: "turq",
			cells: [i]
		});
	}
	else if (a === "blue") {
		if (t.die !== "blue" && t.die !== "white") continue;
		let r = Se(t);
		P(e, r, "left") && n.push({
			area: "blue",
			side: "left"
		}), P(e, r, "right") && n.push({
			area: "blue",
			side: "right"
		});
	} else if (a === "brown") {
		let t = M(e);
		for (let i = t + 1; i < 12; i++) !e.brown[i] && ue[i] === r && n.push({
			area: "brown",
			cell: i
		});
	} else {
		let t = e.pink.findIndex((e) => e === 0);
		t >= 0 && (n.push({
			area: "pink",
			mode: "half"
		}), O[t] > 0 && n.push({
			area: "pink",
			mode: "mult"
		}));
	}
	return n;
}
function Ce(e, t) {
	let n = e.actions[t], r = n.findIndex((e) => e === 0);
	return r < 0 ? null : (n[r] = 1, n.every((e) => e >= 1) ? ge[t] : null);
}
function I(e, t) {
	return e.actions[t].filter((e) => e === 1).length;
}
function we(e, t) {
	let n = e.actions[t].findIndex((e) => e === 1);
	n >= 0 && (e.actions[t][n] = 2);
}
function L(e) {
	let t = /* @__PURE__ */ new Set(), n = !1;
	if (e.actions.joker.forEach((e, r) => {
		if (e !== 1) return;
		let i = T[r];
		i > 0 ? t.add(i) : n = !0;
	}), n) for (let e = 1; e <= 6; e++) t.add(e);
	return [...t].sort();
}
function Te(e, t) {
	let n = e.actions.joker, r = -1;
	for (let e = 0; e < 7; e++) if (n[e] === 1) {
		if (T[e] === t) return n[e] = 2, !0;
		T[e] === 0 && r < 0 && (r = e);
	}
	return r >= 0 && (n[r] = 2, !0);
}
function R(e, t) {
	let n = Math.floor(t / 6), r = t % 6, i = [];
	return n > 0 && e.yellow[t - 6] && i.push(fe[n - 1][r]), n < 2 && e.yellow[t + 6] && i.push(fe[n][r]), i;
}
function z(e, t) {
	if (!D.has(t)) return [];
	let n = Math.floor(t / 6), r = t % 6, i = [];
	return [
		0,
		1,
		2,
		3,
		4,
		5
	].every((t) => !D.has(n * 6 + t) || e.turq[n * 6 + t]) && pe[n] && i.push(pe[n]), [
		0,
		1,
		2,
		3,
		4
	].every((t) => !D.has(t * 6 + r) || e.turq[t * 6 + r]) && i.push(me[r]), i;
}
function B(e, t) {
	let n = [];
	return t > 0 && e.brown[t - 1] && A[t - 1] && n.push(A[t - 1]), t < 11 && e.brown[t + 1] && A[t] && n.push(A[t]), n;
}
function Ee(e, t, n) {
	if (t === "any") return w.some((t) => Ee(e, t, n));
	if (t === "yellow") return e.yellow.some((e) => !e);
	if (t === "turq") return e.turq.some((e) => !e);
	if (t === "blue") {
		for (let t = 1; t <= 6; t++) {
			let r = t + n;
			if (P(e, r, "left") || P(e, r, "right")) return !0;
		}
		return !1;
	}
	if (t === "brown") {
		let t = M(e);
		return e.brown.some((e, n) => !e && n > t);
	}
	return e.pink.some((e) => e === 0);
}
function V(e, t, n) {
	let r = [];
	if (t === "yellow") e.yellow.forEach((e, t) => {
		e || r.push({
			area: "yellow",
			cell: t
		});
	});
	else if (t === "turq") e.turq.forEach((e, t) => {
		e || r.push({
			area: "turq",
			cell: t
		});
	});
	else if (t === "blue") for (let t = 1; t <= 6; t++) {
		let i = t + n;
		P(e, i, "left") && r.push({
			area: "blue",
			side: "left",
			value: t
		}), P(e, i, "right") && r.push({
			area: "blue",
			side: "right",
			value: t
		});
	}
	else if (t === "brown") {
		let t = M(e);
		e.brown.forEach((e, n) => {
			!e && n > t && r.push({
				area: "brown",
				cell: n
			});
		});
	} else {
		let t = e.pink.findIndex((e) => e === 0);
		if (t >= 0) for (let e = 1; e <= 6; e++) r.push({
			area: "pink",
			value: e,
			mode: "half"
		}), O[t] > 0 && r.push({
			area: "pink",
			value: e,
			mode: "mult"
		});
	}
	return r;
}
function De(e) {
	let t = 0;
	for (let n = 0; n < 3; n++) t += se[e.yellow.slice(n * 6, n * 6 + 6).filter(Boolean).length];
	let n = 0;
	for (let t = 0; t < 5; t++) n += ce[e.turq.slice(t * 6, t * 6 + 6).filter(Boolean).length];
	let r = 0, i = -1;
	for (let t = 0; t < 6; t++) if (e.blue[t] > 0) {
		i = t;
		break;
	}
	let a = -1;
	for (let t = 12; t > 6; t--) if (e.blue[t] > 0) {
		a = t;
		break;
	}
	i >= 0 && (r += le[i]), a >= 0 && (r += le[a]);
	for (let t of e.blue) t > 0 && (t <= 4 || t >= 10) && (r += 4);
	let o = de[e.brown.filter(Boolean).length], s = e.pink.reduce((e, t) => e + t, 0);
	return {
		yellow: t,
		turq: n,
		blue: r,
		brown: o,
		pink: s
	};
}
function Oe(e) {
	let t = 0;
	return e.yellow[5] && e.yellow[11] && (t += 1), [
		0,
		1,
		2,
		3,
		4,
		5
	].every((t) => e.turq[t]) && (t += 1), e.blue[12] > 0 && (t += 1), e.brown[10] && e.brown[11] && (t += 1), e.pink[8] > 0 && e.pinkHalf[8] && (t += 1), e.actions.reroll.every((e) => e >= 1) && (t += 1), t;
}
function H(e) {
	let t = De(e), n = w.map((e) => t[e]), r = Math.min(...n), i = Oe(e), a = r > 0 ? i * r : 0;
	return {
		areas: t,
		foxes: i,
		foxScore: a,
		total: n.reduce((e, t) => e + t, 0) + a,
		bestArea: Math.max(...n)
	};
}
function ke(e) {
	let t = ve.findIndex((t) => e >= t);
	return t < 0 ? 10 : t;
}
//#endregion
//#region src/games/clever-cubed/rules.ts
var U = {
	over: "games.clever-cubed.errOver",
	notYourTurn: "games.clever-cubed.errNotYourTurn",
	badStage: "games.clever-cubed.errBadStage",
	badTarget: "games.clever-cubed.errBadTarget",
	badDie: "games.clever-cubed.errBadDie",
	noAction: "games.clever-cubed.errNoAction",
	bonusPending: "games.clever-cubed.errBonusPending",
	tiePending: "games.clever-cubed.errTiePending"
};
function Ae(e) {
	return e === 4 ? 4 : e === 3 ? 5 : 6;
}
function W(e) {
	return e.players.map((t, n) => e.players[(e.activeIdx + n) % e.players.length]);
}
function G(e, t, n) {
	if (n.kind !== "fox") {
		if (n.kind === "action") {
			let r = Ce(e.sheets[t], n.action);
			r && G(e, t, r);
			return;
		}
		e.pending[t].push({ color: n.color });
	}
}
function je(e, t) {
	let n = e.sheets[t];
	e.pending[t] = e.pending[t].filter((t) => Ee(n, t.color, e.dice.white)), e.pending[t].length > 0 && e.bonusFor === null && (e.bonusFor = t);
}
function Me(e, t, n) {
	for (let r of n) r && G(e, t, r);
	je(e, t);
}
function Ne(e, t, n, r) {
	let i = e.sheets[t], a = r.joker ?? r.face;
	if (n.area === "yellow") return i.yellow[n.cell] = !0, R(i, n.cell);
	if (n.area === "turq") {
		let e = [];
		for (let t of n.cells) i.turq[t] = !0, e.push(...z(i, t));
		return e;
	}
	if (n.area === "blue") {
		let e = N(i, n.side);
		return i.blue[e] = Se(r), [he[e]];
	}
	if (n.area === "brown") return i.brown[n.cell] = !0, B(i, n.cell);
	let o = i.pink.findIndex((e) => e === 0), s = n.mode === "half" ? Math.ceil(a / 2) : a * O[o];
	return i.pink[o] = s, i.pinkHalf[o] = n.mode === "half", [n.mode === "half" ? j[o] : null];
}
function Pe(e) {
	if (e.players.length === 1) {
		e.pool = [...C], Be(e), e.slots = [
			null,
			null,
			null
		], e.platter = [], e.extraUsed = {};
		let t = C.map((t) => ({
			c: t,
			v: e.dice[t]
		})).sort((e, t) => e.v - t.v), n = t[2].v, r = 3;
		for (let { c: i, v: a } of t) a < n && (e.platter.push(i), --r);
		let i = t.filter((e) => e.v === n).map((e) => e.c);
		r > 0 && i.length === r && (e.platter.push(...i), r = 0), e.pool = e.pool.filter((t) => !e.platter.includes(t)), r > 0 ? e.soloTie = {
			candidates: i,
			need: r
		} : Fe(e), e.passivePending = [...e.players], e.phase = "passive";
		return;
	}
	e.platter.push(...e.pool), e.pool = [], e.passivePending = e.players.filter((t) => t !== e.players[e.activeIdx]), e.phase = "passive";
}
function Fe(e) {
	let t = [...e.pool].sort((t, n) => e.dice[n] - e.dice[t]);
	e.slots = [
		t[0] ?? null,
		t[1] ?? null,
		t[2] ?? null
	], e.pool = [];
}
function Ie(e) {
	if (e.extraQueue = W(e).filter((t) => I(e.sheets[t], "extra") > 0), e.extraQueue.length === 0) {
		Le(e);
		return;
	}
	e.phase = "extra";
}
function Le(e) {
	if (e.activeIdx = (e.activeIdx + 1) % e.players.length, e.activeIdx === e.firstIdx && (e.round += 1), e.round > e.roundsTotal) {
		e.phase = "done";
		return;
	}
	e.pool = [...C], e.platter = [], e.slots = [
		null,
		null,
		null
	], e.rollCount = 0, e.dice = {
		yellow: 0,
		turq: 0,
		blue: 0,
		brown: 0,
		pink: 0,
		white: 0
	}, e.extraUsed = {}, e.passivePending = [], e.extraQueue = [], e.activeIdx === e.firstIdx && Re(e), W(e).some((t) => e.pending[t].length > 0) ? (e.phase = "roundStart", e.bonusFor = W(e).find((t) => e.pending[t].length > 0) ?? null) : e.phase = "roll";
}
function Re(e) {
	let t = _e[e.round - 1];
	if (t) for (let n of e.players) {
		if (t.kind === "action") {
			let r = Ce(e.sheets[n], t.action);
			r && G(e, n, r);
		} else e.pending[n].push({ color: "any" });
		je(e, n);
	}
}
function ze(e, t) {
	if (je(e, t), !(e.pending[t].length > 0)) {
		if (e.bonusFor = null, e.phase === "roundStart") {
			let t = W(e).find((t) => e.pending[t].length > 0);
			t ? e.bonusFor = t : e.phase = "roll";
			return;
		}
		e.phase === "passive" && e.passivePending.length === 0 && e.soloTie === null && Ie(e);
	}
}
function Be(t) {
	for (let n of C) t.pool.includes(n) && (t.dice[n] = e(t.seed, t.rngCursor, 6) + 1, t.rngCursor += 1);
}
function Ve(t, n, r) {
	let i = {}, a = {};
	for (let e of n) i[e] = ye(), a[e] = [];
	let o = {
		players: n,
		firstIdx: e(r, 0, n.length),
		activeIdx: 0,
		round: 1,
		roundsTotal: Ae(n.length),
		phase: "roll",
		dice: {
			yellow: 0,
			turq: 0,
			blue: 0,
			brown: 0,
			pink: 0,
			white: 0
		},
		pool: [...C],
		platter: [],
		slots: [
			null,
			null,
			null
		],
		rollCount: 0,
		passivePending: [],
		extraQueue: [],
		extraUsed: {},
		sheets: i,
		pending: a,
		bonusFor: null,
		soloTie: null,
		seed: r,
		rngCursor: 1
	};
	return o.activeIdx = o.firstIdx, Re(o), {
		state: o,
		fx: []
	};
}
function K(e, t, n) {
	let r = {
		die: t,
		face: e.dice[t],
		joker: n,
		rollCount: e.rollCount,
		dice: e.dice,
		slots: e.slots,
		platter: e.platter
	};
	if (e.pool.includes(t)) return {
		...r,
		origin: "pool"
	};
	let i = e.slots.indexOf(t);
	return i >= 0 ? {
		...r,
		origin: "slot",
		slotIdx: i
	} : e.platter.includes(t) ? {
		...r,
		origin: "platter"
	} : null;
}
function He(e, t) {
	let n = e.sheets[t], r = e.platter.filter((t) => F(n, K(e, t)).length > 0);
	return r.length > 0 ? r : e.slots.filter((t) => t !== null && F(n, K(e, t)).length > 0);
}
function Ue(e, t, n, r) {
	if (r === void 0) return { joker: void 0 };
	if (r === e.dice[n]) return { code: U.badTarget };
	let i = e.sheets[t];
	return !L(i).includes(r) || !Te(i, r) ? { code: U.noAction } : { joker: r };
}
function We(e, t, n, r, i) {
	let a = K(e, n, i);
	if (!a || a.face < 1) return { code: U.badDie };
	let o = e.sheets[t];
	if (r.area === "turq") {
		let e = F(o, a).filter((e) => e.area === "turq").flatMap((e) => e.cells);
		if (new Set(r.cells).size !== r.cells.length || r.cells.some((t) => !e.includes(t))) return { code: U.badTarget };
		let t = xe(a);
		return r.cells.length < 1 || r.cells.length > t ? { code: U.badTarget } : a;
	}
	return F(o, a).some((e) => be(e, r)) ? a : { code: U.badTarget };
}
function Ge(e, t, n) {
	if (e.phase === "done") return { code: U.over };
	if (e.bonusFor !== null && t.type !== "bonus") return { code: U.bonusPending };
	if (e.soloTie !== null && t.type !== "tiePick" && t.type !== "bonus") return { code: U.tiePending };
	if (t.type === "tiePick") {
		let r = e.soloTie;
		if (e.phase !== "passive" || e.players.length !== 1 || !r || n.by !== e.players[e.activeIdx]) return { code: U.notYourTurn };
		if (!r.candidates.includes(t.die)) return { code: U.badDie };
		let i = structuredClone(e), a = i.soloTie;
		return i.platter.push(t.die), i.pool = i.pool.filter((e) => e !== t.die), a.candidates = a.candidates.filter((e) => e !== t.die), --a.need, a.need <= 0 && (i.soloTie = null, Fe(i)), {
			state: i,
			fx: []
		};
	}
	if (t.type === "bonus") {
		if (e.bonusFor !== n.by) return { code: U.notYourTurn };
		let r = structuredClone(e), i = r.sheets[n.by], a = r.pending[n.by], o = a.findIndex((e) => e.color === t.color);
		if (o < 0 && (o = a.findIndex((e) => e.color === "any")), o < 0) return { code: U.badTarget };
		let s = t.target;
		if (s.area !== t.color) return { code: U.badTarget };
		let c;
		if (s.area === "yellow") {
			if (i.yellow[s.cell]) return { code: U.badTarget };
			i.yellow[s.cell] = !0, c = R(i, s.cell);
		} else if (s.area === "turq") {
			if (i.turq[s.cell]) return { code: U.badTarget };
			i.turq[s.cell] = !0, c = z(i, s.cell);
		} else if (s.area === "blue") {
			let e = s.value + r.dice.white;
			if (!P(i, e, s.side)) return { code: U.badTarget };
			let t = N(i, s.side);
			i.blue[t] = e, c = [he[t]];
		} else if (s.area === "brown") {
			if (i.brown[s.cell] || s.cell <= M(i)) return { code: U.badTarget };
			i.brown[s.cell] = !0, c = B(i, s.cell);
		} else {
			let e = i.pink.findIndex((e) => e === 0);
			if (e < 0 || s.mode === "mult" && O[e] === 0) return { code: U.badTarget };
			i.pink[e] = s.mode === "half" ? Math.ceil(s.value / 2) : s.value * O[e], i.pinkHalf[e] = s.mode === "half", c = [s.mode === "half" ? j[e] : null];
		}
		a.splice(o, 1);
		for (let e of c) e && G(r, n.by, e);
		return ze(r, n.by), {
			state: r,
			fx: []
		};
	}
	if (t.type === "roll") {
		if (e.phase !== "roll" || n.by !== e.players[e.activeIdx]) return { code: U.notYourTurn };
		let t = structuredClone(e);
		return Be(t), t.rollCount += 1, t.phase = "pick", {
			state: t,
			fx: []
		};
	}
	if (t.type === "reroll") {
		if (e.phase !== "pick" || n.by !== e.players[e.activeIdx]) return { code: U.notYourTurn };
		if (I(e.sheets[n.by], "reroll") === 0) return { code: U.noAction };
		let t = structuredClone(e);
		return we(t.sheets[n.by], "reroll"), Be(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "forfeit") {
		if (e.phase !== "pick" || n.by !== e.players[e.activeIdx]) return { code: U.notYourTurn };
		let t = structuredClone(e);
		return t.rollCount >= 3 ? Pe(t) : t.phase = "roll", {
			state: t,
			fx: []
		};
	}
	if (t.type === "pass") {
		let t = structuredClone(e);
		return t.phase === "passive" && t.passivePending.includes(n.by) ? (t.passivePending = t.passivePending.filter((e) => e !== n.by), t.passivePending.length === 0 && t.bonusFor === null && Ie(t), {
			state: t,
			fx: []
		}) : t.phase === "extra" && t.extraQueue[0] === n.by ? (t.extraQueue.shift(), t.extraQueue.length === 0 && Le(t), {
			state: t,
			fx: []
		}) : { code: U.notYourTurn };
	}
	if (t.type === "pick") {
		let r = e.players[e.activeIdx];
		if (e.phase === "pick" && n.by === r) {
			if (!e.pool.includes(t.die)) return { code: U.badDie };
			let r = We(e, n.by, t.die, t.target, t.joker);
			if ("code" in r) return r;
			let i = structuredClone(e), a = Ue(i, n.by, t.die, t.joker);
			if ("code" in a) return a;
			let o = K(i, t.die, a.joker), s = Ne(i, n.by, t.target, o);
			i.pool = i.pool.filter((e) => e !== t.die), i.slots[i.rollCount - 1] = t.die;
			let c = i.dice[t.die];
			return i.platter.push(...i.pool.filter((e) => i.dice[e] < c)), i.pool = i.pool.filter((e) => i.dice[e] >= c), Me(i, n.by, s), i.pool.length === 0 || i.rollCount >= 3 ? Pe(i) : i.phase = "roll", {
				state: i,
				fx: []
			};
		}
		if (e.phase === "passive" && e.passivePending.includes(n.by)) {
			if (!He(e, n.by).includes(t.die)) return { code: U.badDie };
			let r = We(e, n.by, t.die, t.target, t.joker);
			if ("code" in r) return r;
			let i = structuredClone(e), a = Ue(i, n.by, t.die, t.joker);
			if ("code" in a) return a;
			let o = K(i, t.die, a.joker), s = Ne(i, n.by, t.target, o);
			return Me(i, n.by, s), i.passivePending = i.passivePending.filter((e) => e !== n.by), i.passivePending.length === 0 && i.bonusFor === null && Ie(i), {
				state: i,
				fx: []
			};
		}
		if (e.phase === "extra" && e.extraQueue[0] === n.by) {
			if (I(e.sheets[n.by], "extra") === 0) return { code: U.noAction };
			if ((e.extraUsed[n.by] ?? []).includes(t.die)) return { code: U.badDie };
			let r = We(e, n.by, t.die, t.target, t.joker);
			if ("code" in r) return r;
			let i = structuredClone(e), a = i.sheets[n.by], o = Ue(i, n.by, t.die, t.joker);
			if ("code" in o) return o;
			we(a, "extra"), i.extraUsed[n.by] = [...i.extraUsed[n.by] ?? [], t.die];
			let s = K(i, t.die, o.joker), c = Ne(i, n.by, t.target, s);
			return Me(i, n.by, c), (I(a, "extra") === 0 || i.extraUsed[n.by].length >= C.length) && (i.extraQueue.shift(), i.extraQueue.length === 0 && Le(i)), {
				state: i,
				fx: []
			};
		}
		return { code: U.notYourTurn };
	}
	return { code: U.badStage };
}
function Ke(e) {
	return {
		public: {
			players: [...e.players],
			active: e.players[e.activeIdx],
			phase: e.phase,
			round: e.round,
			roundsTotal: e.roundsTotal,
			dice: { ...e.dice },
			pool: [...e.pool],
			platter: [...e.platter],
			slots: [...e.slots],
			rollCount: e.rollCount,
			passivePending: [...e.passivePending],
			extraQueue: [...e.extraQueue],
			extraUsed: Object.fromEntries(Object.entries(e.extraUsed).map(([e, t]) => [e, [...t]])),
			sheets: e.sheets,
			pending: Object.fromEntries(Object.entries(e.pending).map(([e, t]) => [e, t.map((e) => ({ ...e }))])),
			bonusFor: e.bonusFor,
			soloTie: e.soloTie ? {
				candidates: [...e.soloTie.candidates],
				need: e.soloTie.need
			} : null
		},
		private: {}
	};
}
function qe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {}, n = {};
	for (let r of e.players) {
		let i = H(e.sheets[r]);
		t[r] = i.total, n[r] = i.bestArea;
	}
	let r = [...e.players].sort((r, i) => t[i] - t[r] || n[i] - n[r] || e.players.indexOf(r) - e.players.indexOf(i)), i = r[0];
	return {
		phase: "done",
		winner: r.filter((e) => t[e] === t[i] && n[e] === n[i]),
		ranking: r,
		scores: t
	};
}
var Je = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: h,
	schemas: {
		action: b,
		publicView: oe,
		privateView: S
	},
	setup: Ve,
	reduce: Ge,
	viewFor: Ke,
	status: qe
}, Ye = 1026, Xe = 1457, Ze = [
	{
		x: 57,
		y: 10,
		w: 107,
		h: 104
	},
	{
		x: 57,
		y: 150,
		w: 107,
		h: 97
	},
	{
		x: 57,
		y: 283,
		w: 107,
		h: 119
	}
], Qe = {
	x: 256,
	y: 10,
	w: 87,
	h: 109,
	pitch: 123.4,
	count: 6
}, $e = {
	reroll: {
		x: 362,
		y: 157,
		w: 55,
		h: 62,
		pitch: 85.3,
		count: 7
	},
	joker: {
		x: 362,
		y: 256,
		w: 55,
		h: 57,
		pitch: 85.3,
		count: 7
	},
	extra: {
		x: 362,
		y: 348,
		w: 55,
		h: 58,
		pitch: 85.3,
		count: 7
	}
}, et = 73, tt = 527, nt = 71, rt = 143.5, it = 59, at = 60;
function ot(e) {
	return {
		x: et + e % 6 * nt,
		y: tt + Math.floor(e / 6) * rt,
		w: it,
		h: at
	};
}
var st = 539, ct = 524, lt = 66.5, ut = 62, dt = 63;
function q(e) {
	return {
		x: st + e % 6 * lt,
		y: ct + Math.floor(e / 6) * lt,
		w: ut,
		h: dt
	};
}
var J = {
	x: 34,
	y: 944,
	w: 58,
	h: 111,
	pitch: 74.4,
	count: 13
};
function ft(e) {
	return {
		x: J.x + e * J.pitch,
		y: J.y,
		w: J.w,
		h: J.h
	};
}
var Y = {
	x: 90,
	y: 1197,
	w: 60,
	h: 60,
	pitch: 76.5,
	count: 12
};
function pt(e) {
	return {
		x: Y.x + e * Y.pitch,
		y: Y.y,
		w: Y.w,
		h: Y.h
	};
}
var X = {
	x: 86,
	y: 1311,
	w: 67,
	h: 117,
	pitch: 76.5,
	count: 12
};
function Z(e) {
	return {
		x: X.x + e * X.pitch,
		y: X.y,
		w: X.w,
		h: X.h
	};
}
//#endregion
//#region src/games/clever-cubed/sheet-view.tsx
var mt = {
	yellow: "#eab308",
	turq: "#0d9488",
	blue: "#1d4ed8",
	brown: "#92400e",
	pink: "#db2777",
	white: "#f8fafc"
}, ht = {
	1: [[.5, .5]],
	2: [[.28, .28], [.72, .72]],
	3: [
		[.25, .25],
		[.5, .5],
		[.75, .75]
	],
	4: [
		[.28, .28],
		[.72, .28],
		[.28, .72],
		[.72, .72]
	],
	5: [
		[.25, .25],
		[.75, .25],
		[.5, .5],
		[.25, .75],
		[.75, .75]
	],
	6: [
		[.3, .25],
		[.7, .25],
		[.3, .5],
		[.7, .5],
		[.3, .75],
		[.7, .75]
	]
};
function gt({ r: e, light: t }) {
	return /* @__PURE__ */ f(u, {
		mark: "x",
		rect: e,
		color: t ? "#ffffff" : "var(--color-ink)",
		strokeWidth: 9,
		inset: .16
	});
}
function _t({ r: e, text: t, cyRatio: n = .5 }) {
	let r = Math.min(e.h, e.w * 1.3), i = e.y + e.h * n;
	return /* @__PURE__ */ f(d, {
		r: {
			x: e.x,
			y: i - r / 2,
			w: e.w,
			h: r
		},
		text: t
	});
}
function vt({ r: e, die: t, face: n }) {
	let r = Math.min(e.w, e.h) * .62, i = e.x + (e.w - r) / 2, a = e.y + (e.h - r) / 2, o = t === "white" || t === "yellow" ? "#1f2937" : "#ffffff";
	return /* @__PURE__ */ p("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ f("rect", {
			x: i,
			y: a,
			width: r,
			height: r,
			rx: r * .18,
			fill: mt[t],
			stroke: "var(--color-ink)",
			strokeWidth: 3
		}), ht[n]?.map(([e, t], n) => /* @__PURE__ */ f("circle", {
			cx: i + e * r,
			cy: a + t * r,
			r: r * .09,
			fill: o
		}, n))]
	});
}
function yt({ sheet: e, round: t, roundsTotal: n, slots: i, dice: a, eligible: o, onTapEligible: s, readOnly: c, fitKey: l, markedTurq: ee }) {
	let d = r(() => new Set(ee ?? []), [ee]);
	return /* @__PURE__ */ p(ne, {
		image: "games/clever-cubed/sheet.webp",
		sheetW: Ye,
		sheetH: Xe,
		eligible: o,
		onTapEligible: s,
		readOnly: c,
		fitKey: l,
		children: [
			Array.from({ length: n }, (e, n) => {
				let r = te(Qe, n);
				return n < t - 1 ? /* @__PURE__ */ f(u, {
					mark: "x",
					rect: r,
					strokeWidth: 8,
					inset: .12
				}, `rd${n}`) : n === t - 1 ? /* @__PURE__ */ f("rect", {
					x: r.x - 5,
					y: r.y - 5,
					width: r.w + 10,
					height: r.h + 10,
					rx: 16,
					fill: "#fbbf24",
					fillOpacity: .35,
					stroke: "var(--color-ink)",
					strokeWidth: 3,
					pointerEvents: "none"
				}, `rd${n}`) : null;
			}),
			Object.keys($e).map((t) => e.actions[t].map((e, n) => {
				if (e === 0) return null;
				let r = te($e[t], n);
				return e === 1 ? /* @__PURE__ */ f(u, {
					mark: "circle",
					rect: r,
					strokeWidth: 6,
					inset: .05
				}, `${t}${n}`) : /* @__PURE__ */ f(u, {
					mark: "x",
					rect: r,
					strokeWidth: 8,
					inset: .12
				}, `${t}${n}`);
			})),
			i.map((e, t) => e && a[e] > 0 ? /* @__PURE__ */ f(vt, {
				r: Ze[t],
				die: e,
				face: a[e]
			}, `slot${t}`) : null),
			e.yellow.map((e, t) => e ? /* @__PURE__ */ f(gt, { r: ot(t) }, `y${t}`) : null),
			e.brown.map((e, t) => e ? /* @__PURE__ */ f(gt, { r: pt(t) }, `br${t}`) : null),
			e.turq.map((e, t) => e ? /* @__PURE__ */ f(gt, {
				r: q(t),
				light: D.has(t)
			}, `t${t}`) : null),
			[...d].map((t) => {
				if (e.turq[t]) return null;
				let n = q(t);
				return /* @__PURE__ */ f(u, {
					mark: "circle",
					rect: n,
					color: "#ffffff",
					strokeWidth: 7,
					inset: .02
				}, `tm${t}`);
			}),
			e.blue.map((e, t) => e > 0 && t !== 6 ? /* @__PURE__ */ f(_t, {
				r: ft(t),
				text: String(e)
			}, `b${t}`) : null),
			e.pink.map((e, t) => e > 0 ? /* @__PURE__ */ f(_t, {
				r: Z(t),
				text: String(e),
				cyRatio: .3
			}, `p${t}`) : null)
		]
	});
}
//#endregion
//#region src/games/clever-cubed/view-player.tsx
function bt() {
	let e = i(null), [t, r] = a("");
	return n(() => {
		let t = e.current;
		if (!t) return;
		let n = !0, i = new ResizeObserver(([e]) => {
			let t = Math.round(e.contentRect.width), i = Math.round(e.contentRect.height);
			if (!t || !i) return;
			let a = `${t}x${i}`;
			queueMicrotask(() => {
				n && r((e) => e === a ? e : a);
			});
		});
		return i.observe(t), () => {
			n = !1, i.disconnect();
		};
	}, []), [e, t];
}
var xt = {
	yellow: "games.clever-cubed.die.yellow",
	turq: "games.clever-cubed.die.turq",
	blue: "games.clever-cubed.die.blue",
	brown: "games.clever-cubed.die.brown",
	pink: "games.clever-cubed.die.pink",
	white: "games.clever-cubed.die.white"
}, St = {
	yellow: "games.clever-cubed.area.yellow",
	turq: "games.clever-cubed.area.turq",
	blue: "games.clever-cubed.area.blue",
	brown: "games.clever-cubed.area.brown",
	pink: "games.clever-cubed.area.pink"
}, Ct = {
	1: [[.5, .5]],
	2: [[.28, .28], [.72, .72]],
	3: [
		[.25, .25],
		[.5, .5],
		[.75, .75]
	],
	4: [
		[.28, .28],
		[.72, .28],
		[.28, .72],
		[.72, .72]
	],
	5: [
		[.25, .25],
		[.75, .25],
		[.5, .5],
		[.25, .75],
		[.75, .75]
	],
	6: [
		[.3, .25],
		[.7, .25],
		[.3, .5],
		[.7, .5],
		[.3, .75],
		[.7, .75]
	]
};
function wt({ color: e, value: t, selected: n, disabled: r, dim: i, onTap: a, label: o }) {
	let s = e === "white" || e === "yellow" || e === "brown" ? "var(--color-ink)" : "#ffffff", c = /* @__PURE__ */ p("svg", {
		viewBox: "0 0 48 48",
		role: "img",
		className: "cc3-die",
		children: [
			/* @__PURE__ */ f("rect", {
				x: 2,
				y: 2,
				width: 44,
				height: 44,
				rx: 10,
				fill: mt[e],
				stroke: "var(--color-ink)",
				strokeWidth: 2.5
			}),
			t > 0 && Ct[t].map(([e, t], n) => /* @__PURE__ */ f("circle", {
				cx: e * 48,
				cy: t * 48,
				r: 4.6,
				fill: s
			}, n)),
			t === 0 && /* @__PURE__ */ f("circle", {
				cx: 24,
				cy: 24,
				r: 5,
				fill: s,
				opacity: .35
			})
		]
	});
	return a ? /* @__PURE__ */ f("button", {
		type: "button",
		"aria-label": o,
		disabled: r,
		onClick: a,
		className: `shrink-0 rounded-xl transition-transform ${n ? "scale-110 ring-4 ring-sky-400" : ""} ${i ? "opacity-35" : ""} cursor-pointer`,
		children: c
	}) : /* @__PURE__ */ f("span", {
		className: `shrink-0 ${i ? "opacity-35" : ""}`,
		"aria-hidden": !0,
		children: c
	});
}
function Tt(e) {
	let t = e.public;
	return /* @__PURE__ */ f(Et, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Et({ pub: e, members: t, myRid: n, send: i }) {
	let o = s(), [te, u] = bt(), [d, ne] = a(n), [m, g] = a(null), _ = e.sheets[n], ie = e.sheets[d] ?? _, v = e.active === n, y = (e) => t.find((t) => t.rid === e)?.name ?? e, b = e.bonusFor !== null && e.bonusFor !== n, x = (t, n) => {
		let r = {
			die: t,
			face: e.dice[t],
			joker: n,
			rollCount: e.rollCount,
			dice: e.dice,
			slots: e.slots,
			platter: e.platter
		};
		if (e.pool.includes(t)) return {
			...r,
			origin: "pool"
		};
		let i = e.slots.indexOf(t);
		return i >= 0 ? {
			...r,
			origin: "slot",
			slotIdx: i
		} : {
			...r,
			origin: "platter"
		};
	}, ae = r(() => {
		if (!_ || b || e.bonusFor === n || e.soloTie !== null) return [];
		if (e.phase === "pick" && v) return [...e.pool];
		if (e.phase === "passive" && e.passivePending.includes(n)) {
			let t = e.platter.filter((e) => F(_, x(e)).length > 0);
			return t.length > 0 ? t : e.slots.filter((e) => e !== null && F(_, x(e)).length > 0);
		}
		if (e.phase === "extra" && e.extraQueue[0] === n && I(_, "extra") > 0) {
			let t = e.extraUsed[n] ?? [];
			return C.filter((e) => !t.includes(e));
		}
		return [];
	}, [
		_,
		b,
		e,
		n,
		v
	]), oe = e.pending[n] ?? [], S = _ ? _.pink.findIndex((e) => e === 0) : -1, T = r(() => {
		if (!_ || d !== n) return [];
		if (m?.mode === "pick" && !m.jokerPick) return F(_, x(m.die, m.joker)).flatMap((e) => {
			if (e.area === "yellow") return [{
				key: `y${e.cell}`,
				rect: ot(e.cell)
			}];
			if (e.area === "turq") return e.cells.map((e) => ({
				key: `t${e}`,
				rect: q(e)
			}));
			if (e.area === "blue") {
				let t = N(_, e.side);
				return [{
					key: `b${t}`,
					rect: ft(t)
				}];
			}
			return e.area === "brown" ? [{
				key: `br${e.cell}`,
				rect: pt(e.cell)
			}] : S >= 0 ? [{
				key: "p",
				rect: Z(S)
			}] : [];
		});
		if (m?.mode === "turq") {
			let t = ((m.joker ?? e.dice[m.die]) - 1 + 6) % 6;
			return [
				0,
				1,
				2,
				3,
				4
			].map((e) => e * 6 + t).filter((e) => !_.turq[e]).map((e) => ({
				key: `t${e}`,
				rect: q(e)
			}));
		}
		return m?.mode === "pinkMode" && S >= 0 ? [{
			key: "p",
			rect: Z(S)
		}] : m?.mode === "bonus" && e.bonusFor === n ? V(_, m.color, e.dice.white).flatMap((e) => {
			if (e.area === "yellow") return [{
				key: `y${e.cell}`,
				rect: ot(e.cell)
			}];
			if (e.area === "turq") return [{
				key: `t${e.cell}`,
				rect: q(e.cell)
			}];
			if (e.area === "brown") return [{
				key: `br${e.cell}`,
				rect: pt(e.cell)
			}];
			if (e.area === "blue") {
				if (m.value === void 0 || e.value !== m.value) return [];
				let t = N(_, e.side);
				return [{
					key: `b${t}`,
					rect: ft(t)
				}];
			}
			return m.value !== void 0 && S >= 0 ? [{
				key: "p",
				rect: Z(S)
			}] : [];
		}) : [];
	}, [
		_,
		d,
		n,
		m,
		e.bonusFor,
		e.dice,
		S
	]), E = (e, t, n) => {
		i({
			type: "pick",
			die: e,
			target: t,
			...n === void 0 ? {} : { joker: n }
		}), g(null);
	}, se = (t) => {
		if (_ && d === n) {
			if (m?.mode === "pick") {
				if (t.startsWith("y")) return E(m.die, {
					area: "yellow",
					cell: Number(t.slice(1))
				}, m.joker);
				if (t.startsWith("br")) return E(m.die, {
					area: "brown",
					cell: Number(t.slice(2))
				}, m.joker);
				if (t.startsWith("b")) {
					let e = Number(t.slice(1));
					return E(m.die, {
						area: "blue",
						side: e < 6 ? "left" : "right"
					}, m.joker);
				}
				if (t === "p") {
					S >= 0 && O[S] > 0 ? g({
						mode: "pinkMode",
						die: m.die,
						joker: m.joker
					}) : E(m.die, {
						area: "pink",
						mode: "half"
					}, m.joker);
					return;
				}
				if (t.startsWith("t")) {
					let e = Number(t.slice(1));
					g({
						mode: "turq",
						die: m.die,
						joker: m.joker,
						cells: [e],
						maxK: xe(x(m.die, m.joker))
					});
					return;
				}
				return;
			}
			if (m?.mode === "turq" && t.startsWith("t")) {
				let e = Number(t.slice(1));
				if (m.cells.includes(e)) {
					let t = m.cells.filter((t) => t !== e);
					g(t.length > 0 ? {
						...m,
						cells: t
					} : {
						mode: "pick",
						die: m.die,
						joker: m.joker
					});
				} else m.cells.length < m.maxK && g({
					...m,
					cells: [...m.cells, e]
				});
				return;
			}
			if (m?.mode === "bonus" && e.bonusFor === n) {
				if (t.startsWith("y")) {
					i({
						type: "bonus",
						color: m.color,
						target: {
							area: "yellow",
							cell: Number(t.slice(1))
						}
					}), g(null);
					return;
				}
				if (t.startsWith("t")) {
					i({
						type: "bonus",
						color: m.color,
						target: {
							area: "turq",
							cell: Number(t.slice(1))
						}
					}), g(null);
					return;
				}
				if (t.startsWith("br")) {
					i({
						type: "bonus",
						color: m.color,
						target: {
							area: "brown",
							cell: Number(t.slice(2))
						}
					}), g(null);
					return;
				}
				if (t.startsWith("b") && m.value !== void 0) {
					let e = Number(t.slice(1));
					i({
						type: "bonus",
						color: m.color,
						target: {
							area: "blue",
							value: m.value,
							side: e < 6 ? "left" : "right"
						}
					}), g(null);
					return;
				}
			}
		}
	}, D = e.bonusFor ? e.bonusFor === n ? {
		tone: "accent",
		text: o("games.clever-cubed.bonusPrompt")
	} : {
		tone: "info",
		text: o("games.clever-cubed.waitingBonus", { name: y(e.bonusFor) })
	} : e.phase === "roundStart" ? {
		tone: "info",
		text: o("games.clever-cubed.roundStart")
	} : e.phase === "roll" ? v ? {
		tone: "accent",
		text: o("games.clever-cubed.rollPrompt")
	} : {
		tone: "info",
		text: o("games.clever-cubed.waitingRoll", { name: y(e.active) })
	} : e.phase === "pick" ? v ? {
		tone: "accent",
		text: o("games.clever-cubed.pickPrompt")
	} : {
		tone: "info",
		text: o("games.clever-cubed.waitingPick", { name: y(e.active) })
	} : e.phase === "passive" ? e.soloTie ? {
		tone: "accent",
		text: o("games.clever-cubed.tiePrompt", { n: e.soloTie.need })
	} : e.passivePending.includes(n) ? {
		tone: "accent",
		text: o("games.clever-cubed.passivePrompt")
	} : {
		tone: "info",
		text: o("games.clever-cubed.waitingPassive")
	} : e.phase === "extra" ? e.extraQueue[0] === n ? {
		tone: "accent",
		text: o("games.clever-cubed.extraPrompt")
	} : {
		tone: "info",
		text: o("games.clever-cubed.waitingExtra", { name: y(e.extraQueue[0] ?? e.active) })
	} : {
		tone: "info",
		text: ""
	}, ce = _ ? L(_).filter((t) => m?.mode === "pick" && t !== e.dice[m.die]) : [], le = (() => {
		if (m?.mode !== "bonus" || m.color !== "blue" || m.value !== void 0 || !_) return [];
		let t = [];
		for (let n = 1; n <= 6; n++) (P(_, n + e.dice.white, "left") || P(_, n + e.dice.white, "right")) && t.push(n);
		return t;
	})(), ue = m?.mode === "bonus" && m.color === "pink" && m.value !== void 0 && S >= 0, de = e.phase === "pick" && v && !b && e.bonusFor === null && _ && I(_, "reroll") > 0, k = m && (m.mode === "pick" || m.mode === "pinkMode" || m.mode === "turq") ? m.joker ?? e.dice[m.die] : 0;
	return /* @__PURE__ */ f(c, {
		adaptive: !0,
		scroll: !1,
		className: "cc3-screen",
		children: /* @__PURE__ */ p("div", {
			className: "cc3-table",
			children: [/* @__PURE__ */ f("div", {
				ref: te,
				className: "frame cc3-paper",
				children: /* @__PURE__ */ f(yt, {
					sheet: ie,
					round: e.round,
					roundsTotal: e.roundsTotal,
					slots: e.phase === "done" ? [
						null,
						null,
						null
					] : e.slots,
					dice: e.dice,
					eligible: T.length > 0 ? T : void 0,
					onTapEligible: se,
					readOnly: d !== n,
					fitKey: `${d}:${u}`,
					markedTurq: m?.mode === "turq" ? m.cells : void 0
				})
			}), /* @__PURE__ */ p("aside", {
				className: "cc3-sidebar",
				children: [/* @__PURE__ */ p("div", {
					className: "cc3-header",
					children: [/* @__PURE__ */ f(l, {
						tone: D.tone,
						text: D.text,
						accent: h.accent,
						chip: o("games.clever-cubed.roundChip", {
							n: e.round,
							total: e.roundsTotal
						})
					}), /* @__PURE__ */ f(ee, {
						members: t.filter((t) => e.players.includes(t.rid)),
						myRid: n,
						variant: "plate",
						status: (t) => {
							let n = e.sheets[t];
							if (!n) return null;
							let r = H(n);
							return /* @__PURE__ */ p("span", {
								className: "flex items-center gap-1.5 font-mono tabular-nums",
								children: [/* @__PURE__ */ f("span", {
									className: "cc3-total font-black",
									children: r.total
								}), r.foxes > 0 && /* @__PURE__ */ p("span", {
									className: "cc3-fox font-bold",
									children: ["🦊", r.foxes]
								})]
							});
						},
						action: (t) => e.bonusFor ? e.bonusFor === t ? "pending" : null : e.phase === "passive" ? e.passivePending.includes(t) ? "pending" : "done" : e.phase === "extra" ? e.extraQueue.includes(t) ? e.extraQueue[0] === t ? "pending" : null : "done" : null,
						onPick: (e) => {
							ne(e), g(null);
						},
						picked: (e) => e === d
					})]
				}), /* @__PURE__ */ p("div", {
					className: "cc3-controls",
					children: [/* @__PURE__ */ p("div", {
						className: "cc3-context",
						children: [
							e.soloTie !== null && e.soloTie.candidates.map((t) => /* @__PURE__ */ f(wt, {
								color: t,
								value: e.dice[t],
								onTap: () => i({
									type: "tiePick",
									die: t
								}),
								label: o(xt[t], { n: e.dice[t] })
							}, t)),
							e.bonusFor === n && m?.mode !== "bonus" && [...new Set(oe.flatMap((e) => e.color === "any" ? w : [e.color]))].map((e) => /* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => g({
									mode: "bonus",
									color: e
								}),
								className: "btn-base min-h-11 px-3 text-sm font-black text-white",
								style: { background: mt[e] },
								children: [o(St[e]), " ?"]
							}, e)),
							le.map((e) => /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => g(m?.mode === "bonus" ? {
									...m,
									value: e
								} : m),
								className: "btn-base min-h-11 min-w-11 font-mono text-base font-black text-white",
								style: { background: h.accent },
								children: e
							}, e)),
							m?.mode === "bonus" && m.color === "pink" && m.value === void 0 && [
								1,
								2,
								3,
								4,
								5,
								6
							].map((e) => /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => g({
									...m,
									value: e
								}),
								className: "btn-base min-h-11 min-w-11 font-mono text-base font-black text-white",
								style: { background: h.accent },
								children: e
							}, e)),
							ue && m?.mode === "bonus" && m.value !== void 0 && /* @__PURE__ */ p(re, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => {
									i({
										type: "bonus",
										color: m.color,
										target: {
											area: "pink",
											value: m.value,
											mode: "half"
										}
									}), g(null);
								},
								className: "btn-base min-h-11 px-3 text-sm font-black text-white",
								style: { background: h.accent },
								children: o("games.clever-cubed.pinkHalf", { n: Math.ceil(m.value / 2) })
							}), O[S] > 0 && /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => {
									i({
										type: "bonus",
										color: m.color,
										target: {
											area: "pink",
											value: m.value,
											mode: "mult"
										}
									}), g(null);
								},
								className: "btn-base min-h-11 px-3 text-sm font-black text-white",
								style: { background: h.accent },
								children: o("games.clever-cubed.pinkMult", { n: m.value * O[S] })
							})] }),
							m?.mode === "pick" && m.jokerPick && ce.map((e) => /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => g({
									mode: "pick",
									die: m.die,
									joker: m.joker === e ? void 0 : e
								}),
								className: `btn-base min-h-11 min-w-11 font-mono text-base font-black text-white ${m.joker === e ? "ring-4 ring-sky-400" : ""}`,
								style: { background: h.accent },
								children: e
							}, e)),
							m?.mode === "pinkMode" && S >= 0 && /* @__PURE__ */ p(re, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => E(m.die, {
									area: "pink",
									mode: "half"
								}, m.joker),
								className: "btn-base min-h-11 px-3 text-sm font-black text-white",
								style: { background: h.accent },
								children: o("games.clever-cubed.pinkHalf", { n: Math.ceil(k / 2) })
							}), /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => E(m.die, {
									area: "pink",
									mode: "mult"
								}, m.joker),
								className: "btn-base min-h-11 px-3 text-sm font-black text-white",
								style: { background: h.accent },
								children: o("games.clever-cubed.pinkMult", { n: k * O[S] })
							})] }),
							e.bonusFor === null && m?.mode !== "bonus" && m?.mode !== "pinkMode" && !(m?.mode === "pick" && m.jokerPick) && ae.map((t) => /* @__PURE__ */ f(wt, {
								color: t,
								value: e.dice[t],
								selected: (m?.mode === "pick" || m?.mode === "turq") && m.die === t,
								onTap: () => g((m?.mode === "pick" || m?.mode === "turq") && m.die === t ? null : {
									mode: "pick",
									die: t
								}),
								label: o(xt[t], { n: e.dice[t] })
							}, t)),
							ae.length === 0 && m === null && e.bonusFor === null && e.soloTie === null && e.phase !== "done" && /* @__PURE__ */ f("div", {
								className: "cc3-spectator-dice",
								"aria-hidden": !0,
								children: C.map((t) => /* @__PURE__ */ f(wt, {
									color: t,
									value: e.dice[t],
									dim: !e.pool.includes(t) && !e.slots.includes(t) && !e.platter.includes(t),
									label: ""
								}, t))
							})
						]
					}), /* @__PURE__ */ p("div", {
						className: "cc3-actions",
						children: [
							m !== null && /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => g(null),
								className: "btn-quiet min-h-11 flex-1 text-sm font-bold",
								children: o("games.clever-cubed.cancel")
							}),
							m?.mode === "turq" && /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => E(m.die, {
									area: "turq",
									cells: [...m.cells].sort((e, t) => e - t)
								}, m.joker),
								className: "btn-base min-h-12 flex-1 text-base font-black text-white",
								style: { background: h.accent },
								children: o("games.clever-cubed.turqConfirm", { n: m.cells.length })
							}),
							m?.mode === "pick" && !m.jokerPick && _ && L(_).length > 0 && /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => g({
									...m,
									jokerPick: !0
								}),
								className: `btn-quiet min-h-12 flex-1 text-sm font-bold ${m.joker === void 0 ? "" : "ring-2 ring-sky-400"}`,
								children: m.joker === void 0 ? o("games.clever-cubed.jokerUse", { n: I(_, "joker") }) : `${o("games.clever-cubed.jokerPrompt")} ${m.joker}`
							}),
							m === null && e.phase === "roll" && v && !b && /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => i({ type: "roll" }),
								className: "btn-base min-h-12 flex-1 text-base font-black text-white",
								style: { background: h.accent },
								children: o("games.clever-cubed.roll")
							}),
							m === null && e.phase === "pick" && v && !b && /* @__PURE__ */ p(re, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								disabled: !de,
								onClick: () => i({ type: "reroll" }),
								className: "btn-quiet min-h-12 flex-1 text-sm font-bold disabled:opacity-40",
								children: o("games.clever-cubed.reroll", { n: _ ? I(_, "reroll") : 0 })
							}), /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => i({ type: "forfeit" }),
								className: "btn-quiet min-h-12 flex-1 text-sm font-bold",
								children: o("games.clever-cubed.forfeit")
							})] }),
							m === null && e.phase === "passive" && e.passivePending.includes(n) && !b && e.soloTie === null && /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => i({ type: "pass" }),
								className: "btn-quiet min-h-12 w-full text-sm font-bold",
								children: o("games.clever-cubed.passiveSkip")
							}),
							m === null && e.phase === "extra" && e.extraQueue[0] === n && !b && /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => i({ type: "pass" }),
								className: "btn-base min-h-12 w-full text-base font-black text-white",
								style: { background: h.accent },
								children: o("games.clever-cubed.extraDone")
							})
						]
					})]
				})]
			})]
		})
	});
}
//#endregion
//#region src/games/clever-cubed/bot.ts
var Dt = {
	actionW: 1.5,
	bonusFlatW: 2,
	sacrificeW: .3,
	jokerCost: 1.5,
	rerollBelow: 1.5,
	passiveBelow: .5,
	extraBelow: 2
};
function Ot(e, t, n) {
	let r = n.joker ?? n.face;
	if (t.area === "yellow") return e.yellow[t.cell] = !0, R(e, t.cell);
	if (t.area === "turq") {
		let n = [];
		for (let r of t.cells) e.turq[r] = !0, n.push(...z(e, r));
		return n;
	}
	if (t.area === "blue") {
		let r = N(e, t.side);
		e.blue[r] = Se(n);
		let i = he[r];
		return i ? [i] : [];
	}
	if (t.area === "brown") return e.brown[t.cell] = !0, B(e, t.cell);
	let i = e.pink.findIndex((e) => e === 0);
	e.pink[i] = t.mode === "half" ? Math.ceil(r / 2) : r * O[i], e.pinkHalf[i] = t.mode === "half";
	let a = t.mode === "half" ? j[i] : null;
	return a ? [a] : [];
}
function Q(e, t, n) {
	if (t.area === "yellow") return e.yellow[t.cell] = !0, R(e, t.cell);
	if (t.area === "turq") return e.turq[t.cell] = !0, z(e, t.cell);
	if (t.area === "blue") {
		let r = N(e, t.side);
		e.blue[r] = t.value + n;
		let i = he[r];
		return i ? [i] : [];
	}
	if (t.area === "brown") return e.brown[t.cell] = !0, B(e, t.cell);
	let r = e.pink.findIndex((e) => e === 0);
	e.pink[r] = t.mode === "half" ? Math.ceil(t.value / 2) : t.value * O[r], e.pinkHalf[r] = t.mode === "half";
	let i = t.mode === "half" ? j[r] : null;
	return i ? [i] : [];
}
function kt(e, t, n, r) {
	let i = null;
	for (let a of V(e, t, n)) {
		let t = structuredClone(e), o = H(t).total, s = Q(t, a, n), c = s.reduce((e, t) => e + (t.kind === "action" ? r.actionW : t.kind === "bonus" ? r.bonusFlatW : 0), 0), l = H(t).total - o + c;
		(!i || l > i.score) && (i = {
			bt: a,
			rewards: s,
			score: l
		});
	}
	return i;
}
function At(e, t, n, r) {
	let i = 0, a = 6, o = [...t];
	for (; o.length > 0;) {
		let t = o.shift();
		if (t.kind === "fox") continue;
		if (t.kind === "action") {
			let r = Ce(e, t.action);
			i += n.actionW, r && o.push(r);
			continue;
		}
		if (a <= 0) {
			i += n.bonusFlatW;
			continue;
		}
		--a;
		let s = t.color === "any" ? [
			"yellow",
			"turq",
			"blue",
			"brown",
			"pink"
		] : [t.color], c = null;
		for (let t of s) {
			let i = kt(e, t, r, n);
			if (!i) continue;
			let a = structuredClone(e), o = H(a).total;
			Q(a, i.bt, r);
			let s = H(a).total - o + jt(i.rewards, n);
			(!c || s > c.score) && (c = {
				...i,
				score: s
			});
		}
		c && o.push(...Q(e, c.bt, r));
	}
	return i;
}
function jt(e, t) {
	return e.reduce((e, n) => e + (n.kind === "action" ? t.actionW : n.kind === "bonus" ? t.bonusFlatW : 0), 0);
}
function Mt(e, t, n, r, i) {
	let a = structuredClone(e), o = H(a).total, s = Ot(a, n, t);
	return H(a).total - o + At(a, s, r, i);
}
function Nt(e, t) {
	let n = [], r = Math.min(t, e.length), i = (t, a) => {
		if (a.length > 0 && n.push([...a]), !(a.length >= r)) for (let n = t; n < e.length; n++) a.push(e[n]), i(n + 1, a), a.pop();
	};
	return i(0, []), n;
}
function Pt(e, t, n, r, i) {
	let a = [], o = [{ ctx: t }];
	if (i) for (let n of L(e)) n !== t.face && o.push({
		ctx: {
			...t,
			joker: n
		},
		joker: n
	});
	for (let { ctx: i, joker: s } of o) {
		let o = F(e, i), c = o.filter((e) => e.area === "turq").flatMap((e) => e.cells);
		for (let c of o) {
			if (c.area === "turq") continue;
			let o = Mt(e, i, c, n, r) - (s === void 0 ? 0 : n.jokerCost);
			a.push({
				die: t.die,
				target: c,
				joker: s,
				score: o
			});
		}
		if (c.length > 0) {
			let o = xe(i);
			for (let l of Nt(c, o)) {
				let o = {
					area: "turq",
					cells: l
				}, c = Mt(e, i, o, n, r) - (s === void 0 ? 0 : n.jokerCost);
				a.push({
					die: t.die,
					target: o,
					joker: s,
					score: c
				});
			}
		}
	}
	return a.sort((e, t) => t.score - e.score);
}
function $(e, t) {
	let n = {
		die: t,
		face: e.dice[t],
		rollCount: e.rollCount,
		dice: e.dice,
		slots: e.slots,
		platter: e.platter
	};
	if (e.pool.includes(t)) return {
		...n,
		origin: "pool"
	};
	let r = e.slots.indexOf(t);
	return r >= 0 ? {
		...n,
		origin: "slot",
		slotIdx: r
	} : {
		...n,
		origin: "platter"
	};
}
function Ft(e, t, n, r) {
	let i = Pt(e, $(t, n), r, t.dice.white, !1);
	return i.length > 0 ? i[0].score : -Infinity;
}
function It(e = Dt) {
	return (t, n) => {
		let r = t.public, i = r.sheets[n.rid];
		if (!i || r.phase === "done") return null;
		let a = n.difficulty === "weak", o = (e) => e[Math.floor(Math.random() * e.length)], s = r.dice.white;
		if (r.bonusFor === n.rid) {
			let t = r.pending[n.rid]?.[0];
			if (!t) return null;
			let c = t.color === "any" ? [
				"yellow",
				"turq",
				"blue",
				"brown",
				"pink"
			] : [t.color], l = null;
			for (let t of c) {
				let n = kt(i, t, s, e);
				if (!n) continue;
				let r = structuredClone(i), a = H(r).total;
				Q(r, n.bt, s);
				let o = H(r).total - a + jt(n.rewards, e);
				(!l || o > l.score) && (l = {
					color: t,
					bt: n.bt,
					score: o
				});
			}
			if (!l) return null;
			if (a) {
				let e = c.filter((e) => V(i, e, s).length > 0);
				if (e.length === 0) return null;
				let t = o(e);
				return { action: {
					type: "bonus",
					color: t,
					target: o(V(i, t, s))
				} };
			}
			return { action: {
				type: "bonus",
				color: l.color,
				target: l.bt
			} };
		}
		if (r.bonusFor !== null) return null;
		if (r.soloTie) {
			let t = r.soloTie.candidates;
			if (a) return { action: {
				type: "tiePick",
				die: o(t)
			} };
			let n = t[0], s = -Infinity;
			for (let a of t) {
				let t = Ft(i, r, a, e);
				t > s && (s = t, n = a);
			}
			return { action: {
				type: "tiePick",
				die: n
			} };
		}
		let c = r.active === n.rid;
		if (r.phase === "roll" && c) return { action: { type: "roll" } };
		if (r.phase === "pick" && c) {
			let t = [];
			for (let n of r.pool) {
				let a = Pt(i, $(r, n), e, s, !0), o = r.pool.filter((e) => e !== n && r.dice[e] < r.dice[n]);
				for (let n of a) {
					let a = n.score;
					for (let t of o) {
						let n = Ft(i, r, t, e);
						n > 0 && (a -= n * e.sacrificeW);
					}
					t.push({
						...n,
						score: a
					});
				}
			}
			t.sort((e, t) => t.score - e.score);
			let n = I(i, "reroll") > 0;
			if (t.length === 0) return { action: n ? { type: "reroll" } : { type: "forfeit" } };
			if (a) {
				if (n && Math.random() < .25) return { action: { type: "reroll" } };
				let e = o(t);
				return { action: {
					type: "pick",
					die: e.die,
					target: e.target,
					...e.joker === void 0 ? {} : { joker: e.joker }
				} };
			}
			let c = t[0];
			return c.score < e.rerollBelow && n && r.pool.length >= 2 ? { action: { type: "reroll" } } : { action: {
				type: "pick",
				die: c.die,
				target: c.target,
				...c.joker === void 0 ? {} : { joker: c.joker }
			} };
		}
		if (r.phase === "passive" && r.passivePending.includes(n.rid)) {
			let t = r.platter.filter((e) => F(i, $(r, e)).length > 0), n = (t.length > 0 ? t : r.slots.filter((e) => e !== null && F(i, $(r, e)).length > 0)).flatMap((t) => Pt(i, $(r, t), e, s, !0));
			if (n.length === 0) return { action: { type: "pass" } };
			if (a) {
				let e = o(n);
				return { action: {
					type: "pick",
					die: e.die,
					target: e.target,
					...e.joker === void 0 ? {} : { joker: e.joker }
				} };
			}
			let c = n[0];
			return c.score >= e.passiveBelow ? { action: {
				type: "pick",
				die: c.die,
				target: c.target,
				...c.joker === void 0 ? {} : { joker: c.joker }
			} } : { action: { type: "pass" } };
		}
		if (r.phase === "extra" && r.extraQueue[0] === n.rid) {
			let t = C.filter((e) => !(r.extraUsed[n.rid] ?? []).includes(e)).flatMap((t) => Pt(i, $(r, t), e, s, !0));
			if (t.length === 0) return { action: { type: "pass" } };
			if (a) {
				if (Math.random() < .5) {
					let e = o(t);
					return { action: {
						type: "pick",
						die: e.die,
						target: e.target,
						...e.joker === void 0 ? {} : { joker: e.joker }
					} };
				}
				return { action: { type: "pass" } };
			}
			let c = t[0];
			return c.score >= e.extraBelow ? { action: {
				type: "pick",
				die: c.die,
				target: c.target,
				...c.joker === void 0 ? {} : { joker: c.joker }
			} } : { action: { type: "pass" } };
		}
		return null;
	};
}
var Lt = It(), Rt = {
	yellow: "games.clever-cubed.die.yellow",
	turq: "games.clever-cubed.die.turq",
	blue: "games.clever-cubed.die.blue",
	brown: "games.clever-cubed.die.brown",
	pink: "games.clever-cubed.die.pink",
	white: "games.clever-cubed.die.white"
}, zt = {
	yellow: "games.clever-cubed.area.yellow",
	turq: "games.clever-cubed.area.turq",
	blue: "games.clever-cubed.area.blue",
	brown: "games.clever-cubed.area.brown",
	pink: "games.clever-cubed.area.pink"
}, Bt = (e, t, n) => {
	let r = (e) => ({ die: n(Rt[e], { n: t.public.dice[e] }) });
	switch (e.type) {
		case "roll": return n("games.clever-cubed.roll");
		case "reroll": return n("games.clever-cubed.hintReroll");
		case "forfeit": return n("games.clever-cubed.forfeit");
		case "pass": return t.public.phase === "extra" ? n("games.clever-cubed.extraDone") : n("games.clever-cubed.passiveSkip");
		case "pick": return n("games.clever-cubed.hintPick", {
			...r(e.die),
			area: n(zt[e.target.area])
		});
		case "bonus": return n("games.clever-cubed.hintBonus", { area: n(zt[e.color]) });
		case "tiePick": return n("games.clever-cubed.tiePrompt", { n: t.public.soloTie?.need ?? 1 });
		default: return "";
	}
}, Vt = {
	name: "Clever Cubed",
	desc: "Two dice feed the blue row, combos cross the turquoise",
	rules: "Goal: Score across five colored areas; at the end each fox scores your lowest area, highest total wins.\nPlay:\n· 6 rounds with 2 players, 5 with 3, 4 with 4; each player is the active player once per round.\n· Solo plays 6 rounds: each round you act as the active player, then as the passive player — reroll all 6 dice, the 3 lowest go to the silver platter, and you record one of them.\n· At the start of each round everyone collects its bonus: reroll (round 1), extra die (round 2), number joker (round 3).\n· Round 4 grants a black ?: pick any area and record a value of 1-6 immediately.\n· The active player rolls all 6 dice, places one on a dice slot and records it in its area; all lower dice go to the silver platter.\n· The rest may be rerolled, at most 3 rolls and 3 placed dice; you may forfeit a roll instead.\n· Then every other player simultaneously records one die from the silver platter (dice stay put); only if no platter die is usable may they use a die from the active player's slots.\n· At the end of the turn, anyone may spend extra-die actions: pick any die (even used ones) and record it once more; each die once per turn.\nAreas:\n· Yellow: cross the matching number in the row of your current roll; passive players may only cross the grey cells. Crossing both cells of a column triggers the bonus printed between them.\n· Turquoise: cross cells of the die's number; each matching die on your slots (platter, when passive) adds one more cross. Filling every dark cell of a row or column triggers its bonus.\n· Blue: enter the sum of the blue and white dice, extending from the central 7 to either side; neighbors must differ by exactly 1. A 7 resets the sequence (two 7s never touch).\n· Brown: cross the matching number, left to right only; you may skip cells but never go back. Crossing both cells around a gap triggers the bonus printed between them.\n· Pink: fill left to right; each cell is a choice — half the die (rounded up) to take the bonus below, or die × the star multiplier (forfeiting it).\n· The white die is wild for any color; blue entries always sum the blue and white dice.\nActions:\n· Reroll: active player only, reroll everything just rolled; Number joker: record the chosen die as another value (a printed box forces its value); Extra die: used at turn end.\n· Action boxes unlock left to right (circle) and are spent by crossing; filling a full track grants its end bonus.\n· ? bonuses must be used immediately: pick a value 1-6 and record it under that area's rules, possibly chaining into more bonuses; the black ? works in any area.\nScoring:\n· Yellow and turquoise score per row by crosses.\n· Blue scores the values printed at the leftmost and rightmost filled cells, plus 4 per filled entry of 4 or less / 10 or more.\n· Brown scores by total crosses; pink sums its entries; each fox = your lowest area score (0 if any area is empty).\n· Ties go to the highest single area, then shared victory.",
	roundChip: "Round {{n}}/{{total}}",
	roll: "Roll",
	reroll: "Reroll ({{n}} left)",
	jokerUse: "Number joker ({{n}} left)",
	jokerPrompt: "Use as which value?",
	forfeit: "Forfeit this roll",
	passiveSkip: "Skip (no die)",
	extraDone: "Done, next player",
	cancel: "Cancel",
	confirm: "Confirm",
	rollPrompt: "Your turn: roll the dice",
	waitingRoll: "Waiting for {{name}} to roll…",
	pickPrompt: "Tap a die below, then a highlighted cell on the sheet",
	waitingPick: "Waiting for {{name}} to pick a die…",
	passivePrompt: "Record one die from the silver platter, or skip",
	waitingPassive: "Waiting for others to pick from the platter…",
	extraPrompt: "Turn end: spend extra-die actions to record again",
	waitingExtra: "Waiting for {{name}} to use extra dice…",
	bonusPrompt: "Resolve your ? bonus: pick a color to use",
	waitingBonus: "Waiting for {{name}} to resolve a ? bonus…",
	roundStart: "New round: collect round bonuses",
	tiePrompt: "Tied dice: pick {{n}} for the platter",
	pinkHalf: "Enter {{n}} + bonus",
	pinkMult: "Enter {{n}} pts",
	blueLeft: "Fill left ({{n}})",
	blueRight: "Fill right ({{n}})",
	turqConfirm: "Cross {{n}} cells",
	soloLevels: [
		"Clever cubed!",
		"Neat AND clever!",
		"Hello, Mr. Hawking!",
		"On the way to the stars",
		"Pretty clever!",
		"Prodigy in training",
		"On the way up",
		"Rather play Yahtzee?",
		"Room to improve",
		"Must have been bad luck",
		"Let's talk about something else"
	],
	hintReroll: "Reroll all dice",
	hintPick: "Record {{die}} in {{area}}",
	hintBonus: "Use the ? bonus on {{area}}",
	die: {
		yellow: "Yellow die {{n}}",
		turq: "Turquoise die {{n}}",
		blue: "Blue die {{n}}",
		brown: "Brown die {{n}}",
		pink: "Pink die {{n}}",
		white: "White die (wild) {{n}}"
	},
	area: {
		yellow: "Yellow",
		turq: "Turquoise",
		blue: "Blue",
		brown: "Brown",
		pink: "Pink"
	},
	errOver: "This game is over",
	errNotYourTurn: "Not your turn",
	errBadStage: "Not in this phase",
	errBadTarget: "That target is not available",
	errBadDie: "That die is not available",
	errNoAction: "No circled action box left",
	errBonusPending: "Resolve your ? bonus first",
	errTiePending: "Decide the platter dice first"
}, Ht = {
	name: "立方聪明",
	desc: "双骰定蓝区,连击叉满绿松石",
	rules: "目标:在五个色区中尽量多地得分;终局每只狐狸奖励等于你最低分区的分数,总分最高者获胜。\n流程:\n· 2 人玩 6 轮,3 人 5 轮,4 人 4 轮;每轮每人当一次主动玩家。\n· 单人玩 6 轮:每轮你先当主动玩家,再扮演被动玩家——重掷全部 6 骰,点数最低的 3 颗上银盘,从中选 1 颗录入。\n· 每轮开始所有人领取轮次奖励:重掷(第 1 轮)、额外骰(第 2 轮)、数字百搭(第 3 轮)。\n· 第 4 轮获得黑色 ?:任选色区,自选 1-6 点立即录入。\n· 主动玩家掷全部 6 骰,选 1 颗放上骰位并录入对应色区;点数更小的骰全部放上银盘。\n· 余骰可再掷,至多掷 3 次、放 3 颗骰;三颗都不想要可放弃本次投掷。\n· 随后其他玩家同时从银盘各选 1 颗骰录入(骰不移走);银盘骰全不可用时,才可改用主动玩家骰位上的骰。\n· 回合末每人可用额外骰行动:任选一颗骰(含已用过的)再录入一次,每颗骰每回合限用一次。\n色区:\n· 黄区:按第几次投掷叉对应行的对应点数格;被动只能叉灰格。同列上下两格都叉,触发两格之间印出的奖励。\n· 绿松石区:叉与骰值同数的格;骰位(被动为银盘)上每有一颗同点骰可多叉 1 格。叉满某行或某列的全部深色格,触发对应奖励。\n· 蓝区:填蓝骰与白骰点数之和,从中央 7 向两侧逐格延伸,相邻两格必须差 1;填 7 可重置数列(两个 7 不相邻)。\n· 棕区:叉与骰值同数的格,只能从左向右,可跳格但不可回头;相邻两格都叉触发两格之间印出的奖励。\n· 粉区:从左向右依次填,每格二选一——填半数(向上取整)拿格下奖励,或填骰值乘星标倍数(放弃奖励)。\n· 白骰是颜色百搭,可当任意色使用;蓝区填数恒为蓝骰加白骰之和。\n行动:\n· 重掷仅主动玩家可用:重掷全部刚掷的骰;数字百搭把所选骰视作另一点数录入(印数字的格必须用该值);额外骰回合末使用。\n· 行动格从左往右依次解锁(圈),使用时划掉;三条行动轨圈满另有行尾奖励。\n· ? 奖励必须立即使用:自选 1-6 点按对应色区规则录入,可连锁触发新奖励;黑色 ? 可任选色区。\n结算:\n· 黄区与绿松石区按每行叉数查表。\n· 蓝区按最左侧与最右侧已填格印出的分值计分,每个不大于 4 或不小于 10 的已填数再加 4 分。\n· 棕区按总叉数查表;粉区求填入值之和;每只狐狸 = 最低分区得分(有区为 0 分则狐狸为 0 分)。\n· 平分则单区最高者胜,再平共享胜利。",
	roundChip: "第 {{n}}/{{total}} 轮",
	roll: "掷骰",
	reroll: "重掷(剩 {{n}})",
	jokerUse: "数字百搭(剩 {{n}})",
	jokerPrompt: "视作几点?",
	forfeit: "放弃本次投掷",
	passiveSkip: "跳过(不选骰)",
	extraDone: "完成,换下一位",
	cancel: "取消",
	confirm: "确认",
	rollPrompt: "轮到你了:掷骰",
	waitingRoll: "等 {{name}} 掷骰…",
	pickPrompt: "点底部骰子,再点表上高亮格录入",
	waitingPick: "等 {{name}} 选骰…",
	passivePrompt: "从银盘选一颗骰录入,或跳过",
	waitingPassive: "等其他玩家从银盘选骰…",
	extraPrompt: "回合末:可用额外骰行动再录入(点骰子选目标)",
	waitingExtra: "等 {{name}} 使用额外骰…",
	bonusPrompt: "结算 ? 奖励:选一种颜色用掉它",
	waitingBonus: "等 {{name}} 结算 ? 奖励…",
	roundStart: "新一轮开始:领取轮次奖励",
	tiePrompt: "同点并列:选 {{n}} 颗上银盘",
	pinkHalf: "填 {{n}},拿奖励",
	pinkMult: "填 {{n}} 分",
	blueLeft: "填到左侧({{n}})",
	blueRight: "填到右侧({{n}})",
	turqConfirm: "确认叉 {{n}} 格",
	soloLevels: [
		"立方聪明!",
		"漂亮且聪明!",
		"你好,霍金先生!",
		"迈向星辰",
		"相当聪明!",
		"神童养成中",
		"渐入佳境",
		"要不还是玩快艇?",
		"还有上升空间",
		"准是手气不好",
		"换个话题吧"
	],
	hintReroll: "重掷全部骰子",
	hintPick: "用 {{die}} 录入{{area}}",
	hintBonus: "? 奖励落在{{area}}",
	die: {
		yellow: "黄骰 {{n}} 点",
		turq: "绿松石骰 {{n}} 点",
		blue: "蓝骰 {{n}} 点",
		brown: "棕骰 {{n}} 点",
		pink: "粉骰 {{n}} 点",
		white: "白骰(百搭){{n}} 点"
	},
	area: {
		yellow: "黄区",
		turq: "绿松石区",
		blue: "蓝区",
		brown: "棕区",
		pink: "粉区"
	},
	errOver: "本局已结束",
	errNotYourTurn: "现在轮不到你",
	errBadStage: "现在不是这个阶段",
	errBadTarget: "这个目标不可用",
	errBadDie: "这颗骰不可用",
	errNoAction: "对应的行动格已用完",
	errBonusPending: "先结算 ? 奖励",
	errTiePending: "先决定哪颗骰上银盘"
}, Ut = {
	yellow: "games.clever-cubed.area.yellow",
	turq: "games.clever-cubed.area.turq",
	blue: "games.clever-cubed.area.blue",
	brown: "games.clever-cubed.area.brown",
	pink: "games.clever-cubed.area.pink"
};
function Wt({ public: e, rid: t }) {
	let n = s(), r = o((e) => e.locale), i = e, a = i.sheets[t];
	if (!a) return null;
	let c = H(a);
	return /* @__PURE__ */ p("div", {
		className: "cc3-over-details mt-1.5",
		children: [
			i.players.length === 1 && /* @__PURE__ */ f("div", {
				className: "mb-0.5 text-xs font-black",
				style: { color: "var(--color-ink)" },
				children: (r === "zh" ? Ht : Vt).soloLevels[ke(c.total)]
			}),
			/* @__PURE__ */ p("div", {
				className: "flex flex-wrap items-center gap-x-2 gap-y-0.5 font-mono text-xs tabular-nums",
				children: [w.map((e) => /* @__PURE__ */ p("span", { children: [
					n(Ut[e]),
					" ",
					c.areas[e]
				] }, e)), /* @__PURE__ */ p("span", { children: [
					"🦊 ",
					c.foxes,
					"×",
					c.foxScore / Math.max(c.foxes, 1) || 0
				] })]
			}),
			/* @__PURE__ */ f("div", {
				className: "cc3-over-paper frame pointer-events-none mt-1 overflow-hidden",
				"aria-hidden": !0,
				children: /* @__PURE__ */ f("div", {
					style: { aspectRatio: `${Ye} / ${Xe}` },
					children: /* @__PURE__ */ f(yt, {
						sheet: a,
						round: i.roundsTotal,
						roundsTotal: i.roundsTotal,
						slots: [
							null,
							null,
							null
						],
						dice: i.dice,
						readOnly: !0,
						fitKey: `over-${t}`
					})
				})
			})
		]
	});
}
//#endregion
//#region src/games/clever-cubed/game-over.tsx
function Gt(e) {
	return /* @__PURE__ */ f("div", {
		className: "cc3-over",
		children: /* @__PURE__ */ f(m, {
			hintCount: e.hintCount,
			result: e.result,
			members: e.members,
			myRid: e.myRid,
			accent: h.accent,
			onPlayAgain: e.onPlayAgain,
			onBackToLobby: e.onBackToLobby,
			renderRowExtra: (t) => /* @__PURE__ */ f(Wt, {
				public: e.public,
				rid: t,
				myRid: e.myRid
			})
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/clever-cubed/entry.tsx
var Kt = {
	definition: Je,
	View: Tt,
	bot: Lt,
	describe: Bt,
	OverView: Gt,
	RowView: Wt,
	locales: {
		zh: Ht,
		en: Vt
	}
};
//#endregion
export { Kt as default };
