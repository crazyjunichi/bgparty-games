import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useState as r } from "react";
import { gameAssetUrl as i } from "@bgparty/sdk/assets";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as o } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { AVATARS as d } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { seatName as p } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, FlySprite as v, PulseBox as ee } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as y } from "@bgparty/sdk/confirm-button";
import { OptionRadio as b, OptionSection as x } from "@bgparty/sdk/ui/game-options";
//#region src/game/data.ts
var S = [
	"wood",
	"stone",
	"clay",
	"gold",
	"marble",
	"silver"
], C = (e = {}) => ({
	wood: 0,
	stone: 0,
	clay: 0,
	gold: 0,
	marble: 0,
	silver: 0,
	...e
}), w = [
	"forest",
	"quarry",
	"mines",
	"silversmith",
	"storehouse",
	"workshop",
	"town",
	"tax",
	"guard",
	"guild",
	"small",
	"middle",
	"large"
], T = w.slice(0, 9), E = (e, t, n, r, i, a = 0, o = "", s = "") => ({
	id: e,
	name: t,
	cost: C(n),
	skills: r,
	vp: i,
	virtue: a,
	effect: o,
	end: s
}), D = "carpentry", O = "tiling", k = "masonry", A = [
	E(0, "games.architectsofthewestkingdom.b0", {
		clay: 3,
		wood: 1,
		stone: 1
	}, [], 5, 0, "", "carpentry"),
	E(1, "games.architectsofthewestkingdom.b1", {
		clay: 3,
		stone: 3
	}, [], 5, 1, "destroy"),
	E(2, "games.architectsofthewestkingdom.b2", {
		wood: 3,
		stone: 2,
		gold: 1
	}, [D], 6, 0, "hire"),
	E(3, "games.architectsofthewestkingdom.b3", {
		clay: 4,
		stone: 2
	}, [], 3, 0, "wood4"),
	E(4, "games.architectsofthewestkingdom.b4", {
		wood: 1,
		stone: 3,
		gold: 2
	}, [k], 7, 0, "", "basicVirtue"),
	E(5, "games.architectsofthewestkingdom.b5", {
		clay: 1,
		wood: 3,
		stone: 2
	}, [D, k], 8, -2, "releasePrison"),
	E(6, "games.architectsofthewestkingdom.b6", {
		wood: 1,
		stone: 3,
		gold: 1
	}, [O], 6, 0, "treasury"),
	E(7, "games.architectsofthewestkingdom.b7", {
		clay: 3,
		stone: 2,
		gold: 1
	}, [O], 6, 0, "", "mostClay"),
	E(8, "games.architectsofthewestkingdom.b8", {
		stone: 4,
		gold: 3
	}, [D, O], 8, 0, "draw2"),
	E(9, "games.architectsofthewestkingdom.b9", {
		clay: 1,
		wood: 2,
		stone: 3
	}, [k], 8, -2, "silver4"),
	E(10, "games.architectsofthewestkingdom.b10", {
		clay: 3,
		wood: 4,
		gold: 1,
		marble: 1
	}, [
		D,
		O,
		k
	], 11, -1, "watchtower"),
	E(11, "games.architectsofthewestkingdom.b11", {
		clay: 2,
		wood: 1,
		stone: 4
	}, [D], 6, 1, "", "cathedralVirtue"),
	E(12, "games.architectsofthewestkingdom.b12", {
		wood: 3,
		stone: 3,
		marble: 2
	}, [O, k], 9, 0, "palace"),
	E(13, "games.architectsofthewestkingdom.b13", {
		wood: 3,
		stone: 5,
		gold: 1
	}, [D, k], 9, 0, "capture1"),
	E(14, "games.architectsofthewestkingdom.b14", {
		clay: 6,
		wood: 1
	}, [], 4, 0, "", "paidVirtue"),
	E(15, "games.architectsofthewestkingdom.b15", {
		clay: 2,
		wood: 4,
		gold: 1
	}, [D], 7, 0, "", "mostWood"),
	E(16, "games.architectsofthewestkingdom.b16", {
		clay: 3,
		stone: 4,
		gold: 1,
		marble: 2
	}, [
		D,
		O,
		k
	], 12, -2, "capture2"),
	E(17, "games.architectsofthewestkingdom.b17", {
		stone: 1,
		gold: 1,
		marble: 3
	}, [D, O], 10, -2, "", "debtExtra"),
	E(18, "games.architectsofthewestkingdom.b18", {
		stone: 4,
		gold: 2,
		marble: 2
	}, [
		D,
		O,
		k
	], 14, -1, "", "dungeon"),
	E(19, "games.architectsofthewestkingdom.b19", {
		wood: 2,
		stone: 2,
		gold: 3
	}, [k], 7, 0, "marble2"),
	E(20, "games.architectsofthewestkingdom.b20", {
		wood: 2,
		gold: 2
	}, [], 4, 1, "", "cathedralPoints"),
	E(21, "games.architectsofthewestkingdom.b21", {
		wood: 4,
		stone: 2,
		marble: 1
	}, [D, O], 8, 0, "library"),
	E(22, "games.architectsofthewestkingdom.b22", {
		clay: 2,
		wood: 6,
		gold: 2
	}, [
		D,
		O,
		k
	], 10, 0, "barracks"),
	E(23, "games.architectsofthewestkingdom.b23", {
		wood: 2,
		stone: 2
	}, [], 3, 0, "clay4"),
	E(24, "games.architectsofthewestkingdom.b24", {
		clay: 2,
		wood: 3,
		gold: 1
	}, [], 3, 0, "", "buildings"),
	E(25, "games.architectsofthewestkingdom.b25", {
		clay: 2,
		wood: 4,
		gold: 1,
		marble: 2
	}, [
		D,
		O,
		k
	], 10, 0, "", "goldVirtue"),
	E(26, "games.architectsofthewestkingdom.b26", {
		wood: 3,
		stone: 1,
		marble: 2
	}, [O], 6, 0, "", "virtuePoints"),
	E(27, "games.architectsofthewestkingdom.b27", {
		wood: 2,
		gold: 1,
		marble: 1
	}, [O], 6, 0, "", "mostSilver"),
	E(28, "games.architectsofthewestkingdom.b28", {
		wood: 5,
		stone: 2,
		gold: 2
	}, [
		D,
		O,
		k
	], 12, -2, "", "captives"),
	E(29, "games.architectsofthewestkingdom.b29", {
		stone: 3,
		marble: 1
	}, [], 4, 1, "", "debtDiscount"),
	E(30, "games.architectsofthewestkingdom.b30", {
		clay: 1,
		stone: 2,
		gold: 1
	}, [], 7, -1, "debt"),
	E(31, "games.architectsofthewestkingdom.b31", {
		clay: 4,
		wood: 2,
		gold: 1
	}, [k], 5, -1, "", "paidPoints"),
	E(32, "games.architectsofthewestkingdom.b32", {
		wood: 2,
		stone: 3,
		marble: 2
	}, [O, k], 9, 1, "monument"),
	E(33, "games.architectsofthewestkingdom.b33", {
		clay: 2,
		stone: 4,
		marble: 1
	}, [k], 7, 0, "", "mostStone"),
	E(34, "games.architectsofthewestkingdom.b34", {
		clay: 1,
		wood: 3,
		stone: 1,
		gold: 1
	}, [D], 7, 0, "", "marbleVirtue"),
	E(35, "games.architectsofthewestkingdom.b35", {
		clay: 2,
		wood: 1,
		stone: 2
	}, [], 5, 0, "", "tiling"),
	E(36, "games.architectsofthewestkingdom.b36", {
		wood: 2,
		stone: 4
	}, [], 5, 0, "", "masonry"),
	E(37, "games.architectsofthewestkingdom.b37", {
		clay: 4,
		wood: 2
	}, [], 3, 0, "stone4"),
	E(38, "games.architectsofthewestkingdom.b38", {
		clay: 4,
		wood: 1
	}, [], 3, 0, "claypit"),
	E(39, "games.architectsofthewestkingdom.b39", {
		clay: 4,
		wood: 2,
		stone: 3,
		marble: 2
	}, [
		D,
		O,
		k
	], 11, 1, "", "noDebt")
], j = (e, t, n, r, i, a = {}, o, s) => ({
	id: e,
	name: t,
	skill: n,
	virtue: r,
	trigger: i,
	gain: a,
	trade: o,
	benefit: s
}), M = [
	j(0, "games.architectsofthewestkingdom.aPatron", [D], 0, "trade", {}, { wood: 1 }, "virtue"),
	j(1, "games.architectsofthewestkingdom.aSwindler", [O], -1, "market", { clay: 2 }),
	j(2, "games.architectsofthewestkingdom.aTrader", [D], 0, "trade", { marble: 1 }, { wood: 2 }),
	j(3, "games.architectsofthewestkingdom.aPatron", [O], 0, "trade", {}, { clay: 1 }, "virtue"),
	j(4, "games.architectsofthewestkingdom.aAcolyte", [k], 1, "cathedral", { silver: 2 }),
	j(5, "games.architectsofthewestkingdom.aMerchant", [k], 0, "trade", { gold: 1 }, { silver: 2 }),
	j(6, "games.architectsofthewestkingdom.aStonecutter", [k], 0, "quarry", { stone: 1 }),
	j(7, "games.architectsofthewestkingdom.aTrader", [k], 0, "trade", { marble: 1 }, { stone: 2 }),
	j(8, "games.architectsofthewestkingdom.aWoodcutter", [D], 0, "forest", { wood: 1 }),
	j(9, "games.architectsofthewestkingdom.aMiner", [O], 0, "mines", { clay: 1 }),
	j(10, "games.architectsofthewestkingdom.aPickpocket", [O], -1, "tax", { gold: 1 }),
	j(11, "games.architectsofthewestkingdom.aSwindler", [k], -1, "market", { wood: 1 }),
	j(12, "games.architectsofthewestkingdom.aDebtCollector", [k], 0, "paid", { stone: 2 }),
	j(13, "games.architectsofthewestkingdom.aAcolyte", [D], 1, "cathedral", {}, void 0, "draw"),
	j(14, "games.architectsofthewestkingdom.aLabourer", [
		D,
		O,
		k
	], 0, ""),
	j(15, "games.architectsofthewestkingdom.aWoodcutter", [D], 0, "forest", { wood: 1 }),
	j(16, "games.architectsofthewestkingdom.aJeweller", [O], 0, "silversmith", { silver: 1 }),
	j(17, "games.architectsofthewestkingdom.aConspirator", [D], 0, "captureDiscount"),
	j(18, "games.architectsofthewestkingdom.aPatron", [k], 0, "trade", {}, { silver: 2 }, "virtue"),
	j(19, "games.architectsofthewestkingdom.aSquire", [k], 1, "reset", { marble: 1 }),
	j(20, "games.architectsofthewestkingdom.aTrickster", [k], -1, "marketDiscount"),
	j(21, "games.architectsofthewestkingdom.aAcolyte", [O], 1, "cathedral", { clay: 2 }),
	j(22, "games.architectsofthewestkingdom.aThief", [D], 0, "taxDiscount"),
	j(23, "games.architectsofthewestkingdom.aMiner", [O], 0, "mines", { clay: 1 }),
	j(24, "games.architectsofthewestkingdom.aIllusionist", [D], -1, "marketVirtue"),
	j(25, "games.architectsofthewestkingdom.aMerchant", [D], 0, "trade", { wood: 2 }, { silver: 1 }),
	j(26, "games.architectsofthewestkingdom.aMerchant", [k], 0, "trade", { stone: 2 }, { silver: 1 }),
	j(27, "games.architectsofthewestkingdom.aConspirator", [D], 0, "captureDiscount"),
	j(28, "games.architectsofthewestkingdom.aJeweller", [O], 0, "silversmith", { silver: 1 }),
	j(29, "games.architectsofthewestkingdom.aMerchant", [D], 0, "trade", { clay: 3 }, { silver: 1 }),
	j(30, "games.architectsofthewestkingdom.aMerchant", [O], 0, "trade", { marble: 1 }, { silver: 3 }),
	j(31, "games.architectsofthewestkingdom.aPatron", [k], 0, "trade", {}, { stone: 1 }, "virtue"),
	j(32, "games.architectsofthewestkingdom.aSquire", [O], 1, "reset", { gold: 1 }),
	j(33, "games.architectsofthewestkingdom.aSquire", [D], 1, "reset", {}, void 0, "virtue2"),
	j(34, "games.architectsofthewestkingdom.aStonecutter", [k], 0, "quarry", { stone: 1 }),
	j(35, "games.architectsofthewestkingdom.aDebtCollector", [O], 0, "paid", { clay: 2 }),
	j(36, "games.architectsofthewestkingdom.aGatekeeper", [O], -1, "reset", {}, void 0, "release2"),
	j(37, "games.architectsofthewestkingdom.aTrader", [D], 0, "trade", { marble: 1 }, { clay: 3 }),
	j(38, "games.architectsofthewestkingdom.aDebtCollector", [D], 0, "paid", { wood: 2 }),
	j(39, "games.architectsofthewestkingdom.aSwindler", [k], -1, "market", { stone: 1 })
], te = [
	-9,
	-8,
	-7,
	-5,
	-3,
	-1,
	0,
	0,
	0,
	0,
	1,
	2,
	3,
	5,
	7
], ne = [
	0,
	2,
	4,
	7,
	12,
	20
], re = [
	0,
	3,
	2,
	2,
	2,
	1
], ie = [
	C({
		marble: 2,
		wood: 2
	}),
	C({
		marble: 1,
		gold: 1,
		stone: 1,
		wood: 1
	}),
	C({
		gold: 1,
		stone: 1,
		wood: 2
	}),
	C({
		marble: 2,
		stone: 2
	}),
	C({
		marble: 1,
		wood: 1,
		stone: 2
	}),
	C({
		marble: 2,
		wood: 2
	}),
	C({
		marble: 1,
		wood: 1,
		stone: 2
	}),
	C({
		gold: 1,
		stone: 1,
		wood: 2
	}),
	C({
		marble: 1,
		gold: 1,
		stone: 1,
		wood: 1
	}),
	C({
		marble: 2,
		stone: 2
	})
], ae = [
	C({ marble: 1 }),
	C({ gold: 2 }),
	C({
		marble: 1,
		stone: 1
	}),
	C({
		gold: 1,
		wood: 1
	}),
	C({
		marble: 1,
		wood: 1
	}),
	C({ marble: 1 }),
	C({ gold: 2 }),
	C({
		marble: 1,
		stone: 1
	}),
	C({
		gold: 1,
		wood: 1
	}),
	C({
		marble: 1,
		wood: 1
	})
], oe = ie, se = [
	0,
	0,
	1,
	1,
	2,
	3,
	3,
	4,
	4,
	5,
	5
], ce = [
	1,
	2,
	2,
	4,
	4,
	5,
	10,
	11,
	12,
	13,
	13,
	13,
	14,
	15,
	15,
	15,
	16,
	18,
	18,
	19
], le = [
	0,
	3,
	6,
	7,
	7,
	7,
	8,
	9,
	17,
	20
], ue = {
	id: "architectsofthewestkingdom",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"engine-building",
		"hand-management"
	],
	interactionTags: [],
	nameKey: "games.architectsofthewestkingdom.name",
	descKey: "games.architectsofthewestkingdom.desc",
	rulesKey: "games.architectsofthewestkingdom.rules",
	icon: "🏰",
	iconImg: "games/architectsofthewestkingdom.webp",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	accent: "#75492c",
	releasedAt: "2026-11-11T00:12:00+08:00",
	search: {
		py: "xi guo jian zhu shi",
		init: "xgjzs"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/5107676531851159940/956C80F8DD2EA59B247D49BF0DBFBECDF1B5FD8B/" }
}, de = t.object({
	variable: t.boolean().default(!1),
	solo: t.enum(["constantine", "helena"]).default("constantine")
}).default({
	variable: !1,
	solo: "constantine"
}), fe = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(160)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), pe = t.object({
	wood: t.int().nonnegative(),
	stone: t.int().nonnegative(),
	clay: t.int().nonnegative(),
	gold: t.int().nonnegative(),
	marble: t.int().nonnegative(),
	silver: t.int().nonnegative()
}), me = t.object({
	id: t.string(),
	kind: t.string(),
	location: t.enum(w).optional(),
	card: t.int().optional(),
	target: t.string().optional(),
	n: t.number().optional(),
	cost: pe.optional(),
	gain: pe.optional(),
	resource: t.enum(S).optional()
}), he = t.object({
	rid: t.string(),
	role: t.string(),
	stock: pe,
	workers: t.int().nonnegative(),
	virtue: t.int().min(0).max(14),
	debt: t.int().nonnegative(),
	paid: t.int().nonnegative(),
	cathedral: t.int().min(0).max(5),
	prison: t.int().nonnegative(),
	captives: t.record(t.string(), t.int().nonnegative()),
	apprentices: t.array(t.int()),
	built: t.array(t.int()),
	guild: t.int().nonnegative(),
	handCount: t.int().nonnegative()
}), ge = t.object({
	players: t.array(he),
	active: t.string(),
	phase: t.string(),
	turn: t.int(),
	draftRound: t.int(),
	draftReady: t.array(t.string()),
	locations: t.record(t.string(), t.record(t.string(), t.int().nonnegative())),
	market: t.array(t.object({
		card: t.int(),
		silver: t.int().nonnegative()
	}).nullable()),
	guild: t.array(t.string()),
	guildLimit: t.int(),
	tax: t.int().nonnegative(),
	small: pe,
	large: pe,
	deckCount: t.int(),
	apprenticeCount: t.int(),
	rewardCount: t.int(),
	finalTurns: t.int().nullable(),
	pending: t.string(),
	remaining: t.int(),
	last: t.object({
		kind: t.string(),
		rid: t.string(),
		location: t.string().optional(),
		card: t.int().optional(),
		n: t.number().optional()
	}).nullable(),
	reset: t.int(),
	scores: t.record(t.string(), t.record(t.string(), t.number())).nullable(),
	automa: t.string().nullable(),
	scheme: t.int().nullable()
}), _e = t.object({
	hand: t.array(t.int()),
	pool: t.array(t.int()),
	choices: t.array(me)
}), ve = [
	"ada",
	"frederick",
	"caroline",
	"rudolf",
	"therese"
], N = (e, t) => e.players.find((e) => e.rid === t), P = (e) => e.order[e.turnIndex], F = (e, t, n) => e.locations[t]?.[n] ?? 0, I = (e) => e.players.length + 1, ye = (e) => (e.virtue <= 1 ? 2 : +(e.virtue <= 3)) + +(e.role === "ada"), L = (e, t, n = 0) => t + Math.max(0, n - ye(e));
function be(e, t, n, r = 0) {
	let i = Math.max(0, r - ye(t));
	t.stock.silver -= n + i, e.tax += i;
}
function R(e, t) {
	for (let n of S) e.stock[n] += t[n] ?? 0;
}
function z(e, t) {
	let n = e.virtue + t;
	n < 0 && (e.debt -= n), n > 14 && (e.debt = Math.max(0, e.debt - (n - 14))), e.virtue = Math.max(0, Math.min(14, n));
}
function B(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function V(e, t, n) {
	t.hand.push(...e.buildings.splice(0, n));
}
function H(e, ...t) {
	e.effects.unshift(...t);
}
function xe(e, t, n, r, i) {
	H(e, {
		rid: t,
		kind: n,
		...r === void 0 ? {} : { n: r },
		...i ? { gain: C(i) } : {}
	});
}
function Se(e, t, n) {
	let r = [];
	for (let e of t.apprentices) {
		let i = M[e];
		i.trigger === n && (r.push({
			kind: "gain",
			rid: t.rid,
			gain: C(i.gain)
		}), i.benefit === "draw" && r.push({
			kind: "draw",
			rid: t.rid,
			n: 1
		}));
	}
	H(e, ...r);
}
function Ce(e, t) {
	if (e.role !== "therese") return S.every((n) => e.stock[n] >= t[n]) ? [t] : [];
	let n = [], r = t.gold + t.marble;
	for (let i = 0; i <= r; i++) {
		let a = {
			...t,
			gold: i,
			marble: r - i
		};
		S.every((t) => e.stock[t] >= a[t]) && n.push(a);
	}
	return n;
}
function we(e, t) {
	return A[t].skills.every((t) => e.apprentices.some((e) => M[e].skill.includes(t)));
}
function Te(e, t) {
	let n = t.cathedral + 1;
	if (n > 5 || t.virtue <= 4 || !t.hand.length && t.role !== "frederick" || e.players.filter((e) => e.cathedral === n).length >= re[n]) return [];
	if (n === 1) return Ce(t, C({ gold: 1 }));
	if (n === 3) return Ce(t, C({ marble: 1 }));
	if (n === 5) return Ce(t, C({
		gold: 2,
		marble: 2
	}));
	let r = n === 2 ? 4 : 8;
	return Array.from({ length: r + 1 }, (e, t) => C({
		wood: t,
		stone: r - t
	})).filter((e) => t.stock.wood >= e.wood && t.stock.stone >= e.stone);
}
function U(e, t, n, r = {}) {
	e.push({
		id: t,
		kind: n,
		...r
	});
}
function Ee(e, t) {
	let n = [];
	for (let e of t.hand) if (we(t, e)) for (let r of Ce(t, A[e].cost)) U(n, `build:${e}:${r.gold}`, "build", {
		card: e,
		cost: r
	});
	for (let r of Te(e, t)) {
		let e = t.role === "frederick" ? [-1] : t.hand;
		for (let i of e) U(n, `cathedral:${i}:${r.wood}:${r.gold}`, "cathedral", {
			card: i >= 0 ? i : void 0,
			cost: r,
			n: t.cathedral + 1
		});
	}
	return n;
}
function De(e, t, n) {
	if (t.apprentices.length >= (t.role === "rudolf" ? 6 : 5)) return [];
	let r = [];
	for (let i = 0; i < 8; i++) {
		let a = e.market[i];
		if (!a) continue;
		let o = n.source === "workshop" ? Math.max(0, i % 4 + 1 - (n.power ?? 1)) : 0, s = n.source === "workshop" ? L(t, t.role === "rudolf" ? 1 : 2, 2) : 0;
		t.stock.silver >= s + o && U(r, `hire:${a.card}`, "hire", {
			card: a.card,
			target: `market:${i}`,
			n: o,
			cost: C({ silver: s + o }),
			gain: C({ silver: a.silver })
		});
	}
	return r;
}
function Oe(e, t, n) {
	let r = [], i = n.source === "town", a = (n.used?.length ?? 0) === 0, o = a ? 0 : Math.max(0, 1 - (n.discount ?? 0)), s = +!!a;
	if (i && t.stock.silver < L(t, o, s)) return r;
	let c = n.source === "fortress" || e.players.length <= 3 ? 2 : 1, l = new Set((n.used ?? []).map((e) => e.split("/")[0]));
	for (let n of T) if (l.has(n) || l.size < c) for (let a of e.players) {
		let c = F(e, n, a.rid);
		c && U(r, `capture:${n}:${a.rid}`, "capture", {
			location: n,
			target: a.rid,
			n: c,
			cost: C({ silver: i ? L(t, o, s) : 0 })
		});
	}
	return r;
}
function ke(e) {
	let t = [];
	for (let n = 0; n <= 2; n++) for (let r = 0; r <= 2 - n; r++) {
		let i = 2 - n - r, a = C({
			wood: n,
			stone: r,
			clay: i
		});
		S.every((t) => e.stock[t] >= a[t]) && U(t, `trade:v:${n}:${r}`, "tradeVirtue", {
			cost: a,
			n: 1
		});
	}
	for (let n = 0; n <= 3; n++) {
		let r = C({
			wood: n,
			stone: 3 - n
		});
		e.stock.wood >= n && e.stock.stone >= 3 - n && U(t, `trade:m:${n}`, "trade", {
			cost: r,
			gain: C({ marble: 1 })
		});
	}
	for (let n of e.apprentices) {
		let r = M[n];
		if (r.trigger !== "trade" || !r.trade) continue;
		let i = C(r.trade);
		S.every((t) => e.stock[t] >= i[t]) && U(t, `trade:a:${n}`, r.benefit === "virtue" ? "tradeVirtue" : "trade", {
			card: n,
			cost: i,
			gain: C(r.gain),
			n: r.benefit === "virtue" ? 1 : void 0
		});
	}
	return t;
}
function Ae(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n || t === e.automa || e.phase === "done") return [];
	let r = [];
	if (e.phase === "draft") {
		if (e.draftPicks[t] !== void 0) return [];
		for (let e of n.pool) U(r, `draft:${e}`, "draft", { card: e });
		return r;
	}
	let i = e.pending;
	if (i?.rid !== t && (!i && e.phase !== "turn" || P(e) !== t)) return [];
	if (!i && e.phase === "turn") {
		if (n.workers === 0) {
			for (let n of T) F(e, n, t) && U(r, `recover:${n}`, "recover", {
				location: n,
				n: 1
			});
			return r;
		}
		for (let i of w) if ((i !== "tax" || e.tax !== 0) && (i !== "guild" || Ee(e, n).length)) {
			if ([
				"small",
				"middle",
				"large"
			].includes(i)) {
				let t = [
					"small",
					"middle",
					"large"
				].indexOf(i);
				if (n.virtue >= 10 || Object.values(e.locations[i]).some((e) => e > 0) || n.stock.silver < Math.max(0, t + 1 - n.apprentices.filter((e) => M[e].trigger === "marketDiscount").length)) continue;
			}
			U(r, `place:${i}`, "place", {
				location: i,
				n: F(e, i, t) + 1
			});
		}
	}
	if (i && i.rid === t) switch (i.kind) {
		case "mines":
			U(r, "mine:clay", "gather", {
				resource: "clay",
				gain: C({ clay: (i.power ?? 1) + 1 })
			}), (i.power ?? 1) >= 2 && U(r, "mine:gold", "gather", {
				resource: "gold",
				gain: C({ gold: Math.floor((i.power ?? 1) / 2) })
			});
			break;
		case "workshop":
			U(r, "plans", "plans", { n: 1 + Math.floor((i.power ?? 1) / 2) }), r.push(...De(e, n, {
				...i,
				source: "workshop"
			}));
			break;
		case "hire":
			r.push(...De(e, n, i)), i.source === "tavern" && U(r, "finish", "finish");
			break;
		case "middle":
			r.push(...De(e, n, i)), e.buildings.length && U(r, "marketPlans", "marketPlans", { n: Math.min(5, e.buildings.length) }), r.length || U(r, "finish", "finish");
			break;
		case "pick":
			for (let e of i.pool ?? []) U(r, `pick:${e}`, "pick", { card: e });
			break;
		case "guild":
			r.push(...Ee(e, n));
			break;
		case "store":
			r.push(...ke(n)), U(r, "finish", "finish");
			break;
		case "capture":
			r.push(...Oe(e, n, i)), U(r, "finish", "finish");
			break;
		case "guard": {
			let i = Object.values(n.captives).reduce((e, t) => e + t, 0);
			i && U(r, "guard:sell", "sell", {
				n: i,
				gain: C({ silver: i })
			}), n.prison && U(r, "guard:release", "release", { n: n.prison });
			let a = e.players.reduce((e, n) => e + (n.captives[t] ?? 0), 0);
			a && (n.stock.silver >= L(n, 3, 2) && U(r, "guard:ransom", "ransom", {
				cost: C({ silver: L(n, 3, 2) }),
				n: a
			}), U(r, "guard:debt", "ransomDebt", { n: a })), n.debt && n.stock.silver >= L(n, 3, 3) && U(r, "guard:pay", "payDebt", { cost: C({ silver: L(n, 3, 3) }) }), U(r, "finish", "finish");
			break;
		}
		case "discard":
			for (let e of n.hand) U(r, `discard:${e}`, "discard", { card: e });
			break;
		case "treasury":
			U(r, "reward:gold", "gather", { gain: C({ gold: 1 }) }), U(r, "reward:silver", "gather", { gain: C({ silver: 3 }) });
			break;
		case "claypit":
			U(r, "reward:gold", "gather", { gain: C({ gold: 1 }) }), U(r, "reward:marble", "gather", { gain: C({ marble: 1 }) });
			break;
		case "library":
			for (let e of n.hand) U(r, `library:${e}`, "library", {
				card: e,
				gain: C({ gold: 2 })
			});
			U(r, "finish", "finish");
			break;
		case "barracks":
			e.players.some((e) => (e.captives[t] ?? 0) > 0) && U(r, "barracks:release", "ransomFree"), r.push(...Oe(e, n, {
				...i,
				kind: "capture",
				remaining: 1
			})), U(r, "finish", "finish");
			break;
		case "resetSkills":
			for (let e of i.pool ?? []) U(r, `resetSkill:${e}`, "resetSkill", { card: e }), M[e].benefit === "release2" && U(r, `skipSkill:${e}`, "resetSkill", {
				card: e,
				n: 0
			});
			break;
		case "finalEffects": for (let e of i.pool ?? []) U(r, `finalEffect:${e}`, "finalEffect", { card: e });
	}
	if ((e.phase === "turn" || e.phase === "choice") && P(e) === t && ![
		"discard",
		"resetSkills",
		"finalEffects"
	].includes(i?.kind ?? "")) for (let e of n.apprentices) U(r, `drop:${e}`, "drop", { card: e });
	return r;
}
function je(e, t, n) {
	let r = de.parse(e), i = {
		players: [],
		order: [...t],
		turnIndex: 0,
		turn: 1,
		phase: "draft",
		seed: n,
		cursor: 0,
		config: r,
		buildings: [],
		apprentices: [],
		rewards: [],
		smallPile: [],
		largePile: [],
		market: [],
		locations: Object.fromEntries(w.map((e) => [e, {}])),
		guild: [],
		tax: 4,
		draftRound: 1,
		draftPicks: {},
		pending: null,
		effects: [],
		resetDue: !1,
		reset: 0,
		finalTurns: null,
		scores: null,
		last: null,
		beat: 620,
		automa: t.length === 1 ? "$byzantine" : null,
		schemes: [],
		schemeDiscard: [],
		future: [],
		scheme: null
	}, a = B(i, ve);
	i.order = B(i, t), i.automa && (i.order = [...t, i.automa]);
	for (let [e, t] of i.order.entries()) {
		let n = t === i.automa ? r.solo : r.variable ? a[e] : "standard", o = {
			rid: t,
			role: n,
			stock: C({ silver: 3 + e }),
			workers: 20,
			virtue: 7,
			debt: 0,
			paid: 0,
			cathedral: 0,
			prison: 0,
			captives: {},
			apprentices: [],
			built: [],
			guild: 0,
			hand: [],
			pool: []
		};
		n === r.solo && (o.stock.silver = 0), n === "ada" && (o.stock = C({ gold: 1 }), o.virtue = 11), n === "frederick" && (o.stock = C({
			silver: 4,
			stone: 1
		})), n === "caroline" && (o.stock = C({
			silver: 10,
			marble: 1
		}), o.prison = 8, o.workers = 12, o.virtue = 3, o.debt = 1), n === "rudolf" && (o.stock = C({
			silver: 3,
			wood: 1
		}), o.virtue = 9), n === "therese" && (o.stock = C({ silver: 5 }), o.prison = 4, o.workers = 16, o.virtue = 5), i.players.push(o);
	}
	if (r.variable && !i.automa) {
		let e = i.players.reduce((e, t) => e.virtue >= t.virtue ? e : t).rid, t = i.order.indexOf(e);
		i.order = [...i.order.slice(t), ...i.order.slice(0, t)];
	}
	i.buildings = B(i, A.map((e) => e.id).filter((e) => !i.automa || ![
		7,
		15,
		27,
		33
	].includes(e))), i.apprentices = B(i, M.map((e) => e.id)), i.rewards = B(i, se).slice(0, 2 * i.players.length + 1), i.smallPile = B(i, Array.from({ length: 10 }, (e, t) => t)), i.market = i.apprentices.splice(0, 8).map((e) => ({
		card: e,
		silver: 0
	})), i.schemes = B(i, ce), i.future = B(i, le);
	for (let e of i.players) e.rid !== i.automa && (e.pool = i.buildings.splice(0, i.automa ? 5 : 4));
	return { state: i };
}
function W(e) {
	e.pending = null, e.phase = "resolve";
}
function Me(e) {
	e.pending && (e.pending.remaining--, e.pending.remaining <= 0 && W(e));
}
function Ne(e, t, n) {
	let r = e.pending, i = e.market.findIndex((e) => e?.card === n.card), a = e.market[i];
	if (r.kind === "workshop") {
		be(e, t, t.role === "rudolf" ? 1 : 2, 2);
		let r = Math.floor(i / 4) * 4;
		for (let i = 0; i < (n.n ?? 0); i++) e.market[r + i].silver++, t.stock.silver--;
	}
	t.stock.silver += a.silver, t.apprentices.push(a.card), z(t, M[a.card].virtue);
	let o = Math.floor(i / 4) * 4 + 3;
	for (let t = i; t < o; t++) e.market[t] = e.market[t + 1];
	let s = e.apprentices.shift();
	e.market[o] = s === void 0 ? null : {
		card: s,
		silver: 0
	}, W(e);
}
function Pe(e, t) {
	for (let n of e.players) t.workers += n.captives[t.rid] ?? 0, n.captives[t.rid] = 0;
}
function Fe(e, t = e.prison) {
	let n = Math.min(t, e.prison);
	e.prison -= n, e.workers += n;
}
function Ie(e, t, n) {
	let r = e.pending, i = n.location, a = n.target, o = F(e, i, a);
	if (r.source === "town") {
		let n = !r.used?.length, i = n ? 0 : Math.min(1, r.discount ?? 0);
		be(e, t, n ? 0 : 1 - i, +!!n), i && (r.discount = (r.discount ?? 0) - i);
	}
	e.locations[i][a] = 0, a === t.rid ? t.workers += o : t.captives[a] = (t.captives[a] ?? 0) + o, r.used ??= [], r.used.push(`${i}/${a}`), Me(e);
}
function Le(e, t, n) {
	let r = A[n].end, i = e.players.every((e) => e.rid === t.rid || t.cathedral > e.cathedral);
	if (r === "basicVirtue" && z(t, Math.floor((t.stock.wood + t.stock.stone + t.stock.clay) / 4)), r === "paidVirtue" && z(t, Math.floor(t.paid / 2)), r === "goldVirtue" || r === "marbleVirtue") {
		let e = t.role === "therese" ? t.stock.gold + t.stock.marble : t.stock[r === "goldVirtue" ? "gold" : "marble"];
		z(t, Math.floor(e / 2));
	}
	r === "cathedralVirtue" && i && z(t, 2), r === "dungeon" && z(t, -2);
}
function Re(e, t) {
	let n = t.built.reduce((e, t) => e + A[t].vp, 0);
	for (let r of t.built) {
		let i = A[r].end;
		if ([
			"carpentry",
			"tiling",
			"masonry"
		].includes(i) && (n += t.apprentices.filter((e) => M[e].skill.some((e) => e === i)).length), i.startsWith("most")) {
			let r = i.slice(4).toLowerCase();
			e.players.every((e) => e.rid === t.rid || t.stock[r] > e.stock[r]) && (n += 2);
		}
		i === "cathedralPoints" && e.players.every((e) => e.rid === t.rid || t.cathedral > e.cathedral) && (n += 2), i === "buildings" && (n += t.built.length), i === "virtuePoints" && (n += Math.floor(t.virtue / 4)), i === "captives" && (n += Math.floor(Object.values(t.captives).reduce((e, t) => e + t, 0) / 3)), i === "paidPoints" && (n += t.paid), i === "noDebt" && !t.debt && (n += 2);
	}
	t.rid === e.automa && (n = t.guild * (t.role === "helena" ? 3 : 1));
	let r = 2 + t.built.filter((e) => A[e].end === "debtExtra").length - t.built.filter((e) => A[e].end === "debtDiscount").length, i = {
		buildings: n,
		cathedral: ne[t.cathedral],
		virtue: te[t.virtue],
		debts: -t.debt * r,
		resources: t.stock.gold + t.stock.marble,
		silver: Math.floor(t.stock.silver / 10),
		prison: -Math.floor(t.prison / 2)
	};
	return {
		...i,
		total: Object.values(i).reduce((e, t) => e + t, 0)
	};
}
function ze(e, t, n) {
	if (R(t, Object.fromEntries(S.map((e) => [e, -n.cost[e]]))), n.kind === "cathedral") n.card !== void 0 && (t.hand.splice(t.hand.indexOf(n.card), 1), e.buildings.push(n.card)), t.cathedral++, W(e), H(e, {
		kind: "reward",
		rid: t.rid
	}), Se(e, t, "cathedral");
	else {
		let r = n.card;
		t.hand.splice(t.hand.indexOf(r), 1), t.built.push(r), W(e), H(e, {
			kind: "virtue",
			rid: t.rid,
			n: A[r].virtue
		}, {
			kind: "buildingEffect",
			rid: t.rid,
			card: r
		});
	}
}
function Be(e, t, n) {
	t.workers--, e.locations[n][t.rid] = F(e, n, t.rid) + 1;
	let r = F(e, n, t.rid);
	if (e.effects.push({
		kind: "turnEnd",
		rid: t.rid
	}), e.phase = "resolve", n === "forest" || n === "quarry" || n === "silversmith") {
		let i = n === "forest" ? "wood" : n === "quarry" ? "stone" : "silver";
		xe(e, t.rid, "gain", void 0, { [i]: r + +(n === "silversmith") }), Se(e, t, n);
	} else if (n === "mines" || n === "workshop" || n === "storehouse" || n === "town" || n === "guard" || n === "guild") {
		if (e.pending = {
			kind: {
				mines: "mines",
				workshop: "workshop",
				storehouse: "store",
				town: "capture",
				guard: "guard",
				guild: "guild"
			}[n],
			rid: t.rid,
			remaining: r,
			power: r,
			source: n,
			used: [],
			discount: t.apprentices.filter((e) => M[e].trigger === "captureDiscount").length
		}, e.phase = "choice", n === "guild") {
			e.guild.push(t.rid), t.guild++, e.guild.length === I(e) * 4 && (e.finalTurns = e.players.length + 1);
			let n = e.guild.length;
			(n === I(e) * 2 + 1 || n === I(e) * 3 + 1) && (e.resetDue = !0);
		}
	} else if (n === "tax") xe(e, t.rid, "gain", void 0, { silver: e.tax }), e.tax = 0, H(e, {
		kind: "virtue",
		rid: t.rid,
		n: -Math.max(0, 2 - t.apprentices.filter((e) => M[e].trigger === "taxDiscount").length)
	}), Se(e, t, "tax");
	else {
		let r = [
			"small",
			"middle",
			"large"
		].indexOf(n);
		t.stock.silver -= Math.max(0, r + 1 - t.apprentices.filter((e) => M[e].trigger === "marketDiscount").length);
		let i = [];
		t.apprentices.some((e) => M[e].trigger === "marketVirtue") || i.push({
			kind: "virtue",
			rid: t.rid,
			n: -1
		}), t.role === "caroline" && i.push({
			kind: "draw",
			rid: t.rid,
			n: 1
		});
		for (let e of t.apprentices) M[e].trigger === "market" && i.push({
			kind: "gain",
			rid: t.rid,
			gain: C(M[e].gain)
		});
		r === 1 ? i.push({
			kind: "openMiddle",
			rid: t.rid
		}) : i.push({
			kind: "gain",
			rid: t.rid,
			gain: r === 0 ? ae[e.smallPile[0]] : e.largePile.length ? oe[e.largePile[0]] : C({
				marble: 2,
				stone: 1,
				wood: 1
			})
		}), H(e, ...i), [
			"small",
			"middle",
			"large"
		].every((t) => Object.values(e.locations[t]).some((e) => e > 0)) && (e.resetDue = !0);
	}
}
function Ve(e, t, n) {
	let r = n.id.split(":");
	if (n.kind === "draft") {
		e.draftPicks[t.rid] = n.card;
		let r = e.players.filter((t) => t.rid !== e.automa);
		if (r.every((t) => e.draftPicks[t.rid] !== void 0)) {
			let t = r.map((t) => {
				let n = e.draftPicks[t.rid];
				return t.hand.push(n), t.pool.filter((e) => e !== n);
			});
			for (let e = 0; e < r.length; e++) r[(e + 1) % r.length].pool = t[e];
			if (e.draftPicks = {}, e.draftRound++, e.draftRound === 4) {
				for (let t of r) e.buildings.push(...t.pool), t.pool = [], ["ada", "therese"].includes(t.role) && V(e, t, 1);
				e.phase = "turn";
			}
		}
		return;
	}
	if (n.kind === "drop") {
		t.apprentices.splice(t.apprentices.indexOf(n.card), 1), e.apprentices.push(n.card);
		return;
	}
	if (n.kind === "place") {
		Be(e, t, n.location);
		return;
	}
	if (n.kind === "recover") {
		e.locations[n.location][t.rid]--, t.workers++, e.phase = "resolve", e.effects.push({
			kind: "turnEnd",
			rid: t.rid
		});
		return;
	}
	if (n.kind === "build" || n.kind === "cathedral") {
		ze(e, t, n);
		return;
	}
	if (n.kind === "hire") {
		Ne(e, t, n);
		return;
	}
	if (n.kind === "capture") {
		Ie(e, t, n);
		return;
	}
	if (n.kind === "finish") {
		W(e);
		return;
	}
	if (n.kind === "plans") {
		V(e, t, n.n), W(e);
		return;
	}
	if (n.kind === "marketPlans") {
		let n = e.buildings.splice(0, 5);
		e.pending = {
			kind: "pick",
			rid: t.rid,
			remaining: 1,
			pool: n
		};
		return;
	}
	if (n.kind === "pick") {
		t.hand.push(n.card), e.buildings.push(...e.pending.pool.filter((e) => e !== n.card)), W(e);
		return;
	}
	if (n.kind === "discard") {
		t.hand.splice(t.hand.indexOf(n.card), 1), e.buildings.push(n.card), t.hand.length <= 6 && W(e);
		return;
	}
	if (n.kind === "trade" || n.kind === "tradeVirtue") {
		for (let e of S) t.stock[e] -= n.cost[e];
		R(t, n.gain ?? {}), n.kind === "tradeVirtue" && z(t, 1), Me(e);
		return;
	}
	if (n.kind === "gather") {
		R(t, n.gain);
		let r = e.pending?.kind === "mines";
		W(e), r && Se(e, t, "mines");
		return;
	}
	if (n.kind === "library") {
		t.hand.splice(t.hand.indexOf(n.card), 1), e.buildings.push(n.card), R(t, { gold: 2 }), W(e);
		return;
	}
	if (n.kind === "ransomFree") {
		Pe(e, t), W(e);
		return;
	}
	if (n.kind === "resetSkill") {
		let r = M[n.card];
		r.benefit === "release2" && n.n !== 0 ? Fe(t, 2) : t.prison || (R(t, r.gain), r.benefit === "virtue2" && z(t, 2)), e.pending.pool = e.pending.pool.filter((e) => e !== n.card), e.pending.pool.length || W(e);
		return;
	}
	if (n.kind === "finalEffect") {
		Le(e, t, n.card), e.pending.pool = e.pending.pool.filter((e) => e !== n.card), e.pending.pool.length || W(e);
		return;
	}
	if (r[0] === "guard") {
		if (r[1] === "sell") {
			for (let [n, r] of Object.entries(t.captives)) N(e, n).prison += r, t.stock.silver += r;
			t.captives = {};
		}
		r[1] === "release" && Fe(t), r[1] === "ransom" && (be(e, t, 3, 2), Pe(e, t)), r[1] === "debt" && (t.debt++, z(t, -1), Pe(e, t)), r[1] === "pay" && (be(e, t, 3, 3), t.debt--, t.paid++, z(t, 1), Se(e, t, "paid")), Me(e);
	}
}
function He(e) {
	let t = N(e, e.automa);
	if (e.effects.push({
		kind: "turnEnd",
		rid: t.rid
	}), !t.workers) {
		for (let n of T) t.workers += F(e, n, t.rid), e.locations[n][t.rid] = 0;
		Fe(t), Pe(e, t), e.schemes = B(e, [...e.schemes, ...e.schemeDiscard]), e.schemeDiscard = [], e.last = {
			kind: "automaRecover",
			rid: t.rid
		};
		return;
	}
	e.schemes.length || (e.schemes = B(e, e.schemeDiscard), e.schemeDiscard = []);
	let n = e.schemes.shift();
	e.schemeDiscard.push(n), e.scheme = n;
	let r = "guild";
	[
		0,
		5,
		11
	].includes(n) && (r = "workshop"), [1, 12].includes(n) && (r = "tax"), [3, 18].includes(n) && (r = "small"), [
		4,
		6,
		10,
		16
	].includes(n) && (r = "storehouse"), [
		13,
		14,
		17,
		19
	].includes(n) && (r = "town"), [15, 20].includes(n) && (r = "guard"), t.workers--, r === "small" && (r = [
		"large",
		"middle",
		"small"
	].find((t) => !Object.values(e.locations[t]).some((e) => e > 0))), e.locations[r][t.rid] = F(e, r, t.rid) + 1;
	let i = F(e, r, t.rid);
	if (r === "workshop") {
		e.tax += 2;
		for (let t of n === 0 ? [0, 4] : n === 5 ? [0] : [4]) {
			let n = e.market[t];
			n && e.apprentices.push(n.card);
			for (let n = t; n < t + 3; n++) e.market[n] = e.market[n + 1];
			let r = e.apprentices.shift();
			e.market[t + 3] = r === void 0 ? null : {
				card: r,
				silver: 0
			};
		}
		for (let t = 0; t < i; t++) {
			let t = e.future.shift();
			t !== void 0 && e.schemeDiscard.push(t);
		}
	}
	if (r === "tax" && (e.tax = 0, z(t, 2), t.stock.marble++), r === "storehouse" && (z(t, i), n === 6 && t.stock.marble++), r === "guild") {
		e.guild.push(t.rid), t.guild++;
		let n = t.cathedral + 1;
		n <= 5 && e.players.filter((e) => e.cathedral === n).length < re[n] ? (t.cathedral++, e.rewards.shift(), z(t, 1)) : t.stock.marble++, e.guild.length === I(e) * 4 && (e.finalTurns = e.players.length + 1), (e.guild.length === I(e) * 2 + 1 || e.guild.length === I(e) * 3 + 1) && (e.resetDue = !0);
	}
	if (r === "town") {
		e.tax++;
		let r = [
			"mines",
			"storehouse",
			"town",
			"forest",
			"quarry",
			"silversmith",
			"guard",
			"workshop"
		].map((n) => ({
			l: n,
			n: e.players.filter((e) => e.rid !== t.rid).reduce((t, r) => Math.max(t, F(e, n, r.rid)), 0)
		})).sort((e, t) => t.n - e.n);
		for (let { l: i, n: a } of r.slice(0, n === 17 ? 2 : 1)) if (a > 0) {
			let n = e.players.filter((e) => e.rid !== t.rid).sort((t, n) => F(e, i, n.rid) - F(e, i, t.rid))[0];
			t.captives[n.rid] = (t.captives[n.rid] ?? 0) + F(e, i, n.rid), e.locations[i][n.rid] = 0;
		}
	}
	if (r === "guard") {
		let n = i;
		if (t.prison && n > 0 && (Fe(t), n--), Object.values(t.captives).some((e) => e > 0) && n > 0) {
			for (let [n, r] of Object.entries(t.captives)) N(e, n).prison += r;
			t.captives = {}, t.stock.marble++, n--;
		}
		for (e.players.some((e) => (e.captives[t.rid] ?? 0) > 0) && n > 0 && (e.tax += 2, Pe(e, t), n--); n > 0 && t.debt > 0;) e.tax += 3, t.debt--, t.paid++, z(t, 1), n--;
	}
	if ([
		"small",
		"middle",
		"large"
	].includes(r)) {
		if (r === "large" && (z(t, -1), t.stock.marble += 2), r === "middle") {
			z(t, 1);
			let r = e.future.shift();
			r !== void 0 && (n === 3 ? e.schemes : e.schemeDiscard).push(r);
		}
		r === "small" && (z(t, -1), t.stock.marble++), [
			"small",
			"middle",
			"large"
		].every((t) => Object.values(e.locations[t]).some((e) => e > 0)) && (e.resetDue = !0);
	}
	e.last = {
		kind: "automa",
		rid: t.rid,
		location: r,
		card: n
	};
}
function Ue(e) {
	let t = e.effects.shift();
	if (!t) return [];
	let n = N(e, t.rid);
	switch (e.last = {
		kind: t.kind,
		rid: t.rid,
		...t.card === void 0 ? {} : { card: t.card },
		...t.n === void 0 ? {} : { n: t.n }
	}, t.kind) {
		case "gain":
			R(n, t.gain);
			break;
		case "virtue":
			z(n, t.n ?? 0);
			break;
		case "draw":
			V(e, n, t.n ?? 1);
			break;
		case "openMiddle":
			e.pending = {
				kind: "middle",
				rid: n.rid,
				remaining: 1,
				source: "market"
			};
			break;
		case "reward": {
			let t = e.rewards.shift();
			z(n, t === 3 ? 2 : 1), t === 0 && V(e, n, 1), t === 1 && R(n, { silver: 3 }), t === 2 && R(n, { gold: 1 }), t === 4 && R(n, { stone: 2 }), t === 5 && R(n, { wood: 2 });
			break;
		}
		case "buildingEffect": {
			let r = A[t.card].effect;
			if (r === "destroy" && (n.debt = Math.max(0, n.debt - 1)), r === "hire" && (e.pending = {
				kind: "hire",
				rid: n.rid,
				remaining: 1,
				source: "tavern"
			}), r === "releasePrison" && Fe(n), r === "palace" && R(n, { gold: Math.floor(n.virtue / 4) }), r === "debt" && n.debt++, r === "monument") for (let t of e.players) z(t, 1);
			if (r === "watchtower") for (let t of e.players) t.prison >= 3 && z(t, -1);
			r === "draw2" && V(e, n, 2), [
				"wood4",
				"stone4",
				"clay4",
				"silver4",
				"marble2"
			].includes(r) && R(n, { [r.replace(/\d/g, "")]: Number(r.at(-1)) }), [
				"treasury",
				"claypit",
				"library",
				"barracks"
			].includes(r) && (e.pending = {
				kind: r,
				rid: n.rid,
				remaining: 1,
				source: "building"
			}), (r === "capture1" || r === "capture2") && (e.pending = {
				kind: "capture",
				rid: n.rid,
				remaining: r === "capture1" ? 1 : 2,
				source: r === "capture2" ? "fortress" : "building",
				used: []
			});
			break;
		}
		case "turnEnd":
			if (n.hand.length > 6) {
				e.pending = {
					kind: "discard",
					rid: n.rid,
					remaining: n.hand.length - 6
				}, H(e, t);
				break;
			}
			e.resetDue ? (e.resetDue = !1, H(e, {
				kind: "resetStart",
				rid: n.rid
			}, {
				kind: "resetFlip",
				rid: n.rid
			}, ...e.players.map((e) => ({
				kind: "resetSkills",
				rid: e.rid
			})), ...e.players.map((e) => ({
				kind: "resetVirtue",
				rid: e.rid
			})), {
				kind: "resetDebt",
				rid: n.rid
			}, {
				kind: "advance",
				rid: n.rid
			})) : H(e, {
				kind: "advance",
				rid: n.rid
			});
			break;
		case "resetStart":
			e.reset++;
			for (let t of [
				"small",
				"middle",
				"large"
			]) for (let n of e.players) n.prison += F(e, t, n.rid), e.locations[t][n.rid] = 0;
			break;
		case "resetFlip":
			if (e.smallPile.length || (e.smallPile = B(e, e.largePile), e.largePile = []), e.largePile.unshift(e.smallPile.shift()), !e.smallPile.length) {
				let t = e.largePile.shift();
				e.smallPile = B(e, e.largePile), e.largePile = [t];
			}
			break;
		case "resetSkills": {
			let t = n.apprentices.filter((e) => M[e].trigger === "reset");
			t.length && (e.pending = {
				kind: "resetSkills",
				rid: n.rid,
				remaining: t.length,
				pool: t
			});
			break;
		}
		case "resetVirtue":
			n.prison >= 3 && z(n, -1);
			break;
		case "resetDebt": {
			let t = Math.max(...e.players.map((e) => e.prison));
			if (t > 0) for (let n of e.players) n.prison === t && n.debt++;
			break;
		}
		case "advance":
			if (e.finalTurns !== null && (e.finalTurns--, e.finalTurns === 0)) {
				e.phase = "resolve", H(e, ...e.players.map((e) => ({
					kind: "finalEffects",
					rid: e.rid
				})), {
					kind: "score",
					rid: n.rid
				});
				break;
			}
			e.turn++, e.turnIndex = (e.turnIndex + 1) % e.order.length, e.phase = "turn";
			break;
		case "finalEffects": {
			let t = n.built.filter((e) => [
				"basicVirtue",
				"paidVirtue",
				"goldVirtue",
				"marbleVirtue",
				"cathedralVirtue",
				"dungeon"
			].includes(A[e].end));
			t.length && (e.pending = {
				kind: "finalEffects",
				rid: n.rid,
				remaining: t.length,
				pool: t
			});
			break;
		}
		case "score": e.scores = Object.fromEntries(e.players.map((t) => [t.rid, Re(e, t)])), e.phase = "done";
	}
	return e.pending && (e.phase = "choice"), [{
		kind: "architectsEvent",
		rid: t.rid,
		data: {
			...t,
			last: e.last
		}
	}];
}
function We(e, t, n) {
	if (t.type === "tick") {
		if (e.pending || e.phase === "done" || e.phase === "draft" || e.phase === "turn" && P(e) !== e.automa) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		if (t.phase === "turn" && P(t) === t.automa) return t.phase = "resolve", He(t), {
			state: t,
			fx: [{
				kind: "architectsEvent",
				rid: t.automa,
				data: {
					kind: "automa",
					last: t.last,
					...Ge(e, t)
				}
			}]
		};
		let n = Ue(t);
		for (let r of n) r.data = {
			...typeof r.data == "object" && !Array.isArray(r.data) ? r.data : {},
			...Ge(e, t)
		};
		return {
			state: t,
			fx: n
		};
	}
	let r = Ae(e, n.by).find((e) => e.id === t.id);
	if (!r) return { code: "games.architectsofthewestkingdom.errAction" };
	let i = structuredClone(e);
	Ve(i, N(i, n.by), r);
	let a = [
		"draft",
		"pick",
		"discard",
		"library",
		"cathedral"
	].includes(r.kind);
	i.last = {
		kind: r.kind,
		rid: n.by,
		...r.location ? { location: r.location } : {},
		...a || r.card === void 0 ? {} : { card: r.card },
		...r.n === void 0 ? {} : { n: r.n }
	};
	let o = {
		kind: "architectsEvent",
		rid: n.by,
		data: {
			...a ? {
				kind: r.kind,
				n: 1
			} : { ...r },
			...Ge(e, i)
		}
	};
	return a && r.card !== void 0 && (o.for = [n.by], o.secret = { card: r.card }), {
		state: i,
		fx: [o]
	};
}
function Ge(e, t) {
	let n = [], r = [], i = (e, t) => {
		let n = N(e, t);
		return Object.fromEntries([
			[`supply:${t}`, n.workers],
			[`prison:${t}`, n.prison],
			...w.map((n) => [`location:${n}`, F(e, n, t)]),
			...e.players.map((e) => [`captives:${e.rid}`, e.captives[t] ?? 0])
		]);
	};
	for (let a of e.players) {
		let o = i(e, a.rid), s = i(t, a.rid), c = N(t, a.rid), l = Object.keys(o).filter((e) => o[e] > s[e]).map((e) => ({
			key: e,
			n: o[e] - s[e]
		})), u = Object.keys(o).filter((e) => s[e] > o[e]).map((e) => ({
			key: e,
			n: s[e] - o[e]
		}));
		for (let e of l) for (let t of u) {
			let r = Math.min(e.n, t.n);
			r && (n.push({
				rid: a.rid,
				from: e.key,
				to: t.key,
				n: r
			}), e.n -= r, t.n -= r);
		}
		for (let e of [
			...S,
			"virtue",
			"debt"
		]) {
			let t = e === "virtue" || e === "debt" ? c[e] - a[e] : c.stock[e] - a.stock[e];
			t && r.push({
				rid: a.rid,
				resource: e,
				n: t
			});
		}
	}
	return {
		moves: n,
		changes: r,
		marketMoves: t.market.flatMap((t, n) => {
			if (!t) return [];
			let r = e.market.findIndex((e) => e?.card === t.card);
			return r === n ? [] : [{
				card: t.card,
				from: r < 0 ? "apprenticeDeck" : `market:${r}`,
				to: `market:${n}`
			}];
		}),
		draws: t.players.flatMap((t) => {
			let n = t.hand.length - N(e, t.rid).hand.length;
			return n > 0 ? [{
				rid: t.rid,
				n
			}] : [];
		})
	};
}
function Ke(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return {
		public: {
			players: e.players.map(({ hand: e, pool: t, ...n }) => ({
				...n,
				handCount: e.length
			})),
			active: e.pending?.rid ?? P(e),
			phase: e.phase,
			turn: e.turn,
			draftRound: e.draftRound,
			draftReady: Object.keys(e.draftPicks),
			locations: e.locations,
			market: e.market,
			guild: e.guild,
			guildLimit: I(e) * 4,
			tax: e.tax,
			small: ae[e.smallPile[0]],
			large: e.largePile.length ? oe[e.largePile[0]] : C({
				marble: 2,
				wood: 1,
				stone: 1
			}),
			deckCount: e.buildings.length,
			apprenticeCount: e.apprentices.length,
			rewardCount: e.rewards.length,
			finalTurns: e.finalTurns,
			pending: e.pending?.kind ?? "",
			remaining: e.pending?.remaining ?? 0,
			last: e.last,
			reset: e.reset,
			scores: e.scores,
			automa: e.automa,
			scheme: e.scheme
		},
		private: {
			hand: n?.hand ?? [],
			pool: e.pending?.rid === t && e.pending.kind === "pick" ? e.pending.pool ?? [] : n?.pool ?? [],
			choices: Ae(e, t)
		}
	};
}
function qe(e) {
	if (!e.scores) return { phase: e.phase };
	let t = [...e.order].sort((t, n) => e.scores[n].total - e.scores[t].total || N(e, n).virtue - N(e, t).virtue || N(e, n).stock.silver - N(e, t).stock.silver), n = N(e, t[0]);
	return {
		phase: "done",
		ranking: t,
		winner: t.filter((t) => e.scores[t].total === e.scores[n.rid].total && N(e, t).virtue === n.virtue && N(e, t).stock.silver === n.stock.silver),
		scores: Object.fromEntries(e.order.map((t) => [t, e.scores[t].total]))
	};
}
var Je = {
	meta: ue,
	saveCompatibility: { version: "1" },
	schemas: {
		action: fe,
		publicView: ge,
		privateView: _e,
		config: de
	},
	setup: je,
	reduce: We,
	viewFor: Ke,
	status: qe,
	nextTickIn: (e) => !e.pending && (e.phase === "resolve" || e.phase === "turn" && P(e) === e.automa) ? 620 : null
}, Ye = {
	build: 10,
	demand: 2.2,
	engine: 1.7,
	labour: 1.1,
	virtue: .65
}, Xe = {
	wood: .8,
	stone: .85,
	clay: .6,
	gold: 2.6,
	marble: 2.8,
	silver: .65
}, G = (e) => e ? S.reduce((t, n) => t + e[n] * Xe[n], 0) : 0;
function Ze(e, t) {
	return A[t].skills.filter((t) => !e.apprentices.some((e) => M[e].skill.includes(t)));
}
function Qe(e, t) {
	return [...t].sort((t, n) => {
		let r = (t) => S.reduce((n, r) => n + Math.max(0, A[t].cost[r] - e.stock[r]) * Xe[r], 0) + Ze(e, t).length * 3 - A[t].vp * .28;
		return r(t) - r(n);
	})[0];
}
function $e(e, t, n, r, i = Ye) {
	let a = t.players.find((e) => e.rid === r), o = Qe(a, n.hand), s = o === void 0 ? void 0 : A[o], c = (e) => s ? Math.max(0, s.cost[e] - a.stock[e]) : e === "silver" ? Math.max(0, 5 - a.stock.silver) : 0, l = (e, t) => Math.min(t, c(e)) * Xe[e] * i.demand + Math.max(0, t - c(e)) * Xe[e] * (a.stock[e] < 5 ? .5 : .08);
	if (e.kind === "draft" || e.kind === "pick") {
		let t = A[e.card];
		return t.vp - G(t.cost) * .5 - t.skills.length * 1.2;
	}
	if (e.kind === "build") return i.build + A[e.card].vp - G(e.cost) * .3;
	if (e.kind === "cathedral") return i.build + 2 + (e.n ?? 0) * 1.3 - G(e.cost) * .2;
	if (e.kind === "hire") {
		let t = M[e.card], n = s ? Ze(a, s.id) : [];
		return 1 + t.skill.filter((e) => !a.apprentices.some((t) => M[t].skill.includes(e))).length * i.engine + n.filter((e) => t.skill.includes(e)).length * 3 + +(a.apprentices.length < 3) + G(e.gain) - G(e.cost) * .7 + (t.trigger === "trade" && t.gain.marble ? 2 : 0);
	}
	if (e.kind === "place") {
		let o = e.location, u = (t.locations[o][r] ?? 0) + 1;
		if (o === "guild") return i.build + 8;
		if (o === "forest" || o === "quarry" || o === "silversmith") {
			let e = o === "forest" ? "wood" : o === "quarry" ? "stone" : "silver";
			return l(e, u + +(e === "silver")) + (a.stock.silver < 4 && e === "silver" ? 3 : 0);
		}
		if (o === "mines") return Math.max(l("clay", u + 1), l("gold", Math.floor(u / 2))) + (c("gold") > 0 && u === 1 ? 1.4 : 0);
		if (o === "tax") return t.tax * .6 - Math.min(2, a.virtue) * i.virtue + (t.tax >= 7 ? 2 : 0);
		if (o === "workshop") return n.hand.length ? s && Ze(a, s.id).length && a.stock.silver >= 3 ? 6.2 : a.apprentices.length < 3 && a.stock.silver >= 4 ? 3.8 : .1 : 8;
		if (o === "storehouse") return c("marble") && a.stock.wood + a.stock.stone >= 3 ? 6.5 : a.virtue <= 4 && a.stock.wood + a.stock.clay + a.stock.stone >= 2 ? 4 : .05;
		if (o === "guard") return a.prison * i.labour + Object.values(a.captives).reduce((e, t) => e + t, 0) * .9 + (a.debt && a.stock.silver >= 6 ? 2.8 : 0) + (a.workers < 4 && a.prison > 0 ? 4 : 0);
		if (o === "town") {
			let e = Math.max(...Object.values(t.locations).map((e) => e[r] ?? 0)), n = Math.max(0, ...Object.entries(t.locations).filter(([e]) => ![
				"guild",
				"small",
				"middle",
				"large"
			].includes(e)).flatMap(([, e]) => Object.entries(e).filter(([e]) => e !== r).map(([, e]) => e)));
			return Math.max(a.workers < 5 ? e * i.labour : 0, n * .45) + (a.workers < 2 ? 4 : 0);
		}
		if (o === "small" || o === "large") {
			let e = o === "small" ? t.small : t.large;
			return S.reduce((t, n) => t + l(n, e[n]), 0) - (o === "small" ? 1 : 3) * .65 - i.virtue;
		}
		if (o === "middle") return a.apprentices.length < 3 ? 3.6 : n.hand.length ? .1 : 5;
	}
	if (e.kind === "gather") return e.gain ? S.reduce((t, n) => t + l(n, e.gain[n]), 0) : 0;
	if (e.kind === "trade" || e.kind === "tradeVirtue") return (e.kind === "tradeVirtue" ? a.virtue < 7 ? 3 : +(a.virtue < 14) : S.reduce((t, n) => t + l(n, e.gain?.[n] ?? 0), 0)) - G(e.cost) * .5;
	if (e.kind === "capture") return (e.target === r ? a.workers < 5 ? e.n * i.labour : e.n * .15 : e.n * .6) - G(e.cost);
	if (e.kind === "sell") return e.n * .75 + 1;
	if (e.kind === "release") return e.n * i.labour + 1;
	if (e.kind === "payDebt") return 2.8 + i.virtue - G(e.cost) * .45;
	if (e.kind === "ransom") return e.n * i.labour - G(e.cost) * .6;
	if (e.kind === "ransomDebt") return e.n * i.labour - 3;
	if (e.kind === "ransomFree") return 5;
	if (e.kind === "plans") return n.hand.length < 3 ? 5 : .5;
	if (e.kind === "marketPlans") return n.hand.length < 3 ? 3 : 0;
	if (e.kind === "discard" || e.kind === "library") {
		let t = A[e.card];
		return -t.vp + G(t.cost) * .5 + Ze(a, t.id).length * 2;
	}
	return e.kind === "resetSkill" ? e.n === 0 ? -2 : M[e.card].benefit === "release2" ? 10 : 1 : e.kind === "finalEffect" ? A[e.card].end === "dungeon" ? a.virtue >= 14 ? 5 : -5 : 1 : e.kind === "recover" ? t.locations[e.location][r] ?? 0 : e.kind === "finish" ? -.1 : e.kind === "drop" ? -100 : 0;
}
function et(e = Ye) {
	return (t, n) => {
		let r = t.private;
		if (!r?.choices.length) return null;
		let i = r.choices.map((i) => ({
			c: i,
			score: $e(i, t.public, r, n.rid, e)
		})).sort((e, t) => t.score - e.score), a = i[0].c;
		if (n.difficulty === "weak") {
			let e = i.filter((e) => e.c.kind !== "drop" && e.score >= i[0].score - 3).slice(0, 5);
			a = e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length].c;
		}
		return { action: {
			type: "choose",
			id: a.id
		} };
	};
}
var tt = et(), nt = (e, t, n) => {
	if (e.type !== "choose") return "";
	let r = t.private?.choices.find((t) => t.id === e.id);
	return r ? r.location ? n("games.architectsofthewestkingdom.hintLocation", { name: n(rt[r.location]) }) : r.card === void 0 ? n("games.architectsofthewestkingdom.hintAction") : n("games.architectsofthewestkingdom.hintCard", { name: n([
		"hire",
		"drop",
		"resetSkill"
	].includes(r.kind) ? M[r.card].name : A[r.card].name) }) : "";
}, rt = {
	forest: "games.architectsofthewestkingdom.forest",
	quarry: "games.architectsofthewestkingdom.quarry",
	mines: "games.architectsofthewestkingdom.mines",
	silversmith: "games.architectsofthewestkingdom.silversmith",
	storehouse: "games.architectsofthewestkingdom.storehouse",
	workshop: "games.architectsofthewestkingdom.workshop",
	town: "games.architectsofthewestkingdom.town",
	tax: "games.architectsofthewestkingdom.tax",
	guard: "games.architectsofthewestkingdom.guard",
	guild: "games.architectsofthewestkingdom.guild",
	small: "games.architectsofthewestkingdom.small",
	middle: "games.architectsofthewestkingdom.middle",
	large: "games.architectsofthewestkingdom.large"
}, it = /* @__PURE__ */ "games.architectsofthewestkingdom.b0Text,games.architectsofthewestkingdom.b1Text,games.architectsofthewestkingdom.b2Text,games.architectsofthewestkingdom.b3Text,games.architectsofthewestkingdom.b4Text,games.architectsofthewestkingdom.b5Text,games.architectsofthewestkingdom.b6Text,games.architectsofthewestkingdom.b7Text,games.architectsofthewestkingdom.b8Text,games.architectsofthewestkingdom.b9Text,games.architectsofthewestkingdom.b10Text,games.architectsofthewestkingdom.b11Text,games.architectsofthewestkingdom.b12Text,games.architectsofthewestkingdom.b13Text,games.architectsofthewestkingdom.b14Text,games.architectsofthewestkingdom.b15Text,games.architectsofthewestkingdom.b16Text,games.architectsofthewestkingdom.b17Text,games.architectsofthewestkingdom.b18Text,games.architectsofthewestkingdom.b19Text,games.architectsofthewestkingdom.b20Text,games.architectsofthewestkingdom.b21Text,games.architectsofthewestkingdom.b22Text,games.architectsofthewestkingdom.b23Text,games.architectsofthewestkingdom.b24Text,games.architectsofthewestkingdom.b25Text,games.architectsofthewestkingdom.b26Text,games.architectsofthewestkingdom.b27Text,games.architectsofthewestkingdom.b28Text,games.architectsofthewestkingdom.b29Text,games.architectsofthewestkingdom.b30Text,games.architectsofthewestkingdom.b31Text,games.architectsofthewestkingdom.b32Text,games.architectsofthewestkingdom.b33Text,games.architectsofthewestkingdom.b34Text,games.architectsofthewestkingdom.b35Text,games.architectsofthewestkingdom.b36Text,games.architectsofthewestkingdom.b37Text,games.architectsofthewestkingdom.b38Text,games.architectsofthewestkingdom.b39Text".split(","), at = {
	wood: "games.architectsofthewestkingdom.wood",
	stone: "games.architectsofthewestkingdom.stone",
	clay: "games.architectsofthewestkingdom.clay",
	gold: "games.architectsofthewestkingdom.gold",
	marble: "games.architectsofthewestkingdom.marble",
	silver: "games.architectsofthewestkingdom.silver"
}, ot = {
	carpentry: "games.architectsofthewestkingdom.carpentry",
	tiling: "games.architectsofthewestkingdom.tiling",
	masonry: "games.architectsofthewestkingdom.masonry"
}, st = {
	standard: "games.architectsofthewestkingdom.standard",
	ada: "games.architectsofthewestkingdom.ada",
	frederick: "games.architectsofthewestkingdom.frederick",
	caroline: "games.architectsofthewestkingdom.caroline",
	rudolf: "games.architectsofthewestkingdom.rudolf",
	therese: "games.architectsofthewestkingdom.therese",
	constantine: "games.architectsofthewestkingdom.constantine",
	helena: "games.architectsofthewestkingdom.helena"
}, ct = {
	standard: "games.architectsofthewestkingdom.roleStandard",
	ada: "games.architectsofthewestkingdom.roleAda",
	frederick: "games.architectsofthewestkingdom.roleFrederick",
	caroline: "games.architectsofthewestkingdom.roleCaroline",
	rudolf: "games.architectsofthewestkingdom.roleRudolf",
	therese: "games.architectsofthewestkingdom.roleTherese",
	constantine: "games.architectsofthewestkingdom.roleConstantine",
	helena: "games.architectsofthewestkingdom.roleHelena"
};
function lt(e, t) {
	let n = c(), r = s((e) => e.locale);
	return (i) => {
		let a = e.find((e) => e.rid === i);
		if (a) return p(a, r);
		let o = t.players.find((e) => e.rid === i);
		return o && o.role in st ? n(st[o.role]) : n(f[0].nameKey);
	};
}
function K(e, t) {
	let n = e.find((e) => e.rid === t);
	return f[(n?.colorIndex ?? 7) % f.length].hex;
}
function q({ rid: e, members: t, size: n = 25 }) {
	let r = t.find((t) => t.rid === e);
	return /* @__PURE__ */ h("span", {
		className: "awk-avatar",
		style: {
			background: K(t, e),
			width: n,
			height: n
		},
		children: r ? /* @__PURE__ */ h("img", {
			alt: "",
			src: d[r.avatar % d.length],
			draggable: !1
		}) : /* @__PURE__ */ h(J, {
			name: "worker",
			color: "#f7ebd6"
		})
	});
}
function J({ name: e, color: t, size: r = 22 }) {
	let i = n(), a = {
		wood: /* @__PURE__ */ h("path", {
			fill: `url(#${i})`,
			d: "M7 9 11 7 11 3 20 4 23 8 27 9 26 16 21 20 17 28 7 23 8 17 4 14Z"
		}),
		stone: /* @__PURE__ */ h("path", {
			fill: `url(#${i})`,
			d: "M9 3 23 4 29 13 25 25 14 29 4 21 3 10Z"
		}),
		clay: /* @__PURE__ */ h("path", {
			fill: `url(#${i})`,
			d: "m8 4 16 2 6 11-12 12L3 21 2 11Z"
		}),
		gold: /* @__PURE__ */ h("path", {
			fill: `url(#${i})`,
			d: "m4 8 12-5 13 8-4 14-16 4-6-11Z"
		}),
		marble: /* @__PURE__ */ h("path", {
			fill: `url(#${i})`,
			d: "m5 8 20-4 6 13-17 11L1 20Z"
		}),
		silver: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("circle", {
				fill: "#8c8170",
				cx: "16",
				cy: "16",
				r: "13"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "16",
				r: "9",
				fill: "none",
				stroke: "#b3aa97",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ h("path", {
				d: "m12 9 7 2 2 6-4 6-6-4 2-5Z",
				fill: "#a79d8a",
				stroke: "none"
			})
		] }),
		virtue: /* @__PURE__ */ h("path", {
			fill: `url(#${i})`,
			d: "M5 3h23v25l-12-4-11 4Z"
		}),
		vp: /* @__PURE__ */ h("path", {
			fill: `url(#${i})`,
			d: "M5 3h23v25l-12-4-11 4Z"
		}),
		worker: /* @__PURE__ */ h("path", {
			fill: t ?? "#e8e8dd",
			d: "M16 1 21 3 24 7 23 11 21 13 24 16 23 19 25 22 24 27 16 32 6 25 7 19 6 16 9 12 8 9 11 4Z"
		}),
		debt: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("rect", {
			x: "6",
			y: "2",
			width: "21",
			height: "29",
			rx: "2",
			fill: "#454744"
		}), /* @__PURE__ */ h("path", {
			stroke: "#ddd",
			strokeWidth: "4",
			d: "M16 10v14m-7-7h14"
		})] }),
		cathedral: /* @__PURE__ */ h("path", {
			fill: "#d78c3a",
			d: "M7 30V14l6-4V3l6-3 5 6v8l4 3v13Z"
		}),
		carpentry: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("circle", {
				cx: "15",
				cy: "18",
				r: "10",
				fill: "#e7e7db",
				stroke: "#fff6df"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "15",
				cy: "18",
				r: "7.5",
				fill: "none",
				stroke: "#6a4c30",
				strokeWidth: "1.8"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#724b2b",
				d: "m3 28 3 2L25 8l-3-3Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#d7d7cb",
				d: "m18 7 5-5 5 7 4 2q-1 6-8 6Z"
			})
		] }),
		tiling: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				fill: "#e7e6d9",
				stroke: "#d7b32c",
				strokeWidth: "2",
				d: "M6 5h22v23H6Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#d9b52f",
				d: "m3 30 6-11 10-1-2 9Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#d9b52f",
				d: "m18 18 9-16 4 3-11 14Z"
			})
		] }),
		masonry: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				fill: "#b7bab9",
				d: "m3 25 3 5 24-22-4-5Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#d7d8d4",
				d: "m5 20 14-17 10 5-14 18Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "none",
				stroke: "#7f8483",
				strokeWidth: "1.5",
				d: "m8 20 13-14 4 2-13 14Z"
			})
		] })
	};
	return /* @__PURE__ */ g("svg", {
		className: "awk-icon",
		width: r,
		height: r,
		viewBox: "0 0 33 33",
		"aria-hidden": !0,
		stroke: "#fff6df",
		strokeWidth: "1.5",
		strokeLinejoin: "round",
		children: [/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ g("linearGradient", {
			id: i,
			x1: "0",
			y1: "0",
			x2: "1",
			y2: "1",
			children: [/* @__PURE__ */ h("stop", { stopColor: {
				wood: "#a27a51",
				stone: "#c5c9c7",
				clay: "#d44452",
				gold: "#f7db48",
				marble: "#c5ebf0",
				virtue: "#4e2675",
				vp: "#e8b900"
			}[e] ?? "#eee" }), /* @__PURE__ */ h("stop", {
				offset: "1",
				stopColor: {
					wood: "#674122",
					stone: "#777f80",
					clay: "#a3132d",
					gold: "#d9aa06",
					marble: "#83c2d8",
					virtue: "#80549c",
					vp: "#f5d332"
				}[e] ?? "#bbb"
			})]
		}) }), a[e]]
	});
}
function Y({ values: e, zeros: t = !1 }) {
	let n = c();
	return /* @__PURE__ */ h("span", {
		className: "awk-resources",
		children: S.filter((n) => t || (e[n] ?? 0) > 0).map((t) => /* @__PURE__ */ g("span", {
			className: "awk-resource",
			title: n(at[t]),
			children: [/* @__PURE__ */ h(J, { name: t }), /* @__PURE__ */ h("b", { children: e[t] ?? 0 })]
		}, t))
	});
}
function X() {
	return /* @__PURE__ */ h("svg", {
		className: "awk-march",
		"aria-hidden": !0,
		children: /* @__PURE__ */ h("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "6"
		})
	});
}
function ut({ rid: e, n: t, members: n, name: r, onClick: i, legal: o = !1, anchor: s }) {
	let { ref: c, hidden: l } = a(`workers:${e}:${s ?? r}`);
	return /* @__PURE__ */ g("button", {
		type: "button",
		ref: c,
		className: `awk-worker-group${o ? " awk-legal" : ""}`,
		style: {
			"--awk-player": K(n, e),
			visibility: l ? "hidden" : void 0
		},
		onClick: i,
		title: r,
		"aria-label": `${r}: ${t}`,
		children: [
			/* @__PURE__ */ h(q, {
				rid: e,
				members: n,
				size: 18
			}),
			/* @__PURE__ */ h(J, {
				name: "worker",
				color: K(n, e)
			}),
			/* @__PURE__ */ h("b", { children: t }),
			o && /* @__PURE__ */ h(X, {})
		]
	});
}
function dt({ id: e }) {
	let t = c(), n = M[e];
	return /* @__PURE__ */ g("span", {
		className: "awk-effect-formula",
		children: [
			n.trade && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Y, { values: n.trade }), /* @__PURE__ */ h("span", { children: "→" })] }),
			Object.keys(n.gain).length > 0 && /* @__PURE__ */ h(Y, { values: n.gain }),
			" ",
			n.benefit === "virtue" && /* @__PURE__ */ h(J, { name: "virtue" }),
			n.benefit === "virtue2" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(J, { name: "virtue" }), /* @__PURE__ */ h("b", { children: "2" })] }),
			n.benefit === "draw" && /* @__PURE__ */ h("span", {
				className: "awk-draw-icon",
				title: t("games.architectsofthewestkingdom.drawOne"),
				children: "+"
			}),
			[
				"captureDiscount",
				"taxDiscount",
				"marketDiscount",
				"marketVirtue"
			].includes(n.trigger) && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { children: "−1" }), /* @__PURE__ */ h(J, { name: n.trigger.includes("Virtue") || n.trigger === "taxDiscount" ? "virtue" : "silver" })] }),
			n.benefit === "release2" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h(J, { name: "worker" }),
				/* @__PURE__ */ h("b", { children: "2" }),
				/* @__PURE__ */ h("span", { children: "↗" })
			] })
		]
	});
}
function ft({ id: e }) {
	let t = c(), n = M[e], r = n.trigger === "trade" ? "games.architectsofthewestkingdom.aTrade" : n.trigger === "paid" ? "games.architectsofthewestkingdom.aPaid" : n.trigger === "cathedral" ? "games.architectsofthewestkingdom.aCathedral" : n.trigger === "market" ? "games.architectsofthewestkingdom.aMarket" : n.trigger === "captureDiscount" ? "games.architectsofthewestkingdom.aCaptureDiscount" : n.trigger === "taxDiscount" ? "games.architectsofthewestkingdom.aTaxDiscount" : n.trigger === "marketDiscount" ? "games.architectsofthewestkingdom.aMarketDiscount" : n.trigger === "marketVirtue" ? "games.architectsofthewestkingdom.aMarketVirtue" : n.trigger === "tax" ? "games.architectsofthewestkingdom.aTax" : n.trigger === "reset" ? n.benefit === "release2" ? "games.architectsofthewestkingdom.aRelease2" : "games.architectsofthewestkingdom.aReset" : n.trigger === "" ? "games.architectsofthewestkingdom.aSkills" : "games.architectsofthewestkingdom.aGather", i = {
		forest: "games.architectsofthewestkingdom.forest",
		quarry: "games.architectsofthewestkingdom.quarry",
		mines: "games.architectsofthewestkingdom.mines",
		silversmith: "games.architectsofthewestkingdom.silversmith"
	}, a = n.trigger in i ? t(i[n.trigger]) : "";
	return /* @__PURE__ */ g("p", { children: [
		t(r, { location: a }),
		n.benefit === "draw" && ` ${t("games.architectsofthewestkingdom.drawOne")}`,
		n.virtue !== 0 && ` ${t("games.architectsofthewestkingdom.virtueChange", { n: n.virtue })}`
	] });
}
function Z({ id: e, apprentice: t = !1, legal: n = !1, selected: r = !1, onClick: o, anchor: s, detail: l = !1 }) {
	let u = c(), { ref: d, hidden: f } = a(s ?? null), p = t ? M[e] : A[e], _ = t ? M[e].skill : A[e].skills, v = t ? "a" + M[e].name.split(".").at(-1).slice(1) : "b" + e;
	return /* @__PURE__ */ g("button", {
		ref: d,
		type: "button",
		className: `awk-card${t ? " awk-card-apprentice" : ""}${n ? " awk-legal" : ""}${r ? " awk-selected" : ""}${l ? " awk-card-detail" : ""}`,
		style: { visibility: f ? "hidden" : void 0 },
		onClick: o,
		"aria-label": u(p.name),
		"aria-pressed": r,
		children: [
			/* @__PURE__ */ g("span", {
				className: "awk-card-art",
				children: [
					/* @__PURE__ */ h("img", {
						src: i(`games/architectsofthewestkingdom/live/${v}.webp`),
						draggable: !1,
						alt: ""
					}),
					/* @__PURE__ */ h("span", {
						className: "awk-card-skills",
						children: _.map((e) => /* @__PURE__ */ h("span", {
							title: u(ot[e]),
							children: /* @__PURE__ */ h(J, { name: e })
						}, e))
					}),
					!t && /* @__PURE__ */ g("span", {
						className: "awk-card-vp",
						children: [/* @__PURE__ */ h(J, {
							name: "vp",
							size: 31
						}), /* @__PURE__ */ h("b", { children: A[e].vp })]
					}),
					p.virtue !== 0 && /* @__PURE__ */ g("span", {
						className: "awk-card-virtue",
						children: [/* @__PURE__ */ h(J, { name: "virtue" }), /* @__PURE__ */ g("b", { children: [p.virtue > 0 ? "+" : "", p.virtue] })]
					})
				]
			}),
			/* @__PURE__ */ h("strong", {
				className: "awk-card-name",
				children: u(p.name)
			}),
			t ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(dt, { id: e }), l && /* @__PURE__ */ h(ft, { id: e })] }) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Y, { values: A[e].cost }), /* @__PURE__ */ h("span", {
				className: "awk-card-text",
				children: u(it[e])
			})] }),
			n && /* @__PURE__ */ h(X, {})
		]
	});
}
//#endregion
//#region src/game/view-player.tsx
var pt = {
	mines: "games.architectsofthewestkingdom.pMines",
	workshop: "games.architectsofthewestkingdom.pWorkshop",
	hire: "games.architectsofthewestkingdom.pHire",
	middle: "games.architectsofthewestkingdom.pMiddle",
	pick: "games.architectsofthewestkingdom.pPick",
	guild: "games.architectsofthewestkingdom.pGuild",
	store: "games.architectsofthewestkingdom.pStore",
	capture: "games.architectsofthewestkingdom.pCapture",
	guard: "games.architectsofthewestkingdom.pGuard",
	discard: "games.architectsofthewestkingdom.pDiscard",
	treasury: "games.architectsofthewestkingdom.pTreasury",
	claypit: "games.architectsofthewestkingdom.pClaypit",
	library: "games.architectsofthewestkingdom.pLibrary",
	barracks: "games.architectsofthewestkingdom.pBarracks",
	resetSkills: "games.architectsofthewestkingdom.pReset",
	finalEffects: "games.architectsofthewestkingdom.pFinal"
}, mt = {
	place: "games.architectsofthewestkingdom.place",
	recover: "games.architectsofthewestkingdom.recover",
	draft: "games.architectsofthewestkingdom.draft",
	build: "games.architectsofthewestkingdom.build",
	cathedral: "games.architectsofthewestkingdom.cathedralAction",
	hire: "games.architectsofthewestkingdom.hire",
	plans: "games.architectsofthewestkingdom.plans",
	marketPlans: "games.architectsofthewestkingdom.marketPlans",
	pick: "games.architectsofthewestkingdom.pick",
	gather: "games.architectsofthewestkingdom.gather",
	trade: "games.architectsofthewestkingdom.trade",
	tradeVirtue: "games.architectsofthewestkingdom.tradeVirtue",
	capture: "games.architectsofthewestkingdom.capture",
	sell: "games.architectsofthewestkingdom.sell",
	release: "games.architectsofthewestkingdom.release",
	ransom: "games.architectsofthewestkingdom.ransom",
	ransomDebt: "games.architectsofthewestkingdom.ransomDebt",
	payDebt: "games.architectsofthewestkingdom.payDebt",
	ransomFree: "games.architectsofthewestkingdom.ransomFree",
	drop: "games.architectsofthewestkingdom.drop",
	discard: "games.architectsofthewestkingdom.discard",
	library: "games.architectsofthewestkingdom.library",
	resetSkill: "games.architectsofthewestkingdom.resetSkill",
	finalEffect: "games.architectsofthewestkingdom.finalEffect",
	finish: "games.architectsofthewestkingdom.finish"
};
function ht(e) {
	return /* @__PURE__ */ h(_t, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function Q({ id: e, children: t, className: n = "" }) {
	let { ref: r, hidden: i } = a(e);
	return /* @__PURE__ */ h("div", {
		className: n,
		ref: r,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function gt({ choice: e, onChoose: t }) {
	let n = c(), r = e.id.startsWith("skipSkill:") ? "games.architectsofthewestkingdom.skipSkill" : mt[e.kind] ?? "games.architectsofthewestkingdom.choose";
	return /* @__PURE__ */ g("button", {
		type: "button",
		className: "awk-choice",
		onClick: () => t(e),
		children: [/* @__PURE__ */ h("strong", { children: n(r) }), /* @__PURE__ */ g("span", { children: [
			e.cost && S.some((t) => e.cost[t] > 0) && /* @__PURE__ */ h(Y, { values: e.cost }),
			" ",
			(e.cost || e.kind === "tradeVirtue") && /* @__PURE__ */ h("span", { children: "→" }),
			" ",
			e.gain && /* @__PURE__ */ h(Y, { values: e.gain }),
			" ",
			e.kind === "tradeVirtue" && /* @__PURE__ */ h(J, { name: "virtue" }),
			e.n !== void 0 && !e.gain && ![
				"hire",
				"place",
				"tradeVirtue"
			].includes(e.kind) && /* @__PURE__ */ h("b", { children: e.n })
		] })]
	});
}
function _t({ pub: e, priv: t, members: n, myRid: i, send: a, readOnly: s = !1 }) {
	let d = c(), f = lt(n, e), [p, _] = r("kingdom"), [v, ee] = r(i), [y, b] = r(null), x = s ? [] : t?.choices ?? [], S = e.players.find((e) => e.rid === i) ?? e.players[0], C = e.players.find((e) => e.rid === v) ?? S, T = (e, t) => b({
		kind: e,
		id: t,
		owner: i
	}), E = y?.owner === i ? y : null, D = (e) => {
		a({
			type: "choose",
			id: e.id
		}), b(null);
	}, O = e.phase === "draft", k = O || e.pending === "pick" ? t?.pool ?? [] : t?.hand ?? [], A = s ? d("games.architectsofthewestkingdom.resultReadOnly") : O ? e.draftReady.includes(i) ? d("games.architectsofthewestkingdom.draftWaiting") : d("games.architectsofthewestkingdom.draftPrompt") : e.phase === "resolve" ? d("games.architectsofthewestkingdom.resolving") : x.length ? e.pending in pt ? d(pt[e.pending]) : d("games.architectsofthewestkingdom.turnPrompt") : d("games.architectsofthewestkingdom.wait", { name: f(e.active) }), j = x.filter((e) => ![
		"place",
		"build",
		"draft",
		"hire",
		"capture",
		"drop",
		"pick",
		"discard",
		"finalEffect",
		"resetSkill",
		"library",
		"cathedral"
	].includes(e.kind)), M = [...new Set(x.filter((e) => e.kind === "cathedral" && e.card !== void 0).map((e) => e.card))], te = () => T("cathedral", M[0] ?? -1), ne = E ? E.kind === "cathedral" ? x.filter((e) => e.kind === "cathedral" && (e.card === void 0 || e.card === E.id)) : E.kind === "building" ? x.filter((e) => e.card === E.id && [
		"build",
		"draft",
		"pick",
		"discard",
		"library",
		"finalEffect"
	].includes(e.kind)) : E.kind === "apprentice" ? x.filter((e) => e.card === E.id && [
		"hire",
		"drop",
		"resetSkill"
	].includes(e.kind)) : E.kind === "location" ? x.filter((e) => e.location === E.id) : [] : [], re = e.pending === "resetSkills" ? x.filter((e) => e.kind === "resetSkill" && !e.id.startsWith("skip")).map((e) => e.card) : e.pending === "finalEffects" ? x.filter((e) => e.kind === "finalEffect").map((e) => e.card) : [];
	return /* @__PURE__ */ h("div", {
		className: "awk-screen",
		children: /* @__PURE__ */ h(l, {
			adaptive: !0,
			scroll: !1,
			className: "awk-layout",
			banner: /* @__PURE__ */ g("div", {
				className: "awk-header",
				children: [
					/* @__PURE__ */ g("div", {
						className: "awk-title-row",
						children: [/* @__PURE__ */ h("strong", { children: d("games.architectsofthewestkingdom.name") }), /* @__PURE__ */ h("span", { children: s ? d("games.architectsofthewestkingdom.resultReadOnly") : e.finalTurns === null ? d("games.architectsofthewestkingdom.round", { n: e.turn }) : d("games.architectsofthewestkingdom.finalRound", { n: e.finalTurns }) })]
					}),
					/* @__PURE__ */ h("div", {
						className: "awk-player-strip",
						children: e.players.map((t) => /* @__PURE__ */ h(Q, {
							id: `seat:${t.rid}`,
							className: "awk-seat",
							children: /* @__PURE__ */ g("button", {
								type: "button",
								className: `awk-player-chip${t.rid === e.active ? " awk-active" : ""}`,
								onClick: () => {
									ee(t.rid), _("estate");
								},
								style: { "--awk-player": K(n, t.rid) },
								children: [/* @__PURE__ */ h(q, {
									rid: t.rid,
									members: n
								}), /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("b", { children: f(t.rid) }), /* @__PURE__ */ g("small", { children: [
									/* @__PURE__ */ h(J, {
										name: "virtue",
										size: 15
									}),
									t.virtue,
									/* @__PURE__ */ h(J, {
										name: "worker",
										size: 15
									}),
									t.workers
								] })] })]
							}, t.rid)
						}, t.rid))
					}),
					/* @__PURE__ */ h(u, {
						tone: x.length ? "accent" : "info",
						text: A,
						chip: O ? d("games.architectsofthewestkingdom.draftRound", { n: Math.min(3, e.draftRound) }) : e.remaining ? d("games.architectsofthewestkingdom.remaining", { n: e.remaining }) : void 0,
						accent: "#785333"
					})
				]
			}),
			actionsHeight: "awk-hand-slot",
			actions: /* @__PURE__ */ g("div", {
				className: "awk-hand-region",
				children: [/* @__PURE__ */ g(Q, {
					id: `supply:${i}`,
					className: "awk-supply",
					children: [
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "awk-role-name",
							onClick: () => T("role", S.rid),
							children: [/* @__PURE__ */ h(q, {
								rid: i,
								members: n
							}), /* @__PURE__ */ h("b", { children: d(st[S.role]) })]
						}),
						/* @__PURE__ */ h(Q, {
							id: `resources:${i}`,
							children: /* @__PURE__ */ h(Y, {
								values: S.stock,
								zeros: !0
							})
						}),
						/* @__PURE__ */ g("span", {
							className: "awk-supply-workers",
							children: [/* @__PURE__ */ h(J, { name: "worker" }), /* @__PURE__ */ h(o, { value: S.workers })]
						}),
						/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(J, { name: "debt" }), S.debt] })
					]
				}), /* @__PURE__ */ g(Q, {
					id: "hand",
					className: "awk-hand-scroll",
					children: [k.map((e) => /* @__PURE__ */ h(Z, {
						id: e,
						legal: x.some((t) => t.card === e && ![
							"cathedral",
							"hire",
							"drop"
						].includes(t.kind)),
						onClick: () => T("building", e),
						anchor: `hand:${e}`
					}, e)), !k.length && /* @__PURE__ */ h("span", {
						className: "awk-empty",
						children: d("games.architectsofthewestkingdom.noCards")
					})]
				})]
			}),
			overlay: E && /* @__PURE__ */ h("div", {
				className: "awk-detail-shade",
				onClick: () => b(null),
				children: /* @__PURE__ */ g("section", {
					className: "awk-detail",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ h("button", {
						className: "awk-close",
						type: "button",
						onClick: () => b(null),
						"aria-label": d("games.architectsofthewestkingdom.close"),
						children: "×"
					}), /* @__PURE__ */ g("div", {
						className: "awk-detail-content",
						children: [
							(E.kind === "building" || E.kind === "apprentice") && /* @__PURE__ */ h(Z, {
								id: Number(E.id),
								apprentice: E.kind === "apprentice",
								detail: !0
							}),
							E.kind === "cathedral" && /* @__PURE__ */ g(m, { children: [
								/* @__PURE__ */ h("h2", { children: d("games.architectsofthewestkingdom.cathedral") }),
								/* @__PURE__ */ h(J, {
									name: "cathedral",
									size: 80
								}),
								/* @__PURE__ */ h("p", { children: d("games.architectsofthewestkingdom.level", { n: S.cathedral + 1 }) }),
								M.length > 0 && /* @__PURE__ */ g("div", {
									className: "awk-cathedral-discards",
									children: [/* @__PURE__ */ h("p", { children: d("games.architectsofthewestkingdom.cathedralDiscard") }), /* @__PURE__ */ h("div", { children: M.map((e) => /* @__PURE__ */ h(Z, {
										id: e,
										selected: E.id === e,
										onClick: () => T("cathedral", e)
									}, e)) })]
								})
							] }),
							E.kind === "role" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("h2", { children: f(String(E.id)) }), /* @__PURE__ */ h("p", { children: d(ct[e.players.find((e) => e.rid === E.id)?.role ?? "standard"]) })] }),
							E.kind === "location" && /* @__PURE__ */ h("h2", { children: d(rt[E.id]) }),
							/* @__PURE__ */ h("div", {
								className: "awk-detail-actions",
								children: ne.map((e) => /* @__PURE__ */ h(gt, {
									choice: e,
									onChoose: D
								}, e.id))
							})
						]
					})]
				})
			}),
			children: /* @__PURE__ */ g("div", {
				className: "awk-main",
				children: [
					/* @__PURE__ */ h("nav", {
						className: "awk-tabs",
						children: [
							"kingdom",
							"apprentices",
							"estate"
						].map((e) => /* @__PURE__ */ h("button", {
							className: p === e ? "awk-tab-active" : "",
							type: "button",
							onClick: () => _(e),
							children: d(e === "kingdom" ? "games.architectsofthewestkingdom.kingdom" : e === "apprentices" ? "games.architectsofthewestkingdom.apprentices" : "games.architectsofthewestkingdom.estate")
						}, e))
					}),
					/* @__PURE__ */ g("div", {
						className: "awk-main-columns",
						children: [
							/* @__PURE__ */ g("section", {
								className: "awk-kingdom-pane",
								"data-visible": p === "kingdom",
								children: [
									/* @__PURE__ */ g("div", {
										className: "awk-monuments",
										children: [/* @__PURE__ */ h(xt, {
											pub: e,
											members: n,
											myRid: i,
											legal: x.some((e) => e.location === "guild" && e.kind === "place"),
											onClick: () => {
												let e = x.find((e) => e.location === "guild" && e.kind === "place");
												e && D(e);
											}
										}), /* @__PURE__ */ h(St, {
											pub: e,
											members: n,
											legal: x.some((e) => e.kind === "cathedral"),
											onClick: te
										})]
									}),
									/* @__PURE__ */ h("div", {
										className: "awk-locations",
										children: w.filter((e) => e !== "guild").map((t) => /* @__PURE__ */ h(bt, {
											location: t,
											pub: e,
											members: n,
											myRid: i,
											choices: x,
											onChoose: D,
											onInspect: () => T("location", t)
										}, t))
									}),
									/* @__PURE__ */ g("div", {
										className: "awk-board-footer",
										children: [
											/* @__PURE__ */ g(Q, {
												id: "buildingDeck",
												children: [/* @__PURE__ */ h("span", { className: "awk-deck-stack" }), d("games.architectsofthewestkingdom.buildingDeck", { n: e.deckCount })]
											}),
											/* @__PURE__ */ h("span", { children: d("games.architectsofthewestkingdom.rewardDeck", { n: e.rewardCount }) }),
											/* @__PURE__ */ h("span", { children: d("games.architectsofthewestkingdom.resetCount", { n: e.reset }) })
										]
									})
								]
							}),
							/* @__PURE__ */ g("section", {
								className: "awk-market-pane",
								"data-visible": p === "apprentices",
								children: [
									/* @__PURE__ */ h(Q, {
										id: "apprenticeDeck",
										children: /* @__PURE__ */ h("h2", { children: d("games.architectsofthewestkingdom.workshop") })
									}),
									/* @__PURE__ */ h("div", {
										className: "awk-apprentice-market",
										children: e.market.map((e, t) => /* @__PURE__ */ g(Q, {
											id: `market:${t}`,
											className: "awk-market-slot",
											children: [/* @__PURE__ */ h("span", {
												className: "awk-column-workers",
												children: Array.from({ length: t % 4 + 1 }, (e, t) => /* @__PURE__ */ h(J, {
													name: "worker",
													size: 12
												}, t))
											}), e ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Z, {
												id: e.card,
												apprentice: !0,
												legal: x.some((t) => t.kind === "hire" && t.card === e.card),
												onClick: () => T("apprentice", e.card)
											}), e.silver > 0 && /* @__PURE__ */ g("span", {
												className: "awk-silver-on-card",
												children: [/* @__PURE__ */ h(J, { name: "silver" }), e.silver]
											})] }) : /* @__PURE__ */ h("span", { children: d("games.architectsofthewestkingdom.emptyMarket") })]
										}, t))
									}),
									e.automa && /* @__PURE__ */ g("div", {
										className: "awk-automa",
										children: [/* @__PURE__ */ h("h3", { children: d("games.architectsofthewestkingdom.automaScheme") }), /* @__PURE__ */ h("span", { children: e.scheme === null ? "—" : d(rt[vt(e.scheme)]) })]
									})
								]
							}),
							/* @__PURE__ */ g("section", {
								className: "awk-estate-pane",
								"data-visible": p === "estate",
								children: [
									/* @__PURE__ */ g("div", {
										className: "awk-estate-heading",
										children: [/* @__PURE__ */ h("h2", { children: f(C.rid) }), /* @__PURE__ */ h("div", { children: e.players.map((e) => /* @__PURE__ */ h("button", {
											type: "button",
											className: e.rid === C.rid ? "awk-selected-seat" : "",
											onClick: () => ee(e.rid),
											"aria-label": d("games.architectsofthewestkingdom.inspect", { name: f(e.rid) }),
											children: /* @__PURE__ */ h(q, {
												rid: e.rid,
												members: n
											})
										}, e.rid)) })]
									}),
									/* @__PURE__ */ h(Y, {
										values: C.stock,
										zeros: !0
									}),
									/* @__PURE__ */ g("div", {
										className: "awk-estate-meters",
										children: [
											/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(J, { name: "virtue" }), C.virtue] }),
											/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(J, { name: "debt" }), C.debt] }),
											/* @__PURE__ */ g("span", { children: [
												d("games.architectsofthewestkingdom.paid"),
												": ",
												C.paid
											] })
										]
									}),
									/* @__PURE__ */ g("div", {
										className: "awk-detained",
										children: [/* @__PURE__ */ g(Q, {
											id: `prison:${C.rid}`,
											children: [
												/* @__PURE__ */ h("h3", { children: d("games.architectsofthewestkingdom.prison") }),
												/* @__PURE__ */ h(J, {
													name: "worker",
													color: K(n, C.rid)
												}),
												/* @__PURE__ */ h("b", { children: C.prison })
											]
										}), /* @__PURE__ */ g(Q, {
											id: `captives:${C.rid}`,
											children: [/* @__PURE__ */ h("h3", { children: d("games.architectsofthewestkingdom.captives") }), Object.entries(C.captives).filter(([, e]) => e > 0).map(([e, t]) => /* @__PURE__ */ g("span", { children: [
												/* @__PURE__ */ h(q, {
													rid: e,
													members: n
												}),
												f(e),
												" ",
												/* @__PURE__ */ h("b", { children: t })
											] }, e))]
										})]
									}),
									/* @__PURE__ */ g(Q, {
										id: `apprentices:${C.rid}`,
										children: [/* @__PURE__ */ h("h3", { children: d("games.architectsofthewestkingdom.apprentices") }), /* @__PURE__ */ h("div", {
											className: "awk-estate-cards",
											children: C.apprentices.map((e) => /* @__PURE__ */ h(Z, {
												id: e,
												apprentice: !0,
												onClick: () => T("apprentice", e),
												legal: x.some((t) => t.card === e && t.kind === "resetSkill")
											}, e))
										})]
									}),
									/* @__PURE__ */ g(Q, {
										id: `city:${C.rid}`,
										children: [/* @__PURE__ */ h("h3", { children: d("games.architectsofthewestkingdom.buildings") }), /* @__PURE__ */ h("div", {
											className: "awk-estate-cards",
											children: C.built.map((e) => /* @__PURE__ */ h(Z, {
												id: e,
												onClick: () => T("building", e),
												anchor: `cityCard:${e}`,
												legal: x.some((t) => t.card === e && t.kind === "finalEffect")
											}, e))
										})]
									})
								]
							})
						]
					}),
					x.length > 0 && (j.length > 0 || re.length > 0 || e.pending === "guild") && /* @__PURE__ */ h("div", {
						className: "awk-context-panel",
						children: /* @__PURE__ */ g("div", {
							className: "awk-context-scroll",
							children: [
								re.map((t) => /* @__PURE__ */ h(Z, {
									id: t,
									apprentice: e.pending === "resetSkills",
									legal: !0,
									onClick: () => T(e.pending === "resetSkills" ? "apprentice" : "building", t)
								}, t)),
								j.map((e) => /* @__PURE__ */ h(gt, {
									choice: e,
									onChoose: D
								}, e.id)),
								e.pending === "guild" && x.some((e) => e.kind === "cathedral") && /* @__PURE__ */ g("button", {
									type: "button",
									className: "awk-cathedral-choice awk-legal",
									onClick: te,
									children: [
										/* @__PURE__ */ h(J, {
											name: "cathedral",
											size: 38
										}),
										d("games.architectsofthewestkingdom.cathedralAction"),
										/* @__PURE__ */ h(X, {})
									]
								})
							]
						})
					})
				]
			})
		})
	});
}
function vt(e) {
	return [
		0,
		5,
		11
	].includes(e) ? "workshop" : [1, 12].includes(e) ? "tax" : [3, 18].includes(e) ? "small" : [
		4,
		6,
		10,
		16
	].includes(e) ? "storehouse" : [
		13,
		14,
		17,
		19
	].includes(e) ? "town" : [15, 20].includes(e) ? "guard" : "guild";
}
var yt = {
	forest: 3,
	quarry: 33,
	mines: 9,
	silversmith: 37,
	storehouse: 4,
	workshop: 8,
	town: 2,
	tax: 6,
	guard: 22,
	guild: 12,
	small: 30,
	middle: 17,
	large: 5
};
function bt({ location: e, pub: t, members: n, myRid: r, choices: o, onChoose: s, onInspect: l }) {
	let u = c(), d = lt(n, t), { ref: f } = a(`location:${e}`), p = o.find((t) => t.location === e && ["place", "recover"].includes(t.kind)), _ = (t.locations[e][r] ?? 0) + 1, v = t.players.filter((n) => (t.locations[e][n.rid] ?? 0) > 0);
	return /* @__PURE__ */ g("div", {
		ref: f,
		className: `awk-location awk-location-${e}${p ? " awk-legal" : ""}`,
		children: [
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "awk-location-main",
				onClick: () => p ? s(p) : l(),
				"aria-label": `${u(rt[e])}${p ? " · " + u("games.architectsofthewestkingdom.place") : ""}`,
				children: [
					/* @__PURE__ */ h("img", {
						alt: "",
						draggable: !1,
						src: i(`games/architectsofthewestkingdom/live/b${yt[e]}.webp`)
					}),
					/* @__PURE__ */ h("strong", { children: u(rt[e]) }),
					/* @__PURE__ */ h("span", {
						className: "awk-location-yield",
						children: e === "forest" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(J, { name: "wood" }), _] }) : e === "quarry" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(J, { name: "stone" }), _] }) : e === "silversmith" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(J, { name: "silver" }), _ + 1] }) : e === "mines" ? /* @__PURE__ */ g(m, { children: [
							/* @__PURE__ */ h(J, { name: "clay" }),
							_ + 1,
							/* @__PURE__ */ h("span", { children: "/" }),
							/* @__PURE__ */ h(J, { name: "gold" }),
							Math.floor(_ / 2)
						] }) : e === "tax" ? /* @__PURE__ */ g(m, { children: [
							/* @__PURE__ */ h(J, { name: "silver" }),
							t.tax,
							/* @__PURE__ */ h("span", { children: "−2" }),
							/* @__PURE__ */ h(J, { name: "virtue" })
						] }) : e === "small" || e === "large" ? /* @__PURE__ */ h(Y, { values: e === "small" ? t.small : t.large }) : e === "middle" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(J, { name: "silver" }), "2"] }) : e === "storehouse" ? /* @__PURE__ */ g(m, { children: [
							/* @__PURE__ */ h(J, { name: "wood" }),
							/* @__PURE__ */ h(J, { name: "stone" }),
							/* @__PURE__ */ h("span", { children: "→" }),
							/* @__PURE__ */ h(J, { name: "virtue" }),
							/* @__PURE__ */ h(J, { name: "marble" })
						] }) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(J, { name: "worker" }), _] })
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "awk-location-workers",
				children: v.map((r) => {
					let i = o.find((t) => t.kind === "capture" && t.location === e && t.target === r.rid);
					return /* @__PURE__ */ h(ut, {
						rid: r.rid,
						n: t.locations[e][r.rid],
						members: n,
						name: d(r.rid),
						anchor: e,
						legal: !!i,
						onClick: () => i && s(i)
					}, r.rid);
				})
			}),
			p && /* @__PURE__ */ h(X, {})
		]
	});
}
function xt({ pub: e, members: t, myRid: n, legal: r, onClick: i }) {
	let o = c(), { ref: s } = a("location:guild");
	return /* @__PURE__ */ g("button", {
		type: "button",
		ref: s,
		onClick: i,
		className: `awk-guildhall${r ? " awk-legal" : ""}`,
		children: [
			/* @__PURE__ */ h("span", {
				className: "awk-monument-title",
				children: o("games.architectsofthewestkingdom.guild")
			}),
			/* @__PURE__ */ h("span", {
				className: "awk-guild-grid",
				style: { gridTemplateColumns: `repeat(${e.players.length + 1},1fr)` },
				children: Array.from({ length: Math.max(e.guildLimit, e.guild.length) }, (r, i) => /* @__PURE__ */ g("span", {
					className: "awk-guild-cell",
					children: [e.guild[i] ? /* @__PURE__ */ h(J, {
						name: "worker",
						color: K(t, e.guild[i])
					}) : /* @__PURE__ */ h(J, {
						name: "worker",
						color: "#aaa080"
					}), e.guild[i] === n && /* @__PURE__ */ h("i", {})]
				}, i))
			}),
			/* @__PURE__ */ h("small", { children: o("games.architectsofthewestkingdom.guildCount", {
				n: e.guild.length,
				total: e.guildLimit
			}) }),
			r && /* @__PURE__ */ h(X, {})
		]
	});
}
function St({ pub: e, members: t, legal: n, onClick: r }) {
	let i = c(), { ref: o } = a("cathedral"), s = [
		"games.architectsofthewestkingdom.cathedralCost1",
		"games.architectsofthewestkingdom.cathedralCost2",
		"games.architectsofthewestkingdom.cathedralCost3",
		"games.architectsofthewestkingdom.cathedralCost4",
		"games.architectsofthewestkingdom.cathedralCost5"
	];
	return /* @__PURE__ */ g("button", {
		ref: o,
		type: "button",
		className: `awk-cathedral${n ? " awk-legal" : ""}`,
		onClick: r,
		children: [
			/* @__PURE__ */ h("span", {
				className: "awk-monument-title",
				children: i("games.architectsofthewestkingdom.cathedral")
			}),
			/* @__PURE__ */ h("span", {
				className: "awk-cathedral-levels",
				children: [
					5,
					4,
					3,
					2,
					1
				].map((n) => /* @__PURE__ */ g("span", {
					className: "awk-cathedral-level",
					style: { width: `min(100%, max(140px, ${58 + (5 - n) * 10}%))` },
					children: [
						/* @__PURE__ */ g("span", {
							className: "awk-cathedral-score",
							children: [ne[n], /* @__PURE__ */ h(J, {
								name: "vp",
								size: 15
							})]
						}),
						/* @__PURE__ */ h("span", {
							className: "awk-cathedral-cost",
							role: "img",
							"aria-label": `${i("games.architectsofthewestkingdom.level", { n })}: ${i(s[n - 1])}`,
							title: i(s[n - 1]),
							children: /* @__PURE__ */ h("span", {
								"aria-hidden": !0,
								children: n === 2 || n === 4 ? /* @__PURE__ */ g(m, { children: [
									i("games.architectsofthewestkingdom.cathedralAny"),
									" ",
									n === 2 ? 4 : 8,
									/* @__PURE__ */ h(J, {
										name: "wood",
										size: 15
									}),
									"/",
									/* @__PURE__ */ h(J, {
										name: "stone",
										size: 15
									})
								] }) : n === 5 ? /* @__PURE__ */ g(m, { children: [
									"2",
									/* @__PURE__ */ h(J, {
										name: "gold",
										size: 15
									}),
									" + 2",
									/* @__PURE__ */ h(J, {
										name: "marble",
										size: 15
									})
								] }) : /* @__PURE__ */ g(m, { children: ["1", /* @__PURE__ */ h(J, {
									name: n === 1 ? "gold" : "marble",
									size: 15
								})] })
							})
						}),
						/* @__PURE__ */ h("span", {
							className: "awk-cathedral-players",
							children: e.players.filter((e) => e.cathedral === n).map((e) => /* @__PURE__ */ h(q, {
								rid: e.rid,
								members: t,
								size: 16
							}, e.rid))
						})
					]
				}, n))
			}),
			n && /* @__PURE__ */ h(X, {})
		]
	});
}
//#endregion
//#region src/game/fx.tsx
var $ = (e, t = 32, n = t) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), Ct = { architectsEvent(e, t) {
	let n = e.data;
	if (!n || !e.rid) return null;
	let r = (e) => {
		let n = t.anchor(e);
		return n && n.w > 0 && n.h > 0 ? n : null;
	}, i = e.rid, a = r(`seat:${i}`), o = i === t.myRid, s = a ?? r("hand");
	if (!s) return null;
	let c = (e) => r(e) ?? s, l = t.queued ? 180 : 540, u = (e, t, n, r = 32, i = r) => ({
		ms: l,
		node: /* @__PURE__ */ h(v, {
			from: $(e, r, i),
			to: $(t, r, i),
			ms: l,
			children: n
		})
	}), d = (e, t = !1) => e === void 0 ? /* @__PURE__ */ h("span", { className: "awk-fx-card-back" }) : /* @__PURE__ */ h("div", {
		className: "awk-fx-card",
		children: /* @__PURE__ */ h(Z, {
			id: e,
			apprentice: t
		})
	}), p = [], y = [], b = (e, t) => r(e) ?? r(`seat:${e.startsWith("captives:") ? e.slice(9) : t}`) ?? s;
	for (let [e, r] of (n.draws ?? []).entries()) y.push(/* @__PURE__ */ h(v, {
		from: $(c("buildingDeck"), 64, 96),
		to: $(r.rid === t.myRid ? c("hand") : b(`seat:${r.rid}`, r.rid), 64, 96),
		ms: l,
		children: d()
	}, `draw${e}`));
	for (let [e, r] of (n.moves ?? []).entries()) {
		let n = f[(t.member(r.rid)?.colorIndex ?? 7) % f.length].hex;
		y.push(/* @__PURE__ */ h(v, {
			from: $(b(r.from, r.rid), 42, 38),
			to: $(b(r.to, r.rid), 42, 38),
			ms: l,
			children: /* @__PURE__ */ g("span", {
				className: "awk-fx-workers",
				children: [/* @__PURE__ */ h(J, {
					name: "worker",
					color: n,
					size: 30
				}), r.n > 1 && /* @__PURE__ */ h("b", { children: r.n })]
			})
		}, `w${e}`));
	}
	for (let [e, t] of (n.changes ?? []).entries()) y.push(/* @__PURE__ */ h(_, {
		at: b(`resources:${t.rid}`, t.rid),
		ms: l,
		children: /* @__PURE__ */ g("span", {
			className: "awk-fx-gain",
			style: { transform: `translate(${e % 3 * 36}px,${-Math.floor(e / 3) * 34}px)` },
			children: [
				/* @__PURE__ */ h(J, { name: t.resource }),
				t.n > 0 ? "+" : "",
				t.n
			]
		})
	}, `d${e}`));
	for (let [e, t] of (n.marketMoves ?? []).entries()) {
		let n = r(t.from), i = r(t.to);
		n && i && (y.push(/* @__PURE__ */ h(v, {
			from: $(n, 80, 128),
			to: $(i, 80, 128),
			ms: l,
			children: d(t.card, !0)
		}, `m${e}`)), p.push(t.to));
	}
	let x = (() => {
		if (n.kind === "hire") return u(c(n.target ?? "location:workshop"), c(`apprentices:${i}`), d(n.card, !0), 80, 128);
		if (n.kind === "build") {
			let e = `cityCard:${n.card}`, a = r(e) ?? c(`city:${i}`);
			return {
				...u(o ? c("hand") : s, a, d(n.card), 80, 128),
				hide: t.queued ? [] : r(e) ? [e] : []
			};
		}
		if (n.kind === "cathedral") return {
			ms: l,
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(v, {
				from: $(o ? c("hand") : s, 64, 96),
				to: $(c("buildingDeck"), 64, 96),
				ms: l,
				children: d()
			}), /* @__PURE__ */ h(ee, {
				at: c("cathedral"),
				ms: l
			})] })
		};
		if ([
			"draw",
			"plans",
			"marketPlans",
			"draft",
			"pick",
			"discard",
			"library"
		].includes(n.kind)) {
			if (n.draws?.length) return null;
			let e = ["discard", "library"].includes(n.kind), t = o ? c("hand") : s, r = c("buildingDeck");
			return u(e ? t : r, e ? r : t, d(), 64, 96);
		}
		return n.kind === "drop" ? u(c(`apprentices:${i}`), c("apprenticeDeck"), d(n.card, !0), 64, 102) : n.kind === "resetFlip" ? u(c("location:small"), c("location:large"), d(), 64, 96) : [
			"turnEnd",
			"advance",
			"openMiddle",
			"finalEffects",
			"resetSkills",
			"score",
			"place",
			"recover",
			"capture",
			"release",
			"ransom",
			"ransomDebt",
			"ransomFree",
			"sell",
			"resetStart",
			"automa",
			"gain",
			"gather",
			"trade",
			"virtue",
			"tradeVirtue",
			"automaRecover",
			"resetVirtue",
			"resetDebt"
		].includes(n.kind) ? null : {
			ms: l,
			node: /* @__PURE__ */ h(ee, {
				at: s,
				ms: l
			})
		};
	})();
	return x || y.length ? {
		ms: l,
		node: /* @__PURE__ */ g(m, { children: [x?.node, y] }),
		hide: t.queued ? [] : [...p, ...x && "hide" in x ? x.hide : []]
	} : null;
} }, wt = {
	buildings: "games.architectsofthewestkingdom.scoreBuildings",
	cathedral: "games.architectsofthewestkingdom.scoreCathedral",
	virtue: "games.architectsofthewestkingdom.scoreVirtue",
	debts: "games.architectsofthewestkingdom.scoreDebts",
	resources: "games.architectsofthewestkingdom.scoreResources",
	silver: "games.architectsofthewestkingdom.scoreSilver",
	prison: "games.architectsofthewestkingdom.scorePrison",
	total: "games.architectsofthewestkingdom.scoreTotal"
};
function Tt(e) {
	let t = e.public, n = c(), i = lt(e.members, t), [a, o] = r(!0);
	return /* @__PURE__ */ g("div", {
		className: "awk-screen awk-over",
		children: [
			/* @__PURE__ */ h("div", {
				className: "awk-over-board",
				"aria-hidden": a,
				inert: a,
				children: /* @__PURE__ */ h(_t, {
					...e,
					pub: t,
					priv: e.private,
					send: () => {},
					readOnly: !0
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "awk-result-shade",
				style: { display: a ? void 0 : "none" },
				children: /* @__PURE__ */ g("section", {
					className: "awk-result",
					children: [
						/* @__PURE__ */ g("header", {
							className: "awk-result-heading",
							children: [
								/* @__PURE__ */ h(J, {
									name: "cathedral",
									size: 40
								}),
								/* @__PURE__ */ h("h1", { children: n("games.architectsofthewestkingdom.resultTitle") }),
								/* @__PURE__ */ h("p", { children: e.result.winner.map(i).join(" · ") }),
								/* @__PURE__ */ h("button", {
									type: "button",
									className: "awk-result-close",
									"aria-label": n("games.architectsofthewestkingdom.reviewBoard"),
									onClick: () => o(!1),
									children: "⌄"
								})
							]
						}),
						/* @__PURE__ */ g("div", {
							className: "awk-result-scroll",
							children: [/* @__PURE__ */ g("table", {
								className: "awk-score-table",
								children: [/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: n("games.architectsofthewestkingdom.name") }), e.result.ranking.map((t) => /* @__PURE__ */ h("th", { children: /* @__PURE__ */ g("span", {
									className: "awk-score-person",
									children: [
										/* @__PURE__ */ h(q, {
											rid: t,
											members: e.members,
											size: 36
										}),
										/* @__PURE__ */ h("strong", { children: i(t) }),
										e.result.winner.includes(t) && /* @__PURE__ */ h("small", { children: n("games.architectsofthewestkingdom.winner") })
									]
								}) }, t))] }) }), /* @__PURE__ */ h("tbody", { children: Object.keys(wt).map((r) => /* @__PURE__ */ g("tr", {
									className: r === "total" ? "awk-score-total" : "",
									children: [/* @__PURE__ */ h("th", { children: n(wt[r]) }), e.result.ranking.map((e) => /* @__PURE__ */ h("td", { children: t.scores?.[e]?.[r] ?? 0 }, e))]
								}, r)) })]
							}), /* @__PURE__ */ h("div", {
								className: "awk-result-city-list",
								children: t.players.map((t) => /* @__PURE__ */ g("div", { children: [
									/* @__PURE__ */ h(q, {
										rid: t.rid,
										members: e.members
									}),
									/* @__PURE__ */ h("span", { children: i(t.rid) }),
									/* @__PURE__ */ h("b", { children: n("games.architectsofthewestkingdom.buildingCount", { n: t.built.length }) })
								] }, t.rid))
							})]
						}),
						/* @__PURE__ */ g("footer", {
							className: "awk-result-actions",
							children: [
								e.onPlayAgain && /* @__PURE__ */ h(y, {
									label: n("session.result.playAgain"),
									confirmLabel: n("games.architectsofthewestkingdom.confirm"),
									onConfirm: e.onPlayAgain
								}),
								" ",
								e.onBackToLobby && /* @__PURE__ */ h(y, {
									label: n("session.result.backToLobby"),
									confirmLabel: n("games.architectsofthewestkingdom.confirm"),
									onConfirm: e.onBackToLobby
								}),
								" ",
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ h("p", { children: n("session.result.waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "awk-result-reopen",
				style: { display: a ? "none" : void 0 },
				onClick: () => o(!0),
				children: n("games.architectsofthewestkingdom.showResult")
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
function Et({ value: e, onChange: t }) {
	let n = c(), r = de.safeParse(e), i = r.success ? r.data : de.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ h(x, {
				title: n("games.architectsofthewestkingdom.optVariable"),
				columns: 2,
				children: [!1, !0].map((e) => /* @__PURE__ */ h(b, {
					name: "awk-variable",
					value: String(e),
					checked: i.variable === e,
					accent: ue.accent,
					label: n(e ? "games.architectsofthewestkingdom.optAsymmetric" : "games.architectsofthewestkingdom.optStandard"),
					onChange: () => t({
						...i,
						variable: e
					})
				}, String(e)))
			}),
			/* @__PURE__ */ h(x, {
				title: n("games.architectsofthewestkingdom.optSolo"),
				columns: 2,
				children: ["constantine", "helena"].map((e) => /* @__PURE__ */ h(b, {
					name: "awk-solo",
					value: e,
					checked: i.solo === e,
					accent: ue.accent,
					label: n(e === "constantine" ? "games.architectsofthewestkingdom.constantine" : "games.architectsofthewestkingdom.helena"),
					onChange: () => t({
						...i,
						solo: e
					})
				}, e))
			}),
			/* @__PURE__ */ h("p", {
				className: "text-xs",
				children: n("games.architectsofthewestkingdom.optSoloHint")
			})
		]
	});
}
//#endregion
//#region src/game/guide.tsx
function Dt() {
	let e = c();
	return /* @__PURE__ */ g("div", {
		className: "awk-guide",
		children: [
			S.map((t) => /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(J, {
				name: t,
				size: 30
			}), e(at[t])] }, t)),
			[
				"carpentry",
				"tiling",
				"masonry"
			].map((t) => /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(J, {
				name: t,
				size: 30
			}), e(ot[t])] }, t)),
			/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(J, {
				name: "virtue",
				size: 30
			}), e("games.architectsofthewestkingdom.virtue")] }),
			/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(J, {
				name: "debt",
				size: 30
			}), e("games.architectsofthewestkingdom.debt")] })
		]
	});
}
//#endregion
//#region src/index.tsx
var Ot = {
	definition: Je,
	View: ht,
	bot: tt,
	describe: nt,
	fx: Ct,
	OverView: Tt,
	Options: Et,
	Guide: Dt,
	locales: {
		zh: {
			name: "西国建筑师",
			desc: "集结工人、雇佣学徒，在美德与利益之间建造王国。",
			forest: "森林",
			quarry: "采石场",
			mines: "矿场",
			silversmith: "银匠铺",
			storehouse: "国王仓库",
			workshop: "工坊",
			town: "市镇中心",
			tax: "税务所",
			guard: "卫所",
			guild: "行会大厅",
			small: "小黑市",
			middle: "中黑市",
			large: "大黑市",
			wood: "木材",
			stone: "石料",
			clay: "黏土",
			gold: "黄金",
			marble: "大理石",
			silver: "银币",
			carpentry: "木工",
			tiling: "铺瓦",
			masonry: "石工",
			virtue: "美德",
			debt: "未偿债务",
			paid: "已偿债务",
			prison: "监狱",
			workers: "工人",
			captives: "俘虏",
			cathedral: "大教堂",
			cathedralAny: "任意",
			cathedralCost1: "1 份黄金",
			cathedralCost2: "任意组合的 4 份木材和石料",
			cathedralCost3: "1 份大理石",
			cathedralCost4: "任意组合的 8 份木材和石料",
			cathedralCost5: "2 份黄金和 2 份大理石",
			buildings: "建筑",
			apprentices: "学徒",
			hand: "手牌",
			standard: "标准角色",
			ada: "阿达",
			frederick: "弗雷德里克",
			caroline: "卡罗琳",
			rudolf: "鲁道夫",
			therese: "特蕾莎",
			constantine: "君士坦丁",
			helena: "海伦娜",
			optVariable: "角色能力",
			optStandard: "标准",
			optAsymmetric: "随机角色",
			optSolo: "官方单人对手",
			optSoloHint: "单人开局自动加入拜占庭建筑师；多人开局使用通常规则。",
			round: "第 {{n}} 回合",
			turnPrompt: "请选择放置工人的地点。",
			wait: "等待 {{name}} 行动。",
			draftPrompt: "请选择一张建筑牌。",
			draftWaiting: "已选好建筑牌，等待其他人。",
			resolving: "正在结算。",
			finalRound: "最后 {{n}} 个回合",
			draftRound: "建筑轮抽 {{n}} / 3",
			remaining: "剩余 {{n}} 次行动",
			kingdom: "王国",
			estate: "我的城市",
			inspect: "查看 {{name}}",
			close: "关闭",
			back: "返回版图",
			choose: "选择",
			confirm: "确认行动",
			finish: "结束本次行动",
			recover: "收回一名工人",
			place: "放置工人",
			draft: "保留这张建筑牌",
			build: "建造",
			cathedralDiscard: "请选择一张建筑牌，将其弃置以推进大教堂。",
			cathedralAction: "推进大教堂",
			hire: "雇佣学徒",
			plans: "研究建筑图纸",
			marketPlans: "抽取五张建筑牌并保留一张",
			pick: "保留这张牌",
			gather: "获得资源",
			trade: "交换资源",
			tradeVirtue: "捐赠资源，获得美德",
			capture: "抓捕这组工人",
			sell: "将全部俘虏送入监狱",
			release: "释放自己的全部在押工人",
			ransom: "付费赎回被俘工人",
			ransomDebt: "承担债务赎回被俘工人",
			payDebt: "偿还一笔债务",
			ransomFree: "赎回自己的全部被俘工人",
			drop: "解雇学徒",
			discard: "弃置建筑牌",
			library: "弃置这张牌，获得两份黄金",
			resetSkill: "使用学徒能力",
			skipSkill: "放弃释放工人",
			finalEffect: "结算建筑能力",
			pMines: "选择开采的资源。",
			pWorkshop: "选择学徒，或研究新的建筑图纸。",
			pHire: "选择要雇佣的学徒。",
			pMiddle: "选择一名学徒，或研究五张建筑图纸。",
			pPick: "保留一张建筑牌，其余放回牌堆底。",
			pGuild: "选择建造建筑或推进大教堂。",
			pStore: "选择要交换的资源。",
			pCapture: "选择地点中的一组工人。",
			pGuard: "选择卫所行动。",
			pDiscard: "请选择要弃置的建筑牌，直到手牌不超过六张。",
			pTreasury: "选择国库提供的奖励。",
			pClaypit: "选择黏土坑提供的奖励。",
			pLibrary: "可以弃置一张建筑牌，获得两份黄金。",
			pBarracks: "选择赎回工人或抓捕一组工人。",
			pReset: "选择学徒能力的结算顺序。",
			pFinal: "选择建筑效果的结算顺序。",
			cost: "费用",
			gain: "获得",
			points: "{{n}} 分",
			ability: "能力",
			scoreTotal: "总分",
			scoreBuildings: "建筑与附加分",
			scoreCathedral: "大教堂",
			scoreVirtue: "美德",
			scoreDebts: "债务",
			scoreResources: "黄金与大理石",
			scoreSilver: "银币",
			scorePrison: "在押工人",
			resultTitle: "王国竣工",
			winner: "获胜者",
			reviewBoard: "回看王国",
			showResult: "查看计分",
			resultReadOnly: "最终王国",
			noCards: "暂无卡牌",
			prisonCount: "在押 {{n}} 人",
			guildCount: "{{n}} / {{total}} 项建设",
			buildingCount: "{{n}} 座建筑",
			level: "第 {{n}} 层",
			vp: "分",
			taxCoins: "税银 {{n}} 枚",
			debtCount: "债务 {{n}} 笔",
			workerCount: "工人 {{n}} 人",
			capturedCount: "俘虏 {{n}} 人",
			emptyMarket: "学徒牌已用尽",
			hintLocation: "前往{{name}}。",
			hintCard: "选择{{name}}。",
			hintAction: "完成当前选择。",
			errAction: "当前不能执行这项行动，请重新选择。",
			unused: "未建造",
			you: "你",
			free: "免费",
			rewardDeck: "奖励牌 {{n}} 张",
			buildingDeck: "建筑牌 {{n}} 张",
			resetCount: "黑市已清查 {{n}} 次",
			automaScheme: "对手谋略",
			b0: "木匠小屋",
			b0Text: "终局时，每名具有木工技能的学徒额外获得 1 分。",
			b1: "教堂",
			b1Text: "立即获得 1 点美德，并销毁一笔未偿债务。",
			b2: "酒馆",
			b2Text: "立即免费雇佣一名公开的学徒。",
			b3: "伐木营地",
			b3Text: "立即获得 4 份木材。",
			b4: "贸易站",
			b4Text: "终局时，每拥有 4 份木材、石料和黏土的任意组合，获得 1 点美德。",
			b5: "藏身处",
			b5Text: "立即失去 2 点美德，并释放自己的全部在押工人。",
			b6: "国库",
			b6Text: "立即选择获得 1 份黄金或 3 枚银币。",
			b7: "黏土市场",
			b7Text: "终局时，黏土数量独占第一则额外获得 2 分。",
			b8: "绘图室",
			b8Text: "立即抽取两张建筑牌。",
			b9: "盗贼巢穴",
			b9Text: "立即失去 2 点美德，获得 4 枚银币。",
			b10: "瞭望塔",
			b10Text: "立即失去 1 点美德；所有至少有三名工人在押的玩家各失去 1 点美德。",
			b11: "礼拜堂",
			b11Text: "立即获得 1 点美德。终局时，大教堂进度独占第一则获得 2 点美德。",
			b12: "宫殿",
			b12Text: "立即按当前美德，每 4 点获得 1 份黄金。",
			b13: "军械库",
			b13Text: "立即免费抓捕一组工人。",
			b14: "蓄水池",
			b14Text: "终局时，每两笔已偿债务获得 1 点美德。",
			b15: "木材市场",
			b15Text: "终局时，木材数量独占第一则额外获得 2 分。",
			b16: "要塞",
			b16Text: "立即失去 2 点美德，并免费从一个或两个地点抓捕至多两组工人。",
			b17: "赌徒巢穴",
			b17Text: "立即失去 2 点美德。终局时，每笔未偿债务额外扣除 1 分。",
			b18: "地牢",
			b18Text: "立即失去 1 点美德。终局时再失去 2 点美德，可在其他终局美德效果之前或之后结算。",
			b19: "工厂",
			b19Text: "立即获得 2 份大理石。",
			b20: "尖塔",
			b20Text: "立即获得 1 点美德。终局时，大教堂进度独占第一则额外获得 2 分。",
			b21: "图书馆",
			b21Text: "立即可以弃置一张建筑牌，获得 2 份黄金。",
			b22: "兵营",
			b22Text: "立即赎回自己的全部被俘工人，或免费抓捕一组工人。",
			b23: "水井",
			b23Text: "立即获得 4 份黏土。",
			b24: "引水渠",
			b24Text: "终局时，每座自己建造的建筑额外获得 1 分，包括本建筑。",
			b25: "城堡",
			b25Text: "终局时，每两份黄金获得 1 点美德。",
			b26: "灯塔",
			b26Text: "终局时，每 4 点美德额外获得 1 分。",
			b27: "银币市场",
			b27Text: "终局时，银币数量独占第一则额外获得 2 分。",
			b28: "堡楼",
			b28Text: "立即失去 2 点美德。终局时，每三名仍被自己扣押的工人额外获得 1 分。",
			b29: "喷泉",
			b29Text: "立即获得 1 点美德。终局时，每笔未偿债务少扣 1 分。",
			b30: "博彩屋",
			b30Text: "立即失去 1 点美德，并获得一笔未偿债务。",
			b31: "放债人",
			b31Text: "立即失去 1 点美德。终局时，每笔已偿债务额外获得 1 分。",
			b32: "纪念碑",
			b32Text: "立即获得 1 点美德，然后所有玩家，包括自己，各获得 1 点美德。",
			b33: "石料市场",
			b33Text: "终局时，石料数量独占第一则额外获得 2 分。",
			b34: "天文台",
			b34Text: "终局时，每两份大理石获得 1 点美德。",
			b35: "瓦匠小屋",
			b35Text: "终局时，每名具有铺瓦技能的学徒额外获得 1 分。",
			b36: "石匠小屋",
			b36Text: "终局时，每名具有石工技能的学徒额外获得 1 分。",
			b37: "铁匠铺",
			b37Text: "立即获得 4 份石料。",
			b38: "黏土坑",
			b38Text: "立即选择获得 1 份黄金或 1 份大理石。",
			b39: "大学",
			b39Text: "立即获得 1 点美德。终局时，没有未偿债务则额外获得 2 分。",
			aPatron: "赞助人",
			aSwindler: "骗子",
			aTrader: "交易商",
			aAcolyte: "辅祭",
			aMerchant: "商人",
			aStonecutter: "采石匠",
			aWoodcutter: "伐木工",
			aMiner: "矿工",
			aPickpocket: "扒手",
			aDebtCollector: "收债人",
			aLabourer: "劳工",
			aJeweller: "珠宝匠",
			aConspirator: "密谋者",
			aSquire: "侍从",
			aTrickster: "欺诈师",
			aThief: "窃贼",
			aIllusionist: "幻术师",
			aGatekeeper: "守门人",
			aTrade: "在国王仓库，每次行动可以进行本牌所示的交易。",
			aGather: "前往{{location}}采集时，额外获得所示资源。",
			aPaid: "每偿还一笔债务，额外获得所示资源。",
			aCathedral: "每次推进大教堂，额外获得所示奖励。",
			aMarket: "每次使用黑市，额外获得所示资源。",
			aCaptureDiscount: "每次市镇中心行动的非税费用合计减少 1 枚银币。",
			aTaxDiscount: "每次盗取税银时，少失去 1 点美德。",
			aMarketDiscount: "每次黑市行动少支付 1 枚银币。",
			aMarketVirtue: "使用黑市时不失去美德。",
			aTax: "每次盗取税银，额外获得 1 份黄金。",
			aReset: "每次黑市清查时，若没有工人在押，获得所示奖励。",
			aRelease2: "每次黑市清查时，可以释放自己的至多两名在押工人。",
			aSkills: "这名学徒同时具备三种技能。",
			drawOne: "抽取一张建筑牌",
			virtueTwo: "获得两点美德",
			virtueChange: "雇佣或建造时，美德变化 {{n}} 点。",
			roleStandard: "没有额外能力。",
			roleAda: "开局有 11 点美德、1 份黄金和一张额外建筑牌，没有银币。所有行动少缴纳 1 枚税银。",
			roleFrederick: "开局有 4 枚银币、7 点美德和 1 份石料。推进大教堂无需弃置建筑牌。",
			roleCaroline: "开局有 10 枚银币、3 点美德、一笔债务和 1 份大理石，八名工人在押。每次使用黑市时额外抽取一张建筑牌。",
			roleRudolf: "开局有 3 枚银币、9 点美德和 1 份木材。在工坊雇佣学徒少付 1 枚非税银币，学徒上限为六名。",
			roleTherese: "开局有 5 枚银币、5 点美德和一张额外建筑牌，四名工人在押。黄金与大理石可以互相替代。",
			roleConstantine: "按照谋略牌行动，免付通常建造费用。每名行会工人计 1 分。",
			roleHelena: "按照谋略牌行动，免付通常建造费用。每名行会工人计 3 分。",
			rules: "游戏目标：\n你们是九世纪西国的皇家建筑师。通过建造建筑、推进大教堂和保持美德来获得分数。游戏结束时总分最高者获胜；平分时依次比较美德和剩余银币，仍相同则共享胜利。\n准备：\n· 每人获得二十名工人，并从 7 点美德开始。随机起始玩家获得 3 枚银币，后续玩家依次多获得 1 枚。\n· 每人获得四张建筑牌。所有人各保留一张，其余传给左手玩家。重复选择三轮，最后一张放回牌堆底；手牌始终保密。\n· 展示两行、每行四张学徒牌；税务所放入 4 枚银币。奖励牌数量为玩家数的两倍再加一张。\n回合与工人：\n轮到你时，将供应区的一名工人放入一个地点，执行该地点的行动。通常，同一地点自己的工人越多，行动越强；其他人的工人不影响你的行动强度。若回合开始时没有可用工人，整个回合只能从普通地点收回自己的一名工人；不能从行会、黑市、监狱或其他玩家的扣押区收回。\n· 森林每名己方工人获得 1 份木材；采石场每名己方工人获得 1 份石料。\n· 矿场选择获得己方工人数加一份黏土，或每两名己方工人获得 1 份黄金。不能同时选择两种资源。\n· 银匠铺获得己方工人数加一枚银币。\n· 国王仓库每名己方工人提供一次交易。每次可将任意两份木材、石料或黏土换为 1 点美德，或将任意三份木材、石料换为 1 份大理石。相关学徒提供额外交易选项。\n· 工坊可以雇佣一名学徒，或抽取建筑牌。雇佣基础费用为 4 枚银币，其中 2 枚为税。己方工人数决定能选择的列数；每多跨越一列，必须从该行最左边开始，在一张被跳过的学徒上放置 1 枚银币。雇佣时一并获得该牌上的银币，随后该行向左补齐。每人最多五名学徒，可以在自己的行动中解雇学徒。选择建筑图纸时，抽取一张牌，并且每两名己方工人额外抽取一张。回合结束时最多保留六张建筑手牌，超出的牌自行选择，放回牌堆底。\n抓捕、监狱与税收：\n· 市镇中心每名己方工人可以抓捕一个普通地点中的一组同色工人，每组支付 1 枚银币，第一次抓捕的费用为税。二至三人及单人对局最多涉及两个地点，四至五人对局只能涉及一个地点。可以抓捕包括新放工人在内的己方工人，这些工人直接回到自己的供应区；其他人的工人则留在自己的扣押区。不能抓捕行会、黑市、监狱或扣押区的工人。\n· 前往税务所可以拿走其中全部银币，并失去 2 点美德；没有税银时不能前往。\n卫所每名己方工人提供一次行动。你可以按任意顺序重复选择以下四种行动：\n· 将自己扣押的全部工人送入监狱，每送入一名工人，获得 1 枚银币。\n· 释放自己的全部在押工人，让他们回到自己的供应区。\n· 支付 5 枚银币，其中 2 枚为税，赎回自己全部被其他玩家扣押的工人，并放回自己的供应区。你也可以改为承担一笔债务并失去 1 点美德。至少有一名工人被其他玩家扣押时，才可以选择此行动。\n· 支付 6 枚银币，其中 3 枚为税，偿还一笔债务。保留已偿债务牌，并获得 1 点美德。\n红色银币为税，支付到税务所，其余银币回到供应区。美德为 2 或 3 点时，每笔费用少缴纳 1 枚税银；美德为 0 或 1 点时少缴纳 2 枚税银。\n建造与美德：\n· 前往行会大厅后，选择建造一张手牌，或推进大教堂。放入行会的工人永久留在那里。\n· 建造建筑时支付牌上的全部资源，并拥有每种所需技能的至少一名学徒。学徒不会消耗。执行建筑的即时美德和能力；标为终局的能力在游戏结束时结算。\n· 大教堂每次推进一层，并弃置一张建筑手牌。五层费用依次为：1 份黄金；任意四份木材和石料；1 份大理石；任意八份木材和石料；2 份黄金和 2 份大理石。各层容量从低到高为三人、两人、两人、两人、一人。美德不高于 4 点时不能推进。每次推进获得一张奖励牌；奖励用尽时改为获得 1 点美德。五层终局分依次为 2、4、7、12、20 分。\n· 美德最高为 14 点；超出的每点美德可以销毁一笔未偿债务，销毁不视为偿还。美德最低为 0 点；每少于 0 的一点，获得一笔未偿债务。美德达到 10 点时不能进入黑市。\n黑市与清查：\n黑市三个位置各只能容纳一名工人。支付费用并失去 1 点美德后，小黑市花费 1 枚银币，获得展示的小批资源；中黑市花费 2 枚银币，免费雇佣任意公开学徒，或抽五张建筑牌保留一张；大黑市花费 3 枚银币，获得展示的大批资源。\n当三个黑市位置都被占据，或行会第三、第四行的首个位置被占据时，在当前行动完成后依次清查：\n· 将全部黑市工人送入监狱。\n· 将小黑市顶牌翻到大黑市上，更新两边资源。小牌堆用尽时，将可回收的黑市牌重新洗混。\n· 玩家按自己选择的顺序结算清查类学徒能力。\n· 至少有三名工人在押的玩家各失去 1 点美德。\n· 在押工人最多的玩家各获得一笔未偿债务；并列者全部获得，没有人在押时不获得债务。\n游戏结束与计分：\n二至五人分别完成 12、16、20、24 项行会建设后触发结束。触发者完成回合后，每个人，包括触发者，再进行最后一个回合；仍可以继续在行会建设。先自行安排各建筑的终局效果，再合计：\n· 建筑印刷分和附加分，以及大教堂分数。\n· 美德 0 至 14 点分别计为 −9、−8、−7、−5、−3、−1、0、0、0、0、1、2、3、5、7 分。\n· 每笔未偿债务扣除 2 分，除非建筑修改该值。\n· 每份黄金和大理石各获得 1 分，每持有十枚银币，计为 1 分；每两名在押工人扣除 1 分。\n角色与单人对局：\n角色能力选项随机分配基础版五名角色，改变初始资源和能力；由初始美德最高者先行动。角色详情可点击自己的角色查看。基础版的完整建筑与学徒效果可以在牌面详情中查看。\n单人对局自动加入君士坦丁或海伦娜，使用二人行会与五张奖励牌。移除四张资源市场建筑，自己从五张牌中保留三张，之后总是先行动。对手通过二十张起始谋略牌行动，并逐步加入十张未来谋略牌；不使用银币、普通资源、学徒和建筑，建造大教堂无需支付费用，其余行动按谋略牌处理。对手可以不受美德限制进入黑市和推进大教堂。对手用完工人时，收回除行会和黑市以外的所有工人，并将弃置谋略牌洗回抽牌堆。本人的计分不变；对手计算大教堂、美德、大理石、债务和监狱分数，君士坦丁每名行会工人额外获得 1 分，海伦娜每名行会工人额外获得 3 分。"
		},
		en: {
			name: "Architects of the West Kingdom",
			desc: "Gather workers and hire apprentices to build a kingdom while balancing virtue and ambition.",
			forest: "Forest",
			quarry: "Quarry",
			mines: "Mines",
			silversmith: "Silversmith",
			storehouse: "King’s Storehouse",
			workshop: "Workshop",
			town: "Town Centre",
			tax: "Tax Stand",
			guard: "Guardhouse",
			guild: "Guildhall",
			small: "Small Market",
			middle: "Middle Market",
			large: "Large Market",
			wood: "Wood",
			stone: "Stone",
			clay: "Clay",
			gold: "Gold",
			marble: "Marble",
			silver: "Silver",
			carpentry: "Carpentry",
			tiling: "Tiling",
			masonry: "Masonry",
			virtue: "Virtue",
			debt: "Unpaid debts",
			paid: "Paid debts",
			prison: "Prison",
			workers: "Workers",
			captives: "Captured workers",
			cathedral: "Cathedral",
			cathedralAny: "Any",
			cathedralCost1: "1 Gold",
			cathedralCost2: "4 Wood and Stone in any combination",
			cathedralCost3: "1 Marble",
			cathedralCost4: "8 Wood and Stone in any combination",
			cathedralCost5: "2 Gold and 2 Marble",
			buildings: "Buildings",
			apprentices: "Apprentices",
			hand: "Hand",
			standard: "Standard",
			ada: "Ada",
			frederick: "Frederick",
			caroline: "Caroline",
			rudolf: "Rudolf",
			therese: "Therese",
			constantine: "Constantine",
			helena: "Helena",
			optVariable: "Player boards",
			optStandard: "Standard",
			optAsymmetric: "Variable",
			optSolo: "Official solo opponent",
			optSoloHint: "A solo game adds a Byzantine architect automatically. Multiplayer games use the standard rules.",
			round: "Turn {{n}}",
			turnPrompt: "Choose where to place a worker.",
			wait: "Waiting for {{name}}.",
			draftPrompt: "Choose a building card.",
			draftWaiting: "Building selected. Waiting for the others.",
			resolving: "Resolving.",
			finalRound: "{{n}} final turns",
			draftRound: "Building draft {{n}} / 3",
			remaining: "{{n}} actions remaining",
			kingdom: "Kingdom",
			estate: "My estate",
			inspect: "Inspect {{name}}",
			close: "Close",
			back: "Back to the board",
			choose: "Choose",
			confirm: "Confirm action",
			finish: "Finish this action",
			recover: "Recover a worker",
			place: "Place a worker",
			draft: "Keep this building",
			build: "Construct",
			cathedralDiscard: "Choose one building card to discard for the Cathedral advancement.",
			cathedralAction: "Advance the Cathedral",
			hire: "Hire apprentice",
			plans: "Draw building plans",
			marketPlans: "Draw five buildings and keep one",
			pick: "Keep this card",
			gather: "Gain resources",
			trade: "Trade resources",
			tradeVirtue: "Donate resources for virtue",
			capture: "Capture this group",
			sell: "Send all captured workers to Prison",
			release: "Release all your imprisoned workers",
			ransom: "Pay to recover your captured workers",
			ransomDebt: "Take a debt to recover your captured workers",
			payDebt: "Pay off a debt",
			ransomFree: "Recover all your captured workers",
			drop: "Dismiss apprentice",
			discard: "Discard building",
			library: "Discard this building for two Gold",
			resetSkill: "Resolve apprentice ability",
			skipSkill: "Keep workers in Prison",
			finalEffect: "Resolve building effect",
			pMines: "Choose which resource to mine.",
			pWorkshop: "Choose an apprentice or draw building plans.",
			pHire: "Choose an apprentice to hire.",
			pMiddle: "Choose an apprentice or examine five building plans.",
			pPick: "Keep one building; return the others to the bottom of the deck.",
			pGuild: "Construct a building or advance the Cathedral.",
			pStore: "Choose a resource trade.",
			pCapture: "Choose a group of workers at a location.",
			pGuard: "Choose a Guardhouse action.",
			pDiscard: "Discard buildings until you have at most six cards.",
			pTreasury: "Choose a Treasury reward.",
			pClaypit: "Choose a Clay Pit reward.",
			pLibrary: "You may discard a building card for two Gold.",
			pBarracks: "Recover your captured workers or capture one group.",
			pReset: "Choose the order of your apprentice abilities.",
			pFinal: "Choose the order of your end-game building effects.",
			cost: "Cost",
			gain: "Gain",
			points: "{{n}} VP",
			ability: "Ability",
			scoreTotal: "Total",
			scoreBuildings: "Buildings and bonuses",
			scoreCathedral: "Cathedral",
			scoreVirtue: "Virtue",
			scoreDebts: "Debts",
			scoreResources: "Gold and Marble",
			scoreSilver: "Silver",
			scorePrison: "Imprisoned workers",
			resultTitle: "The kingdom is complete",
			winner: "Winner",
			reviewBoard: "View the kingdom",
			showResult: "Show scoring",
			resultReadOnly: "Final kingdom",
			noCards: "No cards",
			prisonCount: "{{n}} in Prison",
			guildCount: "{{n}} / {{total}} constructions",
			buildingCount: "{{n}} buildings",
			level: "Level {{n}}",
			vp: "VP",
			taxCoins: "Tax: {{n}} Silver",
			debtCount: "{{n}} debts",
			workerCount: "{{n}} workers",
			capturedCount: "{{n}} captured workers",
			emptyMarket: "No apprentice available",
			hintLocation: "Visit {{name}}.",
			hintCard: "Choose {{name}}.",
			hintAction: "Resolve the current choice.",
			errAction: "That action is no longer available. Please choose again.",
			unused: "Unbuilt",
			you: "You",
			free: "Free",
			rewardDeck: "{{n}} reward cards",
			buildingDeck: "{{n}} building cards",
			resetCount: "{{n}} Black Market resets",
			automaScheme: "Opponent scheme",
			b0: "Carpenter’s Hut",
			b0Text: "At game end, score 1 extra VP per apprentice with Carpentry.",
			b1: "Church",
			b1Text: "Immediately gain 1 Virtue and destroy an unpaid debt.",
			b2: "Tavern",
			b2Text: "Immediately hire any face-up apprentice for free.",
			b3: "Lumber Camp",
			b3Text: "Immediately gain 4 Wood.",
			b4: "Trading Post",
			b4Text: "At game end, gain 1 Virtue per four Wood, Stone and Clay in any combination.",
			b5: "Hideout",
			b5Text: "Immediately lose 2 Virtue and release all your workers from Prison.",
			b6: "Treasury",
			b6Text: "Immediately gain either 1 Gold or 3 Silver.",
			b7: "Clay Market",
			b7Text: "At game end, score 2 extra VP if you have strictly the most Clay.",
			b8: "Drafting Room",
			b8Text: "Immediately draw two building cards.",
			b9: "Thieves’ Den",
			b9Text: "Immediately lose 2 Virtue and gain 4 Silver.",
			b10: "Watchtower",
			b10Text: "Immediately lose 1 Virtue. Every player with at least three imprisoned workers loses 1 Virtue.",
			b11: "Chapel",
			b11Text: "Immediately gain 1 Virtue. At game end, gain 2 Virtue if you are strictly highest in the Cathedral.",
			b12: "Palace",
			b12Text: "Immediately gain 1 Gold per four Virtue you currently have.",
			b13: "Armoury",
			b13Text: "Immediately capture one group of workers for free.",
			b14: "Reservoir",
			b14Text: "At game end, gain 1 Virtue per two paid debts.",
			b15: "Wood Market",
			b15Text: "At game end, score 2 extra VP if you have strictly the most Wood.",
			b16: "Fortress",
			b16Text: "Immediately lose 2 Virtue and capture up to two groups from one or two locations for free.",
			b17: "Gambler’s Den",
			b17Text: "Immediately lose 2 Virtue. Each unpaid debt costs 1 extra VP at game end.",
			b18: "Dungeon",
			b18Text: "Immediately lose 1 Virtue. At game end, lose 2 more Virtue, before or after your other end-game Virtue effects.",
			b19: "Factory",
			b19Text: "Immediately gain 2 Marble.",
			b20: "Steeple",
			b20Text: "Immediately gain 1 Virtue. At game end, score 2 extra VP if strictly highest in the Cathedral.",
			b21: "Library",
			b21Text: "You may immediately discard one building card to gain 2 Gold.",
			b22: "Barracks",
			b22Text: "Immediately recover all your captured workers, or capture one group for free.",
			b23: "Well",
			b23Text: "Immediately gain 4 Clay.",
			b24: "Aquaduct",
			b24Text: "At game end, score 1 extra VP per constructed building, including this one.",
			b25: "Castle",
			b25Text: "At game end, gain 1 Virtue per two Gold.",
			b26: "Lighthouse",
			b26Text: "At game end, score 1 extra VP per four Virtue.",
			b27: "Silver Market",
			b27Text: "At game end, score 2 extra VP if you have strictly the most Silver.",
			b28: "Keep",
			b28Text: "Immediately lose 2 Virtue. At game end, score 1 extra VP per three workers still captured on your board.",
			b29: "Fountain",
			b29Text: "Immediately gain 1 Virtue. Each unpaid debt costs 1 fewer VP at game end.",
			b30: "Betting House",
			b30Text: "Immediately lose 1 Virtue and take an unpaid debt.",
			b31: "Moneylender",
			b31Text: "Immediately lose 1 Virtue. At game end, score 1 extra VP per paid debt.",
			b32: "Monument",
			b32Text: "Immediately gain 1 Virtue. Then every player, including you, gains 1 Virtue.",
			b33: "Stone Market",
			b33Text: "At game end, score 2 extra VP if you have strictly the most Stone.",
			b34: "Observatory",
			b34Text: "At game end, gain 1 Virtue per two Marble.",
			b35: "Tiler’s Hut",
			b35Text: "At game end, score 1 extra VP per apprentice with Tiling.",
			b36: "Mason’s Hut",
			b36Text: "At game end, score 1 extra VP per apprentice with Masonry.",
			b37: "Smithy",
			b37Text: "Immediately gain 4 Stone.",
			b38: "Clay Pit",
			b38Text: "Immediately gain either 1 Gold or 1 Marble.",
			b39: "University",
			b39Text: "Immediately gain 1 Virtue. At game end, score 2 extra VP if you have no unpaid debts.",
			aPatron: "Patron",
			aSwindler: "Swindler",
			aTrader: "Trader",
			aAcolyte: "Acolyte",
			aMerchant: "Merchant",
			aStonecutter: "Stonecutter",
			aWoodcutter: "Woodcutter",
			aMiner: "Miner",
			aPickpocket: "Pickpocket",
			aDebtCollector: "Debt Collector",
			aLabourer: "Labourer",
			aJeweller: "Jeweller",
			aConspirator: "Conspirator",
			aSquire: "Squire",
			aTrickster: "Trickster",
			aThief: "Thief",
			aIllusionist: "Illusionist",
			aGatekeeper: "Gatekeeper",
			aTrade: "At the King’s Storehouse, spend one action to make the trade shown on this card.",
			aGather: "When gathering at {{location}}, also gain the resources shown.",
			aPaid: "Whenever you pay off a debt, also gain the resources shown.",
			aCathedral: "Whenever you advance the Cathedral, also gain the reward shown.",
			aMarket: "Whenever you use the Black Market, also gain the resources shown.",
			aCaptureDiscount: "Reduce the total non-Tax cost of each Town Centre visit by 1 Silver.",
			aTaxDiscount: "Lose 1 fewer Virtue when stealing from the Tax Stand.",
			aMarketDiscount: "Pay 1 fewer Silver when visiting the Black Market.",
			aMarketVirtue: "Do not lose Virtue when visiting the Black Market.",
			aTax: "Gain 1 Gold whenever you steal from the Tax Stand.",
			aReset: "At each Black Market Reset, gain the reward shown if you have no workers in Prison.",
			aRelease2: "At each Black Market Reset, you may release up to two of your imprisoned workers.",
			aSkills: "This apprentice has all three skills.",
			drawOne: "Draw one building card",
			virtueTwo: "Gain two Virtue",
			virtueChange: "On hiring or construction, change Virtue by {{n}}.",
			roleStandard: "No additional ability.",
			roleAda: "Start with 11 Virtue, 1 Gold and an extra building card, but no Silver. Ignore 1 Tax on every action.",
			roleFrederick: "Start with 4 Silver, 7 Virtue and 1 Stone. Advancing the Cathedral does not require discarding a building.",
			roleCaroline: "Start with 10 Silver, 3 Virtue, a debt, 1 Marble and eight imprisoned workers. Draw a building whenever you visit the Black Market.",
			roleRudolf: "Start with 3 Silver, 9 Virtue and 1 Wood. Pay 1 fewer non-Tax Silver to hire at the Workshop. You may have six apprentices.",
			roleTherese: "Start with 5 Silver, 5 Virtue, an extra building card and four imprisoned workers. Treat Gold and Marble as interchangeable.",
			roleConstantine: "Follows scheme cards and ignores normal construction costs. Each Guildhall worker scores 1 VP.",
			roleHelena: "Follows scheme cards and ignores normal construction costs. Each Guildhall worker scores 3 VP.",
			rules: "Objective:\nAs royal architects in the ninth century, construct buildings, advance the Cathedral and manage your Virtue. The highest final score wins. Break ties by higher Virtue, then remaining Silver; otherwise share victory.\nSetup:\n· Each player starts with twenty workers and 7 Virtue. Randomly choose a starting player, who receives 3 Silver; each subsequent player receives one more Silver.\n· Deal four buildings to each player. Everyone keeps one and passes the rest left. Repeat for three selections, returning the last card to the bottom of the deck. Building hands remain private.\n· Reveal eight apprentices in two rows of four. Place 4 Silver in the Tax Stand. Use two reward cards per player, plus one.\nTurns and workers:\nOn your turn, place one available worker at a location and take its action. Your own workers at that location determine its strength; opponents’ workers do not. If you start with no available workers, spend the entire turn recovering one worker from a normal location. You cannot recover from the Guildhall, Black Market, Prison or an opponent’s board this way.\n· The Forest grants 1 Wood per own worker. The Quarry grants 1 Stone per own worker.\n· At the Mines, gain Clay equal to your worker count plus one, or 1 Gold per two workers. You cannot split the action between both resources.\n· The Silversmith grants Silver equal to your worker count plus one.\n· At the King’s Storehouse, take one trade per own worker. Trade any two Wood, Stone or Clay for 1 Virtue, or any three Wood or Stone for 1 Marble. Apprentices can provide additional trades.\n· At the Workshop, hire one apprentice or draw building plans. Hiring costs 4 Silver, including 2 Tax. Your worker count determines how many columns you can reach. To reach one additional column, place 1 Silver on a skipped apprentice, beginning at the left of its row. Collect any Silver on the hired card, then slide that row left and refill it. You may have five apprentices and can dismiss them during your actions. Drawing plans grants one building card, plus another per two own workers. At the end of your turn, choose buildings to discard to the bottom of the deck until you hold at most six.\nCaptures, Prison and Tax:\n· At the Town Centre, each own worker allows you to capture one group of a single colour from a normal location for 1 Silver. The first capture is taxed. In solo and two- or three-player games, use up to two locations; with four or five players, use only one. You may capture your own workers, including the one just placed, returning them to your supply. Opponents’ workers stay captured on your board. Never capture from the Guildhall, Black Market, Prison or another player’s board.\n· At the Tax Stand, take all its Silver and lose 2 Virtue. You cannot visit when it is empty.\nAt the Guardhouse, take one action per own worker. You may repeat the following four actions in any order:\n· Send all workers you have captured to Prison. Gain 1 Silver for each worker sent.\n· Release all your imprisoned workers to your supply.\n· Pay 5 Silver, including 2 Tax, to return all your workers captured by opponents to your supply. Instead of paying Silver, you may take one debt and lose 1 Virtue. You may choose this action only if an opponent holds at least one of your workers.\n· Pay 6 Silver, including 3 Tax, to pay one debt. Retain the paid debt card and gain 1 Virtue.\nRed coins are Tax and go to the Tax Stand. Other Silver returns to the supply. At 2 or 3 Virtue, ignore 1 Tax per cost. At 0 or 1 Virtue, ignore 2 Tax.\nConstruction and Virtue:\n· At the Guildhall, construct a building from your hand or advance the Cathedral. Workers placed here remain for the rest of the game.\n· Pay the building’s resources and have at least one apprentice matching each required skill. Apprentices are not spent. Resolve immediate Virtue and effects now; end-game abilities resolve before final scoring.\n· Advancing the Cathedral requires discarding one building card and paying for the next level. The five costs are: 1 Gold; any four Wood and Stone; 1 Marble; any eight Wood and Stone; 2 Gold and 2 Marble. Level capacities from bottom to top are three, two, two, two and one players. You need at least 5 Virtue. Gain a reward card on each advancement, or 1 Virtue if none remain. Levels score 2, 4, 7, 12 and 20 VP.\n· Virtue ranges from 0 to 14. Each Virtue gained above 14 may destroy an unpaid debt; destroying is not paying. Each Virtue lost below 0 adds an unpaid debt. At 10 or more Virtue, you cannot visit the Black Market.\nBlack Market and resets:\nEach of the three Black Market spaces holds one worker. Lose 1 Virtue and pay the indicated cost: the Small Market costs 1 Silver for the displayed small resources; the Middle Market costs 2 Silver to hire any face-up apprentice for free, or draw five buildings and keep one; the Large Market costs 3 Silver for its displayed resources.\nAfter all three spaces become occupied, or a worker occupies the first space of the third or fourth Guildhall row, finish the current action and resolve a Black Market Reset:\n· Send every Black Market worker to Prison.\n· Flip the top Small Market card onto the Large Market to update both offers. Reshuffle recyclable market cards when needed.\n· Resolve each player’s reset apprentices in their chosen order.\n· Every player with at least three imprisoned workers loses 1 Virtue.\n· Every player tied for the most imprisoned workers takes one debt. If no workers are imprisoned, nobody takes a debt.\nEnd and scoring:\nThe Guildhall holds 12, 16, 20 or 24 constructions with two, three, four or five players. When it fills, finish the current turn, then everyone, including the triggering player, takes one final turn. More Guildhall constructions are still allowed. Resolve end-game building effects in your chosen order, then score:\n· Printed building VP and bonuses, plus Cathedral VP.\n· Virtue levels 0 through 14 score −9, −8, −7, −5, −3, −1, 0, 0, 0, 0, 1, 2, 3, 5 and 7 VP.\n· Lose 2 VP per unpaid debt, unless a building changes this penalty.\n· Score 1 VP per Gold and per Marble, 1 VP per ten Silver, and lose 1 VP per two imprisoned workers.\nVariable boards and solo:\nThe variable option randomly assigns the five base-game player boards, changing starting resources and abilities. The player with the highest initial Virtue starts. Inspect your role for its full ability. Building and apprentice details show their full effects.\nA solo game automatically adds Constantine or Helena, using the two-player Guildhall and five rewards. Remove the four resource-market buildings. Keep three of five starting buildings and always take the first turn. The opponent follows twenty starting schemes and gradually adds ten future schemes. It does not use Silver, normal resources, apprentices or buildings, and builds the Cathedral for free. Other actions follow its schemes. It can visit the Black Market and Cathedral regardless of Virtue. When it runs out of workers, it recovers all workers except those in the Guildhall and Black Market, and shuffles discarded schemes into its draw pile. Score yourself normally. The opponent scores Cathedral, Virtue, Marble, debts and Prison, plus 1 VP per Guildhall worker for Constantine, or 3 VP for Helena."
		}
	}
};
//#endregion
export { Ot as default };
