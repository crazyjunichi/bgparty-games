import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import t from "@bgparty/sdk/word-list";
import { z as n } from "zod";
import { useState as r } from "react";
import { useT as i } from "@bgparty/sdk/i18n";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as c } from "@bgparty/sdk/assets";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { AVATARS as u } from "@bgparty/sdk/avatars";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { OptionRadio as m, OptionSection as h } from "@bgparty/sdk/ui/game-options";
//#region src/games/codenamesduet/meta.ts
var g = {
	id: "codenamesduet",
	tier: "alpha",
	nameKey: "games.codenamesduet.name",
	descKey: "games.codenamesduet.desc",
	rulesKey: "games.codenamesduet.rules",
	icon: "🕵️",
	iconImg: "games/codenamesduet.webp",
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	mechanics: ["word-association", "deduction"],
	interactionTags: ["cooperative", "communication-limits"],
	accent: "#168943",
	hotseat: "cover",
	releasedAt: "2026-11-09T22:09:20+08:00",
	search: {
		py: "xing dong dai hao er chong zou codenames duet",
		init: "xddhecz"
	},
	rulesUrl: { en: "https://filemanager.czechgames.com/storage/files/codenames-duet/rules/codenames-duet-rules-en.pdf" }
}, _ = n.object({ tokens: n.union([
	n.literal(9),
	n.literal(10),
	n.literal(11)
]).default(9) }).prefault({}), v = n.enum([
	"agent",
	"bystander",
	"assassin"
]), y = n.int().min(0).max(24), b = n.discriminatedUnion("type", [
	n.object({
		type: n.literal("clue"),
		word: n.string().trim().min(1).max(24),
		count: n.int().min(0).max(9)
	}),
	n.object({
		type: n.literal("tap"),
		index: y
	}),
	n.object({ type: n.literal("stop") }),
	n.object({ type: n.literal("retire") }),
	n.object({ type: n.literal("penalty") })
]), x = n.object({
	by: n.string(),
	index: y,
	kind: v
}), S = n.object({
	by: n.string(),
	word: n.string(),
	count: n.int(),
	guesses: n.array(x),
	ended: n.enum([
		"open",
		"stop",
		"bystander",
		"done"
	]),
	penalty: n.boolean()
}), C = n.object({
	phase: n.enum([
		"clue",
		"guess",
		"sudden",
		"done"
	]),
	players: n.array(n.string()).length(2),
	words: n.array(n.string()).length(25),
	contacted: n.array(n.string().nullable()).length(25),
	bystanders: n.array(n.array(n.string())).length(25),
	giver: n.string().nullable(),
	clue: n.object({
		word: n.string(),
		count: n.int()
	}).nullable(),
	guessesThisTurn: n.int().nonnegative(),
	tokens: n.int().nonnegative(),
	initialTokens: n.int(),
	stoppedTurns: n.int().nonnegative(),
	mistakes: n.int().nonnegative(),
	penalties: n.int().nonnegative(),
	retired: n.array(n.string()),
	completed: n.array(n.string()),
	proposal: n.object({
		by: n.string(),
		index: y
	}).nullable(),
	history: n.array(S),
	suddenGuesses: n.array(x),
	usedSudden: n.boolean(),
	outcome: n.enum([
		"success",
		"assassin",
		"sudden-miss"
	]).nullable(),
	failedIndex: y.nullable(),
	finalKeys: n.array(n.array(v).length(25)).length(2).nullable()
}), w = n.object({ key: n.array(v).length(25) });
//#endregion
//#region src/games/codenamesduet/rules.ts
function T(t, n, r) {
	let i = [...t];
	for (let t = i.length - 1; t > 0; t--) {
		let a = e(n, r.value++, t + 1);
		[i[t], i[a]] = [i[a], i[t]];
	}
	return i;
}
function E(e, t) {
	return e.keys[t].some((t, n) => t === "agent" && e.contacted[n] === null);
}
function D(e, t) {
	return !e.retired.includes(t) && E(e, e.players.indexOf(t));
}
function O(e, t) {
	e.phase = "done", e.outcome = t, e.proposal = null, e.history.length && (e.history[e.history.length - 1].ended = "done");
}
function k(e) {
	e.completed = e.players.filter((t, n) => !E(e, n));
}
function A(e) {
	e.phase = "sudden", e.usedSudden = !0, e.giver = null, e.clue = null, e.proposal = null;
}
function j(e) {
	let t = e.giver;
	if (e.proposal = null, e.clue = null, e.guessesThisTurn = 0, e.tokens === 0 || !e.players.some((t) => D(e, t))) {
		A(e);
		return;
	}
	let n = e.players.find((e) => e !== t);
	e.giver = D(e, n) ? n : t, e.phase = "clue";
}
function M(e, n, r) {
	let i = { value: 0 }, a = T([...new Set(t)], r, i).slice(0, 25), o = [], s = (e, t, n) => {
		for (let r = 0; r < n; r++) o.push([e, t]);
	};
	s("agent", "agent", 3), s("agent", "bystander", 5), s("bystander", "agent", 5), s("agent", "assassin", 1), s("assassin", "agent", 1), s("assassin", "assassin", 1), s("assassin", "bystander", 1), s("bystander", "assassin", 1), s("bystander", "bystander", 7);
	let c = T(o, r, i);
	return { state: {
		players: [...n],
		words: a,
		keys: [c.map((e) => e[0]), c.map((e) => e[1])],
		phase: "clue",
		giver: null,
		clue: null,
		guessesThisTurn: 0,
		contacted: Array(25).fill(null),
		bystanders: Array.from({ length: 25 }, () => []),
		initialTokens: e.tokens,
		tokens: e.tokens,
		stoppedTurns: 0,
		mistakes: 0,
		penalties: 0,
		retired: [],
		completed: [],
		proposal: null,
		history: [],
		suddenGuesses: [],
		usedSudden: !1,
		outcome: null,
		failedIndex: null
	} };
}
function N(e, t, n) {
	let r = e.players.indexOf(n.by);
	if (r < 0 || e.phase === "done") return { code: "games.codenamesduet.errTurn" };
	if (t.type === "clue") {
		if (e.phase !== "clue" || e.giver !== null && e.giver !== n.by || !D(e, n.by)) return { code: "games.codenamesduet.errTurn" };
		let r = t.word.trim(), i = r.toLocaleLowerCase("en");
		if (/\s/u.test(r) || e.words.some((t, n) => !e.contacted[n] && (t.toLocaleLowerCase("en").includes(i) || i.includes(t.toLocaleLowerCase("en"))))) return { code: "games.codenamesduet.errClue" };
		let a = structuredClone(e);
		return a.giver = n.by, a.clue = {
			word: r,
			count: t.count
		}, a.phase = "guess", a.guessesThisTurn = 0, a.history.push({
			by: n.by,
			word: r,
			count: t.count,
			guesses: [],
			ended: "open",
			penalty: !1
		}), { state: a };
	}
	if (t.type === "retire") {
		if (e.phase !== "clue" || e.giver !== null && e.giver !== n.by || !D(e, n.by)) return { code: "games.codenamesduet.errTurn" };
		let t = structuredClone(e);
		t.retired.push(n.by);
		let i = t.players[1 - r];
		return D(t, i) ? t.giver = i : A(t), { state: t };
	}
	if (t.type === "penalty") {
		let t = e.history[e.history.length - 1];
		if (e.phase !== "guess" || !t || t.penalty || e.tokens === 0) return { code: "games.codenamesduet.errPenalty" };
		let n = structuredClone(e);
		return n.tokens--, n.penalties++, n.history[n.history.length - 1].penalty = !0, { state: n };
	}
	if (!(e.phase === "guess" && e.giver !== n.by || e.phase === "sudden" && E(e, 1 - r))) return { code: "games.codenamesduet.errTurn" };
	if (t.type === "stop") {
		if (e.phase !== "guess" || e.guessesThisTurn === 0) return { code: "games.codenamesduet.errStop" };
		let t = structuredClone(e);
		return t.tokens > 0 && (t.tokens--, t.stoppedTurns++), t.history[t.history.length - 1].ended = "stop", j(t), { state: t };
	}
	if (e.contacted[t.index] !== null || e.bystanders[t.index].includes(n.by)) return { code: "games.codenamesduet.errCard" };
	let i = structuredClone(e);
	if (i.proposal?.by !== n.by || i.proposal.index !== t.index) return i.proposal = {
		by: n.by,
		index: t.index
	}, { state: i };
	i.proposal = null;
	let a = i.keys[1 - r][t.index], o = {
		by: n.by,
		index: t.index,
		kind: a
	};
	return i.phase === "sudden" ? i.suddenGuesses.push(o) : i.history[i.history.length - 1].guesses.push(o), i.guessesThisTurn++, a === "agent" ? (i.contacted[t.index] = n.by, k(i), i.contacted.filter(Boolean).length === 15 && O(i, "success")) : a === "assassin" ? (i.failedIndex = t.index, O(i, "assassin")) : (i.bystanders[t.index].push(n.by), i.mistakes++, i.phase === "sudden" ? (i.failedIndex = t.index, O(i, "sudden-miss")) : (i.tokens > 0 && i.tokens--, i.history[i.history.length - 1].ended = "bystander", j(i))), {
		state: i,
		fx: [{
			kind: "duet-reveal",
			rid: n.by,
			data: {
				index: t.index,
				cell: a
			}
		}]
	};
}
var P = {
	meta: g,
	saveCompatibility: { version: "1" },
	schemas: {
		action: b,
		publicView: C,
		privateView: w,
		config: _
	},
	setup: M,
	reduce: N,
	viewFor(e, t) {
		let { keys: n, ...r } = e, i = e.players.indexOf(t);
		return {
			public: {
				...r,
				finalKeys: e.phase === "done" ? n : null
			},
			private: i < 0 ? void 0 : { key: [...n[i]] }
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: e.outcome === "success" ? [...e.players] : [],
			ranking: [...e.players]
		} : { phase: e.phase };
	}
};
//#endregion
//#region src/games/codenamesduet/board.tsx
function F({ member: e, compact: t = !1 }) {
	let n = i(), r = o[(e?.colorIndex ?? 0) % o.length], a = n(r.nameKey);
	return /* @__PURE__ */ p("span", {
		className: `cnd-member${t ? " cnd-member-small" : ""}`,
		title: a,
		style: { "--cnd-member": r.hex },
		children: [/* @__PURE__ */ f("img", {
			src: u[(e?.avatar ?? 0) % u.length],
			alt: "",
			draggable: !1
		}), !t && /* @__PURE__ */ f("span", { children: a })]
	});
}
function I({ kind: e }) {
	let t = i();
	return /* @__PURE__ */ f(d, { children: t(e === "agent" ? "games.codenamesduet.agent" : e === "assassin" ? "games.codenamesduet.assassin" : "games.codenamesduet.bystander") });
}
function L({ word: e, kind: t, contacted: n = !1 }) {
	return /* @__PURE__ */ p("span", {
		className: "cnd-card-face",
		"data-kind": t,
		children: [
			(t === "agent" || t === "assassin") && /* @__PURE__ */ f("img", {
				className: "cnd-card-art",
				src: c(`games/codenamesduet/${t}.webp`),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ f("strong", {
				className: "cnd-word",
				children: e
			}),
			t && /* @__PURE__ */ p("span", {
				className: "cnd-card-kind",
				children: [n ? /* @__PURE__ */ f("span", {
					"aria-hidden": "true",
					children: "✓ "
				}) : null, /* @__PURE__ */ f(I, { kind: t })]
			})
		]
	});
}
function R({ pub: e, index: t, members: n, myRid: r, active: a, finalKey: s, onTap: c }) {
	let u = i(), { ref: d, hidden: m } = l(`duet-card:${t}`), h = !!e.contacted[t], g = e.bystanders[t].includes(r), _ = e.proposal?.index === t && e.proposal.by === r, v = h ? "agent" : e.failedIndex === t && e.outcome === "assassin" ? "assassin" : s?.[t], y = a && !h && !g, b = h ? u("games.codenamesduet.contacted") : _ ? u("games.codenamesduet.confirmCard") : v ? u(v === "agent" ? "games.codenamesduet.agent" : v === "assassin" ? "games.codenamesduet.assassin" : "games.codenamesduet.bystander") : e.words[t];
	return /* @__PURE__ */ p("button", {
		type: "button",
		ref: d,
		className: "cnd-card",
		"data-legal": y,
		"data-selected": _,
		"data-covered": h,
		"data-blocked": g,
		style: { visibility: m ? "hidden" : void 0 },
		disabled: !y,
		"aria-pressed": _,
		"aria-label": u("games.codenamesduet.cardLabel", {
			word: e.words[t],
			state: b
		}),
		onClick: () => c?.(t),
		children: [
			/* @__PURE__ */ f(L, {
				word: e.words[t],
				kind: v,
				contacted: h
			}),
			!h && /* @__PURE__ */ f("span", {
				className: "cnd-bystanders",
				children: e.bystanders[t].map((e) => {
					let t = n.find((t) => t.rid === e), r = o[(t?.colorIndex ?? 0) % o.length];
					return /* @__PURE__ */ f("span", {
						title: u("games.codenamesduet.blocked", { name: u(r.nameKey) }),
						"aria-label": u("games.codenamesduet.blocked", { name: u(r.nameKey) }),
						children: /* @__PURE__ */ f(F, {
							member: t,
							compact: !0
						})
					}, e);
				})
			}),
			_ && /* @__PURE__ */ f("span", {
				className: "cnd-confirm-label",
				children: u("games.codenamesduet.confirmCard")
			})
		]
	});
}
function z({ pub: e, members: t, myRid: n, active: r = !1, finalKey: i, onTap: a }) {
	return /* @__PURE__ */ f("div", {
		className: "cnd-board",
		"aria-label": "5 × 5",
		children: e.words.map((o, s) => /* @__PURE__ */ f(R, {
			pub: e,
			index: s,
			members: t,
			myRid: n,
			active: r,
			finalKey: i,
			onTap: a
		}, o))
	});
}
function B({ map: e, pub: t }) {
	let n = i();
	return /* @__PURE__ */ f("div", {
		className: "cnd-key-grid",
		children: e.map((e, r) => /* @__PURE__ */ p("span", {
			"data-kind": e,
			"data-done": !!t.contacted[r],
			role: "img",
			"aria-label": `${t.words[r]} · ${n(e === "agent" ? "games.codenamesduet.agent" : e === "assassin" ? "games.codenamesduet.assassin" : "games.codenamesduet.bystander")}${t.contacted[r] ? ` · ${n("games.codenamesduet.contacted")}` : ""}`,
			children: [/* @__PURE__ */ f("span", {
				className: "cnd-key-word",
				children: t.words[r]
			}), t.contacted[r] && /* @__PURE__ */ f("small", {
				"aria-hidden": "true",
				children: "✓"
			})]
		}, r))
	});
}
//#endregion
//#region src/games/codenamesduet/view-player.tsx
function V({ label: e, confirm: t, onConfirm: n }) {
	let [i, a] = r(!1);
	return /* @__PURE__ */ f("button", {
		type: "button",
		className: "cnd-button cnd-secondary",
		"data-armed": i,
		onBlur: () => a(!1),
		onClick: () => {
			i ? (n(), a(!1)) : a(!0);
		},
		children: i ? t : e
	});
}
function H({ send: e }) {
	let t = i(), [n, a] = r(""), [o, s] = r(2);
	function c() {
		n.trim() && e({
			type: "clue",
			word: n.trim(),
			count: o
		});
	}
	return /* @__PURE__ */ p("form", {
		className: "cnd-clue-form",
		onSubmit: (e) => e.preventDefault(),
		children: [
			/* @__PURE__ */ p("label", {
				className: "cnd-clue-word",
				children: [/* @__PURE__ */ f("span", { children: t("games.codenamesduet.clueWord") }), /* @__PURE__ */ f("input", {
					autoComplete: "off",
					maxLength: 24,
					onKeyDown: (e) => {
						e.key === "Enter" && (e.preventDefault(), c());
					},
					value: n,
					onChange: (e) => a(e.target.value),
					"aria-label": t("games.codenamesduet.clueWord")
				})]
			}),
			/* @__PURE__ */ p("label", {
				className: "cnd-clue-number",
				children: [/* @__PURE__ */ f("span", { children: t("games.codenamesduet.clueCount") }), /* @__PURE__ */ f("select", {
					value: o,
					onChange: (e) => s(Number(e.target.value)),
					"aria-label": t("games.codenamesduet.clueCount"),
					children: Array.from({ length: 10 }, (e, t) => /* @__PURE__ */ f("option", {
						value: t,
						children: t
					}, t))
				})]
			}),
			/* @__PURE__ */ f("button", {
				className: "cnd-button",
				disabled: !n.trim(),
				type: "button",
				onClick: c,
				children: t("games.codenamesduet.sendClue")
			})
		]
	});
}
function U({ public: e, private: t, members: n, myRid: c, send: l }) {
	let u = i(), m = e, h = t, [g, _] = r(null), [v, y] = r(!1), b = g === c, x = (e) => n.find((t) => t.rid === e), S = (e) => u(o[(x(e)?.colorIndex ?? 0) % o.length].nameKey), C = m.phase === "clue" && (m.giver === null || m.giver === c) && !m.retired.includes(c) && !m.completed.includes(c), w = m.players.find((e) => e !== c), T = m.phase === "guess" && m.giver !== c || m.phase === "sudden" && !m.completed.includes(w), E = m.phase === "sudden" ? u("games.codenamesduet.sudden") : m.giver === null ? u("games.codenamesduet.firstClue") : m.phase === "clue" ? u("games.codenamesduet.giving", { name: S(m.giver) }) : u("games.codenamesduet.guessing", { name: S(m.players.find((e) => e !== m.giver)) }), D = m.history[m.history.length - 1];
	return /* @__PURE__ */ p(s, {
		adaptive: !0,
		className: "cnd-game",
		scroll: !1,
		banner: /* @__PURE__ */ p("header", {
			className: "cnd-header",
			children: [
				/* @__PURE__ */ p("div", {
					className: "cnd-title",
					children: [/* @__PURE__ */ f("span", { children: "CODENAMES" }), /* @__PURE__ */ f("strong", { children: u("games.codenamesduet.title") })]
				}),
				/* @__PURE__ */ f("div", {
					className: "cnd-members",
					children: m.players.map((e) => /* @__PURE__ */ f(F, { member: x(e) }, e))
				}),
				/* @__PURE__ */ p("div", {
					className: "cnd-metrics",
					children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("small", { children: u("games.codenamesduet.found") }), /* @__PURE__ */ p("strong", { children: [m.contacted.filter(Boolean).length, /* @__PURE__ */ f("span", { children: " / 15" })] })] }), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("small", { children: u("games.codenamesduet.time") }), /* @__PURE__ */ p("strong", { children: [m.tokens, /* @__PURE__ */ p("span", { children: [" / ", m.initialTokens] })] })] })]
				})
			]
		}),
		actionsHeight: "cnd-actions-slot",
		actions: /* @__PURE__ */ f("div", {
			className: "cnd-action-panel",
			children: C ? /* @__PURE__ */ f(H, { send: l }, `${c}:${m.history.length}`) : /* @__PURE__ */ p("div", {
				className: "cnd-guess-panel",
				children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("small", { children: m.phase === "sudden" ? u("games.codenamesduet.noMoreClues") : u("games.codenamesduet.lastClue") }), /* @__PURE__ */ f("strong", { children: m.clue ? /* @__PURE__ */ p(d, { children: [m.clue.word, /* @__PURE__ */ p("span", { children: [" · ", m.clue.count] })] }) : m.phase === "sudden" ? u("games.codenamesduet.sudden") : u("games.codenamesduet.noClue") })] }), T && m.phase === "guess" ? /* @__PURE__ */ f("button", {
					className: "cnd-button",
					type: "button",
					disabled: m.guessesThisTurn === 0,
					onClick: () => l({ type: "stop" }),
					children: u("games.codenamesduet.stop")
				}) : /* @__PURE__ */ f("span", {
					className: "cnd-action-hint",
					children: u(T ? "games.codenamesduet.guessPrompt" : "games.codenamesduet.waiting")
				})]
			})
		}),
		children: [
			/* @__PURE__ */ p("main", {
				className: "cnd-main",
				children: [/* @__PURE__ */ p("section", {
					className: "cnd-table",
					children: [
						/* @__PURE__ */ p("div", {
							className: "cnd-table-top",
							children: [/* @__PURE__ */ f("strong", { children: E }), /* @__PURE__ */ f("button", {
								className: "cnd-link",
								type: "button",
								onClick: () => y(!0),
								children: u("games.codenamesduet.record")
							})]
						}),
						/* @__PURE__ */ f(z, {
							pub: m,
							members: n,
							myRid: c,
							active: T,
							onTap: (e) => l({
								type: "tap",
								index: e
							})
						}),
						/* @__PURE__ */ p("div", {
							className: "cnd-table-bottom",
							children: [/* @__PURE__ */ f("span", { children: m.phase === "sudden" ? u("games.codenamesduet.suddenHelp") : T ? u("games.codenamesduet.guessPrompt") : m.completed.includes(c) ? u("games.codenamesduet.mapDone") : "" }), /* @__PURE__ */ f("button", {
								className: "cnd-link cnd-key-toggle",
								type: "button",
								onClick: () => _(b ? null : c),
								children: u(b ? "games.codenamesduet.hideMap" : "games.codenamesduet.yourMap")
							})]
						})
					]
				}), /* @__PURE__ */ p("aside", {
					className: "cnd-key-panel",
					children: [/* @__PURE__ */ f("div", {
						className: "cnd-folder-tab",
						children: u("games.codenamesduet.yourMap")
					}), /* @__PURE__ */ p("div", {
						className: "cnd-key-content",
						children: [
							/* @__PURE__ */ f("p", { children: u("games.codenamesduet.mapHelp") }),
							h && /* @__PURE__ */ f(B, {
								map: h.key,
								pub: m
							}),
							/* @__PURE__ */ f("div", {
								className: "cnd-key-legend",
								children: [
									"agent",
									"bystander",
									"assassin"
								].map((e) => /* @__PURE__ */ f("span", {
									"data-kind": e,
									children: /* @__PURE__ */ f(I, { kind: e })
								}, e))
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ f(a, {
				open: b,
				onClose: () => _(null),
				label: u("games.codenamesduet.yourMap"),
				title: u("games.codenamesduet.yourMap"),
				children: /* @__PURE__ */ p("div", {
					className: "cnd-key-content",
					children: [/* @__PURE__ */ f("p", { children: u("games.codenamesduet.mapHelp") }), h && /* @__PURE__ */ f(B, {
						map: h.key,
						pub: m
					})]
				})
			}),
			/* @__PURE__ */ f(a, {
				open: v,
				onClose: () => y(!1),
				label: u("games.codenamesduet.record"),
				title: u("games.codenamesduet.record"),
				children: /* @__PURE__ */ p("div", {
					className: "cnd-record",
					children: [
						m.history.length === 0 && /* @__PURE__ */ f("p", { children: u("games.codenamesduet.noHistory") }),
						m.history.map((e, t) => /* @__PURE__ */ p("section", { children: [
							/* @__PURE__ */ p("h3", { children: [
								u("games.codenamesduet.turn", { n: t + 1 }),
								" · ",
								S(e.by)
							] }),
							/* @__PURE__ */ p("strong", { children: [
								e.word,
								" · ",
								e.count
							] }),
							/* @__PURE__ */ f("ul", { children: e.guesses.map((e, t) => /* @__PURE__ */ p("li", { children: [
								S(e.by),
								" · ",
								m.words[e.index],
								" · ",
								/* @__PURE__ */ f(I, { kind: e.kind })
							] }, t)) }),
							/* @__PURE__ */ p("small", { children: [u(e.ended === "stop" ? "games.codenamesduet.endStop" : e.ended === "bystander" ? "games.codenamesduet.endBystander" : e.ended === "done" ? "games.codenamesduet.endDone" : "games.codenamesduet.endOpen"), e.penalty ? ` · ${u("games.codenamesduet.penaltyApplied")}` : ""] })
						] }, t)),
						m.suddenGuesses.length > 0 && /* @__PURE__ */ p("section", { children: [/* @__PURE__ */ f("h3", { children: u("games.codenamesduet.sudden") }), /* @__PURE__ */ f("ul", { children: m.suddenGuesses.map((e, t) => /* @__PURE__ */ p("li", { children: [
							S(e.by),
							" · ",
							m.words[e.index],
							" · ",
							/* @__PURE__ */ f(I, { kind: e.kind })
						] }, t)) })] }),
						m.retired.map((e) => /* @__PURE__ */ p("p", { children: [
							S(e),
							" · ",
							u("games.codenamesduet.passRecord")
						] }, e)),
						C && /* @__PURE__ */ f(V, {
							label: u("games.codenamesduet.retire"),
							confirm: u("games.codenamesduet.retireConfirm"),
							onConfirm: () => {
								l({ type: "retire" }), y(!1);
							}
						}),
						m.phase === "guess" && m.tokens > 0 && !D?.penalty && /* @__PURE__ */ f(V, {
							label: u("games.codenamesduet.penalty"),
							confirm: u("games.codenamesduet.penaltyConfirm"),
							onConfirm: () => l({ type: "penalty" })
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/codenamesduet/bot.ts
var W = ({ public: e }, t) => {
	if (e.phase === "done") return null;
	if (e.phase === "clue" && (e.giver === null || e.giver === t.rid) && !e.retired.includes(t.rid) && !e.completed.includes(t.rid)) return { action: {
		type: "clue",
		word: [
			"线索",
			"联想",
			"含义",
			"思路",
			"启发",
			"印象",
			"X"
		].find((t) => !e.words.some((n, r) => !e.contacted[r] && (t.includes(n) || n.includes(t)))),
		count: 1
	} };
	if (e.phase === "clue" || e.phase === "guess" && e.giver === t.rid || e.phase === "sudden" && e.completed.includes(e.players.find((e) => e !== t.rid))) return null;
	if (e.phase === "guess" && e.guessesThisTurn > 0) return { action: { type: "stop" } };
	if (e.proposal?.by === t.rid) return { action: {
		type: "tap",
		index: e.proposal.index
	} };
	let n = e.words.map((e, t) => t).filter((n) => !e.contacted[n] && !e.bystanders[n].includes(t.rid));
	return n.length ? { action: {
		type: "tap",
		index: n[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % n.length]
	} } : null;
}, G = { "duet-reveal"(e, t) {
	let n = e.data, r = t.anchor(`duet-card:${n.index}`);
	if (!r) return null;
	let i = n.cell === "agent" || n.cell === "assassin" ? n.cell : null;
	return {
		ms: 480,
		node: /* @__PURE__ */ f("div", {
			className: "cnd-fx-reveal",
			"data-kind": n.cell,
			style: {
				left: r.x,
				top: r.y,
				width: r.w,
				height: r.h,
				animationDuration: "480ms"
			},
			children: i ? /* @__PURE__ */ f("img", {
				src: c(`games/codenamesduet/${i}.webp`),
				alt: ""
			}) : /* @__PURE__ */ f("span", { className: "cnd-fx-token" })
		})
	};
} };
//#endregion
//#region src/games/codenamesduet/game-over.tsx
function K({ public: e, members: t, myRid: n, result: a, hintCount: c, onPlayAgain: l, onBackToLobby: u }) {
	let d = i(), m = e, [h, g] = r(!0), [_, v] = r(0), y = m.outcome === "success", b = m.initialTokens === 9, x = m.stoppedTurns + 3 * m.tokens - +!!m.usedSudden, S = (e) => {
		let n = t.find((t) => t.rid === m.players[e]);
		return d("games.codenamesduet.finalMap", { name: d(o[(n?.colorIndex ?? 0) % o.length].nameKey) });
	};
	return /* @__PURE__ */ f(s, {
		adaptive: !0,
		className: "cnd-game cnd-ending",
		scroll: !1,
		children: /* @__PURE__ */ p("div", {
			className: "cnd-ending-layout",
			children: [
				/* @__PURE__ */ p("div", {
					className: "cnd-end-top",
					children: [/* @__PURE__ */ f("strong", { children: d(y ? "games.codenamesduet.success" : "games.codenamesduet.failure") }), /* @__PURE__ */ f("div", {
						className: "cnd-key-choice",
						children: m.players.map((e, t) => /* @__PURE__ */ f("button", {
							type: "button",
							className: "cnd-link",
							"aria-pressed": _ === t,
							onClick: () => v(t),
							children: S(t)
						}, e))
					})]
				}),
				/* @__PURE__ */ f("div", {
					className: "cnd-end-board",
					inert: h,
					children: /* @__PURE__ */ f(z, {
						pub: m,
						members: t,
						myRid: n,
						finalKey: m.finalKeys?.[_]
					})
				}),
				/* @__PURE__ */ f("button", {
					className: "cnd-button cnd-result-toggle",
					type: "button",
					onClick: () => g(!0),
					children: d("games.codenamesduet.showResult")
				}),
				h && /* @__PURE__ */ f("div", {
					className: "cnd-result-mask",
					children: /* @__PURE__ */ p("section", {
						className: "cnd-result",
						role: "dialog",
						"aria-modal": "true",
						"aria-label": d(y ? "games.codenamesduet.success" : "games.codenamesduet.failure"),
						children: [
							/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("span", { children: "CODENAMES · DUET" }), /* @__PURE__ */ f("button", {
								className: "cnd-link",
								type: "button",
								onClick: () => g(!1),
								children: d("games.codenamesduet.reviewBoard")
							})] }),
							/* @__PURE__ */ p("div", {
								className: "cnd-result-body",
								children: [
									/* @__PURE__ */ f("small", { children: d("games.codenamesduet.mission") }),
									/* @__PURE__ */ f("h1", { children: d(y ? "games.codenamesduet.success" : "games.codenamesduet.failure") }),
									/* @__PURE__ */ f("p", { children: d(y ? "games.codenamesduet.successText" : m.outcome === "assassin" ? "games.codenamesduet.assassinEnd" : "games.codenamesduet.suddenEnd") }),
									m.failedIndex !== null && /* @__PURE__ */ f("strong", {
										className: "cnd-failed-word",
										children: m.words[m.failedIndex]
									}),
									/* @__PURE__ */ f("div", {
										className: "cnd-end-members",
										children: m.players.map((e) => /* @__PURE__ */ f(F, { member: t.find((t) => t.rid === e) }, e))
									}),
									/* @__PURE__ */ p("div", {
										className: "cnd-score",
										children: [/* @__PURE__ */ f("strong", { children: y && b ? x : m.contacted.filter(Boolean).length }), /* @__PURE__ */ p("span", { children: [d(y && b ? "games.codenamesduet.score" : "games.codenamesduet.found"), b ? "" : ` · ${d("games.codenamesduet.noScore")}`] })]
									}),
									/* @__PURE__ */ p("dl", {
										className: "cnd-score-detail",
										children: [
											/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.codenamesduet.unused") }), /* @__PURE__ */ p("dd", { children: [m.tokens, y && b ? " × 3" : ""] })] }),
											/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.codenamesduet.safeStops") }), /* @__PURE__ */ p("dd", { children: [m.stoppedTurns, y && b ? " × 1" : ""] })] }),
											/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.codenamesduet.mistakes") }), /* @__PURE__ */ f("dd", { children: m.mistakes })] }),
											/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.codenamesduet.penalties") }), /* @__PURE__ */ f("dd", { children: m.penalties })] }),
											/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.codenamesduet.suddenPenalty") }), /* @__PURE__ */ f("dd", { children: m.usedSudden ? "−1" : "0" })] })
										]
									}),
									c !== void 0 && c > 0 && /* @__PURE__ */ f("p", { children: d("games.codenamesduet.hints", { n: c }) }),
									m.players.filter((e) => (a.autopilot?.[e] ?? 0) > 0).map((e) => /* @__PURE__ */ p("p", { children: [
										d(o[(t.find((t) => t.rid === e)?.colorIndex ?? 0) % o.length].nameKey),
										" · ",
										d("games.codenamesduet.autopilot", { pct: Math.round((a.autopilot?.[e] ?? 0) * 100) })
									] }, e))
								]
							}),
							/* @__PURE__ */ p("footer", { children: [
								l && /* @__PURE__ */ f("button", {
									className: "cnd-button",
									type: "button",
									onClick: l,
									children: d("session.result.playAgain")
								}),
								u && /* @__PURE__ */ f("button", {
									className: "cnd-button cnd-secondary",
									type: "button",
									onClick: u,
									children: d("session.result.backToLobby")
								}),
								!l && !u && /* @__PURE__ */ f("p", { children: d("session.result.waitHost") })
							] })
						]
					})
				})
			]
		})
	});
}
//#endregion
//#region src/games/codenamesduet/options.tsx
function q({ value: e, onChange: t }) {
	let n = i(), r = _.safeParse(e), a = r.success ? r.data : _.parse(void 0);
	return /* @__PURE__ */ f(h, {
		title: n("games.codenamesduet.optTokens"),
		columns: 3,
		children: [
			9,
			10,
			11
		].map((e) => /* @__PURE__ */ f(m, {
			name: "duet-tokens",
			value: String(e),
			checked: a.tokens === e,
			accent: g.accent,
			label: n(e === 9 ? "games.codenamesduet.standard" : "games.codenamesduet.practice", { n: e }),
			onChange: () => t({ tokens: e })
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/codenamesduet/entry.tsx
var J = {
	definition: P,
	View: U,
	bot: W,
	fx: G,
	OverView: K,
	Options: q,
	locales: {
		zh: {
			name: "行动代号二重奏",
			desc: "两位特工交换线索，在时间耗尽前联络全部 15 名同伴，并避开藏在双方地图中的刺客。",
			rules: "游戏目标：\n这是两人合作游戏。双方轮流提供线索，合作联络 15 名特工；只要有人误认刺客，双方立即失败。本作使用与《行动代号》相同的中文词库。\n\n准备与秘密地图：\n桌面随机摆出 25 张词牌，组成每行五张、每列五张的方阵。双方各有一面秘密地图，每面标有 9 名特工、3 名刺客和 13 名路人。你的地图表示同伴猜词时的结果；你自己猜词时，要以同伴的地图为准。界面中两面地图都与词牌使用相同的方向，无须旋转。\n· 两面地图有 3 名共同特工，因此只需要联络 15 名不同的特工。已经联络的特工会盖住词牌，双方都不能再猜。\n· 每面地图上的 3 张刺客词牌中，恰有 1 张在另一面是特工、1 张在另一面是路人、1 张在双方地图上都是刺客。这个固定关系可以帮助双方推理，但不要把自己地图上的颜色直接当作自己猜词时的结果。\n· 标准任务使用 9 枚时间标记。开局也可选择使用 10 枚或 11 枚进行练习。\n\n提供线索：\n首回合由先想到线索的人出题，此后通常轮流出题。线索必须包含一个词语和一个 0 至 9 的数字，数字表示这个线索与几张词牌有关。请根据词义建立联系，不得利用词牌的位置、字数、字形、口音或手势传递信息。\n· 线索不得使用尚未盖住的词牌本身、其中一部分或其词形变化。系统会拦截明显的文字重合；其他是否合法，由双方按照上述原则共同判断。\n· 数字 0 表示不要猜与该线索有关的词牌。同伴仍须根据以前的线索或排除后的判断至少猜一次。\n· 出题后不能补充说明、暗示答案、建议何时停止，或告知还剩几张特工词牌。只有自己地图上的 9 名特工全部被联络后，才可以宣布已经全部完成。\n· 若双方发现当前线索违规，可在记录面板中确认一次违规罚时，额外弃掉 1 枚时间标记，然后继续当前回合。每条线索最多罚时一次；没有剩余标记时不能再罚时。\n\n猜测词牌：\n收到线索后，点击一张词牌选中，再次点击同一张牌确认猜测。你可以先换选其他词牌；出题者不能替同伴确认。\n· 猜中特工时，该词牌由绿色特工标记覆盖，双方共享这个成果。你可以继续猜测，次数不限，也可以尝试找出以前线索中遗漏的词牌；不使用经典版的“数字加一次”限制。\n· 猜中路人时，在词牌上放置朝向猜词者的时间标记，并立即结束回合。这个人以后不能再猜同一张牌，但同伴仍可猜，因为同伴猜测时使用另一面地图。\n· 猜中刺客时，双方立即失败，即使这张牌在你自己的地图上是特工也一样。\n· 每回合至少猜一次。猜中过至少一名特工后，你可以点击“结束猜测”，取走 1 枚时间标记并结束回合。\n正常回合无论主动停止还是猜中路人，都只消耗 1 枚时间标记；违规罚时另外计算。回合结束后，猜词者成为下一位出题者。若一方已经没有可供同伴猜的特工词牌，余下回合都由另一方出题。\n\n永久放弃出题：\n轮到你出题时，可以确认“此后不再出题”。此操作不消耗时间标记，但本局不能撤销；本回合及余下回合都改由同伴出题。如果同伴也已经放弃出题，或已经没有特工词牌可以出题，立即进入突然死亡，即使仍有时间标记也一样。\n\n胜利与突然死亡：\n联络全部 15 名特工时，双方立即获胜。若最后一枚时间标记用完时尚未获胜，则进入突然死亡：不能再提供新线索，只能根据此前线索猜测。双方可以任意顺序逐张猜词，不必轮流；只能商量由谁先猜，不能讨论策略或泄露剩余词牌数量。只要猜中路人或刺客，双方立即失败；猜完全部特工则获胜。\n\n任务评分：\n标准 9 枚标记任务获胜后，每枚用于主动结束回合的标记得 1 分，每枚未使用的标记得 3 分，用作路人或违规罚时的标记不得分。若进入过突然死亡，再扣 1 分。使用 10 枚或 11 枚标记的练习任务只记录胜负与任务过程，不套用标准任务评分。\n本作按 CGE 2025 年实体基础版制作。任务地图属于其配套 App 内容，不包含在本版中。规则机器人仅用于测试流程，不能理解词义联想。",
			optTokens: "任务时间",
			standard: "标准 · 9 枚",
			practice: "练习 · {{n}} 枚",
			title: "二重奏",
			mission: "合作任务",
			found: "已联络",
			time: "时间标记",
			firstClue: "任一方先提供线索",
			giving: "{{name}} 正在出题",
			guessing: "{{name}} 正在猜词",
			sudden: "突然死亡",
			suddenHelp: "不再出题；任一错误都会结束任务。",
			yourMap: "秘密地图",
			hideMap: "收起地图",
			mapHelp: "这是同伴猜词时的结果。你猜词时使用同伴的地图。",
			mapDone: "你地图上的特工已全部联络。",
			partnerDone: "同伴地图上的特工已全部联络。",
			retired: "此后不再出题",
			agent: "特工",
			bystander: "路人",
			assassin: "刺客",
			contacted: "已联络",
			clueWord: "线索词",
			clueCount: "关联词牌数",
			sendClue: "提供线索",
			stop: "结束猜测",
			retire: "此后不再出题",
			retireConfirm: "确认永久放弃出题",
			waiting: "等待同伴",
			guessPrompt: "点选词牌，再次点击确认",
			confirmCard: "再次点击确认猜测",
			noClue: "等待线索",
			lastClue: "当前线索",
			record: "任务记录",
			close: "关闭",
			noHistory: "尚未提供线索。",
			turn: "第 {{n}} 回合",
			endStop: "主动结束",
			endBystander: "误认路人",
			endDone: "任务结束",
			endOpen: "猜测中",
			penalty: "报告违规线索",
			penaltyConfirm: "确认罚掉 1 枚标记",
			penaltyApplied: "已罚时",
			passRecord: "已永久放弃出题",
			noMoreClues: "只能根据此前线索猜测",
			blocked: "{{name}} 已确认这是路人",
			cardLabel: "{{word}}，{{state}}",
			success: "任务完成",
			failure: "任务失败",
			assassinEnd: "遭遇刺客",
			suddenEnd: "突然死亡中误认路人",
			successText: "全部 15 名特工已安全联络。",
			agentTotal: "{{n}} / 15 名特工",
			score: "任务得分",
			unused: "未用标记",
			safeStops: "主动结束",
			mistakes: "误认路人",
			penalties: "违规罚时",
			suddenPenalty: "突然死亡",
			reviewBoard: "回看词牌",
			showResult: "查看任务结果",
			finalMap: "{{name}} 的地图",
			noScore: "练习任务",
			hints: "使用了 {{n}} 次提示",
			autopilot: "托管代打 {{pct}}%",
			errTurn: "现在不能执行这个行动。",
			errClue: "请使用不与未盖住词牌重合的单个线索词。",
			errCard: "这张词牌不能再由你猜测。",
			errStop: "本回合至少需要先猜一次。",
			errPenalty: "当前不能再执行违规罚时。"
		},
		en: {
			name: "Codenames: Duet",
			desc: "Exchange clues with a fellow operative, contact all 15 agents before time runs out, and avoid the assassins on both secret keys.",
			rules: "Objective:\nThis is a cooperative game for two players. Take turns giving clues and contact all 15 agents together. If either player guesses an assassin, you both lose immediately. This implementation uses the same Chinese word bank as Codenames.\n\nSetup and secret keys:\nTwenty-five random word cards form a 5×5 grid. Each player sees one secret key with 9 agents, 3 assassins, and 13 bystanders. Your key shows the result when your partner guesses; when you guess, your partner's key determines the result. Both digital keys align with the word grid in the same orientation and need no rotation.\n· Three agents are green on both keys, so there are 15 distinct agents to contact. A contacted agent covers the card and cannot be guessed by either player again.\n· Of the 3 assassin cards on each key, exactly 1 is an agent on the other key, 1 is a bystander on the other key, and 1 is an assassin on both keys. This fixed relationship can help deduction, but the color on your own key does not determine the result of your own guess.\n· A standard mission uses 9 timer tokens. You may select 10 or 11 tokens for practice.\n\nGiving clues:\nEither player may give the first clue. After that, players normally alternate. Give one word and a number from 0 to 9 indicating how many cards relate to your clue. Clues must concern meaning, not position, letter count, spelling, accents, or gestures.\n· Do not use an uncovered word, any part of it, or a form of it as a clue. The game rejects obvious text overlap; players judge the remaining cases according to these principles.\n· A zero clue warns your partner not to guess related cards. Your partner must still make at least one guess, using earlier clues or deduction.\n· Do not explain a clue, hint at answers, advise when to stop, or disclose how many agents remain. Announce completion only when all 9 agents on your key have been contacted.\n· If both players identify an invalid current clue, confirm an invalid-clue penalty in the record panel: discard 1 extra timer token, then continue the turn. Each clue may receive one penalty. No penalty can be taken without a remaining token.\n\nGuessing:\nSelect a word card, then tap it again to confirm. You may change your selection first. The clue-giver cannot confirm a guess for their partner.\n· An agent is covered in green and counts for both players. You may keep guessing with no limit, including words missed from earlier clues. Duet does not use the classic number-plus-one limit.\n· A bystander receives a timer token facing the guesser and ends the turn immediately. That player cannot guess it again, but their partner may because the other key applies.\n· An assassin makes both players lose immediately, even if that word is an agent on the guesser's own key.\n· You must guess at least once per turn. After contacting at least one agent, you may choose End guessing and take 1 timer token to end the turn.\nEach normal turn uses exactly 1 timer token, whether ended voluntarily or by a bystander. An invalid-clue penalty is additional. The guesser becomes the next clue-giver. If all agents on one player's key have been contacted, the other player gives all remaining clues.\n\nPassing permanently:\nOn your clue-giving turn, you may confirm Give no more clues. This costs no timer token and cannot be reversed during the mission. Your partner gives this clue and every remaining clue. If your partner has also passed or has no remaining agents to give clues for, sudden death begins immediately, even with tokens left.\n\nWinning and sudden death:\nContact all 15 agents to win immediately. If the last timer token is used before you win, enter sudden death. No new clues are allowed; use previous clues only. Players may guess one card at a time in any order without alternating. Discuss only who will guess, not strategy or the number of remaining cards. A bystander or assassin makes you both lose immediately; finding all remaining agents wins.\n\nMission score:\nAfter winning a standard 9-token mission, score 1 point per token taken to end a turn, 3 points per unused token, and 0 points for bystanders or invalid-clue penalties. Subtract 1 point if you entered sudden death. Practice missions with 10 or 11 tokens record the outcome and mission details without the standard score.\nThis implementation follows the CGE 2025 physical base edition. Its mission map belongs to the companion app and is outside this version. The rule bot is a flow-testing placeholder and does not understand word associations.",
			optTokens: "Mission time",
			standard: "Standard · 9",
			practice: "Practice · {{n}}",
			title: "DUET",
			mission: "Cooperative mission",
			found: "Contacted",
			time: "Timer tokens",
			firstClue: "Either player may give the first clue",
			giving: "{{name}} is giving a clue",
			guessing: "{{name}} is guessing",
			sudden: "Sudden death",
			suddenHelp: "No new clues. Any wrong guess ends the mission.",
			yourMap: "Secret key",
			hideMap: "Hide key",
			mapHelp: "This key applies when your partner guesses. Your guesses use their key.",
			mapDone: "All agents on your key have been contacted.",
			partnerDone: "All agents on your partner’s key have been contacted.",
			retired: "No more clues",
			agent: "Agent",
			bystander: "Bystander",
			assassin: "Assassin",
			contacted: "Contacted",
			clueWord: "Clue word",
			clueCount: "Related cards",
			sendClue: "Give clue",
			stop: "End guessing",
			retire: "Give no more clues",
			retireConfirm: "Confirm permanent pass",
			waiting: "Waiting for your partner",
			guessPrompt: "Select a card, then tap again to confirm",
			confirmCard: "Tap again to confirm guess",
			noClue: "Awaiting a clue",
			lastClue: "Current clue",
			record: "Mission record",
			close: "Close",
			noHistory: "No clues yet.",
			turn: "Turn {{n}}",
			endStop: "Ended voluntarily",
			endBystander: "Bystander",
			endDone: "Mission ended",
			endOpen: "Guessing",
			penalty: "Report invalid clue",
			penaltyConfirm: "Confirm: discard 1 token",
			penaltyApplied: "Penalty taken",
			passRecord: "Gives no more clues",
			noMoreClues: "Use previous clues only",
			blocked: "{{name}} found a bystander here",
			cardLabel: "{{word}}, {{state}}",
			success: "Mission complete",
			failure: "Mission failed",
			assassinEnd: "An assassin was contacted",
			suddenEnd: "A bystander ended sudden death",
			successText: "All 15 agents have been safely contacted.",
			agentTotal: "{{n}} / 15 agents",
			score: "Mission score",
			unused: "Unused tokens",
			safeStops: "Voluntary stops",
			mistakes: "Bystanders",
			penalties: "Clue penalties",
			suddenPenalty: "Sudden death",
			reviewBoard: "Review the grid",
			showResult: "Mission result",
			finalMap: "{{name}}’s key",
			noScore: "Practice mission",
			hints: "Used {{n}} hints",
			autopilot: "Autopilot: {{pct}}%",
			errTurn: "That action is not available now.",
			errClue: "Use a single clue word that does not overlap an uncovered card.",
			errCard: "You cannot guess this card again.",
			errStop: "Make at least one guess before ending the turn.",
			errPenalty: "No further clue penalty can be taken now."
		}
	}
};
//#endregion
export { J as default };
