import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as d } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { AVATARS as h } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as g } from "@bgparty/sdk/player-colors";
import { jsx as _, jsxs as v } from "react/jsx-runtime";
import { Floater as y, FlySprite as b, PulseBox as ee } from "@bgparty/sdk/fx/primitives";
import { Confetti as x } from "@bgparty/sdk/ui/confetti";
//#region src/games/beastybar/meta.ts
var S = {
	id: "beastybar",
	tier: "released",
	mechanics: ["hand-management"],
	interactionTags: [],
	nameKey: "games.beastybar.name",
	descKey: "games.beastybar.desc",
	rulesKey: "games.beastybar.rules",
	icon: "🦁",
	iconImg: "games/beastybar.webp",
	rulesUrl: { de: "https://rules.bgparty.uuppi.com/beastybar/de.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#7c3aed",
	releasedAt: "2026-09-15",
	search: {
		py: "ye shou jiu ba",
		init: "ysjb"
	},
	hotseat: "cover"
}, C = [
	"lion",
	"hippo",
	"crocodile",
	"snake",
	"giraffe",
	"zebra",
	"seal",
	"chameleon",
	"monkey",
	"kangaroo",
	"parrot",
	"skunk"
], w = t.enum(C), T = t.discriminatedUnion("type", [t.object({
	type: t.literal("play"),
	animal: w,
	as: w.optional(),
	target: t.int().min(0).optional(),
	hop: t.union([t.literal(1), t.literal(2)]).optional()
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), E = t.string(), D = t.object({
	id: t.int().min(0),
	owner: E,
	animal: w
}), te = t.object({
	k: t.enum([
		"play",
		"expel",
		"enter",
		"bounce"
	]),
	rid: E.optional(),
	animal: w.optional(),
	as: w.optional(),
	by: w.optional(),
	animals: t.array(w).optional(),
	n: t.int().optional()
}), O = t.object({
	phase: t.enum([
		"play",
		"resolving",
		"done"
	]),
	turn: E,
	queue: t.array(D),
	out: t.array(D),
	players: t.array(t.object({
		rid: E,
		handCount: t.int().nonnegative(),
		deckCount: t.int().nonnegative(),
		barCount: t.int().nonnegative()
	})),
	bars: t.record(t.string(), t.array(w)).nullable(),
	log: t.array(te)
}), ne = t.object({ hand: t.array(w) }), k = {
	lion: 12,
	hippo: 11,
	crocodile: 10,
	snake: 9,
	giraffe: 8,
	zebra: 7,
	seal: 6,
	chameleon: 5,
	monkey: 4,
	kangaroo: 3,
	parrot: 2,
	skunk: 1
}, A = {
	lion: 2,
	hippo: 2,
	crocodile: 3,
	snake: 2,
	giraffe: 3,
	zebra: 4,
	seal: 2,
	chameleon: 3,
	monkey: 3,
	kangaroo: 4,
	parrot: 4,
	skunk: 1
}, re = {
	lion: "🦁",
	hippo: "🦛",
	crocodile: "🐊",
	snake: "🐍",
	giraffe: "🦒",
	zebra: "🦓",
	seal: "🦭",
	chameleon: "🦎",
	monkey: "🐒",
	kangaroo: "🦘",
	parrot: "🦜",
	skunk: "🦨"
}, j = {
	lion: "games.beastybar.a.lion",
	hippo: "games.beastybar.a.hippo",
	crocodile: "games.beastybar.a.crocodile",
	snake: "games.beastybar.a.snake",
	giraffe: "games.beastybar.a.giraffe",
	zebra: "games.beastybar.a.zebra",
	seal: "games.beastybar.a.seal",
	chameleon: "games.beastybar.a.chameleon",
	monkey: "games.beastybar.a.monkey",
	kangaroo: "games.beastybar.a.kangaroo",
	parrot: "games.beastybar.a.parrot",
	skunk: "games.beastybar.a.skunk"
}, M = {
	lion: "games.beastybar.e.lion",
	hippo: "games.beastybar.e.hippo",
	crocodile: "games.beastybar.e.crocodile",
	snake: "games.beastybar.e.snake",
	giraffe: "games.beastybar.e.giraffe",
	zebra: "games.beastybar.e.zebra",
	seal: "games.beastybar.e.seal",
	chameleon: "games.beastybar.e.chameleon",
	monkey: "games.beastybar.e.monkey",
	kangaroo: "games.beastybar.e.kangaroo",
	parrot: "games.beastybar.e.parrot",
	skunk: "games.beastybar.e.skunk"
}, N = 4, P = {
	play: 520,
	act: 700,
	recur: 520,
	recurNoop: 120,
	gate: 1e3,
	turn: 350
}, F = (e) => k[e.animal];
function I(e, t, n) {
	if (e.some((e) => e.animal === "lion" && e.id !== n.id)) {
		let r = e.findIndex((e) => e.id === n.id);
		t.push(...e.splice(r, 1));
		return;
	}
	for (let n = e.length - 1; n >= 0; --n) e[n].animal === "monkey" && t.push(...e.splice(n, 1));
	let r = e.findIndex((e) => e.id === n.id);
	r > 0 && e.unshift(...e.splice(r, 1));
}
function L(e, t, n) {
	let r = e.findIndex((e) => e.id === t.id);
	for (; r > 0;) {
		let i = e[r - 1];
		if (i.animal === "zebra" || n(i) >= n(t)) break;
		[e[r - 1], e[r]] = [e[r], e[r - 1]], --r;
	}
}
function R(e, t, n, r) {
	let i = e.findIndex((e) => e.id === n.id);
	for (; i > 0;) {
		let a = e[i - 1];
		if (a.animal === "zebra" || r(a) >= r(n)) break;
		t.push(...e.splice(i - 1, 1)), --i;
	}
}
function ie(e, t) {
	e.sort((e, n) => t(n) - t(e));
}
function z(e, t, n) {
	let r = e.findIndex((e) => e.id === t.id);
	r > 0 && n(e[r - 1]) < n(t) && ([e[r - 1], e[r]] = [e[r], e[r - 1]]);
}
function ae(e, t, n) {
	let r = e.filter((e) => e.animal === "monkey" && e.id !== n.id);
	if (r.length + 1 < 2) return;
	for (let n = e.length - 1; n >= 0; --n) (e[n].animal === "hippo" || e[n].animal === "crocodile") && t.push(...e.splice(n, 1));
	let i = e.filter((e) => e.animal !== "monkey" && e.id !== n.id);
	e.length = 0, e.push(n, ...r.reverse(), ...i);
}
function oe(e, t, n) {
	let r = e.findIndex((e) => e.id === t.id), i = Math.min(n, r);
	i <= 0 || e.splice(r - i, 0, ...e.splice(r, 1));
}
function se(e, t, n) {
	let r = e.findIndex((e) => e.id === n);
	r >= 0 && t.push(...e.splice(r, 1));
}
function ce(e, t, n, r) {
	let i = [...new Set(e.filter((e) => e.animal !== "skunk").map(r))].sort((e, t) => t - e).slice(0, 2);
	for (let a = e.length - 1; a >= 0; --a) {
		let o = e[a];
		o.animal !== "skunk" && o.id !== n.id && i.includes(r(o)) && t.push(...e.splice(a, 1));
	}
}
function B(e, t, n, r) {
	let i = (n.animal === "chameleon" ? r.as : void 0) ?? n.animal, a = (e) => e.id === n.id ? k[i] : k[e.animal];
	switch (i) {
		case "lion":
			I(e, t, n);
			break;
		case "hippo":
			L(e, n, a);
			break;
		case "crocodile":
			R(e, t, n, a);
			break;
		case "snake":
			ie(e, a);
			break;
		case "giraffe":
			z(e, n, a);
			break;
		case "zebra": break;
		case "seal":
			e.reverse();
			break;
		case "chameleon": break;
		case "monkey":
			ae(e, t, n);
			break;
		case "kangaroo":
			oe(e, n, r.hop ?? 2);
			break;
		case "parrot":
			r.target !== void 0 && se(e, t, r.target);
			break;
		case "skunk": ce(e, t, n, a);
	}
}
function V(e, t) {
	let n = new Map(e.map((e, t) => [e.id, t])), r = new Set(t.map((e) => e.id)), i = e.filter((e) => !r.has(e.id)).map((e) => ({
		id: e.id,
		from: n.get(e.id) ?? 0
	}));
	return {
		moves: t.map((e, t) => ({
			id: e.id,
			from: n.get(e.id) ?? t,
			to: t
		})).filter((e) => e.from !== e.to),
		expelled: i
	};
}
function H(e, t, n, r) {
	if (n.expelled.length === 0) return;
	let i = new Map(t.map((e) => [e.id, e.animal]));
	e.log.push({
		k: "expel",
		by: r,
		animals: n.expelled.map((e) => i.get(e.id) ?? r)
	});
}
function le(e) {
	if (e.queue.length !== 5) return null;
	let t = e.queue.slice(0, 2), n = e.queue[4];
	for (let n of t) e.bar[n.owner].push(n.animal);
	return e.out.push(n), e.queue = e.queue.slice(2, 4), {
		enter: t,
		bounced: n
	};
}
function U(e, t, n, r) {
	if (r.moves.length === 0 && r.expelled.length === 0) return null;
	let i = new Map([...t.queue, ...t.out].map((e) => [e.id, e])), a = (e) => ({
		...e,
		animal: i.get(e.id)?.animal ?? n.animal,
		owner: i.get(e.id)?.owner ?? n.owner
	});
	return {
		kind: e,
		rid: n.owner,
		data: {
			id: n.id,
			animal: n.animal,
			moves: r.moves.map(a),
			expelled: r.expelled.map(a)
		}
	};
}
function ue(e, t, n) {
	if (!e.includes(n)) return [];
	let r = new Set(t.map((e) => e.animal));
	if (n === "chameleon") {
		let e = [...r].filter((e) => e !== "chameleon");
		if (e.length === 0) return [{}];
		let n = [];
		for (let r of e) if (r === "parrot") for (let e of t) n.push({
			as: r,
			target: e.id
		});
		else r === "kangaroo" ? (n.push({
			as: r,
			hop: 1
		}), t.length >= 2 && n.push({
			as: r,
			hop: 2
		})) : n.push({ as: r });
		return n;
	}
	if (n === "parrot") return t.length === 0 ? [{}] : t.map((e) => ({ target: e.id }));
	if (n === "kangaroo") {
		if (t.length === 0) return [{}];
		let e = [{ hop: 1 }];
		return t.length >= 2 && e.push({ hop: 2 }), e;
	}
	return [{}];
}
function de(e, t, n) {
	let r = e.map((e) => ({ ...e })), i = [];
	r.push(t);
	let a = r.map((e) => e.id);
	B(r, i, t, n);
	let o = /* @__PURE__ */ new Set();
	t.animal === "giraffe" && a.indexOf(t.id) > r.findIndex((e) => e.id === t.id) && o.add(t.id);
	let s = /* @__PURE__ */ new Set();
	for (;;) {
		let e = r.find((e) => !s.has(e.id) && (e.animal === "hippo" || e.animal === "crocodile" || e.animal === "giraffe" && !o.has(e.id)));
		if (!e) break;
		s.add(e.id), e.animal === "hippo" ? L(r, e, F) : e.animal === "crocodile" ? R(r, i, e, F) : fe(r, e) && o.add(e.id);
	}
	let c = [], l = null;
	return r.length === 5 && (c = r.slice(0, 2).map((e) => ({
		owner: e.owner,
		animal: e.animal
	})), l = r[4], i.push(l), r.splice(0, 2), r.pop()), {
		queue: r,
		out: i,
		barGains: c,
		bounced: l
	};
}
function fe(e, t) {
	let n = e.map((e) => e.id);
	return z(e, t, F), n.indexOf(t.id) > e.findIndex((e) => e.id === t.id);
}
function pe(t, n, r) {
	let i = 0, a = {}, o = {}, s = {};
	for (let t of n) {
		let n = [...C];
		for (let t = n.length - 1; t > 0; --t) {
			let a = e(r, i, t + 1);
			i += 1, [n[t], n[a]] = [n[a], n[t]];
		}
		a[t] = n.slice(0, N), o[t] = n.slice(N), s[t] = [];
	}
	let c = e(r, i, n.length);
	return {
		state: {
			seed: r,
			rngCursor: i + 1,
			players: n,
			turnIdx: c,
			phase: "play",
			hands: a,
			decks: o,
			queue: [],
			bar: s,
			out: [],
			nextEntryId: 1,
			playedId: null,
			playedOpts: {},
			giraffeMoved: [],
			recurDone: [],
			log: [],
			pending: [],
			beatMs: 0
		},
		fx: n.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: N },
			for: [e],
			secret: { cards: a[e] },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function me(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "resolving" || e.pending.length === 0) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), [n, ...r] = t.pending;
		if (t.pending = r, n.k === "action") {
			let e = t.queue.find((e) => e.id === t.playedId);
			if (!e) return t.beatMs = P.recurNoop, {
				state: t,
				fx: []
			};
			let n = [...t.queue];
			B(t.queue, t.out, e, t.playedOpts);
			let r = V(n, t.queue);
			e.animal === "giraffe" && r.moves.some((t) => t.id === e.id && t.to < t.from) && t.giraffeMoved.push(e.id), H(t, n, r, e.animal === "chameleon" ? t.playedOpts.as ?? e.animal : e.animal), t.beatMs = P.act;
			let i = U("act", t, e, r);
			return {
				state: t,
				fx: i ? [i] : []
			};
		}
		if (n.k === "recur") {
			let e = t.queue.find((e) => !t.recurDone.includes(e.id) && (e.animal === "hippo" || e.animal === "crocodile" || e.animal === "giraffe" && !t.giraffeMoved.includes(e.id)));
			if (e) {
				t.recurDone.push(e.id);
				let n = [...t.queue];
				e.animal === "hippo" ? L(t.queue, e, F) : e.animal === "crocodile" ? R(t.queue, t.out, e, F) : z(t.queue, e, F);
				let r = V(n, t.queue);
				H(t, n, r, e.animal), t.queue.some((e) => !t.recurDone.includes(e.id) && (e.animal === "hippo" || e.animal === "crocodile" || e.animal === "giraffe" && !t.giraffeMoved.includes(e.id))) && t.pending.unshift({ k: "recur" }), t.beatMs = r.moves.length + r.expelled.length > 0 ? P.recur : P.recurNoop;
				let i = U("recur", t, e, r);
				return {
					state: t,
					fx: i ? [i] : []
				};
			}
			return t.beatMs = P.recurNoop, {
				state: t,
				fx: []
			};
		}
		if (n.k === "check") {
			let e = le(t);
			return e ? (t.log.push({
				k: "enter",
				n: e.enter.length
			}, {
				k: "bounce",
				animal: e.bounced.animal
			}), t.beatMs = P.gate, {
				state: t,
				fx: [{
					kind: "check",
					data: {
						enter: e.enter.map((e, t) => ({
							id: e.id,
							animal: e.animal,
							owner: e.owner,
							from: t
						})),
						bounced: {
							id: e.bounced.id,
							animal: e.bounced.animal,
							owner: e.bounced.owner,
							from: 4
						}
					}
				}]
			}) : (t.beatMs = P.recurNoop, {
				state: t,
				fx: []
			});
		}
		let i = t.players[t.turnIdx], a = [];
		if (t.decks[i].length > 0) {
			let e = t.decks[i].shift();
			t.hands[i].push(e), a.push({
				kind: "draw",
				rid: i,
				data: {},
				for: [i],
				secret: { card: e }
			});
		}
		return t.playedId = null, t.playedOpts = {}, t.giraffeMoved = [], t.recurDone = [], t.players.every((e) => t.hands[e].length === 0 && t.decks[e].length === 0) ? t.phase = "done" : (t.turnIdx = (t.turnIdx + 1) % t.players.length, t.phase = "play"), t.beatMs = P.turn, {
			state: t,
			fx: a
		};
	}
	if (e.phase !== "play" || e.players[e.turnIdx] !== n.by) return { code: "games.beastybar.errNotYourTurn" };
	if (!ue(e.hands[n.by] ?? [], e.queue, t.animal).some((e) => e.as === t.as && e.target === t.target && (e.hop === void 0 ? t.hop === void 0 : e.hop === t.hop))) return (e.hands[n.by] ?? []).includes(t.animal) ? t.animal === "chameleon" ? { code: "games.beastybar.errBadSpecies" } : t.animal === "parrot" ? { code: "games.beastybar.errBadTarget" } : { code: "games.beastybar.errBadParam" } : { code: "games.beastybar.errBadCard" };
	let r = structuredClone(e);
	r.hands[n.by] = r.hands[n.by].filter((e) => e !== t.animal);
	let i = {
		id: r.nextEntryId,
		owner: n.by,
		animal: t.animal
	};
	return r.nextEntryId += 1, r.queue.push(i), r.playedId = i.id, r.playedOpts = {
		as: t.as,
		target: t.target,
		hop: t.hop
	}, r.giraffeMoved = [], r.recurDone = [], r.log.push({
		k: "play",
		rid: n.by,
		animal: t.animal,
		as: t.as
	}), r.pending = [
		{ k: "action" },
		{ k: "recur" },
		{ k: "check" },
		{ k: "end" }
	], r.phase = "resolving", r.beatMs = P.play, {
		state: r,
		fx: [{
			kind: "play",
			rid: n.by,
			data: {
				id: i.id,
				animal: i.animal,
				index: r.queue.length - 1,
				as: t.as ?? null
			}
		}]
	};
}
function he(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			queue: e.queue,
			out: e.out,
			players: e.players.map((t) => ({
				rid: t,
				handCount: e.hands[t].length,
				deckCount: e.decks[t].length,
				barCount: e.bar[t].length
			})),
			bars: e.phase === "done" ? e.bar : null,
			log: e.log
		},
		private: { hand: [...e.hands[t] ?? []].sort((e, t) => k[t] - k[e]) }
	};
}
function ge(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t, e.bar[t].reduce((e, t) => e + A[t], 0)])), n = [...e.players].sort((e, n) => t[n] - t[e]), r = t[n[0]];
	return {
		phase: "done",
		winner: n.filter((e) => t[e] === r),
		ranking: n,
		scores: t
	};
}
function _e(e) {
	return e.phase === "resolving" && e.pending.length > 0 ? e.beatMs : null;
}
var ve = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: S,
	schemas: {
		action: T,
		publicView: O,
		privateView: ne
	},
	setup: pe,
	reduce: me,
	viewFor: he,
	status: ge,
	nextTickIn: _e
};
//#endregion
//#region src/games/beastybar/paw-icon.tsx
function ye({ size: e = 16, color: t = "var(--color-ink)", className: n }) {
	return /* @__PURE__ */ _("svg", {
		width: e,
		height: e,
		viewBox: "0 0 64 64",
		fill: "none",
		"aria-hidden": !0,
		className: n,
		children: /* @__PURE__ */ v("g", {
			fill: t,
			children: [
				/* @__PURE__ */ _("ellipse", {
					cx: 32,
					cy: 41,
					rx: 12,
					ry: 9.5
				}),
				/* @__PURE__ */ _("circle", {
					cx: 15.5,
					cy: 26,
					r: 4.6
				}),
				/* @__PURE__ */ _("circle", {
					cx: 25.5,
					cy: 18.5,
					r: 4.8
				}),
				/* @__PURE__ */ _("circle", {
					cx: 38.5,
					cy: 18.5,
					r: 4.8
				}),
				/* @__PURE__ */ _("circle", {
					cx: 48.5,
					cy: 26,
					r: 4.6
				})
			]
		})
	});
}
//#endregion
//#region src/games/beastybar/card.tsx
function W(e) {
	return e ? g[e.colorIndex % g.length].hex : void 0;
}
function G({ animal: e, size: t, tint: n, style: r }) {
	let i = l(), a = t === "hand", o = t === "queue";
	return /* @__PURE__ */ v("span", {
		"aria-label": i("games.beastybar.cardAria", {
			animal: i(j[e]),
			s: k[e],
			p: A[e]
		}),
		className: `bb-animal-card bb-animal-card--${t} relative inline-flex flex-none flex-col overflow-hidden border-2 border-[#483041] bg-[#fff6e4] ${a ? "h-24 w-17 rounded-lg" : o ? "h-20 w-14 rounded-md" : "h-10 w-8 rounded-sm"}`,
		style: {
			...n ? { background: `color-mix(in srgb, ${n} 20%, #fff6e4)` } : {},
			...r
		},
		children: [
			/* @__PURE__ */ _("span", {
				"aria-hidden": !0,
				className: "absolute inset-x-0 top-0 h-[46%] bg-linear-to-b from-white/75 to-transparent"
			}),
			/* @__PURE__ */ _("span", {
				className: `bb-animal-strength absolute z-10 grid place-items-center rounded-br-md bg-[#483041] font-mono font-black leading-none text-[#fff6e4] ${a ? "left-0 top-0 size-5 text-xs" : o ? "left-0 top-0 size-4 text-[10px]" : "left-0 top-0 size-3 text-[8px]"}`,
				children: k[e]
			}),
			/* @__PURE__ */ _("img", {
				src: `/games/beastybar/${e}.webp`,
				alt: "",
				draggable: !1,
				className: `bb-animal-art relative mx-auto min-h-0 w-full flex-1 object-contain ${a ? "px-0.5 pt-3" : o ? "px-0.5 pt-2" : "pt-1.5"}`
			}),
			a && /* @__PURE__ */ _("span", {
				className: "bb-animal-name relative block w-full truncate border-t border-[#483041]/25 bg-[#fffaf0]/85 px-0.5 py-1 text-center text-[10px] font-bold leading-none text-[#483041]",
				children: i(j[e])
			}),
			/* @__PURE__ */ v("span", {
				className: `bb-animal-points absolute right-0 z-10 bg-[#f6c55c] font-mono font-black leading-none text-[#483041] ${a ? "top-0 rounded-bl px-1 py-0.5 text-[10px]" : o ? "bottom-0 rounded-tl px-0.5 py-0.5 text-[9px]" : "bottom-0 rounded-tl px-0.5 text-[7px]"}`,
				children: ["★", A[e]]
			})
		]
	});
}
function K({ size: e, style: t }) {
	return /* @__PURE__ */ v("span", {
		className: `bb-card-back bb-card-back--${e} relative inline-flex flex-none overflow-hidden rounded-md border-2 border-[#483041] ${e === "hand" ? "h-24 w-17" : "h-20 w-14"}`,
		style: {
			background: S.accent,
			...t
		},
		children: [/* @__PURE__ */ _("svg", {
			className: "absolute inset-0 size-full",
			viewBox: "0 0 44 64",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: /* @__PURE__ */ _("path", {
				d: "M-10 16 L54 -12 M-10 36 L54 8 M-10 56 L54 28 M-10 76 L54 48",
				stroke: "#ffffff",
				strokeWidth: 5,
				opacity: .14,
				fill: "none"
			})
		}), /* @__PURE__ */ _("span", {
			"aria-hidden": !0,
			className: "bb-card-back-mark absolute inset-0 grid place-items-center",
			children: /* @__PURE__ */ _(ye, {
				size: e === "hand" ? 28 : 22,
				color: "#ffffff"
			})
		})]
	});
}
function q({ member: e, animal: t, size: n, style: r }) {
	let i = W(e);
	return /* @__PURE__ */ v("span", {
		className: `bb-owned-animal bb-owned-animal--${n} relative inline-flex`,
		style: r,
		children: [/* @__PURE__ */ _(G, {
			animal: t,
			size: n,
			tint: i
		}), e && /* @__PURE__ */ _("img", {
			src: h[e.avatar % h.length],
			alt: "",
			draggable: !1,
			className: `bb-owner-badge absolute z-10 rounded-full border border-[#483041] object-contain ${n === "hand" ? "right-1 top-1 size-4" : n === "queue" ? "right-0.5 top-0.5 size-3.5" : "right-0 top-0 size-2.5"}`,
			style: { backgroundColor: i }
		})]
	});
}
//#endregion
//#region src/games/beastybar/view-player.tsx
function be(e) {
	return /* @__PURE__ */ _(xe, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function xe({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let o = l(), [c, m] = a(null), [h, g] = a(null), y = (e) => n.find((t) => t.rid === e)?.name ?? e, b = e.phase === "play" && e.turn === r, ee = t?.hand ?? [], x = e.players.find((e) => e.rid === r), C = (x?.handCount ?? 0) + (x?.deckCount ?? 0), w = [...new Set(e.queue.map((e) => e.animal))].filter((e) => e !== "chameleon"), T, E;
	e.phase === "resolving" ? (T = "info", E = o("games.beastybar.resolving")) : b ? (T = "accent", E = o("games.beastybar.turnPlay")) : (T = "info", E = o("games.beastybar.turnWait", { name: y(e.turn) }));
	let D = (e, t) => {
		i({
			type: "play",
			animal: e.animal,
			as: e.as,
			target: t.target,
			hop: t.hop
		}), m(null);
	}, te = (e) => {
		b ? (g(null), m((t) => t?.animal === e ? null : { animal: e })) : (m(null), g((t) => t === e ? null : e));
	}, O = (e) => {
		m(null), g((t) => t === e ? null : e);
	}, ne = () => {
		m(null), g(null);
	}, k = (t) => {
		if (!c) return;
		let n = {
			animal: "chameleon",
			as: t
		};
		t === "parrot" || t === "kangaroo" && e.queue.length >= 2 ? m(n) : D(n, t === "kangaroo" && e.queue.length === 1 ? { hop: 1 } : {});
	}, A = c?.as ?? c?.animal, M = !!c && c.animal === "chameleon" && !c.as && w.length > 0, N = !!c && A === "parrot" && e.queue.length > 0, P = !!c && A === "kangaroo" && e.queue.length >= 2, F = M ? "species" : N ? "target" : P ? "hop" : "info", I = c?.animal ?? h;
	return /* @__PURE__ */ _(u, {
		adaptive: !0,
		className: "bb-view",
		scroll: !1,
		banner: /* @__PURE__ */ v("div", {
			className: "bb-header flex flex-col gap-1.5",
			style: { "--bb-player-count": n.length },
			children: [/* @__PURE__ */ _(f, {
				tone: T,
				text: E,
				chip: o("games.beastybar.chipLeft", { n: C }),
				accent: S.accent
			}), /* @__PURE__ */ _(p, {
				variant: "plate",
				members: n,
				myRid: r,
				anchorOf: (e) => `seat:${e}`,
				action: (t) => e.phase === "play" && e.turn === t ? "pending" : null,
				status: (t) => {
					let n = e.players.find((e) => e.rid === t);
					return n ? /* @__PURE__ */ v("span", {
						className: "bb-player-status flex items-center gap-0.5 text-xs font-bold",
						"aria-label": o("games.beastybar.barAria", { n: n.barCount }),
						children: [/* @__PURE__ */ _("span", { children: o("games.beastybar.enteredShort") }), /* @__PURE__ */ _(s, {
							value: n.barCount,
							className: "font-mono tabular-nums"
						})]
					}) : null;
				}
			})]
		}),
		actionsHeight: "bb-actions h-28",
		actions: t ? /* @__PURE__ */ _(Ce, {
			hand: ee,
			deckCount: x?.deckCount ?? 0,
			myTurn: b,
			picked: c?.animal ?? null,
			onHand: te,
			tint: W(n.find((e) => e.rid === r))
		}) : null,
		overlay: I && /* @__PURE__ */ _(Se, {
			animal: I,
			pick: c,
			effective: A,
			mode: F,
			onClose: ne,
			onConfirm: () => {
				c && D(c, A === "kangaroo" && e.queue.length === 1 ? { hop: 1 } : {});
			}
		}),
		children: /* @__PURE__ */ v("div", {
			className: "bb-stage",
			children: [/* @__PURE__ */ _("div", {
				className: "bb-board",
				children: /* @__PURE__ */ v("div", {
					className: "bb-scene",
					children: [
						/* @__PURE__ */ _(Oe, { total: e.players.reduce((e, t) => e + t.barCount, 0) }),
						/* @__PURE__ */ _(Te, {
							pub: e,
							members: n,
							mode: F,
							imitable: w,
							onTarget: (e) => c && D(c, { target: e }),
							onSpecies: k,
							onHop: (e) => c && D(c, { hop: e }),
							onInfo: O
						}),
						/* @__PURE__ */ _(ke, { pub: e })
					]
				})
			}), /* @__PURE__ */ _("div", {
				className: "bb-log",
				children: /* @__PURE__ */ _(d, {
					log: e.log,
					line: (e) => {
						let t = (e) => e ? `${re[e]} ${o(j[e])}` : "?";
						return e.k === "play" ? e.as ? o("games.beastybar.logPlayAs", {
							name: y(e.rid ?? ""),
							animal: t(e.animal),
							as: t(e.as)
						}) : o("games.beastybar.logPlay", {
							name: y(e.rid ?? ""),
							animal: t(e.animal)
						}) : e.k === "expel" ? o("games.beastybar.logExpel", {
							by: t(e.by),
							animals: (e.animals ?? []).map(t).join("、")
						}) : e.k === "enter" ? o("games.beastybar.logEnter", { n: e.n ?? 2 }) : o("games.beastybar.logBounce", { animal: t(e.animal) });
					}
				})
			})]
		})
	});
}
function Se({ animal: e, pick: t, effective: n, mode: r, onClose: i, onConfirm: a }) {
	let o = l(), s = r === "target" ? o("games.beastybar.pickTarget") : r === "species" ? o("games.beastybar.pickSpecies") : r === "hop" ? o("games.beastybar.pickHop") : null;
	return /* @__PURE__ */ _("div", {
		className: "bb-overlay pointer-events-auto",
		children: /* @__PURE__ */ v("div", {
			className: "bb-panel",
			children: [
				/* @__PURE__ */ _(G, {
					animal: e,
					size: "mini"
				}),
				/* @__PURE__ */ v("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ v("p", {
						className: "truncate text-xs font-black",
						children: [o(j[e]), t?.as && /* @__PURE__ */ v("span", {
							className: "opacity-65",
							children: [" → ", o(j[t.as])]
						})]
					}), /* @__PURE__ */ _("p", {
						className: "bb-panel-copy",
						children: s ?? o(M[t ? n ?? e : e])
					})]
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					onClick: i,
					className: "bb-panel-action bb-panel-cancel",
					children: o(t ? "games.beastybar.cancel" : "games.beastybar.close")
				}),
				t && r === "info" && /* @__PURE__ */ _("button", {
					type: "button",
					onClick: a,
					className: "bb-panel-action bb-panel-play",
					style: { background: S.accent },
					children: o("games.beastybar.play")
				})
			]
		})
	});
}
function Ce({ hand: e, deckCount: t, myTurn: n, picked: r, onHand: i, tint: a }) {
	let { ref: s } = o("hand"), c = l();
	return /* @__PURE__ */ v("div", {
		className: "bb-hand safe-b flex h-full items-end gap-2 px-2 pb-1",
		children: [/* @__PURE__ */ _("div", {
			ref: s,
			className: "bb-hand-scroll min-w-0 flex-1 overflow-x-auto",
			children: /* @__PURE__ */ _("div", {
				className: "bb-hand-cards mx-auto flex w-max items-end gap-1.5 px-1 pt-2 pb-1",
				children: e.map((e) => /* @__PURE__ */ _("button", {
					type: "button",
					"aria-label": n ? c("games.beastybar.playAria", { animal: c(j[e]) }) : c("games.beastybar.cardAria", {
						animal: c(j[e]),
						s: k[e],
						p: A[e]
					}),
					onClick: () => i(e),
					className: `flex-none cursor-pointer transition-transform active:translate-y-0.5 ${n ? "" : "opacity-70"} ${r === e ? "-translate-y-2" : ""}`,
					children: /* @__PURE__ */ _(we, {
						animal: e,
						tint: a
					})
				}, e))
			})
		}), /* @__PURE__ */ _(je, { count: t })]
	});
}
function we({ animal: e, tint: t }) {
	let { ref: n, hidden: r } = o(`h:${e}`);
	return /* @__PURE__ */ _("span", {
		ref: n,
		className: "inline-flex",
		style: { visibility: r ? "hidden" : void 0 },
		children: /* @__PURE__ */ _(G, {
			animal: e,
			size: "hand",
			tint: t
		})
	});
}
function Te({ pub: e, members: t, mode: n, imitable: r, onTarget: i, onSpecies: a, onHop: s, onInfo: c }) {
	let u = l(), { ref: d } = o("queue");
	return /* @__PURE__ */ v("div", {
		className: "bb-queue",
		children: [
			/* @__PURE__ */ v("div", {
				className: "bb-queue-top",
				children: [/* @__PURE__ */ v("span", { children: ["← ", u("games.beastybar.queueFront")] }), /* @__PURE__ */ v("span", { children: [u("games.beastybar.queueBack"), " →"] })]
			}),
			/* @__PURE__ */ _("ul", {
				ref: d,
				className: "bb-slots",
				children: Array.from({ length: 5 }, (o, l) => {
					let d = e.queue[l], f = n === "hop" && d && l === e.queue.length - 1 ? 1 : n === "hop" && d && l === e.queue.length - 2 ? 2 : null, p = !!d && (n === "target" || n === "species" && r.includes(d.animal) || !!f), m = d && t.find((e) => e.rid === d.owner);
					return /* @__PURE__ */ _(Ee, {
						index: l,
						label: d ? u(p ? n === "hop" ? f === 1 ? "games.beastybar.hop1" : "games.beastybar.hop2" : n === "species" ? "games.beastybar.chooseSpecies" : "games.beastybar.chooseTarget" : j[d.animal]) : `${l + 1}`,
						children: d && /* @__PURE__ */ _(De, {
							entryId: d.id,
							animal: d.animal,
							member: m,
							selectable: p,
							mode: n,
							hop: f,
							onClick: () => {
								n === "target" ? i(d.id) : n === "species" && r.includes(d.animal) ? a(d.animal) : f ? s(f) : c(d.animal);
							}
						})
					}, l);
				})
			}),
			/* @__PURE__ */ _("p", {
				className: "bb-queue-rule",
				children: u("games.beastybar.queueRule")
			})
		]
	});
}
function Ee({ index: e, label: t, children: n }) {
	let { ref: r } = o(`qslot:${e}`);
	return /* @__PURE__ */ v("li", {
		className: "bb-slot",
		children: [/* @__PURE__ */ _("div", {
			ref: r,
			className: "bb-slot-face",
			children: n ?? /* @__PURE__ */ _("span", {
				"aria-hidden": !0,
				className: "bb-empty-mark",
				children: /* @__PURE__ */ _("span", { children: e + 1 })
			})
		}), /* @__PURE__ */ _("span", {
			className: "bb-slot-label",
			children: t
		})]
	});
}
function De({ entryId: e, animal: t, member: n, selectable: r, mode: i, hop: a, onClick: s }) {
	let c = l(), { ref: u, hidden: d } = o(`q:${e}`), f = i === "target" ? c("games.beastybar.targetAria", { animal: c(j[t]) }) : i === "species" && r ? c("games.beastybar.speciesAria", { animal: c(j[t]) }) : a ? c("games.beastybar.hopAria", {
		n: a,
		animal: c(j[t])
	}) : c("games.beastybar.cardAria", {
		animal: c(j[t]),
		s: k[t],
		p: A[t]
	});
	return /* @__PURE__ */ _("button", {
		type: "button",
		"aria-label": f,
		onClick: s,
		disabled: i !== "info" && !r,
		className: `bb-queue-card ${r ? "bb-queue-card--target" : i === "info" ? "" : "bb-queue-card--muted"}`,
		children: /* @__PURE__ */ _("span", {
			ref: u,
			className: "inline-flex",
			style: { visibility: d ? "hidden" : void 0 },
			children: /* @__PURE__ */ _(q, {
				member: n,
				animal: t,
				size: "queue"
			})
		})
	});
}
function Oe({ total: e }) {
	let { ref: t } = o("bar"), n = l();
	return /* @__PURE__ */ v("div", {
		className: "bb-bar",
		"aria-label": n("games.beastybar.barAria", { n: e }),
		children: [
			/* @__PURE__ */ v("svg", {
				viewBox: "0 0 304 145",
				className: "bb-door-large",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ _("rect", {
						x: "4",
						y: "28",
						width: "296",
						height: "112",
						rx: "15",
						fill: "#d9b9e8",
						stroke: "#483041",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ _("rect", {
						x: "18",
						y: "70",
						width: "84",
						height: "68",
						rx: "9",
						fill: "#5d3a76",
						stroke: "#483041",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ _("path", {
						d: "M31 137V84q0-9 9-9h53v62Z",
						fill: "#f3bf61",
						stroke: "#483041",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ _("circle", {
						cx: "82",
						cy: "108",
						r: "3",
						fill: "#fff2ce",
						stroke: "#483041",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ _("path", {
						d: "M6 64h292l-8 22q-11 13-24 0-13 13-26 0-13 13-26 0-13 13-26 0-13 13-26 0-13 13-26 0-13 13-26 0-13 13-26 0-13 13-26 0-13 13-26 0Z",
						fill: "#8f43d7",
						stroke: "#483041",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ _("rect", {
						x: "178",
						y: "94",
						width: "108",
						height: "39",
						rx: "9",
						fill: "#fff5df",
						stroke: "#483041",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ _("rect", {
						x: "91",
						y: "5",
						width: "122",
						height: "42",
						rx: "11",
						fill: "#ffe3a7",
						stroke: "#483041",
						strokeWidth: "3"
					})
				]
			}),
			/* @__PURE__ */ v("svg", {
				viewBox: "0 0 112 87",
				className: "bb-door-small",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ _("path", {
						d: "M8 77V32Q8 9 56 9t48 23v45Z",
						fill: "#624584",
						stroke: "#473044",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ _("path", {
						d: "M22 76V34Q22 22 56 22t34 12v42Z",
						fill: "#f5bc5e",
						stroke: "#473044",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ _("path", {
						d: "M28 76V40Q28 31 56 31t28 9v36Z",
						fill: "#bd7049"
					}),
					/* @__PURE__ */ _("path", {
						d: "M10 29h92l-6 15H16Z",
						fill: "#ef7281",
						stroke: "#473044",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ _("path", {
						d: "M26 32v10m20-10v10m20-10v10m20-10v10",
						stroke: "#fff1cc",
						strokeWidth: "7"
					}),
					/* @__PURE__ */ _("circle", {
						cx: "70",
						cy: "55",
						r: "3",
						fill: "#ffe6a2"
					})
				]
			}),
			/* @__PURE__ */ _("span", {
				className: "bb-bar-sign",
				children: n("games.beastybar.name")
			}),
			/* @__PURE__ */ _("span", {
				className: "bb-bar-pile-label",
				children: n("games.beastybar.barLabel")
			}),
			/* @__PURE__ */ _("span", {
				ref: t,
				className: "bb-bar-back",
				children: /* @__PURE__ */ _(K, { size: "queue" })
			}),
			/* @__PURE__ */ _("span", {
				className: "bb-pile-count",
				children: e
			}),
			/* @__PURE__ */ _("span", {
				className: "bb-pile-title",
				children: n("games.beastybar.barLabel")
			})
		]
	});
}
function ke({ pub: e }) {
	let { ref: t } = o("out"), n = l(), r = e.out.slice(-3);
	return /* @__PURE__ */ v("div", {
		className: "bb-out",
		children: [
			/* @__PURE__ */ v("div", {
				ref: t,
				className: "bb-out-plate",
				children: [r.length === 0 && /* @__PURE__ */ _("span", {
					className: "bb-out-empty",
					"aria-hidden": "true",
					children: "×"
				}), r.map((e, t) => {
					let n = t - (r.length - 1);
					return t === r.length - 1 ? /* @__PURE__ */ _(Ae, { animal: e.animal }, e.id) : /* @__PURE__ */ _("span", {
						"aria-hidden": !0,
						className: "bb-out-card",
						style: { transform: `translate(${n * 4}px, ${n * 2}px) rotate(${n * 7}deg)` },
						children: /* @__PURE__ */ _(G, {
							animal: e.animal,
							size: "mini"
						})
					}, e.id);
				})]
			}),
			/* @__PURE__ */ _("span", {
				className: "bb-pile-count",
				children: e.out.length
			}),
			/* @__PURE__ */ _("span", {
				className: "bb-pile-title",
				children: n("games.beastybar.outLabel")
			})
		]
	});
}
function Ae({ animal: e }) {
	let { ref: t, hidden: n } = o("out:top");
	return /* @__PURE__ */ _("span", {
		ref: t,
		className: "bb-out-card",
		style: { visibility: n ? "hidden" : void 0 },
		children: /* @__PURE__ */ _(G, {
			animal: e,
			size: "mini"
		})
	});
}
function je({ count: e }) {
	let { ref: t } = o("deck"), n = l();
	return /* @__PURE__ */ v("div", {
		ref: t,
		"aria-label": n("games.beastybar.deckAria", { n: e }),
		className: "bb-deck relative mb-1 flex-none",
		children: [/* @__PURE__ */ _(K, { size: "queue" }), /* @__PURE__ */ _("span", {
			className: "bb-deck-count",
			children: e
		})]
	});
}
//#endregion
//#region src/games/beastybar/bot.ts
function Me(e, t) {
	let n = [];
	for (let r of new Set(e)) for (let i of ue(e, t, r)) n.push({
		animal: r,
		...i
	});
	return n;
}
function Ne(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
}
var Pe = [
	1,
	.8,
	.55,
	.3,
	.1
];
function Fe(e, t, n) {
	let r = {
		id: 1e9,
		owner: t,
		animal: n.animal
	}, i = de(e.queue, r, n), a = (e) => e === t ? 1 : -1, o = 0;
	for (let e of i.barGains) o += a(e.owner) * A[e.animal] * 3;
	return i.bounced && (o += a(i.bounced.owner) * A[i.bounced.animal] * 1.5), i.queue.forEach((e, t) => {
		o += a(e.owner) * A[e.animal] * Pe[Math.min(t, Pe.length - 1)];
	}), o + Ne(100) / 1e4;
}
var Ie = (e, t) => {
	let n = e.public;
	if (n.phase !== "play" || n.turn !== t.rid) return null;
	let r = Me(e.private?.hand ?? [], n.queue);
	if (r.length === 0) return null;
	if (t.difficulty === "weak") {
		let e = r[Ne(r.length)];
		return { action: {
			type: "play",
			animal: e.animal,
			as: e.as,
			target: e.target,
			hop: e.hop
		} };
	}
	let i = r[0], a = -Infinity;
	for (let e of r) {
		let r = Fe(n, t.rid, e);
		r > a && (a = r, i = e);
	}
	return { action: {
		type: "play",
		animal: i.animal,
		as: i.as,
		target: i.target,
		hop: i.hop
	} };
}, Le = (e, t, n) => {
	if (e.type !== "play") return "";
	let r = n(j[e.animal]);
	if (e.as) return n("games.beastybar.hintPlayAs", {
		animal: r,
		as: n(j[e.as])
	});
	if (e.target != null) {
		let i = t.public.queue.find((t) => t.id === e.target);
		if (i) return n("games.beastybar.hintPlayTarget", {
			animal: r,
			target: n(j[i.animal])
		});
	}
	return e.hop ? n("games.beastybar.hintPlayHop", {
		animal: r,
		n: e.hop
	}) : n("games.beastybar.playAria", { animal: r });
}, J = {
	name: "野兽酒吧",
	desc: "十二种动物排队挤酒吧,打出、挤压、驱逐,把高分动物送进酒吧",
	rules: "目标：\n所有玩家打出全部12张动物牌后，酒吧内动物的分值总和最高者获胜。\n流程：\n· 每人拥有相同的12张动物牌，从狮子到臭鼬各1张。玩家轮流打出1张动物牌，将其排到队尾。\n· 动物入队时，立即发动自身能力。各种动物的能力见下方图鉴。\n· 此后，从队首到队尾检查河马、鳄鱼和长颈鹿，并分别再发动1次它们的能力。\n· 队伍达到5只动物时，最前方的2只动物进入酒吧，面朝下放置并留待计分；队尾的1只动物被淘汰。",
	turnPlay: "轮到你:打一张动物牌",
	turnWait: "等 {{name}} 出牌…",
	resolving: "结算能力中…",
	chipLeft: "剩 {{n}} 张",
	outLabel: "淘汰",
	barLabel: "酒吧",
	enteredShort: "入场",
	deckAria: "牌堆还剩 {{n}} 张",
	pickSpecies: "点队里一只动物模仿",
	pickTarget: "点队里一只动物踢走",
	pickHop: "点队列中的落点，选择跳过 1 或 2 只",
	chooseSpecies: "模仿",
	chooseTarget: "踢走",
	speciesAria: "模仿{{animal}}",
	hopAria: "跳过 {{n}} 只，落在{{animal}}前",
	queueFront: "队首 · 入场",
	queueBack: "队尾 · 排队",
	queueRule: "满 5 只：前 2 只入场，最后 1 只淘汰",
	play: "打出",
	hop1: "跳 1 只",
	hop2: "跳 2 只",
	cancel: "取消",
	close: "关闭",
	playAria: "打出{{animal}}",
	cardAria: "{{animal}},强度 {{s}},{{p}} 分",
	targetAria: "踢走{{animal}}",
	barAria: "酒吧里 {{n}} 只",
	finalBar: "进酒吧 {{n}} 只",
	finalEmpty: "一只都没挤进去",
	logPlay: "{{name}} 打出 {{animal}}",
	logPlayAs: "{{name}} 打出 {{animal}} 模仿 {{as}}",
	logExpel: "{{by}} 驱逐了 {{animals}}",
	logEnter: "队首 {{n}} 只挤进酒吧",
	logBounce: "{{animal}} 被挤出局",
	logEmpty: "还没有动静,打出的牌会记在这里",
	errNotYourTurn: "还没轮到你",
	errBadCard: "手里没有这张牌",
	errBadSpecies: "变色龙必须模仿队里的一种动物",
	errBadTarget: "要选队里的一只动物",
	errBadParam: "这步操作不合法",
	a: {
		lion: "狮子",
		hippo: "河马",
		crocodile: "鳄鱼",
		snake: "蛇",
		giraffe: "长颈鹿",
		zebra: "斑马",
		seal: "海豹",
		chameleon: "变色龙",
		monkey: "猴子",
		kangaroo: "袋鼠",
		parrot: "鹦鹉",
		skunk: "臭鼬"
	},
	e: {
		lion: "狮子入队时，如果队伍中已有其他狮子，这只新入队的狮子被淘汰；否则，驱逐队伍中的所有猴子，并移到队首。",
		hippo: "河马依次越过正前方强度低于自己的动物；遇到斑马或强度不低于自己的动物时，停止前进。",
		crocodile: "鳄鱼依次淘汰正前方强度低于自己的动物；遇到斑马或强度不低于自己的动物时，停止行动。",
		snake: "将队伍中的所有动物按强度从高到低重新排列；强度相同的动物保持原有相对顺序。",
		giraffe: "如果正前方动物的强度低于长颈鹿，长颈鹿越过该动物。本回合已经越过动物的长颈鹿，不会在后续循环结算中再次行动。",
		zebra: "斑马入队时不移动。河马和鳄鱼不能越过或淘汰斑马，因此斑马也会保护排在它前方的动物。",
		seal: "交换队首与队尾的方向，使整个队伍的顺序反转。",
		chameleon: "选择队伍中除变色龙以外的一种动物，模仿该动物的强度和能力；本次能力结算完毕后，恢复变色龙的强度。没有可模仿的动物时，不发动能力。",
		monkey: "如果队伍中至少有两只猴子，驱逐所有河马和鳄鱼，再将猴群移到队首；新入队的猴子排在最前，其余猴子的相对顺序反转。只有一只猴子时，不发动能力。",
		kangaroo: "选择向前越过1只或2只动物；被越过动物的强度不影响此能力。",
		parrot: "选择队伍中的另一只动物，将其淘汰。",
		skunk: "驱逐队伍中强度最高和次高的动物；同一强度的动物全部被驱逐，臭鼬不受此能力影响。"
	},
	hintPlayAs: "打出{{animal}}模仿{{as}}",
	hintPlayTarget: "打出{{animal}}踢走{{target}}",
	hintPlayHop: "打出{{animal}}向前跳 {{n}} 只"
}, Re = (e) => 12 - C.indexOf(e), ze = {
	needsAction: (e, t) => e.public.phase === "play" && e.public.turn === t.rid,
	describeView(e, t) {
		let n = e.public, r = (e) => `${e}(${J.a[e]},强度${Re(e)})`, i = ["目标:12 张牌打完后,自己挤进酒吧的动物强度总和最高。队伍每满 5 只:前 2 只进酒吧(计分),最后 1 只淘汰。物种一律用英文枚举值输出。", "动物能力: " + C.map((e) => `${r(e)}——${J.e[e]}`).join(";")];
		i.push(`排队区(0 = 最靠近入口,满 5 触发结算): ${n.queue.map((e) => `#${e.id} ${r(e.animal)}${e.owner === t.rid ? "(你的)" : ""}`).join(" → ") || "(空)"}`), i.push(`淘汰堆: ${n.out.map((e) => J.a[e.animal]).join(", ") || "(空)"}`);
		let a = n.players.find((e) => e.rid === t.rid);
		i.push(`各人进度: ${n.players.map((e) => `${e.rid === t.rid ? "你" : e.rid}: 手牌${e.handCount} 已进酒吧${e.barCount}`).join("; ")}`);
		let o = e.private?.hand ?? [];
		return i.push(`你的手牌(${a ? `牌堆还剩 ${a.deckCount} 张` : ""}): ${o.map(r).join(", ")}`), i.push("轮到你,输出 play 行动。变色龙必须带 as(队里的一种物种),鹦鹉必须带 target(队里条目 id),袋鼠可带 hop=1 或 2。"), i.join("\n");
	},
	actionJsonSchema: {
		type: "object",
		properties: {
			type: { const: "play" },
			animal: { enum: C },
			as: {
				enum: C,
				description: "仅变色龙:模仿队里在场的一种物种"
			},
			target: {
				type: "integer",
				description: "仅鹦鹉:队里条目 id"
			},
			hop: {
				type: "integer",
				enum: [1, 2],
				description: "仅袋鼠:跳 1 或 2 只"
			}
		},
		required: ["type", "animal"],
		additionalProperties: !1
	},
	parseAction(e, t, n) {
		let r = T.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public;
		if (a.phase !== "play" || a.turn !== n.rid || !(t.private?.hand ?? []).includes(i.animal)) return null;
		let o = new Set(a.queue.map((e) => e.animal)), s = new Set(a.queue.map((e) => e.id));
		if (i.animal === "chameleon") {
			if (!i.as || !o.has(i.as)) return null;
		} else if (i.as != null) return null;
		if (i.animal === "parrot") {
			if (i.target == null || !s.has(i.target)) return null;
		} else if (i.target != null) return null;
		return i.hop != null && i.animal !== "kangaroo" ? null : i;
	}
};
//#endregion
//#region src/games/beastybar/fx.tsx
function Y(e, t) {
	return {
		[`--bb-${t}-w`]: `${e.w}px`,
		[`--bb-${t}-h`]: `${e.h}px`
	};
}
function X(e, t) {
	return e.anchor(`qslot:${t}`);
}
function Z(e) {
	let t = e.anchor("queue"), n = X(e, 0);
	return !t || !n ? null : {
		x: t.x + (t.w - n.w) / 2,
		y: n.y,
		w: n.w,
		h: n.h
	};
}
function Be({ ms: e, delay: t, children: r }) {
	let a = i(null);
	return n(() => {
		let n = a.current;
		if (!n) return;
		let r = n.animate([{ transform: "rotate(0deg)" }, { transform: "rotate(360deg)" }], {
			duration: e,
			delay: t,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => r.cancel();
	}, [e, t]), /* @__PURE__ */ _("span", {
		ref: a,
		className: "inline-flex",
		children: r
	});
}
function Q(e) {
	return Array.isArray(e) ? e.filter((e) => typeof e == "object" && !!e && typeof e.id == "number" && typeof e.from == "number") : [];
}
function Ve(e, t, n) {
	let r = e.data, i = Q(r?.moves), a = Q(r?.expelled);
	if (!i.length && !a.length) return null;
	let o = t.anchor("out:top") ?? t.anchor("out"), s = [], c = [];
	for (let e of i) {
		let r = X(t, e.from), i = typeof e.to == "number" ? X(t, e.to) : null;
		r && i && (c.push(`q:${e.id}`), s.push(/* @__PURE__ */ _(b, {
			from: r,
			to: i,
			ms: n - 120,
			children: /* @__PURE__ */ _(q, {
				member: t.member(e.owner),
				animal: e.animal,
				size: "queue",
				style: Y(r, "queue")
			})
		}, `m${e.id}`)));
	}
	return a.forEach((e, r) => {
		let i = X(t, e.from);
		i && o && (r === a.length - 1 && c.push("out:top"), s.push(/* @__PURE__ */ _(b, {
			from: i,
			to: o,
			ms: n - 160,
			delay: r * 90,
			children: /* @__PURE__ */ _(q, {
				member: t.member(e.owner),
				animal: e.animal,
				size: "queue",
				style: Y(i, "queue")
			})
		}, `e${e.id}`)));
	}), s.length ? {
		ms: n,
		node: s,
		hide: c
	} : null;
}
var He = {
	deal(e, t) {
		let n = e.secret;
		if (n && Array.isArray(n.cards)) {
			let r = t.anchor("deck") ?? Z(t);
			if (!r) return null;
			let i = [], a = [];
			for (let [o, s] of n.cards.entries()) {
				let n = t.anchor(`h:${s}`);
				n && (a.push(`h:${s}`), i.push(/* @__PURE__ */ _(b, {
					from: r,
					to: n,
					ms: 320,
					delay: o * 45,
					children: /* @__PURE__ */ _(G, {
						animal: s,
						size: "hand",
						tint: W(e.rid ? t.member(e.rid) : void 0),
						style: Y(n, "hand")
					})
				}, `${s}${o}`)));
			}
			return i.length ? {
				ms: 320 + i.length * 45,
				node: i,
				hide: a
			} : null;
		}
		let r = Z(t), i = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!r || !i) return null;
		let a = e.data?.count, o = typeof a == "number" ? a : 4;
		return {
			ms: 320 + o * 45,
			node: Array.from({ length: o }, (e, t) => /* @__PURE__ */ _(b, {
				from: r,
				to: i,
				ms: 320,
				delay: t * 45,
				children: /* @__PURE__ */ _(K, {
					size: "queue",
					style: Y(r, "queue")
				})
			}, t))
		};
	},
	play(e, t) {
		let n = e.data;
		if (typeof n?.id != "number" || typeof n.animal != "string") return null;
		let r = n.animal, i = t.anchor(`q:${n.id}`);
		if (!i) return null;
		let a = (e.rid === t.myRid ? t.anchor("hand") : e.rid ? t.anchor(`seat:${e.rid}`) : null) ?? Z(t);
		return a ? {
			ms: P.play,
			node: /* @__PURE__ */ _(b, {
				from: a,
				to: i,
				ms: P.play - 100,
				children: /* @__PURE__ */ _(q, {
					member: e.rid ? t.member(e.rid) : void 0,
					animal: r,
					size: "queue",
					style: Y(i, "queue")
				})
			}),
			hide: [`q:${n.id}`]
		} : null;
	},
	act(e, t) {
		return Ve(e, t, P.act);
	},
	recur(e, t) {
		return Ve(e, t, P.recur);
	},
	check(e, t) {
		let n = e.data, r = Q(n?.enter), i = Q(n?.bounced ? [n.bounced] : []);
		if (!r.length && !i.length) return null;
		let a = t.anchor("bar"), o = t.anchor("out:top") ?? t.anchor("out"), s = [], c = [];
		return r.forEach((e, n) => {
			let r = X(t, e.from);
			r && a && s.push(/* @__PURE__ */ _(b, {
				from: r,
				to: a,
				ms: P.gate - 200,
				delay: n * 110,
				children: /* @__PURE__ */ _(Be, {
					ms: P.gate - 200,
					delay: n * 110,
					children: /* @__PURE__ */ _(q, {
						member: t.member(e.owner),
						animal: e.animal,
						size: "queue",
						style: Y(r, "queue")
					})
				})
			}, `b${e.id}`));
		}), i.forEach((e, n) => {
			let i = X(t, e.from);
			i && o && (c.push("out:top"), s.push(/* @__PURE__ */ _(b, {
				from: i,
				to: o,
				ms: P.gate - 240,
				delay: r.length * 110 + n * 90,
				children: /* @__PURE__ */ _(q, {
					member: t.member(e.owner),
					animal: e.animal,
					size: "queue",
					style: Y(i, "queue")
				})
			}, `k${e.id}`)));
		}), a && r.length && (s.push(/* @__PURE__ */ _(ee, {
			at: a,
			ms: 200,
			delay: P.gate - 200
		}, "barPulse")), s.push(/* @__PURE__ */ _(y, {
			at: a,
			ms: 380,
			delay: P.gate - 200,
			children: /* @__PURE__ */ v("span", {
				style: {
					fontSize: Math.max(14, Math.min(30, a.w * .42)),
					lineHeight: 1
				},
				children: ["🍸×", r.length]
			})
		}, "barFloat"))), s.length ? {
			ms: P.gate,
			node: s,
			hide: c
		} : null;
	},
	draw(e, t) {
		let n = e.secret;
		if (n && typeof n.card == "string") {
			let r = n.card, i = t.anchor("deck"), a = t.anchor(`h:${r}`);
			return !i || !a ? null : {
				ms: 380,
				node: /* @__PURE__ */ _(b, {
					from: i,
					to: a,
					ms: 320,
					children: /* @__PURE__ */ _(G, {
						animal: r,
						size: "hand",
						tint: W(e.rid ? t.member(e.rid) : void 0),
						style: Y(a, "hand")
					})
				}),
				hide: [`h:${r}`]
			};
		}
		let r = Z(t), i = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || !i ? null : {
			ms: 380,
			node: /* @__PURE__ */ _(b, {
				from: r,
				to: i,
				ms: 320,
				children: /* @__PURE__ */ _(K, {
					size: "queue",
					style: Y(r, "queue")
				})
			})
		};
	}
}, $ = 14, Ue = 96, We = 220;
function Ge(e, t, n) {
	let r = 1, i = 0;
	for (let a = 1; a <= e; a++) {
		let o = Math.ceil(e / a), s = Math.min((t - $ * (a - 1)) / a, (n - $ * (o - 1)) * .8 / o);
		s > i && (i = s, r = a);
	}
	i < Ue && (r = Math.max(1, Math.min(e, Math.floor((t + $) / 110))));
	let a = Math.floor(Math.min(We, Math.max(Ue, i)) * 100) / 100, o = Math.ceil(e / r);
	return {
		columns: r,
		cardWidth: a,
		minHeight: o * a * 1.25 + $ * (o - 1)
	};
}
function Ke({ animals: e, playerCount: t }) {
	let n = l(), a = i(null);
	return r(() => {
		let n = a.current, r = n?.closest(".bb-result-player"), i = n?.closest(".bb-result-ranks"), o = r?.querySelector(".bb-result-player-heading");
		if (!n || !r || !i || !o) return;
		let s = (e, t) => {
			n.style.getPropertyValue(e) !== t && n.style.setProperty(e, t);
		}, c = () => {
			if (getComputedStyle(n).getPropertyValue("--bb-result-grid").trim() !== "1") {
				for (let e of [
					"--bb-mini-w",
					"--bb-mini-h",
					"--bb-result-columns",
					"--bb-result-grid-min-h"
				]) n.style.removeProperty(e);
				return;
			}
			let a = getComputedStyle(i), c = getComputedStyle(r), l = (e) => Number.parseFloat(e) || 0, u = Math.ceil(t / 2), d = i.clientHeight - l(a.paddingTop) - l(a.paddingBottom), f = Math.max(t > 2 ? 340 : 0, (d - l(a.rowGap) * (u - 1)) / u) - o.getBoundingClientRect().height - l(c.rowGap) - l(c.paddingTop) - l(c.paddingBottom) - l(c.borderTopWidth) - l(c.borderBottomWidth), p = n.clientWidth;
			if (p <= 0 || f <= 0) return;
			let m = Ge(e.length, p, f);
			s("--bb-result-columns", String(m.columns)), s("--bb-mini-w", `${m.cardWidth}px`), s("--bb-mini-h", `${m.cardWidth * 1.25}px`), s("--bb-result-grid-min-h", `${m.minHeight}px`);
		};
		c();
		let l = new ResizeObserver(c);
		for (let e of [
			n,
			i,
			o
		]) l.observe(e);
		return () => l.disconnect();
	}, [e.length, t]), /* @__PURE__ */ _("ul", {
		ref: a,
		className: "bb-result-animals flex flex-wrap gap-1",
		"aria-label": n("games.beastybar.finalBar", { n: e.length }),
		children: e.map((e, t) => /* @__PURE__ */ _("li", { children: /* @__PURE__ */ _(G, {
			animal: e,
			size: "mini"
		}) }, t))
	});
}
function qe({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let a = l(), o = c((e) => e.locale), s = t, u = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? m(t, o) : e;
	}, d = r ?? i;
	return /* @__PURE__ */ _("div", {
		className: "bb-result",
		"data-player-count": e.ranking.length,
		style: { "--bb-result-accent": S.accent },
		children: /* @__PURE__ */ v("div", {
			className: "bb-result-layout relative flex h-full min-h-0 flex-col items-center gap-2 overflow-y-auto",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ _(x, {}),
				/* @__PURE__ */ v("h1", {
					className: "bb-result-title flex flex-none items-center gap-2 text-center font-display text-xl font-extrabold",
					children: [/* @__PURE__ */ _("span", {
						"aria-hidden": !0,
						children: S.icon
					}), a("session.result.title")]
				}),
				/* @__PURE__ */ _("div", {
					className: "bb-result-ranks flex w-full max-w-md flex-none flex-col gap-2",
					children: e.ranking.map((t, r) => {
						let i = [...s.bars?.[t] ?? []].sort((e, t) => A[t] - A[e]), o = e.winner.includes(t), c = n.find((e) => e.rid === t);
						return /* @__PURE__ */ v("section", {
							className: "bb-result-player frame flex flex-col gap-1.5 p-2.5",
							"data-winner": o,
							children: [/* @__PURE__ */ v("header", {
								className: "bb-result-player-heading flex items-center gap-2",
								children: [
									/* @__PURE__ */ _("span", {
										"aria-hidden": !0,
										className: `bb-result-trophy w-5 flex-none text-center ${o ? "" : "invisible"}`,
										children: "🏆"
									}),
									c && /* @__PURE__ */ _("span", {
										className: "bb-result-avatar hidden",
										style: { backgroundColor: W(c) },
										children: /* @__PURE__ */ _("img", {
											src: h[c.avatar % h.length],
											alt: "",
											draggable: !1
										})
									}),
									/* @__PURE__ */ v("span", {
										className: "bb-result-name min-w-0 flex-1 truncate text-sm font-extrabold",
										children: [
											r + 1,
											". ",
											u(t)
										]
									}),
									/* @__PURE__ */ _("span", {
										className: "bb-result-score flex-none font-mono text-lg font-extrabold tabular-nums",
										children: e.scores?.[t] ?? 0
									})
								]
							}), i.length > 0 ? /* @__PURE__ */ _(Ke, {
								animals: i,
								playerCount: e.ranking.length
							}) : /* @__PURE__ */ _("p", {
								className: "bb-result-empty text-xs font-bold text-ink/60",
								children: a("games.beastybar.finalEmpty")
							})]
						}, t);
					})
				}),
				d ? /* @__PURE__ */ v("div", {
					className: "bb-result-controls safe-b flex w-full max-w-sm flex-none flex-col gap-2 pb-1",
					children: [r && /* @__PURE__ */ _("button", {
						className: "btn-base w-full cursor-pointer text-white",
						style: { background: S.accent },
						onClick: r,
						children: a("session.result.playAgain")
					}), i && /* @__PURE__ */ _("button", {
						className: "btn-quiet w-full cursor-pointer",
						onClick: i,
						children: a("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ _("p", {
					className: "bb-result-wait safe-b flex-none pb-1 text-sm font-bold opacity-70",
					children: a("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/games/beastybar/guide.tsx
function Je() {
	let e = l();
	return /* @__PURE__ */ _("ul", {
		className: "flex w-full flex-col gap-2",
		children: C.map((t) => /* @__PURE__ */ v("li", {
			className: "frame flex items-center gap-3 p-2",
			children: [/* @__PURE__ */ _(G, {
				animal: t,
				size: "queue"
			}), /* @__PURE__ */ v("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ _("p", {
					className: "text-sm font-extrabold",
					children: e(j[t])
				}), /* @__PURE__ */ _("p", {
					className: "text-xs leading-5 font-bold opacity-70",
					children: e(M[t])
				})]
			})]
		}, t))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/beastybar/entry.tsx
var Ye = {
	definition: ve,
	View: be,
	bot: Ie,
	describe: Le,
	llm: ze,
	fx: He,
	OverView: qe,
	Guide: Je,
	locales: {
		zh: J,
		en: {
			name: "Beasty Bar",
			desc: "Animals queue for the bar — shove, eat and bounce your high-value animals into the bar",
			rules: "Goal: after everyone has played all 12 cards, the animals in your bar score — the highest total wins.\nPlay:\n· Everyone has the same 12 animal cards (lion through skunk); on your turn, play one to the back of the line.\n· The animal’s ability triggers at once (each ability is listed in the gallery below).\n· Afterwards, hippos, crocodiles and giraffes act once more, from front to back.\n· Whenever the line reaches 5: the front 2 squeeze into the bar (face down, worth points), and the last one is out.",
			turnPlay: "Your turn: play an animal",
			turnWait: "Waiting for {{name}}…",
			resolving: "Resolving…",
			chipLeft: "{{n}} left",
			outLabel: "Out",
			barLabel: "Bar",
			enteredShort: "In",
			deckAria: "{{n}} left in your deck",
			pickSpecies: "Tap an animal in line to imitate",
			pickTarget: "Tap an animal in line to bounce",
			pickHop: "Tap a landing spot to hop past 1 or 2 animals",
			chooseSpecies: "Copy",
			chooseTarget: "Bounce",
			speciesAria: "Imitate {{animal}}",
			hopAria: "Hop past {{n}} and land before {{animal}}",
			queueFront: "Front · enters",
			queueBack: "Back · lines up",
			queueRule: "At 5: first 2 enter, last 1 goes out",
			play: "Play",
			hop1: "Hop 1",
			hop2: "Hop 2",
			cancel: "Cancel",
			close: "Close",
			playAria: "Play {{animal}}",
			cardAria: "{{animal}}, strength {{s}}, {{p}} pts",
			targetAria: "Bounce {{animal}}",
			barAria: "{{n}} in the bar",
			finalBar: "{{n}} in the bar",
			finalEmpty: "None made it in",
			logPlay: "{{name}} plays {{animal}}",
			logPlayAs: "{{name}} plays {{animal}} imitating {{as}}",
			logExpel: "{{by}} drives off {{animals}}",
			logEnter: "Front {{n}} squeeze into the bar",
			logBounce: "{{animal}} is out",
			logEmpty: "Nothing yet — plays will be logged here",
			errNotYourTurn: "Not your turn",
			errBadCard: "You don't have that animal",
			errBadSpecies: "Chameleon must imitate an animal in line",
			errBadTarget: "Pick an animal in line",
			errBadParam: "Illegal move",
			a: {
				lion: "Lion",
				hippo: "Hippo",
				crocodile: "Crocodile",
				snake: "Snake",
				giraffe: "Giraffe",
				zebra: "Zebra",
				seal: "Seal",
				chameleon: "Chameleon",
				monkey: "Monkey",
				kangaroo: "Kangaroo",
				parrot: "Parrot",
				skunk: "Skunk"
			},
			e: {
				lion: "When a Lion joins the line, it is eliminated if another Lion is already there. Otherwise, it drives off every Monkey in the line and moves to the front.",
				hippo: "The Hippo passes weaker animals directly ahead, one at a time. It stops at a Zebra or an animal whose strength is equal to or higher than its own.",
				crocodile: "The Crocodile eliminates weaker animals directly ahead, one at a time. It stops at a Zebra or an animal whose strength is equal to or higher than its own.",
				snake: "Rearrange all animals in the line from highest to lowest strength. Animals of equal strength keep their relative order.",
				giraffe: "If the animal directly ahead is weaker, the Giraffe passes it. A Giraffe that has already passed an animal this turn does not act again during recurring resolution.",
				zebra: "The Zebra does not move when it joins the line. Hippos and Crocodiles cannot pass or eliminate it, so it also protects the animals ahead of it.",
				seal: "Reverse the direction of the line so that the front becomes the back and the back becomes the front.",
				chameleon: "Choose an animal other than a Chameleon already in the line and imitate its strength and ability. Restore the Chameleon’s own strength after resolving this ability. If no animal can be imitated, the ability has no effect.",
				monkey: "If at least 2 Monkeys are in the line, drive off all Hippos and Crocodiles and move the Monkeys to the front. The newly played Monkey goes first, and the other Monkeys reverse their relative order. A lone Monkey has no effect.",
				kangaroo: "Choose to hop past 1 or 2 animals ahead. Their strength does not affect this ability.",
				parrot: "Choose another animal in the line and eliminate it.",
				skunk: "Drive off all animals with the highest or second-highest strength in the line. All animals tied at either strength are affected, but Skunks are immune."
			},
			hintPlayAs: "Play {{animal}} as {{as}}",
			hintPlayTarget: "Play {{animal}} and expel {{target}}",
			hintPlayHop: "Play {{animal}} and hop over {{n}}"
		}
	}
};
//#endregion
export { Ye as default };
