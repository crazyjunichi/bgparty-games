import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as d, seatName as f } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { Floater as g, FlySprite as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { AVATARS as y } from "@bgparty/sdk/avatars";
import { IconBot as b } from "@bgparty/sdk/icons";
import { Confetti as x } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as S } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/catbox/meta.ts
var C = {
	id: "catbox",
	tier: "alpha",
	mechanics: ["trick-taking"],
	interactionTags: [],
	nameKey: "games.catbox.name",
	descKey: "games.catbox.desc",
	rulesKey: "games.catbox.rules",
	icon: "🐈‍⬛",
	iconImg: "games/catbox.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/catbox/en.pdf" },
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#0d9488",
	releasedAt: "2026-09-16",
	search: {
		py: "he zhong mao",
		init: "hzm"
	},
	hotseat: "cover"
}, w = t.enum([
	"red",
	"blue",
	"yellow",
	"green"
]), T = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("discard"),
		num: t.int().min(1).max(9)
	}),
	t.object({
		type: t.literal("bid"),
		n: t.int().min(1).max(4)
	}),
	t.object({
		type: t.literal("play"),
		num: t.int().min(1).max(9),
		color: w
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), E = t.string(), D = t.object({
	rid: E,
	num: t.int().min(1).max(9),
	color: w
}), O = t.object({
	bid: t.int().nullable(),
	won: t.int().nonnegative(),
	bonus: t.int().nonnegative(),
	delta: t.int()
}), k = t.object({
	round: t.int().min(1),
	entries: t.record(E, O)
}), A = t.object({
	phase: t.enum([
		"discard",
		"bid",
		"play",
		"roundEnd",
		"done"
	]),
	round: t.int().min(1),
	totalRounds: t.int().min(1),
	maxNum: t.int().min(1).max(9),
	allowedBids: t.array(t.int()),
	tricksTotal: t.int().min(1),
	startPlayer: E,
	actor: E.nullable(),
	discarded: t.array(E),
	board: t.array(t.array(E.nullable())),
	players: t.array(t.object({
		rid: E,
		handCount: t.int().nonnegative(),
		bid: t.int().nullable(),
		tricksWon: t.int().nonnegative(),
		noHave: t.array(w),
		score: t.int()
	})),
	trick: t.object({
		leader: E,
		ledColor: w.nullable(),
		plays: t.array(D)
	}),
	lastTrick: t.object({
		plays: t.array(D),
		winner: E
	}).nullable(),
	paradoxBy: E.nullable(),
	roundDelta: t.record(E, t.int()).nullable(),
	history: t.array(k)
}), j = t.object({
	hand: t.array(t.int().min(1).max(9)),
	playable: t.record(t.string(), t.array(w)).nullable()
}), M = [
	"red",
	"blue",
	"yellow",
	"green"
], N = 0, P = 2800;
function F(e) {
	return e === 3 ? {
		maxNum: 6,
		allowedBids: [
			1,
			3,
			4
		]
	} : e === 4 ? {
		maxNum: 8,
		allowedBids: [
			1,
			2,
			3
		]
	} : {
		maxNum: 9,
		allowedBids: [
			1,
			2,
			3
		]
	};
}
function I(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function L(e) {
	let t = [];
	for (let n = 1; n <= e; n += 1) for (let e = 0; e < 5; e += 1) t.push(n);
	return t;
}
function R(e) {
	return e.board[N].some((e) => e !== null);
}
function z(e, t) {
	let n = new Set(e.noHave[t] ?? []), r = [];
	for (let i of new Set(e.hands[t])) for (let t = 0; t < M.length; t += 1) n.has(M[t]) || e.board[t][i - 1] === null && r.push({
		num: i,
		color: M[t]
	});
	if (e.trick.plays.length === 0 && !R(e)) {
		let e = r.filter((e) => e.color !== "red");
		if (e.length > 0) return e;
	}
	return r;
}
function B(e, t) {
	let n = e.filter((e) => e.color === "red");
	return (n.length > 0 ? n : e.filter((e) => e.color === t)).reduce((e, t) => t.num > e.num ? t : e).rid;
}
function V(e, t) {
	let n = M.length, r = e.maxNum, i = Array.from({ length: n }, () => Array(r).fill(!1)), a = 0;
	for (let o = 0; o < n; o += 1) for (let s = 0; s < r; s += 1) {
		if (i[o][s] || e.board[o][s] !== t) continue;
		let c = 0, l = [[o, s]];
		for (i[o][s] = !0; l.length > 0;) {
			let [a, o] = l.pop();
			c += 1;
			for (let [s, c] of [
				[a - 1, o],
				[a + 1, o],
				[a, o - 1],
				[a, o + 1]
			]) s < 0 || s >= n || c < 0 || c >= r || i[s][c] || e.board[s][c] !== t || (i[s][c] = !0, l.push([s, c]));
		}
		c > a && (a = c);
	}
	return a;
}
function H(e) {
	return e.players[(e.startIdx + Object.keys(e.bids).length) % e.players.length];
}
function U(e) {
	return e.players.map((t, n) => ({
		kind: "deal",
		rid: t,
		data: { count: e.hands[t].length },
		for: [t],
		secret: { cards: [...e.hands[t]].sort((e, t) => e - t) },
		...n > 0 ? { with: !0 } : {}
	}));
}
function W(e, t = []) {
	let n = {}, r = {};
	for (let t of e.players) {
		let i = e.tricksWon[t], a = e.bids[t] ?? null, o = 0, s;
		e.paradoxBy === t ? s = -i : (a !== null && a === i && (o = V(e, t)), s = i + o), e.scores[t] += s, n[t] = {
			bid: a,
			won: i,
			bonus: o,
			delta: s
		}, r[t] = s;
	}
	return e.history.push({
		round: e.round,
		entries: n
	}), e.roundDelta = r, e.phase = "roundEnd", e.beatMs = P, [...t, ...e.players.map((e, n) => ({
		kind: "roundScore",
		rid: e,
		data: { delta: r[e] },
		...n > 0 || t.length > 0 ? { with: !0 } : {}
	}))];
}
function G(e) {
	return z(e, e.turn).length > 0 ? null : (e.paradoxBy = e.turn, e.trick = {
		leader: e.turn,
		ledColor: null,
		plays: []
	}, W(e, [{
		kind: "paradox",
		rid: e.turn
	}]));
}
function ee(e) {
	let t = e.players.length, n = I(e, L(e.maxNum)), r = n.length / t;
	e.hands = {}, e.players.forEach((t, i) => {
		e.hands[t] = n.slice(i * r, (i + 1) * r);
	}), e.discards = {}, e.bids = {}, e.tricksWon = Object.fromEntries(e.players.map((e) => [e, 0])), e.board = M.map(() => Array(e.maxNum).fill(null)), e.noHave = Object.fromEntries(e.players.map((e) => [e, []]));
	let i = e.players[e.startIdx];
	return e.trick = {
		leader: i,
		ledColor: null,
		plays: []
	}, e.turn = i, e.paradoxBy = null, e.lastTrick = null, e.roundDelta = null, e.phase = "discard", U(e);
}
var K = (e) => ({ code: e });
function q(e) {
	return 5 * e.maxNum / e.players.length - 2;
}
var te = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: C,
	schemas: {
		action: T,
		publicView: A,
		privateView: j
	},
	setup(e, t, n) {
		let r = t.length, i = {
			phase: "discard",
			seed: n,
			rngCursor: 0,
			players: [...t],
			startIdx: 0,
			round: 1,
			totalRounds: r,
			maxNum: F(r).maxNum,
			allowedBids: F(r).allowedBids,
			hands: {},
			discards: {},
			bids: {},
			tricksWon: {},
			board: [],
			noHave: {},
			trick: {
				leader: t[0],
				ledColor: null,
				plays: []
			},
			turn: t[0],
			paradoxBy: null,
			scores: Object.fromEntries(t.map((e) => [e, 0])),
			history: [],
			roundDelta: null,
			lastTrick: null,
			beatMs: 0
		};
		return {
			state: i,
			fx: ee(i)
		};
	},
	reduce(e, t, { by: n }) {
		let r = structuredClone(e);
		switch (t.type) {
			case "tick": return r.phase === "roundEnd" ? r.round >= r.totalRounds ? (r.phase = "done", { state: r }) : (r.round += 1, r.startIdx = (r.startIdx + 1) % r.players.length, {
				state: r,
				fx: ee(r)
			}) : { state: r };
			case "discard": {
				if (r.phase !== "discard") return K("games.catbox.errPhase");
				if (r.discards[n] !== void 0) return K("games.catbox.errTurn");
				let e = r.hands[n], i = e.indexOf(t.num);
				if (i < 0) return K("games.catbox.errCard");
				e.splice(i, 1), r.discards[n] = t.num;
				let a = [{
					kind: "discard",
					rid: n,
					data: {}
				}];
				return Object.keys(r.discards).length === r.players.length && (r.phase = "bid"), {
					state: r,
					fx: a
				};
			}
			case "bid": {
				if (r.phase !== "bid") return K("games.catbox.errPhase");
				if (n !== H(r)) return K("games.catbox.errTurn");
				if (!r.allowedBids.includes(t.n)) return K("games.catbox.errBid");
				r.bids[n] = t.n;
				let e = [{
					kind: "bid",
					rid: n,
					data: { n: t.n }
				}];
				if (Object.keys(r.bids).length === r.players.length) {
					r.phase = "play";
					let t = G(r);
					t && e.push(...t);
				}
				return {
					state: r,
					fx: e
				};
			}
			case "play": {
				if (r.phase !== "play") return K("games.catbox.errPhase");
				if (r.turn !== n) return K("games.catbox.errTurn");
				let e = r.hands[n], i = e.indexOf(t.num);
				if (i < 0) return K("games.catbox.errCard");
				if (!z(r, n).some((e) => e.num === t.num && e.color === t.color)) return K("games.catbox.errColor");
				e.splice(i, 1);
				let a = r.trick.ledColor;
				a === null ? r.trick.ledColor = t.color : t.color !== a && !r.noHave[n].includes(a) && r.noHave[n].push(a), r.board[M.indexOf(t.color)][t.num - 1] = n, r.trick.plays.push({
					rid: n,
					num: t.num,
					color: t.color
				});
				let o = [{
					kind: "play",
					rid: n,
					data: {
						num: t.num,
						color: t.color,
						index: r.trick.plays.length - 1
					}
				}];
				if (r.trick.plays.length < r.players.length) {
					r.turn = r.players[(r.players.indexOf(n) + 1) % r.players.length];
					let e = G(r);
					e && o.push(...e);
				} else {
					let e = B(r.trick.plays, r.trick.ledColor), t = {
						plays: [...r.trick.plays],
						winner: e
					};
					if (r.tricksWon[e] += 1, r.lastTrick = t, o.push({
						kind: "gather",
						rid: e,
						data: { count: r.players.length }
					}), r.trick = {
						leader: e,
						ledColor: null,
						plays: []
					}, r.turn = e, r.players.reduce((e, t) => e + r.tricksWon[t], 0) >= q(r)) o.push(...W(r));
					else {
						let e = G(r);
						e && o.push(...e);
					}
				}
				return {
					state: r,
					fx: o
				};
			}
		}
	},
	viewFor(e, t) {
		let n = e.phase === "bid" ? H(e) : e.phase === "play" ? e.turn : null, r = null;
		if (e.phase === "play" && e.turn === t) {
			r = {};
			for (let n of z(e, t)) {
				let e = String(n.num);
				r[e] = [...r[e] ?? [], n.color];
			}
		}
		return {
			public: {
				phase: e.phase,
				round: e.round,
				totalRounds: e.totalRounds,
				maxNum: e.maxNum,
				allowedBids: [...e.allowedBids],
				tricksTotal: q(e),
				startPlayer: e.players[e.startIdx],
				actor: n,
				discarded: Object.keys(e.discards),
				board: e.board.map((e) => [...e]),
				players: e.players.map((t) => ({
					rid: t,
					handCount: e.hands[t]?.length ?? 0,
					bid: e.bids[t] ?? null,
					tricksWon: e.tricksWon[t] ?? 0,
					noHave: [...e.noHave[t] ?? []],
					score: e.scores[t] ?? 0
				})),
				trick: {
					leader: e.trick.leader,
					ledColor: e.trick.ledColor,
					plays: e.trick.plays.map((e) => ({ ...e }))
				},
				lastTrick: e.lastTrick ? {
					plays: e.lastTrick.plays.map((e) => ({ ...e })),
					winner: e.lastTrick.winner
				} : null,
				paradoxBy: e.paradoxBy,
				roundDelta: e.roundDelta ? { ...e.roundDelta } : null,
				history: e.history.map((e) => ({
					round: e.round,
					entries: e.entries
				}))
			},
			private: {
				hand: [...e.hands[t] ?? []].sort((e, t) => e - t),
				playable: r
			}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = e.history[e.history.length - 1]?.entries ?? {}, n = (e) => t[e]?.delta ?? 0, r = [...e.players].sort((t, r) => e.scores[r] - e.scores[t] || n(r) - n(t)), i = r[0];
		return {
			phase: "done",
			winner: r.filter((t) => e.scores[t] === e.scores[i] && n(t) === n(i)),
			ranking: r,
			scores: { ...e.scores }
		};
	},
	nextTickIn(e) {
		return e.phase === "roundEnd" ? e.beatMs : null;
	}
}, J = {
	red: {
		chip: "bg-rose-500 text-white",
		text: "text-rose-600",
		glyph: "♥"
	},
	blue: {
		chip: "bg-blue-500 text-white",
		text: "text-blue-600",
		glyph: "◆"
	},
	yellow: {
		chip: "bg-amber-400 text-ink",
		text: "text-amber-500",
		glyph: "▲"
	},
	green: {
		chip: "bg-green-500 text-white",
		text: "text-green-600",
		glyph: "■"
	}
};
function ne(e) {
	return `games.catbox.color.${e}`;
}
function Y({ num: e, color: t, size: n, dimmed: r }) {
	let i = s(), a = t ? `${i(ne(t))} ${e}` : `${e}`, o = r ? "grayscale brightness-75" : "";
	if (n === "mini") return /* @__PURE__ */ h("span", {
		"aria-label": a,
		className: `inline-flex h-8 w-6 flex-none flex-col items-center justify-center rounded-sm border border-ink bg-ink ${o}`,
		children: [/* @__PURE__ */ m("span", {
			className: "font-display text-xs leading-none font-extrabold tabular-nums text-white",
			children: e
		}), t && /* @__PURE__ */ m("span", {
			"aria-hidden": !0,
			className: `mt-0.5 grid size-3 place-items-center rounded-full text-[8px] leading-none ${J[t].chip}`,
			children: J[t].glyph
		})]
	});
	let c = n === "hand" ? "h-20 w-14 rounded border-2 p-1" : "h-16 w-11 rounded border-2 p-0.5", l = n === "hand" ? "text-2xl" : "text-base", u = n === "hand" ? "size-4 text-[10px]" : "size-3.5 text-[9px]";
	return /* @__PURE__ */ h("span", {
		"aria-label": a,
		className: `relative inline-flex flex-none flex-col items-start border-ink bg-ink ${c} ${o}`,
		children: [/* @__PURE__ */ m("span", {
			className: `font-display leading-none font-extrabold tabular-nums text-white ${l}`,
			children: e
		}), t ? /* @__PURE__ */ m("span", {
			"aria-hidden": !0,
			className: `grid place-items-center rounded-full ${u} leading-none ${J[t].chip}`,
			children: J[t].glyph
		}) : /* @__PURE__ */ m("span", {
			"aria-hidden": !0,
			className: n === "hand" ? "text-sm leading-none" : "text-[10px] leading-none",
			children: "🐈‍⬛"
		})]
	});
}
function X({ accent: e }) {
	return /* @__PURE__ */ m("span", {
		className: "inline-flex h-16 w-11 flex-none rounded border-2 border-ink",
		style: { background: e }
	});
}
//#endregion
//#region src/games/catbox/post-view.tsx
var re = (e) => e >= 0 ? `+${e}` : String(e);
function ie({ pub: e, members: t }) {
	let n = s(), r = o((e) => e.locale), i = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? f(n, r) : e;
	}, a = e.history[e.history.length - 1];
	return /* @__PURE__ */ h("section", {
		className: "catbox-post-round",
		style: { "--catbox-post-count": e.players.length },
		"aria-label": n("games.catbox.roundScores"),
		children: [
			/* @__PURE__ */ m("h2", { children: n("games.catbox.roundScores") }),
			/* @__PURE__ */ m("ul", { children: e.players.map((r) => {
				let o = a?.entries[r.rid], s = e.roundDelta?.[r.rid] ?? 0, l = t.find((e) => e.rid === r.rid);
				return /* @__PURE__ */ h("li", {
					"data-paradox": r.rid === e.paradoxBy,
					children: [
						/* @__PURE__ */ h("strong", {
							className: "catbox-post-round-name",
							title: i(r.rid),
							style: { color: c[(l?.colorIndex ?? 0) % c.length].hex },
							children: [r.rid === e.paradoxBy && /* @__PURE__ */ m("span", {
								"aria-label": n("games.catbox.paradoxMark"),
								children: "🌀 "
							}), i(r.rid)]
						}),
						/* @__PURE__ */ m("b", {
							className: "catbox-post-round-delta",
							"data-negative": s < 0,
							"aria-label": n("games.catbox.roundScoreAria", { n: s }),
							children: re(s)
						}),
						/* @__PURE__ */ h("span", {
							className: "catbox-post-round-metrics",
							children: [n("games.catbox.bidVsWon", {
								bid: r.bid ?? 0,
								won: r.tricksWon
							}), o && o.bonus > 0 ? ` · ${n("games.catbox.bonusText", { n: o.bonus })}` : ""]
						}),
						/* @__PURE__ */ h("span", {
							className: "catbox-post-round-total",
							"aria-label": n("games.catbox.scoreAria", { n: r.score }),
							children: ["★", r.score]
						})
					]
				}, r.rid);
			}) }),
			e.phase === "roundEnd" && /* @__PURE__ */ m("p", { children: n("games.catbox.nextRoundSoon") })
		]
	});
}
function ae({ pub: e, members: t }) {
	let n = s(), r = o((e) => e.locale), i = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? f(n, r) : e;
	};
	return /* @__PURE__ */ m("div", {
		className: "catbox-score-scroll",
		style: { "--catbox-score-players": e.players.length },
		children: /* @__PURE__ */ h("table", {
			className: "catbox-score-table",
			children: [
				/* @__PURE__ */ m("caption", {
					className: "sr-only",
					children: n("games.catbox.scoreboard")
				}),
				/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
					scope: "col",
					children: n("games.catbox.scoreRound")
				}), e.players.map((e) => {
					let n = t.find((t) => t.rid === e.rid);
					return /* @__PURE__ */ m("th", {
						scope: "col",
						style: { color: c[(n?.colorIndex ?? 0) % c.length].hex },
						children: /* @__PURE__ */ m("span", {
							title: i(e.rid),
							children: i(e.rid)
						})
					}, e.rid);
				})] }) }),
				/* @__PURE__ */ m("tbody", { children: e.history.map((t) => /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
					scope: "row",
					children: t.round
				}), e.players.map((e) => {
					let r = t.entries[e.rid];
					return /* @__PURE__ */ m("td", { children: r ? /* @__PURE__ */ h(p, { children: [
						/* @__PURE__ */ m("span", {
							className: "catbox-score-prediction",
							children: n("games.catbox.bidVsWon", {
								bid: r.bid ?? 0,
								won: r.won
							})
						}),
						/* @__PURE__ */ m("strong", {
							className: "catbox-score-delta",
							"data-negative": r.delta < 0,
							"aria-label": n("games.catbox.roundScoreAria", { n: r.delta }),
							children: re(r.delta)
						}),
						/* @__PURE__ */ m("span", {
							className: "catbox-score-bonus",
							children: n("games.catbox.bonusText", { n: r.bonus })
						})
					] }) : "—" }, e.rid);
				})] }, t.round)) }),
				/* @__PURE__ */ m("tfoot", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
					scope: "row",
					children: n("games.catbox.totalScore")
				}), e.players.map((e) => /* @__PURE__ */ m("td", { children: /* @__PURE__ */ m("strong", {
					className: "catbox-score-total",
					children: e.score
				}) }, e.rid))] }) })
			]
		})
	});
}
function Z({ pub: e, members: t }) {
	let n = s(), r = o((e) => e.locale), i = (e) => t.find((t) => t.rid === e), a = (e) => {
		let t = i(e);
		return t ? f(t, r) : e;
	};
	return /* @__PURE__ */ h("div", {
		className: "catbox-final-board frame",
		role: "img",
		"aria-label": n("games.catbox.boardAria"),
		children: [M.map((t, r) => /* @__PURE__ */ h("div", {
			className: "catbox-final-board-row",
			children: [/* @__PURE__ */ m("span", {
				"aria-hidden": !0,
				className: `catbox-final-suit ${J[t].chip}`,
				children: J[t].glyph
			}), e.board[r].map((e, r) => /* @__PURE__ */ h("span", {
				className: "catbox-final-cell",
				"data-trump": t === "red",
				"aria-label": e ? n("games.catbox.cellAria", {
					color: n(`games.catbox.color.${t}`),
					n: r + 1,
					name: a(e)
				}) : void 0,
				children: [/* @__PURE__ */ m("span", { children: r + 1 }), e && /* @__PURE__ */ m("i", { style: { background: c[(i(e)?.colorIndex ?? 0) % c.length].hex } })]
			}, r))]
		}, t)), /* @__PURE__ */ m("p", { children: n("games.catbox.redTrump") })]
	});
}
//#endregion
//#region src/games/catbox/round-view.tsx
function oe(e, t, i) {
	let a = r(null);
	return n(() => {
		let n = a.current, r = n?.closest(".catbox-screen"), o = r?.querySelector(".catbox-banner");
		if (!n || !r || !o) return;
		let s = window.matchMedia("(orientation: landscape)"), c = [
			"pad",
			"gap",
			"top",
			"body",
			"main-w",
			"side-w",
			"board-h",
			"cell-h",
			"suit",
			"board-font",
			"dot",
			"last-h",
			"last-card-w",
			"last-card-h",
			"last-caption",
			"last-name",
			"scores-h",
			"name-font",
			"delta-font",
			"metric-font",
			"score-title",
			"score-gap",
			"score-min-row"
		], l = (e, t, n) => Math.min(n, Math.max(e, t)), u = (e, t) => {
			let r = `${t.toFixed(4)}px`;
			n.style.getPropertyValue(`--catbox-round-${e}`) !== r && n.style.setProperty(`--catbox-round-${e}`, r);
		}, d = () => {
			let a = r.getBoundingClientRect(), c = o.getBoundingClientRect(), d = a.width, f = a.height, p = l(6, Math.min(d, f) * .01, 12), m = l(8, Math.min(d, f) * .012, 14), h = Math.max(p, c.bottom - a.top + m), g = Math.max(1, f - h - p), _ = d - 2 * p, v = s.matches && d >= 760, y = v ? (_ - m) * .62 : _, b = v ? _ - y - m : _, x = 236 + 4 * Math.max(0, m - 8), S = i ? v ? l(164, Math.min(g * .42, g - x - m), 360) : 164 : 0, C = v ? Math.max(x, g - S - (i ? m : 0)) : Math.max(x, y * .64), w = (C - 24 - 20 - 4 * m) / 4, T = Math.min(44, w * .6), E = (y - 44 - T - t * m) / t, D = l(16, S * .09, 24), O = l(14, S * .075, 20), k = i ? Math.min(S - 24 - D * 1.2 - O * 1.2 - 2 * m, (y - 44 - (i - 1) * m) / i * 64 / 44) : 64, A = v ? 10 : 6, j = v ? l(18, g * .03, 28) : 16, M = v ? l(28, g * .05, 44) : 26, N = v ? l(16, g * .022, 22) : 12, P = v ? l(20, g * .032, 30) : 18, F = v ? 84 : 68, I = v ? g : 68 + 2 * A + N * 1.2 + e * F + (e - 1) * A, L = v ? "table" : "stack";
			n.dataset.catboxRoundLayout !== L && (n.dataset.catboxRoundLayout = L);
			let R = {
				pad: p,
				gap: m,
				top: h,
				body: g,
				"main-w": y,
				"side-w": b,
				"board-h": C,
				"cell-h": w,
				suit: T,
				"board-font": l(18, Math.min(E, w) * .38, 44),
				dot: Math.min(E * .44, w * .36, 44),
				"last-h": S,
				"last-card-w": k * 44 / 64,
				"last-card-h": k,
				"last-caption": D,
				"last-name": O,
				"scores-h": I,
				"name-font": j,
				"delta-font": M,
				"metric-font": N,
				"score-title": P,
				"score-gap": A,
				"score-min-row": F
			};
			for (let [e, t] of Object.entries(R)) u(e, t);
		}, f = new ResizeObserver(d);
		return f.observe(r), f.observe(o), s.addEventListener("change", d), d(), () => {
			f.disconnect(), s.removeEventListener("change", d), delete n.dataset.catboxRoundLayout;
			for (let e of c) n.style.removeProperty(`--catbox-round-${e}`);
		};
	}, [
		e,
		t,
		i
	]), a;
}
function se({ pub: e, members: t, onScores: n }) {
	let r = s(), i = o((e) => e.locale), a = oe(e.players.length, e.maxNum, e.lastTrick?.plays.length ?? 0), l = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? f(n, i) : e;
	}, u = (e) => c[(t.find((t) => t.rid === e)?.colorIndex ?? 0) % c.length].hex;
	return /* @__PURE__ */ h("div", {
		ref: a,
		className: "catbox-round-flow",
		children: [/* @__PURE__ */ h("section", {
			className: "catbox-round-scores",
			children: [/* @__PURE__ */ m(ie, {
				pub: e,
				members: t
			}), /* @__PURE__ */ h("button", {
				type: "button",
				className: "catbox-round-score-entry btn-quiet",
				onClick: n,
				children: ["📋 ", r("games.catbox.scoreboard")]
			})]
		}), /* @__PURE__ */ h("div", {
			className: "catbox-round-public",
			children: [/* @__PURE__ */ m(Z, {
				pub: e,
				members: t
			}), e.lastTrick && /* @__PURE__ */ h("section", {
				className: "catbox-round-last frame",
				"aria-label": r("games.catbox.lastTrick", { name: l(e.lastTrick.winner) }),
				children: [/* @__PURE__ */ m("h2", { children: r("games.catbox.lastTrick", { name: l(e.lastTrick.winner) }) }), /* @__PURE__ */ m("div", {
					className: "catbox-round-last-cards",
					children: e.lastTrick.plays.map((e, t) => /* @__PURE__ */ h("span", {
						className: "catbox-round-last-play",
						children: [/* @__PURE__ */ m("span", {
							className: "catbox-round-last-face",
							children: /* @__PURE__ */ m(Y, {
								num: e.num,
								color: e.color,
								size: "table"
							})
						}), /* @__PURE__ */ m("strong", {
							style: { color: u(e.rid) },
							title: l(e.rid),
							children: l(e.rid)
						})]
					}, `${e.rid}-${t}`))
				})]
			})]
		})]
	});
}
//#endregion
//#region src/games/catbox/view-player.tsx
function ce(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ m(ue, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function le(e, t) {
	let i = r(null);
	return n(() => {
		let n = i.current, r = n?.querySelector(".game-screen-layout");
		if (!n || !r) return;
		let a = window.matchMedia("(orientation: landscape)"), o = /* @__PURE__ */ "pad.gap.phase-h.players-h.top.body.main-w.side-w.controls-h.hand-zone.hand-w.hand-h.hand-step.hand-num.hand-symbol.lift.board-h.cell-h.board-font.owner-dot.suit-size.stage-h.trick-zone.table-w.table-h.table-num.table-symbol.mini-w.mini-h.name-font.status-font.avatar.trick-name.body-font.bid-size.last-h.phase-font.confirm-font".split("."), s = () => {
			delete n.dataset.catboxLayout;
			for (let e of o) n.style.removeProperty(`--catbox-${e}`);
			n.style.removeProperty("--catbox-players");
		}, c = (e, t, r = "px") => {
			let i = r ? `${t.toFixed(4)}${r}` : String(t);
			n.style.getPropertyValue(`--catbox-${e}`) !== i && n.style.setProperty(`--catbox-${e}`, i);
		}, l = (e, t, n) => Math.min(n, Math.max(e, t)), u = () => {
			let { width: r, height: i } = n.getBoundingClientRect();
			if (!a.matches || r < 900 || i < 600) {
				s();
				return;
			}
			let o = l(6, Math.min(r, i) * .01, 12), u = l(8, Math.min(r, i) * .012, 14), d = r - 2 * o, f = i - 2 * o, p = l(54, i * .065, 78), m = l(108, i * .12, 132), h = p + u + m, g = f - h - u, _ = (d - u) * .64, v = d - _ - u, y = l(200, g * .26, 250), b = g - y, x = Math.min(192, (b - 32 - u) * .5 * 56 / 80, (v - 24) / 3.08), S = x * 80 / 56, C = Math.min(x, (v - 24 - x) / 4), w = l(168, g * .38, 360), T = g - 24 - w - u, E = l(44, w * .26, 72), D = w - E - 4, O = l(16, w * .075, 22), k = Math.min((_ - 24 - (e - 1) * u) / e, (D - O * 1.2 - 28) * 44 / 64), A = k * 64 / 44, j = (T - 20 - 4 * u) / 4, M = (_ - 24 - 44 - t * u) / t, N = l(44, m * .58, 76), P = {
				pad: o,
				gap: u,
				"phase-h": p,
				"players-h": m,
				top: h,
				body: g,
				"main-w": _,
				"side-w": v,
				"controls-h": y,
				"hand-zone": b,
				"hand-w": x,
				"hand-h": S,
				"hand-step": C,
				"hand-num": 24 * x / 56,
				"hand-symbol": 14 * x / 56,
				lift: l(8, S * .06, 12),
				"board-h": T,
				"cell-h": j,
				"board-font": l(18, Math.min(M, j) * .38, 36),
				"owner-dot": Math.min(M * .44, j * .36, 44),
				"suit-size": Math.min(44, j * .6),
				"stage-h": w,
				"trick-zone": D,
				"table-w": k,
				"table-h": A,
				"table-num": 16 * k / 44,
				"table-symbol": 14 * k / 44,
				"mini-w": Math.min(48, (E - 4) * 24 / 32),
				"mini-h": Math.min(48, (E - 4) * 24 / 32) * 32 / 24,
				"name-font": l(16, m * .21, 26),
				"status-font": l(16, m * .17, 22),
				avatar: N,
				"trick-name": O,
				"body-font": l(18, i * .022, 26),
				"bid-size": l(64, w * .34, 100),
				"last-h": E,
				"phase-font": l(18, p * .35, 28),
				"confirm-font": l(20, y * .105, 26)
			};
			n.dataset.catboxLayout !== "table" && (n.dataset.catboxLayout = "table");
			for (let [e, t] of Object.entries(P)) c(e, t);
			c("players", e, "");
		}, d = new ResizeObserver(u);
		return d.observe(n), a.addEventListener("change", u), u(), () => {
			d.disconnect(), a.removeEventListener("change", u), s();
		};
	}, [e, t]), i;
}
function ue({ pub: e, priv: t, members: n, myRid: r, send: o }) {
	let f = s(), g = le(n.length, e.maxNum), _ = (e) => n.find((t) => t.rid === e)?.name ?? e, v = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? c[t.colorIndex % c.length].hex : void 0;
	}, { ref: y } = a("table"), { ref: b } = a("trick"), x = t?.hand ?? [], S = t?.playable ?? null, w = e.phase === "discard" && !e.discarded.includes(r), T = e.phase === "bid" && e.actor === r, E = e.phase === "play" && e.actor === r, [D, O] = i(null), [k, A] = i(null), [j, N] = i(!1), P = `${e.phase}|${e.round}|${e.actor}|${x.length}|${e.trick.plays.length}`, [F, I] = i(P);
	F !== P && (I(P), O(null), A(null));
	let L = D === null ? null : x[D] ?? null, R = e.players.reduce((e, t) => e + t.tricksWon, 0), z = e.paradoxBy ? _(e.paradoxBy) : "", B, V;
	e.phase === "discard" ? (B = w ? "accent" : "info", V = f(w ? "games.catbox.discardPrompt" : "games.catbox.discardWaiting")) : e.phase === "bid" ? (B = T ? "accent" : "info", V = T ? f("games.catbox.bidPrompt") : f("games.catbox.bidWaiting", { name: _(e.actor ?? "") })) : e.phase === "play" ? (B = E ? "accent" : "info", V = E ? f("games.catbox.turnYou") : f("games.catbox.turnWait", { name: _(e.actor ?? "") })) : e.phase === "roundEnd" ? (B = e.paradoxBy ? "warn" : "done", V = e.paradoxBy ? f("games.catbox.paradoxEnd", { name: z }) : f("games.catbox.roundEnd")) : (B = "done", V = f("games.catbox.done"));
	let H = e.phase === "play" && e.trick.ledColor ? f("games.catbox.ledIs", { color: `${J[e.trick.ledColor].glyph} ${f(`games.catbox.color.${e.trick.ledColor}`)}` }) : void 0, U = /* @__PURE__ */ h(p, { children: [T && k !== null && /* @__PURE__ */ h("div", {
		className: "catbox-confirm pointer-events-auto flex min-h-12 items-center gap-2 plate px-3 py-1.5",
		children: [
			/* @__PURE__ */ m("span", {
				className: "min-w-0 flex-1 text-sm font-extrabold",
				children: f("games.catbox.bidConfirm", { n: k })
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: "btn-quiet min-h-11 px-3 text-sm",
				onClick: () => A(null),
				children: f("games.catbox.cancel")
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: "btn-base min-h-11 px-4 text-sm text-white",
				style: { background: C.accent },
				onClick: () => {
					o({
						type: "bid",
						n: k
					}), A(null);
				},
				children: f("games.catbox.bidSend")
			})
		]
	}), w && L !== null && /* @__PURE__ */ h("div", {
		className: "catbox-confirm pointer-events-auto flex min-h-12 items-center gap-2 plate px-3 py-1.5",
		children: [
			/* @__PURE__ */ m("span", {
				className: "min-w-0 flex-1 text-sm font-extrabold",
				children: f("games.catbox.discardConfirm", { n: L })
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: "btn-quiet min-h-11 px-3 text-sm",
				onClick: () => O(null),
				children: f("games.catbox.cancel")
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: "btn-base min-h-11 px-4 text-sm text-white",
				style: { background: C.accent },
				onClick: () => {
					o({
						type: "discard",
						num: L
					}), O(null);
				},
				children: f("games.catbox.discardSend")
			})
		]
	})] }), W = /* @__PURE__ */ m(p, { children: t && (e.phase === "discard" || e.phase === "bid" || e.phase === "play") && /* @__PURE__ */ m("div", {
		className: "catbox-hand safe-b pb-1",
		children: /* @__PURE__ */ m("div", {
			className: "catbox-hand-scroll overflow-x-auto",
			children: /* @__PURE__ */ m("div", {
				className: "catbox-hand-grid mx-auto flex w-max items-end px-2 pt-2 pb-1",
				children: x.map((e, t) => {
					let n = x.slice(0, t).filter((t) => t === e).length, r = w || E && (S?.[String(e)]?.length ?? 0) > 0;
					return /* @__PURE__ */ m("button", {
						type: "button",
						disabled: !r,
						onClick: () => O(D === t ? null : t),
						className: `flex-none transition-transform active:translate-y-0.5 ${t > 0 ? "-ml-5" : ""}`,
						children: /* @__PURE__ */ m(fe, {
							num: e,
							copy: n,
							raised: D === t,
							dimmed: E && (S?.[String(e)]?.length ?? 0) === 0
						})
					}, `${e}-${n}`);
				})
			})
		})
	}) });
	return /* @__PURE__ */ h("div", {
		ref: g,
		"data-phase": e.phase,
		className: "catbox-screen relative h-full min-h-0",
		children: [
			/* @__PURE__ */ m(l, {
				adaptive: !0,
				scroll: !1,
				actionsHeight: "catbox-hand-height",
				actions: W,
				overlay: U,
				banner: /* @__PURE__ */ h("div", {
					className: "catbox-banner flex flex-col gap-2",
					children: [/* @__PURE__ */ m("div", {
						className: "catbox-phase",
						children: /* @__PURE__ */ m(u, {
							tone: B,
							text: V,
							chip: f("games.catbox.roundChip", {
								n: e.round,
								total: e.totalRounds
							}),
							sub: H,
							accent: C.accent
						})
					}), /* @__PURE__ */ m("div", {
						className: "catbox-players",
						children: /* @__PURE__ */ m(d, {
							variant: "plate",
							members: n,
							myRid: r,
							anchorOf: (e) => `seat:${e}`,
							action: (t) => e.phase === "discard" ? e.discarded.includes(t) ? "done" : "pending" : (e.phase === "bid" || e.phase === "play") && t === e.actor ? "pending" : e.phase === "bid" && e.players.find((e) => e.rid === t)?.bid !== null ? "done" : null,
							status: (t) => {
								let n = e.players.find((e) => e.rid === t);
								return n ? /* @__PURE__ */ h("span", {
									className: "catbox-player-status flex items-center gap-1 text-xs leading-4.5 font-bold",
									children: [
										t === e.startPlayer && /* @__PURE__ */ m("span", {
											"aria-label": f("games.catbox.startPlayerAria"),
											children: "🧪"
										}),
										/* @__PURE__ */ h("span", {
											className: "font-mono tabular-nums",
											"aria-label": f("games.catbox.scoreAria", { n: n.score }),
											children: ["★", n.score]
										}),
										n.bid !== null && /* @__PURE__ */ h("span", {
											className: "font-mono tabular-nums",
											"aria-label": f("games.catbox.bidAria", {
												n: n.bid,
												won: n.tricksWon
											}),
											children: [
												"🎯",
												n.tricksWon,
												"/",
												n.bid
											]
										}),
										n.noHave.map((e) => /* @__PURE__ */ m("span", {
											"aria-label": f("games.catbox.noHaveAria", { color: f(`games.catbox.color.${e}`) }),
											className: `grid size-4 place-items-center rounded-full text-[9px] leading-none line-through opacity-70 ${J[e].chip}`,
											children: J[e].glyph
										}, e))
									]
								}) : null;
							}
						})
					})]
				}),
				children: /* @__PURE__ */ h("div", {
					ref: y,
					className: "catbox-table frame flex h-full min-h-0 flex-col gap-2 overflow-hidden p-2",
					children: [/* @__PURE__ */ h("div", {
						className: "catbox-board flex flex-none flex-col gap-1",
						role: "img",
						"aria-label": f("games.catbox.boardAria"),
						children: [M.map((t, n) => /* @__PURE__ */ h("div", {
							className: "catbox-board-row flex items-center gap-1",
							children: [/* @__PURE__ */ m("span", {
								"aria-hidden": !0,
								className: `catbox-suit grid size-5 flex-none place-items-center rounded-full text-[10px] leading-none ${J[t].chip}`,
								children: J[t].glyph
							}), e.board[n].map((e, n) => /* @__PURE__ */ h("span", {
								"aria-label": e ? f("games.catbox.cellAria", {
									color: f(`games.catbox.color.${t}`),
									n: n + 1,
									name: _(e)
								}) : void 0,
								className: `catbox-cell flex h-7 min-w-0 flex-1 flex-col items-center justify-center rounded border text-[8px] leading-none font-bold ${t === "red" ? "border-rose-500/50 bg-rose-500/10" : "border-ink/15 bg-surface"}`,
								children: [/* @__PURE__ */ m("span", {
									className: "opacity-50",
									children: n + 1
								}), e && /* @__PURE__ */ m("span", {
									className: "catbox-owner mt-0.5 size-2.5 rounded-full border border-ink/40",
									style: { background: v(e) }
								})]
							}, n))]
						}, t)), /* @__PURE__ */ m("p", {
							className: "catbox-board-note text-center text-[10px] font-bold opacity-60",
							children: f("games.catbox.redTrump")
						})]
					}), /* @__PURE__ */ h("div", {
						className: "catbox-stage",
						children: [
							e.phase === "bid" && /* @__PURE__ */ m("div", {
								className: "catbox-bid flex min-h-0 flex-1 flex-col items-center justify-center gap-2",
								children: T ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("p", {
									className: "text-sm font-extrabold",
									children: f("games.catbox.bidQuestion")
								}), /* @__PURE__ */ m("div", {
									className: "catbox-bid-options flex max-w-80 flex-wrap items-center justify-center gap-1.5",
									children: e.allowedBids.map((e) => {
										let t = k === e;
										return /* @__PURE__ */ m("button", {
											type: "button",
											onClick: () => A(t ? null : e),
											className: "catbox-bid-number card size-11 cursor-pointer p-0 text-center font-mono text-base font-extrabold tabular-nums",
											style: t ? {
												borderColor: C.accent,
												boxShadow: `4px 4px 0 ${C.accent}`
											} : void 0,
											children: e
										}, e);
									})
								})] }) : /* @__PURE__ */ m("p", {
									className: "text-xs font-bold opacity-70",
									children: f("games.catbox.bidWaiting", { name: _(e.actor ?? "") })
								})
							}),
							(e.phase === "play" || e.phase === "roundEnd" || e.phase === "done") && /* @__PURE__ */ h(p, { children: [
								/* @__PURE__ */ h("div", {
									ref: b,
									className: "catbox-trick flex flex-none flex-col items-center gap-1",
									children: [/* @__PURE__ */ h("div", {
										className: "catbox-trick-row relative flex min-h-16 items-center justify-center gap-2",
										children: [/* @__PURE__ */ m("div", {
											className: "catbox-trick-slots",
											"aria-hidden": !0,
											children: e.players.map((e, t) => /* @__PURE__ */ m(pe, { index: t }, e.rid))
										}), e.trick.plays.length === 0 && e.phase === "play" ? /* @__PURE__ */ m("span", {
											className: "catbox-trick-lead text-xs font-bold opacity-60",
											children: f("games.catbox.trickLead", { name: _(e.trick.leader) })
										}) : e.trick.plays.map((e, t) => /* @__PURE__ */ h("span", {
											className: "catbox-trick-play flex flex-col items-center gap-0.5",
											children: [/* @__PURE__ */ m(de, {
												index: t,
												num: e.num,
												color: e.color
											}), /* @__PURE__ */ m("span", {
												className: "catbox-trick-name max-w-14 truncate text-[10px] font-bold",
												style: { color: v(e.rid) },
												children: _(e.rid)
											})]
										}, `${e.rid}-${t}`))]
									}), e.phase === "play" && /* @__PURE__ */ m("span", {
										className: "catbox-trick-count text-[10px] font-bold opacity-60",
										children: f("games.catbox.trickChip", {
											n: R + 1,
											total: e.tricksTotal
										})
									})]
								}),
								e.lastTrick && e.phase === "play" && /* @__PURE__ */ h("div", {
									className: "catbox-last flex flex-none items-center justify-center gap-1 opacity-70",
									children: [/* @__PURE__ */ m("span", {
										className: "text-[10px] font-bold",
										children: f("games.catbox.lastTrick", { name: _(e.lastTrick.winner) })
									}), e.lastTrick.plays.map((e, t) => /* @__PURE__ */ m(Y, {
										num: e.num,
										color: e.color,
										size: "mini"
									}, `${e.rid}-${t}`))]
								}),
								(e.phase === "roundEnd" || e.phase === "done") && e.roundDelta && /* @__PURE__ */ h("div", {
									className: "catbox-round-result flex min-h-0 flex-1 flex-col items-center justify-center gap-1.5",
									children: [/* @__PURE__ */ m("ul", {
										className: "flex w-full max-w-72 flex-col gap-1",
										children: e.players.map((t) => {
											let n = e.roundDelta[t.rid] ?? 0, r = e.history[e.history.length - 1]?.entries[t.rid];
											return /* @__PURE__ */ h("li", {
												className: "flex items-center gap-2 rounded-lg border-2 border-ink/15 bg-surface px-2 py-1 text-xs font-bold",
												children: [
													/* @__PURE__ */ m("span", {
														className: "min-w-0 flex-1 truncate",
														style: { color: v(t.rid) },
														children: t.rid === e.paradoxBy ? `🌀 ${_(t.rid)}` : _(t.rid)
													}),
													/* @__PURE__ */ h("span", {
														className: "font-mono tabular-nums opacity-70",
														children: [f("games.catbox.bidVsWon", {
															bid: t.bid ?? 0,
															won: t.tricksWon
														}), r && r.bonus > 0 ? ` ${f("games.catbox.bonusText", { n: r.bonus })}` : ""]
													}),
													/* @__PURE__ */ m("span", {
														className: `font-mono tabular-nums font-extrabold ${n >= 0 ? "text-emerald-600" : "text-rose-600"}`,
														children: n >= 0 ? `+${n}` : n
													}),
													/* @__PURE__ */ h("span", {
														className: "font-mono tabular-nums",
														children: ["★", t.score]
													})
												]
											}, t.rid);
										})
									}), e.phase === "roundEnd" && /* @__PURE__ */ m("p", {
										className: "text-[10px] font-bold opacity-60",
										children: f("games.catbox.nextRoundSoon")
									})]
								})
							] }),
							e.history.length > 0 && /* @__PURE__ */ h("button", {
								type: "button",
								className: "catbox-score-entry btn-quiet mx-auto flex min-h-11 items-center gap-1 px-4 text-xs font-bold",
								onClick: () => N(!0),
								children: ["📋 ", f("games.catbox.scoreboard")]
							})
						]
					})]
				})
			}),
			(e.phase === "roundEnd" || e.phase === "done") && e.roundDelta && /* @__PURE__ */ m(se, {
				pub: e,
				members: n,
				onScores: () => N(!0)
			}),
			E && L !== null && /* @__PURE__ */ m("div", {
				className: "catbox-declare-layer absolute inset-0 z-30 flex items-end justify-center px-4 pb-30",
				onClick: () => O(null),
				children: /* @__PURE__ */ h("div", {
					className: "catbox-declare-panel relative flex flex-col items-center gap-2 rounded-2xl border-3 border-ink bg-surface px-3 py-2 shadow-[4px_4px_0_var(--color-ink)]",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ h("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ m(Y, {
							num: L,
							size: "table"
						}), /* @__PURE__ */ m("p", {
							className: "text-sm font-extrabold",
							children: f("games.catbox.declarePrompt")
						})]
					}), /* @__PURE__ */ m("div", {
						className: "grid w-full grid-cols-2 gap-2",
						children: M.map((e) => {
							let t = S?.[String(L)]?.includes(e) ?? !1;
							return /* @__PURE__ */ h("button", {
								type: "button",
								disabled: !t,
								className: "catbox-color-choice card flex min-h-11 cursor-pointer items-center justify-center gap-1.5 px-2 text-sm font-extrabold disabled:opacity-30",
								onClick: () => {
									o({
										type: "play",
										num: L,
										color: e
									}), O(null);
								},
								children: [/* @__PURE__ */ m("span", {
									"aria-hidden": !0,
									className: `grid size-5 place-items-center rounded-full text-xs ${J[e].chip}`,
									children: J[e].glyph
								}), f(`games.catbox.color.${e}`)]
							}, e);
						})
					})]
				})
			}),
			j && /* @__PURE__ */ h("div", {
				className: "catbox-score-modal absolute inset-0 z-30",
				children: [/* @__PURE__ */ m("button", {
					type: "button",
					"aria-label": f("games.catbox.cancel"),
					className: "absolute inset-0 bg-ink/40",
					onClick: () => N(!1)
				}), /* @__PURE__ */ h("section", {
					className: "catbox-score-dialog frame",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": f("games.catbox.scoreboard"),
					children: [
						/* @__PURE__ */ m("h2", { children: f("games.catbox.scoreboard") }),
						/* @__PURE__ */ m(ae, {
							pub: e,
							members: n
						}),
						/* @__PURE__ */ m("button", {
							type: "button",
							className: "btn-quiet",
							onClick: () => N(!1),
							children: f("games.catbox.close")
						})
					]
				})]
			})
		]
	});
}
function de({ index: e, num: t, color: n }) {
	let { ref: r, hidden: i } = a(`tcard:${e}`);
	return /* @__PURE__ */ m("span", {
		ref: r,
		className: "catbox-trick-face inline-flex",
		style: { visibility: i ? "hidden" : void 0 },
		children: /* @__PURE__ */ m(Y, {
			num: t,
			color: n,
			size: "table"
		})
	});
}
function fe({ num: e, copy: t, raised: n, dimmed: r }) {
	let { ref: i, hidden: o } = a(`hand:${e}:${t}`);
	return /* @__PURE__ */ m("span", {
		ref: i,
		className: `catbox-hand-face inline-flex ${n ? "-translate-y-2" : ""}`,
		"data-raised": n,
		style: { visibility: o ? "hidden" : void 0 },
		children: /* @__PURE__ */ m(Y, {
			num: e,
			size: "hand",
			dimmed: r
		})
	});
}
function pe({ index: e }) {
	let { ref: t } = a(`catbox-trick-slot:${e}`);
	return /* @__PURE__ */ m("span", { ref: t });
}
//#endregion
//#region src/games/catbox/bot.ts
function me(e, t) {
	let n = [...e].sort((e, t) => t - e), r = 0;
	return n.forEach((e, n) => {
		r += Math.max(0, Math.min(.9, (e - 1.5 * n) / (t + 1)));
	}), r;
}
function he(e, t) {
	if (e.length === 0 || !t) return null;
	let n = e.filter((e) => e.color === "red");
	return (n.length > 0 ? n : e.filter((e) => e.color === t)).reduce((e, t) => t.num > e.num ? t : e);
}
function ge(e, t, n) {
	if (t.length === 0) return !0;
	let r = he(t, n);
	return e.color === "red" ? r.color !== "red" || e.num > r.num : r.color !== "red" && e.color === n && e.num > r.num;
}
function Q(e, t) {
	return e.color === t ? e.num : e.color === "red" ? 100 + e.num : 200 + e.num;
}
function _e(e, t) {
	return e.color === t ? e.num : e.color === "red" ? 200 + e.num : 100 + e.num;
}
var ve = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = t.rid, a = t.difficulty === "weak", o = r.hand;
	if (n.phase === "discard") return n.discarded.includes(i) || o.length === 0 ? null : { action: {
		type: "discard",
		num: a ? o[0] : o[Math.floor(o.length / 2)]
	} };
	if (n.phase === "bid") {
		if (n.actor !== i) return null;
		let e;
		if (a) e = n.allowedBids[(n.round + o.length) % n.allowedBids.length];
		else {
			let t = Math.round(me(o, n.maxNum));
			e = n.allowedBids.reduce((e, n) => Math.abs(n - t) < Math.abs(e - t) ? n : e);
		}
		return { action: {
			type: "bid",
			n: e
		} };
	}
	if (n.phase !== "play" || n.actor !== i || !r.playable) return null;
	let s = Object.entries(r.playable).flatMap(([e, t]) => t.map((t) => ({
		num: Number(e),
		color: t
	})));
	if (s.length === 0) return null;
	if (a) return { action: {
		type: "play",
		...s[(n.round + n.trick.plays.length) % s.length]
	} };
	let c = n.players.find((e) => e.rid === i), l = (c?.bid ?? 0) - (c?.tricksWon ?? 0), u = n.trick.ledColor;
	if (n.trick.plays.length === 0) {
		let e = s.filter((e) => e.color !== "red"), t;
		return t = l > 0 ? e.length > 0 ? e.reduce((e, t) => t.num > e.num ? t : e) : s.reduce((e, t) => t.num < e.num ? t : e) : (e.length > 0 ? e : s).reduce((e, t) => t.num < e.num ? t : e), { action: {
			type: "play",
			...t
		} };
	}
	let d = s.filter((e) => ge(e, n.trick.plays, u)), f = s.filter((e) => !ge(e, n.trick.plays, u)), p;
	return p = l > 0 && d.length > 0 ? d.reduce((e, t) => Q(t, u) < Q(e, u) ? t : e) : f.length > 0 ? f.reduce((e, t) => _e(t, u) < _e(e, u) ? t : e) : s.reduce((e, t) => Q(t, u) < Q(e, u) ? t : e), { action: {
		type: "play",
		...p
	} };
}, ye = {
	red: "games.catbox.color.red",
	blue: "games.catbox.color.blue",
	yellow: "games.catbox.color.yellow",
	green: "games.catbox.color.green"
}, be = (e, t, n) => {
	switch (e.type) {
		case "discard": return n("games.catbox.hintDiscard", { n: e.num });
		case "bid": return n("games.catbox.hintBid", { n: e.n });
		case "play": return n("games.catbox.hintPlay", {
			n: e.num,
			color: n(ye[e.color])
		});
		default: return "";
	}
};
//#endregion
//#region src/games/catbox/fx.tsx
function $(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function xe(e) {
	return Array.isArray(e) && e.every((e) => typeof e == "number") ? e : null;
}
function Se(e, t, n, r) {
	let i = e.anchor(`catbox-trick-slot:${n}`);
	if (i && i.w > 0 && i.h > 0) return i;
	let a = r * 44 + (r - 1) * 8;
	return {
		x: t.x + (t.w - a) / 2 + n * 52,
		y: t.y + (t.h - 64) / 2,
		w: 44,
		h: 64
	};
}
var Ce = {
	deal(e, t) {
		let n = e.secret, r = n ? xe(n.cards) : null, i = t.anchor("table");
		if (r) {
			if (!i) return null;
			let e = {
				x: i.x + i.w / 2 - 28,
				y: i.y + i.h / 2 - 40,
				w: 56,
				h: 80
			}, n = [], a = [], o = {};
			for (let [i, s] of r.entries()) {
				let r = o[s] ?? 0;
				o[s] = r + 1;
				let c = `hand:${s}:${r}`, l = t.anchor(c);
				l && (a.push(c), n.push(/* @__PURE__ */ m(_, {
					from: e,
					to: l,
					ms: 320,
					delay: i * 45,
					children: /* @__PURE__ */ m(Y, {
						num: s,
						size: "hand"
					})
				}, `${s}-${r}`)));
			}
			return n.length ? {
				ms: 320 + n.length * 45,
				node: n,
				hide: a
			} : null;
		}
		let a = $(t, e.rid);
		if (!i || !a) return null;
		let o = {
			x: i.x + i.w / 2 - 22,
			y: i.y + i.h / 2 - 32,
			w: 44,
			h: 64
		}, s = e.data?.count, c = typeof s == "number" ? s : 10;
		return {
			ms: 320 + c * 45,
			node: Array.from({ length: c }, (e, t) => /* @__PURE__ */ m(_, {
				from: o,
				to: a,
				ms: 320,
				delay: t * 45,
				children: /* @__PURE__ */ m(X, { accent: C.accent })
			}, t))
		};
	},
	discard(e, t) {
		let n = $(t, e.rid), r = t.anchor("table");
		if (!n || !r) return null;
		let i = {
			x: r.x + r.w - 44 - 8,
			y: r.y + 8,
			w: 44,
			h: 64
		};
		return {
			ms: 400,
			node: /* @__PURE__ */ m(_, {
				from: n,
				to: i,
				ms: 380,
				children: /* @__PURE__ */ m(X, { accent: C.accent })
			})
		};
	},
	bid(e, t) {
		let n = $(t, e.rid);
		if (!n) return null;
		let r = e.data?.n;
		return {
			ms: 900,
			node: /* @__PURE__ */ h(g, {
				at: n,
				ms: 800,
				delay: 60,
				children: ["🎯", typeof r == "number" ? r : "?"]
			})
		};
	},
	play(e, t) {
		let n = e.data, r = n?.num, i = n?.color, a = n?.index, o = $(t, e.rid);
		if (typeof r != "number" || typeof i != "string" || typeof a != "number" || !o) return null;
		let s = t.anchor("trick"), c = t.anchor(`tcard:${a}`) ?? (s ? Se(t, s, a, a + 1) : null);
		return c ? {
			ms: 400,
			node: /* @__PURE__ */ m(_, {
				from: o,
				to: c,
				ms: 380,
				children: /* @__PURE__ */ m(Y, {
					num: r,
					color: i,
					size: "table"
				})
			}),
			hide: [`tcard:${a}`]
		} : null;
	},
	gather(e, t) {
		let n = $(t, e.rid), r = t.anchor("trick");
		if (!n || !r) return null;
		let i = e.data?.count, a = typeof i == "number" ? i : 4;
		return {
			ms: 500,
			node: Array.from({ length: a }, (e, i) => {
				let o = Se(t, r, i, a);
				return /* @__PURE__ */ m(_, {
					from: o,
					to: n,
					ms: 420,
					delay: i * 50,
					children: /* @__PURE__ */ m("div", {
						style: {
							width: o.w,
							height: o.h
						},
						children: /* @__PURE__ */ m("div", {
							style: {
								width: 44,
								height: 64,
								transform: `scale(${o.w / 44})`,
								transformOrigin: "top left"
							},
							children: /* @__PURE__ */ m(X, { accent: C.accent })
						})
					})
				}, i);
			})
		};
	},
	paradox(e, t) {
		let n = $(t, e.rid), r = t.anchor("table");
		return !n || !r ? null : {
			ms: 1200,
			node: /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m(v, {
					at: n,
					ms: 900
				}),
				/* @__PURE__ */ m(v, {
					at: r,
					ms: 900
				}),
				/* @__PURE__ */ m(g, {
					at: n,
					ms: 1100,
					delay: 100,
					children: "🌀"
				})
			] })
		};
	},
	roundScore(e, t) {
		let n = $(t, e.rid);
		if (!n) return null;
		let r = e.data?.delta;
		return typeof r == "number" ? {
			ms: 1200,
			node: /* @__PURE__ */ m(g, {
				at: n,
				ms: 1100,
				delay: 120,
				children: r >= 0 ? `+${r}` : r
			})
		} : null;
	}
};
//#endregion
//#region src/games/catbox/game-over.tsx
function we(e, t) {
	let i = r(null);
	return n(() => {
		let n = i.current;
		if (!n) return;
		let r = window.matchMedia("(orientation: landscape)"), a = [
			"pad",
			"gap",
			"top",
			"bottom",
			"body",
			"rank-w",
			"detail-w",
			"rank-h",
			"avatar",
			"name-font",
			"score-font",
			"meta-font",
			"board-h",
			"ledger-h",
			"cell-h",
			"suit",
			"board-font",
			"dot",
			"heading-font",
			"winner-font",
			"ledger-font",
			"ledger-number",
			"ledger-row",
			"ledger-head"
		], o = (e, t) => {
			let r = `${t.toFixed(4)}px`;
			n.style.getPropertyValue(`--catbox-over-${e}`) !== r && n.style.setProperty(`--catbox-over-${e}`, r);
		}, s = (e, t, n) => Math.min(n, Math.max(e, t)), c = () => {
			let { width: i, height: a } = n.getBoundingClientRect(), c = s(6, Math.min(i, a) * .01, 12), l = s(8, Math.min(i, a) * .012, 14), u = s(68, a * .08, 92), d = s(60, a * .08, 88), f = Math.max(0, a - 2 * c - u - d - 2 * l), p = r.matches && i >= 760 && a >= 280, m = i - 2 * c, h = p ? Math.max(280, m * .28) : m, g = p ? m - h - l : m, _ = p ? Math.max(88, (f - 4 - (e - 1) * l) / e) : 88, v = p ? Math.max(236, f * .52) : Math.max(236, g * .64), y = p ? Math.max(220, f - v - l) : Math.max(280, Math.min(620, 52 + (e + 1) * 76)), b = (v - 24 - 20 - 4 * l) / 4, x = Math.min(44, b * .6), S = (g - 24 - x - t * l) / t, C = p ? "table" : "stack";
			n.dataset.catboxOverLayout !== C && (n.dataset.catboxOverLayout = C);
			let w = s(16, g / e * .07, 24), T = s(26, g / e * .11, 38), E = {
				pad: c,
				gap: l,
				top: u,
				bottom: d,
				body: f,
				"rank-w": h,
				"detail-w": g,
				"rank-h": _,
				avatar: s(40, _ * .5, 128),
				"name-font": s(18, _ * .17, 36),
				"score-font": s(32, _ * .34, 80),
				"meta-font": s(12, _ * .105, 18),
				"board-h": v,
				"ledger-h": y,
				"cell-h": b,
				suit: x,
				"board-font": s(18, Math.min(S, b) * .38, 36),
				dot: Math.min(S * .44, b * .36, 44),
				"heading-font": s(22, u * .35, 34),
				"winner-font": s(16, u * .27, 26),
				"ledger-font": w,
				"ledger-number": T,
				"ledger-row": Math.max(84, w * 2.25 + T * 1.15 + 16, s(72, y / (e + 2), 100)),
				"ledger-head": s(44, y * .14, 64)
			};
			for (let [e, t] of Object.entries(E)) o(e, t);
		}, l = new ResizeObserver(c);
		return l.observe(n), r.addEventListener("change", c), c(), () => {
			l.disconnect(), r.removeEventListener("change", c), delete n.dataset.catboxOverLayout;
			for (let e of a) n.style.removeProperty(`--catbox-over-${e}`);
		};
	}, [e, t]), i;
}
function Te(e) {
	let t = A.safeParse(e.public);
	return t.success && t.data.phase === "done" ? /* @__PURE__ */ m(Ee, {
		...e,
		pub: t.data
	}) : /* @__PURE__ */ m(S, {
		result: e.result,
		members: e.members,
		myRid: e.myRid,
		accent: C.accent,
		onPlayAgain: e.onPlayAgain,
		onBackToLobby: e.onBackToLobby
	});
}
function Ee({ pub: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let u = s(), d = o((e) => e.locale), p = we(t.ranking.length, e.maxNum), g = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? f(t, d) : e;
	};
	return /* @__PURE__ */ h("div", {
		ref: p,
		className: "catbox-over",
		children: [t.winner.length > 0 && /* @__PURE__ */ m(x, {}), /* @__PURE__ */ m(l, {
			adaptive: !0,
			scroll: !1,
			actionsHeight: "catbox-over-action-height",
			banner: /* @__PURE__ */ h("header", {
				className: "catbox-over-heading",
				children: [/* @__PURE__ */ m("h1", { children: u("session.result.title") }), t.winner.length > 0 && /* @__PURE__ */ m("p", {
					title: t.winner.map(g).join(" / "),
					children: u("games.catbox.matchWinner", { name: t.winner.map(g).join(" / ") })
				})]
			}),
			actions: i || a ? /* @__PURE__ */ h("div", {
				className: "catbox-over-actions",
				children: [i && /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-base text-white",
					style: { background: C.accent },
					onClick: i,
					children: u("session.result.playAgain")
				}), a && /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-quiet",
					onClick: a,
					children: u("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ m("p", {
				className: "catbox-over-wait",
				children: u("session.result.waitHost")
			}),
			children: /* @__PURE__ */ h("div", {
				className: "catbox-over-main",
				children: [/* @__PURE__ */ m("ol", {
					className: "catbox-over-ranking",
					"aria-label": u("games.catbox.matchRanking"),
					children: t.ranking.map((e, i) => {
						let a = n.find((t) => t.rid === e), o = t.winner.includes(e), s = t.autopilot?.[e];
						return /* @__PURE__ */ h("li", {
							"data-winner": o,
							children: [
								/* @__PURE__ */ h("span", {
									className: "catbox-over-avatar",
									style: { background: c[(a?.colorIndex ?? 0) % c.length].hex },
									children: [a && /* @__PURE__ */ m("img", {
										src: y[a.avatar % y.length],
										alt: "",
										draggable: !1
									}), /* @__PURE__ */ m("b", {
										"aria-hidden": !0,
										children: o ? "👑" : i + 1
									})]
								}),
								/* @__PURE__ */ h("span", {
									className: "catbox-over-person",
									children: [/* @__PURE__ */ m("strong", {
										title: g(e),
										children: g(e)
									}), /* @__PURE__ */ h("span", { children: [e === r && /* @__PURE__ */ m("small", { children: u("lobby.you") }), s !== void 0 && s > 0 && /* @__PURE__ */ h("small", {
										className: "catbox-over-autopilot",
										children: [/* @__PURE__ */ m(b, { size: 14 }), u("session.autopilot.share", { n: Math.round(s * 100) })]
									})] })]
								}),
								t.scores?.[e] !== void 0 && /* @__PURE__ */ m("b", {
									className: "catbox-over-score",
									"aria-label": u("games.catbox.scoreAria", { n: t.scores[e] }),
									children: t.scores[e]
								})
							]
						}, e);
					})
				}), /* @__PURE__ */ h("div", {
					className: "catbox-over-details",
					children: [/* @__PURE__ */ m(Z, {
						pub: e,
						members: n
					}), /* @__PURE__ */ m("section", {
						className: "catbox-over-ledger",
						"aria-label": u("games.catbox.scoreboard"),
						children: /* @__PURE__ */ m(ae, {
							pub: e,
							members: n
						})
					})]
				})]
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/catbox/entry.tsx
var De = {
	definition: te,
	View: ce,
	bot: ve,
	describe: be,
	fx: Ce,
	OverView: Te,
	locales: {
		zh: {
			name: "盒中猫",
			desc: "量子吃墩:颜色打出时才宣告,别把自己逼进悖论",
			rules: "目标:预报每轮要赢的墩数并精准命中,几轮后总分最高者获胜。\n准备:\n卡牌只有数字，没有预设颜色。每个数字各有5张牌，使用的数字范围取决于对局人数：\n· 三人对局使用数字1至6。\n· 四人对局使用数字1至8。\n· 五人对局使用数字1至9。\n· 每人起手 10 张(5 人局 9 张),各自扣置 1 张移出本轮。\n· 从起始玩家开始顺时针预报赢墩数:3 人局只能报 1、3 或 4;4~5 人局报 1、2 或 3。\n流程:\n· 轮到你时打出一张牌并宣告它的颜色;研究板上同色同数字的格子只能被占一次。\n· 宣告与领出色不同的颜色,须公开标记「没有领出色」;已标记没有的颜色不能再宣告。\n· 领出者原则上不能领红(王牌);红已被观测过、或整手牌都无法宣告其他颜色时除外。\n· 墩的归属:本墩有红色牌时，由红色牌中数字最大的牌赢墩；没有红色牌时，由领出花色中数字最大的牌赢墩;赢家领出下一墩。\n· 手牌剩 1 张时本轮结束(共 8 墩,5 人局 7 墩);若轮到你时没有任何合法宣告,悖论发生,本轮立即中止、当前墩作废。\n结算:\n· 每赢 1 墩获得 1 分;预报命中再加奖励分,等于研究板上你的标记最大连通片(横竖相邻)的格数。\n· 引发悖论者改为每赢 1 墩扣 1 分,且不获得预报奖励分。\n· 轮数等于人数,起始玩家每轮左移;总分最高者获胜,平分比较最后一轮得分,若仍然相同，则共享胜利。",
			roundChip: "第 {{n}}/{{total}} 轮",
			discardPrompt: "扣置一张牌,移出本轮",
			discardWaiting: "等待其他人扣置…",
			discardConfirm: "扣置 {{n}} 移出本轮?",
			discardSend: "扣置",
			bidPrompt: "轮到你预报",
			bidWaiting: "等待 {{name}} 预报…",
			bidQuestion: "预报:本轮你赢几墩?",
			bidConfirm: "预报赢 {{n}} 墩?",
			bidSend: "预报",
			turnYou: "轮到你出牌",
			turnWait: "等待 {{name}} 出牌…",
			ledIs: "领出:{{color}}",
			trickLead: "等待 {{name}} 领出",
			trickChip: "第 {{n}}/{{total}} 墩",
			lastTrick: "上一墩:{{name}} 收",
			roundEnd: "本轮结束",
			paradoxEnd: "🌀 {{name}} 引发悖论,本轮中止",
			done: "实验结束",
			nextRoundSoon: "即将进入下一轮…",
			declarePrompt: "宣告颜色",
			cancel: "取消",
			close: "关闭",
			scoreboard: "计分板",
			roundScores: "本轮计分",
			roundScoreAria: "本轮得分 {{n}}",
			paradoxMark: "引发悖论",
			scoreRound: "轮次",
			totalScore: "总分",
			matchRanking: "最终排名",
			matchWinner: "获胜：{{name}}",
			bidVsWon: "报{{bid}} 赢{{won}}",
			bonusText: "连通+{{n}}",
			scoreCell: "{{bid}}→{{won}} {{delta}}",
			startPlayerAria: "本轮起始玩家",
			scoreAria: "总分 {{n}}",
			bidAria: "预报 {{n}} 墩,已赢 {{won}} 墩",
			noHaveAria: "没有{{color}}",
			boardAria: "研究板:记录每个颜色每个数字被谁观测",
			cellAria: "{{color}} {{n}},{{name}} 观测",
			redTrump: "红 = 王牌",
			color: {
				red: "红",
				blue: "蓝",
				yellow: "黄",
				green: "绿"
			},
			errPhase: "现在不能这么做",
			errTurn: "还没轮到你",
			errBid: "不能预报这个数",
			errCard: "没有这张牌",
			errColor: "不能宣告这个颜色",
			hintDiscard: "扣置 {{n}} 移出本轮",
			hintBid: "预报赢 {{n}} 墩",
			hintPlay: "打出 {{n}},宣告{{color}}"
		},
		en: {
			name: "Cat in the Box",
			desc: "Quantum trick-taking: a card's color is declared only as you play it — don't paradox yourself",
			rules: "Goal: predict how many tricks you will win each round and hit it exactly; highest total score after all rounds wins.\nSetup:\nCards have numbers but no fixed color. Use five copies of each number in the range for the player count:\n· Three-player games use numbers 1–6.\n· Four-player games use numbers 1–8.\n· Five-player games use numbers 1–9.\n· Each player is dealt 10 cards (9 with 5 players), then sets 1 card face down out of the round.\n· Starting from the round start player and going clockwise, predict your tricks: with 3 players only 1, 3 or 4 is allowed; with 4-5 players choose 1, 2 or 3.\nPlay:\n· On your turn, play a card and declare its color; on the research board, each color-number space can be claimed only once.\n· Declaring a color different from the led color publicly marks that you have none of the led color; a color you have marked as none can never be declared again.\n· The trick leader may not lead red (trump), unless red has already been observed or no card in hand can be declared any other color.\n· If any red cards are played to the trick, the highest-numbered red card wins. Otherwise, the highest-numbered card in the led color wins. The winner leads the next trick.\n· The round ends when 1 card remains in hand (8 tricks, 7 with 5 players); if you have no legal declaration on your turn, a paradox occurs and the round stops immediately with the current trick voided.\nScoring:\n· 1 point per trick won; a successful prediction adds a bonus equal to the largest connected group (orthogonally adjacent) of your tokens on the research board.\n· The player who caused the paradox scores -1 per trick won instead and gets no bonus.\n· Rounds equal the player count, with the start player rotating left; highest total wins, ties break on the final round score, and further ties share the victory.",
			roundChip: "Round {{n}}/{{total}}",
			discardPrompt: "Set one card aside, out of this round",
			discardWaiting: "Waiting for others to set aside…",
			discardConfirm: "Set aside {{n}}?",
			discardSend: "Set aside",
			bidPrompt: "Your prediction",
			bidWaiting: "Waiting for {{name}} to predict…",
			bidQuestion: "Predict: how many tricks will you win?",
			bidConfirm: "Predict {{n}} tricks?",
			bidSend: "Predict",
			turnYou: "Your turn",
			turnWait: "Waiting for {{name}}…",
			ledIs: "Led: {{color}}",
			trickLead: "Waiting for {{name}} to lead",
			trickChip: "Trick {{n}}/{{total}}",
			lastTrick: "Last trick: {{name}}",
			roundEnd: "Round over",
			paradoxEnd: "🌀 {{name}} caused a paradox — round stopped",
			done: "Experiment complete",
			nextRoundSoon: "Next round soon…",
			declarePrompt: "Declare a color",
			cancel: "Cancel",
			close: "Close",
			scoreboard: "Scoreboard",
			roundScores: "Round scores",
			roundScoreAria: "Round score {{n}}",
			paradoxMark: "Caused a paradox",
			scoreRound: "Round",
			totalScore: "Total",
			matchRanking: "Final ranking",
			matchWinner: "Victory: {{name}}",
			bidVsWon: "bid {{bid}} won {{won}}",
			bonusText: "group +{{n}}",
			scoreCell: "{{bid}}→{{won}} {{delta}}",
			startPlayerAria: "Round start player",
			scoreAria: "Score {{n}}",
			bidAria: "Predicted {{n}}, won {{won}}",
			noHaveAria: "No {{color}}",
			boardAria: "Research board: who observed each number in each color",
			cellAria: "{{color}} {{n}}, observed by {{name}}",
			redTrump: "Red = trump",
			color: {
				red: "Red",
				blue: "Blue",
				yellow: "Yellow",
				green: "Green"
			},
			errPhase: "Not allowed right now",
			errTurn: "Not your turn",
			errBid: "Cannot predict that number",
			errCard: "Card not in hand",
			errColor: "Cannot declare that color",
			hintDiscard: "Set {{n}} aside",
			hintBid: "Bid {{n}} tricks",
			hintPlay: "Play {{n}} as {{color}}"
		}
	}
};
//#endregion
export { De as default };
