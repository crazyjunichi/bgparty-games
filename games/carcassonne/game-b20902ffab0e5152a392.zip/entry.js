import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useLayoutEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { IconBack as d, IconBot as f, IconExpand as p, IconLog as m, IconRecenter as h, IconRotate as g } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as _ } from "@bgparty/sdk/player-colors";
import { PhaseBanner as v } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as y } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as b, seatName as x } from "@bgparty/sdk/ui/player-strip";
import { useFrame as S, useThree as C } from "@react-three/fiber";
import { ResilientCanvas as ee } from "@bgparty/sdk/three/resilient-canvas";
import { BoxGeometry as w, BufferGeometry as T, Color as E, DoubleSide as D, ExtrudeGeometry as O, Float32BufferAttribute as k, MeshLambertMaterial as A, Path as te, Plane as ne, Raycaster as j, Shape as M, SphereGeometry as N, Vector2 as re, Vector3 as P } from "three";
import { Texture as ie } from "@bgparty/sdk/texture";
import { Fragment as ae, jsx as F, jsxs as I } from "react/jsx-runtime";
import { Floater as oe, PulseBox as se } from "@bgparty/sdk/fx/primitives";
import { Confetti as ce } from "@bgparty/sdk/ui/confetti";
//#region src/games/carcassonne/meta.ts
var le = {
	id: "carcassonne",
	tier: "beta",
	mechanics: [
		"tile-placement",
		"area-control",
		"route-building"
	],
	interactionTags: [],
	nameKey: "games.carcassonne.name",
	descKey: "games.carcassonne.desc",
	rulesKey: "games.carcassonne.rules",
	icon: "🏰",
	iconImg: "games/carcassonne.webp",
	rulesUrl: { en: "https://www.hans-im-glueck.de/wp-content/uploads/2024/11/Carcassonne-v3_Rulesheet_EN_web.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [2],
	accent: "#c2410c",
	releasedAt: "2026-09-16",
	search: {
		py: "ka ka song",
		init: "kks"
	},
	hotseat: "cover"
}, ue = t.int().min(-99).max(99), de = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		x: ue,
		y: ue,
		rot: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("meeple"),
		zone: t.int().min(0).max(7),
		abbot: t.boolean().optional()
	}),
	t.object({ type: t.literal("skip") }),
	t.object({ type: t.literal("recallAbbot") })
]), fe = t.string(), L = t.object({
	tile: t.int().min(0),
	rot: t.int().min(0).max(3)
}), R = t.object({
	zone: t.int().min(0),
	rid: fe,
	abbot: t.boolean()
}), pe = t.object({
	phase: t.enum(["play", "done"]),
	board: t.record(t.string(), L),
	meeples: t.record(t.string(), R),
	tilesLeft: t.int().min(0),
	players: t.array(t.object({
		rid: fe,
		score: t.number(),
		meeples: t.int().min(0),
		abbot: t.boolean()
	})),
	turn: t.object({
		playerIdx: t.int().min(0),
		stage: t.enum(["place", "meeple"]),
		tile: t.int().min(0),
		placedKey: t.string().optional()
	})
}), z = t.object({}), B = (e, t = []) => ({
	halves: e,
	touches: t
}), V = [
	{
		id: "city4",
		edges: [
			"c",
			"c",
			"c",
			"c"
		],
		cities: [{
			edges: [
				0,
				1,
				2,
				3
			],
			pennant: !0
		}],
		roads: [],
		monastery: !1,
		fields: []
	},
	{
		id: "city3",
		edges: [
			"c",
			"c",
			"c",
			"f"
		],
		cities: [{
			edges: [
				0,
				1,
				2
			],
			pennant: !1
		}],
		roads: [],
		monastery: !1,
		fields: [B([[3, 2], [3, 3]], [0])]
	},
	{
		id: "city3s",
		edges: [
			"c",
			"c",
			"c",
			"f"
		],
		cities: [{
			edges: [
				0,
				1,
				2
			],
			pennant: !0
		}],
		roads: [],
		monastery: !1,
		fields: [B([[3, 2], [3, 3]], [0])]
	},
	{
		id: "city3r",
		edges: [
			"c",
			"c",
			"c",
			"r"
		],
		cities: [{
			edges: [
				0,
				1,
				2
			],
			pennant: !1
		}],
		roads: [{ edges: [3] }],
		monastery: !1,
		fields: [B([[3, 3]], [0]), B([[3, 2]], [0])]
	},
	{
		id: "city3sr",
		edges: [
			"c",
			"c",
			"c",
			"r"
		],
		cities: [{
			edges: [
				0,
				1,
				2
			],
			pennant: !0
		}],
		roads: [{ edges: [3] }],
		monastery: !1,
		fields: [B([[3, 3]], [0]), B([[3, 2]], [0])]
	},
	{
		id: "city2we",
		edges: [
			"f",
			"c",
			"f",
			"c"
		],
		cities: [{
			edges: [1, 3],
			pennant: !1
		}],
		roads: [],
		monastery: !1,
		fields: [B([[0, 0], [0, 3]], [0]), B([[2, 1], [2, 2]], [0])]
	},
	{
		id: "city2wes",
		edges: [
			"f",
			"c",
			"f",
			"c"
		],
		cities: [{
			edges: [1, 3],
			pennant: !0
		}],
		roads: [],
		monastery: !1,
		fields: [B([[0, 0], [0, 3]], [0]), B([[2, 1], [2, 2]], [0])]
	},
	{
		id: "city2nw",
		edges: [
			"c",
			"c",
			"f",
			"f"
		],
		cities: [{
			edges: [0, 1],
			pennant: !1
		}],
		roads: [],
		monastery: !1,
		fields: [B([
			[2, 1],
			[2, 2],
			[3, 2],
			[3, 3]
		], [0])]
	},
	{
		id: "city2nws",
		edges: [
			"c",
			"c",
			"f",
			"f"
		],
		cities: [{
			edges: [0, 1],
			pennant: !0
		}],
		roads: [],
		monastery: !1,
		fields: [B([
			[2, 1],
			[2, 2],
			[3, 2],
			[3, 3]
		], [0])]
	},
	{
		id: "city2nwr",
		edges: [
			"c",
			"c",
			"r",
			"r"
		],
		cities: [{
			edges: [0, 1],
			pennant: !1
		}],
		roads: [{ edges: [2, 3] }],
		monastery: !1,
		fields: [B([[2, 2], [3, 2]]), B([[2, 1], [3, 3]], [0])]
	},
	{
		id: "city2nwsr",
		edges: [
			"c",
			"c",
			"r",
			"r"
		],
		cities: [{
			edges: [0, 1],
			pennant: !0
		}],
		roads: [{ edges: [2, 3] }],
		monastery: !1,
		fields: [B([[2, 2], [3, 2]]), B([[2, 1], [3, 3]], [0])]
	},
	{
		id: "city1",
		edges: [
			"c",
			"f",
			"f",
			"f"
		],
		cities: [{
			edges: [0],
			pennant: !1
		}],
		roads: [],
		monastery: !1,
		fields: [B([
			[1, 0],
			[1, 1],
			[2, 1],
			[2, 2],
			[3, 2],
			[3, 3]
		], [0])]
	},
	{
		id: "city1rwe",
		edges: [
			"c",
			"r",
			"f",
			"r"
		],
		cities: [{
			edges: [0],
			pennant: !1
		}],
		roads: [{ edges: [1, 3] }],
		monastery: !1,
		fields: [B([[1, 0], [3, 3]], [0]), B([
			[1, 1],
			[2, 1],
			[2, 2],
			[3, 2]
		])]
	},
	{
		id: "city1rse",
		edges: [
			"c",
			"r",
			"r",
			"f"
		],
		cities: [{
			edges: [0],
			pennant: !1
		}],
		roads: [{ edges: [1, 2] }],
		monastery: !1,
		fields: [B([[1, 1], [2, 1]]), B([
			[1, 0],
			[2, 2],
			[3, 2],
			[3, 3]
		], [0])]
	},
	{
		id: "city1rsw",
		edges: [
			"c",
			"f",
			"r",
			"r"
		],
		cities: [{
			edges: [0],
			pennant: !1
		}],
		roads: [{ edges: [2, 3] }],
		monastery: !1,
		fields: [B([[2, 2], [3, 2]]), B([
			[2, 1],
			[3, 3],
			[1, 0],
			[1, 1]
		], [0])]
	},
	{
		id: "city1rswe",
		edges: [
			"c",
			"r",
			"r",
			"r"
		],
		cities: [{
			edges: [0],
			pennant: !1
		}],
		roads: [
			{ edges: [1] },
			{ edges: [2] },
			{ edges: [3] }
		],
		monastery: !1,
		fields: [
			B([[1, 0]], [0]),
			B([[1, 1], [2, 1]]),
			B([[2, 2], [3, 2]]),
			B([[3, 3]], [0])
		]
	},
	{
		id: "city11ne",
		edges: [
			"c",
			"c",
			"f",
			"f"
		],
		cities: [{
			edges: [0],
			pennant: !1
		}, {
			edges: [1],
			pennant: !1
		}],
		roads: [],
		monastery: !1,
		fields: [B([
			[2, 1],
			[2, 2],
			[3, 2],
			[3, 3]
		], [0, 1])]
	},
	{
		id: "city11we",
		edges: [
			"f",
			"c",
			"f",
			"c"
		],
		cities: [{
			edges: [1],
			pennant: !1
		}, {
			edges: [3],
			pennant: !1
		}],
		roads: [],
		monastery: !1,
		fields: [B([[0, 0], [0, 3]], [0, 1]), B([[2, 1], [2, 2]], [0, 1])]
	},
	{
		id: "cloister",
		edges: [
			"f",
			"f",
			"f",
			"f"
		],
		cities: [],
		roads: [],
		monastery: !0,
		fields: [B([
			[0, 0],
			[0, 3],
			[1, 0],
			[1, 1],
			[2, 1],
			[2, 2],
			[3, 2],
			[3, 3]
		])]
	},
	{
		id: "cloisterr",
		edges: [
			"f",
			"f",
			"r",
			"f"
		],
		cities: [],
		roads: [{ edges: [2] }],
		monastery: !0,
		fields: [B([
			[0, 0],
			[0, 3],
			[1, 0],
			[1, 1],
			[2, 1],
			[2, 2],
			[3, 2],
			[3, 3]
		])]
	},
	{
		id: "road2ns",
		edges: [
			"r",
			"f",
			"r",
			"f"
		],
		cities: [],
		roads: [{ edges: [0, 2] }],
		monastery: !1,
		fields: [B([
			[0, 0],
			[1, 0],
			[1, 1],
			[2, 1]
		]), B([
			[0, 3],
			[3, 3],
			[3, 2],
			[2, 2]
		])]
	},
	{
		id: "road2sw",
		edges: [
			"f",
			"f",
			"r",
			"r"
		],
		cities: [],
		roads: [{ edges: [2, 3] }],
		monastery: !1,
		fields: [B([[2, 2], [3, 2]]), B([
			[0, 0],
			[0, 3],
			[1, 0],
			[1, 1],
			[2, 1],
			[3, 3]
		])]
	},
	{
		id: "road3",
		edges: [
			"f",
			"r",
			"r",
			"r"
		],
		cities: [],
		roads: [
			{ edges: [1] },
			{ edges: [2] },
			{ edges: [3] }
		],
		monastery: !1,
		fields: [
			B([[0, 0], [1, 0]]),
			B([[0, 3], [3, 3]]),
			B([
				[1, 1],
				[2, 1],
				[2, 2],
				[3, 2]
			])
		]
	},
	{
		id: "road4",
		edges: [
			"r",
			"r",
			"r",
			"r"
		],
		cities: [],
		roads: [
			{ edges: [0] },
			{ edges: [1] },
			{ edges: [2] },
			{ edges: [3] }
		],
		monastery: !1,
		fields: [
			B([[0, 0], [1, 0]]),
			B([[1, 1], [2, 1]]),
			B([[2, 2], [3, 2]]),
			B([[3, 3], [0, 3]])
		]
	}
], me = [
	1,
	3,
	1,
	1,
	2,
	1,
	2,
	3,
	2,
	3,
	2,
	5,
	4,
	3,
	3,
	3,
	2,
	3,
	4,
	2,
	8,
	9,
	4,
	1
], he = V.flatMap((e, t) => Array.from({ length: me[t] - +(t === 12) }, () => t)), ge = [
	0,
	1,
	0,
	-1
], _e = [
	-1,
	0,
	1,
	0
], H = (e, t) => `${e},${t}`;
function U(e) {
	let t = e.indexOf(",");
	return [Number(e.slice(0, t)), Number(e.slice(t + 1))];
}
var W = (e, t, n) => H(e + ge[n], t + _e[n]), G = [
	[0, -50],
	[50, 0],
	[0, 50],
	[-50, 0]
], K = [
	[50, -50],
	[50, 50],
	[-50, 50],
	[-50, -50]
], ve = (e, t) => (e + t) % 4, ye = (e, t) => (e - t + 4) % 4, be = (e, t) => (e + t) % 4;
function xe(e, t, n) {
	return e.edges[ye(n, t)];
}
function Se(e, t) {
	return [(e + 2) % 4, e % 2 == 0 ? t ^ 1 : t ^ 3];
}
var Ce = [];
function q(e) {
	let t = Ce[e];
	if (!t) {
		let n = V[e];
		t = [
			...n.cities.map((e, t) => ({
				kind: "city",
				ref: t
			})),
			...n.roads.map((e, t) => ({
				kind: "road",
				ref: t
			})),
			...n.monastery ? [{
				kind: "monastery",
				ref: 0
			}] : [],
			...n.fields.map((e, t) => ({
				kind: "field",
				ref: t
			}))
		], Ce[e] = t;
	}
	return t;
}
function we(e, t) {
	let n = V[e];
	if (t.kind === "monastery") return [0, 0];
	if (t.kind === "city") {
		let e = n.cities[t.ref].edges;
		if (e.length === 4) return [0, 0];
		if (e.length === 2 && (e[0] + 2) % 4 !== e[1]) {
			let t = (e[0] + 1) % 4 === e[1] ? e[0] : e[1];
			return [K[t][0] * .7, K[t][1] * .7];
		}
		let r = e.reduce((e, t) => e + G[t][0], 0) / e.length, i = e.reduce((e, t) => e + G[t][1], 0) / e.length;
		return [r * .6, i * .6];
	}
	if (t.kind === "road") {
		let e = n.roads[t.ref].edges;
		if (e.length === 1) return [G[e[0]][0] * .45, G[e[0]][1] * .45];
		if (e.length === 2 && (e[0] + 2) % 4 !== e[1]) {
			let t = (e[0] + 1) % 4 === e[1] ? e[0] : e[1];
			return [K[t][0] * .35, K[t][1] * .35];
		}
		return [0, 0];
	}
	let r = n.fields[t.ref].halves.map(([e, t]) => [(G[e][0] + K[t][0]) / 2, (G[e][1] + K[t][1]) / 2]), i = 0, a = 0;
	for (let [e, t] of r) i += e, a += t;
	return i /= r.length, a /= r.length, Math.abs(i) < 1 && Math.abs(a) < 1 && ([i, a] = r[0]), [i * .72, a * .72];
}
var Te = (e, t) => (e - t + 4) % 4;
function Ee(e, t, n, r, i) {
	if (e[H(n, r)]) return !1;
	let a = V[t], o = !1;
	for (let t = 0; t < 4; t++) {
		let s = e[W(n, r, t)];
		if (s && (o = !0, a.edges[ye(t, i)] !== V[s.tile].edges[ye((t + 2) % 4, s.rot)])) return !1;
	}
	return o;
}
function De(e, t) {
	let n = [], r = /* @__PURE__ */ new Set();
	for (let i of Object.keys(e)) {
		let [a, o] = U(i);
		for (let i = 0; i < 4; i++) {
			let s = W(a, o, i);
			if (e[s] || r.has(s)) continue;
			r.add(s);
			let [c, l] = U(s);
			for (let r = 0; r < 4; r++) Ee(e, t, c, l, r) && n.push({
				x: c,
				y: l,
				rot: r
			});
		}
	}
	return n;
}
function Oe() {
	return {
		features: /* @__PURE__ */ new Set(),
		tiles: /* @__PURE__ */ new Set(),
		pennants: 0,
		open: !1
	};
}
function ke(e, t, n, r) {
	return (n === "city" ? e.cities : e.roads).findIndex((e) => e.edges.some((e) => ve(e, t) === r));
}
function J(e, t, n) {
	let r = Oe(), i = [[t, n]];
	for (; i.length > 0;) {
		let [t, n] = i.pop(), a = `${t}:${n}`;
		if (r.features.has(a)) continue;
		r.features.add(a), r.tiles.add(t);
		let o = e[t], s = V[o.tile].cities[n];
		s.pennant && (r.pennants += 1);
		let [c, l] = U(t);
		for (let t of s.edges) {
			let n = ve(t, o.rot), a = e[W(c, l, n)];
			if (!a) {
				r.open = !0;
				continue;
			}
			let s = ke(V[a.tile], a.rot, "city", (n + 2) % 4);
			s >= 0 && i.push([W(c, l, n), s]);
		}
	}
	return r;
}
function Ae(e, t, n) {
	let r = Oe(), i = [[t, n]];
	for (; i.length > 0;) {
		let [t, n] = i.pop(), a = `${t}:${n}`;
		if (r.features.has(a)) continue;
		r.features.add(a), r.tiles.add(t);
		let o = e[t], s = V[o.tile], [c, l] = U(t);
		for (let t of s.roads[n].edges) {
			let n = ve(t, o.rot), a = e[W(c, l, n)];
			if (!a) {
				r.open = !0;
				continue;
			}
			let s = ke(V[a.tile], a.rot, "road", (n + 2) % 4);
			s >= 0 && i.push([W(c, l, n), s]);
		}
	}
	return r;
}
function je(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set(), a = [[t, n]];
	for (; a.length > 0;) {
		let [t, n] = a.pop(), o = `${t}:${n}`;
		if (r.has(o)) continue;
		r.add(o);
		let s = e[t], c = V[s.tile];
		for (let e of c.fields[n].touches) i.add(`${t}:${e}`);
		let [l, u] = U(t);
		for (let [t, r] of c.fields[n].halves) {
			let n = ve(t, s.rot), [i, o] = Se(n, be(r, s.rot)), c = e[W(l, u, n)];
			if (!c) continue;
			let d = V[c.tile], f = ye(i, c.rot), p = Te(o, c.rot), m = d.fields.findIndex((e) => e.halves.some(([e, t]) => e === f && t === p));
			m >= 0 && a.push([W(l, u, n), m]);
		}
	}
	return {
		features: r,
		cities: i
	};
}
function Me(e, t) {
	let [n, r] = U(t), i = 1;
	for (let t = -1; t <= 1; t++) for (let a = -1; a <= 1; a++) (t !== 0 || a !== 0) && e[H(n + t, r + a)] && (i += 1);
	return i;
}
function Y(e, t, n, r) {
	let i = [];
	for (let [a, o] of Object.entries(t)) {
		let t = e[a];
		if (!t) continue;
		let s = q(t.tile)[o.zone];
		s.kind === r && n.features.has(`${a}:${s.ref}`) && i.push(o);
	}
	return i;
}
function Ne(e, t, n, r) {
	return r.kind === "monastery" ? !1 : r.kind === "city" ? Y(e, t, J(e, n, r.ref), "city").length > 0 : r.kind === "road" ? Y(e, t, Ae(e, n, r.ref), "road").length > 0 : Y(e, t, je(e, n, r.ref), "field").length > 0;
}
function Pe(e, t, n, r, i) {
	if (t.length === 0) return;
	let a = /* @__PURE__ */ new Map();
	for (let e of t) a.set(e.rid, (a.get(e.rid) ?? 0) + 1);
	let o = Math.max(...a.values());
	for (let [t, s] of a) s === o && (e.scores[t] += n, i.push({
		kind: "score",
		rid: t,
		data: {
			points: n,
			via: r
		},
		with: !0
	}));
	for (let [n, r] of Object.entries(e.meeples)) t.includes(r) && (delete e.meeples[n], r.abbot ? e.abbot[r.rid] = !0 : e.supply[r.rid] += 1);
}
function Fe(e, t, n) {
	let r = V[e.board[t].tile], i = /* @__PURE__ */ new Set();
	r.cities.forEach((r, a) => {
		if (i.has(`c${t}:${a}`)) return;
		let o = J(e.board, t, a);
		for (let e of o.features) i.add(`c${e}`);
		o.open || Pe(e, Y(e.board, e.meeples, o, "city"), 2 * o.tiles.size + 2 * o.pennants, "city", n);
	}), r.roads.forEach((r, a) => {
		if (i.has(`r${t}:${a}`)) return;
		let o = Ae(e.board, t, a);
		for (let e of o.features) i.add(`r${e}`);
		o.open || Pe(e, Y(e.board, e.meeples, o, "road"), o.tiles.size, "road", n);
	});
	let [a, o] = U(t);
	for (let t = -1; t <= 1; t++) for (let r = -1; r <= 1; r++) {
		let i = H(a + t, o + r), s = e.board[i];
		s && V[s.tile].monastery && Me(e.board, i) === 9 && Pe(e, Y(e.board, e.meeples, {
			features: /* @__PURE__ */ new Set([`${i}:0`]),
			tiles: /* @__PURE__ */ new Set([i]),
			pennants: 0,
			open: !1
		}, "monastery"), 9, "monastery", n);
	}
}
function Ie(e, t) {
	let n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set(), a = [];
	for (let [i, o] of Object.entries(e.meeples)) {
		let s = e.board[i], c = q(s.tile)[o.zone];
		if (c.kind === "city") {
			if (n.has(`${i}:${c.ref}`)) continue;
			let r = J(e.board, i, c.ref);
			for (let e of r.features) n.add(e);
			Pe(e, Y(e.board, e.meeples, r, "city"), r.tiles.size + r.pennants, "city", t);
		} else if (c.kind === "road") {
			if (r.has(`${i}:${c.ref}`)) continue;
			let n = Ae(e.board, i, c.ref);
			for (let e of n.features) r.add(e);
			Pe(e, Y(e.board, e.meeples, n, "road"), n.tiles.size, "road", t);
		} else if (c.kind === "monastery") {
			if (o.abbot) continue;
			e.scores[o.rid] += Me(e.board, i), t.push({
				kind: "score",
				rid: o.rid,
				data: {
					points: Me(e.board, i),
					via: "monastery"
				},
				with: !0
			});
		} else a.push([i, o]);
	}
	let o = /* @__PURE__ */ new Map();
	for (let [n, r] of a) {
		let a = e.board[n], s = q(a.tile)[r.zone];
		if (i.has(`${n}:${s.ref}`)) continue;
		let c = je(e.board, n, s.ref);
		for (let e of c.features) i.add(e);
		let l = 0;
		for (let t of c.cities) {
			let n = o.get(t);
			if (n === void 0) {
				let [r, i] = t.split(":");
				n = !J(e.board, r, Number(i)).open, o.set(t, n);
			}
			n && (l += 1);
		}
		l !== 0 && Pe(e, Y(e.board, e.meeples, c, "field"), l * 3, "farm", t);
	}
}
function Le(e, t) {
	let n = (e.turn.playerIdx + 1) % e.players.length;
	for (; e.deck.length > 0;) {
		let r = e.deck.pop();
		if (De(e.board, r).length > 0) {
			e.turn = {
				playerIdx: n,
				stage: "place",
				tile: r
			};
			return;
		}
		t.push({
			kind: "discard",
			rid: e.players[n],
			data: { tile: r },
			with: !0
		});
	}
	Ie(e, t), e.phase = "done", t.push({ kind: "gameEnd" });
}
function Re(t, n, r) {
	let i = [...he], a = 0;
	for (let t = i.length - 1; t > 0; --t) {
		let n = e(r, a, t + 1);
		a += 1, [i[t], i[n]] = [i[n], i[t]];
	}
	return {
		state: {
			seed: r,
			rngCursor: a,
			players: n,
			deck: i,
			board: { [H(0, 0)]: {
				tile: 12,
				rot: 0
			} },
			meeples: {},
			supply: Object.fromEntries(n.map((e) => [e, 7])),
			abbot: Object.fromEntries(n.map((e) => [e, !0])),
			scores: Object.fromEntries(n.map((e) => [e, 0])),
			turn: {
				playerIdx: 0,
				stage: "place",
				tile: i.pop()
			},
			phase: "play"
		},
		fx: []
	};
}
function ze(e, t, n) {
	let r = e.players[e.turn.playerIdx];
	if (e.phase !== "play" || n.by !== r) return { code: "games.carcassonne.errNotYourTurn" };
	if (t.type === "place") {
		if (e.turn.stage !== "place") return { code: "games.carcassonne.errNotYourTurn" };
		if (!Ee(e.board, e.turn.tile, t.x, t.y, t.rot)) return { code: "games.carcassonne.errBadPlacement" };
		let r = structuredClone(e), i = H(t.x, t.y);
		return r.board[i] = {
			tile: r.turn.tile,
			rot: t.rot
		}, r.turn.stage = "meeple", r.turn.placedKey = i, {
			state: r,
			fx: [{
				kind: "place",
				rid: n.by,
				data: {
					x: t.x,
					y: t.y,
					rot: t.rot,
					tile: r.turn.tile
				}
			}]
		};
	}
	let i = e.turn.placedKey;
	if (e.turn.stage !== "meeple" || !i) return { code: "games.carcassonne.errNotYourTurn" };
	let a = structuredClone(e), o = [];
	if (t.type === "meeple") {
		let e = a.board[i], r = q(e.tile)[t.zone];
		if (!r) return { code: "games.carcassonne.errBadZone" };
		if (t.abbot) {
			if (r.kind !== "monastery" || !a.abbot[n.by]) return { code: "games.carcassonne.errNoAbbot" };
		} else if (a.supply[n.by] < 1) return { code: "games.carcassonne.errNoMeeple" };
		if (Ne(a.board, a.meeples, i, r)) return { code: "games.carcassonne.errOccupied" };
		a.meeples[i] = {
			zone: t.zone,
			rid: n.by,
			abbot: t.abbot === !0
		}, t.abbot ? a.abbot[n.by] = !1 : --a.supply[n.by], o.push({
			kind: "meeple",
			rid: n.by,
			data: {
				key: i,
				kind: r.kind,
				abbot: t.abbot === !0
			}
		});
	} else if (t.type === "recallAbbot") {
		let e = Object.entries(a.meeples).find(([, e]) => e.rid === n.by && e.abbot);
		if (!e) return { code: "games.carcassonne.errNoAbbot" };
		let [t] = e, r = Me(a.board, t);
		delete a.meeples[t], a.abbot[n.by] = !0, a.scores[n.by] += r, o.push({
			kind: "score",
			rid: n.by,
			data: {
				points: r,
				via: "monastery"
			}
		}, {
			kind: "recall",
			rid: n.by,
			with: !0
		});
	}
	return Fe(a, i, o), Le(a, o), {
		state: a,
		fx: o
	};
}
function Be(e) {
	return {
		public: {
			phase: e.phase,
			board: e.board,
			meeples: e.meeples,
			tilesLeft: e.deck.length,
			players: e.players.map((t) => ({
				rid: t,
				score: e.scores[t],
				meeples: e.supply[t],
				abbot: e.abbot[t]
			})),
			turn: e.turn
		},
		private: {}
	};
}
function Ve(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.scores[t] === n),
		ranking: t,
		scores: { ...e.scores }
	};
}
var He = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: le,
	schemas: {
		action: de,
		publicView: pe,
		privateView: z
	},
	setup: Re,
	reduce: ze,
	viewFor: Be,
	status: Ve
}, Ue = {
	field: "#9ccb6b",
	city: "#d9a066",
	road: "#efe6cf",
	roof: "#b5553a",
	plaza: "#f5efe0"
}, X = (e) => `${e[0]},${e[1]}`, We = ([e, t], n) => {
	switch (n) {
		case 1: return [-t, e];
		case 2: return [-e, -t];
		case 3: return [t, -e];
		default: return [e, t];
	}
}, Ge = [
	[-35, -50],
	[35, -50],
	[41, -34],
	[23, -20],
	[-23, -20],
	[-41, -34]
], Ke = [
	[-35, -50],
	[35, -50],
	[50, -35],
	[50, 35],
	[34, 41],
	[23, 32],
	[-32, -23],
	[-41, -34]
], qe = [
	[-35, -50],
	[35, -50],
	[50, -35],
	[50, 35],
	[35, 50],
	[-35, 50],
	[-41, 35],
	[-25, 20],
	[-25, -20],
	[-41, -35]
], Je = [
	[-35, -50],
	[35, -50],
	[42, -32],
	[34, -18],
	[34, 18],
	[42, 32],
	[35, 50],
	[-35, 50],
	[-42, 32],
	[-34, 18],
	[-34, -18],
	[-42, -32]
], Ye = [
	[-35, -50],
	[35, -50],
	[50, -35],
	[50, 35],
	[35, 50],
	[-35, 50],
	[-50, 35],
	[-50, -35]
];
function Xe(e) {
	let t = new Set(e);
	return e.find((e) => !t.has((e + 3) % 4)) ?? e[0];
}
function Ze(e, t) {
	let n = e.cities[t].edges, r = n.length, i = r === 2 && (n[0] + 2) % 4 === n[1], a = i ? +!n.includes(0) : Xe(n), o = r === 4 ? Ye : r === 3 ? qe : i ? Je : r === 2 ? Ke : Ge;
	if (r === 1 && e.cities.length > 1) {
		let n = e.cities.some((e, n) => n !== t && e.edges.includes((a + 1) % 4)), r = e.cities.some((e, n) => n !== t && e.edges.includes((a + 3) % 4));
		o = Ge.map(([e, t], i) => i === 2 && n ? [37, -42] : i === 3 && n ? [20, -23] : i === 4 && r ? [-20, -23] : i === 5 && r ? [-37, -42] : [e, t]);
	}
	return `M${o.map((e) => We(e, a)).map(X).join(" L")} Z`;
}
function Qe(e) {
	let t = e.roads.reduce((e, t) => e + t.edges.length, 0) >= 3;
	return {
		paths: e.roads.map((n) => {
			if (n.edges.length === 1) {
				if (t || e.monastery) return `M${X(G[n.edges[0]])} L0,0`;
				let r = G[n.edges[0]];
				return `M${X(r)} L${r[0] * .45},${r[1] * .45}`;
			}
			if ((n.edges[0] + 2) % 4 === n.edges[1]) return `M${X(G[n.edges[0]])} L${X(G[n.edges[1]])}`;
			let r = (n.edges[0] + 1) % 4 === n.edges[1] ? n.edges[0] : n.edges[1], i = [K[r][0] * .22, K[r][1] * .22];
			return `M${X(G[n.edges[0]])} Q${X(i)} ${X(G[n.edges[1]])}`;
		}),
		junction: t
	};
}
//#endregion
//#region src/games/carcassonne/meeple-ui-position.ts
var $e = (e, t) => Math.max(0, Math.min(e.right, t.right) - Math.max(e.left, t.left)) * Math.max(0, Math.min(e.bottom, t.bottom) - Math.max(e.top, t.top));
function et(e, t, n, r) {
	let i = t.width / 2, a = t.height / 2, o = (r.left + r.right) / 2, s = (r.top + r.bottom) / 2, c = [
		[o, r.bottom + 14 + a],
		[o, r.top - 14 - a],
		[r.right + 14 + i, s],
		[r.left - 14 - i, s]
	], l = [
		i + 8,
		e.w / 2,
		e.w - i - 8
	], u = [
		a + 8,
		e.h / 2,
		e.h - a - 8
	], d = [...c, ...u.flatMap((e) => l.map((t) => [t, e]))], f = {
		left: e.w / 2,
		top: e.h / 2
	}, p = Infinity;
	for (let [t, r] of d) {
		let c = Math.max(i + 8, Math.min(e.w - i - 8, t)), l = Math.max(a + 8, Math.min(e.h - a - 8, r)), u = {
			left: c - i - 4,
			right: c + i + 4,
			top: l - a - 4,
			bottom: l + a + 4
		}, d = n.reduce((e, t) => e + $e(u, t), 0), m = Math.hypot(c - o, l - s), h = d * 100 + m + (t !== c || r !== l ? 20 : 0);
		h < p && (f = {
			left: c,
			top: l
		}, p = h);
	}
	return f;
}
//#endregion
//#region src/games/carcassonne/board-view.tsx
function tt({ tile: e, ghost: t }) {
	let n = V[e], r = Qe(n);
	return /* @__PURE__ */ I("g", {
		opacity: t ? .55 : 1,
		children: [
			/* @__PURE__ */ F("rect", {
				x: -50,
				y: -50,
				width: 100,
				height: 100,
				rx: 6,
				fill: Ue.field,
				className: "stroke-ink",
				strokeWidth: 2.5,
				strokeDasharray: t ? "8 6" : void 0
			}),
			n.cities.map((e, t) => /* @__PURE__ */ F("path", {
				d: Ze(n, t),
				fill: Ue.city,
				className: "stroke-ink",
				strokeWidth: 3,
				strokeLinejoin: "round"
			}, `c${t}`)),
			r.paths.map((e, t) => /* @__PURE__ */ I("g", {
				fill: "none",
				children: [/* @__PURE__ */ F("path", {
					d: e,
					className: "stroke-ink",
					strokeWidth: 20
				}), /* @__PURE__ */ F("path", {
					d: e,
					stroke: Ue.road,
					strokeWidth: 13
				})]
			}, `r${t}`)),
			r.junction && /* @__PURE__ */ I(ae, { children: [/* @__PURE__ */ F("circle", {
				r: 10,
				className: "fill-ink",
				stroke: "none"
			}), /* @__PURE__ */ F("circle", {
				r: 6.5,
				fill: Ue.road,
				stroke: "none"
			})] }),
			n.monastery && /* @__PURE__ */ I("g", { children: [
				/* @__PURE__ */ F("circle", {
					r: 18,
					fill: Ue.plaza,
					className: "stroke-ink",
					strokeWidth: 2.5
				}),
				/* @__PURE__ */ F("rect", {
					x: -8,
					y: -2,
					width: 16,
					height: 10,
					fill: Ue.plaza,
					className: "stroke-ink",
					strokeWidth: 2
				}),
				/* @__PURE__ */ F("polygon", {
					points: "-11,-2 0,-13 11,-2",
					fill: Ue.roof,
					className: "stroke-ink",
					strokeWidth: 2,
					strokeLinejoin: "round"
				})
			] }),
			n.cities.map((t, n) => t.pennant ? /* @__PURE__ */ F("text", {
				x: we(e, {
					kind: "city",
					ref: n
				})[0],
				y: we(e, {
					kind: "city",
					ref: n
				})[1] - 10,
				textAnchor: "middle",
				fontSize: 16,
				children: "🛡️"
			}, `p${n}`) : null)
		]
	});
}
function nt({ color: e, kind: t, abbot: n, ghost: r }) {
	return /* @__PURE__ */ I("g", {
		opacity: r ? .6 : 1,
		children: [
			/* @__PURE__ */ F("path", {
				d: "M0,-13 C2.8,-13 4.5,-11.2 4.5,-8.8 C4.5,-7 3.6,-5.6 2.4,-5 L7.5,-1.5 C8.8,-0.6 8.4,1.4 6.9,1.4 L3.6,1.4 L5.2,11.5 C5.5,13.4 2.8,14 1.9,12.3 L0,8.5 L-1.9,12.3 C-2.8,14 -5.5,13.4 -5.2,11.5 L-3.6,1.4 L-6.9,1.4 C-8.4,1.4 -8.8,-0.6 -7.5,-1.5 L-2.4,-5 C-3.6,-5.6 -4.5,-7 -4.5,-8.8 C-4.5,-11.2 -2.8,-13 0,-13 Z",
				fill: e,
				className: "stroke-ink",
				strokeWidth: 2,
				strokeLinejoin: "round"
			}),
			t === "city" && /* @__PURE__ */ I("g", { children: [/* @__PURE__ */ F("path", {
				d: "M-7,-9 H7 L5,-13 H-5 Z",
				fill: "#f4c765",
				className: "stroke-ink",
				strokeWidth: 1.2
			}), /* @__PURE__ */ F("path", {
				d: "M-7,-2 L-2,-4 L-1,3 L-5,6 L-8,3 Z",
				fill: "#f4c765",
				className: "stroke-ink",
				strokeWidth: 1.1
			})] }),
			t === "road" && /* @__PURE__ */ I("g", { children: [/* @__PURE__ */ F("path", {
				d: "M-5,-10 Q0,-17 5,-10 L7,-5 H-7 Z",
				fill: "#6e4633",
				className: "stroke-ink",
				strokeWidth: 1.1
			}), /* @__PURE__ */ F("rect", {
				x: 5,
				y: 0,
				width: 5,
				height: 6,
				rx: 1,
				fill: "#6e4633",
				className: "stroke-ink",
				strokeWidth: 1
			})] }),
			t === "monastery" && !n && /* @__PURE__ */ I("g", { children: [/* @__PURE__ */ F("path", {
				d: "M-4,-4 L-6,8 H6 L4,-4 Z",
				fill: "#f5e5b9",
				opacity: .85
			}), /* @__PURE__ */ F("path", {
				d: "M0,-1 V5 M-2,1 H2",
				fill: "none",
				className: "stroke-ink",
				strokeWidth: 1.4
			})] }),
			t === "field" && /* @__PURE__ */ I("g", { children: [/* @__PURE__ */ F("path", {
				d: "M-9,-11 H9 M-5,-11 V-14 H5 V-11",
				fill: "none",
				stroke: "#6e4633",
				strokeWidth: 3,
				strokeLinecap: "round"
			}), /* @__PURE__ */ F("path", {
				d: "M-9,-11 H9",
				stroke: "#e5ba59",
				strokeWidth: 2,
				strokeLinecap: "round"
			})] }),
			n && /* @__PURE__ */ I("g", { children: [/* @__PURE__ */ F("path", {
				d: "M-6,-12 L0,-19 L6,-12 Z",
				fill: "#f5e5b9",
				className: "stroke-ink",
				strokeWidth: 1.3
			}), /* @__PURE__ */ F("path", {
				d: "M9,-5 V8 M9,-5 Q13,-9 13,-5",
				fill: "none",
				stroke: "#6e4633",
				strokeWidth: 1.8,
				strokeLinecap: "round"
			})] })
		]
	});
}
function rt(e, t, n) {
	let [r, i] = n;
	for (let e = 0; e < t; e++) [r, i] = [-i, r];
	let [a, o] = U(e);
	return [a * 100 + r, o * 100 + i];
}
function it(e) {
	return window.matchMedia("(orientation: landscape)").matches && e.w >= 900 && e.h >= 320 ? Math.max(1, Math.min(e.w / 700, e.h / 430, 1.8)) : 1;
}
function at(e, t) {
	let n = Object.keys(e);
	if (n.length === 0 || t.w === 0) return {
		cx: 0,
		cy: 0,
		s: 1
	};
	let r = n.map((e) => U(e)[0] * 100), i = n.map((e) => U(e)[1] * 100), a = Math.min(...r) - 160, o = Math.max(...r) + 160, s = Math.min(...i) - 160, c = Math.max(...i) + 160, l = Math.min(t.w / (o - a), t.h / (c - s), 1.2 * it(t));
	return {
		cx: (a + o) / 2,
		cy: (s + c) / 2,
		s: l
	};
}
function ot({ board: e, meeples: t, spots: n, ghost: i, lastPlacedKey: c, fitKey: l, colorOf: u, onTapCell: d, controls: f, controlsSize: p = {
	width: 220,
	height: 62
}, meepleUi: m, meepleUiSize: h }) {
	let g = o(null), [_, v] = s({
		w: 0,
		h: 0
	}), [y, b] = s(null), x = o({
		cx: 0,
		cy: 0,
		s: 1
	});
	r(() => {
		let e = g.current, t = new ResizeObserver(() => v({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let S = `${l}:${+(_.w > 0)}`, [C, ee] = s("");
	C !== S && _.w > 0 && (ee(S), b(at(e, _)));
	let w = y ?? at(e, _);
	r(() => {
		x.current = w;
	}), r(() => {
		let e = g.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = x.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.min(Math.max(r.s * i, .35), 3 * it(_)), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			x.current = u, b(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [_]);
	let T = o(/* @__PURE__ */ new Map()), E = o(0), D = o(0), O = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), T.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), T.current.size === 1 && (E.current = 0), T.current.size === 2) {
			let [e, t] = [...T.current.values()];
			D.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, k = (e) => {
		let t = T.current.get(e.pointerId);
		if (!t) return;
		let n = g.current.getBoundingClientRect();
		if (T.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			E.current += Math.abs(n) + Math.abs(r);
			let i = x.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			x.current = a, b(a);
		} else if (T.current.size === 2) {
			T.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...T.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (D.current > 0 && i > 0) {
				let e = x.current, a = Math.min(Math.max(e.s * i / D.current, .35), 3 * it(_)), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				x.current = u, b(u);
			}
			D.current = i, E.current = 99;
			return;
		}
		T.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, A = (e) => {
		let t = T.current.size === 1 && E.current < 10;
		if (T.current.delete(e.pointerId), D.current = 0, !t) return;
		let r = g.current.getBoundingClientRect(), i = x.current, a = i.cx + (e.clientX - r.left - r.width / 2) / i.s, o = i.cy + (e.clientY - r.top - r.height / 2) / i.s;
		if (!n || !d) return;
		let s = null, c = 62;
		for (let e of n) {
			let [t, n] = U(e), r = Math.hypot(t * 100 - a, n * 100 - o);
			r < c && (c = r, s = e);
		}
		s && d(s);
	}, te = a(() => Object.entries(e), [e]), ne = i && f && _.w && _.h ? ((e, t) => {
		let n = _.w / 2 + (e * 100 - w.cx) * w.s, r = _.h / 2 + (t * 100 - w.cy) * w.s, i = 100 * w.s / 2, a = p.width / 2, o = p.height / 2, s = o + 7, c = o + 9, l = r + i + s, u = r - i - s;
		if (window.matchMedia("(orientation: landscape)").matches && _.h < 320 || l > _.h - o - 29 && u < o + 29) {
			let e = n + i + a + 6, t = n - i - a - 6;
			return {
				left: Math.max(a, Math.min(_.w - a, e <= _.w - a ? e : t)),
				top: Math.max(c, Math.min(_.h - c, r))
			};
		}
		return {
			left: Math.max(a, Math.min(_.w - a, n)),
			top: Math.max(c, Math.min(_.h - c, l > _.h - o - 29 ? u : l))
		};
	})(i.x, i.y) : null, j = (e, t) => {
		let n = _.w / 2 + (e * 100 - w.cx) * w.s, r = _.h / 2 + (t * 100 - w.cy) * w.s, i = 100 * w.s / 2;
		return {
			left: n - i,
			right: n + i,
			top: r - i,
			bottom: r + i
		};
	}, M = c && m && h && _.w && _.h ? (() => {
		let e = te.map(([e]) => j(...U(e)));
		return et(_, h, e, j(...U(c)));
	})() : null;
	return /* @__PURE__ */ I("div", {
		ref: g,
		className: "relative h-full w-full overflow-hidden",
		children: [
			/* @__PURE__ */ F("svg", {
				className: "h-full w-full touch-none select-none",
				onPointerDown: O,
				onPointerMove: k,
				onPointerUp: A,
				onPointerCancel: A,
				children: /* @__PURE__ */ I("g", {
					transform: `translate(${_.w / 2 - w.cx * w.s}, ${_.h / 2 - w.cy * w.s}) scale(${w.s})`,
					children: [
						n && [...n].map((e) => {
							let [t, n] = U(e);
							return /* @__PURE__ */ F("rect", {
								x: t * 100 - 46,
								y: n * 100 - 46,
								width: 92,
								height: 92,
								rx: 6,
								fill: "var(--color-info-soft)",
								fillOpacity: .5,
								className: "stroke-info-ink",
								strokeWidth: 3,
								strokeDasharray: "9 7"
							}, `s${e}`);
						}),
						te.map(([e, t]) => {
							let [n, r] = U(e);
							return /* @__PURE__ */ F("g", {
								transform: `translate(${n * 100}, ${r * 100}) rotate(${t.rot * 90})`,
								children: /* @__PURE__ */ F(tt, { tile: t.tile })
							}, e);
						}),
						c && (() => {
							let [e, t] = U(c);
							return /* @__PURE__ */ F("rect", {
								x: e * 100 - 50,
								y: t * 100 - 50,
								width: 100,
								height: 100,
								rx: 6,
								fill: "none",
								className: "stroke-ink",
								strokeWidth: 3,
								strokeDasharray: "4 6",
								opacity: .4
							});
						})(),
						i && /* @__PURE__ */ F("g", {
							transform: `translate(${i.x * 100}, ${i.y * 100})`,
							children: /* @__PURE__ */ F("g", {
								className: "carc-ghost-bob",
								children: /* @__PURE__ */ F("g", {
									transform: `rotate(${i.rot * 90})`,
									children: /* @__PURE__ */ F(tt, {
										tile: i.tile,
										ghost: !0
									})
								})
							})
						}),
						Object.entries(t).map(([t, n]) => {
							let r = e[t];
							if (!r) return null;
							let i = q(r.tile)[n.zone], [a, o] = rt(t, r.rot, we(r.tile, i));
							return /* @__PURE__ */ F("g", {
								transform: `translate(${a}, ${o})`,
								pointerEvents: "none",
								children: /* @__PURE__ */ F(nt, {
									color: u(n.rid),
									kind: i.kind,
									abbot: n.abbot
								})
							}, `m${t}`);
						})
					]
				})
			}),
			ne && /* @__PURE__ */ F("div", {
				className: "carc-board-controls",
				style: ne,
				children: f
			}),
			M && /* @__PURE__ */ F("div", {
				className: "carc-meeple-ui",
				style: M,
				children: m
			})
		]
	});
}
//#endregion
//#region src/games/carcassonne/meeple-model.tsx
var st = new M(), ct = [
	[-.22, 0],
	[-.22, .27],
	[-.3, .2],
	[-.43, .28],
	[-.32, .44],
	[-.13, .53],
	[.13, .53],
	[.32, .44],
	[.43, .28],
	[.3, .2],
	[.22, .27],
	[.22, 0],
	[.06, 0],
	[0, .13],
	[-.06, 0]
];
st.moveTo(...ct[0]);
for (let [e, t] of ct.slice(1)) st.lineTo(e, t);
st.closePath();
var lt = new O(st, {
	depth: .22,
	bevelEnabled: !0,
	bevelSize: .025,
	bevelThickness: .025,
	bevelSegments: 1,
	curveSegments: 1
}), ut = new N(.18, 8, 6), dt = new M();
dt.moveTo(-.12, .12), dt.lineTo(.12, .12), dt.lineTo(.1, -.05), dt.lineTo(0, -.16), dt.lineTo(-.1, -.05), dt.closePath();
var ft = new O(dt, {
	depth: .045,
	bevelEnabled: !1
}), pt = new A({
	color: "#f4c765",
	flatShading: !0
}), mt = new A({
	color: "#6e4633",
	flatShading: !0
}), ht = new A({
	color: "#f5e5b9",
	flatShading: !0
}), gt = new A({
	color: "#e5ba59",
	flatShading: !0
}), _t = /* @__PURE__ */ new Map();
function vt(e) {
	let t = _t.get(e);
	if (t) return t;
	let n = new E(e), r = {
		body: [new A({
			color: n.clone().lerp(new E("#ffffff"), .14),
			flatShading: !0
		}), new A({
			color: n.clone().multiplyScalar(.68),
			flatShading: !0
		})],
		trim: new A({
			color: n.clone().multiplyScalar(.42),
			flatShading: !0
		}),
		accent: new A({
			color: n.clone().lerp(new E("#ffffff"), .43),
			flatShading: !0
		})
	};
	return _t.set(e, r), r;
}
function yt({ x: e, z: t, groundY: n, color: r, kind: i, abbot: a = !1, choice: o = !1 }) {
	let s = vt(r), c = i === "field";
	return /* @__PURE__ */ F("group", {
		position: [
			e,
			n,
			t
		],
		children: /* @__PURE__ */ I("group", {
			position: [
				0,
				o ? .15 : 0,
				0
			],
			rotation: [
				o ? -.38 : c ? -.25 : -.8,
				0,
				0
			],
			scale: o ? .74 : .6,
			children: [
				/* @__PURE__ */ F("mesh", {
					geometry: lt,
					material: s.trim,
					position: [
						0,
						0,
						-.045
					],
					scale: [
						1.08,
						1.08,
						1
					]
				}),
				/* @__PURE__ */ F("mesh", {
					geometry: lt,
					material: s.body
				}),
				/* @__PURE__ */ F("mesh", {
					geometry: ut,
					material: s.trim,
					position: [
						0,
						.73,
						.065
					],
					scale: 1.13
				}),
				/* @__PURE__ */ F("mesh", {
					geometry: ut,
					material: s.body[0],
					position: [
						0,
						.73,
						.12
					]
				}),
				/* @__PURE__ */ F("mesh", {
					material: s.accent,
					position: [
						0,
						.25,
						.255
					],
					children: /* @__PURE__ */ F("boxGeometry", { args: [
						.075,
						.28,
						.015
					] })
				}),
				i === "city" && /* @__PURE__ */ I("group", { children: [
					/* @__PURE__ */ F("mesh", {
						material: pt,
						position: [
							0,
							.94,
							.11
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: [
							.37,
							.13,
							.29
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: pt,
						position: [
							0,
							1.045,
							.11
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: [
							.11,
							.16,
							.25
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						geometry: ft,
						material: pt,
						position: [
							-.33,
							.34,
							.23
						],
						rotation: [
							0,
							-.28,
							-.12
						]
					})
				] }),
				i === "road" && /* @__PURE__ */ I("group", { children: [
					/* @__PURE__ */ F("mesh", {
						material: mt,
						position: [
							0,
							.84,
							.075
						],
						children: /* @__PURE__ */ F("sphereGeometry", { args: [
							.225,
							7,
							5
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: s.body[0],
						position: [
							0,
							.7,
							.23
						],
						children: /* @__PURE__ */ F("sphereGeometry", { args: [
							.16,
							7,
							5
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: mt,
						position: [
							.28,
							.18,
							.17
						],
						rotation: [
							0,
							0,
							-.18
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: [
							.21,
							.27,
							.19
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: pt,
						position: [
							.29,
							.26,
							.275
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: [
							.1,
							.045,
							.02
						] })
					})
				] }),
				i === "monastery" && !a && /* @__PURE__ */ I("group", { children: [
					/* @__PURE__ */ F("mesh", {
						material: ht,
						position: [
							0,
							.55,
							.24
						],
						children: /* @__PURE__ */ F("torusGeometry", { args: [
							.17,
							.06,
							4,
							7
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: ht,
						position: [
							0,
							.24,
							.25
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: [
							.26,
							.42,
							.045
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: mt,
						position: [
							0,
							.27,
							.285
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: [
							.05,
							.23,
							.025
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: mt,
						position: [
							0,
							.3,
							.3
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: [
							.17,
							.05,
							.03
						] })
					})
				] }),
				c && /* @__PURE__ */ I("group", { children: [
					/* @__PURE__ */ F("mesh", {
						material: gt,
						position: [
							0,
							.91,
							.1
						],
						children: /* @__PURE__ */ F("cylinderGeometry", { args: [
							.3,
							.3,
							.055,
							8
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: gt,
						position: [
							0,
							.99,
							.1
						],
						children: /* @__PURE__ */ F("cylinderGeometry", { args: [
							.16,
							.19,
							.16,
							8
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: mt,
						position: [
							0,
							.93,
							.1
						],
						children: /* @__PURE__ */ F("cylinderGeometry", { args: [
							.17,
							.17,
							.045,
							8
						] })
					})
				] }),
				a && /* @__PURE__ */ I("group", { children: [
					/* @__PURE__ */ F("mesh", {
						material: ht,
						position: [
							0,
							.98,
							.12
						],
						children: /* @__PURE__ */ F("coneGeometry", { args: [
							.23,
							.36,
							4
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: pt,
						position: [
							0,
							.89,
							.315
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: [
							.065,
							.18,
							.02
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: mt,
						position: [
							.35,
							.31,
							.1
						],
						rotation: [
							0,
							0,
							.12
						],
						children: /* @__PURE__ */ F("cylinderGeometry", { args: [
							.025,
							.025,
							.74,
							5
						] })
					}),
					/* @__PURE__ */ F("mesh", {
						material: pt,
						position: [
							.38,
							.71,
							.1
						],
						children: /* @__PURE__ */ F("torusGeometry", { args: [
							.09,
							.025,
							4,
							8,
							Math.PI
						] })
					})
				] })
			]
		})
	});
}
function bt({ onReady: e }) {
	let t = o(!1);
	return S(() => {
		t.current || (t.current = !0, requestAnimationFrame(e));
	}), null;
}
function xt({ choices: e, color: t, columns: n, onReady: r }) {
	let i = Math.ceil(e.length / n);
	return /* @__PURE__ */ I(ee, {
		orthographic: !0,
		camera: {
			position: [
				0,
				0,
				8
			],
			zoom: 48
		},
		dpr: [1, 1.5],
		frameloop: "demand",
		gl: {
			alpha: !0,
			antialias: !0,
			powerPreference: "low-power"
		},
		style: {
			position: "absolute",
			inset: 0,
			pointerEvents: "none"
		},
		children: [
			/* @__PURE__ */ F("ambientLight", { intensity: .9 }),
			/* @__PURE__ */ F("directionalLight", {
				position: [
					-3,
					6,
					7
				],
				intensity: 1.25
			}),
			/* @__PURE__ */ F(bt, { onReady: r }),
			e.map((e, r) => /* @__PURE__ */ F("group", {
				position: [
					(r % n - (n - 1) / 2) * (68 / 48),
					((i - 1) / 2 - Math.floor(r / n)) * (78 / 48) - .14,
					0
				],
				children: /* @__PURE__ */ F(yt, {
					x: 0,
					z: 0,
					groundY: 0,
					kind: e.kind,
					abbot: e.abbot,
					color: t,
					choice: !0
				})
			}, `${e.zone}:${e.abbot}`))
		]
	});
}
//#endregion
//#region src/games/carcassonne/board3d.tsx
var Z = {
	edge: new A({
		color: "#61452e",
		flatShading: !0
	}),
	grass: new A({
		color: "#78ae4f",
		flatShading: !0
	}),
	grassPatches: new A({
		vertexColors: !0,
		side: D,
		flatShading: !0
	}),
	city: new A({
		color: "#d99159",
		flatShading: !0
	}),
	citySide: new A({
		color: "#aa653f",
		flatShading: !0
	}),
	wall: new A({
		color: "#e6bc7b",
		flatShading: !0
	}),
	wallCap: new A({
		color: "#ffe0a2",
		flatShading: !0
	}),
	roadEdge: new A({
		color: "#8b6845",
		flatShading: !0
	}),
	roadBase: new A({
		color: "#d3b386",
		flatShading: !0,
		side: D
	}),
	road: new A({
		color: "#f8e8bc",
		flatShading: !0
	}),
	roof: new A({
		color: "#b9573c",
		flatShading: !0
	}),
	roofOchre: new A({
		color: "#db7e3c",
		flatShading: !0
	}),
	bannerRoof: new A({
		color: "#377fa5",
		flatShading: !0
	}),
	bannerTip: new A({
		color: "#f4ce6b",
		flatShading: !0
	}),
	window: new A({
		color: "#634737",
		flatShading: !0
	}),
	trunk: new A({
		color: "#835b3d",
		flatShading: !0
	}),
	leaves: new A({
		color: "#468d54",
		flatShading: !0
	}),
	abbey: new A({
		color: "#f7e9ca",
		flatShading: !0
	}),
	straw: new A({
		color: "#f1c65d",
		flatShading: !0
	}),
	strawEdge: new A({
		color: "#ba8d3e",
		flatShading: !0
	})
}, Q = 2, St = 34, Ct = .08, $ = new P(1.5, 14, 10.5).normalize(), wt = 2 * Math.tan(St * Math.PI / 360), Tt = new w(Q, .16, Q), Et = new w(1.975, .045, 1.975), Dt = new j(), Ot = new ne(new P(0, 1, 0), 0), kt = new P();
function At() {
	try {
		let e = document.createElement("canvas");
		return !!(e.getContext("webgl2") ?? e.getContext("webgl"));
	} catch {
		return !1;
	}
}
var jt = /* @__PURE__ */ new Map();
function Mt(e, t) {
	let n = t ? new M() : new te();
	for (let t of e.match(/[MLQZ][^MLQZ]*/g) ?? []) {
		let e = (t.slice(1).match(/-?\d+(?:\.\d+)?/g) ?? []).map(Number), r = (t) => e[t] / 50, i = (t) => -e[t] / 50;
		t[0] === "M" ? n.moveTo(r(0), i(1)) : t[0] === "L" ? n.lineTo(r(0), i(1)) : t[0] === "Q" ? n.quadraticCurveTo(r(0), i(1), r(2), i(3)) : n.closePath();
	}
	return n;
}
function Nt(e, t) {
	let n = !1;
	for (let r = 0, i = t.length - 1; r < t.length; i = r++) {
		let a = t[r], o = t[i];
		a.z > e.z != o.z > e.z && e.x < (o.x - a.x) * (e.z - a.z) / (o.z - a.z) + a.x && (n = !n);
	}
	return n;
}
function Pt(e, t, n) {
	let r = n.x - t.x, i = n.z - t.z, a = Math.max(0, Math.min(1, ((e.x - t.x) * r + (e.z - t.z) * i) / (r * r + i * i || 1)));
	return Math.hypot(e.x - t.x - a * r, e.z - t.z - a * i);
}
function Ft(e, t, n) {
	let r = [], i = [];
	for (let a = 0; a < e.length; a++) {
		let o = e[Math.max(0, a - 1)], s = e[Math.min(e.length - 1, a + 1)], c = s.x - o.x, l = s.z - o.z, u = Math.hypot(c, l) || 1, d = -l / u * t / 2, f = c / u * t / 2;
		if (r.push(e[a].x + d, n, e[a].z + f, e[a].x - d, n, e[a].z - f), a > 0) {
			let e = a * 2;
			i.push(e - 2, e, e - 1, e - 1, e, e + 1);
		}
	}
	let a = new T();
	return a.setAttribute("position", new k(r, 3)), a.setIndex(i), a.computeVertexNormals(), a;
}
function It(e, t, n, r) {
	let i = [], a = [];
	for (let o = 0; o < e.length; o++) {
		let s = e[Math.max(0, o - 1)], c = e[Math.min(e.length - 1, o + 1)], l = c.x - s.x, u = c.z - s.z, d = Math.hypot(l, u) || 1, f = -u / d * t / 2, p = l / d * t / 2;
		if (i.push(e[o].x + f, r, e[o].z + p, e[o].x - f, r, e[o].z - p, e[o].x + f, n, e[o].z + p, e[o].x - f, n, e[o].z - p), o === 0) continue;
		let m = (o - 1) * 4, h = o * 4;
		a.push(m, h, m + 1, m + 1, h, h + 1), a.push(m + 2, m, h + 2, h + 2, m, h), a.push(m + 1, m + 3, h + 1, h + 1, m + 3, h + 3);
	}
	let o = new T();
	return o.setAttribute("position", new k(i, 3)), o.setIndex(a), o.computeVertexNormals(), o;
}
function Lt(e, t) {
	let n = [], r = [], i = [
		"#6da749",
		"#8fbd5f",
		"#a6c86a"
	];
	[
		{
			x: -.72,
			z: -.36
		},
		{
			x: -.36,
			z: -.66
		},
		{
			x: .12,
			z: -.72
		},
		{
			x: .66,
			z: -.44
		},
		{
			x: -.7,
			z: .11
		},
		{
			x: -.3,
			z: .1
		},
		{
			x: .32,
			z: -.05
		},
		{
			x: .7,
			z: .18
		},
		{
			x: -.6,
			z: .58
		},
		{
			x: -.09,
			z: .63
		},
		{
			x: .38,
			z: .52
		},
		{
			x: .72,
			z: .66
		}
	].forEach((a, o) => {
		if (!t(a)) return;
		let s = .12 + (e + o) % 3 * .025, c = new E(i[(e + o * 2) % i.length]);
		n.push(a.x - s, .05, a.z + s * .3, a.x + s, .05, a.z - s * .25, a.x + s * .15, .05, a.z + s);
		for (let e = 0; e < 3; e++) r.push(c.r, c.g, c.b);
	});
	let a = new T();
	return a.setAttribute("position", new k(n, 3)), a.setAttribute("color", new k(r, 3)), a.computeVertexNormals(), a;
}
function Rt(e) {
	let t = jt.get(e);
	if (t) return t;
	let n = V[e], r = Qe(n), i = r.paths.map((e) => Mt(e, !1).getPoints(12).map((e) => ({
		x: e.x,
		z: -e.y
	}))), a = n.cities.map((t, r) => {
		let i = Mt(Ze(n, r), !0), a = i.getPoints(12).map((e) => ({
			x: e.x,
			z: -e.y
		})), o = [];
		for (let e = 0; e < a.length; e++) {
			let t = a[e], n = a[(e + 1) % a.length], r = Math.abs(t.x) > .999 && Math.abs(n.x) > .999 && Math.sign(t.x) === Math.sign(n.x) || Math.abs(t.z) > .999 && Math.abs(n.z) > .999 && Math.sign(t.z) === Math.sign(n.z), i = Math.hypot(n.x - t.x, n.z - t.z);
			!r && i > .025 && o.push({
				x: (t.x + n.x) / 2,
				z: (t.z + n.z) / 2,
				length: i,
				angle: -Math.atan2(n.z - t.z, n.x - t.x)
			});
		}
		let s = we(e, {
			kind: "city",
			ref: r
		}), c = s[0] / 50, l = s[1] / 50, u = [
			-.78,
			-.5,
			-.22,
			.06,
			.34,
			.62,
			.82
		], d = u.flatMap((e) => u.map((t) => ({
			x: t,
			z: e
		}))).map((t, n) => ({
			point: t,
			order: (n * 37 + e * 11 + r * 13) % 53
		})).sort((e, t) => e.order - t.order), f = [
			0,
			5,
			9,
			12,
			15
		][n.cities[r].edges.length], p = [];
		for (let { point: e } of d) if (!(!Nt(e, a) || Math.hypot(e.x - c, e.z - l) < .24) && !a.some((t, n) => Pt(e, t, a[(n + 1) % a.length]) < .14) && !p.some((t) => Math.hypot(e.x - t.x, e.z - t.z) < .32) && (p.push(e), p.length === f)) break;
		if (p.length === 0) {
			let e = G[n.cities[r].edges[0]], t = e[0] / 50, i = e[1] / 50, o = [{
				x: t * .76 - i * .35,
				z: i * .76 + t * .35
			}, {
				x: t * .76 + i * .35,
				z: i * .76 - t * .35
			}], s = o.find((e) => Nt(e, a) && Math.hypot(e.x - c, e.z - l) > .33) ?? (n.cities[r].edges.length === 1 ? o[0] : void 0);
			s && p.push(s);
		}
		let m = o.length > 2 ? [o[Math.floor(o.length * .2)], o[Math.floor(o.length * .8)]].map((e) => ({
			x: e.x,
			z: e.z
		})) : [], h = new O(i, {
			depth: .12,
			bevelEnabled: !1,
			curveSegments: 1
		});
		return h.rotateX(-Math.PI / 2), {
			geometry: h,
			outline: a,
			walls: o,
			turrets: m,
			houses: p
		};
	}), o = [
		{
			x: -.68,
			z: -.65
		},
		{
			x: .67,
			z: -.62
		},
		{
			x: -.62,
			z: .64
		},
		{
			x: .66,
			z: .63
		},
		{
			x: -.12,
			z: -.67
		},
		{
			x: .14,
			z: .68
		}
	], s = (e) => n.monastery && Math.hypot(e.x, e.z) < .65 || a.some((t) => Nt(e, t.outline)) ? !1 : i.every((t) => t.every((n, r) => r === 0 || Pt(e, t[r - 1], n) > .29)), c = o.filter(s).slice(0, 2), l = n.fields.map((t, n) => {
		let [r, i] = we(e, {
			kind: "field",
			ref: n
		});
		return {
			x: r / 50,
			z: i / 50
		};
	}), u = [
		{
			x: -.45,
			z: .57
		},
		{
			x: .46,
			z: .56
		},
		{
			x: -.48,
			z: -.5
		},
		{
			x: .47,
			z: -.48
		}
	].filter((e) => s(e) && c.every((t) => Math.hypot(e.x - t.x, e.z - t.z) > .36) && l.every((t) => Math.hypot(e.x - t.x, e.z - t.z) > .3)).slice(0, 2), d = {
		cities: a,
		roads: i.map((e) => ({
			edge: Ft(e, .42, .052),
			base: It(e, .33, .053, .09),
			center: Ft(e, .25, .095)
		})),
		grassPatches: Lt(e, s),
		trees: c,
		hay: u,
		junction: r.junction
	};
	return jt.set(e, d), d;
}
function zt({ x: e, z: t }) {
	return /* @__PURE__ */ I("group", {
		position: [
			e,
			.06,
			t
		],
		scale: .6,
		children: [/* @__PURE__ */ F("mesh", {
			material: Z.trunk,
			position: [
				0,
				.13,
				0
			],
			children: /* @__PURE__ */ F("cylinderGeometry", { args: [
				.045,
				.06,
				.26,
				5
			] })
		}), /* @__PURE__ */ F("mesh", {
			material: Z.leaves,
			position: [
				0,
				.33,
				0
			],
			children: /* @__PURE__ */ F("coneGeometry", { args: [
				.18,
				.43,
				5
			] })
		})]
	});
}
function Bt({ x: e, z: t, pennant: n = !1, variant: r = 0 }) {
	let i = n ? Z.bannerRoof : r % 3 == 0 ? Z.roof : Z.roofOchre;
	return /* @__PURE__ */ I("group", {
		position: [
			e,
			.17,
			t
		],
		scale: .68,
		children: [
			/* @__PURE__ */ F("mesh", {
				material: Z.citySide,
				position: [
					0,
					.015,
					0
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.34,
					.04,
					.31
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.abbey,
				position: [
					0,
					.16,
					0
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.3,
					.27,
					.28
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: i,
				position: [
					0,
					.34,
					0
				],
				rotation: [
					0,
					Math.PI / 4,
					0
				],
				children: /* @__PURE__ */ F("coneGeometry", { args: [
					.26,
					.22,
					4
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.window,
				position: [
					-.07,
					.15,
					.147
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.045,
					.075,
					.014
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.window,
				position: [
					.07,
					.15,
					.147
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.045,
					.075,
					.014
				] })
			}),
			n && /* @__PURE__ */ F("mesh", {
				material: Z.bannerTip,
				position: [
					0,
					.52,
					0
				],
				children: /* @__PURE__ */ F("octahedronGeometry", { args: [.08, 0] })
			})
		]
	});
}
function Vt({ x: e, z: t }) {
	return /* @__PURE__ */ I("group", {
		position: [
			e,
			.07,
			t
		],
		rotation: [
			0,
			Math.PI / 6,
			0
		],
		scale: .75,
		children: [
			/* @__PURE__ */ F("mesh", {
				material: Z.strawEdge,
				position: [
					0,
					.005,
					0
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.36,
					.05,
					.29
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.straw,
				position: [
					-.075,
					.06,
					0
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.14,
					.11,
					.25
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.straw,
				position: [
					.075,
					.06,
					0
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.14,
					.11,
					.25
				] })
			})
		]
	});
}
function Ht({ x: e, z: t }) {
	return /* @__PURE__ */ I("group", {
		position: [
			e,
			.17,
			t
		],
		scale: .62,
		children: [
			/* @__PURE__ */ F("mesh", {
				material: Z.wall,
				position: [
					0,
					.22,
					0
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.24,
					.44,
					.24
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.wallCap,
				position: [
					0,
					.46,
					0
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.3,
					.07,
					.3
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.roof,
				position: [
					0,
					.61,
					0
				],
				rotation: [
					0,
					Math.PI / 4,
					0
				],
				children: /* @__PURE__ */ F("coneGeometry", { args: [
					.22,
					.22,
					4
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.window,
				position: [
					0,
					.33,
					.128
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.055,
					.1,
					.014
				] })
			})
		]
	});
}
function Ut() {
	return /* @__PURE__ */ I("group", {
		position: [
			0,
			.04,
			0
		],
		scale: .7,
		children: [
			/* @__PURE__ */ F("mesh", {
				material: Z.roadEdge,
				position: [
					0,
					.035,
					0
				],
				children: /* @__PURE__ */ F("cylinderGeometry", { args: [
					.44,
					.48,
					.07,
					8
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.abbey,
				position: [
					0,
					.19,
					0
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.44,
					.29,
					.38
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.roof,
				position: [
					0,
					.42,
					0
				],
				rotation: [
					0,
					Math.PI / 4,
					0
				],
				children: /* @__PURE__ */ F("coneGeometry", { args: [
					.36,
					.24,
					4
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.abbey,
				position: [
					.21,
					.39,
					-.1
				],
				children: /* @__PURE__ */ F("boxGeometry", { args: [
					.12,
					.45,
					.12
				] })
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.roof,
				position: [
					.21,
					.67,
					-.1
				],
				rotation: [
					0,
					Math.PI / 4,
					0
				],
				children: /* @__PURE__ */ F("coneGeometry", { args: [
					.13,
					.13,
					4
				] })
			})
		]
	});
}
function Wt({ tile: e, x: t, y: n, rot: r, lifted: i = !1 }) {
	let s = a(() => Rt(e), [e]), c = V[e], l = o(null);
	return S((e) => {
		if (!i || !l.current) return;
		let t = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		l.current.position.y = .22 + (t ? 0 : Math.sin(e.clock.elapsedTime * 3.2) * .055), t || e.invalidate();
	}), /* @__PURE__ */ I("group", {
		ref: l,
		position: [
			t * Q,
			i ? .22 : 0,
			n * Q
		],
		rotation: [
			0,
			-r * Math.PI / 2,
			0
		],
		children: [
			!i && /* @__PURE__ */ I("mesh", {
				position: [
					.1,
					-.18,
					.11
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ F("planeGeometry", { args: [2.08, 2.08] }), /* @__PURE__ */ F("meshBasicMaterial", {
					color: "#554334",
					transparent: !0,
					opacity: .14
				})]
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.edge,
				geometry: Tt,
				position: [
					0,
					-.08,
					0
				]
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.grass,
				geometry: Et,
				position: [
					0,
					.025,
					0
				]
			}),
			/* @__PURE__ */ F("mesh", {
				material: Z.grassPatches,
				geometry: s.grassPatches
			}),
			s.cities.map((e, t) => /* @__PURE__ */ I("group", { children: [
				/* @__PURE__ */ F("mesh", {
					material: [Z.city, Z.citySide],
					geometry: e.geometry,
					position: [
						0,
						.048,
						0
					]
				}),
				e.walls.map((e, t) => /* @__PURE__ */ I("group", {
					position: [
						e.x,
						0,
						e.z
					],
					rotation: [
						0,
						e.angle,
						0
					],
					children: [/* @__PURE__ */ F("mesh", {
						material: Z.wall,
						position: [
							0,
							.29,
							0
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: [
							e.length + .015,
							.18,
							.085
						] })
					}), /* @__PURE__ */ F("mesh", {
						material: Z.wallCap,
						position: [
							0,
							.395,
							0
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: [
							e.length + .025,
							.04,
							.12
						] })
					})]
				}, t)),
				e.turrets.map((e, t) => /* @__PURE__ */ F(Ht, { ...e }, `turret${t}`)),
				e.houses.map((e, n) => /* @__PURE__ */ F(Bt, {
					...e,
					variant: n,
					pennant: c.cities[t].pennant && n === 0
				}, n))
			] }, `city${t}`)),
			s.roads.map((e, t) => /* @__PURE__ */ I("group", { children: [
				/* @__PURE__ */ F("mesh", {
					material: Z.roadEdge,
					geometry: e.edge
				}),
				/* @__PURE__ */ F("mesh", {
					material: Z.roadBase,
					geometry: e.base
				}),
				/* @__PURE__ */ F("mesh", {
					material: Z.road,
					geometry: e.center
				})
			] }, `road${t}`)),
			s.junction && /* @__PURE__ */ I("group", { children: [/* @__PURE__ */ F("mesh", {
				material: Z.roadBase,
				position: [
					0,
					.072,
					0
				],
				children: /* @__PURE__ */ F("cylinderGeometry", { args: [
					.2,
					.23,
					.045,
					12
				] })
			}), /* @__PURE__ */ F("mesh", {
				material: Z.road,
				position: [
					0,
					.098,
					0
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				children: /* @__PURE__ */ F("circleGeometry", { args: [.16, 12] })
			})] }),
			c.monastery && /* @__PURE__ */ F(Ut, {}),
			s.hay.map((e, t) => /* @__PURE__ */ F(Vt, { ...e }, t)),
			s.trees.map((e, t) => /* @__PURE__ */ F(zt, { ...e }, t))
		]
	});
}
function Gt(e, t, n, r) {
	let i = (r ?? [...Object.keys(e), ...t ?? []]).map(U);
	if (i.length === 0 || !n.w || !n.h) return {
		cx: 0,
		cy: 0,
		s: 55
	};
	let a = i.map(([e]) => e * Q), o = i.map(([, e]) => e * Q), s = r ? 1.28 : t ? .98 : 1.28, c = Math.min(...a) - s, l = Math.max(...a) + s, u = Math.min(...o) - s, d = Math.max(...o) + s, f = (c + l) / 2, p = (u + d) / 2, m = n.h / wt, h = Math.hypot($.x, $.z), g = $.z / h, _ = -$.x / h, v = -$.y * $.x / h, y = h, b = -$.y * $.z / h, x = (e) => {
		let t = m / e;
		for (let e of [c, l]) for (let r of [u, d]) for (let i of [-.25, 1]) {
			let a = e - f, o = i - Ct, s = r - p, c = t - (a * $.x + o * $.y + s * $.z);
			if (c <= .1) return !1;
			let l = (a * g + s * _) * m / c, u = (a * v + o * y + s * b) * m / c;
			if (Math.abs(l) > n.w / 2 - 8 || Math.abs(u) > n.h / 2 - 8) return !1;
		}
		return !0;
	}, S = 10, C = (r ? 62 : 54) * it(n);
	for (let e = 0; e < 18; e++) {
		let e = (S + C) / 2;
		x(e) ? S = e : C = e;
	}
	return {
		cx: f,
		cy: p,
		s: S
	};
}
function Kt({ view: e, cameraRef: t }) {
	let n = C((e) => e.camera), i = C((e) => e.invalidate), a = C((e) => e.size.height);
	return r(() => (t.current = n, () => {
		t.current = null;
	}), [n, t]), r(() => {
		i();
	}, [
		i,
		e,
		a
	]), S(() => {
		let n = t.current;
		if (!n) return;
		let r = a / (wt * e.s);
		n.position.set(e.cx + $.x * r, Ct + $.y * r, e.cy + $.z * r), n.lookAt(e.cx, Ct, e.cy), n.updateProjectionMatrix();
	}), null;
}
function qt(e, t, n, r, i) {
	let a = i.h / wt, o = a / r.s, s = Math.hypot($.x, $.z), c = e - r.cx, l = n - Ct, u = t - r.cy, d = o - (c * $.x + l * $.y + u * $.z);
	return {
		x: i.w / 2 + (c * $.z - u * $.x) / s * a / d,
		y: i.h / 2 - (-c * $.y * $.x / s + l * s - u * $.y * $.z / s) * a / d
	};
}
function Jt(e, t, n, r) {
	let i = [-1, 1].flatMap((i) => [-1, 1].flatMap((a) => [0, .85].map((o) => qt(e * Q + i, t * Q + a, o, n, r))));
	return {
		left: Math.min(...i.map((e) => e.x)),
		right: Math.max(...i.map((e) => e.x)),
		top: Math.min(...i.map((e) => e.y)),
		bottom: Math.max(...i.map((e) => e.y))
	};
}
function Yt(e, t, n, r) {
	let i = (e, r) => qt(e, r, .4, t, n), a = i(e.x * Q, e.y * Q), o = [-1, 1].flatMap((t) => [-1, 1].map((n) => i(e.x * Q + t, e.y * Q + n))), s = Math.min(...o.map((e) => e.x)), c = Math.max(...o.map((e) => e.x)), l = r.width / 2, u = r.height / 2, d = u + 9, f = Math.max(...o.map((e) => e.y)) + u + 7, p = Math.min(...o.map((e) => e.y)) - u - 7;
	if (window.matchMedia("(orientation: landscape)").matches && n.h < 320 || f > n.h - u - 29 && p < u + 29) {
		let e = c + l + 6, t = s - l - 6;
		return {
			left: Math.max(l, Math.min(n.w - l, e <= n.w - l ? e : t)),
			top: Math.max(d, Math.min(n.h - d, a.y))
		};
	}
	return {
		left: Math.max(l, Math.min(n.w - l, a.x)),
		top: Math.max(d, Math.min(n.h - d, f > n.h - u - 29 ? p : f))
	};
}
function Xt({ board: e, meeples: t, spots: n, ghost: i, lastPlacedKey: c, fitKey: l, colorOf: u, onTapCell: d, controls: f, controlsSize: p = {
	width: 220,
	height: 62
}, meepleUi: m, meepleUiSize: h }) {
	let g = o(null), _ = o(null), [v, y] = s({
		w: 0,
		h: 0
	}), [b, x] = s({
		cx: 0,
		cy: 0,
		s: 55
	}), S = o(b), [C, w] = s(""), T = o(/* @__PURE__ */ new Map()), E = o(0), D = o(0), O = a(() => Object.entries(e), [e]), k = O.length, A = a(() => {
		let t = [];
		for (let [n, r] of O) {
			let [i, a] = U(n);
			for (let o of [1, 2]) {
				let s = e[W(i, a, o)];
				s && xe(V[r.tile], r.rot, o) === "c" && xe(V[s.tile], s.rot, (o + 2) % 4) === "c" && t.push({
					key: `${n}:${o}`,
					x: (i + (o === 1 ? .5 : 0)) * Q,
					z: (a + (o === 2 ? .5 : 0)) * Q,
					dir: o
				});
			}
		}
		return t;
	}, [e, O]), te = i && f && v.w && v.h ? Yt(i, b, v, p) : null, ne = c && m && h && v.w && v.h ? (() => {
		let [e, t] = U(c), n = O.map(([e]) => Jt(...U(e), b, v));
		return et(v, h, n, Jt(e, t, b, v));
	})() : null;
	r(() => {
		let e = g.current, t = new ResizeObserver(() => y({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let j = `${l}:${v.w}:${v.h}`;
	v.w > 0 && v.h > 0 && j !== C && (w(j), x(Gt(e, l === "0" ? void 0 : n, v))), r(() => {
		S.current = b;
	}, [b]);
	let M = o(k);
	r(() => {
		if (!n || i || !v.w || !v.h || M.current === k) return;
		M.current = k;
		let t = Gt(e, void 0, v);
		S.current = t, x(t);
	}, [
		e,
		k,
		v,
		i,
		n
	]);
	let N = o(""), P = i ? H(i.x, i.y) : "";
	r(() => {
		if (!P) {
			N.current = "";
			return;
		}
		let t = `${P}:${v.w}:${v.h}`;
		if (!v.w || !v.h || N.current === t) return;
		N.current = t;
		let [n, r] = U(P), i = Object.keys(e).map(U).reduce((e, t) => e ? Math.abs(t[0] - n) + Math.abs(t[1] - r) < Math.abs(e[0] - n) + Math.abs(e[1] - r) ? t : e : t, null), a = Gt(e, void 0, v, [P, H(i?.[0] ?? n, i?.[1] ?? r)]);
		S.current = a, x(a);
	}, [
		P,
		v,
		e
	]), r(() => {
		let e = g.current, t = (e) => {
			e.preventDefault();
			let t = S.current, n = {
				...t,
				s: Math.max(10, Math.min(150 * it(v), t.s * (e.deltaY < 0 ? 1.15 : 1 / 1.15)))
			};
			S.current = n, x(n);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [v]);
	let ae = (e, t) => {
		let n = _.current, r = g.current;
		if (!n || !r) return null;
		let i = r.getBoundingClientRect(), a = new re((e - i.left) / i.width * 2 - 1, -((t - i.top) / i.height) * 2 + 1);
		return Dt.setFromCamera(a, n), Dt.ray.intersectPlane(Ot, kt)?.clone() ?? null;
	};
	return /* @__PURE__ */ I("div", {
		ref: g,
		className: "relative h-full w-full touch-none overflow-hidden cursor-grab active:cursor-grabbing",
		onPointerDown: (e) => {
			if (e.currentTarget.setPointerCapture(e.pointerId), T.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			}), T.current.size === 1 && (E.current = 0), T.current.size === 2) {
				let [e, t] = [...T.current.values()];
				D.current = Math.hypot(e.x - t.x, e.y - t.y);
			}
		},
		onPointerMove: (e) => {
			let t = T.current.get(e.pointerId);
			if (!t) return;
			let n = e.clientX - t.x, r = e.clientY - t.y;
			if (T.current.size === 1) {
				E.current += Math.abs(n) + Math.abs(r);
				let i = ae(t.x, t.y), a = ae(e.clientX, e.clientY);
				if (i && a) {
					let e = S.current, t = {
						...e,
						cx: e.cx + i.x - a.x,
						cy: e.cy + i.z - a.z
					};
					S.current = t, x(t);
				}
			} else if (T.current.size === 2) {
				T.current.set(e.pointerId, {
					x: e.clientX,
					y: e.clientY
				});
				let [t, n] = [...T.current.values()], r = Math.hypot(t.x - n.x, t.y - n.y);
				if (D.current && r) {
					let e = S.current, t = {
						...e,
						s: Math.max(10, Math.min(150 * it(v), e.s * r / D.current))
					};
					S.current = t, x(t);
				}
				D.current = r, E.current = 99;
			}
			T.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
		},
		onPointerUp: (e) => {
			let t = T.current.size === 1 && E.current < 10;
			if (T.current.delete(e.pointerId), T.current.size < 2 && (D.current = 0), !t) return;
			let r = ae(e.clientX, e.clientY);
			if (!r) return;
			let i = H(Math.round(r.x / Q), Math.round(r.z / Q));
			n?.has(i) && d?.(i);
		},
		onPointerCancel: (e) => {
			T.current.delete(e.pointerId), D.current = 0, E.current = 99;
		},
		children: [
			/* @__PURE__ */ F(ie, {
				kind: "sheen",
				base: "#eee3cb",
				className: "absolute inset-0 size-full"
			}),
			/* @__PURE__ */ I(ee, {
				camera: {
					fov: St,
					near: .1,
					far: 200
				},
				dpr: [1, 2],
				frameloop: "demand",
				gl: {
					antialias: !0,
					alpha: !0,
					powerPreference: "low-power"
				},
				style: {
					position: "absolute",
					inset: 0
				},
				children: [
					/* @__PURE__ */ F("ambientLight", { intensity: .78 }),
					/* @__PURE__ */ F("directionalLight", {
						position: [
							-5,
							9,
							6
						],
						intensity: 1.35
					}),
					/* @__PURE__ */ F(Kt, {
						view: b,
						cameraRef: _
					}),
					n && [...n].map((e) => {
						let [t, n] = U(e), r = i?.x === t && i?.y === n;
						return /* @__PURE__ */ I("group", {
							position: [
								t * Q,
								-.005,
								n * Q
							],
							children: [
								/* @__PURE__ */ I("mesh", {
									position: [
										0,
										-.035,
										0
									],
									children: [/* @__PURE__ */ F("boxGeometry", { args: [
										2.04,
										.055,
										2.04
									] }), /* @__PURE__ */ F("meshBasicMaterial", {
										color: r ? "#aa6b35" : "#608f82",
										transparent: !0,
										opacity: r ? .18 : .2
									})]
								}),
								/* @__PURE__ */ I("mesh", {
									position: [
										0,
										0,
										0
									],
									children: [/* @__PURE__ */ F("boxGeometry", { args: [
										1.94,
										.012,
										1.94
									] }), /* @__PURE__ */ F("meshBasicMaterial", {
										color: r ? "#f5d69c" : "#dcefe5",
										transparent: !0,
										opacity: r ? .3 : .36
									})]
								}),
								r && [
									[
										0,
										-1.055,
										2.06,
										.045
									],
									[
										0,
										1.055,
										2.06,
										.045
									],
									[
										-1.055,
										0,
										.045,
										2.06
									],
									[
										1.055,
										0,
										.045,
										2.06
									]
								].map(([e, t, n, r], i) => /* @__PURE__ */ I("mesh", {
									position: [
										e,
										.045,
										t
									],
									children: [/* @__PURE__ */ F("boxGeometry", { args: [
										n,
										.025,
										r
									] }), /* @__PURE__ */ F("meshBasicMaterial", { color: "#d98535" })]
								}, `rail${i}`)),
								[
									[-.82, -.82],
									[.82, -.82],
									[.82, .82],
									[-.82, .82]
								].map(([e, t], n) => /* @__PURE__ */ I("group", {
									position: [
										r ? Math.sign(e) * 1.1 : e,
										.075,
										r ? Math.sign(t) * 1.1 : t
									],
									rotation: [
										0,
										-n * Math.PI / 2,
										0
									],
									children: [/* @__PURE__ */ I("mesh", {
										position: [
											.15,
											0,
											0
										],
										children: [/* @__PURE__ */ F("boxGeometry", { args: [
											.37,
											.045,
											.065
										] }), /* @__PURE__ */ F("meshBasicMaterial", { color: r ? "#d98535" : "#25877e" })]
									}), /* @__PURE__ */ I("mesh", {
										position: [
											0,
											0,
											.15
										],
										children: [/* @__PURE__ */ F("boxGeometry", { args: [
											.065,
											.045,
											.37
										] }), /* @__PURE__ */ F("meshBasicMaterial", { color: r ? "#d98535" : "#25877e" })]
									})]
								}, n))
							]
						}, `spot${e}`);
					}),
					O.map(([e, t]) => {
						let [n, r] = U(e);
						return /* @__PURE__ */ F(Wt, {
							x: n,
							y: r,
							tile: t.tile,
							rot: t.rot
						}, e);
					}),
					A.map((e) => /* @__PURE__ */ F("mesh", {
						material: Z.city,
						position: [
							e.x,
							.17,
							e.z
						],
						children: /* @__PURE__ */ F("boxGeometry", { args: e.dir === 1 ? [
							.18,
							.01,
							35 / 25
						] : [
							35 / 25,
							.01,
							.18
						] })
					}, `join${e.key}`)),
					c && (() => {
						let [e, t] = U(c);
						return /* @__PURE__ */ F("group", {
							position: [
								e * Q,
								.2,
								t * Q
							],
							children: [
								[
									0,
									-.98,
									1.94,
									.045
								],
								[
									0,
									.98,
									1.94,
									.045
								],
								[
									-.98,
									0,
									.045,
									1.94
								],
								[
									.98,
									0,
									.045,
									1.94
								]
							].map(([e, t, n, r], i) => /* @__PURE__ */ I("mesh", {
								position: [
									e,
									0,
									t
								],
								children: [/* @__PURE__ */ F("boxGeometry", { args: [
									n,
									.02,
									r
								] }), /* @__PURE__ */ F("meshBasicMaterial", { color: "#d0833a" })]
							}, i))
						});
					})(),
					i && /* @__PURE__ */ I("group", { children: [
						/* @__PURE__ */ I("mesh", {
							position: [
								i.x * Q,
								.012,
								i.y * Q
							],
							rotation: [
								-Math.PI / 2,
								0,
								0
							],
							children: [/* @__PURE__ */ F("planeGeometry", { args: [1.72, 1.72] }), /* @__PURE__ */ F("meshBasicMaterial", {
								color: "#513d2b",
								transparent: !0,
								opacity: .15
							})]
						}),
						/* @__PURE__ */ F(Wt, {
							x: i.x,
							y: i.y,
							tile: i.tile,
							rot: i.rot,
							lifted: !0
						}),
						/* @__PURE__ */ F("group", {
							position: [
								i.x * Q,
								.08,
								i.y * Q
							],
							children: [
								[
									0,
									-1.01,
									2.04,
									.04
								],
								[
									0,
									1.01,
									2.04,
									.04
								],
								[
									-1.01,
									0,
									.04,
									2.04
								],
								[
									1.01,
									0,
									.04,
									2.04
								]
							].map(([e, t, n, r], i) => /* @__PURE__ */ I("mesh", {
								position: [
									e,
									0,
									t
								],
								children: [/* @__PURE__ */ F("boxGeometry", { args: [
									n,
									.035,
									r
								] }), /* @__PURE__ */ F("meshBasicMaterial", { color: "#e6a954" })]
							}, i))
						})
					] }),
					Object.entries(t).map(([t, n]) => {
						let r = e[t];
						if (!r) return null;
						let i = q(r.tile)[n.zone];
						if (!i) return null;
						let [a, o] = rt(t, r.rot, we(r.tile, i)), s = i.kind === "city" ? .18 : i.kind === "road" ? .11 : i.kind === "monastery" ? .25 : .08;
						return /* @__PURE__ */ F(yt, {
							x: a / 50,
							z: o / 50,
							groundY: s,
							color: u(n.rid),
							kind: i.kind,
							abbot: n.abbot
						}, `meeple${t}`);
					})
				]
			}),
			te && /* @__PURE__ */ F("div", {
				className: "carc-board-controls",
				style: te,
				onPointerDown: (e) => e.stopPropagation(),
				onPointerUp: (e) => e.stopPropagation(),
				onPointerCancel: (e) => e.stopPropagation(),
				children: f
			}),
			ne && /* @__PURE__ */ F("div", {
				className: "carc-meeple-ui",
				style: ne,
				onPointerDown: (e) => e.stopPropagation(),
				onPointerUp: (e) => e.stopPropagation(),
				onPointerCancel: (e) => e.stopPropagation(),
				children: m
			})
		]
	});
}
//#endregion
//#region src/games/carcassonne/view-player.tsx
function Zt(e) {
	let t = e.public;
	return /* @__PURE__ */ F(tn, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var Qt = [
	"→",
	"↘",
	"↓",
	"↙",
	"←",
	"↖",
	"↑",
	"↗"
], $t = (e, t) => Qt[(Math.round(Math.atan2(t, e) / (Math.PI / 4)) + 8) % 8], en = {
	city: "games.carcassonne.hintRoleKnight",
	road: "games.carcassonne.hintRoleRobber",
	monastery: "games.carcassonne.hintRoleMonk",
	field: "games.carcassonne.hintRoleFarmer"
};
function tn({ pub: e, members: t, myRid: n, send: r }) {
	let d = u(), f = l((e) => e.locale), p = e.players.find((e) => e.rid === n), [m, S] = s(null), [C, ee] = s(0), [w, T] = s(!1), [E, D] = s(""), [O] = s(At), k = o(null), [A, te] = s(1), ne = O ? Xt : ot;
	i(() => {
		let e = k.current, t = window.matchMedia("(orientation: landscape)"), n = () => {
			let { width: n, height: r } = e.getBoundingClientRect();
			te(t.matches && n >= 900 && r >= 520 ? Math.max(1, Math.min(n / 850, r / 650, 1.65)) : 1);
		}, r = new ResizeObserver(n);
		return r.observe(e), t.addEventListener("change", n), n(), () => {
			r.disconnect(), t.removeEventListener("change", n);
		};
	}, []);
	let j = e.players[e.turn.playerIdx]?.rid, M = e.phase === "play" && j === n, N = e.turn.stage, [re, P] = s(""), ie = `${e.turn.playerIdx}:${N}:${e.tilesLeft}`;
	re !== ie && (P(ie), S(null));
	let oe = (e) => _[(t.find((t) => t.rid === e)?.colorIndex ?? 0) % _.length].hex, se = (e) => t.find((t) => t.rid === e)?.name ?? e, ce = t.filter((t) => e.players.some((e) => e.rid === t.rid)), ue = a(() => M && N === "place" ? De(e.board, e.turn.tile) : [], [
		M,
		N,
		e.board,
		e.turn.tile
	]), de = a(() => ue.length > 0 ? new Set(ue.map((e) => H(e.x, e.y))) : void 0, [ue]), fe = a(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of ue) {
			let n = H(t.x, t.y);
			e.set(n, [...e.get(n) ?? [], t.rot]);
		}
		return e;
	}, [ue]), L = m ? fe.get(H(m.x, m.y)) ?? [] : [], R = e.turn.placedKey, pe = M && N === "meeple" ? R ?? "" : "";
	E !== pe && (D(pe), T(!1));
	let z = a(() => {
		if (!M || N !== "meeple" || !R) return [];
		let t = e.board[R];
		if (!t || !p) return [];
		let n = [];
		return q(t.tile).forEach((r, i) => {
			if (Ne(e.board, e.meeples, R, r)) return;
			let [a, o] = rt(R, t.rot, we(t.tile, r)), s = p.meeples > 0, c = r.kind === "monastery" && p.abbot;
			s && n.push({
				zone: i,
				kind: r.kind,
				abbot: !1,
				x: a,
				y: o
			}), c && n.push({
				zone: i,
				kind: r.kind,
				abbot: !0,
				x: a,
				y: o
			});
		}), n;
	}, [
		M,
		N,
		R,
		e.board,
		e.meeples,
		p
	]), B = z.reduce((e, t) => {
		let n = t.abbot ? "abbot" : t.kind;
		return e[n] = (e[n] ?? 0) + 1, e;
	}, {}), V = Math.min(4, Math.max(1, z.length)), me = Math.ceil(z.length / V), [he, ge] = R ? U(R) : [0, 0], _e = (e) => e.abbot ? d("games.carcassonne.roleAbbot") : d(en[e.kind]), W = Object.values(e.meeples).some((e) => e.rid === n && e.abbot), G = (e) => {
		if (!de?.has(e)) return;
		let [t, n] = U(e);
		S((r) => r?.x === t && r.y === n ? r : {
			x: t,
			y: n,
			rot: fe.get(e)[0]
		});
	}, K = () => {
		!m || L.length < 2 || S({
			...m,
			rot: L[(L.indexOf(m.rot) + 1) % L.length]
		});
	}, ve = "info", ye;
	return M ? (ve = "accent", ye = d(N === "meeple" ? "games.carcassonne.stageMeeple" : m ? L.length > 1 ? "games.carcassonne.stagePlaceSelected" : "games.carcassonne.stagePlaceReady" : "games.carcassonne.stagePlace")) : ye = d("games.carcassonne.waitTurn", { name: se(j ?? "") }), /* @__PURE__ */ F("div", {
		ref: k,
		className: "carc-screen",
		style: { "--carc-ui-scale": A },
		children: /* @__PURE__ */ F(y, {
			adaptive: !0,
			className: "carc-game",
			scroll: !1,
			banner: /* @__PURE__ */ I("div", {
				className: `carc-header flex flex-col gap-2${M ? " carc-header--turn" : ""}`,
				children: [/* @__PURE__ */ F(v, {
					tone: ve,
					text: ye,
					chip: d("games.carcassonne.tilesChip", { n: e.tilesLeft }),
					accent: le.accent
				}), /* @__PURE__ */ F("ul", {
					className: "carc-players",
					style: { gridTemplateColumns: `repeat(${ce.length}, minmax(0, 1fr))` },
					children: ce.map((t) => {
						let r = e.players.find((e) => e.rid === t.rid);
						return /* @__PURE__ */ I("li", {
							className: `carc-player${t.rid === j && e.phase === "play" ? " carc-player--turn" : ""}`,
							style: { "--seat-color": oe(t.rid) },
							children: [
								/* @__PURE__ */ I("div", {
									className: "carc-player__head",
									children: [/* @__PURE__ */ F(b, {
										m: t,
										myRid: n,
										action: t.rid === j && e.phase === "play" ? "pending" : null,
										anchorName: `seat:${t.rid}`,
										box: "carc-player__avatar",
										img: "carc-player__avatar-img"
									}), /* @__PURE__ */ F("span", {
										"aria-label": d("games.carcassonne.scoreAria", { n: r.score }),
										className: "carc-player__score",
										children: /* @__PURE__ */ F(c, { value: r.score })
									})]
								}),
								/* @__PURE__ */ F("span", {
									className: "carc-player__name",
									title: x(t, f),
									children: x(t, f)
								}),
								/* @__PURE__ */ I("span", {
									"aria-label": d("games.carcassonne.meepleAria", { n: r.meeples }),
									className: "carc-player__stock",
									children: [
										/* @__PURE__ */ F("svg", {
											className: "carc-player__piece",
											viewBox: "-15 -15 30 30",
											"aria-hidden": !0,
											children: /* @__PURE__ */ F(nt, { color: oe(t.rid) })
										}),
										/* @__PURE__ */ F("span", {
											className: "font-mono tabular-nums",
											children: r.meeples
										}),
										r.abbot && /* @__PURE__ */ F("svg", {
											className: "carc-player__piece carc-player__piece--abbot",
											viewBox: "-15 -15 30 30",
											"aria-hidden": !0,
											children: /* @__PURE__ */ F(nt, {
												color: oe(t.rid),
												abbot: !0
											})
										})
									]
								})
							]
						}, t.rid);
					})
				})]
			}),
			children: /* @__PURE__ */ I("div", {
				className: "frame relative h-full min-h-0 overflow-hidden",
				children: [
					/* @__PURE__ */ F(ne, {
						board: e.board,
						meeples: e.meeples,
						spots: M && N === "place" ? de : void 0,
						ghost: m ? {
							...m,
							tile: e.turn.tile
						} : null,
						lastPlacedKey: N === "meeple" ? R : void 0,
						fitKey: String(C),
						colorOf: oe,
						onTapCell: M && N === "place" ? G : void 0,
						controlsSize: {
							width: 220 * A,
							height: 62 * A
						},
						controls: m && M && N === "place" ? /* @__PURE__ */ I(ae, { children: [/* @__PURE__ */ I("button", {
							type: "button",
							"aria-label": d("games.carcassonne.rotateAria"),
							disabled: L.length < 2,
							onClick: K,
							className: "carc-board-rotate",
							children: [/* @__PURE__ */ F(g, {
								size: 21,
								"aria-hidden": !0
							}), /* @__PURE__ */ F("span", {
								"aria-hidden": !0,
								children: d("games.carcassonne.rotate")
							})]
						}), /* @__PURE__ */ F("button", {
							type: "button",
							onClick: () => {
								r({
									type: "place",
									x: m.x,
									y: m.y,
									rot: m.rot
								}), S(null);
							},
							className: "carc-board-confirm",
							children: d("games.carcassonne.placeConfirm")
						})] }) : void 0,
						meepleUi: M && N === "meeple" ? /* @__PURE__ */ I("div", {
							className: "carc-meeple-stack",
							children: [z.length > 0 && /* @__PURE__ */ I("div", {
								className: `carc-meeple-picker${O ? "" : " carc-meeple-picker--2d"}`,
								style: {
									gridTemplateColumns: `repeat(${V}, 68px)`,
									width: V * 68,
									height: me * 78
								},
								children: [z.map((e) => {
									let t = e.abbot ? "abbot" : e.kind, i = B[t] > 1 ? $t(e.x - he * 100, e.y - ge * 100) : "", a = _e(e);
									return /* @__PURE__ */ I("button", {
										type: "button",
										className: "carc-meeple-picker__choice",
										"aria-label": `${a}${i ? ` ${i}` : ""}`,
										onClick: () => r({
											type: "meeple",
											zone: e.zone,
											abbot: e.abbot
										}),
										children: [
											(!O || !w) && /* @__PURE__ */ F("svg", {
												className: "carc-meeple-picker__glyph",
												viewBox: "-16 -21 32 38",
												"aria-hidden": !0,
												children: /* @__PURE__ */ F(nt, {
													color: oe(n),
													kind: e.kind,
													abbot: e.abbot
												})
											}),
											i && /* @__PURE__ */ F("span", {
												className: "carc-meeple-picker__direction",
												"aria-hidden": !0,
												children: i
											}),
											/* @__PURE__ */ F("span", {
												className: "carc-meeple-picker__label",
												"aria-hidden": !0,
												children: a
											})
										]
									}, `${e.zone}:${e.abbot}`);
								}), O && /* @__PURE__ */ F(xt, {
									choices: z,
									color: oe(n),
									columns: V,
									onReady: () => T(!0)
								})]
							}), /* @__PURE__ */ I("div", {
								className: "carc-meeple-actions",
								children: [W && /* @__PURE__ */ I("button", {
									type: "button",
									onClick: () => r({ type: "recallAbbot" }),
									className: "carc-choice-action carc-choice-recall",
									children: [/* @__PURE__ */ F("svg", {
										viewBox: "-15 -15 30 30",
										"aria-hidden": !0,
										children: /* @__PURE__ */ F(nt, {
											color: "#d99838",
											kind: "monastery",
											abbot: !0
										})
									}), /* @__PURE__ */ F("span", { children: d("games.carcassonne.recallAbbot") })]
								}), /* @__PURE__ */ I("button", {
									type: "button",
									onClick: () => r({ type: "skip" }),
									className: "carc-choice-action carc-choice-skip",
									children: [/* @__PURE__ */ F("svg", {
										viewBox: "-15 -15 30 30",
										"aria-hidden": !0,
										children: /* @__PURE__ */ F(nt, { color: "#7e8c92" })
									}), /* @__PURE__ */ F("span", { children: d("games.carcassonne.skipMeeple") })]
								})]
							})]
						}) : void 0,
						meepleUiSize: {
							width: Math.max(V * 68, W ? 196 : 80) * A,
							height: (z.length > 0 ? me * 78 + 70 : 62) * A
						}
					}),
					M && N === "place" && /* @__PURE__ */ I("div", {
						role: "img",
						"aria-label": m ? d("games.carcassonne.rotationAria", { n: m.rot * 90 }) : d("games.carcassonne.tilePreviewAria"),
						className: "carc-current-tile",
						children: [/* @__PURE__ */ F("svg", {
							viewBox: "-55 -55 110 110",
							"aria-hidden": !0,
							children: /* @__PURE__ */ F("g", {
								transform: `rotate(${(m?.rot ?? 0) * 90})`,
								children: /* @__PURE__ */ F(tt, { tile: e.turn.tile })
							})
						}), m && /* @__PURE__ */ I("span", {
							"aria-hidden": !0,
							className: "carc-current-tile__angle",
							children: [m.rot * 90, "°"]
						})]
					}),
					/* @__PURE__ */ F("button", {
						type: "button",
						"aria-label": d("games.carcassonne.recenter"),
						onClick: () => ee((e) => e + 1),
						className: "carc-recenter",
						children: /* @__PURE__ */ F(h, {
							size: 20,
							"aria-hidden": !0
						})
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/carcassonne/bot.ts
function nn(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function rn(e, t, n, r, i) {
	let a = e[n], o = q(a.tile)[r];
	if (o.kind === "monastery") return Me(e, n) * 1.1;
	if (o.kind === "city") {
		let r = J(e, n, o.ref);
		if (Y(e, t, r, "city").length > 0) return -1;
		let i = 2 * r.tiles.size + 2 * r.pennants;
		return r.open ? 1.5 * r.tiles.size + r.pennants : i + 2;
	}
	if (o.kind === "road") {
		let r = Ae(e, n, o.ref);
		return Y(e, t, r, "road").length > 0 ? -1 : r.open ? .9 * r.tiles.size : r.tiles.size + 1;
	}
	let s = je(e, n, o.ref);
	if (Y(e, t, s, "field").length > 0) return -1;
	let c = 0, l = 0;
	for (let t of s.cities) {
		let [n, r] = t.split(":");
		J(e, n, Number(r)).open ? l += 1 : c += 1;
	}
	let u = 3 * c + 1.2 * l;
	return i <= 2 && (u *= .5), u;
}
function an(e, t, n, r, i, a, o, s) {
	let c = H(r, i), l = {
		...e,
		[c]: {
			tile: n,
			rot: a
		}
	}, u = 0, d = V[n];
	return d.cities.forEach((e, n) => {
		let r = J(l, c, n), i = Y(l, t, r, "city");
		if (i.length === 0) u += r.open ? 1.5 * r.tiles.size + r.pennants : 2 * r.tiles.size + 2 * r.pennants + 2;
		else if (r.open) i.some((e) => e.rid === o) && (u += .8 * r.tiles.size);
		else {
			let e = i.filter((e) => e.rid === o).length, t = i.length - e, n = 2 * r.tiles.size + 2 * r.pennants;
			u += e >= t ? n * .6 : -n * .5;
		}
	}), d.roads.forEach((e, n) => {
		let r = Ae(l, c, n);
		Y(l, t, r, "road").length === 0 ? u += r.open ? .9 * r.tiles.size : r.tiles.size + 1 : r.open || (u -= r.tiles.size * .5);
	}), d.monastery && (u += Me(l, c) * 1.2), s > 0 && d.fields.forEach((e, n) => {
		let r = je(l, c, n);
		if (Y(l, t, r, "field").length > 0) return;
		let i = 0;
		for (let e of r.cities) {
			let [t, n] = e.split(":");
			J(l, t, Number(n)).open || (i += 1);
		}
		u += i * 2;
	}), u;
}
var on = (e, t) => {
	let n = e.public;
	if (n.phase !== "play") return null;
	let r = n.players[n.turn.playerIdx];
	if (!r || r.rid !== t.rid) return null;
	if (n.turn.stage === "place") {
		let e = De(n.board, n.turn.tile);
		if (e.length === 0) return null;
		if (t.difficulty === "weak") {
			let t = nn(e);
			return { action: {
				type: "place",
				x: t.x,
				y: t.y,
				rot: t.rot
			} };
		}
		let i = e[0], a = -Infinity;
		for (let o of e) {
			let e = an(n.board, n.meeples, n.turn.tile, o.x, o.y, o.rot, t.rid, r.meeples);
			e > a && (a = e, i = o);
		}
		return { action: {
			type: "place",
			x: i.x,
			y: i.y,
			rot: i.rot
		} };
	}
	let i = n.turn.placedKey;
	if (!i) return null;
	let a = n.board[i];
	if (!a) return null;
	let o = q(a.tile);
	if (t.difficulty === "weak") {
		let e = [];
		return o.forEach((t, a) => {
			r.meeples > 0 && rn(n.board, n.meeples, i, a, r.meeples) >= 0 && e.push(a);
		}), e.length === 0 || nn([!0, !1]) ? { action: { type: "skip" } } : { action: {
			type: "meeple",
			zone: nn(e)
		} };
	}
	let s = -1, c = 1.5;
	o.forEach((e, t) => {
		if (r.meeples <= 0) return;
		let a = rn(n.board, n.meeples, i, t, r.meeples);
		a > c && (c = a, s = t);
	});
	let l = Object.entries(n.meeples).find(([, e]) => e.rid === t.rid && e.abbot);
	if (l) {
		let e = Me(n.board, l[0]);
		if (e >= 7 && e >= c) return { action: { type: "recallAbbot" } };
	}
	if (s >= 0) {
		let e = o[s].kind === "monastery" && r.abbot && (r.meeples === 0 || c >= 6);
		return { action: {
			type: "meeple",
			zone: s,
			abbot: e
		} };
	}
	if (r.meeples === 0 && r.abbot) {
		let e = o.findIndex((e) => e.kind === "monastery");
		if (e >= 0) return { action: {
			type: "meeple",
			zone: e,
			abbot: !0
		} };
	}
	return { action: { type: "skip" } };
}, sn = {
	city: "games.carcassonne.hintRoleKnight",
	road: "games.carcassonne.hintRoleRobber",
	monastery: "games.carcassonne.hintRoleMonk",
	field: "games.carcassonne.hintRoleFarmer"
}, cn = (e, t, n) => {
	switch (e.type) {
		case "place": return n("games.carcassonne.hintPlace");
		case "meeple": {
			if (e.abbot) return n("games.carcassonne.hintAbbot");
			let r = t.public.turn.placedKey, i = r ? t.public.board[r] : void 0, a = i ? q(i.tile)[e.zone] : void 0;
			return a ? n("games.carcassonne.hintMeeple", { role: n(sn[a.kind]) }) : n("games.carcassonne.hintMeepleGeneric");
		}
		case "skip": return n("games.carcassonne.skipMeeple");
		case "recallAbbot": return n("games.carcassonne.recallAbbot");
	}
}, ln = {
	city: "🏰",
	road: "🛣️",
	monastery: "⛪",
	farm: "🌾"
}, un = {
	place(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ F(se, {
				at: n,
				ms: 600
			})
		} : null;
	},
	meeple(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ F(se, {
				at: n,
				ms: 600
			})
		} : null;
	},
	score(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!r || typeof n?.points != "number") return null;
		let i = typeof n.via == "string" ? ln[n.via] ?? "" : "";
		return {
			ms: 1300,
			node: /* @__PURE__ */ I(oe, {
				at: r,
				ms: 1300,
				children: [
					i,
					"+",
					n.points
				]
			})
		};
	},
	recall() {
		return null;
	},
	discard() {
		return null;
	},
	gameEnd() {
		return null;
	}
};
//#endregion
//#region src/games/carcassonne/endgame-review.tsx
function dn({ board: e, renderResult: t, ...n }) {
	let i = u(), [c, l] = s(!0), [f, h] = s(null), g = o(null), _ = o(null), v = o(null);
	r(() => {
		if (!f) return;
		v.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => h(null), 5e3);
		return () => clearTimeout(e);
	}, [f]);
	let y = (e) => {
		h(null), l(e), requestAnimationFrame(() => (e ? g : _).current?.focus({ preventScroll: !0 }));
	}, b = a(() => ({
		onPlayAgain: n.onPlayAgain && (() => h({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => h({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => h({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), x = {
		...n,
		...b
	};
	return /* @__PURE__ */ I("div", {
		className: "carcassonne-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ F("div", {
				className: "carcassonne-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ F("div", {
				className: "carcassonne-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ I("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), y(!1));
					},
					className: "carcassonne-endgame-panel",
					"aria-label": i("session.result.title"),
					children: [
						/* @__PURE__ */ I("header", {
							className: "carcassonne-endgame-heading",
							children: [/* @__PURE__ */ I("div", {
								className: "carcassonne-endgame-brand",
								children: [/* @__PURE__ */ F("span", {
									"aria-hidden": "true",
									children: le.icon
								}), i(le.nameKey)]
							}), /* @__PURE__ */ F("button", {
								type: "button",
								ref: g,
								className: "btn-quiet",
								"aria-label": i("games.carcassonne.reviewHide"),
								title: i("games.carcassonne.reviewHide"),
								onClick: () => y(!1),
								children: /* @__PURE__ */ F(p, { size: 19 })
							})]
						}),
						/* @__PURE__ */ F("div", {
							className: "carcassonne-endgame-result",
							inert: f !== null,
							children: t(x)
						}),
						f && /* @__PURE__ */ I("div", {
							className: "carcassonne-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || h(null);
							},
							children: [/* @__PURE__ */ F("button", {
								type: "button",
								ref: v,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = f.run;
									h(null), e();
								},
								children: i(f.label === "again" ? "games.carcassonne.reviewConfirmAgain" : "games.carcassonne.reviewConfirmLobby")
							}), /* @__PURE__ */ F("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									h(null), g.current?.focus({ preventScroll: !0 });
								},
								children: i("games.carcassonne.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ F("div", {
				className: "carcassonne-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ I("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => y(!0),
					children: [
						/* @__PURE__ */ F(m, { size: 18 }),
						i("games.carcassonne.reviewShow"),
						/* @__PURE__ */ F(d, { size: 18 })
					]
				})
			})
		]
	});
}
function fn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: c, renderRowExtra: d, summary: m, navigation: h, content: g, afterRanking: _, scoreUnit: v, rankOf: y }) {
	let b = u(), S = l((e) => e.locale), [C, ee] = s({}), w = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? x(n, S) : e;
	}, T = (t, n) => y?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), E = e.ranking.some((t) => e.scores?.[t] !== void 0), D = (t, n) => /* @__PURE__ */ I("div", {
		className: "carcassonne-score-identity",
		children: [
			/* @__PURE__ */ I("span", {
				className: "carcassonne-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ F("span", {
					"aria-label": b("games.carcassonne.reviewWinner"),
					children: "♛ "
				}), E && T(t, n)]
			}),
			/* @__PURE__ */ I("span", {
				className: "carcassonne-score-name",
				children: [w(t), t === r && /* @__PURE__ */ F("small", { children: b("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ I("small", {
				className: "carcassonne-score-autopilot",
				children: [
					/* @__PURE__ */ F(f, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), O = (t) => e.ranking.map((n) => /* @__PURE__ */ F("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ I("div", {
		className: "carcassonne-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ F(ce, {}),
			h,
			/* @__PURE__ */ I("div", {
				className: "carcassonne-score-body",
				children: [
					m && /* @__PURE__ */ F("div", {
						className: "carcassonne-score-summary",
						children: m
					}),
					i !== void 0 && /* @__PURE__ */ F("p", {
						className: "carcassonne-score-hints",
						children: b("session.hint.usedCount", { n: i })
					}),
					g ?? (c?.length ? /* @__PURE__ */ F("div", {
						className: "carcassonne-score-table-scroll",
						children: /* @__PURE__ */ I("table", {
							className: "carcassonne-score-table",
							"aria-label": b(le.nameKey),
							children: [
								/* @__PURE__ */ F("thead", { children: /* @__PURE__ */ I("tr", { children: [/* @__PURE__ */ F("th", { scope: "col" }), /* @__PURE__ */ F(ae, { children: e.ranking.map((t, n) => /* @__PURE__ */ F("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: D(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ F("tbody", { children: c.map((e, t) => /* @__PURE__ */ I(n, { children: [/* @__PURE__ */ I("tr", { children: [/* @__PURE__ */ F("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ I("button", {
										type: "button",
										"aria-expanded": !!C[t],
										onClick: () => ee((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ F(p, { size: 15 }), e.label]
									}) : e.label
								}), O(e)] }), C[t] && e.details?.map((e, t) => /* @__PURE__ */ I("tr", {
									className: "carcassonne-score-sub",
									children: [/* @__PURE__ */ F("th", {
										scope: "row",
										children: e.label
									}), O(e)]
								}, t))] }, t)) }),
								E && /* @__PURE__ */ F("tfoot", { children: /* @__PURE__ */ I("tr", { children: [/* @__PURE__ */ F("th", {
									scope: "row",
									children: b("games.carcassonne.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ F("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ F("ol", {
						className: "carcassonne-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ I("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ I("div", {
								className: "carcassonne-score-rankline",
								children: [D(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ I("strong", {
									className: "carcassonne-score-points",
									children: [e.scores[t], v && /* @__PURE__ */ F("small", { children: v })]
								})]
							}), d?.(t)]
						}, t))
					})),
					_,
					!!c?.length && d && /* @__PURE__ */ F("div", {
						className: "carcassonne-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ I("details", { children: [/* @__PURE__ */ F("summary", { children: w(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ I("footer", {
				className: "carcassonne-score-actions",
				children: [
					o && /* @__PURE__ */ F("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: b("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ F("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: b("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ F("p", { children: b("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/carcassonne/game-over.tsx
function pn({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ F(fn, {
		hintCount: e,
		result: t,
		members: n,
		myRid: r,
		accent: le.accent,
		onPlayAgain: i,
		onBackToLobby: a
	});
}
function mn(e) {
	return /* @__PURE__ */ F(dn, {
		...e,
		board: /* @__PURE__ */ F(Zt, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ F(pn, { ...e })
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/carcassonne/entry.tsx
var hn = {
	definition: He,
	View: Zt,
	bot: on,
	describe: cn,
	fx: un,
	OverView: mn,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "卡卡颂",
			desc: "拼放板块、派遣米宝,建设中世纪领地",
			rules: "目标:拼放板块建设中世纪领地,派遣米宝占领道路、城堡、修道院与田地,终局得分最高者获胜。\n准备:起始板块置于中央,其余 71 块洗混成牌堆;每人 7 个米宝与 1 个方丈。\n流程(每回合):\n· 自动抽出 1 块板块并亮出;把它拼到版图上——至少与 1 块已有板块相邻,且所有相邻边类型一致(城接城、路接路、田接田)。\n· 抽到的板块无处可放时自动弃置并补抽。\n· 放置板块后，可以在该板块上派遣1个米宝。放在城市中的米宝成为骑士，放在道路上成为强盗，放在修道院中成为修士，放在田地中成为农夫；农夫在终局前不会被收回。\n· 方丈只能进修道院;也可改为召回自己在修道院的方丈,立即按当前大小计分。\n· 一片连通的区域里已有米宝时,不能再往该区域派米宝。\n结算:\n· 道路两端封闭后，该道路每块板块获得1分，并收回米宝。\n· 城市的城墙合拢后，该城市每块板块获得2分，每枚徽章额外获得2分，并收回米宝。\n· 修道院周围8格全部放满板块后，获得9分，并收回米宝。\n· 同一区域中，拥有最多米宝的玩家获得该区域的分数；米宝数量并列最多时，并列玩家各获得全部分数。\n终局计分：\n牌堆耗尽且最后一块板块放置完毕后，游戏结束。未完成的区域按以下方式计分：\n· 未完成的道路，每块板块获得1分。\n· 未完成的城市，每块板块获得1分，每枚徽章额外获得1分。\n· 未完成的修道院，自身及周围每块已放置的板块各获得1分；仍在版图上的方丈不得分。\n· 每个农夫按田地相连的每座已完成城获得 3 分。\n· 总分最高的玩家获胜,并列共享胜利。",
			tilesChip: "剩 {{n}} 块",
			stagePlace: "点亮的空格选位置",
			stagePlaceSelected: "板块待确认:换朝向或放置",
			stagePlaceReady: "板块待确认:可以放置",
			stageMeeple: "选一个米宝派往刚放的板块,或跳过",
			waitTurn: "等 {{name}} 操作…",
			watchHint: "轮到你时,这里会出现操作按钮",
			rotate: "换朝向",
			rotateAria: "切换到下一个可拼接朝向",
			rotationAria: "当前朝向 {{n}} 度",
			tilePreviewAria: "待放板块",
			recenter: "回到版图",
			chooseSpot: "先选落点",
			placeConfirm: "确认放置",
			skipMeeple: "不派米宝",
			recallAbbot: "召回方丈计分",
			useNormal: "用普通米宝",
			useAbbot: "用方丈",
			scoreAria: "{{n}} 分",
			meepleAria: "剩余 {{n}} 个米宝",
			errNotYourTurn: "还没轮到你",
			errBadPlacement: "这里放不了:边类型要和相邻板块一致",
			errBadZone: "这个位置不能放米宝",
			errNoMeeple: "米宝用完了",
			errOccupied: "这片区域已经有米宝了",
			errNoAbbot: "方丈不在手上",
			hintPlace: "把板块拼到最佳位置",
			hintMeeple: "派米宝当{{role}}",
			hintMeepleGeneric: "在这个板块上派米宝",
			hintAbbot: "派方丈进修道院",
			hintRoleKnight: "骑士",
			hintRoleRobber: "强盗",
			hintRoleMonk: "修士",
			hintRoleFarmer: "农夫",
			roleAbbot: "方丈"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Carcassonne",
			desc: "Lay tiles, send out meeples, build a medieval realm",
			rules: "Goal: lay tiles to build a medieval realm and send meeples to claim roads, cities, monasteries, and fields — the highest score after final scoring wins.\nSetup: the start tile sits in the middle; the other 71 tiles are shuffled into a face-down stack; everyone gets 7 meeples plus 1 abbot.\nEach turn:\n· The top tile is revealed automatically; place it so it touches at least one existing tile, with every touching edge matching in type (city to city, road to road, field to field).\n· If the drawn tile fits nowhere, it is discarded and a new one is drawn.\n· Then you may place one meeple on the tile you just placed: knight in a city, robber on a road, monk in a monastery, or farmer in a field (farmers stay until the end).\n· The abbot can only enter a monastery; instead of placing, you may recall your abbot from a monastery to score its current value immediately.\n· You cannot place a meeple on a connected feature that already has one.\nScoring:\n· Completed road (both ends closed): 1 point per tile; the meeple returns.\n· Completed city (walls closed): 2 points per tile plus 2 per pennant; the meeples return.\n· Monastery surrounded by 8 tiles: 9 points; the meeple returns.\n· Whoever has the most meeples on a feature scores it; tied leaders all score.\nFinal scoring:\nAfter the last tile is placed, score incomplete features as follows:\n· Incomplete roads score 1 point per tile.\n· Incomplete cities score 1 point per tile plus 1 point per pennant.\n· Incomplete monasteries score 1 point for themselves plus each surrounding tile; an abbot still on the board scores nothing.\n· Each farmer scores 3 points per completed city bordering the field.\n· Highest score wins; ties share the victory.",
			tilesChip: "{{n}} left",
			stagePlace: "Tap a highlighted space",
			stagePlaceSelected: "Tile ready: turn or place",
			stagePlaceReady: "Tile ready: confirm placement",
			stageMeeple: "Choose a meeple for the tile you just placed, or skip",
			waitTurn: "Waiting for {{name}}…",
			watchHint: "Action buttons appear here on your turn",
			rotate: "Turn",
			rotateAria: "Change to the next valid orientation",
			rotationAria: "Current orientation {{n}} degrees",
			tilePreviewAria: "Tile to place",
			recenter: "Back to the board",
			chooseSpot: "Choose a space",
			placeConfirm: "Confirm placement",
			skipMeeple: "No meeple",
			recallAbbot: "Recall abbot to score",
			useNormal: "Use normal meeple",
			useAbbot: "Use abbot",
			scoreAria: "{{n}} points",
			meepleAria: "{{n}} meeples left",
			errNotYourTurn: "Not your turn yet",
			errBadPlacement: "Doesn’t fit: edges must match neighboring tiles",
			errBadZone: "A meeple can’t go there",
			errNoMeeple: "No meeples left",
			errOccupied: "This feature already has a meeple",
			errNoAbbot: "Your abbot is not in hand",
			hintPlace: "Place the tile at the best spot",
			hintMeeple: "Place a meeple as a {{role}}",
			hintMeepleGeneric: "Place a meeple on this tile",
			hintAbbot: "Send the abbot to the monastery",
			hintRoleKnight: "knight",
			hintRoleRobber: "robber",
			hintRoleMonk: "monk",
			hintRoleFarmer: "farmer",
			roleAbbot: "abbot"
		}
	}
};
//#endregion
export { hn as default };
