import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h } from "@bgparty/sdk/fx/primitives";
import { IconBack as ee, IconBot as g, IconExpand as _, IconLog as v } from "@bgparty/sdk/icons";
import { seatName as y } from "@bgparty/sdk/ui/player-strip";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
//#region src/games/finalgirl/data.ts
var x = {
	"woods-nw": {
		id: "woods-nw",
		kind: "normal",
		pos: {
			x: 10,
			y: 10
		}
	},
	"woods-n": {
		id: "woods-n",
		kind: "normal",
		pos: {
			x: 34,
			y: 8
		}
	},
	"exit-n": {
		id: "exit-n",
		kind: "exit",
		pos: {
			x: 54,
			y: 6
		}
	},
	"woods-ne": {
		id: "woods-ne",
		kind: "normal",
		pos: {
			x: 72,
			y: 10
		}
	},
	shed: {
		id: "shed",
		kind: "search",
		pos: {
			x: 90,
			y: 20
		}
	},
	cabins: {
		id: "cabins",
		kind: "search",
		pos: {
			x: 16,
			y: 24
		}
	},
	makeout: {
		id: "makeout",
		kind: "normal",
		pos: {
			x: 38,
			y: 26
		}
	},
	cliff: {
		id: "cliff",
		kind: "normal",
		pos: {
			x: 62,
			y: 30
		}
	},
	lake: {
		id: "lake",
		kind: "lake",
		pos: {
			x: 64,
			y: 44
		}
	},
	rec: {
		id: "rec",
		kind: "normal",
		pos: {
			x: 10,
			y: 42
		}
	},
	cove: {
		id: "cove",
		kind: "normal",
		pos: {
			x: 30,
			y: 46
		}
	},
	firepit: {
		id: "firepit",
		kind: "normal",
		pos: {
			x: 22,
			y: 62
		}
	},
	dock: {
		id: "dock",
		kind: "search",
		pos: {
			x: 56,
			y: 58
		}
	},
	junction: {
		id: "junction",
		kind: "normal",
		pos: {
			x: 74,
			y: 58
		}
	},
	swamp: {
		id: "swamp",
		kind: "normal",
		pos: {
			x: 82,
			y: 44
		}
	},
	meadow: {
		id: "meadow",
		kind: "normal",
		pos: {
			x: 90,
			y: 32
		}
	},
	"exit-sw": {
		id: "exit-sw",
		kind: "exit",
		pos: {
			x: 4,
			y: 60
		}
	},
	"exit-se": {
		id: "exit-se",
		kind: "exit",
		pos: {
			x: 92,
			y: 68
		}
	}
}, S = [
	"cabins",
	"dock",
	"shed"
], C = {
	"woods-nw": [
		"woods-n",
		"cabins",
		"rec"
	],
	"woods-n": [
		"woods-nw",
		"exit-n",
		"cabins"
	],
	"exit-n": ["woods-n", "woods-ne"],
	"woods-ne": [
		"exit-n",
		"makeout",
		"shed"
	],
	shed: ["woods-ne", "meadow"],
	cabins: ["woods-nw", "woods-n"],
	makeout: ["woods-ne", "cliff"],
	cliff: ["makeout", "swamp"],
	lake: [],
	rec: [
		"woods-nw",
		"cove",
		"exit-sw"
	],
	cove: [
		"rec",
		"firepit",
		"dock"
	],
	firepit: ["cove", "junction"],
	junction: [
		"firepit",
		"swamp",
		"exit-se"
	],
	swamp: [
		"meadow",
		"cliff",
		"dock",
		"junction"
	],
	meadow: ["shed", "swamp"],
	dock: ["cove", "swamp"],
	"exit-sw": ["rec"],
	"exit-se": ["junction"]
}, w = {
	"woods-nw": [
		"cabins",
		"cabins",
		"cabins",
		"cabins",
		"rec",
		"woods-n"
	],
	"woods-n": [
		"cabins",
		"cabins",
		"cabins",
		"woods-nw",
		"woods-nw",
		"exit-n"
	],
	"exit-n": [
		"woods-n",
		"woods-n",
		"woods-ne",
		"woods-ne",
		"woods-ne",
		"woods-ne"
	],
	"woods-ne": [
		"makeout",
		"makeout",
		"makeout",
		"makeout",
		"exit-n",
		"shed"
	],
	shed: [
		"woods-ne",
		"woods-ne",
		"woods-ne",
		"woods-ne",
		"meadow",
		"meadow"
	],
	cabins: [
		null,
		null,
		"woods-nw",
		"woods-nw",
		"woods-n",
		"woods-n"
	],
	makeout: [
		null,
		null,
		"cliff",
		"cliff",
		"cliff",
		"woods-ne"
	],
	cliff: [
		"swamp",
		"swamp",
		"swamp",
		"swamp",
		"makeout",
		null
	],
	lake: [
		null,
		null,
		null,
		null,
		null,
		null
	],
	rec: [
		"cove",
		"cove",
		"cove",
		"woods-nw",
		"woods-nw",
		"exit-sw"
	],
	cove: [
		"dock",
		null,
		null,
		null,
		"firepit",
		"rec"
	],
	firepit: [
		null,
		"junction",
		"junction",
		"junction",
		"junction",
		"cove"
	],
	dock: [
		"cove",
		"cove",
		"cove",
		null,
		null,
		"swamp"
	],
	junction: [
		"exit-se",
		null,
		null,
		"firepit",
		null,
		"swamp"
	],
	swamp: [
		"dock",
		"dock",
		"junction",
		"junction",
		"meadow",
		"cliff"
	],
	meadow: [
		null,
		null,
		null,
		null,
		"shed",
		"swamp"
	],
	"exit-sw": [
		"rec",
		"rec",
		"rec",
		"rec",
		"rec",
		"rec"
	],
	"exit-se": [
		"junction",
		"junction",
		"junction",
		"junction",
		"junction",
		"junction"
	]
}, T = [
	{
		dmg: 2,
		move: 1,
		onReach: null
	},
	{
		dmg: 2,
		move: 1,
		onReach: null
	},
	{
		dmg: 2,
		move: 1,
		onReach: "horror"
	},
	{
		dmg: 2,
		move: 1,
		onReach: null
	},
	{
		dmg: 3,
		move: 1,
		onReach: "horror"
	},
	{
		dmg: 3,
		move: 2,
		onReach: "power"
	},
	{
		dmg: 3,
		move: 2,
		onReach: null
	},
	{
		dmg: 3,
		move: 2,
		onReach: "horror"
	},
	{
		dmg: 4,
		move: 2,
		onReach: null
	},
	{
		dmg: 4,
		move: 2,
		onReach: "horror"
	},
	{
		dmg: 5,
		move: 3,
		onReach: null
	}
], E = T.length - 1, te = (e, t) => t ? e === 0 ? 3 : e <= 3 ? 2 : 1 : e <= 1 ? 3 : e <= 6 ? 2 : 1, D = {
	walk: {
		id: "walk",
		cost: 0,
		reaction: !1,
		attack: !1
	},
	focus: {
		id: "focus",
		cost: 0,
		reaction: !1,
		attack: !1
	},
	"weak-attack": {
		id: "weak-attack",
		cost: 0,
		reaction: !1,
		attack: !0
	},
	"short-rest": {
		id: "short-rest",
		cost: 0,
		reaction: !1,
		attack: !1
	},
	"close-call": {
		id: "close-call",
		cost: 1,
		reaction: !0,
		attack: !1
	},
	guard: {
		id: "guard",
		cost: 2,
		reaction: !0,
		attack: !1
	},
	search: {
		id: "search",
		cost: 2,
		reaction: !1,
		attack: !1
	},
	sprint: {
		id: "sprint",
		cost: 2,
		reaction: !1,
		attack: !1
	},
	distraction: {
		id: "distraction",
		cost: 3,
		reaction: !1,
		attack: !1
	},
	improvise: {
		id: "improvise",
		cost: 3,
		reaction: !1,
		attack: !1
	},
	"furious-strike": {
		id: "furious-strike",
		cost: 4,
		reaction: !1,
		attack: !0
	},
	planning: {
		id: "planning",
		cost: 4,
		reaction: !1,
		attack: !1
	},
	retaliate: {
		id: "retaliate",
		cost: 4,
		reaction: !0,
		attack: !1
	},
	"long-rest": {
		id: "long-rest",
		cost: 5,
		reaction: !1,
		attack: !1
	},
	"critical-blow": {
		id: "critical-blow",
		cost: 5,
		reaction: !1,
		attack: !0
	}
}, ne = [
	"walk",
	"walk",
	"focus",
	"focus",
	"weak-attack",
	"short-rest"
], O = {
	walk: 0,
	focus: 0,
	"weak-attack": 0,
	"short-rest": 0,
	"close-call": 2,
	guard: 2,
	search: 2,
	sprint: 2,
	distraction: 1,
	improvise: 1,
	"furious-strike": 1,
	planning: 1,
	retaliate: 1,
	"long-rest": 1,
	"critical-blow": 1
}, re = [
	"dark-feast",
	"always-wanted",
	"out-of-nowhere",
	"keeps-coming",
	"kept-swinging",
	"fresh-blood",
	"standing-there",
	"hammer-rush",
	"souvenirs",
	"unholy-rage",
	"unholy-speed",
	"fire",
	"fell-asleep",
	"rumors",
	"going-our-way",
	"run-for-life",
	"whats-her-name",
	"that-noise",
	"cant-save-us"
], k = [
	"boyfriend",
	"clingy-campers",
	"dark-waters",
	"deathwish",
	"fresh-meat",
	"girlfriend",
	"secret-tunnel",
	"star-crossed",
	"stubborn-kids",
	"vengeance"
], A = {
	bat: {
		id: "bat",
		hands: 2,
		weapon: {
			minRange: 0,
			maxRange: 0,
			dmg: 2
		}
	},
	bow: {
		id: "bow",
		hands: 2,
		weapon: {
			minRange: 1,
			maxRange: 2,
			dmg: 1,
			standalone: !0
		},
		uses: 3
	},
	axe: {
		id: "axe",
		hands: 2,
		weapon: {
			minRange: 0,
			maxRange: 0,
			dmg: 2
		}
	},
	"bear-trap": {
		id: "bear-trap",
		hands: 0
	},
	"energy-drink": {
		id: "energy-drink",
		hands: 0
	},
	fireworks: {
		id: "fireworks",
		hands: 0
	},
	"first-aid": {
		id: "first-aid",
		hands: 1
	},
	flashlight: {
		id: "flashlight",
		hands: 1
	},
	knife: {
		id: "knife",
		hands: 1,
		weapon: {
			minRange: 0,
			maxRange: 0,
			dmg: 1
		}
	},
	"lucky-dice": {
		id: "lucky-dice",
		hands: 0
	},
	"rabbits-foot": {
		id: "rabbits-foot",
		hands: 0
	},
	map: {
		id: "map",
		hands: 0
	},
	"boat-keys": {
		id: "boat-keys",
		hands: 0
	},
	pills: {
		id: "pills",
		hands: 0
	},
	revolver: {
		id: "revolver",
		hands: 1,
		weapon: {
			minRange: 1,
			maxRange: 1,
			dmg: 1,
			onlyCard: "weak-attack"
		}
	},
	"pepper-spray": {
		id: "pepper-spray",
		hands: 1
	},
	"trashcan-lid": {
		id: "trashcan-lid",
		hands: 1,
		uses: 3
	},
	whistle: {
		id: "whistle",
		hands: 1
	}
}, ie = [
	"blood-frenzy",
	"dark-obsession",
	"feed",
	"sledgehammer"
], ae = [
	"bloodbath",
	"butcher-bloodlust",
	"dark-darker-darkest"
], j = {
	laurie: {
		id: "laurie",
		hp: 5,
		saveGoal: 6,
		rewards: [
			"horror-down",
			"time2",
			"heal1",
			"time2",
			"take-card2",
			"move1"
		]
	},
	reiko: {
		id: "reiko",
		hp: 6,
		saveGoal: 5,
		rewards: [
			"time2",
			"heal1",
			"take-planning",
			"move1",
			"move1"
		]
	}
}, oe = {
	"capture-flag": {
		id: "capture-flag",
		victims: {
			"woods-nw": 2,
			"woods-n": 1,
			shed: 1,
			rec: 2,
			dock: 2,
			junction: 2
		},
		girlStart: "makeout",
		killerStart: "firepit"
	},
	"skinny-dipping": {
		id: "skinny-dipping",
		victims: {
			"woods-nw": 1,
			"woods-n": 1,
			cabins: 1,
			makeout: 2,
			cliff: 2,
			swamp: 1,
			firepit: 2
		},
		girlStart: "cove",
		killerStart: "meadow"
	},
	"treasure-hunt": {
		id: "treasure-hunt",
		victims: {
			cabins: 2,
			"woods-nw": 1,
			"woods-n": 1,
			shed: 1,
			makeout: 1,
			dock: 2,
			junction: 2
		},
		girlStart: "rec",
		killerStart: "makeout"
	},
	bonfire: {
		id: "bonfire",
		victims: {
			"woods-n": 2,
			junction: 1,
			firepit: 6,
			cove: 1
		},
		girlStart: "dock",
		killerStart: "woods-nw"
	},
	meditation: {
		id: "meditation",
		victims: {
			"woods-nw": 1,
			"woods-n": 1,
			"woods-ne": 1,
			makeout: 1,
			meadow: 1,
			swamp: 1,
			junction: 1,
			cove: 1,
			firepit: 2
		},
		girlStart: "rec",
		killerStart: "dock"
	}
}, se = [
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	2,
	3
];
//#endregion
//#region src/games/finalgirl/state.ts
function M(t, n) {
	let r = Math.max(1, n), i = [];
	for (let n = 0; n < r; n += 1) i.push(e(t.seed, t.rngCursor, 6) + 1), t.rngCursor += 1;
	return i;
}
function N(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function P(e, t, n) {
	let r = /* @__PURE__ */ new Map([[t, 0]]), i = [t];
	for (; i.length > 0;) {
		let t = i.shift(), a = r.get(t), o = [...C[t]];
		n && e.tunnel && (t === e.tunnel[0] && o.push(e.tunnel[1]), t === e.tunnel[1] && o.push(e.tunnel[0]));
		for (let e of o) e === "lake" || r.has(e) || (r.set(e, a + 1), i.push(e));
	}
	return r;
}
function ce(e, t, n, r) {
	if (t === n) return null;
	let i = P(e, n, r), a = null, o = Infinity, s = [...C[t]];
	r && e.tunnel && (t === e.tunnel[0] && s.push(e.tunnel[1]), t === e.tunnel[1] && s.push(e.tunnel[0]));
	for (let e of s) {
		if (e === "lake") continue;
		let t = i.get(e);
		t !== void 0 && t < o && (o = t, a = e);
	}
	return a;
}
function F(e, t, n) {
	if (t === 0) return;
	let r = e.horror;
	e.horror = Math.min(9, Math.max(0, e.horror + t)), n.push({
		kind: "horror",
		data: {
			from: r,
			to: e.horror
		}
	}), t > 0 && r + t > 9 ? le(e, r + t - 9, n) : t < 0 && r + t < 0 && I(e, -(r + t), n);
}
function I(e, t, n) {
	if (e.timeBusted || t <= 0) return;
	let r = e.time;
	e.time = Math.min(12, e.time + t), n.push({
		kind: "time",
		data: {
			from: r,
			to: e.time
		}
	});
}
function L(e, t, n) {
	if (t <= 0) return;
	let r = e.time;
	e.time -= t, n.push({
		kind: "time",
		data: {
			from: r,
			to: e.time
		}
	}), e.time < 0 && (e.timeBusted = !0);
}
function le(e, t, n) {
	for (let r = 0; r < t; r += 1) {
		if (e.phase === "won" || e.phase === "lost") return;
		if (e.bloodlust >= E) {
			ue(e, 1, n);
			let t = e.terrorDeck.shift();
			n.push({
				kind: "bloodlust-overflow",
				data: { skipped: t ?? null }
			});
			continue;
		}
		e.bloodlust += 1, n.push({
			kind: "bloodlust",
			data: { to: e.bloodlust }
		});
		let t = T[e.bloodlust].onReach;
		if (t === "horror" && F(e, 1, n), t === "power" && e.darkPowerPile.length > 0) {
			let t = e.darkPowerPile.shift();
			e.darkPowers.push(t), n.push({
				kind: "dark-power",
				data: { id: t }
			});
		}
	}
}
function R(e, t, n) {
	let r = j[e.girl.id].hp, i = e.girl.hp;
	e.girl.hp = Math.min(r, e.girl.hp + t), e.girl.hp !== i && n.push({
		kind: "heal-girl",
		data: {
			from: i,
			to: e.girl.hp
		}
	});
}
function ue(e, t, n) {
	let r = e.killer.hp;
	e.killer.hp = Math.min(12, e.killer.hp + t), e.killer.hp !== r && n.push({
		kind: "heal-killer",
		data: {
			from: r,
			to: e.killer.hp
		}
	});
}
function de(e, t, n) {
	let r = t === "girl" ? e.girl.token : e.killer.token;
	if (r.revealed) {
		t === "girl" ? e.girl.hp = 0 : e.killer.hp = 0, e.phase = t === "girl" ? "lost" : "won", n.push({
			kind: "game-over",
			data: { result: e.phase }
		});
		return;
	}
	if (r.revealed = !0, n.push({
		kind: "token-reveal",
		rid: e.rid,
		data: {
			who: t,
			hp: r.hp
		}
	}), r.hp === 0) {
		t === "girl" ? e.girl.hp = 0 : e.killer.hp = 0, e.phase = t === "girl" ? "lost" : "won", n.push({
			kind: "game-over",
			data: { result: e.phase }
		});
		return;
	}
	r.white = !0, t === "girl" ? e.girl.hp = r.hp : e.killer.hp = r.hp, e.phaseInterrupt = !0, n.push({
		kind: "revive",
		data: {
			who: t,
			hp: r.hp
		}
	});
}
function z(e, t, n) {
	if (t <= 0 || e.phase === "won" || e.phase === "lost") return;
	let r = e.girl.hp;
	e.girl.hp -= t, n.push({
		kind: "damage-girl",
		data: {
			from: r,
			amount: t
		}
	}), e.girl.hp <= 0 && de(e, "girl", n);
}
function fe(e, t, n) {
	if (t <= 0 || e.phase === "won" || e.phase === "lost") return;
	let r = t;
	for (let t of e.minorPowers) {
		if (r <= 0) break;
		let e = Math.min(t.hp, r);
		t.hp -= e, r -= e;
	}
	if (e.minorPowers = e.minorPowers.filter((e) => e.hp > 0), r <= 0) {
		n.push({
			kind: "damage-killer",
			data: {
				amount: t,
				absorbed: !0
			}
		});
		return;
	}
	let i = e.killer.hp;
	e.killer.hp -= r, n.push({
		kind: "damage-killer",
		data: {
			from: i,
			amount: t
		}
	}), e.killer.hp <= 0 && de(e, "killer", n);
}
function B(e, t) {
	return e.victims.filter((e) => e.space === t);
}
function pe(e, t, n, r) {
	for (let r = 0; r < n; r += 1) e.victims.push({
		id: e.nextVictimId,
		space: t,
		special: null
	}), e.nextVictimId += 1;
	r.push({
		kind: "spawn",
		data: {
			space: t,
			count: n
		}
	});
}
function V(e, t, n, r) {
	let i = t.space, a = B(e, i).length === 2;
	if (e.victims = e.victims.filter((e) => e.id !== t.id), e.deadCount += 1, e.victimsDiedThisTurn = !0, n.push({
		kind: "kill-victim",
		data: {
			id: t.id,
			space: i,
			special: t.special
		}
	}), r.byKiller && (le(e, 1 + e.bonusBloodlustPerKill + (t.special === "damned" ? 2 : 0), n), e.darkPowers.includes("feed") && ue(e, 1, n), e.darkPowers.includes("blood-frenzy") && le(e, 1, n), e.horrorPerKill > 0 && F(e, e.horrorPerKill, n)), t.special === "boyfriend" && e.event === "boyfriend" && i === e.girl.space && (e.boyfriendDiedAtGirl = !0), t.special === "girlfriend" && e.event === "girlfriend" && i === e.girl.space && F(e, 5, n), e.event === "star-crossed" && a) {
		let t = B(e, i);
		t.length === 1 && V(e, t[0], n, r);
	}
}
function H(e, t) {
	return e.items.find((e) => e.id === t);
}
function me(e, t) {
	return H(e, t).where === "hands";
}
function he(e) {
	return e.items.filter((e) => e.where === "hands").reduce((e, t) => e + A[t.id].hands, 0);
}
function ge(e, t, n) {
	let r = A[t.id].hands;
	t.where = r > 0 && he(e) + r <= 2 ? "hands" : "backpack", t.pile = null, t.faceUp = !1, n.push({
		kind: "item-take",
		data: {
			id: t.id,
			where: t.where
		}
	});
}
function U(e, t) {
	return e.items.filter((e) => e.where === "pile" && e.pile === t);
}
function _e(e) {
	return e.event === "stubborn-kids" ? 1 : 2 + +!!me(e, "whistle");
}
function ve(e, t, n) {
	if (t.special !== "damned") return !0;
	let r = new Set(n);
	return e.victims.every((e) => e.id === t.id || r.has(e.id));
}
function ye(e) {
	let t = te(e.horror, e.extreme);
	return t += e.nextRollBonus, e.girl.hp === 1 && (t += 1), e.killer.hp === 1 && (t += 1), e.event === "girlfriend" && e.victims.some((t) => t.special === "girlfriend" && t.space === e.girl.space) && (t += 1), Math.max(1, t);
}
function be(e, t) {
	let n = 0;
	for (let r = 0; r < t.dice.length; r += 1) {
		let i = t.dice[r];
		(i >= 5 || i >= 3 && (t.converted[r] || e.improviseNext || e.improvisePhase)) && (n += 1);
	}
	return n;
}
function W(e, t) {
	e.phase = "planning", e.pending = null, e.moveBudget = 0, e.moveAfterEnd = !1, t.push({
		kind: "phase",
		data: { phase: "planning" }
	});
}
function G(e, t) {
	if (e.phase = "upkeep", !e.finaleRevealed && e.terrorDeck.length === 0 && (e.finaleRevealed = !0, t.push({
		kind: "finale",
		data: { id: e.finale }
	}), e.finale === "dark-darker-darkest" && e.darkPowerPile.length > 0)) {
		let n = e.darkPowerPile.shift();
		e.darkPowers.push(n), t.push({
			kind: "dark-power",
			data: { id: n }
		});
	}
	if (e.event === "deathwish" && e.victims.length > 0) {
		let n = P(e, e.killer.space, !1), r = null, i = Infinity;
		for (let t of e.victims) {
			let e = n.get(t.space) ?? Infinity;
			e > 0 && e < i && (i = e, r = t);
		}
		if (r) {
			let n = ce(e, r.space, e.killer.space, !1);
			if (n) {
				let e = r.space;
				r.space = n, t.push({
					kind: "move-victim",
					data: {
						id: r.id,
						from: e,
						to: n,
						cause: "deathwish"
					}
				});
			}
		}
	}
	t.push({
		kind: "phase",
		data: { phase: "upkeep" }
	});
}
function xe(e, t) {
	e.turn += 1, e.phase = "action", e.victimsDiedThisTurn = !1, e.whistleUsed = !1, e.flashlightUsed = !1, e.savesThisPhase = 0, e.improvisePhase = !1, e.girl.ultimateUsed = !1, e.girlAttackedThisPhase = !1, e.obsessionFired = !1, e.horrorPerKill = 0, e.bonusBloodlustPerKill = 0, e.timeBusted = !1, e.boyfriendDiedAtGirl && (e.boyfriendDiedAtGirl = !1, e.time = 12, t.push({
		kind: "time",
		data: {
			from: 0,
			to: 12
		}
	})), t.push({
		kind: "phase",
		data: {
			phase: "action",
			turn: e.turn
		}
	});
}
function Se(e) {
	let t = T[Math.min(e.bloodlust, E)].dmg;
	return e.minorPowers.some((e) => e.id === "unholy-rage") && (t += e.killerIcons.knife), t;
}
function Ce(e) {
	let t = T[Math.min(e.bloodlust, E)].move;
	return e.minorPowers.some((e) => e.id === "unholy-speed") && (t += e.killerIcons.boot), t;
}
function we(e, t, n) {
	let r = e.victims.find((e) => e.id === t);
	if (!r) return;
	let i = M(e, 1)[0], a = w[r.space][i - 1], o = r.space;
	a ? (r.space = a, n.push({
		kind: "panic",
		data: {
			id: r.id,
			die: i,
			from: o,
			to: a
		}
	})) : n.push({
		kind: "panic",
		data: {
			id: r.id,
			die: i,
			from: o,
			to: null
		}
	});
}
function Te(e, t, n) {
	let r = ce(e, e.killer.space, t, !1);
	if (!r) return;
	let i = e.killer.space;
	e.killer.space = r, n.push({
		kind: "move-killer",
		data: {
			from: i,
			to: r
		}
	});
	let a = e.items.find((e) => e.id === "bear-trap" && e.where === "board" && e.boardSpace === r);
	a && (a.where = "gone", a.boardSpace = null, n.push({
		kind: "bear-trap",
		data: { space: r }
	}), fe(e, 2, n), e.phaseInterrupt = !0);
	let o = e.items.find((e) => e.id === "fireworks" && e.where === "board" && e.boardSpace === r);
	o && r === t && (o.where = "gone", o.boardSpace = null, n.push({
		kind: "fireworks-off",
		data: { space: r }
	}));
}
//#endregion
//#region src/games/finalgirl/cards.ts
function Ee(e, t, n) {
	let r = P(e, e.girl.space, !0).get(e.killer.space) ?? Infinity;
	if (r === 0) {
		if (!n) return !0;
		let e = A[n].weapon;
		return !!e && !e.standalone && e.minRange === 0 && !(e.onlyCard && e.onlyCard !== t);
	}
	if (!n) return !1;
	let i = A[n].weapon;
	return !i || i.standalone || i.onlyCard && i.onlyCard !== t ? !1 : r >= i.minRange && r <= i.maxRange;
}
function De(e, t, n, r) {
	let i = D[t];
	if (i.reaction) return { code: "games.finalgirl.errNotNow" };
	if (i.attack && !Ee(e, t, n)) return { code: "games.finalgirl.errOutOfRange" };
	if (n && !me(e, n)) return { code: "games.finalgirl.errBadItem" };
	if (t === "search") {
		if (![
			"cabins",
			"dock",
			"shed"
		].includes(e.girl.space)) return { code: "games.finalgirl.errNotSearchSpace" };
		if (U(e, e.girl.space).length === 0) return { code: "games.finalgirl.errEmptyPile" };
	}
	e.hand = e.hand.filter((n, r) => r !== e.hand.indexOf(t)), e.discard.push(t);
	let a = M(e, ye(e));
	return e.nextRollBonus = 0, e.lastRoll = {
		dice: a,
		context: t
	}, e.pending = {
		kind: "roll",
		ctx: {
			kind: "card",
			card: t,
			weapon: n
		},
		dice: a,
		converted: a.map(() => !1),
		closeCallUsed: !1,
		luckyUsed: !1
	}, r.push({
		kind: "roll",
		data: {
			card: t,
			dice: a
		}
	}), null;
}
function Oe(e, t) {
	e.moveBudget += t;
}
function K(e, t, n, r) {
	if (t <= 0) return;
	let i = t;
	n && (i += A[n].weapon?.dmg ?? 0), e.girl.ultimate && e.girl.id === "laurie" && e.girl.space === e.killer.space && (i += 1), fe(e, i, r), n === "bat" && e.minorPowers.length > 0 && e.phase !== "won" && (e.pending = { kind: "bat-power" });
}
function ke(e, t, n, r, i) {
	switch (e.improviseNext &&= !1, t) {
		case "walk":
			r === "two" ? (Oe(e, 2), L(e, 1, i)) : r === "one" ? (Oe(e, 1), L(e, 1, i)) : e.pending = {
				kind: "fail-choice",
				card: t
			};
			break;
		case "focus":
			r === "two" ? (F(e, -1, i), I(e, 2, i)) : r === "one" ? (F(e, -1, i), L(e, 1, i)) : L(e, 2, i);
			break;
		case "weak-attack":
			r === "two" ? K(e, 1, n, i) : r === "one" ? (K(e, 1, n, i), z(e, 1, i)) : (z(e, 1, i), e.moveAfterEnd = !0);
			break;
		case "short-rest": {
			let t = +!!me(e, "first-aid");
			r === "two" ? R(e, 2 + t, i) : r === "one" ? (R(e, 1 + t, i), L(e, 1, i)) : (R(e, 1 + t, i), F(e, 1, i), L(e, 1, i), e.moveAfterEnd = !0);
			break;
		}
		case "search": {
			let n = U(e, e.girl.space);
			r === "two" ? n.length >= 2 ? (e.pending = {
				kind: "search-pick",
				space: e.girl.space,
				top: [n[0].id, n[1].id]
			}, i.push({
				kind: "peek",
				data: { items: [n[0].id, n[1].id] }
			}), L(e, 1, i)) : (ge(e, n.shift(), i), L(e, 1, i)) : r === "one" ? (ge(e, n.shift(), i), L(e, 1, i)) : e.pending = {
				kind: "fail-choice",
				card: t
			};
			break;
		}
		case "sprint":
			r === "two" ? (Oe(e, 3), L(e, 1, i)) : r === "one" ? (Oe(e, 2), L(e, 1, i)) : e.pending = {
				kind: "fail-choice",
				card: t
			};
			break;
		case "distraction":
			r === "two" ? (F(e, -2, i), I(e, 2, i)) : r === "one" ? (F(e, -1, i), I(e, 1, i)) : e.pending = {
				kind: "fail-choice",
				card: t
			};
			break;
		case "improvise":
			r === "two" ? e.improvisePhase = !0 : r === "one" ? e.improviseNext = !0 : (F(e, 1, i), L(e, 1, i));
			break;
		case "furious-strike":
			r === "two" ? (K(e, 2, n, i), F(e, -1, i)) : r === "one" ? (K(e, 1, n, i), F(e, -1, i), e.moveAfterEnd = !0) : (z(e, 1, i), F(e, 1, i), e.moveAfterEnd = !0);
			break;
		case "planning":
			r === "two" ? e.nextRollBonus = 3 : r === "one" ? (e.nextRollBonus = 2, L(e, 1, i)) : (e.nextRollBonus = 1, F(e, 1, i), L(e, 2, i));
			break;
		case "long-rest": {
			let t = +!!me(e, "first-aid");
			r === "two" ? (R(e, 4 + t, i), L(e, 1, i)) : r === "one" ? (R(e, 3 + t, i), L(e, 2, i)) : (R(e, 2 + t, i), F(e, 1, i), L(e, 2, i), e.moveAfterEnd = !0);
			break;
		}
		case "critical-blow": r === "two" ? (K(e, 3, n, i), F(e, -1, i)) : r === "one" ? (K(e, 2, n, i), F(e, -1, i), e.moveAfterEnd = !0) : (K(e, 2, n, i), z(e, 2, i), F(e, 1, i), e.moveAfterEnd = !0);
	}
	e.moveAfterEnd && e.moveBudget === 0 && e.pending === null && W(e, i);
}
function Ae(e, t, n, r) {
	if (t === "walk") n === 0 ? (Oe(e, 1), z(e, 1, r), L(e, 2, r)) : L(e, 2, r);
	else if (t === "sprint") n === 0 ? (Oe(e, 1), z(e, 1, r), L(e, 2, r), e.moveAfterEnd = !0) : (z(e, 1, r), L(e, 2, r));
	else if (t === "distraction") n === 0 ? (F(e, -1, r), L(e, 4, r)) : (F(e, 1, r), L(e, 2, r));
	else if (t === "search") {
		if (n === 0) {
			let t = U(e, e.girl.space);
			t.length > 0 && ge(e, t.shift(), r), F(e, 2, r), L(e, 2, r);
		} else F(e, 1, r), L(e, 2, r);
	}
	e.pending = null, e.moveAfterEnd && e.moveBudget === 0 && W(e, r);
}
function je(e, t, n, r, i) {
	let a = n;
	return t === "guard" ? a = r === "two" ? 0 : r === "one" ? Math.max(0, n - 2) : Math.max(1, n - 1) : r === "two" ? (a = 0, K(e, 2, null, i)) : r === "one" && (a = Math.max(0, n - 2), K(e, 1, null, i)), i.push({
		kind: "reaction",
		data: {
			card: t,
			outcome: r,
			rest: a
		}
	}), a;
}
function Me(e, t, n) {
	let r = be(e, t), i = r >= 2 ? "two" : r === 1 ? "one" : "fail";
	n.push({
		kind: "roll-result",
		data: {
			dice: t.dice,
			successes: r,
			outcome: i
		}
	}), e.pending = null;
	let a = t.ctx;
	if (a.kind === "card") {
		ke(e, a.card, a.weapon, i, n);
		return;
	}
	if (a.kind === "reaction") {
		Ne(e, je(e, a.card, a.dmg, i, n), a.attacksLeft, n);
		return;
	}
	r > 0 && (e.pending = {
		kind: "item-choice",
		item: "rabbits-foot",
		options: [
			"time2",
			"heal1",
			"horror-down",
			"move1"
		],
		remaining: r,
		piles: []
	});
}
function Ne(e, t, n, r) {
	t > 0 && z(e, t, r), !(e.phase === "lost" || e.phase === "won" || e.phaseInterrupt) && n > 1 && (e.pending = {
		kind: "reaction",
		dmg: Se(e),
		attacksLeft: n - 1
	});
}
function Pe(e, t, n) {
	let r = H(e, t), i = A[t];
	if (r.where === "gone" || r.where === "pile" || r.where === "board") return { code: "games.finalgirl.errBadItem" };
	if (i.hands > 0 && r.where !== "hands") return { code: "games.finalgirl.errNotInHands" };
	switch (t) {
		case "energy-drink":
			r.where = "gone", e.pending = {
				kind: "item-choice",
				item: t,
				options: ["time3", "move1"],
				remaining: 1,
				piles: []
			};
			break;
		case "pills":
			r.where = "gone", e.pending = {
				kind: "item-choice",
				item: t,
				options: ["horror-down", "heal2"],
				remaining: 1,
				piles: []
			};
			break;
		case "rabbits-foot": {
			r.where = "gone";
			let i = M(e, ye(e));
			e.lastRoll = {
				dice: i,
				context: t
			}, e.pending = {
				kind: "roll",
				ctx: { kind: "rabbits-foot" },
				dice: i,
				converted: i.map(() => !1),
				closeCallUsed: !1,
				luckyUsed: !1
			}, n.push({
				kind: "roll",
				data: {
					item: t,
					dice: i
				}
			});
			break;
		}
		case "map": {
			r.where = "gone";
			let n = [
				"cabins",
				"dock",
				"shed"
			].filter((t) => U(e, t).length > 0);
			if (n.length === 0) break;
			e.pending = {
				kind: "item-choice",
				item: t,
				options: [
					"flip",
					"remove",
					"skip"
				],
				remaining: n.length,
				piles: n
			};
			break;
		}
		case "flashlight": {
			if (e.flashlightUsed) return { code: "games.finalgirl.errOncePerPhase" };
			if (e.time < 1) return { code: "games.finalgirl.errNoTime" };
			if (e.terrorDeck.length === 0) return { code: "games.finalgirl.errEmptyDeck" };
			L(e, 1, n), e.flashlightUsed = !0;
			let r = e.terrorDeck[0];
			e.peeked = [r], e.pending = {
				kind: "item-choice",
				item: t,
				options: ["keep-top", "to-bottom"],
				remaining: 1,
				piles: []
			}, n.push({
				kind: "peek",
				data: { terror: r }
			});
			break;
		}
		case "whistle": {
			if (e.whistleUsed) return { code: "games.finalgirl.errOncePerPhase" };
			if (e.time < 1) return { code: "games.finalgirl.errNoTime" };
			L(e, 1, n), e.whistleUsed = !0;
			let t = e.tunnel && (e.girl.space === e.tunnel[0] || e.girl.space === e.tunnel[1]) ? [...e.girl.space === e.tunnel[0] ? [e.tunnel[1]] : [e.tunnel[0]], ...Ie(e.girl.space)] : Ie(e.girl.space);
			for (let r of e.victims) if (t.includes(r.space)) {
				let t = r.space;
				r.space = e.girl.space, n.push({
					kind: "move-victim",
					data: {
						id: r.id,
						from: t,
						to: e.girl.space,
						cause: "whistle"
					}
				});
			}
			e.killerTarget = {
				space: e.girl.space,
				isGirl: !0
			};
			let r = T[e.bloodlust].move;
			for (let t = 0; t < r && e.killer.space !== e.girl.space; t += 1) Te(e, e.girl.space, n);
			break;
		}
		case "bear-trap":
			if (e.time < 2) return { code: "games.finalgirl.errNoTime" };
			if (e.items.some((e) => e.id === "bear-trap" && e.where === "board")) return { code: "games.finalgirl.errNotNow" };
			L(e, 2, n), r.where = "board", r.boardSpace = e.girl.space, n.push({
				kind: "item-place",
				data: {
					id: t,
					space: e.girl.space
				}
			});
			break;
		case "fireworks": {
			if (e.time < 2) return { code: "games.finalgirl.errNoTime" };
			let t = Ie(e.girl.space).filter((e) => e !== "lake");
			if (t.length === 0) return { code: "games.finalgirl.errNotNow" };
			L(e, 2, n), e.pending = {
				kind: "pick-space",
				for: "fireworks",
				options: t
			};
			break;
		}
		case "boat-keys":
			if (e.time < 2) return { code: "games.finalgirl.errNoTime" };
			if (!Fe.includes(e.girl.space)) return { code: "games.finalgirl.errNotLakeside" };
			L(e, 2, n), e.pending = {
				kind: "pick-space",
				for: "boat",
				options: Fe.filter((t) => t !== e.girl.space)
			};
			break;
		case "bow": {
			if (r.uses === null || r.uses <= 0) return { code: "games.finalgirl.errBadItem" };
			if (e.time < 2) return { code: "games.finalgirl.errNoTime" };
			let t = P(e, e.girl.space, !0).get(e.killer.space) ?? Infinity;
			if (t < 1 || t > 2) return { code: "games.finalgirl.errOutOfRange" };
			L(e, 2, n), --r.uses, n.push({
				kind: "bow-shot",
				data: { uses: r.uses }
			}), fe(e, 1, n), r.uses <= 0 && (r.where = "gone");
			break;
		}
		default: return { code: "games.finalgirl.errNotNow" };
	}
	return null;
}
var Fe = [
	"cabins",
	"makeout",
	"cliff",
	"cove",
	"dock",
	"swamp"
];
function Ie(e) {
	return C[e];
}
//#endregion
//#region src/games/finalgirl/killer.ts
function Le(e) {
	if (!e.finaleRevealed) return [
		{
			s: "icons",
			knife: 1,
			boot: 1
		},
		{
			s: "target",
			mode: "closest"
		},
		{ s: "move" },
		{ s: "attack" }
	];
	switch (e.finale) {
		case "bloodbath": return [
			{
				s: "icons",
				knife: 2,
				boot: 2
			},
			{
				s: "target",
				mode: "closest"
			},
			{ s: "move" },
			{ s: "move" },
			{ s: "attack" },
			{ s: "attack" }
		];
		case "butcher-bloodlust": return [
			{
				s: "icons",
				knife: 1,
				boot: 2
			},
			{
				s: "bloodlust",
				n: 1
			},
			{
				s: "target",
				mode: "closest"
			},
			{ s: "move" },
			{ s: "move" },
			{ s: "attack" }
		];
		case "dark-darker-darkest": return [
			{
				s: "icons",
				knife: 1,
				boot: 2
			},
			{
				s: "target",
				mode: "closest"
			},
			{ s: "move" },
			{ s: "move" },
			{ s: "attack" }
		];
	}
}
function Re(e, t) {
	e.phase = "killer", e.girlAttackedThisPhase = !1, e.obsessionFired = !1, e.horrorPerKill = 0, e.bonusBloodlustPerKill = 0, e.killerTarget = null, e.killerQueue = [...Le(e)], e.finaleRevealed || e.killerQueue.push({ s: "draw-terror" }), e.killerQueue.push({ s: "end" }), e.beatMs = 800, t.push({
		kind: "phase",
		data: { phase: "killer" }
	});
}
function ze(e, t) {
	let n = e.victims.length > 0;
	switch (t) {
		case "dark-feast": return [{
			s: "horror",
			n: 1
		}, {
			s: "heal-killer",
			n: e.deadCount
		}];
		case "always-wanted": return [
			{
				s: "icons",
				knife: 1,
				boot: 2
			},
			{
				s: "target",
				mode: "girl"
			},
			{ s: "move" },
			{ s: "move" },
			{ s: "attack" }
		];
		case "out-of-nowhere": return [
			{ s: "teleport-far" },
			{
				s: "horror",
				n: 1
			},
			{ s: "draw-terror" }
		];
		case "keeps-coming": return [
			{
				s: "horror",
				n: 1
			},
			{
				s: "icons",
				knife: 1,
				boot: 1
			},
			{
				s: "target",
				mode: "closest"
			},
			{ s: "move" },
			{ s: "attack" }
		];
		case "kept-swinging": return n ? [
			{
				s: "icons",
				knife: 1,
				boot: 1
			},
			{
				s: "target",
				mode: "victim"
			},
			{ s: "move" },
			{ s: "attack" },
			{
				s: "icons",
				knife: 1,
				boot: 1
			},
			{
				s: "target",
				mode: "victim"
			},
			{ s: "move" },
			{ s: "attack" }
		] : [{ s: "draw-terror" }];
		case "fresh-blood": return n ? [
			{
				s: "icons",
				knife: 1,
				boot: 2
			},
			{
				s: "target",
				mode: "victim"
			},
			{ s: "move" },
			{ s: "move" },
			{ s: "attack" }
		] : [{ s: "draw-terror" }];
		case "standing-there": return [
			{
				s: "horror",
				n: 2
			},
			{
				s: "icons",
				knife: 0,
				boot: 2
			},
			{
				s: "target",
				mode: "closest"
			},
			{ s: "move" },
			{ s: "move" }
		];
		case "hammer-rush": return n ? (e.horrorPerKill = 1, [
			{
				s: "icons",
				knife: 2,
				boot: 2
			},
			{
				s: "target",
				mode: "victim"
			},
			{ s: "move" },
			{ s: "move" },
			{ s: "attack" },
			{ s: "attack" }
		]) : [];
		case "souvenirs": return n ? (e.bonusBloodlustPerKill = 1, [
			{
				s: "icons",
				knife: 2,
				boot: 2
			},
			{
				s: "target",
				mode: "victim"
			},
			{ s: "move" },
			{ s: "move" },
			{ s: "attack" },
			{ s: "attack" }
		]) : [];
		case "fire": return [{ s: "fire" }];
		case "fell-asleep": return [{
			s: "spawn",
			space: "cabins",
			count: 1
		}, {
			s: "horror",
			n: 2
		}];
		case "rumors": return [
			{
				s: "spawn",
				space: e.killerStart,
				count: 2
			},
			{
				s: "horror",
				n: 1
			},
			{ s: "draw-event" }
		];
		case "going-our-way": return [{ s: "gain-item" }];
		case "run-for-life": return n ? [
			{
				s: "panic-scope",
				scope: "not-girl",
				times: 1
			},
			{
				s: "icons",
				knife: 1,
				boot: 0
			},
			{
				s: "target",
				mode: "closest"
			},
			{ s: "attack" },
			{
				s: "icons",
				knife: 0,
				boot: 1
			},
			{
				s: "target",
				mode: "victim"
			},
			{ s: "move" }
		] : [{ s: "draw-terror" }];
		case "whats-her-name": return [
			{
				s: "spawn",
				space: e.girlStart,
				count: 2
			},
			{
				s: "horror",
				n: 1
			},
			{ s: "draw-event" }
		];
		case "that-noise": return n ? [
			{ s: "victims-advance" },
			{
				s: "icons",
				knife: 1,
				boot: 0
			},
			{
				s: "target",
				mode: "closest"
			},
			{ s: "attack" },
			{
				s: "icons",
				knife: 0,
				boot: 1
			},
			{
				s: "target",
				mode: "victim"
			},
			{ s: "move" }
		] : [{ s: "draw-terror" }];
		case "cant-save-us": return n ? [
			{
				s: "panic-scope",
				scope: "girl-space",
				times: 2
			},
			{
				s: "icons",
				knife: 1,
				boot: 0
			},
			{
				s: "target",
				mode: "closest"
			},
			{ s: "attack" },
			{
				s: "icons",
				knife: 0,
				boot: 1
			},
			{
				s: "target",
				mode: "victim"
			},
			{ s: "move" }
		] : [{ s: "draw-terror" }];
		default: return [];
	}
}
function Be(e, t, n) {
	let r = e.items.find((e) => e.id === "fireworks" && e.where === "board");
	if (r && r.boardSpace) {
		e.killerTarget = {
			space: r.boardSpace,
			isGirl: !1
		}, n.push({
			kind: "target",
			data: {
				space: r.boardSpace,
				fireworks: !0
			}
		});
		return;
	}
	if (t === "girl") {
		e.killerTarget = {
			space: e.girl.space,
			isGirl: !0
		}, n.push({
			kind: "target",
			data: {
				space: e.girl.space,
				girl: !0
			}
		});
		return;
	}
	let i = e.victims.find((e) => e.special === "damned");
	if (i && t === "victim") {
		e.killerTarget = {
			space: i.space,
			isGirl: !1
		}, n.push({
			kind: "target",
			data: { space: i.space }
		});
		return;
	}
	let a = P(e, e.killer.space, !1), o = [];
	t === "closest" && o.push({
		space: e.girl.space,
		isGirl: !0,
		d: a.get(e.girl.space) ?? 99,
		victims: 0
	});
	let s = /* @__PURE__ */ new Map();
	for (let t of e.victims) s.set(t.space, (s.get(t.space) ?? 0) + 1);
	for (let [e, t] of s) o.push({
		space: e,
		isGirl: !1,
		d: a.get(e) ?? 99,
		victims: t
	});
	let c = Math.min(...o.map((e) => e.d)), l = o.filter((e) => e.d === c), u = Math.max(...l.map((e) => e.victims));
	if (l = l.filter((e) => e.victims === u), l.length === 1) {
		let t = l[0];
		e.killerTarget = {
			space: t.space,
			isGirl: t.isGirl
		}, n.push({
			kind: "target",
			data: {
				space: t.space,
				girl: t.isGirl
			}
		});
		return;
	}
	e.pending = {
		kind: "tie",
		options: l.map((e) => e.space),
		apply: "target"
	};
}
function Ve(e, t) {
	if (!e.killerTarget) return;
	let n = e.killerTarget.isGirl ? e.girl.space : e.killerTarget.space, r = Ce(e);
	for (let i = 0; i < r && !(e.killer.space === n || e.phaseInterrupt); i += 1) Te(e, n, t);
}
function He(e, t) {
	let n = B(e, t);
	return n.find((e) => e.special === "damned") ?? n.find((e) => e.special === null) ?? n[0] ?? null;
}
function Ue(e, t) {
	let n = e.killer.space, r = B(e, n), i = e.girl.space === n, a = Se(e), o = 1 + e.killerQueue.filter((e) => e.s === "attack").length;
	if (e.darkPowers.includes("sledgehammer")) {
		for (let n of [...r]) V(e, n, t, { byKiller: !0 });
		i && e.phase !== "lost" && !e.phaseInterrupt && (e.girlAttackedThisPhase = !0, e.pending = {
			kind: "reaction",
			dmg: a,
			attacksLeft: o
		}, t.push({
			kind: "attack-girl",
			data: {
				dmg: a,
				attacksLeft: o
			}
		}));
		return;
	}
	if (e.killerTarget?.isGirl !== !0 && r.length > 0) {
		let r = He(e, n);
		r && V(e, r, t, { byKiller: !0 });
		return;
	}
	if (i) {
		e.girlAttackedThisPhase = !0, e.pending = {
			kind: "reaction",
			dmg: a,
			attacksLeft: o
		}, t.push({
			kind: "attack-girl",
			data: {
				dmg: a,
				attacksLeft: o
			}
		});
		return;
	}
	t.push({
		kind: "attack-whiff",
		data: { space: n }
	});
}
function We(e, t) {
	let n = M(e, 1)[0], r = n <= 2 ? "cabins" : n <= 4 ? "shed" : "dock";
	t.push({
		kind: "fire",
		data: {
			die: n,
			space: r
		}
	});
	for (let n of [...B(e, r)]) V(e, n, t, { byKiller: !0 });
	for (let t of U(e, r)) t.where = "gone", t.pile = null;
	e.girl.space === r && z(e, 1, t), e.killer.space === r && fe(e, 1, t);
}
function Ge(e, t) {
	let n = e.eventDeck.shift();
	n && (e.event = n, t.push({
		kind: "event",
		data: { id: n }
	}), Ke(e, n, t));
}
function Ke(e, t, n) {
	if (t === "boyfriend" || t === "girlfriend") {
		let r = P(e, e.girl.space, !0), i = null;
		for (let t of e.victims) {
			let e = r.get(t.space) ?? 99;
			(!i || e < i.d) && (i = {
				id: t.id,
				d: e
			});
		}
		if (i) {
			let r = e.victims.find((e) => e.id === i.id);
			r && (r.special = t === "boyfriend" ? "boyfriend" : "girlfriend", n.push({
				kind: "special-victim",
				data: {
					id: r.id,
					special: r.special
				}
			}));
		}
	} else if (t === "vengeance") {
		let t = P(e, e.killer.space, !1), r = null;
		for (let n of e.victims) {
			let e = t.get(n.space) ?? -1;
			(!r || e > r.d) && (r = {
				id: n.id,
				d: e
			});
		}
		if (r) {
			let t = e.victims.find((e) => e.id === r.id);
			t && (t.special = "damned", n.push({
				kind: "special-victim",
				data: {
					id: t.id,
					special: "damned"
				}
			}));
		}
	} else if (t === "fresh-meat") pe(e, "cabins", 2, n), pe(e, "dock", 2, n), pe(e, "firepit", 2, n);
	else if (t === "secret-tunnel") e.pending = {
		kind: "pick-space",
		for: "tunnel1",
		options: [...S]
	};
	else if (t === "dark-waters") for (let t of [...B(e, "lake")]) V(e, t, n, { byKiller: !1 });
}
function qe(e) {
	let t = [], n = e.killerQueue.shift();
	if (!n) return t;
	switch (e.beatMs = Xe(n), n.s) {
		case "icons": return e.killerIcons = {
			knife: n.knife,
			boot: n.boot
		}, t;
		case "target": return Be(e, n.mode, t), t;
		case "move": return Ve(e, t), t;
		case "attack": return Ue(e, t), t;
		case "horror": return F(e, n.n, t), t;
		case "bloodlust": return le(e, n.n, t), t;
		case "heal-killer": return ue(e, n.n, t), t;
		case "draw-terror": {
			e.horrorPerKill = 0, e.bonusBloodlustPerKill = 0;
			let n = e.terrorDeck.shift();
			return n ? (t.push({
				kind: "terror",
				data: { card: n }
			}), n === "unholy-rage" || n === "unholy-speed" ? (e.minorPowers.push({
				id: n,
				hp: 2
			}), ue(e, 0, t), t.push({
				kind: "minor-power",
				data: { id: n }
			}), t) : (e.terrorDiscard.push(n), e.killerQueue.unshift({
				s: "terror-effect",
				card: n
			}), t)) : t;
		}
		case "terror-effect": {
			let r = ze(e, n.card);
			return e.killerQueue.unshift(...r), t;
		}
		case "panic-scope": {
			let r;
			if (n.scope === "killer-space") r = B(e, e.killer.space).map((e) => e.id);
			else if (n.scope === "not-girl") r = e.victims.filter((t) => t.space !== e.girl.space).map((e) => e.id);
			else {
				let t = B(e, e.girl.space).map((e) => e.id);
				r = n.times === 2 ? [...t, ...t] : t;
			}
			return r.length > 0 && (e.panicQueue = r, e.panicReturn = "killer", e.pending = { kind: "panic" }), t;
		}
		case "victims-advance": {
			let n = P(e, e.killer.space, !1);
			for (let r of e.victims) {
				if ((n.get(r.space) ?? 0) === 0) continue;
				let i = r.space, a = ce(e, r.space, e.killer.space, !1);
				a && (r.space = a, t.push({
					kind: "move-victim",
					data: {
						id: r.id,
						from: i,
						to: a,
						cause: "terror"
					}
				}));
			}
			return t;
		}
		case "fire": return We(e, t), t;
		case "spawn": return pe(e, n.space, n.count, t), t;
		case "draw-event": return Ge(e, t), t;
		case "gain-item": {
			let n = S.filter((t) => U(e, t).length > 0);
			return n.length > 0 && (e.pending = {
				kind: "pick-pile",
				options: n
			}), t;
		}
		case "teleport-far": {
			let n = P(e, e.girl.space, !1), r = -1;
			for (let e of n.values()) e > r && (r = e);
			let i = [...n.entries()].filter(([, e]) => e === r).map(([e]) => e);
			if (i.length === 1) {
				let n = e.killer.space;
				e.killer.space = i[0], t.push({
					kind: "teleport-killer",
					data: {
						from: n,
						to: i[0]
					}
				});
			} else e.pending = {
				kind: "tie",
				options: i,
				apply: "teleport"
			};
			return t;
		}
		case "end": return e.darkPowers.includes("dark-obsession") && e.girlAttackedThisPhase && !e.obsessionFired && e.phase !== "won" && e.phase !== "lost" ? (e.obsessionFired = !0, e.killerQueue.unshift({ s: "attack" }, { s: "end" }), t.push({
			kind: "obsession",
			data: {}
		}), t) : (Je(e, t), t);
	}
	return t;
}
function Je(e, t) {
	e.killerQueue = [], e.killerTarget = null;
	let n = e.victimsDiedThisTurn ? B(e, e.killer.space).map((e) => e.id) : [];
	if (n.length > 0) {
		e.phase = "panic", e.panicQueue = n, e.panicReturn = "panic", e.pending = { kind: "panic" }, t.push({
			kind: "phase",
			data: { phase: "panic" }
		});
		return;
	}
	G(e, t);
}
function Ye(e, t) {
	if (e.phase === "won" || e.phase === "lost") {
		e.killerQueue = [], e.pending = null;
		return;
	}
	e.phaseInterrupt && (e.phaseInterrupt = !1, Je(e, t));
}
function Xe(e) {
	switch (e.s) {
		case "target": return 800;
		case "move": return 700;
		case "attack": return 1e3;
		case "horror":
		case "bloodlust":
		case "heal-killer": return 500;
		case "draw-terror": return 700;
		case "terror-effect": return 400;
		case "panic-scope": return 600;
		case "victims-advance": return 700;
		case "fire": return 900;
		case "spawn": return 700;
		case "draw-event": return 1200;
		case "gain-item": return 600;
		case "teleport-far": return 800;
		case "icons": return 0;
		case "end": return 500;
	}
	return 500;
}
function Ze(e, t, n) {
	let r = e.panicQueue.indexOf(t);
	return r < 0 ? !1 : (e.panicQueue.splice(r, 1), we(e, t, n), e.panicQueue.length === 0 && (e.pending = null, e.panicReturn === "killer" ? e.phase = "killer" : G(e, n)), !0);
}
//#endregion
//#region src/games/finalgirl/meta.ts
var q = {
	id: "finalgirl",
	tier: "alpha",
	mechanics: ["dice-rolling", "hand-management"],
	interactionTags: [],
	nameKey: "games.finalgirl.name",
	descKey: "games.finalgirl.desc",
	rulesKey: "games.finalgirl.rules",
	icon: "🔪",
	iconImg: "games/finalgirl.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/finalgirl/en.pdf" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#b03030",
	releasedAt: "2026-10-01",
	search: {
		py: "jue ming shao nv",
		init: "jmsn"
	},
	hotseat: "off"
}, J = t.enum([
	"woods-nw",
	"woods-n",
	"exit-n",
	"woods-ne",
	"shed",
	"cabins",
	"makeout",
	"cliff",
	"lake",
	"rec",
	"cove",
	"firepit",
	"dock",
	"junction",
	"swamp",
	"meadow",
	"exit-sw",
	"exit-se"
]), Y = t.enum([
	"walk",
	"focus",
	"weak-attack",
	"short-rest",
	"close-call",
	"guard",
	"search",
	"sprint",
	"distraction",
	"improvise",
	"furious-strike",
	"planning",
	"retaliate",
	"long-rest",
	"critical-blow"
]), X = t.enum([
	"bat",
	"bow",
	"axe",
	"bear-trap",
	"energy-drink",
	"fireworks",
	"first-aid",
	"flashlight",
	"knife",
	"lucky-dice",
	"rabbits-foot",
	"map",
	"boat-keys",
	"pills",
	"revolver",
	"pepper-spray",
	"trashcan-lid",
	"whistle"
]), Qe = t.enum([
	"boyfriend",
	"clingy-campers",
	"dark-waters",
	"deathwish",
	"fresh-meat",
	"girlfriend",
	"secret-tunnel",
	"star-crossed",
	"stubborn-kids",
	"vengeance"
]), $e = t.enum(["unholy-rage", "unholy-speed"]), et = t.enum([
	"blood-frenzy",
	"dark-obsession",
	"feed",
	"sledgehammer"
]), tt = t.enum([
	"bloodbath",
	"butcher-bloodlust",
	"dark-darker-darkest"
]), nt = t.enum(["laurie", "reiko"]), rt = t.enum([
	"capture-flag",
	"skinny-dipping",
	"treasure-hunt",
	"bonfire",
	"meditation"
]), it = t.object({
	girl: t.union([nt, t.literal("random")]).catch("random"),
	extreme: t.boolean().catch(!1),
	setup: t.union([rt, t.literal("random")]).catch("random")
}).default({
	girl: "random",
	extreme: !1,
	setup: "random"
}), at = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("play"),
		card: Y,
		weapon: X.optional()
	}),
	t.object({
		type: t.literal("rollConvert"),
		die: t.int().nonnegative(),
		discard: t.tuple([Y, Y])
	}),
	t.object({
		type: t.literal("rollReroll"),
		dice: t.array(t.int().nonnegative()),
		source: t.enum(["close-call", "lucky-dice"])
	}),
	t.object({ type: t.literal("rollDone") }),
	t.object({
		type: t.literal("choose"),
		option: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("move"),
		to: J,
		bring: t.array(t.int().nonnegative())
	}),
	t.object({ type: t.literal("moveDone") }),
	t.object({
		type: t.literal("save"),
		victims: t.array(t.int().nonnegative())
	}),
	t.object({
		type: t.literal("discardTime"),
		cards: t.array(Y)
	}),
	t.object({ type: t.literal("endPhase") }),
	t.object({
		type: t.literal("buy"),
		card: Y
	}),
	t.object({
		type: t.literal("react"),
		card: Y.optional()
	}),
	t.object({
		type: t.literal("reactItem"),
		item: X
	}),
	t.object({
		type: t.literal("useItem"),
		item: X
	}),
	t.object({
		type: t.literal("pickSpace"),
		space: J
	}),
	t.object({
		type: t.literal("pickPile"),
		space: J
	}),
	t.object({
		type: t.literal("pickVictim"),
		victim: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("pickCard"),
		card: Y
	}),
	t.object({
		type: t.literal("searchKeep"),
		keep: t.union([t.literal(0), t.literal(1)]),
		other: t.enum(["top", "bottom"])
	}),
	t.object({
		type: t.literal("rearrange"),
		hands: t.array(X),
		backpack: t.array(X)
	}),
	t.object({ type: t.literal("ultimate") })
]), ot = t.object({
	id: t.int().nonnegative(),
	space: J,
	special: t.enum([
		"boyfriend",
		"girlfriend",
		"damned"
	]).nullable()
}), st = t.object({
	revealed: t.boolean(),
	hp: t.int().min(0).max(3).nullable(),
	white: t.boolean()
}), ct = t.object({
	kind: t.enum([
		"roll",
		"reaction",
		"fail-choice",
		"search-pick",
		"tie",
		"panic",
		"item-choice",
		"pick-space",
		"pick-pile",
		"pick-card",
		"bat-power"
	]),
	data: t.record(t.string(), t.unknown()).optional()
}), lt = t.object({
	phase: t.enum([
		"action",
		"planning",
		"killer",
		"panic",
		"upkeep",
		"won",
		"lost"
	]),
	turn: t.int().min(1),
	time: t.number(),
	timeReset: t.number(),
	horror: t.int().min(0).max(9),
	bloodlust: t.int().min(0),
	extreme: t.boolean(),
	girl: t.object({
		id: nt,
		hp: t.int().nonnegative(),
		maxHp: t.int().positive(),
		space: J,
		ultimate: t.boolean(),
		saved: t.number(),
		saveGoal: t.number(),
		token: st
	}),
	killer: t.object({
		hp: t.int().nonnegative(),
		maxHp: t.int().positive(),
		space: J,
		token: st,
		minorPowers: t.array(t.object({
			id: $e,
			hp: t.number()
		})),
		darkPowers: t.array(et),
		finale: t.object({
			revealed: t.boolean(),
			id: tt.nullable()
		}),
		target: J.nullable()
	}),
	victims: t.array(ot),
	deadCount: t.number(),
	tableau: t.record(t.string(), t.number()),
	discardCount: t.number(),
	terrorLeft: t.number(),
	items: t.object({
		piles: t.record(t.string(), t.object({
			top: X.nullable(),
			count: t.number()
		})),
		hands: t.array(t.object({
			id: X,
			uses: t.number().nullable()
		})),
		backpack: t.array(t.object({
			id: X,
			uses: t.number().nullable()
		})),
		board: t.array(t.object({
			id: X,
			space: J
		}))
	}),
	event: Qe.nullable(),
	tunnel: t.tuple([J, J]).nullable(),
	pending: ct.nullable(),
	moveBudget: t.number(),
	lastRoll: t.object({
		dice: t.array(t.number()),
		context: t.string()
	}).nullable()
}), ut = t.object({
	hand: t.array(Y),
	peeked: t.array(t.string())
}), Z = {
	notNow: "games.finalgirl.errNotNow",
	badCard: "games.finalgirl.errBadCard",
	badOption: "games.finalgirl.errBadOption",
	badSpace: "games.finalgirl.errBadSpace",
	badVictim: "games.finalgirl.errBadVictim",
	noTime: "games.finalgirl.errNoTime",
	handFull: "games.finalgirl.errHandFull",
	notExit: "games.finalgirl.errNotExit"
}, dt = ["laurie", "reiko"], ft = [
	"capture-flag",
	"skinny-dipping",
	"treasure-hunt",
	"bonfire",
	"meditation"
];
function pt(e, t, n) {
	let r = t[0], i = [], a = {};
	a.rid = r, a.seed = n, a.rngCursor = 0, a.extreme = e.extreme, a.beatMs = 0, a.turn = 1, a.phase = "action";
	let o = e.girl === "random" ? N(a, dt)[0] : e.girl, s = e.setup === "random" ? N(a, ft)[0] : e.setup;
	a.setupId = s;
	let c = oe[s];
	a.girlStart = c.girlStart, a.killerStart = c.killerStart, a.girl = {
		id: o,
		hp: j[o].hp,
		space: c.girlStart,
		ultimate: !1,
		ultimateUsed: !1,
		token: {
			hp: 0,
			revealed: !1,
			white: !1
		}
	}, a.killer = {
		hp: 12,
		space: c.killerStart,
		token: {
			hp: 0,
			revealed: !1,
			white: !1
		}
	};
	let l = N(a, se);
	a.girl.token.hp = l[0], a.killer.token.hp = l[1], a.terrorDeck = N(a, re).slice(0, 10), a.terrorDiscard = [], a.darkPowerPile = N(a, ie), a.darkPowers = [], a.minorPowers = [], a.finale = N(a, ae)[0], a.finaleRevealed = !1;
	let u = N(a, Object.keys(A));
	a.items = [], S.forEach((e, t) => {
		for (let n = 0; n < 4; n += 1) {
			let r = u[t * 4 + n];
			a.items.push({
				id: r,
				where: "pile",
				pile: e,
				faceUp: n === 0,
				uses: A[r].uses ?? null,
				boardSpace: null
			});
		}
	});
	for (let e = S.length * 4; e < u.length; e += 1) {
		let t = u[e];
		a.items.push({
			id: t,
			where: "gone",
			pile: null,
			faceUp: !1,
			uses: A[t].uses ?? null,
			boardSpace: null
		});
	}
	a.victims = [], a.nextVictimId = 1;
	for (let [e, t] of Object.entries(c.victims)) for (let n = 0; n < (t ?? 0); n += 1) a.victims.push({
		id: a.nextVictimId,
		space: e,
		special: null
	}), a.nextVictimId += 1;
	return a.eventDeck = N(a, k), a.event = a.eventDeck.shift() ?? null, a.event && (i.push({
		kind: "event",
		data: { id: a.event }
	}), Ke(a, a.event, i)), a.time = e.extreme ? 5 : 6, a.timeBusted = !1, a.horror = 4, a.bloodlust = 0, a.deadCount = 0, a.savedCount = 0, a.rewardsTaken = [], a.hand = [...ne], a.tableau = { ...O }, a.discard = [], a.tunnel = null, a.pending = null, a.killerQueue = [], a.killerIcons = {
		knife: 0,
		boot: 0
	}, a.killerTarget = null, a.girlAttackedThisPhase = !1, a.obsessionFired = !1, a.horrorPerKill = 0, a.bonusBloodlustPerKill = 0, a.panicQueue = [], a.panicReturn = "panic", a.moveBudget = 0, a.moveAfterEnd = !1, a.victimsDiedThisTurn = !1, a.boyfriendDiedAtGirl = !1, a.nextRollBonus = 0, a.improviseNext = !1, a.improvisePhase = !1, a.whistleUsed = !1, a.flashlightUsed = !1, a.savesThisPhase = 0, a.phaseInterrupt = !1, a.peeked = [], a.lastRoll = null, i.push({
		kind: "setup",
		data: {
			girl: o,
			setup: s,
			extreme: e.extreme,
			victims: a.victims.length
		}
	}), {
		state: a,
		fx: i
	};
}
function mt(e, t) {
	if (e.phase === "killer") {
		e.pending || Ye(e, t);
		return;
	}
	if (!(e.phase !== "action" || e.pending)) {
		if (e.phaseInterrupt) {
			e.phaseInterrupt = !1, W(e, t);
			return;
		}
		e.timeBusted && W(e, t);
	}
}
function ht(e, t) {
	let n = j[e.girl.id], r = e.savedCount - 1;
	if (r < n.rewards.length) {
		e.rewardsTaken.push(r);
		let i = n.rewards[r];
		t.push({
			kind: "save-reward",
			data: {
				reward: i,
				slot: r
			}
		}), i === "horror-down" ? F(e, -1, t) : i === "time2" ? I(e, 2, t) : i === "heal1" ? R(e, 1, t) : i === "move1" ? e.moveBudget += 1 : i === "take-card2" ? e.pending = {
			kind: "pick-card",
			for: "cost2"
		} : i === "take-planning" && (e.pending = {
			kind: "pick-card",
			for: "planning"
		});
	} else I(e, 1, t);
	e.savedCount >= n.saveGoal && !e.girl.ultimate && (e.girl.ultimate = !0, t.push({
		kind: "ultimate-unlock",
		data: {}
	}));
}
function gt(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "killer" || e.pending || e.killerQueue.length === 0) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = qe(t);
		return Ye(t, n), {
			state: t,
			fx: n
		};
	}
	if (n.by !== e.rid) return { code: "games.finalgirl.errNotYourTurn" };
	if (e.phase === "won" || e.phase === "lost") return { code: Z.notNow };
	let r = structuredClone(e), i = [];
	return _t(r, t, i) || (mt(r, i), {
		state: r,
		fx: i
	});
}
function _t(e, t, n) {
	let r = e.pending;
	switch (t.type) {
		case "play": return e.phase !== "action" || r ? { code: Z.notNow } : e.hand.includes(t.card) ? De(e, t.card, t.weapon ?? null, n) : { code: Z.badCard };
		case "rollConvert": {
			if (!r || r.kind !== "roll") return { code: Z.notNow };
			let i = t.die;
			if (i >= r.dice.length || r.dice[i] < 3 || r.dice[i] > 4 || r.converted[i]) return { code: Z.badOption };
			let [a, o] = t.discard, s = e.hand.indexOf(a);
			if (s < 0) return { code: Z.badCard };
			let c = e.hand.indexOf(o, o === a ? s + 1 : 0);
			return c < 0 ? { code: Z.badCard } : (e.hand = e.hand.filter((e, t) => t !== s && t !== c), e.discard.push(a, o), r.converted[i] = !0, n.push({
				kind: "convert",
				data: {
					die: i,
					discard: [a, o]
				}
			}), null);
		}
		case "rollReroll": {
			if (!r || r.kind !== "roll") return { code: Z.notNow };
			let i = [...new Set(t.dice)];
			if (i.length === 0 || i.some((e) => e >= r.dice.length)) return { code: Z.badOption };
			if (t.source === "close-call") {
				if (r.closeCallUsed || !e.hand.includes("close-call")) return { code: Z.badCard };
				if (i.length === r.dice.length && r.dice.length > 1) {
					if (e.time < 2) return { code: Z.noTime };
					L(e, 2, n);
				} else if (i.length !== 1) return { code: Z.badOption };
				e.hand = e.hand.filter((e) => e !== "close-call"), e.discard.push("close-call"), r.closeCallUsed = !0;
			} else {
				let t = H(e, "lucky-dice");
				if (r.luckyUsed || t.where !== "hands" && t.where !== "backpack") return { code: Z.badCard };
				t.where = "gone", r.luckyUsed = !0;
			}
			let a = M(e, i.length);
			return i.forEach((e, t) => {
				r.dice[e] = a[t];
			}), n.push({
				kind: "reroll",
				data: {
					dice: i,
					values: a,
					source: t.source
				}
			}), null;
		}
		case "rollDone": return !r || r.kind !== "roll" ? { code: Z.notNow } : (Me(e, r, n), null);
		case "choose": return r ? vt(e, t.option, n) : { code: Z.notNow };
		case "move": return e.phase !== "action" || r ? { code: Z.notNow } : bt(e, t.to, t.bring, n);
		case "moveDone": return e.phase !== "action" || r ? { code: Z.notNow } : (e.moveBudget = 0, e.moveAfterEnd && W(e, n), null);
		case "save": return e.phase !== "action" || r ? { code: Z.notNow } : xt(e, t.victims, n);
		case "discardTime":
			if (e.phase !== "action" || r) return { code: Z.notNow };
			if (t.cards.length === 0 || !t.cards.every((t) => e.hand.includes(t))) return { code: Z.badCard };
			for (let n of t.cards) e.hand.splice(e.hand.indexOf(n), 1), e.discard.push(n);
			return I(e, t.cards.length, n), n.push({
				kind: "discard-time",
				data: { count: t.cards.length }
			}), null;
		case "endPhase":
			if (r) return { code: Z.notNow };
			if (e.phase === "action") return W(e, n), null;
			if (e.phase === "planning") {
				e.time = e.extreme ? 5 : 6, e.timeBusted = !1;
				for (let t of e.discard) e.tableau[t] += 1;
				return e.discard = [], n.push({
					kind: "time",
					data: {
						from: 0,
						to: e.time
					}
				}), Re(e, n), null;
			}
			return e.phase === "upkeep" ? (xe(e, n), null) : { code: Z.notNow };
		case "buy": {
			if (e.phase !== "planning" || r) return { code: Z.notNow };
			let i = D[t.card];
			return e.tableau[t.card] <= 0 ? { code: Z.badCard } : i.cost > e.time ? { code: Z.noTime } : e.hand.length >= 10 ? { code: Z.handFull } : (--e.tableau[t.card], e.hand.push(t.card), e.time -= i.cost, n.push({
				kind: "buy",
				data: {
					card: t.card,
					cost: i.cost
				}
			}), null);
		}
		case "react": {
			if (!r || r.kind !== "reaction") return { code: Z.notNow };
			if (!t.card) {
				e.pending = null;
				let t = r.dmg;
				return Ct(e, t, r.attacksLeft, n), null;
			}
			if (t.card !== "guard" && t.card !== "retaliate" || !e.hand.includes(t.card)) return { code: Z.badCard };
			e.hand = e.hand.filter((e) => e !== t.card), e.discard.push(t.card);
			let i = M(e, ye(e));
			return e.lastRoll = {
				dice: i,
				context: t.card
			}, e.pending = {
				kind: "roll",
				ctx: {
					kind: "reaction",
					card: t.card,
					dmg: r.dmg,
					attacksLeft: r.attacksLeft
				},
				dice: i,
				converted: i.map(() => !1),
				closeCallUsed: !1,
				luckyUsed: !1
			}, n.push({
				kind: "roll",
				data: {
					card: t.card,
					dice: i
				}
			}), null;
		}
		case "reactItem": return !r || r.kind !== "reaction" ? { code: Z.notNow } : St(e, r.dmg, r.attacksLeft, t.item, n);
		case "useItem": return e.phase !== "action" || r ? { code: Z.notNow } : Pe(e, t.item, n);
		case "pickSpace": return !r || r.kind !== "pick-space" || !r.options.includes(t.space) ? { code: Z.badSpace } : wt(e, r.for, t.space, n);
		case "pickPile": {
			if (!r || r.kind !== "pick-pile" || !r.options.includes(t.space)) return { code: Z.badSpace };
			let i = U(e, t.space)[0];
			return i ? (e.pending = null, ge(e, i, n), null) : { code: Z.badSpace };
		}
		case "pickVictim": return !r || r.kind !== "panic" ? { code: Z.notNow } : Ze(e, t.victim, n) ? null : { code: Z.badVictim };
		case "pickCard": return !r || r.kind !== "pick-card" ? { code: Z.notNow } : !(r.for === "cost2" ? D[t.card].cost <= 2 : t.card === "planning") || e.tableau[t.card] <= 0 ? { code: Z.badCard } : e.hand.length >= 10 ? { code: Z.handFull } : (--e.tableau[t.card], e.hand.push(t.card), e.pending = null, n.push({
			kind: "take-card",
			data: { card: t.card }
		}), null);
		case "searchKeep": {
			if (!r || r.kind !== "search-pick") return { code: Z.notNow };
			let i = H(e, r.top[t.keep]), a = H(e, r.top[1 - t.keep]);
			return e.pending = null, ge(e, i, n), t.other === "top" ? a.faceUp = !0 : (a.faceUp = !1, e.items = [...e.items.filter((e) => e !== a), a]), n.push({
				kind: "search-keep",
				data: {
					kept: i.id,
					other: a.id,
					place: t.other
				}
			}), null;
		}
		case "rearrange": return e.phase === "upkeep" ? Tt(e, t.hands, t.backpack) : { code: Z.notNow };
		case "ultimate": {
			if (e.phase !== "action" || r || e.girl.id !== "reiko" || !e.girl.ultimate || e.girl.ultimateUsed) return { code: Z.notNow };
			let t = P(e, e.girl.space, !0).get(e.killer.space) ?? 99;
			if (t < 1 || t > 2) return { code: "games.finalgirl.errOutOfRange" };
			let i = e.girl.space;
			return e.girl.space = e.killer.space, e.girl.ultimateUsed = !0, n.push({
				kind: "ultimate-dash",
				data: {
					from: i,
					to: e.killer.space
				}
			}), null;
		}
		default: return { code: Z.notNow };
	}
}
function vt(e, t, n) {
	let r = e.pending;
	if (!r) return { code: Z.notNow };
	switch (r.kind) {
		case "fail-choice": {
			let i = r.card;
			return Ae(e, i, t, n), null;
		}
		case "tie": {
			let i = r.options[t];
			if (!i) return { code: Z.badOption };
			if (e.pending = null, r.apply === "target") e.killerTarget = {
				space: i,
				isGirl: i === e.girl.space
			}, n.push({
				kind: "target",
				data: {
					space: i,
					girl: i === e.girl.space
				}
			});
			else {
				let t = e.killer.space;
				e.killer.space = i, n.push({
					kind: "teleport-killer",
					data: {
						from: t,
						to: i
					}
				});
			}
			return null;
		}
		case "bat-power": {
			e.pending = null;
			let r = e.minorPowers[t];
			return r && (e.minorPowers = e.minorPowers.filter((e) => e !== r), n.push({
				kind: "minor-power-remove",
				data: { id: r.id }
			})), null;
		}
		case "item-choice": {
			let i = r.options[t];
			return i ? yt(e, r, i, n) : { code: Z.badOption };
		}
		default: return { code: Z.notNow };
	}
}
function yt(e, t, n, r) {
	let i = () => {
		--t.remaining, t.remaining <= 0 && (e.pending = null);
	};
	switch (t.item) {
		case "energy-drink": return n === "time3" ? I(e, 3, r) : e.moveBudget += 1, i(), null;
		case "pills": return n === "horror-down" ? F(e, -1, r) : R(e, 2, r), i(), null;
		case "rabbits-foot": return n === "time2" ? I(e, 2, r) : n === "heal1" ? R(e, 1, r) : n === "horror-down" ? F(e, -1, r) : e.moveBudget += 1, i(), null;
		case "flashlight":
			if (n === "to-bottom" && e.terrorDeck.length > 0) {
				let t = e.terrorDeck.shift();
				t && e.terrorDeck.push(t);
			}
			return i(), null;
		case "map": {
			let a = t.piles[0], o = U(e, a)[0];
			return o && (n === "flip" ? o.faceUp = !o.faceUp : n === "remove" && (o.where = "gone", o.pile = null), r.push({
				kind: "map",
				data: {
					space: a,
					op: n,
					item: o.id
				}
			})), t.piles = t.piles.slice(1), i(), null;
		}
		default: return { code: Z.badOption };
	}
}
function bt(e, t, n, r) {
	if (t === "lake") return { code: Z.badSpace };
	let i = e.girl.space;
	if (!(C[i].includes(t) || e.tunnel !== null && (e.tunnel[0] === i && e.tunnel[1] === t || e.tunnel[1] === i && e.tunnel[0] === t))) return { code: Z.badSpace };
	let a = [...new Set(n)], o = a.map((t) => e.victims.find((e) => e.id === t));
	if (o.some((e) => !e || e.space !== i)) return { code: Z.badVictim };
	if (a.length > _e(e)) return { code: "games.finalgirl.errTooMany" };
	if (t === e.killer.space && o.some((e) => e && e.special !== "girlfriend")) return { code: Z.badVictim };
	if (e.moveBudget > 0) --e.moveBudget;
	else {
		if (e.time < 1) return { code: Z.noTime };
		L(e, 1, r);
	}
	e.girl.space = t;
	for (let e of o) e && (e.space = t);
	return r.push({
		kind: "move-girl",
		data: {
			from: i,
			to: t,
			bring: a
		}
	}), e.moveBudget === 0 && e.moveAfterEnd && W(e, r), null;
}
function xt(e, t, n) {
	if (x[e.girl.space].kind !== "exit") return { code: Z.notExit };
	let r = [...new Set(t)];
	if (r.length === 0) return { code: Z.badVictim };
	let i = r.map((t) => e.victims.find((e) => e.id === t));
	if (i.some((t) => !t || t.space !== e.girl.space)) return { code: Z.badVictim };
	for (let t of i) if (t && !ve(e, t, r)) return { code: "games.finalgirl.errDamnedLast" };
	for (let t of i) t && (e.victims = e.victims.filter((e) => e.id !== t.id), e.savedCount += 1, e.event === "clingy-campers" && e.savesThisPhase >= 1 && z(e, 1, n), e.savesThisPhase += 1, n.push({
		kind: "save",
		data: {
			id: t.id,
			special: t.special
		}
	}), ht(e, n));
	return null;
}
function St(e, t, n, r, i) {
	let a = H(e, r);
	return a.where === "hands" ? r === "pepper-spray" ? (a.where = "gone", e.pending = null, i.push({
		kind: "pepper-spray",
		data: {}
	}), e.phaseInterrupt = !0, null) : r === "trashcan-lid" ? a.uses === null || a.uses <= 0 ? { code: "games.finalgirl.errBadItem" } : (--a.uses, a.uses <= 0 && (a.where = "gone"), e.pending = null, i.push({
		kind: "trashcan-lid",
		data: { uses: a.uses }
	}), Ct(e, Math.max(0, t - 1), n, i), null) : { code: "games.finalgirl.errBadItem" } : { code: "games.finalgirl.errNotInHands" };
}
function Ct(e, t, n, r) {
	t > 0 && z(e, t, r), !(e.phase === "lost" || e.phase === "won" || e.phaseInterrupt) && n > 1 && (e.pending = {
		kind: "reaction",
		dmg: Se(e),
		attacksLeft: n - 1
	});
}
function wt(e, t, n, r) {
	if (t === "tunnel1") return e.tunnel = [n, n], e.pending = {
		kind: "pick-space",
		for: "tunnel2",
		options: S.filter((e) => e !== n)
	}, null;
	if (t === "tunnel2") return e.tunnel = [e.tunnel ? e.tunnel[0] : n, n], e.pending = null, r.push({
		kind: "tunnel",
		data: {
			a: e.tunnel[0],
			b: e.tunnel[1]
		}
	}), null;
	if (t === "fireworks") {
		let t = H(e, "fireworks");
		return t.where = "board", t.boardSpace = n, e.pending = null, r.push({
			kind: "item-place",
			data: {
				id: "fireworks",
				space: n
			}
		}), null;
	}
	let i = e.girl.space, a = B(e, i).map((e) => e.id);
	e.girl.space = n;
	for (let t of e.victims) a.includes(t.id) && (t.space = n);
	return e.pending = null, r.push({
		kind: "boat",
		data: {
			from: i,
			to: n,
			bring: a
		}
	}), null;
}
function Tt(e, t, n) {
	let r = e.items.filter((e) => e.where === "hands" || e.where === "backpack"), i = new Set(t), a = new Set(n);
	if (i.size !== t.length || a.size !== n.length) return { code: "games.finalgirl.errBadItem" };
	for (let e of t) if (a.has(e)) return { code: "games.finalgirl.errBadItem" };
	if (r.length !== t.length + n.length || !r.every((e) => i.has(e.id) || a.has(e.id))) return { code: "games.finalgirl.errBadItem" };
	let o = 0;
	for (let e of t) {
		let t = A[e];
		if (t.hands === 0) return { code: "games.finalgirl.errBadItem" };
		o += t.hands;
	}
	if (o > 2) return { code: "games.finalgirl.errTooMany" };
	for (let e of r) e.where = i.has(e.id) ? "hands" : "backpack";
	return null;
}
function Et(e) {
	let t = e.pending;
	if (!t) return null;
	switch (t.kind) {
		case "roll": return {
			kind: "roll",
			data: {
				ctx: t.ctx.kind === "card" || t.ctx.kind === "reaction" ? t.ctx.card : "rabbits-foot",
				ctxKind: t.ctx.kind,
				dice: t.dice,
				converted: t.converted,
				closeCallUsed: t.closeCallUsed,
				luckyUsed: t.luckyUsed
			}
		};
		case "reaction": return {
			kind: "reaction",
			data: {
				dmg: t.dmg,
				attacksLeft: t.attacksLeft
			}
		};
		case "fail-choice": return {
			kind: "fail-choice",
			data: { card: t.card }
		};
		case "search-pick": return {
			kind: "search-pick",
			data: {
				space: t.space,
				top: t.top
			}
		};
		case "tie": return {
			kind: "tie",
			data: {
				options: t.options,
				apply: t.apply
			}
		};
		case "panic": return {
			kind: "panic",
			data: { queue: [...e.panicQueue] }
		};
		case "item-choice": return {
			kind: "item-choice",
			data: {
				item: t.item,
				options: t.options,
				remaining: t.remaining,
				piles: t.piles
			}
		};
		case "pick-space": return {
			kind: "pick-space",
			data: {
				for: t.for,
				options: t.options
			}
		};
		case "pick-pile": return {
			kind: "pick-pile",
			data: { options: t.options }
		};
		case "pick-card": return {
			kind: "pick-card",
			data: { for: t.for }
		};
		case "bat-power": return {
			kind: "bat-power",
			data: { options: e.minorPowers.map((e) => e.id) }
		};
	}
}
function Dt(e, t) {
	let n = {};
	for (let t of S) {
		let r = U(e, t);
		n[t] = {
			top: r[0]?.faceUp ? r[0].id : null,
			count: r.length
		};
	}
	let r = (e) => ({
		revealed: e.revealed,
		hp: e.revealed ? e.hp : null,
		white: e.white
	}), i = (t) => e.items.filter((e) => e.where === t).map((e) => ({
		id: e.id,
		uses: e.uses
	})), a = e.items.filter((e) => e.where === "board" && e.boardSpace).map((e) => ({
		id: e.id,
		space: e.boardSpace
	}));
	return {
		public: {
			phase: e.phase,
			turn: e.turn,
			time: e.time,
			timeReset: e.extreme ? 5 : 6,
			horror: e.horror,
			bloodlust: e.bloodlust,
			extreme: e.extreme,
			girl: {
				id: e.girl.id,
				hp: e.girl.hp,
				maxHp: j[e.girl.id].hp,
				space: e.girl.space,
				ultimate: e.girl.ultimate,
				saved: e.savedCount,
				saveGoal: j[e.girl.id].saveGoal,
				token: r(e.girl.token)
			},
			killer: {
				hp: e.killer.hp,
				maxHp: 12,
				space: e.killer.space,
				token: r(e.killer.token),
				minorPowers: e.minorPowers.map((e) => ({
					id: e.id,
					hp: e.hp
				})),
				darkPowers: [...e.darkPowers],
				finale: {
					revealed: e.finaleRevealed,
					id: e.finaleRevealed ? e.finale : null
				},
				target: e.killerTarget ? e.killerTarget.space : null
			},
			victims: e.victims.map((e) => ({
				id: e.id,
				space: e.space,
				special: e.special
			})),
			deadCount: e.deadCount,
			tableau: { ...e.tableau },
			discardCount: e.discard.length,
			terrorLeft: e.terrorDeck.length,
			items: {
				piles: n,
				hands: i("hands"),
				backpack: i("backpack"),
				board: a
			},
			event: e.event,
			tunnel: e.tunnel,
			pending: Et(e),
			moveBudget: e.moveBudget,
			lastRoll: e.lastRoll
		},
		private: {
			hand: t === e.rid ? [...e.hand] : [],
			peeked: t === e.rid ? [...e.peeked] : []
		}
	};
}
function Ot(e) {
	return e.phase === "won" ? {
		phase: "done",
		winner: [e.rid],
		ranking: [e.rid]
	} : e.phase === "lost" ? {
		phase: "done",
		winner: [],
		ranking: [e.rid]
	} : { phase: e.phase };
}
function kt(e) {
	return e.phase === "killer" && !e.pending && e.killerQueue.length > 0 ? e.beatMs : null;
}
var At = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: q,
	schemas: {
		action: at,
		publicView: lt,
		privateView: ut,
		config: it
	},
	setup: pt,
	reduce: gt,
	viewFor: Dt,
	status: Ot,
	nextTickIn: kt
}, Q = (e) => `./games/finalgirl/${e}`, jt = {
	bat: "🏏",
	bow: "🏹",
	axe: "🪓",
	"bear-trap": "🪤",
	"energy-drink": "🥤",
	fireworks: "🎆",
	"first-aid": "🩹",
	flashlight: "🔦",
	knife: "🔪",
	"lucky-dice": "🎲",
	"rabbits-foot": "🐇",
	map: "🗺️",
	"boat-keys": "🛥️",
	pills: "💊",
	revolver: "🔫",
	"pepper-spray": "🌶️",
	"trashcan-lid": "🪣",
	whistle: "📯"
}, Mt = {
	1: [[50, 50]],
	2: [[28, 28], [72, 72]],
	3: [
		[26, 26],
		[50, 50],
		[74, 74]
	],
	4: [
		[30, 30],
		[70, 30],
		[30, 70],
		[70, 70]
	],
	5: [
		[28, 28],
		[72, 28],
		[50, 50],
		[28, 72],
		[72, 72]
	],
	6: [
		[30, 26],
		[70, 26],
		[30, 50],
		[70, 50],
		[30, 74],
		[70, 74]
	]
};
function Nt({ value: e, size: t = 40, dim: n = !1 }) {
	let r = e >= 5 ? {
		bg: "var(--color-done-soft)",
		bd: "var(--color-done-ink)",
		pip: "var(--color-done-ink)"
	} : e >= 3 ? {
		bg: "var(--color-warn-soft)",
		bd: "var(--color-warn-ink)",
		pip: "var(--color-warn-ink)"
	} : {
		bg: "var(--color-paper)",
		bd: "var(--color-ink)",
		pip: "var(--color-ink)"
	};
	return /* @__PURE__ */ m("svg", {
		width: t,
		height: t,
		viewBox: "0 0 100 100",
		style: n ? { opacity: .45 } : void 0,
		children: [/* @__PURE__ */ p("rect", {
			x: "4",
			y: "4",
			width: "92",
			height: "92",
			rx: "13",
			fill: r.bg,
			stroke: r.bd,
			strokeWidth: "6"
		}), (Mt[e] ?? []).map(([e, t], n) => /* @__PURE__ */ p("circle", {
			cx: e,
			cy: t,
			r: "10",
			fill: r.pip
		}, n))]
	});
}
function Pt({ x: e, y: t, id: n, r = 4.6, white: i = !1 }) {
	let a = `fg-girl-${n}`;
	return /* @__PURE__ */ m("g", {
		transform: `translate(${e} ${t})`,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ p("defs", { children: /* @__PURE__ */ p("clipPath", {
				id: a,
				children: /* @__PURE__ */ p("circle", { r: r - .45 })
			}) }),
			/* @__PURE__ */ p("circle", {
				r: r + .5,
				fill: i ? "var(--color-surface)" : "var(--color-danger-deep)",
				stroke: "var(--color-ink)",
				strokeWidth: "0.65"
			}),
			/* @__PURE__ */ p("image", {
				href: Q(`people/${n}.webp`),
				x: -r + .45,
				y: -r + .45,
				width: (r - .45) * 2,
				height: (r - .45) * 2,
				preserveAspectRatio: "xMidYMid slice",
				clipPath: `url(#${a})`
			}),
			/* @__PURE__ */ p("circle", {
				r: r - .4,
				fill: "none",
				stroke: i ? "var(--color-surface)" : "var(--color-danger-deep)",
				strokeWidth: "0.9"
			}),
			/* @__PURE__ */ p("circle", {
				cx: r * .72,
				cy: r * .72,
				r: 1.5,
				fill: "var(--color-danger-deep)",
				stroke: "var(--color-surface)",
				strokeWidth: "0.3"
			})
		]
	});
}
function Ft({ x: e, y: t, r: n = 5.2, white: r = !1 }) {
	return /* @__PURE__ */ m("g", {
		transform: `translate(${e} ${t})`,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ p("defs", { children: /* @__PURE__ */ p("clipPath", {
				id: "fg-killer-portrait",
				children: /* @__PURE__ */ p("circle", { r: n - .45 })
			}) }),
			/* @__PURE__ */ p("circle", {
				r: n + .5,
				fill: r ? "var(--color-surface)" : "var(--color-ink)",
				stroke: "var(--color-danger-deep)",
				strokeWidth: "0.75"
			}),
			/* @__PURE__ */ p("image", {
				href: Q("people/hans.webp"),
				x: -n + .45,
				y: -n + .45,
				width: (n - .45) * 2,
				height: (n - .45) * 2,
				preserveAspectRatio: "xMidYMid slice",
				clipPath: "url(#fg-killer-portrait)"
			}),
			/* @__PURE__ */ p("circle", {
				r: n - .4,
				fill: "none",
				stroke: r ? "var(--color-surface)" : "var(--color-ink)",
				strokeWidth: "0.9"
			}),
			/* @__PURE__ */ p("path", {
				d: `M ${n * .45} ${n * .45} l 1.8 -1.8 0.9 0.9 -1.8 1.8 Z`,
				fill: "var(--color-danger-deep)",
				stroke: "var(--color-surface)",
				strokeWidth: "0.2"
			})
		]
	});
}
function It({ x: e, y: t, special: n, r = 2.6 }) {
	let i = n === "boyfriend" ? "#3d9bd4" : n === "girlfriend" ? "#e0526e" : n === "damned" ? "#7d5fd3" : "#b8b2a6";
	return /* @__PURE__ */ m("g", {
		transform: `translate(${e} ${t})`,
		children: [
			/* @__PURE__ */ p("circle", {
				r,
				fill: "#fdf6e8",
				stroke: i,
				strokeWidth: "0.65"
			}),
			/* @__PURE__ */ p("circle", {
				cy: -r * .3,
				r: r * .32,
				fill: "#8a7460"
			}),
			/* @__PURE__ */ p("path", {
				d: `M ${-r * .5} ${r * .62} Q 0 ${-r * .05} ${r * .5} ${r * .62} Z`,
				fill: "#8a7460"
			})
		]
	});
}
function Lt({ id: e }) {
	return /* @__PURE__ */ p("g", {
		fill: "none",
		stroke: "var(--color-ink)",
		strokeWidth: "2.2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: e === "walk" || e === "sprint" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M17 49 L42 31 M32 31 H42 V41" }), /* @__PURE__ */ p("path", { d: "M17 55 L25 49 M32 53 L40 47" })] }) : e === "weak-attack" || e === "furious-strike" || e === "critical-blow" || e === "retaliate" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M19 53 L41 31 M22 31 L42 51" }), /* @__PURE__ */ p("path", { d: "M17 55 L25 47 M39 53 L45 59" })] }) : e === "guard" || e === "close-call" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M31 29 L44 34 V44 Q42 55 31 60 Q20 55 18 44 V34 Z" }), /* @__PURE__ */ p("path", { d: "M25 44 L30 49 L38 39" })] }) : e === "search" || e === "distraction" || e === "improvise" || e === "planning" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
			cx: "28",
			cy: "40",
			r: "11"
		}), /* @__PURE__ */ p("path", { d: "M36 48 L46 58 M23 40 H33 M28 35 V45" })] }) : /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p("circle", {
				cx: "31",
				cy: "43",
				r: "12"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "31",
				cy: "43",
				r: "4"
			}),
			/* @__PURE__ */ p("path", { d: "M31 26 V31 M31 55 V60 M14 43 H19 M43 43 H48" })
		] })
	});
}
function Rt({ id: e, name: t, cost: n, playable: r = !0 }) {
	return /* @__PURE__ */ m("svg", {
		width: 62,
		height: 84,
		viewBox: "0 0 62 84",
		style: r ? void 0 : { opacity: .48 },
		"aria-label": t,
		children: [
			/* @__PURE__ */ p("rect", {
				x: "2",
				y: "3",
				width: "58",
				height: "79",
				rx: "4",
				fill: "var(--color-ink)"
			}),
			/* @__PURE__ */ p("rect", {
				x: "1",
				y: "1",
				width: "58",
				height: "79",
				rx: "4",
				fill: "var(--color-paper)",
				stroke: "var(--color-ink)",
				strokeWidth: "1.8"
			}),
			/* @__PURE__ */ p("path", {
				d: "M5 23 H55 M5 66 H55",
				stroke: "var(--color-ink)",
				strokeWidth: "0.8",
				opacity: "0.5"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12",
				r: "8",
				fill: n === 0 ? "var(--color-done-ink)" : "var(--color-warn-ink)",
				stroke: "var(--color-ink)",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ p("text", {
				x: "12",
				y: "15",
				textAnchor: "middle",
				fontSize: "10",
				fontWeight: "800",
				fill: "var(--color-surface)",
				children: n
			}),
			/* @__PURE__ */ p("path", {
				d: "M42 8 L50 8 M42 12 L54 12 M42 16 L50 16",
				stroke: "var(--color-ink)",
				strokeWidth: "0.8"
			}),
			/* @__PURE__ */ p(Lt, { id: e }),
			/* @__PURE__ */ p("text", {
				x: "30",
				y: "76",
				textAnchor: "middle",
				fontSize: "8.8",
				fontWeight: "800",
				fill: "var(--color-ink)",
				textLength: t.length > 6 ? 48 : void 0,
				lengthAdjust: "spacingAndGlyphs",
				children: t
			})
		]
	});
}
function zt({ id: e, name: t, uses: n, size: r = 30 }) {
	return /* @__PURE__ */ m("svg", {
		width: r,
		height: r * 1.3,
		viewBox: "0 0 30 39",
		children: [
			/* @__PURE__ */ p("rect", {
				x: "1.5",
				y: "2",
				width: "27",
				height: "36",
				rx: "2",
				fill: "var(--color-ink)"
			}),
			/* @__PURE__ */ p("rect", {
				x: "0.8",
				y: "0.8",
				width: "27",
				height: "36",
				rx: "2",
				fill: "var(--color-paper)",
				stroke: "var(--color-ink)",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ p("text", {
				x: "15",
				y: "18",
				textAnchor: "middle",
				fontSize: "13",
				children: jt[e]
			}),
			/* @__PURE__ */ p("image", {
				href: Q(`items/${e}.webp`),
				x: "2.5",
				y: "2.5",
				width: "25",
				height: "24",
				preserveAspectRatio: "xMidYMid slice"
			}),
			/* @__PURE__ */ p("rect", {
				x: "1",
				y: "27",
				width: "26.5",
				height: "9.6",
				fill: "var(--color-paper)"
			}),
			/* @__PURE__ */ p("text", {
				x: "14.5",
				y: "34",
				textAnchor: "middle",
				fontSize: "5.8",
				fontWeight: "800",
				fill: "var(--color-ink)",
				textLength: t.length > 5 ? 24 : void 0,
				lengthAdjust: "spacingAndGlyphs",
				children: t
			}),
			n !== null && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
				cx: "24",
				cy: "7",
				r: "4.6",
				fill: "var(--color-warn-soft)",
				stroke: "var(--color-ink)",
				strokeWidth: "0.8"
			}), /* @__PURE__ */ p("text", {
				x: "24",
				y: "9.4",
				textAnchor: "middle",
				fontSize: "6.4",
				fontWeight: "bold",
				fill: "var(--color-ink)",
				children: n
			})] })
		]
	});
}
var $ = (e) => e === "cliff" ? {
	x: 62,
	y: 23
} : x[e].pos, Bt = {
	"cliff|swamp": [{
		x: 84,
		y: 28
	}],
	"cove|dock": [{
		x: 37,
		y: 61
	}, {
		x: 48,
		y: 66
	}],
	"dock|swamp": [{
		x: 68,
		y: 67
	}, {
		x: 88,
		y: 58
	}]
};
function Vt(e, t) {
	let n = Bt[`${e}|${t}`] ?? [];
	return [
		$(e),
		...n,
		$(t)
	];
}
function Ht(e) {
	if (e.length === 0) return "";
	let t = [...e].sort((e, t) => e - t), n = [], r = t[0], i = t[0];
	for (let e = 1; e <= t.length; e += 1) {
		if (t[e] === i + 1) {
			i = t[e];
			continue;
		}
		n.push(r === i ? `${r}` : `${r}-${i}`), r = t[e], i = t[e];
	}
	return n.join("·");
}
var Ut = [];
for (let e of Object.keys(C)) for (let t of C[e]) e < t && Ut.push({
	a: e,
	b: t
});
var Wt = {
	exit: {
		ring: "var(--color-done-ink)",
		mark: "E"
	},
	search: {
		ring: "var(--color-warn-ink)",
		mark: "S"
	},
	normal: {
		ring: "var(--color-ink)",
		mark: ""
	}
};
function Gt({ pub: e, nameOf: t, clickableSpaces: n, selectedSpace: r, selectedVictims: i, selectableVictimSpaces: a, moveCost: o, onSpace: s, onVictimGroup: c }) {
	let l = /* @__PURE__ */ new Map();
	for (let t of e.victims) {
		let e = l.get(t.space) ?? [];
		e.push(t), l.set(t.space, e);
	}
	let u = /* @__PURE__ */ new Map();
	for (let t of e.items.board) {
		let e = u.get(t.space) ?? [];
		e.push(t.id), u.set(t.space, e);
	}
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 100 72",
		preserveAspectRatio: "xMidYMid meet",
		className: "select-none",
		role: "group",
		"aria-label": "Camp Happy Trails map",
		children: [
			/* @__PURE__ */ p("image", {
				href: Q("camp-map.webp"),
				x: "0",
				y: "0",
				width: 100,
				height: 72,
				preserveAspectRatio: "xMidYMid slice"
			}),
			/* @__PURE__ */ p("rect", {
				x: "0.5",
				y: "0.5",
				width: "99",
				height: "71",
				rx: "1.5",
				fill: "none",
				stroke: "var(--color-ink)",
				strokeWidth: "1"
			}),
			Ut.map(({ a: t, b: n }) => {
				let i = Vt(t, n), a = i[0], o = i[i.length - 1], s = i[1], c = i[i.length - 2], l = a.x + (s.x - a.x) * .36, u = a.y + (s.y - a.y) * .36, d = o.x + (c.x - o.x) * .36, f = o.y + (c.y - o.y) * .36, h = Ht(w[t].map((e, t) => e === n ? t + 1 : 0).filter(Boolean)), ee = Ht(w[n].map((e, n) => e === t ? n + 1 : 0).filter(Boolean)), g = i.map((e, t) => `${t === 0 ? "M" : "L"}${e.x} ${e.y}`).join(" "), _ = r !== null && (t === e.girl.space && n === r || n === e.girl.space && t === r);
				return /* @__PURE__ */ m("g", { children: [
					/* @__PURE__ */ p("path", {
						d: g,
						fill: "none",
						stroke: "var(--color-ink)",
						strokeWidth: _ ? 2.4 : 1.8,
						strokeLinecap: "round",
						strokeLinejoin: "round"
					}),
					/* @__PURE__ */ p("path", {
						d: g,
						fill: "none",
						stroke: _ ? "var(--color-danger-deep)" : "var(--color-paper)",
						strokeWidth: _ ? 1.5 : .9,
						strokeLinecap: "round",
						strokeLinejoin: "round"
					}),
					(e.phase === "panic" || e.pending?.kind === "panic") && h && /* @__PURE__ */ p("text", {
						x: l,
						y: u - 1.1,
						textAnchor: "middle",
						fontSize: "2.1",
						fontWeight: "800",
						fill: "var(--color-ink)",
						paintOrder: "stroke",
						stroke: "var(--color-paper)",
						strokeWidth: "1.1",
						children: h
					}),
					(e.phase === "panic" || e.pending?.kind === "panic") && ee && /* @__PURE__ */ p("text", {
						x: d,
						y: f - 1.1,
						textAnchor: "middle",
						fontSize: "2.1",
						fontWeight: "800",
						fill: "var(--color-ink)",
						paintOrder: "stroke",
						stroke: "var(--color-paper)",
						strokeWidth: "1.1",
						children: ee
					})
				] }, `${t}|${n}`);
			}),
			e.tunnel && /* @__PURE__ */ p("line", {
				x1: $(e.tunnel[0]).x,
				y1: $(e.tunnel[0]).y,
				x2: $(e.tunnel[1]).x,
				y2: $(e.tunnel[1]).y,
				stroke: "var(--color-info)",
				strokeWidth: "1.2",
				strokeDasharray: "2 1.4",
				strokeLinecap: "round"
			}),
			Object.keys(x).filter((e) => e !== "lake").map((i) => {
				let { x: a, y: c } = $(i), l = x[i].kind, u = Wt[l] ?? Wt.normal, d = n.includes(i), f = e.killer.target === i, h = r === i, ee = e.girl.space === i || e.killer.space === i, g = t(i), _ = l !== "normal" || d || f || ee, v = Math.min(18, Math.max(7, g.length * 1.45)), y = Math.max(v / 2 + 1, Math.min(a, 99 - v / 2));
				return /* @__PURE__ */ m("g", { children: [
					f && /* @__PURE__ */ p("circle", {
						cx: a,
						cy: c,
						r: "7.2",
						fill: "none",
						stroke: "var(--color-danger-deep)",
						strokeWidth: "1.5",
						strokeDasharray: "2 1"
					}),
					d && /* @__PURE__ */ p("circle", {
						cx: a,
						cy: c,
						r: "7.4",
						fill: "var(--color-warn-soft)",
						fillOpacity: "0.65",
						stroke: h ? "var(--color-danger-deep)" : "var(--color-warn-ink)",
						strokeWidth: h ? 1.4 : 1.1
					}),
					/* @__PURE__ */ p("circle", {
						cx: a,
						cy: c,
						r: "4.4",
						fill: "var(--color-paper)",
						stroke: u.ring,
						strokeWidth: l === "normal" ? 1 : 1.4
					}),
					u.mark ? /* @__PURE__ */ p("text", {
						x: a,
						y: c + 1.2,
						textAnchor: "middle",
						fontSize: "3.6",
						fontWeight: "900",
						fill: u.ring,
						children: u.mark
					}) : /* @__PURE__ */ p("circle", {
						cx: a,
						cy: c,
						r: "1.15",
						fill: "var(--color-ink)"
					}),
					d && o !== null && /* @__PURE__ */ p("text", {
						x: a + 5.5,
						y: c - 4.4,
						textAnchor: "middle",
						fontSize: "3",
						fontWeight: "900",
						fill: "var(--color-danger-deep)",
						paintOrder: "stroke",
						stroke: "var(--color-paper)",
						strokeWidth: "0.8",
						children: o
					}),
					_ && /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("rect", {
						x: y - v / 2,
						y: c + 5.7,
						width: v,
						height: "4.5",
						rx: "0.8",
						fill: "var(--color-paper)",
						stroke: "var(--color-ink)",
						strokeWidth: "0.4"
					}), /* @__PURE__ */ p("text", {
						x: y,
						y: c + 9,
						textAnchor: "middle",
						fontSize: "2.5",
						fontWeight: "800",
						fill: "var(--color-ink)",
						textLength: g.length > 8 ? v - 1 : void 0,
						lengthAdjust: "spacingAndGlyphs",
						children: g
					})] }),
					d && /* @__PURE__ */ p("circle", {
						cx: a,
						cy: c,
						r: "6.4",
						fill: "transparent",
						className: "cursor-pointer",
						role: "button",
						"aria-label": g,
						tabIndex: 0,
						onClick: () => s(i),
						onKeyDown: (e) => {
							(e.key === "Enter" || e.key === " ") && s(i);
						}
					})
				] }, i);
			}),
			Object.entries(e.items.piles).map(([e, t]) => {
				if (t.count <= 0) return null;
				let { x: n, y: r } = $(e);
				return /* @__PURE__ */ m("g", {
					transform: `translate(${n + 6.4} ${r - 6.4})`,
					children: [
						/* @__PURE__ */ p("rect", {
							x: "-2.2",
							y: "-2.8",
							width: "6.2",
							height: "7.6",
							rx: "0.5",
							fill: "var(--color-ink)"
						}),
						/* @__PURE__ */ p("rect", {
							x: "-2.9",
							y: "-3.5",
							width: "6.2",
							height: "7.6",
							rx: "0.5",
							fill: "var(--color-paper)",
							stroke: "var(--color-ink)",
							strokeWidth: "0.5"
						}),
						t.top ? /* @__PURE__ */ p("image", {
							href: Q(`items/${t.top}.webp`),
							x: "-2.5",
							y: "-3.1",
							width: "5.4",
							height: "5.4"
						}) : /* @__PURE__ */ p("text", {
							y: "0.7",
							textAnchor: "middle",
							fontSize: "3.2",
							fontWeight: "900",
							fill: "var(--color-ink)",
							children: "?"
						}),
						/* @__PURE__ */ p("text", {
							x: "0.2",
							y: "3.5",
							textAnchor: "middle",
							fontSize: "2.4",
							fontWeight: "800",
							fill: "var(--color-ink)",
							children: t.count
						})
					]
				}, `pile-${e}`);
			}),
			[...u.entries()].map(([e, t]) => {
				let { x: n, y: r } = $(e);
				return /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("rect", {
					x: n - 8.6,
					y: r - 9,
					width: "6",
					height: "6",
					rx: "0.7",
					fill: "var(--color-paper)",
					stroke: "var(--color-ink)",
					strokeWidth: "0.5"
				}), /* @__PURE__ */ p("image", {
					href: Q(`items/${t[0]}.webp`),
					x: n - 8.3,
					y: r - 8.7,
					width: "5.4",
					height: "5.4"
				})] }, `bi-${e}`);
			}),
			[...l.entries()].map(([e, n]) => {
				let { x: r, y: o } = $(e), s = o - 7.5, l = n.filter((e) => i.includes(e.id)).length;
				return /* @__PURE__ */ m("g", { children: [
					l > 0 && /* @__PURE__ */ p("circle", {
						cx: r,
						cy: s,
						r: "4.2",
						fill: "none",
						stroke: "var(--color-info)",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ p(It, {
						x: r,
						y: s,
						special: n.length === 1 ? n[0].special : null,
						r: 3.1
					}),
					/* @__PURE__ */ p("circle", {
						cx: r + 3.1,
						cy: s + 2.8,
						r: "2.2",
						fill: "var(--color-paper)",
						stroke: "var(--color-ink)",
						strokeWidth: "0.5"
					}),
					/* @__PURE__ */ p("text", {
						x: r + 3.1,
						y: s + 3.65,
						textAnchor: "middle",
						fontSize: "2.2",
						fontWeight: "900",
						fill: "var(--color-ink)",
						children: l > 0 ? `${l}/${n.length}` : n.length
					}),
					a.includes(e) && /* @__PURE__ */ p("circle", {
						cx: r,
						cy: s,
						r: "6.8",
						fill: "transparent",
						className: "cursor-pointer",
						role: "button",
						"aria-label": `${t(e)} ${n.length}`,
						tabIndex: 0,
						onClick: () => c(e),
						onKeyDown: (t) => {
							(t.key === "Enter" || t.key === " ") && c(e);
						}
					})
				] }, `victims-${e}`);
			}),
			(() => {
				let t = $(e.girl.space), n = $(e.killer.space), r = e.girl.space === e.killer.space;
				return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(Pt, {
					x: t.x - (r ? 4 : 0),
					y: t.y + .2,
					id: e.girl.id,
					white: e.girl.token.white
				}), /* @__PURE__ */ p(Ft, {
					x: n.x + (r ? 4.4 : 0),
					y: n.y + .2,
					white: e.killer.token.white
				})] });
			})()
		]
	});
}
//#endregion
//#region src/games/finalgirl/view-player.tsx
var Kt = {
	"woods-nw": "games.finalgirl.spaceWoodsNw",
	"woods-n": "games.finalgirl.spaceWoodsN",
	"exit-n": "games.finalgirl.spaceExitN",
	"woods-ne": "games.finalgirl.spaceWoodsNe",
	shed: "games.finalgirl.spaceShed",
	cabins: "games.finalgirl.spaceCabins",
	makeout: "games.finalgirl.spaceMakeout",
	cliff: "games.finalgirl.spaceCliff",
	lake: "games.finalgirl.spaceLake",
	rec: "games.finalgirl.spaceRec",
	cove: "games.finalgirl.spaceCove",
	firepit: "games.finalgirl.spaceFirepit",
	dock: "games.finalgirl.spaceDock",
	junction: "games.finalgirl.spaceJunction",
	swamp: "games.finalgirl.spaceSwamp",
	meadow: "games.finalgirl.spaceMeadow",
	"exit-sw": "games.finalgirl.spaceExitSw",
	"exit-se": "games.finalgirl.spaceExitSe"
}, qt = {
	walk: "games.finalgirl.cardWalk",
	focus: "games.finalgirl.cardFocus",
	"weak-attack": "games.finalgirl.cardWeakAttack",
	"short-rest": "games.finalgirl.cardShortRest",
	"close-call": "games.finalgirl.cardCloseCall",
	guard: "games.finalgirl.cardGuard",
	search: "games.finalgirl.cardSearch",
	sprint: "games.finalgirl.cardSprint",
	distraction: "games.finalgirl.cardDistraction",
	improvise: "games.finalgirl.cardImprovise",
	"furious-strike": "games.finalgirl.cardFuriousStrike",
	planning: "games.finalgirl.cardPlanning",
	retaliate: "games.finalgirl.cardRetaliate",
	"long-rest": "games.finalgirl.cardLongRest",
	"critical-blow": "games.finalgirl.cardCriticalBlow"
}, Jt = {
	bat: "games.finalgirl.itemBat",
	bow: "games.finalgirl.itemBow",
	axe: "games.finalgirl.itemAxe",
	"bear-trap": "games.finalgirl.itemBearTrap",
	"energy-drink": "games.finalgirl.itemEnergyDrink",
	fireworks: "games.finalgirl.itemFireworks",
	"first-aid": "games.finalgirl.itemFirstAid",
	flashlight: "games.finalgirl.itemFlashlight",
	knife: "games.finalgirl.itemKnife",
	"lucky-dice": "games.finalgirl.itemLuckyDice",
	"rabbits-foot": "games.finalgirl.itemRabbitsFoot",
	map: "games.finalgirl.itemMap",
	"boat-keys": "games.finalgirl.itemBoatKeys",
	pills: "games.finalgirl.itemPills",
	revolver: "games.finalgirl.itemRevolver",
	"pepper-spray": "games.finalgirl.itemPepperSpray",
	"trashcan-lid": "games.finalgirl.itemTrashcanLid",
	whistle: "games.finalgirl.itemWhistle"
}, Yt = {
	boyfriend: "games.finalgirl.eventBoyfriend",
	"clingy-campers": "games.finalgirl.eventClingyCampers",
	"dark-waters": "games.finalgirl.eventDarkWaters",
	deathwish: "games.finalgirl.eventDeathwish",
	"fresh-meat": "games.finalgirl.eventFreshMeat",
	girlfriend: "games.finalgirl.eventGirlfriend",
	"secret-tunnel": "games.finalgirl.eventSecretTunnel",
	"star-crossed": "games.finalgirl.eventStarCrossed",
	"stubborn-kids": "games.finalgirl.eventStubbornKids",
	vengeance: "games.finalgirl.eventVengeance"
}, Xt = {
	"blood-frenzy": "games.finalgirl.powerBloodFrenzy",
	"dark-obsession": "games.finalgirl.powerDarkObsession",
	feed: "games.finalgirl.powerFeed",
	sledgehammer: "games.finalgirl.powerSledgehammer",
	"unholy-rage": "games.finalgirl.terrorUnholyRage",
	"unholy-speed": "games.finalgirl.terrorUnholySpeed"
}, Zt = {
	bloodbath: "games.finalgirl.finaleBloodbath",
	"butcher-bloodlust": "games.finalgirl.finaleButcherBloodlust",
	"dark-darker-darkest": "games.finalgirl.finaleDarkDarkerDarkest"
}, Qt = {
	time2: "games.finalgirl.optTime2",
	time3: "games.finalgirl.optTime3",
	heal1: "games.finalgirl.optHeal1",
	heal2: "games.finalgirl.optHeal2",
	"horror-down": "games.finalgirl.optHorrorDown",
	move1: "games.finalgirl.optMove1",
	flip: "games.finalgirl.optFlip",
	remove: "games.finalgirl.optRemove",
	skip: "games.finalgirl.optSkip",
	"keep-top": "games.finalgirl.optKeepTop",
	"to-bottom": "games.finalgirl.optToBottom"
}, $t = {
	action: "games.finalgirl.phaseAction",
	planning: "games.finalgirl.phasePlanning",
	killer: "games.finalgirl.phaseKiller",
	panic: "games.finalgirl.phasePanic",
	upkeep: "games.finalgirl.phaseUpkeep"
};
function en(e, t, n) {
	let r = [];
	for (let i of e.items.hands) {
		let e = A[i.id].weapon;
		e && !e.standalone && (e.onlyCard && e.onlyCard !== t || n >= e.minRange && n <= e.maxRange && r.push(i.id));
	}
	return r;
}
function tn(e, t) {
	if (e === t) return 0;
	let n = /* @__PURE__ */ new Map([[e, 0]]), r = [e];
	for (; r.length > 0;) {
		let e = r.shift();
		for (let i of C[e]) if (!(i === "lake" || n.has(i))) {
			if (n.set(i, n.get(e) + 1), i === t) return n.get(i);
			r.push(i);
		}
	}
	return 99;
}
function nn(e) {
	let t = e.public, n = e.private, i = l(), c = e.send, { ref: h } = s("board"), { ref: ee } = s("stats"), { ref: g } = s("girl"), { ref: _ } = s("killer"), v = a(null), y = n?.hand ?? [], b = t.phase === "won" || t.phase === "lost" ? null : t.pending, S = b?.data ?? {}, [w, T] = o([]), [E, ne] = o(null), [O, re] = o(!1), [k, ie] = o([]), [ae, j] = o(null), [oe, se] = o(null), [M, N] = o([]), [P, ce] = o(null), [F, I] = o(null), L = `${t.phase}|${t.turn}|${b?.kind ?? "-"}|${t.moveBudget}`, [le, R] = o(L);
	le !== L && (R(L), T([]), ne(null), re(!1), ie([]), j(null), se(null), N([]), ce(null), I(null));
	let ue = t.victims.filter((e) => e.space === t.girl.space), de = x[t.girl.space].kind === "exit", z = t.phase === "action" && !b, fe = tn(t.girl.space, t.killer.space), B = z && (t.moveBudget > 0 || t.time > 0) ? C[t.girl.space].filter((e) => e !== "lake") : [], pe = t.event === "stubborn-kids" ? 1 : 2 + +!!t.items.hands.some((e) => e.id === "whistle");
	r(() => {
		let e = v.current;
		if (!e) return;
		let n = () => {
			if (!window.matchMedia("(orientation: landscape) and (max-height: 480px)").matches) return;
			let n = t.phase === "killer" || t.phase === "panic" ? t.killer.space : t.girl.space, r = e.querySelector("svg");
			r && (e.scrollTop = Math.max(0, x[n].pos.y / 72 * r.getBoundingClientRect().height - e.clientHeight / 2));
		}, r = new ResizeObserver(n);
		return r.observe(e), n(), () => r.disconnect();
	}, [
		t.girl.space,
		t.killer.space,
		t.phase
	]);
	let V;
	V = b?.kind === "pick-space" || b?.kind === "pick-pile" || b?.kind === "tie" ? S.options ?? [] : B;
	let H = b?.kind === "panic" ? [...new Set(t.victims.filter((e) => (S.queue ?? []).includes(e.id)).map((e) => e.space))] : de && z || E ? [t.girl.space] : [], me = (e) => {
		if (b?.kind === "pick-space") {
			c({
				type: "pickSpace",
				space: e
			});
			return;
		}
		if (b?.kind === "pick-pile") {
			c({
				type: "pickPile",
				space: e
			});
			return;
		}
		if (b?.kind === "tie") {
			let t = (S.options ?? []).indexOf(e);
			t >= 0 && c({
				type: "choose",
				option: t
			});
			return;
		}
		B.includes(e) && (ne({
			to: e,
			sel: []
		}), I(null));
	}, he = (e) => {
		if (b?.kind === "panic") {
			(S.queue ?? []).includes(e) && c({
				type: "pickVictim",
				victim: e
			});
			return;
		}
		if (E) {
			let n = ue.find((t) => t.id === e);
			if (!n || E.to === t.killer.space && n.special !== "girlfriend") return;
			ne({
				to: E.to,
				sel: E.sel.includes(e) ? E.sel.filter((t) => t !== e) : E.sel.length < pe ? [...E.sel, e] : E.sel
			});
			return;
		}
		de && z && T((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
	}, ge = (e) => {
		if (D[e].attack && en(t, e, fe).length > 0) {
			j(e);
			return;
		}
		c({
			type: "play",
			card: e
		});
	}, U = "accent", _e = i($t[t.phase] ?? "games.finalgirl.phaseAction");
	b ? (U = "accent", _e = b.kind === "pick-space" ? i({
		tunnel1: "games.finalgirl.pickSpaceTunnel1",
		tunnel2: "games.finalgirl.pickSpaceTunnel2",
		fireworks: "games.finalgirl.pickSpaceFireworks",
		boat: "games.finalgirl.pickSpaceBoat"
	}[String(S.for)] ?? "games.finalgirl.pickSpaceTunnel1") : b.kind === "reaction" ? i("games.finalgirl.reactPrompt", { dmg: Number(S.dmg ?? 0) }) : i({
		roll: "games.finalgirl.rollDone",
		reaction: "games.finalgirl.reactPrompt",
		"fail-choice": "games.finalgirl.failChoicePrompt",
		"search-pick": "games.finalgirl.searchKeepPrompt",
		tie: "games.finalgirl.tiePrompt",
		panic: "games.finalgirl.panicHint",
		"item-choice": "games.finalgirl.optSkip",
		"pick-space": "games.finalgirl.pickSpaceTunnel1",
		"pick-pile": "games.finalgirl.pickPilePrompt",
		"pick-card": "games.finalgirl.pickCardPrompt",
		"bat-power": "games.finalgirl.batPowerPrompt"
	}[b.kind] ?? "games.finalgirl.phaseAction")) : t.phase === "killer" ? (U = "warn", _e = i("games.finalgirl.killerHint")) : t.phase === "panic" ? (U = "warn", _e = i("games.finalgirl.panicHint")) : t.phase === "planning" ? _e = i("games.finalgirl.planningHint") : t.phase === "upkeep" && (_e = i("games.finalgirl.upkeepHint"));
	let ve = (e, t) => /* @__PURE__ */ m("div", {
		className: "fg-hp-pips",
		"aria-label": `${e}/${t}`,
		children: [Array.from({ length: Math.min(t, 6) }, (t, n) => /* @__PURE__ */ p("i", { "data-filled": n < e }, n)), t > 6 && /* @__PURE__ */ m("span", {
			className: "text-[10px] font-bold",
			children: ["+", t - 6]
		})]
	}), ye = (e, t, n, r) => /* @__PURE__ */ m("div", {
		className: "fg-track",
		style: { "--fg-accent": r },
		children: [/* @__PURE__ */ m("div", {
			className: "fg-track-top",
			children: [/* @__PURE__ */ p("span", { children: e }), /* @__PURE__ */ p("strong", { children: t })]
		}), /* @__PURE__ */ p("div", {
			className: "fg-track-pips",
			"aria-label": `${e} ${t}/${n}`,
			children: Array.from({ length: n }, (e, n) => /* @__PURE__ */ p("i", { "data-filled": n < t }, n))
		})]
	}), be;
	if (t.phase === "action") be = /* @__PURE__ */ m("div", {
		className: "flex h-full flex-col gap-1",
		children: [
			/* @__PURE__ */ m("div", {
				className: "fg-action-row",
				children: [
					t.moveBudget > 0 && /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-quiet min-h-11 flex-none px-3 text-sm",
						onClick: () => c({ type: "moveDone" }),
						children: [
							i("games.finalgirl.moveDone"),
							"(",
							i("games.finalgirl.moveBudget", { n: t.moveBudget }),
							")"
						]
					}),
					de && ue.length > 0 && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base min-h-11 flex-none px-3 text-sm",
						disabled: w.length === 0,
						onClick: () => {
							c({
								type: "save",
								victims: w
							}), T([]);
						},
						children: i("games.finalgirl.saveConfirm", { n: w.length })
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: `min-h-11 flex-none px-3 text-sm ${O ? "btn-base" : "btn-quiet"}`,
						onClick: () => {
							re(!O), ie([]);
						},
						children: i("games.finalgirl.discardTime")
					}),
					O && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base min-h-11 flex-none px-3 text-sm",
						disabled: k.length === 0,
						onClick: () => {
							c({
								type: "discardTime",
								cards: k.map((e) => y[e])
							}), re(!1), ie([]);
						},
						children: i("games.finalgirl.discardConfirm", { n: k.length })
					}),
					t.girl.ultimate && t.girl.id === "reiko" && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet min-h-11 flex-none px-3 text-sm",
						onClick: () => c({ type: "ultimate" }),
						children: i("games.finalgirl.useUltimate")
					}),
					/* @__PURE__ */ p("span", { className: "flex-1" }),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base fg-primary min-h-11 flex-none px-4 text-sm",
						onClick: () => c({ type: "endPhase" }),
						children: i("games.finalgirl.endActionPhase")
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "fg-item-row",
				children: [t.items.hands.length + t.items.backpack.length === 0 && /* @__PURE__ */ p("span", {
					className: "fg-gear-empty",
					children: i("games.finalgirl.gearEmpty")
				}), [...t.items.hands, ...t.items.backpack].map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "fg-item-card",
					title: i(Jt[e.id]),
					onClick: () => c({
						type: "useItem",
						item: e.id
					}),
					children: /* @__PURE__ */ p(zt, {
						id: e.id,
						name: i(Jt[e.id]),
						uses: e.uses,
						size: 26
					})
				}, e.id))]
			}),
			/* @__PURE__ */ p("div", {
				className: "fg-hand-row",
				children: y.map((e, t) => {
					let n = O && k.includes(t);
					return /* @__PURE__ */ p("button", {
						type: "button",
						className: "fg-hand-card",
						"data-selected": n,
						onClick: () => {
							O ? ie((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]) : ge(e);
						},
						children: /* @__PURE__ */ p(Rt, {
							id: e,
							name: i(qt[e]),
							cost: D[e].cost
						})
					}, `${e}-${t}`);
				})
			})
		]
	});
	else if (t.phase === "planning") be = /* @__PURE__ */ m("div", {
		className: "flex h-full flex-col gap-1",
		children: [/* @__PURE__ */ m("div", {
			className: "fg-action-row",
			children: [
				/* @__PURE__ */ m("span", {
					className: "text-xs text-paper",
					children: [
						i("games.finalgirl.tableau"),
						" · ",
						i("games.finalgirl.time"),
						" ",
						t.time
					]
				}),
				/* @__PURE__ */ p("span", { className: "flex-1" }),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base fg-primary min-h-11 flex-none px-4 text-sm",
					onClick: () => c({ type: "endPhase" }),
					children: i("games.finalgirl.endPlanning")
				})
			]
		}), /* @__PURE__ */ p("div", {
			className: "fg-hand-row",
			children: Object.keys(D).filter((e) => (t.tableau[e] ?? 0) > 0).map((e) => /* @__PURE__ */ m("button", {
				type: "button",
				className: "fg-hand-card relative",
				disabled: D[e].cost > t.time || y.length >= 10,
				onClick: () => c({
					type: "buy",
					card: e
				}),
				children: [/* @__PURE__ */ p(Rt, {
					id: e,
					name: i(qt[e]),
					cost: D[e].cost,
					playable: D[e].cost <= t.time
				}), /* @__PURE__ */ m("span", {
					className: "absolute -top-1 -right-1 rounded-full bg-ink px-1.5 text-[10px] font-bold text-surface",
					children: ["×", t.tableau[e]]
				})]
			}, e))
		})]
	});
	else if (t.phase === "upkeep") {
		let e = [...t.items.hands.map((e) => ({
			...e,
			inHand: !0
		})), ...t.items.backpack.map((e) => ({
			...e,
			inHand: !1
		}))];
		be = /* @__PURE__ */ m("div", {
			className: "flex h-full flex-col gap-1",
			children: [/* @__PURE__ */ m("div", {
				className: "fg-action-row",
				children: [
					/* @__PURE__ */ p("span", {
						className: "text-xs text-paper",
						children: i("games.finalgirl.upkeepHint")
					}),
					/* @__PURE__ */ p("span", { className: "flex-1" }),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base fg-primary min-h-11 flex-none px-4 text-sm",
						onClick: () => c({ type: "endPhase" }),
						children: i("games.finalgirl.endUpkeep")
					})
				]
			}), /* @__PURE__ */ m("div", {
				className: "fg-hand-row",
				children: [e.length === 0 && /* @__PURE__ */ m("div", {
					className: "fg-phase-dossier",
					children: [/* @__PURE__ */ p("span", {
						className: "fg-phase-mark",
						children: i("games.finalgirl.phaseUpkeep")
					}), /* @__PURE__ */ p("strong", { children: i("games.finalgirl.gearEmpty") })]
				}), e.map((t) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "fg-item-card",
					"data-selected": t.inHand,
					onClick: () => {
						let n = e.filter((e) => e.id === t.id ? !t.inHand : e.inHand).map((e) => e.id), r = e.filter((e) => e.id === t.id ? t.inHand : !e.inHand).map((e) => e.id);
						c({
							type: "rearrange",
							hands: n,
							backpack: r
						});
					},
					children: /* @__PURE__ */ p(zt, {
						id: t.id,
						name: i(Jt[t.id]),
						uses: t.uses,
						size: 30
					})
				}, t.id))]
			})]
		});
	} else be = /* @__PURE__ */ m("div", {
		className: "fg-phase-dossier",
		children: [
			/* @__PURE__ */ p("span", {
				className: "fg-phase-mark",
				children: i($t[t.phase] ?? "games.finalgirl.phaseKiller")
			}),
			/* @__PURE__ */ p("strong", { children: i(t.phase === "killer" ? "games.finalgirl.killerHint" : "games.finalgirl.panicHint") }),
			/* @__PURE__ */ m("div", {
				className: "fg-phase-facts",
				children: [/* @__PURE__ */ m("span", { children: [
					i("games.finalgirl.killerTarget"),
					" · ",
					t.killer.target ? i(Kt[t.killer.target]) : "—"
				] }), /* @__PURE__ */ m("span", { children: [
					i("games.finalgirl.victimsLeft"),
					" · ",
					t.victims.length
				] })]
			})
		]
	});
	let W = null, G = (e) => /* @__PURE__ */ p("div", {
		className: "fg-overlay pointer-events-auto mx-2 mb-2 p-3",
		style: { "--fg-accent": q.accent },
		children: e
	});
	if (b?.kind === "roll") {
		let e = S.dice ?? [], n = S.converted ?? [], r = y.includes("close-call") && !S.closeCallUsed, a = t.items.hands.some((e) => e.id === "lucky-dice") && !S.luckyUsed;
		W = G(/* @__PURE__ */ m("div", {
			className: "flex flex-col gap-2",
			children: [
				/* @__PURE__ */ m("div", {
					className: "fg-roll-heading",
					children: [/* @__PURE__ */ p("strong", { children: i("games.finalgirl.rollTray") }), /* @__PURE__ */ p("span", { children: i("games.finalgirl.rollLegend") })]
				}),
				/* @__PURE__ */ p("div", {
					className: "fg-dice-tray",
					children: e.map((e, t) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "fg-die-button",
						"data-selected": oe === t,
						disabled: e !== 3 && e !== 4 || !!n[t],
						"aria-label": i("games.finalgirl.rollDie", {
							n: t + 1,
							value: e
						}),
						onClick: () => se(oe === t ? null : t),
						children: /* @__PURE__ */ p(Nt, {
							value: e,
							dim: n[t]
						})
					}, t))
				}),
				oe !== null && /* @__PURE__ */ m("div", {
					className: "flex items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
					children: [y.map((e, t) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "flex-none cursor-pointer",
						style: M.includes(t) ? {
							outline: `3px solid ${q.accent}`,
							borderRadius: 8
						} : void 0,
						onClick: () => N((e) => e.includes(t) ? e.filter((e) => e !== t) : e.length < 2 ? [...e, t] : e),
						children: /* @__PURE__ */ p(Rt, {
							id: e,
							name: i(qt[e]),
							cost: D[e].cost
						})
					}, `cc-${e}-${t}`)), /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base min-h-11 flex-none px-3 text-sm",
						disabled: M.length !== 2,
						onClick: () => {
							let [e, t] = [...M].sort((e, t) => t - e);
							c({
								type: "rollConvert",
								die: oe,
								discard: [y[e], y[t]]
							}), se(null), N([]);
						},
						children: i("games.finalgirl.rollConvert")
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: "flex items-center gap-2",
					children: [
						r && /* @__PURE__ */ m("button", {
							type: "button",
							className: "btn-quiet min-h-11 flex-1 px-3 text-sm",
							onClick: () => {
								se(null), N([]), c({
									type: "rollReroll",
									dice: e.map((e, t) => e < 5 ? t : -1).filter((e) => e >= 0),
									source: "close-call"
								});
							},
							children: [
								i(qt["close-call"]),
								"·",
								i("games.finalgirl.rollReroll")
							]
						}),
						a && /* @__PURE__ */ p("button", {
							type: "button",
							className: "btn-quiet min-h-11 flex-1 px-3 text-sm",
							onClick: () => {
								se(null), N([]), c({
									type: "rollReroll",
									dice: e.map((e, t) => e < 5 ? t : -1).filter((e) => e >= 0),
									source: "lucky-dice"
								});
							},
							children: i("games.finalgirl.rerollLucky")
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "btn-base min-h-11 flex-1 px-3 text-sm",
							onClick: () => c({ type: "rollDone" }),
							children: i("games.finalgirl.rollDone")
						})
					]
				})
			]
		}));
	} else if (b?.kind === "reaction") {
		let e = y.filter((e) => e === "guard" || e === "retaliate"), n = t.items.hands.filter((e) => e.id === "pepper-spray" || e.id === "trashcan-lid");
		W = G(/* @__PURE__ */ m("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ p("div", {
				className: "text-center text-sm font-bold",
				children: i("games.finalgirl.reactPrompt", { dmg: Number(S.dmg ?? 0) })
			}), /* @__PURE__ */ m("div", {
				className: "flex items-center gap-2",
				children: [
					e.map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet min-h-11 flex-1 px-3 text-sm",
						onClick: () => c({
							type: "react",
							card: e
						}),
						children: i(qt[e])
					}, e)),
					n.map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet min-h-11 flex-1 px-3 text-sm",
						onClick: () => c({
							type: "reactItem",
							item: e.id
						}),
						children: i(Jt[e.id])
					}, e.id)),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base min-h-11 flex-1 px-3 text-sm",
						onClick: () => c({ type: "react" }),
						children: i("games.finalgirl.reactTake")
					})
				]
			})]
		}));
	} else if (b?.kind === "fail-choice") W = G(/* @__PURE__ */ m("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ m("div", {
			className: "text-center text-sm font-bold",
			children: [
				i("games.finalgirl.failChoicePrompt"),
				"·",
				i(qt[S.card] ?? "games.finalgirl.cardWalk")
			]
		}), /* @__PURE__ */ m("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: "btn-base min-h-11 flex-1 px-3 text-sm",
				onClick: () => c({
					type: "choose",
					option: 0
				}),
				children: i("games.finalgirl.failOptA")
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: "btn-base min-h-11 flex-1 px-3 text-sm",
				onClick: () => c({
					type: "choose",
					option: 1
				}),
				children: i("games.finalgirl.failOptB")
			})]
		})]
	}));
	else if (b?.kind === "item-choice") {
		let e = S.options ?? [];
		W = G(/* @__PURE__ */ m("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ p("div", {
				className: "text-center text-sm font-bold",
				children: i(Jt[S.item] ?? "games.finalgirl.itemPills")
			}), /* @__PURE__ */ p("div", {
				className: "flex items-center gap-2",
				children: e.map((e, t) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base min-h-11 flex-1 px-3 text-sm",
					onClick: () => c({
						type: "choose",
						option: t
					}),
					children: i(Qt[e] ?? "games.finalgirl.optSkip")
				}, e))
			})]
		}));
	} else if (b?.kind === "bat-power") {
		let e = S.options ?? [];
		W = G(/* @__PURE__ */ m("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ p("div", {
				className: "text-center text-sm font-bold",
				children: i("games.finalgirl.batPowerPrompt")
			}), /* @__PURE__ */ m("div", {
				className: "flex items-center gap-2",
				children: [e.map((e, t) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-quiet min-h-11 flex-1 px-3 text-sm",
					onClick: () => c({
						type: "choose",
						option: t
					}),
					children: i(Xt[e] ?? "games.finalgirl.powerFeed")
				}, e)), /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base min-h-11 flex-1 px-3 text-sm",
					onClick: () => c({
						type: "choose",
						option: e.length
					}),
					children: i("games.finalgirl.batPowerSkip")
				})]
			})]
		}));
	} else if (b?.kind === "search-pick") {
		let e = S.top ?? [];
		W = G(/* @__PURE__ */ m("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ p("div", {
				className: "text-center text-sm font-bold",
				children: i(P === null ? "games.finalgirl.searchKeepPrompt" : "games.finalgirl.searchOtherPrompt")
			}), P === null ? /* @__PURE__ */ p("div", {
				className: "flex items-center justify-center gap-2",
				children: e.map((e, t) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "cursor-pointer",
					onClick: () => ce(t),
					children: /* @__PURE__ */ p(zt, {
						id: e,
						name: i(Jt[e]),
						uses: A[e].uses ?? null,
						size: 40
					})
				}, e))
			}) : /* @__PURE__ */ m("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base min-h-11 flex-1 px-3 text-sm",
					onClick: () => c({
						type: "searchKeep",
						keep: P,
						other: "top"
					}),
					children: i("games.finalgirl.searchTop")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base min-h-11 flex-1 px-3 text-sm",
					onClick: () => c({
						type: "searchKeep",
						keep: P,
						other: "bottom"
					}),
					children: i("games.finalgirl.searchBottom")
				})]
			})]
		}));
	} else if (b?.kind === "pick-card") {
		let e = S.for === "cost2";
		W = G(/* @__PURE__ */ m("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ p("div", {
				className: "text-center text-sm font-bold",
				children: i("games.finalgirl.pickCardPrompt")
			}), /* @__PURE__ */ p("div", {
				className: "flex items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
				children: Object.keys(D).filter((n) => (t.tableau[n] ?? 0) > 0 && (!e || D[n].cost <= 2)).map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "flex-none cursor-pointer",
					onClick: () => c({
						type: "pickCard",
						card: e
					}),
					children: /* @__PURE__ */ p(Rt, {
						id: e,
						name: i(qt[e]),
						cost: D[e].cost
					})
				}, e))
			})]
		}));
	} else if (F) {
		let e = t.victims.filter((e) => e.space === F), n = S.queue ?? [], r = (e) => e.special === "boyfriend" ? i("games.finalgirl.victimBoyfriend") : e.special === "girlfriend" ? i("games.finalgirl.victimGirlfriend") : e.special === "damned" ? i("games.finalgirl.victimDamned") : i("games.finalgirl.victimUnit", { n: e.id + 1 });
		W = G(/* @__PURE__ */ m("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ m("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ m("span", {
					className: "text-sm font-bold",
					children: [
						i(Kt[F]),
						" · ",
						i("games.finalgirl.pickVictim")
					]
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-quiet min-h-11 px-3 text-sm",
					onClick: () => I(null),
					children: i("games.finalgirl.victimClose")
				})]
			}), /* @__PURE__ */ p("div", {
				className: "fg-victim-list flex max-h-40 flex-col gap-1 overflow-y-auto",
				children: e.map((e) => {
					let a = w.includes(e.id) || (E?.sel.includes(e.id) ?? !1), o = b?.kind === "panic" ? n.includes(e.id) : E ? F === t.girl.space && (E.to !== t.killer.space || e.special === "girlfriend") : de && z && F === t.girl.space;
					return /* @__PURE__ */ m("button", {
						type: "button",
						disabled: !o,
						className: `fg-victim-option btn-base min-h-11 justify-between px-3 text-sm ${a ? "fg-primary" : ""}`,
						onClick: () => he(e.id),
						children: [/* @__PURE__ */ p("span", { children: r(e) }), /* @__PURE__ */ p("span", { children: a ? `✓ ${i("games.finalgirl.victimSelected")}` : `#${e.id + 1}` })]
					}, e.id);
				})
			})]
		}));
	} else if (ae) {
		let e = en(t, ae, fe);
		W = G(/* @__PURE__ */ m("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ p("div", {
				className: "text-center text-sm font-bold",
				children: i("games.finalgirl.pickWeapon")
			}), /* @__PURE__ */ m("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-quiet min-h-11 flex-1 px-3 text-sm",
					onClick: () => {
						c({
							type: "play",
							card: ae
						}), j(null);
					},
					children: i("games.finalgirl.weaponNone")
				}), e.map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base min-h-11 flex-1 px-3 text-sm",
					onClick: () => {
						c({
							type: "play",
							card: ae,
							weapon: e
						}), j(null);
					},
					children: i(Jt[e])
				}, e))]
			})]
		}));
	} else E && (W = G(/* @__PURE__ */ m("div", {
		className: "flex flex-col gap-2",
		children: [
			/* @__PURE__ */ m("div", {
				className: "text-center text-sm font-bold",
				children: [
					i(Kt[E.to]),
					" · ",
					t.moveBudget > 0 ? i("games.finalgirl.moveFree") : i("games.finalgirl.moveCost", { n: 1 })
				]
			}),
			ue.length > 0 && /* @__PURE__ */ p("button", {
				type: "button",
				className: "btn-quiet min-h-11 px-3 text-sm",
				onClick: () => I(t.girl.space),
				children: i("games.finalgirl.bringPrompt")
			}),
			/* @__PURE__ */ m("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-quiet min-h-11 flex-1 px-3 text-sm",
					onClick: () => ne(null),
					children: i("games.finalgirl.cancelAction")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base fg-primary min-h-11 flex-1 px-3 text-sm",
					onClick: () => {
						c({
							type: "move",
							to: E.to,
							bring: E.sel
						}), ne(null);
					},
					children: E.sel.length > 0 ? i("games.finalgirl.moveBring", { n: E.sel.length }) : i("games.finalgirl.moveGo")
				})]
			})
		]
	})));
	return /* @__PURE__ */ p(u, {
		adaptive: !0,
		className: "fg-screen",
		banner: /* @__PURE__ */ p(d, {
			tone: U,
			text: _e,
			chip: i("games.finalgirl.turnChip", { n: t.turn }),
			accent: q.accent
		}),
		overlay: W,
		scroll: !1,
		children: /* @__PURE__ */ m("div", {
			className: "fg-layout",
			style: { "--fg-accent": q.accent },
			children: [
				/* @__PURE__ */ m("div", {
					className: "fg-portraits",
					children: [/* @__PURE__ */ m("div", {
						ref: g,
						className: "fg-portrait",
						children: [/* @__PURE__ */ p("img", {
							src: Q(`people/${t.girl.id}.webp`),
							alt: ""
						}), /* @__PURE__ */ m("div", {
							className: "fg-portrait-body",
							children: [
								/* @__PURE__ */ p("div", {
									className: "fg-portrait-name",
									children: i(t.girl.id === "laurie" ? "games.finalgirl.girlLaurie" : "games.finalgirl.girlReiko")
								}),
								/* @__PURE__ */ m("div", {
									className: "flex items-center justify-between gap-1 text-xs font-bold text-ink",
									children: [/* @__PURE__ */ p("span", { children: i("games.finalgirl.hp") }), /* @__PURE__ */ m("span", {
										className: "font-mono tabular-nums",
										children: [
											t.girl.hp,
											"/",
											t.girl.maxHp
										]
									})]
								}),
								ve(t.girl.hp, t.girl.maxHp)
							]
						})]
					}), /* @__PURE__ */ m("div", {
						ref: _,
						className: "fg-portrait",
						style: { "--fg-accent": "var(--color-warn-ink)" },
						children: [/* @__PURE__ */ p("img", {
							src: Q("people/hans.webp"),
							alt: ""
						}), /* @__PURE__ */ m("div", {
							className: "fg-portrait-body",
							children: [
								/* @__PURE__ */ p("div", {
									className: "fg-portrait-name",
									children: i("games.finalgirl.killerHans")
								}),
								/* @__PURE__ */ m("div", {
									className: "flex items-center justify-between gap-1 text-xs font-bold text-ink",
									children: [/* @__PURE__ */ p("span", { children: i("games.finalgirl.hp") }), /* @__PURE__ */ m("span", {
										className: "font-mono tabular-nums",
										children: [
											t.killer.hp,
											"/",
											t.killer.maxHp
										]
									})]
								}),
								ve(t.killer.hp, t.killer.maxHp)
							]
						})]
					})]
				}),
				/* @__PURE__ */ m("div", {
					ref: h,
					className: "fg-map-frame",
					children: [
						/* @__PURE__ */ m("div", {
							className: "fg-map-heading",
							children: [/* @__PURE__ */ p("span", { children: i("games.finalgirl.mapTitle") }), /* @__PURE__ */ p("span", { children: V.length > 0 ? i("games.finalgirl.mapMoves", { n: V.length }) : i($t[t.phase] ?? "games.finalgirl.phaseAction") })]
						}),
						/* @__PURE__ */ p("div", {
							ref: v,
							className: "fg-map-body",
							children: /* @__PURE__ */ p(Gt, {
								pub: t,
								nameOf: (e) => i(Kt[e]),
								clickableSpaces: V,
								selectedSpace: E?.to ?? null,
								selectedVictims: [...w, ...E?.sel ?? []],
								selectableVictimSpaces: H,
								moveCost: z ? t.moveBudget > 0 ? 0 : 1 : null,
								onSpace: me,
								onVictimGroup: I
							})
						}),
						/* @__PURE__ */ m("div", {
							className: "fg-map-footer",
							children: [
								/* @__PURE__ */ p("span", { children: i("games.finalgirl.girlPosition") }),
								/* @__PURE__ */ p("strong", { children: i(Kt[t.girl.space]) }),
								/* @__PURE__ */ p("span", { children: "·" }),
								/* @__PURE__ */ p("span", { children: i("games.finalgirl.killerTarget") }),
								/* @__PURE__ */ p("strong", { children: t.killer.target ? i(Kt[t.killer.target]) : "—" })
							]
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					ref: ee,
					className: "fg-tracks",
					children: [
						ye(i("games.finalgirl.time"), t.time, 12, "var(--color-warn)"),
						ye(i("games.finalgirl.horror"), t.horror, 9, q.accent),
						ye(i("games.finalgirl.bloodlust"), t.bloodlust, 10, q.accent)
					]
				}),
				/* @__PURE__ */ m("div", {
					className: "fg-case-note",
					children: [
						/* @__PURE__ */ m("span", { children: [
							i("games.finalgirl.saved"),
							" ",
							t.girl.saved,
							"/",
							t.girl.saveGoal,
							" · ",
							i("games.finalgirl.dead"),
							" ",
							t.deadCount
						] }),
						/* @__PURE__ */ p("i", { className: "fg-note-divider" }),
						/* @__PURE__ */ p("span", { children: i("games.finalgirl.terrorLeft", { n: t.terrorLeft }) }),
						/* @__PURE__ */ p("i", { className: "fg-note-divider" }),
						/* @__PURE__ */ m("span", { children: [te(t.horror, t.extreme), " 🎲"] }),
						t.event && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("i", { className: "fg-note-divider" }), /* @__PURE__ */ p("span", { children: i(Yt[t.event]) })] }),
						t.killer.finale.revealed && t.killer.finale.id && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("i", { className: "fg-note-divider" }), /* @__PURE__ */ p("span", { children: i(Zt[t.killer.finale.id]) })] }),
						t.killer.darkPowers.map((e) => /* @__PURE__ */ p("span", { children: i(Xt[e]) }, e))
					]
				}),
				/* @__PURE__ */ p("div", {
					className: "fg-actions",
					style: { "--fg-accent": q.accent },
					children: be
				})
			]
		})
	});
}
//#endregion
//#region src/games/finalgirl/fx.tsx
function rn(e, t) {
	return e.anchor(t) ?? e.anchor("stats") ?? e.anchor("board");
}
function an(e, t) {
	let n = e.data;
	return typeof n?.[t] == "number" ? n[t] : 0;
}
function on(e, t, n, r = "board") {
	let i = rn(e, r);
	return i ? {
		ms: t,
		node: /* @__PURE__ */ p(h, {
			at: i,
			ms: t,
			children: /* @__PURE__ */ p("span", {
				className: "rounded bg-white/90 px-1",
				children: n
			})
		})
	} : null;
}
var sn = {
	"damage-girl"(e, t) {
		return on(t, 900, /* @__PURE__ */ m("span", {
			className: "text-danger-deep",
			children: ["-", an(e, "amount")]
		}), "girl");
	},
	"damage-killer"(e, t) {
		return on(t, 900, /* @__PURE__ */ m("span", {
			className: "text-done-ink",
			children: ["-", an(e, "amount")]
		}), "killer");
	},
	"heal-girl"(e, t) {
		return on(t, 900, /* @__PURE__ */ m("span", {
			className: "text-done-ink",
			children: ["+", an(e, "amount")]
		}), "girl");
	},
	"kill-victim"(e, t) {
		return on(t, 900, "💀");
	},
	save(e, t) {
		return on(t, 900, "🎉");
	},
	revive(e, t) {
		return on(t, 1200, "❤️", "girl");
	}
};
//#endregion
//#region src/games/finalgirl/endgame-review.tsx
function cn({ board: e, renderResult: t, ...n }) {
	let s = l(), [c, u] = o(!0), [d, f] = o(null), h = a(null), g = a(null), y = a(null);
	r(() => {
		if (!d) return;
		y.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let b = (e) => {
		f(null), u(e), requestAnimationFrame(() => (e ? h : g).current?.focus({ preventScroll: !0 }));
	}, x = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), S = {
		...n,
		...x
	};
	return /* @__PURE__ */ m("div", {
		className: "finalgirl-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ p("div", {
				className: "finalgirl-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ p("div", {
				className: "finalgirl-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ m("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), b(!1));
					},
					className: "finalgirl-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ m("header", {
							className: "finalgirl-endgame-heading",
							children: [/* @__PURE__ */ m("div", {
								className: "finalgirl-endgame-brand",
								children: [/* @__PURE__ */ p("span", {
									"aria-hidden": "true",
									children: q.icon
								}), s(q.nameKey)]
							}), /* @__PURE__ */ p("button", {
								type: "button",
								ref: h,
								className: "btn-quiet",
								"aria-label": s("games.finalgirl.reviewHide"),
								title: s("games.finalgirl.reviewHide"),
								onClick: () => b(!1),
								children: /* @__PURE__ */ p(_, { size: 19 })
							})]
						}),
						/* @__PURE__ */ p("div", {
							className: "finalgirl-endgame-result",
							inert: d !== null,
							children: t(S)
						}),
						d && /* @__PURE__ */ m("div", {
							className: "finalgirl-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ p("button", {
								type: "button",
								ref: y,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.finalgirl.reviewConfirmAgain" : "games.finalgirl.reviewConfirmLobby")
							}), /* @__PURE__ */ p("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), h.current?.focus({ preventScroll: !0 });
								},
								children: s("games.finalgirl.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "finalgirl-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-base",
					ref: g,
					onClick: () => b(!0),
					children: [
						/* @__PURE__ */ p(v, { size: 18 }),
						s("games.finalgirl.reviewShow"),
						/* @__PURE__ */ p(ee, { size: 18 })
					]
				})
			})
		]
	});
}
function ln({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: u, renderRowExtra: d, summary: h, navigation: ee, content: v, afterRanking: x, scoreUnit: S, rankOf: C }) {
	let w = l(), T = c((e) => e.locale), [E, te] = o({}), D = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? y(n, T) : e;
	}, ne = (t, n) => C?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), O = e.ranking.some((t) => e.scores?.[t] !== void 0), re = (t, n) => /* @__PURE__ */ m("div", {
		className: "finalgirl-score-identity",
		children: [
			/* @__PURE__ */ m("span", {
				className: "finalgirl-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ p("span", {
					"aria-label": w("games.finalgirl.reviewWinner"),
					children: "♛ "
				}), O && ne(t, n)]
			}),
			/* @__PURE__ */ m("span", {
				className: "finalgirl-score-name",
				children: [D(t), t === r && /* @__PURE__ */ p("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ m("small", {
				className: "finalgirl-score-autopilot",
				children: [
					/* @__PURE__ */ p(g, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), k = (t) => e.ranking.map((n) => /* @__PURE__ */ p("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ m("div", {
		className: "finalgirl-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ p(b, {}),
			ee,
			/* @__PURE__ */ m("div", {
				className: "finalgirl-score-body",
				children: [
					h && /* @__PURE__ */ p("div", {
						className: "finalgirl-score-summary",
						children: h
					}),
					i !== void 0 && /* @__PURE__ */ p("p", {
						className: "finalgirl-score-hints",
						children: w("session.hint.usedCount", { n: i })
					}),
					v ?? (u?.length ? /* @__PURE__ */ p("div", {
						className: "finalgirl-score-table-scroll",
						children: /* @__PURE__ */ m("table", {
							className: "finalgirl-score-table",
							"aria-label": w(q.nameKey),
							children: [
								/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { scope: "col" }), /* @__PURE__ */ p(f, { children: e.ranking.map((t, n) => /* @__PURE__ */ p("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: re(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ p("tbody", { children: u.map((e, t) => /* @__PURE__ */ m(n, { children: [/* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ m("button", {
										type: "button",
										"aria-expanded": !!E[t],
										onClick: () => te((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ p(_, { size: 15 }), e.label]
									}) : e.label
								}), k(e)] }), E[t] && e.details?.map((e, t) => /* @__PURE__ */ m("tr", {
									className: "finalgirl-score-sub",
									children: [/* @__PURE__ */ p("th", {
										scope: "row",
										children: e.label
									}), k(e)]
								}, t))] }, t)) }),
								O && /* @__PURE__ */ p("tfoot", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
									scope: "row",
									children: w("games.finalgirl.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ p("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ p("ol", {
						className: "finalgirl-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ m("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ m("div", {
								className: "finalgirl-score-rankline",
								children: [re(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ m("strong", {
									className: "finalgirl-score-points",
									children: [e.scores[t], S && /* @__PURE__ */ p("small", { children: S })]
								})]
							}), d?.(t)]
						}, t))
					})),
					x,
					!!u?.length && d && /* @__PURE__ */ p("div", {
						className: "finalgirl-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ p("summary", { children: D(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ m("footer", {
				className: "finalgirl-score-actions",
				children: [
					s && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: w("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: w("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ p("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/finalgirl/game-over.tsx
function un(e) {
	return /* @__PURE__ */ p(ln, {
		...e,
		accent: q.accent
	});
}
function dn(e) {
	return /* @__PURE__ */ p(cn, {
		...e,
		board: /* @__PURE__ */ p(nn, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ p(un, { ...e })
	});
}
//#endregion
//#region src/games/finalgirl/options.tsx
var fn = {
	laurie: "games.finalgirl.girlLaurie",
	reiko: "games.finalgirl.girlReiko",
	random: "games.finalgirl.optGirlRandom"
}, pn = {
	"capture-flag": "games.finalgirl.setupCaptureFlag",
	"skinny-dipping": "games.finalgirl.setupSkinnyDipping",
	"treasure-hunt": "games.finalgirl.setupTreasureHunt",
	bonfire: "games.finalgirl.setupBonfire",
	meditation: "games.finalgirl.setupMeditation",
	random: "games.finalgirl.optSetupRandom"
};
function mn({ value: e, onChange: t }) {
	let n = l(), r = it.safeParse(e), i = r.success ? r.data : it.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "fg-options flex flex-col gap-4",
		style: { "--fg-accent": q.accent },
		children: [
			/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("div", {
				className: "section-label",
				children: n("games.finalgirl.optGirl")
			}), /* @__PURE__ */ p("div", {
				className: "grid grid-cols-3 gap-2",
				children: Object.keys(fn).map((e) => /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => t({
						...i,
						girl: e
					}),
					className: "fg-option-card fg-girl-choice",
					"data-selected": i.girl === e,
					"aria-pressed": i.girl === e,
					children: [
						e === "random" ? /* @__PURE__ */ p("span", {
							className: "fg-random-still",
							children: "?"
						}) : /* @__PURE__ */ p("img", {
							src: Q(`people/${e}.webp`),
							alt: ""
						}),
						i.girl === e && /* @__PURE__ */ p("i", {
							"aria-hidden": !0,
							className: "absolute right-1 top-1 z-10 grid size-5 place-items-center rounded-full border-2 border-ink bg-surface",
							children: /* @__PURE__ */ p("span", { className: "size-2 rounded-full bg-ink" })
						}),
						/* @__PURE__ */ p("span", { children: n(fn[e]) })
					]
				}, e))
			})] }),
			/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("div", {
				className: "section-label",
				children: n("games.finalgirl.optSetup")
			}), /* @__PURE__ */ p("div", {
				className: "grid grid-cols-2 gap-2",
				children: Object.keys(pn).map((e, r) => /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => t({
						...i,
						setup: e
					}),
					className: "fg-option-card fg-setup-choice",
					"data-selected": i.setup === e,
					"aria-pressed": i.setup === e,
					children: [
						/* @__PURE__ */ p("img", {
							className: "fg-setup-art",
							src: Q("camp-map.webp"),
							alt: "",
							style: { objectPosition: [
								"12% 18%",
								"76% 36%",
								"40% 62%",
								"20% 82%",
								"62% 18%",
								"center"
							][r] }
						}),
						i.setup === e && /* @__PURE__ */ p("i", {
							"aria-hidden": !0,
							className: "absolute right-1 top-1 z-10 grid size-5 place-items-center rounded-full border-2 border-ink bg-surface",
							children: /* @__PURE__ */ p("span", { className: "size-2 rounded-full bg-ink" })
						}),
						/* @__PURE__ */ p("span", {
							className: "fg-setup-index",
							children: String(r + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ p("span", { children: n(pn[e]) })
					]
				}, e))
			})] }),
			/* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => t({
					...i,
					extreme: !i.extreme
				}),
				className: "fg-option-card min-h-12 w-full px-3 py-2 text-left text-sm font-bold",
				"data-selected": i.extreme,
				"aria-pressed": i.extreme,
				children: [/* @__PURE__ */ p("span", {
					className: "mr-2 inline-flex h-6 w-6 items-center justify-center rounded border-2 border-ink",
					children: i.extreme ? "✓" : ""
				}), n("games.finalgirl.optExtreme")]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/finalgirl/entry.tsx
var hn = {
	definition: At,
	View: nn,
	fx: sn,
	OverView: dn,
	Options: mn,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "绝命少女:恐怖快乐小径",
			desc: "单人恐怖生存:扮演最后的少女,救出营员并反杀屠夫",
			rules: "目标:扮演最后的少女,救出营员并杀死屠夫汉斯;少女死亡则失败。\n准备:屠夫与受害者按设置卡落位;你获得 6 张零费行动卡作起手牌。\n回合流程:\n· 行动:打出行动卡并掷骰判定;走动每格消耗 1 点时间。\n· 计划:用剩余时间购买新行动卡,然后时间重置为 6 点。\n· 杀手:屠夫锁定最近的目标、移动并攻击,再抽 1 张恐怖卡。\n· 恐慌:本回合有受害者死亡时,杀手所在格的受害者掷骰逃跑。\n· 维护:恐怖卡组抽空后揭示终章卡;可自由调配手持物品。\n掷骰:5 与 6 算成功;3 与 4 可弃 2 张手牌转为成功。\n救人:少女在出口格可救出同格的受害者;集满奖励格解锁终极能力。",
			phaseAction: "行动阶段",
			phasePlanning: "计划阶段",
			phaseKiller: "杀手阶段",
			phasePanic: "恐慌阶段",
			phaseUpkeep: "维护阶段",
			phaseWon: "屠夫已死,你活了下来",
			phaseLost: "少女倒下了",
			girlLaurie: "劳丽·卡彭特",
			girlReiko: "玲子·里弗斯",
			girlLaurieUlt: "与屠夫同格时,你造成的伤害加一",
			girlReikoUlt: "每行动阶段一次:屠夫在两格内时,免费移动到屠夫所在格",
			saveProgress: "救人 {{a}}/{{b}}",
			ultimateReady: "终极能力已解锁",
			ultimateUsed: "终极能力本阶段已用",
			setupCaptureFlag: "夺旗游戏",
			setupSkinnyDipping: "裸泳",
			setupTreasureHunt: "寻宝游戏",
			setupBonfire: "篝火晚会",
			setupMeditation: "冥想时刻",
			optGirl: "少女",
			optGirlRandom: "随机少女",
			optExtreme: "极限恐怖模式(更少的骰子与时间)",
			optSetup: "设置卡",
			optSetupRandom: "随机设置",
			spaceWoodsNw: "西北树林",
			spaceWoodsN: "北树林",
			spaceExitN: "北出口",
			spaceWoodsNe: "东北树林",
			spaceShed: "工具棚",
			spaceCabins: "小屋",
			spaceMakeout: "约会点",
			spaceCliff: "悬崖",
			spaceLake: "湖",
			spaceRec: "活动区",
			spaceCove: "小湾",
			spaceFirepit: "营火",
			spaceDock: "码头",
			spaceJunction: "岔路口",
			spaceSwamp: "沼泽",
			spaceMeadow: "草地",
			spaceExitSw: "西南出口",
			spaceExitSe: "东南出口",
			cardWalk: "步行",
			cardFocus: "集中精神",
			cardWeakAttack: "弱击",
			cardShortRest: "短休",
			cardCloseCall: "死里逃生",
			cardGuard: "格挡",
			cardSearch: "搜索",
			cardSprint: "冲刺",
			cardDistraction: "声东击西",
			cardImprovise: "随机应变",
			cardFuriousStrike: "狂怒一击",
			cardPlanning: "谋划",
			cardRetaliate: "反击",
			cardLongRest: "长休",
			cardCriticalBlow: "致命一击",
			itemBat: "铝棒",
			itemBow: "弓箭",
			itemAxe: "斧头",
			itemBearTrap: "捕熊夹",
			itemEnergyDrink: "能量饮料",
			itemFireworks: "烟花",
			itemFirstAid: "急救包",
			itemFlashlight: "手电筒",
			itemKnife: "小刀",
			itemLuckyDice: "幸运骰子",
			itemRabbitsFoot: "幸运兔脚",
			itemMap: "地图",
			itemBoatKeys: "摩托艇钥匙",
			itemPills: "神秘药丸",
			itemRevolver: "旧左轮",
			itemPepperSpray: "防狼喷雾",
			itemTrashcanLid: "垃圾桶盖",
			itemWhistle: "哨子",
			eventBoyfriend: "男友",
			eventClingyCampers: "缠人的营员",
			eventDarkWaters: "黑水",
			eventDeathwish: "死亡愿望",
			eventFreshMeat: "新鲜猎物",
			eventGirlfriend: "女友",
			eventSecretTunnel: "秘密通道",
			eventStarCrossed: "苦命鸳鸯",
			eventStubbornKids: "倔强的孩子",
			eventVengeance: "复仇",
			terrorDarkFeast: "黑暗盛宴",
			terrorAlwaysWanted: "他一直想要的是我",
			terrorOutOfNowhere: "他不知从哪冒了出来",
			terrorKeepsComing: "他紧追不舍",
			terrorKeptSwinging: "他挥舞铁锤杀个不停",
			terrorFreshBlood: "他要新鲜的血",
			terrorStandingThere: "他就站在那儿",
			terrorHammerRush: "恐怖锤击冲锋",
			terrorSouvenirs: "收集纪念品",
			terrorUnholyRage: "邪恶之怒",
			terrorUnholySpeed: "邪恶神速",
			terrorFire: "起火了",
			terrorFellAsleep: "我睡着了,错过了什么",
			terrorRumors: "去看看传言是不是真的",
			terrorGoingOurWay: "形势开始好转",
			terrorRunForLife: "逃命吧",
			terrorWhatsHerName: "那个女孩能帮上忙",
			terrorThatNoise: "那是什么动静",
			terrorCantSaveUs: "你救不了我们",
			powerBloodFrenzy: "嗜血狂热",
			powerDarkObsession: "黑暗痴迷",
			powerFeed: "进食",
			powerSledgehammer: "巨锤屠杀",
			finaleBloodbath: "终章:大血洗",
			finaleButcherBloodlust: "终章:屠夫血怒",
			finaleDarkDarkerDarkest: "终章:黑暗,更黑,最黑",
			finaleHidden: "终章(未揭示)",
			hp: "生命",
			time: "时间",
			horror: "恐怖",
			bloodlust: "血怒",
			victimsLeft: "在场受害者",
			saved: "已救出",
			dead: "死亡",
			hand: "手牌",
			discardPile: "弃牌堆",
			tableau: "行动卡池",
			terrorLeft: "恐怖卡剩余 {{n}}",
			moveBudget: "还可移动 {{n}} 格",
			endActionPhase: "结束行动",
			endPlanning: "结束计划",
			endUpkeep: "开始下一回合",
			moveDone: "停止移动",
			save: "救出",
			useUltimate: "终极能力",
			rollDone: "确认结果",
			rollTray: "命运骰盘",
			rollLegend: "5–6 成功 · 3–4 可转成功",
			rollDie: "第 {{n}} 枚骰子，点数 {{value}}",
			rollConvert: "弃两张转成功",
			rollReroll: "重掷",
			killerTarget: "屠夫的目标",
			pickVictim: "选择恐慌的受害者",
			reactPrompt: "屠夫攻击你({{dmg}} 点伤害)",
			reactTake: "硬吃伤害",
			panicHint: "依次点选受害者,掷骰决定逃跑方向",
			upkeepHint: "可以自由调配手持与背包物品",
			planningHint: "用剩余时间购买行动卡,结束后时间重置",
			turnChip: "第 {{n}} 轮",
			killerHint: "杀手行动中……",
			tiePrompt: "目标并列:点选屠夫的目标格",
			pickPilePrompt: "选择一堆物品",
			pickCardPrompt: "从行动卡池选一张卡",
			batPowerPrompt: "铝棒重击:弃掉一种次黑暗力量,或放弃",
			batPowerSkip: "不弃",
			pickSpaceTunnel1: "秘道:点选第一个洞口",
			pickSpaceTunnel2: "秘道:点选第二个洞口",
			pickSpaceFireworks: "烟花:点选放置格",
			pickSpaceBoat: "摩托艇:点选目的湖岸",
			discardTime: "弃牌换时",
			discardConfirm: "弃牌(获得 {{n}} 点时间)",
			bringPrompt: "点选随行受害者(人数有上限)",
			mapTitle: "恐怖快乐小径",
			mapMoves: "{{n}} 处可移动",
			moveCost: "消耗 {{n}} 时间",
			moveFree: "免费移动",
			victimUnit: "营员 {{n}}",
			victimBoyfriend: "男友",
			victimGirlfriend: "女友",
			victimDamned: "被诅咒的营员",
			victimSelected: "已选",
			victimClose: "收起",
			girlPosition: "少女位置",
			killerHans: "屠夫汉斯",
			gearEmpty: "道具袋空 · 前往搜索地点寻找物品",
			moveGo: "移动",
			moveBring: "移动(带 {{n}} 人)",
			cancelAction: "取消",
			saveConfirm: "救出 {{n}} 人",
			searchKeepPrompt: "搜索:保留哪一张?",
			searchOtherPrompt: "另一张怎么处理?",
			searchTop: "放回堆顶",
			searchBottom: "放到堆底",
			failChoicePrompt: "失败:选择一项效果结算",
			failOptA: "效果一",
			failOptB: "效果二",
			optTime2: "获得 2 点时间",
			optTime3: "获得 3 点时间",
			optHeal1: "回复 1 点生命",
			optHeal2: "回复 2 点生命",
			optHorrorDown: "降低 1 点恐怖",
			optMove1: "移动 1 格",
			optFlip: "翻开堆顶",
			optRemove: "移除堆顶",
			optSkip: "跳过",
			optKeepTop: "留在堆顶",
			optToBottom: "放到堆底",
			pickWeapon: "选择武器",
			weaponNone: "徒手",
			rerollLucky: "幸运骰重掷",
			killerHp: "屠夫生命",
			girlHp: "少女生命",
			ultNotReady: "集满奖励格后解锁终极能力",
			errNotYourTurn: "现在不是你的回合",
			errNotNow: "现在不能这么做",
			errBadCard: "这张卡现在不能用",
			errBadOption: "这个选项不可用",
			errBadSpace: "不能去这一格",
			errBadVictim: "这些受害者不能这么选",
			errNoTime: "时间不够了",
			errHandFull: "手牌已满",
			errNotExit: "只有站在出口格才能救人",
			errTooMany: "带不了这么多人",
			errDamnedLast: "被诅咒者必须最后获救",
			errOutOfRange: "屠夫不在攻击范围内",
			errBadItem: "这件物品现在不能用",
			errNotInHands: "这件物品要拿在手上才能用",
			errOncePerPhase: "每个行动阶段只能用一次",
			errEmptyDeck: "恐怖卡组已经抽空",
			errNotLakeside: "只有站在湖边才能用摩托艇",
			errNotSearchSpace: "这里不是搜索格",
			errEmptyPile: "这里的物品堆已经空了"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Final Girl: Camp Happy Trails",
			desc: "Solo horror survival: play the final girl, save the campers and slay the butcher",
			rules: "Goal: play the final girl, rescue campers and slay Hans the butcher; if the girl dies, you lose.\nSetup: the killer and victims are placed by a setup card; you start with 6 zero-cost action cards.\nEach round:\n· Action: play action cards and roll to resolve them; walking costs 1 time per space.\n· Planning: spend remaining time on new action cards, then time resets to 6.\n· Killer: the butcher targets the closest victim or you, moves, attacks, then draws a terror card.\n· Panic: if a victim died this turn, victims on the killer space roll to flee.\n· Upkeep: reveal the finale once the terror deck runs out; rearrange held items freely.\nDice: 5 and 6 are successes; 3 and 4 can be converted by discarding 2 cards.\nRescue: on an exit space you may save victims with you; fill all reward slots to unlock the ultimate.",
			phaseAction: "Action Phase",
			phasePlanning: "Planning Phase",
			phaseKiller: "Killer Phase",
			phasePanic: "Panic Phase",
			phaseUpkeep: "Upkeep Phase",
			phaseWon: "The butcher is dead. You survived.",
			phaseLost: "The final girl has fallen",
			girlLaurie: "Laurie Carpenter",
			girlReiko: "Reiko Rivers",
			girlLaurieUlt: "You deal one extra damage while sharing a space with the killer",
			girlReikoUlt: "Once per action phase: if the killer is within two spaces, move onto his space for free",
			saveProgress: "Saved {{a}}/{{b}}",
			ultimateReady: "Ultimate unlocked",
			ultimateUsed: "Ultimate already used this phase",
			setupCaptureFlag: "Capture the Flag",
			setupSkinnyDipping: "Skinny Dipping",
			setupTreasureHunt: "Treasure Hunt",
			setupBonfire: "The Bonfire",
			setupMeditation: "Meditation Hour",
			optGirl: "Final Girl",
			optGirlRandom: "Random girl",
			optExtreme: "Extreme Horror mode (fewer dice and less time)",
			optSetup: "Setup card",
			optSetupRandom: "Random setup",
			spaceWoodsNw: "NW Woods",
			spaceWoodsN: "N Woods",
			spaceExitN: "North Exit",
			spaceWoodsNe: "NE Woods",
			spaceShed: "Utility Shed",
			spaceCabins: "Cabins",
			spaceMakeout: "Makeout Point",
			spaceCliff: "Cliff",
			spaceLake: "Lake",
			spaceRec: "Rec Area",
			spaceCove: "Cove",
			spaceFirepit: "Firepit",
			spaceDock: "Dock",
			spaceJunction: "Junction",
			spaceSwamp: "Swamp",
			spaceMeadow: "Meadow",
			spaceExitSw: "SW Exit",
			spaceExitSe: "SE Exit",
			cardWalk: "Walk",
			cardFocus: "Focus",
			cardWeakAttack: "Weak Attack",
			cardShortRest: "Short Rest",
			cardCloseCall: "Close Call",
			cardGuard: "Guard",
			cardSearch: "Search",
			cardSprint: "Sprint",
			cardDistraction: "Distraction",
			cardImprovise: "Improvise",
			cardFuriousStrike: "Furious Strike",
			cardPlanning: "Planning",
			cardRetaliate: "Retaliate",
			cardLongRest: "Long Rest",
			cardCriticalBlow: "Critical Blow",
			itemBat: "Aluminum Bat",
			itemBow: "Archery Bow",
			itemAxe: "Axe",
			itemBearTrap: "Bear Trap",
			itemEnergyDrink: "Energy Drink",
			itemFireworks: "Fireworks",
			itemFirstAid: "First Aid Kit",
			itemFlashlight: "Flashlight",
			itemKnife: "Knife",
			itemLuckyDice: "Lucky Dice",
			itemRabbitsFoot: "Rabbit's Foot",
			itemMap: "Map",
			itemBoatKeys: "Motor Boat Keys",
			itemPills: "Mysterious Pills",
			itemRevolver: "Old Revolver",
			itemPepperSpray: "Pepper Spray",
			itemTrashcanLid: "Trashcan Lid",
			itemWhistle: "Whistle",
			eventBoyfriend: "Boyfriend",
			eventClingyCampers: "Clingy Campers",
			eventDarkWaters: "Dark Waters",
			eventDeathwish: "Deathwish",
			eventFreshMeat: "Fresh Meat",
			eventGirlfriend: "Girlfriend",
			eventSecretTunnel: "Secret Tunnel",
			eventStarCrossed: "Star-Crossed Lovers",
			eventStubbornKids: "Stubborn Kids",
			eventVengeance: "Vengeance",
			terrorDarkFeast: "Dark Feast",
			terrorAlwaysWanted: "He Always Wanted Me",
			terrorOutOfNowhere: "Out of Nowhere",
			terrorKeepsComing: "He Just Keeps Coming",
			terrorKeptSwinging: "He Kept Swinging",
			terrorFreshBlood: "Fresh Blood",
			terrorStandingThere: "Just Standing There",
			terrorHammerRush: "Horrific Hammer Rush",
			terrorSouvenirs: "Taking Souvenirs",
			terrorUnholyRage: "Unholy Rage",
			terrorUnholySpeed: "Unholy Speed",
			terrorFire: "Fire!",
			terrorFellAsleep: "I Fell Asleep",
			terrorRumors: "See If the Rumors Are True",
			terrorGoingOurWay: "Things Go Our Way",
			terrorRunForLife: "Run for Your Life",
			terrorWhatsHerName: "What's-Her-Name Can Help",
			terrorThatNoise: "What's That Noise",
			terrorCantSaveUs: "You Cannot Save Us",
			powerBloodFrenzy: "Blood Frenzy",
			powerDarkObsession: "Dark Obsession",
			powerFeed: "Feed",
			powerSledgehammer: "Sledgehammer Massacre",
			finaleBloodbath: "Finale: Bloodbath",
			finaleButcherBloodlust: "Finale: Butcher Bloodlust",
			finaleDarkDarkerDarkest: "Finale: Dark, Darker, Darkest",
			finaleHidden: "Finale (unrevealed)",
			hp: "Health",
			time: "Time",
			horror: "Horror",
			bloodlust: "Bloodlust",
			victimsLeft: "Victims alive",
			saved: "Saved",
			dead: "Dead",
			hand: "Hand",
			discardPile: "Discard",
			tableau: "Action tableau",
			terrorLeft: "{{n}} terror cards left",
			moveBudget: "{{n}} move(s) left",
			endActionPhase: "End action phase",
			endPlanning: "End planning",
			endUpkeep: "Start next turn",
			moveDone: "Stop moving",
			save: "Save",
			useUltimate: "Ultimate",
			rollDone: "Confirm result",
			rollTray: "Fate dice tray",
			rollLegend: "5–6 success · 3–4 convertible",
			rollDie: "Die {{n}}, value {{value}}",
			rollConvert: "Discard two to convert",
			rollReroll: "Reroll",
			killerTarget: "Killer's target",
			pickVictim: "Pick the next panicking victim",
			reactPrompt: "The killer attacks you ({{dmg}} damage)",
			reactTake: "Take the hit",
			panicHint: "Tap victims one by one to roll their escape",
			upkeepHint: "Rearrange items between hands and backpack",
			planningHint: "Spend remaining time on action cards; time resets afterwards",
			turnChip: "Round {{n}}",
			killerHint: "The killer is acting…",
			tiePrompt: "Tied targets: tap the killer target space",
			pickPilePrompt: "Pick an item pile",
			pickCardPrompt: "Pick a card from the tableau",
			batPowerPrompt: "Bat smash: discard a minor power, or pass",
			batPowerSkip: "Pass",
			pickSpaceTunnel1: "Tunnel: tap the first entrance",
			pickSpaceTunnel2: "Tunnel: tap the second entrance",
			pickSpaceFireworks: "Fireworks: tap a space to place it",
			pickSpaceBoat: "Motor boat: tap a lakeside destination",
			discardTime: "Discard for time",
			discardConfirm: "Discard (gain {{n}} time)",
			bringPrompt: "Tap victims to bring along (limited)",
			mapTitle: "Camp Happy Trails",
			mapMoves: "{{n}} places to move",
			moveCost: "Costs {{n}} time",
			moveFree: "Free move",
			victimUnit: "Camper {{n}}",
			victimBoyfriend: "Boyfriend",
			victimGirlfriend: "Girlfriend",
			victimDamned: "Damned camper",
			victimSelected: "Selected",
			victimClose: "Close",
			girlPosition: "Girl at",
			killerHans: "Hans the butcher",
			gearEmpty: "Empty gear bag · Search a location for items",
			moveGo: "Move",
			moveBring: "Move (bring {{n}})",
			cancelAction: "Cancel",
			saveConfirm: "Save {{n}}",
			searchKeepPrompt: "Search: keep which one?",
			searchOtherPrompt: "What about the other card?",
			searchTop: "Back on top",
			searchBottom: "To the bottom",
			failChoicePrompt: "Failure: pick one effect to resolve",
			failOptA: "Effect A",
			failOptB: "Effect B",
			optTime2: "Gain 2 time",
			optTime3: "Gain 3 time",
			optHeal1: "Heal 1 health",
			optHeal2: "Heal 2 health",
			optHorrorDown: "Lower horror by 1",
			optMove1: "Move 1 space",
			optFlip: "Flip the top card",
			optRemove: "Remove the top card",
			optSkip: "Skip",
			optKeepTop: "Keep on top",
			optToBottom: "To the bottom",
			pickWeapon: "Pick a weapon",
			weaponNone: "Bare hands",
			rerollLucky: "Lucky dice reroll",
			killerHp: "Killer health",
			girlHp: "Girl health",
			ultNotReady: "Fill all reward slots to unlock the ultimate",
			errNotYourTurn: "Not your turn",
			errNotNow: "You cannot do that now",
			errBadCard: "That card cannot be used now",
			errBadOption: "That option is unavailable",
			errBadSpace: "You cannot go there",
			errBadVictim: "Those victims cannot be picked that way",
			errNoTime: "Not enough time",
			errHandFull: "Your hand is full",
			errNotExit: "You can only save victims on an exit space",
			errTooMany: "You cannot bring that many victims",
			errDamnedLast: "The Damned must be saved last",
			errOutOfRange: "The killer is out of range",
			errBadItem: "That item cannot be used now",
			errNotInHands: "That item must be in your hands",
			errOncePerPhase: "Only once per action phase",
			errEmptyDeck: "The terror deck is empty",
			errNotLakeside: "The boat can only be used by the lake",
			errNotSearchSpace: "This is not a search space",
			errEmptyPile: "This item pile is empty"
		}
	}
};
//#endregion
export { hn as default };
