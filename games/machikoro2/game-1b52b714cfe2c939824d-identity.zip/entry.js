import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { DICE_ROLL_MS as t } from "@bgparty/sdk/fx/dice-roll-ms";
import { z as n } from "zod";
import { useEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { Texture as u } from "@bgparty/sdk/texture";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { DICE_ROLL_MS as v, createDiceRollRenderer as y } from "@bgparty/sdk/fx/dice-roll";
import { Flash as b, Floater as x, FlySprite as S, PulseBox as C } from "@bgparty/sdk/fx/primitives";
import { AVATARS as w } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as T } from "@bgparty/sdk/player-colors";
import { Confetti as E } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as ee, OptionSection as te } from "@bgparty/sdk/ui/game-options";
//#region src/games/machikoro2/cards.ts
var ne = [
	"wheatField",
	"sushiBar",
	"businessCenter",
	"flowerShop",
	"cafe",
	"bakery",
	"flowerGarden",
	"vineyard",
	"forest",
	"convenienceStore"
], re = [
	"cornField",
	"foodWarehouse",
	"familyRestaurant",
	"shoppingDistrict",
	"hamburgerStand",
	"furnitureFactory",
	"stadium",
	"winery",
	"appleOrchard",
	"mine"
], D = {
	wheatField: {
		id: "wheatField",
		row: "low",
		color: "blue",
		activation: [1, 2],
		cost: 1,
		count: 5,
		category: "agriculture",
		gain: 1,
		emoji: "🌾"
	},
	sushiBar: {
		id: "sushiBar",
		row: "low",
		color: "red",
		activation: [1],
		cost: 2,
		count: 5,
		category: "food",
		takeActive: 3,
		emoji: "🍣"
	},
	businessCenter: {
		id: "businessCenter",
		row: "low",
		color: "purple",
		activation: [6],
		cost: 3,
		count: 3,
		category: "major",
		emoji: "🏢"
	},
	flowerShop: {
		id: "flowerShop",
		row: "low",
		color: "green",
		activation: [6],
		cost: 1,
		count: 3,
		category: "combo",
		comboOf: "flower",
		gain: 3,
		emoji: "💐"
	},
	cafe: {
		id: "cafe",
		row: "low",
		color: "red",
		activation: [3],
		cost: 1,
		count: 5,
		category: "food",
		takeActive: 2,
		emoji: "☕"
	},
	bakery: {
		id: "bakery",
		row: "low",
		color: "green",
		activation: [2, 3],
		cost: 1,
		count: 5,
		category: "shop",
		gain: 2,
		emoji: "🥖"
	},
	flowerGarden: {
		id: "flowerGarden",
		row: "low",
		color: "blue",
		activation: [4],
		cost: 2,
		count: 5,
		category: "flower",
		gain: 2,
		emoji: "🌷"
	},
	vineyard: {
		id: "vineyard",
		row: "low",
		color: "blue",
		activation: [2],
		cost: 1,
		count: 5,
		category: "fruit",
		gain: 2,
		emoji: "🍇"
	},
	forest: {
		id: "forest",
		row: "low",
		color: "blue",
		activation: [5],
		cost: 3,
		count: 5,
		category: "gear",
		gain: 2,
		emoji: "🌲"
	},
	convenienceStore: {
		id: "convenienceStore",
		row: "low",
		color: "green",
		activation: [4],
		cost: 1,
		count: 5,
		category: "shop",
		gain: 3,
		emoji: "🏪"
	},
	cornField: {
		id: "cornField",
		row: "high",
		color: "blue",
		activation: [7],
		cost: 2,
		count: 5,
		category: "agriculture",
		gain: 3,
		emoji: "🌽"
	},
	foodWarehouse: {
		id: "foodWarehouse",
		row: "high",
		color: "green",
		activation: [10, 11],
		cost: 2,
		count: 3,
		category: "combo",
		comboOf: "food",
		gain: 2,
		emoji: "📦"
	},
	familyRestaurant: {
		id: "familyRestaurant",
		row: "high",
		color: "red",
		activation: [9, 10],
		cost: 2,
		count: 5,
		category: "food",
		takeActive: 2,
		emoji: "🍝"
	},
	shoppingDistrict: {
		id: "shoppingDistrict",
		row: "high",
		color: "purple",
		activation: [8, 9],
		cost: 3,
		count: 3,
		category: "major",
		emoji: "🛍️"
	},
	hamburgerStand: {
		id: "hamburgerStand",
		row: "high",
		color: "red",
		activation: [8],
		cost: 1,
		count: 5,
		category: "food",
		takeActive: 2,
		emoji: "🍔"
	},
	furnitureFactory: {
		id: "furnitureFactory",
		row: "high",
		color: "green",
		activation: [8],
		cost: 4,
		count: 3,
		category: "combo",
		comboOf: "gear",
		gain: 4,
		emoji: "🪑"
	},
	stadium: {
		id: "stadium",
		row: "high",
		color: "purple",
		activation: [7],
		cost: 3,
		count: 3,
		category: "major",
		emoji: "🏟️"
	},
	winery: {
		id: "winery",
		row: "high",
		color: "green",
		activation: [9],
		cost: 3,
		count: 3,
		category: "combo",
		comboOf: "fruit",
		gain: 3,
		emoji: "🍷"
	},
	appleOrchard: {
		id: "appleOrchard",
		row: "high",
		color: "blue",
		activation: [10],
		cost: 1,
		count: 5,
		category: "fruit",
		gain: 3,
		emoji: "🍎"
	},
	mine: {
		id: "mine",
		row: "high",
		color: "blue",
		activation: [11, 12],
		cost: 4,
		count: 5,
		category: "gear",
		gain: 6,
		emoji: "⛏️"
	}
}, ie = [
	"airport",
	"amusementPark",
	"charterhouse",
	"exhibitHall",
	"farmersMarket",
	"forge",
	"frenchRestaurant",
	"launchPad",
	"loanOffice",
	"movingCompany",
	"museum",
	"observatory",
	"park",
	"publisher",
	"radioTower",
	"shoppingMall",
	"sodaBottlingPlant",
	"techStartup",
	"temple",
	"tvStation"
], ae = [
	"cityHall",
	"privateClub",
	"renovationCompany"
], O = {
	airport: {
		id: "airport",
		cost: [
			12,
			16,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "🛫"
	},
	amusementPark: {
		id: "amusementPark",
		cost: [
			12,
			16,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "🎡"
	},
	charterhouse: {
		id: "charterhouse",
		cost: [
			12,
			16,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "⛪"
	},
	exhibitHall: {
		id: "exhibitHall",
		cost: [
			12,
			16,
			22
		],
		timing: "instant",
		scope: "builder",
		emoji: "🖼️"
	},
	farmersMarket: {
		id: "farmersMarket",
		cost: [
			10,
			14,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "🧺"
	},
	forge: {
		id: "forge",
		cost: [
			12,
			16,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "⚒️"
	},
	frenchRestaurant: {
		id: "frenchRestaurant",
		cost: [
			10,
			14,
			22
		],
		timing: "instant",
		scope: "builder",
		emoji: "🥐"
	},
	launchPad: {
		id: "launchPad",
		cost: [
			45,
			38,
			25
		],
		timing: "instant",
		scope: "builder",
		emoji: "🚀"
	},
	loanOffice: {
		id: "loanOffice",
		cost: [10],
		timing: "ongoing",
		scope: "builder",
		emoji: "🏦"
	},
	movingCompany: {
		id: "movingCompany",
		cost: [
			10,
			14,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "🚚"
	},
	museum: {
		id: "museum",
		cost: [
			12,
			16,
			22
		],
		timing: "instant",
		scope: "builder",
		emoji: "🏛️"
	},
	observatory: {
		id: "observatory",
		cost: [
			10,
			14,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "🔭"
	},
	park: {
		id: "park",
		cost: [
			12,
			16,
			22
		],
		timing: "instant",
		scope: "builder",
		emoji: "🌳"
	},
	publisher: {
		id: "publisher",
		cost: [
			10,
			14,
			22
		],
		timing: "instant",
		scope: "builder",
		emoji: "📰"
	},
	radioTower: {
		id: "radioTower",
		cost: [
			12,
			16,
			22
		],
		timing: "instant",
		scope: "builder",
		emoji: "📡"
	},
	shoppingMall: {
		id: "shoppingMall",
		cost: [
			10,
			14,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "🏬"
	},
	sodaBottlingPlant: {
		id: "sodaBottlingPlant",
		cost: [
			12,
			16,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "🥤"
	},
	techStartup: {
		id: "techStartup",
		cost: [
			10,
			14,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "💻"
	},
	temple: {
		id: "temple",
		cost: [
			12,
			16,
			22
		],
		timing: "ongoing",
		scope: "all",
		emoji: "⛩️"
	},
	tvStation: {
		id: "tvStation",
		cost: [
			12,
			16,
			22
		],
		timing: "instant",
		scope: "builder",
		emoji: "📺"
	},
	cityHall: {
		id: "cityHall",
		cost: [
			10,
			14,
			22
		],
		promo: !0,
		timing: "ongoing",
		scope: "all",
		emoji: "🏤"
	},
	privateClub: {
		id: "privateClub",
		cost: [
			12,
			16,
			22
		],
		promo: !0,
		timing: "instant",
		scope: "builder",
		emoji: "🎩"
	},
	renovationCompany: {
		id: "renovationCompany",
		cost: [
			10,
			14,
			22
		],
		promo: !0,
		timing: "ongoing",
		scope: "all",
		emoji: "🔨"
	}
}, k = {
	farmersMarket: "agriculture",
	forge: "gear",
	shoppingMall: "shop",
	sodaBottlingPlant: "food",
	airport: null,
	amusementPark: null,
	charterhouse: null,
	exhibitHall: null,
	frenchRestaurant: null,
	launchPad: null,
	loanOffice: null,
	movingCompany: null,
	museum: null,
	observatory: null,
	park: null,
	publisher: null,
	radioTower: null,
	techStartup: null,
	temple: null,
	tvStation: null,
	cityHall: null,
	privateClub: null,
	renovationCompany: null
}, A = {
	agriculture: "🌾",
	fruit: "🍎",
	gear: "⚙️",
	flower: "🌷",
	food: "☕",
	shop: "🏪",
	major: "⭐",
	combo: "🧩"
}, j = {
	wheatField: "games.machikoro2.cardWheatField",
	sushiBar: "games.machikoro2.cardSushiBar",
	businessCenter: "games.machikoro2.cardBusinessCenter",
	flowerShop: "games.machikoro2.cardFlowerShop",
	cafe: "games.machikoro2.cardCafe",
	bakery: "games.machikoro2.cardBakery",
	flowerGarden: "games.machikoro2.cardFlowerGarden",
	vineyard: "games.machikoro2.cardVineyard",
	forest: "games.machikoro2.cardForest",
	convenienceStore: "games.machikoro2.cardConvenienceStore",
	cornField: "games.machikoro2.cardCornField",
	foodWarehouse: "games.machikoro2.cardFoodWarehouse",
	familyRestaurant: "games.machikoro2.cardFamilyRestaurant",
	shoppingDistrict: "games.machikoro2.cardShoppingDistrict",
	hamburgerStand: "games.machikoro2.cardHamburgerStand",
	furnitureFactory: "games.machikoro2.cardFurnitureFactory",
	stadium: "games.machikoro2.cardStadium",
	winery: "games.machikoro2.cardWinery",
	appleOrchard: "games.machikoro2.cardAppleOrchard",
	mine: "games.machikoro2.cardMine"
}, M = {
	airport: "games.machikoro2.lmAirport",
	amusementPark: "games.machikoro2.lmAmusementPark",
	charterhouse: "games.machikoro2.lmCharterhouse",
	exhibitHall: "games.machikoro2.lmExhibitHall",
	farmersMarket: "games.machikoro2.lmFarmersMarket",
	forge: "games.machikoro2.lmForge",
	frenchRestaurant: "games.machikoro2.lmFrenchRestaurant",
	launchPad: "games.machikoro2.lmLaunchPad",
	loanOffice: "games.machikoro2.lmLoanOffice",
	movingCompany: "games.machikoro2.lmMovingCompany",
	museum: "games.machikoro2.lmMuseum",
	observatory: "games.machikoro2.lmObservatory",
	park: "games.machikoro2.lmPark",
	publisher: "games.machikoro2.lmPublisher",
	radioTower: "games.machikoro2.lmRadioTower",
	shoppingMall: "games.machikoro2.lmShoppingMall",
	sodaBottlingPlant: "games.machikoro2.lmSodaBottlingPlant",
	techStartup: "games.machikoro2.lmTechStartup",
	temple: "games.machikoro2.lmTemple",
	tvStation: "games.machikoro2.lmTvStation",
	cityHall: "games.machikoro2.lmCityHall",
	privateClub: "games.machikoro2.lmPrivateClub",
	renovationCompany: "games.machikoro2.lmRenovationCompany"
}, N = {
	airport: "games.machikoro2.lmAirportText",
	amusementPark: "games.machikoro2.lmAmusementParkText",
	charterhouse: "games.machikoro2.lmCharterhouseText",
	exhibitHall: "games.machikoro2.lmExhibitHallText",
	farmersMarket: "games.machikoro2.lmFarmersMarketText",
	forge: "games.machikoro2.lmForgeText",
	frenchRestaurant: "games.machikoro2.lmFrenchRestaurantText",
	launchPad: "games.machikoro2.lmLaunchPadText",
	loanOffice: "games.machikoro2.lmLoanOfficeText",
	movingCompany: "games.machikoro2.lmMovingCompanyText",
	museum: "games.machikoro2.lmMuseumText",
	observatory: "games.machikoro2.lmObservatoryText",
	park: "games.machikoro2.lmParkText",
	publisher: "games.machikoro2.lmPublisherText",
	radioTower: "games.machikoro2.lmRadioTowerText",
	shoppingMall: "games.machikoro2.lmShoppingMallText",
	sodaBottlingPlant: "games.machikoro2.lmSodaBottlingPlantText",
	techStartup: "games.machikoro2.lmTechStartupText",
	temple: "games.machikoro2.lmTempleText",
	tvStation: "games.machikoro2.lmTvStationText",
	cityHall: "games.machikoro2.lmCityHallText",
	privateClub: "games.machikoro2.lmPrivateClubText",
	renovationCompany: "games.machikoro2.lmRenovationCompanyText"
}, P = {
	id: "machikoro2",
	tier: "released",
	mechanics: ["engine-building", "dice-rolling"],
	interactionTags: [],
	nameKey: "games.machikoro2.name",
	descKey: "games.machikoro2.desc",
	rulesKey: "games.machikoro2.rules",
	icon: "🎲",
	iconImg: "games/machikoro2.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/machikoro2/en.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#0d9488",
	releasedAt: "2026-09-21",
	search: {
		py: "tou zi jie",
		init: "tzj"
	},
	hotseat: "open"
}, F = n.enum([...ne, ...re]), I = n.enum([...ie, ...ae]), oe = n.union([F, I]), L = n.string(), se = n.discriminatedUnion("type", [
	n.object({
		type: n.literal("roll"),
		dice: n.union([n.literal(1), n.literal(2)])
	}),
	n.object({
		type: n.literal("build"),
		card: oe
	}),
	n.object({ type: n.literal("pass") }),
	n.object({
		type: n.literal("exchange"),
		mine: F,
		from: L,
		theirs: F
	}),
	n.object({ type: n.literal("skipExchange") }),
	n.object({
		type: n.literal("give"),
		card: F
	}),
	n.object({
		type: n.literal("tick"),
		now: n.number()
	})
]), R = n.object({ promo: n.boolean().catch(!1) }).default({ promo: !1 }), z = n.object({
	id: oe,
	count: n.int().min(1)
}), ce = n.object({
	rid: L,
	coins: n.int().nonnegative(),
	est: n.array(F),
	lm: n.array(I)
}), le = n.object({
	promo: n.boolean(),
	phase: n.enum([
		"draft",
		"roll",
		"settle",
		"exchange",
		"give",
		"build",
		"done"
	]),
	draftRound: n.int().min(0).max(3),
	turn: L,
	marketLow: n.array(z),
	marketHigh: n.array(z),
	marketLm: n.array(I),
	deckCounts: n.object({
		low: n.int().nonnegative(),
		high: n.int().nonnegative(),
		lm: n.int().nonnegative()
	}),
	players: n.array(ce),
	dice: n.array(n.int().min(1).max(6)).nullable(),
	giveTo: L.nullable(),
	winner: L.nullable()
}), ue = n.object({}), de = 5, fe = 3, pe = 5, B = {
	roll: (e) => t.banner(e),
	settle: (e) => 900 + e * 150,
	empty: 150,
	exchange: 700
};
function V(e) {
	return e in D;
}
function H(e, t) {
	return e.players.some((n) => e.lm[n].includes(t));
}
function U(e, t) {
	return e.filter((e) => D[e].category === t).length;
}
function me(e, t) {
	for (let [n, r] of Object.entries(k)) if (r === t && H(e, n)) return 1;
	return 0;
}
function W(e, t, n) {
	let r = e.lm[n].length, i = O[t];
	if (t === "loanOffice" && (r !== 0 || e.players.some((t) => t !== n && e.lm[t].length === 0))) return null;
	let a = i.cost[r];
	if (a === void 0) return null;
	let o = a;
	return t !== "loanOffice" && e.lm[n].includes("loanOffice") && (o -= 2), t === "launchPad" && e.players.some((t) => e.lm[t].includes("observatory")) && (o -= 5), Math.max(0, o);
}
function G(e, t) {
	for (; e.length > 0 && t.length < pe;) {
		let n = e.pop(), r = t.find((e) => e.id === n);
		r ? r.count += 1 : t.push({
			id: n,
			count: 1
		});
	}
}
function he(e, t) {
	for (; e.length > 0 && t.length < pe;) {
		let n = e.pop();
		t.includes(n) || t.push(n);
	}
}
function ge(e, t) {
	let n = e.findIndex((e) => e.id === t);
	return n < 0 ? !1 : (--e[n].count, e[n].count === 0 && e.splice(n, 1), !0);
}
function K(e, t, n) {
	n !== 0 && (e[t] = (e[t] ?? 0) + n);
}
function q(e, t, n, r, i) {
	let a = Math.min(r, e.coins[t]);
	return e.coins[t] -= a, e.coins[n] += a, K(i, t, -a), K(i, n, a), a;
}
function _e(t, n, r) {
	let i = 0, a = (t) => {
		for (let n = t.length - 1; n > 0; --n) {
			let a = e(r, i, n + 1);
			i += 1, [t[n], t[a]] = [t[a], t[n]];
		}
		return t;
	}, o = (e, t) => e.flatMap((e) => Array.from({ length: t(e) }, () => e)), s = Object.keys(D), c = a(o(s.filter((e) => D[e].row === "low"), (e) => D[e].count)), l = a(o(s.filter((e) => D[e].row === "high"), (e) => D[e].count)), u = a(o(Object.keys(O).filter((e) => t.promo || !O[e].promo), () => 1)), d = [], f = [], p = [];
	G(c, d), G(l, f), he(u, p);
	let m = {}, h = {}, g = {};
	for (let e of n) m[e] = de, h[e] = [], g[e] = [];
	return {
		state: {
			players: n,
			promo: t.promo,
			seed: r,
			rngCursor: i,
			deckLow: c,
			deckHigh: l,
			deckLm: u,
			marketLow: d,
			marketHigh: f,
			marketLm: p,
			coins: m,
			est: h,
			lm: g,
			turn: 0,
			draftRound: 1,
			phase: "draft",
			settleStage: null,
			beatMs: 0,
			dice: null,
			earned: 0,
			extraTurn: !1,
			winner: null
		},
		fx: []
	};
}
function ve(e, t, n, r) {
	let i = e.players.length, a = e.players[e.turn];
	for (let o = 1; o < i; o += 1) {
		let s = e.players[(e.turn - o + i) % i];
		for (let i of e.est[s]) {
			let o = D[i];
			if (o.color !== "red" || !o.activation.includes(t)) continue;
			let c = q(e, a, s, (o.takeActive ?? 0) + me(e, o.category), n);
			c > 0 && r.push({
				rid: s,
				card: i,
				amount: c
			});
		}
	}
}
function ye(e, t, n, r) {
	let i = e.players.length, a = e.players[e.turn];
	for (let o = 0; o < i; o += 1) {
		let s = e.players[(e.turn + o) % i];
		for (let i of e.est[s]) {
			let o = D[i];
			if (!o.activation.includes(t)) continue;
			let c = 0;
			o.color === "blue" ? c = (o.gain ?? 0) + me(e, o.category) : s === a && o.color === "green" && (c = o.category === "combo" && o.comboOf ? (o.gain ?? 0) * U(e.est[s], o.comboOf) : (o.gain ?? 0) + me(e, o.category)), c > 0 && (e.coins[s] += c, K(n, s, c), s === a && (e.earned += c), r.push({
				rid: s,
				card: i,
				amount: c
			}));
		}
	}
}
function be(e, t, n, r) {
	let i = e.players.length, a = e.players[e.turn], o = !1;
	for (let s of e.est[a]) {
		let c = D[s];
		if (c.color === "purple" && c.activation.includes(t)) {
			if (s === "businessCenter") e.players.some((t) => t !== a && e.est[t].length > 0) && (o = !0);
			else if (s === "stadium") {
				let t = 0;
				for (let r = 1; r < i; r += 1) t += q(e, e.players[(e.turn + r) % i], a, 3, n);
				e.earned += t, t > 0 && r.push({
					rid: a,
					card: s,
					amount: t
				});
			} else if (s === "shoppingDistrict") {
				let t = 0;
				for (let r = 1; r < i; r += 1) {
					let o = e.players[(e.turn + r) % i];
					e.coins[o] > 10 && (t += q(e, o, a, Math.floor(e.coins[o] / 2), n));
				}
				e.earned += t, t > 0 && r.push({
					rid: a,
					card: s,
					amount: t
				});
			}
		}
	}
	return o;
}
function xe(e, t, n) {
	let r = e.players.length, i = e.players[e.turn], a = e.dice, o = a.reduce((e, t) => e + t, 0), s = a.length === 2 && a[0] === a[1];
	if (o === 12 && H(e, "techStartup") && (e.coins[i] += 8, K(t, i, 8), e.earned += 8, n.push({
		rid: i,
		card: "techStartup",
		amount: 8
	})), o === 6 && H(e, "renovationCompany")) {
		let r = U(e.est[i], "food");
		e.coins[i] += r, K(t, i, r), e.earned += r, r > 0 && n.push({
			rid: i,
			card: "renovationCompany",
			amount: r
		});
	}
	if (s && H(e, "temple")) {
		let a = 0;
		for (let n = 1; n < r; n += 1) a += q(e, e.players[(e.turn + n) % r], i, 2, t);
		e.earned += a, a > 0 && n.push({
			rid: i,
			card: "temple",
			amount: a
		});
	}
	if (e.earned === 0 && (a.length === 2 && H(e, "charterhouse") ? (e.coins[i] += 3, K(t, i, 3), n.push({
		rid: i,
		card: "charterhouse",
		amount: 3
	})) : a.length === 1 && H(e, "cityHall") && (e.coins[i] += 2, K(t, i, 2), n.push({
		rid: i,
		card: "cityHall",
		amount: 2
	}))), s && H(e, "amusementPark") && (e.extraTurn = !0), s && H(e, "movingCompany") && e.est[i].length > 0) {
		e.phase = "give";
		return;
	}
	Se(e, t);
}
function Se(e, t) {
	let n = e.players[e.turn];
	e.coins[n] === 0 && (e.coins[n] = 1, K(t, n, 1)), e.phase = "build";
}
function Ce(e) {
	e.dice = null, e.earned = 0, e.extraTurn ? e.extraTurn = !1 : e.turn = (e.turn + 1) % e.players.length, e.phase = "roll";
}
function we(e, t, n) {
	let r = e.players.length, i = e.players[e.turn], a = Array.from({ length: r - 1 }, (t, n) => e.players[(e.turn + n + 1) % r]);
	if (t === "launchPad") return i;
	if (t === "radioTower") e.extraTurn = !0;
	else if (t === "exhibitHall") for (let t of a) e.coins[t] > 10 && q(e, t, i, Math.floor(e.coins[t] / 2), n);
	else if (t === "frenchRestaurant") for (let t of a) q(e, t, i, 2, n);
	else if (t === "museum") for (let t of a) q(e, t, i, 3 * e.lm[t].length, n);
	else if (t === "publisher") for (let t of a) q(e, t, i, U(e.est[t], "shop"), n);
	else if (t === "tvStation") for (let t of a) q(e, t, i, U(e.est[t], "food"), n);
	else if (t === "privateClub") for (let t of a) e.lm[t].length === 2 && q(e, t, i, 5, n);
	else if (t === "park") {
		let t = e.players.reduce((t, n) => t + e.coins[n], 0), i = Math.ceil(t / r);
		for (let t of e.players) K(n, t, i - e.coins[t]), e.coins[t] = i;
	}
	return null;
}
function J(e) {
	return Object.fromEntries(Object.entries(e).filter(([, e]) => e !== 0));
}
function Te(e, t = [], n = !1) {
	let r = J(e);
	return Object.keys(r).length === 0 && t.length === 0 ? [] : [{
		kind: "coins",
		with: n || void 0,
		data: {
			deltas: r,
			hits: t
		}
	}];
}
function Ee(t, n, r) {
	if (t.phase === "done") return { code: "games.machikoro2.errOver" };
	if (n.type === "tick") {
		if (t.phase !== "settle" || !t.settleStage) return {
			state: t,
			fx: []
		};
		let e = structuredClone(t), n = e.dice.reduce((e, t) => e + t, 0), r = {}, i = [], a = e.settleStage;
		return a === "red" ? (ve(e, n, r, i), e.settleStage = "income") : a === "income" ? (ye(e, n, r, i), e.settleStage = "purple") : a === "purple" ? be(e, n, r, i) ? (e.phase = "exchange", e.settleStage = null) : e.settleStage = "landmark" : (xe(e, r, i), e.settleStage = null), e.beatMs = i.length > 0 || Object.keys(J(r)).length > 0 ? B.settle(i.length) : B.empty, {
			state: e,
			fx: Te(r, i)
		};
	}
	let i = t.players[t.turn];
	if (r.by !== i) return { code: "games.machikoro2.errNotYourTurn" };
	if (t.phase === "draft") {
		if (n.type !== "build" && n.type !== "pass") return { code: "games.machikoro2.errBadPhase" };
		let e = structuredClone(t), i = [];
		if (n.type === "build") {
			if (!V(n.card)) return { code: "games.machikoro2.errBadPhase" };
			let t = D[n.card];
			if (e.coins[r.by] < t.cost) return { code: "games.machikoro2.errNoCoins" };
			let a = t.row === "low" ? e.marketLow : e.marketHigh;
			if (!a.some((e) => e.id === n.card)) return { code: "games.machikoro2.errNoCard" };
			e.coins[r.by] -= t.cost, ge(a, n.card), e.est[r.by].push(n.card), G(t.row === "low" ? e.deckLow : e.deckHigh, a), i.push({
				kind: "build",
				rid: r.by,
				data: {
					card: n.card,
					draft: !0
				}
			});
		} else i.push({
			kind: "pass",
			rid: r.by,
			data: { draft: !0 }
		});
		return e.turn = (e.turn + 1) % e.players.length, e.turn === 0 && (e.draftRound += 1, e.draftRound > fe && (e.draftRound = 0, e.phase = "roll")), {
			state: e,
			fx: i
		};
	}
	if (n.type === "roll") {
		if (t.phase !== "roll") return { code: "games.machikoro2.errBadPhase" };
		let i = structuredClone(t);
		i.extraTurn = !1, i.earned = 0;
		let a = i.rngCursor, o = Array.from({ length: n.dice }, () => e(i.seed, a++, 6) + 1);
		return i.rngCursor = a, i.dice = o, i.phase = "settle", i.settleStage = "red", i.beatMs = B.roll(o.length), {
			state: i,
			fx: [{
				kind: "diceRoll",
				rid: r.by,
				data: {
					dice: o,
					banner: !0
				}
			}, {
				kind: "diceTotal",
				with: !0,
				data: {
					dice: o,
					doubles: o.length === 2 && o[0] === o[1]
				}
			}]
		};
	}
	if (n.type === "exchange" || n.type === "skipExchange") {
		if (t.phase !== "exchange") return { code: "games.machikoro2.errBadPhase" };
		let e = structuredClone(t), i = [];
		if (n.type === "exchange") {
			if (n.from === r.by || !e.players.includes(n.from)) return { code: "games.machikoro2.errBadCard" };
			let t = e.est[r.by].indexOf(n.mine), a = e.est[n.from].indexOf(n.theirs);
			if (t < 0 || a < 0) return { code: "games.machikoro2.errBadCard" };
			e.est[r.by].splice(t, 1, n.theirs), e.est[n.from].splice(a, 1, n.mine), i.push({
				kind: "exchange",
				rid: r.by,
				data: {
					mine: n.mine,
					from: n.from,
					theirs: n.theirs
				}
			}), e.beatMs = B.exchange;
		} else e.beatMs = B.empty;
		return e.phase = "settle", e.settleStage = "landmark", {
			state: e,
			fx: i
		};
	}
	if (n.type === "give") {
		if (t.phase !== "give") return { code: "games.machikoro2.errBadPhase" };
		let e = structuredClone(t), i = e.est[r.by].indexOf(n.card);
		if (i < 0) return { code: "games.machikoro2.errBadCard" };
		let a = e.players.length, o = e.players[(e.turn - 1 + a) % a];
		e.est[r.by].splice(i, 1), e.est[o].push(n.card);
		let s = {};
		return Se(e, s), {
			state: e,
			fx: [{
				kind: "give",
				rid: r.by,
				data: {
					card: n.card,
					to: o
				}
			}, ...Te(s, [], !0)]
		};
	}
	if (t.phase !== "build") return { code: "games.machikoro2.errBadPhase" };
	let a = structuredClone(t);
	if (n.type === "pass") {
		let e = {}, t = [];
		return H(a, "airport") && (a.coins[r.by] += 5, K(e, r.by, 5), t.push({
			rid: r.by,
			card: "airport",
			amount: 5
		})), Ce(a), {
			state: a,
			fx: [{
				kind: "pass",
				rid: r.by,
				data: {
					deltas: J(e),
					hits: t
				}
			}]
		};
	}
	if (n.type !== "build") return { code: "games.machikoro2.errBadPhase" };
	let o = {}, s = [];
	if (V(n.card)) {
		let e = D[n.card];
		if (a.coins[r.by] < e.cost) return { code: "games.machikoro2.errNoCoins" };
		let t = e.row === "low" ? a.marketLow : a.marketHigh;
		if (!t.some((e) => e.id === n.card)) return { code: "games.machikoro2.errNoCard" };
		a.coins[r.by] -= e.cost, ge(t, n.card), a.est[r.by].push(n.card), G(e.row === "low" ? a.deckLow : a.deckHigh, t);
	} else {
		if (!a.marketLm.includes(n.card)) return { code: "games.machikoro2.errNoCard" };
		let e = W(a, n.card, r.by);
		if (e === null) return { code: "games.machikoro2.errNoCard" };
		if (a.coins[r.by] < e) return { code: "games.machikoro2.errNoCoins" };
		a.coins[r.by] -= e, a.marketLm = a.marketLm.filter((e) => e !== n.card), a.lm[r.by].push(n.card), he(a.deckLm, a.marketLm);
		let t = we(a, n.card, o);
		t && (a.phase = "done", a.winner = t);
	}
	return a.phase !== "done" && a.lm[r.by].length >= 3 && (a.phase = "done", a.winner = r.by), s.push({
		kind: "build",
		rid: r.by,
		data: {
			card: n.card,
			deltas: J(o),
			hits: (o[r.by] ?? 0) > 0 ? [{
				rid: r.by,
				card: n.card,
				amount: o[r.by]
			}] : []
		}
	}), a.phase === "done" ? s.push({
		kind: "win",
		rid: r.by,
		with: !0
	}) : (a.extraTurn && s.push({
		kind: "extraTurn",
		rid: r.by,
		with: !0
	}), Ce(a)), {
		state: a,
		fx: s
	};
}
function De(e) {
	let t = e.players.length;
	return {
		public: {
			promo: e.promo,
			phase: e.phase,
			draftRound: e.draftRound,
			turn: e.players[e.turn],
			marketLow: e.marketLow,
			marketHigh: e.marketHigh,
			marketLm: e.marketLm,
			deckCounts: {
				low: e.deckLow.length,
				high: e.deckHigh.length,
				lm: e.deckLm.length
			},
			players: e.players.map((t) => ({
				rid: t,
				coins: e.coins[t],
				est: [...e.est[t]],
				lm: [...e.lm[t]]
			})),
			dice: e.dice ? [...e.dice] : null,
			giveTo: e.phase === "give" ? e.players[(e.turn - 1 + t) % t] : null,
			winner: e.winner
		},
		private: {}
	};
}
function Oe(e) {
	if (e.phase !== "done" || !e.winner) return { phase: e.phase };
	let t = e.players.filter((t) => t !== e.winner).sort((t, n) => e.coins[n] - e.coins[t]);
	return {
		phase: "done",
		winner: [e.winner],
		ranking: [e.winner, ...t],
		scores: { ...e.coins }
	};
}
function ke(e) {
	return e.phase === "settle" ? e.beatMs : null;
}
var Ae = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: P,
	schemas: {
		action: se,
		publicView: le,
		privateView: ue,
		config: R
	},
	setup: _e,
	reduce: Ee,
	viewFor: De,
	status: Oe,
	nextTickIn: ke
}, je = {
	red: "mk-card--red",
	blue: "mk-card--blue",
	green: "mk-card--green",
	purple: "mk-card--purple"
}, Me = {
	red: "games.machikoro2.whenRedShort",
	blue: "games.machikoro2.whenBlueShort",
	green: "games.machikoro2.whenGreenShort",
	purple: "games.machikoro2.whenPurpleShort"
};
function Ne(e) {
	if (!V(e)) return null;
	let t = D[e];
	return e === "businessCenter" ? "⇄" : e === "stadium" ? "↙3×" : e === "shoppingDistrict" ? "½" : t.color === "red" ? `↙${t.takeActive ?? 0}` : t.category === "combo" ? `×${t.gain ?? 0}` : `+${t.gain ?? 0}`;
}
function Pe(e) {
	return e.length > 1 ? `${e[0]}–${e[e.length - 1]}` : String(e[0]);
}
function Y({ id: e, size: t, count: n, cost: r, selected: i, available: a, active: s, anchor: c, onPick: u }) {
	let d = l(), { ref: f } = o(c ?? null), p = V(e) ? D[e] : null, m = V(e) ? null : O[e], h = d(p ? j[p.id] : M[e]), v = r === void 0 ? p ? p.cost : m?.cost.join("/") : r, y = p ? A[p.category] : m?.timing === "instant" ? "⚡" : "↻", b = p?.emoji ?? m?.emoji;
	return /* @__PURE__ */ _("button", {
		ref: f,
		type: "button",
		onClick: u,
		"aria-label": `${h}${v == null ? "" : ` · 🪙${v}`}`,
		"aria-pressed": i,
		className: `mk-card ${t === "market" ? "mk-card--market" : "mk-card--city"} ${p ? je[p.color] : "mk-card--landmark"} ${i ? "mk-card--selected" : ""} ${a ? "mk-card--available" : ""} ${s ? "mk-card--active" : ""}`,
		children: [
			/* @__PURE__ */ _("span", {
				className: "mk-card-head",
				children: [/* @__PURE__ */ g("span", {
					className: "mk-card-number font-display tabular-nums",
					children: p ? Pe(p.activation) : "★"
				}), /* @__PURE__ */ g("span", {
					className: "mk-card-category",
					"aria-hidden": !0,
					children: y
				})]
			}),
			/* @__PURE__ */ _("span", {
				className: "mk-card-art",
				"aria-hidden": !0,
				children: [
					b,
					t === "market" && p && /* @__PURE__ */ g("span", {
						className: "mk-card-timing",
						children: d(Me[p.color])
					}),
					t === "market" && Ne(e) && /* @__PURE__ */ g("span", {
						className: "mk-card-reward font-display tabular-nums",
						children: Ne(e)
					})
				]
			}),
			/* @__PURE__ */ g("span", {
				className: "mk-card-name",
				children: h
			}),
			t === "market" && /* @__PURE__ */ _("span", {
				className: "mk-card-cost font-display tabular-nums",
				children: ["🪙 ", v ?? "—"]
			}),
			n !== void 0 && n > 1 && /* @__PURE__ */ _("span", {
				className: "mk-card-stack font-display tabular-nums",
				children: ["×", n]
			}),
			a && t === "market" && /* @__PURE__ */ g("span", {
				className: "mk-card-can-build",
				"aria-hidden": !0,
				children: "✓"
			})
		]
	});
}
//#endregion
//#region src/games/machikoro2/detail.tsx
var Fe = {
	red: "games.machikoro2.whenRed",
	blue: "games.machikoro2.whenBlue",
	green: "games.machikoro2.whenGreen",
	purple: "games.machikoro2.whenPurple"
};
function Ie({ id: e, cost: t, hint: n, onClose: r }) {
	let i = l(), a, o, s;
	if (V(e)) {
		let t = D[e];
		a = `${t.emoji} ${i(j[e])} · ${Pe(t.activation)}`, o = `${i(Fe[t.color])} · 🪙${t.cost}`, s = t.color === "red" ? i("games.machikoro2.effTakeActive", { n: t.takeActive ?? 0 }) : e === "businessCenter" ? i("games.machikoro2.effExchange") : e === "stadium" ? i("games.machikoro2.effTakeAll", { n: 3 }) : e === "shoppingDistrict" ? i("games.machikoro2.effTakeHalf") : t.category === "combo" && t.comboOf ? i("games.machikoro2.effCombo", {
			n: t.gain ?? 0,
			icon: A[t.comboOf]
		}) : i("games.machikoro2.effGainBank", { n: t.gain ?? 0 });
	} else {
		let n = O[e], r = n.timing === "instant" ? "games.machikoro2.lmInstant" : n.scope === "all" ? "games.machikoro2.lmOngoingAll" : "games.machikoro2.lmOngoingBuilder";
		a = `${n.emoji} ${i(M[e])}`, o = `${i(r)} · 🪙${t ?? n.cost.join("/")}`, s = i(N[e]);
	}
	return /* @__PURE__ */ _("div", {
		className: "mk-detail pointer-events-auto mx-1 mb-1 rounded-xl border-2 border-ink bg-surface p-2 shadow-[3px_3px_0_var(--color-ink)]",
		role: "region",
		"aria-label": a,
		children: [
			/* @__PURE__ */ _("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ _("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ g("p", {
						className: "mk-detail-title truncate text-xs font-black",
						children: a
					}), /* @__PURE__ */ g("p", {
						className: "mk-detail-info text-[10px] font-bold text-ink/60",
						children: o
					})]
				}), /* @__PURE__ */ g("button", {
					type: "button",
					onClick: r,
					"aria-label": i("games.machikoro2.cancel"),
					className: "grid size-11 flex-none place-items-center rounded border border-ink/40 bg-paper text-lg font-black",
					children: "×"
				})]
			}),
			/* @__PURE__ */ g("p", {
				className: "mk-detail-effect mt-1 text-[11px] leading-4",
				children: s
			}),
			n && /* @__PURE__ */ g("p", {
				className: "mk-detail-hint mt-1 rounded bg-warn-soft px-1.5 py-0.5 text-[11px] font-bold text-warn-ink",
				children: n
			})
		]
	});
}
//#endregion
//#region src/games/machikoro2/view-player.tsx
function Le(e) {
	let t = e.public;
	return /* @__PURE__ */ g(Re, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Re({ pub: e, members: t, myRid: n, send: r }) {
	let i = l(), o = (e) => t.find((t) => t.rid === e)?.name ?? e, c = e.phase !== "done" && e.turn === n, m = e.players.find((e) => e.rid === n), h = e.phase === "build" || e.phase === "draft", [v, y] = a(null), [b, x] = a(null), [S, C] = a(null), [w, T] = a(null), E = `${e.phase}:${e.turn}:${e.draftRound}:${e.dice?.join(",") ?? ""}`, [ee, te] = a(E);
	ee !== E && (te(E), x(null), C(null), T(null), e.turn !== n && y(null));
	let ne = {
		players: e.players.map((e) => e.rid),
		lm: Object.fromEntries(e.players.map((e) => [e.rid, e.lm]))
	}, re = (e) => W(ne, e, n), ie = (e) => V(e) ? D[e].cost : re(e), ae = (t) => e.marketLow.some((e) => e.id === t) || e.marketHigh.some((e) => e.id === t) || e.marketLm.includes(t), O = (t) => {
		if (!c || !h || !m || !ae(t) || !V(t) && e.phase === "draft") return !1;
		let n = ie(t);
		return n !== null && n <= m.coins;
	}, k = c && e.phase === "give" || c && e.phase === "exchange" && S === null ? n : v ?? n, A = e.players.find((e) => e.rid === k), M = b?.source === "market" ? b.id : null, N = b?.source === "city" ? b.id : null, F = M ? ie(M) : null, I = (e) => x((t) => t?.id === e && t.source === "market" ? null : {
		id: e,
		source: "market"
	}), oe = (t) => {
		if (!(c && e.phase === "give")) {
			if (c && e.phase === "exchange") {
				if (S === null) return;
				y(t === n ? null : t), T(null);
			} else y(t === n || t === v ? null : t);
			x(null);
		}
	}, L = (t) => {
		if (c && e.phase === "exchange") {
			k === n ? (C(t), T(null), y(null)) : S !== null && T(t), x(null);
			return;
		}
		x((e) => e?.id === t && e.source === "city" ? null : {
			id: t,
			source: "city"
		});
	}, se = "info", R = i("games.machikoro2.waitTurn", { name: o(e.turn) }), z, ce = e.phase === "draft" ? i("games.machikoro2.phaseDraft", { n: e.draftRound }) : void 0;
	e.phase === "done" ? (se = "done", R = i("games.machikoro2.over")) : e.phase === "settle" ? R = i("games.machikoro2.settling") : c && (se = "accent", e.phase === "roll" ? R = i("games.machikoro2.yourRoll") : e.phase === "exchange" ? (ce = S === null ? "1/3" : v === null ? "2/3" : "3/3", R = S === null ? i("games.machikoro2.exchangePickMine") : v === null ? i("games.machikoro2.exchangePickPlayer") : i("games.machikoro2.exchangePickTheirs", { name: o(v) }), S && w && v && (z = i("games.machikoro2.exchangeReady", {
		mine: i(j[S]),
		theirs: i(j[w]),
		name: o(v)
	}))) : e.phase === "give" ? (R = i("games.machikoro2.giveTitle", { name: o(e.giveTo ?? "") }), N && V(N) && (z = i("games.machikoro2.giveReady", {
		card: i(j[N]),
		name: o(e.giveTo ?? "")
	}))) : R = i("games.machikoro2.buildPhase"));
	let le;
	c && h && M && !O(M) && (le = !V(M) && e.phase === "draft" ? i("games.machikoro2.draftNoLandmark") : F === null ? i("games.machikoro2.landmarkUnavailable") : i("games.machikoro2.needCoins", { n: Math.max(0, F - (m?.coins ?? 0)) }));
	let ue = e.dice?.reduce((e, t) => e + t, 0) ?? null;
	return /* @__PURE__ */ g("div", {
		className: "mk-game h-full min-h-0",
		children: /* @__PURE__ */ g(d, {
			adaptive: !0,
			banner: /* @__PURE__ */ _("div", {
				className: "mk-top flex flex-col gap-1.5",
				children: [/* @__PURE__ */ g(f, {
					tone: se,
					text: R,
					sub: z,
					chip: ce,
					accent: P.accent
				}), /* @__PURE__ */ g("div", {
					className: "mk-seats min-w-0",
					children: /* @__PURE__ */ g(p, {
						variant: "plate",
						members: t,
						myRid: n,
						anchorOf: (e) => `seat:${e}`,
						onPick: oe,
						picked: (e) => v === e,
						action: (t) => e.phase !== "done" && t === e.turn ? "pending" : null,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ _("span", {
								className: "mk-seat-status flex items-center gap-1.5 text-xs leading-4.5 font-bold",
								children: [/* @__PURE__ */ _("span", {
									className: "flex items-center gap-0.5",
									children: ["🪙 ", /* @__PURE__ */ g(s, {
										value: n.coins,
										className: "font-mono tabular-nums"
									})]
								}), /* @__PURE__ */ g("span", { children: i("games.machikoro2.landmarksChip", { n: n.lm.length }) })]
							}) : null;
						}
					})
				})]
			}),
			scroll: !1,
			actionsHeight: "mk-actions-height",
			actions: /* @__PURE__ */ _("div", {
				className: "mk-action-dock flex h-full items-center px-2",
				children: [
					c && e.phase === "roll" && /* @__PURE__ */ _("div", {
						className: "grid w-full grid-cols-2 gap-2",
						children: [/* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => r({
								type: "roll",
								dice: 1
							}),
							className: "btn-base flex-col gap-0 bg-surface px-1 text-ink",
							children: [/* @__PURE__ */ _("span", { children: ["🎲 ", i("games.machikoro2.rollOne")] }), /* @__PURE__ */ g("span", {
								className: "font-mono text-[10px] leading-3",
								children: "1–6"
							})]
						}), /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => r({
								type: "roll",
								dice: 2
							}),
							className: "btn-base flex-col gap-0 px-1 text-white",
							style: { background: P.accent },
							children: [/* @__PURE__ */ _("span", { children: ["🎲🎲 ", i("games.machikoro2.rollTwo")] }), /* @__PURE__ */ g("span", {
								className: "font-mono text-[10px] leading-3",
								children: "2–12"
							})]
						})]
					}),
					c && h && /* @__PURE__ */ _("div", {
						className: "grid w-full grid-cols-2 gap-2",
						children: [/* @__PURE__ */ _("button", {
							type: "button",
							disabled: !M || !O(M),
							onClick: () => M && r({
								type: "build",
								card: M
							}),
							className: "btn-base text-white disabled:cursor-not-allowed disabled:opacity-40",
							style: { background: P.accent },
							children: ["🔨 ", i("games.machikoro2.build")]
						}), /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => r({ type: "pass" }),
							className: "btn-quiet bg-surface text-xs",
							children: i(e.players.some((e) => e.lm.includes("airport")) ? "games.machikoro2.passAirport" : "games.machikoro2.pass")
						})]
					}),
					c && e.phase === "exchange" && /* @__PURE__ */ _("div", {
						className: "grid w-full grid-cols-2 gap-2",
						children: [/* @__PURE__ */ _("button", {
							type: "button",
							disabled: !S || !w || !v,
							onClick: () => S && w && v && r({
								type: "exchange",
								mine: S,
								from: v,
								theirs: w
							}),
							className: "btn-base text-white disabled:cursor-not-allowed disabled:opacity-40",
							style: { background: P.accent },
							children: ["🔄 ", i("games.machikoro2.exchangeConfirm")]
						}), /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => r({ type: "skipExchange" }),
							className: "btn-quiet bg-surface",
							children: i("games.machikoro2.exchangeSkip")
						})]
					}),
					c && e.phase === "give" && /* @__PURE__ */ _("button", {
						type: "button",
						disabled: !N || !V(N) || !m?.est.includes(N),
						onClick: () => N && V(N) && r({
							type: "give",
							card: N
						}),
						className: "btn-base w-full text-white disabled:cursor-not-allowed disabled:opacity-40",
						style: { background: P.accent },
						children: ["🚚 ", i("games.machikoro2.giveConfirm")]
					})
				]
			}),
			overlay: b && /* @__PURE__ */ g(Ie, {
				id: b.id,
				cost: F,
				hint: le,
				onClose: () => x(null)
			}),
			children: /* @__PURE__ */ _("div", {
				className: "mk-board relative flex h-full min-h-0 flex-col overflow-hidden p-1.5",
				children: [/* @__PURE__ */ g(u, {
					kind: "sheen",
					base: "var(--color-felt)",
					className: "pointer-events-none absolute inset-0"
				}), /* @__PURE__ */ _("div", {
					className: "mk-table-layout relative flex min-h-0 flex-1 flex-col gap-1 wide:short:flex-row",
					children: [/* @__PURE__ */ _("div", {
						className: "mk-sidebar contents wide:short:flex wide:short:w-44 wide:short:flex-none wide:short:flex-col wide:short:gap-1",
						children: [/* @__PURE__ */ g(Ve, { dice: e.dice }), /* @__PURE__ */ _("div", {
							className: "mk-city-board order-2 flex-none p-1 wide:short:min-h-0 wide:short:flex-1",
							children: [
								/* @__PURE__ */ _("div", {
									className: "mk-city-skyline",
									"aria-hidden": !0,
									children: [
										/* @__PURE__ */ g("i", {}),
										/* @__PURE__ */ g("i", {}),
										/* @__PURE__ */ g("i", {}),
										/* @__PURE__ */ g("i", {}),
										/* @__PURE__ */ g("i", {})
									]
								}),
								/* @__PURE__ */ _("div", {
									className: "mk-city-header mb-1 flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ g("span", {
										className: "truncate text-xs font-black",
										children: k === n ? i("games.machikoro2.myCity") : i("games.machikoro2.cityOf", { name: o(k) })
									}), /* @__PURE__ */ g("span", {
										className: "mk-landmark-track flex flex-none gap-0.5",
										"aria-label": i("games.machikoro2.landmarksChip", { n: A?.lm.length ?? 0 }),
										children: [
											0,
											1,
											2
										].map((e) => /* @__PURE__ */ g("span", {
											className: e < (A?.lm.length ?? 0) ? "mk-landmark-slot mk-landmark-slot--built" : "mk-landmark-slot",
											"aria-hidden": !0,
											children: "★"
										}, e))
									})]
								}),
								A && /* @__PURE__ */ g(He, {
									rid: k,
									playerRid: n,
									est: A.est,
									lm: A.lm,
									selected: N,
									mine: S,
									target: w,
									active: (t, n) => {
										if (ue === null || !D[t].activation.includes(ue)) return !1;
										let r = D[t].color;
										return r === "blue" || (r === "red" ? e.turn !== n : e.turn === n);
									},
									onTapEst: L,
									onTapLm: (e) => x((t) => t?.id === e && t.source === "city" ? null : {
										id: e,
										source: "city"
									})
								})
							]
						})]
					}), /* @__PURE__ */ g("div", {
						className: "mk-market-scroll mk-scrollbar-none order-1 min-h-0 flex-1 overflow-y-auto wide:short:order-none",
						children: /* @__PURE__ */ _("div", {
							className: "mk-market-content",
							children: [
								/* @__PURE__ */ g(Be, {
									kind: "low",
									label: i("games.machikoro2.marketLow"),
									deckLeft: e.deckCounts.low,
									children: e.marketLow.map((e) => /* @__PURE__ */ g(Y, {
										id: e.id,
										size: "market",
										count: e.count,
										selected: M === e.id,
										available: O(e.id),
										anchor: `mkt:${e.id}`,
										onPick: () => I(e.id)
									}, e.id))
								}),
								/* @__PURE__ */ g(Be, {
									kind: "high",
									label: i("games.machikoro2.marketHigh"),
									deckLeft: e.deckCounts.high,
									children: e.marketHigh.map((e) => /* @__PURE__ */ g(Y, {
										id: e.id,
										size: "market",
										count: e.count,
										selected: M === e.id,
										available: O(e.id),
										anchor: `mkt:${e.id}`,
										onPick: () => I(e.id)
									}, e.id))
								}),
								/* @__PURE__ */ g(Be, {
									kind: "landmark",
									label: i("games.machikoro2.marketLandmark"),
									deckLeft: e.deckCounts.lm,
									children: e.marketLm.map((e) => /* @__PURE__ */ g(Y, {
										id: e,
										size: "market",
										cost: re(e),
										selected: M === e,
										available: O(e),
										anchor: `mkt:${e}`,
										onPick: () => I(e)
									}, e))
								})
							]
						})
					})]
				})]
			})
		})
	});
}
var ze = {
	landmark: "mk-market-row--landmark",
	high: "mk-market-row--high",
	low: "mk-market-row--low"
};
function Be({ kind: e, label: t, deckLeft: n, children: r }) {
	let i = l();
	return /* @__PURE__ */ _("section", {
		className: `mk-market-row ${ze[e]}`,
		children: [/* @__PURE__ */ _("div", {
			className: "mk-market-heading flex items-center justify-between px-1.5",
			children: [/* @__PURE__ */ g("span", {
				className: "font-display text-xs font-black",
				children: t
			}), /* @__PURE__ */ _("span", {
				className: "mk-deck-count flex items-center gap-1 font-mono text-[10px] font-black tabular-nums",
				children: [/* @__PURE__ */ g("span", {
					className: "mk-deck-stack",
					"aria-hidden": !0
				}), i("games.machikoro2.deckLeft", { n })]
			})]
		}), /* @__PURE__ */ g("div", {
			className: "mk-market-cards mk-scrollbar-none flex gap-1.5 overflow-x-auto px-2 pb-3 pt-3",
			children: r
		})]
	});
}
function Ve({ dice: e }) {
	let t = l(), { ref: n, hidden: r } = o("dice"), { ref: i, hidden: a } = o("dice-faces"), s = e?.reduce((e, t) => e + t, 0);
	return /* @__PURE__ */ _("div", {
		ref: n,
		className: `mk-dice-tray flex h-11 flex-none items-center gap-1.5 px-2 ${r ? "opacity-0" : ""}`,
		children: [
			/* @__PURE__ */ _("span", {
				className: "mk-dice-label mr-1 text-[11px] font-extrabold",
				children: ["🎲 ", t("games.machikoro2.dicePlaza")]
			}),
			/* @__PURE__ */ g("span", {
				ref: i,
				className: `mk-dice-faces inline-flex flex-none items-center gap-1.5 ${a ? "opacity-0" : ""}`,
				children: e ? e.map((e, t) => /* @__PURE__ */ g("span", {
					className: "mk-dice-face grid size-7 place-items-center rounded border-2 border-ink bg-surface font-display text-base font-black tabular-nums",
					children: e
				}, t)) : /* @__PURE__ */ g("span", {
					className: "font-display text-sm font-extrabold text-ink/45",
					children: "—"
				})
			}),
			e && /* @__PURE__ */ _("span", {
				className: "mk-dice-total font-display text-base font-black tabular-nums",
				children: ["= ", s]
			}),
			e?.length === 2 && e[0] === e[1] && /* @__PURE__ */ g("span", {
				className: "mk-dice-doubles ml-auto rounded border border-ink bg-warn-soft px-1 text-[11px] font-extrabold text-warn-ink",
				children: t("games.machikoro2.doubles")
			})
		]
	});
}
function He({ rid: e, playerRid: t, est: n, lm: r, selected: i, mine: a, target: o, active: s, onTapEst: c, onTapLm: l }) {
	let u = [];
	for (let e of n) {
		let t = u.find((t) => t.id === e);
		t ? t.count++ : u.push({
			id: e,
			count: 1
		});
	}
	return /* @__PURE__ */ _("div", {
		className: "mk-city-cards mk-scrollbar-none flex min-h-20 gap-1.5 overflow-x-auto px-1 pb-1 pt-1",
		children: [
			r.map((t) => /* @__PURE__ */ g(Y, {
				id: t,
				size: "city",
				selected: i === t,
				anchor: `citycard:${e}:${t}`,
				onPick: () => l(t)
			}, `${e}:${t}`)),
			u.map((n) => /* @__PURE__ */ g(Y, {
				id: n.id,
				size: "city",
				count: n.count,
				selected: i === n.id || e === t && a === n.id || e !== t && o === n.id,
				active: s(n.id, e),
				anchor: `citycard:${e}:${n.id}`,
				onPick: () => c(n.id)
			}, `${e}:${n.id}`)),
			n.length === 0 && r.length === 0 && /* @__PURE__ */ g("span", {
				className: "self-center px-2 text-xs text-ink/50",
				children: "—"
			})
		]
	});
}
//#endregion
//#region src/games/machikoro2/bot.ts
function Ue(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var We = [
	0,
	0,
	1,
	2,
	3,
	4,
	5,
	6,
	5,
	4,
	3,
	2,
	1
].map((e) => e / 36), Ge = [
	0,
	1,
	1,
	1,
	1,
	1,
	1
].map((e) => e / 6);
function Ke(e, t) {
	let n = t === 1 ? Ge : We;
	return e.reduce((e, t) => e + (n[t] ?? 0), 0);
}
function qe(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n) return null;
	let r = Object.fromEntries(e.players.map((e) => [e.rid, e.lm]));
	return {
		pub: e,
		me: n,
		n: e.players.length,
		lmOf: r,
		rids: e.players.map((e) => e.rid)
	};
}
function X(e, t) {
	return Object.entries(k).some(([n, r]) => r === t && e.rids.some((t) => e.lmOf[t].includes(n)));
}
function Je(e, t) {
	return e.filter((e) => D[e].category === t).length;
}
function Z(e, t, n) {
	let r = D[t], i = Ke(r.activation, 2), a = Ke(r.activation, 1), o = Math.max(a, i);
	return r.color === "blue" ? o * ((r.gain ?? 0) + +!!X(e, r.category)) * e.n : r.color === "green" ? o * (r.category === "combo" && r.comboOf ? (r.gain ?? 0) * Math.max(1, Je(n, r.comboOf)) : (r.gain ?? 0) + +!!X(e, r.category)) : r.color === "red" ? o * ((r.takeActive ?? 0) + +!!X(e, r.category)) * (e.n - 1) * .8 : t === "stadium" ? o * 3 * (e.n - 1) * .7 : t === "shoppingDistrict" ? o * 4 : o * 2;
}
function Ye(e, t) {
	let n = [];
	for (let r of [e.pub.marketLow, e.pub.marketHigh]) for (let i of r) {
		if (!V(i.id)) continue;
		let r = D[i.id];
		r.cost > t || n.push({
			id: i.id,
			score: Z(e, i.id, e.me.est) / r.cost
		});
	}
	return n.sort((e, t) => t.score - e.score);
}
function Xe(e) {
	let t = {
		players: e.rids,
		lm: e.lmOf
	};
	for (let n of e.pub.marketLm) {
		let r = W(t, n, e.me.rid);
		if (!(r === null || r > e.me.coins) && (n === "launchPad" || e.me.lm.length === 2)) return n;
	}
	return null;
}
function Ze(e) {
	let t = (t) => e.me.est.reduce((n, r) => {
		let i = D[r], a = Ke(i.activation, t);
		return i.color === "blue" ? n + a * ((i.gain ?? 0) + +!!X(e, i.category)) : i.color === "green" ? n + a * (i.category === "combo" && i.comboOf ? (i.gain ?? 0) * Math.max(1, Je(e.me.est, i.comboOf)) : (i.gain ?? 0) + +!!X(e, i.category)) : i.color === "purple" ? n + a * (r === "stadium" ? 2 * (e.n - 1) : 3) : n;
	}, 0);
	return {
		type: "roll",
		dice: t(2) > t(1) ? 2 : 1
	};
}
function Qe(e, t) {
	let n = {
		players: e.rids,
		lm: e.lmOf
	}, r = Xe(e);
	if (r) return {
		type: "build",
		card: r
	};
	if (t) {
		let t = [];
		for (let n of [...e.pub.marketLow, ...e.pub.marketHigh]) V(n.id) && D[n.id].cost <= e.me.coins && t.push(n.id);
		let r = e.pub.marketLm.filter((t) => {
			let r = W(n, t, e.me.rid);
			return r !== null && r <= e.me.coins;
		}), i = [...t, ...r];
		return i.length > 0 && crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 100 < 70 ? {
			type: "build",
			card: Ue(i)
		} : { type: "pass" };
	}
	let i = e.pub.players.some((t) => t.rid !== e.me.rid && t.lm.length >= 2), a = e.pub.marketLm.map((t) => ({
		id: t,
		cost: W(n, t, e.me.rid)
	})).filter((t) => t.cost !== null && t.cost <= e.me.coins).sort((e, t) => e.cost - t.cost);
	if (a.length > 0 && (i || e.me.coins - a[0].cost >= 6 || e.me.lm.length === 1)) return {
		type: "build",
		card: a[0].id
	};
	let o = Ye(e, e.me.coins);
	return o.length > 0 && o[0].score >= .35 ? {
		type: "build",
		card: o[0].id
	} : { type: "pass" };
}
var $e = (e, t) => {
	let n = e.public;
	if (n.phase === "done" || n.phase === "settle" || n.turn !== t.rid) return null;
	let r = t.difficulty === "weak", i = qe(n, t.rid);
	if (!i) return null;
	if (n.phase === "draft") {
		if (r) {
			let e = [...n.marketLow, ...n.marketHigh].filter((e) => V(e.id) && D[e.id].cost <= i.me.coins);
			return e.length === 0 ? { action: { type: "pass" } } : { action: {
				type: "build",
				card: Ue(e).id
			} };
		}
		let e = Ye(i, i.me.coins);
		return e.length === 0 ? { action: { type: "pass" } } : { action: {
			type: "build",
			card: e[0].id
		} };
	}
	if (n.phase === "roll") return r ? { action: {
		type: "roll",
		dice: crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 2 == 0 ? 1 : 2
	} } : { action: Ze(i) };
	if (n.phase === "exchange") {
		if (r) return { action: { type: "skipExchange" } };
		let e = [...i.me.est].sort((e, t) => Z(i, e, i.me.est) - Z(i, t, i.me.est))[0], a = null;
		for (let e of n.players) if (e.rid !== t.rid) for (let t of e.est) {
			let n = Z(i, t, i.me.est);
			(!a || n > a.v) && (a = {
				from: e.rid,
				id: t,
				v: n
			});
		}
		return e && a && a.v > Z(i, e, i.me.est) + .5 ? { action: {
			type: "exchange",
			mine: e,
			from: a.from,
			theirs: a.id
		} } : { action: { type: "skipExchange" } };
	}
	if (n.phase === "give") {
		let e = [...i.me.est].sort((e, t) => Z(i, e, i.me.est) - Z(i, t, i.me.est))[0];
		return { action: {
			type: "give",
			card: r ? Ue(i.me.est) : e
		} };
	}
	return { action: Qe(i, r) };
};
function et(e) {
	return V(e) ? j[e] : M[e];
}
var tt = (e, t, n) => {
	let r = (e) => t.public.players.find((t) => t.rid === e)?.rid ?? e;
	return e.type === "roll" ? n(e.dice === 1 ? "games.machikoro2.hintRollOne" : "games.machikoro2.hintRollTwo") : e.type === "build" ? n("games.machikoro2.hintBuild", { name: n(et(e.card)) }) : e.type === "pass" ? n("games.machikoro2.hintPass") : e.type === "exchange" ? n("games.machikoro2.hintExchange", {
		mine: n(j[e.mine]),
		name: r(e.from),
		theirs: n(j[e.theirs])
	}) : e.type === "skipExchange" ? n("games.machikoro2.hintSkipExchange") : e.type === "give" ? n("games.machikoro2.hintGive", {
		name: n(j[e.card]),
		to: r(t.public.giveTo ?? "")
	}) : "";
};
//#endregion
//#region src/games/machikoro2/fx.tsx
function Q(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function $(e) {
	let t = V(e) ? D[e].emoji : O[e].emoji;
	return /* @__PURE__ */ g("span", {
		className: "grid size-8 place-items-center rounded-lg border-2 border-ink bg-surface text-base shadow-[2px_2px_0_var(--color-ink)]",
		children: t
	});
}
function nt(e, t, n) {
	let r = n.queued > 0 ? 60 : 150, i = {}, a = [];
	return t.forEach((e, t) => {
		if (e.amount <= 0) return;
		let o = n.anchor(`citycard:${e.rid}:${e.card}`);
		o && (i[e.rid] = (i[e.rid] ?? 0) + e.amount, a.push(/* @__PURE__ */ g(C, {
			at: o,
			ms: 600,
			delay: t * r
		}, `p${t}`), /* @__PURE__ */ g(x, {
			at: o,
			ms: 800,
			delay: t * r,
			children: /* @__PURE__ */ _("span", {
				className: "text-done-ink",
				children: [
					"+",
					e.amount,
					" 🪙"
				]
			})
		}, `f${t}`)));
	}), Object.entries(e).forEach(([e, o], s) => {
		let c = o - (i[e] ?? 0), l = Q(n, e);
		l && c !== 0 && a.push(/* @__PURE__ */ g(x, {
			at: l,
			ms: 900,
			delay: t.length * r + s * 60,
			children: /* @__PURE__ */ _("span", {
				className: c > 0 ? "text-done-ink" : "text-danger-ink",
				children: [
					c > 0 ? "+" : "",
					c,
					" 🪙"
				]
			})
		}, `s${e}`));
	}), {
		nodes: a,
		spanMs: 700 + t.length * r
	};
}
var rt = y(), it = {
	diceRoll(e, t) {
		let n = t.anchor("dice-faces"), r = rt(e, {
			...t,
			anchor: (e) => e === "dice" ? n ?? t.anchor(e) : t.anchor(e)
		});
		return r && {
			...r,
			hide: r.hide?.map((e) => e === "dice" && n ? "dice-faces" : e)
		};
	},
	diceTotal(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.dice)) return null;
		let r = t.anchor("dice");
		if (!r) return null;
		let i = n.dice, a = n.doubles === !0, o = i.reduce((e, t) => e + t, 0), s = t.queued > 0, c = s ? 400 : v.banner(i.length) - v.fly - 100, l = s ? 450 : v.fly + 100;
		return {
			ms: c + l,
			node: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(x, {
				at: r,
				ms: l,
				delay: c,
				children: /* @__PURE__ */ _("span", {
					className: "rounded-lg border-2 border-ink bg-warn-soft px-2 py-0.5 font-mono text-lg font-black tabular-nums text-warn-ink shadow-[2px_2px_0_var(--color-ink)]",
					children: ["= ", o]
				})
			}), a && /* @__PURE__ */ g(C, {
				at: r,
				ms: l,
				delay: c
			})] })
		};
	},
	coins(e, t) {
		let n = e.data;
		if (!n?.deltas || typeof n.deltas != "object") return null;
		let r = n.deltas, i = Array.isArray(n.hits) ? n.hits : [];
		if (Object.values(r).every((e) => e === 0) && i.length === 0) return null;
		let { nodes: a, spanMs: o } = nt(r, i, t);
		return a.length ? {
			ms: t.queued > 0 ? o + 200 : B.settle(i.length),
			node: /* @__PURE__ */ g(h, { children: a })
		} : null;
	},
	build(e, t) {
		let n = e.data;
		if (typeof n?.card != "string") return null;
		let r = n.card, i = t.anchor(`mkt:${r}`), a = Q(t, e.rid);
		if (!a) return null;
		let o = Array.isArray(n.hits) ? n.hits : [], { nodes: s, spanMs: c } = nt(n.deltas ?? {}, o, t);
		return {
			ms: Math.max(550, c + 200),
			node: /* @__PURE__ */ _(h, { children: [i ? /* @__PURE__ */ g(S, {
				from: i,
				to: a,
				ms: 450,
				children: $(r)
			}) : /* @__PURE__ */ g(C, {
				at: a,
				ms: 500
			}), s] })
		};
	},
	pass(e, t) {
		let n = e.data;
		if (!n?.deltas || typeof n.deltas != "object") return null;
		let r = n.deltas, i = Array.isArray(n.hits) ? n.hits : [];
		if (Object.values(r).every((e) => e === 0) && i.length === 0) return null;
		let { nodes: a, spanMs: o } = nt(r, i, t);
		return a.length ? {
			ms: o,
			node: /* @__PURE__ */ g(h, { children: a })
		} : null;
	},
	exchange(e, t) {
		let n = e.data;
		if (typeof n?.mine != "string" || typeof n.from != "string" || typeof n.theirs != "string") return null;
		let r = Q(t, e.rid), i = Q(t, n.from);
		return !r || !i ? null : {
			ms: 650,
			node: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(S, {
				from: r,
				to: i,
				ms: 550,
				children: $(n.mine)
			}), /* @__PURE__ */ g(S, {
				from: i,
				to: r,
				ms: 550,
				children: $(n.theirs)
			})] })
		};
	},
	give(e, t) {
		let n = e.data;
		if (typeof n?.card != "string" || typeof n.to != "string") return null;
		let r = Q(t, e.rid), i = Q(t, n.to);
		return !r || !i ? null : {
			ms: 600,
			node: /* @__PURE__ */ g(S, {
				from: r,
				to: i,
				ms: 500,
				children: $(n.card)
			})
		};
	},
	extraTurn(e, t) {
		let n = Q(t, e.rid);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ g(C, {
				at: n,
				ms: 700
			})
		} : null;
	},
	win() {
		return {
			ms: 600,
			node: /* @__PURE__ */ g(b, {
				ms: 600,
				className: "bg-warn"
			})
		};
	}
};
//#endregion
//#region src/games/machikoro2/game-over.tsx
function at({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = t, s = l(), u = c((e) => e.locale), d = o.players.find((t) => e.winner.includes(t.rid)), f = n.find((e) => e.rid === d?.rid), p = f ? m(f, u) : d?.rid ?? "", h = o.players.filter((e) => e.rid !== d?.rid), v = i ?? a;
	return /* @__PURE__ */ g("div", {
		className: "mk-over",
		children: /* @__PURE__ */ _("div", {
			className: "mk-over-layout",
			children: [
				/* @__PURE__ */ g(E, {}),
				/* @__PURE__ */ _("header", {
					className: "mk-over-heading",
					children: [/* @__PURE__ */ g("span", {
						"aria-hidden": !0,
						children: "👑"
					}), /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("h1", { children: s("games.machikoro2.resultWinner", { name: p }) }), /* @__PURE__ */ g("p", { children: s(d?.lm.includes("launchPad") ? "games.machikoro2.resultLaunchPad" : "games.machikoro2.resultThreeLandmarks") })] })]
				}),
				/* @__PURE__ */ _("div", {
					className: "mk-over-main",
					"data-players": o.players.length,
					children: [d && /* @__PURE__ */ g(ot, {
						player: d,
						winner: !0,
						members: n,
						myRid: r
					}), /* @__PURE__ */ g("div", {
						className: "mk-over-others",
						children: h.map((e) => /* @__PURE__ */ g(ot, {
							player: e,
							members: n,
							myRid: r
						}, e.rid))
					})]
				}),
				v ? /* @__PURE__ */ _("div", {
					className: "mk-over-actions safe-b",
					children: [i && /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-base text-white",
						style: { background: P.accent },
						onClick: i,
						children: s("session.result.playAgain")
					}), a && /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-quiet bg-surface",
						onClick: a,
						children: s("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ g("p", {
					className: "mk-over-wait safe-b",
					children: s("session.result.waitHost")
				})
			]
		})
	});
}
function ot({ player: e, winner: t = !1, members: n, myRid: r }) {
	let i = l(), a = c((e) => e.locale), o = n.find((t) => t.rid === e.rid), s = o ? m(o, a) : e.rid, u = T[(o?.colorIndex ?? 0) % T.length].hex, d = /* @__PURE__ */ new Map();
	for (let t of e.est) d.set(t, (d.get(t) ?? 0) + 1);
	return /* @__PURE__ */ _("section", {
		className: `mk-over-city${t ? " mk-over-city--winner" : ""}`,
		style: { "--mk-player": u },
		children: [/* @__PURE__ */ _("header", {
			className: "mk-over-person",
			children: [
				/* @__PURE__ */ g("span", {
					className: "mk-over-avatar",
					children: o && /* @__PURE__ */ g("img", {
						src: w[o.avatar % w.length],
						alt: ""
					})
				}),
				/* @__PURE__ */ _("div", {
					className: "mk-over-name",
					children: [/* @__PURE__ */ g("h2", {
						title: s,
						children: s
					}), e.rid === r && /* @__PURE__ */ g("small", { children: i("lobby.you") })]
				}),
				/* @__PURE__ */ _("div", {
					className: "mk-over-coins",
					children: [/* @__PURE__ */ g("small", { children: i("games.machikoro2.resultCoins") }), /* @__PURE__ */ _("strong", {
						className: "font-mono tabular-nums",
						children: ["🪙 ", e.coins]
					})]
				})
			]
		}), /* @__PURE__ */ _("div", {
			className: "mk-over-city-body",
			children: [
				/* @__PURE__ */ g("h3", { children: i("games.machikoro2.resultLandmarks", { n: e.lm.length }) }),
				/* @__PURE__ */ g("div", {
					className: "mk-over-landmarks",
					children: e.lm.map((e) => /* @__PURE__ */ _("div", {
						className: "mk-over-landmark",
						children: [/* @__PURE__ */ g("span", {
							"aria-hidden": !0,
							children: O[e].emoji
						}), /* @__PURE__ */ g("strong", { children: i(M[e]) })]
					}, e))
				}),
				/* @__PURE__ */ g("h3", { children: i("games.machikoro2.resultEstablishments", { n: e.est.length }) }),
				/* @__PURE__ */ g(st, { groups: [...d] })
			]
		})]
	});
}
function st({ groups: e }) {
	let t = l(), n = i(null), [o, s] = a(null);
	return r(() => {
		let t = n.current, r = t?.closest(".mk-over");
		if (!t || !r) return;
		let i = () => {
			if (!(matchMedia("(orientation: landscape)").matches && r.clientWidth >= 960 && r.clientHeight >= 600) || e.length === 0) {
				s((e) => e === null ? e : null);
				return;
			}
			let n = getComputedStyle(t), i = parseFloat(n.columnGap) || 0, a = t.clientWidth, o = t.clientHeight;
			if (a <= 0 || o <= 0) return;
			let c = Math.min(e.length, Math.max(1, Math.floor((a + i) / (180 + i)))), l = {
				columns: 1,
				width: a,
				height: o,
				scale: -1,
				empty: e.length
			};
			for (let t = 1; t <= c; t += 1) {
				let n = Math.ceil(e.length / t), r = (a - i * (t - 1)) / t, s = (o - i * (n - 1)) / n, c = Math.min(r / 180, s / 150), u = t * n - e.length;
				(c > l.scale + .001 || Math.abs(c - l.scale) <= .001 && u < l.empty) && (l = {
					columns: t,
					width: r,
					height: s,
					scale: c,
					empty: u
				});
			}
			let u = Math.max(150, Math.min(l.height, l.width / 1.2)), d = {
				columns: l.columns,
				height: Math.floor(u),
				art: Math.floor(Math.max(44, Math.min(l.width * .25, u * .4, 148))),
				name: Math.floor(Math.max(16, Math.min(l.width * .065, u * .12, 36))),
				count: Math.floor(Math.max(20, Math.min(l.width * .1, u * .12, 40)))
			};
			s((e) => e && Object.keys(d).every((t) => e[t] === d[t]) ? e : d);
		}, a = new ResizeObserver(i);
		return a.observe(t), a.observe(r), i(), () => a.disconnect();
	}, [e.length]), /* @__PURE__ */ g("div", {
		ref: n,
		className: "mk-over-establishments",
		style: o ? {
			"--mk-over-est-columns": o.columns,
			"--mk-over-est-height": `${o.height}px`,
			"--mk-over-est-art": `${o.art}px`,
			"--mk-over-est-name": `${o.name}px`,
			"--mk-over-est-count": `${o.count}px`
		} : void 0,
		children: e.map(([e, n]) => /* @__PURE__ */ _("div", {
			className: `mk-over-establishment mk-card--${D[e].color}`,
			children: [
				/* @__PURE__ */ g("span", {
					"aria-hidden": !0,
					children: D[e].emoji
				}),
				/* @__PURE__ */ g("strong", { children: t(j[e]) }),
				/* @__PURE__ */ _("b", {
					className: "font-mono tabular-nums",
					children: ["×", n]
				})
			]
		}, e))
	});
}
//#endregion
//#region src/games/machikoro2/options.tsx
function ct({ value: e, onChange: t }) {
	let n = l(), r = R.safeParse(e), i = r.success ? r.data : R.parse(void 0);
	return /* @__PURE__ */ g(te, {
		title: n("games.machikoro2.optPromo"),
		children: [!1, !0].map((e) => /* @__PURE__ */ g(ee, {
			name: "machikoro2-promo",
			value: String(e),
			checked: i.promo === e,
			label: n(e ? "games.machikoro2.promoOn" : "games.machikoro2.promoOff"),
			hint: n(e ? "games.machikoro2.promoOnHint" : "games.machikoro2.promoOffHint"),
			accent: P.accent,
			onChange: () => t({ promo: e })
		}, String(e)))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/machikoro2/entry.tsx
var lt = {
	definition: Ae,
	View: Le,
	bot: $e,
	describe: tt,
	fx: it,
	OverView: at,
	Options: ct,
	locales: {
		zh: {
			name: "骰子街2",
			desc: "掷骰建设你的城市:产业生钱、地标定胜,先建成 3 个地标获胜",
			rules: "目标:最先建成第 3 个地标的玩家立即获胜;建成发射台也立即获胜。\n准备:\n· 卡牌分三叠:产业 1-6、产业 7-12、地标,分别洗匀;各叠逐张翻开,直到市场行有 5 种不同卡牌(同名叠放)。\n· 每名玩家获得 5 枚金币。\n· 从起始玩家开始顺时针进行 3 轮初始建设:每轮每人至多建 1 个产业,可以放弃。\n流程:\n每个回合依次进行掷骰、收入和建设三个步骤。掷骰时，自行选择掷 1 枚或 2 枚骰子；掷 2 枚时，使用点数之和。\n· 收入:所有玩家激活点数匹配的产业,顺序为红(餐馆,仅对手回合,从当前玩家收取)→ 蓝(任何回合)与绿(仅自己回合)→ 紫(仅自己回合)→ 橙色地标。\n· 需向多名玩家付款时按逆时针逐个付清;现金不足时，支付全部剩余金币，未能支付的部分不再追偿。\n· 建设步骤中，至多建造 1 个产业或地标。如果建设步骤开始时没有金币，先从银行领取 1 枚金币。\n· 建成后对应市场行不足 5 种时,翻开牌叠补足;牌堆耗尽后不再补充。\n地标:\n· 地标的建造费用分为三档。建造自己的第一、第二或第三个地标时，分别支付对应档位的费用。\n· 即时效果(紫)建成时结算一次,仅建造者受益;持续效果(橙)此后对所有玩家生效。\n· 掷出对子可能触发游乐园(再来一回合)、寺庙(收取金币)、搬家公司(交出产业)等效果。\n说明:预购赠卡地标(市政厅、私人俱乐部、翻新公司)为可选扩展,默认不加入。",
			optPromo: "预购赠卡地标",
			promoOn: "加入赠卡",
			promoOnHint: "市政厅/私人俱乐部/翻新公司加入地标牌叠",
			promoOff: "标准地标",
			promoOffHint: "20 张基础地标(默认)",
			phaseDraft: "初始建设 · 第 {{n}}/3 轮",
			yourRoll: "你的回合:掷骰",
			settling: "结算中…",
			waitTurn: "等待 {{name}} 行动…",
			over: "对局结束",
			resultWinner: "{{name}}获胜",
			resultThreeLandmarks: "建成第三座地标",
			resultLaunchPad: "建成发射台",
			resultCoins: "金币余额",
			resultLandmarks: "已建地标 · {{n}}",
			resultEstablishments: "已建产业 · {{n}}",
			rollOne: "掷 1 颗",
			rollTwo: "掷 2 颗",
			doubles: "对子!",
			exchangeTitle: "商业中心:可交换 1 个产业",
			exchangePickMine: "选自己 1 个产业换出",
			exchangePickPlayer: "选择要交换的对手",
			exchangePickTheirs: "选 {{name}} 的 1 个产业",
			exchangeReady: "用{{mine}}交换{{name}}的{{theirs}}",
			exchangeConfirm: "交换",
			exchangeSkip: "不换",
			giveTitle: "搬家公司:必须交 1 个产业给 {{name}}",
			giveConfirm: "交出",
			giveReady: "将{{card}}交给{{name}}",
			buildPhase: "建设:点市场卡牌建造,或放弃",
			build: "建造",
			needCoins: "还差 {{n}} 金币才能建造",
			draftNoLandmark: "初始建设阶段只能建造产业",
			landmarkUnavailable: "目前不能建造这座地标",
			pass: "放弃建设",
			passAirport: "放弃建设(机场 +5)",
			cancel: "取消",
			marketLandmark: "地标",
			dicePlaza: "骰子广场",
			marketHigh: "产业 7-12",
			marketLow: "产业 1-6",
			deckLeft: "余 {{n}}",
			myCity: "我的城市",
			cityOf: "{{name}}的城市",
			cityBack: "点自己名牌返回",
			landmarksChip: "🗼 {{n}}/3",
			effGainBank: "从银行获得 {{n}} 金币",
			effTakeActive: "从当前玩家收取 {{n}} 金币",
			effCombo: "你每有 1 个 {{icon}} 产业,从银行获得 {{n}} 金币",
			effExchange: "可用自己 1 个产业换对手 1 个产业",
			effTakeAll: "从每名对手收取 {{n}} 金币",
			effTakeHalf: "从每名持币超过 10 的对手收取其一半金币(向下取整)",
			whenRed: "对手掷出时",
			whenBlue: "任何人掷出时",
			whenGreen: "你掷出时",
			whenPurple: "你掷出时",
			whenRedShort: "对手",
			whenBlueShort: "任意",
			whenGreenShort: "自己",
			whenPurpleShort: "自己",
			lmInstant: "即时",
			lmOngoingAll: "持续·所有人",
			lmOngoingBuilder: "持续·建造者",
			lmAirportText: "若建设阶段没有建造任何卡牌,从银行获得 5 金币",
			lmAmusementParkText: "掷出对子时,本回合后再来一回合(不叠加)",
			lmCharterhouseText: "掷 2 颗骰子后没有任何收入,从银行获得 3 金币",
			lmExhibitHallText: "从每名持币超过 10 的对手收取其一半金币(向下取整)",
			lmFarmersMarketText: "你的 🌾 产业收入增加 1 金币",
			lmForgeText: "你的 ⚙️ 产业收入增加 1 金币",
			lmFrenchRestaurantText: "从每名对手收取 2 金币",
			lmLaunchPadText: "立即获胜",
			lmLoanOfficeText: "仅当自己是唯一没有地标的玩家时可建;此后自己的地标造价减少 2 金币",
			lmMovingCompanyText: "掷出对子时,必须把 1 个产业交给右手边玩家",
			lmMuseumText: "每名对手每有 1 个地标,付给你 3 金币",
			lmObservatoryText: "发射台造价减少 5 金币",
			lmParkText: "所有人金币汇总均分,不能均分时银行补足到向上取整",
			lmPublisherText: "每名对手每有 1 个 🏪 产业,付给你 1 金币",
			lmRadioTowerText: "本回合后再来一回合",
			lmShoppingMallText: "你的 🏪 产业收入增加 1 金币",
			lmSodaBottlingPlantText: "你的 ☕ 产业收入增加 1 金币",
			lmTechStartupText: "掷出 12 时,从银行获得 8 金币",
			lmTempleText: "掷出对子时,从每名对手收取 2 金币",
			lmTvStationText: "每名对手每有 1 个 ☕ 产业,付给你 1 金币",
			lmCityHallText: "掷 1 颗骰子后没有任何收入,从银行获得 2 金币",
			lmPrivateClubText: "从每名恰好有 2 个地标的对手收取 5 金币",
			lmRenovationCompanyText: "掷出 6 时,你每有 1 个 ☕ 产业,从银行获得 1 金币",
			errOver: "对局已结束",
			errNotYourTurn: "还没轮到你",
			errBadPhase: "现在不能这么做",
			errNoCoins: "金币不够",
			errNoCard: "这张卡现在不能建",
			errBadCard: "选择无效",
			hintRollOne: "掷 1 颗骰子",
			hintRollTwo: "掷 2 颗骰子",
			hintBuild: "建造{{name}}",
			hintPass: "放弃建设",
			hintExchange: "用{{mine}}换{{name}}的{{theirs}}",
			hintSkipExchange: "不使用商业中心",
			hintGive: "把{{name}}交给{{to}}",
			cardWheatField: "麦田",
			cardSushiBar: "寿司吧",
			cardBusinessCenter: "商业中心",
			cardFlowerShop: "花店",
			cardCafe: "咖啡馆",
			cardBakery: "面包房",
			cardFlowerGarden: "花园",
			cardVineyard: "葡萄园",
			cardForest: "森林",
			cardConvenienceStore: "便利店",
			cardCornField: "玉米田",
			cardFoodWarehouse: "食品仓库",
			cardFamilyRestaurant: "家庭餐馆",
			cardShoppingDistrict: "商业区",
			cardHamburgerStand: "汉堡摊",
			cardFurnitureFactory: "家具厂",
			cardStadium: "体育场",
			cardWinery: "酿酒厂",
			cardAppleOrchard: "苹果园",
			cardMine: "矿山",
			lmAirport: "机场",
			lmAmusementPark: "游乐园",
			lmCharterhouse: "修道院",
			lmExhibitHall: "展览馆",
			lmFarmersMarket: "农贸市场",
			lmForge: "锻造厂",
			lmFrenchRestaurant: "法式餐厅",
			lmLaunchPad: "发射台",
			lmLoanOffice: "贷款处",
			lmMovingCompany: "搬家公司",
			lmMuseum: "博物馆",
			lmObservatory: "天文台",
			lmPark: "公园",
			lmPublisher: "出版社",
			lmRadioTower: "广播塔",
			lmShoppingMall: "购物中心",
			lmSodaBottlingPlant: "汽水厂",
			lmTechStartup: "科技创业公司",
			lmTemple: "寺庙",
			lmTvStation: "电视台",
			lmCityHall: "市政厅",
			lmPrivateClub: "私人俱乐部",
			lmRenovationCompany: "翻新公司"
		},
		en: {
			name: "Machi Koro 2",
			desc: "Roll dice and build your city: establishments earn coins, landmarks win the race to 3",
			rules: "Goal: the first player to build their 3rd landmark wins immediately; building the Launch Pad also wins instantly.\nSetup:\n· Sort the cards into three decks: establishments 1-6, establishments 7-12, and landmarks; shuffle each separately. Reveal cards from each deck until its market row has 5 different cards (duplicates stack).\n· Each player starts with 5 coins.\n· Starting with the start player and going clockwise, play 3 initial building rounds: each player may build at most 1 establishment per round, or pass.\nPlay:\n· A turn has three steps: roll the dice (your choice of 1 or 2, summed) → earn income → build.\n· Income: all players activate establishments matching the roll, in this order: red (restaurants, only on opponents' turns, paid by the active player) → blue (any turn) and green (your turn only) → purple (your turn only) → orange landmarks.\n· If you owe several players, pay them in counterclockwise order, each in full before the next; if you cannot pay in full, pay what you can and the rest is forgiven.\n· Build: build at most 1 establishment or landmark; if you have no coins at the start of the build step, take 1 coin from the bank first.\n· After a build, refill the matching market row to 5 different cards; empty decks are not refilled.\nLandmarks:\n· Landmark costs come in three tiers: pay the tier matching whether it is your 1st, 2nd, or 3rd landmark.\n· Instant effects (magenta) resolve once when built, for the builder only; ongoing effects (orange) apply to all players from then on.\n· Rolling doubles may trigger effects such as Amusement Park (extra turn), Temple (take coins), or Moving Company (give an establishment away).\nNote: the promo landmarks (City Hall, Private Club, Renovation Company) are an optional expansion, off by default.",
			optPromo: "Promo landmarks",
			promoOn: "With promos",
			promoOnHint: "City Hall, Private Club & Renovation Company are added to the landmark deck",
			promoOff: "Standard",
			promoOffHint: "20 base landmarks (default)",
			phaseDraft: "Initial building · Round {{n}}/3",
			yourRoll: "Your turn: roll the dice",
			settling: "Resolving…",
			waitTurn: "Waiting for {{name}}…",
			over: "Game over",
			resultWinner: "{{name}} wins",
			resultThreeLandmarks: "Built a third landmark",
			resultLaunchPad: "Built the Launch Pad",
			resultCoins: "Coins remaining",
			resultLandmarks: "Landmarks built · {{n}}",
			resultEstablishments: "Establishments built · {{n}}",
			rollOne: "Roll 1 die",
			rollTwo: "Roll 2 dice",
			doubles: "Doubles!",
			exchangeTitle: "Business Center: you may exchange 1 establishment",
			exchangePickMine: "Pick one of yours to give",
			exchangePickPlayer: "Choose an opponent to exchange with",
			exchangePickTheirs: "Pick one of {{name}}'s",
			exchangeReady: "Trade {{mine}} for {{name}}'s {{theirs}}",
			exchangeConfirm: "Exchange",
			exchangeSkip: "Skip",
			giveTitle: "Moving Company: give 1 establishment to {{name}}",
			giveConfirm: "Give",
			giveReady: "Give {{card}} to {{name}}",
			buildPhase: "Build: tap a market card, or pass",
			build: "Build",
			needCoins: "{{n}} more coins needed to build",
			draftNoLandmark: "Only establishments can be built during the draft",
			landmarkUnavailable: "This landmark cannot be built now",
			pass: "Pass",
			passAirport: "Pass (Airport +5)",
			cancel: "Cancel",
			marketLandmark: "Landmarks",
			dicePlaza: "Dice plaza",
			marketHigh: "Est. 7-12",
			marketLow: "Est. 1-6",
			deckLeft: "{{n}} left",
			myCity: "My city",
			cityOf: "{{name}}'s city",
			cityBack: "Tap your own plate to return",
			landmarksChip: "🗼 {{n}}/3",
			effGainBank: "Get {{n}} coins from the bank",
			effTakeActive: "Take {{n}} coins from the active player",
			effCombo: "Get {{n}} coins from the bank for each of your {{icon}} establishments",
			effExchange: "You may exchange 1 of your establishments for 1 of an opponent's",
			effTakeAll: "Take {{n}} coins from each opponent",
			effTakeHalf: "Take half their coins (rounded down) from each opponent with more than 10 coins",
			whenRed: "On opponents' rolls",
			whenBlue: "On anyone's roll",
			whenGreen: "On your roll",
			whenPurple: "On your roll",
			whenRedShort: "OTHER",
			whenBlueShort: "ANY",
			whenGreenShort: "YOU",
			whenPurpleShort: "YOU",
			lmInstant: "Instant",
			lmOngoingAll: "Ongoing · all",
			lmOngoingBuilder: "Ongoing · builder",
			lmAirportText: "If you build nothing during your build step, get 5 coins from the bank",
			lmAmusementParkText: "When you roll doubles, take another turn after this one (does not stack)",
			lmCharterhouseText: "If you roll 2 dice and earn nothing, get 3 coins from the bank",
			lmExhibitHallText: "Take half their coins (rounded down) from each opponent with more than 10 coins",
			lmFarmersMarketText: "Your 🌾 establishments earn 1 more coin",
			lmForgeText: "Your ⚙️ establishments earn 1 more coin",
			lmFrenchRestaurantText: "Take 2 coins from each opponent",
			lmLaunchPadText: "You win the game",
			lmLoanOfficeText: "Buildable only when you are the only player with no landmarks; your landmarks cost 2 coins less",
			lmMovingCompanyText: "When you roll doubles, you must give 1 establishment to the player on your right",
			lmMuseumText: "Each opponent pays you 3 coins per landmark they have",
			lmObservatoryText: "Launch Pad costs 5 coins less",
			lmParkText: "Pool all coins and redistribute evenly; the bank tops up to round up",
			lmPublisherText: "Each opponent pays you 1 coin per 🏪 establishment they have",
			lmRadioTowerText: "Take another turn after this one",
			lmShoppingMallText: "Your 🏪 establishments earn 1 more coin",
			lmSodaBottlingPlantText: "Your ☕ establishments earn 1 more coin",
			lmTechStartupText: "When you roll 12, get 8 coins from the bank",
			lmTempleText: "When you roll doubles, take 2 coins from each opponent",
			lmTvStationText: "Each opponent pays you 1 coin per ☕ establishment they have",
			lmCityHallText: "If you roll 1 die and earn nothing, get 2 coins from the bank",
			lmPrivateClubText: "Take 5 coins from each opponent with exactly 2 landmarks",
			lmRenovationCompanyText: "When you roll 6, get 1 coin from the bank per ☕ you have",
			errOver: "The game is over",
			errNotYourTurn: "Not your turn",
			errBadPhase: "Not allowed right now",
			errNoCoins: "Not enough coins",
			errNoCard: "That card cannot be built now",
			errBadCard: "Invalid choice",
			hintRollOne: "Roll 1 die",
			hintRollTwo: "Roll 2 dice",
			hintBuild: "Build {{name}}",
			hintPass: "Skip building",
			hintExchange: "Trade {{mine}} for {{name}}'s {{theirs}}",
			hintSkipExchange: "Skip the Business Center",
			hintGive: "Give {{name}} to {{to}}",
			cardWheatField: "Wheat Field",
			cardSushiBar: "Sushi Bar",
			cardBusinessCenter: "Business Center",
			cardFlowerShop: "Flower Shop",
			cardCafe: "Café",
			cardBakery: "Bakery",
			cardFlowerGarden: "Flower Garden",
			cardVineyard: "Vineyard",
			cardForest: "Forest",
			cardConvenienceStore: "Convenience Store",
			cardCornField: "Corn Field",
			cardFoodWarehouse: "Food Warehouse",
			cardFamilyRestaurant: "Family Restaurant",
			cardShoppingDistrict: "Shopping District",
			cardHamburgerStand: "Hamburger Stand",
			cardFurnitureFactory: "Furniture Factory",
			cardStadium: "Stadium",
			cardWinery: "Winery",
			cardAppleOrchard: "Apple Orchard",
			cardMine: "Mine",
			lmAirport: "Airport",
			lmAmusementPark: "Amusement Park",
			lmCharterhouse: "Charterhouse",
			lmExhibitHall: "Exhibit Hall",
			lmFarmersMarket: "Farmers Market",
			lmForge: "Forge",
			lmFrenchRestaurant: "French Restaurant",
			lmLaunchPad: "Launch Pad",
			lmLoanOffice: "Loan Office",
			lmMovingCompany: "Moving Company",
			lmMuseum: "Museum",
			lmObservatory: "Observatory",
			lmPark: "Park",
			lmPublisher: "Publisher",
			lmRadioTower: "Radio Tower",
			lmShoppingMall: "Shopping Mall",
			lmSodaBottlingPlant: "Soda Bottling Plant",
			lmTechStartup: "Tech Startup",
			lmTemple: "Temple",
			lmTvStation: "TV Station",
			lmCityHall: "City Hall",
			lmPrivateClub: "Private Club",
			lmRenovationCompany: "Renovation Company"
		}
	}
};
//#endregion
export { lt as default };
