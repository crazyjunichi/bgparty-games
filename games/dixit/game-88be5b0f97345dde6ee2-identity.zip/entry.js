import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { IconClose as l, IconHistory as u, IconZoomIn as d } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { playTurn as p, useSoundEdge as m } from "@bgparty/sdk/sfx";
import { GameScreen as h } from "@bgparty/sdk/ui/game-screen";
import { seatName as g } from "@bgparty/sdk/ui/player-strip";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { AVATARS as b } from "@bgparty/sdk/avatars";
import { FlySprite as x, PulseBox as S } from "@bgparty/sdk/fx/primitives";
//#region src/games/dixit/meta.ts
var C = {
	id: "dixit",
	tier: "alpha",
	mechanics: ["word-association", "hand-management"],
	interactionTags: [],
	nameKey: "games.dixit.name",
	descKey: "games.dixit.desc",
	rulesKey: "games.dixit.rules",
	icon: "🎨",
	iconImg: "games/dixit.webp",
	rulesUrl: { en: "https://cdn.svc.asmodee.net/production-libellud/uploads/2022/03/DIXIT_REFRESH_RULES_US-UK-AU_BD.pdf" },
	minPlayers: 3,
	maxPlayers: 8,
	bestPlayers: [5, 6],
	accent: "#cf9c43",
	releasedAt: "2026-11-04T01:37:00+08:00",
	search: {
		py: "hua wu yu miao yu shuo shu ren zhi yan pian yu",
		init: "hwy myssr zypy"
	},
	hotseat: "cover"
}, w = t.int().min(0).max(83), T = t.string(), E = t.record(T, t.int().min(0)), D = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("story"),
		card: w,
		clue: t.string().trim().min(1).max(160)
	}),
	t.object({
		type: t.literal("submit"),
		cards: t.array(w).min(1).max(2)
	}),
	t.object({
		type: t.literal("vote"),
		at: t.int().min(0).max(7)
	}),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), O = t.object({
	answer: t.int(),
	owners: t.array(T),
	votes: t.record(T, t.int()),
	base: E,
	bonus: E,
	deltas: E,
	correct: t.array(T)
}), k = t.object({
	round: t.int(),
	storyteller: T,
	clue: t.string(),
	cards: t.array(w),
	reveal: O
}), A = t.object({
	index: t.int().min(0),
	stage: t.enum([
		"read",
		"base",
		"bonus"
	])
}), ee = t.object({
	phase: t.enum([
		"story",
		"submit",
		"shuffle",
		"vote",
		"reveal",
		"score",
		"result",
		"discard",
		"refill",
		"done"
	]),
	round: t.int().min(1),
	players: t.array(T),
	storyteller: T.nullable(),
	clue: t.string(),
	scores: E,
	baseScores: E,
	bonusScores: E,
	deckCount: t.int().min(0),
	discardCount: t.int().min(0),
	handCounts: E,
	submitted: t.array(T),
	voted: t.array(T),
	cards: t.array(w),
	reveal: O.nullable(),
	history: t.array(k),
	settlement: A.nullable(),
	roundPoints: E,
	ready: t.array(T)
}), j = t.object({
	hand: t.array(w),
	submitted: t.array(w),
	vote: t.int().nullable(),
	canStory: t.boolean(),
	canNext: t.boolean()
});
//#endregion
//#region src/games/dixit/scoring.ts
function M(e) {
	return [e.answer, ...e.owners.map((e, t) => t).filter((t) => t !== e.answer)];
}
function N(e, t, n) {
	let r = e.owners[t], i = Object.entries(e.votes).filter(([, e]) => e === t).map(([e]) => e);
	if (n === "bonus") return t === e.answer || !i.length ? [] : [{
		rid: r,
		points: i.length,
		source: "owner"
	}];
	let a = i.filter((t) => e.base[t] > 0).map((t) => ({
		rid: t,
		points: e.base[t],
		source: "vote"
	}));
	return t === e.answer && e.base[r] > 0 && a.unshift({
		rid: r,
		points: e.base[r],
		source: "owner"
	}), a;
}
//#endregion
//#region src/games/dixit/rules.ts
var P = {
	shuffle: 500,
	reveal: 3e3,
	read: 800,
	award: 850,
	discard: 450,
	refill: 500
}, F = (e) => Object.fromEntries(e.map((e) => [e, 0]));
function I(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var L = (e) => e.players.length === 3 ? 7 : 6;
function R(e) {
	let t = e.players.reduce((t, n) => t + L(e) - e.hands[n].length, 0);
	return e.deck.length < t && (e.deck = I(e, [...e.deck, ...e.discard]), e.discard = []), e.players.flatMap((t) => {
		let n = e.deck.splice(0, L(e) - e.hands[t].length);
		return e.hands[t].push(...n), n.length ? [{
			kind: "dixitDraw",
			rid: t,
			data: { count: n.length },
			for: [t],
			secret: { cards: n },
			with: !0
		}] : [];
	});
}
function z(e) {
	let t = e.table.findIndex((t) => t.owner === e.storyteller), n = e.players.filter((n) => e.votes[n] === t), r = n.length === 0 || n.length === e.players.length - 1, i = F(e.players), a = F(e.players), o = F(e.players);
	for (let t of e.players) i[t] = r ? t === e.storyteller ? 0 : 2 : t === e.storyteller || n.includes(t) ? 3 : 0, t !== e.storyteller && (a[t] = Object.values(e.votes).filter((n) => e.table[n].owner === t).length), o[t] = i[t] + a[t];
	return {
		answer: t,
		owners: e.table.map((e) => e.owner),
		votes: { ...e.votes },
		base: i,
		bonus: a,
		deltas: o,
		correct: n
	};
}
var B = (e) => ({ code: e });
function V(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine") return B("games.dixit.errAction");
		if (![
			"shuffle",
			"reveal",
			"score",
			"discard",
			"refill"
		].includes(e.phase)) return { state: e };
		let t = structuredClone(e);
		if (t.phase === "shuffle") return t.phase = "vote", {
			state: t,
			fx: [{
				kind: "dixitReveal",
				data: { cards: t.table.map((e) => e.card) }
			}]
		};
		if (t.phase === "reveal") return t.phase = "score", t.settlement = {
			index: 0,
			stage: "read"
		}, { state: t };
		if (t.phase === "score") {
			let e = t.settlement, n = t.reveal, r = M(n), i = r[e.index];
			if (e.stage !== "read") for (let r of N(n, i, e.stage)) t.scores[r.rid] += r.points, t.roundPoints[r.rid] += r.points, (e.stage === "base" ? t.baseScores : t.bonusScores)[r.rid] += r.points;
			return e.stage === "bonus" ? (e.index + 1 === r.length ? (t.phase = "result", t.settlement = null, t.history.push({
				round: t.round,
				storyteller: t.storyteller,
				clue: t.clue,
				cards: t.table.map((e) => e.card),
				reveal: structuredClone(n)
			})) : t.settlement = {
				index: e.index + 1,
				stage: "read"
			}, { state: t }) : (e.stage = e.stage === "read" ? "base" : "bonus", {
				state: t,
				fx: [{
					kind: "dixitScore",
					data: {
						at: i,
						awards: N(n, i, e.stage)
					}
				}]
			});
		}
		return t.phase === "discard" ? (t.discard.push(...t.table.map((e) => e.card)), t.table = [], t.phase = "refill", {
			state: t,
			fx: R(t)
		}) : (t.phase = "story", t.round++, t.storyteller = t.players[(t.players.indexOf(t.storyteller) + 1) % t.players.length], t.submissions = {}, t.votes = {}, t.clue = "", t.reveal = null, t.ready = [], t.roundPoints = F(t.players), { state: t });
	}
	if (!e.players.includes(n.by)) return B("games.dixit.errAction");
	let r = n.by;
	if (t.type === "story") {
		if (e.phase !== "story" || e.storyteller !== null && r !== e.storyteller) return B("games.dixit.errPhase");
		if (!e.hands[r].includes(t.card) || !t.clue.trim()) return B("games.dixit.errCard");
		let n = structuredClone(e);
		return n.storyteller = r, n.clue = t.clue.trim(), n.submissions[r] = [t.card], n.hands[r] = n.hands[r].filter((e) => e !== t.card), n.phase = "submit", {
			state: n,
			fx: [{
				kind: "dixitSubmit",
				rid: r
			}]
		};
	}
	if (t.type === "submit") {
		if (e.phase !== "submit" || r === e.storyteller) return B("games.dixit.errPhase");
		if (e.submissions[r]) return B("games.dixit.errSubmitted");
		let n = e.players.length === 3 ? 2 : 1;
		if (t.cards.length !== n || new Set(t.cards).size !== n || t.cards.some((t) => !e.hands[r].includes(t))) return B("games.dixit.errCard");
		let i = structuredClone(e);
		return i.submissions[r] = [...t.cards], i.hands[r] = i.hands[r].filter((e) => !t.cards.includes(e)), i.players.every((e) => i.submissions[e]) && (i.table = I(i, i.players.flatMap((e) => i.submissions[e].map((t) => ({
			card: t,
			owner: e
		})))), i.phase = "shuffle"), {
			state: i,
			fx: [{
				kind: "dixitSubmit",
				rid: r
			}]
		};
	}
	if (t.type === "vote") {
		if (e.phase !== "vote" || r === e.storyteller) return B("games.dixit.errPhase");
		if (r in e.votes) return B("games.dixit.errSubmitted");
		if (!e.table[t.at] || e.table[t.at].owner === r) return B("games.dixit.errVote");
		let n = structuredClone(e);
		return n.votes[r] = t.at, n.players.filter((e) => e !== n.storyteller).every((e) => e in n.votes) && (n.phase = "reveal", n.reveal = z(n)), {
			state: n,
			fx: n.phase === "reveal" ? [{
				kind: "dixitAnswer",
				data: { at: n.reveal.answer }
			}] : []
		};
	}
	if (e.phase !== "result") return B("games.dixit.errPhase");
	if (e.ready.includes(r)) return B("games.dixit.errSubmitted");
	let i = structuredClone(e);
	if (i.ready.push(r), i.ready.length < i.players.length) return { state: i };
	if (i.players.some((e) => i.scores[e] >= 30)) return i.phase = "done", { state: i };
	let a = i.table.map((e) => e.card);
	return i.phase = "discard", i.submissions = {}, {
		state: i,
		fx: [{
			kind: "dixitDiscard",
			data: { cards: a }
		}]
	};
}
function te(e) {
	let t = e[0];
	if (t?.type !== "$setup" || !Array.isArray(t.players) || !t.players.every((e) => typeof e == "string") || typeof t.seed != "number") return null;
	let n = H.setup(void 0, t.players, t.seed).state, r = [{
		...t,
		saveVersion: "2"
	}], i = (e) => {
		let t = V(n, e.action, { by: e.by });
		return "state" in t && (n = t.state, r.push(e), !0);
	};
	for (let t of e.slice(1)) {
		let e = t, r = D.safeParse(e?.action);
		if (typeof e?.by != "string" || !r.success) return null;
		let a = r.data, o = n.phase;
		if (a.type === "next" && o === "result") {
			for (let t of n.players) if (!i({
				by: t,
				action: a,
				...t === e.by && e.auto === !0 ? { auto: !0 } : {}
			})) return null;
		} else if (!i({
			by: e.by,
			action: a,
			...e.auto === !0 ? { auto: !0 } : {}
		})) return null;
		if (a.type === "tick" && o === "reveal") {
			for (; n.phase === "score";) if (!i({
				by: "$engine",
				action: a
			})) return null;
		}
	}
	return r;
}
var H = {
	meta: C,
	saveCompatibility: {
		version: "2",
		migrate: ({ version: e, log: t }) => e === "1" ? te(t) : null
	},
	schemas: {
		action: D,
		publicView: ee,
		privateView: j
	},
	setup(e, t, n) {
		let r = {
			seed: n,
			cursor: 0,
			players: [...t],
			phase: "story",
			round: 1,
			storyteller: null,
			hands: Object.fromEntries(t.map((e) => [e, []])),
			deck: [],
			discard: [],
			submissions: {},
			table: [],
			votes: {},
			clue: "",
			scores: F(t),
			baseScores: F(t),
			bonusScores: F(t),
			reveal: null,
			history: [],
			settlement: null,
			roundPoints: F(t),
			ready: []
		};
		r.deck = I(r, Array.from({ length: 84 }, (e, t) => t));
		for (let e of t) r.hands[e] = r.deck.splice(0, L(r));
		return {
			state: r,
			fx: t.map((e) => ({
				kind: "dixitDraw",
				rid: e,
				data: { count: r.hands[e].length },
				for: [e],
				secret: { cards: [...r.hands[e]] },
				with: !0
			}))
		};
	},
	reduce: V,
	viewFor(e, t) {
		let n = [
			"vote",
			"reveal",
			"score",
			"result",
			"discard",
			"done"
		].includes(e.phase);
		return {
			public: {
				phase: e.phase,
				round: e.round,
				players: [...e.players],
				storyteller: e.storyteller,
				clue: e.clue,
				scores: { ...e.scores },
				baseScores: { ...e.baseScores },
				bonusScores: { ...e.bonusScores },
				deckCount: e.deck.length,
				discardCount: e.discard.length,
				handCounts: Object.fromEntries(e.players.map((t) => [t, e.hands[t].length])),
				submitted: Object.keys(e.submissions),
				voted: Object.keys(e.votes),
				cards: n ? e.table.map((e) => e.card) : [],
				reveal: [
					"reveal",
					"score",
					"result",
					"discard",
					"done"
				].includes(e.phase) ? structuredClone(e.reveal) : null,
				history: structuredClone(e.history),
				settlement: e.settlement ? { ...e.settlement } : null,
				roundPoints: { ...e.roundPoints },
				ready: [...e.ready]
			},
			private: {
				hand: [...e.hands[t] ?? []],
				submitted: [...e.submissions[t] ?? []],
				vote: e.votes[t] ?? null,
				canStory: e.phase === "story" && (e.storyteller === null || e.storyteller === t),
				canNext: e.phase === "result" && e.players.includes(t) && !e.ready.includes(t)
			}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]);
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((n) => e.scores[n] === e.scores[t[0]]),
			scores: { ...e.scores }
		};
	},
	nextTickIn(e) {
		return e.phase === "score" ? P[e.settlement?.stage === "read" ? "read" : "award"] : P[e.phase] ?? null;
	}
};
//#endregion
//#region src/games/dixit/card.tsx
function U({ card: e, anchor: t, hidden: n = !1 }) {
	let { ref: r, hidden: i } = o(t ?? null), a = c();
	return /* @__PURE__ */ v("span", {
		ref: r,
		className: "dixit-card",
		style: { visibility: n || i ? "hidden" : void 0 },
		children: /* @__PURE__ */ v("img", {
			draggable: !1,
			src: e === void 0 ? "games/dixit/back.svg" : `games/dixit/cards/${String(e).padStart(2, "0")}.webp`,
			alt: e === void 0 ? "" : a("games.dixit.card", { n: e + 1 })
		})
	});
}
function W({ card: e, at: t, selected: n, legal: r, own: i, anchor: a, onPick: o, onZoom: s, caption: l, overlay: u }) {
	let f = c();
	return /* @__PURE__ */ y("div", {
		className: `dixit-picture ${n ? "is-selected" : ""} ${r ? "is-legal" : ""}`,
		children: [
			/* @__PURE__ */ y("button", {
				type: "button",
				className: "dixit-picture-main",
				"aria-label": t === void 0 ? f("games.dixit.card", { n: e + 1 }) : f("games.dixit.tableCard", { n: t + 1 }),
				"aria-pressed": o ? !!n : void 0,
				onClick: o ?? s,
				children: [
					/* @__PURE__ */ v(U, {
						card: e,
						anchor: a
					}),
					r && /* @__PURE__ */ v("svg", {
						className: "dixit-ants",
						viewBox: "0 0 100 150",
						preserveAspectRatio: "none",
						"aria-hidden": !0,
						children: /* @__PURE__ */ v("rect", {
							x: "2",
							y: "2",
							width: "96",
							height: "146",
							rx: "5"
						})
					}),
					n && /* @__PURE__ */ v("span", {
						className: "dixit-selection",
						"aria-hidden": !0,
						children: "✓"
					})
				]
			}),
			t !== void 0 && /* @__PURE__ */ v("span", {
				className: "dixit-number",
				children: t + 1
			}),
			/* @__PURE__ */ v("button", {
				type: "button",
				className: "dixit-zoom",
				"aria-label": f("games.dixit.zoom"),
				onClick: s,
				children: /* @__PURE__ */ v(d, { size: 17 })
			}),
			(l || i) && /* @__PURE__ */ v("div", {
				className: "dixit-card-caption",
				children: l ?? f("games.dixit.ownCard")
			}),
			u
		]
	});
}
//#endregion
//#region src/games/dixit/dialog.tsx
function G({ label: e, onClose: t, children: r, wide: a = !1 }) {
	let o = i(null), s = c();
	return n(() => {
		let e = o.current;
		return e?.showModal(), () => e?.close();
	}, []), /* @__PURE__ */ y("dialog", {
		ref: o,
		className: `dixit-dialog ${a ? "dixit-dialog-wide" : ""}`,
		"aria-label": e,
		onCancel: (e) => {
			e.preventDefault(), t();
		},
		onClick: (e) => {
			e.target === e.currentTarget && t();
		},
		children: [/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ v("h2", { children: e }), /* @__PURE__ */ v("button", {
			type: "button",
			className: "dixit-icon-btn",
			onClick: t,
			"aria-label": s("games.dixit.close"),
			children: /* @__PURE__ */ v(l, { size: 22 })
		})] }), /* @__PURE__ */ v("div", {
			className: "dixit-dialog-content",
			children: r
		})]
	});
}
//#endregion
//#region src/games/dixit/settlement.tsx
function K({ member: e, name: t, anchor: n }) {
	let { ref: r, hidden: i } = o(n ?? null);
	return /* @__PURE__ */ v("span", {
		ref: r,
		className: "dixit-score-avatar",
		title: t,
		style: {
			"--dixit-avatar-color": f[(e?.colorIndex ?? 0) % f.length].hex,
			visibility: i ? "hidden" : void 0
		},
		children: /* @__PURE__ */ v("img", {
			src: b[(e?.avatar ?? 0) % b.length],
			alt: t,
			draggable: !1
		})
	});
}
function q({ at: e, reveal: t, members: n, name: r, focus: i = !1 }) {
	let a = c(), o = t.owners[e], s = Object.entries(t.votes).filter(([, t]) => t === e).map(([e]) => e);
	return /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ y("span", {
		className: "dixit-owner",
		title: a("games.dixit.cardOwner", { name: r(o) }),
		children: [/* @__PURE__ */ v(K, {
			member: n.find((e) => e.rid === o),
			name: r(o),
			anchor: i ? `dx:focus:owner:${o}` : void 0
		}), /* @__PURE__ */ v("small", { children: a(e === t.answer ? "games.dixit.storyteller" : "games.dixit.owner") })]
	}), /* @__PURE__ */ v("span", {
		className: "dixit-voters",
		"aria-label": a("games.dixit.votes", { n: s.length }),
		children: s.length ? s.map((e) => /* @__PURE__ */ v(K, {
			member: n.find((t) => t.rid === e),
			name: r(e),
			anchor: i ? `dx:focus:vote:${e}` : void 0
		}, e)) : /* @__PURE__ */ v("span", {
			className: "dixit-no-votes",
			children: a("games.dixit.noVotes")
		})
	})] });
}
function ne({ pub: e, members: t, name: n }) {
	let r = c(), i = e.reveal, a = M(i), o = e.settlement?.index ?? 0, s = a[o], l = e.settlement?.stage ?? "read", u = Object.values(i.votes).filter((e) => e === s).length, d = i.correct.length === 0 || i.correct.length === e.players.length - 1, f = r(i.correct.length === 0 ? "games.dixit.noneCorrect" : d ? "games.dixit.allCorrect" : "games.dixit.someCorrect"), p = e.phase === "reveal" || s === i.answer && l !== "bonus" ? f : l === "base" ? r(u ? d ? "games.dixit.votersTwo" : "games.dixit.votersZero" : "games.dixit.noVotes") : s === i.answer ? r("games.dixit.noStoryBonus") : r("games.dixit.cardBonus", { n: u });
	return /* @__PURE__ */ y("div", {
		className: "dixit-settlement",
		"aria-label": r("games.dixit.scoring"),
		children: [/* @__PURE__ */ y("div", {
			className: "dixit-settlement-card",
			children: [
				/* @__PURE__ */ v(U, {
					card: e.cards[s],
					anchor: "dx:focus:card"
				}),
				/* @__PURE__ */ v("span", {
					className: "dixit-number",
					children: s + 1
				}),
				/* @__PURE__ */ v(q, {
					at: s,
					reveal: i,
					members: t,
					name: n,
					focus: !0
				})
			]
		}), /* @__PURE__ */ y("div", {
			className: "dixit-settlement-copy",
			role: "status",
			children: [/* @__PURE__ */ y("b", { children: [
				r("games.dixit.scoringCard", {
					n: o + 1,
					total: a.length
				}),
				" · ",
				r(e.phase === "reveal" ? "games.dixit.revealing" : l === "base" ? "games.dixit.base" : l === "bonus" ? "games.dixit.bonus" : "games.dixit.cardResult")
			] }), /* @__PURE__ */ v("p", { children: p })]
		})]
	});
}
//#endregion
//#region src/games/dixit/view-player.tsx
function re(e) {
	let t = e.public, n = e.private, r = c(), i = s((e) => e.locale), l = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? g(n, i) : t;
	}, [d, b] = a([]), [x, S] = a(null), [C, w] = a(""), [T, E] = a(null), [D, O] = a(!1), k = `${e.myRid}/${t.round}/${t.phase}`, [A, ee] = a(k);
	k !== A && (ee(k), b([]), S(null), w(""), E(null));
	let j = n?.canStory ?? !1, M = !!n && t.phase === "submit" && t.storyteller !== e.myRid && !t.submitted.includes(e.myRid), N = !!n && t.phase === "vote" && t.storyteller !== e.myRid && !t.voted.includes(e.myRid), P = M && t.players.length === 3 ? 2 : 1, F = Object.values(t.scores).some((e) => e >= 30);
	m(j || M || N, p);
	let { ref: I } = o("dx:table"), { ref: L } = o("dx:deck"), { ref: R } = o("dx:discard"), { ref: z } = o("dx:hand"), B = j ? r(t.storyteller ? "games.dixit.chooseStory" : "games.dixit.firstStory") : M ? r("games.dixit.submitPrompt", { n: P }) : N ? r("games.dixit.votePrompt") : t.phase === "story" ? r("games.dixit.waitStory", { name: t.storyteller ? l(t.storyteller) : r("games.dixit.storyteller") }) : t.phase === "shuffle" ? r("games.dixit.shuffle") : t.phase === "reveal" ? r("games.dixit.revealing") : t.phase === "score" ? r("games.dixit.scoring") : t.phase === "discard" ? r("games.dixit.discarding") : t.phase === "refill" ? r("games.dixit.refilling") : t.phase === "result" ? r("games.dixit.roundResult") : r("games.dixit.waiting");
	function V(e) {
		b((t) => t.includes(e) ? t.filter((t) => t !== e) : P === 1 ? [e] : t.length < P ? [...t, e] : [...t.slice(1), e]);
	}
	return /* @__PURE__ */ y("div", {
		className: "dixit-screen",
		"data-revealed": !!t.reveal,
		children: [
			/* @__PURE__ */ v(h, {
				adaptive: !0,
				scroll: !1,
				className: "dixit-layout",
				banner: /* @__PURE__ */ y("div", {
					className: "dixit-top",
					children: [/* @__PURE__ */ y("header", {
						className: "dixit-heading",
						children: [
							/* @__PURE__ */ v("span", {
								className: "dixit-wordmark",
								children: "Dixit"
							}),
							/* @__PURE__ */ v("span", { children: r("games.dixit.round", { n: t.round }) }),
							/* @__PURE__ */ v("div", {
								className: "dixit-story",
								children: /* @__PURE__ */ v("blockquote", { children: t.clue || r("games.dixit.empty") })
							}),
							/* @__PURE__ */ v("button", {
								type: "button",
								className: "dixit-icon-btn",
								onClick: () => O(!0),
								"aria-label": r("games.dixit.history"),
								children: /* @__PURE__ */ v(u, { size: 21 })
							})
						]
					}), /* @__PURE__ */ v("div", {
						className: "dixit-seats",
						style: {
							"--dixit-players": t.players.length,
							"--dixit-compact-columns": t.players.length <= 4 ? t.players.length : Math.ceil(t.players.length / 2)
						},
						children: t.players.map((n) => /* @__PURE__ */ v(ie, {
							rid: n,
							name: l(n),
							score: t.scores[n],
							color: f[(e.members.find((e) => e.rid === n)?.colorIndex ?? 0) % f.length].hex,
							story: t.storyteller === n && !t.ready.includes(n),
							delta: ["score", "result"].includes(t.phase) ? t.roundPoints[n] : void 0,
							state: t.ready.includes(n) ? r("games.dixit.ready") : t.voted.includes(n) ? r("games.dixit.voted") : t.submitted.includes(n) ? r("games.dixit.submitted") : ""
						}, n))
					})]
				}),
				actionsHeight: "dixit-actions-height",
				actions: /* @__PURE__ */ y("div", {
					className: "dixit-bottom",
					children: [/* @__PURE__ */ y("div", {
						className: "dixit-controls",
						children: [/* @__PURE__ */ y("div", {
							className: "dixit-hand-label",
							children: [
								r("games.dixit.hand"),
								" ",
								/* @__PURE__ */ v("span", { children: n?.hand.length ?? 0 })
							]
						}), /* @__PURE__ */ y("div", {
							className: "dixit-action",
							role: "group",
							"aria-label": B,
							children: [j && /* @__PURE__ */ v("input", {
								className: "dixit-clue-input",
								"aria-label": r("games.dixit.storyClue"),
								placeholder: r("games.dixit.cluePlaceholder"),
								maxLength: 160,
								value: C,
								onChange: (e) => w(e.target.value)
							}), t.phase === "result" && t.players.includes(e.myRid) ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("button", {
								type: "button",
								className: "dixit-btn",
								disabled: !n?.canNext,
								onClick: () => e.send({ type: "next" }),
								children: r(t.ready.includes(e.myRid) ? "games.dixit.confirmed" : F ? "games.dixit.finish" : "games.dixit.next")
							}), /* @__PURE__ */ v("span", {
								className: "dixit-selection-text",
								children: r("games.dixit.readyCount", {
									n: t.ready.length,
									total: t.players.length
								})
							})] }) : j ? /* @__PURE__ */ v("button", {
								type: "button",
								className: "dixit-btn",
								disabled: d.length !== 1 || !C.trim(),
								onClick: () => e.send({
									type: "story",
									card: d[0],
									clue: C
								}),
								children: r("games.dixit.tell")
							}) : M ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("span", {
								className: "dixit-selection-text",
								children: r("games.dixit.selected", {
									n: d.length,
									total: P
								})
							}), /* @__PURE__ */ v("button", {
								type: "button",
								className: "dixit-btn",
								disabled: d.length !== P,
								onClick: () => e.send({
									type: "submit",
									cards: d
								}),
								children: r("games.dixit.submit")
							})] }) : N ? /* @__PURE__ */ v("button", {
								type: "button",
								className: "dixit-btn",
								disabled: x === null,
								onClick: () => e.send({
									type: "vote",
									at: x
								}),
								children: r("games.dixit.vote")
							}) : n?.canNext ? /* @__PURE__ */ v("button", {
								type: "button",
								className: "dixit-btn",
								onClick: () => e.send({ type: "next" }),
								children: r(F ? "games.dixit.finish" : "games.dixit.next")
							}) : /* @__PURE__ */ v("span", {
								className: "dixit-selection-text",
								role: "status",
								children: B
							})]
						})]
					}), /* @__PURE__ */ v("div", {
						className: "dixit-hand-rail",
						ref: z,
						children: n?.hand.map((e) => /* @__PURE__ */ v(W, {
							card: e,
							anchor: `dx:hand:${e}`,
							legal: j || M,
							selected: d.includes(e),
							onPick: j || M ? () => V(e) : void 0,
							onZoom: () => E(e)
						}, e))
					})]
				}),
				children: /* @__PURE__ */ y("div", {
					className: "dixit-stage",
					children: [/* @__PURE__ */ y("div", {
						className: "dixit-gallery",
						ref: I,
						children: [t.cards.length ? /* @__PURE__ */ v("div", {
							className: "dixit-gallery-cards",
							style: { "--dixit-count": t.cards.length },
							children: t.cards.map((r, i) => {
								let a = n?.submitted.includes(r), o = t.reveal?.answer === i;
								return /* @__PURE__ */ v("div", {
									className: `dixit-exhibit ${o ? "is-answer" : ""}`,
									children: /* @__PURE__ */ v(W, {
										card: r,
										at: i,
										anchor: `dx:table:${i}`,
										own: !t.reveal && a,
										legal: N && !a,
										selected: x === i || n?.vote === i,
										onPick: N && !a ? () => S(i) : void 0,
										onZoom: () => E(r),
										overlay: t.reveal ? /* @__PURE__ */ v(q, {
											at: i,
											reveal: t.reveal,
											members: e.members,
											name: l
										}) : void 0
									})
								}, r);
							})
						}) : /* @__PURE__ */ y("div", {
							className: "dixit-empty",
							children: [/* @__PURE__ */ y("div", {
								className: `dixit-hidden-stack ${t.phase === "shuffle" ? "is-shuffling" : ""}`,
								children: [/* @__PURE__ */ v(U, { card: j ? d[0] : void 0 }), !j && /* @__PURE__ */ y("span", { children: [
									t.submitted.length,
									" / ",
									t.players.length
								] })]
							}), !j && /* @__PURE__ */ v("p", { children: r("games.dixit.tableWaiting") })]
						}), t.reveal && (t.phase === "reveal" || t.phase === "score") && /* @__PURE__ */ v(ne, {
							pub: t,
							members: e.members,
							name: l
						})]
					}), /* @__PURE__ */ y("div", {
						className: "dixit-piles",
						children: [/* @__PURE__ */ v("span", {
							ref: L,
							children: r("games.dixit.deck", { n: t.deckCount })
						}), /* @__PURE__ */ v("span", {
							ref: R,
							children: r("games.dixit.discard", { n: t.discardCount })
						})]
					})]
				})
			}),
			T !== null && /* @__PURE__ */ v(G, {
				label: r("games.dixit.card", { n: T + 1 }),
				onClose: () => E(null),
				children: /* @__PURE__ */ v("div", {
					className: "dixit-enlarged",
					children: /* @__PURE__ */ v(U, { card: T })
				})
			}),
			D && /* @__PURE__ */ v(G, {
				wide: !0,
				label: r("games.dixit.history"),
				onClose: () => O(!1),
				children: /* @__PURE__ */ v(J, {
					rounds: t.history,
					name: l
				})
			})
		]
	});
}
function ie({ rid: e, name: t, score: n, color: r, story: i, state: a, delta: s }) {
	let { ref: l } = o(`dx:seat:${e}`), { ref: u } = o(`dx:score:${e}`), d = c();
	return /* @__PURE__ */ y("div", {
		ref: l,
		className: `dixit-seat ${i ? "is-storyteller" : ""}`,
		style: { "--dixit-player": r },
		children: [
			/* @__PURE__ */ v("span", {
				className: "dixit-seat-name",
				title: t,
				children: t
			}),
			/* @__PURE__ */ y("strong", {
				ref: u,
				children: [/* @__PURE__ */ v("span", {
					className: "dixit-score-value",
					children: n
				}, n), s !== void 0 && s > 0 && /* @__PURE__ */ y("small", { children: ["+", s] })]
			}),
			/* @__PURE__ */ v("span", {
				className: "dixit-seat-state",
				children: i ? d("games.dixit.storyteller") : a || "—"
			})
		]
	});
}
function J({ rounds: e, name: t }) {
	let n = c(), [r, i] = a(null);
	return /* @__PURE__ */ y("div", {
		className: "dixit-history",
		children: [
			!e.length && /* @__PURE__ */ v("p", { children: n("games.dixit.noHistory") }),
			[...e].reverse().map((e) => /* @__PURE__ */ y("section", { children: [
				/* @__PURE__ */ y("h3", { children: [
					n("games.dixit.round", { n: e.round }),
					" · ",
					t(e.storyteller)
				] }),
				/* @__PURE__ */ v("blockquote", { children: e.clue }),
				/* @__PURE__ */ v("div", {
					className: "dixit-history-cards",
					children: e.cards.map((r, a) => /* @__PURE__ */ y("div", { children: [
						/* @__PURE__ */ v(W, {
							card: r,
							at: a,
							onZoom: () => i(r)
						}),
						/* @__PURE__ */ v("b", { children: a === e.reveal.answer ? n("games.dixit.answer") : t(e.reveal.owners[a]) }),
						/* @__PURE__ */ v("small", { children: n("games.dixit.votes", { n: Object.values(e.reveal.votes).filter((e) => e === a).length }) })
					] }, r))
				})
			] }, e.round)),
			r !== null && /* @__PURE__ */ v(G, {
				label: n("games.dixit.card", { n: r + 1 }),
				onClose: () => i(null),
				children: /* @__PURE__ */ v("div", {
					className: "dixit-enlarged",
					children: /* @__PURE__ */ v(U, { card: r })
				})
			})
		]
	});
}
//#endregion
//#region src/games/dixit/semantics.ts
var Y = [
	[
		"芭蕾",
		"ballet",
		"舞蹈",
		"dance",
		"鞋",
		"shoes",
		"丝带",
		"ribbon",
		"蜘蛛网",
		"web"
	],
	[
		"鹿",
		"deer",
		"墙",
		"wall",
		"头",
		"head",
		"水",
		"water",
		"盘子",
		"plate"
	],
	[
		"士兵",
		"soldier",
		"玩具",
		"toy",
		"战争",
		"war",
		"音乐",
		"music",
		"鼓",
		"drum"
	],
	[
		"雪",
		"snow",
		"城堡",
		"castle",
		"玻璃",
		"glass",
		"冬天",
		"winter",
		"孩子",
		"child"
	],
	[
		"指南针",
		"compass",
		"地图",
		"map",
		"旅行",
		"travel",
		"方向",
		"direction"
	],
	[
		"船",
		"ship",
		"蜗牛",
		"snail",
		"火",
		"fire",
		"海",
		"sea",
		"动物",
		"animal"
	],
	[
		"坠落",
		"fall",
		"男人",
		"man",
		"帽子",
		"hat",
		"天空",
		"sky"
	],
	[
		"猫",
		"cat",
		"鸟",
		"bird",
		"笼子",
		"cage",
		"月亮",
		"moon",
		"夜晚",
		"night"
	],
	[
		"灯塔",
		"lighthouse",
		"海",
		"sea",
		"光",
		"light",
		"手",
		"hand",
		"夜晚",
		"night"
	],
	[
		"沙漏",
		"hourglass",
		"时间",
		"time",
		"老人",
		"old man",
		"沙子",
		"sand"
	],
	[
		"书",
		"book",
		"骑士",
		"knight",
		"雪",
		"snow",
		"帽子",
		"hat",
		"故事",
		"story"
	],
	[
		"树",
		"tree",
		"花",
		"flower",
		"石头",
		"stone",
		"道路",
		"road",
		"春天",
		"spring"
	],
	[
		"画画",
		"painting",
		"狐狸",
		"fox",
		"鱼",
		"fish",
		"画布",
		"canvas",
		"艺术",
		"art"
	],
	[
		"长椅",
		"bench",
		"信",
		"letter",
		"鸟",
		"bird",
		"夜晚",
		"night",
		"孤独",
		"loneliness"
	],
	[
		"鸟",
		"bird",
		"笼子",
		"cage",
		"自由",
		"freedom",
		"天空",
		"sky"
	],
	[
		"花",
		"flower",
		"罂粟",
		"poppy",
		"白色",
		"white",
		"红色",
		"red",
		"春天",
		"spring"
	],
	[
		"书",
		"book",
		"鸟",
		"bird",
		"故事",
		"story",
		"知识",
		"knowledge",
		"孩子",
		"child"
	],
	[
		"刀",
		"knife",
		"森林",
		"forest",
		"植物",
		"plant",
		"危险",
		"danger"
	],
	[
		"树",
		"tree",
		"音乐",
		"music",
		"男人",
		"man",
		"鸟",
		"bird",
		"夜晚",
		"night"
	],
	[
		"锚",
		"anchor",
		"沙漠",
		"desert",
		"链条",
		"chain",
		"海",
		"sea",
		"旅行",
		"travel"
	],
	[
		"瓢虫",
		"ladybird",
		"剑",
		"sword",
		"昆虫",
		"insect",
		"危险",
		"danger"
	],
	[
		"房子",
		"house",
		"家",
		"home",
		"玩具",
		"toy",
		"孩子",
		"child"
	],
	[
		"泡泡",
		"bubble",
		"海",
		"sea",
		"天空",
		"sky",
		"夜晚",
		"night",
		"梦想",
		"dream"
	],
	[
		"温度计",
		"thermometer",
		"热",
		"heat",
		"月亮",
		"moon",
		"红色",
		"red"
	],
	[
		"龙卷风",
		"tornado",
		"手",
		"hand",
		"风",
		"wind",
		"灾难",
		"disaster"
	],
	[
		"巨人",
		"giant",
		"房子",
		"house",
		"男人",
		"man",
		"城市",
		"city",
		"吃",
		"eat"
	],
	[
		"龙",
		"dragon",
		"火",
		"fire",
		"男人",
		"man",
		"蓝色",
		"blue",
		"动物",
		"animal"
	],
	[
		"音乐",
		"music",
		"大提琴",
		"cello",
		"女孩",
		"girl",
		"雨",
		"rain"
	],
	[
		"雕像",
		"statue",
		"风",
		"wind",
		"女孩",
		"girl",
		"王冠",
		"crown"
	],
	[
		"手",
		"hand",
		"放大镜",
		"magnifier",
		"地图",
		"map",
		"探索",
		"exploration"
	],
	[
		"贝壳",
		"shell",
		"海",
		"sea",
		"男人",
		"man",
		"音乐",
		"music"
	],
	[
		"骰子",
		"dice",
		"植物",
		"plant",
		"触手",
		"tentacles",
		"红色",
		"red"
	],
	[
		"花",
		"flower",
		"黑色",
		"black",
		"白色",
		"white",
		"地面",
		"ground"
	],
	[
		"猫",
		"cat",
		"鱼",
		"fish",
		"玻璃",
		"glass",
		"星星",
		"stars",
		"夜晚",
		"night"
	],
	[
		"机器人",
		"robot",
		"音乐",
		"music",
		"钥匙",
		"key",
		"黄色",
		"yellow"
	],
	[
		"纸",
		"paper",
		"风",
		"wind",
		"鸟",
		"bird",
		"天空",
		"sky",
		"冬天",
		"winter"
	],
	[
		"天平",
		"scales",
		"重量",
		"weight",
		"羽毛",
		"feather",
		"肉",
		"meat"
	],
	[
		"蛋",
		"egg",
		"鸭子",
		"duck",
		"孩子",
		"child",
		"信",
		"letter",
		"动物",
		"animal"
	],
	[
		"迷宫",
		"maze",
		"路",
		"path",
		"怪物",
		"monster",
		"寻找",
		"search",
		"旅行",
		"travel"
	],
	[
		"楼梯",
		"stairs",
		"天空",
		"sky",
		"云",
		"cloud",
		"道路",
		"road",
		"梦想",
		"dream"
	],
	[
		"梯子",
		"ladder",
		"鸟",
		"bird",
		"天空",
		"sky",
		"孩子",
		"child",
		"自由",
		"freedom"
	],
	[
		"算盘",
		"abacus",
		"星球",
		"planet",
		"宇宙",
		"space",
		"数学",
		"math"
	],
	[
		"兔子",
		"rabbit",
		"门",
		"door",
		"骑士",
		"knight",
		"盔甲",
		"armour",
		"勇气",
		"courage"
	],
	[
		"光",
		"light",
		"人偶",
		"puppet",
		"孤独",
		"loneliness",
		"白色",
		"white"
	],
	[
		"水滴",
		"drop",
		"植物",
		"plant",
		"水",
		"water",
		"世界",
		"world"
	],
	[
		"房子",
		"house",
		"城市",
		"city",
		"夜晚",
		"night",
		"人群",
		"crowd"
	],
	[
		"头发",
		"hair",
		"戒指",
		"ring",
		"女孩",
		"girl",
		"爱情",
		"love"
	],
	[
		"灯泡",
		"lightbulb",
		"魔法",
		"magic",
		"女孩",
		"girl",
		"星星",
		"stars"
	],
	[
		"女孩",
		"girl",
		"人偶",
		"puppet",
		"头发",
		"hair",
		"选择",
		"choice"
	],
	[
		"植物",
		"plant",
		"自行车",
		"bicycle",
		"男人",
		"man",
		"成长",
		"growth"
	],
	[
		"怪物",
		"monster",
		"黑色",
		"black",
		"水",
		"water",
		"旅行",
		"travel",
		"海",
		"sea"
	],
	[
		"戏剧",
		"theatre",
		"老人",
		"old man",
		"人偶",
		"puppet",
		"故事",
		"story"
	],
	[
		"木偶",
		"marionette",
		"国王",
		"king",
		"王冠",
		"crown",
		"椅子",
		"chair"
	],
	[
		"旋转木马",
		"carousel",
		"夜晚",
		"night",
		"马",
		"horse",
		"玩具",
		"toy"
	],
	[
		"蚂蚁",
		"ant",
		"金币",
		"coins",
		"财富",
		"wealth",
		"昆虫",
		"insect"
	],
	[
		"棋",
		"chess",
		"老人",
		"old man",
		"男人",
		"man",
		"游戏",
		"game"
	],
	[
		"蜡烛",
		"candle",
		"光",
		"light",
		"黑暗",
		"darkness",
		"火",
		"fire"
	],
	[
		"熊",
		"bear",
		"孩子",
		"child",
		"玩具",
		"toy",
		"朋友",
		"friend"
	],
	[
		"怪物",
		"monster",
		"牙齿",
		"teeth",
		"音乐",
		"music",
		"号角",
		"horn",
		"危险",
		"danger"
	],
	[
		"水滴",
		"drop",
		"雨",
		"rain",
		"岛屿",
		"island",
		"水",
		"water"
	],
	[
		"气球",
		"balloon",
		"城堡",
		"castle",
		"天空",
		"sky",
		"旅行",
		"travel"
	],
	[
		"蜗牛",
		"snail",
		"螺旋",
		"spiral",
		"链条",
		"chain",
		"时间",
		"time"
	],
	[
		"老鼠",
		"mouse",
		"镜子",
		"mirror",
		"城堡",
		"castle",
		"梦想",
		"dream"
	],
	[
		"森林",
		"forest",
		"幽灵",
		"ghost",
		"树",
		"tree",
		"孤独",
		"loneliness"
	],
	[
		"树",
		"tree",
		"太阳",
		"sun",
		"月亮",
		"moon",
		"四季",
		"seasons",
		"生命",
		"life"
	],
	[
		"面具",
		"mask",
		"戏剧",
		"theatre",
		"悲伤",
		"sadness",
		"脸",
		"face"
	],
	[
		"餐桌",
		"table",
		"食物",
		"food",
		"宴会",
		"feast",
		"吃",
		"eat"
	],
	[
		"星星",
		"stars",
		"月亮",
		"moon",
		"天空",
		"sky",
		"山",
		"mountain"
	],
	[
		"女孩",
		"girl",
		"睡觉",
		"sleep",
		"海",
		"sea",
		"梦",
		"dream"
	],
	[
		"怀表",
		"watch",
		"时间",
		"time",
		"宇宙",
		"space",
		"夜晚",
		"night"
	],
	[
		"女孩",
		"girl",
		"风",
		"wind",
		"书",
		"book",
		"黄色",
		"yellow"
	],
	[
		"独角兽",
		"unicorn",
		"彩虹",
		"rainbow",
		"森林",
		"forest",
		"桥",
		"bridge"
	],
	[
		"门",
		"door",
		"天空",
		"sky",
		"自由",
		"freedom",
		"石头",
		"stone"
	],
	[
		"狼",
		"wolf",
		"影子",
		"shadow",
		"孩子",
		"child",
		"黑暗",
		"darkness",
		"恐惧",
		"fear"
	],
	[
		"月亮",
		"moon",
		"山",
		"mountain",
		"树叶",
		"leaves",
		"秋天",
		"autumn"
	],
	[
		"床",
		"bed",
		"监狱",
		"prison",
		"男人",
		"man",
		"睡觉",
		"sleep",
		"梦",
		"dream"
	],
	[
		"玩具",
		"toy",
		"梯子",
		"ladder",
		"汽车",
		"car",
		"房间",
		"room",
		"童年",
		"childhood"
	],
	[
		"楼梯",
		"stairs",
		"门",
		"door",
		"男人",
		"man",
		"道路",
		"road",
		"天空",
		"sky"
	],
	[
		"雪",
		"snow",
		"房子",
		"house",
		"冬天",
		"winter",
		"男人",
		"man",
		"寒冷",
		"cold"
	],
	[
		"火",
		"fire",
		"玫瑰",
		"rose",
		"花",
		"flower",
		"玻璃",
		"glass",
		"爱情",
		"love"
	],
	[
		"魔法",
		"magic",
		"书",
		"book",
		"瓶子",
		"bottle",
		"老人",
		"old man"
	],
	[
		"女孩",
		"girl",
		"雪",
		"snow",
		"风",
		"wind",
		"冬天",
		"winter"
	],
	[
		"树叶",
		"leaves",
		"男人",
		"man",
		"昆虫",
		"insect",
		"春天",
		"spring"
	],
	[
		"稻草人",
		"scarecrow",
		"花",
		"flower",
		"太阳",
		"sun",
		"田野",
		"field",
		"夏天",
		"summer"
	]
];
function X(e, t) {
	let n = t.normalize("NFKC").toLowerCase();
	return Y[e].filter((e) => n.includes(e)).length;
}
//#endregion
//#region src/games/dixit/bot.ts
function ae(e) {
	let t = Math.floor(4294967296 / e) * e, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return n[0] % e;
}
var Z = (e) => e[ae(e.length)], oe = { ambiguityTarget: .22 };
function se(e = oe) {
	return ({ public: t, private: n }, r) => {
		if (!n) return null;
		let i = r.difficulty === "weak";
		if (n.canStory) {
			let t = n.hand.flatMap((t) => Y[t].filter((e, t) => t % 2 == 0).map((n) => {
				let r = 1 - (1 - (Y.filter((e) => e.includes(n)).length - 1) / 83) ** 6;
				return {
					card: t,
					clue: n,
					score: -Math.abs(r - e.ambiguityTarget)
				};
			})), r = Math.max(...t.map((e) => e.score)), a = Z(i ? t : t.filter((e) => Math.abs(e.score - r) < 1e-8));
			return { action: {
				type: "story",
				card: a.card,
				clue: a.clue
			} };
		}
		if (t.phase === "submit" && t.storyteller !== r.rid && !t.submitted.includes(r.rid)) {
			let e = [...n.hand], r = [];
			for (let n = 0; n < (t.players.length === 3 ? 2 : 1); n++) {
				let n = Math.max(...e.map((e) => X(e, t.clue))), a = Z(i ? e : e.filter((e) => X(e, t.clue) === n));
				r.push(a), e.splice(e.indexOf(a), 1);
			}
			return { action: {
				type: "submit",
				cards: r
			} };
		}
		if (t.phase === "vote" && t.storyteller !== r.rid && !t.voted.includes(r.rid)) {
			let e = t.cards.map((e, t) => ({
				card: e,
				at: t
			})).filter((e) => !n.submitted.includes(e.card)), r = Math.max(...e.map((e) => X(e.card, t.clue)));
			return { action: {
				type: "vote",
				at: Z(i ? e : e.filter((e) => X(e.card, t.clue) === r)).at
			} };
		}
		return n.canNext ? { action: { type: "next" } } : null;
	};
}
var ce = se();
//#endregion
//#region src/games/dixit/fx.tsx
function Q(e, t = 65) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - t * 1.4) / 2,
		w: t,
		h: t * 1.4
	};
}
function $({ card: e, box: t }) {
	return /* @__PURE__ */ v("div", {
		style: {
			width: t.w,
			height: t.h
		},
		children: /* @__PURE__ */ v(U, { card: e })
	});
}
function le({ card: e, box: t, ms: n }) {
	let a = i(null);
	return r(() => {
		let e = a.current?.animate([{
			transform: "scaleX(.04)",
			opacity: .25
		}, {
			transform: "scaleX(1)",
			opacity: 1
		}], {
			duration: n,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [n]), /* @__PURE__ */ v("div", {
		ref: a,
		style: {
			position: "absolute",
			left: t.x,
			top: t.y,
			width: t.w,
			height: t.h
		},
		children: /* @__PURE__ */ v(U, { card: e })
	});
}
function ue({ member: e, points: t, size: n }) {
	let a = i(null);
	return r(() => {
		let e = a.current?.firstElementChild, t = a.current?.lastElementChild, n = {
			duration: P.award,
			fill: "both"
		}, r = e?.animate([
			{ opacity: 1 },
			{
				opacity: 1,
				offset: .2
			},
			{
				opacity: 0,
				offset: .45
			},
			{ opacity: 0 }
		], n), i = t?.animate([
			{
				opacity: 0,
				transform: "scale(.6)"
			},
			{
				opacity: 0,
				transform: "scale(.6)",
				offset: .2
			},
			{
				opacity: 1,
				transform: "scale(1)",
				offset: .45
			},
			{
				opacity: 1,
				transform: "scale(1)"
			}
		], n);
		return () => {
			r?.cancel(), i?.cancel();
		};
	}, []), /* @__PURE__ */ y("div", {
		ref: a,
		className: "dixit-award-token",
		style: {
			width: n,
			height: n
		},
		children: [/* @__PURE__ */ v(K, {
			member: e,
			name: e?.name ?? ""
		}), /* @__PURE__ */ y("b", { children: ["+", t] })]
	});
}
var de = {
	dixitSubmit(e, t) {
		let n = t.anchor(e.rid === t.myRid ? "dx:hand" : `dx:seat:${e.rid}`), r = t.anchor("dx:table");
		if (!n || !r) return null;
		let i = Q(n), a = Q(r);
		return {
			ms: 360,
			node: /* @__PURE__ */ v(x, {
				from: i,
				to: a,
				ms: 360,
				children: /* @__PURE__ */ v($, { box: i })
			})
		};
	},
	dixitReveal(e, t) {
		let n = e.data.cards, r = t.anchor("dx:table");
		if (!r) return null;
		let i = Math.min(P.shuffle, 420);
		return {
			ms: i,
			hide: t.queued ? [] : n.map((e, t) => `dx:table:${t}`),
			node: /* @__PURE__ */ v("div", {
				style: {
					position: "absolute",
					left: r.x,
					top: r.y,
					width: r.w,
					height: r.h,
					overflow: "hidden"
				},
				children: n.map((e, n) => {
					let a = t.anchor(`dx:table:${n}`);
					return a ? /* @__PURE__ */ v(le, {
						card: e,
						box: {
							...a,
							x: a.x - r.x,
							y: a.y - r.y
						},
						ms: i
					}, e) : null;
				})
			})
		};
	},
	dixitAnswer(e, t) {
		let n = t.anchor("dx:focus:card") ?? t.anchor(`dx:table:${e.data.at}`);
		return n ? {
			ms: P.reveal,
			node: /* @__PURE__ */ v(S, {
				at: n,
				ms: P.reveal
			})
		} : null;
	},
	dixitScore(e, t) {
		let n = e.data.awards.flatMap((e) => {
			let n = `dx:focus:${e.source}:${e.rid}`, r = t.anchor(n), i = t.anchor(`dx:score:${e.rid}`);
			return r && i ? [{
				...e,
				source: n,
				from: r,
				to: {
					x: i.x + i.w / 2 - 18,
					y: i.y + i.h / 2 - 18,
					w: 36,
					h: 36
				}
			}] : [];
		});
		return {
			ms: P.award,
			hide: t.queued ? [] : n.map((e) => e.source),
			node: /* @__PURE__ */ v(_, { children: n.map((e) => /* @__PURE__ */ v(x, {
				from: e.from,
				to: e.to,
				ms: P.award,
				children: /* @__PURE__ */ v(ue, {
					member: t.member(e.rid),
					points: e.points,
					size: e.from.w
				})
			}, e.rid)) })
		};
	},
	dixitDiscard(e, t) {
		let n = t.anchor("dx:discard"), r = t.anchor("dx:table"), i = e.data.cards;
		if (!n || !r) return null;
		let a = n.y + n.h;
		return {
			ms: P.discard,
			hide: t.queued ? [] : i.map((e, t) => `dx:table:${t}`),
			node: /* @__PURE__ */ v("div", {
				style: {
					position: "absolute",
					inset: 0,
					clipPath: `polygon(0px ${r.y}px,100% ${r.y}px,100% ${a}px,0px ${a}px)`
				},
				children: i.map((e, i) => {
					let a = t.anchor(`dx:table:${i}`);
					return a && a.y + a.h > r.y && a.y < r.y + r.h ? /* @__PURE__ */ v(x, {
						from: a,
						to: Q(n, 24),
						ms: P.discard,
						children: /* @__PURE__ */ v($, {
							card: e,
							box: a
						})
					}, e) : null;
				})
			})
		};
	},
	dixitDraw(e, t) {
		let n = t.anchor("dx:deck"), r = t.anchor(e.rid === t.myRid ? "dx:hand" : `dx:seat:${e.rid}`);
		if (!n || !r) return null;
		let i = e.secret?.cards, a = e.data.count, o = Q(n, 35), s = i?.map((e) => `dx:hand:${e}`) ?? [];
		return {
			ms: P.refill,
			hide: t.queued ? [] : s,
			node: /* @__PURE__ */ v(_, { children: Array.from({ length: a }, (e, n) => {
				let s = i?.[n], c = s === void 0 ? Q(r, 40) : t.anchor(`dx:hand:${s}`) ?? Q(r);
				return /* @__PURE__ */ v(x, {
					from: o,
					to: c,
					ms: P.refill - 20 - (a - 1) * 35,
					delay: n * 35,
					children: /* @__PURE__ */ v($, {
						card: s,
						box: o
					})
				}, n);
			}) })
		};
	}
};
//#endregion
//#region src/games/dixit/game-over.tsx
function fe({ public: e, result: t, members: n, hintCount: r, onPlayAgain: i, onBackToLobby: o }) {
	let u = e, d = c(), f = s((e) => e.locale), p = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? g(t, f) : e;
	}, [m, h] = a(!0), [b, x] = a(null);
	return /* @__PURE__ */ y("div", {
		className: "dixit-screen dixit-over",
		children: [
			/* @__PURE__ */ y("div", {
				className: "dixit-over-backdrop",
				inert: m,
				children: [/* @__PURE__ */ v("h1", { children: d("games.dixit.history") }), /* @__PURE__ */ v(J, {
					rounds: u.history,
					name: p
				})]
			}),
			!m && /* @__PURE__ */ v("button", {
				type: "button",
				className: "dixit-btn dixit-show-result",
				onClick: () => h(!0),
				children: d("games.dixit.showResult")
			}),
			m && /* @__PURE__ */ v("div", {
				className: "dixit-over-cover",
				children: /* @__PURE__ */ y("section", {
					className: "dixit-score-panel",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": d("games.dixit.resultTitle"),
					children: [
						/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("span", {
							className: "dixit-wordmark",
							children: "Dixit"
						}), /* @__PURE__ */ v("h1", { children: d("games.dixit.resultTitle") })] }), /* @__PURE__ */ v("button", {
							type: "button",
							className: "dixit-icon-btn",
							onClick: () => h(!1),
							"aria-label": d("games.dixit.review"),
							children: /* @__PURE__ */ v(l, { size: 23 })
						})] }),
						/* @__PURE__ */ y("div", {
							className: "dixit-score-scroll",
							children: [
								/* @__PURE__ */ y("p", {
									className: "dixit-winners",
									children: [
										t.winner.map(p).join(" · "),
										" · ",
										d("games.dixit.winner")
									]
								}),
								/* @__PURE__ */ v("div", {
									className: "dixit-score-table",
									children: /* @__PURE__ */ y("table", { children: [/* @__PURE__ */ v("thead", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", { children: d("games.dixit.round", { n: u.round }) }), t.ranking.map((e) => /* @__PURE__ */ y("th", { children: [p(e), t.winner.includes(e) && /* @__PURE__ */ v("small", { children: d("games.dixit.winner") })] }, e))] }) }), /* @__PURE__ */ v("tbody", { children: [
										{
											label: d("games.dixit.base"),
											scores: u.baseScores
										},
										{
											label: d("games.dixit.bonus"),
											scores: u.bonusScores
										},
										{
											label: d("games.dixit.total"),
											scores: u.scores
										}
									].map((e) => /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", { children: e.label }), t.ranking.map((t) => /* @__PURE__ */ v("td", { children: e.scores[t] }, t))] }, e.label)) })] })
								}),
								r !== void 0 && /* @__PURE__ */ v("p", { children: d("session.hint.usedCount", { n: r }) }),
								Object.entries(t.autopilot ?? {}).map(([e, t]) => /* @__PURE__ */ y("p", { children: [
									p(e),
									" · ",
									d("session.autopilot.share", { n: Math.round(t * 100) })
								] }, e))
							]
						}),
						/* @__PURE__ */ v("footer", { children: b ? /* @__PURE__ */ y(_, { children: [
							/* @__PURE__ */ v("span", { children: d(b === "again" ? "games.dixit.confirmAgain" : "games.dixit.confirmLeave") }),
							/* @__PURE__ */ v("button", {
								type: "button",
								className: "dixit-btn dixit-btn-quiet",
								onClick: () => x(null),
								children: d("games.dixit.cancel")
							}),
							/* @__PURE__ */ v("button", {
								type: "button",
								className: "dixit-btn",
								onClick: () => {
									b === "again" ? i?.() : o?.();
								},
								children: d("games.dixit.confirm")
							})
						] }) : i || o ? /* @__PURE__ */ y(_, { children: [i && /* @__PURE__ */ v("button", {
							type: "button",
							className: "dixit-btn",
							onClick: () => x("again"),
							children: d("session.result.playAgain")
						}), o && /* @__PURE__ */ v("button", {
							type: "button",
							className: "dixit-btn dixit-btn-quiet",
							onClick: () => x("leave"),
							children: d("session.result.backToLobby")
						})] }) : /* @__PURE__ */ v("p", { children: d("session.result.waitHost") }) })
					]
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/dixit/entry.tsx
var pe = {
	definition: H,
	View: re,
	bot: ce,
	fx: de,
	OverView: fe,
	locales: {
		zh: {
			name: "画物语",
			desc: "用一句线索讲述梦境，在众多画面中找到说书人的牌",
			rules: "目标：\n某轮结束时有人达到 30 分，游戏结束，总分最高者获胜，并列者共同获胜。\n准备：\n使用基础版 84 张图画牌，支持 3 至 8 人。每人获得 6 张手牌；3 人局每人 7 张。第一位想好线索并出牌的玩家担任首轮说书人，此后顺时针轮换。\n讲述：\n说书人从手牌中暗置 1 张，给出与画面有关的词语、句子或其他线索。在线对局中输入文字；口头或声音线索也须在输入框中留下便于辨认的说明。\n选牌：\n其他玩家各从手牌暗置 1 张与线索相符的牌。3 人局中，每位其他玩家暗置 2 张不同的牌。\n猜牌：\n所有暗置牌混洗后公开并编号。除说书人外，每人秘密投票选择 1 张自己认为属于说书人的牌，不得投给自己提交的牌。全部投票完成后揭晓。\n计分：\n根据本轮猜牌结果，按以下方式计分：\n· 所有人都猜中或所有人都猜错时，说书人获得0分，其他玩家各获得2分。\n· 其他情况下，说书人与猜中的玩家各获得3分，猜错的玩家获得0分。\n此外，每位非说书人玩家提交的牌每获得1票，该玩家额外获得1分。\n换轮：\n逐张结算完成后，每位玩家确认继续。所有玩家确认后，未达到结束条件时，本轮牌进入弃牌堆，每人补回 6 张手牌（3 人局补回 7 张）。牌库不足以为所有玩家补牌时，将剩余牌库与弃牌堆混洗后再补牌。牌库耗尽本身不会结束游戏。\n机器人：\n普通机器人通过固定的中英文画面词汇联想线索、选牌和猜牌，适合具体词语；它无法可靠理解任意隐喻、典故或声音。弱机器人随机选牌与猜牌。",
			round: "第 {{n}} 轮",
			storyteller: "说书人",
			chooseStory: "选择 1 张牌并输入线索",
			firstStory: "选择 1 张牌并输入线索，成为首轮说书人",
			waitStory: "等待 {{name}} 给出线索",
			submitPrompt: "选择 {{n}} 张与线索相符的牌",
			votePrompt: "选择你认为属于说书人的牌",
			waiting: "等待其他玩家",
			shuffle: "正在混洗",
			revealing: "揭晓答案",
			scoring: "本轮计分",
			discarding: "收起本轮牌",
			refilling: "补充手牌",
			roundResult: "本轮结果",
			storyClue: "线索",
			cluePlaceholder: "写下你的线索",
			tell: "讲述",
			submit: "暗置选中的牌",
			vote: "确认投票",
			next: "进入下一轮",
			finish: "查看最终结算",
			hand: "你的手牌",
			selected: "已选择 {{n}} / {{total}} 张",
			card: "图画牌 {{n}}",
			tableCard: "桌面第 {{n}} 张牌",
			zoom: "放大查看",
			close: "关闭",
			ownCard: "你的牌",
			yourVote: "你的投票",
			answer: "说书人的牌",
			votes: "{{n}} 票",
			points: "{{n}} 分",
			deck: "牌库 {{n}}",
			discard: "弃牌 {{n}}",
			submitted: "已出牌",
			voted: "已投票",
			ready: "已准备",
			empty: "故事即将开始",
			tableWaiting: "等待所有玩家选牌",
			history: "故事回顾",
			noHistory: "还没有已完成的故事",
			owner: "牌主",
			cardOwner: "{{name}}的牌",
			noVotes: "无人投票",
			confirmed: "已确认",
			readyCount: "已准备 {{n}} / {{total}}",
			scoringCard: "第 {{n}} / {{total}} 张",
			cardResult: "本牌结果",
			noneCorrect: "所有人猜错：说书人获得 0 分，其他玩家各获得 2 分。",
			allCorrect: "所有人猜中：说书人获得 0 分，其他玩家各获得 2 分。",
			someCorrect: "部分玩家猜中：说书人和猜中的玩家各获得 3 分。",
			votersTwo: "选择本牌的玩家各获得 2 分。",
			votersZero: "选择本牌的玩家未猜中，猜牌得分为 0 分。",
			noStoryBonus: "说书人的牌不获得吸引选票奖励。",
			cardBonus: "本牌获得 {{n}} 票，牌主获得 {{n}} 分奖励。",
			returnGame: "返回对局",
			resultTitle: "梦境的回响",
			winner: "获胜",
			total: "总分",
			base: "猜牌与讲述",
			bonus: "吸引投票",
			review: "回看故事",
			showResult: "展开结算",
			confirmAgain: "确定再来一局？",
			confirmLeave: "确定返回大厅？",
			cancel: "取消",
			confirm: "确定",
			botLimit: "普通机器人擅长具体的中英文画面词语，难以理解隐喻或声音。",
			errAction: "此操作不可用。",
			errPhase: "当前阶段不能进行此操作。",
			errCard: "请选择所需数量的不同手牌，并填写有效线索。",
			errSubmitted: "你已经完成了本阶段的操作。",
			errVote: "请选择桌面上的一张牌，不能投给自己的牌。"
		},
		en: {
			name: "Dixit",
			desc: "Tell a dream in a clue, then discover the storyteller’s card",
			rules: "Goal: when someone reaches 30 points at the end of a round, the game ends. The highest score wins; tied players share victory.\nSetup: 84 base-game picture cards, for 3–8 players. Deal 6 cards each, or 7 each with 3 players. The first player to submit a card and clue becomes the first storyteller; the role then passes clockwise.\nTell a story: the storyteller secretly chooses 1 card and gives a related word, sentence or other clue. Enter text online; leave an identifiable text label for a spoken or sound clue.\nSubmit: each other player secretly chooses 1 card matching the clue. With 3 players, each other player chooses 2 different cards.\nVote: shuffle the submitted cards and display them with numbers. Every player except the storyteller secretly votes for the card they believe belongs to the storyteller. You cannot vote for your own card. Reveal after everyone votes.\nScore:\n· If everyone or nobody guesses correctly, the storyteller scores 0 points and every other player scores 2 points.\n· In every other case, the storyteller and each correct voter score 3 points, while incorrect voters score 0 points.\nAdditionally, each non-storyteller scores 1 point per vote attracted by their submitted cards.\nNext round: after the cards are scored one by one, every player confirms they are ready. Once everyone has confirmed, unless the game has ended, discard the displayed cards and refill everyone to 6 cards (7 with 3 players). If the draw pile cannot refill every hand, shuffle its remainder together with the discard pile before drawing. Running out of cards does not end the game.\nBots: normal bots use a fixed bilingual vocabulary of visible objects to select clues, decoys and votes. They cannot reliably understand arbitrary metaphors, cultural references or sounds. Weak bots submit and vote randomly.",
			round: "Round {{n}}",
			storyteller: "Storyteller",
			chooseStory: "Choose 1 card and enter a clue",
			firstStory: "Choose 1 card and a clue to become the first storyteller",
			waitStory: "Waiting for {{name}} to give a clue",
			submitPrompt: "Choose {{n}} cards matching the clue",
			votePrompt: "Choose the storyteller’s card",
			waiting: "Waiting for other players",
			shuffle: "Shuffling",
			revealing: "Revealing the answer",
			scoring: "Scoring the round",
			discarding: "Collecting the cards",
			refilling: "Refilling hands",
			roundResult: "Round result",
			storyClue: "Clue",
			cluePlaceholder: "Write your clue",
			tell: "Tell the story",
			submit: "Submit selected cards",
			vote: "Confirm vote",
			next: "Next round",
			finish: "Show final scores",
			hand: "Your hand",
			selected: "Selected {{n}} / {{total}}",
			card: "Picture card {{n}}",
			tableCard: "Table card {{n}}",
			zoom: "Enlarge",
			close: "Close",
			ownCard: "Your card",
			yourVote: "Your vote",
			answer: "Storyteller’s card",
			votes: "{{n}} votes",
			points: "{{n}} points",
			deck: "Draw pile {{n}}",
			discard: "Discard pile {{n}}",
			submitted: "Submitted",
			voted: "Voted",
			ready: "Ready",
			empty: "A story is about to begin",
			tableWaiting: "Waiting for everyone to submit",
			history: "Past stories",
			noHistory: "No completed stories yet",
			owner: "Owner",
			cardOwner: "{{name}}’s card",
			noVotes: "No votes",
			confirmed: "Confirmed",
			readyCount: "Ready {{n}} / {{total}}",
			scoringCard: "Card {{n}} / {{total}}",
			cardResult: "Card result",
			noneCorrect: "Nobody guessed correctly: the storyteller scores 0; every other player scores 2.",
			allCorrect: "Everyone guessed correctly: the storyteller scores 0; every other player scores 2.",
			someCorrect: "Some guessed correctly: the storyteller and each correct voter score 3.",
			votersTwo: "Each player who chose this card scores 2.",
			votersZero: "Players who chose this card guessed incorrectly and score 0 for guessing.",
			noStoryBonus: "The storyteller’s card earns no bonus for attracting votes.",
			cardBonus: "Votes received: {{n}}. Owner’s bonus score: {{n}}.",
			returnGame: "Back to game",
			resultTitle: "Echoes of a dream",
			winner: "Winner",
			total: "Total",
			base: "Guessing & storytelling",
			bonus: "Votes attracted",
			review: "Review stories",
			showResult: "Show scores",
			confirmAgain: "Play again?",
			confirmLeave: "Return to the lobby?",
			cancel: "Cancel",
			confirm: "Confirm",
			botLimit: "Normal bots recognize concrete Chinese and English picture words; metaphors and sounds are difficult.",
			errAction: "This action is unavailable.",
			errPhase: "You cannot do that in this phase.",
			errCard: "Choose the required number of different cards and enter a valid clue.",
			errSubmitted: "You have already acted in this phase.",
			errVote: "Choose a displayed card other than your own."
		}
	}
};
//#endregion
export { pe as default };
