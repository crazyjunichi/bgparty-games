import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useId as i, useMemo as a, useRef as o, useState as s } from "react";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconBack as u, IconBot as d, IconCheck as f, IconClose as p, IconExpand as m, IconLog as ee } from "@bgparty/sdk/icons";
import { Texture as te } from "@bgparty/sdk/texture";
import { GameScreen as ne } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as re } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as ie, seatName as h } from "@bgparty/sdk/ui/player-strip";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { Confetti as y } from "@bgparty/sdk/ui/confetti";
import { OptionSwitch as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/puertorico/data.ts
var x = [
	"corn",
	"indigo",
	"sugar",
	"tobacco",
	"coffee"
], S = () => ({
	corn: 0,
	indigo: 0,
	sugar: 0,
	tobacco: 0,
	coffee: 0
}), C = (e) => x.reduce((t, n) => t + e[n], 0), w = [
	"settler",
	"builder",
	"mayor",
	"craftsman",
	"trader",
	"captain",
	"prospector",
	"prospector2",
	"buccaneer"
], ae = [
	"smallIndigo",
	"smallSugar",
	"indigoPlant",
	"sugarMill",
	"tobaccoStorage",
	"coffeeRoaster",
	"smallMarket",
	"hacienda",
	"constructionHut",
	"smallWarehouse",
	"hospice",
	"office",
	"largeMarket",
	"largeWarehouse",
	"factory",
	"university",
	"harbor",
	"wharf",
	"guildHall",
	"residence",
	"fortress",
	"customsHouse",
	"cityHall"
], T = [
	"blackMarket",
	"forestHouse",
	"aqueduct",
	"storehouse",
	"guesthouse",
	"church",
	"tradingPost",
	"smallWharf",
	"lighthouse",
	"specialtyFactory",
	"library",
	"unionHall",
	"cloister",
	"statue"
], E = [
	"districtOffice",
	"royalSupplier",
	"chapel",
	"jeweler",
	"villa",
	"huntingLodge",
	"landOffice",
	"royalGarden"
], oe = [
	...ae,
	...T,
	...E
], D = {
	smallIndigo: {
		cost: 1,
		vp: 1,
		size: 1,
		slots: 1,
		count: 4,
		produces: "indigo"
	},
	smallSugar: {
		cost: 2,
		vp: 1,
		size: 1,
		slots: 1,
		count: 4,
		produces: "sugar"
	},
	indigoPlant: {
		cost: 3,
		vp: 2,
		size: 1,
		slots: 3,
		count: 3,
		produces: "indigo"
	},
	sugarMill: {
		cost: 4,
		vp: 2,
		size: 1,
		slots: 3,
		count: 3,
		produces: "sugar"
	},
	tobaccoStorage: {
		cost: 5,
		vp: 3,
		size: 1,
		slots: 3,
		count: 3,
		produces: "tobacco"
	},
	coffeeRoaster: {
		cost: 6,
		vp: 3,
		size: 1,
		slots: 2,
		count: 3,
		produces: "coffee"
	},
	smallMarket: {
		cost: 1,
		vp: 1,
		size: 1,
		slots: 1,
		count: 2
	},
	hacienda: {
		cost: 2,
		vp: 1,
		size: 1,
		slots: 1,
		count: 2
	},
	constructionHut: {
		cost: 2,
		vp: 1,
		size: 1,
		slots: 1,
		count: 2
	},
	smallWarehouse: {
		cost: 3,
		vp: 1,
		size: 1,
		slots: 1,
		count: 2
	},
	hospice: {
		cost: 4,
		vp: 2,
		size: 1,
		slots: 1,
		count: 2
	},
	office: {
		cost: 5,
		vp: 2,
		size: 1,
		slots: 1,
		count: 2
	},
	largeMarket: {
		cost: 5,
		vp: 2,
		size: 1,
		slots: 1,
		count: 2
	},
	largeWarehouse: {
		cost: 6,
		vp: 2,
		size: 1,
		slots: 1,
		count: 2
	},
	factory: {
		cost: 7,
		vp: 3,
		size: 1,
		slots: 1,
		count: 2
	},
	university: {
		cost: 8,
		vp: 3,
		size: 1,
		slots: 1,
		count: 2
	},
	harbor: {
		cost: 8,
		vp: 3,
		size: 1,
		slots: 1,
		count: 2
	},
	wharf: {
		cost: 9,
		vp: 3,
		size: 1,
		slots: 1,
		count: 2
	},
	guildHall: {
		cost: 10,
		vp: 4,
		size: 2,
		slots: 1,
		count: 1
	},
	residence: {
		cost: 10,
		vp: 4,
		size: 2,
		slots: 1,
		count: 1
	},
	fortress: {
		cost: 10,
		vp: 4,
		size: 2,
		slots: 1,
		count: 1
	},
	customsHouse: {
		cost: 10,
		vp: 4,
		size: 2,
		slots: 1,
		count: 1
	},
	cityHall: {
		cost: 10,
		vp: 4,
		size: 2,
		slots: 1,
		count: 1
	},
	blackMarket: {
		cost: 2,
		vp: 1,
		size: 1,
		slots: 1,
		count: 2
	},
	forestHouse: {
		cost: 2,
		vp: 1,
		size: 1,
		slots: 1,
		count: 2
	},
	aqueduct: {
		cost: 1,
		vp: 1,
		size: 1,
		slots: 1,
		count: 2
	},
	storehouse: {
		cost: 3,
		vp: 1,
		size: 1,
		slots: 1,
		count: 2
	},
	guesthouse: {
		cost: 4,
		vp: 2,
		size: 1,
		slots: 2,
		count: 2
	},
	church: {
		cost: 5,
		vp: 2,
		size: 1,
		slots: 1,
		count: 2
	},
	tradingPost: {
		cost: 5,
		vp: 2,
		size: 1,
		slots: 1,
		count: 2
	},
	smallWharf: {
		cost: 6,
		vp: 2,
		size: 1,
		slots: 1,
		count: 2
	},
	lighthouse: {
		cost: 7,
		vp: 3,
		size: 1,
		slots: 1,
		count: 2
	},
	specialtyFactory: {
		cost: 8,
		vp: 3,
		size: 1,
		slots: 1,
		count: 2
	},
	library: {
		cost: 8,
		vp: 3,
		size: 1,
		slots: 1,
		count: 2
	},
	unionHall: {
		cost: 9,
		vp: 3,
		size: 1,
		slots: 1,
		count: 2
	},
	cloister: {
		cost: 10,
		vp: 4,
		size: 2,
		slots: 1,
		count: 1
	},
	statue: {
		cost: 10,
		vp: 8,
		size: 2,
		slots: 0,
		count: 1
	},
	districtOffice: {
		cost: 5,
		vp: 2,
		size: 1,
		slots: 1,
		count: 2
	},
	royalSupplier: {
		cost: 6,
		vp: 2,
		size: 1,
		slots: 1,
		count: 2
	},
	chapel: {
		cost: 3,
		vp: 1,
		size: 1,
		slots: 1,
		count: 2
	},
	jeweler: {
		cost: 8,
		vp: 3,
		size: 1,
		slots: 1,
		count: 2,
		production: !0
	},
	villa: {
		cost: 7,
		vp: 3,
		size: 1,
		slots: 1,
		count: 2
	},
	huntingLodge: {
		cost: 4,
		vp: 2,
		size: 1,
		slots: 1,
		count: 2
	},
	landOffice: {
		cost: 2,
		vp: 1,
		size: 1,
		slots: 1,
		count: 2
	},
	royalGarden: {
		cost: 10,
		vp: 4,
		size: 2,
		slots: 1,
		count: 1
	}
}, O = (e) => !!D[e].produces || !!D[e].production, se = (e) => D[e].size === 2 ? 4 : D[e].vp, ce = [
	1,
	2,
	2,
	3,
	4,
	5,
	5,
	6,
	7,
	8,
	8,
	9,
	10,
	10,
	10,
	10,
	10
], le = [
	2,
	3,
	4,
	5,
	6,
	7,
	10
], k = {
	corn: 10,
	indigo: 11,
	sugar: 11,
	tobacco: 9,
	coffee: 9
}, ue = {
	corn: 10,
	indigo: 12,
	sugar: 11,
	tobacco: 9,
	coffee: 8
}, A = {
	corn: "#d5a62f",
	indigo: "#5475ad",
	sugar: "#eee0bd",
	tobacco: "#a78256",
	coffee: "#695044",
	quarry: "#9ba5a9",
	forest: "#587f4b"
}, j = {
	id: "puertorico",
	tier: "beta",
	mechanics: ["engine-building", "drafting"],
	interactionTags: [],
	nameKey: "games.puertorico.name",
	descKey: "games.puertorico.desc",
	rulesKey: "games.puertorico.rules",
	icon: "🏝️",
	iconImg: "games/puertorico.webp",
	rulesUrl: { it: "https://cdn.ravensburger.com/content/wcm/mediadata/images/Italy/Scopri/Product%20Specials/Puerto%20Rico/ISTRUZIONI_26928_v2.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	accent: "#287b83",
	releasedAt: "2026-10-24T18:21:06+08:00",
	search: {
		py: "bo duo li ge",
		init: "bdlg"
	},
	hotseat: "cover"
}, M = t.enum(x), N = t.enum(oe), P = t.enum(w), F = t.object({
	corn: t.int().nonnegative(),
	indigo: t.int().nonnegative(),
	sugar: t.int().nonnegative(),
	tobacco: t.int().nonnegative(),
	coffee: t.int().nonnegative()
}), I = t.int().nonnegative(), de = t.object({
	newBuildings: t.boolean().default(!1),
	nobles: t.boolean().default(!1),
	buccaneer: t.boolean().default(!1),
	festival: t.boolean().default(!1)
}).default({
	newBuildings: !1,
	nobles: !1,
	buccaneer: !1,
	festival: !1
}), fe = t.object({
	kind: t.enum([
		"plantation",
		"building",
		"harbor"
	]),
	index: I,
	noble: t.boolean().optional()
}), pe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draft"),
		building: N
	}),
	t.object({
		type: t.literal("role"),
		role: P
	}),
	t.object({
		type: t.literal("recruit"),
		noble: t.boolean()
	}),
	t.object({
		type: t.literal("royalSupply"),
		goods: F
	}),
	t.object({
		type: t.literal("removePlantation"),
		index: I
	}),
	t.object({ type: t.literal("buyLand") }),
	t.object({
		type: t.literal("piracy"),
		ship: I.max(2),
		keep: I.max(3)
	}),
	t.object({ type: t.literal("plunder") }),
	t.object({
		type: t.literal("raid"),
		leaveNobles: I,
		placements: t.array(fe).max(3)
	}),
	t.object({
		type: t.literal("kidnap"),
		role: P
	}),
	t.object({
		type: t.literal("plant"),
		index: t.int().min(-1).max(5),
		hospice: t.boolean(),
		forest: t.boolean().optional(),
		noble: t.boolean().optional()
	}),
	t.object({ type: t.literal("hacienda") }),
	t.object({
		type: t.literal("placeDrawn"),
		forest: t.boolean()
	}),
	t.object({
		type: t.literal("guest"),
		target: fe
	}),
	t.object({
		type: t.literal("build"),
		building: N,
		university: t.boolean(),
		noble: t.boolean().optional(),
		payment: t.object({
			worker: fe.nullable(),
			good: M.nullable(),
			vp: t.boolean()
		}).optional()
	}),
	t.object({
		type: t.literal("assign"),
		plantations: t.array(I).max(12),
		buildings: t.array(I).max(12),
		noblePlantations: t.array(I).max(12).optional(),
		nobleBuildings: t.array(I).max(12).optional()
	}),
	t.object({
		type: t.literal("produce"),
		goods: F
	}),
	t.object({
		type: t.literal("bonus"),
		good: M
	}),
	t.object({
		type: t.literal("trade"),
		good: M,
		privateSale: t.boolean().optional()
	}),
	t.object({
		type: t.literal("ship"),
		good: M,
		ship: t.int().min(-1).max(2)
	}),
	t.object({
		type: t.literal("smallWharf"),
		goods: F
	}),
	t.object({
		type: t.literal("store"),
		goods: F
	}),
	t.object({ type: t.literal("pass") })
]), me = t.object({
	kind: t.enum([
		...x,
		"quarry",
		"forest"
	]),
	workers: t.int().min(0).max(1),
	nobles: I.optional(),
	crop: M.optional()
}), he = t.object({
	id: N,
	workers: t.int().min(0).max(3),
	nobles: I.optional()
}), ge = t.object({
	rid: t.string(),
	money: t.int().nonnegative(),
	goods: F,
	plantations: t.array(me).max(12),
	buildings: t.array(he).max(12),
	unemployed: t.int().nonnegative(),
	unemployedNobles: I.optional()
}), _e = t.enum([
	"draft",
	"role",
	"buccaneer",
	"settler",
	"settlerExtra",
	"forest",
	"guesthouse",
	"builder",
	"recruit",
	"mayor",
	"craftsman",
	"bonus",
	"landOffice",
	"hunting",
	"royalSupplier",
	"trader",
	"captain",
	"storage",
	"done"
]), L = t.object({
	tokens: I,
	buildings: I,
	bonus: I,
	nobles: I,
	total: t.int().nonnegative(),
	tie: t.int().nonnegative()
}), ve = t.object({
	config: de,
	draftSlots: t.array(I),
	guestContext: _e.nullable(),
	buccaneerOwner: t.string().nullable(),
	kidnapped: t.object({
		rid: t.string(),
		role: P
	}).nullable(),
	festival: t.object({
		plantation: t.object({
			good: M,
			claimedBy: t.string().nullable()
		}),
		production: t.object({
			goods: F,
			claimedBy: t.string().nullable()
		}),
		building: t.object({
			id: N.nullable(),
			claimedBy: t.string().nullable()
		})
	}).nullable(),
	phase: _e,
	round: t.int().min(1),
	governor: t.string(),
	turn: t.string().nullable(),
	selector: t.string().nullable(),
	role: P.nullable(),
	players: t.array(ge).min(2).max(5),
	roles: t.array(t.object({
		id: P,
		coins: I,
		pickedBy: t.string().nullable()
	})),
	plantations: t.array(M.nullable()).max(6),
	deckCount: t.int().nonnegative(),
	quarries: I,
	workerSupply: I,
	recruitment: I,
	nobleSupply: I,
	recruitmentNobles: I,
	vpSupply: t.int().nonnegative(),
	goodsSupply: F,
	market: t.record(N, I),
	ships: t.array(t.object({
		capacity: I,
		good: M.nullable(),
		count: I
	})),
	tradingHouse: t.array(M).max(4),
	endReasons: t.array(t.enum([
		"workers",
		"city",
		"vp"
	])),
	scores: t.record(t.string(), L).nullable(),
	vp: t.record(t.string(), t.int().nonnegative()),
	log: t.array(t.object({
		round: t.int(),
		rid: t.string(),
		event: t.enum([
			"draft",
			"guest",
			"role",
			"plant",
			"build",
			"assign",
			"produce",
			"trade",
			"ship",
			"mixedShip",
			"store",
			"recruit",
			"removePlantation",
			"buyLand",
			"royalSupply",
			"piracy",
			"plunder",
			"raid",
			"kidnap",
			"ransom",
			"festivalPlantation",
			"festivalProduction",
			"festivalBuilding"
		]),
		role: P.optional(),
		good: t.enum([
			...x,
			"quarry",
			"forest"
		]).optional(),
		building: N.optional(),
		n: t.int().optional()
	}))
}), ye = t.object({ choices: t.object({
	draft: t.array(N),
	forest: t.boolean(),
	drawnGood: M.nullable(),
	guestTargets: t.array(fe),
	recruit: t.array(t.boolean()),
	placementPeople: t.array(t.boolean()),
	removePlantations: t.array(I),
	buyLand: t.boolean(),
	royalSupply: I,
	piracy: t.array(I),
	kidnap: t.array(P),
	plunder: t.boolean(),
	raid: t.object({
		max: I,
		minLeaveNobles: I,
		maxLeaveNobles: I
	}).nullable(),
	blackMarket: t.boolean(),
	workerPayments: t.array(fe),
	privateTrades: t.array(M),
	smallWharf: t.boolean(),
	roles: t.array(P),
	plantations: t.array(t.int()),
	quarry: t.boolean(),
	hacienda: t.boolean(),
	hospice: t.boolean(),
	university: t.boolean(),
	buildings: t.array(t.object({
		id: N,
		cost: I
	})),
	trades: t.array(M),
	ships: t.array(t.object({
		good: M,
		ship: t.int(),
		count: I
	})),
	production: F,
	bonus: t.array(M),
	canPass: t.boolean()
}) }), R = (e, t) => e.buildings.some((e) => e.id === t && e.workers > 0), z = (e) => e.unemployed + e.plantations.reduce((e, t) => e + t.workers, 0) + e.buildings.reduce((e, t) => e + t.workers, 0), B = (e) => (e.unemployedNobles ?? 0) + [...e.plantations, ...e.buildings].reduce((e, t) => e + (t.nobles ?? 0), 0), be = (e, t) => e.buildings.some((e) => e.id === t && (e.nobles ?? 0) > 0), V = (e) => e.buildings.reduce((e, t) => e + D[t.id].size, 0), xe = (e) => e.plantations.filter((e) => e.kind !== "forest").length + e.buildings.reduce((e, t) => e + D[t.id].slots, 0), H = (e, t) => e.players.find((e) => e.rid === t), Se = (e) => {
	let t = e.players.findIndex((t) => t.rid === e.selector);
	return [...e.players.slice(t), ...e.players.slice(0, t)].map((e) => e.rid);
}, U = (e = "action") => ({ code: Ce[e] }), Ce = {
	turn: "games.puertorico.errTurn",
	action: "games.puertorico.errAction",
	workers: "games.puertorico.errWorkers",
	storage: "games.puertorico.errStorage",
	forced: "games.puertorico.errForced"
};
function we(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.rngCursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function Te(e) {
	return !e.deck.length && e.discard.length && (e.deck = we(e, e.discard), e.discard = []), e.deck.pop() ?? null;
}
function Ee(e) {
	let t = e.plantations.filter((e) => e !== null);
	e.plantations = [], e.discard.push(...t);
	let n = e.players.length + 1;
	for (let t = 0; t < n; t++) e.plantations.push(Te(e));
}
function De(e, t) {
	e.endReasons.includes(t) || e.endReasons.push(t);
}
function W(e, t, n) {
	e.vp[t] += n, e.vpSupply = Math.max(0, e.vpSupply - n), e.vpSupply === 0 && De(e, "vp");
}
function Oe(e, t, n, r = {}) {
	e.log.push({
		round: e.round,
		rid: t,
		event: n,
		...r
	}), e.log.length > 80 && e.log.shift();
}
function G(t) {
	if (!t.config.festival) return;
	let n = x[e(t.seed, t.rngCursor++, x.length)];
	t.deck.splice(t.deck.indexOf(n), 1);
	let r = x.flatMap((e) => [
		e,
		e,
		e
	]), i = S();
	for (let n = 0; n < 3; n++) {
		let [n] = r.splice(e(t.seed, t.rngCursor++, r.length), 1);
		i[n]++, t.goodsSupply[n]--;
	}
	t.festival = {
		plantation: {
			good: n,
			claimedBy: null
		},
		production: {
			goods: i,
			claimedBy: null
		},
		building: {
			id: null,
			claimedBy: null
		}
	};
}
function ke(t) {
	let n = t.festival;
	if (!n || n.building.id) return;
	let r = oe.filter((e) => t.market[e] > 0 && D[e].vp === 3 && (!D[e].produces || n.production.goods[D[e].produces] === 0)), i = r[e(t.seed, t.rngCursor++, r.length)];
	n.building.id = i, t.market[i] = t.players.length === 2 ? Math.min(t.market[i], D[i].count - 1) : t.market[i] - 1;
}
function Ae(e, t, n, r) {
	let i = e.festival;
	if (i) {
		if (!i.plantation.claimedBy && t.plantations.filter((e) => e.kind === i.plantation.good).length >= 3) {
			i.plantation.claimedBy = t.rid;
			let n = Math.min(3, e.workerSupply);
			e.workerSupply -= n, t.unemployed += n, e.discard.push(i.plantation.good), Oe(e, t.rid, "festivalPlantation", { n });
		}
		if (!i.production.claimedBy && n && x.every((e) => n[e] >= i.production.goods[e])) {
			i.production.claimedBy = t.rid, t.money += 3;
			for (let t of x) e.goodsSupply[t] += i.production.goods[t];
			Oe(e, t.rid, "festivalProduction");
		}
		!i.building.claimedBy && r === i.building.id && (i.building.claimedBy = t.rid, e.market[r]++, W(e, t.rid, 3), Oe(e, t.rid, "festivalBuilding"));
	}
}
function je(e, t) {
	return e.workerSupply > 0 ? (e.workerSupply--, 1) : t && e.recruitment > e.recruitmentNobles ? (e.recruitment--, 1) : 0;
}
function Me(e, t) {
	return t && e.workerSupply === 0 && e.recruitmentNobles > 0 ? (e.recruitment--, e.recruitmentNobles--, {
		workers: 1,
		nobles: 1
	}) : {
		workers: t ? 0 : je(e, !0),
		nobles: 0
	};
}
function Ne(e, t, n) {
	t.unemployed++, n && (t.unemployedNobles = (t.unemployedNobles ?? 0) + 1), !e.villaUsed.includes(t.rid) && R(t, "villa") && (e.villaUsed.push(t.rid), e.nobleSupply > 0 ? (e.nobleSupply--, t.unemployed++, t.unemployedNobles = (t.unemployedNobles ?? 0) + 1) : t.unemployed += je(e, !1));
}
function Pe(e, t, n) {
	let [r] = t.plantations.splice(n, 1);
	t.unemployed += r.workers, t.unemployedNobles = (t.unemployedNobles ?? 0) + (r.nobles ?? 0), r.kind === "quarry" ? e.quarries++ : e.discard.push(r.kind === "forest" ? r.crop : r.kind);
}
function Fe(e, t, n) {
	let r = e.plantations.filter((e) => e.kind === "quarry" && e.workers > 0).length, i = Math.floor(e.plantations.filter((e) => e.kind === "forest").length / 2), a = R(e, "districtOffice") ? be(e, "districtOffice") ? Number(D[t].size === 2) * 2 : Number(D[t].size === 1) : 0;
	return Math.max(0, D[t].cost - Math.min(r, se(t)) - i - a - Number(n) * (1 + Number(R(e, "library"))));
}
function Ie(e, t, n, r) {
	if (Fe(e, t, n) <= e.money) return [{
		worker: null,
		good: null,
		vp: !1
	}];
	if (!R(e, "blackMarket")) return [];
	let i = [null, ...Ve(e, !0)], a = [];
	for (let o of i) for (let i of [null, ...x.filter((t) => e.goods[t] > 0)]) for (let s of r > 0 ? [!1, !0] : [!1]) {
		let r = structuredClone(e);
		o?.kind === "plantation" ? r.plantations[o.index].workers-- : o?.kind === "building" && r.buildings[o.index].workers--, o?.noble && o.kind === "plantation" ? r.plantations[o.index].nobles-- : o?.noble && o.kind === "building" && r.buildings[o.index].nobles--;
		let c = Number(!!o) + Number(!!i) + Number(s);
		c > 0 && Fe(r, t, n) - e.money === c && a.push({
			worker: o,
			good: i,
			vp: s
		});
	}
	return a;
}
function Le(e, t) {
	let n = S();
	for (let r of x) {
		let i = e.plantations.filter((e) => e.kind === r && e.workers > 0).length, a = r === "corn" ? i : e.buildings.filter((e) => D[e.id].produces === r).reduce((e, t) => e + t.workers, 0), o = i > 0 && R(e, "aqueduct") && (r === "indigo" && R(e, "indigoPlant") || r === "sugar" && R(e, "sugarMill")) ? 1 : 0;
		n[r] = Math.min(Math.min(i, a) + o, t[r]);
	}
	return n;
}
function Re(e, t, n) {
	let r = [];
	for (let i of x) {
		if (!t.goods[i]) continue;
		let a = e.ships.findIndex((e) => e.good === i);
		if (a >= 0) {
			let n = e.ships[a], o = Math.min(t.goods[i], n.capacity - n.count);
			o > 0 && r.push({
				good: i,
				ship: a,
				count: o
			});
		} else {
			let n = e.ships.map((e, t) => ({
				...e,
				i: t
			})).filter((e) => e.good === null), a = Math.max(0, ...n.map((e) => Math.min(t.goods[i], e.capacity)));
			for (let e of n) Math.min(t.goods[i], e.capacity) === a && r.push({
				good: i,
				ship: e.i,
				count: a
			});
		}
		!n && R(t, "wharf") && r.push({
			good: i,
			ship: -1,
			count: t.goods[i]
		});
	}
	return r;
}
function ze(e, t) {
	if (x.some((n) => t[n] > e.goods[n])) return !1;
	let n = Number(R(e, "smallWarehouse")) + 2 * Number(R(e, "largeWarehouse"));
	return x.map((e) => t[e]).sort((e, t) => t - e).slice(n).reduce((e, t) => e + t, 0) <= 1 + 3 * Number(R(e, "storehouse"));
}
function Be(e, t) {
	let n = 0;
	if (R(e, "guildHall")) for (let t of e.buildings) O(t.id) && (n += t.id === "smallIndigo" || t.id === "smallSugar" ? 1 : 2);
	R(e, "residence") && (n += Math.max(4, e.plantations.length - 5)), R(e, "fortress") && (n += Math.floor(z(e) / 3)), R(e, "customsHouse") && (n += Math.floor(t / 4)), R(e, "cityHall") && (n += e.buildings.filter((e) => !O(e.id)).length);
	let r = B(e);
	if (R(e, "royalGarden") && (n += r), R(e, "cloister")) {
		let t = [
			...x,
			"quarry",
			"forest"
		].reduce((t, n) => t + Math.floor(e.plantations.filter((e) => e.kind === n).length / 3), 0);
		n += [
			0,
			1,
			3,
			6,
			10
		][t];
	}
	let i = e.buildings.reduce((e, t) => e + D[t.id].vp, 0);
	return {
		tokens: t,
		buildings: i,
		bonus: n,
		nobles: r,
		total: t + i + n + r,
		tie: e.money + C(e.goods)
	};
}
function Ve(e, t) {
	return [
		...e.plantations.map((e, t) => ({
			...e,
			kind: "plantation",
			index: t
		})),
		...e.buildings.filter((e) => !t || e.id !== "blackMarket").map((t) => ({
			...t,
			kind: "building",
			index: e.buildings.indexOf(t)
		})),
		{
			kind: "harbor",
			index: 0,
			workers: e.unemployed,
			nobles: e.unemployedNobles
		}
	].flatMap((e) => [...e.workers > (e.nobles ?? 0) ? [{
		kind: e.kind,
		index: e.index
	}] : [], ...(e.nobles ?? 0) > 0 ? [{
		kind: e.kind,
		index: e.index,
		noble: !0
	}] : []]);
}
function He(e) {
	if (!R(e, "guesthouse")) return [];
	let t = [...e.plantations.flatMap((e, t) => e.kind !== "forest" && e.workers === 0 ? [{
		kind: "plantation",
		index: t
	}] : []), ...e.buildings.flatMap((e, t) => e.id !== "guesthouse" && e.workers < D[e.id].slots ? [{
		kind: "building",
		index: t
	}] : [])], n = e.buildings.find((e) => e.id === "guesthouse");
	return t.flatMap((e) => [...n.workers > (n.nobles ?? 0) ? [e] : [], ...(n.nobles ?? 0) > 0 ? [{
		...e,
		noble: !0
	}] : []]);
}
function Ue(e, t) {
	t === "beginRole" ? rt(e) : t === "finishRole" ? Ge(e) : t === "captain" ? tt(e) : t === "endFollowers" && qe(e);
}
function K(e, t = "decision") {
	let n = e.phase === "mayor" ? [] : e.players.filter((e) => He(e).length > 0).map((e) => e.rid);
	if (!n.length) {
		Ue(e, t);
		return;
	}
	e.guestResume = {
		phase: e.phase,
		turn: e.turn,
		after: t
	}, e.guestContext = e.phase, e.guestQueue = n, e.phase = "guesthouse", e.turn = n[0];
}
function We(e) {
	if (e.guestQueue.shift(), e.guestQueue.length) {
		e.turn = e.guestQueue[0];
		return;
	}
	let t = e.guestResume;
	e.phase = t.phase, e.turn = t.turn, e.guestResume = null, e.guestContext = null, Ue(e, t.after);
}
function q(e) {
	K(e, "finishRole");
}
function Ge(e) {
	let t = e.players.length, n = t === 2 ? 6 : t;
	if (e.selectedCount >= n) {
		if (e.kidnapped) {
			let t = e.kidnapped;
			e.kidnapped = null, e.turn = t.rid, Oe(e, t.rid, "role", { role: t.role }), nt(e, t.role, !0);
			return;
		}
		if (e.endReasons.length) {
			e.phase = "done", e.turn = null, e.scores = Object.fromEntries(e.players.map((t) => [t.rid, Be(t, e.vp[t.rid])]));
			return;
		}
		for (let t of e.roles) !t.pickedBy && t.id !== "buccaneer" && t.coins++, t.pickedBy = null;
		e.governor = e.players[(e.players.findIndex((t) => t.rid === e.governor) + 1) % t].rid, e.selectedCount = 0, e.round++;
	}
	e.phase = "role", e.turn = e.players[(e.players.findIndex((t) => t.rid === e.governor) + e.selectedCount) % t].rid, e.selector = null, e.role = null;
}
function Ke(e) {
	K(e, "endFollowers");
}
function qe(e) {
	if (e.phase === "settler") {
		let t = H(e, e.selector);
		if (R(t, "library") && !e.librarySettlerUsed && t.plantations.length < 12) {
			e.librarySettlerUsed = !0, e.phase = "settlerExtra", e.turn = t.rid, K(e);
			return;
		}
		Je(e);
		return;
	}
	if (e.phase === "trader" && e.tradingHouse.length === 4) {
		for (let t of e.tradingHouse) e.goodsSupply[t]++;
		e.tradingHouse = [];
	}
	if (e.phase === "mayor") {
		let t = e.players.reduce((e, t) => e + t.buildings.reduce((e, t) => e + D[t.id].slots - t.workers, 0), 0), n = Math.max(e.players.length, t);
		e.recruitment = Math.min(n, e.workerSupply), e.workerSupply -= e.recruitment, e.config.nobles && e.nobleSupply > 0 && (e.recruitment > 0 && (e.recruitment--, e.workerSupply++), e.nobleSupply--, e.recruitment++, e.recruitmentNobles = 1), !e.config.nobles && e.recruitment < n && De(e, "workers");
	}
	if (e.phase === "craftsman") {
		let t = e.produced[e.selector];
		if (x.some((n) => t[n] > 0 && e.goodsSupply[n] > 0)) {
			e.phase = "bonus", e.turn = e.selector, K(e);
			return;
		}
	}
	q(e);
}
function J(e) {
	e.follower++, e.haciendaUsed = !1, e.hospiceUsed = !1, e.follower >= e.players.length ? Ke(e) : (e.turn = Se(e)[e.follower], e.landAfterTrade = !1, K(e));
}
function Je(e) {
	let t = Se(e).find((t) => !e.huntingDone.includes(t) && R(H(e, t), "huntingLodge") && !be(H(e, t), "huntingLodge") && H(e, t).plantations.some((e) => e.kind !== "quarry"));
	if (t) {
		e.phase = "hunting", e.turn = t, K(e);
		return;
	}
	for (let t of e.players) be(t, "huntingLodge") && e.players.every((e) => e === t || t.plantations.length < e.plantations.length) && W(e, t.rid, 2);
	Ee(e), q(e);
}
function Ye(e) {
	let t = H(e, e.turn);
	!e.landUsed.includes(t.rid) && R(t, "landOffice") ? (e.phase = "landOffice", e.landAfterTrade = !0, K(e)) : J(e);
}
function Xe(e) {
	e.phase = "trader", e.landAfterTrade ? J(e) : K(e);
}
function Ze(e) {
	e.phase = "storage", e.follower = 0, e.turn = Se(e)[0], K(e);
}
function Qe(e, t) {
	return e.captainStarted.includes(t.rid) || (e.captainStarted.push(t.rid), R(t, "unionHall") && W(e, t.rid, x.reduce((e, n) => e + Math.floor(t.goods[n] / 2), 0))), t.rid === e.selector && !e.lighthouseBonusUsed && R(t, "lighthouse") && (t.money++, e.lighthouseBonusUsed = !0), !e.royalDone.includes(t.rid) && (e.royalDone.push(t.rid), R(t, "royalSupplier") && B(t) > 0 && C(t.goods) > 0) ? (e.phase = "royalSupplier", e.turn = t.rid, !0) : !1;
}
function $e(e, t) {
	return Re(e, t, e.wharfUsed.includes(t.rid)).length > 0 || R(t, "smallWharf") && !e.smallWharfUsed.includes(t.rid) && C(t.goods) > 0;
}
function et(e) {
	K(e, "captain");
}
function tt(e) {
	let t = e.players.findIndex((t) => t.rid === e.turn);
	for (let n = 1; n <= e.players.length; n++) {
		let r = e.players[(t + n) % e.players.length];
		if (Qe(e, r)) return;
		if ($e(e, r)) {
			e.turn = r.rid;
			return;
		}
	}
	Ze(e);
}
function nt(e, t, n = !1) {
	let r = e.roles.find((e) => e.id === t), i = H(e, e.turn);
	e.kidnapped?.role === t && (e.kidnapped.rid !== i.rid && (H(e, e.kidnapped.rid).money += 3, Oe(e, e.kidnapped.rid, "ransom", { role: t })), e.kidnapped = null), i.money += r.coins, r.coins = 0, r.pickedBy = i.rid, e.selector = i.rid, e.role = t, n || e.selectedCount++, e.follower = 0, e.haciendaUsed = !1, e.hospiceUsed = !1, e.librarySettlerUsed = !1, e.bonusTaken = 0, e.landUsed = [], e.huntingDone = [], e.landAfterTrade = !1, K(e, "beginRole");
}
function rt(e) {
	let t = e.role, n = H(e, e.selector);
	if (t === "buccaneer") {
		e.phase = "buccaneer", e.buccaneerOwner = n.rid;
		return;
	}
	if (t === "prospector" || t === "prospector2") {
		n.money += 1 + Number(R(n, "library")), q(e);
		return;
	}
	if (e.phase = t, t === "mayor") {
		e.villaUsed = [];
		for (let t = 0; t < 1 + Number(R(n, "library")); t++) je(e, !1) && Ne(e, n, !1);
		let t = Se(e);
		if (e.config.nobles && e.recruitment > 0) e.phase = "recruit";
		else {
			let n = 0;
			for (; e.recruitment > 0;) Ne(e, H(e, t[n++ % t.length]), !1), e.recruitment--;
		}
	}
	if (t === "craftsman") {
		e.produced = Object.fromEntries(e.players.map((e) => [e.rid, S()]));
		for (let t of e.players) R(t, "chapel") && (be(t, "chapel") ? W(e, t.rid, 1) : t.money++);
	}
	if (t === "captain") {
		if (e.wharfUsed = [], e.smallWharfUsed = [], e.captainStarted = [], e.lighthouseBonusUsed = !1, e.captainBonusUsed = !1, e.royalDone = [], Qe(e, n)) return;
		$e(e, n) || et(e);
	}
}
function it(e, t, n) {
	let r = de.parse(e), i = t.length, a = { ...k };
	if (i === 2) for (let e of x) a[e] -= 2;
	let o = {
		config: r,
		draftSlots: r.newBuildings ? [...ce, ...r.nobles ? le : []] : [],
		guestContext: null,
		buccaneerOwner: null,
		kidnapped: null,
		festival: null,
		seed: n,
		rngCursor: 0,
		phase: "role",
		round: 1,
		governor: t[0],
		turn: t[0],
		selector: null,
		role: null,
		players: t.map((e, t) => ({
			rid: e,
			money: i === 2 ? 3 : i - 1,
			goods: S(),
			buildings: [],
			unemployed: 0,
			plantations: [{
				kind: t < (i === 5 ? 3 : i === 2 ? 1 : 2) ? "indigo" : "corn",
				workers: 0
			}]
		})),
		roles: [...w.slice(0, i === 3 ? 6 : i === 5 ? 8 : 7), ...r.buccaneer ? ["buccaneer"] : []].map((e) => ({
			id: e,
			coins: 0,
			pickedBy: null
		})),
		plantations: [],
		deck: [],
		discard: [],
		quarries: i === 2 ? 5 : 8,
		workerSupply: r.nobles && i > 2 ? 101 - i : {
			2: 40,
			3: 55,
			4: 75,
			5: 95
		}[i],
		recruitment: i,
		nobleSupply: r.nobles ? i === 2 ? 20 : 19 : 0,
		recruitmentNobles: r.nobles && i > 2 ? 1 : 0,
		vpSupply: {
			2: 65,
			3: 76,
			4: 101,
			5: 126
		}[i],
		vp: Object.fromEntries(t.map((e) => [e, 0])),
		goodsSupply: a,
		market: Object.fromEntries(oe.map((e) => [e, (!E.includes(e) || r.nobles) && (O(e) || !r.newBuildings && (ae.includes(e) || E.includes(e))) ? i === 2 ? O(e) ? 2 : 1 : D[e].count : 0])),
		ships: (i === 2 ? [4, 6] : [
			i + 1,
			i + 2,
			i + 3
		]).map((e) => ({
			capacity: e,
			good: null,
			count: 0
		})),
		tradingHouse: [],
		endReasons: [],
		scores: null,
		selectedCount: 0,
		follower: 0,
		haciendaUsed: !1,
		hospiceUsed: !1,
		wharfUsed: [],
		captainBonusUsed: !1,
		produced: {},
		log: [],
		smallWharfUsed: [],
		captainStarted: [],
		lighthouseBonusUsed: !1,
		bonusTaken: 0,
		librarySettlerUsed: !1,
		drawnTile: null,
		guestQueue: [],
		guestResume: null,
		villaUsed: [],
		landUsed: [],
		huntingDone: [],
		forestResume: "settler",
		royalDone: [],
		landAfterTrade: !1
	};
	for (let e of x) {
		let t = o.players.filter((t) => t.plantations[0].kind === e).length;
		o.deck.push(...Array(ue[e] - t - (i === 2 ? 3 : 0)).fill(e));
	}
	return G(o), we(o, o.deck), Ee(o), r.newBuildings ? o.phase = "draft" : ke(o), { state: o };
}
function at(e, t) {
	let n = {
		draft: [],
		forest: !1,
		drawnGood: null,
		guestTargets: [],
		blackMarket: !1,
		workerPayments: [],
		privateTrades: [],
		smallWharf: !1,
		roles: [],
		plantations: [],
		quarry: !1,
		hacienda: !1,
		hospice: !1,
		university: !1,
		buildings: [],
		trades: [],
		ships: [],
		production: S(),
		bonus: [],
		canPass: !1,
		recruit: [],
		placementPeople: [],
		removePlantations: [],
		buyLand: !1,
		royalSupply: 0,
		piracy: [],
		kidnap: [],
		plunder: !1,
		raid: null
	}, r = e.players.find((e) => e.rid === t);
	return !r || e.turn !== t || e.phase === "done" ? n : (e.phase === "draft" && (n.draft = oe.filter((t) => !O(t) && (e.config.nobles || !E.includes(t)) && e.market[t] === 0 && e.draftSlots.includes(D[t].cost))), e.phase === "guesthouse" && (n.guestTargets = He(r)), e.phase === "forest" && (n.drawnGood = e.drawnTile, n.forest = R(r, "forestHouse")), e.phase === "role" && (n.roles = e.roles.filter((n) => !n.pickedBy && (n.id !== "buccaneer" || e.buccaneerOwner !== t)).map((e) => e.id)), e.phase === "buccaneer" && (n.piracy = e.ships.flatMap((e, t) => e.count > 0 ? [t] : []), n.plunder = !0, n.kidnap = e.roles.filter((e) => !e.pickedBy && e.id !== "buccaneer").map((e) => e.id), e.recruitment > e.players.length && (n.raid = {
		max: Math.min(3, e.recruitment - e.players.length, xe(r) - z(r) + r.unemployed),
		minLeaveNobles: Math.max(0, e.players.length - (e.recruitment - e.recruitmentNobles)),
		maxLeaveNobles: Math.min(e.recruitmentNobles, e.players.length)
	})), e.phase === "recruit" && (n.recruit = [...e.recruitment > e.recruitmentNobles ? [!1] : [], ...e.recruitmentNobles > 0 ? [!0] : []]), (e.phase === "trader" || e.phase === "landOffice") && !e.landUsed.includes(t) && R(r, "landOffice") && (n.buyLand = !be(r, "landOffice") && r.money > 0 && r.plantations.length < 12 && e.deck.length + e.discard.length > 0, be(r, "landOffice") && (n.removePlantations = r.plantations.flatMap((e, t) => e.kind === "quarry" ? [] : [t]))), e.phase === "hunting" && (n.removePlantations = r.plantations.flatMap((e, t) => e.kind === "quarry" ? [] : [t])), e.phase === "royalSupplier" && (n.royalSupply = B(r)), (e.phase === "settler" || e.phase === "settlerExtra") && (r.plantations.length < 12 && (n.plantations = e.plantations.flatMap((e, t) => e === null ? [] : [t]), n.quarry = e.quarries > 0 && (e.phase === "settler" && e.selector === t || R(r, "constructionHut")), n.hacienda = e.phase === "settler" && R(r, "hacienda") && !e.haciendaUsed && e.deck.length + e.discard.length > 0, n.forest = R(r, "forestHouse")), n.hospice = e.phase === "settler" && R(r, "hospice") && !e.hospiceUsed && e.workerSupply + e.recruitment > 0), e.phase === "builder" && (n.blackMarket = R(r, "blackMarket"), n.blackMarket && (n.workerPayments = Ve(r, !0)), n.buildings = oe.flatMap((n) => {
		let i = Fe(r, n, e.selector === t);
		return e.market[n] > 0 && !r.buildings.some((e) => e.id === n) && V(r) + D[n].size <= 12 && Ie(r, n, e.selector === t, e.vp[t]).length > 0 ? [{
			id: n,
			cost: i
		}] : [];
	}), n.university = R(r, "university") && e.workerSupply + e.recruitment > 0), e.phase === "craftsman" && (n.production = Le(r, e.goodsSupply)), e.phase === "bonus" && (n.bonus = x.filter((n) => e.produced[t][n] > 0 && e.goodsSupply[n] > 0)), e.phase === "trader" && e.tradingHouse.length < 4 && (n.trades = x.filter((t) => r.goods[t] > 0 && (!e.tradingHouse.includes(t) || R(r, "office")))), e.phase === "trader" && R(r, "tradingPost") && (n.privateTrades = x.filter((e) => r.goods[e] > 0)), e.phase === "captain" && (n.ships = Re(e, r, e.wharfUsed.includes(t)), n.smallWharf = R(r, "smallWharf") && !e.smallWharfUsed.includes(t) && C(r.goods) > 0), (n.hospice || n.university) && (n.placementPeople = [...e.workerSupply > 0 || e.recruitment > e.recruitmentNobles ? [!1] : [], ...e.workerSupply === 0 && e.recruitmentNobles > 0 ? [!0] : []]), n.canPass = [
		"settler",
		"settlerExtra",
		"guesthouse",
		"builder",
		"trader",
		"bonus",
		"landOffice",
		"hunting",
		"royalSupplier"
	].includes(e.phase) || e.phase === "captain" && !n.ships.some((e) => e.ship >= 0), n);
}
function ot(e, t, n) {
	if (e.phase === "done" || e.turn !== n.by) return U("turn");
	if (!pe.safeParse(t).success) return U();
	let r = structuredClone(e), i = H(r, n.by), a = at(r, n.by), o = (e) => {
		r.log.push({
			round: r.round,
			rid: n.by,
			...e
		}), r.log.length > 80 && r.log.shift();
	};
	if (t.type === "draft") {
		if (!a.draft.includes(t.building)) return U();
		r.draftSlots.splice(r.draftSlots.indexOf(D[t.building].cost), 1), r.market[t.building] = r.players.length === 2 ? 1 : D[t.building].count, o({
			event: "draft",
			building: t.building
		}), r.draftSlots.length ? r.turn = r.players[(r.players.findIndex((e) => e.rid === n.by) + 1) % r.players.length].rid : (ke(r), r.phase = "role", r.turn = r.governor);
	} else if (t.type === "guest") {
		if (r.phase !== "guesthouse" || !a.guestTargets.some((e) => e.kind === t.target.kind && e.index === t.target.index && !!e.noble == !!t.target.noble)) return U();
		let e = i.buildings.find((e) => e.id === "guesthouse");
		e.workers--, t.target.noble && e.nobles--;
		let n = t.target.kind === "plantation" ? i.plantations[t.target.index] : i.buildings[t.target.index];
		n.workers++, t.target.noble && (n.nobles = (n.nobles ?? 0) + 1), o({ event: "guest" }), He(i).length || We(r);
	} else if (t.type === "recruit") {
		if (!a.recruit.includes(t.noble)) return U();
		r.recruitment--, t.noble && r.recruitmentNobles--, Ne(r, i, t.noble), o({
			event: "recruit",
			n: Number(t.noble)
		}), r.recruitment === 0 ? (r.phase = "mayor", r.turn = r.selector, r.follower = 0) : (r.turn = r.players[(r.players.findIndex((e) => e.rid === r.turn) + 1) % r.players.length].rid, K(r));
	} else if (t.type === "buyLand") {
		if (!a.buyLand) return U();
		let e = Te(r);
		if (!e) return U();
		i.money--, r.landUsed.push(i.rid), o({ event: "buyLand" }), R(i, "forestHouse") ? (r.drawnTile = e, r.forestResume = "trader", r.phase = "forest", K(r)) : (i.plantations.push({
			kind: e,
			workers: 0
		}), Ae(r, i), Xe(r));
	} else if (t.type === "removePlantation") {
		if (!a.removePlantations.includes(t.index)) return U();
		o({
			event: "removePlantation",
			good: i.plantations[t.index].kind
		}), Pe(r, i, t.index), r.phase === "hunting" ? (r.huntingDone.push(i.rid), Je(r)) : (i.money++, r.landUsed.push(i.rid), Xe(r));
	} else if (t.type === "royalSupply") {
		let e = C(t.goods);
		if (r.phase !== "royalSupplier" || e > a.royalSupply || x.some((e) => t.goods[e] > 1 || t.goods[e] > i.goods[e])) return U();
		for (let e of x) i.goods[e] -= t.goods[e], r.goodsSupply[e] += t.goods[e];
		W(r, i.rid, e), o({
			event: "royalSupply",
			n: e
		}), r.phase = "captain", $e(r, i) ? K(r) : et(r);
	} else if (t.type === "piracy") {
		if (!a.piracy.includes(t.ship)) return U();
		let e = r.ships[t.ship];
		if (t.keep > e.count) return U();
		i.goods[e.good] += t.keep, r.goodsSupply[e.good] += e.count - t.keep, o({
			event: "piracy",
			good: e.good,
			n: t.keep
		}), e.good = null, e.count = 0, q(r);
	} else if (t.type === "plunder") {
		if (!a.plunder) return U();
		let e = r.tradingHouse.length;
		for (let e of r.tradingHouse) r.goodsSupply[e]++;
		r.tradingHouse = [], W(r, i.rid, e), o({
			event: "plunder",
			n: e
		}), q(r);
	} else if (t.type === "kidnap") {
		if (!a.kidnap.includes(t.role)) return U();
		let e = r.roles.find((e) => e.id === t.role);
		i.money += e.coins, e.coins = 0, r.kidnapped = {
			rid: i.rid,
			role: e.id
		}, o({
			event: "kidnap",
			role: e.id
		}), q(r);
	} else if (t.type === "raid") {
		if (!a.raid || t.placements.length > a.raid.max || t.leaveNobles < a.raid.minLeaveNobles || t.leaveNobles > a.raid.maxLeaveNobles) return U();
		let e = r.recruitment - r.players.length, n = r.recruitmentNobles - t.leaveNobles, s = t.placements.filter((e) => e.noble).length;
		if (s > n || t.placements.length - s > e - n) return U();
		for (let e of t.placements) {
			if (e.kind === "harbor") return U();
			let t = e.kind === "plantation" ? i.plantations[e.index] : i.buildings[e.index];
			if (!t) return U();
			let n = e.kind === "plantation" ? i.plantations[e.index].kind === "forest" ? 0 : 1 : D[i.buildings[e.index].id].slots;
			if (t.workers >= n) return U();
			t.workers++, e.noble && (t.nobles = (t.nobles ?? 0) + 1);
		}
		r.recruitment = r.players.length, r.recruitmentNobles = t.leaveNobles, r.nobleSupply += n - s, r.workerSupply += e - n - (t.placements.length - s), o({
			event: "raid",
			n: t.placements.length
		}), q(r);
	} else if (t.type === "role") {
		if (!a.roles.includes(t.role)) return U();
		o({
			event: "role",
			role: t.role
		}), nt(r, t.role);
	} else if (t.type === "plant" || t.type === "hacienda") {
		if (r.phase !== "settler" && r.phase !== "settlerExtra") return U();
		let e;
		if (t.type === "hacienda") {
			if (!a.hacienda) return U();
			let t = Te(r);
			if (!t) return U();
			if (e = t, r.haciendaUsed = !0, a.forest) return r.drawnTile = t, r.forestResume = "settler", r.phase = "forest", K(r), { state: r };
		} else if (t.index === -1) {
			if (!a.quarry) return U();
			e = "quarry", r.quarries--;
		} else {
			if (!a.plantations.includes(t.index)) return U();
			e = r.plantations[t.index], r.plantations[t.index] = null;
		}
		if (t.type === "plant" && t.forest && (!a.forest || e === "quarry")) return U();
		let n = t.type === "plant" && t.hospice && a.hospice ? Me(r, !!t.noble) : {
			workers: 0,
			nobles: 0
		};
		if (t.type === "plant" && t.hospice && a.hospice && t.noble && !n.workers) return U();
		let s = n.workers;
		s && (r.hospiceUsed = !0);
		let c = t.type === "plant" && t.forest;
		i.plantations.push(c ? {
			kind: "forest",
			crop: e,
			workers: 0
		} : {
			kind: e,
			...n
		}), c && (i.unemployed += s, i.unemployedNobles = (i.unemployedNobles ?? 0) + n.nobles), o({
			event: "plant",
			good: c ? "forest" : e
		}), Ae(r, i), r.phase === "settlerExtra" ? Je(r) : t.type === "plant" || i.plantations.length === 12 ? J(r) : K(r);
	} else if (t.type === "placeDrawn") {
		if (r.phase !== "forest" || !r.drawnTile || t.forest && !a.forest) return U();
		i.plantations.push(t.forest ? {
			kind: "forest",
			crop: r.drawnTile,
			workers: 0
		} : {
			kind: r.drawnTile,
			workers: 0
		}), r.drawnTile = null, r.phase = r.forestResume, o({
			event: "plant",
			good: i.plantations.at(-1).kind
		}), Ae(r, i), r.forestResume === "trader" ? Xe(r) : i.plantations.length === 12 ? J(r) : K(r);
	} else if (t.type === "build") {
		if (r.phase !== "builder") return U();
		let e = a.buildings.find((e) => e.id === t.building);
		if (!e) return U();
		let n = t.payment, s = Number(!!n?.worker) + Number(!!n?.good) + Number(!!n?.vp);
		if (s > 0) {
			if (!a.blackMarket || e.cost <= i.money) return U();
			if (n.worker) {
				let e = n.worker;
				if (!a.workerPayments.some((t) => t.kind === e.kind && t.index === e.index && !!t.noble == !!e.noble)) return U();
				e.kind === "plantation" ? i.plantations[e.index].workers-- : e.kind === "building" ? i.buildings[e.index].workers-- : i.unemployed--, e.noble ? (e.kind === "plantation" ? i.plantations[e.index].nobles-- : e.kind === "building" ? i.buildings[e.index].nobles-- : i.unemployedNobles--, r.nobleSupply++) : r.workerSupply++;
			}
			if (n.good) {
				if (i.goods[n.good] < 1) return U();
				i.goods[n.good]--, r.goodsSupply[n.good]++;
			}
			if (n.vp) {
				if (r.vp[i.rid] < 1) return U();
				r.vp[i.rid]--, r.vpSupply++;
			}
		}
		let c = Fe(i, t.building, r.selector === i.rid);
		if (s > 0 && c - i.money !== s || c - s > i.money) return U();
		i.money -= c - s, r.market[t.building]--;
		let l = R(i, "church"), u = t.university && R(i, "university") && D[t.building].slots > 0 ? Me(r, !!t.noble) : {
			workers: 0,
			nobles: 0
		};
		if (t.university && t.noble && !u.workers) return U();
		i.buildings.push({
			id: t.building,
			...u
		}), l && W(r, i.rid, [
			0,
			0,
			1,
			1,
			2
		][se(t.building)]), V(i) === 12 && De(r, "city"), o({
			event: "build",
			building: t.building,
			n: c - s
		}), Ae(r, i, void 0, t.building), J(r);
	} else if (t.type === "assign") {
		if (r.phase !== "mayor" || t.plantations.length !== i.plantations.length || t.buildings.length !== i.buildings.length || t.plantations.some((e, t) => e > (i.plantations[t].kind === "forest" ? 0 : 1)) || t.buildings.some((e, t) => e > D[i.buildings[t].id].slots)) return U("workers");
		let e = [...t.plantations, ...t.buildings].reduce((e, t) => e + t, 0), n = z(i);
		if (e !== Math.min(n, xe(i))) return U("workers");
		let a = t.noblePlantations ?? i.plantations.map(() => 0), s = t.nobleBuildings ?? i.buildings.map(() => 0);
		if (a.length !== i.plantations.length || s.length !== i.buildings.length || a.some((e, n) => e > t.plantations[n]) || s.some((e, n) => e > t.buildings[n])) return U("workers");
		let c = B(i), l = [...a, ...s].reduce((e, t) => e + t, 0);
		if (l > c || e - l > n - c) return U("workers");
		i.plantations.forEach((e, n) => {
			e.workers = t.plantations[n], e.nobles = a[n];
		}), i.buildings.forEach((e, n) => {
			e.workers = t.buildings[n], e.nobles = s[n];
		}), i.unemployed = n - e, i.unemployedNobles = c - l, o({
			event: "assign",
			n: e
		}), J(r);
	} else if (t.type === "produce") {
		if (r.phase !== "craftsman" || x.some((e) => t.goods[e] > a.production[e])) return U();
		for (let e of x) i.goods[e] += t.goods[e], r.goodsSupply[e] -= t.goods[e];
		r.produced[i.rid] = { ...t.goods }, R(i, "factory") && (i.money += [
			0,
			0,
			1,
			2,
			3,
			5
		][x.filter((e) => t.goods[e] > 0).length]), R(i, "specialtyFactory") && (i.money += Math.max(0, ...x.filter((e) => e !== "corn").map((e) => t.goods[e] - 1))), R(i, "jeweler") && (i.money += B(i)), o({
			event: "produce",
			n: C(t.goods)
		}), Ae(r, i, r.produced[i.rid]), J(r);
	} else if (t.type === "bonus") {
		if (!a.bonus.includes(t.good)) return U();
		i.goods[t.good]++, r.goodsSupply[t.good]--, r.bonusTaken++, r.produced[i.rid][t.good]++, o({
			event: "produce",
			good: t.good,
			n: 1
		}), Ae(r, i, r.produced[i.rid]), r.bonusTaken < 1 + Number(R(i, "library")) && x.some((e) => r.produced[i.rid][e] > 0 && r.goodsSupply[e] > 0) ? K(r) : q(r);
	} else if (t.type === "trade") {
		if (!(t.privateSale ? a.privateTrades : a.trades).includes(t.good)) return U();
		let e = x.indexOf(t.good) + Number(r.selector === i.rid) * (1 + Number(R(i, "library"))) + (t.privateSale ? 0 : Number(R(i, "smallMarket")) + 2 * Number(R(i, "largeMarket")));
		i.goods[t.good]--, t.privateSale ? r.goodsSupply[t.good]++ : r.tradingHouse.push(t.good), i.money += e, o({
			event: "trade",
			good: t.good,
			n: e
		}), Ye(r);
	} else if (t.type === "ship") {
		let e = a.ships.find((e) => e.good === t.good && e.ship === t.ship);
		if (!e) return U();
		i.goods[t.good] -= e.count, t.ship === -1 ? (r.wharfUsed.push(i.rid), r.goodsSupply[t.good] += e.count) : (r.ships[t.ship].good = t.good, r.ships[t.ship].count += e.count);
		let n = r.selector === i.rid && !r.captainBonusUsed;
		n && (r.captainBonusUsed = !0), W(r, i.rid, e.count + Number(n) * (1 + Number(R(i, "library"))) + Number(R(i, "harbor"))), R(i, "lighthouse") && i.money++, o({
			event: "ship",
			good: t.good,
			n: e.count
		}), et(r);
	} else if (t.type === "smallWharf") {
		let e = C(t.goods);
		if (!a.smallWharf || !e || x.some((e) => t.goods[e] > i.goods[e])) return U();
		for (let e of x) i.goods[e] -= t.goods[e], r.goodsSupply[e] += t.goods[e];
		r.smallWharfUsed.push(i.rid);
		let n = r.selector === i.rid && !r.captainBonusUsed;
		n && (r.captainBonusUsed = !0), W(r, i.rid, Math.floor(e / 2) + Number(n) * (1 + Number(R(i, "library"))) + Number(R(i, "harbor"))), R(i, "lighthouse") && i.money++, o({
			event: "mixedShip",
			n: e
		}), et(r);
	} else if (t.type === "store") {
		if (r.phase !== "storage") return U();
		if (!ze(i, t.goods)) return U("storage");
		for (let e of x) r.goodsSupply[e] += i.goods[e] - t.goods[e], i.goods[e] = t.goods[e];
		if (o({
			event: "store",
			n: C(t.goods)
		}), r.follower++, r.follower === r.players.length) {
			for (let e of r.ships) e.count === e.capacity && e.good && (r.goodsSupply[e.good] += e.count, e.count = 0, e.good = null);
			q(r);
		} else r.turn = Se(r)[r.follower], K(r);
	} else if (t.type === "pass") {
		if (!a.canPass) return r.phase === "captain" ? U("forced") : U();
		r.phase === "guesthouse" ? We(r) : r.phase === "settlerExtra" ? Je(r) : r.phase === "hunting" ? (r.huntingDone.push(i.rid), Je(r)) : r.phase === "landOffice" ? (r.phase = "trader", J(r)) : r.phase === "trader" ? Ye(r) : r.phase === "royalSupplier" ? (r.phase = "captain", $e(r, i) ? K(r) : et(r)) : r.phase === "captain" ? (r.wharfUsed.push(i.rid), r.smallWharfUsed.push(i.rid), et(r)) : r.phase === "bonus" ? q(r) : J(r);
	}
	return { state: r };
}
function st(e, t) {
	return {
		public: {
			config: e.config,
			draftSlots: e.draftSlots,
			guestContext: e.guestContext,
			buccaneerOwner: e.buccaneerOwner,
			kidnapped: e.kidnapped,
			festival: e.festival,
			phase: e.phase,
			round: e.round,
			governor: e.governor,
			turn: e.turn,
			selector: e.selector,
			role: e.role,
			players: e.players.map((e) => ({
				...e,
				plantations: e.plantations.map((e) => e.kind === "forest" ? {
					kind: e.kind,
					workers: e.workers
				} : e)
			})),
			roles: e.roles,
			plantations: e.plantations,
			deckCount: e.deck.length,
			quarries: e.quarries,
			workerSupply: e.workerSupply,
			recruitment: e.recruitment,
			nobleSupply: e.nobleSupply,
			recruitmentNobles: e.recruitmentNobles,
			vpSupply: e.vpSupply,
			goodsSupply: e.goodsSupply,
			market: e.market,
			ships: e.ships,
			tradingHouse: e.tradingHouse,
			endReasons: e.endReasons,
			scores: e.scores,
			vp: e.vp,
			log: e.log
		},
		private: { choices: at(e, t) }
	};
}
function ct(e) {
	if (e.phase !== "done" || !e.scores) return { phase: e.phase };
	let t = e.scores, n = e.players.map((e) => e.rid).sort((e, n) => t[n].total - t[e].total || t[n].tie - t[e].tie), r = t[n[0]];
	return {
		phase: "done",
		ranking: n,
		winner: n.filter((e) => t[e].total === r.total && t[e].tie === r.tie),
		scores: Object.fromEntries(n.map((e) => [e, t[e].total]))
	};
}
var lt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: j,
	schemas: {
		action: pe,
		publicView: ve,
		privateView: ye,
		config: de
	},
	setup: it,
	reduce: ot,
	viewFor: st,
	status: ct
};
//#endregion
//#region src/games/puertorico/scenery.tsx
function Y({ x: e, y: t, scale: n = 1 }) {
	return /* @__PURE__ */ v("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ _("path", {
				d: "M-5 41Q4 17-1 1L5 0Q11 21 2 43Z",
				fill: "#957045",
				stroke: "#675c39",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ _("path", {
				d: "M0 8l5 1M0 16l6 1M-1 25l6 1M-4 34l6 1",
				stroke: "#c0a06a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ _("path", {
				d: "M1 3Q-24-19-35-2-15-5 1 3Q-9-28-26-20-9-17 1 3Q5-27 21-23 10-11 1 3Q31-14 37 4 15-2 1 3Q26 5 24 23 10 9 1 3Q-17 10-22 24-24 3 1 3Z",
				fill: "#4c8050",
				stroke: "#365a3c",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ _("path", {
				d: "M-29-2Q-14-3 1 3L17-20M1 3 31 3M1 3 21 20M1 3-23-19",
				fill: "none",
				stroke: "#96ac59",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ _("ellipse", {
				cx: "1",
				cy: "4",
				rx: "4",
				ry: "3",
				fill: "#7a5435"
			}),
			/* @__PURE__ */ _("ellipse", {
				cx: "6",
				cy: "5",
				rx: "3",
				ry: "4",
				fill: "#a07840"
			})
		]
	});
}
function X({ x: e, y: t, scale: n = 1 }) {
	return /* @__PURE__ */ v("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [/* @__PURE__ */ _("path", {
			d: "M-19 7Q-24-2-13-4-16-16-4-14 3-24 11-12 23-10 19 0 28 8 10 13Z",
			fill: "#5d8949",
			stroke: "#3e6e43",
			strokeWidth: "1.2"
		}), /* @__PURE__ */ _("path", {
			d: "M-13-3Q-11-12-4-8 3-17 9-8 17-7 15-2M-15 5q10-7 18-3",
			fill: "none",
			stroke: "#a0b85c",
			strokeWidth: "2"
		})]
	});
}
function ut({ x: e, y: t, scale: n = 1 }) {
	return /* @__PURE__ */ v("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ _("path", {
				d: "M-11 4-8-5 3-10 13-2 16 7 3 12Z",
				fill: "#819486",
				stroke: "#566f65"
			}),
			/* @__PURE__ */ _("path", {
				d: "M-8-5 3-10 6 1-11 4Z",
				fill: "#bac3a1"
			}),
			/* @__PURE__ */ _("path", {
				d: "M6 1 13-2 16 7 3 12Z",
				fill: "#607e77"
			}),
			/* @__PURE__ */ _("path", {
				d: "M-12 9Q-2 17 16 10",
				fill: "none",
				stroke: "#eef0cc",
				strokeWidth: "2"
			})
		]
	});
}
function dt() {
	let e = i().replace(/:/g, ""), t = "M35 30Q135 8 255 28T490 23Q660 6 795 32L821 124 809 232 824 349 809 477 825 588 809 733Q772 773 680 756L520 754 355 766 195 752Q69 776 30 733L23 596 32 469 18 341 32 212 20 112Z";
	return /* @__PURE__ */ v("svg", {
		className: "pr-island-scenery",
		viewBox: "0 0 856 790",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ v("defs", { children: [/* @__PURE__ */ v("linearGradient", {
				id: `${e}sea`,
				x2: "0",
				y2: "1",
				children: [/* @__PURE__ */ _("stop", { stopColor: "#74bac4" }), /* @__PURE__ */ _("stop", {
					offset: "1",
					stopColor: "#b7dccc"
				})]
			}), /* @__PURE__ */ v("linearGradient", {
				id: `${e}land`,
				x2: ".8",
				y2: "1",
				children: [
					/* @__PURE__ */ _("stop", { stopColor: "#afc97b" }),
					/* @__PURE__ */ _("stop", {
						offset: ".55",
						stopColor: "#d3d88e"
					}),
					/* @__PURE__ */ _("stop", {
						offset: "1",
						stopColor: "#e2cf98"
					})
				]
			})] }),
			/* @__PURE__ */ _("rect", {
				width: "856",
				height: "790",
				rx: "18",
				fill: `url(#${e}sea)`
			}),
			/* @__PURE__ */ _("path", {
				d: t,
				fill: "none",
				stroke: "#e5f0d0",
				strokeWidth: "27"
			}),
			/* @__PURE__ */ _("path", {
				d: t,
				fill: `url(#${e}land)`,
				stroke: "#e8d29b",
				strokeWidth: "13"
			}),
			/* @__PURE__ */ _("path", {
				d: "M320 38Q404 10 509 36L600 62Q496 51 432 71L322 68Z",
				fill: "#7f9d5d"
			}),
			/* @__PURE__ */ _("path", {
				d: "M369 38Q408 26 443 38L485 56 420 50Z",
				fill: "#9db76c"
			}),
			Array.from({ length: 12 }, (e, t) => /* @__PURE__ */ v("g", { children: [
				/* @__PURE__ */ _(ut, {
					x: 24 + t % 3 * 2,
					y: 114 + t * 49,
					scale: .52
				}),
				/* @__PURE__ */ _(ut, {
					x: 823 - t % 2 * 3,
					y: 137 + t * 49,
					scale: .55
				}),
				t % 2 == 0 && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(X, {
					x: 31,
					y: 136 + t * 49,
					scale: .5
				}), /* @__PURE__ */ _(X, {
					x: 811,
					y: 156 + t * 49,
					scale: .42
				})] })
			] }, t)),
			/* @__PURE__ */ _(Y, {
				x: 34,
				y: 66,
				scale: .6
			}),
			/* @__PURE__ */ _(Y, {
				x: 807,
				y: 90,
				scale: .65
			}),
			/* @__PURE__ */ _(Y, {
				x: 24,
				y: 348,
				scale: .48
			}),
			/* @__PURE__ */ _(Y, {
				x: 816,
				y: 426,
				scale: .57
			}),
			/* @__PURE__ */ _(Y, {
				x: 30,
				y: 699,
				scale: .6
			}),
			/* @__PURE__ */ _(Y, {
				x: 811,
				y: 730,
				scale: .6
			}),
			/* @__PURE__ */ _(X, {
				x: 306,
				y: 48,
				scale: .75
			}),
			/* @__PURE__ */ _(X, {
				x: 358,
				y: 39,
				scale: .7
			}),
			/* @__PURE__ */ _(X, {
				x: 400,
				y: 51,
				scale: .6
			}),
			/* @__PURE__ */ v("g", {
				transform: "translate(530 16) scale(.7)",
				children: [
					/* @__PURE__ */ _("path", {
						d: "M0 45 45 33 76 45V76L35 86 0 72Z",
						fill: "#e7d4a7",
						stroke: "#806345",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ _("path", {
						d: "M-4 44 43 20 80 43 35 56Z",
						fill: "#b96b48",
						stroke: "#79543b",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ _("path", {
						d: "M5 47V21L18 16 32 22V77L18 80 5 74Z",
						fill: "#ebdfb7",
						stroke: "#806345",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ _("path", {
						d: "M1 22 18-4 36 21 18 28Z",
						fill: "#aa5c3f",
						stroke: "#79543b",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ _("path", {
						d: "M18-5V-15m-5 5h10M13 40v12m38 18V58l11-3v13",
						stroke: "#6b6b4b",
						strokeWidth: "4"
					})
				]
			}),
			/* @__PURE__ */ v("g", {
				transform: "translate(620 41) scale(.65)",
				children: [
					/* @__PURE__ */ _("path", {
						d: "M0 25 49 12 82 28V64L39 75 0 61Z",
						fill: "#debf89",
						stroke: "#806345",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ _("path", {
						d: "M-5 25 43 1 88 25 39 39Z",
						fill: "#b96b48",
						stroke: "#79543b",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ _("path", {
						d: "M4 41 38 50 75 40v14L39 65 4 55Z",
						fill: "#e9cf8e",
						stroke: "#956e44",
						strokeWidth: "2"
					})
				]
			}),
			/* @__PURE__ */ _("path", {
				d: "M653 80 746 99 810 83",
				fill: "none",
				stroke: "#aa9367",
				strokeWidth: "5"
			})
		]
	});
}
function ft() {
	let e = i().replace(/:/g, "");
	return /* @__PURE__ */ v("svg", {
		className: "pr-harbor-scenery",
		viewBox: "0 0 920 520",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ _("defs", { children: /* @__PURE__ */ v("linearGradient", {
				id: `${e}water`,
				x2: "1",
				y2: ".4",
				children: [
					/* @__PURE__ */ _("stop", { stopColor: "#74b4bb" }),
					/* @__PURE__ */ _("stop", {
						offset: ".7",
						stopColor: "#a9d7cf"
					}),
					/* @__PURE__ */ _("stop", {
						offset: "1",
						stopColor: "#d2e4c8"
					})
				]
			}) }),
			/* @__PURE__ */ _("rect", {
				width: "920",
				height: "520",
				rx: "12",
				fill: `url(#${e}water)`
			}),
			/* @__PURE__ */ _("path", {
				d: "M862 0Q835 64 853 136T851 293Q830 390 861 520H920V0Z",
				fill: "#e0ce99",
				stroke: "#e8edc6",
				strokeWidth: "7"
			}),
			Array.from({ length: 14 }, (e, t) => /* @__PURE__ */ _("path", {
				d: `M${17 + t * 151 % 850} ${23 + t * 35}q20-7 44-1m-28 7 36-1`,
				fill: "none",
				stroke: "#e1eee1",
				opacity: ".55",
				strokeWidth: "1.2"
			}, t)),
			[
				100,
				270,
				440
			].map((e) => /* @__PURE__ */ v("g", { children: [
				/* @__PURE__ */ _("path", {
					d: `M738 ${e - 15}H920V${e + 45}H738Z`,
					fill: "#b49a6d",
					stroke: "#786c4c",
					strokeWidth: "1.3"
				}),
				Array.from({ length: 8 }, (t, n) => /* @__PURE__ */ _("path", {
					d: `M738 ${e - 12 + n * 7}H920`,
					stroke: "#dfc48d"
				}, n)),
				/* @__PURE__ */ _("path", {
					d: `M745 ${e - 17}V${e + 48}M909 ${e - 17}V${e + 48}`,
					stroke: "#715d3e",
					strokeWidth: "4"
				})
			] }, e)),
			/* @__PURE__ */ _(Y, {
				x: 896,
				y: 205,
				scale: .55
			}),
			/* @__PURE__ */ _(Y, {
				x: 897,
				y: 375,
				scale: .5
			})
		]
	});
}
//#endregion
//#region src/games/puertorico/art.tsx
function Z({ good: e, size: t = 28 }) {
	return /* @__PURE__ */ _("svg", {
		width: t,
		height: t,
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		className: "pr-barrel",
		children: /* @__PURE__ */ _(pt, { good: e })
	});
}
function pt({ good: e }) {
	return /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M8 6Q20 0 32 6L35 18 33 34Q20 42 7 34L5 19Z",
			fill: A[e],
			stroke: "#554333",
			strokeWidth: "1.6"
		}),
		/* @__PURE__ */ _("path", {
			d: "M8 7Q20 13 32 7M7 33Q20 39 33 33",
			fill: "none",
			stroke: "#422e25",
			opacity: ".45"
		}),
		/* @__PURE__ */ _("path", {
			d: "M12 10q-3 13 0 23m7-22v24m8-24q3 10 1 23",
			fill: "none",
			stroke: "#f3dcaa",
			opacity: ".4"
		}),
		/* @__PURE__ */ _("path", {
			d: "M7 13Q20 19 33 13L34 17Q20 23 6 17ZM6 27Q20 33 34 27L33 31Q20 37 7 31Z",
			fill: "#817756",
			stroke: "#504a36",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ _("path", {
			d: "M8 14Q20 19 32 14M8 28Q20 33 32 28",
			stroke: "#d4c596",
			strokeWidth: ".7",
			fill: "none"
		}),
		/* @__PURE__ */ _("ellipse", {
			cx: "20",
			cy: "6",
			rx: "11.5",
			ry: "3.8",
			fill: A[e],
			stroke: "#69513b",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M13 5q7-3 14 0",
			stroke: "#f3dfa9",
			fill: "none",
			opacity: ".6"
		})
	] });
}
function mt() {
	return /* @__PURE__ */ v("svg", {
		className: "pr-coin",
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ _("circle", {
				cx: "12",
				cy: "12",
				r: "10",
				fill: "#deb654",
				stroke: "#876b34",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "12",
				cy: "12",
				r: "7",
				fill: "none",
				stroke: "#f6dea0",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ _("path", {
				d: "m10 8 2-1v10m-3 0h6",
				fill: "none",
				stroke: "#876b34",
				strokeWidth: "1.6"
			})
		]
	});
}
function ht() {
	return /* @__PURE__ */ _("svg", {
		className: "pr-point-star",
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: /* @__PURE__ */ _("path", {
			d: "m12 2 3 6.6 7 .8-5.2 4.9 1.4 7-6.2-3.5-6.2 3.5 1.4-7L2 9.4l7-.8Z",
			fill: "#d1a640",
			stroke: "#876b34",
			strokeWidth: "1.2"
		})
	});
}
function gt({ good: e }) {
	return /* @__PURE__ */ v("svg", {
		viewBox: "0 0 180 70",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": "true",
		className: "pr-field-art",
		children: [
			/* @__PURE__ */ _("rect", {
				width: "180",
				height: "70",
				fill: e === "forest" ? "#9eae6c" : e === "quarry" ? "#b4bca0" : "#c0b479"
			}),
			/* @__PURE__ */ _("path", {
				d: "M0 8q80 10 180 0M0 64q80-8 180 0",
				fill: "none",
				stroke: "#dce0a0",
				strokeWidth: "4",
				opacity: ".65"
			}),
			e === "forest" ? /* @__PURE__ */ _(g, { children: [
				25,
				67,
				105,
				149
			].map((e, t) => /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _(Y, {
				x: e,
				y: 24 + t % 2 * 13,
				scale: .8
			}), /* @__PURE__ */ _(X, {
				x: e - 10,
				y: 57 + t % 2 * 5,
				scale: .65
			})] }, e)) }) : Array.from({ length: 18 }, (t, n) => {
				let r = 12 + n % 6 * 26 + Math.floor(n / 6) * 4, i = 19 + Math.floor(n / 6) * 19;
				return /* @__PURE__ */ v("g", {
					transform: `translate(${r} ${i})`,
					children: [/* @__PURE__ */ _("path", {
						d: "M-4 9 21 3",
						stroke: "#8a7549",
						strokeWidth: "3",
						opacity: ".65"
					}), e === "quarry" ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("path", {
						d: "M0 6 6-9 15-11 24 7 10 12Z",
						fill: "#98a39a",
						stroke: "#68766f"
					}), /* @__PURE__ */ _("path", {
						d: "m6-9 4 21 5-23",
						fill: "#bec1a8",
						stroke: "#86988b",
						strokeWidth: ".6"
					})] }) : e === "coffee" ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(X, {
						x: 8,
						y: -3,
						scale: .43
					}), /* @__PURE__ */ _("path", {
						d: "m2-4 4 2m6-3 4 2m-7 4 4 2",
						stroke: "#af5140",
						strokeWidth: "2.5"
					})] }) : e === "tobacco" ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("path", {
						d: "M8 9V-13",
						stroke: "#536539",
						strokeWidth: "2"
					}), /* @__PURE__ */ _("path", {
						d: "M8 4Q-12 2-5-10 8-7 8 4Q25 0 22-13 8-10 8 4M8-4Q-3-13 3-18 9-14 8-4",
						fill: "#6e8f4a",
						stroke: "#49673c"
					})] }) : /* @__PURE__ */ v(g, { children: [
						/* @__PURE__ */ _("path", {
							d: "M8 8 7-10",
							stroke: "#526b38",
							strokeWidth: "1.8"
						}),
						/* @__PURE__ */ _("path", {
							d: "M7 2Q-5-8-3-11 7-9 7 2 10-12 17-11 16-1 7 2M6-4Q3-14 8-16 14-11 6-4",
							fill: e === "indigo" ? "#4f7180" : "#557b40",
							stroke: "#3c623b",
							strokeWidth: ".7"
						}),
						/* @__PURE__ */ _("path", {
							d: "M6-2 0-8m7 5 7-6",
							stroke: "#9fa966",
							strokeWidth: ".8"
						}),
						e === "corn" && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("path", {
							d: "M8-11 7-2",
							stroke: "#e8be52",
							strokeWidth: "3.8"
						}), /* @__PURE__ */ _("path", {
							d: "M7-10h2m-2 3h2",
							stroke: "#bc9439"
						})] }),
						e === "sugar" && /* @__PURE__ */ _("path", {
							d: "M6 6 4-16m6 23 2-19",
							stroke: "#a3b567",
							strokeWidth: "2"
						})
					] })]
				}, n);
			})
		]
	});
}
function _t({ color: e = "#b86846" }) {
	return /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M36 41 100 11 152 36 96 64Z",
			fill: e,
			stroke: "#79543b",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ _("path", {
			d: "m100 11-4 53",
			stroke: "#e1a66b",
			strokeWidth: "2"
		}),
		Array.from({ length: 7 }, (e, t) => /* @__PURE__ */ _("path", {
			d: `M${40 + t * 7} ${39 - t * 3.3}l51 23`,
			stroke: "#814a33",
			strokeWidth: ".8",
			opacity: ".5"
		}, t))
	] });
}
function vt({ x: e, y: t }) {
	return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("path", {
		d: `M${e} ${t + 12}V${t}l9 2v12Z`,
		fill: "#426b69",
		stroke: "#715e45",
		strokeWidth: "1.2"
	}), /* @__PURE__ */ _("path", {
		d: `M${e + 4} ${t + 1}v12`,
		stroke: "#b4a782"
	})] });
}
function yt({ x: e, y: t }) {
	return /* @__PURE__ */ v("g", {
		transform: `translate(${e} ${t})`,
		children: [/* @__PURE__ */ _("path", {
			d: "M0 2 16-2 27 3v20l-15 4L0 23Z",
			fill: "#b79965",
			stroke: "#735638"
		}), /* @__PURE__ */ _("path", {
			d: "m0 2 12 5 15-4M12 7v20M2 6l8 16M2 22l8-12m5 1 9 10m-9 3 9-16",
			fill: "none",
			stroke: "#80643f"
		})]
	});
}
var bt = /* @__PURE__ */ new Set([
	"smallMarket",
	"largeMarket",
	"blackMarket",
	"tradingPost",
	"royalSupplier"
]), xt = /* @__PURE__ */ new Set([
	"harbor",
	"wharf",
	"smallWharf"
]), St = /* @__PURE__ */ new Set([
	"chapel",
	"church",
	"cloister"
]), Ct = /* @__PURE__ */ new Set([
	"forestHouse",
	"huntingLodge",
	"constructionHut"
]), wt = /* @__PURE__ */ new Set([
	"smallWarehouse",
	"largeWarehouse",
	"storehouse",
	"tobaccoStorage"
]), Tt = /* @__PURE__ */ new Set([
	"residence",
	"cityHall",
	"university",
	"guildHall",
	"unionHall",
	"villa"
]);
function Et({ id: e }) {
	let t = e === "smallIndigo" || e === "indigoPlant", n = e === "smallSugar" || e === "sugarMill", r = e === "factory" || e === "specialtyFactory" || e === "coffeeRoaster", i = bt.has(e), a = xt.has(e), o = St.has(e), s = Ct.has(e), c = wt.has(e), l = Tt.has(e), u;
	return u = e === "aqueduct" ? /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M15 67 159 36 181 53 35 85Z",
			fill: "#639b8f",
			stroke: "#547d6d"
		}),
		/* @__PURE__ */ _("path", {
			d: "M22 38 155 10 173 22V67l-15 4V39q-14-14-24 6v31l-14 3V49q-14-14-24 5v29l-14 3V61q-14-14-24 5v24L22 82Z",
			fill: "#c4b58e",
			stroke: "#7a7555",
			strokeWidth: "1.6"
		}),
		/* @__PURE__ */ _("path", {
			d: "M22 38 155 10l18 12L40 52Z",
			fill: "#e3d3a6",
			stroke: "#7a7555"
		}),
		/* @__PURE__ */ _("path", {
			d: "m28 38 126-25 10 7-123 27Z",
			fill: "#649d9f"
		})
	] }) : e === "statue" ? /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M43 72 95 58 149 72 96 88Z",
			fill: "#b8ac88",
			stroke: "#706951"
		}),
		/* @__PURE__ */ _("path", {
			d: "M68 48 97 42 125 50v26l-30 8-27-9Z",
			fill: "#d6c9a2",
			stroke: "#81795d"
		}),
		/* @__PURE__ */ _("path", {
			d: "M95 18 86 37 74 47l10 4 10-11-5 23 18 2-2-29 10 11 8-6-16-16-2-8Z",
			fill: "#879385",
			stroke: "#536e64",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "100",
			cy: "10",
			r: "8",
			fill: "#9ba791",
			stroke: "#536e64"
		}),
		/* @__PURE__ */ _("path", {
			d: "M91 6 109 5l-3-7-11 1Z",
			fill: "#6c8577"
		})
	] }) : e === "royalGarden" ? /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M11 50 98 23 186 51 99 91Z",
			fill: "#64945b",
			stroke: "#3e7352",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M20 52 98 32l79 21-78 29Z",
			fill: "#b8b67a"
		}),
		/* @__PURE__ */ _("path", {
			d: "M31 51 97 39l63 16-60 20Z",
			fill: "#638857"
		}),
		/* @__PURE__ */ _("path", {
			d: "M96 36v44M26 53l139 2",
			stroke: "#e0cb8f",
			strokeWidth: "7"
		}),
		/* @__PURE__ */ _("ellipse", {
			cx: "96",
			cy: "55",
			rx: "24",
			ry: "11",
			fill: "#c5d1a9",
			stroke: "#e4d1a5",
			strokeWidth: "4"
		}),
		/* @__PURE__ */ _("ellipse", {
			cx: "96",
			cy: "54",
			rx: "17",
			ry: "6",
			fill: "#6aa2a1"
		}),
		/* @__PURE__ */ _("path", {
			d: "M96 52V28m-12 8q12-15 24 0",
			stroke: "#d9dcc4",
			strokeWidth: "3",
			fill: "none"
		}),
		/* @__PURE__ */ _(X, {
			x: 33,
			y: 39,
			scale: .6
		}),
		/* @__PURE__ */ _(X, {
			x: 151,
			y: 66,
			scale: .6
		})
	] }) : e === "lighthouse" ? /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M14 77 55 57 122 58 166 77Z",
			fill: "#819285",
			stroke: "#667968"
		}),
		/* @__PURE__ */ _("path", {
			d: "M75 77 81 7h29l8 70Z",
			fill: "#e4d2a3",
			stroke: "#7e6b4d",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "m80 27 33 2 2 15-37-1Z",
			fill: "#ab6547"
		}),
		/* @__PURE__ */ _("path", {
			d: "M79 6h35v15H79Z",
			fill: "#e4c67b",
			stroke: "#78674b"
		}),
		/* @__PURE__ */ _("path", {
			d: "M74 7 96-8l24 15Z",
			fill: "#ad6849",
			stroke: "#78674b"
		}),
		/* @__PURE__ */ _("path", {
			d: "M95 6v15m-12-9h26M91 77V61h12v16",
			stroke: "#71684d",
			strokeWidth: "2"
		})
	] }) : e === "fortress" ? /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M25 36 99 16 167 35v40L96 91 25 73Z",
			fill: "#b4b69a",
			stroke: "#71775d",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M25 36v-9l10-3v9l14-4v-9l11-3v10l14-4v-9l11-3v10l14-4 14 5V12l11 4v11l14 4V21l11 4v11l18 6v-7l10 2v13L98 65Z",
			fill: "#d6d2ac",
			stroke: "#71775d",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M83 88V66q12-23 26-3v25M40 49v10m18-16v11m76-6v11m15-16v11",
			stroke: "#65745b",
			fill: "#6c795e",
			strokeWidth: "3"
		})
	] }) : /* @__PURE__ */ v(g, { children: [
		a && /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("path", {
				d: "M15 73 101 49 183 66 96 91Z",
				fill: "#bca071",
				stroke: "#785d40"
			}),
			/* @__PURE__ */ _("path", {
				d: "M24 72 103 53m-55 26 78-22m-55 28 79-22m-52 25 73-20",
				stroke: "#927044"
			}),
			/* @__PURE__ */ _("path", {
				d: "M34 75v14m111-19v18",
				stroke: "#6f583c",
				strokeWidth: "5"
			})
		] }),
		l && /* @__PURE__ */ _("path", {
			d: "M18 51 46 42 65 51v28l-25 7-22-7Z",
			fill: "#e8d2a7",
			stroke: "#806345"
		}),
		/* @__PURE__ */ _("path", {
			d: "M44 48 100 35 144 49V76L96 88 44 73Z",
			fill: o || l ? "#ece0bd" : s ? "#bd9c66" : "#debe8a",
			stroke: "#806345",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ _("path", {
			d: "M96 61 144 49v27L96 88Z",
			fill: "#bba16e",
			stroke: "#806345",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ _(_t, { color: t ? "#5c7b91" : e === "blackMarket" ? "#615d66" : e === "royalSupplier" || e === "jeweler" ? "#8a5c6b" : s ? "#846c4a" : "#b86846" }),
		/* @__PURE__ */ _(vt, {
			x: 59,
			y: 59
		}),
		/* @__PURE__ */ _(vt, {
			x: 76,
			y: 63
		}),
		/* @__PURE__ */ _("path", {
			d: "M108 84V64l14-4v21Z",
			fill: "#6c6649",
			stroke: "#775c3f"
		}),
		i && /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("path", {
				d: "M35 58 88 72 137 58v13L88 85 35 71Z",
				fill: "#e0bf81",
				stroke: "#806345"
			}),
			Array.from({ length: e === "largeMarket" ? 8 : 6 }, (e, t) => /* @__PURE__ */ _("path", {
				d: `M${37 + t * 8} ${58 + t * 2}l8 2-3 13-8-2Z`,
				fill: t % 2 ? "#b86440" : "#f0ddb2",
				stroke: "#9c7048",
				strokeWidth: ".6"
			}, t)),
			/* @__PURE__ */ _("path", {
				d: "M40 73v11m45-8v15m43-18v10",
				stroke: "#72553c",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ _("ellipse", {
				cx: "56",
				cy: "78",
				rx: "10",
				ry: "4",
				fill: "#bf9a3b"
			}),
			/* @__PURE__ */ _("ellipse", {
				cx: "112",
				cy: "76",
				rx: "10",
				ry: "4",
				fill: "#71914f"
			}),
			/* @__PURE__ */ _(yt, {
				x: 145,
				y: 68
			})
		] }),
		t && /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("path", {
				d: "M15 66 33 61 47 68v14l-19 5-13-7Z",
				fill: "#8f9b8a",
				stroke: "#5f705e"
			}),
			/* @__PURE__ */ _("ellipse", {
				cx: "31",
				cy: "66",
				rx: "15",
				ry: "5",
				fill: "#375a83",
				stroke: "#82979a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ _("path", {
				d: "M21 73v8m9-7v10m9-11v8",
				stroke: "#c0b998"
			}),
			e === "indigoPlant" && /* @__PURE__ */ _("ellipse", {
				cx: "159",
				cy: "76",
				rx: "19",
				ry: "7",
				fill: "#375a83",
				stroke: "#82979a",
				strokeWidth: "4"
			})
		] }),
		(n || r) && /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("path", {
				d: "M126 43V13l12-4 9 4v39l-11 4Z",
				fill: "#b8a480",
				stroke: "#7a6e51"
			}),
			/* @__PURE__ */ _("path", {
				d: "M138 9v47M126 24l12 4 9-4m-21 11 12 4 9-4",
				fill: "none",
				stroke: "#8f7d5a"
			}),
			/* @__PURE__ */ _("path", {
				d: "M133 4q-11-4-5-12t16-7",
				fill: "none",
				stroke: "#d4d2b4",
				strokeWidth: "7",
				opacity: ".75"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "31",
				cy: "77",
				r: "10",
				fill: "#927e58",
				stroke: "#594e35"
			}),
			/* @__PURE__ */ _("path", {
				d: "M31 67v20m-10-10h20m-17-7 14 14m0-14-14 14",
				stroke: "#d2bc87"
			}),
			r && /* @__PURE__ */ _(yt, {
				x: 147,
				y: 69
			})
		] }),
		o && /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("path", {
				d: "M32 42 50 37 68 43v37l-18 5-18-6Z",
				fill: "#e6d4aa",
				stroke: "#816848"
			}),
			/* @__PURE__ */ _("path", {
				d: "M29 42 50 10 72 42 50 49Z",
				fill: "#ac5d3e",
				stroke: "#76563d"
			}),
			/* @__PURE__ */ _("path", {
				d: "M50 49v36M40 58V50l7-2v10Z",
				fill: "#577a75",
				stroke: "#816848"
			}),
			/* @__PURE__ */ _("path", {
				d: "M50 8V-1m-5 4h10",
				stroke: "#7c6342",
				strokeWidth: "2"
			}),
			e !== "chapel" && /* @__PURE__ */ _("path", {
				d: "M139 42V19l15-4 14 7v54l-15 4-14-5Z",
				fill: "#e6d4aa",
				stroke: "#816848"
			})
		] }),
		a && /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("path", {
				d: "M26 79V25M26 29 67 22M27 39 55 25M61 24v25",
				stroke: "#725a3e",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ _(yt, {
				x: 50,
				y: 48
			}),
			e === "wharf" && /* @__PURE__ */ _("path", {
				d: "M146 71 173 64l17 9-20 10Z",
				fill: "#719da0",
				stroke: "#586e59"
			})
		] }),
		c && /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _(yt, {
				x: 18,
				y: 65
			}),
			/* @__PURE__ */ _(yt, {
				x: 140,
				y: 66
			}),
			e === "largeWarehouse" && /* @__PURE__ */ _(yt, {
				x: 162,
				y: 56
			}),
			e === "tobaccoStorage" && /* @__PURE__ */ _("path", {
				d: "m53 56 37 10m-37-3 37 10m-37-3 37 10",
				stroke: "#776c3f",
				strokeWidth: "3"
			})
		] }),
		l && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("path", {
			d: "M48 70 96 83l49-13v8L96 93 48 80Z",
			fill: "#e7d3aa",
			stroke: "#9b8057"
		}), /* @__PURE__ */ _("path", {
			d: "M52 56v21m17-16v21m18-16v20m17-20v20m18-24v20m16-25v19",
			stroke: "#eedeae",
			strokeWidth: "4"
		})] }),
		s && /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _(Y, {
				x: 29,
				y: 43,
				scale: .6
			}),
			/* @__PURE__ */ _(X, {
				x: 158,
				y: 75,
				scale: .7
			}),
			e === "huntingLodge" && /* @__PURE__ */ _("path", {
				d: "M108 42v-9m0 2-9-5m9 5 9-7",
				fill: "none",
				stroke: "#e6ce97",
				strokeWidth: "2"
			})
		] }),
		e === "guesthouse" && /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("path", {
				d: "M142 49V28h19v43l-19 5Z",
				fill: "#d4bd8a",
				stroke: "#806345"
			}),
			/* @__PURE__ */ _("path", {
				d: "m138 29 14-14 15 13Z",
				fill: "#a95d43",
				stroke: "#806345"
			}),
			/* @__PURE__ */ _("path", {
				d: "M150 56V40h6v16",
				fill: "#587c73"
			})
		] }),
		(e === "library" || e === "office" || e === "districtOffice" || e === "landOffice" || e === "customsHouse") && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("path", {
			d: "M20 49h29v24H20Z",
			fill: "#e4d6af",
			stroke: "#8c7954"
		}), /* @__PURE__ */ _("path", {
			d: e === "landOffice" ? "M24 54 31 60l7-4 7 9m-17-9v11m11-11v11" : e === "library" ? "M25 54v13l8 2 8-2V54l-8 2Z M33 56v13" : "M25 56h18m-18 5h18m-18 5h12",
			fill: "none",
			stroke: "#6b765b",
			strokeWidth: "1.5"
		})] }),
		e === "jeweler" && /* @__PURE__ */ _("path", {
			d: "M151 58h20l7 9-17 16-18-16Z M144 67h33m-27-8 11 24 9-24",
			fill: "#8ab6ae",
			stroke: "#536b65",
			strokeWidth: "1.5"
		}),
		e === "hospice" && /* @__PURE__ */ _("path", {
			d: "M30 42v25m-12-13h25",
			stroke: "#6c8c6b",
			strokeWidth: "5"
		}),
		e === "hacienda" && /* @__PURE__ */ _(Y, {
			x: 165,
			y: 43,
			scale: .75
		})
	] }), /* @__PURE__ */ v("svg", {
		viewBox: "0 -12 194 110",
		"aria-hidden": "true",
		className: "pr-building-art",
		children: [
			/* @__PURE__ */ _("path", {
				d: "M7 79Q20 65 55 70L147 69Q182 69 188 81L158 94 30 95Z",
				fill: "#7c9a53",
				stroke: "#55774b"
			}),
			/* @__PURE__ */ _("path", {
				d: "M19 84 77 73 157 80 116 92Z",
				fill: "#c7b27a"
			}),
			u,
			/* @__PURE__ */ _("path", {
				d: "M8 86q8-5 13 0m145 3q8-5 16-2",
				fill: "none",
				stroke: "#d9ce8e",
				strokeWidth: "2"
			})
		]
	});
}
function Dt({ capacity: e, good: t, count: n, preview: r }) {
	let i = 67 + e * 68;
	return /* @__PURE__ */ v("svg", {
		className: "pr-ship-art",
		viewBox: `0 0 ${i + 20} 132`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ _("ellipse", {
				cx: i / 2 + 15,
				cy: "119",
				rx: i / 2 - 7,
				ry: "7",
				fill: "#2a7c7b",
				opacity: ".18"
			}),
			/* @__PURE__ */ _("path", {
				d: `M28 45Q${i / 2} 35 ${i - 24} 40L${i + 5} 95Q${i - 2} 119 ${i - 53} 121H52Q33 117 28 45Z`,
				fill: "#9b7349",
				stroke: "#6e543c",
				strokeWidth: "1.8"
			}),
			/* @__PURE__ */ _("path", {
				d: `M28 43Q${i / 2} 32 ${i - 24} 38L${i - 8} 92Q${i - 17} 108 ${i - 57} 108H43Z`,
				fill: "#d8bd85",
				stroke: "#6e543c",
				strokeWidth: "1.3"
			}),
			Array.from({ length: 7 }, (e, t) => /* @__PURE__ */ _("path", {
				d: `M36 ${48 + t * 8}Q${i / 2} ${40 + t * 8} ${i - 24} ${45 + t * 8}`,
				fill: "none",
				stroke: "#b99b65",
				strokeWidth: ".8"
			}, t)),
			/* @__PURE__ */ _("path", {
				d: `M38 108H${i - 30}m-${i - 77} 7h${i - 91}`,
				fill: "none",
				stroke: "#e2c58a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ _("path", {
				d: `M34 43H${i - 30}`,
				stroke: "#8d653e",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ _("path", {
				d: "M37 21v88m0-82 49 76M37 27l-7 74",
				stroke: "#7d694a",
				strokeWidth: "1.1",
				fill: "none"
			}),
			/* @__PURE__ */ _("path", {
				d: "M34 27Q9 39 5 91q15-9 29-3Z",
				fill: "#f2dfaa",
				stroke: "#8e7850"
			}),
			/* @__PURE__ */ _("path", {
				d: "M30 34Q12 61 12 84",
				fill: "none",
				stroke: "#d3bd84",
				strokeWidth: "1.3"
			}),
			/* @__PURE__ */ _("path", {
				d: "m37 21 19 4-19 7Z",
				fill: "#ac6c42",
				stroke: "#7d5537",
				strokeWidth: ".6"
			}),
			Array.from({ length: e }, (e, i) => {
				let a = !!r && i >= n && i < n + r.count, o = i < n ? t : a ? r?.good : null;
				return /* @__PURE__ */ v("g", {
					transform: `translate(${49 + i * 68} 49)`,
					children: [
						/* @__PURE__ */ _("rect", {
							width: "60",
							height: "54",
							rx: "3",
							fill: a ? "#e8e0ae" : "#e3c997",
							fillOpacity: ".8",
							stroke: a ? "#286c73" : "#ac8a55",
							strokeWidth: a ? 2 : .8
						}),
						o && /* @__PURE__ */ _("g", {
							transform: "translate(5 2) scale(1.25)",
							opacity: a ? .5 : 1,
							children: /* @__PURE__ */ _(pt, { good: o })
						}),
						a && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("circle", {
							cx: "58",
							cy: "2",
							r: "7",
							fill: "#286c73"
						}), /* @__PURE__ */ _("path", {
							d: "M55 2h6m-3-3v6",
							stroke: "#fff5d1",
							strokeWidth: "1.6"
						})] })
					]
				}, i);
			})
		]
	});
}
function Ot({ role: e }) {
	let t = e === "buccaneer", n = e === "captain", r = e === "prospector" || e === "prospector2", i = e === "trader" || e === "craftsman" ? "#b98258" : e === "mayor" || t ? "#ce9a6b" : "#ddb185";
	return /* @__PURE__ */ v("svg", {
		className: "pr-role-art",
		viewBox: "0 0 108 112",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ _("path", {
				d: "M8 107V83q3-22 32-25h28q29 4 32 25v24Z",
				fill: t ? "#70535a" : n ? "#456f80" : e === "trader" ? "#a15d48" : e === "mayor" ? "#74885d" : "#ba9d68",
				stroke: "#665840",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ _("path", {
				d: "m41 59 13 13 14-13-6 39H46Z",
				fill: "#eee0b9",
				stroke: "#8a7754"
			}),
			/* @__PURE__ */ _("path", {
				d: "m42 60-9 8 12 12m23-20 8 8-13 12",
				fill: "none",
				stroke: "#d6bc88",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ _("path", {
				d: "M43 54v12q12 10 24-1V51Z",
				fill: i,
				stroke: "#815f45"
			}),
			/* @__PURE__ */ _("path", {
				d: "M32 25q2-20 23-20 23 0 25 22v23Q73 65 56 65 37 64 32 48Z",
				fill: i,
				stroke: "#73573f",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ _("path", {
				d: "M33 24q-8 8-3 23l7-5V26m36-3 4 21 5-2q5-17-3-24",
				fill: "#635440"
			}),
			/* @__PURE__ */ _("path", {
				d: "M41 35h7m15 0h7m-17 4-2 8 5 1m-8 8q8 4 15-1",
				fill: "none",
				stroke: "#79553e",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "45",
				cy: "39",
				r: "1.8",
				fill: "#453e34"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "66",
				cy: "39",
				r: "1.8",
				fill: "#453e34"
			}),
			t || n ? /* @__PURE__ */ v(g, { children: [
				/* @__PURE__ */ _("path", {
					d: t ? "M19 24Q30-5 48 11q10-23 25-5 15-2 22 21L65 24 43 29Z" : "M24 22 34 3h42l13 19Z",
					fill: t ? "#544c45" : "#527b87",
					stroke: "#514e3c",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ _("path", {
					d: "M27 23q29 9 58 0",
					stroke: "#d2af6b",
					strokeWidth: "3",
					fill: "none"
				}),
				t && /* @__PURE__ */ v(g, { children: [
					/* @__PURE__ */ _("path", {
						d: "M41 36h11v9H41Z",
						fill: "#4d463d"
					}),
					/* @__PURE__ */ _("path", {
						d: "m34 30 39 20",
						stroke: "#5b4b3c"
					}),
					/* @__PURE__ */ _("path", {
						d: "M54 12h8m-4-3v6",
						stroke: "#f1d8a4",
						strokeWidth: "2"
					})
				] })
			] }) : e === "mayor" ? /* @__PURE__ */ _("path", {
				d: "M29 24q-4-18 9-22h33q13 4 10 22l-10-6-12 7-12-7Z",
				fill: "#e0d6b7",
				stroke: "#82775b"
			}) : /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("path", {
				d: "M18 26q35-14 74-1L76 13 67 3H44L33 16Z",
				fill: r ? "#9c8052" : "#d2b77c",
				stroke: "#7b6345",
				strokeWidth: "1.5"
			}), /* @__PURE__ */ _("path", {
				d: "M34 17q21 5 42-1",
				fill: "none",
				stroke: "#8f784d",
				strokeWidth: "3"
			})] }),
			e === "settler" && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("path", {
				d: "m19 107-5-38m0 10-9-12m11 4 9-13m-9 26 12-8",
				stroke: "#5c7b42",
				strokeWidth: "3"
			}), /* @__PURE__ */ _("path", {
				d: "m11 65 3-10 4 11Z",
				fill: "#ddbb58"
			})] }),
			e === "builder" && /* @__PURE__ */ v(g, { children: [
				/* @__PURE__ */ _("path", {
					d: "M48 86h42v21H48Z",
					fill: "#b97652",
					stroke: "#7e573d"
				}),
				/* @__PURE__ */ _("path", {
					d: "M48 96h42M69 86v10m-10 0v11m19-11v11",
					stroke: "#e3b17a",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ _("path", {
					d: "m17 103 13-32m-21 1 31 12",
					stroke: "#765b40",
					strokeWidth: "5"
				})
			] }),
			e === "craftsman" && /* @__PURE__ */ v(g, { children: [
				/* @__PURE__ */ _("path", {
					d: "M29 87h48v24H29Z",
					fill: "#9e8056",
					stroke: "#6b5941"
				}),
				/* @__PURE__ */ _("path", {
					d: "m71 97 21-34m-9-7 19 12",
					stroke: "#70674c",
					strokeWidth: "6"
				}),
				/* @__PURE__ */ _("path", {
					d: "M32 96h37",
					stroke: "#d6ba7c",
					strokeWidth: "2"
				})
			] }),
			e === "trader" && /* @__PURE__ */ v(g, { children: [
				/* @__PURE__ */ _("path", {
					d: "M66 76h32v29H66Z",
					fill: "#889c80",
					stroke: "#576c57"
				}),
				/* @__PURE__ */ _("path", {
					d: "M72 76v29m7-29v29m7-29v29m6-29v29",
					stroke: "#d2cea0",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ _("path", {
					d: "M8 96h31m-24-2 10-16 10 16m-10-16V66",
					fill: "#c9a55d",
					stroke: "#795f3d",
					strokeWidth: "2"
				})
			] }),
			e === "mayor" && /* @__PURE__ */ v(g, { children: [
				/* @__PURE__ */ _("path", {
					d: "M70 70h26v37H70Z",
					fill: "#d8c69a",
					stroke: "#7c704e"
				}),
				/* @__PURE__ */ _("path", {
					d: "M78 69h10v5H78Z",
					fill: "#8b815f"
				}),
				/* @__PURE__ */ _("path", {
					d: "M75 83h15m-15 7h15m-15 7h10",
					stroke: "#879174",
					strokeWidth: "2"
				})
			] }),
			n && /* @__PURE__ */ v(g, { children: [
				/* @__PURE__ */ _("circle", {
					cx: "84",
					cy: "91",
					r: "16",
					fill: "#b79a63",
					stroke: "#715d3f",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ _("circle", {
					cx: "84",
					cy: "91",
					r: "6",
					fill: "#dbbd7f",
					stroke: "#715d3f",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ _("path", {
					d: "M84 69v44M62 91h44M69 76l30 30m0-30-30 30",
					stroke: "#715d3f",
					strokeWidth: "3"
				})
			] }),
			r && /* @__PURE__ */ v(g, { children: [
				/* @__PURE__ */ _("path", {
					d: "m76 108 9-46m-15 3q18-15 34 1",
					stroke: "#7c6849",
					strokeWidth: "4",
					fill: "none"
				}),
				/* @__PURE__ */ _("ellipse", {
					cx: "25",
					cy: "100",
					rx: "19",
					ry: "9",
					fill: "#9b956b",
					stroke: "#6b684d",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ _("path", {
					d: "M15 96h6m5 4h6m-10-2 4-3",
					stroke: "#dfb54b",
					strokeWidth: "3"
				})
			] }),
			t && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("path", {
				d: "M75 108q25-15 26-42-14 13-32 30Z",
				fill: "#bdc7b3",
				stroke: "#616c5c",
				strokeWidth: "1.5"
			}), /* @__PURE__ */ _("path", {
				d: "m65 91 16 14",
				stroke: "#b79759",
				strokeWidth: "4"
			})] })
		]
	});
}
function kt({ count: e, capacity: t, nobles: n = 0 }) {
	return /* @__PURE__ */ _("span", {
		className: "pr-workers",
		"aria-hidden": "true",
		children: Array.from({ length: t }, (t, r) => /* @__PURE__ */ _("span", {
			className: r < n ? "pr-worker pr-worker-noble" : r < e ? "pr-worker pr-worker-filled" : "pr-worker",
			children: r < n ? "◆" : ""
		}, r))
	});
}
var At = (e) => ({ "--pr-good": A[e] }), jt = {
	corn: .7,
	indigo: 1.3,
	sugar: 1.9,
	tobacco: 2.6,
	coffee: 3.4
}, Mt = {
	score: 1,
	money: .5,
	goods: .5,
	capacity: 1.4,
	space: 2.75
}, Nt = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32;
function Pt(e) {
	let t = [...e];
	for (let e = t.length - 1; e > 0; e--) {
		let n = Math.floor(Nt() * (e + 1));
		[t[e], t[n]] = [t[n], t[e]];
	}
	return t;
}
function Ft(e, t) {
	let n = e.players.map((e) => ({
		...e,
		plantations: e.plantations.map((e) => e.kind === "forest" ? {
			kind: "forest",
			crop: "corn",
			workers: e.workers
		} : { ...e })
	})), r = S(), i = 0;
	for (let e of n) for (let t of e.plantations) t.kind === "forest" ? i++ : t.kind !== "quarry" && r[t.kind]++;
	for (let t of e.plantations) t !== null && (r[t] += 1);
	let a = [];
	for (let e of x) {
		let t = Math.max(0, ue[e] - r[e] - Math.ceil(i / x.length));
		for (let n = 0; n < t; n++) a.push(e);
	}
	let o = Math.min(e.deckCount, a.length), s = Pt(a).slice(0, o), c = a.slice(o), l = e.roles.filter((e) => e.pickedBy).length;
	return {
		config: e.config,
		draftSlots: [...e.draftSlots],
		guestContext: e.guestContext,
		buccaneerOwner: e.buccaneerOwner,
		kidnapped: e.kidnapped,
		festival: e.festival ? structuredClone(e.festival) : null,
		phase: e.phase,
		round: e.round,
		governor: e.governor,
		turn: e.turn,
		selector: e.selector,
		role: e.role,
		players: n,
		roles: e.roles.map((e) => ({ ...e })),
		plantations: [...e.plantations],
		quarries: e.quarries,
		workerSupply: e.workerSupply,
		recruitment: e.recruitment,
		nobleSupply: e.nobleSupply,
		recruitmentNobles: e.recruitmentNobles,
		vpSupply: e.vpSupply,
		goodsSupply: { ...e.goodsSupply },
		market: { ...e.market },
		ships: e.ships.map((e) => ({ ...e })),
		tradingHouse: [...e.tradingHouse],
		endReasons: [...e.endReasons],
		scores: e.scores,
		log: [],
		seed: 1,
		rngCursor: 0,
		deck: s,
		discard: c,
		vp: { ...e.vp },
		selectedCount: l,
		follower: 0,
		haciendaUsed: !1,
		hospiceUsed: !1,
		wharfUsed: [],
		captainBonusUsed: !1,
		smallWharfUsed: [],
		captainStarted: [],
		lighthouseBonusUsed: !1,
		bonusTaken: 0,
		librarySettlerUsed: !1,
		drawnTile: e.phase === "forest" ? t.choices.drawnGood : null,
		guestQueue: e.phase === "guesthouse" ? [e.turn] : [],
		guestResume: null,
		produced: {},
		villaUsed: [],
		landUsed: [],
		huntingDone: [],
		forestResume: "settler",
		royalDone: [],
		landAfterTrade: !1
	};
}
function It(e, t) {
	let n = e.players.map((t) => {
		let n = Be(t, e.vp[t.rid] ?? 0), r = x.reduce((e, n) => e + t.goods[n] * jt[n], 0), i = 0;
		for (let e of x) {
			let n = t.plantations.filter((t) => t.kind === e && t.workers > 0).length, r = e === "corn" ? n : t.buildings.filter((t) => D[t.id].produces === e).reduce((e, t) => e + t.workers, 0);
			i += Math.min(n, r) * jt[e];
		}
		let a = 12 - t.buildings.reduce((e, t) => e + D[t.id].size, 0);
		return {
			rid: t.rid,
			value: n.total * Mt.score + t.money * Mt.money + r * Mt.goods + i * Mt.capacity + a * Mt.space
		};
	});
	return n.find((e) => e.rid === t).value - Math.max(...n.filter((e) => e.rid !== t).map((e) => e.value)) * .9;
}
function Lt(e, t, n, r = 1) {
	let i = e, a = i.round;
	for (let e = 0; e < n; e++) {
		if (i.phase === "done" || i.phase === "role" && i.round >= a + r) return i;
		let e = i.turn;
		if (!e) return i;
		let n = lt.viewFor(i, e), o;
		try {
			o = t(i, n);
		} catch {
			return i;
		}
		if (!o) return i;
		let s = lt.reduce(i, o, { by: e });
		if ("code" in s) return i;
		i = s.state;
	}
	return i;
}
function Rt(e, t, n, r, i) {
	if (n.length <= 1) return n[0] ?? null;
	let a = performance.now() + i.budgetMs, o = n.map(() => 0), s = n.map(() => 0);
	for (let c = 0; c < i.samples; c++) for (let c = 0; c < n.length && !(performance.now() > a && s[c] > 0); c++) {
		let a = {
			...structuredClone(e),
			deck: Pt(e.deck),
			discard: Pt(e.discard)
		}, l = lt.reduce(a, n[c], { by: t });
		if ("code" in l) continue;
		let u = Lt(l.state, r, i.maxSteps, i.rounds ?? 1);
		o[c] += It(u, t), s[c] += 1;
	}
	let c = 0;
	for (let e = 1; e < n.length; e++) s[e] && o[e] / s[e] > o[c] / s[c] && (c = e);
	return n[c] ?? null;
}
//#endregion
//#region src/games/puertorico/bot.ts
var zt = {
	corn: 0,
	indigo: 1,
	sugar: 2,
	tobacco: 3,
	coffee: 4
}, Bt = {
	corn: .7,
	indigo: 1.3,
	sugar: 1.9,
	tobacco: 2.6,
	coffee: 3.4
}, Vt = {
	smallIndigo: 5,
	smallSugar: 5,
	indigoPlant: 3,
	sugarMill: 3,
	tobaccoStorage: 4,
	coffeeRoaster: 4,
	smallMarket: 4,
	hacienda: 1,
	constructionHut: 2,
	smallWarehouse: 2,
	hospice: 7,
	office: 1,
	largeMarket: 3,
	largeWarehouse: 2,
	factory: 5,
	university: 5,
	harbor: 8,
	wharf: 8,
	guildHall: 5,
	residence: 5,
	fortress: 5,
	customsHouse: 5,
	cityHall: 5,
	blackMarket: 3,
	forestHouse: 4,
	aqueduct: 4,
	storehouse: 3,
	guesthouse: 5,
	church: 6,
	tradingPost: 4,
	smallWharf: 5,
	lighthouse: 6,
	specialtyFactory: 5,
	library: 9,
	unionHall: 7,
	cloister: 5,
	statue: 6,
	districtOffice: 6,
	royalSupplier: 7,
	chapel: 6,
	jeweler: 8,
	villa: 8,
	huntingLodge: 3,
	landOffice: 3,
	royalGarden: 7
}, Ht = .5, Ut = 1.6, Wt = 5, Gt = { on: 1 }, Kt = (e, t) => e.plantations.filter((e) => e.kind === t).length, qt = (e, t) => e.buildings.filter((e) => D[e.id].produces === t).reduce((e, t) => e + D[t.id].slots, 0), Jt = (e) => e.buildings.filter((e) => D[e.id].produces);
function Yt(e, t) {
	if (t === "quarry") {
		let t = e.plantations.filter((e) => e.kind === "quarry").length;
		return t < 2 && V(e) <= 9 ? 3.5 - t * .5 : 0;
	}
	let n = Kt(e, t);
	if (t === "corn") return Math.max(.5, 4.5 - n * .7);
	let r = qt(e, t), i = Bt[t] * 1.1;
	return r > n ? i + 1.2 : i * .35;
}
function Xt(e, t, n) {
	let r = D[t], i = Vt[t] + r.vp * .8;
	if (r.produces) {
		let t = Kt(e, r.produces), n = qt(e, r.produces);
		i += 5 * Math.min(r.slots, Math.max(0, t - n)), (!t || n >= t + 1) && (i -= 7);
	}
	(t === "hospice" || t === "university") && (i -= V(e) * .4), r.size === 2 && (i += V(e) > 5 ? 5 : -2), t === "guildHall" && (i += Jt(e).length * 1.3), t === "residence" && (i += Math.max(0, e.plantations.length - 5) * .9 + 2), t === "cityHall" && (i += e.buildings.filter((e) => !D[e.id].produces).length * .8), t === "fortress" && (i += Math.floor(z(e) / 3) * .8), t === "customsHouse" && (i += Math.min(6, e.money) * .25), t === "factory" && (i += x.filter((t) => Kt(e, t) > 0).length * 1.2), (t === "harbor" || t === "wharf") && (i += x.reduce((t, n) => t + Kt(e, n), 0) * .4), (t === "smallWarehouse" || t === "largeWarehouse") && (i += (t === "largeWarehouse" ? 2 : 1) * (x.filter((t) => Kt(e, t) > 0).length > 2 ? 2 : 1));
	let a = 12 - V(e);
	return i -= r.size * Ut * (a <= 6 ? 1 : .4), n?.has(t) && (i += Wt), i;
}
function Zt(e, t) {
	let n = Jt(e).length, r = D[t].vp;
	switch (t) {
		case "guildHall": return r + Math.max(1, Math.round(n / 2));
		case "cityHall": return r + Math.max(1, Math.round((e.buildings.length - n) / 2));
		case "residence": return r + Math.max(1, Math.round(e.plantations.length / 3));
		case "fortress": return r + Math.max(1, Math.round(z(e) / 3));
		case "customsHouse": return r + 3;
		case "factory": return r + 2;
		case "harbor": return r + 2;
		case "wharf": return r + 1;
		default: return r;
	}
}
function Qt(e, t) {
	let n = 12 - V(t);
	if (n <= 0 || !Gt.on) return {
		ids: /* @__PURE__ */ new Set(),
		value: 0
	};
	let r = e.vpSupply / (e.players.length * 1.8), i = 2 + Jt(t).length * .8, a = Math.floor(t.money + r * i), o = Object.keys(e.market).filter((r) => e.market[r] > 0 && !t.buildings.some((e) => e.id === r) && D[r].size <= n).map((e) => ({
		id: e,
		size: D[e].size,
		cost: D[e].cost,
		value: Zt(t, e)
	})).sort((e, t) => t.value - e.value).slice(0, 8);
	if (!o.length) return {
		ids: /* @__PURE__ */ new Set(),
		value: 0
	};
	let s = Math.min(a, 60), c = /* @__PURE__ */ new Map();
	c.set("0,0", {
		value: 0,
		ids: []
	});
	for (let e of o) {
		let t = new Map(c);
		for (let [r, i] of c) {
			let [a, o] = r.split(",").map(Number);
			if (a + e.size > n || o + e.cost > s) continue;
			let c = `${a + e.size},${o + e.cost}`, l = i.value + e.value, u = t.get(c);
			(!u || l > u.value) && t.set(c, {
				value: l,
				ids: [...i.ids, e.id]
			});
		}
		c = t;
	}
	let l = {
		value: 0,
		ids: []
	};
	for (let e of c.values()) e.value > l.value && (l = e);
	return {
		ids: new Set(l.ids),
		value: l.value
	};
}
function $t(e, t, n) {
	let r = Object.entries(e.market).filter(([e, r]) => r > 0 && !t.buildings.some((t) => t.id === e) && V(t) + D[e].size <= 12 && Fe(t, e, n) <= t.money);
	if (!r.length) return 0;
	let i = Qt(e, t).ids;
	return Math.max(-2, ...r.map(([e]) => {
		let r = e;
		return Xt(t, r, i) * .8 - Fe(t, r, n) * .15;
	}));
}
function en(e, t) {
	let n = 0;
	for (let r of x) {
		if (!t.goods[r]) continue;
		let i = e.ships.find((e) => e.good === r && e.count < e.capacity), a = i ? i.capacity - i.count : Math.max(0, ...e.ships.filter((e) => e.good === null).map((e) => e.capacity));
		n += Math.min(t.goods[r], a);
	}
	return n + (R(t, "harbor") ? C(t.goods) * .15 : 0);
}
function tn(e, t, n, r) {
	if (n === "mayor") return Math.max(0, xe(t) - z(t)) * 1.9 + t.unemployed * .5;
	if (n === "settler") {
		let n = e.plantations.filter((e) => e !== null);
		return Math.max(0, ...n.map((e) => Yt(t, e))) + (r && e.quarries > 0 && V(t) <= 9 ? 1.5 : 0);
	}
	if (n === "builder") {
		let n = [...Qt(e, t).ids].find((e) => !t.buildings.some((t) => t.id === e));
		if (n) {
			let e = Fe(t, n, r) - t.money;
			return e <= 0 ? Zt(t, n) * .9 : e <= 3 ? Zt(t, n) * .4 : -e * .8;
		}
		return $t(e, t, r);
	}
	if (n === "craftsman") {
		let n = Le(t, e.goodsSupply), i = 0;
		for (let e of x) i += n[e] * Bt[e];
		let a = x.reduce((t, r) => t + Math.max(0, n[r] - e.goodsSupply[r]), 0);
		return i + (r ? 1.2 + a * .4 : 0);
	}
	if (n === "trader") {
		let n = x.filter((n) => t.goods[n] > 0 && (!e.tradingHouse.includes(n) || R(t, "office")));
		return n.length ? Math.max(...n.map((e) => zt[e] + Number(r) * (1 + Number(R(t, "library"))))) + (Number(R(t, "smallMarket")) + 2 * Number(R(t, "largeMarket"))) + (r ? .8 : 0) : 0;
	}
	return n === "captain" ? en(e, t) + (r ? 1 + Number(R(t, "library")) : 0) : n === "prospector" || n === "prospector2" ? 1 + Number(R(t, "library")) : n === "buccaneer" ? Math.max(e.tradingHouse.length * 1.5, ...e.ships.map((e) => Math.min(3, e.count) * 1.2), 2) : 0;
}
function nn(e, t, n) {
	let r = (e.roles.find((e) => e.id === n)?.coins ?? 0) * 1.2;
	if (n === "mayor" && (r += Math.max(0, xe(t) - z(t)) * 1.5 + (t.unemployed > 0 ? 3 : 0)), n === "settler" && (r += t.plantations.length < 12 ? t.plantations.length < 5 ? 4 : 1.5 : -4), n === "builder") {
		let n = [...Qt(e, t).ids].find((e) => !t.buildings.some((t) => t.id === e));
		r += n ? Fe(t, n, !1) <= t.money ? Zt(t, n) * .65 : -2 : 0;
	}
	return n === "craftsman" && (r += C(Le(t, e.goodsSupply)) * 1.4 - C(t.goods) * .6), n === "trader" && (r += e.tradingHouse.length < 4 ? Math.max(0, ...x.filter((n) => t.goods[n] > 0 && (!e.tradingHouse.includes(n) || R(t, "office"))).map((e) => (x.indexOf(e) + 1) * 1.5)) : -2), n === "captain" && (r += C(t.goods) * (R(t, "harbor") ? 2 : 1.4) - 1), (n === "prospector" || n === "prospector2") && (r += 1.5), n === "buccaneer" && (r += Math.max(e.tradingHouse.length * 1.2, ...e.ships.map((e) => Math.min(3, e.count)), 2)), r;
}
function rn(e, t, n) {
	let r = nn(e, t, n), i = tn(e, t, n, !0), a = e.players.filter((e) => e.rid !== t.rid).map((t) => tn(e, t, n, !1)), o = a.length ? a.reduce((e, t) => e + t, 0) / a.length : 0;
	return r + Ht * (i - o) - Ht * .5 * o;
}
var an = [
	"villa",
	"jeweler",
	"chapel",
	"royalSupplier",
	"districtOffice",
	"royalGarden",
	"hospice",
	"university",
	"library",
	"guesthouse",
	"harbor",
	"wharf",
	"church",
	"unionHall",
	"factory",
	"smallMarket",
	"largeMarket",
	"constructionHut"
];
function on(e) {
	let t = e.plantations.map(() => 0), n = e.buildings.map(() => 0), r = z(e), i = (e) => {
		t[e]++, r--;
	}, a = (e) => {
		n[e]++, r--;
	};
	(() => {
		for (let t of an) {
			let i = e.buildings.findIndex((e) => e.id === t);
			i >= 0 && r > 2 && n[i] === 0 && a(i);
		}
	})();
	for (let t = 0; t < e.plantations.length && r > 0; t++) e.plantations[t].kind === "corn" && i(t);
	let o = e.plantations.map((e, t) => ({
		...e,
		i: t
	})).filter((e) => e.kind === "quarry");
	if (V(e) < 10) for (let e of o.slice(0, 2)) r > 0 && i(e.i);
	for (let t of [...x].reverse()) {
		if (t === "corn") continue;
		let o = e.plantations.map((e, t) => ({
			...e,
			i: t
		})).filter((e) => e.kind === t), s = e.buildings.map((e, t) => ({
			...e,
			i: t
		})).filter((e) => D[e.id].produces === t);
		for (let e of o) {
			let t = s.find((e) => n[e.i] < D[e.id].slots);
			if (r < 2 || !t) break;
			i(e.i), a(t.i);
		}
	}
	for (let t = 0; t < e.buildings.length && r > 0; t++) !D[e.buildings[t].id].produces && D[e.buildings[t].id].slots > 0 && n[t] === 0 && a(t);
	for (let n = 0; n < e.plantations.length && r > 0; n++) e.plantations[n].kind !== "forest" && t[n] === 0 && i(n);
	for (let t = 0; t < e.buildings.length && r > 0; t++) for (; n[t] < D[e.buildings[t].id].slots && r > 0;) a(t);
	let s = t.map(() => 0), c = n.map(() => 0), l = B(e), u = e.buildings.map((e, t) => ({
		b: e,
		i: t
	})).sort((e, t) => Number(t.b.id === "chapel" || t.b.id === "huntingLodge" || t.b.id === "landOffice") - Number(e.b.id === "chapel" || e.b.id === "huntingLodge" || e.b.id === "landOffice"));
	for (let { i: e } of u) c[e] = Math.min(l, n[e]), l -= c[e];
	for (let e = 0; e < t.length; e++) s[e] = Math.min(l, t[e]), l -= s[e];
	return {
		type: "assign",
		plantations: t,
		buildings: n,
		noblePlantations: s,
		nobleBuildings: c
	};
}
function sn(e) {
	let t = S(), n = Number(R(e, "smallWarehouse")) + 2 * Number(R(e, "largeWarehouse")), r = [...x].sort((t, n) => e.goods[n] - e.goods[t] || Bt[n] - Bt[t]);
	r.slice(0, n).forEach((n) => {
		t[n] = e.goods[n];
	});
	let i = 1 + 3 * Number(R(e, "storehouse"));
	for (let a of r.slice(n)) t[a] = Math.min(e.goods[a], i), i -= t[a];
	return t;
}
var cn = (e) => [...e.trades.map((e) => ({
	good: e,
	privateSale: !1
})), ...e.privateTrades.map((e) => ({
	good: e,
	privateSale: !0
}))];
function ln(e, t) {
	return t.privateSale ? zt[t.good] * .5 : zt[t.good] + Number(R(e, "smallMarket")) + 2 * Number(R(e, "largeMarket"));
}
function un(e, t) {
	return e + (t ? -.2 : 0);
}
function dn(e, t) {
	let n = e.public, r = e.private;
	if (n.turn !== t.rid || !r || n.phase === "done") return null;
	let i = n.players.find((e) => e.rid === t.rid), a = r.choices, o = (e, n) => {
		if (t.difficulty === "weak") {
			let t = Math.floor(4294967296 / e.length) * e.length, n;
			do
				n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
			while (n >= t);
			return e[n % e.length];
		}
		return e.reduce((e, t) => n(t) > n(e) ? t : e);
	};
	if (n.phase === "draft") return { action: {
		type: "draft",
		building: o(a.draft, (e) => Vt[e])
	} };
	if (n.phase === "buccaneer") {
		let e = [
			{
				action: { type: "plunder" },
				value: n.tradingHouse.length * 1.5
			},
			...a.piracy.map((e) => ({
				action: {
					type: "piracy",
					ship: e,
					keep: Math.min(3, n.ships[e].count)
				},
				value: Math.min(3, n.ships[e].count) * 1.2
			})),
			...a.kidnap.map((e) => ({
				action: {
					type: "kidnap",
					role: e
				},
				value: rn(n, i, e) * .5 + (n.roles.find((t) => t.id === e)?.coins ?? 0)
			}))
		];
		if (a.raid && a.raid.max > 0) {
			let t = [], r = n.recruitmentNobles - a.raid.minLeaveNobles, o = n.recruitment - n.players.length - r, s = [...i.buildings.flatMap((e, t) => Array.from({ length: D[e.id].slots - e.workers }, () => ({
				kind: "building",
				index: t
			}))), ...i.plantations.flatMap((e, t) => e.kind !== "forest" && !e.workers ? [{
				kind: "plantation",
				index: t
			}] : [])];
			for (let e of s.slice(0, a.raid.max)) r > 0 ? (t.push({
				...e,
				noble: !0
			}), r--) : o > 0 && (t.push(e), o--);
			e.push({
				action: {
					type: "raid",
					leaveNobles: a.raid.minLeaveNobles,
					placements: t
				},
				value: t.length * 2
			});
		}
		return { action: o(e, (e) => e.value).action };
	}
	if (n.phase === "recruit") return { action: {
		type: "recruit",
		noble: a.recruit.includes(!0)
	} };
	if (n.phase === "royalSupplier") {
		let e = S(), t = a.royalSupply;
		for (let n of [...x].sort((e, t) => Bt[e] - Bt[t])) t > 0 && i.goods[n] > 0 && (e[n] = 1, t--);
		return { action: {
			type: "royalSupply",
			goods: e
		} };
	}
	if (a.buyLand && i.plantations.length < 8) return { action: { type: "buyLand" } };
	if ((n.phase === "landOffice" || n.phase === "hunting") && a.removePlantations.length) {
		let e = o(a.removePlantations, (e) => Number(i.plantations[e].workers === 0) * 10 + Number(i.plantations[e].kind !== "corn"));
		if (i.plantations[e].workers === 0) return { action: {
			type: "removePlantation",
			index: e
		} };
	}
	if (n.phase === "guesthouse") return a.guestTargets.length ? { action: {
		type: "guest",
		target: o(a.guestTargets, (e) => e.kind === "building" ? Vt[i.buildings[e.index].id] + Number(i.buildings[e.index].workers === 0) * 3 : 4)
	} } : { action: { type: "pass" } };
	if (n.phase === "forest") return { action: {
		type: "placeDrawn",
		forest: a.forest && !i.buildings.some((e) => D[e.id].produces === a.drawnGood)
	} };
	if (n.phase === "role") return { action: {
		type: "role",
		role: o(a.roles, (e) => rn(n, i, e))
	} };
	if (n.phase === "mayor") return { action: on(i) };
	if (n.phase === "craftsman") return { action: {
		type: "produce",
		goods: a.production
	} };
	if (n.phase === "storage") return { action: {
		type: "store",
		goods: sn(i)
	} };
	if (n.phase === "bonus" && a.bonus.length) return { action: {
		type: "bonus",
		good: o(a.bonus, (e) => x.indexOf(e))
	} };
	if (n.phase === "builder" && a.buildings.length) {
		let e = Qt(n, i).ids, t = o(a.buildings, (t) => Xt(i, t.id, e) - t.cost * .2);
		return { action: {
			type: "build",
			building: t.id,
			university: a.university,
			noble: !a.placementPeople.includes(!1) && a.placementPeople.includes(!0),
			payment: Ie(i, t.id, n.selector === i.rid, n.vp[i.rid] ?? 0)[0]
		} };
	}
	if (n.phase === "settler" || n.phase === "settlerExtra") {
		if (a.hacienda && i.plantations.length < 9) return { action: { type: "hacienda" } };
		let e = [...a.plantations, ...a.quarry ? [-1] : []];
		if (e.length) {
			let t = o(e, (e) => Yt(i, e === -1 ? "quarry" : n.plantations[e])), r = t >= 0 && a.forest && o([!1, !0], (e) => e && i.plantations.filter((e) => e.kind === "forest").length < 6 && Yt(i, n.plantations[t]) < 2.2 ? 1 : 0);
			return { action: {
				type: "plant",
				index: t,
				hospice: a.hospice,
				forest: r,
				noble: !a.placementPeople.includes(!1) && a.placementPeople.includes(!0)
			} };
		}
	}
	if (n.phase === "trader") {
		let e = cn(a);
		if (e.length) return { action: {
			type: "trade",
			...o(e, (e) => ln(i, e))
		} };
	}
	if (n.phase === "captain" && a.ships.length) {
		let e = o(a.ships, (e) => un(e.count, e.ship === -1));
		return { action: {
			type: "ship",
			good: e.good,
			ship: e.ship
		} };
	}
	return n.phase === "captain" && a.smallWharf ? { action: {
		type: "smallWharf",
		goods: i.goods
	} } : a.canPass ? { action: { type: "pass" } } : null;
}
var fn = {
	enabled: 1,
	budgetMs: 400,
	samples: 8,
	maxSteps: 140,
	rounds: 1,
	shortlist: 4
}, pn = (e, t) => {
	let n = dn(e, t), r = e.private;
	if (!fn.enabled || t.difficulty === "weak" || !r || e.public.phase !== "role" || e.public.turn !== t.rid) return n;
	let i = e.public, a = i.players.find((e) => e.rid === t.rid), o;
	if (i.phase === "role") o = r.choices.roles.map((e) => ({
		action: {
			type: "role",
			role: e
		},
		value: rn(i, a, e)
	}));
	else if (i.phase === "captain" && !r.choices.smallWharf && r.choices.ships.length + Number(r.choices.canPass) > 1) o = r.choices.ships.map((e) => ({
		action: {
			type: "ship",
			good: e.good,
			ship: e.ship
		},
		value: un(e.count, e.ship === -1)
	})), r.choices.canPass && o.push({
		action: { type: "pass" },
		value: 0
	});
	else return n;
	let s = o.sort((e, t) => t.value - e.value).slice(0, Math.max(2, fn.shortlist)).map((e) => e.action);
	if (s.length < 2) return n;
	let c = Rt(Ft(i, r), t.rid, s, (e, n) => dn(n, {
		...t,
		rid: n.public.turn ?? t.rid
	})?.action ?? null, {
		budgetMs: fn.budgetMs,
		samples: fn.samples,
		maxSteps: fn.maxSteps,
		rounds: fn.rounds
	});
	return c ? { action: c } : n;
}, Q = {
	forest: "games.puertorico.good.forest",
	corn: "games.puertorico.good.corn",
	indigo: "games.puertorico.good.indigo",
	sugar: "games.puertorico.good.sugar",
	tobacco: "games.puertorico.good.tobacco",
	coffee: "games.puertorico.good.coffee",
	quarry: "games.puertorico.good.quarry"
}, mn = {
	buccaneer: "games.puertorico.role.buccaneer",
	settler: "games.puertorico.role.settler",
	builder: "games.puertorico.role.builder",
	mayor: "games.puertorico.role.mayor",
	craftsman: "games.puertorico.role.craftsman",
	trader: "games.puertorico.role.trader",
	captain: "games.puertorico.role.captain",
	prospector: "games.puertorico.role.prospector",
	prospector2: "games.puertorico.role.prospector"
}, hn = {
	buccaneer: "games.puertorico.roleHelp.buccaneer",
	settler: "games.puertorico.roleHelp.settler",
	builder: "games.puertorico.roleHelp.builder",
	mayor: "games.puertorico.roleHelp.mayor",
	craftsman: "games.puertorico.roleHelp.craftsman",
	trader: "games.puertorico.roleHelp.trader",
	captain: "games.puertorico.roleHelp.captain",
	prospector: "games.puertorico.roleHelp.prospector",
	prospector2: "games.puertorico.roleHelp.prospector"
}, gn = {
	buccaneer: "games.puertorico.buccaneerPrompt",
	recruit: "games.puertorico.recruitPrompt",
	landOffice: "games.puertorico.landPrompt",
	hunting: "games.puertorico.huntingPrompt",
	royalSupplier: "games.puertorico.royalPrompt",
	draft: "games.puertorico.draftPrompt",
	forest: "games.puertorico.forestPrompt",
	guesthouse: "games.puertorico.guestPrompt",
	settlerExtra: "games.puertorico.extraSettler",
	role: "games.puertorico.selectRole",
	settler: "games.puertorico.selectPlant",
	builder: "games.puertorico.selectBuilding",
	mayor: "games.puertorico.assignWorkers",
	craftsman: "games.puertorico.produceGoods",
	bonus: "games.puertorico.selectBonus",
	trader: "games.puertorico.tradeGoods",
	captain: "games.puertorico.shipGoods",
	storage: "games.puertorico.storeGoods",
	done: "games.puertorico.done"
}, $ = {
	districtOffice: {
		name: "games.puertorico.building.districtOffice",
		text: "games.puertorico.buildingText.districtOffice"
	},
	royalSupplier: {
		name: "games.puertorico.building.royalSupplier",
		text: "games.puertorico.buildingText.royalSupplier"
	},
	chapel: {
		name: "games.puertorico.building.chapel",
		text: "games.puertorico.buildingText.chapel"
	},
	jeweler: {
		name: "games.puertorico.building.jeweler",
		text: "games.puertorico.buildingText.jeweler"
	},
	villa: {
		name: "games.puertorico.building.villa",
		text: "games.puertorico.buildingText.villa"
	},
	huntingLodge: {
		name: "games.puertorico.building.huntingLodge",
		text: "games.puertorico.buildingText.huntingLodge"
	},
	landOffice: {
		name: "games.puertorico.building.landOffice",
		text: "games.puertorico.buildingText.landOffice"
	},
	royalGarden: {
		name: "games.puertorico.building.royalGarden",
		text: "games.puertorico.buildingText.royalGarden"
	},
	blackMarket: {
		name: "games.puertorico.building.blackMarket",
		text: "games.puertorico.buildingText.blackMarket"
	},
	forestHouse: {
		name: "games.puertorico.building.forestHouse",
		text: "games.puertorico.buildingText.forestHouse"
	},
	aqueduct: {
		name: "games.puertorico.building.aqueduct",
		text: "games.puertorico.buildingText.aqueduct"
	},
	storehouse: {
		name: "games.puertorico.building.storehouse",
		text: "games.puertorico.buildingText.storehouse"
	},
	guesthouse: {
		name: "games.puertorico.building.guesthouse",
		text: "games.puertorico.buildingText.guesthouse"
	},
	church: {
		name: "games.puertorico.building.church",
		text: "games.puertorico.buildingText.church"
	},
	tradingPost: {
		name: "games.puertorico.building.tradingPost",
		text: "games.puertorico.buildingText.tradingPost"
	},
	smallWharf: {
		name: "games.puertorico.building.smallWharf",
		text: "games.puertorico.buildingText.smallWharf"
	},
	lighthouse: {
		name: "games.puertorico.building.lighthouse",
		text: "games.puertorico.buildingText.lighthouse"
	},
	specialtyFactory: {
		name: "games.puertorico.building.specialtyFactory",
		text: "games.puertorico.buildingText.specialtyFactory"
	},
	library: {
		name: "games.puertorico.building.library",
		text: "games.puertorico.buildingText.library"
	},
	unionHall: {
		name: "games.puertorico.building.unionHall",
		text: "games.puertorico.buildingText.unionHall"
	},
	cloister: {
		name: "games.puertorico.building.cloister",
		text: "games.puertorico.buildingText.cloister"
	},
	statue: {
		name: "games.puertorico.building.statue",
		text: "games.puertorico.buildingText.statue"
	},
	smallIndigo: {
		name: "games.puertorico.building.smallIndigo",
		text: "games.puertorico.buildingText.smallIndigo"
	},
	smallSugar: {
		name: "games.puertorico.building.smallSugar",
		text: "games.puertorico.buildingText.smallSugar"
	},
	indigoPlant: {
		name: "games.puertorico.building.indigoPlant",
		text: "games.puertorico.buildingText.indigoPlant"
	},
	sugarMill: {
		name: "games.puertorico.building.sugarMill",
		text: "games.puertorico.buildingText.sugarMill"
	},
	tobaccoStorage: {
		name: "games.puertorico.building.tobaccoStorage",
		text: "games.puertorico.buildingText.tobaccoStorage"
	},
	coffeeRoaster: {
		name: "games.puertorico.building.coffeeRoaster",
		text: "games.puertorico.buildingText.coffeeRoaster"
	},
	smallMarket: {
		name: "games.puertorico.building.smallMarket",
		text: "games.puertorico.buildingText.smallMarket"
	},
	hacienda: {
		name: "games.puertorico.building.hacienda",
		text: "games.puertorico.buildingText.hacienda"
	},
	constructionHut: {
		name: "games.puertorico.building.constructionHut",
		text: "games.puertorico.buildingText.constructionHut"
	},
	smallWarehouse: {
		name: "games.puertorico.building.smallWarehouse",
		text: "games.puertorico.buildingText.smallWarehouse"
	},
	hospice: {
		name: "games.puertorico.building.hospice",
		text: "games.puertorico.buildingText.hospice"
	},
	office: {
		name: "games.puertorico.building.office",
		text: "games.puertorico.buildingText.office"
	},
	largeMarket: {
		name: "games.puertorico.building.largeMarket",
		text: "games.puertorico.buildingText.largeMarket"
	},
	largeWarehouse: {
		name: "games.puertorico.building.largeWarehouse",
		text: "games.puertorico.buildingText.largeWarehouse"
	},
	factory: {
		name: "games.puertorico.building.factory",
		text: "games.puertorico.buildingText.factory"
	},
	university: {
		name: "games.puertorico.building.university",
		text: "games.puertorico.buildingText.university"
	},
	harbor: {
		name: "games.puertorico.building.harbor",
		text: "games.puertorico.buildingText.harbor"
	},
	wharf: {
		name: "games.puertorico.building.wharf",
		text: "games.puertorico.buildingText.wharf"
	},
	guildHall: {
		name: "games.puertorico.building.guildHall",
		text: "games.puertorico.buildingText.guildHall"
	},
	residence: {
		name: "games.puertorico.building.residence",
		text: "games.puertorico.buildingText.residence"
	},
	fortress: {
		name: "games.puertorico.building.fortress",
		text: "games.puertorico.buildingText.fortress"
	},
	customsHouse: {
		name: "games.puertorico.building.customsHouse",
		text: "games.puertorico.buildingText.customsHouse"
	},
	cityHall: {
		name: "games.puertorico.building.cityHall",
		text: "games.puertorico.buildingText.cityHall"
	}
}, _n = {
	piracy: "games.puertorico.event.piracy",
	plunder: "games.puertorico.event.plunder",
	raid: "games.puertorico.event.raid",
	kidnap: "games.puertorico.event.kidnap",
	ransom: "games.puertorico.event.ransom",
	festivalPlantation: "games.puertorico.event.festivalPlantation",
	festivalProduction: "games.puertorico.event.festivalProduction",
	festivalBuilding: "games.puertorico.event.festivalBuilding",
	recruit: "games.puertorico.event.recruit",
	removePlantation: "games.puertorico.event.removePlantation",
	buyLand: "games.puertorico.event.buyLand",
	royalSupply: "games.puertorico.event.royalSupply",
	mixedShip: "games.puertorico.event.mixedShip",
	draft: "games.puertorico.event.draft",
	guest: "games.puertorico.event.guest",
	role: "games.puertorico.event.role",
	plant: "games.puertorico.event.plant",
	build: "games.puertorico.event.build",
	assign: "games.puertorico.event.assign",
	produce: "games.puertorico.event.produce",
	trade: "games.puertorico.event.trade",
	ship: "games.puertorico.event.ship",
	store: "games.puertorico.event.store"
};
//#endregion
//#region src/games/puertorico/expansion-panels.tsx
function vn({ pub: e, choices: t, raiding: n, leaveNobles: r, onRaid: i, onLeaveNobles: a, act: o }) {
	let c = l(), [u, d] = s(3);
	return /* @__PURE__ */ _("div", {
		className: "pr-expansion-actions",
		children: n ? /* @__PURE__ */ v(g, { children: [t.raid && t.raid.maxLeaveNobles > t.raid.minLeaveNobles && /* @__PURE__ */ v("label", {
			className: "pr-check",
			children: [c("games.puertorico.leaveNobles"), /* @__PURE__ */ _("select", {
				value: r,
				onChange: (e) => a(Number(e.target.value)),
				children: Array.from({ length: t.raid.maxLeaveNobles - t.raid.minLeaveNobles + 1 }, (e, n) => t.raid.minLeaveNobles + n).map((e) => /* @__PURE__ */ _("option", {
					value: e,
					children: e
				}, e))
			})]
		}), /* @__PURE__ */ _("button", {
			className: "btn-quiet",
			onClick: () => i(!1),
			children: c("games.puertorico.cancelRaid")
		})] }) : /* @__PURE__ */ v(g, { children: [
			t.piracy.length > 0 && /* @__PURE__ */ v("label", {
				className: "pr-check",
				children: [c("games.puertorico.piracyKeep"), /* @__PURE__ */ _("select", {
					value: u,
					onChange: (e) => d(Number(e.target.value)),
					children: [
						0,
						1,
						2,
						3
					].map((e) => /* @__PURE__ */ _("option", {
						value: e,
						children: e
					}, e))
				})]
			}),
			t.piracy.map((t) => /* @__PURE__ */ v("button", {
				className: "pr-load",
				onClick: () => o({
					type: "piracy",
					ship: t,
					keep: Math.min(u, e.ships[t].count)
				}),
				children: [
					c("games.puertorico.piracy", { n: t + 1 }),
					" · ",
					e.ships[t].good && /* @__PURE__ */ _(Z, { good: e.ships[t].good }),
					" ",
					e.ships[t].count
				]
			}, t)),
			t.plunder && /* @__PURE__ */ v("button", {
				className: "pr-load",
				onClick: () => o({ type: "plunder" }),
				children: [
					c("games.puertorico.plunder"),
					" · ",
					e.tradingHouse.length,
					/* @__PURE__ */ _(ht, {})
				]
			}),
			t.raid && /* @__PURE__ */ _("button", {
				className: "pr-load",
				onClick: () => i(!0),
				children: c("games.puertorico.raid")
			}),
			t.kidnap.map((e) => /* @__PURE__ */ v("button", {
				className: "pr-load pr-kidnap",
				onClick: () => o({
					type: "kidnap",
					role: e
				}),
				children: [/* @__PURE__ */ _(Ot, { role: e }), c("games.puertorico.kidnap", { role: c(mn[e]) })]
			}, e))
		] })
	});
}
function yn({ festival: e, names: t }) {
	let n = l(), r = (e, r) => /* @__PURE__ */ v("small", {
		className: e ? "pr-festival-reward pr-festival-complete" : "pr-festival-reward",
		children: [e && /* @__PURE__ */ _(f, { size: 15 }), e ? n("games.puertorico.claimedBy", { name: t(e) }) : r]
	});
	return /* @__PURE__ */ v("section", {
		className: "pr-festival",
		"aria-label": n("games.puertorico.festival"),
		children: [
			/* @__PURE__ */ _("h2", { children: n("games.puertorico.festival") }),
			/* @__PURE__ */ v("div", { children: [
				/* @__PURE__ */ _("strong", { children: n("games.puertorico.festivalPlantation", { good: n(Q[e.plantation.good]) }) }),
				/* @__PURE__ */ v("span", {
					className: "pr-festival-icons",
					children: [/* @__PURE__ */ _(gt, { good: e.plantation.good }), /* @__PURE__ */ _("span", {
						className: "pr-festival-people",
						children: /* @__PURE__ */ _(kt, {
							count: 3,
							capacity: 3
						})
					})]
				}),
				r(e.plantation.claimedBy, n("games.puertorico.festivalWorkers"))
			] }),
			/* @__PURE__ */ v("div", { children: [
				/* @__PURE__ */ _("strong", { children: n("games.puertorico.festivalProduction") }),
				/* @__PURE__ */ v("span", {
					className: "pr-festival-icons",
					children: [x.flatMap((t) => Array.from({ length: e.production.goods[t] }, (e, r) => /* @__PURE__ */ _("span", {
						title: n(Q[t]),
						children: /* @__PURE__ */ _(Z, { good: t })
					}, `${t}${r}`))), /* @__PURE__ */ _(mt, {})]
				}),
				r(e.production.claimedBy, n("games.puertorico.festivalCoins"))
			] }),
			e.building.id && /* @__PURE__ */ v("div", { children: [
				/* @__PURE__ */ v("strong", { children: [
					n("games.puertorico.festivalBuilding"),
					": ",
					n($[e.building.id].name)
				] }),
				/* @__PURE__ */ v("span", {
					className: "pr-festival-icons",
					children: [/* @__PURE__ */ _(Et, { id: e.building.id }), /* @__PURE__ */ _(ht, {})]
				}),
				r(e.building.claimedBy, n("games.puertorico.festivalVP"))
			] })
		]
	});
}
//#endregion
//#region src/games/puertorico/view-player.tsx
function bn(e) {
	let t = e.public, n = e.private, [r, i] = s(e.myRid), a = `${e.myRid}:${t.round}:${t.phase}:${t.turn}:${t.roles.filter((e) => e.pickedBy).length}:${x.map((n) => t.players.find((t) => t.rid === e.myRid)?.goods[n]).join(".")}`;
	return /* @__PURE__ */ _(xn, {
		...e,
		pub: t,
		priv: n,
		viewedRid: r,
		onView: i
	}, a);
}
function xn({ pub: e, priv: t, members: n, myRid: r, send: i, viewedRid: a, onView: o }) {
	let c = l(), u = e.players.find((e) => e.rid === r), d = e.phase !== "done" && e.turn === r && !!t, m = d && (e.phase === "mayor" || e.phase === "guesthouse" || e.phase === "hunting" || e.phase === "landOffice" || e.phase === "buccaneer") ? u : e.players.find((e) => e.rid === a) ?? u, h = (e) => n.find((t) => t.rid === e)?.name ?? "—", y = t?.choices, [b, S] = s({
		type: "assign",
		plantations: u.plantations.map((e) => e.workers),
		buildings: u.buildings.map((e) => e.workers),
		noblePlantations: u.plantations.map((e) => e.nobles ?? 0),
		nobleBuildings: u.buildings.map((e) => e.nobles ?? 0)
	}), [w, ae] = s(e.phase === "storage" ? sn(u) : e.phase === "captain" ? u.goods : y?.production ?? {
		corn: 0,
		indigo: 0,
		sugar: 0,
		tobacco: 0,
		coffee: 0
	}), [T, E] = s(null), [O, se] = s(!0), [ce, le] = s(!1), [k, ue] = s(!1), [A, M] = s(!1), [N, P] = s([]), [F, I] = s(y?.raid?.minLeaveNobles ?? 0), [de, fe] = s(0), [pe, me] = s(!1), he = e.phase === "builder" || e.phase === "draft" ? "market" : [
		"captain",
		"storage",
		"trader",
		"craftsman",
		"bonus",
		"royalSupplier"
	].includes(e.phase) ? "harbor" : [
		"mayor",
		"recruit",
		"guesthouse",
		"hunting",
		"landOffice"
	].includes(e.phase) ? "island" : "roles", [ge, _e] = s(he), [L, ve] = s(null), ye = ge === "island" ? "roles" : ge, R = [...b.plantations, ...b.buildings].reduce((e, t) => e + t, 0), be = Math.min(z(u), xe(u)), H = [...b.noblePlantations ?? [], ...b.nobleBuildings ?? []].reduce((e, t) => e + t, 0), Se = R === be && H <= B(u) && R - H <= z(u) - B(u), U = y?.buildings.find((e) => e.id === T), Ce = U && t ? Ie(u, U.id, e.selector === r, e.vp[r] ?? 0) : [], we = Ce[de] ?? Ce[0], Te = !!y?.placementPeople.includes(!0) && (k || !y.placementPeople.includes(!1)), Ee = !!T && !!y?.draft.includes(T), De = N.filter((e) => e.noble).length, W = e.recruitmentNobles - F, Oe = !!y?.raid && N.length <= y.raid.max && De <= W && N.length - De <= e.recruitment - e.players.length - W, G = (e) => i(e), ke = (e, t) => {
		let n = e === "plantation" ? 1 - u.plantations[t].workers : D[u.buildings[t].id].slots - u.buildings[t].workers;
		P((r) => {
			let i = r.filter((n) => n.kind === e && n.index === t), a = i.filter((e) => !!e.noble === k).length, o = (a + 1) % (n - (i.length - a) + 1);
			return [...r.filter((n) => n.kind !== e || n.index !== t || !!n.noble !== k), ...Array.from({ length: o }, () => ({
				kind: e,
				index: t,
				noble: k
			}))];
		});
	}, Ae = (e, t) => {
		let n = e === "plantations" ? 1 : D[u.buildings[t].id].slots, r = e === "plantations" ? "noblePlantations" : "nobleBuildings";
		S((i) => {
			let a = i[r] ?? i[e].map(() => 0), o = i[e][t] - a[t], s = k ? (a[t] + 1) % (n - o + 1) : (o + 1) % (n - a[t] + 1);
			return {
				...i,
				[e]: i[e].map((e, n) => n === t ? k ? o + s : a[n] + s : e),
				[r]: a.map((e, n) => n === t && k ? s : e)
			};
		});
	}, je = (e = !1) => /* @__PURE__ */ _("div", {
		className: "pr-tabs",
		role: "tablist",
		"aria-label": c("games.puertorico.boardAreas"),
		children: [
			"island",
			"roles",
			"market",
			"harbor"
		].map((t) => /* @__PURE__ */ _("button", {
			role: "tab",
			"aria-selected": ge === t || e && t === "roles" && ge === "island",
			className: `${ge === t ? "pr-tab pr-tab-active" : "pr-tab"}${t === "island" ? " pr-island-tab" : ""}`,
			onClick: () => {
				_e(t), E(null);
			},
			children: c(t === "island" ? "games.puertorico.islandTab" : t === "roles" ? "games.puertorico.rolesTab" : t === "market" ? "games.puertorico.market" : "games.puertorico.harbor")
		}, t))
	}), Me = /* @__PURE__ */ v("div", {
		className: "pr-actions",
		children: [
			/* @__PURE__ */ v("button", {
				className: "btn-quiet pr-log-button",
				"aria-label": c("games.puertorico.log"),
				onClick: () => {
					me(!0), E(null);
				},
				children: [/* @__PURE__ */ _(ee, { size: 20 }), /* @__PURE__ */ _("span", { children: c("games.puertorico.log") })]
			}),
			L && d && e.phase === "captain" && /* @__PURE__ */ v("span", {
				className: "pr-shipment-summary",
				children: [/* @__PURE__ */ _(Z, { good: L.good }), c("games.puertorico.load", {
					good: c(Q[L.good]),
					n: L.count
				})]
			}),
			/* @__PURE__ */ _("div", {
				className: "pr-decisions",
				children: d ? /* @__PURE__ */ v(g, { children: [
					e.phase === "captain" && /* @__PURE__ */ _("button", {
						className: "btn-base pr-primary",
						disabled: !L,
						onClick: () => L && G({
							type: "ship",
							good: L.good,
							ship: L.ship
						}),
						children: L ? c("games.puertorico.load", {
							good: c(Q[L.good]),
							n: L.count
						}) : c("games.puertorico.shipGoods")
					}),
					e.phase === "mayor" && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
						className: "btn-quiet",
						onClick: () => S(on(u)),
						children: c("games.puertorico.recommend")
					}), /* @__PURE__ */ _("button", {
						className: "btn-base pr-primary",
						disabled: !Se,
						onClick: () => G(b),
						children: c("games.puertorico.assign")
					})] }),
					e.phase === "recruit" && y?.recruit.map((e) => /* @__PURE__ */ _("button", {
						className: "btn-base pr-primary",
						onClick: () => G({
							type: "recruit",
							noble: e
						}),
						children: c(e ? "games.puertorico.takeNoble" : "games.puertorico.takeWorker")
					}, String(e))),
					e.phase === "royalSupplier" && /* @__PURE__ */ _("button", {
						className: "btn-base pr-primary",
						disabled: C(w) > (y?.royalSupply ?? 0),
						onClick: () => G({
							type: "royalSupply",
							goods: w
						}),
						children: c("games.puertorico.supplyRoyal")
					}),
					e.phase === "buccaneer" && A && /* @__PURE__ */ _("button", {
						className: "btn-base pr-primary",
						disabled: !Oe,
						onClick: () => G({
							type: "raid",
							leaveNobles: F,
							placements: N
						}),
						children: c("games.puertorico.confirmRaid")
					}),
					y?.buyLand && /* @__PURE__ */ _("button", {
						className: "btn-quiet",
						onClick: () => G({ type: "buyLand" }),
						children: c("games.puertorico.buyLand")
					}),
					e.phase === "craftsman" && /* @__PURE__ */ _("button", {
						className: "btn-base pr-primary",
						onClick: () => G({
							type: "produce",
							goods: w
						}),
						children: c("games.puertorico.produce")
					}),
					e.phase === "storage" && /* @__PURE__ */ _("button", {
						className: "btn-base pr-primary",
						disabled: !ze(u, w),
						onClick: () => G({
							type: "store",
							goods: w
						}),
						children: c("games.puertorico.store")
					}),
					e.phase === "builder" && /* @__PURE__ */ v("button", {
						className: "btn-base pr-primary",
						disabled: !U || !we,
						onClick: () => U && G({
							type: "build",
							building: U.id,
							university: O && !!y?.university,
							noble: Te,
							payment: we
						}),
						children: [c("games.puertorico.build"), U ? ` · ${c("games.puertorico.cost", { n: Math.min(u.money, U.cost) })}` : ""]
					}),
					e.phase === "draft" && /* @__PURE__ */ _("button", {
						className: "btn-base pr-primary",
						disabled: !Ee,
						onClick: () => T && G({
							type: "draft",
							building: T
						}),
						children: c("games.puertorico.draftBuilding")
					}),
					e.phase === "captain" && y?.smallWharf && /* @__PURE__ */ _("button", {
						className: "btn-base pr-primary",
						disabled: C(w) === 0,
						onClick: () => G({
							type: "smallWharf",
							goods: w
						}),
						children: c("games.puertorico.useSmallWharf")
					}),
					y?.canPass && /* @__PURE__ */ _("button", {
						className: "btn-quiet",
						onClick: () => G({ type: "pass" }),
						children: c(e.phase === "guesthouse" ? "games.puertorico.continuePhase" : e.phase === "captain" ? "games.puertorico.skipWharf" : "games.puertorico.pass")
					}),
					![
						"mayor",
						"craftsman",
						"storage",
						"builder",
						"draft",
						"recruit",
						"captain"
					].includes(e.phase) && !y?.canPass && /* @__PURE__ */ _("span", { children: c(gn[e.phase]) })
				] }) : /* @__PURE__ */ _("span", { children: c("games.puertorico.wait", { name: h(e.turn) }) })
			})
		]
	}), Ne = T ? /* @__PURE__ */ v("div", {
		className: "pr-inspect pointer-events-auto",
		role: "region",
		"aria-label": c($[T].name),
		children: [
			/* @__PURE__ */ v("div", {
				className: "pr-row",
				children: [/* @__PURE__ */ _("strong", { children: c($[T].name) }), /* @__PURE__ */ _("button", {
					className: "btn-quiet",
					onClick: () => E(null),
					"aria-label": c("games.puertorico.close"),
					children: /* @__PURE__ */ _(p, { size: 20 })
				})]
			}),
			/* @__PURE__ */ _("p", { children: c($[T].text) }),
			/* @__PURE__ */ v("div", {
				className: "pr-row",
				children: [/* @__PURE__ */ _("span", { children: c("games.puertorico.cost", { n: U?.cost ?? D[T].cost }) }), /* @__PURE__ */ _("span", { children: c("games.puertorico.points", { n: D[T].vp }) })]
			}),
			U && U.cost > u.money && /* @__PURE__ */ v("label", {
				className: "pr-check",
				children: [c("games.puertorico.blackMarketPayment"), /* @__PURE__ */ _("select", {
					value: de,
					onChange: (e) => fe(Number(e.target.value)),
					children: Ce.map((e, t) => {
						let n = e.worker, r = n?.kind === "building" ? c($[u.buildings[n.index].id].name) : n?.kind === "plantation" ? c(Q[u.plantations[n.index].kind]) : c("games.puertorico.unemployed"), i = [
							n ? c(n.noble ? "games.puertorico.returnNoble" : "games.puertorico.returnWorker", { place: r }) : "",
							e.good ? c("games.puertorico.returnGood", { good: c(Q[e.good]) }) : "",
							e.vp ? c("games.puertorico.returnVP") : ""
						].filter(Boolean);
						return /* @__PURE__ */ _("option", {
							value: t,
							children: i.join(" + ")
						}, t);
					})
				})]
			})
		]
	}) : pe ? /* @__PURE__ */ v("div", {
		className: "pr-inspect pr-log pointer-events-auto",
		role: "region",
		"aria-label": c("games.puertorico.log"),
		children: [/* @__PURE__ */ v("div", {
			className: "pr-row",
			children: [/* @__PURE__ */ _("strong", { children: c("games.puertorico.log") }), /* @__PURE__ */ _("button", {
				className: "btn-quiet",
				onClick: () => me(!1),
				"aria-label": c("games.puertorico.close"),
				children: /* @__PURE__ */ _(p, { size: 20 })
			})]
		}), /* @__PURE__ */ _("ol", { children: e.log.map((e, t) => /* @__PURE__ */ _("li", { children: c(_n[e.event], {
			name: h(e.rid),
			n: e.n ?? 0,
			item: e.building ? c($[e.building].name) : e.good ? c(Q[e.good]) : e.role ? c(mn[e.role]) : ""
		}) }, t)) })]
	}) : void 0;
	return /* @__PURE__ */ v(ne, {
		adaptive: !0,
		scroll: !1,
		className: "pr-screen",
		actionsHeight: "pr-actions-height",
		actions: Me,
		overlay: Ne,
		banner: /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _(re, {
				tone: d ? "accent" : "info",
				accent: j.accent,
				text: d ? c(gn[e.phase]) : c("games.puertorico.wait", { name: h(e.turn) }),
				chip: c("games.puertorico.round", { n: e.round })
			}),
			/* @__PURE__ */ _(ie, {
				adaptive: !0,
				members: n,
				myRid: r,
				variant: "mini",
				scroll: !0,
				onPick: (e) => {
					o(e), _e("island");
				},
				picked: (e) => e === m.rid,
				action: (t) => t === e.turn ? "pending" : e.roles.some((e) => e.pickedBy === t) ? "done" : null,
				status: (t) => /* @__PURE__ */ v("span", {
					className: "pr-player-money",
					children: [
						t === e.governor ? "👑 " : "",
						/* @__PURE__ */ _(mt, {}),
						e.players.find((e) => e.rid === t)?.money ?? 0
					]
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "pr-mobile-goods",
				children: /* @__PURE__ */ _(Sn, { goods: u.goods })
			}),
			/* @__PURE__ */ _("div", {
				className: "pr-mobile-tabs",
				children: je()
			})
		] }),
		children: [/* @__PURE__ */ _(te, {
			className: "pr-table-texture",
			kind: "sheen",
			base: "#f7f0df"
		}), /* @__PURE__ */ v("div", {
			className: "pr-table",
			"data-panel": ge,
			children: [/* @__PURE__ */ _("section", {
				className: "pr-island",
				"aria-label": c("games.puertorico.island", { name: h(m.rid) }),
				children: /* @__PURE__ */ v("div", {
					className: "pr-island-content",
					children: [
						/* @__PURE__ */ _(dt, {}),
						/* @__PURE__ */ v("div", {
							className: "pr-row pr-island-title",
							children: [/* @__PURE__ */ _("strong", { children: c("games.puertorico.island", { name: h(m.rid) }) }), /* @__PURE__ */ v("span", {
								className: "pr-island-totals",
								children: [/* @__PURE__ */ v("span", {
									"aria-label": `${c("games.puertorico.money")}: ${m.money}`,
									children: [/* @__PURE__ */ _(mt, {}), m.money]
								}), /* @__PURE__ */ v("span", {
									"aria-label": `${c("games.puertorico.vp")}: ${e.vp[m.rid] ?? 0}`,
									children: [/* @__PURE__ */ _(ht, {}), e.vp[m.rid] ?? 0]
								})]
							})]
						}),
						d && e.phase === "buccaneer" && A && y && /* @__PURE__ */ _(vn, {
							pub: e,
							choices: y,
							raiding: A,
							leaveNobles: F,
							onRaid: (e) => {
								M(e), P([]), _e("roles");
							},
							onLeaveNobles: I,
							act: G
						}),
						/* @__PURE__ */ v("h2", { children: [
							c("games.puertorico.plantations"),
							" ",
							/* @__PURE__ */ v("span", { children: [m.plantations.length, "/12"] })
						] }),
						d && e.config.nobles && (e.phase === "mayor" || e.phase === "guesthouse" || e.phase === "buccaneer" && A) && /* @__PURE__ */ v("label", {
							className: "pr-check",
							children: [/* @__PURE__ */ _("input", {
								type: "checkbox",
								checked: k,
								onChange: (e) => ue(e.target.checked)
							}), c("games.puertorico.assignNobles")]
						}),
						d && e.phase === "buccaneer" && A && /* @__PURE__ */ _("div", {
							className: "pr-row",
							children: c("games.puertorico.raidPlaced", {
								n: N.length,
								max: y?.raid?.max ?? 0
							})
						}),
						/* @__PURE__ */ v("div", {
							className: "pr-fields",
							children: [m.plantations.map((t, n) => {
								let i = d && e.phase === "mayor" && m.rid === r && t.kind !== "forest", a = d && e.phase === "guesthouse" && y?.guestTargets.find((e) => e.kind === "plantation" && e.index === n && !!e.noble === k), o = d && m.rid === r && y?.removePlantations.includes(n), s = d && e.phase === "buccaneer" && A && t.kind !== "forest" && t.workers < 1, l = s ? N.filter((e) => e.kind === "plantation" && e.index === n) : [], u = i ? b.plantations[n] : t.workers + l.length, f = i ? b.noblePlantations?.[n] ?? 0 : (t.nobles ?? 0) + l.filter((e) => e.noble).length;
								return /* @__PURE__ */ v("button", {
									className: a || o || s ? "pr-field pr-guest-target" : "pr-field",
									style: At(t.kind),
									"aria-label": `${c(Q[t.kind])}, ${c("games.puertorico.workers", {
										n: u,
										max: t.kind === "forest" ? 0 : 1
									})}${f ? `, ${c("games.puertorico.nobleCount", { n: f })}` : ""}`,
									"aria-pressed": i ? u > 0 : void 0,
									disabled: !i && !a && !o && !s,
									onClick: () => s ? ke("plantation", n) : o ? G({
										type: "removePlantation",
										index: n
									}) : a ? G({
										type: "guest",
										target: a
									}) : Ae("plantations", n),
									children: [
										/* @__PURE__ */ _(gt, { good: t.kind }),
										/* @__PURE__ */ _("span", {
											className: "pr-tile-name",
											children: c(Q[t.kind])
										}),
										/* @__PURE__ */ _(kt, {
											count: u,
											nobles: f,
											capacity: t.kind === "forest" ? 0 : 1
										})
									]
								}, n);
							}), Array.from({ length: 12 - m.plantations.length }, (e, t) => /* @__PURE__ */ _("div", {
								className: "pr-empty",
								"aria-label": c("games.puertorico.emptyField")
							}, `empty${t}`))]
						}),
						/* @__PURE__ */ v("h2", { children: [
							c("games.puertorico.city"),
							" ",
							/* @__PURE__ */ v("span", { children: [V(m), "/12"] })
						] }),
						/* @__PURE__ */ v("div", {
							className: "pr-city",
							children: [m.buildings.map((t, n) => {
								let i = d && e.phase === "mayor" && m.rid === r, a = d && e.phase === "guesthouse" && y?.guestTargets.find((e) => e.kind === "building" && e.index === n && !!e.noble === k), o = D[t.id], s = d && e.phase === "buccaneer" && A && t.workers < o.slots, l = s ? N.filter((e) => e.kind === "building" && e.index === n) : [], u = i ? b.buildings[n] : t.workers + l.length, f = i ? b.nobleBuildings?.[n] ?? 0 : (t.nobles ?? 0) + l.filter((e) => e.noble).length;
								return /* @__PURE__ */ v("button", {
									className: `pr-building${o.size === 2 ? " pr-large" : ""}${a || s ? " pr-guest-target" : ""}`,
									style: o.produces ? At(o.produces) : void 0,
									"aria-label": `${c($[t.id].name)}, ${c("games.puertorico.workers", {
										n: u,
										max: o.slots
									})}${f ? `, ${c("games.puertorico.nobleCount", { n: f })}` : ""}`,
									onClick: () => s ? ke("building", n) : a ? G({
										type: "guest",
										target: a
									}) : i ? Ae("buildings", n) : E(t.id),
									children: [
										/* @__PURE__ */ _(Et, { id: t.id }),
										/* @__PURE__ */ _("span", {
											className: "pr-tile-name",
											children: c($[t.id].name)
										}),
										/* @__PURE__ */ v("span", {
											className: "pr-tile-vp",
											children: [/* @__PURE__ */ _(ht, {}), o.vp]
										}),
										/* @__PURE__ */ _(kt, {
											count: u,
											nobles: f,
											capacity: o.slots
										})
									]
								}, t.id);
							}), Array.from({ length: 12 - V(m) }, (e, t) => /* @__PURE__ */ _("div", {
								className: "pr-empty pr-empty-city",
								"aria-label": c("games.puertorico.emptyCity")
							}, `empty${t}`))]
						}),
						/* @__PURE__ */ v("div", {
							className: "pr-row pr-island-footer",
							children: [/* @__PURE__ */ v("span", { children: [
								c("games.puertorico.unemployed"),
								": ",
								d && e.phase === "mayor" && m.rid === r ? z(m) - R : m.unemployed
							] }), d && e.phase === "mayor" && /* @__PURE__ */ _("span", { children: c("games.puertorico.assignment", {
								n: R,
								max: be
							}) })]
						}),
						/* @__PURE__ */ _(Sn, { goods: m.goods }),
						e.config.nobles && /* @__PURE__ */ v("div", {
							className: "pr-noble-summary",
							children: [/* @__PURE__ */ _("span", { children: c("games.puertorico.nobleCount", { n: B(m) }) }), /* @__PURE__ */ _("span", { children: c("games.puertorico.harborNobles", { n: d && e.phase === "mayor" ? B(u) - H : m.unemployedNobles ?? 0 }) })]
						})
					]
				})
			}), /* @__PURE__ */ v("section", {
				className: "pr-shared",
				children: [
					/* @__PURE__ */ _("div", {
						className: "pr-desktop-tabs",
						children: je(!0)
					}),
					d && e.phase === "buccaneer" && !A && y && /* @__PURE__ */ _(vn, {
						pub: e,
						choices: y,
						raiding: A,
						leaveNobles: F,
						onRaid: (e) => {
							M(e), P([]), _e("island");
						},
						onLeaveNobles: I,
						act: G
					}),
					ye === "roles" && ![
						"settler",
						"settlerExtra",
						"forest"
					].includes(e.phase) && /* @__PURE__ */ _("div", {
						className: "pr-role-grid",
						"data-current": e.phase === "role",
						children: e.roles.map((e) => /* @__PURE__ */ v("button", {
							className: "pr-role",
							disabled: !d || !y?.roles.includes(e.id),
							onClick: () => G({
								type: "role",
								role: e.id
							}),
							children: [
								/* @__PURE__ */ _(Ot, { role: e.id }),
								/* @__PURE__ */ _("strong", { children: c(mn[e.id]) }),
								/* @__PURE__ */ _("span", {
									className: "pr-role-owner",
									children: e.pickedBy ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(f, { size: 15 }), h(e.pickedBy)] }) : /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(mt, {}), e.coins] })
								}),
								/* @__PURE__ */ _("small", { children: c(hn[e.id]) })
							]
						}, e.id))
					}),
					(e.phase === "settler" || e.phase === "settlerExtra") && /* @__PURE__ */ v("div", {
						className: "pr-plant-choices",
						children: [
							/* @__PURE__ */ _("h2", { children: c("games.puertorico.selectPlant") }),
							/* @__PURE__ */ v("div", {
								className: "pr-plant-pool",
								children: [e.plantations.map((e, t) => e ? /* @__PURE__ */ v("button", {
									className: "pr-field",
									style: At(e),
									disabled: !d || !y?.plantations.includes(t),
									onClick: () => G({
										type: "plant",
										index: t,
										hospice: O,
										forest: ce,
										noble: Te
									}),
									"aria-label": c("games.puertorico.take", { good: c(Q[e]) }),
									children: [/* @__PURE__ */ _(gt, { good: e }), /* @__PURE__ */ _("span", {
										className: "pr-tile-name",
										children: c(Q[e])
									})]
								}, t) : /* @__PURE__ */ _("span", { className: "pr-empty" }, t)), /* @__PURE__ */ v("button", {
									className: "pr-field",
									style: At("quarry"),
									disabled: !d || !y?.quarry,
									onClick: () => G({
										type: "plant",
										index: -1,
										hospice: O,
										noble: Te
									}),
									children: [/* @__PURE__ */ _(gt, { good: "quarry" }), /* @__PURE__ */ v("span", {
										className: "pr-tile-name",
										children: [
											c(Q.quarry),
											" · ",
											e.quarries
										]
									})]
								})]
							}),
							d && y?.hospice && /* @__PURE__ */ v("label", {
								className: "pr-check",
								children: [/* @__PURE__ */ _("input", {
									type: "checkbox",
									checked: O,
									onChange: (e) => se(e.target.checked)
								}), c("games.puertorico.useHospice")]
							}),
							d && y?.hospice && y.placementPeople.length === 2 && /* @__PURE__ */ v("label", {
								className: "pr-check",
								children: [/* @__PURE__ */ _("input", {
									type: "checkbox",
									checked: k,
									onChange: (e) => ue(e.target.checked)
								}), c("games.puertorico.assignNobles")]
							}),
							d && y?.forest && /* @__PURE__ */ v("label", {
								className: "pr-check",
								children: [/* @__PURE__ */ _("input", {
									type: "checkbox",
									checked: ce,
									onChange: (e) => le(e.target.checked)
								}), c("games.puertorico.asForest")]
							}),
							d && y?.hacienda && /* @__PURE__ */ _("button", {
								className: "btn-quiet",
								onClick: () => G({ type: "hacienda" }),
								children: c("games.puertorico.useHacienda")
							})
						]
					}),
					d && e.phase === "forest" && y?.drawnGood && /* @__PURE__ */ v("div", {
						className: "pr-plant-choices",
						children: [
							/* @__PURE__ */ _(gt, { good: y.drawnGood }),
							/* @__PURE__ */ _("strong", { children: c(Q[y.drawnGood]) }),
							/* @__PURE__ */ _("button", {
								className: "pr-load",
								onClick: () => G({
									type: "placeDrawn",
									forest: !1
								}),
								children: c("games.puertorico.keepPlantation")
							}),
							y.forest && /* @__PURE__ */ _("button", {
								className: "pr-load",
								onClick: () => G({
									type: "placeDrawn",
									forest: !0
								}),
								children: c("games.puertorico.asForest")
							})
						]
					}),
					ye === "market" && /* @__PURE__ */ v("div", {
						className: "pr-market",
						children: [
							d && y?.university && /* @__PURE__ */ v("label", {
								className: "pr-check",
								children: [/* @__PURE__ */ _("input", {
									type: "checkbox",
									checked: O,
									onChange: (e) => se(e.target.checked)
								}), c("games.puertorico.useUniversity")]
							}),
							d && y?.university && y.placementPeople.length === 2 && /* @__PURE__ */ v("label", {
								className: "pr-check",
								children: [/* @__PURE__ */ _("input", {
									type: "checkbox",
									checked: k,
									onChange: (e) => ue(e.target.checked)
								}), c("games.puertorico.assignNobles")]
							}),
							oe.filter((t) => e.market[t] > 0 || e.players.some((e) => e.buildings.some((e) => e.id === t)) || y?.draft.includes(t)).map((t) => {
								let n = D[t], r = y?.buildings.find((e) => e.id === t), i = d && (e.phase === "builder" && !!r || e.phase === "draft" && y?.draft.includes(t));
								return /* @__PURE__ */ v("button", {
									className: `pr-market-building${T === t ? " pr-selected" : ""}${i ? " pr-available" : ""}`,
									onClick: () => {
										E(t), fe(0);
									},
									"aria-pressed": T === t,
									children: [
										/* @__PURE__ */ _(Et, { id: t }),
										/* @__PURE__ */ _("strong", { children: c($[t].name) }),
										/* @__PURE__ */ v("span", {
											className: "pr-market-values",
											children: [
												/* @__PURE__ */ v("span", { children: [/* @__PURE__ */ _(mt, {}), r?.cost ?? n.cost] }),
												/* @__PURE__ */ v("span", { children: [/* @__PURE__ */ _(ht, {}), n.vp] }),
												/* @__PURE__ */ v("span", {
													"aria-label": c("games.puertorico.stock", { n: e.market[t] }),
													children: ["×", e.market[t]]
												})
											]
										}),
										T === t && /* @__PURE__ */ _(f, {
											className: "pr-selected-mark",
											size: 19
										})
									]
								}, t);
							})
						]
					}),
					ye === "harbor" && /* @__PURE__ */ v("div", {
						className: "pr-port",
						children: [
							/* @__PURE__ */ _("h2", { children: c("games.puertorico.cargoShips") }),
							/* @__PURE__ */ v("div", {
								className: "pr-ships",
								children: [/* @__PURE__ */ _(ft, {}), e.ships.map((e, t) => /* @__PURE__ */ v("div", {
									className: L?.ship === t ? "pr-ship pr-ship-selected" : "pr-ship",
									children: [
										/* @__PURE__ */ v("div", {
											className: "pr-row pr-ship-title",
											children: [/* @__PURE__ */ v("strong", { children: [c("games.puertorico.shipCapacity", { n: e.capacity }), e.good ? ` · ${c(Q[e.good])}` : ""] }), /* @__PURE__ */ v("span", { children: [
												e.count,
												"/",
												e.capacity
											] })]
										}),
										/* @__PURE__ */ _(Dt, {
											...e,
											preview: L?.ship === t ? L : void 0
										}),
										/* @__PURE__ */ _("div", {
											className: "pr-ship-options",
											children: d && y?.ships.filter((e) => e.ship === t).map((e) => /* @__PURE__ */ v("button", {
												className: L?.ship === t && L.good === e.good ? "pr-load pr-load-selected" : "pr-load",
												"aria-pressed": L?.ship === t && L.good === e.good,
												onClick: () => ve(e),
												children: [/* @__PURE__ */ _(Z, {
													good: e.good,
													size: 23
												}), c("games.puertorico.load", {
													good: c(Q[e.good]),
													n: e.count
												})]
											}, e.good))
										})
									]
								}, t))]
							}),
							d && y?.ships.some((e) => e.ship === -1) && /* @__PURE__ */ v("div", {
								className: "pr-private-ship",
								children: [/* @__PURE__ */ _("h2", { children: c("games.puertorico.privateShip") }), y.ships.filter((e) => e.ship === -1).map((e) => /* @__PURE__ */ v("button", {
									className: L?.ship === -1 && L.good === e.good ? "pr-load pr-load-selected" : "pr-load",
									"aria-pressed": L?.ship === -1 && L.good === e.good,
									onClick: () => ve(e),
									children: [/* @__PURE__ */ _(Z, { good: e.good }), c("games.puertorico.load", {
										good: c(Q[e.good]),
										n: e.count
									})]
								}, e.good))]
							}),
							/* @__PURE__ */ _("h2", { children: c("games.puertorico.tradingHouse") }),
							/* @__PURE__ */ _("div", {
								className: "pr-trading",
								children: Array.from({ length: 4 }, (t, n) => /* @__PURE__ */ _("span", {
									className: "pr-trade-slot",
									children: e.tradingHouse[n] && /* @__PURE__ */ _(Z, {
										good: e.tradingHouse[n],
										size: 32
									})
								}, n))
							}),
							d && y?.trades.map((e) => /* @__PURE__ */ v("button", {
								className: "pr-load",
								onClick: () => G({
									type: "trade",
									good: e
								}),
								children: [/* @__PURE__ */ _(Z, { good: e }), c("games.puertorico.sell", { good: c(Q[e]) })]
							}, e)),
							d && y?.privateTrades.map((e) => /* @__PURE__ */ v("button", {
								className: "pr-load",
								onClick: () => G({
									type: "trade",
									good: e,
									privateSale: !0
								}),
								children: [/* @__PURE__ */ _(Z, { good: e }), c("games.puertorico.sellPrivately", { good: c(Q[e]) })]
							}, `private-${e}`)),
							d && y?.bonus.map((e) => /* @__PURE__ */ v("button", {
								className: "pr-load",
								onClick: () => G({
									type: "bonus",
									good: e
								}),
								children: [/* @__PURE__ */ _(Z, { good: e }), c("games.puertorico.take", { good: c(Q[e]) })]
							}, e)),
							d && (e.phase === "royalSupplier" || e.phase === "craftsman" || e.phase === "storage" || e.phase === "captain" && y?.smallWharf) && /* @__PURE__ */ v("div", {
								className: "pr-good-editor",
								children: [/* @__PURE__ */ _("h2", { children: c(e.phase === "royalSupplier" ? "games.puertorico.royalCargo" : e.phase === "craftsman" ? "games.puertorico.production" : e.phase === "captain" ? "games.puertorico.smallWharfCargo" : "games.puertorico.keep") }), x.map((t) => /* @__PURE__ */ _(Cn, {
									good: t,
									value: w[t],
									max: e.phase === "royalSupplier" ? Math.min(1, u.goods[t]) : e.phase === "craftsman" ? y.production[t] : u.goods[t],
									onChange: (e) => ae((n) => ({
										...n,
										[t]: e
									}))
								}, t))]
							}),
							/* @__PURE__ */ _("h2", { children: c("games.puertorico.goodsSupply") }),
							/* @__PURE__ */ _(Sn, { goods: e.goodsSupply })
						]
					}),
					/* @__PURE__ */ v("div", {
						className: "pr-supply",
						children: [
							/* @__PURE__ */ v("span", { children: [
								c("games.puertorico.recruitment"),
								": ",
								e.recruitment
							] }),
							/* @__PURE__ */ v("span", { children: [
								c("games.puertorico.workerSupply"),
								": ",
								e.workerSupply
							] }),
							/* @__PURE__ */ v("span", { children: [
								c("games.puertorico.vpSupply"),
								": ",
								e.vpSupply
							] })
						]
					}),
					e.config.nobles && /* @__PURE__ */ v("div", {
						className: "pr-supply",
						children: [/* @__PURE__ */ _("span", { children: c("games.puertorico.recruitmentNobles", { n: e.recruitmentNobles }) }), /* @__PURE__ */ _("span", { children: c("games.puertorico.nobleSupply", { n: e.nobleSupply }) })]
					}),
					e.buccaneerOwner && /* @__PURE__ */ _("p", { children: c("games.puertorico.pirateToken", { name: h(e.buccaneerOwner) }) }),
					e.kidnapped && /* @__PURE__ */ _("p", { children: c("games.puertorico.kidnapped", {
						name: h(e.kidnapped.rid),
						role: c(mn[e.kidnapped.role])
					}) }),
					e.festival && /* @__PURE__ */ _(yn, {
						festival: e.festival,
						names: h
					}),
					e.endReasons.length > 0 && /* @__PURE__ */ _("p", {
						className: "pr-end-note",
						children: c("games.puertorico.endRound")
					})
				]
			})]
		})]
	});
}
function Sn({ goods: e }) {
	let t = l();
	return /* @__PURE__ */ v("div", {
		className: "pr-goods",
		children: [x.map((n) => /* @__PURE__ */ v("span", {
			title: t(Q[n]),
			"aria-label": `${t(Q[n])}: ${e[n]}`,
			children: [
				/* @__PURE__ */ _(Z, { good: n }),
				/* @__PURE__ */ _("b", { children: e[n] }),
				/* @__PURE__ */ _("small", { children: t(Q[n]) })
			]
		}, n)), C(e) === 0 && /* @__PURE__ */ _("span", {
			className: "sr-only",
			children: t("games.puertorico.noGoods")
		})]
	});
}
function Cn({ good: e, value: t, max: n, onChange: r }) {
	let i = l(), a = i(Q[e]);
	return /* @__PURE__ */ v("div", {
		className: "pr-counter",
		children: [
			/* @__PURE__ */ _(Z, { good: e }),
			/* @__PURE__ */ _("span", { children: a }),
			/* @__PURE__ */ _("button", {
				"aria-label": i("games.puertorico.removeGood", { good: a }),
				disabled: t === 0,
				onClick: () => r(t - 1),
				children: "−"
			}),
			/* @__PURE__ */ _("b", { children: t }),
			/* @__PURE__ */ _("button", {
				"aria-label": i("games.puertorico.addGood", { good: a }),
				disabled: t >= n,
				onClick: () => r(t + 1),
				children: "+"
			}),
			/* @__PURE__ */ v("small", { children: ["/ ", n] })
		]
	});
}
//#endregion
//#region src/games/puertorico/endgame-review.tsx
function wn({ board: e, renderResult: t, ...n }) {
	let i = l(), [c, d] = s(!0), [f, p] = s(null), te = o(null), ne = o(null), re = o(null);
	r(() => {
		if (!f) return;
		re.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => p(null), 5e3);
		return () => clearTimeout(e);
	}, [f]);
	let ie = (e) => {
		p(null), d(e), requestAnimationFrame(() => (e ? te : ne).current?.focus({ preventScroll: !0 }));
	}, h = a(() => ({
		onPlayAgain: n.onPlayAgain && (() => p({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => p({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => p({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), g = {
		...n,
		...h
	};
	return /* @__PURE__ */ v("div", {
		className: "puertorico-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ _("div", {
				className: "puertorico-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ _("div", {
				className: "puertorico-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ v("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), ie(!1));
					},
					className: "puertorico-endgame-panel",
					"aria-label": i("session.result.title"),
					children: [
						/* @__PURE__ */ v("header", {
							className: "puertorico-endgame-heading",
							children: [/* @__PURE__ */ v("div", {
								className: "puertorico-endgame-brand",
								children: [/* @__PURE__ */ _("span", {
									"aria-hidden": "true",
									children: j.icon
								}), i(j.nameKey)]
							}), /* @__PURE__ */ _("button", {
								type: "button",
								ref: te,
								className: "btn-quiet",
								"aria-label": i("games.puertorico.reviewHide"),
								title: i("games.puertorico.reviewHide"),
								onClick: () => ie(!1),
								children: /* @__PURE__ */ _(m, { size: 19 })
							})]
						}),
						/* @__PURE__ */ _("div", {
							className: "puertorico-endgame-result",
							inert: f !== null,
							children: t(g)
						}),
						f && /* @__PURE__ */ v("div", {
							className: "puertorico-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || p(null);
							},
							children: [/* @__PURE__ */ _("button", {
								type: "button",
								ref: re,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = f.run;
									p(null), e();
								},
								children: i(f.label === "again" ? "games.puertorico.reviewConfirmAgain" : "games.puertorico.reviewConfirmLobby")
							}), /* @__PURE__ */ _("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									p(null), te.current?.focus({ preventScroll: !0 });
								},
								children: i("games.puertorico.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "puertorico-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ v("button", {
					type: "button",
					className: "btn-base",
					ref: ne,
					onClick: () => ie(!0),
					children: [
						/* @__PURE__ */ _(ee, { size: 18 }),
						i("games.puertorico.reviewShow"),
						/* @__PURE__ */ _(u, { size: 18 })
					]
				})
			})
		]
	});
}
function Tn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: u, renderRowExtra: f, summary: p, navigation: ee, content: te, afterRanking: ne, scoreUnit: re, rankOf: ie }) {
	let b = l(), x = c((e) => e.locale), [S, C] = s({}), w = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? h(n, x) : e;
	}, ae = (t, n) => ie?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), T = e.ranking.some((t) => e.scores?.[t] !== void 0), E = (t, n) => /* @__PURE__ */ v("div", {
		className: "puertorico-score-identity",
		children: [
			/* @__PURE__ */ v("span", {
				className: "puertorico-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ _("span", {
					"aria-label": b("games.puertorico.reviewWinner"),
					children: "♛ "
				}), T && ae(t, n)]
			}),
			/* @__PURE__ */ v("span", {
				className: "puertorico-score-name",
				children: [w(t), t === r && /* @__PURE__ */ _("small", { children: b("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ v("small", {
				className: "puertorico-score-autopilot",
				children: [
					/* @__PURE__ */ _(d, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), oe = (t) => e.ranking.map((n) => /* @__PURE__ */ _("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ v("div", {
		className: "puertorico-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ _(y, {}),
			ee,
			/* @__PURE__ */ v("div", {
				className: "puertorico-score-body",
				children: [
					p && /* @__PURE__ */ _("div", {
						className: "puertorico-score-summary",
						children: p
					}),
					i !== void 0 && /* @__PURE__ */ _("p", {
						className: "puertorico-score-hints",
						children: b("session.hint.usedCount", { n: i })
					}),
					te ?? (u?.length ? /* @__PURE__ */ _("div", {
						className: "puertorico-score-table-scroll",
						children: /* @__PURE__ */ v("table", {
							className: "puertorico-score-table",
							"aria-label": b(j.nameKey),
							children: [
								/* @__PURE__ */ _("thead", { children: /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", { scope: "col" }), /* @__PURE__ */ _(g, { children: e.ranking.map((t, n) => /* @__PURE__ */ _("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: E(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ _("tbody", { children: u.map((e, t) => /* @__PURE__ */ v(n, { children: [/* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ v("button", {
										type: "button",
										"aria-expanded": !!S[t],
										onClick: () => C((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ _(m, { size: 15 }), e.label]
									}) : e.label
								}), oe(e)] }), S[t] && e.details?.map((e, t) => /* @__PURE__ */ v("tr", {
									className: "puertorico-score-sub",
									children: [/* @__PURE__ */ _("th", {
										scope: "row",
										children: e.label
									}), oe(e)]
								}, t))] }, t)) }),
								T && /* @__PURE__ */ _("tfoot", { children: /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
									scope: "row",
									children: b("games.puertorico.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ _("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ _("ol", {
						className: "puertorico-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ v("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ v("div", {
								className: "puertorico-score-rankline",
								children: [E(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ v("strong", {
									className: "puertorico-score-points",
									children: [e.scores[t], re && /* @__PURE__ */ _("small", { children: re })]
								})]
							}), f?.(t)]
						}, t))
					})),
					ne,
					!!u?.length && f && /* @__PURE__ */ _("div", {
						className: "puertorico-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ v("details", { children: [/* @__PURE__ */ _("summary", { children: w(e) }), f(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ v("footer", {
				className: "puertorico-score-actions",
				children: [
					o && /* @__PURE__ */ _("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: b("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ _("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: b("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ _("p", { children: b("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/puertorico/endgame-scores.tsx
function En(e) {
	let t = l(), n = e.public, r = [
		["tokens", "games.puertorico.tokensScore"],
		["buildings", "games.puertorico.buildingsScore"],
		["bonus", "games.puertorico.bonusScore"],
		...n.config.nobles ? [["nobles", "games.puertorico.noblesScore"]] : []
	].map(([e, r]) => ({
		label: t(r),
		value: (t) => n.scores?.[t]?.[e] ?? "—"
	}));
	return /* @__PURE__ */ _(Tn, {
		...e,
		rows: r,
		renderRowExtra: (e) => /* @__PURE__ */ v("p", { children: [
			t("games.puertorico.tieValue"),
			" · ",
			n.scores?.[e]?.tie ?? "—"
		] })
	});
}
//#endregion
//#region src/games/puertorico/game-over.tsx
function Dn(e) {
	return /* @__PURE__ */ _(En, { ...e });
}
function On(e) {
	return /* @__PURE__ */ _(wn, {
		...e,
		board: /* @__PURE__ */ _(bn, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ _(Dn, { ...e })
	});
}
//#endregion
//#region src/games/puertorico/game-over-row.tsx
function kn({ public: e, rid: t }) {
	let n = l(), r = e.scores?.[t];
	return r ? /* @__PURE__ */ v("dl", {
		className: "grid grid-cols-2 gap-x-3 gap-y-1 text-xs",
		children: [
			/* @__PURE__ */ _("dt", { children: n("games.puertorico.tokensScore") }),
			/* @__PURE__ */ _("dd", {
				className: "text-right font-mono",
				children: r.tokens
			}),
			/* @__PURE__ */ _("dt", { children: n("games.puertorico.buildingsScore") }),
			/* @__PURE__ */ _("dd", {
				className: "text-right font-mono",
				children: r.buildings
			}),
			/* @__PURE__ */ _("dt", { children: n("games.puertorico.bonusScore") }),
			/* @__PURE__ */ _("dd", {
				className: "text-right font-mono",
				children: r.bonus
			}),
			e.config.nobles && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("dt", { children: n("games.puertorico.noblesScore") }), /* @__PURE__ */ _("dd", {
				className: "text-right font-mono",
				children: r.nobles
			})] }),
			/* @__PURE__ */ _("dt", { children: n("games.puertorico.tieValue") }),
			/* @__PURE__ */ _("dd", {
				className: "text-right font-mono",
				children: r.tie
			})
		]
	}) : null;
}
//#endregion
//#region src/games/puertorico/options.tsx
function An({ value: e, onChange: t }) {
	let n = l(), r = de.safeParse(e), i = r.success ? r.data : de.parse(void 0);
	return /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _(b, {
			checked: i.newBuildings,
			label: n("games.puertorico.optNewBuildings"),
			hint: n("games.puertorico.optNewBuildingsHint"),
			accent: j.accent,
			onChange: () => t({
				...i,
				newBuildings: !i.newBuildings
			})
		}),
		/* @__PURE__ */ _(b, {
			checked: i.nobles,
			label: n("games.puertorico.optNobles"),
			hint: n("games.puertorico.optNoblesHint"),
			accent: j.accent,
			onChange: () => t({
				...i,
				nobles: !i.nobles
			})
		}),
		/* @__PURE__ */ _(b, {
			checked: i.buccaneer,
			label: n("games.puertorico.optBuccaneer"),
			hint: n("games.puertorico.optBuccaneerHint"),
			accent: j.accent,
			onChange: () => t({
				...i,
				buccaneer: !i.buccaneer
			})
		}),
		/* @__PURE__ */ _(b, {
			checked: i.festival,
			label: n("games.puertorico.optFestival"),
			hint: n("games.puertorico.optFestivalHint"),
			accent: j.accent,
			onChange: () => t({
				...i,
				festival: !i.festival
			})
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/puertorico/entry.tsx
var jn = {
	definition: lt,
	View: bn,
	bot: pn,
	OverView: On,
	RowView: kn,
	Options: An,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "波多黎各",
			desc: "选择角色，建设岛屿，生产、贸易并装船得分；采用 2020 豪华版规则。",
			rules: "游戏目标：\n· 通过开垦种植园、兴建建筑、生产和装运货物，取得胜利分。\n· 游戏结束时，总分最高的玩家获胜；平分时按文末规则比较。\n· 本说明采用 2020 版规则，扩展内容仅在相应选项开启时使用。\n岛屿与资源：\n· 每位玩家拥有一座岛屿，种植区与城市各有 12 格。\n· 每块种植园、采石场或森林占用一格种植区。\n· 小型建筑占用一格城市，大型建筑占用两格城市。\n· 人员分为普通工人与贵族；未安排上岗的人员留在自己的港口。\n· 种植园和采石场各有一个工位；建筑的工位数以其标示为准。\n· 工位上有人即为上岗；无人上岗的种植园不生产，建筑能力不生效。\n· 森林与雕像没有工位，其特殊规则见对应建筑说明。\n· 货物分为玉米、靛蓝、糖、烟草和咖啡，以货桶计数。\n· 钱币用于购买建筑等支出，胜利分筹码用于记录游戏过程中取得的分数。\n· 货物、人员与胜利分筹码均有公共供应；钱币没有数量限制。\n· 自己的货物与港口人员属于自己，不属于公共供应。\n· 钱币、货物与人员公开；各人的胜利分筹码在终局前保密。\n游戏准备：\n· 确定人数与扩展选项后，按顺时针方向确定座次。\n· 第一席玩家担任首轮总督，其后按顺时针方向传递总督。\n· 三人游戏每人有 2 枚钱币；四人有 3 枚；五人有 4 枚。\n· 三人和四人游戏，前两席各有一块靛蓝种植园，其余各有一块玉米种植园。\n· 五人游戏，前三席各有一块靛蓝种植园，后两席各有一块玉米种植园。\n· 所有起始种植园均无人上岗；玩家起初没有建筑、货物、人员或胜利分筹码。\n· 三人游戏，筹码供应为 76 分，普通工人供应为 55 名，招聘所有 3 名。\n· 四人游戏，筹码供应为 101 分，普通工人供应为 75 名，招聘所有 4 名。\n· 五人游戏，筹码供应为 126 分，普通工人供应为 95 名，招聘所有 5 名。\n· 上述普通工人数量适用于基础游戏；贵族扩展另行调整人员供应。\n· 三人游戏使用容量为 4、5、6 桶的三艘公共货船。\n· 四人游戏使用容量为 5、6、7 桶的三艘公共货船。\n· 五人游戏使用容量为 6、7、8 桶的三艘公共货船。\n· 货物供应为玉米 10 桶、靛蓝 11 桶、糖 11 桶、烟草 9 桶、咖啡 9 桶。\n· 种植园总数为玉米 10 块、靛蓝 12 块、甘蔗 11 块、烟草 9 块、咖啡 8 块。\n· 先发放起始种植园，再将其余种植园洗混，组成暗置抽取堆。\n· 公开翻出比玩家人数多一块的种植园，另备 8 块采石场。\n· 交易所与所有公共货船起初均为空，角色牌上没有钱币。\n· 使用拓荒者、建筑师、工头、工匠、商人和船长六种基本角色。\n· 三人不使用勘探者；四人加入一张勘探者；五人加入两张。\n· 同名的两张勘探者牌视为两张独立角色牌，可以在同一轮分别选择。\n· 未开启新建筑扩展时，基础建筑直接进入市场；贵族建筑随贵族选项加入。\n· 三至五人时，两种小型生产建筑各有 4 座，其余基础生产建筑各有 3 座。\n· 每种小型商业建筑各有 2 座，每种大型建筑各有 1 座。\n双人游戏：\n· 两人各有 3 枚起始钱币；第一席持靛蓝种植园，第二席持玉米种植园。\n· 胜利分筹码供应为 65 分，普通工人供应为 40 名，招聘所初始有 2 名普通工人。\n· 使用容量为 4 桶和 6 桶的两艘公共货船，并加入一张勘探者。\n· 每种货物比通常供应减少 2 桶，每种种植园总数减少 3 块。\n· 采石场仅使用 5 块；每种商业建筑各有 1 座，每种生产建筑各有 2 座。\n· 每轮两人交替选择角色，各选择三次，共执行六次角色阶段。\n· 所选扩展先按其规则准备，再应用双人数量调整。\n· 贵族与庆典所需的额外准备，见各扩展章节。\n每轮流程：\n· 从总督开始，按顺时针方向轮流选择一张本轮尚未被选过的角色牌。\n· 选择角色时，先取得该牌上积累的全部钱币，再执行该角色阶段。\n· 角色选择者先行动，并享有该角色的特权。\n· 其余玩家按顺时针方向依次跟随行动，但不享有选择者的特权。\n· 勘探者与海盗仅由选择者行动，其他玩家不跟随。\n· 一个角色阶段全部结束后，才由下一位玩家选择角色。\n· 三至五人时，每人每轮选择一次角色；双人按前述规则各选择三次。\n· 本轮已选角色暂不可再选，直到下一轮重新开放。\n· 轮末在每张未选角色牌上放置 1 枚钱币；海盗牌不积累钱币。\n· 将角色牌恢复为可选状态，总督传给下一席，然后开始新一轮。\n拓荒者阶段：\n· 每位玩家可以从公开种植园中取得一块，放在自己的空种植区。\n· 选择者可以改取一块公共供应中的采石场，代替公开种植园。\n· 玩家可以放弃取地；种植区已有 12 块田地时，不能再取得田地。\n· 新取得的种植园或采石场没有人员，须安排人员后才会生效。\n· 庄园、建筑小屋、济贫院、图书馆与林务所的例外，见各建筑说明。\n· 所有玩家完成后，弃置剩余公开种植园，再翻出人数加一块的新种植园。\n· 暗置抽取堆用尽时，将弃置种植园洗混为新的抽取堆。\n· 采石场不进入种植园抽取堆，其数量受公共供应限制。\n建筑师阶段：\n· 每位玩家可以支付钱币，从建筑市场购买一座建筑，也可以放弃。\n· 所购建筑必须仍有库存，且自己的城市必须有足够空格。\n· 每位玩家不能拥有两座同名建筑；一次行动最多购买一座。\n· 选择者的建造费用减少 1 枚钱币。\n· 自己的每座已上岗采石场可减少 1 枚钱币，受建筑市场行数限制。\n· 第一至第四行，采石场合计最多分别优惠 1、2、3、4 枚钱币。\n· 按市场行数确定采石场上限；雕像属于第四行，上限仍为 4 枚。\n· 森林、区公所与角色特权可另行叠加，最终费用最低为零。\n· 新购建筑通常没有人员；大学可为有工位的新建筑立即安排一名人员。\n· 建筑一经建成即计入城市占格；填满 12 格会触发本轮结束后的终局。\n工头阶段：\n· 选择者先从普通工人供应额外取得 1 名工人，放入自己的港口。\n· 供应没有普通工人时，不能从招聘所补领这项特权。\n· 随后从选择者开始，按顺时针方向每次从招聘所领取一名人员。\n· 重复分配直到招聘所无人；人数不能整除时，部分玩家会多领一名。\n· 每位玩家可以重新安排自己的全部人员，包括原有上岗人员与港口人员。\n· 每个工位最多安排一名人员，森林和雕像不能安排人员。\n· 人员不足时，可自行选择工位，但必须把所有人员安排上岗。\n· 人员多于工位时，必须填满全部工位，多余人员留在自己的港口。\n· 阶段结束时，统计所有玩家建筑中的空工位总数，不计种植园空工位。\n· 下一批招聘人数取该总数与玩家人数中的较大值。\n· 从普通工人供应补充招聘所；基础游戏补不足时，触发本轮结束后的终局。\n· 使用贵族扩展时，人员种类、领取方式与结束条件另有规定。\n工匠阶段：\n· 每位玩家按自己的已上岗种植园与生产建筑，从公共供应取得货物。\n· 每块已上岗玉米种植园最多生产 1 桶玉米，不需要生产建筑。\n· 其余货物须同时有对应的已上岗种植园与生产建筑工位。\n· 产量取已上岗种植园数与对应生产建筑上岗人数中的较小值。\n· 例如有三块已上岗靛蓝种植园、两个已上岗靛蓝工位，最多生产 2 桶靛蓝。\n· 玩家按行动顺序领取，共用同一供应；供应不足时，只能取得尚余货桶。\n· 玩家可以少取或不取某种货物，未领取的产量以后不补发。\n· 所有玩家生产后，选择者可从自己本次实际生产过的种类中额外取得 1 桶。\n· 额外货桶也须有公共供应；没有实际生产货物时，不能领取。\n· 工厂与专门工厂按正常生产计算钱币，不因选择者领取额外货桶而重新计算。\n商人阶段：\n· 每位玩家可以出售自己的一桶货物，也可以放弃出售。\n· 基础售价为玉米 0 枚、靛蓝 1 枚、糖 2 枚、烟草 3 枚、咖啡 4 枚钱币。\n· 选择者成功出售时，额外取得 1 枚钱币；未出售则没有这项奖励。\n· 交易所最多容纳四桶货物；通常不能出售其中已有的货物种类。\n· 事务所允许重复种类，贸易站允许改为私人出售，详见各建筑说明。\n· 玉米基础售价虽为零，仍可以出售，并可取得适用的特权和市场奖励。\n· 整个阶段结束时，交易所若已满四桶，将全部货桶归还公共供应。\n· 交易所未满时，货物留存至以后的商人阶段，不会每轮自动清空。\n船长阶段：\n· 从选择者开始，玩家按顺时针方向反复轮流装船，直到无人继续装运。\n· 每次公共装船只能选择一种货物；玩家可以选择本次要装运的种类。\n· 只要仍能向公共货船装运，就不能直接放弃；私人装运仍可优先使用。\n· 每艘公共货船只能装一种货物；同种货物不能同时装在两艘公共货船上。\n· 若已有装载该货物的货船，必须使用该船，并尽可能装满其剩余空间。\n· 若该种货物的货船已满，不能另开一艘空船装同种货物。\n· 若没有对应货船，须在空船中选择本次能装走最多该种货物的船。\n· 所选货船能装多少就必须装多少，不能主动少装。\n· 两艘船都能装走全部所选货物时，可以任选其一。\n· 例如有 5 桶玉米，空船容量为 4 和 6 桶，须向 6 桶船装入全部 5 桶。\n· 每实际装运一桶货物，取得 1 分胜利分筹码。\n· 装运货物不要求自己拥有或启用对应的生产建筑。\n· 选择者在本阶段第一次实际装运时额外取得 1 分，每阶段仅一次。\n· 选择者没有装运货物时，不会取得这项特权分数。\n· 码头与小型码头提供私人装运，其使用次数、货物范围和分数另有规定。\n· 私人装运可以放弃；同一玩家可能在本阶段多次轮到装船。\n· 满载公共货船仅在整个船长阶段结束时卸货，货物归还公共供应。\n· 阶段进行期间，满船不会提前清空；未满货船继续保留原有货物。\n船长阶段的仓储：\n· 所有装运结束后，每位玩家决定保留哪些未装出的货物。\n· 没有仓储建筑时，每人合计只能保留一桶货物，可以自行选择种类。\n· 小型仓库额外保留一种货物的全部货桶，大型仓库额外保留两种。\n· 两座仓库同时生效时，额外保留三种货物的全部货桶。\n· 基础的一桶可以属于仓库所保留种类以外的另一种货物。\n· 储藏室再增加任意三桶的保留数量，也可与两种仓库叠加。\n· 例如小型仓库可保留全部 4 桶玉米，再使用基础额度保留 1 桶咖啡。\n· 超出保留范围的货桶全部归还公共供应；仓储无需支付钱币。\n勘探者阶段：\n· 仅选择者从钱币供应取得 1 枚钱币，其他玩家不行动。\n· 这枚钱币与角色牌原有积币分别领取。\n建筑能力通则：\n· 除雕像外，建筑必须至少有一名人员上岗，其能力才生效。\n· 生产建筑的上岗人数决定生产能力，并非上岗一名即取得全部产能。\n· 建筑的印刷胜利分不要求人员上岗，游戏结束时一律计入。\n· 大型建筑的额外计分能力，须在终局时有人员上岗才能结算。\n· 一项能力只在其规定时机结算，不会因随后启用建筑而追溯补发。\n· 不同建筑的能力可以叠加，但仍须遵守各自的条件、次数与数量限制。\n· 下列建筑说明中的人员，在贵族扩展中也可由贵族替代，除非明确区分种类。\n基础生产建筑：\n小型靛蓝作坊：\n· 本建筑有一个工位；上岗后，配合一块已上岗靛蓝种植园，最多生产 1 桶靛蓝。\n· 产量受公共货物供应限制；没有对应已上岗种植园时不生产。\n小型糖厂：\n· 本建筑有一个工位；上岗后，配合一块已上岗甘蔗种植园，最多生产 1 桶糖。\n· 产量受公共货物供应限制；没有对应已上岗种植园时不生产。\n靛蓝作坊：\n· 本建筑有 3 个工位，每名上岗人员提供 1 桶靛蓝的生产能力。\n· 每桶货物还须有一块对应的已上岗种植园，整座建筑最多生产 3 桶。\n· 实际领取数量受公共供应限制；多座同类生产建筑的产能可以合计。\n糖厂：\n· 本建筑有 3 个工位，每名上岗人员提供 1 桶糖的生产能力。\n· 每桶货物还须有一块对应的已上岗种植园，整座建筑最多生产 3 桶。\n· 实际领取数量受公共供应限制；多座同类生产建筑的产能可以合计。\n烟草加工厂：\n· 本建筑有 3 个工位，每名上岗人员提供 1 桶烟草的生产能力。\n· 每桶货物还须有一块对应的已上岗种植园，整座建筑最多生产 3 桶。\n· 实际领取数量受公共供应限制；多座同类生产建筑的产能可以合计。\n咖啡烘焙厂：\n· 本建筑有 2 个工位，每名上岗人员提供 1 桶咖啡的生产能力。\n· 每桶货物还须有一块对应的已上岗种植园，整座建筑最多生产 2 桶。\n· 实际领取数量受公共供应限制；多座同类生产建筑的产能可以合计。\n基础商业建筑：\n小型市场：\n· 商人阶段在交易所成功出售一桶货物时，额外取得 1 枚钱币。\n· 可以与商人特权、大型市场叠加；通过贸易站私人出售时不适用。\n庄园：\n· 每个拓荒者阶段，在自己的正常取地行动之前，可以额外抽取一块暗置种植园。\n· 抽取前须有空种植区；抽取后必须放到岛上，不能因不满意而弃置。\n· 庄园所得田地不能使用济贫院领取人员；林务所允许将其改为森林。\n· 如果仅余一格，庄园田地将其占满后，不能再进行正常取地。\n建筑小屋：\n· 拓荒者阶段，即使自己不是角色选择者，也可以改取一块采石场代替公开种植园。\n· 图书馆允许取得第二块田地时，也可用本能力选择采石场；供应仍须有剩余。\n小型仓库：\n· 船长阶段仓储时，除基础可保留的一桶外，可以保留一种货物的全部货桶。\n· 保留种类由自己选择；本能力可与大型仓库、储藏室同时使用。\n济贫院：\n· 拓荒者阶段正常取得第一块种植园或采石场时，可立即为其安排一名人员。\n· 先从普通工人供应领取；该供应用尽时，改从招聘所领取可用人员。\n· 招聘所可领取普通工人；启用贵族扩展时，也可选择其中的贵族。\n· 庄园额外田地与图书馆的第二块田地均不能取得济贫院人员。\n· 若将正常取得的种植园改为森林，领到的人员改放入自己的港口。\n事务所：\n· 商人阶段，可以向交易所出售其中已有的一种货物。\n· 交易所仍最多容纳四桶；已经满载时，事务所不能让自己继续出售。\n大型市场：\n· 商人阶段在交易所成功出售一桶货物时，额外取得 2 枚钱币。\n· 与小型市场同时启用时，两座市场合计额外取得 3 枚钱币。\n· 商人特权可另行叠加；通过贸易站私人出售时，两种市场均无奖励。\n大型仓库：\n· 船长阶段仓储时，除基础可保留的一桶外，可以保留两种货物的全部货桶。\n· 与小型仓库同时启用时，可额外保留三种货物的全部货桶；储藏室另行增加容量。\n工厂：\n· 每个工匠阶段，按自己正常生产实际取得的货物种类数领取钱币。\n· 生产两种取得 1 枚，三种取得 2 枚，四种取得 3 枚，五种取得 5 枚钱币。\n· 只生产零种或一种没有奖励；按种类计数，不按货桶总数计数。\n· 玉米计入种类数；选择者随后取得的额外货桶不会重新触发奖励。\n大学：\n· 建筑师阶段购买有工位的新建筑时，可立即领取一名人员，放入该建筑的空工位。\n· 先从普通工人供应领取；该供应用尽时，可从招聘所领取普通工人或可用贵族。\n· 无论新建筑有几个工位，每次最多取得一名人员。\n· 购买大学自身时没有这项奖励；雕像没有工位，也不能领取人员。\n海港：\n· 船长阶段每次实际装运货物时，额外取得 1 分胜利分筹码。\n· 公共货船、码头和小型码头均适用；每次装运加一分，不按桶数增加。\n· 可以与船长特权叠加；皇家供应商与海盗行动不属于装船。\n码头：\n· 每个船长阶段可以使用一次私人货船，将自己任意一种货物的全部货桶装运。\n· 私人货船没有容量限制，也不受公共货船已有货物种类或满载状态影响。\n· 每桶取得 1 分，货桶立即归还公共供应；适用船长、海港与灯塔奖励。\n· 可以放弃私人装运；与小型码头各有一次使用机会，可在不同装船轮次使用。\n基础大型建筑：\n公会会馆：\n· 终局时本建筑须有人员上岗，才结算以下额外分数。\n· 每座小型靛蓝作坊和小型糖厂各额外取得 1 分，其余每座生产建筑各额外取得 2 分。\n· 被计数的生产建筑无须上岗；贵族扩展的珠宝作坊属于大型生产建筑。\n官邸：\n· 终局时本建筑须有人员上岗，按自己的种植区占格数取得额外分数。\n· 占用零至九格取得 4 分，占十格取得 5 分，占十一格取得 6 分，十二格取得 7 分。\n· 所有种植园、采石场与森林均占格，无须有人员上岗。\n要塞：\n· 终局时本建筑须有人员上岗，自己的人员总数每满三名，额外取得 1 分。\n· 统计种植园、采石场、建筑与港口的全部人员；贵族也计入，不足三名的余数不计分。\n海关：\n· 终局时本建筑须有人员上岗，自己的胜利分筹码每满 4 分，额外取得 1 分。\n· 不足 4 分的余数不计；建筑印刷分、贵族分与其他终局奖励均不纳入计算。\n市政厅：\n· 终局时本建筑须有人员上岗，自己每座商业建筑额外取得 1 分。\n· 市政厅自身也计入；其他商业建筑无须上岗。\n· 所有生产建筑均不计入，贵族扩展的珠宝作坊也不计入。\n新建筑扩展与市场轮选：\n· 开启新建筑后，先从基础、新建筑及已启用贵族扩展的商业建筑中轮选市场。\n· 从总督开始，按顺时针方向，每次选择一种尚未入市的商业建筑。\n· 所选建筑的费用必须匹配一个剩余市场槽位，随后占用该槽位。\n· 同种小型商业建筑成对入市；双人仅一座；大型建筑均只有一座。\n· 反复轮选直到所有槽位填满；未入选的建筑本局不能购买。\n· 生产建筑固定入市，不参加商业建筑轮选；珠宝作坊也属于生产建筑。\n· 开启贵族扩展时，加入贵族建筑候选和相应的额外市场槽位。\n黑市：\n· 只有自己的钱币不足以支付建造费用时，才可以使用黑市补足差额。\n· 可以归还最多一名人员、一桶货物和 1 分胜利分筹码，每项抵付 1 枚钱币。\n· 最多抵付 3 枚钱币；必须花光自己的钱币，归还项目须恰好补足差额，不找零。\n· 人员可以来自种植园、采石场、其他建筑或港口，但不能归还黑市自身的人员。\n· 普通工人归还普通供应，贵族归还贵族供应，货物与筹码归还各自供应。\n· 移走采石场、区公所或图书馆的人员后，失去的优惠也须计入最终建造费用。\n· 已经触发的终局条件，不会因归还筹码或人员而撤销。\n林务所：\n· 本建筑启用时，新取得的种植园可以改放为森林；已在岛上的田地不能转换。\n· 庄园抽取或地政所购买的暗置种植园，也可先查看再决定是否改为森林。\n· 采石场不能转为森林；森林占一格种植区，没有工位，也不生产货物。\n· 自己的森林每满两块，所有建造费用减少 1 枚钱币，可与其他优惠叠加。\n· 已经建成的森林不再要求林务所保持启用；所有森林均视为同一种田地。\n引水渠：\n· 工匠阶段，已上岗靛蓝作坊或糖厂配合对应种植园能正常生产时，对应货物多产 1 桶。\n· 只有大型靛蓝作坊与糖厂适用，小型靛蓝作坊和小型糖厂不能触发。\n· 两种大型建筑均满足条件时，靛蓝和糖各多产 1 桶；仍受公共供应限制。\n储藏室：\n· 船长阶段仓储时，可以额外保留任意种类的三桶货物，不要求三桶同种。\n· 加上基础的一桶，合计可保留四桶；小型仓库与大型仓库的整类保留另行叠加。\n旅馆：\n· 本建筑有两个工位，可在工头阶段安排人员作为客人，贵族也可以入住。\n· 在阶段开始、进行或结束时，可以将客人移至自己其他合法的空工位。\n· 种植园、采石场与建筑均可接收客人；两名客人可以在不同时机分别移出。\n· 客人移入后立即使该工位生效，但不会补发已经错过时机的能力奖励。\n· 移出的人员直到下次工头阶段前不能再移动，也不能送回旅馆反复使用。\n教堂：\n· 建筑师阶段建造第二行或第三行建筑时，取得 1 分胜利分筹码。\n· 建造第四行建筑时取得 2 分，第一行没有奖励。\n· 建造教堂自身没有奖励；这些筹码不影响新建筑原有的印刷胜利分。\n贸易站：\n· 商人阶段可以改在自己的贸易站出售一桶货物，货桶直接归还公共供应。\n· 私人出售不受交易所已满或已有同种货物的限制。\n· 仍可取得商人特权，但不能取得小型市场与大型市场的钱币奖励。\n· 本建筑不增加出售次数，每个商人阶段仍最多出售一桶。\n小型码头：\n· 每个船长阶段可以使用一次，装运任意种类与数量的货物，可以混装。\n· 可以只交出部分库存，每满两桶取得 1 分，不足两桶的余数不计基础分。\n· 至少须交出一桶，所有货桶立即归还公共供应；只交一桶时基础分为零。\n· 仍适用船长特权、海港与灯塔奖励；可以与码头在不同装船轮次分别使用。\n· 私人装运可以放弃，不受公共货船的种类与容量限制。\n灯塔：\n· 船长阶段每次实际装运货物，取得 1 枚钱币，公共货船和两种私人码头均适用。\n· 如果自己选择了船长，本阶段还额外取得 1 枚钱币，即使没有装运。\n· 选择船长的钱币奖励每阶段仅一次；图书馆不会将这项建筑奖励加倍。\n专门工厂：\n· 每个工匠阶段，在自己正常生产取得的非玉米货物中，选择桶数最多的一种。\n· 取得该桶数减一的钱币，最低为零；例如生产 4 桶糖可取得 3 枚钱币。\n· 玉米不参与计算；选择者随后取得的额外货桶不重新计算奖励。\n图书馆：\n· 自己选择角色时，该角色特权加倍；跟随其他玩家时不获得角色特权。\n· 拓荒者可以取得第二块田地，须等其他玩家完成正常取地后再取。\n· 第二块可选剩余公开种植园；只有建筑小屋启用时，才可改选采石场。\n· 第二块不能使用济贫院；仍须有空种植区，可以放弃领取。\n· 建筑师优惠变为 2 枚钱币；工头从普通供应额外取得 2 名工人。\n· 工匠可额外取得两桶本次实际生产过的货物，可以同种，也可以不同种。\n· 商人成功出售时额外取得 2 枚钱币；船长首次实际装运额外取得 2 分。\n· 勘探者取得 2 枚钱币；这些奖励仍受各角色原有条件限制。\n· 图书馆不加倍角色牌积币、其他建筑奖励或海盗行动。\n同业会馆：\n· 每个船长阶段，在自己首次行动之前，按此时拥有的货物取得胜利分筹码。\n· 每种货物分别计算，每满两桶取得 1 分，不同种类的零散货桶不能合并。\n· 例如三桶玉米、一桶咖啡与两桶靛蓝，合计取得 2 分。\n· 计分不消耗货物，此后仍可正常装船、皇家供应或仓储。\n修道院：\n· 终局时本建筑须有人员上岗，按自己同类田地每三块组成一组。\n· 各类种植园分别计算，采石场与森林也各算一类，同一种可组成多组。\n· 一组取得 1 分，两组取得 3 分，三组取得 6 分，四组取得 10 分，零组没有奖励。\n· 例如六块玉米种植园与三块森林共组成三组，取得 6 分；田地无须上岗。\n雕像：\n· 本建筑占两格城市，没有工位，不需要安排人员。\n· 终局按印刷值计入 8 分，没有另行启用的额外计分能力。\n· 雕像属于第四行建筑，采石场优惠上限为 4 枚钱币。\n贵族扩展：\n· 加入 20 名贵族与八种贵族建筑；贵族可以替代普通工人安排到所有合法工位。\n· 部分贵族建筑按上岗者是普通工人还是贵族，提供不同能力。\n· 三至五人使用全部 100 名普通工人，招聘所初始人数等于玩家人数。\n· 初始招聘所中一名为贵族，其余为普通工人；贵族供应另有 19 名。\n· 因此普通工人供应分别为三人 98 名、四人 97 名、五人 96 名。\n· 双人初始招聘所仍为两名普通工人，普通供应 40 名，贵族供应 20 名。\n· 双人首次补充招聘所时，才开始加入贵族。\n· 每次补充招聘所时，只要供应允许，将目标人数中的一名普通工人替换为贵族。\n· 普通工人不足时，也最多加入一名贵族；招聘所人数可以低于目标人数。\n· 工头分配招聘人员时，每次轮到自己，可在尚余人员中选择普通工人或贵族。\n· 工头特权仍只从普通供应领取；图书馆也不会将该特权改为贵族。\n· 终局时自己每名贵族取得 1 分，种植园、建筑与港口中的贵族全部计入。\n· 取消因招聘所补充不足而结束游戏的条件；城市填满与筹码用尽仍会触发终局。\n区公所：\n· 普通工人上岗时，购买小型建筑的费用减少 1 枚钱币。\n· 贵族上岗时，改为购买大型建筑的费用减少 2 枚钱币。\n· 两种能力不同时生效；可以叠加其他优惠，最终费用最低为零。\n皇家供应商：\n· 每个船长阶段，在自己首次正常装船行动前，可以向皇家供应一次货物。\n· 每种货物最多交出一桶，总桶数不超过自己拥有的贵族人数，港口贵族也计入。\n· 交出的货桶立即归还公共供应，每桶取得 1 分胜利分筹码。\n· 不享有船长、海港或灯塔的额外奖励；供应后仍按正常船长规则继续行动。\n礼拜堂：\n· 每个工匠阶段开始时，普通工人上岗取得 1 枚钱币，贵族上岗取得 1 分胜利分筹码。\n· 即使本阶段没有生产货物，仍可取得对应奖励；每阶段只结算一次。\n珠宝作坊：\n· 工匠阶段轮到自己生产时，自己每名贵族带来 1 枚钱币，港口贵族也计入。\n· 本建筑不生产货桶，也不需要对应种植园；没有生产其他货物时仍可取得钱币。\n· 公会会馆将本建筑视为大型生产建筑，市政厅不将其视为商业建筑。\n别墅：\n· 每个工头阶段，自己首次收到人员时，额外从贵族供应取得一名贵族，放入港口。\n· 工头特权取得人员也会触发；同一阶段不能因以后再领取人员而重复触发。\n· 贵族供应用尽时改取一名普通工人；两种供应均用尽时没有额外人员。\n狩猎小屋：\n· 拓荒者阶段结束时，普通工人上岗可以弃置自己一块种植园或森林，不能弃采石场。\n· 被弃田地上的人员移至自己的港口，弃置田地进入种植园弃置堆。\n· 贵族上岗时，比较所有玩家的空种植区；自己严格最多则取得 2 分胜利分筹码。\n· 其他玩家的弃置先完成，再比较空格；并列最多没有奖励，无须自己选择拓荒者。\n地政所：\n· 每个商人阶段可使用一次，可以在自己出售货物之前或之后使用。\n· 普通工人上岗时，可以支付 1 枚钱币，抽取并放置一块暗置种植园，须有空格。\n· 贵族上岗时，可以出售自己一块种植园或森林，取得 1 枚钱币，不能出售采石场。\n· 出售田地上的人员移至港口，田地进入弃置堆；本能力不占出售货物的次数。\n· 林务所启用时，购买的新种植园可以改为森林。\n皇家花园：\n· 终局时本建筑须有人员上岗，自己每名贵族额外取得 1 分。\n· 种植园、建筑与港口中的贵族均计入，连同贵族基础分，每名共计 2 分。\n海盗扩展：\n· 在原有角色外加入海盗；选择者取得海盗标记，并从以下四种行动中选择一种。\n· 其他玩家不跟随海盗行动，图书馆不加倍其效果。\n· 持有海盗标记的玩家不能再次选择海盗，直到另一位玩家选择并取走标记。\n· 海盗牌在未被选择时不积累钱币。\n海盗的劫掠行动：\n· 选择一艘有货物的公共货船，将其全部清空。\n· 可以保留其中零至三桶货物，放入自己的货物库存，其余归还公共供应。\n· 清空后的货船重新为空船；劫掠不算装船，不取得装船分数或相关建筑奖励。\n海盗的掠夺行动：\n· 将交易所全部货桶归还公共供应，每归还一桶取得 1 分胜利分筹码。\n· 掠夺不算出售或装船，不享有商人、船长、市场、海港或灯塔等奖励。\n海盗的袭击行动：\n· 只有招聘所人数多于玩家人数时才可袭击，将其人数移除至等于玩家人数。\n· 可以保留被移除人员中的最多三名，立即安排到自己合法的空工位。\n· 种植园、采石场与建筑空工位均可接收，不能将这些人员留在港口。\n· 未保留的人员归还各自供应；使用贵族时，可决定留下和带走的人员种类。\n海盗的劫持行动：\n· 选择一张本轮尚未被选、且不是海盗的角色牌，先取得其全部积币。\n· 若本轮稍后有对手选择该角色，自己取得 3 枚钱币赎金。\n· 对手仍正常执行该角色并取得特权，劫持不会取消对手行动。\n· 若自己后来选择该角色，不取得赎金，也不再于轮末额外执行。\n· 若本轮无人选择该角色，则在轮末由海盗额外执行，自己取得该角色特权。\n· 其他玩家按该角色的通常规则跟随；即使已触发终局，也须先完成这次额外阶段。\n庆典扩展：\n· 本局设种植、生产与建筑三个公共目标，各自只奖励第一位达成的玩家一次。\n· 同一玩家可以取得多个目标；满足条件后立即结算，不需要额外申领奖励。\n· 用于展示目标的一块种植园、三桶货物与一座建筑，暂时从相应供应中移出。\n· 某项目标达成时，将该目标展示物归还原供应，不交给获奖玩家。\n· 玩家无须交出自己为达成目标而拥有的种植园、货物或建筑。\n庆典种植目标：\n· 随机确定一种种植园；最先拥有三块该种种植园的玩家取得奖励，无须上岗。\n· 从普通工人供应取得最多三名工人，放入自己的港口，稍后才能安排上岗。\n· 普通工人不足时只取尚余人数，不从招聘所领取，也不以贵族替代。\n庆典生产目标：\n· 从五种货物各三桶的组合中随机抽三桶作为要求，可能出现相同种类。\n· 在同一个工匠阶段，实际生产的种类与数量满足要求，即取得 3 枚钱币。\n· 工匠特权取得的额外货桶也计入；以前库存与不同阶段的产量不能累积。\n· 例如目标为两桶糖和一桶咖啡，须在同次工匠阶段至少取得这些生产货物。\n庆典建筑目标：\n· 从本局建筑市场第三行的建筑中随机选择一项作为目标。\n· 若某种货物出现在生产目标中，生产该货物的建筑不作为建筑目标候选。\n· 第一位建成指定建筑的玩家取得 3 分胜利分筹码，不要求该建筑立即上岗。\n触发游戏结束：\n· 任一玩家的城市填满 12 格，或胜利分筹码公共供应用尽，均触发游戏结束。\n· 未开启贵族扩展时，工头阶段不能按要求补足招聘所，也会触发游戏结束。\n· 种植区填满、种植园抽取堆或货物供应用尽，本身不会触发游戏结束。\n· 触发后仍须完成本轮所有角色，以及海盗劫持所需的轮末额外阶段。\n· 筹码用尽后仍照常记录应得胜利分，不因公共筹码不足而少计。\n· 随后直接进行终局计分，不再开始新一轮。\n终局计分与胜负：\n· 总分包括自己的胜利分筹码、全部建筑印刷分、已启用大型建筑奖励与贵族分。\n· 所有建筑印刷分均计入，无须上岗；大型建筑额外奖励须在终局时启用。\n· 普通工人与剩余钱币、货物不直接增加总分，除非某项建筑能力明确规定。\n· 总分最高者获胜；总分相同时，比较各自的钱币枚数与剩余货桶数之和。\n· 货桶一律每桶计一，不按商人售价折算；该合计较高者获胜。\n· 例如剩余 5 枚钱币和 3 桶货物，平分比较值为 8。\n· 若总分与平分比较值仍完全相同，则相关玩家共享胜利。",
			optNewBuildings: "新建筑",
			optNobles: "贵族",
			optNoblesHint: "加入贵族人员、八座建筑与贵族计分。",
			optBuccaneer: "海盗",
			optBuccaneerHint: "追加海盗角色，可劫掠、掠夺、袭击或劫持角色。",
			optFestival: "庆典",
			optFestivalHint: "为首个完成种植、生产和建筑目标的玩家提供奖励。",
			buccaneerPrompt: "选择一项海盗行动",
			piracy: "劫掠货船 {{n}}",
			piracyKeep: "保留货桶数量",
			plunder: "掠夺交易所",
			raid: "袭击招聘所",
			kidnap: "劫持{{role}}",
			kidnapped: "{{name}}劫持了{{role}}",
			pirateToken: "{{name}}持有海盗标记",
			confirmRaid: "确认袭击与人员安置",
			cancelRaid: "取消袭击",
			leaveNobles: "留在招聘所的贵族",
			raidPlaced: "已安置 {{n}} / {{max}} 名人员",
			festival: "庆典",
			festivalPlantation: "种植目标：三块{{good}}种植园",
			festivalProduction: "生产目标",
			festivalBuilding: "建筑目标",
			festivalWorkers: "奖励三名工人",
			festivalCoins: "奖励三枚钱币",
			festivalVP: "奖励三分",
			claimedBy: "{{name}}已达成",
			takeNoble: "领取一名贵族",
			takeWorker: "领取一名工人",
			assignNobles: "安排贵族",
			recruitPrompt: "选择领取的人员",
			landPrompt: "使用地政所，或继续本阶段",
			huntingPrompt: "弃置一块种植园或森林，或放弃",
			royalPrompt: "向皇家供应不同种类的货物",
			supplyRoyal: "确认皇家供应",
			royalCargo: "皇家供应的货物",
			buyLand: "花费一枚钱币购买暗置种植园",
			nobleCount: "贵族 {{n}} 名",
			harborNobles: "港口贵族 {{n}} 名",
			recruitmentNobles: "招聘所贵族 {{n}} 名",
			nobleSupply: "贵族供应 {{n}} 名",
			returnNoble: "{{place}}的一名贵族",
			noblesScore: "贵族分",
			optNewBuildingsHint: "开局由玩家轮选同价商业建筑，采用官方市场设置。",
			draftBuilding: "加入建筑市场",
			draftPrompt: "轮选本局的商业建筑",
			guestPrompt: "移动旅馆客人，或继续本阶段",
			forestPrompt: "决定种植园的用途",
			extraSettler: "图书馆：选择第二块田",
			continuePhase: "继续本阶段",
			asForest: "作为森林放置",
			keepPlantation: "作为种植园放置",
			blackMarketPayment: "黑市归还资源",
			returnWorker: "{{place}}的一名工人",
			returnGood: "一桶{{good}}",
			returnVP: "一分筹码",
			useSmallWharf: "用小型码头装运",
			smallWharfCargo: "小型码头货物",
			sellPrivately: "在贸易站出售一桶{{good}}",
			brand: "PUERTO RICO",
			edition: "2020 豪华版",
			round: "第 {{n}} 轮",
			governor: "总督",
			wait: "等待 {{name}} 行动",
			you: "轮到你",
			selectRole: "选择一个角色",
			island: "{{name}}的岛屿",
			plantations: "种植区",
			city: "城市",
			harbor: "港口",
			market: "建筑市场",
			islandTab: "岛屿",
			rolesTab: "角色",
			boardAreas: "游戏区域",
			shipCapacity: "{{n}} 格货船",
			recruitment: "招聘所",
			workerSupply: "工人供应",
			goodsSupply: "货物供应",
			vpSupply: "剩余胜利分",
			money: "钱币",
			vp: "我的胜利分",
			unemployed: "港口工人",
			tradingHouse: "交易所",
			cargoShips: "货船",
			privateShip: "私人货船",
			ship: "货船 {{n}}",
			cost: "费用 {{n}}",
			points: "{{n}} 分",
			stock: "剩余 {{n}} 座",
			selectPlant: "选择种植园或采石场",
			selectBuilding: "选择一座建筑",
			assignWorkers: "安排全部工人",
			produceGoods: "选择生产数量",
			selectBonus: "选择一桶额外货物",
			tradeGoods: "选择一桶货物出售",
			shipGoods: "选择货物与货船",
			storeGoods: "选择保留的货物",
			done: "本局结束",
			confirm: "确认",
			build: "建造",
			assign: "确认安排",
			produce: "确认生产",
			store: "确认保留",
			pass: "放弃本次行动",
			skipWharf: "不使用私人货船",
			close: "关闭",
			reset: "重置",
			recommend: "建议安排",
			workers: "工人 {{n}} / {{max}}",
			assignment: "已安排 {{n}} / {{max}} 名工人",
			addWorker: "增加工人",
			removeWorker: "减少工人",
			addGood: "增加{{good}}数量",
			removeGood: "减少{{good}}数量",
			emptyField: "空种植区",
			emptyCity: "空城市格",
			active: "已启用",
			inactive: "未启用",
			useHospice: "使用济贫院取得工人",
			useUniversity: "使用大学取得工人",
			useHacienda: "庄园：先取得一块暗置种植园",
			load: "装载 {{n}} 桶{{good}}",
			sell: "出售一桶{{good}}",
			take: "取得{{good}}",
			production: "可生产",
			keep: "保留",
			noGoods: "没有货物",
			noBuildings: "没有可购买的建筑",
			endRound: "本轮结束后结算",
			endWorkers: "招聘所无法补足工人",
			endCity: "城市已建满",
			endVP: "胜利分供应耗尽",
			log: "对局记录",
			tokensScore: "胜利分筹码",
			buildingsScore: "建筑分",
			bonusScore: "大型建筑奖励",
			tieValue: "钱币与货物",
			errTurn: "请等待轮到你行动。",
			errAction: "当前无法执行这项行动，请重新选择。",
			errWorkers: "请把所有可上岗的工人安排到合法空位。",
			errStorage: "保留的货物超出仓储能力。",
			errForced: "仍有货物可以装入公共货船，请先装船。",
			good: {
				forest: "森林",
				corn: "玉米",
				indigo: "靛蓝",
				sugar: "糖",
				tobacco: "烟草",
				coffee: "咖啡",
				quarry: "采石场"
			},
			role: {
				settler: "拓荒者",
				builder: "建筑师",
				mayor: "工头",
				craftsman: "工匠",
				trader: "商人",
				captain: "船长",
				prospector: "勘探者",
				buccaneer: "海盗"
			},
			roleHelp: {
				buccaneer: "仅你选择一项海盗行动；持有标记时不能再次选择。",
				settler: "每人取得种植园；你可改取采石场。",
				builder: "每人购买建筑；你少付一枚钱币。",
				mayor: "分配招聘所工人并重新安排；你多得一名工人。",
				craftsman: "每人生产货物；所有人生产后，你可多取一桶。",
				trader: "每人出售一桶货物；你多得一枚钱币。",
				captain: "依次装船，每桶得一分；你首次装船多得一分。",
				prospector: "你取得一枚钱币，其他人不行动。"
			},
			building: {
				districtOffice: "区公所",
				royalSupplier: "皇家供应商",
				chapel: "礼拜堂",
				jeweler: "珠宝作坊",
				villa: "别墅",
				huntingLodge: "狩猎小屋",
				landOffice: "地政所",
				royalGarden: "皇家花园",
				blackMarket: "黑市",
				forestHouse: "林务所",
				aqueduct: "引水渠",
				storehouse: "储藏室",
				guesthouse: "旅馆",
				church: "教堂",
				tradingPost: "贸易站",
				smallWharf: "小型码头",
				lighthouse: "灯塔",
				specialtyFactory: "专门工厂",
				library: "图书馆",
				unionHall: "同业会馆",
				cloister: "修道院",
				statue: "雕像",
				smallIndigo: "小型靛蓝作坊",
				smallSugar: "小型糖厂",
				indigoPlant: "靛蓝作坊",
				sugarMill: "糖厂",
				tobaccoStorage: "烟草加工厂",
				coffeeRoaster: "咖啡烘焙厂",
				smallMarket: "小型市场",
				hacienda: "庄园",
				constructionHut: "建筑小屋",
				smallWarehouse: "小型仓库",
				hospice: "济贫院",
				office: "事务所",
				largeMarket: "大型市场",
				largeWarehouse: "大型仓库",
				factory: "工厂",
				university: "大学",
				harbor: "海港",
				wharf: "码头",
				guildHall: "公会会馆",
				residence: "官邸",
				fortress: "要塞",
				customsHouse: "海关",
				cityHall: "市政厅"
			},
			buildingText: {
				smallIndigo: "本建筑有一个工位；上岗后，配合一块已上岗靛蓝种植园，最多生产 1 桶靛蓝。产量受公共货物供应限制；没有对应已上岗种植园时不生产。",
				smallSugar: "本建筑有一个工位；上岗后，配合一块已上岗甘蔗种植园，最多生产 1 桶糖。产量受公共货物供应限制；没有对应已上岗种植园时不生产。",
				indigoPlant: "本建筑有 3 个工位，每名上岗人员提供 1 桶靛蓝的生产能力。每桶货物还须有一块对应的已上岗种植园，整座建筑最多生产 3 桶。实际领取数量受公共供应限制；多座同类生产建筑的产能可以合计。",
				sugarMill: "本建筑有 3 个工位，每名上岗人员提供 1 桶糖的生产能力。每桶货物还须有一块对应的已上岗种植园，整座建筑最多生产 3 桶。实际领取数量受公共供应限制；多座同类生产建筑的产能可以合计。",
				tobaccoStorage: "本建筑有 3 个工位，每名上岗人员提供 1 桶烟草的生产能力。每桶货物还须有一块对应的已上岗种植园，整座建筑最多生产 3 桶。实际领取数量受公共供应限制；多座同类生产建筑的产能可以合计。",
				coffeeRoaster: "本建筑有 2 个工位，每名上岗人员提供 1 桶咖啡的生产能力。每桶货物还须有一块对应的已上岗种植园，整座建筑最多生产 2 桶。实际领取数量受公共供应限制；多座同类生产建筑的产能可以合计。",
				smallMarket: "商人阶段在交易所成功出售一桶货物时，额外取得 1 枚钱币。可以与商人特权、大型市场叠加；通过贸易站私人出售时不适用。",
				hacienda: "每个拓荒者阶段，在自己的正常取地行动之前，可以额外抽取一块暗置种植园。抽取前须有空种植区；抽取后必须放到岛上，不能因不满意而弃置。庄园所得田地不能使用济贫院领取人员；林务所允许将其改为森林。如果仅余一格，庄园田地将其占满后，不能再进行正常取地。",
				constructionHut: "拓荒者阶段，即使自己不是角色选择者，也可以改取一块采石场代替公开种植园。图书馆允许取得第二块田地时，也可用本能力选择采石场；供应仍须有剩余。",
				smallWarehouse: "船长阶段仓储时，除基础可保留的一桶外，可以保留一种货物的全部货桶。保留种类由自己选择；本能力可与大型仓库、储藏室同时使用。",
				hospice: "拓荒者阶段正常取得第一块种植园或采石场时，可立即为其安排一名人员。先从普通工人供应领取；该供应用尽时，改从招聘所领取可用人员。招聘所可领取普通工人；启用贵族扩展时，也可选择其中的贵族。庄园额外田地与图书馆的第二块田地均不能取得济贫院人员。若将正常取得的种植园改为森林，领到的人员改放入自己的港口。",
				office: "商人阶段，可以向交易所出售其中已有的一种货物。交易所仍最多容纳四桶；已经满载时，事务所不能让自己继续出售。",
				largeMarket: "商人阶段在交易所成功出售一桶货物时，额外取得 2 枚钱币。与小型市场同时启用时，两座市场合计额外取得 3 枚钱币。商人特权可另行叠加；通过贸易站私人出售时，两种市场均无奖励。",
				largeWarehouse: "船长阶段仓储时，除基础可保留的一桶外，可以保留两种货物的全部货桶。与小型仓库同时启用时，可额外保留三种货物的全部货桶；储藏室另行增加容量。",
				factory: "每个工匠阶段，按自己正常生产实际取得的货物种类数领取钱币。生产两种取得 1 枚，三种取得 2 枚，四种取得 3 枚，五种取得 5 枚钱币。只生产零种或一种没有奖励；按种类计数，不按货桶总数计数。玉米计入种类数；选择者随后取得的额外货桶不会重新触发奖励。",
				university: "建筑师阶段购买有工位的新建筑时，可立即领取一名人员，放入该建筑的空工位。先从普通工人供应领取；该供应用尽时，可从招聘所领取普通工人或可用贵族。无论新建筑有几个工位，每次最多取得一名人员。购买大学自身时没有这项奖励；雕像没有工位，也不能领取人员。",
				harbor: "船长阶段每次实际装运货物时，额外取得 1 分胜利分筹码。公共货船、码头和小型码头均适用；每次装运加一分，不按桶数增加。可以与船长特权叠加；皇家供应商与海盗行动不属于装船。",
				wharf: "每个船长阶段可以使用一次私人货船，将自己任意一种货物的全部货桶装运。私人货船没有容量限制，也不受公共货船已有货物种类或满载状态影响。每桶取得 1 分，货桶立即归还公共供应；适用船长、海港与灯塔奖励。可以放弃私人装运；与小型码头各有一次使用机会，可在不同装船轮次使用。",
				guildHall: "终局时本建筑须有人员上岗，才结算以下额外分数。每座小型靛蓝作坊和小型糖厂各额外取得 1 分，其余每座生产建筑各额外取得 2 分。被计数的生产建筑无须上岗；贵族扩展的珠宝作坊属于大型生产建筑。",
				residence: "终局时本建筑须有人员上岗，按自己的种植区占格数取得额外分数。占用零至九格取得 4 分，占十格取得 5 分，占十一格取得 6 分，十二格取得 7 分。所有种植园、采石场与森林均占格，无须有人员上岗。",
				fortress: "终局时本建筑须有人员上岗，自己的人员总数每满三名，额外取得 1 分。统计种植园、采石场、建筑与港口的全部人员；贵族也计入，不足三名的余数不计分。",
				customsHouse: "终局时本建筑须有人员上岗，自己的胜利分筹码每满 4 分，额外取得 1 分。不足 4 分的余数不计；建筑印刷分、贵族分与其他终局奖励均不纳入计算。",
				cityHall: "终局时本建筑须有人员上岗，自己每座商业建筑额外取得 1 分。市政厅自身也计入；其他商业建筑无须上岗。所有生产建筑均不计入，贵族扩展的珠宝作坊也不计入。",
				blackMarket: "只有自己的钱币不足以支付建造费用时，才可以使用黑市补足差额。可以归还最多一名人员、一桶货物和 1 分胜利分筹码，每项抵付 1 枚钱币。最多抵付 3 枚钱币；必须花光自己的钱币，归还项目须恰好补足差额，不找零。人员可以来自种植园、采石场、其他建筑或港口，但不能归还黑市自身的人员。普通工人归还普通供应，贵族归还贵族供应，货物与筹码归还各自供应。移走采石场、区公所或图书馆的人员后，失去的优惠也须计入最终建造费用。已经触发的终局条件，不会因归还筹码或人员而撤销。",
				forestHouse: "本建筑启用时，新取得的种植园可以改放为森林；已在岛上的田地不能转换。庄园抽取或地政所购买的暗置种植园，也可先查看再决定是否改为森林。采石场不能转为森林；森林占一格种植区，没有工位，也不生产货物。自己的森林每满两块，所有建造费用减少 1 枚钱币，可与其他优惠叠加。已经建成的森林不再要求林务所保持启用；所有森林均视为同一种田地。",
				aqueduct: "工匠阶段，已上岗靛蓝作坊或糖厂配合对应种植园能正常生产时，对应货物多产 1 桶。只有大型靛蓝作坊与糖厂适用，小型靛蓝作坊和小型糖厂不能触发。两种大型建筑均满足条件时，靛蓝和糖各多产 1 桶；仍受公共供应限制。",
				storehouse: "船长阶段仓储时，可以额外保留任意种类的三桶货物，不要求三桶同种。加上基础的一桶，合计可保留四桶；小型仓库与大型仓库的整类保留另行叠加。",
				guesthouse: "本建筑有两个工位，可在工头阶段安排人员作为客人，贵族也可以入住。在阶段开始、进行或结束时，可以将客人移至自己其他合法的空工位。种植园、采石场与建筑均可接收客人；两名客人可以在不同时机分别移出。客人移入后立即使该工位生效，但不会补发已经错过时机的能力奖励。移出的人员直到下次工头阶段前不能再移动，也不能送回旅馆反复使用。",
				church: "建筑师阶段建造第二行或第三行建筑时，取得 1 分胜利分筹码。建造第四行建筑时取得 2 分，第一行没有奖励。建造教堂自身没有奖励；这些筹码不影响新建筑原有的印刷胜利分。",
				tradingPost: "商人阶段可以改在自己的贸易站出售一桶货物，货桶直接归还公共供应。私人出售不受交易所已满或已有同种货物的限制。仍可取得商人特权，但不能取得小型市场与大型市场的钱币奖励。本建筑不增加出售次数，每个商人阶段仍最多出售一桶。",
				smallWharf: "每个船长阶段可以使用一次，装运任意种类与数量的货物，可以混装。可以只交出部分库存，每满两桶取得 1 分，不足两桶的余数不计基础分。至少须交出一桶，所有货桶立即归还公共供应；只交一桶时基础分为零。仍适用船长特权、海港与灯塔奖励；可以与码头在不同装船轮次分别使用。私人装运可以放弃，不受公共货船的种类与容量限制。",
				lighthouse: "船长阶段每次实际装运货物，取得 1 枚钱币，公共货船和两种私人码头均适用。如果自己选择了船长，本阶段还额外取得 1 枚钱币，即使没有装运。选择船长的钱币奖励每阶段仅一次；图书馆不会将这项建筑奖励加倍。",
				specialtyFactory: "每个工匠阶段，在自己正常生产取得的非玉米货物中，选择桶数最多的一种。取得该桶数减一的钱币，最低为零；例如生产 4 桶糖可取得 3 枚钱币。玉米不参与计算；选择者随后取得的额外货桶不重新计算奖励。",
				library: "自己选择角色时，该角色特权加倍；跟随其他玩家时不获得角色特权。拓荒者可以取得第二块田地，须等其他玩家完成正常取地后再取。第二块可选剩余公开种植园；只有建筑小屋启用时，才可改选采石场。第二块不能使用济贫院；仍须有空种植区，可以放弃领取。建筑师优惠变为 2 枚钱币；工头从普通供应额外取得 2 名工人。工匠可额外取得两桶本次实际生产过的货物，可以同种，也可以不同种。商人成功出售时额外取得 2 枚钱币；船长首次实际装运额外取得 2 分。勘探者取得 2 枚钱币；这些奖励仍受各角色原有条件限制。图书馆不加倍角色牌积币、其他建筑奖励或海盗行动。",
				unionHall: "每个船长阶段，在自己首次行动之前，按此时拥有的货物取得胜利分筹码。每种货物分别计算，每满两桶取得 1 分，不同种类的零散货桶不能合并。例如三桶玉米、一桶咖啡与两桶靛蓝，合计取得 2 分。计分不消耗货物，此后仍可正常装船、皇家供应或仓储。",
				cloister: "终局时本建筑须有人员上岗，按自己同类田地每三块组成一组。各类种植园分别计算，采石场与森林也各算一类，同一种可组成多组。一组取得 1 分，两组取得 3 分，三组取得 6 分，四组取得 10 分，零组没有奖励。例如六块玉米种植园与三块森林共组成三组，取得 6 分；田地无须上岗。",
				statue: "本建筑占两格城市，没有工位，不需要安排人员。终局按印刷值计入 8 分，没有另行启用的额外计分能力。雕像属于第四行建筑，采石场优惠上限为 4 枚钱币。",
				districtOffice: "普通工人上岗时，购买小型建筑的费用减少 1 枚钱币。贵族上岗时，改为购买大型建筑的费用减少 2 枚钱币。两种能力不同时生效；可以叠加其他优惠，最终费用最低为零。",
				royalSupplier: "每个船长阶段，在自己首次正常装船行动前，可以向皇家供应一次货物。每种货物最多交出一桶，总桶数不超过自己拥有的贵族人数，港口贵族也计入。交出的货桶立即归还公共供应，每桶取得 1 分胜利分筹码。不享有船长、海港或灯塔的额外奖励；供应后仍按正常船长规则继续行动。",
				chapel: "每个工匠阶段开始时，普通工人上岗取得 1 枚钱币，贵族上岗取得 1 分胜利分筹码。即使本阶段没有生产货物，仍可取得对应奖励；每阶段只结算一次。",
				jeweler: "工匠阶段轮到自己生产时，自己每名贵族带来 1 枚钱币，港口贵族也计入。本建筑不生产货桶，也不需要对应种植园；没有生产其他货物时仍可取得钱币。公会会馆将本建筑视为大型生产建筑，市政厅不将其视为商业建筑。",
				villa: "每个工头阶段，自己首次收到人员时，额外从贵族供应取得一名贵族，放入港口。工头特权取得人员也会触发；同一阶段不能因以后再领取人员而重复触发。贵族供应用尽时改取一名普通工人；两种供应均用尽时没有额外人员。",
				huntingLodge: "拓荒者阶段结束时，普通工人上岗可以弃置自己一块种植园或森林，不能弃采石场。被弃田地上的人员移至自己的港口，弃置田地进入种植园弃置堆。贵族上岗时，比较所有玩家的空种植区；自己严格最多则取得 2 分胜利分筹码。其他玩家的弃置先完成，再比较空格；并列最多没有奖励，无须自己选择拓荒者。",
				landOffice: "每个商人阶段可使用一次，可以在自己出售货物之前或之后使用。普通工人上岗时，可以支付 1 枚钱币，抽取并放置一块暗置种植园，须有空格。贵族上岗时，可以出售自己一块种植园或森林，取得 1 枚钱币，不能出售采石场。出售田地上的人员移至港口，田地进入弃置堆；本能力不占出售货物的次数。林务所启用时，购买的新种植园可以改为森林。",
				royalGarden: "终局时本建筑须有人员上岗，自己每名贵族额外取得 1 分。种植园、建筑与港口中的贵族均计入，连同贵族基础分，每名共计 2 分。"
			},
			event: {
				piracy: "{{name}}劫掠货船并保留了 {{n}} 桶{{item}}",
				plunder: "{{name}}掠夺交易所，取得 {{n}} 分",
				raid: "{{name}}袭击招聘所，安置了 {{n}} 名人员",
				kidnap: "{{name}}劫持了{{item}}",
				ransom: "{{name}}因{{item}}被选择而取得三枚钱币",
				festivalPlantation: "{{name}}完成种植目标，取得 {{n}} 名工人",
				festivalProduction: "{{name}}完成生产目标，取得三枚钱币",
				festivalBuilding: "{{name}}完成建筑目标，取得三分",
				recruit: "{{name}}领取了一名人员",
				removePlantation: "{{name}}移除了{{item}}",
				buyLand: "{{name}}花费一枚钱币购买了一块种植园",
				royalSupply: "{{name}}向皇家供应了 {{n}} 桶货物",
				mixedShip: "{{name}}通过小型码头装运了 {{n}} 桶货物",
				draft: "{{name}}将{{item}}加入建筑市场",
				guest: "{{name}}安置了一名旅馆客人",
				role: "{{name}}选择了{{item}}",
				plant: "{{name}}取得了{{item}}",
				build: "{{name}}建造了{{item}}，支付 {{n}} 枚钱币",
				assign: "{{name}}安排了 {{n}} 名工人",
				produce: "{{name}}取得了 {{n}} 桶货物",
				trade: "{{name}}出售了{{item}}，获得 {{n}} 枚钱币",
				ship: "{{name}}装载了 {{n}} 桶{{item}}",
				store: "{{name}}保留了 {{n}} 桶货物"
			}
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Puerto Rico",
			desc: "Choose roles, develop your island, produce, trade and ship goods. Uses the 2020 edition rules.",
			rules: "Object of the game:\n· Earn victory points by developing plantations, constructing buildings, producing goods and shipping cargo.\n· The player with the highest final score wins; resolve ties as described at the end of these rules.\n· These rules use the 2020 edition; expansion rules apply only when their respective options are enabled.\nGame components:\n· Each player has an island with 12 plantation spaces and 12 city spaces.\n· Each plantation, quarry or forest occupies one plantation space.\n· A small building occupies one city space; a large building occupies two.\n· People are ordinary workers or nobles; people without a workplace remain in their owner's harbor.\n· Each plantation and quarry has one workplace; each building has the number of workplaces shown on it.\n· An occupied workplace is staffed; unstaffed plantations do not produce, and unstaffed buildings have no active ability.\n· Forests and the Statue have no workplaces; their special rules appear under the relevant buildings.\n· Goods are corn, indigo, sugar, tobacco and coffee, counted in barrels.\n· Coins pay for buildings and other expenses; victory point tokens record points earned during play.\n· Goods, people and victory point tokens have shared supplies; coins are not limited.\n· Your goods and harbor personnel belong to you and are separate from the shared supplies.\n· Coins, goods and personnel are public; each player's victory point tokens remain private until final scoring.\nSetup:\n· After choosing the player count and expansions, establish clockwise seating order.\n· The first player is the governor for round one; the governorship then passes clockwise.\n· Each player starts with 2 coins in a three-player game, 3 in a four-player game, or 4 in a five-player game.\n· With three or four players, the first two players start with an indigo plantation each; the others start with corn.\n· With five players, the first three players start with indigo; the last two start with corn.\n· Starting plantations are unstaffed; players begin without buildings, goods, people or victory point tokens.\n· With three players, set aside 76 points in tokens, 55 ordinary workers in supply and 3 in recruitment.\n· With four players, set aside 101 points in tokens, 75 ordinary workers in supply and 4 in recruitment.\n· With five players, set aside 126 points in tokens, 95 ordinary workers in supply and 5 in recruitment.\n· These worker quantities apply to the base game; the Nobles expansion changes the personnel supplies.\n· With three players, use three public cargo ships with capacities of 4, 5 and 6 barrels.\n· With four players, use public ships with capacities of 5, 6 and 7 barrels.\n· With five players, use public ships with capacities of 6, 7 and 8 barrels.\n· The goods supply contains 10 corn, 11 indigo, 11 sugar, 9 tobacco and 9 coffee barrels.\n· Plantation totals are 10 corn, 12 indigo, 11 sugar, 9 tobacco and 8 coffee, including starting plantations.\n· Deal the starting plantations, then shuffle the remaining plantations into a face-down draw pile.\n· Reveal one more plantation than the number of players, and set aside 8 quarries.\n· The trading house and all public ships start empty; role cards start without coins.\n· Use the six main roles: Settler, Builder, Foreman, Craftsman, Trader and Captain.\n· Use no Prospector with three players, one Prospector with four, or two Prospectors with five.\n· The two Prospector cards are separate role cards and may both be chosen in the same round.\n· Without New Buildings, the base buildings enter the market directly; noble buildings are added when Nobles is enabled.\n· With three to five players, use 4 copies of each small production building and 3 of each other base production building.\n· Use 2 copies of each small commercial building and 1 of each large building.\nTwo-player game:\n· Both players start with 3 coins; the first starts with indigo and the second with corn.\n· Set aside 65 points in tokens, 40 ordinary workers in supply and 2 ordinary workers in recruitment.\n· Use two public ships with capacities of 4 and 6 barrels, and include one Prospector.\n· Remove 2 barrels of each good and 3 plantations of each type from the usual totals.\n· Use only 5 quarries, 1 copy of each commercial building and 2 of each production building.\n· Players alternate role choices three times each per round, resolving six role phases in total.\n· Prepare the selected expansions before applying the two-player quantity adjustments.\n· Additional Nobles and Festival setup details appear in their expansion sections.\nRound sequence:\n· Starting with the governor, take turns clockwise choosing a role card that has not yet been chosen this round.\n· Take all accumulated coins from the chosen card, then resolve that role's phase.\n· The chooser acts first and receives the role's privilege.\n· Other players follow clockwise, performing the role's action without the chooser's privilege.\n· Only the chooser acts for the Prospector and Buccaneer; other players do not follow.\n· Finish the entire role phase before the next player chooses a role.\n· With three to five players, each chooses one role per round; with two players, each chooses three.\n· Chosen role cards remain unavailable until the next round.\n· At round end, place 1 coin on each unchosen role card; the Buccaneer never accumulates coins.\n· Make all role cards available again, pass the governorship clockwise and begin the next round.\nSettler phase:\n· Each player may take one face-up plantation and place it in an empty plantation space on their island.\n· The chooser may take a quarry from supply instead of a face-up plantation.\n· A player may decline; a player whose 12 plantation spaces are occupied cannot acquire another tile.\n· Newly acquired plantations and quarries arrive unstaffed and work only after receiving personnel.\n· The Hacienda, Construction Hut, Hospice, Library and Forest House provide exceptions described below.\n· After all players finish, discard the remaining face-up plantations and reveal the player count plus one new tiles.\n· When the draw pile runs out, shuffle the discarded plantations to form a new draw pile.\n· Quarries do not enter the plantation draw pile and are limited by their shared supply.\nBuilder phase:\n· Each player may pay coins to buy one building from the market, or decline.\n· The building must be in stock, and the player's city must have enough empty spaces for it.\n· A player cannot own two buildings with the same name and may buy at most one building per action.\n· The chooser pays 1 coin less for construction.\n· Each of the player's staffed quarries reduces the cost by 1 coin, subject to the building's market-row limit.\n· Quarries save at most 1, 2, 3 or 4 coins in total for buildings in rows one through four respectively.\n· Use the market row to determine this limit; the Statue is in row four and permits at most 4 coins of quarry savings.\n· Forests, the District Office and the role privilege provide additional cumulative discounts; the final cost cannot be negative.\n· New buildings normally arrive unstaffed; the University may immediately staff one workplace in a new building.\n· A completed building immediately occupies city spaces; filling all 12 triggers the end of the game after the round.\nForeman phase:\n· The chooser first takes 1 extra ordinary worker from supply into their harbor.\n· If the ordinary worker supply is empty, recruitment cannot replace this privilege worker.\n· Starting with the chooser, distribute recruitment personnel clockwise, one person per turn.\n· Continue until recruitment is empty; some players receive one extra person if the total is not evenly divisible.\n· Each player may rearrange all their personnel, including those already working and those in their harbor.\n· Each workplace holds at most one person; forests and the Statue cannot receive personnel.\n· If personnel are fewer than workplaces, choose which workplaces to fill, but assign every person.\n· If personnel exceed workplaces, fill every workplace and leave the surplus in your harbor.\n· At phase end, count empty workplaces in all players' buildings, excluding empty plantation and quarry workplaces.\n· The next recruitment total is the greater of that count and the number of players.\n· Refill recruitment from the worker supply; in the base game, a shortage triggers the end of the game after the round.\n· Nobles changes personnel types, recruitment choices and the shortage end condition as described below.\nCraftsman phase:\n· Each player takes goods from supply according to their staffed plantations and production buildings.\n· Each staffed corn plantation produces up to 1 corn barrel without a production building.\n· Every other good requires both a matching staffed plantation and a staffed workplace in its production building.\n· Production equals the smaller of the matching staffed plantation count and staffed production-building workplaces.\n· For example, three staffed indigo plantations and two staffed indigo production workplaces produce at most 2 barrels.\n· Players take goods in action order from the same supply; a shortage limits production to the barrels still available.\n· Players may take fewer barrels or none of a good; unused production is not made up later.\n· After everyone produces, the chooser may take 1 extra barrel of a good they actually produced in this phase.\n· The extra barrel must be available in supply; producing no goods gives no extra barrel.\n· The Factory and Specialty Factory use regular production for their coin awards; privilege barrels do not recalculate those awards.\nTrader phase:\n· Each player may sell one barrel they own, or decline to sell.\n· Base prices are 0 coins for corn, 1 for indigo, 2 for sugar, 3 for tobacco and 4 for coffee.\n· The chooser receives 1 additional coin for a completed sale; declining to sell gives no privilege income.\n· The trading house holds at most four barrels; normally, a good already present cannot be sold there again.\n· The Office permits duplicate goods, and the Trading Post permits a private sale, as described under those buildings.\n· Corn may be sold even at a base price of zero and still earns applicable privilege and market bonuses.\n· At the end of the entire phase, return all trading-house barrels to supply only if all four spaces are occupied.\n· If the trading house is not full, its goods remain for later Trader phases rather than clearing each round.\nCaptain phase:\n· Starting with the chooser, players repeatedly take loading turns clockwise until nobody continues shipping.\n· Each public loading contains one type of good; the player chooses which eligible type to ship.\n· A player who can load a public ship cannot simply pass, but may use an available private shipment first.\n· Each public ship carries one good; two public ships cannot carry the same good simultaneously.\n· If a ship already carries the chosen good, use that ship and load as many barrels as its remaining space allows.\n· If that good's ship is full, an empty ship cannot be started with the same good.\n· If no ship carries that good, choose an empty ship that can take the greatest number of your barrels of that good.\n· Load the maximum number the chosen ship can take; voluntarily loading fewer is not allowed.\n· If either of two ships can take all your barrels of the chosen good, either ship may be chosen.\n· For example, with 5 corn barrels and empty ships of capacity 4 and 6, load all 5 onto the capacity-6 ship.\n· Gain 1 point in victory point tokens for each barrel actually shipped.\n· Shipping a good does not require you to own or staff its corresponding production building.\n· The chooser gains 1 extra point on their first actual shipment of the phase, once per phase.\n· A chooser who ships no goods receives no privilege points.\n· The Wharf and Small Wharf provide private shipments with their own usage, cargo and scoring rules.\n· Private shipping is optional; a player may receive several loading turns during the phase.\n· Full public ships unload only at the end of the entire Captain phase, returning their cargo to supply.\n· Full ships do not clear during loading turns; ships that are not full retain their cargo between phases.\nStorage:\n· After all shipping ends, each player chooses which unshipped goods to keep.\n· Without storage buildings, each player may keep only one barrel in total, of a type they choose.\n· A Small Warehouse preserves every barrel of one additional good; a Large Warehouse preserves two additional goods.\n· If both Warehouses are active, preserve every barrel of three additional goods.\n· The ordinary single barrel may be a good other than those preserved by Warehouses.\n· The Storehouse adds capacity for three barrels of any goods and combines with both Warehouses.\n· For example, a Small Warehouse can preserve all 4 corn barrels, while the ordinary allowance keeps 1 coffee barrel.\n· Return every barrel beyond storage capacity to supply; storing goods costs no coins.\nProspector phase:\n· Only the chooser takes 1 coin from the coin supply; other players do not act.\n· This coin is separate from any accumulated coins taken from the role card.\nBuilding rules:\n· Except for the Statue, a building needs at least one person in a workplace for its ability to operate.\n· A production building's staffed workplaces determine its capacity; one person does not activate its full capacity.\n· Printed building points count at game end regardless of whether the building is staffed.\n· A large building must be staffed at game end to provide its additional scoring ability.\n· Resolve an ability only at its stated time; staffing a building afterward does not grant earlier missed benefits.\n· Different building abilities may combine, subject to each ability's conditions, usage limits and quantities.\n· In the building rules below, nobles may replace workers unless the ability explicitly distinguishes personnel types.\nProduction:\nSmall Indigo Plant:\n· This building has one workplace; when staffed and matched with a staffed indigo plantation, it produces up to 1 indigo barrel.\n· Production is limited by the shared goods supply; without a matching staffed plantation, it produces nothing.\nSmall Sugar Mill:\n· This building has one workplace; when staffed and matched with a staffed sugar plantation, it produces up to 1 sugar barrel.\n· Production is limited by the shared goods supply; without a matching staffed plantation, it produces nothing.\nIndigo Plant:\n· This building has 3 workplaces; each staffed workplace provides capacity for 1 indigo barrel.\n· Each barrel also requires a matching staffed plantation; the building produces at most 3 barrels in total.\n· The shared supply limits the barrels received; capacities from different buildings producing the same good may be combined.\nSugar Mill:\n· This building has 3 workplaces; each staffed workplace provides capacity for 1 sugar barrel.\n· Each barrel also requires a matching staffed plantation; the building produces at most 3 barrels in total.\n· The shared supply limits the barrels received; capacities from different buildings producing the same good may be combined.\nTobacco Storage:\n· This building has 3 workplaces; each staffed workplace provides capacity for 1 tobacco barrel.\n· Each barrel also requires a matching staffed plantation; the building produces at most 3 barrels in total.\n· The shared supply limits the barrels received; capacities from different buildings producing the same good may be combined.\nCoffee Roaster:\n· This building has 2 workplaces; each staffed workplace provides capacity for 1 coffee barrel.\n· Each barrel also requires a matching staffed plantation; the building produces at most 2 barrels in total.\n· The shared supply limits the barrels received; capacities from different buildings producing the same good may be combined.\nBase commerce:\nSmall Market:\n· When you sell a barrel to the trading house during a Trader phase, gain 1 additional coin.\n· This combines with the Trader privilege and Large Market; it does not apply to private Trading Post sales.\nHacienda:\n· Once per Settler phase, before your regular tile-taking action, you may draw one additional face-down plantation.\n· You must have an empty plantation space before drawing and must place the tile on your island rather than reject it.\n· The Hacienda tile does not receive a Hospice person; an active Forest House allows it to become a forest.\n· If only one space remains and the Hacienda tile fills it, you cannot take a regular tile afterward.\nConstruction Hut:\n· During a Settler phase, you may take a quarry instead of a face-up plantation even when you did not choose the role.\n· This also permits a quarry for the Library's second tile, provided one remains in supply.\nSmall Warehouse:\n· During Captain-phase storage, keep every barrel of one good in addition to the ordinary one-barrel allowance.\n· Choose the preserved good yourself; this ability combines with the Large Warehouse and Storehouse.\nHospice:\n· When taking your first regular plantation or quarry in a Settler phase, you may immediately staff it with one person.\n· Take an ordinary worker from supply first; if that supply is empty, take an available person from recruitment instead.\n· Recruitment may provide an ordinary worker or, when Nobles is enabled, an available noble.\n· Neither the extra Hacienda tile nor the Library's second tile receives a Hospice person.\n· If the regular plantation becomes a forest, place the received person in your harbor instead.\nOffice:\n· During a Trader phase, you may sell a good that is already present in the trading house.\n· The trading house still holds at most four barrels; the Office cannot permit a sale when it is full.\nLarge Market:\n· When you sell a barrel to the trading house during a Trader phase, gain 2 additional coins.\n· When both Markets are active, they provide a combined bonus of 3 coins.\n· The Trader privilege applies in addition; neither Market rewards a private Trading Post sale.\nLarge Warehouse:\n· During Captain-phase storage, keep every barrel of two goods in addition to the ordinary one-barrel allowance.\n· With an active Small Warehouse, preserve three additional goods in full; the Storehouse adds separate barrel capacity.\nFactory:\n· Each Craftsman phase, earn coins based on the number of different goods you actually receive from regular production.\n· Producing two types earns 1 coin, three earns 2, four earns 3, and five earns 5.\n· Producing zero or one type earns nothing; count types rather than the total number of barrels.\n· Corn counts as a type; the chooser's later extra barrels do not trigger a recalculation.\nUniversity:\n· When buying a new building with workplaces in a Builder phase, you may immediately take one person and place them in that building.\n· Take an ordinary worker from supply first; if it is empty, take an available ordinary worker or noble from recruitment.\n· Receive at most one person per new building, regardless of its number of workplaces.\n· Buying the University itself gives no such reward; the Statue has no workplace and cannot receive a person.\nHarbor:\n· Each time you actually ship goods in a Captain phase, gain 1 additional point in victory point tokens.\n· This applies to public ships, the Wharf and Small Wharf; award one point per shipment rather than per barrel.\n· It combines with the Captain privilege; Royal Supplier deliveries and Buccaneer actions are not shipments.\nWharf:\n· Once per Captain phase, you may use a private ship to ship every barrel you own of one chosen good.\n· This private ship has unlimited capacity and ignores goods already assigned to public ships and their loading status.\n· Gain 1 point per barrel and return the barrels to supply immediately; Captain, Harbor and Lighthouse bonuses apply.\n· Private shipping is optional; the Wharf and Small Wharf each have one use and may be used on separate loading turns.\nLarge buildings:\nGuild Hall:\n· This building must be staffed at game end to award the following bonus points.\n· Gain 1 point per Small Indigo Plant and Small Sugar Mill, and 2 points per other production building.\n· Counted production buildings need not be staffed; the Nobles expansion's Jeweler counts as a large production building.\nResidence:\n· If staffed at game end, this building awards bonus points for occupied plantation spaces on your island.\n· Occupying zero through nine spaces earns 4 points, ten earns 5, eleven earns 6, and twelve earns 7.\n· All plantations, quarries and forests count as occupied spaces, whether staffed or not.\nFortress:\n· If staffed at game end, this building awards 1 bonus point for every three people you own.\n· Count all personnel on plantations, quarries, buildings and in your harbor, including nobles; ignore any remainder below three.\nCustoms House:\n· If staffed at game end, this building awards 1 bonus point for every 4 points in your victory point tokens.\n· Ignore any remainder below 4; exclude printed building points, noble points and other endgame bonuses.\nCity Hall:\n· If staffed at game end, this building awards 1 bonus point for each commercial building you own.\n· Include the City Hall itself; the other commercial buildings need not be staffed.\n· Exclude all production buildings, including the Nobles expansion's Jeweler.\nNew Buildings draft:\n· With New Buildings enabled, draft the market from base commercial buildings, new commercial buildings and enabled noble commercial buildings.\n· Starting with the governor, take turns clockwise choosing one commercial building type not yet in the market.\n· The building's cost must match a remaining market slot; fill that slot with the chosen type.\n· Add two copies of each small commercial type, or one with two players; each large type has one copy.\n· Continue until every slot is filled; buildings not drafted cannot be bought in this game.\n· Production buildings enter automatically rather than being drafted; the Jeweler is also a production building.\n· With Nobles enabled, add its commercial building candidates and the corresponding extra market slots.\nBlack Market:\n· Use the Black Market only when your coins are insufficient to pay the construction cost.\n· Return at most one person, one barrel and 1 point in victory point tokens; each returned item pays for 1 coin of the cost.\n· Pay at most 3 coins this way; spend all your coins and return exactly enough items to cover the shortfall, with no change.\n· Personnel may come from your plantations, quarries, other buildings or harbor, but never from the Black Market itself.\n· Return ordinary workers and nobles to their respective supplies, and return goods and tokens to theirs.\n· If returning personnel disables a quarry, District Office or Library, recalculate the final construction cost without its discount.\n· Returning tokens or people does not cancel an end condition that has already been triggered.\nForest House:\n· While this building is active, you may place newly acquired plantations as forests; tiles already on your island cannot be converted.\n· You may also inspect a face-down plantation drawn by the Hacienda or bought through the Land Office before deciding to make it a forest.\n· Quarries cannot become forests; a forest occupies one plantation space, has no workplace and produces no goods.\n· Each pair of forests you own reduces every construction cost by 1 coin, cumulatively with other discounts.\n· Existing forests keep their discount even if the Forest House becomes unstaffed; all forests count as one tile type.\nAqueduct:\n· During a Craftsman phase, a staffed Indigo Plant or Sugar Mill that can produce normally with matching plantations produces 1 extra barrel of its good.\n· Only the large Indigo Plant and Sugar Mill qualify; the Small Indigo Plant and Small Sugar Mill do not.\n· If both large buildings qualify, produce 1 extra indigo and 1 extra sugar barrel, subject to the shared supply.\nStorehouse:\n· During Captain-phase storage, keep three additional barrels of any goods; they need not be of one type.\n· Together with the ordinary single barrel, this preserves four barrels; either Warehouse adds its full-type storage separately.\nGuesthouse:\n· This building has two workplaces that may receive guests during a Foreman phase, including nobles.\n· At the beginning, during or end of a phase, you may move guests to other legal empty workplaces on your island.\n· Plantations, quarries and buildings may receive guests; the two guests may move at different times.\n· A guest activates the destination immediately, but does not grant ability rewards whose timing has already passed.\n· Once moved, that person cannot move again until the next Foreman phase or return to the Guesthouse for repeated use.\nChurch:\n· When constructing a row-two or row-three building in a Builder phase, gain 1 point in victory point tokens.\n· Gain 2 points for a row-four building and no points for a row-one building.\n· Constructing the Church itself gives no reward; these tokens do not replace the new building's printed points.\nTrading Post:\n· During a Trader phase, you may sell one barrel through your own Trading Post instead, returning it directly to supply.\n· A private sale ignores whether the trading house is full or already contains the good.\n· The Trader privilege still applies, but Small Market and Large Market coin bonuses do not.\n· This building does not grant another sale; you still sell at most one barrel per Trader phase.\nSmall Wharf:\n· Once per Captain phase, ship any number of barrels of any goods, including mixed cargo.\n· You may ship only part of your stock; gain 1 point per two barrels, ignoring an unmatched barrel for base points.\n· Ship at least one barrel and return all cargo to supply immediately; a one-barrel shipment has zero base points.\n· Captain, Harbor and Lighthouse bonuses still apply; this and the Wharf may be used on separate loading turns.\n· This private shipment is optional and ignores public ships' assigned goods and capacities.\nLighthouse:\n· Each actual shipment during a Captain phase earns 1 coin, whether made on a public ship or through either private Wharf.\n· If you chose the Captain, gain 1 further coin during the phase even if you ship nothing.\n· The chooser's additional coin is awarded once per phase; the Library does not double this building bonus.\nSpecialty Factory:\n· Each Craftsman phase, find the largest number of barrels of one non-corn good received from your regular production.\n· Gain that number minus one in coins, with a minimum of zero; for example, producing 4 sugar barrels earns 3 coins.\n· Exclude corn; extra barrels later taken through the role privilege do not recalculate the award.\nLibrary:\n· When you choose a role, double its privilege; following another player's role gives you no role privilege.\n· As Settler, you may take a second tile after every other player has completed their regular tile-taking action.\n· For the second tile, choose a remaining face-up plantation; a quarry requires an active Construction Hut.\n· The second tile receives no Hospice person; you need an empty plantation space and may decline it.\n· The Builder discount becomes 2 coins; the Foreman takes 2 extra ordinary supply workers.\n· The Craftsman may take 2 extra barrels of goods actually produced in the phase, either matching or different.\n· A completed Trader sale earns 2 extra coins; the Captain's first actual shipment earns 2 extra points.\n· The Prospector takes 2 coins; all these privileges retain their original role conditions.\n· The Library does not double role-card coin accumulations, other building rewards or Buccaneer actions.\nUnion Hall:\n· Once per Captain phase, before your first action, gain victory point tokens based on the goods you own at that time.\n· Count each good separately and gain 1 point per two barrels; unmatched barrels of different goods cannot be combined.\n· For example, three corn, one coffee and two indigo barrels earn 2 points in total.\n· Scoring does not consume the goods; they remain available for normal shipping, royal supply or storage afterward.\nCloister:\n· If staffed at game end, this building awards points for groups of three matching tiles on your island.\n· Count each plantation type separately; quarries and forests are separate types, and one type may form multiple groups.\n· One group earns 1 point, two earn 3, three earn 6 and four earn 10; zero groups earn nothing.\n· For example, six corn plantations and three forests form three groups and earn 6 points; the tiles need not be staffed.\nStatue:\n· This building occupies two city spaces, has no workplace and requires no personnel.\n· It provides its printed value of 8 points at game end and has no separate activated scoring ability.\n· The Statue is a row-four building, so its quarry discount is limited to 4 coins.\nNobles expansion:\n· Add 20 nobles and eight noble building types; nobles may replace ordinary workers in any legal workplace.\n· Some noble buildings provide different abilities depending on whether an ordinary worker or noble staffs them.\n· With three to five players, use all 100 ordinary workers; the initial recruitment total equals the player count.\n· Initially, one recruit is a noble and the rest are ordinary workers; the separate noble supply contains 19.\n· The remaining ordinary worker supply is therefore 98 with three players, 97 with four, or 96 with five.\n· With two players, start with two ordinary recruits, 40 ordinary supply workers and all 20 nobles in supply.\n· In a two-player game, nobles first enter recruitment on the first refill.\n· On each recruitment refill, replace one ordinary worker in the target total with a noble if supplies allow.\n· Even when ordinary workers are insufficient, add at most one noble; recruitment may contain fewer people than the target total.\n· On each recruitment turn during a Foreman phase, choose an available ordinary worker or noble.\n· The Foreman privilege still draws only ordinary supply workers; the Library does not turn that privilege into noble recruitment.\n· At game end, each noble you own is worth 1 point, including nobles on plantations, in buildings and in your harbor.\n· Recruitment shortages no longer end the game; filling a city or exhausting victory point tokens still triggers the end.\nDistrict Office:\n· With an ordinary worker staffing this building, a small building costs 1 coin less.\n· With a noble staffing it, a large building costs 2 coins less instead.\n· These two abilities are alternatives, not simultaneous; other discounts combine with them, and final cost cannot be negative.\nRoyal Supplier:\n· Once per Captain phase, before your first normal loading turn, you may supply goods to the royal court.\n· Supply at most one barrel of each good, with the total no greater than your noble count, including harbor nobles.\n· Return the supplied barrels to the shared supply immediately and gain 1 point in victory point tokens per barrel.\n· Captain, Harbor and Lighthouse bonuses do not apply; afterward, continue under the normal Captain rules.\nChapel:\n· At the beginning of each Craftsman phase, gain 1 coin if an ordinary worker staffs this building, or 1 point in tokens if a noble does.\n· Receive the applicable reward even if you produce no goods that phase; resolve it only once per phase.\nJeweler:\n· On your production turn in a Craftsman phase, gain 1 coin per noble you own, including those in your harbor.\n· This building produces no barrels and needs no plantation; it earns coins even if you produce no other goods.\n· The Guild Hall counts it as a large production building; the City Hall does not count it as a commercial building.\nVilla:\n· The first time you receive personnel in each Foreman phase, take one additional noble from supply into your harbor.\n· Receiving a Foreman privilege worker also triggers this; later recruitment in the same phase does not trigger it again.\n· If no nobles remain in supply, take one ordinary supply worker instead; if both supplies are empty, take nobody extra.\nHunting Lodge:\n· At the end of a Settler phase, an ordinary worker lets you discard one of your plantations or forests, but not a quarry.\n· Move any person on the discarded tile to your harbor and put the tile into the plantation discard pile.\n· With a noble, compare all players' empty plantation spaces; gain 2 points in tokens only if you alone have the most.\n· Finish any tile discards before comparing empty spaces; a tie earns nothing, and you need not have chosen Settler.\nLand Office:\n· Use this ability once per Trader phase, either before or after your sale of goods.\n· With an ordinary worker, pay 1 coin to draw and place a face-down plantation, provided you have an empty plantation space.\n· With a noble, sell one plantation or forest you own for 1 coin; quarries cannot be sold.\n· Move any person from a sold tile to your harbor and discard the tile; this does not use your sale of goods.\n· With an active Forest House, a newly bought plantation may be placed as a forest.\nRoyal Garden:\n· If staffed at game end, this building awards 1 additional point for every noble you own.\n· Count nobles on plantations, in buildings and in your harbor; including each noble's base point, each is worth 2 points in total.\nBuccaneer expansion:\n· Add the Buccaneer to the existing roles; its chooser takes the Buccaneer token and performs one of the following four actions.\n· Other players do not follow Buccaneer actions, and the Library does not double them.\n· The token holder cannot choose Buccaneer again until another player chooses it and takes the token.\n· The Buccaneer card accumulates no coins when left unchosen.\nPiracy:\n· Choose a public cargo ship containing goods and empty it completely.\n· Keep zero to three of its barrels in your own stock and return the rest to supply.\n· The cleared ship becomes empty again; Piracy is not shipping and earns no shipping points or related building rewards.\nPlunder:\n· Return every barrel in the trading house to supply and gain 1 point in victory point tokens per barrel returned.\n· Plunder is neither a sale nor a shipment and receives no Trader, Captain, Market, Harbor, Lighthouse or similar bonuses.\nRaid:\n· Raid is available only if recruitment contains more people than the player count; remove people until that many remain.\n· Keep up to three removed people and immediately place them in legal empty workplaces of your own.\n· Empty plantation, quarry and building workplaces may receive them; these people cannot be left in your harbor.\n· Return unkept people to their respective supplies; with Nobles, choose the personnel types left behind and taken.\nKidnap:\n· Choose an unchosen role card other than Buccaneer and immediately take all accumulated coins on it.\n· If an opponent chooses that role later in the round, gain a ransom of 3 coins.\n· That opponent still resolves the role normally with its privilege; Kidnap does not cancel their action.\n· If you later choose the role yourself, receive no ransom and do not resolve an extra copy at round end.\n· If nobody chooses the role that round, the Buccaneer resolves it as an extra role at round end, receiving its privilege.\n· Other players follow under that role's normal rules; finish this extra phase before scoring even if the game end has been triggered.\nFestival expansion:\n· The game has three public goals: plantation, production and building; each rewards only its first achiever, once.\n· One player may claim several goals; resolve a reward immediately when its condition is met, without a separate claim action.\n· Temporarily remove the plantation tile, three goods barrels and building used to display the goals from their respective supplies.\n· When a goal is achieved, return its display components to their supplies rather than giving them to the achiever.\n· Players do not surrender the plantations, goods or buildings they used to meet a goal.\nPlantation goal:\n· Randomly choose a plantation type; the first player to own three plantations of that type earns the reward, whether staffed or not.\n· Take up to three ordinary supply workers into your harbor, where they wait for a later opportunity to be assigned.\n· If the ordinary supply is insufficient, take only those remaining; do not draw from recruitment or substitute nobles.\nProduction goal:\n· Draw three barrels from a pool containing three of each of the five goods; repeated types are possible.\n· Gain 3 coins when the types and quantities you actually produce within one Craftsman phase satisfy the displayed requirements.\n· Extra Craftsman privilege barrels count; existing stock and production from different phases do not accumulate toward the goal.\n· For a goal of two sugar and one coffee, for example, produce at least those quantities within a single Craftsman phase.\nBuilding goal:\n· Randomly choose a building from the third row of this game's market as the goal.\n· Exclude production buildings whose good appears in the production goal.\n· The first player to construct the designated building gains 3 points in victory point tokens; the new building need not be staffed.\nEnding the game:\n· The game end is triggered when any player's city fills all 12 spaces or the shared victory point token supply is exhausted.\n· Without Nobles, failing to refill recruitment to the required total after a Foreman phase also triggers the end.\n· Filling a plantation area or exhausting the plantation draw pile or goods supply does not itself end the game.\n· After a trigger, finish all remaining roles in the round, including any extra round-end role required by Kidnap.\n· Continue recording all earned victory points after tokens run out; the shortage does not reduce awards.\n· Then proceed directly to final scoring without starting another round.\nScoring and victory:\n· Your total is your victory point tokens, all printed building points, active large-building bonuses and noble points.\n· All printed building points count without staffing; a large building must be active at game end to award its extra bonus.\n· Ordinary workers, remaining coins and goods do not directly add points except through an explicitly applicable building ability.\n· The highest total wins; tied players compare the sum of their remaining coins and goods barrels.\n· Every barrel counts as one regardless of its selling price; the higher combined total wins the tie.\n· For example, 5 remaining coins and 3 goods barrels give a tiebreak total of 8.\n· If both the score and tiebreak total remain equal, those players share the victory.",
			optNewBuildings: "New Buildings",
			optNobles: "Nobles",
			optNoblesHint: "Add nobles, eight buildings and noble scoring.",
			optBuccaneer: "Buccaneer",
			optBuccaneerHint: "Add the Buccaneer role with piracy, plunder, raids and kidnapping.",
			optFestival: "Festival",
			optFestivalHint: "Reward the first player to meet each plantation, production and building goal.",
			buccaneerPrompt: "Choose a Buccaneer action",
			piracy: "Raid cargo ship {{n}}",
			piracyKeep: "Barrels to keep",
			plunder: "Plunder the trading house",
			raid: "Raid recruitment",
			kidnap: "Kidnap {{role}}",
			kidnapped: "{{name}} has kidnapped {{role}}",
			pirateToken: "{{name}} holds the Buccaneer token",
			confirmRaid: "Confirm raid and placements",
			cancelRaid: "Cancel raid",
			leaveNobles: "Nobles left in recruitment",
			raidPlaced: "{{n}} / {{max}} people placed",
			festival: "Festival",
			festivalPlantation: "Plantation goal: three {{good}} plantations",
			festivalProduction: "Production goal",
			festivalBuilding: "Building goal",
			festivalWorkers: "Reward: three workers",
			festivalCoins: "Reward: three coins",
			festivalVP: "Reward: three VP",
			claimedBy: "Claimed by {{name}}",
			takeNoble: "Take one noble",
			takeWorker: "Take one worker",
			assignNobles: "Assign nobles",
			recruitPrompt: "Choose a person to recruit",
			landPrompt: "Use the Land Office or continue",
			huntingPrompt: "Discard a plantation or forest, or pass",
			royalPrompt: "Supply different goods to the royal court",
			supplyRoyal: "Confirm royal supply",
			royalCargo: "Royal supply goods",
			buyLand: "Buy a hidden plantation for one coin",
			nobleCount: "{{n}} nobles",
			harborNobles: "{{n}} harbor nobles",
			recruitmentNobles: "{{n}} recruitment nobles",
			nobleSupply: "{{n}} nobles in supply",
			returnNoble: "One noble from {{place}}",
			noblesScore: "Noble points",
			optNewBuildingsHint: "Draft commercial buildings into matching-cost market spaces.",
			draftBuilding: "Add to market",
			draftPrompt: "Draft the building market",
			guestPrompt: "Move a guest or continue the phase",
			forestPrompt: "Choose how to place the plantation",
			extraSettler: "Library: choose a second tile",
			continuePhase: "Continue phase",
			asForest: "Place as a forest",
			keepPlantation: "Place as a plantation",
			blackMarketPayment: "Return to the Black Market",
			returnWorker: "One worker from {{place}}",
			returnGood: "One {{good}} barrel",
			returnVP: "One VP token",
			useSmallWharf: "Ship via Small Wharf",
			smallWharfCargo: "Small Wharf cargo",
			sellPrivately: "Sell one {{good}} at your post",
			brand: "PUERTO RICO",
			edition: "2020 Edition",
			round: "Round {{n}}",
			governor: "Governor",
			wait: "Waiting for {{name}}",
			you: "Your turn",
			selectRole: "Choose a role",
			island: "{{name}}’s island",
			plantations: "Plantations",
			city: "City",
			harbor: "Harbor",
			market: "Building market",
			islandTab: "Island",
			rolesTab: "Roles",
			boardAreas: "Game areas",
			shipCapacity: "Cargo ship · {{n}}",
			recruitment: "Recruitment hall",
			workerSupply: "Worker supply",
			goodsSupply: "Goods supply",
			vpSupply: "VP remaining",
			money: "Coins",
			vp: "My VP tokens",
			unemployed: "Harbor workers",
			tradingHouse: "Trading house",
			cargoShips: "Cargo ships",
			privateShip: "Private ship",
			ship: "Ship {{n}}",
			cost: "Cost {{n}}",
			points: "{{n}} VP",
			stock: "{{n}} left",
			selectPlant: "Choose a plantation or quarry",
			selectBuilding: "Choose a building",
			assignWorkers: "Assign all workers",
			produceGoods: "Choose production amounts",
			selectBonus: "Choose an extra barrel",
			tradeGoods: "Choose one barrel to sell",
			shipGoods: "Choose goods and a ship",
			storeGoods: "Choose goods to keep",
			done: "Game over",
			confirm: "Confirm",
			build: "Build",
			assign: "Confirm workers",
			produce: "Confirm production",
			store: "Confirm storage",
			pass: "Pass this action",
			skipWharf: "Skip private ship",
			close: "Close",
			reset: "Reset",
			recommend: "Suggested assignment",
			workers: "Workers {{n}} / {{max}}",
			assignment: "{{n}} / {{max}} workers assigned",
			addWorker: "Add worker",
			removeWorker: "Remove worker",
			addGood: "Add {{good}}",
			removeGood: "Remove {{good}}",
			emptyField: "Empty plantation space",
			emptyCity: "Empty city space",
			active: "Active",
			inactive: "Inactive",
			useHospice: "Use Hospice for a worker",
			useUniversity: "Use University for a worker",
			useHacienda: "Hacienda: take a hidden plantation first",
			load: "Load {{n}} {{good}}",
			sell: "Sell one {{good}}",
			take: "Take {{good}}",
			production: "Production",
			keep: "Keep",
			noGoods: "No goods",
			noBuildings: "No buildings available to buy",
			endRound: "Final round",
			endWorkers: "Recruitment cannot be refilled",
			endCity: "A city is full",
			endVP: "VP supply exhausted",
			log: "Game log",
			tokensScore: "VP tokens",
			buildingsScore: "Building points",
			bonusScore: "Large-building bonuses",
			tieValue: "Coins and goods",
			errTurn: "Please wait for your turn.",
			errAction: "That action is unavailable. Please choose again.",
			errWorkers: "Assign every worker that can fit into a legal space.",
			errStorage: "The selected goods exceed your storage capacity.",
			errForced: "You can still load a public ship. Please ship goods first.",
			good: {
				forest: "Forest",
				corn: "Corn",
				indigo: "Indigo",
				sugar: "Sugar",
				tobacco: "Tobacco",
				coffee: "Coffee",
				quarry: "Quarry"
			},
			role: {
				settler: "Settler",
				builder: "Builder",
				mayor: "Foreman",
				craftsman: "Craftsman",
				trader: "Trader",
				captain: "Captain",
				prospector: "Prospector",
				buccaneer: "Buccaneer"
			},
			roleHelp: {
				buccaneer: "Only you perform one Buccaneer action. Its token prevents choosing it again.",
				settler: "Everyone takes a plantation; you may take a quarry.",
				builder: "Everyone may buy a building; you pay one coin less.",
				mayor: "Distribute and rearrange workers; you gain one extra worker.",
				craftsman: "Everyone produces; afterward you may take an extra barrel.",
				trader: "Everyone may sell one barrel; you earn one extra coin.",
				captain: "Ship for one VP per barrel; your first loading earns one extra VP.",
				prospector: "You take one coin. Nobody else acts."
			},
			building: {
				districtOffice: "District Office",
				royalSupplier: "Royal Supplier",
				chapel: "Chapel",
				jeweler: "Jeweler",
				villa: "Villa",
				huntingLodge: "Hunting Lodge",
				landOffice: "Land Office",
				royalGarden: "Royal Garden",
				blackMarket: "Black Market",
				forestHouse: "Forest House",
				aqueduct: "Aqueduct",
				storehouse: "Storehouse",
				guesthouse: "Guesthouse",
				church: "Church",
				tradingPost: "Trading Post",
				smallWharf: "Small Wharf",
				lighthouse: "Lighthouse",
				specialtyFactory: "Specialty Factory",
				library: "Library",
				unionHall: "Union Hall",
				cloister: "Cloister",
				statue: "Statue",
				smallIndigo: "Small Indigo Plant",
				smallSugar: "Small Sugar Mill",
				indigoPlant: "Indigo Plant",
				sugarMill: "Sugar Mill",
				tobaccoStorage: "Tobacco Storage",
				coffeeRoaster: "Coffee Roaster",
				smallMarket: "Small Market",
				hacienda: "Hacienda",
				constructionHut: "Construction Hut",
				smallWarehouse: "Small Warehouse",
				hospice: "Hospice",
				office: "Office",
				largeMarket: "Large Market",
				largeWarehouse: "Large Warehouse",
				factory: "Factory",
				university: "University",
				harbor: "Harbor",
				wharf: "Wharf",
				guildHall: "Guild Hall",
				residence: "Residence",
				fortress: "Fortress",
				customsHouse: "Customs House",
				cityHall: "City Hall"
			},
			buildingText: {
				smallIndigo: "This building has one workplace; when staffed and matched with a staffed indigo plantation, it produces up to 1 indigo barrel. Production is limited by the shared goods supply; without a matching staffed plantation, it produces nothing.",
				smallSugar: "This building has one workplace; when staffed and matched with a staffed sugar plantation, it produces up to 1 sugar barrel. Production is limited by the shared goods supply; without a matching staffed plantation, it produces nothing.",
				indigoPlant: "This building has 3 workplaces; each staffed workplace provides capacity for 1 indigo barrel. Each barrel also requires a matching staffed plantation; the building produces at most 3 barrels in total. The shared supply limits the barrels received; capacities from different buildings producing the same good may be combined.",
				sugarMill: "This building has 3 workplaces; each staffed workplace provides capacity for 1 sugar barrel. Each barrel also requires a matching staffed plantation; the building produces at most 3 barrels in total. The shared supply limits the barrels received; capacities from different buildings producing the same good may be combined.",
				tobaccoStorage: "This building has 3 workplaces; each staffed workplace provides capacity for 1 tobacco barrel. Each barrel also requires a matching staffed plantation; the building produces at most 3 barrels in total. The shared supply limits the barrels received; capacities from different buildings producing the same good may be combined.",
				coffeeRoaster: "This building has 2 workplaces; each staffed workplace provides capacity for 1 coffee barrel. Each barrel also requires a matching staffed plantation; the building produces at most 2 barrels in total. The shared supply limits the barrels received; capacities from different buildings producing the same good may be combined.",
				smallMarket: "When you sell a barrel to the trading house during a Trader phase, gain 1 additional coin. This combines with the Trader privilege and Large Market; it does not apply to private Trading Post sales.",
				hacienda: "Once per Settler phase, before your regular tile-taking action, you may draw one additional face-down plantation. You must have an empty plantation space before drawing and must place the tile on your island rather than reject it. The Hacienda tile does not receive a Hospice person; an active Forest House allows it to become a forest. If only one space remains and the Hacienda tile fills it, you cannot take a regular tile afterward.",
				constructionHut: "During a Settler phase, you may take a quarry instead of a face-up plantation even when you did not choose the role. This also permits a quarry for the Library's second tile, provided one remains in supply.",
				smallWarehouse: "During Captain-phase storage, keep every barrel of one good in addition to the ordinary one-barrel allowance. Choose the preserved good yourself; this ability combines with the Large Warehouse and Storehouse.",
				hospice: "When taking your first regular plantation or quarry in a Settler phase, you may immediately staff it with one person. Take an ordinary worker from supply first; if that supply is empty, take an available person from recruitment instead. Recruitment may provide an ordinary worker or, when Nobles is enabled, an available noble. Neither the extra Hacienda tile nor the Library's second tile receives a Hospice person. If the regular plantation becomes a forest, place the received person in your harbor instead.",
				office: "During a Trader phase, you may sell a good that is already present in the trading house. The trading house still holds at most four barrels; the Office cannot permit a sale when it is full.",
				largeMarket: "When you sell a barrel to the trading house during a Trader phase, gain 2 additional coins. When both Markets are active, they provide a combined bonus of 3 coins. The Trader privilege applies in addition; neither Market rewards a private Trading Post sale.",
				largeWarehouse: "During Captain-phase storage, keep every barrel of two goods in addition to the ordinary one-barrel allowance. With an active Small Warehouse, preserve three additional goods in full; the Storehouse adds separate barrel capacity.",
				factory: "Each Craftsman phase, earn coins based on the number of different goods you actually receive from regular production. Producing two types earns 1 coin, three earns 2, four earns 3, and five earns 5. Producing zero or one type earns nothing; count types rather than the total number of barrels. Corn counts as a type; the chooser's later extra barrels do not trigger a recalculation.",
				university: "When buying a new building with workplaces in a Builder phase, you may immediately take one person and place them in that building. Take an ordinary worker from supply first; if it is empty, take an available ordinary worker or noble from recruitment. Receive at most one person per new building, regardless of its number of workplaces. Buying the University itself gives no such reward; the Statue has no workplace and cannot receive a person.",
				harbor: "Each time you actually ship goods in a Captain phase, gain 1 additional point in victory point tokens. This applies to public ships, the Wharf and Small Wharf; award one point per shipment rather than per barrel. It combines with the Captain privilege; Royal Supplier deliveries and Buccaneer actions are not shipments.",
				wharf: "Once per Captain phase, you may use a private ship to ship every barrel you own of one chosen good. This private ship has unlimited capacity and ignores goods already assigned to public ships and their loading status. Gain 1 point per barrel and return the barrels to supply immediately; Captain, Harbor and Lighthouse bonuses apply. Private shipping is optional; the Wharf and Small Wharf each have one use and may be used on separate loading turns.",
				guildHall: "This building must be staffed at game end to award the following bonus points. Gain 1 point per Small Indigo Plant and Small Sugar Mill, and 2 points per other production building. Counted production buildings need not be staffed; the Nobles expansion's Jeweler counts as a large production building.",
				residence: "If staffed at game end, this building awards bonus points for occupied plantation spaces on your island. Occupying zero through nine spaces earns 4 points, ten earns 5, eleven earns 6, and twelve earns 7. All plantations, quarries and forests count as occupied spaces, whether staffed or not.",
				fortress: "If staffed at game end, this building awards 1 bonus point for every three people you own. Count all personnel on plantations, quarries, buildings and in your harbor, including nobles; ignore any remainder below three.",
				customsHouse: "If staffed at game end, this building awards 1 bonus point for every 4 points in your victory point tokens. Ignore any remainder below 4; exclude printed building points, noble points and other endgame bonuses.",
				cityHall: "If staffed at game end, this building awards 1 bonus point for each commercial building you own. Include the City Hall itself; the other commercial buildings need not be staffed. Exclude all production buildings, including the Nobles expansion's Jeweler.",
				blackMarket: "Use the Black Market only when your coins are insufficient to pay the construction cost. Return at most one person, one barrel and 1 point in victory point tokens; each returned item pays for 1 coin of the cost. Pay at most 3 coins this way; spend all your coins and return exactly enough items to cover the shortfall, with no change. Personnel may come from your plantations, quarries, other buildings or harbor, but never from the Black Market itself. Return ordinary workers and nobles to their respective supplies, and return goods and tokens to theirs. If returning personnel disables a quarry, District Office or Library, recalculate the final construction cost without its discount. Returning tokens or people does not cancel an end condition that has already been triggered.",
				forestHouse: "While this building is active, you may place newly acquired plantations as forests; tiles already on your island cannot be converted. You may also inspect a face-down plantation drawn by the Hacienda or bought through the Land Office before deciding to make it a forest. Quarries cannot become forests; a forest occupies one plantation space, has no workplace and produces no goods. Each pair of forests you own reduces every construction cost by 1 coin, cumulatively with other discounts. Existing forests keep their discount even if the Forest House becomes unstaffed; all forests count as one tile type.",
				aqueduct: "During a Craftsman phase, a staffed Indigo Plant or Sugar Mill that can produce normally with matching plantations produces 1 extra barrel of its good. Only the large Indigo Plant and Sugar Mill qualify; the Small Indigo Plant and Small Sugar Mill do not. If both large buildings qualify, produce 1 extra indigo and 1 extra sugar barrel, subject to the shared supply.",
				storehouse: "During Captain-phase storage, keep three additional barrels of any goods; they need not be of one type. Together with the ordinary single barrel, this preserves four barrels; either Warehouse adds its full-type storage separately.",
				guesthouse: "This building has two workplaces that may receive guests during a Foreman phase, including nobles. At the beginning, during or end of a phase, you may move guests to other legal empty workplaces on your island. Plantations, quarries and buildings may receive guests; the two guests may move at different times. A guest activates the destination immediately, but does not grant ability rewards whose timing has already passed. Once moved, that person cannot move again until the next Foreman phase or return to the Guesthouse for repeated use.",
				church: "When constructing a row-two or row-three building in a Builder phase, gain 1 point in victory point tokens. Gain 2 points for a row-four building and no points for a row-one building. Constructing the Church itself gives no reward; these tokens do not replace the new building's printed points.",
				tradingPost: "During a Trader phase, you may sell one barrel through your own Trading Post instead, returning it directly to supply. A private sale ignores whether the trading house is full or already contains the good. The Trader privilege still applies, but Small Market and Large Market coin bonuses do not. This building does not grant another sale; you still sell at most one barrel per Trader phase.",
				smallWharf: "Once per Captain phase, ship any number of barrels of any goods, including mixed cargo. You may ship only part of your stock; gain 1 point per two barrels, ignoring an unmatched barrel for base points. Ship at least one barrel and return all cargo to supply immediately; a one-barrel shipment has zero base points. Captain, Harbor and Lighthouse bonuses still apply; this and the Wharf may be used on separate loading turns. This private shipment is optional and ignores public ships' assigned goods and capacities.",
				lighthouse: "Each actual shipment during a Captain phase earns 1 coin, whether made on a public ship or through either private Wharf. If you chose the Captain, gain 1 further coin during the phase even if you ship nothing. The chooser's additional coin is awarded once per phase; the Library does not double this building bonus.",
				specialtyFactory: "Each Craftsman phase, find the largest number of barrels of one non-corn good received from your regular production. Gain that number minus one in coins, with a minimum of zero; for example, producing 4 sugar barrels earns 3 coins. Exclude corn; extra barrels later taken through the role privilege do not recalculate the award.",
				library: "When you choose a role, double its privilege; following another player's role gives you no role privilege. As Settler, you may take a second tile after every other player has completed their regular tile-taking action. For the second tile, choose a remaining face-up plantation; a quarry requires an active Construction Hut. The second tile receives no Hospice person; you need an empty plantation space and may decline it. The Builder discount becomes 2 coins; the Foreman takes 2 extra ordinary supply workers. The Craftsman may take 2 extra barrels of goods actually produced in the phase, either matching or different. A completed Trader sale earns 2 extra coins; the Captain's first actual shipment earns 2 extra points. The Prospector takes 2 coins; all these privileges retain their original role conditions. The Library does not double role-card coin accumulations, other building rewards or Buccaneer actions.",
				unionHall: "Once per Captain phase, before your first action, gain victory point tokens based on the goods you own at that time. Count each good separately and gain 1 point per two barrels; unmatched barrels of different goods cannot be combined. For example, three corn, one coffee and two indigo barrels earn 2 points in total. Scoring does not consume the goods; they remain available for normal shipping, royal supply or storage afterward.",
				cloister: "If staffed at game end, this building awards points for groups of three matching tiles on your island. Count each plantation type separately; quarries and forests are separate types, and one type may form multiple groups. One group earns 1 point, two earn 3, three earn 6 and four earn 10; zero groups earn nothing. For example, six corn plantations and three forests form three groups and earn 6 points; the tiles need not be staffed.",
				statue: "This building occupies two city spaces, has no workplace and requires no personnel. It provides its printed value of 8 points at game end and has no separate activated scoring ability. The Statue is a row-four building, so its quarry discount is limited to 4 coins.",
				districtOffice: "With an ordinary worker staffing this building, a small building costs 1 coin less. With a noble staffing it, a large building costs 2 coins less instead. These two abilities are alternatives, not simultaneous; other discounts combine with them, and final cost cannot be negative.",
				royalSupplier: "Once per Captain phase, before your first normal loading turn, you may supply goods to the royal court. Supply at most one barrel of each good, with the total no greater than your noble count, including harbor nobles. Return the supplied barrels to the shared supply immediately and gain 1 point in victory point tokens per barrel. Captain, Harbor and Lighthouse bonuses do not apply; afterward, continue under the normal Captain rules.",
				chapel: "At the beginning of each Craftsman phase, gain 1 coin if an ordinary worker staffs this building, or 1 point in tokens if a noble does. Receive the applicable reward even if you produce no goods that phase; resolve it only once per phase.",
				jeweler: "On your production turn in a Craftsman phase, gain 1 coin per noble you own, including those in your harbor. This building produces no barrels and needs no plantation; it earns coins even if you produce no other goods. The Guild Hall counts it as a large production building; the City Hall does not count it as a commercial building.",
				villa: "The first time you receive personnel in each Foreman phase, take one additional noble from supply into your harbor. Receiving a Foreman privilege worker also triggers this; later recruitment in the same phase does not trigger it again. If no nobles remain in supply, take one ordinary supply worker instead; if both supplies are empty, take nobody extra.",
				huntingLodge: "At the end of a Settler phase, an ordinary worker lets you discard one of your plantations or forests, but not a quarry. Move any person on the discarded tile to your harbor and put the tile into the plantation discard pile. With a noble, compare all players' empty plantation spaces; gain 2 points in tokens only if you alone have the most. Finish any tile discards before comparing empty spaces; a tie earns nothing, and you need not have chosen Settler.",
				landOffice: "Use this ability once per Trader phase, either before or after your sale of goods. With an ordinary worker, pay 1 coin to draw and place a face-down plantation, provided you have an empty plantation space. With a noble, sell one plantation or forest you own for 1 coin; quarries cannot be sold. Move any person from a sold tile to your harbor and discard the tile; this does not use your sale of goods. With an active Forest House, a newly bought plantation may be placed as a forest.",
				royalGarden: "If staffed at game end, this building awards 1 additional point for every noble you own. Count nobles on plantations, in buildings and in your harbor; including each noble's base point, each is worth 2 points in total."
			},
			event: {
				piracy: "{{name}} raided a ship and kept {{n}} {{item}} barrels",
				plunder: "{{name}} plundered the trading house for {{n}} VP",
				raid: "{{name}} raided recruitment and placed {{n}} people",
				kidnap: "{{name}} kidnapped {{item}}",
				ransom: "{{name}} gained three coins when {{item}} was chosen",
				festivalPlantation: "{{name}} claimed the plantation goal and gained {{n}} workers",
				festivalProduction: "{{name}} claimed the production goal and gained three coins",
				festivalBuilding: "{{name}} claimed the building goal and gained three VP",
				recruit: "{{name}} recruited one person",
				removePlantation: "{{name}} removed {{item}}",
				buyLand: "{{name}} bought a plantation for one coin",
				royalSupply: "{{name}} supplied {{n}} barrels to the royal court",
				mixedShip: "{{name}} shipped {{n}} barrels via the Small Wharf",
				draft: "{{name}} added {{item}} to the market",
				guest: "{{name}} placed a guest",
				role: "{{name}} chose {{item}}",
				plant: "{{name}} took {{item}}",
				build: "{{name}} built {{item}} for {{n}} coins",
				assign: "{{name}} assigned {{n}} workers",
				produce: "{{name}} received {{n}} barrels",
				trade: "{{name}} sold {{item}} for {{n}} coins",
				ship: "{{name}} loaded {{n}} {{item}}",
				store: "{{name}} kept {{n}} barrels"
			}
		}
	}
};
//#endregion
export { jn as default };
