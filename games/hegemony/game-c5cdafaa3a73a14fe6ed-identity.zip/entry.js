import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { Floater as p, FlySprite as m, PulseBox as h } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as ee } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as te, OptionSection as ne, OptionSwitch as re } from "@bgparty/sdk/ui/game-options";
//#region src/games/hegemony/content.ts
var ie = {
	Supermarket: "games.hegemony.content.name000",
	"Shopping Mall": "games.hegemony.content.name001",
	College: "games.hegemony.content.name002",
	Clinic: "games.hegemony.content.name003",
	"Fish Farm": "games.hegemony.content.name004",
	"Vegetable Farm": "games.hegemony.content.name005",
	"Fast Food Chain": "games.hegemony.content.name006",
	"Automated Grain Farm": "games.hegemony.content.name007",
	"Automated Dairy Farm": "games.hegemony.content.name008",
	Stadium: "games.hegemony.content.name009",
	Hotel: "games.hegemony.content.name010",
	"Fashion Company": "games.hegemony.content.name011",
	"Electronics Manufacturer": "games.hegemony.content.name012",
	"Car Manufacturer": "games.hegemony.content.name013",
	"Pharmaceutical Company": "games.hegemony.content.name014",
	"Medical Village": "games.hegemony.content.name015",
	Hospital: "games.hegemony.content.name016",
	"Institute of Technology": "games.hegemony.content.name017",
	University: "games.hegemony.content.name018",
	Academy: "games.hegemony.content.name019",
	"TV Station": "games.hegemony.content.name020",
	"Publishing House": "games.hegemony.content.name021",
	"Lobbying Firm": "games.hegemony.content.name022",
	"Radio Station": "games.hegemony.content.name023",
	"Convenience Store": "games.hegemony.content.name024",
	"Doctor's Office": "games.hegemony.content.name025",
	"Fast Food Restaurant": "games.hegemony.content.name026",
	"Organic Farm": "games.hegemony.content.name027",
	"Jewelry Store": "games.hegemony.content.name028",
	"Game Store": "games.hegemony.content.name029",
	"Electronics Store": "games.hegemony.content.name030",
	Pharmacy: "games.hegemony.content.name031",
	"Medical Laboratory": "games.hegemony.content.name032",
	"Training Center": "games.hegemony.content.name033",
	"Tutoring Company": "games.hegemony.content.name034",
	"Private School": "games.hegemony.content.name035",
	"PR Agency": "games.hegemony.content.name036",
	"Local Newspaper": "games.hegemony.content.name037",
	"Regional Radio Station": "games.hegemony.content.name038",
	"Regional TV Station": "games.hegemony.content.name039",
	"Public University": "games.hegemony.content.name040",
	"Public Hospital": "games.hegemony.content.name041",
	"National Public Broadcasting": "games.hegemony.content.name042",
	"Technical University": "games.hegemony.content.name043",
	"University Hospital": "games.hegemony.content.name044",
	"Cooperative Farm": "games.hegemony.content.name045",
	"Political Scandal": "games.hegemony.content.name046",
	"Neighbors at War": "games.hegemony.content.name047",
	Pandemic: "games.hegemony.content.name048",
	"Strike at the Port": "games.hegemony.content.name049",
	"Low Education Index": "games.hegemony.content.name050",
	"Need for Sustainability Initiative": "games.hegemony.content.name051",
	"Fear of Deflation": "games.hegemony.content.name052",
	"Declining Birth Rate": "games.hegemony.content.name053",
	"Need for Stimulus Package": "games.hegemony.content.name054",
	"Demand for Thirteenth Month Pay": "games.hegemony.content.name055",
	"Companies Demand Better Internet": "games.hegemony.content.name056",
	Drought: "games.hegemony.content.name057",
	"Local Industries in Turmoil": "games.hegemony.content.name058",
	"Technological Illiteracy": "games.hegemony.content.name059",
	"Demand for Higher Welfare Standards": "games.hegemony.content.name060",
	"Developing Countries in Need": "games.hegemony.content.name061",
	"Infant Industry Requires Help": "games.hegemony.content.name062",
	"Outdated Public Sector Infrastructure": "games.hegemony.content.name063",
	Earthquake: "games.hegemony.content.name064",
	"Demand for Pension Reform": "games.hegemony.content.name065",
	"Political Polarization": "games.hegemony.content.name066",
	"Civil Unrest": "games.hegemony.content.name067",
	"Unfair Representation": "games.hegemony.content.name068",
	"Low University Ratings": "games.hegemony.content.name069",
	"Global Supply Chain Crisis": "games.hegemony.content.name070",
	"Low Global Innovation Index Ranking": "games.hegemony.content.name071",
	"Demand for Better Public Education": "games.hegemony.content.name072",
	"Demand for Subsidies by Dairy Farmers": "games.hegemony.content.name073",
	"Demand for Administrative Upgrade": "games.hegemony.content.name074",
	"High Illiteracy Rate": "games.hegemony.content.name075",
	"Low Vaccination Rates": "games.hegemony.content.name076",
	"Political Pressure": "games.hegemony.content.name077",
	"Demand for Energy Subsidy": "games.hegemony.content.name078",
	"Smear Campaign": "games.hegemony.content.name079",
	"Demand for Economic Stimulus": "games.hegemony.content.name080",
	"Public Pressure": "games.hegemony.content.name081",
	Hurricane: "games.hegemony.content.name082",
	"Rising Traffic Accidents": "games.hegemony.content.name083",
	"Tax Returns": "games.hegemony.content.name084",
	"Fear of Recession": "games.hegemony.content.name085",
	"Student Protest": "games.hegemony.content.name086",
	"Rising Flu Infections": "games.hegemony.content.name087",
	"Low Political Engagement": "games.hegemony.content.name088",
	"Demand for Digital Transformation": "games.hegemony.content.name089",
	"Rising Economic Inequality": "games.hegemony.content.name090",
	"Healthcare Scandal": "games.hegemony.content.name091",
	"Public Sector Union Negotiations": "games.hegemony.content.name092",
	"Demand for Startup Support": "games.hegemony.content.name093",
	Gerrymandering: "games.hegemony.content.name094",
	"Demand for State Intervention": "games.hegemony.content.name095",
	"Corporate Empire": "games.hegemony.content.name096",
	"Toward a Neoliberal State": "games.hegemony.content.name097",
	"Export Tycoon": "games.hegemony.content.name098",
	"Diversified Portfolio": "games.hegemony.content.name099",
	"Venture Capitalist": "games.hegemony.content.name100",
	Leviathan: "games.hegemony.content.name101",
	"Expert Budgeter": "games.hegemony.content.name102",
	"According to Plan": "games.hegemony.content.name103",
	"Strong Welfare State": "games.hegemony.content.name104",
	"State-Led Economy": "games.hegemony.content.name105",
	Entrepreneur: "games.hegemony.content.name106",
	"Successful Startup": "games.hegemony.content.name107",
	"Growing Middle Class": "games.hegemony.content.name108",
	"Golden Compromise": "games.hegemony.content.name109",
	"We Work, We Thrive": "games.hegemony.content.name110",
	"Rally the Masses": "games.hegemony.content.name111",
	"Workers, Unite!": "games.hegemony.content.name112",
	"Working Class Push": "games.hegemony.content.name113",
	"Small Labor Force": "games.hegemony.content.name114",
	"The Surplus Value Is Ours!": "games.hegemony.content.name115",
	"Washington Consensus": "games.hegemony.content.name116",
	"Failed IMF Negotiations": "games.hegemony.content.name117",
	"Moderate IMF Intervention": "games.hegemony.content.name118",
	"Japanese Model": "games.hegemony.content.name119",
	"Basic IMF Intervention": "games.hegemony.content.name120",
	"US Stimulus Package": "games.hegemony.content.name121",
	"IMF Intervention with Resistance": "games.hegemony.content.name122",
	"New Government Bond Program": "games.hegemony.content.name123",
	"EU Austerity Measures": "games.hegemony.content.name124",
	"Failed IMF Intervention: Revolution": "games.hegemony.content.name125",
	"French Revolution": "games.hegemony.content.name126",
	"Industrial Revolution": "games.hegemony.content.name127",
	"Revolutions of 1848": "games.hegemony.content.name128",
	"Foundation of the International Alliance of Women": "games.hegemony.content.name129",
	"Moving Assembly Line": "games.hegemony.content.name130",
	"World War I": "games.hegemony.content.name131",
	"Introduction of the Ford Model T": "games.hegemony.content.name132",
	"Russian Revolution": "games.hegemony.content.name133",
	"Rise of Authoritarianism": "games.hegemony.content.name134",
	"Panama Canal Opens": "games.hegemony.content.name135",
	"Spanish Flu": "games.hegemony.content.name136",
	"Russo-Japanese War": "games.hegemony.content.name137",
	"Rise of Protectionism": "games.hegemony.content.name138",
	"Bengal Famine": "games.hegemony.content.name139",
	"New Deal": "games.hegemony.content.name140",
	"Great Depression": "games.hegemony.content.name141",
	"Baby Boom": "games.hegemony.content.name142",
	"General Motors Sit-Down Strike": "games.hegemony.content.name143",
	"World War II": "games.hegemony.content.name144",
	"General Agreement on Tariffs and Trade": "games.hegemony.content.name145",
	"Indian Independence": "games.hegemony.content.name146",
	"Post-War Economic Miracle": "games.hegemony.content.name147",
	"Chinese Communist Revolution": "games.hegemony.content.name148",
	"Civil Rights Movement": "games.hegemony.content.name149",
	"Cuban Embargo": "games.hegemony.content.name150",
	"Marshall Plan": "games.hegemony.content.name151",
	Decolonization: "games.hegemony.content.name152",
	"The Keynesian Era": "games.hegemony.content.name153",
	"Rise of the European Left": "games.hegemony.content.name154",
	Consumerism: "games.hegemony.content.name155",
	"Arab Nationalization of Oil": "games.hegemony.content.name156",
	"Chinese Economic Reforms": "games.hegemony.content.name157",
	"Rise of the Asian Tigers": "games.hegemony.content.name158",
	"World Wide Web": "games.hegemony.content.name159",
	"End of Dictatorships in Southern Europe": "games.hegemony.content.name160",
	"Fall of the Berlin Wall": "games.hegemony.content.name161",
	"Latin American Debt Crisis": "games.hegemony.content.name162",
	"Oil Crisis": "games.hegemony.content.name163",
	"Indian Drought": "games.hegemony.content.name164",
	"Elections in Ex-Soviet Countries": "games.hegemony.content.name165",
	"EU Emissions Trading System": "games.hegemony.content.name166",
	"US Financial Crisis": "games.hegemony.content.name167",
	"US-China Trade War": "games.hegemony.content.name168",
	"European Debt Crisis": "games.hegemony.content.name169",
	"Maastricht Treaty": "games.hegemony.content.name170",
	"Dissolution of the Soviet Union": "games.hegemony.content.name171",
	"Rise of the Middle Class in Asia": "games.hegemony.content.name172",
	"Yellow Vests Movement": "games.hegemony.content.name173",
	"Bismarckian Reforms": "games.hegemony.content.name174",
	"American Revolution": "games.hegemony.content.name175"
}, ae = {
	24900: "games.hegemony.content.action24900",
	24901: "games.hegemony.content.action24900",
	24902: "games.hegemony.content.action24902",
	24903: "games.hegemony.content.action24903",
	24904: "games.hegemony.content.action24903",
	24905: "games.hegemony.content.action24905",
	24906: "games.hegemony.content.action24905",
	24907: "games.hegemony.content.action24907",
	24908: "games.hegemony.content.action24908",
	24909: "games.hegemony.content.action24908",
	24910: "games.hegemony.content.action24908",
	24911: "games.hegemony.content.action24911",
	24912: "games.hegemony.content.action24911",
	24913: "games.hegemony.content.action24913",
	24914: "games.hegemony.content.action24913",
	24915: "games.hegemony.content.action24915",
	24916: "games.hegemony.content.action24916",
	24917: "games.hegemony.content.action24917",
	24918: "games.hegemony.content.action24917",
	24919: "games.hegemony.content.action24919",
	24920: "games.hegemony.content.action24919",
	24921: "games.hegemony.content.action24921",
	24922: "games.hegemony.content.action24922",
	24923: "games.hegemony.content.action24923",
	24924: "games.hegemony.content.action24923",
	24925: "games.hegemony.content.action24925",
	24926: "games.hegemony.content.action24925",
	24927: "games.hegemony.content.action24927",
	24928: "games.hegemony.content.action24928",
	24929: "games.hegemony.content.action24929",
	24930: "games.hegemony.content.action24929",
	24931: "games.hegemony.content.action24931",
	24932: "games.hegemony.content.action24932",
	24933: "games.hegemony.content.action24931",
	24934: "games.hegemony.content.action24934",
	24935: "games.hegemony.content.action24934",
	24936: "games.hegemony.content.action24936",
	24937: "games.hegemony.content.action24937",
	24938: "games.hegemony.content.action24937",
	24939: "games.hegemony.content.action24939",
	28e3: "games.hegemony.content.action28000",
	28001: "games.hegemony.content.action28001",
	28002: "games.hegemony.content.action28002",
	28003: "games.hegemony.content.action28003",
	28004: "games.hegemony.content.action28004",
	28100: "games.hegemony.content.action28100",
	28101: "games.hegemony.content.action28101",
	28102: "games.hegemony.content.action28102",
	28103: "games.hegemony.content.action28103",
	28104: "games.hegemony.content.action28104",
	28105: "games.hegemony.content.action28105",
	28106: "games.hegemony.content.action28106",
	28107: "games.hegemony.content.action28107",
	28108: "games.hegemony.content.action28108",
	28109: "games.hegemony.content.action28109",
	28110: "games.hegemony.content.action28110",
	28111: "games.hegemony.content.action28111",
	28112: "games.hegemony.content.action28112",
	28113: "games.hegemony.content.action28113",
	28114: "games.hegemony.content.action28114",
	28115: "games.hegemony.content.action28115",
	28116: "games.hegemony.content.action28116",
	28117: "games.hegemony.content.action28117",
	28118: "games.hegemony.content.action28118",
	28119: "games.hegemony.content.action24936",
	28120: "games.hegemony.content.action28120",
	28121: "games.hegemony.content.action28121",
	28122: "games.hegemony.content.action28122",
	28123: "games.hegemony.content.action28123",
	28124: "games.hegemony.content.action28124",
	28125: "games.hegemony.content.action28125",
	28126: "games.hegemony.content.action28126",
	28127: "games.hegemony.content.action28127",
	28128: "games.hegemony.content.action28104",
	28129: "games.hegemony.content.action28103",
	28130: "games.hegemony.content.action28120",
	28131: "games.hegemony.content.action28112",
	28132: "games.hegemony.content.action28123",
	28133: "games.hegemony.content.action28101",
	28134: "games.hegemony.content.action28117",
	28135: "games.hegemony.content.action28110",
	28136: "games.hegemony.content.action28116",
	28137: "games.hegemony.content.action28127",
	28138: "games.hegemony.content.action28118",
	28139: "games.hegemony.content.action28105",
	28200: "games.hegemony.content.action28002",
	28201: "games.hegemony.content.action28003",
	28202: "games.hegemony.content.action28004",
	28203: "games.hegemony.content.action28001",
	28204: "games.hegemony.content.action28204",
	28300: "games.hegemony.content.action28300",
	28301: "games.hegemony.content.action28301",
	28302: "games.hegemony.content.action28302",
	28303: "games.hegemony.content.action28303",
	28304: "games.hegemony.content.action28304",
	28305: "games.hegemony.content.action28305",
	28306: "games.hegemony.content.action24939",
	28307: "games.hegemony.content.action28307",
	28308: "games.hegemony.content.action28308",
	28309: "games.hegemony.content.action28309",
	28310: "games.hegemony.content.action28310",
	28311: "games.hegemony.content.action28311",
	28312: "games.hegemony.content.action28312",
	28313: "games.hegemony.content.action24932",
	28314: "games.hegemony.content.action28314",
	28315: "games.hegemony.content.action28315",
	28316: "games.hegemony.content.action28316",
	28317: "games.hegemony.content.action28317",
	28318: "games.hegemony.content.action28318",
	28319: "games.hegemony.content.action28319",
	28320: "games.hegemony.content.action28320",
	28321: "games.hegemony.content.action24936",
	28322: "games.hegemony.content.action28322",
	28323: "games.hegemony.content.action28323",
	28324: "games.hegemony.content.action28324",
	28325: "games.hegemony.content.action28325",
	28326: "games.hegemony.content.action28326",
	28327: "games.hegemony.content.action24921",
	28328: "games.hegemony.content.action28304",
	28329: "games.hegemony.content.action28318",
	28330: "games.hegemony.content.action28325",
	28331: "games.hegemony.content.action28325",
	28332: "games.hegemony.content.action28303",
	28333: "games.hegemony.content.action28310",
	28334: "games.hegemony.content.action28311",
	28335: "games.hegemony.content.action28322",
	28336: "games.hegemony.content.action28308",
	28337: "games.hegemony.content.action28312",
	28338: "games.hegemony.content.action28309",
	28339: "games.hegemony.content.action28307",
	28400: "games.hegemony.content.action28002",
	28401: "games.hegemony.content.action28401",
	28402: "games.hegemony.content.action28003",
	28403: "games.hegemony.content.action28001",
	28404: "games.hegemony.content.action28004",
	28500: "games.hegemony.content.action24905",
	28501: "games.hegemony.content.action28501",
	28502: "games.hegemony.content.action28501",
	28503: "games.hegemony.content.action28503",
	28504: "games.hegemony.content.action28503",
	28505: "games.hegemony.content.action28505",
	28506: "games.hegemony.content.action28505",
	28507: "games.hegemony.content.action28507",
	28508: "games.hegemony.content.action28507",
	28509: "games.hegemony.content.action28509",
	28510: "games.hegemony.content.action28509",
	28511: "games.hegemony.content.action28511",
	28512: "games.hegemony.content.action28511",
	28513: "games.hegemony.content.action24921",
	28514: "games.hegemony.content.action24921",
	28515: "games.hegemony.content.action24913",
	28516: "games.hegemony.content.action24913",
	28517: "games.hegemony.content.action24932",
	28518: "games.hegemony.content.action28518",
	28519: "games.hegemony.content.action28518",
	28520: "games.hegemony.content.action24934",
	28521: "games.hegemony.content.action24902",
	28522: "games.hegemony.content.action28522",
	28523: "games.hegemony.content.action28523",
	28524: "games.hegemony.content.action28524",
	28525: "games.hegemony.content.action28525",
	28526: "games.hegemony.content.action28526",
	28527: "games.hegemony.content.action24939",
	28528: "games.hegemony.content.action28528",
	28529: "games.hegemony.content.action28528",
	28530: "games.hegemony.content.action24913",
	28531: "games.hegemony.content.action24911",
	28532: "games.hegemony.content.action28532",
	28533: "games.hegemony.content.action28532",
	28534: "games.hegemony.content.action28534",
	28535: "games.hegemony.content.action28535",
	28536: "games.hegemony.content.action28535",
	28537: "games.hegemony.content.action28537",
	28538: "games.hegemony.content.action28538",
	28539: "games.hegemony.content.action28538",
	28600: "games.hegemony.content.action28003",
	28601: "games.hegemony.content.action28002",
	28602: "games.hegemony.content.action28001",
	28603: "games.hegemony.content.action28603",
	28604: "games.hegemony.content.action28004"
}, oe = {
	name000: "games.hegemony.content.name000",
	name001: "games.hegemony.content.name001",
	name002: "games.hegemony.content.name002",
	name003: "games.hegemony.content.name003",
	name004: "games.hegemony.content.name004",
	name005: "games.hegemony.content.name005",
	name006: "games.hegemony.content.name006",
	name007: "games.hegemony.content.name007",
	name008: "games.hegemony.content.name008",
	name009: "games.hegemony.content.name009",
	name010: "games.hegemony.content.name010",
	name011: "games.hegemony.content.name011",
	name012: "games.hegemony.content.name012",
	name013: "games.hegemony.content.name013",
	name014: "games.hegemony.content.name014",
	name015: "games.hegemony.content.name015",
	name016: "games.hegemony.content.name016",
	name017: "games.hegemony.content.name017",
	name018: "games.hegemony.content.name018",
	name019: "games.hegemony.content.name019",
	name020: "games.hegemony.content.name020",
	name021: "games.hegemony.content.name021",
	name022: "games.hegemony.content.name022",
	name023: "games.hegemony.content.name023",
	name024: "games.hegemony.content.name024",
	name025: "games.hegemony.content.name025",
	name026: "games.hegemony.content.name026",
	name027: "games.hegemony.content.name027",
	name028: "games.hegemony.content.name028",
	name029: "games.hegemony.content.name029",
	name030: "games.hegemony.content.name030",
	name031: "games.hegemony.content.name031",
	name032: "games.hegemony.content.name032",
	name033: "games.hegemony.content.name033",
	name034: "games.hegemony.content.name034",
	name035: "games.hegemony.content.name035",
	name036: "games.hegemony.content.name036",
	name037: "games.hegemony.content.name037",
	name038: "games.hegemony.content.name038",
	name039: "games.hegemony.content.name039",
	name040: "games.hegemony.content.name040",
	name041: "games.hegemony.content.name041",
	name042: "games.hegemony.content.name042",
	name043: "games.hegemony.content.name043",
	name044: "games.hegemony.content.name044",
	name045: "games.hegemony.content.name045",
	name046: "games.hegemony.content.name046",
	name047: "games.hegemony.content.name047",
	name048: "games.hegemony.content.name048",
	name049: "games.hegemony.content.name049",
	name050: "games.hegemony.content.name050",
	name051: "games.hegemony.content.name051",
	name052: "games.hegemony.content.name052",
	name053: "games.hegemony.content.name053",
	name054: "games.hegemony.content.name054",
	name055: "games.hegemony.content.name055",
	name056: "games.hegemony.content.name056",
	name057: "games.hegemony.content.name057",
	name058: "games.hegemony.content.name058",
	name059: "games.hegemony.content.name059",
	name060: "games.hegemony.content.name060",
	name061: "games.hegemony.content.name061",
	name062: "games.hegemony.content.name062",
	name063: "games.hegemony.content.name063",
	name064: "games.hegemony.content.name064",
	name065: "games.hegemony.content.name065",
	name066: "games.hegemony.content.name066",
	name067: "games.hegemony.content.name067",
	name068: "games.hegemony.content.name068",
	name069: "games.hegemony.content.name069",
	name070: "games.hegemony.content.name070",
	name071: "games.hegemony.content.name071",
	name072: "games.hegemony.content.name072",
	name073: "games.hegemony.content.name073",
	name074: "games.hegemony.content.name074",
	name075: "games.hegemony.content.name075",
	name076: "games.hegemony.content.name076",
	name077: "games.hegemony.content.name077",
	name078: "games.hegemony.content.name078",
	name079: "games.hegemony.content.name079",
	name080: "games.hegemony.content.name080",
	name081: "games.hegemony.content.name081",
	name082: "games.hegemony.content.name082",
	name083: "games.hegemony.content.name083",
	name084: "games.hegemony.content.name084",
	name085: "games.hegemony.content.name085",
	name086: "games.hegemony.content.name086",
	name087: "games.hegemony.content.name087",
	name088: "games.hegemony.content.name088",
	name089: "games.hegemony.content.name089",
	name090: "games.hegemony.content.name090",
	name091: "games.hegemony.content.name091",
	name092: "games.hegemony.content.name092",
	name093: "games.hegemony.content.name093",
	name094: "games.hegemony.content.name094",
	name095: "games.hegemony.content.name095",
	name096: "games.hegemony.content.name096",
	name097: "games.hegemony.content.name097",
	name098: "games.hegemony.content.name098",
	name099: "games.hegemony.content.name099",
	name100: "games.hegemony.content.name100",
	name101: "games.hegemony.content.name101",
	name102: "games.hegemony.content.name102",
	name103: "games.hegemony.content.name103",
	name104: "games.hegemony.content.name104",
	name105: "games.hegemony.content.name105",
	name106: "games.hegemony.content.name106",
	name107: "games.hegemony.content.name107",
	name108: "games.hegemony.content.name108",
	name109: "games.hegemony.content.name109",
	name110: "games.hegemony.content.name110",
	name111: "games.hegemony.content.name111",
	name112: "games.hegemony.content.name112",
	name113: "games.hegemony.content.name113",
	name114: "games.hegemony.content.name114",
	name115: "games.hegemony.content.name115",
	name116: "games.hegemony.content.name116",
	name117: "games.hegemony.content.name117",
	name118: "games.hegemony.content.name118",
	name119: "games.hegemony.content.name119",
	name120: "games.hegemony.content.name120",
	name121: "games.hegemony.content.name121",
	name122: "games.hegemony.content.name122",
	name123: "games.hegemony.content.name123",
	name124: "games.hegemony.content.name124",
	name125: "games.hegemony.content.name125",
	name126: "games.hegemony.content.name126",
	name127: "games.hegemony.content.name127",
	name128: "games.hegemony.content.name128",
	name129: "games.hegemony.content.name129",
	name130: "games.hegemony.content.name130",
	name131: "games.hegemony.content.name131",
	name132: "games.hegemony.content.name132",
	name133: "games.hegemony.content.name133",
	name134: "games.hegemony.content.name134",
	name135: "games.hegemony.content.name135",
	name136: "games.hegemony.content.name136",
	name137: "games.hegemony.content.name137",
	name138: "games.hegemony.content.name138",
	name139: "games.hegemony.content.name139",
	name140: "games.hegemony.content.name140",
	name141: "games.hegemony.content.name141",
	name142: "games.hegemony.content.name142",
	name143: "games.hegemony.content.name143",
	name144: "games.hegemony.content.name144",
	name145: "games.hegemony.content.name145",
	name146: "games.hegemony.content.name146",
	name147: "games.hegemony.content.name147",
	name148: "games.hegemony.content.name148",
	name149: "games.hegemony.content.name149",
	name150: "games.hegemony.content.name150",
	name151: "games.hegemony.content.name151",
	name152: "games.hegemony.content.name152",
	name153: "games.hegemony.content.name153",
	name154: "games.hegemony.content.name154",
	name155: "games.hegemony.content.name155",
	name156: "games.hegemony.content.name156",
	name157: "games.hegemony.content.name157",
	name158: "games.hegemony.content.name158",
	name159: "games.hegemony.content.name159",
	name160: "games.hegemony.content.name160",
	name161: "games.hegemony.content.name161",
	name162: "games.hegemony.content.name162",
	name163: "games.hegemony.content.name163",
	name164: "games.hegemony.content.name164",
	name165: "games.hegemony.content.name165",
	name166: "games.hegemony.content.name166",
	name167: "games.hegemony.content.name167",
	name168: "games.hegemony.content.name168",
	name169: "games.hegemony.content.name169",
	name170: "games.hegemony.content.name170",
	name171: "games.hegemony.content.name171",
	name172: "games.hegemony.content.name172",
	name173: "games.hegemony.content.name173",
	name174: "games.hegemony.content.name174",
	name175: "games.hegemony.content.name175",
	action24900: "games.hegemony.content.action24900",
	action24902: "games.hegemony.content.action24902",
	action24903: "games.hegemony.content.action24903",
	action24905: "games.hegemony.content.action24905",
	action24907: "games.hegemony.content.action24907",
	action24908: "games.hegemony.content.action24908",
	action24911: "games.hegemony.content.action24911",
	action24913: "games.hegemony.content.action24913",
	action24915: "games.hegemony.content.action24915",
	action24916: "games.hegemony.content.action24916",
	action24917: "games.hegemony.content.action24917",
	action24919: "games.hegemony.content.action24919",
	action24921: "games.hegemony.content.action24921",
	action24922: "games.hegemony.content.action24922",
	action24923: "games.hegemony.content.action24923",
	action24925: "games.hegemony.content.action24925",
	action24927: "games.hegemony.content.action24927",
	action24928: "games.hegemony.content.action24928",
	action24929: "games.hegemony.content.action24929",
	action24931: "games.hegemony.content.action24931",
	action24932: "games.hegemony.content.action24932",
	action24934: "games.hegemony.content.action24934",
	action24936: "games.hegemony.content.action24936",
	action24937: "games.hegemony.content.action24937",
	action24939: "games.hegemony.content.action24939",
	action28000: "games.hegemony.content.action28000",
	action28001: "games.hegemony.content.action28001",
	action28002: "games.hegemony.content.action28002",
	action28003: "games.hegemony.content.action28003",
	action28004: "games.hegemony.content.action28004",
	action28100: "games.hegemony.content.action28100",
	action28101: "games.hegemony.content.action28101",
	action28102: "games.hegemony.content.action28102",
	action28103: "games.hegemony.content.action28103",
	action28104: "games.hegemony.content.action28104",
	action28105: "games.hegemony.content.action28105",
	action28106: "games.hegemony.content.action28106",
	action28107: "games.hegemony.content.action28107",
	action28108: "games.hegemony.content.action28108",
	action28109: "games.hegemony.content.action28109",
	action28110: "games.hegemony.content.action28110",
	action28111: "games.hegemony.content.action28111",
	action28112: "games.hegemony.content.action28112",
	action28113: "games.hegemony.content.action28113",
	action28114: "games.hegemony.content.action28114",
	action28115: "games.hegemony.content.action28115",
	action28116: "games.hegemony.content.action28116",
	action28117: "games.hegemony.content.action28117",
	action28118: "games.hegemony.content.action28118",
	action28120: "games.hegemony.content.action28120",
	action28121: "games.hegemony.content.action28121",
	action28122: "games.hegemony.content.action28122",
	action28123: "games.hegemony.content.action28123",
	action28124: "games.hegemony.content.action28124",
	action28125: "games.hegemony.content.action28125",
	action28126: "games.hegemony.content.action28126",
	action28127: "games.hegemony.content.action28127",
	action28204: "games.hegemony.content.action28204",
	action28300: "games.hegemony.content.action28300",
	action28301: "games.hegemony.content.action28301",
	action28302: "games.hegemony.content.action28302",
	action28303: "games.hegemony.content.action28303",
	action28304: "games.hegemony.content.action28304",
	action28305: "games.hegemony.content.action28305",
	action28307: "games.hegemony.content.action28307",
	action28308: "games.hegemony.content.action28308",
	action28309: "games.hegemony.content.action28309",
	action28310: "games.hegemony.content.action28310",
	action28311: "games.hegemony.content.action28311",
	action28312: "games.hegemony.content.action28312",
	action28314: "games.hegemony.content.action28314",
	action28315: "games.hegemony.content.action28315",
	action28316: "games.hegemony.content.action28316",
	action28317: "games.hegemony.content.action28317",
	action28318: "games.hegemony.content.action28318",
	action28319: "games.hegemony.content.action28319",
	action28320: "games.hegemony.content.action28320",
	action28322: "games.hegemony.content.action28322",
	action28323: "games.hegemony.content.action28323",
	action28324: "games.hegemony.content.action28324",
	action28325: "games.hegemony.content.action28325",
	action28326: "games.hegemony.content.action28326",
	action28401: "games.hegemony.content.action28401",
	action28501: "games.hegemony.content.action28501",
	action28503: "games.hegemony.content.action28503",
	action28505: "games.hegemony.content.action28505",
	action28507: "games.hegemony.content.action28507",
	action28509: "games.hegemony.content.action28509",
	action28511: "games.hegemony.content.action28511",
	action28518: "games.hegemony.content.action28518",
	action28522: "games.hegemony.content.action28522",
	action28523: "games.hegemony.content.action28523",
	action28524: "games.hegemony.content.action28524",
	action28525: "games.hegemony.content.action28525",
	action28526: "games.hegemony.content.action28526",
	action28528: "games.hegemony.content.action28528",
	action28532: "games.hegemony.content.action28532",
	action28534: "games.hegemony.content.action28534",
	action28535: "games.hegemony.content.action28535",
	action28537: "games.hegemony.content.action28537",
	action28538: "games.hegemony.content.action28538",
	action28603: "games.hegemony.content.action28603",
	event27900: "games.hegemony.content.event27900",
	reward27900: "games.hegemony.content.reward27900",
	event27901: "games.hegemony.content.event27901",
	reward27901: "games.hegemony.content.reward27901",
	event27902: "games.hegemony.content.event27902",
	reward27902: "games.hegemony.content.reward27902",
	event27903: "games.hegemony.content.event27903",
	reward27903: "games.hegemony.content.reward27903",
	event27904: "games.hegemony.content.event27904",
	reward27904: "games.hegemony.content.reward27904",
	event27905: "games.hegemony.content.event27905",
	reward27905: "games.hegemony.content.reward27905",
	event27906: "games.hegemony.content.event27906",
	reward27906: "games.hegemony.content.reward27906",
	event27907: "games.hegemony.content.event27907",
	reward27907: "games.hegemony.content.reward27907",
	event27908: "games.hegemony.content.event27908",
	reward27908: "games.hegemony.content.reward27908",
	event27909: "games.hegemony.content.event27909",
	reward27909: "games.hegemony.content.reward27909",
	event27910: "games.hegemony.content.event27910",
	reward27910: "games.hegemony.content.reward27910",
	event27911: "games.hegemony.content.event27911",
	reward27911: "games.hegemony.content.reward27911",
	event27912: "games.hegemony.content.event27912",
	reward27912: "games.hegemony.content.reward27912",
	event27913: "games.hegemony.content.event27913",
	reward27913: "games.hegemony.content.reward27913",
	event27914: "games.hegemony.content.event27914",
	reward27914: "games.hegemony.content.reward27914",
	event27915: "games.hegemony.content.event27915",
	reward27915: "games.hegemony.content.reward27915",
	event27916: "games.hegemony.content.event27916",
	reward27916: "games.hegemony.content.reward27916",
	event27917: "games.hegemony.content.event27917",
	reward27917: "games.hegemony.content.reward27917",
	event27918: "games.hegemony.content.event27918",
	reward27918: "games.hegemony.content.reward27918",
	event27919: "games.hegemony.content.event27919",
	reward27919: "games.hegemony.content.reward27919",
	event27920: "games.hegemony.content.event27920",
	reward27920: "games.hegemony.content.reward27920",
	event27921: "games.hegemony.content.event27921",
	reward27921: "games.hegemony.content.reward27921",
	event27922: "games.hegemony.content.event27922",
	reward27922: "games.hegemony.content.reward27922",
	event27923: "games.hegemony.content.event27923",
	reward27923: "games.hegemony.content.reward27923",
	event27924: "games.hegemony.content.event27924",
	reward27924: "games.hegemony.content.reward27924",
	event21200: "games.hegemony.content.event21200",
	benefit21200: "games.hegemony.content.benefit21200",
	reward21200: "games.hegemony.content.reward21200",
	event21201: "games.hegemony.content.event21201",
	benefit21201: "games.hegemony.content.benefit21201",
	reward21201: "games.hegemony.content.reward21201",
	event21202: "games.hegemony.content.event21202",
	benefit21202: "games.hegemony.content.benefit21202",
	reward21202: "games.hegemony.content.reward21202",
	event21203: "games.hegemony.content.event21203",
	benefit21203: "games.hegemony.content.benefit21203",
	reward21203: "games.hegemony.content.reward21203",
	event21204: "games.hegemony.content.event21204",
	benefit21204: "games.hegemony.content.benefit21204",
	reward21204: "games.hegemony.content.reward21204",
	event21205: "games.hegemony.content.event21205",
	benefit21205: "games.hegemony.content.benefit21205",
	reward21205: "games.hegemony.content.reward21205",
	event21206: "games.hegemony.content.event21206",
	benefit21206: "games.hegemony.content.benefit21206",
	reward21206: "games.hegemony.content.reward21206",
	event21207: "games.hegemony.content.event21207",
	benefit21207: "games.hegemony.content.benefit21207",
	reward21207: "games.hegemony.content.reward21207",
	event21208: "games.hegemony.content.event21208",
	benefit21208: "games.hegemony.content.benefit21208",
	reward21208: "games.hegemony.content.reward21208",
	event21209: "games.hegemony.content.event21209",
	benefit21209: "games.hegemony.content.benefit21209",
	reward21209: "games.hegemony.content.reward21209",
	event21210: "games.hegemony.content.event21210",
	benefit21210: "games.hegemony.content.benefit21210",
	reward21210: "games.hegemony.content.reward21210",
	event21211: "games.hegemony.content.event21211",
	benefit21211: "games.hegemony.content.benefit21211",
	reward21211: "games.hegemony.content.reward21211",
	event21212: "games.hegemony.content.event21212",
	benefit21212: "games.hegemony.content.benefit21212",
	reward21212: "games.hegemony.content.reward21212",
	event21213: "games.hegemony.content.event21213",
	benefit21213: "games.hegemony.content.benefit21213",
	reward21213: "games.hegemony.content.reward21213",
	event21214: "games.hegemony.content.event21214",
	benefit21214: "games.hegemony.content.benefit21214",
	reward21214: "games.hegemony.content.reward21214",
	event21215: "games.hegemony.content.event21215",
	benefit21215: "games.hegemony.content.benefit21215",
	reward21215: "games.hegemony.content.reward21215",
	event21216: "games.hegemony.content.event21216",
	benefit21216: "games.hegemony.content.benefit21216",
	reward21216: "games.hegemony.content.reward21216",
	event21217: "games.hegemony.content.event21217",
	benefit21217: "games.hegemony.content.benefit21217",
	reward21217: "games.hegemony.content.reward21217",
	event21218: "games.hegemony.content.event21218",
	benefit21218: "games.hegemony.content.benefit21218",
	reward21218: "games.hegemony.content.reward21218",
	event21219: "games.hegemony.content.event21219",
	benefit21219: "games.hegemony.content.benefit21219",
	reward21219: "games.hegemony.content.reward21219",
	event21220: "games.hegemony.content.event21220",
	benefit21220: "games.hegemony.content.benefit21220",
	reward21220: "games.hegemony.content.reward21220",
	event21221: "games.hegemony.content.event21221",
	benefit21221: "games.hegemony.content.benefit21221",
	reward21221: "games.hegemony.content.reward21221",
	event21222: "games.hegemony.content.event21222",
	benefit21222: "games.hegemony.content.benefit21222",
	reward21222: "games.hegemony.content.reward21222",
	event21223: "games.hegemony.content.event21223",
	benefit21223: "games.hegemony.content.benefit21223",
	reward21223: "games.hegemony.content.reward21223",
	event21224: "games.hegemony.content.event21224",
	benefit21224: "games.hegemony.content.benefit21224",
	reward21224: "games.hegemony.content.reward21224",
	agenda21315: "games.hegemony.content.agenda21315",
	agenda21316: "games.hegemony.content.agenda21316",
	agenda21317: "games.hegemony.content.agenda21317",
	agenda21318: "games.hegemony.content.agenda21318",
	agenda21319: "games.hegemony.content.agenda21319",
	agenda21400: "games.hegemony.content.agenda21400",
	agenda21401: "games.hegemony.content.agenda21401",
	agenda21402: "games.hegemony.content.agenda21402",
	agenda21403: "games.hegemony.content.agenda21403",
	agenda21404: "games.hegemony.content.agenda21404",
	agenda21505: "games.hegemony.content.agenda21505",
	agenda21506: "games.hegemony.content.agenda21506",
	agenda21507: "games.hegemony.content.agenda21507",
	agenda21508: "games.hegemony.content.agenda21508",
	agenda21509: "games.hegemony.content.agenda21509",
	agenda21610: "games.hegemony.content.agenda21610",
	agenda21611: "games.hegemony.content.agenda21611",
	agenda21612: "games.hegemony.content.agenda21612",
	agenda21613: "games.hegemony.content.agenda21613",
	agenda21614: "games.hegemony.content.agenda21614",
	crisis21100: "games.hegemony.content.crisis21100",
	crisis21101: "games.hegemony.content.crisis21101",
	crisis21102: "games.hegemony.content.crisis21102",
	crisis21103: "games.hegemony.content.crisis21103",
	crisis21104: "games.hegemony.content.crisis21104",
	crisis21105: "games.hegemony.content.crisis21105",
	crisis21106: "games.hegemony.content.crisis21106",
	crisis21107: "games.hegemony.content.crisis21107",
	crisis21108: "games.hegemony.content.crisis21108",
	crisis21109: "games.hegemony.content.crisis21109",
	history0: "games.hegemony.content.history0",
	history1: "games.hegemony.content.history1",
	history2: "games.hegemony.content.history2",
	history3: "games.hegemony.content.history3",
	history4: "games.hegemony.content.history4",
	historyReq4: "games.hegemony.content.historyReq4",
	history5: "games.hegemony.content.history5",
	history6: "games.hegemony.content.history6",
	historyReq6: "games.hegemony.content.historyReq6",
	history7: "games.hegemony.content.history7",
	historyReq7: "games.hegemony.content.historyReq7",
	history8: "games.hegemony.content.history8",
	history9: "games.hegemony.content.history9",
	history10: "games.hegemony.content.history10",
	historyReq10: "games.hegemony.content.historyReq10",
	history11: "games.hegemony.content.history11",
	history12: "games.hegemony.content.history12",
	historyReq12: "games.hegemony.content.historyReq12",
	history13: "games.hegemony.content.history13",
	historyReq13: "games.hegemony.content.historyReq13",
	history14: "games.hegemony.content.history14",
	historyReq14: "games.hegemony.content.historyReq14",
	history15: "games.hegemony.content.history15",
	historyReq15: "games.hegemony.content.historyReq15",
	history16: "games.hegemony.content.history16",
	historyReq16: "games.hegemony.content.historyReq16",
	history17: "games.hegemony.content.history17",
	historyReq17: "games.hegemony.content.historyReq17",
	history18: "games.hegemony.content.history18",
	history19: "games.hegemony.content.history19",
	historyReq19: "games.hegemony.content.historyReq19",
	history20: "games.hegemony.content.history20",
	history21: "games.hegemony.content.history21",
	history22: "games.hegemony.content.history22",
	historyReq22: "games.hegemony.content.historyReq22",
	history23: "games.hegemony.content.history23",
	historyReq23: "games.hegemony.content.historyReq23",
	history24: "games.hegemony.content.history24",
	historyReq24: "games.hegemony.content.historyReq24",
	history25: "games.hegemony.content.history25",
	historyReq25: "games.hegemony.content.historyReq25",
	history26: "games.hegemony.content.history26",
	historyReq26: "games.hegemony.content.historyReq26",
	history27: "games.hegemony.content.history27",
	historyReq27: "games.hegemony.content.historyReq27",
	history28: "games.hegemony.content.history28",
	historyReq28: "games.hegemony.content.historyReq28",
	history29: "games.hegemony.content.history29",
	historyReq29: "games.hegemony.content.historyReq29",
	history30: "games.hegemony.content.history30",
	historyReq30: "games.hegemony.content.historyReq30",
	history31: "games.hegemony.content.history31",
	historyReq31: "games.hegemony.content.historyReq31",
	history32: "games.hegemony.content.history32",
	historyReq32: "games.hegemony.content.historyReq32",
	history33: "games.hegemony.content.history33",
	historyReq33: "games.hegemony.content.historyReq33",
	history34: "games.hegemony.content.history34",
	historyReq34: "games.hegemony.content.historyReq34",
	history35: "games.hegemony.content.history35",
	history36: "games.hegemony.content.history36",
	historyReq36: "games.hegemony.content.historyReq36",
	history37: "games.hegemony.content.history37",
	history38: "games.hegemony.content.history38",
	history39: "games.hegemony.content.history39",
	history40: "games.hegemony.content.history40",
	historyReq40: "games.hegemony.content.historyReq40",
	history41: "games.hegemony.content.history41",
	historyReq41: "games.hegemony.content.historyReq41",
	history42: "games.hegemony.content.history42",
	history43: "games.hegemony.content.history43",
	historyReq43: "games.hegemony.content.historyReq43",
	history44: "games.hegemony.content.history44",
	history45: "games.hegemony.content.history45",
	historyReq45: "games.hegemony.content.historyReq45",
	history46: "games.hegemony.content.history46",
	historyReq46: "games.hegemony.content.historyReq46",
	history47: "games.hegemony.content.history47",
	historyReq47: "games.hegemony.content.historyReq47",
	history48: "games.hegemony.content.history48",
	history49: "games.hegemony.content.history49"
}, se = {
	Specialization: "games.hegemony.messages.n001",
	"Highlight Social Issues": "games.hegemony.messages.n002",
	"Cooperative Farm": "games.hegemony.messages.n003",
	"Healthcare Benefits": "games.hegemony.messages.n004",
	"State Scholarship": "games.hegemony.messages.n005",
	"Healthcare Movement": "games.hegemony.messages.n006",
	"Workers Movement": "games.hegemony.messages.n007",
	"Student Movement": "games.hegemony.messages.n008",
	"Immigration Reform": "games.hegemony.messages.n009",
	"Need for Change": "games.hegemony.messages.n010",
	"Labor Market Deregulation": "games.hegemony.messages.n011",
	"Workplace Accident": "games.hegemony.messages.n012",
	"Proletarians of the World, Unite!": "games.hegemony.messages.n013",
	"Boost Domestic Tourism": "games.hegemony.messages.n014",
	"Supplemental Income Program": "games.hegemony.messages.n015",
	"Extra Shift": "games.hegemony.messages.n016",
	"Affordable Housing": "games.hegemony.messages.n017",
	"Signing Bonus": "games.hegemony.messages.n018",
	"General Strike": "games.hegemony.messages.n019",
	"Unemployment Benefits": "games.hegemony.messages.n020",
	"Public Opinion Polling": "games.hegemony.messages.n021",
	"Fake News": "games.hegemony.messages.n022",
	"Interest Groups": "games.hegemony.messages.n023",
	"Radical Reforms": "games.hegemony.messages.n024",
	Migration: "games.hegemony.messages.n025",
	"Health Crisis": "games.hegemony.messages.n026",
	"Higher Education Program": "games.hegemony.messages.n027",
	"Political Pressure": "games.hegemony.messages.n028",
	"Foreign Recruitment": "games.hegemony.messages.n029",
	"Competitive Wages": "games.hegemony.messages.n030",
	"Global Branding": "games.hegemony.messages.n031",
	"Offshore Companies": "games.hegemony.messages.n032",
	"Foreign Market Insight": "games.hegemony.messages.n033",
	"Unemployment Initiative Program": "games.hegemony.messages.n034",
	"Foreign Partner": "games.hegemony.messages.n035",
	"Business Expansion": "games.hegemony.messages.n036",
	"Investment Opportunities": "games.hegemony.messages.n037",
	"Global Food Crisis": "games.hegemony.messages.n038",
	Industrialization: "games.hegemony.messages.n039",
	"Bid Rigging": "games.hegemony.messages.n040",
	"Private Island": "games.hegemony.messages.n041",
	"Exit Strategy": "games.hegemony.messages.n042",
	"Business Grants": "games.hegemony.messages.n043",
	"Foreign Trade Lobby": "games.hegemony.messages.n044",
	"Taxation Lobby": "games.hegemony.messages.n045",
	"Endorse Political Campaign": "games.hegemony.messages.n046",
	"Technological Progress": "games.hegemony.messages.n047",
	"Trade Protectionism Lobby": "games.hegemony.messages.n048",
	"Import Subsidy": "games.hegemony.messages.n049",
	"Small Business Grant": "games.hegemony.messages.n050",
	"Land of Opportunity": "games.hegemony.messages.n051",
	"Employment Subsidy": "games.hegemony.messages.n052",
	"Voice of Middle Class Workers": "games.hegemony.messages.n053",
	"New Theme Park": "games.hegemony.messages.n054",
	"Export Subsidy": "games.hegemony.messages.n055",
	"Personal Consumption": "games.hegemony.messages.n056",
	"Growing Business": "games.hegemony.messages.n057",
	"Public Sector Overtime": "games.hegemony.messages.n058",
	"Employment Support Scheme": "games.hegemony.messages.n059",
	"Shift Focus": "games.hegemony.messages.n060",
	"Denial of Free Speech": "games.hegemony.messages.n061",
	"Step for Representation": "games.hegemony.messages.n062",
	"Immediate Response": "games.hegemony.messages.n063",
	"Geopolitical Support": "games.hegemony.messages.n064",
	"Foreign Students": "games.hegemony.messages.n065",
	"Healthcare Program": "games.hegemony.messages.n066",
	"Medical Tourism": "games.hegemony.messages.n067",
	"A Matter of High Priority": "games.hegemony.messages.n068",
	"Emergency State": "games.hegemony.messages.n069",
	"Foreign Investment Program": "games.hegemony.messages.n070",
	"Literacy Program": "games.hegemony.messages.n071",
	"Growth in Tourism": "games.hegemony.messages.n072",
	"Allowances and Subsidies": "games.hegemony.messages.n073",
	"Agenda-Setting": "games.hegemony.messages.n074",
	"Pressing Matters": "games.hegemony.messages.n075",
	"Construction Boom": "games.hegemony.messages.n076",
	"Higher VAT": "games.hegemony.messages.n077",
	Nationalization: "games.hegemony.messages.n078",
	"Quantitative Easing": "games.hegemony.messages.n079",
	Privatization: "games.hegemony.messages.n080",
	"Foreign Financial Assistance": "games.hegemony.messages.n081",
	"Protect the Status Quo": "games.hegemony.messages.n082",
	"Change of Government Agenda": "games.hegemony.messages.n083",
	"Momentum for Change": "games.hegemony.messages.n084",
	"Reveal Political Scandal": "games.hegemony.messages.n085",
	"Rising Covid-19 Cases": "games.hegemony.messages.n086",
	"Covid-19 Vaccination Program": "games.hegemony.messages.n087",
	"Covid-19 Vaccine R&D Funding": "games.hegemony.messages.n088",
	"Covid-19 Stimulus Package": "games.hegemony.messages.n089",
	"Controlling the Narrative": "games.hegemony.messages.n090",
	"Rapid Resolution": "games.hegemony.messages.n091"
};
function g(e, t) {
	return t ? {
		key: e,
		params: t
	} : { key: e };
}
function _(e) {
	let t = se[e] ?? ie[e];
	return t ? g(t) : g("games.hegemony.messages.literal", { value: e });
}
function v(e, t) {
	let n = e.params ? Object.fromEntries(Object.entries(e.params).map(([e, n]) => [e, typeof n == "object" ? v(n, t) : n])) : void 0;
	return t(e.key, n);
}
//#endregion
//#region src/games/hegemony/data.ts
var y = [
	{
		id: 12e3,
		name: "Supermarket",
		owner: "capital",
		resource: "food",
		cost: 16,
		workers: ["skill", "any"],
		production: 4,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 1,
		helper: null,
		initial: !0,
		unlock: null
	},
	{
		id: 12001,
		name: "Shopping Mall",
		owner: "capital",
		resource: "luxury",
		cost: 16,
		workers: ["skill", "any"],
		production: 6,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 2,
		helper: null,
		initial: !0,
		unlock: null
	},
	{
		id: 12002,
		name: "College",
		owner: "capital",
		resource: "education",
		cost: 16,
		workers: ["skill", "any"],
		production: 6,
		wages: [
			10,
			20,
			30
		],
		machineryBonus: 2,
		helper: null,
		initial: !0,
		unlock: null
	},
	{
		id: 12003,
		name: "Clinic",
		owner: "capital",
		resource: "health",
		cost: 16,
		workers: ["skill", "any"],
		production: 6,
		wages: [
			10,
			20,
			30
		],
		machineryBonus: 2,
		helper: null,
		initial: !0,
		unlock: null
	},
	{
		id: 12004,
		name: "Fish Farm",
		owner: "capital",
		resource: "food",
		cost: 20,
		workers: [
			"skill",
			"any",
			"any"
		],
		production: 6,
		wages: [
			25,
			30,
			35
		],
		machineryBonus: 1,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12005,
		name: "Vegetable Farm",
		owner: "capital",
		resource: "food",
		cost: 15,
		workers: [
			"any",
			"any",
			"any"
		],
		production: 5,
		wages: [
			20,
			25,
			30
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12006,
		name: "Supermarket",
		owner: "capital",
		resource: "food",
		cost: 16,
		workers: ["skill", "any"],
		production: 4,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 1,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12007,
		name: "Fast Food Chain",
		owner: "capital",
		resource: "food",
		cost: 8,
		workers: ["any", "any"],
		production: 3,
		wages: [
			10,
			15,
			20
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12008,
		name: "Automated Grain Farm",
		owner: "capital",
		resource: "food",
		cost: 25,
		workers: [],
		production: 2,
		wages: [],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12009,
		name: "Automated Dairy Farm",
		owner: "capital",
		resource: "food",
		cost: 45,
		workers: [],
		production: 3,
		wages: [],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12010,
		name: "Stadium",
		owner: "capital",
		resource: "luxury",
		cost: 20,
		workers: [
			"skill",
			"any",
			"any"
		],
		production: 8,
		wages: [
			25,
			30,
			35
		],
		machineryBonus: 3,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12011,
		name: "Hotel",
		owner: "capital",
		resource: "luxury",
		cost: 15,
		workers: [
			"any",
			"any",
			"any"
		],
		production: 7,
		wages: [
			20,
			25,
			30
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12012,
		name: "Shopping Mall",
		owner: "capital",
		resource: "luxury",
		cost: 16,
		workers: ["skill", "any"],
		production: 6,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 2,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12013,
		name: "Fashion Company",
		owner: "capital",
		resource: "luxury",
		cost: 8,
		workers: ["any", "any"],
		production: 4,
		wages: [
			10,
			15,
			20
		],
		machineryBonus: 2,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12014,
		name: "Electronics Manufacturer",
		owner: "capital",
		resource: "luxury",
		cost: 25,
		workers: [],
		production: 3,
		wages: [],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12015,
		name: "Car Manufacturer",
		owner: "capital",
		resource: "luxury",
		cost: 45,
		workers: [],
		production: 5,
		wages: [],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12016,
		name: "Pharmaceutical Company",
		owner: "capital",
		resource: "health",
		cost: 20,
		workers: [
			"skill",
			"any",
			"any"
		],
		production: 8,
		wages: [
			20,
			30,
			40
		],
		machineryBonus: 3,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12017,
		name: "Medical Village",
		owner: "capital",
		resource: "health",
		cost: 24,
		workers: [
			"skill",
			"any",
			"any"
		],
		production: 9,
		wages: [
			20,
			30,
			40
		],
		machineryBonus: 2,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12018,
		name: "Clinic",
		owner: "capital",
		resource: "health",
		cost: 16,
		workers: ["skill", "any"],
		production: 6,
		wages: [
			10,
			20,
			30
		],
		machineryBonus: 2,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12019,
		name: "Hospital",
		owner: "capital",
		resource: "health",
		cost: 20,
		workers: ["skill", "any"],
		production: 7,
		wages: [
			10,
			20,
			30
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12020,
		name: "Institute of Technology",
		owner: "capital",
		resource: "education",
		cost: 20,
		workers: [
			"skill",
			"any",
			"any"
		],
		production: 8,
		wages: [
			20,
			30,
			40
		],
		machineryBonus: 3,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12021,
		name: "University",
		owner: "capital",
		resource: "education",
		cost: 24,
		workers: [
			"skill",
			"any",
			"any"
		],
		production: 9,
		wages: [
			20,
			30,
			40
		],
		machineryBonus: 2,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12022,
		name: "College",
		owner: "capital",
		resource: "education",
		cost: 16,
		workers: ["skill", "any"],
		production: 6,
		wages: [
			10,
			20,
			30
		],
		machineryBonus: 2,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12023,
		name: "Academy",
		owner: "capital",
		resource: "education",
		cost: 20,
		workers: ["skill", "any"],
		production: 7,
		wages: [
			10,
			20,
			30
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12024,
		name: "TV Station",
		owner: "capital",
		resource: "influence",
		cost: 24,
		workers: [
			"skill",
			"any",
			"any"
		],
		production: 4,
		wages: [
			20,
			30,
			40
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12025,
		name: "Publishing House",
		owner: "capital",
		resource: "influence",
		cost: 12,
		workers: [
			"any",
			"any",
			"any"
		],
		production: 3,
		wages: [
			20,
			25,
			30
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12026,
		name: "Lobbying Firm",
		owner: "capital",
		resource: "influence",
		cost: 16,
		workers: ["skill", "any"],
		production: 3,
		wages: [
			10,
			20,
			30
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12027,
		name: "Radio Station",
		owner: "capital",
		resource: "influence",
		cost: 8,
		workers: ["any", "any"],
		production: 2,
		wages: [
			10,
			15,
			20
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12100,
		name: "Convenience Store",
		owner: "middle",
		resource: "food",
		cost: 14,
		workers: ["skill"],
		production: 2,
		wages: [
			6,
			8,
			10
		],
		machineryBonus: 0,
		helper: {
			skill: "any",
			bonus: 1
		},
		initial: !0,
		unlock: null
	},
	{
		id: 12101,
		name: "Doctor's Office",
		owner: "middle",
		resource: "health",
		cost: 12,
		workers: ["skill"],
		production: 2,
		wages: [
			6,
			8,
			10
		],
		machineryBonus: 0,
		helper: {
			skill: "any",
			bonus: 2
		},
		initial: !0,
		unlock: null
	},
	{
		id: 12102,
		name: "Fast Food Restaurant",
		owner: "middle",
		resource: "food",
		cost: 20,
		workers: ["skill", "any"],
		production: 3,
		wages: [],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12103,
		name: "Convenience Store",
		owner: "middle",
		resource: "food",
		cost: 14,
		workers: ["skill"],
		production: 2,
		wages: [
			6,
			8,
			10
		],
		machineryBonus: 0,
		helper: {
			skill: "any",
			bonus: 1
		},
		initial: !1,
		unlock: null
	},
	{
		id: 12104,
		name: "Organic Farm",
		owner: "middle",
		resource: "food",
		cost: 20,
		workers: ["skill"],
		production: 2,
		wages: [
			9,
			12,
			15
		],
		machineryBonus: 0,
		helper: {
			skill: "skill",
			bonus: 2
		},
		initial: !1,
		unlock: null
	},
	{
		id: 12105,
		name: "Jewelry Store",
		owner: "middle",
		resource: "luxury",
		cost: 16,
		workers: ["skill", "any"],
		production: 4,
		wages: [],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12106,
		name: "Game Store",
		owner: "middle",
		resource: "luxury",
		cost: 12,
		workers: ["skill"],
		production: 2,
		wages: [
			6,
			8,
			10
		],
		machineryBonus: 0,
		helper: {
			skill: "any",
			bonus: 2
		},
		initial: !1,
		unlock: null
	},
	{
		id: 12107,
		name: "Electronics Store",
		owner: "middle",
		resource: "luxury",
		cost: 20,
		workers: ["skill"],
		production: 2,
		wages: [
			9,
			12,
			15
		],
		machineryBonus: 0,
		helper: {
			skill: "skill",
			bonus: 4
		},
		initial: !1,
		unlock: null
	},
	{
		id: 12108,
		name: "Pharmacy",
		owner: "middle",
		resource: "health",
		cost: 16,
		workers: ["skill", "any"],
		production: 4,
		wages: [],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12109,
		name: "Doctor's Office",
		owner: "middle",
		resource: "health",
		cost: 12,
		workers: ["skill"],
		production: 2,
		wages: [
			6,
			8,
			10
		],
		machineryBonus: 0,
		helper: {
			skill: "any",
			bonus: 2
		},
		initial: !1,
		unlock: null
	},
	{
		id: 12110,
		name: "Medical Laboratory",
		owner: "middle",
		resource: "health",
		cost: 20,
		workers: ["skill"],
		production: 2,
		wages: [
			9,
			12,
			15
		],
		machineryBonus: 0,
		helper: {
			skill: "skill",
			bonus: 4
		},
		initial: !1,
		unlock: null
	},
	{
		id: 12111,
		name: "Training Center",
		owner: "middle",
		resource: "education",
		cost: 16,
		workers: ["skill", "any"],
		production: 4,
		wages: [],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12112,
		name: "Tutoring Company",
		owner: "middle",
		resource: "education",
		cost: 12,
		workers: ["skill"],
		production: 2,
		wages: [
			6,
			8,
			10
		],
		machineryBonus: 0,
		helper: {
			skill: "any",
			bonus: 2
		},
		initial: !1,
		unlock: null
	},
	{
		id: 12113,
		name: "Private School",
		owner: "middle",
		resource: "education",
		cost: 20,
		workers: ["skill"],
		production: 2,
		wages: [
			9,
			12,
			15
		],
		machineryBonus: 0,
		helper: {
			skill: "skill",
			bonus: 4
		},
		initial: !1,
		unlock: null
	},
	{
		id: 12114,
		name: "PR Agency",
		owner: "middle",
		resource: "influence",
		cost: 20,
		workers: ["skill", "any"],
		production: 3,
		wages: [],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	},
	{
		id: 12115,
		name: "Local Newspaper",
		owner: "middle",
		resource: "influence",
		cost: 14,
		workers: ["skill"],
		production: 2,
		wages: [
			6,
			8,
			10
		],
		machineryBonus: 0,
		helper: {
			skill: "any",
			bonus: 1
		},
		initial: !1,
		unlock: null
	},
	{
		id: 12116,
		name: "Regional Radio Station",
		owner: "middle",
		resource: "influence",
		cost: 20,
		workers: ["skill"],
		production: 2,
		wages: [
			9,
			12,
			15
		],
		machineryBonus: 0,
		helper: {
			skill: "any",
			bonus: 2
		},
		initial: !1,
		unlock: null
	},
	{
		id: 26800,
		name: "Regional TV Station",
		owner: "state",
		resource: "influence",
		cost: 20,
		workers: ["skill", "any"],
		production: 3,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "C"
	},
	{
		id: 26900,
		name: "Public University",
		owner: "state",
		resource: "education",
		cost: 20,
		workers: ["skill", "any"],
		production: 4,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "C"
	},
	{
		id: 27e3,
		name: "Public Hospital",
		owner: "state",
		resource: "health",
		cost: 20,
		workers: ["skill", "any"],
		production: 4,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "C"
	},
	{
		id: 27100,
		name: "Public Hospital",
		owner: "state",
		resource: "health",
		cost: 20,
		workers: ["skill", "any"],
		production: 4,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "B"
	},
	{
		id: 27200,
		name: "Public University",
		owner: "state",
		resource: "education",
		cost: 20,
		workers: ["skill", "any"],
		production: 4,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "B"
	},
	{
		id: 27300,
		name: "Regional TV Station",
		owner: "state",
		resource: "influence",
		cost: 20,
		workers: ["skill", "any"],
		production: 3,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "B"
	},
	{
		id: 27400,
		name: "National Public Broadcasting",
		owner: "state",
		resource: "influence",
		cost: 30,
		workers: [
			"skill",
			"any",
			"any"
		],
		production: 4,
		wages: [
			25,
			30,
			35
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "A"
	},
	{
		id: 27500,
		name: "Technical University",
		owner: "state",
		resource: "education",
		cost: 30,
		workers: [
			"skill",
			"any",
			"any"
		],
		production: 6,
		wages: [
			25,
			30,
			35
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "A"
	},
	{
		id: 27600,
		name: "University Hospital",
		owner: "state",
		resource: "health",
		cost: 30,
		workers: [
			"skill",
			"any",
			"any"
		],
		production: 6,
		wages: [
			25,
			30,
			35
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "A"
	},
	{
		id: 18600,
		name: "Public Hospital",
		owner: "state",
		resource: "health",
		cost: 20,
		workers: ["skill", "any"],
		production: 4,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "A"
	},
	{
		id: 18700,
		name: "Public University",
		owner: "state",
		resource: "education",
		cost: 20,
		workers: ["skill", "any"],
		production: 4,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "A"
	},
	{
		id: 18800,
		name: "Regional TV Station",
		owner: "state",
		resource: "influence",
		cost: 20,
		workers: ["skill", "any"],
		production: 3,
		wages: [
			15,
			20,
			25
		],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: "A"
	},
	{
		id: 12300,
		name: "Cooperative Farm",
		owner: "working",
		resource: "food",
		cost: 0,
		workers: [
			"any",
			"any",
			"any"
		],
		production: 2,
		wages: [],
		machineryBonus: 0,
		helper: null,
		initial: !1,
		unlock: null
	}
], b = [
	{
		id: 24900,
		role: "working",
		name: "Specialization",
		requirement: "7B/7C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24901,
		role: "working",
		name: "Specialization",
		requirement: "7B/7C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24902,
		role: "working",
		name: "Highlight Social Issues",
		requirement: null,
		legitimacy: "working:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24903,
		role: "working",
		name: "Cooperative Farm",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24904,
		role: "working",
		name: "Cooperative Farm",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24905,
		role: "working",
		name: "Healthcare Benefits",
		requirement: "4B/4C",
		legitimacy: "working:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24906,
		role: "working",
		name: "Healthcare Benefits",
		requirement: "4B/4C",
		legitimacy: "working:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24907,
		role: "working",
		name: "Healthcare Movement",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24908,
		role: "working",
		name: "Need for Change",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24909,
		role: "working",
		name: "Need for Change",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24910,
		role: "working",
		name: "Need for Change",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24911,
		role: "working",
		name: "Labor Market Deregulation",
		requirement: "2B/2C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24912,
		role: "working",
		name: "Labor Market Deregulation",
		requirement: "2B/2C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24913,
		role: "working",
		name: "Migration",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24914,
		role: "working",
		name: "Migration",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24915,
		role: "working",
		name: "Workers Movement",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24916,
		role: "working",
		name: "Workplace Accident",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24917,
		role: "working",
		name: "Proletarians of the World, Unite!",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24918,
		role: "working",
		name: "Proletarians of the World, Unite!",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24919,
		role: "working",
		name: "Boost Domestic Tourism",
		requirement: "1A/1B",
		legitimacy: "working:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24920,
		role: "working",
		name: "Boost Domestic Tourism",
		requirement: "1A/1B",
		legitimacy: "working:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24921,
		role: "working",
		name: "Public Opinion Polling",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24922,
		role: "working",
		name: "Student Movement",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24923,
		role: "working",
		name: "Supplemental Income Program",
		requirement: "2B/2C",
		legitimacy: "working:+1/10 employed workers",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24924,
		role: "working",
		name: "Supplemental Income Program",
		requirement: "2B/2C",
		legitimacy: "working:+1/10 employed workers",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24925,
		role: "working",
		name: "Extra Shift",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24926,
		role: "working",
		name: "Extra Shift",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24927,
		role: "working",
		name: "Affordable Housing",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24928,
		role: "working",
		name: "Immigration Reform",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24929,
		role: "working",
		name: "Signing Bonus",
		requirement: "2B/2C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24930,
		role: "working",
		name: "Signing Bonus",
		requirement: "2B/2C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24931,
		role: "working",
		name: "General Strike",
		requirement: "2B/2C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24932,
		role: "working",
		name: "Fake News",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24933,
		role: "working",
		name: "General Strike",
		requirement: "2B/2C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24934,
		role: "working",
		name: "State Scholarship",
		requirement: "5B/5C",
		legitimacy: "working:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24935,
		role: "working",
		name: "State Scholarship",
		requirement: "5B/5C",
		legitimacy: "working:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24936,
		role: "working",
		name: "Radical Reforms",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24937,
		role: "working",
		name: "Unemployment Benefits",
		requirement: "4A/4B",
		legitimacy: "working:+1/3 unemployed workers",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24938,
		role: "working",
		name: "Unemployment Benefits",
		requirement: "4A/4B",
		legitimacy: "working:+1/3 unemployed workers",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 24939,
		role: "working",
		name: "Interest Groups",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28e3,
		role: "working",
		name: "Rising Covid-19 Cases",
		requirement: null,
		legitimacy: "working:+1",
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28001,
		role: "working",
		name: "Momentum for Change",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28002,
		role: "working",
		name: "Protect the Status Quo",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28003,
		role: "working",
		name: "Change of Government Agenda",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28004,
		role: "working",
		name: "Reveal Political Scandal",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28100,
		role: "state",
		name: "Employment Support Scheme",
		requirement: null,
		legitimacy: "working:+1,middle:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28101,
		role: "state",
		name: "Shift Focus",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28102,
		role: "state",
		name: "Denial of Free Speech",
		requirement: null,
		legitimacy: "chosen two:-1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28103,
		role: "state",
		name: "Step for Representation",
		requirement: null,
		legitimacy: "target:+2",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28104,
		role: "state",
		name: "Immediate Response",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28105,
		role: "state",
		name: "Geopolitical Support",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28106,
		role: "state",
		name: "Foreign Students",
		requirement: "1A/1B",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28107,
		role: "state",
		name: "Healthcare Program",
		requirement: "4A/4B",
		legitimacy: "target:+1",
		expansion: "base",
		legitimacyKind: "token"
	},
	{
		id: 28108,
		role: "state",
		name: "Medical Tourism",
		requirement: "1A/1B",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28109,
		role: "state",
		name: "Unemployment Initiative Program",
		requirement: "4A/4B",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28110,
		role: "state",
		name: "A Matter of High Priority",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28111,
		role: "state",
		name: "Emergency State",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28112,
		role: "state",
		name: "Foreign Investment Program",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28113,
		role: "state",
		name: "Literacy Program",
		requirement: "5A/5B",
		legitimacy: "target:+1",
		expansion: "base",
		legitimacyKind: "token"
	},
	{
		id: 28114,
		role: "state",
		name: "Growth in Tourism",
		requirement: null,
		legitimacy: "middle:+1,capital:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28115,
		role: "state",
		name: "Supplemental Income Program",
		requirement: "2B/2C",
		legitimacy: "target:+1/10 paid",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28116,
		role: "state",
		name: "Allowances and Subsidies",
		requirement: null,
		legitimacy: "target:+1",
		expansion: "base",
		legitimacyKind: "token"
	},
	{
		id: 28117,
		role: "state",
		name: "Agenda-Setting",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28118,
		role: "state",
		name: "Pressing Matters",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28119,
		role: "state",
		name: "Radical Reforms",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28120,
		role: "state",
		name: "Public Sector Overtime",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28121,
		role: "state",
		name: "Construction Boom",
		requirement: null,
		legitimacy: "working:+1,capital:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28122,
		role: "state",
		name: "Business Grants",
		requirement: "1A/1B",
		legitimacy: "capital:+1/3 companies",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28123,
		role: "state",
		name: "Higher VAT",
		requirement: null,
		legitimacy: "chosen two:-1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28124,
		role: "state",
		name: "Nationalization",
		requirement: "1A/1B",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28125,
		role: "state",
		name: "Quantitative Easing",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28126,
		role: "state",
		name: "Privatization",
		requirement: "1B/1C",
		legitimacy: "capital:+1",
		expansion: "base",
		legitimacyKind: "token"
	},
	{
		id: 28127,
		role: "state",
		name: "Foreign Financial Assistance",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28128,
		role: "state",
		name: "Immediate Response",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28129,
		role: "state",
		name: "Step for Representation",
		requirement: null,
		legitimacy: "target:+2",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28130,
		role: "state",
		name: "Public Sector Overtime",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28131,
		role: "state",
		name: "Foreign Investment Program",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28132,
		role: "state",
		name: "Higher VAT",
		requirement: null,
		legitimacy: "chosen two:-1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28133,
		role: "state",
		name: "Shift Focus",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28134,
		role: "state",
		name: "Agenda-Setting",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28135,
		role: "state",
		name: "A Matter of High Priority",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28136,
		role: "state",
		name: "Allowances and Subsidies",
		requirement: null,
		legitimacy: "target:+1",
		expansion: "base",
		legitimacyKind: "token"
	},
	{
		id: 28137,
		role: "state",
		name: "Foreign Financial Assistance",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28138,
		role: "state",
		name: "Pressing Matters",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28139,
		role: "state",
		name: "Geopolitical Support",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28200,
		role: "state",
		name: "Protect the Status Quo",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28201,
		role: "state",
		name: "Change of Government Agenda",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28202,
		role: "state",
		name: "Reveal Political Scandal",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28203,
		role: "state",
		name: "Momentum for Change",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28204,
		role: "state",
		name: "Covid-19 Vaccination Program",
		requirement: null,
		legitimacy: "target:+1/3 health",
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28300,
		role: "capital",
		name: "Health Crisis",
		requirement: null,
		legitimacy: "capital:+1/3 health",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28301,
		role: "capital",
		name: "Higher Education Program",
		requirement: null,
		legitimacy: "capital:+1/3 education",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28302,
		role: "capital",
		name: "Political Pressure",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28303,
		role: "capital",
		name: "Foreign Recruitment",
		requirement: "7B/7C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28304,
		role: "capital",
		name: "Competitive Wages",
		requirement: "2B/2C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28305,
		role: "capital",
		name: "Global Branding",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28306,
		role: "capital",
		name: "Interest Groups",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28307,
		role: "capital",
		name: "Offshore Companies",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28308,
		role: "capital",
		name: "Foreign Market Insight",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28309,
		role: "capital",
		name: "Unemployment Initiative Program",
		requirement: "4A/4B",
		legitimacy: "capital:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28310,
		role: "capital",
		name: "Foreign Partner",
		requirement: "6B/6C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28311,
		role: "capital",
		name: "Business Expansion",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28312,
		role: "capital",
		name: "Investment Opportunities",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28313,
		role: "capital",
		name: "Fake News",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28314,
		role: "capital",
		name: "Global Food Crisis",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28315,
		role: "capital",
		name: "Industrialization",
		requirement: "1A/1B",
		legitimacy: "capital:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28316,
		role: "capital",
		name: "Bid Rigging",
		requirement: null,
		legitimacy: "capital:+1/3 luxury",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28317,
		role: "capital",
		name: "Private Island",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28318,
		role: "capital",
		name: "Exit Strategy",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28319,
		role: "capital",
		name: "Business Grants",
		requirement: "1A/1B",
		legitimacy: "capital:+1/3 companies",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28320,
		role: "capital",
		name: "Foreign Trade Lobby",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28321,
		role: "capital",
		name: "Radical Reforms",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28322,
		role: "capital",
		name: "Extra Shift",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28323,
		role: "capital",
		name: "Taxation Lobby",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28324,
		role: "capital",
		name: "Endorse Political Campaign",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28325,
		role: "capital",
		name: "Technological Progress",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28326,
		role: "capital",
		name: "Trade Protectionism Lobby",
		requirement: "6A/6B",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28327,
		role: "capital",
		name: "Public Opinion Polling",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28328,
		role: "capital",
		name: "Competitive Wages",
		requirement: "2B/2C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28329,
		role: "capital",
		name: "Exit Strategy",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28330,
		role: "capital",
		name: "Technological Progress",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28331,
		role: "capital",
		name: "Technological Progress",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28332,
		role: "capital",
		name: "Foreign Recruitment",
		requirement: "7B/7C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28333,
		role: "capital",
		name: "Foreign Partner",
		requirement: "6B/6C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28334,
		role: "capital",
		name: "Business Expansion",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28335,
		role: "capital",
		name: "Extra Shift",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28336,
		role: "capital",
		name: "Foreign Market Insight",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28337,
		role: "capital",
		name: "Investment Opportunities",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28338,
		role: "capital",
		name: "Unemployment Initiative Program",
		requirement: "4A/4B",
		legitimacy: "capital:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28339,
		role: "capital",
		name: "Offshore Companies",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28400,
		role: "capital",
		name: "Protect the Status Quo",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28401,
		role: "capital",
		name: "Covid-19 Vaccine R&D Funding",
		requirement: null,
		legitimacy: "capital:+1/operational health company",
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28402,
		role: "capital",
		name: "Change of Government Agenda",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28403,
		role: "capital",
		name: "Momentum for Change",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28404,
		role: "capital",
		name: "Reveal Political Scandal",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28500,
		role: "middle",
		name: "Healthcare Benefits",
		requirement: "4B/4C",
		legitimacy: "middle:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28501,
		role: "middle",
		name: "Import Subsidy",
		requirement: "6A/6B",
		legitimacy: "middle:+1/4 goods",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28502,
		role: "middle",
		name: "Import Subsidy",
		requirement: "6A/6B",
		legitimacy: "middle:+1/4 goods",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28503,
		role: "middle",
		name: "Small Business Grant",
		requirement: "1A/1B",
		legitimacy: "middle:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28504,
		role: "middle",
		name: "Small Business Grant",
		requirement: "1A/1B",
		legitimacy: "middle:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28505,
		role: "middle",
		name: "Land of Opportunity",
		requirement: "7B/7C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28506,
		role: "middle",
		name: "Land of Opportunity",
		requirement: "7B/7C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28507,
		role: "middle",
		name: "Investment Opportunities",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28508,
		role: "middle",
		name: "Investment Opportunities",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28509,
		role: "middle",
		name: "Foreign Market Insight",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28510,
		role: "middle",
		name: "Foreign Market Insight",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28511,
		role: "middle",
		name: "Employment Subsidy",
		requirement: "1A/1B",
		legitimacy: "middle:+1/3 qualifying companies",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28512,
		role: "middle",
		name: "Employment Subsidy",
		requirement: "1A/1B",
		legitimacy: "middle:+1/3 qualifying companies",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28513,
		role: "middle",
		name: "Public Opinion Polling",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28514,
		role: "middle",
		name: "Public Opinion Polling",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28515,
		role: "middle",
		name: "Migration",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28516,
		role: "middle",
		name: "Migration",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28517,
		role: "middle",
		name: "Fake News",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28518,
		role: "middle",
		name: "Specialization",
		requirement: "7B/7C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28519,
		role: "middle",
		name: "Specialization",
		requirement: "7B/7C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28520,
		role: "middle",
		name: "State Scholarship",
		requirement: "5B/5C",
		legitimacy: "middle:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28521,
		role: "middle",
		name: "Highlight Social Issues",
		requirement: null,
		legitimacy: "middle:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28522,
		role: "middle",
		name: "Health Crisis",
		requirement: null,
		legitimacy: "middle:+1/3 health",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28523,
		role: "middle",
		name: "Unemployment Initiative Program",
		requirement: "4A/4B",
		legitimacy: "middle:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28524,
		role: "middle",
		name: "Higher Education Program",
		requirement: null,
		legitimacy: "middle:+1/3 education",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28525,
		role: "middle",
		name: "Voice of Middle Class Workers",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28526,
		role: "middle",
		name: "New Theme Park",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28527,
		role: "middle",
		name: "Interest Groups",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28528,
		role: "middle",
		name: "Export Subsidy",
		requirement: "1A/1B",
		legitimacy: "middle:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28529,
		role: "middle",
		name: "Export Subsidy",
		requirement: "1A/1B",
		legitimacy: "middle:+1",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28530,
		role: "middle",
		name: "Migration",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28531,
		role: "middle",
		name: "Labor Market Deregulation",
		requirement: "2B/2C",
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28532,
		role: "middle",
		name: "Personal Consumption",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28533,
		role: "middle",
		name: "Personal Consumption",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28534,
		role: "middle",
		name: "Immigration Reform",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28535,
		role: "middle",
		name: "Growing Business",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28536,
		role: "middle",
		name: "Growing Business",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28537,
		role: "middle",
		name: "Public Sector Overtime",
		requirement: null,
		legitimacy: null,
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28538,
		role: "middle",
		name: "Supplemental Income Program",
		requirement: "2B/2C",
		legitimacy: "middle:+1/5 qualifying workers",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28539,
		role: "middle",
		name: "Supplemental Income Program",
		requirement: "2B/2C",
		legitimacy: "middle:+1/5 qualifying workers",
		expansion: "base",
		legitimacyKind: "track"
	},
	{
		id: 28600,
		role: "middle",
		name: "Change of Government Agenda",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28601,
		role: "middle",
		name: "Protect the Status Quo",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28602,
		role: "middle",
		name: "Momentum for Change",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28603,
		role: "middle",
		name: "Covid-19 Stimulus Package",
		requirement: null,
		legitimacy: "middle:+1/15 paid",
		expansion: "crisis-control",
		legitimacyKind: "track"
	},
	{
		id: 28604,
		role: "middle",
		name: "Reveal Political Scandal",
		requirement: null,
		legitimacy: null,
		expansion: "crisis-control",
		legitimacyKind: "track"
	}
], x = [
	{
		id: 27900,
		name: "Political Scandal",
		penalty: "any2",
		reward: "W/M/C:L+1 per influence",
		expansion: "base"
	},
	{
		id: 27901,
		name: "Neighbors at War",
		penalty: "any2",
		reward: "V+1 per health",
		expansion: "base"
	},
	{
		id: 27902,
		name: "Pandemic",
		penalty: "MC",
		reward: "M/C:L+1 per 3 health",
		expansion: "base"
	},
	{
		id: 27903,
		name: "Strike at the Port",
		penalty: "WC",
		reward: "W/C:T+1",
		expansion: "base"
	},
	{
		id: 27904,
		name: "Low Education Index",
		penalty: "WM",
		reward: "W:L+1; M:L+1",
		expansion: "base"
	},
	{
		id: 27905,
		name: "Need for Sustainability Initiative",
		penalty: "any2",
		reward: "W/M/C:T+1 each chosen",
		expansion: "base"
	},
	{
		id: 27906,
		name: "Fear of Deflation",
		penalty: "any2",
		reward: "V+2 per 15",
		expansion: "base"
	},
	{
		id: 27907,
		name: "Declining Birth Rate",
		penalty: "WM",
		reward: "W:L+1; M:L+1",
		expansion: "base"
	},
	{
		id: 27908,
		name: "Need for Stimulus Package",
		penalty: "any2",
		reward: "10:V+3; 15:W/M/C:L+1",
		expansion: "base"
	},
	{
		id: 27909,
		name: "Demand for Thirteenth Month Pay",
		penalty: "WM",
		reward: "W:T+1 per 25; M:L+1 per 15",
		expansion: "base"
	},
	{
		id: 27910,
		name: "Companies Demand Better Internet",
		penalty: "MC",
		reward: "M/C:L+1 per 2 luxury",
		expansion: "base"
	},
	{
		id: 27911,
		name: "Drought",
		penalty: "WC",
		reward: "W/C:T+1",
		expansion: "base"
	},
	{
		id: 27912,
		name: "Local Industries in Turmoil",
		penalty: "MC",
		reward: "M:T+1 per 20; C:V+2 per 15",
		expansion: "base"
	},
	{
		id: 27913,
		name: "Technological Illiteracy",
		penalty: "WC",
		reward: "W/C:L+1 per 2 items",
		expansion: "base"
	},
	{
		id: 27914,
		name: "Demand for Higher Welfare Standards",
		penalty: "WM",
		reward: "W/M:L+1",
		expansion: "base"
	},
	{
		id: 27915,
		name: "Developing Countries in Need",
		penalty: "any2",
		reward: "V+1 per education",
		expansion: "base"
	},
	{
		id: 27916,
		name: "Infant Industry Requires Help",
		penalty: "MC",
		reward: "M/C:T+1",
		expansion: "base"
	},
	{
		id: 27917,
		name: "Outdated Public Sector Infrastructure",
		penalty: "MC",
		reward: "M/C:L+1 per 3 luxury",
		expansion: "base"
	},
	{
		id: 27918,
		name: "Earthquake",
		penalty: "WM",
		reward: "W/M:L+1 per 2 items",
		expansion: "base"
	},
	{
		id: 27919,
		name: "Demand for Pension Reform",
		penalty: "WM",
		reward: "W:V+2 per 15; M:T+1 per 20",
		expansion: "base"
	},
	{
		id: 27920,
		name: "Political Polarization",
		penalty: "WC",
		reward: "W/C:L+1 per 2 cubes",
		expansion: "base"
	},
	{
		id: 27921,
		name: "Civil Unrest",
		penalty: "WC",
		reward: "W/C:L+2",
		expansion: "base"
	},
	{
		id: 27922,
		name: "Unfair Representation",
		penalty: "any2",
		reward: "W/M/C:L+1",
		expansion: "base"
	},
	{
		id: 27923,
		name: "Low University Ratings",
		penalty: "MC",
		reward: "M/C:L+1 per 3 education",
		expansion: "base"
	},
	{
		id: 27924,
		name: "Global Supply Chain Crisis",
		penalty: "WM",
		reward: "W:L+1 per 2 items; M:V+1 per 2 items",
		expansion: "base"
	},
	{
		id: 21200,
		name: "Low Global Innovation Index Ranking",
		penalty: "WC",
		reward: "W/C:L+2",
		benefitPhase: "preparation",
		expansion: "alternative-events"
	},
	{
		id: 21201,
		name: "Demand for Better Public Education",
		penalty: "MC",
		reward: "M/C:L+1",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21202,
		name: "Demand for Subsidies by Dairy Farmers",
		penalty: "WC",
		reward: "W:L+2; C:T+1",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21203,
		name: "Demand for Administrative Upgrade",
		penalty: "MC",
		reward: "M/C:L+1",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21204,
		name: "High Illiteracy Rate",
		penalty: "WM",
		reward: "W/M:L+2",
		benefitPhase: "preparation",
		expansion: "alternative-events"
	},
	{
		id: 21205,
		name: "Low Vaccination Rates",
		penalty: "WM",
		reward: "W/M:L+2",
		benefitPhase: "preparation",
		expansion: "alternative-events"
	},
	{
		id: 21206,
		name: "Political Pressure",
		penalty: "WC",
		reward: "W:L+2; C:T+1",
		benefitPhase: "elections",
		expansion: "alternative-events"
	},
	{
		id: 21207,
		name: "Demand for Energy Subsidy",
		penalty: "any2",
		reward: "W/M/C:T+1",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21208,
		name: "Smear Campaign",
		penalty: "any2",
		reward: "W/M/C:L+2",
		benefitPhase: "elections",
		expansion: "alternative-events"
	},
	{
		id: 21209,
		name: "Demand for Economic Stimulus",
		penalty: "MC",
		reward: "M:L+2; C:V+3",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21210,
		name: "Public Pressure",
		penalty: "WC",
		reward: "W/C:L+2",
		benefitPhase: "elections",
		expansion: "alternative-events"
	},
	{
		id: 21211,
		name: "Hurricane",
		penalty: "WM",
		reward: "W/M:T+1",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21212,
		name: "Rising Traffic Accidents",
		penalty: "WM",
		reward: "W/M:V+3",
		benefitPhase: "preparation",
		expansion: "alternative-events"
	},
	{
		id: 21213,
		name: "Tax Returns",
		penalty: "any2",
		reward: "W/M/C:T+1",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21214,
		name: "Fear of Recession",
		penalty: "any2",
		reward: "W:L+2; M:T+1; C:V+3",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21215,
		name: "Student Protest",
		penalty: "any2",
		reward: "W:V+3; M:L+2; C:T+1",
		benefitPhase: "preparation",
		expansion: "alternative-events"
	},
	{
		id: 21216,
		name: "Rising Flu Infections",
		penalty: "MC",
		reward: "M/C:L+1",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21217,
		name: "Low Political Engagement",
		penalty: "WC",
		reward: "W:V+3; C:L+2",
		benefitPhase: "elections",
		expansion: "alternative-events"
	},
	{
		id: 21218,
		name: "Demand for Digital Transformation",
		penalty: "MC",
		reward: "M/C:L+2",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21219,
		name: "Rising Economic Inequality",
		penalty: "WM",
		reward: "W:L+2; M:T+1",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21220,
		name: "Healthcare Scandal",
		penalty: "any2",
		reward: "W:T+1; M:V+3; C:L+2",
		benefitPhase: "preparation",
		expansion: "alternative-events"
	},
	{
		id: 21221,
		name: "Public Sector Union Negotiations",
		penalty: "WM",
		reward: "W:T+1; M:V+2",
		benefitPhase: "production",
		expansion: "alternative-events"
	},
	{
		id: 21222,
		name: "Demand for Startup Support",
		penalty: "MC",
		reward: "M/C:L+1",
		benefitPhase: "action",
		expansion: "alternative-events"
	},
	{
		id: 21223,
		name: "Gerrymandering",
		penalty: "any2",
		reward: "W/M/C:L+2",
		benefitPhase: "elections",
		expansion: "alternative-events"
	},
	{
		id: 21224,
		name: "Demand for State Intervention",
		penalty: "WC",
		reward: "W/C:V+2",
		benefitPhase: "production",
		expansion: "alternative-events"
	}
], ce = [
	{
		id: 26600,
		working: "any",
		middle: "education"
	},
	{
		id: 26601,
		working: "health",
		middle: "any"
	},
	{
		id: 26602,
		working: "education",
		middle: "any"
	},
	{
		id: 26603,
		working: "any",
		middle: "luxury"
	},
	{
		id: 26604,
		working: "luxury",
		middle: "any"
	},
	{
		id: 26605,
		working: "any",
		middle: "education"
	},
	{
		id: 26606,
		working: "any",
		middle: "education"
	},
	{
		id: 26607,
		working: "education",
		middle: "any"
	},
	{
		id: 26608,
		working: "any",
		middle: "luxury"
	},
	{
		id: 26609,
		working: "luxury",
		middle: "any"
	},
	{
		id: 26610,
		working: "any",
		middle: "luxury"
	},
	{
		id: 26611,
		working: "any",
		middle: "influence"
	},
	{
		id: 26612,
		working: "health",
		middle: "any"
	},
	{
		id: 26613,
		working: "any",
		middle: "health"
	},
	{
		id: 26614,
		working: "any",
		middle: "health"
	},
	{
		id: 26615,
		working: "any",
		middle: "health"
	},
	{
		id: 26616,
		working: "food",
		middle: "any"
	},
	{
		id: 26617,
		working: "any",
		middle: "influence"
	},
	{
		id: 26618,
		working: "any",
		middle: "influence"
	},
	{
		id: 26619,
		working: "any",
		middle: "food"
	},
	{
		id: 26620,
		working: "influence",
		middle: "any"
	},
	{
		id: 26621,
		working: "influence",
		middle: "any"
	},
	{
		id: 26622,
		working: "any",
		middle: "food"
	},
	{
		id: 26623,
		working: "food",
		middle: "any"
	},
	{
		id: 26624,
		working: "any",
		middle: "food"
	}
], le = [
	{
		id: 27800,
		trades: [
			{
				resource: "food",
				quantity: 2,
				money: 20
			},
			{
				resource: "food",
				quantity: 6,
				money: 55
			},
			{
				resource: "luxury",
				quantity: 4,
				money: 30
			},
			{
				resource: "luxury",
				quantity: 8,
				money: 55
			},
			{
				resource: "health",
				quantity: 3,
				money: 25
			},
			{
				resource: "health",
				quantity: 5,
				money: 40
			},
			{
				resource: "education",
				quantity: 3,
				money: 15
			},
			{
				resource: "education",
				quantity: 7,
				money: 35
			}
		]
	},
	{
		id: 27801,
		trades: [
			{
				resource: "food",
				quantity: 3,
				money: 30
			},
			{
				resource: "food",
				quantity: 7,
				money: 70
			},
			{
				resource: "luxury",
				quantity: 4,
				money: 30
			},
			{
				resource: "luxury",
				quantity: 6,
				money: 40
			},
			{
				resource: "health",
				quantity: 3,
				money: 20
			},
			{
				resource: "health",
				quantity: 5,
				money: 35
			},
			{
				resource: "education",
				quantity: 2,
				money: 15
			},
			{
				resource: "education",
				quantity: 6,
				money: 35
			}
		]
	},
	{
		id: 27802,
		trades: [
			{
				resource: "food",
				quantity: 4,
				money: 50
			},
			{
				resource: "food",
				quantity: 8,
				money: 95
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 20
			},
			{
				resource: "luxury",
				quantity: 5,
				money: 30
			},
			{
				resource: "health",
				quantity: 3,
				money: 15
			},
			{
				resource: "health",
				quantity: 7,
				money: 35
			},
			{
				resource: "education",
				quantity: 2,
				money: 15
			},
			{
				resource: "education",
				quantity: 6,
				money: 40
			}
		]
	},
	{
		id: 27803,
		trades: [
			{
				resource: "food",
				quantity: 3,
				money: 35
			},
			{
				resource: "food",
				quantity: 7,
				money: 80
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 15
			},
			{
				resource: "luxury",
				quantity: 5,
				money: 25
			},
			{
				resource: "health",
				quantity: 4,
				money: 20
			},
			{
				resource: "health",
				quantity: 8,
				money: 40
			},
			{
				resource: "education",
				quantity: 2,
				money: 15
			},
			{
				resource: "education",
				quantity: 6,
				money: 45
			}
		]
	},
	{
		id: 27804,
		trades: [
			{
				resource: "food",
				quantity: 4,
				money: 45
			},
			{
				resource: "food",
				quantity: 7,
				money: 80
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 20
			},
			{
				resource: "luxury",
				quantity: 5,
				money: 30
			},
			{
				resource: "health",
				quantity: 2,
				money: 15
			},
			{
				resource: "health",
				quantity: 6,
				money: 40
			},
			{
				resource: "education",
				quantity: 3,
				money: 20
			},
			{
				resource: "education",
				quantity: 7,
				money: 50
			}
		]
	},
	{
		id: 27805,
		trades: [
			{
				resource: "food",
				quantity: 3,
				money: 25
			},
			{
				resource: "food",
				quantity: 7,
				money: 55
			},
			{
				resource: "luxury",
				quantity: 4,
				money: 25
			},
			{
				resource: "luxury",
				quantity: 8,
				money: 45
			},
			{
				resource: "health",
				quantity: 2,
				money: 10
			},
			{
				resource: "health",
				quantity: 6,
				money: 35
			},
			{
				resource: "education",
				quantity: 3,
				money: 20
			},
			{
				resource: "education",
				quantity: 5,
				money: 35
			}
		]
	},
	{
		id: 27806,
		trades: [
			{
				resource: "food",
				quantity: 2,
				money: 20
			},
			{
				resource: "food",
				quantity: 6,
				money: 60
			},
			{
				resource: "luxury",
				quantity: 4,
				money: 20
			},
			{
				resource: "luxury",
				quantity: 7,
				money: 30
			},
			{
				resource: "health",
				quantity: 3,
				money: 20
			},
			{
				resource: "health",
				quantity: 7,
				money: 40
			},
			{
				resource: "education",
				quantity: 3,
				money: 25
			},
			{
				resource: "education",
				quantity: 6,
				money: 45
			}
		]
	},
	{
		id: 27807,
		trades: [
			{
				resource: "food",
				quantity: 3,
				money: 25
			},
			{
				resource: "food",
				quantity: 6,
				money: 55
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 20
			},
			{
				resource: "luxury",
				quantity: 7,
				money: 50
			},
			{
				resource: "health",
				quantity: 3,
				money: 20
			},
			{
				resource: "health",
				quantity: 7,
				money: 40
			},
			{
				resource: "education",
				quantity: 3,
				money: 15
			},
			{
				resource: "education",
				quantity: 7,
				money: 55
			}
		]
	},
	{
		id: 27808,
		trades: [
			{
				resource: "food",
				quantity: 3,
				money: 30
			},
			{
				resource: "food",
				quantity: 5,
				money: 50
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 25
			},
			{
				resource: "luxury",
				quantity: 7,
				money: 55
			},
			{
				resource: "health",
				quantity: 3,
				money: 20
			},
			{
				resource: "health",
				quantity: 6,
				money: 50
			},
			{
				resource: "education",
				quantity: 3,
				money: 20
			},
			{
				resource: "education",
				quantity: 7,
				money: 50
			}
		]
	},
	{
		id: 27809,
		trades: [
			{
				resource: "food",
				quantity: 2,
				money: 15
			},
			{
				resource: "food",
				quantity: 6,
				money: 45
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 20
			},
			{
				resource: "luxury",
				quantity: 7,
				money: 50
			},
			{
				resource: "health",
				quantity: 3,
				money: 20
			},
			{
				resource: "health",
				quantity: 5,
				money: 30
			},
			{
				resource: "education",
				quantity: 4,
				money: 25
			},
			{
				resource: "education",
				quantity: 8,
				money: 45
			}
		]
	},
	{
		id: 27810,
		trades: [
			{
				resource: "food",
				quantity: 3,
				money: 35
			},
			{
				resource: "food",
				quantity: 7,
				money: 75
			},
			{
				resource: "luxury",
				quantity: 2,
				money: 10
			},
			{
				resource: "luxury",
				quantity: 6,
				money: 35
			},
			{
				resource: "health",
				quantity: 3,
				money: 20
			},
			{
				resource: "health",
				quantity: 5,
				money: 35
			},
			{
				resource: "education",
				quantity: 4,
				money: 20
			},
			{
				resource: "education",
				quantity: 7,
				money: 40
			}
		]
	},
	{
		id: 27811,
		trades: [
			{
				resource: "food",
				quantity: 4,
				money: 45
			},
			{
				resource: "food",
				quantity: 8,
				money: 85
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 15
			},
			{
				resource: "luxury",
				quantity: 6,
				money: 40
			},
			{
				resource: "health",
				quantity: 3,
				money: 15
			},
			{
				resource: "health",
				quantity: 5,
				money: 25
			},
			{
				resource: "education",
				quantity: 3,
				money: 15
			},
			{
				resource: "education",
				quantity: 7,
				money: 35
			}
		]
	},
	{
		id: 27812,
		trades: [
			{
				resource: "food",
				quantity: 2,
				money: 15
			},
			{
				resource: "food",
				quantity: 6,
				money: 50
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 25
			},
			{
				resource: "luxury",
				quantity: 5,
				money: 40
			},
			{
				resource: "health",
				quantity: 4,
				money: 25
			},
			{
				resource: "health",
				quantity: 8,
				money: 45
			},
			{
				resource: "education",
				quantity: 3,
				money: 15
			},
			{
				resource: "education",
				quantity: 7,
				money: 35
			}
		]
	},
	{
		id: 27813,
		trades: [
			{
				resource: "food",
				quantity: 2,
				money: 15
			},
			{
				resource: "food",
				quantity: 6,
				money: 50
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 15
			},
			{
				resource: "luxury",
				quantity: 7,
				money: 35
			},
			{
				resource: "health",
				quantity: 4,
				money: 20
			},
			{
				resource: "health",
				quantity: 7,
				money: 50
			},
			{
				resource: "education",
				quantity: 3,
				money: 20
			},
			{
				resource: "education",
				quantity: 5,
				money: 35
			}
		]
	},
	{
		id: 27814,
		trades: [
			{
				resource: "food",
				quantity: 2,
				money: 20
			},
			{
				resource: "food",
				quantity: 5,
				money: 50
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 10
			},
			{
				resource: "luxury",
				quantity: 6,
				money: 50
			},
			{
				resource: "health",
				quantity: 3,
				money: 20
			},
			{
				resource: "health",
				quantity: 7,
				money: 55
			},
			{
				resource: "education",
				quantity: 4,
				money: 15
			},
			{
				resource: "education",
				quantity: 8,
				money: 35
			}
		]
	},
	{
		id: 27815,
		trades: [
			{
				resource: "food",
				quantity: 4,
				money: 40
			},
			{
				resource: "food",
				quantity: 7,
				money: 70
			},
			{
				resource: "luxury",
				quantity: 3,
				money: 25
			},
			{
				resource: "luxury",
				quantity: 6,
				money: 50
			},
			{
				resource: "health",
				quantity: 2,
				money: 15
			},
			{
				resource: "health",
				quantity: 7,
				money: 55
			},
			{
				resource: "education",
				quantity: 3,
				money: 10
			},
			{
				resource: "education",
				quantity: 5,
				money: 30
			}
		]
	}
], ue = [
	{
		id: 0,
		copies: 2,
		food: 7,
		luxury: 0,
		cost: 50,
		tariffA: 14,
		tariffB: 7,
		tariffs: [
			14,
			7,
			0
		]
	},
	{
		id: 1,
		copies: 2,
		food: 0,
		luxury: 12,
		cost: 50,
		tariffA: 24,
		tariffB: 12,
		tariffs: [
			24,
			12,
			0
		]
	},
	{
		id: 2,
		copies: 2,
		food: 0,
		luxury: 10,
		cost: 40,
		tariffA: 20,
		tariffB: 10,
		tariffs: [
			20,
			10,
			0
		]
	},
	{
		id: 3,
		copies: 2,
		food: 5,
		luxury: 6,
		cost: 60,
		tariffA: 22,
		tariffB: 11,
		tariffs: [
			22,
			11,
			0
		]
	},
	{
		id: 4,
		copies: 2,
		food: 8,
		luxury: 4,
		cost: 75,
		tariffA: 24,
		tariffB: 12,
		tariffs: [
			24,
			12,
			0
		]
	},
	{
		id: 5,
		copies: 2,
		food: 6,
		luxury: 0,
		cost: 40,
		tariffA: 12,
		tariffB: 6,
		tariffs: [
			12,
			6,
			0
		]
	},
	{
		id: 6,
		copies: 2,
		food: 8,
		luxury: 0,
		cost: 55,
		tariffA: 16,
		tariffB: 8,
		tariffs: [
			16,
			8,
			0
		]
	},
	{
		id: 7,
		copies: 2,
		food: 0,
		luxury: 8,
		cost: 30,
		tariffA: 16,
		tariffB: 8,
		tariffs: [
			16,
			8,
			0
		]
	},
	{
		id: 8,
		copies: 2,
		food: 4,
		luxury: 8,
		cost: 60,
		tariffA: 24,
		tariffB: 12,
		tariffs: [
			24,
			12,
			0
		]
	},
	{
		id: 9,
		copies: 2,
		food: 7,
		luxury: 5,
		cost: 70,
		tariffA: 24,
		tariffB: 12,
		tariffs: [
			24,
			12,
			0
		]
	}
], de = [
	{
		id: 21315,
		role: "capital",
		name: "Corporate Empire",
		timing: "anytime",
		vp: 10
	},
	{
		id: 21316,
		role: "capital",
		name: "Toward a Neoliberal State",
		timing: "after-round-1",
		vp: 4
	},
	{
		id: 21317,
		role: "capital",
		name: "Export Tycoon",
		timing: "action",
		vp: 8
	},
	{
		id: 21318,
		role: "capital",
		name: "Diversified Portfolio",
		timing: "game-end",
		vp: 8
	},
	{
		id: 21319,
		role: "capital",
		name: "Venture Capitalist",
		timing: "game-end",
		vp: 5
	},
	{
		id: 21400,
		role: "state",
		name: "Leviathan",
		timing: "anytime",
		vp: 8
	},
	{
		id: 21401,
		role: "state",
		name: "Expert Budgeter",
		timing: "game-end",
		vp: 4
	},
	{
		id: 21402,
		role: "state",
		name: "According to Plan",
		timing: "scoring",
		vp: 5
	},
	{
		id: 21403,
		role: "state",
		name: "Strong Welfare State",
		timing: "anytime",
		vp: 10
	},
	{
		id: 21404,
		role: "state",
		name: "State-Led Economy",
		timing: "anytime",
		vp: 8
	},
	{
		id: 21505,
		role: "middle",
		name: "Entrepreneur",
		timing: "anytime",
		vp: 8
	},
	{
		id: 21506,
		role: "middle",
		name: "Successful Startup",
		timing: "before-round-4",
		vp: 8
	},
	{
		id: 21507,
		role: "middle",
		name: "Growing Middle Class",
		timing: "anytime",
		vp: 10
	},
	{
		id: 21508,
		role: "middle",
		name: "Golden Compromise",
		timing: "anytime",
		vp: 4
	},
	{
		id: 21509,
		role: "middle",
		name: "We Work, We Thrive",
		timing: "game-end",
		vp: 5
	},
	{
		id: 21610,
		role: "working",
		name: "Rally the Masses",
		timing: "anytime",
		vp: 4
	},
	{
		id: 21611,
		role: "working",
		name: "Workers, Unite!",
		timing: "anytime",
		vp: 8
	},
	{
		id: 21612,
		role: "working",
		name: "Working Class Push",
		timing: "elections",
		vp: 10
	},
	{
		id: 21613,
		role: "working",
		name: "Small Labor Force",
		timing: "game-end",
		vp: 5
	},
	{
		id: 21614,
		role: "working",
		name: "The Surplus Value Is Ours!",
		timing: "production",
		vp: 8
	}
], fe = [
	{
		id: 25400,
		policies: [
			"B",
			"A",
			"C",
			"A",
			"C"
		]
	},
	{
		id: 25401,
		policies: [
			"C",
			"B",
			"A",
			"B",
			"C"
		]
	},
	{
		id: 25402,
		policies: [
			"A",
			"C",
			"B",
			"C",
			"A"
		]
	},
	{
		id: 25403,
		policies: [
			"C",
			"B",
			"B",
			"B",
			"A"
		]
	},
	{
		id: 25404,
		policies: [
			"B",
			"C",
			"A",
			"B",
			"A"
		]
	},
	{
		id: 25405,
		policies: [
			"C",
			"A",
			"A",
			"C",
			"B"
		]
	},
	{
		id: 25406,
		policies: [
			"B",
			"A",
			"C",
			"C",
			"A"
		]
	},
	{
		id: 25407,
		policies: [
			"A",
			"B",
			"C",
			"B",
			"C"
		]
	},
	{
		id: 25408,
		policies: [
			"C",
			"B",
			"B",
			"A",
			"B"
		]
	},
	{
		id: 25409,
		policies: [
			"B",
			"C",
			"B",
			"A",
			"B"
		]
	}
], S = [
	{
		id: 21100,
		name: "Washington Consensus",
		discardBills: "all",
		policies: [
			"C",
			"C",
			"C",
			"C",
			"C",
			"C",
			"B"
		],
		locks: [],
		legitimacy: "working:-3,middle:-2"
	},
	{
		id: 21101,
		name: "Failed IMF Negotiations",
		discardBills: [2, 7],
		policies: [
			"-",
			"C",
			"-",
			"-",
			"-",
			"-",
			"A"
		],
		locks: [],
		legitimacy: "each:-1 per 10 collected from that class"
	},
	{
		id: 21102,
		name: "Moderate IMF Intervention",
		discardBills: "all",
		policies: [
			"C",
			"C",
			"B",
			"B",
			"B",
			"C",
			"B"
		],
		locks: [6],
		legitimacy: "each:-2"
	},
	{
		id: 21103,
		name: "Japanese Model",
		discardBills: "all",
		policies: [
			"C",
			"B",
			"B",
			"B",
			"B",
			"C",
			"A"
		],
		locks: [],
		legitimacy: "each:-1"
	},
	{
		id: 21104,
		name: "Basic IMF Intervention",
		discardBills: "all",
		policies: [
			"C",
			"C",
			"A",
			"B",
			"C",
			"B",
			"B"
		],
		locks: [1, 3],
		legitimacy: "each:half-rounded-up"
	},
	{
		id: 21105,
		name: "US Stimulus Package",
		discardBills: "all",
		policies: [
			"C",
			"C",
			"B",
			"C",
			"C",
			"B",
			"B"
		],
		locks: [],
		legitimacy: "working:half-rounded-up,middle:half-rounded-up"
	},
	{
		id: 21106,
		name: "IMF Intervention with Resistance",
		discardBills: [
			1,
			2,
			3,
			6,
			7
		],
		policies: [
			"C",
			"C",
			"B",
			"-",
			"-",
			"B",
			"A"
		],
		locks: [1],
		legitimacy: "each:-2"
	},
	{
		id: 21107,
		name: "New Government Bond Program",
		discardBills: [],
		policies: [
			"-",
			"-",
			"-",
			"-",
			"-",
			"-",
			"-"
		],
		locks: [],
		legitimacy: "none"
	},
	{
		id: 21108,
		name: "EU Austerity Measures",
		discardBills: "all",
		policies: [
			"C",
			"C",
			"A",
			"B",
			"B",
			"B",
			"B"
		],
		locks: [],
		legitimacy: "each:half-rounded-up"
	},
	{
		id: 21109,
		name: "Failed IMF Intervention: Revolution",
		discardBills: "all",
		policies: [
			"A",
			"C",
			"A",
			"A",
			"A",
			"A",
			"A"
		],
		locks: [],
		legitimacy: "capital:-3,middle:-2"
	}
], pe = {
	rules: "Separate six periods; select one per period. Setup card applies during setup; reveal round card at end of Preparation including round1. Requirements must hold at trigger; at most once per card. State-icon sections require State player; text-only State applies at all counts. Policy shift removes pending bill with 1 influence compensation; no elections removes all pending bills with compensation.",
	cards: [
		{
			slot: 0,
			name: "French Revolution",
			period: 0,
			requirement: null,
			trigger: "setup",
			roles: null
		},
		{
			slot: 1,
			name: "Industrial Revolution",
			period: 0,
			requirement: null,
			trigger: "setup",
			roles: null
		},
		{
			slot: 2,
			name: "Revolutions of 1848",
			period: 0,
			requirement: null,
			trigger: "setup",
			roles: null
		},
		{
			slot: 3,
			name: "Foundation of the International Alliance of Women",
			period: 1,
			requirement: null,
			trigger: "actionEnd",
			roles: null
		},
		{
			slot: 4,
			name: "Moving Assembly Line",
			period: 1,
			trigger: "free",
			roles: ["capital"]
		},
		{
			slot: 5,
			name: "World War I",
			period: 1,
			requirement: null,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 6,
			name: "Introduction of the Ford Model T",
			period: 1,
			trigger: "free",
			roles: "all"
		},
		{
			slot: 7,
			name: "Russian Revolution",
			period: 1,
			trigger: "basic+2influence",
			roles: ["working"]
		},
		{
			slot: 8,
			name: "Rise of Authoritarianism",
			period: 1,
			requirement: null,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 9,
			name: "Panama Canal Opens",
			period: 1,
			requirement: null,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 10,
			name: "Spanish Flu",
			period: 1,
			trigger: "actionEnd",
			roles: null
		},
		{
			slot: 11,
			name: "Russo-Japanese War",
			period: 1,
			requirement: null,
			trigger: "actionEnd",
			roles: null
		},
		{
			slot: 12,
			name: "Rise of Protectionism",
			period: 2,
			requirement: "6B/C。",
			trigger: "free",
			roles: ["capital", "state"]
		},
		{
			slot: 13,
			name: "Bengal Famine",
			period: 2,
			trigger: "actionEnd",
			roles: null
		},
		{
			slot: 14,
			name: "New Deal",
			period: 2,
			trigger: "basic",
			roles: ["working", "middle"]
		},
		{
			slot: 15,
			name: "Great Depression",
			period: 2,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 16,
			name: "Baby Boom",
			period: 2,
			trigger: "free",
			roles: ["working", "middle"]
		},
		{
			slot: 17,
			name: "General Motors Sit-Down Strike",
			period: 2,
			trigger: "free",
			roles: ["working"]
		},
		{
			slot: 18,
			name: "World War II",
			period: 2,
			requirement: null,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 19,
			name: "General Agreement on Tariffs and Trade",
			period: 2,
			trigger: "free",
			roles: ["capital", "state"]
		},
		{
			slot: 20,
			name: "Indian Independence",
			period: 2,
			requirement: null,
			trigger: "free",
			roles: ["working"]
		},
		{
			slot: 21,
			name: "Post-War Economic Miracle",
			period: 3,
			requirement: null,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 22,
			name: "Chinese Communist Revolution",
			period: 3,
			trigger: "basic",
			roles: ["working", "state"]
		},
		{
			slot: 23,
			name: "Civil Rights Movement",
			period: 3,
			trigger: "free",
			roles: ["working", "middle"]
		},
		{
			slot: 24,
			name: "Cuban Embargo",
			period: 3,
			trigger: "free",
			roles: ["working", "state"]
		},
		{
			slot: 25,
			name: "Marshall Plan",
			period: 3,
			trigger: "free",
			roles: ["capital", "state"]
		},
		{
			slot: 26,
			name: "Decolonization",
			period: 3,
			trigger: "free",
			roles: "all"
		},
		{
			slot: 27,
			name: "The Keynesian Era",
			period: 3,
			trigger: "basic",
			roles: "all"
		},
		{
			slot: 28,
			name: "Rise of the European Left",
			period: 3,
			trigger: "free",
			roles: ["working", "middle"]
		},
		{
			slot: 29,
			name: "Consumerism",
			period: 3,
			trigger: "free",
			roles: ["working", "middle"]
		},
		{
			slot: 30,
			name: "Arab Nationalization of Oil",
			period: 4,
			trigger: "free",
			roles: [
				"working",
				"middle",
				"state"
			]
		},
		{
			slot: 31,
			name: "Chinese Economic Reforms",
			period: 4,
			trigger: "actionEnd",
			roles: null
		},
		{
			slot: 32,
			name: "Rise of the Asian Tigers",
			period: 4,
			requirement: "6A/B。",
			trigger: "free",
			roles: [
				"capital",
				"middle",
				"state"
			]
		},
		{
			slot: 33,
			name: "World Wide Web",
			period: 4,
			trigger: "free",
			roles: "all"
		},
		{
			slot: 34,
			name: "End of Dictatorships in Southern Europe",
			period: 4,
			trigger: "free",
			roles: [
				"working",
				"capital",
				"middle"
			]
		},
		{
			slot: 35,
			name: "Fall of the Berlin Wall",
			period: 4,
			requirement: null,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 36,
			name: "Latin American Debt Crisis",
			period: 4,
			trigger: "basic+1influence",
			roles: ["capital", "state"]
		},
		{
			slot: 37,
			name: "Oil Crisis",
			period: 4,
			requirement: null,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 38,
			name: "Indian Drought",
			period: 4,
			requirement: null,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 39,
			name: "Elections in Ex-Soviet Countries",
			period: 5,
			requirement: null,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 40,
			name: "EU Emissions Trading System",
			period: 5,
			trigger: "free",
			roles: ["working", "state"]
		},
		{
			slot: 41,
			name: "US Financial Crisis",
			period: 5,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 42,
			name: "US-China Trade War",
			period: 5,
			requirement: null,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 43,
			name: "European Debt Crisis",
			period: 5,
			trigger: "reveal",
			roles: null
		},
		{
			slot: 44,
			name: "Maastricht Treaty",
			period: 5,
			requirement: null,
			trigger: "free",
			roles: "all"
		},
		{
			slot: 45,
			name: "Dissolution of the Soviet Union",
			period: 5,
			trigger: "basic",
			roles: "all"
		},
		{
			slot: 46,
			name: "Rise of the Middle Class in Asia",
			period: 5,
			trigger: "free",
			roles: ["working", "middle"]
		},
		{
			slot: 47,
			name: "Yellow Vests Movement",
			period: 5,
			trigger: "free",
			roles: [
				"working",
				"capital",
				"middle"
			]
		},
		{
			slot: 48,
			name: "Bismarckian Reforms",
			period: 0,
			requirement: null,
			trigger: "setup",
			roles: null
		},
		{
			slot: 49,
			name: "American Revolution",
			period: 0,
			requirement: null,
			trigger: "setup",
			roles: null
		}
	]
}, C = {
	desiredPolicies: {
		working: "AAAAACB",
		capital: "CCCCCAC",
		middle: "BBBBBBA",
		state: "BCABBBC"
	},
	actionSymbols: {
		B: "build",
		E: "export",
		P: "propose",
		L: "lobby",
		A: "special",
		W: "assign",
		G: "buy",
		S: "strike"
	},
	cards: [
		{
			id: 23600,
			role: "capital",
			number: 3,
			actions: [
				"special",
				"export",
				"build",
				"propose"
			],
			policies: [1, 6],
			bonus: "machine-check",
			special: "machines",
			influence: !0
		},
		{
			id: 23601,
			role: "capital",
			number: 26,
			actions: [
				"build",
				"propose",
				"export",
				"lobby"
			],
			policies: [6, 4],
			bonus: "build2",
			special: "unemployment",
			influence: !1
		},
		{
			id: 23602,
			role: "capital",
			number: 1,
			actions: [
				"build",
				"export",
				"propose",
				"lobby"
			],
			policies: [2, 1],
			bonus: "build2",
			special: "grants",
			influence: !0
		},
		{
			id: 23603,
			role: "capital",
			number: 15,
			actions: [
				"export",
				"build",
				"propose",
				"lobby"
			],
			policies: [7, 3],
			bonus: "foodExport",
			special: "votes",
			influence: !0
		},
		{
			id: 23604,
			role: "capital",
			number: 7,
			actions: [
				"build",
				"export",
				"propose",
				"lobby"
			],
			policies: [2, 5],
			bonus: "industrialSubsidy",
			special: "island",
			influence: !0
		},
		{
			id: 23605,
			role: "capital",
			number: 21,
			actions: [
				"export",
				"build",
				"propose",
				"lobby"
			],
			policies: [5, 3],
			bonus: "luxuryExport",
			special: "votes",
			influence: !0
		},
		{
			id: 23606,
			role: "capital",
			number: 23,
			actions: [
				"special",
				"propose",
				"build",
				"export"
			],
			policies: [4, 7],
			bonus: "offshore-check",
			special: "offshore",
			influence: !1
		},
		{
			id: 23607,
			role: "capital",
			number: 2,
			actions: [
				"build",
				"propose",
				"export",
				"lobby"
			],
			policies: [1, 3],
			bonus: "exitDouble",
			special: "extraShift",
			influence: !0
		},
		{
			id: 23608,
			role: "capital",
			number: 24,
			actions: [
				"propose",
				"export",
				"build",
				"lobby"
			],
			policies: [3, 2],
			bonus: "immediateFree",
			special: "deal",
			influence: !0
		},
		{
			id: 23609,
			role: "capital",
			number: 10,
			actions: [
				"export",
				"propose",
				"build",
				"lobby"
			],
			policies: [6, 1],
			bonus: "foodExport",
			special: "competitiveWages",
			influence: !1
		},
		{
			id: 23610,
			role: "capital",
			number: 18,
			actions: [
				"propose",
				"export",
				"build",
				"lobby"
			],
			policies: [3, 6],
			bonus: "bill2",
			special: "interestGroups",
			influence: !1
		},
		{
			id: 23611,
			role: "capital",
			number: 16,
			actions: [
				"export",
				"propose",
				"build",
				"lobby"
			],
			policies: [4, 2],
			bonus: "luxuryExport",
			special: "grants",
			influence: !0
		},
		{
			id: 23612,
			role: "capital",
			number: 17,
			actions: [
				"propose",
				"build",
				"export",
				"lobby"
			],
			policies: [2, 3],
			bonus: "immediateFree",
			special: "deal",
			influence: !0
		},
		{
			id: 23613,
			role: "capital",
			number: 13,
			actions: [
				"build",
				"export",
				"propose",
				"lobby"
			],
			policies: [3, 5],
			bonus: "buildDiscount",
			special: "fakeNews",
			influence: !0
		},
		{
			id: 23614,
			role: "capital",
			number: 28,
			actions: [
				"special",
				"export",
				"propose",
				"build"
			],
			policies: [6, 7],
			bonus: "offshore-check",
			special: "offshore",
			influence: !1
		},
		{
			id: 23615,
			role: "capital",
			number: 25,
			actions: [
				"special",
				"build",
				"export",
				"propose"
			],
			policies: [7, 1],
			bonus: "luxury-check",
			special: "bidRigging",
			influence: !0
		},
		{
			id: 23616,
			role: "capital",
			number: 19,
			actions: [
				"build",
				"export",
				"propose",
				"lobby"
			],
			policies: [3, 4],
			bonus: "exitDouble",
			special: "health",
			influence: !0
		},
		{
			id: 23617,
			role: "capital",
			number: 11,
			actions: [
				"propose",
				"build",
				"export",
				"lobby"
			],
			policies: [3, 2],
			bonus: "bill2",
			special: "extraShift",
			influence: !0
		},
		{
			id: 23618,
			role: "capital",
			number: 29,
			actions: [
				"propose",
				"build",
				"export",
				"lobby"
			],
			policies: [6, 3],
			bonus: "radical",
			special: "health",
			influence: !1
		},
		{
			id: 23619,
			role: "capital",
			number: 14,
			actions: [
				"special",
				"build",
				"propose",
				"export"
			],
			policies: [5, 2],
			bonus: "machine-check",
			special: "machines",
			influence: !1
		},
		{
			id: 23620,
			role: "capital",
			number: 22,
			actions: [
				"export",
				"propose",
				"build",
				"lobby"
			],
			policies: [3, 5],
			bonus: "exportSubsidy",
			special: "competitiveWages",
			influence: !1
		},
		{
			id: 23621,
			role: "capital",
			number: 30,
			actions: [
				"propose",
				"export",
				"build",
				"lobby"
			],
			policies: [3, 6],
			bonus: "billVotes",
			special: "education",
			influence: !0
		},
		{
			id: 23622,
			role: "capital",
			number: 4,
			actions: [
				"export",
				"propose",
				"build",
				"lobby"
			],
			policies: [3, 4],
			bonus: "dealFirst",
			special: "interestGroups",
			influence: !1
		},
		{
			id: 23623,
			role: "capital",
			number: 9,
			actions: [
				"export",
				"build",
				"propose",
				"lobby"
			],
			policies: [3, 1],
			bonus: "dealFirst",
			special: "unemployment",
			influence: !0
		},
		{
			id: 23624,
			role: "capital",
			number: 12,
			actions: [
				"special",
				"propose",
				"export",
				"build"
			],
			policies: [5, 7],
			bonus: "protectionism-check",
			special: "protectionism",
			influence: !1
		},
		{
			id: 23625,
			role: "capital",
			number: 20,
			actions: [
				"build",
				"propose",
				"export",
				"lobby"
			],
			policies: [4, 3],
			bonus: "industrialSubsidy",
			special: "education",
			influence: !0
		},
		{
			id: 23626,
			role: "capital",
			number: 8,
			actions: [
				"build",
				"propose",
				"export",
				"lobby"
			],
			policies: [2, 7],
			bonus: "buildDiscount",
			special: "foreignRecruitment",
			influence: !1
		},
		{
			id: 23627,
			role: "capital",
			number: 27,
			actions: [
				"export",
				"build",
				"propose",
				"lobby"
			],
			policies: [6, 5],
			bonus: "exportSubsidy",
			special: "foreignRecruitment",
			influence: !0
		},
		{
			id: 23628,
			role: "capital",
			number: 6,
			actions: [
				"propose",
				"export",
				"build",
				"lobby"
			],
			policies: [2, 6],
			bonus: "radical",
			special: "deal",
			influence: !1
		},
		{
			id: 23629,
			role: "capital",
			number: 5,
			actions: [
				"propose",
				"build",
				"export",
				"lobby"
			],
			policies: [2, 4],
			bonus: "billVotes",
			special: "fakeNews",
			influence: !0
		},
		{
			id: 23700,
			role: "working",
			number: 1,
			actions: [
				"assign",
				"buy",
				"propose",
				"strike"
			],
			policies: [1, 2],
			bonus: "signingBonus",
			special: "interestGroups",
			influence: !0
		},
		{
			id: 23701,
			role: "working",
			number: 11,
			actions: [
				"propose",
				"assign",
				"buy",
				"strike"
			],
			policies: [2, 6],
			bonus: "radical",
			special: "populationVotes",
			influence: !1
		},
		{
			id: 23702,
			role: "working",
			number: 13,
			actions: [
				"buy",
				"assign",
				"propose",
				"strike"
			],
			policies: [7, 2],
			bonus: "income",
			special: "accident",
			influence: !0
		},
		{
			id: 23703,
			role: "working",
			number: 30,
			actions: [
				"propose",
				"buy",
				"assign",
				"strike"
			],
			policies: [6, 7],
			bonus: "billVotes",
			special: "highlight",
			influence: !1
		},
		{
			id: 23704,
			role: "working",
			number: 19,
			actions: [
				"assign",
				"buy",
				"propose",
				"strike"
			],
			policies: [4, 6],
			bonus: "deregulation",
			special: "housing",
			influence: !0
		},
		{
			id: 23705,
			role: "working",
			number: 21,
			actions: [
				"buy",
				"assign",
				"propose",
				"strike"
			],
			policies: [5, 1],
			bonus: "healthHalf",
			special: "interestGroups",
			influence: !0
		},
		{
			id: 23706,
			role: "working",
			number: 28,
			actions: [
				"buy",
				"propose",
				"assign",
				"strike"
			],
			policies: [6, 1],
			bonus: "tourism",
			special: "populationVotes",
			influence: !1
		},
		{
			id: 23707,
			role: "working",
			number: 17,
			actions: [
				"propose",
				"assign",
				"buy",
				"strike"
			],
			policies: [2, 6],
			bonus: "immediateFree",
			special: "migration",
			influence: !0
		},
		{
			id: 23708,
			role: "working",
			number: 24,
			actions: [
				"propose",
				"buy",
				"assign",
				"strike"
			],
			policies: [5, 4],
			bonus: "bill2",
			special: "accident",
			influence: !0
		},
		{
			id: 23709,
			role: "working",
			number: 26,
			actions: [
				"assign",
				"propose",
				"buy",
				"strike"
			],
			policies: [5, 7],
			bonus: "signingBonus",
			special: "fakeNews",
			influence: !1
		},
		{
			id: 23710,
			role: "working",
			number: 8,
			actions: [
				"assign",
				"propose",
				"buy",
				"strike"
			],
			policies: [2, 5],
			bonus: "deregulation",
			special: "fakeNews",
			influence: !1
		},
		{
			id: 23711,
			role: "working",
			number: 6,
			actions: [
				"propose",
				"buy",
				"assign",
				"strike"
			],
			policies: [2, 3],
			bonus: "immediateFree",
			special: "housing",
			influence: !0
		},
		{
			id: 23712,
			role: "working",
			number: 5,
			actions: [
				"propose",
				"assign",
				"buy",
				"strike"
			],
			policies: [2, 3],
			bonus: "billVotes",
			special: "accident",
			influence: !0
		},
		{
			id: 23713,
			role: "working",
			number: 4,
			actions: [
				"buy",
				"propose",
				"assign",
				"strike"
			],
			policies: [1, 2],
			bonus: "educationHalf",
			special: "populationVotes",
			influence: !1
		},
		{
			id: 23714,
			role: "working",
			number: 9,
			actions: [
				"buy",
				"assign",
				"propose",
				"strike"
			],
			policies: [2, 4],
			bonus: "publicEducationOvertime",
			special: "highlight",
			influence: !0
		},
		{
			id: 23715,
			role: "working",
			number: 29,
			actions: [
				"propose",
				"assign",
				"buy",
				"strike"
			],
			policies: [6, 2],
			bonus: "bill2",
			special: "housing",
			influence: !0
		},
		{
			id: 23716,
			role: "working",
			number: 18,
			actions: [
				"propose",
				"buy",
				"assign",
				"strike"
			],
			policies: [4, 5],
			bonus: "radical",
			special: "accident",
			influence: !0
		},
		{
			id: 23717,
			role: "working",
			number: 27,
			actions: [
				"buy",
				"propose",
				"assign",
				"strike"
			],
			policies: [4, 3],
			bonus: "educationHalf",
			special: "interestGroups",
			influence: !0
		},
		{
			id: 23718,
			role: "working",
			number: 15,
			actions: [
				"buy",
				"assign",
				"propose",
				"strike"
			],
			policies: [4, 1],
			bonus: "tourism",
			special: "fakeNews",
			influence: !1
		},
		{
			id: 23719,
			role: "working",
			number: 20,
			actions: [
				"assign",
				"propose",
				"buy",
				"strike"
			],
			policies: [4, 7],
			bonus: "specialization",
			special: "populationVotes",
			influence: !1
		},
		{
			id: 23720,
			role: "working",
			number: 2,
			actions: [
				"assign",
				"propose",
				"buy",
				"strike"
			],
			policies: [3, 1],
			bonus: "farm",
			special: "highlight",
			influence: !1
		},
		{
			id: 23721,
			role: "working",
			number: 16,
			actions: [
				"buy",
				"propose",
				"assign",
				"strike"
			],
			policies: [4, 2],
			bonus: "publicHealthOvertime",
			special: "highlight",
			influence: !0
		},
		{
			id: 23722,
			role: "working",
			number: 14,
			actions: [
				"assign",
				"propose",
				"buy",
				"strike"
			],
			policies: [2, 7],
			bonus: "farm",
			special: "housing",
			influence: !1
		},
		{
			id: 23723,
			role: "working",
			number: 7,
			actions: [
				"assign",
				"buy",
				"propose",
				"strike"
			],
			policies: [2, 4],
			bonus: "specialization",
			special: "interestGroups",
			influence: !0
		},
		{
			id: 23724,
			role: "working",
			number: 3,
			actions: [
				"buy",
				"assign",
				"propose",
				"strike"
			],
			policies: [1, 7],
			bonus: "unemploymentBenefits",
			special: "fakeNews",
			influence: !0
		},
		{
			id: 23725,
			role: "working",
			number: 25,
			actions: [
				"buy",
				"assign",
				"propose",
				"strike"
			],
			policies: [5, 6],
			bonus: "unemploymentBenefits",
			special: "migration",
			influence: !1
		},
		{
			id: 23726,
			role: "working",
			number: 23,
			actions: [
				"propose",
				"assign",
				"buy",
				"strike"
			],
			policies: [5, 3],
			bonus: "billVotes",
			special: "highlight",
			influence: !0
		},
		{
			id: 23727,
			role: "working",
			number: 12,
			actions: [
				"propose",
				"buy",
				"assign",
				"strike"
			],
			policies: [6, 3],
			bonus: "billVotes",
			special: "migration",
			influence: !0
		},
		{
			id: 23728,
			role: "working",
			number: 10,
			actions: [
				"buy",
				"propose",
				"assign",
				"strike"
			],
			policies: [2, 5],
			bonus: "healthHalf",
			special: "migration",
			influence: !0
		},
		{
			id: 23729,
			role: "working",
			number: 22,
			actions: [
				"buy",
				"propose",
				"assign",
				"strike"
			],
			policies: [5, 2],
			bonus: "income",
			special: "migration",
			influence: !1
		},
		{
			id: 23800,
			role: "middle",
			number: 27,
			actions: [
				"propose",
				"buy",
				"build",
				"export"
			],
			policies: [7, 3],
			bonus: "billVotes",
			special: "extraShift",
			influence: !0
		},
		{
			id: 23801,
			role: "middle",
			number: 2,
			actions: [
				"buy",
				"build",
				"export",
				"assign"
			],
			policies: [],
			bonus: "educationHalf",
			special: "interestGroups",
			influence: !1
		},
		{
			id: 23802,
			role: "middle",
			number: 1,
			actions: [
				"buy",
				"build",
				"export",
				"propose"
			],
			policies: [1, 6],
			bonus: "healthHalf",
			special: "extraShift",
			influence: !0
		},
		{
			id: 23803,
			role: "middle",
			number: 4,
			actions: [
				"buy",
				"build",
				"propose",
				"export"
			],
			policies: [7, 5],
			bonus: "publicEducationOvertime",
			special: "education",
			influence: !1
		},
		{
			id: 23804,
			role: "middle",
			number: 5,
			actions: [
				"buy",
				"propose",
				"assign",
				"export"
			],
			policies: [],
			bonus: "publicHealthOvertime",
			special: "health",
			influence: !0
		},
		{
			id: 23805,
			role: "middle",
			number: 8,
			actions: [
				"buy",
				"propose",
				"build",
				"assign"
			],
			policies: [3, 5],
			bonus: "personalConsumption",
			special: "themePark",
			influence: !1
		},
		{
			id: 23806,
			role: "middle",
			number: 19,
			actions: [
				"assign",
				"build",
				"buy",
				"propose"
			],
			policies: [2, 4],
			bonus: "specialization",
			special: "workVotes",
			influence: !1
		},
		{
			id: 23807,
			role: "middle",
			number: 15,
			actions: [
				"build",
				"propose",
				"buy",
				"export"
			],
			policies: [1, 5],
			bonus: "storageBuild",
			special: "education",
			influence: !0
		},
		{
			id: 23808,
			role: "middle",
			number: 9,
			actions: [
				"buy",
				"propose",
				"build",
				"export"
			],
			policies: [7, 4],
			bonus: "income",
			special: "workVotes",
			influence: !0
		},
		{
			id: 23809,
			role: "middle",
			number: 6,
			actions: [
				"buy",
				"assign",
				"build",
				"propose"
			],
			policies: [2, 6],
			bonus: "importSubsidy",
			special: "highlight",
			influence: !1
		},
		{
			id: 23810,
			role: "middle",
			number: 23,
			actions: [
				"export",
				"build",
				"buy",
				"propose"
			],
			policies: [5, 2],
			bonus: "exportSubsidy",
			special: "fakeNews",
			influence: !0
		},
		{
			id: 23811,
			role: "middle",
			number: 24,
			actions: [
				"propose",
				"build",
				"buy",
				"assign"
			],
			policies: [3, 7],
			bonus: "immediateFree",
			special: "employmentSubsidy",
			influence: !1
		},
		{
			id: 23812,
			role: "middle",
			number: 30,
			actions: [
				"special",
				"buy",
				"assign",
				"export"
			],
			policies: [],
			bonus: "migration-check",
			special: "migration",
			influence: !1
		},
		{
			id: 23813,
			role: "middle",
			number: 14,
			actions: [
				"build",
				"export",
				"buy",
				"assign"
			],
			policies: [],
			bonus: "landOpportunity",
			special: "health",
			influence: !0
		},
		{
			id: 23814,
			role: "middle",
			number: 13,
			actions: [
				"build",
				"assign",
				"buy",
				"export"
			],
			policies: [],
			bonus: "stateBuild",
			special: "fakeNews",
			influence: !0
		},
		{
			id: 23815,
			role: "middle",
			number: 25,
			actions: [
				"propose",
				"build",
				"buy",
				"export"
			],
			policies: [6, 3],
			bonus: "billVotes",
			special: "workVotes",
			influence: !0
		},
		{
			id: 23816,
			role: "middle",
			number: 20,
			actions: [
				"export",
				"buy",
				"build",
				"assign"
			],
			policies: [],
			bonus: "exportBonus",
			special: "unemployment",
			influence: !1
		},
		{
			id: 23817,
			role: "middle",
			number: 3,
			actions: [
				"buy",
				"build",
				"propose",
				"assign"
			],
			policies: [4, 3],
			bonus: "personalConsumption",
			special: "fakeNews",
			influence: !1
		},
		{
			id: 23818,
			role: "middle",
			number: 17,
			actions: [
				"assign",
				"buy",
				"build",
				"propose"
			],
			policies: [3, 1],
			bonus: "specialization",
			special: "employmentSubsidy",
			influence: !1
		},
		{
			id: 23819,
			role: "middle",
			number: 10,
			actions: [
				"build",
				"assign",
				"buy",
				"export"
			],
			policies: [6, 4],
			bonus: "stateBuild",
			special: "unemployment",
			influence: !0
		},
		{
			id: 23820,
			role: "middle",
			number: 28,
			actions: [
				"special",
				"buy",
				"propose",
				"assign"
			],
			policies: [6, 1],
			bonus: "migration-check",
			special: "migration",
			influence: !1
		},
		{
			id: 23821,
			role: "middle",
			number: 22,
			actions: [
				"export",
				"build",
				"buy",
				"assign"
			],
			policies: [],
			bonus: "exportBonus",
			special: "interestGroups",
			influence: !1
		},
		{
			id: 23822,
			role: "middle",
			number: 16,
			actions: [
				"assign",
				"buy",
				"build",
				"export"
			],
			policies: [],
			bonus: "deregulation",
			special: "highlight",
			influence: !1
		},
		{
			id: 23823,
			role: "middle",
			number: 29,
			actions: [
				"special",
				"export",
				"build",
				"propose"
			],
			policies: [4, 7],
			bonus: "migration-check",
			special: "migration",
			influence: !0
		},
		{
			id: 23824,
			role: "middle",
			number: 18,
			actions: [
				"assign",
				"build",
				"buy",
				"export"
			],
			policies: [],
			bonus: "deregulation",
			special: "themePark",
			influence: !1
		},
		{
			id: 23825,
			role: "middle",
			number: 11,
			actions: [
				"build",
				"buy",
				"export",
				"propose"
			],
			policies: [7, 2],
			bonus: "storageBuild",
			special: "extraShift",
			influence: !0
		},
		{
			id: 23826,
			role: "middle",
			number: 21,
			actions: [
				"export",
				"buy",
				"build",
				"propose"
			],
			policies: [7, 1],
			bonus: "exportSubsidy",
			special: "extraShift",
			influence: !0
		},
		{
			id: 23827,
			role: "middle",
			number: 12,
			actions: [
				"build",
				"buy",
				"assign",
				"propose"
			],
			policies: [5, 3],
			bonus: "landOpportunity",
			special: "interestGroups",
			influence: !0
		},
		{
			id: 23828,
			role: "middle",
			number: 26,
			actions: [
				"propose",
				"buy",
				"export",
				"assign"
			],
			policies: [3, 6],
			bonus: "immediateFree",
			special: "unemployment",
			influence: !1
		},
		{
			id: 23829,
			role: "middle",
			number: 7,
			actions: [
				"buy",
				"export",
				"build",
				"assign"
			],
			policies: [],
			bonus: "income",
			special: "employmentSubsidy",
			influence: !0
		}
	],
	instructions: [
		{
			id: 23900,
			role: "capital"
		},
		{
			id: 23901,
			role: "capital"
		},
		{
			id: 23902,
			role: "capital"
		},
		{
			id: 23903,
			role: "capital"
		},
		{
			id: 23904,
			role: "capital"
		},
		{
			id: 23905,
			role: "capital"
		},
		{
			id: 23906,
			role: "capital"
		},
		{
			id: 23907,
			role: "capital"
		},
		{
			id: 23908,
			role: "capital"
		},
		{
			id: 23909,
			role: "capital"
		},
		{
			id: 23910,
			role: "capital"
		},
		{
			id: 24e3,
			role: "working"
		},
		{
			id: 24001,
			role: "working"
		},
		{
			id: 24002,
			role: "working"
		},
		{
			id: 24003,
			role: "working"
		},
		{
			id: 24004,
			role: "working"
		},
		{
			id: 24005,
			role: "working"
		},
		{
			id: 24006,
			role: "working"
		},
		{
			id: 24007,
			role: "working"
		},
		{
			id: 24008,
			role: "working"
		},
		{
			id: 24009,
			role: "working"
		},
		{
			id: 24100,
			role: "middle"
		},
		{
			id: 24101,
			role: "middle"
		},
		{
			id: 24102,
			role: "middle"
		},
		{
			id: 24103,
			role: "middle"
		},
		{
			id: 24104,
			role: "middle"
		},
		{
			id: 24105,
			role: "middle"
		},
		{
			id: 24106,
			role: "middle"
		},
		{
			id: 24107,
			role: "middle"
		},
		{
			id: 24108,
			role: "middle"
		},
		{
			id: 24109,
			role: "middle"
		},
		{
			id: 24110,
			role: "middle"
		},
		{
			id: 24111,
			role: "middle"
		},
		{
			id: 24112,
			role: "middle"
		},
		{
			id: 24200,
			role: "general"
		},
		{
			id: 24302,
			role: "general"
		},
		{
			id: 24401,
			role: "general"
		},
		{
			id: 24500,
			role: "general"
		}
	],
	instructionNotes: {
		policyCheck: "If listed policy available and bill marker available: PB + distance(1/2); WC labor +1, C tax +1; move policy priority same amount. If neither can be proposed SA+1.",
		workingWorkers: "Swap skilled out of unskilled slots first. If >=2 can be assigned AW+1 each; AW+2 per formable union; if none SA+1; if unemployed exceeds available slots DEM+difference.",
		workingGoods: "Per prosperity resource affordable in population quantity from <=2 sources: free BGS+3, average<=6 BGS+2, else BGS+1. If none SA+1.",
		workingStrike: "2B with >=2 unions STR+1 per3 eligible companies; 2C STR+1 per2 eligible, policy2+1. Only minimum-wage companies count. Exclude free public services.",
		workingAssignOrder: [
			"form union",
			"most unemployed assigned",
			"qualify for union",
			"highest wage",
			"public",
			"capital",
			"health/education: unavailable public then cheaper",
			"food",
			"media",
			"luxury",
			"random"
		],
		workingGoodsOrder: [
			"free",
			"education if >=3 unemployed unskilled",
			"cheapest; omit health causing population growth if alternatives",
			"health",
			"education",
			"luxury",
			"state",
			"foreign",
			"capital",
			"middle"
		],
		workingStrikeOrder: [
			"machine",
			"only operational company in industry for owner",
			"largest wage difference",
			"media",
			"health",
			"education",
			"luxury",
			"food",
			"highest production",
			"random"
		],
		workingSkillOrder: [
			"form union; if tied fewest slots then random",
			"qualify for union",
			"most company slots",
			"most slots in markets",
			"health/education: unavailable public then more expensive",
			"food",
			"media",
			"luxury"
		],
		capitalCompanies: "Each affordable market company: if automated or unemployed can fill, BC+1 per2 remaining productions; if also new resource BC+1. Demonstration BC+3. If previous total <=1 SA+1. Each nonoperational company worth>=20: SC+1 per10 sale money.",
		capitalBuildOrder: [
			"workers can fill",
			"automated",
			"fewest own operational of industry",
			"does not qualify union",
			"food",
			"luxury",
			"media",
			"health/education: unavailable public then more expensive",
			"highest production",
			"random"
		],
		capitalBuildRestrictions: "Never build nonoperational company if own nonoperational of same industry exists. When both classes available prefer middle, except demonstration prefer working.",
		capitalSellOrder: [
			"highest cost",
			"would qualify union if operational with working workers",
			"fewest matching unemployed",
			"random"
		],
		capitalSellRestriction: "Never sell operational company.",
		capitalMachineOrder: [
			"no other own company of industry has machine",
			"food",
			"luxury",
			"health/education: unavailable public then more expensive",
			"highest production",
			"random"
		],
		capitalAssignOrder: [
			"no own operational of industry",
			"does not qualify union",
			"media",
			"health/education: unavailable public then more expensive",
			"food",
			"luxury",
			"random"
		],
		capitalInfluence: "If pending bill: compare opponents present+expected production influence versus own present+expected. LOB+difference if opponents higher; otherwise SA+1. No bill SA+1.",
		exportCheck: "If >=2 transactions SFM+1 per transaction; MCA also +1 if cash<=15. Otherwise SA+1.",
		middleCompanies: "Each affordable buildable: BC+1 per2 remaining productions; if helper slot and available WC BC+2; if new resource BC+2. If prosperity>=fully operational own companies BC+2. If previous total<=1 SA+1.",
		middleBuildOrder: [
			"WC helper available",
			"only middle slots",
			"fewest own operational of industry",
			"health/education: unavailable public then more expensive",
			"food",
			"luxury",
			"media",
			"highest production",
			"random"
		],
		middleBuildRestriction: "Never build third company of same industry.",
		middleAssignOrder: [
			"most unemployed assigned",
			"highest wage",
			"public",
			"capital",
			"health/education: unavailable public then cheaper",
			"food",
			"media",
			"luxury",
			"random"
		],
		middleAssignWCOrder: [
			"production less than storage",
			"no own company of industry",
			"does not qualify union",
			"food",
			"health/education: unavailable public then more expensive",
			"luxury",
			"media",
			"random"
		],
		middleGoodsOrder: [
			"free",
			"education if >=3 unemployed unskilled",
			"cheapest; omit health causing population growth if alternatives",
			"education",
			"health",
			"luxury",
			"state",
			"foreign",
			"capital"
		],
		middleSkillOrder: [
			"market needs excluding industry already2; enough other workers; absent industry; food/education/health/luxury/media",
			"nonoperational capital/public needs",
			"capital market needs",
			"random"
		],
		middleExtraShiftOrder: [
			"storage space",
			"2 middle workers",
			"uncommitted WC worker",
			"food",
			"health/education: unavailable public then more expensive",
			"luxury"
		],
		middleExtraShiftRestriction: "Exclude media companies.",
		middleWorkers: "Swap skilled first; >=2 assignable AW+1 per worker else SA+1.",
		criteria: "Narrow candidate set sequentially; ignore later criterion whose matching options do not intersect remaining candidates. Random only last tie.",
		voteWinning: "If opposite none: spend0. If opposite exactly needed: Draw1. If more: Draw(difference+1), difference=opposite total-needed.",
		voteLosingSolo: "If opposite none: necessary. If opposite influence and own side exactly needed: Draw1 to spendAll. If own side more than needed: necessary then Draw(opposite total).",
		voteLosingAllies: "If opposite none: necessary. If opposite influence and own side exactly needed: spend0. If own side more than needed: necessary-1 then Draw1.",
		initialRows: {
			working: {
				actions: [[
					"special",
					"strike",
					"demonstration"
				], [
					"assign",
					"buy",
					"propose"
				]],
				policies: [[
					2,
					4,
					6
				], [1, 5]],
				setAside: [3, 7]
			},
			capital: {
				actions: [[
					"special",
					"lobby",
					"sell"
				], [
					"build",
					"export",
					"propose"
				]],
				policies: [[
					2,
					4,
					6,
					7
				], [3]],
				setAside: [1, 5]
			},
			middle: {
				actions: [[
					"special",
					"export",
					"propose"
				], [
					"buy",
					"build",
					"assign"
				]],
				policies: [[
					1,
					3,
					5,
					7
				]],
				setAside: [
					2,
					4,
					6
				]
			}
		}
	}
}, w = [
	"working",
	"middle",
	"capital",
	"state"
], T = [
	"food",
	"luxury",
	"health",
	"education",
	"influence"
], me = () => ({
	food: 0,
	luxury: 0,
	health: 0,
	education: 0,
	influence: 0
}), E = {
	food: g("games.hegemony.messages.m063"),
	luxury: g("games.hegemony.messages.m064"),
	health: g("games.hegemony.messages.m065"),
	education: g("games.hegemony.messages.m066"),
	influence: g("games.hegemony.messages.m067")
}, D = {
	working: g("games.hegemony.messages.m068"),
	middle: g("games.hegemony.messages.m069"),
	capital: g("games.hegemony.messages.m070"),
	state: g("games.hegemony.messages.m071")
}, he = [
	g("games.hegemony.messages.m072"),
	g("games.hegemony.messages.m073"),
	g("games.hegemony.messages.m074"),
	g("games.hegemony.messages.m075"),
	g("games.hegemony.messages.m076"),
	g("games.hegemony.messages.m077"),
	g("games.hegemony.messages.m078")
], O = (e) => y.find((t) => t.id === e.definition), k = (e, t) => e.companies.find((e) => e.uid === t), A = (e, t) => e.workers.filter((e) => e.company === t.uid), j = (e, t) => e.companies.filter((e) => e.active && e.owner === t), M = (e) => e === "working" || e === "middle", N = (e) => 3 - "ABC".indexOf(e.policies[1]), P = (e, t) => {
	let n = e.workers.filter((e) => e.role === t).length;
	return [
		10,
		12,
		15,
		18,
		21,
		24,
		27,
		30
	].reduce((e, t, r) => n >= t ? r + 3 : e, 3);
}, F = (e, t) => e.classes[t].money + e.classes[t].capital, ge = (e) => {
	let t = "ABC".indexOf(e.policies[2]);
	return 3 - t + (2 - t) * (4 - "ABC".indexOf(e.policies[3]) - "ABC".indexOf(e.policies[4]));
};
function _e(t, n) {
	if (n <= 1) return 0;
	let r = e(t.seed, t.cursor, n);
	return t.cursor += 1, r;
}
function I(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; --t) {
		let r = _e(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function ve(e, t, n) {
	e.log.push({
		id: e.nextId++,
		text: t,
		...n ? { role: n } : {}
	}), e.log.length > 100 && e.log.shift();
}
function L(e, t, n, r) {
	e.classes[t].vp += n, r && (e.scoreBreakdown.push({
		role: t,
		text: r,
		vp: n
	}), ve(e, g("games.hegemony.messages.m079", {
		p1: r,
		p2: n
	}), t));
}
function R(e, t, n, r, i = !1, a = !1) {
	let o = e.classes[t];
	if (F(e, t) < n && !i) return !1;
	for (; F(e, t) < n;) o.loans += 1, o.everLoan = !0, t === "capital" ? o.capital += 50 : o.money += 50, ve(e, g("games.hegemony.messages.m080"), t);
	let s = a ? "capital" : "money", c = a ? "money" : "capital", l = Math.min(o[s], n);
	return o[s] -= l, o[c] -= n - l, r && (e.classes[r].money += n), !0;
}
function ye(e, t, n = 50) {
	let r = e.classes[t];
	return !r.loans || !R(e, t, n, void 0, !1, t === "capital") ? !1 : (--r.loans, !0);
}
function z(e, t, n, r = !1) {
	if (!e.roles.includes("state") || t === "state") return;
	let i = e.classes[t], a = 18 - w.reduce((t, n) => t + e.classes[n].tokens, 0);
	r && (n = Math.min(n, a), i.tokens += n), i.legitimacy = Math.max(1, Math.min(10, i.legitimacy + n));
}
function be(e, t, n = 1) {
	let r = e.classes[t];
	for (let i = 0; i < n; i += 1) r.prosperity = Math.min(10, r.prosperity + 1), L(e, t, t === "middle" ? [
		0,
		1,
		2,
		3,
		4,
		5,
		5,
		6,
		6,
		7,
		7
	][r.prosperity] : r.prosperity);
}
function B(e, t) {
	return Math.max(0, (t === "influence" ? 35 : t === "food" ? 62 : 64) - w.reduce((n, r) => {
		let i = e.classes[r];
		return n + i.storage[t] + i.personal[t] + i.benefits[t] + (t === "food" || t === "luxury" ? i.freeTrade[t] : 0);
	}, 0));
}
function xe(e, t, n) {
	if (t === "state") return 6 + j(e, t).filter((e) => O(e).resource === n).reduce((e, t) => e + O(t).production, 0);
	if (n === "influence" || t === "working") return 2 ** 53 - 1;
	let r = t === "capital" && n !== "food" ? 12 : 8;
	return r + (e.classes[t].expanded.includes(n) ? r : 0);
}
function V(e, t, n, r, i = "personal") {
	let a = e.classes[t];
	n === "influence" && t !== "state" && (i = i === "benefits" ? i : "personal");
	let o = i === "storage" ? xe(e, t, n) : 2 ** 53 - 1, s = Math.min(r, B(e, n), Math.max(0, o - a[i][n]));
	return a[i][n] += s, s;
}
function Se(e, t, n, r) {
	let i = r - V(e, t, n, r, t === "working" ? "personal" : "storage"), a = e.classes[t];
	if (t === "capital" && (n === "food" || n === "luxury")) {
		let t = Math.min(i, (n === "food" ? 8 : 12) - a.freeTrade[n], B(e, n));
		a.freeTrade[n] += t, i -= t;
	}
	i > 0 && a.automa !== "off" && (t === "capital" || t === "middle") && n !== "influence" && !a.expanded.includes(n) && w.reduce((t, n) => t + e.classes[n].expanded.length, 0) < 6 && R(e, t, 20) && (a.expanded.push(n), V(e, t, n, i, "storage"));
}
function H(e, t, n) {
	if (t === "state") return 0;
	let r = Math.min(n, 25 - e.bag.filter((e) => e === t).length - (e.election?.cubes.filter((e) => e === t).length ?? 0) - e.classes[t].benefits.votes);
	for (let n = 0; n < r; n += 1) e.bag.push(t);
	return r;
}
function Ce(e, t, n) {
	return Math.max(0, (n === "any" ? t === "working" ? 23 : 12 : t === "working" ? 5 : 6) - e.workers.filter((e) => e.role === t && e.skill === n).length);
}
function U(e, t, n) {
	let r = n;
	if (!Ce(e, t, r)) {
		if (r !== "any" && Ce(e, t, "any")) r = "any";
		else {
			let n = T.filter((n) => Ce(e, t, n));
			if (!n.length) return null;
			r = n[_e(e, n.length)];
		}
	}
	let i = {
		id: e.nextId++,
		role: t,
		skill: r,
		company: null,
		slot: -1,
		committed: !1,
		union: null
	};
	return e.workers.push(i), i;
}
function we(e, t, n) {
	for (let r = 0; r < n; r += 1) {
		let n = e.immigrationDeck.shift();
		U(e, t, ce.find((e) => e.id === n)[t]), e.immigrationDeck.push(n);
	}
}
function W(e) {
	let t = O(e), n = t.workers.map((n) => ({
		role: e.owner === "middle" ? "middle" : e.owner === "working" ? "working" : "either",
		skill: n === "skill" ? t.resource : "any",
		optional: !1
	}));
	return t.helper && n.push({
		role: "working",
		skill: t.helper.skill === "skill" ? t.resource : "any",
		optional: !0
	}), n;
}
function G(e, t) {
	if (!t.active) return !1;
	let n = W(t).filter((e) => !e.optional).length;
	return n === 0 || A(e, t).filter((e) => e.slot < n).length === n;
}
function Te(e, t) {
	if (t.committed || t.union) return !1;
	if (t.role === "middle" && t.company !== null) {
		let n = k(e, t.company);
		if (n.owner === "middle" && A(e, n).some((e) => e.role === "working" && e.committed)) return !1;
	}
	return !0;
}
function Ee(e, t, n, r) {
	let i = W(n)[r];
	if (!i || !n.active || i.role !== "either" && i.role !== t.role || i.skill !== "any" && i.skill !== t.skill) return !1;
	let a = A(e, n).filter((e) => e.id !== t.id);
	return a.some((e) => e.slot === r) || i.role === "either" && a.some((e) => e.role !== t.role) ? !1 : !i.optional || G(e, n);
}
function De(e) {
	for (let t of e.companies) G(e, t) || (A(e, t).forEach((e) => {
		e.company = null, e.slot = -1, e.committed = !1;
	}), t.strike = !1);
	for (let t of T) e.workers.filter((n) => n.role === "working" && n.company !== null && O(k(e, n.company)).resource === t).length < 4 && e.workers.filter((e) => e.union === t).forEach((e) => {
		e.union = null, e.committed = !1;
	});
}
function Oe(e, t) {
	if (!G(e, t)) return 0;
	let n = O(t);
	return !n.wages.length || t.owner === "middle" && !A(e, t).some((e) => e.role === "working") ? 0 : n.wages[t.wage - 1];
}
function ke(e, t, n = !0, r = !1) {
	if (!G(e, t)) return !1;
	let i = O(t), a = A(e, t), o = a.find((e) => e.role === "working" && t.owner === "middle"), s = !!o && (t.strike || r && o.committed);
	if (t.strike && t.wage !== 3 && t.owner !== "middle" || r && t.owner === "middle" && a.filter((e) => e.role === "middle").some((e) => e.committed)) return !1;
	let c = t.owner === "state" ? [...new Set(a.map((e) => e.role))].reduce((t, n) => t + (e.roundEffects[`publicWageBonus:${n}`] ? 5 : 0), 0) : 0, l = (s ? 0 : Oe(e, t)) + c;
	if (l && !R(e, t.owner, l, o?.role ?? a[0].role, n)) return !1;
	c && L(e, "state", 1);
	let u = Number(e.roundEffects[`${i.resource === "influence" ? "media" : i.resource}Production`] ?? 0) + (t.machinery && t.owner === "capital" ? Number(e.roundEffects.machineryBonus ?? 0) : 0) + (t.machinery && i.resource === "luxury" ? Number(e.roundEffects.machineryLuxuryBonus ?? 0) : 0) + (e.roundEffects[`luxuryBonus:${t.owner}`] && i.resource === "luxury" ? 1 : 0);
	return Se(e, t.owner, i.resource, Math.max(0, i.production + (t.machinery ? i.machineryBonus : 0) + (o && !s ? i.helper.bonus : 0) + u)), e.effect.amount = i.production + (t.machinery ? i.machineryBonus : 0) + (o && !s ? i.helper.bonus : 0), e.roundEffects.lastProductionResource = T.indexOf(i.resource), r && a.forEach((e) => {
		e.committed = !0;
	}), ve(e, g("games.hegemony.messages.m081", {
		p1: _(i.name),
		p2: E[i.resource]
	}), t.owner), !0;
}
function K(e, t, n) {
	return t === "foreign" ? {
		price: n === "food" ? e.roundEffects.oilCrisis ? 15 : 10 : e.roundEffects.oilCrisis ? 9 : 6,
		tariff: n === "food" ? [
			10,
			5,
			0
		]["ABC".indexOf(e.policies[5])] : [
			6,
			3,
			0
		]["ABC".indexOf(e.policies[5])]
	} : t === "state" ? {
		price: n === "health" ? [
			0,
			5,
			10
		]["ABC".indexOf(e.policies[3])] : n === "education" ? [
			0,
			5,
			10
		]["ABC".indexOf(e.policies[4])] : n === "food" ? 10 : n === "luxury" ? 6 : 10,
		tariff: 0
	} : {
		price: e.classes[t].prices[n],
		tariff: 0
	};
}
function Ae(e, t, n, r, i, a = {}) {
	let o = n === "foreign" ? null : e.classes[n];
	if (!Number.isInteger(i) || i <= 0 || n === "foreign" && B(e, r) < i || n === "foreign" && r !== "food" && r !== "luxury" || r === "influence" && n !== "state" || o && o.storage[r] < i || !a.overflow && a.area === "storage" && e.classes[t].storage[r] + (t === n ? 0 : i) > xe(e, t, r)) return !1;
	let s = K(e, n, r), c = s.price * i, l = a.discount ?? 1, u = t === n ? 0 : Math.ceil(c * l), d = n !== "foreign" || t === "state" || a.noTariff ? 0 : s.tariff * i;
	return !a.forced && F(e, t) < u + d ? !1 : (R(e, t, u, n === "foreign" || t === n ? void 0 : n, a.forced), a.subsidy && n !== "foreign" && R(e, "state", c - u, n, !0), d && R(e, t, d, "state", a.forced), o && (o.storage[r] -= i), a.overflow ? e.classes[t].storage[r] += i : V(e, t, r, i, a.area ?? "personal"), n === "state" && e.roles.includes("state") && (r === "health" || r === "education") && (s.price === 5 && L(e, "state", 1), s.price === 0 && z(e, t, Math.floor(i / 3))), !0);
}
function je(e, t = !1) {
	e.companies.forEach((n) => {
		n.wage = t || n.owner === "state" && !e.roles.includes("state") ? N(e) : Math.max(n.wage, N(e));
	});
}
function Me(e, t, n, r = !1) {
	r && (e.bills.filter((e) => e.policy === t).forEach((t) => V(e, t.role, "influence", 1)), e.bills = e.bills.filter((e) => e.policy !== t)), e.policies[t] = n, t === 1 && je(e), ve(e, g("games.hegemony.messages.m082", {
		p1: he[t],
		p2: n
	}));
}
//#endregion
//#region src/games/hegemony/cards.ts
function Ne(e) {
	return _(e >= 9e4 ? e % 10 == 0 ? "Controlling the Narrative" : "Rapid Resolution" : b.find((t) => t.id === e).name);
}
function Pe(e, t) {
	return t === "pressure" ? [{
		kind: "gainVotes",
		actor: e,
		n: 3
	}] : t === "lobby" ? [{
		kind: "payMoney",
		actor: e,
		n: 30,
		flag: "capital"
	}, {
		kind: "gainResource",
		actor: e,
		resource: "influence",
		n: 3
	}] : t === "campaign" ? [{
		kind: "convertMedia",
		actor: e,
		n: 3
	}] : t === "extraTax" ? [{
		kind: "extraTax",
		actor: e
	}, {
		kind: "extraTaxLoss",
		actor: e,
		n: 2
	}] : t === "demonstration" ? [{
		kind: "demonstration",
		actor: e
	}] : [{
		kind: t,
		actor: e
	}];
}
function Fe(e, t, n) {
	if (n >= 9e4) return n % 10 == 0 ? e.bills.filter((e) => e.role === t).length < 3 : e.bills.some((e) => e.role !== t && !e.protected) && e.classes[t].personal.influence > 0;
	let r = b.find((e) => e.id === n);
	if (r.role !== t || r.requirement && !r.requirement.split("/").some((t) => e.policies[Number(t[0]) - 1] === t[1])) return !1;
	let i = F(e, t);
	if (!(() => {
		switch (r.name) {
			case "Cooperative Farm": return e.workers.filter((e) => e.role === t && e.company === null && !e.union).length >= 3 && j(e, t).length < 2;
			case "Highlight Social Issues": return i >= 15 && e.classes.state.storage.influence >= 3;
			case "Political Pressure": return i >= 25;
			case "Foreign Recruitment": return i >= 10 && j(e, t).some((t) => !G(e, t));
			case "Migration": return e.workers.filter((e) => e.role === t && e.company === null && !e.union).length >= 4;
			case "Private Island": return i >= 50;
			case "Affordable Housing": return i >= 20 || e.roles.includes("middle") && i >= 10;
			case "Endorse Political Campaign": return i >= 15;
			case "Technological Progress": return i >= 20 && j(e, t).some((e) => O(e).machineryBonus > 0 && !e.machinery);
			case "Foreign Investment Program": return e.classes.state.personal.influence >= 2;
			case "New Theme Park": return i >= 6 * P(e, t);
			case "Emergency State": return e.bills.length >= 3;
			case "Denial of Free Speech":
			case "Higher VAT": return e.roles.filter((t) => t !== "state" && e.classes[t].legitimacy > 1).length >= 2;
			case "Health Crisis": return e.classes[t].storage.health > 0;
			case "Higher Education Program": return e.classes[t].storage.education > 0;
			case "Bid Rigging": return e.classes[t].storage.luxury > 0;
			case "Protect the Status Quo": return e.bills.filter((e) => e.role === t).length < 3;
			case "Change of Government Agenda": return e.bills.length <= 3 && e.bills.some((e) => e.role !== t);
			case "Reveal Political Scandal": return e.roles.some((n) => n !== t && e.classes[n].personal.influence >= 2);
			case "Business Grants": return t !== "state" || i >= j(e, "capital").length * 5;
			case "Employment Support Scheme": return i >= 30;
			case "Fake News": return e.bag.length > 0;
			case "Interest Groups": return e.bag.some((e) => e !== t) && e.bag.filter((e) => e === t).length < 25;
			default: return !0;
		}
	})()) return !1;
	if (r.name === "Shift Focus" || r.name === "A Matter of High Priority") return e.eventDeck.length > 0 || X(e, {
		kind: "event",
		actor: t
	}).length > 0;
	let a = Ie(e, t, n).find((e) => (/* @__PURE__ */ "propose.pollPropose.directPolicy.build.assign.landOpportunity.buy.event.newSkill.overtime.strike.workplaceAccident.chooseHire.competitiveWages.investmentChoice.industrialization.personalConsumption.growingStorage.protectPolicy.nationalization.privatization.providePopulation.provideChoice.provideIncome.provideRepresentation.foreignRecruitment.sellState.technologyChoice.sellCompany.removeBill".split(".")).includes(e.kind) && !e.optional);
	return !a || X(e, a, !0).some((e) => !["finish", "skip"].includes(e.key));
}
function Ie(e, t, n) {
	let r = (e, n = {}) => ({
		kind: e,
		actor: t,
		...n
	});
	if (n >= 9e4) return n % 10 == 0 ? [r("propose", { flag: "narrative" })] : [r("rapidResolution")];
	let i = b.find((e) => e.id === n), a = e.classes[t], o = e.workers.filter((e) => e.role === t && (e.company !== null || e.union)), s = o.filter((n) => n.company !== null && e.companies.find((e) => e.uid === n.company).owner !== t), c = e.workers.filter((e) => e.role === t && e.company === null && !e.union), l = j(e, t), u = (e, t) => r("gainMoney", {
		n: e,
		source: t
	}), d = (e) => r("gainResource", {
		n: e,
		resource: "influence"
	}), f = (e) => [r("propose", { policy: e - 1 }), r("gainVotes", { n: 2 })], p;
	switch (i.name) {
		case "Public Opinion Polling":
			p = [r("pollPropose")];
			break;
		case "Fake News":
			p = [r("fakeNews")];
			break;
		case "Interest Groups":
			p = [r("interestGroups")];
			break;
		case "Radical Reforms":
			p = [r("propose", { flag: "radical" })];
			break;
		case "Migration":
			p = [r("removeWorkers", {
				limit: 2,
				flag: "migration"
			})];
			break;
		case "Specialization":
			p = [r("newSkill", { target: t === "middle" ? "working" : t }), r("assign", {
				target: t === "middle" ? "working" : t,
				mode: t === "middle" ? "own" : void 0,
				limit: 3,
				flag: "unemployed",
				optional: !0
			})];
			break;
		case "Highlight Social Issues":
			p = [r("buy", {
				resource: "influence",
				source: "state",
				limit: 3,
				discount: .5,
				count: 1,
				data: { exactQuantity: !0 }
			})];
			break;
		case "Cooperative Farm":
			p = [r("cooperativeFarm")];
			break;
		case "Healthcare Benefits":
		case "State Scholarship":
			p = [r("buy", {
				resource: i.name === "Healthcare Benefits" ? "health" : "education",
				source: "state",
				discount: .5,
				count: 1
			})];
			break;
		case "Healthcare Movement":
			p = f(4);
			break;
		case "Workers Movement":
			p = f(2);
			break;
		case "Student Movement":
			p = f(5);
			break;
		case "Immigration Reform":
			p = f(7);
			break;
		case "Need for Change":
			p = [r("propose"), r("proposeSecond", { optional: !0 })];
			break;
		case "Labor Market Deregulation":
			p = [r("assign", {
				limit: 90,
				flag: e.policies[1] === "C" ? void 0 : "unemployed"
			})];
			break;
		case "Workplace Accident":
			p = [r("workplaceAccident")];
			break;
		case "Proletarians of the World, Unite!":
			p = [r("gainVotes", { n: P(e, t) })];
			break;
		case "Boost Domestic Tourism":
			p = [r("buy", {
				resource: "luxury",
				mode: "others",
				discount: .5,
				flag: "subsidy"
			})];
			break;
		case "Supplemental Income Program":
			p = [u(t === "working" ? o.length : t === "middle" ? s.length * 2 : 0, "state"), ...t === "state" ? [r("provideIncome")] : [r("buy", { optional: !0 })]];
			break;
		case "Extra Shift":
			p = [r("overtime", { target: t === "working" ? "state" : t }), ...t === "working" ? [r("buyProduced", {
				source: "state",
				optional: !0
			})] : []];
			break;
		case "Affordable Housing":
			p = [r("affordableHousing")];
			break;
		case "Signing Bonus":
			p = [r("assign", {
				limit: 4,
				flag: "unemployed",
				amount: 4
			})];
			break;
		case "General Strike":
			p = [r("strike", { limit: 2 + e.workers.filter((e) => e.union).length })];
			break;
		case "Unemployment Benefits":
			p = [u(c.length * 5, "state"), r("buy", {
				source: "state",
				optional: !0
			})];
			break;
		case "Health Crisis":
		case "Higher Education Program":
		case "Bid Rigging":
			p = [r("sellState", {
				resource: i.name === "Health Crisis" ? "health" : i.name === "Bid Rigging" ? "luxury" : "education",
				limit: i.name === "Bid Rigging" ? 6 : t === "capital" ? 9 : 6,
				amount: 10
			}), ...i.name === "Bid Rigging" ? [d(1)] : []];
			break;
		case "Political Pressure":
			p = [
				r("payMoney", { n: 25 }),
				r("propose"),
				r("proposeSecond", { optional: !0 })
			];
			break;
		case "Foreign Recruitment":
			p = [r("foreignRecruitment")];
			break;
		case "Competitive Wages":
			p = [r("competitiveWages")];
			break;
		case "Global Branding":
		case "Global Food Crisis":
			p = [r("export", { optional: !0 }), r("extraExport", {
				resource: i.name === "Global Branding" ? "luxury" : "food",
				limit: i.name === "Global Branding" ? 6 : 4,
				amount: i.name === "Global Branding" ? 10 : 15,
				optional: !0
			})];
			break;
		case "Offshore Companies":
			p = [r("offshore")];
			break;
		case "Foreign Market Insight":
			p = [r("exportInsight", { n: t === "capital" ? 2 : 1 }), r("export", {
				limit: t === "middle" ? 2 : 1,
				optional: !0
			})];
			break;
		case "Unemployment Initiative Program":
			p = t === "middle" ? [r("assign", {
				target: "working",
				mode: "own",
				flag: "unemployed",
				limit: 3,
				data: { statePerWorker: 5 }
			})] : [r("chooseHire", { data: { statePerWorker: t === "capital" ? 5 : 0 } })];
			break;
		case "Foreign Partner":
			p = [r("deal"), r("export", {
				mode: "goods",
				optional: !0
			})];
			break;
		case "Business Expansion":
			p = [r("build", { flag: "refill" }), r("build", {
				flag: "refill",
				optional: !0
			})];
			break;
		case "Investment Opportunities":
			p = [r("investmentChoice", { n: t === "capital" ? 10 : 8 })];
			break;
		case "Industrialization":
			p = [r("industrialization")];
			break;
		case "Private Island":
			p = [r("payMoney", {
				n: 50,
				target: "state",
				flag: "capital"
			}), r("score", { n: 7 })];
			break;
		case "Exit Strategy":
			p = [r("sellCompany", { flag: "double" })];
			break;
		case "Business Grants":
			p = t === "state" ? [r("provide", {
				target: "capital",
				resource: void 0,
				amount: j(e, "capital").length * 5,
				data: {
					per: 3,
					metric: "companies"
				}
			})] : [u(l.length * 5, "state")];
			break;
		case "Foreign Trade Lobby":
			p = f(6);
			break;
		case "Taxation Lobby":
			p = f(3);
			break;
		case "Endorse Political Campaign":
			p = [r("payMoney", { n: 15 }), r("gainVotes", { n: 6 })];
			break;
		case "Technological Progress":
			p = [r("technologyChoice")];
			break;
		case "Trade Protectionism Lobby":
			p = [r("gainVotes", { n: 2 * l.filter((t) => O(t).resource === "food" || e.policies[5] === "A" && O(t).resource === "luxury").length })];
			break;
		case "Import Subsidy":
			p = [r("buy", {
				source: "foreign",
				flag: "noTariff",
				count: 1
			})];
			break;
		case "Small Business Grant":
			p = [r("build", { flag: "statePays" })];
			break;
		case "Land of Opportunity":
			p = [r("landOpportunity")];
			break;
		case "Employment Subsidy":
			p = [u(5 * l.filter((t) => A(e, t).some((e) => e.role === "working")).length, "state"), r("overtime", {
				optional: !0,
				mode: "withHelper"
			})];
			break;
		case "Voice of Middle Class Workers":
			p = [r("gainVotes", { n: 2 + new Set(s.map((e) => e.company)).size })];
			break;
		case "New Theme Park":
			p = [r("payMoney", { n: P(e, t) * 6 }), r("prosperity")];
			break;
		case "Export Subsidy":
			p = [r("export", { flag: "subsidy" })];
			break;
		case "Personal Consumption":
			p = [r("personalConsumption")];
			break;
		case "Growing Business":
			p = [r("growingStorage")];
			break;
		case "Public Sector Overtime":
			p = [r("overtime", { target: "state" }), ...t === "middle" ? [r("buyProduced", {
				source: "state",
				optional: !0
			})] : []];
			break;
		case "Employment Support Scheme":
			p = [r("payMoney", { n: 30 }), r("distributeMoney", {
				n: 15,
				used: ["working", "middle"]
			})];
			break;
		case "Shift Focus":
		case "A Matter of High Priority":
			p = [r("eventInsight", { flag: i.name === "Shift Focus" ? "replace" : "add" }), r("event")];
			break;
		case "Denial of Free Speech":
			p = [r("convertMedia", { n: 2 }), r("denySpeech", { n: 2 })];
			break;
		case "Step for Representation":
			p = [r("provideRepresentation")];
			break;
		case "Immediate Response":
			p = [r("event", { n: 2 })];
			break;
		case "Geopolitical Support":
			p = [u([
				15,
				30,
				45
			]["ABC".indexOf(e.policies[5])])];
			break;
		case "Foreign Students":
		case "Medical Tourism":
			p = [r("extraExport", {
				resource: i.name === "Foreign Students" ? "education" : "health",
				limit: 8,
				flag: "publicPrice"
			})];
			break;
		case "Healthcare Program":
		case "Literacy Program":
			p = [r("providePopulation", {
				resource: i.name === "Healthcare Program" ? "health" : "education",
				flag: "token"
			})];
			break;
		case "Emergency State":
			p = [r("directPolicy")];
			break;
		case "Foreign Investment Program":
			p = [r("spendInfluence", { n: 2 }), u(40)];
			break;
		case "Growth in Tourism":
			p = [r("distributeMoney", {
				n: 15,
				used: [
					"state",
					"middle",
					"capital"
				]
			}), ...["middle", "capital"].filter((t) => e.roles.includes(t)).map((e) => r("legitimacyGain", {
				target: e,
				n: 1
			}))];
			break;
		case "Allowances and Subsidies":
			p = [r("provideChoice", {
				amount: 20,
				flag: "token"
			})];
			break;
		case "Agenda-Setting":
			p = [r("agendaReward", { resource: "influence" })];
			break;
		case "Pressing Matters":
			p = [r("propose", { flag: "free" })];
			break;
		case "Construction Boom":
			p = [r("distributeMoney", {
				n: 15,
				used: [
					"state",
					"working",
					"capital"
				]
			}), ...["working", "capital"].map((e) => r("legitimacyGain", {
				target: e,
				n: 1
			}))];
			break;
		case "Higher VAT":
			p = [r("extraTax", { n: 15 }), r("chooseLegitimacyLoss", { n: 2 })];
			break;
		case "Nationalization":
			p = [r("nationalization")];
			break;
		case "Quantitative Easing":
			p = [u(a.loans ? 35 : 25)];
			break;
		case "Privatization":
			p = [r("privatization")];
			break;
		case "Foreign Financial Assistance":
			p = [r("agendaReward", { amount: 10 })];
			break;
		case "Protect the Status Quo":
			p = [r("protectPolicy"), d(1)];
			break;
		case "Change of Government Agenda":
			p = [r("removeBill", { flag: "government" })];
			break;
		case "Momentum for Change":
			p = [d(e.bills.filter((e) => e.role === t).length), r("propose", { flag: "forbidden" })];
			break;
		case "Reveal Political Scandal":
			p = [r("stealInfluence", { n: 2 })];
			break;
		case "Rising Covid-19 Cases":
			p = [r("covidCases"), r("buy", {
				resource: "health",
				count: 4,
				optional: !0
			})];
			break;
		case "Covid-19 Vaccination Program":
			p = [r("foreignHealth"), r("providePopulation", {
				resource: "health",
				n: 3
			})];
			break;
		case "Covid-19 Vaccine R&D Funding":
			p = [u(15 * l.filter((t) => O(t).resource === "health" && G(e, t)).length, "state")];
			break;
		case "Covid-19 Stimulus Package":
			p = [u(s.length * 2 + l.length * 4, "state")];
			break;
		default: p = [];
	}
	if (i.name === "Employment Support Scheme" && p.push(...["working", "middle"].filter((t) => e.roles.includes(t)).map((e) => r("legitimacyGain", {
		target: e,
		n: 1
	}))), i.legitimacy && t !== "state") {
		let t = i.legitimacy, a = t.includes("unemployed workers") ? c.length : t.includes("employed workers") ? o.length : t.includes("qualifying workers") ? s.length : t.includes("qualifying companies") ? l.filter((t) => A(e, t).some((e) => e.role === "working")).length : t.includes("operational health company") ? l.filter((t) => G(e, t) && O(t).resource === "health").length : t.includes("companies") ? l.length : void 0;
		p.push(r("cardLegitimacy", {
			card: n,
			amount: a
		}));
	}
	return p;
}
//#endregion
//#region src/games/hegemony/events.ts
var Le = (e) => e === "working" ? "W" : e === "middle" ? "M" : "C";
function Re(e, t, n, r) {
	let i = Math.max(0, r - e.classes.state.storage[n]), a = 0, o = ["capital", "middle"].filter((n) => e.roles.includes(n) && n !== t).sort((t, r) => K(e, t, n).price - K(e, r, n).price);
	for (let t of o) {
		let r = Math.min(i, e.classes[t].storage[n]);
		i -= r, a += r * K(e, t, n).price;
	}
	return i && (n !== "food" && n !== "luxury" || B(e, n) < i) ? Infinity : a + i * K(e, "foreign", n).price;
}
function ze(e, t) {
	let n = x.find((e) => e.id === t.card), r = n.id >= 27900 ? n.id - 27900 : n.id - 21200, i = n.id < 27900, a = e.classes.state, o = [], s = e.roles.filter((e) => e !== "state");
	function c(t, r = {}) {
		let i = Le(t);
		if (!(n.reward.includes(`${i}:`) || n.reward.includes(`${i}/`) || n.reward.includes(`/${i}:`) || n.reward.includes(`/${i}/`) || !n.reward.match(/[WMC]/)) && n.id !== 27920) return;
		let s = {
			target: t,
			cash: 0,
			spend: {},
			provide: {},
			money: 0,
			votes: 0,
			metric: 1,
			personal: 0,
			label: D[t],
			...r
		};
		s.cash + s.money + T.reduce((n, r) => n + Re(e, t, r, s.provide[r] ?? 0), 0) > F(e, "state") || s.personal > a.personal.influence || T.some((e) => (s.spend[e] ?? 0) > a.storage[e]) || s.votes > 25 - e.bag.filter((e) => e === t).length - e.classes[t].benefits.votes || (!r.label && s.money ? s.label = g("games.hegemony.messages.m083", {
			p1: D[t],
			p2: s.money
		}) : !r.label && s.metric > 1 && (s.label = g("games.hegemony.messages.m084", {
			p1: D[t],
			p2: s.metric
		})), o.push(s));
	}
	for (let n of s) {
		let o = P(e, n), l = j(e, n).filter((t) => G(e, t)).length, u = e.workers.filter((t) => t.role === n && t.company !== null && k(e, t.company).owner === "state").length;
		if (i) {
			switch (r) {
				case 0: {
					let e = Math.min(4, a.storage.education);
					c(n, {
						spend: { education: e },
						cash: (4 - e) * 8,
						label: g("games.hegemony.messages.m085", {
							p1: D[n],
							p2: e,
							p3: (4 - e) * 8
						})
					});
					break;
				}
				case 1:
				case 3:
				case 16:
				case 18: {
					let t = r === 1 ? "education" : r === 16 ? "health" : "luxury";
					j(e, n).some((n) => G(e, n) && O(n).resource === t) && c(n, { cash: r === 18 ? 30 : 0 });
					break;
				}
				case 2:
				case 9:
				case 19:
					c(n, { cash: 30 });
					break;
				case 4:
				case 5: {
					let e = r === 4 ? "education" : "health";
					c(n, { cash: 30 }), c(n, {
						spend: { [e]: 4 },
						label: g("games.hegemony.messages.m086", {
							p1: D[n],
							p2: E[e]
						})
					});
					break;
				}
				case 6: {
					let t = 5 - (fe.find((t) => t.id === e.politicalCard)?.policies.filter((t, n) => t === e.policies[n]).length ?? 0);
					for (let e = 0; e <= t; e += 1) c(n, {
						spend: { influence: e },
						personal: t - e,
						label: g("games.hegemony.messages.m087", {
							p1: D[n],
							p2: e,
							p3: t - e
						})
					});
					break;
				}
				case 7:
					c(n, { spend: { influence: 1 } });
					break;
				case 8:
				case 14:
					c(n, {
						personal: 1,
						cash: 15
					});
					break;
				case 10:
				case 13:
				case 22:
					c(n);
					break;
				case 11:
					t.counter && c(n, { metric: t.counter });
					break;
				case 12:
					for (let e = 1; e <= 3; e += 1) c(n, { spend: {
						health: e,
						education: 4 - e
					} });
					break;
				case 15:
					c(n, {
						personal: 1,
						spend: { education: 2 }
					});
					break;
				case 17: {
					let t = 3 - e.bills.filter((e) => e.role === n).length;
					if (t > 0) for (let e = 0; e <= t; e += 1) c(n, {
						spend: { influence: e },
						personal: t - e
					});
					break;
				}
				case 20:
					c(n, {
						personal: 1,
						spend: { health: 2 }
					});
					break;
				case 21:
					u > 0 && c(n);
					break;
				case 23:
					c(n, { personal: 2 });
					break;
				case 24: c(n, { cash: 20 });
			}
			continue;
		}
		switch (r) {
			case 0:
				for (let e = 1; e <= Math.min(t.limit ?? 3, a.storage.influence); e += 1) c(n, {
					cash: t.counter ? 0 : 25,
					provide: { influence: e },
					metric: e
				});
				break;
			case 1:
			case 15: {
				let e = r === 1 ? "health" : "education";
				for (let t = 1; t <= Math.min(6, a.storage[e]); t += 1) c(n, {
					spend: { [e]: t },
					metric: t
				});
				break;
			}
			case 2:
			case 17:
			case 23: break;
			case 3:
				c(n, {
					provide: { influence: 2 },
					metric: 2
				});
				break;
			case 4:
			case 7:
				c(n, { provide: { [r === 4 ? "education" : "health"]: Math.ceil(o / 2) } });
				break;
			case 5:
				!t.used?.includes(n) && F(e, "state") >= (t.counter ? 25 : 50) && c(n, { money: 25 });
				break;
			case 6:
				for (let e of [
					15,
					30,
					45
				]) c(n, {
					cash: e,
					metric: e
				});
				break;
			case 8:
				if (n === s[0]) for (let t of [10, 15]) F(e, "state") >= t * s.length && c(n, {
					money: t,
					metric: t,
					label: g("games.hegemony.messages.m088", { p1: t })
				});
				break;
			case 9:
				u && c(n, {
					money: u * 5,
					metric: u * 5
				});
				break;
			case 10:
				l && c(n, {
					provide: { luxury: Math.ceil(l / 2) },
					metric: Math.ceil(l / 2)
				});
				break;
			case 11: {
				let e = Math.ceil((n === "working" ? o : l) / 2);
				e && c(n, {
					provide: { food: e },
					metric: e
				});
				break;
			}
			case 12:
				l && c(n, {
					money: l * 5,
					metric: l * 5
				});
				break;
			case 13:
			case 14:
			case 18:
			case 24: {
				let e = Math.ceil((r === 13 && n === "capital" ? l : o) / 2), t = r === 13 ? "luxury" : r === 14 ? "health" : "food", i = r === 13 || r === 14 ? "education" : r === 18 ? "health" : "luxury";
				for (let r = 1; r < e; r += 1) c(n, {
					provide: {
						[t]: r,
						[i]: e - r
					},
					metric: e,
					label: g("games.hegemony.messages.m089", {
						p1: D[n],
						p2: r,
						p3: E[t],
						p4: e - r,
						p5: E[i]
					})
				});
				break;
			}
			case 16: break;
			case 19:
				c(n, {
					money: o * 5,
					metric: o * 5
				});
				break;
			case 20:
				for (let e = 1; e <= (t.limit ?? 4); e += 1) c(n, {
					cash: t.counter ? 0 : 30,
					votes: e,
					metric: e
				});
				break;
			case 21:
				c(n);
				break;
			case 22: c(n, {
				personal: 1,
				votes: 2,
				provide: { influence: 0 }
			});
		}
	}
	return o;
}
function Be(e, t, n, r, i = 0) {
	let a = x.find((e) => e.id === t).reward;
	t === 27908 && (a = r === 10 ? "V+3" : "W/M/C:L+1");
	for (let t of a.split(";")) {
		let a = t.trim(), o = a.indexOf(":");
		if (o >= 0 && !a.slice(0, o).split("/").includes(Le(n))) continue;
		let s = o >= 0 ? a.slice(o + 1) : a, c = s.match(/([LTV])\+(\d+)(?: per (\d+))?/);
		if (!c) continue;
		let l = Number(c[2]) * (c[3] ? Math.floor(r / Number(c[3])) - Math.floor(i / Number(c[3])) : /per (influence|health|education)/.test(s) ? r - i : 1);
		c[1] === "V" ? L(e, "state", l) : z(e, n, l, c[1] === "T");
	}
}
function Ve(e, t) {
	switch (t.kind) {
		case "event": return e.events.filter((n) => n === 21211 ? Ve(e, {
			kind: "eventTarget",
			actor: t.actor,
			card: n,
			resource: "food",
			n: 5
		}).length > 0 : [
			27902,
			27917,
			27923
		].includes(n) ? Ve(e, {
			kind: "eventTarget",
			actor: t.actor,
			card: n,
			resource: n === 27902 ? "health" : n === 27917 ? "luxury" : "education",
			n: j(e, "state").length
		}).length > 0 : n === 27916 ? X(e, {
			kind: "historicalChoice",
			actor: t.actor,
			mode: "eventBuild"
		}).length > 0 : ze(e, {
			...t,
			card: n
		}).length > 0).map((e) => J(`event:${e}`, _(x.find((t) => t.id === e).name), "eventCard", { card: e }));
		case "eventTask": return ze(e, t).map((e, t) => J(`eventPlan:${t}`, e.label, "eventPlan", {
			role: e.target,
			amount: t
		})).concat(t.counter && t.card === 27900 ? [J("eventAllocationDone", g("games.hegemony.messages.m090"))] : []);
		case "eventBenefit": return [J("benefit:keep", g("games.hegemony.messages.m091"), "keepBenefit", { score: e.round < 5 ? 10 : 0 }), J("benefit:vp", g("games.hegemony.messages.m092"), "discardBenefit", { score: e.round === 5 ? 10 : 0 })];
		case "provideChoice":
		case "providePopulation":
		case "provideIncome":
		case "provideRepresentation": {
			let n = t.resource;
			return e.roles.filter((e) => e !== "state" && (t.kind !== "providePopulation" || e !== "capital")).filter((r) => {
				let i = t.kind === "provideIncome" ? e.workers.filter((e) => e.role === r && e.company !== null).length : t.kind === "providePopulation" ? P(e, r) : t.amount ?? 0;
				return F(e, "state") >= (n ? Re(e, r, n, i) : i) && (t.kind !== "provideRepresentation" || e.classes.state.personal.influence >= 1);
			}).map((e) => J(`provideTarget:${e}`, D[e], "provideTarget", { role: e }));
		}
		case "provideBuy": {
			let n = t.resource, r = [];
			for (let i of [
				"capital",
				"middle",
				"foreign"
			]) {
				if (i === t.target || i !== "foreign" && !e.roles.includes(i) || i === "foreign" && n !== "food" && n !== "luxury") continue;
				let a = i === "foreign" ? B(e, n) : e.classes[i].storage[n], o = K(e, i, n).price;
				for (let s = 1; s <= Math.min(t.n - (t.counter ?? 0), a); s += 1) {
					if (F(e, "state") < o * s) continue;
					let a = structuredClone(e);
					Ae(a, "state", i, n, s, {
						area: "storage",
						noTariff: !0,
						overflow: !0
					}) && (T.reduce((e, r) => e + Re(a, t.target, r, r === n ? t.n : Number(t.data?.[r] ?? 0)), 0) > F(a, "state") || r.push(J(`providePurchase:${i}:${s}`, g("games.hegemony.messages.m093", {
						p1: i === "foreign" ? g("games.hegemony.messages.m046") : D[i],
						p2: s,
						p3: E[n]
					}), "providePurchase", {
						role: i === "foreign" ? void 0 : i,
						resource: n,
						amount: s,
						score: s - o * .1
					})));
				}
			}
			return e.classes.state.storage[n] >= t.n && r.push(J("provideReady", g("games.hegemony.messages.m094"), "provideReady", { score: 10 })), r;
		}
		case "eventTarget": {
			let n = t.resource, r = [];
			for (let i of [
				"middle",
				"capital",
				...t.card === 21211 ? ["foreign"] : []
			]) {
				if (i !== "foreign" && !e.roles.includes(i)) continue;
				let a = i === "foreign" ? B(e, n) : e.classes[i].storage[n], o = i === "foreign" ? g("games.hegemony.messages.m046") : D[i];
				for (let s = 1; s <= Math.min(t.n, a, xe(e, "state", n) - e.classes.state.storage[n]); s += 1) F(e, "state") >= K(e, i, n).price * s && r.push(J(`eventBuy:${i}:${s}`, g("games.hegemony.messages.m093", {
					p1: o,
					p2: s,
					p3: E[n]
				}), "eventBuy", {
					role: i === "foreign" ? void 0 : i,
					resource: n,
					amount: s
				}));
			}
			return t.counter && r.push(J("eventBuyFinish", g("games.hegemony.messages.m095"))), r;
		}
		case "eventInsightChoice": return (t.ids ?? []).flatMap((n) => t.flag === "replace" ? e.events.map((e) => J(`replaceEvent:${n}:${e}`, g("games.hegemony.messages.m096", {
			p1: _(x.find((t) => t.id === e).name),
			p2: _(x.find((e) => e.id === n).name)
		}), "replaceEvent", {
			card: n,
			amount: e
		})) : e.events.length < 2 ? [J(`addEvent:${n}`, _(x.find((e) => e.id === n).name), "addEvent", { card: n })] : []).concat([J("declineEvent", g("games.hegemony.messages.m097"))]);
		case "perkDecision": return [J("perk:yes", g("games.hegemony.messages.m098"), "usePerk", {
			card: t.card,
			score: 5
		}), J("perk:no", g("games.hegemony.messages.m099"), "skipPerk")];
		case "publicPressure": return [J("pressure:keep", g("games.hegemony.messages.m100"), "skipPerk"), J("pressure:use", g("games.hegemony.messages.m101"), "publicPressure", { score: 3 })];
		case "perkHire": return [J("perkHire:skip", g("games.hegemony.messages.m102"), "skipPerk"), ...X(e, {
			kind: "hire",
			actor: t.actor,
			company: t.company,
			flag: "unemployed"
		}).some((e) => e.kind === "hireWorker") ? [J("perkHire:use", g("games.hegemony.messages.m103"), "perkHire", { score: 5 })] : []];
		case "perkWage": return e.companies.filter((n) => n.active && n.owner !== "state" && (n.owner === t.actor || A(e, n).some((e) => e.role === t.actor))).flatMap((e) => [-1, 1].filter((t) => e.wage + t >= 1 && e.wage + t <= 3).map((t) => J(`perkWage:${e.uid}:${t}`, g("games.hegemony.messages.m104", {
			p1: _(O(e).name),
			p2: e.wage,
			p3: e.wage + t
		}), "perkWage", {
			company: e.uid,
			amount: t
		})));
		default: return [];
	}
}
function He(e, t) {
	let n = t.target, r = e.classes[n], i = `benefits:${e.round}:${e.turn}:${n}`;
	e.roundEffects[i] || (r.benefits = {
		...me(),
		money: 0,
		votes: 0
	}, e.roundEffects[i] = !0);
	for (let n of T) {
		let i = Number(t.data?.[n] ?? 0);
		(n !== "influence" || t.flag !== "personalPaid") && (e.classes.state.storage[n] -= i), r.benefits[n] += i;
	}
	r.benefits.money += Number(t.data?.money ?? 0), r.benefits.votes += Number(t.data?.votes ?? 0);
}
function Ue(e, t, n) {
	let r = t.actor, i = n.key.split(":");
	switch (n.kind) {
		case "eventCard": return e.jobs.shift(), [
			27902,
			27917,
			27923
		].includes(n.card) ? Y(e, {
			kind: "eventTarget",
			actor: r,
			card: n.card,
			resource: n.card === 27902 ? "health" : n.card === 27917 ? "luxury" : "education",
			n: j(e, "state").length,
			count: t.n
		}) : n.card === 21211 ? Y(e, {
			kind: "eventTarget",
			actor: r,
			card: n.card,
			resource: "food",
			n: 5,
			count: t.n
		}) : n.card === 27916 ? Y(e, {
			kind: "historicalChoice",
			actor: r,
			mode: "eventBuild",
			card: n.card,
			n: t.n
		}) : Y(e, {
			kind: "eventTask",
			actor: r,
			card: n.card,
			n: t.n
		}), !0;
		case "eventPlan": {
			let i = ze(e, t)[n.amount], a = e.classes.state;
			if (t.card === 27908) {
				let n = [];
				for (let t of e.roles.filter((e) => e !== "state")) R(e, "state", i.money), n.push({
					kind: "deliverBenefit",
					actor: r,
					target: t,
					data: { money: i.money }
				}), i.money === 15 && n.push({
					kind: "legitimacyGain",
					actor: r,
					target: t,
					n: 1
				});
				return i.money === 10 && L(e, "state", 3), n.push({
					kind: "eventComplete",
					actor: r,
					card: t.card,
					target: i.target,
					n: t.n
				}), e.jobs.shift(), Y(e, ...n), !0;
			}
			R(e, "state", i.cash + i.money), T.forEach((e) => {
				a.storage[e] -= i.spend[e] ?? 0;
			}), a.personal.influence -= i.personal;
			let o = { ...i.provide };
			t.card === 27922 && (o.influence = 1);
			let s = [];
			for (let [e, n] of T.entries()) (o[n] ?? 0) > 0 && (t.card !== 27922 || n !== "influence") && s.push({
				kind: "provideBuy",
				actor: r,
				target: i.target,
				resource: n,
				n: o[n],
				data: Object.fromEntries(T.slice(e + 1).map((e) => [e, o[e] ?? 0]))
			});
			(i.money || i.votes || T.some((e) => o[e])) && s.push({
				kind: "deliverBenefit",
				actor: r,
				target: i.target,
				flag: t.card === 27922 ? "personalPaid" : void 0,
				data: {
					...o,
					money: i.money,
					votes: i.votes
				}
			});
			let c = Number(t.data?.[i.target] ?? 0);
			if (s.push({
				kind: "eventReward",
				actor: r,
				card: t.card,
				target: i.target,
				amount: t.card === 27920 ? c + i.metric : i.metric,
				counter: t.card === 27920 ? c : 0
			}), t.card === 27921 && s.push({
				kind: "propose",
				actor: i.target,
				payBy: "state"
			}), [
				27900,
				27905,
				27920
			].includes(t.card)) {
				let e = (t.limit ?? (t.card === 27900 ? 3 : t.card === 27905 ? 2 : 4)) - (t.card === 27905 ? 1 : i.metric);
				e ? s.push({
					...t,
					limit: e,
					counter: (t.counter ?? 0) + 1,
					used: [...t.used ?? [], i.target],
					data: {
						...t.data,
						[i.target]: c + i.metric
					}
				}) : s.push({
					kind: "eventComplete",
					actor: r,
					card: t.card,
					target: i.target,
					n: t.n
				});
			} else s.push({
				kind: "eventComplete",
				actor: r,
				card: t.card,
				target: i.target,
				n: t.n
			});
			return e.jobs.shift(), Y(e, ...s), !0;
		}
		case "eventAllocationDone": return e.jobs.shift(), Y(e, {
			kind: "eventComplete",
			actor: r,
			card: t.card,
			target: "capital",
			n: t.n
		}), !0;
		case "keepBenefit":
		case "discardBenefit": return n.kind === "keepBenefit" && !e.roles.some((n) => e.classes[n].perks.includes(t.card)) ? (e.classes[r].perks.push(t.card), e.eventDiscard = e.eventDiscard.filter((e) => e !== t.card)) : L(e, r, 1), e.jobs.shift(), !0;
		case "provideTarget": {
			let i = n.role, a = t.kind === "providePopulation" ? P(e, i) : t.kind === "provideIncome" ? e.workers.filter((e) => e.role === i && e.company !== null).length : t.amount ?? 0;
			e.jobs.shift();
			let o = [];
			t.kind === "provideRepresentation" ? (--e.classes.state.personal.influence, o.push({
				kind: "deliverBenefit",
				actor: r,
				target: i,
				flag: "personalPaid",
				data: {
					influence: 1,
					votes: 2
				}
			})) : t.resource ? (a && o.push({
				kind: "provideBuy",
				actor: r,
				resource: t.resource,
				target: i,
				n: a
			}), o.push({
				kind: "deliverBenefit",
				actor: r,
				target: i,
				data: { [t.resource]: a }
			})) : (R(e, r, a), o.push({
				kind: "deliverBenefit",
				actor: r,
				target: i,
				data: { money: a }
			}));
			let s = t.kind === "provideIncome" ? Math.floor(a / 10) : t.kind === "provideRepresentation" ? 2 : t.n ? Math.floor(a / t.n) : 1;
			return o.push({
				kind: "legitimacyGain",
				actor: r,
				target: i,
				n: s,
				flag: t.flag
			}), Y(e, ...o), !0;
		}
		case "providePurchase": return Ae(e, "state", i[1], t.resource, n.amount, {
			area: "storage",
			noTariff: !0,
			overflow: !0
		}), t.counter = (t.counter ?? 0) + n.amount, !0;
		case "provideReady": return e.jobs.shift(), !0;
		case "eventBuy": {
			Ae(e, "state", i[1], t.resource, n.amount, { area: "storage" }), t.data ??= {};
			let a = Number(t.data[n.role] ?? 0), o = a + n.amount;
			return t.card !== 21211 && z(e, n.role, Math.floor(o / 3) - Math.floor(a / 3)), t.data[n.role] = o, t.counter = (t.counter ?? 0) + n.amount, t.n -= n.amount, t.n === 0 && (e.jobs.shift(), Y(e, t.card === 21211 ? {
				kind: "eventTask",
				actor: r,
				card: t.card,
				counter: t.counter,
				n: t.count
			} : {
				kind: "eventComplete",
				actor: r,
				card: t.card,
				target: n.role,
				n: t.count
			})), !0;
		}
		case "eventBuyFinish": return e.jobs.shift(), Y(e, t.card === 21211 ? {
			kind: "eventTask",
			actor: r,
			card: t.card,
			counter: t.counter,
			n: t.count
		} : {
			kind: "eventComplete",
			actor: r,
			card: t.card,
			target: "capital",
			n: t.count
		}), !0;
		case "replaceEvent":
		case "addEvent":
		case "declineEvent": return n.kind === "replaceEvent" && (e.events = e.events.filter((e) => e !== n.amount), e.eventDiscard.push(n.amount), e.events.push(n.card)), n.kind === "addEvent" && e.events.push(n.card), e.eventDeck.unshift(...(t.ids ?? []).filter((e) => e !== n.card)), e.jobs.shift(), !0;
		case "skipPerk": return e.jobs.shift(), !0;
		case "publicPressure": {
			let t = Math.min(2, e.classes.state.personal.influence);
			return e.classes.state.personal.influence -= t, e.election.sides.state = !0, e.election.prepaid.state = (e.election.prepaid.state ?? 0) + t, e.election.spending.state = 0, e.classes[r].perks = e.classes[r].perks.filter((e) => e !== 21210), e.eventDiscard.push(21210), e.jobs = e.jobs.filter((e) => e.kind !== "electionSides" || e.actor !== "state"), e.jobs.shift(), !0;
		}
		case "perkHire": return delete e.roundEffects[`preproductionAssign:${r}`], e.jobs.shift(), Y(e, {
			kind: "hire",
			actor: r,
			company: t.company,
			flag: "unemployed"
		}), !0;
		case "perkWage": {
			let t = k(e, n.company);
			return e.roundEffects[`restoreWage:${t.uid}`] = t.wage, t.wage += n.amount, e.jobs.shift(), !0;
		}
		case "usePerk": return e.jobs.shift(), Y(e, {
			kind: "activatePerk",
			actor: r,
			card: t.card,
			flag: t.flag
		}), !0;
		default: return !1;
	}
}
function We(e, t) {
	return e.config.alternativeEvents ? e.roles.flatMap((n) => e.classes[n].perks.filter((e) => {
		let n = x.find((t) => t.id === e);
		return ![
			21210,
			21211,
			21213,
			21222
		].includes(e) && "benefitPhase" in n && n.benefitPhase === t;
	}).map((e) => ({
		kind: "perkDecision",
		actor: n,
		card: e,
		flag: t
	}))) : [];
}
function Ge(e, t) {
	let n = t.actor;
	switch (t.kind) {
		case "deliverBenefit": return He(e, t), !0;
		case "provide": return t.resource ? Y(e, {
			kind: "provideBuy",
			actor: n,
			target: t.target,
			resource: t.resource,
			n: t.amount
		}, {
			kind: "deliverBenefit",
			actor: n,
			target: t.target,
			data: { [t.resource]: t.amount }
		}) : (R(e, "state", t.amount), He(e, {
			...t,
			data: { money: t.amount }
		})), t.target && z(e, t.target, Math.floor(j(e, t.target).length / Number(t.data?.per ?? 1))), !0;
		case "legitimacyGain": return z(e, t.target, t.n, t.flag === "token"), !0;
		case "eventReward": return Be(e, t.card, t.target, t.amount, t.counter), !0;
		case "eventComplete": {
			let n = t.card, r = e.events.includes(n);
			e.classes.state.eventsResolved += 1, e.events = e.events.filter((e) => e !== n), r && e.eventDiscard.push(n);
			let i = [];
			if (n < 27900) {
				let r = e.roles.find((t) => e.classes[t].perks.includes(n));
				r ? L(e, r, 1) : i.push({
					kind: "eventBenefit",
					actor: t.target,
					card: n
				});
			}
			return (t.n ?? 1) > 1 && i.push([
				21211,
				27902,
				27917,
				27923
			].includes(n) ? {
				kind: "eventTarget",
				actor: "state",
				card: n,
				resource: n === 21211 ? "food" : n === 27902 ? "health" : n === 27917 ? "luxury" : "education",
				n: n === 21211 ? 5 : j(e, "state").length,
				count: 1
			} : {
				kind: "eventTask",
				actor: "state",
				card: n,
				n: 1
			}), Y(e, ...i), !0;
		}
		case "eventPenalties": {
			if (!e.roles.includes("state")) return !0;
			let t = e.events.splice(0);
			for (let n of t) {
				let t = x.find((e) => e.id === n);
				if (t.penalty === "any2") Y(e, {
					kind: "chooseLegitimacyLoss",
					actor: "state",
					n: 2
				});
				else for (let n of e.roles.filter((e) => e !== "state")) t.penalty.includes(Le(n)) && z(e, n, -1);
			}
			return e.eventDiscard.push(...t), !0;
		}
		case "eventInsight": return Y(e, {
			kind: "eventInsightChoice",
			actor: n,
			ids: e.eventDeck.splice(0, 2),
			flag: t.flag
		}), !0;
		case "activatePerk": {
			let r = e.classes[n];
			switch (t.card) {
				case 21200:
					V(e, n, "education", 1, n === "working" ? "personal" : "storage"), V(e, n, "luxury", 1, n === "working" ? "personal" : "storage");
					break;
				case 21202:
				case 21219:
					r.money += 10;
					break;
				case 21204:
				case 21215:
					V(e, n, "education", 2, n === "working" ? "personal" : "storage");
					break;
				case 21205:
				case 21220:
					V(e, n, "health", 2, n === "working" ? "personal" : "storage");
					break;
				case 21206:
				case 21217:
				case 21223:
					H(e, n, 2);
					break;
				case 21207:
					R(e, "state", 10, n, !0);
					break;
				case 21208:
					V(e, n, "influence", 1);
					break;
				case 21209:
					r.money += 5, e.roundEffects[`preproductionAssign:${n}`] = !0;
					break;
				case 21212:
					V(e, n, "health", 1, n === "working" ? "personal" : "storage"), V(e, n, "education", 1, n === "working" ? "personal" : "storage");
					break;
				case 21214:
					V(e, n, "food", 1, n === "working" ? "personal" : "storage");
					break;
				case 21218:
					e.roundEffects[`luxuryBonus:${n}`] = !0;
					break;
				case 21221:
					e.roundEffects[`publicWageBonus:${n}`] = !0;
					break;
				case 21201:
				case 21203:
				case 21216:
					Y(e, {
						kind: "sellState",
						actor: n,
						resource: t.card === 21201 ? "education" : t.card === 21203 ? "luxury" : "health",
						limit: 2,
						amount: 10,
						optional: !0,
						flag: "perkSale"
					});
					break;
				case 21211:
					e.classes.state.storage.food ? (--e.classes.state.storage.food, V(e, n, "food", 1)) : L(e, "state", -1);
					break;
				case 21224: Y(e, {
					kind: "perkWage",
					actor: n,
					card: t.card
				});
			}
			return !0;
		}
		default: return !1;
	}
}
//#endregion
//#region src/games/hegemony/historical.ts
function Ke(e) {
	if (!e.config.historicalEvents || e.historical === null || e.historicalUsed.length) return !1;
	let t = e.historical, n = (t) => e.companies.filter((n) => G(e, n) && O(n).resource === t).length, r = e.workers.filter((e) => e.union).length, i = e.policies.slice(0, 5).filter((e) => e === "A").length, a = e.roles.includes("middle") ? 3 : 2, o = e.workers.filter((e) => e.company === null && !e.union).length, s = e.roles.reduce((t, n) => t + e.classes[n].loans, 0) + (e.roles.includes("state") ? 0 : e.classes.state.loans), c = e.roles.reduce((t, n) => t + e.classes[n].personal.influence, 0);
	switch (t) {
		case 4: return e.companies.some((e) => e.machinery);
		case 6: return n("luxury") >= a;
		case 7: return e.policies[1] !== "A" && e.policies[3] !== "A" && r >= 1;
		case 10:
		case 13: return n("health") <= a;
		case 12: return e.policies[5] !== "A";
		case 14:
		case 27: return o >= (e.roles.includes("middle") ? 7 : 4);
		case 15: return s >= 2 || e.classes.state.money <= 100;
		case 16: return e.policies[1] !== "C" && n("health") >= a;
		case 17: return e.policies[1] !== "A" && r >= 2;
		case 19: return e.companies.filter((e) => e.active && ["food", "luxury"].includes(O(e).resource)).length >= (e.roles.includes("middle") ? 6 : 4);
		case 22: return e.policies[1] !== "A" && e.classes.working.prosperity <= 3 && r >= 2;
		case 23: return e.classes.working.prosperity <= 3;
		case 24: return i >= 2;
		case 25: return i <= 2;
		case 26: return c >= (e.roles.length === 2 ? 4 : e.roles.length === 3 ? 5 : 7);
		case 28: return e.policies.slice(0, 5).filter((e) => e === "B").length >= 3 && r >= 2 && (!e.roles.includes("middle") || P(e, "middle") >= 5);
		case 29: return n("luxury") >= 3;
		case 30: return j(e, "capital").length >= 9 && (!e.roles.includes("state") || e.classes.state.personal.influence >= 3);
		case 31: return i >= 3;
		case 32: return e.policies[5] !== "C";
		case 33: return n("education") >= (e.roles.includes("middle") ? 5 : 3);
		case 34: return c >= (e.roles.includes("middle") ? 5 : 4);
		case 36: return e.classes.state.money < 100 && e.classes.state.loans > 0;
		case 40: return e.policies[0] !== "C" && e.policies[2] !== "C";
		case 41:
		case 43: return s >= 2;
		case 45: return e.classes.state.money <= 50 || i >= 3;
		case 46: return e.classes.working.prosperity >= 5 && (!e.roles.includes("middle") || e.classes.middle.prosperity >= 5);
		case 47: return e.policies[1] !== "A" && e.policies[2] !== "C";
		default: return !0;
	}
}
function qe(e, t) {
	let n = t.actor;
	if (t.kind === "freeExtensions" || t.kind === "historicalBasic") {
		if (!Ke(e)) return [];
		let r = pe.cards.find((t) => t.slot === e.historical), i = r.roles === "all" ? null : r.roles;
		if (r.trigger === "free" != (t.kind === "freeExtensions") || i && !i.includes(n)) return [];
		let a = r.trigger.includes("2influence") ? 2 : +!!r.trigger.includes("1influence");
		return e.classes[n].personal.influence < a ? [] : [J("triggerHistory", _(r.name), "triggerHistory", {
			card: r.slot,
			score: 6
		})];
	}
	if (t.kind !== "historicalChoice") return [];
	switch (t.mode) {
		case "recruitClass": return ["working", "middle"].filter((t) => e.roles.includes(t)).map((e) => J(`recruit:${e}`, D[e], "recruit", { role: e }));
		case "eventBuild": return ["capital", "middle"].filter((t) => e.roles.includes(t)).flatMap((t) => e.classes[t].market.filter((n) => {
			let r = y.find((e) => e.id === n);
			return r.cost >= 15 && F(e, "state") >= r.cost && X(e, {
				kind: "build",
				actor: t,
				flag: "statePays",
				data: { onlyUnemployed: !0 }
			}).some((e) => e.card === n);
		}).map((e) => J(`eventBuild:${t}:${e}`, g("games.hegemony.messages.m084", {
			p1: D[t],
			p2: _(y.find((t) => t.id === e).name)
		}), "eventBuild", {
			role: t,
			card: e
		})));
		case "sellLuxuryToState": return j(e, "capital").filter((e) => O(e).resource === "luxury").map((e) => J(`transferState:${e.uid}`, _(O(e).name), "transferState", { company: e.uid }));
		case "giveCompany":
		case "giveOperatingCompany": return j(e, "capital").filter((n) => t.mode !== "giveOperatingCompany" || G(e, n)).map((e) => J(`transferState:${e.uid}`, _(O(e).name), "transferState", { company: e.uid }));
		case "replacePublic": {
			let n = j(e, "state"), r = n.filter((t) => !G(e, t));
			return (r.length || t.flag !== "giveOperatingCompany" ? r : n).map((e) => J(`replacePublic:${e.uid}`, _(O(e).name), "replacePublic", { company: e.uid }));
		}
		case "discardOperating": return j(e, n).filter((t) => G(e, t)).map((e) => J(`discardOperating:${e.uid}`, _(O(e).name), "discardOperating", { company: e.uid }));
		case "rescue": return [J("rescue:no", g("games.hegemony.messages.m147"), "rescue"), ...F(e, "state") >= Math.floor(O(k(e, t.company)).cost / 2) ? [J("rescue:yes", g("games.hegemony.messages.m148"), "rescue")] : []];
		case "privatizeHalf": return j(e, "state").filter((t) => F(e, "capital") >= Math.ceil(O(t).cost / 2)).map((e) => J(`halfPublic:${e.uid}`, _(O(e).name), "halfPublic", { company: e.uid }));
		case "civilUnrest": return X(e, {
			kind: "propose",
			actor: n,
			payBy: "state"
		});
		case "exportOrDeal": return ["export", "deal"].flatMap((t) => X(e, {
			kind: t,
			actor: n
		}).some((e) => !["finish", "skip"].includes(e.key)) ? [J(`historyTrade:${t}`, g(t === "export" ? "games.hegemony.messages.m012" : "games.hegemony.messages.m013"), "historyTrade")] : []);
		case "legitimacyTwo": return e.roles.filter((e) => e !== "state" && !t.used?.includes(e)).map((e) => J(`historyLegitimacy:${e}`, D[e], "historyLegitimacy", { role: e }));
		default: return [];
	}
}
function Je(e) {
	e.bills.forEach((t) => V(e, t.role, "influence", 1)), e.bills = [], e.locked.push(-1);
}
function Ye(e, t, n) {
	let r = "ABC".indexOf(e.policies[t]);
	return {
		kind: "policyChange",
		actor: "working",
		policy: t,
		flag: typeof n == "string" ? n : "ABC"[Math.max(0, Math.min(2, r + n))],
		mode: "compensate"
	};
}
function Xe(e, t) {
	let n = k(e, t);
	A(e, n).forEach((e) => {
		e.company = null, e.slot = -1, e.committed = !1;
	}), e.classes[n.owner].companyDiscard.push(n.definition), e.companies = e.companies.filter((e) => e.uid !== t), De(e);
}
function Ze(e, t, n) {
	let r = n.key.split(":");
	switch (n.kind) {
		case "triggerHistory": {
			let n = pe.cards.find((t) => t.slot === e.historical), r = n.trigger.includes("2influence") ? 2 : +!!n.trigger.includes("1influence");
			return e.classes[t.actor].personal.influence -= r, e.jobs[0] === t && e.jobs.shift(), Y(e, {
				kind: "applyHistorical",
				actor: t.actor,
				card: n.slot
			}), !0;
		}
		case "recruit": {
			let r = k(e, t.company);
			for (let [t, i] of W(r).entries()) {
				let a = U(e, n.role, i.skill);
				a && (a.company = r.uid, a.slot = t, a.committed = !0);
			}
			return e.jobs.shift(), !0;
		}
		case "eventBuild": {
			let r = n.role, i = y.find((e) => e.id === n.card);
			R(e, "state", i.cost), e.classes[r].market = e.classes[r].market.filter((e) => e !== i.id);
			let a = e.nextId++;
			return e.companies.push({
				uid: a,
				definition: i.id,
				owner: r,
				wage: 3 - "ABC".indexOf(e.policies[1]),
				active: !0,
				strike: !1,
				machinery: !1
			}), e.jobs.shift(), Y(e, {
				kind: "hire",
				actor: r,
				company: a,
				flag: "unemployed"
			}, {
				kind: "eventReward",
				actor: "state",
				card: 27916,
				target: r,
				amount: 1
			}, {
				kind: "eventComplete",
				actor: "state",
				card: 27916,
				target: r,
				n: t.n
			}), !0;
		}
		case "transferState": return e.jobs.shift(), Y(e, {
			...t,
			kind: "historicalChoice",
			actor: e.roles.includes("state") ? "state" : "capital",
			mode: "replacePublic",
			company: n.company,
			flag: t.mode
		}), !0;
		case "replacePublic": {
			let r = k(e, n.company);
			A(e, r).forEach((e) => {
				e.company = null, e.slot = -1, e.committed = !1;
			});
			let i = k(e, t.company), a = r.uid;
			return e.companies = e.companies.filter((e) => e.uid !== i.uid), r.definition = i.definition, r.active = !0, r.wage = i.wage, r.machinery = i.machinery, r.strike = i.strike, A(e, i).forEach((e) => {
				e.company = a;
			}), (e.historical === 5 || e.historical === 18) && R(e, "state", 32, "capital", !0), e.jobs.shift(), De(e), !0;
		}
		case "discardOperating": return e.jobs.shift(), t.flag === "rescue" && e.roles.includes("state") ? Y(e, {
			kind: "historicalChoice",
			actor: "state",
			mode: "rescue",
			company: n.company,
			target: t.actor
		}) : Xe(e, n.company), !0;
		case "rescue": return r[1] === "yes" ? (R(e, "state", Math.floor(O(k(e, t.company)).cost / 2), t.target), z(e, t.target, 1)) : Xe(e, t.company), e.jobs.shift(), !0;
		case "halfPublic": return R(e, "capital", Math.ceil(O(k(e, n.company)).cost / 2), "state"), k(e, n.company).owner = "capital", e.jobs.shift(), !0;
		case "historyTrade": return e.jobs.shift(), Y(e, {
			kind: r[1],
			actor: t.actor
		}), !0;
		case "historyLegitimacy": return z(e, n.role, 1), t.used ??= [], t.used.push(n.role), t.used.length === 2 && e.jobs.shift(), !0;
		default: return !1;
	}
}
function Qe(e, t) {
	if (t.kind === "removeAllUnemployed") return e.workers = e.workers.filter((e) => e.role !== t.actor || e.company !== null || !!e.union), !0;
	if (t.kind === "historicalSetup") return Y(e, {
		kind: "applyHistorical",
		actor: "working",
		card: e.historicalDeck.shift()
	}), !0;
	if (t.kind === "historicalReveal") return e.historical = e.historicalDeck.shift(), e.historicalUsed = [], pe.cards.find((t) => t.slot === e.historical).trigger === "reveal" && Ke(e) && Y(e, {
		kind: "applyHistorical",
		actor: "working",
		card: e.historical
	}), !0;
	if (t.kind === "historicalEnd") return Ke(e) && pe.cards.find((t) => t.slot === e.historical).trigger === "actionEnd" && Y(e, {
		kind: "applyHistorical",
		actor: "working",
		card: e.historical
	}), !0;
	if (t.kind !== "applyHistorical") return !1;
	let n = t.card;
	e.historical === n && (e.historicalUsed = [t.actor]);
	let r = [], i = (e, t, n = {}) => ({
		kind: e,
		actor: t,
		...n
	}), a = ["working", "middle"].filter((t) => e.roles.includes(t)), o = (e, t) => r.push(i("gainResource", e, {
		resource: "influence",
		n: t
	})), s = (t, n, r) => {
		H(e, "working", t), H(e, "capital", n), e.roles.includes("middle") && H(e, "middle", r);
	}, c = (e, t = !1) => a.forEach((n) => r.push(i("removeWorkers", n, {
		limit: e,
		flag: t ? "any" : void 0,
		optional: !0
	}))), l = (t) => t.forEach(([t, n]) => r.push(Ye(e, t - 1, n))), u = (t = !1) => ["capital", "middle"].filter((t) => e.roles.includes(t)).forEach((e) => r.push(i("historicalChoice", e, {
		mode: "discardOperating",
		flag: t ? "rescue" : void 0
	})));
	switch (n) {
		case 0:
			e.classes.state.personal.influence = 0, e.roles.filter((e) => e !== "state").forEach((e) => r.push(i("propose", e)));
			break;
		case 1:
		case 2: {
			let t = n === 1 ? "capital" : "working", r = n === 1 ? "Technological Progress" : "Need for Change", i = e.classes[t], a = [...i.deck, ...i.hand].filter((e) => b.find((t) => t.id === e)?.name === r).slice(0, 2), o = I(e, [...i.deck, ...i.hand].filter((e) => !a.includes(e)));
			i.automa === "off" && (i.hand = [...a, ...o.splice(0, 5)], i.deck = o), n === 1 ? (s(2, 0, 2), i.money += 10) : (e.roles.includes("middle") && H(e, "middle", 2), e.roles.includes("state") && (e.classes.state.storage.influence = Math.max(0, e.classes.state.storage.influence - 2)));
			break;
		}
		case 3:
			s(4, 1, 2);
			break;
		case 4:
			e.roundEffects.machineryLuxuryBonus = 3;
			break;
		case 5:
		case 18:
			e.roundEffects.publicHalf = !0, l([
				[1, -1],
				[3, -1],
				[6, -1]
			]), c(n === 5 ? 1 : 2), r.push(i("historicalChoice", "capital", {
				mode: "sellLuxuryToState",
				optional: !0
			}));
			break;
		case 6:
			V(e, "working", "luxury", 1), e.roundEffects.luxuryProduction = 2, e.roles.includes("state") && (e.classes.state.money += 15);
			break;
		case 7:
			Je(e), e.roundEffects.publicFree = !0, l([
				[1, "A"],
				[2, "C"],
				[3, "A"],
				[4, "A"]
			]), r.push(i("cooperativeFarm", "working"), i("historicalChoice", "capital", { mode: "giveCompany" }), i("payMoney", "capital", {
				n: 20,
				target: "state"
			}));
			break;
		case 8:
			Je(e), e.roles.filter((e) => e !== "state").forEach((t) => {
				e.classes[t].personal.influence = Math.max(0, e.classes[t].personal.influence - 1);
			}), e.roles.includes("state") && (r.push(i("directPolicy", "state", { flag: "historical" }), i("directPolicy", "state", { flag: "historical" })), o("state", 2), e.roles.filter((e) => e !== "state").forEach((t) => z(e, t, -1)));
			break;
		case 9:
			e.business.push(e.businessDeck.shift()), e.classes.state.money += 20, a.forEach((t) => V(e, t, "food", 1)), r.push(i("historicalChoice", "capital", {
				mode: "exportOrDeal",
				optional: !0
			}));
			break;
		case 10:
			c(1, !0);
			break;
		case 11:
			c(1), e.classes.state.money = Math.max(0, e.classes.state.money - 15);
			break;
		case 12:
			l([[6, "A"]]), e.businessDiscard.push(...e.business.splice(0));
			break;
		case 13:
			c(2, !0), a.forEach((t) => z(e, t, -1));
			break;
		case 14:
			l([[1, -1], [2, -1]]), a.forEach((e) => r.push(i("assign", e, {
				flag: "unemployed",
				limit: 90,
				mode: "external",
				optional: !0,
				data: { stateToCapital: 5 }
			})));
			break;
		case 15:
			l([
				[2, 1],
				[4, 1],
				[5, 1]
			]), u(), e.roundEffects.allPricesLocked = !0, e.classes.state.money = Math.max(0, e.classes.state.money - 30);
			break;
		case 16:
			a.forEach((t) => {
				for (let n = 0; n < 3; n += 1) U(e, t, "any");
				r.push(i("prosperity", t));
			});
			break;
		case 17:
			o("working", 1), r.push(i("strike", "working", { limit: 2 + e.workers.filter((e) => e.union).length })), e.roles.includes("middle") && H(e, "middle", new Set(e.workers.filter((t) => t.role === "middle" && t.company !== null && k(e, t.company).owner !== "middle").map((e) => e.company)).size);
			break;
		case 19:
			l([[6, 1]]), e.business.push(e.businessDeck.shift()), r.push(i("deal", "capital", { optional: !0 })), e.roundEffects.exportLegitimacy = !0;
			break;
		case 20:
			s(4, 1, 1);
			break;
		case 21:
			r.push(i("assign", "working", {
				flag: "unemployed",
				limit: 90,
				optional: !0
			})), e.roundEffects.machineryBonus = 2;
			break;
		case 22:
			Je(e), r.push(i("directPolicy", "working", {
				flag: "historical",
				optional: !0
			}), i("directPolicy", "working", {
				flag: "historical",
				optional: !0
			}), i("payMoney", "capital", {
				n: 40,
				target: "state"
			})), e.roles.includes("state") && r.push(i("directPolicy", "state", { flag: "historical" }));
			break;
		case 23:
			r.push(i("strike", "working")), s(4, 0, 2);
			break;
		case 24:
			e.businessDiscard.push(...e.business.splice(0)), e.roundEffects.embargo = !0;
			break;
		case 25:
			e.classes.state.money += 30, r.push(i("build", "capital", {
				discount: 1e3,
				mode: "nonAutomated"
			}));
			break;
		case 26:
			e.roundEffects.freeVotes = !0, s(3, 1, 2);
			break;
		case 27:
			l([
				[1, "B"],
				[2, "B"],
				[3, "B"],
				[4, "A"],
				[5, "B"],
				[6, "B"]
			]);
			break;
		case 28:
			s(4, 0, 0), e.roles.includes("middle") && o("middle", 1), z(e, "working", 1);
			break;
		case 29:
			r.push(i("buy", "working", {
				resource: "luxury",
				source: "capital",
				limit: Math.floor(P(e, "working") / 2),
				optional: !0
			})), e.roles.includes("middle") && r.push(i("buy", "middle", {
				resource: "luxury",
				source: "capital",
				optional: !0
			}));
			break;
		case 30:
			r.push(i("historicalChoice", "capital", { mode: "giveOperatingCompany" })), z(e, "capital", -1);
			break;
		case 31:
			l([[1, 1], [3, 1]]), e.classes.state.money += 30;
			break;
		case 32:
			e.roundEffects.asianTigers = !0;
			break;
		case 33:
			e.roundEffects.mediaProduction = 1, r.push(i("educate", "working", { optional: !0 })), o("working", 1);
			for (let t of ["capital", "middle"]) e.roles.includes(t) && r.push(i("export", t, {
				count: 2,
				optional: !0
			}));
			e.roles.includes("state") && o("state", Math.floor(j(e, "state").filter((t) => G(e, t)).length / 2));
			break;
		case 34:
			e.classes.state.storage.influence = Math.max(0, e.classes.state.storage.influence - 3), e.roles.filter((e) => e !== "state").forEach((e) => o(e, 1)), e.roles.includes("state") && r.push(i("historicalChoice", "state", { mode: "legitimacyTwo" }));
			break;
		case 35:
			l([[7, "C"]]), a.forEach((t) => we(e, t, 1));
			break;
		case 36:
			l([
				[1, 1],
				[2, 1],
				[4, 1]
			]);
			break;
		case 37:
			e.roundEffects.oilCrisis = !0, e.roundEffects.goodsPricesLocked = !0;
			break;
		case 38:
			e.roundEffects.foodProduction = -1;
			break;
		case 39:
			e.roundEffects.freeVotes = !0;
			break;
		case 40:
			for (let t of ["capital", "middle"]) e.roles.includes(t) && R(e, t, j(e, t).filter((t) => G(e, t) && O(t).resource === "luxury").length * 10, "state", !0);
			break;
		case 41:
			l([[2, 1], [3, 1]]), e.roles.filter((e) => e !== "state").forEach((t) => R(e, "state", 10, t, !0)), u(!0), e.roles.includes("state") && r.push(i("chooseLegitimacyLoss", "state", { n: 2 }));
			break;
		case 42:
			l([[6, -1]]), e.business.length && e.businessDiscard.push(...e.business.splice(_e(e, e.business.length), 1)), e.roundEffects.luxuryPricesLocked = !0;
			break;
		case 43:
			l([
				[1, 1],
				[2, 1],
				[3, -1],
				[4, 1]
			]), u(), e.roles.filter((e) => e !== "state").forEach((t) => z(e, t, -1));
			break;
		case 44:
			e.policies[5] === "C" && e.policies[6] === "C" ? r.push(i("maastrichtReward", t.actor)) : r.push(i("maastrichtVote", t.actor));
			break;
		case 45:
			l([
				[1, 1],
				[2, 1],
				[3, 1]
			]), a.forEach((e) => r.push(i("removeAllUnemployed", e))), r.push(i("historicalChoice", "capital", {
				mode: "privatizeHalf",
				optional: !0
			}));
			break;
		case 46:
			e.roundEffects.useResourceVP = 1;
			break;
		case 47:
			l([[2, -1], [3, 1]]);
			break;
		case 48:
			l([
				[1, "C"],
				[2, "B"],
				[3, "B"],
				[4, "A"],
				[5, "A"],
				[6, "B"],
				[7, "B"]
			]);
			{
				let t = 2;
				e.bag = e.bag.filter((e) => e !== "working" || t-- <= 0);
			}
			o("capital", 2), z(e, "working", 1, !0);
			break;
		case 49: l([
			[1, "C"],
			[2, "B"],
			[3, "B"],
			[4, "B"],
			[5, "C"],
			[6, "A"],
			[7, "B"]
		]), o("working", 3), e.roles.includes("middle") && o("middle", 1), H(e, "capital", 4), z(e, "capital", 1, !0);
	}
	if (e.roundEffects.allPricesLocked || e.roundEffects.goodsPricesLocked || e.roundEffects.luxuryPricesLocked) for (let t of ["capital", "middle"]) e.classes[t].prices.luxury = 10, e.roundEffects.luxuryPricesLocked || (e.classes[t].prices.food = 15), e.roundEffects.allPricesLocked && (e.classes[t].prices.health = 10, e.classes[t].prices.education = 10);
	return Y(e, ...r), !0;
}
//#endregion
//#region src/games/hegemony/crisis.ts
function $e(e, t) {
	for (let n of e.bills.filter((e) => t.includes(e.policy))) V(e, n.role, "influence", 1);
	e.bills = e.bills.filter((e) => !t.includes(e.policy));
}
function et(e) {
	let t = e.classes.state;
	R(e, "state", Math.min(t.money, t.loans * 55)), t.loans = 0;
}
function tt(e, t) {
	return t.kind === "bondBuy" ? [J("bond:0", g("games.hegemony.messages.m059"), "bond", { amount: 0 }), ...[30, 50].filter((n) => F(e, t.actor) >= n).map((e) => J(`bond:${e}`, g("games.hegemony.messages.m060", {
		p1: e,
		p2: e === 30 ? 40 : 70
	}), "bond", { amount: e }))] : [];
}
function nt(e, t, n) {
	if (n.kind !== "bond") return !1;
	let r = n.amount;
	return r && (R(e, t.actor, r, "state"), e.bonds.push({
		role: t.actor,
		principal: r,
		repayment: r === 30 ? 40 : 70,
		due: e.round + 1
	})), e.jobs.shift(), !0;
}
function rt(e, t) {
	let n = e.roles.filter((e) => e !== "state");
	switch (t.kind) {
		case "imf": {
			if (!e.config.crisisResponse) return $e(e, [
				0,
				1,
				2,
				3,
				4,
				5,
				6
			]), Y(e, ...[
				"C",
				"C",
				"A",
				"B",
				"C",
				"B",
				"B"
			].map((e, t) => ({
				kind: "policyChange",
				actor: "state",
				flag: e,
				policy: t,
				mode: "imf"
			})), {
				kind: "imfLoans",
				actor: "state"
			}, {
				kind: "imfLegitimacy",
				actor: "state",
				flag: "half"
			}), ve(e, g("games.hegemony.messages.m061")), !0;
			let n = S.find((t) => t.id === e.crisisCard);
			if (n.id === 21107 && e.round === 5 || n.id === 21109 && e.workers.filter((e) => e.union).length < 2) return e.crisisCard = e.crisisDeck.shift(), Y(e, t), !0;
			ve(e, g("games.hegemony.messages.m062", { p1: _(n.name) })), $e(e, n.discardBills === "all" ? [
				0,
				1,
				2,
				3,
				4,
				5,
				6
			] : n.discardBills.map((e) => e - 1)), e.locked.push(...n.locks.map((e) => e - 1)), n.id === 21109 && (e.roundEffects.publicFree = !0);
			let r = n.policies.flatMap((e, t) => e === "-" ? [] : [{
				kind: "policyChange",
				actor: "state",
				flag: e,
				policy: t
			}]);
			return r.push({
				kind: "crisisEffects",
				actor: "state",
				card: n.id
			}), n.id !== 21107 && r.push({
				kind: "imfLoans",
				actor: "state"
			}, {
				kind: "crisisLegitimacy",
				actor: "state",
				card: n.id
			}, {
				kind: "crisisNext",
				actor: "state"
			}), Y(e, ...r), !0;
		}
		case "imfLoans": return et(e), !0;
		case "imfLegitimacy": return n.forEach((t) => {
			e.classes[t].legitimacy = Math.max(1, Math.ceil(e.classes[t].legitimacy / 2));
		}), !0;
		case "crisisNext": return e.crisisCard = e.crisisDeck.shift() ?? null, !0;
		case "crisisEffects":
			switch (t.card) {
				case 21100:
					V(e, "working", "influence", Math.ceil(P(e, "working") / 2)), H(e, "working", e.workers.filter((e) => e.union).length * 2), e.roles.includes("middle") && (V(e, "middle", "influence", 2), H(e, "middle", new Set(e.workers.filter((t) => t.role === "middle" && t.company !== null && ["state", "capital"].includes(k(e, t.company).owner)).map((e) => e.company)).size * 2)), Y(e, ...["working", ...e.roles.includes("middle") ? ["middle"] : []].map((e) => ({
						kind: "removeWorkers",
						actor: e,
						limit: 2,
						optional: !0
					})));
					break;
				case 21101:
					for (; e.classes.state.money < e.classes.state.loans * 55;) for (let t of n) R(e, t, 10, "state", !0), z(e, t, -1);
					break;
				case 21102:
					Y(e, {
						kind: "removeWorkers",
						actor: "working",
						limit: 2,
						optional: !0
					});
					break;
				case 21103:
					e.classes.state.money += 40;
					break;
				case 21105:
					e.classes.state.money += 60;
					for (let t of n) if (R(e, "state", t === "capital" ? 15 : 10, t, !0), t !== "capital") {
						let n = Math.min(2, e.classes.state.storage.health);
						e.classes.state.storage.health -= n, V(e, t, "health", n);
					}
					break;
				case 21106:
					Y(e, {
						kind: "strike",
						actor: "working",
						limit: 3,
						optional: !0
					});
					break;
				case 21107:
					Y(e, ...[...n].reverse().map((e) => ({
						kind: "bondBuy",
						actor: e
					})), {
						kind: "bondCheck",
						actor: "state"
					});
					break;
				case 21108:
					n.forEach((t) => R(e, t, 10, "state", !0));
					break;
				case 21109: for (let t of n) R(e, t, t === "working" ? 10 : t === "middle" ? 20 : 35, "state", !0), t !== "working" && V(e, t, "influence", Math.floor(j(e, t).length / 2));
			}
			return !0;
		case "bondCheck":
			if (e.classes.state.money >= e.classes.state.loans * 55) et(e), Y(e, {
				kind: "crisisNext",
				actor: "state"
			});
			else {
				for (let t of e.bonds.filter((t) => t.due === e.round + 1)) R(e, "state", t.principal, t.role);
				e.bonds = e.bonds.filter((t) => t.due !== e.round + 1), e.crisisCard = e.crisisDeck.shift(), Y(e, {
					kind: "imf",
					actor: "state"
				});
			}
			return !0;
		case "crisisLegitimacy": {
			let r = S.find((e) => e.id === t.card);
			for (let t of r.legitimacy.split(",")) {
				let [r, i] = t.split(":");
				if (i) for (let t of r === "each" ? n : [r]) e.roles.includes(t) && (i === "half-rounded-up" ? e.classes[t].legitimacy = Math.max(1, Math.ceil(e.classes[t].legitimacy / 2)) : /^-\d+$/.test(i) && z(e, t, Number(i)));
			}
			return !0;
		}
		default: return !1;
	}
}
//#endregion
//#region src/games/hegemony/assignments.ts
function it(e, t, n, r, i, a = !1) {
	let o = A(e, r).find((e) => e.id !== n.id && e.slot === i);
	return o ? n.company === null && !a || o.role !== (t.target ?? t.actor) || !Te(e, o) || t.moves?.some((e) => e.worker === o.id) || t.flag === "unemployed" ? !1 : Ee({
		...e,
		workers: e.workers.filter((e) => e.id !== o.id)
	}, n, r, i) : Ee(e, n, r, i);
}
function at(e, t) {
	let n = structuredClone(e);
	for (let e of t.moves ?? []) Object.assign(n.workers.find((t) => t.id === e.worker), {
		company: e.company,
		slot: e.slot,
		union: e.union,
		committed: !0
	});
	return n;
}
function ot(e, t) {
	return !e.companies.some((t) => {
		let n = A(e, t);
		return new Set(n.map((e) => e.slot)).size !== n.length;
	}) && (t.moves ?? []).every((t) => t.company === null ? !t.union || e.workers.filter((e) => e.union === t.union).length !== 1 ? !1 : e.workers.filter((n) => n.role === "working" && n.company !== null && G(e, k(e, n.company)) && O(k(e, n.company)).resource === t.union).length >= 4 : G(e, k(e, t.company)));
}
function st(e, t) {
	let n = at(e, t), r = t.target ?? t.actor;
	if (!M(r)) return null;
	let i = [...t.moves ?? []], a = new Set(i.map((e) => e.worker)), o = /* @__PURE__ */ new Set(), s = () => {
		let e = i.map((e) => `${e.worker},${e.company ?? -1},${e.slot},${e.union ?? "-"}`).sort().join(";");
		if (o.has(e)) return !1;
		o.add(e);
		let c = [...new Set(i.flatMap((e) => e.company === null ? [] : [e.company]))].map((e) => k(n, e)), l = n.workers.filter((e) => e.role === r && !a.has(e.id) && Te(n, e) && (t.flag !== "unemployed" || e.company === null)).sort((e, t) => Number(c.some((t) => t.uid === e.company)) - Number(c.some((e) => e.uid === t.company)) || Number(e.company !== null) - Number(t.company !== null)), u = c.flatMap((e) => W(e).flatMap((t, r) => t.optional || A(n, e).some((e) => e.slot === r) ? [] : [{
			c: e,
			slot: r
		}])), d = /* @__PURE__ */ new Map(), f = (e, t) => {
			let { c: r, slot: i } = u[e];
			for (let a of l) if (!t.has(a.id) && Ee(n, a, r, i)) {
				t.add(a.id);
				let n = d.get(a.id);
				if (n === void 0 || f(n, t)) return d.set(a.id, e), !0;
			}
			return !1;
		};
		if (u.length > (t.limit ?? 3) - i.length || !u.every((e, t) => f(t, /* @__PURE__ */ new Set()))) return !1;
		let p = n.workers.find((e) => e.company !== null && !a.has(e.id) && n.workers.some((t) => t.id !== e.id && a.has(t.id) && t.company === e.company && t.slot === e.slot));
		if (p) {
			if (i.length >= (t.limit ?? 3) || p.role !== r || !Te(n, p)) return !1;
			let e = {
				company: p.company,
				slot: p.slot,
				union: p.union,
				committed: p.committed
			};
			p.company = null, p.slot = -1;
			let o = n.companies.filter((e) => e.active && (t.company === void 0 || e.uid === t.company) && (t.mode !== "own" || e.owner === t.actor) && (t.mode !== "external" || ["state", "capital"].includes(e.owner))).flatMap((e) => W(e).map((t, r) => ({
				c: e,
				slot: r,
				occupied: A(n, e).some((e) => e.slot === r)
			}))).sort((e, t) => Number(e.occupied) - Number(t.occupied));
			for (let { c: r, slot: c, occupied: l } of o) if (!(l && i.length + 2 > (t.limit ?? 3)) && it(n, {
				...t,
				moves: i
			}, p, r, c, !0)) {
				if (a.add(p.id), Object.assign(p, {
					company: r.uid,
					slot: c,
					committed: !0
				}), i.push({
					worker: p.id,
					company: r.uid,
					slot: c,
					union: null
				}), s()) return Object.assign(p, e), !0;
				i.pop(), a.delete(p.id), p.company = null, p.slot = -1, p.committed = e.committed;
			}
			return Object.assign(p, e), !1;
		}
		let m = c.find((e) => !G(n, e));
		if (!m) return ot(n, {
			...t,
			moves: i
		});
		if (i.length >= (t.limit ?? 3)) return !1;
		let h = W(m).findIndex((e, t) => !e.optional && !A(n, m).some((e) => e.slot === t));
		if (h < 0) return !1;
		for (let e of l.filter((e) => Ee(n, e, m, h))) {
			let t = {
				company: e.company,
				slot: e.slot,
				union: e.union,
				committed: e.committed
			};
			if (a.add(e.id), Object.assign(e, {
				company: m.uid,
				slot: h,
				committed: !0
			}), i.push({
				worker: e.id,
				company: m.uid,
				slot: h,
				union: null
			}), s()) return Object.assign(e, t), !0;
			i.pop(), a.delete(e.id), Object.assign(e, t);
		}
		return !1;
	};
	return s() ? i : null;
}
function ct(e, t, n = !1) {
	let r = at(e, t), i = t.target ?? t.actor;
	if (!M(i) || (t.moves?.length ?? 0) >= (t.limit ?? 3)) return [];
	let a = [], o = /* @__PURE__ */ new Set(), s = (n) => {
		let r = st(e, {
			...t,
			moves: [...t.moves ?? [], n]
		});
		if (!r) return;
		let i = r.slice(t.moves?.length ?? 0), s = JSON.stringify(i);
		o.has(s) || (o.add(s), a.push(i));
	}, c = r.workers.filter((e) => e.role === i && Te(r, e) && (t.flag !== "unemployed" || e.company === null)), l = r.companies.filter((e) => e.active && (t.company === void 0 || e.uid === t.company) && (t.mode !== "own" || e.owner === t.actor) && (t.mode !== "external" || ["state", "capital"].includes(e.owner)));
	for (let e of c) {
		for (let i of l) for (let o = 0; o < W(i).length; o += 1) if ((e.company !== i.uid || e.slot !== o) && it(r, t, e, i, o) && s({
			worker: e.id,
			company: i.uid,
			slot: o,
			union: null
		}), n && a.length) return a;
		if (i === "working" && e.skill !== "any" && !r.workers.some((t) => t.union === e.skill) && s({
			worker: e.id,
			company: null,
			slot: -1,
			union: e.skill
		}), n && a.length) return a;
	}
	return a;
}
//#endregion
//#region src/games/hegemony/automa.ts
var lt = (e, t) => C.desiredPolicies[e][t], ut = (e, t) => Math.abs("ABC".indexOf(e) - "ABC".indexOf(t));
function dt(e, t, n, r) {
	return ut(r, lt(t, n)) < ut(e.policies[n], lt(t, n));
}
function ft(e, t) {
	let n = e.classes[t];
	n.aiDeck.length || n.aiDeck.push(...I(e, n.aiDiscard.splice(0)));
	let r = n.aiDeck.shift();
	return n.aiDiscard.push(r), C.cards.find((e) => e.id === r);
}
function pt(e, t, n) {
	let r = e.classes[t];
	r.aiDeck.length < n && r.aiDiscard.length && r.aiDeck.push(...I(e, r.aiDiscard.splice(0)));
	let i = 0;
	for (let e = 0; e < n; e += 1) {
		let e = r.aiDeck.shift();
		C.cards.find((t) => t.id === e).influence && (i += 1), r.aiDeck.push(e);
	}
	return i;
}
function mt(e, t, n, r = !1) {
	let i = e.findIndex((e) => e.includes(t));
	if (i < 0) return;
	e[i] = e[i].filter((e) => e !== t);
	let a = Math.max(0, i + n);
	for (; e.length <= a;) e.push([]);
	if (e[a].push(t), r) for (let t = e.length - 1; t >= 0; --t) e[t].length || e.splice(t, 1);
}
var ht = (e) => [...e].reverse().flat();
function gt(e, t) {
	for (let n of e.roles.filter((t) => e.classes[t].automa === "advanced")) {
		let r = e.classes[n];
		n === "working" && (e.demonstration ? r.actionRows = r.actionRows.map((e) => e.filter((e) => e !== "demonstration")) : t.demonstration && !r.actionRows.some((e) => e.includes("demonstration")) && (r.actionRows[0] ??= [], r.actionRows[0].push("demonstration")), e.companies.filter((e) => e.strike).length >= 7 ? r.actionRows = r.actionRows.map((e) => e.filter((e) => e !== "strike")) : e.round !== t.round && !r.actionRows.some((e) => e.includes("strike")) && (r.actionRows[0] ??= [], r.actionRows[0].push("strike")));
		for (let i = 0; i < 7; i += 1) {
			if (e.round === 5 && i === 6) continue;
			let a = e.bills.some((e) => e.policy === i), o = e.election?.bill.policy === i || e.jobs.some((e) => [
				"immediate",
				"pollDecision",
				"startElection"
			].includes(e.kind) && e.policy === i);
			a && !o && !r.policyAside.includes(i) && (r.policyRows = r.policyRows.map((e) => e.filter((e) => e !== i)), r.policyAside.push(i));
			let s = t.bills.some((e) => e.policy === i) && !a && !t.election && !e.election;
			if (!a && (t.policies[i] !== e.policies[i] || s && r.policyAside.includes(i))) {
				r.policyRows = r.policyRows.map((e) => e.filter((e) => e !== i)), r.policyAside = r.policyAside.filter((e) => e !== i);
				let t = ut(e.policies[i], lt(n, i));
				if (!t) r.policyAside.push(i);
				else {
					for (; r.policyRows.length < t;) r.policyRows.push([]);
					r.policyRows[t - 1].push(i);
				}
			}
		}
	}
}
function q(e, t, n) {
	let r = t;
	for (let e of n) {
		let t = Math.max(...r.map(e));
		if (r = r.filter((n) => e(n) === t), r.length <= 1) break;
	}
	return r.length ? r[_e(e, r.length)] : void 0;
}
var _t = (e) => e === "capital" ? [
	"food",
	"luxury",
	"influence",
	"health",
	"education"
] : [
	"health",
	"education",
	"food",
	"luxury",
	"influence"
];
function vt(e, t) {
	return ["health", "education"].includes(t) && !j(e, "state").some((n) => O(n).resource === t && G(e, n)) ? 1 : 0;
}
function yt(e, t, n, r = !1) {
	let i = r ? [
		"health",
		"education",
		"food",
		"influence",
		"luxury"
	] : _t(t), a = ["health", "education"].includes(n) ? Math.max(i.indexOf("health"), i.indexOf("education")) : i.indexOf(n), o = ["health", "education"].includes(n) ? K(e, "state", n).price * (r ? -1 : 1) : 0;
	return 10 * (i.length - a) + 2 * vt(e, n) + o / 10;
}
function bt(e, t, n) {
	let r = O(t).resource, i = e.workers.filter((t) => t.role === "working" && t.company !== null && O(k(e, t.company)).resource === r).length;
	return Number(!e.workers.some((e) => e.union === r) && i < 4 && i + n >= 4);
}
function xt(e, t) {
	if (M(t)) for (let n of e.workers.filter((n) => n.role === t && n.skill !== "any" && n.company !== null && !n.committed && W(k(e, n.company))[n.slot].skill === "any")) {
		let r = e.workers.find((e) => e.role === t && e.skill === "any" && e.company === null && !e.union && !e.committed);
		r && (r.company = n.company, r.slot = n.slot, n.company = null, n.slot = -1);
	}
}
function St(e, t) {
	return e.companies.filter((n) => A(e, n).some((e) => e.role === t) && (t !== "middle" || n.owner !== t)).reduce((t, n) => t + Oe(e, n), 0);
}
function Ct(e, t) {
	return e.workers.filter((n) => n.role === "working" && n.company !== null && G(e, k(e, n.company)) && O(k(e, n.company)).resource === t).length;
}
function wt(e, t, n) {
	if (!M(t)) return [];
	let r = structuredClone(e);
	for (let e of r.workers) e.company !== null && !["capital", ...t === "working" ? ["middle"] : []].includes(k(r, e.company).owner) && (e.committed = !0);
	let i = [];
	for (let a of j(r, "state").filter((e) => !G(r, e))) for (let o of r.workers.filter((e) => e.role === t && Te(r, e))) for (let s = 0; s < W(a).length; s += 1) {
		let c = W(a)[s];
		if (c.role !== "either" && c.role !== t || c.skill !== "any" && c.skill !== o.skill || !it(r, {
			kind: "assign",
			actor: t
		}, o, a, s)) continue;
		let l = st(r, {
			kind: "assign",
			actor: t,
			company: a.uid,
			limit: n,
			moves: [{
				worker: o.id,
				company: a.uid,
				slot: s,
				union: null
			}]
		});
		if (!l || !l.some((t) => e.workers.find((e) => e.id === t.worker).company !== null)) continue;
		let u = at(e, {
			kind: "assign",
			actor: t,
			moves: l
		});
		De(u), !(St(u, t) < St(e, t) || t === "working" && T.some((t) => Ct(e, t) >= 4 && Ct(u, t) < 4)) && i.push(l);
	}
	return i;
}
function Tt(e, t, n) {
	let r = W(t).filter((e) => !e.optional);
	if (!n && r.some((e) => e.role === "either")) {
		let n = A(e, t)[0]?.role;
		if (n) return Tt(e, t, n);
		let r = e.demonstration ? "working" : "middle";
		return Tt(e, t, r) ?? Tt(e, t, r === "working" ? "middle" : "working");
	}
	let i = e.workers.filter((e) => e.company === null && !e.union && !e.committed && (!n || e.role === n)), a = [], o = [];
	for (let n of r.map((e, t) => t).sort((e, t) => Number(r[t].skill !== "any") - Number(r[e].skill !== "any"))) {
		if (A(e, t).some((e) => e.slot === n)) continue;
		let s = r[n], c = i.filter((e) => !a.includes(e) && (s.role === "either" || e.role === s.role) && (s.skill === "any" || e.skill === s.skill) && (s.role !== "either" || !a.length || a[0].role === e.role)).sort((e, t) => Number(e.skill !== "any") - Number(t.skill !== "any"))[0];
		if (!c) return null;
		a.push(c), o.push({
			worker: c.id,
			company: t.uid,
			slot: n,
			union: null
		});
	}
	return o;
}
function Et(e, t, n = 3, r = !1) {
	if (!M(t)) return [];
	let i = structuredClone(e), a = [];
	for (; a.length < n;) {
		let e = t === "working" ? T.flatMap((e) => {
			let n = i.workers.filter((n) => n.role === t && n.company !== null && O(k(i, n.company)).resource === e).length, r = i.workers.find((n) => n.role === t && n.skill === e && n.company === null && !n.union && !n.committed);
			return n >= 4 && r && !i.workers.some((t) => t.union === e) ? [[{
				worker: r.id,
				company: null,
				slot: -1,
				union: e
			}]] : [];
		}) : [], o = i.companies.filter((e) => e.active && !G(i, e)).flatMap((e) => {
			let r = Tt(i, e, t);
			return r?.length && r.length <= n - a.length ? [r] : [];
		});
		if (t === "working") for (let e of j(i, "middle").filter((e) => G(i, e) && O(e).helper && !A(i, e).some((e) => e.role === "working"))) {
			let n = W(e).at(-1), r = i.workers.find((e) => e.role === t && e.company === null && !e.union && !e.committed && (n.skill === "any" || e.skill === n.skill));
			r && o.push([{
				worker: r.id,
				company: e.uid,
				slot: W(e).length - 1,
				union: null
			}]);
		}
		r && o.push(...wt(i, t, n - a.length));
		let s = q(i, [...e, ...o], [
			(e) => Number(!!e[0].union),
			(e) => e.filter((e) => i.workers.find((t) => t.id === e.worker).company === null && !e.union).length,
			(e) => {
				let n = e[0].company === null ? null : k(i, e[0].company);
				return !n || t !== "working" ? 0 : bt(i, n, e.length);
			},
			(e) => e[0].company === null ? 0 : O(k(i, e[0].company)).wages[k(i, e[0].company).wage - 1] ?? 0,
			(e) => e[0].company === null ? 0 : Number(k(i, e[0].company).owner === "state"),
			(e) => e[0].company === null ? 0 : Number(k(i, e[0].company).owner === "capital"),
			(e) => e[0].company === null ? 0 : yt(i, t, O(k(i, e[0].company)).resource, !0)
		]);
		if (!s) break;
		for (let e of s) Object.assign(i.workers.find((t) => t.id === e.worker), {
			company: e.company,
			slot: e.slot,
			union: e.union,
			committed: !0
		}), a.push(e);
	}
	return a;
}
function Dt(e, t, n = !1) {
	if (!M(t)) return;
	let r = T.filter((n) => Ce(e, t, n) > 0), i = e.workers.filter((e) => e.role === t && e.company === null && !e.union), a = (n) => e.companies.filter((t) => t.active && !G(e, t) && O(t).resource === n).reduce((n, r) => n + W(r).filter((n, i) => !n.optional && (n.role === "either" || n.role === t) && !A(e, r).some((e) => e.slot === i)).length, 0), o = (t, n) => e.roles.filter((e) => !n || e === n).flatMap((t) => e.classes[t].market).map((e) => y.find((t) => t.id === e)).filter((e) => e.resource === t).reduce((e, t) => e + t.workers.length, 0);
	if (t === "working") {
		let n = r.map((n) => {
			let r = structuredClone(e), i = U(r, t, n), a = Et(r, t), o = at(r, {
				kind: "assign",
				actor: t,
				moves: a
			});
			return De(o), {
				resource: n,
				union: a.some((e) => e.worker === i.id && e.union === n),
				qualifies: Ct(e, n) < 4 && Ct(o, n) >= 4
			};
		}), s = n.filter((e) => e.union || !i.some((t) => t.skill === e.resource)), c = s.filter((e) => e.union);
		return c.length ? q(e, c, [(e) => -a(e.resource)])?.resource : q(e, s.length ? s : n, [
			(e) => Number(e.qualifies),
			(e) => a(e.resource),
			(e) => o(e.resource),
			(n) => yt(e, t, n.resource)
		])?.resource;
	}
	let s = r.filter((e) => !i.some((t) => t.skill === e)), c = s.length ? s : r;
	if (!n) {
		let n = c.filter((n) => j(e, t).filter((e) => O(e).resource === n).length < 2 && e.classes[t].market.some((e) => {
			let t = y.find((t) => t.id === e);
			return t.resource === n && t.workers.some((e) => e === "skill");
		}));
		if (n.length) return q(e, n, [
			(n) => {
				let r = structuredClone(e);
				return U(r, t, n), Number(e.classes[t].market.some((i) => y.find((e) => e.id === i).resource === n && !!Tt(r, {
					uid: -1,
					definition: i,
					owner: t,
					wage: N(e),
					active: !0,
					machinery: !1,
					strike: !1
				}, t)));
			},
			(n) => Number(!j(e, t).some((e) => O(e).resource === n)),
			(e) => -[
				"food",
				"education",
				"health",
				"luxury",
				"influence"
			].indexOf(e)
		]);
	}
	return q(e, c, [(e) => Number(a(e) > 0), (e) => Number(o(e, "capital") > 0)]);
}
function Ot(e, t, n = "", r = !1) {
	let i = [], a = P(e, t);
	for (let o of [
		"health",
		"education",
		"luxury"
	]) {
		let s = e.classes[t].personal[o], c = r || s >= a ? a : a - s, l = [
			"state",
			"capital",
			...e.roles.includes("middle") ? ["middle"] : [],
			...o === "luxury" ? ["foreign"] : []
		];
		for (let r of l) for (let a of l.filter((e) => e !== r)) {
			let s = (t) => t === "foreign" ? B(e, o) : e.classes[t].storage[o], l = Math.min(c, s(r));
			for (let u = l; u >= 0; --u) {
				if (s(a) < c - u) continue;
				let l = (r, i) => {
					if (r === t) return 0;
					let a = K(e, r, o), s = r === "state" && (n === "healthHalf" && o === "health" || n === "educationHalf" && o === "education") || n === "tourism" && e.policies[0] !== "C" && r !== "foreign" && o === "luxury";
					return Math.ceil(a.price * i * (s ? .5 : 1)) + (n === "importSubsidy" && e.policies[5] !== "C" ? 0 : a.tariff * i);
				}, d = l(r, u) + l(a, c - u);
				d <= F(e, t) && i.push({
					resource: o,
					cost: d,
					sources: [{
						source: r,
						amount: u
					}, {
						source: a,
						amount: c - u
					}].filter((e) => e.amount)
				});
			}
		}
	}
	return i;
}
function kt(e, t, n) {
	let r = e.workers.filter((e) => e.role === t && e.company === null && !e.union && e.skill === "any").length, i = P(e, t), a = structuredClone(e);
	return M(t) && U(a, t, "any"), q(e, n.some((e) => e.resource !== "health") && P(a, t) > i ? n.filter((e) => e.resource !== "health") : n, [
		(e) => Number(e.cost === 0),
		(e) => Number(r >= 3 && e.resource === "education"),
		(e) => -e.cost,
		(e) => (t === "working" ? [
			"health",
			"education",
			"luxury"
		] : [
			"education",
			"health",
			"luxury"
		]).length - (t === "working" ? [
			"health",
			"education",
			"luxury"
		] : [
			"education",
			"health",
			"luxury"
		]).indexOf(e.resource),
		(e) => -[
			"state",
			"foreign",
			"capital",
			"middle"
		].indexOf(e.sources[0].source)
	]);
}
function At(e, t, n, r = !1) {
	let i = e.classes[t].automa === "simple" ? n.policies.map((e) => e - 1) : ht(e.classes[t].policyRows), a = X(e, {
		kind: "propose",
		actor: t,
		flag: r ? "radical" : void 0
	});
	return i.flatMap((n) => a.filter((i) => i.policy === n && (r ? i.key.split(":")[2] === lt(t, n) : dt(e, t, n, i.key.split(":")[2])) && (e.round !== 5 || n !== 6)));
}
function jt(e, t, n, r, i = !1) {
	let a = e.classes[t].personal.influence - Number(!i);
	if (a < 0) return !1;
	let o = e.roles.filter((i) => i !== t && dt(e, i, n, r)), s = e.roles.filter((e) => e !== t && !o.includes(e));
	return a + o.reduce((t, n) => t + e.classes[n].personal.influence, 0) > s.reduce((t, n) => t + e.classes[n].personal.influence, 0) && (e.roles.length === 2 ? e.bag.filter((e) => e === t).length >= e.bag.filter((e) => e === s[0]).length : o.some((e) => e !== "state"));
}
function Mt(e, t, n, r = "") {
	return At(e, t, n, r === "radical").filter((n) => e.round !== 5 || n.policy !== 5 || (r !== "radical" || ut(e.policies[n.policy], n.key.split(":")[2]) === 1) && jt(e, t, n.policy, n.key.split(":")[2], r === "immediateFree"));
}
var Nt = {
	sell: "sellCompany",
	demonstration: "demonstration"
};
function Pt(e, t, n) {
	let r = (e, n = {}) => ({
		kind: e,
		actor: t,
		...n
	}), i = {
		accident: "Workplace Accident",
		fakeNews: "Fake News",
		highlight: "Highlight Social Issues",
		housing: "Affordable Housing",
		interestGroups: "Interest Groups",
		migration: "Migration",
		populationVotes: "Proletarians of the World, Unite!",
		employmentSubsidy: "Employment Subsidy",
		extraShift: "Extra Shift",
		health: "Health Crisis",
		education: "Higher Education Program",
		themePark: "New Theme Park",
		unemployment: "Unemployment Initiative Program",
		workVotes: "Voice of Middle Class Workers",
		bidRigging: "Bid Rigging",
		competitiveWages: "Competitive Wages",
		deal: "Foreign Partner",
		foreignRecruitment: "Foreign Recruitment",
		grants: "Business Grants",
		island: "Private Island",
		machines: "Technological Progress",
		offshore: "Offshore Companies",
		protectionism: "Trade Protectionism Lobby"
	};
	if (n.special === "votes") return [{
		kind: "gainVotes",
		actor: t,
		n: 3
	}, ...F(e, t) >= 15 ? [{
		kind: "payMoney",
		actor: t,
		n: 15
	}, {
		kind: "gainVotes",
		actor: t,
		n: 3
	}] : []];
	if (n.special === "fakeNews") return [r("automaFakeNews")];
	if (n.special === "highlight") return [r("automaHighlight")];
	if (n.special === "migration") return e.workers.filter((e) => e.role === t && e.company === null && !e.union).length >= 4 ? [r("removeWorkers", { limit: 2 }), r("gainMoney", { n: 10 })] : null;
	if (n.special === "housing") return F(e, t) >= 20 ? [r("payMoney", {
		n: 20,
		target: "capital"
	}), r("score", { n: 5 })] : null;
	if (n.special === "accident") {
		let n = q(e, e.roles.filter((e) => e !== t), [(n) => e.workers.filter((r) => r.role === t && r.company !== null && k(e, r.company).owner === n).length]);
		return n && e.workers.some((r) => r.role === t && r.company !== null && k(e, r.company).owner === n) ? [r("gainMoney", {
			source: n,
			n: 15
		})] : null;
	}
	if (n.special === "deal") return X(e, r("deal")).length ? [r("deal")] : null;
	if (n.special === "employmentSubsidy") {
		let n = j(e, t).filter((t) => A(e, t).some((e) => e.role === "working")).length;
		return n ? [
			r("gainMoney", {
				source: "state",
				n: 5 * n
			}),
			r("legitimacyGain", {
				target: t,
				n: 1
			}),
			r("overtime", {
				mode: "withHelper",
				optional: !0
			})
		] : null;
	}
	if (n.special === "unemployment" && t === "middle") return ct(e, r("assign", {
		target: "working",
		mode: "own",
		flag: "unemployed",
		limit: 3
	})).length ? [r("assign", {
		target: "working",
		mode: "own",
		flag: "unemployed",
		limit: 3,
		data: { statePerWorker: 5 }
	}), r("legitimacyGain", {
		target: t,
		n: 1
	})] : null;
	if (n.special === "machines" && e.round === 5 || n.actions[0] === "special" && e.classes[t].automa === "simple" && n.special === "bidRigging" && e.classes[t].storage.luxury < 3 || n.actions[0] === "special" && e.classes[t].automa === "simple" && n.special === "protectionism" && (e.policies[5] === "C" || !j(e, t).some((e) => O(e).resource === "food")) || n.special === "offshore" && e.classes[t].money < 150) return null;
	let a = i[n.special], o = b.find((n) => n.role === t && n.name === a && (n.expansion === "base" || e.config.actionExpansion));
	if (!o || !Fe(e, t, o.id)) return null;
	let s = Ie(e, t, o.id), c = s[0];
	return c && [
		"assign",
		"overtime",
		"sellState",
		"foreignRecruitment",
		"competitiveWages",
		"affordableHousing",
		"workplaceAccident",
		"deal",
		"technologyChoice"
	].includes(c.kind) && !X(e, c).some((e) => e.key !== "skip" && e.key !== "finish") ? null : s;
}
function Ft(e, t, n, r, i) {
	return {
		kind: "build",
		actor: t,
		resource: r,
		mode: "only",
		selected: i,
		data: { onlyUnemployed: !0 },
		discount: n === "buildDiscount" ? 10 : n === "storageBuild" && r !== "influence" ? 4 : 0,
		flag: n === "stateBuild" && e.policies[0] !== "C" ? "statePays" : n === "industrialSubsidy" && e.policies[0] !== "C" && ["food", "luxury"].includes(r) ? "half" : n === "landOpportunity" && e.policies[6] !== "A" ? "landOpportunity" : void 0
	};
}
function It(e, t, n) {
	let r = (e, r) => T.flatMap((i) => X(e, Ft(e, t, n, i, r)));
	return (n === "landOpportunity" && e.policies[6] !== "A" ? T.flatMap((t) => {
		if (!Ce(e, "middle", t)) return [];
		let n = structuredClone(e), i = U(n, "middle", t);
		return r(n, i.id).map((e) => ({
			...e,
			key: `${e.key}:${t}`
		}));
	}) : r(e)).filter((r) => {
		let i = y.find((e) => e.id === r.card), a = {
			uid: -1,
			definition: i.id,
			owner: t,
			wage: N(e),
			active: !0,
			machinery: !1,
			strike: !1
		}, o = structuredClone(e);
		n === "landOpportunity" && e.policies[6] !== "A" && U(o, "middle", r.key.split(":")[2]);
		let s = !!Tt(o, a, t === "middle" ? "middle" : void 0);
		return t === "middle" ? j(e, t).filter((e) => O(e).resource === i.resource).length < 2 && s : !(j(e, t).some((t) => O(t).resource === i.resource && !G(e, t)) && !s) && (e.classes[t].automa !== "simple" || s);
	});
}
function Lt(e, t, n, r, i) {
	let a = e.classes[t], o = (e, n = {}) => ({
		kind: e,
		actor: t,
		...n
	});
	if (r === "special") {
		let r = n.actions[0] === "special" ? void 0 : X(e, o("historicalBasic"))[0];
		return r ? Vt(t, r.card) : Pt(e, t, n);
	}
	if (r === "propose") {
		let r = Mt(e, t, n, i)[0];
		return r ? [o("automaPropose", {
			policy: r.policy,
			flag: r.key.split(":")[2],
			mode: i
		})] : null;
	}
	if (r === "assign") {
		if (a.automa === "simple" && xt(e, t), i === "farm" && e.workers.filter((e) => e.role === t && e.company === null && !e.union).length >= 3 && j(e, t).length < 2) return [{
			kind: "cooperativeFarm",
			actor: t
		}];
		let n = i === "signingBonus" && e.policies[1] !== "A", r = Et(e, t, i === "deregulation" && e.policies[1] !== "A" ? 90 : n ? 4 : 3, i === "deregulation" && e.policies[1] === "C");
		return r.length < 2 && !r.some((e) => e.union) ? a.automa === "simple" && en(e) ? [o("demonstration")] : null : [o("assign", {
			moves: r,
			limit: r.length,
			amount: n ? 4 : void 0
		})];
	}
	if (r === "buy") {
		let n = Ot(e, t, i);
		i === "unemploymentBenefits" && e.policies[3] !== "C" && (n = n.filter((e) => e.sources.every((e) => e.source === "state")));
		let r = kt(e, t, n);
		return r ? i === "personalConsumption" ? [o("automaManyBuy", { resource: r.resource })] : [...r.sources.map(({ source: e, amount: t }) => o("automaBuy", {
			resource: r.resource,
			source: e,
			n: t,
			mode: i
		})), ...r.sources.length === 1 ? [o("automaAdditionalBuy", {
			resource: r.resource,
			source: r.sources[0].source,
			mode: i
		})] : []] : null;
	}
	if (r === "build") {
		let r = q(e, It(e, t, i), [
			(n) => {
				let r = y.find((e) => e.id === n.card);
				return Number(!!Tt(e, {
					uid: -1,
					definition: r.id,
					owner: t,
					active: !0,
					wage: N(e),
					machinery: !1,
					strike: !1
				}, t === "middle" ? "middle" : void 0));
			},
			(n) => t === "middle" ? Number(!!y.find((e) => e.id === n.card).helper && e.workers.some((e) => e.role === "working" && e.company === null && !e.union)) : 0,
			(e) => Number(t === "middle" ? !y.find((t) => t.id === e.card).helper : !y.find((t) => t.id === e.card).workers.length),
			(n) => -j(e, t).filter((t) => G(e, t) && O(t).resource === n.resource).length,
			(n) => t === "capital" ? -bt(e, {
				uid: -1,
				definition: n.card,
				owner: t,
				active: !0,
				wage: N(e),
				machinery: !1,
				strike: !1
			}, y.find((e) => e.id === n.card).workers.length) : 0,
			(n) => yt(e, t, n.resource),
			(e) => y.find((t) => t.id === e.card).production
		]);
		return r ? [o("automaBuild", {
			card: r.card,
			mode: i,
			resource: i === "landOpportunity" ? r.key.split(":")[2] : void 0
		})] : t === "capital" && a.automa === "simple" ? Lt(e, t, n, "sell", i) : null;
	}
	if (r === "export") {
		if (X(e, o("export")).filter((e) => e.kind === "exportTrade").length < 2) return null;
		let n = [];
		return i === "dealFirst" && e.policies[5] !== "C" && X(e, o("deal")).length && n.push(o("deal")), (i === "foodExport" || i === "luxuryExport") && n.push(o("extraExport", {
			resource: i === "foodExport" ? "food" : "luxury",
			limit: i === "foodExport" ? 4 : 6,
			amount: i === "foodExport" ? 15 : 10,
			optional: !0
		})), n.push(o("export", { flag: i === "exportBonus" || i === "exportSubsidy" && t === "capital" ? "bonus" : i === "exportSubsidy" && e.policies[0] !== "C" ? "subsidy" : void 0 })), n;
	}
	if (r === "lobby" && (F(e, t) < 30 || a.automa === "simple" && a.personal.influence >= e.roles.filter((e) => e !== t).reduce((t, n) => t + e.classes[n].personal.influence, 0))) return null;
	if (r === "demonstration") return en(e) ? [o("demonstration")] : null;
	let s = Nt[r] ?? r, c = X(e, o(s)).filter((e) => e.key !== "finish" && e.key !== "skip");
	if (r === "strike") {
		let t = e.workers.filter((e) => e.union).length, n = c.filter((t) => t.company !== void 0 && (k(e, t.company).owner !== "state" || !["health", "education"].includes(O(k(e, t.company)).resource) || K(e, "state", O(k(e, t.company)).resource).price > 0));
		return e.policies[1] === "A" || e.policies[1] === "B" && t < 2 || n.length < 2 ? null : [o("strike", { limit: 2 + t })];
	}
	return r === "sell" ? c.filter((t) => !G(e, k(e, t.company)) && O(k(e, t.company)).cost >= 20).length ? [o("sellCompany", { flag: i === "exitDouble" ? "double" : void 0 })] : null : r === "lobby" ? Pe(t, "lobby") : c.length ? [o(s)] : null;
}
function Rt(e, t, n) {
	let r = structuredClone(e), i = [], a = (e) => {
		R(r, "state", e, t, !0), i.push({
			kind: "gainMoney",
			actor: t,
			source: "state",
			n: e
		}, {
			kind: "legitimacyGain",
			actor: "state",
			target: t,
			n: 1
		});
	};
	if (n === "income" && e.policies[1] !== "A" && a(e.workers.filter((n) => n.role === t && (t === "middle" ? n.company !== null && ["capital", "state"].includes(k(e, n.company).owner) : n.company !== null || n.union)).length * (t === "middle" ? 2 : 1)), n === "unemploymentBenefits" && e.policies[3] !== "C" && a(e.workers.filter((e) => e.role === t && e.company === null && !e.union).length * 5), n === "publicEducationOvertime" || n === "publicHealthOvertime") {
		let a = n === "publicEducationOvertime" ? "education" : "health", o = q(r, j(e, "state").filter((n) => G(e, n) && O(n).resource === a && A(e, n).some((e) => e.role === t)), [(e) => O(e).production]);
		o && (ke(r, k(r, o.uid)), i.push({
			kind: "produceCompany",
			actor: "state",
			company: o.uid
		}));
	}
	if (n === "specialization" && e.policies[6] !== "A" && M(t)) {
		let e = Dt(r, t, !0);
		e && (U(r, t, e), i.push({
			kind: "automaWorker",
			actor: t,
			resource: e
		}));
	}
	return {
		projected: r,
		jobs: i
	};
}
function zt(e, t, n) {
	let r = e.classes[t];
	n.actions.some((e) => e === "assign") && xt(e, t);
	let i = (e, t) => {
		t && mt(r.actionRows, e, t);
	};
	for (let a of n.actions) {
		let o = a === n.actions[0] ? n.bonus : "", s = Rt(e, t, o).projected;
		if (a === "propose") {
			let e = 0;
			for (let i of n.policies) {
				let a = i - 1;
				if (!At(s, t, n).some((e) => e.policy === a)) continue;
				let o = ut(s.policies[a], lt(t, a)) + Number(t === "working" && a === 1 || t === "capital" && a === 2);
				mt(r.policyRows, a, o), e += o;
			}
			i(e ? "propose" : "special", e || 1);
		} else if (a === "assign") {
			let e = o === "farm" && s.workers.filter((e) => e.role === t && e.company === null && !e.union).length >= 3 && j(s, t).length < 2, n = e ? [] : Et(s, t, o === "deregulation" && s.policies[1] !== "A" ? 90 : o === "signingBonus" && s.policies[1] !== "A" ? 4 : 3, o === "deregulation" && s.policies[1] === "C"), r = e ? 3 : n.filter((e) => e.company !== null).length, a = n.filter((e) => e.union).length;
			if (i(r >= 2 || a ? "assign" : "special", r >= 2 || a ? (r >= 2 ? r : 0) + 2 * a : 1), t === "working") {
				let e = s.workers.filter((e) => e.role === t && e.company === null && !e.union).length, n = s.companies.filter((e) => e.active).reduce((e, t) => e + W(t).filter((e, n) => e.role !== "middle" && !A(s, t).some((e) => e.slot === n)).length, 0);
				i("demonstration", Math.max(0, e - n));
			}
		} else if (a === "buy") {
			let n = Ot(s, t, o, !0).filter((e) => o !== "unemploymentBenefits" || s.policies[3] === "C" || e.sources.every((e) => e.source === "state"));
			n.length || i("special", 1);
			for (let r of [
				"health",
				"education",
				"luxury"
			]) {
				let a = Math.max(0, Math.min(...n.filter((e) => e.resource === r).map((e) => e.cost)) - (F(s, t) - F(e, t)));
				Number.isFinite(a) && i("buy", a === 0 ? 3 : a <= 6 * P(s, t) ? 2 : 1);
			}
		} else if (a === "build") {
			let e = 0;
			for (let n of It(s, t, o)) {
				let r = y.find((e) => e.id === n.card);
				Tt(s, {
					uid: -1,
					definition: r.id,
					owner: t,
					active: !0,
					wage: N(s),
					machinery: !1,
					strike: !1
				}, t === "middle" ? "middle" : void 0) && (e += Math.floor((6 - s.round) / 2) + Number(!j(s, t).some((e) => G(s, e) && O(e).resource === r.resource)) * (t === "middle" ? 2 : 1), t === "middle" && r.helper && s.workers.some((e) => e.role === "working" && e.company === null && !e.union) && (e += 2));
			}
			t === "capital" && s.demonstration && (e += 3), t === "middle" && [
				0,
				1,
				2,
				3,
				4,
				5,
				5,
				6,
				6,
				7,
				7
			][r.prosperity] >= j(s, t).filter((e) => G(s, e) && A(s, e).length === W(e).length).length && (e += 2), i("build", e), e <= 1 && i("special", 1), t === "capital" && i("sell", j(s, t).filter((e) => !G(s, e) && O(e).cost >= 20).reduce((e, t) => e + Math.floor(O(t).cost / 10), 0));
		} else if (a === "export") {
			let e = X(s, {
				kind: "export",
				actor: t
			}).filter((e) => e.kind === "exportTrade").length;
			i(e >= 2 ? "export" : "special", e >= 2 ? e + Number(t === "middle" && r.money <= 15) : 1);
		} else if (a === "strike") {
			let e = X(s, {
				kind: "strike",
				actor: t
			}).filter((e) => e.company && k(s, e.company).wage === N(s) && (k(s, e.company).owner !== "state" || !["health", "education"].includes(O(k(s, e.company)).resource) || K(s, "state", O(k(s, e.company)).resource).price > 0)).length;
			s.policies[1] === "C" && (i("strike", Math.floor(e / 2)), mt(r.policyRows, 1, 1)), s.policies[1] === "B" && s.workers.filter((e) => e.union).length >= 2 && i("strike", Math.floor(e / 3));
		} else if (a === "lobby") {
			let e = s.roles.filter((e) => e !== t).reduce((e, t) => e + s.classes[t].personal.influence + j(s, t).filter((e) => G(s, e) && O(e).resource === "influence").reduce((e, t) => e + O(t).production, 0) + (t === "working" ? s.workers.filter((e) => e.union).length : 0), 0), n = r.personal.influence + j(s, t).filter((e) => G(s, e) && O(e).resource === "influence").reduce((e, t) => e + O(t).production, 0);
			i(s.bills.length && e > n ? "lobby" : "special", s.bills.length && e > n ? e - n : 1);
		} else a === "special" && Pt(s, t, n) && (n.special === "machines" ? (i("special", j(s, t).filter((e) => O(e).machineryBonus > 0 && !e.machinery).length), s.round <= 4 && i("special", Math.floor((6 - s.round) / 2))) : n.special === "offshore" ? i("special", Math.floor(r.money / 100) + (s.policies[2] === "A" ? 2 : +(s.policies[2] === "B"))) : n.special === "bidRigging" ? i("special", Math.floor(r.storage.luxury / 3) + Number(!r.personal.influence)) : n.special === "protectionism" ? i("special", j(s, t).filter((e) => O(e).resource === "food" || s.policies[5] === "A" && O(e).resource === "luxury").length) : n.special === "migration" ? i("special", s.workers.filter((e) => e.role === t && e.company === null && !e.union).length) : i("special", 1));
	}
	r.actionRows = r.actionRows.filter((e) => e.length), r.policyRows = r.policyRows.filter((e) => e.length);
}
function Bt(e, t) {
	let n = e.classes[t];
	if (!n.benefits.money && !n.benefits.votes && !T.some((e) => n.benefits[e])) return;
	for (let r of T) {
		let i = n.benefits[r];
		n.benefits[r] = 0, V(e, t, r, i);
	}
	n.money += n.benefits.money, n.benefits.money = 0;
	let r = n.benefits.votes;
	n.benefits.votes = 0, H(e, t, r), L(e, "state", 1);
}
function Vt(e, t) {
	let n = pe.cards.find((e) => e.slot === t), r = n.trigger.includes("2influence") ? 2 : +!!n.trigger.includes("1influence");
	return [...r ? [{
		kind: "spendInfluence",
		actor: e,
		n: r
	}] : [], {
		kind: "applyHistorical",
		actor: e,
		card: t
	}];
}
function Ht(e) {
	let t = e.turnRole, n = e.classes[t];
	if (n.automa === "off") return;
	if (e.mainDone) {
		Y(e, {
			kind: "endTurn",
			actor: t
		});
		return;
	}
	Bt(e, t), n.loans && (t !== "capital" || n.capital >= 100) && ye(e, t), (t === "capital" || t === "middle") && (e.roundEffects.allPricesLocked || (e.roundEffects.goodsPricesLocked || (n.prices.food = e.policies[5] === "A" ? 15 : 12), !e.roundEffects.goodsPricesLocked && !e.roundEffects.luxuryPricesLocked && (n.prices.luxury = e.policies[5] === "A" ? 10 : 8), n.prices.health = e.policies[3] === "C" ? 10 : 8, n.prices.education = e.policies[4] === "C" ? 10 : 8), t === "middle" && j(e, t).filter((e) => e.strike).forEach((e) => {
		e.wage = 3;
	}));
	let r = ft(e, t);
	n.aiCard = r.id, e.effect = {
		amount: 0,
		target: null,
		card: null
	}, n.automa === "advanced" && zt(e, t, r);
	let i = n.automa === "simple" ? [...r.actions, "special"] : ht(n.actionRows).slice(0, 2), a = null;
	for (let o of i) {
		let i = o === r.actions[0] ? r.bonus : "", s = Rt(e, t, i);
		if (a = Lt(s.projected, t, r, o, i), a && s.jobs.length && (a = [...s.jobs, {
			kind: "automaResume",
			actor: t,
			card: r.id,
			mode: o,
			flag: i
		}]), a) {
			n.automa === "simple" && o === "assign" && xt(e, t), e.cursor = s.projected.cursor, n.automa === "advanced" && mt(n.actionRows, o, -2, !0);
			break;
		}
	}
	e.mainDone = !0, Y(e, ...a ?? [{
		kind: "gainVotes",
		actor: t,
		n: 3
	}], {
		kind: "endTurn",
		actor: t
	}), ve(e, g("games.hegemony.messages.m001", { p1: r.number }), t);
}
function Ut(e) {
	let t = e.jobs[0], n = t.actor;
	if (t.kind === "assign" && !t.moves?.length) {
		let r = ct(e, t), i = (t) => t[0].company === null ? null : k(e, t[0].company), a = n === "capital" ? q(e, r.filter((e) => !!i(e)), [
			(t) => Number(!j(e, n).some((n) => G(e, n) && O(n).resource === O(i(t)).resource)),
			(t) => -bt(e, i(t), t.length),
			(t) => {
				let r = O(i(t)).resource;
				return r === "influence" ? 100 : yt(e, n, r, !0);
			}
		]) : n === "middle" && t.target === "working" ? q(e, r.filter((e) => !!i(e)), [
			(t) => {
				let r = O(i(t)).resource;
				return Number(j(e, n).filter((t) => G(e, t) && O(t).resource === r).reduce((e, t) => e + O(t).production, 0) < xe(e, n, r));
			},
			(t) => Number(j(e, n).filter((e) => O(e).resource === O(i(t)).resource).length <= 1),
			(t) => -bt(e, i(t), t.length),
			(t) => O(i(t)).resource === "food" ? 100 : yt(e, n, O(i(t)).resource)
		]) : q(e, r, [
			(e) => Number(!!e[0].union),
			(e) => e.length,
			(t) => i(t) ? Oe(e, i(t)) : 0,
			(e) => Number(i(e)?.owner === "state"),
			(e) => Number(i(e)?.owner === "capital")
		]);
		a?.length && (t.moves = a);
	}
	let r = an(e, n), i;
	if (t.kind === "propose" && e.classes[n].automa !== "off") {
		let a = r.filter((r) => r.kind === "bill" && dt(e, n, r.policy, r.key.split(":")[2]) && (e.round !== 5 || r.policy !== 6) && (e.round !== 5 || r.policy !== 5 || t.flag !== "radical" && jt(e, n, r.policy, r.key.split(":")[2], t.flag === "free")));
		if (e.classes[n].automa === "advanced") i = ht(e.classes[n].policyRows).flatMap((e) => a.filter((t) => t.policy === e))[0];
		else {
			let t = e.classes[n], r = t.aiDeck.length + t.aiDiscard.length;
			for (let t = 0; t < r && !i; t += 1) i = ft(e, n).policies.flatMap((e) => a.filter((t) => t.policy === e - 1))[0];
		}
		if (!i) {
			e.jobs.shift();
			return;
		}
	} else if (t.kind === "immediate") i = r.find((r) => r.key === (t.flag !== "forbidden" && jt(e, n, t.policy, e.bills.find((e) => e.policy === t.policy).target, t.flag === "free") ? "voteNow" : "laterVote"));
	else if (t.kind === "electionSides") i = r.find((t) => t.kind === (dt(e, n, e.election.bill.policy, e.election.bill.target) ? "support" : "oppose"));
	else if (t.kind === "publicPressure") i = r.find((t) => t.kind === (e.election.bill.policy >= 1 && e.election.bill.policy <= 5 && !dt(e, "state", e.election.bill.policy, e.election.bill.target) ? "publicPressure" : "skipPerk"));
	else if (t.kind === "perkWage") i = q(e, r.filter((t) => t.amount === (k(e, t.company).owner === n ? -1 : 1)), [(t) => {
		let n = k(e, t.company);
		return Math.abs(O(n).wages[n.wage + t.amount - 1] - O(n).wages[n.wage - 1]);
	}]);
	else if (t.kind === "assign") i = r.find((e) => e.key === "finish") ?? r.find((e) => e.kind === "assignmentPlan") ?? r.find((e) => e.key === "skip");
	else if (t.kind === "newSkill" || t.kind === "educate" && t.selected !== void 0) {
		let a = Dt(e, t.target ?? n);
		i = r.find((e) => e.resource === a);
	} else i = t.kind === "educate" ? q(e, r.filter((e) => e.worker !== void 0), [(t) => Number(e.workers.find((e) => e.id === t.worker).company === null), (t) => Number(e.workers.find((e) => e.id === t.worker).skill === "any")]) : t.kind === "strike" ? q(e, r.filter((t) => t.company !== void 0 && (k(e, t.company).owner !== "state" || !["health", "education"].includes(O(k(e, t.company)).resource) || K(e, "state", O(k(e, t.company)).resource).price > 0)), [
		(t) => Number(k(e, t.company).machinery),
		(t) => {
			let n = k(e, t.company);
			return Number(j(e, n.owner).filter((t) => G(e, t) && O(t).resource === O(n).resource).length === 1);
		},
		(t) => {
			let n = k(e, t.company);
			return O(n).wages[2] - O(n).wages[n.wage - 1];
		},
		(t) => -[
			"influence",
			"health",
			"education",
			"luxury",
			"food"
		].indexOf(O(k(e, t.company)).resource),
		(t) => O(k(e, t.company)).production
	]) ?? r.find((e) => e.key === "finish" || e.key === "skip") : t.kind === "machinery" ? q(e, r.filter((e) => e.company !== void 0), [
		(t) => Number(!j(e, n).some((n) => n.machinery && O(n).resource === O(k(e, t.company)).resource)),
		(t) => yt(e, n, O(k(e, t.company)).resource),
		(t) => O(k(e, t.company)).production
	]) ?? r.find((e) => e.key === "finish") : t.kind === "overtime" && n === "middle" ? q(e, r.filter((t) => t.company !== void 0 && O(k(e, t.company)).resource !== "influence"), [
		(t) => {
			let r = k(e, t.company), i = O(r);
			return Number(xe(e, n, i.resource) - e.classes[n].storage[i.resource] >= i.production + (A(e, r).some((e) => e.role === "working") ? i.helper?.bonus ?? 0 : 0));
		},
		(t) => Number(A(e, k(e, t.company)).filter((e) => e.role === "middle").length === 2),
		(t) => Number(A(e, k(e, t.company)).some((e) => e.role === "working" && !e.committed)),
		(t) => O(k(e, t.company)).resource === "food" ? 100 : yt(e, n, O(k(e, t.company)).resource)
	]) ?? r.find((e) => e.key === "finish" || e.key === "skip") : t.kind === "marketRefresh" ? r.find((t) => t.card && (n === "capital" || j(e, n).some((e) => O(e).resource === y.find((e) => e.id === t.card).resource))) ?? r.find((e) => e.key === "finish") : t.kind === "hire" ? q(e, r.filter((e) => e.kind === "hireWorker"), [(t) => Number(e.workers.find((e) => e.id === t.worker).role === (e.demonstration ? "working" : "middle")), (t) => Number(e.workers.find((e) => e.id === t.worker).skill === "any")]) ?? r.find((e) => e.key === "finish") : t.kind === "wages" || t.kind === "prices" ? r.find((e) => e.key === "finish") : t.kind === "setBuildWage" ? r.find((t) => t.amount === N(e)) ?? r.find((e) => e.key === "skip") : t.kind === "food" ? q(e, r, [
		(t) => {
			let r = t.key.split(":")[1], i = K(e, r, "food");
			return r === n ? 0 : -(i.price + i.tariff);
		},
		(e) => e.amount,
		(e) => -(n === "middle" ? [
			"middle",
			"state",
			"foreign",
			"capital"
		] : [
			"foreign",
			"state",
			"capital",
			"middle"
		]).indexOf(e.key.split(":")[1])
	]) : t.kind === "sellCompany" ? q(e, r.filter((t) => t.company && !G(e, k(e, t.company))), [
		(t) => O(k(e, t.company)).cost,
		(t) => Number(e.workers.filter((n) => n.role === "working" && n.company !== null && O(k(e, n.company)).resource === O(k(e, t.company)).resource).length + O(k(e, t.company)).workers.length >= 4),
		(t) => -e.workers.filter((n) => n.company === null && !n.union && (n.skill === "any" || n.skill === O(k(e, t.company)).resource)).length
	]) : t.kind === "deal" ? q(e, r, [(e) => Number(e.key.endsWith(":free")), (t) => ue.find((n) => n.id === e.business[t.amount]).cost]) : t.kind === "buy" ? r.filter((e) => e.kind === "purchase").sort((e, t) => t.amount - e.amount)[0] ?? r.find((e) => e.key === "finish") : t.kind === "bondBuy" ? pt(e, n, 1) ? r.filter((e) => e.amount).at(-1) : r[0] : t.kind === "demonstrationPenalty" ? q(e, r.filter((e) => e.kind === "demo"), [(e) => -[
		"capital",
		"middle",
		"state"
	].indexOf(e.role), (e) => e.amount]) ?? r.find((e) => e.key === "finish") : t.kind === "removeWorkers" ? q(e, r.filter((e) => e.worker), [(t) => Number(e.workers.find((e) => e.id === t.worker).skill === "any")]) ?? r.find((e) => e.key === "skip" || e.key === "finish") : q(e, r.filter((e) => ![
		"cancel",
		"backWorker",
		"finish",
		"skip"
	].includes(e.key)), [(e) => e.score]) ?? r.find((e) => e.key === "finish" || e.key === "skip");
	i ??= r.find((e) => e.key === "finish" || e.key === "skip"), i ? on(e, i) : [
		"newSkill",
		"educate",
		"overtime",
		"strike"
	].includes(t.kind) && e.jobs.shift();
}
function Wt(e) {
	let t = e.election, n = [];
	for (let r of [!0, !1]) {
		let i = e.roles.filter((n) => e.classes[n].automa !== "off" && t.sides[n] === r);
		if (!i.length) continue;
		let a = e.roles.filter((e) => t.sides[e] === r), o = e.roles.filter((e) => t.sides[e] !== r), s = t.cubes.filter((e) => a.includes(e)).length + a.reduce((e, n) => e + (t.prepaid[n] ?? 0), 0), c = t.cubes.filter((e) => o.includes(e)).length + o.reduce((e, n) => e + (t.prepaid[n] ?? 0), 0), l = Math.max(0, c - s + Number(!r)), u = i.reduce((t, n) => t + e.classes[n].personal.influence, 0), d = a.reduce((t, n) => t + e.classes[n].personal.influence, 0), f = o.reduce((t, n) => t + e.classes[n].personal.influence, 0), p = i[_e(e, i.length)], m = 0;
		if (e.round === 5 && e.phase === "elections" && e.bills.filter((e) => !e.protected).length === 1) m = u;
		else if (u && d >= l) {
			if (l === 0) {
				let t = Math.max(0, s - c + Number(r));
				f >= t && f && (m = pt(e, p, Math.min(u, f - t + 1)));
			} else a.length === i.length || d === u ? m = f ? d === l ? pt(e, p, 1) ? u : 0 : l + pt(e, p, Math.min(u - l, f)) : l : f ? d > l && (m = Math.max(0, l - 1) + pt(e, p, 1)) : m = l;
		}
		n.push({
			roles: i,
			n: Math.min(m, u)
		});
	}
	for (let r of n) for (r.roles.forEach((e) => {
		t.spending[e] = 0;
	}); r.n > 0;) {
		let n = q(e, r.roles.filter((n) => (t.spending[n] ?? 0) < e.classes[n].personal.influence), [(e) => -(t.spending[e] ?? 0), (t) => e.classes[t].personal.influence]);
		t.spending[n] = (t.spending[n] ?? 0) + 1, --r.n;
	}
}
function Gt(e, t) {
	let n = t.actor, r = e.classes[n];
	switch (t.kind) {
		case "automaFakeNews": {
			let t = [];
			for (let n = 0; n < 6 && e.bag.length; n += 1) t.push(e.bag.splice(_e(e, e.bag.length), 1)[0]);
			return e.bag.push(...t.filter((e) => e === n)), !0;
		}
		case "automaHighlight": {
			let t = Math.min(3, e.classes.state.storage.influence, Math.floor(F(e, n) / 5));
			return t && (Ae(e, n, "state", "influence", t, { discount: .5 }), z(e, n, 1)), H(e, n, 2 * (3 - t)), !0;
		}
		case "automaWorker": return M(n) && U(e, n, t.resource), !0;
		case "automaResume": return Y(e, ...Lt(e, n, C.cards.find((e) => e.id === t.card), t.mode, t.flag ?? "") ?? [{
			kind: "gainVotes",
			actor: n,
			n: 3
		}]), !0;
		case "automaTurnStart": return Ht(e), !0;
		case "automaFreeEnd": {
			let t = X(e, {
				kind: "freeExtensions",
				actor: n
			})[0];
			if (t) return Y(e, ...Vt(n, t.card), {
				kind: "automaFreeEnd",
				actor: n
			}), !0;
			if (M(n)) for (let t of [
				"luxury",
				"education",
				"health"
			]) for (; r.personal[t] >= P(e, n);) r.personal[t] -= P(e, n), be(e, n), t === "health" && (L(e, n, 2), U(e, n, "any")), t === "education" && Y(e, {
				kind: "educate",
				actor: n,
				optional: !0
			});
			return !0;
		}
		case "automaPrep":
			e.round === 5 && (r.policyRows = r.policyRows.map((e) => e.filter((e) => e !== 6)), r.policyAside = r.policyAside.filter((e) => e !== 6));
			for (let t of [...r.policyAside].sort()) {
				let i = ut(e.policies[t], lt(n, t));
				if (i) {
					for (r.policyAside = r.policyAside.filter((e) => e !== t); r.policyRows.length < i;) r.policyRows.push([]);
					r.policyRows[i - 1].push(t);
				}
			}
			return !0;
		case "automaStrike":
			if (e.classes.capital.automa !== "off") for (let t of j(e, "capital").filter((e) => e.strike)) pt(e, "capital", t.machinery || j(e, "capital").filter((n) => G(e, n) && O(n).resource === O(t).resource).length === 1 ? 2 : 1) && (t.wage = 3);
			return !0;
		case "automaPropose": return e.bills.push({
			role: n,
			policy: t.policy,
			target: t.flag,
			protected: !1
		}), Y(e, {
			kind: "immediate",
			actor: n,
			policy: t.policy,
			flag: t.mode === "immediateFree" ? "free" : t.mode === "radical" && ut(e.policies[t.policy], t.flag) > 1 ? "forbidden" : void 0
		}), t.mode === "billVotes" && H(e, n, 2), t.mode === "bill2" && (n === "working" || F(e, n) >= 25) && e.jobs.splice(1, 0, {
			kind: "automaSecondBill",
			actor: n,
			card: r.aiCard,
			policy: t.policy
		}), !0;
		case "automaSecondBill": {
			let r = Mt(e, n, C.cards.find((e) => e.id === t.card)).find((e) => e.policy !== t.policy);
			return r && (n === "working" || F(e, n) >= 25) && (n !== "working" && R(e, n, 25), Y(e, {
				kind: "automaPropose",
				actor: n,
				policy: r.policy,
				flag: r.key.split(":")[2]
			})), !0;
		}
		case "automaBuy": {
			let r = t.source === "state" && (t.mode === "healthHalf" && t.resource === "health" || t.mode === "educationHalf" && t.resource === "education") || t.mode === "tourism" && e.policies[0] !== "C" && t.resource === "luxury" && t.source !== "foreign" && t.source !== n, i = `automaBuyBenefit:${e.turn}:${n}`;
			return r && !e.roundEffects[i] && (z(e, n, 1), e.roundEffects[i] = !0), Y(e, {
				kind: "buy",
				actor: n,
				resource: t.resource,
				source: t.source,
				limit: t.n,
				count: 1,
				discount: t.source === "state" && (t.mode === "healthHalf" && t.resource === "health" || t.mode === "educationHalf" && t.resource === "education") || t.mode === "tourism" && e.policies[0] !== "C" && t.source !== "foreign" && t.source !== n && t.resource === "luxury" ? .5 : 1,
				flag: t.mode === "importSubsidy" && e.policies[5] !== "C" ? "noTariff" : t.mode === "tourism" && e.policies[0] !== "C" && t.source !== "foreign" && t.source !== n ? "subsidy" : void 0
			}), !0;
		}
		case "automaManyBuy": {
			let r = t.resource, i = [
				n,
				"state",
				"foreign",
				"capital",
				"middle"
			].find((i) => !t.used?.includes(i) && (i === "foreign" ? r === "luxury" && B(e, r) > 0 : e.roles.includes(i) && e.classes[i].storage[r] > 0) && (i === n || F(e, n) >= K(e, i, r).price + K(e, i, r).tariff));
			if (i) {
				let a = K(e, i, r);
				Y(e, {
					kind: "automaBuy",
					actor: n,
					source: i,
					resource: r,
					n: Math.min(P(e, n), i === "foreign" ? B(e, r) : e.classes[i].storage[r], i === n || !a.price ? Infinity : Math.floor(F(e, n) / (a.price + a.tariff)))
				}, {
					...t,
					used: [...t.used ?? [], i]
				});
			}
			return !0;
		}
		case "automaAdditionalBuy": {
			let r = t.resource, i = structuredClone(e);
			if (M(n) && U(i, n, "any"), r === "health" && P(i, n) > P(e, n)) return !0;
			let a = P(e, n), o = kt(e, n, Ot(e, n, t.mode, !0).filter((n) => n.resource === r && n.sources.length === 1 && n.sources[0].source !== t.source && n.sources[0].amount === a && (t.mode !== "unemploymentBenefits" || e.policies[3] === "C" || n.sources[0].source === "state")));
			return o && Y(e, {
				kind: "automaBuy",
				actor: n,
				resource: r,
				source: o.sources[0].source,
				n: a,
				mode: t.mode
			}), !0;
		}
		case "automaBuild": {
			let i = t.mode === "landOpportunity" && t.resource && e.policies[6] !== "A" ? U(e, "middle", t.resource) : null, a = y.find((e) => e.id === t.card), o = Ft(e, n, t.mode ?? "", a.resource, i?.id), s = X(e, o).find((e) => e.card === t.card);
			if (s && (Y(e, o), on(e, s), (o.flag === "statePays" || o.flag === "half") && z(e, n, 1), t.mode === "storageBuild" && a.resource !== "influence" && !r.expanded.includes(a.resource) && e.roles.reduce((t, n) => t + e.classes[n].expanded.length, 0) < 6 && r.expanded.push(a.resource), t.mode === "build2")) {
				let t = e.jobs.findIndex((e) => e.kind === "endTurn" && e.actor === n);
				e.jobs.splice(t < 0 ? e.jobs.length : t, 0, {
					kind: "automaSecondBuild",
					actor: n,
					card: r.aiCard
				}, {
					kind: "automaMarketAdd",
					actor: n,
					n: 2
				});
			}
			return !0;
		}
		case "automaSecondBuild": return Y(e, ...Lt(e, n, C.cards.find((e) => e.id === t.card), "build", "") ?? []), !0;
		case "automaMarketAdd":
			for (let e = 0; e < t.n && r.companyDeck.length; e += 1) r.market.push(r.companyDeck.shift());
			return !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/hegemony/extensions.ts
function Kt(e, t) {
	let n = t.actor, r = e.classes[n], i = [], a = (t = e.roles.filter((e) => e !== "state")) => t.map((e) => J(`target:${e}`, D[e], "target", { role: e })), o = (e, t, n) => Array.from({ length: Math.max(0, e) }, (e, r) => J(`${t}:${r + 1}`, n(r + 1), t, { amount: r + 1 }));
	switch (t.kind) {
		case "freeExtensions":
		case "historicalBasic": return qe(e, t);
		case "removeWorkers": return e.workers.filter((r) => r.role === n && !r.union && (r.company === null || t.flag === "any" && !e.workers.some((e) => e.role === n && e.company === null && !e.union))).map((e) => J(`removeWorker:${e.id}`, g("games.hegemony.messages.m105", { p1: e.id }), "removeWorker", {
			worker: e.id,
			score: e.skill === "any" ? 3 : 0
		}));
		case "workplaceAccident":
			for (let t of e.roles.filter((e) => e !== n)) for (let r of T) {
				let a = j(e, t).filter((t) => O(t).resource === r && A(e, t).some((e) => e.role === n)).length;
				a && i.push(J(`accident:${t}:${r}`, g("games.hegemony.messages.m106", {
					p1: D[t],
					p2: E[r],
					p3: a * 8
				}), "accident", {
					role: t,
					resource: r,
					amount: a * 8
				}));
			}
			return i;
		case "affordableHousing": return F(e, n) >= 20 && i.push(J("housing:capital:20:5", g("games.hegemony.messages.m107"), "housing", {
			role: "capital",
			amount: 20,
			score: 5
		})), e.roles.includes("middle") && F(e, n) >= 10 && i.push(J("housing:middle:10:3", g("games.hegemony.messages.m108"), "housing", {
			role: "middle",
			amount: 10,
			score: 3
		})), i;
		case "sellState": {
			let n = t.resource;
			return o(Math.min(t.limit, r.storage[n], e.roles.includes("state") ? xe(e, "state", n) - e.classes.state.storage[n] : Infinity), "sellState", (e) => g("games.hegemony.messages.m109", {
				p1: e,
				p2: E[n],
				p3: e * t.amount
			}));
		}
		case "extraExport": {
			let i = t.resource, a = t.flag === "publicPrice" ? K(e, "state", i).price : t.amount;
			return o(Math.min(t.limit, r.storage[i] + (n === "capital" && (i === "food" || i === "luxury") ? r.freeTrade[i] : 0)), "extraExport", (e) => g("games.hegemony.messages.m110", {
				p1: e,
				p2: E[i],
				p3: e * a
			}));
		}
		case "foreignRecruitment":
		case "chooseHire": return j(e, n).filter((t) => !G(e, t)).map((e) => J(`hireCompany:${e.uid}`, _(O(e).name), "hireCompany", { company: e.uid }));
		case "competitiveWages":
			for (let t of j(e, n).filter((t) => !G(e, t))) for (let n of j(e, "state").filter((n) => G(e, n) && O(t).resource === O(n).resource && O(t).workers.length === O(n).workers.length)) i.push(J(`competitive:${t.uid}:${n.uid}`, g("games.hegemony.messages.m096", {
				p1: _(O(n).name),
				p2: _(O(t).name)
			}), "competitive", {
				company: t.uid,
				amount: n.uid
			}));
			return i;
		case "investmentChoice": return [J("investment:market", g("games.hegemony.messages.m111", { p1: t.n }), "investment"), J("investment:search", g("games.hegemony.messages.m112", { p1: t.n }), "investment")];
		case "industrialization": return ["food", "luxury"].map((e) => J(`industrial:${e}`, E[e], "industrial", { resource: e }));
		case "technologyChoice": return F(e, n) >= 20 && i.push(J("technology:1:20", g("games.hegemony.messages.m113"), "technology", {
			amount: 20,
			score: 1
		})), F(e, n) >= 45 && j(e, n).filter((e) => O(e).machineryBonus > 0 && !e.machinery).length >= 2 && i.push(J("technology:2:45", g("games.hegemony.messages.m114"), "technology", {
			amount: 45,
			score: 2
		})), i;
		case "personalConsumption": return [J("consumption:many", g("games.hegemony.messages.m115"), "consumption"), J("consumption:double", g("games.hegemony.messages.m116"), "consumption")];
		case "growingStorage": return T.filter((e) => e !== "influence" && !r.expanded.includes(e)).map((e) => J(`growing:${e}`, E[e], "growing", { resource: e }));
		case "denySpeech":
		case "stealInfluence": return a(e.roles.filter((r) => r !== n && e.classes[r].personal.influence >= (t.kind === "denySpeech" ? 1 : 2) && !t.used?.includes(r) && (t.kind !== "denySpeech" || e.classes[r].legitimacy > 1)));
		case "protectPolicy": return e.policies.flatMap((t, n) => e.bills.some((e) => e.policy === n) || e.locked.includes(n) ? [] : [J(`protect:${n}`, g("games.hegemony.messages.m117", {
			p1: n + 1,
			p2: t
		}), "protect", { policy: n })]);
		case "removeBill":
		case "rapidResolution": return e.bills.filter((e) => e.role !== n && !e.protected).map((e) => J(`billTarget:${e.policy}`, g("games.hegemony.messages.m118", {
			p1: e.policy + 1,
			p2: e.target,
			p3: D[e.role]
		}), "billTarget", {
			policy: e.policy,
			role: e.role
		}));
		case "exportInsightChoice": return [J(`exportInsight:${e.exportCard}`, g("games.hegemony.messages.m119"), "exportInsight", { card: e.exportCard }), ...(t.ids ?? []).map((e) => J(`exportInsight:${e}`, g("games.hegemony.messages.m120", { p1: e }), "exportInsight", { card: e }))];
		case "publicCapacity": {
			let t = {
				A: 9,
				B: 6,
				C: 3
			}[e.policies[0]], n = e.companies.filter((e) => e.owner === "state"), r = n.filter((e) => e.active).length;
			if (r === Math.min(t, n.length)) return [J("finish", g("games.hegemony.messages.m121"))];
			let i = r < t, a = e.roles.includes("middle") ? [
				26800,
				27500,
				27600,
				27100,
				27200,
				27300,
				27e3,
				26900,
				27400
			] : [
				26800,
				26900,
				27e3,
				27100,
				27200,
				27300,
				18600,
				18700,
				18800
			], o = n.filter((e) => e.active !== i);
			return e.roles.includes("state") || (o = o.filter((e) => i ? a.indexOf(e.uid) < t : a.indexOf(e.uid) >= t)), o.map((e) => J(`public:${e.uid}:${i ? "open" : "close"}`, g("games.hegemony.messages.m124", {
				p1: g(i ? "games.hegemony.messages.m122" : "games.hegemony.messages.m123"),
				p2: _(O(e).name)
			}), "public", {
				company: e.uid,
				score: a.indexOf(e.uid) * (i ? -1 : 1)
			}));
		}
		case "demonstrationPenalty": {
			let n = e.roles.filter((e) => e !== "working").flatMap((n) => {
				let r = (n === "state" ? 9 : n === "capital" ? 12 : 8) - j(e, n).length, i = Number(t.data?.[n] ?? 0);
				return o(Math.min(t.n, Math.max(0, r - i)), `demo:${n}`, (e) => g("games.hegemony.messages.m125", {
					p1: D[n],
					p2: e
				})).map((e) => ({
					...e,
					kind: "demo",
					role: n
				}));
			});
			return n.length ? n : [J("finish", g("games.hegemony.messages.m126"))];
		}
		case "pollPropose": return X(e, {
			...t,
			kind: "propose"
		});
		case "pollDecision": return [J("poll:yes", g("games.hegemony.messages.m127"), "poll"), J("poll:no", g("games.hegemony.messages.m128"), "poll")];
		case "fakeNewsRemove": return (t.ids ?? []).flatMap((e, t) => [J(`fake:${t}`, g("games.hegemony.messages.m129", { p1: D[w[e]] }), "fake", {
			amount: t,
			score: w[e] === n ? -1 : 1
		})]).concat([J("fakeFinish", g("games.hegemony.messages.m130"))]);
		case "privatization": return j(e, "state").filter((t) => G(e, t) && F(e, "capital") >= O(t).cost && j(e, "capital").length < 12).map((e) => J(`privatize:${e.uid}`, _(O(e).name), "privatize", { company: e.uid }));
		case "nationalization": {
			let n = j(e, "capital").filter((t) => !G(e, t) && !t.machinery && (e.policies[0] !== "B" || F(e, "state") >= O(t).cost));
			return t.company === void 0 ? n.length ? j(e, "state").filter((t) => !G(e, t)).map((e) => J(`nationalPublic:${e.uid}`, _(O(e).name), "nationalPublic", { company: e.uid })) : [] : n.map((e) => J(`nationalPrivate:${e.uid}`, _(O(e).name), "nationalPrivate", { company: e.uid }));
		}
		case "foreignHealth": return o(Math.min(Math.floor(F(e, n) / 5), xe(e, n, "health") - r.storage.health), "foreignHealth", (e) => g("games.hegemony.messages.m131", {
			p1: e,
			p2: e * 5
		}));
		default: return [
			...Ve(e, t),
			...qe(e, t),
			...tt(e, t)
		];
	}
}
function qt(e, t, n) {
	let r = t.actor, i = e.classes[r], a = n.key.split(":");
	switch (n.kind) {
		case "removeWorker": {
			let r = e.workers.find((e) => e.id === n.worker);
			t.flag === "migration" && (i.money += r.skill === "any" ? 5 : 10), e.workers = e.workers.filter((e) => e.id !== r.id), t.counter = (t.counter ?? 0) + 1, t.counter >= (t.limit ?? 1) && e.jobs.shift(), De(e);
			return;
		}
		case "accident":
			R(e, n.role, n.amount, r, !0), e.jobs.shift();
			return;
		case "housing":
			R(e, r, n.amount, n.role), L(e, r, Number(a[3])), e.jobs.shift();
			return;
		case "sellState": {
			let a = t.resource, o = n.amount;
			i.storage[a] -= o, e.roles.includes("state") && V(e, "state", a, o, "storage"), R(e, "state", o * t.amount, r, !0), t.flag === "perkSale" && L(e, "state", 1), e.effect.amount += o, e.jobs.shift();
			return;
		}
		case "extraExport": {
			let a = t.resource, o = n.amount, s = o;
			if (r === "capital" && (a === "food" || a === "luxury")) {
				let e = Math.min(s, i.freeTrade[a]);
				i.freeTrade[a] -= e, s -= e;
			}
			i.storage[a] -= s;
			let c = o * (t.flag === "publicPrice" ? K(e, "state", a).price : t.amount);
			i.money += c, e.effect.amount += c, e.jobs.shift();
			return;
		}
		case "hireCompany":
			e.jobs.shift(), t.kind === "foreignRecruitment" ? (R(e, r, 10), Y(e, {
				kind: "recruitClass",
				actor: r,
				company: n.company
			})) : Y(e, {
				kind: "hire",
				actor: r,
				company: n.company,
				flag: "unemployed",
				data: t.data
			});
			return;
		case "competitive": {
			let t = k(e, n.company), r = k(e, n.amount);
			t.wage = 3, A(e, r).forEach((e) => {
				e.company = t.uid, e.committed = !0;
			}), e.jobs.shift(), De(e);
			return;
		}
		case "investment":
			e.jobs.shift(), Y(e, {
				kind: "build",
				actor: r,
				discount: a[1] === "search" ? -t.n : t.n,
				flag: a[1] === "search" ? "search" : void 0
			});
			return;
		case "industrial":
			e.jobs.shift(), Y(e, {
				kind: "build",
				actor: r,
				resource: n.resource,
				mode: "only",
				flag: "half"
			});
			return;
		case "technology":
			R(e, r, n.amount), e.jobs.shift(), Y(e, {
				kind: "machinery",
				actor: r,
				limit: Number(a[1])
			});
			return;
		case "consumption":
			e.jobs.shift(), Y(e, {
				kind: "buy",
				actor: r,
				count: a[1] === "many" ? 4 : 1,
				limit: P(e, r) * (a[1] === "many" ? 1 : 2)
			});
			return;
		case "growing":
			i.expanded.push(n.resource), e.jobs.shift(), Y(e, {
				kind: "build",
				actor: r,
				resource: n.resource,
				discount: 4,
				optional: !0
			});
			return;
		case "target":
			if (t.kind === "denySpeech" || t.kind === "stealInfluence") {
				let i = t.kind === "denySpeech" ? 1 : 2;
				e.classes[n.role].personal.influence -= i, V(e, r, "influence", i), t.kind === "denySpeech" && z(e, n.role, -1), t.used ??= [], t.used.push(n.role), t.used.length >= (t.n ?? 1) && e.jobs.shift();
				return;
			}
			break;
		case "protect":
			e.bills.push({
				role: r,
				policy: n.policy,
				target: e.policies[n.policy],
				protected: !0
			}), e.jobs.shift();
			return;
		case "billTarget":
			t.kind === "rapidResolution" ? (--i.personal.influence, e.jobs.shift(), Y(e, {
				kind: "startElection",
				actor: r,
				policy: n.policy,
				flag: "rapid"
			})) : (e.bills = e.bills.filter((e) => e.policy !== n.policy), e.jobs.shift(), Y(e, {
				kind: "propose",
				actor: r,
				optional: !0
			}, {
				kind: "propose",
				actor: n.role,
				optional: !0
			}));
			return;
		case "exportInsight":
			e.exportDiscard.push(...[e.exportCard, ...t.ids ?? []].filter((e) => e !== n.card)), e.exportCard = n.card, e.jobs.shift();
			return;
		case "public": {
			let t = k(e, n.company), r = a[2] === "open";
			if (t.active = r, r) {
				let n = e.roundEffects.publicFree ? 0 : e.roundEffects.publicHalf ? .5 : 1;
				R(e, "state", O(t).cost * n, void 0, !0), Y(e, {
					kind: "hire",
					actor: e.roles.includes("state") ? "state" : e.roles.includes("middle") ? "middle" : "working",
					company: t.uid,
					flag: "automatic"
				});
			} else {
				e.classes.state.money += O(t).cost, A(e, t).forEach((e) => {
					e.company = null, e.slot = -1, e.committed = !1;
				}), De(e);
				for (let t of T) e.classes.state.storage[t] = Math.min(e.classes.state.storage[t], xe(e, "state", t));
			}
			return;
		}
		case "demo":
			L(e, n.role, -n.amount), t.n -= n.amount, t.data ??= {}, t.data[n.role] = Number(t.data[n.role] ?? 0) + n.amount, t.n === 0 && (e.jobs.shift(), e.demonstration = !1, V(e, r, "influence", 1));
			return;
		case "bill":
			if (t.kind === "pollPropose") {
				e.bills.push({
					role: r,
					policy: n.policy,
					target: a[2],
					protected: !1
				});
				let t = [];
				for (let n = 0; n < 5 && e.bag.length; n += 1) t.push(w.indexOf(e.bag.splice(_e(e, e.bag.length), 1)[0]));
				e.jobs.shift(), Y(e, {
					kind: "pollDecision",
					actor: r,
					policy: n.policy,
					ids: t
				});
				return;
			}
			break;
		case "poll":
			e.jobs.shift(), a[1] === "yes" ? Y(e, {
				kind: "startElection",
				actor: r,
				policy: t.policy,
				ids: t.ids
			}) : e.bag.push(...(t.ids ?? []).map((e) => w[e]));
			return;
		case "fake":
			t.ids.splice(n.amount, 1), t.counter = (t.counter ?? 0) + 1, t.counter === 4 && (e.bag.push(...t.ids.map((e) => w[e])), e.jobs.shift());
			return;
		case "fakeFinish":
			e.bag.push(...(t.ids ?? []).map((e) => w[e])), e.jobs.shift();
			return;
		case "privatize": {
			let t = k(e, n.company);
			R(e, "capital", O(t).cost, "state"), t.owner = "capital", z(e, "capital", 1, !0), e.jobs.shift();
			return;
		}
		case "nationalPublic":
			t.company = n.company;
			return;
		case "nationalPrivate": {
			let i = k(e, t.company), a = k(e, n.company);
			e.companies = e.companies.filter((e) => e.uid !== a.uid), i.definition = a.definition, i.wage = a.wage, i.machinery = a.machinery, i.strike = a.strike, e.policies[0] === "B" && R(e, "state", O(a).cost, "capital"), e.jobs.shift(), Y(e, {
				kind: "hire",
				actor: r,
				company: i.uid,
				flag: "unemployed"
			});
			return;
		}
		case "foreignHealth":
			R(e, r, n.amount * 5), V(e, r, "health", n.amount, "storage"), e.jobs.shift();
			return;
	}
	if (!(Ue(e, t, n) || Ze(e, t, n) || nt(e, t, n))) throw Error(`Unhandled Hegemony choice: ${t.kind}/${n.kind}`);
}
function Jt(e, t) {
	return We(e, t);
}
function Yt(e, t) {
	if (e.config.hiddenAgendas) for (let n of e.roles) {
		let r = e.classes[n], i = r.automa === "off" ? r.agenda === null ? [] : [r.agenda] : r.agendas, a = j(e, n), o = a.filter((t) => G(e, t) && A(e, t).length === 2).length, s = new Set(e.workers.filter((t) => t.role === n && t.company !== null && k(e, t.company).owner !== n).map((e) => e.company)).size;
		for (let c of i) {
			if (r.agendaAchieved.includes(c)) continue;
			let i = de.find((e) => e.id === c);
			if (!(i.timing === "anytime" || i.timing === t || i.timing === "after-round-1" && e.round > 1 || i.timing === "before-round-4" && e.round < 4) || [21316, 21508].includes(c) && e.phase === "elections" && (e.election || e.bills.some((e) => !e.protected))) continue;
			let l = !1;
			switch (c) {
				case 21315:
					l = a.length >= 12 && a.filter((t) => G(e, t)).length >= 11;
					break;
				case 21316:
					l = e.policies.slice(0, 5).filter((e) => e === "C").length >= 3;
					break;
				case 21317:
					l = r.largestExport >= 240;
					break;
				case 21318:
					l = T.every((e) => a.filter((t) => O(t).resource === e).length >= 2);
					break;
				case 21319:
					l = r.capital >= 320;
					break;
				case 21400:
					l = r.eventsResolved >= 10;
					break;
				case 21401:
					l = !r.everLoan;
					break;
				case 21402:
					l = (fe.find((t) => t.id === e.politicalCard)?.policies.filter((t, n) => t === e.policies[n]).length ?? 0) >= 4;
					break;
				case 21403:
					l = r.money >= 150 && e.policies[3] === "A" && e.policies[4] === "A";
					break;
				case 21404:
					l = e.policies[0] === "A" && a.filter((t) => G(e, t)).length >= 6;
					break;
				case 21505:
					l = [
						"food",
						"luxury",
						"health",
						"education"
					].every((e) => r.storage[e] >= 8);
					break;
				case 21506:
					l = o >= 5;
					break;
				case 21507:
					l = o >= 8 && s >= 5;
					break;
				case 21508:
					l = e.policies.slice(0, 5).every((e) => e === "B");
					break;
				case 21509:
					l = !e.workers.some((e) => e.role === n && e.company === null && !e.union);
					break;
				case 21610:
					l = r.personal.influence >= 6;
					break;
				case 21611:
					l = e.workers.filter((e) => e.union).length >= 4;
					break;
				case 21612:
					l = e.billsPassed.working >= 3;
					break;
				case 21613:
					l = P(e, n) <= 7;
					break;
				case 21614: l = e.wagesEarned.working >= 240;
			}
			l && (r.agendaAchieved.push(c), r.automa === "off" && L(e, n, i.vp, g("games.hegemony.messages.m132", { p1: _(i.name) })));
		}
		t === "game-end" && r.automa !== "off" && L(e, n, Math.max(0, ...r.agendaAchieved.map((e) => de.find((t) => t.id === e).vp)), g("games.hegemony.messages.m133"));
	}
}
function Xt(e, t) {
	let n = t.actor, r = e.classes[n];
	switch (t.kind) {
		case "offshore": {
			let e = Math.floor(r.money / 2);
			r.money -= e, r.capital += e;
			return;
		}
		case "cooperativeFarm": {
			let t = e.nextId++;
			e.companies.push({
				uid: t,
				definition: 12300,
				owner: "working",
				wage: 1,
				active: !0,
				strike: !1,
				machinery: !1
			}), Y(e, {
				kind: "assign",
				actor: n,
				company: t,
				flag: "unemployed",
				limit: 3
			});
			return;
		}
		case "buyProduced": {
			let r = t.resource ?? T[Number(e.roundEffects.lastProductionResource)];
			Y(e, {
				...t,
				kind: "buy",
				resource: r,
				limit: Math.min(e.effect.amount, P(e, n)),
				count: 1
			});
			return;
		}
		case "proposeSecond": {
			let n = e.roundEffects.lastProposedPolicy === void 0 ? void 0 : Number(e.roundEffects.lastProposedPolicy);
			Y(e, {
				...t,
				kind: "propose",
				ids: n === void 0 ? [] : [n]
			});
			return;
		}
		case "fakeNews": {
			let t = [];
			for (let n = 0; n < 6 && e.bag.length; n += 1) t.push(w.indexOf(e.bag.splice(_e(e, e.bag.length), 1)[0]));
			Y(e, {
				kind: "fakeNewsRemove",
				actor: n,
				ids: t
			});
			return;
		}
		case "interestGroups": {
			let t = [], r = 0;
			for (; e.bag.length && r < 3;) {
				let i = e.bag.splice(_e(e, e.bag.length), 1)[0];
				i !== n && r < 3 && e.bag.filter((e) => e === n).length + t.filter((e) => e === n).length < 25 ? (t.push(n), r += 1) : t.push(i);
			}
			e.bag.push(...t);
			return;
		}
		case "exportInsight":
			Y(e, {
				kind: "exportInsightChoice",
				actor: n,
				ids: e.exportDeck.splice(0, t.n)
			});
			return;
		case "recruitClass":
			Y(e, {
				kind: "historicalChoice",
				actor: n,
				mode: "recruitClass",
				company: t.company
			});
			return;
		case "covidCases": {
			let t = Math.min(Math.ceil(P(e, n) / 2), e.classes.state.storage.health);
			e.classes.state.storage.health -= t, V(e, n, "health", t);
			return;
		}
		case "agendaReward": {
			let i = fe.find((t) => t.id === e.politicalCard)?.policies.filter((t, n) => t === e.policies[n]).length ?? 0;
			t.resource ? V(e, n, t.resource, i) : r.money += i * t.amount;
			return;
		}
		case "cardLegitimacy": {
			let n = b.find((e) => e.id === t.card), r = n.legitimacy, i = r.match(/^([a-z]+):\+1(?:\/(\d+))?/);
			if (!i) return;
			let a = i[1], o = t.amount ?? e.effect.amount;
			z(e, a, i[2] ? Math.floor(o / Number(i[2])) : r.includes("operational health company") ? o : 1, n.legitimacyKind === "token");
			return;
		}
		default:
			if (Ge(e, t) || Qe(e, t) || rt(e, t) || Gt(e, t)) return;
			throw Error(`Unhandled Hegemony effect: ${t.kind}`);
	}
}
//#endregion
//#region src/games/hegemony/choices.ts
function J(e, t, n = e, r = {}) {
	return {
		key: e,
		text: t,
		kind: n,
		score: 0,
		...r
	};
}
function Y(e, ...t) {
	e.jobs.unshift(...t);
}
var Zt = () => J("skip", g("games.hegemony.messages.m002")), Qt = () => J("finish", g("games.hegemony.messages.m003"));
function $t(e, t) {
	let n = t === "working" ? [
		"propose",
		"assign",
		"buy",
		"strike",
		"demonstration",
		"pressure"
	] : t === "capital" ? [
		"propose",
		"build",
		"sellCompany",
		"export",
		"deal",
		"lobby",
		"pressure"
	] : t === "middle" ? [
		"propose",
		"assign",
		"build",
		"sellCompany",
		"export",
		"buy",
		"overtime",
		"pressure"
	] : [
		"propose",
		"event",
		"export",
		"meet",
		"extraTax",
		"campaign"
	], r = {
		propose: g("games.hegemony.messages.m004"),
		assign: g("games.hegemony.messages.m005"),
		buy: g("games.hegemony.messages.m006"),
		strike: g("games.hegemony.messages.m007"),
		demonstration: g("games.hegemony.messages.m008"),
		pressure: g("games.hegemony.messages.m009"),
		build: g("games.hegemony.messages.m010"),
		sellCompany: g("games.hegemony.messages.m011"),
		export: g("games.hegemony.messages.m012"),
		deal: g("games.hegemony.messages.m013"),
		lobby: g("games.hegemony.messages.m014"),
		overtime: g("games.hegemony.messages.m015"),
		event: g("games.hegemony.messages.m016"),
		meet: g("games.hegemony.messages.m017"),
		extraTax: g("games.hegemony.messages.m018"),
		campaign: g("games.hegemony.messages.m019")
	};
	return n.filter((n) => n === "pressure" ? !0 : n === "lobby" ? F(e, t) >= 30 : n === "demonstration" ? en(e) : n === "campaign" ? e.classes.state.storage.influence > 0 : n === "extraTax" ? e.roles.filter((t) => t !== "state" && e.classes[t].legitimacy > 1).length >= 2 : X(e, {
		kind: n,
		actor: t
	}, !0).length > 0).map((e) => J(`basic:${e}`, r[e], "basic", { score: e === "pressure" ? 1 : e === "build" ? 8 : e === "buy" ? 6 : 4 })).concat(Kt(e, {
		kind: "historicalBasic",
		actor: t
	}));
}
function en(e) {
	return !e.demonstration && e.workers.filter((e) => e.role === "working" && e.company === null && !e.union).length >= e.companies.filter((t) => t.active && !G(e, t)).reduce((e, t) => e + (t.owner === "middle" ? 0 : W(t).length), 0) + j(e, "middle").filter((t) => G(e, t) && O(t).helper && !A(e, t).some((e) => e.role === "working")).length + 2;
}
function tn(e, t) {
	if (e.phase !== "action" || e.turnRole !== t) return [];
	let n = e.classes[t], r = [];
	if (e.mainDone || n.hand.forEach((e) => r.push(J(`hand:${e}`, Ne(e), "hand", { card: e }))), e.mainDone && r.push(J("endTurn", g("games.hegemony.messages.m020"), "endTurn", { score: -10 })), !e.freeDone) {
		if (M(t)) {
			for (let i of [
				"health",
				"education",
				"luxury"
			]) n.personal[i] >= P(e, t) && r.push(J(`free:use:${i}`, g("games.hegemony.messages.m021", { p1: E[i] }), "freeUse", {
				resource: i,
				score: 20
			}));
			X(e, {
				kind: "swap",
				actor: t
			}).length && r.push(J("free:swap", g("games.hegemony.messages.m022"), "freeTask"));
		}
		(t === "middle" || t === "capital") && (r.push(J("free:prices", g("games.hegemony.messages.m023"), "freeTask")), X(e, {
			kind: "storage",
			actor: t
		}).length && r.push(J("free:storage", g("games.hegemony.messages.m024"), "freeTask"))), t !== "working" && r.push(J("free:wages", g("games.hegemony.messages.m025"), "freeTask")), t === "capital" && j(e, t).some((t) => G(e, t) && nn(e, t.uid, 5)) && r.push(J("free:bonus", g("games.hegemony.messages.m026"), "freeTask")), n.loans && F(e, t) >= 50 && r.push(J("free:repay", g("games.hegemony.messages.m027"), "freeRepay", { score: 2 })), t !== "state" && e.roles.includes("state") && (n.benefits.money || n.benefits.votes || T.some((e) => n.benefits[e])) && r.push(J("free:benefits", g("games.hegemony.messages.m028"), "freeBenefits", { score: 14 })), r.push(...Kt(e, {
			kind: "freeExtensions",
			actor: t
		}));
	}
	return r;
}
var nn = (e, t, n) => F(e, k(e, t).owner) >= n;
function rn(e, t, n, r) {
	if (t.flag === "statePays") return 0;
	let i = t.flag === "half" ? Math.ceil(n / 2) : n - (t.resource && t.resource !== r ? 0 : t.discount ?? 0);
	return Math.max(0, i - (e.phase === "action" && e.classes[t.actor].perks.includes(21222) ? 10 : 0));
}
function X(e, t, n = !1) {
	let r = t.actor, i = e.classes[r], a = [];
	switch (t.kind) {
		case "cardMenu":
			a = $t(e, r), Fe(e, r, t.card) && a.unshift(J("playEffect", g("games.hegemony.messages.m029"), "playEffect", {
				card: t.card,
				score: 7
			})), a.push(J("cancel", g("games.hegemony.messages.m030")));
			break;
		case "chooseAgenda":
			a = i.agendas.map((e) => {
				let t = de.find((t) => t.id === e);
				return J(`agenda:${e}`, g("games.hegemony.messages.m031", {
					p1: _(t.name),
					p2: t.vp
				}), "agenda", { card: e });
			});
			break;
		case "newSkill":
		case "educate": {
			let n = t.target ?? r;
			if (!M(n)) break;
			a = t.kind === "educate" && t.selected === void 0 ? e.workers.filter((t) => t.role === n && (t.skill === "any" || t.company === null || W(k(e, t.company))[t.slot]?.skill === "any")).map((e) => J(`educateWorker:${e.id}`, g("games.hegemony.messages.m032", { p1: e.id }), "educateWorker", {
				worker: e.id,
				score: e.skill === "any" ? 3 : 0
			})) : T.filter((t) => Ce(e, n, t) > 0).map((t) => J(`skill:${t}`, E[t], "skill", {
				resource: t,
				score: j(e, n).filter((n) => O(n).resource === t && !G(e, n)).length
			}));
			break;
		}
		case "propose":
		case "directPolicy":
			if (t.kind === "propose" && (e.bills.filter((e) => e.role === (t.payBy ?? r)).length >= 3 || e.locked.includes(-1))) break;
			e.policies.forEach((n, i) => {
				if (!(e.bills.some((e) => e.policy === i) && t.flag !== "historical" || e.locked.includes(i) && t.flag !== "historical" || t.policy !== void 0 && t.policy !== i || t.ids?.includes(i)) && !(t.kind === "directPolicy" && t.flag === "historical" && e.roundEffects[`historyPolicy:${i}`])) for (let e of [
					"A",
					"B",
					"C"
				]) e !== n && (t.flag === "radical" || Math.abs("ABC".indexOf(e) - "ABC".indexOf(n)) === 1) && a.push(J(`bill:${i}:${e}`, g("games.hegemony.messages.m033", {
					p1: he[i],
					p2: n,
					p3: e
				}), "bill", {
					policy: i,
					score: (r === "working" ? e === "A" : r === "capital" ? e === "C" : e === "B") ? 10 : 0
				}));
			});
			break;
		case "immediate":
			a.push(J("laterVote", g("games.hegemony.messages.m034"))), t.flag !== "forbidden" && (e.roundEffects.freeVotes || t.flag === "free" || t.flag === "narrative" || i.personal.influence > 0) && a.unshift(J("voteNow", e.roundEffects.freeVotes || t.flag === "free" || t.flag === "narrative" ? g("games.hegemony.messages.m035") : g("games.hegemony.messages.m036"), "voteNow"));
			break;
		case "assign": {
			let i = at(e, t), o = t.target ?? r;
			if (!M(o)) break;
			if (t.selected === void 0) {
				let r = ct(e, t, n);
				a.push(...r.map((t) => {
					let n = t.map((e) => `${e.worker},${e.company ?? -1},${e.slot},${e.union ?? "-"}`).join(";"), r = t[0].company === null ? null : k(e, t[0].company);
					return J(`assignmentPlan:${n}`, r ? g("games.hegemony.messages.m037", {
						p1: t.length,
						p2: _(O(r).name)
					}) : g("games.hegemony.messages.m038", { p1: E[t[0].union] }), "assignmentPlan", {
						company: r?.uid,
						resource: t[0].union ?? void 0,
						score: t.length * 4 + Number(!r) * 15
					});
				})), (t.moves?.length ?? 0) < (t.limit ?? 3) && a.push(...i.workers.filter((e) => r.some((t) => t[0].worker === e.id)).map((e) => J(`selectWorker:${e.id}`, g("games.hegemony.messages.m040", {
					p1: e.skill === "any" ? g("games.hegemony.messages.m039") : E[e.skill],
					p2: e.id
				}), "selectWorker", {
					worker: e.id,
					score: e.company === null ? 4 : 0
				})));
				let o = t.moves ?? [];
				o.length && ot(i, t) && a.push(Qt()), !o.length && t.optional && a.push(Zt());
			} else {
				let n = i.workers.find((e) => e.id === t.selected);
				for (let o of i.companies.filter((e) => e.active && (t.company === void 0 || e.uid === t.company) && (t.mode !== "own" || e.owner === r) && (t.mode !== "external" || ["state", "capital"].includes(e.owner)))) W(o).forEach((r, s) => {
					let c = {
						worker: n.id,
						company: o.uid,
						slot: s,
						union: null
					};
					it(i, t, n, o, s) && (n.company !== o.uid || n.slot !== s) && st(e, {
						...t,
						moves: [...t.moves ?? [], c]
					}) && a.push(J(`slot:${o.uid}:${s}`, g("games.hegemony.messages.m041", {
						p1: _(O(o).name),
						p2: s + 1
					}), "slot", {
						company: o.uid,
						worker: n.id,
						amount: s,
						score: o.owner === "state" ? 5 : 3
					}));
				});
				o === "working" && n.skill !== "any" && st(e, {
					...t,
					moves: [...t.moves ?? [], {
						worker: n.id,
						company: null,
						slot: -1,
						union: n.skill
					}]
				}) && a.push(J(`union:${n.skill}`, g("games.hegemony.messages.m038", { p1: E[n.skill] }), "union", {
					resource: n.skill,
					score: 10
				})), a.push(J("backWorker", g("games.hegemony.messages.m042")));
			}
			break;
		}
		case "landOpportunity":
			a = T.filter((t) => {
				if (!Ce(e, "middle", t)) return !1;
				let n = structuredClone(e), i = U(n, "middle", t);
				return X(n, {
					kind: "build",
					actor: r,
					flag: "landOpportunity",
					selected: i.id
				}).length > 0;
			}).map((e) => J(`landSkill:${e}`, E[e], "landSkill", { resource: e }));
			break;
		case "build": {
			let n = t.flag === "search" ? i.companyDeck : i.market, o = r === "capital" ? 12 : 8;
			if (j(e, r).length >= o) break;
			a = n.map((e) => y.find((t) => t.id === e)).filter((n) => {
				if (t.resource && t.mode === "only" && n.resource !== t.resource || t.mode === "nonAutomated" && !n.workers.length || F(e, r) < rn(e, t, n.cost, n.resource)) return !1;
				if (r === "middle") {
					let i = e.workers.filter((n) => n.role === r && Te(e, n) && (!t.data?.onlyUnemployed || n.company === null)), a = /* @__PURE__ */ new Set(), o = t.flag === "landOpportunity" ? i.find((e) => e.id === t.selected) : void 0;
					if (t.flag === "landOpportunity" && !o) return !1;
					let s = n.workers.map((e, t) => ({
						skill: e,
						slot: t
					})).sort((e, t) => Number(t.skill === "skill") - Number(e.skill === "skill")), c = o ? s.find((e) => e.skill === "any" || o.skill === n.resource)?.slot : void 0;
					return o && c === void 0 ? !1 : s.every(({ skill: e, slot: t }) => {
						if (t === c) return a.add(o.id), !0;
						let r = i.find((t) => !a.has(t.id) && (e === "any" || t.skill === n.resource));
						return r && a.add(r.id), !!r;
					});
				}
				return !0;
			}).map((n) => J(`build:${n.id}`, g("games.hegemony.messages.m043", {
				p1: _(n.name),
				p2: rn(e, t, n.cost, n.resource)
			}), "buildCompany", {
				card: n.id,
				resource: n.resource,
				score: 10
			}));
			break;
		}
		case "hire": {
			let n = k(e, t.company), i = W(n).findIndex((t, r) => !A(e, n).some((e) => e.slot === r));
			if (i < 0) {
				a = [Qt()];
				break;
			}
			let o = W(n)[i], s = e.workers.filter((r) => Te(e, r) && (n.owner === "middle" && r.role === "middle" && t.flag !== "unemployed" || r.company === null) && Ee(e, r, n, i)).filter((a) => st(e, {
				kind: "assign",
				actor: r,
				target: a.role,
				company: n.uid,
				flag: n.owner === "middle" && t.flag !== "unemployed" && t.flag !== "automatic" ? void 0 : "unemployed",
				limit: 4,
				moves: [{
					worker: a.id,
					company: n.uid,
					slot: i,
					union: null
				}]
			}));
			a = s.filter((e) => o.skill !== "any" || e.skill === "any" || !s.some((t) => t.role === e.role && t.skill === "any")).map((e) => J(`hire:${e.id}`, g("games.hegemony.messages.m044", {
				p1: D[e.role],
				p2: e.id
			}), "hireWorker", {
				worker: e.id,
				company: n.uid,
				amount: i
			})), (G(e, n) || n.owner !== "middle" && !A(e, n).length && (t.flag !== "automatic" || !a.length)) && a.push(Qt());
			break;
		}
		case "setBuildWage":
		case "wages":
			j(e, r).filter((e) => t.company === void 0 || e.uid === t.company).forEach((n) => {
				if (O(n).wages.length) for (let r = N(e); r <= 3; r += 1) (t.kind === "setBuildWage" || r !== n.wage) && (r > n.wage || !A(e, n).some((e) => e.committed)) && a.push(J(`wage:${n.uid}:${r}`, g("games.hegemony.messages.m045", {
					p1: _(O(n).name),
					p2: r,
					p3: O(n).wages[r - 1]
				}), "wage", {
					company: n.uid,
					amount: r,
					score: r === N(e) ? 4 : 0
				}));
			}), t.kind === "wages" && a.push(Qt());
			break;
		case "sellCompany":
		case "overtime":
		case "bonus":
		case "strike":
		case "machinery":
			a = e.companies.filter((n) => {
				if (!n.active || t.ids?.includes(n.uid)) return !1;
				let i = O(n), a = A(e, n);
				if (t.kind === "strike") return !n.strike && n.wage < 3 && (n.owner !== "state" || e.roles.includes("state")) && a.some((e) => e.role === "working") && !a.some((e) => e.role === "working" && e.committed) && e.companies.filter((e) => e.strike).length < 7;
				if (n.owner !== (t.target ?? r)) return !1;
				if (t.kind === "sellCompany") return !a.some((e) => e.committed) && !(t.flag === "double" && n.machinery);
				if (t.kind === "machinery") return i.machineryBonus > 0 && !n.machinery && e.companies.filter((e) => e.machinery).length < 6;
				if (!G(e, n)) return !1;
				if (t.kind === "bonus") return F(e, r) >= 5;
				if (t.mode === "withHelper" && !a.some((e) => e.role === "working") || !i.workers.length || n.strike && n.wage < 3 && n.owner !== "middle" || n.owner === "middle" && a.some((e) => e.role === "middle" && e.committed)) return !1;
				let o = i.wages[n.wage - 1] ?? 0;
				return F(e, n.owner) >= (n.owner === "middle" && !a.some((e) => e.role === "working" && !e.committed) ? 0 : o);
			}).map((e) => J(`${t.kind}:${e.uid}`, _(O(e).name), "companyTask", {
				company: e.uid,
				score: 5
			})), (t.counter ?? 0) > 0 && a.push(Qt());
			break;
		case "buy":
		case "food": {
			if (!t.resource && t.kind !== "food") {
				a = T.filter((n) => X(e, {
					...t,
					resource: n
				}).length > 0).map((e) => J(`buyResource:${e}`, E[e], "buyResource", {
					resource: e,
					score: e === "food" ? 0 : 5
				}));
				break;
			}
			let n = t.kind === "food" ? "food" : t.resource, i = t.source ? [t.source] : [
				"state",
				"capital",
				...e.roles.includes("middle") ? ["middle"] : [],
				"foreign"
			];
			for (let o of i) {
				if (t.used?.includes(o) || t.mode === "others" && o === r || n === "influence" && o !== "state" || o === "foreign" && n !== "food" && n !== "luxury") continue;
				let i = o === "foreign" ? B(e, n) : e.classes[o].storage[n], s = K(e, o, n), c = Math.min(i, t.kind === "food" ? t.n : t.limit ?? P(e, r));
				for (let i = t.data?.exactQuantity ? c : 1; i <= c; i += 1) {
					if (t.data?.exactQuantity && c !== t.limit) continue;
					let l = o === r ? 0 : Math.ceil(s.price * i * (t.discount ?? 1)) + (t.flag === "noTariff" ? 0 : s.tariff * i);
					if (t.kind !== "food" && F(e, r) < l) continue;
					let u = o === "foreign" ? g("games.hegemony.messages.m046") : D[o];
					a.push(J(`purchase:${o}:${n}:${i}`, g("games.hegemony.messages.m047", {
						p1: u,
						p2: i,
						p3: E[n],
						p4: l
					}), "purchase", {
						role: o === "foreign" ? void 0 : o,
						resource: n,
						amount: i,
						score: i * 2 - l * .1
					}));
				}
			}
			t.kind === "buy" && (t.counter ?? 0) > 0 && a.push(Qt());
			break;
		}
		case "export":
			if (e.roundEffects.embargo) break;
			le.find((t) => t.id === e.exportCard).trades.forEach((e, n) => {
				let o = e.resource;
				t.count !== void 0 && (t.counter ?? 0) >= t.count || r === "state" && o !== "food" && o !== "luxury" || (t.used?.filter((e) => e === String(n)).length ?? 0) >= (t.limit ?? 1) || i.storage[o] + (r === "capital" && (o === "food" || o === "luxury") ? i.freeTrade[o] : 0) >= e.quantity && a.push(J(`export:${n}`, g("games.hegemony.messages.m048", {
					p1: e.quantity,
					p2: E[o],
					p3: e.money
				}), "exportTrade", {
					resource: o,
					amount: n,
					score: e.money
				}));
			}), ((t.counter ?? 0) > 0 || t.optional) && a.push(Qt());
			break;
		case "deal":
			if (e.roundEffects.embargo) break;
			e.business.forEach((t, n) => {
				let i = ue.find((e) => e.id === t);
				for (let t of ["local", "free"]) {
					let o = t === "free" ? 0 : i.tariffs["ABC".indexOf(e.policies[5])];
					F(e, r) < i.cost + o || a.push(J(`deal:${n}:${t}`, g("games.hegemony.messages.m051", {
						p1: i.food,
						p2: i.luxury,
						p3: g(t === "local" ? "games.hegemony.messages.m049" : "games.hegemony.messages.m050"),
						p4: i.cost + o
					}), "businessDeal", {
						amount: n,
						score: 8
					}));
				}
			});
			break;
		case "prices":
			for (let t of [
				"food",
				"luxury",
				"health",
				"education"
			]) for (let n of t === "food" ? [
				9,
				12,
				15
			] : [
				5,
				8,
				10
			]) i.prices[t] !== n && !e.roundEffects.allPricesLocked && !(e.roundEffects.goodsPricesLocked && ["food", "luxury"].includes(t)) && !(e.roundEffects.luxuryPricesLocked && t === "luxury") && a.push(J(`price:${t}:${n}`, g("games.hegemony.messages.m052", {
				p1: E[t],
				p2: n
			}), "price", {
				resource: t,
				amount: n
			}));
			a.push(Qt());
			break;
		case "storage":
			if (e.roles.reduce((t, n) => t + e.classes[n].expanded.length, 0) >= 6 || F(e, r) < (t.discount ? 0 : 20)) break;
			a = T.filter((e) => e !== "influence" && !i.expanded.includes(e)).map((e) => J(`storage:${e}`, g("games.hegemony.messages.m053", { p1: E[e] }), "storage", { resource: e }));
			break;
		case "swap":
			e.workers.filter((t) => t.role === r && t.company !== null && t.skill !== "any" && W(k(e, t.company))[t.slot].skill === "any").forEach((t) => {
				e.workers.filter((e) => e.role === r && e.company === null && !e.union).forEach((e) => a.push(J(`swap:${t.id}:${e.id}`, g("games.hegemony.messages.m054", {
					p1: t.id,
					p2: e.id
				}), "swapWorkers", {
					worker: t.id,
					amount: e.id
				})));
			}), t.counter && a.push(Qt());
			break;
		case "meet":
			i.personal.influence >= 2 && (a = e.roles.filter((e) => e !== r).map((e) => J(`meet:${e}`, D[e], "meet", { role: e })));
			break;
		case "extraTaxLoss":
		case "chooseLegitimacyLoss":
			a = e.roles.filter((n) => n !== "state" && e.classes[n].legitimacy > 1 && !t.used?.includes(n)).filter((n) => t.kind !== "extraTaxLoss" || e.classes[n].legitimacy === Math.min(...e.roles.filter((e) => e !== "state" && !t.used?.includes(e)).map((t) => e.classes[t].legitimacy))).map((e) => J(`legLoss:${e}`, D[e], "legLoss", { role: e }));
			break;
		case "electionSides":
			a = [J("support", g("games.hegemony.messages.m055")), J("oppose", g("games.hegemony.messages.m056"))];
			break;
		case "electionInfluence":
			for (let e = 0; e <= i.personal.influence; e += 1) a.push(J(`influence:${e}`, g("games.hegemony.messages.m057", { p1: e }), "influence", { amount: e }));
			break;
		case "marketRefresh":
			a = i.market.filter((e) => !t.ids?.includes(e)).map((e) => J(`marketDiscard:${e}`, _(y.find((t) => t.id === e).name), "marketDiscard", { card: e })), a.push(Qt());
			break;
		default: a = Kt(e, t);
	}
	return t.optional && !a.some((e) => e.key === "skip" || e.key === "finish") && a.push(Zt()), a;
}
function an(e, t, n = !1) {
	let r = e.jobs[0];
	return r && r.actor !== t ? [] : r ? X(e, r, n) : tn(e, t);
}
function on(e, t) {
	let n = e.jobs[0], r = n?.actor ?? e.turnRole, i = e.classes[r], a = t.key.split(":");
	if (t.key === "skip") {
		e.jobs.shift();
		return;
	}
	if (!n) {
		if (t.kind === "hand") {
			Y(e, {
				kind: "cardMenu",
				actor: r,
				card: t.card
			});
			return;
		}
		if (t.kind === "endTurn") {
			Y(e, {
				kind: "endTurn",
				actor: r
			});
			return;
		}
		if (e.freeDone = !0, t.kind === "freeUse") i.personal[t.resource] -= P(e, r), be(e, r), t.resource === "health" && (L(e, r, 2), U(e, r, "any")), t.resource === "education" && Y(e, {
			kind: "educate",
			actor: r,
			optional: !0
		});
		else if (t.kind === "freeRepay") ye(e, r);
		else if (t.kind === "freeBenefits") {
			for (let t of T) {
				let n = i.benefits[t];
				i.benefits[t] = 0, V(e, r, t, n);
			}
			i.money += i.benefits.money, i.benefits.money = 0;
			let t = i.benefits.votes;
			i.benefits.votes = 0, H(e, r, t), L(e, "state", 1);
		} else t.kind === "freeTask" ? Y(e, {
			kind: a[1],
			actor: r
		}) : qt(e, {
			kind: "freeExtensions",
			actor: r
		}, t);
		return;
	}
	if (t.key === "cancel") {
		e.jobs.shift();
		return;
	}
	if (n.kind === "pollPropose" && t.kind === "bill") {
		qt(e, n, t);
		return;
	}
	if (n.kind === "cardMenu") {
		i.hand = i.hand.filter((e) => e !== n.card), i.discard.push(n.card), e.mainDone = !0, e.effect = {
			card: n.card,
			target: null,
			amount: 0
		}, e.jobs.shift();
		let o = t.kind === "playEffect" ? Ie(e, r, n.card) : t.kind === "triggerHistory" ? [{
			kind: "applyHistorical",
			actor: r,
			card: t.card
		}] : Pe(r, a[1]);
		t.kind === "triggerHistory" && (i.personal.influence -= t.card === 7 ? 2 : +(t.card === 17)), Y(e, ...o), ve(e, g("games.hegemony.messages.m058", { p1: Ne(n.card) }), r);
		return;
	}
	if (t.key === "finish") {
		if (e.jobs.shift(), n.kind === "assign") {
			let t = new Set(e.companies.filter((t) => t.owner !== "middle" && G(e, t) && !A(e, t).some((e) => e.committed)).map((e) => e.uid));
			n.moves?.forEach((i) => {
				let a = e.workers.find((e) => e.id === i.worker), o = i.company !== null && t.has(i.company);
				a.company = i.company, a.slot = i.slot, a.union = i.union, a.committed = !o, n.amount && i.company !== null && R(e, k(e, i.company).owner, n.amount, r, !0), n.data?.statePerWorker && i.company !== null && R(e, "state", Number(n.data.statePerWorker), r, !0), n.data?.stateToCapital && i.company !== null && k(e, i.company).owner === "capital" && R(e, "state", Number(n.data.stateToCapital), "capital", !0);
			}), De(e), e.demonstration && n.moves?.some((e) => e.company !== null) && !en({
				...e,
				demonstration: !1
			}) && (e.demonstration = !1);
		} else n.kind === "hire" ? De(e) : n.kind === "marketRefresh" ? (i.companyDiscard.push(...n.ids ?? []), i.market = i.market.filter((e) => !n.ids?.includes(e)), Y(e, {
			kind: "refillMarket",
			actor: r
		})) : n.kind === "export" ? i.largestExport = Math.max(i.largestExport, (n.amount ?? 0) + e.effect.amount) : n.kind === "demonstrationPenalty" && (e.demonstration = !1, V(e, "working", "influence", 1));
		return;
	}
	switch (t.kind) {
		case "assignmentPlan": {
			let e = t.key.slice(15).split(";").map((e) => {
				let [t, n, r, i] = e.split(",");
				return {
					worker: Number(t),
					company: Number(n) === -1 ? null : Number(n),
					slot: Number(r),
					union: i === "-" ? null : i
				};
			});
			n.moves = [...n.moves ?? [], ...e];
			break;
		}
		case "agenda":
			i.agenda = t.card, i.agendas = [], e.jobs.shift();
			break;
		case "educateWorker":
			n.selected = t.worker;
			break;
		case "skill": {
			let i = n.target ?? r;
			n.kind === "newSkill" ? U(e, i, t.resource) : e.workers.find((e) => e.id === n.selected).skill = t.resource, e.jobs.shift();
			break;
		}
		case "bill": {
			let i = t.policy, o = a[2];
			e.jobs.shift(), n.kind === "directPolicy" ? (n.flag === "historical" && (e.roundEffects[`historyPolicy:${i}`] = !0), Y(e, {
				kind: "policyChange",
				actor: r,
				policy: i,
				flag: o,
				mode: "compensate"
			})) : (e.effect.target = r, e.roundEffects.lastProposedPolicy = i, e.bills.push({
				role: n.payBy ?? r,
				policy: i,
				target: o,
				protected: !1
			}), Y(e, {
				kind: "immediate",
				actor: n.payBy ?? r,
				policy: i,
				flag: n.flag === "radical" ? "forbidden" : n.flag
			}));
			break;
		}
		case "voteNow":
			!e.roundEffects.freeVotes && n.flag !== "free" && n.flag !== "narrative" && --i.personal.influence, e.jobs.shift(), Y(e, {
				kind: "startElection",
				actor: r,
				policy: n.policy,
				flag: n.flag
			});
			break;
		case "laterVote":
			e.jobs.shift();
			break;
		case "selectWorker":
			n.selected = t.worker;
			break;
		case "slot":
		case "union":
			n.moves ??= [], n.moves.push({
				worker: n.selected,
				company: t.company ?? null,
				slot: t.amount ?? -1,
				union: t.kind === "union" ? t.resource : null
			}), n.selected = void 0;
			break;
		case "backWorker":
			n.selected = void 0;
			break;
		case "landSkill": {
			let n = U(e, "middle", t.resource);
			e.jobs.shift(), Y(e, {
				kind: "build",
				actor: r,
				flag: "landOpportunity",
				selected: n.id
			});
			break;
		}
		case "buildCompany": {
			let a = y.find((e) => e.id === t.card), o = rn(e, n, a.cost, a.resource);
			R(e, r, o), (n.flag === "statePays" || n.flag === "half") && R(e, "state", a.cost - o, void 0, !0);
			let s = e.nextId++;
			if (e.companies.push({
				uid: s,
				definition: a.id,
				owner: r,
				wage: N(e),
				active: !0,
				strike: !1,
				machinery: !1
			}), i.market = i.market.filter((e) => e !== a.id), i.companyDeck = i.companyDeck.filter((e) => e !== a.id), n.flag === "landOpportunity") {
				let t = e.workers.find((e) => e.id === n.selected), r = a.workers.findIndex((e) => e === "skill" && t.skill === a.resource);
				t.company = s, t.slot = r >= 0 ? r : a.workers.findIndex((e) => e === "any"), t.committed = !0;
			}
			e.roundEffects.asianTigers && (R(e, "state", 10, r, !0), z(e, r, 1)), e.phase === "action" && i.perks.includes(21222) && (n.flag !== "statePays" && n.flag !== "half" && R(e, "state", Math.min(10, Math.max(0, a.cost - (n.discount ?? 0))), void 0, !0), L(e, "state", 1)), e.jobs.shift(), Y(e, {
				kind: "setBuildWage",
				actor: r,
				company: s,
				optional: !0
			}, {
				kind: "hire",
				actor: r,
				company: s
			}), n.flag === "refill" && e.jobs.splice(2, 0, {
				kind: "refillMarket",
				actor: r
			});
			break;
		}
		case "hireWorker": {
			let i = e.workers.find((e) => e.id === t.worker);
			i.company = n.company, i.slot = t.amount, i.committed = !0, n.data?.statePerWorker && R(e, "state", Number(n.data.statePerWorker), r, !0), W(k(e, n.company)).every((t, r) => A(e, k(e, n.company)).some((e) => e.slot === r)) && (e.jobs.shift(), De(e));
			break;
		}
		case "wage": {
			let r = k(e, t.company), i = t.amount > r.wage;
			r.wage = t.amount, i && n.kind !== "setBuildWage" && A(e, r).forEach((e) => {
				e.committed = !0;
			}), n.kind === "setBuildWage" && e.jobs.shift();
			break;
		}
		case "companyTask": {
			let a = k(e, t.company);
			n.kind === "sellCompany" ? (i.money += O(a).cost * (n.flag === "double" ? 2 : 1), O(a).owner === "state" ? (a.owner = "state", a.active = !1) : (i.companyDiscard.push(a.definition), e.companies = e.companies.filter((e) => e.uid !== a.uid)), A(e, a).forEach((e) => {
				e.company = null, e.slot = -1, e.committed = !1;
			}), e.jobs.shift(), De(e)) : n.kind === "overtime" ? (ke(e, a, !1, a.owner === "middle"), e.jobs.shift()) : n.kind === "bonus" ? (R(e, r, 5, A(e, a)[0].role), A(e, a).forEach((e) => {
				e.committed = !0;
			}), e.jobs.shift()) : (n.kind === "strike" || n.kind === "machinery") && (n.kind === "strike" ? a.strike = !0 : a.machinery = !0, n.ids ??= [], n.ids.push(a.uid), n.counter = (n.counter ?? 0) + 1, n.counter >= (n.limit ?? 2) && e.jobs.shift());
			break;
		}
		case "buyResource":
			n.resource = t.resource;
			break;
		case "purchase": {
			let o = a[1], s = t.amount;
			Ae(e, r, o, t.resource, s, {
				forced: n.kind === "food",
				discount: n.discount,
				noTariff: n.flag === "noTariff",
				subsidy: n.flag === "subsidy"
			}), e.effect.amount += s, n.counter = (n.counter ?? 0) + 1, n.used ??= [], n.used.push(o), n.kind === "food" ? (i.personal.food -= s, n.n -= s, n.used = [], n.n === 0 && e.jobs.shift()) : (n.counter >= (n.count ?? 2) || n.source) && e.jobs.shift();
			break;
		}
		case "exportTrade": {
			let a = le.find((t) => t.id === e.exportCard).trades[t.amount], o = a.quantity;
			if (r === "capital" && (a.resource === "food" || a.resource === "luxury")) {
				let e = Math.min(o, i.freeTrade[a.resource]);
				i.freeTrade[a.resource] -= e, o -= e;
			}
			i.storage[a.resource] -= o, i.money += a.money, r === "middle" && L(e, r, 1), n.flag === "subsidy" && R(e, "state", 5, r, !0), n.flag === "bonus" && (i.money += 5), !n.counter && e.roundEffects.asianTigers && (R(e, "state", 10, r, !0), z(e, r, 1)), !n.counter && e.roundEffects.exportLegitimacy && z(e, r, 1), n.used ??= [], n.used.push(String(t.amount)), n.counter = (n.counter ?? 0) + 1, n.amount = (n.amount ?? 0) + a.money;
			break;
		}
		case "businessDeal": {
			let n = t.amount, o = ue.find((t) => t.id === e.business[n]);
			R(e, r, o.cost), a[2] === "free" ? (i.freeTrade.food += Math.min(8 - i.freeTrade.food, o.food, B(e, "food")), i.freeTrade.luxury += Math.min(12 - i.freeTrade.luxury, o.luxury, B(e, "luxury"))) : (R(e, r, o.tariffs["ABC".indexOf(e.policies[5])], "state"), V(e, r, "food", o.food, "storage"), V(e, r, "luxury", o.luxury, "storage")), e.businessDiscard.push(...e.business.splice(n, 1)), e.jobs.shift();
			break;
		}
		case "price":
			i.prices[t.resource] = t.amount;
			break;
		case "storage":
			n.discount || R(e, r, 20), i.expanded.push(t.resource), e.jobs.shift();
			break;
		case "swapWorkers": {
			let r = e.workers.find((e) => e.id === t.worker), i = e.workers.find((e) => e.id === t.amount);
			i.company = r.company, i.slot = r.slot, i.committed = r.committed, r.company = null, r.slot = -1, r.committed = !1, n.counter = (n.counter ?? 0) + 1;
			break;
		}
		case "meet":
			i.personal.influence -= 2, V(e, t.role, "influence", 2), z(e, t.role, 1), e.jobs.shift();
			break;
		case "legLoss":
			z(e, t.role, -1), n.used ??= [], n.used.push(t.role), n.used.length >= (n.n ?? 2) && e.jobs.shift();
			break;
		case "support":
		case "oppose":
			e.election.sides[r] = t.kind === "support", e.jobs.shift();
			break;
		case "influence":
			e.election.spending[r] = t.amount, e.jobs.shift();
			break;
		case "marketDiscard":
			n.ids ??= [], n.ids.push(t.card);
			break;
		default: qt(e, n, t);
	}
}
//#endregion
//#region src/games/hegemony/flow.ts
var sn = {
	action: 450,
	production: 700,
	election: 950,
	phase: 750
}, cn = /* @__PURE__ */ new Set(/* @__PURE__ */ "cardMenu.chooseAgenda.newSkill.educate.propose.directPolicy.immediate.assign.landOpportunity.build.hire.setBuildWage.wages.sellCompany.overtime.bonus.strike.machinery.buy.food.export.deal.prices.storage.swap.meet.extraTaxLoss.chooseLegitimacyLoss.electionSides.electionInfluence.marketRefresh.pollPropose.pollDecision.fakeNewsRemove.removeWorkers.workplaceAccident.affordableHousing.sellState.foreignRecruitment.competitiveWages.extraExport.exportInsightChoice.chooseHire.investmentChoice.industrialization.technologyChoice.personalConsumption.growingStorage.event.eventTask.eventTarget.eventBenefit.eventInsightChoice.provideChoice.providePopulation.provideIncome.provideRepresentation.provideBuy.denySpeech.nationalization.privatization.protectPolicy.removeBill.stealInfluence.rapidResolution.foreignHealth.publicCapacity.demonstrationPenalty.bondBuy.historicalChoice.perkDecision.perkWage.publicPressure.perkHire".split("."));
function ln(e) {
	return e.jobs[0]?.actor ?? e.turnRole;
}
function un(e) {
	if (e.phase === "done") return !1;
	let t = e.jobs[0];
	return t ? !cn.has(t.kind) || e.classes[t.actor].automa !== "off" || !e.classes[t.actor].rid || !an(e, t.actor, !0).length : e.classes[e.turnRole].automa !== "off";
}
function dn(e, t, n) {
	!t.length && n.length && t.push(...I(e, n.splice(0)));
}
function fn(e, t, n) {
	let r = e.classes[t];
	if (r.automa === "off") for (let t = 0; t < n; t += 1) dn(e, r.deck, r.discard), r.deck.length && r.hand.push(r.deck.shift());
}
function pn(e) {
	return fe.find((t) => t.id === e.politicalCard)?.policies.filter((t, n) => e.policies[n] === t).length ?? 0;
}
function mn(e, t = !0) {
	for (let t of [
		"working",
		"middle",
		"capital"
	]) H(e, t, e.roles.includes(t) ? t === "working" ? Math.ceil(P(e, t) / 2) : t === "capital" ? Math.ceil(j(e, t).filter((t) => G(e, t)).length / 2) : Math.max(Math.ceil(P(e, t) / 2), Math.ceil(j(e, t).filter((t) => G(e, t)).length / 2)) : 5);
	t && e.roles.includes("state") && V(e, "state", "influence", Math.floor(Math.min(...e.roles.filter((e) => e !== "state").map((t) => e.classes[t].legitimacy)) / 2));
}
function hn(e, t) {
	let n = t.mode === "maastricht" ? {
		role: t.actor,
		policy: 5,
		target: "C",
		protected: !1
	} : e.bills.find((e) => e.policy === t.policy && !e.protected);
	if (!n) return;
	e.election = {
		bill: { ...n },
		sides: { [n.role]: !0 },
		cubes: t.ids?.map((e) => w[e]) ?? [],
		spending: {},
		stage: "sides",
		narrative: t.flag === "narrative" ? t.actor : null,
		prepaid: t.flag === "rapid" ? { [t.actor]: 1 } : {}
	}, t.mode === "maastricht" && (e.election.special = "maastricht");
	let r = [];
	for (let t of e.roles) t === n.role || t === "state" && e.classes.state.personal.influence === 0 && !e.election.prepaid.state || r.push({
		kind: "electionSides",
		actor: t
	});
	if (e.phase === "elections") for (let t of e.roles.filter((t) => e.classes[t].perks.includes(21210))) r.unshift({
		kind: "publicPressure",
		actor: t
	});
	r.push({
		kind: "drawElection",
		actor: n.role
	}), Y(e, ...r), ve(e, g("games.hegemony.messages.m134", {
		p1: n.policy + 1,
		p2: n.target
	}), n.role);
}
function gn(e) {
	let t = e.election, n = 0, r = 0, i = {};
	for (let a of t.cubes) e.roles.includes(a) && (i[a] = (i[a] ?? 0) + 1, t.sides[a] ? n += 1 : r += 1);
	for (let a of e.roles) {
		let o = t.spending[a] ?? 0;
		e.classes[a].personal.influence -= o;
		let s = o + (t.prepaid[a] ?? 0);
		i[a] = (i[a] ?? 0) + s, t.sides[a] ? n += s : r += s;
	}
	let a = n >= r;
	if (t.cubes.forEach((n) => {
		e.roles.includes(n) && t.sides[n] !== a && e.bag.push(n);
	}), t.special || (e.bills = e.bills.filter((e) => e.policy !== t.bill.policy)), a) {
		if (t.special === "maastricht") Y(e, {
			kind: "policyChange",
			actor: t.bill.role,
			policy: 5,
			flag: "C",
			mode: "compensate"
		}, {
			kind: "policyChange",
			actor: t.bill.role,
			policy: 6,
			flag: "C",
			mode: "compensate"
		}, {
			kind: "maastrichtReward",
			actor: t.bill.role
		});
		else {
			L(e, t.bill.role, 3), e.phase === "elections" && (e.billsPassed[t.bill.role] += 1);
			for (let n of e.roles) n !== t.bill.role && t.sides[n] && (i[n] ?? 0) > 0 && L(e, n, 1);
			Y(e, {
				kind: "policyChange",
				actor: t.bill.role,
				policy: t.bill.policy,
				flag: t.bill.target
			});
		}
	}
	ve(e, g("games.hegemony.messages.m137", {
		p1: g(a ? "games.hegemony.messages.m135" : "games.hegemony.messages.m136"),
		p2: n,
		p3: r
	})), e.election = null;
}
function _n(e) {
	let t = [{
		kind: "productionStart",
		actor: "state"
	}, ...Jt(e, "production")];
	for (let n of [
		"state",
		"capital",
		"middle",
		"working"
	]) {
		for (let r of j(e, n)) t.push({
			kind: "produceCompany",
			actor: n,
			company: r.uid
		});
		n === "working" && t.push({
			kind: "unionIncome",
			actor: n
		});
	}
	t.push({
		kind: "releaseWorkers",
		actor: "working"
	});
	for (let n of ["middle", "working"]) e.roles.includes(n) && t.push({
		kind: "coverNeeds",
		actor: n
	});
	t.push({
		kind: "checkIMF",
		actor: "state"
	});
	for (let n of [
		"capital",
		"middle",
		"working"
	]) e.roles.includes(n) && t.push({
		kind: "tax",
		actor: n
	});
	return t.push({
		kind: "electionsStart",
		actor: "working"
	}), t;
}
function vn(e) {
	let t = [{
		kind: "preparationStart",
		actor: "working"
	}, ...Jt(e, "preparation")];
	for (let n of [...e.roles].reverse()) t.push({
		kind: "interest",
		actor: n
	});
	e.roles.includes("state") || t.push({
		kind: "interest",
		actor: "state"
	}), e.roles.includes("state") && t.push({
		kind: "drawEvents",
		actor: "state",
		n: 2
	}, {
		kind: "drawPolitical",
		actor: "state"
	}), t.push({
		kind: "tradeRefresh",
		actor: "capital"
	});
	for (let n of ["capital", "middle"]) e.roles.includes(n) && t.push({
		kind: "marketRefresh",
		actor: n
	});
	for (let n of e.roles) t.push({
		kind: "prepClass",
		actor: n
	});
	return e.config.historicalEvents && t.push({
		kind: "historicalReveal",
		actor: "working"
	}), t.push({
		kind: "beginAction",
		actor: "working"
	}), t;
}
function yn(e, t) {
	let n = "ABC".indexOf(e.laborAtProduction), r = "ABC".indexOf(e.policies[2]), i = [
		[
			7,
			6,
			5
		],
		[
			4,
			4,
			4
		],
		[
			1,
			2,
			3
		]
	][n][r], a = j(e, t).filter((t) => G(e, t)).length * ge(e), o = e.classes[t].perks.includes(21213) ? 10 : 0;
	if (t === "working") R(e, t, Math.max(0, i * P(e, t) - o), "state", !0);
	else if (t === "middle") {
		let n = new Set(e.workers.filter((n) => n.role === t && n.company !== null && e.companies.find((e) => e.uid === n.company).owner !== t).map((e) => e.company)).size;
		R(e, t, Math.max(0, i * n + a - o), "state", !0);
	} else {
		R(e, t, Math.max(0, a - o), "state", !0);
		let n = e.classes[t].money, i = [
			5,
			10,
			25,
			50,
			100,
			200,
			300
		].reduce((e, t, r) => n >= t ? r : e, -1);
		i >= 0 && R(e, t, Math.max(0, [
			[
				1,
				2,
				2
			],
			[
				5,
				5,
				4
			],
			[
				12,
				10,
				7
			],
			[
				24,
				15,
				10
			],
			[
				40,
				30,
				20
			],
			[
				100,
				70,
				40
			],
			[
				160,
				120,
				60
			]
		][i][r] - Math.max(0, o - a)), "state", !0);
	}
}
function bn(e) {
	for (let t of e.roles) {
		let n = e.classes[t];
		if (t === "capital") L(e, t, -5 * n.loans, g("games.hegemony.messages.m138"));
		else {
			let r = n.loans * 55, i = Math.min(r, Math.floor(F(e, t) / 5) * 5);
			R(e, t, i), L(e, t, -(r - i) / 5, g("games.hegemony.messages.m138"));
		}
		if (t !== "state") {
			let n = t === "working" ? "A" : t === "middle" ? "B" : "C", r = e.policies.slice(0, 5).filter((e) => e === n).length;
			L(e, t, (t === "middle" ? [
				0,
				1,
				3,
				6,
				10,
				15
			] : [
				0,
				1,
				4,
				8,
				12,
				18
			])[r], g("games.hegemony.messages.m139"));
		}
		if (t !== "working") {
			let r = Math.floor((n.storage.food + n.freeTrade.food) / 2);
			for (let e of [
				"luxury",
				"health",
				"education"
			]) r += Math.floor((n.storage[e] + (e === "luxury" ? n.freeTrade.luxury : 0)) / 3);
			t === "state" && (r += Math.floor(n.storage.influence / 3)), L(e, t, r, g("games.hegemony.messages.m140"));
		}
		t !== "capital" && L(e, t, t === "working" ? Math.min(15, Math.floor(n.money / 10)) : Math.floor(n.money / (t === "middle" ? 15 : 30)), g("games.hegemony.messages.m141"));
	}
	Yt(e, "game-end"), e.phase = "done";
}
function xn(e) {
	let t = e.jobs[0];
	if (t && cn.has(t.kind)) {
		an(e, t.actor, !0).length ? Ut(e) : (ve(e, g("games.hegemony.messages.m142"), t.actor), e.jobs.shift());
		return;
	}
	let n = e.jobs.shift();
	if (!n) {
		Ht(e);
		return;
	}
	let r = n.actor, i = e.classes[r];
	switch (n.kind) {
		case "beginAction":
			e.phase = "action", e.turn = 0, e.turnRole = e.roles[0], e.mainDone = !1, e.freeDone = !1;
			break;
		case "gainMoney":
			n.source ? R(e, n.source, n.n, r, !0) : i.money += n.n, e.effect.amount += n.n;
			break;
		case "gainResource":
			V(e, r, n.resource, n.n);
			break;
		case "gainVotes":
			H(e, r, n.n);
			break;
		case "payMoney":
			R(e, r, n.n, n.target, !1, n.flag === "capital");
			break;
		case "spendInfluence":
			i.personal.influence -= n.n;
			break;
		case "score":
			L(e, r, n.n);
			break;
		case "prosperity":
			be(e, r);
			break;
		case "distributeMoney":
			n.used?.forEach((t) => {
				e.roles.includes(t) && (e.classes[t].money += n.n);
			});
			break;
		case "convertMedia": {
			let t = Math.min(n.n, i.storage.influence);
			i.storage.influence -= t, V(e, r, "influence", t);
			break;
		}
		case "extraTax":
			e.roles.filter((e) => e !== "state").forEach((t) => R(e, t, n.n ?? 10, "state", !0));
			break;
		case "demonstration":
			e.demonstration = !0;
			break;
		case "refillMarket":
			for (; i.market.length < (r === "capital" ? 4 : 3) && (i.companyDeck.length || i.companyDiscard.length);) dn(e, i.companyDeck, i.companyDiscard), i.market.push(i.companyDeck.shift());
			break;
		case "drawEvents":
			for (let t = 0; t < (n.n ?? 2); t += 1) {
				dn(e, e.eventDeck, e.eventDiscard);
				for (let t = 0; t < e.eventDeck.length; t += 1) {
					let t = e.eventDeck.shift(), n = x.find((e) => e.id === t);
					if (e.round === 1 && "rounds" in n && n.rounds === "2-5") {
						e.eventDeck.push(t);
						continue;
					}
					e.events.push(t);
					break;
				}
			}
			break;
		case "drawPolitical":
			e.politicalCard = e.politicalDeck.shift();
			break;
		case "endTurn":
			if (!e.mainDone && i.automa === "off") break;
			if (i.automa !== "off") {
				Y(e, {
					kind: "automaFreeEnd",
					actor: r
				}, {
					kind: "advanceTurn",
					actor: r
				});
				break;
			}
			Y(e, {
				kind: "advanceTurn",
				actor: r
			});
			break;
		case "advanceTurn":
			e.turn += 1, e.turn >= e.roles.length * 5 ? Y(e, {
				kind: "actionEnd",
				actor: "working"
			}) : (e.turnRole = e.roles[e.turn % e.roles.length], e.mainDone = !1, e.freeDone = !1, e.classes[e.turnRole].automa !== "off" && Y(e, {
				kind: "automaTurnStart",
				actor: e.turnRole
			}));
			break;
		case "actionEnd":
			for (let t of e.bonds.filter((t) => t.due === e.round)) R(e, "state", t.repayment, t.role, !0);
			e.bonds = e.bonds.filter((t) => t.due !== e.round), Y(e, {
				kind: "historicalEnd",
				actor: "working"
			}, ..._n(e));
			break;
		case "productionStart":
			e.phase = "production", e.laborAtProduction = e.policies[1], e.wagesEarned = {
				working: 0,
				middle: 0,
				capital: 0,
				state: 0
			}, Y(e, {
				kind: "automaStrike",
				actor: "capital"
			}), e.demonstration && Y(e, {
				kind: "demonstrationPenalty",
				actor: "working",
				n: e.workers.filter((e) => e.role === "working" && e.company === null && !e.union).length + e.workers.filter((e) => e.union).length
			});
			break;
		case "produceCompany": {
			let t = e.companies.find((e) => e.uid === n.company);
			if (!t?.active) break;
			if (e.roundEffects[`preproductionAssign:${r}`] && !n.flag) {
				Y(e, {
					kind: "perkHire",
					actor: r,
					company: t.uid
				}, {
					...n,
					flag: "benefitChecked"
				});
				break;
			}
			t.strike && t.wage === 3 && (t.strike = !1), t.strike && G(e, t) && V(e, "working", "influence", 1);
			let i = {
				working: e.classes.working.money,
				middle: e.classes.middle.money
			};
			ke(e, t), e.wagesEarned.working += Math.max(0, e.classes.working.money - i.working), e.wagesEarned.middle += Math.max(0, e.classes.middle.money - i.middle), t.strike = !1;
			break;
		}
		case "unionIncome":
			V(e, r, "influence", e.workers.filter((e) => e.union).length);
			break;
		case "releaseWorkers":
			e.workers.filter((e) => !e.union).forEach((e) => {
				e.committed = !1;
			}), Yt(e, "production");
			break;
		case "coverNeeds": {
			i.perks.includes(21211) && (e.classes.state.storage.food ? (--e.classes.state.storage.food, V(e, r, "food", 1)) : L(e, "state", -1));
			let t = P(e, r);
			for (let e of ["personal", "storage"]) {
				let n = Math.min(t, i[e].food);
				i[e].food -= n, t -= n;
			}
			t && Y(e, {
				kind: "food",
				actor: r,
				n: t
			});
			break;
		}
		case "checkIMF": {
			e.locked = e.locked.filter((e) => e === -1);
			let t = e.policies[0] === "C" ? 1 : 2;
			for (; i.loans >= t && F(e, "state") >= 55;) ye(e, "state", 55);
			i.loans >= t && Y(e, {
				kind: "imf",
				actor: r
			});
			break;
		}
		case "tax":
			yn(e, r);
			break;
		case "electionsStart":
			e.phase = "elections", e.billsPassed = {
				working: 0,
				middle: 0,
				capital: 0,
				state: 0
			}, Y(e, ...Jt(e, "elections"), {
				kind: "electionsReady",
				actor: "working"
			});
			break;
		case "electionsReady":
			e.bills.some((e) => !e.protected) && !e.locked.includes(-1) ? (mn(e), Y(e, {
				kind: "nextElection",
				actor: "working"
			})) : Y(e, {
				kind: "scoringStart",
				actor: "working"
			});
			break;
		case "nextElection": {
			let t = [...e.bills].filter((e) => !e.protected).sort((e, t) => e.policy - t.policy)[0];
			t ? Y(e, {
				kind: "startElection",
				actor: t.role,
				policy: t.policy
			}, {
				kind: "nextElection",
				actor: "working"
			}) : (Yt(e, "elections"), Y(e, {
				kind: "scoringStart",
				actor: "working"
			}));
			break;
		}
		case "startElection":
			hn(e, n);
			break;
		case "drawElection": {
			let t = e.election;
			if (t.stage = "draw", !t.cubes.length) for (let n = 0; n < 5; n += 1) e.bag.length || (mn(e, !1), mn(e, !1)), t.cubes.push(e.bag.splice(_e(e, e.bag.length), 1)[0]);
			let n = e.roles.filter((n) => e.classes[n].automa === "off" && n !== t.narrative && t.spending[n] === void 0);
			t.stage = "influence", Y(e, ...n.map((e) => ({
				kind: "electionInfluence",
				actor: e
			})), {
				kind: "automaInfluence",
				actor: "working"
			}, ...t.narrative && e.classes[t.narrative].automa === "off" && t.spending[t.narrative] === void 0 ? [{
				kind: "electionInfluence",
				actor: t.narrative
			}] : [], {
				kind: "resolveElection",
				actor: t.bill.role
			});
			break;
		}
		case "automaInfluence":
			Wt(e);
			break;
		case "maastrichtVote":
			hn(e, {
				...n,
				mode: "maastricht"
			});
			break;
		case "maastrichtReward":
			e.classes.working.money += 10, e.classes.capital.money += 25, e.roles.includes("middle") && (e.classes.middle.money += 10), e.roles.includes("state") && V(e, "state", "influence", 2);
			break;
		case "resolveElection":
			gn(e);
			break;
		case "policyChange":
			if (Me(e, n.policy, n.flag, n.mode === "compensate"), n.policy === 1 && n.mode === "imf" && je(e, !0), n.policy === 0 && Y(e, {
				kind: "publicCapacity",
				actor: e.roles.includes("state") ? "state" : e.roles.includes("middle") ? "middle" : "working",
				flag: n.mode
			}), n.policy === 1) for (let t of e.roles.filter((e) => e !== "working")) Y(e, {
				kind: "wages",
				actor: t,
				optional: !0
			});
			if ([
				3,
				4,
				5
			].includes(n.policy)) for (let t of ["capital", "middle"]) e.roles.includes(t) && Y(e, {
				kind: "prices",
				actor: t,
				optional: !0
			});
			break;
		case "scoringStart":
			e.phase = "scoring", e.bills = e.bills.filter((e) => !e.protected), Y(e, {
				kind: "eventPenalties",
				actor: "state"
			}, ...[...e.roles].reverse().map((e) => ({
				kind: "scoreClass",
				actor: e
			})), {
				kind: "roundEnd",
				actor: "working"
			});
			break;
		case "scoreClass":
			if (r === "working" && L(e, r, e.workers.filter((e) => e.union).length * 2, g("games.hegemony.messages.m143", { p1: e.round })), r === "middle") {
				let t = j(e, r).filter((t) => A(e, t).length === 2).length;
				[
					0,
					1,
					2,
					3,
					4,
					5,
					5,
					6,
					6,
					7,
					7
				][i.prosperity] < t && be(e, r);
			}
			if (r === "capital") {
				i.capital += i.money, i.money = 0;
				let t = [
					10,
					25,
					50,
					75,
					100,
					125,
					150,
					175,
					200,
					250,
					300,
					350,
					400,
					450,
					500
				].filter((e) => i.capital >= e).length;
				L(e, r, t + Math.max(0, t - i.wealth) * 3, g("games.hegemony.messages.m144", { p1: e.round })), i.wealth = Math.max(t, i.wealth);
			}
			if (r === "state") {
				let t = e.roles.filter((e) => e !== "state").map((t) => e.classes[t].legitimacy).sort((e, t) => e - t);
				L(e, r, t[0] + t[1], g("games.hegemony.messages.m145", { p1: e.round })), e.roles.filter((e) => e !== "state").forEach((t) => {
					let n = e.classes[t];
					n.legitimacy = Math.min(10, Math.ceil(n.legitimacy / 2) + n.tokens);
				}), L(e, r, pn(e), g("games.hegemony.messages.m146", { p1: e.round }));
			}
			Yt(e, "scoring");
			break;
		case "roundEnd":
			e.round === 5 ? Y(e, {
				kind: "finalScore",
				actor: "working"
			}) : (e.round += 1, Y(e, ...vn(e)));
			break;
		case "preparationStart":
			for (let t of e.companies) e.roundEffects[`restoreWage:${t.uid}`] !== void 0 && (t.wage = Number(e.roundEffects[`restoreWage:${t.uid}`]));
			e.phase = "preparation", e.roundEffects = {}, e.historicalUsed = [], e.bills = [], e.locked = e.locked.filter((e) => e !== -1);
			break;
		case "interest":
			if (R(e, r, i.loans * 5, void 0, !0, r === "capital"), r === "state" && !e.roles.includes("state")) for (; i.loans && i.money > 50;) ye(e, r);
			break;
		case "tradeRefresh":
			e.businessDiscard.push(...e.business.splice(0));
			for (let t = 0; t < "ABC".indexOf(e.policies[5]); t += 1) dn(e, e.businessDeck, e.businessDiscard), e.business.push(e.businessDeck.shift());
			e.exportDiscard.push(e.exportCard), dn(e, e.exportDeck, e.exportDiscard), e.exportCard = e.exportDeck.shift();
			break;
		case "prepClass":
			M(r) && (i.prosperity = Math.max(0, i.prosperity - (r === "working" ? 1 : 2)), U(e, r, "any"), r === "working" ? U(e, r, "any") : Y(e, {
				kind: "newSkill",
				actor: r
			}), we(e, r, "ABC".indexOf(e.policies[6]))), fn(e, r, 5), i.automa !== "off" && (j(e, r).forEach((t) => {
				t.wage = N(e);
			}), Y(e, {
				kind: "automaPrep",
				actor: r
			}));
			break;
		case "finalScore":
			bn(e);
			break;
		default: Xt(e, n);
	}
	Yt(e, e.phase);
}
//#endregion
//#region src/games/hegemony/meta.ts
var Sn = {
	id: "hegemony",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"worker-placement",
		"engine-building",
		"deck-bag-building"
	],
	interactionTags: [],
	nameKey: "games.hegemony.name",
	descKey: "games.hegemony.desc",
	rulesKey: "games.hegemony.rules",
	icon: "🏛️",
	iconImg: "games/hegemony.webp",
	rulesUrl: { en: "https://hegemonicproject.com/wp-content/uploads/2023/04/Hegemony-English-Rulebook-v1.2.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#334d6b",
	releasedAt: "2026-11-02T16:15:00+08:00",
	search: {
		py: "ling guo zhe",
		init: "lgz"
	},
	hotseat: "cover"
}, Z = t.enum([
	"working",
	"middle",
	"capital",
	"state"
]), Cn = t.enum([
	"food",
	"luxury",
	"health",
	"education",
	"influence"
]), wn = t.enum([
	"A",
	"B",
	"C"
]), Tn = t.lazy(() => t.object({
	key: t.string(),
	params: t.record(t.string(), t.union([
		t.string(),
		t.number(),
		Tn
	])).optional()
})), En = t.object({
	food: t.number(),
	luxury: t.number(),
	health: t.number(),
	education: t.number(),
	influence: t.number()
}), Dn = t.enum([
	"off",
	"simple",
	"advanced"
]), On = t.object({
	actionExpansion: t.boolean().default(!1),
	crisisResponse: t.boolean().default(!1),
	hiddenAgendas: t.boolean().default(!1),
	alternativeEvents: t.boolean().default(!1),
	historicalEvents: t.boolean().default(!1),
	controllingNarrative: t.boolean().default(!1),
	rapidResolution: t.boolean().default(!1),
	seatRoles: t.string().default(""),
	workingAutoma: Dn.default("off"),
	middleAutoma: Dn.default("off"),
	capitalAutoma: Dn.default("off")
}).prefault({}), kn = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	revision: t.int().nonnegative(),
	key: t.string().min(1).max(160)
}), t.object({
	type: t.literal("tick"),
	now: t.number().finite()
})]), An = t.object({
	role: Z,
	rid: t.string().nullable(),
	money: t.number(),
	capital: t.number(),
	loans: t.int(),
	vp: t.number(),
	prosperity: t.int(),
	wealth: t.int(),
	storage: En,
	personal: En,
	freeTrade: t.object({
		food: t.number(),
		luxury: t.number()
	}),
	prices: En,
	benefits: En.extend({
		money: t.number(),
		votes: t.number()
	}),
	expanded: t.array(Cn),
	legitimacy: t.int(),
	tokens: t.int(),
	handCount: t.int(),
	deckCount: t.int(),
	discard: t.array(t.int()),
	market: t.array(t.int()),
	agendaAchieved: t.array(t.int()),
	visibleAgendas: t.array(t.int()),
	perks: t.array(t.int()),
	automa: Dn,
	aiCard: t.int().nullable(),
	actionRows: t.array(t.array(t.string())),
	policyRows: t.array(t.array(t.int()))
}), jn = t.object({
	key: t.string(),
	text: Tn,
	kind: t.string(),
	card: t.int().optional(),
	company: t.int().optional(),
	worker: t.int().optional(),
	resource: Cn.optional(),
	policy: t.int().optional(),
	amount: t.number().optional(),
	role: Z.optional(),
	score: t.number()
}), Mn = t.object({
	revision: t.int(),
	round: t.int(),
	turn: t.int(),
	turnRole: Z,
	roles: t.array(Z),
	phase: t.enum([
		"setup",
		"preparation",
		"action",
		"production",
		"elections",
		"scoring",
		"done"
	]),
	mainDone: t.boolean(),
	freeDone: t.boolean(),
	actor: Z,
	automatic: t.boolean(),
	task: t.string().nullable(),
	taskText: Tn.nullable(),
	playedCard: t.int().nullable(),
	classes: t.array(An),
	winnerRoles: t.array(Z),
	workers: t.array(t.object({
		id: t.int(),
		role: t.enum(["working", "middle"]),
		skill: t.enum([
			"any",
			"food",
			"luxury",
			"health",
			"education",
			"influence"
		]),
		company: t.int().nullable(),
		slot: t.int(),
		committed: t.boolean(),
		union: Cn.nullable()
	})),
	companies: t.array(t.object({
		uid: t.int(),
		definition: t.int(),
		owner: Z,
		wage: t.int(),
		machinery: t.boolean(),
		strike: t.boolean(),
		active: t.boolean()
	})),
	policies: t.array(wn),
	bills: t.array(t.object({
		role: Z,
		policy: t.int(),
		target: wn,
		protected: t.boolean()
	})),
	locked: t.array(t.int()),
	demonstration: t.boolean(),
	bagCounts: t.array(t.object({
		role: Z,
		count: t.int()
	})),
	exportCard: t.int(),
	business: t.array(t.int()),
	events: t.array(t.int()),
	politicalCard: t.int().nullable(),
	crisisCard: t.int().nullable(),
	historical: t.int().nullable(),
	historicalUsed: t.array(Z),
	election: t.object({
		bill: t.object({
			role: Z,
			policy: t.int(),
			target: wn,
			protected: t.boolean()
		}),
		sides: t.partialRecord(Z, t.boolean()),
		cubes: t.array(Z),
		stage: t.enum([
			"sides",
			"draw",
			"influence",
			"result"
		]),
		decided: t.array(Z)
	}).nullable(),
	bonds: t.array(t.object({
		role: Z,
		principal: t.number(),
		repayment: t.number(),
		due: t.int()
	})),
	log: t.array(t.object({
		id: t.int(),
		text: Tn,
		role: Z.optional()
	})),
	scoreBreakdown: t.array(t.object({
		role: Z,
		text: Tn,
		vp: t.number()
	})),
	config: On
}), Nn = t.object({
	role: Z.nullable(),
	hand: t.array(t.int()),
	agendas: t.array(t.int()),
	agenda: t.int().nullable(),
	choices: t.array(jn),
	moves: t.array(t.object({
		worker: t.int(),
		company: t.int().nullable(),
		slot: t.int(),
		union: Cn.nullable()
	})),
	selected: t.int().nullable(),
	influence: t.int().nullable(),
	knownSpending: t.partialRecord(Z, t.number())
});
//#endregion
//#region src/games/hegemony/setup.ts
function Pn() {
	return {
		rid: null,
		money: 0,
		capital: 0,
		loans: 0,
		everLoan: !1,
		vp: 0,
		prosperity: 0,
		wealth: 0,
		storage: me(),
		personal: me(),
		freeTrade: {
			food: 0,
			luxury: 0
		},
		prices: {
			food: 12,
			luxury: 8,
			health: 8,
			education: 8,
			influence: 0
		},
		expanded: [],
		benefits: {
			...me(),
			money: 0,
			votes: 0
		},
		legitimacy: 2,
		tokens: 0,
		deck: [],
		discard: [],
		hand: [],
		companyDeck: [],
		companyDiscard: [],
		market: [],
		agendas: [],
		agenda: null,
		agendaAchieved: [],
		perks: [],
		eventsResolved: 0,
		largestExport: 0,
		automa: "off",
		aiDeck: [],
		aiDiscard: [],
		aiCard: null,
		actionRows: [],
		policyRows: [],
		policyAside: []
	};
}
function Fn(e, t, n) {
	let r = e.seatRoles.split(",").filter((e) => w.includes(e)), i = t.length === 1 ? ["working"] : t.length === 2 ? ["working", "capital"] : t.length === 3 ? [
		"working",
		"middle",
		"capital"
	] : [...w], a = r.length === t.length && new Set(r).size === t.length ? r : i, o = w.filter((t) => a.includes(t) || t !== "state" && e[`${t}Automa`] !== "off");
	for (let e of ["working", "capital"]) o.includes(e) || o.push(e);
	o.includes("state") && w.forEach((e) => {
		o.includes(e) || o.push(e);
	});
	let s = {
		players: t,
		roles: w.filter((e) => o.includes(e)),
		classes: {
			working: Pn(),
			middle: Pn(),
			capital: Pn(),
			state: Pn()
		},
		seed: n,
		cursor: 0,
		revision: 0,
		round: 1,
		turn: 0,
		turnRole: "working",
		mainDone: !1,
		freeDone: !1,
		phase: "setup",
		jobs: [],
		workers: [],
		companies: [],
		policies: [
			"C",
			"B",
			"A",
			"B",
			"C",
			"B",
			"B"
		],
		bills: [],
		locked: [],
		demonstration: !1,
		bag: [],
		immigrationDeck: [],
		exportDeck: [],
		exportDiscard: [],
		exportCard: 0,
		businessDeck: [],
		businessDiscard: [],
		business: [],
		eventDeck: [],
		eventDiscard: [],
		events: [],
		politicalDeck: [],
		politicalCard: null,
		crisisDeck: [],
		crisisCard: null,
		bonds: [],
		historicalDeck: [],
		historical: null,
		historicalUsed: [],
		election: null,
		laborAtProduction: "B",
		log: [],
		nextId: 1,
		config: e,
		scoreBreakdown: [],
		effect: {
			amount: 0,
			target: null,
			card: null
		},
		roundEffects: {},
		wagesEarned: {
			working: 0,
			middle: 0,
			capital: 0,
			state: 0
		},
		billsPassed: {
			working: 0,
			middle: 0,
			capital: 0,
			state: 0
		}
	};
	a.forEach((e, n) => {
		s.classes[e].rid = t[n];
	});
	for (let t of s.roles) {
		let n = s.classes[t];
		if (n.automa = t === "state" || n.rid ? "off" : e[`${t}Automa`] === "off" ? "simple" : e[`${t}Automa`], n.personal.influence = 1, n.money = t === "working" ? 30 : t === "middle" ? 40 : 120, n.deck = I(s, b.filter((n) => n.role === t && (n.expansion === "base" || e.actionExpansion)).map((e) => e.id)), e.controllingNarrative && n.deck.push(9e4 + w.indexOf(t) * 10), e.rapidResolution && n.deck.push(90001 + w.indexOf(t) * 10), n.deck = I(s, n.deck), n.automa === "off" && (n.hand = n.deck.splice(0, 7)), (t === "capital" || t === "middle") && (n.companyDeck = I(s, y.filter((e) => e.owner === t && !e.initial).map((e) => e.id)), n.market = n.companyDeck.splice(0, t === "capital" ? 4 : 3)), e.hiddenAgendas && (n.agendas = I(s, de.filter((e) => e.role === t).map((e) => e.id)).slice(0, n.automa === "off" ? 2 : 5), n.automa === "off" && s.jobs.push({
			kind: "chooseAgenda",
			actor: t
		})), n.automa !== "off") {
			n.aiDeck = I(s, C.cards.filter((e) => e.role === t).map((e) => e.id));
			let e = C.instructionNotes.initialRows[t];
			n.actionRows = e.actions.map((e) => [...e]), n.policyRows = e.policies.map((e) => e.map((e) => e - 1)), n.policyAside = [...e.setAside].map((e) => e - 1);
		}
	}
	s.roles.includes("state") || (s.classes.state.money = 120);
	let c = s.roles.includes("middle") ? 3 : 2, l = c === 2 ? [
		27400,
		27500,
		27600
	] : [
		18600,
		18700,
		18800
	], u = c === 2 ? [
		26800,
		26900,
		27e3
	] : [
		26800,
		27500,
		27600
	];
	for (let e of y) e.owner === "working" || e.owner === "middle" && !s.roles.includes("middle") || l.includes(e.id) || (e.initial || e.owner === "state") && s.companies.push({
		uid: e.id,
		definition: e.id,
		owner: e.owner,
		wage: 2,
		machinery: !1,
		strike: !1,
		active: e.owner !== "state" || u.includes(e.id)
	});
	let d = (e, t, n) => {
		n.forEach((n, r) => {
			let i = U(s, e, n);
			i.company = t, i.slot = r, k(s, t).active = !0;
		});
	};
	d("working", 12e3, ["food", "any"]), c === 2 ? (d("working", 12001, ["luxury", "any"]), d("working", 27e3, ["health", "any"]), d("working", 26900, ["education", "any"])) : (d("working", 12002, ["education", "any"]), d("working", 27600, [
		"health",
		"any",
		"any"
	]), d("middle", 27500, [
		"education",
		"any",
		"any"
	]), d("middle", 12001, ["luxury", "any"]), d("middle", 12100, ["food"]), d("middle", 12101, ["health"])), s.immigrationDeck = I(s, ce.map((e) => e.id)), U(s, "working", "any"), we(s, "working", c === 2 ? 1 : 2), s.roles.includes("middle") && (s.jobs.push({
		kind: "newSkill",
		actor: "middle"
	}), we(s, "middle", 2), s.classes.middle.storage.food = 1, s.classes.middle.storage.health = 1), s.classes.capital.storage.food = 1, s.classes.capital.storage.luxury = 2, s.classes.capital.storage.education = 2;
	for (let e of [
		"working",
		"middle",
		"capital"
	]) for (let t = 0; t < 8; t += 1) s.bag.push(e);
	if (s.classes.state.storage.health = c === 2 ? 5 : 6, s.classes.state.storage.education = c === 2 ? 5 : 6, s.classes.state.storage.influence = c === 2 ? 3 : 4, s.businessDeck = I(s, ue.flatMap((e) => [e.id, e.id])), s.business.push(s.businessDeck.shift()), s.exportDeck = I(s, le.map((e) => e.id)), s.exportCard = s.exportDeck.shift(), s.roles.includes("state") && (s.eventDeck = I(s, x.filter((t) => t.expansion === (e.alternativeEvents ? "alternative-events" : "base")).map((e) => e.id)), s.politicalDeck = I(s, fe.map((e) => e.id)), s.politicalCard = s.politicalDeck.shift(), s.jobs.push({
		kind: "drawEvents",
		actor: "state",
		n: 2
	})), e.crisisResponse && (s.crisisDeck = I(s, S.map((e) => e.id)), s.crisisCard = s.crisisDeck.shift()), e.historicalEvents) {
		for (let e of [
			0,
			1,
			2,
			3,
			4,
			5
		]) {
			let t = pe.cards.filter((t) => t.period === e);
			s.historicalDeck.push(I(s, t)[0].slot);
		}
		s.jobs.push({
			kind: "historicalSetup",
			actor: "working"
		}, {
			kind: "historicalReveal",
			actor: "working"
		});
	}
	return s.jobs.push({
		kind: "beginAction",
		actor: "working"
	}), s;
}
//#endregion
//#region src/games/hegemony/effects.ts
var In = (e) => e.company === null ? e.union ? `union:${e.union}` : "unemployed" : `slot:${e.company}:${e.slot}`;
function Ln(e, t, n) {
	let r = e.jobs[0], i = r?.actor ?? e.turnRole, a = n?.kind ?? r?.kind ?? "", o = e.phase === "production" ? sn.production : e.election ? sn.election : sn.action, s = [], c = (t, n, r, a = 1, c = {}) => {
		a > 0 && s.push({
			kind: "hegemonyMove",
			rid: e.classes[i].rid ?? void 0,
			data: {
				from: t,
				to: n,
				piece: r,
				amount: a,
				ms: o,
				...c
			},
			with: s.length > 0
		});
	}, l = (e) => s.push({
		kind: "hegemonyPulse",
		data: {
			target: e,
			ms: o
		},
		with: s.length > 0
	});
	if (r?.kind === "cardMenu" && n && n.key !== "cancel" && e.classes[i].hand.includes(r.card) && !t.classes[i].hand.includes(r.card) && c(`hand:${r.card}`, "played", "action", 1, { card: r.card }), r?.kind === "prepClass") {
		let n = t.classes[i].hand.filter((t) => !e.classes[i].hand.includes(t));
		n.length && s.push({
			kind: "hegemonyDraw",
			rid: e.classes[i].rid ?? void 0,
			data: {
				role: i,
				amount: n.length,
				ms: o
			},
			for: e.classes[i].rid ? [e.classes[i].rid] : [],
			secret: { cards: n },
			with: s.length > 0
		});
	}
	for (let n of t.workers) {
		let t = e.workers.find((e) => e.id === n.id);
		!t || In(t) !== In(n) ? c(t ? In(t) : `supply:${n.role}`, In(n), "worker", 1, {
			role: n.role,
			skill: n.skill,
			worker: n.id,
			hide: `worker:${n.id}`
		}) : t.skill !== n.skill && l(`worker:${n.id}`);
	}
	for (let n of e.workers.filter((e) => !t.workers.some((t) => t.id === e.id))) c(In(n), `supply:${n.role}`, "worker", 1, {
		role: n.role,
		skill: n.skill,
		worker: n.id
	});
	for (let n of t.companies.filter((e) => e.active)) {
		let t = e.companies.find((e) => e.uid === n.uid);
		!t || !t.active ? c(`market:${n.definition}`, `company:${n.uid}`, "company", 1, {
			card: n.definition,
			hide: `company:${n.uid}`
		}) : n.owner === t.owner ? (t.wage !== n.wage || t.machinery !== n.machinery || t.strike !== n.strike) && l(`company:${n.uid}`) : c(`class:${t.owner}`, `company:${n.uid}`, "company", 1, {
			card: n.definition,
			hide: `company:${n.uid}`
		});
	}
	for (let n of e.companies.filter((e) => e.active && !t.companies.some((t) => t.uid === e.uid && t.active))) c(`class:${n.owner}`, `market:${n.definition}`, "company", 1, { card: n.definition });
	if (a === "purchase" || a === "eventBuy" || a === "providePurchase") {
		let o = n.key.split(":")[1], s = n.resource, l = a === "purchase" ? "personal" : "storage", u = a === "purchase" ? i : "state";
		c(o === "foreign" ? "foreign" : `storage:${o}:${s}`, r?.kind === "food" ? `class:${u}` : `${l}:${u}:${s}`, s, n.amount), o !== u && o !== "foreign" && c(`class:${u}`, `class:${o}`, "money", Math.max(0, t.classes[o].money - e.classes[o].money));
	}
	if (r?.kind === "produceCompany") {
		let n = e.companies.find((e) => e.uid === r.company);
		if (n) {
			let r = y.find((e) => e.id === n.definition).resource;
			c(`company:${n.uid}`, `storage:${n.owner}:${r}`, r, t.classes[n.owner].storage[r] - e.classes[n.owner].storage[r]);
			for (let r of ["working", "middle"]) c(`company:${n.uid}`, `class:${r}`, "money", t.classes[r].money - e.classes[r].money);
		}
	}
	if (a === "exportTrade" && c(`storage:${i}:${n.resource}`, "export", n.resource, le.find((t) => t.id === e.exportCard).trades[n.amount].quantity), a === "businessDeal") for (let n of ["food", "luxury"]) {
		let r = t.classes[i].storage[n] + t.classes[i].freeTrade[n] - e.classes[i].storage[n] - e.classes[i].freeTrade[n];
		c("foreign", `storage:${i}:${n}`, n, r);
	}
	if (a === "freeUse" && c(`personal:${i}:${n.resource}`, `class:${i}`, n.resource, e.classes[i].personal[n.resource] - t.classes[i].personal[n.resource]), a === "freeBenefits") for (let t of T) c(`benefits:${i}:${t}`, `personal:${i}:${t}`, t, e.classes[i].benefits[t]);
	if (r?.kind === "deliverBenefit") for (let n of t.roles) for (let r of T) c(`storage:state:${r}`, `benefits:${n}:${r}`, r, t.classes[n].benefits[r] - e.classes[n].benefits[r]);
	if (r?.kind === "tax" && c(`class:${i}`, "class:state", "money", Math.max(0, t.classes.state.money - e.classes.state.money)), e.policies.forEach((e, n) => {
		e !== t.policies[n] && c(`policy:${n}:${e}`, `policy:${n}:${t.policies[n]}`, "policy");
	}), r?.kind === "drawElection" && t.election) for (let e of t.election.cubes) c("bag", "election", "vote", 1, { role: e });
	r?.kind === "resolveElection" && l("election"), t.historical !== e.historical && t.historical !== null && c("historyDeck", "history", "history", 1, { card: t.historical }), t.crisisCard !== e.crisisCard && t.crisisCard !== null && c("crisisDeck", "crisis", "crisis", 1, { card: t.crisisCard });
	for (let n of w) t.classes[n].vp !== e.classes[n].vp && s.push({
		kind: "hegemonyScore",
		data: {
			role: n,
			amount: t.classes[n].vp - e.classes[n].vp,
			ms: o
		},
		with: s.length > 0
	});
	return s;
}
//#endregion
//#region src/games/hegemony/outcome.ts
function Rn(e) {
	let t = fe.find((t) => t.id === e.politicalCard), n = (n) => [
		e.classes[n].vp,
		e.policies.slice(0, 5).filter((e, r) => e === (n === "state" ? t?.policies[r] : n === "working" ? "A" : n === "middle" ? "B" : "C")).length,
		Number(n === "state"),
		e.bag.filter((e) => e === n).length
	], r = (e, t) => {
		let r = n(e), i = n(t);
		for (let e = 0; e < r.length; e += 1) if (r[e] !== i[e]) return i[e] - r[e];
		return 0;
	}, i = e.roles.slice().sort(r);
	return {
		ranking: i,
		winners: i.filter((e) => r(e, i[0]) === 0)
	};
}
//#endregion
//#region src/games/hegemony/rules.ts
function zn(e, t) {
	let n = e.roles.find((n) => e.classes[n].rid === t) ?? null, r = ln(e), i = un(e), a = e.jobs[0];
	return {
		public: {
			revision: e.revision,
			round: e.round,
			turn: e.turn,
			turnRole: e.turnRole,
			roles: e.roles,
			phase: e.phase,
			mainDone: e.mainDone,
			freeDone: e.freeDone,
			winnerRoles: e.phase === "done" ? Rn(e).winners : [],
			actor: r,
			automatic: i,
			task: a?.kind ?? null,
			taskText: a?.text ?? null,
			playedCard: e.effect.card,
			classes: [...e.roles, ...e.roles.includes("state") ? [] : ["state"]].map((t) => {
				let n = e.classes[t];
				return {
					role: t,
					rid: n.rid,
					money: n.money,
					capital: n.capital,
					loans: n.loans,
					vp: n.vp,
					prosperity: n.prosperity,
					wealth: n.wealth,
					storage: n.storage,
					personal: n.personal,
					freeTrade: n.freeTrade,
					prices: n.prices,
					benefits: n.benefits,
					expanded: n.expanded,
					legitimacy: n.legitimacy,
					tokens: n.tokens,
					handCount: n.hand.length,
					deckCount: n.deck.length,
					discard: n.discard,
					market: n.market,
					agendaAchieved: n.agendaAchieved,
					visibleAgendas: n.automa === "off" ? [] : n.agendas,
					perks: n.perks,
					automa: n.automa,
					aiCard: n.aiCard,
					actionRows: n.actionRows,
					policyRows: n.policyRows
				};
			}),
			workers: e.workers,
			companies: e.companies,
			policies: e.policies,
			bills: e.bills,
			locked: e.locked,
			demonstration: e.demonstration,
			bagCounts: w.filter((e) => e !== "state").map((t) => ({
				role: t,
				count: e.bag.filter((e) => e === t).length
			})),
			exportCard: e.exportCard,
			business: e.business,
			events: e.events,
			politicalCard: e.politicalCard,
			crisisCard: e.crisisCard,
			historical: e.historical,
			historicalUsed: e.historicalUsed,
			election: e.election ? {
				bill: e.election.bill,
				sides: e.election.sides,
				cubes: e.election.cubes,
				stage: e.election.stage,
				decided: Object.keys(e.election.spending)
			} : null,
			bonds: e.bonds,
			log: e.log,
			scoreBreakdown: e.scoreBreakdown,
			config: e.config
		},
		private: {
			role: n,
			hand: n ? e.classes[n].hand : [],
			agendas: n ? e.classes[n].agendas : [],
			agenda: n ? e.classes[n].agenda : null,
			choices: n === r && !i ? an(e, r) : [],
			moves: n === r ? a?.moves ?? [] : [],
			selected: n === r ? a?.selected ?? null : null,
			influence: n ? e.election?.spending[n] ?? null : null,
			knownSpending: n && n === e.election?.narrative && r === n && a?.kind === "electionInfluence" ? { ...e.election.spending } : {}
		}
	};
}
var Bn = {
	meta: Sn,
	saveCompatibility: { version: "1" },
	schemas: {
		action: kn,
		config: On,
		publicView: Mn,
		privateView: Nn
	},
	setup(e, t, n) {
		return { state: Fn(On.parse(e), t, n) };
	},
	reduce(e, t, n) {
		if (e.phase === "done") return { code: "games.hegemony.errors.finished" };
		let r = structuredClone(e), i = t.type === "choose" ? an(e, ln(e)).find((e) => e.key === t.key) : void 0;
		if (t.type === "tick") {
			if (!un(r)) return { state: e };
			xn(r);
		} else {
			let e = ln(r);
			if (r.classes[e].rid !== n.by || un(r)) return { code: "games.hegemony.errors.turn" };
			if (t.revision !== r.revision) return { code: "games.hegemony.errors.stale" };
			if (!i) return { code: "games.hegemony.errors.invalid" };
			on(r, i);
		}
		return gt(r, e), r.revision += 1, {
			state: r,
			fx: Ln(e, r, i)
		};
	},
	viewFor: zn,
	status(e) {
		let t = Rn(e), n = t.ranking.flatMap((t) => e.classes[t].rid ? [e.classes[t].rid] : []), r = Object.fromEntries(e.roles.filter((t) => e.classes[t].rid).map((t) => [e.classes[t].rid, e.classes[t].vp]));
		return e.phase === "done" ? {
			phase: "done",
			scores: r,
			ranking: n,
			winner: t.winners.flatMap((t) => e.classes[t].rid ? [e.classes[t].rid] : [])
		} : {
			phase: e.phase,
			scores: r
		};
	},
	nextTickIn(e) {
		return un(e) ? e.phase === "production" ? sn.production : e.election ? sn.election : sn.action : null;
	}
}, Vn = {
	"working:+1": "games.hegemony.legitimacyText.l0",
	"working:+1/10 employed workers": "games.hegemony.legitimacyText.l1",
	"working:+1/3 unemployed workers": "games.hegemony.legitimacyText.l2",
	"working:+1,middle:+1": "games.hegemony.legitimacyText.l3",
	"chosen two:-1": "games.hegemony.legitimacyText.l4",
	"target:+2": "games.hegemony.legitimacyText.l5",
	"target:+1": "games.hegemony.legitimacyText.l6",
	"middle:+1,capital:+1": "games.hegemony.legitimacyText.l7",
	"target:+1/10 paid": "games.hegemony.legitimacyText.l8",
	"working:+1,capital:+1": "games.hegemony.legitimacyText.l9",
	"capital:+1/3 companies": "games.hegemony.legitimacyText.l10",
	"capital:+1": "games.hegemony.legitimacyText.l11",
	"target:+1/3 health": "games.hegemony.legitimacyText.l12",
	"capital:+1/3 health": "games.hegemony.legitimacyText.l13",
	"capital:+1/3 education": "games.hegemony.legitimacyText.l14",
	"capital:+1/3 luxury": "games.hegemony.legitimacyText.l15",
	"capital:+1/operational health company": "games.hegemony.legitimacyText.l16",
	"middle:+1": "games.hegemony.legitimacyText.l17",
	"middle:+1/4 goods": "games.hegemony.legitimacyText.l18",
	"middle:+1/3 qualifying companies": "games.hegemony.legitimacyText.l19",
	"middle:+1/3 health": "games.hegemony.legitimacyText.l20",
	"middle:+1/3 education": "games.hegemony.legitimacyText.l21",
	"middle:+1/5 qualifying workers": "games.hegemony.legitimacyText.l22",
	"middle:+1/15 paid": "games.hegemony.legitimacyText.l23",
	"working:-3,middle:-2": "games.hegemony.legitimacyText.l24",
	"each:-1 per 10 collected from that class": "games.hegemony.legitimacyText.l25",
	"each:-2": "games.hegemony.legitimacyText.l26",
	"each:-1": "games.hegemony.legitimacyText.l27",
	"each:half-rounded-up": "games.hegemony.legitimacyText.l28",
	"working:half-rounded-up,middle:half-rounded-up": "games.hegemony.legitimacyText.l29",
	none: "games.hegemony.legitimacyText.l30",
	"capital:-3,middle:-2": "games.hegemony.legitimacyText.l31"
}, Hn = {
	working: "#ed2028",
	middle: "#ffc500",
	capital: "#0097cf",
	state: "#aaaeb0"
}, Un = {
	food: "#869e48",
	luxury: "#009bd0",
	health: "#d90a19",
	education: "#ef9200",
	influence: "#92177f",
	any: "#b2b3b3"
};
function Q({ name: e, className: t = "" }) {
	return /* @__PURE__ */ d("img", {
		className: `hg-art ${t}`,
		src: `games/hegemony/${e}.svg`,
		alt: "",
		draggable: !1
	});
}
function $({ name: e, children: t, className: n = "", style: r }) {
	let { ref: i, hidden: a } = l(e);
	return /* @__PURE__ */ d("div", {
		ref: i,
		className: n,
		style: {
			...r,
			visibility: a ? "hidden" : void 0
		},
		children: t
	});
}
function Wn() {
	return /* @__PURE__ */ d("svg", {
		className: "hg-target",
		width: "100%",
		height: "100%",
		"aria-hidden": !0,
		children: /* @__PURE__ */ d("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "5",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeDasharray: "7 5",
			children: /* @__PURE__ */ d("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-24",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	});
}
function Gn({ worker: e }) {
	return /* @__PURE__ */ f("span", {
		className: "hg-worker-art",
		style: { "--skill-color": Un[e.skill] },
		children: [/* @__PURE__ */ d("span", {
			className: `hg-worker-shape hg-${e.role}`,
			style: { maskImage: `url('games/hegemony/worker-${e.role}.svg')` }
		}), e.skill !== "any" && /* @__PURE__ */ d(Q, { name: e.skill })]
	});
}
function Kn({ worker: e, options: t, onPick: n, preview: r = !1, selected: i = !1 }) {
	let o = a(), s = `${v(D[e.role], o)} · ${e.skill === "any" ? o("games.hegemony.ui.unskilled") : v(E[e.skill], o)} · ${e.id}`;
	return /* @__PURE__ */ d($, {
		name: `worker:${e.id}`,
		className: `hg-worker ${r ? "hg-preview" : ""} ${i ? "hg-selected" : ""}`,
		children: /* @__PURE__ */ f("button", {
			type: "button",
			title: s,
			"aria-label": s,
			disabled: !t.length,
			onClick: () => n(t),
			children: [
				/* @__PURE__ */ d(Gn, { worker: e }),
				e.committed && /* @__PURE__ */ d("span", {
					className: "hg-commit",
					title: o("games.hegemony.ui.committed"),
					children: "●"
				}),
				t.length > 0 && /* @__PURE__ */ d(Wn, {})
			]
		})
	});
}
function qn({ values: e, anchor: t, onPick: n, choices: r = [] }) {
	let i = a();
	return /* @__PURE__ */ d("div", {
		className: "hg-resource-row",
		children: T.map((a) => {
			let o = r.filter((e) => e.resource === a);
			return /* @__PURE__ */ d($, {
				name: `${t}:${a}`,
				className: "hg-resource-cell",
				children: /* @__PURE__ */ f("button", {
					title: v(E[a], i),
					"aria-label": `${v(E[a], i)} ${e[a]}`,
					disabled: !o.length,
					onClick: () => n?.(o),
					children: [
						/* @__PURE__ */ d(Q, { name: a }),
						/* @__PURE__ */ d(s, { value: e[a] }),
						o.length > 0 && /* @__PURE__ */ d(Wn, {})
					]
				})
			}, a);
		})
	});
}
function Jn({ company: e, workers: t = [], choices: n = [], workerChoices: r = [], onPick: i, onInspect: o, previewWorkers: s = [], selected: c }) {
	let l = a(), u = y.find((t) => t.id === e.definition), p = u.workers.length, m = p + +!!u.helper, h = t.length + s.length >= p, ee = n.filter((e) => e.kind !== "slot" && e.kind !== "wage" && e.kind !== "assignmentPlan"), te = n.filter((e) => e.kind === "wage");
	return /* @__PURE__ */ f($, {
		name: `company:${e.uid}`,
		className: `hg-company ${e.active ? "" : "hg-inactive"} ${e.strike ? "hg-striking" : ""}`,
		style: {
			"--industry": Un[u.resource],
			"--owner": Hn[e.owner]
		},
		children: [
			/* @__PURE__ */ f("div", {
				className: "hg-company-title",
				children: [/* @__PURE__ */ f("button", {
					onClick: () => ee.length ? i(ee) : o(),
					children: [/* @__PURE__ */ d("strong", { children: v(_(u.name), l) }), ee.length > 0 && /* @__PURE__ */ d(Wn, {})]
				}), /* @__PURE__ */ d("button", {
					className: "hg-info",
					"aria-label": `${l("games.hegemony.ui.details")} ${v(_(u.name), l)}`,
					onClick: o,
					children: "ⓘ"
				})]
			}),
			/* @__PURE__ */ f("div", {
				className: "hg-company-stats",
				children: [
					/* @__PURE__ */ f("span", {
						title: l("games.hegemony.ui.output"),
						children: [/* @__PURE__ */ d(Q, { name: u.resource }), /* @__PURE__ */ d("b", { children: u.production + (e.machinery ? u.machineryBonus : 0) + (t.some((e) => e.role === "working") && e.owner === "middle" && u.helper ? u.helper.bonus : 0) })]
					}),
					/* @__PURE__ */ f("span", {
						title: l("games.hegemony.ui.cost"),
						children: [u.cost, /* @__PURE__ */ d("small", { children: l("games.hegemony.ui.money") })]
					}),
					e.machinery && /* @__PURE__ */ d(Q, { name: "machine" }),
					e.strike && /* @__PURE__ */ d(Q, { name: "strike" })
				]
			}),
			/* @__PURE__ */ d("div", {
				className: "hg-wage-track",
				"aria-label": l("games.hegemony.ui.wages"),
				children: u.wages.map((t, n) => {
					let r = te.filter((e) => e.amount === n + 1);
					return /* @__PURE__ */ f("button", {
						className: e.wage === n + 1 ? "hg-current" : "",
						disabled: !r.length,
						onClick: () => i(r),
						title: l("games.hegemony.ui.level", { level: n + 1 }),
						children: [
							/* @__PURE__ */ f("small", { children: ["L", n + 1] }),
							t,
							r.length > 0 && /* @__PURE__ */ d(Wn, {})
						]
					}, n);
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "hg-slots",
				children: [Array.from({ length: m }, (a, o) => {
					let m = s.find((e) => e.slot === o) ?? t.find((e) => e.slot === o), h = n.filter((e) => e.kind === "slot" && e.amount === o), ee = (o >= p ? u.helper?.skill : u.workers[o]) === "skill" ? u.resource : "any";
					return /* @__PURE__ */ d($, {
						name: `slot:${e.uid}:${o}`,
						className: `hg-slot ${m && s.includes(m) ? "hg-preview" : ""}`,
						children: m ? /* @__PURE__ */ d(Kn, {
							worker: m,
							options: h.length ? h : r.filter((e) => e.worker === m.id),
							onPick: i,
							preview: s.includes(m),
							selected: c === m.id
						}) : /* @__PURE__ */ f("button", {
							className: "hg-vacant",
							disabled: !h.length,
							onClick: () => i(h),
							"aria-label": `${l("games.hegemony.ui.vacant")} ${o + 1}`,
							children: [
								/* @__PURE__ */ d("span", {
									className: "hg-worker-shape",
									style: { maskImage: `url('games/hegemony/worker-${o >= p ? "working" : e.owner === "middle" ? "middle" : "working"}.svg')` }
								}),
								ee !== "any" && /* @__PURE__ */ d(Q, { name: ee }),
								h.length > 0 && /* @__PURE__ */ d(Wn, {})
							]
						})
					}, o);
				}), /* @__PURE__ */ d("span", {
					className: "hg-operation",
					children: e.active ? l(h ? "games.hegemony.ui.operating" : "games.hegemony.ui.notOperating") : l("games.hegemony.ui.inactive")
				})]
			})
		]
	});
}
function Yn(e, t) {
	return e === "company" ? y.find((e) => e.id === t)?.name ?? "" : e === "event" ? x.find((e) => e.id === t)?.name ?? "" : e === "agenda" ? de.find((e) => e.id === t)?.name ?? "" : e === "history" ? pe.cards.find((e) => e.slot === t)?.name ?? "" : e === "crisis" ? S.find((e) => e.id === t)?.name ?? "" : t >= 9e4 ? t % 10 == 0 ? "Controlling the Narrative" : "Rapid Resolution" : b.find((e) => e.id === t)?.name ?? "";
}
function Xn({ kind: e, id: t }) {
	let n = a(), r = e === "action" ? b.find((e) => e.id === t) : void 0, i = e === "action" ? ae[t] : oe[`${e === "agenda" ? "agenda" : e === "history" ? "history" : e}${t}`], o = e === "history" ? pe.cards.find((e) => e.slot === t) : void 0, s = e === "event" ? x.find((e) => e.id === t) : void 0, c = e === "agenda" ? de.find((e) => e.id === t) : void 0, l = e === "crisis" ? S.find((e) => e.id === t) : void 0, p = e === "company" ? y.find((e) => e.id === t) : void 0, m = (e) => oe[e] ? n(oe[e]) : "";
	return /* @__PURE__ */ f("div", {
		className: "hg-card-body",
		children: [
			r?.requirement && /* @__PURE__ */ f("p", {
				className: "hg-requirement",
				children: [
					n("games.hegemony.ui.requirement"),
					"：",
					r.requirement.split("/").map((e) => `${v(he[Number(e[0]) - 1], n)} ${e[1]}`).join(" / ")
				]
			}),
			(o || c) && /* @__PURE__ */ f("p", {
				className: "hg-requirement",
				children: [
					n("games.hegemony.ui.timing"),
					"：",
					n(`games.hegemony.timing.${o?.trigger ?? c.timing}`)
				]
			}),
			o && Array.isArray(o.roles) && /* @__PURE__ */ f("p", { children: [
				n("games.hegemony.ui.eligibleRoles"),
				"：",
				o.roles.map((e) => v(D[e], n)).join(" / ")
			] }),
			o && oe[`historyReq${t}`] && /* @__PURE__ */ f("p", {
				className: "hg-requirement",
				children: [
					n("games.hegemony.ui.requirement"),
					"：",
					m(`historyReq${t}`)
				]
			}),
			i && /* @__PURE__ */ d("p", { children: n(i) }),
			e === "action" && t >= 9e4 && /* @__PURE__ */ d("p", { children: n(t % 10 == 0 ? "games.hegemony.promo.narrative" : "games.hegemony.promo.rapid") }),
			r?.legitimacy && /* @__PURE__ */ d("p", {
				className: "hg-requirement",
				children: n(Vn[r.legitimacy])
			}),
			l && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("h4", { children: n("games.hegemony.ui.policyChanges") }),
				/* @__PURE__ */ d("div", {
					className: "hg-crisis-policies",
					children: l.policies.map((e, t) => e !== "-" && /* @__PURE__ */ f("span", { children: [
						v(he[t], n),
						" ",
						/* @__PURE__ */ d("b", { children: e })
					] }, t))
				}),
				l.locks.length > 0 && /* @__PURE__ */ f("p", { children: [
					n("games.hegemony.ui.policyLocks"),
					"：",
					l.locks.map((e) => v(he[e - 1], n)).join(" / ")
				] }),
				/* @__PURE__ */ f("p", { children: [
					n("games.hegemony.ui.discardBills"),
					"：",
					l.discardBills === "all" ? n("games.hegemony.ui.allBills") : l.discardBills.map((e) => v(he[e - 1], n)).join(" / ") || "—"
				] }),
				Vn[l.legitimacy] && /* @__PURE__ */ d("p", {
					className: "hg-requirement",
					children: n(Vn[l.legitimacy])
				})
			] }),
			s && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("h4", { children: n("games.hegemony.ui.reward") }),
				/* @__PURE__ */ d("p", { children: m(`reward${t}`) }),
				/* @__PURE__ */ d("h4", { children: n("games.hegemony.ui.penalty") }),
				/* @__PURE__ */ d("p", { children: n(s.penalty === "any2" ? "games.hegemony.eventPenalty.any" : "games.hegemony.eventPenalty.list", { roles: s.penalty.split("").map((e) => v(D[e === "W" ? "working" : e === "M" ? "middle" : "capital"], n)).join(" / ") }) }),
				oe[`benefit${t}`] && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("h4", { children: n("games.hegemony.ui.benefit") }), /* @__PURE__ */ d("p", { children: m(`benefit${t}`) })] })
			] }),
			c && /* @__PURE__ */ f("p", {
				className: "hg-card-vp",
				children: [/* @__PURE__ */ d(Q, { name: "vp" }), c.vp]
			}),
			p && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ f("div", {
					className: "hg-company-stats",
					children: [
						/* @__PURE__ */ d(Q, { name: p.resource }),
						n("games.hegemony.ui.output"),
						" ",
						p.production,
						/* @__PURE__ */ f("span", { children: [
							n("games.hegemony.ui.cost"),
							" ",
							p.cost
						] })
					]
				}),
				/* @__PURE__ */ f("p", { children: [
					n("games.hegemony.ui.wages"),
					"：",
					p.wages.join(" / ") || "0"
				] }),
				/* @__PURE__ */ d("div", {
					className: "hg-detail-workers",
					children: p.workers.map((e, t) => /* @__PURE__ */ d(Gn, { worker: {
						role: p.owner === "middle" ? "middle" : "working",
						skill: e === "skill" ? p.resource : "any"
					} }, t))
				}),
				p.helper && /* @__PURE__ */ f("p", { children: [
					n("games.hegemony.ui.helper"),
					" ",
					/* @__PURE__ */ d(Gn, { worker: {
						role: "working",
						skill: p.helper.skill === "skill" ? p.resource : "any"
					} }),
					" · ",
					n("games.hegemony.ui.extraOutput"),
					" ",
					p.helper.bonus
				] }),
				p.machineryBonus > 0 && /* @__PURE__ */ f("p", { children: [
					/* @__PURE__ */ d(Q, { name: "machine" }),
					" ",
					n("games.hegemony.ui.extraOutput"),
					" ",
					p.machineryBonus
				] })
			] })
		]
	});
}
function Zn({ kind: e, id: t, onPick: n, available: r = !1, compact: i = !1 }) {
	let o = a(), s = e === "action" ? b.find((e) => e.id === t) : void 0, c = e === "company" ? y.find((e) => e.id === t) : void 0, l = s ? Hn[s.role] : c ? Un[c.resource] : "#ad8741";
	return /* @__PURE__ */ f("button", {
		className: `hg-card-face ${i ? "hg-card-compact" : ""}`,
		style: { "--card-color": l },
		onClick: n,
		children: [
			/* @__PURE__ */ d("strong", { children: v(_(Yn(e, t)), o) }),
			/* @__PURE__ */ d(Xn, {
				kind: e,
				id: t
			}),
			r && /* @__PURE__ */ d(Wn, {})
		]
	});
}
//#endregion
//#region src/games/hegemony/view-player.tsx
var Qn = {
	role: null,
	hand: [],
	agendas: [],
	agenda: null,
	choices: [],
	moves: [],
	selected: null,
	influence: null,
	knownSpending: {}
}, $n = {
	setup: "games.hegemony.ui.setup",
	preparation: "games.hegemony.ui.preparation",
	action: "games.hegemony.ui.action",
	production: "games.hegemony.ui.production",
	elections: "games.hegemony.ui.elections",
	scoring: "games.hegemony.ui.scoring",
	done: "games.hegemony.ui.done"
}, er = [
	"#0085ad",
	"#77649c",
	"#a64e98",
	"#be1629",
	"#ca8317",
	"#957248",
	"#7a858c"
];
function tr(e) {
	let t = a(), n = e.public, r = e.private ?? Qn, [l, p] = i(null), [m, h] = i(!1), [ee, te] = i([]), [ne, re] = i(!1), [ie, ae] = i(null), [oe, se] = i(null), [g, b] = i(!1), [x, ce] = i(!1), S = n.phase === "done" ? [] : r.choices, pe = n.classes.find((e) => e.role === r.role), C = n.classes.find((e) => e.role === ie) ?? pe ?? n.classes[0], w = [
		"propose",
		"directPolicy",
		"protectPolicy",
		"removeBill",
		"event",
		"eventTask",
		"eventTarget",
		"electionSides",
		"electionInfluence"
	].includes(n.task ?? "") ? "government" : n.task === "chooseAgenda" ? "class" : "economy", me = oe?.task === n.task ? oe.tab : w, O = (e) => se({
		task: n.task,
		tab: e
	}), k = (e) => v(D[e], t), A = (t) => {
		e.send({
			type: "choose",
			revision: n.revision,
			key: t.key
		}), te([]);
	}, j = (e) => {
		e.length === 1 ? A(e[0]) : te(e.map((e) => e.key));
	}, M = (e, t) => {
		p({
			kind: e,
			id: t
		}), h(!0);
	}, N = (e) => S.filter((t) => t.company === e), F = S.filter((e) => e.worker !== void 0 && e.kind !== "slot"), ge = n.workers.map((e) => {
		let t = r.moves.find((t) => t.worker === e.id);
		return t ? {
			...e,
			company: t.company,
			slot: t.slot,
			union: t.union
		} : e;
	}), _e = new Set(r.moves.map((e) => e.worker)), I = S.find((e) => e.kind === "playEffect")?.card, ve = S.filter((e) => e.kind !== "hand" && e.kind !== "slot" && e.kind !== "selectWorker" && e.kind !== "bill" && e.kind !== "buildCompany" && e.kind !== "eventCard" && e.kind !== "agenda" && ![
		"assignmentPlan",
		"businessDeal",
		"exportTrade",
		"triggerHistory",
		"union"
	].includes(e.kind) && e.company === void 0 && e.worker === void 0 && ![
		"purchase",
		"eventBuy",
		"providePurchase"
	].includes(e.kind)), L = ee.flatMap((e) => S.filter((t) => t.key === e)), R = [.../* @__PURE__ */ new Set([...C.market, ...S.filter((e) => e.kind === "buildCompany" && e.card !== void 0).map((e) => e.card)])], ye = (e, t) => S.filter((n) => n.resource === t && (n.role === e || n.key.includes(`:${e}:`)) && [
		"purchase",
		"eventBuy",
		"providePurchase"
	].includes(n.kind)), z = (e) => n.classes.find((t) => t.role === e), be = (e) => /* @__PURE__ */ d(Jn, {
		company: e,
		workers: ge.filter((t) => t.company === e.uid && !_e.has(t.id)),
		previewWorkers: ge.filter((t) => t.company === e.uid && _e.has(t.id)),
		choices: N(e.uid),
		workerChoices: F,
		selected: r.selected,
		onPick: j,
		onInspect: () => M("company", e.definition)
	}, e.uid), B = (r) => {
		let i = z(r), a = e.members.find((e) => e.rid === i.rid);
		return /* @__PURE__ */ d($, {
			name: `class:${r}`,
			className: `hg-class-ledger ${n.actor === r && n.phase !== "done" ? "hg-active-class" : ""}`,
			style: { "--role": Hn[r] },
			children: /* @__PURE__ */ f("button", {
				onClick: () => {
					ae(r), O("class");
				},
				className: "hg-ledger-button",
				children: [
					/* @__PURE__ */ d(Q, { name: `role-${r}` }),
					/* @__PURE__ */ f("span", { children: [
						/* @__PURE__ */ d("strong", { children: k(r) }),
						/* @__PURE__ */ d("small", { children: i.automa === "off" ? a?.name ?? "" : `${t("games.hegemony.ui.automa")} · ${t(i.automa === "simple" ? "games.hegemony.ui.simple" : "games.hegemony.ui.advanced")}` }),
						/* @__PURE__ */ f("span", {
							className: "hg-ledger-values",
							children: [
								/* @__PURE__ */ f("span", { children: [
									t(r === "capital" ? "games.hegemony.ui.revenue" : "games.hegemony.ui.money"),
									" ",
									/* @__PURE__ */ d(s, { value: i.money })
								] }),
								r === "capital" && /* @__PURE__ */ f("span", { children: [
									t("games.hegemony.ui.capital"),
									" ",
									/* @__PURE__ */ d(s, { value: i.capital })
								] }),
								(r === "working" || r === "middle") && /* @__PURE__ */ f("span", { children: [
									t("games.hegemony.ui.population"),
									" ",
									P(n, r)
								] })
							]
						})
					] }),
					/* @__PURE__ */ f("span", {
						className: "hg-score",
						children: [/* @__PURE__ */ d(s, { value: i.vp }), /* @__PURE__ */ d(Q, { name: "vp" })]
					})
				]
			})
		}, r);
	}, xe = /* @__PURE__ */ f("div", {
		className: "hg-topline",
		children: [
			/* @__PURE__ */ d("b", {
				className: "hg-wordmark",
				children: "HEGEMONY"
			}),
			/* @__PURE__ */ d("span", { children: t("games.hegemony.ui.round", { round: n.round }) }),
			/* @__PURE__ */ d("span", { children: t($n[n.phase]) }),
			/* @__PURE__ */ d("span", {
				className: "hg-turn-label",
				children: n.phase === "done" ? t("games.hegemony.ui.readonly") : n.automatic ? t("games.hegemony.ui.resolving") : n.actor === r.role ? t("games.hegemony.ui.yourTurn") : t("games.hegemony.ui.waiting", { role: k(n.actor) })
			}),
			/* @__PURE__ */ d("button", {
				onClick: () => re(!0),
				children: t("games.hegemony.ui.log")
			})
		]
	}), V = /* @__PURE__ */ f("div", {
		className: "hg-action-desk",
		children: [/* @__PURE__ */ d("div", {
			className: "hg-hand",
			"aria-label": t("games.hegemony.ui.hand"),
			children: /* @__PURE__ */ f($, {
				name: "hand",
				className: "hg-hand-cards",
				children: [r.hand.map((e) => /* @__PURE__ */ d($, {
					name: `hand:${e}`,
					children: /* @__PURE__ */ d(Zn, {
						kind: "action",
						id: e,
						compact: !0,
						available: S.some((t) => t.kind === "hand" && t.card === e),
						onPick: () => {
							M("action", e);
						}
					})
				}, e)), !r.hand.length && /* @__PURE__ */ d("span", {
					className: "hg-empty-hand",
					children: t("games.hegemony.ui.noHand")
				})]
			})
		}), /* @__PURE__ */ f("div", {
			className: "hg-actions",
			children: [/* @__PURE__ */ d("div", {
				className: "hg-action-status",
				children: n.taskText ? v(n.taskText, t) : r.selected === null ? n.task === "assign" ? t("games.hegemony.ui.selectWorker") : n.phase === "done" ? t("games.hegemony.ui.readonly") : t(n.mainDone ? "games.hegemony.ui.mainDone" : "games.hegemony.ui.mainReady") : t("games.hegemony.ui.selectDestination")
			}), /* @__PURE__ */ f("div", {
				className: "hg-action-buttons",
				children: [
					I !== void 0 && /* @__PURE__ */ f("button", {
						className: "hg-quiet",
						onClick: () => M("action", I),
						children: [v(_(Yn("action", I)), t), " ⓘ"]
					}),
					ve.map((e) => /* @__PURE__ */ f("button", {
						className: `hg-action ${e.key === "cancel" || e.key === "backWorker" || e.key === "skip" ? "hg-quiet" : ""}`,
						onClick: () => A(e),
						children: [e.resource && /* @__PURE__ */ d(Q, { name: e.resource }), v(e.text, t)]
					}, e.key)),
					S.some((e) => e.kind === "buildCompany") && /* @__PURE__ */ d("button", {
						className: "hg-action",
						onClick: () => b(!0),
						children: t("games.hegemony.ui.market")
					}),
					!S.length && /* @__PURE__ */ d("span", { children: n.automatic ? t("games.hegemony.ui.resolving") : n.phase === "done" ? t("games.hegemony.ui.readonly") : t("games.hegemony.ui.waiting", { role: k(n.actor) }) })
				]
			})]
		})]
	});
	return /* @__PURE__ */ f(c, {
		adaptive: !0,
		scroll: !1,
		className: "hegemony",
		banner: /* @__PURE__ */ f("div", {
			className: "hg-header",
			children: [xe, /* @__PURE__ */ d("div", {
				className: "hg-ledgers",
				style: { gridTemplateColumns: `repeat(${n.roles.length},minmax(0,1fr))` },
				children: n.roles.map(B)
			})]
		}),
		actionsHeight: "hg-desk-height",
		actions: V,
		children: [
			/* @__PURE__ */ f("div", {
				className: `hg-main hg-tab-${me}`,
				children: [
					/* @__PURE__ */ d("nav", {
						className: "hg-mobile-tabs",
						children: [
							["economy", t("games.hegemony.ui.board")],
							["government", t("games.hegemony.ui.government")],
							["class", t("games.hegemony.ui.classBoard")]
						].map(([e, t]) => /* @__PURE__ */ d("button", {
							className: me === e ? "hg-tab-active" : "",
							onClick: () => O(e),
							children: t
						}, e))
					}),
					/* @__PURE__ */ f("section", {
						className: "hg-government",
						children: [
							/* @__PURE__ */ d($, {
								name: "governmentDeck",
								children: /* @__PURE__ */ d("h2", { children: t("games.hegemony.ui.policies") })
							}),
							/* @__PURE__ */ d("div", {
								className: "hg-policy-table",
								children: n.policies.map((e, r) => /* @__PURE__ */ f("div", {
									className: "hg-policy-row",
									style: { "--policy": er[r] },
									children: [
										/* @__PURE__ */ d("span", {
											className: "hg-policy-no",
											children: r + 1
										}),
										/* @__PURE__ */ d("strong", { children: v(he[r], t) }),
										/* @__PURE__ */ d("div", {
											className: "hg-policy-options",
											children: [
												"A",
												"B",
												"C"
											].map((i) => {
												let a = S.filter((e) => e.policy === r && e.kind === "bill" && e.key.endsWith(`:${i}`)), o = n.bills.filter((e) => e.policy === r && e.target === i);
												return /* @__PURE__ */ d($, {
													name: `policy:${r}:${i}`,
													children: /* @__PURE__ */ f("button", {
														disabled: !a.length,
														className: e === i ? "hg-policy-current" : "",
														onClick: () => j(a),
														children: [
															/* @__PURE__ */ d("b", { children: i }),
															e === i && /* @__PURE__ */ d("span", { className: "hg-policy-marker" }),
															o.map((e) => /* @__PURE__ */ d("span", {
																className: "hg-bill-token",
																style: { background: Hn[e.role] },
																title: `${k(e.role)} · ${t("games.hegemony.ui.pending")}`,
																children: e.protected ? "×" : "●"
															}, e.role)),
															a.length > 0 && /* @__PURE__ */ d(Wn, {})
														]
													})
												}, i);
											})
										})
									]
								}, r))
							}),
							/* @__PURE__ */ d("button", {
								className: "hg-rule-link",
								onClick: () => ce(!0),
								children: t("games.hegemony.ui.taxTable")
							}),
							/* @__PURE__ */ f("div", {
								className: "hg-trade",
								children: [
									/* @__PURE__ */ d("h2", { children: t("games.hegemony.ui.foreignTrade") }),
									/* @__PURE__ */ f($, {
										name: "foreign",
										className: "hg-foreign",
										children: [/* @__PURE__ */ d("strong", { children: t("games.hegemony.ui.foreign") }), ["food", "luxury"].map((e) => /* @__PURE__ */ f("button", {
											disabled: !S.some((t) => t.resource === e && [
												"purchase",
												"eventBuy",
												"providePurchase"
											].includes(t.kind) && t.key.includes(":foreign:")),
											onClick: () => j(S.filter((t) => t.resource === e && [
												"purchase",
												"eventBuy",
												"providePurchase"
											].includes(t.kind) && t.key.includes(":foreign:"))),
											children: [
												/* @__PURE__ */ d(Q, { name: e }),
												/* @__PURE__ */ d("span", { children: e === "food" ? 10 : 6 }),
												/* @__PURE__ */ f("small", { children: [
													t("games.hegemony.ui.tariff"),
													" ",
													[
														e === "food" ? 10 : 6,
														e === "food" ? 5 : 3,
														0
													]["ABC".indexOf(n.policies[5])]
												] })
											]
										}, e))]
									}),
									/* @__PURE__ */ f($, {
										name: "export",
										className: "hg-trade-card",
										children: [/* @__PURE__ */ d("h3", { children: t("games.hegemony.ui.export") }), le.find((e) => e.id === n.exportCard)?.trades.map((e, t) => {
											let n = S.filter((e) => e.kind === "exportTrade" && e.amount === t);
											return /* @__PURE__ */ f("button", {
												disabled: !n.length,
												onClick: () => j(n),
												children: [
													/* @__PURE__ */ d(Q, { name: e.resource }),
													e.quantity,
													/* @__PURE__ */ d("span", { children: "→" }),
													e.money,
													n.length > 0 && /* @__PURE__ */ d(Wn, {})
												]
											}, t);
										})]
									}),
									/* @__PURE__ */ d("div", {
										className: "hg-deals",
										children: n.business.map((e, n) => {
											let r = ue.find((t) => t.id === e), i = S.filter((e) => e.kind === "businessDeal" && e.amount === n);
											return /* @__PURE__ */ f("button", {
												disabled: !i.length,
												onClick: () => j(i),
												children: [
													/* @__PURE__ */ d("h3", { children: t("games.hegemony.ui.deal") }),
													/* @__PURE__ */ f("span", { children: [
														/* @__PURE__ */ d(Q, { name: "food" }),
														r.food,
														" ",
														/* @__PURE__ */ d(Q, { name: "luxury" }),
														r.luxury
													] }),
													/* @__PURE__ */ d("b", { children: r.cost }),
													i.length > 0 && /* @__PURE__ */ d(Wn, {})
												]
											}, `${e}:${n}`);
										})
									})
								]
							}),
							n.events.length > 0 && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("h2", { children: t("games.hegemony.ui.events") }), /* @__PURE__ */ d("div", {
								className: "hg-public-cards",
								children: n.events.map((e) => /* @__PURE__ */ d(Zn, {
									kind: "event",
									id: e,
									available: S.some((t) => t.kind === "eventCard" && t.card === e),
									onPick: () => {
										M("event", e);
									}
								}, e))
							})] }),
							n.historical !== null && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("h2", { children: t("games.hegemony.ui.history") }), /* @__PURE__ */ d($, {
								name: "history",
								children: /* @__PURE__ */ d(Zn, {
									kind: "history",
									id: n.historical,
									available: S.some((e) => e.kind === "triggerHistory"),
									onPick: () => {
										let e = S.filter((e) => e.kind === "triggerHistory");
										e.length ? j(e) : M("history", n.historical);
									}
								})
							})] }),
							n.crisisCard !== null && /* @__PURE__ */ d($, {
								name: "crisis",
								children: /* @__PURE__ */ d(Zn, {
									kind: "crisis",
									id: n.crisisCard,
									onPick: () => M("crisis", n.crisisCard)
								})
							}),
							n.election && /* @__PURE__ */ f($, {
								name: "election",
								className: "hg-election",
								children: [
									/* @__PURE__ */ f("h2", { children: [
										t("games.hegemony.ui.bill"),
										" · ",
										v(he[n.election.bill.policy], t),
										" → ",
										n.election.bill.target
									] }),
									/* @__PURE__ */ d("div", {
										className: "hg-ballots",
										children: n.election.cubes.map((e, t) => /* @__PURE__ */ d("span", {
											style: { backgroundColor: Hn[e] },
											title: k(e)
										}, t))
									}),
									n.roles.map((e) => /* @__PURE__ */ f("div", { children: [
										k(e),
										" · ",
										n.election.sides[e] === void 0 ? "—" : t(n.election.sides[e] ? "games.hegemony.ui.support" : "games.hegemony.ui.oppose"),
										n.election.decided.includes(e) && /* @__PURE__ */ f("small", { children: [" · ", t("games.hegemony.ui.sealed")] }),
										r.knownSpending[e] !== void 0 && /* @__PURE__ */ f("b", { children: [" · ", r.knownSpending[e]] })
									] }, e))
								]
							}),
							/* @__PURE__ */ f($, {
								name: "bag",
								className: "hg-bag",
								children: [t("games.hegemony.ui.bag"), n.bagCounts.map((e) => /* @__PURE__ */ f("span", {
									style: { color: Hn[e.role] },
									children: [/* @__PURE__ */ d(Q, { name: `role-${e.role}` }), e.count]
								}, e.role))]
							})
						]
					}),
					/* @__PURE__ */ f("section", {
						className: "hg-economy",
						style: { backgroundImage: "linear-gradient(#26323dd9,#26323de8),url('games/hegemony/streets.svg')" },
						children: [
							/* @__PURE__ */ f($, {
								name: "table",
								className: "hg-played",
								children: [
									/* @__PURE__ */ d($, {
										name: "played",
										className: "hg-played-card",
										children: n.playedCard !== null && /* @__PURE__ */ f("button", {
											onClick: () => M("action", n.playedCard),
											children: [v(_(Yn("action", n.playedCard)), t), " ⓘ"]
										})
									}),
									/* @__PURE__ */ d("span", { children: t("games.hegemony.ui.turn", { turn: Math.min(5, Math.floor(n.turn / n.roles.length) + 1) }) }),
									n.log.at(-1) && /* @__PURE__ */ d("span", { children: v(n.log.at(-1).text, t) })
								]
							}),
							[
								"state",
								"capital",
								"middle",
								"working"
							].filter((e) => e === "state" || n.roles.includes(e)).map((e) => {
								let r = n.companies.filter((t) => t.owner === e && (t.active || N(t.uid).length > 0));
								return r.length > 0 && /* @__PURE__ */ f("div", {
									className: "hg-sector",
									children: [/* @__PURE__ */ f("h2", {
										style: { color: Hn[e] },
										children: [
											/* @__PURE__ */ d(Q, { name: e === "working" ? "role-working" : `company-${e}` }),
											e === "state" ? t("games.hegemony.ui.publicSector") : k(e),
											/* @__PURE__ */ d("small", { children: t("games.hegemony.ui.companyCount", { count: r.filter((e) => e.active).length }) })
										]
									}), /* @__PURE__ */ d("div", {
										className: "hg-company-grid",
										children: r.map(be)
									})]
								}, e);
							}),
							/* @__PURE__ */ f("div", {
								className: "hg-labor-pool",
								children: [
									/* @__PURE__ */ d("h2", { children: t("games.hegemony.ui.unemployed") }),
									/* @__PURE__ */ d($, {
										name: "unemployed",
										className: "hg-unemployed",
										children: ge.filter((e) => e.company === null && !e.union).map((e) => /* @__PURE__ */ d(Kn, {
											worker: e,
											options: F.filter((t) => t.worker === e.id),
											onPick: j,
											selected: r.selected === e.id,
											preview: _e.has(e.id)
										}, e.id))
									}),
									/* @__PURE__ */ d("h2", { children: t("games.hegemony.ui.unions") }),
									/* @__PURE__ */ d("div", {
										className: "hg-unions",
										children: T.map((e) => /* @__PURE__ */ d($, {
											name: `union:${e}`,
											className: "hg-union",
											children: /* @__PURE__ */ f("button", {
												disabled: !S.some((t) => t.kind === "union" && t.resource === e),
												onClick: () => j(S.filter((t) => t.kind === "union" && t.resource === e)),
												children: [
													/* @__PURE__ */ d(Q, { name: e }),
													ge.filter((t) => t.union === e).map((e) => /* @__PURE__ */ d("span", { children: e.id }, e.id)),
													S.some((t) => t.kind === "union" && t.resource === e) && /* @__PURE__ */ d(Wn, {})
												]
											})
										}, e))
									})
								]
							}),
							S.some((e) => e.kind === "assignmentPlan") && /* @__PURE__ */ f("div", {
								className: "hg-plans",
								children: [/* @__PURE__ */ d("h2", { children: t("games.hegemony.ui.assignmentPreview") }), S.filter((e) => e.kind === "assignmentPlan").map((e) => /* @__PURE__ */ d("button", {
									onClick: () => {
										let t = e.key.slice(15).split(";");
										te([e.key]), t.length && O("economy");
									},
									children: v(e.text, t)
								}, e.key))]
							})
						]
					}),
					/* @__PURE__ */ f("section", {
						className: "hg-class-panel",
						children: [
							/* @__PURE__ */ d("div", {
								className: "hg-class-tabs",
								children: n.roles.map((e) => /* @__PURE__ */ f("button", {
									className: e === C.role ? "hg-tab-active" : "",
									style: { "--role": Hn[e] },
									onClick: () => ae(e),
									children: [/* @__PURE__ */ d(Q, { name: `role-${e}` }), k(e)]
								}, e))
							}),
							/* @__PURE__ */ d("h2", {
								style: { color: Hn[C.role] },
								children: k(C.role)
							}),
							/* @__PURE__ */ f("div", {
								className: "hg-track-readings",
								children: [
									/* @__PURE__ */ f("span", { children: [
										t(C.role === "capital" ? "games.hegemony.ui.wealth" : "games.hegemony.ui.prosperity"),
										" ",
										/* @__PURE__ */ d("b", { children: C.role === "capital" ? C.wealth : C.prosperity })
									] }),
									/* @__PURE__ */ f("span", { children: [
										t("games.hegemony.ui.loans"),
										" ",
										/* @__PURE__ */ d("b", { children: C.loans })
									] }),
									n.roles.includes("state") && C.role !== "state" && /* @__PURE__ */ f("span", { children: [
										t("games.hegemony.ui.legitimacy"),
										" ",
										/* @__PURE__ */ d("b", { children: C.legitimacy }),
										" · ",
										C.tokens
									] })
								]
							}),
							/* @__PURE__ */ d($, {
								name: "marketDeck",
								children: /* @__PURE__ */ d("h3", { children: t("games.hegemony.ui.storage") })
							}),
							/* @__PURE__ */ d(qn, {
								values: C.storage,
								anchor: `storage:${C.role}`,
								choices: T.flatMap((e) => ye(C.role, e)),
								onPick: j
							}),
							/* @__PURE__ */ d("h3", { children: t("games.hegemony.ui.personal") }),
							/* @__PURE__ */ d(qn, {
								values: C.personal,
								anchor: `personal:${C.role}`
							}),
							/* @__PURE__ */ d("h3", { children: t("games.hegemony.ui.benefits") }),
							/* @__PURE__ */ d(qn, {
								values: C.benefits,
								anchor: `benefits:${C.role}`
							}),
							/* @__PURE__ */ f("p", { children: [
								t("games.hegemony.ui.money"),
								" ",
								C.benefits.money,
								" · ",
								t("games.hegemony.ui.votes"),
								" ",
								C.benefits.votes
							] }),
							n.classes.filter((e) => e.role !== C.role).map((e) => /* @__PURE__ */ f("div", {
								className: "hg-source-stock",
								children: [/* @__PURE__ */ f("h3", { children: [
									k(e.role),
									" · ",
									t("games.hegemony.ui.storage")
								] }), /* @__PURE__ */ d(qn, {
									values: e.storage,
									anchor: `source:${e.role}`,
									choices: T.flatMap((t) => ye(e.role, t)),
									onPick: j
								})]
							}, e.role)),
							C.role === "capital" || C.role === "middle" ? /* @__PURE__ */ f(u, { children: [
								/* @__PURE__ */ d("h3", { children: t("games.hegemony.ui.prices") }),
								/* @__PURE__ */ d(qn, {
									values: C.prices,
									anchor: `prices:${C.role}`
								}),
								/* @__PURE__ */ f("button", {
									className: "hg-action",
									onClick: () => b(!0),
									children: [
										t("games.hegemony.ui.market"),
										" · ",
										C.market.length
									]
								})
							] }) : null,
							C.role === "state" && n.politicalCard !== null && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("h3", { children: t("games.hegemony.ui.stateAgenda") }), /* @__PURE__ */ d("div", {
								className: "hg-agenda-policies",
								children: fe.find((e) => e.id === n.politicalCard)?.policies.map((e, t) => /* @__PURE__ */ f("span", {
									style: { background: er[t] },
									children: [
										t + 1,
										" · ",
										e
									]
								}, t))
							})] }),
							(C.role === r.role ? [...r.agendas, ...r.agenda === null ? [] : [r.agenda]] : C.visibleAgendas).map((e) => /* @__PURE__ */ d(Zn, {
								kind: "agenda",
								id: e,
								available: S.some((t) => t.kind === "agenda" && t.card === e),
								onPick: () => {
									let t = S.filter((t) => t.kind === "agenda" && t.card === e);
									t.length ? j(t) : M("agenda", e);
								}
							}, e)),
							C.agendaAchieved.map((e) => /* @__PURE__ */ f("button", {
								className: "hg-achieved",
								onClick: () => M("agenda", e),
								children: [
									/* @__PURE__ */ d(Q, { name: "vp" }),
									de.find((t) => t.id === e).vp,
									" · ",
									v(_(Yn("agenda", e)), t)
								]
							}, e)),
							C.perks.map((e) => /* @__PURE__ */ d(Zn, {
								kind: "event",
								id: e,
								onPick: () => M("event", e)
							}, e))
						]
					})
				]
			}),
			/* @__PURE__ */ d(o, {
				open: m,
				label: t("games.hegemony.ui.details"),
				title: l ? v(_(Yn(l.kind, l.id)), t) : "",
				onClose: () => h(!1),
				children: /* @__PURE__ */ d("div", {
					className: "hegemony hg-inspection",
					children: l && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(Xn, {
						kind: l.kind,
						id: l.id
					}), S.filter((e) => e.card === l.id && [
						"hand",
						"eventCard",
						"agenda"
					].includes(e.kind)).map((e) => /* @__PURE__ */ d("button", {
						className: "hg-action",
						onClick: () => {
							A(e), h(!1);
						},
						children: v(e.text, t)
					}, e.key))] })
				})
			}),
			/* @__PURE__ */ d(o, {
				open: L.length > 0,
				label: t("games.hegemony.ui.choose"),
				title: t("games.hegemony.ui.choose"),
				onClose: () => te([]),
				children: /* @__PURE__ */ d("div", {
					className: "hegemony hg-choice-list",
					children: L.map((e) => /* @__PURE__ */ f("button", {
						className: "hg-action",
						onClick: () => A(e),
						children: [
							e.resource && /* @__PURE__ */ d(Q, { name: e.resource }),
							v(e.text, t),
							e.kind === "assignmentPlan" && /* @__PURE__ */ d("span", {
								className: "hg-plan-moves",
								children: e.key.slice(15).split(";").map((e, r) => {
									let [i, a, , o] = e.split(","), s = n.workers.find((e) => e.id === Number(i)), c = n.companies.find((e) => e.uid === Number(a));
									return /* @__PURE__ */ f("small", { children: [
										s ? `${s.id} · ${s.company === null ? t("games.hegemony.ui.unemployed") : v(_(y.find((e) => e.id === n.companies.find((e) => e.uid === s.company).definition).name), t)}` : i,
										" → ",
										c ? v(_(y.find((e) => e.id === c.definition).name), t) : `${t("games.hegemony.ui.unions")} ${v(E[o], t)}`
									] }, r);
								})
							})
						]
					}, e.key))
				})
			}),
			/* @__PURE__ */ d(o, {
				open: g,
				label: t("games.hegemony.ui.market"),
				title: t("games.hegemony.ui.market"),
				onClose: () => b(!1),
				children: /* @__PURE__ */ d("div", {
					className: "hegemony hg-market-cards",
					children: R.map((e) => /* @__PURE__ */ d($, {
						name: `market:${e}`,
						children: /* @__PURE__ */ d(Zn, {
							kind: "company",
							id: e,
							available: S.some((t) => t.kind === "buildCompany" && t.card === e),
							onPick: () => {
								let t = S.find((t) => t.kind === "buildCompany" && t.card === e);
								t ? (A(t), b(!1)) : M("company", e);
							}
						})
					}, e))
				})
			}),
			/* @__PURE__ */ d(o, {
				open: ne,
				label: t("games.hegemony.ui.log"),
				title: t("games.hegemony.ui.log"),
				onClose: () => re(!1),
				children: /* @__PURE__ */ d("ol", {
					className: "hegemony hg-journal",
					children: n.log.map((e) => /* @__PURE__ */ f("li", { children: [e.role && /* @__PURE__ */ f("b", {
						style: { color: Hn[e.role] },
						children: [k(e.role), " · "]
					}), v(e.text, t)] }, e.id))
				})
			}),
			/* @__PURE__ */ d(o, {
				open: x,
				label: t("games.hegemony.ui.taxTable"),
				title: t("games.hegemony.ui.taxTable"),
				onClose: () => ce(!1),
				children: /* @__PURE__ */ f("div", {
					className: "hegemony hg-tax-reference",
					children: [/* @__PURE__ */ f("h3", { children: [
						v(he[1], t),
						" / ",
						v(he[2], t)
					] }), /* @__PURE__ */ f("table", { children: [/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [
						/* @__PURE__ */ d("th", {}),
						/* @__PURE__ */ d("th", { children: "A" }),
						/* @__PURE__ */ d("th", { children: "B" }),
						/* @__PURE__ */ d("th", { children: "C" })
					] }) }), /* @__PURE__ */ d("tbody", { children: [
						[
							7,
							6,
							5
						],
						[
							4,
							4,
							4
						],
						[
							1,
							2,
							3
						]
					].map((e, t) => /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: "ABC"[t] }), e.map((e, t) => /* @__PURE__ */ d("td", { children: e }, t))] }, t)) })] })]
				})
			})
		]
	});
}
//#endregion
//#region src/games/hegemony/bot.ts
var nr = {
	engine: 1,
	consumption: 1,
	cash: 1,
	politics: 1,
	avoidRepeat: 1
}, rr = (e, t, n) => e === "state" ? fe.find((e) => e.id === n.politicalCard)?.policies[t] : C.desiredPolicies[e][t], ir = (e) => y.find((t) => t.id === e), ar = (e) => [...e].reduce((e, t) => Math.imul(e, 31) + t.charCodeAt(0) >>> 0, 7);
function or(e = {}) {
	let t = {
		...nr,
		...e
	};
	return ({ public: e, private: n }, r) => {
		if (!n || !n.role || !n.choices.length || e.automatic || e.phase === "done") return null;
		let i = n.moves.length, a = n.role, o = e.classes.find((e) => e.role === a), s = e.companies.filter((e) => e.active && e.owner === a), c = e.workers.filter((e) => e.role === a), l = P(e, a), u = c.filter((e) => e.company === null && !e.union), d = `${e.round}:${e.turnRole}:${e.turn}:${e.task ?? "root"}:${e.mainDone}:${e.freeDone}`, f = r.memory, p = f?.task === d ? { ...f.counts } : {}, m = o.money + o.capital;
		function h(n) {
			let r = b.find((e) => e.id === n);
			if (!r) return 7;
			let i = r.name;
			return i === "Cooperative Farm" ? u.length >= 3 && !s.some((e) => ir(e.definition).owner === "working") ? 22 * t.engine : -5 : i.includes("Specialization") || i === "Labor Market Deregulation" || i === "Foreign Recruitment" ? (u.length ? 12 : 4) * t.engine : [
				"Business Expansion",
				"Business Grants",
				"Industrialization",
				"Small Business Grant",
				"Land of Opportunity",
				"Investment Opportunities"
			].includes(i) ? e.round < 5 ? 19 * t.engine : 4 : [
				"Healthcare Benefits",
				"State Scholarship",
				"Covid-19 Vaccination Program",
				"E-commerce",
				"Import Subsidy",
				"Personal Consumption"
			].includes(i) ? (m > l * 5 ? 15 : 5) * t.consumption : [
				"Employment Support Scheme",
				"Global Financial Aid",
				"Business Bailout",
				"Capital Injection",
				"Geopolitical Support",
				"Business Boost"
			].includes(i) ? 14 * t.cash : a === "state" ? [
				"Immediate Response",
				"Shift Focus",
				"A Matter of High Priority"
			].includes(i) ? 15 : 9 : 8 + (i.includes("Lobby") || i.includes("Movement") || i === "Need for Change" ? 3 * t.politics : 0);
		}
		function ee(n) {
			let r = n.score * .2;
			if (n.kind === "hand") r += h(n.card);
			else if (n.kind === "playEffect") r += h(n.card);
			else if (n.kind === "freeUse") r += 35 * t.consumption;
			else if (n.kind === "freeBenefits") r += 28;
			else if (n.kind === "freeRepay") r += m > (a === "working" ? l * 10 + 50 : 90) ? 20 : -10;
			else if (n.kind === "freeTask") r -= 15;
			else if (n.kind === "endTurn") r -= 10;
			else if (n.kind === "basic") {
				let i = n.key.split(":")[1];
				r += i === "event" ? 19 : i === "build" ? (e.round < 5 ? 14 : 1) * t.engine : i === "assign" ? (u.length >= 2 ? 18 : 2) * t.engine : i === "buy" ? [
					"health",
					"education",
					"luxury"
				].some((e) => o.personal[e] < l) && m > l * 5 ? 14 * t.consumption : -2 : i === "export" ? 13 : i === "sellCompany" ? -12 : i === "pressure" ? 1 : 7;
			} else if (n.kind === "buildCompany") {
				let e = ir(n.card), i = e.workers.filter((e) => e === "skill").length, a = u.filter((t) => t.skill === e.resource).length;
				r += (e.production * 2 - e.cost * .18 + (e.workers.length === 0 ? 7 : u.length >= e.workers.length && a >= i ? 9 : -8)) * t.engine;
			} else if (n.kind === "assignmentPlan") {
				let t = n.key.slice(15).split(";").map((e) => e.split(",")).filter(([e]) => u.some((t) => t.id === Number(e))).length, i = n.company === void 0 ? void 0 : e.companies.find((e) => e.uid === n.company);
				r += t * 8 + (n.resource ? 14 : 0) + (i ? (ir(i.definition).wages[i.wage - 1] ?? 0) / Math.max(1, ir(i.definition).workers.length) : 0);
			} else if (n.kind === "bill") {
				let i = n.key.split(":")[2], o = rr(a, n.policy, e);
				r += (i === o ? 20 : Math.abs("ABC".indexOf(i) - "ABC".indexOf(o ?? "B")) < Math.abs("ABC".indexOf(e.policies[n.policy]) - "ABC".indexOf(o ?? "B")) ? 5 : -12) * t.politics;
			} else if (n.kind === "purchase") {
				let t = n.resource, i = n.amount, a = Math.max(0, (t === "food" && e.task === "food" ? i : l) - o.personal[t]), s = n.text.params?.p4, c = typeof s == "number" ? s / i : 0;
				r += t === "influence" ? 2 : Math.min(i, a) * (t === "food" ? 6 : 10) - Math.max(0, i - a) * 6 - c * i * .5;
			} else if (n.kind === "buyResource") r += Math.max(0, l - o.personal[n.resource]) * 4 - (n.resource === "food" && o.personal.food >= l ? 20 : 0);
			else if (n.kind === "support" || n.kind === "oppose") {
				let t = e.election, i = rr(a, t.bill.policy, e), o = Math.abs("ABC".indexOf(i ?? "B") - "ABC".indexOf(t.bill.target)) <= Math.abs("ABC".indexOf(i ?? "B") - "ABC".indexOf(e.policies[t.bill.policy]));
				r += n.key === (o ? "support" : "oppose") ? 15 : -10;
			} else if (n.kind === "influence") {
				let t = e.election, i = t.sides[a], s = t.cubes.reduce((e, n) => e + (t.sides[n] === i ? 1 : -1), 0), c = Math.max(0, -s + (i === !0 ? 0 : 1));
				r += n.amount === Math.min(o.personal.influence, c) ? 20 : -Math.abs(n.amount - c) * 3;
			} else n.key === "finish" ? r += e.task === "assign" && i ? 35 : [
				"prices",
				"wages",
				"marketRefresh",
				"swap"
			].includes(e.task ?? "") ? 12 : 0 : n.key === "skip" ? r -= 10 : (n.key === "cancel" || n.key === "backWorker") && (r -= 80);
			return n.key === "free:storage" && s.length >= 3 && e.round < 5 && (r += 18), r - (p[n.key] ?? 0) * 35 * t.avoidRepeat;
		}
		let te = n.choices.map((t) => ({
			c: t,
			value: r.difficulty === "weak" ? ar(`${e.revision}:${r.rid}:${t.key}`) % 1e3 : ee(t)
		}));
		te.sort((e, t) => t.value - e.value || e.c.key.localeCompare(t.c.key));
		let ne = te[0].c;
		return p[ne.key] = (p[ne.key] ?? 0) + 1, {
			action: {
				type: "choose",
				revision: e.revision,
				key: ne.key
			},
			memory: {
				task: d,
				counts: p
			}
		};
	};
}
var sr = or();
//#endregion
//#region src/games/hegemony/fx.tsx
function cr(e, t) {
	let n = e.anchor(t);
	return n && n.w > 0 && n.h > 0 ? n : null;
}
function lr(e, t) {
	let n = cr(e, t);
	if (n) return n;
	let r = t.split(":");
	return [
		"storage",
		"personal",
		"benefits"
	].includes(r[0]) ? cr(e, `source:${r[1]}:${r[2]}`) ?? cr(e, `class:${r[1]}`) : ["supply", "deck"].includes(r[0]) ? cr(e, `class:${r[1]}`) : r[0] === "hand" ? cr(e, "hand") : r[0] === "market" ? cr(e, "marketDeck") : ["historyDeck", "crisisDeck"].includes(r[0]) ? cr(e, "governmentDeck") : null;
}
var ur = (e, t, n = t) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), dr = {
	hegemonyMove(e, t) {
		let n = e.data, r = lr(t, n.from), i = lr(t, n.to);
		if (!r || !i) return null;
		let a = t.queued ? Math.min(220, n.ms) : n.ms, o = [
			"action",
			"company",
			"history",
			"crisis"
		].includes(n.piece), s = o ? 134 : n.piece === "worker" ? 29 : 25;
		return {
			ms: a,
			hide: t.queued || !n.hide ? [] : [n.hide],
			node: /* @__PURE__ */ d(m, {
				from: ur(r, s, o ? 105 : 32),
				to: ur(i, s, o ? 105 : 32),
				ms: a,
				children: /* @__PURE__ */ d("div", {
					className: "hegemony",
					style: {
						position: "relative",
						width: s,
						height: o ? 105 : 32
					},
					children: o ? /* @__PURE__ */ d(Zn, {
						kind: n.piece,
						id: n.card,
						compact: !0,
						onPick: () => {}
					}) : n.piece === "worker" ? /* @__PURE__ */ d(Gn, { worker: {
						role: n.role,
						skill: n.skill
					} }) : n.piece === "vote" ? /* @__PURE__ */ d("span", { style: {
						display: "block",
						width: 22,
						height: 22,
						background: Hn[n.role],
						border: "1px solid #ddd7bd",
						boxShadow: "2px 3px #142633"
					} }) : n.piece === "policy" ? /* @__PURE__ */ d("span", {
						className: "hg-policy-marker",
						style: {
							display: "block",
							width: 18,
							height: 18
						}
					}) : n.piece === "money" ? /* @__PURE__ */ d("b", {
						style: {
							display: "grid",
							placeItems: "center",
							width: 29,
							height: 29,
							background: "#e2d1a4",
							color: "#304554",
							border: "2px solid #82734e",
							borderRadius: "50%",
							fontSize: 11
						},
						children: n.amount
					}) : /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(Q, { name: n.piece }), n.amount > 1 && /* @__PURE__ */ d("b", {
						style: {
							position: "absolute",
							right: -5,
							bottom: 0,
							background: "#233b4c",
							color: "#fff2bf",
							borderRadius: 3,
							padding: "0 3px",
							fontSize: 12
						},
						children: n.amount
					})] })
				})
			})
		};
	},
	hegemonyDraw(e, t) {
		let n = e.data, r = e.secret?.cards, i = lr(t, `deck:${n.role}`), a = e.rid === t.myRid ? cr(t, "hand") : cr(t, `class:${n.role}`);
		return !i || !a ? null : {
			ms: sn.action,
			node: /* @__PURE__ */ d(m, {
				from: ur(i, 80, 105),
				to: ur(a, 80, 105),
				ms: sn.action,
				children: /* @__PURE__ */ d("div", {
					className: "hegemony",
					style: {
						width: 80,
						height: 105
					},
					children: r?.[0] === void 0 ? /* @__PURE__ */ f("div", {
						style: {
							height: "100%",
							background: "#233b4c",
							border: `4px double ${Hn[n.role]}`,
							color: "#e4d7b4",
							display: "grid",
							placeItems: "center",
							fontSize: 18
						},
						children: ["H · ", n.amount]
					}) : /* @__PURE__ */ d(Zn, {
						kind: "action",
						id: r[0],
						compact: !0,
						onPick: () => {}
					})
				})
			})
		};
	},
	hegemonyPulse(e, t) {
		let n = e.data, r = lr(t, n.target);
		return r ? {
			ms: n.ms,
			node: /* @__PURE__ */ d(h, {
				at: r,
				ms: n.ms
			})
		} : null;
	},
	hegemonyScore(e, t) {
		let n = e.data, r = lr(t, `class:${n.role}`);
		return r ? {
			ms: n.ms,
			node: /* @__PURE__ */ d(p, {
				at: r,
				ms: n.ms,
				children: /* @__PURE__ */ f("span", {
					style: {
						background: "#213846",
						border: "1px solid #cfb571",
						color: "#f0d38d",
						padding: "3px 7px",
						fontSize: 19
					},
					children: [
						n.amount > 0 ? "+" : "",
						n.amount,
						" ",
						/* @__PURE__ */ d(Q, { name: "vp" })
					]
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/hegemony/game-over.tsx
function fr(e) {
	let t = Mn.safeParse(e.public);
	return !t.success || t.data.phase !== "done" ? /* @__PURE__ */ d(ee, {
		...e,
		accent: Sn.accent
	}) : /* @__PURE__ */ d(pr, {
		...e,
		pub: t.data
	});
}
function pr({ pub: e, ...t }) {
	let o = a(), [s, c] = i(!0), [l, u] = i(null), p = r(null), m = r(null), h = r(null);
	n(() => {
		m.current?.focus({ preventScroll: !0 });
	}, []), n(() => {
		if (!l) return;
		let e = setTimeout(() => u(null), 5e3);
		return () => clearTimeout(e);
	}, [l]);
	let ee = (e) => {
		c(e), u(null), requestAnimationFrame(() => (e ? m : h).current?.focus({ preventScroll: !0 }));
	}, te = (e) => {
		l === e ? (u(null), (e === "again" ? t.onPlayAgain : t.onBackToLobby)?.()) : u(e);
	}, ne = e.roles.map((t) => e.classes.find((e) => e.role === t)), re = ne.filter((t) => e.winnerRoles.includes(t.role)), ie = [...new Map(e.scoreBreakdown.map((e) => [JSON.stringify(e.text), e.text])).entries()];
	return /* @__PURE__ */ f("div", {
		className: "hegemony hg-endgame",
		children: [
			/* @__PURE__ */ d("div", {
				className: "hg-final-board",
				inert: s,
				children: /* @__PURE__ */ d(tr, {
					public: e,
					private: t.private,
					members: t.members,
					myRid: t.myRid,
					send: () => {}
				})
			}),
			/* @__PURE__ */ d("div", {
				className: "hg-result-overlay",
				hidden: !s,
				children: /* @__PURE__ */ f("section", {
					ref: p,
					className: "hg-result-panel",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": o("games.hegemony.end.title"),
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), ee(!1)), e.key === "Tab") {
							let t = p.current?.querySelectorAll("button:not(:disabled)");
							if (!t?.length) return;
							let n = t[0], r = t[t.length - 1];
							e.shiftKey && document.activeElement === n ? (e.preventDefault(), r.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n.focus());
						}
					},
					children: [
						/* @__PURE__ */ f("header", {
							className: "hg-result-heading",
							children: [/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("span", {
								className: "hg-result-wordmark",
								children: "HEGEMONY"
							}), /* @__PURE__ */ d("h1", { children: o("games.hegemony.end.title") })] }), /* @__PURE__ */ d("button", {
								ref: m,
								onClick: () => ee(!1),
								children: o("games.hegemony.end.readBoard")
							})]
						}),
						/* @__PURE__ */ f("div", {
							className: "hg-result-body",
							children: [
								/* @__PURE__ */ f("div", {
									className: "hg-outcome",
									children: [
										/* @__PURE__ */ d(Q, { name: "vp" }),
										/* @__PURE__ */ d("h2", { children: re.map((e) => v(D[e.role], o)).join(" · ") }),
										/* @__PURE__ */ d("p", { children: o(re.length > 1 ? "games.hegemony.end.tied" : "games.hegemony.end.winner") })
									]
								}),
								t.hintCount !== void 0 && /* @__PURE__ */ d("p", { children: o("session.hint.usedCount", { n: t.hintCount }) }),
								/* @__PURE__ */ d("div", {
									className: "hg-score-scroll",
									children: /* @__PURE__ */ f("table", {
										className: "hg-score-table",
										children: [
											/* @__PURE__ */ d("caption", {
												className: "sr-only",
												children: o("games.hegemony.end.scores")
											}),
											/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: o("games.hegemony.end.scores") }), ne.map((n) => /* @__PURE__ */ f("th", {
												style: { "--role": Hn[n.role] },
												"data-winner": e.winnerRoles.includes(n.role),
												children: [
													/* @__PURE__ */ d(Q, { name: `role-${n.role}` }),
													/* @__PURE__ */ d("span", { children: v(D[n.role], o) }),
													/* @__PURE__ */ d("small", { children: n.automa === "off" ? t.members.find((e) => e.rid === n.rid)?.name : o(n.automa === "simple" ? "games.hegemony.ui.simple" : "games.hegemony.ui.advanced") }),
													n.rid && (t.result.autopilot?.[n.rid] ?? 0) > 0 && /* @__PURE__ */ d("small", { children: o("session.autopilot.share", { n: Math.round(t.result.autopilot[n.rid] * 100) }) })
												]
											}, n.role))] }) }),
											/* @__PURE__ */ f("tbody", { children: [
												/* @__PURE__ */ f("tr", {
													className: "hg-total",
													children: [/* @__PURE__ */ d("th", { children: o("games.hegemony.end.total") }), ne.map((t) => /* @__PURE__ */ d("td", {
														"data-winner": e.winnerRoles.includes(t.role),
														children: t.vp
													}, t.role))]
												}),
												ie.map(([t, n]) => /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: v(n, o) }), ne.map((n) => /* @__PURE__ */ d("td", { children: e.scoreBreakdown.filter((e) => e.role === n.role && JSON.stringify(e.text) === t).reduce((e, t) => e + t.vp, 0) }, n.role))] }, t)),
												/* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: o("games.hegemony.end.other") }), ne.map((t) => /* @__PURE__ */ d("td", { children: t.vp - e.scoreBreakdown.filter((e) => e.role === t.role).reduce((e, t) => e + t.vp, 0) }, t.role))] })
											] })
										]
									})
								})
							]
						}),
						/* @__PURE__ */ f("footer", {
							className: "hg-result-actions",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || u(null);
							},
							children: [
								t.onBackToLobby && /* @__PURE__ */ f("button", {
									className: l === "lobby" ? "hg-action" : "hg-quiet",
									onClick: () => te("lobby"),
									children: [l === "lobby" ? `${o("games.hegemony.ui.confirm")} · ` : "", o("games.hegemony.end.lobby")]
								}),
								t.onPlayAgain && /* @__PURE__ */ f("button", {
									className: "hg-action",
									onClick: () => te("again"),
									children: [l === "again" ? `${o("games.hegemony.ui.confirm")} · ` : "", o("games.hegemony.end.again")]
								}),
								!t.onPlayAgain && !t.onBackToLobby && /* @__PURE__ */ d("span", { children: o("games.hegemony.end.waiting") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ d("div", {
				className: "hg-review-toolbar",
				hidden: s,
				children: /* @__PURE__ */ d("button", {
					ref: h,
					className: "hg-action",
					onClick: () => ee(!0),
					children: o("games.hegemony.end.scores")
				})
			})
		]
	});
}
//#endregion
//#region src/games/hegemony/options.tsx
var mr = [
	"",
	"working",
	"middle",
	"capital",
	"state",
	"working,capital",
	"working,middle",
	"working,state",
	"middle,capital",
	"middle,state",
	"capital,state",
	"working,middle,capital",
	"working,middle,state",
	"working,capital,state",
	"middle,capital,state"
];
function hr({ value: e, onChange: t }) {
	let n = a(), r = On.safeParse(e), i = r.success ? r.data : On.parse(void 0), o = [
		["actionExpansion", n("games.hegemony.options.actionExpansion")],
		["crisisResponse", n("games.hegemony.options.crisisResponse")],
		["hiddenAgendas", n("games.hegemony.options.hiddenAgendas")],
		["alternativeEvents", n("games.hegemony.options.alternativeEvents")],
		["historicalEvents", n("games.hegemony.options.historicalEvents")],
		["controllingNarrative", n("games.hegemony.options.controllingNarrative")],
		["rapidResolution", n("games.hegemony.options.rapidResolution")]
	];
	return /* @__PURE__ */ f("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ d("p", {
				className: "text-sm",
				children: n("games.hegemony.options.seatHelp")
			}),
			/* @__PURE__ */ d(ne, {
				title: n("games.hegemony.options.seats"),
				children: mr.map((e) => /* @__PURE__ */ d(te, {
					name: "hegemony-seats",
					value: e,
					checked: i.seatRoles === e,
					label: e ? e.split(",").map((e) => v(D[e], n)).join(" · ") : n("games.hegemony.options.standard"),
					accent: Sn.accent,
					onChange: () => t({
						...i,
						seatRoles: e
					})
				}, e))
			}),
			/* @__PURE__ */ d("p", {
				className: "text-sm",
				children: n("games.hegemony.options.automaHelp")
			}),
			[
				"working",
				"middle",
				"capital"
			].map((e) => /* @__PURE__ */ d(ne, {
				title: v(D[e], n),
				columns: 3,
				children: [
					"off",
					"simple",
					"advanced"
				].map((r) => /* @__PURE__ */ d(te, {
					name: `hegemony-${e}`,
					value: r,
					checked: i[`${e}Automa`] === r,
					label: n(r === "off" ? "games.hegemony.options.off" : r === "simple" ? "games.hegemony.options.simple" : "games.hegemony.options.advanced"),
					accent: Sn.accent,
					onChange: () => t({
						...i,
						[`${e}Automa`]: r
					})
				}, r))
			}, e)),
			/* @__PURE__ */ d(ne, {
				title: n("games.hegemony.options.expansions"),
				children: /* @__PURE__ */ d("div", {
					className: "col-span-2",
					children: o.map(([e, n]) => /* @__PURE__ */ d(re, {
						checked: i[e],
						label: n,
						accent: Sn.accent,
						onChange: () => t({
							...i,
							[e]: !i[e]
						})
					}, e))
				})
			}),
			/* @__PURE__ */ d("p", {
				className: "text-sm",
				children: n("games.hegemony.options.stateHelp")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/hegemony/entry.tsx
var gr = {
	definition: Bn,
	View: tr,
	bot: sr,
	fx: dr,
	OverView: fr,
	Options: hr,
	locales: {
		zh: {
			name: "领国者",
			desc: "领导你的阶级，在政策、产业与民生的博弈中争取胜利。",
			rules: "目标：\n带领工人阶级、中产阶级、资本家阶级或国家，在五轮政治与经济竞争中获得最多胜利点。各阶级的行动、收入与计分方式不同。官方自动对手也参与胜负比较。同分时，先比较前五项政策中符合本阶级偏好的数量（国家按政治议程）；仍同分则国家优先，否则比较票袋中的投票方块数量；再次同分才共同获胜。\n\n准备：\n标准两阶级为工人阶级与资本家阶级，第三阶级加入中产阶级，第四阶级加入国家。单人默认扮演工人阶级，其余必要阶级由官方简易自动对手补齐。可在选项中指定真人席位和简易／进阶自动对手；平台机器人占据普通玩家席位，国家没有官方自动对手。\n初始政策依次为C、B、A、B、C、B、B。玩家持有7张行动牌，每轮执行5次主行动，轮间抽5张补充。行动牌、隐藏议程与投票中未公开的影响力属于私人信息。\n\n每轮流程：\n依次进行准备、行动、生产、选举和计分。每个阶级按工人阶级、中产阶级、资本家阶级、国家的顺序轮流行动，共5次。准备阶段支付贷款利息、更新市场、增加工人并处理移民；工人阶级繁荣降低1，中产阶级繁荣降低2。\n每回合必须打出一张行动牌，执行牌面效果，或弃掉它执行本阶级的一项基本行动。每回合至多执行一次自由行动，可在主行动之前或之后执行。选中手牌后仍可返回，确认卡牌效果或基本行动后支付相应费用。\n· 工人阶级可提议法案、分配工人、购买商品与服务、罢工、示威或施加政治压力。\n· 资本家阶级可提议法案、建造或出售企业、出口、进行商业交易、游说或施加政治压力。\n· 中产阶级结合雇工与经营企业，并可执行加班。\n· 国家可提议法案、处理事件、出口、会见议员、额外征税或开展宣传。\n\n工人、企业与消费：\n熟练岗位须由对应产业的熟练工人担任。工人阶级工人可进入公共及资本家企业，并可担任中产企业的辅助岗位；中产阶级工人可进入自己的企业或公共及资本家企业。一次分配可以同时移动多名工人，目标企业须在分配结束时满足岗位要求。原企业不足时，其余工人回到失业区。新分配的工人在当轮生产前被承诺，不能随意重新分配。工会按产业建立，要求该产业至少有4名工人阶级工人。\n企业只有满足岗位要求才运营。机器增加产量，企业支付牌面所列总工资。劳动政策A、B、C分别要求最低工资等级3、2、1。中产企业的辅助工人另增加产量并领取工资。\n工人阶级与中产阶级每轮须为人口提供同等数量食物。医疗、教育和奢侈品存入私人资源，达到人口数量后可用一次自由行动消费。消费不同资源时，获得以下效果：\n· 医疗提高繁荣，并增加工人。\n· 教育提高繁荣，并升级工人。\n· 奢侈品提高繁荣。\n繁荣提升按本阶级轨道获得胜利点。人口按工人数量区间计算，最低3、最高10。\n\n政策与选举：\n七项政策依次为财政、劳动市场、税收、医疗与福利、教育、对外贸易、移民。一般提案把政策移到相邻档位，每个阶级至多有3项法案，同一政策同时只能有一项法案。可支付1影响力立即投票，否则在选举阶段处理。特殊牌可以改变提案条件。\n各阶级先声明支持或反对，再从票袋揭示5个投票方块，各方秘密支付私人影响力补票。平票时提案通过。提案者获得3胜利点，其他实际贡献支持票的阶级各获得1胜利点。胜方揭示的方块移除，败方方块回袋。未参局阶级的方块仍按规则参与抽取。\n\n生产、税收与危机：\n按国家、资本家、中产、工人的顺序逐家企业生产并支付工资，然后解除工人承诺。中产阶级先满足食物需求，再轮到工人阶级。现金不足以承担强制付款时取得贷款，每笔贷款获得 50 资金，轮间每笔贷款支付 5 资金作为利息。使用自由行动偿还一笔贷款需支付 50 资金；检查 IMF 时，国家偿还每笔贷款需支付 55 资金。\n满足需求后检查IMF，再缴税。财政政策A、B下国家取得第二笔贷款触发干预，C下第一笔即触发。基础干预将政策设为C、C、A、B、C、B、B，并重设最低工资。启用危机应对时改为处理危机牌，政策锁定持续到下次检查IMF。\n工人阶级按人口缴所得税，中产阶级按公共及资本家就业企业数缴所得税，并为自己的运营企业缴雇佣税；资本家缴雇佣税与公司税。所得税使用生产开始时的劳动政策：劳动A下，税收A／B／C税率为7／6／5；劳动B均为4；劳动C为1／2／3。雇佣税还受医疗、教育政策影响，公司税按收入区间计算。\n\n计分与终局：\n· 每轮工人阶级每个工会获得2胜利点。\n· 中产阶级以完全运营企业数与繁荣轨道比较，满足条件时提高繁荣。\n· 资本家把收入转入资本，按财富等级计分，提高历史最高财富等级时每级另获得3胜利点。\n· 国家获得最低的两项合法性之和，以及符合政治议程的政策数量；随后各阶级合法性减半向上取整，再加永久标记。\n第五轮计分后进行终局结算。前三阶级按政策1至5符合偏好的数量计分：工人偏好A、资本家偏好C，0至5项依次为0、1、4、8、12、18分；中产偏好B，依次为0、1、3、6、10、15分。\n· 除工人阶级外，每剩余 2 份食物获得 1 分；奢侈品、医疗和教育分别计算，每剩余 3 份获得 1 分。国家每剩余 3 点媒体影响力再获得 1 分。\n· 工人阶级每剩余 10 资金获得 1 分，最多获得 15 分；中产阶级每剩余 15 资金获得 1 分；国家每剩余 30 资金获得 1 分。\n· 资本家阶级每笔未偿贷款扣除 5 分。其他阶级先以资金偿还终局债务，剩余未偿金额每满 5 资金扣除 1 分。\n\n扩展：\n“危机与控制”的额外行动牌、隐藏议程、替代事件和危机应对可分别启用。真人从两张隐藏议程中选择一张，满足时获得其胜利点。官方自动对手持有本阶级全部议程，终局仅获得已达成议程中的最高分。替代事件完成后，受益阶级可保留收益牌或立即获得1胜利点。\n“历史事件”从六个时期各选一张，分别用于开局及五轮。牌面条件须在触发时满足，主动历史效果只触发一次；揭示和行动结束效果按对应时机处理。国家图标下的效果要求国家玩家参局。“掌控话语权”和“快速决议”赠卡可独立加入。牌面完整说明、条件、事件奖励和持有收益可在详情中查看。",
			errors: {
				finished: "对局已经结束。",
				turn: "当前步骤由其他玩家执行。",
				stale: "局面已更新，请重新选择。",
				invalid: "当前局面无法执行此项操作。"
			},
			messages: {
				m001: "自动对手翻开第 {{p1}} 号指令",
				m002: "不执行此项",
				m003: "完成",
				m004: "提议法案",
				m005: "分配工人",
				m006: "购买商品与服务",
				m007: "罢工",
				m008: "示威",
				m009: "施加政治压力",
				m010: "建造企业",
				m011: "出售企业",
				m012: "向外国市场出售",
				m013: "达成商业交易",
				m014: "游说",
				m015: "加班",
				m016: "处理事件",
				m017: "会见议员",
				m018: "征收额外税款",
				m019: "宣传活动",
				m020: "结束回合",
				m021: "使用{{p1}}",
				m022: "交换工人",
				m023: "调整售价",
				m024: "购买仓库",
				m025: "调整工资",
				m026: "发放奖金",
				m027: "偿还一笔贷款（50 元）",
				m028: "领取福利",
				m029: "使用牌面效果",
				m030: "返回手牌",
				m031: "{{p1}}（{{p2}} 分）",
				m032: "选择工人 {{p1}}",
				m033: "{{p1}} {{p2}} → {{p3}}",
				m034: "保留至选举阶段",
				m035: "立即投票",
				m036: "支付 1 影响力并立即投票",
				m037: "分配 {{p1}} 名工人至 {{p2}}",
				m038: "成立{{p1}}工会",
				m039: "非熟练",
				m040: "选择{{p1}}工人 {{p2}}",
				m041: "{{p1}} · 岗位 {{p2}}",
				m042: "重新选择工人",
				m043: "{{p1}} · {{p2}} 元",
				m044: "雇用{{p1}}工人 {{p2}}",
				m045: "{{p1}} · L{{p2}}（{{p3}} 元）",
				m046: "外国市场",
				m047: "从{{p1}}购买 {{p2}} {{p3}}（{{p4}} 元）",
				m048: "出售 {{p1}} {{p2}}，获得 {{p3}} 元",
				m049: "本地仓库",
				m050: "自由贸易区",
				m051: "{{p1}} 食物、{{p2}} 奢侈品 · {{p3}}（{{p4}} 元）",
				m052: "{{p1}}：{{p2}} 元",
				m053: "{{p1}}仓库",
				m054: "工人 {{p1}} 与 {{p2}} 交换",
				m055: "支持法案",
				m056: "反对法案",
				m057: "投入 {{p1}} 影响力",
				m058: "打出 {{p1}}",
				m059: "不购买国债",
				m060: "购买 {{p1}} 元国债（下轮偿还 {{p2}} 元）",
				m061: "国际货币基金组织开始干预",
				m062: "危机应对：{{p1}}",
				m063: "食物",
				m064: "奢侈品",
				m065: "医疗",
				m066: "教育",
				m067: "影响力",
				m068: "工人阶级",
				m069: "中产阶级",
				m070: "资本家阶级",
				m071: "国家",
				m072: "财政政策",
				m073: "劳动市场",
				m074: "税收政策",
				m075: "医疗与福利",
				m076: "教育政策",
				m077: "对外贸易",
				m078: "移民政策",
				m079: "{{p1}}：{{p2}} 分",
				m080: "取得一笔 50 元贷款",
				m081: "{{p1}} 生产{{p2}}",
				m082: "{{p1}}调整至 {{p2}}",
				m083: "{{p1}} · 提供 {{p2}} 元",
				m084: "{{p1}} · {{p2}}",
				m085: "{{p1}} · 支付 {{p2}} 教育及 {{p3}} 元",
				m086: "{{p1}} · 支付 4 {{p2}}",
				m087: "{{p1}} · 支付 {{p2}} 媒体及 {{p3}} 私人影响力",
				m088: "向每个阶级提供 {{p1}} 元",
				m089: "{{p1}} · {{p2}} {{p3}}、{{p4}} {{p5}}",
				m090: "完成分配",
				m091: "保留事件，获得持续收益",
				m092: "弃置事件，获得 1 分",
				m093: "从{{p1}}购买 {{p2}} {{p3}}",
				m094: "提供资源",
				m095: "完成购买",
				m096: "{{p1}} → {{p2}}",
				m097: "保留当前事件",
				m098: "使用事件收益",
				m099: "放弃本次收益",
				m100: "保留事件",
				m101: "弃置事件，要求国家支持法案",
				m102: "本企业不使用雇工收益",
				m103: "在生产前分配工人",
				m104: "{{p1}} · L{{p2}} → L{{p3}}",
				m105: "移除工人 {{p1}}",
				m106: "{{p1}} · {{p2}}产业（{{p3}} 元）",
				m107: "向资本家支付 20 元，获得 5 分",
				m108: "向中产支付 10 元，获得 3 分",
				m109: "向国家出售 {{p1}} {{p2}}（{{p3}} 元）",
				m110: "出售 {{p1}} {{p2}}（{{p3}} 元）",
				m111: "从市场建造，费用减少 {{p1}}",
				m112: "从牌堆选择，费用增加 {{p1}}",
				m113: "支付 20 元，放置 1 个机器",
				m114: "支付 45 元，放置 2 个机器",
				m115: "可从任意数量的来源购买，每个来源的数量至多等于人口",
				m116: "可从一个来源购买，数量至多等于两倍人口",
				m117: "政策 {{p1}}{{p2}}",
				m118: "政策 {{p1}}{{p2}} · {{p3}}",
				m119: "保留当前出口牌",
				m120: "选择出口牌 {{p1}}",
				m121: "完成公共部门调整",
				m122: "开放",
				m123: "关闭",
				m124: "{{p1}} {{p2}}",
				m125: "{{p1}}失去 {{p2}} 分",
				m126: "结束示威结算",
				m127: "使用揭示方块，免费立即投票",
				m128: "将方块放回，保留法案",
				m129: "移除{{p1}}方块",
				m130: "将剩余方块放回",
				m131: "购买 {{p1}} 医疗（{{p2}} 元）",
				m132: "隐藏议程：{{p1}}",
				m133: "自动对手议程",
				m134: "政策 {{p1}}{{p2}} 开始投票",
				m135: "通过",
				m136: "未通过",
				m137: "法案{{p1}}：支持 {{p2}}，反对 {{p3}}",
				m138: "未偿贷款",
				m139: "政策奖励",
				m140: "剩余资源",
				m141: "剩余资金",
				m142: "当前效果没有可执行的目标",
				m143: "第 {{p1}} 轮工会",
				m144: "第 {{p1}} 轮财富",
				m145: "第 {{p1}} 轮合法性",
				m146: "第 {{p1}} 轮政治议程",
				m147: "不救助",
				m148: "支付半数成本，救助企业",
				n001: "专业化",
				n002: "关注社会问题",
				n003: "合作农场",
				n004: "医疗福利",
				n005: "国家奖学金",
				n006: "医疗运动",
				n007: "工人运动",
				n008: "学生运动",
				n009: "移民改革",
				n010: "变革诉求",
				n011: "劳动市场放松管制",
				n012: "工伤事故",
				n013: "全世界无产者，联合起来！",
				n014: "促进国内旅游",
				n015: "收入补助计划",
				n016: "加班",
				n017: "保障性住房",
				n018: "签约奖金",
				n019: "总罢工",
				n020: "失业救济",
				n021: "民意调查",
				n022: "虚假新闻",
				n023: "利益集团",
				n024: "激进改革",
				n025: "人口迁移",
				n026: "医疗危机",
				n027: "高等教育计划",
				n028: "政治施压",
				n029: "海外招聘",
				n030: "竞争性工资",
				n031: "全球品牌",
				n032: "离岸公司",
				n033: "洞察海外市场",
				n034: "就业促进计划",
				n035: "海外伙伴",
				n036: "企业扩张",
				n037: "投资机会",
				n038: "全球粮食危机",
				n039: "工业化",
				n040: "操纵招标",
				n041: "私人岛屿",
				n042: "退出策略",
				n043: "企业补助",
				n044: "外贸游说",
				n045: "税收游说",
				n046: "支持政治竞选",
				n047: "技术进步",
				n048: "贸易保护游说",
				n049: "进口补贴",
				n050: "小企业补助",
				n051: "机遇之地",
				n052: "就业补贴",
				n053: "中产劳动者之声",
				n054: "新主题公园",
				n055: "出口补贴",
				n056: "个人消费",
				n057: "企业成长",
				n058: "公共部门加班",
				n059: "就业支持方案",
				n060: "转移焦点",
				n061: "压制言论自由",
				n062: "迈向代表权",
				n063: "即时响应",
				n064: "地缘政治支持",
				n065: "海外留学生",
				n066: "医疗计划",
				n067: "医疗旅游",
				n068: "优先要务",
				n069: "紧急状态",
				n070: "海外投资计划",
				n071: "扫盲计划",
				n072: "旅游业增长",
				n073: "津贴与补助",
				n074: "设置议程",
				n075: "紧迫事项",
				n076: "建筑热潮",
				n077: "提高增值税",
				n078: "国有化",
				n079: "量化宽松",
				n080: "私有化",
				n081: "海外资金援助",
				n082: "维持现状",
				n083: "更换政府议程",
				n084: "变革动力",
				n085: "揭露政治丑闻",
				n086: "新冠病例增加",
				n087: "新冠疫苗接种计划",
				n088: "新冠疫苗研发资助",
				n089: "新冠刺激方案",
				n090: "掌控话语权",
				n091: "快速决议",
				literal: "{{value}}"
			},
			content: {
				name000: "超市",
				name001: "购物中心",
				name002: "学院",
				name003: "诊所",
				name004: "养鱼场",
				name005: "蔬菜农场",
				name006: "快餐连锁店",
				name007: "自动化谷物农场",
				name008: "自动化奶牛场",
				name009: "体育场",
				name010: "酒店",
				name011: "时装公司",
				name012: "电子制造厂",
				name013: "汽车制造厂",
				name014: "制药公司",
				name015: "医疗园区",
				name016: "医院",
				name017: "理工学院",
				name018: "大学",
				name019: "学术院",
				name020: "电视台",
				name021: "出版社",
				name022: "游说公司",
				name023: "广播电台",
				name024: "便利店",
				name025: "医师事务所",
				name026: "快餐店",
				name027: "有机农场",
				name028: "珠宝店",
				name029: "游戏商店",
				name030: "电子产品商店",
				name031: "药店",
				name032: "医学实验室",
				name033: "培训中心",
				name034: "辅导机构",
				name035: "私立学校",
				name036: "公关公司",
				name037: "地方报社",
				name038: "地区广播电台",
				name039: "地区电视台",
				name040: "公立大学",
				name041: "公立医院",
				name042: "国家公共广播",
				name043: "理工大学",
				name044: "大学附属医院",
				name045: "合作农场",
				name046: "政治丑闻",
				name047: "邻国战争",
				name048: "大流行",
				name049: "港口罢工",
				name050: "教育指数偏低",
				name051: "可持续发展倡议",
				name052: "通货紧缩恐慌",
				name053: "出生率下降",
				name054: "经济刺激方案",
				name055: "第十三个月工资诉求",
				name056: "企业要求改善网络",
				name057: "干旱",
				name058: "地方产业动荡",
				name059: "技术素养不足",
				name060: "提高福利标准的诉求",
				name061: "发展中国家的需求",
				name062: "幼稚产业需要扶持",
				name063: "公共基础设施老化",
				name064: "地震",
				name065: "养老金改革诉求",
				name066: "政治极化",
				name067: "社会动荡",
				name068: "代表权不公",
				name069: "大学排名偏低",
				name070: "全球供应链危机",
				name071: "全球创新指数排名偏低",
				name072: "改善公共教育的诉求",
				name073: "奶农补贴诉求",
				name074: "行政升级诉求",
				name075: "文盲率偏高",
				name076: "疫苗接种率偏低",
				name077: "政治压力",
				name078: "能源补贴诉求",
				name079: "抹黑运动",
				name080: "经济刺激诉求",
				name081: "公众压力",
				name082: "飓风",
				name083: "交通事故增加",
				name084: "退税",
				name085: "衰退恐慌",
				name086: "学生抗议",
				name087: "流感感染增加",
				name088: "政治参与不足",
				name089: "数字化转型诉求",
				name090: "经济不平等加剧",
				name091: "医疗丑闻",
				name092: "公共部门工会谈判",
				name093: "初创企业扶持诉求",
				name094: "选区划分操纵",
				name095: "国家干预诉求",
				name096: "企业帝国",
				name097: "迈向新自由主义国家",
				name098: "出口大亨",
				name099: "多元化投资组合",
				name100: "风险资本家",
				name101: "利维坦",
				name102: "预算专家",
				name103: "按计划行事",
				name104: "强大的福利国家",
				name105: "国家主导经济",
				name106: "企业家",
				name107: "成功的初创企业",
				name108: "壮大的中产阶级",
				name109: "黄金妥协",
				name110: "劳动带来繁荣",
				name111: "团结群众",
				name112: "工人们，联合起来！",
				name113: "工人阶级的推动力",
				name114: "精简劳动力",
				name115: "剩余价值属于我们！",
				name116: "华盛顿共识",
				name117: "IMF谈判失败",
				name118: "温和的IMF干预",
				name119: "日本模式",
				name120: "基础IMF干预",
				name121: "美国经济刺激方案",
				name122: "遭遇抵抗的IMF干预",
				name123: "新国债计划",
				name124: "欧盟紧缩措施",
				name125: "IMF干预失败：革命",
				name126: "法国大革命",
				name127: "工业革命",
				name128: "1848年革命",
				name129: "国际妇女联盟成立",
				name130: "移动装配线",
				name131: "第一次世界大战",
				name132: "福特T型车问世",
				name133: "俄国革命",
				name134: "威权主义兴起",
				name135: "巴拿马运河通航",
				name136: "西班牙流感",
				name137: "日俄战争",
				name138: "保护主义兴起",
				name139: "孟加拉饥荒",
				name140: "罗斯福新政",
				name141: "大萧条",
				name142: "婴儿潮",
				name143: "通用汽车静坐罢工",
				name144: "第二次世界大战",
				name145: "关税与贸易总协定",
				name146: "印度独立",
				name147: "战后经济奇迹",
				name148: "中国共产主义革命",
				name149: "民权运动",
				name150: "古巴禁运",
				name151: "马歇尔计划",
				name152: "非殖民化",
				name153: "凯恩斯主义时代",
				name154: "欧洲左翼兴起",
				name155: "消费主义",
				name156: "阿拉伯石油国有化",
				name157: "中国经济改革",
				name158: "亚洲四小龙崛起",
				name159: "万维网",
				name160: "南欧独裁统治终结",
				name161: "柏林墙倒塌",
				name162: "拉丁美洲债务危机",
				name163: "石油危机",
				name164: "印度干旱",
				name165: "前苏联国家的选举",
				name166: "欧盟碳排放交易体系",
				name167: "美国金融危机",
				name168: "中美贸易战",
				name169: "欧洲债务危机",
				name170: "马斯特里赫特条约",
				name171: "苏联解体",
				name172: "亚洲中产阶级崛起",
				name173: "黄背心运动",
				name174: "俾斯麦改革",
				name175: "美国革命",
				action24900: "从供给中新增一名自选技能的熟练工人，放入失业区；然后分配至多3名失业工人。",
				action24902: "支付15元，从国家购买3点影响力。",
				action24903: "至少有3名失业工人时，建造合作农场并分配3名工人。",
				action24905: "从国家购买医疗，数量至多等于人口；支付半价，向上取整。",
				action24907: "提议政策4的法案；将2个自己的投票方块加入票袋。",
				action24908: "提议2个法案。",
				action24911: "分配任意数量的失业工人。劳动市场为C时，还可重新分配任意数量的已就业工人。",
				action24913: "至少有4名失业工人时，移除其中至多2名。每移除一名非熟练工人，获得5元；每移除一名熟练工人，获得10元。",
				action24915: "提议政策2的法案；将2个自己的投票方块加入票袋。",
				action24916: "选择一个产业和另一个阶级；该阶级在此产业中每有一家雇用我方工人的企业，向我方支付8元。",
				action24917: "将等于自己人口的投票方块加入票袋。",
				action24919: "从其他阶级购买奢侈品，数量至多等于人口。自己支付半价，向上取整；国家支付余款。",
				action24921: "提议一项法案并揭示5个投票方块。可免费立即投票并使用这些方块；否则将它们放回票袋。",
				action24922: "提议政策5的法案；将2个自己的投票方块加入票袋。",
				action24923: "国家按我方每名已就业工人支付1元；然后可执行购买商品与服务行动。",
				action24925: "选择一家运营中的公共企业，由国家支付工资并生产。然后可从国家购买该企业生产的资源，数量至多等于人口。",
				action24927: "向资本家阶级支付20元，获得5胜利点；或向中产阶级支付10元，获得3胜利点。",
				action24928: "提议政策7的法案；将2个自己的投票方块加入票袋。",
				action24929: "分配至多4名失业工人；每分配一名，由目标企业的所有者向我方支付4元。",
				action24931: "执行罢工行动，额外获得等于工会数量的罢工标记。",
				action24932: "从票袋揭示6个投票方块，移除其中至多4个，将其余方块放回票袋。",
				action24934: "从国家购买教育，数量至多等于人口；支付半价，向上取整。",
				action24936: "提议一项法案，可选择任意其他档位；不能立即投票。",
				action24937: "国家按我方每名失业工人支付5元；然后可从国家购买商品与服务。",
				action24939: "从票袋依次揭示方块，直到出现3个其他阶级的方块。用我方方块替换这3个方块，再将所有揭示的方块放回票袋。",
				action28000: "从国家免费获得医疗，数量至多为人口的一半，向上取整。然后可从任意数量的来源购买医疗，每个来源的购买量至多等于人口。",
				action28001: "按自己在政策表上的每个法案标记获得1点影响力；然后提议法案，不能立即投票。",
				action28002: "选择一项政策，本轮禁止对其提议法案。将一个自己的法案标记放在当前档位作为提示，然后获得1点影响力。",
				action28003: "政策表上至多有3项法案时，弃置另一个阶级的一项法案。然后双方可各提议一项法案，由我方先提议。",
				action28004: "从另一个阶级拿取2点影响力。",
				action28100: "向工人阶级和中产阶级各支付15元。",
				action28101: "查看事件牌堆顶的2张牌。可弃置一个当前事件，不承受其未完成后果，并用查看的一张牌替换；然后执行处理事件行动。",
				action28102: "获得至多2点媒体影响力。选择两个其他阶级，各向我方交付1点私人影响力；国家对这两个阶级的合法性各降低1。",
				action28103: "向一个阶级提供1点私人影响力和2个投票方块；国家对该阶级的合法性提高2。",
				action28104: "选择一个事件，执行其任务两次；两次可作出不同选择。",
				action28105: "根据对外贸易政策获得资金：A为15元，B为30元，C为45元。",
				action28106: "按当前本地售价向外国市场出售至多8单位教育。",
				action28107: "向一个阶级提供等于其人口的医疗；获得该阶级的一个永久合法性标记。",
				action28108: "按当前本地售价向外国市场出售至多8单位医疗。",
				action28109: "将失业工人分配到自己一家尚未运营的企业。",
				action28110: "查看事件牌堆顶的2张牌；有空位时放置其中一张。然后执行处理事件行动。",
				action28111: "至少3项政策已有法案时，选择一项没有法案的政策，将其移至相邻档位。",
				action28112: "支付2点私人影响力，获得40元。",
				action28113: "向一个阶级提供等于其人口的教育；获得该阶级的一个永久合法性标记。",
				action28114: "国家、中产阶级和资本家阶级各获得15元。",
				action28115: "选择一个阶级，按其每名已就业工人提供1元。每提供10元，国家对该阶级的合法性提高1。",
				action28116: "向一个阶级提供20元；获得该阶级的一个永久合法性标记。",
				action28117: "每有一项政策符合当前政治议程，获得1点私人影响力。",
				action28118: "提议一项法案，可免费立即投票。",
				action28120: "选择自己的一家企业，支付工资并生产。",
				action28121: "国家、工人阶级和资本家阶级各获得15元。",
				action28122: "资本家阶级每拥有一家企业，国家向其支付5元。",
				action28123: "每个阶级向国家支付15元。然后选择两个阶级，国家对它们的合法性各降低1。",
				action28124: "移除一家尚未运营的公共企业，用自选的一家没有机器且尚未运营的资本家企业替换；然后可分配工人。财政政策为B时，国家须向资本家支付该企业的建造成本。",
				action28125: "获得25元；有贷款时改为获得35元。",
				action28126: "将自己一家运营中的企业按建造成本出售给资本家阶级，转为私营企业。",
				action28127: "每有一项政策符合当前政治议程，获得10元。",
				action28204: "以每单位5元的价格从外国市场购买医疗，至多购至储存容量。然后向一个阶级提供等于其人口的医疗；每提供3单位，国家对该阶级的合法性提高1。",
				action28300: "向国家出售至多9单位医疗，每单位10元。",
				action28301: "向国家出售至多9单位教育，每单位10元。",
				action28302: "支付25元，提议两项法案。",
				action28303: "选择自己一家尚未运营的企业，支付10元，从供给中为它配齐符合岗位要求的工人。",
				action28304: "将自己一家企业的工资设为等级3。选择一家产业相同、工人数相同的运营公共企业，将其工人分配到自己的该企业。",
				action28305: "执行出口行动；除出口牌的交易外，还可出售至多6单位奢侈品，每单位10元。",
				action28307: "将当前收入的一半转入资本，向下取整。",
				action28308: "揭示接下来的2张出口牌，可用其中一张替换当前出口牌，弃置其余牌；然后可执行出口行动。",
				action28309: "将失业工人分配到自己一家尚未运营的企业；每分配一名，国家向我方支付5元。",
				action28310: "达成一项商业交易，然后可向外国市场出售食物和奢侈品。",
				action28311: "建造两家企业，然后向市场补充相同数量的企业。",
				action28312: "从市场建造一家企业，费用减少10元；或搜索企业牌堆，自选一家企业建造，费用增加10元。",
				action28314: "执行出口行动；除出口牌的交易外，还可出售至多4单位食物，每单位15元。",
				action28315: "建造一家农业或奢侈品企业。自己支付一半建造成本，国家支付另一半。",
				action28316: "向国家出售至多6单位奢侈品，每单位10元；然后获得1点影响力。",
				action28317: "从资本中向国家支付50元，获得7胜利点。",
				action28318: "出售一家没有机器的企业，获得两倍建造成本。",
				action28319: "自己每拥有一家企业，国家向我方支付5元。",
				action28320: "提议政策6法案，将2个自己的投票方块加入票袋。",
				action28322: "选择自己一家未自动化的企业，支付工资并生产。",
				action28323: "提议政策3法案，将2个自己的投票方块加入票袋。",
				action28324: "支付15元，将6个自己的投票方块加入票袋。",
				action28325: "支付20元，放置一台机器；或支付45元，放置两台机器。",
				action28326: "每有一家农业企业，将2个自己的投票方块加入票袋。对外贸易政策为A时，也计入奢侈品企业。",
				action28401: "自己每有一家运营中的医疗企业，国家向我方支付15元。",
				action28501: "从外国市场购买食物或奢侈品，数量至多等于人口，无须支付关税。",
				action28503: "建造一家企业，由国家支付建造成本。",
				action28505: "建造一家企业，并从供给中选择一名中产阶级熟练工人，分配到该企业。",
				action28507: "从市场建造一家企业，费用减少8元；或搜索企业牌堆，自选一家企业建造，费用增加8元。",
				action28509: "揭示下一张出口牌，可用它替换当前出口牌。执行出口行动，每项交易至多执行两次；弃置未选择的牌。",
				action28511: "自己的企业中，每有一家雇用工人阶级工人，国家向我方支付5元；然后可对其中一家企业执行加班。",
				action28518: "从供给中向失业区新增一名自选技能的工人阶级熟练工人；然后可向自己的企业分配至多3名工人阶级失业工人。",
				action28522: "向国家出售至多6单位医疗，每单位10元。",
				action28523: "向自己的企业分配至多3名工人阶级失业工人；每分配一名，国家向我方支付5元。",
				action28524: "向国家出售至多6单位教育，每单位10元。",
				action28525: "将2个自己的投票方块加入票袋。公共及资本家企业中，每有一家雇用我方工人，再加入1个方块。",
				action28526: "按每人口6元支付资金，提高1点繁荣。",
				action28528: "执行出口行动；每完成一项交易，国家向我方支付5元。",
				action28532: "购买一种商品或服务：可从任意数量的来源购买，每个来源至多等于人口；或从单一来源购买，至多等于两倍人口。",
				action28534: "提议政策7法案，将2个自己的投票方块加入票袋。",
				action28535: "免费扩建一种资源的储存区。然后可建造一家企业；若生产该种资源，费用减少4元。",
				action28537: "选择一家运营中的公共企业，由国家支付工资并生产。然后可购买该种资源，数量至多等于人口。",
				action28538: "在公共及资本家企业中，每有一名我方已就业工人，国家向我方支付2元；然后可购买商品与服务。",
				action28603: "在公共及资本家企业中，每有一名我方已就业工人，国家向我方支付2元；再按我方每家企业支付4元。",
				event27900: "支付25元，向各阶级任意分配至多3点媒体影响力。",
				reward27900: "对工人阶级／中产阶级／资本家阶级：每1点影响力，合法性提高1。",
				event27901: "支付至多6单位医疗。",
				reward27901: "每1单位医疗，国家获得1胜利点。",
				event27902: "从其他玩家任意组合购买医疗，上限为公共企业数量。",
				reward27902: "对中产阶级／资本家阶级：每3单位所提供的资源，合法性提高1。",
				event27903: "向一个阶级提供2点媒体影响力。",
				reward27903: "对工人阶级／资本家阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event27904: "向一个阶级提供等于其半数人口向上取整的教育。",
				reward27904: "对工人阶级：合法性提高1。对中产阶级：合法性提高1。",
				event27905: "选择两个阶级，各提供25元。",
				reward27905: "对工人阶级／中产阶级／资本家阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event27906: "支付15、30或45。",
				reward27906: "每15单位，国家获得2胜利点。",
				event27907: "向一个阶级提供等于其半数人口向上取整的医疗。",
				reward27907: "对工人阶级：合法性提高1。对中产阶级：合法性提高1。",
				event27908: "选择向每个阶级提供10元或15。",
				reward27908: "每阶级提供10时，国家获得3胜利点；每阶级提供15时，对每个阶级的合法性提高1。",
				event27909: "向一个阶级按其每名公共部门工人提供5元。",
				reward27909: "对工人阶级：每25单位，获得1个永久合法性标记，并立即提高同等合法性。对中产阶级：每15单位，合法性提高1。",
				event27910: "向一个阶级提供等于其运营企业数一半向上取整的奢侈品。",
				reward27910: "对中产阶级／资本家阶级：每2单位所提供的资源，合法性提高1。",
				event27911: "向一个阶级提供食物，等于其半数人口或半数运营企业数，向上取整。",
				reward27911: "对工人阶级／资本家阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event27912: "向一个阶级按每家运营企业提供5元。",
				reward27912: "对中产阶级：每20单位，获得1个永久合法性标记，并立即提高同等合法性。对资本家阶级：每15单位，国家获得2胜利点。",
				event27913: "向一个阶级提供奢侈品与教育，两种各至少1；总数等于其半数人口或半数运营企业数，向上取整。",
				reward27913: "对工人阶级／资本家阶级：每2单位所提供的资源，合法性提高1。",
				event27914: "向一个阶级提供医疗与教育，两种各至少1；总数等于其半数人口向上取整。",
				reward27914: "对工人阶级／中产阶级：合法性提高1。",
				event27915: "支付至多6单位教育。",
				reward27915: "每1单位教育，国家获得1胜利点。",
				event27916: "支付成本，为另一个阶级建造成本至少15的企业。",
				reward27916: "对中产阶级／资本家阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event27917: "从其他玩家任意组合购买奢侈品，上限为公共企业数量。",
				reward27917: "对中产阶级／资本家阶级：每3单位所提供的资源，合法性提高1。",
				event27918: "向一个阶级提供食物与医疗，两种各至少1；总数等于其半数人口向上取整。",
				reward27918: "对工人阶级／中产阶级：每2单位所提供的资源，合法性提高1。",
				event27919: "向一个阶级提供其人口5倍的资金。",
				reward27919: "对工人阶级：每15单位，国家获得2胜利点。对中产阶级：每20单位，获得1个永久合法性标记，并立即提高同等合法性。",
				event27920: "支付30元，向各阶级任意分配4票。",
				reward27920: "对工人阶级／资本家阶级：每2单位所提供的资源，合法性提高1。",
				event27921: "提议一个由另一玩家选择的法案。",
				reward27921: "对工人阶级／资本家阶级：合法性提高2。",
				event27922: "向一个阶级提供1点私人影响力与2票。",
				reward27922: "对工人阶级／中产阶级／资本家阶级：合法性提高1。",
				event27923: "从其他玩家任意组合购买教育，上限为公共企业数量。",
				reward27923: "对中产阶级／资本家阶级：每3单位所提供的资源，合法性提高1。",
				event27924: "向一个阶级提供食物与奢侈品，两种各至少1；总数等于其半数人口向上取整。",
				reward27924: "对工人阶级：每2单位所提供的资源，合法性提高1。对中产阶级：每2单位所提供的资源，国家获得1胜利点。",
				event21200: "支付4单位教育，每缺1以8资金代替；然后选择一个阶级。",
				benefit21200: "获得1单位教育和1单位奢侈品。",
				reward21200: "对工人阶级／资本家阶级：合法性提高2。",
				event21201: "选择一个有运营教育企业的阶级。",
				benefit21201: "可向国家出售至多2单位教育，每个10；若出售，国家获得1胜利点。",
				reward21201: "对中产阶级／资本家阶级：合法性提高1。",
				event21202: "支付30元，然后选择一个阶级。",
				benefit21202: "获得10元。",
				reward21202: "对工人阶级：合法性提高2。对资本家阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event21203: "选择一个有运营奢侈品企业的阶级。",
				benefit21203: "可向国家出售至多2单位奢侈品，每个10；若出售，国家获得1胜利点。",
				reward21203: "对中产阶级／资本家阶级：合法性提高1。",
				event21204: "支付4单位教育或30元，然后选择一个阶级。",
				benefit21204: "获得2单位教育。",
				reward21204: "对工人阶级／中产阶级：合法性提高2。",
				event21205: "支付4单位医疗或30元，然后选择一个阶级。",
				benefit21205: "获得2单位医疗。",
				reward21205: "对工人阶级／中产阶级：合法性提高2。",
				event21206: "每项不符当前政治议程的政策支付1媒体或私人影响力，然后选择一个阶级。",
				benefit21206: "将2个自己的投票方块加入票袋。",
				reward21206: "对工人阶级：合法性提高2。对资本家阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event21207: "支付1点媒体影响力，然后选择一个阶级。",
				benefit21207: "从国家获得10元。",
				reward21207: "对工人阶级／中产阶级／资本家阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event21208: "支付1点私人影响力及15，然后选择一个阶级。",
				benefit21208: "获得1点影响力。",
				reward21208: "对工人阶级／中产阶级／资本家阶级：合法性提高2。",
				event21209: "支付30元，然后选择一个阶级。",
				benefit21209: "获得5元；可在自己一家企业生产前分配工人给它。",
				reward21209: "对中产阶级：合法性提高2。对资本家阶级：国家获得3胜利点。",
				event21210: "选择一个阶级。",
				benefit21210: "对一项法案投票前，可弃置此牌。国家必须支持该法案，并支付尽可能多的私人影响力，最多2点；本次不能额外投入影响力。",
				reward21210: "对工人阶级／资本家阶级：合法性提高2。",
				event21211: "购买至多5单位食物，然后选择一个阶级。",
				benefit21211: "满足需求时国家给你1单位食物；不能则国家失去1胜利点。",
				reward21211: "对工人阶级／中产阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event21212: "支付2单位医疗及2单位教育，或一种3个另一种1个，然后选择一个阶级。",
				benefit21212: "获得1单位医疗和1单位教育。",
				reward21212: "对工人阶级／中产阶级：国家获得3胜利点。",
				event21213: "选择一个阶级。",
				benefit21213: "缴税步骤少付10。",
				reward21213: "对工人阶级／中产阶级／资本家阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event21214: "支付1点私人影响力及15，然后选择一个阶级。",
				benefit21214: "获得1单位食物。",
				reward21214: "对工人阶级：合法性提高2。对中产阶级：获得1个永久合法性标记，并立即提高同等合法性。对资本家阶级：国家获得3胜利点。",
				event21215: "支付1点私人影响力及2单位教育，然后选择一个阶级。",
				benefit21215: "获得2单位教育。",
				reward21215: "对工人阶级：国家获得3胜利点。对中产阶级：合法性提高2。对资本家阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event21216: "选择一个有运营医疗企业的阶级。",
				benefit21216: "可向国家出售至多2单位医疗，每个10；若出售，国家获得1胜利点。",
				reward21216: "对中产阶级／资本家阶级：合法性提高1。",
				event21217: "选择至少还有1法案标记可用的阶级；每个可用标记支付1媒体或私人影响力。",
				benefit21217: "将2个自己的投票方块加入票袋。",
				reward21217: "对工人阶级：国家获得3胜利点。对资本家阶级：合法性提高2。",
				event21218: "支付30元；选择一个有运营奢侈品企业的阶级。",
				benefit21218: "仅本阶段，每家自己的奢侈品企业产量增加1。",
				reward21218: "对中产阶级／资本家阶级：合法性提高2。",
				event21219: "支付30元，然后选择一个阶级。",
				benefit21219: "获得10元。",
				reward21219: "对工人阶级：合法性提高2。对中产阶级：获得1个永久合法性标记，并立即提高同等合法性。",
				event21220: "支付1点私人影响力及2单位医疗，然后选择一个阶级。",
				benefit21220: "获得2单位医疗。",
				reward21220: "对工人阶级：获得1个永久合法性标记，并立即提高同等合法性。对中产阶级：国家获得3胜利点。对资本家阶级：合法性提高2。",
				event21221: "选择有工人在公共企业的阶级。",
				benefit21221: "领取工资时，每家有自己工人的公共企业国家额外支付5元；然后国家获得1胜利点。",
				reward21221: "对工人阶级：获得1个永久合法性标记，并立即提高同等合法性。对中产阶级：国家获得2胜利点。",
				event21222: "选择一个阶级。",
				benefit21222: "每次建造企业，国家支付其中10元成本并获得1胜利点。",
				reward21222: "对中产阶级／资本家阶级：合法性提高1。",
				event21223: "支付2点私人影响力，然后选择一个阶级。",
				benefit21223: "将2个自己的投票方块加入票袋。",
				reward21223: "对工人阶级／中产阶级／资本家阶级：合法性提高2。",
				event21224: "支付20元，然后选择一个阶级。",
				benefit21224: "选择自己拥有或有工人的一家私营企业；仅此阶段，忽略劳动政策将其工资等级升或降1。",
				reward21224: "对工人阶级／资本家阶级：国家获得2胜利点。",
				agenda21315: "拥有12家企业，其中至少11家运营。",
				agenda21316: "政策1至5中至少3项为C；选举阶段须等所有选举结束。",
				agenda21317: "单次出口行动获得至少240。",
				agenda21318: "每个产业各拥有至少2家企业。",
				agenda21319: "资本至少320。",
				agenda21400: "完成至少10次事件任务。",
				agenda21401: "整局没有取得过贷款；曾借贷即弃此议程。",
				agenda21402: "至少4项政策符合当前政治议程。",
				agenda21403: "拥有至少150资金，政策4及5均为A。",
				agenda21404: "政策1为A，至少6家运营公共企业。",
				agenda21505: "储存区食物、奢侈品、医疗、教育各至少8。",
				agenda21506: "第4轮前至少5家完全运营企业。",
				agenda21507: "拥有8家完全运营企业，并在至少5家公共及／或资本家企业有工人。",
				agenda21508: "政策1至5全部为B；选举阶段须等所有选举结束。",
				agenda21509: "没有失业工人。",
				agenda21610: "拥有至少6点影响力。",
				agenda21611: "拥有至少4个工会。",
				agenda21612: "同一个选举阶段通过自己提出的3项法案。",
				agenda21613: "人口至多7。",
				agenda21614: "同一个生产阶段获得至少240工资。",
				crisis21100: "工人阶级获得等于人口一半的影响力，向上取整；每个工会加入2个投票方块，并移除2名失业工人。中产阶级获得2点影响力；公共及资本家企业中，每有一家雇用我方工人，加入2个投票方块，并移除2名失业工人。",
				crisis21101: "每个阶级向国家支付10元；重复此过程，直到国家有足够资金偿清贷款。",
				crisis21102: "工人阶级移除2名失业工人。",
				crisis21103: "国家获得40元。",
				crisis21104: "执行本牌所示的政策及合法性变化。",
				crisis21105: "国家获得60元。工人阶级和中产阶级各从国家获得10元及至多2单位现有医疗；资本家阶级从国家获得15元。",
				crisis21106: "工人阶级放置3个罢工标记。",
				crisis21107: "第五轮时重新抽取危机牌。各阶级按行动顺序的反向次序，可向国家支付30元或50元。若总额不足以还贷，退还出资并重新抽牌；否则由国家还贷。下轮行动阶段结束前，国家须分别向出资者偿还40元或70元。",
				crisis21108: "每个阶级向国家支付10元。",
				crisis21109: "少于两个工会时，重新抽取危机牌。国家本轮无须支付新增公共企业的建造成本。工人阶级支付10元；资本家阶级支付35元，按自己每两家企业获得1点影响力；中产阶级支付20元，按自己每两家企业获得1点影响力。",
				history0: "开局设置结束时，各阶级按行动顺序提议法案；国家玩家不获得初始私人影响力。",
				history1: "工人阶级和中产阶级各加入2个投票方块。资本家阶级的起始手牌为两张“技术进步”和5张随机行动牌，并获得10元。",
				history2: "工人阶级的起始手牌为两张“变革诉求”和5张随机行动牌。中产阶级加入2个投票方块；国家玩家从公共服务中移除2点媒体影响力。",
				history3: "工人阶级加入4个投票方块，资本家阶级加入1个，中产阶级加入2个。",
				history4: "本轮中，安装机器的奢侈品企业产量增加3。",
				historyReq4: "至少一家企业有机器。",
				history5: "财政和税收政策各向A移动一档，对外贸易政策向A移动一档。本轮公共企业的建造成本减半。工人阶级和中产阶级各移除一名失业工人。资本家阶级可将一家奢侈品企业以32元出售给国家，替换一家尚未运营的公共企业。",
				history6: "工人阶级获得1单位奢侈品。本轮资本家阶级和中产阶级的奢侈品企业产量增加2。国家玩家获得15元。",
				historyReq6: "两人局至少有2家运营中的奢侈品企业；三人及以上时至少有3家。",
				history7: "将财政、劳动市场、税收、医疗与福利政策分别设为A、C、A、A。本轮不举行选举，国家新增公共企业无须支付建造成本。工人阶级建造合作农场；资本家阶级向国家交付一家企业并支付20元，该企业替换一家公共企业。",
				historyReq7: "劳动市场和医疗与福利政策均为B或C，并且至少有一个工会。",
				history8: "本轮不举行选举，各阶级失去1点影响力。国家玩家将两项政策各移至相邻档位，获得2点私人影响力，并将对各阶级的合法性分别降低1。",
				history9: "额外揭示一张商业交易牌。国家获得20元；工人阶级和中产阶级各获得1单位食物；资本家阶级可执行出口或商业交易行动。",
				history10: "工人阶级和中产阶级各移除一名工人，优先移除失业工人。",
				historyReq10: "两人局运营中的医疗企业至多2家；三人及以上时至多3家。",
				history11: "工人阶级和中产阶级各移除一名失业工人；国家失去15元。",
				history12: "将对外贸易政策设为A，弃置所有商业交易牌。",
				historyReq12: "对外贸易政策为B或C。",
				history13: "工人阶级和中产阶级各移除两名工人，优先移除失业工人。国家玩家对这两个阶级的合法性各降低1。",
				historyReq13: "两人局运营中的医疗企业至多2家；三人及以上时至多3家。",
				history14: "财政和劳动市场政策各向A移动一档。工人阶级和中产阶级可分配任意数量的失业工人到公共及资本家企业。每有一名工人新分配到资本家企业，资本家阶级从国家获得5元。",
				historyReq14: "两人局至少有4名失业工人；三人及以上时至少有7名。",
				history15: "劳动市场、医疗与福利、教育政策各向C移动一档。资本家阶级和中产阶级各弃置一家运营企业，将所有售价设为最高档并锁定至本轮结束。国家失去30元。",
				historyReq15: "各阶级的贷款合计至少2笔，或国库资金至多100元。",
				history16: "工人阶级和中产阶级各获得3名非熟练工人，并提高1点繁荣。",
				historyReq16: "劳动市场政策为A或B；两人局至少有两家运营医疗企业，三人及以上至少有三家。",
				history17: "工人阶级获得1点影响力并执行罢工，额外增加等于工会数量的罢工标记。公共及资本家企业中，每有一家雇用中产工人，中产阶级加入1个投票方块。",
				historyReq17: "劳动市场政策为B或C，并且至少有两个工会。",
				history18: "财政、税收和对外贸易政策各向A移动一档。本轮公共企业建造成本减半。工人阶级和中产阶级各移除两名失业工人。资本家阶级可将一家奢侈品企业以32元出售给国家，替换一家尚未运营的公共企业。",
				history19: "对外贸易政策向C移动一档，额外揭示一张商业交易牌，资本家阶级可执行商业交易行动。本轮其他阶级执行出口行动时，国家玩家对该阶级的合法性提高1。",
				historyReq19: "两人局现有农业及奢侈品企业合计至少4家；三人及以上时至少有6家。",
				history20: "工人阶级加入4个投票方块，资本家阶级和中产阶级各加入1个。",
				history21: "工人阶级可分配任意数量的失业工人。本轮资本家阶级安装机器的企业产量增加2。",
				history22: "本轮不举行选举。工人阶级将至多两项政策各移至相邻档位。资本家阶级向国家支付40元。国家玩家可选择一项工人阶级未选择的政策，移至相邻档位。",
				historyReq22: "劳动市场政策为B或C，工人阶级的繁荣至多为3，并且至少有两个工会。",
				history23: "工人阶级执行罢工并加入4个投票方块；中产阶级加入2个投票方块。",
				historyReq23: "工人阶级的繁荣至多为3。",
				history24: "弃置所有商业交易牌。本轮禁止出口，也禁止从外国市场购买商品与服务。",
				historyReq24: "前五项政策中至少2项为A。",
				history25: "国家获得30元；资本家阶级免费建造一家非自动化企业。",
				historyReq25: "前五项政策中至多2项为A。",
				history26: "本轮所有提案均可免费立即投票。工人阶级加入3个投票方块，资本家阶级加入1个，中产阶级加入2个。",
				historyReq26: "两人局各阶级的私人影响力合计至少4点；三人局至少5点；四人局至少7点。",
				history27: "将财政、劳动市场、税收、医疗与福利、教育、对外贸易政策分别设为B、B、B、A、B、B。",
				historyReq27: "两人局至少有4名失业工人；三人及以上时至少有7名。",
				history28: "工人阶级加入4个投票方块；中产阶级获得1点影响力；国家玩家对工人阶级的合法性提高1。",
				historyReq28: "前五项政策中至少三项为B，并且至少有两个工会。三人及以上时，中产阶级的人口还须至少为5。",
				history29: "工人阶级可从资本家阶级购买奢侈品，数量至多为人口的一半，向下取整。中产阶级可从资本家阶级购买奢侈品，数量至多等于人口。",
				historyReq29: "运营奢侈品企业至少3家。",
				history30: "资本家阶级向国家交付一家运营企业，替换一家公共企业，优先替换尚未运营的企业。国家玩家对资本家阶级的合法性降低1。",
				historyReq30: "资本家阶级至少拥有9家企业。国家参局时，还须至少拥有3点私人影响力。",
				history31: "财政和税收政策各向C移动一档，国家获得30元。",
				historyReq31: "前五项政策中至少3项为A。",
				history32: "本轮资本家阶级和中产阶级每次执行建造企业或出口行动时，从国家获得10元；国家玩家对该阶级的合法性提高1。",
				historyReq32: "对外贸易政策为A或B。",
				history33: "本轮媒体企业产量增加1。工人阶级升级一名工人并获得1点影响力。资本家阶级和中产阶级各可执行至多两项出口交易。国家玩家每拥有两家运营公共企业，获得1点私人影响力。",
				historyReq33: "两人局至少有3家运营中的教育企业；三人及以上时至少有5家。",
				history34: "从公共服务中移除3点媒体影响力，各阶级获得1点影响力。国家玩家选择两个阶级，对它们的合法性各提高1。",
				historyReq34: "两人局各阶级的私人影响力合计至少4点；三人及以上时至少5点。",
				history35: "将移民政策设为C。工人阶级和中产阶级各揭示一张移民牌，加入对应工人。",
				history36: "财政、劳动市场、医疗与福利政策各向C移动一档。",
				historyReq36: "国库资金少于100元，并且国家至少有1笔贷款。",
				history37: "本轮外国市场的食物和奢侈品基础售价分别为15元和9元。资本家阶级和中产阶级将食物及奢侈品售价设为最高档，并锁定至本轮结束。",
				history38: "本轮农业企业的产量减少1。",
				history39: "本轮所有提案均可免费立即投票。",
				history40: "资本家阶级和中产阶级按自己每家运营中的奢侈品企业，向国家支付10元。",
				historyReq40: "财政和税收政策均为A或B。",
				history41: "劳动市场和税收政策各向C移动一档。国家向工人阶级支付10元，并向资本家阶级和中产阶级各支付10元，后两者各弃置一家运营企业。国家玩家可支付企业建造成本的一半进行救助，向下取整，并对该阶级提高1点合法性。随后国家玩家选择两个阶级，对它们的合法性各降低1。",
				historyReq41: "各阶级的贷款合计至少2笔。",
				history42: "对外贸易政策向A移动一档，随机移除一张商业交易牌。资本家阶级和中产阶级将奢侈品售价设为最高档，并锁定至本轮结束。",
				history43: "财政、劳动市场、医疗与福利政策各向C移动一档，税收政策向A移动一档。资本家阶级和中产阶级各弃置一家运营企业。国家玩家对各阶级的合法性分别降低1。",
				historyReq43: "各阶级的贷款合计至少2笔。",
				history44: "通过一次共同投票，决定是否将对外贸易和移民政策都设为C。提案通过或两项政策原本均为C时，工人阶级和中产阶级各获得10元，资本家阶级获得25元，国家玩家获得2点私人影响力。本次投票不奖励选举胜利点。",
				history45: "财政、劳动市场、税收政策各向C移动一档。工人阶级和中产阶级移除所有失业工人。资本家阶级可半价购买一家公共企业。",
				historyReq45: "国库资金至多50元，或前五项政策中至少3项为A。",
				history46: "本轮使用医疗、教育或奢侈品时，每次额外获得1胜利点。",
				historyReq46: "工人阶级的繁荣至少为5；中产阶级参局时，其繁荣也须至少为5。",
				history47: "劳动市场政策向A移动一档，税收政策向C移动一档。",
				historyReq47: "劳动市场政策为B或C，税收政策为A或B。",
				history48: "将七项初始政策依次设为C、B、B、A、A、B、B。工人阶级移除2个投票方块，资本家阶级获得2点影响力；国家玩家获得一个工人阶级的永久合法性标记。",
				history49: "将七项初始政策依次设为C、B、B、B、C、A、B。工人阶级获得3点影响力，中产阶级获得1点影响力，资本家阶级加入4个投票方块；国家玩家获得一个资本家阶级的永久合法性标记。"
			},
			options: {
				seats: "真人席位",
				standard: "标准分配",
				seatHelp: "按列出的顺序分配真人席位。所选席位数须与玩家人数一致；人数不匹配时使用标准分配。缺席的必要阶级由官方简易自动对手补齐。",
				automaHelp: "下列设置用于加入未被真人占据的阶级。国家由真人扮演；官方自动对手与平台机器人可同时参加。",
				off: "不额外加入",
				simple: "简易自动对手",
				advanced: "进阶自动对手",
				expansions: "官方扩展与赠卡",
				actionExpansion: "危机与控制：额外行动牌",
				crisisResponse: "危机与控制：危机应对",
				hiddenAgendas: "危机与控制：隐藏议程",
				alternativeEvents: "危机与控制：替代事件",
				historicalEvents: "历史事件",
				controllingNarrative: "掌控话语权赠卡",
				rapidResolution: "快速决议赠卡",
				stateHelp: "包含国家时使用四阶级规则，缺席阶级自动补齐。事件、政治议程与国家合法性只在国家参局时启用。"
			},
			ui: {
				round: "第{{round}}轮 · 共5轮",
				turn: "第{{turn}}次行动",
				setup: "准备开局",
				preparation: "准备阶段",
				action: "行动阶段",
				production: "生产阶段",
				elections: "选举阶段",
				scoring: "计分阶段",
				done: "终局",
				money: "资金",
				revenue: "收入",
				capital: "资本",
				vp: "胜利点",
				population: "人口",
				prosperity: "繁荣",
				wealth: "财富",
				loans: "贷款",
				legitimacy: "合法性",
				permanent: "永久标记",
				storage: "储存区",
				personal: "私人资源",
				prices: "售价",
				benefits: "福利",
				unemployed: "失业区",
				unions: "工会",
				workers: "工人",
				companies: "企业",
				publicSector: "公共部门",
				market: "企业市场",
				policies: "政策",
				foreignTrade: "对外贸易",
				events: "事件",
				history: "历史事件",
				agenda: "议程",
				hand: "行动牌",
				log: "记录",
				close: "关闭",
				back: "返回",
				details: "查看详情",
				choose: "选择行动",
				waiting: "等待{{role}}行动",
				resolving: "正在结算",
				yourTurn: "轮到你行动",
				actions: "可执行行动",
				board: "经济版图",
				government: "政府",
				classBoard: "阶级面板",
				more: "更多",
				confirm: "确认",
				cancel: "取消",
				noChoices: "等待下一步",
				noHand: "没有行动牌",
				cost: "建造成本",
				output: "产量",
				wages: "工资",
				level: "等级{{level}}",
				machine: "机器",
				strike: "罢工",
				committed: "已承诺",
				available: "可分配",
				unskilled: "非熟练",
				vacant: "空岗",
				inactive: "未启用",
				operating: "运营中",
				notOperating: "未运营",
				votes: "投票方块",
				bill: "法案",
				support: "支持",
				oppose: "反对",
				sealed: "已提交影响力",
				export: "出口",
				deal: "商业交易",
				tariff: "关税",
				requirement: "条件",
				effect: "效果",
				reward: "完成奖励",
				penalty: "未完成后果",
				benefit: "持有收益",
				timing: "时机",
				free: "自由行动",
				basic: "基本行动",
				special: "卡牌效果",
				mainReady: "主行动未执行",
				mainDone: "主行动已执行",
				freeReady: "自由行动未执行",
				freeDone: "自由行动已执行",
				viewBoard: "回看版图",
				showResults: "查看结果",
				results: "终局报告",
				winner: "获胜阶级",
				tie: "并列获胜",
				automa: "官方自动对手",
				simple: "简易",
				advanced: "进阶",
				total: "总分",
				otherPoints: "对局中得分",
				playAgain: "再来一局",
				lobby: "返回大厅",
				awaitHost: "等待主机开始下一局",
				confirmLeave: "确定离开本局？",
				confirmAgain: "确定开始新的一局？",
				hints: "求助次数：{{count}}",
				readonly: "最终局面",
				empty: "无",
				taxTable: "税务参考",
				stateAgenda: "政治议程",
				crisis: "危机应对",
				showHand: "查看手牌",
				showMarket: "查看企业市场",
				selectWorker: "选择工人",
				selectDestination: "选择岗位",
				assignmentPreview: "分配预览",
				companyCount: "{{count}}家企业",
				workerCount: "{{count}}名工人",
				cardCount: "{{count}}张牌",
				currency: "{{amount}}元",
				foreign: "外国市场",
				cardRequirement: "须符合政策{{policy}}",
				legitimacyEffect: "合法性变化：{{value}}",
				gainVP: "获得{{count}}胜利点",
				inspect: "检视",
				selected: "已选择",
				drawn: "已揭示",
				bag: "票袋",
				pending: "待表决",
				policyChanges: "政策调整",
				policyLocks: "锁定政策",
				discardBills: "弃置法案",
				allBills: "全部法案",
				eligibleRoles: "适用阶级",
				helper: "辅助岗位",
				extraOutput: "额外产量"
			},
			promo: {
				narrative: "提议一项法案并免费立即投票。在其他阶级宣布支付的影响力后，再决定自己支付多少影响力。",
				rapid: "支付1影响力，对其他阶级的待表决法案立即投票。在抽票前，把支付的影响力放在自己的支持侧或反对侧；提案者照常获得选举得分。"
			},
			eventPenalty: {
				any: "任意两个阶级各失去1合法性。",
				list: "{{roles}}各失去1合法性。"
			},
			timing: {
				anytime: "随时",
				"after-round-1": "第一轮结束后",
				action: "行动阶段",
				"game-end": "游戏结束时",
				elections: "选举结束时",
				production: "生产阶段",
				scoring: "计分阶段",
				setup: "开局设置时",
				reveal: "揭示时",
				active: "行动阶段主动使用",
				"action-end": "行动阶段结束时",
				"before-round-4": "第四轮前",
				actionEnd: "行动阶段结束时",
				free: "作为自由行动",
				basic: "作为基本行动",
				"basic+1influence": "基本行动，另支付1影响力",
				"basic+2influence": "基本行动，另支付2影响力"
			},
			legitimacyText: {
				l0: "国家对工人阶级：合法性提高1",
				l1: "国家对工人阶级：每10名就业工人，合法性提高1",
				l2: "国家对工人阶级：每3名失业工人，合法性提高1",
				l3: "国家对工人阶级：合法性提高1；国家对中产阶级：合法性提高1",
				l4: "国家选择两个阶级，对它们的合法性各降低1",
				l5: "国家对目标阶级：合法性提高2",
				l6: "国家对目标阶级：合法性提高1",
				l7: "国家对中产阶级：合法性提高1；国家对资本家阶级：合法性提高1",
				l8: "国家对目标阶级：每支付10资金，合法性提高1",
				l9: "国家对工人阶级：合法性提高1；国家对资本家阶级：合法性提高1",
				l10: "国家对资本家阶级：每3家企业，合法性提高1",
				l11: "国家对资本家阶级：合法性提高1",
				l12: "国家对目标阶级：每3医疗，合法性提高1",
				l13: "国家对资本家阶级：每3医疗，合法性提高1",
				l14: "国家对资本家阶级：每3教育，合法性提高1",
				l15: "国家对资本家阶级：每3奢侈品，合法性提高1",
				l16: "国家对资本家阶级：每家运营的医疗企业，合法性提高1",
				l17: "国家对中产阶级：合法性提高1",
				l18: "国家对中产阶级：每4件商品，合法性提高1",
				l19: "国家对中产阶级：每3家符合条件的企业，合法性提高1",
				l20: "国家对中产阶级：每3医疗，合法性提高1",
				l21: "国家对中产阶级：每3教育，合法性提高1",
				l22: "国家对中产阶级：每5名符合条件的工人，合法性提高1",
				l23: "国家对中产阶级：每支付15资金，合法性提高1",
				l24: "国家对工人阶级：合法性降低3；国家对中产阶级：合法性降低2",
				l25: "国家对各阶级：每被收取10资金，合法性降低1",
				l26: "国家对各阶级：合法性降低2",
				l27: "国家对各阶级：合法性降低1",
				l28: "国家对各阶级：合法性减半，向上取整",
				l29: "国家对工人阶级：合法性减半，向上取整；国家对中产阶级：合法性减半，向上取整",
				l30: "",
				l31: "国家对资本家阶级：合法性降低3；国家对中产阶级：合法性降低2"
			},
			end: {
				title: "五轮之后 · 阶级报告",
				readBoard: "回看版图",
				winner: "获得胜利",
				tied: "共同获胜",
				scores: "计分报告",
				total: "总胜利点",
				other: "其余对局得分",
				lobby: "返回大厅",
				again: "再来一局",
				waiting: "等待主机安排下一局"
			}
		},
		en: {
			name: "Hegemony",
			desc: "Lead your class through political, economic and social conflict.",
			rules: "Objective:\nLead the Working Class, Middle Class, Capitalist Class or State through five rounds of political and economic competition. The class with the most Victory Points wins. Ties compare matching Policies 1–5 (the Political Agenda for State), then favor State, otherwise compare Voting cubes in the bag. Only a remaining tie shares victory. Official Automas participate in this comparison.\n\nSetup:\nThe standard two-class game uses Working and Capitalist Classes; add the Middle Class for three and the State for four. Solo defaults to the Working Class with required missing classes filled by Simple Automas. Options select human seats and Simple or Advanced Automas. Platform bots occupy ordinary seats. There is no official State Automa.\nInitial Policies are C B A B C B B. Players start with 7 Action cards, take 5 Main Actions per round and draw 5 between rounds. Hands, Hidden Agendas and unrevealed Influence commitments are private.\n\nRound sequence:\nEach round has Preparation, Action, Production, Elections and Scoring. Classes act in Working, Middle, Capitalist, State order for five turns each. Preparation includes Loan interest, market refresh, new Workers and Immigration. Working Class Prosperity falls by 1; Middle Class Prosperity falls by 2.\nOn your turn, play one Action card for its effect or discard it for a Basic Action. You may also take one Free Action before or after your Main Action. Selecting a hand card opens its action choice and allows you to return before confirming.\n· Working Class Basic Actions are Propose a Bill, Assign Workers, Buy Goods & Services, Strike, Demonstration and Apply Political Pressure.\n· Capitalist can Propose, Build or Sell a Company, Export, make a Business Deal, Lobby or Apply Political Pressure.\n· Middle Class combines employment and Company management and can take an Extra Shift.\n· State can Propose, resolve Events, Export, Meet with MPs, take Extra Tax or run a Campaign.\n\nWorkers, Companies and consumption:\nSkilled slots require Workers skilled in the corresponding industry. Working Class Workers can work in Public or Capitalist Companies and Middle Class helper slots. Middle Class Workers can work in their own, Public or Capitalist Companies. Assignments may move several Workers simultaneously. Destinations must meet staffing requirements when finished. If a source Company becomes understaffed, its remaining Workers become unemployed. Newly assigned Workers are committed until Production. A Trade Union requires at least 4 Working Class Workers in its industry.\nA Company operates only when required slots are filled. Machinery increases production. Listed Wages are the total per Company. Labor Policies A/B/C require minimum Wage levels 3/2/1. Middle Class helper Workers add production and receive Wages.\nWorking and Middle Classes cover Food needs equal to Population each round. Health, Education and Luxury are Personal resources, consumed with a Free Action when you have at least your Population. Consuming each resource has the following effect:\n· Health increases Prosperity and adds Workers.\n· Education increases Prosperity and upgrades Workers.\n· Luxury increases Prosperity.\nProsperity increases score according to the class track. Population depends on Worker count, from 3 to 10.\n\nPolicies and Elections:\nThe seven Policies are Fiscal, Labor Market, Taxation, Healthcare & Welfare, Education, Foreign Trade and Immigration. A normal Bill moves a Policy one adjacent space. Each class has at most 3 pending Bills; each Policy can have only one. Spend 1 Influence for an Immediate Vote or wait for Elections. Cards may alter these conditions.\nClasses declare support or opposition, reveal 5 Voting cubes, then secretly commit Personal Influence to add votes. A tie passes the Bill. Its proposer gains 3 VP; other supporting classes that contributed votes gain 1 VP each. Winning-side revealed cubes are removed; losing-side cubes return to the bag. Absent-class cubes still participate as specified by the rules.\n\nProduction, taxes and crises:\nCompanies produce and pay Wages in State, Capitalist, Middle, Working order, then Workers are released. Middle covers Food before Working. Forced payments may require Loans: each provides 50, costs 5 interest between rounds and can be repaid by a Free Action for 50. During Check IMF, State repayment costs 55 per Loan.\nCheck IMF follows needs and precedes taxes. Under Fiscal A/B, the State's second Loan triggers intervention; under C, its first does. Basic intervention sets Policies C C A B C B B and resets minimum Wages. With Crisis Response, resolve a Crisis card instead; its Policy locks last until the next Check IMF.\nWorking pays Income Tax per Population. Middle pays Income Tax per Public or Capitalist workplace and Employment Tax for its operational Companies. Capitalist pays Employment and Corporate Taxes. Income Tax uses Labor Policy at the start of Production: under Labor A, Taxation A/B/C rates are 7/6/5; under B all are 4; under C they are 1/2/3. Employment Tax also depends on Healthcare and Education Policies. Corporate Tax uses Revenue bands.\n\nScoring and game end:\n· Each round Working gains 2 VP per Trade Union.\n· Middle compares fully operational Companies with its Prosperity track and may increase Prosperity.\n· Capitalist moves Revenue to Capital and scores its Wealth level, plus 3 VP per new historical-high level.\n· State scores its two lowest Legitimacy values and the number of Policies matching its Political Agenda; then each class's Legitimacy is halved, rounded up, plus permanent tokens.\nAfter round 5, score final bonuses. For matching Policies 1–5, Working prefers A and Capitalist C: 0–5 matches score 0/1/4/8/12/18 VP. Middle prefers B: 0/1/3/6/10/15 VP.\n· Classes other than Working score 1 VP per 2 Food and per 3 Luxury, Health or Education; State also scores per 3 Media Influence.\n· Working scores 1 VP per 10 money, capped at 15 VP; Middle scores 1 VP per 15 money; State scores 1 VP per 30 money.\n· Capitalist loses 5 VP per Loan.\n· Other classes spend available money toward final debt and lose 1 VP per 5 unpaid.\n\nExpansions:\nCrisis & Control Extra Action Cards, Hidden Agendas, Alternative Events and Crisis Response can be enabled separately. Humans choose one of two Hidden Agendas and score it when achieved. Official Automas hold all their class Agendas and score only the highest achieved Agenda at game end. After an Alternative Event, the beneficiary may keep its benefit card or immediately gain 1 VP.\nHistorical Events selects one card from each of six periods for Setup and the five rounds. Requirements must hold when triggered. Active effects are used once; reveal and end-of-Action effects resolve at their stated times. State-icon sections require a State player. Controlling the Narrative and Rapid Resolution promos can be added separately. Inspect cards for full effects, requirements, Event rewards and ongoing benefits.",
			errors: {
				finished: "The game has ended.",
				turn: "Another player must act in this step.",
				stale: "The position has changed. Choose again.",
				invalid: "That action is unavailable in the current position."
			},
			messages: {
				m001: "Automa revealed AI card {{p1}}",
				m002: "Skip this action",
				m003: "Done",
				m004: "Propose Bill",
				m005: "Assign Workers",
				m006: "Buy Goods & Services",
				m007: "Strike",
				m008: "Demonstration",
				m009: "Apply Political Pressure",
				m010: "Build Company",
				m011: "Sell Company",
				m012: "Sell to Foreign Market",
				m013: "Make Business Deal",
				m014: "Lobby",
				m015: "Extra Shift",
				m016: "Event Action",
				m017: "Meet with MPs",
				m018: "Extra Tax",
				m019: "Campaign",
				m020: "End Turn",
				m021: "Use {{p1}}",
				m022: "Swap Workers",
				m023: "Adjust Prices",
				m024: "Buy Storage",
				m025: "Adjust Wages",
				m026: "Give Bonus",
				m027: "Pay Off Loan (50)",
				m028: "Receive Benefits",
				m029: "Play Card Effect",
				m030: "Back to Hand",
				m031: "{{p1}} ({{p2}} VP)",
				m032: "Choose worker {{p1}}",
				m033: "{{p1}} {{p2}} → {{p3}}",
				m034: "Wait for Elections",
				m035: "Call Immediate Vote",
				m036: "Call Immediate Vote",
				m037: "Assign {{p1}} Workers to {{p2}}",
				m038: "Form {{p1}} Trade Union",
				m039: "unskilled",
				m040: "Choose {{p1}} worker {{p2}}",
				m041: "{{p1}} · Slot {{p2}}",
				m042: "Choose Another Worker",
				m043: "{{p1}} · {{p2}}",
				m044: "Hire {{p1}} worker {{p2}}",
				m045: "{{p1}} · L{{p2}} ({{p3}})",
				m046: "Foreign Market",
				m047: "Buy {{p2}} {{p3}} from {{p1}} ({{p4}})",
				m048: "Sell {{p1}} {{p2}} for {{p3}}",
				m049: "Storage",
				m050: "Free Trade Zone",
				m051: "{{p1}} Food, {{p2}} Luxury · {{p3}} ({{p4}})",
				m052: "{{p1}}: {{p2}}",
				m053: "{{p1}} Storage",
				m054: "Swap workers {{p1}} and {{p2}}",
				m055: "Support Bill",
				m056: "Oppose Bill",
				m057: "Spend {{p1}} Influence",
				m058: "Played {{p1}}",
				m059: "Do Not Buy Bonds",
				m060: "Buy Bond for {{p1}} (Repaid {{p2}} Next Round)",
				m061: "IMF Intervention",
				m062: "Crisis Response: {{p1}}",
				m063: "Food",
				m064: "Luxury",
				m065: "Health",
				m066: "Education",
				m067: "Influence",
				m068: "Working Class",
				m069: "Middle Class",
				m070: "Capitalist Class",
				m071: "State",
				m072: "Fiscal Policy",
				m073: "Labor Market",
				m074: "Taxation",
				m075: "Health & Benefits",
				m076: "Education",
				m077: "Foreign Trade",
				m078: "Immigration",
				m079: "{{p1}}: {{p2}} VP",
				m080: "Took a loan of 50",
				m081: "{{p1}} produced {{p2}}",
				m082: "{{p1}} changed to {{p2}}",
				m083: "{{p1}} · Provide {{p2}}",
				m084: "{{p1}} · {{p2}}",
				m085: "{{p1}} · Spend {{p2}} Education and {{p3}}",
				m086: "{{p1}} · Spend 4 {{p2}}",
				m087: "{{p1}} · Spend {{p2}} Media and {{p3}} Personal Influence",
				m088: "Provide {{p1}} to Every Class",
				m089: "{{p1}} · {{p2}} {{p3}}, {{p4}} {{p5}}",
				m090: "Finish Distribution",
				m091: "Keep Event for its Benefit",
				m092: "Discard Event for 1 VP",
				m093: "Buy {{p2}} {{p3}} from {{p1}}",
				m094: "Provide Resources",
				m095: "Finish Purchases",
				m096: "{{p1}} → {{p2}}",
				m097: "Keep Current Events",
				m098: "Use Event Benefit",
				m099: "Decline Benefit",
				m100: "Keep Event",
				m101: "Discard Event to Require State Support",
				m102: "Do Not Use Hiring Benefit Here",
				m103: "Assign Workers Before Production",
				m104: "{{p1}} · L{{p2}} → L{{p3}}",
				m105: "Remove worker {{p1}}",
				m106: "{{p1}} · {{p2}} ({{p3}})",
				m107: "Pay Capitalist Class 20 for 5 VP",
				m108: "Pay Middle Class 10 for 3 VP",
				m109: "Sell State {{p1}} {{p2}} ({{p3}})",
				m110: "Sell {{p1}} {{p2}} ({{p3}})",
				m111: "Build from market at {{p1}} discount",
				m112: "Search deck and pay {{p1}} extra",
				m113: "Pay 20 for 1 Machinery",
				m114: "Pay 45 for 2 Machinery",
				m115: "Buy up to Population from any number of sources",
				m116: "Buy up to twice Population from one source",
				m117: "Policy {{p1}}{{p2}}",
				m118: "Policy {{p1}}{{p2}} · {{p3}}",
				m119: "Keep current Export card",
				m120: "Choose Export card {{p1}}",
				m121: "Finish Public Sector Adjustment",
				m122: "Open",
				m123: "Close",
				m124: "{{p1}} {{p2}}",
				m125: "{{p1}} loses {{p2}} VP",
				m126: "Finish Demonstration",
				m127: "Call free Immediate Vote with revealed cubes",
				m128: "Return cubes and keep Bill",
				m129: "Remove {{p1}} cube",
				m130: "Return Remaining Cubes",
				m131: "Buy {{p1}} Health ({{p2}})",
				m132: "Hidden Agenda: {{p1}}",
				m133: "Automa Agenda",
				m134: "Voting on Policy {{p1}}{{p2}}",
				m135: "passed",
				m136: "failed",
				m137: "Bill {{p1}}: {{p2}} in favor, {{p3}} against",
				m138: "Outstanding Loans",
				m139: "Policy Bonus",
				m140: "Remaining Resources",
				m141: "Remaining Money",
				m142: "No eligible target for the current effect",
				m143: "Round {{p1}} Trade Unions",
				m144: "Round {{p1}} Wealth",
				m145: "Round {{p1}} Legitimacy",
				m146: "Round {{p1}} Political Agenda",
				m147: "Decline Rescue",
				m148: "Pay half its cost to Rescue Company",
				n001: "Specialization",
				n002: "Highlight Social Issues",
				n003: "Cooperative Farm",
				n004: "Healthcare Benefits",
				n005: "State Scholarship",
				n006: "Healthcare Movement",
				n007: "Workers Movement",
				n008: "Student Movement",
				n009: "Immigration Reform",
				n010: "Need for Change",
				n011: "Labor Market Deregulation",
				n012: "Workplace Accident",
				n013: "Proletarians of the World, Unite!",
				n014: "Boost Domestic Tourism",
				n015: "Supplemental Income Program",
				n016: "Extra Shift",
				n017: "Affordable Housing",
				n018: "Signing Bonus",
				n019: "General Strike",
				n020: "Unemployment Benefits",
				n021: "Public Opinion Polling",
				n022: "Fake News",
				n023: "Interest Groups",
				n024: "Radical Reforms",
				n025: "Migration",
				n026: "Health Crisis",
				n027: "Higher Education Program",
				n028: "Political Pressure",
				n029: "Foreign Recruitment",
				n030: "Competitive Wages",
				n031: "Global Branding",
				n032: "Offshore Companies",
				n033: "Foreign Market Insight",
				n034: "Unemployment Initiative Program",
				n035: "Foreign Partner",
				n036: "Business Expansion",
				n037: "Investment Opportunities",
				n038: "Global Food Crisis",
				n039: "Industrialization",
				n040: "Bid Rigging",
				n041: "Private Island",
				n042: "Exit Strategy",
				n043: "Business Grants",
				n044: "Foreign Trade Lobby",
				n045: "Taxation Lobby",
				n046: "Endorse Political Campaign",
				n047: "Technological Progress",
				n048: "Trade Protectionism Lobby",
				n049: "Import Subsidy",
				n050: "Small Business Grant",
				n051: "Land of Opportunity",
				n052: "Employment Subsidy",
				n053: "Voice of Middle Class Workers",
				n054: "New Theme Park",
				n055: "Export Subsidy",
				n056: "Personal Consumption",
				n057: "Growing Business",
				n058: "Public Sector Overtime",
				n059: "Employment Support Scheme",
				n060: "Shift Focus",
				n061: "Denial of Free Speech",
				n062: "Step for Representation",
				n063: "Immediate Response",
				n064: "Geopolitical Support",
				n065: "Foreign Students",
				n066: "Healthcare Program",
				n067: "Medical Tourism",
				n068: "A Matter of High Priority",
				n069: "Emergency State",
				n070: "Foreign Investment Program",
				n071: "Literacy Program",
				n072: "Growth in Tourism",
				n073: "Allowances and Subsidies",
				n074: "Agenda-Setting",
				n075: "Pressing Matters",
				n076: "Construction Boom",
				n077: "Higher VAT",
				n078: "Nationalization",
				n079: "Quantitative Easing",
				n080: "Privatization",
				n081: "Foreign Financial Assistance",
				n082: "Protect the Status Quo",
				n083: "Change of Government Agenda",
				n084: "Momentum for Change",
				n085: "Reveal Political Scandal",
				n086: "Rising Covid-19 Cases",
				n087: "Covid-19 Vaccination Program",
				n088: "Covid-19 Vaccine R&D Funding",
				n089: "Covid-19 Stimulus Package",
				n090: "Controlling the Narrative",
				n091: "Rapid Resolution",
				literal: "{{value}}"
			},
			content: {
				name000: "Supermarket",
				name001: "Shopping Mall",
				name002: "College",
				name003: "Clinic",
				name004: "Fish Farm",
				name005: "Vegetable Farm",
				name006: "Fast Food Chain",
				name007: "Automated Grain Farm",
				name008: "Automated Dairy Farm",
				name009: "Stadium",
				name010: "Hotel",
				name011: "Fashion Company",
				name012: "Electronics Manufacturer",
				name013: "Car Manufacturer",
				name014: "Pharmaceutical Company",
				name015: "Medical Village",
				name016: "Hospital",
				name017: "Institute of Technology",
				name018: "University",
				name019: "Academy",
				name020: "TV Station",
				name021: "Publishing House",
				name022: "Lobbying Firm",
				name023: "Radio Station",
				name024: "Convenience Store",
				name025: "Doctor's Office",
				name026: "Fast Food Restaurant",
				name027: "Organic Farm",
				name028: "Jewelry Store",
				name029: "Game Store",
				name030: "Electronics Store",
				name031: "Pharmacy",
				name032: "Medical Laboratory",
				name033: "Training Center",
				name034: "Tutoring Company",
				name035: "Private School",
				name036: "PR Agency",
				name037: "Local Newspaper",
				name038: "Regional Radio Station",
				name039: "Regional TV Station",
				name040: "Public University",
				name041: "Public Hospital",
				name042: "National Public Broadcasting",
				name043: "Technical University",
				name044: "University Hospital",
				name045: "Cooperative Farm",
				name046: "Political Scandal",
				name047: "Neighbors at War",
				name048: "Pandemic",
				name049: "Strike at the Port",
				name050: "Low Education Index",
				name051: "Need for Sustainability Initiative",
				name052: "Fear of Deflation",
				name053: "Declining Birth Rate",
				name054: "Need for Stimulus Package",
				name055: "Demand for Thirteenth Month Pay",
				name056: "Companies Demand Better Internet",
				name057: "Drought",
				name058: "Local Industries in Turmoil",
				name059: "Technological Illiteracy",
				name060: "Demand for Higher Welfare Standards",
				name061: "Developing Countries in Need",
				name062: "Infant Industry Requires Help",
				name063: "Outdated Public Sector Infrastructure",
				name064: "Earthquake",
				name065: "Demand for Pension Reform",
				name066: "Political Polarization",
				name067: "Civil Unrest",
				name068: "Unfair Representation",
				name069: "Low University Ratings",
				name070: "Global Supply Chain Crisis",
				name071: "Low Global Innovation Index Ranking",
				name072: "Demand for Better Public Education",
				name073: "Demand for Subsidies by Dairy Farmers",
				name074: "Demand for Administrative Upgrade",
				name075: "High Illiteracy Rate",
				name076: "Low Vaccination Rates",
				name077: "Political Pressure",
				name078: "Demand for Energy Subsidy",
				name079: "Smear Campaign",
				name080: "Demand for Economic Stimulus",
				name081: "Public Pressure",
				name082: "Hurricane",
				name083: "Rising Traffic Accidents",
				name084: "Tax Returns",
				name085: "Fear of Recession",
				name086: "Student Protest",
				name087: "Rising Flu Infections",
				name088: "Low Political Engagement",
				name089: "Demand for Digital Transformation",
				name090: "Rising Economic Inequality",
				name091: "Healthcare Scandal",
				name092: "Public Sector Union Negotiations",
				name093: "Demand for Startup Support",
				name094: "Gerrymandering",
				name095: "Demand for State Intervention",
				name096: "Corporate Empire",
				name097: "Toward a Neoliberal State",
				name098: "Export Tycoon",
				name099: "Diversified Portfolio",
				name100: "Venture Capitalist",
				name101: "Leviathan",
				name102: "Expert Budgeter",
				name103: "According to Plan",
				name104: "Strong Welfare State",
				name105: "State-Led Economy",
				name106: "Entrepreneur",
				name107: "Successful Startup",
				name108: "Growing Middle Class",
				name109: "Golden Compromise",
				name110: "We Work, We Thrive",
				name111: "Rally the Masses",
				name112: "Workers, Unite!",
				name113: "Working Class Push",
				name114: "Small Labor Force",
				name115: "The Surplus Value Is Ours!",
				name116: "Washington Consensus",
				name117: "Failed IMF Negotiations",
				name118: "Moderate IMF Intervention",
				name119: "Japanese Model",
				name120: "Basic IMF Intervention",
				name121: "US Stimulus Package",
				name122: "IMF Intervention with Resistance",
				name123: "New Government Bond Program",
				name124: "EU Austerity Measures",
				name125: "Failed IMF Intervention: Revolution",
				name126: "French Revolution",
				name127: "Industrial Revolution",
				name128: "Revolutions of 1848",
				name129: "Foundation of the International Alliance of Women",
				name130: "Moving Assembly Line",
				name131: "World War I",
				name132: "Introduction of the Ford Model T",
				name133: "Russian Revolution",
				name134: "Rise of Authoritarianism",
				name135: "Panama Canal Opens",
				name136: "Spanish Flu",
				name137: "Russo-Japanese War",
				name138: "Rise of Protectionism",
				name139: "Bengal Famine",
				name140: "New Deal",
				name141: "Great Depression",
				name142: "Baby Boom",
				name143: "General Motors Sit-Down Strike",
				name144: "World War II",
				name145: "General Agreement on Tariffs and Trade",
				name146: "Indian Independence",
				name147: "Post-War Economic Miracle",
				name148: "Chinese Communist Revolution",
				name149: "Civil Rights Movement",
				name150: "Cuban Embargo",
				name151: "Marshall Plan",
				name152: "Decolonization",
				name153: "The Keynesian Era",
				name154: "Rise of the European Left",
				name155: "Consumerism",
				name156: "Arab Nationalization of Oil",
				name157: "Chinese Economic Reforms",
				name158: "Rise of the Asian Tigers",
				name159: "World Wide Web",
				name160: "End of Dictatorships in Southern Europe",
				name161: "Fall of the Berlin Wall",
				name162: "Latin American Debt Crisis",
				name163: "Oil Crisis",
				name164: "Indian Drought",
				name165: "Elections in Ex-Soviet Countries",
				name166: "EU Emissions Trading System",
				name167: "US Financial Crisis",
				name168: "US-China Trade War",
				name169: "European Debt Crisis",
				name170: "Maastricht Treaty",
				name171: "Dissolution of the Soviet Union",
				name172: "Rise of the Middle Class in Asia",
				name173: "Yellow Vests Movement",
				name174: "Bismarckian Reforms",
				name175: "American Revolution",
				action24900: "Add a skilled Worker of your choice from the Supply to the Unemployed area. Then assign up to 3 unemployed Workers.",
				action24902: "Buy 3 Influence from the State for a total of 15.",
				action24903: "With at least 3 unemployed Workers, build a Cooperative Farm and assign 3 Workers to it.",
				action24905: "Buy Health from the State, up to your Population, at half price, rounded up.",
				action24907: "Propose a Bill for Policy 4. Add 2 of your Voting cubes to the bag.",
				action24908: "Propose 2 Bills.",
				action24911: "Assign any number of unemployed Workers. Under Policy 2C, you may also reassign any number of employed Workers.",
				action24913: "With at least 4 unemployed Workers, remove up to 2 of them. Gain 5 per unskilled Worker and 10 per skilled Worker removed.",
				action24915: "Propose a Bill for Policy 2. Add 2 of your Voting cubes to the bag.",
				action24916: "Choose an industry and another player. That player pays you 8 for each of their Companies in that industry employing your Workers.",
				action24917: "Add Voting cubes equal to your Population to the bag.",
				action24919: "Buy Luxury from other players, up to your Population. Pay half the price, rounded up; the State pays the rest.",
				action24921: "Propose a Bill and reveal 5 Voting cubes. You may use these cubes for a free Immediate Vote; otherwise return them to the bag.",
				action24922: "Propose a Bill for Policy 5. Add 2 of your Voting cubes to the bag.",
				action24923: "Receive 1 from the State for each of your employed Workers. Then you may Buy Goods & Services.",
				action24925: "Choose an operational Public Company. The State pays its Wages and produces with it. You may then buy the resource it produced from the State, up to your Population.",
				action24927: "Pay the Capitalist Class 20 to gain 5 VP, or pay the Middle Class 10 to gain 3 VP.",
				action24928: "Propose a Bill for Policy 7. Add 2 of your Voting cubes to the bag.",
				action24929: "Assign up to 4 unemployed Workers. For each assigned Worker, receive 4 from the Company's owner.",
				action24931: "Perform a Strike action, with additional Strike tokens equal to your number of Trade Unions.",
				action24932: "Draw 6 Voting cubes. Remove up to 4 of them and return the rest to the bag.",
				action24934: "Buy Education from the State, up to your Population, at half price, rounded up.",
				action24936: "Propose a Bill for any other section of a Policy, including a non-adjacent section. You cannot call an Immediate Vote.",
				action24937: "Receive 5 from the State per unemployed Worker. Then you may Buy Goods & Services from the State.",
				action24939: "Reveal Voting cubes until 3 opposing cubes appear. Replace those 3 with your cubes and return all revealed cubes to the bag.",
				action28000: "Receive free Health from the State, up to half your Population, rounded up. You may then buy Health from any number of sources, up to your Population from each.",
				action28001: "Gain 1 Influence per Bill marker you have on the Politics table. Then propose a Bill without calling an Immediate Vote.",
				action28002: "Choose a Policy and place your Bill marker at its current section. No Bills may be proposed for it this round. Gain 1 Influence.",
				action28003: "With no more than 3 Bills on the table, discard another player's Bill. You may each propose a Bill, beginning with you.",
				action28004: "Take 2 Influence from another player.",
				action28100: "Pay 15 to the Working Class and 15 to the Middle Class.",
				action28101: "Look at the top 2 Events. You may replace a current Event with one of them without suffering its penalty. Then perform an Event Action.",
				action28102: "Gain up to 2 Media Influence. Choose 2 other players: each gives you 1 Influence and loses 1 Legitimacy.",
				action28103: "Provide a class with 1 Personal Influence and 2 Voting cubes. Increase its Legitimacy by 2.",
				action28104: "Perform the same Event Action twice. You may make different choices each time.",
				action28105: "Gain money according to Foreign Trade Policy: 15 under 6A, 30 under 6B, or 45 under 6C.",
				action28106: "Sell up to 8 Education to the Foreign Market at the current Public Education price.",
				action28107: "Provide a class with Health equal to its Population. It gains 1 permanent Legitimacy token.",
				action28108: "Sell up to 8 Health to the Foreign Market at the current Public Health price.",
				action28109: "Assign unemployed Workers to one of your non-operational Companies.",
				action28110: "Look at the top 2 Events. If a space is available, add one of them. Then perform an Event Action.",
				action28111: "With Bills on at least 3 Policies, choose a Policy without a Bill and move its marker to an adjacent section.",
				action28112: "Spend 2 Personal Influence to gain 40.",
				action28113: "Provide a class with Education equal to its Population. It gains 1 permanent Legitimacy token.",
				action28114: "The State, Middle Class and Capitalist Class each gain 15.",
				action28115: "Provide a class with 1 per employed Worker. Increase its Legitimacy by 1 for every 10 provided.",
				action28116: "Provide a class with 20. It gains 1 permanent Legitimacy token.",
				action28117: "Gain 1 Personal Influence for each Policy matching the current Political Agenda.",
				action28118: "Propose a Bill. You may call a free Immediate Vote.",
				action28120: "Choose one of your operational Companies, pay its Wages and produce with it.",
				action28121: "The State, Working Class and Capitalist Class each gain 15.",
				action28122: "Provide the Capitalist Class with 5 per Company it owns.",
				action28123: "Each other player pays 15 to the State. Choose 2 classes and reduce their Legitimacy by 1 each.",
				action28124: "Replace a non-operational Public Company with a non-operational Capitalist Company without Machinery. You may assign Workers to it. Under Policy 1B, pay its cost to the Capitalist Class.",
				action28125: "Gain 25, or 35 if you have a Loan.",
				action28126: "Sell one of your operational Companies to the Capitalist Class for its cost and move it into the private sector.",
				action28127: "Gain 10 for each Policy matching the current Political Agenda.",
				action28204: "Buy Health from the Foreign Market at 5 each, up to storage capacity. Then provide a class with Health equal to its Population, gaining 1 Legitimacy per 3 Health provided.",
				action28300: "Sell up to 9 Health to the State for 10 each.",
				action28301: "Sell up to 9 Education to the State for 10 each.",
				action28302: "Pay 25 to propose 2 Bills.",
				action28303: "Choose one of your non-operational Companies. Pay 10 and fill its slots with matching Workers from the Supply.",
				action28304: "Set one of your Companies to L3 Wages. Move the Workers from an operational Public Company of the same industry with the same number of Workers to your Company.",
				action28305: "Sell to the Foreign Market. In addition to its listed transactions, you may sell up to 6 Luxury for 10 each.",
				action28307: "Move half your Revenue, rounded down, into Capital.",
				action28308: "Reveal the next 2 Export cards. You may replace the current card with one of them; discard the others. Then you may export.",
				action28309: "Assign unemployed Workers to one of your non-operational Companies. The State pays you 5 per assigned Worker.",
				action28310: "Make a Business Deal. Then you may sell Food and/or Luxury to the Foreign Market.",
				action28311: "Build up to 2 Companies, replenishing your Market for each Company built.",
				action28312: "Build a Company from your Market at a discount of 10, or choose one from your Company deck and pay 10 extra.",
				action28314: "Sell to the Foreign Market. In addition to its listed transactions, you may sell up to 4 Food for 15 each.",
				action28315: "Build an Agricultural or Luxury Company. Pay half its cost; the State pays the rest.",
				action28316: "Sell up to 6 Luxury to the State for 10 each. Then gain 1 Influence.",
				action28317: "Pay 50 from Capital to the State to gain 7 VP.",
				action28318: "Sell a Company without Machinery for twice its construction cost.",
				action28319: "Receive 5 from the State per Company you own.",
				action28320: "Propose a Bill for Policy 6. Add 2 of your Voting cubes to the bag.",
				action28322: "Choose one of your non-automated operational Companies, pay its Wages and produce with it.",
				action28323: "Propose a Bill for Policy 3. Add 2 of your Voting cubes to the bag.",
				action28324: "Pay 15 to add 6 of your Voting cubes to the bag.",
				action28325: "Pay 20 to place 1 Machinery token, or 45 to place 2 Machinery tokens.",
				action28326: "Add 2 Voting cubes per Agricultural Company you own. Under Policy 6A, also count your Luxury Companies.",
				action28401: "Receive 15 from the State per operational Healthcare Company you own.",
				action28501: "Buy Food or Luxury from the Foreign Market, up to your Population, without paying tariffs.",
				action28503: "Build a Company; the State pays its cost.",
				action28505: "Build a Company using a skilled Middle Class Worker of your choice from the Supply.",
				action28507: "Build a Company from your Market at a discount of 8, or choose one from your Company deck and pay 8 extra.",
				action28509: "Reveal the next Export card and choose whether to replace the current card. Discard the other card. Then export, using each transaction up to twice.",
				action28511: "Receive 5 from the State per Company of yours employing a Working Class Worker. Then you may perform an Extra Shift in one of those Companies.",
				action28518: "Add a skilled Working Class Worker of your choice from the Supply to the Unemployed area. Then you may assign up to 3 unemployed Working Class Workers to your Companies.",
				action28522: "Sell up to 6 Health to the State for 10 each.",
				action28523: "Assign up to 3 unemployed Working Class Workers to your Companies. Receive 5 from the State per assigned Worker.",
				action28524: "Sell up to 6 Education to the State for 10 each.",
				action28525: "Add 2 Voting cubes, plus 1 per Public or Capitalist Company employing your Workers.",
				action28526: "Pay 6 per Population to increase your Prosperity by 1.",
				action28528: "Sell to the Foreign Market. Receive 5 from the State for each transaction.",
				action28532: "Buy one resource from any number of sources, up to your Population from each, or buy up to twice your Population from one source.",
				action28534: "Propose a Bill for Policy 7. Add 2 of your Voting cubes to the bag.",
				action28535: "Build a Storage for a chosen resource for free. Then you may build a Company; reduce its cost by 4 if it produces that resource.",
				action28537: "Choose an operational Public Company. The State pays its Wages and produces with it. You may then buy that resource, up to your Population.",
				action28538: "Receive 2 from the State per Worker you employ in Public and Capitalist Companies. Then you may Buy Goods & Services.",
				action28603: "Receive 2 from the State per Worker you employ in Public or Capitalist Companies, plus 4 per Company you own.",
				event27900: "Pay 25 and distribute up to 3 Media Influence among classes.",
				reward27900: "Working Class/Middle Class/Capitalist Class: Per 1 influence, gain 1 Legitimacy.",
				event27901: "Spend up to 6 Health.",
				reward27901: "Per 1 health, the State gains 1 VP.",
				event27902: "Buy Health from any combination of other players, up to the number of Public Companies.",
				reward27902: "Middle Class/Capitalist Class: Per 3 units, gain 1 Legitimacy.",
				event27903: "Provide 2 Media Influence to one class.",
				reward27903: "Working Class/Capitalist Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event27904: "Provide Education to one class equal to half its Population, rounded up.",
				reward27904: "Working Class: gain 1 Legitimacy. Middle Class: gain 1 Legitimacy.",
				event27905: "Choose two different classes and provide 25 to each.",
				reward27905: "Working Class/Middle Class/Capitalist Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event27906: "Pay 15, 30 or 45.",
				reward27906: "Per 15 units, the State gains 2 VP.",
				event27907: "Provide Health to one class equal to half its Population, rounded up.",
				reward27907: "Working Class: gain 1 Legitimacy. Middle Class: gain 1 Legitimacy.",
				event27908: "Provide either 10 to every class or 15 to every class.",
				reward27908: "Provide 10 each: State gains 3 VP. Provide 15 each: gain 1 Legitimacy with every class.",
				event27909: "Provide 5 to one class for each of its Workers employed in Public Companies.",
				reward27909: "Working Class: Per 25 units, gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy. Middle Class: Per 15 units, gain 1 Legitimacy.",
				event27910: "Provide Luxury to one class equal to half its operational Companies, rounded up.",
				reward27910: "Middle Class/Capitalist Class: Per 2 units, gain 1 Legitimacy.",
				event27911: "Provide Food to the Working Class equal to half its Population, or to the Capitalist Class equal to half its operational Companies, rounded up.",
				reward27911: "Working Class/Capitalist Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event27912: "Provide 5 to one class for each of its operational Companies.",
				reward27912: "Middle Class: Per 20 units, gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy. Capitalist Class: Per 15 units, the State gains 2 VP.",
				event27913: "Provide Luxury and Education to one class, at least 1 of each. The total equals half its Population (Working Class) or half its operational Companies (Capitalist Class), rounded up.",
				reward27913: "Working Class/Capitalist Class: Per 2 units, gain 1 Legitimacy.",
				event27914: "Provide Health and Education to one class, at least 1 of each. The total equals half its Population, rounded up.",
				reward27914: "Working Class/Middle Class: gain 1 Legitimacy.",
				event27915: "Spend up to 6 Education.",
				reward27915: "Per 1 education, the State gains 1 VP.",
				event27916: "Pay the construction cost to build a Company costing at least 15 for another class.",
				reward27916: "Middle Class/Capitalist Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event27917: "Buy Luxury from any combination of other players, up to the number of Public Companies.",
				reward27917: "Middle Class/Capitalist Class: Per 3 units, gain 1 Legitimacy.",
				event27918: "Provide Food and Health to one class, at least 1 of each. The total equals half its Population, rounded up.",
				reward27918: "Working Class/Middle Class: Per 2 units, gain 1 Legitimacy.",
				event27919: "Provide money to one class equal to 5 times its Population.",
				reward27919: "Working Class: Per 15 units, the State gains 2 VP. Middle Class: Per 20 units, gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event27920: "Pay 30 and distribute 4 Voting cubes among classes.",
				reward27920: "Working Class/Capitalist Class: Per 2 units, gain 1 Legitimacy.",
				event27921: "Propose a Bill chosen by another player.",
				reward27921: "Working Class/Capitalist Class: gain 2 Legitimacy.",
				event27922: "Provide 1 Personal Influence and 2 Voting cubes to one class.",
				reward27922: "Working Class/Middle Class/Capitalist Class: gain 1 Legitimacy.",
				event27923: "Buy Education from any combination of other players, up to the number of Public Companies.",
				reward27923: "Middle Class/Capitalist Class: Per 3 units, gain 1 Legitimacy.",
				event27924: "Provide Food and Luxury to one class, at least 1 of each. The total equals half its Population, rounded up.",
				reward27924: "Working Class: Per 2 units, gain 1 Legitimacy. Middle Class: Per 2 units, the State gains 1 VP.",
				event21200: "Spend 4 Education, paying 8 for each missing Education. Then choose a class.",
				benefit21200: "During Preparation, gain 1 Education and 1 Luxury.",
				reward21200: "Working Class/Capitalist Class: gain 2 Legitimacy.",
				event21201: "Choose a class with an operational Education Company.",
				benefit21201: "During Production, you may sell up to 2 Education to the State for 10 each. If you sell any, the State gains 1 VP.",
				reward21201: "Middle Class/Capitalist Class: gain 1 Legitimacy.",
				event21202: "Pay 30, then choose a class.",
				benefit21202: "During Production, gain 10.",
				reward21202: "Working Class: gain 2 Legitimacy. Capitalist Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event21203: "Choose a class with an operational Luxury Company.",
				benefit21203: "During Production, you may sell up to 2 Luxury to the State for 10 each. If you sell any, the State gains 1 VP.",
				reward21203: "Middle Class/Capitalist Class: gain 1 Legitimacy.",
				event21204: "Spend 4 Education or pay 30, then choose a class.",
				benefit21204: "During Preparation, gain 2 Education.",
				reward21204: "Working Class/Middle Class: gain 2 Legitimacy.",
				event21205: "Spend 4 Health or pay 30, then choose a class.",
				benefit21205: "During Preparation, gain 2 Health.",
				reward21205: "Working Class/Middle Class: gain 2 Legitimacy.",
				event21206: "Spend 1 Media or Personal Influence for each Policy that differs from the current Political Agenda. Then choose a class.",
				benefit21206: "During Elections, add 2 of your Voting cubes to the bag.",
				reward21206: "Working Class: gain 2 Legitimacy. Capitalist Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event21207: "Spend 1 Media Influence, then choose a class.",
				benefit21207: "During Production, receive 10 from the State.",
				reward21207: "Working Class/Middle Class/Capitalist Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event21208: "Spend 1 Personal Influence and pay 15, then choose a class.",
				benefit21208: "During Elections, gain 1 Influence.",
				reward21208: "Working Class/Middle Class/Capitalist Class: gain 2 Legitimacy.",
				event21209: "Pay 30, then choose a class.",
				benefit21209: "During Production, gain 5. Before one of your Companies produces, you may assign unemployed Workers to it.",
				reward21209: "Middle Class: gain 2 Legitimacy. Capitalist Class: the State gains 3 VP.",
				event21210: "Choose a class.",
				benefit21210: "Before voting on a Bill, discard this card to require the State to support it and spend as much Personal Influence as possible, up to 2. The State cannot spend additional Influence in this Election.",
				reward21210: "Working Class/Capitalist Class: gain 2 Legitimacy.",
				event21211: "Buy up to 5 Food, then choose a class.",
				benefit21211: "When covering your needs, receive 1 Food from the State. If it cannot provide it, the State loses 1 VP.",
				reward21211: "Working Class/Middle Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event21212: "Spend 4 resources: either 2 Health and 2 Education, or 3 of one and 1 of the other. Then choose a class.",
				benefit21212: "During Preparation, gain 1 Health and 1 Education.",
				reward21212: "Working Class/Middle Class: the State gains 3 VP.",
				event21213: "Choose a class.",
				benefit21213: "Pay 10 less during the Pay Taxes step.",
				reward21213: "Working Class/Middle Class/Capitalist Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event21214: "Spend 1 Personal Influence and pay 15, then choose a class.",
				benefit21214: "During Production, gain 1 Food.",
				reward21214: "Working Class: gain 2 Legitimacy. Middle Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy. Capitalist Class: the State gains 3 VP.",
				event21215: "Spend 1 Personal Influence and 2 Education, then choose a class.",
				benefit21215: "During Preparation, gain 2 Education.",
				reward21215: "Working Class: the State gains 3 VP. Middle Class: gain 2 Legitimacy. Capitalist Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event21216: "Choose a class with an operational Health Company.",
				benefit21216: "During Production, you may sell up to 2 Health to the State for 10 each. If you sell any, the State gains 1 VP.",
				reward21216: "Middle Class/Capitalist Class: gain 1 Legitimacy.",
				event21217: "Choose a class with at least one available Bill marker. Spend 1 Media or Personal Influence for each available marker.",
				benefit21217: "During Elections, add 2 of your Voting cubes to the bag.",
				reward21217: "Working Class: the State gains 3 VP. Capitalist Class: gain 2 Legitimacy.",
				event21218: "Pay 30 and choose a class with an operational Luxury Company.",
				benefit21218: "During this Production phase, each of your Luxury Companies produces 1 extra Luxury.",
				reward21218: "Middle Class/Capitalist Class: gain 2 Legitimacy.",
				event21219: "Pay 30, then choose a class.",
				benefit21219: "During Production, gain 10.",
				reward21219: "Working Class: gain 2 Legitimacy. Middle Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy.",
				event21220: "Spend 1 Personal Influence and 2 Health, then choose a class.",
				benefit21220: "During Preparation, gain 2 Health.",
				reward21220: "Working Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy. Middle Class: the State gains 3 VP. Capitalist Class: gain 2 Legitimacy.",
				event21221: "Choose a class with Workers employed in Public Companies.",
				benefit21221: "When receiving Wages, the State pays you 5 extra for each Public Company employing your Workers. The State then gains 1 VP.",
				reward21221: "Working Class: gain 1 permanent Legitimacy token(s) and the same immediate Legitimacy. Middle Class: the State gains 2 VP.",
				event21222: "Choose a class.",
				benefit21222: "Whenever you build a Company, the State pays 10 of its cost and gains 1 VP.",
				reward21222: "Middle Class/Capitalist Class: gain 1 Legitimacy.",
				event21223: "Spend 2 Personal Influence, then choose a class.",
				benefit21223: "During Elections, add 2 of your Voting cubes to the bag.",
				reward21223: "Working Class/Middle Class/Capitalist Class: gain 2 Legitimacy.",
				event21224: "Pay 20, then choose a class.",
				benefit21224: "During Production, choose a private Company you own or that employs your Workers. Raise or lower its Wage level by 1 for this phase, ignoring Labor Market policy.",
				reward21224: "Working Class/Capitalist Class: the State gains 2 VP.",
				agenda21315: "Own 12 Companies, at least 11 of them operational.",
				agenda21316: "After round 1, at least 3 of Policies 1–5 must be C. During Elections, check only after all Elections finish.",
				agenda21317: "Earn at least 240 in a single Export action.",
				agenda21318: "At game end, own at least 2 Companies in each industry.",
				agenda21319: "At game end, have at least 320 Capital.",
				agenda21400: "Complete at least 10 Event tasks.",
				agenda21401: "Finish the game without taking a Loan. Discard this Agenda if you ever take one.",
				agenda21402: "During Scoring, at least 4 Policies must match the current Political Agenda.",
				agenda21403: "Have at least 150 money, with Policies 4 and 5 both A.",
				agenda21404: "Have Policy 1A and at least 6 operational Public Companies.",
				agenda21505: "Have at least 8 each of Food, Luxury, Health and Education in Storage.",
				agenda21506: "Before round 4, have at least 5 fully operational Companies.",
				agenda21507: "Have 8 fully operational Companies and Workers in at least 5 Public and/or Capitalist Companies.",
				agenda21508: "Policies 1–5 must all be B. During Elections, check only after all Elections finish.",
				agenda21509: "At game end, have no unemployed Workers.",
				agenda21610: "Have at least 6 Influence.",
				agenda21611: "Have at least 4 Trade Unions.",
				agenda21612: "Pass 3 of your own Bills during one Elections phase.",
				agenda21613: "At game end, have a Population of 7 or less.",
				agenda21614: "Receive at least 240 in Wages during one Production phase.",
				crisis21100: "The Working Class gains Influence equal to half its Population, rounded up, adds 2 Voting cubes per Trade Union and removes 2 unemployed Workers. The Middle Class gains 2 Influence, adds 2 Voting cubes per Public or Capitalist Company employing its Workers and removes 2 unemployed Workers.",
				crisis21101: "Each class pays 10 to the State. Repeat until the State can repay its Loans.",
				crisis21102: "The Working Class removes 2 unemployed Workers.",
				crisis21103: "The State gains 40.",
				crisis21104: "Apply the Policy and Legitimacy changes shown on this card.",
				crisis21105: "The State gains 60. Working and Middle Classes each receive 10 and up to 2 available Health from the State. The Capitalist Class receives 15 from the State.",
				crisis21106: "The Working Class places 3 Strike markers.",
				crisis21107: "Redraw in round 5. In reverse class order, each class may pay 30 or 50 to the State. If the total cannot cover Loan repayment, refund it and redraw. Otherwise, the State repays its Loans and owes contributors 40 or 70 respectively by the end of the next Action phase.",
				crisis21108: "Each class pays 10 to the State.",
				crisis21109: "Redraw with fewer than 2 Trade Unions. New Public Companies are free this round. The Working Class pays 10; the Capitalist Class pays 35 and gains 1 Influence per 2 Companies; the Middle Class pays 20 and gains 1 Influence per 2 Companies.",
				history0: "At the end of Setup, each class proposes a Bill in turn order. The State player starts without Personal Influence.",
				history1: "Working and Middle Classes each add 2 Voting cubes. The Capitalist Class starts with 2 Technological Progress cards and 5 random Action cards, and gains 10.",
				history2: "The Working Class starts with 2 Need for Change cards and 5 random Action cards. The Middle Class adds 2 Voting cubes. The State player removes 2 Media Influence.",
				history3: "Add 4 Working Class, 1 Capitalist Class and 2 Middle Class Voting cubes to the bag.",
				history4: "For this round, Luxury Companies with Machinery produce 3 extra Luxury.",
				historyReq4: "At least one Company has Machinery.",
				history5: "Move Policies 1 and 3 left and Policy 6 up. Halve Public Company construction costs this round. Working and Middle Classes each remove 1 unemployed Worker. The Capitalist Class may sell a Luxury Company to the State for 32, replacing a non-operational Public Company.",
				history6: "The Working Class gains 1 Luxury. Capitalist and Middle Class Luxury Companies produce 2 extra Luxury this round. The State player gains 15.",
				historyReq6: "At least 2/3 operational Luxury Companies in a 2-class/3-or-more-class game.",
				history7: "Set Policies 1A, 2C, 3A and 4A. No Elections this round; new Public Companies are free. The Working Class builds a Cooperative Farm. The Capitalist Class gives the State one Company and pays 20; that Company replaces a non-operational Public Company.",
				historyReq7: "Policies 2B/C and 4B/C; at least one Trade Union.",
				history8: "No Elections this round. Each class loses 1 Influence. The State player moves two different Policies one space each, gains 2 Personal Influence and loses 1 Legitimacy with every class.",
				history9: "Reveal one extra Business Deal. The State gains 20. Working and Middle Classes each gain 1 Food. The Capitalist Class may Export or make a Business Deal.",
				history10: "Working and Middle Classes each remove 1 Worker, taking unemployed Workers first.",
				historyReq10: "At most 2/3 operational Health Companies in a 2-class/3-or-more-class game.",
				history11: "Working and Middle Classes each remove 1 unemployed Worker. The State loses 15.",
				history12: "Set Policy 6A and discard all Business Deals.",
				historyReq12: "Policy 6B/C.",
				history13: "Working and Middle Classes each remove 2 Workers, taking unemployed Workers first. The State player loses 1 Legitimacy with each of them.",
				historyReq13: "At most 2/3 operational Health Companies in a 2-class/3-or-more-class game.",
				history14: "Move Policies 1 and 2 left. Working and Middle Classes may assign any number of unemployed Workers to Public or Capitalist Companies. The Capitalist Class receives 5 from the State for each Worker newly assigned to its Companies.",
				historyReq14: "At least 4/7 unemployed Workers in a 2-class/3-or-more-class game.",
				history15: "Move Policies 2, 4 and 5 right. Capitalist and Middle Classes each discard an operational Company. Set all their prices to the maximum and lock them for this round. The State loses 30.",
				historyReq15: "At least 2 total Loans, or State Treasury at most 100.",
				history16: "Working and Middle Classes each gain 3 unskilled Workers and 1 Prosperity.",
				historyReq16: "Policy 2A/B; at least 2/3 operational Health Companies in a 2-class/3-or-more-class game.",
				history17: "The Working Class gains 1 Influence and Strikes, with extra Strike markers equal to its Trade Unions. The Middle Class adds 1 Voting cube per Public or Capitalist Company employing its Workers.",
				historyReq17: "Policy 2B/C; at least 2 Trade Unions.",
				history18: "Move Policies 1 and 3 left and Policy 6 up. Halve Public Company construction costs this round. Working and Middle Classes each remove 2 unemployed Workers. The Capitalist Class may sell a Luxury Company to the State for 32, replacing a non-operational Public Company.",
				history19: "Move Policy 6 down and reveal an extra Business Deal. The Capitalist Class may make a Business Deal. This round, whenever another player Exports, the State player gains 1 Legitimacy with that class.",
				historyReq19: "At least 4/6 Agricultural and Luxury Companies combined in a 2-class/3-or-more-class game.",
				history20: "Add 4 Working Class, 1 Capitalist Class and 1 Middle Class Voting cubes to the bag.",
				history21: "The Working Class may assign any number of unemployed Workers. Capitalist Companies with Machinery produce 2 extra resources this round.",
				history22: "No Elections this round. The Working Class may move up to two different Policies one space each. The Capitalist Class pays 40 to the State. The State player moves one other Policy one space.",
				historyReq22: "Policy 2B/C; Working Class Prosperity at most 3; at least 2 Trade Unions.",
				history23: "The Working Class Strikes and adds 4 Voting cubes. The Middle Class adds 2 Voting cubes.",
				historyReq23: "Working Class Prosperity at most 3.",
				history24: "Discard all Business Deals. No Exports or purchases from the Foreign Market this round.",
				historyReq24: "At least 2 socialist Policies.",
				history25: "The State gains 30. The Capitalist Class builds a non-automated Company for free.",
				historyReq25: "At most 2 socialist Policies.",
				history26: "All Bills may receive a free Immediate Vote this round. Add 3 Working Class, 1 Capitalist Class and 2 Middle Class Voting cubes.",
				historyReq26: "Total Influence at least 4/5/7 with 2/3/4 classes. Count only Personal Influence for the State.",
				history27: "Set Policies 1B, 2B, 3B, 4A, 5B and 6B.",
				historyReq27: "At least 4/7 unemployed Workers in a 2-class/3-or-more-class game.",
				history28: "The Working Class adds 4 Voting cubes. The Middle Class gains 1 Influence. The State player gains 1 Legitimacy with the Working Class.",
				historyReq28: "At least 3 of Policies 1–5 are B; at least 2 Trade Unions. With a Middle Class, its Population must be at least 5.",
				history29: "The Working Class may buy Luxury from the Capitalist Class, up to half its Population. The Middle Class may buy Luxury from the Capitalist Class, up to its Population.",
				historyReq29: "At least 3 operational Luxury Companies.",
				history30: "The Capitalist Class gives the State an operational Company. Replace a non-operational Public Company if possible; otherwise replace an operational one. The State player loses 1 Legitimacy with the Capitalist Class.",
				historyReq30: "The Capitalist Class owns at least 9 Companies. With a State player, it must have at least 3 Personal Influence.",
				history31: "Move Policies 1 and 3 right. The State gains 30.",
				historyReq31: "At least 3 socialist Policies.",
				history32: "This round, whenever the Capitalist or Middle Class builds a Company or Exports, it receives 10 from the State. The State player gains 1 Legitimacy with that class.",
				historyReq32: "Policy 6A/B.",
				history33: "Media Companies produce 1 extra Influence this round. The Working Class upgrades 1 Worker and gains 1 Influence. Capitalist and Middle Classes may each perform up to 2 Export transactions. The State player gains 1 Personal Influence per 2 operational Public Companies.",
				historyReq33: "At least 3/5 operational Education Companies in a 2-class/3-or-more-class game.",
				history34: "Remove 3 Media Influence from the Public Services area. Each class gains 1 Influence. The State player gains 1 Legitimacy with each of two chosen classes.",
				historyReq34: "Total Influence at least 4/5 in a 2-class/3-or-more-class game.",
				history35: "Set Policy 7C. Working and Middle Classes each reveal an Immigration card and add its Workers.",
				history36: "Move Policies 1, 2 and 4 right.",
				historyReq36: "State Treasury below 100 and the State has a Loan.",
				history37: "This round, Foreign Market base prices are 15 for Food and 9 for Luxury. Capitalist and Middle Class Food and Luxury prices are set to the maximum and locked.",
				history38: "Agricultural Companies produce 1 less Food this round.",
				history39: "All Bills may receive a free Immediate Vote this round.",
				history40: "Capitalist and Middle Classes pay 10 to the State for each operational Luxury Company they own.",
				historyReq40: "Policies 1A/B and 3A/B.",
				history41: "Move Policies 2 and 3 right. The State pays 10 to each class. Capitalist and Middle Classes each discard an operational Company; the State player may rescue it for half its cost, rounded down, gaining 1 Legitimacy with that class. The State player loses 1 Legitimacy with each of two chosen classes.",
				historyReq41: "At least 2 total Loans.",
				history42: "Move Policy 6 up and randomly discard a Business Deal. Set Capitalist and Middle Class Luxury prices to the maximum and lock them this round.",
				history43: "Move Policies 1, 2 and 4 right and Policy 3 left. Capitalist and Middle Classes each discard an operational Company. The State player loses 1 Legitimacy with each class.",
				historyReq43: "At least 2 total Loans.",
				history44: "Hold one joint vote on Policies 6C and 7C, without Election VP rewards. If it passes, or both Policies already match, Working and Middle Classes each gain 10, the Capitalist Class gains 25 and the State player gains 2 Personal Influence.",
				history45: "Move Policies 1, 2 and 3 right. Working and Middle Classes remove all unemployed Workers. The Capitalist Class may buy one Public Company for half price.",
				historyReq45: "State Treasury at most 50, or at least 3 socialist Policies.",
				history46: "Using Health, Education or Luxury grants 1 extra VP this round.",
				historyReq46: "Working and Middle Class Prosperity both at least 5.",
				history47: "Move Policy 2 left and Policy 3 right.",
				historyReq47: "Policies 2B/C and 3A/B.",
				history48: "Start with Policies C B B A A B B. Remove 2 Working Class Voting cubes. The Capitalist Class gains 2 Influence. The State player gains 1 permanent Working Class Legitimacy token.",
				history49: "Start with Policies C B B B C A B. Working and Middle Classes gain 3 and 1 Influence respectively. The Capitalist Class adds 4 Voting cubes. The State player gains 1 permanent Capitalist Class Legitimacy token."
			},
			options: {
				seats: "Human seats",
				standard: "Standard allocation",
				seatHelp: "Human seats are assigned in the listed order. The selected seat count must match the player count; otherwise standard allocation is used. Required missing classes are filled by Simple Automas.",
				automaHelp: "These settings add classes without a human seat. The State requires a human seat. Official Automas and platform bots may participate together.",
				off: "Do not add",
				simple: "Simple Automa",
				advanced: "Advanced Automa",
				expansions: "Official expansions and promos",
				actionExpansion: "Crisis & Control: Extra Action Cards",
				crisisResponse: "Crisis & Control: Crisis Response",
				hiddenAgendas: "Crisis & Control: Hidden Agendas",
				alternativeEvents: "Crisis & Control: Alternative Events",
				historicalEvents: "Historical Events",
				controllingNarrative: "Controlling the Narrative promo",
				rapidResolution: "Rapid Resolution promo",
				stateHelp: "Including the State uses all four classes, filling missing classes with Automas. Events, Political Agendas and State Legitimacy apply only with a State player."
			},
			ui: {
				round: "Round {{round}} of 5",
				turn: "Action {{turn}}",
				setup: "Setup",
				preparation: "Preparation",
				action: "Action phase",
				production: "Production",
				elections: "Elections",
				scoring: "Scoring",
				done: "Game end",
				money: "Money",
				revenue: "Revenue",
				capital: "Capital",
				vp: "Victory points",
				population: "Population",
				prosperity: "Prosperity",
				wealth: "Wealth",
				loans: "Loans",
				legitimacy: "Legitimacy",
				permanent: "Permanent tokens",
				storage: "Storage",
				personal: "Personal resources",
				prices: "Prices",
				benefits: "Benefits",
				unemployed: "Unemployed",
				unions: "Trade Unions",
				workers: "Workers",
				companies: "Companies",
				publicSector: "Public sector",
				market: "Company market",
				policies: "Policies",
				foreignTrade: "Foreign trade",
				events: "Events",
				history: "Historical Event",
				agenda: "Agenda",
				hand: "Action cards",
				log: "Journal",
				close: "Close",
				back: "Back",
				details: "View details",
				choose: "Choose an action",
				waiting: "Waiting for {{role}}",
				resolving: "Resolving",
				yourTurn: "Your turn",
				actions: "Available actions",
				board: "Economic board",
				government: "Government",
				classBoard: "Class board",
				more: "More",
				confirm: "Confirm",
				cancel: "Cancel",
				noChoices: "Waiting for the next step",
				noHand: "No Action cards",
				cost: "Construction cost",
				output: "Production",
				wages: "Wages",
				level: "Level {{level}}",
				machine: "Machinery",
				strike: "Strike",
				committed: "Committed",
				available: "Available",
				unskilled: "Unskilled",
				vacant: "Vacant slot",
				inactive: "Inactive",
				operating: "Operational",
				notOperating: "Not operational",
				votes: "Voting cubes",
				bill: "Bill",
				support: "Support",
				oppose: "Oppose",
				sealed: "Influence committed",
				export: "Export",
				deal: "Business Deal",
				tariff: "Tariff",
				requirement: "Requirement",
				effect: "Effect",
				reward: "Completion reward",
				penalty: "If unresolved",
				benefit: "Card benefit",
				timing: "Timing",
				free: "Free Action",
				basic: "Basic Action",
				special: "Card effect",
				mainReady: "Main Action available",
				mainDone: "Main Action used",
				freeReady: "Free Action available",
				freeDone: "Free Action used",
				viewBoard: "Review board",
				showResults: "Show results",
				results: "Final report",
				winner: "Winning class",
				tie: "Shared victory",
				automa: "Official Automa",
				simple: "Simple",
				advanced: "Advanced",
				total: "Total",
				otherPoints: "Points during play",
				playAgain: "Play again",
				lobby: "Back to lobby",
				awaitHost: "Waiting for the host to start another game",
				confirmLeave: "Leave this game?",
				confirmAgain: "Start a new game?",
				hints: "Hints used: {{count}}",
				readonly: "Final position",
				empty: "None",
				taxTable: "Tax reference",
				stateAgenda: "Political Agenda",
				crisis: "Crisis Response",
				showHand: "View hand",
				showMarket: "View Company market",
				selectWorker: "Choose a Worker",
				selectDestination: "Choose a job slot",
				assignmentPreview: "Assignment preview",
				companyCount: "{{count}} Companies",
				workerCount: "{{count}} Workers",
				cardCount: "{{count}} cards",
				currency: "{{amount}} money",
				foreign: "Foreign Market",
				cardRequirement: "Requires Policy {{policy}}",
				legitimacyEffect: "Legitimacy change: {{value}}",
				gainVP: "Gain {{count}} VP",
				inspect: "Inspect",
				selected: "Selected",
				drawn: "Revealed",
				bag: "Voting bag",
				pending: "Pending vote",
				policyChanges: "Policy changes",
				policyLocks: "Locked Policies",
				discardBills: "Discard Bills",
				allBills: "All Bills",
				eligibleRoles: "Eligible classes",
				helper: "Optional Worker",
				extraOutput: "Extra production"
			},
			promo: {
				narrative: "Propose a Bill and call a free Immediate Vote. Decide how much Influence to spend after all other classes announce their commitments.",
				rapid: "Spend 1 Influence to call an Immediate Vote on another class’s pending Bill. Before drawing cubes, place that Influence on your supporting or opposing side. The original proposer scores as usual."
			},
			eventPenalty: {
				any: "Any two classes each lose 1 Legitimacy.",
				list: "{{roles}} each lose 1 Legitimacy."
			},
			timing: {
				anytime: "Any time",
				"after-round-1": "After round 1",
				action: "Action phase",
				"game-end": "Game end",
				elections: "After Elections",
				production: "Production phase",
				scoring: "Scoring phase",
				setup: "Setup",
				reveal: "On reveal",
				active: "Activate during the Action phase",
				"action-end": "End of Action phase",
				"before-round-4": "Before round 4",
				actionEnd: "End of Action phase",
				free: "As a Free Action",
				basic: "As a Basic Action",
				"basic+1influence": "Basic Action and 1 Influence",
				"basic+2influence": "Basic Action and 2 Influence"
			},
			legitimacyText: {
				l0: "State Legitimacy with Working Class: Gain 1 Legitimacy",
				l1: "State Legitimacy with Working Class: Gain 1 Legitimacy per 10 employed Workers",
				l2: "State Legitimacy with Working Class: Gain 1 Legitimacy per 3 unemployed Workers",
				l3: "State Legitimacy with Working Class: Gain 1 Legitimacy; State Legitimacy with Middle Class: Gain 1 Legitimacy",
				l4: "The State loses 1 Legitimacy with each of two chosen classes",
				l5: "State Legitimacy with Target class: Gain 2 Legitimacy",
				l6: "State Legitimacy with Target class: Gain 1 Legitimacy",
				l7: "State Legitimacy with Middle Class: Gain 1 Legitimacy; State Legitimacy with Capitalist Class: Gain 1 Legitimacy",
				l8: "State Legitimacy with Target class: Gain 1 Legitimacy per 10 paid",
				l9: "State Legitimacy with Working Class: Gain 1 Legitimacy; State Legitimacy with Capitalist Class: Gain 1 Legitimacy",
				l10: "State Legitimacy with Capitalist Class: Gain 1 Legitimacy per 3 Companies",
				l11: "State Legitimacy with Capitalist Class: Gain 1 Legitimacy",
				l12: "State Legitimacy with Target class: Gain 1 Legitimacy per 3 Health",
				l13: "State Legitimacy with Capitalist Class: Gain 1 Legitimacy per 3 Health",
				l14: "State Legitimacy with Capitalist Class: Gain 1 Legitimacy per 3 Education",
				l15: "State Legitimacy with Capitalist Class: Gain 1 Legitimacy per 3 Luxury",
				l16: "State Legitimacy with Capitalist Class: Gain 1 Legitimacy per operational Healthcare Company",
				l17: "State Legitimacy with Middle Class: Gain 1 Legitimacy",
				l18: "State Legitimacy with Middle Class: Gain 1 Legitimacy per 4 goods",
				l19: "State Legitimacy with Middle Class: Gain 1 Legitimacy per 3 qualifying Companies",
				l20: "State Legitimacy with Middle Class: Gain 1 Legitimacy per 3 Health",
				l21: "State Legitimacy with Middle Class: Gain 1 Legitimacy per 3 Education",
				l22: "State Legitimacy with Middle Class: Gain 1 Legitimacy per 5 qualifying Workers",
				l23: "State Legitimacy with Middle Class: Gain 1 Legitimacy per 15 paid",
				l24: "State Legitimacy with Working Class: Lose 3 Legitimacy; State Legitimacy with Middle Class: Lose 2 Legitimacy",
				l25: "State Legitimacy with Each class: Lose 1 Legitimacy per 10 collected from this class",
				l26: "State Legitimacy with Each class: Lose 2 Legitimacy",
				l27: "State Legitimacy with Each class: Lose 1 Legitimacy",
				l28: "State Legitimacy with Each class: Halve Legitimacy, rounding up",
				l29: "State Legitimacy with Working Class: Halve Legitimacy, rounding up; State Legitimacy with Middle Class: Halve Legitimacy, rounding up",
				l30: "",
				l31: "State Legitimacy with Capitalist Class: Lose 3 Legitimacy; State Legitimacy with Middle Class: Lose 2 Legitimacy"
			},
			end: {
				title: "After Five Rounds · Class Report",
				readBoard: "Review board",
				winner: "Victory",
				tied: "Shared victory",
				scores: "Score report",
				total: "Total VP",
				other: "Other points earned",
				lobby: "Return to lobby",
				again: "Play again",
				waiting: "Waiting for the host"
			}
		}
	}
};
//#endregion
export { gr as default };
