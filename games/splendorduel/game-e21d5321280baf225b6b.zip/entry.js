import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as i } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { Texture as s } from "@bgparty/sdk/texture";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u, seatName as d } from "@bgparty/sdk/ui/player-strip";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Flash as h, Floater as g, FlySprite as _ } from "@bgparty/sdk/fx/primitives";
import { AVATARS as ee } from "@bgparty/sdk/avatars";
import { IconBot as v } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as y } from "@bgparty/sdk/player-colors";
import { Confetti as te } from "@bgparty/sdk/ui/confetti";
//#region src/games/splendorduel/cards.ts
var b = [
	"white",
	"blue",
	"green",
	"red",
	"black"
], x = [
	...b,
	"pearl",
	"gold"
], S = [...b, "pearl"];
function C(e, t, n, r, i, a, o, s) {
	return {
		id: e,
		tier: t,
		color: n,
		bonusCount: r,
		points: i,
		crowns: a,
		ability: o,
		cost: s
	};
}
var w = [
	C("1W1", 1, "white", 1, 0, 0, null, {
		blue: 1,
		green: 1,
		red: 1,
		black: 1
	}),
	C("1W2", 1, "white", 1, 0, 1, null, { blue: 3 }),
	C("1W3", 1, "white", 1, 0, 0, "extraTurn", {
		blue: 2,
		green: 2,
		pearl: 1
	}),
	C("1W4", 1, "white", 1, 0, 0, "takeSameColor", {
		red: 2,
		black: 2
	}),
	C("1W5", 1, "white", 1, 1, 0, null, {
		green: 2,
		red: 3
	}),
	C("1U1", 1, "blue", 1, 0, 0, null, {
		white: 1,
		green: 1,
		red: 1,
		black: 1
	}),
	C("1U2", 1, "blue", 1, 0, 1, null, { green: 3 }),
	C("1U3", 1, "blue", 1, 0, 0, "extraTurn", {
		green: 2,
		red: 2,
		pearl: 1
	}),
	C("1U4", 1, "blue", 1, 0, 0, "takeSameColor", {
		white: 2,
		black: 2
	}),
	C("1U5", 1, "blue", 1, 1, 0, null, {
		red: 2,
		black: 3
	}),
	C("1G1", 1, "green", 1, 0, 0, null, {
		white: 1,
		blue: 1,
		red: 1,
		black: 1
	}),
	C("1G2", 1, "green", 1, 0, 1, null, { red: 3 }),
	C("1G3", 1, "green", 1, 0, 0, "extraTurn", {
		red: 2,
		black: 2,
		pearl: 1
	}),
	C("1G4", 1, "green", 1, 0, 0, "takeSameColor", {
		white: 2,
		blue: 2
	}),
	C("1G5", 1, "green", 1, 1, 0, null, {
		white: 3,
		black: 2
	}),
	C("1R1", 1, "red", 1, 0, 0, null, {
		white: 1,
		blue: 1,
		green: 1,
		black: 1
	}),
	C("1R2", 1, "red", 1, 0, 1, null, { black: 3 }),
	C("1R3", 1, "red", 1, 0, 0, "extraTurn", {
		white: 2,
		black: 2,
		pearl: 1
	}),
	C("1R4", 1, "red", 1, 0, 0, "takeSameColor", {
		blue: 2,
		green: 2
	}),
	C("1R5", 1, "red", 1, 1, 0, null, {
		white: 2,
		blue: 3
	}),
	C("1K1", 1, "black", 1, 0, 0, null, {
		white: 1,
		blue: 1,
		green: 1,
		red: 1
	}),
	C("1K2", 1, "black", 1, 0, 1, null, { white: 3 }),
	C("1K3", 1, "black", 1, 0, 0, "extraTurn", {
		white: 2,
		blue: 2,
		pearl: 1
	}),
	C("1K4", 1, "black", 1, 0, 0, "takeSameColor", {
		green: 2,
		red: 2
	}),
	C("1K5", 1, "black", 1, 1, 0, null, {
		blue: 2,
		green: 3
	}),
	C("1J1", 1, "joker", 1, 1, 0, null, {
		black: 4,
		pearl: 1
	}),
	C("1J2", 1, "joker", 1, 0, 1, null, {
		white: 4,
		pearl: 1
	}),
	C("1J3", 1, "joker", 1, 1, 0, null, {
		blue: 2,
		red: 2,
		black: 1,
		pearl: 1
	}),
	C("1J4", 1, "joker", 1, 1, 0, null, {
		white: 2,
		green: 2,
		black: 1,
		pearl: 1
	}),
	C("1N1", 1, "none", 0, 3, 0, null, {
		red: 4,
		pearl: 1
	}),
	C("2W1", 2, "white", 1, 2, 1, null, {
		green: 2,
		red: 2,
		black: 2,
		pearl: 1
	}),
	C("2W2", 2, "white", 1, 1, 0, "steal", {
		blue: 4,
		red: 3
	}),
	C("2W3", 2, "white", 1, 2, 0, "privilege", {
		white: 4,
		black: 2,
		pearl: 1
	}),
	C("2W4", 2, "white", 2, 1, 0, null, {
		blue: 5,
		green: 2
	}),
	C("2U1", 2, "blue", 1, 2, 1, null, {
		white: 2,
		red: 2,
		black: 2,
		pearl: 1
	}),
	C("2U2", 2, "blue", 1, 1, 0, "steal", {
		green: 4,
		black: 3
	}),
	C("2U3", 2, "blue", 1, 2, 0, "privilege", {
		white: 2,
		blue: 4,
		pearl: 1
	}),
	C("2U4", 2, "blue", 2, 1, 0, null, {
		green: 5,
		red: 2
	}),
	C("2G1", 2, "green", 1, 2, 1, null, {
		white: 2,
		blue: 2,
		black: 2,
		pearl: 1
	}),
	C("2G2", 2, "green", 1, 1, 0, "steal", {
		white: 3,
		red: 4
	}),
	C("2G3", 2, "green", 1, 2, 0, "privilege", {
		blue: 2,
		green: 4,
		pearl: 1
	}),
	C("2G4", 2, "green", 2, 1, 0, null, {
		red: 5,
		black: 2
	}),
	C("2R1", 2, "red", 1, 2, 1, null, {
		white: 2,
		blue: 2,
		green: 2,
		pearl: 1
	}),
	C("2R2", 2, "red", 1, 1, 0, "steal", {
		blue: 3,
		black: 4
	}),
	C("2R3", 2, "red", 1, 2, 0, "privilege", {
		green: 2,
		red: 4,
		pearl: 1
	}),
	C("2R4", 2, "red", 2, 1, 0, null, {
		white: 2,
		black: 5
	}),
	C("2K1", 2, "black", 1, 2, 1, null, {
		blue: 2,
		green: 2,
		red: 2,
		pearl: 1
	}),
	C("2K2", 2, "black", 1, 1, 0, "steal", {
		white: 4,
		green: 3
	}),
	C("2K3", 2, "black", 1, 2, 0, "privilege", {
		red: 2,
		black: 4,
		pearl: 1
	}),
	C("2K4", 2, "black", 2, 1, 0, null, {
		white: 5,
		blue: 2
	}),
	C("2J1", 2, "joker", 1, 2, 0, null, {
		green: 6,
		pearl: 1
	}),
	C("2J2", 2, "joker", 1, 0, 2, null, {
		green: 6,
		pearl: 1
	}),
	C("2J3", 2, "joker", 1, 0, 2, null, {
		blue: 6,
		pearl: 1
	}),
	C("2N1", 2, "none", 0, 5, 0, null, {
		blue: 6,
		pearl: 1
	}),
	C("3W1", 3, "white", 1, 3, 2, null, {
		blue: 3,
		red: 5,
		black: 3,
		pearl: 1
	}),
	C("3W2", 3, "white", 1, 4, 0, null, {
		white: 6,
		blue: 2,
		black: 2
	}),
	C("3U1", 3, "blue", 1, 3, 2, null, {
		white: 3,
		green: 3,
		black: 5,
		pearl: 1
	}),
	C("3U2", 3, "blue", 1, 4, 0, null, {
		white: 2,
		blue: 6,
		green: 2
	}),
	C("3G1", 3, "green", 1, 3, 2, null, {
		white: 5,
		blue: 3,
		red: 3,
		pearl: 1
	}),
	C("3G2", 3, "green", 1, 4, 0, null, {
		blue: 2,
		green: 6,
		red: 2
	}),
	C("3R1", 3, "red", 1, 3, 2, null, {
		blue: 5,
		green: 3,
		black: 3,
		pearl: 1
	}),
	C("3R2", 3, "red", 1, 4, 0, null, {
		green: 2,
		red: 6,
		black: 2
	}),
	C("3K1", 3, "black", 1, 3, 2, null, {
		white: 3,
		blue: 5,
		green: 3,
		pearl: 1
	}),
	C("3K2", 3, "black", 1, 4, 0, null, {
		white: 2,
		red: 2,
		black: 6
	}),
	C("3J1", 3, "joker", 1, 3, 0, "extraTurn", { red: 8 }),
	C("3J2", 3, "joker", 1, 0, 3, null, { black: 8 }),
	C("3N1", 3, "none", 0, 6, 0, null, { white: 8 })
], T = [
	{
		id: "R1",
		points: 2,
		ability: "steal"
	},
	{
		id: "R2",
		points: 2,
		ability: "privilege"
	},
	{
		id: "R3",
		points: 2,
		ability: "extraTurn"
	},
	{
		id: "R4",
		points: 3,
		ability: null
	}
], E = new Map(w.map((e) => [e.id, e])), D = new Map(T.map((e) => [e.id, e]));
function O(e) {
	let t = E.get(e);
	if (!t) throw Error(`unknown jewel card ${e}`);
	return t;
}
function k(e) {
	let t = D.get(e);
	if (!t) throw Error(`unknown royal card ${e}`);
	return t;
}
//#endregion
//#region src/games/splendorduel/meta.ts
var A = {
	id: "splendorduel",
	tier: "beta",
	mechanics: [
		"engine-building",
		"set-collection",
		"drafting"
	],
	interactionTags: [],
	nameKey: "games.splendorduel.name",
	descKey: "games.splendorduel.desc",
	rulesKey: "games.splendorduel.rules",
	icon: "💠",
	iconImg: "games/splendorduel.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/splendorduel/en.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#b45309",
	releasedAt: "2026-10-01",
	search: {
		py: "cui can bao shi dui jue",
		init: "ccbsdj"
	},
	hotseat: "cover"
}, j = t.enum([
	"white",
	"blue",
	"green",
	"red",
	"black"
]), M = t.enum([
	"white",
	"blue",
	"green",
	"red",
	"black",
	"pearl",
	"gold"
]), N = t.int().min(0).max(24), P = t.union([
	t.object({
		type: t.literal("take"),
		cells: t.array(N).min(1).max(3)
	}),
	t.object({
		type: t.literal("reserve"),
		cardId: t.string()
	}),
	t.object({
		type: t.literal("reserve"),
		tier: t.union([
			t.literal(1),
			t.literal(2),
			t.literal(3)
		])
	}),
	t.object({
		type: t.literal("buy"),
		cardId: t.string(),
		from: t.enum(["pyramid", "reserved"]),
		attachColor: j.optional()
	}),
	t.object({
		type: t.literal("usePrivilege"),
		cell: N
	}),
	t.object({ type: t.literal("replenish") }),
	t.object({
		type: t.literal("steal"),
		color: t.enum([
			"white",
			"blue",
			"green",
			"red",
			"black",
			"pearl"
		])
	}),
	t.object({
		type: t.literal("chooseRoyal"),
		royalId: t.string()
	}),
	t.object({
		type: t.literal("discard"),
		tokens: t.array(M).min(1)
	}),
	t.object({ type: t.literal("pass") })
]), F = t.string(), I = t.object({
	white: t.int().nonnegative(),
	blue: t.int().nonnegative(),
	green: t.int().nonnegative(),
	red: t.int().nonnegative(),
	black: t.int().nonnegative(),
	pearl: t.int().nonnegative(),
	gold: t.int().nonnegative()
}), ne = t.object({
	phase: t.enum([
		"play",
		"steal",
		"chooseRoyal",
		"discard",
		"done"
	]),
	turn: F,
	board: t.array(M.nullable()).length(25),
	pyramid: t.array(t.string().nullable()).length(12),
	deckCounts: t.object({
		1: t.int().nonnegative(),
		2: t.int().nonnegative(),
		3: t.int().nonnegative()
	}),
	bagCount: t.int().nonnegative(),
	supply: t.int().nonnegative(),
	royals: t.array(t.string()),
	mustDiscard: t.int().nonnegative(),
	extraTurn: t.boolean(),
	players: t.array(t.object({
		rid: F,
		tokens: I,
		bonuses: t.object({
			white: t.int().nonnegative(),
			blue: t.int().nonnegative(),
			green: t.int().nonnegative(),
			red: t.int().nonnegative(),
			black: t.int().nonnegative()
		}),
		points: t.int().nonnegative(),
		colorPoints: t.object({
			white: t.int().nonnegative(),
			blue: t.int().nonnegative(),
			green: t.int().nonnegative(),
			red: t.int().nonnegative(),
			black: t.int().nonnegative()
		}),
		crowns: t.int().nonnegative(),
		privileges: t.int().nonnegative(),
		reservedPublic: t.array(t.string()),
		blindCount: t.int().nonnegative(),
		royalsWon: t.array(t.string())
	}))
}), re = t.object({ reservedBlind: t.array(t.string()) }), ie = [3, 6], ae = [
	12,
	13,
	18,
	17,
	16,
	11,
	6,
	7,
	8,
	9,
	14,
	19,
	24,
	23,
	22,
	21,
	20,
	15,
	10,
	5,
	0,
	1,
	2,
	3,
	4
], L = [
	3,
	3,
	3,
	2,
	2,
	2,
	2,
	1,
	1,
	1,
	1,
	1
], R = [
	...[
		,
		,
		,
		,
	].fill("white"),
	...[
		,
		,
		,
		,
	].fill("blue"),
	...[
		,
		,
		,
		,
	].fill("green"),
	...[
		,
		,
		,
		,
	].fill("red"),
	...[
		,
		,
		,
		,
	].fill("black"),
	"pearl",
	"pearl",
	"gold",
	"gold",
	"gold"
], z = () => ({
	white: 0,
	blue: 0,
	green: 0,
	red: 0,
	black: 0,
	pearl: 0,
	gold: 0
}), oe = () => ({
	white: 0,
	blue: 0,
	green: 0,
	red: 0,
	black: 0
}), se = (e) => x.reduce((t, n) => t + e[n], 0), B = (e, t) => e.players.find((e) => e !== t);
function V(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.cursor, n + 1);
		t.cursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function ce(e, t) {
	if (e.supply > 0) return --e.supply, e.privileges[t] += 1, {
		kind: "privilege",
		rid: t,
		data: { from: "supply" }
	};
	let n = B(e, t);
	return e.privileges[n] > 0 ? (--e.privileges[n], e.privileges[t] += 1, {
		kind: "privilege",
		rid: t,
		data: {
			from: "opponent",
			fromRid: n
		}
	}) : null;
}
function le(e, t) {
	let n = O(t);
	return n.color === "none" ? null : n.color === "joker" ? e.attach[t] : n.color;
}
function ue(e, t) {
	return e.purchased[t].reduce((e, t) => e + O(t).crowns, 0);
}
function H(e, t) {
	return e.purchased[t].reduce((e, t) => e + O(t).points, 0) + e.royalsWon[t].reduce((e, t) => e + k(t).points, 0);
}
function U(e, t) {
	let n = oe();
	for (let r of e.purchased[t]) {
		let t = O(r);
		if (t.color === "none") continue;
		let i = t.color === "joker" ? e.attach[r] : t.color;
		n[i] += t.points;
	}
	return n;
}
function W(e, t, n) {
	let r = {}, i = 0;
	for (let a of S) {
		let o = a === "pearl" ? 0 : t[a], s = Math.max(0, (e[a] ?? 0) - o), c = Math.min(n[a], s);
		c > 0 && (r[a] = c), i += s - c;
	}
	return i > n.gold ? null : {
		pay: r,
		gold: i
	};
}
function de(e, t) {
	if (e.length < 1 || e.length > 3 || new Set(e).size !== e.length) return !1;
	for (let n of e) {
		let e = t[n];
		if (e == null || e === "gold") return !1;
	}
	if (e.length === 1) return !0;
	let n = e.map((e) => [Math.floor(e / 5), e % 5]), r = n[1][0] - n[0][0], i = n[1][1] - n[0][1];
	if (!(Math.abs(r) <= 1 && Math.abs(i) <= 1 && (r !== 0 || i !== 0))) return !1;
	if (e.length === 2) return !0;
	let a = n[2][0] - n[1][0], o = n[2][1] - n[1][1];
	return a === r && o === i;
}
function G(e, t) {
	if (e.board.some((e) => e !== null && e !== "gold")) return !0;
	let n = e.reservedPublic[t].length + e.reservedBlind[t].length;
	if (e.board.includes("gold") && n < 3 && (e.pyramid.some((e) => e !== null) || e.decks[1].length + e.decks[2].length + e.decks[3].length > 0)) return !0;
	let r = (n) => W(O(n).cost, e.bonuses[t], e.tokens[t]) !== null;
	return e.pyramid.some((e) => e !== null && r(e)) || [...e.reservedPublic[t], ...e.reservedBlind[t]].some(r);
}
function fe(t, n, r) {
	let i = {
		seed: r,
		cursor: 0
	}, a = {};
	for (let e of [
		1,
		2,
		3
	]) a[e] = V(i, w.filter((t) => t.tier === e).map((e) => e.id));
	let o = L.map((e) => a[e].pop()), s = V(i, R), c = Array(25).fill(null);
	ae.forEach((e, t) => {
		c[e] = s[t];
	});
	let l = e(r, i.cursor, n.length);
	i.cursor += 1;
	let u = [...n];
	[u[0], u[l]] = [u[l], u[0]];
	let d = {
		players: u,
		turnIdx: 0,
		phase: "play",
		seed: r,
		cursor: i.cursor,
		decks: a,
		pyramid: o,
		board: c,
		bag: [],
		supply: 2,
		royals: T.map((e) => e.id),
		queue: [],
		mustDiscard: 0,
		extraTurn: !1,
		crownsGranted: {},
		tokens: {},
		bonuses: {},
		purchased: {},
		attach: {},
		reservedPublic: {},
		reservedBlind: {},
		privileges: {},
		royalsWon: {},
		winner: null
	};
	for (let e of u) d.tokens[e] = z(), d.bonuses[e] = oe(), d.purchased[e] = [], d.reservedPublic[e] = [], d.reservedBlind[e] = [], d.privileges[e] = 0, d.royalsWon[e] = [], d.crownsGranted[e] = 0;
	return d.privileges[u[1]] = 1, {
		state: d,
		fx: []
	};
}
function pe(e) {
	let t = [];
	for (; e.queue.length > 0;) {
		if (e.queue[0] === "steal") {
			let t = e.players[e.turnIdx], n = B(e, t);
			if (!(b.some((t) => e.tokens[n][t] > 0) || e.tokens[n].pearl > 0)) {
				e.queue.shift();
				continue;
			}
		}
		return e.phase = e.queue.shift(), t;
	}
	return [...t, ...K(e)];
}
function K(e) {
	let t = e.players[e.turnIdx], n = se(e.tokens[t]) - 10;
	return n > 0 ? (e.phase = "discard", e.mustDiscard = n, []) : me(e);
}
function me(e) {
	let t = e.players[e.turnIdx], n = U(e, t);
	return H(e, t) >= 20 || ue(e, t) >= 10 || b.some((e) => n[e] >= 10) ? (e.phase = "done", e.winner = t, [{
		kind: "gameover",
		rid: t
	}]) : (e.extraTurn ? e.extraTurn = !1 : e.turnIdx = 1 - e.turnIdx, e.phase = "play", []);
}
function he(e, t) {
	let n = ue(e, t);
	ie.forEach((r, i) => {
		n >= r && e.crownsGranted[t] <= i && (e.crownsGranted[t] = i + 1, e.royals.length > 0 && e.queue.push("chooseRoyal"));
	});
}
function ge(e, t, n) {
	if (e.phase === "done") return { code: "games.splendorduel.errNotYourTurn" };
	let r = n.by;
	if (e.players[e.turnIdx] !== r) return { code: "games.splendorduel.errNotYourTurn" };
	let i = B(e, r);
	if (t.type === "usePrivilege") {
		if (e.phase !== "play") return { code: "games.splendorduel.errNotYourTurn" };
		if (e.privileges[r] <= 0) return { code: "games.splendorduel.errNoPrivilege" };
		let n = e.board[t.cell];
		if (n == null || n === "gold") return { code: "games.splendorduel.errBadCell" };
		let i = structuredClone(e);
		return i.board[t.cell] = null, i.tokens[r][n] += 1, --i.privileges[r], i.supply += 1, {
			state: i,
			fx: [{
				kind: "privilegeUse",
				rid: r,
				data: {
					cell: t.cell,
					token: n
				}
			}]
		};
	}
	if (t.type === "replenish") {
		if (e.phase !== "play") return { code: "games.splendorduel.errNotYourTurn" };
		if (e.bag.length === 0) return { code: "games.splendorduel.errBagEmpty" };
		let t = structuredClone(e), n = V(t, t.bag);
		t.bag = [];
		let a = [], o = 0;
		for (let e of ae) {
			if (o >= n.length) break;
			t.board[e] === null && (t.board[e] = n[o], a.push({
				cell: e,
				token: n[o]
			}), o += 1);
		}
		let s = [{
			kind: "replenish",
			rid: r,
			data: { placements: a }
		}], c = ce(t, i);
		return c && s.push(c), {
			state: t,
			fx: s
		};
	}
	if (t.type === "take") {
		if (e.phase !== "play") return { code: "games.splendorduel.errNotYourTurn" };
		if (!de(t.cells, e.board)) return { code: "games.splendorduel.errBadTake" };
		let n = structuredClone(e), a = t.cells.map((e) => {
			let t = n.board[e];
			return n.board[e] = null, n.tokens[r][t] += 1, t;
		}), o = [{
			kind: "take",
			rid: r,
			data: {
				cells: t.cells,
				tokens: a
			}
		}], s = a.length === 3 && a.every((e) => e === a[0]), c = a.filter((e) => e === "pearl").length;
		if (s || c >= 2) {
			let e = ce(n, i);
			e && o.push(e);
		}
		return {
			state: n,
			fx: [...o, ...K(n)]
		};
	}
	if (t.type === "reserve") {
		if (e.phase !== "play") return { code: "games.splendorduel.errNotYourTurn" };
		if (e.reservedPublic[r].length + e.reservedBlind[r].length >= 3) return { code: "games.splendorduel.errReserveFull" };
		let n = ae.find((t) => e.board[t] === "gold");
		if (n === void 0) return { code: "games.splendorduel.errNoGold" };
		if ("cardId" in t) {
			let i = e.pyramid.indexOf(t.cardId);
			if (i < 0) return { code: "games.splendorduel.errBadCard" };
			let a = structuredClone(e);
			a.pyramid[i] = null;
			let o = a.decks[L[i]].pop();
			return o && (a.pyramid[i] = o), a.reservedPublic[r].push(t.cardId), a.board[n] = null, a.tokens[r].gold += 1, {
				state: a,
				fx: [{
					kind: "reserve",
					rid: r,
					data: {
						cardId: t.cardId,
						slot: i,
						goldCell: n
					}
				}, ...K(a)]
			};
		}
		if (e.decks[t.tier].length === 0) return { code: "games.splendorduel.errBadCard" };
		let i = structuredClone(e), a = i.decks[t.tier].pop();
		return i.reservedBlind[r].push(a), i.board[n] = null, i.tokens[r].gold += 1, {
			state: i,
			fx: [{
				kind: "reserve",
				rid: r,
				data: {
					tier: t.tier,
					blind: !0,
					goldCell: n
				},
				for: [r],
				secret: { cardId: a }
			}, ...K(i)]
		};
	}
	if (t.type === "buy") {
		if (e.phase !== "play") return { code: "games.splendorduel.errNotYourTurn" };
		let n = w.find((e) => e.id === t.cardId);
		if (!n) return { code: "games.splendorduel.errBadCard" };
		let i = -1;
		if (t.from === "pyramid") {
			if (i = e.pyramid.indexOf(t.cardId), i < 0) return { code: "games.splendorduel.errBadCard" };
		} else if (!e.reservedPublic[r].includes(t.cardId) && !e.reservedBlind[r].includes(t.cardId)) return { code: "games.splendorduel.errBadCard" };
		if (n.color === "joker") {
			if (!t.attachColor) return { code: "games.splendorduel.errNeedAttach" };
			if (!e.purchased[r].some((n) => O(n).bonusCount !== 0 && le(e, n) === t.attachColor)) return { code: "games.splendorduel.errBadAttach" };
		} else if (t.attachColor) return { code: "games.splendorduel.errBadAttach" };
		let a = W(n.cost, e.bonuses[r], e.tokens[r]);
		if (!a) return { code: "games.splendorduel.errCantAfford" };
		let o = structuredClone(e);
		for (let e of S) {
			let t = a.pay[e] ?? 0;
			o.tokens[r][e] -= t;
			for (let n = 0; n < t; n += 1) o.bag.push(e);
		}
		for (let e = 0; e < a.gold; e += 1) o.bag.push("gold");
		o.tokens[r].gold -= a.gold;
		let s = -1;
		if (i >= 0) {
			o.pyramid[i] = null;
			let e = o.decks[L[i]].pop();
			e && (o.pyramid[i] = e);
		} else s = o.reservedPublic[r].indexOf(t.cardId), s >= 0 ? o.reservedPublic[r].splice(s, 1) : (s = o.reservedBlind[r].indexOf(t.cardId), o.reservedBlind[r].splice(s, 1));
		o.purchased[r].push(n.id), n.color === "joker" ? (o.attach[n.id] = t.attachColor, o.bonuses[r][t.attachColor] += n.bonusCount) : n.color !== "none" && (o.bonuses[r][n.color] += n.bonusCount);
		let c = [{
			kind: "buy",
			rid: r,
			data: {
				cardId: n.id,
				from: t.from,
				slot: i,
				rsvIndex: s,
				attachColor: t.attachColor ?? null
			}
		}];
		if (n.ability === "extraTurn" && (o.extraTurn = !0), n.ability === "privilege") {
			let e = ce(o, r);
			e && c.push(e);
		}
		if (n.ability === "takeSameColor" && n.color !== "joker" && n.color !== "none") {
			let e = ae.find((e) => o.board[e] === n.color);
			e !== void 0 && (o.board[e] = null, o.tokens[r][n.color] += 1, c.push({
				kind: "bonusToken",
				rid: r,
				data: {
					cell: e,
					token: n.color
				}
			}));
		}
		return n.ability === "steal" && o.queue.push("steal"), he(o, r), {
			state: o,
			fx: [...c, ...pe(o)]
		};
	}
	if (t.type === "steal") {
		if (e.phase !== "steal") return { code: "games.splendorduel.errNotYourTurn" };
		if (e.tokens[i][t.color] <= 0) return { code: "games.splendorduel.errBadSteal" };
		let n = structuredClone(e);
		return --n.tokens[i][t.color], n.tokens[r][t.color] += 1, {
			state: n,
			fx: [{
				kind: "steal",
				rid: r,
				data: {
					color: t.color,
					from: i
				}
			}, ...pe(n)]
		};
	}
	if (t.type === "chooseRoyal") {
		if (e.phase !== "chooseRoyal" || !e.royals.includes(t.royalId)) return { code: "games.splendorduel.errBadRoyal" };
		let n = structuredClone(e);
		n.royals = n.royals.filter((e) => e !== t.royalId), n.royalsWon[r].push(t.royalId);
		let i = [{
			kind: "royal",
			rid: r,
			data: { royalId: t.royalId }
		}], a = k(t.royalId).ability;
		if (a === "extraTurn" && (n.extraTurn = !0), a === "privilege") {
			let e = ce(n, r);
			e && i.push(e);
		}
		return a === "steal" && n.queue.push("steal"), {
			state: n,
			fx: [...i, ...pe(n)]
		};
	}
	if (t.type === "discard") {
		if (e.phase !== "discard") return { code: "games.splendorduel.errNotYourTurn" };
		if (t.tokens.length !== e.mustDiscard) return { code: "games.splendorduel.errBadDiscard" };
		let n = /* @__PURE__ */ new Map();
		for (let e of t.tokens) n.set(e, (n.get(e) ?? 0) + 1);
		for (let [t, i] of n) if (e.tokens[r][t] < i) return { code: "games.splendorduel.errBadDiscard" };
		let i = structuredClone(e);
		for (let e of t.tokens) --i.tokens[r][e], i.bag.push(e);
		return i.mustDiscard = 0, {
			state: i,
			fx: [{
				kind: "discard",
				rid: r,
				data: { tokens: t.tokens }
			}, ...me(i)]
		};
	}
	if (e.phase !== "play") return { code: "games.splendorduel.errNotYourTurn" };
	if (G(e, r) || e.bag.length > 0) return { code: "games.splendorduel.errBadPass" };
	let a = structuredClone(e);
	return {
		state: a,
		fx: me(a)
	};
}
function _e(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			board: [...e.board],
			pyramid: [...e.pyramid],
			deckCounts: {
				1: e.decks[1].length,
				2: e.decks[2].length,
				3: e.decks[3].length
			},
			bagCount: e.bag.length,
			supply: e.supply,
			royals: [...e.royals],
			mustDiscard: e.mustDiscard,
			extraTurn: e.extraTurn,
			players: e.players.map((t) => ({
				rid: t,
				tokens: { ...e.tokens[t] },
				bonuses: { ...e.bonuses[t] },
				points: H(e, t),
				colorPoints: U(e, t),
				crowns: ue(e, t),
				privileges: e.privileges[t],
				reservedPublic: [...e.reservedPublic[t]],
				blindCount: e.reservedBlind[t].length,
				royalsWon: [...e.royalsWon[t]]
			}))
		},
		private: { reservedBlind: [...e.reservedBlind[t] ?? []] }
	};
}
function q(e) {
	if (e.phase !== "done" || !e.winner) return { phase: e.phase };
	let t = e.winner, n = B(e, t), r = {};
	for (let t of e.players) r[t] = H(e, t);
	return {
		phase: "done",
		winner: [t],
		ranking: [t, n],
		scores: r
	};
}
var J = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: A,
	schemas: {
		action: P,
		publicView: ne,
		privateView: re
	},
	setup: fe,
	reduce: ge,
	viewFor: _e,
	status: q
}, Y = {
	white: {
		bg: "var(--color-sp-white)",
		fg: "var(--color-sp-white-ink)",
		deep: "var(--color-sp-white-deep)"
	},
	blue: {
		bg: "var(--color-sp-blue)",
		fg: "var(--color-surface)",
		deep: "var(--color-sp-blue-deep)"
	},
	green: {
		bg: "var(--color-sp-green)",
		fg: "var(--color-surface)",
		deep: "var(--color-sp-green-deep)"
	},
	red: {
		bg: "var(--color-sp-red)",
		fg: "var(--color-surface)",
		deep: "var(--color-sp-red-deep)"
	},
	black: {
		bg: "var(--color-sp-black)",
		fg: "var(--color-surface)",
		deep: "var(--color-sp-black-deep)"
	},
	pearl: {
		bg: "var(--color-sp-pearl)",
		fg: "var(--color-sp-pearl-ink)",
		deep: "var(--color-sp-pearl-deep)"
	},
	gold: {
		bg: "var(--color-sp-gold)",
		fg: "var(--color-sp-gold-ink)",
		deep: "var(--color-sp-gold-deep)"
	}
}, ve = {
	white: Y.white,
	blue: Y.blue,
	green: Y.green,
	red: Y.red,
	black: Y.black,
	joker: {
		bg: "var(--color-sp-parchment)",
		fg: "var(--color-ink)",
		deep: "var(--color-sp-brass-deep)"
	},
	none: {
		bg: "var(--color-sp-white-deep)",
		fg: "var(--color-surface)",
		deep: "var(--color-sp-white-ink)"
	}
}, ye = {
	1: "var(--color-sp-deck-1)",
	2: "var(--color-sp-deck-2)",
	3: "var(--color-sp-deck-3)"
}, be = {
	1: "var(--color-sp-art-1)",
	2: "var(--color-sp-art-2)",
	3: "var(--color-sp-art-3)"
}, xe = {
	1: "Ⅰ",
	2: "Ⅱ",
	3: "Ⅲ"
};
function Se({ fill: e, line: t, size: n, x: r = 0, y: i = 0 }) {
	return /* @__PURE__ */ m("svg", {
		x: r,
		y: i,
		width: n,
		height: n,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		className: "flex-none",
		children: [/* @__PURE__ */ p("path", {
			d: "M12 2.5 L20 9 L16.5 21.5 L7.5 21.5 L4 9 Z",
			fill: e
		}), /* @__PURE__ */ p("path", {
			d: "M4 9 L20 9 M8.2 9 L10.2 21.3 M15.8 9 L13.8 21.3",
			fill: "none",
			stroke: t,
			strokeWidth: 1,
			opacity: .55
		})]
	});
}
function Ce({ fill: e = "var(--color-sp-brass)", size: t = 10, x: n = 0, y: r = 0 }) {
	return /* @__PURE__ */ p("svg", {
		x: n,
		y: r,
		width: t,
		height: t,
		viewBox: "0 0 16 12",
		"aria-hidden": !0,
		className: "flex-none",
		children: /* @__PURE__ */ p("path", {
			d: "M1.5 10.5 L0.5 3 L5 6 L8 0.8 L11 6 L15.5 3 L14.5 10.5 Z",
			fill: e,
			stroke: "var(--color-ink)",
			strokeWidth: .9,
			strokeLinejoin: "round"
		})
	});
}
function we({ ability: e, size: t = 13, x: n = 0, y: r = 0 }) {
	return /* @__PURE__ */ m("svg", {
		x: n,
		y: r,
		width: t,
		height: t,
		viewBox: "0 0 16 16",
		"aria-hidden": !0,
		className: "flex-none",
		children: [
			/* @__PURE__ */ p("circle", {
				cx: 8,
				cy: 8,
				r: 7.4,
				fill: "var(--color-surface)",
				stroke: "var(--color-ink)",
				strokeWidth: 1.1
			}),
			e === "extraTurn" && /* @__PURE__ */ m("g", {
				fill: "none",
				stroke: "var(--color-ink)",
				strokeWidth: 1.5,
				strokeLinecap: "round",
				children: [/* @__PURE__ */ p("path", { d: "M11.8 5.2 A4.4 4.4 0 1 0 12.4 8" }), /* @__PURE__ */ p("path", {
					d: "M10.2 2.8 L12.1 5.4 L9.2 6.4 Z",
					fill: "var(--color-ink)",
					stroke: "none"
				})]
			}),
			e === "takeSameColor" && /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("path", {
				d: "M8 3.4 L11.2 6 L9.9 11.2 L6.1 11.2 L4.8 6 Z",
				fill: "var(--color-ink)"
			}), /* @__PURE__ */ p("path", {
				d: "M11.6 12.4 h2.4 M12.8 11.2 v2.4",
				stroke: "var(--color-ink)",
				strokeWidth: 1.3,
				strokeLinecap: "round"
			})] }),
			e === "privilege" && /* @__PURE__ */ m("g", {
				fill: "var(--color-ink)",
				children: [
					/* @__PURE__ */ p("rect", {
						x: 4.6,
						y: 4.2,
						width: 6.8,
						height: 7.6,
						rx: 1.2
					}),
					/* @__PURE__ */ p("circle", {
						cx: 4.6,
						cy: 8,
						r: 1.7
					}),
					/* @__PURE__ */ p("circle", {
						cx: 11.4,
						cy: 8,
						r: 1.7,
						fill: "var(--color-surface)",
						stroke: "var(--color-ink)",
						strokeWidth: 1
					})
				]
			}),
			e === "steal" && /* @__PURE__ */ m("g", {
				fill: "none",
				stroke: "var(--color-ink)",
				strokeWidth: 1.4,
				strokeLinecap: "round",
				children: [/* @__PURE__ */ p("circle", {
					cx: 5.4,
					cy: 8,
					r: 2.5,
					fill: "var(--color-ink)",
					stroke: "none"
				}), /* @__PURE__ */ p("path", { d: "M8.6 8 h4.4 M11.4 6.2 L13.2 8 L11.4 9.8" })]
			})
		]
	});
}
function Te({ x: e, y: t, color: n, n: r, size: i }) {
	let a = Y[n];
	return /* @__PURE__ */ m("g", {
		transform: `translate(${e} ${t})`,
		children: [
			/* @__PURE__ */ p("circle", {
				cx: i / 2,
				cy: i / 2,
				r: i / 2 - .6,
				fill: a.deep,
				stroke: "var(--color-surface)",
				strokeWidth: 1.2
			}),
			/* @__PURE__ */ p("circle", {
				cx: i / 2,
				cy: i / 2,
				r: i / 2 - 2,
				fill: a.bg
			}),
			/* @__PURE__ */ p("path", {
				d: `M3.2 5.4 Q${i / 2} 1.7 ${i - 3.2} 5.4`,
				fill: "none",
				stroke: a.fg,
				strokeWidth: 1,
				strokeLinecap: "round",
				opacity: .6
			}),
			/* @__PURE__ */ p("text", {
				x: i / 2,
				y: i / 2 + 3.3,
				textAnchor: "middle",
				fill: a.fg,
				fontFamily: "monospace",
				fontWeight: 900,
				fontSize: 10,
				children: r
			})
		]
	});
}
function Ee(e) {
	return Object.entries(e).filter(([, e]) => e > 0);
}
function X({ id: e, w: t = 58, h: n = 78 }) {
	let r = O(e), i = ve[r.color], a = Ee(r.cost), o = 74 - a.length * 14.5;
	return /* @__PURE__ */ m("svg", {
		width: t,
		height: n,
		viewBox: "0 0 58 78",
		"aria-hidden": !0,
		className: "block flex-none overflow-visible",
		children: [
			/* @__PURE__ */ p("rect", {
				x: 1,
				y: 1,
				width: 56,
				height: 76,
				rx: 4.5,
				fill: "var(--color-sp-parchment)",
				stroke: "var(--color-ink)",
				strokeWidth: 1.8
			}),
			/* @__PURE__ */ p("rect", {
				x: 15,
				y: 17,
				width: 41,
				height: 59,
				fill: be[r.tier]
			}),
			/* @__PURE__ */ p("path", {
				d: "M15 68 56 34v42H15Z",
				fill: "var(--color-surface)",
				opacity: .12
			}),
			/* @__PURE__ */ p("path", {
				d: "M17 20h37M17 73h37M18 22v49M53 22v49",
				fill: "none",
				stroke: "var(--color-sp-brass)",
				strokeWidth: .75,
				opacity: .8
			}),
			/* @__PURE__ */ p("path", {
				d: "M17 34 35.5 20 54 34M17 61 35.5 74 54 61",
				fill: "none",
				stroke: "var(--color-sp-parchment)",
				strokeWidth: .55,
				opacity: .38
			}),
			r.color === "joker" ? /* @__PURE__ */ m("g", {
				transform: "translate(35.5 47)",
				children: [[
					0,
					1,
					2,
					3,
					4
				].map((e) => /* @__PURE__ */ p("path", {
					d: "M0 0 L-13 -15 A20 20 0 0 1 13 -15 Z",
					fill: Y[[
						"white",
						"blue",
						"green",
						"red",
						"black"
					][e]].bg,
					stroke: "var(--color-sp-brass)",
					strokeWidth: .7,
					transform: `rotate(${e * 72})`
				}, e)), /* @__PURE__ */ p("circle", {
					r: 4.6,
					fill: "var(--color-sp-parchment)",
					stroke: "var(--color-sp-brass)",
					strokeWidth: 1
				})]
			}) : /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("path", {
					d: "M35.5 26 47.5 42 35.5 60 23.5 42Z",
					fill: "var(--color-sp-velvet-deep)",
					stroke: "var(--color-sp-brass)",
					strokeWidth: 1.5
				}),
				/* @__PURE__ */ p("path", {
					d: "M35.5 28.5 44.5 42 35.5 57 26.5 42Z",
					fill: "none",
					stroke: "var(--color-sp-parchment)",
					strokeWidth: .7,
					opacity: .7
				}),
				/* @__PURE__ */ p(Se, {
					fill: i.bg,
					line: i.fg,
					x: 26.5,
					y: 33.5,
					size: 18
				})
			] }),
			/* @__PURE__ */ p("rect", {
				x: 1.8,
				y: 17,
				width: 13.4,
				height: 59,
				fill: "var(--color-sp-parchment)",
				opacity: .92
			}),
			/* @__PURE__ */ p("path", {
				d: "M15.2 17v59",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .8
			}),
			/* @__PURE__ */ p("rect", {
				x: 1.8,
				y: 1.8,
				width: 54.4,
				height: 15,
				rx: 2.5,
				fill: "var(--color-sp-parchment)"
			}),
			/* @__PURE__ */ p("path", {
				d: "M2.6 16.8h52.8",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .9
			}),
			r.points > 0 && /* @__PURE__ */ p("text", {
				x: 4.5,
				y: 14,
				fill: "var(--color-ink)",
				fontFamily: "var(--font-display)",
				fontWeight: 800,
				fontSize: 14,
				children: r.points
			}),
			Array.from({ length: r.crowns }, (e, t) => /* @__PURE__ */ p(Ce, {
				x: r.points > 0 ? 13 + t * 8.6 : 4 + t * 8.6,
				y: 5.4,
				size: 8.6
			}, t)),
			r.bonusCount > 0 && /* @__PURE__ */ m("g", { children: [
				/* @__PURE__ */ p("circle", {
					cx: 50,
					cy: 9,
					r: 6.6,
					fill: i.bg,
					stroke: "var(--color-ink)",
					strokeWidth: 1.1
				}),
				/* @__PURE__ */ p(Se, {
					fill: i.bg,
					line: i.fg,
					x: 45.2,
					y: 4.2,
					size: 9.6
				}),
				r.bonusCount === 2 && /* @__PURE__ */ p("text", {
					x: 41.5,
					y: 12.6,
					textAnchor: "middle",
					fill: "var(--color-ink)",
					fontFamily: "monospace",
					fontWeight: 900,
					fontSize: 7.5,
					children: "×2"
				})
			] }),
			r.ability && /* @__PURE__ */ p(we, {
				ability: r.ability,
				x: 43.4,
				y: 17.6,
				size: 12.4
			}),
			a.map(([e, t], n) => /* @__PURE__ */ p(Te, {
				x: 1.8,
				y: o + n * 14.5,
				color: e,
				n: t,
				size: 13.6
			}, e)),
			/* @__PURE__ */ p("rect", {
				x: 2.6,
				y: 2.6,
				width: 52.8,
				height: 72.8,
				rx: 2.6,
				fill: "none",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .55,
				opacity: .75
			})
		]
	});
}
function De({ tier: e, w: t = 34, h: n = 78 }) {
	return /* @__PURE__ */ m("svg", {
		width: t,
		height: n,
		viewBox: "0 0 34 78",
		"aria-hidden": !0,
		className: "block flex-none overflow-visible",
		children: [
			/* @__PURE__ */ p("rect", {
				x: 1,
				y: 1,
				width: 32,
				height: 76,
				rx: 4.5,
				fill: ye[e],
				stroke: "var(--color-ink)",
				strokeWidth: 1.8
			}),
			/* @__PURE__ */ p("rect", {
				x: 3.6,
				y: 3.6,
				width: 26.8,
				height: 70.8,
				rx: 2.6,
				fill: "none",
				stroke: "var(--color-sp-brass)",
				strokeWidth: .9
			}),
			/* @__PURE__ */ p("path", {
				d: "M17 10 27 34 17 58 7 34Z",
				fill: "none",
				stroke: "var(--color-sp-brass)",
				strokeWidth: .9,
				opacity: .85
			}),
			/* @__PURE__ */ p(Se, {
				fill: "var(--color-sp-brass)",
				line: "var(--color-sp-velvet-deep)",
				x: 9.5,
				y: 24,
				size: 15
			}),
			/* @__PURE__ */ p("text", {
				x: 17,
				y: 52,
				textAnchor: "middle",
				fill: "var(--color-surface)",
				fontFamily: "var(--font-display)",
				fontWeight: 800,
				fontSize: 13,
				children: xe[e]
			})
		]
	});
}
function Z({ color: e, count: t, size: n = 40 }) {
	let r = Y[e];
	return /* @__PURE__ */ m("svg", {
		width: n,
		height: n,
		viewBox: "0 0 48 48",
		"aria-hidden": !0,
		className: "flex-none",
		children: [
			/* @__PURE__ */ p("circle", {
				cx: 24,
				cy: 24,
				r: 21.5,
				fill: r.deep,
				stroke: "var(--color-ink)",
				strokeWidth: 2.4
			}),
			[
				0,
				45,
				90,
				135,
				180,
				225,
				270,
				315
			].map((e) => /* @__PURE__ */ p("rect", {
				x: 22.2,
				y: 3.4,
				width: 3.6,
				height: 6,
				rx: 1.8,
				fill: r.fg,
				opacity: .55,
				transform: `rotate(${e} 24 24)`
			}, e)),
			/* @__PURE__ */ p("circle", {
				cx: 24,
				cy: 24,
				r: 13.5,
				fill: r.bg,
				stroke: r.deep,
				strokeWidth: 1.2
			}),
			e === "pearl" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
				cx: 24,
				cy: 24,
				r: 8.5,
				fill: r.bg,
				stroke: r.deep,
				strokeWidth: .8
			}), /* @__PURE__ */ p("path", {
				d: "M19 21 Q24 16.5 29 21",
				fill: "none",
				stroke: r.fg,
				strokeWidth: 1.4,
				strokeLinecap: "round",
				opacity: .7
			})] }) : /* @__PURE__ */ p("path", {
				d: "M13 16.5 Q24 9 35 16.5",
				fill: "none",
				stroke: r.fg,
				strokeWidth: 2,
				strokeLinecap: "round",
				opacity: .35
			}),
			t !== void 0 && /* @__PURE__ */ p("text", {
				x: 24,
				y: 24.8,
				textAnchor: "middle",
				dominantBaseline: "central",
				fill: r.fg,
				className: "font-mono font-extrabold tabular-nums",
				style: { fontSize: 17 },
				children: t
			})
		]
	});
}
function Oe({ size: e = 26 }) {
	return /* @__PURE__ */ m("svg", {
		width: e,
		height: e,
		viewBox: "0 0 28 20",
		"aria-hidden": !0,
		className: "flex-none",
		children: [
			/* @__PURE__ */ p("rect", {
				x: 4,
				y: 3,
				width: 20,
				height: 14,
				rx: 2,
				fill: "var(--color-sp-parchment)",
				stroke: "var(--color-ink)",
				strokeWidth: 1.6
			}),
			/* @__PURE__ */ p("circle", {
				cx: 5,
				cy: 10,
				r: 3.4,
				fill: "var(--color-sp-parchment)",
				stroke: "var(--color-ink)",
				strokeWidth: 1.6
			}),
			/* @__PURE__ */ p("circle", {
				cx: 5,
				cy: 10,
				r: 1.1,
				fill: "var(--color-sp-brass-deep)"
			}),
			/* @__PURE__ */ p("path", {
				d: "M10 7h10M10 10h10M10 13h7",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: 1.1,
				strokeLinecap: "round"
			})
		]
	});
}
function ke({ id: e, w: t = 46, h: n = 60 }) {
	let r = k(e);
	return /* @__PURE__ */ m("svg", {
		width: t,
		height: n,
		viewBox: "0 0 46 60",
		"aria-hidden": !0,
		className: "block flex-none overflow-visible",
		children: [
			/* @__PURE__ */ p("rect", {
				x: 1,
				y: 1,
				width: 44,
				height: 58,
				rx: 4.5,
				fill: "var(--color-sp-parchment)",
				stroke: "var(--color-ink)",
				strokeWidth: 1.8
			}),
			/* @__PURE__ */ p("rect", {
				x: 3.4,
				y: 3.4,
				width: 39.2,
				height: 53.2,
				rx: 2.6,
				fill: "none",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .8
			}),
			/* @__PURE__ */ p("path", {
				d: "M6 24 L9 12 L15 19 L23 8 L31 19 L37 12 L40 24 Z",
				fill: "var(--color-sp-brass)",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: 1.1,
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ p("circle", {
				cx: 9,
				cy: 11,
				r: 1.6,
				fill: "var(--color-sp-brass)",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .8
			}),
			/* @__PURE__ */ p("circle", {
				cx: 23,
				cy: 7,
				r: 1.8,
				fill: "var(--color-sp-brass)",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .8
			}),
			/* @__PURE__ */ p("circle", {
				cx: 37,
				cy: 11,
				r: 1.6,
				fill: "var(--color-sp-brass)",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .8
			}),
			/* @__PURE__ */ p("rect", {
				x: 7,
				y: 24,
				width: 32,
				height: 3.4,
				rx: 1.7,
				fill: "var(--color-sp-brass)",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .9
			}),
			/* @__PURE__ */ p("text", {
				x: 23,
				y: 46,
				textAnchor: "middle",
				fill: "var(--color-ink)",
				fontFamily: "var(--font-display)",
				fontWeight: 800,
				fontSize: 20,
				children: r.points
			}),
			r.ability && /* @__PURE__ */ p(we, {
				ability: r.ability,
				x: 16.4,
				y: 47.6,
				size: 13.2
			})
		]
	});
}
function Ae({ fg: e, bg: t, size: n = 11 }) {
	return /* @__PURE__ */ m("svg", {
		width: n,
		height: n,
		viewBox: "0 0 16 16",
		"aria-hidden": !0,
		className: "flex-none",
		children: [/* @__PURE__ */ p("rect", {
			x: 3,
			y: 1.8,
			width: 10,
			height: 12.4,
			rx: 2,
			fill: e
		}), /* @__PURE__ */ p("path", {
			d: "M8 4.6 L11.2 7.2 L10.1 11.6 L5.9 11.6 L4.8 7.2 Z",
			fill: t
		})]
	});
}
//#endregion
//#region src/games/splendorduel/view-player.tsx
function je(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(Le, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var Me = {
	white: "games.splendorduel.gem.white",
	blue: "games.splendorduel.gem.blue",
	green: "games.splendorduel.gem.green",
	red: "games.splendorduel.gem.red",
	black: "games.splendorduel.gem.black",
	pearl: "games.splendorduel.gem.pearl",
	gold: "games.splendorduel.gem.gold"
}, Ne = [
	[
		0,
		1,
		2
	],
	[
		3,
		4,
		5,
		6
	],
	[
		7,
		8,
		9,
		10,
		11
	]
], Pe = [
	3,
	2,
	1
], Fe = "./games/splendorduel/board.webp";
function Ie(e) {
	if (e.length <= 1) return !0;
	let t = (e) => [Math.floor(e / 5), e % 5], [n, r] = t(e[e.length - 2]), [i, a] = t(e[e.length - 1]), o = i - n, s = a - r;
	if (Math.abs(o) > 1 || Math.abs(s) > 1 || o === 0 && s === 0) return !1;
	if (e.length === 2) return !0;
	let [c, l] = t(e[0]);
	return n - c === o && r - l === s;
}
function Le({ pub: e, priv: t, members: r, myRid: a, send: d }) {
	let h = o(), g = (e) => r.find((t) => t.rid === e)?.name ?? e, _ = e.players.find((e) => e.rid === a), ee = e.players.find((e) => e.rid !== a), v = e.phase === "play" && e.turn === a, y = e.phase === "steal" && e.turn === a, te = e.phase === "chooseRoyal" && e.turn === a, C = e.phase === "discard" && e.turn === a, [w, T] = n([]), [E, D] = n(null), [k, j] = n(null), [M, N] = n(null), [P, F] = n([]), [I, ne] = n(!1), re = `${e.phase}|${e.turn}|${e.board.map((e) => e ?? ".").join("")}|${e.pyramid.map((e) => e ?? ".").join(",")}|${e.mustDiscard}|${e.supply}|${e.royals.join(".")}`, [ie, ae] = n(re);
	ie !== re && (ae(re), T([]), D(null), j(null), N(null), F([]), ne(!1));
	let [L, R] = n(a), z = v || y || te || C, [oe, se] = n(z);
	oe !== z && (se(z), z && R(a));
	let B = L === a ? _ : e.players.find((e) => e.rid === L), V = L !== a, ce = B ? Math.max(...b.map((e) => B.colorPoints[e])) : 0, le = e.board.includes("gold"), ue = _ ? _.reservedPublic.length + _.blindCount : 0, H = le && ue < 3 && (e.pyramid.some((e) => e !== null) || e.deckCounts[1] + e.deckCounts[2] + e.deckCounts[3] > 0), U = E ? O(E.cardId) : null, G = U && _ ? W(U.cost, _.bonuses, _.tokens) : null, fe = U && _ ? Math.max(0, S.reduce((e, t) => {
		let n = t === "pearl" ? 0 : _.bonuses[t];
		return e + Math.max(0, (U.cost[t] ?? 0) - n - _.tokens[t]);
	}, 0) - _.tokens.gold) : 0, pe = new Set(v && !I && w.length > 0 && w.length < 3 ? e.board.flatMap((e, t) => e && e !== "gold" && !w.includes(t) && Ie([...w, t]) ? [t] : []) : []), K = _ ? b.filter((e) => _.bonuses[e] > 0) : [], me = e.board.some((e) => e !== null && e !== "gold"), he = _ !== void 0 && (e.pyramid.some((e) => e !== null && W(O(e).cost, _.bonuses, _.tokens) !== null) || [..._.reservedPublic, ...t?.reservedBlind ?? []].some((e) => W(O(e).cost, _.bonuses, _.tokens) !== null)), ge = v && !me && !H && !he && e.bagCount === 0, _e = w.length > 0 || E !== null || k !== null || y || ge, q, J;
	C ? (q = "warn", J = h("games.splendorduel.discardPrompt", { n: e.mustDiscard })) : e.phase === "discard" ? (q = "info", J = h("games.splendorduel.discardWait", { name: g(e.turn) })) : y ? (q = "accent", J = h("games.splendorduel.stealPrompt")) : e.phase === "steal" ? (q = "info", J = h("games.splendorduel.stealWait", { name: g(e.turn) })) : te ? (q = "accent", J = h("games.splendorduel.royalPrompt")) : e.phase === "chooseRoyal" ? (q = "info", J = h("games.splendorduel.royalWait", { name: g(e.turn) })) : v ? (q = "accent", J = h(I ? "games.splendorduel.privilegeMode" : "games.splendorduel.turnYou")) : e.phase === "play" ? (q = "info", J = h("games.splendorduel.turnWait", { name: g(e.turn) })) : (q = "done", J = "");
	let Y = (t) => {
		let n = e.board[t];
		if (n) {
			if (v && I) {
				n !== "gold" && d({
					type: "usePrivilege",
					cell: t
				});
				return;
			}
			v && n !== "gold" && (R(a), D(null), j(null), T((e) => {
				let n = e.indexOf(t);
				if (n >= 0) return e.slice(0, n);
				if (e.length >= 3) return e;
				let r = [...e, t];
				return Ie(r) ? r : e;
			}));
		}
	}, ve = (e, t) => {
		v && (R(a), T([]), j(null), N(null), D(E?.cardId === e ? null : {
			cardId: e,
			from: t
		}));
	}, ye = (e) => {
		v && (R(a), T([]), D(null), j(k === e ? null : e));
	}, be = (t) => {
		C && _ && F((n) => {
			let r = n.indexOf(t);
			return r >= 0 ? n.filter((e, t) => t !== r) : n.filter((e) => e === t).length >= _.tokens[t] || n.length >= e.mustDiscard ? n : [...n, t];
		});
	}, xe = /* @__PURE__ */ m("div", {
		className: "sd-banner",
		children: [/* @__PURE__ */ p(l, {
			tone: q,
			text: J,
			chip: e.extraTurn ? h("games.splendorduel.extraTurnChip") : void 0,
			accent: A.accent
		}), /* @__PURE__ */ p(u, {
			variant: "plate",
			members: r,
			myRid: a,
			anchorOf: (e) => `seat:${e}`,
			onPick: (e) => R(e === L ? a : e),
			picked: (e) => e === L && L !== a,
			action: (t) => e.phase !== "done" && t === e.turn ? "pending" : null,
			status: (t) => {
				let n = e.players.find((e) => e.rid === t);
				if (!n) return null;
				let r = x.reduce((e, t) => e + n.tokens[t], 0);
				return /* @__PURE__ */ m("span", {
					className: "sd-player-status flex w-full flex-nowrap items-center justify-between gap-1 font-mono text-sm leading-4.5 font-extrabold tabular-nums whitespace-nowrap",
					children: [
						/* @__PURE__ */ m("span", {
							className: "flex items-center gap-px",
							children: [/* @__PURE__ */ p("span", {
								"aria-hidden": !0,
								className: "text-[10px]",
								children: "🏆"
							}), /* @__PURE__ */ p(i, { value: n.points })]
						}),
						/* @__PURE__ */ m("span", {
							className: "flex items-center gap-0.5",
							children: [/* @__PURE__ */ p(Ce, { size: 11 }), n.crowns]
						}),
						/* @__PURE__ */ m("span", {
							className: "flex items-center gap-0.5",
							children: [/* @__PURE__ */ p(Oe, { size: 15 }), n.privileges]
						}),
						/* @__PURE__ */ m("span", {
							className: "flex items-center gap-0.5",
							children: [/* @__PURE__ */ p(Z, {
								color: "gold",
								size: 13
							}), r]
						})
					]
				});
			}
		})]
	}), Se = _ && B && /* @__PURE__ */ m("div", {
		className: "sd-tray safe-b",
		"data-covered": _e,
		children: [/* @__PURE__ */ p("div", {
			className: "sd-tray-tokens flex items-center justify-center gap-1",
			children: x.map((e) => /* @__PURE__ */ p(Ge, {
				color: e,
				count: B.tokens[e],
				anchor: V ? null : `mtok:${e}`,
				picked: !V && C && P.includes(e),
				onPick: !V && C && B.tokens[e] > 0 ? () => be(e) : void 0
			}, e))
		}), /* @__PURE__ */ m("div", {
			className: "sd-tray-controls flex items-center justify-center gap-2",
			children: [/* @__PURE__ */ m("div", {
				className: "sd-reserves flex items-center gap-1",
				children: [V ? Array.from({ length: B.reservedPublic.length + B.blindCount }, (e, t) => t < B.reservedPublic.length ? /* @__PURE__ */ p("span", {
					className: "sd-rsv-card",
					children: /* @__PURE__ */ p(X, {
						id: B.reservedPublic[t],
						w: 36,
						h: 49
					})
				}, B.reservedPublic[t]) : /* @__PURE__ */ p("span", {
					className: "sd-rsv-card",
					children: /* @__PURE__ */ p(De, {
						tier: 1,
						w: 36,
						h: 49
					})
				}, `blind-${t}`)) : [..._.reservedPublic, ...t?.reservedBlind ?? []].map((e, t) => /* @__PURE__ */ p(Ke, {
					id: e,
					index: t,
					active: E?.cardId === e,
					affordable: v && W(O(e).cost, _.bonuses, _.tokens) !== null,
					disabled: !v,
					onPick: () => ve(e, "reserved")
				}, e)), Array.from({ length: Math.max(0, 3 - (V ? B.reservedPublic.length + B.blindCount : ue)) }, (e, t) => /* @__PURE__ */ p("span", {
					className: "sd-rsv-slot",
					"aria-label": h("games.splendorduel.reservedSlot"),
					role: "img",
					children: h("games.splendorduel.reservedSlot")
				}, `empty-${t}`))]
			}), !V && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("button", {
				type: "button",
				disabled: !v || _.privileges <= 0,
				"aria-pressed": I,
				className: "btn-quiet min-h-11 flex-none px-2 text-xs disabled:opacity-40",
				"data-active": I,
				onClick: () => {
					ne(!I), T([]);
				},
				children: [
					/* @__PURE__ */ p(Oe, { size: 18 }),
					h("games.splendorduel.usePrivilege"),
					"×",
					_.privileges
				]
			}), /* @__PURE__ */ p("button", {
				type: "button",
				disabled: !v || e.bagCount === 0 || !e.board.includes(null),
				className: "btn-quiet min-h-11 flex-none px-2 text-xs disabled:opacity-40",
				onClick: () => d({ type: "replenish" }),
				children: h("games.splendorduel.replenish")
			})] })]
		})]
	}), we = /* @__PURE__ */ m("div", {
		className: "sd-action-overlay",
		"data-lower": !C,
		children: [
			w.length > 0 && v && !I && /* @__PURE__ */ m("div", {
				className: "card pointer-events-auto mx-2 mb-1 flex min-h-12 items-center gap-2 px-3 py-1.5",
				children: [
					/* @__PURE__ */ m("span", {
						className: "flex min-w-0 flex-1 items-center gap-1",
						children: [w.map((t, n) => /* @__PURE__ */ p(Z, {
							color: e.board[t],
							size: 22
						}, `${t}-${n}`)), !de(w, e.board) && /* @__PURE__ */ p("span", {
							className: "ml-1 truncate text-xs font-bold text-warn-ink",
							children: h("games.splendorduel.takeIllegal")
						})]
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-3 text-sm",
						onClick: () => T([]),
						children: h("games.splendorduel.cancel")
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						disabled: !de(w, e.board),
						className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
						style: { background: A.accent },
						onClick: () => {
							d({
								type: "take",
								cells: w
							}), T([]);
						},
						children: h("games.splendorduel.takeConfirm", { n: w.length })
					})
				]
			}),
			E && U && _ && /* @__PURE__ */ m("div", {
				className: "card pointer-events-auto mx-2 mb-1 flex min-h-12 items-center gap-2 px-3 py-1.5",
				children: [
					/* @__PURE__ */ p(X, {
						id: U.id,
						w: 34,
						h: 46
					}),
					/* @__PURE__ */ m("span", {
						className: "flex min-w-0 flex-1 flex-wrap items-center gap-0.5",
						children: [U.color === "joker" ? K.length === 0 ? /* @__PURE__ */ p("span", {
							className: "truncate text-xs font-bold text-warn-ink",
							children: h("games.splendorduel.errBadAttach")
						}) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", {
							className: "w-full text-[11px] font-bold text-ink/70",
							children: h("games.splendorduel.attachPrompt")
						}), K.map((e) => /* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": h(Me[e]),
							"aria-pressed": M === e,
							className: "sd-attach-btn",
							"data-picked": M === e,
							onClick: () => N(M === e ? null : e),
							children: /* @__PURE__ */ p(Z, {
								color: e,
								size: 20
							})
						}, e))] }) : G ? /* @__PURE__ */ m(f, { children: [
							S.filter((e) => (G.pay[e] ?? 0) > 0).map((e) => /* @__PURE__ */ p(Z, {
								color: e,
								count: G.pay[e],
								size: 20
							}, e)),
							G.gold > 0 && /* @__PURE__ */ p(Z, {
								color: "gold",
								count: G.gold,
								size: 20
							}),
							Object.keys(G.pay).length === 0 && G.gold === 0 && /* @__PURE__ */ p("span", {
								className: "text-sm font-extrabold text-emerald-600",
								children: h("games.splendorduel.free")
							})
						] }) : /* @__PURE__ */ p("span", {
							className: "truncate text-xs font-bold text-warn-ink",
							children: h("games.splendorduel.missingTokens", { n: fe })
						}), U.color === "joker" && K.length > 0 && !G && /* @__PURE__ */ p("span", {
							className: "truncate text-xs font-bold text-warn-ink",
							children: h("games.splendorduel.missingTokens", { n: fe })
						})]
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-2 text-xs",
						onClick: () => D(null),
						children: h("games.splendorduel.cancel")
					}),
					E.from === "pyramid" && /* @__PURE__ */ p("button", {
						type: "button",
						disabled: !H,
						className: "btn-quiet min-h-11 px-2 text-xs disabled:opacity-40",
						onClick: () => {
							d({
								type: "reserve",
								cardId: E.cardId
							}), D(null);
						},
						children: h("games.splendorduel.reserve")
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						disabled: !G || U.color === "joker" && !M,
						className: "btn-base min-h-11 px-3 text-sm text-white disabled:opacity-40",
						style: { background: A.accent },
						onClick: () => {
							d({
								type: "buy",
								cardId: E.cardId,
								from: E.from,
								attachColor: U.color === "joker" ? M ?? void 0 : void 0
							}), D(null), N(null);
						},
						children: h("games.splendorduel.buy")
					})
				]
			}),
			k !== null && /* @__PURE__ */ m("div", {
				className: "card pointer-events-auto mx-2 mb-1 flex min-h-12 items-center gap-2 px-3 py-1.5",
				children: [
					/* @__PURE__ */ p("span", {
						className: "min-w-0 flex-1 truncate text-sm font-extrabold",
						children: h("games.splendorduel.reserveDeckDesc", { tier: k })
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-3 text-sm",
						onClick: () => j(null),
						children: h("games.splendorduel.cancel")
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						disabled: !H,
						className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
						style: { background: A.accent },
						onClick: () => {
							d({
								type: "reserve",
								tier: k
							}), j(null);
						},
						children: h("games.splendorduel.reserve")
					})
				]
			}),
			y && ee && /* @__PURE__ */ p("div", {
				className: "card pointer-events-auto mx-2 mb-1 flex min-h-12 items-center gap-2 px-3 py-1.5",
				children: /* @__PURE__ */ p("span", {
					className: "flex min-w-0 flex-1 items-center justify-center gap-1.5",
					children: [...b, "pearl"].filter((e) => ee.tokens[e] > 0).map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						"aria-label": h(Me[e]),
						className: "sd-steal-btn",
						onClick: () => d({
							type: "steal",
							color: e
						}),
						children: /* @__PURE__ */ p(Z, {
							color: e,
							count: ee.tokens[e],
							size: 30
						})
					}, e))
				})
			}),
			C && /* @__PURE__ */ m("div", {
				className: "card pointer-events-auto mx-2 mb-1 flex min-h-12 items-center gap-2 px-3 py-1.5",
				children: [
					/* @__PURE__ */ m("span", {
						className: "flex min-w-0 flex-1 items-center gap-1",
						children: [P.map((e, t) => /* @__PURE__ */ p(Z, {
							color: e,
							size: 22
						}, `${e}-${t}`)), /* @__PURE__ */ m("span", {
							className: "ml-1 font-mono text-sm font-extrabold tabular-nums",
							children: [
								P.length,
								"/",
								e.mustDiscard
							]
						})]
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-3 text-sm",
						onClick: () => F([]),
						children: h("games.splendorduel.cancel")
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						disabled: P.length !== e.mustDiscard,
						className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
						style: { background: A.accent },
						onClick: () => {
							d({
								type: "discard",
								tokens: P
							}), F([]);
						},
						children: h("games.splendorduel.discardConfirm")
					})
				]
			}),
			ge && /* @__PURE__ */ m("div", {
				className: "card pointer-events-auto mx-2 mb-1 flex min-h-12 items-center gap-2 px-3 py-1.5",
				children: [/* @__PURE__ */ p("span", {
					className: "min-w-0 flex-1 truncate text-sm font-extrabold",
					children: h("games.splendorduel.passPrompt")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base min-h-11 px-4 text-sm text-white",
					style: { background: A.accent },
					onClick: () => d({ type: "pass" }),
					children: h("games.splendorduel.pass")
				})]
			})
		]
	});
	return /* @__PURE__ */ p(c, {
		adaptive: !0,
		className: "sd-view",
		banner: xe,
		actions: Se,
		actionsHeight: "sd-actions h-28 wide:short:h-18",
		overlay: we,
		children: /* @__PURE__ */ m("div", {
			className: "sd-center",
			"data-waiting": !z,
			children: [
				/* @__PURE__ */ p(s, {
					kind: "sheen",
					base: "var(--color-sp-velvet)",
					className: "pointer-events-none absolute inset-0 size-full"
				}),
				/* @__PURE__ */ m("div", {
					className: "sd-goals",
					"aria-label": h("games.splendorduel.goalLabel"),
					children: [
						/* @__PURE__ */ m("span", {
							className: "sd-goal",
							children: [/* @__PURE__ */ m("span", { children: ["★ ", h("games.splendorduel.goalPoints")] }), /* @__PURE__ */ m("strong", { children: [B?.points ?? 0, /* @__PURE__ */ p("small", { children: "/20" })] })]
						}),
						/* @__PURE__ */ m("span", {
							className: "sd-goal",
							children: [/* @__PURE__ */ m("span", { children: [
								/* @__PURE__ */ p(Ce, { size: 12 }),
								" ",
								h("games.splendorduel.goalCrowns")
							] }), /* @__PURE__ */ m("strong", { children: [B?.crowns ?? 0, /* @__PURE__ */ p("small", { children: "/10" })] })]
						}),
						/* @__PURE__ */ m("span", {
							className: "sd-goal",
							children: [/* @__PURE__ */ m("span", { children: ["◆ ", h("games.splendorduel.goalColor")] }), /* @__PURE__ */ m("strong", { children: [ce, /* @__PURE__ */ p("small", { children: "/10" })] })]
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: "sd-tabletop",
					children: [/* @__PURE__ */ m("div", {
						className: "sd-market",
						children: [Ne.map((t, n) => {
							let r = Pe[n];
							return /* @__PURE__ */ m("div", {
								className: "sd-pyramid-row",
								children: [/* @__PURE__ */ p(Be, {
									tier: r,
									count: e.deckCounts[String(r)],
									selected: k === r,
									disabled: !v || !H,
									onPick: () => ye(r)
								}), t.map((t) => {
									let n = e.pyramid[t];
									return n ? /* @__PURE__ */ p(ze, {
										slot: t,
										id: n,
										active: E?.from === "pyramid" && E.cardId === n,
										affordable: v && _ !== void 0 && W(O(n).cost, _.bonuses, _.tokens) !== null,
										disabled: !v,
										onPick: () => ve(n, "pyramid")
									}, t) : /* @__PURE__ */ p("span", {
										className: "sd-slot-empty",
										children: h("games.splendorduel.soldOut")
									}, t);
								})]
							}, r);
						}), /* @__PURE__ */ p(Ve, { supply: e.supply })]
					}), /* @__PURE__ */ m("div", {
						className: "sd-board-wrap",
						children: [/* @__PURE__ */ m("div", {
							className: "sd-board",
							role: "grid",
							"aria-label": h("games.splendorduel.boardLabel"),
							style: { backgroundImage: `url(${Fe})` },
							children: [w.length > 1 && /* @__PURE__ */ p("svg", {
								className: "sd-board-path",
								viewBox: "0 0 5 5",
								preserveAspectRatio: "none",
								"aria-hidden": !0,
								children: /* @__PURE__ */ p("polyline", { points: w.map((e) => `${e % 5 + .5},${Math.floor(e / 5) + .5}`).join(" ") })
							}), e.board.map((e, t) => /* @__PURE__ */ p(Re, {
								cell: t,
								token: e,
								selectedOrder: w.indexOf(t) + 1,
								legalNext: pe.has(t),
								selectable: v && !I && e !== null && e !== "gold" && (w.length === 0 || w.includes(t) || pe.has(t)),
								privilegeTarget: v && I && e !== null && e !== "gold",
								onPick: () => Y(t)
							}, t))]
						}), /* @__PURE__ */ m("div", {
							className: "sd-side-rail",
							children: [/* @__PURE__ */ p(Ue, {
								royals: e.royals,
								pickable: te,
								onPick: (e) => d({
									type: "chooseRoyal",
									royalId: e
								})
							}), /* @__PURE__ */ p(He, { count: e.bagCount })]
						})]
					})]
				})
			]
		})
	});
}
function Re({ cell: e, token: t, selectedOrder: n, legalNext: i, selectable: a, privilegeTarget: s, onPick: c }) {
	let l = o(), { ref: u } = r(`cell:${e}`), { ref: d } = r(`ctok:${e}`);
	if (t === null) return /* @__PURE__ */ p("span", {
		ref: u,
		className: "sd-cell sd-cell-empty",
		"aria-label": l("games.splendorduel.emptyCellAria"),
		role: "img",
		children: /* @__PURE__ */ p("span", {
			ref: d,
			className: "sd-cell-token",
			"aria-hidden": !0
		})
	});
	let f = l(Me[t]), h = n > 0 ? l("games.splendorduel.cellPickedAria", {
		gem: f,
		n
	}) : l(i ? "games.splendorduel.cellNextAria" : "games.splendorduel.cellAria", { gem: f });
	return /* @__PURE__ */ m("button", {
		ref: u,
		type: "button",
		"aria-label": h,
		"aria-pressed": n > 0,
		disabled: !a && !s,
		onClick: c,
		className: "sd-cell",
		"data-selected": n > 0,
		"data-legal": i,
		"data-pickable": a && n === 0,
		"data-privilege": s,
		children: [
			/* @__PURE__ */ p("span", {
				ref: d,
				className: "sd-cell-token",
				children: /* @__PURE__ */ p(Z, {
					color: t,
					size: 40
				})
			}),
			n > 0 && /* @__PURE__ */ p("span", {
				className: "sd-cell-order",
				"aria-hidden": !0,
				children: n
			}),
			i && /* @__PURE__ */ p("span", {
				className: "sd-cell-next",
				"aria-hidden": !0,
				children: "+"
			})
		]
	});
}
function ze({ slot: e, id: t, active: n, affordable: i, disabled: a, onPick: s }) {
	let c = o(), { ref: l } = r(`pslot:${e}`);
	return /* @__PURE__ */ m("button", {
		ref: l,
		type: "button",
		"aria-label": c("games.splendorduel.cardAria", { tier: O(t).tier }),
		"aria-pressed": n,
		disabled: a,
		onClick: s,
		className: "sd-card-btn",
		"data-selected": n,
		"data-affordable": i && !n,
		children: [/* @__PURE__ */ p(X, {
			id: t,
			w: 54,
			h: 73
		}), i && !n && /* @__PURE__ */ p("span", {
			className: "sd-card-ready",
			"aria-hidden": !0,
			children: "✓"
		})]
	});
}
function Be({ tier: e, count: t, selected: n, disabled: i, onPick: a }) {
	let s = o(), { ref: c } = r(`deck:${e}`);
	return /* @__PURE__ */ p("div", {
		className: "relative flex-none",
		children: t === 0 ? /* @__PURE__ */ p("span", {
			ref: c,
			className: "sd-deck-empty",
			children: s("games.splendorduel.soldOut")
		}) : /* @__PURE__ */ m("button", {
			type: "button",
			"aria-label": s("games.splendorduel.deckAria", {
				tier: e,
				n: t
			}),
			"aria-pressed": n,
			disabled: i,
			onClick: a,
			className: "sd-deck-btn",
			"data-selected": n,
			children: [/* @__PURE__ */ p("span", {
				ref: c,
				className: "sd-deck-face",
				children: /* @__PURE__ */ p(De, {
					tier: e,
					w: 32,
					h: 73
				})
			}), /* @__PURE__ */ p("span", {
				className: "sd-deck-count",
				children: t
			})]
		})
	});
}
function Ve({ supply: e }) {
	let t = o(), { ref: n } = r("supply");
	return /* @__PURE__ */ p("div", {
		ref: n,
		className: "sd-supply",
		"aria-label": t("games.splendorduel.privilegeAria"),
		children: Array.from({ length: 3 }, (t, n) => n < e ? /* @__PURE__ */ p(Oe, { size: 24 }, n) : /* @__PURE__ */ p("span", {
			className: "sd-supply-slot",
			"aria-hidden": !0
		}, n))
	});
}
function He({ count: e }) {
	let t = o(), { ref: n } = r("bag");
	return /* @__PURE__ */ m("div", {
		ref: n,
		className: "sd-bag",
		"aria-label": t("games.splendorduel.bagAria", { n: e }),
		children: [/* @__PURE__ */ m("svg", {
			width: "28",
			height: "28",
			viewBox: "0 0 28 28",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ p("path", {
				d: "M8 8h12l-2.3 4.2 4.4 11H5.9l4.4-11Z",
				fill: "var(--color-sp-deck-3)",
				stroke: "var(--color-ink)",
				strokeWidth: "1.5",
				strokeLinejoin: "round"
			}), /* @__PURE__ */ p("path", {
				d: "M8 8c1-4 3.2-5.5 6-3.5 2.8-2 5-.5 6 3.5M10 12h8",
				fill: "none",
				stroke: "var(--color-sp-brass)",
				strokeWidth: "1.3",
				strokeLinecap: "round"
			})]
		}), /* @__PURE__ */ p("span", {
			className: "font-mono tabular-nums",
			children: e
		})]
	});
}
function Ue({ royals: e, pickable: t, onPick: n }) {
	let r = o();
	return /* @__PURE__ */ p("div", {
		className: "sd-royals",
		children: T.map(({ id: i }) => /* @__PURE__ */ p(We, {
			id: i,
			available: e.includes(i),
			pickable: t,
			label: r("games.splendorduel.royalAria", { points: k(i).points }),
			emptyLabel: r("games.splendorduel.royalClaimed"),
			onPick: () => n(i)
		}, i))
	});
}
function We({ id: e, available: t, pickable: n, label: i, emptyLabel: a, onPick: o }) {
	let { ref: s } = r(`royal:${e}`);
	return /* @__PURE__ */ p("span", {
		ref: s,
		className: "sd-royal-slot",
		children: t ? n ? /* @__PURE__ */ p("button", {
			type: "button",
			"aria-label": i,
			onClick: o,
			className: "sd-royal-btn",
			"data-pickable": "true",
			children: /* @__PURE__ */ p(ke, { id: e })
		}) : /* @__PURE__ */ p("span", {
			className: "inline-flex",
			"aria-label": i,
			role: "img",
			children: /* @__PURE__ */ p(ke, { id: e })
		}) : /* @__PURE__ */ p("span", {
			className: "sd-royal-empty",
			"aria-label": a,
			role: "img",
			children: /* @__PURE__ */ p(Ce, { size: 22 })
		})
	});
}
function Ge({ color: e, count: t, anchor: n, picked: i, onPick: a }) {
	let s = o(), { ref: c } = r(n), l = /* @__PURE__ */ p("span", {
		ref: c,
		className: "sd-tray-token",
		"data-picked": i,
		"data-empty": t === 0,
		children: /* @__PURE__ */ p(Z, {
			color: e,
			count: t,
			size: 32
		})
	});
	return a ? /* @__PURE__ */ p("button", {
		type: "button",
		"aria-label": `${s(Me[e])} ${t}`,
		"aria-pressed": i,
		onClick: a,
		className: "flex min-h-11 min-w-11 items-center justify-center transition-transform active:translate-y-0.5",
		children: l
	}) : /* @__PURE__ */ p("span", {
		className: "inline-flex",
		"aria-label": `${s(Me[e])} ${t}`,
		role: "img",
		children: l
	});
}
function Ke({ id: e, index: t, active: n, affordable: i, disabled: a, onPick: s }) {
	let c = o(), { ref: l } = r(`rsv:${t}`);
	return /* @__PURE__ */ m("button", {
		ref: l,
		type: "button",
		"aria-label": c("games.splendorduel.reservedCardAria", { tier: O(e).tier }),
		"aria-pressed": n,
		disabled: a,
		onClick: s,
		className: "sd-card-btn",
		"data-selected": n,
		"data-affordable": i && !n,
		children: [/* @__PURE__ */ p(X, {
			id: e,
			w: 36,
			h: 49
		}), i && !n && /* @__PURE__ */ p("span", {
			className: "sd-card-ready",
			"aria-hidden": !0,
			children: "✓"
		})]
	});
}
//#endregion
//#region src/games/splendorduel/bot.ts
function qe(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Je = (e) => x.reduce((t, n) => t + e[n], 0);
function Ye(e) {
	let t = [], n = [
		[0, 1],
		[1, 0],
		[1, 1],
		[1, -1]
	];
	for (let r = 0; r < 25; r += 1) {
		if (e[r] === null || e[r] === "gold") continue;
		t.push([r]);
		let i = Math.floor(r / 5), a = r % 5;
		for (let [o, s] of n) {
			let n = [r];
			for (let r = 1; r < 3; r += 1) {
				let c = i + o * r, l = a + s * r;
				if (c < 0 || c > 4 || l < 0 || l > 4) break;
				let u = c * 5 + l;
				if (e[u] === null || e[u] === "gold") break;
				n.push(u), t.push([...n]);
			}
		}
	}
	return t.filter((t) => de(t, e));
}
function Xe(e) {
	let t = O(e), n = t.points * 5 + t.bonusCount * 2.2 + t.crowns * 2.5;
	return t.ability === "extraTurn" ? n += 2 : t.ability === "privilege" ? n += 1.5 : t.ability === "takeSameColor" ? n += 1 : t.ability === "steal" && (n += 1.5), n;
}
function Ze(e, t, n) {
	let r = O(e).cost, i = 0;
	for (let e of S) {
		let a = e === "pearl" ? 0 : t[e];
		i += Math.max(0, (r[e] ?? 0) - a - n[e]);
	}
	return i -= Math.min(n.gold, i), i / 2.5;
}
function Qe(e, t) {
	let n = O(e);
	if (t.points + n.points >= 20 || t.crowns + n.crowns >= 10) return !0;
	if (n.color !== "none" && n.points > 0) {
		let e = n.color === "joker" ? null : n.color;
		if (e && t.bonuses[e] + n.points >= 10 && t.points >= 10) return !0;
	}
	return !1;
}
function $e(e, t, n, r) {
	let i = 0, a = {};
	for (let e of x) a[e] = 0;
	for (let e of n) {
		let t = O(e).cost;
		for (let e of S) {
			let n = e === "pearl" ? 0 : r.bonuses[e];
			a[e] += Math.max(0, (t[e] ?? 0) - n - r.tokens[e]);
		}
	}
	let o = et(e, t);
	for (let e of x) o[e] !== 0 && (i += Math.min(o[e], a[e]) * 1.2 + o[e] * .2);
	(b.map((e) => o[e]).some((e) => e === 3) || o.pearl >= 2) && (i -= 1.6);
	let s = Je(r.tokens) + e.length - 10;
	return s > 0 && (i -= s * 1.5), i;
}
function et(e, t) {
	let n = {
		white: 0,
		blue: 0,
		green: 0,
		red: 0,
		black: 0,
		pearl: 0,
		gold: 0
	};
	for (let r of e) {
		let e = t[r];
		e && (n[e] += 1);
	}
	return n;
}
function tt(e, t) {
	return e.map((e) => ({
		id: e,
		eff: Xe(e) / (Ze(e, t.bonuses, t.tokens) + 1)
	})).sort((e, t) => t.eff - e.eff).slice(0, 3).map((e) => e.id);
}
var nt = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (!r || n.turn !== t.rid || n.phase === "done") return null;
	let i = n.players.find((e) => e.rid !== t.rid);
	if (n.phase === "discard") {
		let e = tt(n.pyramid.filter((e) => e !== null), r), i = (t) => {
			if (t === "gold") return 3;
			let n = 0;
			for (let i of e) {
				let e = O(i).cost, a = t === "pearl" ? 0 : r.bonuses[t];
				n += Math.max(0, (e[t] ?? 0) - a - r.tokens[t]);
			}
			return n;
		}, a = x.flatMap((e) => Array.from({ length: r.tokens[e] }, () => e)), o = [];
		for (let e = 0; e < n.mustDiscard && a.length > 0; e += 1) if (t.difficulty === "weak") o.push(a.splice(crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % a.length, 1)[0]);
		else {
			let e = 0;
			for (let t = 1; t < a.length; t += 1) i(a[t]) < i(a[e]) && (e = t);
			o.push(a.splice(e, 1)[0]);
		}
		return { action: {
			type: "discard",
			tokens: o
		} };
	}
	if (n.phase === "steal") {
		let e = [...b, "pearl"].filter((e) => i.tokens[e] > 0);
		if (e.length === 0) return null;
		if (t.difficulty === "weak") return { action: {
			type: "steal",
			color: qe(e)
		} };
		let a = tt(n.pyramid.filter((e) => e !== null), r), o = e[0], s = -1;
		for (let t of e) {
			let e = t === "pearl" ? .6 : 0;
			for (let n of a) {
				let i = O(n).cost, a = t === "pearl" ? 0 : r.bonuses[t];
				e += Math.max(0, (i[t] ?? 0) - a - r.tokens[t]);
			}
			e > s && (s = e, o = t);
		}
		return { action: {
			type: "steal",
			color: o
		} };
	}
	if (n.phase === "chooseRoyal") {
		let e = {
			extraTurn: 3,
			steal: 2,
			privilege: 1
		}, r = [...n.royals].sort((t, n) => {
			let r = k(t), i = k(n);
			return r.points === i.points ? (i.ability ? e[i.ability] : 0) - (r.ability ? e[r.ability] : 0) : i.points - r.points;
		});
		return { action: {
			type: "chooseRoyal",
			royalId: t.difficulty === "weak" ? qe(n.royals) : r[0]
		} };
	}
	let a = [...r.reservedPublic, ...e.private?.reservedBlind ?? []], o = n.pyramid.filter((e) => e !== null), s = Ye(n.board), c = n.board.includes("gold") && a.length < 3, l = [
		1,
		2,
		3
	].filter((e) => n.deckCounts[String(e)] > 0);
	if (t.difficulty === "weak") {
		let e = [];
		for (let t of o) if (W(O(t).cost, r.bonuses, r.tokens)) {
			if (O(t).color === "joker") {
				let n = b.filter((e) => r.bonuses[e] > 0);
				n.length > 0 && e.push({
					type: "buy",
					cardId: t,
					from: "pyramid",
					attachColor: qe(n)
				});
			} else e.push({
				type: "buy",
				cardId: t,
				from: "pyramid"
			});
		}
		for (let t of a) W(O(t).cost, r.bonuses, r.tokens) && O(t).color !== "joker" && e.push({
			type: "buy",
			cardId: t,
			from: "reserved"
		});
		for (let t of s) e.push({
			type: "take",
			cells: t
		});
		if (c) {
			for (let t of o) e.push({
				type: "reserve",
				cardId: t
			});
			for (let t of l) e.push({
				type: "reserve",
				tier: t
			});
		}
		return n.bagCount > 0 && n.board.includes(null) && e.push({ type: "replenish" }), e.length === 0 ? { action: { type: "pass" } } : { action: qe(e) };
	}
	let u = [...o, ...a], d = tt(u, r), f = [], p = (e) => O(e).color === "joker" ? b.filter((e) => r.bonuses[e] > 0).sort((e, t) => r.bonuses[t] - r.bonuses[e])[0] ?? null : null;
	for (let e of u) {
		if (!W(O(e).cost, r.bonuses, r.tokens)) continue;
		let t = o.includes(e) ? "pyramid" : "reserved";
		if (O(e).color === "joker") {
			let n = p(e);
			if (!n) continue;
			f.push({
				action: {
					type: "buy",
					cardId: e,
					from: t,
					attachColor: n
				},
				score: Qe(e, r) ? 1e6 : 10 + Xe(e)
			});
		} else f.push({
			action: {
				type: "buy",
				cardId: e,
				from: t
			},
			score: Qe(e, r) ? 1e6 : 10 + Xe(e)
		});
	}
	for (let e of s) f.push({
		action: {
			type: "take",
			cells: e
		},
		score: 4 + $e(e, n.board, d, r)
	});
	if (c) {
		for (let e of o) W(O(e).cost, r.bonuses, r.tokens) || f.push({
			action: {
				type: "reserve",
				cardId: e
			},
			score: 2 + Xe(e) * .5 + (d.includes(e) ? 1.5 : 0)
		});
		for (let e of l) f.push({
			action: {
				type: "reserve",
				tier: e
			},
			score: 1.5 + e * .8
		});
	}
	let m = n.board.filter((e) => e !== null && e !== "gold").length;
	if (n.bagCount > 0 && n.board.includes(null) && m <= 6 && f.push({
		action: { type: "replenish" },
		score: (6 - m) * .6 - 1
	}), r.privileges > 0) for (let e of d) {
		if (W(O(e).cost, r.bonuses, r.tokens)) continue;
		let t = O(e).cost, i = 0, a = null;
		for (let e of S) {
			let n = e === "pearl" ? 0 : r.bonuses[e], o = Math.max(0, (t[e] ?? 0) - n - r.tokens[e]);
			o > 0 && (i += o, a = e);
		}
		if (i - Math.min(r.tokens.gold, i) === 1 && a) {
			let t = n.board.findIndex((e) => e === a);
			t >= 0 && f.push({
				action: {
					type: "usePrivilege",
					cell: t
				},
				score: 8 + Xe(e) * .5
			});
		}
	}
	return f.length === 0 ? { action: { type: "pass" } } : (f.sort((e, t) => t.score - e.score), { action: f[0].action });
}, rt = {
	white: "games.splendorduel.gem.white",
	blue: "games.splendorduel.gem.blue",
	green: "games.splendorduel.gem.green",
	red: "games.splendorduel.gem.red",
	black: "games.splendorduel.gem.black",
	pearl: "games.splendorduel.gem.pearl",
	gold: "games.splendorduel.gem.gold"
};
function it(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t, (n.get(t) ?? 0) + 1);
	return [...n].map(([e, n]) => n > 1 ? t("games.splendorduel.hintGemCount", {
		gem: t(rt[e]),
		n
	}) : t(rt[e])).join(" ");
}
var at = (e, t, n) => {
	switch (e.type) {
		case "take": return n("games.splendorduel.hintTake", { gems: it(e.cells.map((e) => t.public.board[e]), n) });
		case "buy": {
			let t = O(e.cardId);
			return n("games.splendorduel.hintBuy", {
				tier: t.tier,
				points: t.points
			});
		}
		case "reserve": return "tier" in e ? n("games.splendorduel.reserveDeckDesc", { tier: e.tier }) : n("games.splendorduel.hintReserve", { tier: O(e.cardId).tier });
		case "usePrivilege": {
			let r = t.public.board[e.cell];
			return n("games.splendorduel.hintPrivilege", { gem: r ? n(rt[r]) : "" });
		}
		case "replenish": return n("games.splendorduel.hintReplenish");
		case "steal": return n("games.splendorduel.hintSteal", { gem: n(rt[e.color]) });
		case "chooseRoyal": return n("games.splendorduel.hintRoyal", { points: k(e.royalId).points });
		case "discard": return n("games.splendorduel.hintDiscard", { gems: it(e.tokens, n) });
		case "pass": return n("games.splendorduel.hintPass");
	}
};
//#endregion
//#region src/games/splendorduel/fx.tsx
function Q(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function ot(e) {
	return typeof e == "string" ? e : null;
}
function $(e, t) {
	return e.anchor(`ctok:${t}`) ?? e.anchor(`cell:${t}`);
}
function st(e, t) {
	return e.anchor(`mtok:${t}`)?.w ?? $(e, 12)?.w ?? 26;
}
function ct(e) {
	return Math.max(22, Math.min(42, e.anchor("supply")?.h ?? 22));
}
var lt = {
	take(e, t) {
		let n = e.data, r = Array.isArray(n?.cells) ? n.cells : [], i = Array.isArray(n?.tokens) ? n.tokens : [], a = Q(t, e.rid);
		if (!r.length || !a) return null;
		let o = r.map((e, n) => {
			let r = $(t, e), o = i[n];
			return !r || !o ? null : /* @__PURE__ */ p(_, {
				from: r,
				to: a,
				ms: 340,
				delay: n * 70,
				children: /* @__PURE__ */ p(Z, {
					color: o,
					size: r.w
				})
			}, `${e}`);
		}).filter(Boolean);
		return o.length ? {
			ms: 340 + r.length * 70,
			node: o
		} : null;
	},
	privilegeUse(e, t) {
		let n = e.data, r = Q(t, e.rid), i = ot(n?.token);
		if (typeof n?.cell != "number" || !r || !i) return null;
		let a = $(t, n.cell), o = t.anchor("supply");
		return a ? {
			ms: 500,
			node: [/* @__PURE__ */ p(_, {
				from: a,
				to: r,
				ms: 340,
				children: /* @__PURE__ */ p(Z, {
					color: i,
					size: a.w
				})
			}, "tok"), ...o ? [/* @__PURE__ */ p(_, {
				from: r,
				to: o,
				ms: 380,
				delay: 120,
				children: /* @__PURE__ */ p(Oe, { size: ct(t) })
			}, "scroll")] : []]
		} : null;
	},
	replenish(e, t) {
		let n = e.data, r = Array.isArray(n?.placements) ? n.placements : [], i = t.anchor("bag");
		if (!r.length || !i) return null;
		let a = r.map((e, n) => {
			let r = $(t, e.cell);
			return r ? /* @__PURE__ */ p(_, {
				from: i,
				to: r,
				ms: 320,
				delay: n * 60,
				children: /* @__PURE__ */ p(Z, {
					color: e.token,
					size: r.w
				})
			}, `${e.cell}`) : null;
		}).filter(Boolean);
		return a.length ? {
			ms: 320 + r.length * 60,
			node: a
		} : null;
	},
	reserve(e, t) {
		let n = e.data, r = Q(t, e.rid);
		if (!n || !r) return null;
		let i = e.secret, a = [];
		if (n.blind === !0 && typeof n.tier == "number") {
			let e = t.anchor(`deck:${n.tier}`);
			if (e) {
				let t = typeof i?.cardId == "string" ? /* @__PURE__ */ p("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ p(X, {
						id: i.cardId,
						w: e.h * 58 / 78,
						h: e.h
					})
				}) : /* @__PURE__ */ p("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ p(De, {
						tier: n.tier ?? 1,
						w: e.w,
						h: e.h
					})
				});
				a.push(/* @__PURE__ */ p(_, {
					from: e,
					to: r,
					ms: 380,
					children: t
				}, "card"));
			}
		} else if (typeof n.cardId == "string" && typeof n.slot == "number") {
			let e = t.anchor(`pslot:${n.slot}`);
			e && a.push(/* @__PURE__ */ p(_, {
				from: e,
				to: r,
				ms: 380,
				children: /* @__PURE__ */ p("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ p(X, {
						id: n.cardId,
						w: e.w,
						h: e.h
					})
				})
			}, "card"));
		}
		if (typeof n.goldCell == "number") {
			let e = $(t, n.goldCell);
			e && a.push(/* @__PURE__ */ p(_, {
				from: e,
				to: r,
				ms: 340,
				delay: 100,
				children: /* @__PURE__ */ p(Z, {
					color: "gold",
					size: e.w
				})
			}, "gold"));
		}
		return a.length ? {
			ms: 560,
			node: a
		} : null;
	},
	buy(e, t) {
		let n = e.data;
		if (typeof n?.cardId != "string") return null;
		let r = Q(t, e.rid);
		if (!r) return null;
		let i = null;
		n.from === "pyramid" && typeof n.slot == "number" ? i = t.anchor(`pslot:${n.slot}`) : n.from === "reserved" && typeof n.rsvIndex == "number" && (i = t.anchor(`rsv:${n.rsvIndex}`));
		let a = i?.w ?? 58, o = i?.h ?? 78;
		i ??= r;
		let s = O(n.cardId).points;
		return {
			ms: 900,
			node: [/* @__PURE__ */ p(_, {
				from: i,
				to: r,
				ms: 420,
				children: /* @__PURE__ */ p("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ p(X, {
						id: n.cardId,
						w: a,
						h: o
					})
				})
			}, "card"), ...s > 0 ? [/* @__PURE__ */ m(g, {
				at: r,
				ms: 900,
				delay: 420,
				children: ["+", s]
			}, "pts")] : []]
		};
	},
	bonusToken(e, t) {
		let n = e.data, r = Q(t, e.rid), i = ot(n?.token);
		if (typeof n?.cell != "number" || !r || !i) return null;
		let a = $(t, n.cell);
		return a ? {
			ms: 400,
			node: /* @__PURE__ */ p(_, {
				from: a,
				to: r,
				ms: 340,
				children: /* @__PURE__ */ p(Z, {
					color: i,
					size: a.w
				})
			})
		} : null;
	},
	steal(e, t) {
		let n = e.data, r = Q(t, e.rid), i = ot(n?.color), a = Q(t, typeof n?.from == "string" ? n.from : void 0);
		return !r || !i || !a ? null : {
			ms: 420,
			node: /* @__PURE__ */ p(_, {
				from: a,
				to: r,
				ms: 360,
				children: /* @__PURE__ */ p(Z, {
					color: i,
					size: st(t, i)
				})
			})
		};
	},
	royal(e, t) {
		let n = e.data, r = Q(t, e.rid);
		if (typeof n?.royalId != "string" || !r) return null;
		let i = t.anchor(`royal:${n.royalId}`) ?? r, a = k(n.royalId).points;
		return {
			ms: 900,
			node: [/* @__PURE__ */ p(_, {
				from: i,
				to: r,
				ms: 420,
				children: /* @__PURE__ */ p("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ p(ke, {
						id: n.royalId,
						w: i.w,
						h: i.h
					})
				})
			}, "royal"), /* @__PURE__ */ m(g, {
				at: r,
				ms: 900,
				delay: 420,
				children: ["+", a]
			}, "pts")]
		};
	},
	privilege(e, t) {
		let n = e.data, r = Q(t, e.rid);
		if (!r) return null;
		let i = n?.from === "opponent" ? Q(t, typeof n.fromRid == "string" ? n.fromRid : void 0) : t.anchor("supply");
		return i ? {
			ms: 420,
			node: /* @__PURE__ */ p(_, {
				from: i,
				to: r,
				ms: 360,
				children: /* @__PURE__ */ p(Oe, { size: ct(t) })
			})
		} : null;
	},
	discard(e, t) {
		let n = e.data, r = Array.isArray(n?.tokens) ? n.tokens : [], i = Q(t, e.rid), a = t.anchor("bag");
		if (!r.length || !i || !a) return null;
		let o = r.map((e, n) => {
			let r = t.anchor(`mtok:${e}`) ?? i;
			return /* @__PURE__ */ p(_, {
				from: r,
				to: a,
				ms: 320,
				delay: n * 60,
				children: /* @__PURE__ */ p(Z, {
					color: e,
					size: st(t, e)
				})
			}, `${e}-${n}`);
		}).filter(Boolean);
		return {
			ms: 320 + r.length * 60,
			node: o
		};
	},
	gameover() {
		return {
			ms: 600,
			node: /* @__PURE__ */ p(h, {
				ms: 600,
				className: "bg-done"
			})
		};
	}
};
//#endregion
//#region src/games/splendorduel/game-over.tsx
function ut({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: s }) {
	let c = o(), l = a((e) => e.locale), u = t, f = i ?? s;
	return /* @__PURE__ */ p("div", {
		className: "sd-result",
		style: { "--sd-result-accent": A.accent },
		children: /* @__PURE__ */ m("div", {
			className: "sd-result-layout",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ p(te, {}),
				/* @__PURE__ */ m("h1", {
					className: "sd-result-title",
					children: [/* @__PURE__ */ p("span", {
						"aria-hidden": !0,
						children: A.icon
					}), c("session.result.title")]
				}),
				/* @__PURE__ */ p("div", {
					className: "sd-result-players",
					children: e.ranking.map((t, i) => {
						let a = u.players.find((e) => e.rid === t);
						if (!a) return null;
						let o = n.find((e) => e.rid === t), s = e.winner.includes(t), f = e.autopilot?.[t], h = [
							{
								key: "goalPoints",
								value: a.points,
								target: 20
							},
							{
								key: "goalCrowns",
								value: a.crowns,
								target: 10
							},
							{
								key: "goalColor",
								value: Math.max(...b.map((e) => a.colorPoints[e])),
								target: 10
							}
						];
						return /* @__PURE__ */ m("section", {
							className: "sd-result-player",
							"data-winner": s,
							children: [
								/* @__PURE__ */ m("header", {
									className: "sd-result-person",
									children: [
										/* @__PURE__ */ p("span", {
											className: "sd-result-avatar",
											style: { backgroundColor: y[(o?.colorIndex ?? 0) % y.length].hex },
											children: o && /* @__PURE__ */ p("img", {
												src: ee[o.avatar % ee.length],
												alt: "",
												draggable: !1
											})
										}),
										/* @__PURE__ */ m("div", {
											className: "sd-result-name",
											children: [/* @__PURE__ */ m("strong", { children: [
												i + 1,
												". ",
												o ? d(o, l) : t,
												t === r && /* @__PURE__ */ p("small", { children: c("lobby.you") })
											] }), f !== void 0 && f > 0 && /* @__PURE__ */ m("small", {
												className: "sd-result-autopilot",
												children: [/* @__PURE__ */ p(v, { size: 14 }), c("session.autopilot.share", { n: Math.round(f * 100) })]
											})]
										}),
										s && /* @__PURE__ */ p("span", {
											className: "sd-result-cup",
											"aria-hidden": !0,
											children: "🏆"
										})
									]
								}),
								/* @__PURE__ */ p("dl", {
									className: "sd-result-goals",
									"aria-label": c("games.splendorduel.goalLabel"),
									children: h.map((e) => /* @__PURE__ */ m("div", {
										"data-reached": s && e.value >= e.target,
										children: [/* @__PURE__ */ m("dt", { children: [e.key === "goalCrowns" && /* @__PURE__ */ p(Ce, { size: 18 }), c(`games.splendorduel.${e.key}`)] }), /* @__PURE__ */ m("dd", { children: [/* @__PURE__ */ p("strong", { children: e.value }), /* @__PURE__ */ m("span", { children: ["/ ", e.target] })] })]
									}, e.key))
								}),
								/* @__PURE__ */ m("section", {
									className: "sd-result-section",
									children: [/* @__PURE__ */ p("h2", { children: c("games.splendorduel.resultTokens") }), /* @__PURE__ */ p("ul", {
										className: "sd-result-tokens",
										children: x.map((e) => /* @__PURE__ */ p("li", {
											"aria-label": c("games.splendorduel.hintGemCount", {
												gem: c(`games.splendorduel.gem.${e}`),
												n: a.tokens[e]
											}),
											"data-empty": a.tokens[e] === 0,
											children: /* @__PURE__ */ p(Z, {
												color: e,
												count: a.tokens[e]
											})
										}, e))
									})]
								}),
								/* @__PURE__ */ m("section", {
									className: "sd-result-section",
									children: [/* @__PURE__ */ p("h2", { children: c("games.splendorduel.resultBonuses") }), /* @__PURE__ */ p("ul", {
										className: "sd-result-color-values",
										children: b.map((e) => /* @__PURE__ */ m("li", {
											"aria-label": c("games.splendorduel.hintGemCount", {
												gem: c(`games.splendorduel.gem.${e}`),
												n: a.bonuses[e]
											}),
											children: [/* @__PURE__ */ p(Ae, {
												fg: Y[e].deep,
												bg: Y[e].bg,
												size: 22
											}), /* @__PURE__ */ p("strong", { children: a.bonuses[e] })]
										}, e))
									})]
								}),
								/* @__PURE__ */ m("section", {
									className: "sd-result-section",
									children: [/* @__PURE__ */ p("h2", { children: c("games.splendorduel.resultColorPoints") }), /* @__PURE__ */ p("ul", {
										className: "sd-result-color-values",
										children: b.map((e) => /* @__PURE__ */ m("li", {
											"aria-label": c("games.splendorduel.hintGemCount", {
												gem: c(`games.splendorduel.gem.${e}`),
												n: a.colorPoints[e]
											}),
											children: [/* @__PURE__ */ p(Ae, {
												fg: Y[e].deep,
												bg: Y[e].bg,
												size: 22
											}), /* @__PURE__ */ p("strong", { children: a.colorPoints[e] })]
										}, e))
									})]
								}),
								/* @__PURE__ */ m("section", {
									className: "sd-result-section sd-result-royals-section",
									children: [/* @__PURE__ */ p("h2", { children: c("games.splendorduel.resultRoyals") }), a.royalsWon.length > 0 ? /* @__PURE__ */ p("ul", {
										className: "sd-result-royals",
										children: a.royalsWon.map((e) => /* @__PURE__ */ p("li", {
											"aria-label": c("games.splendorduel.royalAria", { points: k(e).points }),
											children: /* @__PURE__ */ p(ke, {
												id: e,
												w: 92,
												h: 120
											})
										}, e))
									}) : /* @__PURE__ */ p("p", {
										className: "sd-result-empty",
										children: c("games.splendorduel.resultNoRoyals")
									})]
								})
							]
						}, t);
					})
				}),
				f ? /* @__PURE__ */ m("div", {
					className: "sd-result-controls safe-b",
					children: [i && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base text-white",
						style: { background: A.accent },
						onClick: i,
						children: c("session.result.playAgain")
					}), s && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: c("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ p("p", {
					className: "sd-result-wait safe-b",
					children: c("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/splendorduel/entry.tsx
var dt = {
	definition: J,
	View: je,
	bot: nt,
	describe: at,
	fx: lt,
	OverView: ut,
	locales: {
		zh: {
			name: "璀璨宝石:对决",
			desc: "两人对决:从版图连线取标记、买卡攒折扣,率先达成 20 声望、10 皇冠或单色 10 声望",
			rules: "目标：率先达成以下任一条件的玩家获胜。\n· 获得至少20分声望。\n· 获得至少10个皇冠。\n· 同一种颜色卡牌上的声望合计达到10分。\n准备:\n· 将25枚标记随机放到版图上，填满所有位置。\n· 分别翻开3张三级卡、4张二级卡和5张一级卡，组成卡牌金字塔。\n· 后行动的玩家获得1个特权。\n流程：每回合先执行可选行动，也可以全部跳过；之后必须选择一项主行动。\n可选行动：\n· 归还 1 个特权，从版图拿取 1 枚非黄金标记；可以重复归还特权。\n· 将袋中的标记补充到版图空格，对手获得 1 个特权。\n主行动，三选一：\n· 拿取标记：从版图拿取 1 至 3 枚横向、纵向或斜向连续的非黄金标记。拿取 3 枚同色标记或 2 枚珍珠时，对手获得 1 个特权。\n· 保留卡牌：从版图获得 1 枚黄金，再保留 1 张金字塔中的公开卡牌，或不查看牌面而保留牌堆顶的卡牌。最多同时保留 3 张卡牌。\n· 购买卡牌：从金字塔或自己保留的卡牌中购买 1 张。已有折扣可以抵扣相应费用，黄金可以代替任意颜色的标记支付。\n结算:\n· 购买带有能力的卡牌后，立即结算其能力：获得额外回合、拿取同色标记、获得特权，或拿取对手的标记。\n· 购买变色卡时，必须选择一种自己已经拥有折扣的颜色，将变色卡叠放在该颜色的卡牌上；此后将它视为该颜色。\n· 获得第3个和第6个皇冠时，各选择1张王室卡，并立即结算其能力。\n· 回合结束时，持有的标记超过10枚，须弃置多余的标记，直到只剩10枚。",
			turnYou: "轮到你:取标记 / 扣牌 / 购卡",
			turnWait: "等 {{name}} 行动…",
			stealPrompt: "偷取:从对手处拿 1 枚标记",
			stealWait: "等 {{name}} 挑选偷取的标记…",
			royalPrompt: "皇冠奖励:挑选 1 张王室卡",
			royalWait: "等 {{name}} 挑选王室卡…",
			discardPrompt: "标记超过 10 枚,点选弃置 {{n}} 枚",
			discardWait: "等 {{name}} 弃置超出的标记…",
			extraTurnChip: "额外回合",
			takeIllegal: "须为横、竖或斜向连续不断的非黄金标记",
			takeConfirm: "取 {{n}} 枚",
			usePrivilege: "用特权",
			privilegeMode: "点版图上的 1 枚非黄金标记",
			replenish: "补充版图",
			replenishDesc: "将袋中 {{n}} 枚标记补充到版图,对手获得 1 个特权",
			cancel: "取消",
			free: "免费",
			cantAfford: "标记不够",
			missingTokens: "差 {{n}} 枚",
			buy: "购买",
			reserve: "扣牌",
			reserveDeckDesc: "从 {{tier}} 级牌堆顶盲扣 1 张",
			attachPrompt: "选择变色卡的叠放色:",
			discardConfirm: "弃置",
			pass: "跳过",
			passPrompt: "无可执行的动作且袋子已空,跳过本回合",
			reservedLabel: "扣牌",
			reservedSlot: "扣牌位",
			goalLabel: "胜利条件",
			goalPoints: "声望",
			goalCrowns: "皇冠",
			goalColor: "单色",
			resultTokens: "持有标记",
			resultBonuses: "永久折扣",
			resultColorPoints: "各色声望",
			resultRoyals: "已领取王室",
			resultNoRoyals: "未领取王室卡",
			boardLabel: "取标记版图",
			royalClaimed: "已领取的王室卡位",
			bagLabel: "袋 {{n}}",
			gem: {
				white: "钻石",
				blue: "蓝宝石",
				green: "绿宝石",
				red: "红宝石",
				black: "玛瑙",
				pearl: "珍珠",
				gold: "黄金"
			},
			ability: {
				extraTurn: "额外回合",
				takeSameColor: "取同色标记",
				privilege: "获得特权",
				steal: "偷取标记"
			},
			cellAria: "版图格,{{gem}}",
			cellNextAria: "下一格可取:{{gem}}",
			cellPickedAria: "已选第 {{n}} 格:{{gem}}",
			emptyCellAria: "版图空格",
			cardAria: "{{tier}} 级宝石卡",
			reservedCardAria: "扣下的 {{tier}} 级宝石卡",
			deckAria: "{{tier}} 级牌堆,剩 {{n}} 张",
			royalAria: "王室卡,{{points}} 分",
			privilegeAria: "特权卷轴",
			bagAria: "袋子,内有 {{n}} 枚标记",
			soldOut: "空",
			errNotYourTurn: "还没轮到你",
			errBadTake: "须取横、竖或斜向连续不断的非黄金标记",
			errBadCell: "这格不能取",
			errNoPrivilege: "你没有特权可用",
			errBagEmpty: "袋子是空的,无法补充",
			errReserveFull: "最多扣 3 张牌",
			errNoGold: "版图上没有黄金了",
			errBadCard: "这张卡不在那里了",
			errCantAfford: "标记不够,买不起",
			errNeedAttach: "变色卡必须选择叠放色",
			errBadAttach: "只能叠放在已有折扣的颜色上",
			errBadSteal: "对手没有这种标记",
			errBadRoyal: "不能选这张王室卡",
			errBadDiscard: "弃置的数量或种类不对",
			errBadPass: "还有能做的动作,不能跳过",
			hintTake: "取 {{gems}}",
			hintGemCount: "{{gem}}×{{n}}",
			hintBuy: "购买 {{tier}} 级卡({{points}} 分)",
			hintReserve: "扣下 {{tier}} 级卡",
			hintPrivilege: "用特权取 1 枚{{gem}}",
			hintReplenish: "补充版图",
			hintSteal: "偷取{{gem}}",
			hintRoyal: "挑选王室卡({{points}} 分)",
			hintDiscard: "弃置 {{gems}}",
			hintPass: "跳过回合"
		},
		en: {
			name: "Splendor Duel",
			desc: "Two-player duel: take tokens in lines from the board, buy cards for discounts, race to 20 prestige, 10 crowns, or 10 prestige in one color",
			rules: "Goal: Be the first player to meet any one of these conditions:\n· Have at least 20 prestige points.\n· Have at least 10 crowns.\n· Have at least 10 prestige points on cards of a single color.\nSetup:\n· Randomly place all 25 tokens on the board, filling every space.\n· Reveal 3 level-3 cards, 4 level-2 cards and 5 level-1 cards to form a pyramid.\n· The second player receives 1 Privilege.\nPlay: Take any optional actions first, or skip them all, then choose exactly one mandatory action.\nOptional actions:\n· Return 1 Privilege to take 1 non-Gold token from the board. You may repeat this action.\n· Refill the empty board spaces from the bag. Your opponent receives 1 Privilege.\nMandatory actions:\n· Take tokens: Take 1 to 3 non-Gold tokens in an uninterrupted horizontal, vertical or diagonal line. Taking 3 tokens of one color or 2 Pearls gives your opponent 1 Privilege.\n· Reserve: Take 1 Gold from the board, then reserve 1 face-up pyramid card or the top card of a deck without looking at it. You may have at most 3 reserved cards.\n· Purchase: Buy 1 card from the pyramid or your reserve. Your bonuses reduce the corresponding cost, and Gold can replace a token of any color when paying.\nResolution:\n· After purchasing a card with an ability, resolve it immediately: take an extra turn, take a same-color token, gain a Privilege, or take a token from your opponent.\n· When buying a color-changing card, attach it to cards of a color for which you already have a bonus. It then counts as that color.\n· When you gain your 3rd or 6th crown, choose 1 Royal card and resolve its ability.\n· At the end of your turn, discard excess tokens until you have 10 if you hold more than 10.",
			turnYou: "Your turn: take tokens / reserve / buy",
			turnWait: "Waiting for {{name}}…",
			stealPrompt: "Steal: take 1 token from your opponent",
			stealWait: "Waiting for {{name}} to steal a token…",
			royalPrompt: "Crown reward: choose 1 Royal card",
			royalWait: "Waiting for {{name}} to choose a Royal card…",
			discardPrompt: "Over 10 tokens: tap {{n}} to discard",
			discardWait: "Waiting for {{name}} to discard…",
			extraTurnChip: "Extra turn",
			takeIllegal: "Must be 1–3 non-Gold tokens in an uninterrupted line",
			takeConfirm: "Take {{n}}",
			usePrivilege: "Privilege",
			privilegeMode: "Tap 1 non-Gold token on the board",
			replenish: "Replenish",
			replenishDesc: "Refill the board with {{n}} tokens from the bag; your opponent takes 1 Privilege",
			cancel: "Cancel",
			free: "Free",
			cantAfford: "Not enough tokens",
			missingTokens: "Need {{n}}",
			buy: "Buy",
			reserve: "Reserve",
			reserveDeckDesc: "Reserve the top card of the level {{tier}} deck",
			attachPrompt: "Choose the color to attach to:",
			discardConfirm: "Discard",
			pass: "Pass",
			passPrompt: "No action available and the bag is empty: pass",
			reservedLabel: "Reserved",
			reservedSlot: "Hold",
			goalLabel: "Victory",
			goalPoints: "Prestige",
			goalCrowns: "Crowns",
			goalColor: "One color",
			resultTokens: "Held tokens",
			resultBonuses: "Permanent bonuses",
			resultColorPoints: "Prestige by color",
			resultRoyals: "Claimed Royals",
			resultNoRoyals: "No Royal cards claimed",
			boardLabel: "Token board",
			royalClaimed: "Claimed Royal card slot",
			bagLabel: "Bag {{n}}",
			gem: {
				white: "Diamond",
				blue: "Sapphire",
				green: "Emerald",
				red: "Ruby",
				black: "Onyx",
				pearl: "Pearl",
				gold: "Gold"
			},
			ability: {
				extraTurn: "Extra turn",
				takeSameColor: "Take a same-color token",
				privilege: "Take 1 Privilege",
				steal: "Steal a token"
			},
			cellAria: "Board cell, {{gem}}",
			cellNextAria: "Next legal token: {{gem}}",
			cellPickedAria: "Selected token {{n}}: {{gem}}",
			emptyCellAria: "Empty board cell",
			cardAria: "Level {{tier}} jewel card",
			reservedCardAria: "Reserved level {{tier}} jewel card",
			deckAria: "Level {{tier}} deck, {{n}} left",
			royalAria: "Royal card, {{points}} points",
			privilegeAria: "Privilege scroll",
			bagAria: "Bag with {{n}} tokens",
			soldOut: "Empty",
			errNotYourTurn: "Not your turn",
			errBadTake: "Take non-Gold tokens in an uninterrupted line",
			errBadCell: "Cannot take from this cell",
			errNoPrivilege: "You have no Privilege to spend",
			errBagEmpty: "The bag is empty; cannot replenish",
			errReserveFull: "At most 3 reserved cards",
			errNoGold: "No Gold token left on the board",
			errBadCard: "That card is no longer there",
			errCantAfford: "Not enough tokens to buy",
			errNeedAttach: "A color-changing card needs an attach color",
			errBadAttach: "Attach only to a color you already have a bonus in",
			errBadSteal: "Your opponent has no such token",
			errBadRoyal: "Cannot choose this Royal card",
			errBadDiscard: "Wrong number or kind of tokens to discard",
			errBadPass: "You still have an action available; cannot pass",
			hintTake: "Take {{gems}}",
			hintGemCount: "{{gem}}×{{n}}",
			hintBuy: "Buy the level {{tier}} card ({{points}} pts)",
			hintReserve: "Reserve a level {{tier}} card",
			hintPrivilege: "Spend a Privilege for 1 {{gem}}",
			hintReplenish: "Replenish the board",
			hintSteal: "Steal {{gem}}",
			hintRoyal: "Take the Royal card ({{points}} pts)",
			hintDiscard: "Discard {{gems}}",
			hintPass: "Pass"
		}
	}
};
//#endregion
export { dt as default };
