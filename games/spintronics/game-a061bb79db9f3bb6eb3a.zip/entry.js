import { z as e } from "zod";
import { useCallback as t, useEffect as n, useLayoutEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useT as s } from "@bgparty/sdk/i18n";
import { IconBack as c, IconCheck as l, IconClose as u, IconInfo as d, IconPlay as f, IconRecenter as p, IconTrash as m, IconZoomIn as h, IconZoomOut as ee } from "@bgparty/sdk/icons";
import { useWakeLock as te } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as ne } from "@bgparty/sdk/ui/game-screen";
import { useFrame as g, useThree as _ } from "@react-three/fiber";
import * as v from "three";
import { usePrefersReducedMotion as y } from "@bgparty/sdk/fx/use-reduced-motion";
import { ResilientCanvas as re } from "@bgparty/sdk/three/resilient-canvas";
import { Fragment as b, jsx as x, jsxs as S } from "react/jsx-runtime";
//#region \0bgparty-json:D:/Other/BG/BGParty/src/games/spintronics/challenges.json.mjs
var C = await fetch("games/spintronics/data/challenges.json").then((e) => e.json()), ie = [
	"motor",
	"resistor",
	"junction",
	"button",
	"capacitor",
	"inductor",
	"transistor",
	"level-changer",
	"diode",
	"phonograph"
], ae = {
	motor: "games.spintronics.motor",
	resistor: "games.spintronics.resistor",
	junction: "games.spintronics.junction",
	button: "games.spintronics.button",
	capacitor: "games.spintronics.capacitor",
	inductor: "games.spintronics.inductor",
	transistor: "games.spintronics.transistor",
	"level-changer": "games.spintronics.levelChanger",
	diode: "games.spintronics.diode",
	phonograph: "games.spintronics.phonograph"
};
function w(e) {
	return e.kind === "transistor" ? [0, 2] : e.kind === "level-changer" ? [
		0,
		1,
		2,
		3,
		4
	] : [
		0,
		1,
		2
	];
}
function T(e, t) {
	return e.kind === "junction" ? [
		88,
		58.5,
		29.5
	][t] : e.kind === "transistor" ? t === 2 ? 90.5 : 58.5 : e.kind === "motor" ? 37.5 : e.kind === "inductor" ? 35 : e.kind === "diode" ? 49.5 : e.kind === "level-changer" ? 49 : 58.5;
}
function E(e) {
	return {
		x: e.x + (e.kind === "motor" ? .5 : 0),
		y: e.y - (e.kind === "motor" ? 91.5 : 0)
	};
}
function D(e) {
	return `${e.part}:${e.level}`;
}
function oe(e) {
	return `${e.kind}:${e.value}`;
}
function se(e) {
	return e.kind === "resistor" ? e.value >= 1e3 ? `${e.value / 1e3} kΩ` : `${e.value} Ω` : e.kind === "capacitor" ? `${Number((e.value * 1e3).toPrecision(4))} mF` : e.kind === "inductor" ? `${e.value} H` : e.kind === "motor" ? `${e.value} V` : "";
}
//#endregion
//#region src/games/spintronics/data.ts
var ce = C;
function le(e, t, n, r) {
	let i = n === "button" || n === "transistor", a = e.stock.filter((e) => e.kind === n && (i || e.value === r)).reduce((e, t) => e + t.count, 0);
	if (n === "diode-kit") return a - new Set(t.parts.filter((e) => e.group).map((e) => e.group)).size;
	let o = (e) => e.kind === n && (["button", "transistor"].includes(n) || e.value === r), s = new Set(e.initial.parts.filter(o).map((e) => e.id)), c = t.parts.filter((e) => o(e) && !e.group && !s.has(e.id)).length, l = e.initial.parts.filter((e) => s.has(e.id) && !e.fixed && !t.parts.some((t) => t.id === e.id)).length;
	return a - c + l;
}
function ue(e, t) {
	if (Math.abs(t.x) > 4500 || Math.abs(t.y) > 4500) return !1;
	let n = (e) => e.kind === "motor" ? 94 : Math.max(T(e, 0), T(e, 2)) + 2, r = E(t), i = n(t);
	return !e.parts.some((e) => {
		if (e.id === t.id || t.group && e.group === t.group) return !1;
		let a = E(e), o = n(e);
		return Math.hypot(r.x - a.x, r.y - a.y) < i + o;
	});
}
//#endregion
//#region src/games/spintronics/geometry.ts
var O = Math.PI * 2, k = (e) => (e % O + O) % O;
function A(e, t) {
	let n = e.find((e) => e.id === t.part);
	return n && w(n).includes(t.level) ? {
		...E(n),
		r: T(n, t.level),
		s: t.cw ? 1 : -1
	} : null;
}
function de(e, t) {
	let n = t.x - e.x, r = t.y - e.y, i = Math.hypot(n, r), a = e.s * e.r - t.s * t.r;
	if (i < 1e-6 || Math.abs(a) >= i - 1e-5) return null;
	let o = n / i, s = r / i, c = a / i, l = Math.sqrt(1 - c * c), u = c * o + l * s, d = c * s - l * o;
	return {
		a: {
			x: e.x + e.s * e.r * u,
			y: e.y + e.s * e.r * d
		},
		b: {
			x: t.x + t.s * t.r * u,
			y: t.y + t.s * t.r * d
		}
	};
}
function fe(e, t, n = !0, r) {
	let i = t.map((t) => A(e, t)), a = {
		path: [],
		cumulative: [],
		length: 0,
		valid: !1
	};
	if (!i.length || i.some((e) => !e) || n && i.length < 2) return a;
	let o = i, s = Array.from({ length: n ? i.length : i.length - 1 }, (e, t) => de(o[t], o[(t + 1) % i.length]));
	if (s.some((e) => !e)) return a;
	let c = o.at(-1), l = !n && r && Math.hypot(r.x - c.x, r.y - c.y) > c.r ? de(c, {
		...r,
		r: 0,
		s: 1
	}) : null, u = [], d = (e) => {
		(!u.length || Math.hypot(u.at(-1).x - e.x, u.at(-1).y - e.y) > .001) && u.push(e);
	};
	for (let e = 0; e < o.length; e++) {
		let t = o[e], r = e > 0 ? s[e - 1].b : n ? s.at(-1).b : null, i = s[e]?.a ?? l?.a ?? r;
		if (!i) continue;
		let a = Math.atan2(i.y - t.y, i.x - t.x), c = r ? Math.atan2(r.y - t.y, r.x - t.x) : a, u = t.s > 0 ? k(a - c) : -k(c - a), f = Math.max(1, Math.ceil(Math.abs(u * t.r) / 5));
		for (let e = 0; e <= f; e++) {
			let n = c + u * e / f;
			d({
				x: t.x + t.r * Math.cos(n),
				y: t.y + t.r * Math.sin(n)
			});
		}
		s[e] && d(s[e].b);
	}
	l && d(l.b), n && u.length && d(u[0]);
	let f = [0];
	for (let e = 1; e < u.length; e++) f.push(f[e - 1] + Math.hypot(u[e].x - u[e - 1].x, u[e].y - u[e - 1].y));
	return {
		path: u,
		cumulative: f,
		length: f.at(-1) ?? 0,
		valid: !0
	};
}
function pe(e, t, n, r = []) {
	return r.includes(n.part) || !A(e.parts, n) || t.length && n.level !== t[0].level || e.chains.some((e) => e.connections.some((e) => D(e) === D(n))) ? !1 : t.length ? n.part === t.at(-1).part ? !1 : t.find((e) => e.part === n.part) ? t.length >= 2 && D(n) === D(t[0]) && n.cw === t[0].cw && fe(e.parts, t).valid : fe(e.parts, [...t, n], !1).valid : !0;
}
function j(e, t) {
	let n = t.connections;
	return n.length >= 2 && n.length <= 40 && new Set(n.map((e) => e.part)).size === n.length && n.every((e) => e.level === n[0].level) && fe(e.parts, n).valid;
}
function me(e, t, n) {
	if (e.length < 2) return {
		p: e[0] ?? {
			x: 0,
			y: 0
		},
		angle: 0
	};
	let r = 1, i = e.length - 1;
	for (; r < i;) {
		let e = r + i >>> 1;
		t[e] < n ? r = e + 1 : i = e;
	}
	let a = e[r - 1], o = e[r], s = Math.max(0, Math.min(1, (n - t[r - 1]) / (t[r] - t[r - 1] || 1)));
	return {
		p: {
			x: a.x + (o.x - a.x) * s,
			y: a.y + (o.y - a.y) * s
		},
		angle: Math.atan2(o.y - a.y, o.x - a.x)
	};
}
//#endregion
//#region src/games/spintronics/meta.ts
var he = {
	id: "spintronics",
	tier: "beta",
	nameKey: "games.spintronics.name",
	descKey: "games.spintronics.desc",
	rulesKey: "games.spintronics.rules",
	icon: "⚙️",
	iconImg: "games/spintronics.webp",
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	hotseat: "open",
	mechanics: [
		"route-building",
		"engine-building",
		"deduction"
	],
	interactionTags: [],
	accent: "#537d70",
	releasedAt: "2026-10-23T21:30:00+08:00",
	search: {
		py: "zi xuan dian lu",
		init: "zxdl"
	}
}, M = 1 / 240, N = .003, ge = (e, t) => e.reduce((e, n, r) => e + n * t[r], 0);
function P(e, t) {
	let n = [], r = {};
	for (let t of e.parts) {
		let e = t.kind === "junction" ? [
			0,
			1,
			2
		] : t.kind === "transistor" ? [0, 2] : [0], i = n.length;
		for (let i of e) r[`${t.id}:${i}`] = n.length, n.push({
			part: t,
			level: i,
			ratio: t.kind === "junction" ? [
				1.5,
				1,
				.5
			][i] : T(t, i) / 58.5
		});
		if (e.length === 1) for (let e = 1; e < 5; e++) r[`${t.id}:${e}`] = i;
	}
	let i = [], a = (e) => {
		let t = Array(n.length).fill(0);
		for (let [n, r] of e) t[n] += r;
		i.push(t);
	};
	for (let n of e.parts) {
		let e = r[`${n.id}:0`];
		n.kind === "junction" && a([
			[e, 3],
			[e + 1, -2],
			[e + 2, -1]
		]), (n.kind === "button" && !n.on || t.includes(n.id)) && a([[e, 1]]);
	}
	for (let t of e.chains) {
		let e = t.connections[0], i = r[`${e.part}:${e.level}`];
		if (i !== void 0) for (let o of t.connections.slice(1)) {
			let t = r[`${o.part}:${o.level}`];
			t !== void 0 && a([[i, n[i].ratio * (e.cw ? 1 : -1)], [t, -n[t].ratio * (o.cw ? 1 : -1)]]);
		}
	}
	return {
		rotors: n,
		indices: r,
		rows: i,
		connected: new Set(e.chains.flatMap((e) => e.connections.map((e) => e.part)))
	};
}
function F(e, t) {
	let n = e.map((e) => [...e]), r = [], i = 0;
	for (let e = 0; e < t && i < n.length; e++) {
		let a = i;
		for (let t = i + 1; t < n.length; t++) Math.abs(n[t][e]) > Math.abs(n[a][e]) && (a = t);
		if (Math.abs(n[a][e]) < 1e-9) continue;
		[n[i], n[a]] = [n[a], n[i]];
		let o = n[i][e];
		for (let r = e; r < t; r++) n[i][r] /= o;
		for (let r = 0; r < n.length; r++) if (r !== i) {
			let a = n[r][e];
			for (let o = e; o < t; o++) n[r][o] -= a * n[i][o];
		}
		r.push(e), i++;
	}
	return Array.from({ length: t }, (e, t) => t).filter((e) => !r.includes(e)).map((e) => {
		let a = Array(t).fill(0);
		a[e] = 1;
		for (let t = 0; t < i; t++) a[r[t]] = -n[t][e];
		return a;
	});
}
function _e(e, t) {
	let n = t.length, r = e.map((e, n) => [...e, t[n]]);
	for (let e = 0; e < n; e++) {
		let t = e;
		for (let i = e + 1; i < n; i++) Math.abs(r[i][e]) > Math.abs(r[t][e]) && (t = i);
		[r[e], r[t]] = [r[t], r[e]];
		let i = r[e][e];
		if (!(Math.abs(i) < 1e-16)) {
			for (let t = e; t <= n; t++) r[e][t] /= i;
			for (let t = e + 1; t < n; t++) {
				let i = r[t][e];
				for (let a = e; a <= n; a++) r[t][a] -= i * r[e][a];
			}
		}
	}
	let i = Array(n).fill(0);
	for (let e = n - 1; e >= 0; e--) i[e] = r[e][n] - r[e].slice(e + 1, n).reduce((t, n, r) => t + n * i[e + 1 + r], 0);
	return i;
}
function I(e, t) {
	let n = [], r = [], i = [], a = [];
	return e.rotors.forEach(({ part: o, level: s, ratio: c }, l) => {
		let u = N * c;
		if (n[l] = 2e-6 * c ** 2, r[l] = 2e-7 * c ** 2, i[l] = 0, a[l] = 0, o.kind === "resistor" && (r[l] += o.value * u * u), o.kind === "motor" && o.on && e.connected.has(o.id) && t.energy[o.id] > 0 && !t.shorted.includes(o.id) && (a[l] = o.value * u, r[l] += 12 * u * u), o.kind === "capacitor" && (i[l] = u * u / o.value, r[l] += 2 * u * u), o.kind === "inductor" && (n[l] += o.value * u * u, r[l] += 2 * u * u), o.kind === "phonograph" && (r[l] += 35 * u * u), o.kind === "transistor") {
			if (s === 2) {
				let e = (o.value ? 1 : -1) * Math.PI * 2 * .018;
				i[l] = .01, a[l] = e * i[l], r[l] += 1e-5;
			} else {
				let n = e.indices[`${o.id}:2`], i = o.value ? 1 : -1, a = Math.max(0, Math.min(1, (t.q[n] * i - Math.PI * 2 * .018) / (Math.PI * 2 * .107)));
				r[l] += Math.max(.5, 100 ** ((1 - a) * 2) - 1) * u * u;
			}
		}
		let d = t.hand[`${o.id}:${s}`];
		d !== void 0 && (i[l] += .08, a[l] += .08 * d, r[l] += .008);
	}), {
		mass: n,
		damping: r,
		spring: i,
		force: a
	};
}
function ve(e, t, n) {
	let { mass: r, damping: i, spring: a, force: o } = I(e, t), s = r.map((e, t) => e + M * i[t] + M * M * a[t]), c = r.map((e, n) => e * t.v[n] + M * (o[n] - a[n] * t.q[n])), l = (e) => {
		let t = _e(e.map((t) => e.map((e) => t.reduce((t, n, r) => t + n * s[r] * e[r], 0))), e.map((e) => ge(e, c)));
		return s.map((n, r) => e.reduce((e, n, i) => e + n[r] * t[i], 0));
	}, u = l(n), d = [];
	for (let n = 0; n < e.rotors.length; n++) {
		let { part: r, level: i } = e.rotors[n], a = r.kind === "diode" && u[n] < -1e-8, o = r.value ? 1 : -1, s = r.kind === "transistor" && i === 2 && (t.q[n] * o >= Math.PI / 4 && u[n] * o > 0 || t.q[n] * o <= Math.PI * 2 * .018 && u[n] * o < 0);
		if (a || s) {
			let e = Array(u.length).fill(0);
			e[n] = 1, d.push(e);
		}
	}
	d.length && (u = l(F([...e.rows, ...d], e.rotors.length))), t.v = u, t.q = t.q.map((e, t) => e + M * u[t]), t.time += M;
	for (let { part: n, ratio: r } of e.rotors) if (n.kind === "motor" && n.on && e.connected.has(n.id) && t.energy[n.id] > 0 && !t.shorted.includes(n.id)) {
		let i = e.indices[`${n.id}:0`];
		t.energy[n.id] = Math.max(0, Math.min(12, t.energy[n.id] - n.value * N * r * u[i] * M)), t.overload[n.id] = Math.abs(u[i] * N * r) > .11 ? (t.overload[n.id] ?? 0) + M : 0, t.overload[n.id] > .25 && t.shorted.push(n.id);
	}
}
function ye(e, t) {
	let n = {
		time: t.time,
		angles: {},
		speeds: {},
		volts: {},
		currents: {},
		shorted: [...t.shorted]
	};
	for (let r of [...new Map(e.rotors.map((e) => [e.part.id, e.part])).values()]) {
		let i = [], a = [];
		for (let n = 0; n < 5; n++) {
			let o = e.indices[`${r.id}:${n}`];
			i.push(t.q[o] ?? 0), a.push(t.v[o] ?? 0);
		}
		n.angles[r.id] = i, n.speeds[r.id] = a;
		let o = e.indices[`${r.id}:0`], s = N * e.rotors[o].ratio;
		n.currents[r.id] = t.v[o] * s * 1e3, n.volts[r.id] = r.kind === "capacitor" ? t.q[o] * s / r.value : r.kind === "resistor" ? t.v[o] * s * r.value : r.kind === "motor" ? r.value : 0;
	}
	return n;
}
function be(e) {
	let t = P(e, []), n = {
		q: t.rotors.map(({ part: e, level: t, ratio: n }) => e.kind === "capacitor" ? e.initial * e.value / (N * n) : e.kind === "transistor" && t === 2 ? (e.value ? 1 : -1) * Math.PI * 2 * .018 : 0),
		v: t.rotors.map(() => 0),
		time: 0,
		shorted: [],
		overload: {},
		hand: {},
		energy: Object.fromEntries(e.parts.filter((e) => e.kind === "motor").map((e) => [e.id, 12])),
		pose: {
			time: 0,
			angles: {},
			speeds: {},
			currents: {},
			volts: {},
			shorted: []
		}
	};
	for (let r of e.chains) {
		let i = r.connections.flatMap((t) => {
			let n = e.parts.find((e) => e.id === t.part);
			return n?.kind === "transistor" && t.level === 2 ? [{
				p: n,
				direction: (t.cw ? 1 : -1) * (n.value ? 1 : -1)
			}] : [];
		});
		if (i.some((e) => e.direction > 0) && i.some((e) => e.direction < 0)) for (let { p: e, direction: r } of i) n.q[t.indices[`${e.id}:2`]] = (e.value ? 1 : -1) * (r > 0 ? Math.PI * 2 * .018 : Math.PI / 4);
	}
	return n.pose = ye(t, n), n;
}
function xe(e, t, n = .1) {
	let r = structuredClone(t), i = P(e, r.shorted), a = F(i.rows, i.rotors.length);
	for (let t = 0; t < Math.round(n / M); t++) {
		let t = r.shorted.length;
		ve(i, r, a), t !== r.shorted.length && (i = P(e, r.shorted), a = F(i.rows, i.rotors.length));
	}
	return r.pose = ye(i, r), r;
}
function Se(e, t, n) {
	let r = P(e, t.shorted).indices[n], i = t.hand[n];
	return i === void 0 || r === void 0 ? 0 : .08 * (i - t.q[r]) - .008 * t.v[r];
}
function L(e) {
	let t = P(e, []);
	return F(t.rows, t.rotors.length).length;
}
//#endregion
//#region src/games/spintronics/schema.ts
var R = e.string().min(1).max(40), z = e.number().finite(), Ce = z.min(-5e3).max(5e3), B = e.object({
	part: R,
	level: e.int().min(0).max(4),
	cw: e.boolean()
}), V = e.object({
	id: R,
	kind: e.enum(ie),
	x: Ce,
	y: Ce,
	value: z.min(0).max(1e5),
	fixed: e.boolean(),
	label: e.string().max(10),
	on: e.boolean(),
	initial: z.min(-24).max(24),
	group: R.optional()
}), H = e.object({
	id: R,
	connections: e.array(B).min(2).max(40),
	fixed: e.boolean()
}), we = e.object({
	parts: e.array(V).max(60),
	chains: e.array(H).max(100)
}), U = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("place"),
		kind: e.enum([...ie, "diode-kit"]),
		value: z,
		x: Ce,
		y: Ce
	}),
	e.object({
		type: e.literal("move"),
		id: R,
		x: Ce,
		y: Ce
	}),
	e.object({
		type: e.literal("remove"),
		id: R
	}),
	e.object({
		type: e.literal("chain"),
		connections: e.array(B).min(2).max(40)
	}),
	e.object({
		type: e.literal("extend"),
		id: R,
		connections: e.array(B).min(3).max(40)
	}),
	e.object({
		type: e.literal("unchain"),
		id: R
	}),
	e.object({
		type: e.literal("toggle"),
		id: R
	}),
	e.object({
		type: e.literal("flip"),
		id: R
	}),
	e.object({
		type: e.literal("charge"),
		id: R,
		value: z.min(-24).max(24)
	}),
	e.object({
		type: e.literal("hand"),
		id: R,
		level: e.int().min(0).max(4),
		target: z.min(-1e4).max(1e4).nullable()
	}),
	e.object({
		type: e.literal("power"),
		id: R
	}),
	e.object({ type: e.literal("undo") }),
	e.object({ type: e.literal("reset") }),
	e.object({ type: e.literal("edit") }),
	e.object({ type: e.literal("run") }),
	e.object({ type: e.literal("pause") }),
	e.object({ type: e.literal("check") }),
	e.object({
		type: e.literal("speed"),
		value: e.union([
			e.literal(.5),
			e.literal(1),
			e.literal(2)
		])
	}),
	e.object({
		type: e.literal("goto"),
		n: e.int().min(1).max(160)
	}),
	e.object({
		type: e.literal("tick"),
		now: z
	})
]), Te = e.record(e.string(), z), Ee = e.object({
	time: z,
	angles: e.record(e.string(), e.array(z)),
	speeds: e.record(e.string(), e.array(z)),
	volts: Te,
	currents: Te,
	shorted: e.array(R)
}), De = e.object({
	challenge: e.int().min(1).max(160),
	circuit: we,
	phase: e.enum([
		"build",
		"running",
		"paused",
		"checking",
		"passed",
		"failed",
		"unverified"
	]),
	speed: z,
	pose: Ee.nullable(),
	previousPose: Ee.nullable(),
	revision: e.int(),
	canUndo: e.boolean(),
	check: e.object({
		done: e.int(),
		total: e.int()
	}),
	failure: e.enum([
		"short",
		"goal",
		"missing",
		"unsupported"
	]).nullable()
}), Oe = e.object({}), W = /* @__PURE__ */ new Set([
	73,
	74,
	75,
	76,
	87,
	88,
	89,
	90,
	91,
	92,
	93,
	96,
	97,
	98,
	99,
	100,
	101,
	102,
	103,
	104,
	105,
	106,
	107,
	108,
	112,
	113,
	117,
	118,
	119,
	120,
	121,
	122,
	123,
	143,
	144
]), G = /* @__PURE__ */ new Set([
	77,
	78,
	128,
	129,
	130,
	131,
	133,
	139,
	140,
	145,
	146,
	157,
	159
]);
function K(e) {
	let t = e.reference.parts.filter((e) => e.kind === "button").sort((e, t) => e.label.localeCompare(t.label));
	if (W.has(e.n) || G.has(e.n)) {
		let n = G.has(e.n), r = e.reference.parts.some((e) => e.kind === "inductor") ? .25 : 1.5;
		return [
			0,
			1,
			0,
			-1,
			.4,
			0
		].map((i) => ({
			seconds: r,
			switches: t.map(() => !0),
			hand: {
				label: n ? e.n === 140 ? "T2" : "T1" : "S1",
				level: n ? 2 : 0,
				value: n ? i > 0 ? Math.PI / 4 : Math.PI * 2 * .018 : i * 2
			}
		}));
	}
	if (e.n === 160) return [{
		seconds: 4,
		switches: [!0]
	}, {
		seconds: 4,
		switches: [!0],
		outage: !0
	}];
	if (!t.length) return [{
		seconds: 6,
		switches: []
	}];
	let n = t.filter((e) => !e.value), r = Math.min(8, 2 ** n.length), i = [];
	for (let a = 0; a < r * 2; a++) {
		let o = a % r;
		if ([
			35,
			36,
			66
		].includes(e.n) && o === 3) continue;
		let s = t.map((e) => e.value ? !0 : !!(o & 1 << n.indexOf(e))), c = e.reference.parts.some((e) => e.kind === "inductor");
		i.push({
			seconds: c && s.some(Boolean) ? .25 : 2,
			switches: s
		});
	}
	return i;
}
function ke(e, t, n) {
	if (e.parts.filter((e) => e.kind === "button").sort((e, t) => e.label.localeCompare(t.label)).forEach((e, t) => {
		e.on = n.switches[t] ?? !0;
	}), n.outage) {
		let t = e.parts.find((e) => e.kind === "motor");
		t && (t.on = !1);
	}
	if (t.hand = {}, n.hand) {
		let r = n.hand, i = e.parts.find((e) => e.label === r.label);
		i && (i.on = !0, t.hand[`${i.id}:${r.level}`] = r.value * (i.kind === "transistor" && !i.value ? -1 : 1));
	}
}
function Ae(e, t) {
	let n = structuredClone(t), r = structuredClone(e.reference);
	return n.parts.forEach((e) => {
		e.initial = 0;
	}), r.parts.forEach((e) => {
		e.initial = 0;
	}), {
		candidate: n,
		reference: r,
		a: be(n),
		b: be(r),
		step: 0,
		elapsed: 0,
		samples: 0,
		actual: {},
		expected: {}
	};
}
var je = (e) => K(e).reduce((e, t) => e + Math.ceil(t.seconds / .25), 0), Me = (e, t) => e.kind === "capacitor" ? t.pose.volts[e.id] : e.kind === "transistor" ? t.pose.angles[e.id]?.[2] : t.pose.currents[e.id], Ne = (e) => [
	"resistor",
	"capacitor",
	"inductor",
	"phonograph",
	"transistor"
].includes(e.kind);
function Pe(e, t) {
	let n = structuredClone(t), r = K(e)[n.step];
	if (!r) return n;
	ke(n.candidate, n.a, r), ke(n.reference, n.b, r);
	for (let t = 0; t < 5; t++) {
		n.a = xe(n.candidate, n.a, .05), n.b = xe(n.reference, n.b, .05);
		for (let [t, r, i] of [[
			n.candidate,
			n.a,
			n.actual
		], [
			n.reference,
			n.b,
			n.expected
		]]) {
			for (let e of t.parts.filter(Ne)) (i[e.id] ??= []).push(Me(e, r) ?? 0);
			if (e.n === 54) for (let e of t.parts.filter((e) => e.kind === "motor")) (i[`battery:${e.id}`] ??= []).push(r.pose.currents[e.id] ?? 0);
			let n = Object.keys(r.hand)[0];
			(i.hand ??= []).push(n ? Se(t, r, n) : 0);
		}
	}
	return n.samples++, n.elapsed += .25, n.elapsed >= r.seconds - .001 && (n.step++, n.elapsed = 0), n;
}
var q = (e, t) => {
	let n = t.reduce((e, t) => e + t * t, 0);
	return Math.sqrt(t.reduce((t, n, r) => t + ((e[r] ?? 0) - n) ** 2, 0) / Math.max(4e-4 * t.length, n));
};
function Fe(e, t) {
	if (!t.candidate.chains.length || t.candidate.parts.length < 2 || [
		141,
		146,
		159
	].includes(e.n) && e.initial.parts.some((e) => e.kind === "capacitor" && !e.fixed && t.candidate.parts.some((t) => t.id === e.id))) return "failed";
	if (e.n === 134) {
		let e = t.candidate.parts.find((e) => e.label === "T1"), n = t.candidate.parts.find((e) => e.label === "S1");
		if (e && n && t.candidate.chains.some((t) => t.connections.some((t) => t.part === e.id && t.level === 2) && t.connections.some((e) => e.part === n.id))) return "failed";
	}
	if (t.a.shorted.length && ![
		54,
		65,
		151
	].includes(e.n)) return "failed";
	let n = t.candidate.parts.filter((e) => e.kind === "resistor"), r = n.map((e) => t.a.pose.currents[e.id] ?? 0);
	if (e.n >= 3 && e.n <= 5) return n.length === 2 && (e.n === 3 ? r.every((e) => e > .05) : e.n === 4 ? r[0] * r[1] < -.0025 : r.every((e) => e < -.05)) ? "passed" : "failed";
	if (e.n <= 2) {
		let n = e.initial.parts.find((e) => e.kind === "resistor"), r = Math.abs(t.a.pose.currents[n.id] ?? 0), i = 6e3 / (n.value + 12);
		return r > .02 && r < i * .9 ? "passed" : "failed";
	}
	if (e.n === 43 || e.n === 45 || e.n === 46 || e.n === 61 || e.n === 62 || e.n === 150) {
		let n = t.candidate.parts.find((e) => e.kind === "capacitor"), r = n && t.a.pose.volts[n.id], i = e.n === 43 ? [-6.5, -5.5] : e.n === 45 ? [1.95, 3.05] : e.n === 46 ? [4.45, 5.55] : e.n === 61 || e.n === 150 ? [11, 13] : [2.7, 3.3];
		return r !== void 0 && r >= i[0] && r <= i[1] ? "passed" : "failed";
	}
	if (e.n === 65) return n.length === 3 && L(t.candidate) === 0 ? "passed" : "failed";
	if (e.n === 54) {
		let e = t.candidate.parts.find((e) => e.kind === "motor");
		return e && t.candidate.chains.some((t) => t.connections.some((t) => t.part === e.id)) && (t.actual[`battery:${e.id}`] ?? []).every((e) => Math.abs(e) < .02) ? "passed" : "failed";
	}
	if (e.n === 151) {
		let e = t.candidate.parts.filter((e) => e.kind === "motor"), n = new Set(e.slice(0, 1).map((e) => e.id));
		for (let e = 0; e < t.candidate.parts.length; e++) for (let e of t.candidate.chains) e.connections.some((e) => n.has(e.part)) && e.connections.forEach((e) => n.add(e.part));
		let r = {
			parts: t.candidate.parts.filter((e) => n.has(e.id)),
			chains: t.candidate.chains.filter((e) => e.connections.every((e) => n.has(e.part)))
		};
		return e.length === 2 && e.every((e) => n.has(e.id) && Math.abs(t.a.pose.currents[e.id]) < .05) && L(r) === 1 && !t.a.shorted.length ? "passed" : "failed";
	}
	let i = t.reference.parts.filter(Ne);
	if (!i.length) return "unverified";
	let a = /* @__PURE__ */ new Set();
	for (let n of i) {
		let r = e.initial.parts.find((e) => e.id === n.id && e.fixed), i = t.candidate.parts.filter((e) => !a.has(e.id) && e.kind === n.kind && Math.abs(e.value - n.value) < .001 && (!r || e.id === r.id)).map((e) => ({
			p: e,
			error: q(t.actual[e.id] ?? [], t.expected[n.id] ?? [])
		})).sort((e, t) => e.error - t.error);
		if (!i.length || i[0].error > .18) return "failed";
		a.add(i[0].p.id);
	}
	return W.has(e.n) && q(t.actual.hand ?? [], t.expected.hand ?? []) > .15 ? "failed" : "passed";
}
//#endregion
//#region src/games/spintronics/rules.ts
var J = () => ({ code: "games.spintronics.invalid" });
function Y(e) {
	e.history.push(structuredClone(e.circuit)), e.history.length > 60 && e.history.shift();
}
function Ie(e) {
	e.phase = "build", e.machine = null, e.previousPose = null, e.check = null, e.failure = null;
}
function Le(e, t, n = !1) {
	e.challenge = t, e.circuit = structuredClone(!n && e.saved[t] || ce[t - 1].initial), e.history = [], Ie(e);
}
var Re = {
	motor: "B",
	resistor: "R",
	junction: "J",
	button: "S",
	capacitor: "C",
	inductor: "L",
	transistor: "T",
	"level-changer": "X",
	diode: "D",
	phonograph: "A"
};
function ze(e, t, n, r, i, a) {
	let o = 1;
	for (; e.circuit.parts.some((e) => e.label === `${Re[t]}${o}`);) o++;
	let s = {
		id: `u${++e.serial}`,
		kind: t,
		value: n,
		x: r,
		y: i,
		fixed: !1,
		label: `${Re[t]}${o}`,
		on: !0,
		initial: 0,
		...a ? { group: a } : {}
	};
	return e.circuit.parts.push(s), s;
}
var Be = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: he,
	schemas: {
		action: U,
		publicView: De,
		privateView: Oe
	},
	setup(e, t) {
		let n = {
			host: t[0],
			challenge: 1,
			circuit: {
				parts: [],
				chains: []
			},
			phase: "build",
			speed: 1,
			serial: 0,
			revision: 0,
			history: [],
			saved: {},
			machine: null,
			previousPose: null,
			check: null,
			failure: null
		};
		return Le(n, 1), { state: n };
	},
	reduce(e, t, n) {
		if (t.type === "tick" ? n.by !== "$engine" : n.by !== e.host) return J();
		let r = structuredClone(e), i = ce[r.challenge - 1], a = "id" in t ? r.circuit.parts.find((e) => e.id === t.id) : void 0;
		switch (t.type) {
			case "tick":
				if (r.phase === "checking" && r.check) r.check = Pe(i, r.check), r.machine = r.check.a, r.check.step >= K(i).length && (r.phase = Fe(i, r.check), r.failure = r.phase === "passed" ? null : r.phase === "unverified" ? "unsupported" : r.machine.shorted.length ? "short" : "goal");
				else if (r.phase === "running" && r.machine) r.previousPose = r.machine.pose, r.machine = xe(r.circuit, r.machine, .1 * r.speed);
				else return { state: e };
				break;
			case "goto":
				r.saved[r.challenge] = r.circuit, Le(r, t.n);
				break;
			case "reset":
				Le(r, r.challenge, !0);
				break;
			case "edit":
				Ie(r);
				break;
			case "speed":
				r.speed = t.value;
				break;
			case "pause":
				if (r.phase !== "running") return J();
				r.phase = "paused", r.machine && (r.machine.hand = {});
				break;
			case "run":
				r.phase !== "paused" && (r.machine = be(r.circuit), r.previousPose = null), r.phase = "running", r.failure = null;
				break;
			case "check":
				r.check = Ae(i, r.circuit), r.phase = "checking", r.failure = null, r.previousPose = null;
				break;
			case "toggle":
				if (!a || a.kind !== "button" || r.phase === "checking") return J();
				r.phase === "build" && Y(r), a.on = !a.on;
				break;
			case "power":
				if (!a || a.kind !== "motor" || r.phase === "checking") return J();
				a.on = !a.on, r.machine && (r.machine.shorted = r.machine.shorted.filter((e) => e !== a.id));
				break;
			case "hand":
				if (!a || r.phase !== "running" || !r.machine || !w(a).includes(t.level)) return J();
				a.kind === "button" && (a.on = !0), t.target === null ? delete r.machine.hand[D({
					part: a.id,
					level: a.kind === "transistor" ? t.level : 0,
					cw: !0
				})] : r.machine.hand[`${a.id}:${a.kind === "transistor" ? t.level : 0}`] = t.target;
				break;
			default:
				if (r.phase !== "build") return J();
				switch (t.type) {
					case "undo": {
						let e = r.history.pop();
						e && (r.circuit = e);
						break;
					}
					case "place": {
						if (r.circuit.parts.length >= Math.min(58, i.restrictions.maxParts ?? 58) || le(i, r.circuit, t.kind, t.value) <= 0) return J();
						let e = {
							id: "probe",
							kind: t.kind === "diode-kit" ? "junction" : t.kind,
							value: t.value,
							x: t.x,
							y: t.y,
							fixed: !1,
							label: "",
							on: !0,
							initial: 0
						};
						if (!ue(r.circuit, e) || t.kind === "diode-kit" && !ue(r.circuit, {
							...e,
							kind: "transistor",
							y: t.y - 260
						})) return J();
						if (Y(r), t.kind === "diode-kit") {
							let e = `k${++r.serial}`, n = ze(r, "junction", 0, t.x, t.y, e), i = ze(r, "transistor", 1, t.x, t.y - 260, e);
							r.circuit.chains.push({
								id: `${e}a`,
								fixed: !0,
								connections: [{
									part: n.id,
									level: 2,
									cw: !0
								}, {
									part: i.id,
									level: 2,
									cw: !0
								}]
							}, {
								id: `${e}b`,
								fixed: !0,
								connections: [{
									part: n.id,
									level: 0,
									cw: !0
								}, {
									part: i.id,
									level: 0,
									cw: !0
								}]
							});
						} else ze(r, t.kind, t.value, t.x, t.y);
						break;
					}
					case "move": {
						if (!a || a.fixed) return J();
						let e = r.circuit.parts.filter((e) => e.id === a.id || a.group && a.group === e.group), n = t.x - a.x, i = t.y - a.y, o = r.circuit.parts.map((t) => e.includes(t) ? {
							...t,
							x: t.x + n,
							y: t.y + i
						} : t), s = {
							...r.circuit,
							parts: o
						};
						if (o.filter((t) => e.some((e) => e.id === t.id)).some((e) => !ue(s, e)) || s.chains.some((e) => !j(s, e))) return J();
						Y(r), r.circuit = s;
						break;
					}
					case "remove": {
						if (!a || a.fixed) return J();
						let e = r.circuit.parts.filter((e) => e.id === a.id || a.group && a.group === e.group).map((e) => e.id);
						if (r.circuit.chains.some((t) => t.fixed && t.connections.some((t) => e.includes(t.part)) && !t.id.startsWith(a.group ?? "\0"))) return J();
						Y(r), r.circuit.parts = r.circuit.parts.filter((t) => !e.includes(t.id)), r.circuit.chains = r.circuit.chains.filter((t) => !t.connections.some((t) => e.includes(t.part)));
						break;
					}
					case "chain": {
						let e = {
							id: `c${r.serial + 1}`,
							connections: t.connections,
							fixed: !1
						};
						if (!j(r.circuit, e) || r.circuit.chains.filter((e) => !e.fixed).length >= i.loops + i.initial.chains.filter((e) => !e.fixed).length || t.connections.some((e, n) => !pe(r.circuit, t.connections.slice(0, n), e, i.restrictions.noConnect)) || i.restrictions.lockedLevels?.some((e) => t.connections.some((t) => D(e) === D(t)))) return J();
						Y(r), r.serial++, r.circuit.chains.push(e);
						break;
					}
					case "extend": {
						let e = r.circuit.chains.find((e) => e.id === t.id);
						if (!e || e.id.startsWith("k") || t.connections.length <= e.connections.length || !e.connections.every((e) => t.connections.some((t) => D(t) === D(e) && t.cw === e.cw))) return J();
						let n = {
							...r.circuit,
							chains: r.circuit.chains.filter((t) => t !== e)
						}, a = t.connections.filter((t) => !e.connections.some((e) => D(e) === D(t)));
						if (!j(n, {
							...e,
							connections: t.connections
						}) || a.some((e) => !pe(n, [], e, i.restrictions.noConnect)) || i.restrictions.lockedLevels?.some((e) => a.some((t) => D(e) === D(t)))) return J();
						Y(r), e.connections = t.connections;
						break;
					}
					case "unchain": {
						let e = r.circuit.chains.find((e) => e.id === t.id);
						if (!e || e.fixed) return J();
						Y(r), r.circuit.chains = r.circuit.chains.filter((e) => e.id !== t.id);
						break;
					}
					case "flip":
						if (!a || a.kind !== "transistor" || a.fixed) return J();
						Y(r), a.value = +!a.value;
						break;
					case "charge":
						if (!a || a.kind !== "capacitor") return J();
						Y(r), a.initial = t.value;
				}
		}
		return r.revision++, { state: r };
	},
	viewFor(e) {
		return { public: {
			challenge: e.challenge,
			circuit: e.circuit,
			phase: e.phase,
			speed: e.speed,
			pose: e.machine?.pose ?? null,
			previousPose: e.previousPose,
			revision: e.revision,
			canUndo: e.history.length > 0,
			check: {
				done: e.check?.samples ?? 0,
				total: je(ce[e.challenge - 1])
			},
			failure: e.failure
		} };
	},
	status: () => ({ phase: "play" }),
	nextTickIn: (e) => e.phase === "running" || e.phase === "checking" ? 100 : null
}, X = {
	brass: "#bd9957",
	steel: "#a7b19b",
	ink: "#354339",
	board: "#c5d0b4",
	edge: "#93a48c",
	cream: "#efe3bd",
	resistor: "#504d40",
	junction: "#376b8c",
	button: "#ba5044",
	capacitor: "#ecedd8",
	inductor: "#39806a",
	transistor: "#9b527d",
	"level-changer": "#789667",
	diode: "#687a67",
	phonograph: "#745c84",
	motor: "#b59e67",
	chain: "#5a5748",
	movable: "#267caa",
	highlight: "#24996f"
}, Ve = /* @__PURE__ */ new Map(), Z = /* @__PURE__ */ new Map(), He = (e, t = .3) => {
	let n = `${e}:${t}`;
	return Ve.has(n) || Ve.set(n, new v.MeshStandardMaterial({
		color: e,
		roughness: .55,
		metalness: t
	})), Ve.get(n);
};
function Ue(e, t, n, r = 0) {
	let i = new v.Mesh(t, He(n));
	return i.position.z = r, i.castShadow = !0, i.receiveShadow = !0, e.add(i), i;
}
function We(e, t, n, r, i) {
	let a = `d:${t}:${r}`;
	return Z.has(a) || Z.set(a, new v.CylinderGeometry(t, t, r, 48).rotateX(Math.PI / 2)), Ue(e, Z.get(a), i, n + r / 2);
}
function Ge(e, t, n, r, i = 1) {
	let a = `r:${t}:${i}`;
	return Z.has(a) || Z.set(a, new v.TorusGeometry(t, i, 6, 64)), Ue(e, Z.get(a), r, n);
}
function Ke(e, t, n, r, i = 3) {
	We(e, i, r, 2, X.steel).position.set(t, n, r + 1), Ue(e, new v.BoxGeometry(i * 1.4, .85, .3), X.ink, r + 2.1).position.set(t, n, r + 2.1);
}
function qe(e) {
	let t = `g:${e}`;
	if (!Z.has(t)) {
		let n = Math.round(e * .45) + 6, r = new v.Shape();
		for (let t = 0; t < n; t++) for (let [i, a] of [
			[.02, .95],
			[.2, 1.03],
			[.63, 1.03],
			[.82, .95]
		]) {
			let o = (t + i) * Math.PI * 2 / n, s = e * a * Math.cos(o), c = e * a * Math.sin(o);
			t === 0 && i === .02 ? r.moveTo(s, c) : r.lineTo(s, c);
		}
		r.closePath(), Z.set(t, new v.ExtrudeGeometry(r, {
			depth: 7,
			bevelEnabled: !0,
			bevelSize: .6,
			bevelThickness: .6,
			bevelSegments: 1,
			steps: 1
		}));
	}
	return Z.get(t);
}
function Je(e, t, n, r) {
	let i = new v.Group();
	i.position.z = n, e.add(i), Ue(i, qe(t), r), Ge(i, t * .77, 7.8, X.brass, .8);
	for (let e = 0; e < 5; e++) {
		let n = e * Math.PI * 2 / 5;
		We(i, t * .045, 8, .6, X.ink).position.set(t * .64 * Math.cos(n), t * .64 * Math.sin(n), 8.4);
	}
	return i;
}
var Q = [
	22,
	44,
	66,
	88,
	110
];
function Ye(e) {
	let t = new v.Group(), n = [], r = [], i = E(e), a = e.kind === "junction" ? 99 : e.kind === "transistor" ? 103 : 72;
	We(t, a, 2, 8, X.edge).scale.set(1, 1, 1), We(t, a - 4, 10, 4, X.cream);
	for (let e of [
		Math.PI / 4,
		Math.PI * 3 / 4,
		Math.PI * 5 / 4,
		Math.PI * 7 / 4
	]) Ke(t, (a - 12) * Math.cos(e), (a - 12) * Math.sin(e), 15, 2.8);
	if (e.kind === "motor") {
		We(t, 90, 0, 12, X.cream).position.set(-.5, -91.5, 6), We(t, 67, 13, 8, X.brass).position.set(-.5, -91.5, 17);
		for (let e = 0; e < 7; e++) Ge(t, 12 + e * 7, 22, X.ink, .65).position.set(-.5, -91.5, 22);
		for (let [e, n, r] of [
			[
				-29,
				-50,
				27
			],
			[
				38,
				-57,
				23
			],
			[
				7,
				-110,
				42
			]
		]) {
			let i = Je(t, r, 24, X.brass);
			i.position.x = e, i.position.y = n;
		}
	}
	for (let r of w(e)) {
		let i = T(e, r), a = Q[r];
		We(t, Math.max(13, i * .62), a - 7, 8, e.kind === "junction" ? "#31556a" : X.steel);
		let o = Je(t, i, a, X[e.kind]);
		if (n.push({
			level: r,
			node: o
		}), e.kind === "inductor") for (let e = 0; e < 3; e++) {
			let t = e * Math.PI * 2 / 3, n = Ue(o, new v.BoxGeometry(78, 14, 10), X.brass, 5);
			n.position.set(Math.cos(t) * 60, Math.sin(t) * 60, 5), n.rotation.z = t;
		}
	}
	let o = Q[w(e).at(-1)] + 11;
	if (We(t, e.kind === "capacitor" ? 50 : e.kind === "resistor" ? 38 : 15, o, 5, X.cream), [
		"capacitor",
		"resistor",
		"motor"
	].includes(e.kind)) {
		let n = document.createElement("canvas");
		n.width = 256, n.height = 256;
		let i = n.getContext("2d");
		if (i.fillStyle = X.cream, i.fillRect(0, 0, 256, 256), i.strokeStyle = X.brass, i.lineWidth = 4, i.beginPath(), i.arc(128, 128, 115, 0, Math.PI * 2), i.stroke(), i.fillStyle = X.ink, i.textAlign = "center", i.textBaseline = "middle", i.font = "bold 43px Georgia", i.fillText(se(e), 128, 128), e.kind === "capacitor") {
			i.font = "17px system-ui";
			for (let e = -9; e <= 9; e++) {
				let t = e / 10 * Math.PI - Math.PI / 2;
				i.fillText(String(e), 128 + Math.cos(t) * 90, 128 - Math.sin(t) * 90);
			}
		}
		let a = new v.CanvasTexture(n);
		a.colorSpace = v.SRGBColorSpace, r.push(a);
		let s = new v.Mesh(new v.CircleGeometry(e.kind === "capacitor" ? 49 : 36, 48), new v.MeshStandardMaterial({
			map: a,
			roughness: .85
		}));
		s.position.z = o + 5.3, t.add(s);
	}
	if (e.kind === "capacitor" || e.kind === "transistor" || e.kind === "button") {
		let r = new v.Group();
		r.position.z = o + 7;
		let i = Ue(r, new v.BoxGeometry(4, e.kind === "capacitor" ? 72 : 38, 3), e.kind === "button" ? X.button : X.ink);
		i.position.y = e.kind === "capacitor" ? 20 : 8, t.add(r), n.push({
			level: e.kind === "transistor" ? 2 : 0,
			node: r
		});
	}
	if (e.kind === "phonograph") {
		let e = Ue(t, new v.ConeGeometry(58, 95, 40, 1, !0), X.brass, 70);
		e.rotation.x = Math.PI * .64, e.position.set(16, 20, 95), Ge(t, 58, 120, X.brass, 2).rotation.x = -.45;
	}
	Ke(t, 0, 0, o + 7, 4), t.position.set(i.x, -i.y, 0);
	let s = [];
	return t.traverse((e) => {
		e instanceof v.Mesh && ![...Z.values()].includes(e.geometry) && s.push(e.geometry);
	}), {
		root: t,
		rotors: n,
		unique: s,
		textures: r
	};
}
function Xe(e) {
	e.unique.forEach((e) => e.dispose()), e.textures.forEach((e) => e.dispose()), e.root.traverse((e) => {
		e instanceof v.Mesh && ![...Ve.values()].includes(e.material) && e.material.dispose();
	});
}
//#endregion
//#region src/games/spintronics/board3d.tsx
function Ze({ part: e, pose: t, previousPose: o, running: s, speed: c }) {
	let l = i(() => Ye(e), [e]), u = y(), d = a(0), f = a(l);
	return r(() => {
		d.current = performance.now(), f.current = l;
	}, [t, l]), n(() => () => Xe(l), [l]), g(() => {
		let n = s && !u ? Math.min(1, (performance.now() - d.current) / 100) : 1;
		for (let { level: r, node: i } of f.current.rotors) {
			let a = t?.angles[e.id]?.[r] ?? (e.kind === "capacitor" ? e.initial * e.value / .003 : 0), s = o?.angles[e.id]?.[r] ?? a;
			i.rotation.set(0, 0, -(s + (a - s) * n)), e.kind === "button" && i === f.current.rotors.at(-1)?.node && i.rotation.set(0, 0, e.on ? -.6 : .6);
		}
	}), /* @__PURE__ */ x("primitive", {
		object: l.root,
		dispose: null
	});
}
var $ = new v.Object3D();
function Qe({ path: e, level: t, color: n, pose: i, previousPose: o, running: s, circuit: c, first: l }) {
	let u = a(null), d = a(null), f = a(null), p = a(0), m = y();
	r(() => {
		p.current = performance.now();
	}, [i]);
	let h = Math.max(1, Math.min(1800, Math.round(e.length / 8)));
	return g(() => {
		let n = l && c.parts.find((e) => e.id === l.part), r = n && l ? i?.angles[n.id]?.[l.level] ?? 0 : 0, a = n && l ? o?.angles[n.id]?.[l.level] ?? r : r, ee = s && !m ? Math.min(1, (performance.now() - p.current) / 100) : 1, te = n && l ? (a + (r - a) * ee) * T(n, l.level) * (l.cw ? 1 : -1) : 0;
		if (!(!e.valid || e.length < .01 || !u.current || !d.current) && (f.current?.path !== e || f.current.offset !== te || f.current.mesh !== u.current)) {
			f.current = {
				path: e,
				offset: te,
				mesh: u.current
			};
			for (let n = 0; n < h; n++) {
				let r = ((n * e.length / h + te) % e.length + e.length) % e.length, i = me(e.path, e.cumulative, r);
				$.position.set(i.p.x, -i.p.y, Q[t] + 5), $.rotation.set(0, 0, -i.angle), $.updateMatrix(), u.current.setMatrixAt(n, $.matrix), $.position.z += 2, $.rotation.x = Math.PI / 2, $.updateMatrix(), d.current.setMatrixAt(n, $.matrix);
			}
			u.current.instanceMatrix.needsUpdate = !0, d.current.instanceMatrix.needsUpdate = !0;
		}
	}), e.valid ? /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ S("instancedMesh", {
		ref: u,
		args: [
			void 0,
			void 0,
			h
		],
		frustumCulled: !1,
		castShadow: !0,
		children: [/* @__PURE__ */ x("boxGeometry", { args: [
			8.7,
			3.8,
			3
		] }), /* @__PURE__ */ x("meshStandardMaterial", {
			color: n,
			roughness: .5,
			metalness: .4
		})]
	}), /* @__PURE__ */ S("instancedMesh", {
		ref: d,
		args: [
			void 0,
			void 0,
			h
		],
		frustumCulled: !1,
		children: [/* @__PURE__ */ x("cylinderGeometry", { args: [
			1.5,
			1.5,
			3,
			6
		] }), /* @__PURE__ */ x("meshStandardMaterial", {
			color: X.brass,
			roughness: .5,
			metalness: .4
		})]
	})] }) : null;
}
function $e({ part: e, connection: t }) {
	let n = E(e), r = T(e, t.level), i = t.cw ? -.3 : Math.PI - .3, a = t.cw ? i : i + Math.PI;
	return /* @__PURE__ */ S("group", {
		position: [
			n.x,
			-n.y,
			Q[t.level] + 11
		],
		children: [/* @__PURE__ */ S("mesh", { children: [/* @__PURE__ */ x("ringGeometry", { args: [
			r + 3,
			r + 7,
			64,
			1,
			i,
			Math.PI
		] }), /* @__PURE__ */ x("meshBasicMaterial", {
			color: X.highlight,
			side: v.DoubleSide,
			depthTest: !1
		})] }), /* @__PURE__ */ S("mesh", {
			position: [
				(r + 5) * Math.cos(a),
				(r + 5) * Math.sin(a),
				1
			],
			rotation: [
				0,
				0,
				t.cw ? a + Math.PI : a
			],
			children: [/* @__PURE__ */ x("coneGeometry", { args: [
				7,
				14,
				3
			] }), /* @__PURE__ */ x("meshBasicMaterial", {
				color: X.highlight,
				depthTest: !1
			})]
		})]
	});
}
function et(e) {
	let { circuit: t, camera: n, bounds: a, onProject: o } = e, { get: s, size: c } = _(), l = i(() => t.chains.map((e) => ({
		ch: e,
		path: fe(t.parts, e.connections)
	})), [t]), u = i(() => {
		let n = e.hover?.part === e.draft[0]?.part && e.draft.length > 1, r = e.hover && !n ? [...e.draft, e.hover] : e.draft;
		return fe(t.parts, r, n, e.hover ? void 0 : e.tail);
	}, [
		t.parts,
		e.draft,
		e.hover,
		e.tail
	]);
	r(() => {
		let e = s().camera;
		if (!(e instanceof v.OrthographicCamera)) return;
		let r = Math.min(c.width / a.width, c.height / (a.height * .94)) * n.zoom;
		e.left = -c.width / 2, e.right = c.width / 2, e.top = c.height / 2, e.bottom = -c.height / 2, e.zoom = r, e.up.set(0, 0, 1), e.position.set(n.x, -n.y - 650, 1800), e.lookAt(n.x, -n.y, 0), e.updateProjectionMatrix(), e.updateMatrixWorld(!0);
		let i = (t, n, r) => {
			let i = new v.Vector3(t, -n, r).project(e);
			return {
				x: (i.x + 1) * c.width / 2,
				y: (1 - i.y) * c.height / 2
			};
		}, l = i(0, 0, 0), u = i(1, 0, 0), d = i(0, 1, 0), f = {}, p = [];
		for (let e of t.parts) {
			let t = E(e);
			f[e.id] = i(t.x, t.y, Q[w(e).at(-1)] + 20);
			for (let n of w(e)) {
				let r = i(t.x, t.y, Q[n] + 4), a = T(e, n), o = i(t.x + a, t.y, Q[n]), s = i(t.x, t.y + a, Q[n]);
				p.push({
					...r,
					part: e.id,
					level: n,
					rx: Math.abs(o.x - r.x),
					ry: Math.abs(s.y - r.y)
				});
			}
		}
		let m = Q.map((e) => {
			let t = i(0, 0, e + 5);
			return {
				x: t.x - l.x,
				y: t.y - l.y
			};
		});
		o({
			origin: l,
			xAxis: {
				x: u.x - l.x,
				y: u.y - l.y
			},
			yAxis: {
				x: d.x - l.x,
				y: d.y - l.y
			},
			centers: f,
			wheels: p,
			layers: m,
			viewport: {
				width: c.width,
				height: c.height
			}
		});
	}, [
		s,
		n,
		a,
		c,
		t.parts,
		o
	]);
	let d = e.hover && t.parts.find((t) => t.id === e.hover.part);
	return /* @__PURE__ */ S(b, { children: [
		/* @__PURE__ */ x("color", {
			attach: "background",
			args: ["#e9e6d8"]
		}),
		/* @__PURE__ */ x("hemisphereLight", {
			color: "#fffbea",
			groundColor: "#80947e",
			intensity: 2.3
		}),
		/* @__PURE__ */ x("directionalLight", {
			color: "#fff4d9",
			intensity: 2.4,
			position: [
				-600,
				900,
				1700
			]
		}),
		/* @__PURE__ */ S("mesh", {
			position: [
				0,
				0,
				-12
			],
			receiveShadow: !0,
			children: [/* @__PURE__ */ x("boxGeometry", { args: [
				1e4,
				1e4,
				20
			] }), /* @__PURE__ */ x("meshStandardMaterial", {
				color: X.board,
				roughness: .85
			})]
		}),
		/* @__PURE__ */ x("gridHelper", {
			args: [
				1e4,
				250,
				"#aab99d",
				"#b8c6aa"
			],
			position: [
				0,
				0,
				.1
			],
			rotation: [
				Math.PI / 2,
				0,
				0
			]
		}),
		t.parts.map((t) => /* @__PURE__ */ x(Ze, {
			part: t,
			pose: e.pose,
			previousPose: e.previousPose,
			running: e.running,
			speed: e.speed
		}, t.id)),
		l.map(({ ch: n, path: r }) => /* @__PURE__ */ x(Qe, {
			circuit: t,
			path: r,
			level: n.connections[0].level,
			color: n.id === e.selectedChain ? X.highlight : n.fixed ? X.chain : X.movable,
			pose: e.pose,
			previousPose: e.previousPose,
			running: e.running,
			first: n.connections[0]
		}, n.id)),
		e.draft.length > 0 && /* @__PURE__ */ x(Qe, {
			circuit: t,
			path: u,
			level: e.draft[0].level,
			color: X.highlight,
			pose: null,
			previousPose: null,
			running: !1
		}),
		!e.draft.length && e.hover && d && /* @__PURE__ */ x($e, {
			part: d,
			connection: e.hover
		}),
		t.parts.filter((t) => t.id === e.selected).map((e) => {
			let t = E(e);
			return /* @__PURE__ */ S("mesh", {
				position: [
					t.x,
					-t.y,
					16
				],
				children: [/* @__PURE__ */ x("ringGeometry", { args: [
					T(e, 0) + 12,
					T(e, 0) + 15,
					64
				] }), /* @__PURE__ */ x("meshBasicMaterial", {
					color: X.highlight,
					side: v.DoubleSide
				})]
			}, e.id);
		})
	] });
}
function tt({ fallback: e, ...t }) {
	return /* @__PURE__ */ x(re, {
		orthographic: !0,
		camera: {
			near: .1,
			far: 2e4
		},
		dpr: [1, 2],
		gl: {
			antialias: !0,
			alpha: !1
		},
		recoveryFallback: e,
		children: /* @__PURE__ */ x(et, { ...t })
	});
}
//#endregion
//#region src/games/spintronics/chain-contacts.tsx
var nt = (e) => `${e.part}:${e.level}:${e.cw}`;
function rt(e, t, n, r, i) {
	let a = {
		x: e.x + t * Math.cos(r),
		y: e.y + n * Math.sin(r)
	}, o = -t * Math.sin(r) * i, s = n * Math.cos(r) * i, c = Math.hypot(o, s), l = o / c, u = s / c;
	return {
		end: a,
		ux: l,
		uy: u,
		length: c,
		points: [
			a,
			{
				x: a.x - l * 20 - u * 11,
				y: a.y - u * 20 + l * 11
			},
			{
				x: a.x - l * 20 + u * 11,
				y: a.y - u * 20 - l * 11
			}
		]
	};
}
function it(e, t, n, r) {
	let i = r.length === 0;
	return t.flatMap((a) => {
		let o = e.wheels.find((e) => e.part === a.part && e.level === a.level);
		if (!o) return [];
		let s = i ? e.wheels.filter((e) => e.part === a.part) : [o], c = [...new Set(t.filter((e) => e.part === a.part).map((e) => e.level))].sort((e, t) => e - t), l = i ? c.indexOf(a.level) * 32 : 0, u = i ? s.reduce((e, t) => e.level < t.level ? e : t) : o, d = Math.max(44, ...s.map((e) => e.rx + 16)) + l, f = Math.max(44, ...s.map((e) => e.ry + 16)) + l, p = a.cw ? 1 : -1, m = 4 * Math.PI / 9, h = a.cw ? -m / 2 : -Math.PI + m / 2;
		if (!i) {
			let e = A(n, r.at(-1)), t = A(n, a), i = e && t && de(e, t);
			if (!i || !t) return [];
			if (h = Math.atan2(i.b.y - t.y, i.b.x - t.x), a.part === r[0].part && r.length > 1) {
				let e = A(n, r[1]), i = e && de(t, e);
				if (!i) return [];
				let a = Math.atan2(i.a.y - t.y, i.a.x - t.x);
				m = Math.min(m, ((a - h) * p % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2));
			}
		}
		if (!i) {
			let t = Math.min(m, Math.PI / 4), { width: n, height: r } = e.viewport;
			for (; m > t && rt(u, d, f, h + p * m, p).points.some((e) => e.x < 6 || e.y < 6 || e.x > n - 6 || e.y > r - 6);) m = Math.max(t, m - Math.PI / 36);
		}
		let ee = m * Math.min(d, f) < 24, te = h + p * m, { end: ne, ux: g, uy: _, length: v, points: y } = rt(u, d, f, te, p), re = Array.from({ length: 33 }, (e, t) => {
			if (ee) return {
				x: ne.x - g * 44 * (1 - t / 32),
				y: ne.y - _ * 44 * (1 - t / 32)
			};
			let n = h + p * m * t / 32;
			return {
				x: u.x + d * Math.cos(n),
				y: u.y + f * Math.sin(n)
			};
		}), b = re[0], x = re.at(-1), S = te - p * 16 / v, C = ee ? x.x - g * 16 : u.x + d * Math.cos(S), ie = ee ? x.y - _ * 16 : u.y + f * Math.sin(S), ae = -2 * Math.PI / 9 - .12, w = ee ? "L" : `A ${d} ${f} 0 0 ${+!!a.cw}`;
		return [{
			connection: a,
			wheel: o,
			path: re,
			label: {
				x: u.x + (a.cw ? 1 : -1) * d * Math.cos(ae),
				y: u.y + f * Math.sin(ae) - 9
			},
			d: `M ${b.x} ${b.y} ${w} ${x.x} ${x.y}`,
			line: `M ${b.x} ${b.y} ${w} ${C} ${ie}`,
			tip: `M ${y[0].x} ${y[0].y} L ${y[1].x} ${y[1].y} L ${y[2].x} ${y[2].y} Z`
		}];
	});
}
function at({ projection: e, connections: t, parts: n, draft: r, hover: a, levelName: o, name: s, onHover: c, onConnect: l }) {
	let u = JSON.stringify(t), d = r.length === 0, f = i(() => it(e, JSON.parse(u), n, r), [
		e,
		u,
		n,
		r
	]), p = a && nt(a), m = (e, t) => {
		let n = e.currentTarget.ownerSVGElement.getBoundingClientRect(), r = {
			x: e.clientX - n.left,
			y: e.clientY - n.top
		}, i = Infinity, a = t;
		for (let e of f) for (let t = 1; t < e.path.length; t++) {
			let n = e.path[t - 1], o = e.path[t], s = o.x - n.x, c = o.y - n.y, l = Math.max(0, Math.min(1, ((r.x - n.x) * s + (r.y - n.y) * c) / (s * s + c * c))), u = Math.hypot(r.x - n.x - l * s, r.y - n.y - l * c);
			u < i && (i = u, a = e.connection);
		}
		return a;
	};
	return /* @__PURE__ */ x("svg", {
		className: "spin-chain-contacts",
		width: "100%",
		height: "100%",
		children: f.map(({ connection: e, d: t, line: n, tip: r, label: i }) => /* @__PURE__ */ S("g", {
			role: "button",
			tabIndex: 0,
			"aria-label": s(e),
			className: `spin-contact-arc ${nt(e) === p ? "is-active" : ""}`,
			onPointerDown: (e) => e.stopPropagation(),
			onPointerUp: (e) => e.stopPropagation(),
			onPointerMove: (t) => {
				t.stopPropagation(), t.pointerType === "mouse" && c(m(t, e));
			},
			onPointerEnter: (t) => {
				t.pointerType === "mouse" && c(m(t, e));
			},
			onPointerLeave: () => c(null),
			onFocus: () => c(e),
			onBlur: () => c(null),
			onKeyDown: (t) => {
				t.key === "Enter" ? (t.preventDefault(), l(e)) : t.key === " " && t.preventDefault();
			},
			onKeyUp: (t) => {
				t.key === " " && (t.preventDefault(), l(e));
			},
			onClick: (t) => {
				t.stopPropagation(), l(t.detail === 0 ? e : m(t, e));
			},
			children: [
				/* @__PURE__ */ x("title", { children: s(e) }),
				/* @__PURE__ */ x("path", {
					className: "spin-contact-hit",
					d: t
				}),
				/* @__PURE__ */ x("path", {
					className: "spin-contact-line",
					d: n
				}),
				/* @__PURE__ */ x("path", {
					className: "spin-contact-tip",
					d: r
				}),
				d && /* @__PURE__ */ x("text", {
					className: "spin-contact-level",
					x: i.x,
					y: i.y,
					textAnchor: "middle",
					"aria-hidden": "true",
					children: o(e.level)
				})
			]
		}, nt(e)))
	});
}
//#endregion
//#region src/games/spintronics/level-keys.ts
var ot = {
	1: {
		title: "games.spintronics.levels.c001.title",
		goal: "games.spintronics.levels.c001.goal"
	},
	2: {
		title: "games.spintronics.levels.c002.title",
		goal: "games.spintronics.levels.c002.goal"
	},
	3: {
		title: "games.spintronics.levels.c003.title",
		goal: "games.spintronics.levels.c003.goal"
	},
	4: {
		title: "games.spintronics.levels.c004.title",
		goal: "games.spintronics.levels.c004.goal"
	},
	5: {
		title: "games.spintronics.levels.c005.title",
		goal: "games.spintronics.levels.c005.goal"
	},
	6: {
		title: "games.spintronics.levels.c006.title",
		goal: "games.spintronics.levels.c006.goal"
	},
	7: {
		title: "games.spintronics.levels.c007.title",
		goal: "games.spintronics.levels.c007.goal"
	},
	8: {
		title: "games.spintronics.levels.c008.title",
		goal: "games.spintronics.levels.c008.goal"
	},
	9: {
		title: "games.spintronics.levels.c009.title",
		goal: "games.spintronics.levels.c009.goal"
	},
	10: {
		title: "games.spintronics.levels.c010.title",
		goal: "games.spintronics.levels.c010.goal"
	},
	11: {
		title: "games.spintronics.levels.c011.title",
		goal: "games.spintronics.levels.c011.goal"
	},
	12: {
		title: "games.spintronics.levels.c012.title",
		goal: "games.spintronics.levels.c012.goal"
	},
	13: {
		title: "games.spintronics.levels.c013.title",
		goal: "games.spintronics.levels.c013.goal"
	},
	14: {
		title: "games.spintronics.levels.c014.title",
		goal: "games.spintronics.levels.c014.goal"
	},
	15: {
		title: "games.spintronics.levels.c015.title",
		goal: "games.spintronics.levels.c015.goal"
	},
	16: {
		title: "games.spintronics.levels.c016.title",
		goal: "games.spintronics.levels.c016.goal"
	},
	17: {
		title: "games.spintronics.levels.c017.title",
		goal: "games.spintronics.levels.c017.goal"
	},
	18: {
		title: "games.spintronics.levels.c018.title",
		goal: "games.spintronics.levels.c018.goal"
	},
	19: {
		title: "games.spintronics.levels.c019.title",
		goal: "games.spintronics.levels.c019.goal"
	},
	20: {
		title: "games.spintronics.levels.c020.title",
		goal: "games.spintronics.levels.c020.goal"
	},
	21: {
		title: "games.spintronics.levels.c021.title",
		goal: "games.spintronics.levels.c021.goal"
	},
	22: {
		title: "games.spintronics.levels.c022.title",
		goal: "games.spintronics.levels.c022.goal"
	},
	23: {
		title: "games.spintronics.levels.c023.title",
		goal: "games.spintronics.levels.c023.goal"
	},
	24: {
		title: "games.spintronics.levels.c024.title",
		goal: "games.spintronics.levels.c024.goal"
	},
	25: {
		title: "games.spintronics.levels.c025.title",
		goal: "games.spintronics.levels.c025.goal"
	},
	26: {
		title: "games.spintronics.levels.c026.title",
		goal: "games.spintronics.levels.c026.goal"
	},
	27: {
		title: "games.spintronics.levels.c027.title",
		goal: "games.spintronics.levels.c027.goal"
	},
	28: {
		title: "games.spintronics.levels.c028.title",
		goal: "games.spintronics.levels.c028.goal"
	},
	29: {
		title: "games.spintronics.levels.c029.title",
		goal: "games.spintronics.levels.c029.goal"
	},
	30: {
		title: "games.spintronics.levels.c030.title",
		goal: "games.spintronics.levels.c030.goal"
	},
	31: {
		title: "games.spintronics.levels.c031.title",
		goal: "games.spintronics.levels.c031.goal"
	},
	32: {
		title: "games.spintronics.levels.c032.title",
		goal: "games.spintronics.levels.c032.goal"
	},
	33: {
		title: "games.spintronics.levels.c033.title",
		goal: "games.spintronics.levels.c033.goal"
	},
	34: {
		title: "games.spintronics.levels.c034.title",
		goal: "games.spintronics.levels.c034.goal"
	},
	35: {
		title: "games.spintronics.levels.c035.title",
		goal: "games.spintronics.levels.c035.goal"
	},
	36: {
		title: "games.spintronics.levels.c036.title",
		goal: "games.spintronics.levels.c036.goal"
	},
	37: {
		title: "games.spintronics.levels.c037.title",
		goal: "games.spintronics.levels.c037.goal"
	},
	38: {
		title: "games.spintronics.levels.c038.title",
		goal: "games.spintronics.levels.c038.goal"
	},
	39: {
		title: "games.spintronics.levels.c039.title",
		goal: "games.spintronics.levels.c039.goal"
	},
	40: {
		title: "games.spintronics.levels.c040.title",
		goal: "games.spintronics.levels.c040.goal"
	},
	41: {
		title: "games.spintronics.levels.c041.title",
		goal: "games.spintronics.levels.c041.goal"
	},
	42: {
		title: "games.spintronics.levels.c042.title",
		goal: "games.spintronics.levels.c042.goal"
	},
	43: {
		title: "games.spintronics.levels.c043.title",
		goal: "games.spintronics.levels.c043.goal"
	},
	44: {
		title: "games.spintronics.levels.c044.title",
		goal: "games.spintronics.levels.c044.goal"
	},
	45: {
		title: "games.spintronics.levels.c045.title",
		goal: "games.spintronics.levels.c045.goal"
	},
	46: {
		title: "games.spintronics.levels.c046.title",
		goal: "games.spintronics.levels.c046.goal"
	},
	47: {
		title: "games.spintronics.levels.c047.title",
		goal: "games.spintronics.levels.c047.goal"
	},
	48: {
		title: "games.spintronics.levels.c048.title",
		goal: "games.spintronics.levels.c048.goal"
	},
	49: {
		title: "games.spintronics.levels.c049.title",
		goal: "games.spintronics.levels.c049.goal"
	},
	50: {
		title: "games.spintronics.levels.c050.title",
		goal: "games.spintronics.levels.c050.goal"
	},
	51: {
		title: "games.spintronics.levels.c051.title",
		goal: "games.spintronics.levels.c051.goal"
	},
	52: {
		title: "games.spintronics.levels.c052.title",
		goal: "games.spintronics.levels.c052.goal"
	},
	53: {
		title: "games.spintronics.levels.c053.title",
		goal: "games.spintronics.levels.c053.goal"
	},
	54: {
		title: "games.spintronics.levels.c054.title",
		goal: "games.spintronics.levels.c054.goal"
	},
	55: {
		title: "games.spintronics.levels.c055.title",
		goal: "games.spintronics.levels.c055.goal"
	},
	56: {
		title: "games.spintronics.levels.c056.title",
		goal: "games.spintronics.levels.c056.goal"
	},
	57: {
		title: "games.spintronics.levels.c057.title",
		goal: "games.spintronics.levels.c057.goal"
	},
	58: {
		title: "games.spintronics.levels.c058.title",
		goal: "games.spintronics.levels.c058.goal"
	},
	59: {
		title: "games.spintronics.levels.c059.title",
		goal: "games.spintronics.levels.c059.goal"
	},
	60: {
		title: "games.spintronics.levels.c060.title",
		goal: "games.spintronics.levels.c060.goal"
	},
	61: {
		title: "games.spintronics.levels.c061.title",
		goal: "games.spintronics.levels.c061.goal"
	},
	62: {
		title: "games.spintronics.levels.c062.title",
		goal: "games.spintronics.levels.c062.goal"
	},
	63: {
		title: "games.spintronics.levels.c063.title",
		goal: "games.spintronics.levels.c063.goal"
	},
	64: {
		title: "games.spintronics.levels.c064.title",
		goal: "games.spintronics.levels.c064.goal"
	},
	65: {
		title: "games.spintronics.levels.c065.title",
		goal: "games.spintronics.levels.c065.goal"
	},
	66: {
		title: "games.spintronics.levels.c066.title",
		goal: "games.spintronics.levels.c066.goal"
	},
	67: {
		title: "games.spintronics.levels.c067.title",
		goal: "games.spintronics.levels.c067.goal"
	},
	68: {
		title: "games.spintronics.levels.c068.title",
		goal: "games.spintronics.levels.c068.goal"
	},
	69: {
		title: "games.spintronics.levels.c069.title",
		goal: "games.spintronics.levels.c069.goal"
	},
	70: {
		title: "games.spintronics.levels.c070.title",
		goal: "games.spintronics.levels.c070.goal"
	},
	71: {
		title: "games.spintronics.levels.c071.title",
		goal: "games.spintronics.levels.c071.goal"
	},
	72: {
		title: "games.spintronics.levels.c072.title",
		goal: "games.spintronics.levels.c072.goal"
	},
	73: {
		title: "games.spintronics.levels.c073.title",
		goal: "games.spintronics.levels.c073.goal"
	},
	74: {
		title: "games.spintronics.levels.c074.title",
		goal: "games.spintronics.levels.c074.goal"
	},
	75: {
		title: "games.spintronics.levels.c075.title",
		goal: "games.spintronics.levels.c075.goal"
	},
	76: {
		title: "games.spintronics.levels.c076.title",
		goal: "games.spintronics.levels.c076.goal"
	},
	77: {
		title: "games.spintronics.levels.c077.title",
		goal: "games.spintronics.levels.c077.goal"
	},
	78: {
		title: "games.spintronics.levels.c078.title",
		goal: "games.spintronics.levels.c078.goal"
	},
	79: {
		title: "games.spintronics.levels.c079.title",
		goal: "games.spintronics.levels.c079.goal"
	},
	80: {
		title: "games.spintronics.levels.c080.title",
		goal: "games.spintronics.levels.c080.goal"
	},
	81: {
		title: "games.spintronics.levels.c081.title",
		goal: "games.spintronics.levels.c081.goal"
	},
	82: {
		title: "games.spintronics.levels.c082.title",
		goal: "games.spintronics.levels.c082.goal"
	},
	83: {
		title: "games.spintronics.levels.c083.title",
		goal: "games.spintronics.levels.c083.goal"
	},
	84: {
		title: "games.spintronics.levels.c084.title",
		goal: "games.spintronics.levels.c084.goal"
	},
	85: {
		title: "games.spintronics.levels.c085.title",
		goal: "games.spintronics.levels.c085.goal"
	},
	86: {
		title: "games.spintronics.levels.c086.title",
		goal: "games.spintronics.levels.c086.goal"
	},
	87: {
		title: "games.spintronics.levels.c087.title",
		goal: "games.spintronics.levels.c087.goal"
	},
	88: {
		title: "games.spintronics.levels.c088.title",
		goal: "games.spintronics.levels.c088.goal"
	},
	89: {
		title: "games.spintronics.levels.c089.title",
		goal: "games.spintronics.levels.c089.goal"
	},
	90: {
		title: "games.spintronics.levels.c090.title",
		goal: "games.spintronics.levels.c090.goal"
	},
	91: {
		title: "games.spintronics.levels.c091.title",
		goal: "games.spintronics.levels.c091.goal"
	},
	92: {
		title: "games.spintronics.levels.c092.title",
		goal: "games.spintronics.levels.c092.goal"
	},
	93: {
		title: "games.spintronics.levels.c093.title",
		goal: "games.spintronics.levels.c093.goal"
	},
	94: {
		title: "games.spintronics.levels.c094.title",
		goal: "games.spintronics.levels.c094.goal"
	},
	95: {
		title: "games.spintronics.levels.c095.title",
		goal: "games.spintronics.levels.c095.goal"
	},
	96: {
		title: "games.spintronics.levels.c096.title",
		goal: "games.spintronics.levels.c096.goal"
	},
	97: {
		title: "games.spintronics.levels.c097.title",
		goal: "games.spintronics.levels.c097.goal"
	},
	98: {
		title: "games.spintronics.levels.c098.title",
		goal: "games.spintronics.levels.c098.goal"
	},
	99: {
		title: "games.spintronics.levels.c099.title",
		goal: "games.spintronics.levels.c099.goal"
	},
	100: {
		title: "games.spintronics.levels.c100.title",
		goal: "games.spintronics.levels.c100.goal"
	},
	101: {
		title: "games.spintronics.levels.c101.title",
		goal: "games.spintronics.levels.c101.goal"
	},
	102: {
		title: "games.spintronics.levels.c102.title",
		goal: "games.spintronics.levels.c102.goal"
	},
	103: {
		title: "games.spintronics.levels.c103.title",
		goal: "games.spintronics.levels.c103.goal"
	},
	104: {
		title: "games.spintronics.levels.c104.title",
		goal: "games.spintronics.levels.c104.goal"
	},
	105: {
		title: "games.spintronics.levels.c105.title",
		goal: "games.spintronics.levels.c105.goal"
	},
	106: {
		title: "games.spintronics.levels.c106.title",
		goal: "games.spintronics.levels.c106.goal"
	},
	107: {
		title: "games.spintronics.levels.c107.title",
		goal: "games.spintronics.levels.c107.goal"
	},
	108: {
		title: "games.spintronics.levels.c108.title",
		goal: "games.spintronics.levels.c108.goal"
	},
	109: {
		title: "games.spintronics.levels.c109.title",
		goal: "games.spintronics.levels.c109.goal"
	},
	110: {
		title: "games.spintronics.levels.c110.title",
		goal: "games.spintronics.levels.c110.goal"
	},
	111: {
		title: "games.spintronics.levels.c111.title",
		goal: "games.spintronics.levels.c111.goal"
	},
	112: {
		title: "games.spintronics.levels.c112.title",
		goal: "games.spintronics.levels.c112.goal"
	},
	113: {
		title: "games.spintronics.levels.c113.title",
		goal: "games.spintronics.levels.c113.goal"
	},
	114: {
		title: "games.spintronics.levels.c114.title",
		goal: "games.spintronics.levels.c114.goal"
	},
	115: {
		title: "games.spintronics.levels.c115.title",
		goal: "games.spintronics.levels.c115.goal"
	},
	116: {
		title: "games.spintronics.levels.c116.title",
		goal: "games.spintronics.levels.c116.goal"
	},
	117: {
		title: "games.spintronics.levels.c117.title",
		goal: "games.spintronics.levels.c117.goal"
	},
	118: {
		title: "games.spintronics.levels.c118.title",
		goal: "games.spintronics.levels.c118.goal"
	},
	119: {
		title: "games.spintronics.levels.c119.title",
		goal: "games.spintronics.levels.c119.goal"
	},
	120: {
		title: "games.spintronics.levels.c120.title",
		goal: "games.spintronics.levels.c120.goal"
	},
	121: {
		title: "games.spintronics.levels.c121.title",
		goal: "games.spintronics.levels.c121.goal"
	},
	122: {
		title: "games.spintronics.levels.c122.title",
		goal: "games.spintronics.levels.c122.goal"
	},
	123: {
		title: "games.spintronics.levels.c123.title",
		goal: "games.spintronics.levels.c123.goal"
	},
	124: {
		title: "games.spintronics.levels.c124.title",
		goal: "games.spintronics.levels.c124.goal"
	},
	125: {
		title: "games.spintronics.levels.c125.title",
		goal: "games.spintronics.levels.c125.goal"
	},
	126: {
		title: "games.spintronics.levels.c126.title",
		goal: "games.spintronics.levels.c126.goal"
	},
	127: {
		title: "games.spintronics.levels.c127.title",
		goal: "games.spintronics.levels.c127.goal"
	},
	128: {
		title: "games.spintronics.levels.c128.title",
		goal: "games.spintronics.levels.c128.goal"
	},
	129: {
		title: "games.spintronics.levels.c129.title",
		goal: "games.spintronics.levels.c129.goal"
	},
	130: {
		title: "games.spintronics.levels.c130.title",
		goal: "games.spintronics.levels.c130.goal"
	},
	131: {
		title: "games.spintronics.levels.c131.title",
		goal: "games.spintronics.levels.c131.goal"
	},
	132: {
		title: "games.spintronics.levels.c132.title",
		goal: "games.spintronics.levels.c132.goal"
	},
	133: {
		title: "games.spintronics.levels.c133.title",
		goal: "games.spintronics.levels.c133.goal"
	},
	134: {
		title: "games.spintronics.levels.c134.title",
		goal: "games.spintronics.levels.c134.goal"
	},
	135: {
		title: "games.spintronics.levels.c135.title",
		goal: "games.spintronics.levels.c135.goal"
	},
	136: {
		title: "games.spintronics.levels.c136.title",
		goal: "games.spintronics.levels.c136.goal"
	},
	137: {
		title: "games.spintronics.levels.c137.title",
		goal: "games.spintronics.levels.c137.goal"
	},
	138: {
		title: "games.spintronics.levels.c138.title",
		goal: "games.spintronics.levels.c138.goal"
	},
	139: {
		title: "games.spintronics.levels.c139.title",
		goal: "games.spintronics.levels.c139.goal"
	},
	140: {
		title: "games.spintronics.levels.c140.title",
		goal: "games.spintronics.levels.c140.goal"
	},
	141: {
		title: "games.spintronics.levels.c141.title",
		goal: "games.spintronics.levels.c141.goal"
	},
	142: {
		title: "games.spintronics.levels.c142.title",
		goal: "games.spintronics.levels.c142.goal"
	},
	143: {
		title: "games.spintronics.levels.c143.title",
		goal: "games.spintronics.levels.c143.goal"
	},
	144: {
		title: "games.spintronics.levels.c144.title",
		goal: "games.spintronics.levels.c144.goal"
	},
	145: {
		title: "games.spintronics.levels.c145.title",
		goal: "games.spintronics.levels.c145.goal"
	},
	146: {
		title: "games.spintronics.levels.c146.title",
		goal: "games.spintronics.levels.c146.goal"
	},
	147: {
		title: "games.spintronics.levels.c147.title",
		goal: "games.spintronics.levels.c147.goal"
	},
	148: {
		title: "games.spintronics.levels.c148.title",
		goal: "games.spintronics.levels.c148.goal"
	},
	149: {
		title: "games.spintronics.levels.c149.title",
		goal: "games.spintronics.levels.c149.goal"
	},
	150: {
		title: "games.spintronics.levels.c150.title",
		goal: "games.spintronics.levels.c150.goal"
	},
	151: {
		title: "games.spintronics.levels.c151.title",
		goal: "games.spintronics.levels.c151.goal"
	},
	152: {
		title: "games.spintronics.levels.c152.title",
		goal: "games.spintronics.levels.c152.goal"
	},
	153: {
		title: "games.spintronics.levels.c153.title",
		goal: "games.spintronics.levels.c153.goal"
	},
	154: {
		title: "games.spintronics.levels.c154.title",
		goal: "games.spintronics.levels.c154.goal"
	},
	155: {
		title: "games.spintronics.levels.c155.title",
		goal: "games.spintronics.levels.c155.goal"
	},
	156: {
		title: "games.spintronics.levels.c156.title",
		goal: "games.spintronics.levels.c156.goal"
	},
	157: {
		title: "games.spintronics.levels.c157.title",
		goal: "games.spintronics.levels.c157.goal"
	},
	158: {
		title: "games.spintronics.levels.c158.title",
		goal: "games.spintronics.levels.c158.goal"
	},
	159: {
		title: "games.spintronics.levels.c159.title",
		goal: "games.spintronics.levels.c159.goal"
	},
	160: {
		title: "games.spintronics.levels.c160.title",
		goal: "games.spintronics.levels.c160.goal"
	}
};
//#endregion
//#region src/games/spintronics/part-glyph.tsx
function st({ kind: e }) {
	let t = (e, t, n = 0) => /* @__PURE__ */ S("g", {
		transform: `translate(0 ${n})`,
		children: [
			/* @__PURE__ */ x("circle", {
				r: e + 3,
				fill: X.cream,
				stroke: X.ink,
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ x("circle", {
				r: e,
				fill: t,
				stroke: X.brass,
				strokeWidth: "3",
				strokeDasharray: "3 2"
			}),
			/* @__PURE__ */ x("circle", {
				r: e * .64,
				fill: "none",
				stroke: X.brass,
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ x("circle", {
				r: "4",
				fill: X.cream,
				stroke: X.ink
			})
		]
	});
	return /* @__PURE__ */ x("svg", {
		viewBox: "-42 -44 84 88",
		"aria-hidden": "true",
		children: e === "diode-kit" ? /* @__PURE__ */ S(b, { children: [
			t(20, X.transistor, -21),
			t(25, X.junction, 21),
			/* @__PURE__ */ x("path", {
				d: "M-20-21V21M20-21V21",
				fill: "none",
				stroke: X.chain,
				strokeWidth: "3"
			})
		] }) : e === "junction" ? /* @__PURE__ */ S(b, { children: [
			t(34, X.junction),
			t(23, "#648fa3"),
			t(12, X.brass)
		] }) : e === "motor" ? /* @__PURE__ */ S(b, { children: [
			/* @__PURE__ */ x("rect", {
				x: "-32",
				y: "-26",
				width: "64",
				height: "67",
				rx: "12",
				fill: X.cream,
				stroke: X.brass,
				strokeWidth: "2"
			}),
			/* @__PURE__ */ x("g", {
				transform: "translate(0 14)",
				children: t(22, X.brass)
			}),
			t(13, X.motor, -23)
		] }) : /* @__PURE__ */ S(b, { children: [
			t(e === "inductor" ? 23 : 31, X[e]),
			e === "capacitor" && /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("circle", {
				r: "23",
				fill: X.cream
			}), /* @__PURE__ */ x("path", {
				d: "M0 18V-19M-14 13L13-15",
				stroke: X.ink,
				strokeWidth: "2"
			})] }),
			e === "button" && /* @__PURE__ */ x("rect", {
				x: "-6",
				y: "-20",
				width: "12",
				height: "40",
				rx: "6",
				fill: X.button,
				stroke: X.brass
			}),
			e === "inductor" && [
				0,
				120,
				240
			].map((e) => /* @__PURE__ */ x("rect", {
				x: "15",
				y: "-5",
				width: "25",
				height: "10",
				rx: "2",
				transform: `rotate(${e})`,
				fill: X.brass,
				stroke: X.ink
			}, e)),
			e === "phonograph" && /* @__PURE__ */ x("path", {
				d: "M-10 0Q5-28 25-31L36-9Q12-18 2 12Z",
				fill: X.brass,
				stroke: X.ink
			})
		] })
	});
}
//#endregion
//#region src/games/spintronics/progress.ts
var ct = "bgparty:spintronics", lt;
function ut() {
	if (lt) return lt;
	try {
		let e = JSON.parse(localStorage.getItem(ct) ?? "[]");
		Array.isArray(e) && (lt = [...new Set(e.filter((e) => Number.isInteger(e) && e >= 1 && e <= 160))]);
	} catch {}
	return lt ??= [];
}
function dt(e) {
	if (!ut().includes(e)) {
		lt = [...ut(), e];
		try {
			localStorage.setItem(ct, JSON.stringify(lt));
		} catch {}
	}
}
//#endregion
//#region src/games/spintronics/view-player.tsx
var ft = {
	build: "games.spintronics.build",
	running: "games.spintronics.running",
	paused: "games.spintronics.paused",
	checking: "games.spintronics.checking",
	passed: "games.spintronics.passed",
	failed: "games.spintronics.failed",
	unverified: "games.spintronics.unverified"
}, pt = {
	short: "games.spintronics.short",
	missing: "games.spintronics.missing",
	goal: "games.spintronics.goalFailure",
	unsupported: "games.spintronics.unsupported"
}, mt = {
	wheels: [],
	centers: {},
	layers: [],
	origin: {
		x: 0,
		y: 0
	},
	xAxis: {
		x: 1,
		y: 0
	},
	yAxis: {
		x: 0,
		y: 1
	},
	viewport: {
		width: 0,
		height: 0
	}
}, ht = {
	one: "games.spintronics.bookOne",
	two: "games.spintronics.bookTwo",
	power: "games.spintronics.bookPower"
};
function gt(e) {
	let t = e.public;
	return /* @__PURE__ */ x(_t, {
		pub: t,
		send: e.send
	}, t.challenge);
}
function _t({ pub: e, send: r }) {
	let g = s();
	te();
	let _ = ce[e.challenge - 1], v = e.phase === "build", y = e.phase === "running", re = JSON.stringify(e.circuit), C = i(() => JSON.parse(re), [re]), [ie, T] = o(null), [ue, O] = o(null), [k, A] = o([]), [de, j] = o(null), [me, he] = o(), [M, N] = o(null), [ge, P] = o(null), [F, _e] = o(mt), [I, ve] = o(null), [ye, be] = o(!1), [xe, Se] = o(!1), [L, R] = o(null), [z, Ce] = o(!1), B = a(null), V = a(null), H = a(/* @__PURE__ */ new Map()), we = a(null), U = a(null), Te = a(null), Ee = i(() => {
		let e = _.initial.parts.map(E), t = e.map((e) => e.x), n = e.map((e) => e.y), r = Math.min(-120, ...t) - 160, i = Math.max(120, ...t) + 240, a = Math.min(-120, ...n) - 180, o = Math.max(100, ...n) + 200;
		return {
			x: (r + i) / 2,
			y: (a + o) / 2,
			width: Math.max(650, i - r),
			height: Math.max(700, o - a)
		};
	}, [_]), De = {
		x: Ee.x,
		y: Ee.y,
		zoom: 1
	}, [Oe, W] = o(De), G = C.parts.find((e) => e.id === ie), K = C.chains.find((e) => e.id === ue), ke = i(() => {
		if (!L) return C;
		let e = C.parts.find((e) => e.id === L.id);
		return {
			...C,
			parts: C.parts.map((t) => t.id === e?.id || e?.group && e.group === t.group ? {
				...t,
				x: t.x + L.x - e.x,
				y: t.y + L.y - e.y
			} : t)
		};
	}, [C, L]), Ae = i(() => {
		let e = [..._.stock];
		for (let t of _.initial.parts.filter((e) => !e.fixed && !e.group)) e.some((e) => oe(e) === oe(t)) || e.push({
			kind: t.kind,
			value: t.value,
			count: 0
		});
		return e;
	}, [_]), je = Math.max(0, _.loops + _.initial.chains.filter((e) => !e.fixed).length - C.chains.filter((e) => !e.fixed && !e.id.startsWith("k")).length), Me = t((e) => _e((t) => JSON.stringify(t) === JSON.stringify(e) ? t : e), []), Ne = () => {
		let e = C.parts.map(E), t = e.map((e) => e.x), n = e.map((e) => e.y);
		if (!e.length || !B.current) {
			W(De);
			return;
		}
		let r = Math.min(...t) - 160, i = Math.max(...t) + 160, a = Math.min(...n) - 180, o = Math.max(...n) + 180, s = B.current.getBoundingClientRect(), c = Math.min(s.width / Ee.width, s.height / (Ee.height * .94));
		W({
			x: (r + i) / 2,
			y: (a + o) / 2,
			zoom: Math.min(4, Math.max(.08, Math.min(s.width / Math.max(450, i - r), s.height / (Math.max(450, o - a) * .94)) / c))
		});
	};
	n(() => {
		e.phase === "passed" && dt(e.challenge);
	}, [e.phase, e.challenge]), n(() => {
		if (!I) return;
		let e = document.activeElement instanceof HTMLElement ? document.activeElement : null, t = (e) => {
			if (e.key !== "Tab") return;
			let t = [...we.current?.querySelectorAll("button:not(:disabled), input:not(:disabled), [tabindex=\"0\"]") ?? []], n = t[0], r = t.at(-1);
			e.shiftKey && (document.activeElement === n || !we.current?.contains(document.activeElement)) ? (e.preventDefault(), r?.focus()) : !e.shiftKey && (document.activeElement === r || !we.current?.contains(document.activeElement)) && (e.preventDefault(), n?.focus());
		};
		return document.addEventListener("keydown", t), () => {
			document.removeEventListener("keydown", t), e?.focus();
		};
	}, [I]), n(() => {
		let e = (e) => {
			e.target.closest("input") || (e.key === "Escape" && (ve(null), A([]), N(null), P(null), T(null), O(null), j(null)), e.key === "Backspace" && k.length > (M ? C.chains.find((e) => e.id === M)?.connections.length ?? 0 : 0) && (e.preventDefault(), A((e) => e.slice(0, -1)), j(null)));
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, [
		k.length,
		M,
		C.chains
	]), n(() => {
		let e = B.current;
		if (!e) return;
		let t = (e) => {
			e.target.closest("[role=dialog]") || (e.preventDefault(), W((t) => ({
				...t,
				zoom: Math.max(.08, Math.min(4, t.zoom * Math.exp(-e.deltaY * .001)))
			})));
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []), n(() => {
		if (!z) return;
		let e = {
			context: new AudioContext(),
			voices: /* @__PURE__ */ new Map()
		};
		return Te.current = e, e.context.resume().catch(() => {}), () => {
			for (let t of e.voices.values()) t.oscillator.stop();
			e.context.close(), Te.current = null;
		};
	}, [z]), n(() => {
		let t = Te.current;
		if (!t) return;
		let n = new Set(C.parts.filter((e) => e.kind === "phonograph").map((e) => e.id));
		for (let [e, r] of t.voices) n.has(e) || (r.oscillator.stop(), t.voices.delete(e));
		for (let r of n) {
			let i = t.voices.get(r);
			if (!i) {
				let e = t.context.createOscillator(), n = t.context.createGain();
				e.type = "sine", n.gain.value = 0, e.connect(n), n.connect(t.context.destination), e.start(), i = {
					oscillator: e,
					gain: n
				}, t.voices.set(r, i);
			}
			let a = Math.abs(e.pose?.currents[r] ?? 0);
			i.oscillator.frequency.setTargetAtTime(Math.min(2400, 65 + a * 60), t.context.currentTime, .05), i.gain.gain.setTargetAtTime(y && a > .05 ? .035 / Math.max(1, n.size) : 0, t.context.currentTime, .04);
		}
	}, [
		C,
		e.pose,
		y
	]);
	let Pe = (e, t) => {
		let n = B.current.getBoundingClientRect();
		return {
			x: e - n.left,
			y: t - n.top
		};
	}, q = (e) => {
		let { origin: t, xAxis: n, yAxis: r } = F, i = n.x * r.y - n.y * r.x;
		return {
			x: ((e.x - t.x) * r.y - (e.y - t.y) * r.x) / i,
			y: ((e.y - t.y) * n.x - (e.x - t.x) * n.y) / i
		};
	}, Fe = M ? {
		...C,
		chains: C.chains.filter((e) => e.id !== M)
	} : C, J = (e) => v && (je > 0 || !!M) && !_.restrictions.lockedLevels?.some((t) => D(t) === D(e)) && pe(Fe, k, e, _.restrictions.noConnect), Y = (e) => C.parts.find((t) => F.centers[t.id] && Math.hypot(e.x - F.centers[t.id].x, e.y - F.centers[t.id].y) < (ye ? 24 : 16)), Ie = (e) => {
		J(e) && (he(void 0), k.length > 1 && e.part === k[0].part ? (r(M ? {
			type: "extend",
			id: M,
			connections: k
		} : {
			type: "chain",
			connections: k
		}), A([]), N(null), j(null), T(null)) : (A([...k, e]), j(null), T(null), O(null)));
	}, Le = (e) => {
		if (ge && v) {
			let t = q(e);
			r({
				type: "place",
				...ge,
				x: Math.round(t.x),
				y: Math.round(t.y)
			}), P(null);
			return;
		}
		if (k.length) return;
		let t = Y(e);
		if (t) {
			T(t.id), O(null), j(null), t.kind === "button" && !k.length && r({
				type: "toggle",
				id: t.id
			});
			return;
		}
		let n = F.wheels.map((t) => ({
			w: t,
			d: Math.hypot((e.x - t.x) / Math.max(t.rx, 20), (e.y - t.y) / Math.max(t.ry, 20))
		})).filter((e) => e.d < 1.35).sort((e, t) => e.d - t.d)[0];
		if (n) {
			T(n.w.part), O(null), j(null);
			return;
		}
		let i = null, a = 12;
		for (let t of C.chains) {
			let n = F.layers[t.connections[0].level] ?? {
				x: 0,
				y: 0
			}, r = fe(C.parts, t.connections).path.map((e) => ({
				x: F.origin.x + F.xAxis.x * e.x + F.yAxis.x * e.y + n.x,
				y: F.origin.y + F.xAxis.y * e.x + F.yAxis.y * e.y + n.y
			}));
			for (let n = 1; n < r.length; n++) {
				let o = r[n - 1], s = r[n], c = s.x - o.x, l = s.y - o.y, u = Math.max(0, Math.min(1, ((e.x - o.x) * c + (e.y - o.y) * l) / (c * c + l * l || 1))), d = Math.hypot(e.x - o.x - c * u, e.y - o.y - l * u);
				d < a && (a = d, i = t.id);
			}
		}
		O(i), T(null), j(null);
	}, Re = (t) => {
		if (I || t.target.closest("button,input,[role=dialog]")) return;
		be(t.pointerType !== "mouse");
		let n = Pe(t.clientX, t.clientY);
		if (H.current.set(t.pointerId, n), t.currentTarget.setPointerCapture(t.pointerId), H.current.size === 2) {
			let [e, t] = [...H.current.values()];
			U.current = {
				distance: Math.max(1, Math.hypot(e.x - t.x, e.y - t.y)),
				camera: Oe
			}, V.current = null, R(null);
			return;
		}
		let r = k.length ? void 0 : Y(n), i = r && F.wheels.filter((e) => e.part === r.id).at(-1);
		V.current = {
			pointer: t.pointerId,
			start: n,
			last: n,
			camera: Oe,
			moved: !1,
			part: r?.id,
			angle: i ? Math.atan2(n.y - i.y, n.x - i.x) : 0,
			target: r ? e.pose?.angles[r.id]?.[i?.level ?? 0] ?? 0 : 0,
			level: i?.level ?? 0,
			sent: 0
		};
	}, ze = (e) => {
		let t = Pe(e.clientX, e.clientY);
		if (H.current.has(e.pointerId) && H.current.set(e.pointerId, t), U.current && H.current.size === 2) {
			let [e, t] = [...H.current.values()];
			W({
				...U.current.camera,
				zoom: Math.max(.08, Math.min(4, U.current.camera.zoom * Math.hypot(e.x - t.x, e.y - t.y) / U.current.distance))
			});
			return;
		}
		let n = V.current;
		if (!n) {
			e.pointerType === "mouse" && j(null), he(q(t));
			return;
		}
		if (Math.hypot(t.x - n.start.x, t.y - n.start.y) > 5 && (n.moved = !0), !n.moved) return;
		let i = C.parts.find((e) => e.id === n.part);
		if (i && v && !i.fixed && !k.length) {
			let e = q(n.start), r = q(t);
			R({
				id: i.id,
				x: Math.round(i.x + r.x - e.x),
				y: Math.round(i.y + r.y - e.y)
			});
		} else if (i && y) {
			let a = F.centers[i.id], o = Math.atan2(t.y - a.y, t.x - a.x), s = Math.atan2(Math.sin(o - n.angle), Math.cos(o - n.angle));
			n.target = (n.target ?? 0) + s, n.angle = o, e.timeStamp - n.sent > 60 && (r({
				type: "hand",
				id: i.id,
				level: n.level,
				target: n.target
			}), n.sent = e.timeStamp);
		} else if (!i) {
			let e = q(n.start), r = q(t);
			W({
				...n.camera,
				x: n.camera.x - (r.x - e.x),
				y: n.camera.y - (r.y - e.y)
			});
		}
		n.last = t;
	}, Be = (e) => {
		if (H.current.delete(e.pointerId), U.current) {
			H.current.size || (U.current = null), V.current = null;
			return;
		}
		let t = V.current;
		V.current = null, t && (t.moved && L && r({
			type: "move",
			...L
		}), t.moved && t.part && y && r({
			type: "hand",
			id: t.part,
			level: t.level,
			target: null
		}), t.moved || Le(Pe(e.clientX, e.clientY)), R(null));
	}, X = a(null), Ve = v && !ge && !I && !L ? (k.length ? C.parts.flatMap((e) => [!0, !1].map((t) => ({
		part: e.id,
		level: k[0].level,
		cw: t
	}))) : G ? w(G).flatMap((e) => [!0, !1].map((t) => ({
		part: G.id,
		level: e,
		cw: t
	}))) : []).filter(J) : [], Z = () => Ce((e) => !e), He = (e) => g("games.spintronics.connect", {
		part: C.parts.find((t) => t.id === e.part)?.label ?? "",
		n: e.level + 1,
		direction: g(e.cw ? "games.spintronics.clockwise" : "games.spintronics.counterclockwise")
	});
	return /* @__PURE__ */ x(ne, {
		adaptive: !0,
		scroll: !1,
		className: "spintronics",
		banner: /* @__PURE__ */ S("header", {
			className: "spin-header",
			children: [
				/* @__PURE__ */ S("button", {
					className: "spin-level",
					onClick: () => ve("levels"),
					children: [_.code, /* @__PURE__ */ x("span", { children: g(ot[_.n].title) })]
				}),
				/* @__PURE__ */ S("button", {
					className: "spin-goal",
					onClick: () => ve("goal"),
					"aria-label": g("games.spintronics.goal"),
					children: [/* @__PURE__ */ x(d, { size: 20 }), /* @__PURE__ */ x("span", { children: g(ot[_.n].goal) })]
				}),
				/* @__PURE__ */ x("span", {
					className: `spin-phase ${e.phase === "passed" ? "spin-passed" : ""}`,
					"aria-live": "polite",
					children: g(ft[e.phase], {
						n: e.check.done,
						total: e.check.total
					})
				})
			]
		}),
		actionsHeight: "spin-actions-height",
		actions: /* @__PURE__ */ S("div", {
			className: "spin-actions",
			children: [/* @__PURE__ */ S("div", {
				className: "spin-tray",
				"aria-label": g("games.spintronics.available"),
				children: [Ae.map((e) => {
					let t = le(_, C, e.kind, e.value), n = ge && oe(ge) === oe(e);
					return /* @__PURE__ */ S("button", {
						disabled: !v || t <= 0,
						className: `spin-stock ${n ? "is-active" : ""}`,
						"aria-pressed": !!n,
						title: `${g(e.kind === "diode-kit" ? "games.spintronics.diodeKit" : ae[e.kind])} ${se({
							...e,
							kind: e.kind === "diode-kit" ? "junction" : e.kind
						})}`,
						onPointerDown: (n) => {
							!v || t <= 0 || (X.current = {
								stock: e,
								x: n.clientX,
								y: n.clientY,
								moved: !1
							}, n.currentTarget.setPointerCapture(n.pointerId));
						},
						onPointerMove: (e) => {
							let t = X.current;
							t && Math.hypot(e.clientX - t.x, e.clientY - t.y) > 8 && (t.moved = !0);
						},
						onPointerCancel: () => {
							X.current = null;
						},
						onClick: (t) => {
							t.detail === 0 && (P(e), A([]), N(null), T(null));
						},
						onPointerUp: (t) => {
							let n = X.current;
							X.current = null;
							let i = B.current?.getBoundingClientRect();
							if (n?.moved && i && t.clientX >= i.left && t.clientX <= i.right && t.clientY >= i.top && t.clientY <= i.bottom) {
								let e = q(Pe(t.clientX, t.clientY));
								r({
									type: "place",
									...n.stock,
									x: Math.round(e.x),
									y: Math.round(e.y)
								}), P(null);
							} else n?.moved || (P(e), A([]), T(null));
						},
						children: [
							/* @__PURE__ */ x(st, { kind: e.kind === "diode-kit" ? "diode" : e.kind }),
							/* @__PURE__ */ x("span", { children: se({
								...e,
								kind: e.kind === "diode-kit" ? "junction" : e.kind
							}) || g(e.kind === "diode-kit" ? "games.spintronics.diodeKit" : ae[e.kind]) }),
							/* @__PURE__ */ S("b", { children: ["×", t] })
						]
					}, oe(e));
				}), /* @__PURE__ */ x("span", {
					className: "spin-chain-count",
					children: g("games.spintronics.chains", { n: _.loops >= 60 ? "∞" : je })
				})]
			}), /* @__PURE__ */ x("div", {
				className: "spin-controls",
				children: k.length ? /* @__PURE__ */ S(b, { children: [
					/* @__PURE__ */ x("span", {
						className: "spin-chain-level",
						role: "status",
						children: g("games.spintronics.layer", { n: k[0].level + 1 })
					}),
					/* @__PURE__ */ S("button", {
						disabled: !!M && k.length <= (C.chains.find((e) => e.id === M)?.connections.length ?? 0),
						onClick: () => {
							A((e) => e.slice(0, -1)), j(null), he(void 0);
						},
						children: [/* @__PURE__ */ x(c, { size: 19 }), g("games.spintronics.back")]
					}),
					/* @__PURE__ */ S("button", {
						onClick: () => {
							A([]), N(null), j(null);
						},
						children: [/* @__PURE__ */ x(u, { size: 19 }), g("games.spintronics.cancel")]
					})
				] }) : /* @__PURE__ */ S(b, { children: [
					/* @__PURE__ */ x("button", {
						disabled: !v || !e.canUndo,
						onClick: () => r({ type: "undo" }),
						"aria-label": g("games.spintronics.undo"),
						title: g("games.spintronics.undo"),
						children: /* @__PURE__ */ x(c, { size: 21 })
					}),
					/* @__PURE__ */ x("button", {
						className: xe ? "danger-stripes" : "",
						disabled: !v,
						onClick: () => {
							xe ? (r({ type: "reset" }), Se(!1)) : Se(!0);
						},
						onBlur: () => Se(!1),
						children: g(xe ? "games.spintronics.confirmReset" : "games.spintronics.reset")
					}),
					v || e.phase === "paused" ? /* @__PURE__ */ S("button", {
						className: "spin-primary",
						onClick: () => {
							P(null), T(null), r({ type: "run" });
						},
						children: [/* @__PURE__ */ x(f, { size: 19 }), g(e.phase === "paused" ? "games.spintronics.resume" : "games.spintronics.start")]
					}) : y ? /* @__PURE__ */ x("button", {
						onClick: () => r({ type: "pause" }),
						children: g("games.spintronics.pause")
					}) : null,
					v ? /* @__PURE__ */ S("button", {
						className: "spin-primary",
						onClick: () => {
							T(null), r({ type: "check" });
						},
						children: [/* @__PURE__ */ x(l, { size: 19 }), g("games.spintronics.check")]
					}) : /* @__PURE__ */ x("button", {
						onClick: () => r({ type: "edit" }),
						children: g("games.spintronics.edit")
					}),
					e.phase === "passed" && _.n < 160 && /* @__PURE__ */ x("button", {
						className: "spin-primary",
						onClick: () => r({
							type: "goto",
							n: _.n + 1
						}),
						children: g("games.spintronics.next")
					})
				] })
			})]
		}),
		children: /* @__PURE__ */ S("div", {
			ref: B,
			className: `spin-stage ${ge ? "is-placing" : ""}`,
			role: "application",
			"aria-label": g("games.spintronics.board"),
			onPointerDown: Re,
			onPointerMove: ze,
			onPointerUp: Be,
			onPointerCancel: (e) => {
				H.current.delete(e.pointerId), V.current?.part && y && r({
					type: "hand",
					id: V.current.part,
					level: V.current.level,
					target: null
				}), V.current = null, U.current = null, R(null);
			},
			children: [
				/* @__PURE__ */ x(tt, {
					circuit: ke,
					pose: e.pose,
					previousPose: e.previousPose,
					running: y,
					speed: e.speed,
					camera: Oe,
					bounds: Ee,
					selected: ie,
					selectedChain: ue,
					draft: k,
					hover: de,
					tail: me,
					onProject: Me,
					fallback: /* @__PURE__ */ x("p", {
						className: "spin-fallback",
						children: g("games.spintronics.webgl")
					})
				}),
				/* @__PURE__ */ x("div", {
					className: "spin-labels",
					"aria-hidden": "true",
					children: C.parts.map((t) => {
						let n = F.centers[t.id];
						return n ? /* @__PURE__ */ S("span", {
							className: `spin-label ${t.fixed ? "" : "spin-movable"}`,
							style: {
								left: n.x,
								top: n.y + 25
							},
							children: [
								t.fixed ? "⌖ " : "↔ ",
								t.label,
								" ",
								se(t),
								e.pose && [
									"capacitor",
									"phonograph",
									"resistor",
									"inductor"
								].includes(t.kind) && /* @__PURE__ */ S("small", { children: [
									(t.kind === "capacitor" ? e.pose.volts[t.id] ?? 0 : e.pose.currents[t.id] ?? 0).toFixed(2),
									" ",
									t.kind === "capacitor" ? "V" : "mA"
								] })
							]
						}, t.id) : null;
					})
				}),
				Ve.length > 0 && /* @__PURE__ */ x(at, {
					projection: F,
					connections: Ve,
					parts: C.parts,
					draft: k,
					hover: de,
					levelName: (e) => g("games.spintronics.layer", { n: e + 1 }),
					name: He,
					onHover: j,
					onConnect: Ie
				}),
				/* @__PURE__ */ S("div", {
					className: "spin-camera",
					children: [
						/* @__PURE__ */ x("button", {
							"aria-label": g("games.spintronics.fit"),
							title: g("games.spintronics.fit"),
							onClick: Ne,
							children: /* @__PURE__ */ x(p, { size: 21 })
						}),
						/* @__PURE__ */ x("button", {
							"aria-label": g("games.spintronics.zoomIn"),
							onClick: () => W((e) => ({
								...e,
								zoom: Math.min(4, e.zoom * 1.25)
							})),
							children: /* @__PURE__ */ x(h, { size: 21 })
						}),
						/* @__PURE__ */ x("button", {
							"aria-label": g("games.spintronics.zoomOut"),
							onClick: () => W((e) => ({
								...e,
								zoom: Math.max(.08, e.zoom / 1.25)
							})),
							children: /* @__PURE__ */ x(ee, { size: 21 })
						}),
						/* @__PURE__ */ x("button", {
							"aria-pressed": z,
							"aria-label": g(z ? "games.spintronics.soundOff" : "games.spintronics.soundOn"),
							onClick: Z,
							title: g(z ? "games.spintronics.soundOff" : "games.spintronics.soundOn"),
							children: z ? "♪" : "♩"
						})
					]
				}),
				ge && /* @__PURE__ */ S("div", {
					className: "spin-instruction",
					role: "status",
					children: [g("games.spintronics.place"), /* @__PURE__ */ x("button", {
						onClick: () => P(null),
						"aria-label": g("games.spintronics.cancel"),
						children: /* @__PURE__ */ x(u, { size: 18 })
					})]
				}),
				de && /* @__PURE__ */ x("div", {
					className: "spin-hover-name",
					children: He(de)
				}),
				G && !k.length && /* @__PURE__ */ S("section", {
					className: "spin-inspector",
					"aria-label": g("games.spintronics.selected"),
					children: [
						/* @__PURE__ */ S("div", {
							className: "spin-inspector-title",
							children: [
								/* @__PURE__ */ S("strong", { children: [
									G.label,
									" · ",
									g(ae[G.kind])
								] }),
								/* @__PURE__ */ x("span", { children: g(G.fixed ? "games.spintronics.fixed" : "games.spintronics.movable") }),
								/* @__PURE__ */ x("button", {
									"aria-label": g("games.spintronics.close"),
									onClick: () => T(null),
									children: /* @__PURE__ */ x(u, { size: 18 })
								})
							]
						}),
						G.kind === "button" && /* @__PURE__ */ x("button", {
							disabled: e.phase === "checking",
							onClick: () => r({
								type: "toggle",
								id: G.id
							}),
							children: g(G.on ? "games.spintronics.on" : "games.spintronics.off")
						}),
						G.kind === "motor" && /* @__PURE__ */ x("button", {
							disabled: e.phase === "checking",
							onClick: () => r({
								type: "power",
								id: G.id
							}),
							children: g(G.on ? "games.spintronics.powerOff" : "games.spintronics.powerOn")
						}),
						G.kind === "capacitor" && v && /* @__PURE__ */ S("label", { children: [
							g("games.spintronics.charge"),
							/* @__PURE__ */ x("input", {
								type: "number",
								min: -24,
								max: 24,
								step: .5,
								value: G.initial,
								onChange: (e) => {
									let t = Number(e.target.value);
									Number.isFinite(t) && Math.abs(t) <= 24 && r({
										type: "charge",
										id: G.id,
										value: t
									});
								}
							}),
							" V"
						] }),
						G.kind === "transistor" && y && /* @__PURE__ */ x("div", {
							className: "spin-gate-controls",
							children: [!1, !0].map((e) => /* @__PURE__ */ x("button", {
								onClick: () => r({
									type: "hand",
									id: G.id,
									level: 2,
									target: (G.value ? 1 : -1) * (e ? Math.PI / 4 : Math.PI * 2 * .018)
								}),
								children: g(e ? "games.spintronics.openGate" : "games.spintronics.closeGate")
							}, String(e)))
						}),
						G.kind === "transistor" && v && !G.fixed && /* @__PURE__ */ x("button", {
							onClick: () => r({
								type: "flip",
								id: G.id
							}),
							children: g("games.spintronics.flip")
						}),
						v && !G.fixed && /* @__PURE__ */ S("button", {
							onClick: () => {
								r({
									type: "remove",
									id: G.id
								}), T(null);
							},
							children: [/* @__PURE__ */ x(m, { size: 16 }), g("games.spintronics.remove")]
						})
					]
				}),
				K && /* @__PURE__ */ S("div", {
					className: "spin-chain-inspector",
					children: [
						/* @__PURE__ */ x("button", {
							disabled: !v || K.id.startsWith("k"),
							onClick: () => {
								N(K.id), A(K.connections), O(null), T(null);
							},
							children: g("games.spintronics.extendChain")
						}),
						/* @__PURE__ */ S("button", {
							disabled: !v || K.fixed,
							onClick: () => {
								r({
									type: "unchain",
									id: K.id
								}), O(null);
							},
							children: [/* @__PURE__ */ x(m, { size: 17 }), g("games.spintronics.removeChain")]
						}),
						/* @__PURE__ */ x("button", {
							onClick: () => O(null),
							"aria-label": g("games.spintronics.close"),
							children: /* @__PURE__ */ x(u, { size: 18 })
						})
					]
				}),
				e.failure && /* @__PURE__ */ x("div", {
					className: "spin-feedback",
					role: "status",
					children: g(pt[e.failure])
				}),
				I && /* @__PURE__ */ x("div", {
					className: "spin-panel-backdrop",
					onClick: () => ve(null),
					children: /* @__PURE__ */ S("section", {
						ref: we,
						className: "spin-panel",
						role: "dialog",
						"aria-modal": "true",
						"aria-label": g(I === "levels" ? "games.spintronics.choose" : "games.spintronics.goal"),
						onClick: (e) => e.stopPropagation(),
						children: [/* @__PURE__ */ S("div", {
							className: "spin-panel-title",
							children: [/* @__PURE__ */ x("strong", { children: g(I === "levels" ? "games.spintronics.choose" : "games.spintronics.goal") }), /* @__PURE__ */ x("button", {
								autoFocus: !0,
								onClick: () => ve(null),
								"aria-label": g("games.spintronics.close"),
								children: /* @__PURE__ */ x(u, { size: 22 })
							})]
						}), I === "levels" ? [
							"one",
							"two",
							"power"
						].map((e) => /* @__PURE__ */ S("section", { children: [/* @__PURE__ */ x("h3", { children: g(ht[e]) }), /* @__PURE__ */ x("div", {
							className: "spin-level-grid",
							children: ce.filter((t) => t.book === e).map((e) => /* @__PURE__ */ S("button", {
								title: g(ot[e.n].title),
								"aria-current": e.n === _.n ? "step" : void 0,
								className: ut().includes(e.n) ? "is-complete" : "",
								onClick: () => {
									ve(null), e.n !== _.n && r({
										type: "goto",
										n: e.n
									});
								},
								children: [e.code, ut().includes(e.n) && /* @__PURE__ */ x("span", { children: "✓" })]
							}, e.n))
						})] }, e)) : /* @__PURE__ */ S(b, { children: [
							/* @__PURE__ */ S("h3", { children: [
								_.code,
								" · ",
								g(ot[_.n].title)
							] }),
							/* @__PURE__ */ x("p", { children: g(ot[_.n].goal) }),
							_.diagram && /* @__PURE__ */ S("figure", { children: [/* @__PURE__ */ x("svg", {
								role: "img",
								"aria-label": g("games.spintronics.diagram"),
								viewBox: `0 0 ${_.diagram.width} ${_.diagram.height}`,
								children: /* @__PURE__ */ x("path", {
									d: _.diagram.path,
									fill: "currentColor"
								})
							}), /* @__PURE__ */ x("figcaption", { children: g("games.spintronics.diagram") })] }),
							/* @__PURE__ */ x("p", {
								className: "spin-source",
								children: g("games.spintronics.sourceAttribution")
							})
						] })]
					})
				})
			]
		})
	});
}
//#endregion
//#region src/games/spintronics/guide.tsx
function vt() {
	let e = s();
	return /* @__PURE__ */ S("div", { children: [/* @__PURE__ */ x("div", {
		className: "grid grid-cols-3 gap-3 py-3",
		children: [
			"motor",
			"resistor",
			"junction",
			"button",
			"capacitor",
			"inductor",
			"transistor",
			"phonograph"
		].map((t) => /* @__PURE__ */ S("div", {
			className: "flex flex-col items-center text-center text-xs",
			children: [/* @__PURE__ */ x("div", {
				className: "h-16 w-16",
				children: /* @__PURE__ */ x(st, { kind: t })
			}), e(ae[t])]
		}, t))
	}), /* @__PURE__ */ S("p", {
		className: "text-xs leading-relaxed",
		children: [
			e("games.spintronics.sourceAttribution"),
			" ",
			/* @__PURE__ */ x("a", {
				className: "underline",
				href: "https://creativecommons.org/licenses/by-nc-sa/4.0/",
				target: "_blank",
				rel: "noreferrer",
				children: e("games.spintronics.sourceLicense")
			})
		]
	})] });
}
//#endregion
//#region .bgparty/cache/pack-entry/spintronics/entry.tsx
var yt = {
	definition: Be,
	View: gt,
	Guide: vt,
	locales: {
		zh: {
			name: "自旋电路",
			desc: "用链条、分流器与机械零件搭出电路，挑战三册机械谜题",
			rules: "目标：\n用初始电路和库存完成目标。第一幕 1—67，第二幕 68—149，动力包 P1—P11。\n搭建：\n· 从托盘拖出零件，或先点零件再点空位。拖零件中心可以移动。\n· 带固定标记的初始件不能移动或移除。蓝色标记表示可以移动或拆除。\n· 先点选零件，再点击轮外标有层号的蓝色短弧线，选定起始层级与绕向。\n· 接点标注层级，同一链条只能连接同层链轮。\n· 牵链时，仅提示当前层的可用位置；点击蓝色方向弧线接入链轮，最后点击起点弧线闭环。\n· 悬停或聚焦箭头可预览链路，点击后固定绕向。可以退回一步或取消。\n· 点击已有链条，可以拆除允许移动的链，或选择“加入链轮”后重新闭环。\n· 拖空白处平移，滚轮或双指缩放；居中按钮显示全盘。\n机械与电路：\n· 链轮转速对应电流，转向对应电流方向，转动力矩对应电压。\n· 同一链条串联路径上的零件。电阻阻碍转动，断开的开关锁住链轮。\n· 电容储存扭转能量，显示电压；电感通过飞轮储存运动能量。\n· 分流器三个轮独立转动，下层轮电流等于中层与上层轮电流之和。\n· 晶体管上层是闸门，下层是通道。反向安装改变闸门打开的方向。\n· 二极管组合包含分流器、晶体管及内部链条，移动时保持一体。\n运行：\n· 启动后可点击开关、拖动轮心手动转动，也可用零件操作开闭闸门。\n· 电容与电流读数随运行变化；电流表转得越快，音调越高。声音需手动开启。\n· 电池短路会断路，返回搭建可恢复。储能耗尽后，电池停止供力。\n· 可以单独切断电池，观察备用电源的工作情况。\n检验：\n· 检验从初态运行，尝试开关组合和手动输入，比较电压、电流及变化过程。\n· 等效的绕法可以通过。开发版数值近似机械模型，有限输入检验并非严格证明。\n· 题册图示和目标仍是最终依据。已完成关卡保存在本机。\n· 房间保留各关搭建，重置只恢复当前关。",
			motor: "电池",
			resistor: "电阻",
			junction: "分流器",
			button: "开关",
			capacitor: "电容",
			inductor: "电感",
			transistor: "晶体管",
			levelChanger: "换层器",
			diode: "二极管",
			diodeKit: "二极管组合",
			phonograph: "电流表",
			choose: "选择关卡",
			level: "第 {{n}} 关",
			bookOne: "第一幕",
			bookTwo: "第二幕",
			bookPower: "动力包",
			build: "搭建中",
			running: "运行中",
			paused: "已暂停",
			checking: "检验 {{n}} / {{total}}",
			passed: "挑战完成",
			failed: "未达成目标",
			unverified: "需要核对题意",
			start: "启动",
			pause: "暂停",
			resume: "继续",
			edit: "返回搭建",
			check: "检验",
			next: "下一关",
			goal: "关卡目标",
			diagram: "题册图示",
			available: "可用零件",
			chains: "链环 {{n}}",
			place: "选择放置位置",
			undo: "撤销",
			back: "退回一轮",
			cancel: "取消",
			close: "关闭",
			remove: "移除零件",
			removeChain: "拆除链条",
			extendChain: "加入链轮",
			reset: "重置",
			resetQuestion: "恢复本关初始布局？",
			confirmReset: "确认重置",
			fit: "居中",
			zoomIn: "放大",
			zoomOut: "缩小",
			speed: "速度",
			layer: "第 {{n}} 层",
			clockwise: "顺时针",
			counterclockwise: "逆时针",
			connect: "{{part}}，第 {{n}} 层，{{direction}}",
			selected: "零件操作",
			fixed: "固定",
			movable: "可移动",
			on: "接通",
			off: "断开",
			charge: "初始电压",
			openGate: "打开闸门",
			closeGate: "关闭闸门",
			flip: "反向安装",
			powerOff: "切断电池",
			powerOn: "恢复供电",
			soundOn: "开启声音",
			soundOff: "关闭声音",
			board: "机械电路盘面",
			webgl: "此设备无法显示 3D 盘面。请使用支持 WebGL 2 的浏览器。",
			short: "电池已断路，请检查是否短路。",
			missing: "还没有完整电路。",
			goalFailure: "有输入下的输出未达到目标，可以返回搭建调整。",
			unsupported: "请结合题册目标检查电路。",
			invalid: "此操作当前不可用。",
			sourceAttribution: "题册关卡、图示与封面：Paul Boswell / Upper Story，插画 Aleksandar Zolotić，© 2022，CC BY-NC-SA 4.0。本版翻译了目标并裁切图示。交互参考官网模拟器；三维模型与求解器由本项目实现。",
			sourceLicense: "查看题册素材许可",
			levels: {
				c001: {
					title: "电阻",
					goal: "先运行初始电路，再用可用零件使它转得更慢。"
				},
				c002: {
					title: "另一种解法",
					goal: "使电路转得更慢，但不能再向 R1 添加链条。"
				},
				c003: {
					title: "一条链，两个电阻",
					goal: "只用一条链环，使两个电阻都顺时针转动。"
				},
				c004: {
					title: "顺时针与逆时针",
					goal: "使一个电阻顺时针转动，另一个逆时针转动。"
				},
				c005: {
					title: "只向逆时针",
					goal: "使两个电阻都逆时针转动。"
				},
				c006: {
					title: "开关",
					goal: "用开关控制 R1 转动或停止。"
				},
				c007: {
					title: "环路中的开关",
					goal: "用开关控制 R1 转动或停止。"
				},
				c008: {
					title: "与门",
					goal: "只有 S1、S2 都接通时，电阻才转动。"
				},
				c009: {
					title: "发出声音",
					goal: "使电流表 A1 转动。电流表的阻力很小，须用电阻避免短路。"
				},
				c010: {
					title: "声音开关",
					goal: "用开关控制 A1 转动或停止。"
				},
				c011: {
					title: "低音",
					goal: "只选用一个可用电阻，使 A1 的音调比上一关更低。"
				},
				c012: {
					title: "最低音",
					goal: "利用可用零件，使 A1 发出尽可能低的音调。"
				},
				c013: {
					title: "第一张电路图",
					goal: "搭出图示电路。等效的连接方式也可以。"
				},
				c014: {
					title: "等效电路",
					goal: "搭出图示电路。可以继续寻找其他等效解法。"
				},
				c015: {
					title: "简化电路图",
					goal: "搭出图示电路。"
				},
				c016: {
					title: "交叉跨越",
					goal: "搭出图示电路。拱形跨线表示两条导线相交但不连接。"
				},
				c017: {
					title: "修复短路",
					goal: "修复短路，且不能再向电池添加链条。"
				},
				c018: {
					title: "堵住漏洞",
					goal: "修复所有短路，且不能再向电池添加链条。进阶：只用一个电阻。"
				},
				c019: {
					title: "或门",
					goal: "S1、S2 只要有一个接通，A1 就转动；两者均断开时停止。"
				},
				c020: {
					title: "最大电流在哪里",
					goal: "在初始电路中接入电流表，使它处于电流最大、音调最高的位置。"
				},
				c021: {
					title: "最小电流在哪里",
					goal: "在初始电路中接入电流表，使它处于电流最小、音调最低的位置。"
				},
				c022: {
					title: "并联电阻",
					goal: "先运行初始电路，再使 A1 的音调略微升高。蓝色标记的件和链可以移动或拆除。"
				},
				c023: {
					title: "音调开关",
					goal: "S1 接通时，A1 的音调应高于 S1 断开时。"
				},
				c024: {
					title: "改变层级",
					goal: "把 J1 与 J2 连通，完成电路。用于换层的开关须始终接通。"
				},
				c025: {
					title: "串并联组合",
					goal: "搭出图示电路。"
				},
				c026: {
					title: "双重分流",
					goal: "搭出图示电路。"
				},
				c027: {
					title: "串并联组合 2",
					goal: "搭出图示电路。"
				},
				c028: {
					title: "串并联组合 3",
					goal: "搭出图示电路。"
				},
				c029: {
					title: "串并联组合 4",
					goal: "搭出图示电路。只需使用一个分流器。"
				},
				c030: {
					title: "串并联组合 5",
					goal: "搭出图示电路。"
				},
				c031: {
					title: "给电容充电",
					goal: "使电池为电容充电。开始前将电容电压设为 0 V。"
				},
				c032: {
					title: "按下充电",
					goal: "S1 接通时给 C1 充电；S1 断开后，C1 保持电荷。"
				},
				c033: {
					title: "缓慢充电",
					goal: "使电容的充电速度比上一关更慢。"
				},
				c034: {
					title: "啾声",
					goal: "首次接通 S1 时，A1 短暂转动，然后停止。"
				},
				c035: {
					title: "充电与放电 1",
					goal: "用 S1 为 C1 充电，用 S2 为 C1 放电。"
				},
				c036: {
					title: "充电与放电 2",
					goal: "使 C1 的充电和放电速度都变慢。"
				},
				c037: {
					title: "充电与放电 3",
					goal: "使 S1、S2 同时接通时也不会发生短路。"
				},
				c038: {
					title: "充电与放电 4",
					goal: "使 C1 每次充电或放电时，A1 都转动发声。"
				},
				c039: {
					title: "自动放电",
					goal: "S1 接通时，C1 充电；S1 断开时，C1 放电。"
				},
				c040: {
					title: "缓升缓降",
					goal: "S1 接通后，C1 缓慢充电；S1 断开后，C1 缓慢放电。"
				},
				c041: {
					title: "电容备用电源",
					goal: "S1 短暂切断电池供电后，A1 仍继续转动一段时间。"
				},
				c042: {
					title: "测量电池电压",
					goal: "用电容测量电池电压，并使用电阻减少过冲。"
				},
				c043: {
					title: "负电压",
					goal: "使 C1 上的电压约为 −6 V。"
				},
				c044: {
					title: "电池电压是否恒定",
					goal: "在电池经 R1 放电时，持续测量电池电压。"
				},
				c045: {
					title: "分压器：2 V",
					goal: "使 C1 上的电压约为 2 V，允许范围为 2～3 V。"
				},
				c046: {
					title: "分压器：5 V",
					goal: "使 C1 上的电压为 4.5～5.5 V。进阶：改为 1～2 V。"
				},
				c047: {
					title: "电压降",
					goal: "测量 R2 两端、即图中 A 与 B 两点之间的电压差。"
				},
				c048: {
					title: "非门",
					goal: "S1 接通时 C1 约为 0 V；断开时约为 6 V。−6 V 也可以。"
				},
				c049: {
					title: "与非门",
					goal: "S1、S2 均接通时，C1 约为 0 V；其余情况约为 ±6 V。"
				},
				c050: {
					title: "或非门",
					goal: "S1、S2 只要有一个接通，C1 就约为 0 V；两者均断开时约为 ±6 V。"
				},
				c051: {
					title: "反向音调开关",
					goal: "S1 断开时，A1 应比 S1 接通时转得更快。"
				},
				c052: {
					title: "分流器转向",
					goal: "使 R1 逆时针转动，R2 顺时针转动。"
				},
				c053: {
					title: "分流器转向 2",
					goal: "使 R1、R2 都顺时针转动。"
				},
				c054: {
					title: "锁住电路",
					goal: "搭出一个使电池无法转动的电路。"
				},
				c055: {
					title: "分流器点图 1",
					goal: "搭出图示电路，并检查三个电阻的转向。"
				},
				c056: {
					title: "分流器点图 2",
					goal: "搭出图示电路，并检查三个电阻的转向。"
				},
				c057: {
					title: "全部同向",
					goal: "使三个电阻并联，并都顺时针转动。"
				},
				c058: {
					title: "耦合图 1",
					goal: "搭出图示耦合电路。"
				},
				c059: {
					title: "耦合图 2",
					goal: "搭出图示耦合电路。"
				},
				c060: {
					title: "耦合图 3",
					goal: "搭出图示耦合电路。"
				},
				c061: {
					title: "电压倍增",
					goal: "使 C1 上的电压达到 +12 V。"
				},
				c062: {
					title: "电压减半",
					goal: "使 C1 上的电压达到 +3 V。"
				},
				c063: {
					title: "电压四倍",
					goal: "使 A1 的转速变为初始电路的四倍。接通的开关也可以耦合环路或换层。"
				},
				c064: {
					title: "电压三倍",
					goal: "使 A1 的转速变为初始电路的三倍。"
				},
				c065: {
					title: "锁住电路 2",
					goal: "用可用零件搭出完全无法转动的电路。"
				},
				c066: {
					title: "极性双按钮",
					goal: "S1 接通时，A1 顺时针转动；S2 接通时，A1 逆时针转动。不考查两者同时接通的情况。"
				},
				c067: {
					title: "极性按钮",
					goal: "S1 断开时，A1 顺时针转动；S1 接通时，A1 逆时针转动。"
				},
				c068: {
					title: "按下充电 2",
					goal: "S1 接通时，C1、C2 都充到 6 V；断开后，两者都保持电荷。"
				},
				c069: {
					title: "自动放电 2",
					goal: "S1 接通时，C1、C2 都充到 6 V；断开后，两者都放电到 0 V。"
				},
				c070: {
					title: "两种电压",
					goal: "使 C1 为 6 V，C2 约为 3 V。须用分压器产生 C2 的 3 V。"
				},
				c071: {
					title: "更大的备用电容",
					goal: "使 S1 短暂切断电池供电时，A1 的转速受到的影响比初始电路更小。"
				},
				c072: {
					title: "串联电容",
					goal: "使开关从断开切到接通，或从接通切到断开时，声音都比初始电路更短。"
				},
				c073: {
					title: "电容量加倍",
					goal: "使在 S1 处感受到的等效电容量加倍。题册中的 C2 仅供比较。"
				},
				c074: {
					title: "电容量减半",
					goal: "使在 S1 处感受到的等效电容量减半。题册中的 C2 仅供比较。"
				},
				c075: {
					title: "搭出 0.004 F 电容",
					goal: "使 S1 处的等效电容量为 0.004 F。题册中的 C2 仅供比较。"
				},
				c076: {
					title: "搭出 0.00025 F 电容",
					goal: "使 S1 处的等效电容量为 0.00025 F。题册中的 C2 仅供比较。"
				},
				c077: {
					title: "晶体管开关",
					goal: "手动打开或关闭 T1 的闸门时，A1 也相应转动或停止。"
				},
				c078: {
					title: "有源区",
					goal: "手动调整 T1 闸门的位置，连续控制 C1 上的电压。"
				},
				c079: {
					title: "换层器 2",
					goal: "利用电池的动力打开 T1 闸门。T1 的通道不连接其他零件。"
				},
				c080: {
					title: "闸门充电",
					goal: "S1 接通时打开 T1，S1 断开时关闭 T1。通道不连接其他零件。"
				},
				c081: {
					title: "闸门充电 2",
					goal: "S1 接通时 A1 转动，S1 断开时 A1 停止。"
				},
				c082: {
					title: "放大 1",
					goal: "S1 接通时打开 T1 的闸门，S1 断开时关闭闸门。"
				},
				c083: {
					title: "放大 2",
					goal: "S1 接通时，使 A1 以较高转速转动；S1 断开时，A1 停止。"
				},
				c084: {
					title: "晶体管电路图 1",
					goal: "搭出图示电路。"
				},
				c085: {
					title: "晶体管电路图 2",
					goal: "搭出图示电路。"
				},
				c086: {
					title: "晶体管电路图 3",
					goal: "搭出图示电路。"
				},
				c087: {
					title: "电压放大器",
					goal: "搭出手动电压源，控制 T1 闸门，并将较小的正输入电压放大到 C1。"
				},
				c088: {
					title: "负电压放大器",
					goal: "将手动电压源的负电压放大为 C1 上较大的正电压。"
				},
				c089: {
					title: "正负电压放大器",
					goal: "手动电压源的正电压或负电压都应变为 C1 上较大的正电压。"
				},
				c090: {
					title: "达林顿对",
					goal: "使用两级晶体管放大，将手动电压源先放大一次，再放大到 C1。"
				},
				c091: {
					title: "加法",
					goal: "C1 显示电池电压加上手动电压源的电压。例如输入 2 V 时显示 8 V，输入 −3 V 时显示 3 V。"
				},
				c092: {
					title: "减法 1",
					goal: "C1 显示电池电压减去手动电压源的电压。例如输入 2 V 时显示 4 V，输入 −3 V 时显示 9 V。"
				},
				c093: {
					title: "减法 2",
					goal: "C1 显示手动电压源的电压减去电池电压。例如输入 2 V 时显示 −4 V，输入 −3 V 时显示 −9 V。"
				},
				c094: {
					title: "电路算术",
					goal: "初始电路的 C1、C2 显示两个分压器的电压。修改电路，显示 C1 − C2 的结果；只需保留一个电容。"
				},
				c095: {
					title: "晶体管偏置 1",
					goal: "用分压器向 T1 闸门施加约 1 V，将其置于有源区中段。C1 应约为 4 V，允许范围为 1～5 V。"
				},
				c096: {
					title: "晶体管偏置 2",
					goal: "在分压器电压上叠加手动电压源，使 C1 放大小幅的正、负输入电压。"
				},
				c097: {
					title: "一端关闭",
					goal: "除手动电压源高于 +6 V 的情况外，A1 都应转动。"
				},
				c098: {
					title: "两端关闭",
					goal: "手动电压源在 −6 V 到 +6 V 之间时，A1 转动；超出两端阈值时停止。"
				},
				c099: {
					title: "电流转电压 1",
					goal: "将手动电流源的电流转换为 C1 上的电压。"
				},
				c100: {
					title: "电流转电压 2",
					goal: "再将 C1 上的正电压放大为 C2 上更大的电压。"
				},
				c101: {
					title: "晶体管二极管",
					goal: "使 S1 只能顺时针转动。进阶：改为只能逆时针转动。"
				},
				c102: {
					title: "两个二极管",
					goal: "手动顺时针转动 S1 时，A1 转动；逆时针转动 S1 时，R1 转动。"
				},
				c103: {
					title: "全波整流",
					goal: "不论手动向哪个方向转动 S1，A1 都顺时针转动。进阶：改为都逆时针转动。"
				},
				c104: {
					title: "正向限幅",
					goal: "C1 显示手动施加到 S1 的电压，但不能超过 +1.5 V。"
				},
				c105: {
					title: "正负限幅",
					goal: "C1 显示手动施加到 S1 的电压，并将其限制在 −1.5 V 到 +1.5 V 之间。"
				},
				c106: {
					title: "峰值检测",
					goal: "C1 始终保持手动电压源曾施加过的最高电压。"
				},
				c107: {
					title: "带复位的峰值检测",
					goal: "保留峰值检测功能，并让复位开关把 C1 恢复到 0 V。"
				},
				c108: {
					title: "电压限制器",
					goal: "把手动电压源能产生的最高电压限制在约 +3.5 V；实物允许约 4～5 V。"
				},
				c109: {
					title: "电感",
					goal: "S1 接通后，A1 的转速逐渐升高；断开后按图示停止。"
				},
				c110: {
					title: "反射器",
					goal: "使 A1 的电流按图示随 S1 改变，保留图中平坦的区段。"
				},
				c111: {
					title: "电感反冲",
					goal: "S1 接通时 L1 转动；S1 断开后，为 L1 中储存的能量提供释放通路。"
				},
				c112: {
					title: "电感量减半",
					goal: "使在 S1 处感受到的等效电感量减为 L1 的一半。"
				},
				c113: {
					title: "电感量四倍",
					goal: "使在 S1 处感受到的等效电感量变为 L1 的四倍。"
				},
				c114: {
					title: "电感与二极管电路图 1",
					goal: "搭出图示电路。"
				},
				c115: {
					title: "电感与二极管电路图 2",
					goal: "搭出图示电路。"
				},
				c116: {
					title: "电感与二极管电路图 3",
					goal: "搭出图示电路。"
				},
				c117: {
					title: "交流叠加直流",
					goal: "把手动电压源的交流信号叠加到电池的 6 V 直流信号上。"
				},
				c118: {
					title: "高通滤波",
					goal: "来回转动 S1 输入交流信号。让高频成分传到 C1，同时阻断直流成分。"
				},
				c119: {
					title: "低通滤波",
					goal: "来回转动 S1 输入交流信号。让低频及直流成分传到 C1，同时抑制高频成分。"
				},
				c120: {
					title: "平滑输出",
					goal: "改进全波整流电路，把两个电容并联，使 A1 的电流更接近恒定。"
				},
				c121: {
					title: "高通滤波 2",
					goal: "来回转动 S1，让高频成分传到 A1，同时削弱低频成分。"
				},
				c122: {
					title: "低通滤波 2",
					goal: "来回转动 S1，让低频及直流成分传到 A1，同时削弱高频成分。"
				},
				c123: {
					title: "带通滤波",
					goal: "来回转动 S1，让中等频率信号传到 C1，同时削弱低频和高频成分。"
				},
				c124: {
					title: "降压转换器 1",
					goal: "快速切换 S1，搭出图示降压电路，为 100 Ω 等效负载供电。"
				},
				c125: {
					title: "降压转换器 2",
					goal: "加入由 C1、C2 组成的低通滤波器，减小输出电压的波动。快速切换 S1。"
				},
				c126: {
					title: "升压转换器 1",
					goal: "S1 接通时给电感储能；S1 断开时，电感向 A1 释放一股电流。"
				},
				c127: {
					title: "升压转换器 2",
					goal: "用高于电池电压的电压驱动 R1。使用二极管防止能量倒流，并用两个电容平滑输出。"
				},
				c128: {
					title: "同步开关",
					goal: "连接 T1、T2 的闸门，使其中一个始终打开。顺时针转动闸门时 L1 转动，否则 A1 转动。"
				},
				c129: {
					title: "极性翻转",
					goal: "向两个方向切换同步开关，使 C1 分别为 +6 V、−6 V，并同时控制 A1 的转向。"
				},
				c130: {
					title: "同步升压转换器",
					goal: "用同步开关替代开关和二极管，来回切换，为 R1 提供高于电池的电压。"
				},
				c131: {
					title: "同步降压转换器",
					goal: "用同步开关替代开关和二极管，来回切换，为 100 Ω 等效负载供电。"
				},
				c132: {
					title: "电压尖峰",
					goal: "不用电感或电压倍增器，使 C1 出现超过 7 V 的尖峰。可先给电容充电，再将其与电池串联。"
				},
				c133: {
					title: "基本反馈",
					goal: "T1 起初关闭；手动打开闸门后，电路应使闸门自行保持打开。"
				},
				c134: {
					title: "按 S1 启动",
					goal: "接通 S1 启动 A1；之后即使 S1 断开，A1 仍持续转动。T1 闸门须由 200 Ω 电阻的反馈电压控制，不能与 S1 串联。"
				},
				c135: {
					title: "基本振荡器",
					goal: "S1 接通时给 L1 储能；S1 断开后，电路来回振荡一段时间。"
				},
				c136: {
					title: "它会振荡吗",
					goal: "搭出由 T1 控制的非门，再把非门输出接回 T1 的闸门，观察结果。"
				},
				c137: {
					title: "延迟反馈",
					goal: "修改初始电路，为反馈加入延迟。"
				},
				c138: {
					title: "平滑振荡器",
					goal: "加入电容，吸收电感打开晶体管闸门后剩余的能量，使振荡更平滑。"
				},
				c139: {
					title: "张弛振荡器 1",
					goal: "搭出缓冲门：手动打开或关闭 T1，输出 C1 和 A1 相应改变。"
				},
				c140: {
					title: "张弛振荡器 2",
					goal: "保留原缓冲门，并联一个由 T2 控制的非门，输出显示在 C2 上。"
				},
				c141: {
					title: "张弛振荡器 3",
					goal: "移除 C1、C2；将非门输出接到缓冲门输入，再将缓冲门输出接到非门输入，形成振荡器。"
				},
				c142: {
					title: "恒流源 1",
					goal: "向 T1 闸门施加 −2 V，使闸门完全打开。注意初始闸门的转向。"
				},
				c143: {
					title: "恒流源 2",
					goal: "连接 S1 与 A1，使手动转动 S1 时 A1 以四倍速度转动。此时不连接电池。"
				},
				c144: {
					title: "恒流源 3",
					goal: "为 S1 提供近似恒定的电流，即使对 S1 施加少量阻力，电流也不明显改变。用 200 Ω 电阻给 T1 提供负反馈。"
				},
				c145: {
					title: "触发器 1",
					goal: "并联两个非门：T1 控制的门在 C1 上输出 −6 V，T2 控制的门在 C2 上输出 +6 V。"
				},
				c146: {
					title: "触发器 2：施密特触发器",
					goal: "移除 C1、C2。手动打开或关闭任一晶体管闸门后，闸门应保持该位置。"
				},
				c147: {
					title: "触发器 3",
					goal: "用 S1、S2 改变触发器状态，代替直接手动转动闸门，并用 C1 显示状态。"
				},
				c148: {
					title: "异或门",
					goal: "S1、S2 恰有一个接通时，A1 转动；两者均接通或均断开时停止。"
				},
				c149: {
					title: "脉冲发生器",
					goal: "每次接通 S1 时，让 A1 短暂转动，随后停止。"
				},
				c150: {
					title: "电池串联",
					goal: "将两块电池串联，并在 C1 上测量它们的总电压。"
				},
				c151: {
					title: "相互对抗的电池",
					goal: "连接两块电池，使它们以相等的力互相抵抗，不产生电流。"
				},
				c152: {
					title: "电池并联",
					goal: "将两块电池并联，为电阻 LOAD 供电。"
				},
				c153: {
					title: "更容易充电",
					goal: "将电池并联为 LOAD 供电，并增加开关，以便分别切断每块电池后为其充电。"
				},
				c154: {
					title: "单向电池",
					goal: "将电池并联为 LOAD 供电，并用两个二极管使每块电池只能向一个方向转动。"
				},
				c155: {
					title: "选择电池 1",
					goal: "S1 断开时 T1 关闭、T2 打开；S1 接通时 T1 打开、T2 关闭。此关只使用 B1 供电。"
				},
				c156: {
					title: "选择电池 2",
					goal: "S1 接通时由 B1 驱动 A1；S1 断开时由 B2 驱动 A1。"
				},
				c157: {
					title: "断路器 1",
					goal: "手动转动 T1 的闸门，用分流电阻 R1 观测通道电流，并让 C1 显示 R1 两端电压。"
				},
				c158: {
					title: "断路器 2",
					goal: "增加产生 −2 V 的分压器，利用它让 T2 的闸门默认保持打开。"
				},
				c159: {
					title: "断路器 3",
					goal: "R1 两端电压超过 2 V 时，T2 自动关闭并保持关闭，切断电路。"
				},
				c160: {
					title: "备用电池",
					goal: "起初只由 B1 驱动 A1；B1 耗尽后，电路自动切换为 B2 供电。"
				}
			}
		},
		en: {
			name: "Spintronics",
			desc: "Build mechanical circuits with chains and junctions across three puzzle books",
			rules: "Goal:\nUse the starting circuit and inventory. Act One: 1–67; Act Two: 68–149; Power Pack: P1–P11.\nBuild:\n· Drag parts from the tray, or tap a part and then an empty position. Drag centers to move parts.\n· Fixed starting parts cannot move or be removed. Blue marks show movable parts and removable chains.\n· Select a part, then click a blue arc labeled with a level to choose the starting level and winding direction.\n· Contacts show the level. Every sprocket in a chain must be on the same level.\n· While connecting, only available contacts on the current level are shown. Click blue arcs to add sprockets, then the starting arc to close the loop.\n· Hover or focus an arrow to preview the route. Click to fix its direction. Undo a contact or cancel at any time.\n· Select a chain to remove it where permitted, or choose Add sprockets and close the loop again.\n· Drag empty space to pan, scroll or pinch to zoom, and recenter to show the whole circuit.\nMechanics:\n· Speed represents current, rotation direction represents current direction, and torque represents voltage.\n· A chain connects its parts in series. Resistors resist motion; an OFF switch locks its sprocket.\n· Capacitors store torsional energy and show voltage. Inductors store motion in a flywheel.\n· Junction wheels rotate independently. Bottom current equals middle plus top current.\n· A transistor has a top gate and a bottom path. Reversing installation changes the opening direction.\n· A diode kit retains its junction, transistor, and internal chains as one assembly.\nRun:\n· Start, click switches, drag wheel centers to turn them by hand, or open and close gates with part controls.\n· Readings follow the circuit. Faster ammeter rotation makes a higher tone. Enable sound explicitly.\n· A short trips the battery; return to building to reset it. Stored energy can also run out.\n· Disconnect an individual battery to observe how a backup supply takes over.\nCheck:\n· Checking starts from the initial state and compares voltage, current, and changes under switch and hand inputs.\n· Equivalent windings can pass. This development model is approximate; finite checks are not a proof for every input.\n· The book diagram and stated goal remain authoritative. Completed challenges are stored locally.\n· The room retains each build. Reset affects only the current challenge.",
			motor: "Battery",
			resistor: "Resistor",
			junction: "Junction",
			button: "Switch",
			capacitor: "Capacitor",
			inductor: "Inductor",
			transistor: "Transistor",
			levelChanger: "Level changer",
			diode: "Diode",
			diodeKit: "Diode kit",
			phonograph: "Ammeter",
			choose: "Challenges",
			level: "Challenge {{n}}",
			bookOne: "Act One",
			bookTwo: "Act Two",
			bookPower: "Power Pack",
			build: "Building",
			running: "Running",
			paused: "Paused",
			checking: "Checking {{n}} / {{total}}",
			passed: "Challenge complete",
			failed: "Goal not met",
			unverified: "Review the goal",
			start: "Start",
			pause: "Pause",
			resume: "Resume",
			edit: "Back to building",
			check: "Check",
			next: "Next",
			goal: "Challenge goal",
			diagram: "Book diagram",
			available: "Available parts",
			chains: "Chain loops {{n}}",
			place: "Choose a position",
			undo: "Undo",
			back: "Undo contact",
			cancel: "Cancel",
			close: "Close",
			remove: "Remove part",
			removeChain: "Remove chain",
			extendChain: "Add sprockets",
			reset: "Reset",
			resetQuestion: "Restore this challenge’s starting setup?",
			confirmReset: "Confirm reset",
			fit: "Recenter",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			speed: "Speed",
			layer: "Level {{n}}",
			clockwise: "Clockwise",
			counterclockwise: "Counterclockwise",
			connect: "{{part}}, level {{n}}, {{direction}}",
			selected: "Part controls",
			fixed: "Fixed",
			movable: "Movable",
			on: "ON",
			off: "OFF",
			charge: "Initial voltage",
			openGate: "Open gate",
			closeGate: "Close gate",
			flip: "Reverse installation",
			powerOff: "Disconnect battery",
			powerOn: "Restore power",
			soundOn: "Enable sound",
			soundOff: "Mute sound",
			board: "Mechanical circuit board",
			webgl: "This device cannot display the 3D board. Please use a browser with WebGL 2 support.",
			short: "The battery has tripped. Check for a short circuit.",
			missing: "There is no complete circuit yet.",
			goalFailure: "An input produced an output outside the goal. Return to building to adjust it.",
			unsupported: "Review the circuit against the book goal.",
			invalid: "That action is not available now.",
			sourceAttribution: "Book challenges, diagrams, and cover: Paul Boswell / Upper Story; illustrations by Aleksandar Zolotić, © 2022, CC BY-NC-SA 4.0. This edition translates goals and crops diagrams. Interaction references the official simulator; this project implements its own 3D models and solver.",
			sourceLicense: "Book asset license",
			levels: {
				c001: {
					title: "Resistance",
					goal: "Run the starting circuit, then use the available parts to make it run slower."
				},
				c002: {
					title: "Another solution",
					goal: "Make the circuit run slower without adding any more chains to R1."
				},
				c003: {
					title: "One chain, two resistors",
					goal: "Use one chain loop to make both resistors turn clockwise."
				},
				c004: {
					title: "Clockwise and counterclockwise",
					goal: "Make one resistor turn clockwise and the other counterclockwise."
				},
				c005: {
					title: "Counterclockwise only",
					goal: "Make both resistors turn counterclockwise."
				},
				c006: {
					title: "The switch",
					goal: "Use the switch to turn R1 on and off."
				},
				c007: {
					title: "A switch in the loop",
					goal: "Use the switch to turn R1 on and off."
				},
				c008: {
					title: "AND gate",
					goal: "The resistor must turn only when both S1 and S2 are ON."
				},
				c009: {
					title: "Make some noise",
					goal: "Make ammeter A1 turn. Use a resistor to avoid a short circuit."
				},
				c010: {
					title: "Sound switch",
					goal: "Use the switch to turn A1 on and off."
				},
				c011: {
					title: "Low pitch",
					goal: "Choose only one available resistor to make A1 produce a lower pitch than in the previous challenge."
				},
				c012: {
					title: "Lowest pitch",
					goal: "Make A1 produce the lowest pitch possible with the available parts."
				},
				c013: {
					title: "First circuit diagram",
					goal: "Build the circuit shown. Equivalent connections are allowed."
				},
				c014: {
					title: "Equivalent circuits",
					goal: "Build the circuit shown. Try finding other equivalent solutions."
				},
				c015: {
					title: "Simplified circuit diagram",
					goal: "Build the circuit shown."
				},
				c016: {
					title: "Crossover",
					goal: "Build the circuit shown. A bridge means the crossing wires are not connected."
				},
				c017: {
					title: "Fix the short circuit",
					goal: "Fix the short without adding more chains to the battery."
				},
				c018: {
					title: "Plugging holes",
					goal: "Fix every short without adding more chains to the battery. Extra: use only one resistor."
				},
				c019: {
					title: "OR gate",
					goal: "A1 must turn when either or both switches are ON, and stop when both are OFF."
				},
				c020: {
					title: "Where is the highest current?",
					goal: "Add A1 at the position with the highest current and highest pitch."
				},
				c021: {
					title: "Where is the lowest current?",
					goal: "Add A1 at the position with the lowest current and lowest pitch."
				},
				c022: {
					title: "Resistors in parallel",
					goal: "Run the starting circuit, then make A1 produce a slightly higher pitch. Blue parts and chains may be moved or removed."
				},
				c023: {
					title: "Pitch switch",
					goal: "A1 must produce a higher pitch when S1 is ON than when it is OFF."
				},
				c024: {
					title: "Changing levels",
					goal: "Complete the circuit by connecting J1 to J2. Keep the switch used to change levels ON."
				},
				c025: {
					title: "Parallel and series together",
					goal: "Build the circuit shown."
				},
				c026: {
					title: "Double split",
					goal: "Build the circuit shown."
				},
				c027: {
					title: "Parallel and series 2",
					goal: "Build the circuit shown."
				},
				c028: {
					title: "Parallel and series 3",
					goal: "Build the circuit shown."
				},
				c029: {
					title: "Parallel and series 4",
					goal: "Build the circuit shown. Only one junction is needed."
				},
				c030: {
					title: "Parallel and series 5",
					goal: "Build the circuit shown."
				},
				c031: {
					title: "Charge the capacitor",
					goal: "Use the battery to charge the capacitor. Set its initial voltage to 0 V."
				},
				c032: {
					title: "Push to charge",
					goal: "Charge C1 while S1 is ON, and keep the charge after S1 is turned OFF."
				},
				c033: {
					title: "Slow charge",
					goal: "Make the capacitor charge more slowly than in the previous challenge."
				},
				c034: {
					title: "Chirp",
					goal: "A1 must turn briefly when S1 is first turned ON, then stop."
				},
				c035: {
					title: "Charge and discharge 1",
					goal: "Use S1 to charge C1 and S2 to discharge it."
				},
				c036: {
					title: "Charge and discharge 2",
					goal: "Make both charging and discharging slower."
				},
				c037: {
					title: "Charge and discharge 3",
					goal: "Prevent a short when S1 and S2 are both ON."
				},
				c038: {
					title: "Charge and discharge 4",
					goal: "A1 must turn every time C1 charges or discharges."
				},
				c039: {
					title: "Automatic discharge",
					goal: "C1 must charge when S1 is ON and discharge when S1 is OFF."
				},
				c040: {
					title: "Slow rise, slow fall",
					goal: "C1 must charge slowly when S1 is ON and discharge slowly when S1 is OFF."
				},
				c041: {
					title: "Capacitor backup",
					goal: "A1 must continue turning briefly after S1 cuts off the battery."
				},
				c042: {
					title: "Measure the battery voltage",
					goal: "Measure the battery voltage with a capacitor. Use a resistor to reduce overshoot."
				},
				c043: {
					title: "Negative voltage",
					goal: "Set the voltage across C1 to approximately −6 V."
				},
				c044: {
					title: "Is battery voltage constant?",
					goal: "Measure the battery voltage continuously while the battery discharges through R1."
				},
				c045: {
					title: "Voltage divider: 2 V",
					goal: "Set C1 to 2–3 V."
				},
				c046: {
					title: "Voltage divider: 5 V",
					goal: "Set C1 to 4.5–5.5 V. Extra: change it to 1–2 V."
				},
				c047: {
					title: "Voltage drop",
					goal: "Measure the voltage across R2, between points A and B in the diagram."
				},
				c048: {
					title: "NOT gate",
					goal: "C1 must read about 0 V when S1 is ON and about 6 V when S1 is OFF. −6 V is also allowed."
				},
				c049: {
					title: "NAND gate",
					goal: "C1 must read about 0 V when both S1 and S2 are ON, and about ±6 V otherwise."
				},
				c050: {
					title: "NOR gate",
					goal: "C1 must read about 0 V when either switch is ON, and about ±6 V when both are OFF."
				},
				c051: {
					title: "Pitch switch reversed",
					goal: "A1 must turn faster when S1 is OFF than when S1 is ON."
				},
				c052: {
					title: "Junction spin direction",
					goal: "Make R1 turn counterclockwise and R2 clockwise."
				},
				c053: {
					title: "Junction spin direction 2",
					goal: "Make both R1 and R2 turn clockwise."
				},
				c054: {
					title: "Locked circuit",
					goal: "Build a circuit that prevents the battery from turning."
				},
				c055: {
					title: "Junction dot diagrams 1",
					goal: "Build the circuit shown and check the direction of all three resistors."
				},
				c056: {
					title: "Junction dot diagrams 2",
					goal: "Build the circuit shown and check the direction of all three resistors."
				},
				c057: {
					title: "All the same direction",
					goal: "Connect all three resistors in parallel so that they all turn clockwise."
				},
				c058: {
					title: "Coupling diagrams 1",
					goal: "Build the coupled circuit shown."
				},
				c059: {
					title: "Coupling diagrams 2",
					goal: "Build the coupled circuit shown."
				},
				c060: {
					title: "Coupling diagrams 3",
					goal: "Build the coupled circuit shown."
				},
				c061: {
					title: "Voltage doubler",
					goal: "Set C1 to +12 V."
				},
				c062: {
					title: "Voltage halver",
					goal: "Set C1 to +3 V."
				},
				c063: {
					title: "Voltage quadrupler",
					goal: "Make A1 turn four times faster than in the starting circuit. An ON switch can couple loops or change levels."
				},
				c064: {
					title: "Voltage tripler",
					goal: "Make A1 turn three times faster than in the starting circuit."
				},
				c065: {
					title: "Locked circuit 2",
					goal: "Use the available parts to build a circuit that cannot move at all."
				},
				c066: {
					title: "Polarity buttons",
					goal: "A1 must turn clockwise when S1 is ON and counterclockwise when S2 is ON. Both ON is not assessed."
				},
				c067: {
					title: "Polarity button",
					goal: "A1 must turn clockwise when S1 is OFF and counterclockwise when S1 is ON."
				},
				c068: {
					title: "Push to charge 2",
					goal: "Charge C1 and C2 to 6 V when S1 is ON. Both must keep their charge after S1 is turned OFF."
				},
				c069: {
					title: "Automatic discharge 2",
					goal: "Charge C1 and C2 to 6 V when S1 is ON. Discharge both to 0 V when S1 is OFF."
				},
				c070: {
					title: "Two voltages",
					goal: "Set C1 to 6 V and C2 to approximately 3 V. Use a voltage divider for C2."
				},
				c071: {
					title: "Bigger capacitor backup",
					goal: "Make a brief interruption of battery power by S1 affect A1 less than in the starting circuit."
				},
				c072: {
					title: "Capacitors in series",
					goal: "Make the sounds shorter when S1 changes from OFF to ON or ON to OFF."
				},
				c073: {
					title: "Double capacitance",
					goal: "Double the effective capacitance felt at S1. C2 in the book is only a comparison part."
				},
				c074: {
					title: "Half capacitance",
					goal: "Halve the effective capacitance felt at S1. C2 in the book is only a comparison part."
				},
				c075: {
					title: "Build a 0.004 F capacitor",
					goal: "Make the effective capacitance at S1 equal to 0.004 F. C2 in the book is only for comparison."
				},
				c076: {
					title: "Build a 0.00025 F capacitor",
					goal: "Make the effective capacitance at S1 equal to 0.00025 F. C2 in the book is only for comparison."
				},
				c077: {
					title: "Transistor as a switch",
					goal: "Opening and closing the gate of T1 by hand must start and stop A1."
				},
				c078: {
					title: "The active region",
					goal: "Adjust the gate of T1 by hand to continuously control the voltage across C1."
				},
				c079: {
					title: "Level changer 2",
					goal: "Use the battery to open the gate of T1. Leave the transistor path unconnected."
				},
				c080: {
					title: "Gate charge",
					goal: "T1 must open when S1 is ON and close when S1 is OFF. Leave its path unconnected."
				},
				c081: {
					title: "Gate charge 2",
					goal: "A1 must turn when S1 is ON and stop when S1 is OFF."
				},
				c082: {
					title: "Amplification 1",
					goal: "Modify the circuit so that S1 opens the gate of T1 when ON and closes it when OFF."
				},
				c083: {
					title: "Amplification 2",
					goal: "A1 must turn quickly when S1 is ON and stop when S1 is OFF."
				},
				c084: {
					title: "Transistor circuit diagrams 1",
					goal: "Build the circuit shown."
				},
				c085: {
					title: "Transistor circuit diagrams 2",
					goal: "Build the circuit shown."
				},
				c086: {
					title: "Transistor circuit diagrams 3",
					goal: "Build the circuit shown."
				},
				c087: {
					title: "Voltage amplifier",
					goal: "Build a manual voltage source to control the gate of T1 and amplify a small positive input voltage at C1."
				},
				c088: {
					title: "Negative voltage amplifier",
					goal: "Amplify a negative manual input voltage into a larger positive voltage at C1."
				},
				c089: {
					title: "Positive or negative amplifier",
					goal: "Amplify either polarity of manual input voltage into a larger positive voltage at C1."
				},
				c090: {
					title: "Darlington pair",
					goal: "Use two transistor amplifier stages. C1 must show the output of the second stage."
				},
				c091: {
					title: "Addition",
					goal: "C1 must show battery voltage plus manual input voltage: 2 V gives 8 V, and −3 V gives 3 V."
				},
				c092: {
					title: "Subtraction 1",
					goal: "C1 must show battery voltage minus manual input voltage: 2 V gives 4 V, and −3 V gives 9 V."
				},
				c093: {
					title: "Subtraction 2",
					goal: "C1 must show manual input voltage minus battery voltage: 2 V gives −4 V, and −3 V gives −9 V."
				},
				c094: {
					title: "Circuit math",
					goal: "C1 and C2 initially show two divider voltages. Modify the circuit to display C1 − C2 using only one capacitor."
				},
				c095: {
					title: "Biased transistor 1",
					goal: "Apply about 1 V to the gate of T1 with a divider, setting it in the active region. C1 should read about 4 V; 1–5 V is acceptable."
				},
				c096: {
					title: "Biased transistor 2",
					goal: "Add a manual voltage source to the divider voltage so C1 amplifies small positive and negative inputs."
				},
				c097: {
					title: "Off at one end",
					goal: "A1 must turn except when the manual input voltage exceeds +6 V."
				},
				c098: {
					title: "Off at both ends",
					goal: "A1 must turn while the manual input is between −6 V and +6 V, and stop outside that range."
				},
				c099: {
					title: "Current to voltage 1",
					goal: "Convert manual input current into a voltage across C1."
				},
				c100: {
					title: "Current to voltage 2",
					goal: "Amplify positive voltages at C1 into larger voltages at C2."
				},
				c101: {
					title: "The transistor diode",
					goal: "S1 must turn only clockwise. Extra: make it turn only counterclockwise."
				},
				c102: {
					title: "Two diodes",
					goal: "Turning S1 clockwise must turn A1. Turning it counterclockwise must turn R1."
				},
				c103: {
					title: "Full wave rectifier",
					goal: "A1 must turn clockwise regardless of the direction S1 is turned by hand. Extra: make A1 always turn counterclockwise."
				},
				c104: {
					title: "Positive clipper",
					goal: "C1 must show the voltage applied to S1, limited to a maximum of +1.5 V."
				},
				c105: {
					title: "Positive and negative clipper",
					goal: "C1 must show the voltage applied to S1, limited to −1.5 V through +1.5 V."
				},
				c106: {
					title: "Peak detector",
					goal: "C1 must retain the highest voltage ever applied by the manual source."
				},
				c107: {
					title: "Peak detector with reset",
					goal: "Retain peak detection and add a reset switch that returns C1 to 0 V."
				},
				c108: {
					title: "Voltage limiter",
					goal: "Limit the maximum manual source voltage to approximately +3.5 V. The physical circuit may limit at 4–5 V."
				},
				c109: {
					title: "Inductance",
					goal: "A1 must speed up gradually when S1 is ON and stop as shown when S1 is turned OFF."
				},
				c110: {
					title: "Reflector",
					goal: "Make the current in A1 respond to S1 as shown, retaining the flat sections of the graph."
				},
				c111: {
					title: "Inductor kick",
					goal: "L1 must spin when S1 is ON. Provide a path for its stored energy when S1 is turned OFF."
				},
				c112: {
					title: "Halve the inductance",
					goal: "Halve the effective inductance felt at S1 relative to L1."
				},
				c113: {
					title: "Quadruple the inductance",
					goal: "Make the effective inductance felt at S1 four times that of L1."
				},
				c114: {
					title: "Inductor and diode diagrams 1",
					goal: "Build the circuit shown."
				},
				c115: {
					title: "Inductor and diode diagrams 2",
					goal: "Build the circuit shown."
				},
				c116: {
					title: "Inductor and diode diagrams 3",
					goal: "Build the circuit shown."
				},
				c117: {
					title: "Superimpose AC on DC",
					goal: "Add a manual AC voltage signal to the battery's 6 V DC signal."
				},
				c118: {
					title: "High-pass filter",
					goal: "Turn S1 back and forth. Pass high frequencies to C1 while blocking DC."
				},
				c119: {
					title: "Low-pass filter",
					goal: "Turn S1 back and forth. Pass low frequencies and DC to C1 while weakening high frequencies."
				},
				c120: {
					title: "Smooth it out",
					goal: "Improve the full wave rectifier by using both capacitors in parallel to make A1 current nearly constant."
				},
				c121: {
					title: "High-pass filter 2",
					goal: "Turn S1 back and forth. Pass high frequencies to A1 while weakening low frequencies."
				},
				c122: {
					title: "Low-pass filter 2",
					goal: "Turn S1 back and forth. Pass low frequencies and DC to A1 while weakening high frequencies."
				},
				c123: {
					title: "Band-pass filter",
					goal: "Turn S1 back and forth. Pass middle frequencies to C1 while weakening low and high frequencies."
				},
				c124: {
					title: "Buck converter 1",
					goal: "Switch S1 rapidly to power the 100 Ω equivalent load with the buck circuit shown."
				},
				c125: {
					title: "Buck converter 2",
					goal: "Add a low-pass filter using C1 and C2 to reduce voltage ripple. Switch S1 rapidly."
				},
				c126: {
					title: "Boost converter 1",
					goal: "Store energy in L1 while S1 is ON, then release a surge of current through A1 when S1 is OFF."
				},
				c127: {
					title: "Boost converter 2",
					goal: "Drive R1 above battery voltage. Prevent reverse flow with a diode and smooth the output using two capacitors."
				},
				c128: {
					title: "Synchronous switch",
					goal: "Couple the gates of T1 and T2 so one is always open. Clockwise gate rotation must turn L1; otherwise A1 must turn."
				},
				c129: {
					title: "Polarity flipper",
					goal: "Use the synchronous switch to set C1 to +6 V or −6 V and reverse A1's direction."
				},
				c130: {
					title: "Synchronous boost converter",
					goal: "Replace the switch and diode with a synchronous switch. Turn it back and forth to drive R1 above battery voltage."
				},
				c131: {
					title: "Synchronous buck converter",
					goal: "Use a synchronous switch instead of the switch and diode. Turn it back and forth to power the 100 Ω equivalent load."
				},
				c132: {
					title: "Voltage spike",
					goal: "Generate a spike above 7 V at C1 without inductors or voltage doublers. Try charging a capacitor, then connecting it in series with the battery."
				},
				c133: {
					title: "Basic feedback",
					goal: "T1 starts closed. Once opened by hand, the circuit must keep its gate open."
				},
				c134: {
					title: "Press S1 to start",
					goal: "Start A1 with S1 and keep it turning after S1 is OFF. Control T1's gate using feedback across the 200 Ω resistor; do not put the gate in series with S1."
				},
				c135: {
					title: "Basic oscillator",
					goal: "Store energy in L1 when S1 is ON. After S1 is OFF, the circuit must oscillate for a while."
				},
				c136: {
					title: "Will it oscillate?",
					goal: "Build a NOT gate controlled by T1 and feed its output back into T1's gate. Observe the result."
				},
				c137: {
					title: "Delayed feedback",
					goal: "Modify the starting circuit to delay its feedback."
				},
				c138: {
					title: "Smooth oscillator",
					goal: "Add a capacitor to absorb the energy remaining after the inductor opens the transistor gate, smoothing the oscillation."
				},
				c139: {
					title: "Relaxation oscillator 1",
					goal: "Build a buffer gate: opening and closing T1 by hand must produce matching changes in C1 and A1."
				},
				c140: {
					title: "Relaxation oscillator 2",
					goal: "Keep the buffer gate and add a separate NOT gate in parallel, controlled by T2 and measured by C2."
				},
				c141: {
					title: "Relaxation oscillator 3",
					goal: "Remove C1 and C2. Connect each gate's output to the other gate's input to form an oscillator."
				},
				c142: {
					title: "Current source 1",
					goal: "Apply −2 V to fully open the gate of T1. Pay attention to its initial direction."
				},
				c143: {
					title: "Current source 2",
					goal: "Connect S1 to A1 so turning S1 by hand makes A1 turn four times faster. Do not connect the battery yet."
				},
				c144: {
					title: "Current source 3",
					goal: "Supply nearly constant current to S1 despite a small applied resistance. Use the 200 Ω resistor for negative feedback to T1."
				},
				c145: {
					title: "Flip-flop 1",
					goal: "Build two NOT gates in parallel. T1's gate must produce −6 V at C1; T2's gate must produce +6 V at C2."
				},
				c146: {
					title: "Flip-flop 2: Schmitt trigger",
					goal: "Remove C1 and C2. Opening or closing either transistor gate by hand must leave it in that position."
				},
				c147: {
					title: "Flip-flop 3",
					goal: "Use S1 and S2 to flip the transistors instead of turning their gates by hand. C1 must show the state."
				},
				c148: {
					title: "XOR gate",
					goal: "A1 must turn when exactly one of S1 and S2 is ON, and stop when both or neither are ON."
				},
				c149: {
					title: "Pulse generator",
					goal: "Each time S1 turns ON, A1 must turn briefly and then stop."
				},
				c150: {
					title: "Batteries in series",
					goal: "Connect the two batteries in series and measure their combined voltage at C1."
				},
				c151: {
					title: "Opposing batteries",
					goal: "Connect the two batteries so their equal forces oppose each other and no current flows."
				},
				c152: {
					title: "Batteries in parallel",
					goal: "Connect both batteries in parallel to power resistor LOAD."
				},
				c153: {
					title: "Easier to charge",
					goal: "Power LOAD with parallel batteries and use switches to disconnect either battery independently for charging."
				},
				c154: {
					title: "One-way batteries",
					goal: "Power LOAD with parallel batteries and two diodes so each battery can turn only one way."
				},
				c155: {
					title: "One battery or the other 1",
					goal: "When S1 is OFF, T1 must close and T2 open; when S1 is ON, T1 must open and T2 close. Use only B1 as a power supply."
				},
				c156: {
					title: "One battery or the other 2",
					goal: "B1 must power A1 when S1 is ON; B2 must power it when S1 is OFF."
				},
				c157: {
					title: "Circuit breaker 1",
					goal: "Turn T1's gate by hand. Use shunt resistor R1 to observe path current, and C1 to display R1's voltage."
				},
				c158: {
					title: "Circuit breaker 2",
					goal: "Add a divider producing −2 V and use it to keep T2's gate open by default."
				},
				c159: {
					title: "Circuit breaker 3",
					goal: "When R1's voltage exceeds 2 V, T2 must close and stay closed, breaking the circuit."
				},
				c160: {
					title: "Backup battery",
					goal: "Initially only B1 must power A1. When B1 runs out, the circuit must automatically switch to B2."
				}
			}
		}
	}
};
//#endregion
export { yt as default };
