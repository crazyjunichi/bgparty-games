import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { createPortal as r } from "react-dom";
import { gameAssetUrl as i } from "@bgparty/sdk/assets";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useT as s } from "@bgparty/sdk/i18n";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
import { Floater as d, FlySprite as f } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as ee } from "@bgparty/sdk/confirm-button";
import { OptionSection as p, OptionSwitch as m } from "@bgparty/sdk/ui/game-options";
//#region src/games/istanbuldice/data.ts
var h = [
	8,
	8,
	8,
	8,
	10,
	12,
	87
], g = Array.from({ length: 24 }, (e, t) => t >= 20 ? {
	id: t,
	color: -1,
	ability: "die"
} : {
	id: t,
	color: t % 4,
	ability: [
		"money",
		"crystal",
		"bazaar",
		"action",
		"goods"
	][Math.floor(t / 4)]
}), _ = [
	["exchange", 0],
	["exchange", 5],
	["exchange", 1],
	["exchange", 3],
	["holdMoney", 0],
	["holdCrystal", 0],
	["payBrown", 0],
	["brownGift", 0],
	["brownGift", 3],
	["brownGift", 1],
	["exchange", 2],
	["swapGoods", 0],
	["holdAll", 0],
	["swapMosque", 0],
	["twoColor", 0],
	["twoBrown", 0],
	["twoMoney", 0],
	["brownGift", 2],
	["payAll", 0],
	["paySame", 0],
	["buyGift", 1],
	["buyGift", 2],
	["buyGift", 0],
	["holdBrown", 0],
	["choiceGift", 2],
	["buyGift", 3],
	["choiceGift", 3],
	["choiceGift", 1],
	["choiceGift", 0],
	["choiceGift", 5],
	["payMoney", 0],
	["buyMosque", 0],
	["buyBrown", 0]
], v = (e) => e === 4 ? 5 : 6, y = (e) => e === 4 ? 4 : 5;
function b(e) {
	return [
		...Array.from({ length: 4 }, () => Array(e === 4 ? 4 : 3).fill(!0)),
		Array.from({ length: 5 }, (t, n) => e !== 2 || n !== 0),
		Array.from({ length: 6 }, (t, n) => e !== 2 || n !== 0),
		Array(e === 4 ? 4 : 3).fill(!0)
	];
}
function x(e, t, n) {
	if (e < 4) {
		let r = [
			0,
			0,
			0,
			0
		];
		return r[e] = (n === 4 ? [
			4,
			4,
			5,
			6
		] : [
			4,
			5,
			6
		])[t], r;
	}
	return e === 4 ? [
		1,
		1,
		1,
		1
	] : [10 + t * 2];
}
//#endregion
//#region src/games/istanbuldice/meta.ts
var S = {
	id: "istanbuldice",
	tier: "alpha",
	mechanics: [
		"dice-rolling",
		"engine-building",
		"race"
	],
	interactionTags: [],
	nameKey: "games.istanbuldice.name",
	descKey: "games.istanbuldice.desc",
	rulesKey: "games.istanbuldice.rules",
	icon: "💎",
	iconImg: "games/istanbuldice.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/17602515663484884948/68AE9F4E5167E362D6ACDC1363AFC50DCD46FB32/" },
	accent: "#a12d30",
	releasedAt: "2026-11-01T01:18:08+08:00",
	search: {
		py: "yi si tan bao tou zi ban",
		init: "ystbtzb"
	},
	hotseat: "open",
	botDelayMs: 650
}, C = t.int().nonnegative(), w = t.tuple([
	C,
	C,
	C,
	C,
	C
]), T = t.object({ promo: t.boolean().default(!1) }).default({ promo: !1 }), E = t.object({
	type: t.literal("use"),
	kind: t.enum([
		"same",
		"crystal",
		"brown",
		"two",
		"money",
		"bazaar",
		"mosque",
		"ruby",
		"promo",
		"card",
		"response"
	]),
	dice: t.array(t.int().min(0).max(8)).max(9).default([]),
	goods: w.default([
		0,
		0,
		0,
		0,
		0
	]),
	colors: t.array(t.int().min(0).max(3)).max(8).default([]),
	target: t.int().min(-1).max(32).default(-1),
	slot: t.int().min(-1).max(23).default(-1),
	discard: t.int().min(-1).max(23).default(-1),
	mode: t.enum([
		"effect",
		"coin",
		"resource",
		"skip"
	]).default("effect")
}), te = t.discriminatedUnion("type", [
	E,
	t.object({
		type: t.literal("reroll"),
		dice: t.array(t.int().min(0).max(8)).min(1).max(9)
	}),
	t.object({ type: t.enum(["keep", "end"]) }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ne = t.object({
	rid: t.string(),
	goods: w,
	crystals: C,
	money: C,
	rubies: C,
	mosques: t.array(t.object({
		id: t.int().min(0).max(23),
		ready: C
	})),
	rewarded: t.boolean(),
	turns: C
}), re = t.object({
	players: t.array(ne),
	active: t.string(),
	round: C,
	phase: t.enum([
		"beat",
		"reroll",
		"action",
		"card",
		"response",
		"done"
	]),
	dice: t.array(t.int().min(-1).max(5)),
	actions: C,
	tracks: t.array(t.array(t.boolean())),
	display: t.array(t.int().min(0).max(23)),
	deckCount: C,
	bazaarCount: C,
	discardCount: C,
	offered: t.array(t.int().min(0).max(32)),
	cardDice: C,
	responseCard: t.int().min(-1).max(32),
	responder: t.string().nullable(),
	finalRound: t.boolean(),
	promo: t.boolean(),
	promoUsed: t.tuple([t.boolean(), t.boolean()]),
	stock: t.array(C),
	log: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		value: t.number()
	})),
	serial: C
}), D = t.object({ moves: t.array(E) }), O = (e) => e.players[e.activeIndex], k = (e) => e.reduce((e, t) => e + t, 0), A = (e) => E.parse({
	type: "use",
	...e
}), j = () => ({ code: "games.istanbuldice.errAction" });
function M(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function ie(e, t) {
	return t < 5 ? e.goods[t] : t === 5 ? e.crystals : e.money;
}
function N(e, t, n) {
	t < 5 ? e.goods[t] += n : t === 5 ? e.crystals += n : e.money += n;
}
function P(e, t) {
	return h[t] - e.locked[t] - k(e.players.map((e) => ie(e, t)));
}
function F(e, t, n, r, i = []) {
	let a = /* @__PURE__ */ new Map(), o = Math.min(r, h[n] - e.locked[n]);
	for (; P(e, n) < o;) for (let t of e.players) ie(t, n) > 0 && (N(t, n, -1), a.set(t.rid, (a.get(t.rid) ?? 0) + 1));
	N(t, n, o), i.push({
		kind: "resources",
		with: !0,
		data: { moves: [...a].map(([e, t]) => ({
			from: e,
			to: "supply",
			resource: n,
			count: t
		})).concat([{
			from: "supply",
			to: t.rid,
			resource: n,
			count: o
		}]) }
	});
}
var I = (e, t) => e.mosques.filter((n) => n.ready <= e.turns && g[n.id].ability === t);
function L(e, t, n, r = 0) {
	e.log.push({
		rid: t,
		kind: n,
		value: r
	}), e.log = e.log.slice(-80), e.serial++;
}
function R(e, t, n, r) {
	return e.tracks[n]?.[r] ? (e.tracks[n][r] = !1, t.rubies++, t.rubies >= v(e.players.length) && (e.finalRound = !0), !0) : !1;
}
function z(e, t, n) {
	let r = e.display.indexOf(n);
	if (r < 0) return !1;
	e.display.splice(r, 1);
	let i = e.mosqueDeck.shift();
	if (i !== void 0 && e.display.splice(r, 0, i), t.mosques.push({
		id: n,
		ready: t.turns + 1
	}), !t.rewarded && t.mosques.length === y(e.players.length)) {
		t.rewarded = !0;
		let n = e.tracks[6].findIndex(Boolean);
		n >= 0 && R(e, t, 6, n);
	}
	return !0;
}
function ae(e) {
	let t = O(e);
	t.turns++, e.dice = [], e.offered = [], e.responder = null, e.actions = 2 + I(t, "action").length;
	for (let n of t.mosques.filter((e) => e.ready <= t.turns)) {
		let r = g[n.id].ability;
		(r === "money" || r === "crystal") && e.queue.push({
			kind: "gain",
			rid: t.rid,
			resource: r === "money" ? 6 : 5,
			count: r === "money" ? 3 : 1
		}), r === "bazaar" && e.queue.push({
			kind: "draw",
			rid: t.rid,
			count: 1
		});
	}
	e.queue.push({
		kind: "roll",
		rid: t.rid
	}), e.phase = "beat";
}
function B(e, t) {
	e.offered = [];
	for (let n = 0; n < t; n++) {
		e.bazaarDeck.length || (e.bazaarDeck = M(e, e.bazaarDiscard), e.bazaarDiscard = []);
		let t = e.bazaarDeck.shift();
		t !== void 0 && e.offered.push(t);
	}
	e.phase = e.offered.length ? "card" : "beat";
}
function oe(e, t, n) {
	if (new Set(n.dice).size !== n.dice.length) return null;
	let r = n.goods.slice(0, 4);
	if (n.goods.some((e, n) => e > t.goods[n])) return null;
	for (let i of n.dice) {
		if (t !== O(e) || !["action", "card"].includes(e.phase) || e.dice[i] === void 0 || e.dice[i] < 0 || e.dice[i] > 3) return null;
		r[e.dice[i]]++;
	}
	return r;
}
function V(e, t, n, r, i = 0) {
	let a = oe(e, t, n);
	if (!a || k(a) + n.goods[4] !== k(r) + i || k(r.map((e, t) => Math.max(0, e - a[t]))) > n.goods[4]) return !1;
	for (let t of n.dice) e.dice[t] = -1;
	return t.goods = t.goods.map((e, t) => e - n.goods[t]), !0;
}
var H = (e) => e.dice.length === 0 && k(e.goods) === 0, U = (e) => [
	0,
	1,
	2,
	3
].map((t) => e.filter((e) => e === t).length), W = (e, t) => e.colors.length === t;
function se(e, t) {
	return e.money < t ? !1 : (e.money -= t, !0);
}
function ce(e, t, n, r) {
	if (!e.offered.includes(n.target)) return !1;
	if (n.mode === "coin") return !H(n) || [
		"exchange",
		"brownGift",
		"buyGift",
		"choiceGift"
	].includes(_[n.target][0]) ? !1 : (F(e, t, 6, 1, r), !0);
	if (n.mode !== "effect") return !1;
	let [i, a] = _[n.target];
	if (i === "exchange" || i === "brownGift" || i === "buyGift" || i === "choiceGift") {
		if (!H(n)) return !1;
		i === "exchange" && F(e, t, 6, 4, r), i === "brownGift" && F(e, t, 4, 1, r), (i === "buyGift" || i === "choiceGift") && F(e, t, a, 1, r), i === "choiceGift" && F(e, t, 6, 3, r);
		for (let t = 1; t < e.players.length; t++) e.queue.unshift({
			kind: "response",
			rid: e.players[(e.activeIndex + e.players.length - t) % e.players.length].rid,
			card: n.target
		});
		return !0;
	}
	if (i.startsWith("hold")) {
		let a = i === "holdAll" ? 3 : i === "holdBrown" ? 1 : 2;
		if (!H(n) || t.goods[4] < a) return !1;
		if (i === "holdMoney" && F(e, t, 6, 6, r), i === "holdCrystal" && F(e, t, 5, 2, r), i === "holdAll") for (let n = 0; n < 4; n++) F(e, t, n, 1, r);
		return i === "holdBrown" && F(e, t, 4, 1, r), !0;
	}
	if (i.startsWith("two")) return !H(n) || e.cardDice < 2 || i === "twoColor" && !W(n, 1) ? !1 : (F(e, t, i === "twoColor" ? n.colors[0] : i === "twoBrown" ? 4 : 6, i === "twoMoney" ? 5 : 1, r), !0);
	if ([
		"payAll",
		"paySame",
		"payMoney",
		"payBrown"
	].includes(i)) {
		if (n.slot !== e.tracks[n.discard]?.findIndex(Boolean) || n.discard < 0 || n.discard > 5 || i === "payAll" && !V(e, t, n, [
			1,
			1,
			1,
			1
		]) || i === "paySame" && (!W(n, 1) || !V(e, t, n, U([
			n.colors[0],
			n.colors[0],
			n.colors[0]
		]))) || i === "payMoney" && (!H(n) || !se(t, 10))) return !1;
		if (i === "payBrown") {
			if (n.dice.length || n.goods.some((e, t) => e !== (t === 4 ? 2 : 0)) || t.goods[4] < 2) return !1;
			t.goods[4] -= 2;
		}
		return R(e, t, n.discard, n.slot);
	}
	if (i === "swapGoods") {
		if (!W(n, 2) || !V(e, t, n, [
			0,
			0,
			0,
			0
		], 1)) return !1;
		for (let i of n.colors) F(e, t, i, 1, r);
	} else if (i === "buyBrown") {
		if (!V(e, t, n, [
			0,
			0,
			0,
			0
		], 2)) return !1;
		F(e, t, 4, 2, r);
	} else if (i === "buyMosque") {
		if (!V(e, t, n, [
			0,
			0,
			0,
			0
		], 2) || !z(e, t, n.discard)) return !1;
	} else if (i === "swapMosque") {
		if (!H(n) || !e.display.includes(n.slot)) return !1;
		let r = t.mosques.findIndex((e) => e.id === n.discard);
		if (r < 0 || (t.mosques.splice(r, 1), e.mosqueDiscard.push(n.discard), !z(e, t, n.slot))) return !1;
		e.actions++;
	} else return !1;
	return !0;
}
function le(e, t, n, r) {
	let [i, a] = _[e.responseCard];
	if (i === "choiceGift") {
		if (!H(n) || !["coin", "resource"].includes(n.mode)) return !1;
		F(e, t, n.mode === "coin" ? 6 : a, n.mode === "coin" ? 3 : 1, r);
	} else {
		if (n.mode === "skip") return H(n);
		if (n.mode !== "effect") return !1;
		if (i === "exchange") {
			if (a === 5) {
				if (!H(n) || t.crystals < 1) return !1;
				t.crystals--;
			} else if (!V(e, t, n, U([a]))) return !1;
			F(e, t, 6, a === 5 ? 3 : 4, r);
		} else if (i === "buyGift") {
			if (!H(n) || !se(t, 2)) return !1;
			F(e, t, a, 1, r);
		} else return !1;
	}
	return !0;
}
function ue(e, t, n, r = []) {
	let i = e.players.find((e) => e.rid === n);
	if (!i) return !1;
	if (e.phase === "response") return n !== e.responder || t.kind !== "response" || !le(e, i, t, r) ? !1 : (e.responder = null, e.responseCard = -1, e.phase = "beat", !0);
	if (i !== O(e)) return !1;
	if (e.phase === "card") return t.kind !== "card" || !ce(e, i, t, r) ? !1 : (e.bazaarDiscard.push(...e.offered), e.offered = [], e.cardDice = 0, e.phase = "beat", !0);
	if (e.phase !== "action" || e.actions < 1) return !1;
	if (t.kind === "same") {
		if (!W(t, 1) || !V(e, i, t, U([t.colors[0], t.colors[0]]))) return !1;
		F(e, i, t.colors[0], 1, r);
	} else if (t.kind === "crystal" || t.kind === "brown" || t.kind === "two") {
		let n = t.kind === "crystal" ? 2 : t.kind === "brown" ? 3 : 4, a = t.kind === "two" ? [
			0,
			1,
			2,
			3
		] : t.colors;
		if (a.length !== n || new Set(a).size !== n || t.kind === "two" && !W(t, 2) || !V(e, i, t, U(a))) return !1;
		if (t.kind === "two") for (let n of t.colors) F(e, i, n, 1, r);
		else F(e, i, t.kind === "crystal" ? 5 : 4, 1, r);
	} else if (t.kind === "money" || t.kind === "bazaar") {
		if (k(t.goods) || !t.dice.length || new Set(t.dice).size !== t.dice.length) return !1;
		let a = t.kind === "money" ? 4 : 5;
		if (t.dice.some((t) => e.dice[t] !== a) || a === 4 && e.dice.filter((e) => e === 4).length !== t.dice.length) return !1;
		if (t.dice.forEach((t) => {
			e.dice[t] = -1;
		}), a === 4) {
			F(e, i, 6, t.dice.length * 2, r);
			for (let t of I(i, "goods")) e.queue.push({
				kind: "gain",
				rid: n,
				resource: g[t.id].color,
				count: 1
			});
		} else e.cardDice = t.dice.length, e.queue.push({
			kind: "draw",
			rid: n,
			count: t.dice.length
		});
	} else if (t.kind === "mosque") {
		let n = g[t.target];
		if (!n || !e.display.includes(t.target) || !V(e, i, t, n.color < 0 ? [
			1,
			1,
			1,
			1
		] : U([
			n.color,
			n.color,
			n.color
		])) || !z(e, i, t.target)) return !1;
	} else if (t.kind === "ruby") {
		let n = t.target;
		if (n < 0 || n > 5 || t.slot !== e.tracks[n].findIndex(Boolean)) return !1;
		let r = x(n, t.slot, e.players.length);
		if ((n === 5 ? !H(t) || !se(i, r[0]) : !V(e, i, t, r, n === 4 ? t.slot : 0)) || !R(e, i, n, t.slot)) return !1;
	} else if (t.kind === "promo") {
		if (!e.config.promo || t.target < 0 || t.target > 1 || e.promoUsed[t.target]) return !1;
		if (t.target === 0) {
			if (!H(t) || i.goods[4] < 2) return !1;
			i.goods[4] -= 2, e.locked[4]++, e.queue.push({
				kind: "gain",
				rid: n,
				resource: 6,
				count: 6
			}, {
				kind: "gain",
				rid: n,
				resource: 5,
				count: 1
			}, {
				kind: "draw",
				rid: n,
				count: 1
			}), e.cardDice = 0;
		} else {
			if (!H(t) || i.crystals < 4 || !R(e, i, t.discard, t.slot)) return !1;
			i.crystals -= 4, e.locked[5]++;
		}
		e.promoUsed[t.target] = !0;
	} else return !1;
	return e.actions--, e.queue.push({
		kind: "after",
		rid: n
	}), e.phase = "beat", !0;
}
function de(t) {
	let n = [], r = t.queue.shift();
	if (!r) return [];
	let i = t.players.find((e) => e.rid === r.rid);
	if (r.kind === "gain") return F(t, i, r.resource, r.count, n), L(t, i.rid, "gain", r.resource), n;
	if (r.kind === "draw") return B(t, r.count), L(t, i.rid, "draw", r.count), [{
		kind: "draw",
		rid: i.rid,
		data: { cards: [...t.offered] }
	}];
	if (r.kind === "roll") return t.dice = Array.from({ length: 5 + I(i, "die").length }, () => e(t.seed, t.cursor++, 6)), t.phase = "reroll", L(t, i.rid, "roll"), [{
		kind: "roll",
		rid: i.rid,
		data: { dice: [...t.dice] }
	}];
	if (r.kind === "response") {
		let [e, a] = _[r.card];
		return e === "brownGift" ? (F(t, i, a, 1, n), L(t, i.rid, "gift", a), n) : (t.phase = "response", t.responder = i.rid, t.responseCard = r.card, []);
	}
	return r.kind === "after" && (t.actions > 0 ? t.phase = "action" : t.queue.push({
		kind: "turn",
		rid: i.rid
	})), r.kind === "turn" && (t.activeIndex === t.players.length - 1 && t.finalRound ? t.phase = "done" : (t.activeIndex = (t.activeIndex + 1) % t.players.length, t.activeIndex === 0 && t.round++, ae(t))), [];
}
function fe(e, t, n) {
	let r = {
		players: t.map((e, t) => ({
			rid: e,
			goods: [
				0,
				0,
				0,
				0,
				0
			],
			crystals: 1,
			money: t,
			rubies: 0,
			mosques: [],
			rewarded: !1,
			turns: 0
		})),
		activeIndex: 0,
		round: 1,
		phase: "beat",
		dice: [],
		actions: 2,
		tracks: b(t.length),
		display: [],
		mosqueDeck: [],
		mosqueDiscard: [],
		bazaarDeck: [],
		bazaarDiscard: [],
		offered: [],
		cardDice: 0,
		responseCard: -1,
		responder: null,
		finalRound: !1,
		config: T.parse(e),
		promoUsed: [!1, !1],
		locked: Array(7).fill(0),
		queue: [],
		seed: n,
		cursor: 0,
		serial: 0,
		log: []
	};
	return r.mosqueDeck = M(r, g.map((e) => e.id)), r.display = r.mosqueDeck.splice(0, 6), r.bazaarDeck = M(r, _.map((e, t) => t)), ae(r), {
		state: r,
		fx: []
	};
}
function pe(e, t, n, r) {
	let i = [], a = (e, t) => i.push({
		kind: e,
		rid: r,
		with: !0,
		data: t
	}), o = n.kind === "ruby" && n.target === 5 ? 10 + n.slot * 2 : 0, s = 0, c = [...n.goods];
	if (n.kind === "promo" && (n.target === 0 ? c[4] = 2 : s = 4), n.kind === "card" && n.mode === "effect" && _[n.target][0] === "payMoney" && (o = 10), n.kind === "response" && n.mode === "effect") {
		let [t, n] = _[e.responseCard];
		t === "exchange" && n === 5 && (s = 1), t === "buyGift" && (o = 2);
	}
	(n.dice.length || c.some(Boolean) || o || s) && a("pay", {
		dice: n.dice.map((t) => ({
			index: t,
			face: e.dice[t]
		})),
		goods: c,
		money: o,
		crystals: s,
		promo: n.kind === "promo" ? n.target : -1
	});
	for (let n = 0; n < e.tracks.length; n++) e.tracks[n].forEach((e, r) => {
		e && !t.tracks[n][r] && a("ruby", {
			track: n,
			slot: r
		});
	});
	let l = e.players.find((e) => e.rid === r), u = t.players.find((e) => e.rid === r);
	for (let n of u.mosques.filter((e) => !l.mosques.some((t) => t.id === e.id))) {
		let r = e.display.indexOf(n.id);
		a("mosque", {
			tile: n.id,
			slot: r,
			refill: t.display[r] ?? -1
		});
	}
	for (let e of l.mosques.filter((e) => !u.mosques.some((t) => t.id === e.id))) a("returnMosque", { tile: e.id });
	return n.kind === "card" && a("discard", { cards: [...e.offered] }), i;
}
function me(t, n, r) {
	if (n.type === "tick") {
		if (t.phase !== "beat" || !t.queue.length) return {
			state: t,
			fx: []
		};
		let e = structuredClone(t);
		return {
			state: e,
			fx: de(e)
		};
	}
	let i = structuredClone(t);
	if (n.type === "use") {
		let e = [];
		return ue(i, n, r.by, e) ? (L(i, r.by, n.kind, n.kind === "card" || n.kind === "ruby" ? n.target : 0), {
			state: i,
			fx: [...pe(t, i, n, r.by), ...e]
		}) : j();
	}
	return r.by === O(i).rid ? n.type === "reroll" ? i.phase !== "reroll" || O(i).crystals < 1 || new Set(n.dice).size !== n.dice.length || n.dice.some((e) => i.dice[e] === void 0 || i.dice[e] < 0) ? j() : (O(i).crystals--, n.dice.forEach((t) => {
		i.dice[t] = e(i.seed, i.cursor++, 6);
	}), L(i, r.by, "reroll"), {
		state: i,
		fx: [{
			kind: "roll",
			rid: r.by,
			data: {
				dice: [...i.dice],
				selected: n.dice
			}
		}, {
			kind: "pay",
			rid: r.by,
			with: !0,
			data: { crystals: 1 }
		}]
	}) : n.type === "keep" && i.phase === "reroll" ? (i.phase = "action", {
		state: i,
		fx: []
	}) : n.type === "end" && i.phase === "action" ? (i.actions = 0, i.phase = "beat", i.queue.push({
		kind: "turn",
		rid: r.by
	}), {
		state: i,
		fx: []
	}) : j() : j();
}
function he(e, t, n, r = 0) {
	let i = [];
	function a(e, t, n) {
		if (t === 3) {
			i.push(n.concat(e));
			return;
		}
		for (let r = 0; r <= e; r++) a(e - r, t + 1, n.concat(r));
	}
	a(r, 0, []);
	let o = [];
	for (let r of i) for (let i of [
		0,
		1,
		2
	]) {
		let a = [
			0,
			0,
			0,
			0,
			0
		], s = [], c = t.goods[4];
		for (let o = 0; o < 4; o++) {
			let l = n[o] + r[o], u = t === O(e) && ["action", "card"].includes(e.phase) ? e.dice.flatMap((e, t) => e === o ? [t] : []) : [];
			if (i === 2) {
				let e = Math.min(l, c);
				a[4] += e, c -= e, l -= e;
			}
			i === 1 && (a[o] = Math.min(l, t.goods[o]), l -= a[o]);
			let d = Math.min(l, u.length);
			s.push(...u.slice(0, d)), l -= d, i !== 1 && (a[o] = Math.min(l, t.goods[o]), l -= a[o]);
			let f = Math.min(l, c);
			if (a[4] += f, c -= f, l -= f, l) {
				c = -1;
				break;
			}
		}
		c >= 0 && o.push({
			dice: s,
			goods: a
		});
	}
	return o;
}
function ge(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n || (e.phase === "response" ? e.responder !== t : O(e).rid !== t) || ![
		"card",
		"action",
		"response"
	].includes(e.phase)) return [];
	let r = [], i = /* @__PURE__ */ new Set(), a = (n) => {
		let a = A(n);
		a.dice.sort((e, t) => e - t);
		let o = JSON.stringify(a);
		i.has(o) || (i.add(o), ue(structuredClone(e), a, t) && r.push(a));
	}, o = (t, r, i = 0) => {
		for (let o of he(e, n, r, i)) a({
			...t,
			...o
		});
	}, s = Array.from({ length: 4 }, (e, t) => Array.from({ length: 4 - t }, (e, n) => [t, t + n])).flat();
	if (e.phase === "response") {
		a({
			kind: "response",
			mode: "skip"
		}), a({
			kind: "response",
			mode: "coin"
		}), a({
			kind: "response",
			mode: "resource"
		}), a({ kind: "response" });
		let t = _[e.responseCard][1];
		t < 4 && o({ kind: "response" }, U([t]));
	} else if (e.phase === "card") for (let t of e.offered) {
		let r = {
			kind: "card",
			target: t
		}, i = _[t][0];
		a({
			...r,
			mode: "coin"
		}), a(r);
		for (let e = 0; e < 4; e++) a({
			...r,
			colors: [e]
		});
		if (i === "swapGoods") for (let e of s) o({
			...r,
			colors: e
		}, [
			0,
			0,
			0,
			0
		], 1);
		if (i === "buyBrown" && o(r, [
			0,
			0,
			0,
			0
		], 2), i === "buyMosque") for (let t of e.display) o({
			...r,
			discard: t
		}, [
			0,
			0,
			0,
			0
		], 2);
		if (i === "swapMosque") for (let t of n.mosques) for (let n of e.display) a({
			...r,
			discard: t.id,
			slot: n
		});
		for (let t = 0; t < 6; t++) {
			let n = e.tracks[t].findIndex(Boolean);
			if (n < 0) continue;
			let s = {
				...r,
				discard: t,
				slot: n
			};
			if (i === "payAll" && o(s, [
				1,
				1,
				1,
				1
			]), i === "paySame") for (let e = 0; e < 4; e++) o({
				...s,
				colors: [e]
			}, U([
				e,
				e,
				e
			]));
			i === "payBrown" && a({
				...s,
				goods: [
					0,
					0,
					0,
					0,
					2
				]
			}), i === "payMoney" && a(s);
		}
	}
	else {
		for (let e = 0; e < 4; e++) o({
			kind: "same",
			colors: [e]
		}, U([e, e]));
		for (let e = 0; e < 4; e++) for (let t = e + 1; t < 4; t++) {
			o({
				kind: "crystal",
				colors: [e, t]
			}, U([e, t]));
			for (let n = t + 1; n < 4; n++) o({
				kind: "brown",
				colors: [
					e,
					t,
					n
				]
			}, U([
				e,
				t,
				n
			]));
		}
		for (let e of s) o({
			kind: "two",
			colors: e
		}, [
			1,
			1,
			1,
			1
		]);
		let t = e.dice.flatMap((e, t) => e === 4 ? [t] : []);
		t.length && a({
			kind: "money",
			dice: t
		});
		let n = e.dice.flatMap((e, t) => e === 5 ? [t] : []);
		for (let e = 1; e <= n.length; e++) a({
			kind: "bazaar",
			dice: n.slice(0, e)
		});
		for (let t of e.display) {
			let e = g[t].color;
			o({
				kind: "mosque",
				target: t
			}, e < 0 ? [
				1,
				1,
				1,
				1
			] : U([
				e,
				e,
				e
			]));
		}
		for (let t = 0; t < 6; t++) {
			let n = e.tracks[t].findIndex(Boolean);
			n < 0 || (t === 5 ? a({
				kind: "ruby",
				target: t,
				slot: n
			}) : o({
				kind: "ruby",
				target: t,
				slot: n
			}, x(t, n, e.players.length), t === 4 ? n : 0));
		}
		e.config.promo && (a({
			kind: "promo",
			target: 0
		}), e.tracks.forEach((e, t) => e.forEach((e, n) => {
			e && a({
				kind: "promo",
				target: 1,
				discard: t,
				slot: n
			});
		})));
	}
	return r;
}
function _e(e, t) {
	return {
		public: {
			players: structuredClone(e.players),
			active: O(e).rid,
			round: e.round,
			phase: e.phase,
			dice: [...e.dice],
			actions: e.actions,
			tracks: e.tracks.map((e) => [...e]),
			display: [...e.display],
			deckCount: e.mosqueDeck.length,
			bazaarCount: e.bazaarDeck.length,
			discardCount: e.bazaarDiscard.length,
			offered: [...e.offered],
			cardDice: e.cardDice,
			responseCard: e.responseCard,
			responder: e.responder,
			finalRound: e.finalRound,
			promo: e.config.promo,
			promoUsed: [...e.promoUsed],
			stock: h.map((t, n) => P(e, n)),
			log: [...e.log],
			serial: e.serial
		},
		private: { moves: ge(e, t) }
	};
}
function ve(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (e) => e.money + k(e.goods) * 3 + e.crystals * 2, n = [...e.players].sort((e, n) => n.rubies - e.rubies || t(n) - t(e));
	return {
		phase: e.phase,
		ranking: n.map((e) => e.rid),
		winner: n.filter((e) => e.rubies === n[0].rubies && t(e) === t(n[0])).map((e) => e.rid),
		scores: Object.fromEntries(e.players.map((e) => [e.rid, e.rubies]))
	};
}
var ye = {
	meta: S,
	saveCompatibility: { version: "1" },
	schemas: {
		action: te,
		publicView: re,
		privateView: D,
		config: T
	},
	setup: fe,
	reduce: me,
	viewFor: _e,
	status: ve,
	nextTickIn: (e) => e.phase === "beat" && e.queue.length ? 650 : null
}, G = [
	"cloth",
	"fruit",
	"spice",
	"jewelry",
	"wild",
	"crystal",
	"money",
	"bazaar",
	"ruby"
];
function K() {
	let e = s();
	return (t, n) => e(`games.istanbuldice.${t}`, n);
}
function q({ r: e, count: t, label: n = !1 }) {
	let r = K(), a = G[e];
	return /* @__PURE__ */ u("span", {
		className: "id-resource",
		children: [/* @__PURE__ */ l("img", {
			src: i(`games/istanbuldice/${a}.svg`),
			alt: n ? r(a) : "",
			draggable: !1
		}), t !== void 0 && /* @__PURE__ */ l("b", { children: t })]
	});
}
function J({ name: e, label: t = "" }) {
	return /* @__PURE__ */ l("img", {
		className: "id-symbol",
		src: i(`games/istanbuldice/${e}.svg`),
		alt: t,
		draggable: !1
	});
}
function Y({ name: e, children: t, className: n = "" }) {
	let { ref: r, hidden: i } = o(e);
	return /* @__PURE__ */ l("div", {
		ref: r,
		className: n,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function be({ card: e }) {
	let t = K();
	return /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("span", {
		className: "id-card-number",
		children: t("cardNumber", { n: e + 1 })
	}), /* @__PURE__ */ l(xe, { card: e })] });
}
function X() {
	return /* @__PURE__ */ l("svg", {
		className: "id-march",
		"aria-hidden": "true",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		children: /* @__PURE__ */ l("rect", {
			x: "1.5",
			y: "1.5",
			width: "97",
			height: "97",
			rx: "8",
			pathLength: "100"
		})
	});
}
function Z({ id: e, compact: t = !1 }) {
	let n = K(), r = g[e], i = r.ability === "money" ? "abilityMoney" : r.ability === "crystal" ? "abilityCrystal" : r.ability === "bazaar" ? "abilityBazaar" : r.ability === "action" ? "abilityAction" : r.ability === "die" ? "abilityDie" : "abilityGoods";
	return /* @__PURE__ */ u("div", {
		className: `id-mosque-face${t ? " id-compact" : ""}`,
		children: [
			/* @__PURE__ */ l("div", {
				className: "id-cost",
				children: (r.color < 0 ? [
					0,
					1,
					2,
					3
				] : [
					r.color,
					r.color,
					r.color
				]).map((e, t) => /* @__PURE__ */ l(q, { r: e }, t))
			}),
			/* @__PURE__ */ l("div", {
				className: "id-ability-art",
				children: r.ability === "action" ? /* @__PURE__ */ u("span", {
					className: "id-action-icon",
					children: [/* @__PURE__ */ l("b", { children: "1" }), /* @__PURE__ */ l(J, { name: "action" })]
				}) : r.ability === "die" ? /* @__PURE__ */ l(J, { name: "extra-die" }) : /* @__PURE__ */ l(q, {
					r: r.ability === "money" ? 6 : r.ability === "crystal" ? 5 : r.ability === "bazaar" ? 7 : r.color,
					count: r.ability === "money" ? 3 : 1
				})
			}),
			/* @__PURE__ */ l("span", {
				className: "id-ability-label",
				children: n(i)
			})
		]
	});
}
function xe({ card: e }) {
	let t = K(), [n, r] = _[e], i = (e, t = 1) => /* @__PURE__ */ l(q, {
		r: e,
		count: t
	}), a = null, o = null, s = null, d = !1;
	return n === "exchange" && (o = i(6, 4), s = /* @__PURE__ */ u(c, { children: [
		i(r),
		/* @__PURE__ */ l("span", {
			className: "id-pay-arrow",
			children: "→"
		}),
		i(6, r === 5 ? 3 : 4)
	] })), n === "brownGift" && (o = i(4), s = i(r)), n === "buyGift" && (o = i(r), s = /* @__PURE__ */ u(c, { children: [
		i(6, 2),
		/* @__PURE__ */ l("span", {
			className: "id-pay-arrow",
			children: "→"
		}),
		i(r)
	] })), n === "choiceGift" && (o = /* @__PURE__ */ u(c, { children: [i(r), i(6, 3)] }), s = /* @__PURE__ */ u(c, { children: [
		i(r),
		/* @__PURE__ */ l("span", { children: "/" }),
		i(6, 3)
	] })), n.startsWith("hold") && (a = i(4, n === "holdAll" ? 3 : n === "holdBrown" ? 1 : 2), d = !0, o = n === "holdMoney" ? i(6, 6) : n === "holdCrystal" ? i(5, 2) : n === "holdAll" ? /* @__PURE__ */ l(c, { children: [
		0,
		1,
		2,
		3
	].map((e) => /* @__PURE__ */ l(q, { r: e }, e)) }) : i(4)), n.startsWith("two") && (a = i(7, 2), d = !0, o = n === "twoMoney" ? i(6, 5) : n === "twoBrown" ? i(4) : /* @__PURE__ */ l("span", {
		className: "id-four-colors",
		children: [
			0,
			1,
			2,
			3
		].map((e) => /* @__PURE__ */ l(q, { r: e }, e))
	})), [
		"payAll",
		"paySame",
		"payMoney",
		"payBrown"
	].includes(n) && (a = n === "payAll" ? /* @__PURE__ */ l(c, { children: [
		0,
		1,
		2,
		3
	].map((e) => /* @__PURE__ */ l(q, { r: e }, e)) }) : n === "payMoney" ? i(6, 10) : n === "payBrown" ? i(4, 2) : /* @__PURE__ */ l("span", {
		className: "id-goods-formula",
		children: [
			0,
			1,
			2
		].map((e) => /* @__PURE__ */ l(J, { name: "any-a" }, e))
	}), o = i(8)), (n === "swapGoods" || n === "buyBrown" || n === "buyMosque") && (a = /* @__PURE__ */ u("span", {
		className: "id-goods-formula",
		children: [/* @__PURE__ */ l(J, { name: "any-q" }), n !== "swapGoods" && /* @__PURE__ */ l(J, { name: "any-q" })]
	}), o = n === "buyBrown" ? i(4, 2) : n === "buyMosque" ? /* @__PURE__ */ l(J, {
		name: "mosque-back",
		label: t("mosque")
	}) : /* @__PURE__ */ u("span", {
		className: "id-four-colors",
		children: [[
			0,
			1,
			2,
			3
		].map((e) => /* @__PURE__ */ l(q, { r: e }, e)), /* @__PURE__ */ l("b", { children: "2" })]
	})), n === "swapMosque" && (a = /* @__PURE__ */ l(J, {
		name: "mosque-back",
		label: t("mosque")
	}), o = /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l(J, {
		name: "mosque-back",
		label: t("mosque")
	}), /* @__PURE__ */ u("span", {
		className: "id-action-icon",
		children: [/* @__PURE__ */ l("b", { children: "1" }), /* @__PURE__ */ l(J, { name: "action" })]
	})] })), /* @__PURE__ */ u("div", {
		className: "id-card-diagram",
		children: [
			/* @__PURE__ */ u("div", {
				className: "id-card-own",
				children: [
					/* @__PURE__ */ l(J, {
						name: "self",
						label: t("self")
					}),
					a,
					/* @__PURE__ */ l("span", {
						className: d ? "id-hold-arrow" : "id-pay-arrow",
						children: a ? "→" : ""
					}),
					o
				]
			}),
			s && /* @__PURE__ */ u("div", {
				className: "id-card-others",
				children: [/* @__PURE__ */ l(J, {
					name: "others",
					label: t("others")
				}), s]
			}),
			/* @__PURE__ */ l("p", { children: t(n) })
		]
	});
}
function Se({ pub: e, track: t, slot: n }) {
	let r = K(), i = r(t < 4 ? G[t] : t === 4 ? "allColors" : t === 5 ? "money" : "bonus"), a = t < 6 ? x(t, n, e.players.length) : [];
	return /* @__PURE__ */ u("span", {
		className: "id-ruby-choice",
		children: [
			/* @__PURE__ */ l(q, { r: 8 }),
			/* @__PURE__ */ u("span", { children: [
				i,
				" · ",
				r("rubySpot", { n: n + 1 })
			] }),
			t < 6 && /* @__PURE__ */ u("small", { children: [
				r("boardPrice"),
				": ",
				t === 5 ? /* @__PURE__ */ l(q, {
					r: 6,
					count: a[0]
				}) : /* @__PURE__ */ u(c, { children: [a.map((e, t) => e > 0 && /* @__PURE__ */ l(q, {
					r: t,
					count: e
				}, t)), t === 4 && n > 0 && /* @__PURE__ */ l("span", { children: r("extraGoods", { n }) })] })
			] })
		]
	});
}
function Ce({ move: e, pub: t }) {
	let n = K();
	if (e.kind === "card") {
		if (e.mode === "coin") return /* @__PURE__ */ l(q, {
			r: 6,
			count: 1
		});
		let n = _[e.target][0];
		if (n === "buyMosque") return /* @__PURE__ */ l(Z, {
			id: e.discard,
			compact: !0
		});
		if (n === "swapMosque") return /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l(Z, {
			id: e.slot,
			compact: !0
		}), /* @__PURE__ */ u("span", {
			className: "id-action-icon",
			children: [/* @__PURE__ */ l("b", { children: "1" }), /* @__PURE__ */ l(J, { name: "action" })]
		})] });
		if ([
			"payMoney",
			"paySame",
			"payAll",
			"payBrown"
		].includes(n)) return /* @__PURE__ */ l(Se, {
			pub: t,
			track: e.discard,
			slot: e.slot
		});
		if (e.colors.length) return /* @__PURE__ */ l(c, { children: e.colors.map((e, t) => /* @__PURE__ */ l(q, { r: e }, t)) });
		let r = _[e.target][1];
		return n === "exchange" ? /* @__PURE__ */ l(q, {
			r: 6,
			count: 4
		}) : n === "brownGift" || n === "holdBrown" || n === "twoBrown" ? /* @__PURE__ */ l(q, {
			r: 4,
			count: 1
		}) : n === "buyBrown" ? /* @__PURE__ */ l(q, {
			r: 4,
			count: 2
		}) : n === "buyGift" ? /* @__PURE__ */ l(q, {
			r,
			count: 1
		}) : n === "choiceGift" ? /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l(q, {
			r,
			count: 1
		}), /* @__PURE__ */ l(q, {
			r: 6,
			count: 3
		})] }) : n === "holdMoney" || n === "twoMoney" ? /* @__PURE__ */ l(q, {
			r: 6,
			count: n === "holdMoney" ? 6 : 5
		}) : n === "holdCrystal" ? /* @__PURE__ */ l(q, {
			r: 5,
			count: 2
		}) : /* @__PURE__ */ l(c, { children: [
			0,
			1,
			2,
			3
		].map((e) => /* @__PURE__ */ l(q, {
			r: e,
			count: 1
		}, e)) });
	}
	if (e.kind === "response") {
		if (e.mode === "skip") return /* @__PURE__ */ l(c, { children: n("decline") });
		let [r, i] = _[t.responseCard];
		return r === "exchange" ? /* @__PURE__ */ l(q, {
			r: 6,
			count: i === 5 ? 3 : 4
		}) : /* @__PURE__ */ l(q, {
			r: e.mode === "coin" ? 6 : i,
			count: e.mode === "coin" ? 3 : 1
		});
	}
	return e.kind === "mosque" ? /* @__PURE__ */ l(Z, {
		id: e.target,
		compact: !0
	}) : e.kind === "ruby" || e.kind === "promo" && e.target === 1 ? /* @__PURE__ */ l(Se, {
		pub: t,
		track: e.kind === "ruby" ? e.target : e.discard,
		slot: e.slot
	}) : e.kind === "promo" ? /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l(q, {
			r: 6,
			count: 6
		}),
		/* @__PURE__ */ l(q, { r: 5 }),
		/* @__PURE__ */ l(q, { r: 7 })
	] }) : e.kind === "money" ? /* @__PURE__ */ l(q, {
		r: 6,
		count: e.dice.length * 2
	}) : e.kind === "bazaar" ? /* @__PURE__ */ l(q, {
		r: 7,
		count: e.dice.length
	}) : e.kind === "crystal" ? /* @__PURE__ */ l(q, { r: 5 }) : e.kind === "brown" ? /* @__PURE__ */ l(q, { r: 4 }) : /* @__PURE__ */ l(c, { children: e.colors.map((e, t) => /* @__PURE__ */ l(q, { r: e }, t)) });
}
function we({ move: e, dice: t, pub: n }) {
	let r = K(), i = [];
	e.dice.forEach((e) => i.push(/* @__PURE__ */ l("span", {
		className: "id-paid-die",
		children: /* @__PURE__ */ l(q, { r: t[e] === 4 ? 6 : t[e] === 5 ? 7 : t[e] })
	}, "d" + e))), e.goods.forEach((e, t) => {
		e && i.push(/* @__PURE__ */ l(q, {
			r: t,
			count: e
		}, "g" + t));
	});
	let a = e.kind === "card" ? _[e.target][0] : null;
	if (e.kind === "ruby" && e.target === 5 && i.push(/* @__PURE__ */ l(q, {
		r: 6,
		count: 10 + e.slot * 2
	}, "money")), e.kind === "promo" && i.push(/* @__PURE__ */ l(q, {
		r: e.target === 0 ? 4 : 5,
		count: e.target === 0 ? 2 : 4
	}, "promo")), a === "payMoney" && e.mode === "effect" && i.push(/* @__PURE__ */ l(q, {
		r: 6,
		count: 10
	}, "money")), a === "swapMosque" && e.mode === "effect" && i.push(/* @__PURE__ */ l(Z, {
		id: e.discard,
		compact: !0
	}, "mosque")), e.kind === "response" && e.mode === "effect") {
		let [e, t] = _[n.responseCard];
		e === "exchange" && t === 5 && i.push(/* @__PURE__ */ l(q, {
			r: 5,
			count: 1
		}, "crystal")), e === "buyGift" && i.push(/* @__PURE__ */ l(q, {
			r: 6,
			count: 2
		}, "money"));
	}
	return /* @__PURE__ */ l("span", {
		className: "id-payment",
		children: i.length ? i : r("noCost")
	});
}
//#endregion
//#region src/games/istanbuldice/selection.ts
function Te(e, t, n, r, i) {
	let a = e.players.find((e) => e.rid === t);
	if (!a || i.some((e, t) => e > a.goods[t]) || new Set(r).size !== r.length) return null;
	let o = {
		...n,
		dice: [...r].sort((e, t) => e - t),
		goods: [...i]
	}, s = i.reduce((e, t) => e + t, 0) + r.length, c = [
		0,
		0,
		0,
		0
	], l = 0, u = (e) => {
		c = [
			0,
			1,
			2,
			3
		].map((t) => e.filter((e) => e === t).length);
	};
	if (o.kind === "money" || o.kind === "bazaar") {
		let t = o.kind === "money" ? 4 : 5;
		return i.some(Boolean) || !r.length || r.some((n) => e.dice[n] !== t) || r.length !== n.dice.length ? null : o;
	}
	if (o.kind === "same") u([o.colors[0], o.colors[0]]);
	else if (o.kind === "crystal" || o.kind === "brown") u(o.colors);
	else if (o.kind === "two") c = [
		1,
		1,
		1,
		1
	];
	else if (o.kind === "mosque") {
		let e = g[o.target].color;
		e < 0 ? c = [
			1,
			1,
			1,
			1
		] : u([
			e,
			e,
			e
		]);
	} else if (o.kind === "ruby" && o.target < 5) c = x(o.target, o.slot, e.players.length), l = o.target === 4 ? o.slot : 0;
	else if (o.kind === "card" && o.mode === "effect") {
		let e = _[o.target][0];
		if (e === "payAll") c = [
			1,
			1,
			1,
			1
		];
		else if (e === "paySame") u([
			o.colors[0],
			o.colors[0],
			o.colors[0]
		]);
		else if (e === "swapGoods") l = 1;
		else if (e === "buyMosque" || e === "buyBrown") l = 2;
		else if (e === "payBrown") return !r.length && i.every((e, t) => e === (t === 4 ? 2 : 0)) ? o : null;
	} else o.kind === "response" && o.mode === "effect" && _[e.responseCard][0] === "exchange" && _[e.responseCard][1] < 4 && u([_[e.responseCard][1]]);
	if (c.reduce((e, t) => e + t, 0) + l !== s) return null;
	let d = i.slice(0, 4);
	for (let n of r) {
		let r = e.dice[n];
		if (r < 0 || r > 3 || r === void 0 || e.active !== t) return null;
		d[r]++;
	}
	return c.reduce((e, t, n) => e + Math.max(0, t - d[n]), 0) > i[4] ? null : o;
}
//#endregion
//#region src/games/istanbuldice/view-player.tsx
function Ee(e) {
	return e.kind === "card" || e.kind === "mosque" || e.kind === "ruby" || e.kind === "promo" ? `${e.kind}:${e.target}` : e.kind === "same" ? `same:${e.colors[0]}` : e.kind;
}
function De(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ l(Me, {
		pub: t,
		priv: n,
		...e
	});
}
function Oe({ pub: e, members: t, myRid: n }) {
	return /* @__PURE__ */ l(Me, {
		pub: e,
		public: e,
		members: t,
		myRid: n,
		send: () => {},
		readOnly: !0
	});
}
function ke({ pub: e, choose: t, available: n = () => !1 }) {
	let r = K();
	return /* @__PURE__ */ l("div", {
		className: "id-tracks",
		children: e.tracks.slice(0, 6).map((i, a) => {
			let o = i.findIndex(Boolean), s = `ruby:${a}`, d = r(a < 4 ? G[a] : a === 4 ? "allColors" : "money");
			return /* @__PURE__ */ l(Y, {
				name: `track:${a}`,
				className: `id-track id-track-${a}`,
				children: /* @__PURE__ */ u("button", {
					type: "button",
					className: "id-track-hit",
					disabled: !t || !n(s),
					onClick: () => t?.(s),
					"aria-label": r("trackLabel", { resource: d }),
					children: [
						/* @__PURE__ */ u("span", {
							className: "id-track-heading",
							children: [a < 4 && /* @__PURE__ */ l(q, { r: a }), /* @__PURE__ */ l("b", { children: d })]
						}),
						/* @__PURE__ */ l("span", {
							className: "id-ruby-row",
							children: i.map((t, n) => /* @__PURE__ */ u("span", {
								className: `id-ruby-slot${t ? "" : " id-sold"}`,
								children: [
									/* @__PURE__ */ l(Y, {
										name: `ruby:${a}:${n}`,
										children: /* @__PURE__ */ l(q, { r: 8 })
									}),
									/* @__PURE__ */ l("span", {
										className: "id-price",
										children: a < 4 ? x(a, n, e.players.length)[a] : a === 4 ? /* @__PURE__ */ l(c, { children: n ? `4 + ${n}` : "4" }) : 10 + n * 2
									}),
									o === n && /* @__PURE__ */ l("span", { className: "id-next-mark" })
								]
							}, n))
						}),
						o < 0 && /* @__PURE__ */ l("span", {
							className: "id-sold-label",
							children: r("emptyTrack")
						}),
						n(s) && /* @__PURE__ */ l(X, {})
					]
				})
			}, a);
		})
	});
}
function Ae({ p: e, name: t, active: n, onClick: r }) {
	return /* @__PURE__ */ l(Y, {
		name: `seat:${e.rid}`,
		className: `id-ledger${n ? " id-active-ledger" : ""}`,
		children: /* @__PURE__ */ u("button", {
			className: "id-ledger-hit",
			type: "button",
			onClick: r,
			children: [/* @__PURE__ */ u("span", {
				className: "id-ledger-name",
				children: [
					t,
					/* @__PURE__ */ l(Y, {
						name: `owned:${e.rid}`,
						className: "id-mosque-count",
						children: /* @__PURE__ */ u("span", { children: [
							/* @__PURE__ */ l(J, { name: "mosque-back" }),
							" ",
							e.mosques.length
						] })
					}),
					/* @__PURE__ */ l(Y, {
						name: `ruby:${e.rid}`,
						children: /* @__PURE__ */ l(q, {
							r: 8,
							count: e.rubies
						})
					})
				]
			}), /* @__PURE__ */ u("span", {
				className: "id-ledger-resources",
				children: [
					e.goods.map((t, n) => /* @__PURE__ */ l(Y, {
						name: `resource:${e.rid}:${n}`,
						children: /* @__PURE__ */ l(q, {
							r: n,
							count: t
						})
					}, n)),
					/* @__PURE__ */ l(Y, {
						name: `resource:${e.rid}:5`,
						children: /* @__PURE__ */ l(q, {
							r: 5,
							count: e.crystals
						})
					}),
					/* @__PURE__ */ l(Y, {
						name: `resource:${e.rid}:6`,
						children: /* @__PURE__ */ l(q, {
							r: 6,
							count: e.money
						})
					})
				]
			})]
		})
	});
}
function je({ title: e, children: t, close: n, host: i }) {
	let a = K();
	return i ? r(/* @__PURE__ */ l("div", {
		className: "id-modal-shade",
		onClick: n,
		children: /* @__PURE__ */ u("section", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			className: "id-modal",
			onClick: (e) => e.stopPropagation(),
			onKeyDown: (e) => {
				e.key === "Escape" && n();
			},
			children: [/* @__PURE__ */ u("header", { children: [/* @__PURE__ */ l("h2", { children: e }), /* @__PURE__ */ l("button", {
				type: "button",
				onClick: n,
				children: a("close")
			})] }), t]
		})
	}), i) : null;
}
function Me({ pub: e, priv: t, members: r, myRid: o, send: s, readOnly: d = !1 }) {
	let [f, ee] = n(null), p = K(), [m, h] = n([]), [g, _] = n([
		0,
		0,
		0,
		0,
		0
	]), [y, b] = n(null), [x, S] = n(0), [C, w] = n(null), T = `${e.serial}:${e.phase}:${e.active}:${e.responder}`, [E, te] = n(T), [ne, re] = n(e.offered);
	E !== T && (te(T), h([]), _([
		0,
		0,
		0,
		0,
		0
	]), b(null), S(0)), e.offered.length && e.offered.join(",") !== ne.join(",") && re(e.offered);
	let D = (e) => r.find((t) => t.rid === e)?.name ?? e, O = e.players.find((e) => e.rid === o), k = e.responder ?? e.active, A = !d && k === o, j = A ? t?.moves ?? [] : [], M = m.length > 0 || g.some(Boolean), ie = M ? j.flatMap((t) => {
		let n = Te(e, o, t, m, g);
		return n ? [n] : [];
	}) : j, N = [...new Map(ie.map((e) => [JSON.stringify(e), e])).values()], P = (e) => N.some((t) => Ee(t) === e), F = (e) => {
		b(e), S(0);
	}, I = N.filter((e) => Ee(e) === y), L = I[Math.min(x, I.length - 1)], R = () => {
		L && s(L);
	}, z = d ? p("final") : A ? e.phase === "reroll" ? p("rerollPrompt") : e.phase === "card" ? p("cardPrompt") : e.phase === "response" ? p("responsePrompt") : e.phase === "beat" ? p("resolving") : p("actionPrompt") : p("waiting", { name: D(k) }), ae = (e) => {
		b(null), h((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
	}, B = (e, t, n, r) => /* @__PURE__ */ u("button", {
		className: "id-trade-tile",
		type: "button",
		disabled: !P(e),
		onClick: () => F(e),
		title: r,
		children: [
			/* @__PURE__ */ l("span", {
				className: "id-trade-diagram",
				children: n
			}),
			/* @__PURE__ */ l("span", { children: t }),
			P(e) && /* @__PURE__ */ l(X, {})
		]
	}, e), oe = /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("div", {
		className: "id-ledgers",
		children: e.players.map((e) => /* @__PURE__ */ l(Ae, {
			p: e,
			name: D(e.rid),
			active: !d && e.rid === k,
			onClick: () => w(e.rid)
		}, e.rid))
	}), /* @__PURE__ */ u("div", {
		className: "id-phase",
		children: [
			/* @__PURE__ */ u("span", { children: [
				e.finalRound ? p("finalRound") : p("round", { n: e.round }),
				" · ",
				/* @__PURE__ */ l(q, { r: 8 }),
				" ",
				v(e.players.length)
			] }),
			/* @__PURE__ */ l("strong", {
				"aria-live": "polite",
				children: z
			}),
			/* @__PURE__ */ l(Y, {
				name: "supply",
				children: /* @__PURE__ */ l("button", {
					onClick: () => w("stock"),
					type: "button",
					children: p("stock")
				})
			})
		]
	})] }), V = /* @__PURE__ */ u("div", {
		className: "id-counter",
		children: [/* @__PURE__ */ u("div", {
			className: "id-dice-shelf",
			children: [/* @__PURE__ */ l(Y, {
				name: "dice",
				className: "id-dice",
				children: e.dice.map((t, n) => /* @__PURE__ */ l(Y, {
					name: `die:${n}`,
					className: "id-die-anchor",
					children: /* @__PURE__ */ l("button", {
						type: "button",
						className: `id-die${m.includes(n) ? " id-selected" : ""}${t < 0 ? " id-spent" : ""}`,
						disabled: !A || t < 0 || ![
							"reroll",
							"action",
							"card"
						].includes(e.phase),
						"aria-pressed": m.includes(n),
						"aria-label": p("selectDie", {
							n: n + 1,
							resource: t < 0 ? "—" : p(G[t === 4 ? 6 : t === 5 ? 7 : t])
						}),
						onClick: () => ae(n),
						children: t >= 0 ? /* @__PURE__ */ l(q, { r: t === 4 ? 6 : t === 5 ? 7 : t }) : /* @__PURE__ */ l("span", { children: "—" })
					})
				}, n))
			}), /* @__PURE__ */ l("div", {
				className: "id-turn-tools",
				children: A && e.phase === "reroll" ? /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("button", {
					type: "button",
					disabled: !m.length || !O?.crystals,
					onClick: () => s({
						type: "reroll",
						dice: m
					}),
					children: p("reroll")
				}), /* @__PURE__ */ l("button", {
					className: "id-primary",
					type: "button",
					onClick: () => {
						h([]), s({ type: "keep" });
					},
					children: p("keep")
				})] }) : /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("span", { children: d ? p("final") : p("actionLeft", { n: e.actions }) }), !d && /* @__PURE__ */ l("button", {
					type: "button",
					disabled: !A || e.phase !== "action",
					onClick: () => s({ type: "end" }),
					children: p("end")
				})] })
			})]
		}), /* @__PURE__ */ u("div", {
			className: "id-personal-goods",
			children: [
				O?.goods.map((t, n) => /* @__PURE__ */ u("button", {
					type: "button",
					className: `id-good-marker${g[n] ? " id-selected" : ""}`,
					disabled: !A || ![
						"action",
						"card",
						"response"
					].includes(e.phase) || t === 0,
					onClick: () => {
						b(null), _((e) => e.map((e, r) => r === n ? (e + 1) % (t + 1) : e));
					},
					"aria-label": p("selectGood", {
						resource: p(G[n]),
						n: g[n]
					}),
					"aria-pressed": g[n] > 0,
					children: [/* @__PURE__ */ l(q, {
						r: n,
						count: t
					}), g[n] > 0 && /* @__PURE__ */ l("span", {
						className: "id-selected-count",
						children: g[n]
					})]
				}, n)),
				/* @__PURE__ */ l(q, {
					r: 5,
					count: O?.crystals ?? 0
				}),
				/* @__PURE__ */ l(q, {
					r: 6,
					count: O?.money ?? 0
				}),
				!d && /* @__PURE__ */ l("button", {
					type: "button",
					disabled: !M,
					onClick: () => {
						h([]), _([
							0,
							0,
							0,
							0,
							0
						]), b(null);
					},
					children: p("clear")
				})
			]
		})]
	}), H = e.offered.length ? e.offered : ne, U = /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("div", {
		className: `id-card-display${e.phase === "card" ? "" : " id-card-hidden"}`,
		"aria-hidden": e.phase !== "card",
		children: H.map((t) => /* @__PURE__ */ l(Y, {
			name: `card:${t}`,
			children: /* @__PURE__ */ u("button", {
				type: "button",
				className: "id-bazaar-card",
				disabled: e.phase !== "card" || !P(`card:${t}`),
				onClick: () => F(`card:${t}`),
				children: [/* @__PURE__ */ l(be, { card: t }), P(`card:${t}`) && /* @__PURE__ */ l(X, {})]
			})
		}, t))
	}), e.phase === "response" && /* @__PURE__ */ l("div", {
		className: "id-card-display",
		children: /* @__PURE__ */ u("div", {
			className: "id-bazaar-card",
			children: [/* @__PURE__ */ l(xe, { card: e.responseCard }), A && /* @__PURE__ */ l("button", {
				className: "id-primary",
				type: "button",
				onClick: () => F("response"),
				children: p("responsePrompt")
			})]
		})
	})] });
	return /* @__PURE__ */ l("div", {
		ref: ee,
		className: "id-root id-scene",
		children: /* @__PURE__ */ u(a, {
			adaptive: !0,
			banner: oe,
			actionsHeight: "id-actions-height",
			actions: V,
			overlay: U,
			children: [
				/* @__PURE__ */ u(Y, {
					name: "table",
					className: "id-table",
					children: [/* @__PURE__ */ l("img", {
						className: "id-arch",
						src: i("games/istanbuldice/istanbul-arch.svg"),
						alt: "",
						draggable: !1
					}), /* @__PURE__ */ u("div", {
						className: "id-main",
						children: [
							/* @__PURE__ */ l(ke, {
								pub: e,
								choose: F,
								available: P
							}),
							/* @__PURE__ */ u("section", {
								className: "id-market-wrap",
								children: [
									/* @__PURE__ */ u("h2", { children: [p("mosque"), /* @__PURE__ */ l(Y, {
										name: "mosque-deck",
										className: "id-deck-badge",
										children: /* @__PURE__ */ u("span", { children: [
											/* @__PURE__ */ l(J, { name: "mosque-back" }),
											" ",
											e.deckCount
										] })
									})] }),
									/* @__PURE__ */ l("div", {
										className: "id-market",
										children: e.display.map((e, t) => /* @__PURE__ */ l(Y, {
											name: `mosque-slot:${t}`,
											children: /* @__PURE__ */ u("button", {
												className: "id-mosque-tile",
												type: "button",
												disabled: !P(`mosque:${e}`),
												onClick: () => F(`mosque:${e}`),
												children: [/* @__PURE__ */ l(Z, { id: e }), P(`mosque:${e}`) && /* @__PURE__ */ l(X, {})]
											})
										}, t))
									}),
									/* @__PURE__ */ u("div", {
										className: "id-mosque-reward",
										children: [/* @__PURE__ */ l("span", { children: p("bonus") }), e.tracks[6].map((e, t) => /* @__PURE__ */ l("span", {
											className: e ? "" : "id-sold",
											children: /* @__PURE__ */ l(Y, {
												name: `ruby:6:${t}`,
												children: /* @__PURE__ */ l(q, { r: 8 })
											})
										}, t))]
									})
								]
							}),
							/* @__PURE__ */ u("section", {
								className: "id-trades",
								children: [
									[
										0,
										1,
										2,
										3
									].map((e) => B(`same:${e}`, p(G[e]), /* @__PURE__ */ u(c, { children: [
										/* @__PURE__ */ l(q, {
											r: e,
											count: 2
										}),
										/* @__PURE__ */ l("span", { children: "→" }),
										/* @__PURE__ */ l(q, { r: e })
									] }), p("sameDesc"))),
									B("crystal", p("crystal"), /* @__PURE__ */ u(c, { children: [
										/* @__PURE__ */ u("span", {
											className: "id-goods-formula",
											children: [/* @__PURE__ */ l(J, { name: "any-a" }), /* @__PURE__ */ l(J, { name: "any-b" })]
										}),
										/* @__PURE__ */ l("span", { children: "→" }),
										/* @__PURE__ */ l(q, { r: 5 })
									] }), p("crystalDesc")),
									B("brown", p("brown"), /* @__PURE__ */ u(c, { children: [
										/* @__PURE__ */ u("span", {
											className: "id-goods-formula",
											children: [
												/* @__PURE__ */ l(J, { name: "any-a" }),
												/* @__PURE__ */ l(J, { name: "any-b" }),
												/* @__PURE__ */ l(J, { name: "any-c" })
											]
										}),
										/* @__PURE__ */ l("span", { children: "→" }),
										/* @__PURE__ */ l(q, { r: 4 })
									] }), p("brownDesc")),
									B("two", p("two"), /* @__PURE__ */ u(c, { children: [
										/* @__PURE__ */ l("span", {
											className: "id-four-colors",
											children: [
												0,
												1,
												2,
												3
											].map((e) => /* @__PURE__ */ l(q, { r: e }, e))
										}),
										/* @__PURE__ */ l("span", { children: "→" }),
										/* @__PURE__ */ l("b", { children: "2" })
									] }), p("twoDesc")),
									B("money", p("money"), /* @__PURE__ */ u(c, { children: [
										/* @__PURE__ */ l(q, { r: 6 }),
										/* @__PURE__ */ l("span", { children: "→" }),
										/* @__PURE__ */ l(q, {
											r: 6,
											count: 2
										})
									] }), p("moneyDesc")),
									B("bazaar", p("bazaar"), /* @__PURE__ */ u(c, { children: [
										/* @__PURE__ */ l(q, { r: 7 }),
										/* @__PURE__ */ l("span", { children: "→" }),
										/* @__PURE__ */ l(q, { r: 7 })
									] }), p("bazaarDesc"))
								]
							}),
							e.promo && /* @__PURE__ */ l("section", {
								className: "id-promos",
								children: [0, 1].map((t) => /* @__PURE__ */ u("button", {
									className: "id-promo",
									type: "button",
									disabled: !P(`promo:${t}`),
									onClick: () => F(`promo:${t}`),
									children: [
										/* @__PURE__ */ l(q, {
											r: t === 0 ? 4 : 5,
											count: t === 0 ? 2 : 4
										}),
										/* @__PURE__ */ l("span", { children: "→" }),
										t === 0 ? /* @__PURE__ */ u(c, { children: [
											/* @__PURE__ */ l(q, {
												r: 6,
												count: 6
											}),
											/* @__PURE__ */ l(q, { r: 5 }),
											/* @__PURE__ */ l(q, { r: 7 })
										] }) : /* @__PURE__ */ l(q, { r: 8 }),
										/* @__PURE__ */ l("small", { children: e.promoUsed[t] ? p("used") : p(t === 0 ? "promoTrade" : "promoRuby") }),
										P(`promo:${t}`) && /* @__PURE__ */ l(X, {})
									]
								}, t))
							})
						]
					})]
				}),
				y && /* @__PURE__ */ u(je, {
					host: f,
					title: p("confirm"),
					close: () => b(null),
					children: [/* @__PURE__ */ l("div", {
						className: "id-plan-list",
						children: I.map((t, n) => /* @__PURE__ */ l("button", {
							type: "button",
							className: `id-plan${n === x ? " id-selected" : ""}`,
							onClick: () => S(n),
							children: t.kind === "response" && t.mode === "skip" ? p("decline") : /* @__PURE__ */ u(c, { children: [
								/* @__PURE__ */ u("span", { children: [p("payment"), /* @__PURE__ */ l(we, {
									move: t,
									dice: e.dice,
									pub: e
								})] }),
								/* @__PURE__ */ l("span", {
									className: "id-pay-arrow",
									children: "→"
								}),
								/* @__PURE__ */ u("span", { children: [p("receive"), /* @__PURE__ */ l(Ce, {
									move: t,
									pub: e
								})] })
							] })
						}, JSON.stringify(t)))
					}), /* @__PURE__ */ u("footer", { children: [/* @__PURE__ */ l("button", {
						type: "button",
						onClick: () => b(null),
						children: p("cancel")
					}), /* @__PURE__ */ l("button", {
						type: "button",
						className: "id-primary",
						disabled: !L,
						onClick: R,
						children: p("confirm")
					})] })]
				}),
				C && /* @__PURE__ */ l(je, {
					host: f,
					title: C === "stock" ? p("stock") : D(C),
					close: () => w(null),
					children: C === "stock" ? /* @__PURE__ */ l("div", {
						className: "id-stock",
						children: e.stock.map((e, t) => /* @__PURE__ */ u("span", { children: [/* @__PURE__ */ l(q, {
							r: t,
							count: e
						}), p(G[t])] }, t))
					}) : /* @__PURE__ */ l("div", {
						className: "id-owned",
						children: e.players.find((e) => e.rid === C)?.mosques.map((t) => /* @__PURE__ */ u("div", {
							className: "id-owned-tile",
							children: [/* @__PURE__ */ l(Z, { id: t.id }), t.ready > (e.players.find((e) => e.rid === C)?.turns ?? 0) && /* @__PURE__ */ l("small", { children: p("nextTurn") })]
						}, t.id))
					})
				})
			]
		})
	});
}
//#endregion
//#region src/games/istanbuldice/bot.ts
var Ne = {
	ruby: 24,
	engine: 1,
	token: 1.6,
	cash: .45,
	bazaar: 3
}, Pe = (e) => e.reduce((e, t) => e + t, 0);
function Fe(e, t, n, r = Ne) {
	let i = e.players.find((e) => e.rid === t), a = Math.max(...e.players.map((e) => e.rubies)) / v(e.players.length), o = Math.max(1, (1 - a) * 7), s = 0, c = (t) => {
		let n = g[t], a = n.ability === "action" ? 4.6 : n.ability === "die" ? 3 : n.ability === "money" ? 3 * r.cash : n.ability === "crystal" ? 1.2 : n.ability === "bazaar" ? r.bazaar : 1.6, s = !i.rewarded && i.mosques.length === y(e.players.length) - 1 ? r.ruby : 0;
		return a * o * r.engine + s;
	};
	if (n.kind === "ruby" && (s = r.ruby + (i.rubies + 1 >= v(e.players.length) ? 8 : 0) - (n.target === 5 ? (10 + n.slot * 2) * r.cash : 0)), n.kind === "mosque" && (s = c(n.target)), n.kind === "same" && (s = r.token), n.kind === "crystal" && (s = i.crystals < 2 ? 2 : .6), n.kind === "brown" && (s = r.token * 1.8), n.kind === "two" && (s = r.token * 2.2), n.kind === "money" && (s = n.dice.length * 2 * r.cash + i.mosques.filter((e) => e.ready <= i.turns && g[e.id].ability === "goods").length * r.token), n.kind === "bazaar" && (s = r.bazaar + (n.dice.length - 1) * .4), n.kind === "promo" && (s = n.target === 0 ? 6 * r.cash + 1.5 + r.bazaar - 2 * r.token * 1.5 : r.ruby - 5), n.kind === "response") {
		let [t, i] = _[e.responseCard];
		s = n.mode === "skip" ? 0 : n.mode === "coin" ? 3 * r.cash : n.mode === "resource" ? i === 5 ? 1.5 : r.token : t === "exchange" ? i === 5 ? 3 * r.cash - 1.5 : 4 * r.cash : r.token - 2 * r.cash;
	}
	if (n.kind === "card") {
		let e = _[n.target][0];
		s = n.mode === "coin" ? r.cash : e === "exchange" ? 4 * r.cash : e === "brownGift" || e === "holdBrown" || e === "twoBrown" ? r.token * 1.8 : e === "buyGift" || e === "twoColor" ? r.token : e === "choiceGift" ? r.token + 3 * r.cash : e === "holdMoney" ? 6 * r.cash : e === "holdCrystal" ? i.crystals < 2 ? 3 : 1 : e === "holdAll" ? 4 * r.token : e === "twoMoney" ? 5 * r.cash : e === "buyBrown" ? r.token * 3.6 : e === "swapGoods" ? r.token * 2.1 : e === "buyMosque" ? c(n.discard) : e === "swapMosque" ? c(n.slot) - c(n.discard) + 3 : r.ruby - (e === "payMoney" ? 10 * r.cash : e === "payBrown" ? r.token * 3.6 : 0);
	}
	let l = n.dice.length * .25, u = Pe(n.goods.slice(0, 4)) * r.token + n.goods[4] * r.token * 1.8;
	return s - l - u;
}
function Ie(e = Ne) {
	return (t, n) => {
		let r = t.public;
		if (r.phase === "reroll" && r.active === n.rid) return { action: { type: "keep" } };
		let i = t.private?.moves ?? [];
		if (!i.length) return r.phase === "action" && r.active === n.rid ? { action: { type: "end" } } : null;
		let a = i.map((t, i) => ({
			action: t,
			score: Fe(r, n.rid, t, e),
			i
		}));
		if (a.sort((e, t) => t.score - e.score || e.i - t.i), n.difficulty === "weak") {
			let e = a.filter((e) => [
				"ruby",
				"same",
				"money",
				"bazaar"
			].includes(e.action.kind));
			return { action: (e.length ? e : a)[0].action };
		}
		return { action: a[0].action };
	};
}
var Le = Ie(), Re = (e, t, n) => t === "supply" ? e.anchor("supply") : e.anchor(`resource:${t}:${n}`), Q = (e, t = 30) => ({
	x: e.x + e.w / 2 - t / 2,
	y: e.y + e.h / 2 - t / 2,
	w: t,
	h: t
}), $ = (e, t, n, r, i) => /* @__PURE__ */ l(f, {
	from: Q(e),
	to: Q(t),
	ms: 650,
	children: /* @__PURE__ */ l("span", {
		className: "id-pay-sprite",
		style: {
			width: 30,
			height: 30
		},
		children: /* @__PURE__ */ l(q, {
			r: n,
			count: r > 1 ? r : void 0
		})
	})
}, i), ze = {
	roll(e, t) {
		let n = e.data;
		if (!n?.dice) return null;
		let r = [], i = [];
		return n.dice.forEach((e, a) => {
			if (n.selected && !n.selected.includes(a)) return;
			let o = t.anchor(`die:${a}`);
			o && (i.push(`die:${a}`), r.push(/* @__PURE__ */ l("div", {
				className: "id-roll-sprite",
				style: {
					position: "absolute",
					left: o.x,
					top: o.y,
					width: o.w,
					height: o.h
				},
				children: /* @__PURE__ */ l("span", {
					className: "id-die",
					style: {
						width: o.w,
						height: o.h,
						fontSize: o.h * .63
					},
					children: e < 0 ? "—" : /* @__PURE__ */ l(q, { r: e === 4 ? 6 : e === 5 ? 7 : e })
				})
			}, a)));
		}), {
			ms: 650,
			hide: i,
			node: /* @__PURE__ */ l(c, { children: r })
		};
	},
	ruby(e, t) {
		let n = e.data, r = t.anchor(`ruby:${n.track}:${n.slot}`), i = t.anchor(`ruby:${e.rid}`);
		return !r || !i ? null : {
			ms: 650,
			hide: t.queued ? [] : [`ruby:${e.rid}`],
			node: $(r, i, 8, 1, "ruby")
		};
	},
	mosque(e, t) {
		let n = e.data, r = t.anchor(`mosque-slot:${n.slot}`), i = t.anchor(`owned:${e.rid}`), a = t.anchor("mosque-deck");
		return !r || !i ? null : {
			ms: 650,
			hide: t.queued ? [] : [`owned:${e.rid}`, `mosque-slot:${n.slot}`],
			node: /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l(f, {
				from: r,
				to: i,
				ms: 650,
				children: /* @__PURE__ */ l("div", {
					className: "id-tile-sprite",
					style: {
						width: r.w,
						height: r.h
					},
					children: /* @__PURE__ */ l(Z, { id: n.tile })
				})
			}), n.refill >= 0 && a && /* @__PURE__ */ l(f, {
				from: Q(a, 24),
				to: r,
				ms: 650,
				children: /* @__PURE__ */ l("span", {
					className: "id-tile-back",
					style: {
						width: 24,
						height: 24
					},
					children: /* @__PURE__ */ l(J, { name: "mosque-back" })
				})
			})] })
		};
	},
	returnMosque(e, t) {
		let n = t.anchor(`owned:${e.rid}`), r = t.anchor("mosque-deck");
		return !n || !r ? null : {
			ms: 650,
			node: /* @__PURE__ */ l(f, {
				from: Q(n, 24),
				to: Q(r, 24),
				ms: 650,
				children: /* @__PURE__ */ l("span", {
					className: "id-tile-back",
					style: {
						width: 24,
						height: 24
					},
					children: /* @__PURE__ */ l(J, { name: "mosque-back" })
				})
			})
		};
	},
	resources(e, t) {
		let n = e.data.moves.flatMap((e, n) => {
			let r = Re(t, e.from, e.resource), i = Re(t, e.to, e.resource);
			return !r || !i || !e.count ? [] : [$(r, i, e.resource, e.count, String(n)), /* @__PURE__ */ l(d, {
				at: i,
				ms: 650,
				children: /* @__PURE__ */ l("span", {
					className: "id-fx-resource",
					children: /* @__PURE__ */ l(q, {
						r: e.resource,
						count: e.count
					})
				})
			}, "f" + n)];
		});
		return {
			ms: 650,
			node: /* @__PURE__ */ l(c, { children: n })
		};
	},
	pay(e, t) {
		let n = e.data, r = t.anchor("supply");
		if (!r) return null;
		let i = [];
		return n.dice?.forEach(({ index: e, face: n }) => {
			let a = t.anchor(`die:${e}`);
			a && i.push($(a, r, n === 4 ? 6 : n === 5 ? 7 : n, 1, "d" + e));
		}), [
			...n.goods ?? [
				0,
				0,
				0,
				0,
				0
			],
			n.crystals ?? 0,
			n.money ?? 0
		].forEach((n, a) => {
			let o = Re(t, e.rid, a);
			n && o && i.push($(o, r, a, n, "p" + a));
		}), {
			ms: 650,
			node: /* @__PURE__ */ l(c, { children: i })
		};
	},
	draw(e, t) {
		let n = e.data, r = t.anchor("supply");
		if (!r) return null;
		let i = [], a = n.cards.flatMap((e) => {
			let n = t.anchor(`card:${e}`);
			if (!n) return [];
			i.push(`card:${e}`);
			let a = n.h * 32 / n.w, o = {
				x: r.x + r.w / 2 - 16,
				y: r.y + r.h / 2 - a / 2,
				w: 32,
				h: a
			};
			return [/* @__PURE__ */ l(f, {
				from: o,
				to: n,
				ms: 650,
				children: /* @__PURE__ */ l("span", {
					className: "id-bazaar-back",
					style: {
						width: 32,
						height: a
					},
					children: /* @__PURE__ */ l(q, { r: 7 })
				})
			}, e)];
		});
		return {
			ms: 650,
			hide: t.queued ? [] : i,
			node: /* @__PURE__ */ l(c, { children: a })
		};
	},
	discard(e, t) {
		let n = e.data, r = t.anchor("supply");
		return r ? {
			ms: 650,
			node: /* @__PURE__ */ l(c, { children: n.cards.map((e) => {
				let n = t.anchor(`card:${e}`);
				return n ? /* @__PURE__ */ l(f, {
					from: n,
					to: Q(r, 24),
					ms: 650,
					children: /* @__PURE__ */ l("div", {
						className: "id-bazaar-card",
						style: {
							width: n.w,
							height: n.h,
							minWidth: 0
						},
						children: /* @__PURE__ */ l(be, { card: e })
					})
				}, e) : null;
			}) })
		} : null;
	}
}, Be = (e) => e.money + e.goods.reduce((e, t) => e + t, 0) * 3 + e.crystals * 2;
function Ve({ result: e, public: t, members: r, myRid: i, hintCount: a, onPlayAgain: o, onBackToLobby: c }) {
	let d = K(), f = s(), p = t, [m, h] = n(!0), g = (e) => r.find((t) => t.rid === e)?.name ?? e, _ = e.ranking.map((e) => p.players.find((t) => t.rid === e));
	return /* @__PURE__ */ u("div", {
		className: "id-root id-ending-scene",
		children: [
			/* @__PURE__ */ l("div", {
				className: "id-final-board",
				inert: m,
				children: /* @__PURE__ */ l(Oe, {
					pub: p,
					members: r,
					myRid: i
				})
			}),
			/* @__PURE__ */ l("div", {
				className: "id-ending-shade",
				hidden: !m,
				children: /* @__PURE__ */ u("section", {
					className: "id-results",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": d("final"),
					children: [
						/* @__PURE__ */ u("header", {
							className: "id-results-header",
							children: [
								/* @__PURE__ */ l("button", {
									className: "id-collapse",
									type: "button",
									"aria-label": d("hideResults"),
									onClick: () => h(!1),
									children: "⌄"
								}),
								/* @__PURE__ */ l(q, { r: 8 }),
								/* @__PURE__ */ l("span", { children: d("final") }),
								/* @__PURE__ */ l("h1", { children: d(e.winner.length > 1 ? "sharedWinner" : "winner") }),
								/* @__PURE__ */ l("h2", { children: e.winner.map(g).join(" · ") })
							]
						}),
						/* @__PURE__ */ u("div", {
							className: "id-results-scroll",
							children: [a !== void 0 && a > 0 && /* @__PURE__ */ l("p", { children: f("session.hint.usedCount", { n: a }) }), /* @__PURE__ */ u("table", {
								className: "id-score-table",
								children: [/* @__PURE__ */ l("thead", { children: /* @__PURE__ */ u("tr", { children: [/* @__PURE__ */ l("th", { "aria-label": d("final") }), _.map((t) => {
									let n = _.findIndex((e) => e.rubies === t.rubies && Be(e) === Be(t)) + 1, r = e.autopilot?.[t.rid];
									return /* @__PURE__ */ u("th", {
										className: e.winner.includes(t.rid) ? "id-winner" : "",
										children: [
											/* @__PURE__ */ l("span", {
												className: "id-result-rank",
												children: n
											}),
											/* @__PURE__ */ l("span", { children: g(t.rid) }),
											e.winner.includes(t.rid) && /* @__PURE__ */ l("small", { children: d("winner") }),
											r !== void 0 && r > 0 && /* @__PURE__ */ l("small", { children: f("session.autopilot.share", { n: Math.round(r * 100) }) })
										]
									}, t.rid);
								})] }) }), /* @__PURE__ */ u("tbody", { children: [
									/* @__PURE__ */ u("tr", {
										className: "id-score-rubies",
										children: [/* @__PURE__ */ l("th", { children: /* @__PURE__ */ l(q, {
											r: 8,
											label: !0
										}) }), _.map((e) => /* @__PURE__ */ l("td", { children: e.rubies }, e.rid))]
									}),
									/* @__PURE__ */ u("tr", { children: [/* @__PURE__ */ l("th", { children: /* @__PURE__ */ l(q, {
										r: 6,
										label: !0
									}) }), _.map((e) => /* @__PURE__ */ l("td", { children: e.money }, e.rid))] }),
									[
										0,
										1,
										2,
										3,
										4
									].map((e) => /* @__PURE__ */ u("tr", { children: [/* @__PURE__ */ l("th", { children: /* @__PURE__ */ l(q, {
										r: e,
										label: !0
									}) }), _.map((t) => /* @__PURE__ */ l("td", { children: t.goods[e] }, t.rid))] }, e)),
									/* @__PURE__ */ u("tr", { children: [/* @__PURE__ */ l("th", { children: /* @__PURE__ */ l(q, {
										r: 5,
										label: !0
									}) }), _.map((e) => /* @__PURE__ */ l("td", { children: e.crystals }, e.rid))] }),
									/* @__PURE__ */ u("tr", {
										className: "id-score-assets",
										children: [/* @__PURE__ */ l("th", { children: d("tieValue") }), _.map((e) => /* @__PURE__ */ l("td", { children: Be(e) }, e.rid))]
									})
								] })]
							})]
						}),
						/* @__PURE__ */ u("footer", {
							className: "id-final-controls",
							children: [
								o && /* @__PURE__ */ l(ee, {
									label: d("playAgain"),
									confirmLabel: d("confirmAgain"),
									onConfirm: o
								}),
								c && /* @__PURE__ */ l(ee, {
									label: d("lobby"),
									confirmLabel: d("confirmAgain"),
									onConfirm: c
								}),
								!o && !c && /* @__PURE__ */ l("span", { children: d("waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ l("button", {
				className: "id-show-results",
				type: "button",
				hidden: m,
				onClick: () => h(!0),
				children: d("showResults")
			})
		]
	});
}
//#endregion
//#region src/games/istanbuldice/options.tsx
function He({ value: e, onChange: t }) {
	let n = K(), r = T.safeParse(e), i = r.success ? r.data : T.parse(void 0);
	return /* @__PURE__ */ l(p, {
		title: n("promo"),
		children: /* @__PURE__ */ l(m, {
			checked: i.promo,
			label: n(i.promo ? "promoOn" : "promoOff"),
			accent: S.accent,
			onChange: () => t({
				...i,
				promo: !i.promo
			})
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/istanbuldice/entry.tsx
var Ue = {
	definition: ye,
	View: De,
	bot: Le,
	fx: ze,
	OverView: Ve,
	Options: He,
	locales: {
		zh: {
			name: "伊斯坦堡：骰子版",
			desc: "掷骰收集货物，建设清真寺，争先获得红宝石。支持官方清真寺促销扩展。",
			cloth: "布料",
			fruit: "水果",
			spice: "香料",
			jewelry: "珠宝",
			wild: "通配货物",
			crystal: "水晶",
			money: "里拉",
			bazaar: "市集",
			ruby: "红宝石",
			mosque: "清真寺",
			self: "本人",
			others: "其他玩家",
			round: "第{{n}}轮",
			finalRound: "最后一轮",
			actionLeft: "剩余{{n}}次行动",
			waiting: "等待{{name}}",
			resolving: "正在结算",
			rerollPrompt: "选择要重掷的骰子",
			actionPrompt: "选择货物、骰子或交易目标",
			cardPrompt: "选择并使用一张市集牌",
			responsePrompt: "选择市集收益",
			keep: "保留骰面",
			reroll: "支付1水晶并重掷",
			end: "结束回合",
			confirm: "确认交易",
			cancel: "取消",
			clear: "清除选择",
			payment: "支付",
			receive: "获得",
			noCost: "无需支付",
			stock: "公共供应",
			owned: "持有的清真寺",
			nextTurn: "下回合生效",
			same: "同色货物",
			sameDesc: "支付2个同色货物，获得1个该色货物标记。",
			crystalDesc: "支付2个不同色货物，获得1水晶。",
			brown: "通配货物",
			brownDesc: "支付3个不同色货物，获得1个通配货物。",
			two: "自选货物",
			twoDesc: "支付四色各1个货物，获得2个自选非棕色货物。",
			moneyDesc: "弃掉全部剩余里拉骰面，每个获得2里拉。",
			bazaarDesc: "弃掉任意数量市集骰面，翻开同数量市集牌并使用1张。",
			buy: "购买",
			cost: "费用",
			allColors: "四色各1",
			extraGoods: "另加{{n}}个任意货物",
			emptyTrack: "已取完",
			bonus: "清真寺奖励",
			promo: "清真寺促销扩展",
			promoOff: "关闭",
			promoOn: "启用",
			used: "已使用",
			promoTrade: "支付2个通配货物，获得6里拉、1水晶和1张市集牌。",
			promoRuby: "支付4水晶，从版图任意位置获得1颗红宝石。",
			abilityMoney: "每回合开始获得3里拉",
			abilityCrystal: "每回合开始获得1水晶",
			abilityBazaar: "每回合开始使用1张市集牌",
			abilityAction: "每回合增加1次行动",
			abilityDie: "每回合增加1个骰子",
			abilityGoods: "每次领取里拉时获得1个对应色货物",
			cardNumber: "市集牌{{n}}",
			decline: "放弃交易",
			takeCoin: "改为获得1里拉",
			takeMoney: "获得3里拉",
			takeResource: "获得对应资源",
			exchange: "你获得4里拉。其他玩家可支付图示资源，获得4里拉（水晶换3里拉）。",
			holdMoney: "若持有至少2个通配货物，获得6里拉；否则或不愿执行时获得1里拉。",
			holdCrystal: "若持有至少2个通配货物，获得2水晶；否则或不愿执行时获得1里拉。",
			payBrown: "支付2个通配货物，获得任一非清真寺轨道的下一颗红宝石；或获得1里拉。",
			brownGift: "你获得1个通配货物。其他玩家各获得图示颜色的1个货物标记。",
			swapGoods: "支付1个任意货物，获得2个自选非棕色货物标记；或获得1里拉。",
			holdAll: "若持有至少3个通配货物，获得四色货物各1个；否则或不愿执行时获得1里拉。",
			swapMosque: "弃掉自己1块清真寺，拿取展示区1块清真寺，并增加本回合1次行动；或获得1里拉。",
			twoColor: "若本次行动使用至少2个市集骰面，获得1个自选非棕色货物；否则或不愿执行时获得1里拉。",
			twoBrown: "若本次行动使用至少2个市集骰面，获得1个通配货物；否则或不愿执行时获得1里拉。",
			twoMoney: "若本次行动使用至少2个市集骰面，获得5里拉；否则或不愿执行时获得1里拉。",
			payAll: "支付四色货物各1个，获得任一非清真寺轨道的下一颗红宝石；或获得1里拉。",
			paySame: "支付3个同色货物，获得任一非清真寺轨道的下一颗红宝石；或获得1里拉。",
			buyGift: "你获得图示颜色的1个货物。其他玩家可支付2里拉，获得1个该色货物。",
			holdBrown: "若持有至少1个通配货物，获得1个通配货物；否则或不愿执行时获得1里拉。",
			choiceGift: "你获得图示资源和3里拉。其他玩家各选择获得图示资源1个或3里拉。",
			payMoney: "支付10里拉，获得任一非清真寺轨道的下一颗红宝石；或获得1里拉。",
			buyMosque: "支付2个任意货物，拿取展示区1块清真寺；或获得1里拉。",
			buyBrown: "支付2个任意货物，获得2个通配货物；或获得1里拉。",
			selectDie: "选择第{{n}}个骰子：{{resource}}",
			selectGood: "选择{{resource}}货物标记，已选{{n}}个",
			trackLabel: "{{resource}}红宝石轨道",
			winner: "市集大师",
			final: "交易结束",
			tieValue: "剩余资产折合",
			assetDetail: "{{money}}里拉 · {{goods}}货物 · {{crystals}}水晶",
			playAgain: "再来一局",
			lobby: "返回大堂",
			reviewBoard: "回看版图",
			close: "关闭",
			log: "对局记录",
			logGain: "获得资源",
			logDraw: "翻开市集牌",
			logRoll: "掷骰",
			logReroll: "重掷骰子",
			logGift: "获得市集赠礼",
			logTrade: "完成交易",
			errAction: "当前不能执行该交易，请重新选择可用的骰子、货物或目标。",
			boardPrice: "原轨道费用",
			rubySpot: "轨道第{{n}}格",
			hideResults: "收起结算",
			showResults: "查看结算",
			waitHost: "等待主机决定下一步",
			confirmAgain: "再次点击确认",
			sharedWinner: "共享胜利",
			rules: "目标：\n两人或三人游戏中，有玩家收集至少 6 颗红宝石时，触发最后一轮；四人游戏中，触发门槛为 5 颗。完成当前轮，让所有玩家经历相同数量的回合，再进行结算。\n红宝石最多的玩家获胜。红宝石数量相同时，将剩余里拉与资源折算价值相加：每个货物标记按 3 里拉计算，每颗水晶按 2 里拉计算，总价值较高的玩家获胜；仍然相同时，共享胜利。\n设置：\n· 每名玩家获得 1 颗水晶。起始玩家以 0 里拉开始游戏，之后按顺时针方向，每名玩家比前一名玩家多获得 1 里拉。\n· 展示 6 块清真寺板块，并将 33 张市集牌洗混。\n· 两人游戏中，移除标有三人标记的 2 颗红宝石。此时，四色地毯上最便宜的红宝石需要四种颜色的货物各 1 个，再加任意颜色货物 1 个；里拉轨道上最便宜的红宝石需要 12 里拉。\n回合：\n先领取清真寺提供的收入，再掷 5 枚骰子。每支付 1 颗水晶，可以重掷任意数量的骰子；可以多次重掷，每次均须支付相应的水晶费用。确认保留骰面后，通常执行 2 次行动，再由下一名玩家开始回合。\n货物：\n四色货物标记可替代对应货物骰面，棕色可替代任意一种货物色，不能替代里拉或市集骰面。每个骰子每回合只能使用一次。\n行动：\n· 支付 2 个同色货物，获得 1 个该色货物标记。\n· 支付 2 个不同色货物，获得 1 颗水晶。\n· 支付 3 个不同色货物，获得 1 个通配货物。\n· 支付四色货物各 1 个，获得 2 个自选的非棕色货物。\n· 弃掉全部剩余的里拉骰子，每个里拉骰面提供 2 里拉。\n· 弃掉任意数量的市集骰子，翻开相同数量的市集牌，从中选择使用 1 张，然后弃掉全部翻开的牌。牌堆耗尽时，将市集弃牌混洗成新牌堆。\n清真寺：\n支付清真寺板块所示的费用，领取该板块，并立即补充陈列区。新获得的板块从自己的下个回合开始生效，同类板块的效果可以叠加。\n两人或三人游戏中，自己的清真寺数量恰好达到 5 块时，立即从清真寺区获得 1 颗红宝石；四人游戏中，所需数量为 4 块。每名玩家整局只能获得一次这项奖励。\n购买红宝石：\n购买红宝石时，支付所选轨道上下一颗红宝石的费用，并从费用最低的一端依次领取。\n· 单色货物轨道：两人或三人游戏中，依次需要支付 4 个、5 个和 6 个对应颜色的货物；四人游戏中，依次需要支付 4 个、4 个、5 个和 6 个。\n· 四色地毯：每次都需要支付四种颜色的货物各 1 个，再根据所选位置额外支付 0 至 4 个任意颜色的货物。\n· 里拉地毯：各位置的费用依次为 10、12、14、16、18、20 里拉。\n市集：\n· 牌面红箭头表示需要支付对应资源；白箭头表示只需持有对应资源，不必将其弃置。\n· 有替代选项的牌可以不执行原效果，改为获得 1 里拉。涉及对手的可选效果时，由该对手自行决定是否执行。\n· 回合开始时因收入而翻开的市集牌，不能视为满足「使用至少 2 枚市集骰子」的条件。\n每张市集牌的具体效果以牌面说明为准。\n有限供应：\n获得某种货物、水晶或里拉时，如果公共供应不足，所有持有该资源的玩家各归还 1 个单位的该资源；必要时重复此过程，直到公共供应足够，再领取资源。里拉按照数值处理，可以进行等值换零。\n可选促销：\n两块公共板块各整局仅一次，且不计入清真寺数量。\n· 支付 2 个通配货物，获得 6 里拉、1 颗水晶和 1 张市集牌，占用一次行动。\n· 支付 4 颗水晶，取得版图上任意一颗红宝石，占用一次行动。"
		},
		en: {
			name: "Istanbul: The Dice Game",
			desc: "Roll for goods, build your mosque engine and race for rubies. Includes the official Mosque promo.",
			cloth: "Cloth",
			fruit: "Fruit",
			spice: "Spices",
			jewelry: "Jewelry",
			wild: "Wild goods",
			crystal: "Crystal",
			money: "Lira",
			bazaar: "Bazaar",
			ruby: "Ruby",
			mosque: "Mosque",
			self: "You",
			others: "Other players",
			round: "Round {{n}}",
			finalRound: "Final round",
			actionLeft: "{{n}} actions left",
			waiting: "Waiting for {{name}}",
			resolving: "Resolving",
			rerollPrompt: "Select dice to reroll",
			actionPrompt: "Select goods, dice or a trade target",
			cardPrompt: "Choose and use one Bazaar card",
			responsePrompt: "Choose your Bazaar benefit",
			keep: "Keep dice",
			reroll: "Pay 1 crystal and reroll",
			end: "End turn",
			confirm: "Confirm trade",
			cancel: "Cancel",
			clear: "Clear selection",
			payment: "Pay",
			receive: "Receive",
			noCost: "No payment",
			stock: "Supply",
			owned: "Your mosques",
			nextTurn: "Active next turn",
			same: "Matching goods",
			sameDesc: "Pay 2 identical goods for 1 goods marker of that color.",
			crystalDesc: "Pay 2 different goods for 1 crystal.",
			brown: "Wild goods",
			brownDesc: "Pay 3 different goods for 1 wild goods marker.",
			two: "Choose goods",
			twoDesc: "Pay 1 of each color for 2 non-brown goods markers of your choice.",
			moneyDesc: "Discard all remaining Lira dice and receive 2 Lira per die.",
			bazaarDesc: "Discard any number of Bazaar dice, reveal that many cards, and use one.",
			buy: "Buy",
			cost: "Cost",
			allColors: "1 of each color",
			extraGoods: "Plus {{n}} goods of any color",
			emptyTrack: "Sold out",
			bonus: "Mosque reward",
			promo: "Mosque promo expansion",
			promoOff: "Off",
			promoOn: "On",
			used: "Used",
			promoTrade: "Pay 2 wild goods for 6 Lira, 1 crystal and 1 Bazaar card.",
			promoRuby: "Pay 4 crystals for any ruby on the board.",
			abilityMoney: "Receive 3 Lira at the start of each turn",
			abilityCrystal: "Receive 1 crystal at the start of each turn",
			abilityBazaar: "Use 1 Bazaar card at the start of each turn",
			abilityAction: "One additional action each turn",
			abilityDie: "One additional die each turn",
			abilityGoods: "Receive 1 matching goods marker whenever you take Lira",
			cardNumber: "Bazaar card {{n}}",
			decline: "Decline trade",
			takeCoin: "Receive 1 Lira instead",
			takeMoney: "Receive 3 Lira",
			takeResource: "Receive the depicted resource",
			exchange: "Receive 4 Lira. Other players may pay the depicted resource for 4 Lira (a crystal gives 3 Lira).",
			holdMoney: "If you hold at least 2 wild goods, receive 6 Lira. Otherwise, or if you decline, receive 1 Lira.",
			holdCrystal: "If you hold at least 2 wild goods, receive 2 crystals. Otherwise, or if you decline, receive 1 Lira.",
			payBrown: "Pay 2 wild goods for the next ruby from any trade track except the Mosque area, or receive 1 Lira.",
			brownGift: "Receive 1 wild goods marker. Each other player receives 1 goods marker of the depicted color.",
			swapGoods: "Pay 1 goods for 2 non-brown goods markers of your choice, or receive 1 Lira.",
			holdAll: "If you hold at least 3 wild goods, receive 1 goods of each color. Otherwise, or if you decline, receive 1 Lira.",
			swapMosque: "Discard one of your mosques, take one from the display and gain one action this turn, or receive 1 Lira.",
			twoColor: "If you used at least 2 Bazaar dice for this action, receive 1 non-brown goods of your choice. Otherwise, or if you decline, receive 1 Lira.",
			twoBrown: "If you used at least 2 Bazaar dice for this action, receive 1 wild goods. Otherwise, or if you decline, receive 1 Lira.",
			twoMoney: "If you used at least 2 Bazaar dice for this action, receive 5 Lira. Otherwise, or if you decline, receive 1 Lira.",
			payAll: "Pay 1 goods of each color for the next ruby from any trade track except the Mosque area, or receive 1 Lira.",
			paySame: "Pay 3 identical goods for the next ruby from any trade track except the Mosque area, or receive 1 Lira.",
			buyGift: "Receive 1 goods of the depicted color. Other players may pay 2 Lira for 1 goods of that color.",
			holdBrown: "If you hold at least 1 wild goods, receive 1 wild goods. Otherwise, or if you decline, receive 1 Lira.",
			choiceGift: "Receive the depicted resource and 3 Lira. Each other player chooses 1 depicted resource or 3 Lira.",
			payMoney: "Pay 10 Lira for the next ruby from any trade track except the Mosque area, or receive 1 Lira.",
			buyMosque: "Pay 2 goods of any colors for a mosque from the display, or receive 1 Lira.",
			buyBrown: "Pay 2 goods of any colors for 2 wild goods, or receive 1 Lira.",
			selectDie: "Select die {{n}}: {{resource}}",
			selectGood: "Select {{resource}} goods markers, {{n}} selected",
			trackLabel: "{{resource}} ruby track",
			winner: "Master of the Bazaar",
			final: "Trading complete",
			tieValue: "Remaining asset value",
			assetDetail: "{{money}} Lira · {{goods}} goods · {{crystals}} crystals",
			playAgain: "Play again",
			lobby: "Back to lobby",
			reviewBoard: "Review board",
			close: "Close",
			log: "Game log",
			logGain: "Received resources",
			logDraw: "Revealed Bazaar cards",
			logRoll: "Rolled dice",
			logReroll: "Rerolled dice",
			logGift: "Received a Bazaar gift",
			logTrade: "Completed a trade",
			errAction: "That trade is unavailable. Choose available dice, goods or a target again.",
			boardPrice: "Original track price",
			rubySpot: "Track space {{n}}",
			hideResults: "Collapse results",
			showResults: "Show results",
			waitHost: "Waiting for the host",
			confirmAgain: "Click again to confirm",
			sharedWinner: "Shared victory",
			rules: "Goal:\nCollect at least 6 rubies with 2–3 players, or 5 with 4 players, to trigger the final round. Finish the round so everyone has the same number of turns. The player with the most rubies wins. For a tie, add each tied player’s remaining Lira to the value of their resources, counting 3 Lira per goods marker and 2 Lira per crystal. The higher total wins; further ties share victory.\nSetup:\nEach player starts with 1 crystal. The first player has 0 Lira, then each clockwise player has 1 more Lira. Reveal 6 mosques and shuffle the 33 Bazaar cards. With 2 players remove both rubies marked for 3 players: the mixed-goods track starts at one of each color plus 1 extra, and the Lira track at 12.\nTurn:\nTake mosque income, then roll 5 dice. Pay 1 crystal to reroll any number of dice, as often as you can pay. Keep the dice, then take 2 actions before passing the turn.\nGoods:\nMarkers substitute for dice of their color; brown markers substitute for any goods color, never Lira or Bazaar icons. Each die is usable only once per turn.\nActions:\n· Pay 2 goods of the same color to gain 1 marker of that color.\n· Pay 2 goods of different colors to gain 1 crystal.\n· Pay 3 goods of different colors to gain 1 wild marker.\n· Pay one good of each color to gain 2 non-brown markers of your choice.\n· Discard all remaining Lira dice to gain 2 Lira per die.\n· Discard any number of Bazaar dice, reveal that many cards, use one, then discard all the revealed cards. Reshuffle the Bazaar discard when the deck runs out.\nMosques:\nPay the depicted cost, take a displayed mosque and refill immediately. New abilities start next turn and may stack. On reaching exactly 5 mosques (4 with 4 players), receive one Mosque-area ruby immediately, once per game.\nRubies:\nPay the price of the next ruby on the chosen track, taking rubies in order from the cheapest end.\n· On a single-color track, prices are 4, 5, and 6 goods of that color with 2–3 players, or 4, 4, 5, and 6 goods with 4 players.\n· On the mixed-goods track, each ruby costs one good of every color plus 0 to 4 additional goods of any color, as shown by its position.\n· On the Lira track, prices are 10, 12, 14, 16, 18, and 20 Lira.\nBazaar cards:\nRed arrows require payment; white arrows require holding the resource without discarding it. Cards with an alternative may be declined for 1 Lira. Other players choose their own optional effects. Cards drawn as turn-start income cannot satisfy the two-Bazaar-dice condition. Card faces give each individual effect.\nLimited supply:\nIf goods, crystals or Lira are short, every holder returns 1 of that resource, repeatedly if needed, before the recipient takes the reward. Lira is managed by value with change.\nOptional promo:\nEach of the two shared tiles may be used only once in the entire game, costs an action, and does not count as a mosque.\n· Pay 2 wild markers to gain 6 Lira, 1 crystal and 1 Bazaar card.\n· Pay 4 crystals to take any ruby on the board."
		}
	}
};
//#endregion
export { Ue as default };
