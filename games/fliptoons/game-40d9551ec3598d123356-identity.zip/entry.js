import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { gameAssetUrl as a } from "@bgparty/sdk/assets";
import { useT as o } from "@bgparty/sdk/i18n";
import { BottomSheet as s } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as l } from "@bgparty/sdk/fx/delta-number";
import { IconClose as u, IconEye as d } from "@bgparty/sdk/icons";
import { AVATARS as ee } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { GameScreen as te } from "@bgparty/sdk/ui/game-screen";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { Floater as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as ne } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as re, OptionRadio as v, OptionSection as y } from "@bgparty/sdk/ui/game-options";
//#region src/games/fliptoons/meta.ts
var b = {
	id: "fliptoons",
	tier: "alpha",
	nameKey: "games.fliptoons.name",
	descKey: "games.fliptoons.desc",
	rulesKey: "games.fliptoons.rules",
	icon: "🎬",
	iconImg: "games/fliptoons.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/12445997011621711637/721DB29BBD346D9FEE96FD6AD8EF78D50E407E09/" },
	minPlayers: 1,
	maxPlayers: 8,
	bestPlayers: [
		2,
		3,
		4
	],
	accent: "#b7463f",
	releasedAt: "2026-11-07T15:15:00+08:00",
	search: {
		py: "fanzhuanxingtu",
		init: "fzxt"
	},
	hotseat: "cover",
	playerRange: (e) => ({
		min: 1,
		max: e?.season === "combined" ? 8 : 4
	}),
	mechanics: ["deck-bag-building", "set-collection"],
	interactionTags: []
}, x = {
	caterpillar: {
		rank: 0,
		fame: 0,
		count: 0,
		season: "base",
		name: "games.fliptoons.card.caterpillar.name",
		text: "games.fliptoons.card.caterpillar.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	skunk: {
		rank: 0,
		fame: 0,
		count: 0,
		season: "base",
		name: "games.fliptoons.card.skunk.name",
		text: "games.fliptoons.card.skunk.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	dragonfly: {
		rank: 0,
		fame: 0,
		count: 0,
		season: "base",
		name: "games.fliptoons.card.dragonfly.name",
		text: "games.fliptoons.card.dragonfly.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	bee: {
		rank: 0,
		fame: 1,
		count: 0,
		season: "base",
		name: "games.fliptoons.card.bee.name",
		text: "games.fliptoons.card.bee.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	snail: {
		rank: 0,
		fame: 2,
		count: 0,
		season: "base",
		name: "games.fliptoons.card.snail.name",
		text: "games.fliptoons.card.snail.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	mosquito: {
		rank: 0,
		fame: 0,
		count: 0,
		season: "season2",
		name: "games.fliptoons.card.mosquito.name",
		text: "games.fliptoons.card.mosquito.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	spider: {
		rank: 0,
		fame: 1,
		count: 0,
		season: "season2",
		name: "games.fliptoons.card.spider.name",
		text: "games.fliptoons.card.spider.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	grasshopper: {
		rank: 0,
		fame: 1,
		count: 0,
		season: "season2",
		name: "games.fliptoons.card.grasshopper.name",
		text: "games.fliptoons.card.grasshopper.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	ladybug: {
		rank: 0,
		fame: 1,
		count: 0,
		season: "season2",
		name: "games.fliptoons.card.ladybug.name",
		text: "games.fliptoons.card.ladybug.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	firefly: {
		rank: 0,
		fame: 1,
		count: 0,
		season: "season2",
		name: "games.fliptoons.card.firefly.name",
		text: "games.fliptoons.card.firefly.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	ostrich: {
		rank: 1,
		fame: 1,
		count: 3,
		season: "base",
		name: "games.fliptoons.card.ostrich.name",
		text: "games.fliptoons.card.ostrich.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	eagle: {
		rank: 2,
		fame: 4,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.eagle.name",
		text: "games.fliptoons.card.eagle.text",
		unflip: !0,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	donkey: {
		rank: 3,
		fame: 1,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.donkey.name",
		text: "games.fliptoons.card.donkey.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	butterfly: {
		rank: 4,
		fame: 2,
		count: 3,
		season: "base",
		name: "games.fliptoons.card.butterfly.name",
		text: "games.fliptoons.card.butterfly.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	dog: {
		rank: 5,
		fame: 0,
		count: 4,
		season: "base",
		name: "games.fliptoons.card.dog.name",
		text: "games.fliptoons.card.dog.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	goat: {
		rank: 6,
		fame: 1,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.goat.name",
		text: "games.fliptoons.card.goat.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	sheep: {
		rank: 7,
		fame: 1,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.sheep.name",
		text: "games.fliptoons.card.sheep.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	camel: {
		rank: 8,
		fame: 2,
		count: 5,
		season: "base",
		name: "games.fliptoons.card.camel.name",
		text: "games.fliptoons.card.camel.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	rabbit: {
		rank: 9,
		fame: 3,
		count: 4,
		season: "base",
		name: "games.fliptoons.card.rabbit.name",
		text: "games.fliptoons.card.rabbit.text",
		unflip: !0,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	horse: {
		rank: 10,
		fame: 4,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.horse.name",
		text: "games.fliptoons.card.horse.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	snake: {
		rank: 11,
		fame: 1,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.snake.name",
		text: "games.fliptoons.card.snake.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	elephant: {
		rank: 12,
		fame: 7,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.elephant.name",
		text: "games.fliptoons.card.elephant.text",
		unflip: !0,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	rooster: {
		rank: 13,
		fame: 0,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.rooster.name",
		text: "games.fliptoons.card.rooster.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	cat: {
		rank: 14,
		fame: 1,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.cat.name",
		text: "games.fliptoons.card.cat.text",
		unflip: !1,
		undismiss: !0,
		unreturn: !1,
		fish: !1
	},
	alligator: {
		rank: 15,
		fame: 6,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.alligator.name",
		text: "games.fliptoons.card.alligator.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	lion: {
		rank: 16,
		fame: 3,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.lion.name",
		text: "games.fliptoons.card.lion.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	monkey: {
		rank: 17,
		fame: 3,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.monkey.name",
		text: "games.fliptoons.card.monkey.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	pig: {
		rank: 18,
		fame: -1,
		count: 1,
		season: "base",
		name: "games.fliptoons.card.pig.name",
		text: "games.fliptoons.card.pig.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	peacock: {
		rank: 19,
		fame: 5,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.peacock.name",
		text: "games.fliptoons.card.peacock.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	turkey: {
		rank: 20,
		fame: 5,
		count: 2,
		season: "base",
		name: "games.fliptoons.card.turkey.name",
		text: "games.fliptoons.card.turkey.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	bull: {
		rank: 21,
		fame: 3,
		count: 1,
		season: "base",
		name: "games.fliptoons.card.bull.name",
		text: "games.fliptoons.card.bull.text",
		unflip: !0,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	tiger: {
		rank: 22,
		fame: 3,
		count: 1,
		season: "base",
		name: "games.fliptoons.card.tiger.name",
		text: "games.fliptoons.card.tiger.text",
		unflip: !1,
		undismiss: !0,
		unreturn: !1,
		fish: !1
	},
	deer: {
		rank: 23,
		fame: 3,
		count: 1,
		season: "base",
		name: "games.fliptoons.card.deer.name",
		text: "games.fliptoons.card.deer.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	bear: {
		rank: 24,
		fame: 1,
		count: 1,
		season: "base",
		name: "games.fliptoons.card.bear.name",
		text: "games.fliptoons.card.bear.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	cow: {
		rank: 25,
		fame: 0,
		count: 1,
		season: "base",
		name: "games.fliptoons.card.cow.name",
		text: "games.fliptoons.card.cow.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	salamander: {
		rank: 1,
		fame: 3,
		count: 3,
		season: "season2",
		name: "games.fliptoons.card.salamander.name",
		text: "games.fliptoons.card.salamander.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	groundhog: {
		rank: 2,
		fame: 3,
		count: 3,
		season: "season2",
		name: "games.fliptoons.card.groundhog.name",
		text: "games.fliptoons.card.groundhog.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	rat: {
		rank: 3,
		fame: 1,
		count: 4,
		season: "season2",
		name: "games.fliptoons.card.rat.name",
		text: "games.fliptoons.card.rat.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	goldfish: {
		rank: 4,
		fame: 1,
		count: 5,
		season: "season2",
		name: "games.fliptoons.card.goldfish.name",
		text: "games.fliptoons.card.goldfish.text",
		unflip: !0,
		undismiss: !1,
		unreturn: !1,
		fish: !0
	},
	mole: {
		rank: 5,
		fame: 3,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.mole.name",
		text: "games.fliptoons.card.mole.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	hen: {
		rank: 6,
		fame: 0,
		count: 3,
		season: "season2",
		name: "games.fliptoons.card.hen.name",
		text: "games.fliptoons.card.hen.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	starfish: {
		rank: 7,
		fame: 4,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.starfish.name",
		text: "games.fliptoons.card.starfish.text",
		unflip: !0,
		undismiss: !1,
		unreturn: !1,
		fish: !0
	},
	raccoon: {
		rank: 8,
		fame: 3,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.raccoon.name",
		text: "games.fliptoons.card.raccoon.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	panther: {
		rank: 9,
		fame: 2,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.panther.name",
		text: "games.fliptoons.card.panther.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	opossum: {
		rank: 10,
		fame: 2,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.opossum.name",
		text: "games.fliptoons.card.opossum.text",
		unflip: !1,
		undismiss: !0,
		unreturn: !1,
		fish: !1
	},
	mongoose: {
		rank: 11,
		fame: 2,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.mongoose.name",
		text: "games.fliptoons.card.mongoose.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	capybara: {
		rank: 12,
		fame: 2,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.capybara.name",
		text: "games.fliptoons.card.capybara.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	crow: {
		rank: 13,
		fame: 2,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.crow.name",
		text: "games.fliptoons.card.crow.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	coyote: {
		rank: 14,
		fame: 5,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.coyote.name",
		text: "games.fliptoons.card.coyote.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !0,
		fish: !1
	},
	clownfish: {
		rank: 15,
		fame: 3,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.clownfish.name",
		text: "games.fliptoons.card.clownfish.text",
		unflip: !0,
		undismiss: !1,
		unreturn: !1,
		fish: !0
	},
	fox: {
		rank: 16,
		fame: 3,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.fox.name",
		text: "games.fliptoons.card.fox.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	crab: {
		rank: 17,
		fame: 5,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.crab.name",
		text: "games.fliptoons.card.crab.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	swordfish: {
		rank: 18,
		fame: 8,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.swordfish.name",
		text: "games.fliptoons.card.swordfish.text",
		unflip: !0,
		undismiss: !1,
		unreturn: !1,
		fish: !0
	},
	gorilla: {
		rank: 19,
		fame: 5,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.gorilla.name",
		text: "games.fliptoons.card.gorilla.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	vulture: {
		rank: 20,
		fame: 6,
		count: 1,
		season: "season2",
		name: "games.fliptoons.card.vulture.name",
		text: "games.fliptoons.card.vulture.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	zebra: {
		rank: 21,
		fame: 5,
		count: 2,
		season: "season2",
		name: "games.fliptoons.card.zebra.name",
		text: "games.fliptoons.card.zebra.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !0,
		fish: !1
	},
	shark: {
		rank: 22,
		fame: 3,
		count: 1,
		season: "season2",
		name: "games.fliptoons.card.shark.name",
		text: "games.fliptoons.card.shark.text",
		unflip: !0,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	rhinoceros: {
		rank: 23,
		fame: 1,
		count: 1,
		season: "season2",
		name: "games.fliptoons.card.rhinoceros.name",
		text: "games.fliptoons.card.rhinoceros.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	hippopotamus: {
		rank: 24,
		fame: 0,
		count: 1,
		season: "season2",
		name: "games.fliptoons.card.hippopotamus.name",
		text: "games.fliptoons.card.hippopotamus.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	sloth: {
		rank: 25,
		fame: 3,
		count: 1,
		season: "season2",
		name: "games.fliptoons.card.sloth.name",
		text: "games.fliptoons.card.sloth.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	axolotl: {
		rank: 26,
		fame: 7,
		count: 2,
		season: "button",
		name: "games.fliptoons.card.axolotl.name",
		text: "games.fliptoons.card.axolotl.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	},
	platypus: {
		rank: 26,
		fame: 5,
		count: 2,
		season: "button2",
		name: "games.fliptoons.card.platypus.name",
		text: "games.fliptoons.card.platypus.text",
		unflip: !1,
		undismiss: !1,
		unreturn: !1,
		fish: !1
	}
}, ie = Object.keys(x);
function S(e) {
	return x[e];
}
var ae = (e) => e === "pig" ? "hiredDismissed" : e === "crow" ? "dismissed" : [
	"butterfly",
	"horse",
	"peacock",
	"raccoon",
	"panther",
	"axolotl",
	"platypus"
].includes(e) ? "hired" : null, C = t.object({
	season: t.enum([
		"base",
		"season2",
		"combined"
	]).default("base"),
	bigButton: t.boolean().default(!1),
	bigButton2: t.enum([
		"off",
		"grid",
		"market"
	]).default("off"),
	soloDifficulty: t.enum([
		"easy",
		"normal",
		"hard"
	]).default("normal"),
	soloStart: t.enum(["base", "season2"]).default("base")
}).default({
	season: "base",
	bigButton: !1,
	bigButton2: "off",
	soloDifficulty: "normal",
	soloStart: "base"
}), w = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("hire"),
		slot: t.int().min(0).max(6)
	}),
	t.object({
		type: t.literal("dismiss"),
		card: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("choose"),
		card: t.int().nonnegative().optional(),
		cards: t.array(t.int().nonnegative()).max(7).optional(),
		target: t.string().optional()
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("button"),
		use: t.boolean()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), T = t.object({
	id: t.int(),
	kind: t.string().nullable(),
	row: t.int(),
	col: t.int().min(0).max(2),
	face: t.boolean()
}), oe = t.object({
	config: C,
	phase: t.enum([
		"flip",
		"fame",
		"button",
		"market",
		"endTurn",
		"cleanup",
		"done"
	]),
	round: t.int().positive(),
	final: t.boolean(),
	first: t.string(),
	turn: t.string(),
	critic: t.string().nullable(),
	supplyCount: t.int().nonnegative(),
	market: t.array(t.object({
		id: t.int(),
		kind: t.string(),
		price: t.int()
	}).nullable()),
	discarded: t.array(t.object({
		id: t.int(),
		kind: t.string()
	})),
	players: t.array(t.object({
		rid: t.string(),
		grid: t.array(T),
		deckCount: t.int(),
		dismissed: t.array(t.object({
			id: t.int(),
			kind: t.string()
		})),
		fame: t.int(),
		generated: t.int(),
		actions: t.int(),
		button: t.boolean(),
		buttonDecided: t.boolean(),
		flipDone: t.boolean(),
		breakdown: t.array(t.object({
			id: t.int(),
			kind: t.string().nullable(),
			value: t.int()
		}))
	})),
	pending: t.object({
		rid: t.string(),
		kind: t.enum([
			"skunk",
			"butterfly",
			"horse",
			"pig",
			"raccoon",
			"panther",
			"crow",
			"alligator",
			"triggerOrder"
		]),
		source: t.int(),
		optional: t.boolean()
	}).nullable(),
	triggerSources: t.array(t.object({
		id: t.int(),
		kind: t.string()
	})),
	lastEvent: t.object({
		kind: t.enum([
			"reveal",
			"flip",
			"return",
			"stack",
			"dismiss",
			"hire",
			"score",
			"reset",
			"cleanup",
			"reorder"
		]),
		rid: t.string(),
		card: t.int().nullable(),
		serial: t.int()
	}).nullable(),
	soloWon: t.boolean().nullable(),
	ranking: t.array(t.string())
}), E = t.object({
	legalActions: t.array(w),
	deck: t.array(t.object({
		id: t.int(),
		kind: t.string()
	}))
}), D = {
	reveal: 440,
	effect: 520,
	score: 1e3,
	cleanup: 650
}, O = (e, t) => e.players.find((e) => e.rid === t), k = (e) => {
	let t = e.players.findIndex((t) => t.rid === e.first);
	return [...e.players.slice(t), ...e.players.slice(0, t)];
}, A = (e, t) => e.row === t.row && e.col === t.col, j = (e, t) => Math.abs(e.row - t.row) + Math.abs(e.col - t.col) === 1, M = (e) => e.grid.filter((e) => e.face), N = (e, t, n) => t.row - n.row || t.col - n.col || e.grid.indexOf(n) - e.grid.indexOf(t), P = (e, t, n, r) => A(n, r) ? t.grid.indexOf(r) - t.grid.indexOf(n) : e.config.season === "base" ? N(t, n, r) : t.history.indexOf(n.id) - t.history.indexOf(r.id), F = (e) => Array.from({ length: 6 }, (e, t) => ({
	row: Math.floor(t / 3),
	col: t % 3
})).find((t) => !e.grid.some((e) => A(e, t))), I = (e, t) => M(e).filter((e) => e.id !== t).sort((t, n) => S(t.kind).rank - S(n.kind).rank || t.row - n.row || t.col - n.col || e.grid.indexOf(n) - e.grid.indexOf(t))[0], se = (e) => e.config.bigButton || e.config.bigButton2 !== "off", ce = (e) => se(e) && e.config.bigButton2 !== "market", L = (e) => e.config.season === "combined" ? [
	3,
	3,
	4,
	7,
	10,
	15,
	15
] : [
	3,
	4,
	7,
	10,
	15
];
function R(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
}
function z(e, t, n, r, i, a, o = !0) {
	e.lastEvent = {
		kind: t,
		rid: n.rid,
		card: r,
		serial: ++e.serial
	}, e.fx.push({
		kind: t,
		rid: n.rid,
		...e.fx.length ? { with: !0 } : {},
		data: {
			card: r,
			toon: o && r !== null ? e.cards[r] : null,
			from: i ?? null,
			to: a ?? null,
			value: t === "score" ? n.generated : null
		}
	}), e.beatMs = Math.max(e.beatMs, t === "score" ? D.score : t === "cleanup" || t === "reset" ? D.cleanup : t === "reveal" ? D.reveal : D.effect);
}
function B(e, t) {
	let n = e.nextId++;
	return e.cards[n] = t, n;
}
function V(e, t, n) {
	let r = [...e.market], i = e.market.filter((e) => e !== null), a = t === void 0 ? L(e).length : i.length + t;
	for (; i.length < a && e.supply.length;) {
		let t = e.supply.shift();
		i.push(t), z(e, "reveal", O(e, e.turn), t, "supply", `market:${t}`);
	}
	i.sort((t, n) => S(e.cards[t]).rank - S(e.cards[n]).rank), e.market = n && i.length === a && e.supply.length ? L(e).map((e, t) => {
		let r = n.indexOf(t);
		return r < 0 ? null : i[r];
	}) : [...Array(L(e).length - i.length).fill(null), ...i], r.forEach((t, n) => {
		t !== null && e.market.indexOf(t) !== n && z(e, "reorder", O(e, e.turn), t, `marketSlot:${n}`, `market:${t}`);
	}), i.length || (e.ending = !0), e.players.length === 1 && i.length < a && (e.phase = "done", e.soloWon = !1, e.ranking = [e.players[0].rid]);
}
function H(e, t, n = !0) {
	e.phase = "flip", e.scored = !1, e.jobs = [], e.deferred = [], e.choices = [], e.pending = null;
	for (let r of e.players) r.flipDone = !t.includes(r.rid), r.buttonDecided = !1, !r.flipDone && (r.deck.push(...r.grid.map((e) => e.id)), r.grid = [], r.history = [], r.next = [], n && (r.bonus = 0, r.actions = 2, r.usedActions = 0), r.breakdown = [], R(e, r.deck), z(e, "reset", r, null, `grid:${r.rid}`, `deck:${r.rid}`));
	e.turn = k(e).find((e) => !e.flipDone)?.rid ?? e.first;
}
function le(t, n, r) {
	let i = C.parse(t), a = {
		config: i,
		seed: r,
		cursor: 0,
		cards: {},
		nextId: 1,
		players: [],
		supply: [],
		market: [],
		discarded: [],
		phase: "flip",
		round: 1,
		final: !1,
		ending: !1,
		first: n[0],
		turn: n[0],
		critic: null,
		active: [...n],
		eliminated: [],
		jobs: [],
		deferred: [],
		pending: null,
		choices: [],
		scored: !1,
		buttonUsers: [],
		ranking: [],
		soloWon: null,
		lastEvent: null,
		serial: 0,
		beatMs: D.reveal,
		fx: []
	};
	n.length > 4 && i.season !== "combined" && (a.config.season = "combined");
	for (let e of ie) {
		let t = S(e);
		if ((n.length !== 1 || e !== "pig") && (t.season === "button" ? i.bigButton : t.season === "button2" ? i.bigButton2 !== "off" : i.season === "combined" || i.season === t.season)) for (let n = 0; n < t.count; n++) a.supply.push(B(a, e));
	}
	R(a, a.supply);
	let o = i.season === "combined" ? [
		0,
		0,
		0,
		0,
		1,
		1,
		1,
		1
	] : Array(n.length).fill(+(i.season === "season2"));
	if (i.season === "combined" && R(a, o), n.forEach((e, t) => {
		let r = (n.length === 1 ? i.season === "combined" ? i.soloStart === "season2" : i.season === "season2" : o[t] === 1) ? [
			"mosquito",
			"mosquito",
			"spider",
			"grasshopper",
			"ladybug",
			n.length === 1 ? "mosquito" : "firefly"
		] : [
			"caterpillar",
			"caterpillar",
			"dragonfly",
			"bee",
			"snail",
			n.length === 1 ? "caterpillar" : "skunk"
		];
		a.players.push({
			rid: e,
			deck: r.map((e) => B(a, e)),
			grid: [],
			dismissed: [],
			fame: 0,
			generated: 0,
			bonus: 0,
			actions: 2,
			usedActions: 0,
			button: se(a),
			buttonDecided: !1,
			flipDone: !1,
			history: [],
			next: [],
			breakdown: []
		});
	}), V(a), n.length === 1) {
		let e = {
			easy: 17,
			normal: 20,
			hard: 23
		}[i.soloDifficulty] + (i.season === "combined" ? 50 : 0) + (i.bigButton ? 2 : 0) + (i.bigButton2 === "off" ? 0 : 2);
		a.discarded.push(...a.supply.splice(0, e));
	}
	return a.first = n[e(r, a.cursor++, n.length)], H(a, n), a.fx = [], {
		state: a,
		fx: []
	};
}
function U(e, t, n) {
	n && !S(n.kind).unflip && (n.face = !n.face, z(e, "flip", t, n.id, `card:${n.id}`, `card:${n.id}`, n.face));
}
function W(e, t, n) {
	return !S(n.kind).unreturn && (t.grid = t.grid.filter((e) => e.id !== n.id), t.deck.push(n.id), z(e, "return", t, n.id, `slot:${t.rid}:${n.row}:${n.col}`, `deck:${t.rid}`), !0);
}
function G(e, t, n) {
	if (S(e.cards[n]).undismiss || t.deck.length + t.grid.length < 4) return;
	let r = t.grid.find((e) => e.id === n), i = r ? `slot:${t.rid}:${r.row}:${r.col}` : `deck:${t.rid}`;
	t.grid = t.grid.filter((e) => e.id !== n), t.deck = t.deck.filter((e) => e !== n), t.dismissed.push(n), z(e, "dismiss", t, n, i, `dismissed:${t.rid}`), (e.cards[n] === "pig" || e.cards[n] === "crow") && de(e, t, n, "dismiss");
}
function K(e, t, n, r, i) {
	e.choices.push({
		rid: t.rid,
		kind: n,
		source: r,
		optional: i
	});
}
function ue(e, t, n, r) {
	let i = e.cards[n];
	if (i === "pig" && K(e, t, "pig", n, !1), r === "dismiss") {
		i === "crow" && K(e, t, "crow", n, !0);
		return;
	}
	if (i === "peacock" && (t.bonus += 2, t.fame += 2, t.actions++), i === "axolotl" && (t.button = !0), i === "platypus") for (let t of e.players) t.button = !0;
	(i === "horse" || i === "butterfly" || i === "raccoon") && K(e, t, i, n, !0), i === "panther" && K(e, t, i, n, !1);
}
function de(e, t, n, r) {
	let i = ae(e.cards[n]);
	(r === "hire" ? i !== "hired" && i !== "hiredDismissed" : i !== "dismissed" && i !== "hiredDismissed") || (e.phase === "flip" ? e.deferred.push({
		rid: t.rid,
		card: n,
		mode: r
	}) : ue(e, t, n, r));
}
function fe(e, t, n, r) {
	e.market = e.market.map((e) => e === n ? null : e);
	for (let t of e.players) t.dismissed = t.dismissed.filter((e) => e !== n);
	t.deck.unshift(n), z(e, "hire", t, n, r, `deck:${t.rid}`), de(e, t, n, "hire");
}
function q(e, t, n, r) {
	if (!r || A(n, r)) return;
	let i = `slot:${t.rid}:${n.row}:${n.col}`;
	n.row = r.row, n.col = r.col, z(e, "stack", t, n.id, i, `card:${n.id}`);
}
function pe(e, t, n) {
	let r = (n === void 0 ? void 0 : t.grid.find((e) => e.id === n)) ?? F(t), i = n === void 0 ? t.deck : e.supply;
	if (!r || !i.length) {
		n === void 0 && (t.flipDone = !0);
		return;
	}
	let a = i.shift(), o = e.cards[a], s = [...t.history].reverse().find((e) => t.grid.some((t) => t.id === e)) ?? null, c = {
		id: a,
		kind: o,
		row: r.row,
		col: r.col,
		face: !0
	};
	t.grid.push(c), t.history.push(a), z(e, "reveal", t, a, n === void 0 ? `deck:${t.rid}` : "supply", `card:${a}`);
	let l = n === void 0 ? t.next.splice(0).map((e) => t.grid.find((t) => t.id === e)).filter((e) => e !== void 0).sort((n, r) => P(e, t, n, r)).map((e) => ({
		type: "next",
		rid: t.rid,
		card: a,
		source: e.id
	})) : [];
	n !== void 0 && de(e, t, a, "hire"), e.jobs.unshift(...l, {
		type: "ability",
		rid: t.rid,
		card: a,
		previous: s,
		snake: n ?? null
	});
}
function me(e, t) {
	let n = O(e, t.rid), r = n.grid.find((e) => e.id === t.card && e.face), i = n.grid.find((e) => e.id === t.source && e.face);
	if (r && i) {
		if (i.kind === "ostrich" && q(e, n, r, i), i.kind === "gorilla") {
			let t = `slot:${n.rid}:${r.row}:${r.col}`;
			r.col = i.col, r.row = Math.min(0, ...n.grid.filter((e) => e.id !== r.id && e.col === i.col).map((e) => e.row)) - 1, z(e, "stack", n, r.id, t, `card:${r.id}`);
		}
		(i.kind === "eagle" || i.kind === "swordfish") && U(e, n, r), i.kind === "salamander" && S(r.kind).rank <= 1 && W(e, n, r);
	}
}
function he(e, t) {
	let n = O(e, t.rid), r = n.grid.find((e) => e.id === t.card && e.face);
	if (!r) return;
	let i = n.grid.find((e) => e.id === t.previous);
	switch (r.kind) {
		case "elephant":
		case "swordfish":
			U(e, n, i);
			break;
		case "starfish":
			U(e, n, i), q(e, n, r, i);
			break;
		case "rat":
		case "panther":
		case "sloth":
			q(e, n, r, i);
			break;
		case "turkey":
			q(e, n, r, t.snake === null ? i : n.grid.find((e) => e.id === t.snake));
			break;
		case "rabbit":
			t.snake || q(e, n, r, n.grid.find((e) => e.id !== r.id && (!e.face || e.kind === "rabbit")));
			break;
		case "mole":
			r.row === 1 && q(e, n, r, n.grid.find((e) => e.row === 0 && e.col === r.col));
			break;
		case "monkey":
			if (r.row === 0) {
				let t = `slot:${n.rid}:${r.row}:${r.col}`;
				r.row = Math.min(0, ...n.grid.filter((e) => e.id !== r.id && e.col === r.col).map((e) => e.row)) - 1, z(e, "stack", n, r.id, t, `card:${r.id}`);
			}
			break;
		case "coyote":
		case "zebra": {
			let t = r.kind === "coyote" ? i : I(n);
			t && t.id !== r.id && (q(e, n, r, t), W(e, n, t));
			break;
		}
		case "crab":
			r.col === 1 && (W(e, n, r), n.deck.every((t) => e.cards[t] === "crab") && (n.flipDone = !0));
			break;
		case "snake": {
			let t = n.deck[0];
			t !== void 0 && !S(e.cards[t]).undismiss && G(e, n, t), e.jobs.unshift({
				type: "gain",
				rid: n.rid,
				source: r.id
			}), t !== void 0 && S(e.cards[t]).undismiss && F(n) && pe(e, n);
			break;
		}
		case "mongoose": {
			let t = n.deck.at(-1);
			if (t !== void 0 && !S(e.cards[t]).undismiss && G(e, n, t), e.supply.length) {
				let t = e.supply.shift();
				n.deck.unshift(t), z(e, "hire", n, t, "supply", `deck:${n.rid}`, !1);
			}
			break;
		}
	}
	[
		"ostrich",
		"eagle",
		"salamander",
		"swordfish",
		"gorilla"
	].includes(r.kind) && F(n) && (r.kind !== "gorilla" || r.row === 0) && n.next.push(r.id);
}
function ge(e, t, n) {
	if (!n.face) return 0;
	let r = M(t), i = r.filter((e) => j(n, e)), a = n.kind, o = (e) => r.filter((t) => t.kind === e).length, s = (n) => e.market.some((t) => t !== null && n.includes(e.cards[t])) || e.players.some((e) => (e.rid !== t.rid || a === "fox") && M(e).some((e) => n.includes(e.kind))), c = S(a).fame;
	switch (a) {
		case "dragonfly":
			c += new Set(i.map((e) => e.kind)).size;
			break;
		case "spider":
			c += t.grid.filter((e) => e.col === n.col && e.row > n.row).length;
			break;
		case "grasshopper":
			c += t.grid.filter((e) => e.col === n.col && e.row < n.row).length;
			break;
		case "donkey":
			n.row === 1 && (c += 5);
			break;
		case "dog":
			s(["dog"]) && (c += 5);
			break;
		case "goat":
			n.row === 0 && (c += 3);
			break;
		case "sheep":
			n.col === 1 && (c += 4);
			break;
		case "camel":
			e.players.every((e) => M(e).filter((e) => e.kind === "camel").length <= o("camel")) && e.market.filter((t) => t !== null && e.cards[t] === "camel").length <= o("camel") && (c += 2);
			break;
		case "rooster":
			c += r.filter((e) => S(e.kind).rank <= 13).length;
			break;
		case "cat":
			c += t.dismissed.filter((t) => S(e.cards[t]).rank === 0).length;
			break;
		case "lion":
			i.every((e) => S(e.kind).rank <= 16) && (c += 4);
			break;
		case "bull":
			t.grid.some((e) => !e.face) && (c += 7);
			break;
		case "tiger":
			c += t.dismissed.length;
			break;
		case "deer":
			new Set(r.map((e) => e.kind)).size === r.length && (c += 5);
			break;
		case "bear":
			c += r.length;
			break;
		case "cow": {
			let n = i.filter((e) => e.kind !== "cow").map((n) => ge(e, t, n));
			c = n.length ? Math.max(...n) : 0;
			break;
		}
		case "goldfish":
		case "shark":
			c += r.filter((e) => S(e.kind).fish).length;
			break;
		case "hen":
			c += r.filter((e) => S(e.kind).rank >= 6).length;
			break;
		case "opossum": {
			let n = {};
			for (let r of t.dismissed) n[e.cards[r]] = (n[e.cards[r]] ?? 0) + 1;
			c += Object.values(n).reduce((e, t) => e + Math.floor(t / 2) * 2, 0);
			break;
		}
		case "capybara":
			t.deck.length >= 3 && (c += 4);
			break;
		case "clownfish":
			i.some((e) => S(e.kind).fish) && (c += 2);
			break;
		case "fox":
			s(["hen", "rooster"]) && (c += 3);
			break;
		case "rhinoceros":
			c += 3 * i.filter((e) => S(e.kind).rank % 2 == 1).length;
			break;
		case "hippopotamus":
			c += 2 * t.deck.length;
			break;
		case "sloth":
			t.grid.length >= 8 && (c += 5);
			break;
		case "platypus": t.button || (c += 3);
	}
	return c;
}
function _e(e, t) {
	let n = e.grid.find((e) => e.id === t), r = n.kind === "caterpillar" || e.grid.some((e) => e.face && e.kind === "ladybug" && j(n, e));
	return Math.max(0, (r ? 3 : 5) - e.grid.filter((e) => e.face && e.kind === "rat" && A(e, n)).length);
}
function ve(e) {
	for (let t of e.players) (!e.final || e.active.includes(t.rid)) && (t.breakdown = t.grid.map((n) => ({
		id: n.id,
		kind: n.face ? n.kind : null,
		value: ge(e, t, n)
	})), t.generated = t.breakdown.reduce((e, t) => e + t.value, 0) + t.bonus + (e.final && e.critic === t.rid ? 3 : 0), t.fame = t.generated);
	let t = e.players.filter((t) => !e.final || e.active.includes(t.rid)), n = Math.min(...t.map((e) => e.generated)), r = t.filter((e) => e.generated === n);
	if (e.players.length > 1 && r.length === 1) {
		let t = r[0], n = M(t).filter((e) => e.kind === "firefly").length;
		t.generated += n * 2, t.fame += n * 2;
		for (let n of M(t).filter((e) => e.kind === "skunk")) K(e, t, "skunk", n.id, !1);
	}
	for (let n of t) z(e, "score", n, null, void 0, `score:${n.rid}`);
	if (e.scored = !0, e.phase = "fame", e.players.length === 1 && e.players[0].generated >= 30 && (e.soloWon = !0, e.phase = "done", e.ranking = [e.first]), !e.final && e.players.length > 1 && e.players.some((e) => e.generated >= 30)) {
		e.ending = !0;
		let t = Math.max(...e.players.map((e) => e.generated)), n = e.players.filter((e) => e.generated === t);
		e.critic = n.length === 1 ? n[0].rid : null;
	}
}
function ye(e) {
	if (ce(e) && k(e).some((t) => (!e.final || e.active.includes(t.rid)) && t.button && !t.buttonDecided)) {
		e.phase = "button", e.turn = k(e).find((t) => (!e.final || e.active.includes(t.rid)) && t.button && !t.buttonDecided).rid;
		return;
	}
	if (e.players.length === 1 && e.players[0].generated >= 30) {
		e.soloWon = !0, e.phase = "done", e.ranking = [e.first];
		return;
	}
	if (e.final) {
		let t = e.players.filter((t) => e.active.includes(t.rid)), n = Math.max(...t.map((e) => e.generated)), r = t.filter((e) => e.generated === n).map((e) => e.rid), i = t.filter((e) => e.generated !== n).sort((e, t) => t.generated - e.generated).map((e) => e.rid);
		r.length > 1 ? (e.eliminated.unshift(i), e.active = r, e.round++, H(e, r)) : (e.phase = "done", e.ranking = [
			...r,
			...i,
			...e.eliminated.flat()
		]);
		return;
	}
	e.phase = "market", e.turn = e.first;
}
function be(e, t) {
	let n = O(e, t.rid), r = n.deck.length + n.grid.length < 4 ? [] : M(n).filter((e) => !S(e.kind).undismiss), i = [];
	if (t.kind === "triggerOrder" && (i = e.deferred.filter((e) => e.rid === t.rid).map((e) => ({
		type: "choose",
		card: e.card
	}))), t.kind === "pig" && (i = [...e.players.map((e) => ({
		type: "choose",
		target: e.rid
	})), {
		type: "choose",
		target: "$supply"
	}]), t.kind === "horse") {
		let t = e.market.filter((e) => e !== null);
		i = Array.from({ length: 2 ** t.length }, (e, n) => ({
			type: "choose",
			cards: t.filter((e, t) => n & 1 << t)
		}));
	}
	if ((t.kind === "skunk" || t.kind === "panther") && (i = r.map((e) => ({
		type: "choose",
		card: e.id
	}))), t.kind === "butterfly" && (i = r.filter((e) => e.kind === "caterpillar").map((e) => ({
		type: "choose",
		card: e.id
	}))), t.kind === "alligator") {
		let e = n.grid.find((e) => e.id === t.source && e.face);
		i = e ? r.filter((t) => t.row === e.row && t.col === e.col + 1).map((e) => ({
			type: "choose",
			card: e.id
		})) : [];
	}
	return t.kind === "raccoon" && (i = e.players.flatMap((e) => e.dismissed.map((e) => ({
		type: "choose",
		card: e
	})))), t.kind === "crow" && (i = e.market.flatMap((e) => e === null ? [] : [{
		type: "choose",
		card: e
	}])), t.optional && i.push({ type: "pass" }), i;
}
function J(e) {
	for (; !e.pending && e.choices.length;) {
		let t = e.choices.shift();
		be(e, t).some((e) => e.type !== "pass") && (e.pending = t, e.turn = t.rid);
	}
}
function xe(e, t) {
	if (e.phase === "done") return [];
	if (e.pending) return e.pending.rid === t ? be(e, e.pending) : [];
	if (e.turn !== t) return [];
	let n = O(e, t);
	if (e.phase === "button") return [{
		type: "button",
		use: !1
	}, {
		type: "button",
		use: !0
	}];
	if (e.phase !== "market") return [];
	let r = [{ type: "pass" }];
	if (n.actions > 0 && (e.market.forEach((t, i) => {
		t !== null && n.fame >= L(e)[i] && r.push({
			type: "hire",
			slot: i
		});
	}), n.deck.length + n.grid.length >= 4)) for (let e of M(n)) !S(e.kind).undismiss && n.fame >= _e(n, e.id) && r.push({
		type: "dismiss",
		card: e.id
	});
	return e.config.bigButton2 === "market" && n.button && n.usedActions === 0 && r.push({
		type: "button",
		use: !0
	}), r;
}
function Se(e, t) {
	let n = e.pending, r = O(e, n.rid);
	if (e.pending = null, t.type !== "pass" && t.type === "choose") {
		if (n.kind === "triggerOrder") {
			let i = e.deferred.findIndex((e) => e.rid === n.rid && e.card === t.card), a = e.deferred.splice(i, 1)[0];
			ue(e, r, a.card, a.mode);
		} else if (n.kind === "horse") {
			let n = t.cards, i = e.market.flatMap((e, t) => e === null ? [] : [t]);
			e.market = e.market.map((e) => e !== null && n.includes(e) ? null : e), e.discarded.push(...n), n.forEach((t) => z(e, "dismiss", r, t, `market:${t}`, "discard")), V(e, n.length, i);
		} else if (n.kind === "pig") {
			for (let t of e.players) t.deck = t.deck.filter((e) => e !== n.source), t.dismissed = t.dismissed.filter((e) => e !== n.source), t.grid = t.grid.filter((e) => e.id !== n.source);
			t.target === "$supply" ? (e.supply.push(n.source), R(e, e.supply)) : O(e, t.target).deck.unshift(n.source), z(e, "hire", r, n.source, `card:${n.source}`, t.target === "$supply" ? "supply" : `deck:${t.target}`);
		} else if (n.kind === "crow" || n.kind === "raccoon") {
			let i = n.kind === "crow" ? `market:${t.card}` : `dismissed:${e.players.find((e) => e.dismissed.includes(t.card)).rid}`;
			fe(e, r, t.card, i), n.kind === "crow" && V(e);
		} else G(e, r, t.card);
	}
}
function Ce(e, t) {
	e.phase = "endTurn", e.jobs.push(...M(t).sort((e, n) => N(t, e, n)).filter((e) => [
		"donkey",
		"groundhog",
		"alligator",
		"vulture"
	].includes(e.kind)).map((e) => ({
		type: "end",
		rid: t.rid,
		card: e.id
	})));
}
function we(e, t) {
	if (t.type !== "end") return;
	let n = O(e, t.rid), r = n.grid.find((e) => e.id === t.card && e.face);
	if (r) {
		if ((r.kind === "donkey" && r.row === 1 || r.kind === "groundhog" && (r.row === 0 && r.col === 0 || r.row === 1 && r.col === 2)) && G(e, n, r.id), r.kind === "vulture") {
			let t = I(n);
			t && G(e, n, t.id);
		}
		r.kind === "alligator" && K(e, n, "alligator", r.id, !1);
	}
}
function Te(e) {
	if (!(e.pending || e.phase === "market" || e.phase === "button" || e.phase === "done")) {
		if (e.jobs.length) {
			let t = e.jobs.shift();
			t.type === "ability" ? he(e, t) : t.type === "next" ? me(e, t) : t.type === "gain" ? pe(e, O(e, t.rid), t.source) : we(e, t), J(e);
			return;
		}
		if (e.phase === "flip") {
			let t = k(e), n = Math.max(0, t.findIndex((t) => t.rid === e.turn)), r = [...t.slice(n), ...t.slice(0, n)].find((e) => !e.flipDone);
			if (r) {
				!F(r) || !r.deck.length ? r.flipDone = !0 : pe(e, r), e.turn = t[(t.indexOf(r) + 1) % t.length].rid;
				return;
			}
			let i = t.find((t) => e.deferred.some((e) => e.rid === t.rid));
			if (i) {
				let t = e.deferred.filter((e) => e.rid === i.rid);
				if (t.length > 1) K(e, i, "triggerOrder", t[0].card, !1);
				else {
					let n = e.deferred.splice(e.deferred.indexOf(t[0]), 1)[0];
					ue(e, i, n.card, n.mode);
				}
				J(e);
				return;
			}
			e.phase = "fame", J(e);
			return;
		}
		if (e.phase === "fame") {
			e.scored ? ye(e) : (ve(e), J(e));
			return;
		}
		if (e.phase === "endTurn") {
			let t = O(e, e.turn);
			if (V(e), e.soloWon === !1) return;
			let n = k(e), r = n.indexOf(t);
			r === n.length - 1 ? e.phase = "cleanup" : (e.phase = "market", e.turn = n[r + 1].rid);
			return;
		}
		if (e.phase === "cleanup") {
			if (e.players.length <= (e.config.season === "combined" ? 4 : 2)) {
				let t = e.market.filter((e) => e !== null), n = [...new Set([t[0], t.at(-1)].filter((e) => e !== void 0))];
				if (e.discarded.push(...n), e.market = e.market.map((e) => e !== null && n.includes(e) ? null : e), V(e), e.soloWon === !1) return;
			}
			e.ending ? e.final = !0 : e.first = e.players[(e.players.findIndex((t) => t.rid === e.first) + 1) % e.players.length].rid, e.round++, H(e, e.players.map((e) => e.rid));
		}
	}
}
function Ee(e, t, n) {
	if (t.type !== "tick" && !xe(e, n.by).some((e) => JSON.stringify(e) === JSON.stringify(t))) return { code: "games.fliptoons.invalid" };
	if (t.type === "tick" && De(e) === null) return {
		state: e,
		fx: []
	};
	let r = structuredClone(e);
	if (r.fx = [], r.beatMs = 70, t.type === "tick") Te(r);
	else if (r.pending) Se(r, t), J(r);
	else {
		let e = O(r, n.by);
		if (t.type === "button") {
			if (r.phase === "market") e.button = !1, r.supply.push(...r.market.filter((e) => e !== null)), r.market = L(r).map(() => null), R(r, r.supply), V(r), z(r, "reset", e, null, "market", "supply");
			else {
				e.buttonDecided = !0, t.use && r.buttonUsers.push(e.rid);
				let n = k(r).find((e) => (!r.final || r.active.includes(e.rid)) && e.button && !e.buttonDecided);
				if (n) r.turn = n.rid;
				else if (r.buttonUsers.length) {
					let e = r.buttonUsers.splice(0);
					e.forEach((e) => {
						O(r, e).button = !1;
					}), H(r, e, !1);
				} else r.phase = "fame", r.turn = r.first;
			}
		} else if (t.type === "pass") Ce(r, e);
		else if (t.type === "hire") {
			let n = r.market[t.slot];
			e.fame -= L(r)[t.slot], e.actions--, e.usedActions++, fe(r, e, n, `market:${n}`), J(r);
		} else t.type === "dismiss" && (e.fame -= _e(e, t.card), e.actions--, e.usedActions++, G(r, e, t.card), J(r));
	}
	r.phase === "market" && !r.pending && !r.choices.length && O(r, r.turn).actions <= 0 && Ce(r, O(r, r.turn));
	let i = r.fx;
	return r.fx = [], {
		state: r,
		fx: i
	};
}
function De(e) {
	return e.pending || [
		"market",
		"button",
		"done"
	].includes(e.phase) ? null : e.beatMs;
}
function Oe(e, t) {
	let n = (t) => ({
		id: t,
		kind: e.cards[t]
	});
	return {
		public: {
			config: e.config,
			phase: e.phase,
			round: e.round,
			final: e.final,
			first: e.first,
			turn: e.turn,
			critic: e.critic,
			supplyCount: e.supply.length,
			market: e.market.map((t, r) => t === null ? null : {
				...n(t),
				price: L(e)[r]
			}),
			discarded: e.discarded.map(n),
			players: e.players.map((e) => ({
				rid: e.rid,
				grid: e.grid.map((e) => ({
					...e,
					kind: e.face ? e.kind : null
				})),
				deckCount: e.deck.length,
				dismissed: e.dismissed.map(n),
				fame: e.fame,
				generated: e.generated,
				actions: e.actions,
				button: e.button,
				buttonDecided: e.buttonDecided,
				flipDone: e.flipDone,
				breakdown: e.breakdown
			})),
			pending: e.pending,
			triggerSources: e.pending?.kind === "triggerOrder" ? e.deferred.filter((t) => t.rid === e.pending.rid).map((e) => n(e.card)) : [],
			lastEvent: e.lastEvent,
			soloWon: e.soloWon,
			ranking: e.ranking
		},
		private: {
			legalActions: xe(e, t),
			deck: ["market", "endTurn"].includes(e.phase) ? (e.players.find((e) => e.rid === t)?.deck ?? []).map(n) : []
		}
	};
}
function ke(e) {
	return e.phase === "done" ? {
		phase: "done",
		winner: e.soloWon === !1 ? [] : e.ranking.slice(0, 1),
		ranking: e.ranking,
		scores: Object.fromEntries(e.players.map((e) => [e.rid, e.generated]))
	} : { phase: e.phase };
}
var Ae = {
	meta: b,
	saveCompatibility: { version: "1" },
	schemas: {
		config: C,
		action: w,
		publicView: oe,
		privateView: E
	},
	setup: le,
	reduce: Ee,
	viewFor: Oe,
	status: ke,
	nextTickIn: De
};
//#endregion
//#region src/games/fliptoons/icons.tsx
function Y({ value: e, label: t }) {
	return /* @__PURE__ */ h("span", {
		className: "ft-fame",
		"aria-label": t,
		children: [/* @__PURE__ */ h("svg", {
			viewBox: "0 0 44 44",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ m("circle", {
				cx: "22",
				cy: "22",
				r: "20",
				fill: "#d4bd73",
				stroke: "#302b2d",
				strokeWidth: "3"
			}), /* @__PURE__ */ m("circle", {
				cx: "22",
				cy: "22",
				r: "15.5",
				fill: "none",
				stroke: "#302b2d",
				strokeWidth: "1.5"
			})]
		}), e !== void 0 && /* @__PURE__ */ m("b", { children: e })]
	});
}
function X({ kind: e }) {
	let t;
	return t = e === "hired" || e === "dismissed" || e === "hiredDismissed" ? /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("rect", {
			x: "8",
			y: "3",
			width: "24",
			height: "28",
			rx: "3",
			fill: "#f0e4c8",
			stroke: "#302b2d",
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "20",
			cy: "12",
			r: "5.5",
			fill: "#302b2d"
		}),
		e !== "dismissed" && /* @__PURE__ */ m("path", {
			d: e === "hiredDismissed" ? "M8 21H16V29H21L12 38 3 29H8Z" : "M16 21H24V29H29L20 38 11 29H16Z",
			fill: "#302b2d",
			stroke: "#f0e4c8",
			strokeWidth: "1.4"
		}),
		e !== "hired" && /* @__PURE__ */ m("path", {
			d: e === "hiredDismissed" ? "m29 22 2 5 5-3-2 5 5 2-6 2 2 5-5-3-3 4-1-6-6 1 4-4-4-3 6 1Z" : "m20 21 3 5 6-3-2 6 7 2-7 2 2 6-6-3-3 4-2-6-7 1 4-5-5-3 7 1Z",
			fill: "#302b2d",
			stroke: "#f0e4c8",
			strokeWidth: "1.2"
		})
	] }) : e === "fish" ? /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("circle", {
			cx: "20",
			cy: "20",
			r: "18",
			fill: "#55566f",
			stroke: "#f0e4c8",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ m("path", {
			d: "M7 20Q10 10 20 10Q26 10 28 16L35 10V30L28 24Q24 31 15 28L13 34 11 27Q8 25 7 20Z",
			fill: "#f0e4c8"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "13",
			cy: "17",
			r: "1.7",
			fill: "#55566f"
		})
	] }) : /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("circle", {
			cx: "20",
			cy: "20",
			r: "18",
			fill: "#ede2c9",
			stroke: "#302b2d",
			strokeWidth: "2.5"
		}),
		e === "unflip" ? /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M12 30Q4 17 17 9",
				fill: "none",
				stroke: "#302b2d",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ m("path", {
				d: "m10 24 6 6-9 1M28 10Q36 23 23 31",
				fill: "none",
				stroke: "#302b2d",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ m("path", {
				d: "m25 8 7 2-4 7",
				fill: "#302b2d"
			})
		] }) : e === "undismiss" ? /* @__PURE__ */ m("path", {
			d: "m20 6 3 8 7-6-2 10 8 2-9 4 4 9-9-5-4 8-2-10-9 3 6-8-8-5 10 1Z",
			fill: "#302b2d"
		}) : /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "m8 12 17-5 4 11-17 5Z",
				fill: "#302b2d"
			}),
			/* @__PURE__ */ m("path", {
				d: "m10 12 14-4M11 15 25 11M12 18 26 14",
				stroke: "#ede2c9",
				strokeWidth: ".9"
			}),
			/* @__PURE__ */ m("path", {
				d: "M31 19Q34 31 20 31",
				fill: "none",
				stroke: "#302b2d",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ m("path", {
				d: "m23 25-9 5 8 6Z",
				fill: "#302b2d"
			})
		] }),
		/* @__PURE__ */ m("path", {
			d: "M7 33 33 7",
			stroke: "#ede2c9",
			strokeWidth: "6"
		}),
		/* @__PURE__ */ m("path", {
			d: "M7 33 33 7",
			stroke: "#302b2d",
			strokeWidth: "2.8"
		})
	] }), /* @__PURE__ */ m("svg", {
		className: "ft-rule-icon",
		viewBox: "0 0 40 40",
		"aria-hidden": !0,
		children: t
	});
}
//#endregion
//#region src/games/fliptoons/card.tsx
var je = [
	"#766278",
	"#827b55",
	"#60817c",
	"#b36a4e",
	"#6b7198",
	"#a47055",
	"#77836b"
];
function Z({ id: e, kind: t, anchor: n, target: r = !1, selected: i = !1, value: s, onClick: l, compact: u = !1 }) {
	let d = o(), { ref: ee } = c(n ?? `card:${e}`), f = t === null ? null : S(t), te = t === null ? null : ae(t);
	return /* @__PURE__ */ h("button", {
		ref: ee,
		type: "button",
		className: `ft-card${u ? " ft-card-compact" : ""}${f ? "" : " ft-card-back"}${r ? " is-target" : ""}${i ? " is-selected" : ""}`,
		onClick: l,
		"aria-label": f ? `${d(f.name)} · ${d("games.fliptoons.rank", { n: f.rank })} · ${d("games.fliptoons.cardFame", { n: s ?? f.fame })}` : d("games.fliptoons.faceDown"),
		"aria-pressed": i,
		style: { "--ft-card-color": je[(f?.rank ?? 0) % je.length] },
		children: [f && t ? /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("span", {
				className: "ft-card-art",
				children: /* @__PURE__ */ m("img", {
					src: a(`games/fliptoons/live/${t}.webp`),
					alt: "",
					draggable: !1
				})
			}),
			/* @__PURE__ */ m("span", {
				className: "ft-card-rank",
				title: d("games.fliptoons.rank", { n: f.rank }),
				children: f.rank
			}),
			/* @__PURE__ */ m("strong", {
				className: "ft-card-name",
				children: d(f.name)
			}),
			/* @__PURE__ */ h("span", {
				className: "ft-card-foot",
				children: [
					/* @__PURE__ */ m(Y, { value: s ?? f.fame }),
					/* @__PURE__ */ h("span", {
						className: "ft-card-icons",
						children: [
							te && /* @__PURE__ */ m(X, { kind: te }),
							" ",
							f.unflip && /* @__PURE__ */ m(X, { kind: "unflip" }),
							f.undismiss && /* @__PURE__ */ m(X, { kind: "undismiss" }),
							f.unreturn && /* @__PURE__ */ m(X, { kind: "unreturn" }),
							f.fish && /* @__PURE__ */ m(X, { kind: "fish" })
						]
					}),
					/* @__PURE__ */ h("span", {
						className: "ft-card-count",
						"aria-hidden": !0,
						children: ["×", f.count || (t === "caterpillar" || t === "mosquito" ? 2 : 1)]
					})
				]
			})
		] }) : /* @__PURE__ */ h("span", {
			className: "ft-back-mark",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ m("i", {}),
				/* @__PURE__ */ h("strong", { children: [
					"FLIP",
					/* @__PURE__ */ m("br", {}),
					"TOONS"
				] }),
				/* @__PURE__ */ m("i", {})
			]
		}), r && /* @__PURE__ */ m("svg", {
			className: "ft-target",
			viewBox: "0 0 100 135",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: /* @__PURE__ */ m("rect", {
				x: "2",
				y: "2",
				width: "96",
				height: "131",
				rx: "5"
			})
		})]
	});
}
//#endregion
//#region src/games/fliptoons/view-player.tsx
var Me = {
	skunk: "games.fliptoons.choice.skunk",
	butterfly: "games.fliptoons.choice.butterfly",
	horse: "games.fliptoons.choice.horse",
	pig: "games.fliptoons.choice.pig",
	raccoon: "games.fliptoons.choice.raccoon",
	panther: "games.fliptoons.choice.panther",
	crow: "games.fliptoons.choice.crow",
	alligator: "games.fliptoons.choice.alligator",
	triggerOrder: "games.fliptoons.choice.triggerOrder"
};
function Q({ name: e, className: t, children: n }) {
	let { ref: r } = c(e);
	return /* @__PURE__ */ m("div", {
		ref: r,
		className: t,
		children: n
	});
}
function Ne(e) {
	return /* @__PURE__ */ m(Pe, {
		...e,
		pub: e.public,
		priv: e.private
	}, e.myRid);
}
function Pe({ pub: e, priv: t, members: n, myRid: r, send: c, readOnly: g = !1 }) {
	let _ = o(), [ne, re] = i(r), [v, y] = i(null), [b, x] = i(null), [ie, C] = i({
		source: -1,
		ids: []
	}), w = !g && e.pending?.rid === r ? e.pending : null, T = g ? [] : t?.legalActions ?? [], oe = w && [
		"skunk",
		"butterfly",
		"panther",
		"alligator",
		"triggerOrder"
	].includes(w.kind), E = e.players.find((e) => e.rid === (oe ? r : ne)) ?? e.players[0], D = (t) => n.find((e) => e.rid === t)?.name || _(f[e.players.findIndex((e) => e.rid === t) % f.length].nameKey), O = (t) => f[(n.find((e) => e.rid === t)?.colorIndex ?? e.players.findIndex((e) => e.rid === t)) % f.length].hex, k = (e) => {
		c(e), y(null);
	}, A = ie.source === w?.source ? ie.ids.filter((t) => e.market.some((e) => e?.id === t)) : [], j = new Set(T.flatMap((t) => t.type === "choose" && t.card !== void 0 || t.type === "dismiss" ? [t.card] : t.type === "hire" && e.market[t.slot] ? [e.market[t.slot].id] : [])), M = [
		...e.triggerSources,
		...e.market.flatMap((e) => e ? [e] : []),
		...e.players.flatMap((e) => [...e.grid, ...e.dismissed]),
		...e.discarded,
		...t?.deck ?? []
	], N = v === null ? void 0 : M.find((e) => e.id === v), P = N?.kind ? S(N.kind) : null, F = N?.kind ? ae(N.kind) : null, I = N ? T.find((t) => t.type === "choose" && t.card === N.id || t.type === "dismiss" && t.card === N.id || t.type === "hire" && e.market[t.slot]?.id === N.id) : void 0, se = I?.type === "hire" ? e.market[I.slot].price : I?.type === "dismiss" ? Fe(e.players.find((e) => e.grid.some((e) => e.id === N.id)).grid, N.id) : null, ce = I?.type === "hire" ? _("games.fliptoons.hire", { n: se }) : I?.type === "dismiss" ? _("games.fliptoons.dismiss", { n: se }) : _("games.fliptoons.choose"), L = !g && e.phase === "market" && e.turn === r && !e.pending, R = g ? _("games.fliptoons.result") : w ? _(Me[w.kind]) : e.pending ? _("games.fliptoons.waiting", { name: D(e.pending.rid) }) : e.phase === "market" ? L ? _("games.fliptoons.yourTurn") : _("games.fliptoons.waiting", { name: D(e.turn) }) : e.phase === "button" ? e.turn === r ? _("games.fliptoons.buttonPrompt") : _("games.fliptoons.waiting", { name: D(e.turn) }) : e.phase === "flip" ? _("games.fliptoons.flip") : e.phase === "fame" ? _("games.fliptoons.famePhase") : _("games.fliptoons.cleanup"), z = (e) => {
		w?.kind === "horse" ? C({
			source: w.source,
			ids: A.includes(e) ? A.filter((t) => t !== e) : [...A, e]
		}) : y(e);
	}, B = w?.kind === "triggerOrder", V = B ? e.triggerSources : w?.kind === "raccoon" ? e.players.flatMap((e) => e.dismissed) : b === "deck" ? t?.deck ?? [] : b === "discarded" ? e.discarded : E.dismissed, H = (B || w?.kind === "raccoon" || b !== null) && v === null, le = /* @__PURE__ */ m(p, { children: P && N?.kind ? /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("div", {
			className: "ft-detail-art",
			children: /* @__PURE__ */ m("img", {
				src: a(`games/fliptoons/live/${N.kind}.webp`),
				alt: ""
			})
		}),
		/* @__PURE__ */ h("div", {
			className: "ft-detail-heading",
			children: [/* @__PURE__ */ m("h2", { children: _(P.name) }), /* @__PURE__ */ m(Y, {
				value: P.fame,
				label: _("games.fliptoons.fame")
			})]
		}),
		/* @__PURE__ */ m("p", {
			className: "ft-detail-rank",
			children: _("games.fliptoons.rank", { n: P.rank })
		}),
		/* @__PURE__ */ m("p", {
			className: "ft-detail-rule",
			children: _(P.text)
		}),
		/* @__PURE__ */ h("div", {
			className: "ft-protections",
			children: [
				F && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: F }), _(F === "hired" ? "games.fliptoons.whenHired" : F === "dismissed" ? "games.fliptoons.whenDismissed" : "games.fliptoons.whenHiredDismissed")] }),
				P.unflip && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "unflip" }), _("games.fliptoons.protectedFlip")] }),
				P.undismiss && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "undismiss" }), _("games.fliptoons.protectedDismiss")] }),
				P.unreturn && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "unreturn" }), _("games.fliptoons.protectedReturn")] }),
				P.fish && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "fish" }), _("games.fliptoons.fish")] })
			]
		})
	] }) : /* @__PURE__ */ h("div", {
		className: "ft-detail-empty",
		children: [/* @__PURE__ */ m(d, { size: 28 }), /* @__PURE__ */ m("p", { children: _(N ? "games.fliptoons.faceDown" : "games.fliptoons.selectPrompt") })]
	}) }), U = I && /* @__PURE__ */ m("button", {
		className: "ft-button ft-primary",
		onClick: () => k(I),
		children: ce
	}), W = Array.from({ length: 2 - Math.min(0, ...E.grid.map((e) => e.row)) }, (e, t) => Math.min(0, ...E.grid.map((e) => e.row)) + t);
	return /* @__PURE__ */ h("div", {
		className: "ft-screen",
		children: [
			/* @__PURE__ */ m(te, {
				adaptive: !0,
				className: "ft-game-screen",
				banner: /* @__PURE__ */ h("div", {
					className: "ft-banner",
					children: [/* @__PURE__ */ h("div", {
						className: "ft-title-row",
						children: [
							/* @__PURE__ */ m("h1", { children: _("games.fliptoons.name") }),
							/* @__PURE__ */ m("b", {
								className: "ft-round",
								children: e.final ? _("games.fliptoons.final") : _("games.fliptoons.round", { n: e.round })
							}),
							/* @__PURE__ */ m("span", {
								className: "ft-status",
								"aria-live": "polite",
								children: R
							})
						]
					}), /* @__PURE__ */ m("div", {
						className: "ft-players",
						"aria-label": _("games.fliptoons.grid"),
						children: e.players.map((t) => {
							let r = n.find((e) => e.rid === t.rid);
							return /* @__PURE__ */ h("button", {
								className: `ft-player${t.rid === E.rid ? " is-selected" : ""}${t.rid === e.turn && !g ? " is-turn" : ""}`,
								style: { "--ft-player-color": O(t.rid) },
								onClick: () => re(t.rid),
								"aria-pressed": t.rid === E.rid,
								children: [
									/* @__PURE__ */ m("span", {
										className: "ft-avatar",
										"aria-hidden": !0,
										children: /* @__PURE__ */ m("img", {
											src: a(ee[r?.avatar ?? 0]),
											alt: ""
										})
									}),
									/* @__PURE__ */ m("span", {
										className: "ft-player-name",
										children: D(t.rid)
									}),
									/* @__PURE__ */ h(Q, {
										name: `score:${t.rid}`,
										className: "ft-score",
										children: [/* @__PURE__ */ m(Y, {}), /* @__PURE__ */ m(l, { value: e.phase === "market" || e.phase === "endTurn" ? t.fame : t.generated })]
									}),
									e.critic === t.rid && /* @__PURE__ */ m("span", {
										className: "ft-critic-dot",
										title: _("games.fliptoons.critic"),
										children: "+3"
									})
								]
							}, t.rid);
						})
					})]
				}),
				actionsHeight: "ft-action-height",
				actions: /* @__PURE__ */ h("div", {
					className: "ft-actions",
					children: [
						/* @__PURE__ */ m("span", { children: L ? _("games.fliptoons.actions", { n: e.players.find((e) => e.rid === r).actions }) : w ? _(Me[w.kind]) : "" }),
						L && /* @__PURE__ */ h(p, { children: [T.some((e) => e.type === "button") && /* @__PURE__ */ m("button", {
							className: "ft-button ft-reset",
							onClick: () => k({
								type: "button",
								use: !0
							}),
							children: _("games.fliptoons.resetMarket")
						}), /* @__PURE__ */ m("button", {
							className: "ft-button ft-primary",
							onClick: () => k({ type: "pass" }),
							children: _("games.fliptoons.pass")
						})] }),
						!g && e.phase === "button" && e.turn === r && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("button", {
							className: "ft-button",
							onClick: () => k({
								type: "button",
								use: !1
							}),
							children: _("games.fliptoons.keepGrid")
						}), /* @__PURE__ */ m("button", {
							className: "ft-button ft-primary",
							onClick: () => k({
								type: "button",
								use: !0
							}),
							children: _("games.fliptoons.resetGrid")
						})] }),
						w?.kind === "horse" && /* @__PURE__ */ m("button", {
							className: "ft-button ft-primary",
							onClick: () => {
								let e = T.find((e) => e.type === "choose" && e.cards?.length === A.length && e.cards.every((e) => A.includes(e)));
								e && k(e);
							},
							children: _("games.fliptoons.choose")
						}),
						w?.optional && /* @__PURE__ */ m("button", {
							className: "ft-button",
							onClick: () => k({ type: "pass" }),
							children: _("games.fliptoons.skip")
						})
					]
				}),
				children: /* @__PURE__ */ h("div", {
					className: "ft-workbench",
					children: [
						/* @__PURE__ */ h("section", {
							className: "ft-market-panel",
							children: [/* @__PURE__ */ h("div", {
								className: "ft-section-heading",
								children: [
									/* @__PURE__ */ m("h2", { children: _("games.fliptoons.market") }),
									/* @__PURE__ */ m(Q, {
										name: "supply",
										children: /* @__PURE__ */ m("button", {
											className: "ft-pile-button",
											onClick: () => x("discarded"),
											children: _("games.fliptoons.supply", { n: e.supplyCount })
										})
									}),
									/* @__PURE__ */ m(Q, { name: "discard" })
								]
							}), /* @__PURE__ */ m(Q, {
								name: "market",
								className: `ft-market-row${e.config.season === "combined" ? " ft-market-seven" : ""}`,
								children: e.market.map((t, n) => /* @__PURE__ */ h("div", {
									className: "ft-market-slot",
									children: [/* @__PURE__ */ m("span", {
										className: "ft-price",
										children: /* @__PURE__ */ m(Y, { value: t?.price ?? (e.config.season === "combined" ? [
											3,
											3,
											4,
											7,
											10,
											15,
											15
										][n] : [
											3,
											4,
											7,
											10,
											15
										][n]) })
									}), /* @__PURE__ */ m(Q, {
										name: `marketSlot:${n}`,
										className: "ft-market-card-space",
										children: t ? /* @__PURE__ */ m(Z, {
											id: t.id,
											kind: t.kind,
											anchor: `market:${t.id}`,
											compact: !0,
											target: w?.kind === "horse" || j.has(t.id),
											selected: A.includes(t.id) || v === t.id,
											onClick: () => z(t.id)
										}) : /* @__PURE__ */ m("span", {
											className: "ft-empty-market",
											"aria-label": _("games.fliptoons.empty")
										})
									})]
								}, n))
							})]
						}),
						/* @__PURE__ */ h("section", {
							className: "ft-stage-panel",
							children: [
								/* @__PURE__ */ h("div", {
									className: "ft-section-heading",
									children: [
										/* @__PURE__ */ h("h2", { children: [
											D(E.rid),
											" ",
											/* @__PURE__ */ m("span", { children: _("games.fliptoons.grid") })
										] }),
										/* @__PURE__ */ m(Q, {
											name: `deck:${E.rid}`,
											children: /* @__PURE__ */ m("button", {
												className: "ft-pile-button",
												disabled: E.rid !== r || !t?.deck.length || !["market", "endTurn"].includes(e.phase),
												onClick: () => x("deck"),
												children: _("games.fliptoons.deck", { n: E.deckCount })
											})
										}),
										/* @__PURE__ */ m(Q, {
											name: `dismissed:${E.rid}`,
											children: /* @__PURE__ */ m("button", {
												className: "ft-pile-button",
												onClick: () => x("dismissed"),
												children: _("games.fliptoons.dismissed", { n: E.dismissed.length })
											})
										})
									]
								}),
								/* @__PURE__ */ m(Q, {
									name: `grid:${E.rid}`,
									className: "ft-cast-grid",
									children: W.flatMap((t) => [
										0,
										1,
										2
									].map((n) => {
										let r = E.grid.filter((e) => e.row === t && e.col === n);
										return /* @__PURE__ */ m("div", {
											className: "ft-grid-slot",
											"data-extra": t < 0 || void 0,
											children: /* @__PURE__ */ m(Q, {
												name: `slot:${E.rid}:${t}:${n}`,
												children: r.length ? r.map((t) => /* @__PURE__ */ m(Z, {
													id: t.id,
													kind: t.kind,
													target: j.has(t.id),
													selected: v === t.id,
													value: e.phase === "flip" ? void 0 : E.breakdown.find((e) => e.id === t.id)?.value,
													onClick: () => y(t.id)
												}, t.id)) : /* @__PURE__ */ m("span", {
													className: "ft-empty-slot",
													"aria-label": _("games.fliptoons.empty")
												})
											})
										}, `${t}:${n}`);
									}))
								}),
								(e.config.bigButton || e.config.bigButton2 !== "off") && /* @__PURE__ */ h("div", {
									className: `ft-button-token${E.button ? "" : " is-spent"}`,
									children: [/* @__PURE__ */ m("i", {}), _(E.button ? "games.fliptoons.buttonReady" : "games.fliptoons.buttonSpent")]
								})
							]
						}),
						/* @__PURE__ */ h("aside", {
							className: "ft-detail-rail",
							children: [
								/* @__PURE__ */ h("div", {
									className: "ft-detail-rail-head",
									children: [/* @__PURE__ */ m("span", { children: _("games.fliptoons.details") }), N && /* @__PURE__ */ m("button", {
										"aria-label": _("games.fliptoons.close"),
										onClick: () => y(null),
										children: /* @__PURE__ */ m(u, { size: 18 })
									})]
								}),
								le,
								U
							]
						})
					]
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "ft-narrow-sheet",
				children: /* @__PURE__ */ m(s, {
					open: N !== void 0,
					onClose: () => y(null),
					label: _("games.fliptoons.details"),
					title: _("games.fliptoons.details"),
					footer: U && /* @__PURE__ */ m("div", {
						className: "ft-sheet-footer",
						children: U
					}),
					children: le
				})
			}),
			/* @__PURE__ */ m(s, {
				open: H,
				onClose: B || w?.kind === "raccoon" ? void 0 : () => x(null),
				label: _(B ? "games.fliptoons.choice.triggerOrder" : b === "deck" ? "games.fliptoons.seeDeck" : "games.fliptoons.seeDismissed"),
				title: _(B ? "games.fliptoons.choice.triggerOrder" : w?.kind === "raccoon" ? "games.fliptoons.choice.raccoon" : b === "deck" ? "games.fliptoons.seeDeck" : "games.fliptoons.seeDismissed"),
				footer: w?.kind === "raccoon" && /* @__PURE__ */ m("div", {
					className: "ft-sheet-footer",
					children: /* @__PURE__ */ m("button", {
						className: "ft-button",
						onClick: () => k({ type: "pass" }),
						children: _("games.fliptoons.skip")
					})
				}),
				children: /* @__PURE__ */ m("div", {
					className: "ft-gallery",
					children: V.map((e) => /* @__PURE__ */ m(Z, {
						...e,
						anchor: `gallery:${e.id}`,
						target: j.has(e.id),
						onClick: () => y(e.id)
					}, e.id))
				})
			}),
			/* @__PURE__ */ m(s, {
				open: w?.kind === "pig",
				label: _("games.fliptoons.chooseTarget"),
				title: _("games.fliptoons.chooseTarget"),
				children: /* @__PURE__ */ m("div", {
					className: "ft-deck-targets",
					children: T.map((e, t) => e.type === "choose" && e.target && /* @__PURE__ */ m("button", {
						className: "ft-button",
						onClick: () => k(e),
						children: e.target === "$supply" ? _("games.fliptoons.toonDeck") : D(e.target)
					}, t))
				})
			})
		]
	});
}
function Fe(e, t) {
	let n = e.find((e) => e.id === t), r = n.kind === "caterpillar" || e.some((e) => e.face && e.kind === "ladybug" && Math.abs(e.row - n.row) + Math.abs(e.col - n.col) === 1);
	return Math.max(0, (r ? 3 : 5) - e.filter((e) => e.face && e.kind === "rat" && e.row === n.row && e.col === n.col).length);
}
//#endregion
//#region src/games/fliptoons/bot.ts
var Ie = {
	dilution: .8,
	dismiss: 1,
	price: .08,
	synergy: 1
}, Le = {
	caterpillar: 0,
	skunk: .6,
	dragonfly: 2.4,
	bee: 1,
	snail: 2,
	mosquito: 0,
	spider: 1.5,
	grasshopper: 1.5,
	ladybug: 1.4,
	firefly: 1.7,
	ostrich: 2.4,
	eagle: 2.6,
	donkey: 3.4,
	butterfly: 3.5,
	dog: 1.4,
	goat: 2.5,
	sheep: 2.3,
	camel: 3.7,
	rabbit: 3.8,
	horse: 4.2,
	snake: 4.6,
	elephant: 5.4,
	rooster: 4.5,
	cat: 2.5,
	alligator: 4.9,
	lion: 5.8,
	monkey: 4.2,
	pig: -1.8,
	peacock: 6.2,
	turkey: 6,
	bull: 5.2,
	tiger: 5,
	deer: 6.2,
	bear: 7.2,
	cow: 5,
	salamander: 3.5,
	groundhog: 2.4,
	rat: 2.4,
	goldfish: 2.3,
	mole: 4,
	hen: 4.2,
	starfish: 3.8,
	raccoon: 4.7,
	panther: 4.5,
	opossum: 3.5,
	mongoose: 5,
	capybara: 3.2,
	crow: 3,
	coyote: 5.2,
	clownfish: 3.7,
	fox: 4.5,
	crab: 3.5,
	swordfish: 5,
	gorilla: 6,
	vulture: 4.8,
	zebra: 5.8,
	shark: 4.5,
	rhinoceros: 4.6,
	hippopotamus: 4,
	sloth: 4.3,
	axolotl: 8,
	platypus: 6.5
};
function Re(e) {
	return Le[e] ?? S(e).fame;
}
function ze(e, t, n = Ie) {
	let r = e.public, i = e.private?.legalActions ?? [], a = r.players.find((e) => e.rid === t);
	if (!a || !i.length) return null;
	let o = [...a.grid.flatMap((e) => e.kind === null ? [] : [e.kind]), ...(e.private?.deck ?? []).map((e) => e.kind)], s = (e) => o.filter((t) => t === e).length, c = (e) => {
		let t = Re(e);
		return (e === "cat" || e === "tiger") && (t += a.dismissed.length * .6), e === "dog" && r.market.some((e) => e?.kind === "dog") && (t += 2), (e === "camel" || e === "rabbit") && (t += s(e) * .45 * n.synergy), (S(e).fish || e === "shark") && (t += o.filter((e) => S(e).fish).length * .6 * n.synergy), (e === "hippopotamus" || e === "capybara") && (t += Math.max(0, o.length - 6) * .6), e === "butterfly" && s("caterpillar") === 0 && (t -= 1.3), t;
	}, l = o.reduce((e, t) => e + c(t), 0) / Math.max(1, o.length), u = (e) => a.grid.find((t) => t.id === e)?.kind ?? r.market.find((t) => t?.id === e)?.kind ?? r.players.flatMap((e) => e.dismissed).find((t) => t.id === e)?.kind, d = (e) => {
		if (e.type === "hire") {
			let t = r.market[e.slot];
			return c(t.kind) - l * n.dilution * Math.min(1, Math.max(0, o.length - 5) / 3) - t.price * n.price;
		}
		if (e.type === "dismiss") {
			let t = u(e.card);
			return t ? (l - c(t)) * n.dismiss - (o.length <= 5 ? 4 : .15) : -10;
		}
		if (e.type === "button") return e.use ? r.phase === "button" ? a.generated < l * Math.min(6, o.length) * .7 ? 2 : -1 : r.market.every((e) => e === null || e.price > a.fame || c(e.kind) < l) ? 1 : -1 : 0;
		if (e.type === "choose") {
			if (r.pending?.kind === "pig") return e.target === "$supply" ? 0 : e.target === t ? -10 : 10 / Math.max(1, r.players.find((t) => t.rid === e.target).deckCount);
			if (e.cards) return e.cards.reduce((e, t) => e + 3.2 - c(u(t)), 0);
			if (e.card !== void 0) {
				let t = u(e.card);
				return t ? r.pending?.kind === "triggerOrder" ? t === "peacock" ? 10 : t === "crow" || t === "raccoon" ? 7 : t === "horse" ? 1 : 5 : ["raccoon", "crow"].includes(r.pending?.kind ?? "") ? c(t) - l * n.dilution : l - c(t) + 1 : -10;
			}
		}
		return e.type === "pass" ? r.pending ? -.05 : i.some((e) => e.type === "hire") ? -20 : -.05 : -30;
	};
	return i.reduce((e, t) => d(t) > d(e) ? t : e, i[0]);
}
function Be(e = Ie) {
	return (t, n) => {
		let r = t.private?.legalActions ?? [];
		if (!r.length) return null;
		if (n.difficulty === "weak") {
			let e = Math.floor(4294967296 / r.length) * r.length, t;
			do
				t = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
			while (t >= e);
			return { action: r[t % r.length] };
		}
		let i = ze(t, n.rid, e);
		return i ? { action: i } : null;
	};
}
var Ve = Be(), He = (e) => e.data;
function Ue({ from: e, to: t, data: i, ms: a, compact: o }) {
	let s = r(null);
	return n(() => {
		let n = e.x + e.w / 2 - t.x - t.w / 2, r = e.y + e.h / 2 - t.y - t.h / 2, i = s.current?.animate([
			{ transform: `translate(${n}px,${r}px) scale(${e.w / t.w},${e.h / t.h})` },
			{
				transform: `translate(${n * .45}px,${r * .45 - 12}px) scale(${.55 + e.w / t.w * .45},${.55 + e.h / t.h * .45})`,
				offset: .55
			},
			{ transform: "translate(0,0) scale(1)" }
		], {
			duration: a,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => i?.cancel();
	}, [
		e,
		t,
		a
	]), /* @__PURE__ */ m("div", {
		ref: s,
		className: "ft-fx-card",
		style: {
			position: "absolute",
			left: t.x,
			top: t.y,
			width: t.w,
			height: t.h
		},
		children: /* @__PURE__ */ m(Z, {
			id: i.card ?? -1,
			kind: i.toon,
			compact: o,
			anchor: `sprite:${i.card}`
		})
	});
}
function We({ box: e, data: t, ms: i }) {
	let a = r(null);
	return n(() => {
		let e = a.current?.animate([{ transform: "perspective(700px) rotateY(-95deg) scale(.96)" }, { transform: "perspective(700px) rotateY(0) scale(1)" }], {
			duration: i,
			easing: "cubic-bezier(.2,.7,.3,1)",
			fill: "both"
		});
		return () => e?.cancel();
	}, [i]), /* @__PURE__ */ m("div", {
		ref: a,
		className: "ft-fx-card",
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ m(Z, {
			id: t.card ?? -1,
			kind: t.toon,
			anchor: `sprite:${t.card}`
		})
	});
}
var $ = (e, t) => {
	let n = He(e), r = t.anchor(`score:${e.rid}`), i = n.from ? t.anchor(n.from) ?? r : r, a = n.to ? t.anchor(n.to) ?? r : r;
	if (!i || !a) return null;
	let o = e.kind === "reveal" ? D.reveal : e.kind === "reset" ? D.cleanup : D.effect, s = t.queued ? Math.min(220, o) : o, c = (e) => e?.startsWith("card:") || e?.startsWith("market:") || e?.startsWith("marketSlot:") || e?.startsWith("slot:"), l = (e, t) => c(t) && e.w > 60 && e.h > 60 ? e : {
		x: e.x + e.w / 2 - 24,
		y: e.y + e.h / 2 - 32,
		w: 48,
		h: 64
	}, u = l(i, n.from), d = l(a, n.to);
	return {
		ms: s,
		hide: !t.queued && n.to?.startsWith("card:") || !t.queued && n.to?.startsWith("market:") ? [n.to] : void 0,
		node: /* @__PURE__ */ m(Ue, {
			from: u,
			to: d,
			data: n,
			ms: s,
			compact: !!n.to?.startsWith("market:")
		})
	};
}, Ge = {
	reveal: $,
	stack: $,
	hire: $,
	dismiss: $,
	return: $,
	reset: $,
	cleanup: $,
	reorder: $,
	flip(e, t) {
		let n = He(e), r = t.anchor(`card:${n.card}`);
		if (!r) return null;
		let i = t.queued ? 180 : D.effect;
		return {
			ms: i,
			hide: t.queued ? [] : [`card:${n.card}`],
			node: /* @__PURE__ */ m(We, {
				box: r,
				data: n,
				ms: i
			})
		};
	},
	score(e, t) {
		let n = t.anchor(`score:${e.rid}`), r = He(e);
		return n ? {
			ms: D.score,
			node: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(_, {
				at: n,
				ms: D.score
			}), /* @__PURE__ */ m(g, {
				at: n,
				ms: D.score,
				children: /* @__PURE__ */ m(Y, { value: r.value ?? 0 })
			})] })
		} : null;
	}
};
//#endregion
//#region src/games/fliptoons/game-over.tsx
function Ke(e) {
	let t = o(), n = e.public, [r, a] = i(!0), s = (r) => e.members.find((e) => e.rid === r)?.name || t(f[n.players.findIndex((e) => e.rid === r) % f.length].nameKey), c = e.result.ranking.map((e) => n.players.find((t) => t.rid === e)), l = e.result.winner[0], ee = n.players.length === 1 ? t(n.soloWon ? "games.fliptoons.soloWin" : "games.fliptoons.soloLoss") : t("games.fliptoons.winner", { name: s(l) });
	return /* @__PURE__ */ h("div", {
		className: "ft-result-root",
		children: [
			/* @__PURE__ */ m("div", {
				className: "ft-final-table",
				inert: r,
				children: /* @__PURE__ */ m(Pe, {
					...e,
					pub: n,
					priv: e.private,
					send: () => {},
					readOnly: !0
				})
			}),
			/* @__PURE__ */ m("button", {
				className: "ft-result-tab ft-button",
				hidden: r,
				onClick: () => a(!0),
				children: t("games.fliptoons.showResult")
			}),
			/* @__PURE__ */ m("div", {
				className: "ft-result-shade",
				hidden: !r,
				children: /* @__PURE__ */ h("section", {
					className: "ft-awards",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.fliptoons.result"),
					children: [
						/* @__PURE__ */ h("header", {
							className: "ft-awards-head",
							children: [/* @__PURE__ */ h("span", { children: ["FlipToons · ", t("games.fliptoons.result")] }), /* @__PURE__ */ m("button", {
								onClick: () => a(!1),
								"aria-label": t("games.fliptoons.review"),
								children: /* @__PURE__ */ m(d, { size: 22 })
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "ft-awards-scroll",
							children: [
								/* @__PURE__ */ h("div", {
									className: "ft-awards-hero",
									children: [
										/* @__PURE__ */ m("span", {
											className: "ft-award-seal",
											"aria-hidden": !0,
											children: "★"
										}),
										/* @__PURE__ */ m("h1", { children: ee }),
										/* @__PURE__ */ m("p", { children: t("games.fliptoons.round", { n: n.round }) })
									]
								}),
								/* @__PURE__ */ m("div", {
									className: "ft-result-table-wrap",
									children: /* @__PURE__ */ h("table", {
										className: "ft-result-table",
										style: c.length > 4 ? { minWidth: c.length * 90 + 110 } : void 0,
										children: [/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {}), /* @__PURE__ */ m(p, { children: c.map((e) => /* @__PURE__ */ m("th", { children: s(e.rid) }, e.rid)) })] }) }), /* @__PURE__ */ h("tbody", { children: [
											/* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { children: t("games.fliptoons.gridFame") }), c.map((e) => /* @__PURE__ */ m("td", { children: e.breakdown.reduce((e, t) => e + t.value, 0) }, e.rid))] }),
											/* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { children: t("games.fliptoons.abilityBonus") }), c.map((e) => /* @__PURE__ */ m("td", { children: e.generated - e.breakdown.reduce((e, t) => e + t.value, 0) - (n.final && n.critic === e.rid ? 3 : 0) }, e.rid))] }),
											n.critic && /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { children: t("games.fliptoons.bonus") }), c.map((e) => /* @__PURE__ */ m("td", { children: n.critic === e.rid && n.final ? 3 : 0 }, e.rid))] }),
											/* @__PURE__ */ h("tr", {
												className: "ft-total-row",
												children: [/* @__PURE__ */ m("th", { children: t("games.fliptoons.total") }), c.map((e) => /* @__PURE__ */ m("td", { children: e.generated }, e.rid))]
											})
										] })]
									})
								}),
								c.map((n) => /* @__PURE__ */ h("details", {
									className: "ft-awards-details",
									children: [
										/* @__PURE__ */ h("summary", { children: [
											s(n.rid),
											" · ",
											t("games.fliptoons.scoreDetails")
										] }),
										/* @__PURE__ */ m("div", {
											className: "ft-breakdown",
											children: n.breakdown.map((e) => /* @__PURE__ */ h("p", { children: [/* @__PURE__ */ m("span", { children: e.kind ? t(S(e.kind).name) : t("games.fliptoons.faceDown") }), /* @__PURE__ */ m("b", { children: e.value })] }, e.id))
										}),
										e.result.autopilot?.[n.rid] ? /* @__PURE__ */ m("p", { children: t("session.autopilot.share", { n: Math.round(e.result.autopilot[n.rid] * 100) }) }) : null
									]
								}, n.rid)),
								e.hintCount !== void 0 && /* @__PURE__ */ m("p", { children: t("session.hint.usedCount", { n: e.hintCount }) })
							]
						}),
						/* @__PURE__ */ h("footer", {
							className: "ft-awards-controls",
							children: [e.onPlayAgain || e.onBackToLobby ? /* @__PURE__ */ h(p, { children: [
								e.onPlayAgain && /* @__PURE__ */ m(ne, {
									label: t("session.result.playAgain"),
									confirmLabel: t("games.fliptoons.confirmAgain"),
									onConfirm: e.onPlayAgain
								}),
								" ",
								e.onBackToLobby && /* @__PURE__ */ m(ne, {
									label: t("session.result.backToLobby"),
									confirmLabel: t("games.fliptoons.confirmLobby"),
									onConfirm: e.onBackToLobby
								})
							] }) : /* @__PURE__ */ m("p", { children: t("session.result.waitHost") }), /* @__PURE__ */ h("button", {
								className: "ft-button",
								onClick: () => a(!1),
								children: [
									/* @__PURE__ */ m(u, { size: 13 }),
									" ",
									t("games.fliptoons.review")
								]
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/fliptoons/options.tsx
function qe({ value: e, onChange: t }) {
	let n = o(), r = C.safeParse(e), i = r.success ? r.data : C.parse(void 0), a = [
		["base", "games.fliptoons.base"],
		["season2", "games.fliptoons.season2"],
		["combined", "games.fliptoons.combined"]
	], s = [
		["off", "games.fliptoons.off"],
		["grid", "games.fliptoons.gridReset"],
		["market", "games.fliptoons.marketReset"]
	], c = [
		["easy", "games.fliptoons.easy"],
		["normal", "games.fliptoons.normal"],
		["hard", "games.fliptoons.hard"]
	], l = (e, t, r, i, a) => /* @__PURE__ */ m(v, {
		name: `ft-${e}`,
		value: t,
		checked: r,
		label: n(i),
		accent: b.accent,
		onChange: a
	}, t);
	return /* @__PURE__ */ h("div", {
		className: "ft-options",
		children: [
			/* @__PURE__ */ m(y, {
				title: n("games.fliptoons.optSeason"),
				children: a.map(([e, n]) => l("season", e, i.season === e, n, () => t({
					...i,
					season: e
				})))
			}),
			/* @__PURE__ */ m(y, {
				title: n("games.fliptoons.optButton"),
				children: /* @__PURE__ */ m(re, {
					name: "ft-button",
					value: "on",
					checked: i.bigButton,
					label: n("games.fliptoons.optButton"),
					accent: b.accent,
					onChange: () => t({
						...i,
						bigButton: !i.bigButton
					})
				})
			}),
			/* @__PURE__ */ m(y, {
				title: n("games.fliptoons.optButton2"),
				children: s.map(([e, n]) => l("button2", e, i.bigButton2 === e, n, () => t({
					...i,
					bigButton2: e
				})))
			}),
			/* @__PURE__ */ m(y, {
				title: n("games.fliptoons.optDifficulty"),
				children: c.map(([e, n]) => l("difficulty", e, i.soloDifficulty === e, n, () => t({
					...i,
					soloDifficulty: e
				})))
			}),
			i.season === "combined" && /* @__PURE__ */ m(y, {
				title: n("games.fliptoons.optSoloStart"),
				children: a.slice(0, 2).map(([e, n]) => l("soloStart", e, i.soloStart === e, n, () => t({
					...i,
					soloStart: e
				})))
			})
		]
	});
}
//#endregion
//#region src/games/fliptoons/guide.tsx
function Je() {
	let e = o();
	return /* @__PURE__ */ h("section", {
		className: "ft-guide",
		children: [/* @__PURE__ */ m("h3", { children: e("games.fliptoons.legend") }), /* @__PURE__ */ h("div", {
			className: "ft-guide-symbols",
			children: [
				/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(Y, {}), e("games.fliptoons.fame")] }),
				/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "fish" }), e("games.fliptoons.fish")] }),
				/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "unflip" }), e("games.fliptoons.protectedFlip")] }),
				/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "undismiss" }), e("games.fliptoons.protectedDismiss")] }),
				/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "unreturn" }), e("games.fliptoons.protectedReturn")] }),
				/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "hired" }), e("games.fliptoons.whenHired")] }),
				/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "dismissed" }), e("games.fliptoons.whenDismissed")] }),
				/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, { kind: "hiredDismissed" }), e("games.fliptoons.whenHiredDismissed")] })
			]
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/fliptoons/entry.tsx
var Ye = {
	definition: Ae,
	View: Ne,
	bot: Ve,
	fx: Ge,
	OverView: Ke,
	Options: qe,
	Guide: Je,
	locales: {
		zh: {
			selectPrompt: "点选一张角色牌，查看完整能力与可用行动。",
			gridFame: "牌阵声望",
			abilityBonus: "额外声望",
			scoreDetails: "逐牌计分",
			card: {
				caterpillar: {
					name: "毛毛虫",
					text: "解雇本牌只需支付3点声望。"
				},
				skunk: {
					name: "臭鼬",
					text: "计分后，如果只有你拥有全场最低声望，你必须免费解雇自己牌阵中的一张正面朝上的牌。此效果不消耗行动。"
				},
				dragonfly: {
					name: "蜻蜓",
					text: "每种与本牌相邻且正面朝上的不同角色，为本牌增加1点声望。"
				},
				bee: {
					name: "蜜蜂",
					text: "本牌产生1点声望。"
				},
				snail: {
					name: "蜗牛",
					text: "本牌产生2点声望。"
				},
				mosquito: {
					name: "蚊子",
					text: "本牌不产生声望。"
				},
				spider: {
					name: "蜘蛛",
					text: "同一列中，每张位于本牌下方的牌，为本牌增加1点声望。同一叠中的牌不计。"
				},
				grasshopper: {
					name: "蚱蜢",
					text: "同一列中，每张位于本牌上方的牌，为本牌增加1点声望。同一叠中的牌不计。"
				},
				ladybug: {
					name: "瓢虫",
					text: "与本牌相邻的牌，其解雇费用改为3点声望。"
				},
				firefly: {
					name: "萤火虫",
					text: "计分后，如果只有你拥有全场最低声望，额外获得2点声望。并列最低时无效。"
				},
				ostrich: {
					name: "鸵鸟",
					text: "将下一张揭示的牌叠在本牌上，再处理那张牌的能力。位于牌阵最后一格时不再额外抽牌。"
				},
				eagle: {
					name: "老鹰",
					text: "将下一张放置的牌翻为背面朝上，并忽略其能力；不能翻面的牌不受影响。本牌不能翻面。"
				},
				donkey: {
					name: "驴",
					text: "位于原牌阵下排时，额外产生5点声望，并在本人的市场阶段结束后解雇本牌。"
				},
				butterfly: {
					name: "蝴蝶",
					text: "招募本牌时，你可以免费解雇自己牌阵中一张正面朝上的毛毛虫。"
				},
				dog: {
					name: "狗",
					text: "如果市场或任意其他玩家的牌阵中至少有一张正面朝上的狗，本牌额外产生5点声望。"
				},
				goat: {
					name: "山羊",
					text: "位于原牌阵上排时，额外产生3点声望。"
				},
				sheep: {
					name: "绵羊",
					text: "位于中间一列时，额外产生4点声望。"
				},
				camel: {
					name: "骆驼",
					text: "如果没有其他玩家或市场拥有比你更多的正面朝上骆驼，本牌额外产生2点声望。并列最多也有效。"
				},
				rabbit: {
					name: "兔子",
					text: "将本牌叠在牌阵中第一张兔子或背面朝上的牌上；没有符合条件的牌时留在原位。本牌不能翻面。"
				},
				horse: {
					name: "马",
					text: "招募本牌时，你可以弃掉市场中任意数量的牌，翻出等量新牌替换，再按等级重新排列市场；其他购买留下的空位不补牌。"
				},
				snake: {
					name: "蛇",
					text: "解雇自己牌库顶的一张牌，再将市场牌库顶的一张牌叠在本牌上。不能解雇的牌保留，并按规则继续放置。"
				},
				elephant: {
					name: "大象",
					text: "将之前放置的牌翻面；不能翻面的牌不受影响。本牌不能翻面。翻回正面的牌不重新触发能力。"
				},
				rooster: {
					name: "公鸡",
					text: "自己牌阵中，每张等级不超过13且正面朝上的牌，为本牌增加1点声望，包括本牌。"
				},
				cat: {
					name: "猫",
					text: "自己的解雇牌中，每张起始牌为本牌增加1点声望。本牌不能被解雇。"
				},
				alligator: {
					name: "短吻鳄",
					text: "在本人的市场阶段结束后，解雇本牌右侧相邻格中的一张正面朝上的牌。若该格为一叠牌，你选择其中一张。"
				},
				lion: {
					name: "狮子",
					text: "如果与本牌相邻的所有正面朝上牌的等级均不超过16，额外产生4点声望。"
				},
				monkey: {
					name: "猴子",
					text: "放入原牌阵上排时，将本牌移到该格上方的新一排。下一张牌填入腾出的格位。"
				},
				pig: {
					name: "猪",
					text: "本牌被招募或解雇时，将本牌放入任意玩家的牌库，或洗回市场牌库。"
				},
				peacock: {
					name: "孔雀",
					text: "招募本牌时，立即获得2点声望，并获得一次额外市场行动。"
				},
				turkey: {
					name: "火鸡",
					text: "将本牌叠在之前放置的牌上。若本牌是第一张放置的牌，则留在原位。"
				},
				bull: {
					name: "公牛",
					text: "自己的牌阵中只要有一张背面朝上的牌，额外产生7点声望。本牌不能翻面。"
				},
				tiger: {
					name: "老虎",
					text: "自己的解雇牌中，每张牌为本牌增加1点声望。本牌不能被解雇。"
				},
				deer: {
					name: "鹿",
					text: "如果自己牌阵中所有正面朝上的角色均不重复，额外产生5点声望。"
				},
				bear: {
					name: "熊",
					text: "自己牌阵中，每张正面朝上的牌为本牌增加1点声望，包括本牌。"
				},
				cow: {
					name: "奶牛",
					text: "复制一张相邻牌产生的声望。相邻格中有叠牌时，可以选择其中任意一张。"
				},
				salamander: {
					name: "蝾螈",
					text: "如果下一张揭示的牌等级不超过1，将其放回自己牌库底，并忽略其能力。"
				},
				groundhog: {
					name: "土拨鼠",
					text: "在本人的市场阶段结束后，若本牌位于原3×2牌阵的第一格或最后一格，解雇本牌。"
				},
				rat: {
					name: "老鼠",
					text: "将本牌叠在之前放置的牌上。本叠中每张正面朝上的老鼠，使本叠牌的解雇费用减少1点声望，最低为0。"
				},
				goldfish: {
					name: "金鱼",
					text: "自己牌阵中，每张鱼类牌为本牌增加1点声望，包括本牌。本牌不能翻面。"
				},
				mole: {
					name: "鼹鼠",
					text: "放入原牌阵下排时，将本牌叠在它正上方格位的牌上。"
				},
				hen: {
					name: "母鸡",
					text: "自己牌阵中，每张等级至少为6且正面朝上的牌，为本牌增加1点声望，包括本牌。"
				},
				starfish: {
					name: "海星",
					text: "将之前放置的牌翻面，再将本牌叠在其上；不能翻面的牌只叠放。本牌是鱼类牌，不能翻面。"
				},
				raccoon: {
					name: "浣熊",
					text: "招募本牌时，你可以免费招募任意玩家解雇牌中的一张牌。"
				},
				panther: {
					name: "黑豹",
					text: "将本牌叠在之前放置的牌上。招募本牌时，必须免费解雇自己牌阵中一张正面朝上的牌。"
				},
				opossum: {
					name: "负鼠",
					text: "自己的解雇牌中，每对相同角色为本牌增加2点声望。每张牌最多计入一对。本牌不能被解雇。"
				},
				mongoose: {
					name: "猫鼬",
					text: "解雇自己牌库底的一张牌，再将市场牌库顶的一张牌放到自己牌库顶。不能解雇的牌保留；获得牌不触发招募能力。"
				},
				capybara: {
					name: "水豚",
					text: "如果自己的牌库中至少剩3张牌，额外产生4点声望。"
				},
				crow: {
					name: "乌鸦",
					text: "本牌被解雇时，你可以免费招募市场中的一张牌，然后立即补满市场。"
				},
				coyote: {
					name: "郊狼",
					text: "将之前放置的牌放回自己牌库底，并让本牌占据它的格位。若该牌不能被放回，则将本牌叠在其上。本牌不能被放回。"
				},
				clownfish: {
					name: "小丑鱼",
					text: "如果至少与一张鱼类牌相邻，额外产生2点声望。本牌是鱼类牌，不能翻面。"
				},
				fox: {
					name: "狐狸",
					text: "如果市场或任意玩家的牌阵中至少有一张母鸡或公鸡，额外产生3点声望。"
				},
				crab: {
					name: "螃蟹",
					text: "放入中间一列时，将本牌放回自己牌库底。如果牌库只剩螃蟹，结束本次翻牌。本牌在额外排或叠牌中也适用。"
				},
				swordfish: {
					name: "剑鱼",
					text: "将之前放置的牌和下一张放置的牌分别翻面；不能翻面的牌不受影响。本牌是鱼类牌，不能翻面。"
				},
				gorilla: {
					name: "大猩猩",
					text: "放入原牌阵上排时，将下一张揭示的牌放在本牌上方的新一排。若上方已有牌，继续向上增加一排。"
				},
				vulture: {
					name: "秃鹫",
					text: "在本人的市场阶段结束后，解雇自己牌阵中等级最低的正面朝上牌；若该牌不能解雇，则不解雇其他牌。"
				},
				zebra: {
					name: "斑马",
					text: "将自己牌阵中等级最低的正面朝上牌放回牌库底，并让本牌占据其格位。若该牌不能被放回，则将本牌叠在其上。本牌不能被放回。"
				},
				shark: {
					name: "鲨鱼",
					text: "自己牌阵中，每张鱼类牌为本牌增加1点声望。鲨鱼自身不算鱼类牌，且不能翻面。"
				},
				rhinoceros: {
					name: "犀牛",
					text: "每张与本牌相邻、等级为奇数且正面朝上的牌，为本牌增加3点声望。"
				},
				hippopotamus: {
					name: "河马",
					text: "自己的牌库中，每张尚未翻出的牌为本牌增加2点声望。"
				},
				sloth: {
					name: "树懒",
					text: "将本牌叠在之前放置的牌上。如果自己的牌阵中至少有8张牌，额外产生5点声望。"
				},
				axolotl: {
					name: "美西螈",
					text: "招募本牌时，将自己的大按钮翻回正面。"
				},
				platypus: {
					name: "鸭嘴兽",
					text: "招募本牌时，将所有玩家的大按钮翻回正面。如果自己的按钮背面朝上，本牌额外产生3点声望。"
				}
			},
			name: "翻转星途",
			desc: "组建动画演员牌库，让六格试镜阵容产生精彩组合。",
			round: "第{{n}}轮",
			final: "最终试镜",
			flip: "演员正在登场",
			famePhase: "正在计算声望",
			market: "演员市场",
			yourTurn: "轮到你选择演员",
			waiting: "等待{{name}}行动",
			fame: "声望",
			actions: "剩余{{n}}次行动",
			deck: "牌库 · {{n}}张",
			dismissed: "已解雇 · {{n}}张",
			supply: "市场牌库 · {{n}}张",
			critic: "影评人之选 +3",
			grid: "试镜阵容",
			hire: "招募 · {{n}}声望",
			dismiss: "解雇 · {{n}}声望",
			pass: "结束市场回合",
			choose: "确认选择",
			skip: "跳过此能力",
			close: "关闭",
			faceDown: "背面朝上的牌",
			empty: "空位",
			inspect: "查看卡牌",
			seeDeck: "查看自己的牌库",
			seeDismissed: "查看解雇牌",
			details: "卡牌详情",
			buttonReady: "重置按钮可用",
			buttonSpent: "重置按钮已使用",
			resetGrid: "重置本次试镜",
			resetMarket: "重置市场",
			keepGrid: "保留当前阵容",
			buttonPrompt: "选择是否使用大按钮",
			chooseTarget: "选择接收牌的牌库",
			toonDeck: "市场牌库",
			result: "本季最佳演员阵容",
			winner: "{{name}}赢得最佳阵容",
			soloWin: "试镜成功！",
			soloLoss: "市场已关闭，本次试镜未达标。",
			review: "回看阵容",
			showResult: "查看颁奖结果",
			cancel: "取消",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			total: "总声望",
			cardFame: "本轮产生{{n}}点声望",
			bonus: "影评人奖励",
			chooseHorse: "选择要弃掉的市场牌，然后确认。可以不选。",
			optSeason: "演员阵容版本",
			base: "基础版",
			season2: "Season 2",
			combined: "基础版 + Season 2（最多8人）",
			optButton: "Big Button 迷你扩展",
			optButton2: "Big Button 2 重置方式",
			off: "关闭",
			gridReset: "重置牌阵",
			marketReset: "重置市场",
			optDifficulty: "单人难度",
			easy: "入门",
			normal: "标准",
			hard: "挑战",
			optSoloStart: "组合版单人起始牌库",
			invalid: "此时不能执行该行动。",
			emptyMarket: "市场已售罄",
			chosen: "已选中",
			protectedFlip: "不能翻面",
			protectedDismiss: "不能解雇",
			protectedReturn: "不能放回",
			fish: "鱼类",
			rank: "等级{{n}}",
			fallbackName: "蓝色剧组",
			cleanup: "准备下一场试镜",
			choice: {
				skunk: "臭鼬：选择一张牌免费解雇。",
				butterfly: "蝴蝶：可以免费解雇一张毛毛虫。",
				horse: "马：选择要替换的市场牌。",
				pig: "猪：选择本牌要加入的牌库。",
				raccoon: "浣熊：可以免费招募一张已解雇的牌。",
				panther: "黑豹：选择一张牌免费解雇。",
				crow: "乌鸦：可以免费招募一张市场牌。",
				alligator: "短吻鳄：解雇右侧相邻格中的一张牌。",
				triggerOrder: "选择先结算哪张牌的招募或解雇能力。"
			},
			rules: "目标：\n你是一名动画演员经纪人。每轮将自己的牌库洗牌，逐张翻入3列、2排的试镜牌阵，利用角色能力产生声望，再用这些声望招募或解雇演员。多人游戏中，有人达到30点声望后触发最终试镜；最终试镜声望最高者获胜。声望不会跨轮累积。\n准备：\n· 基础版每人获得2张毛毛虫、1张臭鼬、1张蜻蜓、1张蜜蜂和1张蜗牛。Season 2每人获得2张蚊子、1张蜘蛛、1张蚱蜢、1张瓢虫和1张萤火虫。\n· 将53张市场牌洗匀，翻出5张，按等级从低到高对应3、4、7、10、15点声望的价位。相同等级的牌保留出现先后顺序。各轮由起始玩家先进行市场回合，起始玩家标记每轮顺时针传递。\n· 基础版和Season 2组合时，混合两套市场牌，使用3、3、4、7、10、15、15七个价位，最多支持8人。每名玩家随机获得其中一套起始牌库，每套最多分配4份。超过4人时使用组合版。\n翻牌阶段：\n所有玩家同时进行试镜。每名玩家把自己的牌库洗匀，逐张从左到右填满上排，再填下排。放置能力必须在下一张牌揭示前处理。牌库不足时，放完现有牌后结束翻牌。系统逐步展示各张牌及其能力结果。基础版同时触发的能力按从上到下、从左到右的格位顺序处理；Season 2及组合版的翻牌能力按揭示顺序处理。同一叠内均从最上方的牌开始。\n· 相邻只指共用边的格位，不包括对角。叠在同一格的牌彼此不相邻，但整叠均与相邻格的牌相邻；每张正面朝上的叠牌仍具有自己的名称、等级、声望和能力。\n· 背面朝上的牌占据格位，但没有名称、等级、声望或能力。被其他能力翻回正面时，不重新触发放置能力。不能翻面的牌不受翻面能力影响。\n· 放回是把牌放到本人牌库底；解雇是把牌移入公开的解雇牌区。自己的解雇牌与其他玩家的解雇牌始终可以查看。市场阶段可以查看自己的牌库，其他玩家只能看到张数。\n· 指向下一张牌的能力只对下一次揭示生效一次。放在最后一个格位时，不为此额外揭示一张。指向之前放置牌的能力，以最后加入且仍在牌阵中的牌为准。\n· 选择最低等级牌时，先看正面朝上的牌；同等级时，从最上排、最左列开始，同一叠中先取最上方的牌。额外排不改变原本上排、下排的含义。\n· 翻牌中触发的招募或解雇能力，在全员翻牌结束后，从起始玩家开始依次处理。蛇从市场牌库放入牌阵的牌会触发适用的招募能力；猫鼬只把牌加入牌库，不触发招募能力。\n同一玩家在牌阵外有多项同时触发的招募或解雇能力时，由该玩家选择先后顺序。\n声望阶段：\n计算每张正面朝上牌产生的声望，详见牌面能力。奶牛自动复制相邻牌中最高的声望。萤火虫只奖励唯一声望最低者；臭鼬的免费解雇也只属于唯一最低者。并列最低时，相应能力无效。声望一旦确定，在市场阶段不随牌阵或市场变化重新计算。\n若任意玩家达到30点声望，本轮声望最高且未并列的玩家获得“影评人之选”，在最终试镜中额外获得3点声望；最高分并列时无人获得。继续完成本轮市场阶段，再进入最终试镜。\n市场阶段：\n从起始玩家开始，每人最多执行两次以下行动。可以各执行一次，也可以重复同一种行动；可以提前结束回合。\n· 招募：支付该牌上方价位所示的声望，将牌加入自己的牌库，并立即处理其招募能力。\n· 解雇：通常支付5点声望，将自己牌阵中一张正面朝上的牌移到公开解雇区。毛毛虫、瓢虫和老鼠可以降低费用；不能解雇的牌不能选择。自己的牌库和牌阵合计少于4张牌时，不能解雇任何牌，包括免费能力。\n· 角色给予的免费招募、免费解雇和额外行动按牌面处理。猪被招募或解雇时，必须选择一副牌库供它加入；放回市场牌库时会洗牌。可选能力可以跳过，强制能力有合法目标时必须完成。\n市场回合结束时，同时触发的牌阵能力按从上到下、从左到右的格位顺序处理，同一叠内从最上方开始。每名玩家完成行动及本回合结束能力后，补满市场并按等级重新排列。市场牌库耗尽时不再补牌，剩余牌排列在最高的几个价位下；连市场也耗尽时，本轮结束后进入最终试镜。\n清理与结束：\n· 全员完成市场回合后，把牌阵中的牌收回各自牌库。单独版本的1至2人局，以及组合版的1至4人局，额外弃掉市场最左和最右各一张牌，然后补满市场。\n· 若本轮尚未触发结束，传递起始玩家标记并开始下一轮。若已触发结束，全员再洗牌、翻牌并计算声望，不再进入市场。\n· 最终试镜声望最高者获胜。若最高者并列，仅并列者重新收牌、洗牌、翻牌及计分，直到决出胜者；影评人奖励继续适用。\n单人模式：\n单人局的目标是在市场牌库无法补满市场前，单次计分达到30点声望。达到目标立即获胜，不进行最终试镜。\n· 基础起始牌库改为3张毛毛虫、1张蜻蜓、1张蜜蜂和1张蜗牛，不使用臭鼬；Season 2改为3张蚊子、1张蜘蛛、1张蚱蜢和1张瓢虫，不使用萤火虫。移除市场牌库中的猪。\n· 单独版本在初始市场建立后，按入门、标准或挑战难度弃掉17、20或23张市场牌。组合版对应弃掉67、70或73张，并可选择两套单人起始牌库之一。\n· 每轮市场结束后仍需弃掉市场两端并补满。任何一次补牌不足时立即失败。\n迷你扩展：\n· Big Button默认关闭。启用后加入2张美西螈，每人获得一个正面朝上的大按钮。每次计分后，按起始顺序决定是否使用按钮。使用者把按钮翻为背面，将牌阵收回牌库洗牌，再同时重新翻牌；随后全员重新计分。招募美西螈会恢复自己的按钮。\n· Big Button 2默认关闭。启用后加入2张鸭嘴兽，开局选择重置牌阵或重置市场。重置牌阵使用上述时机；重置市场只能在本人市场回合执行任何行动之前使用，把所有市场牌洗回市场牌库后重新补满。招募鸭嘴兽恢复所有玩家的按钮。\n· 两款同时启用时共用每人一个按钮，使用Big Button 2选定的重置方式。单人局每启用一款迷你扩展，准备时额外弃掉2张市场牌。",
			whenHired: "招募时触发",
			whenDismissed: "解雇时触发",
			whenHiredDismissed: "招募或解雇时触发",
			legend: "规则图标"
		},
		en: {
			selectPrompt: "Select a toon to read its ability and available actions.",
			gridFame: "Cast fame",
			abilityBonus: "Extra fame",
			scoreDetails: "Card-by-card scoring",
			card: {
				caterpillar: {
					name: "Caterpillar",
					text: "This card costs 3 fame to dismiss."
				},
				skunk: {
					name: "Skunk",
					text: "After scoring, if you alone have the least fame, dismiss a face-up card in your grid for free without using an action."
				},
				dragonfly: {
					name: "Dragonfly",
					text: "Gain 1 fame per unique face-up adjacent toon."
				},
				bee: {
					name: "Bee",
					text: "This card generates 1 fame."
				},
				snail: {
					name: "Snail",
					text: "This card generates 2 fame."
				},
				mosquito: {
					name: "Mosquito",
					text: "This card generates no fame."
				},
				spider: {
					name: "Spider",
					text: "Gain 1 fame per card below this card in the same column, excluding its own stack."
				},
				grasshopper: {
					name: "Grasshopper",
					text: "Gain 1 fame per card above this card in the same column, excluding its own stack."
				},
				ladybug: {
					name: "Ladybug",
					text: "Adjacent cards cost 3 fame to dismiss instead of 5."
				},
				firefly: {
					name: "Firefly",
					text: "After scoring, gain 2 fame if you alone have the least fame. Ties do not qualify."
				},
				ostrich: {
					name: "Ostrich",
					text: "Stack the next revealed card on this card before resolving its ability. Do not draw an extra card from the last grid slot."
				},
				eagle: {
					name: "Eagle",
					text: "Flip the next placed card face down and ignore its ability unless it cannot be flipped. This card cannot be flipped."
				},
				donkey: {
					name: "Donkey",
					text: "If in the lower row, gain 5 fame and dismiss this card after your Market phase."
				},
				butterfly: {
					name: "Butterfly",
					text: "When hired, you may dismiss a face-up caterpillar in your grid for free."
				},
				dog: {
					name: "Dog",
					text: "Gain 5 fame if there is at least one dog in the market or another player's grid."
				},
				goat: {
					name: "Goat",
					text: "Gain 3 fame if in the upper row."
				},
				sheep: {
					name: "Sheep",
					text: "Gain 4 fame if in the middle column."
				},
				camel: {
					name: "Camel",
					text: "Gain 2 fame if no other player or the market has more camels than you. Ties qualify."
				},
				rabbit: {
					name: "Rabbit",
					text: "Stack this card on the first rabbit or face-down card in your grid if possible. This card cannot be flipped."
				},
				horse: {
					name: "Horse",
					text: "When hired, you may discard any number of market cards and reveal an equal number of replacements, then arrange them by rank. Do not fill other purchase gaps."
				},
				snake: {
					name: "Snake",
					text: "Dismiss the top card of your deck, then stack the top card of the toon deck on this card. An undismissable card is kept and placed normally."
				},
				elephant: {
					name: "Elephant",
					text: "Flip the previously placed card unless it cannot be flipped. This card cannot be flipped. Turning a card face up does not reactivate its ability."
				},
				rooster: {
					name: "Rooster",
					text: "Gain 1 fame per face-up card of rank 13 or lower in your grid, including this card."
				},
				cat: {
					name: "Cat",
					text: "Gain 1 fame per starting card in your dismissed cards. This card cannot be dismissed."
				},
				alligator: {
					name: "Alligator",
					text: "After your Market phase, dismiss one face-up card in the adjacent space to the right. Choose one card if that space is a stack."
				},
				lion: {
					name: "Lion",
					text: "Gain 4 fame if all face-up adjacent cards are rank 16 or lower."
				},
				monkey: {
					name: "Monkey",
					text: "If placed in the upper row, move this card to a new row above. Fill the vacated slot with the next card."
				},
				pig: {
					name: "Pig",
					text: "When hired or dismissed, place this card in any player's deck or shuffle it into the toon deck."
				},
				peacock: {
					name: "Peacock",
					text: "When hired, gain 2 fame and take a bonus Market action."
				},
				turkey: {
					name: "Turkey",
					text: "Stack this card on the previously placed card, if any."
				},
				bull: {
					name: "Bull",
					text: "Gain 7 fame if one or more cards in your grid are face down. This card cannot be flipped."
				},
				tiger: {
					name: "Tiger",
					text: "Gain 1 fame per card in your dismissed cards. This card cannot be dismissed."
				},
				deer: {
					name: "Deer",
					text: "Gain 5 fame if every face-up card in your grid is unique."
				},
				bear: {
					name: "Bear",
					text: "Gain 1 fame per face-up card in your grid, including this card."
				},
				cow: {
					name: "Cow",
					text: "Copy the fame of one adjacent card. You may choose any card in an adjacent stack."
				},
				salamander: {
					name: "Salamander",
					text: "If the next revealed card is rank 1 or lower, return it to the bottom of your deck and ignore its ability."
				},
				groundhog: {
					name: "Groundhog",
					text: "After your Market phase, dismiss this card if it is in the first or last slot of the original grid."
				},
				rat: {
					name: "Rat",
					text: "Stack this card on the previous card. Each face-up rat reduces the dismiss cost of cards in its stack by 1, to a minimum of 0."
				},
				goldfish: {
					name: "Goldfish",
					text: "Gain 1 fame per fish card in your grid, including this card. This card cannot be flipped."
				},
				mole: {
					name: "Mole",
					text: "If placed in the lower row, stack this card on the card above it."
				},
				hen: {
					name: "Hen",
					text: "Gain 1 fame per face-up card of rank 6 or higher in your grid, including this card."
				},
				starfish: {
					name: "Starfish",
					text: "Flip the previous card unless protected, then stack this card on it. This is a fish card and cannot be flipped."
				},
				raccoon: {
					name: "Raccoon",
					text: "When hired, you may hire any player's dismissed card for free."
				},
				panther: {
					name: "Panther",
					text: "Stack this card on the previous card. When hired, dismiss a face-up card in your grid for free."
				},
				opossum: {
					name: "Opossum",
					text: "Gain 2 fame per pair of identical dismissed cards. Each card counts in only one pair. This card cannot be dismissed."
				},
				mongoose: {
					name: "Mongoose",
					text: "Dismiss the bottom card of your deck unless protected, then add the top toon-deck card to the top of your deck without triggering its hire ability."
				},
				capybara: {
					name: "Capybara",
					text: "Gain 4 fame if at least three cards remain in your deck."
				},
				crow: {
					name: "Crow",
					text: "When dismissed, you may hire one market card for free, then refill the market immediately."
				},
				coyote: {
					name: "Coyote",
					text: "Return the previous card and place this card in its space; stack instead if that card cannot be returned. This card cannot be returned."
				},
				clownfish: {
					name: "Clownfish",
					text: "Gain 2 fame if adjacent to at least one fish card. This is a fish card and cannot be flipped."
				},
				fox: {
					name: "Fox",
					text: "Gain 3 fame if there is at least one hen or rooster in the market or any player's grid."
				},
				crab: {
					name: "Crab",
					text: "If placed in the middle column, return this card. If only crabs remain in your deck, end your Flip. This also applies in extra rows and stacks."
				},
				swordfish: {
					name: "Swordfish",
					text: "Flip the previous and next placed cards unless protected. This is a fish card and cannot be flipped."
				},
				gorilla: {
					name: "Gorilla",
					text: "If placed in the upper row, place the next revealed card in a new row above this card, above any existing cards there."
				},
				vulture: {
					name: "Vulture",
					text: "After your Market phase, dismiss the lowest-rank face-up card in your grid unless it is protected."
				},
				zebra: {
					name: "Zebra",
					text: "Return the lowest-rank face-up card in your grid and occupy its space; stack instead if it cannot be returned. This card cannot be returned."
				},
				shark: {
					name: "Shark",
					text: "Gain 1 fame per fish card in your grid. The shark is not a fish card and cannot be flipped."
				},
				rhinoceros: {
					name: "Rhinoceros",
					text: "Gain 3 fame per adjacent face-up card with an odd rank."
				},
				hippopotamus: {
					name: "Hippopotamus",
					text: "Gain 2 fame per card remaining in your deck."
				},
				sloth: {
					name: "Sloth",
					text: "Stack this card on the previous card. Gain 5 fame if your grid has at least eight cards."
				},
				axolotl: {
					name: "Axolotl",
					text: "When hired, turn your Big Button face up."
				},
				platypus: {
					name: "Platypus",
					text: "When hired, turn every Big Button face up. Gain 3 fame if your own Big Button is face down."
				}
			},
			name: "FlipToons",
			desc: "Build a cast of animated stars and find the perfect six-slot audition.",
			round: "Round {{n}}",
			final: "Final Flip",
			flip: "Casting the audition",
			famePhase: "Checking fame",
			market: "Casting market",
			yourTurn: "Your casting turn",
			waiting: "Waiting for {{name}}",
			fame: "Fame",
			actions: "{{n}} actions left",
			deck: "Deck · {{n}} cards",
			dismissed: "Dismissed · {{n}} cards",
			supply: "Toon deck · {{n}} cards",
			critic: "Critic’s Choice +3",
			grid: "Audition grid",
			hire: "Hire · {{n}} fame",
			dismiss: "Dismiss · {{n}} fame",
			pass: "End Market turn",
			choose: "Confirm choice",
			skip: "Skip ability",
			close: "Close",
			faceDown: "Face-down card",
			empty: "Empty slot",
			inspect: "Inspect card",
			seeDeck: "View your deck",
			seeDismissed: "View dismissed cards",
			details: "Card details",
			buttonReady: "Reset available",
			buttonSpent: "Reset used",
			resetGrid: "Reset this audition",
			resetMarket: "Reset market",
			keepGrid: "Keep this audition",
			buttonPrompt: "Choose whether to use your Big Button",
			chooseTarget: "Choose a deck for this card",
			toonDeck: "Toon deck",
			result: "This season’s winning cast",
			winner: "{{name}} wins the casting award",
			soloWin: "A star-making audition!",
			soloLoss: "The market has closed before your cast reached its goal.",
			review: "Review the cast",
			showResult: "Show awards",
			cancel: "Cancel",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			total: "Total fame",
			cardFame: "Generated {{n}} fame this round",
			bonus: "Critic’s bonus",
			chooseHorse: "Choose market cards to discard, then confirm. You may choose none.",
			optSeason: "Cast edition",
			base: "Original",
			season2: "Season 2",
			combined: "Original + Season 2 (up to 8 players)",
			optButton: "Big Button mini-expansion",
			optButton2: "Big Button 2 reset effect",
			off: "Off",
			gridReset: "Reset grid",
			marketReset: "Reset market",
			optDifficulty: "Solo difficulty",
			easy: "Easy",
			normal: "Normal",
			hard: "Hard",
			optSoloStart: "Combined solo starting deck",
			invalid: "That action is not available now.",
			emptyMarket: "Market sold out",
			chosen: "Selected",
			protectedFlip: "Cannot be flipped",
			protectedDismiss: "Cannot be dismissed",
			protectedReturn: "Cannot be returned",
			fish: "Fish",
			rank: "Rank {{n}}",
			fallbackName: "Blue studio",
			cleanup: "Preparing the next audition",
			choice: {
				skunk: "Skunk: dismiss a card for free.",
				butterfly: "Butterfly: you may dismiss a caterpillar for free.",
				horse: "Horse: choose market cards to replace.",
				pig: "Pig: choose a deck for this card.",
				raccoon: "Raccoon: you may hire a dismissed card for free.",
				panther: "Panther: dismiss a card for free.",
				crow: "Crow: you may hire a market card for free.",
				alligator: "Alligator: dismiss a card in the adjacent space to the right.",
				triggerOrder: "Choose which hire or dismiss ability to resolve first."
			},
			rules: "Objective:\nYou are casting an animated show. Shuffle your personal deck each round, reveal toons into a three-column, two-row audition grid, earn fame from their abilities, then spend that fame to improve your cast. In multiplayer, reaching 30 fame triggers a Final Flip. The most fame in the Final Flip wins. Fame does not carry between rounds.\nSetup:\n· The original starting deck contains two caterpillars, one skunk, one dragonfly, one bee and one snail. Season 2 contains two mosquitoes, one spider, one grasshopper, one ladybug and one firefly.\n· Shuffle the 53 toon cards and reveal five into the market, sorted by rank beneath prices of 3, 4, 7, 10 and 15 fame. Equal ranks retain their arrival order. The first-player marker passes clockwise each round.\n· Combining both games mixes their toon decks and uses seven prices: 3, 3, 4, 7, 10, 15 and 15. It supports up to eight players. Randomly assign either starting deck, using at most four of each. More than four players requires the combined edition.\nFlip:\nEveryone auditions simultaneously. Shuffle your deck, reveal one card at a time, and fill the top row from left to right, then the lower row. Resolve placement abilities before revealing the next card. If your deck runs out, leave any remaining spaces empty. The game presents placements and effects in steps. In the original edition, simultaneous abilities resolve from left to right, starting with the top row. In Season 2 and the combined edition, placement abilities resolve in reveal order. Within a stack, always start with the topmost card.\n· Adjacent spaces share an edge, never a corner. Cards in the same stack are not adjacent to each other, but all cards in a stack are adjacent to neighboring spaces. Each face-up stacked card retains its own name, rank, fame and abilities.\n· A face-down card occupies a space but has no name, rank, fame or abilities. Turning it face up does not reactivate placement abilities. Protected cards cannot be flipped.\n· Return means move a card to the bottom of its owner's deck. Dismiss means move it into that player's public dismissed pile. All dismissed piles can be examined. During the Market phase, you may examine your own deck; other players can only see its size.\n· A next-card ability affects only the next reveal, once. A card in the last grid space does not cause an extra reveal. A previous-card ability uses the last card added that is still in the grid.\n· For lowest rank, ignore face-down cards. Break equal ranks by the topmost row, then leftmost column, then topmost card in a stack. Extra rows do not change the original upper and lower rows.\n· Hire and dismiss effects triggered during the Flip resolve after everyone finishes flipping, starting with the first player. Cards added to the grid by a snake trigger applicable hire effects. A mongoose adds a card to the deck without triggering a hire effect.\nWhen multiple hire or dismiss abilities activate outside your grid at the same time, choose their order.\nCheck Fame:\nAdd each face-up card's fame as described on its card. A cow automatically copies the highest adjacent fame. A firefly rewards only the sole lowest-scoring player. A skunk's free dismissal also requires a sole lowest player. Ties do not qualify. Once calculated, fame stays fixed throughout the Market phase.\nIf anyone reaches 30 fame, the unique highest-scoring player receives Critic's Choice, worth 3 extra fame in the Final Flip. A tie for highest fame grants no award. Finish this round's Market phase before the Final Flip.\nMarket:\nStarting with the first player, each player takes up to two actions. You may take each action once or repeat one action, and may end your turn early.\n· Hire: spend the fame shown above a market card, add it to your deck, and resolve its hire effect immediately.\n· Dismiss: normally spend 5 fame to move a face-up card from your grid to your dismissed pile. Caterpillars, ladybugs and rats reduce this cost. Protected cards cannot be dismissed. You cannot dismiss any card, including through a free ability, with fewer than four cards in your grid and deck combined.\n· Free hires, free dismissals and bonus actions follow the card. A hired or dismissed pig must join a chosen player's deck or be shuffled into the toon deck. Optional abilities may be skipped; mandatory abilities must resolve if a legal target exists.\nAt the end of a Market turn, simultaneous grid abilities resolve from left to right, starting with the top row, and from the top of each stack. After each player's actions and end-of-turn abilities, refill and sort the market. If the toon deck is empty, do not refill; align remaining cards beneath the highest prices. If the market also empties, finish the round and proceed to the Final Flip.\nCleanup and winning:\n· Collect your grid into your deck. With one or two players in a single edition, or one to four players in the combined edition, discard the leftmost and rightmost market cards, then refill.\n· If the end has not triggered, pass the first-player marker and start the next round. Otherwise everyone shuffles, flips and scores once more without a Market phase.\n· The most fame in the Final Flip wins. If the highest score is tied, only those tied players shuffle, flip and score again until a winner is found. The critic's bonus continues to apply.\nSolo:\nReach 30 fame in one Check Fame phase before the toon deck can no longer fill the market. Reaching the target wins immediately, without a Final Flip.\n· The original solo deck contains three caterpillars, one dragonfly, one bee and one snail, without a skunk. Season 2 uses three mosquitoes, one spider, one grasshopper and one ladybug, without a firefly. Remove the pig from the toon deck.\n· After forming the initial market, discard 17, 20 or 23 toon cards for easy, normal or hard. In combined solo, discard 67, 70 or 73 and choose either solo starting deck.\n· Discard both market ends and refill each round. Failing to refill any market ends the game in a loss.\nMini-expansions:\n· Big Button is off by default. Add two axolotls and give each player a ready button. After each Check Fame, decide in first-player order whether to use it. Users turn their button face down, collect their grid, shuffle and flip again simultaneously; everyone then checks fame again. Hiring an axolotl readies your button.\n· Big Button 2 is off by default. Add two platypuses and choose Reset Grid or Reset Market. Reset Grid uses the timing above. Reset Market may only be used before any action on your Market turn: shuffle all market cards into the toon deck, then refill. Hiring a platypus readies every player's button.\n· If both expansions are enabled, each player shares one button and uses the effect selected for Big Button 2. In solo, discard two extra toon cards during setup for each enabled mini-expansion.",
			whenHired: "When hired",
			whenDismissed: "When dismissed",
			whenHiredDismissed: "When hired or dismissed",
			legend: "Rule icons"
		}
	}
};
//#endregion
export { Ye as default };
