import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useId as i, useImperativeHandle as a, useMemo as o, useRef as s, useState as c } from "react";
import { DeltaNumber as l } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { IconBack as f, IconBot as p, IconClose as m, IconExpand as h, IconLog as g, IconMirror as _, IconRotate as v } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as y } from "@bgparty/sdk/player-colors";
import { PhaseBanner as b } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as x, seatName as S } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as C } from "@bgparty/sdk/ui/game-screen";
import { useFxAnchor as w } from "@bgparty/sdk/fx/anchors";
import { Fragment as T, jsx as E, jsxs as D } from "react/jsx-runtime";
import { botAvatarOf as O } from "@bgparty/sdk/lobby";
import { botPersonality as k } from "@bgparty/sdk/bot-personality";
import { Floater as A } from "@bgparty/sdk/fx/primitives";
import { Confetti as ee } from "@bgparty/sdk/ui/confetti";
//#region src/games/frostedbloom/meta.ts
var j = {
	id: "frostedbloom",
	tier: "beta",
	mechanics: ["drafting", "tile-placement"],
	interactionTags: [],
	nameKey: "games.frostedbloom.name",
	descKey: "games.frostedbloom.desc",
	rulesKey: "games.frostedbloom.rules",
	icon: "🌷",
	iconImg: "games/frostedbloom.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/frostedbloom/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#eb825c",
	precacheAssets: [
		"meadow.webp",
		"pond.webp",
		"tulip-purple.webp",
		"tulip-red.webp",
		"tulip-white.webp",
		"imp-worker.webp",
		"imp-barn.webp",
		"imp-windmill.webp"
	],
	releasedAt: "2026-09-23",
	search: {
		py: "yu jin xiang zhuang yuan",
		init: "yjxzy"
	},
	hotseat: "cover"
}, M = t.int().min(-64).max(64), N = t.string(), P = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("take"),
		steps: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("place"),
		x: M,
		y: M,
		rot: t.int().min(0).max(3),
		flip: t.boolean()
	}),
	t.object({
		type: t.literal("playCard"),
		card: t.int().min(0).max(9)
	}),
	t.object({
		type: t.literal("claim"),
		keys: t.array(t.int().min(0).max(20)).max(7)
	})
]), F = t.object({
	t: t.int().min(-1).max(43),
	x: M,
	y: M,
	r: t.int().min(0).max(3),
	f: t.boolean()
}), I = t.object({
	k: t.enum([
		"worker",
		"barn",
		"windmill"
	]),
	cells: t.array(t.tuple([M, M])).min(1).max(4)
}), L = t.object({
	P: t.int().nonnegative(),
	R: t.int().nonnegative(),
	W: t.int().nonnegative(),
	"~": t.int().nonnegative()
}), R = t.object({
	rid: N,
	track: t.number(),
	imps: t.number(),
	objectives: t.number(),
	coins: t.number(),
	total: t.number()
}), z = t.object({
	phase: t.enum(["play", "done"]),
	round: t.int().min(1),
	turn: N,
	step: t.enum([
		"take",
		"place",
		"card",
		"claim"
	]),
	slots: t.array(t.int().min(-1).max(43)).length(6),
	token: t.int().min(0).max(5),
	slotCoins: t.array(t.int().nonnegative()).length(6),
	bagCount: t.int().nonnegative(),
	players: t.array(t.object({
		rid: N,
		score: t.number(),
		coins: t.number(),
		handCount: t.int().nonnegative(),
		board: t.array(F),
		imps: t.array(I),
		discards: t.array(t.int().min(0).max(9)),
		claimed: t.array(t.int().min(0).max(20))
	})),
	objectives: t.array(t.int().min(0).max(20)),
	current: t.int().min(0).max(43).nullable(),
	placed: F.nullable(),
	groups: L.nullable(),
	impThisTurn: t.boolean(),
	final: t.array(R).optional()
}), B = t.object({ hand: t.array(t.int().min(0).max(9)) }), V = [
	[
		[
			0,
			1,
			"R",
			3
		],
		[
			1,
			1,
			"P",
			1
		],
		[
			2,
			1,
			"W",
			2
		],
		[
			3,
			0,
			"~",
			0
		],
		[
			3,
			1,
			"~",
			0
		]
	],
	[
		[
			0,
			0,
			"P",
			2
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			3,
			0,
			"R",
			1
		],
		[
			4,
			0,
			"W",
			3
		]
	],
	[
		[
			0,
			0,
			"W",
			2
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"P",
			1
		],
		[
			2,
			2,
			"R",
			3
		]
	],
	[
		[
			0,
			1,
			"R",
			2
		],
		[
			1,
			1,
			"P",
			3
		],
		[
			2,
			1,
			"W",
			1
		],
		[
			3,
			0,
			"~",
			0
		],
		[
			3,
			1,
			"~",
			0
		]
	],
	[
		[
			0,
			1,
			"W",
			2
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"P",
			1
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			2,
			1,
			"R",
			3
		]
	],
	[
		[
			0,
			0,
			"~",
			0
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"R",
			3
		],
		[
			2,
			0,
			"P",
			1
		],
		[
			3,
			0,
			"W",
			2
		]
	],
	[
		[
			0,
			0,
			"~",
			0
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"R",
			2
		],
		[
			2,
			0,
			"P",
			3
		],
		[
			3,
			0,
			"W",
			1
		]
	],
	[
		[
			0,
			0,
			"~",
			0
		],
		[
			0,
			1,
			"W",
			1
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"P",
			3
		],
		[
			2,
			1,
			"R",
			2
		]
	],
	[
		[
			0,
			0,
			"P",
			3
		],
		[
			1,
			0,
			"W",
			1
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			2,
			1,
			"~",
			0
		],
		[
			3,
			1,
			"R",
			2
		]
	],
	[
		[
			0,
			0,
			"R",
			2
		],
		[
			0,
			1,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			2,
			0,
			"W",
			1
		],
		[
			2,
			1,
			"P",
			3
		]
	],
	[
		[
			0,
			0,
			"P",
			2
		],
		[
			1,
			0,
			"W",
			3
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			2,
			1,
			"~",
			0
		],
		[
			3,
			1,
			"R",
			1
		]
	],
	[
		[
			0,
			0,
			"P",
			1
		],
		[
			0,
			1,
			"R",
			3
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"~",
			0
		],
		[
			2,
			1,
			"W",
			2
		]
	],
	[
		[
			0,
			0,
			"P",
			3
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			3,
			0,
			"R",
			2
		],
		[
			4,
			0,
			"W",
			1
		]
	],
	[
		[
			0,
			0,
			"R",
			3
		],
		[
			0,
			1,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"W",
			2
		],
		[
			2,
			2,
			"P",
			1
		]
	],
	[
		[
			0,
			0,
			"R",
			1
		],
		[
			0,
			1,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"W",
			3
		],
		[
			2,
			2,
			"P",
			2
		]
	],
	[
		[
			0,
			0,
			"P",
			2
		],
		[
			0,
			1,
			"R",
			1
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"~",
			0
		],
		[
			2,
			1,
			"W",
			3
		]
	],
	[
		[
			0,
			1,
			"R",
			1
		],
		[
			1,
			1,
			"P",
			2
		],
		[
			2,
			1,
			"W",
			3
		],
		[
			3,
			0,
			"~",
			0
		],
		[
			3,
			1,
			"~",
			0
		]
	],
	[
		[
			0,
			0,
			"R",
			2
		],
		[
			0,
			1,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"W",
			2
		],
		[
			2,
			2,
			"P",
			2
		]
	],
	[
		[
			0,
			0,
			"W",
			2
		],
		[
			0,
			1,
			"R",
			2
		],
		[
			0,
			2,
			"P",
			2
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			2,
			1,
			"~",
			0
		]
	],
	[
		[
			0,
			0,
			"R",
			3
		],
		[
			0,
			1,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			2,
			0,
			"W",
			2
		],
		[
			2,
			1,
			"P",
			1
		]
	],
	[
		[
			0,
			0,
			"W",
			3
		],
		[
			0,
			1,
			"R",
			1
		],
		[
			0,
			2,
			"P",
			2
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			2,
			1,
			"~",
			0
		]
	],
	[
		[
			0,
			0,
			"P",
			3
		],
		[
			0,
			1,
			"R",
			2
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"~",
			0
		],
		[
			2,
			1,
			"W",
			1
		]
	],
	[
		[
			0,
			0,
			"W",
			2
		],
		[
			0,
			1,
			"R",
			3
		],
		[
			0,
			2,
			"P",
			1
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			2,
			1,
			"~",
			0
		]
	],
	[
		[
			0,
			0,
			"R",
			2
		],
		[
			0,
			1,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"W",
			1
		],
		[
			2,
			2,
			"P",
			3
		]
	],
	[
		[
			0,
			2,
			"P",
			1
		],
		[
			1,
			2,
			"~",
			0
		],
		[
			2,
			0,
			"R",
			3
		],
		[
			2,
			1,
			"W",
			2
		],
		[
			2,
			2,
			"~",
			0
		]
	],
	[
		[
			0,
			2,
			"P",
			2
		],
		[
			1,
			2,
			"~",
			0
		],
		[
			2,
			0,
			"R",
			1
		],
		[
			2,
			1,
			"W",
			3
		],
		[
			2,
			2,
			"~",
			0
		]
	],
	[
		[
			0,
			1,
			"W",
			3
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"P",
			2
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			2,
			1,
			"R",
			1
		]
	],
	[
		[
			0,
			0,
			"W",
			1
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"P",
			3
		],
		[
			2,
			2,
			"R",
			2
		]
	],
	[
		[
			0,
			0,
			"P",
			2
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			3,
			0,
			"R",
			2
		],
		[
			4,
			0,
			"W",
			2
		]
	],
	[
		[
			0,
			1,
			"W",
			2
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"P",
			2
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			2,
			1,
			"R",
			2
		]
	],
	[
		[
			0,
			0,
			"W",
			2
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"P",
			2
		],
		[
			2,
			2,
			"R",
			2
		]
	],
	[
		[
			0,
			0,
			"P",
			1
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			3,
			0,
			"R",
			3
		],
		[
			4,
			0,
			"W",
			2
		]
	],
	[
		[
			0,
			0,
			"~",
			0
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"R",
			2
		],
		[
			2,
			0,
			"P",
			2
		],
		[
			3,
			0,
			"W",
			2
		]
	],
	[
		[
			0,
			0,
			"P",
			2
		],
		[
			0,
			1,
			"R",
			2
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"~",
			0
		],
		[
			2,
			1,
			"W",
			2
		]
	],
	[
		[
			0,
			1,
			"R",
			2
		],
		[
			1,
			1,
			"P",
			2
		],
		[
			2,
			1,
			"W",
			2
		],
		[
			3,
			0,
			"~",
			0
		],
		[
			3,
			1,
			"~",
			0
		]
	],
	[
		[
			0,
			0,
			"R",
			2
		],
		[
			0,
			1,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			2,
			0,
			"W",
			2
		],
		[
			2,
			1,
			"P",
			2
		]
	],
	[
		[
			0,
			0,
			"R",
			1
		],
		[
			0,
			1,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			2,
			0,
			"W",
			3
		],
		[
			2,
			1,
			"P",
			2
		]
	],
	[
		[
			0,
			0,
			"W",
			1
		],
		[
			0,
			1,
			"R",
			2
		],
		[
			0,
			2,
			"P",
			3
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			2,
			1,
			"~",
			0
		]
	],
	[
		[
			0,
			2,
			"P",
			2
		],
		[
			1,
			2,
			"~",
			0
		],
		[
			2,
			0,
			"R",
			2
		],
		[
			2,
			1,
			"W",
			2
		],
		[
			2,
			2,
			"~",
			0
		]
	],
	[
		[
			0,
			0,
			"W",
			3
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"~",
			0
		],
		[
			1,
			2,
			"P",
			2
		],
		[
			2,
			2,
			"R",
			1
		]
	],
	[
		[
			0,
			0,
			"~",
			0
		],
		[
			1,
			0,
			"~",
			0
		],
		[
			1,
			1,
			"R",
			1
		],
		[
			2,
			0,
			"P",
			2
		],
		[
			3,
			0,
			"W",
			3
		]
	],
	[
		[
			0,
			2,
			"P",
			3
		],
		[
			1,
			2,
			"~",
			0
		],
		[
			2,
			0,
			"R",
			2
		],
		[
			2,
			1,
			"W",
			1
		],
		[
			2,
			2,
			"~",
			0
		]
	],
	[
		[
			0,
			0,
			"P",
			1
		],
		[
			1,
			0,
			"W",
			2
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			2,
			1,
			"~",
			0
		],
		[
			3,
			1,
			"R",
			3
		]
	],
	[
		[
			0,
			0,
			"P",
			2
		],
		[
			1,
			0,
			"W",
			2
		],
		[
			2,
			0,
			"~",
			0
		],
		[
			2,
			1,
			"~",
			0
		],
		[
			3,
			1,
			"R",
			2
		]
	]
], H = [
	[
		1,
		0,
		"~",
		0
	],
	[
		0,
		1,
		"W",
		2
	],
	[
		1,
		1,
		"~",
		0
	],
	[
		2,
		1,
		"R",
		2
	],
	[
		1,
		2,
		"P",
		2
	]
];
function U(e, t, n) {
	let r = (typeof e == "number" ? V[e] : e).map((e) => [
		e[0],
		e[1],
		e[2],
		e[3]
	]);
	if (n) {
		let e = Math.max(...r.map((e) => e[0])) + 1;
		r = r.map(([t, n, r, i]) => [
			e - 1 - t,
			n,
			r,
			i
		]);
	}
	for (let e = 0; e < t; e++) {
		let e = Math.max(...r.map((e) => e[1])) + 1;
		r = r.map(([t, n, r, i]) => [
			e - 1 - n,
			t,
			r,
			i
		]);
	}
	return r;
}
var W = [
	{ elems: ["P"] },
	{ elems: ["R"] },
	{ elems: ["W"] },
	{ elems: ["~"] },
	{ elems: ["P", "R"] },
	{ elems: ["P", "W"] },
	{ elems: ["P", "~"] },
	{ elems: ["R", "W"] },
	{ elems: ["R", "~"] },
	{ elems: ["W", "~"] }
], te = [
	"P",
	"R",
	"W",
	"~",
	"worker",
	"barn",
	"windmill"
], G = {
	P: [
		6,
		8,
		10
	],
	R: [
		6,
		8,
		10
	],
	W: [
		6,
		8,
		10
	],
	"~": [
		6,
		8,
		10
	],
	worker: [
		3,
		4,
		5
	],
	barn: [
		2,
		3,
		4
	],
	windmill: [
		1,
		2,
		3
	]
}, K = te.flatMap((e) => G[e].map((t, n) => ({
	type: e,
	tier: n,
	need: t,
	points: [
		3,
		10,
		25
	][n]
}))), q = {
	worker: 3,
	barn: 10,
	windmill: 25
}, J = (e) => 2 * e + 4, Y = [
	1,
	2,
	3,
	4
], X = [
	[1, 0],
	[-1, 0],
	[0, 1],
	[0, -1]
], Z = (e, t) => `${e},${t}`;
function Q(e) {
	return U(e.t < 0 ? H : e.t, e.r, e.f).map(([t, n, r, i]) => ({
		x: e.x + t,
		y: e.y + n,
		e: r,
		n: i
	}));
}
function ne(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let t of e) for (let e of Q(t)) n.add(Z(e.x, e.y));
	for (let e of t) for (let [t, r] of e.cells) n.add(Z(t, r));
	return n;
}
function re(e, t, n, r, i) {
	let a = ne(e, t), o = /* @__PURE__ */ new Set();
	for (let t of e) for (let e of Q(t)) o.add(Z(e.x, e.y));
	let s = !1;
	for (let [e, t] of n) {
		let n = r + e, c = i + t;
		if (a.has(Z(n, c))) return !1;
		if (!s) {
			for (let [e, t] of X) if (o.has(Z(n + e, c + t))) {
				s = !0;
				break;
			}
		}
	}
	return s;
}
function ie(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) for (let e of Q(t)) n.set(Z(e.x, e.y), {
		e: e.e,
		n: e.n
	});
	let r = Q(t), i = {
		P: 0,
		R: 0,
		W: 0,
		"~": 0
	};
	for (let e of [
		"P",
		"R",
		"W",
		"~"
	]) {
		let t = /* @__PURE__ */ new Set(), a = r.filter((t) => t.e === e).map((e) => Z(e.x, e.y)), o = 0;
		for (; a.length;) {
			let r = a.pop();
			if (t.has(r)) continue;
			t.add(r);
			let i = n.get(r);
			if (!i || i.e !== e) continue;
			o += e === "~" ? 1 : i.n;
			let [s, c] = r.split(",").map(Number);
			for (let [e, t] of X) a.push(Z(s + e, c + t));
		}
		i[e] = o;
	}
	return i;
}
function ae(e, t, n) {
	let r = ne(e, t), i = Infinity, a = Infinity, o = -Infinity, s = -Infinity;
	for (let t of e) for (let e of Q(t)) i = Math.min(i, e.x), a = Math.min(a, e.y), o = Math.max(o, e.x), s = Math.max(s, e.y);
	--i, --a, o += 1, s += 1;
	let c = [], l = /* @__PURE__ */ new Set();
	for (let [e, t] of n) for (let [n, u] of X) {
		let d = Z(e + n, t + u);
		if (r.has(d) || l.has(d)) continue;
		let f = [], p = /* @__PURE__ */ new Set([d]), m = [[e + n, t + u]], h = !1;
		for (; m.length && !h;) {
			let [e, t] = m.pop();
			f.push([e, t]);
			for (let [n, c] of X) {
				let l = e + n, u = t + c;
				if (l < i || l > o || u < a || u > s) {
					h = !0;
					break;
				}
				let d = Z(l, u);
				!r.has(d) && !p.has(d) && (p.add(d), m.push([l, u]));
			}
		}
		for (let e of f) l.add(Z(e[0], e[1]));
		!h && f.length <= 4 && c.push(f);
	}
	return c;
}
function oe(e) {
	let t = [...e].sort((e, t) => e[1] - t[1] || e[0] - t[0]), n = (e, t) => Math.abs(e[0] - t[0]) + Math.abs(e[1] - t[1]) === 1;
	if (t.length === 1) return [{
		k: "worker",
		cells: [t[0]]
	}];
	if (t.length === 2) return [{
		k: "barn",
		cells: t
	}];
	if (t.length === 4 && new Set(t.map((e) => e[0])).size === 2 && new Set(t.map((e) => e[1])).size === 2) return [{
		k: "windmill",
		cells: t
	}];
	let r = (e) => {
		for (let r = 0; r < t.length; r++) for (let i = r + 1; i < t.length; i++) if (n(t[r], t[i])) {
			let a = t.filter((e, t) => t !== r && t !== i);
			if (!e || n(a[0], a[1])) return [t[r], t[i]];
		}
		return [t[0], t[1]];
	};
	if (t.length === 3) {
		let e = r(!1), n = t.find((t) => !e.includes(t));
		return [{
			k: "barn",
			cells: e
		}, {
			k: "worker",
			cells: [n]
		}];
	}
	let i = t.map((e) => t.filter((t) => n(e, t)).length);
	if (Math.max(...i) === 3) {
		let e = r(!1), n = t.filter((t) => !e.includes(t));
		return [{
			k: "barn",
			cells: e
		}, ...n.map((e) => ({
			k: "worker",
			cells: [e]
		}))];
	}
	let a = r(!0);
	return [{
		k: "barn",
		cells: a
	}, {
		k: "barn",
		cells: t.filter((e) => !a.includes(e))
	}];
}
function se(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r.c, i + 1);
		r.c += 1, [t[i], t[a]] = [t[a], t[i]];
	}
	return t;
}
function ce(t, n, r) {
	let i = { c: 0 }, a = se(Array.from({ length: V.length }, (e, t) => t), r, i), o = se(Array.from({ length: K.length }, (e, t) => t), r, i).slice(0, J(n.length)), s = {}, c = {}, l = {}, u = {}, d = {}, f = {}, p = {}, m = {};
	n.forEach((e) => {
		let t = se(Array.from({ length: W.length }, (e, t) => t), r, i);
		s[e] = t.slice(0, 3), c[e] = t.slice(3), l[e] = [], u[e] = [{
			t: -1,
			x: 0,
			y: 0,
			r: 0,
			f: !1
		}], d[e] = [], p[e] = 0, m[e] = [];
	});
	let h = e(r, i.c, n.length);
	return n.forEach((e, t) => {
		f[n[(h + t) % n.length]] = Y[t];
	}), { state: {
		players: n,
		phase: "play",
		round: 1,
		turnIdx: h,
		step: "take",
		slots: [-1, ...Array.from({ length: 5 }, () => a.pop())],
		token: 0,
		slotCoins: Array.from({ length: 6 }, () => 0),
		bag: a,
		hands: s,
		decks: c,
		discards: l,
		boards: u,
		imps: d,
		coins: f,
		scores: p,
		objectives: o,
		claimed: m,
		current: null,
		placed: null,
		groups: null,
		impThisTurn: !1
	} };
}
function le(e) {
	let t = [];
	for (let n = 1; n < 6; n++) {
		let r = (e.token + n) % 6;
		e.slots[r] >= 0 && t.push(r);
	}
	return t;
}
function ue(e, t) {
	let n = e.imps[t].reduce((e, t) => e + q[t.k], 0), r = e.claimed[t].reduce((e, t) => e + K[t].points, 0);
	return {
		rid: t,
		track: e.scores[t],
		imps: n,
		objectives: r,
		coins: e.coins[t],
		total: e.scores[t] + n + r + e.coins[t]
	};
}
function de(e, t, n) {
	return e.claimed[t].some((e) => K[e].type === n.type) ? !1 : n.type === "worker" || n.type === "barn" || n.type === "windmill" ? e.impThisTurn && e.imps[t].filter((e) => e.k === n.type).length >= n.need : !!e.groups && e.groups[n.type] >= n.need;
}
function fe(e) {
	e.current = null, e.placed = null, e.groups = null, e.impThisTurn = !1, e.turnIdx += 1, e.turnIdx === e.players.length && (e.turnIdx = 0, e.round += 1), e.round > 10 ? e.phase = "done" : e.step = "take";
}
function pe(e, t, n) {
	if (e.phase !== "play" || n.by !== e.players[e.turnIdx]) return { code: "games.frostedbloom.errNotYourTurn" };
	if (t.type === "take") {
		if (e.step !== "take") return { code: "games.frostedbloom.errNotYourTurn" };
		let r = le(e);
		if (t.steps >= r.length) return { code: "games.frostedbloom.errNoTile" };
		if (t.steps > e.coins[n.by]) return { code: "games.frostedbloom.errNoCoins" };
		let i = structuredClone(e), a = r[t.steps];
		for (let e of r.slice(0, t.steps)) i.slotCoins[e] += 1, --i.coins[n.by];
		let o = i.slotCoins[a];
		return i.coins[n.by] += o, i.slotCoins[a] = 0, i.current = i.slots[a], i.slots[a] = -1, i.bag.length > 0 && (i.slots[i.token] = i.bag.pop()), i.token = a, i.step = "place", {
			state: i,
			fx: [{
				kind: "take",
				rid: n.by,
				data: {
					steps: t.steps,
					gained: o
				}
			}]
		};
	}
	if (t.type === "place") {
		if (e.step !== "place" || e.current === null) return { code: "games.frostedbloom.errNotYourTurn" };
		let r = U(e.current, t.rot, t.flip);
		if (!re(e.boards[n.by], e.imps[n.by], r, t.x, t.y)) return { code: "games.frostedbloom.errBadPlacement" };
		let i = e.current, a = structuredClone(e), o = {
			t: i,
			x: t.x,
			y: t.y,
			r: t.rot,
			f: t.flip
		};
		a.boards[n.by].push(o), a.placed = o, a.groups = ie(a.boards[n.by], o);
		let s = r.map(([e, n]) => [t.x + e, t.y + n]), c = 0, l = 0, u = 0;
		for (let e of ae(a.boards[n.by], a.imps[n.by], s)) for (let t of oe(e)) a.imps[n.by].push(t), t.k === "worker" ? c += 1 : t.k === "barn" ? l += 1 : u += 1;
		a.coins[n.by] += c, a.impThisTurn = c + l + u > 0, a.step = a.hands[n.by].length > 0 ? "card" : "claim";
		let d = [{
			kind: "place",
			rid: n.by,
			data: { t: o.t }
		}];
		return c + l + u > 0 && d.push({
			kind: "fill",
			rid: n.by,
			data: {
				workers: c,
				barns: l,
				windmills: u
			},
			with: !0
		}), {
			state: a,
			fx: d
		};
	}
	if (t.type === "playCard") {
		if (e.step !== "card" || !e.groups) return { code: "games.frostedbloom.errNotYourTurn" };
		if (!e.hands[n.by].includes(t.card)) return { code: "games.frostedbloom.errBadCard" };
		let r = structuredClone(e), i = W[t.card], a = i.elems.reduce((e, t) => e + r.groups[t] * (i.elems.length === 1 ? 2 : 1), 0);
		return r.scores[n.by] += a, r.hands[n.by].splice(r.hands[n.by].indexOf(t.card), 1), r.discards[n.by].push(t.card), r.decks[n.by].length > 0 && r.hands[n.by].push(r.decks[n.by].pop()), r.step = "claim", {
			state: r,
			fx: [{
				kind: "card",
				rid: n.by,
				data: {
					n: a,
					card: t.card
				}
			}]
		};
	}
	if (e.step !== "claim") return { code: "games.frostedbloom.errNotYourTurn" };
	let r = [...new Set(t.keys)];
	for (let t of r) if (!e.objectives.includes(t) || !de(e, n.by, K[t])) return { code: "games.frostedbloom.errBadClaim" };
	let i = structuredClone(e), a = 0;
	for (let e of r) i.objectives.splice(i.objectives.indexOf(e), 1), i.claimed[n.by].push(e), a += K[e].points;
	fe(i);
	let o = [];
	return r.length > 0 && o.push({
		kind: "claim",
		rid: n.by,
		data: {
			n: a,
			count: r.length
		}
	}), {
		state: i,
		fx: o
	};
}
function me(e, t) {
	let n = {
		phase: e.phase,
		round: Math.min(e.round, 10),
		turn: e.players[e.turnIdx],
		step: e.step,
		slots: e.slots,
		token: e.token,
		slotCoins: e.slotCoins,
		bagCount: e.bag.length,
		players: e.players.map((t) => ({
			rid: t,
			score: e.scores[t],
			coins: e.coins[t],
			handCount: e.hands[t].length,
			board: e.boards[t],
			imps: e.imps[t],
			discards: e.discards[t],
			claimed: e.claimed[t]
		})),
		objectives: e.objectives,
		current: e.current,
		placed: e.placed,
		groups: e.groups,
		impThisTurn: e.impThisTurn
	};
	return e.phase === "done" && (n.final = e.players.map((t) => ue(e, t))), {
		public: n,
		private: { hand: e.hands[t] ?? [] }
	};
}
function he(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.map((t) => ue(e, t)), n = {};
	for (let e of t) n[e.rid] = e.total;
	let r = [...e.players].sort((n, r) => {
		let i = t.find((e) => e.rid === n), a = t.find((e) => e.rid === r);
		return a.total - i.total || a.coins - i.coins || e.players.indexOf(n) - e.players.indexOf(r);
	}), i = t.find((e) => e.rid === r[0]);
	return {
		phase: "done",
		winner: t.filter((e) => e.total === i.total && e.coins === i.coins).map((e) => e.rid),
		ranking: r,
		scores: n
	};
}
var ge = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: j,
	schemas: {
		action: P,
		publicView: z,
		privateView: B
	},
	setup: ce,
	reduce: pe,
	viewFor: me,
	status: he
}, $ = "./games/frostedbloom/", _e = {
	P: `${$}tulip-purple.webp`,
	R: `${$}tulip-red.webp`,
	W: `${$}tulip-white.webp`
}, ve = {
	1: [[
		.5,
		.5,
		.86
	]],
	2: [[
		.32,
		.37,
		.65
	], [
		.68,
		.64,
		.65
	]],
	3: [
		[
			.5,
			.27,
			.56
		],
		[
			.25,
			.69,
			.56
		],
		[
			.76,
			.69,
			.56
		]
	]
};
function ye({ elem: e, size: t }) {
	let n = t / 2;
	return /* @__PURE__ */ D("svg", {
		viewBox: `0 0 ${t} ${t}`,
		style: {
			width: t,
			height: t
		},
		"aria-hidden": !0,
		children: [/* @__PURE__ */ E("circle", {
			cx: n,
			cy: n,
			r: n - 1,
			fill: e === "~" ? "#79dce0" : "#e7f2ba",
			stroke: "#5b865e",
			strokeWidth: Math.max(1, t / 14)
		}), e === "~" ? /* @__PURE__ */ E("path", {
			d: `M ${t * .2} ${t * .42} q ${t * .15} ${-t * .15} ${t * .3} 0 t ${t * .3} 0 M ${t * .28} ${t * .65} q ${t * .15} ${-t * .13} ${t * .3} 0`,
			fill: "none",
			stroke: "#fffef1",
			strokeWidth: Math.max(1.2, t / 11),
			strokeLinecap: "round"
		}) : /* @__PURE__ */ E("image", {
			href: _e[e],
			x: t * .12,
			y: t * .08,
			width: t * .76,
			height: t * .76
		})]
	});
}
function be({ cell: e, size: t, meadow: n, water: r }) {
	let [i, a, o, s] = e;
	return /* @__PURE__ */ D("g", {
		transform: `translate(${i * t}, ${a * t})`,
		children: [
			/* @__PURE__ */ E("rect", {
				x: 0,
				y: t * .07,
				width: t,
				height: t,
				rx: t * .025,
				fill: "#a4a06b"
			}),
			/* @__PURE__ */ E("rect", {
				width: t,
				height: t,
				rx: t * .025,
				fill: `url(#${o === "~" ? r : n})`
			}),
			/* @__PURE__ */ E("rect", {
				width: t,
				height: t,
				rx: t * .025,
				fill: o === "~" ? "#b7f1e5" : "#fff4b9",
				opacity: o === "~" ? .2 : .16
			}),
			o === "~" && /* @__PURE__ */ E("path", {
				d: `M ${t * .14} ${t * .39} q ${t * .18} ${-t * .13} ${t * .36} 0 t ${t * .36} 0 M ${t * .2} ${t * .7} q ${t * .15} ${-t * .12} ${t * .3} 0 t ${t * .3} 0`,
				fill: "none",
				stroke: "#e7fffb",
				strokeWidth: Math.max(.7, t / 34),
				strokeLinecap: "round",
				opacity: .8
			}),
			o !== "~" && /* @__PURE__ */ D(T, { children: [/* @__PURE__ */ E("ellipse", {
				cx: t * .5,
				cy: t * .53,
				rx: t * .42,
				ry: t * .38,
				fill: "#edf2a4",
				opacity: .38
			}), ve[s].map(([e, n, r], i) => /* @__PURE__ */ E("image", {
				href: _e[o],
				x: (e - r / 2) * t,
				y: (n - r / 2) * t,
				width: r * t,
				height: r * t
			}, i))] })
		]
	});
}
function xe(e, t) {
	let n = new Set(e.map(([e, t]) => `${e},${t}`));
	return e.map(([e, r]) => {
		let i = e * t, a = r * t;
		return `${n.has(`${e},${r - 1}`) ? "" : `M${i},${a}h${t}`}${n.has(`${e + 1},${r}`) ? "" : `M${i + t},${a}v${t}`}${n.has(`${e},${r + 1}`) ? "" : `M${i},${a + t}h${t}`}${n.has(`${e - 1},${r}`) ? "" : `M${i},${a}v${t}`}`;
	}).join("");
}
function Se({ cells: e, cell: t }) {
	let n = i().replace(/:/g, ""), r = `${n}-meadow`, a = `${n}-water`, o = t * 3, s = xe([...e], t);
	return /* @__PURE__ */ D("g", { children: [
		/* @__PURE__ */ D("defs", { children: [/* @__PURE__ */ E("pattern", {
			id: r,
			patternUnits: "userSpaceOnUse",
			width: o,
			height: o,
			children: /* @__PURE__ */ E("image", {
				href: `${$}meadow.webp`,
				width: o,
				height: o
			})
		}), /* @__PURE__ */ E("pattern", {
			id: a,
			patternUnits: "userSpaceOnUse",
			width: o,
			height: o,
			children: /* @__PURE__ */ E("image", {
				href: `${$}pond.webp`,
				width: o,
				height: o
			})
		})] }),
		e.map((e, n) => /* @__PURE__ */ E(be, {
			cell: e,
			size: t,
			meadow: r,
			water: a
		}, n)),
		/* @__PURE__ */ E("path", {
			d: s,
			fill: "none",
			stroke: "#fff3c9",
			strokeWidth: Math.max(1.3, t / 15),
			strokeLinejoin: "round",
			pointerEvents: "none"
		}),
		/* @__PURE__ */ E("path", {
			d: s,
			fill: "none",
			stroke: "#668451",
			strokeWidth: Math.max(.6, t / 35),
			strokeLinejoin: "round",
			pointerEvents: "none"
		})
	] });
}
function Ce(e, t, n) {
	let r = U(e, t, n);
	return {
		w: Math.max(...r.map((e) => e[0])) + 1,
		h: Math.max(...r.map((e) => e[1])) + 1,
		cells: r
	};
}
function we({ tid: e, maxSize: t, fluid: n = !1 }) {
	let { w: r, h: i, cells: a } = Ce(e, 0, !1), o = Math.min(t / Math.max(r, i), 22);
	return /* @__PURE__ */ E("svg", {
		viewBox: `-2 -2 ${r * o + 4} ${i * o + 4}`,
		className: n ? "fbv-market-art" : void 0,
		style: n ? void 0 : {
			width: r * o + 4,
			height: i * o + 4
		},
		"aria-hidden": !0,
		children: /* @__PURE__ */ E(Se, {
			cells: a,
			cell: o
		})
	});
}
function Te({ kind: e, size: t }) {
	return /* @__PURE__ */ E("svg", {
		viewBox: "0 0 256 256",
		style: {
			width: t,
			height: t
		},
		"aria-hidden": !0,
		children: /* @__PURE__ */ E("image", {
			href: `${$}imp-${e}.webp`,
			width: 256,
			height: 256
		})
	});
}
function Ee({ card: e, w: t, h: n, score: r }) {
	let i = e.elems.length === 1, a = r === void 0 ? 0 : n * .24, o = n - a;
	return /* @__PURE__ */ D("svg", {
		viewBox: `0 0 ${t} ${n}`,
		style: {
			width: "100%",
			height: "100%"
		},
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ E("rect", {
				x: 1.5,
				y: 1.5,
				width: t - 3,
				height: n - 3,
				rx: t * .08,
				fill: "var(--color-surface)",
				className: "stroke-ink",
				strokeWidth: 2
			}),
			i ? /* @__PURE__ */ D("g", { children: [/* @__PURE__ */ E("g", {
				transform: `translate(${t * .07}, ${o / 2 - t * .2})`,
				children: /* @__PURE__ */ E(ye, {
					elem: e.elems[0],
					size: t * .4
				})
			}), /* @__PURE__ */ E("text", {
				x: t * .72,
				y: o / 2,
				textAnchor: "middle",
				dominantBaseline: "central",
				fontSize: t * .26,
				fontWeight: 800,
				fill: "var(--color-ink)",
				fontFamily: "monospace",
				children: "×2"
			})] }) : /* @__PURE__ */ E("g", { children: e.elems.map((e, n) => /* @__PURE__ */ D("g", { children: [/* @__PURE__ */ E("g", {
				transform: `translate(${t * .12}, ${o * (.28 + n * .44) - t * .14})`,
				children: /* @__PURE__ */ E(ye, {
					elem: e,
					size: t * .28
				})
			}), /* @__PURE__ */ E("text", {
				x: t * .68,
				y: o * (.28 + n * .44),
				textAnchor: "middle",
				dominantBaseline: "central",
				fontSize: t * .18,
				fontWeight: 800,
				fill: "var(--color-ink)",
				fontFamily: "monospace",
				children: "×1"
			})] }, n)) }),
			r !== void 0 && /* @__PURE__ */ D("g", { children: [/* @__PURE__ */ E("path", {
				d: `M 1.5 ${n - a} H ${t - 1.5} V ${n - t * .08 - 1.5} Q ${t - 1.5} ${n - 1.5} ${t - t * .08 - 1.5} ${n - 1.5} H ${t * .08 + 1.5} Q 1.5 ${n - 1.5} 1.5 ${n - t * .08 - 1.5} Z`,
				fill: "var(--color-done-soft)",
				className: "stroke-ink",
				strokeWidth: 2
			}), /* @__PURE__ */ D("text", {
				x: t / 2,
				y: n - a * .28,
				textAnchor: "middle",
				fontSize: t * .22,
				fontWeight: 800,
				fill: "var(--color-ink)",
				fontFamily: "monospace",
				children: ["+", r]
			})] })
		]
	});
}
function De(e) {
	return e.w >= 800 && e.h >= 480 ? 4 : e.w >= 600 && e.h >= 350 ? 3 : 1.6;
}
function Oe(e, t, n) {
	let r = [], i = [];
	for (let t of e) for (let e of U(t.t < 0 ? H : t.t, t.r, t.f)) r.push(t.x + e[0]), i.push(t.y + e[1]);
	for (let e of t) for (let [t, n] of e.cells) r.push(t), i.push(n);
	if (r.length === 0 || n.w === 0) return {
		cx: 0,
		cy: 0,
		s: 1
	};
	let a = De(n), o = a > 1.6 ? 1 : 1.6, s = (Math.min(...r) - o) * 40, c = (Math.max(...r) + o + 1) * 40, l = (Math.min(...i) - o) * 40, u = (Math.max(...i) + o + 1) * 40, d = a > 1.6 ? 48 : 0, f = Math.min(n.w / (c - s), (n.h - d) / (u - l), a);
	return {
		cx: (s + c) / 2,
		cy: (l + u) / 2 - d / (2 * f),
		s: f
	};
}
function ke({ board: e, imps: t, ghost: n, ghostValid: i, placed: l, fitKey: u, onTap: d, onGhostDragStart: f, onGhostDrag: p, controls: m, label: h, scoreLabel: g, placementLabel: _, viewRid: v, handleRef: y }) {
	let { ref: b } = w(`garden:${v}`), x = s(null), [S, C] = c({
		w: 0,
		h: 0
	}), [T, O] = c(null), k = s({
		cx: 0,
		cy: 0,
		s: 1
	}), [A, ee] = c(null), [j, M] = c({
		w: 0,
		h: 0
	});
	r(() => {
		if (!A) return;
		let e = new ResizeObserver(() => M({
			w: A.offsetWidth,
			h: A.offsetHeight
		}));
		return e.observe(A), () => e.disconnect();
	}, [A]), r(() => {
		let e = x.current, t = new ResizeObserver(() => C({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let N = `${u}:${S.w}:${S.h}`, [P, F] = c("");
	P !== N && S.w > 0 && (F(N), O(Oe(e, t, S)));
	let I = T ?? Oe(e, t, S);
	r(() => {
		k.current = I;
	}), a(y, () => ({ cellAt(e, t) {
		let n = x.current;
		if (!n) return null;
		let r = n.getBoundingClientRect();
		if (e < r.left || e > r.right || t < r.top || t > r.bottom) return null;
		let i = k.current;
		return {
			x: Math.floor((i.cx + (e - r.left - r.width / 2) / i.s) / 40),
			y: Math.floor((i.cy + (t - r.top - r.height / 2) / i.s) / 40)
		};
	} })), r(() => {
		let e = x.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = k.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.min(Math.max(r.s * i, .35), Math.max(3, De({
				w: n.width,
				h: n.height
			}))), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			k.current = u, O(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let L = s(/* @__PURE__ */ new Map()), R = s(0), z = s(0), B = s(!1), V = (e, t) => {
		let n = x.current.getBoundingClientRect(), r = k.current;
		return {
			x: Math.floor((r.cx + (e - n.left - n.width / 2) / r.s) / 40),
			y: Math.floor((r.cy + (t - n.top - n.height / 2) / r.s) / 40)
		};
	}, W = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), L.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), L.current.size === 1 && (R.current = 0, B.current = !1, n && p)) {
			let t = V(e.clientX, e.clientY);
			n.cells.some((e) => n.x + e[0] === t.x && n.y + e[1] === t.y) && (B.current = !0, f?.(t.x, t.y));
		}
		if (L.current.size === 2) {
			B.current = !1;
			let [e, t] = [...L.current.values()];
			z.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, te = (e) => {
		let t = L.current.get(e.pointerId);
		if (!t) return;
		let n = x.current.getBoundingClientRect();
		if (L.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			if (R.current += Math.abs(n) + Math.abs(r), B.current) {
				let t = V(e.clientX, e.clientY);
				p?.(t.x, t.y);
			} else if (R.current > 6) {
				let e = k.current, t = {
					...e,
					cx: e.cx - n / e.s,
					cy: e.cy - r / e.s
				};
				k.current = t, O(t);
			}
		} else if (L.current.size === 2) {
			L.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...L.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (z.current > 0 && i > 0) {
				let e = k.current, a = Math.min(Math.max(e.s * i / z.current, .35), Math.max(3, De({
					w: n.width,
					h: n.height
				}))), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				k.current = u, O(u);
			}
			z.current = i, R.current = 99;
			return;
		}
		L.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, G = (e) => {
		let t = L.current.size === 1 && R.current < 10, n = B.current;
		if (L.current.delete(e.pointerId), z.current = 0, B.current = !1, !t || n || !d) return;
		let r = V(e.clientX, e.clientY);
		d(r.x, r.y);
	}, K = o(() => e.map((e) => ({
		p: e,
		cells: U(e.t < 0 ? H : e.t, e.r, e.f)
	})), [e]), q = n && m && S.w > 0 && S.h > 0 ? (() => {
		let e = n.cells.map((e) => e[0]), t = n.cells.map((e) => e[1]), r = (e, t) => ({
			x: S.w / 2 + (e - I.cx) * I.s,
			y: S.h / 2 + (t - I.cy) * I.s
		}), i = r((n.x + Math.min(...e)) * 40, (n.y + Math.min(...t)) * 40), a = r((n.x + Math.max(...e) + 1) * 40, (n.y + Math.max(...t) + 1) * 40);
		if (a.x < 0 || i.x > S.w || a.y < 0 || i.y > S.h) return null;
		let o = S.h < 300 && window.matchMedia("(orientation: landscape)").matches, s = Math.min(j.w || (o ? 150 : 252), S.w - 12) / 2, c = (j.h || (o ? 118 : 76)) / 2, l = (e) => Math.max(s + 6, Math.min(S.w - s - 6, e)), u = Math.min(58 + c, S.h - c - 6), d = (e) => Math.max(c + 6, Math.max(u, Math.min(S.h - c - 6, e)));
		if (o) return {
			left: l(i.x > S.w - a.x ? i.x - s - 8 : a.x + s + 8),
			top: d((i.y + a.y) / 2)
		};
		let f = a.y + c + 8, p = i.y - c - 8, m = f <= S.h - c - 6 ? f : p >= u ? p : d(f);
		return {
			left: l((i.x + a.x) / 2),
			top: d(m)
		};
	})() : null;
	return /* @__PURE__ */ D("div", {
		ref: b,
		className: "fbv-garden relative min-h-0 flex-1 overflow-hidden",
		children: [
			/* @__PURE__ */ D("div", {
				className: "fbv-garden-heading",
				children: [/* @__PURE__ */ E("strong", { children: h }), /* @__PURE__ */ E("span", { children: g })]
			}),
			/* @__PURE__ */ E("div", {
				ref: x,
				className: "absolute inset-0",
				children: /* @__PURE__ */ E("svg", {
					className: "h-full w-full touch-none select-none",
					onPointerDown: W,
					onPointerMove: te,
					onPointerUp: G,
					onPointerCancel: G,
					children: /* @__PURE__ */ D("g", {
						transform: `translate(${S.w / 2 - I.cx * I.s}, ${S.h / 2 - I.cy * I.s}) scale(${I.s})`,
						children: [
							K.map(({ p: e, cells: t }, n) => /* @__PURE__ */ E("g", {
								transform: `translate(${e.x * 40}, ${e.y * 40})`,
								children: /* @__PURE__ */ E(Se, {
									cells: t,
									cell: 40
								})
							}, n)),
							t.map((e, t) => {
								let n = e.cells.map((e) => e[0]), r = e.cells.map((e) => e[1]), i = Math.min(...n) * 40, a = Math.min(...r) * 40, o = (Math.max(...n) - Math.min(...n) + 1) * 40, s = (Math.max(...r) - Math.min(...r) + 1) * 40, c = Math.min(o, s) * .86;
								return /* @__PURE__ */ E("g", {
									transform: `translate(${i + (o - c) / 2}, ${a + (s - c) / 2})`,
									pointerEvents: "none",
									children: /* @__PURE__ */ E(Te, {
										kind: e.k,
										size: c
									})
								}, `i${t}`);
							}),
							l && (() => {
								let e = U(l.t, l.r, l.f), t = e.map((e) => e[0]), n = e.map((e) => e[1]);
								return /* @__PURE__ */ E("rect", {
									x: (l.x + Math.min(...t)) * 40 - 3,
									y: (l.y + Math.min(...n)) * 40 - 3,
									width: (Math.max(...t) - Math.min(...t) + 1) * 40 + 6,
									height: (Math.max(...n) - Math.min(...n) + 1) * 40 + 6,
									rx: 8,
									fill: "none",
									className: "stroke-ink",
									strokeWidth: 2.5,
									strokeDasharray: "5 6",
									opacity: .45,
									pointerEvents: "none"
								});
							})(),
							n && /* @__PURE__ */ D("g", {
								transform: `translate(${n.x * 40}, ${n.y * 40})`,
								opacity: i ? .88 : .67,
								pointerEvents: "none",
								children: [
									/* @__PURE__ */ E(Se, {
										cells: n.cells,
										cell: 40
									}),
									(() => {
										let e = n.cells.map((e) => e[0]), t = n.cells.map((e) => e[1]);
										return /* @__PURE__ */ E("rect", {
											x: Math.min(...e) * 40 - 3,
											y: Math.min(...t) * 40 - 3,
											width: (Math.max(...e) - Math.min(...e) + 1) * 40 + 6,
											height: (Math.max(...t) - Math.min(...t) + 1) * 40 + 6,
											rx: 8,
											fill: "none",
											stroke: i ? "#f5a947" : "#df5f51",
											strokeWidth: 3.5,
											strokeDasharray: i ? void 0 : "7 5"
										});
									})(),
									!i && /* @__PURE__ */ E("text", {
										x: 40 * .18,
										y: 32.8,
										fill: "#b73d39",
										fontSize: 32,
										fontWeight: 900,
										children: "×"
									})
								]
							})
						]
					})
				})
			}),
			q && /* @__PURE__ */ D("div", {
				ref: ee,
				className: "fbv-ghost-dock",
				style: q,
				children: [_ && /* @__PURE__ */ E("span", {
					className: `fbv-ghost-status ${i ? "fbv-ghost-status--valid" : "fbv-ghost-status--invalid"}`,
					children: _
				}), /* @__PURE__ */ E("div", {
					className: "fbv-ghost-actions",
					children: m
				})]
			})
		]
	});
}
//#endregion
//#region src/games/frostedbloom/view-player.tsx
var Ae = {
	P: "games.frostedbloom.elemP",
	R: "games.frostedbloom.elemR",
	W: "games.frostedbloom.elemW",
	"~": "games.frostedbloom.elemWater",
	worker: "games.frostedbloom.impWorker",
	barn: "games.frostedbloom.impBarn",
	windmill: "games.frostedbloom.impWindmill"
};
function je(e) {
	return /* @__PURE__ */ E(Me, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Me({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let a = d(), u = e.players.find((e) => e.rid === r), [f, p] = c(r), [h, g] = c(null), [S, w] = c({
		rot: 0,
		flip: !1
	}), [O, k] = c([]), [A, ee] = c(!1), M = s(null), N = s(!1), P = s({
		dx: 0,
		dy: 0
	}), F = e.phase === "play" && e.turn === r, I = e.step, L = F && f === r && !!u, [R, z] = c(""), B = `${e.turn}:${e.step}:${e.round}:${f}`;
	R !== B && (z(B), g(null), w({
		rot: 0,
		flip: !1
	}), k([]));
	let H = (e) => n.find((t) => t.rid === e)?.name ?? e, te = (e) => {
		let t = n.find((t) => t.rid === e);
		return y[(t?.colorIndex ?? 0) % y.length].hex;
	}, G = o(() => Array.from({ length: 5 }, (t, n) => (e.token + 1 + n) % 6), [e.token]), q = o(() => {
		let t = /* @__PURE__ */ new Map(), n = 0;
		for (let r of G) e.slots[r] >= 0 && (t.set(r, n), n += 1);
		return t;
	}, [G, e.slots]), J = e.players.find((e) => e.rid === f), Y = h && e.current !== null ? U(e.current, S.rot, S.flip) : null, X = !!(L && I === "place" && h && Y && re(J?.board ?? [], J?.imps ?? [], Y, h.x, h.y)), Z = (t, n) => {
		if (e.current === null) return;
		let { w: r, h: i } = Ce(e.current, S.rot, S.flip);
		g({
			x: t - Math.floor(r / 2),
			y: n - Math.floor(i / 2)
		});
	}, Q = (e, t) => {
		L && I === "place" && Z(e, t);
	}, ne = (t) => {
		L && I === "place" && e.current !== null && (t.currentTarget.setPointerCapture(t.pointerId), N.current = !0);
	}, ie = (e) => {
		if (!N.current) return;
		let t = M.current?.cellAt(e.clientX, e.clientY);
		t && Z(t.x, t.y);
	}, ae = () => {
		N.current = !1;
	}, oe = (e, t) => {
		h && (P.current = {
			dx: e - h.x,
			dy: t - h.y
		});
	}, se = (e, t) => {
		L && I === "place" && h && g({
			x: e - P.current.dx,
			y: t - P.current.dy
		});
	}, ce = (t) => {
		if (e.current === null || !h) return;
		let n = t === "rotate" ? {
			...S,
			rot: (S.rot + 1) % 4
		} : {
			...S,
			flip: !S.flip
		}, r = Ce(e.current, S.rot, S.flip), i = Ce(e.current, n.rot, n.flip), a = h.x + Math.floor(r.w / 2), o = h.y + Math.floor(r.h / 2);
		w(n), g({
			x: a - Math.floor(i.w / 2),
			y: o - Math.floor(i.h / 2)
		});
	}, le = h && L && I === "place" ? /* @__PURE__ */ D(T, { children: [
		/* @__PURE__ */ E("button", {
			type: "button",
			"aria-label": a("games.frostedbloom.rotate"),
			onClick: () => ce("rotate"),
			className: "fbv-ghost-action",
			children: /* @__PURE__ */ E(v, {
				size: 21,
				"aria-hidden": !0
			})
		}),
		/* @__PURE__ */ E("button", {
			type: "button",
			"aria-label": a("games.frostedbloom.flip"),
			onClick: () => ce("flip"),
			className: "fbv-ghost-action",
			children: /* @__PURE__ */ E(_, {
				size: 21,
				"aria-hidden": !0
			})
		}),
		/* @__PURE__ */ E("button", {
			type: "button",
			"aria-label": a("games.frostedbloom.previewCancel"),
			onClick: () => {
				g(null), w({
					rot: 0,
					flip: !1
				});
			},
			className: "fbv-ghost-action fbv-ghost-action--cancel",
			children: /* @__PURE__ */ E(m, {
				size: 20,
				"aria-hidden": !0
			})
		}),
		/* @__PURE__ */ E("button", {
			type: "button",
			disabled: !X,
			onClick: () => {
				i({
					type: "place",
					x: h.x,
					y: h.y,
					rot: S.rot,
					flip: S.flip
				}), g(null);
			},
			className: "fbv-ghost-confirm",
			children: a("games.frostedbloom.placeConfirm")
		})
	] }) : null, ue = (t) => {
		if (!e.groups) return 0;
		let n = W[t];
		return n.elems.reduce((t, r) => t + e.groups[r] * (n.elems.length === 1 ? 2 : 1), 0);
	}, de = e.objectives.filter((t) => {
		let n = K[t];
		return u?.claimed.some((e) => K[e].type === n.type) ? !1 : n.type === "worker" || n.type === "barn" || n.type === "windmill" ? e.impThisTurn && (u?.imps.filter((e) => e.k === n.type).length ?? 0) >= n.need : !!e.groups && e.groups[n.type] >= n.need;
	}), fe = "info", pe;
	return F ? (fe = "accent", pe = a(I === "take" ? "games.frostedbloom.stageTake" : I === "place" ? "games.frostedbloom.stagePlace" : I === "card" ? "games.frostedbloom.stageCard" : "games.frostedbloom.stageClaim")) : pe = a("games.frostedbloom.waitTurn", { name: H(e.turn) }), /* @__PURE__ */ E("div", {
		className: "fbv-game",
		children: /* @__PURE__ */ E(C, {
			adaptive: !0,
			className: "fbv-screen",
			scroll: !1,
			banner: /* @__PURE__ */ E(b, {
				tone: fe,
				text: pe,
				chip: a("games.frostedbloom.roundShort", { n: e.round }),
				accent: j.accent
			}),
			actionsHeight: "fbv-actions-slot",
			actions: /* @__PURE__ */ E("div", {
				className: "fbv-tray",
				children: !F || f !== r ? /* @__PURE__ */ E("p", {
					className: "flex flex-1 items-center justify-center text-xs font-bold opacity-50",
					children: a("games.frostedbloom.watchHint")
				}) : I === "take" ? /* @__PURE__ */ E("p", {
					className: "flex flex-1 items-center justify-center px-2 text-center text-xs font-bold opacity-70",
					children: a("games.frostedbloom.takeHint")
				}) : I === "place" ? /* @__PURE__ */ D(T, { children: [/* @__PURE__ */ E("div", {
					role: "button",
					"aria-label": a("games.frostedbloom.placeHint"),
					onPointerDown: ne,
					onPointerMove: ie,
					onPointerUp: ae,
					onPointerCancel: ae,
					className: "card fbv-pending-tile grid h-full flex-none touch-none place-items-center p-0.5",
					children: e.current !== null && (() => {
						let { w: t, h: n, cells: r } = Ce(e.current, S.rot, S.flip);
						return /* @__PURE__ */ E("svg", {
							viewBox: `-2 -2 ${t * 40 + 4} ${n * 40 + 4}`,
							className: "fbv-pending-art",
							"aria-hidden": !0,
							children: /* @__PURE__ */ E(Se, {
								cells: r,
								cell: 40
							})
						});
					})()
				}), /* @__PURE__ */ E("p", {
					className: "fbv-tray-hint flex flex-1 items-center justify-center px-1 text-center text-xs font-bold",
					children: a(h ? "games.frostedbloom.placeAdjustHint" : "games.frostedbloom.placeHint")
				})] }) : I === "card" ? /* @__PURE__ */ E("div", {
					className: "fbv-hand flex min-w-0 flex-1 items-center justify-center gap-1.5",
					children: t.hand.map((e) => /* @__PURE__ */ E("button", {
						type: "button",
						"aria-label": a("games.frostedbloom.hintCard", { n: ue(e) }),
						onClick: () => i({
							type: "playCard",
							card: e
						}),
						className: "fbv-hand-card h-full flex-none overflow-hidden rounded-lg border-2 border-ink bg-surface",
						children: /* @__PURE__ */ E(Ee, {
							card: W[e],
							w: 60,
							h: 84,
							score: ue(e)
						})
					}, e))
				}) : /* @__PURE__ */ D(T, { children: [/* @__PURE__ */ D("div", {
					className: "flex min-w-0 flex-1 items-center gap-1 overflow-x-auto",
					children: [de.map((e) => {
						let t = K[e], n = O.includes(e);
						return /* @__PURE__ */ D("button", {
							type: "button",
							"aria-pressed": n,
							onClick: () => k((t) => n ? t.filter((t) => t !== e) : [...t, e]),
							className: `card fbv-claim-card flex flex-none items-center gap-1 px-2 py-1 text-xs font-bold ${n ? "ring-3 ring-ink ring-offset-1 ring-offset-paper" : ""}`,
							children: [
								t.type === "worker" || t.type === "barn" || t.type === "windmill" ? /* @__PURE__ */ E(Te, {
									kind: t.type,
									size: 18
								}) : /* @__PURE__ */ E(ye, {
									elem: t.type,
									size: 18
								}),
								/* @__PURE__ */ E("span", { children: a("games.frostedbloom.objLabel", {
									n: t.need,
									what: a(Ae[t.type])
								}) }),
								/* @__PURE__ */ D("span", {
									className: "font-mono tabular-nums",
									children: ["+", t.points]
								})
							]
						}, e);
					}), de.length === 0 && /* @__PURE__ */ E("span", {
						className: "px-1 text-xs font-bold opacity-50",
						children: a("games.frostedbloom.claimHint")
					})]
				}), /* @__PURE__ */ E("button", {
					type: "button",
					onClick: () => {
						i({
							type: "claim",
							keys: O
						}), k([]);
					},
					className: "btn-base fbv-end-turn min-h-12 flex-none px-4 text-sm text-white",
					style: { background: j.accent },
					children: O.length > 0 ? a("games.frostedbloom.claimEnd") : a("games.frostedbloom.endTurn")
				})] })
			}),
			children: /* @__PURE__ */ D("div", {
				className: "fbv-main",
				children: [
					/* @__PURE__ */ E("div", {
						className: "fbv-players",
						children: /* @__PURE__ */ E(x, {
							members: n.filter((t) => e.players.some((e) => e.rid === t.rid)),
							myRid: r,
							variant: "plate",
							anchorOf: (e) => `seat:${e}`,
							action: (t) => e.phase === "play" && t === e.turn ? "pending" : null,
							onPick: (e) => p(e),
							picked: (e) => f === e,
							status: (t) => {
								let n = e.players.find((e) => e.rid === t);
								return n ? /* @__PURE__ */ D(T, { children: [
									/* @__PURE__ */ D("span", {
										"aria-label": a("games.frostedbloom.scoreAria", { n: n.score }),
										className: "fbv-player-stat flex items-center gap-0.5 rounded-md border border-ink bg-surface px-1 text-[10px] leading-3.5 font-bold",
										children: [/* @__PURE__ */ E("span", {
											"aria-hidden": !0,
											children: "⭐"
										}), /* @__PURE__ */ E(l, {
											value: n.score,
											className: "font-mono tabular-nums"
										})]
									}),
									/* @__PURE__ */ D("span", {
										"aria-label": a("games.frostedbloom.coinsAria", { n: n.coins }),
										className: "fbv-player-stat flex items-center gap-0.5 rounded-md border border-ink bg-warn-soft px-1 text-[10px] leading-3.5 font-bold",
										children: [/* @__PURE__ */ E("span", {
											"aria-hidden": !0,
											children: "🪙"
										}), /* @__PURE__ */ E(l, {
											value: n.coins,
											className: "font-mono tabular-nums"
										})]
									}),
									/* @__PURE__ */ D("span", {
										"aria-label": a("games.frostedbloom.handAria", { n: n.handCount }),
										className: "fbv-player-stat flex items-center gap-0.5 rounded-md border border-ink bg-surface px-1 text-[10px] leading-3.5 font-bold",
										children: [/* @__PURE__ */ E("span", {
											"aria-hidden": !0,
											children: "🎴"
										}), /* @__PURE__ */ E("span", {
											className: "font-mono tabular-nums",
											children: n.handCount
										})]
									})
								] }) : null;
							}
						})
					}),
					/* @__PURE__ */ D("div", {
						className: "fbv-market",
						"aria-label": a("games.frostedbloom.takeHint"),
						children: [
							/* @__PURE__ */ E("span", {
								className: "fbv-market-token",
								"aria-hidden": !0,
								children: "🌷"
							}),
							G.map((t, n) => {
								let r = e.slots[t];
								if (r < 0) return /* @__PURE__ */ E("div", { className: "fbv-market-empty" }, t);
								let o = q.get(t) ?? 0, s = L && I === "take" && o <= (u?.coins ?? 0), c = {
									p: 0,
									r: 0,
									w: 0
								};
								for (let e of V[r]) e[2] === "P" ? c.p = e[3] : e[2] === "R" ? c.r = e[3] : e[2] === "W" && (c.w = e[3]);
								return /* @__PURE__ */ D("button", {
									type: "button",
									"aria-label": a("games.frostedbloom.slotAria", {
										n: n + 1,
										k: o,
										c: e.slotCoins[t]
									}) + ", " + a("games.frostedbloom.tileAria", c),
									disabled: !s,
									onClick: () => i({
										type: "take",
										steps: o
									}),
									className: "fbv-market-tile",
									children: [/* @__PURE__ */ E(we, {
										tid: r,
										maxSize: 48,
										fluid: !0
									}), (o > 0 || e.slotCoins[t] > 0) && /* @__PURE__ */ D("span", {
										className: "fbv-market-cost absolute bottom-0.5 left-1/2 flex -translate-x-1/2 items-center gap-0.5 rounded-full border border-ink bg-warn-soft px-1 font-mono text-[9px] leading-3 font-bold tabular-nums",
										children: [o > 0 && /* @__PURE__ */ D("span", {
											"aria-hidden": !0,
											children: ["-", o]
										}), e.slotCoins[t] > 0 && /* @__PURE__ */ D("span", {
											"aria-hidden": !0,
											children: [
												"+",
												e.slotCoins[t],
												"🪙"
											]
										})]
									})]
								}, t);
							}),
							/* @__PURE__ */ E("span", {
								className: "fbv-market-bag font-mono tabular-nums",
								children: a("games.frostedbloom.bagShort", { n: e.bagCount })
							})
						]
					}),
					/* @__PURE__ */ E("div", {
						className: "fbv-board",
						children: /* @__PURE__ */ D("div", {
							className: "relative flex h-full min-h-0 flex-col",
							children: [
								/* @__PURE__ */ E(ke, {
									board: J?.board ?? [],
									imps: J?.imps ?? [],
									ghost: L && I === "place" && h && Y ? {
										x: h.x,
										y: h.y,
										cells: Y
									} : null,
									ghostValid: X,
									placed: f === e.turn ? e.placed : null,
									fitKey: `${f}:${e.players.find((e) => e.rid === f)?.board.length ?? 0}`,
									onTap: L && I === "place" ? Q : void 0,
									onGhostDragStart: L && I === "place" ? oe : void 0,
									onGhostDrag: L && I === "place" && h ? se : void 0,
									controls: le,
									label: f === r ? a("games.frostedbloom.myGarden") : a("games.frostedbloom.otherGarden", { name: H(f) }),
									scoreLabel: a("games.frostedbloom.scoreAria", { n: J?.score ?? 0 }),
									placementLabel: h ? a(X ? "games.frostedbloom.placeValid" : "games.frostedbloom.placeInvalid") : void 0,
									viewRid: f,
									handleRef: M
								}),
								/* @__PURE__ */ D("button", {
									type: "button",
									"aria-label": a("games.frostedbloom.objOpen"),
									onClick: () => ee((e) => !e),
									className: "fbv-objective absolute top-1.5 right-1.5 z-10 flex min-h-11 items-center gap-1 px-2.5 text-sm font-bold",
									children: [/* @__PURE__ */ E("span", {
										"aria-hidden": !0,
										children: "🎯"
									}), /* @__PURE__ */ E("span", {
										className: "font-mono tabular-nums",
										children: e.objectives.length
									})]
								}),
								A && /* @__PURE__ */ E(Ne, {
									pub: e,
									colorOf: te,
									onClose: () => ee(!1)
								})
							]
						})
					})
				]
			})
		})
	});
}
function Ne({ pub: e, colorOf: t, onClose: n }) {
	let r = d(), i = [...e.objectives.map((e) => ({
		o: e,
		claimedBy: null
	})), ...e.players.flatMap((e) => e.claimed.map((t) => ({
		o: t,
		claimedBy: e.rid
	})))].sort((e, t) => e.o - t.o);
	return /* @__PURE__ */ E("div", {
		className: "absolute inset-0 z-20 flex justify-end",
		onClick: n,
		children: /* @__PURE__ */ D("div", {
			className: "card fbv-objectives-panel m-2 flex min-h-0 max-h-full w-56 flex-col gap-1 overflow-y-auto p-2",
			onClick: (e) => e.stopPropagation(),
			children: [i.length === 0 && /* @__PURE__ */ E("p", {
				className: "text-xs font-bold opacity-50",
				children: r("games.frostedbloom.objNone")
			}), i.map(({ o: e, claimedBy: n }) => {
				let i = K[e];
				return /* @__PURE__ */ D("div", {
					className: `fbv-objective-row flex flex-none items-center gap-1.5 rounded-md border border-ink px-1.5 py-1 text-xs font-bold ${n ? "opacity-55" : "bg-surface"}`,
					children: [
						i.type === "worker" || i.type === "barn" || i.type === "windmill" ? /* @__PURE__ */ E(Te, {
							kind: i.type,
							size: 20
						}) : /* @__PURE__ */ E(ye, {
							elem: i.type,
							size: 20
						}),
						/* @__PURE__ */ E("span", {
							className: "min-w-0 flex-1",
							children: r("games.frostedbloom.objLabel", {
								n: i.need,
								what: r(Ae[i.type])
							})
						}),
						/* @__PURE__ */ E("span", {
							className: "font-mono tabular-nums",
							children: i.points
						}),
						n && /* @__PURE__ */ E("span", {
							className: "size-3 flex-none rounded-full border border-ink",
							style: { background: t(n) },
							"aria-hidden": !0
						})
					]
				}, e);
			})]
		})
	});
}
//#endregion
//#region src/games/frostedbloom/bot.ts
function Pe() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function Fe(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Ie(e, t) {
	let n = 0;
	for (let r of e) {
		let e = W[r], i = e.elems.reduce((n, r) => n + t[r] * (e.elems.length === 1 ? 2 : 1), 0);
		i > n && (n = i);
	}
	return n;
}
function Le(e, t, n, r) {
	let i = 0, a = [...e.imps, ...r];
	for (let o of t.objectives) {
		let t = K[o];
		e.claimed.some((e) => K[e].type === t.type) || (t.type === "worker" || t.type === "barn" || t.type === "windmill" ? r.length > 0 && a.filter((e) => e.k === t.type).length >= t.need && (i += t.points) : n[t.type] >= t.need && (i += t.points));
	}
	return i;
}
function Re(e, t, n, r, i) {
	let a = /* @__PURE__ */ new Set();
	for (let e of t.board) for (let t of Q(e)) a.add(`${t.x},${t.y}`);
	for (let e of t.imps) for (let [t, n] of e.cells) a.add(`${t},${n}`);
	let o = /* @__PURE__ */ new Set();
	for (let e of a) {
		let [t, n] = e.split(",").map(Number);
		for (let [e, r] of [
			[1, 0],
			[-1, 0],
			[0, 1],
			[0, -1]
		]) {
			let i = `${t + e},${n + r}`;
			a.has(i) || o.add(i);
		}
	}
	let s = null;
	for (let c = 0; c < 2; c++) for (let l = 0; l < 4; l++) {
		let u = U(e, l, c === 1), d = /* @__PURE__ */ new Set();
		for (let f of o) {
			let [o, p] = f.split(",").map(Number);
			for (let [f, m] of u) {
				let h = o - f, g = p - m, _ = `${h},${g}`;
				if (d.has(_) || (d.add(_), !re(t.board, t.imps, u, h, g))) continue;
				let v = {
					t: e,
					x: h,
					y: g,
					r: l,
					f: c === 1
				}, y = ie([...t.board, v], v), b = u.map(([e, t]) => [h + e, g + t]), x = [];
				for (let e of ae(t.board, t.imps, b)) x = [...x, ...oe(e)];
				let S = 0;
				for (let e of x) S += q[e.k] + +(e.k === "worker");
				let C = 0;
				for (let [e, t] of b) for (let [n, r] of [
					[1, 0],
					[-1, 0],
					[0, 1],
					[0, -1]
				]) a.has(`${e + n},${t + r}`) && (C += 1);
				let w = Ie(r, y) + S + Le(t, n, y, x) + C * .5 + i();
				(!s || w > s.value) && (s = {
					x: h,
					y: g,
					rot: l,
					flip: c === 1,
					value: w
				});
			}
		}
	}
	return s;
}
var ze = (e, t) => {
	let n = e.public;
	if (n.phase !== "play" || n.turn !== t.rid) return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = k(O(t.rid)), a = t.difficulty === "weak", o = () => (Pe() - .5) * i.noise * 2, s = e.private?.hand ?? [];
	if (n.step === "take") {
		let e = [], t = 0;
		for (let i = 1; i <= 5; i++) {
			let a = (n.token + i) % 6;
			n.slots[a] < 0 || (t <= r.coins && e.push({
				steps: t,
				pos: a
			}), t += 1);
		}
		if (e.length === 0) return null;
		if (a) return { action: {
			type: "take",
			steps: Fe(e).steps
		} };
		let i = null;
		for (let t of e) {
			let e = (Re(n.slots[t.pos], r, n, s, o)?.value ?? 0) + 2 * n.slotCoins[t.pos] - 2 * t.steps + o();
			(!i || e > i.score) && (i = {
				steps: t.steps,
				score: e
			});
		}
		return { action: {
			type: "take",
			steps: i.steps
		} };
	}
	if (n.step === "place") {
		if (n.current === null) return null;
		if (a) {
			let e = Re(n.current, r, n, s, () => (Pe() - .5) * 40);
			return e ? { action: {
				type: "place",
				x: e.x,
				y: e.y,
				rot: e.rot,
				flip: e.flip
			} } : null;
		}
		let e = Re(n.current, r, n, s, o);
		return e ? { action: {
			type: "place",
			x: e.x,
			y: e.y,
			rot: e.rot,
			flip: e.flip
		} } : null;
	}
	if (n.step === "card") {
		if (s.length === 0 || !n.groups) return null;
		if (a) return { action: {
			type: "playCard",
			card: Fe(s)
		} };
		let e = s[0], t = -1;
		for (let r of s) {
			let i = W[r], a = i.elems.reduce((e, t) => e + n.groups[t] * (i.elems.length === 1 ? 2 : 1), 0) + o();
			a > t && (t = a, e = r);
		}
		return { action: {
			type: "playCard",
			card: e
		} };
	}
	let c = [];
	for (let e of n.objectives) {
		let t = K[e];
		if (r.claimed.some((e) => K[e].type === t.type) || !(t.type === "worker" || t.type === "barn" || t.type === "windmill" ? n.impThisTurn && r.imps.filter((e) => e.k === t.type).length >= t.need : n.groups && n.groups[t.type] >= t.need)) continue;
		let i = t.points >= 25 ? 1 : t.points >= 10 ? 6 : 8;
		(a || n.round >= i) && c.push(e);
	}
	return { action: {
		type: "claim",
		keys: c
	} };
}, Be = (e, t, n) => {
	if (e.type === "take") return n("games.frostedbloom.hintTake", {
		n: e.steps + 1,
		cost: e.steps
	});
	if (e.type === "place") return n("games.frostedbloom.hintPlace");
	if (e.type === "playCard") {
		let r = t.public.groups, i = 0;
		if (r) {
			let t = W[e.card];
			i = t.elems.reduce((e, n) => e + r[n] * (t.elems.length === 1 ? 2 : 1), 0);
		}
		return n("games.frostedbloom.hintCard", { n: i });
	}
	return e.keys.length > 0 ? n("games.frostedbloom.hintClaim", { n: e.keys.length }) : n("games.frostedbloom.hintEnd");
};
//#endregion
//#region src/games/frostedbloom/fx.tsx
function Ve(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
var He = {
	take(e, t) {
		let n = e.data, r = Ve(t, e.rid);
		return typeof n?.gained != "number" || n.gained <= 0 || !r ? null : {
			ms: 800,
			node: /* @__PURE__ */ E(A, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ D("span", { children: [
					"+",
					n.gained,
					" 🪙"
				] })
			})
		};
	},
	place(e, t) {
		let n = e.rid ? t.anchor(`garden:${e.rid}`) : null;
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ E(A, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ E("span", { children: "🌷" })
			})
		} : null;
	},
	fill(e, t) {
		let n = e.data;
		if (typeof n?.workers != "number") return null;
		let r = [], i = Ve(t, e.rid);
		n.workers > 0 && i && r.push({
			ms: 900,
			node: /* @__PURE__ */ E(A, {
				at: i,
				ms: 900,
				children: /* @__PURE__ */ D("span", { children: [
					"+",
					n.workers,
					" 🪙"
				] })
			})
		});
		let a = e.rid ? t.anchor(`garden:${e.rid}`) : null;
		return (typeof n.barns == "number" ? n.barns : 0) + (typeof n.windmills == "number" ? n.windmills : 0) > 0 && a && r.push({
			ms: 1e3,
			node: /* @__PURE__ */ E(A, {
				at: a,
				ms: 1e3,
				delay: 150,
				children: /* @__PURE__ */ D("span", {
					className: "flex items-center gap-0.5",
					children: [typeof n.barns == "number" && Array.from({ length: n.barns }, (e, t) => /* @__PURE__ */ E(Te, {
						kind: "barn",
						size: 22
					}, `b${t}`)), typeof n.windmills == "number" && Array.from({ length: n.windmills }, (e, t) => /* @__PURE__ */ E(Te, {
						kind: "windmill",
						size: 22
					}, `w${t}`))]
				})
			})
		}), r.length === 0 ? null : {
			ms: Math.max(...r.map((e) => e.ms)),
			node: /* @__PURE__ */ E(T, { children: r.map((e, t) => /* @__PURE__ */ E("span", { children: e.node }, t)) })
		};
	},
	card(e, t) {
		let n = e.data, r = Ve(t, e.rid);
		return typeof n?.n != "number" || n.n <= 0 || !r ? null : {
			ms: 900,
			node: /* @__PURE__ */ E(A, {
				at: r,
				ms: 900,
				children: /* @__PURE__ */ D("span", { children: [
					"+",
					n.n,
					" ⭐"
				] })
			})
		};
	},
	claim(e, t) {
		let n = e.data, r = Ve(t, e.rid);
		return typeof n?.n != "number" || !r ? null : {
			ms: 1e3,
			node: /* @__PURE__ */ E(A, {
				at: r,
				ms: 1e3,
				children: /* @__PURE__ */ D("span", { children: ["🎯 +", n.n] })
			})
		};
	}
};
//#endregion
//#region src/games/frostedbloom/endgame-review.tsx
function Ue({ board: e, renderResult: t, ...n }) {
	let i = d(), [a, l] = c(!0), [u, p] = c(null), m = s(null), _ = s(null), v = s(null);
	r(() => {
		if (!u) return;
		v.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => p(null), 5e3);
		return () => clearTimeout(e);
	}, [u]);
	let y = (e) => {
		p(null), l(e), requestAnimationFrame(() => (e ? m : _).current?.focus({ preventScroll: !0 }));
	}, b = o(() => ({
		onPlayAgain: n.onPlayAgain && (() => p({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => p({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => p({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), x = {
		...n,
		...b
	};
	return /* @__PURE__ */ D("div", {
		className: "frostedbloom-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ E("div", {
				className: "frostedbloom-endgame-board",
				inert: a,
				children: e
			}),
			/* @__PURE__ */ E("div", {
				className: "frostedbloom-endgame-overlay",
				hidden: !a,
				children: /* @__PURE__ */ D("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), y(!1));
					},
					className: "frostedbloom-endgame-panel",
					"aria-label": i("session.result.title"),
					children: [
						/* @__PURE__ */ D("header", {
							className: "frostedbloom-endgame-heading",
							children: [/* @__PURE__ */ D("div", {
								className: "frostedbloom-endgame-brand",
								children: [/* @__PURE__ */ E("span", {
									"aria-hidden": "true",
									children: j.icon
								}), i(j.nameKey)]
							}), /* @__PURE__ */ E("button", {
								type: "button",
								ref: m,
								className: "btn-quiet",
								"aria-label": i("games.frostedbloom.reviewHide"),
								title: i("games.frostedbloom.reviewHide"),
								onClick: () => y(!1),
								children: /* @__PURE__ */ E(h, { size: 19 })
							})]
						}),
						/* @__PURE__ */ E("div", {
							className: "frostedbloom-endgame-result",
							inert: u !== null,
							children: t(x)
						}),
						u && /* @__PURE__ */ D("div", {
							className: "frostedbloom-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || p(null);
							},
							children: [/* @__PURE__ */ E("button", {
								type: "button",
								ref: v,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = u.run;
									p(null), e();
								},
								children: i(u.label === "again" ? "games.frostedbloom.reviewConfirmAgain" : "games.frostedbloom.reviewConfirmLobby")
							}), /* @__PURE__ */ E("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									p(null), m.current?.focus({ preventScroll: !0 });
								},
								children: i("games.frostedbloom.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ E("div", {
				className: "frostedbloom-endgame-toolbar",
				hidden: a,
				children: /* @__PURE__ */ D("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => y(!0),
					children: [
						/* @__PURE__ */ E(g, { size: 18 }),
						i("games.frostedbloom.reviewShow"),
						/* @__PURE__ */ E(f, { size: 18 })
					]
				})
			})
		]
	});
}
function We({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: s, renderRowExtra: l, summary: f, navigation: m, content: g, afterRanking: _, scoreUnit: v, rankOf: y }) {
	let b = d(), x = u((e) => e.locale), [C, w] = c({}), O = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? S(n, x) : e;
	}, k = (t, n) => y?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), A = e.ranking.some((t) => e.scores?.[t] !== void 0), M = (t, n) => /* @__PURE__ */ D("div", {
		className: "frostedbloom-score-identity",
		children: [
			/* @__PURE__ */ D("span", {
				className: "frostedbloom-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ E("span", {
					"aria-label": b("games.frostedbloom.reviewWinner"),
					children: "♛ "
				}), A && k(t, n)]
			}),
			/* @__PURE__ */ D("span", {
				className: "frostedbloom-score-name",
				children: [O(t), t === r && /* @__PURE__ */ E("small", { children: b("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ D("small", {
				className: "frostedbloom-score-autopilot",
				children: [
					/* @__PURE__ */ E(p, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), N = (t) => e.ranking.map((n) => /* @__PURE__ */ E("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ D("div", {
		className: "frostedbloom-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ E(ee, {}),
			m,
			/* @__PURE__ */ D("div", {
				className: "frostedbloom-score-body",
				children: [
					f && /* @__PURE__ */ E("div", {
						className: "frostedbloom-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ E("p", {
						className: "frostedbloom-score-hints",
						children: b("session.hint.usedCount", { n: i })
					}),
					g ?? (s?.length ? /* @__PURE__ */ E("div", {
						className: "frostedbloom-score-table-scroll",
						children: /* @__PURE__ */ D("table", {
							className: "frostedbloom-score-table",
							"aria-label": b(j.nameKey),
							children: [
								/* @__PURE__ */ E("thead", { children: /* @__PURE__ */ D("tr", { children: [/* @__PURE__ */ E("th", { scope: "col" }), /* @__PURE__ */ E(T, { children: e.ranking.map((t, n) => /* @__PURE__ */ E("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: M(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ E("tbody", { children: s.map((e, t) => /* @__PURE__ */ D(n, { children: [/* @__PURE__ */ D("tr", { children: [/* @__PURE__ */ E("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ D("button", {
										type: "button",
										"aria-expanded": !!C[t],
										onClick: () => w((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ E(h, { size: 15 }), e.label]
									}) : e.label
								}), N(e)] }), C[t] && e.details?.map((e, t) => /* @__PURE__ */ D("tr", {
									className: "frostedbloom-score-sub",
									children: [/* @__PURE__ */ E("th", {
										scope: "row",
										children: e.label
									}), N(e)]
								}, t))] }, t)) }),
								A && /* @__PURE__ */ E("tfoot", { children: /* @__PURE__ */ D("tr", { children: [/* @__PURE__ */ E("th", {
									scope: "row",
									children: b("games.frostedbloom.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ E("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ E("ol", {
						className: "frostedbloom-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ D("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ D("div", {
								className: "frostedbloom-score-rankline",
								children: [M(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ D("strong", {
									className: "frostedbloom-score-points",
									children: [e.scores[t], v && /* @__PURE__ */ E("small", { children: v })]
								})]
							}), l?.(t)]
						}, t))
					})),
					_,
					!!s?.length && l && /* @__PURE__ */ E("div", {
						className: "frostedbloom-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ D("details", { children: [/* @__PURE__ */ E("summary", { children: O(e) }), l(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ D("footer", {
				className: "frostedbloom-score-actions",
				children: [
					o && /* @__PURE__ */ E("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: b("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ E("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: b("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ E("p", { children: b("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/frostedbloom/endgame-scores.tsx
function Ge(e) {
	let t = d(), n = e.public, r = (e) => n.final?.find((t) => t.rid === e), i = [
		["track", "games.frostedbloom.scoreTrack"],
		["imps", "games.frostedbloom.scoreImps"],
		["objectives", "games.frostedbloom.scoreObjs"],
		["coins", "games.frostedbloom.scoreCoins"]
	].map(([e, n]) => ({
		label: t(n),
		value: (t) => r(t)?.[e] ?? "—"
	}));
	return /* @__PURE__ */ E(We, {
		...e,
		renderRowExtra: void 0,
		rows: i,
		rankOf: (t) => {
			let n = r(t);
			return e.result.ranking.findIndex((e) => {
				let t = r(e);
				return t?.total === n?.total && t?.coins === n?.coins;
			}) + 1;
		}
	});
}
//#endregion
//#region src/games/frostedbloom/game-over.tsx
function Ke(e) {
	return /* @__PURE__ */ E(Ge, { ...e });
}
function qe(e) {
	return /* @__PURE__ */ E(Ue, {
		...e,
		board: /* @__PURE__ */ E(je, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ E(Ke, { ...e })
	});
}
//#endregion
//#region src/games/frostedbloom/game-over-row.tsx
function Je({ public: e, rid: t }) {
	let n = d(), r = e.final?.find((e) => e.rid === t);
	return r ? /* @__PURE__ */ D("div", {
		className: "fbv-result-details mt-1 font-mono text-xs tabular-nums text-ink-soft",
		children: [
			n("games.frostedbloom.scoreTrack"),
			" ",
			r.track,
			" · ",
			n("games.frostedbloom.scoreImps"),
			" ",
			r.imps,
			" · ",
			n("games.frostedbloom.scoreObjs"),
			" ",
			r.objectives,
			" · ",
			n("games.frostedbloom.scoreCoins"),
			" ",
			r.coins
		]
	}) : null;
}
//#endregion
//#region .bgparty/cache/pack-entry/frostedbloom/entry.tsx
var Ye = {
	definition: ge,
	View: je,
	bot: ze,
	describe: Be,
	fx: He,
	OverView: qe,
	RowView: Je,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "郁金香庄园",
			desc: "轮盘拿块建花园,连通花海抢目标",
			rules: "目标:10 轮建设郁金香庄园,终局总分最高者胜。\n· 终局总分为计分轨、升级标记、目标板块与剩余金币四部分之和。\n准备:\n· 每人 1 块起始板块与 10 张景观卡(洗匀抽 3 张作手牌)。\n· 按回合顺序获得 1/2/3/4 金币。\n· 44 块景观板块洗混成袋,翻 5 块摆上市场;按人数翻 8/10/12 块目标板块。\n流程(每回合四步):\n· 拿板块:花朵标记顺时针移向要拿取的市场板块,每跳过 1 块须在其旁放 1 金币。\n· 拿走板块与其旁积累的金币,再从袋中补 1 块。\n· 放板块:至少一边与已有板块相邻(元素无需同类相接),可自由旋转翻面;放下后不可移动。\n· 打 1 张景观卡:按刚放置板块的同元素连通组计分。\n· 单元素卡每元素 2 分,双元素卡每类各 1 分;然后补牌至 3 张,牌库空后不重洗。\n· 填升级(能填必填):围出的空地立即按格数填充。\n· 1 格填 1 个花农;2 格填 1 个谷仓;3 格填 1 个谷仓与 1 个花农。\n· 4 格 T 形填 1 个谷仓与 2 个花农;4 格其他非方形填 2 个谷仓。\n· 4 格方形填 1 座风车。\n· 每放置 1 个花农立即获得 1 金币。\n认领目标(可选):\n· 景观类:本回合放置板块的连通组达 6/8/10(花按朵数、水按格数)。\n· 升级类:本回合放置过升级标记,且该类总数达标。\n· 升级类目标值:花农 3/4/5、谷仓 2/3/4、风车 1/2/3。\n· 每人每类限 1 块;达标本回合可领多块,放弃则可能被对手抢走。\n结算:\n· 升级分:花农 3 / 谷仓 10 / 风车 25;目标板块 3/10/25 分。\n· 每枚剩余金币 1 分。\n· 平分比剩余金币,再平则共享胜利。",
			roundShort: "第 {{n}}/10 轮",
			stageTake: "轮到你:拿板块",
			stagePlace: "轮到你:放板块",
			stageCard: "轮到你:打景观卡",
			stageClaim: "轮到你:认领目标或结束回合",
			waitTurn: "等 {{name}} 行动…",
			watchHint: "轮到你时,这里会出现操作按钮",
			takeHint: "点一块市场板块拿取;每跳过 1 块付 1 金币,拿走槽上积累的金币",
			placeHint: "拖动板块进花园,或点花园空处预览位置",
			placeAdjustHint: "在预览板块旁调整朝向、撤回或确认",
			previewCancel: "撤回预览",
			placeValid: "可以接入花园",
			placeInvalid: "与板块重叠或未接边",
			myGarden: "我的花园",
			otherGarden: "{{name}}的花园",
			cardHint: "打 1 张景观卡,按连通组计分",
			claimHint: "可认领达标目标,或直接结束回合",
			rotate: "旋转",
			flip: "翻面",
			placeConfirm: "放到这里",
			cardScore: "+{{n}}",
			endTurn: "结束回合",
			claimEnd: "认领并结束",
			objOpen: "查看目标板块",
			objNone: "目标板块已全部被认领",
			objLabel: "{{n}}×{{what}}",
			elemP: "紫花",
			elemR: "红花",
			elemW: "白花",
			elemWater: "水域",
			impWorker: "花农",
			impBarn: "谷仓",
			impWindmill: "风车",
			coinsAria: "{{n}} 金币",
			scoreAria: "{{n}} 分",
			handAria: "手牌 {{n}} 张",
			bagShort: "袋 {{n}}",
			slotAria: "第 {{n}} 块可选板块,跳过需付 {{k}} 金币,槽上有 {{c}} 金币",
			tileAria: "板块:紫 {{p}} 红 {{r}} 白 {{w}}",
			errNotYourTurn: "还没轮到你",
			errNoCoins: "金币不够跳过这么多板块",
			errNoTile: "那个位置没有板块",
			errBadPlacement: "这里放不下:需与已有板块边相邻且不重叠",
			errBadCard: "这张卡不在你手上",
			errBadClaim: "目标未达标或该类已认领过",
			scoreTrack: "计分轨",
			scoreImps: "升级标记",
			scoreObjs: "目标板块",
			scoreCoins: "剩余金币",
			hintTake: "拿第 {{n}} 块板块(付 {{cost}} 金币)",
			hintPlace: "把板块放进花园(尽量围合空地)",
			hintCard: "打这张卡,约得 {{n}} 分",
			hintClaim: "认领 {{n}} 块目标并结束回合",
			hintEnd: "结束回合"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Frosted Blooms",
			desc: "Draft tiles from the rondel, grow flower groups, claim objectives",
			rules: "Goal: 10 rounds to build the most valuable tulip estate; the highest final score wins.\n· Final score is the sum of score track, improvements, objective tiles, and leftover coins.\nSetup:\n· Each player gets a starting tile and a deck of 10 Landscape cards (shuffle, draw 3).\n· Gain 1/2/3/4 coins in turn order.\n· Shuffle all 44 Landscape tiles into a bag and reveal 5 onto the market; reveal 8/10/12 objective tiles by player count.\nPlay (four steps per turn):\n· Take a tile: move the Flower token clockwise toward the market tile you want, placing 1 coin next to each tile you skip.\n· Take the tile and any coins beside it, then refill from the bag.\n· Place the tile: at least one edge adjacent to your garden (elements need not match), rotating and flipping freely; placed tiles cannot move.\n· Play 1 Landscape card: score the connected group of the just-placed tile.\n· Single-type cards score 2 points per element, dual-type cards 1 point per element of each type; then draw back to 3, no reshuffle when the deck runs out.\n· Fill gaps (mandatory): an enclosed gap is filled immediately according to its size.\n· 1 space takes 1 Worker; 2 spaces take 1 Barn; 3 spaces take 1 Barn and 1 Worker.\n· A 4-space T takes 1 Barn and 2 Workers; other non-square 4-space gaps take 2 Barns.\n· A 4-space square takes 1 Windmill.\n· Each Worker placed earns 1 coin at once.\nClaiming objectives (optional):\n· Landscapes: the group formed by the tile placed this turn reaches 6/8/10 (flowers counted by blooms, water by spaces).\n· Improvements: you placed an improvement this turn and your total for that type meets the target.\n· Improvement targets: Workers 3/4/5, Barns 2/3/4, Windmills 1/2/3.\n· At most 1 objective per type per player; you may claim several in one turn, but passing lets opponents snatch them.\nFinal scoring:\n· Improvements: Worker 3 / Barn 10 / Windmill 25; objective tiles 3/10/25.\n· Each leftover coin scores 1 point.\n· Ties are broken by leftover coins, then shared victory.",
			roundShort: "Round {{n}}/10",
			stageTake: "Your turn: take a tile",
			stagePlace: "Your turn: place the tile",
			stageCard: "Your turn: play a card",
			stageClaim: "Your turn: claim objectives or end turn",
			waitTurn: "Waiting for {{name}}…",
			watchHint: "Actions appear here on your turn",
			takeHint: "Tap a market tile to take it; pay 1 coin per tile skipped, collect coins on the slot",
			placeHint: "Drag the tile into your garden, or tap an open spot to preview",
			placeAdjustHint: "Rotate, flip, cancel or confirm beside the preview tile",
			previewCancel: "Cancel preview",
			placeValid: "Fits your garden",
			placeInvalid: "Overlaps or does not touch",
			myGarden: "My garden",
			otherGarden: "{{name}}'s garden",
			cardHint: "Play 1 Landscape card to score the connected group",
			claimHint: "Claim any objectives you met, or end your turn",
			rotate: "Rotate",
			flip: "Flip",
			placeConfirm: "Place here",
			cardScore: "+{{n}}",
			endTurn: "End turn",
			claimEnd: "Claim & end",
			objOpen: "View objectives",
			objNone: "All objectives claimed",
			objLabel: "{{n}}× {{what}}",
			elemP: "purple flowers",
			elemR: "red flowers",
			elemW: "white flowers",
			elemWater: "water",
			impWorker: "Workers",
			impBarn: "Barns",
			impWindmill: "Windmills",
			coinsAria: "{{n}} coins",
			scoreAria: "{{n}} points",
			handAria: "{{n}} cards in hand",
			bagShort: "Bag {{n}}",
			slotAria: "Market tile {{n}}, skip cost {{k}} coins, {{c}} coins on slot",
			tileAria: "Tile: {{p}} purple, {{r}} red, {{w}} white",
			errNotYourTurn: "Not your turn",
			errNoCoins: "Not enough coins to skip that many tiles",
			errNoTile: "No tile on that space",
			errBadPlacement: "Doesn't fit: must touch an existing tile edge without overlap",
			errBadCard: "That card is not in your hand",
			errBadClaim: "Requirement not met or type already claimed",
			scoreTrack: "Score track",
			scoreImps: "Improvements",
			scoreObjs: "Objectives",
			scoreCoins: "Coins left",
			hintTake: "Take market tile {{n}} (pay {{cost}} coins)",
			hintPlace: "Place the tile in your garden (try to enclose gaps)",
			hintCard: "Play this card for about {{n}} points",
			hintClaim: "Claim {{n}} objectives and end the turn",
			hintEnd: "End turn"
		}
	}
};
//#endregion
export { Ye as default };
