import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { useT as i } from "@bgparty/sdk/i18n";
import { useWakeLock as a } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { SheetFxProbe as s, SheetView as c } from "@bgparty/sdk/sheet-view";
import { usePrefersReducedMotion as l } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { BottomSheet as p } from "@bgparty/sdk/bottom-sheet";
import { FlySprite as m } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as h } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as g, OptionRadio as _, OptionSection as v } from "@bgparty/sdk/ui/game-options";
//#endregion
//#region src/games/landmarks/maps.ts
var y = /* @__PURE__ */ JSON.parse("[{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,2,4,4,0,0,0,3,0,5,4,0,0,0,0,0,0,0,2,0,5,4,7,6,0,5,0,3,0,2,0,0,0,3],\"start\":[15,16,17],\"words\":[\"DAILY\",\"LIGHTNING\",\"CHESS\"],\"zh\":[\"日常\",\"闪电\",\"国际象棋\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,0,0,3,0,2,0,5,0,6,0,7,0,2,4,0,3,0,0,0,0,0,5,0,2,0,4,5,4,0,4,3,0,0],\"start\":[11,18,24],\"words\":[\"LAUNDRY\",\"BAND\",\"MOMMY\"],\"zh\":[\"洗衣\",\"乐队\",\"妈妈\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,3,2,6,0,2,0,4,0,4,0,0,3,0,5,0,4,0,0,2,5,0,5,0,0,0,3,7,4,0,0,0,0,0],\"start\":[20,21,26],\"words\":[\"LUNCH\",\"COUGH\",\"NATURE\"],\"zh\":[\"午餐\",\"咳嗽\",\"自然\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[4,0,0,0,0,2,3,7,0,0,6,5,3,2,0,0,0,0,0,5,0,0,5,3,0,4,2,0,0,0,0,4,0,0,0,0,4],\"start\":[29,30,34],\"words\":[\"LAUGHTER\",\"MOTORCYCLE\",\"SUN\"],\"zh\":[\"笑声\",\"摩托车\",\"太阳\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,2,0,0,7,0,5,0,4,4,3,6,5,0,2,0,5,4,0,0,0,0,2,0,3,0,0,0,4,0,0,0,3,0,0,0],\"start\":[24,30,31],\"words\":[\"MACHINE\",\"BRIDGE\",\"GRAM\"],\"zh\":[\"机器\",\"桥\",\"克\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,3,0,3,0,0,0,0,4,2,0,4,4,5,2,5,5,0,0,0,0,0,7,6,3,0,0,0,0,2,4,0,0,0,0],\"start\":[2,6,12],\"words\":[\"HEAT\",\"MONITOR\",\"LION\"],\"zh\":[\"热量\",\"显示器\",\"狮子\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[3,0,0,0,7,0,0,0,0,2,0,0,0,5,0,0,4,4,0,2,4,0,3,6,3,0,0,0,0,4,5,2,5,0,0,0,0],\"start\":[2,6,7],\"words\":[\"VOTE\",\"PALACE\",\"BANK\"],\"zh\":[\"投票\",\"宫殿\",\"银行\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[3,0,0,0,0,0,5,4,2,0,0,0,5,0,0,0,2,0,3,7,0,0,0,0,4,6,2,0,3,4,5,0,4,0,0,0,0],\"start\":[4,5,11],\"words\":[\"POPE\",\"SPORT\",\"ARTICLE\"],\"zh\":[\"教皇\",\"运动\",\"文章\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,2,0,0,5,0,0,0,0,6,0,7,0,0,4,0,3,4,2,5,0,0,2,0,4,3,0,4,5,3,0,0,0,0,0],\"start\":[4,5,10],\"words\":[\"PENNY\",\"CLOWN\",\"SONG\"],\"zh\":[\"便士\",\"小丑\",\"歌曲\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[2,0,0,0,0,0,0,3,0,0,4,0,0,4,0,0,3,0,5,5,2,0,0,4,6,5,3,0,0,0,4,7,0,0,2,0,0],\"start\":[6,11,12],\"words\":[\"DITCH\",\"BUCKET\",\"MODERN\"],\"zh\":[\"沟渠\",\"水桶\",\"现代\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,3,0,0,0,0,4,0,0,2,5,0,0,0,2,3,3,4,5,0,0,4,0,6,0,4,7,0,0,5,0,2,0,0,0,0,0],\"start\":[3,7,13],\"words\":[\"SWAMP\",\"FENCE\",\"BUBBLE\"],\"zh\":[\"沼泽\",\"栅栏\",\"泡泡\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,2,0,3,5,4,0,4,0,0,0,3,0,4,0,0,0,0,5,5,2,0,0,0,6,7,0,0,4,0,2,0,0,0,0,0,3],\"start\":[10,17,23],\"words\":[\"SALAD\",\"POEM\",\"APP\"],\"zh\":[\"沙拉\",\"诗\",\"应用\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[2,0,0,0,0,0,0,4,0,0,0,6,5,2,0,0,3,4,0,5,0,0,0,0,5,0,0,0,4,3,3,2,0,7,4,0,0],\"start\":[4,5,10],\"words\":[\"SHIP\",\"BILL\",\"CASTLE\"],\"zh\":[\"船\",\"账单\",\"城堡\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,0,3,4,0,2,7,6,4,5,0,0,0,2,3,3,5,0,0,0,0,4,0,0,4,0,2,5,0,0,0,0,0,0],\"start\":[26,31,36],\"words\":[\"ATHLETE\",\"DRESS\",\"GONE\"],\"zh\":[\"运动员\",\"连衣裙\",\"消失\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,0,2,5,0,0,4,3,4,0,0,0,0,7,4,0,3,3,0,0,0,5,6,2,0,0,4,5,0,0,0,0,0,2],\"start\":[7,12,13],\"words\":[\"CANDY\",\"GLASSES\",\"POPSICLE\"],\"zh\":[\"糖果\",\"眼镜\",\"冰棒\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[4,0,0,0,0,5,7,2,4,0,2,5,0,3,0,0,4,4,6,0,0,2,0,0,0,3,5,0,0,0,0,3,0,0,0,0,0],\"start\":[23,24,29],\"words\":[\"RADIO\",\"CRUMBLE\",\"THUNDER\"],\"zh\":[\"收音机\",\"碎屑\",\"雷声\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,4,5,2,5,4,0,0,0,7,0,5,3,3,0,3,4,2,0,0,0,0,0,0,4,0,0,0,0,6,0,0,0,0,2],\"start\":[29,30,34],\"words\":[\"EARTH\",\"ASHES\",\"SPACE\"],\"zh\":[\"地球\",\"灰烬\",\"太空\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,5,2,4,0,0,0,0,4,0,3,0,0,0,6,5,4,0,0,0,0,0,3,3,7,0,0,2,0,2,0,5,4,0],\"start\":[3,7,12],\"words\":[\"CANTEEN\",\"GRAPE\",\"SKI\"],\"zh\":[\"食堂\",\"葡萄\",\"滑雪\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[4,0,0,0,0,0,3,0,0,0,2,0,0,0,0,0,0,5,4,6,0,3,0,0,2,7,0,0,0,5,4,5,2,0,0,3,4],\"start\":[7,12,13],\"words\":[\"SKATE\",\"WORM\",\"ARM\"],\"zh\":[\"滑冰\",\"蠕虫\",\"手臂\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,0,0,2,5,0,0,5,7,0,0,0,0,2,4,3,3,2,0,5,0,6,0,0,0,4,4,4,0,0,3,0,0,0],\"start\":[25,31,32],\"words\":[\"FAUNA\",\"REEL\",\"AVENUE\"],\"zh\":[\"动物群\",\"卷轴\",\"大街\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[3,2,0,0,3,2,7,4,0,0,0,0,6,0,3,0,5,0,0,5,2,0,0,4,0,0,4,0,5,0,4,0,0,0,0,0,0],\"start\":[24,25,29],\"words\":[\"RANGE\",\"DRYER\",\"ELF\"],\"zh\":[\"范围\",\"烘干机\",\"精灵\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,2,0,5,6,0,4,0,3,0,7,5,0,0,0,0,4,0,3,0,0,0,5,0,2,0,0,2,0,4,0,4,3,0,0],\"start\":[16,17,23],\"words\":[\"LEVEL\",\"SILVER\",\"MAGAZINE\"],\"zh\":[\"等级\",\"白银\",\"杂志\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,4,0,6,0,0,0,2,5,0,0,0,0,0,4,5,0,3,0,0,5,2,0,0,0,4,4,7,0,3,0,3,2,0],\"start\":[13,19,26],\"words\":[\"SQUARE\",\"WHIP\",\"CABIN\"],\"zh\":[\"正方形\",\"鞭子\",\"小屋\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,3,0,4,7,4,0,0,0,6,0,0,0,0,0,2,5,0,0,0,2,5,2,3,3,0,0,5,0,0,0,0,4,0,4],\"start\":[13,19,20],\"words\":[\"STONE\",\"BIG\",\"RIB\"],\"zh\":[\"石头\",\"巨大\",\"肋骨\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,0,2,4,0,0,3,5,3,0,0,0,0,6,7,0,0,4,2,0,3,0,4,0,0,4,0,5,5,2,0,0,0,0],\"start\":[3,7,13],\"words\":[\"CUP\",\"ARCHIVE\",\"PASTRY\"],\"zh\":[\"杯子\",\"档案\",\"糕点\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,0,0,5,4,0,4,0,5,0,5,4,0,0,3,6,0,2,0,0,0,7,2,3,0,0,2,4,0,0,0,0,0,3],\"start\":[0,5,10],\"words\":[\"FAN\",\"WORKSHOP\",\"TIN\"],\"zh\":[\"风扇\",\"工坊\",\"锡\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,0,2,4,3,0,0,2,0,5,0,0,5,4,4,0,0,0,0,0,0,6,5,3,0,0,4,7,3,0,2,0,0,0],\"start\":[13,19,20],\"words\":[\"COURSE\",\"BELT\",\"ECONOMY\"],\"zh\":[\"课程\",\"腰带\",\"经济\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[3,0,0,2,0,4,0,0,0,0,0,0,7,3,0,5,0,0,0,4,5,0,0,0,4,6,0,0,2,5,2,3,0,0,4,0,0],\"start\":[16,17,23],\"words\":[\"MOUNTAIN\",\"TRUCK\",\"GOLD\"],\"zh\":[\"山\",\"卡车\",\"黄金\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,0,3,0,0,0,0,5,0,0,4,0,0,2,4,0,3,0,0,5,0,6,4,5,0,0,2,7,0,4,0,0,2,3],\"start\":[6,7,12],\"words\":[\"CABLE\",\"WHISTLE\",\"GALLOP\"],\"zh\":[\"电缆\",\"哨子\",\"飞奔\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,7,0,0,2,3,3,0,2,0,4,0,5,0,5,0,4,6,0,2,0,0,4,0,3,4,0,0,0,0,0,0,5,0,0,0],\"start\":[24,29,34],\"words\":[\"FINGER\",\"BANANA\",\"ROOF\"],\"zh\":[\"手指\",\"香蕉\",\"屋顶\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,4,0,0,5,0,0,0,0,0,2,3,0,0,0,0,0,0,0,5,2,0,0,4,4,3,5,0,0,4,6,7,0,3,0,2,0],\"start\":[6,7,12],\"words\":[\"NOSE\",\"HUT\",\"MASCOT\"],\"zh\":[\"鼻子\",\"茅屋\",\"吉祥物\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[2,0,0,0,0,0,4,0,3,0,7,4,0,0,0,5,3,6,0,2,5,0,0,0,5,0,4,0,2,0,4,3,0,0,0,0,0],\"start\":[7,12,13],\"words\":[\"TEAM\",\"BLUR\",\"PAPER\"],\"zh\":[\"团队\",\"模糊\",\"纸\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,4,0,4,7,5,0,0,2,4,2,3,5,0,0,0,0,5,0,4,0,2,3,0,0,0,0,0,6,0,0,0,3,0,0,0],\"start\":[25,30,31],\"words\":[\"CAR\",\"DAY\",\"SHAMPOO\"],\"zh\":[\"汽车\",\"白天\",\"洗发水\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,5,0,3,0,2,3,5,0,0,5,2,0,3,0,0,0,0,0,7,6,0,0,0,0,4,0,0,0,4,0,4,2,0,0,0,4],\"start\":[16,22,23],\"words\":[\"TROUSERS\",\"OYSTER\",\"SYRUP\"],\"zh\":[\"裤子\",\"牡蛎\",\"糖浆\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,5,0,0,0,0,3,5,0,0,0,4,0,3,0,0,0,3,5,2,0,0,4,4,7,2,0,0,2,0,6,0,4,0,0,0],\"start\":[0,5,10],\"words\":[\"ZONE\",\"THEATER\",\"CHICKEN\"],\"zh\":[\"区域\",\"剧院\",\"鸡\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,2,0,3,0,0,0,2,0,0,0,0,0,7,0,3,0,5,4,0,5,0,0,4,4,6,5,0,0,3,4,2,0,0,0,0,0],\"start\":[4,10,16],\"words\":[\"SPIDER\",\"MOUTH\",\"DOCTOR\"],\"zh\":[\"蜘蛛\",\"嘴\",\"医生\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,2,0,0,0,0,5,3,5,0,4,4,0,4,3,0,0,2,5,4,2,0,3,6,7,0,0,0,0,0,0,0,0,0,0,0,0],\"start\":[26,31,36],\"words\":[\"CURLING\",\"VILLAGE\",\"FROWN\"],\"zh\":[\"冰壶\",\"村庄\",\"皱眉\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,7,0,4,0,2,0,3,0,2,0,4,0,0,5,4,3,6,5,0,2,5,0,4,0,0,0,3,0,0,0,0,0,0,0],\"start\":[26,31,32],\"words\":[\"TOOTH\",\"SEASON\",\"PRINCESS\"],\"zh\":[\"牙\",\"季节\",\"公主\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,5,5,0,5,2,0,0,7,4,6,3,0,2,0,4,0,0,0,0,0,4,3,4,0,0,0,2,0,0,0,3,0,0,0],\"start\":[19,20,26],\"words\":[\"FLAT\",\"CUSHION\",\"PAJAMAS\"],\"zh\":[\"平坦\",\"靠垫\",\"睡衣\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,0,0,4,0,3,4,0,3,0,0,5,0,2,0,5,6,0,0,0,4,0,7,2,0,0,5,2,4,3,0,0,0,0],\"start\":[4,5,10],\"words\":[\"FRIEND\",\"SANDWICH\",\"EYE\"],\"zh\":[\"朋友\",\"三明治\",\"眼睛\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[5,0,0,0,0,0,0,2,0,0,5,0,2,0,0,0,4,3,7,5,3,0,0,0,0,6,0,0,2,4,4,0,0,0,3,4,0],\"start\":[26,31,32],\"words\":[\"DICE\",\"BROOM\",\"FACE\"],\"zh\":[\"骰子\",\"扫帚\",\"脸\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[3,3,0,0,0,2,0,0,0,0,0,0,0,4,0,0,2,7,0,0,4,0,0,5,6,5,4,0,2,0,3,0,0,4,0,0,5],\"start\":[3,6,7],\"words\":[\"BEER\",\"JET\",\"SOUND\"],\"zh\":[\"啤酒\",\"喷气机\",\"声音\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,3,4,4,7,0,6,2,5,4,3,0,0,0,5,0,0,0,0,0,0,3,5,0,0,0,0,4,0,2,2,0,0,0],\"start\":[19,20,26],\"words\":[\"ASTEROID\",\"SAMBA\",\"LAKE\"],\"zh\":[\"小行星\",\"桑巴\",\"湖\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[3,2,0,0,4,0,0,0,0,0,5,4,0,0,0,7,3,2,5,4,0,4,0,3,0,5,0,0,0,0,6,2,0,0,0,0,0],\"start\":[6,7,12],\"words\":[\"HEART\",\"NIGHT\",\"SOLE\"],\"zh\":[\"心脏\",\"夜晚\",\"鞋底\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[3,0,0,0,2,4,0,5,3,0,0,4,2,3,0,0,0,0,5,6,4,0,0,0,0,4,2,0,0,5,0,0,0,0,0,0,7],\"start\":[16,17,23],\"words\":[\"LIME\",\"WATERMELON\",\"TIE\"],\"zh\":[\"青柠\",\"西瓜\",\"领带\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,2,0,0,0,0,4,0,0,0,0,0,0,0,4,0,3,0,3,7,3,0,0,4,5,6,5,0,0,5,2,4,0,2,0,0,0],\"start\":[10,11,17],\"words\":[\"HAIR\",\"WAX\",\"OBSTACLE\"],\"zh\":[\"头发\",\"蜡\",\"障碍\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[4,0,0,0,0,4,5,4,0,5,2,7,4,0,0,0,0,0,6,0,0,0,2,5,3,3,0,0,0,3,0,2,0,0,0,0,0],\"start\":[13,20,21],\"words\":[\"FRINGE\",\"GIRL\",\"SUSHI\"],\"zh\":[\"刘海\",\"女孩\",\"寿司\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[2,0,0,3,0,4,6,4,0,0,5,0,3,3,0,0,0,0,4,2,5,0,0,0,4,0,5,0,0,0,2,7,0,0,0,0,0],\"start\":[16,17,23],\"words\":[\"DIRTY\",\"GASOLINE\",\"CHOCOLATE\"],\"zh\":[\"肮脏\",\"汽油\",\"巧克力\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,4,0,0,5,0,3,3,0,0,0,4,2,0,0,0,2,5,0,7,0,0,0,0,6,0,3,0,5,4,2,0,4,0,0,0],\"start\":[10,15,16],\"words\":[\"FRAME\",\"PARTY\",\"ELEVATOR\"],\"zh\":[\"画框\",\"派对\",\"电梯\"]},{\"mode\":\"easy\",\"promo\":false,\"cells\":[0,0,0,0,0,0,2,0,0,2,3,5,0,4,2,0,0,5,0,0,4,0,0,0,0,6,5,4,0,4,0,3,7,0,0,0,3],\"start\":[18,24,30],\"words\":[\"ART\",\"MAST\",\"FIST\"],\"zh\":[\"艺术\",\"桅杆\",\"拳头\"]},{\"mode\":\"easy\",\"promo\":true,\"cells\":[0,2,0,0,0,4,0,4,0,0,2,5,6,0,0,0,0,7,0,0,0,0,4,0,5,0,4,3,0,3,3,2,0,0,0,5,0],\"start\":[13,14,20],\"words\":[\"DELAY\",\"GASOLINE\",\"STATE\"],\"zh\":[\"延误\",\"汽油\",\"州\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,4,0,4,3,3,6,2,7,5,4,0,5,5,0,2,0,0,0,0,3,4,0,0,3,5,0,4,5,4,0,0,2,0,0,2],\"start\":[17,23,24],\"words\":[\"DART\",\"RABBIT\",\"PIRATE\"],\"zh\":[\"飞镖\",\"兔子\",\"海盗\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,4,4,0,2,5,5,3,2,5,4,5,6,4,3,3,4,0,0,0,0,0,0,0,0,0,0,5,0,3,7,0,2,2,0,4],\"start\":[19,20,27],\"words\":[\"RAIN\",\"CROSS\",\"SCORE\"],\"zh\":[\"雨\",\"十字\",\"分数\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[4,0,4,0,0,4,0,0,2,0,4,0,6,3,0,0,0,2,4,2,5,5,0,0,0,5,7,4,5,3,3,0,0,5,3,0,2],\"start\":[16,22,23],\"words\":[\"PEOPLE\",\"CIRCUS\",\"KITCHEN\"],\"zh\":[\"人群\",\"马戏团\",\"厨房\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,2,2,0,0,4,0,5,3,7,5,3,0,6,5,4,2,0,5,3,0,0,4,0,4,4,3,2,0,0,5,4,0,0,0,0,0],\"start\":[23,28,29],\"words\":[\"CATHEDRAL\",\"TRACTOR\",\"LAP\"],\"zh\":[\"大教堂\",\"拖拉机\",\"大腿\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[4,2,2,5,0,0,4,0,0,0,3,0,5,6,0,2,0,0,4,3,0,2,4,0,0,0,4,5,0,3,5,3,7,4,5,0,0],\"start\":[17,23,24],\"words\":[\"KINGDOM\",\"SHERIFF\",\"TRASH\"],\"zh\":[\"王国\",\"警长\",\"垃圾\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[4,5,0,0,4,0,0,0,0,0,3,3,2,3,2,0,5,4,0,0,4,5,2,6,3,5,0,2,4,7,4,0,5,0,0,0,0],\"start\":[3,6,7],\"words\":[\"BOARD\",\"LETTER\",\"DRAWING\"],\"zh\":[\"木板\",\"信\",\"绘画\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,2,0,0,0,4,7,0,0,0,0,4,0,5,3,3,5,3,2,6,2,4,5,3,5,0,5,0,0,2,4,0,0,0,4,0,4],\"start\":[25,31,32],\"words\":[\"BRANCH\",\"DOOR\",\"TV\"],\"zh\":[\"树枝\",\"门\",\"电视\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,0,3,2,0,3,5,6,0,4,4,0,0,0,5,2,0,4,0,0,4,5,0,3,4,3,5,0,2,0,4,7,0,0,2,5],\"start\":[12,13,19],\"words\":[\"SPY\",\"TOURNAMENT\",\"ICE\"],\"zh\":[\"间谍\",\"锦标赛\",\"冰\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[2,0,3,0,0,4,4,0,3,3,4,2,0,0,0,0,4,7,5,6,0,0,5,5,2,5,4,0,5,0,0,2,3,0,0,4,0],\"start\":[3,7,13],\"words\":[\"BASEBALL\",\"DUST\",\"TOURISM\"],\"zh\":[\"棒球\",\"灰尘\",\"旅游\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,0,2,4,0,6,0,0,0,0,5,5,3,4,2,2,0,3,0,4,0,5,5,4,5,0,0,3,3,0,2,4,7,0,4,0],\"start\":[0,5,10],\"words\":[\"PARK\",\"SCHOOL\",\"CAKE\"],\"zh\":[\"公园\",\"学校\",\"蛋糕\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,3,0,0,5,3,2,4,4,0,2,4,5,0,0,0,0,0,4,7,4,2,0,5,6,0,4,0,5,2,5,0,0,0,3,0,3],\"start\":[15,16,17],\"words\":[\"ERASER\",\"IRON\",\"ROAD\"],\"zh\":[\"橡皮\",\"铁\",\"道路\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[2,5,3,0,0,4,4,3,0,5,7,0,0,0,0,0,5,4,0,0,0,0,0,2,5,3,4,3,2,6,0,5,0,2,4,0,4],\"start\":[12,13,20],\"words\":[\"COACH\",\"SINGER\",\"POCKET\"],\"zh\":[\"教练\",\"歌手\",\"口袋\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[3,0,5,7,5,4,4,2,5,2,0,3,4,0,4,4,3,5,0,4,0,0,0,5,0,0,6,0,0,2,0,3,0,0,0,0,2],\"start\":[24,25,30],\"words\":[\"RISK\",\"CLOCK\",\"MOVIE\"],\"zh\":[\"风险\",\"时钟\",\"影片\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[2,5,4,3,0,6,4,0,0,2,4,0,0,0,0,0,5,7,5,5,3,4,5,3,4,0,2,0,0,0,2,0,0,4,0,3,0],\"start\":[7,8,13],\"words\":[\"PROOF\",\"MAMMOTH\",\"ATTACHMENT\"],\"zh\":[\"证据\",\"猛犸象\",\"附件\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,4,0,5,2,5,3,0,4,7,0,6,0,3,2,4,4,4,4,2,0,2,0,5,0,0,3,5,0,3,0,0,0,0,5,0],\"start\":[26,31,32],\"words\":[\"ERROR\",\"BAG\",\"FOLKS\"],\"zh\":[\"错误\",\"袋子\",\"人们\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,0,2,3,5,4,0,3,5,3,0,0,5,6,2,4,0,0,0,4,0,0,2,0,3,7,2,0,4,4,5,5,0,0,4,0],\"start\":[11,17,18],\"words\":[\"STAR\",\"BATHTUB\",\"HUMIDIFIER\"],\"zh\":[\"星星\",\"浴缸\",\"加湿器\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[5,2,0,0,0,0,0,3,0,4,4,5,0,4,2,0,3,6,3,0,4,3,0,0,0,4,2,5,0,0,5,7,0,0,2,5,4],\"start\":[22,23,29],\"words\":[\"PILOT\",\"NIGHTMARE\",\"ROOM\"],\"zh\":[\"飞行员\",\"噩梦\",\"房间\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[3,4,3,0,0,0,0,0,0,2,7,2,0,4,4,0,4,3,5,6,5,2,0,5,0,5,0,0,0,3,2,5,4,4,0,0,0],\"start\":[6,7,12],\"words\":[\"OCEAN\",\"ZIPPER\",\"BIRD\"],\"zh\":[\"海洋\",\"拉链\",\"鸟\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[2,0,0,0,5,3,4,2,4,0,3,0,5,0,0,0,0,4,6,0,0,2,0,3,5,4,0,0,4,7,3,4,5,0,0,5,2],\"start\":[20,26,27],\"words\":[\"AVOCADO\",\"THIEF\",\"BLUE\"],\"zh\":[\"牛油果\",\"小偷\",\"蓝色\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,4,2,0,2,0,4,6,0,0,0,5,4,0,0,3,3,0,0,0,3,2,0,5,4,5,0,4,0,3,4,5,2,0,5,0,7],\"start\":[5,10,17],\"words\":[\"EAR\",\"ROCK\",\"CRUISE\"],\"zh\":[\"耳朵\",\"岩石\",\"游轮\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[2,0,4,5,4,6,3,0,7,0,3,5,4,3,0,0,0,4,0,2,0,0,0,0,0,3,2,0,5,5,0,4,0,4,5,0,2],\"start\":[15,16,23],\"words\":[\"WAIST\",\"ALLIGATOR\",\"DOCUMENT\"],\"zh\":[\"腰\",\"短吻鳄\",\"文件\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,5,2,3,0,0,6,0,3,3,0,4,2,0,0,0,5,4,4,5,0,5,0,0,4,5,4,0,7,2,2,4,0,3,0,0],\"start\":[1,5,11],\"words\":[\"COW\",\"BODY\",\"ORGAN\"],\"zh\":[\"奶牛\",\"身体\",\"器官\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,7,4,4,3,3,5,3,0,0,0,2,2,3,4,0,5,5,5,5,4,0,0,4,2,0,2,0,0,6,0,0,4,0,0,0],\"start\":[16,22,23],\"words\":[\"EDITOR\",\"CELL\",\"MILK\"],\"zh\":[\"编辑\",\"细胞\",\"牛奶\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,0,4,4,0,0,5,3,0,0,2,4,4,6,2,4,0,5,5,3,5,0,0,0,3,0,0,2,7,3,2,0,0,0,5,4],\"start\":[1,5,6],\"words\":[\"BALD\",\"LADYBIRD\",\"PUBLISH\"],\"zh\":[\"秃头\",\"瓢虫\",\"出版\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[2,2,0,0,4,3,5,6,4,0,0,3,5,0,3,2,7,5,4,3,0,5,0,4,0,4,0,4,5,2,0,0,0,0,0,0,0],\"start\":[26,30,31],\"words\":[\"DELAY\",\"LANDFILL\",\"PASTA\"],\"zh\":[\"延误\",\"垃圾填埋场\",\"意大利面\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,0,0,2,5,4,5,5,0,4,3,3,4,2,7,0,2,5,6,3,0,4,0,0,0,4,0,0,0,5,2,0,0,0,3,4],\"start\":[23,29,33],\"words\":[\"SHOELACE\",\"CHURCH\",\"VIOLIN\"],\"zh\":[\"鞋带\",\"教堂\",\"小提琴\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[3,0,2,7,0,3,0,5,4,4,5,0,5,0,0,0,4,4,3,0,4,2,0,5,2,4,6,0,2,0,0,0,3,0,5,0,0],\"start\":[30,31,35],\"words\":[\"HOCKEY\",\"FEATHER\",\"ELEPHANT\"],\"zh\":[\"曲棍球\",\"羽毛\",\"大象\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,0,0,0,5,2,0,7,0,5,2,3,5,2,5,4,3,0,0,4,0,2,4,0,0,0,5,6,4,0,4,0,3,0,4,3],\"start\":[18,25,30],\"words\":[\"BIB\",\"AXE\",\"LIZARD\"],\"zh\":[\"围兜\",\"斧头\",\"蜥蜴\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,0,0,3,0,0,0,5,5,4,4,4,4,5,0,0,3,0,6,0,0,2,7,0,4,2,3,0,4,2,5,2,0,3,0,5],\"start\":[0,5,6],\"words\":[\"CALCULATOR\",\"METAL\",\"TELEPHONE\"],\"zh\":[\"计算器\",\"金属\",\"电话\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,5,0,5,0,7,4,3,4,0,3,2,6,0,2,5,0,3,0,2,0,4,0,0,4,0,0,4,0,5,0,3,0,5,4,2],\"start\":[23,29,33],\"words\":[\"SPONGE\",\"PASSWORD\",\"COMPANY\"],\"zh\":[\"海绵\",\"密码\",\"公司\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[4,0,0,5,3,5,4,3,0,7,3,4,0,0,5,2,3,0,0,5,6,2,4,0,0,0,4,2,0,4,0,5,0,2,0,0,0],\"start\":[12,17,18],\"words\":[\"STUDENT\",\"FIRE\",\"PICNIC\"],\"zh\":[\"学生\",\"火\",\"野餐\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,3,0,4,0,4,2,6,3,5,2,4,5,0,0,0,4,4,3,0,2,7,0,0,0,3,5,0,0,0,0,5,0,4,5,2,0],\"start\":[23,24,29],\"words\":[\"MARKET\",\"BALLOON\",\"AIRPORT\"],\"zh\":[\"市场\",\"气球\",\"机场\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[4,0,0,0,2,5,0,0,5,3,4,0,0,4,4,5,4,0,0,2,0,0,3,3,0,5,7,0,0,5,3,6,0,4,2,0,2],\"start\":[2,6,12],\"words\":[\"BUSH\",\"GLOBE\",\"DISCO\"],\"zh\":[\"灌木\",\"地球仪\",\"迪斯科\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,4,0,5,0,2,0,2,0,2,3,7,5,0,0,5,0,0,0,0,0,0,3,4,6,0,0,0,5,3,4,4,5,2,4,3,4],\"start\":[13,14,20],\"words\":[\"UNIVERSE\",\"TIDE\",\"HOUSE\"],\"zh\":[\"宇宙\",\"潮汐\",\"房子\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[5,0,4,0,7,3,0,0,2,2,0,3,6,5,4,0,4,4,3,0,0,0,4,5,5,0,0,0,0,3,4,0,2,0,0,2,5],\"start\":[20,25,26],\"words\":[\"MECHANICS\",\"TAXI\",\"SCAR\"],\"zh\":[\"机械\",\"出租车\",\"伤疤\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,3,0,4,5,0,4,2,3,0,0,3,0,0,0,2,6,0,5,4,2,0,5,0,0,5,0,0,0,5,3,4,7,4,4,0,2],\"start\":[23,24,28],\"words\":[\"RAINBOW\",\"GUITAR\",\"SMILE\"],\"zh\":[\"彩虹\",\"吉他\",\"微笑\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[2,0,0,0,2,6,3,0,2,7,5,0,5,0,0,3,4,4,0,0,0,4,0,2,0,5,3,4,0,3,0,0,4,4,5,5,0],\"start\":[13,19,20],\"words\":[\"BOY\",\"DOG\",\"ACCESS\"],\"zh\":[\"男孩\",\"狗\",\"入口\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[5,0,3,4,0,3,0,7,4,6,0,2,2,4,0,0,5,5,4,4,3,2,2,0,0,0,0,4,0,0,3,5,0,0,0,5,0],\"start\":[23,24,29],\"words\":[\"INTERN\",\"WOLF\",\"MATTRESS\"],\"zh\":[\"实习生\",\"狼\",\"床垫\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,0,0,4,5,0,0,0,0,6,4,0,4,0,4,2,3,4,5,3,0,2,5,7,5,0,2,0,4,3,0,3,0,0,2,5],\"start\":[6,7,12],\"words\":[\"QUEEN\",\"RIVER\",\"CASH\"],\"zh\":[\"女王\",\"河\",\"现金\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,2,0,2,7,6,5,5,0,0,0,3,4,0,0,0,2,3,5,0,0,5,0,4,4,0,0,0,4,0,2,5,4,4,3,0,3],\"start\":[13,20,26],\"words\":[\"PINK\",\"BLANKET\",\"STAIRS\"],\"zh\":[\"粉色\",\"毯子\",\"楼梯\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[5,4,0,2,0,3,0,5,3,0,3,5,4,6,0,0,3,5,2,0,5,0,0,0,4,4,0,7,0,0,4,0,2,0,2,0,4],\"start\":[23,28,29],\"words\":[\"CAPITAL\",\"GOOD\",\"FROG\"],\"zh\":[\"首都\",\"良好\",\"青蛙\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[7,2,3,4,4,3,4,4,0,2,0,5,0,3,0,0,2,4,5,0,0,0,5,4,5,0,0,3,2,6,0,0,0,0,0,0,5],\"start\":[19,20,26],\"words\":[\"STEM\",\"ACADEMY\",\"TABLE\"],\"zh\":[\"茎\",\"学院\",\"桌子\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[4,0,4,5,2,5,4,3,0,0,3,6,0,2,3,0,0,0,0,5,5,0,0,0,4,7,3,5,2,0,4,0,2,0,4,0,0],\"start\":[23,29,33],\"words\":[\"STEP\",\"ARENA\",\"FACULTY\"],\"zh\":[\"台阶\",\"竞技场\",\"院系\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[4,3,0,0,0,0,5,4,0,0,3,4,3,0,0,0,2,0,3,5,2,0,0,0,5,5,0,4,0,0,4,7,6,4,2,5,2],\"start\":[23,28,29],\"words\":[\"DOLL\",\"SHEET\",\"PHOTO\"],\"zh\":[\"玩偶\",\"床单\",\"照片\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,4,0,0,5,0,0,0,0,3,0,0,0,2,0,4,2,5,3,3,7,3,5,0,6,5,4,2,4,5,2,0,0,0,4,4],\"start\":[6,7,12],\"words\":[\"TRIANGLE\",\"CURTAIN\",\"BEACH\"],\"zh\":[\"三角形\",\"窗帘\",\"海滩\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,2,4,0,0,4,3,5,3,0,2,7,0,4,5,5,0,4,0,0,3,5,0,6,5,3,4,0,0,0,0,2,0,0,0,2,4],\"start\":[29,30,34],\"words\":[\"MOTOR\",\"SAFE\",\"FISH\"],\"zh\":[\"发动机\",\"保险箱\",\"鱼\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[5,0,0,0,3,0,0,0,0,5,2,0,4,3,0,0,0,0,3,7,0,0,5,3,4,4,6,2,4,2,4,4,2,5,0,0,5],\"start\":[3,6,7],\"words\":[\"BOOK\",\"WELDER\",\"HURT\"],\"zh\":[\"书\",\"焊工\",\"受伤\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[4,0,5,0,0,5,0,2,0,5,0,6,4,5,0,0,0,0,4,0,2,0,2,4,0,3,7,3,3,0,4,4,5,2,0,3,0],\"start\":[10,16,17],\"words\":[\"CLAY\",\"OIL\",\"POOL\"],\"zh\":[\"黏土\",\"油\",\"泳池\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[0,0,3,3,0,0,5,2,2,0,0,0,5,7,0,6,4,3,0,2,4,0,2,4,0,5,4,0,0,3,0,4,4,5,5,0,0],\"start\":[1,5,11],\"words\":[\"SALT\",\"DRAIN\",\"TORNADO\"],\"zh\":[\"盐\",\"排水管\",\"龙卷风\"]},{\"mode\":\"standard\",\"promo\":true,\"cells\":[2,4,0,2,0,4,3,4,0,0,0,0,0,0,3,5,4,6,4,0,5,0,5,0,0,2,3,5,2,0,3,7,0,5,4,0,0],\"start\":[12,13,19],\"words\":[\"MUSIC\",\"KOALA\",\"ANIMAL\"],\"zh\":[\"音乐\",\"考拉\",\"动物\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,9,5,2,5,0,9,8,0,0,0,8,0,0,0,0,0,5,9,5,8,0,0,0,0,8,0,9,0,0,6,0,0,2,5,5],\"start\":[11,16,17],\"words\":[\"KEY\",\"RAIL\",\"COMPUTER\"],\"zh\":[\"钥匙\",\"铁轨\",\"电脑\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,9,0,0,2,0,0,0,5,0,0,0,0,0,0,8,5,0,5,8,5,0,5,8,2,9,0,8,0,0,0,9,0,5,9,0,6],\"start\":[3,7,13],\"words\":[\"YOLK\",\"WORLD\",\"CARD\"],\"zh\":[\"蛋黄\",\"世界\",\"卡片\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,2,0,8,0,0,0,9,5,0,0,0,0,0,8,0,5,0,0,5,0,0,9,0,5,8,0,9,0,5,0,9,5,2,0,8,6],\"start\":[4,10,11],\"words\":[\"COLOR\",\"NEIGHBOR\",\"TOUR\"],\"zh\":[\"颜色\",\"邻居\",\"巡游\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,5,2,0,9,9,5,0,0,5,0,0,0,0,8,8,0,2,0,0,9,0,8,5,0,0,5,0,9,0,5,0,6,8,0,0],\"start\":[20,26,32],\"words\":[\"KNIGHT\",\"LINEN\",\"CUTICLE\"],\"zh\":[\"骑士\",\"亚麻\",\"角质层\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,2,8,9,6,0,0,5,0,8,0,0,0,5,9,5,0,0,0,0,5,0,5,0,8,0,0,0,0,0,0,0,9,9,8,5,2],\"start\":[25,29,30],\"words\":[\"LAW\",\"PEN\",\"WIG\"],\"zh\":[\"法律\",\"钢笔\",\"假发\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,5,0,8,0,8,6,0,9,0,9,9,8,0,0,2,0,0,0,5,0,5,0,0,8,5,0,5,2,5,0,0,0,0,0,9,0],\"start\":[26,31,36],\"words\":[\"TRAIN\",\"SALMON\",\"CROW\"],\"zh\":[\"火车\",\"鲑鱼\",\"乌鸦\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[5,0,0,9,0,0,0,0,5,0,0,8,9,0,0,5,0,0,0,8,9,2,9,0,0,0,0,5,8,0,6,5,0,5,2,8,0],\"start\":[4,5,10],\"words\":[\"CHALK\",\"SHARK\",\"JELLY\"],\"zh\":[\"粉笔\",\"鲨鱼\",\"果冻\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[8,0,0,0,5,0,0,0,9,8,0,0,8,5,0,9,0,5,0,0,0,2,5,2,0,9,0,5,9,8,5,0,6,0,0,0,0],\"start\":[2,6,7],\"words\":[\"ELBOW\",\"JEANS\",\"SNEAKERS\"],\"zh\":[\"手肘\",\"牛仔裤\",\"运动鞋\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[5,2,5,8,8,0,0,0,9,5,0,0,0,0,8,9,0,0,0,0,9,2,5,0,0,8,0,0,0,0,5,6,9,0,0,5,0],\"start\":[17,23,29],\"words\":[\"VULTURE\",\"FILM\",\"CITY\"],\"zh\":[\"秃鹫\",\"电影\",\"城市\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,0,6,0,8,0,0,0,8,0,0,9,0,0,9,9,0,0,8,5,2,5,0,5,9,5,0,0,0,8,0,2,0,5,5,0],\"start\":[23,29,33],\"words\":[\"TRAIL\",\"BLOOD\",\"HAT\"],\"zh\":[\"小径\",\"血液\",\"帽子\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[5,0,0,0,9,0,0,0,0,0,8,9,0,0,2,8,0,5,0,8,0,2,0,0,5,0,8,5,0,0,5,9,5,0,0,9,6],\"start\":[23,29,33],\"words\":[\"NEWSPAPER\",\"CAT\",\"WOOD\"],\"zh\":[\"报纸\",\"猫\",\"木头\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[9,0,0,0,0,9,8,0,0,6,0,0,9,0,5,0,5,0,8,5,0,0,2,0,9,5,5,0,0,0,0,5,2,8,8,0,0],\"start\":[3,7,13],\"words\":[\"NEUTRON\",\"BAT\",\"FIELD\"],\"zh\":[\"中子\",\"蝙蝠\",\"田野\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[8,0,5,0,0,8,0,8,0,9,5,5,5,0,0,2,0,9,0,5,0,9,0,0,0,0,5,0,0,0,6,0,0,8,2,0,9],\"start\":[13,14,20],\"words\":[\"HARBOR\",\"MOLD\",\"STATE\"],\"zh\":[\"港口\",\"霉菌\",\"州\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,6,9,8,0,9,8,9,0,0,5,0,2,0,0,0,8,0,0,0,5,0,0,0,0,0,8,0,5,9,0,5,2,5,5,0],\"start\":[10,15,16],\"words\":[\"HORN\",\"MUTE\",\"SNOW\"],\"zh\":[\"号角\",\"沉默\",\"雪\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,0,5,9,5,0,0,9,2,0,8,5,0,0,0,5,0,6,0,0,0,5,9,0,0,9,0,8,0,0,0,5,0,8,8,2],\"start\":[7,13,14],\"words\":[\"BRONZE\",\"SOCCER\",\"DOMINO\"],\"zh\":[\"青铜\",\"足球\",\"多米诺\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,5,5,0,0,0,9,6,2,5,0,0,9,0,8,8,0,0,0,8,0,0,0,0,0,9,8,0,5,0,5,0,9,0,5,0,2],\"start\":[16,22,23],\"words\":[\"TIP\",\"BEAT\",\"DICTIONARY\"],\"zh\":[\"小费\",\"节拍\",\"词典\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[9,0,9,0,8,8,5,0,0,2,5,5,0,0,0,9,0,0,0,0,0,0,5,0,9,0,0,0,0,8,5,0,0,8,6,2,5],\"start\":[20,21,26],\"words\":[\"CUTTER\",\"BEAR\",\"TREE\"],\"zh\":[\"切割机\",\"熊\",\"树\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,5,2,0,9,9,5,0,0,5,0,0,0,0,8,8,0,2,0,0,9,0,8,5,0,0,5,0,9,0,5,0,6,8,0,0],\"start\":[20,26,32],\"words\":[\"PLUMBER\",\"INN\",\"BLIND\"],\"zh\":[\"水管工\",\"旅馆\",\"失明\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,0,6,0,8,0,0,0,8,0,0,9,0,0,9,9,0,0,8,5,2,5,0,5,9,5,0,0,0,8,0,2,0,5,5,0],\"start\":[23,29,33],\"words\":[\"GAME\",\"FRECKLE\",\"TIME\"],\"zh\":[\"游戏\",\"雀斑\",\"时间\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[8,5,5,0,0,9,5,0,2,5,0,0,0,0,0,8,0,0,0,5,6,8,9,0,5,8,0,0,0,2,0,9,9,0,0,0,0],\"start\":[10,11,18],\"words\":[\"BROCCOLI\",\"LEG\",\"TOOL\"],\"zh\":[\"西兰花\",\"腿\",\"工具\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,8,0,5,0,0,0,9,0,0,0,5,0,9,0,2,9,0,5,0,0,0,0,0,8,0,5,2,0,8,5,9,8,5,0,0,6],\"start\":[10,17,23],\"words\":[\"AGREEMENT\",\"CLIFF\",\"RAFT\"],\"zh\":[\"协议\",\"悬崖\",\"木筏\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[5,6,0,0,2,0,0,9,5,0,0,0,8,0,5,9,0,0,0,9,0,5,8,9,0,0,0,5,0,8,0,0,0,8,5,2,0],\"start\":[25,26,32],\"words\":[\"AUTHOR\",\"LIBRARY\",\"CHAIN\"],\"zh\":[\"作者\",\"图书馆\",\"链条\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,0,9,0,5,2,9,9,8,0,0,5,8,5,9,6,0,0,0,2,5,0,0,0,0,5,0,8,0,0,0,5,8,0,0,0],\"start\":[24,29,30],\"words\":[\"CANDLE\",\"BATTLE\",\"NETWORK\"],\"zh\":[\"蜡烛\",\"战斗\",\"网络\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[5,8,2,9,8,0,0,0,0,0,0,0,9,5,6,0,9,5,0,8,0,5,0,8,9,0,0,0,5,0,0,0,0,0,2,5,0],\"start\":[26,31,36],\"words\":[\"TIGER\",\"BALANCE\",\"KOALA\"],\"zh\":[\"老虎\",\"平衡\",\"考拉\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,0,6,8,0,0,9,2,2,9,8,5,0,8,5,0,0,0,0,5,5,9,9,0,0,8,5,0,0,5,0,0,0,0,0,0],\"start\":[25,31,32],\"words\":[\"FREIGHT\",\"DEEP\",\"CASHIER\"],\"zh\":[\"货运\",\"深处\",\"收银员\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[9,0,0,0,5,0,0,0,9,2,0,5,0,8,0,5,0,0,0,0,0,8,9,8,9,0,5,0,0,8,0,6,0,0,5,2,5],\"start\":[6,7,12],\"words\":[\"CRUST\",\"OFFICE\",\"STOVE\"],\"zh\":[\"外壳\",\"办公室\",\"炉灶\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[9,5,8,0,0,0,5,0,0,2,5,0,9,0,0,0,9,5,0,0,9,5,8,6,0,0,0,0,0,8,0,8,2,5,0,0,0],\"start\":[13,14,19],\"words\":[\"PENDULUM\",\"MONSTER\",\"TEMPLE\"],\"zh\":[\"钟摆\",\"怪兽\",\"寺庙\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,0,8,2,0,0,0,0,5,9,0,0,0,0,0,9,5,5,5,0,9,0,8,6,0,0,8,0,0,2,8,0,0,5,5,9],\"start\":[13,14,20],\"words\":[\"BRAND\",\"DUCK\",\"FABRIC\"],\"zh\":[\"品牌\",\"鸭\",\"织物\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[2,0,8,0,0,0,0,0,0,0,9,5,0,5,5,9,5,8,5,0,0,0,0,6,0,0,0,2,8,0,0,8,0,9,9,0,5],\"start\":[3,6,7],\"words\":[\"STRAW\",\"NOTE\",\"VOICE\"],\"zh\":[\"稻草\",\"笔记\",\"嗓音\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,2,0,9,8,8,0,2,0,5,5,0,0,0,9,0,5,5,5,0,8,9,0,0,0,0,0,0,0,0,0,6,5,0,8,0,9],\"start\":[23,29,33],\"words\":[\"CHILD\",\"PHRASE\",\"TOWER\"],\"zh\":[\"孩子\",\"短语\",\"塔\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,8,0,5,9,0,8,0,9,8,0,5,0,9,2,0,0,0,5,0,5,8,0,0,0,0,0,0,9,5,0,0,5,6,2,0],\"start\":[25,26,32],\"words\":[\"HOSE\",\"IMAGE\",\"CHAIR\"],\"zh\":[\"水管\",\"图像\",\"椅子\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,0,2,0,0,0,0,5,9,0,2,5,0,9,9,8,0,0,5,0,0,8,5,9,0,0,0,0,5,8,0,0,5,8,6,0],\"start\":[20,21,26],\"words\":[\"PUPPY\",\"COMFORT\",\"SHEEP\"],\"zh\":[\"小狗\",\"舒适\",\"羊\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[5,0,0,8,8,9,8,5,0,0,0,0,0,6,2,0,0,9,0,5,0,9,5,0,0,0,8,9,5,0,0,2,0,5,0,0,0],\"start\":[10,15,16],\"words\":[\"IVORY\",\"BATTERY\",\"CLEAR\"],\"zh\":[\"象牙\",\"电池\",\"清澈\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[9,2,0,0,0,0,5,0,0,6,2,0,0,0,0,9,5,8,5,0,5,5,0,0,9,8,0,8,5,0,9,0,0,8,0,0,0],\"start\":[26,31,32],\"words\":[\"DREAM\",\"ANIMAL\",\"HELICOPTER\"],\"zh\":[\"梦\",\"动物\",\"直升机\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,2,5,9,5,5,0,8,0,5,8,0,0,0,2,8,0,0,0,0,5,0,0,0,0,0,9,0,5,0,0,0,0,9,9,8,6],\"start\":[24,29,30],\"words\":[\"TRAVEL\",\"FLOWER\",\"COLD\"],\"zh\":[\"旅行\",\"花\",\"寒冷\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[5,5,0,2,5,0,8,0,9,0,0,8,0,9,9,0,0,0,0,6,0,5,0,0,5,0,9,0,0,0,5,0,8,0,8,0,2],\"start\":[16,17,23],\"words\":[\"BATH\",\"HOTEL\",\"KNEE\"],\"zh\":[\"洗澡\",\"酒店\",\"膝盖\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,8,0,5,0,0,0,9,0,0,0,5,0,9,0,2,9,0,5,0,0,0,0,0,8,0,5,2,0,8,5,9,8,5,0,0,6],\"start\":[10,17,23],\"words\":[\"TEAPOT\",\"MOTH\",\"PARODY\"],\"zh\":[\"茶壶\",\"飞蛾\",\"戏仿\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,0,2,6,0,0,5,0,0,0,5,0,0,5,9,9,0,0,0,8,5,8,0,9,5,0,2,0,0,5,0,9,0,8,0,8],\"start\":[23,29,33],\"words\":[\"HALL\",\"THRONE\",\"LOYALTY\"],\"zh\":[\"大厅\",\"王座\",\"忠诚\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[2,0,0,0,0,0,5,0,0,2,9,0,5,0,0,8,0,0,8,0,0,5,0,0,0,5,9,0,8,5,0,6,5,8,0,9,9],\"start\":[13,14,20],\"words\":[\"MOON\",\"GEAR\",\"SATELLITE\"],\"zh\":[\"月亮\",\"齿轮\",\"卫星\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,5,0,0,0,2,9,0,5,0,0,0,5,9,0,0,8,6,0,0,0,8,8,0,9,0,0,5,2,5,0,0,0,5,9,8,0],\"start\":[26,31,32],\"words\":[\"CREAM\",\"LOADER\",\"ACTOR\"],\"zh\":[\"奶油\",\"装载机\",\"演员\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,0,5,9,5,0,0,9,2,0,8,5,0,0,0,5,0,6,0,0,0,5,9,0,0,9,0,8,0,0,0,5,0,8,8,2],\"start\":[7,13,14],\"words\":[\"BICYCLE\",\"CLOTH\",\"STAPLE\"],\"zh\":[\"自行车\",\"布\",\"订书钉\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[5,9,0,5,0,8,8,0,0,0,8,0,0,0,9,0,2,5,0,9,0,2,6,5,0,0,9,0,0,5,0,5,8,0,0,0,0],\"start\":[24,30,34],\"words\":[\"HORSE\",\"UNIFORM\",\"CLUB\"],\"zh\":[\"马\",\"制服\",\"俱乐部\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[5,2,5,5,8,0,8,5,0,6,0,0,0,9,0,2,9,5,8,0,0,0,5,0,9,0,0,0,9,0,0,0,0,0,0,0,8],\"start\":[26,31,32],\"words\":[\"PIANO\",\"COAL\",\"GARDEN\"],\"zh\":[\"钢琴\",\"煤\",\"花园\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[5,2,5,8,8,0,0,0,9,5,0,0,0,0,8,9,0,0,0,0,9,2,5,0,0,8,0,0,0,0,5,6,9,0,0,5,0],\"start\":[17,23,29],\"words\":[\"PEPPER\",\"FLASH\",\"ANKLE\"],\"zh\":[\"胡椒\",\"闪光\",\"脚踝\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,9,0,8,2,0,0,9,0,5,0,0,5,8,0,0,0,0,0,5,0,2,0,0,5,0,9,6,8,5,0,8,0,5,0,0,9],\"start\":[17,22,23],\"words\":[\"ALTITUDE\",\"FATHER\",\"SHIRT\"],\"zh\":[\"海拔\",\"父亲\",\"衬衫\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,6,8,0,9,2,5,0,5,0,8,0,0,0,0,0,5,0,5,9,0,2,0,0,9,5,5,0,0,8,0,0,0,8,0,9,0],\"start\":[30,31,34],\"words\":[\"TEETH\",\"STRIPE\",\"RATE\"],\"zh\":[\"牙齿\",\"条纹\",\"比率\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[2,0,0,0,0,5,0,0,0,0,9,6,8,0,8,0,9,5,0,0,9,5,5,0,5,0,8,2,8,0,0,5,0,0,0,0,9],\"start\":[23,29,33],\"words\":[\"LOLLIPOP\",\"MARS\",\"TROOP\"],\"zh\":[\"棒棒糖\",\"火星\",\"部队\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[2,0,0,8,5,0,0,0,0,0,0,8,5,0,0,0,6,9,0,0,0,9,9,0,9,5,8,0,5,0,2,0,5,0,0,8,5],\"start\":[13,14,20],\"words\":[\"CORE\",\"ANTHEM\",\"GUM\"],\"zh\":[\"核心\",\"颂歌\",\"口香糖\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[0,0,0,2,0,8,5,9,0,8,0,0,5,0,0,5,0,0,0,6,8,0,5,0,0,5,0,9,9,9,0,8,0,5,0,0,2],\"start\":[16,17,23],\"words\":[\"PLANT\",\"CAGE\",\"ISLAND\"],\"zh\":[\"植物\",\"笼子\",\"岛屿\"]},{\"mode\":\"competitive\",\"promo\":false,\"cells\":[8,0,0,5,0,0,9,5,0,5,5,0,8,0,9,2,0,0,0,0,0,0,2,5,0,0,0,0,5,6,9,8,0,0,8,0,9],\"start\":[20,21,26],\"words\":[\"MUSIC\",\"SPRING\",\"DISH\"],\"zh\":[\"音乐\",\"春天\",\"盘子\"]},{\"mode\":\"competitive\",\"promo\":true,\"cells\":[0,5,0,0,2,0,9,0,0,8,9,8,0,0,0,8,0,0,5,0,2,0,6,0,0,0,5,0,9,0,0,8,5,9,0,5,5],\"start\":[29,30,34],\"words\":[\"SANDWICH\",\"ACTOR\",\"TORNADO\"],\"zh\":[\"三明治\",\"演员\",\"龙卷风\"]},{\"mode\":\"standard\",\"promo\":false,\"cells\":[3,5,0,5,3,7,2,0,0,0,6,2,5,0,4,4,2,4,5,2,0,0,0,0,4,0,0,0,0,3,3,5,0,4,0,0,4],\"start\":[20,21,26],\"words\":[\"BOMB\",\"KITE\",\"DRUM\"],\"zh\":[\"炸弹\",\"风筝\",\"鼓\"]}]"), b = [
	[-3, 3],
	[-2, 4],
	[-1, 5],
	[0, 6],
	[-3, 1],
	[-2, 2],
	[-1, 3],
	[0, 4],
	[1, 5],
	[-3, -1],
	[-2, 0],
	[-1, 1],
	[0, 2],
	[1, 3],
	[2, 4],
	[-3, -3],
	[-2, -2],
	[-1, -1],
	[0, 0],
	[1, 1],
	[2, 2],
	[3, 3],
	[-2, -4],
	[-1, -3],
	[0, -2],
	[1, -1],
	[2, 0],
	[3, 1],
	[-1, -5],
	[0, -4],
	[1, -3],
	[2, -2],
	[3, -1],
	[0, -6],
	[1, -5],
	[2, -4],
	[3, -3]
], x = b.map(([e, t]) => ({
	x: 400 + e * 90,
	y: 400 - t * 52
})), S = b.map(([e, t], n) => b.flatMap(([r, i], a) => n !== a && (r === e && Math.abs(i - t) === 2 || Math.abs(r - e) === 1 && Math.abs(i - t) === 1) ? [a] : [])), C = "60,0 30,52 -30,52 -60,0 -30,-52 30,-52";
function w(e) {
	return e.flatMap((t, n) => t === null && S[n].some((t) => e[t] !== null) ? [n] : []);
}
//#endregion
//#region src/games/landmarks/meta.ts
var T = {
	id: "landmarks",
	tier: "alpha",
	nameKey: "games.landmarks.name",
	descKey: "games.landmarks.desc",
	rulesKey: "games.landmarks.rules",
	icon: "🧭",
	iconImg: "games/landmarks.webp",
	rulesUrl: { en: "https://cdn.shopify.com/s/files/1/2319/3985/files/Landmarks_-_Rulebook.pdf?v=1723060511" },
	minPlayers: 2,
	maxPlayers: 10,
	bestPlayers: [
		4,
		5,
		6
	],
	mechanics: ["word-association", "tile-placement"],
	interactionTags: [
		"cooperative",
		"team-based",
		"communication-limits"
	],
	accent: "#127d86",
	releasedAt: "2026-11-03T02:15:00+08:00",
	search: {
		py: "shen mi dao yu",
		init: "smdy"
	},
	hotseat: "cover",
	playerRange: (e) => ({
		min: e?.mode === "competitive" ? 4 : 2,
		max: 10
	})
}, E = t.enum([
	"easy",
	"standard",
	"competitive"
]), D = t.object({
	mode: E.default("easy"),
	promo: t.boolean().default(!1),
	words: t.enum(["zh", "en"]).default("zh")
}).default({
	mode: "easy",
	promo: !1,
	words: "zh"
}), O = t.int().min(0).max(1), k = t.int().min(0).max(36), A = t.union([
	t.literal(0),
	t.literal(2),
	t.literal(3),
	t.literal(4),
	t.literal(5),
	t.literal(6),
	t.literal(7),
	t.literal(8),
	t.literal(9)
]), j = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("assign"),
		rid: t.string(),
		team: O,
		guide: t.boolean()
	}),
	t.object({
		type: t.literal("first"),
		team: O
	}),
	t.object({ type: t.literal("start") }),
	t.object({
		type: t.literal("clue"),
		word: t.string().trim().min(1).max(24)
	}),
	t.object({
		type: t.literal("propose"),
		cell: k
	}),
	t.object({
		type: t.literal("place"),
		cell: k
	}),
	t.object({ type: t.literal("continue") })
]), M = t.object({
	players: t.array(t.string()),
	guide: t.string(),
	treasure: t.int().nonnegative(),
	curses: t.int().nonnegative(),
	amulets: t.int().nonnegative()
}), N = t.object({
	cell: k,
	word: t.string(),
	kind: A,
	team: O,
	by: t.string()
}), P = t.object({
	phase: t.enum([
		"setup",
		"clue",
		"place",
		"reveal",
		"done"
	]),
	mode: E,
	players: t.array(t.string()),
	teams: t.array(M),
	turn: O,
	chooser: O,
	firstTeam: O.nullable(),
	words: t.array(t.string().nullable()).length(37),
	revealed: t.array(A.nullable()).length(37),
	starts: t.array(k),
	clue: t.string().nullable(),
	proposal: k.nullable(),
	water: t.int().nonnegative(),
	capacity: t.int().nonnegative(),
	history: t.array(N),
	latest: N.nullable(),
	outcome: t.enum([
		"exit",
		"dry",
		"cursed",
		"treasure"
	]).nullable(),
	winner: O.nullable(),
	finalMap: t.array(A).length(37).nullable()
}), F = t.object({ map: t.array(A).length(37).nullable() }), I = () => ({ code: "games.landmarks.invalid" }), L = (e) => e.normalize("NFKC").trim().toLocaleLowerCase("en"), R = (e, t) => e.teams[t].curses - e.teams[t].amulets, z = (e, t) => R(e, t) >= 2 || R(e, t) > 0 && e.revealed.includes(6);
function B(e, t, n) {
	let r = structuredClone(e), i = e.map[t], a = {
		cell: t,
		word: e.clue,
		kind: i,
		team: e.turn,
		by: n
	};
	r.words[t] = e.clue, r.revealed[t] = i, r.history.push(a), r.latest = a, r.proposal = null, r.phase = "reveal";
	let o = r.teams[r.turn];
	if (i === 2 && o.treasure++, (i === 8 || i === 9) && r.teams[i === 8 ? 0 : 1].treasure++, i === 5 && o.curses++, i === 6 && o.amulets++, e.mode !== "competitive") i === 3 && (r.water = r.capacity), i === 4 && (r.capacity = Math.max(0, r.capacity - 1), r.water = Math.max(0, r.water - 1)), z(r, 0) ? r.outcome = "cursed" : i === 7 ? (r.outcome = "exit", o.treasure > 0 && R(r, 0) <= 0 && (r.winner = 0)) : r.water === 0 && (r.outcome = "dry");
	else {
		let e = r.teams.findIndex((e, t) => z(r, t));
		if (e >= 0) r.outcome = "cursed", r.winner = 1 - e;
		else {
			let e = r.teams.findIndex((e) => e.treasure >= 4);
			e >= 0 && (r.outcome = "treasure", r.winner = R(r, e) > 0 ? 1 - e : e);
		}
	}
	return r;
}
var V = {
	meta: T,
	saveCompatibility: { version: "1" },
	schemas: {
		action: j,
		publicView: P,
		privateView: F,
		config: D
	},
	setup(t, n, r) {
		let i = D.parse(t), a = y.filter((e) => e.mode === i.mode && (i.promo || !e.promo)), o = a[e(r, 0, a.length)], s = i.mode === "competitive", c = s ? e(r, 1, 2) : 0, l = (s ? [n.filter((e, t) => t % 2 == 0), n.filter((e, t) => t % 2 == 1)] : [[...n]]).map((e) => ({
			players: e,
			guide: e[0] ?? "",
			treasure: 0,
			curses: 0,
			amulets: 0
		})), u = Array(37).fill(null);
		return o.start.forEach((e, t) => {
			u[e] = i.words === "zh" ? o.zh[t] : o.words[t];
		}), { state: {
			phase: "setup",
			mode: i.mode,
			players: [...n],
			teams: l,
			turn: c,
			chooser: c,
			firstTeam: s ? null : 0,
			words: u,
			starts: o.start,
			revealed: u.map((e) => e === null ? null : 0),
			map: o.cells,
			clue: null,
			proposal: null,
			water: 7,
			capacity: 7,
			history: [],
			latest: null,
			outcome: null,
			winner: null
		} };
	},
	reduce(e, t, { by: n }) {
		if (!e.players.includes(n) || e.phase === "done") return I();
		if (t.type === "assign") {
			if (e.phase !== "setup" || n !== e.players[0] || !e.players.includes(t.rid) || !e.teams[t.team]) return I();
			let r = structuredClone(e);
			for (let e of r.teams) e.players = e.players.filter((e) => e !== t.rid), e.guide === t.rid && (e.guide = "");
			return r.teams[t.team].players.push(t.rid), t.guide && (r.teams[t.team].guide = t.rid), { state: r };
		}
		if (t.type === "first") return e.phase !== "setup" || e.mode !== "competitive" || !e.teams[e.chooser].players.includes(n) ? I() : { state: {
			...e,
			firstTeam: t.team,
			turn: t.team,
			teams: e.teams.map((e, n) => ({
				...e,
				amulets: n === t.team ? 0 : 1
			}))
		} };
		if (t.type === "start") return e.phase !== "setup" || n !== e.players[0] || e.firstTeam === null || e.teams.some((e) => e.players.length < 2 || !e.players.includes(e.guide)) ? I() : { state: {
			...e,
			phase: "clue"
		} };
		let r = e.teams[e.turn];
		if (t.type === "clue") {
			if (e.phase !== "clue" || n !== r.guide) return I();
			let i = t.word.trim();
			return /\s/u.test(i) || e.words.some((e) => e !== null && L(e) === L(i)) ? { code: "games.landmarks.invalidClue" } : { state: {
				...e,
				phase: "place",
				clue: i,
				proposal: null,
				water: e.mode === "competitive" ? e.water : e.water - 1
			} };
		}
		return t.type === "propose" || t.type === "place" ? e.phase !== "place" || !r.players.includes(n) || n === r.guide || !w(e.words).includes(t.cell) ? I() : t.type === "propose" ? { state: {
			...e,
			proposal: t.cell
		} } : e.proposal === t.cell ? {
			state: B(e, t.cell, n),
			fx: [{
				kind: "placeClue",
				rid: n,
				data: {
					cell: t.cell,
					word: e.clue,
					kind: e.map[t.cell]
				}
			}]
		} : I() : t.type === "continue" ? e.phase !== "reveal" || n !== r.guide ? I() : { state: {
			...e,
			phase: e.outcome ? "done" : "clue",
			turn: e.mode === "competitive" && !e.outcome ? 1 - e.turn : e.turn,
			clue: null
		} } : I();
	},
	viewFor(e, t) {
		let { map: n, ...r } = e;
		return {
			public: {
				...r,
				finalMap: e.phase === "done" ? n : null
			},
			private: { map: e.phase !== "setup" && e.teams.some((e) => e.guide === t) ? n : null }
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = e.winner === null ? [] : e.teams[e.winner].players;
		return {
			phase: "done",
			winner: t,
			ranking: [...t, ...e.players.filter((e) => !t.includes(e))],
			scores: Object.fromEntries(e.teams.flatMap((e) => e.players.map((t) => [t, e.treasure])))
		};
	}
}, H = {
	2: "M8,26 8,28 17,38 17,39 23,45 23,46 24,46 25,45 25,44 23,41 23,37 22,36 22,34 21,33 21,31 20,30 20,29 21,28 23,30 23,31 24,32 24,34 25,35 25,38 27,41 27,43 28,44 28,46 29,47 29,49 31,51 32,51 32,49 33,48 34,45 35,44 36,45 36,46 37,47 38,47 40,45 40,44 44,40 44,39 52,31 52,30 54,28 54,23 49,18 49,17 48,17 47,16 45,16 44,17 42,17 41,16 38,18 36,16 26,16 25,17 24,17 23,16 15,16 10,21 10,22 9,23 9,25ZM39,34 40,35 40,36 39,37 39,40 36,44 35,43 35,41 36,40 36,38 37,37 37,36ZM39,31 39,29 40,28 41,28 42,29 42,30 40,32ZM45,25 46,24 51,24 52,25 51,26 46,26ZM36,25 37,24 38,25 37,26ZM26,25 27,24 32,24 33,25 32,26 27,26ZM11,25 12,24 13,24 14,25 13,26 12,26ZM21,22 22,23 22,25 20,27 17,25ZM40,19 42,21 42,23 44,25 44,26 41,28 39,26 39,24 40,23 39,20ZM23,17 24,18 24,19 22,21 21,20 21,19ZM16,9 17,10 17,11 20,11 20,10 18,8 17,8ZM45,6 42,4 40,6 39,6 36,9 36,10 39,10 40,9 43,8ZM21,3 22,6 24,8 25,8 25,5 24,4 24,2Z",
	3: "M31,2 30,3 29,6 26,10 26,12 25,13 25,14 19,25 19,27 17,29 17,31 16,32 16,35 15,36 15,42 16,43 16,47 21,52 22,52 23,53 25,53 26,54 30,54 31,55 33,55 34,54 39,53 42,50 43,50 43,49 45,47 45,46 46,45 46,33 45,32 44,27 42,25 42,23 40,21 40,19 36,12 36,10 33,6 33,4 32,3 32,2ZM42,35 42,44 41,45 41,46 37,50 36,50 35,51 31,51 30,50 27,50 22,45 24,43 25,44 29,44 30,43 33,43 38,38 38,35 40,33Z",
	4: "M57,33 56,33 56,35 55,36 55,39 54,40 54,43 55,43 56,42 56,41 57,40 57,38 58,37 58,35 57,34ZM5,33 5,34 3,36 2,36 2,37 3,38 3,40 4,41 5,44 7,44 7,36ZM19,28 19,35 20,36 20,37 21,38 22,38 22,37 24,34 23,33 23,31 22,31ZM42,27 39,31 38,30 37,30 37,33 38,34 38,39 40,39 42,37 42,36 44,33 44,30ZM55,16 55,17 49,28 48,33 47,34 44,41 42,43 42,44 43,45 44,45 47,47 50,47 50,41 51,40 51,36 52,35 52,32 53,31 53,28 55,25 55,22 56,21 56,18 55,17ZM8,12 8,17 9,18 9,31 10,32 10,37 11,38 11,47 14,47 15,46 17,46 18,45 19,45 19,43 17,40 17,38 16,37 16,35 15,34 15,32 14,31 14,28 13,27 13,24 12,23 12,20 11,19 11,16 10,15 9,12ZM32,6 31,7 31,10 30,11 30,18 29,19 29,21 28,22 28,26 27,27 27,34 26,35 26,39 25,40 25,42 24,43 24,48 23,49 23,53 22,54 22,56 23,56 24,57 28,57 29,56 35,56 36,55 37,55 37,53 36,52 36,42 35,41 35,33 34,32 34,18 33,17 33,8 32,7Z",
	5: "M14,6 11,9 10,9 9,10 9,11 6,14 6,15 5,16 5,26 6,27 6,32 7,33 7,38 8,39 8,42 9,43 9,46 11,48 14,48 15,47 16,47 18,49 18,53 21,55 22,54 24,54 24,53 23,52 23,49 25,47 26,47 27,48 27,51 26,52 26,53 27,54 30,54 31,53 31,52 30,51 30,48 31,47 32,47 33,48 33,53 34,54 36,54 36,48 38,46 40,48 39,49 39,53 40,54 44,54 45,53 45,47 47,45 49,45 50,46 51,45 53,45 53,35 54,34 53,33 53,31 54,30 54,17 53,16 53,14 52,13 51,10 50,9 49,9 46,6 45,6 40,3 38,3 37,2 31,2 30,1 29,2 23,2 22,3 22,5 23,6 24,6 25,5 28,5 29,6 27,8 27,9 23,13 22,16 18,21 16,19 17,18 17,16 18,15 18,12 16,12 15,13 13,13 12,12 12,10 13,9ZM30,30 32,33 32,36 34,38 34,40 33,41 29,41 27,43 26,43 25,42 26,41 26,40 27,39 27,37 28,36 28,32ZM17,25 20,25 21,26 22,26 25,30 25,34 24,35 24,36 20,39 16,39 11,34 11,31 12,30 12,29 15,26 16,26ZM41,23 46,23 49,26 49,27 50,28 50,32 46,36 41,36 37,33 37,31 36,30 36,29 37,28 37,26Z",
	6: "M26,46 25,47 25,48 26,49 26,53 27,54 28,57 29,57 30,58 34,58 32,56 32,53 36,48 35,47 28,47 27,46ZM46,38 39,45 39,46 43,49 45,49 46,50 51,50 51,49 52,48 51,48 49,46 49,45 48,44 48,41ZM15,38 14,38 12,40 12,42 10,45 10,51 11,51 14,54 13,53 13,49 14,48 16,48 17,47 20,47 21,46 22,46 22,45 21,44 20,44 15,39ZM48,25 48,26 49,27 49,30 48,31 48,35 51,35 52,34 54,34 55,33 56,33 59,30 58,29 58,27 57,28 54,28 49,24ZM12,24 7,25 6,26 5,26 2,29 2,35 2,34 4,31 6,31 7,32 8,32 11,35 12,35 13,34 13,33 12,32ZM10,9 7,13 8,12 11,12 13,15 13,19 15,19 15,18 20,13 20,11 19,11 18,10 16,10 15,9ZM48,8 48,9 46,11 45,11 44,12 41,12 41,14 42,14 45,17 46,20 48,20 49,19 49,17 50,16 50,9 49,9ZM36,6 38,6 40,4 41,4 40,3 37,3 36,4ZM20,3 20,4 21,5 22,5 23,6 24,5 24,4 23,3ZM30,1 29,2 27,2 27,5 28,6 28,8 29,9 29,12 26,14 24,14 18,20 18,21 16,23 16,27 15,28 15,29 16,30 16,34 17,35 17,36 22,41 23,41 26,43 34,43 35,42 37,42 44,35 44,32 45,31 45,25 44,24 44,22 42,20 42,19 38,15 37,15 36,14 34,14 31,12 31,9 32,8 32,6 33,5 33,2 31,2ZM19,23 20,22 22,22 25,25 25,30 26,31 26,32 27,33 33,33 37,37 37,39 36,40 31,40 30,41 29,40 26,40 25,39 24,39 20,35 20,34 18,32 18,25 19,24ZM25,17 26,17 27,16 34,16 35,17 36,17 41,22 41,23 42,24 42,33 40,35 39,35 35,31 35,30 36,29 36,27 33,23 27,23 24,20 24,18Z",
	7: "M32,52 33,53 37,53 38,54 39,54 40,53 40,52 36,52 35,51ZM18,52 30,52 29,52 28,51 24,51 23,52 22,52 21,51 19,51ZM54,46 52,46 51,47 50,47 50,48 49,49 48,48 47,48 44,51 43,51 44,52 45,51 47,51 50,48 52,48ZM45,42 52,42 52,41 49,41 48,42 47,41 46,41ZM2,35 2,36 5,41 5,43 6,43 5,42 5,40 2,36ZM58,23 58,28 57,29 57,33 58,34 58,35 58,31 59,30 58,29ZM39,11 38,12 38,17 37,18 37,22 38,23 38,25 37,26 38,27 38,26 39,25 40,25 41,26 41,29 40,30 37,29 37,30 36,31 37,32 37,38 39,36 41,38 39,40 37,40 37,42 43,42 43,41 42,40 42,38 41,37 41,28 42,27 42,23 41,22 41,21 42,20 42,16 41,17 41,19 39,21 38,20 38,17 39,16 39,14 40,13 40,11ZM39,31 41,33 41,34 39,36 38,35 38,32ZM43,8 43,10 44,10 45,9 46,9 47,10 47,11 46,12 44,12 43,13 43,14 45,14 46,13 49,13 50,14 52,14 51,13 51,11 49,9 46,9 45,8ZM13,7 13,8 14,8 15,9 17,9 20,11 22,11 25,13 27,13 25,11 24,11 17,7 15,7 14,6ZM42,4 41,4 40,3 38,3 31,10 31,12 30,13 31,14 31,19 30,20 29,19 29,18 23,18 22,17 20,17 17,15 13,15 12,14 6,14 6,15 7,16 12,16 13,17 17,17 18,18 23,18 24,19 28,19 29,20 29,32 31,34 30,35 29,35 29,38 28,39 26,39 21,42 18,41 17,42 13,42 11,44 9,44 11,44 12,43 16,43 17,42 18,42 19,43 19,44 17,46 14,46 19,46 20,45 22,45 25,43 31,43 30,42 31,41 31,26 32,25 32,13 33,12 33,10 36,7 36,6 37,5ZM22,42 23,41 24,41 25,42 24,43 23,43ZM30,38 31,39 28,42 27,42 26,41 29,38ZM20,3 20,4 22,4 23,5 24,5 22,3Z",
	8: "M15,17 10,21 10,22 6,26 6,27 7,28 8,31 17,41 18,44 21,47 21,48 24,50 24,51 28,55 28,56 29,57 32,57 33,56 33,55 38,50 38,49 43,44 43,43 48,38 48,37 53,32 53,31 55,29 55,26 54,25 54,24 53,23 52,23 49,19 48,19 47,18 45,18 44,17 40,17 39,18 32,18 31,17ZM29,22 32,22 33,23 33,29 32,30 33,31 32,32 33,33 32,34 32,36 34,39 35,39 36,38 37,38 38,39 38,41 36,43 24,43 23,42 23,40 24,39 27,39 28,38 28,33 30,31 28,29 28,28 27,28 27,29 26,30 25,30 24,29 24,27 26,25 27,26 28,26 28,25 27,24ZM15,10 15,12 16,12 18,14 22,14 17,9 16,9ZM47,7 46,6 43,5 42,6 41,6 38,9 37,9 34,12 33,12 32,13 32,14 36,14 40,11 47,8ZM23,2 22,3 21,3 20,4 20,5 22,7 23,10 24,11 25,11 25,5Z",
	9: "M16,18 15,19 14,19 9,24 8,24 6,26 6,28 8,30 8,31 9,32 10,32 11,33 11,34 15,38 15,39 18,42 19,45 24,50 24,51 28,55 28,56 29,57 31,57 35,53 35,52 38,49 38,48 43,43 43,42 48,37 48,36 55,29 55,27 47,19 46,19 45,18 19,18 18,19 17,19ZM24,23 25,23 26,22 34,22 37,24 37,25 38,26 38,29 37,30 37,31 34,34 33,34 28,38 29,39 30,39 31,38 35,38 36,39 37,39 38,40 38,42 36,44 24,44 22,42 22,38 23,37 23,36 26,33 27,33 32,29 32,27 28,27 26,29 25,28 24,28 22,26 22,25ZM15,10 15,13 18,13 19,14 21,14 21,13 20,12 19,12 17,10ZM46,7 44,5 43,5 39,9 38,9 33,13 37,13 42,10 44,10 46,8ZM24,2 23,2 20,4 20,5 22,7 23,10 24,9Z"
}, U = {
	0: "#718b45",
	2: "#e9bc28",
	3: "#329fc5",
	4: "#b63b92",
	5: "#d74c3f",
	6: "#298569",
	7: "#ede9d8",
	8: "#91b83c",
	9: "#5dacc3"
}, W = {
	0: "games.landmarks.empty",
	2: "games.landmarks.treasure",
	3: "games.landmarks.water",
	4: "games.landmarks.trap",
	5: "games.landmarks.curse",
	6: "games.landmarks.amulet",
	7: "games.landmarks.exit",
	8: "games.landmarks.greenTreasure",
	9: "games.landmarks.blueTreasure"
};
function G({ kind: e, size: t = 32 }) {
	return /* @__PURE__ */ f("svg", {
		width: t,
		height: t,
		viewBox: "0 0 61 61",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ d("path", {
			d: "M30.5 1L57 16V46L30.5 60 4 46V16Z",
			fill: U[e],
			stroke: "#424e36",
			strokeWidth: "1.2"
		}), e !== 0 && /* @__PURE__ */ d("path", {
			d: H[e],
			fill: e === 7 ? "#6b7778" : "#fff",
			fillRule: "evenodd",
			stroke: "#414f48",
			strokeWidth: ".35"
		})]
	});
}
function K({ word: e, discovered: t }) {
	let n = Array.from(e), r = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u.test(e), i = r ? 4 : 10, a = Array.from({ length: Math.ceil(n.length / i) }, (e, t) => n.slice(t * i, (t + 1) * i).join("")), o = r ? a.length > 3 ? 10 : a.length > 1 ? 17 : 22 : Math.min(19, 140 / Math.min(i, n.length)), s = o * 1.18, c = t ? 13 : 2;
	return /* @__PURE__ */ d("text", {
		fill: "#29372d",
		textAnchor: "middle",
		fontSize: o,
		fontWeight: "750",
		fontFamily: "'Microsoft YaHei', 'Segoe UI', sans-serif",
		children: a.map((e, t) => /* @__PURE__ */ d("tspan", {
			x: "0",
			y: c + o * .34 + (t - (a.length - 1) / 2) * s,
			children: e
		}, t))
	});
}
function q({ word: e, kind: t = 0, start: n = !1, proposed: r = !1 }) {
	return /* @__PURE__ */ f(u, { children: [
		/* @__PURE__ */ d("polygon", {
			points: C,
			transform: "translate(0,4) scale(.92)",
			fill: "#475a46",
			opacity: ".5"
		}),
		/* @__PURE__ */ d("polygon", {
			points: C,
			transform: "scale(.92)",
			fill: r ? "#fffdf3" : "#f6f3e6",
			fillOpacity: r ? .75 : 1,
			stroke: "#d9d4bc",
			strokeWidth: "2",
			strokeDasharray: r ? "5 4" : void 0
		}),
		/* @__PURE__ */ d("polygon", {
			points: C,
			transform: "scale(.85)",
			fill: "none",
			stroke: "#bdbb9f",
			strokeWidth: ".8"
		}),
		t !== 0 && /* @__PURE__ */ d("g", {
			transform: "translate(-13,-43)",
			children: /* @__PURE__ */ d(G, {
				kind: t,
				size: 26
			})
		}),
		n && /* @__PURE__ */ d("path", {
			d: "M0-38L4-29 0-24-4-29ZM0-35V-27M-4-29H4",
			fill: "#a99058",
			stroke: "#a99058",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ d(K, {
			word: e,
			discovered: t !== 0 || n
		})
	] });
}
function J({ word: e, kind: t = 0, style: n }) {
	return /* @__PURE__ */ d("svg", {
		viewBox: "-60 -56 120 112",
		style: n,
		"aria-hidden": "true",
		children: /* @__PURE__ */ d(q, {
			word: e,
			kind: t
		})
	});
}
function ee() {
	return /* @__PURE__ */ f("g", {
		"aria-hidden": "true",
		children: [x.map(({ x: e, y: t }, n) => /* @__PURE__ */ d("g", {
			transform: `translate(${e},${t})`,
			children: /* @__PURE__ */ d("polygon", {
				points: C,
				transform: "scale(1.09)",
				fill: "#e8ddba",
				stroke: "#e8ddba",
				strokeWidth: "3"
			})
		}, n)), x.map(({ x: e, y: t }, n) => /* @__PURE__ */ f("g", {
			transform: `translate(${e},${t})`,
			children: [/* @__PURE__ */ d("polygon", {
				points: C,
				fill: n % 4 == 0 ? "#7e934b" : n % 4 == 1 ? "#748c43" : "#6e863f",
				stroke: "#d6d8a1",
				strokeWidth: "1.2"
			}), /* @__PURE__ */ d("path", {
				d: "M-37 28l6-10 6 10m29-48l4-8 4 8m21 28l3-6 3 6",
				fill: "none",
				stroke: "#a9b273",
				strokeOpacity: ".5",
				strokeWidth: "1.1"
			})]
		}, n))]
	});
}
//#endregion
//#region src/games/landmarks/board.tsx
function te({ p: e, cell: t, map: n, legal: a, onChoose: o }) {
	let c = i(), u = l(), { hidden: p } = r(`landmarks-tile:${t}`), { x: m, y: h } = x[t], g = e.words[t], _ = e.revealed[t] ?? n?.[t] ?? 0, v = g ?? c(n ? W[_] : "games.landmarks.unknown"), y = a ? c("games.landmarks.placeCell", {
		word: e.clue ?? "",
		n: t + 1
	}) : c("games.landmarks.cell", {
		n: t + 1,
		content: v
	});
	return /* @__PURE__ */ f("g", {
		transform: `translate(${m},${h})`,
		role: a ? "button" : void 0,
		tabIndex: a ? 0 : void 0,
		"aria-label": y,
		onKeyDown: a ? (e) => {
			(e.key === "Enter" || e.key === " ") && (e.preventDefault(), o?.(t));
		} : void 0,
		className: "lm-cell",
		"data-cell": t,
		children: [
			/* @__PURE__ */ d("title", { children: y }),
			!g && n && _ !== 0 && /* @__PURE__ */ d("g", {
				transform: "translate(-24,-24)",
				children: /* @__PURE__ */ d(G, {
					kind: _,
					size: 48
				})
			}),
			g && /* @__PURE__ */ d("g", {
				visibility: p ? "hidden" : void 0,
				children: /* @__PURE__ */ d(q, {
					word: g,
					kind: _,
					start: e.starts.includes(t)
				})
			}),
			a && /* @__PURE__ */ f("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ d("polygon", {
					points: "60,0 30,52 -30,52 -60,0 -30,-52 30,-52",
					transform: "scale(.89)",
					fill: "#f6f3e6",
					fillOpacity: ".08",
					stroke: "#fff7cf",
					strokeWidth: "5"
				}), /* @__PURE__ */ d("polygon", {
					points: "60,0 30,52 -30,52 -60,0 -30,-52 30,-52",
					transform: "scale(.89)",
					fill: "none",
					stroke: "#34584b",
					strokeWidth: "2.7",
					strokeDasharray: "9 7",
					children: !u && /* @__PURE__ */ d("animate", {
						attributeName: "stroke-dashoffset",
						from: "0",
						to: "-32",
						dur: "1s",
						repeatCount: "indefinite"
					})
				})]
			}),
			!g && e.proposal === t && e.phase === "place" && e.clue && /* @__PURE__ */ d(q, {
				word: e.clue,
				proposed: !0
			}),
			/* @__PURE__ */ d(s, {
				name: `landmarks-tile:${t}`,
				r: {
					x: -60,
					y: -56,
					w: 120,
					h: 112
				}
			})
		]
	});
}
function Y({ p: e, map: t, canPlace: r = !1, onChoose: a }) {
	let o = i(), [s, l] = n(0), u = r ? w(e.words) : [], p = u.map((e) => ({
		key: String(e),
		rect: {
			x: x[e].x - 29,
			y: x[e].y - 33,
			w: 58,
			h: 66
		}
	}));
	return /* @__PURE__ */ f("section", {
		className: "lm-island",
		"aria-label": o("games.landmarks.island"),
		children: [/* @__PURE__ */ f(c, {
			sheetW: 800,
			sheetH: 800,
			fitKey: `landmarks:${s}`,
			clampToSheet: !0,
			eligible: p,
			onTapEligible: (e) => a?.(Number(e)),
			highlight: "off",
			children: [/* @__PURE__ */ d(ee, {}), x.map((n, r) => /* @__PURE__ */ d(te, {
				p: e,
				cell: r,
				map: t,
				legal: u.includes(r),
				onChoose: a
			}, r))]
		}), /* @__PURE__ */ d("button", {
			type: "button",
			className: "lm-fit",
			onClick: () => l((e) => e + 1),
			children: o("games.landmarks.overview")
		})]
	});
}
//#endregion
//#region src/games/landmarks/components.tsx
function X(e, t) {
	return e.mode === "competitive" ? t === 0 ? "games.landmarks.green" : "games.landmarks.blue" : "games.landmarks.party";
}
function Z({ p: e }) {
	let t = i();
	return /* @__PURE__ */ f("aside", {
		className: "lm-tracker",
		"aria-label": t("games.landmarks.resources"),
		children: [e.mode !== "competitive" && /* @__PURE__ */ f("div", {
			className: "lm-supply",
			children: [/* @__PURE__ */ f("div", { children: [
				/* @__PURE__ */ d(G, { kind: 3 }),
				/* @__PURE__ */ d("span", { children: t("games.landmarks.supply") }),
				/* @__PURE__ */ f("strong", { children: [e.water, /* @__PURE__ */ f("small", { children: [" / ", e.capacity] })] })
			] }), /* @__PURE__ */ d("div", {
				className: "lm-water-slots",
				"aria-label": t("games.landmarks.waterLimit", { n: e.capacity }),
				children: Array.from({ length: 7 }, (t, n) => /* @__PURE__ */ d("span", {
					"data-filled": n < e.water,
					"data-lost": n >= e.capacity
				}, n))
			})]
		}), /* @__PURE__ */ d("div", {
			className: "lm-teams",
			children: e.teams.map((n, r) => /* @__PURE__ */ f("section", {
				className: "lm-team",
				"data-team": r,
				"data-active": e.mode === "competitive" && e.turn === r,
				children: [e.mode === "competitive" && /* @__PURE__ */ d("h2", { children: t(X(e, r)) }), /* @__PURE__ */ f("div", {
					className: "lm-counts",
					children: [
						/* @__PURE__ */ f("div", {
							"aria-label": t("games.landmarks.treasure"),
							children: [
								/* @__PURE__ */ d(G, { kind: e.mode === "competitive" ? r === 0 ? 8 : 9 : 2 }),
								/* @__PURE__ */ d("strong", { children: n.treasure }),
								/* @__PURE__ */ d("span", { children: t("games.landmarks.treasure") })
							]
						}),
						/* @__PURE__ */ f("div", {
							"aria-label": t("games.landmarks.curse"),
							children: [
								/* @__PURE__ */ d(G, { kind: 5 }),
								/* @__PURE__ */ d("strong", { children: n.curses }),
								/* @__PURE__ */ d("span", { children: t("games.landmarks.curse") })
							]
						}),
						/* @__PURE__ */ f("div", {
							"aria-label": t("games.landmarks.amulet"),
							children: [
								/* @__PURE__ */ d(G, { kind: 6 }),
								/* @__PURE__ */ d("strong", { children: n.amulets }),
								/* @__PURE__ */ d("span", { children: t("games.landmarks.amulet") })
							]
						})
					]
				})]
			}, r))
		})]
	});
}
function Q({ p: e, open: t, onClose: n }) {
	let r = i();
	return /* @__PURE__ */ f(p, {
		open: t,
		onClose: n,
		label: r("games.landmarks.history"),
		title: r("games.landmarks.history"),
		children: [/* @__PURE__ */ d("ol", {
			className: "lm-history",
			children: e.history.map((t, n) => /* @__PURE__ */ f("li", { children: [/* @__PURE__ */ d(G, {
				kind: t.kind,
				size: 36
			}), /* @__PURE__ */ f("div", { children: [
				/* @__PURE__ */ d("small", { children: r("games.landmarks.historyEntry", {
					n: n + 1,
					team: r(X(e, t.team))
				}) }),
				/* @__PURE__ */ d("strong", { children: t.word }),
				/* @__PURE__ */ d("span", { children: r(W[t.kind]) })
			] })] }, t.cell))
		}), !e.history.length && /* @__PURE__ */ d("p", { children: r("games.landmarks.historyEmpty") })]
	});
}
//#endregion
//#region src/games/landmarks/view-player.tsx
function ne({ public: e, private: t, members: s, myRid: c, send: l }) {
	a();
	let p = i(), m = e, h = t, [g, _] = n(""), [v, y] = n(!1), [b, x] = n(!1), { ref: S } = r("landmarks-clue"), C = m.teams[m.turn], w = C.guide === c, T = m.phase === "clue" && w, E = m.phase === "place" && C.players.includes(c) && !w, D = c === m.players[0], O = (e) => s.find((t) => t.rid === e)?.name ?? e, k = m.teams.find((e) => e.players.includes(c)), A = j.safeParse({
		type: "clue",
		word: g
	}).success && !/\s/u.test(g.trim()), M = () => {
		T && A && (l({
			type: "clue",
			word: g
		}), _(""));
	}, N = m.firstTeam !== null && m.teams.every((e) => e.players.length >= 2 && e.players.includes(e.guide)), P = m.phase === "setup" ? p("games.landmarks.setup") : m.phase === "clue" ? T ? p("games.landmarks.write") : p("games.landmarks.waitClue", { name: O(C.guide) }) : m.phase === "place" ? E ? p("games.landmarks.choose") : p("games.landmarks.waitPlace", { team: p(X(m, m.turn)) }) : m.latest ? p("games.landmarks.revealed", { kind: p(W[m.latest.kind]) }) : "";
	return /* @__PURE__ */ f(o, {
		adaptive: !0,
		scroll: !1,
		className: "lm-game",
		actionsHeight: "lm-actions-slot",
		banner: /* @__PURE__ */ f("header", {
			className: "lm-header",
			children: [
				/* @__PURE__ */ f("div", {
					className: "lm-heading",
					children: [/* @__PURE__ */ d("h1", { children: p("games.landmarks.name") }), /* @__PURE__ */ d("span", { children: m.phase === "setup" ? p("games.landmarks.setup") : p("games.landmarks.turn", { n: m.history.length + (m.phase === "reveal" ? 0 : 1) }) })]
				}),
				/* @__PURE__ */ f("div", {
					className: "lm-identity",
					children: [
						/* @__PURE__ */ d("span", { children: p(X(m, m.turn)) }),
						/* @__PURE__ */ d("span", { children: p("games.landmarks.guideName", { name: O(C.guide) }) }),
						k && /* @__PURE__ */ d("span", { children: p("games.landmarks.yourRole", { role: p(k.guide === c ? "games.landmarks.guide" : "games.landmarks.explorer") }) })
					]
				}),
				/* @__PURE__ */ f("div", {
					className: "lm-toolbar",
					children: [
						/* @__PURE__ */ d("p", {
							role: "status",
							children: P
						}),
						h?.map && /* @__PURE__ */ d("button", {
							type: "button",
							className: "lm-tool",
							"aria-pressed": v,
							onClick: () => y((e) => !e),
							children: p(v ? "games.landmarks.hideMap" : "games.landmarks.showMap")
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							className: "lm-tool",
							onClick: () => x(!0),
							children: p("games.landmarks.history")
						})
					]
				})
			]
		}),
		actions: /* @__PURE__ */ f("div", {
			className: "lm-actions",
			children: [/* @__PURE__ */ d("div", {
				ref: S,
				className: "lm-clue-tile",
				children: /* @__PURE__ */ d(J, { word: m.clue ?? "" })
			}), /* @__PURE__ */ d("div", {
				className: "lm-action-content",
				children: m.phase === "setup" ? D ? /* @__PURE__ */ d("button", {
					type: "button",
					className: "lm-primary",
					disabled: !N,
					onClick: () => l({ type: "start" }),
					children: p("games.landmarks.start")
				}) : /* @__PURE__ */ d("p", { children: p("games.landmarks.waitSetup") }) : T ? /* @__PURE__ */ f("div", {
					className: "lm-write",
					children: [/* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("span", { children: p("games.landmarks.clue") }), /* @__PURE__ */ d("input", {
						"aria-label": p("games.landmarks.clue"),
						autoComplete: "off",
						value: g,
						maxLength: 24,
						onChange: (e) => _(e.target.value),
						onKeyDown: (e) => {
							e.key === "Enter" && !e.nativeEvent.isComposing && (e.preventDefault(), M());
						}
					})] }), /* @__PURE__ */ d("button", {
						type: "button",
						className: "lm-primary",
						disabled: !A,
						onClick: M,
						children: p("games.landmarks.submit")
					})]
				}) : m.phase === "place" && E ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("span", {
					className: "lm-action-label",
					children: p(m.proposal === null ? "games.landmarks.choose" : "games.landmarks.selection")
				}), /* @__PURE__ */ d("button", {
					type: "button",
					className: "lm-primary",
					disabled: m.proposal === null,
					onClick: () => {
						m.proposal !== null && l({
							type: "place",
							cell: m.proposal
						});
					},
					children: p("games.landmarks.confirm")
				})] }) : m.phase === "reveal" ? w ? /* @__PURE__ */ d("button", {
					type: "button",
					className: "lm-primary",
					onClick: () => l({ type: "continue" }),
					children: p(m.outcome ? "games.landmarks.finish" : "games.landmarks.continue")
				}) : /* @__PURE__ */ d("p", { children: p("games.landmarks.waitContinue", { name: O(C.guide) }) }) : /* @__PURE__ */ d("p", { children: P })
			})]
		}),
		children: [m.phase === "setup" ? /* @__PURE__ */ f("section", {
			className: "lm-setup",
			children: [
				/* @__PURE__ */ d("p", { children: p("games.landmarks.setupHint") }),
				m.mode === "competitive" && /* @__PURE__ */ f("section", {
					className: "lm-first-choice",
					children: [
						/* @__PURE__ */ d("p", { children: p("games.landmarks.chooseOrder", { team: p(X(m, m.chooser)) }) }),
						m.teams[m.chooser].players.includes(c) ? /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("button", {
							type: "button",
							className: "lm-secondary",
							"aria-pressed": m.firstTeam === m.chooser,
							onClick: () => l({
								type: "first",
								team: m.chooser
							}),
							children: p("games.landmarks.goFirst")
						}), /* @__PURE__ */ d("button", {
							type: "button",
							className: "lm-secondary",
							"aria-pressed": m.firstTeam === 1 - m.chooser,
							onClick: () => l({
								type: "first",
								team: 1 - m.chooser
							}),
							children: p("games.landmarks.goSecond")
						})] }) : null,
						m.firstTeam !== null && /* @__PURE__ */ d("p", { children: p("games.landmarks.firstChosen", { team: p(X(m, m.firstTeam)) }) })
					]
				}),
				/* @__PURE__ */ d("div", {
					className: "lm-roster",
					children: m.players.map((e) => {
						let t = m.teams.findIndex((t) => t.players.includes(e)), n = m.teams[t];
						return /* @__PURE__ */ f("div", {
							className: "lm-member",
							"data-team": t,
							children: [
								/* @__PURE__ */ d("strong", { children: O(e) }),
								m.mode === "competitive" && /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("span", { children: p("games.landmarks.team") }), /* @__PURE__ */ f("select", {
									disabled: !D,
									value: t,
									onChange: (t) => l({
										type: "assign",
										rid: e,
										team: Number(t.target.value),
										guide: !1
									}),
									children: [/* @__PURE__ */ d("option", {
										value: 0,
										children: p("games.landmarks.green")
									}), /* @__PURE__ */ d("option", {
										value: 1,
										children: p("games.landmarks.blue")
									})]
								})] }),
								/* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("span", { children: p("games.landmarks.role") }), /* @__PURE__ */ f("select", {
									disabled: !D,
									value: n.guide === e ? "guide" : "explorer",
									onChange: (n) => l({
										type: "assign",
										rid: e,
										team: t,
										guide: n.target.value === "guide"
									}),
									children: [/* @__PURE__ */ d("option", {
										value: "guide",
										children: p("games.landmarks.guide")
									}), /* @__PURE__ */ d("option", {
										value: "explorer",
										children: p("games.landmarks.explorer")
									})]
								})] })
							]
						}, e);
					})
				})
			]
		}) : /* @__PURE__ */ f("div", {
			className: "lm-table",
			children: [
				/* @__PURE__ */ d(Y, {
					p: m,
					map: v ? h?.map : null,
					canPlace: E,
					onChoose: (e) => l({
						type: "propose",
						cell: e
					})
				}),
				/* @__PURE__ */ d(Z, { p: m }),
				v && h?.map && /* @__PURE__ */ d("span", {
					className: "lm-secret-label",
					children: p("games.landmarks.secret")
				})
			]
		}), /* @__PURE__ */ d(Q, {
			p: m,
			open: b,
			onClose: () => x(!1)
		})]
	});
}
//#endregion
//#region src/games/landmarks/bot.ts
var re = () => null, ie = { placeClue(e, t) {
	let n = e.data, r = t.anchor("landmarks-clue"), i = t.anchor(`landmarks-tile:${n.cell}`);
	if (!r || !i) return null;
	let a = t.queued ? 180 : 460;
	return {
		ms: a,
		hide: t.queued ? [] : [`landmarks-tile:${n.cell}`],
		node: /* @__PURE__ */ d(m, {
			from: r,
			to: i,
			ms: a,
			children: /* @__PURE__ */ d(J, {
				word: n.word,
				kind: n.kind,
				style: {
					width: r.w,
					height: r.h
				}
			})
		})
	};
} };
//#endregion
//#region src/games/landmarks/game-over.tsx
function ae({ public: e, members: t, onPlayAgain: r, onBackToLobby: a, hintCount: s }) {
	let c = i(), l = e, [p, m] = n(!0), [g, _] = n(!1), v = l.mode !== "competitive", y = v ? c(l.winner === null ? "games.landmarks.defeat" : "games.landmarks.victory") : c("games.landmarks.teamWins", { team: c(X(l, l.winner ?? 0)) }), b = l.outcome === "dry" ? c("games.landmarks.dry") : l.outcome === "cursed" ? c("games.landmarks.cursed") : l.outcome === "treasure" ? c("games.landmarks.treasureEnd") : l.teams[0].curses > l.teams[0].amulets ? c("games.landmarks.exitCursed") : l.teams[0].treasure === 0 ? c("games.landmarks.exitEmpty") : c("games.landmarks.exitSuccess"), x = l.teams[0].treasure, S = x >= 4 ? "games.landmarks.rating4" : x === 3 ? "games.landmarks.rating3" : x === 2 ? "games.landmarks.rating2" : "games.landmarks.rating1";
	return /* @__PURE__ */ f(o, {
		adaptive: !0,
		scroll: !1,
		className: "lm-game lm-final",
		actionsHeight: "lm-actions-slot",
		banner: /* @__PURE__ */ f("header", {
			className: "lm-header",
			children: [/* @__PURE__ */ f("div", {
				className: "lm-heading",
				children: [/* @__PURE__ */ d("h1", { children: c("games.landmarks.name") }), /* @__PURE__ */ d("span", { children: c("games.landmarks.finalMap") })]
			}), /* @__PURE__ */ f("div", {
				className: "lm-toolbar",
				children: [
					/* @__PURE__ */ d("p", { children: y }),
					/* @__PURE__ */ d("button", {
						type: "button",
						className: "lm-tool",
						"aria-pressed": p,
						onClick: () => m((e) => !e),
						children: c(p ? "games.landmarks.reviewMap" : "games.landmarks.showResult")
					}),
					/* @__PURE__ */ d("button", {
						type: "button",
						className: "lm-tool",
						onClick: () => _(!0),
						children: c("games.landmarks.history")
					})
				]
			})]
		}),
		actions: /* @__PURE__ */ d("footer", {
			className: "lm-final-actions",
			children: r || a ? /* @__PURE__ */ f(u, { children: [r && /* @__PURE__ */ d(h, {
				className: "lm-primary",
				label: c("session.result.playAgain"),
				confirmLabel: c("games.landmarks.confirmAgain"),
				onConfirm: r
			}), a && /* @__PURE__ */ d(h, {
				className: "lm-secondary",
				label: c("session.result.backToLobby"),
				confirmLabel: c("games.landmarks.confirmLobby"),
				onConfirm: a
			})] }) : /* @__PURE__ */ d("p", {
				role: "status",
				children: c("session.result.waitHost")
			})
		}),
		children: [
			/* @__PURE__ */ f("div", {
				className: "lm-table",
				children: [/* @__PURE__ */ d(Y, {
					p: l,
					map: l.finalMap
				}), /* @__PURE__ */ d(Z, { p: l })]
			}),
			/* @__PURE__ */ f("section", {
				className: "lm-report",
				hidden: !p,
				"aria-label": c("games.landmarks.finalTitle"),
				children: [/* @__PURE__ */ f("div", {
					className: "lm-report-scroll",
					children: [
						/* @__PURE__ */ d("small", { children: c("games.landmarks.finalTitle") }),
						/* @__PURE__ */ d("h2", { children: y }),
						/* @__PURE__ */ d("p", { children: b }),
						v && l.winner !== null && /* @__PURE__ */ d("strong", {
							className: "lm-rating",
							children: c(S)
						}),
						/* @__PURE__ */ d(Z, { p: l }),
						/* @__PURE__ */ d("div", {
							className: "lm-result-members",
							children: l.teams.map((e, n) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("h3", { children: c(X(l, n)) }), e.players.map((n) => /* @__PURE__ */ f("span", { children: [t.find((e) => e.rid === n)?.name ?? n, /* @__PURE__ */ d("small", { children: c(e.guide === n ? "games.landmarks.guide" : "games.landmarks.explorer") })] }, n))] }, n))
						}),
						s !== void 0 && /* @__PURE__ */ d("p", { children: c("session.hint.usedCount", { n: s }) })
					]
				}), /* @__PURE__ */ d("button", {
					type: "button",
					className: "lm-primary",
					onClick: () => m(!1),
					children: c("games.landmarks.reviewMap")
				})]
			}),
			/* @__PURE__ */ d(Q, {
				p: l,
				open: g,
				onClose: () => _(!1)
			})
		]
	});
}
//#endregion
//#region src/games/landmarks/options.tsx
function oe({ value: e, onChange: t }) {
	let n = i(), r = D.safeParse(e), a = r.success ? r.data : D.parse(void 0), o = (e) => t({
		...a,
		...e
	});
	return /* @__PURE__ */ f(u, { children: [
		/* @__PURE__ */ d(v, {
			title: n("games.landmarks.mode"),
			columns: 3,
			children: [
				[
					"easy",
					"games.landmarks.easy",
					"games.landmarks.easyHint"
				],
				[
					"standard",
					"games.landmarks.standard",
					"games.landmarks.standardHint"
				],
				[
					"competitive",
					"games.landmarks.competitive",
					"games.landmarks.competitiveHint"
				]
			].map(([e, t, r]) => /* @__PURE__ */ d(_, {
				name: "landmarks-mode",
				value: e,
				checked: a.mode === e,
				label: n(t),
				hint: n(r),
				accent: T.accent,
				onChange: () => o({ mode: e })
			}, e))
		}),
		/* @__PURE__ */ f(v, {
			title: n("games.landmarks.wordLanguage"),
			children: [/* @__PURE__ */ d(_, {
				name: "landmarks-words",
				value: "zh",
				checked: a.words === "zh",
				label: n("games.landmarks.chinese"),
				accent: T.accent,
				onChange: () => o({ words: "zh" })
			}), /* @__PURE__ */ d(_, {
				name: "landmarks-words",
				value: "en",
				checked: a.words === "en",
				label: n("games.landmarks.english"),
				accent: T.accent,
				onChange: () => o({ words: "en" })
			})]
		}),
		/* @__PURE__ */ d(v, {
			title: n("games.landmarks.extras"),
			children: /* @__PURE__ */ d(g, {
				name: "landmarks-promo",
				value: "promo",
				checked: a.promo,
				label: n("games.landmarks.promo"),
				hint: n("games.landmarks.promoHint"),
				onChange: () => o({ promo: !a.promo })
			})
		})
	] });
}
//#endregion
//#region src/games/landmarks/rule-icons.tsx
var $ = (e) => ({ size: t = 24 }) => /* @__PURE__ */ d(G, {
	kind: e,
	size: t
}), se = {
	definition: V,
	View: ne,
	bot: re,
	fx: ie,
	OverView: ae,
	Options: oe,
	ruleIcons: {
		treasure: $(2),
		water: $(3),
		trap: $(4),
		curse: $(5),
		amulet: $(6),
		exit: $(7),
		green: $(8),
		blue: $(9)
	},
	locales: {
		zh: {
			name: "神秘导语",
			desc: "用词语之间的联系引导探险队，在神秘岛屿上寻找宝藏与出口。",
			rules: "目标：\n合作模式中，寻路人根据秘密地图给出词语线索，探险队寻找至少一份宝藏，再从出口安全离开。竞争模式中，两队争先获得四份宝藏。\n准备：\n采用Floodgate Games 2024年Landmarks基础规则。入门、标准和竞争模式各有50张基础地图；可选的Dice Tower 2025推广包为每种模式增加一张地图，默认关闭。起始词可选人工中文译文或原版英文；中文词表不是官方中文版。\n合作模式需要2至10人，选择一名寻路人，其余人为探险队。竞争模式需要4至10人，分为两队，每队至少两人、各有一名寻路人。主机在准备页调整队伍和身份，确认后开始。每局随机选择地图；竞争模式随机选出一队，由该队决定先后手，后手队获得一枚护符。只有寻路人可以查看秘密地图。\n岛上放置三个起始词牌。合作模式的跟踪板有七张空白词牌，水上限为七；入门地图有三份宝藏，标准地图有四份。\n每轮流程：\n· 当前队伍的寻路人写下一个词，只能提供这个词，不得补充语境、暗示目标位置或透露落点是否符合原意。合作模式每写一个词，从库存中使用一张词牌。\n· 线索应与岛上已有词语的含义或主题相关。不得使用已有词语的任何组成部分、同根词、押韵、字数、词牌位置、版图特征或方向提示。可用能作为单词读出的缩写，例如NASA；不得使用逐字母读出的缩写，例如FBI。系统拦截空白、空格和字面重复，其余语义限制由全桌遵守。\n· 当前探险队讨论后，点击与任意已有词牌相邻的空格提出落点，再确认放置。寻路人不能替队伍选格，探险者不能向寻路人建议未来线索。新词牌留在岛上，成为之后的路标。\n· 揭示该格发现并更新资源。所有人观察后，由当前寻路人继续；竞争模式随后换另一队行动。\n合作模式的发现：\n· 宝藏 [icon:treasure|宝藏]：共同获得一份宝藏。\n· 水 [icon:water|水]：将库存词牌补满至当前水上限。最后一张词牌找到水时仍可继续。\n· 陷阱 [icon:trap|陷阱]：额外失去一张库存词牌，并永久降低一点水上限；库存最低为零。\n· 诅咒 [icon:curse|诅咒]：记录一次诅咒。每枚护符可以抵消一次诅咒；唯一的地图护符尚未发现时，可以带着一次未抵消的诅咒继续。两次未抵消的诅咒，或护符已经发现后仍有未抵消的诅咒，立即失败。\n· 护符 [icon:amulet|护符]：获得一枚护符，无论先于还是晚于诅咒发现，都可抵消一次诅咒。\n· 出口 [icon:exit|出口]：立即结束。没有未抵消的诅咒且至少有一份宝藏时获胜；否则失败。没有找到出口且库存词牌耗尽时失败。\n合作成绩：\n安全离岛时，一份宝藏勉强获胜，两份为成功，三份为出色，标准模式四份为传奇胜利。\n竞争模式：\n没有水、陷阱和出口，不限制词牌库存。[icon:green|绿队宝藏] 绿色与[icon:blue|蓝队宝藏] 蓝色宝藏始终归对应颜色的队伍，无论由哪队发现；两份金色宝藏归发现它们的队伍。诅咒和地图上唯一的护符归发现队伍。\n后手队的一枚起始护符也可抵消一次诅咒。未抵消的诅咒达到两次，或地图护符已经被任一队找到而本队仍有未抵消的诅咒时，本队立即失败。任一队获得第四份宝藏时立即判定：该队没有未抵消的诅咒则获胜，否则另一队获胜。对方发现本队宝藏也可能触发这个判定。",
			mode: "游戏模式",
			easy: "入门合作",
			standard: "标准合作",
			competitive: "双队竞争",
			easyHint: "3份宝藏，较少危险",
			standardHint: "4份宝藏，更多危险",
			competitiveHint: "每队至少2人，争取4份宝藏",
			wordLanguage: "起始词语言",
			chinese: "中文译文",
			english: "原版英文",
			extras: "可选地图",
			promo: "Dice Tower 2025推广包",
			promoHint: "每种模式增加1张官方推广地图",
			setup: "分配探险队与寻路人",
			guide: "寻路人",
			explorer: "探险者",
			party: "探险队",
			green: "绿队",
			blue: "蓝队",
			team: "队伍",
			role: "身份",
			start: "开始探险",
			setupHint: "每队至少两人，选择一名寻路人。",
			waitSetup: "等待主机确认队伍与身份",
			chooseOrder: "由{{team}}选择先后手，后手队获得一枚护符。",
			goFirst: "本队先行动",
			goSecond: "本队后行动",
			firstChosen: "先手：{{team}}",
			turn: "第 {{n}} 次探索",
			guideName: "寻路人：{{name}}",
			yourRole: "你的身份：{{role}}",
			write: "写下一个词，引导探险队",
			waitClue: "等待{{name}}给出线索",
			choose: "在相邻空格提出落点",
			waitPlace: "{{team}}正在讨论落点",
			revealed: "发现：{{kind}}",
			continue: "继续探险",
			finish: "查看探险结果",
			waitContinue: "等待{{name}}继续",
			clue: "线索词",
			submit: "提交线索",
			confirm: "确认放在这里",
			selection: "已提出落点",
			secret: "秘密地图",
			showMap: "查看秘密地图",
			hideMap: "收起秘密地图",
			overview: "回到全景",
			island: "探险岛屿",
			cell: "岛屿格位 {{n}}：{{content}}",
			placeCell: "将“{{word}}”提案放到格位 {{n}}",
			unknown: "未探索",
			empty: "空地",
			starting: "起始路标",
			treasure: "宝藏",
			water: "水",
			trap: "陷阱",
			curse: "诅咒",
			amulet: "护符",
			exit: "出口",
			greenTreasure: "绿队宝藏",
			blueTreasure: "蓝队宝藏",
			supply: "词牌库存",
			waterLimit: "水上限 {{n}}",
			resources: "探险记录",
			history: "探索经过",
			historyEmpty: "尚未探索新格位",
			close: "关闭",
			historyEntry: "第 {{n}} 次 · {{team}}",
			finalTitle: "岛屿探险报告",
			victory: "安全离岛",
			defeat: "探险结束",
			teamWins: "{{team}}获胜",
			dry: "库存词牌耗尽，未能找到出口。",
			cursed: "诅咒已无法抵消，探险失败。",
			exitCursed: "抵达出口时仍被诅咒，未能安全离岛。",
			exitEmpty: "抵达出口，但没有找到宝藏。",
			exitSuccess: "带着宝藏安全离开了岛屿。",
			treasureEnd: "第四份宝藏已被找到。",
			rating1: "勉强获胜",
			rating2: "成功",
			rating3: "出色",
			rating4: "传奇胜利",
			reviewMap: "回看完整地图",
			showResult: "查看探险报告",
			finalMap: "完整地图",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			invalid: "当前不能执行这个操作，请核对身份、阶段与落点。",
			invalidClue: "线索必须是一个不含空格、未在岛上出现过的词。"
		},
		en: {
			name: "Landmarks",
			desc: "Connect words to guide your party across a mysterious island in search of treasure and a way home.",
			rules: "Goal:\nIn co-op, a Pathfinder gives word clues from a secret map. The Party must find at least one treasure and reach the exit safely. In competitive mode, two teams race for four treasures.\nSetup:\nUses Floodgate Games’ 2024 base rules. Beginner, standard and competitive modes each have 50 base maps. The optional Dice Tower 2025 promo adds one official map per mode and is off by default. Starting words use the printed English or a handmade Chinese translation; the Chinese word list is not an official edition.\nCo-op supports 2–10 players: one Pathfinder and everyone else in the Party. Competitive supports 4–10, in two teams of at least two players, each with a Pathfinder. The host adjusts teams and roles before starting. The map is random. In competitive mode, a randomly selected team decides who goes first; the second team starts with one amulet. Only Pathfinders see the secret map.\nPlace three starting word tiles. Co-op starts with seven blank tiles and a water limit of seven. Beginner maps contain three treasures; standard maps contain four.\nEach round:\n· The active Pathfinder writes one word, with no extra context, positional hints or confirmation of whether the Party reached the intended space. In co-op, writing uses one tile from the supply.\n· Clues must relate to the meanings or themes of existing Landmarks. Do not use any part or root of an existing word, rhymes, letter counts, tile positions, board features or directions. Acronyms pronounced as words, such as NASA, are allowed; initialisms such as FBI are not. The app rejects empty clues, spaces and exact repeats; players enforce the remaining meaning-based restrictions.\n· The active Party discusses a space adjacent to any existing word tile, taps to propose it, then confirms placement. Pathfinders cannot select spaces for their Party, and explorers must not suggest future clues. The new word stays as a Landmark.\n· Reveal the discovery and update resources. After everyone has seen it, the active Pathfinder continues. In competitive mode the other team then takes a turn.\nCo-op discoveries:\n· Treasure [icon:treasure|Treasure]: gain one shared treasure.\n· Water [icon:water|Water]: refill the tile supply to the current water limit. Finding water with the last tile lets you continue.\n· Trap [icon:trap|Trap]: lose one additional supply tile and permanently reduce the water limit by one. Supply cannot fall below zero.\n· Curse [icon:curse|Curse]: record one curse. Each amulet cancels one curse. You may carry one uncancelled curse while the map’s sole amulet is still undiscovered. Two uncancelled curses, or any uncancelled curse after that amulet has been found, cause immediate defeat.\n· Amulet [icon:amulet|Amulet]: gain one amulet. It cancels one curse whether found before or after the curse.\n· Exit [icon:exit|Exit]: end immediately. Win with at least one treasure and no uncancelled curse; otherwise lose. Running out of supply without finding the exit also loses.\nCo-op result:\nEscaping with one treasure is a narrow win, two a solid success, three an impressive feat and four (standard only) a legendary victory.\nCompetitive mode:\nNo water, traps or exit, and no tile supply limit. [icon:green|Green treasure] Green and [icon:blue|Blue treasure] blue treasures always go to their matching team, whoever discovers them. The two gold treasures go to the discovering team. Curses and the single map amulet go to the discovering team.\nThe second team’s starting amulet also cancels one curse. A team loses immediately with two uncancelled curses, or with any uncancelled curse after either team has found the map amulet. When either team gains its fourth treasure, it wins if uncursed; otherwise the other team wins. A treasure discovered by the opposing team can trigger this result.",
			mode: "Game mode",
			easy: "Beginner co-op",
			standard: "Standard co-op",
			competitive: "Team vs. team",
			easyHint: "3 treasures, fewer hazards",
			standardHint: "4 treasures, more hazards",
			competitiveHint: "At least 2 per team; race for 4 treasures",
			wordLanguage: "Starting words",
			chinese: "Chinese translation",
			english: "Printed English",
			extras: "Optional maps",
			promo: "Dice Tower 2025 promo",
			promoHint: "Adds 1 official map per mode",
			setup: "Choose teams and Pathfinders",
			guide: "Pathfinder",
			explorer: "Explorer",
			party: "The Party",
			green: "Green team",
			blue: "Blue team",
			team: "Team",
			role: "Role",
			start: "Begin expedition",
			setupHint: "Each team needs at least two players and one Pathfinder.",
			waitSetup: "Waiting for the host to confirm teams and roles",
			chooseOrder: "{{team}} chooses turn order. The second team gains one amulet.",
			goFirst: "Our team goes first",
			goSecond: "Our team goes second",
			firstChosen: "First: {{team}}",
			turn: "Exploration {{n}}",
			guideName: "Pathfinder: {{name}}",
			yourRole: "Your role: {{role}}",
			write: "Write one word to guide your Party",
			waitClue: "Waiting for {{name}}’s clue",
			choose: "Propose an adjacent empty space",
			waitPlace: "{{team}} is choosing a space",
			revealed: "Found: {{kind}}",
			continue: "Continue expedition",
			finish: "View expedition result",
			waitContinue: "Waiting for {{name}} to continue",
			clue: "Clue word",
			submit: "Give clue",
			confirm: "Confirm this space",
			selection: "Space proposed",
			secret: "Secret map",
			showMap: "View secret map",
			hideMap: "Hide secret map",
			overview: "Fit island",
			island: "Expedition island",
			cell: "Island space {{n}}: {{content}}",
			placeCell: "Propose “{{word}}” at space {{n}}",
			unknown: "Unexplored",
			empty: "Nothing",
			starting: "Starting Landmark",
			treasure: "Treasure",
			water: "Water",
			trap: "Trap",
			curse: "Curse",
			amulet: "Amulet",
			exit: "Exit",
			greenTreasure: "Green treasure",
			blueTreasure: "Blue treasure",
			supply: "Tile supply",
			waterLimit: "Water limit {{n}}",
			resources: "Expedition tracker",
			history: "Exploration log",
			historyEmpty: "No new spaces explored yet",
			close: "Close",
			historyEntry: "Exploration {{n}} · {{team}}",
			finalTitle: "Island expedition report",
			victory: "Escaped safely",
			defeat: "Expedition ended",
			teamWins: "{{team}} wins",
			dry: "The tile supply ran out before the exit was found.",
			cursed: "The curse can no longer be cured. The expedition is lost.",
			exitCursed: "You reached the exit while cursed and could not escape safely.",
			exitEmpty: "You reached the exit without any treasure.",
			exitSuccess: "You escaped the island with treasure.",
			treasureEnd: "The fourth treasure has been found.",
			rating1: "A narrow win",
			rating2: "Solid success",
			rating3: "Impressive feat",
			rating4: "Legendary victory",
			reviewMap: "Review the full map",
			showResult: "View expedition report",
			finalMap: "Full map",
			confirmAgain: "Confirm another expedition",
			confirmLobby: "Confirm return to lobby",
			invalid: "That action is unavailable. Check your role, the phase and the space.",
			invalidClue: "Use one word with no spaces that is not already on the island."
		}
	}
};
//#endregion
export { se as default };
