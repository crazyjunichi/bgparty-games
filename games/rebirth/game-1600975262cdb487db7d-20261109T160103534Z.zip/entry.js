import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { avatarNameAt as n, useI18nSettings as r, useT as i } from "@bgparty/sdk/i18n";
import { botAvatarOf as a } from "@bgparty/sdk/lobby";
import { AVATARS as o } from "@bgparty/sdk/avatars";
import { Fragment as s, useEffect as c, useId as l, useMemo as u, useRef as d, useState as f } from "react";
import { PLAYER_COLORS as p } from "@bgparty/sdk/player-colors";
import { IconBack as m, IconBot as h, IconExpand as g, IconLog as _, IconPile as v } from "@bgparty/sdk/icons";
import { DeltaNumber as y } from "@bgparty/sdk/fx/delta-number";
import { playTurn as b, useSoundEdge as x } from "@bgparty/sdk/sfx";
import { Texture as ee } from "@bgparty/sdk/texture";
import { useWakeLock as te } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as ne } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as re, seatName as S } from "@bgparty/sdk/ui/player-strip";
import { SheetView as C } from "@bgparty/sdk/sheet-view";
import { Fragment as w, jsx as T, jsxs as E } from "react/jsx-runtime";
import { Confetti as D } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as O, OptionSection as ie } from "@bgparty/sdk/ui/game-options";
//#region src/games/rebirth/map-data.ts
var ae = {
	scotland: [
		"SS.ESCB....",
		"EC.CEEBS...",
		"E.SSES.....",
		"..EEEC.....",
		"SECFB.SDFF.",
		"SBEFDSCSFSD",
		"CEBFSSBFCS.",
		".SECFBESFS.",
		".EEEFCEBF..",
		".CSDFBSEC..",
		"FFSFEDESS..",
		"..FCEECE...",
		"FFFESEESSF.",
		"FCSBDSEDSCF",
		".S.BSECBFF.",
		"....CBEEFF.",
		"...FFBDBC..",
		"...FSFCSS..",
		"..FCSB....."
	],
	ireland: [
		"....BCSBCB.",
		"....EESTBSB",
		"...EEEEBBTS",
		"...BCBBSFCS",
		"....BBFFFBS",
		".BBTSBTFBBT",
		"BBBEEEEBSS.",
		".TSFFFBBTB.",
		"BFFTSBSBSS.",
		".BSCBEEBBCS",
		"..SBESBSBS.",
		"..BTBCSBTB.",
		".BSBBBBCBS.",
		".TSCSTSSBB.",
		"SFFSBCBTS..",
		".CFBBBSSB..",
		"BBBCSB.....",
		".BTSS......",
		"BBBB......."
	]
}, k = {
	scotland: [
		"0.0 0.1",
		"0.4",
		"1.7",
		"2.2 2.3",
		"2.5",
		"4.0 5.0",
		"4.6 5.7",
		"5.5 6.4 6.5",
		"5.9 6.9 7.9",
		"7.1",
		"7.7",
		"9.2 10.2",
		"9.6",
		"10.7 10.8",
		"12.4 13.5 14.4",
		"12.7 12.8 13.8",
		"13.2 14.1",
		"17.4 18.4",
		"17.7 17.8"
	],
	ireland: [
		"0.6 1.6",
		"1.9",
		"2.10 3.10 4.10",
		"3.7",
		"5.4",
		"6.8 6.9",
		"7.2",
		"8.4",
		"8.6",
		"8.8 8.9 9.10 10.9",
		"9.2 10.2",
		"10.5 11.6",
		"10.7",
		"12.2 13.2",
		"12.9",
		"13.4 14.3",
		"13.6 13.7",
		"14.0",
		"14.8",
		"15.6 15.7",
		"16.4 17.3 17.4"
	]
}, A = {
	scotland: "0.0 0.1 0.3 0.4 0.5 0.6 1.0 1.1 1.3 1.4 1.5 1.6 2.0 2.2 2.3 8.7 8.8 9.7 9.8 10.7 10.8 12.0 12.1 13.0 13.1 13.2 14.1 17.3 17.4 18.2 18.3 18.4",
	ireland: "2.5 2.6 2.7 3.6 3.7 5.7 5.8 6.7 7.5 7.6 8.4 8.5 8.6 8.0 9.1 13.4 14.3 12.9 13.9 15.6 15.7 15.8 18.2 18.3"
}, j = {
	scotland: "0.1 1.7 4.0 7.1 7.9 12.7 14.1 18.4",
	ireland: "0.9 1.4 5.1 7.9 9.1 13.9 15.8 16.5 18.0 18.3"
}, M = {
	scotland: {
		"0.5": "thurso",
		"1.1": "stornoway",
		"1.3": "ardvreck",
		"3.5": "dornoch",
		"4.2": "eileanDonan",
		"5.6": "invernessCastle",
		"6.0": "armadale",
		"6.8": "aberdeenCastle",
		"7.3": "invergarry",
		"8.5": "blair",
		"9.1": "duart",
		"9.8": "glamis",
		"11.3": "inveraray",
		"11.6": "stirling",
		"13.1": "kilberry",
		"13.9": "edinburghCastle",
		"14.6": "neidpath",
		"15.4": "culzean",
		"16.8": "hermitage",
		"17.6": "caerlaverock",
		"18.3": "kirkcudbright",
		"4.7": "elgin",
		"5.4": "invernessCathedral",
		"5.10": "aberdeenCathedral",
		"9.3": "oban",
		"10.5": "perth",
		"13.4": "glasgow",
		"13.7": "edinburghCathedral",
		"16.6": "dumfries"
	},
	ireland: {
		"0.5": "doe",
		"0.8": "dunluce",
		"3.4": "donegal",
		"3.9": "belfast",
		"9.3": "dunguaire",
		"9.9": "dublin",
		"11.5": "birr",
		"12.7": "kilkenny",
		"13.3": "bunratty",
		"14.5": "cahir",
		"15.1": "ross",
		"16.3": "blarney",
		"7.8": "tara"
	}
}, oe = new Set("13.10 14.9 15.9 17.7 17.8".split(" ")), N = [
	11,
	10,
	10,
	9,
	9,
	7,
	7
].flatMap((e, t) => Array.from({ length: 13 - e }, (n, r) => ({
	row: t + 13,
	col: r + e
}))), P = new Set(N.map((e) => `${e.row}.${e.col}`));
function se(e, t) {
	let n = e % 2 == 0 ? 1 : -1;
	return [
		[e, t - 1],
		[e, t + 1],
		[e - 1, t],
		[e - 1, t + n],
		[e + 1, t],
		[e + 1, t + n]
	].map(([e, t]) => `${e}.${t}`);
}
function F(e) {
	let t = new Set(ae[e].flatMap((e, t) => [...e].flatMap((e, n) => e === "." ? [] : [`${t}.${n}`]))), n = new Set(A[e].split(" ")), r = new Set(j[e].split(" ")), i = k[e].map((e) => e.split(" "));
	return ae[e].flatMap((a, o) => [...a].flatMap((a, s) => {
		if (a === ".") return [];
		let c = `${o}.${s}`, l = se(o, s), u = i.findIndex((e) => e.includes(c));
		return [{
			id: c,
			row: o,
			col: s,
			terrain: a,
			neighbors: l.filter((e) => t.has(e)),
			coast: l.some((n) => !t.has(n) && !(e === "scotland" && P.has(n))),
			border: e === "scotland" && oe.has(c),
			bonus: r.has(c),
			blockedForTwo: n.has(c),
			settlement: u < 0 ? null : u,
			landmark: M[e][c] ?? null
		}];
	}));
}
var I = {
	scotland: F("scotland"),
	ireland: F("ireland")
}, L = {
	scotland: k.scotland.map((e) => e.split(" ")),
	ireland: k.ireland.map((e) => e.split(" "))
}, R = {
	scotland: Object.fromEntries(I.scotland.map((e) => [e.id, e])),
	ireland: Object.fromEntries(I.ireland.map((e) => [e.id, e]))
};
function z(e) {
	return {
		x: 60 + 84 * (e.col + (e.row % 2 == 0 ? .5 : 0)),
		y: 65 + 73 * e.row
	};
}
//#endregion
//#region src/games/rebirth/missions.ts
var ce = [
	{
		id: 0,
		key: "games.rebirth.mGlasgow",
		high: 5,
		low: 5
	},
	{
		id: 2,
		key: "games.rebirth.mEdinburghCastle",
		high: 5,
		low: 5
	},
	{
		id: 3,
		key: "games.rebirth.mAberdeenCastle",
		high: 5,
		low: 5
	},
	{
		id: 4,
		key: "games.rebirth.mPerth",
		high: 5,
		low: 5
	},
	{
		id: 5,
		key: "games.rebirth.mEileanDonan",
		high: 5,
		low: 5
	},
	{
		id: 6,
		key: "games.rebirth.mEdinburghCathedral",
		high: 5,
		low: 5
	},
	{
		id: 7,
		key: "games.rebirth.mPorts",
		high: 5,
		low: 5
	},
	{
		id: 8,
		key: "games.rebirth.mBorder",
		high: 5,
		low: 5
	},
	{
		id: 9,
		key: "games.rebirth.mCastles",
		high: 5,
		low: 5
	},
	{
		id: 10,
		key: "games.rebirth.mBlair",
		high: 5,
		low: 5
	},
	{
		id: 12,
		key: "games.rebirth.mDumfries",
		high: 5,
		low: 5
	},
	{
		id: 13,
		key: "games.rebirth.mInvergarry",
		high: 5,
		low: 5
	},
	{
		id: 14,
		key: "games.rebirth.mCoast",
		high: 5,
		low: 5
	},
	{
		id: 15,
		key: "games.rebirth.mMedium",
		high: 5,
		low: 5
	},
	{
		id: 16,
		key: "games.rebirth.mEnergyGroups",
		high: 5,
		low: 5
	},
	{
		id: 17,
		key: "games.rebirth.mInveraray",
		high: 5,
		low: 5
	},
	{
		id: 18,
		key: "games.rebirth.mFoodGroups",
		high: 5,
		low: 5
	},
	{
		id: 19,
		key: "games.rebirth.mInverness",
		high: 5,
		low: 5
	},
	{
		id: 20,
		key: "games.rebirth.mSmall",
		high: 5,
		low: 5
	},
	{
		id: 21,
		key: "games.rebirth.mLargestEnergy",
		high: 5,
		low: 5
	},
	{
		id: 22,
		key: "games.rebirth.mLarge",
		high: 5,
		low: 5
	},
	{
		id: 23,
		key: "games.rebirth.mBonus",
		high: 3,
		low: 3
	},
	{
		id: 24,
		key: "games.rebirth.mCathedrals",
		high: 5,
		low: 5
	},
	{
		id: 25,
		key: "games.rebirth.mOban",
		high: 5,
		low: 5
	},
	{
		id: 26,
		key: "games.rebirth.mLargestFood",
		high: 5,
		low: 5
	},
	{
		id: 27,
		key: "games.rebirth.mOwnMedium",
		high: 5,
		low: 5
	}
], B = [
	{
		id: 0,
		key: "games.rebirth.iEnergy",
		high: 8,
		low: 5
	},
	{
		id: 1,
		key: "games.rebirth.iFood",
		high: 8,
		low: 5
	},
	{
		id: 2,
		key: "games.rebirth.iSmall",
		high: 6,
		low: 4
	},
	{
		id: 3,
		key: "games.rebirth.iOwnMedium",
		high: 8,
		low: 5
	},
	{
		id: 4,
		key: "games.rebirth.iCoast",
		high: 8,
		low: 5
	},
	{
		id: 5,
		key: "games.rebirth.iCastle",
		high: 8,
		low: 5
	},
	{
		id: 6,
		key: "games.rebirth.iLarge",
		high: 8,
		low: 5
	},
	{
		id: 7,
		key: "games.rebirth.iOffshore",
		high: 8,
		low: 5
	},
	{
		id: 8,
		key: "games.rebirth.iTower",
		high: 8,
		low: 5
	},
	{
		id: 9,
		key: "games.rebirth.iLinkTowers",
		high: 12,
		low: 8
	},
	{
		id: 10,
		key: "games.rebirth.iLinkCastles",
		high: 12,
		low: 8
	},
	{
		id: 11,
		key: "games.rebirth.iMedium",
		high: 8,
		low: 5
	}
];
function V(e, t) {
	return (e === "scotland" ? ce : B).find((e) => e.id === t);
}
function H(e, t) {
	let n = new Set(t), r = [];
	for (; n.size;) {
		let t = n.values().next().value, i = [t];
		n.delete(t);
		for (let t = 0; t < i.length; t++) for (let r of R[e][i[t]].neighbors) n.delete(r) && i.push(r);
		r.push(i);
	}
	return r;
}
function le(e, t, n = 2 ** 53 - 1) {
	let r = 0;
	for (let i of H(e, t).sort((e, t) => t.length - e.length)) {
		if (i.length <= r) continue;
		let t = new Map(i.map((e, t) => [e, t])), a = i.map((n) => R[e][n].neighbors.flatMap((e) => t.has(e) ? [t.get(e)] : [])), o = /* @__PURE__ */ new Set(), s = (e, t, c) => {
			if (r = Math.max(r, c), r >= Math.min(i.length, n)) return;
			let l = `${e}:${t}`;
			if (!o.has(l)) {
				o.add(l);
				for (let o of a[e]) {
					let e = 1n << BigInt(o);
					if ((t & e) === 0n && s(o, t | e, c + 1), r >= Math.min(i.length, n)) return;
				}
			}
		};
		for (let e = 0; e < i.length && r < Math.min(i.length, n); e++) s(e, 1n << BigInt(e), 1);
		if (r >= n) return n;
	}
	return r;
}
function U(e, t, n, r = !1) {
	return R[e.map][t].neighbors.filter((t) => e.board[t]?.owner === n && (!r || e.board[t].tile.kind !== "S")).length;
}
function W(e, t, n) {
	let r = Object.keys(e.board).filter((n) => e.board[n].owner === t), i = R[e.map], a = (t) => H(e.map, r.filter((n) => e.board[n].tile.kind === t)), o = (n, r = !1) => L[e.map].filter((i) => i.length === n && (r ? i.every((n) => e.board[n]?.owner === t) : i.some((n) => e.board[n]?.owner === t))).length, s = (n) => U(e, I[e.map].find((e) => e.landmark === n).id, t), c = (n) => Math.max(0, ...I[e.map].filter((t) => t.terrain === n && !(e.players.length === 2 && t.blockedForTwo)).map((n) => U(e, n.id, t))), l = (t) => Math.max(0, ...H(e.map, r).map((n) => new Set(n.flatMap((n) => i[n].neighbors.filter((n) => i[n].terrain === t && !(e.players.length === 2 && i[n].blockedForTwo)))).size));
	if (e.map === "ireland") switch (n) {
		case 0: return a("E").filter((e) => e.length >= 3).length;
		case 1: return a("F").filter((e) => e.length >= 3).length;
		case 2: return o(1);
		case 3: return o(2, !0);
		case 4: return le(e.map, r.filter((e) => i[e].coast), 4);
		case 5: return c("C");
		case 6: return o(3);
		case 7: return r.filter((e) => i[e].bonus).length;
		case 8: return c("T");
		case 9: return l("T");
		case 10: return l("C");
		case 11: return o(2);
		default: return 0;
	}
	let u = {
		0: "glasgow",
		2: "edinburghCastle",
		3: "aberdeenCastle",
		4: "perth",
		5: "eileanDonan",
		6: "edinburghCathedral",
		10: "blair",
		12: "dumfries",
		13: "invergarry",
		17: "inveraray",
		19: "invernessCathedral",
		25: "oban"
	};
	if (u[n]) return s(u[n]);
	switch (n) {
		case 7: return r.filter((e) => i[e].bonus).length;
		case 8: return r.filter((e) => i[e].border).length;
		case 9: return Object.values(e.castles).filter((e) => e === t).length;
		case 14: return le(e.map, r.filter((e) => i[e].coast));
		case 15: return o(2);
		case 16: return a("E").filter((e) => e.length >= 3).length;
		case 18: return a("F").filter((e) => e.length >= 3).length;
		case 20: return o(1);
		case 21: return Math.max(0, ...a("E").map((e) => e.length));
		case 22: return o(3);
		case 23: return 1;
		case 24: return I.scotland.filter((n) => n.terrain === "D" && e.visited[n.id]?.includes(t)).length;
		case 26: return Math.max(0, ...a("F").map((e) => e.length));
		case 27: return o(2, !0);
		default: return 0;
	}
}
var G = [
	2,
	2,
	3,
	2,
	4,
	4,
	3,
	3,
	4,
	4,
	4,
	4
];
function K(e, t, n) {
	let r = W(e, t, n);
	return e.map === "ireland" ? r >= G[n] : e.players.every((t) => W(e, t, n) <= r);
}
//#endregion
//#region src/games/rebirth/meta.ts
var q = {
	id: "rebirth",
	tier: "beta",
	mechanics: ["tile-placement", "area-control"],
	interactionTags: [],
	nameKey: "games.rebirth.name",
	descKey: "games.rebirth.desc",
	rulesKey: "games.rebirth.rules",
	icon: "🌱",
	iconImg: "games/rebirth.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/rebirth/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3],
	accent: "#39734f",
	releasedAt: "2026-10-17T02:21:16+08:00",
	search: {
		py: "chong zhu jia yuan",
		init: "czjy"
	},
	hotseat: "cover"
}, ue = t.object({ map: t.enum(["scotland", "ireland"]).default("scotland") }).default({ map: "scotland" }), J = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("E"),
		influence: t.literal(0)
	}),
	t.object({
		kind: t.literal("F"),
		influence: t.literal(0)
	}),
	t.object({
		kind: t.literal("S"),
		influence: t.int().min(1).max(4)
	})
]), de = t.enum([
	"score3",
	"set13",
	"extra",
	"draw3",
	"mission",
	"double"
]), fe = t.discriminatedUnion("type", [t.object({
	type: t.literal("place"),
	cell: t.string().max(6),
	tile: t.int().min(0).max(2)
}), t.object({
	type: t.literal("double"),
	mission: t.int().min(0).max(11)
})]), pe = t.object({
	owner: t.string(),
	tile: J
}), me = t.object({
	farms: t.int(),
	settlements: t.int(),
	bonuses: t.int(),
	castles: t.int(),
	missions: t.int()
}), he = t.object({
	map: t.enum(["scotland", "ireland"]),
	players: t.array(t.string()),
	current: t.string(),
	phase: t.enum([
		"place",
		"double",
		"done"
	]),
	turn: t.int(),
	extra: t.boolean(),
	board: t.record(t.string(), pe),
	scores: t.record(t.string(), t.int()),
	breakdown: t.record(t.string(), me),
	remaining: t.record(t.string(), t.int()),
	reservedCount: t.record(t.string(), t.int()),
	missionCount: t.record(t.string(), t.int()),
	castles: t.record(t.string(), t.string()),
	visited: t.record(t.string(), t.array(t.string())),
	towers: t.record(t.string(), de),
	missions: t.array(t.object({
		id: t.int(),
		claims: t.array(t.object({
			rid: t.string(),
			points: t.int()
		}))
	})),
	doubles: t.record(t.string(), t.int()),
	last: t.object({
		cell: t.string(),
		rid: t.string(),
		gains: t.record(t.string(), t.int())
	}).nullable(),
	revealed: t.record(t.string(), t.array(t.object({
		id: t.int(),
		points: t.int()
	}))),
	tieBreak: t.enum([
		"none",
		"edinburgh",
		"stirling",
		"blarney",
		"tara"
	])
}), ge = t.object({
	hand: t.array(J).max(3),
	setAside: t.array(J),
	missions: t.array(t.int()),
	legal: t.array(t.array(t.string()))
}), _e = () => ({
	farms: 0,
	settlements: 0,
	bonuses: 0,
	castles: 0,
	missions: 0
});
function Y(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function ve(e) {
	let t = e ? 9 : 12, n = Array.from({ length: t }, () => ({
		kind: "E",
		influence: 0
	}));
	n.push(...Array.from({ length: t }, () => ({
		kind: "F",
		influence: 0
	})));
	for (let t = 1; t <= 4; t++) for (let r = 0; r < (e && t > 1 ? 2 : 3); r++) n.push({
		kind: "S",
		influence: t
	});
	return n;
}
function ye(e, t) {
	let n = I[e.map].filter((t) => !e.board[t.id] && !(e.players.length === 2 && t.blockedForTwo));
	if (t.kind === "S") return n.filter((e) => e.terrain === "S").map((e) => e.id);
	let r = n.filter((e) => e.terrain === t.kind || e.terrain === "B");
	return (r.length ? r : n.filter((e) => e.terrain === (t.kind === "E" ? "F" : "E"))).map((e) => e.id);
}
function X(e, t, n, r) {
	e.pub.scores[t] += r, e.pub.breakdown[t][n] += r;
}
function be(e, t) {
	return !(e.pub.players.length === 2 && R[e.pub.map][t].blockedForTwo);
}
function xe(e) {
	for (let t of e.pub.players) e.pub.remaining[t] = e.supplies[t].length + e.hands[t].length, e.pub.reservedCount[t] = e.reserves[t].length, e.pub.missionCount[t] = e.privateMissions[t].length;
}
function Se(e, t, n) {
	let r = {
		map: e.map,
		players: [...t],
		current: t[0],
		phase: "place",
		turn: 1,
		extra: !1,
		board: {},
		scores: {},
		breakdown: {},
		remaining: {},
		reservedCount: {},
		missionCount: {},
		castles: {},
		visited: {},
		towers: {},
		missions: [],
		doubles: {},
		last: null,
		revealed: {},
		tieBreak: "none"
	}, i = {
		pub: r,
		seed: n,
		cursor: 0,
		supplies: {},
		hands: {},
		reserves: {},
		setAside: {},
		privateMissions: {},
		missionDeck: [],
		extraTile: null,
		usedExtra: !1,
		drawThree: !1,
		doubleUsed: [],
		winner: []
	};
	if (i.missionDeck = Y(i, e.map === "scotland" ? [...ce.map((e) => e.id), ...[
		,
		,
		,
		,
		,
		,
	].fill(23)] : B.map((e) => e.id)), e.map === "ireland") {
		r.missions = i.missionDeck.splice(0, 8).map((e) => ({
			id: e,
			claims: []
		}));
		let e = Y(i, [
			"score3",
			"score3",
			"set13",
			"set13",
			"set13",
			"extra",
			"extra",
			"extra",
			"extra",
			"draw3",
			"draw3",
			"mission",
			"double",
			"double"
		]);
		I.ireland.filter((e) => e.terrain === "T").forEach((t, n) => {
			r.towers[t.id] = e[n];
		});
	}
	for (let n of t) {
		let a = Y(i, ve(t.length === 4));
		i.reserves[n] = a.splice(0, e.map === "scotland" ? 2 : 4), i.setAside[n] = [...i.reserves[n]], i.reserves[n] = Y(i, i.reserves[n]), i.hands[n] = a.splice(0, 1), i.supplies[n] = a, i.privateMissions[n] = [], r.scores[n] = 0, r.breakdown[n] = _e();
	}
	return xe(i), i;
}
function Ce(e, t, n) {
	let r = R[e.map][t];
	if (r.settlement === null) return {};
	let i = L[e.map][r.settlement];
	if (!i.every((t) => e.board[t])) return {};
	if (i.length === 1) return { [n]: e.board[t].tile.influence };
	let a = /* @__PURE__ */ new Map();
	for (let t of i) {
		let n = e.board[t];
		a.set(n.owner, (a.get(n.owner) ?? 0) + n.tile.influence);
	}
	let o = e.players, s = (e) => (o.indexOf(e) - o.indexOf(n) + o.length - 1) % o.length, c = [...a.keys()].sort((e, t) => a.get(t) - a.get(e) || s(e) - s(t)), l = i.length === 2 ? [5, 3] : i.length === 3 ? [8, 5] : [
		12,
		8,
		5
	], u = {};
	return l.forEach((e, t) => {
		let n = c[t] ?? c[0];
		u[n] = (u[n] ?? 0) + e;
	}), u;
}
function we(e, t, n) {
	for (let r of R[e.pub.map][t].neighbors) {
		if (R[e.pub.map][r].terrain !== "C" || !be(e, r)) continue;
		let t = e.pub.castles[r];
		if (t === n) continue;
		let i = U(e.pub, r, n), a = t ? U(e.pub, r, t) : 0;
		(i > a || i === a && U(e.pub, r, n, !0) > U(e.pub, r, t, !0)) && (e.pub.castles[r] = n);
	}
}
function Te(e, t) {
	for (let n of e.pub.missions) {
		if (n.claims.some((e) => e.rid === t) || !K(e.pub, t, n.id)) continue;
		let r = V("ireland", n.id), i = (n.claims.length ? r.low : r.high) * (e.pub.doubles[t] === n.id ? 2 : 1);
		n.claims.push({
			rid: t,
			points: i
		}), X(e, t, "missions", i);
	}
}
function Ee(e, t, n) {
	for (let r of R[e.pub.map][t].neighbors) {
		let t = R[e.pub.map][r].terrain;
		if (t !== "D" && t !== "T" || !be(e, r) || e.pub.visited[r]?.includes(n)) continue;
		if ((e.pub.visited[r] ??= []).push(n), t === "D") {
			let t = e.missionDeck.shift();
			t !== void 0 && e.privateMissions[n].push(t);
			continue;
		}
		let i = e.pub.towers[r];
		if (i === "score3" && X(e, n, "bonuses", 3), i === "draw3" && (e.drawThree = !0), i === "mission") {
			let t = e.missionDeck.shift();
			t !== void 0 && e.privateMissions[n].push(t);
		}
		i === "extra" && !e.usedExtra && (e.usedExtra = !0, e.extraTile = e.reserves[n].shift() ?? null), i === "set13" && Object.entries(e.pub.towers).filter(([, e]) => e === "set13").every(([t]) => e.pub.visited[t]?.includes(n)) && X(e, n, "bonuses", 13);
	}
}
function De(e) {
	let t = e.pub.current, n = Object.entries(e.pub.towers).filter(([, e]) => e === "double");
	return !e.doubleUsed.includes(t) && n.length === 2 && n.every(([n]) => e.pub.visited[n]?.includes(t)) && e.pub.missions.some((e) => !e.claims.some((e) => e.rid === t));
}
function Oe(e) {
	for (let t of L[e.pub.map]) if (!t.every((t) => e.pub.board[t])) for (let n of t) {
		let t = e.pub.board[n];
		t && X(e, t.owner, "settlements", t.tile.influence);
	}
	for (let t of Object.values(e.pub.castles)) X(e, t, "castles", 5);
	for (let t of e.pub.players) e.pub.revealed[t] = e.privateMissions[t].map((n) => ({
		id: n,
		points: K(e.pub, t, n) ? V(e.pub.map, n).high : 0
	})), X(e, t, "missions", e.pub.revealed[t].reduce((e, t) => e + t.points, 0));
	let t = Math.max(...Object.values(e.pub.scores)), n = e.pub.players.filter((n) => e.pub.scores[n] === t);
	if (e.winner = n, n.length > 1) {
		let t = e.pub.map === "scotland" ? "edinburghCastle" : "blarney", r = I[e.pub.map].find((e) => e.landmark === t), i = e.pub.castles[r.id];
		if (n.includes(i)) e.winner = [i], e.pub.tieBreak = e.pub.map === "scotland" ? "edinburgh" : "blarney";
		else if (e.pub.map === "scotland") {
			let t = e.pub.castles["11.6"];
			t && (e.winner = [t], e.pub.tieBreak = "stirling");
		} else {
			let t = Math.max(...e.pub.players.map((t) => U(e.pub, "7.8", t)));
			e.winner = e.pub.players.filter((n) => U(e.pub, "7.8", n) === t), e.pub.tieBreak = "tara";
		}
	}
	e.pub.phase = "done";
}
function ke(e) {
	if (e.pub.extra = e.extraTile !== null, De(e)) {
		e.pub.phase = "double";
		return;
	}
	if (e.extraTile) {
		e.pub.extra = !0, e.pub.phase = "place";
		return;
	}
	let t = e.pub.current;
	if (e.hands[t] = e.supplies[t].splice(0, e.drawThree ? 3 : 1), xe(e), e.pub.players.every((t) => e.pub.remaining[t] === 0)) {
		Oe(e);
		return;
	}
	let n = e.pub.players.indexOf(t);
	for (let t = 1; t <= e.pub.players.length; t++) {
		let r = e.pub.players[(n + t) % e.pub.players.length];
		if (e.pub.remaining[r] > 0) {
			e.pub.current = r;
			break;
		}
	}
	e.pub.turn++, e.pub.phase = "place", e.pub.extra = !1, e.usedExtra = !1, e.drawThree = !1;
}
function Ae(e, t, n) {
	if (e.pub.current !== n || e.pub.phase === "done") return { code: "games.rebirth.errTurn" };
	if (t.type === "double") {
		if (e.pub.phase !== "double" || !e.pub.missions.some((e) => e.id === t.mission && !e.claims.some((e) => e.rid === n))) return { code: "games.rebirth.errMission" };
		let r = structuredClone(e);
		return r.pub.doubles[n] = t.mission, r.doubleUsed.push(n), ke(r), r;
	}
	let r = e.pub.extra ? t.tile === 0 ? e.extraTile : null : e.hands[n][t.tile];
	if (e.pub.phase !== "place" || !r || !ye(e.pub, r).includes(t.cell)) return { code: "games.rebirth.errPlace" };
	let i = structuredClone(e), a = { ...i.pub.scores };
	if (i.pub.extra) i.extraTile = null, i.pub.extra = !1;
	else {
		let e = i.hands[n].filter((e, n) => n !== t.tile);
		i.hands[n] = [], e.length && (i.supplies[n] = Y(i, [...i.supplies[n], ...e]));
	}
	i.pub.board[t.cell] = {
		owner: n,
		tile: { ...r }
	};
	let o = R[i.pub.map][t.cell];
	if (r.kind !== "S") {
		let e = Object.keys(i.pub.board).filter((e) => i.pub.board[e].owner === n && i.pub.board[e].tile.kind === r.kind);
		X(i, n, "farms", H(i.pub.map, e).find((e) => e.includes(t.cell)).length);
	} else for (let [e, r] of Object.entries(Ce(i.pub, t.cell, n))) X(i, e, "settlements", r);
	return o.bonus && X(i, n, "bonuses", 1), we(i, t.cell, n), Te(i, n), Ee(i, t.cell, n), i.pub.last = {
		cell: t.cell,
		rid: n,
		gains: Object.fromEntries(i.pub.players.map((e) => [e, i.pub.scores[e] - a[e]]))
	}, xe(i), ke(i), i;
}
var je = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: q,
	schemas: {
		action: fe,
		publicView: he,
		privateView: ge,
		config: ue
	},
	setup: (e, t, n) => ({ state: Se(e, t, n) }),
	reduce: (e, t, n) => {
		let r = Ae(e, t, n.by);
		return "code" in r ? r : { state: r };
	},
	viewFor: (e, t) => {
		let n = e.pub.current === t && e.pub.extra && e.extraTile ? [e.extraTile] : e.hands[t];
		return {
			public: structuredClone(e.pub),
			...n ? { private: {
				hand: structuredClone(n),
				setAside: structuredClone(e.setAside[t]),
				missions: [...e.privateMissions[t]],
				legal: e.pub.current === t && e.pub.phase === "place" ? n.map((t) => ye(e.pub, t)) : []
			} } : {}
		};
	},
	status: (e) => e.pub.phase === "done" ? {
		phase: "done",
		winner: [...e.winner],
		ranking: [...e.pub.players].sort((t, n) => Number(e.winner.includes(n)) - Number(e.winner.includes(t)) || e.pub.scores[n] - e.pub.scores[t]),
		scores: { ...e.pub.scores }
	} : {
		phase: e.pub.phase,
		scores: { ...e.pub.scores }
	}
}, Me = {
	scotland: "games.rebirth.scotland",
	ireland: "games.rebirth.ireland"
}, Z = {
	E: "games.rebirth.energy",
	F: "games.rebirth.food",
	S: "games.rebirth.settlement",
	B: "games.rebirth.flexible",
	C: "games.rebirth.castle",
	D: "games.rebirth.cathedral",
	T: "games.rebirth.tower"
}, Ne = {
	score3: "+3",
	set13: "13",
	extra: "+▱",
	draw3: "▱3",
	mission: "?",
	double: "×2"
}, Pe = {
	score3: "games.rebirth.towerScore3",
	set13: "games.rebirth.towerSet13",
	extra: "games.rebirth.towerExtra",
	draw3: "games.rebirth.towerDraw3",
	mission: "games.rebirth.towerMission",
	double: "games.rebirth.towerDouble"
};
function Fe(e, t) {
	return e === "ireland" ? t === 0 ? "E" : t === 1 ? "F" : [
		2,
		3,
		6,
		11
	].includes(t) ? "S" : [5, 10].includes(t) ? "C" : [8, 9].includes(t) ? "T" : "B" : [16, 21].includes(t) ? "E" : [18, 26].includes(t) ? "F" : [
		15,
		20,
		22,
		27
	].includes(t) ? "S" : [
		2,
		3,
		5,
		9,
		10,
		13,
		17
	].includes(t) ? "C" : [
		0,
		4,
		6,
		12,
		19,
		23,
		24,
		25
	].includes(t) ? "D" : "B";
}
var Ie = {
	thurso: "games.rebirth.thurso",
	stornoway: "games.rebirth.stornoway",
	ardvreck: "games.rebirth.ardvreck",
	dornoch: "games.rebirth.dornoch",
	eileanDonan: "games.rebirth.eileanDonan",
	invernessCastle: "games.rebirth.invernessCastle",
	armadale: "games.rebirth.armadale",
	aberdeenCastle: "games.rebirth.aberdeenCastle",
	invergarry: "games.rebirth.invergarry",
	blair: "games.rebirth.blair",
	duart: "games.rebirth.duart",
	glamis: "games.rebirth.glamis",
	inveraray: "games.rebirth.inveraray",
	stirling: "games.rebirth.stirling",
	kilberry: "games.rebirth.kilberry",
	edinburghCastle: "games.rebirth.edinburghCastle",
	neidpath: "games.rebirth.neidpath",
	culzean: "games.rebirth.culzean",
	hermitage: "games.rebirth.hermitage",
	caerlaverock: "games.rebirth.caerlaverock",
	kirkcudbright: "games.rebirth.kirkcudbright",
	elgin: "games.rebirth.elgin",
	invernessCathedral: "games.rebirth.invernessCathedral",
	aberdeenCathedral: "games.rebirth.aberdeenCathedral",
	oban: "games.rebirth.oban",
	perth: "games.rebirth.perth",
	glasgow: "games.rebirth.glasgow",
	edinburghCathedral: "games.rebirth.edinburghCathedral",
	dumfries: "games.rebirth.dumfries",
	doe: "games.rebirth.doe",
	dunluce: "games.rebirth.dunluce",
	donegal: "games.rebirth.donegal",
	belfast: "games.rebirth.belfast",
	dunguaire: "games.rebirth.dunguaire",
	dublin: "games.rebirth.dublin",
	birr: "games.rebirth.birr",
	kilkenny: "games.rebirth.kilkenny",
	bunratty: "games.rebirth.bunratty",
	cahir: "games.rebirth.cahir",
	ross: "games.rebirth.ross",
	blarney: "games.rebirth.blarney",
	tara: "games.rebirth.tara"
}, Le = [
	[0, -146 / 3],
	[42, -73 / 3],
	[42, 73 / 3],
	[0, 146 / 3],
	[-42, 73 / 3],
	[-42, -73 / 3]
], Q = Le.map((e) => e.join(",")).join(" ");
function Re({ id: e }) {
	return /* @__PURE__ */ E("defs", { children: [
		/* @__PURE__ */ E("linearGradient", {
			id: `${e}-sea`,
			x2: ".8",
			y2: "1",
			children: [/* @__PURE__ */ T("stop", { stopColor: "#87bfcb" }), /* @__PURE__ */ T("stop", {
				offset: "1",
				stopColor: "#b7d8d6"
			})]
		}),
		/* @__PURE__ */ E("linearGradient", {
			id: `${e}-paper`,
			x2: "0",
			y2: "1",
			children: [/* @__PURE__ */ T("stop", { stopColor: "#fffbed" }), /* @__PURE__ */ T("stop", {
				offset: "1",
				stopColor: "#eee6ce"
			})]
		}),
		/* @__PURE__ */ E("linearGradient", {
			id: `${e}-food`,
			x2: ".4",
			y2: "1",
			children: [/* @__PURE__ */ T("stop", { stopColor: "#d2d88b" }), /* @__PURE__ */ T("stop", {
				offset: "1",
				stopColor: "#8eac61"
			})]
		}),
		/* @__PURE__ */ E("linearGradient", {
			id: `${e}-energy`,
			x2: ".9",
			y2: "1",
			children: [/* @__PURE__ */ T("stop", { stopColor: "#a4b1a3" }), /* @__PURE__ */ T("stop", {
				offset: "1",
				stopColor: "#6f897a"
			})]
		}),
		/* @__PURE__ */ E("linearGradient", {
			id: `${e}-meadow`,
			x2: ".4",
			y2: "1",
			children: [/* @__PURE__ */ T("stop", { stopColor: "#b8ce8d" }), /* @__PURE__ */ T("stop", {
				offset: "1",
				stopColor: "#93b576"
			})]
		}),
		/* @__PURE__ */ T("pattern", {
			id: `${e}-waves`,
			width: "46",
			height: "36",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ T("path", {
				d: "M5 13q5 3 10 0m15 16q4 2 8 0",
				stroke: "#f1fbef",
				strokeWidth: ".7",
				fill: "none",
				opacity: ".21"
			})
		}),
		/* @__PURE__ */ E("pattern", {
			id: `${e}-grain`,
			width: "13",
			height: "11",
			patternUnits: "userSpaceOnUse",
			children: [/* @__PURE__ */ T("circle", {
				cx: "2",
				cy: "3",
				r: ".45",
				fill: "#fff",
				opacity: ".14"
			}), /* @__PURE__ */ T("circle", {
				cx: "9",
				cy: "8",
				r: ".5",
				fill: "#254a38",
				opacity: ".09"
			})]
		}),
		/* @__PURE__ */ T("clipPath", {
			id: `${e}-cell`,
			children: /* @__PURE__ */ T("polygon", { points: "0,-48.666666666666664 42,-24.333333333333332 42,24.333333333333332 0,48.666666666666664 -42,24.333333333333332 -42,-24.333333333333332" })
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-leaf`,
			children: [
				/* @__PURE__ */ T("path", {
					d: "M0 11C-16 6-18-6-11-14 0-11 4-2 0 11Z",
					fill: "#f7f6d5"
				}),
				/* @__PURE__ */ T("path", {
					d: "M3 11C1-4 9-14 19-14 23-2 18 9 3 11Z",
					fill: "#fffbe2"
				}),
				/* @__PURE__ */ T("path", {
					d: "M1 10C-3-7-1-18 5-23 14-15 12 1 1 10Z",
					fill: "#fdfbe8"
				})
			]
		}),
		/* @__PURE__ */ T("g", {
			id: `${e}-bolt`,
			children: /* @__PURE__ */ T("path", {
				d: "M4-23-13 3H-1L-5 23 15-6H3Z",
				fill: "#f7f8e4",
				stroke: "#526d66",
				strokeWidth: "1.4",
				strokeLinejoin: "round"
			})
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-turbine`,
			children: [/* @__PURE__ */ T("path", {
				d: "M0 25 1-11M1-11-14-18M1-11 13-23M1-11 5 4",
				fill: "none",
				stroke: "#f4f4dc",
				strokeWidth: "2.4",
				strokeLinecap: "round"
			}), /* @__PURE__ */ T("circle", {
				cx: "1",
				cy: "-11",
				r: "2.5",
				fill: "#4d746b"
			})]
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-energy-art`,
			children: [
				/* @__PURE__ */ T("polygon", {
					points: "0,-48.666666666666664 42,-24.333333333333332 42,24.333333333333332 0,48.666666666666664 -42,24.333333333333332 -42,-24.333333333333332",
					fill: `url(#${e}-energy)`
				}),
				/* @__PURE__ */ T("path", {
					d: "M-49 16-24-27-7-3 10-37 48 14V49H-49Z",
					fill: "#5c786e",
					opacity: ".68"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-24-27-13-11-21-15-28-8-32-10ZM10-37 24-16 14-21 8-15 2-19Z",
					fill: "#c4cdb8"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-49 32Q-9 5 49 27V50H-49Z",
					fill: "#83a077"
				}),
				/* @__PURE__ */ T("use", {
					href: `#${e}-turbine`,
					transform: "translate(-17 13) scale(0.65)"
				}),
				/* @__PURE__ */ T("use", {
					href: `#${e}-turbine`,
					transform: "translate(22 21) scale(0.5)"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-40 32 42 12",
					stroke: "#b4bea0",
					strokeWidth: "2",
					opacity: ".7"
				}),
				/* @__PURE__ */ T("use", {
					href: `#${e}-bolt`,
					transform: "translate(3 1) scale(0.53)"
				})
			]
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-food-art`,
			children: [
				/* @__PURE__ */ T("polygon", {
					points: "0,-48.666666666666664 42,-24.333333333333332 42,24.333333333333332 0,48.666666666666664 -42,24.333333333333332 -42,-24.333333333333332",
					fill: `url(#${e}-food)`
				}),
				/* @__PURE__ */ T("path", {
					d: "M-48-13 48 7V48H-48Z",
					fill: "#a6ba70"
				}),
				/* @__PURE__ */ T("path", {
					d: "m-49 0 98 24m-98-12 98 24m-98-12 98 24m-65-76-25 67m44-63-24 68m44-64-24 67",
					stroke: "#6c9556",
					strokeWidth: "2",
					opacity: ".65"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-48-23q30-8 69 13",
					stroke: "#d4dea1",
					strokeWidth: "8",
					fill: "none"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-33 34q5-12 22-16",
					stroke: "#dce4b0",
					strokeWidth: "2",
					fill: "none"
				}),
				/* @__PURE__ */ T("use", {
					href: `#${e}-leaf`,
					transform: "translate(0 0) scale(0.64)"
				})
			]
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-meadow-art`,
			children: [
				/* @__PURE__ */ T("polygon", {
					points: "0,-48.666666666666664 42,-24.333333333333332 42,24.333333333333332 0,48.666666666666664 -42,24.333333333333332 -42,-24.333333333333332",
					fill: `url(#${e}-meadow)`
				}),
				/* @__PURE__ */ T("path", {
					d: "M-45 22Q-20-8 46 6M-41 36Q-12 11 47 20",
					stroke: "#d2dda6",
					strokeWidth: "10",
					fill: "none",
					opacity: ".47"
				}),
				/* @__PURE__ */ T("path", {
					d: "m-18-14 3-6 3 6m21 12 3-7 3 7m-27 35 2-5 3 5",
					fill: "none",
					stroke: "#688c53",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ T("circle", {
					cx: "-16",
					cy: "10",
					r: "1.6",
					fill: "#f4e9b7"
				}),
				/* @__PURE__ */ T("circle", {
					cx: "23",
					cy: "-19",
					r: "1.6",
					fill: "#f4e9b7"
				})
			]
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-house`,
			children: [
				/* @__PURE__ */ T("path", {
					d: "M-9-1 0-9 10-2V12H-9Z",
					fill: "#fff2d5",
					stroke: "#6c785c",
					strokeWidth: "1.2"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-12-1 0-12 13-2 10 1 0-7-9 2Z",
					fill: "#9c765b"
				}),
				/* @__PURE__ */ T("rect", {
					x: "-2",
					y: "5",
					width: "4",
					height: "7",
					fill: "#658276"
				}),
				/* @__PURE__ */ T("rect", {
					x: "-6",
					y: "2",
					width: "3",
					height: "3",
					fill: "#b9c8aa"
				})
			]
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-settlement-art`,
			children: [
				/* @__PURE__ */ T("polygon", {
					points: "0,-48.666666666666664 42,-24.333333333333332 42,24.333333333333332 0,48.666666666666664 -42,24.333333333333332 -42,-24.333333333333332",
					fill: "#c6c69b"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-30 30 17-37M-33-7 37 28",
					stroke: "#e5d9b6",
					strokeWidth: "8"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-33 31 15-38",
					stroke: "#aeaf88",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ T("use", {
					href: `#${e}-house`,
					transform: "translate(-17 -17) scale(0.93)"
				}),
				/* @__PURE__ */ T("use", {
					href: `#${e}-house`,
					transform: "translate(17 -11) scale(0.8)"
				}),
				/* @__PURE__ */ T("use", {
					href: `#${e}-house`,
					transform: "translate(-1 16) scale(1.08)"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-31 3v14m-5-5h10",
					stroke: "#779663",
					strokeWidth: "3"
				})
			]
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-castle-art`,
			children: [
				/* @__PURE__ */ T("polygon", {
					points: "0,-48.666666666666664 42,-24.333333333333332 42,24.333333333333332 0,48.666666666666664 -42,24.333333333333332 -42,-24.333333333333332",
					fill: "#bd94b1"
				}),
				/* @__PURE__ */ T("ellipse", {
					cy: "24",
					rx: "34",
					ry: "11",
					fill: "#846f79",
					opacity: ".4"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-32 19-22-21-10-33 20-31 36 8 22 29-12 32Z",
					fill: "#a4b486"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-26 18V-12H-13V-2H15V-16H28V18L9 27Z",
					fill: "#e5ccb9",
					stroke: "#705b66",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-26 18V-12L-16-7V22M15-2 28-9V18L9 27V1",
					fill: "#b79895",
					stroke: "#705b66",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-29-13v-10h6v4h5v-4h7v12m24-4v-10h6v4h5v-4h7v11",
					fill: "#eddbc4",
					stroke: "#705b66",
					strokeWidth: "1.8"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-4 23V12q5-8 10 0v14",
					fill: "#736068"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-20-3v7m41-8v7",
					stroke: "#675966",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ T("path", {
					d: "M0-4V-22m0 0 13 3-13 5",
					stroke: "#6d586b",
					fill: "#995a87",
					strokeWidth: "1.6"
				})
			]
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-cathedral-art`,
			children: [
				/* @__PURE__ */ T("polygon", {
					points: "0,-48.666666666666664 42,-24.333333333333332 42,24.333333333333332 0,48.666666666666664 -42,24.333333333333332 -42,-24.333333333333332",
					fill: "#dfc46f"
				}),
				/* @__PURE__ */ T("ellipse", {
					cy: "27",
					rx: "29",
					ry: "9",
					fill: "#a68c52",
					opacity: ".25"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-24 22V-4L-3-16 19-4V22Z",
					fill: "#f4dfad",
					stroke: "#8c785a",
					strokeWidth: "1.7"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-27-4-5-22 22-5 17 0-4-15-21 1Z",
					fill: "#8b9686"
				}),
				/* @__PURE__ */ T("path", {
					d: "M3 22V-23h15V22",
					fill: "#f6e8c2",
					stroke: "#887558",
					strokeWidth: "1.6"
				}),
				/* @__PURE__ */ T("path", {
					d: "m0-23 10-20 11 20Z",
					fill: "#657d74"
				}),
				/* @__PURE__ */ T("path", {
					d: "M10-43v-8m-4 4h8",
					stroke: "#8d7957",
					strokeWidth: "1.8"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-13 22V11q4-8 8 0v11m16-29v8m-1 8v7",
					fill: "#9b9a7e",
					stroke: "#857d63",
					strokeWidth: "1.5"
				})
			]
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-task-icon`,
			children: [
				/* @__PURE__ */ T("path", {
					d: "M-12-16H7l5 5v27h-24Z",
					fill: "#f7efd6",
					stroke: "#776f50",
					strokeWidth: "1.8"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-7-8H4M-7-3H7M-7 9h14",
					stroke: "#9b9875",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ T("path", {
					d: "m-3 4 3-5 3 5-3 4Z",
					fill: "#79966b"
				})
			]
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-compass`,
			children: [
				/* @__PURE__ */ T("path", {
					d: "M0-19 5-4 17 0 5 4 0 19-5 4-17 0-5-4Z",
					fill: "#e7f2df",
					opacity: ".6"
				}),
				/* @__PURE__ */ T("path", {
					d: "M0-19V19M-17 0H17",
					stroke: "#4b858b",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ T("circle", {
					r: "4",
					fill: "#a4c8c9",
					stroke: "#56878c"
				})
			]
		}),
		/* @__PURE__ */ E("g", {
			id: `${e}-tower-art`,
			children: [
				/* @__PURE__ */ T("polygon", {
					points: Q,
					fill: "#dfc46f"
				}),
				/* @__PURE__ */ T("ellipse", {
					cy: "30",
					rx: "24",
					ry: "8",
					fill: "#a68c52",
					opacity: ".25"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-12 30-9-23H10L15 30Z",
					fill: "#f3e4bb",
					stroke: "#82775b",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ T("path", {
					d: "M3-23H10L15 30H5Z",
					fill: "#c5bd9d"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-13-22 0-43 14-22Z",
					fill: "#6a8475",
					stroke: "#697e68",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-3 30V19q4-7 8 0v11M-3-12v7m1 5v7",
					fill: "#7f8d76",
					stroke: "#7c8067",
					strokeWidth: "2.5"
				}),
				/* @__PURE__ */ T("path", {
					d: "M-8-17H10M-9 4H12M-10 15H13",
					stroke: "#b6b496",
					strokeWidth: "1"
				})
			]
		})
	] });
}
var ze = {
	E: "energy-art",
	F: "food-art",
	B: "meadow-art",
	S: "settlement-art",
	C: "castle-art",
	D: "cathedral-art",
	T: "tower-art"
};
function Be({ terrain: e, id: t }) {
	return /* @__PURE__ */ T("use", { href: `#${t}-${ze[e]}` });
}
function $({ terrain: e, influence: t = 0, selected: n = !1, className: r }) {
	let i = `rebirth-piece-${l().replace(/[^a-zA-Z0-9_-]/g, "")}`;
	return /* @__PURE__ */ E("svg", {
		viewBox: "-55 -55 110 110",
		className: r,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ T(Re, { id: i }),
			/* @__PURE__ */ T("polygon", {
				points: Q,
				transform: "translate(0 3)",
				fill: "#6c8159"
			}),
			/* @__PURE__ */ T("g", {
				clipPath: `url(#${i}-cell)`,
				children: /* @__PURE__ */ T(Be, {
					id: i,
					terrain: e
				})
			}),
			/* @__PURE__ */ T("polygon", {
				points: Q,
				fill: "none",
				stroke: "#fffae1",
				strokeWidth: "4"
			}),
			n && /* @__PURE__ */ T("polygon", {
				points: Q,
				transform: "scale(1.08)",
				fill: "none",
				stroke: "#3d7058",
				strokeWidth: "2.5"
			}),
			t > 0 && /* @__PURE__ */ E("g", { children: [/* @__PURE__ */ T("circle", {
				cx: "25",
				cy: "-23",
				r: "13",
				fill: "#fff5d8",
				stroke: "#65775c",
				strokeWidth: "2"
			}), /* @__PURE__ */ T("text", {
				x: "25",
				y: "-18",
				textAnchor: "middle",
				fontSize: "17",
				fontWeight: "800",
				fill: "#3c5742",
				className: "font-mono tabular-nums",
				children: t
			})] })
		]
	});
}
//#endregion
//#region src/games/rebirth/board.tsx
function Ve(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = z(n);
		Le.forEach((n, r) => {
			let i = Le[(r + 1) % 6], a = [e.x + n[0], e.y + n[1]], o = [e.x + i[0], e.y + i[1]], s = [a.map((e) => e.toFixed(3)).join(","), o.map((e) => e.toFixed(3)).join(",")].sort().join("|");
			t.has(s) ? t.delete(s) : t.set(s, [a, o]);
		});
	}
	return [...t.values()].map(([e, t]) => `M${e.join(" ")} ${t.join(" ")}`).join("");
}
var He = {
	scotland: Ve([...I.scotland, ...N]),
	ireland: Ve(I.ireland)
}, Ue = Object.fromEntries(Object.entries(I).map(([e, t]) => [e, t.map((e) => {
	let { x: t, y: n } = z(e);
	return {
		key: e.id,
		rect: {
			x: t - 21,
			y: n - 17,
			w: 42,
			h: 34
		}
	};
})]));
function We({ cell: e, map: t }) {
	let n = L[t][e.settlement], r = z(e);
	return /* @__PURE__ */ T("g", {
		fill: "none",
		pointerEvents: "none",
		children: Le.map((i, a) => {
			let o = Le[(a + 1) % 6];
			return n.some((n) => {
				if (n === e.id) return !1;
				let a = z(R[t][n]);
				return Math.hypot(a.x - r.x - i[0] - o[0], a.y - r.y - i[1] - o[1]) < 3;
			}) ? null : /* @__PURE__ */ E("g", { children: [/* @__PURE__ */ T("path", {
				d: `M${i.join(" ")} ${o.join(" ")}`,
				stroke: "#456553",
				strokeWidth: "7"
			}), /* @__PURE__ */ T("path", {
				d: `M${i.join(" ")} ${o.join(" ")}`,
				stroke: "#faf3cf",
				strokeWidth: "4"
			})] }, a);
		})
	});
}
function Ge({ rid: e, avatar: t, color: n, name: r, y: i = 30 }) {
	return /* @__PURE__ */ E("g", {
		transform: `translate(0 ${i})`,
		children: [
			/* @__PURE__ */ T("title", { children: r(e) }),
			/* @__PURE__ */ T("rect", {
				x: "-13",
				y: "-9",
				width: "26",
				height: "18",
				rx: "8",
				fill: n(e),
				stroke: "#fff8de",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ T("image", {
				href: t(e),
				x: -8,
				y: -8,
				width: 16,
				height: 16,
				preserveAspectRatio: "xMidYMid meet",
				pointerEvents: "none"
			})
		]
	});
}
function Ke({ bonus: e, id: t }) {
	let n = i();
	return /* @__PURE__ */ E("g", {
		transform: "translate(0 23)",
		children: [
			/* @__PURE__ */ T("title", { children: n(Pe[e]) }),
			/* @__PURE__ */ T("rect", {
				x: "-21",
				y: "-10",
				width: "42",
				height: "20",
				rx: "5",
				fill: "#fff0be",
				stroke: "#a18b51",
				strokeWidth: "1.3"
			}),
			e === "mission" ? /* @__PURE__ */ T("use", {
				href: `#${t}-task-icon`,
				transform: "scale(.48)"
			}) : e === "draw3" || e === "extra" ? /* @__PURE__ */ E("g", { children: [/* @__PURE__ */ T("rect", {
				x: "-14",
				y: "-6",
				width: "10",
				height: "12",
				rx: "1",
				fill: "#f9f1d7",
				stroke: "#746e50",
				strokeWidth: "1.5"
			}), /* @__PURE__ */ T("text", {
				x: "7",
				y: "5",
				textAnchor: "middle",
				fontSize: "14",
				fill: "#685b34",
				fontWeight: "800",
				children: e === "draw3" ? "3" : "+1"
			})] }) : /* @__PURE__ */ T("text", {
				y: "5",
				textAnchor: "middle",
				fontSize: "14",
				fill: "#685b34",
				fontWeight: "800",
				children: Ne[e]
			})
		]
	});
}
function qe({ pub: e, legal: t, selected: n, preview: r, myRid: a, fit: o, choose: s, name: c, color: u, cellLabel: d, avatar: f }) {
	let p = i(), m = `rebirth-map-${l().replace(/[^a-zA-Z0-9_-]/g, "")}`, h = new Set(t);
	return /* @__PURE__ */ E(C, {
		sheetW: 990,
		sheetH: 1460,
		fitKey: `${e.map}:${o}`,
		clampToSheet: !0,
		highlight: "off",
		eligible: Ue[e.map],
		onTapEligible: s,
		children: [
			/* @__PURE__ */ T(Re, { id: m }),
			/* @__PURE__ */ E("g", {
				strokeLinejoin: "round",
				children: [
					/* @__PURE__ */ T("path", {
						d: He[e.map],
						fill: "none",
						stroke: "#dcf0df",
						strokeWidth: "20",
						opacity: ".75"
					}),
					/* @__PURE__ */ T("path", {
						d: He[e.map],
						fill: "none",
						stroke: "#4d7c6a",
						strokeWidth: "10"
					}),
					e.map === "scotland" && /* @__PURE__ */ E("g", {
						fill: "#a3bc80",
						stroke: "#a3bc80",
						strokeWidth: "1",
						pointerEvents: "none",
						children: [N.map((e) => {
							let t = z(e);
							return /* @__PURE__ */ T("polygon", {
								points: Q,
								transform: `translate(${t.x} ${t.y})`
							}, `${e.row}.${e.col}`);
						}), /* @__PURE__ */ T("text", {
							x: "860",
							y: "1380",
							textAnchor: "middle",
							fill: "#668561",
							stroke: "none",
							fontSize: "20",
							letterSpacing: "4",
							children: p("games.rebirth.england")
						})]
					}),
					I[e.map].map((t) => {
						let i = z(t), o = e.board[t.id], l = e.players.length === 2 && t.blockedForTwo, g = n === t.id, _ = g && h.has(t.id) && r, v = o?.tile ?? _, y = o?.owner ?? (_ ? a : void 0), b = e.visited[t.id] ?? [], x = e.last?.cell === t.id, ee = [
							d(t),
							p("games.rebirth.cell", {
								row: t.row + 1,
								col: t.col + 1
							}),
							l ? p("games.rebirth.blocked") : o ? p("games.rebirth.owned", { name: c(o.owner) }) : "",
							e.towers[t.id] ? p(Pe[e.towers[t.id]]) : ""
						].filter(Boolean).join(" · ");
						return /* @__PURE__ */ E("g", {
							transform: `translate(${i.x} ${i.y})`,
							role: "button",
							tabIndex: 0,
							"aria-label": ee,
							"aria-pressed": g,
							onKeyDown: (e) => {
								(e.key === "Enter" || e.key === " ") && (e.preventDefault(), s(t.id));
							},
							className: "rebirth-map-cell",
							children: [
								/* @__PURE__ */ T("title", { children: ee }),
								/* @__PURE__ */ E("g", {
									opacity: l ? .45 : 1,
									children: [
										/* @__PURE__ */ E("g", {
											clipPath: `url(#${m}-cell)`,
											children: [/* @__PURE__ */ T(Be, {
												id: m,
												terrain: t.terrain
											}), /* @__PURE__ */ T("polygon", {
												points: Q,
												fill: `url(#${m}-grain)`
											})]
										}),
										/* @__PURE__ */ T("polygon", {
											points: Q,
											fill: "none",
											stroke: "#4e7059",
											strokeWidth: "1.25",
											strokeOpacity: ".65"
										}),
										t.settlement !== null && /* @__PURE__ */ T(We, {
											cell: t,
											map: e.map
										})
									]
								}),
								!l && h.has(t.id) && !_ && /* @__PURE__ */ E("g", {
									pointerEvents: "none",
									children: [/* @__PURE__ */ T("polygon", {
										points: Q,
										transform: "scale(.87)",
										fill: "#f4f5d4",
										fillOpacity: ".15",
										stroke: "#faffdf",
										strokeWidth: "2.5"
									}), /* @__PURE__ */ T("circle", {
										cy: "-29",
										r: "4.2",
										fill: "#f8f7d3",
										stroke: "#4f785e",
										strokeWidth: "1.2"
									})]
								}),
								v && y && /* @__PURE__ */ E("g", {
									className: x ? "rebirth-placement" : void 0,
									children: [
										/* @__PURE__ */ T("polygon", {
											points: Q,
											transform: "translate(0 2) scale(.87)",
											fill: "#3b4a3c",
											opacity: ".22"
										}),
										/* @__PURE__ */ T("g", {
											clipPath: `url(#${m}-cell)`,
											opacity: _ ? .78 : 1,
											children: /* @__PURE__ */ T("g", {
												transform: "scale(.91)",
												children: /* @__PURE__ */ T(Be, {
													id: m,
													terrain: v.kind
												})
											})
										}),
										/* @__PURE__ */ T("polygon", {
											points: Q,
											transform: "scale(.91)",
											fill: "none",
											stroke: "#f9f0cf",
											strokeWidth: "4"
										}),
										/* @__PURE__ */ T("polygon", {
											points: Q,
											transform: "scale(.84)",
											fill: "none",
											stroke: u(y),
											strokeWidth: "4",
											strokeDasharray: _ ? "8 4" : void 0
										}),
										/* @__PURE__ */ T(Ge, {
											rid: y,
											avatar: f,
											name: c,
											color: u
										}),
										v.kind === "S" && /* @__PURE__ */ E("g", { children: [/* @__PURE__ */ T("circle", {
											cx: "25",
											cy: "-23",
											r: "11",
											fill: "#f9f0cf",
											stroke: u(y),
											strokeWidth: "2"
										}), /* @__PURE__ */ T("text", {
											x: "25",
											y: "-18",
											textAnchor: "middle",
											fontSize: "15",
											fontWeight: "800",
											fill: "#405247",
											className: "font-mono tabular-nums",
											children: v.influence
										})] })
									]
								}),
								t.terrain === "C" && e.castles[t.id] && !l && /* @__PURE__ */ T(Ge, {
									rid: e.castles[t.id],
									avatar: f,
									name: c,
									color: u
								}),
								e.towers[t.id] && !l && /* @__PURE__ */ T(Ke, {
									bonus: e.towers[t.id],
									id: m
								}),
								!l && b.map((e, n) => /* @__PURE__ */ E("g", {
									transform: `translate(${(n - (b.length - 1) / 2) * 13} ${t.terrain === "T" ? 40 : 31})`,
									children: [
										/* @__PURE__ */ T("title", { children: p("games.rebirth.visited", { names: c(e) }) }),
										/* @__PURE__ */ T("circle", {
											r: "6",
											fill: u(e),
											stroke: "#fff4d0",
											strokeWidth: "1.5"
										}),
										/* @__PURE__ */ T("image", {
											href: f(e),
											x: -5,
											y: -5,
											width: 10,
											height: 10,
											preserveAspectRatio: "xMidYMid meet",
											pointerEvents: "none"
										})
									]
								}, e)),
								t.bonus && !l && /* @__PURE__ */ E("g", { children: [/* @__PURE__ */ T("circle", {
									cx: "29",
									cy: "23",
									r: "11",
									fill: "#ecf4db",
									stroke: "#528491",
									strokeWidth: "2"
								}), /* @__PURE__ */ T("text", {
									x: "29",
									y: "27",
									textAnchor: "middle",
									fontSize: "12",
									fontWeight: "800",
									fill: "#387a8b",
									children: "+1"
								})] }),
								t.border && !l && /* @__PURE__ */ T("path", {
									d: "m21 35 4-6 4 6m-1-6 4-6 4 6",
									fill: "none",
									stroke: "#5e7f58",
									strokeWidth: "2"
								}),
								l && /* @__PURE__ */ E("g", {
									pointerEvents: "none",
									children: [
										/* @__PURE__ */ T("polygon", {
											points: Q,
											fill: `url(#${m}-blocked)`
										}),
										/* @__PURE__ */ T("circle", {
											r: "13",
											fill: "#c9cbb6",
											stroke: "#738573",
											strokeWidth: "2"
										}),
										/* @__PURE__ */ T("path", {
											d: "m-5-5 10 10m0-10L-5 5",
											stroke: "#65765f",
											strokeWidth: "3",
											strokeLinecap: "round"
										})
									]
								}),
								x && !g && /* @__PURE__ */ T("polygon", {
									points: Q,
									transform: "scale(.95)",
									fill: "none",
									stroke: "#fff8df",
									strokeWidth: "3"
								}),
								g && /* @__PURE__ */ E("g", {
									pointerEvents: "none",
									children: [
										/* @__PURE__ */ T("polygon", {
											points: Q,
											transform: "scale(1.04)",
											fill: "none",
											stroke: "#244b40",
											strokeWidth: "6"
										}),
										/* @__PURE__ */ T("polygon", {
											points: Q,
											transform: "scale(1.09)",
											fill: "none",
											stroke: "#fff8d4",
											strokeWidth: "2.5"
										}),
										_ && /* @__PURE__ */ T("path", {
											d: "m-9-57 9 9 9-9",
											fill: "none",
											stroke: "#224b3e",
											strokeWidth: "4",
											strokeLinecap: "round"
										})
									]
								}),
								x && Object.entries(e.last.gains).filter(([, e]) => e > 0).map(([t, n], r) => /* @__PURE__ */ E("text", {
									className: "rebirth-gain font-mono",
									x: "0",
									y: -48 - r * 24,
									textAnchor: "middle",
									fill: u(t),
									stroke: "#fff8df",
									strokeWidth: "5",
									paintOrder: "stroke",
									fontSize: "25",
									fontWeight: "800",
									pointerEvents: "none",
									children: ["+", n]
								}, `${e.turn}:${t}`)),
								/* @__PURE__ */ T("polygon", {
									className: "rebirth-cell-focus",
									points: Q,
									transform: "scale(.96)",
									fill: "none",
									stroke: "#243c35",
									strokeWidth: "6",
									pointerEvents: "none"
								})
							]
						}, t.id);
					})
				]
			}),
			/* @__PURE__ */ T("defs", { children: /* @__PURE__ */ T("pattern", {
				id: `${m}-blocked`,
				width: "14",
				height: "14",
				patternUnits: "userSpaceOnUse",
				children: /* @__PURE__ */ T("path", {
					d: "M-4 4 4-4M0 14 14 0M10 18 18 10",
					stroke: "#5e7862",
					strokeWidth: "2",
					opacity: ".12"
				})
			}) })
		]
	});
}
//#endregion
//#region src/games/rebirth/view-player.tsx
function Je({ title: e, close: t, children: n }) {
	let r = i(), a = d(null);
	return c(() => {
		let e = a.current;
		return e.showModal(), () => e.close();
	}, []), /* @__PURE__ */ T("dialog", {
		ref: a,
		className: "rebirth-dialog",
		"aria-label": e,
		onCancel: (e) => {
			e.preventDefault(), t();
		},
		onClick: (e) => {
			e.target === e.currentTarget && t();
		},
		children: /* @__PURE__ */ E("div", {
			className: "flex max-h-[80dvh] flex-col",
			children: [/* @__PURE__ */ E("div", {
				className: "flex flex-none items-center justify-between gap-3 border-b border-ink/20 p-3",
				children: [/* @__PURE__ */ T("h2", {
					className: "font-display text-lg font-extrabold",
					children: e
				}), /* @__PURE__ */ T("button", {
					className: "btn-quiet min-h-11 px-3",
					onClick: t,
					children: r("games.rebirth.close")
				})]
			}), /* @__PURE__ */ T("div", {
				className: "min-h-0 overflow-y-auto p-3",
				children: n
			})]
		})
	});
}
function Ye({ public: e, private: t, members: s, myRid: c, send: l }) {
	let u = r((e) => e.locale);
	te();
	let d = i(), h = e, _ = t, [S, C] = f({
		context: "",
		cell: "",
		tile: 0
	}), [D, O] = f(null), [ie, ae] = f(0), k = h.current === c && h.phase !== "done";
	x(k, b);
	let A = `${c}:${h.turn}:${h.extra}:${h.phase}`, j = S.context === A ? S.tile : 0, M = S.context === A ? S.cell : "", oe = _?.hand ?? [], N = oe[j], P = k && h.phase === "place" ? _?.legal[j] ?? [] : [], se = new Set(P), F = R[h.map][M], I = k && h.phase === "place" && se.has(M), z = (e) => {
		let t = s.find((t) => t.rid === e);
		return t ? a(e) === null ? t.name : n(u, t.avatar) : e;
	}, ce = (e) => p[(s.find((t) => t.rid === e)?.colorIndex ?? 0) % p.length].hex, B = (e) => e.kind === "S" ? d("games.rebirth.tileLabel", {
		kind: d(Z.S),
		n: e.influence
	}) : d(Z[e.kind]), H = (e) => e.landmark ? d(Ie[e.landmark]) : d(Z[e.terrain]), le = (e) => C({
		context: A,
		cell: e,
		tile: j
	}), K = (e) => {
		if (!P.length) return;
		let t = P.indexOf(M);
		le(P[t < 0 ? 0 : (t + e + P.length) % P.length]);
	}, q = (e, t, n) => /* @__PURE__ */ T("button", {
		className: "rebirth-hand-tile",
		disabled: !n,
		"aria-label": d("games.rebirth.chooseTile", { n: t + 1 }) + ": " + B(e),
		"aria-pressed": n && j === t,
		onClick: () => C({
			context: A,
			cell: "",
			tile: t
		}),
		children: /* @__PURE__ */ T($, {
			terrain: e.kind,
			influence: e.influence,
			selected: j === t
		})
	}, t), ue = F && /* @__PURE__ */ E("div", {
		className: "space-y-3 text-sm",
		children: [/* @__PURE__ */ E("div", {
			className: "rebirth-detail-piece",
			children: [/* @__PURE__ */ T($, {
				terrain: h.board[F.id]?.tile.kind ?? F.terrain,
				influence: h.board[F.id]?.tile.influence
			}), /* @__PURE__ */ E("p", { children: [
				d("games.rebirth.cell", {
					row: F.row + 1,
					col: F.col + 1
				}),
				" · ",
				d(Z[F.terrain])
			] })]
		}), F.blockedForTwo && h.players.length === 2 ? /* @__PURE__ */ T("p", { children: d("games.rebirth.blocked") }) : /* @__PURE__ */ E(w, { children: [
			/* @__PURE__ */ T("p", { children: [
				F.bonus && d(h.map === "scotland" ? "games.rebirth.port" : "games.rebirth.offshore"),
				F.coast && d("games.rebirth.coastal"),
				F.border && d("games.rebirth.border")
			].filter(Boolean).join(" · ") }),
			h.board[F.id] && /* @__PURE__ */ E("p", { children: [
				d("games.rebirth.owned", { name: z(h.board[F.id].owner) }),
				" · ",
				B(h.board[F.id].tile)
			] }),
			F.settlement !== null && /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T("p", {
				className: "font-bold",
				children: d("games.rebirth.settlementStatus", {
					size: L[h.map][F.settlement].length,
					n: L[h.map][F.settlement].filter((e) => h.board[e]).length
				})
			}), h.players.map((e) => /* @__PURE__ */ T("p", { children: d("games.rebirth.influence", {
				name: z(e),
				n: L[h.map][F.settlement].reduce((t, n) => t + (h.board[n]?.owner === e ? h.board[n].tile.influence : 0), 0)
			}) }, e))] }),
			(F.terrain === "C" || F.terrain === "T" || F.terrain === "D") && /* @__PURE__ */ E("div", { children: [F.terrain === "C" && /* @__PURE__ */ T("p", {
				className: "mb-2 font-bold",
				children: h.castles[F.id] ? d("games.rebirth.controlled", { name: z(h.castles[F.id]) }) : d("games.rebirth.unclaimed")
			}), h.players.map((e) => /* @__PURE__ */ T("p", { children: d("games.rebirth.neighbors", {
				name: z(e),
				n: U(h, F.id, e),
				farms: U(h, F.id, e, !0)
			}) }, e))] }),
			(F.terrain === "D" || F.terrain === "T") && /* @__PURE__ */ T("p", { children: h.visited[F.id]?.length ? d("games.rebirth.visited", { names: h.visited[F.id].map(z).join(", ") }) : d("games.rebirth.notVisited") }),
			h.towers[F.id] && /* @__PURE__ */ E("div", { children: [/* @__PURE__ */ T("p", {
				className: "font-bold",
				children: d(Pe[h.towers[F.id]])
			}), ["set13", "double"].includes(h.towers[F.id]) && /* @__PURE__ */ T("p", { children: d("games.rebirth.towerProgress", {
				n: Object.entries(h.towers).filter(([e, t]) => t === h.towers[F.id] && h.visited[e]?.includes(c)).length,
				total: h.towers[F.id] === "set13" ? 3 : 2
			}) })] })
		] })]
	}), J = (e, t) => {
		let n = V(h.map, e), r = t === void 0 ? h.missions.find((t) => t.id === e) : void 0, i = W(h, c, e), a = r?.claims.some((e) => e.rid === c), o = k && h.phase === "double" && r && !a;
		return /* @__PURE__ */ E("article", {
			className: "rebirth-mission",
			"data-terrain": Fe(h.map, e),
			"data-completed": a || void 0,
			children: [
				/* @__PURE__ */ E("div", {
					className: "rebirth-mission-heading",
					"data-public": !!r || void 0,
					children: [
						/* @__PURE__ */ T($, { terrain: Fe(h.map, e) }),
						/* @__PURE__ */ T("h3", { children: d(n.key) }),
						!r && /* @__PURE__ */ T("strong", {
							className: "rebirth-mission-value font-mono tabular-nums",
							title: d("games.rebirth.points", { n: n.high }),
							children: n.high
						})
					]
				}),
				r && /* @__PURE__ */ T("p", {
					className: "mt-1 text-xs text-ink/70",
					children: d("games.rebirth.firstLater", {
						high: n.high,
						low: n.low
					})
				}),
				/* @__PURE__ */ T("p", {
					className: "mt-1 font-mono text-xs",
					children: a ? d("games.rebirth.completed") : h.map === "ireland" ? d("games.rebirth.progress", {
						n: Math.min(i, G[e]),
						target: G[e]
					}) : e === 23 ? "" : d("games.rebirth.currentValue", { n: i })
				}),
				h.map === "ireland" && /* @__PURE__ */ T("progress", {
					className: "rebirth-mission-progress",
					max: G[e],
					value: a ? G[e] : Math.min(i, G[e]),
					"aria-label": d("games.rebirth.progress", {
						n: Math.min(i, G[e]),
						target: G[e]
					})
				}),
				r?.claims.map((e) => /* @__PURE__ */ T("p", {
					className: "mt-1 text-xs",
					children: d("games.rebirth.claim", {
						name: z(e.rid),
						n: e.points
					})
				}, e.rid)),
				r && Object.entries(h.doubles).filter(([, t]) => t === e).map(([e]) => /* @__PURE__ */ E("p", {
					className: "mt-1 text-xs font-bold",
					children: ["×2 ", d("games.rebirth.doubled", { name: z(e) })]
				}, e)),
				o && /* @__PURE__ */ T("button", {
					className: "rebirth-confirm mt-3 w-full",
					onClick: () => {
						l({
							type: "double",
							mission: e
						}), O(null);
					},
					children: d("games.rebirth.doubleMission")
				})
			]
		}, t === void 0 ? e : `private:${t}`);
	}, de = /* @__PURE__ */ E(w, { children: [
		/* @__PURE__ */ T("button", {
			className: "btn-quiet mb-3 min-h-11 w-full",
			onClick: () => O("reserve"),
			children: d("games.rebirth.setAside")
		}),
		h.missions.length > 0 && /* @__PURE__ */ E(w, { children: [/* @__PURE__ */ T("h3", {
			className: "section-label mb-2",
			children: d("games.rebirth.publicMissions")
		}), /* @__PURE__ */ T("div", {
			className: "grid grid-cols-1 gap-2",
			children: h.missions.map((e) => J(e.id))
		})] }),
		/* @__PURE__ */ T("h3", {
			className: "section-label mt-4 mb-2",
			children: d("games.rebirth.privateMissions")
		}),
		/* @__PURE__ */ T("div", {
			className: "grid grid-cols-1 gap-2",
			children: _?.missions.length ? _.missions.map((e, t) => J(e, t)) : /* @__PURE__ */ T("p", {
				className: "text-sm text-ink/60",
				children: d("games.rebirth.noMissions")
			})
		})
	] }), fe = k ? h.phase === "double" ? d("games.rebirth.doublePrompt") : h.extra ? d("games.rebirth.extraPrompt") : N ? d("games.rebirth.placeTile", { tile: d(Z[N.kind]) }) : d("games.rebirth.placePrompt") : d("games.rebirth.wait", { name: z(h.current) }), pe = N?.kind ?? "B";
	return /* @__PURE__ */ E("div", {
		className: "rebirth-game",
		children: [
			/* @__PURE__ */ T(ne, {
				adaptive: !0,
				className: "rebirth-screen",
				scroll: !1,
				banner: /* @__PURE__ */ E("div", {
					className: "rebirth-header",
					children: [/* @__PURE__ */ E("div", {
						className: "rebirth-phase",
						role: "status",
						"data-active": k || void 0,
						children: [/* @__PURE__ */ T($, { terrain: k ? pe : "B" }), /* @__PURE__ */ E("div", {
							className: "rebirth-phase-copy",
							children: [/* @__PURE__ */ T("p", {
								title: fe,
								children: fe
							}), /* @__PURE__ */ T("span", { children: d("games.rebirth.turn", { n: h.turn }) })]
						})]
					}), /* @__PURE__ */ T("ul", {
						className: "rebirth-players",
						style: { gridTemplateColumns: `repeat(${h.players.length}, minmax(0, 1fr))` },
						children: h.players.map((e) => {
							let t = s.find((t) => t.rid === e), n = Object.values(h.castles).filter((t) => t === e).length;
							return /* @__PURE__ */ E("li", {
								className: "rebirth-seat",
								"data-current": h.current === e || void 0,
								"aria-label": z(e) + ": " + d("games.rebirth.scoreLine", {
									score: h.scores[e],
									castles: n,
									remaining: h.remaining[e]
								}),
								children: [
									/* @__PURE__ */ T("span", {
										className: "rebirth-seat-avatar",
										children: t && /* @__PURE__ */ T(re, {
											m: t,
											myRid: c,
											action: h.current === e && e !== c ? "pending" : null,
											anchorName: null,
											box: "size-7",
											img: "size-6"
										})
									}),
									/* @__PURE__ */ T("span", {
										className: "rebirth-seat-name",
										title: z(e),
										children: z(e)
									}),
									/* @__PURE__ */ E("strong", {
										className: "rebirth-seat-score",
										children: [/* @__PURE__ */ T(y, {
											value: h.scores[e],
											className: "font-mono tabular-nums"
										}), /* @__PURE__ */ T("span", { children: d("games.rebirth.scoreUnit") })]
									}),
									/* @__PURE__ */ T("span", {
										className: "rebirth-seat-castles",
										children: d("games.rebirth.castleCount", { n })
									})
								]
							}, e);
						})
					})]
				}),
				children: /* @__PURE__ */ E("div", {
					className: "rebirth-layout",
					children: [/* @__PURE__ */ E("div", {
						className: "rebirth-board",
						children: [
							/* @__PURE__ */ T(ee, {
								kind: "sheen",
								base: "#9ecbd0",
								className: "absolute inset-0 overflow-hidden rounded-[inherit]"
							}),
							/* @__PURE__ */ E("svg", {
								className: "rebirth-sea-texture",
								"aria-hidden": !0,
								children: [/* @__PURE__ */ T("defs", { children: /* @__PURE__ */ T("pattern", {
									id: "rebirth-sea-waves",
									width: "46",
									height: "36",
									patternUnits: "userSpaceOnUse",
									children: /* @__PURE__ */ T("path", {
										d: "M5 13q5 3 10 0m15 16q4 2 8 0",
										stroke: "#f1fbef",
										strokeWidth: ".7",
										fill: "none",
										opacity: ".21"
									})
								}) }), /* @__PURE__ */ T("rect", {
									width: "100%",
									height: "100%",
									fill: "url(#rebirth-sea-waves)"
								})]
							}),
							/* @__PURE__ */ E("div", {
								className: "rebirth-map-tools",
								children: [/* @__PURE__ */ T("span", {
									className: "rebirth-map-label",
									children: d(Me[h.map])
								}), /* @__PURE__ */ T("button", {
									className: "rebirth-overview",
									onClick: () => ae((e) => e + 1),
									children: d("games.rebirth.overview")
								})]
							}),
							/* @__PURE__ */ T(qe, {
								avatar: (e) => o[(s.find((t) => t.rid === e)?.avatar ?? 0) % o.length],
								pub: h,
								legal: P,
								selected: M,
								preview: N,
								myRid: c,
								fit: ie,
								choose: le,
								name: z,
								color: ce,
								cellLabel: H
							}),
							/* @__PURE__ */ T("div", {
								className: "rebirth-board-overlay",
								children: F ? /* @__PURE__ */ E("button", {
									className: "rebirth-selection",
									onClick: () => O("detail"),
									children: [
										/* @__PURE__ */ T($, {
											terrain: I && N ? N.kind : h.board[F.id]?.tile.kind ?? F.terrain,
											influence: I ? N?.influence : h.board[F.id]?.tile.influence
										}),
										/* @__PURE__ */ E("span", { children: [/* @__PURE__ */ T("strong", { children: H(F) }), /* @__PURE__ */ T("span", { children: h.board[F.id] ? z(h.board[F.id].owner) : d("games.rebirth.cell", {
											row: F.row + 1,
											col: F.col + 1
										}) })] }),
										/* @__PURE__ */ T(g, {
											size: 16,
											className: "-rotate-90",
											"aria-hidden": !0
										})
									]
								}) : null
							})
						]
					}), /* @__PURE__ */ E("aside", {
						className: "rebirth-sidebar",
						children: [/* @__PURE__ */ E("div", {
							className: "rebirth-actions",
							children: [/* @__PURE__ */ E("div", {
								className: "rebirth-hand-row",
								children: [/* @__PURE__ */ E("div", {
									className: "rebirth-hand",
									"data-multiple": oe.length > 1 || void 0,
									children: [/* @__PURE__ */ T("div", {
										className: "rebirth-hand-tiles",
										children: oe.map((e, t) => q(e, t, k && h.phase === "place"))
									}), /* @__PURE__ */ E("div", {
										className: "rebirth-hand-label",
										children: [/* @__PURE__ */ T("strong", {
											title: N ? B(N) : void 0,
											children: d(N ? Z[N.kind] : "games.rebirth.hand")
										}), /* @__PURE__ */ T("span", { children: d("games.rebirth.reserveLeft", { n: h.remaining[c] ?? 0 }) })]
									})]
								}), /* @__PURE__ */ E("button", {
									className: "rebirth-tasks-button",
									onClick: () => O("missions"),
									children: [
										/* @__PURE__ */ T(v, {
											size: 17,
											"aria-hidden": !0
										}),
										/* @__PURE__ */ T("span", { children: d("games.rebirth.tasks") }),
										!!_?.missions.length && /* @__PURE__ */ T("span", {
											className: "rebirth-task-count",
											children: _.missions.length
										})
									]
								})]
							}), /* @__PURE__ */ E("div", {
								className: "rebirth-controls",
								children: [
									/* @__PURE__ */ T("button", {
										className: "rebirth-step",
										"aria-label": d("games.rebirth.previous"),
										disabled: !P.length,
										onClick: () => K(-1),
										children: /* @__PURE__ */ T(m, {
											size: 19,
											"aria-hidden": !0
										})
									}),
									/* @__PURE__ */ T("button", {
										className: "rebirth-confirm",
										disabled: h.phase === "double" ? !k : !I,
										onClick: () => {
											if (h.phase === "double") {
												O("missions");
												return;
											}
											l({
												type: "place",
												cell: M,
												tile: j
											}), C({
												context: "",
												cell: "",
												tile: 0
											});
										},
										children: h.phase === "double" && k ? d("games.rebirth.chooseMission") : d(k ? I ? "games.rebirth.confirm" : "games.rebirth.chooseCell" : "games.rebirth.waiting")
									}),
									/* @__PURE__ */ T("button", {
										className: "rebirth-step",
										"aria-label": d("games.rebirth.next"),
										disabled: !P.length,
										onClick: () => K(1),
										children: /* @__PURE__ */ T(m, {
											size: 19,
											className: "rotate-180",
											"aria-hidden": !0
										})
									})
								]
							})]
						}), /* @__PURE__ */ T("div", {
							className: "rebirth-missions-sidebar",
							children: D !== "missions" && de
						})]
					})]
				})
			}),
			D === "detail" && F && /* @__PURE__ */ T(Je, {
				title: H(F),
				close: () => O(null),
				children: ue
			}),
			D === "reserve" && /* @__PURE__ */ E(Je, {
				title: d("games.rebirth.setAside"),
				close: () => O(null),
				children: [/* @__PURE__ */ T("p", {
					className: "mb-3 text-sm",
					children: d("games.rebirth.reserveLeft", { n: h.map === "scotland" ? _?.setAside.length ?? 0 : h.reservedCount[c] ?? 0 })
				}), /* @__PURE__ */ T("div", {
					className: "rebirth-reserve",
					children: _?.setAside.map((e, t) => /* @__PURE__ */ T("div", {
						title: B(e),
						role: "img",
						"aria-label": B(e),
						children: /* @__PURE__ */ T($, {
							terrain: e.kind,
							influence: e.influence
						})
					}, t))
				})]
			}),
			D === "missions" && /* @__PURE__ */ T(Je, {
				title: d("games.rebirth.tasks"),
				close: () => O(null),
				children: de
			})
		]
	});
}
//#endregion
//#region src/games/rebirth/bot.ts
function Xe(e) {
	let t = Math.floor(4294967296 / e.length) * e.length, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return e[n[0] % e.length];
}
function Ze(e, t, n, r) {
	let i = R[e.map][r], a = {
		...e,
		board: {
			...e.board,
			[r]: {
				owner: t,
				tile: n
			}
		},
		castles: { ...e.castles }
	}, o = +!!i.bonus;
	if (n.kind === "S") {
		let s = Ce(a, r, t);
		if (o += (s[t] ?? 0) - Object.entries(s).reduce((e, [n, r]) => e + (n === t ? 0 : r * .5), 0), Object.keys(s).length === 0) {
			let r = L[e.map][i.settlement], s = r.reduce((e, n) => e + (a.board[n]?.owner === t ? a.board[n].tile.influence : 0), 0);
			o += n.influence * .55 + s / r.length;
		}
	} else {
		let s = Object.keys(a.board).filter((e) => a.board[e].owner === t && a.board[e].tile.kind === n.kind);
		o += H(e.map, s).find((e) => e.includes(r)).length, o += i.neighbors.filter((t) => !e.board[t] && ["B", n.kind].includes(R[e.map][t].terrain)).length * .17;
	}
	for (let n of i.neighbors) {
		let r = R[e.map][n];
		if (!(e.players.length === 2 && r.blockedForTwo)) {
			if (r.terrain === "C") {
				let r = e.castles[n], i = U(a, n, t), s = r ? U(a, n, r) : 0;
				r !== t && (i > s || i === s && U(a, n, t, !0) > U(a, n, r, !0)) ? (a.castles[n] = t, o += r ? 3.4 : 2.4) : r === t && (o += .45);
			}
			if (!e.visited[n]?.includes(t) && (r.terrain === "D" && (o += 2.2), r.terrain === "T")) {
				let r = e.towers[n], i = Object.entries(e.towers).filter(([n, i]) => i === r && e.visited[n]?.includes(t)).length;
				r === "score3" && (o += 3), r === "set13" && (o += [
					1.5,
					3,
					13
				][i]), r === "extra" && !e.extra && e.reservedCount[t] > 0 && (o += 3), r === "draw3" && (o += 1.4), r === "mission" && (o += 3.2), r === "double" && (o += i ? 3.5 : 1);
			}
		}
	}
	for (let n of e.missions) {
		if (n.claims.some((e) => e.rid === t)) continue;
		let r = W(e, t, n.id), i = W(a, t, n.id);
		if (i >= G[n.id]) {
			let r = V("ireland", n.id);
			o += (n.claims.length ? r.low : r.high) * (e.doubles[t] === n.id ? 2 : 1);
		} else o += Math.max(0, i - r) / G[n.id] * 2;
	}
	return o;
}
var Qe = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || n.current !== t.rid || n.phase === "done") return null;
	if (n.phase === "double") {
		let e = n.missions.filter((e) => !e.claims.some((e) => e.rid === t.rid));
		return e.length ? { action: {
			type: "double",
			mission: (t.difficulty === "weak" ? Xe(e) : [...e].sort((e, r) => {
				let i = (e) => W(n, t.rid, e) / G[e] * V("ireland", e).high;
				return i(r.id) - i(e.id);
			})[0]).id
		} } : null;
	}
	let i = r.hand.flatMap((e, i) => (r.legal[i] ?? []).map((r) => ({
		tile: i,
		cell: r,
		value: t.difficulty === "weak" ? 0 : Ze(n, t.rid, e, r)
	})));
	if (!i.length) return null;
	if (t.difficulty !== "weak" && (i.sort((e, t) => t.value - e.value), n.map === "scotland")) {
		for (let e of i.slice(0, 10)) {
			let i = {
				...n,
				board: {
					...n.board,
					[e.cell]: {
						owner: t.rid,
						tile: r.hand[e.tile]
					}
				}
			};
			for (let a of r.missions) {
				if (a === 23) continue;
				let r = W(i, t.rid, a) - W(n, t.rid, a);
				e.value += Math.max(0, r) * (K(i, t.rid, a) ? .9 : .4);
			}
		}
		i.sort((e, t) => t.value - e.value);
	}
	let a = t.difficulty === "weak" ? Xe(i) : i[0];
	return { action: {
		type: "place",
		cell: a.cell,
		tile: a.tile
	} };
}, $e = (e, t, n) => {
	if (e.type === "double") return n("games.rebirth.hintDouble", { mission: n(V(t.public.map, e.mission).key) });
	let r = R[t.public.map][e.cell], i = t.private?.hand[e.tile];
	return n("games.rebirth.hintPlace", {
		tile: i ? i.kind === "S" ? n("games.rebirth.tileLabel", {
			kind: n(Z.S),
			n: i.influence
		}) : n(Z[i.kind]) : "",
		row: r.row + 1,
		col: r.col + 1
	});
};
//#endregion
//#region src/games/rebirth/endgame-review.tsx
function et({ board: e, renderResult: t, ...n }) {
	let r = i(), [a, o] = f(!0), [s, l] = f(null), p = d(null), h = d(null), v = d(null);
	c(() => {
		if (!s) return;
		v.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => l(null), 5e3);
		return () => clearTimeout(e);
	}, [s]);
	let y = (e) => {
		l(null), o(e), requestAnimationFrame(() => (e ? p : h).current?.focus({ preventScroll: !0 }));
	}, b = u(() => ({
		onPlayAgain: n.onPlayAgain && (() => l({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => l({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => l({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), x = {
		...n,
		...b
	};
	return /* @__PURE__ */ E("div", {
		className: "rebirth-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ T("div", {
				className: "rebirth-endgame-board",
				inert: a,
				children: e
			}),
			/* @__PURE__ */ T("div", {
				className: "rebirth-endgame-overlay",
				hidden: !a,
				children: /* @__PURE__ */ E("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), y(!1));
					},
					className: "rebirth-endgame-panel",
					"aria-label": r("session.result.title"),
					children: [
						/* @__PURE__ */ E("header", {
							className: "rebirth-endgame-heading",
							children: [/* @__PURE__ */ E("div", {
								className: "rebirth-endgame-brand",
								children: [/* @__PURE__ */ T("span", {
									"aria-hidden": "true",
									children: q.icon
								}), r(q.nameKey)]
							}), /* @__PURE__ */ T("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": r("games.rebirth.reviewHide"),
								title: r("games.rebirth.reviewHide"),
								onClick: () => y(!1),
								children: /* @__PURE__ */ T(g, { size: 19 })
							})]
						}),
						/* @__PURE__ */ T("div", {
							className: "rebirth-endgame-result",
							inert: s !== null,
							children: t(x)
						}),
						s && /* @__PURE__ */ E("div", {
							className: "rebirth-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || l(null);
							},
							children: [/* @__PURE__ */ T("button", {
								type: "button",
								ref: v,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = s.run;
									l(null), e();
								},
								children: r(s.label === "again" ? "games.rebirth.reviewConfirmAgain" : "games.rebirth.reviewConfirmLobby")
							}), /* @__PURE__ */ T("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									l(null), p.current?.focus({ preventScroll: !0 });
								},
								children: r("games.rebirth.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ T("div", {
				className: "rebirth-endgame-toolbar",
				hidden: a,
				children: /* @__PURE__ */ E("button", {
					type: "button",
					className: "btn-base",
					ref: h,
					onClick: () => y(!0),
					children: [
						/* @__PURE__ */ T(_, { size: 18 }),
						r("games.rebirth.reviewShow"),
						/* @__PURE__ */ T(m, { size: 18 })
					]
				})
			})
		]
	});
}
function tt({ result: e, members: t, myRid: n, hintCount: a, onPlayAgain: o, onBackToLobby: c, rows: l, renderRowExtra: u, summary: d, navigation: p, content: m, afterRanking: _, scoreUnit: v, rankOf: y }) {
	let b = i(), x = r((e) => e.locale), [ee, te] = f({}), ne = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? S(n, x) : e;
	}, re = (t, n) => y?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), C = e.ranking.some((t) => e.scores?.[t] !== void 0), O = (t, r) => /* @__PURE__ */ E("div", {
		className: "rebirth-score-identity",
		children: [
			/* @__PURE__ */ E("span", {
				className: "rebirth-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ T("span", {
					"aria-label": b("games.rebirth.reviewWinner"),
					children: "♛ "
				}), C && re(t, r)]
			}),
			/* @__PURE__ */ E("span", {
				className: "rebirth-score-name",
				children: [ne(t), t === n && /* @__PURE__ */ T("small", { children: b("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ E("small", {
				className: "rebirth-score-autopilot",
				children: [
					/* @__PURE__ */ T(h, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), ie = (t) => e.ranking.map((n) => /* @__PURE__ */ T("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ E("div", {
		className: "rebirth-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ T(D, {}),
			p,
			/* @__PURE__ */ E("div", {
				className: "rebirth-score-body",
				children: [
					d && /* @__PURE__ */ T("div", {
						className: "rebirth-score-summary",
						children: d
					}),
					a !== void 0 && /* @__PURE__ */ T("p", {
						className: "rebirth-score-hints",
						children: b("session.hint.usedCount", { n: a })
					}),
					m ?? (l?.length ? /* @__PURE__ */ T("div", {
						className: "rebirth-score-table-scroll",
						children: /* @__PURE__ */ E("table", {
							className: "rebirth-score-table",
							"aria-label": b(q.nameKey),
							children: [
								/* @__PURE__ */ T("thead", { children: /* @__PURE__ */ E("tr", { children: [/* @__PURE__ */ T("th", { scope: "col" }), /* @__PURE__ */ T(w, { children: e.ranking.map((t, n) => /* @__PURE__ */ T("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: O(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ T("tbody", { children: l.map((e, t) => /* @__PURE__ */ E(s, { children: [/* @__PURE__ */ E("tr", { children: [/* @__PURE__ */ T("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ E("button", {
										type: "button",
										"aria-expanded": !!ee[t],
										onClick: () => te((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ T(g, { size: 15 }), e.label]
									}) : e.label
								}), ie(e)] }), ee[t] && e.details?.map((e, t) => /* @__PURE__ */ E("tr", {
									className: "rebirth-score-sub",
									children: [/* @__PURE__ */ T("th", {
										scope: "row",
										children: e.label
									}), ie(e)]
								}, t))] }, t)) }),
								C && /* @__PURE__ */ T("tfoot", { children: /* @__PURE__ */ E("tr", { children: [/* @__PURE__ */ T("th", {
									scope: "row",
									children: b("games.rebirth.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ T("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ T("ol", {
						className: "rebirth-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ E("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ E("div", {
								className: "rebirth-score-rankline",
								children: [O(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ E("strong", {
									className: "rebirth-score-points",
									children: [e.scores[t], v && /* @__PURE__ */ T("small", { children: v })]
								})]
							}), u?.(t)]
						}, t))
					})),
					_,
					!!l?.length && u && /* @__PURE__ */ T("div", {
						className: "rebirth-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ E("details", { children: [/* @__PURE__ */ T("summary", { children: ne(e) }), u(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ E("footer", {
				className: "rebirth-score-actions",
				children: [
					c && /* @__PURE__ */ T("button", {
						type: "button",
						className: "btn-quiet",
						onClick: c,
						children: b("session.result.backToLobby")
					}),
					o && /* @__PURE__ */ T("button", {
						type: "button",
						className: "btn-base",
						onClick: o,
						children: b("session.result.playAgain")
					}),
					!o && !c && /* @__PURE__ */ T("p", { children: b("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/rebirth/endgame-scores.tsx
function nt(e) {
	let t = i(), n = e.public, r = [
		["farms", "games.rebirth.reviewFarms"],
		["settlements", "games.rebirth.reviewSettlements"],
		["bonuses", "games.rebirth.reviewBonuses"],
		["castles", "games.rebirth.reviewCastles"],
		["missions", "games.rebirth.reviewMissions"]
	].map(([e, r]) => ({
		label: t(r),
		value: (t) => n.breakdown[t]?.[e] ?? "—"
	}));
	return /* @__PURE__ */ T(tt, {
		...e,
		rows: r,
		renderRowExtra: (e) => /* @__PURE__ */ T(w, { children: n.revealed[e]?.map((e, r) => /* @__PURE__ */ E("p", { children: [
			t(V(n.map, e.id).key),
			" · ",
			t("games.rebirth.points", { n: e.points })
		] }, r)) })
	});
}
//#endregion
//#region src/games/rebirth/game-over.tsx
function rt(e) {
	return /* @__PURE__ */ T(nt, { ...e });
}
function it(e) {
	return /* @__PURE__ */ T(et, {
		...e,
		board: /* @__PURE__ */ T(Ye, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ T(rt, { ...e })
	});
}
//#endregion
//#region src/games/rebirth/game-over-row.tsx
var at = {
	edinburgh: "games.rebirth.tieEdinburgh",
	stirling: "games.rebirth.tieStirling",
	blarney: "games.rebirth.tieBlarney",
	tara: "games.rebirth.tieTara"
};
function ot({ public: e, rid: t }) {
	let n = i(), r = e, a = r.breakdown[t];
	return a ? /* @__PURE__ */ E("div", {
		className: "rebirth-over-row mt-2 space-y-1 text-xs text-ink/70",
		children: [
			/* @__PURE__ */ T("p", { children: n("games.rebirth.overLine", a) }),
			r.tieBreak !== "none" && /* @__PURE__ */ T("p", {
				className: "font-bold",
				children: n(at[r.tieBreak])
			}),
			r.revealed[t]?.map((e, t) => /* @__PURE__ */ E("p", { children: [
				n(V(r.map, e.id).key),
				" · ",
				n("games.rebirth.points", { n: e.points })
			] }, t))
		]
	}) : null;
}
//#endregion
//#region src/games/rebirth/options.tsx
function st({ value: e, onChange: t }) {
	let n = i(), r = ue.safeParse(e), a = r.success ? r.data : ue.parse(void 0);
	return /* @__PURE__ */ E(ie, {
		title: n("games.rebirth.map"),
		children: [/* @__PURE__ */ T(O, {
			name: "rebirth-map",
			value: "scotland",
			checked: a.map === "scotland",
			label: n("games.rebirth.scotland"),
			hint: n("games.rebirth.scotlandHint"),
			accent: q.accent,
			onChange: () => t({ map: "scotland" })
		}), /* @__PURE__ */ T(O, {
			name: "rebirth-map",
			value: "ireland",
			checked: a.map === "ireland",
			label: n("games.rebirth.ireland"),
			hint: n("games.rebirth.irelandHint"),
			accent: q.accent,
			onChange: () => t({ map: "ireland" })
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/rebirth/entry.tsx
var ct = {
	definition: je,
	View: Ye,
	bot: Qe,
	describe: $e,
	OverView: it,
	RowView: ot,
	Options: st,
	locales: {
		zh: {
			reviewFarms: "农场",
			reviewSettlements: "聚落",
			reviewBonuses: "特殊奖励",
			reviewCastles: "城堡",
			reviewMissions: "任务",
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "重筑家园",
			desc: "重建苏格兰与爱尔兰，发展农场、争夺城堡并完成使命",
			rules: "目标：通过重建家园获得最高总分。\n准备：\n· 可选择苏格兰或爱尔兰地图，采用官方 1.2b 规则。\n· 每人有能源农场和粮食农场各 12 块，影响力为 1、2、3、4 的聚落板块各 3 块。\n· 4 人局每人移除能源农场和粮食农场各 3 块。\n· 4 人局每人另移除影响力为 2、3、4 的聚落板块各 1 块。\n· 将自己的板块洗混。苏格兰随机留出 2 块，本局不使用。\n· 爱尔兰随机留出 4 块，供圆塔奖励使用。可以随时查看自己留出的板块种类。\n· 每人提前抽取 1 块作为手牌。从首位玩家开始，顺时针行动。\n· 2 人局封锁地图上标记的区域：苏格兰 32 格，爱尔兰 24 格。封锁格不参与游戏。\n放置：\n· 每回合将手牌放在一个未被占用的合法格上，结算后抽取下回合的 1 块手牌。\n· 能源农场放在能源或空白农场格；粮食农场放在粮食或空白农场格。\n· 聚落板块只能放在聚落格。城堡、教堂、圆塔格不能放置板块。\n· 对应类型的农场格和空白农场格均已被占用时，才允许改放到另一类型的农场格。\n得分：\n· 同一玩家、同一类型且相连的农场构成农场群。不同类型或不同玩家的农场不能连成同一群。\n· 每次放置农场板块，立即获得放置后所在农场群的板块数量分数。\n· 单格小型聚落立即获得所放板块的影响力分数。\n· 多格聚落填满时，按各玩家在其中的影响力总和排名。\n· 中型聚落奖励为 5、3 分；大型聚落为 8、5 分，其余玩家不得分。\n· 爱尔兰的四格扩展聚落奖励为 12、8、5 分，其余玩家不得分。\n· 聚落影响力相同时，完成该聚落的玩家排在并列玩家之后。\n· 其他并列玩家从完成者的下一位开始，按顺时针优先。未分配的奖励归第一名。\n· 放置在苏格兰港口格或爱尔兰离岸农场格，额外获得 1 分。\n· 每座城堡由占用相邻格最多的玩家控制。相同时，比较相邻农场板块数量。\n· 相邻格数和农场数量仍相同时，当前落子者不能夺取城堡。\n苏格兰：\n· 每位玩家第一次在一座教堂旁放置板块时，获得一张私人任务。每座教堂每人限一次。\n· 私人任务在终局计分：达成条件获得 5 分，条件并列最多也视为达成。\n· 教堂奖励卡无条件获得 3 分。\n爱尔兰：\n· 随机公开 8 张公共任务，其余 4 张放在任务牌堆中。每人每张公共任务只能完成一次。\n· 首次完成者获得较高分，之后完成者获得较低分。一次放置可以完成多张任务。\n· 连接城堡或圆塔的任务，要求用自己的连续板块接触指定数量的建筑。建筑本身不能作为路径。\n· 沿海任务要求占用连续的沿海格。\n· 每位玩家首次占用圆塔相邻格时，触发该塔奖励。同一圆塔每人只能触发一次。\n· 两座奖励圆塔各提供 3 分；到访全部三座同类圆塔获得 13 分。\n· 额外放置圆塔：从留出的板块中随机抽取 1 块并立即放置，正常结算。\n· 每回合最多触发一次额外放置。额外板块触及另一座此类圆塔时，忽略该塔奖励。\n· 抽取三块圆塔：回合结束时，从供应中抽取最多 3 块。\n· 下回合选择其中 1 块放置，然后将其余板块洗回供应。\n· 私人任务圆塔：从剩余任务牌堆抽取 1 张私人任务。\n· 私人任务在终局达成时获得牌面较高分；抽取前已经达成也可计分。\n· 翻倍圆塔：到访两座此类圆塔后，将翻倍标记放在一张自己尚未完成的公共任务上。\n· 之后完成该任务时，实际获得的高分或低分均翻倍。\n终局：\n· 所有玩家用完手牌与供应后游戏结束。未完成聚落中的板块各按影响力计分。\n· 每座控制的城堡获得 5 分。公开并结算私人任务。\n· 苏格兰最高分并列时，优先由并列玩家中控制爱丁堡城堡者获胜。\n· 若无人符合，则控制斯特灵城堡的玩家获胜，即使其并非最高分。\n· 斯特灵城堡也无人控制时，最高分玩家共享胜利。\n· 爱尔兰最高分并列时，优先由并列玩家中控制布拉尼城堡者获胜。\n· 若无人符合，则所有玩家中占用塔拉山圆塔相邻格最多者获胜，即使其并非最高分。\n· 塔拉山仍并列时，共享胜利。",
			map: "地图",
			scotland: "苏格兰",
			ireland: "爱尔兰",
			scotlandHint: "私人任务与教堂",
			irelandHint: "公共任务与圆塔",
			energy: "能源农场",
			food: "粮食农场",
			settlement: "聚落",
			flexible: "农场空白格",
			castle: "城堡",
			cathedral: "教堂",
			tower: "圆塔",
			turn: "回合 {{n}}",
			placePrompt: "选择位置放置板块",
			extraPrompt: "放置额外板块",
			doublePrompt: "选择一张公共任务进行翻倍",
			placeTile: "放置{{tile}}",
			scoreUnit: "分",
			castleCount: "{{n}} 座城堡",
			chooseMission: "选择翻倍任务",
			waiting: "等待行动",
			wait: "等待 {{name}} 行动",
			confirm: "确认放置",
			chooseCell: "请选择一个合法位置",
			tasks: "任务",
			close: "关闭",
			overview: "全景",
			previous: "上一个合法位置",
			next: "下一个合法位置",
			publicMissions: "公共任务",
			privateMissions: "私人任务",
			noMissions: "尚未获得私人任务",
			setAside: "留出的板块",
			reserveLeft: "剩余 {{n}} 块",
			hand: "手牌",
			chooseTile: "选择板块 {{n}}",
			tileLabel: "{{kind}}，影响力 {{n}}",
			cell: "位置 {{row}} · {{col}}",
			blocked: "双人局封锁格",
			port: "港口",
			offshore: "离岸农场",
			border: "英格兰边界",
			coastal: "沿海",
			england: "英格兰",
			owned: "{{name}} 的板块",
			controlled: "{{name}} 控制",
			unclaimed: "尚无人控制",
			neighbors: "{{name}}：相邻 {{n}} 格，其中农场 {{farms}} 格",
			settlementStatus: "{{size}} 格聚落 · 已占用 {{n}} 格",
			influence: "{{name}}：影响力 {{n}}",
			visited: "已到访：{{names}}",
			notVisited: "尚无人到访",
			completed: "已完成",
			currentValue: "当前：{{n}}",
			progress: "进度：{{n}} / {{target}}",
			firstLater: "首次 {{high}} 分 · 之后 {{low}} 分",
			points: "{{n}} 分",
			claim: "{{name}}：{{n}} 分",
			doubleMission: "翻倍此任务",
			doubled: "{{name}} 的翻倍任务",
			scoreLine: "{{score}} 分 · 城堡 {{castles}} · 剩余 {{remaining}} 块",
			towerScore3: "首次到访获得 3 分",
			towerSet13: "到访全部 3 座同类圆塔后获得 13 分",
			towerExtra: "首次到访随机放置 1 块留出的板块，每回合限一次",
			towerDraw3: "首次到访后，回合结束时抽取最多 3 块，下回合选 1 块放置",
			towerMission: "首次到访获得 1 张私人任务",
			towerDouble: "到访两座同类圆塔后，选择一张未完成的公共任务进行翻倍",
			towerProgress: "已到访同类圆塔：{{n}} / {{total}}",
			mGlasgow: "占用格拉斯哥教堂旁的格数最多",
			mEdinburghCastle: "占用爱丁堡城堡旁的格数最多",
			mAberdeenCastle: "占用阿伯丁城堡旁的格数最多",
			mPerth: "占用珀斯教堂旁的格数最多",
			mEileanDonan: "占用爱莲朵娜城堡旁的格数最多",
			mEdinburghCathedral: "占用爱丁堡教堂旁的格数最多",
			mPorts: "占用的港口格最多",
			mBorder: "占用英格兰边界格最多",
			mCastles: "控制的城堡最多",
			mBlair: "占用布莱尔城堡旁的格数最多",
			mDumfries: "占用邓弗里斯教堂旁的格数最多",
			mInvergarry: "占用因弗加里城堡旁的格数最多",
			mCoast: "占用最长的连续沿海格",
			mMedium: "至少占用 1 格的中型聚落数量最多",
			mEnergyGroups: "拥有至少 3 块板块的能源农场群最多",
			mInveraray: "占用因弗拉里城堡旁的格数最多",
			mFoodGroups: "拥有至少 3 块板块的粮食农场群最多",
			mInverness: "占用因弗内斯教堂旁的格数最多",
			mSmall: "占用的小型聚落最多",
			mLargestEnergy: "拥有最大的能源农场群",
			mLarge: "至少占用 1 格的大型聚落数量最多",
			mBonus: "教堂奖励：获得 3 分",
			mCathedrals: "到访的教堂最多",
			mOban: "占用奥本教堂旁的格数最多",
			mLargestFood: "拥有最大的粮食农场群",
			mOwnMedium: "完全占有的中型聚落最多",
			iEnergy: "拥有 2 个各含至少 3 块板块的能源农场群",
			iFood: "拥有 2 个各含至少 3 块板块的粮食农场群",
			iSmall: "占用 3 个小型聚落",
			iOwnMedium: "完全占有 2 个中型聚落",
			iCoast: "占用 4 个连续沿海格",
			iCastle: "占用同一城堡旁的 4 格",
			iLarge: "在 3 个大型聚落中各占用至少 1 格",
			iOffshore: "占用 3 个离岸农场格",
			iTower: "占用同一圆塔旁的 4 格",
			iLinkTowers: "以自己的连续板块连接 4 座圆塔",
			iLinkCastles: "以自己的连续板块连接 4 座城堡",
			iMedium: "在 4 个中型聚落中各占用至少 1 格",
			thurso: "瑟索",
			stornoway: "斯托诺韦",
			ardvreck: "阿德弗雷克",
			dornoch: "多诺赫",
			eileanDonan: "爱莲朵娜",
			invernessCastle: "因弗内斯城堡",
			armadale: "阿马代尔",
			aberdeenCastle: "阿伯丁城堡",
			invergarry: "因弗加里",
			blair: "布莱尔",
			duart: "杜阿尔特",
			glamis: "格拉姆斯",
			inveraray: "因弗拉里",
			stirling: "斯特灵",
			kilberry: "基尔伯里",
			edinburghCastle: "爱丁堡城堡",
			neidpath: "奈德帕斯",
			culzean: "卡尔津",
			hermitage: "赫米蒂奇",
			caerlaverock: "卡尔拉弗罗克",
			kirkcudbright: "柯库布里",
			elgin: "埃尔金",
			invernessCathedral: "因弗内斯教堂",
			aberdeenCathedral: "阿伯丁教堂",
			oban: "奥本",
			perth: "珀斯",
			glasgow: "格拉斯哥",
			edinburghCathedral: "爱丁堡教堂",
			dumfries: "邓弗里斯",
			doe: "多伊",
			dunluce: "邓卢斯",
			donegal: "多尼戈尔",
			belfast: "贝尔法斯特",
			dunguaire: "邓古莱",
			dublin: "都柏林",
			birr: "比尔",
			kilkenny: "基尔肯尼",
			bunratty: "本拉蒂",
			cahir: "凯尔",
			ross: "罗斯",
			blarney: "布拉尼",
			tara: "塔拉山",
			overLine: "农场 {{farms}} · 聚落 {{settlements}} · 特殊奖励 {{bonuses}} · 城堡 {{castles}} · 任务 {{missions}}",
			tieEdinburgh: "依爱丁堡城堡规则决胜",
			tieStirling: "依斯特灵城堡规则决胜",
			tieBlarney: "依布拉尼城堡规则决胜",
			tieTara: "依塔拉山规则决胜",
			hintPlace: "将{{tile}}放在第 {{row}} 行、第 {{col}} 列",
			hintDouble: "将任务“{{mission}}”设为翻倍任务",
			errTurn: "现在轮不到你行动",
			errPlace: "这块板块不能放在这里",
			errMission: "请选择一张自己尚未完成的公共任务"
		},
		en: {
			reviewFarms: "Farms",
			reviewSettlements: "Settlements",
			reviewBonuses: "Bonuses",
			reviewCastles: "Castles",
			reviewMissions: "Missions",
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Rebirth",
			desc: "Restore Scotland and Ireland with farms, castles and missions",
			rules: "Goal: rebuild the land and earn the most points.\nSetup:\n· Choose Scotland or Ireland. Both maps follow official rulebook 1.2b.\n· Each player has 12 Energy Farms, 12 Food Farms and 3 Settlement Tiles of each Influence value from 1 to 4.\n· With 4 players, each player removes 3 of each farm type.\n· With 4 players, each player also removes 1 Settlement Tile of each value 2, 3 and 4.\n· Shuffle your tiles. In Scotland, set aside 2 at random; these are not used.\n· In Ireland, set aside 4 at random for tower bonuses. You may inspect the types of your set-aside tiles at any time.\n· Each player draws 1 tile into their hand. The first seat starts; play proceeds clockwise.\n· With 2 players, the marked spaces are blocked: 32 in Scotland, 24 in Ireland. Blocked spaces do not take part.\nPlacement:\n· Place your hand tile on an unoccupied legal space, score it, then draw 1 tile for your next turn.\n· Energy Farms go on Energy or blank farm spaces; Food Farms go on Food or blank farm spaces.\n· Settlements go only on Settlement spaces. Castles, Cathedrals and Towers cannot be occupied.\n· Only when all matching farm spaces and blank farm spaces are occupied may you use a space of the other farm type.\nScoring:\n· Connected farms of the same type and player form a cluster. Different types or players never share a cluster.\n· Each farm placement scores the size of its resulting cluster.\n· A Small Settlement scores its tile’s Influence immediately.\n· A larger Settlement scores once full, ranking players by total Influence within it.\n· Medium Settlements award 5 and 3 points; Large Settlements award 8 and 5. Other players score nothing.\n· Ireland’s four-space Sprawling Settlements award 12, 8 and 5 points. Other players score nothing.\n· Influence ties put the player completing the Settlement last among tied players.\n· Other ties favor clockwise order starting after the completing player. Any unassigned prizes go to first place.\n· Placing on a Scottish Port or Irish Offshore Farm scores 1 extra point.\n· A Castle is controlled by the player with the most adjacent occupied spaces. Ties favor more adjacent farm tiles.\n· If both counts remain equal, the active player cannot take control.\nScotland:\n· Your first placement beside each Cathedral earns a Private Mission, once per player per Cathedral.\n· Private Missions score 5 points at game end if fulfilled; ties for most also qualify.\n· Cathedral Bonus cards award 3 points unconditionally.\nIreland:\n· Reveal 8 Public Missions, leaving 4 in the deck. Each player can complete each Public Mission once.\n· The first player earns the higher score; later players earn the lower score. One placement may complete several missions.\n· Linking missions require your connected tiles to touch the required number of Castles or Towers. Buildings cannot be part of the path.\n· Coastal missions require consecutive coastal spaces.\n· Your first placement beside each Tower activates its bonus, once per player per tower.\n· Two towers award 3 points each; visiting all three matching towers awards 13 points.\n· Extra placement: randomly draw one set-aside tile and place it immediately, scoring normally.\n· Extra placement can activate only once per turn. An extra tile touching another such tower ignores that bonus.\n· Draw three: draw up to 3 supply tiles at turn end.\n· On your next turn, place one, then shuffle the rest back into your supply.\n· Private Mission: draw one remaining mission card privately.\n· It scores its higher value at game end if fulfilled, including a condition met before drawing it.\n· Doubling: after visiting both matching towers, mark one Public Mission you have not completed.\n· When you later complete it, double the actual higher or lower award.\nEnd:\n· End when all hands and supplies are exhausted. Tiles in incomplete Settlements score their Influence.\n· Each controlled Castle scores 5 points. Reveal and score Private Missions.\n· In a Scottish top-score tie, a tied player controlling Edinburgh Castle wins.\n· Otherwise, Stirling Castle’s controller wins even if outside the top-score tie.\n· If Stirling is uncontrolled too, the top scorers share victory.\n· In an Irish top-score tie, a tied player controlling Blarney Castle wins.\n· Otherwise, whoever occupies the most spaces beside the Hill of Tara wins, even if outside the top-score tie.\n· Further ties at Tara share victory.",
			map: "Map",
			scotland: "Scotland",
			ireland: "Ireland",
			scotlandHint: "Private Missions and Cathedrals",
			irelandHint: "Public Missions and Towers",
			energy: "Energy Farm",
			food: "Food Farm",
			settlement: "Settlement",
			flexible: "Blank Farm Space",
			castle: "Castle",
			cathedral: "Cathedral",
			tower: "Round Tower",
			turn: "Turn {{n}}",
			placePrompt: "Choose a space for your tile",
			extraPrompt: "Place your extra tile",
			doublePrompt: "Choose a Public Mission to double",
			placeTile: "Place {{tile}}",
			scoreUnit: "pts",
			castleCount: "{{n}} castles",
			chooseMission: "Choose a mission",
			waiting: "Waiting for turn",
			wait: "Waiting for {{name}}",
			confirm: "Confirm placement",
			chooseCell: "Choose a legal space",
			tasks: "Missions",
			close: "Close",
			overview: "Overview",
			previous: "Previous legal space",
			next: "Next legal space",
			publicMissions: "Public Missions",
			privateMissions: "Private Missions",
			noMissions: "No Private Missions yet",
			setAside: "Set-aside Tiles",
			reserveLeft: "{{n}} remaining",
			hand: "Hand",
			chooseTile: "Choose tile {{n}}",
			tileLabel: "{{kind}}, Influence {{n}}",
			cell: "Space {{row}} · {{col}}",
			blocked: "Blocked with 2 players",
			port: "Port",
			offshore: "Offshore Farm",
			border: "English Border",
			coastal: "Coastal",
			england: "England",
			owned: "{{name}}’s tile",
			controlled: "Controlled by {{name}}",
			unclaimed: "Uncontrolled",
			neighbors: "{{name}}: {{n}} adjacent, {{farms}} farms",
			settlementStatus: "{{size}}-space Settlement · {{n}} occupied",
			influence: "{{name}}: {{n}} Influence",
			visited: "Visited: {{names}}",
			notVisited: "Not visited yet",
			completed: "Completed",
			currentValue: "Current: {{n}}",
			progress: "Progress: {{n}} / {{target}}",
			firstLater: "{{high}} first · {{low}} later",
			points: "{{n}} pts",
			claim: "{{name}}: {{n}} pts",
			doubleMission: "Double this mission",
			doubled: "{{name}}’s doubled mission",
			scoreLine: "{{score}} pts · {{castles}} castles · {{remaining}} tiles left",
			towerScore3: "First visit: score 3 points",
			towerSet13: "Visit all 3 matching towers to score 13 points",
			towerExtra: "First visit: randomly place 1 set-aside tile, once per turn",
			towerDraw3: "First visit: draw up to 3 at turn end; place 1 next turn",
			towerMission: "First visit: gain 1 Private Mission",
			towerDouble: "Visit both matching towers, then double an uncompleted Public Mission",
			towerProgress: "Matching towers visited: {{n}} / {{total}}",
			mGlasgow: "Occupy the most spaces beside Glasgow Cathedral",
			mEdinburghCastle: "Occupy the most spaces beside Edinburgh Castle",
			mAberdeenCastle: "Occupy the most spaces beside Aberdeen Castle",
			mPerth: "Occupy the most spaces beside Perth Cathedral",
			mEileanDonan: "Occupy the most spaces beside Eilean Donan Castle",
			mEdinburghCathedral: "Occupy the most spaces beside Edinburgh Cathedral",
			mPorts: "Occupy the most Port spaces",
			mBorder: "Occupy the most English Border spaces",
			mCastles: "Control the most Castles",
			mBlair: "Occupy the most spaces beside Blair Castle",
			mDumfries: "Occupy the most spaces beside Dumfries Cathedral",
			mInvergarry: "Occupy the most spaces beside Invergarry Castle",
			mCoast: "Occupy the longest sequence of coastal spaces",
			mMedium: "Occupy at least 1 space in the most Medium Settlements",
			mEnergyGroups: "Have the most Energy clusters of at least 3 tiles",
			mInveraray: "Occupy the most spaces beside Inveraray Castle",
			mFoodGroups: "Have the most Food clusters of at least 3 tiles",
			mInverness: "Occupy the most spaces beside Inverness Cathedral",
			mSmall: "Occupy the most Small Settlements",
			mLargestEnergy: "Have the largest Energy Farm cluster",
			mLarge: "Occupy at least 1 space in the most Large Settlements",
			mBonus: "Cathedral Bonus: score 3 points",
			mCathedrals: "Visit the most Cathedrals",
			mOban: "Occupy the most spaces beside Oban Cathedral",
			mLargestFood: "Have the largest Food Farm cluster",
			mOwnMedium: "Fully own the most Medium Settlements",
			iEnergy: "Have 2 Energy Farm clusters of at least 3 tiles each",
			iFood: "Have 2 Food Farm clusters of at least 3 tiles each",
			iSmall: "Occupy 3 Small Settlements",
			iOwnMedium: "Fully own 2 Medium Settlements",
			iCoast: "Occupy 4 consecutive coastal spaces",
			iCastle: "Occupy 4 spaces beside one Castle",
			iLarge: "Occupy at least 1 space in each of 3 Large Settlements",
			iOffshore: "Occupy 3 Offshore Farms",
			iTower: "Occupy 4 spaces beside one Tower",
			iLinkTowers: "Link 4 Towers with your connected tiles",
			iLinkCastles: "Link 4 Castles with your connected tiles",
			iMedium: "Occupy at least 1 space in each of 4 Medium Settlements",
			thurso: "Thurso",
			stornoway: "Stornoway",
			ardvreck: "Ardvreck",
			dornoch: "Dornoch",
			eileanDonan: "Eilean Donan",
			invernessCastle: "Inverness Castle",
			armadale: "Armadale",
			aberdeenCastle: "Aberdeen Castle",
			invergarry: "Invergarry",
			blair: "Blair",
			duart: "Duart",
			glamis: "Glamis",
			inveraray: "Inveraray",
			stirling: "Stirling",
			kilberry: "Kilberry",
			edinburghCastle: "Edinburgh Castle",
			neidpath: "Neidpath",
			culzean: "Culzean",
			hermitage: "Hermitage",
			caerlaverock: "Caerlaverock",
			kirkcudbright: "Kirkcudbright",
			elgin: "Elgin",
			invernessCathedral: "Inverness Cathedral",
			aberdeenCathedral: "Aberdeen Cathedral",
			oban: "Oban",
			perth: "Perth",
			glasgow: "Glasgow",
			edinburghCathedral: "Edinburgh Cathedral",
			dumfries: "Dumfries",
			doe: "Doe",
			dunluce: "Dunluce",
			donegal: "Donegal",
			belfast: "Belfast",
			dunguaire: "Dunguaire",
			dublin: "Dublin",
			birr: "Birr",
			kilkenny: "Kilkenny",
			bunratty: "Bunratty",
			cahir: "Cahir",
			ross: "Ross",
			blarney: "Blarney",
			tara: "Hill of Tara",
			overLine: "Farms {{farms}} · Settlements {{settlements}} · Bonuses {{bonuses}} · Castles {{castles}} · Missions {{missions}}",
			tieEdinburgh: "Decided by Edinburgh Castle",
			tieStirling: "Decided by Stirling Castle",
			tieBlarney: "Decided by Blarney Castle",
			tieTara: "Decided by the Hill of Tara",
			hintPlace: "Place {{tile}} at row {{row}}, column {{col}}",
			hintDouble: "Double the mission “{{mission}}”",
			errTurn: "It is not your turn",
			errPlace: "This tile cannot be placed here",
			errMission: "Choose a Public Mission you have not completed"
		}
	}
};
//#endregion
export { ct as default };
