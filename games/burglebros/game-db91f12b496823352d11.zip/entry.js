import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { AVATARS as s } from "@bgparty/sdk/avatars";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { IconBack as d, IconBot as f, IconClose as p, IconExpand as m, IconLog as h } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as g } from "@bgparty/sdk/player-colors";
import { Texture as ee } from "@bgparty/sdk/texture";
import { GameScreen as _ } from "@bgparty/sdk/ui/game-screen";
import { HintRing as v } from "@bgparty/sdk/ui/hint-ring";
import { PhaseBanner as y } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as te, seatName as b } from "@bgparty/sdk/ui/player-strip";
import { Fragment as x, jsx as S, jsxs as C } from "react/jsx-runtime";
import { Flash as w, Floater as T, PulseBox as E } from "@bgparty/sdk/fx/primitives";
import { Confetti as ne } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as re, OptionSection as D } from "@bgparty/sdk/ui/game-options";
//#region src/games/burglebros/data.ts
var O = (e, t, n, r) => ({
	id: e,
	kind: t,
	num: n,
	white: r
}), k = [
	O(300, "safe", 0, !0),
	O(301, "safe", 0, !0),
	O(302, "safe", 0, !0),
	O(303, "stairs", 4, !0),
	O(304, "stairs", 5, !0),
	O(305, "stairs", 6, !1),
	O(306, "walkway", 1, !0),
	O(307, "walkway", 2, !1),
	O(308, "walkway", 3, !0),
	O(309, "laboratory", 3, !0),
	O(310, "laboratory", 4, !0),
	O(311, "lavatory", 5, !0),
	O(312, "serviceDuct", 5, !0),
	O(313, "serviceDuct", 6, !0),
	O(314, "secretDoor", 1, !0),
	O(315, "secretDoor", 2, !0),
	O(316, "computerFp", 4, !0),
	O(317, "computerLaser", 5, !0),
	O(318, "computerMotion", 6, !0),
	O(319, "camera", 1, !1),
	O(320, "camera", 2, !0),
	O(321, "camera", 3, !0),
	O(322, "camera", 6, !0),
	O(323, "laser", 1, !0),
	O(324, "laser", 2, !0),
	O(325, "laser", 3, !1),
	O(326, "motion", 1, !0),
	O(327, "motion", 2, !1),
	O(328, "motion", 3, !0),
	O(329, "detector", 4, !1),
	O(330, "detector", 5, !1),
	O(331, "detector", 6, !1),
	O(332, "fingerprint", 4, !0),
	O(333, "fingerprint", 5, !0),
	O(334, "fingerprint", 6, !1),
	O(335, "thermo", 1, !0),
	O(336, "thermo", 2, !0),
	O(337, "thermo", 3, !1),
	O(338, "keypad", 4, !0),
	O(339, "keypad", 5, !1),
	O(340, "keypad", 6, !0),
	O(341, "deadbolt", 1, !1),
	O(342, "deadbolt", 2, !0),
	O(343, "deadbolt", 3, !0),
	O(344, "foyer", 1, !0),
	O(345, "foyer", 2, !0),
	O(346, "atrium", 3, !1),
	O(347, "atrium", 4, !1)
], ie = /* @__PURE__ */ "peekhole.deadDrop.lampshade.switchSigns.headsUp.gymnastics.changeOfPlans.goWithGut.brownOut.crash.espresso.reboot.squeak.shiftChange.buddySystem.freightElevator.keycodeChange.jumpTheGun.daydreaming.juryRig.timeLock.lostGrip.whereIsHe.shoplifting.throwVoice.videoLoop".split("."), ae = [
	"blueprints",
	"crowbar",
	"crystalBall",
	"donuts",
	"dynamite",
	"emp",
	"invisibleSuit",
	"makeupKit",
	"rollerskates",
	"smokeBomb",
	"stethoscope",
	"thermalBomb",
	"virus"
], oe = [
	"stamp",
	"chihuahua",
	"tiara",
	"persianKitty",
	"keycard",
	"mirror",
	"gemstone",
	"goldBar",
	"cursedGoblet",
	"bust",
	"isotope",
	"painting"
], A = [
	"stamp",
	"chihuahua",
	"tiara",
	"persianKitty",
	"keycard",
	"mirror",
	"gemstone",
	"goldBar",
	"goldBar",
	"cursedGoblet",
	"bust",
	"isotope",
	"painting"
], se = [
	"rook",
	"spotter",
	"hawk",
	"acrobat",
	"juicer",
	"rigger",
	"peterman",
	"hacker",
	"raven"
], j = {
	office: {
		floors: 2,
		size: 4,
		guardDice: [2, 3],
		blanks: [],
		safes: 2,
		patrolPerFloor: 16,
		walls: [[
			[0, 1],
			[1, 2],
			[4, 5],
			[6, 7],
			[9, 10],
			[3, 7],
			[9, 13],
			[11, 15]
		], [
			[4, 5],
			[5, 6],
			[6, 7],
			[8, 9],
			[9, 10],
			[3, 7],
			[4, 8],
			[11, 15]
		]]
	},
	bank: {
		floors: 3,
		size: 4,
		guardDice: [
			2,
			3,
			4
		],
		blanks: [],
		safes: 3,
		patrolPerFloor: 16,
		walls: [
			[
				[0, 1],
				[6, 7],
				[12, 13],
				[13, 14],
				[2, 6],
				[4, 8],
				[5, 9],
				[11, 15]
			],
			[
				[0, 1],
				[1, 2],
				[2, 3],
				[12, 13],
				[13, 14],
				[14, 15],
				[5, 9],
				[6, 10]
			],
			[
				[4, 5],
				[6, 7],
				[8, 9],
				[9, 10],
				[14, 15],
				[2, 6],
				[4, 8],
				[6, 10]
			]
		]
	},
	fortknox: {
		floors: 2,
		size: 5,
		guardDice: [3, 4],
		blanks: [17],
		safes: 3,
		patrolPerFloor: 25,
		walls: [[
			[5, 6],
			[15, 16],
			[20, 21],
			[7, 8],
			[12, 13],
			[0, 5],
			[3, 8],
			[6, 11],
			[7, 12],
			[8, 13],
			[13, 18],
			[19, 24]
		], [
			[0, 1],
			[3, 4],
			[6, 7],
			[10, 11],
			[11, 12],
			[13, 14],
			[23, 24],
			[2, 7],
			[7, 12],
			[8, 13],
			[16, 21],
			[18, 23]
		]]
	}
}, ce = {
	1: 9,
	2: 6,
	3: 3,
	4: 0
}, le = [
	{
		dc: 0,
		dr: -1
	},
	{
		dc: 1,
		dr: 0
	},
	{
		dc: 0,
		dr: 1
	},
	{
		dc: -1,
		dr: 0
	}
], ue = (e, t) => [e % t, Math.floor(e / t)], M = (e, t, n) => t * n + e;
function N(e, t, n) {
	for (let [r, i] of e) if (r === t && i === n || r === n && i === t) return !0;
	return !1;
}
function P(e, t, n, r) {
	let [i, a] = ue(r, e), o = [];
	for (let { dc: s, dr: c } of le) {
		let l = i + s, u = a + c;
		if (l < 0 || l >= e || u < 0 || u >= e) continue;
		let d = M(l, u, e);
		n.includes(d) || N(t, r, d) || o.push(d);
	}
	return o;
}
function de(e, t, n, r) {
	let i = Array(e * e).fill(-1);
	i[r] = 0;
	let a = [r];
	for (; a.length;) {
		let r = [];
		for (let o of a) for (let a of P(e, t, n, o)) i[a] === -1 && (i[a] = i[o] + 1, r.push(a));
		a = r;
	}
	return i;
}
function F(e, t, n, r, i) {
	if (r === i) return null;
	let a = de(e, t, n, i), o = a[r];
	if (o <= 0) return null;
	for (let i of P(e, t, n, r)) if (a[i] === o - 1) return i;
	return null;
}
//#endregion
//#region src/games/burglebros/meta.ts
var I = {
	id: "burglebros",
	tier: "alpha",
	mechanics: [
		"dice-rolling",
		"grid-movement",
		"action-points"
	],
	interactionTags: ["cooperative"],
	nameKey: "games.burglebros.name",
	descKey: "games.burglebros.desc",
	rulesKey: "games.burglebros.rules",
	icon: "🥷",
	iconImg: "games/burglebros.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/burglebros/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [3],
	accent: "#0ea5e9",
	releasedAt: "2026-09-28",
	search: {
		py: "shen tou pai dang",
		init: "stpd"
	},
	hotseat: "cover"
}, L = t.int().min(0).max(24), R = t.int().min(0).max(2), fe = t.enum(ae), z = t.enum(oe), pe = t.string(), B = t.object({
	scenario: t.enum([
		"office",
		"bank",
		"fortknox"
	]),
	chars: t.enum([
		"basic",
		"advanced",
		"mixed"
	])
}).prefault({
	scenario: "bank",
	chars: "basic"
}), me = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("peek"),
		floor: R.optional(),
		tile: L
	}),
	t.object({
		type: t.literal("move"),
		floor: R,
		tile: L,
		unsafe: t.boolean().optional()
	}),
	t.object({ type: t.literal("escape") }),
	t.object({ type: t.literal("hack") }),
	t.object({
		type: t.literal("addDie"),
		floor: R.optional()
	}),
	t.object({
		type: t.literal("crack"),
		floor: R.optional()
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("useTool"),
		tool: fe,
		floor: R.optional(),
		tile: L.optional(),
		target: pe.optional(),
		wall: t.tuple([L, L]).optional()
	}),
	t.object({
		type: t.literal("ability"),
		ability: t.enum([
			"orders",
			"disguise",
			"clairvoyance",
			"precognition",
			"xray",
			"crybaby",
			"reroutePickup",
			"rerouteDrop",
			"crow",
			"tinker",
			"climbWindow"
		]),
		floor: R.optional(),
		tile: L.optional(),
		target: pe.optional()
	}),
	t.object({
		type: t.literal("give"),
		kind: t.enum(["tool", "loot"]),
		card: t.string(),
		to: pe
	}),
	t.object({
		type: t.literal("resolve"),
		order: t.array(t.enum(ie)).optional(),
		bottom: t.boolean().optional(),
		keep: fe.optional(),
		die: t.int().min(0).max(5).optional(),
		face: t.int().min(1).max(6).optional(),
		tile: L.optional(),
		floor: R.optional(),
		target: pe.optional()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), he = t.object({
	def: t.int().nullable(),
	revealed: t.boolean(),
	alarm: t.boolean(),
	hacks: t.int().min(0),
	stealthPool: t.int().min(0),
	open: t.boolean(),
	dice: t.int().min(0),
	cracked: t.boolean(),
	crackedNums: t.array(t.int()),
	crow: t.boolean(),
	stairsDown: t.boolean(),
	thermal: t.boolean(),
	crowbar: t.boolean(),
	labTaken: t.boolean()
}), ge = t.object({
	active: t.boolean(),
	pos: t.int(),
	dest: t.int(),
	dice: t.int(),
	bonus: t.int(),
	donuts: t.boolean()
}), _e = t.object({
	rid: t.string(),
	char: t.enum(se),
	side: t.enum(["basic", "advanced"]),
	floor: t.int(),
	pos: t.int(),
	stealth: t.int().min(0),
	tools: t.array(fe),
	loot: t.array(z),
	escaped: t.boolean(),
	laptopHack: t.boolean(),
	rerouteAlarm: t.boolean()
}), ve = t.object({
	k: t.enum([
		"entrance",
		"peekhole",
		"goWithGut",
		"throwVoice",
		"buddySystem",
		"crystalBall",
		"toolDraw",
		"clairvoyance",
		"precognition",
		"crackReroll"
	]),
	by: t.string(),
	dice: t.array(t.int()).optional(),
	floor: t.int().optional()
}), ye = t.object({
	scenario: t.enum([
		"office",
		"bank",
		"fortknox"
	]),
	size: t.union([t.literal(4), t.literal(5)]),
	floors: t.array(t.object({
		tiles: t.array(he),
		walls: t.array(t.tuple([t.int(), t.int()])),
		blanks: t.array(t.int())
	})),
	guards: t.array(ge),
	players: t.array(_e),
	turn: t.object({
		seat: t.int(),
		actionsLeft: t.int()
	}),
	phase: t.enum([
		"play",
		"pending",
		"guard",
		"won",
		"lost"
	]),
	pending: ve.nullable(),
	decks: t.object({
		events: t.int(),
		tools: t.int(),
		loot: t.int()
	}),
	patrolLeft: t.array(t.int()),
	patrolDiscard: t.array(t.array(t.int())),
	effects: t.object({
		timeLock: t.boolean(),
		emp: t.boolean(),
		videoLoop: t.boolean(),
		gymnastics: t.boolean()
	}),
	kitty: t.object({
		floor: t.int(),
		pos: t.int()
	}).nullable(),
	lootOnTile: t.object({
		floor: t.int(),
		pos: t.int(),
		loot: z
	}).nullable(),
	lootFound: t.array(z),
	lostReason: t.string().nullable()
}), be = t.object({
	crystalCards: t.array(t.enum(ie)).nullable(),
	clairvoyanceCard: t.int().nullable(),
	precognitionCard: t.enum(ie).nullable(),
	toolDrawCards: t.array(fe).nullable()
}), xe = (e, t, n) => {
	let r = e.floors[t].tiles[n];
	return r.revealed && r.def !== null ? k[r.def - 300] : null;
};
function Se(e, t, n) {
	let r = n % e, i = Math.floor(n / e), a = [];
	for (let [n, o] of [
		[0, -1],
		[1, 0],
		[0, 1],
		[-1, 0]
	]) {
		let s = r + n, c = i + o;
		if (s < 0 || s >= e || c < 0 || c >= e) continue;
		let l = c * e + s;
		t.includes(l) || a.push(l);
	}
	return a;
}
function Ce(e, t, n) {
	let { size: r } = e, i = e.floors[t].blanks;
	return Se(r, i, n).filter((r) => !e.floors[t].walls.some(([e, t]) => e === n && t === r || e === r && t === n));
}
function we(e, t, n) {
	return Ce(e, t, n);
}
function Te(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n || n.escaped || e.phase !== "play" || e.pending) return [];
	let r = n.floor, i = e.floors[r], a = i.blanks, o = [], s = n.loot.includes("painting"), c = e.effects.timeLock, l = (n, r) => e.players.some((e) => e.rid !== t && !e.escaped && e.floor === n && e.pos === r) || e.guards[n].active && e.guards[n].pos === r, u = (e) => {
		o.some((t) => t.floor === e.floor && t.tile === e.tile && (t.unsafe ?? !1) === (e.unsafe ?? !1)) || o.push(e);
	};
	for (let t of Ce(e, r, n.pos)) {
		let n = xe(e, r, t);
		if (!n) {
			u({
				floor: r,
				tile: t,
				cost: 1,
				entering: !0
			});
			continue;
		}
		if (n.kind === "deadbolt" && !l(r, t) && !i.tiles[t].crowbar) {
			u({
				floor: r,
				tile: t,
				cost: 3,
				entering: !0
			});
			continue;
		}
		if (n.kind === "laser" && !i.tiles[t].crowbar) {
			u({
				floor: r,
				tile: t,
				cost: 2,
				entering: !0
			}), u({
				floor: r,
				tile: t,
				cost: 1,
				unsafe: !0,
				entering: !0
			});
			continue;
		}
		u({
			floor: r,
			tile: t,
			cost: 1,
			entering: !0
		});
	}
	if (!s) for (let t of Se(e.size, a, n.pos)) Ce(e, r, n.pos).includes(t) || xe(e, r, t)?.kind === "secretDoor" && !i.tiles[t].crowbar && u({
		floor: r,
		tile: t,
		cost: 1,
		entering: !0
	});
	let d = i.tiles[n.pos], f = xe(e, r, n.pos), p = r + 1 < e.floors.length ? r + 1 : -1, m = r - 1 >= 0 ? r - 1 : -1;
	if (!c && (f?.kind === "stairs" && p >= 0 && !e.floors[p].blanks.includes(n.pos) && u({
		floor: p,
		tile: n.pos,
		cost: 1,
		entering: !0
	}), d.stairsDown && m >= 0 && u({
		floor: m,
		tile: n.pos,
		cost: 1,
		entering: !0
	}), d.thermal)) for (let t of [p, m]) t >= 0 && e.floors[t].tiles[n.pos].thermal && u({
		floor: t,
		tile: n.pos,
		cost: 1,
		entering: !0
	});
	if (f?.kind === "walkway" && m >= 0 && u({
		floor: m,
		tile: n.pos,
		cost: 1,
		entering: !1
	}), e.effects.gymnastics && p >= 0 && xe(e, p, n.pos)?.kind === "walkway" && u({
		floor: p,
		tile: n.pos,
		cost: 1,
		entering: !0
	}), f?.kind === "serviceDuct" && !s) for (let t = 0; t < e.floors.length; t++) e.floors[t].tiles.forEach((i, a) => {
		(t !== r || a !== n.pos) && xe(e, t, a)?.kind === "serviceDuct" && u({
			floor: t,
			tile: a,
			cost: 1,
			entering: !0
		});
	});
	return o;
}
function Ee(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n || n.escaped) return [];
	let r = n.floor, i = e.floors[r].blanks, a = [], o = (t, n) => {
		e.floors[t].tiles[n].revealed || e.floors[t].blanks.includes(n) || a.some((e) => e.floor === t && e.tile === n) || a.push({
			floor: t,
			tile: n
		});
	};
	for (let t of Se(e.size, i, n.pos)) o(r, t);
	if (xe(e, r, n.pos)?.kind === "atrium" && (r + 1 < e.floors.length && o(r + 1, n.pos), r - 1 >= 0 && o(r - 1, n.pos)), n.char === "hawk" && n.side === "advanced") {
		let t = n.pos % e.size, i = Math.floor(n.pos / e.size);
		for (let n = 0; n < e.size * e.size; n++) Math.abs(n % e.size - t) + Math.abs(Math.floor(n / e.size) - i) === 2 && o(r, n);
		r + 1 < e.floors.length && o(r + 1, n.pos), r - 1 >= 0 && o(r - 1, n.pos);
	}
	return a;
}
var V = (e) => ({ code: e }), H = (e) => k[e.def - 300], De = [
	"camera",
	"laser",
	"motion",
	"detector",
	"fingerprint",
	"thermo"
], Oe = {
	fingerprint: "computerFp",
	laser: "computerLaser",
	motion: "computerMotion"
}, ke = (t, n) => e(t.seed, t.cursor++, n), Ae = (e) => ke(e, 6) + 1;
function U(e, t) {
	for (let n = t.length - 1; n > 0; n--) {
		let r = ke(e, n + 1);
		[t[n], t[r]] = [t[r], t[n]];
	}
	return t;
}
var je = (e, t) => e.players.find((e) => e.rid === t), Me = (e, t) => e.players.findIndex((e) => e.rid === t), Ne = (e) => e.players[e.turn.seat], W = (e, t) => e.loot.includes(t), Pe = (e, t) => e.tools.includes(t), Fe = (e, t, n) => e.players.some((e) => e.char === t && (n === void 0 || e.side === n)), Ie = (e, t, n) => e.char === t && e.side === n, G = (e) => j[e.scenario].blanks;
function Le(e, t, n) {
	let r = j[e.scenario], i = {
		scenario: e.scenario,
		size: r.size,
		floors: [],
		guards: [],
		players: [],
		seats: [...t],
		turn: {
			seat: 0,
			actionsLeft: 4,
			keypadTries: 0,
			enteredMotion: [],
			rookUsed: !1,
			hawkUsed: !1,
			juicerUsed: !1,
			firstAction: !0,
			spent: 0,
			invisible: !1
		},
		phase: "pending",
		pending: {
			k: "entrance",
			by: t[0]
		},
		afterPending: "play",
		guardMove: null,
		events: [],
		eventDiscard: [],
		tools: [],
		lootDeck: [],
		patrol: [],
		patrolRemoved: [],
		effects: {
			timeLockBy: null,
			empBy: null,
			videoLoopBy: null,
			gymnasticsBy: null
		},
		skipSeat: null,
		guardDelta: null,
		bonusActions: {},
		kitty: null,
		lootOnTile: null,
		lostReason: null,
		seed: n,
		cursor: 0,
		log: [],
		beatMs: 500
	}, a = k.filter((e) => e.kind !== "safe" && e.kind !== "stairs"), o = k.filter((e) => e.kind === "safe"), s = k.filter((e) => e.kind === "stairs"), c;
	if (e.scenario === "office") {
		let e = U(i, a.filter((e) => e.white)).slice(0, 28);
		c = [U(i, [
			...e.slice(0, 14),
			o[0],
			s[0]
		]), U(i, [
			...e.slice(14),
			o[1],
			s[1]
		])];
	} else if (e.scenario === "bank") {
		let e = U(i, [...a]);
		c = [
			U(i, [
				...e.slice(0, 14),
				o[0],
				s[0]
			]),
			U(i, [
				...e.slice(14, 28),
				o[1],
				s[1]
			]),
			U(i, [
				...e.slice(28),
				o[2],
				s[2]
			])
		];
	} else {
		let e = U(i, [
			...a,
			...o,
			...s
		]);
		c = [e.slice(0, 24), e.slice(24)];
		for (let e = 0; e < 2; e++) if (!c[e].some((e) => e.kind === "safe")) {
			let t = 1 - e, n = c[t].findIndex((e) => e.kind === "safe"), r = c[e].findIndex((e) => e.kind !== "safe" && e.kind !== "stairs");
			[c[e][r], c[t][n]] = [c[t][n], c[e][r]];
		}
	}
	i.floors = c.map((e, t) => {
		let n = [], i = 0;
		for (let t = 0; t < r.size * r.size; t++) {
			let a = r.blanks.includes(t) ? -1 : e[i++].id;
			n.push({
				def: a,
				revealed: !1,
				alarm: !1,
				hacks: 0,
				stealthPool: 0,
				open: !1,
				dice: 0,
				cracked: !1,
				crackedNums: [],
				crow: !1,
				stairsDown: !1,
				thermal: !1,
				crowbar: !1,
				labTaken: !1
			});
		}
		return {
			tiles: n,
			walls: r.walls[t]
		};
	}), i.guards = r.guardDice.map((e) => ({
		active: !1,
		pos: 0,
		dest: 0,
		dice: e,
		bonus: 0,
		donuts: !1
	}));
	let l = ce[t.length] ?? 0;
	for (let e = 0; e < r.floors; e++) {
		let e = U(i, Array.from({ length: r.size * r.size }, (e, t) => t).filter((e) => !r.blanks.includes(e))), t = e.splice(0, l);
		i.patrol.push({
			deck: e,
			discard: []
		}), i.patrolRemoved.push(t);
	}
	i.events = U(i, [...ie]), i.tools = U(i, [...ae]), i.lootDeck = U(i, [...A]);
	let u = U(i, [...se]).slice(0, t.length);
	return i.players = t.map((t, n) => {
		let r = e.chars === "mixed" ? ke(i, 2) === 0 ? "basic" : "advanced" : e.chars, a = {
			rid: t,
			char: u[n],
			side: r,
			floor: 0,
			pos: 0,
			stealth: 3,
			tools: [],
			loot: [],
			escaped: !1,
			laptopHack: !1,
			rerouteAlarm: !1
		};
		return a.char === "rigger" && r === "basic" && (a.tools.push("dynamite"), i.tools.splice(i.tools.indexOf("dynamite"), 1)), a;
	}), { state: i };
}
function K(e, t) {
	let n = e.patrol[t];
	if (n.deck.length === 0) {
		let r = Array.from({ length: e.size * e.size }, (e, t) => t).filter((t) => !G(e).includes(t));
		U(e, r);
		let i = ce[e.players.length] ?? 0;
		e.patrolRemoved[t] = r.splice(0, i), n.deck = r, n.discard = [];
		let a = e.guards[t];
		a.dice + a.bonus < 6 && a.bonus++;
	}
	let r = n.deck.pop();
	return n.discard.push(r), r;
}
function Re(e, t, n) {
	let r = e.guards[t];
	if (!r.active) {
		r.active = !0, r.pos = K(e, t);
		do
			r.dest = K(e, t);
		while (r.dest === r.pos);
		n.push({
			kind: "guardDeploy",
			data: {
				floor: t,
				pos: r.pos,
				dest: r.dest
			}
		});
	}
}
function q(e, t) {
	let n = [];
	return e.floors[t].tiles.forEach((e, t) => {
		e.alarm && n.push(t);
	}), n;
}
function ze(e, t) {
	let n = e.guards[t];
	if (!n.active) return;
	let r = q(e, t);
	r.length && (n.dest = Be(e, t, n.pos, r));
}
function Be(e, t, n, r) {
	let i = gt(e, t, n), a = r[0];
	for (let e of r) i[e] !== -1 && (i[a] === -1 || i[e] < i[a] || i[e] === i[a] && e < a) && (a = e);
	return a;
}
function Ve(e, t, n, r) {
	if (e.phase === "lost" || e.phase === "won") return;
	let i = e.floors[t.floor].tiles[t.pos];
	if (i.stealthPool > 0) i.stealthPool--;
	else if (t.stealth > 0) t.stealth--;
	else {
		e.phase = "lost", e.lostReason = r, e.pending = null, e.guardMove = null, n.push({
			kind: "caught",
			rid: t.rid
		}), e.log.push({
			t: "caught",
			who: t.rid
		});
		return;
	}
	n.push({
		kind: "stealth",
		rid: t.rid
	}), e.log.push({
		t: "stealthLost",
		who: t.rid
	});
}
function J(e, t, n, r) {
	let i = e.floors[t].tiles[n];
	if (i.def < 0 || !i.revealed || i.alarm || e.effects.empBy !== null) return;
	let a = H(i).kind;
	if (a === "camera" && e.effects.videoLoopBy !== null) return;
	let o = Oe[a];
	if (o) {
		let i = !1;
		for (let t of e.floors) {
			for (let e of t.tiles) if (e.def >= 0 && e.revealed && H(e).kind === o && e.hacks > 0) {
				e.hacks--, i = !0;
				break;
			}
			if (i) break;
		}
		if (!i) {
			let t = e.players.find((e) => e.char === "hacker" && e.side === "advanced" && e.laptopHack);
			t && (t.laptopHack = !1, i = !0);
		}
		if (i) {
			e.log.push({
				t: "alarmCancel",
				floor: t
			}), r.push({
				kind: "alarmCancel",
				data: {
					floor: t,
					tile: n
				}
			});
			return;
		}
	}
	i.alarm = !0, e.log.push({
		t: "alarm",
		floor: t,
		kind: a
	}), r.push({
		kind: "alarm",
		data: {
			floor: t,
			tile: n
		}
	}), ze(e, t);
}
function Y(e, t, n, r) {
	let i = e.floors[t].tiles[n];
	i.revealed = !0;
	let a = H(i);
	return a.kind === "stairs" && t + 1 < e.floors.length && (e.floors[t + 1].tiles[n].stairsDown = !0), a.kind === "lavatory" && (i.stealthPool = 3), r.push({
		kind: "reveal",
		data: {
			floor: t,
			tile: n,
			kind: a.kind
		}
	}), a;
}
function He(e, t, n) {
	let r = e.turn.enteredMotion.findIndex(([e, n]) => e === t.floor && n === t.pos);
	r >= 0 && (e.turn.enteredMotion.splice(r, 1), J(e, t.floor, t.pos, n));
}
function Ue(e, t, n, r, i, a) {
	if (!a) return;
	let o = e.floors[n], s = o.tiles[r];
	if (!s.revealed && Y(e, n, r, i).kind === "walkway" && n > 0) {
		t.floor = n - 1, e.log.push({
			t: "fall",
			who: t.rid,
			floor: n - 1
		}), i.push({
			kind: "fall",
			rid: t.rid,
			data: {
				floor: n - 1,
				tile: r
			}
		}), Re(e, n - 1, i);
		return;
	}
	let c = H(s), l = e.guards[n];
	if (l.active && l.pos === r && !e.turn.invisible && !Ie(t, "acrobat", "basic") && Ve(e, t, i, "games.burglebros.lostGuard"), e.phase !== "lost") {
		if (!s.crowbar) {
			let a = e.players.some((e) => e.char === "hacker" && e.side === "basic" && e.floor === n && e.pos === r);
			if (c.kind === "fingerprint" && !a && J(e, n, r, i), c.kind === "motion" && e.turn.enteredMotion.push([n, r]), c.kind === "detector" && (t.tools.length > 0 || t.loot.length > 0) && J(e, n, r, i), c.kind === "camera" && e.effects.videoLoopBy === null && l.active && l.pos !== r && o.tiles[l.pos].revealed && H(o.tiles[l.pos]).kind === "camera" && J(e, n, r, i), c.kind === "atrium") for (let a of [n - 1, n + 1]) a >= 0 && a < e.floors.length && e.guards[a].active && e.guards[a].pos === r && !e.turn.invisible && Ve(e, t, i, "games.burglebros.lostGuard");
			c.kind === "foyer" && l.active && !e.turn.invisible && P(e.size, o.walls, G(e), r).includes(l.pos) && Ve(e, t, i, "games.burglebros.lostGuard");
		}
		c.kind === "laboratory" && !s.labTaken && (s.labTaken = !0, We(e, t, i)), W(t, "tiara") && l.active && P(e.size, o.walls, G(e), r).includes(l.pos) && !e.turn.invisible && Ve(e, t, i, "games.burglebros.lostGuard"), W(t, "gemstone") && e.players.some((e) => e !== t && !e.escaped && e.floor === n && e.pos === r) && e.turn.actionsLeft++, W(t, "isotope") && c.kind === "thermo" && J(e, n, r, i), e.lootOnTile && e.lootOnTile.floor === n && e.lootOnTile.pos === r && (e.lootOnTile.loot !== "goldBar" || !W(t, "goldBar")) && (Ge(e, t, e.lootOnTile.loot, i, n, r), e.lootOnTile = null), e.kitty && e.kitty.floor === n && e.kitty.pos === r && (e.kitty = null);
	}
}
function We(e, t, n) {
	if (e.tools.length === 0) return;
	if (Fe(e, "rigger", "basic") && e.tools.length >= 2) {
		let n = [e.tools.pop(), e.tools.pop()];
		e.pending = {
			k: "toolDraw",
			by: t.rid,
			cards: n
		}, e.phase = "pending";
		return;
	}
	let r = e.tools.pop();
	t.tools.push(r), e.log.push({
		t: "tool",
		who: t.rid,
		tool: r
	}), n.push({
		kind: "tool",
		rid: t.rid,
		data: { tool: r }
	});
}
function Ge(e, t, n, r, i, a) {
	if (t.loot.push(n), e.log.push({
		t: "loot",
		who: t.rid,
		loot: n
	}), r.push({
		kind: "loot",
		rid: t.rid,
		data: { loot: n }
	}), n === "cursedGoblet" && t.stealth > 0 && t.stealth--, n === "goldBar" && i !== void 0) {
		let t = e.lootDeck.indexOf("goldBar");
		t >= 0 && (e.lootDeck.splice(t, 1), e.lootOnTile = {
			floor: i,
			pos: a,
			loot: "goldBar"
		}, U(e, e.lootDeck));
	}
}
function Ke(e, t, n, r, i) {
	e.lootDeck.length !== 0 && Ge(e, t, e.lootDeck.pop(), n, r, i);
}
function qe(e, t, n) {
	let r = e.size, i = n % r, a = Math.floor(n / r), o = /* @__PURE__ */ new Set();
	for (let n = 0; n < r; n++) for (let s of [a * r + n, n * r + i]) {
		let n = e.floors[t].tiles[s];
		if (!(n.def < 0)) {
			if (!n.revealed) return null;
			H(n).num > 0 && o.add(H(n).num);
		}
	}
	return [...o].sort((e, t) => e - t);
}
function Je(e, t) {
	let n = Ne(e), r = W(n, "stamp") ? 3 : 2;
	if (e.turn.spent > r) return;
	if (e.events.length === 0) {
		if (e.eventDiscard.length === 0) return;
		e.events = U(e, e.eventDiscard), e.eventDiscard = [];
	}
	let i = e.events.pop();
	e.eventDiscard.push(i), e.log.push({
		t: "event",
		who: n.rid,
		card: i
	}), t.push({
		kind: "event",
		data: { card: i }
	}), Ye(e, n, i, t);
}
function Ye(e, t, n, r) {
	let i = t.floor, a = e.guards[i], o = e.turn.seat, s = (t) => {
		e.pending = t, e.phase = "pending", e.afterPending = "guard";
	};
	switch (n) {
		case "peekhole":
			s({
				k: "peekhole",
				by: t.rid
			});
			break;
		case "deadDrop": {
			let t = e.players.length, n = e.players.map((e) => ({
				tools: e.tools,
				loot: e.loot
			}));
			e.players.forEach((e, r) => {
				let i = n[(r - 1 + t) % t];
				e.tools = i.tools, e.loot = i.loot;
			});
			break;
		}
		case "lampshade":
			t.stealth++;
			break;
		case "switchSigns":
			if (a.active) {
				let t = q(e, i);
				if (t.length) {
					a.pos = Be(e, i, a.pos, t), e.floors[i].tiles[a.pos].alarm = !1;
					do
						a.dest = K(e, i);
					while (a.dest === a.pos);
				} else [a.pos, a.dest] = [a.dest, a.pos];
				r.push({
					kind: "guardDeploy",
					data: {
						floor: i,
						pos: a.pos,
						dest: a.dest
					}
				});
			}
			break;
		case "headsUp": {
			let t = Xe(e, o);
			e.bonusActions[t] = (e.bonusActions[t] ?? 0) + 1;
			break;
		}
		case "gymnastics":
			e.effects.gymnasticsBy = o;
			break;
		case "changeOfPlans":
			if (a.active && q(e, i).length === 0) do
				a.dest = K(e, i);
			while (a.dest === a.pos);
			break;
		case "goWithGut":
			P(e.size, e.floors[i].walls, G(e), t.pos).filter((t) => !e.floors[i].tiles[t].revealed).length && s({
				k: "goWithGut",
				by: t.rid
			});
			break;
		case "brownOut":
			for (let t = 0; t < e.floors.length; t++) {
				let n = q(e, t);
				if (n.length) {
					for (let r of n) e.floors[t].tiles[r].alarm = !1;
					if (e.guards[t].active) {
						for (let r = 0; r < n.length; r++) e.guards[t].dest = K(e, t);
						e.guards[t].dest === e.guards[t].pos && (e.guards[t].dest = K(e, t));
					}
				}
			}
			break;
		case "crash":
			a.active && q(e, i).length === 0 && (a.pos = t.pos, e.turn.invisible || Ve(e, t, r, "games.burglebros.lostGuard"));
			break;
		case "espresso":
			e.guardDelta = {
				floor: i,
				delta: 1
			};
			break;
		case "reboot":
			for (let t of e.floors) for (let e of t.tiles) e.def >= 0 && e.revealed && H(e).kind.startsWith("computer") && (e.hacks = 1);
			break;
		case "squeak": {
			if (!a.active) break;
			let t = e.players.filter((e) => !e.escaped && e.floor === i).map((e) => e.pos);
			if (!t.length) break;
			let n = Be(e, i, a.pos, t), o = F(e.size, e.floors[i].walls, G(e), a.pos, n);
			o !== null && et(e, i, o, r, 1);
			break;
		}
		case "shiftChange":
			e.guardDelta = {
				floor: i,
				delta: -99
			};
			break;
		case "buddySystem":
			e.players.some((e) => e !== t && !e.escaped) && s({
				k: "buddySystem",
				by: t.rid
			});
			break;
		case "freightElevator":
			i + 1 < e.floors.length ? (t.floor = i + 1, r.push({
				kind: "move",
				rid: t.rid,
				data: {
					floor: t.floor,
					tile: t.pos
				}
			}), Re(e, t.floor, r)) : Ze(e) && Qe(e, t, r);
			break;
		case "keycodeChange":
			for (let t of e.floors) for (let e of t.tiles) e.def >= 0 && H(e).kind === "keypad" && (e.open = !1);
			break;
		case "jumpTheGun":
			e.skipSeat = Xe(e, o);
			break;
		case "daydreaming":
			e.guardDelta = {
				floor: i,
				delta: -1
			};
			break;
		case "juryRig":
			We(e, t, r);
			break;
		case "timeLock":
			e.effects.timeLockBy = o;
			break;
		case "lostGrip":
			i > 0 && (t.floor = i - 1, r.push({
				kind: "fall",
				rid: t.rid,
				data: {
					floor: t.floor,
					tile: t.pos
				}
			}), Re(e, t.floor, r));
			break;
		case "whereIsHe":
			a.active && (a.pos = a.dest, $e(e, i, r), r.push({
				kind: "guardDeploy",
				data: {
					floor: i,
					pos: a.pos,
					dest: a.dest
				}
			}));
			break;
		case "shoplifting":
			e.floors[i].tiles.forEach((t, n) => {
				t.def >= 0 && H(t).kind === "laboratory" && t.labTaken && J(e, i, n, r);
			});
			break;
		case "throwVoice":
			a.active && q(e, i).length === 0 && s({
				k: "throwVoice",
				by: t.rid
			});
			break;
		case "videoLoop": e.effects.videoLoopBy = o;
	}
}
function Xe(e, t) {
	let n = e.players.length, r = t;
	do
		r = (r + 1) % n;
	while (e.players[r].escaped);
	return r;
}
function Ze(e) {
	return e.lootDeck.length === 0 && !e.lootOnTile && !e.kitty;
}
function Qe(e, t, n) {
	t.escaped = !0, e.log.push({
		t: "escape",
		who: t.rid
	}), n.push({
		kind: "escape",
		rid: t.rid
	});
	let r = Me(e, t.rid);
	for (let t of [
		"timeLockBy",
		"empBy",
		"videoLoopBy",
		"gymnasticsBy"
	]) e.effects[t] === r && (e.effects[t] = null);
	e.players.every((e) => e.escaped) && (e.phase = "won", e.guardMove = null, e.pending = null);
}
function $e(e, t, n) {
	let r = e.guards[t], i = e.floors[t].tiles[r.pos];
	i.alarm && (i.alarm = !1, e.log.push({
		t: "alarmCancel",
		floor: t
	}), n.push({
		kind: "alarmOff",
		data: {
			floor: t,
			tile: r.pos
		}
	}));
	let a = q(e, t);
	if (a.length) return r.dest = Be(e, t, r.pos, a), r.dest !== r.pos;
	let o = 0;
	do
		r.dest = K(e, t);
	while (r.dest === r.pos && ++o < 10);
	return r.dest !== r.pos;
}
function et(e, t, n, r, i) {
	let a = e.guards[t];
	a.pos = n, e.guardMove && (e.guardMove.stepsLeft -= i), r.push({
		kind: "guardStep",
		data: {
			floor: t,
			to: n
		}
	}), e.floors[t].tiles[n].crow && e.guardMove && e.guardMove.stepsLeft--;
	let o = e.floors[t];
	for (let i of e.players) if (!i.escaped && (i.floor === t && i.pos === n && !e.turn.invisible && Ve(e, i, r, "games.burglebros.lostGuard"), e.phase === "lost")) return;
	let s = o.tiles[n];
	if (s.revealed && s.def >= 0 && H(s).kind === "camera" && e.effects.videoLoopBy === null) for (let i of e.players) {
		if (i.escaped || i.floor !== t || i.pos === n || e.turn.invisible) continue;
		let a = o.tiles[i.pos];
		a.revealed && a.def >= 0 && H(a).kind === "camera" && J(e, t, i.pos, r);
	}
	for (let i of e.players) {
		if (i.escaped || i.floor !== t || e.turn.invisible) continue;
		let a = o.tiles[i.pos];
		a.revealed && a.def >= 0 && H(a).kind === "foyer" && P(e.size, o.walls, G(e), i.pos).includes(n) && Ve(e, i, r, "games.burglebros.lostGuard");
	}
	for (let i of e.players) {
		if (i.escaped || e.turn.invisible || Math.abs(i.floor - t) !== 1 || i.pos !== n) continue;
		let a = e.floors[i.floor].tiles[i.pos];
		a.revealed && a.def >= 0 && H(a).kind === "atrium" && Ve(e, i, r, "games.burglebros.lostGuard");
	}
}
function tt(e) {
	let t = Ne(e).floor, n = e.guards[t], r = e.guardDelta && e.guardDelta.floor === t ? e.guardDelta.delta : 0;
	e.guardDelta = null;
	let i = Fe(e, "raven", "advanced") && e.floors[t].tiles[n.pos].crow && q(e, t).length === 0;
	if (!n.active || n.donuts || i) {
		n.donuts = !1, it(e);
		return;
	}
	let a = n.dice + n.bonus + q(e, t).length + r;
	if (a <= 0) {
		it(e);
		return;
	}
	e.phase = "guard", e.guardMove = {
		floor: t,
		stepsLeft: a
	}, e.log.push({
		t: "guardMove",
		floor: t
	});
}
function nt(e) {
	return e.phase === "won" || e.phase === "lost";
}
function rt(e) {
	let t = [], n = e.guardMove;
	if (e.phase !== "guard" || !n) return { state: e };
	let r = n.floor, i = e.guards[r], a = 0;
	for (; a++ < 10;) {
		if (nt(e)) return {
			state: e,
			fx: t
		};
		if (i.pos === i.dest) {
			if (!$e(e, r, t) || n.stepsLeft <= 0) break;
			continue;
		}
		let a = F(e.size, e.floors[r].walls, G(e), i.pos, i.dest);
		if (a === null) {
			if (!$e(e, r, t)) break;
			continue;
		}
		et(e, r, a, t, 1);
		break;
	}
	if (nt(e)) return {
		state: e,
		fx: t
	};
	if (n.stepsLeft <= 0 || i.pos === i.dest) {
		if (n.stepsLeft > 0 && i.pos === i.dest && q(e, r).length === 0) return {
			state: e,
			fx: t
		};
		if (n.stepsLeft <= 0) return e.guardMove = null, it(e), {
			state: e,
			fx: t
		};
	}
	return {
		state: e,
		fx: t
	};
}
function it(e) {
	let t = e.players.length, n = e.turn.seat;
	do
		n = (n + 1) % t;
	while (e.players[n].escaped);
	if (e.skipSeat !== null && n === e.skipSeat) {
		e.skipSeat = null;
		do
			n = (n + 1) % t;
		while (e.players[n].escaped);
	}
	e.turn = {
		seat: n,
		actionsLeft: 4 + (e.bonusActions[n] ?? 0) - +!!W(e.players[n], "mirror"),
		keypadTries: 0,
		enteredMotion: [],
		rookUsed: !1,
		hawkUsed: !1,
		juicerUsed: !1,
		firstAction: !0,
		spent: 0,
		invisible: !1
	}, delete e.bonusActions[n], e.afterPending = "play";
	for (let t of [
		"timeLockBy",
		"empBy",
		"videoLoopBy",
		"gymnasticsBy"
	]) e.effects[t] === n && (e.effects[t] = null);
	e.phase = "play";
	let r = e.players[n];
	if (W(r, "chihuahua") && Ae(e) === 6 && J(e, r.floor, r.pos, []), W(r, "persianKitty") && !e.kitty && ke(e, 6) + 1 <= 2) {
		let t = [];
		if (e.floors[r.floor].tiles.forEach((e, n) => {
			e.revealed && e.def >= 0 && De.includes(H(e).kind) && t.push(n);
		}), t.length) {
			let n = Be(e, r.floor, r.pos, t), i = P(e.size, e.floors[r.floor].walls, G(e), n);
			e.kitty = {
				floor: r.floor,
				pos: i[0] ?? n
			};
		}
	}
}
function X(e, t) {
	e.turn.actionsLeft -= t, e.turn.spent += t, e.turn.firstAction = !1;
}
function at(e, t, n) {
	let r = structuredClone(e), i = [];
	if (t.type === "tick") return rt(r);
	if (r.phase === "won" || r.phase === "lost") return V("games.burglebros.errOver");
	if (r.pending) {
		if (t.type !== "resolve") return V("games.burglebros.errPending");
		if (r.pending.by !== n.by) return V("games.burglebros.errNotYours");
		let e = vt(r, r.pending, t, i);
		if (e) return e;
		if (!r.pending) {
			if (nt(r)) return {
				state: r,
				fx: i
			};
			r.afterPending === "guard" ? tt(r) : r.phase = "play";
		}
		return {
			state: r,
			fx: i
		};
	}
	if (r.phase !== "play") return V("games.burglebros.errPhase");
	let a = je(r, n.by);
	if (!a) return V("games.burglebros.errNotYours");
	if (Ne(r).rid !== n.by) return V("games.burglebros.errTurn");
	switch (t.type) {
		case "peek": return ot(r, a, t.tile, !1, i, t.floor);
		case "move": return st(r, a, t.floor, t.tile, t.unsafe ?? !1, i);
		case "escape": return ct(r, a, i);
		case "hack": return lt(r, a, i);
		case "addDie": return dt(r, a, t.floor, i);
		case "crack": return ft(r, a, t.floor, i);
		case "endTurn": {
			let e = r.floors[a.floor].tiles[a.pos];
			return e.revealed && e.def >= 0 && H(e).kind === "thermo" && !e.crowbar && J(r, a.floor, a.pos, i), nt(r) || (r.afterPending = "guard", Je(r, i), nt(r)) || r.pending || tt(r), {
				state: r,
				fx: i
			};
		}
		case "useTool": return mt(r, a, t, i);
		case "ability": return ht(r, a, t, i);
		case "give": return _t(r, a, t, i);
		default: return V("games.burglebros.errPhase");
	}
}
function ot(e, t, n, r, i, a) {
	if (!r && e.turn.actionsLeft < 1) return V("games.burglebros.errActions");
	let o = a ?? t.floor;
	if (!Ee(yt(e), t.rid).some((e) => e.floor === o && e.tile === n)) return V("games.burglebros.errPeek");
	r || X(e, 1);
	let s = Y(e, o, n, i);
	return e.log.push({
		t: "peek",
		who: t.rid,
		floor: o,
		kind: s.kind
	}), {
		state: e,
		fx: i
	};
}
function st(e, t, n, r, i, a) {
	let o = Te(yt(e), t.rid).find((e) => e.floor === n && e.tile === r && (e.unsafe ?? !1) === i);
	if (!o) return V("games.burglebros.errMove");
	if (e.turn.actionsLeft < o.cost) return V("games.burglebros.errActions");
	let s = e.floors[n].tiles[r], c = s.def >= 0 ? H(s) : null;
	if (!s.revealed && c?.kind === "deadbolt" && !(e.players.some((e) => e !== t && !e.escaped && e.floor === n && e.pos === r) || e.guards[n].active && e.guards[n].pos === r)) return X(e, o.cost), Y(e, n, r, a), {
		state: e,
		fx: a
	};
	if (c?.kind === "keypad" && !s.open && !s.crowbar) {
		X(e, o.cost), s.revealed || Y(e, n, r, a), e.turn.keypadTries++;
		let i = e.turn.keypadTries + +!!Ie(t, "peterman", "basic"), c = !1;
		for (let t = 0; t < i; t++) Ae(e) === 6 && (c = !0);
		if (!c) return a.push({
			kind: "keypadFail",
			data: {
				floor: n,
				tile: r
			}
		}), {
			state: e,
			fx: a
		};
		s.open = !0;
	} else X(e, o.cost);
	return He(e, t, a), t.floor = n, t.pos = r, e.log.push({
		t: "move",
		who: t.rid,
		floor: n
	}), a.push({
		kind: "move",
		rid: t.rid,
		data: {
			floor: n,
			tile: r
		}
	}), Re(e, n, a), e.phase === "lost" || !o.entering ? {
		state: e,
		fx: a
	} : (Ue(e, t, n, r, a, !0), s.def >= 0 && H(s).kind === "laser" && !s.crowbar && (i || o.cost === 1) && (e.players.some((e) => e.char === "hacker" && e.side === "basic" && e.floor === n && e.pos === r) || J(e, n, r, a)), {
		state: e,
		fx: a
	});
}
function ct(e, t, n) {
	let r = e.floors.length - 1, i = e.floors[t.floor].tiles[t.pos];
	return t.floor !== r || !i.revealed || i.def < 0 || H(i).kind !== "stairs" ? V("games.burglebros.errEscape") : Ze(e) ? e.turn.actionsLeft < 1 ? V("games.burglebros.errActions") : (X(e, 1), Qe(e, t, n), e.phase === "won" ? {
		state: e,
		fx: n
	} : (e.turn.actionsLeft = 0, e.afterPending = "guard", Je(e, n), !e.pending && e.phase === "play" && tt(e), {
		state: e,
		fx: n
	})) : V("games.burglebros.errLootMissing");
}
function lt(e, t, n) {
	let r = e.floors[t.floor].tiles[t.pos];
	if (!r.revealed || r.def < 0 || !H(r).kind.startsWith("computer")) return V("games.burglebros.errHack");
	if (e.turn.actionsLeft < 1) return V("games.burglebros.errActions");
	let i = Ie(t, "hacker", "advanced") && !t.laptopHack;
	return !i && r.hacks >= 6 ? V("games.burglebros.errHackFull") : (X(e, 1), i ? t.laptopHack = !0 : r.hacks++, e.log.push({
		t: "hack",
		who: t.rid
	}), n.push({
		kind: "hack",
		rid: t.rid,
		data: {
			floor: t.floor,
			tile: t.pos
		}
	}), {
		state: e,
		fx: n
	});
}
function ut(e, t, n) {
	let r = n ?? t.floor;
	if (r < 0 || r >= e.floors.length) return V("games.burglebros.errSafe");
	let i = e.floors[r].tiles[t.pos];
	return !(i.def >= 0 && i.revealed && H(i).kind === "safe") || r !== t.floor && (!Ie(t, "peterman", "advanced") || Math.abs(r - t.floor) !== 1) ? V("games.burglebros.errSafe") : {
		f: r,
		t: i
	};
}
function dt(e, t, n, r) {
	let i = ut(e, t, n);
	return "code" in i ? i : e.turn.actionsLeft < 2 ? V("games.burglebros.errActions") : i.t.dice >= 6 ? V("games.burglebros.errDiceFull") : (X(e, 2), i.t.dice++, e.log.push({
		t: "addDie",
		who: t.rid
	}), r.push({
		kind: "addDie",
		rid: t.rid,
		data: {
			floor: i.f,
			tile: t.pos
		}
	}), {
		state: e,
		fx: r
	});
}
function ft(e, t, n, r) {
	let i = ut(e, t, n);
	if ("code" in i) return i;
	if (e.turn.actionsLeft < 1) return V("games.burglebros.errActions");
	if (i.t.dice < 1) return V("games.burglebros.errNoDice");
	if (i.t.cracked) return V("games.burglebros.errSafe");
	if (!qe(e, i.f, t.pos)) return V("games.burglebros.errCombo");
	let a = e.players.find((e) => W(e, "keycard"));
	if (a && (a.floor !== i.f || a.pos !== t.pos)) return V("games.burglebros.errKeycard");
	X(e, 1);
	let o = i.t.dice + +!!Ie(t, "peterman", "basic"), s = Array.from({ length: o }, () => Ae(e));
	return Pe(t, "stethoscope") ? (e.afterPending = "play", e.pending = {
		k: "crackReroll",
		by: t.rid,
		floor: i.f,
		dice: s
	}, e.phase = "pending", {
		state: e,
		fx: r
	}) : (pt(e, t, i.f, t.pos, s, r), {
		state: e,
		fx: r
	});
}
function pt(e, t, n, r, i, a) {
	let o = e.floors[n].tiles[r], s = qe(e, n, r), c = new Set(o.crackedNums);
	for (let e of i) s.includes(e) && c.add(e);
	if (o.crackedNums = [...c], a.push({
		kind: "crack",
		rid: t.rid,
		data: {
			floor: n,
			tile: r,
			dice: i
		}
	}), s.every((e) => c.has(e))) {
		o.cracked = !0, e.log.push({
			t: "crackOk",
			who: t.rid,
			floor: n
		}), a.push({
			kind: "cracked",
			rid: t.rid,
			data: {
				floor: n,
				tile: r
			}
		});
		for (let t = n; t >= 0; t--) {
			let n = e.guards[t];
			n.dice + n.bonus < 6 && n.bonus++;
		}
		Ke(e, t, a, n, r), We(e, t, a);
	} else e.log.push({
		t: "crackFail",
		who: t.rid,
		floor: n
	});
}
function mt(e, t, n, r) {
	if (!Pe(t, n.tool)) return V("games.burglebros.errTool");
	if (W(t, "bust")) return V("games.burglebros.errBust");
	let i = t.floor, a = e.floors[i], o = () => {
		t.tools.splice(t.tools.indexOf(n.tool), 1);
	};
	switch (n.tool) {
		case "blueprints": {
			if (n.floor === void 0 || n.tile === void 0) return V("games.burglebros.errTile");
			let t = e.floors[n.floor]?.tiles[n.tile];
			if (!t || t.def < 0 || t.revealed) return V("games.burglebros.errTile");
			o(), Y(e, n.floor, n.tile, r);
			break;
		}
		case "crowbar":
			if (n.tile === void 0 || !P(e.size, a.walls, G(e), t.pos).includes(n.tile)) return V("games.burglebros.errTile");
			o(), a.tiles[n.tile].crowbar = !0;
			break;
		case "crystalBall": {
			if (e.events.length === 0) return V("games.burglebros.errTool");
			o();
			let n = e.events.splice(-3).reverse();
			e.afterPending = "play", e.pending = {
				k: "crystalBall",
				by: t.rid,
				cards: n
			}, e.phase = "pending";
			break;
		}
		case "donuts": {
			let t = n.floor ?? i;
			if (!e.guards[t]?.active) return V("games.burglebros.errTool");
			o(), e.guards[t].donuts = !0;
			break;
		}
		case "dynamite": {
			if (!n.wall) return V("games.burglebros.errTile");
			let [s, c] = n.wall;
			if (s !== t.pos && c !== t.pos || !N(a.walls, s, c)) return V("games.burglebros.errTile");
			o(), a.walls = a.walls.filter(([e, t]) => !(e === s && t === c || e === c && t === s)), J(e, i, t.pos, r);
			break;
		}
		case "emp":
			o();
			for (let t of e.floors) for (let e of t.tiles) e.alarm = !1;
			e.effects.empBy = e.turn.seat;
			break;
		case "invisibleSuit":
			o(), e.turn.invisible = !0, e.turn.actionsLeft++;
			break;
		case "makeupKit":
			o();
			for (let n of e.players) !n.escaped && n.floor === i && n.pos === t.pos && n.stealth++;
			break;
		case "rollerskates":
			o(), e.turn.actionsLeft += 2;
			break;
		case "smokeBomb":
			o(), a.tiles[t.pos].stealthPool += 3;
			break;
		case "stethoscope": return V("games.burglebros.errToolPassive");
		case "thermalBomb":
			o();
			for (let n of [
				i - 1,
				i,
				i + 1
			]) n >= 0 && n < e.floors.length && e.floors[n].tiles[t.pos].def >= 0 && (e.floors[n].tiles[t.pos].thermal = !0);
			J(e, i, t.pos, r);
			break;
		case "virus": {
			let t = n.floor ?? i;
			if (n.tile === void 0) return V("games.burglebros.errTile");
			let r = e.floors[t]?.tiles[n.tile];
			if (!r || !r.revealed || r.def < 0 || !H(r).kind.startsWith("computer")) return V("games.burglebros.errTile");
			o(), r.hacks = Math.min(6, r.hacks + 3);
			break;
		}
	}
	return e.log.push({
		t: "tool",
		who: t.rid,
		tool: n.tool
	}), r.push({
		kind: "useTool",
		rid: t.rid,
		data: { tool: n.tool }
	}), {
		state: e,
		fx: r
	};
}
function ht(e, t, n, r) {
	let i = t.floor, a = e.floors[i], o = (e, n) => Ie(t, e, n) ? null : V("games.burglebros.errAbility");
	switch (n.ability) {
		case "orders": {
			{
				let e = o("rook", "basic");
				if (e) return e;
			}
			if (e.turn.rookUsed) return V("games.burglebros.errAbilityUsed");
			if (e.turn.actionsLeft < 1) return V("games.burglebros.errActions");
			let s = e.players.find((e) => e.rid === n.target);
			if (!s || s === t || s.escaped || s.floor !== t.floor) return V("games.burglebros.errTarget");
			if (n.tile === void 0 || !P(e.size, a.walls, G(e), s.pos).includes(n.tile)) return V("games.burglebros.errTile");
			let c = a.tiles[n.tile];
			if (c.revealed && c.def >= 0 && H(c).kind === "keypad" && !c.open && !c.crowbar) {
				if (Ae(e) !== 6) return {
					state: e,
					fx: r
				};
				c.open = !0;
			}
			return e.turn.rookUsed = !0, X(e, 1), s.pos = n.tile, r.push({
				kind: "move",
				rid: s.rid,
				data: {
					floor: i,
					tile: n.tile
				}
			}), Ue(e, s, i, n.tile, r, !0), e.log.push({
				t: "ability",
				who: t.rid,
				ability: "orders"
			}), {
				state: e,
				fx: r
			};
		}
		case "disguise": {
			{
				let e = o("rook", "advanced");
				if (e) return e;
			}
			if (!e.turn.firstAction) return V("games.burglebros.errAbility");
			let i = e.players.find((e) => e.rid === n.target);
			return !i || i === t || i.escaped ? V("games.burglebros.errTarget") : ([t.floor, t.pos, i.floor, i.pos] = [
				i.floor,
				i.pos,
				t.floor,
				t.pos
			], e.turn.firstAction = !1, r.push({
				kind: "move",
				rid: t.rid,
				data: {
					floor: t.floor,
					tile: t.pos
				}
			}), r.push({
				kind: "move",
				rid: i.rid,
				data: {
					floor: i.floor,
					tile: i.pos
				}
			}), e.log.push({
				t: "ability",
				who: t.rid,
				ability: "disguise"
			}), {
				state: e,
				fx: r
			});
		}
		case "clairvoyance":
			{
				let e = o("spotter", "basic");
				if (e) return e;
			}
			return e.turn.actionsLeft < 1 ? V("games.burglebros.errActions") : e.patrol[i].deck.length === 0 ? V("games.burglebros.errAbility") : (X(e, 1), e.afterPending = "play", e.pending = {
				k: "clairvoyance",
				by: t.rid,
				card: e.patrol[i].deck[e.patrol[i].deck.length - 1]
			}, e.phase = "pending", e.log.push({
				t: "ability",
				who: t.rid,
				ability: "clairvoyance"
			}), {
				state: e,
				fx: r
			});
		case "precognition":
			{
				let e = o("spotter", "advanced");
				if (e) return e;
			}
			return e.turn.actionsLeft < 1 ? V("games.burglebros.errActions") : e.events.length === 0 ? V("games.burglebros.errAbility") : (X(e, 1), e.afterPending = "play", e.pending = {
				k: "precognition",
				by: t.rid,
				card: e.events[e.events.length - 1]
			}, e.phase = "pending", e.log.push({
				t: "ability",
				who: t.rid,
				ability: "precognition"
			}), {
				state: e,
				fx: r
			});
		case "xray":
			{
				let e = o("hawk", "basic");
				if (e) return e;
			}
			return e.turn.hawkUsed ? V("games.burglebros.errAbilityUsed") : n.tile === void 0 ? V("games.burglebros.errTile") : (e.turn.hawkUsed = !0, ot(e, t, n.tile, !0, r));
		case "crybaby": {
			{
				let e = o("juicer", "basic");
				if (e) return e;
			}
			if (n.tile === void 0 || !P(e.size, a.walls, G(e), t.pos).includes(n.tile)) return V("games.burglebros.errTile");
			let s = a.tiles[n.tile], c = e.guards[i];
			return !s.revealed || s.def < 0 || s.alarm || c.active && c.pos === n.tile ? V("games.burglebros.errTile") : (J(e, i, n.tile, r), e.log.push({
				t: "ability",
				who: t.rid,
				ability: "crybaby"
			}), {
				state: e,
				fx: r
			});
		}
		case "reroutePickup": {
			{
				let e = o("juicer", "advanced");
				if (e) return e;
			}
			if (e.turn.juicerUsed || t.rerouteAlarm) return V("games.burglebros.errAbilityUsed");
			let n = a.tiles[t.pos];
			if (!n.alarm) return V("games.burglebros.errAbility");
			e.turn.juicerUsed = !0, n.alarm = !1, t.rerouteAlarm = !0;
			let s = e.guards[i];
			if (s.active) {
				let t = q(e, i);
				s.dest = t.length ? Be(e, i, s.pos, t) : K(e, i);
			}
			return e.log.push({
				t: "ability",
				who: t.rid,
				ability: "reroutePickup"
			}), {
				state: e,
				fx: r
			};
		}
		case "rerouteDrop":
			{
				let e = o("juicer", "advanced");
				if (e) return e;
			}
			return e.turn.juicerUsed || !t.rerouteAlarm ? V("games.burglebros.errAbilityUsed") : (e.turn.juicerUsed = !0, t.rerouteAlarm = !1, a.tiles[t.pos].alarm = !0, ze(e, i), r.push({
				kind: "alarm",
				data: {
					floor: i,
					tile: t.pos
				}
			}), e.log.push({
				t: "ability",
				who: t.rid,
				ability: "rerouteDrop"
			}), {
				state: e,
				fx: r
			});
		case "crow": {
			{
				let e = o("raven", "basic");
				if (e) return e;
			}
			if (n.tile === void 0) return V("games.burglebros.errTile");
			let s = gt(e, i, t.pos);
			return s[n.tile] === -1 || s[n.tile] > 2 ? V("games.burglebros.errTile") : (a.tiles[n.tile].crow = !0, e.log.push({
				t: "ability",
				who: t.rid,
				ability: "crow"
			}), {
				state: e,
				fx: r
			});
		}
		case "tinker":
			{
				let e = o("rigger", "advanced");
				if (e) return e;
			}
			return t.stealth < 1 ? V("games.burglebros.errAbility") : (t.stealth--, We(e, t, r), e.log.push({
				t: "ability",
				who: t.rid,
				ability: "tinker"
			}), {
				state: e,
				fx: r
			});
		case "climbWindow": {
			{
				let e = o("acrobat", "advanced");
				if (e) return e;
			}
			if (e.turn.actionsLeft < 3) return V("games.burglebros.errActions");
			let a = e.size, s = t.pos % a, c = Math.floor(t.pos / a);
			if (!(s === 0 || s === a - 1 || c === 0 || c === a - 1 || G(e).some((e) => Math.abs(e % a - s) + Math.abs(Math.floor(e / a) - c) === 1))) return V("games.burglebros.errAbility");
			let l = n.floor ?? -1;
			return Math.abs(l - i) !== 1 || l < 0 || l >= e.floors.length || e.floors[l].tiles[t.pos].def < 0 ? V("games.burglebros.errTile") : (X(e, 3), He(e, t, r), t.floor = l, Re(e, l, r), r.push({
				kind: "move",
				rid: t.rid,
				data: {
					floor: l,
					tile: t.pos
				}
			}), Ue(e, t, l, t.pos, r, !0), e.turn.actionsLeft = 0, e.log.push({
				t: "ability",
				who: t.rid,
				ability: "climbWindow"
			}), {
				state: e,
				fx: r
			});
		}
	}
}
function gt(e, t, n) {
	let r = Array(e.size * e.size).fill(-1);
	r[n] = 0;
	let i = [n];
	for (; i.length;) {
		let n = [];
		for (let a of i) for (let i of P(e.size, e.floors[t].walls, G(e), a)) r[i] === -1 && (r[i] = r[a] + 1, n.push(i));
		i = n;
	}
	return r;
}
function _t(e, t, n, r) {
	let i = e.players.find((e) => e.rid === n.to);
	if (!i || i === t || i.escaped || i.floor !== t.floor || i.pos !== t.pos) return V("games.burglebros.errTarget");
	if (n.kind === "tool") {
		let e = n.card;
		if (!Pe(t, e)) return V("games.burglebros.errTool");
		t.tools.splice(t.tools.indexOf(e), 1), i.tools.push(e);
	} else {
		let e = n.card;
		if (!W(t, e)) return V("games.burglebros.errLoot");
		if (e === "goldBar" && W(i, "goldBar")) return V("games.burglebros.errGoldBar");
		t.loot.splice(t.loot.indexOf(e), 1), i.loot.push(e);
	}
	return e.log.push({
		t: "give",
		who: t.rid,
		to: i.rid
	}), {
		state: e,
		fx: r
	};
}
function vt(e, t, n, r) {
	let i = je(e, t.by), a = () => {
		e.pending = null;
	};
	switch (t.k) {
		case "entrance": {
			if (n.tile === void 0) return V("games.burglebros.errTile");
			let t = e.floors[0].tiles[n.tile];
			if (!t || t.def < 0) return V("games.burglebros.errTile");
			Y(e, 0, n.tile, r), t.stairsDown = !0;
			for (let t of e.players) t.floor = 0, t.pos = n.tile;
			return Re(e, 0, r), a(), null;
		}
		case "peekhole":
			if (n.floor !== void 0 && n.tile !== void 0) {
				let t = e.floors[n.floor]?.tiles[n.tile];
				if (!t || t.def < 0 || t.revealed) return V("games.burglebros.errTile");
				Y(e, n.floor, n.tile, r);
			}
			return a(), null;
		case "goWithGut": {
			if (n.tile === void 0) return V("games.burglebros.errTile");
			let t = i.floor;
			if (!P(e.size, e.floors[t].walls, G(e), i.pos).includes(n.tile)) return V("games.burglebros.errTile");
			let o = e.floors[t].tiles[n.tile];
			if (o.revealed) return V("games.burglebros.errTile");
			He(e, i, r);
			let s = k[o.def - 300];
			if (s.kind === "deadbolt") {
				let o = e.players.some((e) => e !== i && !e.escaped && e.floor === t && e.pos === n.tile) || e.guards[t].active && e.guards[t].pos === n.tile;
				if (Y(e, t, n.tile, r), !o) return a(), null;
			}
			if (s.kind === "keypad" && !o.open) {
				if (Y(e, t, n.tile, r), Ae(e) !== 6) return a(), null;
				o.open = !0;
			}
			return i.pos = n.tile, r.push({
				kind: "move",
				rid: i.rid,
				data: {
					floor: t,
					tile: n.tile
				}
			}), Ue(e, i, t, n.tile, r, !0), s.kind === "laser" && !o.crowbar && J(e, t, n.tile, r), a(), null;
		}
		case "throwVoice": {
			if (n.tile === void 0) return V("games.burglebros.errTile");
			let t = i.floor, r = e.guards[t];
			return P(e.size, e.floors[t].walls, G(e), r.dest).includes(n.tile) ? (r.dest = n.tile, a(), null) : V("games.burglebros.errTile");
		}
		case "buddySystem": {
			let t = e.players.find((e) => e.rid === n.target);
			return !t || t === i || t.escaped ? V("games.burglebros.errTarget") : (t.floor = i.floor, t.pos = i.pos, Re(e, t.floor, r), r.push({
				kind: "move",
				rid: t.rid,
				data: {
					floor: t.floor,
					tile: t.pos
				}
			}), a(), null);
		}
		case "crystalBall": {
			if (!n.order || n.order.length !== t.cards.length) return V("games.burglebros.errOrder");
			let r = [...t.cards].sort();
			if (![...n.order].sort().every((e, t) => e === r[t])) return V("games.burglebros.errOrder");
			for (let t = n.order.length - 1; t >= 0; t--) e.events.push(n.order[t]);
			return a(), null;
		}
		case "toolDraw": {
			if (!n.keep || !t.cards.includes(n.keep)) return V("games.burglebros.errKeep");
			i.tools.push(n.keep), e.log.push({
				t: "tool",
				who: i.rid,
				tool: n.keep
			}), r.push({
				kind: "tool",
				rid: i.rid,
				data: { tool: n.keep }
			});
			let o = t.cards.find((e) => e !== n.keep);
			return e.tools.unshift(o), a(), null;
		}
		case "clairvoyance":
			if (n.bottom) {
				let t = e.patrol[i.floor], n = t.deck.pop();
				t.deck.unshift(n);
			}
			return a(), null;
		case "precognition":
			if (n.bottom) {
				let t = e.events.pop();
				e.events.unshift(t);
			}
			return a(), null;
		case "crackReroll": {
			let o = [...t.dice];
			if (n.die !== void 0 && n.face !== void 0) {
				if (n.die < 0 || n.die >= o.length) return V("games.burglebros.errDie");
				o[n.die] = n.face;
			}
			return a(), pt(e, i, t.floor, i.pos, o, r), null;
		}
	}
}
function yt(e) {
	let t = G(e);
	return {
		scenario: e.scenario,
		size: e.size,
		floors: e.floors.map((e) => ({
			tiles: e.tiles.map((e) => ({
				def: e.revealed && e.def >= 0 ? e.def : null,
				revealed: e.revealed,
				alarm: e.alarm,
				hacks: e.hacks,
				stealthPool: e.stealthPool,
				open: e.open,
				dice: e.dice,
				cracked: e.cracked,
				crackedNums: e.crackedNums,
				crow: e.crow,
				stairsDown: e.stairsDown,
				thermal: e.thermal,
				crowbar: e.crowbar,
				labTaken: e.labTaken
			})),
			walls: e.walls,
			blanks: t
		})),
		guards: e.guards.map((e) => ({
			active: e.active,
			pos: e.pos,
			dest: e.dest,
			dice: e.dice,
			bonus: e.bonus,
			donuts: e.donuts
		})),
		players: e.players.map((e) => ({
			rid: e.rid,
			char: e.char,
			side: e.side,
			floor: e.floor,
			pos: e.pos,
			stealth: e.stealth,
			tools: [...e.tools],
			loot: [...e.loot],
			escaped: e.escaped,
			laptopHack: e.laptopHack,
			rerouteAlarm: e.rerouteAlarm
		})),
		turn: {
			seat: e.turn.seat,
			actionsLeft: e.turn.actionsLeft
		},
		phase: e.phase,
		pending: e.pending ? {
			k: e.pending.k,
			by: e.pending.by,
			dice: e.pending.k === "crackReroll" ? [...e.pending.dice] : void 0,
			floor: e.pending.k === "crackReroll" ? e.pending.floor : void 0
		} : null,
		decks: {
			events: e.events.length,
			tools: e.tools.length,
			loot: e.lootDeck.length
		},
		patrolLeft: e.patrol.map((e) => e.deck.length),
		patrolDiscard: e.patrol.map((e) => [...e.discard]),
		effects: {
			timeLock: e.effects.timeLockBy !== null,
			emp: e.effects.empBy !== null,
			videoLoop: e.effects.videoLoopBy !== null,
			gymnastics: e.effects.gymnasticsBy !== null
		},
		kitty: e.kitty ? { ...e.kitty } : null,
		lootOnTile: e.lootOnTile ? { ...e.lootOnTile } : null,
		lootFound: e.players.flatMap((e) => e.loot),
		lostReason: e.lostReason
	};
}
function bt(e, t) {
	let n = {
		crystalCards: null,
		clairvoyanceCard: null,
		precognitionCard: null,
		toolDrawCards: null
	}, r = e.pending;
	return r && r.by === t && (r.k === "crystalBall" && (n.crystalCards = [...r.cards]), r.k === "clairvoyance" && (n.clairvoyanceCard = r.card), r.k === "precognition" && (n.precognitionCard = r.card), r.k === "toolDraw" && (n.toolDrawCards = [...r.cards])), {
		public: yt(e),
		private: n
	};
}
function xt(e) {
	return e.phase === "won" ? {
		phase: "won",
		winner: e.seats,
		ranking: e.seats
	} : e.phase === "lost" ? {
		phase: "lost",
		winner: [],
		ranking: e.seats
	} : { phase: e.phase };
}
function St(e) {
	return e.phase === "guard" && e.guardMove ? e.beatMs : null;
}
var Ct = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: I,
	schemas: {
		action: me,
		publicView: ye,
		privateView: be,
		config: B
	},
	setup: Le,
	reduce: at,
	viewFor: bt,
	status: xt,
	nextTickIn: St
}, Z = "var(--color-ink)", wt = {
	safe: {
		band: "#3d9e63",
		deep: "#2c7a4b"
	},
	stairs: {
		band: "#33415c",
		deep: "#232c40"
	},
	walkway: {
		band: "#8aa9c4",
		deep: "#5f7f9c"
	},
	laboratory: {
		band: "#8aa9c4",
		deep: "#5f7f9c"
	},
	lavatory: {
		band: "#8aa9c4",
		deep: "#5f7f9c"
	},
	serviceDuct: {
		band: "#9a9b4a",
		deep: "#74752f"
	},
	secretDoor: {
		band: "#9a9b4a",
		deep: "#74752f"
	},
	computerFp: {
		band: "#8b7fa8",
		deep: "#6a5f87"
	},
	computerLaser: {
		band: "#8b7fa8",
		deep: "#6a5f87"
	},
	computerMotion: {
		band: "#8b7fa8",
		deep: "#6a5f87"
	},
	camera: {
		band: "#c2497f",
		deep: "#9c3563"
	},
	laser: {
		band: "#d64541",
		deep: "#ab3230"
	},
	motion: {
		band: "#d64541",
		deep: "#ab3230"
	},
	detector: {
		band: "#d64541",
		deep: "#ab3230"
	},
	fingerprint: {
		band: "#d64541",
		deep: "#ab3230"
	},
	thermo: {
		band: "#d64541",
		deep: "#ab3230"
	},
	keypad: {
		band: "#b58430",
		deep: "#8f6620"
	},
	deadbolt: {
		band: "#b58430",
		deep: "#8f6620"
	},
	foyer: {
		band: "#d9a821",
		deep: "#ad8315"
	},
	atrium: {
		band: "#d9a821",
		deep: "#ad8315"
	}
}, Tt = /* @__PURE__ */ new Set([
	"camera",
	"laser",
	"motion",
	"detector",
	"fingerprint",
	"thermo"
]), Et = /* @__PURE__ */ new Set(["keypad", "deadbolt"]);
function Dt(e) {
	return /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("rect", {
			x: 14,
			y: 14,
			width: 20,
			height: 13,
			rx: 2,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		e,
		/* @__PURE__ */ S("path", {
			d: "M24 27 v4 M19 33 h10",
			fill: "none",
			stroke: Z,
			strokeWidth: 2,
			strokeLinecap: "round"
		})
	] });
}
var Ot = {
	safe: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("circle", {
			cx: 24,
			cy: 27,
			r: 11,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("circle", {
			cx: 24,
			cy: 27,
			r: 6.5,
			fill: "none",
			stroke: Z,
			strokeWidth: 1.6
		}),
		/* @__PURE__ */ S("circle", {
			cx: 24,
			cy: 27,
			r: 2,
			fill: Z,
			stroke: "none"
		}),
		[
			45,
			135,
			225,
			315
		].map((e) => /* @__PURE__ */ S("path", {
			d: "M24 20.5 v-4.5",
			stroke: Z,
			strokeWidth: 1.6,
			transform: `rotate(${e} 24 27)`
		}, e))
	] }),
	stairs: /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("path", {
		d: "M12 41 h8 v-7 h8 v-7 h8 v-7",
		fill: "none",
		stroke: Z,
		strokeWidth: 2.2,
		strokeLinejoin: "round"
	}), /* @__PURE__ */ S("path", {
		d: "M24 9 l-4 5 M24 9 l4 5 M24 9 v6",
		fill: "none",
		stroke: Z,
		strokeWidth: 2,
		strokeLinecap: "round"
	})] }),
	walkway: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("path", {
			d: "M10 35 H38",
			stroke: Z,
			strokeWidth: 2.2,
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ S("path", {
			d: "M10 27 H38 M10 23 H38",
			stroke: Z,
			strokeWidth: 1.8,
			strokeLinecap: "round"
		}),
		[
			14,
			20,
			26,
			32
		].map((e) => /* @__PURE__ */ S("path", {
			d: `M${e} 23 V35`,
			stroke: Z,
			strokeWidth: 1.8
		}, e))
	] }),
	laboratory: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("path", {
			d: "M20 14 h8 M22 14 v6 l-7 16 h18 l-7 -16 v-6",
			fill: "none",
			stroke: Z,
			strokeWidth: 2,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ S("path", {
			d: "M17.5 30 h13",
			stroke: Z,
			strokeWidth: 1.6
		}),
		/* @__PURE__ */ S("circle", {
			cx: 21,
			cy: 33.5,
			r: 1.3,
			fill: Z,
			stroke: "none"
		}),
		/* @__PURE__ */ S("circle", {
			cx: 26.5,
			cy: 32.5,
			r: 1,
			fill: Z,
			stroke: "none"
		})
	] }),
	lavatory: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("rect", {
			x: 13,
			y: 13,
			width: 6,
			height: 11,
			rx: 1.5,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("ellipse", {
			cx: 26.5,
			cy: 26,
			rx: 7,
			ry: 3.5,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("path", {
			d: "M23.5 29 v7 h6 M13 37 h22",
			fill: "none",
			stroke: Z,
			strokeWidth: 2,
			strokeLinecap: "round"
		})
	] }),
	serviceDuct: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("circle", {
			cx: 24,
			cy: 27,
			r: 9,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("circle", {
			cx: 24,
			cy: 27,
			r: 3,
			fill: "none",
			stroke: Z,
			strokeWidth: 1.6
		}),
		[
			0,
			90,
			180,
			270
		].map((e) => /* @__PURE__ */ S("path", {
			d: "M24 18 v-4",
			stroke: Z,
			strokeWidth: 2,
			strokeLinecap: "round",
			transform: `rotate(${e} 24 27)`
		}, e))
	] }),
	secretDoor: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("rect", {
			x: 17,
			y: 12,
			width: 14,
			height: 27,
			rx: 1.5,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("path", {
			d: "M17 17 h3 M17 34 h3",
			stroke: Z,
			strokeWidth: 1.6
		}),
		/* @__PURE__ */ S("path", {
			d: "M10 25 h28 m0 0 l-4 -3 m4 3 l-4 3",
			fill: "none",
			stroke: Z,
			strokeWidth: 1.8,
			strokeDasharray: "4 2.5",
			strokeLinecap: "round"
		})
	] }),
	computerFp: Dt(/* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("path", {
		d: "M20 24 a4.5 4.5 0 0 1 8 0 M22 24 a2.5 2.5 0 0 1 4 0",
		fill: "none",
		stroke: Z,
		strokeWidth: 1.4
	}), /* @__PURE__ */ S("circle", {
		cx: 24,
		cy: 24.5,
		r: .9,
		fill: Z,
		stroke: "none"
	})] })),
	computerLaser: Dt(/* @__PURE__ */ S(x, { children: /* @__PURE__ */ S("path", {
		d: "M16 15.5 L32 25.5 M32 15.5 L16 25.5",
		stroke: "#d64541",
		strokeWidth: 1.6,
		strokeLinecap: "round"
	}) })),
	computerMotion: Dt(/* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("path", {
		d: "M22 24.5 a3.5 3.5 0 0 1 0 -7 M25.5 26.5 a7 7 0 0 1 0 -11",
		fill: "none",
		stroke: Z,
		strokeWidth: 1.4,
		strokeLinecap: "round"
	}), /* @__PURE__ */ S("circle", {
		cx: 22,
		cy: 21,
		r: 1,
		fill: Z,
		stroke: "none"
	})] })),
	camera: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("path", {
			d: "M24 13 v4",
			stroke: Z,
			strokeWidth: 2,
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ S("path", {
			d: "M13 27 a11 11 0 0 1 22 0 Z",
			fill: "none",
			stroke: Z,
			strokeWidth: 2,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ S("circle", {
			cx: 24,
			cy: 22,
			r: 2.5,
			fill: "none",
			stroke: Z,
			strokeWidth: 1.6
		}),
		/* @__PURE__ */ S("path", {
			d: "M13 31 h22",
			stroke: Z,
			strokeWidth: 2,
			strokeLinecap: "round"
		})
	] }),
	laser: /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("path", {
		d: "M11 15 L37 39 M37 15 L11 39",
		stroke: "#d64541",
		strokeWidth: 2.2,
		strokeLinecap: "round"
	}), /* @__PURE__ */ S("path", {
		d: "M11 27 H37",
		stroke: "#d64541",
		strokeWidth: 2.2,
		strokeLinecap: "round",
		opacity: .75
	})] }),
	motion: /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("circle", {
		cx: 17,
		cy: 37,
		r: 2,
		fill: Z,
		stroke: "none"
	}), /* @__PURE__ */ S("path", {
		d: "M22.5 31.5 a8 8 0 0 1 8 8 M27.5 26.5 a15 15 0 0 1 15 15",
		fill: "none",
		stroke: Z,
		strokeWidth: 2,
		strokeLinecap: "round",
		transform: "translate(0 -22)"
	})] }),
	detector: /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("path", {
		d: "M15 40 V15 h18 v25",
		fill: "none",
		stroke: Z,
		strokeWidth: 2.2,
		strokeLinejoin: "round"
	}), /* @__PURE__ */ S("path", {
		d: "M24 19 v17",
		stroke: Z,
		strokeWidth: 1.6,
		strokeDasharray: "3 2.5"
	})] }),
	fingerprint: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("path", {
			d: "M16 31 a8.5 8.5 0 1 1 16 0",
			fill: "none",
			stroke: Z,
			strokeWidth: 1.8,
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ S("path", {
			d: "M19.5 31 a5 5 0 1 1 9 0",
			fill: "none",
			stroke: Z,
			strokeWidth: 1.8,
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ S("path", {
			d: "M23 31 a1.8 1.8 0 1 1 2.2 0",
			fill: "none",
			stroke: Z,
			strokeWidth: 1.6,
			strokeLinecap: "round"
		})
	] }),
	thermo: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("path", {
			d: "M22 26 V15 a2.5 2.5 0 0 1 5 0 v11",
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("circle", {
			cx: 24.5,
			cy: 31,
			r: 5,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("circle", {
			cx: 24.5,
			cy: 31,
			r: 1.8,
			fill: Z,
			stroke: "none"
		}),
		/* @__PURE__ */ S("path", {
			d: "M30 17 h3 M30 21 h3",
			stroke: Z,
			strokeWidth: 1.6,
			strokeLinecap: "round"
		})
	] }),
	keypad: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("rect", {
			x: 15,
			y: 12,
			width: 18,
			height: 26,
			rx: 2,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("path", {
			d: "M18.5 16.5 h11",
			stroke: Z,
			strokeWidth: 1.6,
			strokeLinecap: "round"
		}),
		[
			20.5,
			24,
			27.5
		].flatMap((e) => [
			21,
			25.5,
			30
		].map((t) => /* @__PURE__ */ S("circle", {
			cx: e,
			cy: t,
			r: 1.2,
			fill: Z,
			stroke: "none"
		}, `${e},${t}`)))
	] }),
	deadbolt: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("path", {
			d: "M17 11 V41",
			stroke: Z,
			strokeWidth: 2.2,
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ S("rect", {
			x: 17,
			y: 22,
			width: 13,
			height: 7,
			rx: 2,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("circle", {
			cx: 27,
			cy: 25.5,
			r: 1.5,
			fill: Z,
			stroke: "none"
		}),
		/* @__PURE__ */ S("path", {
			d: "M33 20 v11",
			stroke: Z,
			strokeWidth: 2,
			strokeLinecap: "round"
		})
	] }),
	foyer: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("rect", {
			x: 13,
			y: 19,
			width: 22,
			height: 8,
			rx: 3.5,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("rect", {
			x: 13,
			y: 26,
			width: 22,
			height: 7,
			rx: 2.5,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("path", {
			d: "M16 33 v4 M32 33 v4",
			stroke: Z,
			strokeWidth: 2,
			strokeLinecap: "round"
		})
	] }),
	atrium: /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("ellipse", {
			cx: 24,
			cy: 27,
			rx: 13,
			ry: 6,
			fill: "none",
			stroke: Z,
			strokeWidth: 2
		}),
		/* @__PURE__ */ S("ellipse", {
			cx: 24,
			cy: 27,
			rx: 8.5,
			ry: 4,
			fill: "none",
			stroke: Z,
			strokeWidth: 1.6
		}),
		/* @__PURE__ */ S("ellipse", {
			cx: 24,
			cy: 27,
			rx: 4,
			ry: 2,
			fill: "none",
			stroke: Z,
			strokeWidth: 1.4
		}),
		/* @__PURE__ */ S("path", {
			d: "M24 13 v6",
			stroke: Z,
			strokeWidth: 1.8,
			strokeLinecap: "round"
		})
	] })
};
function kt({ kind: e, num: t, white: n, size: r }) {
	let i = wt[e];
	return /* @__PURE__ */ C("svg", {
		viewBox: "0 0 48 48",
		"aria-hidden": !0,
		className: r ? "flex-none" : "absolute inset-0 size-full",
		...r ? {
			width: r,
			height: r
		} : {},
		children: [
			/* @__PURE__ */ S("rect", {
				width: 48,
				height: 48,
				rx: 4,
				fill: "#faf5ea"
			}),
			/* @__PURE__ */ S("path", {
				d: "M4 0 H44 A4 4 0 0 1 48 4 V10 H0 V4 A4 4 0 0 1 4 0 Z",
				fill: i.band
			}),
			/* @__PURE__ */ S("path", {
				d: "M0 10 H48",
				stroke: i.deep,
				strokeWidth: 1.6
			}),
			/* @__PURE__ */ S("g", {
				opacity: .16,
				transform: "translate(24 27) scale(1.2) translate(-24 -27)",
				children: Ot[e]
			}),
			Tt.has(e) && /* @__PURE__ */ C("g", {
				transform: "translate(2.5 36.5)",
				children: [/* @__PURE__ */ S("path", {
					d: "M4.5 0 L9 8.5 H0 Z",
					fill: "#d64541",
					stroke: Z,
					strokeWidth: 1,
					strokeLinejoin: "round"
				}), /* @__PURE__ */ S("path", {
					d: "M4.5 3 v2.2 M4.5 6.8 v.6",
					stroke: "#fff",
					strokeWidth: 1.2,
					strokeLinecap: "round"
				})]
			}),
			Et.has(e) && /* @__PURE__ */ C("g", {
				transform: "translate(2.5 36.5)",
				children: [/* @__PURE__ */ S("circle", {
					cx: 4.5,
					cy: 4.5,
					r: 4.2,
					fill: "#b58430",
					stroke: Z,
					strokeWidth: 1
				}), /* @__PURE__ */ S("path", {
					d: "M1.8 7.2 L7.2 1.8",
					stroke: "#fff",
					strokeWidth: 1.4,
					strokeLinecap: "round"
				})]
			}),
			t > 0 && /* @__PURE__ */ C("g", { children: [/* @__PURE__ */ S("circle", {
				cx: 40,
				cy: 40,
				r: 6.5,
				fill: n ? "#ffffff" : Z,
				stroke: Z,
				strokeWidth: 1.4
			}), /* @__PURE__ */ S("text", {
				x: 40,
				y: 40.5,
				textAnchor: "middle",
				dominantBaseline: "central",
				fontSize: 9.5,
				fontWeight: 800,
				fill: n ? Z : "#ffffff",
				className: "font-mono tabular-nums",
				children: t
			})] })
		]
	});
}
function At({ size: e }) {
	let t = e ? {
		width: e,
		height: e
	} : {}, n = I.accent;
	return /* @__PURE__ */ C("svg", {
		viewBox: "0 0 48 48",
		"aria-hidden": !0,
		className: e ? "flex-none" : "absolute inset-0 size-full",
		...t,
		children: [
			/* @__PURE__ */ S("rect", {
				width: 48,
				height: 48,
				rx: 4,
				fill: n
			}),
			/* @__PURE__ */ C("g", {
				fill: "none",
				stroke: "#ffffff",
				strokeWidth: 1,
				opacity: .5,
				children: [
					/* @__PURE__ */ S("path", { d: "M5 11 h12 v9 h-7 v9" }),
					/* @__PURE__ */ S("path", { d: "M43 9 v11 h-9" }),
					/* @__PURE__ */ S("path", { d: "M5 43 v-8 h10" }),
					/* @__PURE__ */ S("path", { d: "M38 43 h5 v-7" })
				]
			}),
			/* @__PURE__ */ S("g", {
				stroke: "#ffffff",
				strokeWidth: 1.2,
				opacity: .35,
				children: /* @__PURE__ */ S("path", { d: "M38 10 L46 2 M42 10 L48 4 M34 10 L46 -2" })
			}),
			/* @__PURE__ */ S("circle", {
				cx: 24,
				cy: 25,
				r: 9.5,
				fill: "none",
				stroke: "#ffffff",
				strokeWidth: 2
			}),
			/* @__PURE__ */ S("path", {
				d: "M15.5 25 Q24 17.5 32.5 25 Q24 32.5 15.5 25 Z",
				fill: "#ffffff"
			}),
			/* @__PURE__ */ S("circle", {
				cx: 24,
				cy: 25,
				r: 2.6,
				fill: n
			})
		]
	});
}
//#endregion
//#region src/games/burglebros/view-player.tsx
var jt = {
	safe: "games.burglebros.tileSafe",
	stairs: "games.burglebros.tileStairs",
	walkway: "games.burglebros.tileWalkway",
	laboratory: "games.burglebros.tileLaboratory",
	lavatory: "games.burglebros.tileLavatory",
	serviceDuct: "games.burglebros.tileServiceDuct",
	secretDoor: "games.burglebros.tileSecretDoor",
	computerFp: "games.burglebros.tileComputerFp",
	computerLaser: "games.burglebros.tileComputerLaser",
	computerMotion: "games.burglebros.tileComputerMotion",
	camera: "games.burglebros.tileCamera",
	laser: "games.burglebros.tileLaser",
	motion: "games.burglebros.tileMotion",
	detector: "games.burglebros.tileDetector",
	fingerprint: "games.burglebros.tileFingerprint",
	thermo: "games.burglebros.tileThermo",
	keypad: "games.burglebros.tileKeypad",
	deadbolt: "games.burglebros.tileDeadbolt",
	foyer: "games.burglebros.tileFoyer",
	atrium: "games.burglebros.tileAtrium"
}, Mt = {
	safe: "games.burglebros.tileDescSafe",
	stairs: "games.burglebros.tileDescStairs",
	walkway: "games.burglebros.tileDescWalkway",
	laboratory: "games.burglebros.tileDescLaboratory",
	lavatory: "games.burglebros.tileDescLavatory",
	serviceDuct: "games.burglebros.tileDescServiceDuct",
	secretDoor: "games.burglebros.tileDescSecretDoor",
	computerFp: "games.burglebros.tileDescComputerFp",
	computerLaser: "games.burglebros.tileDescComputerLaser",
	computerMotion: "games.burglebros.tileDescComputerMotion",
	camera: "games.burglebros.tileDescCamera",
	laser: "games.burglebros.tileDescLaser",
	motion: "games.burglebros.tileDescMotion",
	detector: "games.burglebros.tileDescDetector",
	fingerprint: "games.burglebros.tileDescFingerprint",
	thermo: "games.burglebros.tileDescThermo",
	keypad: "games.burglebros.tileDescKeypad",
	deadbolt: "games.burglebros.tileDescDeadbolt",
	foyer: "games.burglebros.tileDescFoyer",
	atrium: "games.burglebros.tileDescAtrium"
}, Nt = {
	peekhole: "games.burglebros.evPeekhole",
	deadDrop: "games.burglebros.evDeadDrop",
	lampshade: "games.burglebros.evLampshade",
	switchSigns: "games.burglebros.evSwitchSigns",
	headsUp: "games.burglebros.evHeadsUp",
	gymnastics: "games.burglebros.evGymnastics",
	changeOfPlans: "games.burglebros.evChangeOfPlans",
	goWithGut: "games.burglebros.evGoWithGut",
	brownOut: "games.burglebros.evBrownOut",
	crash: "games.burglebros.evCrash",
	espresso: "games.burglebros.evEspresso",
	reboot: "games.burglebros.evReboot",
	squeak: "games.burglebros.evSqueak",
	shiftChange: "games.burglebros.evShiftChange",
	buddySystem: "games.burglebros.evBuddySystem",
	freightElevator: "games.burglebros.evFreightElevator",
	keycodeChange: "games.burglebros.evKeycodeChange",
	jumpTheGun: "games.burglebros.evJumpTheGun",
	daydreaming: "games.burglebros.evDaydreaming",
	juryRig: "games.burglebros.evJuryRig",
	timeLock: "games.burglebros.evTimeLock",
	lostGrip: "games.burglebros.evLostGrip",
	whereIsHe: "games.burglebros.evWhereIsHe",
	shoplifting: "games.burglebros.evShoplifting",
	throwVoice: "games.burglebros.evThrowVoice",
	videoLoop: "games.burglebros.evVideoLoop"
}, Pt = {
	blueprints: "games.burglebros.toolBlueprints",
	crowbar: "games.burglebros.toolCrowbar",
	crystalBall: "games.burglebros.toolCrystalBall",
	donuts: "games.burglebros.toolDonuts",
	dynamite: "games.burglebros.toolDynamite",
	emp: "games.burglebros.toolEmp",
	invisibleSuit: "games.burglebros.toolInvisibleSuit",
	makeupKit: "games.burglebros.toolMakeupKit",
	rollerskates: "games.burglebros.toolRollerskates",
	smokeBomb: "games.burglebros.toolSmokeBomb",
	stethoscope: "games.burglebros.toolStethoscope",
	thermalBomb: "games.burglebros.toolThermalBomb",
	virus: "games.burglebros.toolVirus"
}, Ft = {
	stamp: "games.burglebros.lootStamp",
	chihuahua: "games.burglebros.lootChihuahua",
	tiara: "games.burglebros.lootTiara",
	persianKitty: "games.burglebros.lootPersianKitty",
	keycard: "games.burglebros.lootKeycard",
	mirror: "games.burglebros.lootMirror",
	gemstone: "games.burglebros.lootGemstone",
	goldBar: "games.burglebros.lootGoldBar",
	cursedGoblet: "games.burglebros.lootCursedGoblet",
	bust: "games.burglebros.lootBust",
	isotope: "games.burglebros.lootIsotope",
	painting: "games.burglebros.lootPainting"
}, It = {
	rook: "games.burglebros.charRook",
	spotter: "games.burglebros.charSpotter",
	hawk: "games.burglebros.charHawk",
	acrobat: "games.burglebros.charAcrobat",
	juicer: "games.burglebros.charJuicer",
	rigger: "games.burglebros.charRigger",
	peterman: "games.burglebros.charPeterman",
	hacker: "games.burglebros.charHacker",
	raven: "games.burglebros.charRaven"
}, Lt = (e, t) => `${String.fromCharCode(65 + e % t)}${Math.floor(e / t) + 1}`;
function Rt(e) {
	return /* @__PURE__ */ S(zt, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function zt({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let s = u(), c = e.players.find((e) => e.rid === r), [l, d] = o(c?.floor ?? 0), [f, p] = o({ k: "move" }), [m, h] = o(null), [v, b] = o(null), [w, T] = o(null), E = (e) => n.find((t) => t.rid === e)?.name ?? e, ne = (e) => {
		let t = n.find((t) => t.rid === e);
		return g[(t?.colorIndex ?? 0) % g.length].hex;
	}, re = (e) => n.find((t) => t.rid === e)?.avatar ?? 0, D = c && !c.escaped && e.phase === "play" && !e.pending && e.players[e.turn.seat]?.rid === r, O = i(() => c ? Te(e, r) : [], [
		e,
		c,
		r
	]), ie = i(() => c ? Ee(e, r) : [], [
		e,
		c,
		r
	]), [ae, oe] = o(c?.floor ?? 0);
	if (c && c.floor !== ae && (oe(c.floor), D && d(c.floor)), !c) return null;
	let A = e.pending, se = "info", j;
	e.phase === "guard" ? (se = "warn", j = s("games.burglebros.guardBanner")) : A ? (se = A.by === r ? "accent" : "info", j = A.by === r ? Bt(A.k, s) : s("games.burglebros.pendingWait", { name: E(A.by) }), A.k === "entrance" && A.by !== r && (j = s("games.burglebros.entranceWaiting", { name: E(A.by) })), A.k === "entrance" && A.by === r && (j = s("games.burglebros.entrancePrompt"))) : D ? (se = "accent", j = s("games.burglebros.turnBanner", { n: e.turn.actionsLeft })) : j = s("games.burglebros.waitBanner", { name: E(e.players[e.turn.seat]?.rid ?? "") });
	let ce = /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S(y, {
		tone: se,
		text: j,
		accent: I.accent
	}), /* @__PURE__ */ S(te, {
		adaptive: !0,
		variant: "plate",
		members: n,
		myRid: r,
		anchorOf: (e) => `seat:${e}`,
		action: (t) => e.players[e.turn.seat]?.rid === t && e.phase === "play" ? "pending" : null,
		status: (t) => {
			let n = e.players.find((e) => e.rid === t);
			return n ? /* @__PURE__ */ C("span", {
				className: "burgle-player-status flex items-center gap-1 text-xs leading-4.5 font-bold",
				children: [
					/* @__PURE__ */ S("span", { children: s(It[n.char]) }),
					/* @__PURE__ */ C("span", {
						className: "font-mono tabular-nums",
						children: ["🥷", n.stealth]
					}),
					n.escaped && /* @__PURE__ */ S("span", {
						className: "rounded-md bg-done-soft px-1 text-done-ink",
						children: s("games.burglebros.escapedMark")
					})
				]
			}) : null;
		}
	})] }), le = (t, n) => {
		if (A) return A.by === r ? A.k === "entrance" && t === 0 ? (a({
			type: "resolve",
			tile: n
		}), !0) : A.k === "peekhole" && !e.floors[t].tiles[n].revealed ? (a({
			type: "resolve",
			floor: t,
			tile: n
		}), !0) : A.k === "goWithGut" && t === c.floor || A.k === "throwVoice" && t === c.floor ? (a({
			type: "resolve",
			tile: n
		}), !0) : !1 : !1;
		if (!D) return !1;
		if (f.k === "peek") return ie.some((e) => e.floor === t && e.tile === n) ? (a({
			type: "peek",
			floor: t,
			tile: n
		}), !0) : !1;
		if (f.k === "move") {
			let e = O.filter((e) => e.floor === t && e.tile === n);
			return e.length === 1 ? (a({
				type: "move",
				floor: t,
				tile: n,
				unsafe: e[0].unsafe
			}), !0) : e.length > 1 && (h(e), !0);
		}
		if (f.k === "tool") {
			let e = f.tool;
			return e === "blueprints" && a({
				type: "useTool",
				tool: e,
				floor: t,
				tile: n
			}), e === "crowbar" && t === c.floor && a({
				type: "useTool",
				tool: e,
				tile: n
			}), e === "virus" && a({
				type: "useTool",
				tool: e,
				floor: t,
				tile: n
			}), e === "dynamite" && t === c.floor && a({
				type: "useTool",
				tool: e,
				wall: [c.pos, n]
			}), b(null), p({ k: "move" }), !0;
		}
		if (f.k === "ability") {
			let e = f.ability;
			return e === "xray" && a({
				type: "ability",
				ability: "xray",
				tile: n
			}), e === "crybaby" && t === c.floor && a({
				type: "ability",
				ability: "crybaby",
				tile: n
			}), e === "crow" && t === c.floor && a({
				type: "ability",
				ability: "crow",
				tile: n
			}), e === "orders" && f.target && a({
				type: "ability",
				ability: "orders",
				target: f.target,
				tile: n
			}), b(null), p({ k: "move" }), !0;
		}
		return !1;
	}, ue = (e, t) => {
		T(null), le(e, t) || T({
			f: e,
			idx: t
		});
	}, M = /* @__PURE__ */ new Set();
	if (A?.by === r) A.k === "entrance" && e.floors[0].tiles.forEach((t, n) => {
		t.def === null && !e.floors[0].blanks.includes(n) && !t.revealed && M.add(`0:${n}`);
	}), A.k === "peekhole" && e.floors.forEach((e, t) => e.tiles.forEach((n, r) => {
		!n.revealed && !e.blanks.includes(r) && M.add(`${t}:${r}`);
	})), A.k === "goWithGut" && e.floors[c.floor].tiles.forEach((e, t) => {
		e.revealed || M.add(`${c.floor}:${t}`);
	}), A.k === "throwVoice" && e.floors[c.floor].tiles.forEach((e, t) => M.add(`${c.floor}:${t}`));
	else if (D) {
		if (f.k === "move") for (let e of O) M.add(`${e.floor}:${e.tile}`);
		if (f.k === "peek") for (let e of ie) M.add(`${e.floor}:${e.tile}`);
		if (f.k === "ability" && f.ability === "xray") for (let e of ie) e.floor === c.floor && M.add(`${e.floor}:${e.tile}`);
	}
	let N = l, P = e.floors[N], de = e.guards[N], F = e.size, L = (() => {
		let e = P.tiles[c.pos];
		if (N !== c.floor || !e.revealed || e.def === null || k[e.def - 300].kind !== "safe") return null;
		let t = c.pos % F, n = Math.floor(c.pos / F), r = /* @__PURE__ */ new Set();
		for (let e = 0; e < F; e++) for (let i of [n * F + e, e * F + t]) {
			if (P.blanks.includes(i)) continue;
			let e = P.tiles[i];
			if (!e.revealed) return {
				known: !1,
				nums: [],
				covered: []
			};
			if (e.def === null) continue;
			let t = k[e.def - 300].num;
			t > 0 && r.add(t);
		}
		return {
			known: !0,
			nums: [...r].sort((e, t) => e - t),
			covered: e.crackedNums
		};
	})(), R = /* @__PURE__ */ C("div", {
		className: "burgle-board flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ C("div", {
				className: "burgle-floor-bar flex flex-none items-center gap-1 px-1",
				children: [e.floors.map((e, t) => /* @__PURE__ */ S("button", {
					type: "button",
					onClick: () => d(t),
					className: `burgle-floor-tab min-h-11 rounded-lg border-2 border-ink px-2 text-xs font-extrabold ${t === N ? "bg-ink text-white" : "bg-white text-ink"}`,
					children: s("games.burglebros.floorLabel", { n: t + 1 })
				}, t)), /* @__PURE__ */ C("span", {
					className: "burgle-guard-status ml-auto flex items-center gap-2 text-xs font-bold text-ink/70",
					children: [de.active && /* @__PURE__ */ C("span", {
						className: "font-mono tabular-nums",
						children: [
							"💂",
							de.dice + de.bonus,
							" 🎯",
							Lt(de.dest, F)
						]
					}), /* @__PURE__ */ S("span", {
						className: "font-mono tabular-nums",
						children: s("games.burglebros.patrolLeft", { n: e.patrolLeft[N] })
					})]
				})]
			}),
			/* @__PURE__ */ C("div", {
				className: "burgle-board-stage relative min-h-0 flex-1",
				children: [/* @__PURE__ */ S(ee, {
					kind: "sheen",
					base: "var(--color-paper)",
					className: "absolute inset-0"
				}), /* @__PURE__ */ S("div", {
					className: "burgle-room-grid relative grid gap-1 p-1",
					style: {
						gridTemplateColumns: `repeat(${F}, minmax(0, 1fr))`,
						gridTemplateRows: `repeat(${F}, minmax(0, 1fr))`
					},
					children: P.tiles.map((t, n) => /* @__PURE__ */ S(Vt, {
						pub: e,
						f: N,
						idx: n,
						hl: M.has(`${N}:${n}`),
						myPos: c.floor === N && c.pos === n,
						onTap: () => ue(N, n),
						colorOf: ne,
						avatarOf: re
					}, n))
				})]
			}),
			/* @__PURE__ */ S("div", {
				className: "burgle-safe-readout flex h-7 flex-none items-center justify-center gap-1 text-xs font-bold",
				children: L && (L.known ? /* @__PURE__ */ C(x, { children: [
					/* @__PURE__ */ S("span", {
						className: "text-ink/60",
						children: s("games.burglebros.comboReady")
					}),
					L.nums.map((e) => /* @__PURE__ */ S("span", {
						className: `rounded border border-ink px-1 font-mono tabular-nums ${L.covered.includes(e) ? "bg-done-soft text-done-ink line-through" : "bg-white"}`,
						children: e
					}, e)),
					/* @__PURE__ */ S("span", {
						className: "font-mono tabular-nums text-ink/60",
						children: s("games.burglebros.safeDice", { n: P.tiles[c.pos].dice })
					})
				] }) : /* @__PURE__ */ S("span", {
					className: "text-ink/60",
					children: s("games.burglebros.comboUnknown")
				}))
			})
		]
	}), fe = e.floors[c.floor].tiles[c.pos], z = fe.revealed && fe.def !== null ? k[fe.def - 300].kind : null, pe = D && c.floor === e.floors.length - 1 && z === "stairs" && e.decks.loot === 0 && !e.lootOnTile && !e.kitty, B = (e, t, n = !1, r = !1) => /* @__PURE__ */ S("button", {
		type: "button",
		disabled: r || !D,
		onClick: t,
		className: `burgle-action btn-base min-h-12 flex-none rounded-xl border-2 border-ink px-3 text-sm font-extrabold whitespace-nowrap disabled:opacity-40 ${n ? "bg-ink text-white" : "bg-white text-ink"}`,
		children: e
	}, e), me = /* @__PURE__ */ C("div", {
		className: "burgle-actions flex h-full items-center gap-2 overflow-x-auto px-2",
		children: [
			B(s("games.burglebros.actMove"), () => {
				p({ k: "move" }), b(null);
			}, f.k === "move"),
			B(s("games.burglebros.actPeek"), () => {
				p({ k: "peek" }), b(null);
			}, f.k === "peek"),
			B(s("games.burglebros.actHack"), () => a({ type: "hack" }), !1, z === null || !z.startsWith("computer")),
			B(s("games.burglebros.actAddDie"), () => a({ type: "addDie" }), !1, z !== "safe"),
			B(s("games.burglebros.actCrack"), () => a({ type: "crack" }), !1, z !== "safe"),
			B(s("games.burglebros.actTool"), () => b(v === "tool" ? null : "tool"), v === "tool", c.tools.length === 0),
			B(s("games.burglebros.actAbility"), () => b(v === "ability" ? null : "ability"), v === "ability"),
			B(s("games.burglebros.actGive"), () => b(v === "give" ? null : "give"), v === "give"),
			pe && B(s("games.burglebros.actEscape"), () => a({ type: "escape" })),
			B(s("games.burglebros.actEndTurn"), () => a({ type: "endTurn" }))
		]
	}), he = /* @__PURE__ */ C(x, { children: [
		v === "tool" && /* @__PURE__ */ S("div", {
			className: "card pointer-events-auto m-2 flex max-h-56 flex-col gap-1 overflow-y-auto p-2",
			children: c.tools.map((e) => /* @__PURE__ */ S("button", {
				type: "button",
				className: "btn-quiet min-h-11 rounded-lg border-2 border-ink bg-white px-2 text-left text-sm font-bold",
				onClick: () => {
					let t = [
						"crystalBall",
						"emp",
						"invisibleSuit",
						"makeupKit",
						"rollerskates",
						"smokeBomb",
						"thermalBomb"
					];
					if (e === "donuts") {
						a({
							type: "useTool",
							tool: e,
							floor: c.floor
						}), b(null);
						return;
					}
					if (t.includes(e)) {
						a({
							type: "useTool",
							tool: e
						}), b(null);
						return;
					}
					e !== "stethoscope" && (p({
						k: "tool",
						tool: e
					}), b(null));
				},
				children: s(Pt[e])
			}, e))
		}),
		v === "ability" && /* @__PURE__ */ S(Ht, {
			pub: e,
			me: c,
			onPick: (t, n) => {
				if (t === "disguise" || t === "orders") {
					if (!n) return;
					if (t === "disguise") {
						a({
							type: "ability",
							ability: "disguise",
							target: n
						}), b(null);
						return;
					}
					p({
						k: "ability",
						ability: t,
						target: n
					}), b(null);
					return;
				}
				if (t === "clairvoyance" || t === "precognition" || t === "tinker" || t === "reroutePickup" || t === "rerouteDrop") {
					a({
						type: "ability",
						ability: t
					}), b(null);
					return;
				}
				if (t === "climbWindow") {
					let t = c.floor + 1 < e.floors.length ? c.floor + 1 : c.floor - 1;
					t >= 0 && a({
						type: "ability",
						ability: "climbWindow",
						floor: t
					}), b(null);
					return;
				}
				p({
					k: "ability",
					ability: t
				}), b(null);
			},
			onClose: () => b(null)
		}),
		v === "give" && /* @__PURE__ */ S(Ut, {
			pub: e,
			me: c,
			myRid: r,
			nameOf: E,
			send: a,
			onClose: () => b(null)
		}),
		m && /* @__PURE__ */ S("div", {
			className: "card pointer-events-auto m-2 flex gap-2 p-2",
			children: m.map((e) => /* @__PURE__ */ S("button", {
				type: "button",
				className: "btn-base min-h-12 flex-1 rounded-xl border-2 border-ink bg-white px-2 text-sm font-extrabold",
				onClick: () => {
					a({
						type: "move",
						floor: e.floor,
						tile: e.tile,
						unsafe: e.unsafe
					}), h(null);
				},
				children: e.unsafe ? s("games.burglebros.actMoveUnsafe") : `${s("games.burglebros.actMove")} ×${e.cost}`
			}, String(e.unsafe)))
		}),
		A && A.by === r && t && /* @__PURE__ */ S(Kt, {
			pub: e,
			pend: A,
			priv: t,
			send: a
		}),
		w && /* @__PURE__ */ S(Wt, {
			pub: e,
			f: w.f,
			idx: w.idx,
			onClose: () => T(null)
		})
	] });
	return /* @__PURE__ */ S(_, {
		adaptive: !0,
		className: "burgle-screen",
		banner: ce,
		actions: me,
		actionsHeight: "burgle-action-slot h-16",
		overlay: /* @__PURE__ */ S("div", {
			className: "burgle-overlay",
			children: he
		}),
		scroll: !1,
		children: R
	});
}
function Bt(e, t) {
	switch (e) {
		case "entrance": return t("games.burglebros.entrancePrompt");
		case "peekhole": return t("games.burglebros.pendingPeekhole");
		case "goWithGut": return t("games.burglebros.pendingGoWithGut");
		case "throwVoice": return t("games.burglebros.pendingThrowVoice");
		case "buddySystem": return t("games.burglebros.pendingBuddySystem");
		case "crystalBall": return t("games.burglebros.pendingCrystalBall");
		case "toolDraw": return t("games.burglebros.pendingToolDraw");
		case "clairvoyance": return t("games.burglebros.pendingClairvoyance");
		case "precognition": return t("games.burglebros.pendingPrecognition");
		case "crackReroll": return t("games.burglebros.crackRerollPrompt");
	}
}
function Vt({ pub: e, f: t, idx: n, hl: r, myPos: i, onTap: a, colorOf: o, avatarOf: l }) {
	let d = u(), { ref: f } = c(`tile:${t}:${n}`), p = e.floors[t], m = p.tiles[n], h = e.size;
	if (p.blanks.includes(n)) return /* @__PURE__ */ S("div", {
		ref: f,
		className: "rounded-md bg-ink/10"
	});
	let g = m.revealed && m.def !== null ? k[m.def - 300] : null, ee = e.players.filter((e) => !e.escaped && e.floor === t && e.pos === n), _ = e.guards[t], y = _.active && _.pos === n, te = _.active && _.dest === n, b = p.walls.some(([e, t]) => e === n && t === n + 1 && n % h !== h - 1), w = p.walls.some(([e, t]) => e === n && t === n + h);
	return /* @__PURE__ */ C("button", {
		ref: f,
		type: "button",
		onClick: a,
		className: `burgle-tile relative flex min-h-11 flex-col items-center justify-center rounded-md border-2 p-0 text-[10px] leading-tight font-bold ${m.revealed ? "border-ink" : "border-ink/60"} ${m.alarm ? "ring-3 ring-rose-500" : ""} ${i ? "outline-2 outline-sky-600" : ""}`,
		style: {
			borderRightWidth: b ? 6 : void 0,
			borderBottomWidth: w ? 6 : void 0
		},
		children: [
			r && /* @__PURE__ */ S(v, { radius: 6 }),
			m.revealed && g ? /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S(kt, {
				kind: g.kind,
				num: g.num,
				white: g.white
			}), /* @__PURE__ */ S("span", {
				className: "pointer-events-none absolute inset-x-1 top-[26%] bottom-[26%] flex items-center justify-center text-center",
				children: /* @__PURE__ */ S("span", {
					className: "burgle-room-name rounded bg-white/75 px-1 font-display text-xs leading-tight font-extrabold text-ink",
					children: d(jt[g.kind])
				})
			})] }) : /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S(At, {}), /* @__PURE__ */ S("span", {
				className: "burgle-room-coordinate absolute inset-x-0 bottom-0.5 text-center font-mono text-[9px] font-bold tabular-nums text-white/90",
				children: Lt(n, h)
			})] }),
			/* @__PURE__ */ C("span", {
				className: "burgle-tile-markers pointer-events-none absolute top-0 left-0 flex gap-0.5 rounded-br-md bg-white/85 px-0.5 text-[9px]",
				children: [
					m.hacks > 0 && /* @__PURE__ */ C("span", { children: ["🖥", m.hacks] }),
					m.stealthPool > 0 && /* @__PURE__ */ C("span", { children: ["🫧", m.stealthPool] }),
					m.open && /* @__PURE__ */ S("span", { children: "🔓" }),
					m.cracked && /* @__PURE__ */ S("span", { children: "✅" }),
					!m.cracked && m.dice > 0 && /* @__PURE__ */ C("span", { children: ["🎲", m.dice] })
				]
			}),
			/* @__PURE__ */ C("span", {
				className: "burgle-tile-markers pointer-events-none absolute bottom-0 left-1/2 flex -translate-x-1/2 gap-0.5 rounded-t-md bg-white/85 px-0.5 text-[9px]",
				children: [
					m.stairsDown && /* @__PURE__ */ S("span", { children: "⬇️" }),
					m.thermal && /* @__PURE__ */ S("span", { children: "🟠" }),
					m.crow && /* @__PURE__ */ S("span", { children: "🐦‍⬛" }),
					m.crowbar && /* @__PURE__ */ S("span", { children: "🪓" }),
					e.kitty && e.kitty.floor === t && e.kitty.pos === n && /* @__PURE__ */ S("span", { children: "🐱" }),
					e.lootOnTile && e.lootOnTile.floor === t && e.lootOnTile.pos === n && /* @__PURE__ */ S("span", { children: "🧱" })
				]
			}),
			y && /* @__PURE__ */ S("span", {
				className: "burgle-guard-piece pointer-events-none absolute -top-1.5 -right-1.5 flex size-6 items-center justify-center rounded-full border-2 border-ink bg-ink text-sm leading-none",
				children: "💂"
			}),
			te && !y && /* @__PURE__ */ S("span", {
				className: "burgle-destination-piece pointer-events-none absolute -top-1 -right-1 flex size-5 items-center justify-center rounded-full border-2 border-ink bg-white text-[10px] leading-none",
				children: "🎯"
			}),
			ee.length > 0 && /* @__PURE__ */ S("span", {
				className: "pointer-events-none absolute -bottom-1.5 left-1/2 flex -translate-x-1/2 gap-0.5",
				children: ee.map((e) => /* @__PURE__ */ S("img", {
					src: s[l(e.rid) % s.length],
					alt: "",
					draggable: !1,
					className: "burgle-player-piece size-5 rounded-full border-2 object-contain",
					style: {
						borderColor: o(e.rid),
						backgroundColor: o(e.rid)
					}
				}, e.rid))
			})
		]
	});
}
function Ht({ pub: e, me: t, onPick: n, onClose: r }) {
	let i = u(), [a, s] = o(null), c = [], l = (e, t, n) => c.push({
		id: e,
		label: i(t),
		desc: i(n)
	});
	t.char === "rook" && t.side === "basic" && l("orders", "games.burglebros.abOrders", "games.burglebros.abOrdersDesc"), t.char === "rook" && t.side === "advanced" && l("disguise", "games.burglebros.abDisguise", "games.burglebros.abDisguiseDesc"), t.char === "spotter" && t.side === "basic" && l("clairvoyance", "games.burglebros.abClairvoyance", "games.burglebros.abClairvoyanceDesc"), t.char === "spotter" && t.side === "advanced" && l("precognition", "games.burglebros.abPrecognition", "games.burglebros.abPrecognitionDesc"), t.char === "hawk" && t.side === "basic" && l("xray", "games.burglebros.abXray", "games.burglebros.abXrayDesc"), t.char === "hawk" && t.side === "advanced" && l("xray", "games.burglebros.abEnhance", "games.burglebros.abEnhanceDesc"), t.char === "acrobat" && t.side === "advanced" && l("climbWindow", "games.burglebros.abClimbWindow", "games.burglebros.abClimbWindowDesc"), t.char === "juicer" && t.side === "basic" && l("crybaby", "games.burglebros.abCrybaby", "games.burglebros.abCrybabyDesc"), t.char === "juicer" && t.side === "advanced" && l(t.rerouteAlarm ? "rerouteDrop" : "reroutePickup", "games.burglebros.abReroute", "games.burglebros.abRerouteDesc"), t.char === "rigger" && t.side === "advanced" && l("tinker", "games.burglebros.abTinker", "games.burglebros.abTinkerDesc"), t.char === "raven" && t.side === "basic" && l("crow", "games.burglebros.abDistract", "games.burglebros.abDistractDesc"), t.char === "acrobat" && t.side === "basic" && l("flexibility", "games.burglebros.abFlexibility", "games.burglebros.abFlexibilityDesc"), t.char === "hacker" && t.side === "basic" && l("jammer", "games.burglebros.abJammer", "games.burglebros.abJammerDesc"), t.char === "hacker" && t.side === "advanced" && l("laptop", "games.burglebros.abLaptop", "games.burglebros.abLaptopDesc"), t.char === "peterman" && t.side === "basic" && l("steadyHands", "games.burglebros.abSteadyHands", "games.burglebros.abSteadyHandsDesc"), t.char === "peterman" && t.side === "advanced" && l("drill", "games.burglebros.abDrill", "games.burglebros.abDrillDesc"), t.char === "rigger" && t.side === "basic" && l("solution", "games.burglebros.abSolution", "games.burglebros.abSolutionDesc"), t.char === "raven" && t.side === "advanced" && l("disrupt", "games.burglebros.abDisrupt", "games.burglebros.abDisruptDesc");
	let d = /* @__PURE__ */ new Set([
		"flexibility",
		"jammer",
		"laptop",
		"steadyHands",
		"drill",
		"solution",
		"disrupt"
	]), f = /* @__PURE__ */ new Set(["orders", "disguise"]);
	return a ? /* @__PURE__ */ C("div", {
		className: "card pointer-events-auto m-2 flex flex-col gap-1 p-2",
		children: [e.players.filter((e) => !e.escaped && e.rid !== t.rid && (a !== "orders" || e.floor === t.floor)).map((e) => /* @__PURE__ */ S("button", {
			type: "button",
			className: "btn-quiet min-h-11 rounded-lg border-2 border-ink bg-white px-2 text-left text-sm font-bold",
			onClick: () => n(a, e.rid),
			children: i(It[e.char])
		}, e.rid)), /* @__PURE__ */ S("button", {
			type: "button",
			className: "btn-quiet min-h-11 text-sm",
			onClick: () => s(null),
			children: "←"
		})]
	}) : /* @__PURE__ */ C("div", {
		className: "card pointer-events-auto m-2 flex max-h-56 flex-col gap-1 overflow-y-auto p-2",
		children: [c.map((e) => /* @__PURE__ */ C("button", {
			type: "button",
			disabled: d.has(e.id),
			className: "btn-quiet min-h-11 rounded-lg border-2 border-ink bg-white px-2 text-left disabled:opacity-50",
			onClick: () => f.has(e.id) ? s(e.id) : n(e.id),
			children: [/* @__PURE__ */ S("span", {
				className: "block text-sm font-bold",
				children: e.label
			}), /* @__PURE__ */ S("span", {
				className: "block text-xs text-ink/60",
				children: e.desc
			})]
		}, e.id)), /* @__PURE__ */ S("button", {
			type: "button",
			className: "btn-quiet min-h-11 text-sm",
			onClick: r,
			children: "✕"
		})]
	});
}
function Ut({ pub: e, me: t, nameOf: n, send: r, onClose: i }) {
	let a = u(), o = e.players.filter((e) => !e.escaped && e.rid !== t.rid && e.floor === t.floor && e.pos === t.pos);
	return /* @__PURE__ */ C("div", {
		className: "card pointer-events-auto m-2 flex max-h-56 flex-col gap-1 overflow-y-auto p-2",
		children: [
			t.tools.map((e) => o.map((t) => /* @__PURE__ */ C("button", {
				type: "button",
				className: "btn-quiet min-h-11 rounded-lg border-2 border-ink bg-white px-2 text-left text-sm font-bold",
				onClick: () => {
					r({
						type: "give",
						kind: "tool",
						card: e,
						to: t.rid
					}), i();
				},
				children: [
					a(Pt[e]),
					" → ",
					n(t.rid)
				]
			}, `t${e}${t.rid}`))),
			t.loot.map((e) => o.map((t) => /* @__PURE__ */ C("button", {
				type: "button",
				className: "btn-quiet min-h-11 rounded-lg border-2 border-ink bg-white px-2 text-left text-sm font-bold",
				onClick: () => {
					r({
						type: "give",
						kind: "loot",
						card: e,
						to: t.rid
					}), i();
				},
				children: [
					a(Ft[e]),
					" → ",
					n(t.rid)
				]
			}, `l${e}${t.rid}`))),
			/* @__PURE__ */ S("button", {
				type: "button",
				className: "btn-quiet min-h-11 text-sm",
				onClick: i,
				children: "✕"
			})
		]
	});
}
function Wt({ pub: e, f: t, idx: n, onClose: r }) {
	let i = u(), a = e.floors[t].tiles[n], o = a.revealed && a.def !== null ? k[a.def - 300] : null;
	return /* @__PURE__ */ C("div", {
		className: "card pointer-events-auto m-2 flex items-start gap-2 p-2",
		children: [
			/* @__PURE__ */ S("span", {
				className: "relative block size-14 flex-none overflow-hidden rounded-md border-2 border-ink",
				children: o ? /* @__PURE__ */ S(kt, {
					kind: o.kind,
					num: o.num,
					white: o.white
				}) : /* @__PURE__ */ S(At, {})
			}),
			/* @__PURE__ */ C("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ C("div", {
						className: "text-sm font-extrabold",
						children: [o ? i(jt[o.kind]) : Lt(n, e.size), /* @__PURE__ */ S("span", {
							className: "ml-1 font-mono text-xs font-bold tabular-nums text-ink/50",
							children: Lt(n, e.size)
						})]
					}),
					/* @__PURE__ */ S("div", {
						className: "text-xs leading-snug text-ink/70",
						children: i(o ? Mt[o.kind] : "games.burglebros.tileUnrevealed")
					}),
					o && o.num > 0 && /* @__PURE__ */ S("div", {
						className: "text-xs text-ink/50",
						children: i("games.burglebros.tileNumInfo", { n: o.num })
					})
				]
			}),
			/* @__PURE__ */ S("button", {
				type: "button",
				"aria-label": i("common.close"),
				onClick: r,
				className: "btn-quiet flex-none rounded-lg p-1",
				children: /* @__PURE__ */ S(p, { className: "size-4" })
			})
		]
	});
}
var Gt = [
	"⚀",
	"⚁",
	"⚂",
	"⚃",
	"⚄",
	"⚅"
];
function Kt({ pub: e, pend: t, priv: n, send: r }) {
	let i = u(), [a, s] = o([]), [c, l] = o(null), [d, f] = o(null);
	if (t.k === "crystalBall" && n.crystalCards) {
		let e = n.crystalCards.filter((e) => !a.includes(e));
		return /* @__PURE__ */ C("div", {
			className: "card pointer-events-auto m-2 flex flex-col gap-1 p-2",
			children: [
				/* @__PURE__ */ S("div", {
					className: "text-xs text-ink/60",
					children: i("games.burglebros.pendingCrystalBall")
				}),
				/* @__PURE__ */ S("div", {
					className: "flex gap-1",
					children: a.map((e) => /* @__PURE__ */ S("span", {
						className: "rounded border border-ink bg-ink px-2 py-1 text-xs font-bold text-white",
						children: i(Nt[e])
					}, e))
				}),
				/* @__PURE__ */ S("div", {
					className: "flex flex-wrap gap-1",
					children: e.map((e) => /* @__PURE__ */ S("button", {
						type: "button",
						className: "btn-quiet min-h-11 rounded-lg border-2 border-ink bg-white px-2 text-sm font-bold",
						onClick: () => s([...a, e]),
						children: i(Nt[e])
					}, e))
				}),
				/* @__PURE__ */ S("button", {
					type: "button",
					disabled: a.length !== n.crystalCards.length,
					className: "btn-base min-h-12 rounded-xl border-2 border-ink bg-ink text-sm font-extrabold text-white disabled:opacity-40",
					onClick: () => r({
						type: "resolve",
						order: a
					}),
					children: i("games.burglebros.btnConfirm")
				})
			]
		});
	}
	return t.k === "toolDraw" && n.toolDrawCards ? /* @__PURE__ */ S("div", {
		className: "card pointer-events-auto m-2 flex gap-2 p-2",
		children: n.toolDrawCards.map((e) => /* @__PURE__ */ S("button", {
			type: "button",
			className: "btn-base min-h-12 flex-1 rounded-xl border-2 border-ink bg-white text-sm font-extrabold",
			onClick: () => r({
				type: "resolve",
				keep: e
			}),
			children: i(Pt[e])
		}, e))
	}) : t.k === "clairvoyance" && n.clairvoyanceCard !== null ? /* @__PURE__ */ C("div", {
		className: "card pointer-events-auto m-2 flex items-center gap-2 p-2",
		children: [
			/* @__PURE__ */ C("span", {
				className: "flex-1 text-sm font-bold",
				children: ["🎯 ", Lt(n.clairvoyanceCard, e.size)]
			}),
			/* @__PURE__ */ S("button", {
				type: "button",
				className: "btn-base min-h-12 rounded-xl border-2 border-ink bg-white px-3 text-sm font-extrabold",
				onClick: () => r({
					type: "resolve",
					bottom: !1
				}),
				children: i("games.burglebros.btnKeepTop")
			}),
			/* @__PURE__ */ S("button", {
				type: "button",
				className: "btn-base min-h-12 rounded-xl border-2 border-ink bg-white px-3 text-sm font-extrabold",
				onClick: () => r({
					type: "resolve",
					bottom: !0
				}),
				children: i("games.burglebros.btnBottom")
			})
		]
	}) : t.k === "precognition" && n.precognitionCard ? /* @__PURE__ */ C("div", {
		className: "card pointer-events-auto m-2 flex items-center gap-2 p-2",
		children: [
			/* @__PURE__ */ S("span", {
				className: "flex-1 text-sm font-bold",
				children: i(Nt[n.precognitionCard])
			}),
			/* @__PURE__ */ S("button", {
				type: "button",
				className: "btn-base min-h-12 rounded-xl border-2 border-ink bg-white px-3 text-sm font-extrabold",
				onClick: () => r({
					type: "resolve",
					bottom: !1
				}),
				children: i("games.burglebros.btnKeepTop")
			}),
			/* @__PURE__ */ S("button", {
				type: "button",
				className: "btn-base min-h-12 rounded-xl border-2 border-ink bg-white px-3 text-sm font-extrabold",
				onClick: () => r({
					type: "resolve",
					bottom: !0
				}),
				children: i("games.burglebros.btnBottom")
			})
		]
	}) : t.k === "buddySystem" ? /* @__PURE__ */ S("div", {
		className: "card pointer-events-auto m-2 flex flex-col gap-1 p-2",
		children: e.players.filter((e) => !e.escaped && e.rid !== t.by).map((e) => /* @__PURE__ */ S("button", {
			type: "button",
			className: "btn-quiet min-h-11 rounded-lg border-2 border-ink bg-white px-2 text-left text-sm font-bold",
			onClick: () => r({
				type: "resolve",
				target: e.rid
			}),
			children: i(It[e.char])
		}, e.rid))
	}) : t.k === "crackReroll" && t.dice ? /* @__PURE__ */ C("div", {
		className: "card pointer-events-auto m-2 flex flex-col gap-1 p-2",
		children: [
			/* @__PURE__ */ S("div", {
				className: "flex gap-1",
				children: t.dice.map((e, t) => /* @__PURE__ */ S("button", {
					type: "button",
					onClick: () => l(t),
					className: `min-h-11 rounded-lg border-2 border-ink px-2 text-xl ${c === t ? "bg-ink text-white" : "bg-white"}`,
					children: Gt[e - 1]
				}, t))
			}),
			c !== null && /* @__PURE__ */ S("div", {
				className: "flex gap-1",
				children: [
					1,
					2,
					3,
					4,
					5,
					6
				].map((e) => /* @__PURE__ */ S("button", {
					type: "button",
					onClick: () => f(e),
					className: `min-h-11 rounded-lg border-2 border-ink px-2 text-xl ${d === e ? "bg-ink text-white" : "bg-white"}`,
					children: Gt[e - 1]
				}, e))
			}),
			/* @__PURE__ */ C("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ S("button", {
					type: "button",
					disabled: c === null || d === null,
					className: "btn-base min-h-12 flex-1 rounded-xl border-2 border-ink bg-ink text-sm font-extrabold text-white disabled:opacity-40",
					onClick: () => r({
						type: "resolve",
						die: c,
						face: d
					}),
					children: i("games.burglebros.btnConfirm")
				}), /* @__PURE__ */ S("button", {
					type: "button",
					className: "btn-base min-h-12 flex-1 rounded-xl border-2 border-ink bg-white text-sm font-extrabold",
					onClick: () => r({ type: "resolve" }),
					children: i("games.burglebros.crackRerollKeep")
				})]
			})
		]
	}) : t.k === "peekhole" ? /* @__PURE__ */ S("div", {
		className: "card pointer-events-auto m-2 p-2",
		children: /* @__PURE__ */ S("button", {
			type: "button",
			className: "btn-base min-h-12 w-full rounded-xl border-2 border-ink bg-white text-sm font-extrabold",
			onClick: () => r({ type: "resolve" }),
			children: i("games.burglebros.btnSkip")
		})
	}) : null;
}
//#endregion
//#region src/games/burglebros/bot.ts
function Q(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var qt = (e, t, n) => {
	let r = e.floors[t].tiles[n];
	return r.revealed && r.def !== null ? k[r.def - 300] : null;
};
function Jt(e, t) {
	let n = /* @__PURE__ */ new Set(), r = e.floors[t];
	return r.tiles.forEach((i, a) => {
		if (qt(e, t, a)?.kind === "safe" && !i.cracked) {
			let t = a % e.size, i = Math.floor(a / e.size);
			for (let a = 0; a < e.size; a++) for (let o of [i * e.size + a, a * e.size + t]) !r.tiles[o].revealed && !r.blanks.includes(o) && n.add(o);
		}
	}), n;
}
function Yt(e, t, n, r) {
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Set([n]), o = [n];
	for (; o.length;) {
		let s = o.shift();
		if (s !== n && r(s)) {
			let e = s;
			for (; i.get(e) !== n;) e = i.get(e);
			return e;
		}
		for (let n of we(e, t, s)) a.has(n) || (a.add(n), i.set(n, s), o.push(n));
	}
	return null;
}
function Xt(e, t, n) {
	let r = e.size, i = e.floors[t].blanks, a = n % r, o = Math.floor(n / r);
	for (let n = 0; n < r; n++) for (let s of [o * r + n, n * r + a]) if (!i.includes(s) && !e.floors[t].tiles[s].revealed) return !1;
	return !0;
}
function Zt(e, t, n) {
	let r = e.size, i = e.floors[t].blanks, a = n % r, o = Math.floor(n / r), s = /* @__PURE__ */ new Set();
	for (let n = 0; n < r; n++) for (let c of [o * r + n, n * r + a]) {
		if (i.includes(c)) continue;
		let n = e.floors[t].tiles[c];
		if (!n.revealed || n.def === null) continue;
		let r = k[n.def - 300].num;
		r > 0 && s.add(r);
	}
	return [...s].filter((r) => !e.floors[t].tiles[n].crackedNums.includes(r));
}
var Qt = (e, t) => {
	let n = e.public, r = e.private, i = n.players.find((e) => e.rid === t.rid);
	if (!i || i.escaped || n.phase === "won" || n.phase === "lost") return null;
	let a = n.pending;
	if (a) {
		if (a.by !== t.rid) return null;
		switch (a.k) {
			case "entrance": {
				let e = n.floors[0].tiles.map((e, t) => ({
					t: e,
					i: t
				})).filter(({ t: e, i: t }) => !e.revealed && e.def === null && !n.floors[0].blanks.includes(t));
				return e.length ? { action: {
					type: "resolve",
					tile: Q(e).i
				} } : null;
			}
			case "peekhole": {
				if (t.difficulty === "weak") return { action: { type: "resolve" } };
				let e = [];
				return n.floors.forEach((t, n) => t.tiles.forEach((r, i) => {
					!r.revealed && !t.blanks.includes(i) && e.push({
						floor: n,
						tile: i
					});
				})), e.length ? { action: {
					type: "resolve",
					...Q(e)
				} } : { action: { type: "resolve" } };
			}
			case "goWithGut": {
				let e = we(n, i.floor, i.pos).filter((e) => !n.floors[i.floor].tiles[e].revealed);
				return e.length ? { action: {
					type: "resolve",
					tile: Q(e)
				} } : null;
			}
			case "throwVoice": {
				let e = n.guards[i.floor], t = we(n, i.floor, e.dest);
				return t.length ? { action: {
					type: "resolve",
					tile: Q(t)
				} } : { action: {
					type: "resolve",
					tile: e.dest
				} };
			}
			case "buddySystem": {
				let e = n.players.filter((e) => e.rid !== t.rid && !e.escaped);
				return e.length ? { action: {
					type: "resolve",
					target: Q(e).rid
				} } : null;
			}
			case "crystalBall": return r?.crystalCards ? { action: {
				type: "resolve",
				order: r.crystalCards
			} } : null;
			case "toolDraw": return r?.toolDrawCards?.length ? { action: {
				type: "resolve",
				keep: r.toolDrawCards[0]
			} } : null;
			case "clairvoyance":
			case "precognition": return { action: {
				type: "resolve",
				bottom: !1
			} };
			case "crackReroll": {
				if (!a.dice || a.floor === void 0) return { action: { type: "resolve" } };
				let e = n.floors[a.floor].tiles.find((e) => e.revealed && e.dice > 0 && !e.cracked);
				if (!e) return { action: { type: "resolve" } };
				let t = n.floors[a.floor].tiles.indexOf(e), r = Zt(n, a.floor, t).filter((e) => e >= 1 && e <= 6);
				for (let e = 0; e < a.dice.length; e++) {
					let t = a.dice[e];
					if (!r.includes(t) && r.length) return { action: {
						type: "resolve",
						die: e,
						face: r[0]
					} };
				}
				return { action: { type: "resolve" } };
			}
		}
	}
	if (n.phase !== "play" || n.players[n.turn.seat]?.rid !== t.rid) return null;
	let o = n.turn.actionsLeft;
	if (o <= 0) return { action: { type: "endTurn" } };
	let s = Te(n, t.rid), c = Ee(n, t.rid);
	if (t.difficulty === "weak") {
		let e = [{ type: "endTurn" }];
		c.length && e.push({
			type: "peek",
			...Q(c)
		});
		let t = s.filter((e) => e.cost <= o);
		return t.length && e.push({
			type: "move",
			floor: t[0].floor,
			tile: t[0].tile,
			unsafe: t[0].unsafe
		}), { action: Q(e) };
	}
	let l = qt(n, i.floor, i.pos);
	if (i.floor === n.floors.length - 1 && l?.kind === "stairs" && n.decks.loot === 0 && !n.lootOnTile && !n.kitty) return { action: { type: "escape" } };
	if (l?.kind === "safe") {
		let e = n.floors[i.floor].tiles[i.pos];
		if (!e.cracked && Xt(n, i.floor, i.pos)) {
			let t = Zt(n, i.floor, i.pos);
			if (t.length > 0) {
				if (e.dice >= t.length && e.dice > 0) return { action: { type: "crack" } };
				if (o >= 2 && e.dice < 6) return { action: { type: "addDie" } };
				if (e.dice > 0) return { action: { type: "crack" } };
			}
		}
	}
	if (l && l.kind.startsWith("computer") && n.floors[i.floor].tiles[i.pos].hacks < 6) return { action: { type: "hack" } };
	let u = n.guards[i.floor], d = s.filter((e) => e.cost <= o && !e.unsafe && e.entering && !(u.active && e.floor === i.floor && e.tile === u.pos && i.stealth <= 1)), f = Jt(n, i.floor), p = c.find((e) => e.floor === i.floor && f.has(e.tile));
	if (p) return { action: {
		type: "peek",
		floor: p.floor,
		tile: p.tile
	} };
	if (d.length) {
		let e = d.filter((e) => e.floor === i.floor && (f.has(e.tile) || qt(n, e.floor, e.tile)?.kind === "safe" && !n.floors[e.floor].tiles[e.tile].cracked));
		if (e.length) {
			let t = Q(e);
			return { action: {
				type: "move",
				floor: t.floor,
				tile: t.tile
			} };
		}
		let t = f.size ? Yt(n, i.floor, i.pos, (e) => f.has(e) || qt(n, i.floor, e)?.kind === "safe" && !n.floors[i.floor].tiles[e].cracked ? !0 : we(n, i.floor, e).some((e) => f.has(e))) : null;
		if (t !== null) {
			let e = d.find((e) => e.floor === i.floor && e.tile === t);
			if (e) return { action: {
				type: "move",
				floor: e.floor,
				tile: e.tile
			} };
		}
		if (f.size === 0) {
			let e = d.find((e) => e.floor > i.floor);
			if (e) return { action: {
				type: "move",
				floor: e.floor,
				tile: e.tile
			} };
			let t = n.floors[i.floor].tiles.findIndex((e, t) => e.revealed && qt(n, i.floor, t)?.kind === "stairs");
			if (t >= 0) {
				let e = Yt(n, i.floor, i.pos, (e) => e === t);
				if (e !== null) {
					let t = d.find((t) => t.floor === i.floor && t.tile === e);
					if (t) return { action: {
						type: "move",
						floor: t.floor,
						tile: t.tile
					} };
				}
			}
			let r = c.find((e) => e.floor === i.floor);
			if (r) return { action: {
				type: "peek",
				floor: r.floor,
				tile: r.tile
			} };
			let a = d.find((e) => e.floor === i.floor && !n.floors[e.floor].tiles[e.tile].revealed);
			if (a) return { action: {
				type: "move",
				floor: a.floor,
				tile: a.tile
			} };
			let o = Yt(n, i.floor, i.pos, (e) => !n.floors[i.floor].tiles[e].revealed);
			if (o !== null) {
				let e = d.find((e) => e.floor === i.floor && e.tile === o);
				if (e) return { action: {
					type: "move",
					floor: e.floor,
					tile: e.tile
				} };
			}
		}
		let r = Q(d);
		return { action: {
			type: "move",
			floor: r.floor,
			tile: r.tile
		} };
	}
	if (c.length) {
		let e = Q(c);
		return { action: {
			type: "peek",
			floor: e.floor,
			tile: e.tile
		} };
	}
	return { action: { type: "endTurn" } };
};
//#endregion
//#region src/games/burglebros/fx.tsx
function $(e, t, n = "tile") {
	let r = t, i = r[n];
	return typeof r.floor == "number" && typeof i == "number" ? e.anchor(`tile:${r.floor}:${i}`) : null;
}
var $t = (e, t) => t ? e.anchor(`seat:${t}`) : null, en = {
	reveal(e, t) {
		let n = $(t, e.data);
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ S(E, {
				at: n,
				ms: 600
			})
		} : null;
	},
	move(e, t) {
		let n = $(t, e.data);
		return n ? {
			ms: 350,
			node: /* @__PURE__ */ S(E, {
				at: n,
				ms: 350
			})
		} : null;
	},
	fall(e, t) {
		let n = $(t, e.data);
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ S("span", {
					className: "text-lg",
					children: "⬇️"
				})
			})
		} : null;
	},
	alarm(e, t) {
		let n = $(t, e.data);
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S(E, {
				at: n,
				ms: 900
			}), /* @__PURE__ */ S(T, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ S("span", {
					className: "text-lg",
					children: "🚨"
				})
			})] })
		} : null;
	},
	alarmCancel(e, t) {
		let n = $(t, e.data);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ S("span", {
					className: "text-base",
					children: "🖥️✕"
				})
			})
		} : null;
	},
	alarmOff(e, t) {
		let n = $(t, e.data);
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 600,
				children: /* @__PURE__ */ S("span", {
					className: "text-base",
					children: "🔕"
				})
			})
		} : null;
	},
	guardDeploy(e, t) {
		let n = $(t, e.data, "pos");
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ S(E, {
				at: n,
				ms: 800
			})
		} : null;
	},
	guardStep(e, t) {
		let n = $(t, e.data, "to");
		return n ? {
			ms: 420,
			node: /* @__PURE__ */ S(E, {
				at: n,
				ms: 420
			})
		} : null;
	},
	stealth(e, t) {
		let n = $t(t, e.rid);
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ S("span", {
					className: "text-base font-extrabold text-rose-600",
					children: "-1🥷"
				})
			})
		} : null;
	},
	caught(e, t) {
		let n = $t(t, e.rid);
		return {
			ms: 1100,
			node: /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S(w, { ms: 800 }), n && /* @__PURE__ */ S(T, {
				at: n,
				ms: 1e3,
				children: /* @__PURE__ */ S("span", {
					className: "text-xl",
					children: "💥"
				})
			})] })
		};
	},
	hack(e, t) {
		let n = $(t, e.data);
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 600,
				children: /* @__PURE__ */ S("span", {
					className: "text-base",
					children: "🖥️"
				})
			})
		} : null;
	},
	addDie(e, t) {
		let n = $(t, e.data);
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 500,
				children: /* @__PURE__ */ S("span", {
					className: "text-base",
					children: "🎲+1"
				})
			})
		} : null;
	},
	crack(e, t) {
		let n = $(t, e.data), r = e.data?.dice ?? [];
		if (!n) return null;
		let i = [
			"⚀",
			"⚁",
			"⚂",
			"⚃",
			"⚄",
			"⚅"
		];
		return {
			ms: 1100,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 1100,
				children: /* @__PURE__ */ S("span", {
					className: "text-base",
					children: r.map((e) => i[e - 1]).join(" ")
				})
			})
		};
	},
	cracked(e, t) {
		let n = $(t, e.data);
		return {
			ms: 1200,
			node: /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S(w, {
				ms: 800,
				className: "bg-done"
			}), n && /* @__PURE__ */ S(T, {
				at: n,
				ms: 1100,
				children: /* @__PURE__ */ S("span", {
					className: "text-lg",
					children: "✅💰"
				})
			})] })
		};
	},
	keypadFail(e, t) {
		let n = $(t, e.data);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ S("span", {
					className: "text-base",
					children: "🔢✕"
				})
			})
		} : null;
	},
	tool(e, t) {
		let n = $t(t, e.rid);
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ S("span", {
					className: "text-base",
					children: "🧰+1"
				})
			})
		} : null;
	},
	loot(e, t) {
		let n = $t(t, e.rid);
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ S("span", {
					className: "text-base",
					children: "💎+1"
				})
			})
		} : null;
	},
	useTool(e, t) {
		let n = $t(t, e.rid);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ S("span", {
					className: "text-base",
					children: "🧰"
				})
			})
		} : null;
	},
	event(e, t) {
		let n = $t(t, e.rid);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ S(T, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ S("span", {
					className: "text-base",
					children: "🃏"
				})
			})
		} : null;
	},
	escape(e, t) {
		let n = $t(t, e.rid);
		return {
			ms: 1100,
			node: /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S(w, {
				ms: 700,
				className: "bg-done"
			}), n && /* @__PURE__ */ S(T, {
				at: n,
				ms: 1e3,
				children: /* @__PURE__ */ S("span", {
					className: "text-lg",
					children: "🏃‍➡️"
				})
			})] })
		};
	}
};
//#endregion
//#region src/games/burglebros/endgame-review.tsx
function tn({ board: e, renderResult: t, ...n }) {
	let s = u(), [c, l] = o(!0), [f, p] = o(null), g = a(null), ee = a(null), _ = a(null);
	r(() => {
		if (!f) return;
		_.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => p(null), 5e3);
		return () => clearTimeout(e);
	}, [f]);
	let v = (e) => {
		p(null), l(e), requestAnimationFrame(() => (e ? g : ee).current?.focus({ preventScroll: !0 }));
	}, y = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => p({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => p({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => p({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), te = {
		...n,
		...y
	};
	return /* @__PURE__ */ C("div", {
		className: "burglebros-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ S("div", {
				className: "burglebros-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ S("div", {
				className: "burglebros-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ C("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), v(!1));
					},
					className: "burglebros-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ C("header", {
							className: "burglebros-endgame-heading",
							children: [/* @__PURE__ */ C("div", {
								className: "burglebros-endgame-brand",
								children: [/* @__PURE__ */ S("span", {
									"aria-hidden": "true",
									children: I.icon
								}), s(I.nameKey)]
							}), /* @__PURE__ */ S("button", {
								type: "button",
								ref: g,
								className: "btn-quiet",
								"aria-label": s("games.burglebros.reviewHide"),
								title: s("games.burglebros.reviewHide"),
								onClick: () => v(!1),
								children: /* @__PURE__ */ S(m, { size: 19 })
							})]
						}),
						/* @__PURE__ */ S("div", {
							className: "burglebros-endgame-result",
							inert: f !== null,
							children: t(te)
						}),
						f && /* @__PURE__ */ C("div", {
							className: "burglebros-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || p(null);
							},
							children: [/* @__PURE__ */ S("button", {
								type: "button",
								ref: _,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = f.run;
									p(null), e();
								},
								children: s(f.label === "again" ? "games.burglebros.reviewConfirmAgain" : "games.burglebros.reviewConfirmLobby")
							}), /* @__PURE__ */ S("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									p(null), g.current?.focus({ preventScroll: !0 });
								},
								children: s("games.burglebros.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ S("div", {
				className: "burglebros-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ C("button", {
					type: "button",
					className: "btn-base",
					ref: ee,
					onClick: () => v(!0),
					children: [
						/* @__PURE__ */ S(h, { size: 18 }),
						s("games.burglebros.reviewShow"),
						/* @__PURE__ */ S(d, { size: 18 })
					]
				})
			})
		]
	});
}
function nn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: c, renderRowExtra: d, summary: p, navigation: h, content: g, afterRanking: ee, scoreUnit: _, rankOf: v }) {
	let y = u(), te = l((e) => e.locale), [w, T] = o({}), E = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? b(n, te) : e;
	}, re = (t, n) => v?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), D = e.ranking.some((t) => e.scores?.[t] !== void 0), O = (t, n) => /* @__PURE__ */ C("div", {
		className: "burglebros-score-identity",
		children: [
			/* @__PURE__ */ C("span", {
				className: "burglebros-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ S("span", {
					"aria-label": y("games.burglebros.reviewWinner"),
					children: "♛ "
				}), D && re(t, n)]
			}),
			/* @__PURE__ */ C("span", {
				className: "burglebros-score-name",
				children: [E(t), t === r && /* @__PURE__ */ S("small", { children: y("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ C("small", {
				className: "burglebros-score-autopilot",
				children: [
					/* @__PURE__ */ S(f, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), k = (t) => e.ranking.map((n) => /* @__PURE__ */ S("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ C("div", {
		className: "burglebros-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ S(ne, {}),
			h,
			/* @__PURE__ */ C("div", {
				className: "burglebros-score-body",
				children: [
					p && /* @__PURE__ */ S("div", {
						className: "burglebros-score-summary",
						children: p
					}),
					i !== void 0 && /* @__PURE__ */ S("p", {
						className: "burglebros-score-hints",
						children: y("session.hint.usedCount", { n: i })
					}),
					g ?? (c?.length ? /* @__PURE__ */ S("div", {
						className: "burglebros-score-table-scroll",
						children: /* @__PURE__ */ C("table", {
							className: "burglebros-score-table",
							"aria-label": y(I.nameKey),
							children: [
								/* @__PURE__ */ S("thead", { children: /* @__PURE__ */ C("tr", { children: [/* @__PURE__ */ S("th", { scope: "col" }), /* @__PURE__ */ S(x, { children: e.ranking.map((t, n) => /* @__PURE__ */ S("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: O(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ S("tbody", { children: c.map((e, t) => /* @__PURE__ */ C(n, { children: [/* @__PURE__ */ C("tr", { children: [/* @__PURE__ */ S("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ C("button", {
										type: "button",
										"aria-expanded": !!w[t],
										onClick: () => T((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ S(m, { size: 15 }), e.label]
									}) : e.label
								}), k(e)] }), w[t] && e.details?.map((e, t) => /* @__PURE__ */ C("tr", {
									className: "burglebros-score-sub",
									children: [/* @__PURE__ */ S("th", {
										scope: "row",
										children: e.label
									}), k(e)]
								}, t))] }, t)) }),
								D && /* @__PURE__ */ S("tfoot", { children: /* @__PURE__ */ C("tr", { children: [/* @__PURE__ */ S("th", {
									scope: "row",
									children: y("games.burglebros.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ S("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ S("ol", {
						className: "burglebros-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ C("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ C("div", {
								className: "burglebros-score-rankline",
								children: [O(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ C("strong", {
									className: "burglebros-score-points",
									children: [e.scores[t], _ && /* @__PURE__ */ S("small", { children: _ })]
								})]
							}), d?.(t)]
						}, t))
					})),
					ee,
					!!c?.length && d && /* @__PURE__ */ S("div", {
						className: "burglebros-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ C("details", { children: [/* @__PURE__ */ S("summary", { children: E(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ C("footer", {
				className: "burglebros-score-actions",
				children: [
					s && /* @__PURE__ */ S("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: y("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ S("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: y("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ S("p", { children: y("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/burglebros/game-over.tsx
function rn({ result: e, members: t, myRid: n, onPlayAgain: r, onBackToLobby: i, hintCount: a }) {
	return /* @__PURE__ */ S(nn, {
		result: e,
		members: t,
		myRid: n,
		accent: I.accent,
		onPlayAgain: r,
		onBackToLobby: i,
		hintCount: a
	});
}
function an(e) {
	return /* @__PURE__ */ S(tn, {
		...e,
		board: /* @__PURE__ */ S(Rt, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ S(rn, { ...e })
	});
}
//#endregion
//#region src/games/burglebros/options.tsx
var on = {
	office: "games.burglebros.scenarioOffice",
	bank: "games.burglebros.scenarioBank",
	fortknox: "games.burglebros.scenarioFortknox"
}, sn = {
	basic: "games.burglebros.charsBasic",
	advanced: "games.burglebros.charsAdvanced",
	mixed: "games.burglebros.charsMixed"
};
function cn({ value: e, onChange: t }) {
	let n = u(), r = B.safeParse(e), i = r.success ? r.data : B.parse(void 0);
	return /* @__PURE__ */ C("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ S(D, {
			title: n("games.burglebros.optScenario"),
			columns: 3,
			children: Object.keys(on).map((e) => /* @__PURE__ */ S(re, {
				name: "burglebros-scenario",
				value: e,
				checked: i.scenario === e,
				label: n(on[e]),
				accent: I.accent,
				onChange: () => t({
					...i,
					scenario: e
				})
			}, e))
		}), /* @__PURE__ */ S(D, {
			title: n("games.burglebros.optChars"),
			columns: 3,
			children: Object.keys(sn).map((e) => /* @__PURE__ */ S(re, {
				name: "burglebros-chars",
				value: e,
				checked: i.chars === e,
				label: n(sn[e]),
				accent: I.accent,
				onChange: () => t({
					...i,
					chars: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/burglebros/entry.tsx
var ln = {
	definition: Ct,
	View: Rt,
	bot: Qt,
	fx: en,
	OverView: an,
	Options: cn,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "神偷拍档",
			desc: "合作潜入大楼:躲开巡逻守卫,撬开所有保险箱,带着战利品从屋顶逃脱",
			rules: "目标:合作撬开所有保险箱并集齐战利品,全员从顶层楼梯登上屋顶;任何人隐身耗尽被抓,全队立即失败。\n回合:每回合有四点行动,自由组合下列动作——\n· 侦察(一点):翻开一个相邻房间,全员可见。\n· 移动(一点):走进相邻房间;走进未翻开的房间会当场翻开。\n· 黑客(一点):在电脑房放置一枚黑客标记,可抵消同类型警报。\n· 加骰(两点):为所在的保险箱增加一颗骰子。\n· 撬箱(一点):掷出保险箱上的全部骰子,盖住组合数字。\n门槛:进入没有其他玩家的死门房需要花费3点行动；进入激光房需要花费2点行动,否则触发警报;密码盘房要掷出六才能进入。\n破解:保险箱的整行整列全部翻开后才可知组合;覆盖全部组合数字后，保险箱才算破解。\n收获:每破解一个保险箱抽一张工具卡和一张战利品卡;本层与下层的守卫从此永久加速。\n事件:本回合花费不超过两点行动时,回合结束抽一张事件卡。\n守卫:回合结束时所在层的守卫朝目的地移动,步数等于掷出的骰子点数加上响着的警报数;与守卫位于同一格时，交出1枚隐身标记。\n特殊:楼梯通往上一层;两条通风管都翻开后可以互通。\n坠落:走进未翻开的天台走道会坠落一层;在热感房结束回合会触发警报。\n提示:点击当前不可选择的房间可查看它的说明。",
			scenarioOffice: "办公楼(2 层)",
			scenarioBank: "银行(3 层)",
			scenarioFortknox: "诺克斯堡(2 层大楼面)",
			optScenario: "场景",
			optChars: "角色面",
			charsBasic: "基本",
			charsAdvanced: "进阶",
			charsMixed: "随机",
			floorLabel: "F{{n}}",
			turnBanner: "轮到你:剩 {{n}} 点行动",
			waitBanner: "等待 {name} 行动…",
			guardBanner: "守卫巡逻中…",
			entrancePrompt: "选择破入位置(首格)",
			entranceWaiting: "等待 {name} 选择破入位置…",
			stealthLabel: "隐身",
			guardDest: "目的地",
			patrolLeft: "巡逻牌 {{n}}",
			safeDice: "骰 {{n}}",
			hackTokens: "黑客标记 {{n}}",
			poolLabel: "池 {{n}}",
			comboReady: "组合已知",
			comboUnknown: "组合未知",
			lootProgress: "战利品 {{n}}/13",
			kittyOut: "猫跑了!捡到才能赢",
			effTimeLock: "定时锁:禁走楼梯",
			effEmp: "EMP:警报静默",
			effVideoLoop: "循环录像:摄像头失效",
			effGymnastics: "体操:走道可上行",
			escapedMark: "已逃脱",
			actPeek: "侦察",
			actMove: "移动",
			actMoveUnsafe: "硬闯(触发警报)",
			actHack: "黑客",
			actAddDie: "加骰(2)",
			actCrack: "撬箱",
			actEndTurn: "结束回合",
			actEscape: "上屋顶逃脱",
			actGive: "转交",
			actTool: "工具",
			actAbility: "能力",
			crackRerollPrompt: "听诊器:可把 1 颗骰子改成任意面",
			crackRerollKeep: "保持原样",
			pendingPeekhole: "窥孔:翻开任意一格(可放弃)",
			pendingGoWithGut: "跟直觉走:必须走进相邻的一间未翻开房间",
			pendingThrowVoice: "腹语:把目的地骰移到相邻格",
			pendingBuddySystem: "结伴系统:选一名队友拉到你身边",
			pendingCrystalBall: "水晶球:重排事件堆顶 3 张(点按顺序=从顶到底)",
			pendingToolDraw: "机关解:抽 2 张工具卡,留下其中 1 张",
			pendingClairvoyance: "千里眼:巡逻堆顶是此格,是否置底?",
			pendingPrecognition: "预感:事件堆顶如下,是否置底?",
			pendingWait: "等待 {name} 决定…",
			btnBottom: "置底",
			btnKeepTop: "保留",
			btnSkip: "放弃",
			btnConfirm: "确定",
			tileSafe: "保险箱",
			tileStairs: "楼梯",
			tileWalkway: "天台走道",
			tileLaboratory: "实验室",
			tileLavatory: "厕所",
			tileServiceDuct: "通风管",
			tileSecretDoor: "暗门",
			tileComputerFp: "电脑房·指纹",
			tileComputerLaser: "电脑房·激光",
			tileComputerMotion: "电脑房·动态",
			tileCamera: "摄像头",
			tileLaser: "激光",
			tileMotion: "动态感应",
			tileDetector: "探测器",
			tileFingerprint: "指纹锁",
			tileThermo: "热感",
			tileKeypad: "密码盘",
			tileDeadbolt: "死门",
			tileFoyer: "门厅",
			tileAtrium: "中庭",
			tileDescSafe: "花两点行动加一颗骰子,花一点行动掷出全部骰子;整行整列翻开后可知组合,盖齐数字即破解。",
			tileDescStairs: "可移动或侦察上一层楼;全员经顶层楼梯登上屋顶即获胜。",
			tileDescWalkway: "若因移动进入而翻开,会坠落到下一层。",
			tileDescLaboratory: "第一个进入的玩家抽一张工具卡。",
			tileDescLavatory: "翻开时放置三枚隐身标记,藏身此处的玩家可以取用。",
			tileDescServiceDuct: "两条通风管都翻开后,可在两者之间直接移动。",
			tileDescSecretDoor: "可以穿墙进入此房间。",
			tileDescComputerFp: "可在此放置黑客标记,抵消任意楼层的指纹警报。",
			tileDescComputerLaser: "可在此放置黑客标记,抵消任意楼层的激光警报。",
			tileDescComputerMotion: "可在此放置黑客标记,抵消任意楼层的动态感应警报。",
			tileDescCamera: "守卫在任何摄像头格时,进入此处会触发警报。",
			tileDescLaser: "进入需花两点行动,否则触发警报。",
			tileDescMotion: "进入后必须停在此处,再移动会触发警报。",
			tileDescDetector: "持有工具或战利品时进入会触发警报。",
			tileDescFingerprint: "进入即触发警报。",
			tileDescThermo: "在此处结束回合会触发警报。",
			tileDescKeypad: "进入需掷骰开门,掷出六即开;同一回合每次重试多加一颗骰。",
			tileDescDeadbolt: "无人停留时需花三点行动进入。",
			tileDescFoyer: "守卫经过相邻格时能看到这里,会交出隐身。",
			tileDescAtrium: "守卫在正上方或正下方同列位置时能看到这里;可侦察上一层或下一层。",
			tileNumInfo: "右下数字圈:保险箱组合数字 {{n}}",
			tileUnrevealed: "未翻开的房间。移动进入或侦察可翻开。",
			evPeekhole: "窥孔",
			evDeadDrop: "死信箱",
			evLampshade: "灯罩",
			evSwitchSigns: "调换指示牌",
			evHeadsUp: "通风报信",
			evGymnastics: "体操",
			evChangeOfPlans: "改变计划",
			evGoWithGut: "跟直觉走",
			evBrownOut: "停电",
			evCrash: "巨响",
			evEspresso: "浓缩咖啡",
			evReboot: "重启",
			evSqueak: "吱呀声",
			evShiftChange: "换班",
			evBuddySystem: "结伴系统",
			evFreightElevator: "货梯",
			evKeycodeChange: "改密码",
			evJumpTheGun: "抢跑",
			evDaydreaming: "白日梦",
			evJuryRig: "临时拼凑",
			evTimeLock: "定时锁",
			evLostGrip: "失手",
			evWhereIsHe: "他在哪?",
			evShoplifting: "顺手牵羊",
			evThrowVoice: "腹语",
			evVideoLoop: "循环录像",
			toolBlueprints: "蓝图",
			toolCrowbar: "撬棍",
			toolCrystalBall: "水晶球",
			toolDonuts: "甜甜圈",
			toolDynamite: "炸药",
			toolEmp: "电磁脉冲",
			toolInvisibleSuit: "隐形衣",
			toolMakeupKit: "化妆盒",
			toolRollerskates: "轮滑鞋",
			toolSmokeBomb: "烟雾弹",
			toolStethoscope: "听诊器",
			toolThermalBomb: "热焰弹",
			toolVirus: "病毒",
			lootStamp: "邮票",
			lootChihuahua: "吉娃娃",
			lootTiara: "冠冕",
			lootPersianKitty: "波斯猫",
			lootKeycard: "钥匙卡",
			lootMirror: "镜子",
			lootGemstone: "宝石",
			lootGoldBar: "金条",
			lootCursedGoblet: "诅咒圣杯",
			lootBust: "半身像",
			lootIsotope: "同位素",
			lootPainting: "名画",
			charRook: "打手",
			charSpotter: "眼线",
			charHawk: "鹰眼",
			charAcrobat: "杂技手",
			charJuicer: "内应",
			charRigger: "机关师",
			charPeterman: "锁匠",
			charHacker: "黑客",
			charRaven: "驯鸦人",
			abOrders: "号令",
			abOrdersDesc: "1 点行动:移动队友 1 格,无视额外行动消耗",
			abDisguise: "伪装",
			abDisguiseDesc: "回合首行动:与任一玩家换位",
			abClairvoyance: "千里眼",
			abClairvoyanceDesc: "1 点行动:查看本层巡逻牌堆顶,可将其置底",
			abPrecognition: "预感",
			abPrecognitionDesc: "1 点行动:查看事件牌堆顶,可将其置底",
			abXray: "透视",
			abXrayDesc: "每回合一次:免费侦察相邻格",
			abEnhance: "强化视野",
			abEnhanceDesc: "可侦察 2 格远与上下层对应格",
			abFlexibility: "柔术",
			abFlexibilityDesc: "进入守卫所在格不弃隐身",
			abClimbWindow: "翻窗",
			abClimbWindowDesc: "3 点行动:从边缘格直上或直下一层,本回合行动随即结束",
			abCrybaby: "报警鬼",
			abCrybabyDesc: "免费:在相邻已翻开格触发警报",
			abReroute: "改道",
			abRerouteDesc: "每回合一次:拾走本格的警报标记以改变目的地,或放下标记触发警报",
			abSolution: "机关解",
			abSolutionDesc: "开局携带炸药;任何人抽工具卡时抽 2 张并留下其中 1 张",
			abTinker: "修补",
			abTinkerDesc: "失去 1 枚隐身:抽 1 张工具卡",
			abSteadyHands: "稳手",
			abSteadyHandsDesc: "撬箱与猜密码时多掷 1 颗骰子",
			abDrill: "钻机",
			abDrillDesc: "可隔层对上/下层的保险箱加骰与撬箱",
			abJammer: "干扰器",
			abJammerDesc: "你与同格玩家不触发指纹/激光/动态警报",
			abLaptop: "笔记本",
			abLaptopDesc: "可额外储存 1 枚能当作任意类型使用的黑客标记",
			abDistract: "引鸦",
			abDistractDesc: "免费:在 2 格范围内放置乌鸦,守卫进入该格时少移动 1 步",
			abDisrupt: "扰敌",
			abDisruptDesc: "乌鸦在守卫格且无警报时,守卫不能移动",
			wonBanner: "全员脱身,干得漂亮!",
			lostBanner: "有人被抓,行动失败",
			lostGuard: "隐身耗尽,被守卫抓住",
			errOver: "本局已结束",
			errPending: "请先完成当前选择",
			errNotYours: "该由队友操作",
			errTurn: "还没轮到你",
			errPhase: "现在不能这么做",
			errActions: "行动点不足",
			errMove: "走不到那格",
			errPeek: "看不到那格",
			errHack: "这里不是电脑房",
			errHackFull: "标记已满",
			errSafe: "这里开不了保险箱",
			errNoDice: "保险箱上还没有骰子",
			errDiceFull: "骰子已满(6 颗)",
			errCombo: "组合未知:同行同列还没翻完",
			errKeycard: "钥匙卡持有者必须在保险箱格",
			errTool: "没有这张工具",
			errToolPassive: "听诊器在撬箱时自动生效",
			errBust: "半身像持有者不能使用工具",
			errAbility: "现在用不了这个能力",
			errAbilityUsed: "本回合已用过",
			errTarget: "目标无效",
			errTile: "那格不行",
			errOrder: "顺序无效",
			errKeep: "选择无效",
			errDie: "骰子选择无效",
			errLoot: "没有这件战利品",
			errGoldBar: "每人最多拿一根金条",
			errEscape: "只能从顶层楼梯离开",
			errLootMissing: "战利品还没集齐"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Burgle Bros",
			desc: "Co-op heist: dodge the patrols, crack every safe, and escape from the roof with the loot",
			rules: "Goal: crack every safe, collect all the loot, and get the whole crew out via the top-floor stairs; if anyone runs out of stealth and gets caught, the team fails at once.\nTurn: each turn you have four actions, spent freely among——\n· Peek (one): reveal an adjacent room to everyone.\n· Move (one): step into an adjacent room; entering an unrevealed room reveals it.\n· Hack (one): place a hack token in a computer room; tokens cancel alarms of their type.\n· Add die (two): add one die to the safe you stand on.\n· Crack (one): roll all dice on the safe to cover the combination numbers.\nThresholds: an empty Deadbolt room costs three actions to enter; a Laser room costs two, or it triggers an alarm; a Keypad room requires rolling a six.\nCracking: the combination is known only once the safe's whole row and column are revealed; covering every number cracks the safe.\nReward: each cracked safe draws one tool card and one loot card; guards on that floor and below permanently speed up.\nEvents: if you spent at most two actions this turn, draw an event card when the turn ends.\nGuard: at the end of your turn, the guard on your floor moves toward his destination by the rolled die plus the number of ringing alarms; sharing his tile costs one stealth.\nSpecial: stairs lead one floor up; the two service ducts link once both are revealed.\nFalling: stepping into an unrevealed walkway drops you one floor; ending your turn on a thermo room triggers an alarm.\nTip: tap a room that is not a legal choice to see what it does.",
			scenarioOffice: "Office Job (2 floors)",
			scenarioBank: "Bank Job (3 floors)",
			scenarioFortknox: "Fort Knox (2 wide floors)",
			optScenario: "Scenario",
			optChars: "Character side",
			charsBasic: "Basic",
			charsAdvanced: "Advanced",
			charsMixed: "Mixed",
			floorLabel: "F{{n}}",
			turnBanner: "Your turn: {{n}} actions left",
			waitBanner: "Waiting for {name}…",
			guardBanner: "Guard on patrol…",
			entrancePrompt: "Choose the break-in tile",
			entranceWaiting: "Waiting for {name} to pick the entrance…",
			stealthLabel: "Stealth",
			guardDest: "Dest",
			patrolLeft: "Patrol {{n}}",
			safeDice: "Dice {{n}}",
			hackTokens: "Hacks {{n}}",
			poolLabel: "Pool {{n}}",
			comboReady: "Combo known",
			comboUnknown: "Combo unknown",
			lootProgress: "Loot {{n}}/13",
			kittyOut: "The kitty ran off! Catch it to win",
			effTimeLock: "Time Lock: no stairs",
			effEmp: "EMP: alarms silenced",
			effVideoLoop: "Video Loop: cameras off",
			effGymnastics: "Gymnastics: walkways go up",
			escapedMark: "Escaped",
			actPeek: "Peek",
			actMove: "Move",
			actMoveUnsafe: "Rush in (alarm)",
			actHack: "Hack",
			actAddDie: "Add die (2)",
			actCrack: "Crack",
			actEndTurn: "End turn",
			actEscape: "Escape to roof",
			actGive: "Give",
			actTool: "Tool",
			actAbility: "Ability",
			crackRerollPrompt: "Stethoscope: change one die to any face",
			crackRerollKeep: "Keep as rolled",
			pendingPeekhole: "Peekhole: reveal any tile (or skip)",
			pendingGoWithGut: "Go With Your Gut: step into an adjacent face-down room",
			pendingThrowVoice: "Throw Voice: move the destination die to an adjacent tile",
			pendingBuddySystem: "Buddy System: pull a teammate to your tile",
			pendingCrystalBall: "Crystal Ball: reorder the top 3 events (tap top to bottom)",
			pendingToolDraw: "The Solution: draw 2 tools, keep 1",
			pendingClairvoyance: "Clairvoyance: top patrol card — send to bottom?",
			pendingPrecognition: "Precognition: top event card — send to bottom?",
			pendingWait: "Waiting for {name}…",
			btnBottom: "Bottom",
			btnKeepTop: "Keep",
			btnSkip: "Skip",
			btnConfirm: "OK",
			tileSafe: "Safe",
			tileStairs: "Stairs",
			tileWalkway: "Walkway",
			tileLaboratory: "Lab",
			tileLavatory: "Lavatory",
			tileServiceDuct: "Air Duct",
			tileSecretDoor: "Secret Door",
			tileComputerFp: "FP Computer",
			tileComputerLaser: "Laser Computer",
			tileComputerMotion: "Motion Computer",
			tileCamera: "Camera",
			tileLaser: "Laser",
			tileMotion: "Motion",
			tileDetector: "Detector",
			tileFingerprint: "Fingerprint",
			tileThermo: "Thermo",
			tileKeypad: "Keypad",
			tileDeadbolt: "Deadbolt",
			tileFoyer: "Foyer",
			tileAtrium: "Atrium",
			tileDescSafe: "Add a die for two actions; roll all its dice for one. The combination is known once its row and column are revealed; cover every number to crack it.",
			tileDescStairs: "Move or peek one floor up. The whole crew escapes via the top-floor stairs to win.",
			tileDescWalkway: "If revealed by moving in, you fall one floor.",
			tileDescLaboratory: "The first player to enter draws a tool card.",
			tileDescLavatory: "Place three stealth tokens here when revealed; players hiding here may take them.",
			tileDescServiceDuct: "Once both ducts are revealed, move directly between them.",
			tileDescSecretDoor: "You may enter this room through walls.",
			tileDescComputerFp: "Place hack tokens here; they cancel fingerprint alarms on any floor.",
			tileDescComputerLaser: "Place hack tokens here; they cancel laser alarms on any floor.",
			tileDescComputerMotion: "Place hack tokens here; they cancel motion alarms on any floor.",
			tileDescCamera: "Entering triggers an alarm while the guard is on any camera.",
			tileDescLaser: "Entering costs two actions, or triggers an alarm.",
			tileDescMotion: "You must stop here; moving on triggers an alarm.",
			tileDescDetector: "Entering with a tool or loot triggers an alarm.",
			tileDescFingerprint: "Entering triggers an alarm.",
			tileDescThermo: "Ending your turn here triggers an alarm.",
			tileDescKeypad: "Roll to open: a six opens it; each retry in the same turn adds one die.",
			tileDescDeadbolt: "Entering costs three actions while nobody is here.",
			tileDescFoyer: "The guard sees this room from adjacent tiles and costs you stealth.",
			tileDescAtrium: "The guard sees this room from the same spot one floor up or down; you may peek a floor up or down.",
			tileNumInfo: "Bottom-right circle: safe combination number {{n}}",
			tileUnrevealed: "Unrevealed room. Move in or peek to reveal it.",
			evPeekhole: "Peekhole",
			evDeadDrop: "Dead Drop",
			evLampshade: "Lampshade",
			evSwitchSigns: "Switch Signs",
			evHeadsUp: "Heads Up!",
			evGymnastics: "Gymnastics",
			evChangeOfPlans: "Change of Plans",
			evGoWithGut: "Go With Your Gut",
			evBrownOut: "Brown Out",
			evCrash: "Crash!",
			evEspresso: "Espresso",
			evReboot: "Reboot",
			evSqueak: "Squeak!",
			evShiftChange: "Shift Change",
			evBuddySystem: "Buddy System",
			evFreightElevator: "Freight Elevator",
			evKeycodeChange: "Keycode Change",
			evJumpTheGun: "Jump the Gun",
			evDaydreaming: "Daydreaming",
			evJuryRig: "Jury-Rig",
			evTimeLock: "Time Lock",
			evLostGrip: "Lost Grip",
			evWhereIsHe: "Where Is He?",
			evShoplifting: "Shoplifting",
			evThrowVoice: "Throw Voice",
			evVideoLoop: "Video Loop",
			toolBlueprints: "Blueprints",
			toolCrowbar: "Crowbar",
			toolCrystalBall: "Crystal Ball",
			toolDonuts: "Donuts",
			toolDynamite: "Dynamite",
			toolEmp: "E.M.P.",
			toolInvisibleSuit: "Invisible Suit",
			toolMakeupKit: "Makeup Kit",
			toolRollerskates: "Rollerskates",
			toolSmokeBomb: "Smoke Bomb",
			toolStethoscope: "Stethoscope",
			toolThermalBomb: "Thermal Bomb",
			toolVirus: "Virus",
			lootStamp: "Stamp",
			lootChihuahua: "Chihuahua",
			lootTiara: "Tiara",
			lootPersianKitty: "Persian Kitty",
			lootKeycard: "Keycard",
			lootMirror: "Mirror",
			lootGemstone: "Gemstone",
			lootGoldBar: "Gold Bar",
			lootCursedGoblet: "Cursed Goblet",
			lootBust: "Bust",
			lootIsotope: "Isotope",
			lootPainting: "Painting",
			charRook: "The Rook",
			charSpotter: "The Spotter",
			charHawk: "The Hawk",
			charAcrobat: "The Acrobat",
			charJuicer: "The Juicer",
			charRigger: "The Rigger",
			charPeterman: "The Peterman",
			charHacker: "The Hacker",
			charRaven: "The Raven",
			abOrders: "Orders",
			abOrdersDesc: "1 action: move a teammate 1 tile, ignoring extra action costs",
			abDisguise: "Disguise",
			abDisguiseDesc: "First action: swap places with any player",
			abClairvoyance: "Clairvoyance",
			abClairvoyanceDesc: "1 action: look at this floor's top patrol card; you may send it to the bottom",
			abPrecognition: "Precognition",
			abPrecognitionDesc: "1 action: look at the top event card; you may send it to the bottom",
			abXray: "X-Ray",
			abXrayDesc: "Once per turn: peek an adjacent tile for free",
			abEnhance: "Enhance",
			abEnhanceDesc: "Peek up to 2 tiles away, and up/down one floor",
			abFlexibility: "Flexibility",
			abFlexibilityDesc: "Entering the guard's tile costs no stealth",
			abClimbWindow: "Climb Window",
			abClimbWindowDesc: "3 actions: from an edge tile, go straight up or down one floor; your turn's actions then end",
			abCrybaby: "Crybaby",
			abCrybabyDesc: "Free: trigger an alarm on an adjacent revealed tile",
			abReroute: "Reroute",
			abRerouteDesc: "Once per turn: pick up your tile's alarm to change the destination, or drop it to trigger an alarm here",
			abSolution: "The Solution",
			abSolutionDesc: "Start with Dynamite; anyone drawing a tool draws 2 and keeps 1 of them",
			abTinker: "Tinker",
			abTinkerDesc: "Lose 1 stealth: draw 1 tool card",
			abSteadyHands: "Steady Hands",
			abSteadyHandsDesc: "Roll 1 extra die for safes and keypads",
			abDrill: "Drill",
			abDrillDesc: "Add dice to and crack the safe one floor up/down",
			abJammer: "Jammer",
			abJammerDesc: "You and players with you never trigger fingerprint/laser/motion alarms",
			abLaptop: "Laptop",
			abLaptopDesc: "Store 1 extra hack token, usable as any type",
			abDistract: "Distract",
			abDistractDesc: "Free: place the crow within 2 tiles; a guard entering that tile moves 1 step fewer",
			abDisrupt: "Disrupt",
			abDisruptDesc: "With the crow on the guard's tile and no alarms, the guard cannot move",
			wonBanner: "Everyone made it out — clean getaway!",
			lostBanner: "Someone got caught. Job blown.",
			lostGuard: "Out of stealth — caught by the guard",
			errOver: "The game is over",
			errPending: "Finish the current choice first",
			errNotYours: "That choice belongs to a teammate",
			errTurn: "Not your turn",
			errPhase: "Not right now",
			errActions: "Not enough actions",
			errMove: "Can't get there",
			errPeek: "Can't peek that tile",
			errHack: "Not a computer room",
			errHackFull: "Hack tokens maxed out",
			errSafe: "No safe to work on here",
			errNoDice: "No dice on the safe yet",
			errDiceFull: "Dice maxed out (6)",
			errCombo: "Combo unknown: finish revealing the row and column",
			errKeycard: "The Keycard holder must be on the safe tile",
			errTool: "You don't have that tool",
			errToolPassive: "Stethoscope applies automatically when cracking",
			errBust: "The Bust holder can't use tools",
			errAbility: "Can't use that ability now",
			errAbilityUsed: "Already used this turn",
			errTarget: "Invalid target",
			errTile: "That tile won't work",
			errOrder: "Invalid order",
			errKeep: "Invalid choice",
			errDie: "Invalid die",
			errLoot: "You don't have that loot",
			errGoldBar: "One Gold Bar per person",
			errEscape: "Leave only via the top-floor stairs",
			errLootMissing: "Not all loot collected yet"
		}
	}
};
//#endregion
export { ln as default };
