import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { IconLog as o } from "@bgparty/sdk/icons";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { LogSheet as ee } from "@bgparty/sdk/ui/log-sheet";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
import { OptionRadio as te, OptionSection as d } from "@bgparty/sdk/ui/game-options";
//#region src/games/fornorthwood/data.ts
var f = [
	4,
	3,
	2,
	1,
	1,
	2,
	3,
	4
], p = {
	bronze: 16,
	silver: 18,
	gold: 20
}, m = (e) => [
	"claw",
	"flower",
	"leaf",
	"eye"
][e / 8 | 0], h = (e) => e % 8 + 1, g = [
	{
		suit: "claw",
		rank: "jack",
		nameKey: "games.fornorthwood.charClawJack",
		abilityKey: "games.fornorthwood.abClawJack"
	},
	{
		suit: "claw",
		rank: "queen",
		nameKey: "games.fornorthwood.charClawQueen",
		abilityKey: "games.fornorthwood.abClawQueen"
	},
	{
		suit: "claw",
		rank: "king",
		nameKey: "games.fornorthwood.charClawKing",
		abilityKey: "games.fornorthwood.abClawKing"
	},
	{
		suit: "claw",
		rank: "prince",
		nameKey: "games.fornorthwood.charClawPrince",
		abilityKey: "games.fornorthwood.abClawPrince"
	},
	{
		suit: "claw",
		rank: "lady",
		nameKey: "games.fornorthwood.charClawLady",
		abilityKey: "games.fornorthwood.abClawLady"
	},
	{
		suit: "claw",
		rank: "baron",
		nameKey: "games.fornorthwood.charClawBaron",
		abilityKey: "games.fornorthwood.abClawBaron"
	},
	{
		suit: "flower",
		rank: "jack",
		nameKey: "games.fornorthwood.charFlowerJack",
		abilityKey: "games.fornorthwood.abFlowerJack"
	},
	{
		suit: "flower",
		rank: "queen",
		nameKey: "games.fornorthwood.charFlowerQueen",
		abilityKey: "games.fornorthwood.abFlowerQueen"
	},
	{
		suit: "flower",
		rank: "king",
		nameKey: "games.fornorthwood.charFlowerKing",
		abilityKey: "games.fornorthwood.abFlowerKing"
	},
	{
		suit: "flower",
		rank: "prince",
		nameKey: "games.fornorthwood.charFlowerPrince",
		abilityKey: "games.fornorthwood.abFlowerPrince"
	},
	{
		suit: "flower",
		rank: "lady",
		nameKey: "games.fornorthwood.charFlowerLady",
		abilityKey: "games.fornorthwood.abFlowerLady"
	},
	{
		suit: "flower",
		rank: "baron",
		nameKey: "games.fornorthwood.charFlowerBaron",
		abilityKey: "games.fornorthwood.abFlowerBaron"
	},
	{
		suit: "leaf",
		rank: "jack",
		nameKey: "games.fornorthwood.charLeafJack",
		abilityKey: "games.fornorthwood.abLeafJack"
	},
	{
		suit: "leaf",
		rank: "queen",
		nameKey: "games.fornorthwood.charLeafQueen",
		abilityKey: "games.fornorthwood.abLeafQueen"
	},
	{
		suit: "leaf",
		rank: "king",
		nameKey: "games.fornorthwood.charLeafKing",
		abilityKey: "games.fornorthwood.abLeafKing"
	},
	{
		suit: "leaf",
		rank: "prince",
		nameKey: "games.fornorthwood.charLeafPrince",
		abilityKey: "games.fornorthwood.abLeafPrince"
	},
	{
		suit: "leaf",
		rank: "lady",
		nameKey: "games.fornorthwood.charLeafLady",
		abilityKey: "games.fornorthwood.abLeafLady"
	},
	{
		suit: "leaf",
		rank: "baron",
		nameKey: "games.fornorthwood.charLeafBaron",
		abilityKey: "games.fornorthwood.abLeafBaron"
	},
	{
		suit: "eye",
		rank: "jack",
		nameKey: "games.fornorthwood.charEyeJack",
		abilityKey: "games.fornorthwood.abEyeJack"
	},
	{
		suit: "eye",
		rank: "queen",
		nameKey: "games.fornorthwood.charEyeQueen",
		abilityKey: "games.fornorthwood.abEyeQueen"
	},
	{
		suit: "eye",
		rank: "king",
		nameKey: "games.fornorthwood.charEyeKing",
		abilityKey: "games.fornorthwood.abEyeKing"
	},
	{
		suit: "eye",
		rank: "prince",
		nameKey: "games.fornorthwood.charEyePrince",
		abilityKey: "games.fornorthwood.abEyePrince"
	},
	{
		suit: "eye",
		rank: "lady",
		nameKey: "games.fornorthwood.charEyeLady",
		abilityKey: "games.fornorthwood.abEyeLady"
	},
	{
		suit: "eye",
		rank: "baron",
		nameKey: "games.fornorthwood.charEyeBaron",
		abilityKey: "games.fornorthwood.abEyeBaron"
	}
], _ = (e, t) => [
	"claw",
	"flower",
	"leaf",
	"eye"
].indexOf(e) * 6 + [
	"jack",
	"queen",
	"king",
	"prince",
	"lady",
	"baron"
].indexOf(t), v = {
	id: "fornorthwood",
	tier: "beta",
	mechanics: ["trick-taking"],
	interactionTags: [],
	nameKey: "games.fornorthwood.name",
	descKey: "games.fornorthwood.desc",
	rulesKey: "games.fornorthwood.rules",
	icon: "🌲",
	iconImg: "games/fornorthwood.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/fornorthwood/en.pdf" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#35804e",
	releasedAt: "2026-09-25",
	search: {
		py: "wei le bei jing sen lin",
		init: "wlbjsl"
	},
	hotseat: "cover"
}, y = t.enum([
	"claw",
	"flower",
	"leaf",
	"eye"
]);
t.enum([
	"jack",
	"queen",
	"king",
	"prince",
	"lady",
	"baron"
]);
var b = t.object({
	mode: t.enum(["intro", "full"]).default("intro"),
	medal: t.enum([
		"bronze",
		"silver",
		"gold"
	]).default("bronze")
}).default({
	mode: "intro",
	medal: "bronze"
}), ne = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("fief"),
		fief: t.int().min(0).max(7)
	}),
	t.object({
		type: t.literal("substitute"),
		subs: t.array(t.tuple([t.int().min(0).max(3), t.int().min(0).max(7)])).max(4)
	}),
	t.object({ type: t.literal("skipSub") }),
	t.object({
		type: t.literal("activate"),
		slot: t.int().min(0).max(3)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("respond"),
		card: t.int().min(0).max(31)
	}),
	t.object({
		type: t.literal("pick"),
		cards: t.array(t.int().min(0).max(31))
	}),
	t.object({
		type: t.literal("pickSuit"),
		suit: y
	}),
	t.object({
		type: t.literal("pickFief"),
		fief: t.int().min(0).max(7)
	}),
	t.object({
		type: t.literal("pickAlly"),
		slot: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("prince"),
		more: t.boolean()
	}),
	t.object({ type: t.literal("ok") }),
	t.object({ type: t.literal("concede") })
]), x = t.discriminatedUnion("kind", [
	t.object({ kind: t.literal("fief") }),
	t.object({ kind: t.literal("sub") }),
	t.object({ kind: t.literal("ally") }),
	t.object({ kind: t.literal("respond") }),
	t.object({ kind: t.literal("peek") }),
	t.object({ kind: t.literal("prince") }),
	t.object({ kind: t.literal("suit") }),
	t.object({
		kind: t.literal("visitEnd"),
		fief: t.int().min(0).max(7),
		won: t.boolean(),
		score: t.int()
	}),
	t.object({
		kind: t.literal("pickFief"),
		use: t.enum(["leafJack", "leafPrince"])
	}),
	t.object({
		kind: t.literal("pickAlly"),
		exclude: t.int()
	}),
	t.object({
		kind: t.literal("pick"),
		use: t.enum([
			"clawLady",
			"clawBaron",
			"flowerKing",
			"flowerPrince",
			"flowerLady",
			"eyeJack",
			"eyePrince",
			"eyeLady",
			"eyeBaron",
			"leafKing",
			"leafBaronDiscard",
			"leafBaronScore"
		]),
		target: t.int().optional(),
		left: t.int().optional(),
		exclude: t.array(t.int()).optional()
	})
]), S = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("visit"),
		fief: t.int()
	}),
	t.object({
		k: t.literal("ability"),
		id: t.int().min(0).max(23)
	}),
	t.object({
		k: t.literal("respond"),
		card: t.int().min(0).max(31),
		hit: t.boolean()
	}),
	t.object({
		k: t.literal("won"),
		fief: t.int().min(0).max(7)
	}),
	t.object({
		k: t.literal("lost"),
		fief: t.int().min(0).max(7)
	}),
	t.object({ k: t.literal("concede") })
]), C = t.object({
	mode: t.enum(["intro", "full"]),
	medal: t.enum([
		"bronze",
		"silver",
		"gold"
	]),
	done: t.boolean(),
	win: t.boolean(),
	total: t.int(),
	fiefs: t.array(t.object({
		ruler: t.int().min(0).max(23).nullable(),
		friendly: t.boolean(),
		failed: t.boolean(),
		visiting: t.boolean()
	})).length(8),
	allies: t.array(t.object({
		id: t.int().min(0).max(23),
		sub: t.boolean(),
		used: t.boolean()
	})).length(4),
	hand: t.array(t.int().min(0).max(31)),
	deckCount: t.int(),
	discardCount: t.int(),
	discardTop: t.int().min(0).max(31).nullable(),
	scoreTop: t.int().min(0).max(31).nullable(),
	statement: t.int().min(0).max(31).nullable(),
	scoreNow: t.int(),
	trump: y.nullable(),
	eyeBaron: t.boolean(),
	peek: t.array(t.int().min(0).max(31)).nullable(),
	pending: x.nullable(),
	log: t.array(S)
}), w = t.object({}), T = (e) => ({ code: e }), E = "games.fornorthwood.errInvalid";
function D(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r, i + 1);
		r += 1, [t[i], t[a]] = [t[a], t[i]];
	}
	return r;
}
var O = (e) => {
	let t = e.deck.pop();
	t !== void 0 && e.hand.push(t);
};
function k(e) {
	if (!e.visit) return null;
	let t = e.fiefs[e.visit.fief].ruler;
	return t === null ? null : g[t].suit;
}
function A(e) {
	return e.fiefs.reduce((e, t, n) => e + (t.friendly ? f[n] : 0), 0);
}
function re(e, t, n) {
	let r = 0, i = Array.from({ length: 32 }, (e, t) => t);
	r = D(i, n, r);
	let a = i.splice(i.length - 8, 8), o, s;
	if (e.mode === "intro") {
		o = [
			"claw",
			"flower",
			"leaf",
			"eye"
		].map((e) => _(e, "jack")), s = [];
		for (let e of [
			"claw",
			"flower",
			"leaf",
			"eye"
		]) s.push(_(e, "queen"), _(e, "king"));
		r = D(s, n, r);
	} else {
		o = [], s = [];
		for (let e of [
			"claw",
			"flower",
			"leaf",
			"eye"
		]) {
			let t = [
				"jack",
				"queen",
				"king",
				"prince",
				"lady",
				"baron"
			].map((t) => _(e, t));
			r = D(t, n, r), o.push(t[0]), s.push(t[1], t[2]);
		}
		r = D(s, n, r);
	}
	return { state: {
		players: t,
		host: t[0],
		seed: n,
		rngCursor: r,
		cfg: e,
		deck: i,
		hand: a,
		discard: [],
		scorePile: [],
		fiefs: Array.from({ length: 8 }, (e, t) => ({
			ruler: s[t],
			friendly: !1,
			failed: !1
		})),
		baseAllies: o,
		allies: o.map((e) => ({
			id: e,
			sub: !1,
			used: !1
		})),
		visit: null,
		pending: { kind: "fief" },
		peek: null,
		done: !1,
		log: []
	} };
}
function j(e) {
	if (e.hand.length === 0 || e.deck.length === 0) return N(e);
	let t = e.deck.pop();
	e.discard.push(t), e.visit.statement = t, e.pending = { kind: "respond" };
}
function M(e) {
	if (e.hand.length === 0 || e.deck.length === 0) return N(e);
	e.pending = { kind: "ally" };
}
function N(e) {
	let t = e.visit, n = e.fiefs[t.fief], r = e.scorePile.length === t.fief;
	r ? (n.friendly = !0, e.log.push({
		k: "won",
		fief: t.fief
	})) : (n.failed = !0, n.ruler = null, e.log.push({
		k: "lost",
		fief: t.fief
	}));
	for (let t of e.allies) {
		if (!t.sub) continue;
		let n = e.fiefs.find((e) => e.ruler === t.id);
		n && (n.ruler = null);
	}
	e.allies = e.baseAllies.map((e) => ({
		id: e,
		sub: !1,
		used: !1
	})), e.visit = null, e.peek = null, e.pending = {
		kind: "visitEnd",
		fief: t.fief,
		won: r,
		score: e.scorePile.length
	};
}
function ie(e) {
	if (e.fiefs.every((e) => e.friendly || e.failed)) {
		e.done = !0, e.pending = null;
		return;
	}
	e.deck = [
		...e.deck,
		...e.discard,
		...e.scorePile,
		...e.hand
	], e.discard = [], e.scorePile = [], e.hand = [], e.rngCursor = D(e.deck, e.seed, e.rngCursor), e.hand = e.deck.splice(e.deck.length - 8, 8), e.pending = { kind: "fief" };
}
function P(e) {
	if (e.deck.length === 0) return !1;
	let t = e.deck.pop();
	return e.hand.push(t), m(t) !== k(e) && e.deck.length > 0;
}
function F(e, t) {
	e.hand = e.hand.filter((e) => e !== t), e.discard.push(t);
	for (let n = 0; n < h(t) && e.deck.length > 0; n += 1) O(e);
}
function I(e, t) {
	let n = t === "discard" ? e.discard : e.scorePile;
	if (n.length > 0) {
		let r = h(n[n.length - 1]);
		if (e.hand.some((e) => h(e) === r)) {
			e.pending = {
				kind: "pick",
				use: t === "discard" ? "leafBaronDiscard" : "leafBaronScore",
				target: r
			};
			return;
		}
	}
	t === "discard" && I(e, "score");
}
function L(e, t, n) {
	switch (`${g[t].suit}:${g[t].rank}`) {
		case "claw:jack":
			for (; e.hand.length < 8 && e.deck.length > 0;) O(e);
			break;
		case "claw:queen":
			e.deck.length > 0 && e.hand.push(e.deck.pop()), e.discard.length > 0 && e.hand.push(e.discard.pop()), e.scorePile.length > 0 && e.hand.push(e.scorePile.pop());
			break;
		case "claw:king": {
			if (e.hand.length === 0) break;
			let t = Math.max(...e.hand.map(h)), n = e.hand.filter((e) => h(e) === t);
			e.hand = e.hand.filter((e) => h(e) !== t), e.scorePile.push(...n);
			break;
		}
		case "claw:prince":
			P(e) && (e.pending = { kind: "prince" });
			break;
		case "claw:lady": {
			if (e.hand.length === 0) break;
			let t = Math.min(...e.hand.map(h)), n = e.hand.filter((e) => h(e) === t);
			n.length === 1 ? F(e, n[0]) : e.pending = {
				kind: "pick",
				use: "clawLady"
			};
			break;
		}
		case "claw:baron":
			e.hand.length > 0 && (e.pending = {
				kind: "pick",
				use: "clawBaron"
			});
			break;
		case "flower:jack": {
			let t = k(e);
			if (!t) break;
			e.discard.push(...e.hand.filter((e) => m(e) === t)), e.hand = e.hand.filter((e) => m(e) !== t);
			break;
		}
		case "flower:queen":
			e.scorePile.length > 0 && e.deck.push(e.scorePile.pop());
			break;
		case "flower:king": {
			let t = e.hand.map(h), n = (e) => t.includes(e);
			[
				1,
				2,
				3,
				4
			].some((e) => n(e) && n(9 - e)) && (e.pending = {
				kind: "pick",
				use: "flowerKing"
			});
			break;
		}
		case "flower:prince":
			[
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			].some((t) => e.hand.filter((e) => h(e) === t).length >= 2) && (e.pending = {
				kind: "pick",
				use: "flowerPrince"
			});
			break;
		case "flower:lady": {
			let t = e.hand.length, n = e.hand.filter((e) => h(e) === t);
			n.length === 1 ? (e.hand = e.hand.filter((e) => e !== n[0]), e.discard.push(n[0])) : n.length > 1 && (e.pending = {
				kind: "pick",
				use: "flowerLady",
				target: t
			});
			break;
		}
		case "flower:baron":
			e.discard.push(...e.hand.filter((e) => h(e) <= 3)), e.hand = e.hand.filter((e) => h(e) > 3);
			break;
		case "eye:jack":
			O(e), O(e), e.pending = {
				kind: "pick",
				use: "eyeJack"
			};
			break;
		case "eye:queen":
			e.deck.length > 0 && (e.peek = e.deck.slice(-3).reverse(), e.pending = { kind: "peek" });
			break;
		case "eye:king":
			e.pending = { kind: "suit" };
			break;
		case "eye:prince":
			e.pending = {
				kind: "pick",
				use: "eyePrince",
				left: 1 + e.allies.filter((e, t) => e.used && t !== n).length
			};
			break;
		case "eye:lady": {
			let t = [];
			for (let n = 0; n < 2 && e.deck.length > 0; n += 1) t.push(e.deck.pop());
			e.hand.push(...t), t.length > 0 && (e.pending = {
				kind: "pick",
				use: "eyeLady",
				target: t.reduce((e, t) => e + h(t), 0)
			});
			break;
		}
		case "eye:baron":
			e.visit.eyeBaron = !0;
			break;
		case "leaf:jack":
			R(e).length > 0 && (e.pending = {
				kind: "pickFief",
				use: "leafJack"
			});
			break;
		case "leaf:queen": {
			let t = e.fiefs[e.visit.fief].ruler;
			t !== null && t !== _("leaf", "queen") && L(e, t, n);
			break;
		}
		case "leaf:king": {
			if (e.deck.length === 0) break;
			let t = e.deck.pop();
			e.hand.push(t), e.pending = {
				kind: "pick",
				use: "leafKing",
				exclude: [t]
			};
			break;
		}
		case "leaf:prince":
			z(e).length > 0 && (e.pending = {
				kind: "pickFief",
				use: "leafPrince"
			});
			break;
		case "leaf:lady":
			O(e), e.allies.some((e, t) => e.used && t !== n) && (e.pending = {
				kind: "pickAlly",
				exclude: n
			});
			break;
		case "leaf:baron": I(e, "discard");
	}
}
function R(e) {
	let t = e.visit.fief, n = [];
	for (let r = Math.max(0, t - 2); r <= Math.min(7, t + 2); r += 1) {
		if (r === t) continue;
		let i = e.fiefs[r];
		!i.friendly && !i.failed && i.ruler !== null && n.push(r);
	}
	return n;
}
function z(e) {
	let t = e.visit.fief, n = [];
	for (let r = t + 1; r < 8; r += 1) if (!e.fiefs[r].friendly && !e.fiefs[r].failed) {
		n.push(r);
		break;
	}
	for (let r = t - 1; r >= 0; --r) if (!e.fiefs[r].friendly && !e.fiefs[r].failed) {
		n.push(r);
		break;
	}
	return n;
}
function B(e, t) {
	if (e.pending?.kind !== "fief") return T(E);
	let n = e.fiefs[t];
	if (n.friendly || n.failed) return T(E);
	e.visit = {
		fief: t,
		statement: null,
		eyeBaron: !1
	}, e.log.push({
		k: "visit",
		fief: t
	}), e.pending = e.fiefs.some((e) => e.friendly && e.ruler !== null) ? { kind: "sub" } : { kind: "ally" };
}
function V(e, t) {
	if (e.pending?.kind !== "sub" || new Set(t.map(([e]) => e)).size !== t.length || new Set(t.map(([, e]) => e)).size !== t.length) return T(E);
	for (let [, n] of t) if (!e.fiefs[n].friendly || e.fiefs[n].ruler === null) return T(E);
	for (let [n, r] of t) e.allies[n] = {
		id: e.fiefs[r].ruler,
		sub: !0,
		used: !1
	};
	e.pending = { kind: "ally" };
}
function H(e, t) {
	if (e.pending?.kind !== "ally") return T(E);
	let n = e.allies[t];
	if (!n || n.used) return T(E);
	n.used = !0, e.log.push({
		k: "ability",
		id: n.id
	}), e.peek = null, L(e, n.id, t), e.pending.kind === "ally" && j(e);
}
function ae(e) {
	if (e.pending?.kind !== "ally") return T(E);
	e.peek = null, j(e);
}
function oe(e, t) {
	if (e.pending?.kind !== "respond") return T(E);
	let n = e.visit, r = n.statement, i = m(r);
	if (!e.hand.includes(t) || e.hand.some((e) => m(e) === i) && m(t) !== i) return T(E);
	e.hand = e.hand.filter((e) => e !== t);
	let a = k(e), o = m(t) === i && h(t) > h(r) || i !== a && m(t) === a;
	if (o ? e.scorePile.push(t) : e.discard.push(t), n.statement = null, e.log.push({
		k: "respond",
		card: t,
		hit: o
	}), n.eyeBaron) {
		n.eyeBaron = !1, h(t) % 2 == 0 ? (O(e), M(e)) : e.hand.length > 0 ? e.pending = {
			kind: "pick",
			use: "eyeBaron"
		} : M(e);
		return;
	}
	M(e);
}
function se(e, t) {
	let n = e.pending;
	if (n?.kind !== "pick" || new Set(t).size !== t.length || t.some((t) => !e.hand.includes(t))) return T(E);
	let r = (e) => e.map(h);
	switch (n.use) {
		case "clawLady": {
			if (t.length !== 1) return T(E);
			let n = Math.min(...e.hand.map(h));
			if (h(t[0]) !== n) return T(E);
			F(e, t[0]);
			break;
		}
		case "clawBaron": {
			if (t.length !== 1) return T(E);
			let n = h(t[0]), r = e.deck.filter((e) => h(e) === n);
			e.deck = e.deck.filter((e) => h(e) !== n), e.hand.push(...r), e.rngCursor = D(e.deck, e.seed, e.rngCursor);
			break;
		}
		case "flowerKing":
			if (t.length !== 2 || h(t[0]) + h(t[1]) !== 9) return T(E);
			e.hand = e.hand.filter((e) => !t.includes(e)), e.discard.push(...t);
			break;
		case "flowerPrince":
			for (let n = 1; n <= 8; n += 1) {
				let r = e.hand.filter((e) => h(e) === n), i = t.filter((e) => h(e) === n);
				if (r.length >= 2 ? i.length !== 1 : i.length !== 0) return T(E);
			}
			e.hand = e.hand.filter((e) => !t.includes(e)), e.discard.push(...t);
			break;
		case "flowerLady":
			if (t.length !== 1 || h(t[0]) !== n.target) return T(E);
			e.hand = e.hand.filter((e) => e !== t[0]), e.discard.push(t[0]);
			break;
		case "eyeJack":
			if (t.length !== 2) return T(E);
			e.hand = e.hand.filter((e) => !t.includes(e)), e.discard.push(...t);
			break;
		case "eyePrince":
			if (t.length !== 1) return T(E);
			if (e.hand = e.hand.filter((e) => e !== t[0]), e.discard.push(t[0]), O(e), n.left - 1 > 0 && e.hand.length > 0 && e.deck.length > 0) {
				e.pending = {
					kind: "pick",
					use: "eyePrince",
					left: n.left - 1
				};
				return;
			}
			break;
		case "eyeLady":
			if (t.length === 0 || r(t).reduce((e, t) => e + t, 0) !== n.target) return T(E);
			e.hand = e.hand.filter((e) => !t.includes(e)), e.discard.push(...t);
			break;
		case "eyeBaron":
			if (t.length !== 1) return T(E);
			e.hand = e.hand.filter((e) => e !== t[0]), e.discard.push(t[0]), M(e);
			return;
		case "leafKing":
			if (t.length !== 1 || n.exclude.includes(t[0])) return T(E);
			e.hand = e.hand.filter((e) => e !== t[0]), e.deck.push(t[0]);
			break;
		case "leafBaronDiscard":
		case "leafBaronScore": {
			if (t.length > 1 || t.length === 1 && h(t[0]) !== n.target) return T(E);
			let r = n.use === "leafBaronDiscard" ? e.discard : e.scorePile;
			if (t.length === 1) {
				let n = r.pop();
				e.hand = e.hand.filter((e) => e !== t[0]), e.hand.push(n), r.push(t[0]);
			}
			if (n.use === "leafBaronDiscard" && (e.pending = { kind: "ally" }, I(e, "score"), e.pending.kind !== "ally")) return;
			break;
		}
	}
	j(e);
}
function U(e, t) {
	if (e.pending?.kind !== "suit") return T(E);
	O(e), O(e), e.discard.push(...e.hand.filter((e) => m(e) === t)), e.hand = e.hand.filter((e) => m(e) !== t), j(e);
}
function W(e, t) {
	let n = e.pending;
	if (n?.kind !== "pickFief" || !(n.use === "leafJack" ? R(e) : z(e)).includes(t)) return T(E);
	if (n.use === "leafJack") {
		let n = e.visit.fief;
		[e.fiefs[n].ruler, e.fiefs[t].ruler] = [e.fiefs[t].ruler, e.fiefs[n].ruler];
	} else e.visit = {
		fief: t,
		statement: null,
		eyeBaron: e.visit.eyeBaron
	}, e.log.push({
		k: "visit",
		fief: t
	});
	j(e);
}
function G(e, t) {
	let n = e.pending;
	if (n?.kind !== "pickAlly" || t === n.exclude || !e.allies[t].used) return T(E);
	e.allies[t].used = !1, j(e);
}
function K(e, t) {
	if (e.pending?.kind !== "prince") return T(E);
	if (t && P(e)) {
		e.pending = { kind: "prince" };
		return;
	}
	j(e);
}
function q(e) {
	if (e.pending?.kind === "peek") {
		e.peek = null, j(e);
		return;
	}
	return e.pending?.kind === "visitEnd" ? ie(e) : T(E);
}
function ce(e, t) {
	if (e.done) return T(E);
	let n = structuredClone(e), r;
	switch (t.type) {
		case "fief":
			r = B(n, t.fief);
			break;
		case "substitute":
			r = V(n, t.subs);
			break;
		case "skipSub":
			n.pending?.kind === "sub" ? n.pending = { kind: "ally" } : r = T(E);
			break;
		case "activate":
			r = H(n, t.slot);
			break;
		case "pass":
			r = ae(n);
			break;
		case "respond":
			r = oe(n, t.card);
			break;
		case "pick":
			r = se(n, t.cards);
			break;
		case "pickSuit":
			r = U(n, t.suit);
			break;
		case "pickFief":
			r = W(n, t.fief);
			break;
		case "pickAlly":
			r = G(n, t.slot);
			break;
		case "prince":
			r = K(n, t.more);
			break;
		case "ok":
			r = q(n);
			break;
		case "concede": n.done = !0, n.pending = null, n.log.push({ k: "concede" });
	}
	return r || { state: n };
}
function le(e) {
	return {
		public: {
			mode: e.cfg.mode,
			medal: e.cfg.medal,
			done: e.done,
			win: A(e) >= p[e.cfg.medal],
			total: A(e),
			fiefs: e.fiefs.map((t, n) => ({
				...t,
				visiting: e.visit?.fief === n
			})),
			allies: e.allies.map((e) => ({ ...e })),
			hand: [...e.hand],
			deckCount: e.deck.length,
			discardCount: e.discard.length,
			discardTop: e.discard.length > 0 ? e.discard[e.discard.length - 1] : null,
			scoreTop: e.scorePile.length > 0 ? e.scorePile[e.scorePile.length - 1] : null,
			statement: e.visit?.statement ?? null,
			scoreNow: e.scorePile.length,
			trump: k(e),
			eyeBaron: e.visit?.eyeBaron ?? !1,
			peek: e.peek ? [...e.peek] : null,
			pending: e.pending,
			log: e.log
		},
		private: {}
	};
}
function ue(e) {
	if (!e.done) return { phase: "playing" };
	let t = A(e);
	return {
		phase: "done",
		winner: [e.host],
		ranking: [e.host],
		scores: { [e.host]: t }
	};
}
var de = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: v,
	schemas: {
		action: ne,
		publicView: C,
		privateView: w,
		config: b
	},
	setup: re,
	reduce: ce,
	viewFor: le,
	status: ue
}, J = {
	claw: "#c4604b",
	flower: "#bd728f",
	leaf: "#60915f",
	eye: "#6084a9"
};
function Y({ suit: e, size: t = 20 }) {
	let n = J[e];
	switch (e) {
		case "claw": return /* @__PURE__ */ u("svg", {
			width: t,
			height: t,
			viewBox: "0 0 24 24",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ l("ellipse", {
					cx: "12",
					cy: "15",
					rx: "5",
					ry: "4",
					fill: n
				}),
				/* @__PURE__ */ l("circle", {
					cx: "5.5",
					cy: "9",
					r: "2.2",
					fill: n
				}),
				/* @__PURE__ */ l("circle", {
					cx: "12",
					cy: "6.5",
					r: "2.2",
					fill: n
				}),
				/* @__PURE__ */ l("circle", {
					cx: "18.5",
					cy: "9",
					r: "2.2",
					fill: n
				})
			]
		});
		case "flower": return /* @__PURE__ */ u("svg", {
			width: t,
			height: t,
			viewBox: "0 0 24 24",
			"aria-hidden": !0,
			children: [[
				0,
				72,
				144,
				216,
				288
			].map((e) => /* @__PURE__ */ l("circle", {
				cx: 12 + 6.5 * Math.cos(e * Math.PI / 180),
				cy: 12 + 6.5 * Math.sin(e * Math.PI / 180),
				r: "4",
				fill: n
			}, e)), /* @__PURE__ */ l("circle", {
				cx: "12",
				cy: "12",
				r: "3",
				fill: "#f5d45c"
			})]
		});
		case "leaf": return /* @__PURE__ */ u("svg", {
			width: t,
			height: t,
			viewBox: "0 0 24 24",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ l("path", {
				d: "M12 2 C19 7 19 15 12 22 C5 15 5 7 12 2 Z",
				fill: n
			}), /* @__PURE__ */ l("path", {
				d: "M12 4 L12 20",
				stroke: "#ffffff",
				strokeWidth: "1.4",
				opacity: "0.7"
			})]
		});
		case "eye": return /* @__PURE__ */ u("svg", {
			width: t,
			height: t,
			viewBox: "0 0 24 24",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ l("path", {
					d: "M2 12 C6 5.5 18 5.5 22 12 C18 18.5 6 18.5 2 12 Z",
					fill: n
				}),
				/* @__PURE__ */ l("circle", {
					cx: "12",
					cy: "12",
					r: "4",
					fill: "#ffffff"
				}),
				/* @__PURE__ */ l("circle", {
					cx: "12",
					cy: "12",
					r: "2",
					fill: n
				})
			]
		});
	}
}
function X({ id: e, w: t = 44, dim: n = !1, ring: r = !1 }) {
	let i = m(e), a = h(e), o = J[i], s = Math.round(t * 1.48);
	return /* @__PURE__ */ u("div", {
		className: `fnw-talk-card ${n ? "is-dim" : ""} ${r ? "is-ring" : ""}`,
		style: {
			"--fnw-base-w": `${t}px`,
			"--fnw-base-h": `${s}px`,
			"--fnw-suit": o
		},
		children: [
			/* @__PURE__ */ l("span", {
				className: "fnw-talk-band",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ l("span", {
				className: "fnw-talk-corner",
				"aria-hidden": !0,
				children: a
			}),
			/* @__PURE__ */ l("span", {
				className: "fnw-talk-glyph",
				children: /* @__PURE__ */ l(Y, {
					suit: i,
					size: t * .44
				})
			}),
			/* @__PURE__ */ l("span", {
				className: "fnw-talk-number",
				children: a
			})
		]
	});
}
function fe({ w: e = 44, count: t }) {
	let n = Math.round(e * 1.48);
	return /* @__PURE__ */ u("div", {
		className: "fnw-card-back",
		style: {
			"--fnw-base-w": `${e}px`,
			"--fnw-base-h": `${n}px`,
			boxShadow: t > 1 ? "2px 4px 0 #15352a" : "2px 3px 0 #15352a"
		},
		children: [/* @__PURE__ */ l(Y, {
			suit: "leaf",
			size: e * .48
		}), /* @__PURE__ */ l("span", {
			className: "fnw-card-back-count",
			children: t
		})]
	});
}
//#endregion
//#region src/games/fornorthwood/view-player.tsx
var Z = {
	claw: "games.fornorthwood.suitClaw",
	flower: "games.fornorthwood.suitFlower",
	leaf: "games.fornorthwood.suitLeaf",
	eye: "games.fornorthwood.suitEye"
}, pe = {
	jack: "games.fornorthwood.rankJack",
	queen: "games.fornorthwood.rankQueen",
	king: "games.fornorthwood.rankKing",
	prince: "games.fornorthwood.rankPrince",
	lady: "games.fornorthwood.rankLady",
	baron: "games.fornorthwood.rankBaron"
}, Q = /* @__PURE__ */ new Set([
	"clawLady",
	"clawBaron",
	"flowerLady",
	"eyePrince",
	"eyeBaron",
	"leafKing",
	"leafBaronDiscard",
	"leafBaronScore"
]);
function me(e, t, n) {
	switch (e?.kind) {
		case "fief": return { key: "games.fornorthwood.promptFief" };
		case "sub": return { key: "games.fornorthwood.promptSub" };
		case "ally": return { key: "games.fornorthwood.promptAlly" };
		case "respond": return t ? {
			key: "games.fornorthwood.promptRespond",
			params: { suit: n }
		} : { key: "games.fornorthwood.promptRespondFree" };
		case "peek": return { key: "games.fornorthwood.promptPeek" };
		case "visitEnd": return { key: e.won ? "games.fornorthwood.visitWon" : "games.fornorthwood.visitLost" };
		case "prince": return { key: "games.fornorthwood.promptPrince" };
		case "suit": return { key: "games.fornorthwood.promptSuit" };
		case "pickFief": return { key: e.use === "leafJack" ? "games.fornorthwood.promptPickFiefJack" : "games.fornorthwood.promptPickFiefPrince" };
		case "pickAlly": return { key: "games.fornorthwood.promptPickAlly" };
		case "pick": switch (e.use) {
			case "clawLady": return { key: "games.fornorthwood.promptPickClawLady" };
			case "clawBaron": return { key: "games.fornorthwood.promptPickClawBaron" };
			case "flowerKing": return { key: "games.fornorthwood.promptPickFlowerKing" };
			case "flowerPrince": return { key: "games.fornorthwood.promptPickFlowerPrince" };
			case "flowerLady": return {
				key: "games.fornorthwood.promptPickFlowerLady",
				params: { n: e.target }
			};
			case "eyeJack": return { key: "games.fornorthwood.promptPickEyeJack" };
			case "eyePrince": return {
				key: "games.fornorthwood.promptPickEyePrince",
				params: { n: e.left }
			};
			case "eyeLady": return {
				key: "games.fornorthwood.promptPickEyeLady",
				params: { n: e.target }
			};
			case "eyeBaron": return { key: "games.fornorthwood.promptPickEyeBaron" };
			case "leafKing": return { key: "games.fornorthwood.promptPickLeafKing" };
			case "leafBaronDiscard":
			case "leafBaronScore": return {
				key: "games.fornorthwood.promptPickLeafBaron",
				params: { n: e.target }
			};
		}
	}
	return { key: "games.fornorthwood.promptFief" };
}
function he({ public: e, members: t, myRid: te, send: d }) {
	let _ = a(), v = e, y = v.pending, [b, ne] = i([]), [x, S] = i(null), [C, w] = i(null), [T, E] = i(null), [D, O] = i({}), [k, A] = i(!1), [re, j] = i(!1), [M, N] = i(null), [ie, P] = i(null), F = r(null), I = r(null), L = r(null), R = r(null), z = r(0), B = r(null);
	n(() => () => {
		R.current !== null && window.clearTimeout(R.current), B.current !== null && window.clearTimeout(B.current);
	}, []), n(() => {
		v.statement !== null && M !== null && v.statement !== M.statement && R.current !== null && window.clearTimeout(R.current);
	}, [v.statement, M]);
	let V = M && (v.statement === null || v.statement === M.statement) ? M : null, H = JSON.stringify(y), [ae, oe] = i(H);
	ae !== H && (oe(H), ne([]), S(null), w(null), E(null), A(!1), y?.kind !== "sub" && O({}));
	let se = v.hand.map(h), U = v.statement === null ? null : m(v.statement), W = U !== null && v.hand.some((e) => m(e) === U), G = me(y, W, U ? _(Z[U]) : ""), K = y?.kind === "visitEnd" ? y.fief : C ?? v.fiefs.findIndex((e) => e.visiting), q = K >= 0 ? v.fiefs[K].ruler : null, ce = t.find((e) => e.rid === te)?.name ?? _("games.fornorthwood.soloLabel"), le = (() => {
		let e = (e) => !v.fiefs[e].friendly && !v.fiefs[e].failed;
		if (y?.kind === "fief") return v.fiefs.map((e, t) => t).filter(e);
		if (y?.kind !== "pickFief") return [];
		let t = v.fiefs.findIndex((e) => e.visiting);
		if (y.use === "leafJack") {
			let n = [];
			for (let r = Math.max(0, t - 2); r <= Math.min(7, t + 2); r += 1) r !== t && e(r) && v.fiefs[r].ruler !== null && n.push(r);
			return n;
		}
		let n = [];
		for (let r = t + 1; r < 8; r += 1) if (e(r)) {
			n.push(r);
			break;
		}
		for (let r = t - 1; r >= 0; --r) if (e(r)) {
			n.push(r);
			break;
		}
		return n;
	})(), ue = (e) => {
		if (y?.kind !== "pick") return !1;
		switch (y.use) {
			case "clawLady": return h(e) === Math.min(...se);
			case "flowerLady": return h(e) === y.target;
			case "leafKing": return !(y.exclude ?? []).includes(e);
			case "leafBaronDiscard":
			case "leafBaronScore": return h(e) === y.target;
			default: return !0;
		}
	}, de = () => {
		if (y?.kind !== "pick") return !1;
		let e = b.map(h);
		switch (y.use) {
			case "flowerKing": return b.length === 2 && e[0] + e[1] === 9;
			case "eyeJack": return b.length === 2;
			case "flowerPrince":
				for (let e = 1; e <= 8; e += 1) {
					let t = v.hand.filter((t) => h(t) === e).length, n = b.filter((t) => h(t) === e).length;
					if (t >= 2 ? n !== 1 : n !== 0) return !1;
				}
				return !0;
			case "eyeLady": return b.length >= 1 && e.reduce((e, t) => e + t, 0) === y.target;
			default: return !1;
		}
	}, he = (e, t) => {
		if (y?.kind === "respond") {
			if (W && m(e) !== U) return;
			let n = v.statement !== null && v.trump !== null && (m(e) === U && h(e) > h(v.statement) || U !== v.trump && m(e) === v.trump), r = (t.currentTarget.querySelector(".fnw-talk-card") ?? t.currentTarget).getBoundingClientRect(), i = F.current?.getBoundingClientRect(), a = (n ? I : L).current?.getBoundingClientRect();
			if (i && a && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
				let t = (e) => e.left + e.width / 2 - r.left - r.width / 2, o = (e) => e.top + e.height / 2 - r.top - r.height / 2;
				z.current += 1, N({
					key: z.current,
					card: e,
					statement: v.statement,
					hit: n,
					left: r.left,
					top: r.top,
					width: r.width,
					height: r.height,
					viaX: t(i),
					viaY: o(i),
					endX: t(a),
					endY: o(a),
					targetX: a.left + a.width / 2,
					targetY: a.top
				}), R.current !== null && window.clearTimeout(R.current), B.current !== null && window.clearTimeout(B.current), P(null), R.current = window.setTimeout(() => {
					N(null), P(n ? "score" : "discard"), B.current = window.setTimeout(() => P(null), 320);
				}, 660);
			}
			d({
				type: "respond",
				card: e
			});
			return;
		}
		if (y?.kind === "pick") {
			if (Q.has(y.use)) {
				ue(e) && d({
					type: "pick",
					cards: [e]
				});
				return;
			}
			ne((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
		}
	}, ge = (e) => y?.kind === "respond" ? !W || m(e) === U : y?.kind === "pick" ? !Q.has(y.use) || ue(e) : !1, _e = v.fiefs.map((e, t) => ({
		f: e,
		i: t
	})).filter(({ f: e }) => e.friendly && e.ruler !== null), ve = (e) => {
		if (y?.kind === "sub") {
			if (T === null) {
				D[e] !== void 0 && O((t) => {
					let n = { ...t };
					return delete n[e], n;
				});
				return;
			}
			O((t) => ({
				...t,
				[e]: T
			})), E(null);
			return;
		}
		if (y?.kind === "pickAlly") {
			e !== y.exclude && v.allies[e].used && d({
				type: "pickAlly",
				slot: e
			});
			return;
		}
		y?.kind === "ally" && (v.allies[e].used || S((t) => t === e ? null : e));
	}, ye = (e) => {
		switch (e.k) {
			case "visit": return _("games.fornorthwood.logVisit", { n: e.fief });
			case "won": return _("games.fornorthwood.logWon", { n: e.fief });
			case "lost": return _("games.fornorthwood.logLost", { n: e.fief });
			case "ability": return _("games.fornorthwood.logAbility", { name: _(g[e.id].nameKey) });
			case "respond": return _(e.hit ? "games.fornorthwood.logHit" : "games.fornorthwood.logMiss", { card: `${_(Z[m(e.card)])} ${h(e.card)}` });
			case "concede": return _("games.fornorthwood.logConcede");
		}
	}, be = y?.kind === "visitEnd" ? /* @__PURE__ */ u("div", {
		className: `fnw-overlay fnw-result ${y.won ? "is-won" : "is-lost"}`,
		children: [/* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l("p", {
			className: "fnw-overlay-title",
			children: _(y.won ? "games.fornorthwood.visitWon" : "games.fornorthwood.visitLost")
		}), /* @__PURE__ */ l("p", {
			className: "fnw-overlay-text",
			children: _("games.fornorthwood.visitScore", {
				score: y.score,
				target: y.fief
			})
		})] }), /* @__PURE__ */ l("span", {
			className: "fnw-result-score",
			children: y.won ? _("games.fornorthwood.visitStars", { n: f[y.fief] }) : "×"
		})]
	}) : y?.kind === "peek" && v.peek ? /* @__PURE__ */ u("div", {
		className: "fnw-overlay",
		children: [/* @__PURE__ */ l("p", {
			className: "fnw-overlay-title",
			children: _("games.fornorthwood.promptPeek")
		}), /* @__PURE__ */ l("div", {
			className: "fnw-overlay-cards",
			children: v.peek.map((e, t) => /* @__PURE__ */ l(X, {
				id: e,
				w: 48
			}, t))
		})]
	}) : y?.kind === "suit" ? /* @__PURE__ */ u("div", {
		className: "fnw-overlay",
		children: [/* @__PURE__ */ l("p", {
			className: "fnw-overlay-title",
			children: _("games.fornorthwood.promptSuit")
		}), /* @__PURE__ */ l("div", {
			className: "fnw-overlay-options",
			children: [
				"claw",
				"flower",
				"leaf",
				"eye"
			].map((e) => /* @__PURE__ */ u("button", {
				type: "button",
				className: "fnw-overlay-option",
				style: { "--fnw-suit": J[e] },
				onClick: () => d({
					type: "pickSuit",
					suit: e
				}),
				children: [/* @__PURE__ */ l(Y, {
					suit: e,
					size: 22
				}), _(Z[e])]
			}, e))
		})]
	}) : y?.kind === "sub" ? /* @__PURE__ */ u("div", {
		className: "fnw-overlay",
		children: [
			/* @__PURE__ */ l("p", {
				className: "fnw-overlay-title",
				children: _(T === null ? Object.keys(D).length > 0 ? "games.fornorthwood.subReady" : "games.fornorthwood.subPickRuler" : "games.fornorthwood.subPickSlot")
			}),
			/* @__PURE__ */ l("div", {
				className: "fnw-overlay-options",
				children: _e.map(({ f: e, i: t }) => {
					let n = g[e.ruler];
					return /* @__PURE__ */ u("button", {
						type: "button",
						disabled: Object.values(D).includes(t),
						className: `fnw-overlay-option ${T === t ? "is-selected" : ""}`,
						style: { "--fnw-suit": J[n.suit] },
						onClick: () => E((e) => e === t ? null : t),
						children: [/* @__PURE__ */ l(Y, {
							suit: n.suit,
							size: 18
						}), _(n.nameKey)]
					}, t);
				})
			}),
			T !== null && /* @__PURE__ */ l("p", {
				className: "fnw-overlay-text",
				children: _(g[v.fiefs[T].ruler].abilityKey)
			})
		]
	}) : y?.kind === "ally" && x !== null ? /* @__PURE__ */ u("div", {
		className: "fnw-overlay",
		children: [/* @__PURE__ */ l("p", {
			className: "fnw-overlay-title",
			children: _(g[v.allies[x].id].nameKey)
		}), /* @__PURE__ */ l("p", {
			className: "fnw-overlay-text",
			children: _(g[v.allies[x].id].abilityKey)
		})]
	}) : null, $ = (e, t, n = "main", r = !1) => /* @__PURE__ */ l("button", {
		type: "button",
		className: `fnw-action ${n === "main" ? "" : n === "quiet" ? "is-quiet" : "is-danger"}`,
		disabled: r,
		onClick: t,
		children: _(e)
	}), xe = /* @__PURE__ */ u("div", {
		className: "fnw-actions",
		children: [
			y?.kind === "ally" && x === null && $("games.fornorthwood.pass", () => d({ type: "pass" }), "quiet"),
			y?.kind === "ally" && x !== null && /* @__PURE__ */ u(c, { children: [$("games.fornorthwood.activate", () => d({
				type: "activate",
				slot: x
			})), $("games.fornorthwood.cancel", () => S(null), "quiet")] }),
			y?.kind === "prince" && /* @__PURE__ */ u(c, { children: [$("games.fornorthwood.princeMore", () => d({
				type: "prince",
				more: !0
			})), $("games.fornorthwood.princeStop", () => d({
				type: "prince",
				more: !1
			}), "quiet")] }),
			y?.kind === "visitEnd" && $("games.fornorthwood.cont", () => d({ type: "ok" })),
			y?.kind === "peek" && $("games.fornorthwood.ok", () => d({ type: "ok" })),
			y?.kind === "pick" && !Q.has(y.use) && $("games.fornorthwood.confirm", () => d({
				type: "pick",
				cards: b
			}), "main", !de()),
			y?.kind === "pick" && (y.use === "leafBaronDiscard" || y.use === "leafBaronScore") && $("games.fornorthwood.decline", () => d({
				type: "pick",
				cards: []
			}), "quiet"),
			y?.kind === "sub" && /* @__PURE__ */ u(c, { children: [Object.keys(D).length > 0 && $("games.fornorthwood.subDone", () => d({
				type: "substitute",
				subs: Object.entries(D).map(([e, t]) => [Number(e), t])
			})), $("games.fornorthwood.subSkip", () => d({ type: "skipSub" }), "quiet")] }),
			y?.kind === "fief" && C !== null && /* @__PURE__ */ u(c, { children: [$("games.fornorthwood.confirm", () => d({
				type: "fief",
				fief: C
			})), $("games.fornorthwood.cancel", () => w(null), "quiet")] }),
			y?.kind === "fief" && C === null && $(k ? "games.fornorthwood.concedeConfirm" : "games.fornorthwood.concede", () => k ? d({ type: "concede" }) : A(!0), k ? "danger" : "quiet"),
			y?.kind === "respond" && /* @__PURE__ */ l("div", {
				className: "fnw-action-hint",
				children: _("games.fornorthwood.tapHandRespond")
			}),
			(y?.kind === "pickFief" || y?.kind === "pickAlly" || y?.kind === "suit" || y?.kind === "pick" && Q.has(y.use) && y.use !== "leafBaronDiscard" && y.use !== "leafBaronScore") && /* @__PURE__ */ l("div", {
				className: "fnw-action-hint",
				children: _("games.fornorthwood.tapHighlighted")
			})
		]
	}), Se = /* @__PURE__ */ u("div", {
		className: "fnw-banner",
		children: [
			/* @__PURE__ */ u("div", {
				className: "fnw-player",
				children: [
					_("games.fornorthwood.youLabel"),
					" · ",
					ce
				]
			}),
			/* @__PURE__ */ l("h2", {
				className: "fnw-title",
				children: _("games.fornorthwood.name")
			}),
			/* @__PURE__ */ l("div", {
				className: "fnw-subtitle",
				"aria-hidden": !0,
				children: "FOR NORTHWOOD!"
			}),
			/* @__PURE__ */ l("button", {
				type: "button",
				className: "fnw-log",
				"aria-label": _("common.log.title"),
				onClick: () => j(!0),
				children: /* @__PURE__ */ l(o, { size: 17 })
			}),
			/* @__PURE__ */ u("div", {
				className: "fnw-progress",
				children: [
					/* @__PURE__ */ l("span", {
						className: "fnw-progress-label",
						children: _("games.fornorthwood.starsEarned")
					}),
					/* @__PURE__ */ l("span", {
						className: "fnw-progress-n",
						children: v.total
					}),
					/* @__PURE__ */ u("span", {
						className: "fnw-progress-goal",
						children: [
							" / ",
							p[v.medal],
							" ★"
						]
					})
				]
			}),
			/* @__PURE__ */ u("div", {
				className: "fnw-prompt",
				children: [/* @__PURE__ */ l("span", {
					className: "fnw-prompt-icon",
					children: /* @__PURE__ */ l(Y, {
						suit: v.trump ?? "leaf",
						size: 23
					})
				}), /* @__PURE__ */ l("span", {
					className: "fnw-prompt-text",
					children: _(G.key, G.params)
				})]
			})
		]
	});
	return /* @__PURE__ */ u("div", {
		className: "fnw-root",
		children: [
			/* @__PURE__ */ l(s, {
				adaptive: !0,
				className: "fnw-screen",
				banner: Se,
				actions: xe,
				actionsHeight: "fnw-actions-height",
				overlay: V ? null : be,
				scroll: !1,
				children: /* @__PURE__ */ u("div", {
					className: "fnw-body",
					children: [
						/* @__PURE__ */ u("section", {
							className: "fnw-fiefs",
							"aria-label": _("games.fornorthwood.fiefsLabel"),
							children: [/* @__PURE__ */ u("div", {
								className: "fnw-area-title",
								children: [/* @__PURE__ */ l("strong", { children: _("games.fornorthwood.fiefsLabel") }), /* @__PURE__ */ l("span", { children: _("games.fornorthwood.fiefRange") })]
							}), /* @__PURE__ */ l("div", {
								className: "fnw-fief-row",
								children: v.fiefs.map((e, t) => {
									let n = e.ruler === null ? null : g[e.ruler], r = Object.values(D).includes(t), i = y?.kind === "sub" && e.friendly && n !== null && !r, a = le.includes(t) || i, o = y?.kind === "visitEnd" && y.fief === t, s = C === t || T === t, ee = e.friendly ? "games.fornorthwood.fiefWon" : e.failed ? "games.fornorthwood.fiefLost" : "games.fornorthwood.fiefOpen";
									return /* @__PURE__ */ u("button", {
										type: "button",
										disabled: !a,
										"aria-label": `${t} · ${_(ee)} · ${_(n ? n.nameKey : "games.fornorthwood.fiefLost")}`,
										onClick: () => y?.kind === "sub" ? E((e) => e === t ? null : t) : y?.kind === "fief" ? w((e) => e === t ? null : t) : d({
											type: "pickFief",
											fief: t
										}),
										className: `fnw-fief ${e.friendly ? "is-friendly" : ""} ${e.failed ? "is-failed" : ""} ${e.visiting ? "is-visiting" : ""} ${o ? "is-settling" : ""} ${s ? "is-picked" : ""} ${a ? "is-tappable" : ""}`,
										style: { "--fnw-suit": n ? J[n.suit] : "#68766d" },
										children: [
											/* @__PURE__ */ l("span", {
												className: "fnw-fief-head",
												children: t
											}),
											/* @__PURE__ */ u("span", {
												className: "fnw-fief-glyph",
												children: [n && /* @__PURE__ */ l(Y, {
													suit: n.suit,
													size: 22
												}), (e.friendly || e.failed) && /* @__PURE__ */ l("span", {
													className: "fnw-fief-state",
													children: e.friendly ? "✓" : "×"
												})]
											}),
											/* @__PURE__ */ l("span", {
												className: "fnw-fief-stars",
												children: "★".repeat(f[t])
											}),
											/* @__PURE__ */ l("span", {
												className: "fnw-fief-tag",
												children: s ? _("games.fornorthwood.selectedLabel") : o ? _(ee) : e.visiting ? _("games.fornorthwood.visitingLabel") : "\xA0"
											})
										]
									}, t);
								})
							})]
						}),
						/* @__PURE__ */ u("section", {
							className: "fnw-table",
							"aria-label": _("games.fornorthwood.tableLabel"),
							children: [
								/* @__PURE__ */ u("div", {
									className: "fnw-table-top",
									children: [/* @__PURE__ */ l("span", { children: K >= 0 ? _(y?.kind === "fief" ? "games.fornorthwood.previewFief" : "games.fornorthwood.visitingFief", { n: K }) : _("games.fornorthwood.awaitFief") }), /* @__PURE__ */ l("span", {
										className: `fnw-score-pill ${V?.hit ? "is-fx-landing" : ""}`,
										children: _("games.fornorthwood.scoreProgress", {
											score: v.scoreNow,
											target: K >= 0 ? K : "–"
										})
									})]
								}),
								/* @__PURE__ */ u("div", {
									className: "fnw-table-scene",
									children: [
										q === null ? /* @__PURE__ */ u("div", {
											className: "fnw-ruler is-empty",
											children: [/* @__PURE__ */ l("span", {
												className: "fnw-ruler-art",
												children: /* @__PURE__ */ l(Y, {
													suit: "leaf",
													size: 40
												})
											}), /* @__PURE__ */ l("span", {
												className: "fnw-ruler-name",
												children: _(K >= 0 && v.fiefs[K].failed ? "games.fornorthwood.fiefLost" : "games.fornorthwood.awaitFief")
											})]
										}) : /* @__PURE__ */ u("div", {
											className: "fnw-ruler",
											style: { "--fnw-suit": J[g[q].suit] },
											children: [
												/* @__PURE__ */ u("span", {
													className: "fnw-ruler-head",
													children: [
														"♛ ",
														_(Z[g[q].suit]),
														" · ",
														_(pe[g[q].rank])
													]
												}),
												/* @__PURE__ */ l("span", {
													className: "fnw-ruler-art",
													children: /* @__PURE__ */ l(Y, {
														suit: g[q].suit,
														size: 40
													})
												}),
												/* @__PURE__ */ l("span", {
													className: "fnw-ruler-name",
													children: _(g[q].nameKey)
												}),
												/* @__PURE__ */ u("span", {
													className: "fnw-ruler-note",
													children: [
														_("games.fornorthwood.trumpLabel"),
														" · ",
														_(Z[g[q].suit])
													]
												})
											]
										}),
										/* @__PURE__ */ u("div", {
											className: "fnw-speech",
											children: [/* @__PURE__ */ l("span", {
												className: "fnw-speech-label",
												children: _("games.fornorthwood.rulerStatement")
											}), /* @__PURE__ */ l("div", {
												className: "fnw-speech-card",
												children: v.statement === null ? /* @__PURE__ */ l("div", {
													className: "fnw-empty-statement fnw-speech-card",
													children: _("games.fornorthwood.emptyStatement")
												}) : /* @__PURE__ */ l("div", {
													className: "fnw-statement-appear",
													children: /* @__PURE__ */ l(X, {
														id: v.statement,
														w: 72,
														ring: !0
													})
												}, v.statement)
											})]
										}),
										/* @__PURE__ */ l("span", {
											className: "fnw-scene-arrow",
											"aria-hidden": !0,
											children: "→"
										}),
										/* @__PURE__ */ u("div", {
											className: "fnw-response",
											children: [/* @__PURE__ */ l("span", {
												className: "fnw-speech-label",
												children: _("games.fornorthwood.yourResponse")
											}), /* @__PURE__ */ l("div", {
												ref: F,
												className: "fnw-response-slot",
												children: _("games.fornorthwood.emptyResponse")
											})]
										})
									]
								}),
								/* @__PURE__ */ u("div", {
									className: "fnw-piles",
									children: [
										/* @__PURE__ */ u("div", {
											className: "fnw-pile",
											children: [
												/* @__PURE__ */ l("span", {
													className: "fnw-pile-card",
													children: v.deckCount > 0 ? /* @__PURE__ */ l(fe, {
														w: 28,
														count: v.deckCount
													}) : /* @__PURE__ */ l("span", { className: "fnw-pile-empty" })
												}),
												/* @__PURE__ */ l("span", {
													className: "fnw-pile-n",
													children: v.deckCount
												}),
												/* @__PURE__ */ l("span", {
													className: "fnw-pile-label",
													children: _("games.fornorthwood.deckLabel")
												})
											]
										}),
										/* @__PURE__ */ u("div", {
											ref: I,
											className: `fnw-pile ${V?.hit ? "is-fx-landing" : ""} ${ie === "score" ? "is-fx-arrived" : ""}`,
											children: [
												/* @__PURE__ */ l("span", {
													className: "fnw-pile-card",
													children: v.scoreTop === null ? /* @__PURE__ */ l("span", { className: "fnw-pile-empty" }) : /* @__PURE__ */ l(X, {
														id: v.scoreTop,
														w: 28
													})
												}),
												/* @__PURE__ */ u("span", {
													className: "fnw-pile-n",
													children: [v.scoreNow, K >= 0 ? `/${K}` : ""]
												}),
												/* @__PURE__ */ l("span", {
													className: "fnw-pile-label",
													children: _("games.fornorthwood.scoreLabel")
												})
											]
										}),
										/* @__PURE__ */ u("div", {
											ref: L,
											className: `fnw-pile ${V && !V.hit ? "is-fx-landing" : ""} ${ie === "discard" ? "is-fx-arrived" : ""}`,
											children: [
												/* @__PURE__ */ l("span", {
													className: "fnw-pile-card",
													children: v.discardTop === null ? /* @__PURE__ */ l("span", { className: "fnw-pile-empty" }) : /* @__PURE__ */ l(X, {
														id: v.discardTop,
														w: 28
													})
												}),
												/* @__PURE__ */ l("span", {
													className: "fnw-pile-n",
													children: v.discardCount
												}),
												/* @__PURE__ */ l("span", {
													className: "fnw-pile-label",
													children: _("games.fornorthwood.discardLabel")
												})
											]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ u("div", {
							className: "fnw-side",
							children: [/* @__PURE__ */ u("section", {
								className: "fnw-allies",
								"aria-label": _("games.fornorthwood.alliesLabel"),
								children: [/* @__PURE__ */ u("div", {
									className: "fnw-area-title",
									children: [/* @__PURE__ */ l("strong", { children: _("games.fornorthwood.alliesLabel") }), /* @__PURE__ */ l("span", { children: _("games.fornorthwood.allyLimit") })]
								}), /* @__PURE__ */ l("div", {
									className: "fnw-ally-row",
									children: v.allies.map((e, t) => {
										let n = D[t], r = g[n === void 0 ? e.id : v.fiefs[n].ruler], i = y?.kind === "pickAlly" && t !== y.exclude && e.used, a = x === t, o = y?.kind === "sub" ? T !== null || n !== void 0 : y?.kind === "pickAlly" ? i : y?.kind === "ally" && !e.used;
										return /* @__PURE__ */ u("button", {
											type: "button",
											disabled: !o,
											onClick: () => ve(t),
											"aria-label": `${_(r.nameKey)} · ${_(e.used ? "games.fornorthwood.usedLabel" : e.sub || n !== void 0 ? "games.fornorthwood.subTag" : "games.fornorthwood.availableLabel")}`,
											className: `fnw-ally ${e.used ? "is-used" : ""} ${a ? "is-active" : ""} ${i || y?.kind === "sub" && T !== null ? "is-target" : ""}`,
											style: { "--fnw-suit": J[r.suit] },
											children: [
												/* @__PURE__ */ l("span", {
													className: "fnw-ally-name",
													children: _(r.nameKey)
												}),
												/* @__PURE__ */ l("span", {
													className: "fnw-ally-emblem",
													children: /* @__PURE__ */ l(Y, {
														suit: r.suit,
														size: 27
													})
												}),
												/* @__PURE__ */ l("span", {
													className: "fnw-ally-state",
													children: e.used ? _("games.fornorthwood.usedLabel") : a ? _("games.fornorthwood.selectedLabel") : e.sub || n !== void 0 ? _("games.fornorthwood.subTag") : _("games.fornorthwood.availableLabel")
												})
											]
										}, t);
									})
								})]
							}), /* @__PURE__ */ u("section", {
								className: "fnw-hand-area",
								"aria-label": _("games.fornorthwood.handLabel"),
								children: [/* @__PURE__ */ u("div", {
									className: "fnw-area-title",
									children: [/* @__PURE__ */ l("strong", { children: _("games.fornorthwood.handLabel") }), /* @__PURE__ */ l("span", { children: y?.kind === "respond" ? _("games.fornorthwood.legalCount", { n: v.hand.filter(ge).length }) : _("games.fornorthwood.handCount", { n: v.hand.length }) })]
								}), /* @__PURE__ */ l("div", {
									className: "fnw-hand",
									children: v.hand.map((e, t) => {
										let n = ge(e), r = b.includes(e);
										return /* @__PURE__ */ l("button", {
											type: "button",
											disabled: !n && !r,
											"aria-label": `${_(Z[m(e)])} ${h(e)}`,
											onClick: (t) => he(e, t),
											className: `fnw-hand-button ${r ? "is-selected" : ""} ${y?.kind === "respond" && n ? "is-legal" : ""}`,
											children: /* @__PURE__ */ l(X, {
												id: e,
												w: 44,
												dim: !n && !r && (y?.kind === "respond" || y?.kind === "pick"),
												ring: r
											})
										}, `${e}-${t}`);
									})
								})]
							})]
						})
					]
				})
			}),
			V && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("div", {
				className: "fnw-fx-sprite",
				style: {
					left: V.left,
					top: V.top,
					"--fnw-card-w": `${V.width}px`,
					"--fnw-card-h": `${V.height}px`,
					"--fnw-via-x": `${V.viaX}px`,
					"--fnw-via-y": `${V.viaY}px`,
					"--fnw-end-x": `${V.endX}px`,
					"--fnw-end-y": `${V.endY}px`
				},
				children: /* @__PURE__ */ l(X, {
					id: V.card,
					w: V.width
				})
			}, V.key), /* @__PURE__ */ l("div", {
				className: "fnw-fx-outcome",
				style: {
					left: V.targetX,
					top: V.targetY
				},
				children: _(V.hit ? "games.fornorthwood.fxHit" : "games.fornorthwood.fxMiss")
			}, `result-${V.key}`)] }),
			re && /* @__PURE__ */ l(ee, {
				log: v.log,
				line: ye,
				onClose: () => j(!1)
			})
		]
	});
}
//#endregion
//#region src/games/fornorthwood/game-over.tsx
var ge = {
	bronze: "games.fornorthwood.medalBronze",
	silver: "games.fornorthwood.medalSilver",
	gold: "games.fornorthwood.medalGold"
};
function _e({ public: e, onPlayAgain: t, onBackToLobby: n }) {
	let r = a(), i = e;
	return /* @__PURE__ */ u("div", {
		className: "fnw-root fnw-over",
		children: [/* @__PURE__ */ u("div", {
			className: "fnw-over-scroll",
			children: [/* @__PURE__ */ u("header", {
				className: `fnw-over-header ${i.win ? "is-won" : "is-lost"}`,
				children: [
					/* @__PURE__ */ u("div", {
						className: "fnw-over-kicker",
						children: [/* @__PURE__ */ l(Y, {
							suit: "leaf",
							size: 20
						}), " FOR NORTHWOOD!"]
					}),
					/* @__PURE__ */ l("h1", { children: r(i.win ? "games.fornorthwood.overWin" : "games.fornorthwood.overLose") }),
					/* @__PURE__ */ l("p", { children: r(ge[i.medal]) }),
					/* @__PURE__ */ u("div", {
						className: "fnw-over-score",
						children: [
							/* @__PURE__ */ l("span", { children: r("games.fornorthwood.overScore") }),
							/* @__PURE__ */ u("strong", { children: [i.total, " ★"] }),
							/* @__PURE__ */ l("span", { children: r("games.fornorthwood.overTarget", { n: p[i.medal] }) })
						]
					})
				]
			}), /* @__PURE__ */ u("section", {
				className: "fnw-over-map",
				"aria-label": r("games.fornorthwood.fiefsLabel"),
				children: [/* @__PURE__ */ u("div", {
					className: "fnw-area-title",
					children: [/* @__PURE__ */ l("strong", { children: r("games.fornorthwood.fiefsLabel") }), /* @__PURE__ */ l("span", { children: r("games.fornorthwood.fiefRange") })]
				}), /* @__PURE__ */ l("div", {
					className: "fnw-over-fiefs",
					children: i.fiefs.map((e, t) => {
						let n = e.ruler === null ? null : g[e.ruler];
						return /* @__PURE__ */ u("div", {
							className: `fnw-over-fief ${e.friendly ? "is-friendly" : e.failed ? "is-failed" : "is-open"}`,
							style: { "--fnw-suit": n ? J[n.suit] : "#68766d" },
							children: [
								/* @__PURE__ */ u("div", {
									className: "fnw-over-fief-head",
									children: [/* @__PURE__ */ l("strong", { children: t }), /* @__PURE__ */ l("span", { children: e.friendly ? `+${f[t]} ★` : `${f[t]} ★` })]
								}),
								/* @__PURE__ */ l("div", {
									className: "fnw-over-fief-glyph",
									children: n ? /* @__PURE__ */ l(Y, {
										suit: n.suit,
										size: 27
									}) : /* @__PURE__ */ l(Y, {
										suit: "leaf",
										size: 27
									})
								}),
								/* @__PURE__ */ l("div", {
									className: "fnw-over-fief-name",
									children: r(n ? n.nameKey : e.failed ? "games.fornorthwood.fiefLost" : "games.fornorthwood.fiefOpen")
								}),
								/* @__PURE__ */ l("div", {
									className: "fnw-over-fief-state",
									children: r(e.friendly ? "games.fornorthwood.fiefWon" : e.failed ? "games.fornorthwood.fiefLost" : "games.fornorthwood.fiefOpen")
								})
							]
						}, t);
					})
				})]
			})]
		}), /* @__PURE__ */ u("div", {
			className: "fnw-over-actions",
			children: [t && /* @__PURE__ */ l("button", {
				type: "button",
				className: "fnw-action",
				onClick: t,
				children: r("session.result.playAgain")
			}), n && /* @__PURE__ */ l("button", {
				type: "button",
				className: "fnw-action is-quiet",
				onClick: n,
				children: r("session.result.backToLobby")
			})]
		})]
	});
}
//#endregion
//#region src/games/fornorthwood/options.tsx
var ve = {
	intro: "games.fornorthwood.modeIntro",
	full: "games.fornorthwood.modeFull"
}, ye = {
	bronze: "games.fornorthwood.medalBronze",
	silver: "games.fornorthwood.medalSilver",
	gold: "games.fornorthwood.medalGold"
};
function be({ value: e, onChange: t }) {
	let n = a(), r = b.safeParse(e), i = r.success ? r.data : b.parse(void 0), o = (e, r, a) => /* @__PURE__ */ l(d, {
		title: n(e),
		columns: Object.keys(a).length === 3 ? 3 : 2,
		children: Object.keys(a).map((e) => /* @__PURE__ */ l(te, {
			name: `fornorthwood-${r}`,
			value: e,
			checked: i[r] === e,
			label: n(a[e]),
			accent: v.accent,
			onChange: () => t({
				...i,
				[r]: e
			})
		}, e))
	});
	return /* @__PURE__ */ u("div", {
		className: "flex flex-col gap-3",
		children: [o("games.fornorthwood.optMode", "mode", ve), o("games.fornorthwood.optMedal", "medal", ye)]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/fornorthwood/entry.tsx
var $ = {
	definition: de,
	View: he,
	OverView: _e,
	Options: be,
	locales: {
		zh: {
			name: "为了北境森林",
			desc: "单人吃墩:走访八块领地,用恰到好处的对话说服各位统治者",
			rules: "目标:独自拜访北境森林的八块领地,通过对话(吃墩)说服统治者。\n· 游戏结束时,友好领地的星数之和达到胜利线即获胜。\n准备:\n· 将八块领地按目标墩数 0 至 7 依次排列。各领地的星数如下：\n· 目标为 0 墩或 7 墩的领地，各有 4 颗星。\n· 目标为 1 墩或 6 墩的领地，各有 3 颗星。\n· 目标为 2 墩或 5 墩的领地，各有 2 颗星。\n· 目标为 3 墩或 4 墩的领地，各有 1 颗星。\n· 教学局由四名骑士担任盟友,八张女王与国王洗匀后各置一块领地担任统治者。\n· 完整局将 24 张角色卡洗匀后按花色发放,每种花色第 1 张为盟友,第 2、3 张为统治者。\n· 32 张对话牌(爪/花/叶/瞳四花色,各 1-8 点)洗成牌堆,摸 8 张手牌。\n流程:每次拜访依次进行——\n· 选择一块未拜访的领地。\n· 可让任意名已友好的统治者前来替换盟友,每位占一个盟友位,拜访结束后离场。\n· 对话时每墩可先激活至多一个盟友能力(每次拜访每个盟友限一次)。\n· 翻开牌堆顶牌作为统治者的发言;你必须跟出同花色,没有同花色才可任意出牌。\n· 回应与发言同花色且点数更大,或发言非王牌花色(统治者花色)而你打出王牌花色,即赢得此墩。\n· 赢墩的回应牌入计分牌堆,否则入弃牌堆。\n· 手牌或牌堆任一耗尽,拜访立即结束。\n结算:\n· 计分牌堆的牌数恰好等于目标墩数,则统治者转为友好;否则拜访失败,统治者离场。\n· 拜访结束后所有对话牌重洗,补摸 8 张,选择下一块领地。\n结束：拜访完八块领地后，或提前认输时，结算友好领地的星数。标准难度的胜利线为 16 颗星，进阶难度为 18 颗星，理想难度为 20 颗星。",
			suitClaw: "爪",
			suitFlower: "花",
			suitLeaf: "叶",
			suitEye: "瞳",
			rankJack: "骑士",
			rankQueen: "女王",
			rankKing: "国王",
			rankPrince: "王子",
			rankLady: "贵妇",
			rankBaron: "男爵",
			charClawJack: "爪之骑士",
			charClawQueen: "爪之女王",
			charClawKing: "爪之国王",
			charClawPrince: "爪之王子",
			charClawLady: "爪之贵妇",
			charClawBaron: "爪之男爵",
			charFlowerJack: "花之骑士",
			charFlowerQueen: "花之女王",
			charFlowerKing: "花之国王",
			charFlowerPrince: "花之王子",
			charFlowerLady: "花之贵妇",
			charFlowerBaron: "花之男爵",
			charLeafJack: "叶之骑士",
			charLeafQueen: "叶之女王",
			charLeafKing: "叶之国王",
			charLeafPrince: "叶之王子",
			charLeafLady: "叶之贵妇",
			charLeafBaron: "叶之男爵",
			charEyeJack: "瞳之骑士",
			charEyeQueen: "瞳之女王",
			charEyeKing: "瞳之国王",
			charEyePrince: "瞳之王子",
			charEyeLady: "瞳之贵妇",
			charEyeBaron: "瞳之男爵",
			abClawJack: "若手牌少于 8 张,摸牌直至达到 8 张。",
			abClawQueen: "从牌堆、弃牌堆、计分牌堆的堆顶各摸 1 张牌。",
			abClawKing: "将手牌中点数最大的所有牌放入计分牌堆。",
			abClawPrince: "逐张摸牌,直到摸到王牌花色的牌,或你选择停止。",
			abClawLady: "弃掉手牌中点数最小的 1 张牌(并列时自选),然后摸取其点数数量的牌。",
			abClawBaron: "选择 1 张手牌,从牌堆找出所有同点数的牌加入手牌,然后洗混牌堆。",
			abFlowerJack: "弃掉手牌中所有王牌花色的牌。",
			abFlowerQueen: "将计分牌堆顶的牌放回牌堆顶。",
			abFlowerKing: "弃掉点数之和恰好为 9 的 2 张手牌。",
			abFlowerPrince: "每种点数各保留 1 张手牌,弃掉其余重复的牌。",
			abFlowerLady: "弃掉 1 张点数等于当前手牌数的牌。",
			abFlowerBaron: "弃掉所有点数为 1、2、3 的手牌。",
			abEyeJack: "摸 2 张牌,然后弃 2 张牌。",
			abEyeQueen: "查看牌堆顶的 3 张牌,按原顺序放回。",
			abEyeKing: "指定一种花色,摸 2 张牌,然后弃掉手牌中所有该花色的牌。",
			abEyePrince: "弃 1 张牌再摸 1 张牌;每有 1 个其他已使用能力的盟友,再重复一次。",
			abEyeLady: "摸 2 张牌,然后弃掉若干张点数之和恰好等于这 2 张牌点数之和的手牌。",
			abEyeBaron: "你的下一张回应牌为偶数则回应后摸 1 张牌,为奇数则回应后弃 1 张牌。",
			abLeafJack: "将当前统治者与相距至多 2 块领地的未拜访统治者交换。",
			abLeafQueen: "使用当前统治者的能力。",
			abLeafKing: "查看牌堆顶的牌,将其与另 1 张手牌交换。",
			abLeafPrince: "将拜访移至目标墩数更高或更低的最近未拜访领地。",
			abLeafLady: "摸 1 张牌,重置另 1 个已使用能力的盟友。",
			abLeafBaron: "可将 1 张手牌与弃牌堆顶的同点数牌交换,然后可对计分牌堆顶同样操作一次。",
			optMode: "模式",
			modeIntro: "教学局",
			modeFull: "完整局",
			optMedal: "难度",
			medalBronze: "标准 16 星",
			medalSilver: "进阶 18 星",
			medalGold: "理想 20 星",
			promptFief: "选择一块未拜访的领地",
			promptSub: "可让友好的统治者替换盟友,或直接进入对话",
			promptAlly: "可激活一个盟友能力,或直接对话",
			promptRespond: "打出回应:须跟{{suit}}花色",
			promptRespondFree: "打出回应:任意一张",
			promptPrince: "继续摸牌,还是停止?",
			promptPeek: "牌堆顶的 3 张牌(先翻出的在左)",
			promptSuit: "指定一种花色",
			promptPickClawLady: "弃掉点数最小的 1 张牌",
			promptPickClawBaron: "选择 1 张手牌,找出牌堆中所有同点数的牌",
			promptPickFlowerKing: "弃掉点数之和为 9 的 2 张牌",
			promptPickFlowerPrince: "每种重复的点数各弃 1 张",
			promptPickFlowerLady: "弃掉 1 张点数为 {{n}} 的牌",
			promptPickEyeJack: "弃 2 张牌",
			promptPickEyePrince: "弃 1 张牌再摸 1 张(还剩 {{n}} 次)",
			promptPickEyeLady: "弃掉点数之和为 {{n}} 的若干张牌",
			promptPickEyeBaron: "回应为奇数:弃 1 张牌",
			promptPickLeafKing: "选择 1 张手牌放回牌堆顶",
			promptPickLeafBaron: "可用 1 张点数为 {{n}} 的手牌交换堆顶,或不交换",
			promptPickFiefJack: "选择要交换统治者的领地",
			promptPickFiefPrince: "选择要移往的领地",
			promptPickAlly: "重置哪个盟友?",
			visitWon: "说服成功!统治者转为友好",
			visitLost: "谈判失败,统治者离场",
			visitScore: "得分 {{score}} / 目标 {{target}}",
			visitStars: "+{{n}} ★",
			cont: "继续",
			deckLabel: "牌堆",
			discardLabel: "弃牌",
			scoreLabel: "得分",
			targetLabel: "目标",
			alliesLabel: "盟友",
			trumpLabel: "王牌",
			subDone: "完成替换",
			subSkip: "不替换",
			subPickRuler: "先点选一位友好的统治者",
			subPickSlot: "再点选被替换的盟友位",
			subReady: "替换已选好；点代打盟友可撤销，或完成替换",
			pass: "直接对话",
			activate: "使用能力",
			cancel: "取消",
			ok: "知道了",
			confirm: "确定",
			decline: "不交换",
			princeMore: "继续摸",
			princeStop: "停止",
			concede: "提前认输",
			concedeConfirm: "确认认输",
			usedLabel: "已用",
			subTag: "代打",
			soloLabel: "独行旅人",
			youLabel: "你",
			starsEarned: "已获星数",
			fiefsLabel: "八块领地",
			fiefRange: "目标墩数 0–7",
			tableLabel: "对话桌面",
			fiefOpen: "未拜访",
			selectedLabel: "已选",
			visitingLabel: "拜访中",
			previewFief: "待拜访 · {{n}} 号领地",
			visitingFief: "正在拜访 · {{n}} 号领地",
			awaitFief: "选择领地",
			scoreProgress: "{{score}} / {{target}} 墩",
			rulerStatement: "统治者发言",
			yourResponse: "你的回应",
			emptyStatement: "待发言",
			emptyResponse: "点手牌",
			allyLimit: "每位每次拜访限用一次",
			availableLabel: "能力可用",
			handLabel: "手牌",
			handCount: "{{n}} 张 · 当前手牌",
			legalCount: "可出 {{n}} 张",
			tapHandRespond: "点选一张可出的手牌回应",
			tapHighlighted: "点选高亮目标继续",
			fxHit: "赢得此墩",
			fxMiss: "进入弃牌",
			overWin: "北境统一!",
			overLose: "谈判破裂",
			overScore: "星数",
			overTarget: "胜利线 {{n}}",
			fiefWon: "已友好",
			fiefLost: "未说服",
			medalEarned: "达成{{medal}}奖牌",
			logVisit: "前往 {{n}} 号领地",
			logWon: "说服了 {{n}} 号领地的统治者",
			logLost: "{{n}} 号领地谈判失败",
			logConcede: "提前认输",
			logAbility: "使用了{{name}}的能力",
			logHit: "打出{{card}}，赢得此墩",
			logMiss: "打出{{card}}，未赢得此墩",
			errInvalid: "现在不能这样操作"
		},
		en: {
			name: "For Northwood!",
			desc: "Solo trick-taking: visit eight fiefs and win over their rulers through precise dialogue",
			rules: "Goal: visit the eight fiefs of Northwood alone and win over their rulers through dialogues (tricks).\n· At the end, you win if your friendly fiefs' stars reach the victory line.\nSetup:\n· The eight fiefs are laid out with target scores 0-7 and star values 4/3/2/1/1/2/3/4.\n· Intro game: the four Jacks are your allies, and the shuffled Queens and Kings become the rulers, one per fief.\n· Full game: shuffle all 24 character cards and deal by suit — the first card of each suit is an ally, the second and third are rulers.\n· Shuffle the 32 dialogue cards (suits Claws/Flowers/Leaves/Eyes, valued 1-8) into a deck and draw 8.\nPlay: each visit proceeds in order —\n· Choose an unvisited fief.\n· Any number of friendly rulers may substitute for allies, one per ally slot; they leave when the visit ends.\n· Dialogue: before each trick you may activate at most one ally ability (each ally once per visit).\n· The top card of the deck is revealed as the ruler's statement; you must follow its suit if able.\n· You score the trick if your response is a higher card of the statement's suit, or if the statement is not the trump suit (the ruler's suit) but your response is.\n· Scored responses go to the score pile, others to the discard pile.\n· The visit ends immediately when your hand or the deck runs out.\nScoring:\n· If the score pile exactly equals the target, the ruler turns friendly; otherwise the visit fails and the ruler leaves.\n· After a visit, reshuffle all dialogue cards, draw 8, and choose the next fief.\nEnd: after visiting all eight fiefs, or conceding early, total the stars on your friendly fiefs. The victory line is 16 stars for Standard, 18 for Advanced and 20 for Idealist.",
			suitClaw: "Claws",
			suitFlower: "Flowers",
			suitLeaf: "Leaves",
			suitEye: "Eyes",
			rankJack: "Jack",
			rankQueen: "Queen",
			rankKing: "King",
			rankPrince: "Prince",
			rankLady: "Lady",
			rankBaron: "Baron",
			charClawJack: "Jack of Claws",
			charClawQueen: "Queen of Claws",
			charClawKing: "King of Claws",
			charClawPrince: "Prince of Claws",
			charClawLady: "Lady of Claws",
			charClawBaron: "Baron of Claws",
			charFlowerJack: "Jack of Flowers",
			charFlowerQueen: "Queen of Flowers",
			charFlowerKing: "King of Flowers",
			charFlowerPrince: "Prince of Flowers",
			charFlowerLady: "Lady of Flowers",
			charFlowerBaron: "Baron of Flowers",
			charLeafJack: "Jack of Leaves",
			charLeafQueen: "Queen of Leaves",
			charLeafKing: "King of Leaves",
			charLeafPrince: "Prince of Leaves",
			charLeafLady: "Lady of Leaves",
			charLeafBaron: "Baron of Leaves",
			charEyeJack: "Jack of Eyes",
			charEyeQueen: "Queen of Eyes",
			charEyeKing: "King of Eyes",
			charEyePrince: "Prince of Eyes",
			charEyeLady: "Lady of Eyes",
			charEyeBaron: "Baron of Eyes",
			abClawJack: "If you hold fewer than 8 cards, draw until you have 8.",
			abClawQueen: "Draw the top card of the deck, the discard pile, and the score pile.",
			abClawKing: "Put the highest-valued card(s) in your hand into the score pile.",
			abClawPrince: "Draw one at a time until you draw a trump-suit card or choose to stop.",
			abClawLady: "Discard your lowest-valued card (your choice on ties), then draw as many cards as its value.",
			abClawBaron: "Choose a card in hand. Draw every card of the same value from the deck, then shuffle the deck.",
			abFlowerJack: "Discard all trump-suit cards from your hand.",
			abFlowerQueen: "Put the top card of the score pile on top of the deck.",
			abFlowerKing: "Discard two cards whose values sum to exactly 9.",
			abFlowerPrince: "Keep one card of each value; discard all duplicates.",
			abFlowerLady: "Discard a card whose value equals your current hand size.",
			abFlowerBaron: "Discard all cards valued 1, 2, or 3.",
			abEyeJack: "Draw 2 cards, then discard 2 cards.",
			abEyeQueen: "Look at the top 3 cards of the deck and return them in the same order.",
			abEyeKing: "Name a suit. Draw 2 cards, then discard all cards of that suit.",
			abEyePrince: "Discard a card, then draw a card. Repeat once per other exhausted ally.",
			abEyeLady: "Draw 2 cards, then discard cards whose values sum exactly to those two cards' total.",
			abEyeBaron: "If your next response is even, draw a card after responding; if odd, discard a card.",
			abLeafJack: "Swap the current ruler with the ruler of an unvisited fief up to two fiefs away.",
			abLeafQueen: "Use the current ruler's ability.",
			abLeafKing: "Look at the top card of the deck and swap it with another card in your hand.",
			abLeafPrince: "Move the visit to the nearest unvisited fief with a higher or lower target.",
			abLeafLady: "Draw a card and ready another exhausted ally.",
			abLeafBaron: "You may swap a hand card with the discard pile's top card of equal value, then likewise with the score pile.",
			optMode: "Mode",
			modeIntro: "Introductory",
			modeFull: "Full game",
			optMedal: "Difficulty",
			medalBronze: "Standard 16★",
			medalSilver: "Advanced 18★",
			medalGold: "Idealist 20★",
			promptFief: "Choose an unvisited fief",
			promptSub: "Friendly rulers may substitute for allies, or start the dialogue",
			promptAlly: "Activate an ally ability, or talk directly",
			promptRespond: "Respond: follow {{suit}} if able",
			promptRespondFree: "Respond: any card",
			promptPrince: "Keep drawing, or stop?",
			promptPeek: "Top 3 cards of the deck (drawn left first)",
			promptSuit: "Name a suit",
			promptPickClawLady: "Discard your lowest-valued card",
			promptPickClawBaron: "Choose a card; draw every card of that value from the deck",
			promptPickFlowerKing: "Discard two cards whose values sum to 9",
			promptPickFlowerPrince: "Discard one card of each duplicated value",
			promptPickFlowerLady: "Discard a card valued {{n}}",
			promptPickEyeJack: "Discard 2 cards",
			promptPickEyePrince: "Discard 1 and draw 1 ({{n}} left)",
			promptPickEyeLady: "Discard cards whose values sum to {{n}}",
			promptPickEyeBaron: "Odd response: discard 1 card",
			promptPickLeafKing: "Choose a hand card to put back on the deck",
			promptPickLeafBaron: "Swap with a card valued {{n}}, or decline",
			promptPickFiefJack: "Choose the fief to swap rulers with",
			promptPickFiefPrince: "Choose the fief to move the visit to",
			promptPickAlly: "Ready which ally?",
			visitWon: "Won over! The ruler turns friendly",
			visitLost: "Failed — the ruler leaves",
			visitScore: "Score {{score}} / target {{target}}",
			visitStars: "+{{n}} ★",
			cont: "Continue",
			deckLabel: "Deck",
			discardLabel: "Discard",
			scoreLabel: "Score",
			targetLabel: "Target",
			alliesLabel: "Allies",
			trumpLabel: "Trump",
			subDone: "Confirm",
			subSkip: "No substitutes",
			subPickRuler: "Tap a friendly ruler first",
			subPickSlot: "Then tap an ally slot",
			subReady: "Substitute selected. Tap its slot to undo, or confirm",
			pass: "Talk",
			activate: "Activate",
			cancel: "Cancel",
			ok: "Got it",
			confirm: "Confirm",
			decline: "No swap",
			princeMore: "Draw",
			princeStop: "Stop",
			concede: "Concede",
			concedeConfirm: "Confirm concede",
			usedLabel: "Used",
			subTag: "Sub",
			soloLabel: "Lone traveler",
			youLabel: "You",
			starsEarned: "Stars earned",
			fiefsLabel: "Eight fiefs",
			fiefRange: "Targets 0–7",
			tableLabel: "Dialogue table",
			fiefOpen: "Unvisited",
			selectedLabel: "Selected",
			visitingLabel: "Visiting",
			previewFief: "Next visit · Fief {{n}}",
			visitingFief: "Visiting · Fief {{n}}",
			awaitFief: "Choose a fief",
			scoreProgress: "{{score}} / {{target}} tricks",
			rulerStatement: "Ruler speaks",
			yourResponse: "Your reply",
			emptyStatement: "Awaiting card",
			emptyResponse: "Tap hand",
			allyLimit: "Once each per visit",
			availableLabel: "Ready",
			handLabel: "Hand",
			handCount: "{{n}} cards in hand",
			legalCount: "{{n}} playable",
			tapHandRespond: "Tap a playable card to respond",
			tapHighlighted: "Tap a highlighted target",
			fxHit: "Trick won",
			fxMiss: "Discarded",
			overWin: "Northwood united!",
			overLose: "Talks broke down",
			overScore: "Stars",
			overTarget: "Victory line {{n}}",
			fiefWon: "Friendly",
			fiefLost: "Not convinced",
			medalEarned: "{{medal}} medal earned",
			logVisit: "Visiting fief {{n}}",
			logWon: "Won over fief {{n}}",
			logLost: "Fief {{n}} unconvinced",
			logConcede: "Conceded early",
			logAbility: "Used {{name}}’s ability",
			logHit: "Played {{card}} and won the trick",
			logMiss: "Played {{card}} and lost the trick",
			errInvalid: "Not allowed right now"
		}
	}
};
//#endregion
export { $ as default };
