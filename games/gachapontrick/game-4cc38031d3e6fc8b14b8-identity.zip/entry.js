import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useI18nSettings as r, useT as i } from "@bgparty/sdk/i18n";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { useWakeLock as o } from "@bgparty/sdk/use-wake-lock";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { seatName as l } from "@bgparty/sdk/ui/player-strip";
import { usePrefersReducedMotion as u } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Floater as m, FlySprite as h, PulseBox as g } from "@bgparty/sdk/fx/primitives";
//#region src/games/gachapontrick/data.ts
var _ = [
	"motorcycle",
	"octopus",
	"cactus",
	"frog",
	"pig",
	"robot",
	"slime"
], v = [
	"blue",
	"cyan",
	"green",
	"red",
	"purple",
	"gray",
	"yellow"
], y = [
	"#2564a0",
	"#32b8c5",
	"#218746",
	"#d93e63",
	"#98245f",
	"#8b9294",
	"#b3aa08"
], b = [
	"●",
	"◆",
	"▲",
	"♥",
	"★",
	"■",
	"✦"
], x = [
	[
		0,
		1,
		2,
		3,
		4,
		5,
		6
	],
	[
		2,
		3,
		4,
		5,
		6,
		0,
		1
	],
	[
		6,
		0,
		1,
		2,
		3,
		4,
		5
	],
	[
		5,
		6,
		0,
		1,
		2,
		3,
		4
	],
	[
		3,
		4,
		5,
		6,
		0,
		1,
		2
	],
	[
		4,
		5,
		6,
		0,
		1,
		2,
		3
	],
	[
		1,
		2,
		3,
		4,
		5,
		6,
		0
	]
], S = (e) => Math.floor(e / 7), C = (e) => (e % 7 + 2) * 100, w = (e) => x[S(e)][e % 7];
function T(e) {
	let t = Array(7).fill(0);
	for (let n of e) t[w(n)] += 1;
	return t;
}
//#endregion
//#region src/games/gachapontrick/meta.ts
var E = {
	id: "gachapontrick",
	tier: "alpha",
	mechanics: ["trick-taking", "set-collection"],
	interactionTags: [],
	nameKey: "games.gachapontrick.name",
	descKey: "games.gachapontrick.desc",
	rulesKey: "games.gachapontrick.rules",
	icon: "🫧",
	iconImg: "games/gachapontrick.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/63711481628535531/95EB645EADC2961D00EFAE83B1840042824FE872/" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#db292b",
	releasedAt: "2026-11-06T01:40:00+08:00",
	search: {
		py: "niu dan shou cang jia",
		init: "ndscj"
	},
	hotseat: "cover"
}, D = t.int().min(0).max(48), O = t.string(), k = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: D
	}),
	t.object({
		type: t.literal("buy"),
		card: D
	}),
	t.object({ type: t.literal("random") }),
	t.object({ type: t.literal("finish") }),
	t.object({
		type: t.literal("refund"),
		card: D
	}),
	t.object({ type: t.literal("ready") }),
	t.object({ type: t.literal("continue") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), A = t.object({
	round: t.int(),
	collection: t.array(D),
	counts: t.array(t.int()),
	sets: t.int(),
	money: t.int(),
	cashPoints: t.int(),
	bonus: t.int(),
	points: t.int()
}), j = t.object({
	phase: t.enum([
		"play",
		"move",
		"award",
		"buy",
		"solo",
		"clear",
		"refund",
		"scored",
		"done"
	]),
	round: t.int(),
	trickNo: t.int(),
	turn: O.nullable(),
	leader: O,
	winner: O.nullable(),
	players: t.array(t.object({
		rid: O,
		money: t.int(),
		collection: t.array(D),
		refund: t.boolean(),
		out: t.boolean(),
		handCount: t.int(),
		drawCount: t.int(),
		spent: t.boolean(),
		score: t.int(),
		history: t.array(A)
	})),
	trick: t.array(t.object({
		rid: O,
		card: D,
		boughtBy: O.nullable()
	})),
	deckCount: t.int(),
	bought: t.int(),
	randomBought: t.boolean(),
	ready: t.array(O),
	lastRandom: t.int().min(-1).max(48).nullable()
}), M = t.object({ hand: t.array(D) }), N = {
	play: 480,
	award: 850,
	buy: 620,
	clear: 420,
	deal: 850
};
function P(t, n) {
	for (let r = n.length - 1; r > 0; --r) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function F(e) {
	let t = P(e, Array.from({ length: 49 }, (e, t) => t)), n = e.players.length === 3 ? 12 : 10;
	for (let r of e.players) r.hand = t.splice(0, n).sort((e, t) => e - t), r.draw = e.players.length === 2 ? t.splice(0, 10) : [], r.money = e.players.length === 2 ? 8e3 : 5e3, r.collection = [], r.refund = !1, r.out = !1, r.spent = !1;
	return e.deck = P(e, [...t, -1]), e.discard = [], e.trick = [], e.turn = e.leader, e.winner = null, e.bought = 0, e.randomBought = !1, e.ready = [], e.lastRandom = null, e.trickNo = 1, e.phase = "move", e.resume = "play", e.beat = N.deal, e.players.map((e, t) => ({
		kind: "deal",
		rid: e.rid,
		data: { count: n },
		for: [e.rid],
		secret: { cards: e.hand },
		...t ? { with: !0 } : {}
	}));
}
function I(t, n, r) {
	let i = {
		players: n.map((e) => ({
			rid: e,
			hand: [],
			draw: [],
			money: 0,
			collection: [],
			refund: !1,
			out: !1,
			spent: !1,
			score: 0,
			history: []
		})),
		deck: [],
		discard: [],
		trick: [],
		phase: "play",
		resume: "play",
		round: 1,
		trickNo: 1,
		leader: n[e(r, 0, n.length)],
		turn: null,
		winner: null,
		bought: 0,
		randomBought: !1,
		ready: [],
		lastRandom: null,
		seed: r,
		cursor: 1,
		beat: 0
	};
	return {
		state: i,
		fx: F(i)
	};
}
function L(e, t) {
	let n = new Set(t.map((e) => S(e.card))), r = e.filter((e) => n.has(S(e)));
	return r.length ? r : e;
}
function R(e) {
	let t = Array(7).fill(0);
	for (let n of e) t[S(n.card)] += 1;
	return e.map((e, t) => t).sort((n, r) => t[S(e[r].card)] - t[S(e[n].card)] || C(e[r].card) - C(e[n].card) || r - n);
}
function z(e, t, n) {
	let r = e.players.findIndex((e) => e.rid === t);
	for (let t = 1; t <= e.players.length; t += 1) {
		let i = e.players[(r + t) % e.players.length];
		if (n(i)) return i;
	}
}
var B = (e) => !e.out && e.hand.length > 0;
function V(e) {
	e.phase = "refund", e.turn = null, e.ready = [], e.trick = [], e.winner = null;
}
function H(e) {
	let t = e.players.filter(B);
	if (e.bought = 0, e.randomBought = !1, e.lastRandom = null, !t.length) {
		V(e);
		return;
	}
	if (t.length === 1) {
		e.phase = "solo", e.turn = t[0].rid, e.winner = t[0].rid;
		return;
	}
	t.some((t) => t.rid === e.leader) || (e.leader = z(e, e.leader, B).rid), e.phase = "play", e.turn = e.leader;
}
function U(e) {
	e.discard.push(...e.trick.filter((e) => e.boughtBy === null).map((e) => e.card)), e.trick = [];
	let t = [];
	for (let n of e.players) if (n.money < 200) n.out = !0, e.discard.push(...n.hand, ...n.draw), n.hand = [], n.draw = [];
	else if (e.players.length === 2 && n.draw.length) {
		let e = n.draw.splice(0, 2);
		n.hand = [...n.hand, ...e].sort((e, t) => e - t), t.push({
			kind: "deal",
			rid: n.rid,
			data: { count: e.length },
			for: [n.rid],
			secret: { cards: e },
			...t.length ? { with: !0 } : {}
		});
	}
	return e.leader = e.players.length === 2 ? z(e, e.leader, () => !0).rid : e.winner ?? e.leader, e.winner = null, e.trickNo += 1, H(e), t.length && e.phase === "play" && (e.phase = "move", e.resume = "play", e.beat = N.deal), t;
}
function W(e) {
	let t = R(e.trick), n = e.trick[t[0]].rid, r = t.map((t) => e.players.find((n) => n.rid === e.trick[t].rid)).find((t) => !t.out && e.trick.some((e) => C(e.card) <= t.money));
	e.winner = r?.rid ?? n, e.turn = r?.rid ?? null, e.phase = "award", e.beat = N.award;
}
function G(e) {
	for (let t of e.players) {
		let n = T(t.collection), r = n.reduce((e, t) => e + t * t, 0), i = Math.floor(t.money / 200), a = t.spent ? 0 : 5, o = r + i + a;
		t.history.push({
			round: e.round,
			collection: [...t.collection],
			counts: n,
			sets: r,
			money: t.money,
			cashPoints: i,
			bonus: a,
			points: o
		}), t.score += o;
	}
	e.ready = [], e.turn = null, e.phase = e.round === 3 ? "done" : "scored";
}
var K = (e) => ({ code: `games.gachapontrick.${e}` });
function q(t, n, r) {
	if (n.type === "tick") {
		if (![
			"move",
			"award",
			"clear"
		].includes(t.phase)) return {
			state: t,
			fx: []
		};
		let e = structuredClone(t);
		if (e.phase === "clear") return {
			state: e,
			fx: U(e)
		};
		if (e.phase === "award") e.turn === null ? (e.phase = "clear", e.beat = N.clear) : e.phase = "buy";
		else if (e.resume === "award") return W(e), {
			state: e,
			fx: [{
				kind: "award",
				rid: e.winner,
				data: { buyer: e.turn }
			}]
		};
		else e.phase = e.resume;
		return {
			state: e,
			fx: []
		};
	}
	if (!t.players.find((e) => e.rid === r.by) || t.phase === "done") return K("errTurn");
	let i = structuredClone(t), a = i.players.find((e) => e.rid === r.by);
	if (n.type === "ready" || n.type === "refund") return i.phase !== "refund" || i.ready.includes(r.by) ? K("errTurn") : n.type === "refund" ? !a.refund || !a.collection.includes(n.card) ? K("errRefund") : (a.refund = !1, a.collection = a.collection.filter((e) => e !== n.card), a.money += C(n.card), i.discard.push(-1, n.card), {
		state: i,
		fx: [{
			kind: "refund",
			rid: a.rid,
			data: {
				card: n.card,
				money: C(n.card)
			}
		}]
	}) : (i.ready.push(r.by), i.ready.length === i.players.length && G(i), {
		state: i,
		fx: []
	});
	if (n.type === "continue") {
		if (i.phase !== "scored" || i.ready.includes(r.by)) return K("errTurn");
		if (i.ready.push(r.by), i.ready.length < i.players.length) return {
			state: i,
			fx: []
		};
		let t = Math.max(...i.players.map((e) => e.score)), n = i.players.filter((e) => e.score === t);
		return i.leader = n[e(i.seed, i.cursor++, n.length)].rid, i.round += 1, {
			state: i,
			fx: F(i)
		};
	}
	if (i.turn !== r.by) return K("errTurn");
	if (n.type === "play") {
		if (i.phase !== "play") return K("errTurn");
		if (!a.hand.includes(n.card)) return K("errCard");
		if (!L(a.hand, i.trick).includes(n.card)) return K("errFollow");
		let e = a.hand.indexOf(n.card);
		a.hand = a.hand.filter((e) => e !== n.card), i.trick.push({
			rid: r.by,
			card: n.card,
			boughtBy: null
		});
		let t = i.players.length === 2 ? 4 : i.players.filter((e) => !e.out && (e.hand.length > 0 || i.trick.some((t) => t.rid === e.rid))).length, o = i.trick.length >= t;
		return i.phase = "move", i.resume = o ? "award" : "play", i.beat = N.play, o || (i.turn = z(i, r.by, B).rid), {
			state: i,
			fx: [{
				kind: "play",
				rid: a.rid,
				data: {
					card: n.card,
					slot: i.trick.length - 1
				},
				for: [a.rid],
				secret: {
					handIndex: e,
					first: a.hand[0],
					second: a.hand[1]
				}
			}]
		};
	}
	if (i.phase !== "buy" && i.phase !== "solo") return K("errTurn");
	let o = i.phase === "solo";
	if (n.type === "finish") return !o && !i.bought ? K("errRequired") : (o ? (i.discard.push(...a.hand, ...a.draw), a.hand = [], a.draw = [], V(i)) : (i.phase = "clear", i.beat = N.clear), {
		state: i,
		fx: []
	});
	if (n.type === "random") {
		if (i.randomBought || !i.deck.length) return K("errRandom");
		if (a.money < 500) return K("errMoney");
		if (!o && !i.bought && !i.trick.some((e) => e.boughtBy === null && C(e.card) <= a.money - 500)) return K("errRequired");
		let e = i.deck.shift();
		return a.money -= 500, a.spent = !0, i.randomBought = !0, i.lastRandom = e, e === -1 ? a.refund = !0 : a.collection.push(e), i.phase = "move", i.resume = o ? "solo" : "buy", i.beat = N.buy, {
			state: i,
			fx: [{
				kind: "buy",
				rid: a.rid,
				data: {
					card: e,
					money: 500,
					from: "machine"
				}
			}]
		};
	}
	if (n.type !== "buy") return K("errTurn");
	if (!(o ? a.hand.includes(n.card) : i.trick.some((e) => e.card === n.card && e.boughtBy === null))) return K("errCard");
	if (C(n.card) > a.money) return K("errMoney");
	let s = i.trick.findIndex((e) => e.card === n.card), c = a.hand.indexOf(n.card);
	return o ? a.hand = a.hand.filter((e) => e !== n.card) : i.trick[s].boughtBy = r.by, a.money -= C(n.card), a.collection.push(n.card), a.spent = !0, i.bought += 1, i.phase = "move", i.resume = o ? "solo" : "buy", i.beat = N.buy, {
		state: i,
		fx: [{
			kind: "buy",
			rid: a.rid,
			data: {
				card: n.card,
				money: C(n.card),
				from: o ? "hand" : `slot:${s}`
			},
			...o ? {
				for: [a.rid],
				secret: {
					handIndex: c,
					first: a.hand[0],
					second: a.hand[1]
				}
			} : {}
		}]
	};
}
function ee(e, t) {
	return {
		public: {
			phase: e.phase,
			round: e.round,
			trickNo: e.trickNo,
			turn: e.turn,
			leader: e.leader,
			winner: e.winner,
			players: e.players.map(({ hand: e, draw: t, ...n }) => ({
				...n,
				handCount: e.length,
				drawCount: t.length
			})),
			trick: e.trick,
			deckCount: e.deck.length,
			bought: e.bought,
			randomBought: e.randomBought,
			ready: e.ready,
			lastRandom: e.lastRandom
		},
		private: { hand: e.players.find((e) => e.rid === t)?.hand ?? [] }
	};
}
function te(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((e, t) => t.score - e.score || t.money - e.money);
	return {
		phase: "done",
		ranking: t.map((e) => e.rid),
		winner: t.filter((e) => e.score === t[0].score && e.money === t[0].money).map((e) => e.rid),
		scores: Object.fromEntries(t.map((e) => [e.rid, e.score]))
	};
}
var ne = {
	meta: E,
	saveCompatibility: { version: "1" },
	schemas: {
		action: k,
		publicView: j,
		privateView: M
	},
	setup: I,
	reduce: q,
	viewFor: ee,
	status: te,
	nextTickIn: (e) => [
		"move",
		"award",
		"clear"
	].includes(e.phase) ? e.beat : null
};
//#endregion
//#region src/games/gachapontrick/card.tsx
function re() {
	let e = u();
	return /* @__PURE__ */ f("svg", {
		className: "gt-ants",
		viewBox: "0 0 100 146",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ f("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "142",
			rx: "8",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2.2",
			strokeDasharray: "7 5",
			children: !e && /* @__PURE__ */ f("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-24",
				dur: "1.3s",
				repeatCount: "indefinite"
			})
		})
	});
}
function J({ card: e, onClick: t, legal: n = !1, selected: r = !1, anchor: a, className: o = "", style: c }) {
	let l = i(), u = s(a ?? null), m = S(e), h = w(e), g = l("games.gachapontrick.cardLabel", {
		suit: l(`games.gachapontrick.${v[m]}`),
		toy: l(`games.gachapontrick.${_[h]}`),
		price: C(e)
	}), x = /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ p("span", {
			className: "gt-price",
			children: [
				"¥",
				C(e),
				/* @__PURE__ */ f("span", { children: b[m] })
			]
		}),
		/* @__PURE__ */ f("span", {
			className: "gt-art",
			children: /* @__PURE__ */ f("img", {
				src: `games/gachapontrick/toy-${e}.webp`,
				alt: "",
				draggable: !1
			})
		}),
		/* @__PURE__ */ f("span", {
			className: "gt-toy-name",
			children: l(`games.gachapontrick.${_[h]}`)
		}),
		n && /* @__PURE__ */ f(re, {})
	] }), T = {
		ref: u.ref,
		className: `gt-card ${o}${r ? " is-selected" : ""}${n ? " is-legal" : ""}`,
		style: {
			"--gt-suit": y[m],
			visibility: u.hidden ? "hidden" : void 0,
			...c
		},
		"aria-label": g
	};
	return t ? /* @__PURE__ */ f("button", {
		type: "button",
		...T,
		onClick: t,
		"aria-pressed": r,
		children: x
	}) : /* @__PURE__ */ f("span", {
		...T,
		children: x
	});
}
function Y({ className: e = "" }) {
	return /* @__PURE__ */ p("svg", {
		className: e,
		viewBox: "0 0 100 100",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("circle", {
				cx: "50",
				cy: "50",
				r: "43",
				fill: "#b9dfeb",
				stroke: "#252529",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M12 31C36 40 62 58 82 80A43 43 0 0 1 12 31",
				fill: "#ec4442",
				stroke: "#252529",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M31 14Q47 10 62 17",
				fill: "none",
				stroke: "#fff",
				strokeWidth: "5",
				strokeLinecap: "round"
			})
		]
	});
}
//#endregion
//#region src/games/gachapontrick/view-player.tsx
function X({ name: e, className: t, children: n }) {
	let { ref: r, hidden: i } = s(e);
	return /* @__PURE__ */ f("div", {
		ref: r,
		className: t,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function Z({ cards: e, onPick: t }) {
	let n = i(), r = T(e);
	return /* @__PURE__ */ f("div", {
		className: "gt-collection-grid",
		children: _.map((i, a) => {
			let o = e.find((e) => w(e) === a) ?? a;
			return /* @__PURE__ */ p("div", {
				className: "gt-collection-type",
				children: [
					/* @__PURE__ */ f("img", {
						src: `games/gachapontrick/toy-${o}.webp`,
						alt: n(`games.gachapontrick.${i}`)
					}),
					/* @__PURE__ */ f("b", { children: r[a] }),
					t && e.filter((e) => w(e) === a).map((e) => /* @__PURE__ */ f(J, {
						card: e,
						legal: !0,
						onClick: () => t(e)
					}, e))
				]
			}, i);
		})
	});
}
function ie({ public: e, private: t, members: s, myRid: u, send: m }) {
	o();
	let h = i(), g = r((e) => e.locale), v = e, y = t, [b, x] = n(null), [S, T] = n(null), [E, D] = n(null), O = v.players.find((e) => e.rid === u), k = (e) => {
		let t = s.find((t) => t.rid === e);
		return t ? l(t, g) : e;
	}, A = v.turn === u, j = v.phase === "play" && A, M = (v.phase === "buy" || v.phase === "solo") && A, N = y?.hand ?? [], P = j ? L(N, v.trick) : M && v.phase === "solo" ? N.filter((e) => C(e) <= (O?.money ?? 0)) : [], F = v.trick.filter((e) => e.boughtBy === null).map((e) => e.card).filter((e) => C(e) <= (O?.money ?? 0)), I = b?.phase === v.phase && b.round === v.round && b.trick === v.trickNo && (j || v.phase === "solo" ? P : F).includes(b.card) ? b.card : null, R = (e) => x({
		card: e,
		phase: v.phase,
		round: v.round,
		trick: v.trickNo
	}), z = (e) => {
		x(null), D(null), m(e);
	}, B = v.ready.includes(u), V = v.phase === "award" ? v.turn ? h("games.gachapontrick.award", { name: k(v.turn) }) : h("games.gachapontrick.noBuyer") : v.phase === "refund" ? B ? h("games.gachapontrick.acknowledged") : O?.refund ? h("games.gachapontrick.refundPrompt") : h("games.gachapontrick.roundFinished") : v.phase === "scored" ? h("games.gachapontrick.roundFinished") : j ? h("games.gachapontrick.playPrompt") : M ? v.phase === "solo" ? h("games.gachapontrick.soloPrompt") : v.bought ? h("games.gachapontrick.buyMore") : h("games.gachapontrick.buyPrompt") : ["move", "clear"].includes(v.phase) ? h("games.gachapontrick.resolving") : h("games.gachapontrick.waiting", { name: v.turn ? k(v.turn) : "" }), H = M && !v.randomBought && v.deckCount > 0 && (O?.money ?? 0) >= 500 && (v.phase === "solo" || v.bought > 0 || F.some((e) => C(e) <= (O?.money ?? 0) - 500)), U = v.players.find((e) => e.rid === S), W = v.phase === "refund" && !B && O?.refund, G = /* @__PURE__ */ p("header", {
		className: "gt-header",
		children: [/* @__PURE__ */ p("div", {
			className: "gt-heading",
			children: [/* @__PURE__ */ f("strong", { children: h("games.gachapontrick.name") }), /* @__PURE__ */ p("span", { children: [
				h("games.gachapontrick.round", { n: v.round }),
				" / 3 · ",
				h("games.gachapontrick.trick", { n: v.trickNo })
			] })]
		}), /* @__PURE__ */ f("div", {
			className: "gt-players",
			children: v.players.map((e) => /* @__PURE__ */ f(X, {
				name: `seat:${e.rid}`,
				className: `gt-seat${e.rid === v.turn ? " is-turn" : ""}${e.out ? " is-out" : ""}`,
				children: /* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => T(e.rid),
					"aria-label": h("games.gachapontrick.collectionOf", { name: k(e.rid) }),
					children: [
						/* @__PURE__ */ p("span", {
							className: "gt-seat-name",
							children: [k(e.rid), e.rid === u && /* @__PURE__ */ p("small", { children: [" · ", h("lobby.you")] })]
						}),
						/* @__PURE__ */ p("span", {
							className: "gt-seat-money",
							children: [
								"¥",
								e.money,
								/* @__PURE__ */ f("small", { children: h("games.gachapontrick.points", { n: e.score }) })
							]
						}),
						/* @__PURE__ */ p("span", {
							className: "gt-seat-counts",
							children: [
								e.out ? h("games.gachapontrick.out") : h("games.gachapontrick.handCount", { n: e.handCount }),
								e.drawCount > 0 && ` · ${h("games.gachapontrick.drawCount", { n: e.drawCount })}`,
								e.refund && /* @__PURE__ */ f("b", { children: " ¥↩" })
							]
						})
					]
				})
			}, e.rid))
		})]
	}), K = /* @__PURE__ */ p("div", {
		className: "gt-actions",
		children: [/* @__PURE__ */ f("p", {
			role: "status",
			children: V
		}), /* @__PURE__ */ p("div", {
			className: "gt-action-buttons",
			children: [
				I !== null && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
					type: "button",
					className: "gt-button gt-quiet",
					onClick: () => x(null),
					children: h("games.gachapontrick.cancel")
				}), /* @__PURE__ */ f("button", {
					type: "button",
					className: "gt-button",
					onClick: () => z({
						type: j ? "play" : "buy",
						card: I
					}),
					children: h(j ? "games.gachapontrick.confirmPlay" : "games.gachapontrick.confirmBuy")
				})] }),
				I === null && M && /* @__PURE__ */ f("button", {
					type: "button",
					className: "gt-button",
					disabled: v.phase !== "solo" && v.bought === 0,
					onClick: () => z({ type: "finish" }),
					children: h("games.gachapontrick.finish")
				}),
				v.phase === "refund" && !B && /* @__PURE__ */ f("button", {
					type: "button",
					className: "gt-button",
					onClick: () => z({ type: "ready" }),
					children: h("games.gachapontrick.scoreRound")
				}),
				v.phase === "scored" && !B && /* @__PURE__ */ f("button", {
					type: "button",
					className: "gt-button",
					onClick: () => z({ type: "continue" }),
					children: h("games.gachapontrick.nextRound")
				})
			]
		})]
	});
	return /* @__PURE__ */ p(c, {
		adaptive: !0,
		className: "gt-screen",
		scroll: !1,
		banner: G,
		actions: K,
		actionsHeight: "gt-action-slot",
		children: [/* @__PURE__ */ p("div", {
			className: "gt-main",
			children: [
				/* @__PURE__ */ p("div", {
					className: "gt-table",
					children: [/* @__PURE__ */ f("div", {
						className: "gt-trick",
						children: Array.from({ length: 4 }, (e, t) => {
							let n = v.trick[t], r = M && n?.boughtBy === null && F.includes(n.card) && v.phase === "buy";
							return /* @__PURE__ */ p(X, {
								name: `slot:${t}`,
								className: `gt-slot${n?.boughtBy ? " is-bought" : ""}`,
								children: [
									/* @__PURE__ */ f("span", {
										className: "gt-slot-name",
										children: n ? k(n.rid) : /* @__PURE__ */ f("span", {
											"aria-hidden": !0,
											children: "○"
										})
									}),
									n ? /* @__PURE__ */ f(J, {
										card: n.card,
										legal: r,
										selected: I === n.card,
										onClick: r ? () => R(n.card) : void 0,
										anchor: `table:${n.card}`
									}) : /* @__PURE__ */ f("span", {
										className: "gt-empty-card",
										"aria-hidden": !0,
										children: /* @__PURE__ */ f(Y, {})
									}),
									n?.boughtBy && /* @__PURE__ */ f("span", {
										className: "gt-bought-stamp",
										children: h("games.gachapontrick.bought")
									})
								]
							}, t);
						})
					}), /* @__PURE__ */ f(X, {
						name: "machine",
						className: "gt-machine",
						children: /* @__PURE__ */ p("button", {
							type: "button",
							disabled: !H,
							onClick: () => z({ type: "random" }),
							"aria-label": h("games.gachapontrick.randomBuy"),
							children: [
								/* @__PURE__ */ p("div", {
									className: "gt-globe",
									children: [
										/* @__PURE__ */ f(Y, {}),
										/* @__PURE__ */ f(Y, {}),
										/* @__PURE__ */ f(Y, {})
									]
								}),
								/* @__PURE__ */ f("strong", { children: "¥500" }),
								/* @__PURE__ */ f("span", {
									className: "gt-knob",
									"aria-hidden": !0,
									children: "↻"
								}),
								/* @__PURE__ */ f("small", { children: h("games.gachapontrick.remaining", { n: v.deckCount }) }),
								v.lastRandom !== null && /* @__PURE__ */ f("span", {
									className: "gt-last-random",
									children: v.lastRandom === -1 ? h("games.gachapontrick.refund") : h(`games.gachapontrick.${_[w(v.lastRandom)]}`)
								})
							]
						})
					})]
				}),
				/* @__PURE__ */ p(X, {
					name: `collection:${u}`,
					className: "gt-my-collection",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						className: "gt-collection-open",
						onClick: () => T(u),
						"aria-label": h("games.gachapontrick.collection"),
						children: [/* @__PURE__ */ f(Z, { cards: O?.collection ?? [] }), O?.refund && /* @__PURE__ */ f("span", {
							className: "gt-refund-token",
							children: "¥↩"
						})]
					}), W && /* @__PURE__ */ f("button", {
						type: "button",
						className: "gt-refund-open",
						onClick: () => T(u),
						children: h("games.gachapontrick.refund")
					})]
				}),
				/* @__PURE__ */ f(X, {
					name: "hand",
					className: "gt-hand",
					children: /* @__PURE__ */ f("div", {
						className: "gt-hand-rail",
						children: N.map((e) => /* @__PURE__ */ f(J, {
							card: e,
							anchor: `hand:${e}`,
							legal: P.includes(e),
							selected: I === e,
							onClick: P.includes(e) ? () => R(e) : void 0,
							className: j && !P.includes(e) ? "is-unavailable" : ""
						}, e))
					})
				}),
				v.phase === "scored" && /* @__PURE__ */ f("div", {
					className: "gt-round-overlay",
					children: /* @__PURE__ */ p("div", {
						className: "gt-round-paper",
						children: [/* @__PURE__ */ f("h2", { children: h("games.gachapontrick.round", { n: v.round }) }), v.players.map((e) => /* @__PURE__ */ p("button", {
							onClick: () => T(e.rid),
							type: "button",
							children: [
								/* @__PURE__ */ f("b", { children: k(e.rid) }),
								/* @__PURE__ */ f("span", { children: h("games.gachapontrick.roundPoints", { n: e.history.at(-1)?.points ?? 0 }) }),
								/* @__PURE__ */ f("strong", { children: h("games.gachapontrick.points", { n: e.score }) })
							]
						}, e.rid))]
					})
				})
			]
		}), /* @__PURE__ */ f(a, {
			open: S !== null,
			onClose: () => {
				T(null), D(null);
			},
			label: h("games.gachapontrick.collection"),
			title: U ? h("games.gachapontrick.collectionOf", { name: k(U.rid) }) : h("games.gachapontrick.collection"),
			footer: E !== null && S === u && W ? /* @__PURE__ */ p("button", {
				type: "button",
				className: "gt-button",
				onClick: () => {
					z({
						type: "refund",
						card: E
					}), T(null);
				},
				children: [
					h("games.gachapontrick.confirmRefund"),
					" · ¥",
					C(E)
				]
			}) : void 0,
			children: /* @__PURE__ */ f("div", {
				className: "gt-detail",
				children: U && /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ f(Z, { cards: U.collection }),
					/* @__PURE__ */ f("div", {
						className: "gt-detail-cards",
						children: U.collection.map((e) => /* @__PURE__ */ f(J, {
							card: e,
							selected: E === e,
							legal: !!W && S === u,
							onClick: W && S === u ? () => D(e) : void 0
						}, e))
					}),
					U.history.map((e) => /* @__PURE__ */ p("div", {
						className: "gt-history",
						children: [/* @__PURE__ */ p("b", { children: [
							h("games.gachapontrick.round", { n: e.round }),
							" · ",
							e.points
						] }), /* @__PURE__ */ p("span", { children: [
							h("games.gachapontrick.sets"),
							": ",
							e.sets,
							" · ",
							h("games.gachapontrick.cashPoints"),
							": ",
							e.cashPoints,
							" · ",
							h("games.gachapontrick.bonus"),
							": ",
							e.bonus
						] })]
					}, e.round))
				] })
			})
		})]
	});
}
//#endregion
//#region src/games/gachapontrick/bot.ts
var ae = {
	cashValue: 1,
	prospect: .15,
	reserve: 0
};
function oe(e = ae) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (!i) return null;
		let a = T(i.collection), o = (t) => 2 * a[w(t)] + 1 + e.prospect * Math.max(0, 7 - a[w(t)]) - e.cashValue * C(t) / 200 - e.reserve * C(t) / Math.max(200, i.money);
		if (r.phase === "scored" && !r.ready.includes(n.rid)) return { action: { type: "continue" } };
		if (r.phase === "refund" && !r.ready.includes(n.rid)) {
			if (i.refund && i.collection.length) {
				let e = [...i.collection].sort((e, t) => C(t) / 200 - (2 * a[w(t)] - 1) - (C(e) / 200 - (2 * a[w(e)] - 1)));
				if (C(e[0]) / 200 > 2 * a[w(e[0])] - 1) return { action: {
					type: "refund",
					card: e[0]
				} };
			}
			return { action: { type: "ready" } };
		}
		if (r.turn !== n.rid) return null;
		if (r.phase === "play") {
			let e = L(t.private?.hand ?? [], r.trick);
			if (!e.length) return null;
			if (n.difficulty === "weak") return { action: {
				type: "play",
				card: e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length]
			} };
			let a = (e) => {
				let t = [...r.trick, {
					rid: n.rid,
					card: e
				}], a = t[R(t)[0]].rid === n.rid, s = t.filter((e) => C(e.card) <= i.money).map((e) => o(e.card)), c = s.length ? Math.max(...s) : -3;
				return (a ? c : 0) - o(e) * .12 - C(e) / 1e4;
			};
			return { action: {
				type: "play",
				card: [...e].sort((e, t) => a(t) - a(e) || e - t)[0]
			} };
		}
		if (r.phase !== "buy" && r.phase !== "solo") return null;
		let s = [...(r.phase === "solo" ? t.private?.hand ?? [] : r.trick.filter((e) => e.boughtBy === null).map((e) => e.card)).filter((e) => C(e) <= i.money)].sort((e, t) => o(t) - o(e) || C(e) - C(t));
		if (s.length && (r.phase === "buy" && r.bought === 0 || o(s[0]) > 0)) return { action: {
			type: "buy",
			card: s[0]
		} };
		let c = /* @__PURE__ */ new Set([
			...r.players.flatMap((e) => e.collection),
			...r.trick.map((e) => e.card),
			...t.private?.hand ?? []
		]), l = Array.from({ length: 49 }, (e, t) => t).filter((e) => !c.has(e)), u = l.reduce((t, n) => t + 2 * a[w(n)] + 1 + e.prospect * Math.max(0, 7 - a[w(n)]), 0) / Math.max(1, l.length) - e.cashValue * 2.5;
		return !r.randomBought && r.deckCount && i.money >= 500 && (r.phase === "solo" || r.bought > 0) && u > 0 ? { action: { type: "random" } } : { action: { type: "finish" } };
	};
}
var se = oe(), ce = (e, t, n) => e.type === "play" ? n("games.gachapontrick.playCard", { price: C(e.card) }) : e.type === "buy" ? n("games.gachapontrick.buyCard", { price: C(e.card) }) : e.type === "refund" ? n("games.gachapontrick.refundCard", { price: C(e.card) }) : e.type === "random" ? n("games.gachapontrick.randomBuy") : e.type === "finish" ? n("games.gachapontrick.finish") : e.type === "ready" ? n("games.gachapontrick.scoreRound") : e.type === "continue" ? n("games.gachapontrick.nextRound") : "";
//#endregion
//#region src/games/gachapontrick/fx.tsx
function Q(e, t) {
	return e === -1 ? /* @__PURE__ */ f("span", {
		className: "gt-button",
		style: {
			width: t.w,
			height: t.h,
			display: "grid",
			placeItems: "center",
			fontSize: Math.min(t.w, t.h) / 2
		},
		children: "¥↩"
	}) : /* @__PURE__ */ f(J, {
		card: e,
		style: {
			width: t.w,
			height: t.h,
			padding: 4
		}
	});
}
function le(e, t) {
	let n = e.anchor(`collection:${t}`) ?? e.anchor(`seat:${t}`);
	if (!n) return null;
	let r = Math.min(60, n.w / 7), i = r * 1.46;
	return {
		x: n.x + n.w / 2 - r / 2,
		y: n.y + n.h / 2 - i / 2,
		w: r,
		h: i
	};
}
function $(e, t) {
	let n = t, r = e.anchor("hand");
	if (!r) return null;
	let i = n?.first === void 0 ? null : e.anchor(`hand:${n.first}`), a = n?.second === void 0 ? null : e.anchor(`hand:${n.second}`), o = i?.h ?? r.h - 16, s = i?.w ?? o * 100 / 146, c = i && a ? a.x - i.x : s + 8;
	return {
		x: (i?.x ?? r.x + 5) + (n?.handIndex ?? 0) * c,
		y: i?.y ?? r.y + 6,
		w: s,
		h: o
	};
}
var ue = {
	play(e, t) {
		let n = e.data, r = t.anchor(`table:${n.card}`), i = e.rid === t.myRid ? $(t, e.secret) : t.anchor(`seat:${e.rid}`);
		if (!r || !i) return null;
		let a = e.rid === t.myRid ? i : {
			x: i.x + i.w / 2 - 30,
			y: i.y,
			w: 60,
			h: 87.6
		};
		return {
			ms: N.play,
			hide: [`table:${n.card}`],
			node: /* @__PURE__ */ f(h, {
				from: a,
				to: r,
				ms: N.play,
				children: Q(n.card, a)
			})
		};
	},
	award(e, t) {
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: N.award,
			node: /* @__PURE__ */ f(g, {
				at: n,
				ms: N.award
			})
		} : null;
	},
	buy(e, t) {
		let n = e.data, r = n.from === "machine" ? t.anchor("machine") : n.from === "hand" ? e.rid === t.myRid ? $(t, e.secret) : t.anchor(`seat:${e.rid}`) : t.anchor(`table:${n.card}`), i = le(t, e.rid), a = t.anchor(`seat:${e.rid}`);
		if (!i || !r) return null;
		let o = n.from === "machine" ? {
			x: r.x + r.w / 2 - 40,
			y: r.y + r.h / 2 - 58.4,
			w: 80,
			h: 116.8
		} : r;
		return {
			ms: N.buy,
			hide: n.from.startsWith("slot:") ? [`table:${n.card}`] : [],
			node: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(h, {
				from: o,
				to: i,
				ms: N.buy,
				children: Q(n.card, o)
			}), a && /* @__PURE__ */ f(m, {
				at: a,
				ms: N.buy,
				children: /* @__PURE__ */ p("span", {
					className: "gt-button",
					children: ["−¥", n.money]
				})
			})] })
		};
	},
	refund(e, t) {
		let n = e.data, r = t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: N.buy,
			node: /* @__PURE__ */ f(m, {
				at: r,
				ms: N.buy,
				children: /* @__PURE__ */ p("span", {
					className: "gt-button",
					children: ["+¥", n.money]
				})
			})
		} : null;
	},
	deal(e, t) {
		let n = t.anchor("machine"), r = t.anchor(`seat:${e.rid}`), i = e.secret?.cards;
		if (!n || !r) return null;
		if (i) {
			let e = i.map((e) => ({
				card: e,
				box: t.anchor(`hand:${e}`)
			})).filter((e) => e.box !== null);
			return {
				ms: N.deal,
				hide: e.map((e) => `hand:${e.card}`),
				node: e.map(({ card: e, box: t }, r) => /* @__PURE__ */ f(h, {
					from: n,
					to: t,
					ms: 430,
					delay: r * 30,
					children: Q(e, t)
				}, e))
			};
		}
		let a = {
			x: r.x + r.w / 2 - 20,
			y: r.y + r.h / 2 - 28,
			w: 40,
			h: 56
		};
		return {
			ms: N.deal,
			node: /* @__PURE__ */ f(h, {
				from: n,
				to: a,
				ms: 600,
				children: /* @__PURE__ */ f("span", {
					style: {
						display: "block",
						width: 50,
						height: 70
					},
					children: /* @__PURE__ */ f(Y, { className: "gt-deal-capsule" })
				})
			})
		};
	}
};
//#endregion
//#region src/games/gachapontrick/game-over.tsx
function de({ result: e, public: t, members: a, onPlayAgain: o, onBackToLobby: s }) {
	let c = t, u = i(), m = r((e) => e.locale), [h, g] = n(3), _ = (e) => {
		let t = a.find((t) => t.rid === e);
		return t ? l(t, m) : e;
	};
	return /* @__PURE__ */ p("div", {
		className: "gt-over",
		children: [
			/* @__PURE__ */ p("header", {
				className: "gt-over-heading",
				children: [/* @__PURE__ */ f("h1", { children: u("games.gachapontrick.resultTitle") }), /* @__PURE__ */ f("span", { children: u("games.gachapontrick.name") })]
			}),
			/* @__PURE__ */ f("div", {
				className: "gt-over-body",
				children: e.ranking.map((t, n) => {
					let r = c.players.find((e) => e.rid === t), i = r.history.find((e) => e.round === h);
					return /* @__PURE__ */ p("section", {
						className: `gt-over-person${e.winner.includes(t) ? " is-winner" : ""}`,
						children: [
							/* @__PURE__ */ p("h2", { children: [
								/* @__PURE__ */ f("span", {
									"aria-label": e.winner.includes(t) ? u("games.gachapontrick.winner") : void 0,
									children: e.winner.includes(t) ? "★" : n + 1
								}),
								_(t),
								/* @__PURE__ */ f("strong", {
									className: "gt-over-total",
									children: r.score
								})
							] }),
							/* @__PURE__ */ f("div", {
								className: "gt-over-rounds",
								children: [
									1,
									2,
									3
								].map((e) => /* @__PURE__ */ p("button", {
									type: "button",
									"aria-pressed": h === e,
									onClick: () => g(e),
									children: [
										u("games.gachapontrick.round", { n: e }),
										" · ",
										r.history.find((t) => t.round === e)?.points ?? 0
									]
								}, e))
							}),
							i && /* @__PURE__ */ p(d, { children: [
								/* @__PURE__ */ f(Z, { cards: i.collection }),
								/* @__PURE__ */ p("div", {
									className: "gt-over-breakdown",
									children: [
										/* @__PURE__ */ p("span", { children: [
											u("games.gachapontrick.sets"),
											" ",
											/* @__PURE__ */ f("b", { children: i.sets })
										] }),
										/* @__PURE__ */ p("span", { children: [
											u("games.gachapontrick.cashPoints"),
											" ",
											/* @__PURE__ */ f("b", { children: i.cashPoints })
										] }),
										/* @__PURE__ */ p("span", { children: [
											u("games.gachapontrick.bonus"),
											" ",
											/* @__PURE__ */ f("b", { children: i.bonus })
										] }),
										/* @__PURE__ */ p("span", { children: ["¥", i.money] })
									]
								}),
								/* @__PURE__ */ f("div", {
									className: "gt-over-cards",
									children: i.collection.map((e) => /* @__PURE__ */ f(J, { card: e }, e))
								})
							] })
						]
					}, t);
				})
			}),
			/* @__PURE__ */ p("footer", {
				className: "gt-over-actions",
				children: [
					o && /* @__PURE__ */ f("button", {
						type: "button",
						className: "gt-button",
						onClick: o,
						children: u("session.result.playAgain")
					}),
					s && /* @__PURE__ */ f("button", {
						type: "button",
						className: "gt-button gt-quiet",
						onClick: s,
						children: u("session.result.backToLobby")
					}),
					!o && !s && /* @__PURE__ */ f("p", { children: u("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/gachapontrick/entry.tsx
var fe = {
	definition: ne,
	View: ie,
	bot: se,
	describe: ce,
	fx: ue,
	OverView: de,
	locales: {
		zh: {
			name: "扭蛋收藏家",
			desc: "跟随颜色赢得吃墩，精打细算收集成套玩具",
			rules: "目标：进行三轮，累计分最高者获胜；总分相同时，最后一轮剩余现金较多的玩家获胜；若仍相同，则共享胜利。\n准备：\n· 49 张玩具牌分为七色，每色的价格为 ¥200 至 ¥800；七种玩具各有七张。每人获得 10 张手牌（三人时 12 张）及 ¥5000。余牌加入退款牌，作为公共随机牌堆。\n流程：\n· 先手玩家可以打出任意一张手牌。后续玩家如果有本墩已出现过的任一颜色，必须跟出其中一种；否则可以打出任意一张手牌。\n· 出现次数最多的颜色获胜；多个颜色并列时比较其中最高价格，再并列则后出的牌获胜。\n· 胜者必须购买至少一张本墩牌，也可购买更多；每墩另可花 ¥500 购买一次公共牌堆顶牌。盲抽不能代替从本墩购买卡牌的要求。如果在购买本墩卡牌之前进行盲抽，必须保留足以购买至少一张本墩卡牌的现金。\n· 本墩的胜者在下一墩首先出牌。如果胜者无法支付本墩任何一张牌的价格，购买权交给打出同色较低牌的玩家；之后按本墩各花色的张数、卡牌价格和出牌先后，依次确定下一位获得购买权的玩家。如果所有玩家均无法购买，则弃置本墩的全部卡牌。\n· 购买回合结束余款只有 ¥0 或 ¥100 时退出本轮，剩余手牌弃置；先手退出则顺时针顺延。只剩一人时，可购买其剩余手牌及一次公共随机牌。\n· 抽到退款牌后，将其保留至轮末。轮末可以弃置退款牌和一张已收藏的玩具牌，获得等于该玩具标价的现金；也可以放弃退款。\n结算：\n· 本轮手牌用尽后，每种玩具按数量的平方计分（1、4、9、16、25、36、49）。每剩余 ¥200，获得 1 分；整轮未进行任何消费的玩家，额外获得 5 分。\n· 每轮重新洗牌、恢复初始资金与手牌。累计领先者下一轮先出；同分以随机抽签代替猜拳。\n双人变化：\n· 每名玩家获得 ¥8000、10 张手牌及一个由 10 张牌组成的个人补牌堆。每墩交替出牌，双方各出两张。每墩后双方各补两张，个人牌堆用完后继续打完手牌。先手每墩交替。只剩一人时仅购买当时手牌，不继续个人补牌。",
			round: "第 {{n}} 轮",
			trick: "第 {{n}} 墩",
			points: "{{n}} 分",
			cash: "余款 ¥{{n}}",
			playPrompt: "选择一张手牌",
			buyPrompt: "购买至少一张本墩玩具",
			buyMore: "可以继续购买",
			soloPrompt: "可以购买剩余手牌",
			waiting: "等待 {{name}}",
			resolving: "正在结算",
			award: "{{name}} 获得购买权",
			noBuyer: "本墩无人能购买",
			playCard: "打出 ¥{{price}} 玩具",
			buyCard: "购买 ¥{{price}} 玩具",
			refundCard: "退还 ¥{{price}} 玩具",
			confirmPlay: "打出这张牌",
			confirmBuy: "购买这张牌",
			confirmRefund: "退还这张玩具",
			cancel: "取消",
			randomBuy: "随机购买 ¥500",
			randomDeck: "随机牌堆",
			remaining: "剩余 {{n}} 张",
			finish: "结束购买",
			scoreRound: "确认计分",
			nextRound: "开始下一轮",
			acknowledged: "已确认，等待其他玩家",
			refundPrompt: "可选择一件收藏退款，或直接计分",
			roundFinished: "本轮结束",
			collection: "收藏",
			collectionOf: "{{name}} 的收藏",
			hand: "手牌",
			out: "本轮已退出",
			bought: "已购",
			refund: "退款牌",
			handCount: "手牌 {{n}}",
			drawCount: "补牌 {{n}}",
			sets: "收藏得分",
			cashPoints: "余款得分",
			bonus: "节制奖励",
			total: "累计分",
			resultTitle: "收藏大赏",
			winner: "获胜",
			roundPoints: "本轮 {{n}} 分",
			viewRound: "查看第 {{n}} 轮",
			close: "关闭",
			toyCount: "{{toy}} {{n}} 件",
			toyPoints: "{{n}} 件 · {{points}} 分",
			empty: "尚无收藏",
			motorcycle: "摩托车",
			octopus: "章鱼",
			cactus: "仙人掌",
			frog: "青蛙马桶",
			pig: "小猪",
			robot: "机器人",
			slime: "史莱姆挂饰",
			blue: "蓝色",
			cyan: "青色",
			green: "绿色",
			red: "红色",
			purple: "紫色",
			gray: "灰色",
			yellow: "黄色",
			cardLabel: "{{suit}} {{toy}}，¥{{price}}",
			errTurn: "现在不能执行此操作",
			errCard: "这张牌不在可选范围内",
			errFollow: "必须跟出本墩已有的颜色",
			errMoney: "余款不足",
			errRequired: "请先购买一张本墩玩具，或为它保留足够余款",
			errRandom: "本次不能再随机购买",
			errRefund: "这件玩具不能退款"
		},
		en: {
			name: "Gachapon Trick",
			desc: "Win colorful tricks and spend wisely to collect matching toys",
			rules: "Goal: Score the most points over three rounds. Ties go to the most money left in the final round; equal ties are shared.\nSetup:\n· There are 49 toy cards: seven suits, each priced ¥200–¥800, and seven toy types. Each player receives 10 cards (12 with three players) and ¥5000. Shuffle the Refund into the remaining central deck.\nPlay:\n· The leader plays any card. Later players must follow any suit already in the trick if able; otherwise play any suit.\n· The most frequent suit wins. Among tied suits, the highest price wins; equal prices go to the later card.\n· The winner must buy at least one card from the trick and may buy more. Once per trick, they may also buy the top central card for ¥500. A random purchase never replaces the required trick purchase; reserve enough money for it.\n· The winner leads next. If they cannot afford any trick card, purchasing passes down the winning suit, then by suit frequency, price and play order. If nobody can afford a card, discard the trick.\n· Players ending their purchasing turn with ¥0 or ¥100 leave the round and discard their remaining cards. An unavailable leader passes clockwise. A sole remaining player may buy from their current hand and optionally once from the central deck.\n· Keep the Refund until round end. Discard it and one collected toy to recover that toy’s printed price, or decline.\nScoring:\n· Score each toy type as its count squared: 1, 4, 9, 16, 25, 36, 49. Score one point per ¥200 left and five more if you never spent this round.\n· Reset cards and money each round. The cumulative leader starts the next; ties are resolved by a random draw instead of rock-paper-scissors.\nTwo players:\n· Each receives ¥8000, a ten-card hand and a ten-card personal draw pile. Alternate playing until each has played twice into a four-card trick. Draw two each after every trick while personal cards remain, then play out the hands. Alternate leaders every trick. A sole player may buy only their current hand, without further personal draws.",
			round: "Round {{n}}",
			trick: "Trick {{n}}",
			points: "{{n}} pts",
			cash: "Cash ¥{{n}}",
			playPrompt: "Choose a card to play",
			buyPrompt: "Buy at least one toy from this trick",
			buyMore: "You may buy more toys",
			soloPrompt: "You may buy remaining hand cards",
			waiting: "Waiting for {{name}}",
			resolving: "Resolving",
			award: "{{name}} may purchase",
			noBuyer: "Nobody can afford this trick",
			playCard: "Play the ¥{{price}} toy",
			buyCard: "Buy the ¥{{price}} toy",
			refundCard: "Refund the ¥{{price}} toy",
			confirmPlay: "Play this card",
			confirmBuy: "Buy this toy",
			confirmRefund: "Refund this toy",
			cancel: "Cancel",
			randomBuy: "Random purchase ¥500",
			randomDeck: "Random deck",
			remaining: "{{n}} cards left",
			finish: "Finish purchasing",
			scoreRound: "Confirm scoring",
			nextRound: "Start next round",
			acknowledged: "Confirmed; waiting for other players",
			refundPrompt: "Refund a collected toy, or confirm scoring",
			roundFinished: "Round complete",
			collection: "Collection",
			collectionOf: "{{name}}’s collection",
			hand: "Hand",
			out: "Out this round",
			bought: "Bought",
			refund: "Refund",
			handCount: "Hand {{n}}",
			drawCount: "Draw {{n}}",
			sets: "Toy sets",
			cashPoints: "Cash points",
			bonus: "Restraint bonus",
			total: "Total score",
			resultTitle: "The Toy Collection Awards",
			winner: "Winner",
			roundPoints: "{{n}} this round",
			viewRound: "View round {{n}}",
			close: "Close",
			toyCount: "{{n}} {{toy}}",
			toyPoints: "{{n}} toys · {{points}} pts",
			empty: "No toys yet",
			motorcycle: "Motorcycle",
			octopus: "Octopus",
			cactus: "Cactus",
			frog: "Frog toilet",
			pig: "Pig",
			robot: "Robot",
			slime: "Slime keychain",
			blue: "Blue",
			cyan: "Cyan",
			green: "Green",
			red: "Red",
			purple: "Purple",
			gray: "Gray",
			yellow: "Yellow",
			cardLabel: "{{suit}} {{toy}}, ¥{{price}}",
			errTurn: "You cannot do that now",
			errCard: "That card is not available",
			errFollow: "Follow a suit already played in this trick",
			errMoney: "Not enough money",
			errRequired: "Buy a trick toy first, or reserve enough money for one",
			errRandom: "You cannot make another random purchase",
			errRefund: "That toy cannot be refunded"
		}
	}
};
//#endregion
export { fe as default };
