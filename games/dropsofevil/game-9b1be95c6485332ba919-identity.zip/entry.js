import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useT as r } from "@bgparty/sdk/i18n";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { PLAYER_COLORS as a } from "@bgparty/sdk/player-colors";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { Floater as u, FlySprite as d } from "@bgparty/sdk/fx/primitives";
import { Confetti as f } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as p, OptionSection as m } from "@bgparty/sdk/ui/game-options";
//#region src/games/dropsofevil/data.ts
var h = [
	"claw",
	"wing",
	"eye",
	"tail",
	"spider",
	"worm",
	"mushroom",
	"rat"
], g = [
	"claw",
	"wing",
	"eye",
	"tail",
	"worm",
	"spider"
], _ = [
	"rat",
	"worm",
	"claw",
	"wing",
	"eye",
	"tail"
], v = [
	"crow",
	"cat",
	"toad",
	"snake",
	"pouch"
], ee = {
	4: {
		rows: [
			"00011000",
			"11111100",
			"11111110",
			"01111111",
			"00111110",
			"...0100."
		],
		cats: [
			[3.5, 0],
			[0, .5],
			[1, .5],
			[2, .5],
			[5, .5],
			[6, .5],
			[3.5, 1],
			[2.5, 2],
			[4.5, 2],
			[6.5, 2],
			[0, 2.5],
			[1, 2.5],
			[2.5, 3],
			[5.5, 3],
			[4, 3.5],
			[7, 3.5],
			[1.5, 4],
			[3, 4.5],
			[5, 4.5]
		],
		toads: [
			[.5, .5],
			[2.5, .5],
			[4.5, .5],
			[6.5, 1.5],
			[2.5, 2.5],
			[4.5, 2.5],
			[.5, 3.5],
			[3.5, 4.5],
			[5.5, 4.5]
		]
	},
	3: {
		rows: [
			"001100",
			"111100",
			"111110",
			"011111",
			"011110",
			".0010."
		],
		cats: [
			[2.5, 0],
			[0, .5],
			[1, .5],
			[4, .5],
			[2, 1.5],
			[3, 1.5],
			[.5, 2],
			[4.5, 2],
			[0, 2.5],
			[1.5, 3],
			[4.5, 3],
			[0, 3.5],
			[3, 3.5],
			[4.5, 4]
		],
		toads: [
			[.5, .5],
			[2.5, .5],
			[4.5, 1.5],
			[2.5, 2.5],
			[1.5, 4.5],
			[3.5, 4.5]
		]
	},
	"2A": {
		rows: [
			"1100",
			"1100",
			"1100",
			"1111",
			"1111",
			"1000"
		],
		cats: [
			[.5, 0],
			[2.5, 1],
			[0, 1.5],
			[1, 1.5],
			[2.5, 2],
			[1.5, 3],
			[0, 3.5],
			[3, 3.5],
			[2, 4.5],
			[.5, 5]
		],
		toads: [
			[.5, 2.5],
			[2.5, 2.5],
			[.5, 4.5],
			[2.5, 4.5]
		]
	},
	"2B": {
		rows: [
			"1111",
			"1100",
			"1100",
			"1000",
			"1110",
			"1110"
		],
		cats: [
			[1.5, 0],
			[0, .5],
			[3, .5],
			[1.5, 1],
			[1.5, 2],
			[0, 2.5],
			[2.5, 3],
			[1, 3.5],
			[0, 4.5],
			[.5, 5]
		],
		toads: [
			[.5, .5],
			[2.5, .5],
			[.5, 2.5],
			[2.5, 2.5],
			[1.5, 4.5]
		]
	}
};
function y(e) {
	let t = ee[e], n = t.rows.flatMap((e, t) => [...e].flatMap((e, n) => e === "." ? [] : [{
		x: n,
		y: t,
		clearing: e === "1"
	}])), r = (e, t) => n.findIndex((n) => n.x === e && n.y === t), i = n.map((e, t) => ({
		id: `crow:${t}`,
		kind: "crow",
		x: e.x,
		y: e.y,
		cells: [t]
	}));
	for (let [e, n] of [["cat", t.cats], ["toad", t.toads]]) for (let [t, a] of n) {
		let n = e === "toad" ? [
			[t - .5, a - .5],
			[t + .5, a - .5],
			[t - .5, a + .5],
			[t + .5, a + .5]
		] : Number.isInteger(t) ? [[t, a - .5], [t, a + .5]] : [[t - .5, a], [t + .5, a]];
		i.push({
			id: `${e}:${t}:${a}`,
			kind: e,
			x: t,
			y: a,
			cells: n.map(([e, t]) => r(e, t)).filter((e) => e >= 0)
		});
	}
	for (let e = 0; e < t.rows[0].length; e++) i.push({
		id: `snake:${e}`,
		kind: "snake",
		x: e,
		y: -.8,
		cells: n.flatMap((t, n) => t.x === e ? [n] : [])
	});
	return {
		cells: n,
		spots: i,
		width: t.rows[0].length,
		height: 6
	};
}
var b = [
	[
		[0, 0],
		[1, 0],
		[0, 1]
	],
	[
		[2, 0],
		[2, 1],
		[3, 1]
	],
	[
		[3, 0],
		[4, 0],
		[5, 0]
	],
	[
		[6, 0],
		[5, 1],
		[6, 1]
	],
	[
		[7, 0],
		[7, 1],
		[8, 1]
	],
	[
		[8, 0],
		[9, 0],
		[10, 0]
	],
	[
		[11, 0],
		[11, 1],
		[11, 2]
	],
	[
		[1, 1],
		[1, 2],
		[1, 3]
	],
	[
		[4, 1],
		[4, 2],
		[5, 2]
	],
	[
		[9, 1],
		[8, 2],
		[9, 2]
	],
	[
		[10, 1],
		[10, 2],
		[10, 3]
	],
	[
		[0, 2],
		[0, 3],
		[0, 4]
	],
	[
		[2, 2],
		[3, 2],
		[2, 3]
	],
	[
		[6, 2],
		[7, 2],
		[7, 3]
	],
	[
		[8, 3],
		[9, 3],
		[9, 4]
	],
	[
		[11, 3],
		[10, 4],
		[11, 4]
	],
	[
		[3, 3],
		[4, 3],
		[4, 4]
	],
	[
		[5, 3],
		[6, 3],
		[5, 4]
	],
	[
		[1, 4],
		[2, 4],
		[3, 4]
	],
	[
		[6, 4],
		[7, 4],
		[8, 4]
	]
].map((e) => e.map(([e, t]) => t * 12 + e)), x = Array.from({ length: 60 }, (e, t) => b.findIndex((e) => e.includes(t))), te = b.flatMap((e, t) => new Set(e.map((e) => e % 12)).size > 1 && new Set(e.map((e) => Math.floor(e / 12))).size > 1 ? [t] : []), ne = Array.from({ length: 48 }, (e, t) => [t, t + 12]).filter(([e, t]) => x[e] !== x[t]), S = [
	0,
	1,
	2,
	1,
	2,
	1,
	1,
	2,
	1,
	2,
	1,
	0
], re = {
	claw: 30,
	wing: 26,
	eye: 22,
	tail: 18,
	spider: 14,
	worm: 58,
	mushroom: 18,
	rat: 14
}, C = {
	claw: 14,
	wing: 12,
	eye: 10,
	tail: 8,
	spider: 6,
	worm: 0,
	mushroom: 8,
	rat: 6
}, ie = Array.from({ length: 18 }, (e, t) => t + 1), ae = [
	4,
	6,
	8,
	14,
	15,
	16,
	18
], w = {
	id: "dropsofevil",
	tier: "alpha",
	nameKey: "games.dropsofevil.name",
	descKey: "games.dropsofevil.desc",
	rulesKey: "games.dropsofevil.rules",
	icon: "⚗️",
	iconImg: "games/dropsofevil.webp",
	accent: "#365f62",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	mechanics: ["worker-placement", "tile-placement"],
	interactionTags: [],
	search: {
		py: "",
		init: ""
	},
	hotseat: "open",
	releasedAt: "2026-11-06T00:30:00+08:00",
	rulesUrl: { en: "https://www.dropbox.com/scl/fi/9dq3dr4v9b1piga3uxmr4/DOE_Rulebook_v18-web.pdf?rlkey=3bym1y3p8evkhn46sd2mnvpv1&dl=0" }
}, T = t.enum([
	"claw",
	"wing",
	"eye",
	"tail",
	"spider",
	"worm",
	"mushroom",
	"rat"
]), E = t.enum([
	"crow",
	"cat",
	"toad",
	"snake",
	"pouch"
]), D = t.int().nonnegative(), oe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		pawn: E,
		spot: t.string(),
		special: t.boolean().optional()
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("brew"),
		resource: T,
		cell: D
	}),
	t.object({
		type: t.literal("return"),
		cell: D
	}),
	t.object({ type: t.literal("mushroom") }),
	t.object({
		type: t.literal("bonus"),
		index: D
	}),
	t.object({ type: t.literal("cheese") }),
	t.object({
		type: t.literal("assistant"),
		targets: t.array(t.union([t.string(), D])).max(3).default([])
	}),
	t.object({
		type: t.literal("tradeAssistant"),
		resource: t.enum(["worm", "cheese"])
	}),
	t.object({ type: t.literal("ready") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), se = t.object({
	resource: T,
	locked: t.boolean(),
	pair: t.number().optional()
}), O = t.object({
	area: t.enum(["brewer", "distiller"]),
	at: D,
	kind: t.enum(["extra", "scroll"]),
	resource: t.string(),
	count: D,
	taken: t.boolean()
}), k = t.object({
	rid: t.string(),
	score: D,
	lab: t.array(se.nullable()).length(60),
	pool: t.record(T, D),
	mushrooms: D,
	cheese: D,
	freeRats: D,
	capturedRats: D,
	toxins: t.record(t.string(), D),
	scrolls: t.record(t.string(), D),
	bonuses: t.array(O),
	placements: t.record(E, t.string().nullable()),
	effective: t.record(E, E),
	assistant: t.number().nullable(),
	used: t.boolean(),
	hutkeeper: t.boolean(),
	surgeon: t.boolean(),
	pendingBonus: t.array(D),
	ready: t.boolean()
}), A = t.object({
	phase: t.enum([
		"placement",
		"gather",
		"brewing",
		"income",
		"refill",
		"done"
	]),
	round: t.int().min(1).max(3),
	boardKind: t.enum([
		"2A",
		"2B",
		"3",
		"4"
	]),
	turn: t.string(),
	placedThisTurn: t.boolean(),
	order: t.array(t.string()),
	players: t.array(k),
	forest: t.array(t.array(T)),
	assistants: t.array(D),
	merchant: t.array(T),
	recipes: t.array(t.object({
		id: D,
		resource: T
	})),
	bagCount: D,
	gatherStep: D,
	incomeStep: D,
	last: t.object({
		kind: t.string(),
		rid: t.string(),
		n: t.number()
	}).nullable()
}), j = t.object({}), M = t.object({ twoPlayerSide: t.enum(["A", "B"]).default("A") }).default({ twoPlayerSide: "A" }), N = {
	gather: 620,
	income: 850,
	refill: 650
}, P = () => Object.fromEntries(h.map((e) => [e, 0])), F = (e, t) => e.players.find((e) => e.rid === t), I = (e) => v.filter((t) => e.placements[t] === null);
function L(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function R(e) {
	if (!e.assistants.includes(9)) return;
	let t = e.bag.findIndex((e) => e !== "rat");
	t >= 0 && e.merchant.push(...e.bag.splice(t, 1));
}
function z(e) {
	let t = L(e, [
		"claw",
		"wing",
		"eye",
		"tail",
		"spider",
		"spider",
		"spider",
		"mushroom",
		"mushroom",
		"mushroom",
		"worm",
		"worms",
		"cheese",
		"cheeses"
	]), n = [], r = (e, r) => {
		let i = t.pop();
		n.push({
			area: e,
			at: r,
			kind: "extra",
			resource: i === "worms" ? "worm" : i === "cheeses" ? "cheese" : i,
			count: i === "worms" || i === "cheeses" ? 2 : 1,
			taken: !1
		});
	};
	for (let e = 0; e < 4; e++) r("distiller", e);
	for (let e of [
		0,
		0,
		1,
		3,
		5,
		6,
		8,
		10,
		11,
		11
	]) r("brewer", e);
	for (let [t, r] of [["distiller", [
		"rat",
		"claw",
		"wing",
		"eye",
		"tail"
	]], ["brewer", [
		"worm",
		"claw",
		"wing",
		"eye",
		"tail"
	]]]) L(e, [...r]).slice(0, 4).forEach((e, r) => n.push({
		area: t,
		at: t === "distiller" ? r : [
			2,
			4,
			7,
			9
		][r],
		kind: "scroll",
		resource: e,
		count: 1,
		taken: !1
	}));
	return n;
}
function B(e, t, n) {
	let r = {
		seed: n,
		cursor: 0
	}, i = L(r, h.filter((e) => e !== "worm").flatMap((e) => Array.from({ length: re[e] - (t.length === 2 ? C[e] : t.length === 3 ? C[e] / 2 : 0) }, () => e))), a = t.length === 2 ? M.parse(e).twoPlayerSide === "B" ? "2B" : "2A" : t.length === 3 ? "3" : "4", o = L(r, [...ie]).slice(0, t.length === 2 ? 4 : 5), s = L(r, [
		"claw",
		"wing",
		"eye",
		"tail"
	]), c = L(r, Array.from({ length: 8 }, (e, t) => t + 1)).slice(0, 2).map((e, t) => ({
		id: e,
		resource: s[t]
	})), l = z(r), u = L(r, [...t]), d = {
		...r,
		bag: i,
		boardKind: a,
		assistants: o,
		recipes: c,
		order: u,
		turn: u[0],
		round: 1,
		phase: "placement",
		placedThisTurn: !1,
		players: t.map((e) => ({
			rid: e,
			score: 0,
			lab: Array.from({ length: 60 }, () => null),
			pool: P(),
			mushrooms: 0,
			cheese: 0,
			freeRats: 0,
			capturedRats: 0,
			toxins: Object.fromEntries(_.map((e, t) => [e, t + 1])),
			scrolls: Object.fromEntries(_.map((e) => [e, 0])),
			bonuses: structuredClone(l),
			placements: {
				crow: null,
				cat: null,
				toad: null,
				snake: null,
				pouch: null
			},
			effective: {
				crow: "crow",
				cat: "cat",
				toad: "toad",
				snake: "snake",
				pouch: "pouch"
			},
			assistant: null,
			used: !1,
			hutkeeper: !1,
			surgeon: !1,
			pendingBonus: [],
			ready: !1
		})),
		forest: y(a).cells.map(() => [i.pop()]),
		merchant: [],
		bagCount: 0,
		gatherStep: 0,
		incomeStep: 0,
		last: null,
		gatherQueue: []
	};
	return R(d), d.bagCount = d.bag.length, { state: d };
}
function V(e, t, n = 1) {
	t === "rat" ? e.freeRats += n : e.pool[t] += n;
}
function H(e, t) {
	return [
		0,
		1,
		2,
		3,
		4
	].every((n) => e.lab[n * 12 + t] !== null);
}
function ce(e) {
	return S.reduce((t, n, r) => t + (e.bonuses.filter((e) => e.area === "brewer" && e.at === r).every((e) => e.taken) ? n : 0), 0);
}
function U(e) {
	return e.bonuses.filter((e) => e.area === "distiller" && e.taken).length;
}
function W(e, t) {
	if (t.taken = !0, t.kind === "scroll") {
		let n = t.resource;
		e.toxins[n] = Math.min(9, e.toxins[n] + t.count + +(e.scrolls[n] === 1)), e.scrolls[n]++;
	} else t.resource === "cheese" ? e.cheese += t.count : V(e, t.resource, t.count);
}
function G(e, t) {
	for (let n of e.bonuses) n.area === "brewer" && n.at === t && !n.taken && W(e, n);
	for (let n = 0; n < 5; n++) {
		let r = e.lab[n * 12 + t];
		r && (r.locked = !0);
	}
}
function K(e, t, n) {
	if (n < 0 || n >= 60 || e.lab[n] || !g.includes(t) || e.pool[t] <= 0) return !1;
	let r = b[x[n]].flatMap((t) => e.lab[t] ? [e.lab[t].resource] : []);
	return t === "spider" ? r.some((e) => e !== "spider") : r.every((e) => e === "spider" || e === t);
}
function le(e) {
	e.mushrooms++;
	let t = e.mushrooms === 1 ? 0 : e.mushrooms === 3 ? 1 : e.mushrooms === 5 ? 2 : e.mushrooms >= 7 && e.mushrooms % 2 == 1 ? 3 : -1;
	t >= 0 && e.bonuses.some((e) => e.area === "distiller" && !e.taken && e.at <= t) && e.pendingBonus.push(t);
}
function q(e, t) {
	let n = y(e.boardKind);
	for (let r of [
		"crow",
		"cat",
		"toad",
		"snake"
	]) for (let i of e.order) {
		let a = F(e, i);
		for (let e of v) if (a.effective[e] === r && n.spots.find((t) => t.id === a.placements[e])?.cells.includes(t)) return i;
	}
	return null;
}
function J(e, t, n, r = !1) {
	if (t.placements[n] !== null) return [];
	let i = new Set(e.players.flatMap((e) => Object.values(e.placements).filter((e) => e !== null)));
	if (n === "pouch") return r ? [] : e.assistants.map((e) => `assistant:${e}`).filter((e) => !i.has(e));
	let a = n;
	if (r) {
		if (t.used) return [];
		if (t.assistant === 4 && n === "crow") a = "cat";
		else if (t.assistant === 8 && n === "cat") a = "toad";
		else if (t.assistant !== 6 || n !== "crow") return [];
	}
	let o = y(e.boardKind);
	return o.spots.filter((e) => e.kind === a && !i.has(e.id) && (a !== "crow" || (r && t.assistant === 6 ? !o.cells[e.cells[0]].clearing : o.cells[e.cells[0]].clearing))).map((e) => e.id);
}
function Y(e, t, n) {
	let r = t.assistant;
	if (r === null || t.used || (ae.includes(r) ? e.phase !== "placement" || e.turn !== t.rid : e.phase !== "brewing" || t.ready)) return !1;
	let [i, a] = n, o = typeof i == "number" ? i : -1, s = typeof a == "number" ? a : -1, c = y(e.boardKind), l = (n) => {
		for (let r of e.forest[n]) V(t, r);
		e.forest[n] = [];
	};
	if (r === 1) {
		if (i !== "free" && i !== "captured" || s < 0 || s >= 60 || t.lab[s] || (i === "free" ? t.freeRats : t.capturedRats) < 1 || !b[x[s]].some((e) => t.lab[e] && t.lab[e].resource !== "spider")) return !1;
		i === "free" ? t.freeRats-- : t.capturedRats--, t.lab[s] = {
			resource: "spider",
			locked: !1
		}, H(t, s % 12) && G(t, s % 12);
	} else if (r === 2) {
		let e = t.bonuses[o], n = t.bonuses[s];
		if (!e || !n || e.taken || n.taken || o === s) return !1;
		let r = [
			"resource",
			"count",
			"kind"
		], i = { ...e };
		for (let t of r) Object.assign(e, { [t]: n[t] });
		for (let e of r) Object.assign(n, { [e]: i[e] });
		t.pool.worm++;
	} else if (r === 3) t.hutkeeper = !0;
	else if (r === 5) t.pool.worm += 2;
	else if (r === 7) {
		if (o < 0 || o > 11) return !1;
		let e = [
			0,
			1,
			2,
			3,
			4
		].filter((e) => t.lab[e * 12 + o] === null).length;
		if (e < 1 || e > 2 || !t.bonuses.some((e) => e.area === "brewer" && e.at === o && !e.taken)) return !1;
		G(t, o);
	} else if (r === 9) {
		for (let n of e.merchant) V(t, n);
		e.merchant = [];
	} else if (r === 10) {
		if (o < 0 || s < 0 || o >= 60 || s >= 60 || o === s || x[o] !== x[s] || t.lab[o] || t.lab[s] || t.pool.spider < 1 || !b[x[o]].some((e) => t.lab[e] && t.lab[e].resource !== "spider")) return !1;
		t.pool.spider--, t.lab[o] = {
			resource: "spider",
			locked: !1,
			pair: o + 1
		}, t.lab[s] = {
			resource: "spider",
			locked: !1,
			pair: o + 1
		};
		for (let e of /* @__PURE__ */ new Set([o % 12, s % 12])) H(t, e) && G(t, e);
	} else if (r === 11) {
		if (i === "worm" && t.pool.worm > 0) t.pool.worm--;
		else if (i === "free" && t.freeRats > 0) t.freeRats--;
		else if (i === "captured" && t.capturedRats > 0) t.capturedRats--;
		else return !1;
		le(t);
	} else if (r === 12) t.capturedRats += t.freeRats, t.freeRats = 0;
	else if (r === 13) {
		if (o < 0 || o >= e.forest.length || !e.forest[o].length) return !1;
		l(o);
	} else if (r === 14) {
		if (!v.includes(i) || i === "pouch" || t.placements[i] === null) return !1;
		t.placements[i] = null, t.effective[i] = i;
	} else if (r === 15) {
		let n = c.spots.find((e) => e.id === t.placements.snake);
		if (o < 0 || o >= e.forest.length || !n?.cells.includes(o) || q(e, o) !== null && q(e, o) !== t.rid) return !1;
		l(o);
	} else if (r === 16) {
		if (o < 0 || s < 0 || o >= e.forest.length || s >= e.forest.length || q(e, o) !== null && q(e, o) !== t.rid) return !1;
		let n = c.cells[o], r = c.cells[s];
		if (Math.abs(n.x - r.x) + Math.abs(n.y - r.y) !== 1 || !e.forest[o].length) return !1;
		e.forest[s].push(...e.forest[o]), e.forest[o] = [];
	} else if (r === 18) {
		let n = c.spots.find((e) => e.id === t.placements.toad);
		if (!n) return !1;
		for (let r of n.cells) t.capturedRats += e.forest[r].filter((e) => e === "rat").length, e.forest[r] = e.forest[r].filter((e) => e !== "rat");
	} else return !1;
	return t.used = !0, !0;
}
function X(e, t, n) {
	let r = F(e, n);
	if (!r || e.phase === "done") return !1;
	if (t.type === "place") return e.phase !== "placement" || e.turn !== n || e.placedThisTurn || !J(e, r, t.pawn, t.special).includes(t.spot) ? !1 : (r.placements[t.pawn] = t.spot, e.placedThisTurn = !0, t.pawn === "pouch" ? r.assistant = Number(t.spot.split(":")[1]) : t.special && (r.assistant === 4 && (r.effective.crow = "cat"), r.assistant === 8 && (r.effective.cat = "toad"), r.assistant === 6 && r.pool.worm++, r.used = !0), e.last = {
		kind: "place",
		rid: n,
		n: 0
	}, !0);
	if (t.type === "endTurn") return e.phase === "placement" && e.turn === n && e.placedThisTurn;
	if (t.type === "assistant") return r.pendingBonus.length === 0 && Y(e, r, t.targets);
	if (t.type === "tradeAssistant") return e.phase !== "brewing" || r.ready || r.pendingBonus.length || r.assistant === null || r.used ? !1 : (t.resource === "worm" ? r.pool.worm++ : r.cheese++, r.used = !0, !0);
	if (e.phase !== "brewing" || r.ready || r.pendingBonus.length && t.type !== "bonus") return !1;
	if (t.type === "brew") return K(r, t.resource, t.cell) ? (r.pool[t.resource]--, r.lab[t.cell] = {
		resource: t.resource,
		locked: !1
	}, H(r, t.cell % 12) && G(r, t.cell % 12), e.last = {
		kind: "brew",
		rid: n,
		n: t.cell
	}, !0) : !1;
	if (t.type === "return") {
		let e = r.lab[t.cell];
		if (!e || e.locked) return !1;
		let n = e.pair ? b[x[t.cell]].filter((t) => r.lab[t]?.pair === e.pair) : [t.cell];
		if (n.some((e) => r.lab[e]?.locked)) return !1;
		let i = b[x[t.cell]].filter((e) => !n.includes(e)).flatMap((e) => r.lab[e] ? [r.lab[e].resource] : []);
		return i.length && i.every((e) => e === "spider") ? !1 : (n.forEach((e) => {
			r.lab[e] = null;
		}), r.pool[e.resource]++, !0);
	}
	if (t.type === "mushroom") return r.pool.mushroom < 1 ? !1 : (r.pool.mushroom--, le(r), e.last = {
		kind: "mushroom",
		rid: n,
		n: r.mushrooms
	}, !0);
	if (t.type === "bonus") {
		let e = r.bonuses[t.index], n = r.pendingBonus[0];
		return !e || n === void 0 || e.area !== "distiller" || e.taken || e.at > n ? !1 : (W(r, e), r.pendingBonus.shift(), !0);
	}
	return t.type === "cheese" ? r.cheese < 1 || r.freeRats < 1 ? !1 : (r.cheese--, r.freeRats--, r.capturedRats++, !0) : t.type === "ready" ? r.pool.mushroom > 0 || g.some((e) => r.pool[e] > 0 && r.lab.some((t, n) => K(r, e, n))) ? !1 : (r.ready = !0, r.pool = P(), r.cheese = 0, r.lab.forEach((e) => {
		e && (e.locked = !0);
	}), !0) : !1;
}
function ue(e) {
	let t = y(e.boardKind).spots;
	e.order.sort((n, r) => t.find((t) => t.id === F(e, n).placements.snake).x - t.find((t) => t.id === F(e, r).placements.snake).x), e.gatherQueue = e.order.flatMap((e) => v.filter((e) => e !== "pouch").map((t) => ({
		rid: e,
		pawn: t
	}))).sort((t, n) => v.indexOf(F(e, t.rid).effective[t.pawn]) - v.indexOf(F(e, n.rid).effective[n.pawn])), e.phase = "gather", e.gatherStep = 0, e.last = null;
}
function de(e) {
	e.placedThisTurn = !1;
	let t = e.order.indexOf(e.turn);
	for (let n = 1; n <= e.order.length; n++) {
		let r = e.order[(t + n) % e.order.length];
		if (I(F(e, r)).length) {
			e.turn = r;
			return;
		}
	}
	ue(e);
}
function Z(e, t, n) {
	let r = (t) => e.lab[t]?.resource === n || e.lab[t]?.resource === "spider";
	if (t === 1) {
		let e = 0;
		for (let t = 0; t < 5; t++) {
			let n = 0;
			for (let i = 0; i < 12; i++) n = r(t * 12 + i) ? n + 1 : 0, n === 4 && (e++, n = 0);
		}
		return e * 4;
	}
	if (t === 2) return Array.from({ length: 12 }, (e, t) => [
		2,
		3,
		4
	].every((e) => r(e * 12 + t)) ? 2 : 0).reduce((e, t) => e + t, 0);
	if (t === 3) {
		let e = 0, t = /* @__PURE__ */ new Set();
		for (let n = 0; n < 60; n++) if (r(n) && !t.has(n)) {
			let i = [n];
			t.add(n);
			for (let e = 0; e < i.length; e++) {
				let n = i[e];
				for (let e of [
					n - 12,
					n + 12,
					...n % 12 > 0 ? [n - 1] : [],
					...n % 12 < 11 ? [n + 1] : []
				]) e >= 0 && e < 60 && r(e) && !t.has(e) && (t.add(e), i.push(e));
			}
			e = Math.max(e, i.length);
		}
		return Math.floor(e / 2);
	}
	if (t === 4) return Array.from({ length: 12 }, (e, t) => +!![
		0,
		1,
		2,
		3,
		4
	].some((e) => r(e * 12 + t))).reduce((e, t) => e + t, 0);
	if (t === 5) return Math.floor(Array.from({ length: 60 }, (e, t) => t).filter((e) => (e < 12 || e >= 48 || e % 12 == 0 || e % 12 == 11) && r(e)).length / 2);
	if (t === 6) {
		let e = /* @__PURE__ */ new Map(), t = (n, i) => {
			if (n >= 60) return 0;
			let a = `${n}:${i >> BigInt(n)}`, o = e.get(a);
			if (o !== void 0) return o;
			let s = t(n + 1, i);
			if (n % 12 < 11 && n < 48) {
				let e = [
					n,
					n + 1,
					n + 12,
					n + 13
				];
				e.every((e) => r(e) && (i & 1n << BigInt(e)) == 0n) && (s = Math.max(s, 1 + t(n + 1, e.reduce((e, t) => e | 1n << BigInt(t), i))));
			}
			return e.set(a, s), s;
		};
		return t(0, 0n) * 3;
	}
	if (t === 7) {
		let e = 0, t = /* @__PURE__ */ new Set();
		for (let [n, i] of ne) r(n) && r(i) && !t.has(n) && !t.has(i) && (t.add(n), t.add(i), e++);
		return e * 2;
	}
	return t === 8 ? Math.floor(te.flatMap((e) => b[e]).filter(r).length / 2) : 0;
}
function fe(e, t) {
	let n = b.reduce((t, n) => {
		if (n.some((t) => e.lab[t] === null)) return t;
		let r = n.map((t) => e.lab[t].resource).find((e) => e !== "spider");
		return t + (r ? e.toxins[r] : 0);
	}, 0), r = e.capturedRats * e.toxins.rat, i = t.map((t) => Z(e, t.id, t.resource));
	return {
		income: e.score,
		vials: n,
		rats: r,
		recipe: i,
		total: e.score + n + r + i.reduce((e, t) => e + t, 0)
	};
}
function pe(e) {
	if (e.phase === "gather") {
		let t = e.gatherQueue.shift();
		if (!t) return e.phase = "brewing", e.last = null, [];
		let n = F(e, t.rid), r = y(e.boardKind).spots.find((e) => e.id === n.placements[t.pawn]), i = [], a = 0;
		for (let t of r.cells) {
			let r = e.forest[t].length ? e.forest[t] : ["worm"];
			for (let e of r) V(n, e), i.push({
				kind: e,
				from: `forest:${t}`,
				to: e === "rat" ? `free:${n.rid}` : `pool:${n.rid}:${e}`,
				rid: n.rid
			});
			a += r.length, e.forest[t] = [];
		}
		return n.placements[t.pawn] = null, e.gatherStep++, e.last = {
			kind: "gather",
			rid: n.rid,
			n: a
		}, i.push({
			kind: t.pawn,
			from: r.id.startsWith("crow:") ? `forest:${r.id.slice(5)}` : `spot:${r.id}`,
			to: `dock:${n.rid}:${t.pawn}`,
			rid: n.rid
		}), [{
			kind: "move",
			rid: n.rid,
			data: {
				items: i,
				ms: 480
			}
		}];
	}
	if (e.phase === "income") {
		let t = F(e, e.order[e.incomeStep]);
		if (!t) return e.phase = e.round === 3 ? "done" : "refill", e.last = null, [];
		t.assistant === 17 && !t.used && (t.surgeon = !0, t.used = !0);
		let n = ce(t) + U(t) * (t.hutkeeper ? 2 : 1) + (t.surgeon ? t.capturedRats : 0) - t.freeRats, r = t.score;
		return t.score = Math.max(0, t.score + n), e.incomeStep++, e.last = {
			kind: "income",
			rid: t.rid,
			n: t.score - r
		}, [{
			kind: "income",
			rid: t.rid,
			data: { n: t.score - r }
		}];
	}
	if (e.phase === "refill") {
		e.round++;
		for (let t of e.forest) {
			let n = e.bag.pop();
			n && t.push(n);
		}
		for (let t of e.players) t.placements = {
			crow: null,
			cat: null,
			toad: null,
			snake: null,
			pouch: null
		}, t.effective = {
			crow: "crow",
			cat: "cat",
			toad: "toad",
			snake: "snake",
			pouch: "pouch"
		}, t.assistant = null, t.used = !1, t.ready = !1, t.hutkeeper = !1, t.surgeon = !1;
		return R(e), e.bagCount = e.bag.length, e.phase = "placement", e.turn = e.order[0], e.last = {
			kind: "refill",
			rid: "",
			n: e.round
		}, [{
			kind: "move",
			data: {
				ms: 570,
				items: e.forest.map((e, t) => ({
					kind: e[e.length - 1],
					from: "bag",
					to: `forest:${t}`,
					rid: ""
				}))
			}
		}];
	}
	return [];
}
function me(e, t, n) {
	if (t.type === "tick") {
		if (![
			"gather",
			"income",
			"refill"
		].includes(e.phase)) return { state: e };
		let t = structuredClone(e);
		return {
			state: t,
			fx: pe(t)
		};
	}
	let r = structuredClone(e);
	return X(r, t, n.by) ? (t.type === "endTurn" && de(r), t.type === "ready" && r.players.every((e) => e.ready) && (r.phase = "income", r.incomeStep = 0), {
		state: r,
		fx: he(e, r, t, n.by)
	}) : { code: "games.dropsofevil.invalidAction" };
}
function he(e, t, n, r) {
	let i = F(e, r), a = F(t, r), o = [], s = (e, t, n, i = 1) => {
		for (let a = 0; a < i; a++) o.push({
			kind: e,
			from: t,
			to: n,
			rid: r
		});
	};
	n.type === "place" && (s(n.pawn, `dock:${r}:${n.pawn}`, n.spot.startsWith("crow:") ? `forest:${n.spot.slice(5)}` : `spot:${n.spot}`), a.pool.worm > i.pool.worm && s("worm", `spot:assistant:${i.assistant}`, `pool:${r}:worm`, a.pool.worm - i.pool.worm));
	for (let e = 0; e < 60; e++) !i.lab[e] && a.lab[e] && s(a.lab[e].resource, n.type === "assistant" && i.assistant === 1 ? `${n.targets[0]}:${r}` : `pool:${r}:${a.lab[e].resource}`, `cell:${r}:${e}`), i.lab[e] && !a.lab[e] && s(i.lab[e].resource, `cell:${r}:${e}`, `pool:${r}:${i.lab[e].resource}`);
	if (a.mushrooms > i.mushrooms && s("mushroom", n.type === "assistant" ? n.targets[0] === "worm" ? `pool:${r}:worm` : `${n.targets[0]}:${r}` : `pool:${r}:mushroom`, `distiller:${r}`), a.capturedRats > i.capturedRats && (n.type !== "assistant" || i.assistant !== 18) && s("rat", `free:${r}`, `captured:${r}`, a.capturedRats - i.capturedRats), a.bonuses.forEach((e, t) => {
		e.taken && !i.bonuses[t].taken && s(e.resource, `bonus:${r}:${t}`, e.kind === "scroll" ? `toxin:${r}:${e.resource}` : `pool:${r}:${e.resource}`, e.count);
	}), n.type === "assistant") {
		let [a, o] = n.targets;
		if (i.assistant === 2 && typeof a == "number" && typeof o == "number" && (s(i.bonuses[a].resource, `bonus:${r}:${a}`, `bonus:${r}:${o}`), s(i.bonuses[o].resource, `bonus:${r}:${o}`, `bonus:${r}:${a}`)), i.assistant === 14 && typeof a == "string") {
			let e = i.placements[a];
			s(a, e.startsWith("crow:") ? `forest:${e.slice(5)}` : `spot:${e}`, `dock:${r}:${a}`);
		}
		if (i.assistant === 2 && s("worm", "spot:assistant:2", `pool:${r}:worm`), [
			13,
			15,
			16
		].includes(i.assistant ?? 0) && typeof a == "number") for (let t of e.forest[a]) s(t, `forest:${a}`, i.assistant === 16 ? `forest:${o}` : t === "rat" ? `free:${r}` : `pool:${r}:${t}`);
		if (i.assistant === 18 && e.forest.forEach((e, n) => {
			let i = e.filter((e) => e === "rat").length - t.forest[n].filter((e) => e === "rat").length;
			i > 0 && s("rat", `forest:${n}`, `captured:${r}`, i);
		}), i.assistant === 5 && s("worm", "spot:assistant:5", `pool:${r}:worm`, 2), i.assistant === 9) for (let t of e.merchant) s(t, "spot:assistant:9", `pool:${r}:${t}`);
	}
	return n.type === "tradeAssistant" && s(n.resource, `spot:assistant:${i.assistant}`, `pool:${r}:${n.resource}`), o.length ? [{
		kind: "move",
		rid: r,
		data: {
			items: o,
			ms: 350
		}
	}] : [];
}
function ge(e) {
	let t = structuredClone(e);
	return delete t.seed, delete t.cursor, delete t.bag, delete t.gatherQueue, {
		public: t,
		private: {}
	};
}
function _e(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t.rid, fe(t, e.recipes).total])), n = [...e.order].sort((e, n) => t[n] - t[e]);
	return {
		phase: "done",
		winner: [n[0]],
		ranking: n,
		scores: t
	};
}
var ve = {
	meta: w,
	saveCompatibility: { version: "1" },
	schemas: {
		action: oe,
		publicView: A,
		privateView: j,
		config: M
	},
	setup: B,
	reduce: me,
	viewFor: ge,
	status: _e,
	nextTickIn: (e) => e.phase === "gather" ? N.gather : e.phase === "income" ? N.income : e.phase === "refill" ? N.refill : null
}, ye = {
	claw: "data:image/webp;base64,UklGRrgRAABXRUJQVlA4TKsRAAAvn8AkENfAJgCANMhHCSrR/7DP3ac11AYAiGg2F3jI/Y7ozgkGAQAkoXsCM1jOD3603Tn/Mda6z4WLkQpB5N4lB+CfXvDA7wYpgIGAEUeQEVqz/g6I31+EfGf3Ajo+wE7FvrqtpnvFzY5phyrL4NG27batbWtbYhKDQIE0gyW//5MCpCTPuU68obWI/k/Az/+O/efyauE/cPnXK/5BL2U2KU6XeShU/p2gPFvlVVI5KPKXf5+C8mR1MignS7Jmi8u/yj+FlmqVymHIDuFAc4NAaeFF/iWgyFTHQWsgGYebAD0hPUGZFl742/1TeNFSb1W+Vc/1N1uTztPVAJRalFpc+IuVamGpNw09dNCqVxtrCI49jK10cOdUz1BlS7XwAvyFgDJbQbwN2tMdtk12pId21MHuDnTYWo85g1VaapH9+xSWSjYGB3va94wwaHuHa80AN4NGDWoCpVqkl78KhaVWh0mrHpmEkb7V0UGhvpHc1AqiBpshA6Um/k0ulGp1GLQnMaPaGByhVQcFbgnVAcSxZzCYUKqF+re4UKbVcX0L7RuDtiaDAjU34jQv7Lf5aQWErgca6yp9llro5a9AmVbZoENohvZ9OGiAGpjm1W0HfFpRN1d7oKmvoQKeWmrhX+BSqlW2HtSg7Yt9GlTIBGsgrju5b+Rh9Kr23LWphwqeWmqhlz+sKNUqbTUz0mp/RP6gtQ+ZuO7gY4Pv7L5OSXeHnkGDFTxLLfTyJ1GUWmWbNh1GIDQOZvrDkKNtQm7dQR+bRyxTuNaMdLT3kQxPSwu9/DkUpVbZps2HEZqDugeGGoJGgz1NTRCmZd0xIwfAVMfkzgjBCnhaWujlT6EorbJ124GQDGaCNfQ1JwwMkXRa3TNsaoYEomHo7nTQjtFEy0L/kMJSoE67w+CgNjVk8nFmV5jN7NklYVNJyBAd7FpRx2jFUy0t9M8oBWqg707WMJCPTktUV90Po8ueXxdwh03NkGGpb0Pfphl4auLv+6coraAG+u6Fw+ieXU/xTc4lcYdNJVF3WKeqbjKO0Qp4almov+xiUVpxc6jpTtdAVCrcz88sq/vxzALMqC7Atn8DGZyjwVYHg1bA09JC/WWUVnAb7LtXQlQX9tOrMwvqDuoCM8ucHrD5nSYYrQgnE0v9bUUpMGj/SnBa45oeLMz7wgHHc/4LFmBeYDtSPTfCUxN/0+VobLvzQ/haD/fNA1jSU/L14rzwULfvvC7RoCONAPGppYX+nktRWsHgSJfvSdoQV91BdXm4bzqnr/gaCzzc1AzuS6zA0NiqQZ6WFl5+TVFaAa12+WsPodUwre55H7q6rS4z8LWcnvUlkp0j2NfqhiFeW+0IPrW08JdcitIKCK0d0MPVoLU6LSfg4cK26gxfkAgoM/oG2Df1CCqitnrvMJjzdxS50J4JaqVx2V9cYFX5ShMT3wI50lOh9T6q8amlhZffUFha5bpsfzVYVxDn1f17Wxcws+XMsJjgnPhaqpl8BQdo9Kmlhb+itAJCe8S1hlsF86p7vGnUJYH1lLkZ/NjTHPXQ6qh65C8oT3T5GrhZsWyrTkNOT3lCF/Nv2rMPNUfTdpAEn1paeOFTlFZAeKli2UnCkQm5d369+cSWCyO0aTiw8OfDlzJXh+6wBipgdXceW4c+5Fx24JUvcrx1kjV55OaKxhwE9amJHypKbxU1cDDUUAGrOrVD37WOTCa6H26PbXXh63jKzV/LqXTZt4cKEGuaVse7jkGtSPxUoTf7kJAZtK6AuOo8duSYIFnO6Kl0ZYYF5lMLPNQd+Br7jla92phY8TS5fOimfeOpOjOv2nap42FUlxzbW+bc1xu2Hdapz11tTlla+Iki6d+zQ2tPB+PJyej+DTuQrOqk5hZ42w7MYw93Wq/hDLnLJ0oz9Zk6s+p888QdRqbEdc+kiS8ssPra5u4S6547dATNRY9836U8Z8KJmw4d3JkkHRHivO7pN3ver4MZlj19bVOpYbgDPQR9wcLLJ272NPWZNrPs6zLetON+eoQpzmuOHC58qTO4882OvrDDtlQ1g97pco5XDdHqqYkfag7oaM3tMLW3we7+4jhp9A2mszvfwM7Xa0sFuT430l4NRjN+Krx00yQO6v3lc+RYFVD5fsNMUuXumZC0SuLB5U3/lFqFU+3BDoRB7y+PnIPMJhngG3Z8bbOihqG1O2jTMZiY+KH6LWG4DbfuDUxmtkzqY3vshxuwfp1f3GGbYw1tesqg1YeKUognehLr257T/pUxM7/CY3sARwvnlnVPjdaQ6BmPLLx8YIQXBsNRxwsjEHV5E+xsPpY3YbTxPXyGJIzXA7pc3GEJvjYCUd3T77PbTob9ofMLC3t+e0MHB36iqAg2HrXZ4JumEaK68/3q0f7I8ZbvJYaeVkfOjATjge8j9O+ZvCVjMiXqGNWd7zfoN2iyzHydXNjhmx0WGJPxqDvwV9B8YPKOiQc73284+XCH1aMFtv07N43viia+r6xae+p8kxlc2JmG23AbuikdD6Lztn+/cT9BdjU3L2x+H8ArduBYM/PUj4S2g1xzxA6rN+0YSciMcVn377ewCXDEao7H/n0A0WuXeOpaw9HlHVDcDO+47cCcuecgWdb9+53b/sbM/ELUpoM7rY2tQnfnWlPxsaEDTvXDzbjDclPvwKSj2Z3XHhVwtFTZHb6ABfT76DsaklZtrib8Fl/jpjtwxDm2h9uJxzOpZ2BfYpVddzCz+Z3dAWNN3wGtV08MWs8f614KWsFOTLqEEZI9fTx1O3garahhHqw5Sr9YYPs+86hqero0gTsdWvOxMmSaTJtN5m0nJiP3dORg5qmPzL49owZrrn1CRdQ1O7mwfefd4WkF5+50B/FTVc4acyHzvcPNDqYMkDHqU8g8oo60HXAfmhpOfE3Oj+9D3XlWSXfinsGa+BEpyvogzRgqWJJx8Nyqk9GZZYfvnUcMOnLPMFITK1x3XPha8GjbfWauOU4ZPnazfyloxZ5O/WDH0Zoxzsu6A1GDfQd3OuA+ghWwwwLzAkcchOsdXgkaHz7Lz/iSwWrOzM3NoZu8m+bW7LyHtDVDl45NzQlgPwOZ+2tjrvzUcNRngrpnF292TOqofq3OmCUG22yX5oagORbmbT9Dpub60kgw+vD5ifKmzWEPyRCcV/dNjVXdweSYuB7X0LTZ7mxjsAKWHTZ9iaRpNenhTs898/iUN2syPXS0Noa46rJ9uzPHvmMkt5OJNdBmu7PNweoObHJqP6BNz1Vw4udTPXSAGqZVK75hdw5Da24HVo31ie6sB3HVnU3SF+ojG5Nr773JlVp8iMb+AA1rhm/YjZnJuJqJddrYane6SW/RxE0f2W1PHx60h03PNVv9ov6gR+tVqxzMNRDTZA7DQfrSTaM7pzTZHhvVuethU0H8Jf05zzkdrO7Mg3rGNxh34Bv23Cb5pHmN26nLBxzM5W96iiVWoE77SkxsxpA2evWgUWtuRvfv0yeqdxGd/4Dg6pw8MttcARntGVrHnHrNN9k6fQV4jzmS5Zd4SldNyLA9KiC6r6GHVh0J1qBNpjkImewZMnNVQ/uWJXn+OlfnZM7A9kycQ0+bb+qsp8lWmYXthZlY07wERJeHPssPFGeagyFjrGA/4FEBcTX05Bj8yEKcqR6bCUmsMx1wVEN0fpz4+YSDfXMqrDpVsB3tz4roquHAQV8hHzNqBU8f7tlYQ2OXPxF1ScpP/HOCxqOgq1awbDnVeWHV2JNL6+sZ8jFZpmiV5rYlak3THbc2BpOF9VPlGQ4caqbVvQKWM2tmDnqiO1OfWN1jld5g3dyhgmg9dCcbNdQQF9bk+YlLzsGe5rge4g5zBa77N2w+N3cWVg3qQQdk6sObTKsu0Yqbsqr7XGWGTHsU6syaPD9wScypBzWwA8myA0sF6w6bMAetM91RfcY1d1PrVV3mCqiBvoNWD2ogLqxuPj/h0ZA/ww5LRXTZoQKeB0RvDq12RyOE/M0pmepbuqrLFCuo02suzcWDh6UWb/NSlDeH44wH3KK6uiSw7NsKeEZ7CGeiqzrXyZqNEARu3DlXQ3ReVn34CypOWDfXXFw1HpBhdnFbNdZkzNDooJll1RB1WhU11jdJXwl1ZmH18QvKV66aDLdp1VdYMGWKoe0wPROnZcXJ6JrFOTgccPWcNdGF9dzld9Q0CnDTVeeMN00E5jWdxr49SaMhTl+rLjCbH9Sgw4nuRNA6zgurbv4Kz2hjnYabYZnPRKubojH5Gq+nIIzT13p+CgfNoDXj1Z6ONtsHdVrTLVNmft5+Ka04Yw0YdHBeIM6sLnV6y8dVJ0PSgw7CeDRnovWQbUeaQWty3Gntk2k+MlN8yKruoSG5WTMoUV2OM4SbDoZxmkeCNdADgybzGl0Nq0atGWxCTztedVBP2YQ4zetvazU0euJGUOLCqvtSZ8ch28N4RK4dYYpaE/Qm6UDTw1WtB/WqHbTqNcRpXt5weZ9JaA0eDbfhNhCEec0nIwzSdvQwEup8mx0hWJMREHBsO3quWg/q0cjkvKzZ7ZdQWtGExEGtvSkEIJ5r7fI9NDVUcOQY1BrIqDS22vVwtXHwqnbQjjDNy5rdcqUW+vMZK3LqoLehqbPBmDE2rUfaU6dVfcJEMBmC2mjbQU+Tv6qdI0wu66nHL7CwrODoOnirrwxq8NZMSzKP11M2GcCOnB41Q2Ow0b5Lj2q46si0sOa3c5ePcGA/0nN1OEnrGBOhbzXptdGcdifb5tpetTkJ0KpJnY1OLuvhln1YZn4+ZWaE7g5Xaw5oacavFcbQDynZRq3Bc9DqVc+12cY6G3VhPdxOFZ/ykhA1jC13uHqgPTBOEprhFM1h92Kr9pxoD5s6G50X1lceTzOXz5kxXEe4ozWZPtsYmld4E332oD1sMiE6s6zH21GpxecsLJ8VREOT4WpNYubmcG1MOGzy11f6bJOHXKPWwejMsr72PPj59KUofSbejqxRe0aGbDBpch62L/QvObR6tXGc1AXW1x7PUgv9+RU+K4jWyVUORyBpznnCU316tTkxaHPVcdIvWFhfeGw+LH+Ll6LUZwVTrMNV7+cYbHTIv6BHfape00w9qISRSb9gfXHzkZRqoZdfYGHp0wqmmnMkNGeyJ3rI9IDpiRoYCCOTX8B6fksfWuYuP7/D8qnVTE0Y76cTGoc390BzdtBGDY11ftKvdD2/nSv051deCi2faqyCI69Bc9Ckp5rTw4EGa6I6+ZWu57ejUi1+jRaWJunIG2hIQ6ZWTZoXc+Ew6uRXup7f8g9LtVAvv4XC0qcmjnA0mVETSA6H5uUhBiY1ZmdYsue2o1It1MvP7y0sPfDEdCaFkE9eD1Oc1K+sy9kT2/GjzF1+fnOh5VMPuE8CowpRc4rZkE6cmaNT8nW4vGU7WaaFl59fTaE+NXG6TnofSdSoB28F5vTr7PLiwXbymRT688svFJZPzWRHjz8yH59YTq5nt7PPUi305w8sSp9q1MwvnJWzueX8ie3ko0wL/fkTL4WlT43VDL+B7Fd6Ynk12fIPdfNRpoX+/JmXwtKnVsxRJ41OGvVNnoEZvmA5ux5s+Uf2WaaFXv4cS59aEWdQp5yfAL5ggZmv5eyqmS3/yD4zhf78sZdCS5/ZExqndx/A8s41u+Uf2WeZFnr5c6TQ0owzkHuZhFPLe8/pQ8u0UC8/fzSFlhnfBXyl88nlFzy2p2VaqJc/TAu19KkewRng63BePrmm8DB5+CyzhV5+/jyKtPSpSUzggFPLJ9eUg4dlvtDLz9+xUEufadQMCfnc/Dl5JM/ysNCfv2aRlvrMZpjk7Bcw86HNR1LmC73w8xelUEvNmOON79v0sWXKfKFefv6yFFqmz8OHuYUZllfXFB7ZTR/6fFgeFunl5+9LkZbqgc6wAG96HCdPLQ+L9PLzd04s06f6yC/MQG6GjC8+LZ/lYZFefv7aiVqqT8vcbyzPFik/f3EyaZn/WHm2yPPz14eMZo7fUZ4vDvn5d8ypZz5aHMLPvykk+Y8UJ/n5F+Yg/4biNPz8SwNHb4ef/wACvIH05/8CCgA=",
	wing: "data:image/webp;base64,UklGRgIPAABXRUJQVlA4TPUOAAAvn8AkEM+gKJKkhgxysIB/DfC+FzknHWoiSVIOFJyhM/4m3sGHnzKTmraRpJmtlsAyWQDHn8Z/5X9Xzn/kNOc0ge+czazZmDN/ggKFN2AkgoQXHBCIv/tF3gP86BV4jcY90lmIXD5c/mZGnX6Bwdtt21oi29qWgjCVUCcELyHx///pfBHNXOfTOdfVWkT/J+D3f9n/U/k/ixM0KtWqAL+k/2FItlFbbfKt2qhU/hf9gcZTm23S9uUm32bJ/of8OUGjtuoZdNfW0J3zva0d6N4WG/UE/Fc0tJXndM+GS3dP6d0FUM90tOdUtTml/7o/jbbqboee6QD1GvSiSZ92Q4Td0AEZkuzpnwZtuqtd0sOuhstNvegtfcBlgMgQ1A5IaMHEE/+mP9C02T3t0t6wK+H26gBmHhD2Dohdeqa1abU58S+CNrunXW/QAXzcjhx4RNi9+YBgB32GMy2JnuAfQ6Ot7h2o0D8IA3A7NjzSxMRbzwAdcD8Dbdqc4F/S2LqrXRrUB7evAW61QYo3kyFrEQi3y13tzt0ZWhtP8K9otHVXuzTolcvjpoOVV8hch1dL+cye0NroCf42VGg8s2uXBvUKA7cXr8DAFXiP3rUDztBqo574uwQaz0CXhnTgygDUPLiX677Sl7y728EZ2rTxr2taPcPeQcgOwMXkAQQV6EtqTjXxpQcxgTO0auMJ/h4abT1D3A35ISc8Sjt9R81XNvFLB6DmAfS7scueabXxBH/TmQ7innnAUPIBHXs11X05JpT2B6ixwJlWbfxrGm3PXRrS2wO4JEHvfZcWeMPYO0yPJNzingXtQIDExhN/AY3adtk96HDTxJxdXTpao8a8Wz/5gCUGct2YUWMHZ1ptPPFxNK2eSXaDAxWGtKvf1lE3HbNb9ejmpK4LEGdYulFjx24kB62NJz6tVc/JrkaGW7bQazIWN1d1O3bUbXXUZE7Addq6MdJ36RlobTzBx513td/1AbfiRYN9EpnW8WejMrekc3Zy1JjagQuosKqbTpG+RGvjh9F6pksMt5pgJ9A7Om/+vJibF75hZkpHY7aDc9Gtdho7IKG10RMfA627Xe4xUAjaZePo+vPyps7wXc7ECjiD6bQws7ClowVaGz3xITStu/Z3DUl4QB+MXX7Vn9pNheX74Ckzpue8UzYHjJqBRv0QmtZd78WgPnpDTEZ1/aneXN0mPQqMjNkOi5FJmMkwauw4A22jH7Prva6PTnOct9Wfl7dV58nv42fI6aaTo72RDuI8xskF1tEOEhtPfMCfpu2qQhphZtn058DV+QjrFlZh80enSK8d7EIEFthGI108Q2vjJzStHX2oi8ywsPlzpLrw/eqcTWZYEjf9YR1jV9trHJMIHZyhbfT0tqZ1t/c+QKbXyDdvIGEGFiAz1y+w5nTuyrsZnRaIdDnaxhNvok3CgwG+KviOjNNx5QVmYKlZUl3dslOhr43TMka63tidgbbxTTStuxoeX3pPg/YR6OJ41FpRXl61PPUvBSWOQN9FyNh4ekuTC94KIR/pYPo5clt105kFKHiYpaD2w92EPnLXHjgDrY0njqNp3TV4v/mll3so7toxHrGt6TwJCzAv6eZhc79rR1AH4BK073b7uxoZ9X1Nq3tv8Ja7lkwYD1h11Emd+QYybFZZHXftDTpkHvTuarxr6DO0Nh7XtLp3vQ9uflX0Jh2Mh03pN2CW7EFjB72GAbj4APqwS4QB7PgMw6UiVHZHbaXvA5057u5lMBeUhDpPR7W6qwM39evmg9Jux5lDXE2+D1QjoGMVHQS9++By0wEyX94j2nsGWo+jdVcfOav249hcnZw5gByMWlrIeXlwyxEel6800xU8vaN/3EqGcsJ4CJvOHEPMd4yacxm7oF6BxIEr5LxrwXfdKkN+QDM/H0YJRjeXZOqDXmuucPFm4l07zpB4SKPtHvsj0u6VNbsVDyPpcy6wOWlhyF7hot7y975g4+mwLg4V4ZXVAxYyMqcHENNuVOcFmKfIS5cq+w7O8IZ2NzhwwM2KLbNmJ13ImAFeggiMupmJ3AswcOWlR9fHEm+4vfTgZlfYtGJS5wUSyQGvzHFaxi2FSK8Vee9etEQXyXkEza6GR4kcMNDBuP1gCrjqzKTfLJBIfoZX1CUzRQjZGtV7qPDRd/H5rkeJOjqmTV1180ddmOG7uJhmYM5+z8CC5WmMhHLBcpUd51YPIRNqgtrRPxgAx+0H1nRLX2BJNEOywMyCWaYx7mrFgZeCn+BQCGoH6HWAOG0/rDo6HzIuGTO1Zplit6vB3gMA1cKDDp4c1u4GB6joANVk8wfXUZ0PmEZdExdQC+an2CXB/ghS1VJ/HAULBLvS7RGn7QddHdV5U5eZ78pRXZPKBcxPsYPeoPaG4X2+oXW3Cw63lNJuuEcq5gpe0jpXM+s0dhDMPLh/wjPnAeddO8KDmwNVEmH7yU0JGeYKRo14yDzGLpQTDlC9FXqNT9pGPb3WZPoHQ3rRkLDL6PaT6jLpOLPkgAIR6MfptXmKfchf8/dXQ5aC7yFDcIDrRYN2sHtmXH+qnCEDL8lcs6nLFPt77vqeW/FBr09aP2MIHeyeYf2p+oYKmF9hKayZKTJwN1xrj+EjrLpy0SHZk2fV/J1mNKFOxrkuwnDXy7t4Ib7t7pVL5tHB7nlcf0pLAZcK6nYZ1yQ7Av3di9ZU3y+GA+I7moKXXOjS0Z86MkuJOS3t6biW5kjv/fJiFYWLh5w+wg5Gf8pbxZST7AxMNYxrYYJ+N7yB14IRzm3m97XWXQtft0dudH2B+ZtJ54UtzcDMZIS+SzyPZhZix18wHmbGzJc+CNrHafl55TtjIUs6jUam0po4dtAH79Wf8ORN9wpC7zhvdR5kwpQs424c1UyXxEedVl1eChrHt4W7l8QHwX50rdgKU46aVWBTJ7Y5JgtsOnb0PuAFK7zc9ZUIb6A18X75SgeC3R5HfWVKI1WrbnmAmWmcNLNr8LWXgxYuoXf0Axwo7eromtleoW5Tf1CXyMKU4hz3jJ9gcgmfBTz6Y5g0AnNFdv2BeYrc6Z2Ujgi7Qb2/N2S8eXlfkzG5fAEPOtj1/AKl7SWdxwh3DXvQzsrLW0L+ogZ7x/dY0AeZvoPd8zPZ0iUhZl8YFejvgymhzJXLmwtetDd5vsXEJDJwCXvG87OOKbfWrGOXDUPmyytkBm76IT6oaj5gSHdzW8masWrs8gNfev9Sr9mbH9Wr0/gs/TngVHMZKuC8vWlh7PLh/lW8ZfQrfU/IPtBeI2PN7xHkDA51o5s/Vhlh1NJYutfkv/LvewD2xsQn5+R0UNvljDCAJoxbZTJPkbG0MMYu298rbn+BmfFT1LrxJeZpTNdNlzH23Ws3Ndz06xPMqX2EyfH5Dmndy0Ma3DuYtuoEJmDd1CnuGkzM3dKgXvmcbB+ZdH1C+1nazbkfEnXJq86xywh69/rlLQ3ZT+qDfWZe/YCu4krY7cYtu1Y4usCWjn3wpsHe4P0K3HyEyoJv69PI5Mz6fNOZvYPE4aLXezCOS7IatSuP07zpMsUuY6/e9QqE6g+KwOScad/imZID8Ogjk8ssY+xe1NXRfh9u6SMDV0K+A9Xc/V29EZic39fk9hoikwpj9/JuHO0dMl/egz4A890Ll3eG0vTNDOub2mRX+8g+FJhk1w56rRMI3rIDIa2wcEkuB9+9aFAhwvTNXHf6PfRPqYOQu0fUTJ9Fkz0T9MpNh8KR18zNi1AarupdzXTJ5JwtNJ54R5fNwT0f1OQB4cWr7wW43NThCgMXBa7c04sOoe+IMBfX53ukOUPuboGa9IC3X4Gh9soA3FMu2quRcS76hDb3e1R7hqTXe4GMBfDTD7mnQCbCNLMkq7nmOGmteEBmN/TqPQPgFf62R86Yneb8qhZOhzUJe2eOAXYNXa8+4Dpkr+lQvn7gTQvX5PKAe1Bjdprza93ve+h2cmQ6oH+kVwaun/+4qVfgkga17nvOrxXNO/60ega6EgRNyHBRrwyfhlp4kKh9iOk3czpp5kmb+T38xCvxQbQDdn0M5Lx+uCYhvUjI90bgG+bCWnc6TprWM5CLWTv2dAAy+lloeL03wjcwF9fsk1YbT7/vpMn0VXSw65DN+VmE12P6zVybeX4GSUcddJQg49/Ux3SaqxeSJ7TavEtaz5CjBIRrAf6u3mSai0tuVZ+l0+9H0MdXgHsBLnxUqO6NMDlXkKzqE2g/QloT4rEFILkUVOBeZsiZL/URhMm5cgFm1kKrNp5+39a0njkMGGAnDV6Cesneq0P+kgvFmHwzl5f8/ELzCdK0vgXYwwAWAb0fUtkHjen0zVxe8jOshTZz+v0E2zMcMmkGGEIlFg+Lxe8J5pfWGbNPWrXx9BE0rcelCYdU92mI1dP8Pdcna/lJptHT7ydC056B41Tos+T1hV4BrZicK5d0VTC7uT6BVhs9/X4ojWcgMh6m1PevU/mdzrVLqfYJtLnfDz3R6Bl4vuO7nBw6fzvnv5nf8wTatNHT59DYnnnCeNj3q1bPb86sr7Rpo6ffjwWa1uRM1VjjK8yfm6zVT2jTRk+/HwzQ6vMMjFpAK9S/hIX1lXPSfJpCY2vBAmqNNaJA4Rt4A2v9k3OrNurp98OhsbVgjR5gFuAj1vonbdqop9+/wdYzPMeXj7LivWv9kzZt1NPv5wONrWeewEG+AMzvXlhffNKmjZ74/SuhsdWE9/ApyytPaNNGT79/KzTa6hOomQ5A5SPW2ie0aaMnfv8iaLTVJ1SY+5bqZH7zwlr5hDbb6InfvxlotNUnUFLn1+Z3L7BWPoE22+iJ378cGm3VZ7bglE9mDluyhbXyCW220RO/fz80aWsmrVJnUN/BvNY+0zbf6InffyEk2moOWNWCMxy05NfN0jNt84164vdfSaKtVmnOOW9pmRcorJae2TbfpCd+/6HQpG36TJNyxspFfP2ZtuVGPcHvvxUaNdFnWvN+0rbcpCf4/ecCTbZVn8D5E56SbctNeoLffzFpYlt+lg8he07aYpM9pf+kLNBkM1oAzq8+89Y2+dPvvx6gySYf2+SB3/9EyKif0ZTh978TICke1tQCv/+9ALk3A/z+Z5N9A+nvfz/VOcq///PkD3Dyf00FAA==",
	eye: "data:image/webp;base64,UklGRl4RAABXRUJQVlA4TFIRAAAvn8AkEN/AOpKkVHj+KdqfOzxZ4lDktm3jAPn/K5OO094LittGUnaP+u/xfsxM8x9njs+aei1C8JzX9Kcgkmfh9UqoU5nfc77/IPyL/YfguPgASvKj7vOe6yOAUT14MLc7mu9vPhsGb7dt521r29o0AZIAX8RX8NX//48CJCUlWd9WKb1F9H8Cfv9P8s/NDP6XAENhs8/+/KN+YuOwpkDvxRuryPBPyqDARFBcezmQirRkHSaZ8W8BrOQKN0nALGmSKvlJkp/l05MEBVYyUpb+J4ChcBa8JmlOR7OiOTFdI4+NDf+CH8lYScXkAF9NNYmGTlOAOVF7qZogIalyFLGxyoC/GgaHFZMkr0BXA03ypQBoahg7+bqvgcA8STXj5FQVXtYVhgz+Uj+yKhxQ+WpSpToANTQXA4EaGlqk/qJvOtEOTKGrvRwFYDP4GxkKnJ+QFKRKPQFaoIG2bmFoIVXTDtQQBhradD9KU1yANWTwlzHYAuc1zZPUqx57oK0T7d2aBmogMUSkuJJ3hTWQ8Tf5MRTgvGZpUg2j1NPW0LQMJGpaCAyJgdAmaCCF1CUq7wow8d/CSirwrpqWWYGxRgGpraMhDgPUhOTQVBqglVQPtNRc9MAsafKSHIWBjL8CVnJemqR6CcAokFSHdkgGIgKwAkPTDkAlYG3eIXktkwNryIA/DqtiWhJVzRSAkRr6ANsAq6Tt2A84DyIYaoZ0AwNvkKbFS85K5o8DU8CkSlOqC3ENAY41WcJ+sSucyxZqAjDQ3BmIApDCyxVYGbI/CmxR+kl1Nc2qxLx0NQH6MbFprNby0vkqbCdICum6IXDVAyE5T9ICfqq8lQwZ/DEGB36Z6qrp5ldVh1WvSt1KDwSOfqykWz5s7pRWSQHqVN3SXyfGaoJZUiVXWBky+EOsCgfzwktSjQLbS5W2VT34pAMSEoAcksIa15UUoIZOV5JUj1KAuV+p5AqsgQz+ACsVjkpz95LUUAeWIM2bVPvcJx2QS/JxCSRUjZu0VtK4SvXYpcf0RaWBsfKOAgP8AQYrNy2z5NUkA5V/sW8qIVdCuDwuAUmAl5SLatNJXUlhpXtQAxpCFQVmL0dhgOz7rMNPmlVXzUVXv5aDtSrJVdXTPFUlkItYaZeQ/AmEahRXY7KhBhpITZKXKwyQfRfGOippCjWkwop0QAm4eV9GR3k7l5wkeUm5VPqTgyXizqtJNEDNAG09zZO8KwzwXdjCV5L6IRoaArCts7wrwcXlw1zgkFTipVwwbQdawtXYSYqkhDSAxlnS5AoMZN+ELVylmjDU0FATgGXT7Ms4yqULSYCrJihzKZIg99MBATrpFUfPe6LKFVhDxtdg5SrVQFtDqFOb5MvYASU3iOYTDkrIgZSotmh6Xb8HGFX5wsqQ8SVgHVUNtAkkwabF5yU4VCalK6Z1S+U2l/CVhFXuDlhqbrwzCqPqyWENfIuxjqqroaWqFS72U7nk5XLpQo6I/WQMJ0dV5mlXCSuV0wlKdHpbiLtJzspA9hXYwk31KA33dpY8ck/w57zuxzavUijzSyopt8KfsMwvqXtbF5LzJLnCGviGH1t4TeppAy11gErqN425JAeKS1BiPmGbfLVK8iVXVMoluRNYupe6Hl5qeNaTYJ7kCytDxudMwayphyHQwEC0CZdL3FEinLAtaJ0rR/kGRVvfiQ/AhVRYAx/7+bWFn1Wpp4WGAWq0bEdV5poclCQUu+U4j6ma9/PwuVQCKckrl81VnUCgh8CrAfW8YSRASl8AVtNcaZRamouwHXsJfq2I80umE7xjO5nKCyRDwkrK/S0a4C1xF6mwMmQfkrF+UtWNUg0tAzWsx7mVMC3lZQT+gKVEJ1MZKWFAJV65lZTPJ2yBxOstASK6yEd8COs1aV5G1Q3ULdHBWcIyuTy+Wg5YmPdzm0ogj9EdRf4EriQ96kIczZrkCysDH8lsQsso1dAy1LAebCXIk7icjugAynSkSCV4cslK+ZZ46TP0zJImqbD6kJVj1qRRapPRdjCWeEde3poPvABcnnJEhiyalKeJXlL/nk6jopfELE0qsIbsQ9U83ZIUtgOiXCV3wuql85hyXQCSec/2kgL0b1LgFTFLkyusPoJ1lSZJYWyTkgLrQelK96RaJmk/qzy+UJSZEtxVecaJHqkJPNGo/iVpIJIrsDKfKPyUDNzow5bwcmUCkBT2SdrWPH1lMkNUTT6XzSUXrS+pj5t3SHqpZYBoKqyU8TZMMUmzFKCtaRmlnnBG4MsbUJ1wbPK55HTX/IgSps3nsjJ5OUWvj7XAALO0ROYTbtKcqoGBsY8gKoFckovOyOdS6eCGyVLb4XPJgNvuNdDzNhJTQcT77CTNGsNAQle5ErrwZ6w8VXJhyDCorI4zl0yGcUTrS1JP4FPMcgVYmfdZxySNageamgFJQTqhdFGeBL+ccEx5AtANQHILlDI/mXDnA+k9bXogzEuKz4w1DNAMUUjhPORXnHBMJc9kwOZyLD63+smwqS5S4ukjwuI/VbiqvgBqbknkKpEkTo6qBFJ66itHbs2PMvIzuSb0HVOkz/SJNkWASSdUzi9VSYJJp8oLAQ9cJeUJZUVq+RIGwiQXZXyEtqaJ6lsq2deqzCXBJLn8ZgkJEpXkc1n996vMutTre5ikL2hRTUNiTOikhFWLTzh8/jBBspJXLpvxnzD5lAp/k2rsBxItNUO4ooTFp+IUJAQX1VT5XNZk/P5nrDuTWw+8JPGn/WCLugsMNbREgVHRDiV4yeWSbnAV4/BTJXJZw4+ELc+Lpgde6mg+NitlPsEzadKyH4vL5VVdIYkHzkuqcsmaH0nk7rxcRvVAJ9WN3tHemi74RAM1NFAD4+WyHVMuqfJVLpUgiQd+Xia5XLLmRxK5Py/XUap7QqcaQn/RIg1ACzTQgmZp8u5zNOkaGG+uBz6X5CuvklwSV4Dw2paqzK0M2Y9kcndeh1F9jQLUQE/UpgdaoIlbadbC56a6eUfDazlYfS6Vft083CI+Vi+XW8mQ/f7I2NLf6GEN6XpUD69uIJWOXtJ8K/sEqfoBYT32xedlPOHJuet1MPtcsjJkYJSX/ry59QsBljUsYwIYuAUvSfOt7F1WrmoubzWAtOzbOkU5sUtHeJcnU8pLP5+3wjIGOFjHGwxEDXyVrMpKdQMDPELztkpj9EkrQ1765Uwv43ECi1SvJwcaFUhxRTTAnPycKqkBhvoZWqUA3uVS+TZZk7vpvKy8q9bzgLGqtxNYxxBJtEML1NBAy3BjkuM74FndL4RYlcvfD/68nn0J1NsBS6/EsQTGuKFVB0RtIpDQ51z1SvGoZ5EU2A6FyrsnJQ4dfjpvzr5MjwdsC9J5gJYrOg0tDc8cFJ8pfd3U71EysGoJi7aTknDmElMJCg6O86bKmz7SgnSwozVcDdDStPGD4hNYlfgm2T7iQvGx6bw7iYezL++6+oS+7jdJO9IaGKVG/QC0yeFeEZmPuCpq7zSXUg1KL+cnD5fr1nhCpVXaVmmTVgXGHgKJIR3mW+Yz+Ig3tEOdAqQA+7sOXF5eS0qNa3qTFKAnAEPLkO76aCFh4OddJqGWhvoNRAH6GvUEtKxn4OR45sv8FiesYSHlx01ruG6HdJdYwEf2fSSorsYHTU1DG2ighSBJfXxsAXSCpESoyps5bMd5aIFxlXrnx23V1Zh6dT2zlhv6WNMC9Zhu3toC0c3AQmDrw7ofnGzhIAXMJxzbMkocqyup93BZM9DyknoCy63s980/KVc1LfAx7qkHalC/bscJHMDJWrsSdMKxjRLgS6oAPVEc9YQLXIGVzIe8Kn0Fb4E+rCcccMaqSrwiGNUfmxzR0qM1QA+dINyykvmcqrodr99C9Iov+hvNANsZjjM+dh2jV9gixnrdNHopHJx9NQZA3Z+i5lskdeqTA9Q0tAx14FhGrZt0ANVYV+GAMG7SUXmtAD0BRnXqCcDyHTZyeKTqY6+bF0O6aamBdozDGp2qSj8fwCZgLNGmg36J9EcAXvVH2ltdarhs7/VhiY6p9G494hNKoDpgCYk+sXxJVtypaj7xupsYWmigBRqgHkLcQ4Dt5AheUkRK4WQh0I+8w5C9Swl/oRre9nqiK1qauG1uLdvJEbw0Jva6xPkTlp7QxwGWy0mFNZ+hxAE+kmq+oIsHaJvHNaN6wiwtJ5ukI+kqjdsqnfQQoCfAcouPmIg7qhmbz3TpIX6LNMfrdnHCFI4tYl/C9QLaJH2BVcpfqeYz3T1abg0EoB+jStsCKY6oR9JyJWlLTwXYT/zckr5BiZfaBC3PYJk1VSLezouQXLmUtMU7+AL7IT2S6ne87nbSSwIGaG+1wBgBkqI+sJ/LvoankrbkDkyFlUz2+xXVdc1H0tBC09Kk28uxlwKtJK4XQifppS61StqSe/JTslLpoITqbs3U6R4vkjfa60R7dxSPX1L3ktQpWiVtD7DmI5gCB5T+lmomJV4xN1MD3KCB9sO6DrCs0pbcBRw7vrDf4fVANUSv9JPhwXuHtwRYYLvcj+ROEWWfEKbA+ThRkxDADaWUjvjMADzqAiywXR/JnSn1+xlbcKNOShIguHgaPXzEPcUBWNhu7le+sDLZhzAF7gm6Ce+QHvHoruIALGx399TOVCR+P2MivKQ7cUqieamHBxr6h914994rDsDCdnOH48JF2ae4p5oGiLgQRECnG3oy3r8zvKQALKu2mzsc8Q6TK6xkPiXshaIm+ZJqbvBSxJ1OD3jLEAdgYdV2c4fjYnIFVobfT2e24A7RK+5rqCTi1+NO0njdd3rDEIfUdnuH40aB/Q5swTu6PgCvJgHc6ySNd7unPWEgXC7b9Z4+bvjIkH1MmALcPV5Sn1h6QveK4lQnabz/SCG9Sst2c08fN32BlSH7/ULDM15dHxIQQBeKOknjZ0J6lba7e/q4ORWp36+EwpFQVDd0/Q0Cy9zd4FEnjULSRUiu8Zbcbx13fWTIvgIMDqJJTQ009OFGvErqpDC+aujCne6GOmnpCazSIm3p/f5x1xdgDdnvlxoKh9ckqarhpUYpUutlYKkh3IFOMNdLgE4LBLZV280dDhLHw6kAK8Pv10Lh8JqS80uq37QBSOGptESs2+M9Th2XZ8JRYGW+KcMWDnxC6poxtdzavn5PHonjBgfL5IqvU2YoHPhJ8ySpC8yPti/e7x/AfiT3xM7kKLAyZHwThsKBn6VJUpilb9l5xBsuI8598gVYGTJ+v9pg5fDTPEla+MSqB9p5wOM76cUXYCWT/X45xkrOT8m36I4effjJvvgCrJTxdQKrgk/oxvb0Q8f9c59cAVaG7Pf7wUABH1Dq+f7Z4+HioMDKkP3+iREFzt9YvmD/7PF0X7wrwMr8MRiwkvOaIt3atEqKdi749HH3jHYmX4CVDGR/hiQwVgVeU6Qbm6QnfPq4H+3L5AuwkoHs988FA7bwbop0sd26fNsRP4sXXwBWMpD9/tEYrOTwkaJNIqmPHOwcN3cgcSYWJl8AVjJkv386BqxU+EgL25Uk8a7j8YN9wRVgJRnIfv98MFipcH6SFthidoiQtEvcPz69+AKwkgzZ718RDFaSS8Em7ckF2NMScPAFy+QLwEqGjN+/JQYbO2BJplh2DmBPH8AObIJnezTJF2CThozfvydgsJIcBX4BUkdyTx/Jne1dbvJFbGNDxu/fFQw2WcAU73Ak9/i4uZ/sx+PFOyiSVjKQ8fvXBQxgJRUwyS2w3zjghAQnx8NF8sWllWQg4/evDCa2kgpwsOzRsgPHCeyJp5ODIm1jQ8bv35sIsElH4Se34CXBFO8s+6EFL+lYDoprmzZk/P7VAUwcSSqS7r1eRWyF0gbI+P0HEpFKF+8WoJsGMn7/jcQGuPo4kGEg+/2ngkkn4H3EGfz8/oMBc/cRcYaBjN9/OpAiSxvIwMQZoP8Vea7/Hwo=",
	tail: "data:image/webp;base64,UklGRpwOAABXRUJQVlA4TI8OAAAvn8AkEM/AJgCANOhFG/onoIEFcIe51GAaAEAaHJL/n3iFTtITHLYLGEeylQi5QgzkHwI5cCYGd5fdmv+oL+1/YYdihiQUByMhifC7H5HAgZYHPi/6IQF9CKAQm/iB93P255+/HV5sUV9DgvK+gHDPtNQYfEu2bTW2bVvRdKFyE4EUSI3a//9LKbmUWkGK/jQuOUf0H6Ik206iuefI8xFUwkuw+wH//KdofFn8ieOL/BfgJP0hzxIhpJMFfg3Jf5/fe6BOLs66klRdwPeCo/j7jhccJLc3iJHEKC4kZlxpB9JW/UUpRkcrFaK1+HZx4fp9paSL/5hfkoGn0+VK3AuledM6fZfCgPgdCfIM6+tCthjdCEFg4vpdjrnVvBJOM3fFfvCqxHWZAk/0TNTwTdbYgqtLSLjZTz2fLg48iVZOFuM3xETeJPuAOky8tIk8X/mZiRO3s+ICqbbLd67d5Pj2WAK31NEzDsZE9ylKrZWAH3gF2MmO83qLYeZEnxPDzkUzNNry2XPTqImz1Eu2errCCfZZmcRrcYUjNWLAYVLZAS6yHiSlez+TpNF3F69PWdzmWbrt8EyKmG8Q37PQbUfYD2yCIKIkzzT286WFCuVDBEu0kmYNdvFhoNRzY1Y39ExdmzKaKaBFGqUmS7OPVlDlfcLHfWEpu9FztNNIkDFLm3qLLmlmssiPl8h08bUEg/An2RzJKmGnD3DbkWgTMvQucpKAhS9JSZcgylKrQOmt+opsKSVj9Ega1JFEy6RGQgiVRplrE2ZOa38XvSDxHv5YcQENi9gMzHyHS04XkuanIbKYdBWWk0Xb3SXYo8Em+KZK3gyMm4FJmjHFHyghIMUzm6f0lwDZNqkCKZR0l3LPVu+sJXiWnPsAywXuP9zUKPjd1w2Mhc0rN1bzQgSCg0uirCzemLeV3tYUcMWZ+llg0CBpbdE5uAbPIA9fy1NkI6dggpB4OnbkLL1P3Kp5AgMgYzTbkbzLXDpzrvTwKVRSrOvC5krJTr2AMXm9yx2sD0wcbTutBJ9WvPY2nrW6OBYSa0DL3HSX5pXJdPjky7ujr6qgKu2A/EM9yua1AIqEOuLC5nrma6FvGNLqW89b5FvmHaH6JKqn+0huauGLASuJesm2Bw7EhIUdJekSxIPkhnqoUporz8cKnFZay2hyic3EjzTQksygRvbTcWcIN4f7o0AhkS08m46DG0laoaVLl2AHZLRWIiuGGoRsEv3ekGDRZ61iYHJckjS3nUPyokd+d4C2TGVXrTZSasns8OdYI+llKpIwsq5HCraQtNLW0G28FfT44SO1HgpWSC4lKCrUZqlHNXo6PSWvFnVXRPI6qDoFbwrb6FDnr8RmZWBKjS5wDeLpDe42k/P9pdR4ydW70HoCrbYItG/mrKAVdcRnQX0FLeyA9UZH+3qolWJL8Jujac9hFCf2nWtPeeOlaolkl7NphuaXsm3soImlWwQK274jLLbGXBhdjvBzkYVoYi3SsTVtmwxDdg0kOC862JSFlExn0H4uiCtrkZUkkOzH6+KUHi9XF+A0ubS7VrpWzVIyieWx7bCEBa+dgaBGR3ASdPtXYHIvvs8/tKl5qQHaLQWlQ+RHTp1Z4w3omBotm+vUSMzaFu5McugYWrTrIvYkJWNtlRcr+huSr/bnFVha9LjnjuTmWXDMsXu7/K2IqFKDTQFSUuNmH4BphsIMTZlWMutlSC8fwVoPSHE0m8aNBqlNLCC8ToYAqF73FrrJGG/cGCRZdTq5q9BbKhjOY8uxAGSXTJajNuOlxV8ocnJl784GE4w6TcPNZs6gjkTyCwkyLNf9vNaj2zHgNwY2g1z7ZCeb6drC28Ko3qn7oasqCwW9GiXBdLCwxJa9kUOeqhLQztJwG6OJac8U5w8brjUH/Wus8YWgggodqwIMh7R5VpJfDU7zKucE3ZZv3mz3J8mxt1JYuc0jjiS6Be8WcBwUXV2hB0aBiRnLKmxM2fej20MBkBcMvZkOmL1N4RTCej5acQZaqSy0lcx2dP3iUBfPd7nRDOK3IzSbAwku5hAhNHbMb7UBI4XYWBpBvrMMiWckpMUhqo6MVrppvkvwVmg97KKOhGXN9M1IWY2OAGoD3gI63sFQlYIKk1Yab9CsLyJ3KgJtUq4jHIDeAO0pes9S0FpCJIM4eOK14DqOpN43EYI3iFnOkrLVpka0lci4igEjLbvgiDIkDQISgFoY7H5gvhXkmqoF1N314MIGhOSkm0K0n6+zLmFr2IPTkLTQA1XCLBk+HIX3+jHgO7guG6AipusuLo6JwA3oGWBNZNJPAPY0gl/nGUJewkGiArCtoYA2rsQZ1bUCZLsWE9E15KjnmlWC/ggO2sBdsQA5BaCbJBj4qeC0jwlwE67kbFzwjYs79q3h5LX6dJS+YyH9HY9VMHgb8EJjpSVVvageTiQjSM1ZD15QHpTt/UdHjkVcVtf/MJtLWtAbreECBwwhG2dUZgdAGQ8MlldkBl5CpgK3gJUdM6iQsaCzYBqGQzuBOz84AoD0rZQvLCnlxpEd/uwdbwpWNqpk31ba8LsjYPemToJFOHYYMO02HqyQt9ybAenDTZEGbiTk8UNwH+wNKfgCh8CejtWY7SiFeL2A1Eq3aaTtc6jhwhRnSX22r036RIYReWqka99rCGPeCc9FyGmwfaDmwrNwUmDZGDRxhfqqC6KHkQ64ZQr9a3erLUuG7+i5/lvog5g8XF2POwMSzIpJwI00dSGbvikY/JjVMSlD0DyMs24uQCF7F/nj6q3Oh6PddA4UGRpNvOHvL9h+5G20A48dJ7wCYAxg0KbYRa5HoBAbrchSc46V5AfxoIvO4Iaqt+sCrT1Gx0KjVPDedZwBWBKK0OsRROoRsolhaiQ/yLiS86BCVeIsRuGREcfBuOyAnljeG4qw3gyh1WnFO6wxYCvBVXWqwP/+eqSDEJS7t+BFjhbHFCRxuTRbnU1sOy4mPC5wpqiM3xUxexzyVYtW0pADGw19kp4YV6u2gz4q3IO6C/pEY0DwW4M9cTinfS90nTGQMfUbS3AvpdDDN4j0N2lCynEwu8Z+zsKKlUbwZmKS/tZGowcGPCNU6Zu0l9DGeQ88ASCHjK6RKoFxWiEryzlR2XoUMzQSPHsqfvfEBTC5bT0rzdRaPMjcwhkZ9ZhKEVPrnocRyGIKqDVyaRbaBPbkUAd30tMNjhwGHTAeP1n2q2rgEIY1O7zptzC38rXT8fTH0q6YGEUfaaPKDfMMbY+LKSsFtT5hNxz2RoE3moAdw3pOt0Ct9KoaXE/SN0mHG8P2mUcugs0WNzTXbFx3E0wY0ajCDZrunq4bw1YbtEDirVYzQMC+BB5stK/cFc/y4MNc0Oito5HWiLPxwDt4rYMH1AtDCDjknx14zSJ7gG0qD1+/1KwOfOZh0wuKYNiMmzUOVRXrWMkdWa57IRBE1+NARVoqyJ1/Opjmp/CWKN5Lbn0z06uymg2ZnYHT7pfI3OR4lTWXcR0vfGTFFESlhph7jBtXrm2ZpAhs2jm9VOT+DWffBd5ENBGxalIxWZsd591IMb2nmJQeM3SJsMf2/MuLi5/cSkCsPebRXCLoR1c2tJSSkuwLynvDNeorGXdB9GGoBHs3DJQbFZUayRsgEbX9sS8kzo/X3Pc8UPxMAw6ujBtJTTEJlUzg5eK8gR2NntIhL7pb/JBuesSNIZjM7rl5aEveBkvk0gbMJP0AuJu/AetHdemuJWcLcMhpJxemAu7xZXf5LIxuPEkIfgf3rMpPFlDq9FekRgWGFLDsnyORF1f19517eh6fDZI6VHjjSdJV+huSLU2uLI5LVORib9v7SER3X7y/Jym7F3heExKpUeUt0Ea2Bjwz5P0dtpnq0KCCid4NPogrKUnZQXePcluvbaQq3P2/n417RxbQPu4lwAfAJIf8Qy2cSMBUZaMBG4Vme9AELbbUx9hQ5pIHTPWFCC2sF1xLWSKreApuPaKxTnVU9CCRoB0cpZ2PgDwrAsYw0UFhnJpnHSS6lYFlRS2uGezWquOAp4UDZqkfStidiTLceJhbyTQXCRw8vOgdLvSUe/TriKetUb0f0O9Cw8JFvWD85+eehJ78k7yhgnvYpE/FBg6ZSkCj1JGzD2LC+hglRY/dkNBxDKriuL/ouni+LYCpsrkZOORx9TJ3MXGFTpqXYksP1+/2j7HFZ/oggR2QU+NrMP8QNUoapACLWdZCKenlUkxqg84OUHEp+u7XDkOdfxAnmD1Yfe/sJA2tXMLfWssv6DC6c2bCO+pSoNBZNakF43ngVOJJsPAwe0LJ1WpNKkTPWb4B54ZSgvA5UmWqkKd/jsI0S1JB8oIhABd+CRha9y8sOUNUbpv+szDvKFQk1r1vC3+JGt+zEF6Ea50fP7t8KKScsndFBC9ITye4v+jXhSJ2FompPQbi6TGrSE1W6LpF7yrcrZp9rNIwuwLWtY1q/ZLkLfBxguohS/P9wJgLEbY76lIln91oHo/+q51GysDBi8aH6wAr8KFTSTABaS8/LhzOhNjNWy3xFEgBD1b4TbEtC3qW/D5FJvPBXshtuYov8xLovRZ5kmJlPRjWPgcZoyT/xyglv/HveYOZ2cWjZnc8WOs64vIs9tulwCRLORDHsRifYhF0JV3iEUTZB02wEej+8CioTNHvlFDSoxCBPdXxqgqXoss1vznxXu3xOfKbxVNQwsUuQ/KohEuV/P5MVLwHjtSO3MifkalQFRs9bKarqcq5n5IJm3FX4aFRWj5IeX9egoRBkANXLfyxRUXqk4QJzAgqpD17Y/ER+Fq1xOcl3OJ1GcFRXErxrEspTn3WSnWJcOiwdp5gXrwE+lOTftNafDQi63OKF2Ow1qcqSOh8iv8nU8jVBZxL4XalUs6vmOWkIMiKrxHM86nfEXHidA6jYAXzqlK/afWCTjuWpUv9sgyeaiNa15cTvzbqZxW2+6uRxCgqdsdXad3fvSos9+XCjtR/h4cAAA==",
	spider: "data:image/webp;base64,UklGRn4RAABXRUJQVlA4WAoAAAAQAAAAnwAAkwAAQUxQSOwAAAABcCPAbdvc/z+NLQUE6DpExATwrq+Pl6HfrkC2pWTeRjObaGwHBcymjLmUNI8iZ4HtKHMSpY6h7AGUf5q2I0sopgrSINWcoqYz1PWAqO5+5KbGVrIlixLF9VHv80cmqm6h8gdA9f+m80PL0xWk1WmJ+1EMoI38tJzg15d+pQeBfqPHA28SXHS8h7E27jI8vfjrfriC+Pd+qMfZg+O5geeZget5gW8rnDuxHcz3Qx/82zCxCzP3QxHGtmByB2Y3YHo8AoYjZDBipiJoKKImInAYMgchdwbCByD+MEqOoekI+npR24P+f2GVn/GWClZQOCBsEAAAEEcAnQEqoACUAD4xFolDoiEhEkm93CADBLSAaXCC94J3NPwOipCvy1/wn41/tx64+Sj2n7if2/3AMxfX7mt+/f6f+8elX/D8Ofk1/d+oR+Qfz//R/mDxLgBfzv+xf9Pj3+zPsBfmZ6z/5/w0fv3+39gL+hf4v9hfdY/uf/Z/pfO59Nf+z/T/AJ/OP7J/3f8L7afsR/cT2SP2J/+DPYEao091D9hiaLi0IkOPUmA086OkeJUYa6lbvsF7OyTIf+RusMSJgem+SWU6BOb2shSKnSl9QTLY3w32qw+zF120JcsOGntu+LO3n1qqStYRTCTRxVIJK+GeKu3DC9qf8/LxMo2x3gF2+jDPV8iGj01g2wXPhdEKSFzHSOtAjdsZ6UtDG267UCvP/xefYai/33IsDWANcLtSpUYXN+VmCRKEWtVGUUPkH5PJUmlMeMhQUQmAiUKOfogvsWCK6M6ALYRL6mwqosD5pbkDUVKxp3plM1MF22C2QYUC6jlz9zYsnbR97K5j6U+jEpXhrA8F2Lp9gAZBS6hbERrEvj0VJ9wd/ywXJvmfOFq7QmjZO7/MS46GIdJUXNoqr95SSMaGN6vxM11+emaALyDPZAspdnyzL1TlGUQB7KkNk6EYYIczOS584CMcJ6PLSuSOU5RRxa+AnQa03ROFCDKA7Q1Eu/+1vhoqYIsoY2mFesxjgCRYqqolP6mMzuNaY+McJWo2ZNPCq4Q/qqPwuF2LBW50ay0mdpvmscLvUVrP+5LG5RBUon9KAAD+/2AYIv/+MTzZm/Kc0pHA1lNN3Ls/hRiC3u6qjL0dbOffieti9/RgzBdNl1HGKJf8Po+aKC4kmLYXlHjW0hSu/oXolAPY5ul0KqnR7iT4H6ASr94VCLXFmwsvuB+W+41Qt+dQkjtHOVZSYDemVsiESPcObumELJbr7OomL+rTA/dj0+XDFL5F2K0O5kQLLZobKo2YkGavCp2UbnU3Mu+g/t8uH4rqP7lw38tflw1f6bnham4TT4DKFKstaP8YgeIUI8gJYvTL43gdDb/hnkhJFXSgM7vRjimpuRya+pxi5wn2x4UzQ+ODTRApv/55zBNta4WVSWRaxTrXT/AYX3PEeF1rBSJH//brHHbExdRN6PdSTaepD4yuaQqC5DA1p5wVqXHQ5Ri0tRkFFJ2Ryqw6kYYo6R7DmlfAFrk8ABhhpKeRwYG5oUg28OiOxpzjWReyJEKsNillljtttfOjHBzY7/pqGa0Xv2JS8ssTpmXZc01Qh5pUXW33LAR5gowcFfFv8rt2ypiGvUlp5a+PDpasAfBWoeQtQhSGrYnYBcoCowq+B0CgLt2/l91Gotu5p2N+9Hx3TeGzYviB03WyElOlD6EkVsmpmvpS1cVDTVqBpRyfJ1HJogh5GAkC/WkiYNici2cEa/ZIEeqO9nFJthAuSzC2alh6M1Cr0BUW0aDEZ+xmR8ZaTO9abGCqjwVXZHwStORLdrtohAzKNEX2HBpT7bXtxUqJdcGRCg5Qd16oU8jwDO3lqwQxuELIPbwVUlt0EH+80d1VKV73NnjeUkQIgWnf9p4xQSgficyZXdEryrstEjhVE1z8GsNYsthfnYQRuTs21xT9WzklmIAuvUSieMBeE8J8FIEEDRfXDCSQtkA/F7yhC2MnQoh1vKzjSdxh61jRtpqZq5wZLB3UHSn/Fy/Ah8r//d6Nx7ra7XgX9zuPpkD30790b4VGpgQDDUjUYRc8ACwm8lH5fVNMJzwF1995haDilSfyI1QuRvFGeIdQjUWTqOU8fYRWPYLD5J6nrk3ElCBU8+JDLrBNmjWV5e2r+hHwJkROMJ2JGHQoskdobAOdR1H6pbpefNkfIokbaTeTNLlvnncZ31yft3IK4JAv9gXpsmDbnn0H5b9Eby87LzxssjatCVO8bofwy/TYaDqorXjf4cs85Jq4QZBv7Mw9QEuGBDH62iVsBBe7tuys5YOvq3n09neVh7iljebPhacc8reaZVbB0BvJtjXhp0v5BKorO+jSbH4TRrQ3e2K54/MZ7N3CcpEObv4JNjUH2DDE8JIBfTJvVCHHL2GJ8weYfMDieqkBNN8KrHm/+bVyiggaXo2OzqrL97qiXxatdKWVjdtEMBlSM2VmJ3uHtJ36a7aaJou287jJTNkcXvv4aBvzrI/fsCKrOaytQcSNJnbeZl+S/ENHHYXbOfjLT3qtSaL21y2ub5KEbIrFgD6rgR4/I+i6/FhCnyoTm0wDQehGLXNpEk9Z0GK/4dU7LKJKrB/GiEK6+HV9YmYYPHLtWhPr7boelBTexVGIa8SxKy//KeONDFMk+heltdErwUuxC8ZM9xGRcVbMWGcg+eW+irO0qd+CuWbKX//bt0D5M/C8fBpjzltU8datOpF1SJtfv/GL3f7h8II9dcndlYa+VBkQNRkIJcq0tBWfl36zD2PGXazlEAVjTRVr+VKZCB4ex0iDUyUrnwJMo80OubT+D/EURXcbvzOqhdRpYNHuOr+d56klWnD+Qge6+x6CLN8Ch7IwlzJIgvD9p3lb8xrUOqFivGvP3Si9TorKx4scGlLJms9nLLM3LjwWT5dgCREhlLWlnG3l8ziU/2jVFA3w/qBmbkZh4gQyoNDd+POkXvx+LEhJhiDjD1P4s/AhwSxvXKzN3cHXGZ1oAb0Sly0Wl2NkZDa3YTc7W3VsPZQR8S2lb5XCXP51rKRLRy14wk0gZDLTV7RXutyt8Uwv40nTUE5hMUemvgvz7ozn0DBx4ypmz0enEpdmRRGTIV8U8aPSY76LFLWf8WKJs+o2sZ8HLQ5E9zow/Z0jKbpETOWy4PS/9Orc2ET6TPIzFR9vENXUAAJDeJxF6fs+KR6DjpX84ftzreugsiKkkgCYo2jGo5k6jZRfyselePbI/dzQ4LGOo8lZtaByAtIMwhq6eEmEnZb4ru/QD6/Fa9JI/F+q8LPQTTSJ/sPgnhvi0+jj18AFTB/4/OFAVvB61bM57rlBCrP29Xuju7OBtEa4K3cfizw9ZGRRc8zKSGuVbSZWKxGiD/iWSNxsjbbHmt8Ivyr+5XttobNSgjnoZ7hXCabYnohNv4k1d+p6MSjukFq6P+t7B/avBy+SG5kNqCvb5NEsmYC5JwZNGT6tsKKgzETxLeMJGyYz5slSIWGSib6V7UqQMfzzH553ON6MzFAkYyRD9DwdD0AbXp7nAOAbuT/pNX/11M91U4Gsk6ll7WCR0Gbm6P5KOHljn9pCARbuCWLWrVaJARuuHVK5V+wvPaqbUXKbeYA/gjgL+XBnnEKe2IGCa2mcydSLjZq++TDWty29vl7hZV7d7swr8uG1VaeO1cM3X0A/w3sYpbkRkMn9kHXDW/W+riRVcprDleVpgK0eNTB7o0L3eqxK5ks0eUUf+2y4Wm1H28vgQVjzXbWB81NkLZosXpAaEGnz6MrwBlqmkymOLLOnpE3guuFi6iht0tjlvoWPKxKjWNWSp/OTjrPf5CqP6dCRbJY54admB8yFxsAiuLQ4oLMZJEX54JBynUuXXbIW6zhA6wUgqbB7a8NKKEKr/N7tnaVe90InJLzu4OyhdOUHhk9ebX5v5jbX/7udIoqB43uSQR4k0zgI5VpqSSdU44BFFPm3cWofrLwcmTMGhMNgr4tQmo+WER85vYjCwxDIL68HAzHQykKjyOAD+HtJUxQqT16/CNSYrVmOLvgT+7oOoAF0cnlbTjgjTl6r9xJ38yG0N3bH6Ly/20o4gXowlPaDppBsvuDtrpxkojG8Lk8TeEw1Sjc8x3+BWQVxuTp3wmYZpLMDK37ldXB21mudP4TTtKLDlBjsy/A5dTbLqzqVYAxP0zQLUT1aGaz9rribT3cVPGOwMiji1PG9MV9uV5Z/RJFxh+RNn+3I0+y2Z5BZlND918WVwtZlTQ6RgFOr10PyCFVogqk2JlTwmwMFgoPniyB1g/jQw9FqhxNA4n4KlJ3pg01/9BRHK9sutfNj33CfO0coMDKi8VdJKjwDJ2v6b5ubCa0bTN4vkfRKUED9sbZS2WYSRHei5WYGe2nDdD8/PU8W5uysk3+iQJgxSY3bs5HOZZalGl0eNv/75a+8VBj9TX5L7ZiQkZ/3D2sS6/+BfyGzTy8Ph00kXJBrPFzSZAnYHcugMowKr4ruAByAqq2IIDeujywGILtL+maBzkZx7ngl85w6pzwXMtzmJ552iStxoQ+TGd1o7rL+qvZxn2sbck+JpQ8K5HjBPGCfkI5rj6xV7HK7V5F/AIOMDdDyx5EAIGV7JQXnUDNFbIbX9vXc/3gO4daUrmD4lx4BJ+LXO9j/wNR8V2WsGSBATlN8BPjd3IEemAVyL39zwsxWm8f5OFpgSOge1Z0P7ucmdJXaLUUMj7dz6K2+ZCWpkc5+DMBpSunw2Pi18r9lU9eB8EJPaFMs/QXVTNl2VRRadn8dIXxPRLqLofatzay0uDtXyViu5IJSuzHGkCousj+xCbjyJZtew3KZS/fybdvmy3jHMw8/T/Ye6Z8aJOq0pMzaPxtLugFVh408NDgA2VshetQqRQbI6ORXPe4KqoOW010kFFPsLMWZQwxuJe1NjcOGgzAJehZf7wosmVNV8IRvsXIckKmVfNNY5UqmWuSuoCCgm9HHKoRWnESvc9omh7jTuYSvuhcINbzhC0El3Ln0OjCCxk3IexLf0gqNoUxG+vM7PLhGgeb2tjrU4EccGwE5BNvtbXobOXfAxclwBczMp5nBICuUJFp3jz4Sm4gm8E8uBscq4jeAHzkKqoh80zuDWiU67xGVb+s41ry5CAtmLCjO+nBz3z57TLYPQ/1Ks9bjhY4jYefoCQPfEP5WIhCZzsBcXxYpRfWVUpHDumTdty6RtT66yp70EhqYhb/vNA14gq8vzjYbtlA/Z1ou2xv4+UOiIalmK0DnLal3BRBZ3XlICv9xDHiPqZttuAwPcXvSpbo5QHg4ckwlTupJA03odO+yS6ygrDRW9qWQAmuHen+NUiE/o4d9EEuieoKflR9kAJleEqibXArgCEOkm9V08oxJ8mYbka57RkhE5D3GF9e/bibvr+0NQ3khMPgXpgSPAVTn/1Kuwwb5AqoY5XqSC+hc+fD4epX+vh3cvNI3QATFPFW2DjknsKvIBFZCC9s+2whdaBsToPijX/LsemCfWWuU/V0eMf++QIBJixUdgNgXCsLI4sKRrG7lBT1old+n4DzgcceS0i+q1BFbeUkRIDLr64BTSmqBphncS/g2IfTgYjur3ZIIZMEUTW025tqXnNU59ezdnCrhE+R1C7K4g0LAay1e2nXEytiXe8WQk3pj3oTTGH44cEHXGVbu0c+ThONJUVVJkuiN53KBG+bnDQsRKLGPA0K5OImwr31O7XPjVJftLwOGceE12OQCymrwvQrvDuB/iApyE8pGt4hCZP/uEYjSyq3ybVxpq2WSYXdXRDzibzi4xT/NLZcmsGRyTgFdlAmPnQegAZaDom1D4FD45F7cnWkGdZRE8agvzyoxVh6z/kudoeon8U6c3SPFTjQIiwnDaUWbEp6VCAve8a4BMFL+p+FXtY4IiOIGgEcAioaOQb/K4JpsEW0oTb/LsQP4KDGJ/uYUAAAAAAAAAA==",
	worm: "data:image/webp;base64,UklGRrgMAABXRUJQVlA4TKwMAAAvn8AlENegNpKt5H+s/9oIySFzd9pQEMlW8nHpX4cc0MJdGTSSpGiO/fvbk8CM//MfMaRzLa11KWfWO/oQo60lhsc/hMCBH8EAwD0EAAf5AJh5CD4BfiXxjJq6Q6+eh+o2ZYk0xODttm0rtW3bagPkjaDy7v7/X1or2DrY57e1QkoR/Z+A9/8P9Cfxv0//h/jh1kEyVun+SNLd/ov6z/vJupGu+d2RjFui/sPSbKRr/u4ISfgv+kmz5qxlnoT/mJ/b2JyaLFH/IT9Z15x+yZLw3/CTdTQXnIs8Cb/fTzZ2zUXnIk/CL5eOzZUfS2qi3+wna64+52mi3+tnbL7gkqWJfqefrPmObZ6a6BdKx2a/Bi6kU6qJX+dnbPbryzmlmvhlflrdqb+AQ56a6DfJugN1OHAxlzzVxO+Rdc3QWsfnr+Ccp/o9srl1oD4EXE3zVJMvkc1Dq3U4QL1/uTlPNfEbZAO01uHAyMC3cM5TTbxeNoQ1M+2w/yWGeU018Wo/dVDPSuPASADUfsN5TfVqP2NXDzUw0yjDQb9jmarJpZKxq5kDGBpr5hAYqA89LuOUqsmVsq6Z1RoGGGnneB0eeOiz6y/SLYHXuT0GmlklHBkaI1qHd31Fn3ZwDecs1ev8jAOwV48LjcYmS+/62n16GecbqclVxjlod5awdIR5Csu7r4MXcr2lmlyDOaKODCzxaSQPP+rouYo3UhOvkIw1A8wRFth0hXx/vOuR/kLLjdRLZPUnW3zNdYtwpOuvZH5LNTnfT1PjjmOxbvuA5lqUR3qgue5y4xJZo/1esbL9MfbHTc0tWveePVT1dZ75jTTxbD81wcNZeyfXzdgfddPJkbtGnvaUFddxuUGaeLKs1R4CmHRli//Rbac6UqrVdVwu8DPudXPPyHqMTV0mSyNPmzLCdeYbpCfL2r1h1moNc7cctj9uKgRtpCm18FKuN1KTM/3cA/uHMqs7AFsUWIqK9v7UJmbZXHg6HffWsrV52MNefNNcgaKCunl637O8kDdITU50by21bXp4KE5H2PJg06LUxnuj1Y4Xyk+WjhGrHrqHIyyxXDHc1CWiDhXFNyBNPE+9QxeO0Z0xWCLs+BW8kXqan6y1jA5wIA9GDNdNF6bSmsaBqrwcj3MlreUButkh4gqxlU0gQgdqoRWc7akvbLR0yG6QJp4k7Y69Zq1G8mAZVVf4E4xcBYKn+gL1XlZEPMt/TamFpbZGuooi2DRX2PRAF7PQqjxDTwWUPTz1FbUpKzjVWEYsW7vZF+xs4UpMmIoK7nYQmfxbD5ueSKnBa6eugPxEP9WOewNVrtsRECYLre8+lVKnv9GjPrQjUioD7N2bUitukCaeIu2P3IfZZYDC4E9kydUV9MBQlzqVv9LvP9Rn11NRBgyw01hamAWeo4dDzF3EdfujGyz5AYvS+j6ETan2fEY40DP78KmPQ0+v8t8ndAyUxQp/VCAgVuoQf8yluleBJUM996ADGnnxsKKcFOg/8XQWtrFXN1DlK3+im+znFnvPZbactaLUugJmR1B748ArsJyis11Ezzf2UIatdx14DTDmHtADFq3DC5borOu0lK7TWBgBjA89dEFPacynL9Sm3CNNPMF/n7yI8Ftj6305uK2owlSoy17PyECESEUxWXP3qTY7Bp6GUlvvkSGybJHNNcxjI8W0hCssrMSUCIzMVtAbeQEddQVjRTnVd/2F/85QxNqY3QAjLBzJjYTTApuuYb7tEy7AbFnBrPY8fNHtFFZAE7MszpX2UNPqPcYAB9w0j2wKqKhCbqYrm4DRBaaxYOehdkFZjTt1YFPqgeQMXVjf9yPFsucWroCHyXfZgJyITgGwMPcDjw6oS50stIJWnypnqwIOvAZgGlc4lLsHuRLJXNmEjHwFNgUKR6CCATq4W+oSTkUZe/SUnuoW3I8wMJl7jFw2FQmAjbhKlgeyu0TmgQ7uDqVLfCpt9RLVC55/wU3N3VQwzDcNjEMOqAZbZHK2b7q7IwTrdsQeSovpZDwPDFDmh3QTgt8GUHIVNmUpRqa5oqkjU+G6KZOlkUcPpd6Ac1R1xMhTrSDC3v6mf9RN/2jkj26CITtSjEBFOWskX9mUPe0hlpxinGPen2FPzN/47W0fMEpkVkdYyDVYRspWA3sg5gnS8flC7VTpgyLQ7STuHVwZgWImPOAIrfeIpxprno8AXl1AVRhZt5PsR8hhg5HCMkJ+oNDy7gueerKHdrsBU8x1O5ebQraiMhVWR7ZoofcI0EXS5H2CpIb2ABGLvwfo9okxQ5ZihKmIrAFwiOwG6Yls9uiBqTBwZfsVIFvzXeADjLNMYWSLLYVex+ZYRWGwrJufQa6ZR1eOxFGFwFz5DjbdU17gQyvKwlzHZd38YBPIP99ixoiEsORu8RWu4d5dn69oRB3DTT9xzeMjsKMxd1Dw8B83yS1b/eC/sxnhYRdMAUu++YEr5DrGd9aYuikS7hEI+Ujp6zredYcO6oFpDvLon20N3WVhh5jrITU4HCF47twiySk84vPAALOWVWFEV/SAC7OjChBji3loim1GpqLsIZZFklP8t3MPX7sdRGoOqKPrBLF5dwxzdd2MeWDKgw3/6MZUaA/dsfcpkxr23Ik+fWhbjhxxYl2ie3UAubpuMd12c9n8E92WaSzmHgiW/Abpmcbf8qHNCFMUigmIlJHRmoWAPNx2NBb+iW45HFo5lTUjOx7i6eOpdTnHFiLqXA1aM8J9Cffc9tz7E91yhaIPn75Yb2f6L2j3nh6Lzhopl6nUadaRdlYAlxUWMLay9+FGroWWPTzVOY8k73MmjnWrxny65/5cQ1Uq6OTsCKjuwcIUcd1+ZSMPx9Kep75cbkB6GpMs4p4v8Hgd7jjNhSNOs63lfHeBDZiMuG760SbkOkJN93wBpzOm3tXn/sPYQ5jVilKnEQp1mstWa4JwKqaIbisc24IlUtXdK9wiyWlMxnrHvUc8eGgXVJQxCy211RqYdYGpiAa6wpEthAXGth6I3IDU5H0eDzxsog9tDg8QmdRRLbU+sKxaOKrkOuXLCkq4CSos0ftIkH0D2+bwQM0QzAsQqaEFmANgGgXInRZgjeYh6N4IXMKEuvXRPnog1uqR1oHZUuclrvX+HguMQDG5ACv54bGIDIy8IAtSk/eZHOtH2AONdSQeCDC35awRPzFYAMdCwQVYlyMjFKU1A7wuYkIX9DGr9jda9Yh7qOXKEpliThYag0KgKh3g6QvW7BYk/53LsXv08cYK2GkO0OoQn7UGGgNgLF1GYKZUYNICzSfzIiipaAZ4+oI1kpq8T5Z1/X4EWpv9j2o+mSsYS0J1diorRgonywp7hcbHK75yu4KJY3fAqqbCw7Fhf64/oKwY43NbzloO1aj1NFDRx5+v+Ep2g9TkfTrmI9Z+PACtNbPK5yNU1rTjrJZDDczaM0DXx7u9jNs1TMwOfT5Ea+bfgxp0UeudDp5C3/UdqJE1kpq8z5+kU6z5vZo55PPWEQYONHYwA7yeQBcavlizK5mWzV8c5nj9i42tjGgNs0oTefR0r92OF4ErGTdITd7X8G/M0XoAPmkicI83YQ8P6Q6EQbdm3CA1uYSJaf6XaoYjjQcE7h8BHU+PdOiacYu9r5mk5t2vOVszHmjCA3L/NY11wGPNuAGpyfsqpha/V48MYQ0YP+IeNFYQoeO5C/BYskhqchkTU4tfG2BkqEN/80gVjVTHHksGN0g1eV83SXX8tVHrqH+DoNzHuvXu0x4eSwa3SPK+kqmOvxQG/nakBcoPW723dv1jzuAGpCbvSyemWv3e371rU1OGRTywjT7mDG5AanIxE1OtLuG90TIsDpZqZM7gBqQmvq+emGrRXSFaavEbSwY3IDXxff3Aojvfw0YrfmfJ4Aakmry/YZKqy3y2h/bwSRnLgBuQavL+jkmqZvPpuk/KeDtnwA1ITXx/yyRVs+VcdtBDRWkBUKrYNksG3IDUxPf3TNJwqS9BadDoACsZ3MLUxPc3TUzVbJ1PpPZ4eGCFDG5hauL7uyamapYvp/pwZlgzuEVTk/fXTUxVyOdztZF5WbclA27RVJP3N05MFVjK+SSD9dwu84rWRRbewlQT3985MVWBfJqHv4XlAjOsZfNos+gtmmri+2snqQqQrwO/B/PCusBa1QN1Fr9FUzV5f/PEVImu9L+zrMNcNgtt6VCT7d7iqSa+v3yiqUG4lJGBnfxoXWb7t3iqib7/gYmmGgnzaRlYzD7NvUFw203VxPc/MjFVd85pmPj+hyZqqicxmvj+xyaaRv+S8UTf/+BEg/gBP0/C9786+U+NmMTTD5Pw/e8HSA4SqoK+/w9k",
	mushroom: "data:image/webp;base64,UklGRtAUAABXRUJQVlA4TMQUAAAvn8AkEM+goI0k5ci/U3rm16G4bSRFs9t/mbt3L2ZW3DaSMtN/lbt392VGzX+UXM6SlFyp85oIbcs0zgLs98EY8H3yCZg+iEB/bJvgr2cCUhum81Jr2j62K8J6XhKDb9u2q9a2bWuYO9hgQALs+v9/KoFdW299znVfKUX0fwJ+/m+hty8m//l3K8rbVS0+rLilpfqffyeqwtIasNWqt7zaWkFTp4k3+Lf5T2kF9WmrnbY9Nczaqo3moBRQb/8mlNYVTZtp2lwPzNm2GxuBqW7ltLTwJvwLUKY1NPYwKf3cqXOyZuxh6qE9r4GyolBv+nejKNO2p2vHWR3oz1umdbaZ5h4mGO3PmhqoKLWw9PbXotQaWqvGHqa7s472MK3Q49TPOtGf9GfAijVQZgv/TrfypG9UnLjPAyNTz0QL9PMwzrr2jFyfsrZr16p1V1p4+/tQlFrVQOPqpAL3IV3maRkmmAcmVuhbz0ZmbTMM89Ro22lbWnj7uxRaWjd27dzYBiYahScwwJxODPQT48qU86PHsDRq27XWlEV6+2sUWlq3jc7249Q78YTpmd6H5aHz4kPHSW1k7tt01Dm76P3JojbZGigL9S9RStr1NlM/Lw6N9yQ1fSjr/eHAYgK5qefCE7P3M0oL/RvcSuu0n9XRYdHGsDwfd/VhDu7GgUXtxwHoWyfoYRaGRT2BRvuuTasi/acVpXV2vvIEH8n80Lsu4RkiDC+USBgIKxP0p8MTldN56CFjXVroP6soq9YatV+G+f6EHFM6+xjmxUjYjwgvNo2oR1iZr9wXfV4cZu0zXV1a6D/pVlZ1m++HiSdwV2BM2lnXsO1vX+aBLT12txhO5mFJ7sByZt/aqXVVFnr7xxQVNbQ9yjCeTAwwtYnjGl/v62PVTEsVj/3FCoz2s9Nj8Ql3XVSYs30rndalFv5DihKgsQen2fszOyX91Orqdrw/3eviVlZQt/MKBCKyPu/kHov6MKM90FpTWug/oSBt2qZHnZ+nE/QwYXjxVjgBdK1uPxT+QFlBDTENz3wD37CmKtQ/71anrTrb6PBJiPvrBDLCsVbFDdQLNJsHPGl8LMojHYBZF7VvO62r0sI/rShraNNZHxM84S4wNNqHyPHifULGI1a3NCmrun3NiR6whcZFZ33oADwhYR7oaetSC/+sogQ6+3T2oT6Z7io0GpKwXSCzd+WPN7WwDHF/vzy20KjrQWTN5Z8J6UDfal1q4Z9UVNS0mizz8/7wrgkw9isR2sqwZ46s+1r4o96omni8X6AesbGu1pius/2lfK6rSy1uf05pDW12HHhyvzjBGgm0VaGW7friyNdVkd6gXre3J7otdQUZeiYYePiExZMpsS61uP0ppVYfALnGYY1AWxV56lu2rjwn7G99pYnGCgpjvxLXqXF4KM8lJe1zlFr85w8prIFOW0fNwaKNrhFCV/iTu/GTCBe6d5oh41FXhbLukbVxXh4+ITGZ7UwotfhTKlr7rtUpeVzqI4S6Ki7+6C1b6A9Y1PFSqjWlhSVhP+LcL+ozzQ2zdmrG4o8oKuquB1pnB3hortE1AhXlhdvpz0m5vj8C61KLW9nvHjFcyA5z0jN3NaVa/N6tKKu6m+2B0SFz5wlOjUs8XkdsqxIgc/lG4jeg9JY5IIbleXXO92pnnfhrRQndrI3TqA6oAPcJjAdviV2VL7WdSZs6B1+qihtU4XgdEMPZxHiS9tTVn3Ara5pxHqdGGE8TJogHb30dsYJSWOPx9uXd472FvipuUJ74QXn7kXC8slvILcNE1848ngzLbN9RV6W/VtY009hegtzdcPDWF+xjBWUd9nf64kDdxipptzNzYnvjh/Z4nW7xeU/su1aTRTs18fY7pXXj1Dpqw6gCaC4e75x1Bczb+wRUYlMWWq1vfaGeudc3KNa3icAW7rqoY6vjQxe1S6tSf6mGxHGdEy7el3C81RccJH00fZ0fUBcq8XhdUN26GxRVTDQ54nL3udgD4zzkejqtSy1+oxQa+6llmOUD1vhWX6BOVd1vR/IC9GRJrMO1I9RlUr/1pZJG7k7NmLD40HnRte+0Ki38hcK60dlpmOR0PAnHW1+ZrakIL3gLoAoHEOtE5u14+0qNa2lxg9J3PkPk2eiF2WEFOq1LLfyNsnGcdXQ6VaGROb71Baixpokv3hlzHC+OpbTQW9XF+pVua11a6O3ngpkjLo2azE+WAaYV6Kz5pbLRaZh19GRgSpfwIqNsS02/v6+/AD1oSgtvlHVh25e2Vel/brnjrS/UhMjSONszwXNxgnnN/k5RVs3oxJBoMmCyhPjKvvUITW14X3yp5hpLLW6AaSn86IUXcEIM92lWgUWFrs9RFvqt0mpaBIY5OzEOqNMctiPz9thCU4Eh88rmOCCxOCOrAuX7krKFZbgyS9tlqEu/VpRW9WJ/NmrONR7vLMS5qSsI7/SVVTmpE4sbqPAjwAVfqKJumvNk7HLWfK2wrOpmmh24YrKE7ZU5CFNFTcWU8YUpeUMFlOrteqEnF1+bYZ4AB54szosZTSxuX6rqZoKTiQzqGvftxds9ztVpEzOnGbXKlumFnxzXXscWlyFhfKbz0jONGWpKi6+UQjsxDqITJ+ocIvv2Co3V1fX4DGNS505v/BSZn/XK64jL8z4OCZmBfoIeujVz+05Nm2QTZh0BApFlqj4NxxX1BUeXoRnnV9x8wdLUZZG90R5nsIXnxGMYdeKRG3Nr4GtFWUM7nifOOma2ufpiPK75oqaCmi68rsY+p/VBjkhYHuoA4/R4AgMw2l8ovH2jqqHnGnOarM2VpdHkHrdLe+jrNGz7cYltrQu9adm809cWn2F5PnRIZj8JtHVVWvgFPhlgAocJhrgvVbYx7odxaazSZ9hPjlhTQU23v/UaxKbIVslrX57wSBOuaA8dqzWUFn52q6HrITdkBJgjTJln3N/q64iNCTyDagxzk6ENxxeOUBU3KJvjrXtonHjokwzJw4FZ7fK/0cN4OjswKTRrZKuAZtnep8e25GqaCmsqyKz76y0XD17A3lTFWtbz/jq2MOeeMJvw0fq9EtoPHMiEzWSI+/vqHqbk8+2VfQsqxysb5pUIBCdcHNLnrGbu3/GzUtuE3MAM4zrrtGkFTTzel19HbL5geKsvVBPN7VvMrtAOJw9IJu7PT9Cq1NtHhWV9yUGdZnXdM8v+Pn2BynHP1Zw1Hkn2BSeqR2TWNbXxjNkcAzDbQ8KX/lNat13PeHUCXeOLWEF8Z1951SVTX2iM76svs5ljW5nt+oxTZiLx4YU+Terv0Y6XJ2g0bC9CRXif5lBjk1zV7dLpCzzCCp06yjDrCY/kfjZm+J22my4AmLyggu3MHOpnz/3kRcJpDLMrXav9aDMtPswNs5JhgIlk/YWihm7iBMCFxniAVXhnX5ypofp4eV9AyW9rp3Nv0+oMjYuj8wAP78xAMsD8h5EOi07JVMfM66pafxYucYTN+IJ9pbMHWsdkSga4P+4qcjrb/wlMkJAf5mk8gNhsn8Hx/GiKl7aAEXgdYe3TeZwYYGJ21If38wEeMGc6f6M8YSRvIxASji8cNJ8YXuSO+IosYd0jgcMw90yMAzNMuccHD8116or+Qut0ccytB/GC50CkvrBN9X2KCVs0AHFt+4MY2F9bWCcYzgbGh94/GD1bCbniI28no2cKjWtMM1cPiBCACDSbhGV7sUQeU0g3+3Y7IisviOsEwzI7wagPvV+bYJh17DJmii/RXPDMOa6R7QACxzvmD7Yr6TrFIyxQk7i5NsvBthJfGCbof6mfoVNOiq9UZwIqaaMsszRLzsiaHmFF7V2dk6XmCEeGCM12hKYa9y00vjZdm8lZfqEHOmVN6m/ViePAdGWw0UUbnYCw3CPrLLCMy7yMjf1EYg1JrMHY12uEikBsKyKEeSLjt8Yephzttwq/MSw2Os1Jy+V11GXWZoI2wlxDONY60lgPWw0ZQpwr2DS0U3bxF4AVwkpNWXj7rPQbszlphvmkUSHRGUaX3BT3GrYGmEPNlOk3KwgR5naCEb/gw9ELATK3L5hzNBmYAGdtZAAW53vmNJkXYA5HpK9ZN2uIoannI9aQaTZDxRQ1TNmV4fEdkpUA1FB6+/kiNXCt0Tkd0sbZuzo1KukwLz0Tswc0ao62OuJJiZsC4SCumWX4iiO58AdwMsvYKJyMjc4T3AF6mGAc5swBawVbzLQVREisoN+k4gBCn7H/yjBrz/prZWaAaXR21AZgHhtZbJTsY7RPJ3XuJ5bcFE8rOJgqYlgrYDPUVXNAnEdbFx2+IbN6VpXfqqhp7AdGFVQnkAYWIfPQMe1BZ2UKu/Y1vbHRk22uIIbkBV1pPF7b7NiYAHd9cmUiE4j8VqMOzKMTA2B+gn7ioXhmD85T67jthho4iBXoWrWbJlRQhhdBje99pUkmBnjm7wIPJ6CfDcTfo1GnedRkOlHhoXe9YD9gq+vu1tcQDsi1GupcqevBVur6PlbGs+f1HCt/AjWNOuYn+OCePjRnP7Ta7xq7GmIuxL7dt1xIfB0v1SMG5tbFafiIKR1WQvylMkOj/pYntLruGpq6Wt/aVURC665JOCGpI4FlYtRvrYTfs4KzAafvPK6YhN3YVxDfWlflARXsrhfqF3Sl1RwD9OP35jUQLxXfa7IDTH9AmxzbWgHH21iaa907qMNRUZTML9ZC6xhiD995TAxrIJ5RWty+4wXngd8wZ+t8xKNJ3rrmtN1DU1rzqii0fREKrfq4Tl96OI1z+Ojnm0UpNKfj0A/fGNKTCVojrHVptb7d2lJ3j1IDqPWrKtT6CKB2zBO94/DRQ50DRLY0UJd6+46X7Bk/czhjdAKcI/SlGt7Ope5aqgcmIcP+CnWhgUZnh6/MSyCyZVe+Z+GlqR/96O4JZ2uEJuGIVSG71idFTdiSMoJFWYQ+s3xlCUS2fOAXKC85pVce6sD9moYIZVEW5WZXFta7oSrttDCJeqM0ooWBRhe/gBoi23ldfc8vDaA+1Ht65gQGYlWarNXtp+z2bS2UjHXAW661uAVo7GfHb4TIdr5mii/dypoL5ob00iN7EgNlsh1t+WMZNi2sw17cJIC3H4rcz60Oa6OzE1+IbJcoLX6n1YzfeZxmlpNqP6ripyC+t0I7tqQNFNkWMzFxnAbgWohsF+l+jTbNqNNj4O7j7vPUEycYCBHKml3LH8t2f4eqJO4h6SK5LtBWJTHExOFiZomwZXc37erMz6+tc87pcU+eXzBZl0ioQ9xDefth3e1K24Ou0HKNa5XpY1h75hhYkyU3ArOLIbJdCV1N+Qve6rTVfvbsCXdSp+xD7/poXIY1YX8dhOpGtWqpYbcutIp7xQ0o133bD4zMja6LfTpO9LNrILJdzhW3X6J11nVK5AmLyXR6zza6oj4jrwO6qqzDFiu69/6m8FbFvctU4XhxEBloVmLosxP0zIH4yVr/UlFDm5/XicRHIkyn99Mmf19C3A8wxGNbK8JbK26UkZqilHV/AVscoNGxnzJM/Uogwp7djt1cqcXP96qk03aFiTHx8VwEyN0vktxtNB5EOHa3pnvrVlcldaStadot7sfriGvTD0wqsxlWAhH266FLil+wFBLXucdlnhoFnsBdJ55wwUaXzKIR2APbwdv4cYhhaHR2SYDRnhUibPuHXZ35+cVbWdVkmIXF4ZGYG3wCF1SuEdg8MLdLIxBg6RudXZQpO7sSgS3ZPAtdTflr1tD1c3bRdR4S5THA/TpTdvHeqLPS2C+M0xxXYz822RgWW6d+Vhcdk34NRGBz1+1KVyfFr3grqxo6MysQFu+Jkr/rmKE5aVIA58W2GXvXuZ/IjYukuVHpVwIR9tNtP8jEk5/fLUro1MSERadGuTrqXS5mZmCNi80QlmYamIDFhsci/UQPczs1o85hDbC5X81toYZSb79EkXNlBgKwLvq4BqNAsy5TI+kyL8Bgo4+wNstgZgClhxladZxXYoBN9y/GtabU289vU55lQ7rIrPZJe2EJ9I2LE84uPsBGWZfpaeMEzMmo/TIxthqAGCKb+xdZa6rS4vcsai5BOJ3XxTNG+0aZ6BedBtOHT5qJ5wI0OgEPFx16JpiXlQCR/dPjZK2htLj9/D5FWXfqGSew6DCdD41OMC+ODjx8chfwIRmYeD68Lw+TPkCETT85IBO6pPDnTygz63m4vkKuh6adxtOH3tOnV0ldMrMBYrJ/fBK6GkqL259gUfoLsAbmCehpGS+ZPO4P9cqSDSsx3fRrca2h1OLnj7wVZd2t5+E8ksmu9MAyn02PDzOLF2K6qfunB2Zj6GpKLW5/hoVl/YV4ehJYjCsB57Vncbg2a1iybDGQqO4fH0ASQ1dTauHPn3oryuozTj4NxJU+LA6gTzUwqzEsEcKmEUz3Lx6Aali7mlILf/7cW2GdC5e/kg0sV2GFSCDCprua7F88ztaapPijLKwy4cNf+HQ730+/cuTV0NVQWujtT6Kwar/AR9s3AU728+0bx4XQ1VBq8fOn30rrLsDKb/CF/Ztb9msx1ECpxe1PA4qybrs1PYu/t39n/+YBqFvoaqAqLW4//8BCq/ZS/OL2xa988ciroauBstCff2ahVbtCyMbPt+//znHRLXQ1lFr4808ttOSMP8hfOK66hRootfD2j7HQsm6/Bl/b/wQNaw2UWvjzjy60pPu9Pdn/xETZYli7Gkq18OcfZyl8tgme77q5Xz3S7+QDa1cDpVr4808v1FIJcGX7cNftl/gg0NVpqYX+/AULtRSubNd3dfvk04MPAnVaaqE/f8cbhZbW3ZrZFMigu7p97Tj1aljrtNRCbz9/TwpLrdsAm8Zv7N88zlVJAmsNVJTJ7eevWmiZ1m23htyubvvl49tmo2Gts6VaePv52wKJVjUk+xe/ZRpYuzots8Xt568MiVrDGuCzy9uuOQ2wdnW2VAu98fPXptSi1IouQDQNcfsCqgGPLYb6vEwL/fm73yi0TOu2A1QDn0Ak0Mm+1udlWqQ/f/9boWW+puq0/jTQxrXOV0l5Wqg//463XFGe11RfrPFqoTf1598ToFDLwuQXCy2L7M+/caGomeJLhUrm51+bQjH9qBBMf/5LmMh1AX7+d1g=",
	rat: "data:image/webp;base64,UklGRqoQAABXRUJQVlA4TJ4QAAAvn8AkEM+guG0kNTh7zHz3QsZtJClaZoYf5p8h3YmBJEmG1jbO/P8TFzH/4Y2qKRO9sdvur59OjSeJzVOTJxuQyBOhJg0U8AYYYHAgwNAPgQCAHYccNiOp4Fi0ymXVhcHbbdtVY9u2ZQMGIcBPnvH//6kEtqPHWJ/W2ruUiP5PwM//jbwC29v/U9ic2Pis+f+yTReddO3TyTk7uQC9K7MuwOZ/0JauLMxO+jB3vI+6A5ur/ykbLMA6p9P4UIB3Hp39MOkySz+7wqb+eZuoy35m3Ds8PR9DN6hTN+s068Ka3f44gHnJOs0+Zgf14Qhc37w7ZJ+MTM46Lb2ywuaftQn9rC5g95jmhw7pDV433rgrDI7A/Trl+3ReF9btL9oU5j5ZeMw+dAQGveVfPEeeu4k8R+Da3c2Z6AIr25/DsjI7To9Zid3I8zEkt/0Xz0Oo12dG9dEfnxdW4C8BFpgdX4DjK71xvY+82HnBmD6vPMVrx11x9AqDDw8N/eyyAn8GsACz4+voLfsaX8B4+ArcgSGTVx8qw36frrD9DcC8MD1Gbnu3/RHeeSb5NyTd6+w1zitsfwAwq4MjN956jXCFY/c904wqxzr1YR+nZYV/jgWm97I3uKbyZAQBr3dHnsBIxitmP+Cjn1xYge1f2liA2VEfN97hds3dTZ4Oer2PgEd2r/kbMKSdOmnvsgLbvwMLMDt14+wNXm8+2RthFgbJ3p/jW17RWz7RzjgpLCvwz8ACzImznbcxfQLJfWTQ66z3wefsOMlsMtw/cDu+Q4LLCv8Ie7Hvhk4d808e2RGUWQdbusekzjo9B2XkkXnkbu91Q0xEXVZg+weAJe3VLvvI4d70mJztQlOXTWgzk73DY/ax/xE6Hcz006yuwO8Dllnp1UFHuPnITYf7rm0uVVEWNCFOap9Ofqc7YsYV+G3Akky9zmYQprd7Q12VhWWhdWh7jYCdB/ycD43pPM2uwO/aYEmmXqekTcfp/djWVVmcQC2DO2340vBGn84rbL9rYUp77ey7ps3HnWCvBsDSMycgYwS0Vg743rDbPex3I6zwq1gmZ6deY0u4NGoLIYI0damFWhFLPRe5qmlDfakgXGr1wHD3yaFht9N+NwKusP2WTZapn7WPoblQXTJBjaqlFtmyQi3UE5RhiZQnKoRaw6TJoCO8eKtTH2mnEZhwhe13bAvQ6+yjbapSL9AY1CkSrHKlCuQ8WYU6WpzQ0opL3UzpyB6Zl9lHp4+00yECk21cWPkdCzCbsS3Thm559E7GYJ0rlQQotBSoLS20VLlQx9xDciSDdg52Ouw9zAgL6/YbtgVmfTg9WpJLE+cFeqdYh7qCUoBaE5GslmpRol6g6edJHw4Pd2Cw233o0O0NnXts34MFxtmFR9dyKSW08wK9bahqDqqh3k8o86C84fjMDHbZIenaJjA8Oh3sdOqNLKz8jhFYaMMFqJq+ZYFIdbw+Rr4UJENtnLLJYOaa6YeH2jalXkIcuiGBhIWV7y2MQGdLnTTt3MeF+ImgOT5q3PHhYHf3hQ529j7UrqkSwpB2GnvN8aXtSJM0xrlXg9W7dThm/pCxn3onHcykw8NefdiFqkwaky4xCQvf2tjhxa1raSTSaxUo1UMhm3k70dBr1MnHoOYeTomEUm3adOh2J4P2y8r2FWB+dQkvtAUitE1V7h6o3wJyAKW1vSHC5ENHdiZNmqrU5jG30GVHkhh04XvX15jeeN2619gOEZrqgEBtYtD6IGkClCl1MPLI7k1pb6hKNUzzo+2O9hq0X1a2z23AMozpDXgxgrEPdVKUhZZKnYJ52Cu1For0hBo0PuruMQL3QR9Jb6zLojTYA91wwF6DLqx8jHRMX7fsa2Swm0KsK4rd0h3I7GeUIj3BWS2tau0c4THolI1cihNliOlj0G44QBv6ZYWPLTACr4PP8T5ohDZU5ZlD+qlij3OqdXEJbex6nTO9VCegnYz4sNNBE3ptgwtfYJnHu77gmdHryKBxdghVkWfnbeDAmRPnvGVxKq3qvbk3huoETvbZIds5POxbgv3Cun1omx0TfebVEQYB2qYqLAtL+I65oyc4Q3kJcZ6c1Z1mr0u6jIkLrB+a9eExdgS6timzFXyq/AplVYeY9FKdoLSNZOYdB7UNxmT7yLbwqbvXkc72AN86Hz7lTmet6tDPvca6SJrc7PPuga4NkYWVzzD7uL9xHUbgfoXOljpjBXyheOOUPXPijJZVE3u1KU+gIeN018FOzRD83Kz3dwbvI5C01FolKrwH5SdOR89wsqzq0GsoPUFF2+tkf0DtzbBuv+Q6cB+BTtvG2oqc+A7HzJ0OnoFTalmFXpvSE1S0k0buDnb7iQsrnxre8QoJXdu8odbsKkCZLY6c0jNKekrPWFah1zqhCjEZ7LKg+q3HW14hGWJyKY/vZc0WhzjBGdWdM5ygvPRq6QmKup20H7rdjEG+4fONkSswgl1LcykPVh7MmC3ecjdz3tFe29IT2MR+tns3w7p9aLy/BVf1CV1LiNRlaOcYmgr2FHzvxBmPo3ACtKxjT12eKKxCP81DZvAd3ttgmYd3GAEHn3Afukjv5OykoSp0b7fYPyd+MnOmrELsrctCy7qdhrdi6P0MsHRmnm8w2D0ZgdhP2jtpH8pCPVbsnrMnLd05kzNHmYRLWZwpm9jn3CGo3/Cuz33NXDvIMO3Oxros1E+c81pmTvuJAmdK2165lOfCKsTBzG4yLytsH1jofL4/Ak+4+46xLovdD5UJHOBMDs5lHeJkqAr1Ej728wGWefyGV5+PdMq3yTlR3zidKVPSvTNQnHKWdZw0lMXZso5vBJVPLTB/gL0raGIu1gnvyQkyxQnOQHLOnnbPVu2klBZatZ3e/RXMPr+mDzVjqBKS8pAnKNUCOAMnOO/uQdnEWeqyOFGGzvHOXvzO9C12zPR1BtSPkL5xOlTN2geKE9Th/tb8selXMDzUZC71DKdkFwVO5wOcDx+iCrO2dXmCqolHYvjO40u37JWHmjSFZ05w3gMSDvGRM4XW86S1JwojI2/0C5/YmB35ym33Ss5Q6NkTHjodAL5AYR13SuPzSPuN+Vt+wnNh7pyREyRkTsD5I5wpqMJnWoKR5d+4Hd27nEuFQoDEI0Xm/CHOEnptC0+UFxgZjujC+jf0ZbqHyk6phSc4Ayc+wbkMZrTU7olDEoM2db+s/9jLx0jS1mXh+aDsn0p17/wRCNqHPXWwM2b6Odnec2F25AOMT7gnL0hePMdc6anQRDl6IlNwfvtYFYN14TkZumzM0Luw8vP+lug7d3YTXvknI5MaS08UunNKE6DUSs9w4lNVUhYnKPXe6QiRNqiRZWX7xt2MgLpDArlxh5zn0wFylBVYnE+f0ypQnDKxy+8trPx8zvGZUd8x4friOcJ84Fx4IsMbVmpx/kZdFbmmy0fanfUz7t31CVefb/l6js+rwwiz9vMUS0/n4sibZRbgBLnT7jmjApwvbTfoTmNw/tL4BO56hfcY4Tk4MmvXQig9FXo+4SfMWJi8eT52LptIN2gnLY1B48I3xp3BKyN3n4eue8wx1G1V7J7JnI6pO6c3z+kJzuoJLKuQs2sPrB/aWBJ2/BDPEehCXVq8oScwZ/4j5wNwAso69BG6XKOGuHwtTXjPJNs2pYWW6pFsqRZaHvHQeeecnqCsw9QboRskNBmX9TdwHfgAw9iOodO2uZTFjoUnOLBbWqjJmSPn4yfQJk791KWERmuD8zfmI3f9SNeCNlalFpZpkfjpc8mHT9lzoXWcek3a0FirfWb7Hp8Yn3Tahsb6UjWl2pQWann4yBlVwEOndK/US2hzhDd+PrsxHXnyAbrkiW1oImVIqqawPuRFc2VFYWkhHigz2aJUq9BG+odDS2hy4Svz5MiTHbi/YadeR5iBCKEFG6kN+QvthUhZtalVeLO0OVpKi02QTjNNLtgvrNvHnEbuPnOmb133iJCQ7ggX+mx7MBiPN7aZABB7u3RoaQ6t/HzO8crgcwTub6i+gGunDiP4iEDQFneB2O+2EExi+oBehUFN6MYWB587zV5k+QLMPjoHve49AfUInQ73Rzb2QIAjsd2L7W6EhwC95NL7CD4H75mWxjofWdZvMNvlhxHuPgH1ige4dndNBn10kT4NtqBA3wT7IBDp1KF/qC29GodjPLmStDQ7F+P8W67JE/CalXEH08fwZt9mmuyFoC3xoQ76sN3thocOegWOtE16oVZj78LnBPaGkXvmmtURcubfsTukBhj04ZAe8u51f/RKp21zDL615IZOh0M89/yULV1IM9A5HM2ZvR69d2ljrXvBBdbtY8Jyz+TvI09zPkcTP2fbORjsYtMO0t3gQLCFYfcInbYh42WnX1j5+fzG/LznWvQ6ctcMPBP3b/kj4+uWvUM76POWT7pGOx++19nS6GX/NwDD3QN6z2bcvb0/yL5kX7DHIYdOB69wF+hsafRyJOgC6/aFDboDEdUrdxXgRsIXuzQDr9tRbWw7H4M57+q10zY0XnZrhWC/sPLznXjvdnM63NPr4F29fbHL5w6rLeiQGfSudiqNXg4ZdFrW77gtfXewBUwzoN6++g1bHY7er522TXqAJLKwsn2JuNfmTXduv/3FDejS4XCntk16ORZi77LCz3e3JfIOmP4Lr/QGdMNDj3TaNurlzaoOkeU3sMT0GKj+luETdwcfw26nto16ebOiNjItK/x8jQxvgOntFw6694Lbyx2106GzBRr18mYFdYSFle0X0CfwRtplM4MHTLmbDOqV15MbPF837oPcc13aQrC5fLCCEJmWFX5+A0nffrZLh+xdr2nGu3obck+4v3kd7LSlSS+frCBEWFj5+YU70NLpsQDQqccGBe7ZzH33eeBK2wk06uWDVVpH+nlZ+fmVwA5vBCXtdLBTB6+7yl1fDPf3B22BDpr08sEqGyLz8ms2WCK0H9wBuuyQ7fSa6gtzg1c6dcgmTf7ysRDpF1a23+EGcwTee7tTAXWwS1/Y3tAhTVptDM3+5aNVGoz9Auv283uYYvtGcEe1ybLfHSXcOltQBZrDlw8nwcgC6+9RYI5AG3MhzXhkn+PBjmxz+PLFCqhDZFpY2X5+8QZLkg8puP/Oh8Ohy+ertI4wLaz8/G5giWkLIeW3pZdU+XyV1hGmhZWf3w70sQ0KJAI7ze/6ZpWGCNMC6/brNmCKQW1hB36Z36nSoJFpgXX7+X0Cc2LOveZvqNI6GJkWWLeffxKgDwdbTJtfeQG+VKUhQr8A6/bzjwL0B/LNr7x8vwKCyQKs/PyzG7D8A5fvVrtBIyyssP38yxssHFO/c/lydTAYexZY4edfB5b+F1x+Z7UfNPYusMLPv78Bc59pvvhLyAUj9C6wws9fuAEsfVC/YH30C1UaTKYFVvj5IzeABf6xKhuMwLTACtvP37kJLBDbA3WuPnz5YrUb035aWIHt50/dBBagbYJaq0n9tQouYBKM2X5hTX/+3I10gcQDFw54qIILWAHBmgi5BVhh+/mTE5ZsbOug1gl8okpVifszLOkKbD9/9QZkYDrEjoAqVaoa6XNLui5r9ucv3wRYYJ1dgDpoH4xJyNYKQSdrYDm47v/89ZscXXYjs3WY1FDPanA5urLAuvvz33gAlhVYPr0m68Ht5791y+0u65uZ9c2f/+ht55OS9+d/gNtH9Od/ywc=",
	cheese: "data:image/webp;base64,UklGRtwjAABXRUJQVlA4WAoAAAAQAAAAnwAAlgAAQUxQSIAVAAABCs/X/69t4//fmxl2DDuGJb/fK2Zmhh0z4+zezMzMMBSHbUmWnSjORIFp1UlyMvH4NG3y0mTSpmnqUHWO/XiC5PwBj7vuEUFRkuywbTSv6iXhWb6lQAAPC0gfoLcyPm+1rv+5ruv/q+frmrU92vVqXf9XbQlT1z9bhK3KYP2lenvjKwsgBLCFA4Cwx2kNYBWWMHWFFmGQofiOW8oHH5EniPN5AJfFcY7Mwdt9P5J8HGsuHh+RH33beJ/3qz+seD4kA8qGILlP8tL6h5ULkjgYkrGQkQxJ5iTJqyIg+Rwf/363jNcBYBerzocGXS8sz52PLqBt6AJuER/2CeR28VafPQsH/UNJj8cmZ9xnW3DUz0b0Ux9dNWe5zyfo9slbxF8Yb7ujXSwRwhK7MBtTXKWPrnqU1GjMW8KHfxHwt+maUgV3VMamja4+dBOMZOYmXV1TEdT2iJa+otNCyi3hO8Sjuopdo9v7JKBtwaXrwKXrFJDpNl3+sB/4rTjg+ghl2LEyzbMKiEODDh8ImGAlbmAmJufjNm8Fn190i9B83E8d6aA0trDppjUdYPK8QP5BOGXjsap2DWJdVAtTqpoXGGpUwEuXTffCSHemW4auyVMAW/bkmDfdadfVrsCBV3LFpPmdv4+b7BUDzpAM+VDygGRPsEAHiatfBDwz6XFdEHVuGQPruOlqF/VLKDGuhGgLTnGL+MVFoJ0a3FfVO0VLddmgrzpiU52sJ05SGX3M6Mpt498BV922aj7XrsneOa56j8u3L/30znyfvAJTC4e8AG6Y9Fv9QMzrcb8GN+Rd87Hkhj3zUeK+rAuyPkk+xiHJe1IEOUuSTDk5fhNdR9d3ztu2cZcl5333rz1195vJ8GVDssk25Q0xdTK8LK6HZM3n4r6FhIAkKX72+TCxIOrOCwvZECat4VKRkpwE7/Xh34nzPCqifAU3BTRPcGpnJ39UAGd5p8CI/LgAupZx5e0cQBtPRrpauCwAe10v+k0uQtzX5oQuf3oB93PTdf8DCC11mx2jWax1Bw7sOPvtRHjPz/i24nE2J+8uewAmI17LFPcz8i5Zs8MF1owFScYVkrOG0DhzUPMumWSUilnzLdxbN3jAmq2sZvV8KGDpd7D2O9u8SQBtZ93rl+xX5bzs+pHuZOqSr/nuok4ayRRJcoltMuBGcZC8ypdJLnK5zbAAWkmXjWSJAVkLyC7Jg6Jj6C1UCDk2Ibuc4RK1zbXiKCGJkHtFzcp5LNZdrrpN0bXNm7X5XJeoi4FV/3ljd6ybjnVvxXz3Tz67iEILEQSDaGrEcjQYsRgIIS8iFbqeFBGwVLwZAVuVMBO1guIwmrKJiapft54C3utWY1609wt7u6KiBDjvq3KCqCxNFWyLBMyNZW5GUy4G0XIBTEUDO3UEHEtWIqABYBZPqucUpZPZrmGZZI4r5frFZNZlv/R/c8nVmCMxGIQkHUwni6yXCW4ZBAxJinGl46IlNNdJQCM6mOa9MU9JoXs3aSTHVb+sgV3H++6R5LhKwPTNHOOqXyPRWRe760KiQn5+dS47N8YzNizzkogZktN8XMTZNbCThQDmsllGfGBylC2X5n62AmD9njkm8Z2q+QvL4y59D0cy+71j3neua0sDV12sQLX86NFC3pPs5Y+KtlEXHecFcEfUTU/yNnZk3QQs5k+LIL8c103jUOhI15qN8zwqSTzSDYzqsqp4j/f7lSIcLlNEBqA9vEY8fA6AZGpfV0DoioZkbJiOBbDEgNfCV4QZyhtcsKYJyd6InCNuGAK4FHVtpb6OI0Iv36FkXVLD3u28fpF13W7qrpKTflABAXfwVtZP+vsMcMye5NAwEmuSZLbfp+FGhtwc0R8YLDAieXPGfcKie8DKCCtLp/CcF5y+vKdvZl7edeiuptT8ol9O53SleCNVvbY8BrqmYapqYU97RUvPTGaFa5iP2dTAQrKcvo476Z6NPM0MgpHq02vhOz7U7ohM86JaX6z8c2utKyy+q0/z0uFrA1B7XScuV+17f3bciKcYcNvly7S5aTKIyVmuFDXbZEjFHntFTfIMUE67eMi1Yj0mB9L3Uc5yw2CWYVSccC7ujNjgPpZYTarAd+jafVu6xn2Ok39dR4Be80q18+qHvvAbVoJmGLk4DVUTwZTmY3ZUtWdBo4Ka2MaWUKNiX2d0q2A4r4sqiFU1GzEdDqmRIA13EetpFXxcsWXDqDtK93t41n0W3c51ranLuFx5Xff3fxf3LAS8tFHHEZvkkuEb7hWN+GFxes5ZK0s0+sUU103dJyQDzpJsxCTnjctAyBMEHcE6dyrD4evvOnwbj3nbXFd5hdrXDQDsSQGvdUnVdNOWyZkYRus0tqHaN4baa2rLcu+WcVm1xp6qxnpm0k9V+o6ddF4DwRvpYMxAm2JcDtLHFeHxvkvfxKsu9t0XsPsqjnHbkuyXHS+rgHCnPxC+4LGLbv+kOOq3eWUj4JnJRp9sI+QzAH2SPDJI+laO+ks8HLMp6gJyA0n/xjKv9p+M2OiX9rUt84qLtte46+VLWR5zj2T3tdTab1DtvN8cAiQvBFdMhs89UV4KkiE5Hnd5KWQ6uB62MdbN3EpKwPAdr4UzOa4Lhxfj++K11FWSDo5z13Qj6eWhe95+msdCVz+H6Iqyrnf8VdT9jj+S/MbmO7bxKN+TutbypvGy8hzAjxpwE9r3xeDzD5TYd6OJXVd7wqxk90cMsu0RJAO8kzWyu5zLanKdcUaS02zyLq3xdhGSZEqSvC8IsmXiXdwT68pGtmVF3tcEUxuw1m3WusQMpy/h4au5fDfIuttKJb/oM77x5eTYi1POJ1PscrPYSJbJVexxWqC0vo27I11Bcm6FRy7uJnOJhXnhW5JXVfLvHvuujnHL6nubyWMgc7a7i24Bn3Q6QdJoRbITtQWr0aAUvehN4Zs56ETPTDaje6auQbRaMGqO6EStxclRG8k+Lvhir1t81r1+vnfX6ptPjqloYGd61C4RWhCN+GbUQNMD6dsGVuXHBS4iYCZ6EZlBBKCIo/8f6W5LXWGxFy2ggTerT3Ak331Z+NQd3uOOdd0rk0e/Ksl3/t/AZC8hX2VL8jRZ82Ez2cUbyRIXyY6BsstNGwmneGTxFQ0CCjaTV9nlyzwy+lWyVQm/Keclv3HRA1td5qHL7avAb9x11zWoiCA7A0DyLoMRc9mWi4CtjGTPQshz4Dobi1jmEYAgI0dsZ+rmbcYFsJc9MImztyvHOm+bz6WLrntdtepc91vrXq92d1/GpMjvFUAnBxbQxnref9viC4b55pibHGhhHkBPcpV3DE5yYMRlflo8Fdule2P2RrrivImkgDiXiJOiky9WzXu+3+8YyXIuMBomw2xcV8LiK6YUIp4zYpPXZtJhIrgUNiP3bS8T+8rMxrqGAWs+lxd1WI91Cwxf83pYlh8EfHybVde+Ytd3XPL1HQE4fTHHc+dVt1TAYv+ZJOsfuTjrB1hgb8QGSXaLDme5wBXbuYaAZM+H+/2sz6Tf5j4XCyDuX4EbyEYiTjgnfUlWSNc6bnn7ihZdnnWtB9Z1k0z2edWI6lI/VYTp0EVLT23r7neZPBZCwnRGVXVZX/dlb6TLmJlX0obOj1hIuyq7udbVEwLl9n0c/cL5XPtSO9Yl7oRbgcYPi4BU2RniO25CKs8lzVhGTS7IyZIvxdt2poXveIB4ycJaTDIkqWxMBjj3bSzYh0xHcs6rluRRF3rULSX5+BemKmA63DWU6LwmBjM6pM5r1yDWU8muzo7yviQ3zhUm4QEiFb7llLw7zSX7OlWSrwQqSd0CJXzDNuBad4Qe8653XQN5uQps5wL3OWXnIUlyzs4gXi463C5mGQaCPfYEC+RSsc+XOW17riOSDcOsfKeIpZgprtvYjl+vAmtd5/RdfRLkvOXhuzrrDs9xGZ6+XBUYvh+AWmyhrCBIVa/P0tcdCE0B5tMW3tCzYrlOqU1VfU1VH0s2dVH7FoTMh+mUqu4WsRrxmtC/UxlevohHXedT9wFwn0s5cLc7vNrVWjJVyUL/iYtcTOT33jJm+0VBTcGT/jFykkn/RrnCQ/PtorHvtygRug2OucBnGIi6QRCQrDiJ8FjX+/m2PuMu3C9z/JdVr3mv6svtYeAm4o3xI8PLsS9oMLTFKqznCoMhjbrTICK5azAkQ7GvvE+SFxaU8r6qQKST/MbhK7nm9SgHHspzhc9yiLp9I38+rtvbgLEvf5xb6v64ADZk3b+K87wJ4E6R5QDeJVTH1nGpMrZwUApY5wVn3WuOWx51m23eUMB5rrQ63v8zfqIIhIm4XfTI7UqIxbnDJu9ynYyzJkODJBMRWEjXSYacZmxjU/qSgvW7jLN9K97nMq3jfkVJUdvrXniM+x4/4k5t67hXCTNJ7EdnxUnS5AbipIM270lOk2kfEna5RPCp+F/xjTHmuaUZkqavsdIZM8mEU5+05aor6JUcvq6zLnHuq1VIJzoc8yhasvMsmhmfe7OzGc1iAdsmh9EcgKxYjRajRyaMGpiJDi1DbZQZSN/RcnLuWYVY31cblnZxJs99N5evBv9zHa66uFqWIsBCGu15cxi9hM1CI2BHpmTEZjQTzQPAYjQLYAFbZrvLmCs60eIoi5gaqW5gUD1wPpfewH0ZAGDxhZzjgiV1PXzbyZCQG/4EyTFwTvKuwdp4XDjlDKdY81Uu8bjgKo5JkgNj3BG8lnR5MNK9RPneJruYFuqejllhu9oET5x1mWNcNX0XL13Ol1nnRbvuyXKezWVkIyPPsE0nKUXMj/I7I7Yz9gRxNs0tGwHJWdPXbGWBhXvrgrcZTwynr1KiXRTwWHdYk6uu6/rMW+FE6eXAU/k2y7ooyQPBRo6+wVmeSG7ylYI5ENrRHOjYeCa8yzXJXh6X5FOHZOSHbd+ZZhxIX7LN1pDmvjFJBiSXTL2bhm+5zOcjLOcKY/M2tkiSsl2ZF7vDZHiFcAJ1u2teLB2OcdHHd2t7+nLWfj0Zgv4y92uShxYGJHlQPOmT5JknV+yKzxXn3Ch6dNDllZ2A+zyTBGxPJFl9Cb914aoVvx8BADtevpzV95kMrTSh4Rvel+cCx+xq4I3tXGFXG3o85lpfRy+dMbH5lntpU1uq6+K+QmCyyV1XwBuvuq0G3Ukd6/rK1rXL8cCHWQatmJzm65ghuWlH45XShDzB6TkDbLNhEMbiXOKANH3JWt5XWWwPo/++rE+qK0gAnfOCY9/AMclOgl44q3kRqCALX1QV5waNc4dbI1VzqqpNlfGi7pZirG5W+I66qPOauMl0q3raXr6ty1eE0xeqIKnUrX5DeViKL447PjTEc6mRwYzwvZdIjCAzk8s4MGjE+2PeiefFAcN1Nxuxsk22YiW5PL4vB6V9AVTsm/mYX4quc1/KiVfdUiHi3POM7rq+N2FWVXXdAsVBQhvClzzTtKlz2tBXdE0fF13VzYLiBvZ0VhzU1rYD3bTwRjowWUnny/mOnusqj/fVOu84xlV/32TVuq9Q+lxnDa2EuE/K3yhOBp55YPiG1nOHb2W46Dc5yxOTw36boWXfj/dGbPRzg9q8rxk+tiB0hdWmrme/9qxrPeoCuuoCw9f18q0c6+IKGe77csUlk+ckAwvMcCO/d8buSzZJ9iQ7TGznDg3YsiDqTjIoxRcdnbrODXTys6KVXziN0tzqXzIPjSQ+16M5jbreIvLcSPl6sWbU/Vsw6AgbEtgr8DxfFxV9kD8rva/WLbbcvpgrHP3W/Q8FvMfFXS/fwq6b5mBZkihbIHgxIiPnEWcBFnhuZ8AmL0wWGJics8n5bEGwbfMtQ9YkuW4gfE3JGRc4xWVj3cg4I++Xxz7vAV237wVTl0fy+EW01X1e+0rWfaNqz819yf8tJJvFbNJK2MJx0kjIlznD+YTLJJdIdsW5wpYUQXaKtlQQi1OJ7UJJkgHZ5IaB8hTtFcEgmR+xIe6CMwyNzyWT7drwNfbRLX9uyadu2LWsix3tUtYXctUlhm8p+5WvbyvbtTQ/G70peRQ1XBxHbTuPosVoAYBiT3IYTTmIXgVgzJ7R6TNoMYgaRS+6VzB6ZJLZfLVOAfG52050WO5ckPV9dUHADjzqWr8UAg5fxzru2HR57PuWZkk4sOJ9B17ETLSAVoCOm81otSSHUcePTnRocm/crmZqYiaaqgKvdZNRl/kklAToOvHzfeCYl6vk2Oj3b3ClWEssSLN/iRVwTrLLGflmclmqfZnkKySPC9RsCt+yTRErggE5YoPH5fAcN93rrtI4ZFp8GTP5rStc41JpkszKfkZurAuWeWSQkXsj4uwuLePXCkPDWyQt8xpJ1uRY95bl3Ps2CV8eGEKrTF7nxrzr5tpjXeJYt9l830ravRTmuUAz1gRCQrMIpBrTdxTHzKSQjeIibwJG3WPoOjPoiy1SgxMptJdHI57ka5PAcW4wGZI5DF+xyRv7ucTQPHdo7kvLsOi6NoQY+85XkEGSTLHE2uVrXlUIDuAb7nVjG6se73sVn8v377eVMegXh/T+S9gnryQdHo8ISO6T9w2O+uQ6OSiAJ/1ZPna8pzyxfy8h0BS6kr6IQ0MXqpsXSgSNZPfddyWWdvdeN3nU1c51T2WkqgvGdwIee/2UFkNVDcTn8mbl9w4OdDrds6IqbMYwPfZhMxW8K20jTFUHFeOxri53EW2Hr+2TgFUf6OxCVfExP1DXfxPfKXpsxYI7zIRJSJJUyhhI36dJcmNEI57mfNzq4CR+hVMk26XZiGfZJM4Y8WUGVFoiLL+udb6vPnUXAGe7Os8tVZFcvmNYpW/2YS/8m+H7NcJFNZhTSyyE8o4SVVPXrqpmxrJ7pGtOe0UavqQi5oxzhT21jOC1OIYoHwld1Fc1cZPpVul9K/gmWwcov6/m/TJrv3DUzZX5tn/69/qice6vzUYc0Y8HlLE/gmSAO8a5Q0BJsQnAnWKD+yaDmPbn+hVxXxsUsSTYEboeVnDu8LGlXcqdC3DWFS7fYNel66DEBmKV576+YNGM67NUjWGWSlU1mNcVH7JURFN3cV8fiu9lOCugqRmbAJTl6OoYy+eaqarGfXftfIfHg+vnC/rHlv2yj6ASWOZFm+/o9bKP3KnrhyOCvoi3nFDGMXJaou3imRDTFeg9+5TRT2khYKufyHP/+zTjSpxLtNzXhWSD5CJlvNvHWbpqySj3Mse63mNSc89rhI+0MvPWkMa+73WV3MiNYhqRAghJyreLmZUhBUsklTdFNoSddEiSfvcVWciBlWJCEeXATSG/t8e+rtj1KlFtnysG9nIz7hS+cZGHFt8RB5ho0LhvT8rUzVU8t7bJeL6eZJii/73+Z9vXwb9ql2fqqut/qWHKQF02YBFb11ZQOCA2DgAAsEQAnQEqoACXAD4xFohCoiEhFpuGTCADBLKAZ88U7R9Js3fsZzu+63zOw/MD6P85X/E9aO3Z83nm3+nD/Ten/6U/rB+iB0wH+cwYj/Gfhn+kHyu6a+JPns+bTOKZ/GXwT+Y+od7K3xEAe7zx1f8vxh/wXQvf63mprnt6yFP1N5RlKltG9k0y5led9OdoPsY0qNDgqmFdzWiwOMNPydNsDXU6rEMqPdE0YTpwrrr7dwTkRrPJKhgJ9IJzO3bZVVfNZfSxiYeZdhd71NxedRI6JMAWjJWsbtoJ6G38fsWdLnttAdX4pBVPh4zKlvm7GgTrEfKGEu3+LPQlGOt3kmJz7YS/XZxgTu5WeFOP/OYtlgMz+QAbT9Jl6Kn5Ueua9TtN7iWQxezA0D0/HBVlUJ/ZapcpxRCVY11wKuOH3L9M0u/wtngtqxWuV3p3vnPpeVayxiX4+U0JUI3eT7uGJV54zvXV+vILnOs2LwqTUnbOXr2AYmZ61FV2MCXDXjjTA4ZV4wm3h098R4U962edyZTb1NDepMVzROGwBNjD9YmY3SJFd52V4Ej28Q+nHpjDCszelC4aw39kjHOjGB8HCZtt7XXfQD/soQop7ENiwC46Osb+0MhItuySaqemjY+WWrIzlk/deWbinCaBIqUVW1v1PpPs8zfM9RjsglYm4cJTBVRGMcbJhb8DKxUayMYOnyMO06q7yOCVIU/7ymprs651DWmc4wDX8Yevoq3/G6QAAP7/DWQKH9hGHYBer/1k/zxqnmgKgQREiSrMWxlrXe0m2QU0bZbTnrMahkDjbIkwzOyhURCbYigzbJ61/p8b7QCfxVjkEoSyoUrOMHpuTSKq/6Xs4BYJB4/aIDu/IwdkJg/MehekNU1hU/gZlO/+q/8UDT+hwWCrJoc00Uzl4BRZWzk4mhQRRuLYxGeZ/i0+HtIX/6yppV027jOOx676c7FkZ+HHiNjvhvbWH8bfzB6vE8CuHFwlwoHQNjBrmyUsX3c6Ym9SqbhMBpYmVQSenvhwk3MF10nMj7/F9TLbQli4fH3jo4NgHMBotWqh9icXnJXzd57tOt4jmg5urVestAH0toiEU+cdDhoOr80Rhlu0UEcn4WhThrTceZ/5V4UTeIIh7mlKxaLWOcXgFv+I5FPvvsYVYYHUoNSIGB8Truc8zbnFZOv0W5qp9n8RshBv1NueQpsdU6El5j3PZ5qLqq0e+P91XRGp0uQbV7GQ3W3Q/aaBNxH5UddHKMqz0ZN8v/U7sRvUPPqViFM5WQGyg5uH0xqAEiTQsNouLVosh/IZqZbOTNcAWpeJy362HuX/2myxdB16DqukBRak8EiCqioy3CBTPPzGsrrJJgD0Nj5xAVVPn8B8vj2xgqO45wMUCzLrLCKb5KwiXx0HaWA+Y3StcswU6khFFuGUHcF9Gh3dez4uGxngYgoOL3bHKiM1jVTwrIGFwA/l37J4HFHFOco/T5ZgJ4cAOD+cjo2ddxkffrgQY+nRZ2sl9tWpB5kymrG/S6io+dkebTJprevl2Y1BybIoeXlEW9klBiKODa0lQlFi1dXaDMUbE4OQbhh9Op9b6EPI6YwYWnVbo0xS8ghn7yeBScAfr2/2cSyJwdM1cfciMxzJpMW1sIvCIm384PTiEV0KOoe5B/nmUL1hIrBat9QDQCHArV1O4IdgGZUjgH/Tngx+FTxJEea5uIiIgISTUBRh8NP0vk5rlOr8YNbYba1dKmypeyeZJ61sujxvw1g1VP67crgVIUMEyLuEQ3GljfuO2uhexNH2fkf3o7CL8ia3RBf4OqpRXH/Z4eaIzXGlUhM8h+sXCSDEgKpIBqcDkwQ5c6RWHbRix0ao1t3FXaTJgzBhIVgUIlzG1TlqAQwnZh8kupGk5Wz0MM25ev2na582vn4PTUWZ+5zDqAD6zk/+27yXB62jqV4ypXpnvkEQavcy5KCgcCOCyJVUTkkElX7VBLYTZGJDf7UZB5dIWSe/ulIH3ZyQtt+Fe+KfF1EY1B5xpOxk/0dueS4r08Ve/w2C3ilcluhyG8oB0Xgykvb+C2m32tW8dKBB9FhLYeYgWSfF5C6RR7RQWbIkOH04EkakhA9mq3d6nzKIg/xAJqfLxKrSMeoF+7urxJsLcQiWePDSUH09Rq3HVVKzgpzD9ix9mk+cJMnNzUr7lM1B1lBUOC90TQln/3suQcn4DZOYkOfG8rafTIBkR+hA1PLUjDNqlecJWPKoKxK6iNFSKxLxLbuOjEB5ZdsQTwdPrQv6BNBpT9OpNIN1Uy+KMv8okY6PxI8SMl2HSqAu43O3b04hbdmeyzKp3gRCnQ0tGZIKtgQpv7mp9d0YsMwhvTETfHoiEoer0c2Y2WQOSs8TMi6IhO83pRhu3q9o3cgU4RNmzyW25pdYfNPeqiYETC9VGcT+vMWquSHH+dpTCFJ1iOK4py5ov30pXPNgkd1FtMCNkgNrYQ2fNCXO2lvPByuTaBrtcEMBua0xxgmDproarTj5YapO+CpI991LQroX3Pg5Lg5+Z00I2ShyCB0F4aocjqUO8fjywxk6BpRe90goo8b9UnK6U6r3TgPnQwDhpfR96Cyci5BO9i4XWHAMz4ypx0Z6mHrttusEjkwXHahrYEI32U3nZ7sGs6AERGm+KP7jj7ZZelRsaBcOltZeS8FMwKOxRxV32uc7CaKLPo7WkVP3NV5M+U0O/6UldKWblGlL1Nm98D0sOZq5rQ7dDmpT3LAwjVDJgADyL9yYHSUjq5lQm7lF4e7I5vmTabLfHO8t56VU0MqVtmBadv3LbjxR73yBPmPW0T5mZs3wDfv1LndveH66B9Dw1JQ1u7eg3zwMW/KNNG51DSVesoEcVFetEdkOCjf9Ku9gWP9IHnz2ddHG8gRyONtER+Z4z8G0IopeaTx8QY89JHo4jpI92C/UmsYjJr+12pdPp+sMnV2Y4Vw6tafHhLo78jUbL7wUS9smzFyu5Z99mQOqs3SxqW2I4g4SWv09km8gumrEi7jWUHHv3GumRLGvQVlxXwPxvoy+p0+JnI9XEBWx2/BydB//CHvSeSg80C/ucKPApDi8BFHuLysnAXEGr/QttEG7OjhfcUjBxB3SLLFsLS5h77W59GlGIj0irzi8q50eEaoNJ66zmhGwYanBJ+JDYz7B04ntIjgOQ0xGiZyS7W09RpjBSTJlZMytKtWtFnjTUN/RmuxA8725QG1q5wHIEX17QTqdpIQIRtoEJ3ugbqSfy8g0ZgfTdORvmNdVfYWk3tOGbYZx3HV25J3AnNf/oq0tLut57jV0AhgkIzE/6alXYCTUmYLW7xPC081dWXQRn4mXxq+TYF1zZ6kOVqh1oxzO+R2A/xxJOB9PV15KykXOdNP3RTANPsqBGIRzs5qj9/LtyJvX5KcEO4pZb9nrxFOu+n/MvhqVyeZgg82SAxCLGGFDl/P92Wo7RoQNETHnEzlW/kEosNF9WiA0kN222GWM3sZEvBoc1h8wweW8gRuD0irEWWZpVyjQiumxidsu7/zh7XqmP+xkuSg6W87t+1Mk+xY83Y+1StlbrL791WZKfv8WS1jglN1S510LhqEHVP0/XDl/1ldJtldG5vZB5iVU52E7Q5oQXWcWKQkCZGr3J3alKNxdVXz5wQpnhYb09V6+H84GgFec30+wH7Dd6hr6lSVkjttq7+CwSh0ec4yJEylNasobgG60JwNqTg8FGK5PPAzB1cv2T3Us+mkvSEEK56xrECT8uQN2bMVNRAUYLPbE5M71U60VT1SOp3thAwynk0D5vgsxHUuvIkI8QXXz/aOysg2KvrbrahI7AmZiP5NWwZgGjAgtDZYL5JY2UpkkvSHqHgLjgPe4x1Xh9plIQwY5OOzNV/xMO4O4w6g+tYlacCh09pfZpUc+0tkv/al61meptY5EeC0a5k8n30TaqhQjICcyTSGBE2kbv8hn9tz5dqPWMVnJKzLm75Q4xbiQvjnUNIAqE0VI4Gn/2e4xNlod52upTFhChdTfzTWEV9ArEE6KEAstTUyLVWM/V0w3SNl7oFcJA2jGQnZ0o+mRW6izmquQhvNWKZMXzGBm55HVbO7S4fwQeMqP2+feAZTaW0H5XF3gpycMZG27zFg4X5+taX///SD3nAz3Qz5BHV14JvvmispyuNgYFNRzx/c+RAZMMq/m8uQZQwPJLP6KAyuKs+pxhXG/50dg9tRhQ3ZJEYXblSgnh/V8gPq8W6ysUxjSbYAxEoG/AGdq/NThj+EQw7mWqT8hUf7cHaaJRvcPbuOdyxgqltnETmrOCiBwRMhkQkV1I0LyD5eAEmyQmXlrS0TPVUSc1BqhgGZSoX+x+NUUI8++RzEsrvc2RMB5XQpd/br9gnjGY6EGqrahEbo6MNDvRLv/H23D9Ym3VdwEmJJ1g17XKvXMh16j+g4TBZXWqq/U4GpnDNbCI66JHYN+TkEHRZA3ouD+4xnr78VLBzavc9of4XvMiJ5HOJEIgKi2VvG8LHG76tBLG0G6JMI2jAmcDhFmt9vZZjSbt9uz0cgCpq+3Z32xq5at6XW0Mip4RP/yM7vGdf6C7T5AwnY8Bxha5BfnGxDTAe9/UBJiW0iu6bP43dW3cYKBTVzZ6ehDbIrBWMXHIt+LfILd6X+8v+pr24xnNXgNixQakwI9+jHPKSPyscukvslMI30U9pZIzUQJiyfezAsHzjgGI4frU32v747bumPJOBgNxh7wOcOkbBG7YE8SlrVCIPzx4XF4uJjqlh8R9rKfxdsobAn8ImU2GV9HbB1F0TVkqWqxGHMGtqLDpIJvhEh8oaDpeYg6ajXRZxucoL5oV4IlIfp0jSCYCZmP+LsPGGUqJMStx6AAAAA=",
	crow: "data:image/webp;base64,UklGRngkAABXRUJQVlA4WAoAAAAQAAAAnwAAzQAAQUxQSOYUAAABDIZt24ax9P/Xa9xseyAiJiD/B4WOsaHsFBSc2CqnrBAUFHTIUihX0ir4rHKAC8aV9IJe5ZBLxooNFBT0pZBP0oK1bW3jaMvgLcMypQxONdNb5lyWmbxlWEZfFZeZsczuVeuNJ3Emlvzb+y94J+MsaSFTlV2VW6ncPhdSlvzJV51OREyAn/v/m7extm1ewj7zWe93cOY45Zmqs9rVmfNZxXJewRmqUOVQ59kjK1sECFJ/ioQsgvayQWvRgmVF2LI0HkKWbXm+BYDjoNcan3VETIBlZ9umt21y3D6MJG134wHMogmWP/U9b14RBJhJEzxkplfFS6+s/w1EBeW9+L//I2X83UfEBBj/t3306Ibm2OMTnR2J8HENSleFKpF7GpKLptU2WV9ElHPTpk2bNmHatCsaitugQrQmbEO6cUiBxiFccSI8CIgMFjUAo5YqtaY89JQ6OFNrSmkllVr564sXLz77i88++6GPWA0QPDhyAYJGAwjwIx+rmu97pfT0Nvnd9H6S0iTdtnnKPaQe1/P5znz+Cx+bS0f5kG/VG1pvaESxo8iboJjWy/oFKK3/8g//JB8ZG2kC8Mg9OLAsou7JrSevxcPUWu1rzyvwrRcPd+K7e3EQ45sPcNHPLndjvP+ROCK1RAGlrLKV2Vo2Zs0cUL1Ryw8+3IPHJgLHxmwYqz11gXwJIgPwIACWhk6rMRQAR1XBKOG+f/+/JpkOX8MkBBvyh6Wj8KrJ9EVhHkKXkxDCTuE79zHZfvw3ZMmIiPQhyBUE8o7I+ZWIpuFMXlP3InvwTHoj7CKjZPvXSEMNNcB6mitaOgAJgGizuro+txXj/WmLp09q137Ze++va33vH839pvf9G78BPi9L1bfl1c2VjX52YK0hP7Vnteobawd2GyCVzu1TUNZuTFgZo6CnJJUJLoZcUTW0j5AoVoSy9UjIbF+kpFLrqtX11QjKurErDQ7anDj3ADUpTRQMnVvLtHMd7Ta6Ll+t1v5R98qTfJA9ip4yvHV3LMWJcy9pOevDWyfvnXPuCO66t4aHHbh0U7AHbmXbZbcBpOUxDgsCROqJ9gJESAAKNNEQAAtggYDyJPr7lRW5a5etPT+z9l5l2942eGjL540OrR3a/uMmq3etS9b6o7JRmm/9iAOcn8CzHepeU73yXtP0wr8oFHe9z0beez954tdntO3BhsWmJN/BZwDCQoXWugmQWRzFgPJCIMZV//mf/8Fuh05f/DM5WcCeyP0PtalgKOOKfFjAKUlybwgaxsG9DmNPw4tQOuzQ/Dzkq4/DZROrwdI9KVHohkCSFGXnoJGiHGkpYEAnVJNA5lwFT5g7zXPoGBOb3Zhp4Z65bnBgHh+bZ8/NATzomGlFGdNdNmvfNTGaxy1evlmG0x+Pkxg9vBw0eXgH0EcU6hcxxgHGxnifYR/9YB/xHi662G58+zbeq0TsoodpMtQggAdHE2MoGr0FsNQTDdIAAniLc+QZBpqS3rLe0pleLjzYW9ia3Q2K5S+O9OEHWNX6xVB/IbW0blL+SsmAzWSSPb4DUgB95p6qTWlUO0SuMvvsLY8QgN00us5eT3nsU5XZCRkUSMWSO5BUkxNtzRJAJEQNnMsk4IFVICHFTK1vt9iq1kl907ZSK0q96jXvdI0WutzyH6mNPhyo40Zfl4kBTwujnhBNgIAHloihERAELDQiJ2MUHiCL0mDU4hx4KFARQwcBcAUCzqAqQmeI7leMadVpfFUdHan1daWUmndSp7+JhfR1ZV/FQ/VFt7KRFqvas9cJgCFQwbdKTrTUE4HAKuAtjgpgWWORAIfzFGAy4Nq2ygOxyrTaJN3W1Odl5gGU2afU43qQmpWYjN/VX0FnU/uZPnPgte5lG6OqmeW9/rLkyL/Undn1k30NYDOGXm9p/va/mmxWtrSQPeq4OvsTcsGDyyBkZA0ICM0CDiTVtAp4+PTTJiQiup8E92P09+LbtzHuxp3Ah+/gGNVdRKzipBNjNz6offiOsh/JeA/sxHdgzmLcrZSI1TT8xt+Y6wPzHFYV+bFZ3TS+8h+om7svzOay0d814wNzCjw3P3/wbxi+dd0jN0YDdIbgjVnPDOYuwhyiAfBUBQhsZOgA3uLAkjujAqPVgYdQEeL0QxjD+W72IgRdexVCCMMQut2wtZM9D6FXuAw+hNBp8zZIi83T6ytIab0vM+j05eRcnl2JDFgREbmlqkQ2lmVpTU7IzSCDBOzJvLDXKcxlD8y2DNB7Qt7L9aUpeUvuETBAQgGkGuAc1iMFUhMIBUchkCcAS4ItH1/6413vvX+U+dUdjnfhvY/ZVDU50F53eSZ+UDPeq2zm83lBeT+oec6vdfbtX9lessbaTgdAPeDhlnXB2r49ArAHsGPfnNpUYGw3Nuz5mf3C2qOCgh37hsbe9sHUYEOl8kM9fUaiscN6CBDRGQogGkLJYT0CBnQNYgukRViQV261A8G5bbfuXA+O3bU4d0C3U3jlhnO33M8OR4A7WshaP1Mj51y1KA2oDKJbKsBoFaLbLoGdu71QsNRbyYlbfoC+dsdUs9V/pMGX0Ili0mAI1DwUNB8AiGhQAIEQXWvvWrsPnZFdHqNGdiiAXbKjobVDm2qrmxDs0NjhYEGdSeGN3axssevKXNxLAA8O9BM2ZhggceZRtLZPvBe48H4C+LNs1/ub0txPQM0A1qdo79Sg7PxVR7B/eCRUFAsBCTRUGRBKjjxkOgFYAJ4Em8ty5eWicH9bFJiezBYwk+EzOVnISIp7JRGRz7dlAD1aZXXnjLr7ORyNQuiSz8IczG3oJSCshK+buTD2IdhFtAzh1W3YAhUAx3K7F9adAvBUBUyEDEgtwEP4cJiIphzYeC/XTyqVejCVSt35u7/7u7/7a7/7u4+BY9N/bg4KYlp1hqhVeGXchzg2RnD9klLKKihrWv20VoCPnUmM76AP0XITY4wPwHoAH4kydhNjjG/hcpdyhT4SvvudLAAOJNURAQvtWgXAgaWFGP4xBjqjwqE+arS1hs4ok1V9VJsJsKUdJqXtGqZpPk9XcIi2ANcDcDBNt5UUjYH82lI95iqyT56ynxTjUwAJAMZJngJIKWkuOeqBJQKREzRYbfdKbSoVodvLvthQBbadqodzXKj5SsvkWnqJttNDaOeUHbkEHCyp5jkCDpYAApseAYK6AIKipSxAYKABBk65JLSAmJCfVodR9WBbavoKXqmvGFOIar/2lbSQ5tJF4VCtqbwHm5Xm3eBal19PyqdYj4DTatQ9RU9eAcTQC5ayAIHlANIm5efT9nWTkg3TlN43O6b6zGybvK68nmI7DpGqPOW74jdJ8e2/My+0/1LfVwRgG/hBvwg6lxrMVgALG8601vqUetB/X1pX7A+fDmC55mwpPvlkxUOgXknAQchdE8uBOGvAA0tefFILJPnPixaK4xcRl9y/ygYS7/mYfxflGBHRn6U7ifEdD7t4+V9gv4xpWaH2m2/xDVdr1s66yQ8OzHdX4ZVxsb4C/NUZXprPO/DBf3j0vzuAMVVJNSEgULUeAsME0Bk8Qm4g/j/0wq2Et430UeHroOEy5J3COIRuCBLmhY0QVkK2FUJHknSerR37MpOeAUPD5buyLMUBfSnf7MkcdjvsdeCZnAA3MoIVAQYG9nSTHIaJdvdFkWhhPdVEPUIAD45cgAigABL52aLke0JqivZEP4fdFX8Mfe87Hb/1ZBH7HWbeX0/8HHjir6Czn617f8d79U2TrJQJa1AACaIhgAe1jqXFob0FrE0w6cClHWpI1gK3dhsU6G8aE30QcO0UiTyABxwWCOQJvpmS1fI+9ZxTROUa7Jvae+ecO2Li3Et46Nz8gXPThZy5l98sJjrqveuBAl0x+xkHbuyce0DjSP5IAdmsnx1awN1x78+cuGqTRAlqhgDYAggQF+GpCLmmHNgAZwvSt+Uj4NIeZXZo7azR2D4svbE7Tbo2/6r01J4Dl/YIjK0odI80hpEBIiTOPEXbqTksqBmAmgK+GGl6t08eARRYBAimKEdaEDIS9WaWj8etrC1gLENgLnvArYi0m8n5RwRU4csQYfe84LDkhubZPIQzTvpUK24+DjQRkA8mYHG0woqHvoFnxlgYm43OIvrGmD04NbHZjZnCLuULtOqb/WIdb8lfDrD7McZ4+b7trAFJH0AgkHH2/kEoOLDkHh+HiJ9DPSx8s3w+mxl3Jtg+n06Yvi44bIHIp+d53OWq55C9/OU3iQN2AtIKex4HEtHLy4aw+1FmFCk1KByrNZ1t9BFsxUtZluWLl0ZQdWB95nwEBgIIJDKMPwaM0YLDgjQS2NmSagD9DKlaLW51qM1ULBiTbcRWuq3cqW/aVvmrsW7rD8ksENQEX8BnBIAqEE2Was0CmVZ+EpWr7CEtux5UXk/hmAaHzMMpkzSfFPb5VOkM/OWJPgK97IU22YgEPOvrwqkOAWBj3BnVkSOtFZzqAN8UqGyx/UWGxFHQ5imAFEjECZaygDMCgUwnXOwVQ9FVfo2HN/FdFu/B1f24Bo7Rn7B72aLsasP7imT0ww6xcN0DBPJhBzWAgK9prnmq2pgbsKwlDNlEWosDfEY8S3nqznRzuw7C2yALGIWbVvOgYfnZfaTSWQVIn+6a3DR7JidgriRUBp7uQxBa67ksiZ5kSN0PAiKTJjYDAQO6kjSYxSSAaWIdYb7jO47TQLx/0uzCv2ikvd9oc+FfzL3B7C+WYSz6rfIp9oDBmu1ZG0A/RD2oLBt7VBloMCBtIiSMNSRfBBYo0EQIgAVXMaAr+cIgBo7dtUacyy7d9JV7ALN+M6sYHEDfOdWkM3TO8g+fivZ8N8WqGzu7yuCA/gxAT1GP4MSpihs7u+5idK8FbO21Wxa4dn/6ieiLAgAFGgxIhgMPYCoo0ERDaBbAA0jH0KV9+JV1TewqHFn9mPEKXNh96Fhrx4XfWkbINmnDvgy83/L+KYB+gprR2Wfde+/Z8P6U3WNmG/CV73g/AW78zorzrW9In9gXCAI2w0OAiCZXoMEQBCzVgAI7JmbyOsgVjNbk2bnMgCu5P5e9G1nrAbIPQa6UzHuysVxRo2zmTeId7/4AlyHB/ecg7JzRPwHQR3QO6TwOIQBPQ5h0QNjpFG7CiGyUIX4CCxS5ybDgMgJESBQTRDJswcNH6MA8f2aOT81BNI9L1+beOzPEGPNuMevaUxfId1ytvTe4f8XuJQ4scBh/BYMSwD7iu4ixC6P4tta5w4jFafuCgK2BV6oJOAGwuJqqxdKRHsOOandtdkHPNHqhXxwZF1nGBuk92GuYppRSSUoP5IEomYLtNJc0AaZp7tODRly0e3COamAJIDBwELylLIFUTEyw9NUJvaVar1e9rmEhLaSFUmtqY7sy+PyzZExMA52AqwGJQJx1/5P4PMmBbQNZCf/f2Eq61AJJB5DURbNv08nYcyAR9aB9KoYG6T24SboFnqbfQH1DZnraprMndnpLAHcUwGhDm9nMmFtjaPaTva5tVHPMBMkcuVBMRGMLF2BUPPR7zguAcrwVuBez/bhdKLu2SSfabqx2x4iRxt4GCh6al0MzBjwCN+4X8gtvDA/N2h2q3yil1Iv3xQV2BHiLqzmQNAfA1iJtP05ehaNRuBkFB93j7HkIva9D47dACuURcBGC3//jj8B3/kbEwDO5q9hdlxlYMsBsS+M5VbeL2hZRIkb+5jvyUTYA3kIjEo1DzXoI1KV7uqu0e1z4yj+Cp/2K8t57jPfLvmnH+0fezxp0PS3Z4S3vkh/ZS+DcPgUHPLJLYx5buwMH1i5Zu2TfwNjmQ0XbytyWw+VKEK3JBUoeCRhyRTlCIHcsMiHW6PKBmOps1nVL4uTaHVceLLvXrV46ga4DyqNlOvKyD4ieqMKec2Pn7rqxYWbcsqBGNDSUK6+dG6CcW3LhhZcdKdEPU09UvQWwIECE9AECeaLeT5wBuZW7i9h8mK1aew68sXbHblf6X9gz0Kt2DB1rl8coa5fkm2vYjTRu4Mkt1VPnl3w5Gna83970He9H137d+9V91KTBtUOEybiHhk4ock00AJ7ceggQaf6yKMMyn/l6rzaQ24IWyWbSV4Ur+b+u9CT37PRERK4Kbh01avdxpp8cA250fTCFixAUT0Nuz9kJIfRhFvJJWJ2yYB82Qwj3W8C1/cTIge5NASRNLmBpaPiAngVnhDj75RLob9RBbWjelfrG3GniVCaGoWk/aLFJqazqzKr8fBlO+VUsqPvUBYLKRRdsdhmL30dEdBGFZ+0jCvtlfLfytr4qgyITFhGoWA8BAkA8twCSoZuRrmdQm1qv6rUtrVchzYq9aulovb6i9arWWi934MFmZkszs2LDn0TppVKO5BEYpClcj9IgpTRlmIxnn57CRMCldI2ElLtcZeMREIVQSKhAUHVggdAqHMBbcOCRwKkxKUsagno1dqtDw4E6PlLrSqlNpU7qNB6OWlVxqNQd8GptU526mlvWPDGsh4CPQTZYcFQDkvFwgoAFB55FOmSEcOABPBraHbm0G7W01kg4ZxtCHKnDMzWDTadXB922aKUi3FF5D7addKmTV5XqNXrS9UBSN7eapAALQm6glgAeHLmAc1YLrlFSTYZnSzFJI3id0hUcIvtsmKY0T2mU8nlKyswAsrqHaa+UUkompbLL7Ecs99PxskJv6QDrL+BgZra0+obOD2FH5/dAb2ZUl6ZfeL21BA7AbOn7BzOZmS2tzCjfiKEAjwBBXZxsqSfjQe5thcAwAQQGLkvsxrj+X8Q7SrTvAw/im/24s5id+O5NFFmUeWcJ8YoxZsN8LvgaHn0LcOWja8qYDnhzx5ji7la7Kt65MXfMS1heMvmGkbvL3f3C/cJ9xtlCKMAjAYLxZNySewCnMY0g9+AcZedEl6So3YLrrt8PvYLt/huxxYbN7o4dbkH3FriRTofrFkJfFCmqA2W7TUK8VtbOZ7oEd7ZkVfIy0R2tWud0W5vOtYOvs+t1qcgeTY/+bbPWraH84syyZZno+Zn9nJ/pJ4SqAmgwEU1zl94dcMHDDrDAIqxCphGDyne6Ia+dR/ucTgDHhrLjOM7vUH7XDDebZrNpNpvJS8ykaSbNcNI0TfPYWPg+tzqXW/l2Lv98ZWUltyyXW5aLfv15I/6VMhrcZLLR+Q9KVlA4IGwPAABwRwCdASqgAM4APjEWiUKiISEWS+14IAMEsbdur9V/j6N2lWKfK/0j0QOT+1n2z444JkyvcXOq8w/9bOnB5h/No9Kv9q9Q//AdT76C37VdbH/af/DhJH+E+h35ReGmOLoV+HyuvCfC7xe78/lllU3kkAnWi64SuPM59GT/f8s2oYchV0q010qWITl0Udy3fuEsObGG17GRDylSWDJgCVwuoCMqS0mF+MsWpPf/iS+P5cY+S0H+OgsZ8uGcv/Ne4nOltlY6aqOmV1qwZTVWTaJKZP7VjLFiOdUysIXroN7LtIfkhlamo4yUlJyMn4jiV4s+kS2PqWrHrXvW8etd0YiWbOvvVzcfKqyqRkwAyhKSnn/T79nq9yQr8HhGL1JenErDkU7Y5s2masgmocXDUUUSo+xcqvVqJ3D6xDcZ76F3BSNHVB4qTfcE5I4Rm/BcO6JqseY4gNQnXMwAsFVSX8bK8CnR76cGNTH+O5ee5a1ojZCvDJI8jtrURIVOfJ1PKorKfh+ebMMXd5eO7YrbjyU63rNS8P0x6G++pSFr3RnzWd24/ONWlLAdEojoQiwGVJZC6SIYgthQTRk+HizUR8ZDBliYD3aKviE7YHn0L03p6MOSUNbcLyTS10b/PRm/jnJVGYyYEMI+S/zDCm2T/TkfrXAqQCMH2cxouxOk0hOf0LeZ3pcMW0NehQnBnK1ZKo3n+BhdzxxayRmxyVFN2x/SGun8QQz8C8O3t5HN6JZjsdKUKGVj/7fghMtv3zFQkVEyhOKAAP7+7qoAYX+vQa0S5cBhf504SEi6SzrgoneiGNcdxVA2t0A99n4svcbIl2MZlL48rqL0nNTNmEuIv5n5qyYnAxmXkByN/FOqUt15lrSeo5Rz+yH0vl4Ofgc9QnR2IGBqiRpwfY9fJFOP3N9mPMbzR/aoiGjpOfTxnv/6kVkp1Dt4I1t8u6FY3MPJidkDxKgVVTTgX98aXlW/VF/f/GHl9xYu7sz+/7rMg68s59s+OaaEHsdngOFsYUynReH09T//7jkYfV4wUwjSR2n8fzbMa3QdZ2ANQaamWHyH0N/tB19X/4AK0F9tocgh9d4Y2KdcdPzCxZLqsNkKG0fIQ40A5a8WmtC/B+ezdM1S77uWFnwSau0HNwjaZia5ij+/dOD0oLF829l8dhGCAX9i/8YJKQ7lEkvvKovqjnQ17hu4kxGWJi9mNRAgoDe9435KMPH2ok0dKwEDeGyCRU3BDWt5a5lhnvfi65Altuc1qWm1J9C3/prdq3QETzs6tVHCYOw+hOmMGwk+a9xV9N79BOOTxFNsCGpV4nxTG8ul2UZ6G81PQAwYlWkvFJL2kGe3QCReIhNNFVXz02m/U+CjfrH1DffXXMcz16n16nTOFB1O4in3FXNifSOPV9HX64VdBx2PoGbpfeK8mAastGBlw1+s1cBJgSZnQjFE0zoA+ASIhy4nEZ7O/a7nOJn96bevMiX6QZDRnWUrcBlEXlaemhmOETh+qdNvNAmulb4weHg5UxBYD1CxJyiwqOmndBwCF7mZeY5uderMMags07lEQd9mYEptJ2jfvrotZ62sKD4n1j6I/4WHzz8m6hamKtJL9Q4LZjaiOGNQckVUzQ2l3ShUXFy7G32oHUGxNrxLZpSAA89xBw8/vcY/QBcA7Vy8h01FsoM6Ges6lVdZWkCai7vW0KZ2EfuAjV84v8FWvYiATGBl/L0/wwh3EmIhH+X0AvtznXPt/19dlngS/g9qDIUSTRXv1/82dr2kE4382hHm6AUI1K2QcLM/jiwDDVIC+oMGzcBj+TaaG0hWOlYC1qOryG90szgUZLhUgcTZRyrRTyx4TRnbGTg4UHDOFClgR/WFxeMY+naX2911vo6AO1plAI6tVR4YT4U9eQ6QLPa/5Xbi9JZVxPDvVD+Gxf0NM4UKpbzbw1GWQnUVn5xPcZpKFIZX4wh9yWLmuKNgRBpx+2dSTwfU4nCx1Hpy3vDQ7rRCpYetpeS+ggLm4V0CNbDR+57UCnvISqw+q0CG9asVcgcSFQAeUqBCl8PybQXWSQ0baKmqcHiGn4f+TBHpXY1dhH/SWVlrPkVTtfenylgrWvnOSE8ciKqv39BCs8Nuo14nVlOofjPg63w2XdGZmMHp/vL3Yw/8R0ZPIFOKmoCF0O/Jha8Xzfy2m0RBdICh71nHpfKxOZUoQvb9E5CJcvW2QsTsz1O6ZZ/xip9y03dXc3WqomcMrl75HqeUh8inrRrtyVq+QzWYZyvmsE8c42ZBoE84QmaU2yScfSwt1rSjpF1nfiuFOOt/ay/wzP2ZYaT6uqZSJDkirVUjkS/AQ1SmnTe3/V4ISjHmNAm+K2JqH0AdGlkD1MY1Lw2zYH2ZASua7COBv8TZACfdXskrNoR+Opad8aOVDwXgPjS3KgViBdZAtFp7LhVKKUuGau+X2d9DZLm2jS48qWNj567uR8qdA4ckBOO6VwYJ6hKAe/FvgW3CozdOtyAIA6r5Tw5EbWMBo1U1Fo+VmJGPxxOFKfBYHlcHAT1s4nfurY5i+atrXkGnqFWCZdk2ZsQz3sspj6Cli3mmxpUqbAC0X08DUjggO02/fA/woqO3xHMdGc01mPPj54TYq/EonVwDbu/r4vLDAHIh4ibpHke6lekg6281WU5nPVRiH6XM0WP/KT2Lz2Vo3MVDdUvBvqRiY6hO2eooMPqPaXKADfJ3pplHiqyU4QLSag30UCM+oqy5Mg8ZnTQQwIvyCBZQnb4BWXQ71ZT5yWe0Ux0pBbbus49peXoIStT+i8IOz5J2VWwwN2YvYu2vVjKslz/+XUng8Ol/1InVGbCUyQyoWp+DGd1OHz66URsLRhfNABv8ipW4u2fbTjOhFxDQEjvkh1hYSf9b9FjWTVQMsijTTz2RHZR+4elrzWNNKrOMj3YFwTvVUbqtWFLmlVH2w2IbY/WgsERU7M2x7N4gwUYlx5dK5UzlhJZG/ntmT2YnRgfkaHX/1K9fwVuOUT7/ZT8Tu2bvu5O0P+Aai7LEISc5WteU/nJcD09ecXZxBiwpHsQmwmaDM9jreE4jVtzEKx2+WghykyIy9ZbL0eFNwRtjrHG+EiwKO7O7RFnwxoj6pSrI1LY0lIqUwSoUoZ2Kf5uLWNZ5/DOrqE1RQOBUUVvLE4ayUuAUpI8kBRVTbp3cHudKXH/173/v2HAm9zcPvSX4wM0WdAvuDLWc/USr3lslFNmnlYRnSdQgeOcY012J0Gc2aQTtb2PJC6/ZTaeDkcI+iQ9QPidKPmHpWdsJb7psOuie/WJRpDmWmguNpbj8/Y3WxiZSP6n6xQqXOEl/u4STbZIXKIXcOKjrFS+/QHYae1Gd034z9DDS7/IolioLV1AJ/7unJBT97IQ/u9lHrFuNyUFFnB7a/XNpomyO7LDTkecgjmNjfePcSPFBz2/1//1gSzybG+sE9hHerg+Iz3HCKg35d3HQCmR+ouuspWeu4KKXAY+Q8G1fhxuHYk7gLmMhJ0G/cpcZ2PY2CiaOkC9Bggl8pRnezFs8vVeC2hG60N4Cf7sODlw+N3F7CF7PUJwAUk2phewKTI077Y0OTN6aOT7ere8qC9K+mgJyCBw7J3pRdPli82KGvUz/2PKUd8Wjejj5qxRO8dovS9iX/llLv1Aw7bHxkk9UegfnrVC86ayZJiHyvE3F8brqd+OnOJuJCxN6he7/S0vpaujoLjDQ/HPResCc3/Ag3CfP69bI6GFddXV8rmrNbfMmof/1DutFjJ0vIECyNSktjMHYDXQP58OLYbsnX0B9/+gNv//l6f/LP//6qHPJfGud2RZwcHcbe4EmRpvHVThaxpmHJF606qbd5uj/ft6/8DM9X59NccXpBYxQlD/6G+kjCeukXvT51YMRMOJuTWiOc2loGt19Ofv2UNNI9Lop+2BH5GYGs8Vo8IW9oJt/qBIbW1JTJ7B0U5N+xfGc9ZCQDS+MDTw+S0l21wD4vwftDgzOdF3LhyrqMk8M4zUPTFzrwPIFSH5/+ATFWKkna/0q2gR79ScWrKLHZRJV0OqTENTyuHEuw2/NaMTl2z2wp6FdL8labza2QABt/wAGp/d/zFHMEBDhAPX8ZCXxnxlW1UuoUWKopZQDLz8YpbzOssz+Qr30sL/GL/nZr2v56JUWmXjy2OErd/T44nsl9Tk0xuNV/Y+9eKWz+m+N6RkyRclMB33bRPV8NocecLltUe6a3FbAbKpmKdz6YJrg6wv2mT3dBfW8v7wqMPyaSDBb64/4g3x1XDIN9C+gacYOxlEFZVoflbNay7thT0LBrLPeSZmZRtK8E6Q9gYH7uGzSD5xpTcvpEdcUEmjKcuPtaFNYh5jixBJdcVGRhF/uLIP3oP1bK1InA2gQtsz+h66auWtIfjafj4O7IwC1iQ07AZ+mVSghAE54aRa+KyuEW1eTxjLcaUWqmEcsvvwgbkgJck4MQr+i5KXd0BvHBpLpvnbuce1GYnEhLplfalpxP3HPBdIfkob+kmLKN/eFi7dRi/HEhxoRkhyYSP4sKORD48rlqTXw3Ty/w+nPS3YuoJKhS1mgOe7p/1kiOQf/7iAdW2xkrOLPY562wiqwehX2DWcYOWzwhXGe3NtqXVSkQZcO3y+7w6oVeRE1q23pKz79k5yc2Zc3piV52L6D7uRvRKl5ji2V53DdS2KWK8jhQDS6MPEidLEkPsf7Li574AVjj4mUYVYzfgFs72WBix+sB5iQdjnzTbsHWHLeK4EUwIYiawCe392lsdpaOBtpc5ewT6Jxasyp9u+Hz52NwefTRijdov2TrDkuupRiYEfWFi1saVNkWDZQACUAMgwnvkVWZml3F+rOmL8FUBuzlGyNhbDyvu4FKL1uVGif5irJoxr4hKYCNYwbP681srPITx1hlHCzwvzFf/qIbdiH7eWqoe0uzMvo9M6+AZOK1gkploGomG/N7gCDT4cG36To/nH5BRGI4QuEteykUQgNJkDDeZRipLFnkatNUvlMEUSNnWV3S/eU7Iio099w62DyIRR4yexrjwRzJ3zha6iKinFqUjanC2F6QnDc0bJ18mFJgmHEVox4Zq2ruoGT5L5//8k6OvDcLN9BHGGpplG7axCCw7OsEBEe8ctyQ+Wsc10+l25T1slKt8v53SekHb/8jJb0M8KWoXnb4JbYFcEJNCpJWcaLkv+uzcW7Unn3A6x1LLjaOOvKNbnJHFtu+aSHLvRhQSnGwQjIOqLD4ylvJzqxJ3DwYANG13+hwFo8aZB6vgMPXOhSgTKwAAA=",
	cat: "data:image/webp;base64,UklGRqoqAABXRUJQVlA4WAoAAAAQAAAAnwAAwwAAQUxQSJUZAAABDAVt2zANf9j7B0BETIAeBhwqYYIWvcOQsk9wQS30qQAimUBGqVZ60P4fjqQ+L6ps42xzLle2bdu2bdu2slWZWQ0ak3Sno0422Yx1nZtc3a3N9490Vv2tMyJiAnRp/z+nkWTtKLO9nD7nXJ0FjKs49+f6bCGHKjvAA9bvrwkhBgmMGQMPhAkgCDCBscEKrM/F/y/ZVU8sICImQPl/5D1OHvUbZyRn/Xaxv2tra4vz88TfIqOuvvrqq+cldF2v0fXg1SN+exxK+SLAgb8lBiwuXboaLC79bn0ZtvgM2fZ55JGbnqVso7ra3z0yaN1VPPLIzU+pb975yHiRNurbt0/fvreAiueKefN05s+bx2ru0XPdbNK37+3z5mmwKM3RvSQKgAkqRwNgQZqHd9bNOZT1IKqSaF/DqDNWGTPHCeHKeQGn/u9w/TvvvFPrUXac+4ljTXrnuQvECQBMTPMKuocuNzc3P3p8vc2Ga2XYNttolL1xYBYA2K9vs80guVxy6XkP6LtW3mNNPYwGPCZQo2DoK031csy1mz0mn7sm34dCocnl6m0bHsMpWLZdKNjhT0OhYwTZ13FaQBn4Ej9CH1qxcQGOBx8Hyg068MADD1wGqI7jNDLDcWb95MRRmVEcd6EV5qirnPv2kSMA5mpAzbAgBfBXg8XlTmG1UzQAKgh46B5LoEOUcL57arrvbtrdF43upyrjetpVDz2dOFVRlJ0TCSdfPpzPq3kjn7en5bvflt0V2CotdV5LE4kP5MhGXMc0hAYY/L9KvlPy3WPfd3yv6PJ///M///P/+K7vu77vO77vn/t+we/B5T9931dc+f5FwXdt7GISaYf0J3LAhPelqBl+lzgEh42Ajd6GB0DI7MEcowcRjAABDSxTIFlk9Kx0NuvMZuHMW8HzbHR6PxOwZ/oh3/fZzLCYvQxnrznmFouLRTmNDC4ZC0lho26+qmIAQ3V5cqlOlBqQKXVgpfQq1rlSyqIqAKOhsqp4ijJRHwI+EIID7Mi/BxiheyDoHgaHNb+W/VdNj3ik31NMboop7UCYjlKAVGWN0xTATg2kc1It7f6i9lFDQfVJASsyPKzYQBfu5QZjXTI3GB2MXdnGotHDLkqe+g+FCBBTIU9zsVAsyPG6yHhvuvAMK1m8CWwXi0V90ajSvDSt/MWYKgblfNAnX8gHrTH3POYCgh5VwTG5WKY0vuM1DcVjb0fqVR89L8Q68y6PPa9sEE9fguP5mhQ8u8Wl8jx16XkW9UZWfV24IEi9nygQcA19D0iRKpN+31EExf6bPYDXfgO92u+/Auz7yua2319Cv9+AUb8/5qbYX5M2hl0QBCYfwgy/S4y+YQdj3juiCj3yVxnBmj2I5zcaDb9x1s6InLdGw2k084nTWPYaT4DfyFo2shYn06K4BYO0ss5rMKvFIF0Nr1abzGuFdo6ftdoIIoDIJu9oWvPDCoAlCsrAMEtSmKGHBsAGWjnWkDUnnwOCdM5wKSlSNzwNh5ZhVoXWsG+SEdbdx5SHw80v6cJ9y+OxkNT9s+SOMcau2wW+uw937mlkKNhuExi5KkZcF15cqWgjsMrAgvoZsiiSd6HANwGCHgCBQdaYex7GOV4vYw3ggizWanWZb/d9tYPtatUC3NXTy1TbVsFfTWBWesx6XX0zrF4Pqya0hEfrF6ROQPK1Lcy2Dw4bfkoXyqcif8kaShGEtgHOROBJhhDBqCPy6Rc0UTnSpGsnCyE7TBJJlgdQSRIAAcAecEZJkiT9t2T+liRv4KVJBP0DifVra9D3IBc3sBGy82D0QEDA66E7rOWX06Bt8xVqIKmKstwTJX9IhvylVk31DqsJslE3JksZ5muNUlQUCrXgTPL00bBmGXiTVPaTyQxeJ93qpHXB/sdkcj6Z7PaTidCZTCYX15NJaFCTwcUEVhRiUgTABEjeRw7YCDCGFsCDYi9rgGpED6MAPYPDWvbgghT7mmaVx9DRrNhwVs6alWewGZXLtW25HGGVyxeFsusG2ievvDaUz3MFf7lmyJYjAMlc+/o6YcXYo7a5tu/pnpIF/vX1FrDR2+B/un4FeLl2RpivL3J11D5XuzQ3WxCYgOZCrQEeC8mVmeMB84hqlIHkWrNHc7GkabmmdfN+0UzOY1S52bhtXpw2J9prM/bfI12GAy04aTbjAHrNLrjN5s9fzL7RaA57APJUEahBH5C0Upnx6bwSdSqlcqVS8Srjb5VKE6lUvo8rb4CqVMqVSqVcUceVyt2cTqlSrFS+ArdeNGREp0sRABMUCLh5gBk+xICDbgMtdMUeYxXw0GWO1yNT9uCCFPt1hjs6Zz/uk3ztc0MpYGZnfY9gd9+DeMlYAXf36v6+fGE4/5LrYijKvvqPMBnacgqujwqxLu2nmq3ZF/Y8xHeha8OYmm0XbfsBKNi2XbCHUHA0u/5sn57aM4NT+ak3CxIAmCgQYAgN8IBUo0sccgPITgvQNQFGAD3MczyIDGtAE+fnc3I5gfS5/vZ8tTdYL9qu/PxsPW8yrp7bwXNW+lwOtXHp+fl5/HzIt7Rl4UJVjhb1okoiL9ID18UuQ8uSczRuZdmVUrFEeC5FB8fnAawmBIrqFzkXuagDczB1pSSiZl0whahYsKAeFKtLUM8Qbd+cbSrp9nILve3hsL2FDbutNcD8AHvYujdbf7t9wzzf/nzbxoC9XQNqsxwBShUIMAToeywE1AwgDsGAPc63Ro/oZeH10B2MrjQXtn15abce7SGU/7QXfRs1s23btk40x3Y48QxdW9n2IUfZNpSVfVrWrPhXM+IsCkXGFrC6O33AnkJwd7VM74rxnX6pQXrnoU8URtPV3b5yd4A7Bzzg+e5+c/cG/JoSIwg5kwka7hAaAAtJyQxNO8xt8kEP5hi1KjisAQ0xXrftOUW7YgNJGFyGXUPtryDrWzgFfD+jaWnlsJqn5oAThv8UrAKqTzUsSxLEsxzHcQuG8ZkVb4HzKAtuoOXsMoj1V8zr+A6uisSncXyiYksYAZO6UysOJKxgCA36gKTv2JDjnRHAXEDA6xFhENBEOnQKnc7VpqNdtDsn4b9JtZPMO53rTudcdZ4MjSkUohKBu/ELMdIGSf2/lO/XiXx/9i9oWtRO0Pu+f3oKMBr7awBXqCE0wAMBNYMuMfqHVaHnGQS8nsHh12N3l2INptNvGb0fcDGdTivTV8NnYeq+S+pTNZ0mL9OFtpheLPCn0+ajaUV3TI6TC/XUU+oPC92w6CgVAR2lKjBU1omo4qVSPtwpda70YkEVlCopdXGuVMHCLalbsOomsOS4LjNRIOQSjF0IwWHDDnsMLQhAoTsjgB4gIEAP3fnlNA8H7zC2Di+WIawfDs5hZhncA4SHwxsbOBxugcPhDeRg1g6Hw1frcEi1Q/RLikWKUvpD3sRQayAhi7boIyAEuBALfkhB5FRE6rxT/SESg+cQ3YgUZG966lwhmlAGBdZyuT8sGw368HlL5g97eYANu+UOnO/LKz5SLZeX4EHZAwfjypknKtIA7hAMSFYMNxrYQIv2hwBiiMjhcooQ/+/CHec4qSB1w9B1a8AX91vfzTi5cN0z9+qD3D8vXfsdnReMEeL/C+4FeIOUwyDYD1rbwS3wfYAMBgOfsaIyGLQGg4E/HWxaAzUYDGYfgNQHF7fYX7g9Hwy+pU25SYqUfzWhDJCwgiE00CUF8CFG3wh60KId8KA+gjleD2K0GqAu4VpFEtXXwuMIucKq1cca9fKy7tzWH02nIczrtWvatbr6R73ibesndeOnev24rg2sen9morYFupKiDOs3GM6Seg1q0IfYpl6eUVB06vX6Z4LjsP51jL6o2yf1vePXT1oAV5/qrwK3HvQ4TSRqE4nlrJx6vCBkJrKCrAUpzPAhBhxgh20KAPasYaT1YC4gaBG0whyWKIKaaoNB5+wzljfYwu1g8NMZIKN86WBQ0dwHbThown4wGAx24WBwZtoNGtBeR8sTO0jz4K5Grh2COyRTQD27JyGfXNfWgO+ua7v3mJ/dO2DuujZ+0XXP0COwKgnfqkhTBkXC+2bQJYYbcrbI6wARwFxAsloN5jwmzutyqj0urceMz6Xl8sXwY7k8fMRXge1yufyhrbYsL4dZ+swteonyUhjgtCAHHqWzFPG1hSBSlLNzEZELkdeWJSJy25KZYS+8NyzJmcOxqk6tUvspon6fKpkoeFvAEBqHw+EwtdLD4eHgXh8Oh8PwcFhdbg8pBC3ahq31LuY4nUN9JaxaIUwwXU4wGBekqBlADDeAgJ3rI+d4QAzeU4QtadSeFNLJdX4iqnCWq22p/lIVS+rqXxTV7jtUmk/C3d1q99QiAR4bhufp4GIyvehkxNPpdHo3nTan1nQarv4lS717G0XaYJqcCRhcjB4LAUUGDro9BmgH/5IIthPn1apIds2Ub/VT31Uw9htd33f8FxLfDbVG6+NOfH+ROqOPOO/o5ExYdH5y6IQmu7OYt2EGXS5LnU6nE3Wa5O9cdzrLfF+rnUKn0/lQkTeIhwJWZHoshIw45EP3Ak4+meMBVRI1OfO97FaGcxH7Yy2OnfjHu5SFH8e1CRTcXEUvdoCZ2lh50uARljEuwy8eC2CowvCclvWe9lW4+BImgCrlKthhjL6dXAnmBpgU0CXmXYDCOMolc8xire8Mt3d3UyoXhu9N6N55dr7unXNxd3d7d3fXecddYfzLernKA7TYAigU7SeAtX3fsRthvpZ9/snegtN9tq1iHrtO5gMHSBNMr5aL3vfI9LvE76END7AXcEZ5cr8nXrTtu9vvpl28Df3tbQ6vpm23W14n26frLNn+0gpq9+q5p3JWZmFiJv/8W25yBC1OfIw7KRayzkSuciQf6CHL1wsXZlevBn1yQDV47r7mitzn51d06TwfDC+l52fJAf1lCUJu3RBy4+RqA8rgQNUw573yWJN1+9jWojP7UnKsbduCil0o2Lt3DG27mq9u58ro/cQh1vlToTGEBuHC9O3+PoDovla6765MzfsrjHJ/r5J7a8bk/r5VvM9lsMsAcWCSD8+UfeOwEVOLtok1zggieoDwjjmPifJ6NBpVmYwr5XIOVQncXI1/VDY3/vsq8lQplCs/wBnm0iqlCQImE0jsKxg343OoNZsqF2EzbNZh14xbzdIog2KXKnp5nG9qeoFUrABqDYAF792wgzG0IMhyRhlzyTVy4Ney5eUl5evrrPr1XQ7LyXLa19c+NK+tW4O6vpbP1z+A2vUHTGxJlADJKlQPb7QtfwGrgLSz/HH5OzAu24W38v0YbsrnV4ZiuXx8ju5hHZez5uWzv8tl91eTM0GBgAs0wMsBMeCA7LDHAO3AIMAoY07OKiMHZC9KRWHposJsO0kEVvWMrpVPTSYX2mTiT8qW4WKA1LTqkrk9yfBkUl/B5kaUAHRok76SU2AIt2rpsWgozVHqDnCgeMmxBS11fGyQtfrT0j4pdRaguoaTojprAPvrd5LFZKJATND3WJBqmQ7IDhto0Q4ycNB7MAfEEFXB0bhWkA02tSPLNGsOaZJUTSSS4y3ZvG0SpSWxm9wmySb5ltijJKklPS8ho5/UkiRRSXK5WXa1IIrykYUWl6QD1OS8IKUqnFhZsGGHreEW5ULkULvg2IYHOTkVqSJtoIcncnYMsudaUaIwsVer3QoXnvzVwWN0vlpZ89Vr1pfH6UreVq+t1UqteqvVStYrG72xBbVC70Gy+uzweD7j5n7SAGKoQd8DSVHgZyE77DFBi3aAcY1j6Hlk96DKyGEtoHUI43vQcdxT1w2hf+9uJOVachUdtzQmWLjfPXcJlC9dy1CMs+wKUuf01H0VmD5Rks9nNA/PhyngQg36EJ+lw+ViWLrPErDHBEB9+ACcN4end5r71fRz6EC0HYYWCNC5Qx85lNNAkeRDQIHf/QjQZA0jreeZ5ngQVRlhcjlFllItBQq1WtV0XqtdQOEix2utlKVqtcrY1K+dF97TFMphJR7X4scJckKyUYD7ekNBzSSgwFKNdcYOe95oGh5gz7YxG9ErNUrHjVdt1Thrc3bZ2Epj+6WaTOqcIshpoEBWuO+iS5yHTAM4I6oRPY+5Bl6PqMrIAQFcgc6a/cf7/tMHtc52TPv9BtDoP8DAhrN+vz+mt+7n6Dslbs6yOj6WY69P1J+eW1nBEPK8eN65Fxk2ge3dQgDVorcEyo5nAd+8h7FndQ2qSNT3fsTeqzYzrAmiKGNFwvtm0CU2AbahHWBc4wAReCAGekQwgrUGlilJ82wBK6S5WCwWP4HnuaaiRWK4E3i65sdiEcpicb5YLG4175HGBi4XpkWjsVgsFuvt4hdDmrGC2MIdkp1yYnEsmDdFkd5KzkXOXOwAeJFPIkWRGagQEQU9oirARROsGnXyh5LcCQi4wzRHKqQe5nRjpdhQTtNWmj6QpuSeA8zTtJs2Qm1lAS6WKckYE9SyYIZvcoCdBrQBBfIB0CNCX8sv6NIfygVKzYBIYKpORZM61BWNc6WUmn2ErZRSJfXJpWwbTgVc7eEzJVGup6itLOrofZifzWA+cwez2Yqb59nsdAZj9N3s4MxmF7PsR4DZrIsHNGaz2Wwt42IxyymKMMuYRX3WghTAB0JuHGCXFfAACMYIPE3XjGv2aIjW9HPN/MtrCHzDre83DX3fj3L54dp/AHr+FMr/dCJBTaR81OSRC24Au9vtVqDf3UI4gVm3GwCNbld1davaXb10uxeUH8C5QivmjxcI749hh7kNKBCMEXjoAl4PquAAezQ4RZaRBy7TMx7dWM7jxItQXrwwXAth3MzoxrEbxXEUG6M4jmI/juOzOI6iuJvlhCLSKEokgmeDvkfdScNjl8xa6Ie5nSHvtMMwPEe3PoWhAIk9sU6ehFwLUvJvyP2g3jMHxECVTM2V5r/1yOPcXBVukOgmZ67azc/1TV7/5ubg3Nycxzf61xzL206Q5b87b6aq0FfO05nj1GfkvHQcx/G1iuKdVgQCMnfuyXkwQmFOkeV/kJhq0PdAgFwbgLHW5t1eBl6ePbjCtHdsxPAc0HwxWJtNubfRhY1sNvZ4Y282H5BsNiUoPaGa+Tr6bizItvetAZPn8ClAaqDA/4Qrcl6QfXwphQspikzeZYtIQaQgUlBwJ1IUEQs6FEE3Owfd2pHsdvW3XdveLWBX2u0OXWq7XS+Bn4/ob7s3wy7n1W4H7PQ91HY72e1+IkwU7xUu0KDvASmA30V3QHaGFm3DHnDQezDH3AMYAfKLChxNVSgcA9gN8Du2XrLtkm3SQzo4urJtu2TrS3Bs29C1bdv+DNL+tfSYYHuM1du4nIzjl3FwPj4ACkrBWF/CemwMd4VrurqmdKW8jZ94dw9gBL3xF3AnTBghRICcR8IKhtCgDwuT30V3QHbYQAbvPWucj0P2lJoy3PERKctahkHKKggaWE1NBUHwdxD4kcEKgtFb8PdlEDhlgnISPOQK9IZWDwL78x7dsqr079989fuhPutRoacBysJVq9JqtlpnQ6TVWkxbLZ/sSusAFF3ynrZaC0O/9e5mq9qKMiZMzWTSTubkiooN/bQFeAAJK1ygQR8Wwjs3gD3OJeAYeh7ZPXQH2ANYkIEu6CmF6nDvwo/2lUVnkq/SPvDa/rZvx15mNjput6/a+rNH2DaL5o2BNFuZzUagNpvtAv3DWvN4n+x6DdMne9wHPwUYontktv1APw3KgQvb4JNlRSzLCllJMcg+CdaYx0EQBF8xaqBaVqZodcFidR6PnHLKMD+8CZWmQcGH+F10hw07GAO0MQr/aoXeCsgw4Nj1r2dHzcPDi8l6uP0BEnNd3XVdt2OBdfXgGhoP5mme24f+v4f35SFjZtIPvak8hSbcK/WnStipq2ZN0wCsE6WiH+rTqVJKfSN3G1ylfl7Jh3kNw4lL9VIVq4yHaheWoE073A/6vaEMioQVNLPu2/AACB8+cgzqgaANAWObHRto41i/pPtrw9N+9u/xujce3mXt9/bVfr/f9/ZGxb7chrf9yNpj7ZcYDT029EOoCA/SHsmPjpTknLJexhLLMJNxnkf5zLvHIgXRixZeT8Yw6oheFDk7FynKuiTSBKNB8WFv9PE6uVq3YbJfJ7t71DyPpXO+k671BuHauGO97mGv14dknTtYrwX26/V6tHZ7BOv11eU6+wmC9bq0BuaocZ9ABa5hokBW0OwRxjiDLsANbGSHPSaAdoBxDVAFPBB0r0dE/jYEADs2GA3+s/t7p/XoFBzHsZzSRBFdHMdxlMOmKNhfHCk6J5ZjVE4TTgzDqDOMOkO3lDMbOLnFcRoQOcpRxuRv/TH1TvO/Mrkc9ZaH0elodDmBH6PSSUkiu9FoAjJqF7qcVUcje+R8hceRXhyNLltXe7MbjWyAm5H5C8CdRfdzuzUY8od+r1Fmokhkhd4AD88ikS6E4AA77DF6AIqP9XqY15jb2hiQDZcp/phkV88F5tWJonq2QqrVTgNVqcYM0O2Y0UXCarVSrVbDasWp6pVq9bSa2SlXrVarZ60Mt2oOq9VC9QU49WLn+qJXKnqPJdEGvH9G0XEZdxudnkVWFKUqU6nKDHUX0VmU00X/HkUK43N0mkqlWqCQAvC20SO0o2hLzma0m0bRccBlvugN99DkGlDACndI7iJ0+cCA7BF6GFQMPSIY8d6xzY6NTzbcddffj45+O/r96Ojot6Ojo9+Pfvv9KPfOu+76+9EH/naU/fuRvtOuu+60q/7b70e/HR39fvTe3387+o+j/9h1oC/+1ggAVlA4IO4QAAAQTACdASqgAMQAPjEWiEKiISEXqjWIIAMEsbd+PkyqcF9Pnt+T823mPtn+E5Q+1ONb21Z3P+H6t/MO56HmX/cD1b/+j69/QA/bvrivQd8uv2XP7X/zvStzTP+q/RL5Y/7Dwn8m3xjQVyD+f/1Pml9iMcHJ35Hagrwu0RtMNYaUz/yfGVoB/y7ze9I7NVSrS/n/TgtGNmrIHTgFTfwiDTx29ulhw6DScA/9ps3zfS3F50qJx0J4feeTVw/0KjtgHtANNi8o38wdypFvZOVUtdApfH6c2YdEbgP6MfHx720VdxbTqPjsyEbqvGj5mhdzQkxk2LhJKqeKxvvcXJZQWcO1sYGLQeJ1qXNdNYTD2LVKFPxja8S/PKPYbftySGUIDs5WRs5jrgGCXsDqdPLmSFrnPYxkghhsE/aDtHaXxTV87D/Be6hY6OHBd84ChTL+THRJh0lL48pvyrtG572I4c2ZRq3M8a+z6rXoei5gZ82r3QO0Fp8oL0QAB8+jd36HxwVpGKTad5GPucGMOli4Uksu5X7JvKavXzPmu3bH6qWWifagFDZcCETojsVpl+2VwkIZv9S9+/qpUdL80d/oXBQ2+Czmp4VDlbyMTxlfFfQ9KU03MhDWgun+eDDPL8r3M7aW4DqQ1vdrG7IUE0/M27yr9nhxZwjBvNMwqCPrCGkl94uTYz6xf1Z49HdgpesdKvIenTh3fn+tearIx0AEBqS5SqyBb1Hemi6+flGliBbh6Vscz8A/pWJskDV9oWJvAev9DCqUMp3ONRz6/SDpEBPxIO/u5UxiHim0ub4NvTvP6pVivpGJ7P2lgAD+/+ONAG//huAnuvQOp+mlVvpLtMKW564nqoyH/vU0lvIF9EsR0+dDwR1QPz+73gr8Kr+D0bpdedfdyQt0uNcp4DMyqBFr3y7qJP/G6MK2d4CCbx0WLSRrEIEzi/As3kuhyed3iH/GmFE4PGBEP9xs+H89afDJlVptf9la5xo4/2GzJjBv/VVf/bo2F8lAy3nbGTgS0nGR5QW37fYR9bKGcCZQ8Zy01y67naQR/x/MB4jcJfK7+l7b5HYhNGX/s69kxNiJpC+H8NPpa0yezlz2wuJ0HRa7oC2XuuNUphN6OC0yQjGGoAXAxcasuH4/pfrjVOa+hFSIhHXJIX2DDHIKXAFxccZQ3F02/J2LLWqKKW+9UcbTW+9UkIGtqFRmnQNvcW605xgiiXDJ2EeULaUvZ4S4znsW3tjMbp1MIJE6x+6QTITmTnXTyYfLAvrnI4fZhVvgYVncQNJRBbJ++1TUDwmCb4b4z0IRkQq7JUA0MjONFlaAhcaJySGfvSmAfQEQsOmgGx6ruGgJTSPo7rDTibHB5FfOAhHbKGDTUu4A4Pf/4r2ghogcWqKtsPjF9WqkfuGP1zwT71Wp2EQaPB3cvWuSXhDjsGbpTuzLDdhPNaQIdcNx4uexUDE0xcWJkQVD5iiwi12TBAygF/6lFDE8Ge953K2XK1PV35dbG0f+YWxdcmOpS8FBZK/Gd8IW3v3G0kfSzvo43wQFn6dnv84SWyPhb4xZXxrryj7tBc4yshagp7LO3PcLjSvqZ02s2NrqVUzxf6IGEGms18h9Afx5QEDqJXbvK72uz5n5SBLuBCHGpGJAyOiQcZp4x+lC6RXZehdQbZDZxlZsZuAFeleDWTWQFWAGaE/1jnkWRhklLy5Gir0zBC2ftfyHCQO25U/oUY8eLHe+kwFhbZuzeUGDE+K59hleHzO6269uzowLiv20WePvp0FvKrQRirZ82OXLBd4Av9noyLTjwUlGF0Il7xUWFKlKu3BbKKJ+w9azH6FBos4MJQAQOuzk14nDTRmIsZLiArmwwUE7oKppAe7Vq4sJ03DWFy/h40R9DsSzLZSC48zkZRAV2gWVElQMJD/O6p+J0S2mSHa2RzrZ5cSMjxxSyGxgYTjDsCoEpnC079htlnqUbTIer6RNj5SPABVjzUGLEKtqcO1DJK5cmDpbAjOA09KfbUy3ZlTu8wI7ns7gNS9/qI6rToU2JrAzKiIyVoVni1pfmP3ObjZB8XNk7LwBVflUVVqaTEa6q5sPFZQ/TJ5vuxyjvkeWLlxWQ8M5RIxyFcwujd98nrDfhmH55dqNHQAKf63dBxAp6t9tHZ5b1PD3SgpJYq98vcF8QoMCoHjAZZNezKgU35ZIE8zf2SJC+pIpQv14iOYHC0CWVwlHi8DOvbJVYMoo68PqnuNjV7DO2i4RK1/QHZzX2Sq8/qfdHhViu+4Iq43SC8bSMVpJyOVNfmT3j3u6CEovIzwd7Wm7vIxL8sRPHi6J33pl38NzqsdsXTtAC47WymhvdhhN7EPeqUghNGm76JNE6Bo7Nx5eqkawnuLD6id7148AIV0+Vs+4ICKybUiR0+zUPsPwCRAcEycjZHF5w1NdXKDeReJdQy0ziiG3PqwQONNwRi3l9hopZkKe6YH8q3oUQUaqPmSEIcEvoGUzzQSqo+ukwzC5AKg9KMtdgYLPcXnMUGNVLy4krtBLQcSU0vtAJVNjwPhdmgTy579hSH/ea/vCzsmbN+Y6hQiaM0tHwmNJlqJylJGmg9sGGYQD3Qaa2lhVfm2z9YR4krcVF4p9aduyHDQ0Fo3tr05Xs61urqVDSyzZPDl7Zvrc6JhxcJQTXf+HOEdVuNvlVMWxP8nPtvoh2PPdEDjO7uhiNlMqi8sbdD0Dmh0A3cmvX/Kp9jdJXYUqDoH6UEmSdKuAPIzNCLpzyJG9kaQuhYKhg7T+yyjSLx2LRdYPCK3rVX2bQaFchtDVmSmcHIVupWV9dlKe+UJ2ZG2UXno04vEiX8Kx3ssYFwOUpm3qComvglwq3g1wnK/NmsxPgG6ZcRNMr7UFSdRbOjih+EGGKh8A9WY1ELFFYce4xGsBFFfDSQwYE3AEcymUCdEAC2T8kVzsyDm4a6X6ud7v+8BiOGDPsZ3YyNAEqnzWTFLnLp+VX6fqn1z+/BQrRh3FawWRDrNj7ZvGDA7MPiHzdS0anOxa7ecAMYUTbPh7/QgNjq3Nl3rxX1iwwQEFC4LyQIUGjWwvBMmIX2ZdWn/8HJjdtNRx/8AH0keCU0LLtrC3675bVSdeThlTWkBQHuB3MyrMgbDC5YciBlVBe8Tp/cpW6oLFNl2AS+Ba6lVG/sv/xJYOmYkm00hiUzbgSVf6YsMsdX6ZMB0rmhrPBFZNf6qVAwJN1w5G5xqF+Z07UMw/+HaWTxD9avy0joLYVZCpScmeEcQY5zBXmrXMreZwtuCHgylVPEBJlqMsXIdVSdWO3eYhtt3rtObGueyUa7NcQSRFSi8Q5dgpmJ/1kZaksPiU8++jGYfUtEdEuvFwr9QV3BkeM3gm2JnCG+VZ4xXIjGW59oEkfanj7HxDWTZULuoxFSwwWMxDdyARKS+ge0CRSsNDdUjBl/ZarZ/oYcg83vpk7dYijFOShrBUqYjzeDyF7qZ/d9uXtI9W7rGXCOnZLGx1vtCtno5MvjRpZ8tc1sxt3iQ0KQrbu9QuWbJpS2AWVCtSFFlcOHKXvtDSjoqLyEeDKcuL8l+B3Eo6B7miJr4FePMyUkfuUuBmEqjW2nwNgH3ew66XsttGaLDstIipQPPbxNd83EWeom3uAuNMwePI4LyyKg6Bz33TGUYwub6OHJr27dj2dhtr91IqqA2FvaiHDmnb1+JCYBh1OkrC2wjmTvLlFxT6rnjhvn2wRbu9u7sIz4smJVOaukzJsLkVa405PR5hjeFEkXG78NwE0LI/JaLrqqxqyfMkBo8Vtsp46FH8jQw7cG4kasUqQJ5IRbs4ZqlJbujBNoHeg+binVj04TVHEazjhOqEwp60YlvXah5lEyie7WNIrgfrSv5zjZCLttGF4QOyOx8+EnAWnk6nYIy67Ik+AkzjTEwLt2o/yL/FIweIJ2eAzg41Nd38tkzF88DXU81FEW//IiGI0IwAeqzUNZkHSiyyFxSr+yK5792lt/ytlR2kwhcFdoCfvjMoHa/sccn2jqP3O30Vcctb9IjrWsj93xBTn/QJ3AMXJQmOu5hF1gZoi5Pka3Ah52nyKMYmd570StHEhEPm/hQdtlAGzV0pi4v/ttE6QzmfQDeEC7E/i7Ey572zQWITfOdov5o39at9lowv2OwVKqHAAw3yDfEK0jllmfTrV9TVeGwlGjKBmaU1eszLN54JjOe3evPIqqAvJLlTCWxtOHgN+a8XCBgybHqwDct8B+2ALbD2Lq6Jl+lhuo2Idhd+piNBIdywcrxOIVYUdXLRrJuuMAFYtVO8E1k90cnfRazAwYYm2SYchWbs/XpUaPjWoUE1yY5gzD3UZ9Ntum51i3p8ji+MWFoE1E45Upr7eNRjQXr1KWT29MHhBeOm9ey67x0qVdWq1L+ObWl0AFOCzLzRUWPk4QbG8n4VAdQiekOLMD28SRW9VjP9eyUZv9JXK0LvzEERwloL9asxwk+/A6V6ueZYd8I9THNgr3ThJxBr7nf+ClFJA8jn5pL4GVGer9jMmVQQOd8r/PehR6D25hUHQLR1vD4JMOz6ZwKqRxA1xthpWAe1hqeI5jeEQOLpFDjlCa6GXMiP2ms6sV4WAw+19KvlSEN0Tj26MTelf0E53RZC8tiLtdupM+lt4bbQ3QKnbaEEUNoFYrL1XuF/90y3gOQwW+NMduYSud9cdoWC3JAsRcZ8BOX4clKX2WocdsOstB3hF2qscJ7GGpx3wengbfjDAznvIhO9oMLYRlIEHNrpPScSxu5bZkMM82KQcpJztm0G90rlVCmpUNRq3ugbXnrIPFUvbWCiXedoSvu4WgDrTNuEL9rAxXDs9e3vnLUyweeBgxn3HKGP/7kXsoPIVvSe5KAK/4zr4aCba5MkMZ0IqRLG+JOLS4XGkIEKd1lWnyWDl/X8y0pkxWUv3azjrpiZuSIylgc6UDu+k3JlPMcYlLUGIvuLdkO7ewPBJxQ/jnAIUvQPbWL8ugsC4ghig9s5jz7xtg/cWLUeFQv5D+C6I46NrVY2ZSC/Jo58KEmtRT1raQ7IK5C3lN6+Ol3MOrYb9+d+fi4M6JAECZsIShZ+ZyyNTzMBHkOEqN+3sH+NrdrWTVLxtjy724mTBEu947IdzZSLyFgNgS0VV6OY7Xtpnc0V3UPpNbtJPn7Ga0l7Em6ax3SKuG2G8SzejKJxVqdEWvgM1SqKjW9GPODDdbfpqptiswJkXPkErHYIQCn+69f6bsVrrIGbxXo6m8pmFlNtv3xsDrX8k7gSLc+W4NIRWakm9T9y9Dqg81zyq6lrhVxQyFPL8oVZml4hi8EzVe05KoH4cAwavEQtneBdObmfw2sw6KHEh804OwVtKiwtac3mg1hZjJC/n2hEGSnVVtEoo4XJ0fM01W92lyB+yTu0OCk8SWNjxJQNcNWF2EGAz5sOrQnByeWuiBr2P/6lkBwzsDC6se0Cg+k6huCPRDhpHp/yf6moigzce7N2CKokOl6hXvvknxmk1o7l4d2PvI+8WPodeiD2nw5oA7SH5ZjULziDCRSkhOHs7LEyrnVAQdHpYx5Uy85GyOoQS8zTaJAu/6QswsrPVlxTeWDMLMby+zas8zh7GswMa1t3/sX6W1vGY9O8kCzlm3iIH0hJwugNhir1YjBz6jKLnpKblj3T/cWjHn3MEz7Eh5vMPkHMtpZcGFFrMzr9q+UIEgWSTJTTHl35eUf2BUdJUEtxOzbmcIWuErD9rqinrfrwm4jRzPPA/Ce62t7NNoiKmCeqNHQFAhks7cQhVTlSU3P/zRwoq1KBAAAAAAAAAA==",
	toad: "data:image/webp;base64,UklGRmgkAABXRUJQVlA4WAoAAAAQAAAAnwAAuwAAQUxQSNsUAAABDAVtGzkJf9g3fwCIiAngxy6ooDs6KT+hSmZFAIKtZsUpDrHihv1TqAiNa6nh/582bjSGMjOMMR0zMzOm42vG4DEz85aOmVdmPMgin2+uz/fUBasUtcs9PSi5XJXb34v4nCz6X18NImICNGv7H0uNLe3x2dO6jRrVDXTzcyvV99O+anTG1c5qdLpMIAIIWH8tgQhEIjoZJxYkmQg2mFQ4jB0CDJhvIK0FzsoLiIgJYP/7/5+v92m5o4PEDkjJiFRU7+Ydg13i8avj8fj18fjV8esHckyzq5Mzg0QB+l3WDLUAPAAB4CIA4KHqNQV5M9ts8TrYSgH1alvYjqBKCvCqVCqtlKpuZrbV8n5SG9Aojaq/D8rsX4B/oVFbQPqL8sTm4qJl690u9nP4wEPwwFUo8dJ++f2nh+Dp+VIsdtihsVgb8gwgYC0QKRV1pwCRl0oTiDcjW/7HYud9RYgR+f3bH7ta73PmiWmQjuP8WO6cSpoZaL20oD8DW1p/odPJ7z9Rn+ozOhWw2LImrrXeOI+yKGCpOvr+DYGeCvAADrhjycL1ifQvkKG3zEEIgM5UbetZx9jULnU5/ueCyA5wqRfndW4GyhIA5vGcXy8mykGHUL7x2nvvUTqiAPf+EN74NZqGsvXOD07gyvopgHeObB4yAa+B5RQgAmTAUw1kjAMBC4Bnqdq6rl1vwVbwg/XwbjnIlQX49z/BVnjmNNwWR+F+LbAs4TLtFtODzf4JNDWqrew3oNXq7pVScwAF+E8wXkOpAdVzNdlVamGgFveTCgvNdQA+NYxdCYJUZIE7Tcq3oAHcFjtF2eOPf/zjf3/OO085f/E18F8ow0oEF0122pWsBDjIhBoQizIWIIIBRU9ViZJ6waDm2qzMrZtxrxtjPECtfWhY8r1Bg8YIMDPDfXgrhTHGLC9UNgf3ZmFGU9b4dwjpdQmYuihgO67dHVXP+8M7jO18zjnnnFNR6nn+gXvgzm0DBA63HUD73U6BwHBe2FJvA/46pzUZBoCjn6Gn5+/+4Y+UQpmIuJrXVFXusrZmkHsiLfGxdhH3aFdqJtJccX56GjeBm0Nw8Ssx3lViHMXac9yEvekk5hc0vkXGZi5zUGNXcKamkUOqZh2YiQxFROBYRJZEBiKiQYGBuN/AieQ++JaK++qAA3lOP8BE6KES3XvpKz0/tnSmtFWkMUSZABznHis+pMJQYQkg0UfTO/Zx9NSAygCRVCA9TmRUJtyQ07b4YQOGC7XGwqm11sCRjdxYu2Bb29gJ0KoeI1O4tdqJWPsWQL17LCVvh10IOAPB2qnGbghwb+3QqpMbO25IRAC7eW7Lps/wxl4DRKoZQgwF40BSPwVeg6Y7Cli6MnUNqFxEAdtL4kRCAvnI4exl01X4vFXbS18F2pSea6mtfd4CRRrvpa+rx9ysAV/T3jhQaY+QkhQfitxQafZ7oIErqa7DfoMFamyLyBg59AXjdWQ3y8mpzJjKd2Pw8jnPdifj3vl1m3cxxkPIcTKNcb9X70T7K0x3K6UGXQMiYOHw5k/RAZg+o9NQwFG1IBFeDwsSvxECv0fN20pzxMb5N3hwbtu57X3EOTcGdYK76vXRTWDj/L1rBp6XosXep2oh8UrXxhxRn5kAKPAAvRJAIhn1t7b93TukoPNbOJCOSPktwBnAYIQ+EICdnJuUn2ymuYWnnB6/wXPegfTYcZBDF9kW53nznhhDYW0Mhy1YEOCtkl2QuT4XSu13wFipR8CsF2rSgzmlVrc/qZU1Yu4WMNQtJ+1DCMsgIRxJ6PHCsxCeATZCCG24XwswC5vXT2EH3CCE2ZbM3E2JgUiJCIaq5rUd5KIeyOCIkgASEQeUQZMceOsNTPwd0Hr/Olf+E+x4733T8dUPR8QrC3v+kXu/3OD0rhTd6aVGrx5FABWm+gy03nzZYQOQAXQHtPNEkhYFh1oP/tbam1GUsBakggpU/cuEV8EVWEAAgxa0KJRSI+IKqhoCGVzFQgJczQO6yBgHQpGowKCnOUz64kJ/JuqrHvon2JhrtV7UZaO1mtP6ChqtdQL2GoZas7NV2Vas2dqUl4n55K+uLID1hlJB8J5Swc+rvpwCypd3dB74XwA+eb/k/XTP+3nvDxoA809sSYoDSUUidnnqCoyjtLyip+pAwAJEHKEnknG3kEshXBY74VdiKCen4RZCWIOVEEJTOQ/BtS9ofmEjeJiFcP0hvAvVWZGVx5FhKBiI28tqNFSz/QZO1eOuULpFpTaAU/UJ4EzNpJ86eK+u+KJGSqnlht7TOT48hw7V3nH8kPK6Ia8CJicFPOas6T5+ACz0esw57wDkNue8kisPt4Uytyv1dQsqAONAEhaSUGYATX95BU09A0RSRWIFEgDo2F8yK4N7M4bxIrBvnrgwRpt+xy1cGtOumFBr/sZUtgzKmMi9eQvt8cwMjb21qixn0Fkk3Ol5rnHqO+eWj0A7N91xbnuVl3907og917K07b4ycyOhqsBM3Xse3HjiPgLu2vMcmeM9cywF/xhwRElYS+kAFV4BsCQizpAJdBcOSFhL6QxQARwCBt8fF39ajlEL8KcYY7xVDzE2r5DjV2KMifPFyx6fQpxVYn6NjdmDtDvYX5HjX0QWwJ5I3hWArIBDya+MlIq+GX6RGxIUN7JoEJEakDxPOzLyEQTWbjheBe5Tbj7w6pXU9rmN6R4O0zH8kJ6JfEwpUw2CZUHwUScCjKtgSQIYMuEbZfoqMAAJIBFx9BUAlGZ/2Wb7/UFtw6YTa+3YPrU7r5ettfap15mpfbG+YseCsZ2OmxpvaXYwMhhwQ8CydkpVARe2MK+ZkQNKW/xqJ3s209OctPHyHnopiigVpI+meHB9wEEvmECcktlh19ZngqpiaT+CHKfN11s9XKtyzjUMd2s/DGvXcgWwimJfMCC7CXsiGVg3yD6oMXAh1wpQ+2Y7fdJpwNzFPwG/trC8x/sEjaUsDkURb97EVaG6GZ+XY/xRxRjHbC2eA+Ckdtr4AIyjtICAM0D47QlYW4OsAA0aIBd1b2q0wZt7C+vOTWBj6b2bXjs7739bQYhLzq0M3Mc+6gROFIxd9WlthlmV9rw2xlA2QwHIa1u/oZFhvyEKyAKpT+MBD4rqm9r4pgKOziRUCL8hlTFUsP3QvxM1KoDerNlM13N+A+BKKV4kxw/AZo7S5zGX4TFnVa0O2U0bfzo3T10HzWFldRc8oIEf5RvJQJQ+VRHA0g6bYnUgdAYAHvZh2pZyBXx4AM5HJOAsBL8cglwSNoCJD+/OXu3yXThVOayqcFlDYuFXTkPneghh9hi/hz4+FIAIWFtxgAKvqSow7tW0B5UxjmoPFP3jTOd+H4b8qGCp8Y/K++1t75fWCPMegm8PdvzaJ3/1Cq33fimwtrTrl09qUz/tOPdl10jH6aYPM0KQO/2dYs3CfAvrA62HWut5fckXraE5fMlUnwEahn+tMHTL4kRfUf9JdwtgHwISFhLgAAJowFMaQF4SKDUERS8EXIemt06sRQQLxB5lDQeSarHIXZ5ApneHekmKaR3SDEf6oqKveiV9yRet50Hu9FEPPSdaa83csh7opt9h09Xsoed1/Ru99nSCNaK61AUq/hNw3tZgze/4iQPt/ZL33q8Xb8ytnyXv51e98jv9iH7155r3fuT9LV+9+FUvxgZ5qONBEzhAha7SOHrGIhPwGrTn5RFnKh7QEMggpdvnC+GWLYB5DjyE17ho+jwEvxV8OKUdhDD45RUegrsJbyan4XYjhCmshwAfrNut35sr+HpTQquU2j5VMi99HpUaqNX9DlBD1Silhuug6dZKKbVJ6U5VMxpg1ikDMO5r3dg5WJ8OAEjApiYDdznnR7jNKT/B8Sj31HSru64IYHNh13KWwM4X+JLzu8ec7RQBdYjgqHhAQ1BgAAFrebl/ASQAAyqABg1BAfTrEq8NG49hx5inNWMOwPxNQxgZcwEct+zt9WtaYGIuXkf/zRY0xpzB0lv45CztGMuGIZQ745kbOYcsu+Z757bfsu82qN4559xXZu5kywG0py97O+c2V+BQcNvOnQFxRk4mUPWgwDginREgE+hWL3OGrMADLISS0PO9PJrL2n208Zik45685CH+aGLl03GxG6tvY4x6heNPP8VyHSHs/rKQBZElkZV96ldyzYPIoiwvdEzl/FgeADVGyu0siyLDXcpm/0Z+0TI6DHAkCN3MryTBmBci4CDT6QFSGqe0lKoZTJNS+gB3ibKNSEpRJgXNGz6upryyy3SVcLX0KhJY58JlcHQLOEAF0HQbiKQKEWdAgdddjMiQtSVwe/ap16ZFRrb0wNDasbV2PLZLCx339rL4Yj2wNrYTbe3o96jN2MXX9mbN0QyAz9ZaW1EgDeXAWrtEt3xn7QXsbBjeHtDacUXgYAHUZ3v6u8PYWAtEMECgWuu0gPRAg4agwDggUQo4AyrA79CgNk2IKa2m3Hwo0sjCbew3O+xxl/ic0lOT0v1DupCT9AMcZ1j/BCsfenzdiY5r/wsiCgwry1TtolzzIEd9iD0ORQ4BRTn8K8GeyOruVLahWQa1KJyXcv48I/TPqW7G3MR4D+Cx8Rx533UR97quGhjFGBtIMe4KWMvFcDeaGLMCP4uAqKt7iyDIBHwtkMF1JXp6QFM1jkglScRBRQMIIEnJ3/lH7Xplcxw4FJBt946vbmfq3gNHQ/fQdeYOuu7c9bYrhgNnFo2bQh4496lxXo1A4gBK/vCHxeFmoYeNMX9jzA4EQBnTmDF7C8DMlHrZHIDZKbLRDcX896YZClyYds6YtXlQORkxRuu1xAIVQFMWQCRhLRApFXg6M4aKtSQBDBnwGkCQ82f/IeSd4jnv5Nzrtkn56SlXNekR7hRZAyrlJ7htUjYmxwewaxngTgC2qcOJYY+XwqmCXaVW1lFqUU12VflhsaVbK5lXSs2BU2ppWQE0f72svtskWaUuTtUXQEbK9GuNDtQ8xOW6mhDehXC7EcLUg6LcGoSeAgrYCGF6G04BZsEu7AQVws7oIYQQ3rx7F44AZaMZvfvAA1mBB3QPSPQuAO2pOpCEhSSRUgVKyyGojzDTvFmB0MDZgffn0KjX8geh0pww9pucLvnHxR+Lnfe3PoDwRxDU8dspNixswJ6mDFr7ba31qtbbtTOt/1prvUe5cQDtFpEEFgQ401+AptGwniGIsZQNKtCtAEfV1gwoQFeCAtwLDFUNEozgfeDZZAK+8JSGFxog1DzUkBoRBxnwv1NXfWstjqD1JvBFn73kTH9ZF60brbVovQBc6UlxoT+Pld4G7S71UqNhPUPO3/u/kZOh7yiP/I6fvAScoaeiNItT7723y+CAReUPQPiTTjyxDy3XRBz0CoB5WeZlUQALUlPgAZYAkpT8/YMnYijkXei8f42t8CppF8bhw1IIqyGEFfilAdZ6mQ2q6bjsf8B+g9oiK/rPjV9gWFVKrYxUsbZRWVTLENTKQDO/BQrMXyv8aYNP32QMuIqGFuMAAQxJXqC38jNwn3N+gDtNBnyb4WsOVONDzE8QV0N2JufVnHcUSk0DuELlpBY7EdAZbo+sXoAjAhYQcNQ04OmMAhaQiINMwAMgAFPB9rCPdsn3RsJ9a8wxoM3Lrk3zvTHamE9Hxlzvmydg6F9toDBm0UwAlRNte46yraX2sPe+1KrdORWlnpdqKN82bI5fAu3cHsDGOWCAmTvhJQ/uoCYj95VAaS3w1jW4SM/BzMkrz+mo0T8CSViqDjIvj6QC6QhUeyVKiWDIXRAU4IgCf67PX1wWcdzjONr40ke+xnK0G6uXleaqIm3cHb7piLGJvewH4C7Gmzfx52y2gxa7Pfv/lkQGK7LRI28vyxWvK1ORMd36SsqBRgYzOQV+GMm5oTm8lqvaYBs4l7i/IqdAZx326hOkDSYrYDvuU2522fr8Ok1Kqa3dpTTaonOylFJ7A1wk0ySaD2x9BknppE182uBw5TltamIABqL0MVT16/TWoOmOJLCUDjIBNOCBjAEkYfUY6Ic0Jzf2uvjVTrQ11tqlDWu3T621xr72UQ+xNpOsrx0IdvOzPS2m9nxz3eriix2lNWh3+WS51V0e219JVCMHQgY8sCBA5hsWZ9buAdzYDW+/AOzZp3YHX0BQ9zVoJmpwIqSpYBz0cfTQ/BYU3RZSAZnQB0wNV4Pjg63puiB9BJlUmpTcOMFJeuwida/1OUnlakpp1jFJv64xSSmlltQGpqup+LBSW0kpVWpwLOdTFUqhbPansn0sD7alrPW0PWxLqemb5ORUZgAGVJKLI5FDkHn4XiMLwBTeqeiOzG5GtDTdw83isQZmMS7FF7a1WYz6IZZLV1zG6iOJ9lcS8F5AgZ/FuBSjXTxnpY27wxhjRbZD0THm5yPgDBlA8+oGCFQ9gWokga04ahrwQMZQtWOZjtEO3Pr5ezfV7us30s7N+9qBe9enOepx2jJadB3uGljf4OgrnTYN7C2aT0fCjqK6Y8o1U51xb7rnzdOaMUYbY4aIXjdmh5ERMzDmE9DsAxfmQAM/mzXdUo5bGKtTBKwFAUf/QDWS6JsBNOBBZXBE+hpKX0BQuVJqYiqwk58lZ3NPfACre6icn2u3uZo6su/yTS6j5DIBNuekOt7kZ5XRubo+XIvB04G1MchMnQV1C4xHSs0LopQpkWdQtzV4p9QcgG9mTAUgHqpyvVtuTgXMisVmzrqB0arSwLZS47FajGgEDPy0vMu5onoTnmU9HE0D8h6HzmcCSJCZKsgqIUMINtQn1aCyAeDV0krJIIDKGGB0gtWDGSFRwFI3ZAJo8rd05kIDC5BQeLENQEJYQPeR9P/PBjEBczH1046J/1okn5ec1ra99wfeH3jhC+GLWflViWlCiEg/K8YHltNv9Rhggiu91AjbumcIWmuNGVb0BV1v+dY2FIAoupnTkaT1p3oYAI4oYOmpAqUFPfPDOCIJxuqVuhx9RZG5AG/CZ3RG0BfFRF/95jYlum9KJOKJRKJ/oiRxNSHXuyHlrliZs1isAVDvi1y/MlpWiGqnkGlGfYsQDrg5gAfAlMi1EN0FOrPmOMTNTEe9CXApM1LK8oy8JhaLHRqLfmgstkszNenl5FvJd5PJl5LJ55OhzyeTfdgO497qOvZPvQBWUDggZg8AAJBCAJ0BKqAAvAA+MRaIQqIhIRZqrYAgAwSxt26v4YgAifWeaVY/9RuYFgeUX0N5y/9N6qfMN53fmV/b71hfTL/bfUW/qX+q61v0FvLs9l/++/9TCPP6H+Jf6geW/+u8K/J78tlBeCua/8P42uVny11C/aW9vgC3dtMTO0f7Hlg1DznpIM/EgkBMy1ICZk0UAFfcmzBI+FQ9vonhpVR+001ZcLlMPeCkN53ADx8s3iQCK9H+wwO7fGvMZvzQ4QGbexTIoDOWCrPQjPsjvpqlY+V4tU1eKiOE9eo7loXDpyjR8//biVKQXneY00NJB5RnvrzXRurb1FffvQ5Qn32j14904KqmIYPvU6eb++I7MJ1slbBb0VpRtfl3wkRlkYT/ioaxKil3YePgaMmH4JDtZQpxN8mzF2/FKiYGNVcmxK9fL4nxshVYbNprbYpdVLyknXeiOJQUWtUMh7OtTIVWlM4jchFdXkGA28p069Kk0NbamOsaFJcOa4SO9pnN8eVMXeoU1hfrk1RbeuEzW1BOoZQ2PagHWwptkSEMVAwzdQGz9rE5jUVlt43TrC9OvDODygAmza8Qe/WZBJRF2M9JvVISRUKCRar5rWS0HyXVQ7YkP506LpPZaLCtv079slC9U5JOP60cByvOhs75o8TRMDff0XYL4MxsJq5hqi0q7S0reNiyvCNQ1WYJuj32+9UDwP2DIamBDP5S3KLLjgAA/v8NZAAS/yT5Zh8uwlMiEf8WFXYpDbJzliJ1gCX3c2p3c7zLMxUYFPOOjxhfsqJuMu3s3LMwl8jld1PC5z5rk2y6kv6qY7fX9g6EF8NbvhEv30T8iHziLSLSjBmpoayz+AwQhBvrgk4d2FC3te5MLsrO3F/9PV1v2XxClcPyMP3/Gh979xJw9Le5rDVNqQA3E8OwWMpzYQw+nKsi/oMxSFsMUXOpQyXVGJZKum4WvEZpzXQNj2Nxh3HiVvysTJAP/wDlsV+w4m3jPrrN/UHmH3LLgGFKCUsm5Vi7wHwqdJDDl1d/lH/r+p/NOrR/8lhWLlO30lJUn2Y+EFQvjWCNIdN1vPLddyoLJLnl5ANJKdSJz28IknX2dWv7DOXNaOE16s0qWGmooXfamVJVMd1wud+ZgfR75DSUpwXaFqx9VAMfM1q+F0AenFniGZnqEHaPIe/6373YB3DOKy5krDMu4EFms8PwRJtw15x15evSCRIcCs1+mskNVvgizcEdnQ3E7Yso4nyXK3wuqKHFZ1VXU+/gx2AVWUNgJclwGvUsFkiwoQx1r1TCD8E4Cn79d/yxii32s/Me+7KW1BfR2Y5IWKs5e3cW5su6iDS/sy7ECAgl8SlET57ZUUcW1ddEw1rXBhbrLyZJxeAs1AH81dnDJjnHShG4+5KBY5fra1L1Hll80RXMCpN/r71nbiG/CGNv1zC07CCQKfqgH5rT/PR9aS5vwCzLiUSTbHJpMTbVMFrS2vLVKJR4Jk6AtOsrlqPBPhSZARWKzuKEEkDO4ou3nXdDYtCnTbO5PACusKbbP/L4f9MeDP+f96ugPIBZ9ov/ydf3nv5pKRCjDjC9NKbGzlsVtw/5m2FUPl0VUd//+cjh7R6LHd9bY6bQSb05ZppDTEmxMUQljAaGTCmpgpfqXxiPDUZdFD0u4fgAt6FvdsSh0/CFHIJCYTgNW1/YQhsCqG+l+qtmxGih1PINSGbyT937+Tfu1piQO+Fdb9CbjBzNHNueIAWqaxzGDy/H5aBvr6Uw5UeNqHJOWsJNQs2bckvl+4gRnrApje6qlYj7FNwOI0HJgrDp/E/8H69pLpJo1r+2d+x0L3vn87LoHWS6pxv8tgpBvyXB9dMjOITVp/bAwt2fFmfTbQdPlnu+EfBtHfP/3c+4Pcsi76Sn+v7QsG2TuThhQ+aU/vtp7cOFPOT4oR2syesuZxO5wmeyLtfY5KqUJ/duke/vxq0IGvuf1Bg6LHeaNm5pAtWKdFXtm/IAkmaQqsKVW/3sOrMoMwMXMWPPxez/Jl4i6JaQ7B1/ecTlH6c1O01glyOqAzSKLyQ32d1is5G+vszmxDo25EYjpggxawBraTYPWkZGET6tHMTef38LshCZRdu9N21hRvxkDnEyKt+A17KTPDq8CC3x60fvxlDHUeCDUZHIzI7F+5n0ZQh1El6MedtWRJzZaDZdT7/Tq4hnMslAaZ+KQU8ajSkOZAfMneLcUj41wtY0BvaiZHzhLBE9kHOlaUKNnHxyJmSMJhgLcD0yHWkNNLX1eAczQu/9S3PV7VWom6s34UIHRXYk1IxHF4x4OdNYPq6SlPtPJ/hOIU9HFltDm/HLX73DSv4Y9Hi+0owSLTZXjWeVy6r7TINQV7ynLkhecjkS4DhUB/tQfzlp9vDrGe6+mE33ksbr0104AlgAjHpBiYwQblF2lmJUjHFd/QENXjuPPk+dJQSypqUvh2vW0lZtV4aI7dCUgXDaedkD+wVAuNq0eSTc5gXWKP8vkLquLY5x2/Is8spF5vS+cThmB5p+Z/eXLOheT0EqzZUpgEQR0FP2VXWYBeRkw8glKn49MrzJs6wrZl80tCfg+Wawc4+mdRCcrHIJjmPCjY1bn3FrkuoAUlVkQ24XtJvnSogjc0KKrdmoGpteyLtefLTpjf8cOnY5L4yFOPycixsy2PZNFGg0C7lCe60L6NOcnSe8BUB+r3f4J3iRU/weU0HwuIkP58BGeAH49ZSPLXnBatv2pRNCFaAS3F5ZMpXa3nlLV6v8f9GuKVsnvgid1XfemYosdkJk64kDqi6RMzsywLxBYY7TUw5e3qSbxV/hrdtHkQ/Lc6aMxNJmLH/YyIEVUo4szgXLaSLWPwKJM8kUXjqduboMfMNWoH//kZg+eQrYQZm9BZVovSfHUjVjpXAxL6njbi70gC65zisTqmYIca6VO0PHE6N4ChkKxdccp1jC2pQQW+eF7IPFd2wAc4OKXQSinkZYd2yMdBbvBoftzOBh7FppbkW7uKoNfQOB496KnVqJsob2SXdj6P6RC3Vaay8x88NKDox7Hq8sQNEmLlUzdNFxjqJDjUCGzYqZ1qdpT+5pzfr2T9jZzOzg3aH6/qFxoxK6PHtqhCf8+bUwD7X3lO26J9WFNyMMBhkPIpDbcUtwIIZcp/ERSYu/rUmVNQsCm4/nTaclQZDT2kyBSw4sVPVuN3zZKDde1Z+Hld9sGHHjlGeeH4gFKg+q8iwUvqQkwNnMg7nUpvT0WyRzUJlB7aLxgs0UnuHVKyJ8exuUFVgcRLHNGz3iuSplM+etA+Xl+tbOgQ56vE3rgp9DYIuso/Warb50SrnSm9mG3+BGySPeHoNXr5HRZD38IF+30W0cEkwB7w55AsoZUgR1ijD7pe+9nhhSxwLcqk9s3gfMNLunihupT8eD9Tv7F/BvWeX/4+EIAPkdrVzhWsRJngv14jnmkdUFkDnNCmq4ASHuR1mRPztnPgjpsL0l5CqRld1I1TMb6uHXuk/gwLAg5ibJ/aO4PL5P2DeD0s8z58MdcInWhbh/h2qbHk81Irtwi6mZpS7WP5dMXP7ZUvGq76a3SAOxEZ/zUEM3t/b1AtFO2cWxwF8vYB3rC/GG7ZP1+SO7+SJLA7UARx1qqvIO3A0E9DA2sFXyALzt3EVhhhthfVL1u9WuSdnS86cpiTKJO+i5eB9Q6Rd/c8c0N/gMNAn8BbGuHK8znwbazS0UAYWPsx3kkjp8kXFQOYxzWUvr7UibfpYepYLDIWKH6a/lhO0xuDPG6epIpUS9111W8akAgmG7E8HGX2k5Q8STGmcgZ4Y8pxr30IUlQF31Y1alkT/2ufzJslTqp9hys8k+NFiDO5hma4p+9oIQzpgOsbD+AIkEdzz7YNUguQJHEgVPKy7UoSxUNRnonFVnMRHl5UgE/taHvIs6+jNazEgX2pPi5vH1mkmtjNajqyqMAbK0T3kbFNnkzezHhnzfp9iaa/J098iUyYunucVvDkSGEqTrXSZzXD+5fg3nsq35tNz7vSQ/3Ew65IPXZp445AFYZlqSWrodU6OfaEEprQYnGG6igWKGK9uoslUssApiAWvVHabcoPw9ZGFmAAAIb64z2QITH9iRihs5NtjRHRktaNI+OkcFjjaRiHXI1FwVa95UqejuYYRGU8PTE/6on5ldEzgrjHTdIq/o+bLasSHDt1XXqi+HYPDiLq1vjp7NshYRpr15ydfSGyzON62SvF+M+pJAZp4aOR1jTJVrl6juIy8oeCm0RnX0qCkIwi+jE50y4QQEzdfCRFrtWhFh7bLINXUx8cxEoqVBMBD915RQSQus+VpHcJ52lly4cPlN/iIX4ci1BjxjxGhrGxsi3Ci78Sxop64uOVumFvxaY93Y9Ekvib2OZ4dWbnztFzMV3GTwUycrePXzEYG+TbPaMWbhjdERtOajjS4U3tHC5pmeCPbeY42MOTNH6bo5QpPnp0SKwvB/MHQysFNuuFE68DAwbuG3NIH+6jbivIIR13raT4e7AT3+J1v3NDdS0S/799EKYElssvPRGJrKwoGSWmiLJMQiAosfcTkqYTObF9Tg+Fl6qogY9Lk4Uws/X1hTXpRFhH9j8Lu74dpP56vDfVYHdovfdUcMJ96fWe/PBpeytV7DZUQzcgs2ayxCtvJbocQUjKcfJyyS2CFcBJJKz1lyhVHmtqFGgwatQ0FvR9gTtPp7dFctYTBC8Q0ctzoaC0JFPQm5vC8uBp0B5f9sZiRqHDc9QMGfnjQP7wN1gZ0fLNVrAOP1FzJC4BKavAVRReE2nt9f17kKlDQR51LB8XZOUxvxcBXe7BG1bs8ai+B76VI3RMOT8VLTyqnQz1EbUa+W5XBexueWYejGkwH1lWKMycqWOOPZlUw3qN8ADin5L2f4SsFt2SMPwbHjaqpyGejt3Ff9z20+q1+RmmiLgn7VShVSiRXVbt9LVKjBdHsybBA9aycMlufoWUMO0FQoCnaRSTlgzq/CQ4f67f6tYFgk7USGb72Owf/qzUkaiegb/mF+ItgWqAyC01BAJiujc6L03nEEMV3olIF1/4Sa0JmexDQzIULkOb6T8H6F0HUvUU5ZCiwVQ8Dnd63CnwUcv9Lc7+tvzpvH+8t1ML/l1X7o8Qu6zXhqSsrspZLAXTc9cPrCG/Ob1IsRDE1DR70nrB0ggXe6gcDnFrW8MsbhH3NBawVpAHP2HI5PD75KSpWao/KP7DXA0qVsBHXjznW62PKCPxQDlAcdDmqK+AY5QANRM94QMgqy9xUAHIEAAA==",
	snake: "data:image/webp;base64,UklGRhYnAABXRUJQVlA4WAoAAAAQAAAAnwAA2QAAQUxQSIQXAAABDAVtGzkJf9g3fwCIiAngg+rEyNCy5Xe4Bw7wiHnPDZv3aOEKe2QM0s7T1KD/X9s2/9UdMy9lhndjptyYmZmZmZlzN2bGMjet0zmzwDDXoaLiZU49L0o9bb6Gb8XPC8uF0+/fl1tETIAmatvdNpKk6u7xfjtndrP23s9+Vr2dpfez9t6svJ+l97acDOWIey+8SJGCQAjBYFKCEAEFghFUMAIMSAgF9S7uBaiqydxHxASo//2/9XiUM04/Q2+69ibfK27yvfKmLVrFgfq5kDy+Fr5JtrB+wmbH+pLujtWbdr1ahc/Q9aluvo5T2hSl7MbMYWyYCH0K/GkYb+hlm+2TlK6OsjmummaoNQJdNU2TZs23evl9mGuepb2kc+YHrdz0LwyRfHy2aymlXAOpWrPaNOebZqb5/V01Mj3WSouubyVURVHcau9d9Kpwa5qJuG4TpF13f+3kdE4ACay0AUbJeorEKHuANvab0hbDxF9vJV90Er5v/cCH1ck27Qw7C14mE0HX6ySZ3SVv0ZIkSQ6SRCTJQLCJZwzRxEd5gJjOIeBjXAEM0Eu2rtLC9nb7JokougN1HLm70Wg3blFR1Hw3/dIw7G+j0A8OQ9ULvV4Q+kF4HIY3QB4axy3Dv/6d8Msgf57Ep5A0YoU9Z4BRYpy1LP7xd8FfeJm5baPM+NHgHmfj9zTLGxbX2akhem9qMvPXu5fy/dEfgjK9UkuMkVLKUrs/VHcz9Yhx9xRuVF8ppRw6On0l3yc6BLQqICLxQdI6GINHCbDsshDIV1htZ7Wpqr5o1aiGL5UxqR6/Vue1war0M7iQVdWvpDv42YdzIf6f0GKM5xb6uZjQHh4JIcRhT5wIYe0LMQVHiEMfMeTZo0Tb4fa+uq4R911qC2NUnzcttcLo1nVdV4/gYPxaL4CHRXsJFTXknWgh8U0rbJMHsBEdXHThLtSXllz1laYGpnO1u2MILTXvJFPYsdpGyrpVsF/260MLTAufsq8hTBHBcZ4vyY9e5FUn2OT+da6rPLfg2SFy/TwZbQHEwTb4FJJGgL3FEn0ELrpREOsf/Ltg3RZ4EJfBYgs38HuBewip1MSPA2G3WSdBcIn94+DXRI1Qv+L3nYcAk4sx5AQQg5938+EkHtvAPI4v4isP/yiOL07j+AVHgulFHEigINTvBkMl6ILaSmKcwxg8SgkCmDGEqYtRsCAunqU426qK9y7i+CKOL+KmjOOdAdTx6jK+uOY0jpcsWZw4TaLD/zLnFjII7B68kC1DBVQtY2FaBSM6iyrQLSiCFcarJZoCEUYBipacTgktbClod2nVQJH7XZ5yF1Se51Kb914gzjrdXbacvjcV85fJl6MChFIGUBACjlIe1qBW1lv12uCcqCfW6sowRbdqo7x2qQaIAbbxARrAhoGhlGwApxMGxJskW/TBqutwU08My7qu5ZTwoq7ruoCVAJnW3oALVT9Jqrqjqut+3Veb7+tLyWT3hNgX/X2LwbHoKWKQ++IRUJno2QAF9HsW9lwc/Fgc9kR1JJ4A3glhw0sh9jDCBjTJxGm1USDeVZ+mOGfVWVU9qQrAuqxC9NmnqmFVqTlE1Qau+hhn1dcRusBXKsgUUKOAmBhyqAGVYSoksMKeA6RQyhaG33on/zWVtXxVJ4ZQarYSqI/qhwIulegrNVip73uGRJ30lRqCfaJu36hbEH1lzTVkUr8bt2R4kG0A6xWlm2UiG70D1tnxK/pedu+jiwTrtRYISkCAc51l15l/nS0Bo5jLLZCJEBQVQE4QQ0Cu0FVGGJGYWMFcgw7AiKmLbgBNQvlhOOXU1cLScNYLG20dHh2F1mH4HnBsmIehhQjD+zAMf2CHhydhby88TLHDkBZbriiqgcMLyJlLpr0oOozOChCXHKjoZC96DRe7p9FiDmlkXTGRIAfRoRNZJ9ELWAB4ckEGiFoLIAYUtQAywojEp4AGsOfoHiXAEmfGcMT0u8Cx4M0k8R+SD6Z3Sf0mSYKM60nSP068veSJKnl/n1wAy8TwmEwmyWSSfIY0ScBbtsxMHSZUduY/Asr3Xd+/AG58xw9Qwi8hif2THX8zswH2fL0/5Tk9+DN5glRQYQwgBhRQQUYICRTQCPQBeimfC06Wyi2eOiwU0euiEBU8FsrX3lhcnxikq00Oio3JKYpvDG6N67oL3Uqhei6tysffkzkg7uUMwhs5AdunObXksZQHu3AtP45lyxDEGaQSA8hwslAZHWNiMICCEBIooGGFDYMxeABdcEEg2mnz1MEbN09BY6iaTdZsOgga1TThsIkftUZ0KppmdRRoXn2SSNdiCYz7QgjhvhFFQA7WfgUZwG5PFMC5EL1Dkb0WO57G+ESkJiUWgAFkOFkkSFarlVWvHsCpGNqkq1VtFXy+ZL1aDeXq5WoFICerRxiL1RPAciU+4a9WX13mqxXRTslyFlCjgBgCcowKQkjQG4wD9NKAMwOYuiwAPKH2vem3jbiw7fSdbQtbC4RtHdn+tT3ptmvbrye28sB3iA604Af2Auw6D5rtE+RRyu7JtiWyG+r5fD73gWp+u5rPZTWfD5BivoWaz1MPnPlcQRlq+TELwPAoJLKVIqUAKmrICYAAFFChRyTdGKOZHfSp2xaHk0Xy0oV0+tEdGOaDwdFgMMPfcbcIPNNyIPZNnwa3YA0Gn9RA2aTDDTSbQkHOAgHX9vhEklpQjh8OTg0vxxPDwDGBOh43QB4ADIGz8cIbE15M1pJOQQAxoEDQmhgaOnqUgKANFoDhEUey8/I+vUzTkzRdQ1hwcXlueJE6aRqmaWpXqa60l2maLDoM0m+7lYkFcxP1zIa1lwC33rvMa6g9z/NsC8v2loCn0L/xHAngzA3WGJSnxcyEBa+cIFGKHCCAHD0ARWsI+GyZom+EgRG4aHjEgbBA+1QMbIGr6r4sF3BZlnfEH7kpr7S7gNO7bhflF0N5Ynoov7HLBRQKfxH/vVCYIpBS6om33/40EfBRSgGZvJvKLzzIl0AuC1BSysmDlCfyqCflAFIpD4GlPJaydDmSEnrNefMhLJNS6pMAcvQAFLqitQDECuYMAA8kCGDGEHBZAHiQkexn/zbIzXNEm81mA2AtN/oInjYbwZcnsDcGZ0ML6xvk+t7v+8t/+X/RIs6ABzFdCuEihTgWQvQE+hj9UjwBO0L8qCcOD4Wx1nAg8ZFc3/ve9/7h+/cNcLp8DXx+xXoCj8sUXiyXy6Pl8gE++ctlRasDjs8U899FowPCoimlplNegAIigAKjDQPA6zSkA8QzGqi8/voWHzW9d64XjjOAxFmbLo6c27nj9Jy+49iO48gjp4RT1enNU6RTSn2fZ0VLy/27eDY7RR/OvphKfzYTMJidvWUDkM3WgNuhuaVS6fBC8oCo6FiYbGCMLk0w3CLDyVrY//RTPiA4OOtyvjMc7gyHbzq8Hp56hkur2+LT99aCUuqcyN73v47eAKvRaDQ6k2CPRmcxTEdnM4DhkYGz0Wi/LTpd6fTvVSggAigw2nOA1NM2wjQCt40mrfzll9yGWz1Mo8tpvZpO96bp7nR6CvLF9LrDk2O18vdgIuDKdV335NKgQsSRewcM3CfPdcVHdwrR6njc8bla6UbRLg3MYUxKuzOj1dDQ1f5iITp8XiwEiCU0i4Vs6y/bej3wDthBK/VQiEkHYCCEhfGFWJs8W4sZRi9AQem15jltE5QmZloGPD1VWtiNeQvS4HR7WGn2aFdqgTAGpjsxN1i7iN0TcbgnemGjWUs7HpALur4/WizW6M5Cn54s3hzMFotz3AT1nudB4Q693ElN5wIQBsYApWQjlpgz4IHS7HXxr90Cp02cQeweK9c5bFto6uhO2tdTfX86tab6KVwfT99Dujc29GQykYznNekrIsEo0AeQegAbzA0Qx6tSmnozGl223QTawWh0tg/+aOS1WT83rNbVTA6Hw+GVifVwOBgmd8NPHkgQhssokXn8crOmVMa2cxiTdhtCJs4BSrfz27mcxbPZ9TZWBuNZ0JudHcIi+i5rbY013DuO4wjpOGN8x7ijHGcPa5dSAkttz4z9YunIojWMwKfAPIcxeJ2GDWTQUGOxuFy+gptl87hMm+UGsG4QK0OzfHm3XEqDWyw2mBRf0E0rQMVQACToYlyL7ysYicVcHI9AfBZCiGswwkZPlWZCfhuFHm/0+omNmm02Z5vE2WwEWBta46x8Uy8XUtZkbsQK5jAGDySw7OJVaelB9sGWsjBdSJjLfR+u5MdUPnEv5aGUplkTNnu1VF2hwC7L1ASsznHK8gtclmVRluXnGcsimWSh8PZADYlK66jZ6Ckg2QhwZgxHTAGBTv6uDWee13v0bjoMvQ1rL2+TKd4hTA688sw72PU+zj19/PLfHsDsKE0Vnftpmo4BsjSVafoekFOYkUncXjq4TPXx+4ghV2wrQaAPIMW81IboC4Fm1PU27jXDQxDjcQgnlkGF47E1vjNc/HisjYP/7GD+dvAWBlmHt4P3rwePzungDAbLQXY+eIDTo0+D8BjzyOas4ZqYDgQAtejggwRWAIMxQAkbAc6sZQE8rIVBTgyo5rfdvDcd8rkotKw3n81jnId53/5O+X1/mQA9Bxkazmx7gmbbkshCDDR3337izr74YM/mtm3ZC7Bv08G/pUtrCImhAWxgrJUSWMIM3WUBPKyJ9VD7JLZ6WMHHVdP2TW2QnwzO6mq16rhfvl/w1/83EMOVWJ2Ixy2AcwvdUALjE5GiK48F8Ol90v3cr0E0TTNuGo+5aFZNo/lNMzEJtumXmKcYonnp/hYo9BhQ1FQakDyXYBujINw//M9f5EmHl7Lmi7wAbuTEIC4NKoBLWYI4tgxXsu+Yet8/VLBdhs6O74vjEh4K7z3A/CNYJe99/CVURQPwWIzhraSE/NOHYg3vXHCK99p695YKuf40lQCVQwyBVgsgI4TEB4lxDpCiIcCBIeCiiwWcf6v1fP9m7U/aggNg7Zdz/+7W77/oduF7Nt5V5Tu+PwCUvwp9/+jBj1b/+zcK9Zv+GpVAFypZGy4Pk2SSJBPFLEn8SfJ0ewmvkkmSWEdJspdcJEMAkSSTAwYSDlKsGX9xrEwvVRsxsaEWFQpCSABJI1YAA0g9gA3tUxddLGAKYYn+gF2/jc4O2qb7UQl1EUXnbovf46J4jKIoCrtZzlbr6KjeHi7PHw7XUAlDIogscqgByjC4Cw/D0PphqBfrcCcMrR+FgR/6fhjKWRgG4dGPwwcId2Toh2Evmbr+IHF+nqxDADEdIIzQJbo9ZwCpRynZCHBmMAKXBcACF6ij5Rtp/lvBK4vqaAq32botk8Cr7NrGz7Ksl2XZJYuz7DrLrq+z6/3sen/C4rXBziZZhrjQ7JW0Vf+2pyz/fggKsS/UNzksVK+vji8gtIksOFc5IIGVsiz0G/V5pNThUimhrF1wEX2lzhbYlvqxZVkzrXsOF8UONQSoHGIIQAEVCojQDdgYPUpALGHGcKQhgAVMGQExeEOQ3/7p/LG6MfWnVWiY3muVSDtZFfeXLWuLVWX8+rXa8iuwpru7a5Ug4sBD7BhOj0XvUNx6Igd4EL0jcXAg3oA4BQEsRfZaCB9i8cRPeMOzRwix3R8iOq1rq8aq+TKr3TFjlxzqR2oF3qg+r+sCag38AXyt6y/8FD66gwxTIAIUFTUKAiAwiAoFROADNHT0QP404IoR7Cl1ojp5ytpVdaIMpXp1o+62yNRHiVRKxT+JDZZV+9Ghwes/Yh5wlr/Kc8NjPoRSgqIGw33uvyPK8/kK+JKbLw7yDSBuDeu881+05/P5fC7fCfcNDNxQ/DMw5AAx3SISH6ARwBwgRdeYGVx0gT4aMgPYIIGzb4+z4JGavWFbHriBo1nnLW7PQZ5p4yAIbILAhk+BfglhEPQC3fOCTxpBBnz4f79BhA9xoeB2jAKqeIY+uq1Q93FEy/iwik/Rp3EcC+BjHL8AmMZxfBjHLs+5jv/YeAlCUCAwxJhrUaEyaGsErSkdZwZA8MwpVAfqgciSJVYcz/Fyzgro+VDFM1MRxzspTGN5DX4cX8Rx7GrTOF621HEcx59/AtYUViWGBuj9tl8TAiB7FdR8DQY5wMGEYRA4c1AQWyTAaWAUgdl+aer4PPdBhH7PwQFySWJQQA2GOCAHhCHE0DrHXMqfipLWL4OyXWt4cb4HOMtHS5Df5Hlh+JxrH6YsRyzs/KHLl3wMhPnXLYLcOEHkeS5yvZfnefH/nzouAIKeegdqX6C/VTloVJAx2GXLAeDBSD118Gz0+ETtKnU7RBd0DswvRhqiEKASGGPoFkbPBJsOU4wCffQt8pc+1P17uKw3YV1b9eJLh7B+6uA9aFd13Zj8uo5skPW6ruv6Esb1k6F+BKZ17deXdV1/AVHX9YV20HYB+Qt9JHg2yoO+aGhTHvpIEB4JH5iJjxNhCeOBjfqBEEOsCJjBCCl09IUQLjOMEki18SqYv/JvLSvxVAUQPVaVRfukmqBXfSqRVuHXqpJVJWiPqspmXVXVcVVVcVUF1Qs6bqrqM3FVVQ+my6rq7h4XkA8CZAEQhaA6tNeiQmWEEfhsmUJJ52mXKQyZAcKUAowPyME+7Lra3hDm6n6Lc/VVfFLf99gJIVd3LW+VUspSOKrzsstSqUMllFoLiJVSlroKzgd5nfWB+yxCT5eGMsvuATd7EilHWXZ8CzB+b1gMoM4enOw66/62w0OWKV4vmAgys1yRGxsUVmMCCSaEIYAYvaZCQRhpSIMNjEk9Srq7HaYAMwfY0JpmvBTXHizCEqIwXIAbOuFrCO/CayAP9QJYhieXDMMwDO3QfOyHYRgaXoRhGFZFGIZhW+S8XYKVVW08RJGHOYeaKnoLIag5W6aYl9F5pFtR+7nNM1aroJZJ0qGzCWXAfzYctnX5NjnkY5+c3a1MzA9Qq3Fy6CbBNEkmSZIkXzrMeolxkBwlSSI73SRJIr411D3xZC2Q0LvQghmkktYb3/mB9A8EYh+zOzdEvu/v+kYb6fu+1Ul/4X8Crvz2T4LzFJg+UahVAhTtCkSFAqIWhGHAT+EMEBtaqwMVcd2FCVFd5FB8NKVFURTnd1y9nhnOi+KkKA4L47B4XbRuAFEUhbuNWxQzvyiOi5Y/sm+gTEgmRJBhVHAqAA6krLmX35dShk3ThiZTHkv5zUJ2fAIcKaXEPZb6sdT3pTzclTKkbKWSJkDPoQYUnQXYPO/URRc8b5CeWL169YoyXyRQN5u82cC526AatusvkNOmY91vGpk2zWnzZGi+fus8BbhGdiLOgVQIIQglFOLAB8Uz7J+I6VIIIQ6FOBbCimFHYR8KcSCEEDx3kB5cBS4kq4h2Besh8ZfVqq+t7G6C1vFqNauBp5W1WrlrtlyvO/V0dJwQILW9H1sEEAeggIotOwClBJboo21Gw04JqAzee3tHdhpZ7O3AiS1tZe/Y9p5t19h2xLbtqUHYenlk27ZjKO3WHVsv39j2rm3v2PbcWjufu6kieBCN5k0H4rktubGogcP5/DibzUBdtvwp+viQuXlN69ymNbe43p9jrsxm56lAbwRknQByDApCSl2ADoC0T8FkPb515TZ2Bks2mAWol+HAegZrMAgG3iBUW7Wnq9Ol/+bT+C9Lly0T7Q3WYA/CdKT9rLOODV7jPyD2xuKq23Jsj8cPfB6Xt+MLn3hDY2NDqrHRJo1ve2OZjf2jsbGhLvr9f7Isy9qxTqKfT1ZBLyEJhGSqW0Crot0EowMoZ7J+0wyINylRt8dwnOW2YZmm8j7tAxeplbcVASLqGI6TWu44TkNJxHFMx1m43PFdcMjGHnjIIQeOl6X/hFnAjffe9/oJ+Mo7gWjP2/O8tYlrz29K1CzGXZFI/N6TsM0J70yY8OGECV9M8H9TCf8+pVFIptAVBDEx5C0Z4SJI4ppggO0ozfotVfnmqLwqb/h4UfpNGcOiLEuxLsvw1/3aAQMHVgwcUDFwYMXAgRX76YkUWER/NiD39jNvv/38275Pvvn2208ozW8cBtCqtjLf/yNU2i8U6hcK9QuFQv22Nk6+Xf2HVVZQOCBsDwAAcEkAnQEqoADaAD4xFolDIiEhFhmtMCADBLG3bq+7DA+zdlNrn3vm28m9nvtCAHx75gfOfzHfDD1c+YN+sPTU8yH7oesd/s/2Z97v9m9Qr9uusv9BP9xvTf/cr4Uv7R/zf3B9qf//5qr+EH6AeV3+h8K/MH8wz/cnfYlhx4y99vyR1Anm9oRBALE1ATxnNLHMAPUyfMEXcIev1Si4vDJ4kLnoc9ls4DtSfUJ2qEal7U6UwO1h9ycz7THB7UHwGN3yvmv9zqO3B5F5BFOO/R1SuLQzUvqo0Fnqaz2NoqrY4UaeunBh+KJ1rrWGwGq3YvvMEU0hamV6aPmDz5Voj5c0m+hk7z+VB5HQIkzMGoX99b+CdorP6ND6TrJyOO7t/nd5rPSNGh3eTP9xvA1NnPAzhBEZ3yyd0AxDWf/0XOudUBufYev+p+q7SkanSefpylwPjMaNVthykra3+z7awh8WhA69EKCWGUzDoKx6z8Fc6Z9Q9Xaez0s268m8CuES7ZqoLQpFTpk59XUXV72nKFVt5AdbEa7eBfhfjVtzZH+c0+cuceQ6aD/2sNU6Kjs4DVbiK/mb4LpawMg7JAwPw77GmbrcYyfFI2BDf1rMv5xrJkYPqkjS9L7Nw9kZlF+7JpG35zfHIv2su5cO32B8vgswNTvnHj1rJLXuCwz0mp1yO7h9bLO3cdv+r5P1/SZdcN2dBpNbyeT26QcwqtEp3fRKxXU70UdamiCGj6dEaKp1l1uYuQq37wrF6ix08clfP76pakMy6ecJmnkWN39wiz5F9VfIiQAA/v7uqgArP4sRixj29U2oWKCr+Wt++Z7POTBjrPJLma56/s3OQ2CBr3wMeqMvArujbFNAYxgIjQxnRwyDpzwHSMRTq8dqHjBT4uTwBt0ld48b9rWPEvRV9H18Ztg/WX/6QBxtCJUJAYx4XX/5eHKYB4/tlHL+Kn7gq+wmZxh1yAzM6O2V2D6p6lZwwZTY6A8aJESiMPnCult17qWGeyn2f7DieESmknR8HXLfEbcPvEkL8to/mccSqzGFAXQe4t+1k3RImzMXx6+bbrIEPHolla3IvLoqMtv6Vj21lJeZ1f61jwDz5AuLfPj2SAM3qXWsEPhwIykHNOMPeywdU3ANTybYhQ19q8cpZFMmrs6Z6KlQMjYQbMcN3i1gV3yrYO5way9hDkLmSjY8vgX8Ai7QRznLQeu4B7s3+L+qudwXiJ/InTXfXHMU2/N1QXBkdHqlcimDa8Vljr7fuwtJbASnWm+XpKZ4uWvV3ETnrSGfsjHLm0DINtceRmwM+e5hv8J5nOibgCEDW+m1iu8a6siir7lg7PnHwb0fIQwvHKQQo2/sRv58r2+PBlWDzBtge3nj+93/mccRQt/fyAjrF1CbEd9alUmvngY1O5XsLKHA2gs/eu3e//blL2KXGBlaj+wdSTnVguATa+ttI2hHBylXSEF++XIUeO3VUSvFWzPcsF0HkbLiMQ880FNnmnzTtpyb4ObWQsJ5hSpzZMKn8+BNep1TnkMaC99Qz5V+iF6ceNF7TxlQQg1w4yLDZhu7LqFCHQ1QsRCypxN+1+WZhva/fOxwenblLh5FguV2gWWwXz28NBuNq8TJ42KpJ0eTDHOW2Uw0ST3Kk7lEsLW0ood93hctCEI4p1/2yYANJmMlMzcPOmQwF7/xNbD0R8S4Mx8gKXK9PnmEMbDxFBC/yeScTId3CUZb4/XNljCVn0CA7shrkH4wBnx+ctmEc47GIqk4Tlm07KIXVC6JgzsHTLxBl+L/zffMrLjGDgZBv7wUnLLXH+Z1yst4yyu70NqcUxRWrLdB3WjETHHRGhkm3t5fO4IVSaAjPHYJtQlhtR7ZaOayEm6rWKUL9AnuQxxnRx14BpvIx32Wg5inrmvuq3+sHN7HYUi4ukD+kgSrdzVTe+04Of2VDBx6V/yEjkWRglzaqpTV8hABYFXBIwbt/rQO+/1p+rbCSKMCxijP7BPIgGKmEHtvTAVN+PvkuF53AkEUhN7h+ywbFEW08NtO6cgMttzcn+kmtUxma7HZApbFocSjrq0Mn8wMFrdPxeBuoOW7ikUOrpIroNVtGfmfyP16SDDvY2/5FS1G00jwUPIiIMuj2HO/5wFjsMKjvUU8x9TgRxOZbuxsyRAqEEJGdUgMyKttGI0J33q9jCP8k+JqxMLipZHfRve0XqzgbR6mOmFCPwG/R/cJZekUWDnEermtTT7Ujjk2qoN4IbdX5+y3L151hDRVhSbzuaT7xr4uJnH9OZmc5hxCxd66AbJTQYjqAvP8KldRfcLD1y4p04QnkcGSNH5xm0VPg5ydPWCvtocGBypFZpUYGAXniJVK4Qm6sK86I5EFo0Jsw+22PpBSdypKuENLmki4Q6bnFlJ6k9HrdJRpiSTVreEp/8Lit28g+Kglg8QdDdDMaUR6N+iChc9nw8j/0iUbmHo4B9KMe+cdf8i9QRvgngKiSXZwAvAu3f+1OfLyv40MN1Y8EIuSWtxBYWwyi149Cq58gOEhhQq5LQq19j+WilenZ6tNA5sWey+YTrKrj+p11NlFiP8gBeCX0ldnPtUz/i9rnklW0FvVmLAAkUwxemk5EkkRBgRGpG4lYi5SFJ3eX8RLMVtHIZQ22RdkxgVPuYMBhzsEsBAge+ytbfSnYDLVs9o9Ro2YbRoaoY4a46w4yNXv14ltfGe3vjCSb6bB61/Sa0Umf0GQldM1Nj6zEF5oeidC2dKWjxzU5ZQLYEC8CUcvMWnZNQuXxNWjgNfvnl1j6vgNfUPqdTGHmN/C/j1AkfN/5LLP6osEDUQ424Fso2Tpat0MZmPvk56PbgQP8cB6vYPxtSeAqRhIqeqiLHyo5QfFZU6bAEOsd5HQxHsKhkWlxSLU+NeipsbaSsucCK5V0hQKGJZYKGkMf1Vs86yBNxce8+sw6JF8o/dkgqsoSJWp1q39qhq/2aaEJ4tSNdcSmDZhipcUuUPt+Fdt1Wyu1hDukhc2ccIo4CcZifXqe2JXsTAzqSdz5uBuAOE0TwVVyyqGYGH58D/4XB38hoi+mzZr8A9/wNwhaLWxP3FSfbUPPqzaSOUL9iSMB4zN0aFNy9YIqD7gyT/5PRnoGRDvrOInqdtO2e2UrB/bWr6bABwfxMqkWvcdZt9nno3VbDNfkW9BmY1uEIJ3B0W8W70oPYCayIJ0Rtl1MSq7R0ihSYRov4mwi9BJ/Jn6hyoZbI5yg0JLEDhrIZulIWiKCnO5UMNgGzROYXRRlmuJruAqkQZ98jrCKnCERSFrO0TO5np7sCns48rB9YAIoJLNHfmDRhTm1ZQMdKD6txsmeoTIJq5gWb21gVFDvkJqbtw+0z14lf87TLj+xWc3gGzFZmAtC9QpJHjQu1MzQB/250QVylX3IrYPV7mXimMtP/AQoXoL2vOzlV9Pm9wDo067/qgaO6sWJ0pslCz0RWnLWD85HIcWEIQP4OH7mzZjj/Ujmj9KK6KQoUn1DlJXN/l7HYJ0YkDW9VCqH7Z9A5k7bz3vEe2W0vYbTTt3V+Zd1bTItzC1zYf7z4O3G675qDb4o95tIVaZj7YQsU1lvHoIpi9sg9ADQVJcFyKy60v9yqbWuDLtlXQiyIKzFWUbUkNvW5JRltm+PXPqvDajQj4A7h9MUR/ekceeUAbcGjQaa1reA14+W9XLuAuMgLgmTWTC5VHIuLOwNO7oQ5JfrIK19zXBJpxkLnf7IVki7dILu8/RCB3Llq566XqkczYnaS4YML30Y7jHuLHeq0Y1T2QCSbKMfDoswR5Sjts4qXoxSksNjUdYBf3JeSjx07cEFwi6nc6ammvq393rmWSBwuxvsO6XfIdWHEaQ3PVAkBXuw1dprzI2r/BKCqtTm0TFuRQoHka0yzIG5dlk1wYYRsMlAyAsGIbCTTHmgwsKm6PNqLreTrU0buOnUf8dZJgmQ0oTerzHg/MzklCzOb+q6HiuvYnGB98FXvPSpnBC+03Fgo73lhtElx+KPjWCIrGoQrE/6dX9+b7pZgi5ifzOQtLqfe5gA7S9o2qZsFmklpb18wraX4j8kJyF4A38OqooR33A9zIQKmmIRoXhjBBP+rxcNPE5E0eabNMM8TUp8qbORI3ssnDJ8UTSP1r8trQPg5BLSHV7PO81NmVP2qZzXYZ74KYTeO9rU0UO2ZBjpZ8JKY2N1e9rhxWnL8IOPUiZ/BJxLi9jrsqBRmJpeS2+l14YRI/akmVWkN9RSNnmlgQ6ubnJ7NiQst2NPdqqggkdqmg5UrPd0vv1gKVAw/KrriPZEmPqpQxg68As1ybSl37akZNS0fsTP+CF/UE4pfUHSflAory64PcQkN/WX/TB4c48FuQM2+REAdakR6Gz5dV6wpCtr/XVMDuGPuh3E+Xo5QgrooVtLTDmaNruFzg3sab7jAbxGdXwPEsfu/OwJmwK6uH6gwa+eIQ6CwQohJu13m5rcapLlA9woRJv3f4StGp5VuPvbDVx/hdKf6Wx5Ez8j3KAKTCF1vIf0yhGIXwqqM8r1iQ5KwfJhDF50/PAg4zDJXoXFYYVp6LX3DiossRH9lKio39u+JbFgUxFx6YV210xDB2vARcunp7jxNfY5ruL4itt/n4eF1G//WaznKDPaqXXYLfprDlWW2GLQIAlXAP/rDLxkyy8VjRZwp8552EKELRYzm8UlMbi4TdmF709SuXJqXgTJTGP7BF1XFmX7l2Ol05K4L5seoOgOpHz0m05r0q7fVpKRVH+Jd3Cs+/1aIwljVWwLQv02T3utAxlQatIs2qsx4fAjCFov/QMWCmA8HVYlv8hwUn8/FW0h7wJsv9O5gfA4OE3IaH88wtztIaFyk5cQhZipJtrvr4QU3+dgVt0jtHYRfqBZqKnKRoxALEilDOFkdz6D43H3l/U9rCCHT0cRg8NgpjzHNxBYLMM23vkLsJH/XvgXq20r8HTPmNaVoNCzutziIyJiUrx4sHx+FmrG4sqor8znmZ7FWLYBi2/jqQwpFRdDGtuoJ6B8bQLBtWz8kNqHPla4q3jnfZnVnoUGfiwAg/g0/ONH18+V7bJkgZk3MiRlx9WJbk/XBRyGbDhar37HXDCwLj0N4Qqp7P+rnwWYCIiZvRWTX9xC3tH8pQi3VMWSZ4P75kVJq6YBTw9gePn6A+GpcmkkL3ST33sSQE7VVRSF2UGgcAxxZp3/TH9yNy4IUJRjgKBoEEUoXoeObtCj43WAPHxllfVyqhPbxjCzEPSwPFcFIb7FYv6P/NaXT+i3amAAAAAAAAA",
	pouch: "data:image/webp;base64,UklGRugiAABXRUJQVlA4WAoAAAAQAAAAnwAAuAAAQUxQSKkVAAABDAVt20gJf9r77wBExATwvraMZyz5Bc44Y42RfIsdqhYbjOQ9lPu0qO1f2zb/MvOYuQwaMzN5V8xMGm9lGDMzlpm5TpW0fwWUKotycpyBXFJJRavcf/Dku7Cs9CyfczWIiAnQLP+fJTWW9Bi9bJsX6Muud7Od3bzDPM99Vv0Ave5TOkpQXkji7+GZngSGJ8gpSR5IyM3S5FKWkCM4UI5SIH0XHpFQZnX2ETEB4v/6PvVUE+Zi/WldLy6+rynyX/7pX//1X//1//tjAKs1rUuT45kACJ0eEGtKfJ/f5A/5+2nO+b6rXgXV7zQJPjd+NQwj58iRMK/Yurxiw+dZ7u6X3njjjRnx+RJmvEmS55ZH2tj0xhsnZqeLr7zu6uuuWWY4DuRiw3K2Yq05OQV4Zdtiu+M4FQDw0snZqP1qU7nKL1oJADUWUKnUz5y4/wbuuykKkHlE6+xzBFCAiBKABwIgDpzwGCzIOv/VcXC5hd7jyn/j4Bxkfeu9udhCvHjv/av6+B//vvy3qbqi0yqlBm/OapgtQVYAjjOllFqCrHAAZzX/8W/Z5J//Z6JzoeeAawUOT4D6U1cDsJqZG3AG2t0F/Pv52eMf/m/2xX30FogHih9xRdkUi1gDlxLijxQN8eM+X+M9M048qXmWmEuTikCidJDo7ujWBFIjDpwAAXg4IjusZrFqQSYv448ibrCfelK1jXkZz9Texxg3V7FlHY0yv+K6LHDWNNxcz83eM31If0P/edUjw9EhC11VlBtjTmQJiuffS0/7DOyMgOEpwKErXL0FruNODX/ZUeoOO1JK7R0Cs8UAYOg6ueddFyf+jADfvD/R3hM0W17o4vrYNwpIKy+ANHDuh977a0DrQG0wgINUBBI4cGwrlE0i6KLB9QTKBsAlzGbWAPkHpPwTQk4mf3uE+V5U84/Z9/zILPMi5589p1ldTGx2PsITcORIDW+tvd5i8QVA/np0gpMja7+3VrBHdndBd2NegRl3surxhrIjaZi8dxqwIkWSDFFk7ACaAWUUiXa0LyKikGdDEekPJnXcI0C0I0dq62sLwt/s7xCADyNr7VELvHvRcW2tDIZ/s9a+e2/ne9Zap/Q5Tq2fBmDVRHnwOTU4CmgfHlrYTJeANOQ8m92Rc7bkUw4zgZnP8RBA2aucxiJdRtEBtkFroBHXkQgQSOAoEwECic7BzPa89y0nFlDnHF/r0BcjHF9fCOhxdeK/denKAycn/hsE/9Dlf85o1J8dAuzsjCbqYjaAhNAHF+oOu6/U/otpDZzOSMhvCmgScDqkfwGf1vdsRefhzODmu9rsPRscbvHJmBsI8HIO2DGlhtrMkzFGj5Qxq5PJn1i7gcjsiCZGH6O5Pe6raji+LRqAxT6wjgJwY2KM6qAFuVzFH39aMUQCGgho+jr1FggQNKU4gAZAQ/p7sIlA9vGeehl/1Fd9x7dmDVIVe9HH49ui3juILKIUt8d8skVxzpZyYp2v52ZvoCfUn+i+MTf1r1Avzo0BIZkAa2N0m4xxNDfGGDMzZvzcGKtwvkyx6f9LJLWvaqgqLlSiN4EG0kCVY27VBedDgN+Ucm4odDd2ASBXL2UjjsiwWgPar+D8gG++7/qY8wO++auGUt54730VCuf9bCL0Xehin02rEcoGAgT6GggQoIsGgqYLnLCFUNgpVvHhftkR888iHwI5500xuyN2VRu4UyrkPJ9+I+f7vmi+n2agRil1JqeTU64t8MVAQcNbS2eQdx/t99aWE4B3I8diMbGWbrFi57v2FY5hAejJicaJACTAvyiidL3wXgFEASnwE7mcW3rVcDiR/fcAEpJYNaSzELHfqwD2Gr7b8E4APkwsryYdayEB2M7ZWALdhkWoh6oPQToeYs5ZICHAMudI0A93gEBe7m3IOYsnPtDvZw9t8SOrCgCqfwsuQiSjNQC6DxoIWocunDQJNIHUbBHQlI70AN6jvHzbUfkDEhe6WFj/bRS/+SsuvPf+4toW3/xDo733bUc12kK65W4Vqfo/lWJnMIDqnEB9xm8KaBIMZlCfsVLAWU31ywxk6kDtKyWE5V4F2EWBSnNYb047w5kxk/HruVmzmoC0YBKva3NT7wBihkD73Ji9Z89mJtGbzJ75dW2MmdNRPe1YQemTnS7AKL7GGKerGLP6DA4Sx3F/DfA68nlUw3oyWcYEm8jnGxKg4VO8AuzM8f8QfEMSAjiAoDXQ4HrQOhSAEyBoAgkcOOlLCCABpFh9soUZ1bCOU0CiiXxWHbfH8WsdY4xmv7iMa9pq9Jm4uarark+yF6NfjeXHE7pFArxswUzOGwAN9SeSMaHd3TdGuDHzg8MK41pTMzk5Mab6dF5hzGBnY9ZF/em8AphymWA8toDflBrtPauBSqlEKWq0BxpgsOvAsdojzAZXaqqcQ6lhDWE5u1K38FKZY68VxC4q72VHrrz3I1h67z2sJXk/9ecgk8p78XLlP8SpgdVu5UF48OYAHgAkXPdCwUwcIEBAQ2oEQEigCYAACIDWARocRQIyAJdQq75t8dCSzTRnlveHOYcOk5e5q3148DltKpezzfMMSlYCkEq1b05N2IL39m/DIeDqFmRiHYsvOCAMrbU7O5Wdn34YWTuyu8Za2e44+yF/v06wbpAaikKeWZCRI0tqGkjgBC0DQPtd2V/gkLEMBTQAGZ/4qGB9cfwxyDug4dri+LIAjqydf+GttW9pwO28+2jNbnD0SmkC5bnDBe0kOqucc64KdHG/BEdDbwPkfN/k7LOCaPaXuWdjesoveoeeAMg2whOANAAaUiOOXg0PiAl6e+K9v3iEv5XVk535sfe+0lx57+MWsP5Fem8W9BcDB+BqYKaUum3sUIGslLrgvALeKKX2/3N3D2a5hUD+EHpba1gsSAZo4PAEqCa7DpMECLA2Gzrnu2LMCQDYi64l1fykddHyJ0DF+LXB0RUA2gNx4HqgzR3b2vjtJE5HoIFNAnSAR6XmMTRPAGSDSorbJTTqc5FjvMfEGKuRIW6Er7G7jou/R9W42Zg1BOpPAlRGgPpXqEfDF5iRlkT3y3kywGsxnXIbPGvaWezUwDZQnRNICKgVDcxOgb0zO1Jq8OZsrwe7QCk1FDqlaRomPtPIefGTM6j8QZe/XQsELr1fXl9o0GN/4r2PBa333gtbtt49OJgcCAnQdOGEQgONAEiTCOiOJ01kjbYr/xBS/qk2EB869jfks6zaJ6vKm0nnItmQU2M/yrvfbQfI6QnoI2tTNSyGdoEcrcWaoZ1YO7GdAotT3lrAWzWbTQwNaRIvPEkyEgXsHNA6SZ7vFkKW1AxfyOS9GwvOSjkUuZzLSAAglQUC6wra2tH7YkdzYofAq0ELvJOP1hwNrLWTgT2Bd+8gtQGcfUjlX9ee1o8MchgJ6AANW2ggIYDjMOc8AzC5O+afus45NpKzKlMW0JOWAwT+KCDw2KA1pIb+bKDOtztQjzk/6Gq995or732Es5GvfNfr/84ktiSCXfTM1IDtggbqF1MpzgSWs8IuALdb03144JRaFUzvI/IRIgpgB2YBnBxCc151bMy6oDmvwLVyY244McaYOeXrRQ/jXUNl9AIYy2n6GRy5BVjFH43Q+TVGU0gFOAGOb9n6a4y3RaocMUb5Gu+ZeCwlcUVDd+qDQNnQh94O0EWDA2ggUJBkFTfk9lFf41afp8WlPOYyHtNmNjEaldvo4u71m7pRMibMJT0q0VF/KpCCldlSKG9MonTCxlQn8KweLGJLIoyHSq12d/fV1XarqZrsqRmJrbY+U+oKQFaFvFA1YVbm4cVTSYhYptUYYOyXPhRl5WENnB/wwR9fPxVwcAkgawBZJQKmheCl49g0UgjQESBCAEjNH4AukIKmKPAQ4CM690tg38DdDJ5SJX+njSrulx0f85/U4gvOWjtpAA0PsLfItC+LnrYG5MPTsNaAObJQt4mAXInyig2fc+j5UZi8xwFSNHYaEmlcSmpEZPrejUQcT50kzy1IFC4lUBBIZaOIgzgijOHRxFo7Hlp7dLRoZZRk7RFAZUeWyYengsUkAG7YJiorDzlFcY+NmeYMQspBmZ7K8H2TaB+AnLMln1Y5wybn/DgayZmlNIkAPPgqL49MtwBBAwjCpEmggQSOMoEG0hPQ2Qf7I0FGpPXFlfe+grSSW+/9RZO8V3zwD3DrfQsP3lwCZ16ewrd/Rm31HSGDvR2KBGhICMDBYYLlLNCpJjs1zE4p3yilVo9hYZs7VSkz18zbREOIZEhzPjLYgakAMaZHSPDrYAKcG8Pw+e7c3OyYQxbGWKhMpz5kcVAw313Ar5ZEADr1BOJrSIBa0+aer/Fes4o/UgVxfsPXuBxfrmKC1zFu6NSr+LWOnym/xmgABLuGsUHoLHSApgeCBlID4ARAa0iUrofSdUAgLSZY/YjLyWWAtLcAruqvMaq+OJ/GFi4nMXqJMfI5Rh9j3D8uNvHP6hZZSNsFE+HG3CDJAIsFaNZm83IeDK41c2MGz4xJDd0bs65/DUX/n48YWwzUomcowN7KLlC/0QCD5Xt1h50oHKXWkAZqX5U11c7yQt11OaVUAHvNg3z21i998eA/aOD4AAeuo3phOL7G+a7z4dD75WTtfHni/eWB91eF9xoI0bXdOj6NOMoEBc026AANjq5ApzhASKAJdDsKDQ8BoXubgcPcs6l+ZL7JQyx+5tTgcs5Cyj+77r8B3w25zdnnfNiTcq7hqeNbMOnzP4HWvgLq3QV6XTAWIFTJfmQt1i64tjC0JzzyywJny92BtVbs8ATeOQkcIaj+D3r1X2QqAUBk+Fwk8n4iCYLkhlJ4fJaJNMB8qEHLPIsM41KymphTaz+yPrIJ3lrkA8n+DoFU2OungMCRA3C2nNvfRR5yenDKy3sSdw+6Jeb8jfxDSDlAyNF8B5b7m6doHx7anHO2Oec8j7RZuYoUCImgNSTEgROgIDUCIM1ToDWPTgqy3e8I862cLDm/1B/8A3u1927tj4tvful3vPftev/4KWL80xM90zaZan86qgF9pW4ZL1DuQNXFharOxgKO1V5xoTp7npJUwoJWAGRmlPnFYoKwMXvm1wDyyxCqc5Ixq5XQacz5Y6zRppxH6UAx+KwALifHtHE0iyCkeE99DMjrCEKC6WTdBVXa4ibGaGIVyyJKEsBRaoAGRwcBTQE9Woc+mi2EbZN0Wp60G3m+HzuOb7s2kcWN/USQy+JmQTSx8jGOL+9jtF0Hsf+qw8YY44/H0hEiJZOASUWoa6g/EYxJNDdmKifGmN15MmbXPK/MWgO8fG7Klzxyro0x5n3BaHECGYenp0pNV28EcEMhaA00Asibxb4KHQhPKpRjKdm5rls8+OYSONsf33qCbuBgOPTeTwpkcuW7VmPvvb94nJv+GSeJ0ETQQGrEgaOhDPQ30NUIgDwKCACMZdRuzgogn3IY889NzplH/MzpESHnhyeD8p5uzUj8UCrBq8HRCcBHa758mBRfFgWcnPLW2rcd73Yc8MFaaz88BRL3CsoL4EuRMZ1BEm5QkLqYWwfODrLsyoA/+FFKV1gA7JEp3lmxczuS4suiB3lrrYwmxspa/0GJYX34NGufqq4B8vIeuJOcc9pUkE+/G3o3FWQnTQI9u+vKj/yGCnXrJrSl0xOwJYATIECAhlLobwB6CF2PdWQsQJLQsR8DYWey9H2tR1/0HV/Ten/bMfLeX0HrfbuVDvjKCxwoPv/2HyQEQFaVeg/vlVrZBeo3ui/UHThgdypqcn5aUe+qBSzsFrVbKfUbC6WulubCbzpQOf/fodbPLTB/CaL1BF7O2TYA5xXwQhuzp+tgzG4LsPuyZ/H6/AVAQ7ndeuR4IsfOAGh4HeGqhvVYAjRsvYo/UDHGOLWfQOIxMI0xRmVj91fExRhjFXvv68ojia5SgKB5HCRwgJAADSA8VhyP/IhFt021IRIXxHjD13j/x1j/VG282sQ/pXPmIPzlPBmYmwp6gnmUoRr+tYJaC7V5AcYc9iUIxoT5rulf9gaHGDKPF6h9y6WqTjveCI94s4Ma7DwTZkM1VpdYpVjsKFFqqpRK4JQa7tQA68z0OTqD416KIK33LVz5QIfwGGk9bj158OYAOPZl5VfJe3Xp/dJ7Tf+qdVjtuq6rdWh8HyEKvU8HOGkSj2wSaA00bO0hQPoljS6v9nD9zNF870uqnHPM309z/iEPsQg5z7PNOctDzvnhIef8sI1SlVBFSil1cWMz9uJwgVnQvd85BODk1LwCObLWfpQdgXYgFoTyyFp72vM3a6XUcZwUAJTc2cgQeT4ci8hwJDLxQGp6AoTK0AIOQP3SJBHZjdLnReR9oUUEmriUcn0ajLt5DGsHSAPoJ/jdLk4BJh8ANKWxtsvZI9v7ls7SBGCHYAGNfIjLIIeZu9kjVD0efI65dFKofAebXFYPObdZck5s7ylVwiaBA4REYDvAgw7QAHRpAjQ4QJrEH8zjbOJDl3/MlffD6TnH1x1j772Z+G3HZ08mu778tXHp6yLQAGo43d1Xj0lU5/pC3VHuvDlTal/YtqG8UNMzq7YdK7V6IwDzb25coqghxrGokdVWn8SskQndL4wAeqvXppxQ7z43xiS6A4AzwGDBo74CFrEGNNAedDUJ0KHYxPiacrvuANzEGF9fpa4YY1zg+y8RQQCEntQ8gaP3qQRAmi56BxOpJ8VV3bGKUY8WRfZxGffXUMfPf9Q0xhin2cc4mayL19H/k0kjxfx5jTyrAzTnE2PCfLc2AQ009IveMUZeHxpjRsaI2Ts5mRmzqyuotJkbo7WAmJmxCp8hMtjZVyxGza0aV6dDaFgpNfxLfakutlsp9ULtKDXdHSilHCTC4C/76q55M1RqqLrHSp3xmzJ3DCbSXIj3L8eTMxh54/3+GkDeWO/fDM85m/gAwcuDN35L6bplsOIvjF9OBHz/OgBIuK58nokATkigNdBIQQNBE0jgwAmJR9oBPGge7YUAGEzE7AO2gtzqhxaa+2VHyj+VCjkhOeej6TznACHnnJegTNb5SqlNx2kGDnMOoF6pIqWUurIlkeEQcGFobTW2FbT1tQW+zO1HvXak6shaK39twR0d2XICjFLHcbaCj9Za+wqoWxDrFKA4BQCXiMb+aFGEwVBEIoupTDxJpu+dRiJk2R02SabvnYiMxgCDBpjLWORyKSVMKQpwIjJ2wAvvGlKBg/goQkPnqbEf4XdrJsGBfAD0zo5Ya2uA2lprj4CTU66tswYIHMd5Bye2BsRaaz+KREYqJuecf0ACHlrifP84Q7XhCe9yzjmBA6hRW5RS05w/5Ke9kAkCuC4NNOIAmqcIEKBrsGAfRS4H3INhpuu6K1wJN/nFAO0wDtS0gZqmaQM0TTuKX0LP+MjDeujTuq4/rOv6I/pjuv6YJrL9va+Kf7QEAFZQOCAYDQAAEEAAnQEqoAC5AD4xGIlDIiGhFNp1SCADBLG3cLpN7KxCkKfI/0X0T7G/n/655ruk+Jr2V/xfuZ+Enqu8w/9ZOlj5lv3L/aP3Y/Sr/Y/UL/qv+w61b0HfLo9lj+w/9f9yvanzG78IP0A8xv8/4a+VL4NLk8J8M/FfwP4BDy8vbTHzXfKRqFl7xlMplMohhV1XKItbZpG60lERuqVHmE9DKYpyqu0HpyKl0v+RXEArPVcVkGnaPrbwimV9NnhuM1Dpc2dAISuFB8ThjujbDb0d2R3yn7fHAWbJ7cDU0Y4K+FQRlEJMli+ndAXVnuNAFUWawVYoCed6Gb/PmE4BPbD3bP3gdveTwO8CAenTScwVn2h/taIbxrPyCQG1nBQGtqw7+FJa1yv61KHnZJwekrFv+PSiA+LnyforcbQ1PfhMkyEc49gI0Fu1iTh4it1b1Z+LEMSMEH/zACXWDDM3N4B4EubrRY0J2X8hUO6HCwNI6tOdJoGi7JbmsDL1UnfeO+enEa6KktqXFGEYp5AZfoDKxRmmXa7O/qmUu62Pxi3b7jtYIKODfLJ1UDYPW3hyLvX6Fu40iVByvleld41ZRDXJsLFiA5QDrWnh/SPu6rDhoEUPuGJrqTxlPJRWVeMjupDTpdCZz51cR2vnjhKHAY3MdqgR4SY9XVBNHhDmbTX+9w3TPDjnQ7fnT0AA/v/kXYNP+1PQU4nT0WKUO+7l+7lzuuLavf1OALgOnUQ5CFALKz5zvBQH/8QyCJ3mw19+1w2ggiFd5b91Ocla/oAjr7QOwcgwOvmVjOlsVFHa0bRLF7te51jxeV4C8PTgu2X74IHneCY515KJcsKbwVrINLA+GUvXM5cE8m0eOO3in4OPhd3LI8gRIvK0jpz39spTfwcSw8uEpFQ6ELTLvREB+Mt+ueV2WpRGApXNZOix6vLjlem5whbKaAa8jQB+m2iP6DS8DIdhqF85POPOHw/EGzuUuH8WKM86SDzx3XqR6pZ5UctarPpUnNACF+HMlgUjixdslyNqCNJfMjqAtKzhj/ankOwbKz47Dz/NgfPPkCiwUBIb8BbuZuL+ru+K2g4dwkZ+09X0+MVnyeQnikj3wj2LkyubDn/ODhu7dDcWUw1d9PCsSPiZWbSp4itRTZIZLppfKPZj34cBSt7rk1IBrl5l/wb9BKLDeEGofe9H/U/rLNbXlIs/1jp3MZEC0MMZ/tS3l4Va00f09XJRNm2vGM1+sGhvb+4nR6D18XMq6bop2OuIecr57ws3+tOMlwMJPSt2u1y4Vj/x5dUMD5dCBeTwsX8fhmazEhXUPv0dDrgqc/29+sQoDKbr+y7IOnVZMQS5+0d2nwnNWSZzYS9Lce1r3WvBDJ8mWLd9lO+06W2httQb7kqO9B+vB4f9jVH0khN2s+Q4S86LjXg/C2qHTnnKCc7trJGxbQ3qm+lLThJ3ceGb4+zFfAdwGSC7kso3b5fMJQ04kR6Gi8x34fiuORy0ILQ7URXhiTm0RemVZrNOHAhhnGWhCrt721nsA6rn6oCwpqk+X1awxj9ghC8mdi/mlAFXzrz6dcPdquSe8hWdC4qEEWnnRNBDrUGZkZfsN3qFG7cJHmnVzMmek+Gs6ddhedamGkaAg54iQyA6FtXuqYGbR8ydKT5WYKbsTlH22gRPucoLlhEo+K4mWYfJOVquFtpRMBXPstxGl3B6Eb2Y7+8GaK/2xWy/Kyiz20bNKRZYsmIR7AvlnjTO/ABQYFfMthCfa8Ev9lkL+eCtuApPkWjKmd0Hk/w5/GyWhUkuoNlIrPDEH6TZRsBfghGM0/jOUVh8EwLI29s54pUJBPT/KE0wAqEA3l7+nJkegof+YKdvJoxG7ax7/d6WODb2xwWKM7qYaLjIKFEZ8lrGnIoOuQ40JVb2ck4vSQY2CkQ9eXGilwBDEOtA4xipGYzkuKhOJ+QWbTkfiaESI68Jbve02FRZKBSJQSWIX3d5eBMMx8QaiB2xbc4KoO7m6fqlFYQCTF5wseYobUWUvYNq8a4BMpI/+3m1TqiQ9+V9muiOByGxTGnH41gvN7V+Vx0EZ5Hvkrhgu8n3SanAWkQAYCIfA+nAZ9eYQnmpmAW8WLIZI59kCI5MioFVWdYcXPMk4N4cFXu5pvwrAfvGgvxlFB0WWh+M7gmkTWgp1J1h8Idj9sw3ZahbrT83msLWK3i2blti5VWMpHMet/uxG3QkzU6xOjgBO2CY2ckkhkZZ8KXcpbG+7RkvZ7nDTGglQ78avyvkuW1qalK4F49NClaDBJz+8ZpkJaeVDSvaPH6oxnv2376SL/sNr1dv6cJHnUzJF5HGtNbSHwEYNKffsryBUGEsvlW/Y5MieJvyZ0xkPh1mc6hfxgzvu/HkOsIG1fdClIphYGLQT/k90rQ4Ot/DEZP2/8BgzI5YraUVts+y71J/DKTIT0si3jDMNkRlidf30wPgchnlMEbLM7SFblcUrktD8le9ahYCaexFuCBfJE+VP+fkuD7HaqwanVw+V0Heo9IAegYRO0dOtpW87ee+EbfyadBi/z6bhDWI5flZ/6wCpveoqN05JcMpctUr4ByS2PbSIL5x395KRrQ8EyyJp8z5Pk3fhEtwTy4XnflgjXG+m4c32Rn8whGaD6LCg11xZsZvNaF15jDus6kfszF9ypBAEwNhlh0owZOaMlFGTUja7TeMGZ5qRaPe4WOO+G5Oi+qzp7/tUIXI57gZBsVERaNMWaHRxbO6iJFISoHMOGyf+4iv7+KGBugDpnHhFHYP+BTmb5BWBDB43EArnWgcv0ZIaEP5r5+Ym5nu0obu7itbMDPVBtRMZMPYPDBwDGo03vd/VXvYq0fnraCeGWZfCI3x9FfabWtOAjh4M8g2DvmoFPG3GhbGernGosDAKqrdfpw0BHhhu71Seir3wqcitk3lGtDxKkM1NXKHr82uxaAI67doIJFAtLT06WiUCqDeg6WpAA3FssTdsaSYl7xbpcNzwJdT2AE2vXtOb2sdGyvDnFDtrscMNqtP5D8xTeBtTLmfRhtBHs9k0YDx+ofG48Zip7AIwuFv9J5zch4MaflIB+mZqp+Z3UfV+Rx27xzU2dg4MjziC/19/+BkZMFXjkz9Tvz2t/E124M9ysQEYLdGQZjFHEyg20KKIYFhQ/nkx/AkzFHkgVjMHw+IZTdztpzDI/QE2vUFamTVaUJe6qSbta+xxvl/RhpTEuXjFd4ciSlroRggglo1faYWLl8IU74t/yAeAX992Sa+2kDodkVYhflIItM/XTofSREGVYxkQ8zmJsn/y1IQU7nqBTLwnNHTnTFzkhr1JQTYGpdwhj1aPDwfK2f3bcaH1vUNcPDJ8SH4DNF3OvYOA9Uw8mB8ZlDxor+wD/JGCp+VYK5ZUpI7oic3jiP38HEXBSwqimYIAVaKl03FeNvhIe+wxbX9ttyIZOSfVVedn2HAdzxnZAWyECJ/8RsbCHsnaAP27NjoHLcHz7apuSK1WuN3ODs/M95V4abYZdrWRmpzwa+fC6SwIzP31XaX0uYGNmqR3N1bvfEKKuHHLuND41ZKOsT+wZKdEXS7i8NwuhEqpTk4wweBGFttDfpxC5k5kiCPc/+4of/O4AN2aBTPnHCB4TlsXKeGZJVzMLvfesfO9PKfeHYLhkxLnKNGcNqYGu83yX9mjIZ0IEdqFg883w8RWp3FN7ojcwWeZdMIRDAzG8D+araCrMbOwDY9tPDKN01G+OdiowakUkjrXpunoP8HzUePoR944LYZNFPSqNEiFhNrYwh1BL3/mXpB42jlx3TjvUCRqfVZvJEvtjwV3KJdrNbKvqSAVTz83T/z3tEOT+ETagZgRPSplm84j8SHaFVneaPy6BlAd0RaxQQNNI81dsvHiazl4xlgI4JMNzeD3E9B/YSxdiB+cr62SZSokVsKmtAVRrdODRkQNIobJYTVpVs210SNNJNnAQ4W8AwLUn1eQh8dm+gdWYCTCHywy7i3dS1dfKMR9G1pEExVm+YSc8kYjRFEmmyOdYFZqZPdcAXOtpzpJzQul1kevzDay+1+Jko3ZMyZYoxgkkA9KCLYlQRB6VFmRSQmdQdvi7FBJKO34058jzY7mlm7xYwMd9wSMgds7iVVZjLBpjv55yknX9MP9t0+Ia4WkTin3Tiwnd5xZ3iaJ0tFmga06EAI5XYY923Q8E7eL8lfNnifhe/sQOwmZ6GOnXE/Hac72gef5mrVvcveIfDYLwh+rIYcTVzS44eEtRt+1R+ca2g9idXSPdq3Wecr9UlK8jRpTQ8JRhmUHhzQDgwC9Mp9y97pHGrrLczbWaxMr9KRcys+w6Ow55sBW5WrZ1hwMZsgv8A7+sfR/ia1Gkg4ftfY3lhPC6LSmf5Tu2cENGtR1ZYDjbJkAHwX2KyW36lGD5h3IZ47T5iFIdlXbbZoUqh8crg35AbLZ4gn58SD0XfTzJuyZRfLduG8/8jbALbw8kIYAAAAAA=="
};
function Q({ kind: e, className: t = "", style: n }) {
	return /* @__PURE__ */ c("img", {
		className: `doe-piece ${t}`,
		src: ye[e],
		alt: "",
		draggable: !1,
		style: n
	});
}
function be() {
	return /* @__PURE__ */ l("svg", {
		className: "doe-income-flame",
		viewBox: "0 0 20 30",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ c("path", {
				d: "M5 20C1 16 6 12 7 8c1 2 2 3 2 4 2-4 3-7 2-11 6 6 4 10 6 14 2 4 0 7-7 7Z",
				fill: "#e9522e",
				stroke: "#a93428",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ c("path", {
				d: "M8 21c-3-3 1-6 2-9 0 3 4 5 2 9",
				fill: "#f8ad4b"
			}),
			/* @__PURE__ */ c("path", {
				d: "M2 22h16l-3 4h-3v3H8v-3H5Z",
				fill: "#e8ac63",
				stroke: "#a97145",
				strokeWidth: "1"
			})
		]
	});
}
//#endregion
//#region src/games/dropsofevil/moves.ts
function xe(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n || n.assistant === null || n.used) return [];
	let r = [], i = (e) => r.push({
		type: "assistant",
		targets: e
	});
	switch (n.assistant) {
		case 1:
			for (let e of ["free", "captured"]) for (let t = 0; t < 60; t++) i([e, t]);
			break;
		case 2:
			for (let e = 0; e < n.bonuses.length; e++) for (let t = e + 1; t < n.bonuses.length; t++) i([e, t]);
			break;
		case 7:
			for (let e = 0; e < 12; e++) i([e]);
			break;
		case 10:
			for (let e of b) for (let t = 0; t < e.length; t++) for (let n = t + 1; n < e.length; n++) i([e[t], e[n]]);
			break;
		case 11:
			for (let e of [
				"worm",
				"free",
				"captured"
			]) i([e]);
			break;
		case 13:
		case 15:
			for (let t = 0; t < e.forest.length; t++) i([t]);
			break;
		case 14:
			for (let e of v) i([e]);
			break;
		case 16: {
			let t = y(e.boardKind).cells;
			for (let e = 0; e < t.length; e++) for (let n = 0; n < t.length; n++) Math.abs(t[e].x - t[n].x) + Math.abs(t[e].y - t[n].y) === 1 && i([e, n]);
			break;
		}
		default: i([]);
	}
	return r.filter((n) => X(structuredClone(e), n, t));
}
function Se(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n || n.ready || [
		"gather",
		"income",
		"refill",
		"done"
	].includes(e.phase)) return [];
	let r = [];
	if (e.phase === "placement") {
		if (e.turn !== t) return [];
		if (!e.placedThisTurn) for (let t of v) for (let i of [!1, !0]) for (let a of J(e, n, t, i)) r.push({
			type: "place",
			pawn: t,
			spot: a,
			...i ? { special: !0 } : {}
		});
		e.placedThisTurn && r.push({ type: "endTurn" });
	} else if (n.pendingBonus.length) return n.bonuses.forEach((e, t) => {
		e.area === "distiller" && !e.taken && e.at <= n.pendingBonus[0] && r.push({
			type: "bonus",
			index: t
		});
	}), r;
	else {
		for (let e of g) for (let t = 0; t < 60; t++) K(n, e, t) && r.push({
			type: "brew",
			resource: e,
			cell: t
		});
		if (n.pool.mushroom && r.push({ type: "mushroom" }), n.cheese && n.freeRats && r.push({ type: "cheese" }), X(structuredClone(e), { type: "ready" }, t) && r.push({ type: "ready" }), n.assistant !== null && !n.used) for (let e of ["worm", "cheese"]) r.push({
			type: "tradeAssistant",
			resource: e
		});
	}
	return r.push(...xe(e, t)), r;
}
//#endregion
//#region src/games/dropsofevil/bot.ts
var Ce = {
	column: 1.3,
	vial: 1,
	income: 1.5,
	recipe: .5,
	rat: 1.2,
	order: .35
};
function we(e, t) {
	return t === "rat" ? -1.2 : t === "mushroom" ? e.bonuses.some((e) => e.area === "distiller" && !e.taken) ? 2.2 : .1 : t === "spider" ? 2.7 : e.lab.filter((n, r) => K({
		...e,
		pool: {
			...e.pool,
			[t]: 1
		}
	}, t, r)).length ? 1.2 + (e.toxins[t] ?? 2) * .16 : -.3;
}
function Te(e, t, n) {
	let r = ce(e) * n.income * (4 - t.round) + U(e) * n.income * (4 - t.round) - e.freeRats * n.rat * (4 - t.round) + e.capturedRats * e.toxins.rat;
	for (let i = 0; i < 12; i++) {
		let a = [
			0,
			1,
			2,
			3,
			4
		].filter((t) => e.lab[t * 12 + i]).length;
		r += n.column * (a / 5) ** 3 * (2 + S[i] * (4 - t.round));
	}
	for (let t of b) {
		let i = t.flatMap((t) => e.lab[t] ? [e.lab[t].resource] : []), a = i.find((e) => e !== "spider");
		r += n.vial * (i.length / 3) ** 2 * (a ? e.toxins[a] ?? 0 : 0);
	}
	for (let i of t.recipes) r += n.recipe * Z(e, i.id, i.resource);
	for (let [t, n] of Object.entries(e.pool)) r += n * we(e, t) * .6;
	return r += e.cheese * Math.min(1, e.freeRats) * .8, r;
}
function Ee(e, t, n = Ce) {
	let r = Se(e, t), i = e.players.find((e) => e.rid === t);
	if (!i || !r.length) return null;
	let a = y(e.boardKind), o = r[0], s = -Infinity;
	for (let c of r) {
		let r = 0;
		if (c.type === "place") {
			if (c.pawn === "pouch") {
				let e = Number(c.spot.split(":")[1]);
				r = [
					0,
					2.5,
					2.8,
					2,
					3.5,
					2.2,
					1.8,
					4,
					3.5,
					2.6,
					3.3,
					2.6,
					2 + i.freeRats * 1.6,
					4.2,
					2,
					3,
					2.2,
					1 + i.capturedRats,
					2.5
				][e];
			} else {
				let o = a.spots.find((e) => e.id === c.spot), s = v.indexOf(o.kind);
				for (let n of o.cells) {
					let o = e.players.some((e) => v.some((r) => {
						if (e.rid === t && r === c.pawn) return !1;
						let i = a.spots.find((t) => t.id === e.placements[r]);
						return i && v.indexOf(e.effective[r]) < s && i.cells.includes(n);
					})) || !e.forest[n].length ? ["worm"] : e.forest[n];
					r += o.reduce((e, t) => e + we(i, t), 0);
				}
				c.pawn === "snake" && (r += n.order * (a.width - o.x)), r /= Math.sqrt(o.cells.length);
			}
		} else if (c.type === "endTurn") r = -100;
		else if (c.type === "ready") r = -90;
		else {
			let a = structuredClone(e);
			if (!X(a, c, t)) continue;
			r = Te(a.players.find((e) => e.rid === t), a, n) - Te(i, e, n), c.type === "bonus" && (r += .6), c.type === "mushroom" && (r += 1), c.type === "cheese" && (r += 1), c.type === "assistant" && i.assistant === 14 && (r = -.5), c.type === "assistant" && i.assistant === 16 && (r = -1), c.type === "assistant" && i.assistant === 3 && (r += U(i));
		}
		r > s && (s = r, o = c);
	}
	return o;
}
function De(e = Ce) {
	return (t, n) => {
		let r = n.difficulty === "weak" ? Se(t.public, n.rid) : [], i;
		if (n.difficulty === "weak" && r.length) {
			let e = r.length, t = Math.floor(4294967296 / e) * e, n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
			for (; n >= t;) n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
			i = r[n % e];
		} else i = Ee(t.public, n.rid, e);
		return i ? { action: i } : null;
	};
}
var Oe = De(), ke = (e, t, n) => e.type === "brew" ? n("games.dropsofevil.brewHint", {
	resource: n(Ae[e.resource]),
	n: e.cell + 1
}) : e.type === "place" ? n("games.dropsofevil.placeHint", { pawn: n(je[e.pawn]) }) : n("games.dropsofevil.actionHint"), Ae = {
	claw: "games.dropsofevil.claw",
	wing: "games.dropsofevil.wing",
	eye: "games.dropsofevil.eye",
	tail: "games.dropsofevil.tail",
	spider: "games.dropsofevil.spider",
	worm: "games.dropsofevil.worm",
	mushroom: "games.dropsofevil.mushroom",
	rat: "games.dropsofevil.rat"
}, je = {
	crow: "games.dropsofevil.crow",
	cat: "games.dropsofevil.cat",
	toad: "games.dropsofevil.toad",
	snake: "games.dropsofevil.snake",
	pouch: "games.dropsofevil.pouch"
}, Me = [
	"games.dropsofevil.assistantNames.a1",
	"games.dropsofevil.assistantNames.a2",
	"games.dropsofevil.assistantNames.a3",
	"games.dropsofevil.assistantNames.a4",
	"games.dropsofevil.assistantNames.a5",
	"games.dropsofevil.assistantNames.a6",
	"games.dropsofevil.assistantNames.a7",
	"games.dropsofevil.assistantNames.a8",
	"games.dropsofevil.assistantNames.a9",
	"games.dropsofevil.assistantNames.a10",
	"games.dropsofevil.assistantNames.a11",
	"games.dropsofevil.assistantNames.a12",
	"games.dropsofevil.assistantNames.a13",
	"games.dropsofevil.assistantNames.a14",
	"games.dropsofevil.assistantNames.a15",
	"games.dropsofevil.assistantNames.a16",
	"games.dropsofevil.assistantNames.a17",
	"games.dropsofevil.assistantNames.a18"
], Ne = [
	"games.dropsofevil.assistantDescriptions.a1",
	"games.dropsofevil.assistantDescriptions.a2",
	"games.dropsofevil.assistantDescriptions.a3",
	"games.dropsofevil.assistantDescriptions.a4",
	"games.dropsofevil.assistantDescriptions.a5",
	"games.dropsofevil.assistantDescriptions.a6",
	"games.dropsofevil.assistantDescriptions.a7",
	"games.dropsofevil.assistantDescriptions.a8",
	"games.dropsofevil.assistantDescriptions.a9",
	"games.dropsofevil.assistantDescriptions.a10",
	"games.dropsofevil.assistantDescriptions.a11",
	"games.dropsofevil.assistantDescriptions.a12",
	"games.dropsofevil.assistantDescriptions.a13",
	"games.dropsofevil.assistantDescriptions.a14",
	"games.dropsofevil.assistantDescriptions.a15",
	"games.dropsofevil.assistantDescriptions.a16",
	"games.dropsofevil.assistantDescriptions.a17",
	"games.dropsofevil.assistantDescriptions.a18"
], Pe = [
	"games.dropsofevil.recipeNames.a1",
	"games.dropsofevil.recipeNames.a2",
	"games.dropsofevil.recipeNames.a3",
	"games.dropsofevil.recipeNames.a4",
	"games.dropsofevil.recipeNames.a5",
	"games.dropsofevil.recipeNames.a6",
	"games.dropsofevil.recipeNames.a7",
	"games.dropsofevil.recipeNames.a8"
], Fe = [
	"games.dropsofevil.recipeDescriptions.a1",
	"games.dropsofevil.recipeDescriptions.a2",
	"games.dropsofevil.recipeDescriptions.a3",
	"games.dropsofevil.recipeDescriptions.a4",
	"games.dropsofevil.recipeDescriptions.a5",
	"games.dropsofevil.recipeDescriptions.a6",
	"games.dropsofevil.recipeDescriptions.a7",
	"games.dropsofevil.recipeDescriptions.a8"
];
//#endregion
//#region src/games/dropsofevil/view-player.tsx
function $({ id: e, children: t, className: n = "", style: r }) {
	let { ref: a, hidden: o } = i(e);
	return /* @__PURE__ */ c("span", {
		ref: a,
		className: n,
		style: {
			...r,
			visibility: o ? "hidden" : void 0
		},
		children: t
	});
}
var Ie = {
	placement: "games.dropsofevil.placement",
	gather: "games.dropsofevil.gather",
	brewing: "games.dropsofevil.brewing",
	income: "games.dropsofevil.income",
	refill: "games.dropsofevil.refill",
	done: "games.dropsofevil.done"
};
function Le(e) {
	return /* @__PURE__ */ c(Re, { ...e });
}
function Re({ public: e, members: t, myRid: i, send: u, readOnly: d = !1 }) {
	let f = r(), p = e, [m, g] = n(i), [_, ee] = n(null), [te, re] = n(null), [C, ie] = n(!1), [ae, w] = n(null), [T, E] = n(null), [D, oe] = n(null), [se, O] = n(!1), [k, A] = n([]), j = p.players.find((e) => e.rid === m) ?? p.players[0], M = p.players.find((e) => e.rid === i), N = j.rid === i && !d, P = M && !d ? Se(p, i) : [], F = M && !d ? xe(p, i).filter((e) => e.type === "assistant") : [], I = se && M && !M.used && F.length > 0, L = I ? F.filter((e) => e.type === "assistant" && k.every((t, n) => e.targets[n] === t)) : [], R = (e) => L.some((t) => t.type === "assistant" && t.targets[k.length] === e), z = (e) => t.find((t) => t.rid === e)?.name ?? e, B = (e) => a[(t.find((t) => t.rid === e)?.colorIndex ?? 0) % a.length].hex, V = (e) => {
		u(e), A([]), O(!1);
	}, H = (e) => {
		if (!R(e)) return;
		let t = [...k, e], n = L.find((e) => e.type === "assistant" && e.targets.length === t.length && t.every((t, n) => e.targets[n] === t));
		n ? V(n) : A(t);
	}, W = P.filter((e) => e.type === "place" && e.pawn === _ && !!e.special === C), G = te && M && M.pool[te] > 0 ? te : null, K = (e) => N && (I ? [1, 10].includes(M?.assistant ?? 0) && R(e) : G !== null && P.some((t) => t.type === "brew" && t.cell === e && t.resource === G)), le = (e) => N && p.phase === "brewing" && !j.ready && !I && !!j.lab[e] && !j.lab[e].locked && X(structuredClone(p), {
		type: "return",
		cell: e
	}, i), q = ae ?? (p.phase === "brewing" || p.phase === "income" || p.phase === "done" ? "lab" : "forest"), J = y(p.boardKind), Y = p.players.flatMap((e) => v.flatMap((t) => e.placements[t] ? [{
		rid: e.rid,
		pawn: t,
		spot: e.placements[t]
	}] : [])), ue = d ? "" : I ? f("games.dropsofevil.selectTarget") : M?.pendingBonus.length ? f("games.dropsofevil.chooseBonus") : p.phase === "placement" ? p.turn === i ? f("games.dropsofevil.yourTurn") : f("games.dropsofevil.turn", { name: z(p.turn) }) : p.phase === "brewing" && !M?.ready ? f("games.dropsofevil.brewPrompt") : f("games.dropsofevil.waiting"), de = (e) => `${e.kind === "scroll" ? f("games.dropsofevil.scroll") : f("games.dropsofevil.bonus")} · ${e.resource === "cheese" ? f("games.dropsofevil.cheese") : f(Ae[e.resource])} ${e.count}`, Z = (e, t) => {
		let n = N && (I && M?.assistant === 2 ? R(t) : P.some((e) => e.type === "bonus" && e.index === t));
		return /* @__PURE__ */ c("button", {
			className: `doe-bonus ${n ? "doe-target" : ""} ${k.includes(t) && I ? "is-picked" : ""}`,
			"data-taken": e.taken,
			disabled: !n,
			title: de(e),
			"aria-label": de(e),
			onClick: () => I ? H(t) : V({
				type: "bonus",
				index: t
			}),
			children: /* @__PURE__ */ c($, {
				id: `bonus:${j.rid}:${t}`,
				children: e.taken ? /* @__PURE__ */ c("b", {
					className: "doe-income-mark",
					children: "✦"
				}) : /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c(Q, { kind: e.resource }), e.kind === "scroll" ? /* @__PURE__ */ c("small", {
					className: "doe-scroll",
					children: f("games.dropsofevil.scroll")
				}) : e.count > 1 ? /* @__PURE__ */ c("b", {
					className: "doe-mult",
					children: e.count
				}) : null] })
			})
		}, t);
	}, fe = /* @__PURE__ */ l("section", {
		className: "doe-forest-panel",
		"data-kind": p.boardKind,
		children: [
			/* @__PURE__ */ l("div", {
				className: "doe-section-title",
				children: [/* @__PURE__ */ c("h2", { children: f("games.dropsofevil.forest") }), /* @__PURE__ */ l($, {
					id: "bag",
					className: "doe-bag",
					children: ["◈ ", p.bagCount]
				})]
			}),
			/* @__PURE__ */ c("div", {
				className: "doe-forest-wrap",
				children: /* @__PURE__ */ l("div", {
					className: "doe-forest",
					style: {
						"--doe-forest-ratio": (J.width + 1) / 7.5,
						aspectRatio: `${J.width + 1}/7.5`
					},
					children: [J.cells.map((e, t) => {
						let n = N && I && [
							13,
							15,
							16
						].includes(M?.assistant ?? 0) && R(t), r = `crow:${t}`, i = W.some((e) => e.type === "place" && e.spot === r), a = Y.find((e) => e.spot === r);
						return /* @__PURE__ */ l("button", {
							className: `doe-clearing ${e.clearing ? "is-light" : ""} ${n || i ? "doe-target" : ""} ${I && k.includes(t) ? "is-picked" : ""}`,
							style: {
								left: `${(e.x + .65) / (J.width + 1) * 100}%`,
								top: `${(e.y + 1.2) / 7.5 * 100}%`,
								width: `${.78 / (J.width + 1) * 100}%`,
								height: "10.4%"
							},
							disabled: !n && !i,
							"aria-label": f("games.dropsofevil.cell", { n: t + 1 }),
							onClick: () => n ? H(t) : _ && V({
								type: "place",
								pawn: _,
								spot: r,
								special: C
							}),
							children: [/* @__PURE__ */ c($, {
								id: `forest:${t}`,
								className: "doe-pile",
								children: p.forest[t].length ? p.forest[t].map((e, t) => /* @__PURE__ */ c(Q, {
									kind: e,
									style: {
										transform: `translate(${(t % 3 - 1) * 17}%,${Math.floor(t / 3) * -18}%) rotate(${(t % 3 - 1) * 9}deg)`,
										zIndex: t
									}
								}, t)) : /* @__PURE__ */ c("span", {
									className: "doe-empty-worm",
									children: /* @__PURE__ */ c(Q, { kind: "worm" })
								})
							}), a && /* @__PURE__ */ c("span", {
								className: "doe-on-pawn",
								style: { background: B(a.rid) },
								children: /* @__PURE__ */ c(Q, { kind: a.pawn })
							})]
						}, t);
					}), J.spots.filter((e) => e.kind !== "crow").map((e) => {
						let t = W.some((t) => t.type === "place" && t.spot === e.id), n = Y.find((t) => t.spot === e.id);
						return /* @__PURE__ */ c("button", {
							className: `doe-spot ${e.kind === "snake" ? "is-snake" : ""} ${t ? "doe-target" : ""}`,
							style: {
								left: `${(e.x + 1.04) / (J.width + 1) * 100}%`,
								top: `${(e.y + 1.6) / 7.5 * 100}%`
							},
							disabled: !t,
							"aria-label": f("games.dropsofevil.spot", {
								pawn: f(je[e.kind]),
								n: J.spots.indexOf(e) + 1
							}),
							onClick: () => _ && V({
								type: "place",
								pawn: _,
								spot: e.id,
								special: C
							}),
							children: /* @__PURE__ */ c($, {
								id: `spot:${e.id}`,
								children: n ? /* @__PURE__ */ c("span", {
									className: "doe-on-pawn",
									style: { background: B(n.rid) },
									children: /* @__PURE__ */ c(Q, { kind: n.pawn })
								}) : /* @__PURE__ */ c("span", {
									className: "doe-arrow",
									"aria-hidden": !0,
									children: e.kind === "snake" ? "↓" : e.kind === "cat" ? Number.isInteger(e.x) ? "↕" : "↔" : "✥"
								})
							})
						}, e.id);
					})]
				})
			}),
			/* @__PURE__ */ l("div", {
				className: "doe-assistants",
				children: [/* @__PURE__ */ c("h3", { children: f("games.dropsofevil.assistants") }), /* @__PURE__ */ c("div", {
					className: "doe-assistant-row",
					children: p.assistants.map((e) => {
						let t = Y.find((t) => t.spot === `assistant:${e}`), n = W.some((t) => t.type === "place" && t.spot === `assistant:${e}`);
						return /* @__PURE__ */ l("div", {
							className: "doe-assistant-card",
							children: [/* @__PURE__ */ l("button", {
								className: "doe-assistant-info",
								onClick: () => E(e),
								children: [/* @__PURE__ */ c("span", {
									className: "doe-assistant-seal",
									children: e
								}), /* @__PURE__ */ c("b", { children: f(Me[e - 1]) })]
							}), /* @__PURE__ */ c($, {
								id: `spot:assistant:${e}`,
								children: t ? /* @__PURE__ */ l("span", {
									className: "doe-hired",
									style: { color: B(t.rid) },
									children: [/* @__PURE__ */ c(Q, { kind: "pouch" }), z(t.rid)]
								}) : /* @__PURE__ */ c("button", {
									className: n ? "doe-target" : "doe-hire",
									disabled: !n,
									onClick: () => V({
										type: "place",
										pawn: "pouch",
										spot: `assistant:${e}`
									}),
									children: /* @__PURE__ */ c(Q, { kind: "pouch" })
								})
							})]
						}, e);
					})
				})]
			}),
			/* @__PURE__ */ c("div", {
				className: "doe-recipes",
				children: p.recipes.map((e, t) => /* @__PURE__ */ l("button", {
					onClick: () => oe(t),
					children: [/* @__PURE__ */ c(Q, { kind: e.resource }), /* @__PURE__ */ c("span", { children: f(Pe[e.id - 1]) })]
				}, t))
			})
		]
	}), pe = /* @__PURE__ */ l("section", {
		className: "doe-lab-panel",
		children: [
			/* @__PURE__ */ l("div", {
				className: "doe-section-title",
				children: [/* @__PURE__ */ l("h2", { children: [
					z(j.rid),
					" · ",
					f("games.dropsofevil.lab")
				] }), /* @__PURE__ */ c("span", { children: f("games.dropsofevil.incomePoints", { n: ce(j) + U(j) }) })]
			}),
			/* @__PURE__ */ c("div", {
				className: "doe-toxicity",
				children: [
					"rat",
					"worm",
					"claw",
					"wing",
					"eye",
					"tail"
				].map((e) => /* @__PURE__ */ l($, {
					id: `toxin:${j.rid}:${e}`,
					children: [/* @__PURE__ */ c(Q, { kind: e }), /* @__PURE__ */ c("b", { children: j.toxins[e] })]
				}, e))
			}),
			/* @__PURE__ */ l("div", {
				className: "doe-rats",
				children: [/* @__PURE__ */ c($, {
					id: `free:${j.rid}`,
					children: /* @__PURE__ */ l("button", {
						disabled: !N || !R("free"),
						className: R("free") ? "doe-target" : "",
						onClick: () => H("free"),
						children: [
							/* @__PURE__ */ c(Q, { kind: "rat" }),
							f("games.dropsofevil.freeRats"),
							" ",
							/* @__PURE__ */ c("b", { children: j.freeRats })
						]
					})
				}), /* @__PURE__ */ c($, {
					id: `captured:${j.rid}`,
					children: /* @__PURE__ */ l("button", {
						disabled: !N || !R("captured"),
						className: R("captured") ? "doe-target" : "",
						onClick: () => H("captured"),
						children: [
							/* @__PURE__ */ c(Q, { kind: "rat" }),
							f("games.dropsofevil.capturedRats"),
							" ",
							/* @__PURE__ */ c("b", { children: j.capturedRats })
						]
					})
				})]
			}),
			/* @__PURE__ */ c("div", {
				className: "doe-lab-scroll",
				children: /* @__PURE__ */ l("div", {
					className: "doe-machinery",
					children: [/* @__PURE__ */ l("div", {
						className: "doe-distiller",
						children: [/* @__PURE__ */ c("h3", { children: f("games.dropsofevil.distiller") }), /* @__PURE__ */ c($, {
							id: `distiller:${j.rid}`,
							className: "doe-distiller-vials",
							children: [
								3,
								2,
								1,
								0
							].map((e) => /* @__PURE__ */ l("div", {
								className: "doe-distiller-tier",
								children: [/* @__PURE__ */ c("span", {
									className: "doe-glass-mushrooms",
									children: Array.from({ length: e === 0 ? 1 : 2 }, (t, n) => {
										let r = e === 0 ? 0 : e === 1 ? 1 : e === 2 ? 3 : 5;
										return /* @__PURE__ */ c("span", { children: j.mushrooms > r + n && /* @__PURE__ */ c(Q, { kind: "mushroom" }) }, n);
									})
								}), /* @__PURE__ */ c("span", { children: j.bonuses.map((t, n) => t.area === "distiller" && t.at === e ? Z(t, n) : null) })]
							}, e))
						})]
					}), /* @__PURE__ */ l("div", {
						className: "doe-brewer",
						children: [
							/* @__PURE__ */ c("h3", { children: f("games.dropsofevil.brewer") }),
							/* @__PURE__ */ l("div", {
								className: "doe-vials",
								children: [/* @__PURE__ */ l("svg", {
									className: "doe-tube-shapes",
									viewBox: "0 0 1200 500",
									preserveAspectRatio: "none",
									"aria-hidden": !0,
									children: [ne.map(([e, t]) => /* @__PURE__ */ c("path", {
										d: `M${e % 12 * 100 + 50},${Math.floor(e / 12) * 100 + 50}L${t % 12 * 100 + 50},${Math.floor(t / 12) * 100 + 50}`,
										stroke: "#b7d7d9",
										strokeWidth: "16"
									}, `link:${e}`)), b.map((e, t) => /* @__PURE__ */ l("g", { children: [/* @__PURE__ */ c("path", {
										d: e.map((e) => `M${e % 12 * 100 + 3},${Math.floor(e / 12) * 100 + 3}h94v94h-94Z`).join(""),
										fill: t % 2 ? "#b2d4dc" : "#92b8cd",
										stroke: "#315267",
										strokeWidth: "5"
									}), e.slice(1).map((n, r) => {
										let i = e[r], a = b[t].find((e) => e !== n && Math.abs(e % 12 - n % 12) + Math.abs(Math.floor(e / 12) - Math.floor(n / 12)) === 1) ?? i;
										return /* @__PURE__ */ c("path", {
											d: `M${a % 12 * 100 + 50},${Math.floor(a / 12) * 100 + 50}L${n % 12 * 100 + 50},${Math.floor(n / 12) * 100 + 50}`,
											stroke: t % 2 ? "#b2d4dc" : "#92b8cd",
											strokeWidth: "88"
										}, n);
									})] }, t))]
								}), j.lab.map((e, t) => /* @__PURE__ */ c("button", {
									className: `doe-lab-cell ${K(t) ? "doe-target" : ""} ${k.includes(t) && I ? "is-picked" : ""}`,
									"data-vial": x[t],
									disabled: !K(t) && !le(t),
									"aria-label": e ? `${f(Ae[e.resource])} · ${f(e.locked ? "games.dropsofevil.locked" : "games.dropsofevil.returnPiece")} · ${f("games.dropsofevil.cell", { n: t + 1 })}` : f("games.dropsofevil.cell", { n: t + 1 }),
									onClick: () => I ? H(t) : e ? V({
										type: "return",
										cell: t
									}) : G && V({
										type: "brew",
										resource: G,
										cell: t
									}),
									children: /* @__PURE__ */ c($, {
										id: `cell:${j.rid}:${t}`,
										children: e ? /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c(Q, { kind: e.resource }), !e.locked && /* @__PURE__ */ c("i", { className: "doe-new-piece" })] }) : /* @__PURE__ */ c("i", { className: "doe-empty-cell" })
									})
								}, t))]
							}),
							/* @__PURE__ */ c("div", {
								className: "doe-column-bonuses",
								children: Array.from({ length: 12 }, (e, t) => /* @__PURE__ */ l("div", {
									className: "doe-column",
									children: [/* @__PURE__ */ c("button", {
										"aria-label": f("games.dropsofevil.incomePoints", { n: S[t] }),
										disabled: !N || !(I && M?.assistant === 7 && R(t)),
										className: I && M?.assistant === 7 && R(t) ? "doe-target" : "",
										onClick: () => H(t),
										children: /* @__PURE__ */ c("span", {
											className: "doe-flames",
											children: Array.from({ length: S[t] }, (e, t) => /* @__PURE__ */ c(be, {}, t))
										})
									}), j.bonuses.map((e, n) => e.area === "brewer" && e.at === t ? Z(e, n) : null)]
								}, t))
							})
						]
					})]
				})
			}),
			j.assistant !== null && /* @__PURE__ */ l("button", {
				className: "doe-my-assistant",
				onClick: () => E(j.assistant),
				children: [
					/* @__PURE__ */ c(Q, { kind: "pouch" }),
					/* @__PURE__ */ c("b", { children: f(Me[j.assistant - 1]) }),
					/* @__PURE__ */ c("span", { children: f(j.used ? "games.dropsofevil.used" : "games.dropsofevil.available") })
				]
			})
		]
	});
	return /* @__PURE__ */ l("div", {
		className: "doe-screen",
		children: [
			/* @__PURE__ */ c(o, {
				adaptive: !0,
				scroll: !1,
				banner: /* @__PURE__ */ l("header", {
					className: "doe-header",
					children: [
						/* @__PURE__ */ l("div", {
							className: "doe-brand",
							children: [/* @__PURE__ */ c("span", { children: "Drops of Evil" }), /* @__PURE__ */ l("strong", { children: [
								f("games.dropsofevil.round", { n: p.round }),
								" · ",
								f(Ie[p.phase])
							] })]
						}),
						/* @__PURE__ */ c("nav", {
							className: "doe-players",
							children: p.order.map((e) => /* @__PURE__ */ c("button", {
								onClick: () => g(e),
								"aria-pressed": j.rid === e,
								style: { "--seat": B(e) },
								children: /* @__PURE__ */ l($, {
									id: `seat:${e}`,
									children: [
										/* @__PURE__ */ c("i", {}),
										z(e),
										" ",
										/* @__PURE__ */ c("b", { children: p.players.find((t) => t.rid === e).score })
									]
								})
							}, e))
						}),
						/* @__PURE__ */ l("nav", {
							className: "doe-pages",
							children: [/* @__PURE__ */ c("button", {
								"aria-pressed": q === "forest",
								onClick: () => w("forest"),
								children: f("games.dropsofevil.forest")
							}), /* @__PURE__ */ c("button", {
								"aria-pressed": q === "lab",
								onClick: () => w("lab"),
								children: f("games.dropsofevil.lab")
							})]
						})
					]
				}),
				actionsHeight: "doe-actions-height",
				actions: /* @__PURE__ */ l("div", {
					className: "doe-actions",
					children: [/* @__PURE__ */ c("p", { children: ue }), /* @__PURE__ */ l("div", {
						className: "doe-action-row",
						children: [p.phase === "placement" ? /* @__PURE__ */ c("div", {
							className: "doe-dock",
							children: v.map((e) => /* @__PURE__ */ c("button", {
								disabled: d || !M || p.turn !== i || (I ? !R(e) : M.placements[e] !== null || p.placedThisTurn),
								"aria-pressed": _ === e,
								"aria-label": f(je[e]),
								className: I && R(e) ? "doe-target" : "",
								onClick: () => I ? H(e) : ee(_ === e ? null : e),
								children: /* @__PURE__ */ l($, {
									id: `dock:${i}:${e}`,
									children: [/* @__PURE__ */ c(Q, { kind: e }), /* @__PURE__ */ c("small", { children: f(je[e]) })]
								})
							}, e))
						}) : /* @__PURE__ */ l("div", {
							className: "doe-pool",
							children: [h.filter((e) => e !== "rat").map((e) => /* @__PURE__ */ c("button", {
								"aria-label": f("games.dropsofevil.resourceCount", {
									name: f(Ae[e]),
									n: M?.pool[e] ?? 0
								}),
								"aria-pressed": G === e,
								disabled: d || !M || p.phase !== "brewing" || M.ready || M.pendingBonus.length > 0 || !M.pool[e] || I && !(e === "worm" && R("worm")),
								onClick: () => I && e === "worm" ? H("worm") : e === "mushroom" ? V({ type: "mushroom" }) : re(G === e ? null : e),
								children: /* @__PURE__ */ l($, {
									id: `pool:${i}:${e}`,
									children: [/* @__PURE__ */ c(Q, { kind: e }), /* @__PURE__ */ c("b", { children: M?.pool[e] ?? 0 })]
								})
							}, e)), /* @__PURE__ */ c("button", {
								disabled: !P.some((e) => e.type === "cheese"),
								"aria-label": f("games.dropsofevil.cheese"),
								onClick: () => V({ type: "cheese" }),
								children: /* @__PURE__ */ l($, {
									id: `pool:${i}:cheese`,
									children: [/* @__PURE__ */ c(Q, { kind: "cheese" }), /* @__PURE__ */ c("b", { children: M?.cheese ?? 0 })]
								})
							})]
						}), /* @__PURE__ */ c("div", {
							className: "doe-submit",
							children: I ? /* @__PURE__ */ c("button", {
								onClick: () => {
									O(!1), A([]);
								},
								children: f("games.dropsofevil.cancel")
							}) : /* @__PURE__ */ l(s, { children: [M?.assistant !== null && M?.assistant !== void 0 && !M.used && [
								4,
								6,
								8
							].includes(M.assistant) && p.phase === "placement" && /* @__PURE__ */ c("button", {
								"aria-pressed": C,
								onClick: () => ie(!C),
								children: f("games.dropsofevil.special")
							}), p.phase === "placement" ? /* @__PURE__ */ c("button", {
								className: "doe-primary",
								disabled: !P.some((e) => e.type === "endTurn"),
								onClick: () => {
									V({ type: "endTurn" }), ee(null);
								},
								children: f("games.dropsofevil.endTurn")
							}) : /* @__PURE__ */ c("button", {
								className: "doe-primary",
								disabled: !P.some((e) => e.type === "ready"),
								onClick: () => V({ type: "ready" }),
								children: f("games.dropsofevil.ready")
							})] })
						})]
					})]
				}),
				children: /* @__PURE__ */ l("main", {
					className: "doe-main",
					"data-page": q,
					children: [fe, pe]
				})
			}),
			T !== null && /* @__PURE__ */ c("div", {
				className: "doe-modal",
				role: "dialog",
				"aria-modal": "true",
				children: /* @__PURE__ */ l("div", {
					className: "doe-detail",
					children: [
						/* @__PURE__ */ c("button", {
							className: "doe-close",
							"aria-label": f("games.dropsofevil.close"),
							onClick: () => E(null),
							children: "×"
						}),
						/* @__PURE__ */ c("span", {
							className: "doe-assistant-seal",
							children: T
						}),
						/* @__PURE__ */ c("h2", { children: f(Me[T - 1]) }),
						/* @__PURE__ */ c("p", { children: f(Ne[T - 1]) }),
						T === 9 && /* @__PURE__ */ c("div", {
							className: "doe-merchant",
							children: p.merchant.map((e, t) => /* @__PURE__ */ c(Q, { kind: e }, t))
						}),
						M?.assistant === T && !M.used && !d && /* @__PURE__ */ l("div", {
							className: "doe-detail-actions",
							children: [/* @__PURE__ */ c("button", {
								disabled: !F.length,
								onClick: () => {
									let e = F.find((e) => e.type === "assistant" && !e.targets.length);
									g(i), E(null), e ? V(e) : (O(!0), A([]), [
										13,
										15,
										16
									].includes(T) ? w("forest") : w("lab"));
								},
								children: f("games.dropsofevil.useAssistant")
							}), ["worm", "cheese"].map((e) => /* @__PURE__ */ c("button", {
								disabled: !P.some((t) => t.type === "tradeAssistant" && t.resource === e),
								onClick: () => {
									V({
										type: "tradeAssistant",
										resource: e
									}), E(null);
								},
								children: f(e === "worm" ? "games.dropsofevil.tradeWorm" : "games.dropsofevil.tradeCheese")
							}, e))]
						})
					]
				})
			}),
			D !== null && /* @__PURE__ */ c("div", {
				className: "doe-modal",
				role: "dialog",
				"aria-modal": "true",
				children: /* @__PURE__ */ l("div", {
					className: "doe-detail",
					children: [
						/* @__PURE__ */ c("button", {
							className: "doe-close",
							onClick: () => oe(null),
							"aria-label": f("games.dropsofevil.close"),
							children: "×"
						}),
						/* @__PURE__ */ c(Q, { kind: p.recipes[D].resource }),
						/* @__PURE__ */ c("h2", { children: f(Pe[p.recipes[D].id - 1]) }),
						/* @__PURE__ */ c("p", { children: f(Fe[p.recipes[D].id - 1]) })
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/dropsofevil/fx.tsx
var ze = {
	move(e, t) {
		let n = e.data;
		if (!n?.items?.length) return null;
		let r = t.queued ? 180 : n.ms ?? 350, i = n.items.slice(0, 55), a = [], o = [];
		for (let [e, n] of i.entries()) {
			if (!(n.kind in ye)) continue;
			let i = t.anchor(n.from), s = t.anchor(n.to), l = t.anchor(`seat:${n.rid}`), u = i && i.w > 0 ? i : l, f = s && s.w > 0 ? s : l;
			if (!u || !f || u === f) continue;
			let p = Math.max(21, Math.min(45, u.w, u.h)), m = Math.max(21, Math.min(45, f.w, f.h)), h = {
				x: u.x + (u.w - p) / 2,
				y: u.y + (u.h - p) / 2,
				w: p,
				h: p
			}, g = {
				x: f.x + (f.w - m) / 2,
				y: f.y + (f.h - m) / 2,
				w: m,
				h: m
			};
			!t.queued && n.to.startsWith("cell:") && s && a.push(n.to), o.push(/* @__PURE__ */ c(d, {
				from: h,
				to: g,
				ms: r - Math.min(100, e * 7),
				delay: Math.min(100, e * 7),
				children: /* @__PURE__ */ c("div", {
					style: {
						width: p,
						height: p,
						filter: "drop-shadow(0 3px 2px #09293988)"
					},
					children: /* @__PURE__ */ c(Q, { kind: n.kind })
				})
			}, e));
		}
		return o.length ? {
			ms: r,
			node: /* @__PURE__ */ c(s, { children: o }),
			hide: a
		} : null;
	},
	income(e, t) {
		let n = t.anchor(`seat:${e.rid}`);
		if (!n) return null;
		let r = Number(e.data?.n ?? 0);
		return {
			ms: 650,
			node: /* @__PURE__ */ c(u, {
				at: n,
				ms: 650,
				children: /* @__PURE__ */ l("span", {
					style: {
						background: "#e9e8b2",
						color: "#133d45",
						padding: "4px 9px",
						borderRadius: 12
					},
					children: [r >= 0 ? "+" : "", r]
				})
			})
		};
	}
};
//#endregion
//#region src/games/dropsofevil/game-over.tsx
function Be(e) {
	let t = r(), i = e.public, [a, o] = n(!0), [u, d] = n(null), p = Object.fromEntries(i.players.map((e) => [e.rid, fe(e, i.recipes)])), m = [
		{
			label: t("games.dropsofevil.incomeScore"),
			values: e.result.ranking.map((e) => p[e].income)
		},
		{
			label: t("games.dropsofevil.vialPoints"),
			values: e.result.ranking.map((e) => p[e].vials)
		},
		{
			label: t("games.dropsofevil.ratPoints"),
			values: e.result.ranking.map((e) => p[e].rats)
		},
		...i.recipes.map((n, r) => ({
			label: /* @__PURE__ */ l("span", {
				className: "flex items-center gap-1",
				children: [/* @__PURE__ */ c("span", {
					className: "inline-block size-6",
					children: /* @__PURE__ */ c(Q, { kind: n.resource })
				}), t(Pe[n.id - 1])]
			}),
			values: e.result.ranking.map((e) => p[e].recipe[r])
		}))
	];
	return /* @__PURE__ */ l("div", {
		className: "doe-screen",
		children: [
			/* @__PURE__ */ c(Re, {
				public: i,
				members: e.members,
				myRid: e.myRid,
				send: () => void 0,
				readOnly: !0
			}),
			!a && /* @__PURE__ */ c("button", {
				className: "doe-result-reopen",
				onClick: () => o(!0),
				children: t("games.dropsofevil.result")
			}),
			a && /* @__PURE__ */ c("div", {
				className: "doe-result-layer",
				children: /* @__PURE__ */ l("div", {
					className: "doe-result-paper",
					children: [
						/* @__PURE__ */ c(f, {}),
						/* @__PURE__ */ c("button", {
							className: "doe-close",
							onClick: () => o(!1),
							"aria-label": t("games.dropsofevil.review"),
							children: "⌄"
						}),
						/* @__PURE__ */ l("div", {
							className: "doe-result-title",
							children: [/* @__PURE__ */ c("h1", { children: "Drops of Evil" }), /* @__PURE__ */ c("span", { children: t("games.dropsofevil.done") })]
						}),
						/* @__PURE__ */ l("div", {
							className: "doe-result-body",
							children: [
								/* @__PURE__ */ l("table", {
									className: "doe-score-table",
									children: [/* @__PURE__ */ c("thead", { children: /* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", { children: t("games.dropsofevil.done") }), e.result.ranking.map((n, r) => /* @__PURE__ */ l("th", {
										className: e.result.winner.includes(n) ? "is-winner" : "",
										children: [
											r + 1,
											". ",
											e.members.find((e) => e.rid === n)?.name ?? n,
											e.result.winner.includes(n) && /* @__PURE__ */ c("div", { children: t("games.dropsofevil.winner") })
										]
									}, n))] }) }), /* @__PURE__ */ l("tbody", { children: [m.map((e, t) => /* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", { children: e.label }), e.values.map((e, t) => /* @__PURE__ */ c("td", { children: e }, t))] }, t)), /* @__PURE__ */ l("tr", {
										className: "doe-total",
										children: [/* @__PURE__ */ c("th", { children: t("games.dropsofevil.total") }), e.result.ranking.map((t) => /* @__PURE__ */ c("td", { children: e.result.scores?.[t] ?? p[t].total }, t))]
									})] })]
								}),
								e.hintCount !== void 0 && e.hintCount > 0 && /* @__PURE__ */ c("p", {
									className: "doe-result-note",
									children: t("games.dropsofevil.hintCount", { n: e.hintCount })
								}),
								e.result.ranking.some((t) => (e.result.autopilot?.[t] ?? 0) > 0) && /* @__PURE__ */ c("div", {
									className: "doe-result-meta",
									children: e.result.ranking.map((n) => {
										let r = e.result.autopilot?.[n] ?? 0;
										return r > 0 ? /* @__PURE__ */ l("span", { children: [
											e.members.find((e) => e.rid === n)?.name,
											" · ",
											t("games.dropsofevil.autopilot", { n: Math.round(r * 100) })
										] }, n) : null;
									})
								})
							]
						}),
						/* @__PURE__ */ c("div", {
							className: "doe-result-controls",
							children: u ? /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("button", {
								className: "doe-cancel-confirm",
								onClick: () => d(null),
								children: t("games.dropsofevil.cancel")
							}), /* @__PURE__ */ c("button", {
								onClick: () => {
									u === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.(), d(null);
								},
								children: t(u === "again" ? "games.dropsofevil.confirmAgain" : "games.dropsofevil.confirmLobby")
							})] }) : /* @__PURE__ */ l(s, { children: [
								e.onPlayAgain && /* @__PURE__ */ c("button", {
									onClick: () => d("again"),
									children: t("games.dropsofevil.again")
								}),
								e.onBackToLobby && /* @__PURE__ */ c("button", {
									onClick: () => d("lobby"),
									children: t("games.dropsofevil.lobby")
								}),
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ c("span", { children: t("games.dropsofevil.hostWait") })
							] })
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/dropsofevil/options.tsx
function Ve({ value: e, onChange: t }) {
	let n = r(), i = M.safeParse(e).data ?? { twoPlayerSide: "A" };
	return /* @__PURE__ */ c(m, {
		title: n("games.dropsofevil.twoPlayerSide"),
		children: ["A", "B"].map((e) => /* @__PURE__ */ c(p, {
			name: "dropsofevil-two-player-side",
			value: e,
			checked: i.twoPlayerSide === e,
			label: n(e === "A" ? "games.dropsofevil.sideA" : "games.dropsofevil.sideB"),
			accent: w.accent,
			onChange: () => t({
				...i,
				twoPlayerSide: e
			})
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/dropsofevil/entry.tsx
var He = {
	definition: ve,
	View: Le,
	bot: Oe,
	describe: ke,
	fx: ze,
	OverView: Be,
	Options: Ve,
	locales: {
		zh: {
			name: "Drops of Evil",
			desc: "派遣魔宠争夺森林材料，填满试管，酿制最强毒剂。",
			rules: "目标：三轮结束后，毒性分最高者获胜。平分时，最终行动顺序靠前者获胜。\n每轮流程：\n· 按行动顺序轮流放置一个棋子。\n· 乌鸦放在浅色采集格。\n· 猫放在双箭头。\n· 蟾蜍放在四箭头。\n· 蛇放在列顶。\n· 钱袋雇用一名助手。\n已占位置不能再放棋子。\n· 全员放完后，按蛇从左到右确定下一轮顺序。第三轮也更新，用于平分判定。\n· 按乌鸦、猫、蟾蜍、蛇的顺序采集，分别取得对应1格、2格、4格或整列中的全部资源；每遇到1个空格，改为获得1条蠕虫。\n酿制：\n· 所有玩家同时将资源放入炼金板。爪、翼、眼、尾、蠕虫和蜘蛛放入酿造器；蘑菇放入蒸馏器；老鼠进入游离区。\n· 每个格子放一个材料，每支试管只能放同一种材料。蜘蛛是万能材料，但每支已使用的试管都必须至少有一个非蜘蛛材料。\n· 本轮新放的材料可以取回重放。以前轮次的材料不能移动；用于解锁奖励的材料立即锁定。酿制结束时，所有材料锁定。\n· 填满酿造器一列，立即获得该列下方全部奖励，并揭示收入。必须尽可能放完材料；确实没有合法位置的剩余材料在结束酿制时弃掉。\n· 蒸馏器从下向上填入蘑菇，四层容量分别为 1、2、2、2。填满一层，领取该层或更低层的一个剩余奖励。顶层每放两枚蘑菇可重复领取一个剩余奖励。每领取一个蒸馏器奖励，收入增加 1。\n· 奖励包括额外资源和卷轴。卷轴将对应材料的毒性提高 1；第二张同类卷轴额外提高 1。每份奶酪可捕获一只游离老鼠。未使用的额外资源在本轮结束时弃掉。\n· 每轮只能使用一次所雇助手的能力。放置阶段的能力可在自己放棋子之前或之后使用；也可在酿制结束前放弃能力，改为获得一条蠕虫或一份奶酪。点击助手查看完整效果。\n收入与换轮：\n· 每个已揭示收入图标获得 1 分，每只游离老鼠扣 1 分，最低为零。随后收回棋子，森林每格补充一个随机资源，未采走的资源累积。第三轮不补充。\n终局计分：\n· 累计收入分，加上每支填满试管内材料的当前毒性、每只捕获老鼠的当前毒性，以及两份配方的得分。未填满的试管不计分。\n配方要求：\n· 四枚横向相邻的目标材料，每组获得4分。\n· 包含最底格的三枚纵向相邻目标材料，每组获得2分。\n· 最大正交连通区域内的目标材料，每两枚获得1分。\n· 每个含有目标材料的列获得1分。\n· 位于边缘的目标材料，每两枚获得1分。\n· 组成两行两列方阵的目标材料，每组获得3分。\n· 位于不同试管连接两端的目标材料，每对获得2分。\n· L形试管内的目标材料，每两枚获得1分。\n· 同一材料在同一配方中只能计入一次。蜘蛛可以在两份配方中分别作为不同材料，也不受所在试管的材料种类限制。",
			claw: "猫头鹰爪",
			wing: "蝙蝠翼",
			eye: "蝾螈眼",
			tail: "蝎尾",
			spider: "蜘蛛",
			worm: "蠕虫",
			mushroom: "蘑菇",
			rat: "老鼠",
			cheese: "奶酪",
			crow: "乌鸦",
			cat: "猫",
			toad: "蟾蜍",
			snake: "蛇",
			pouch: "钱袋",
			placement: "放置",
			gather: "采集",
			brewing: "酿制",
			income: "收入",
			refill: "准备下一轮",
			done: "终局",
			round: "第 {{n}}／3 轮",
			turn: "轮到 {{name}}",
			yourTurn: "选择魔宠，再选择森林位置",
			brewPrompt: "选择材料，再放入试管",
			waiting: "等待其他玩家",
			forest: "森林",
			lab: "炼金板",
			distiller: "蒸馏器",
			brewer: "酿造器",
			assistants: "助手",
			recipes: "配方",
			toxicity: "毒性",
			freeRats: "游离老鼠",
			capturedRats: "捕获老鼠",
			endTurn: "结束放置回合",
			ready: "结束酿制",
			special: "使用助手放置",
			useAssistant: "使用助手",
			tradeWorm: "改为获得一条蠕虫",
			tradeCheese: "改为获得一份奶酪",
			cancel: "取消",
			close: "关闭",
			chooseBonus: "领取一个蒸馏器奖励",
			returnPiece: "取回本轮材料",
			placed: "已放置",
			used: "已使用",
			available: "可用",
			locked: "已锁定",
			cell: "第 {{n}} 格",
			resourceCount: "{{name}}，{{n}} 枚",
			spot: "{{pawn}}位置，{{n}} 号",
			selectTarget: "选择助手的目标",
			bonus: "奖励",
			scroll: "卷轴",
			incomePoints: "收入 {{n}}",
			points: "{{n}} 分",
			total: "总分",
			vialPoints: "完整试管",
			ratPoints: "捕获老鼠",
			recipePoints: "配方得分",
			incomeScore: "累计收入",
			winner: "获胜",
			review: "回看炼金板",
			result: "查看结算",
			again: "再来一局",
			lobby: "返回大厅",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			hostWait: "等待主机",
			hintCount: "求助 {{n}} 次",
			autopilot: "托管 {{n}}%",
			twoPlayerSide: "双人森林",
			sideA: "A 面（常规）",
			sideB: "B 面（变体）",
			brewHint: "将{{resource}}放入第 {{n}} 格",
			placeHint: "放置{{pawn}}",
			actionHint: "执行当前合法行动",
			invalidAction: "当前不能执行这个行动，请检查阶段、材料和目标。",
			assistantNames: {
				a1: "药剂师",
				a2: "骗子",
				a3: "小屋看守",
				a4: "乌鸦驯师",
				a5: "蠕虫牧人",
				a6: "寻路者",
				a7: "扫灰人",
				a8: "猫夫人",
				a9: "阴森商人",
				a10: "诡术师",
				a11: "屠夫",
				a12: "捕鼠人",
				a13: "拾荒者",
				a14: "智者",
				a15: "驯蛇人",
				a16: "驯兽人",
				a17: "外科医生",
				a18: "偷猎者"
			},
			assistantDescriptions: {
				a1: "酿制时，将炼金板中一只游离或捕获老鼠作为蜘蛛放入酿造器。",
				a2: "酿制时，交换炼金板上两个尚未领取的奖励，可以跨区域交换；随后获得一条蠕虫。",
				a3: "酿制时启用，本轮蒸馏器收入翻倍。",
				a4: "放置时，乌鸦可以放在双箭头，并作为猫采集。",
				a5: "酿制时，获得两条蠕虫。",
				a6: "放置时，乌鸦可以放在深色灌木采集格，并获得一条蠕虫。",
				a7: "酿制时，选择尚缺一或两个材料的未满列，提前获得该列全部奖励。",
				a8: "放置时，猫可以放在四箭头，并作为蟾蜍采集。",
				a9: "每轮开始从袋中存入一个非老鼠资源；酿制时取走此处全部资源。",
				a10: "酿制时，将资源池中的一枚蜘蛛横跨同一试管的两个空格，分别视为蜘蛛。",
				a11: "酿制时，将资源池的一条蠕虫，或一只游离或捕获老鼠，作为蘑菇放入蒸馏器。",
				a12: "酿制时，捕获全部游离老鼠。",
				a13: "酿制时，取走森林中任意一个仍有资源的采集格内全部资源。",
				a14: "放置时，收回自己已放置的一只魔宠。钱袋不能收回；本轮会多一次放置。",
				a15: "放置时，从自己蛇所在列选择一个未被对手优先占取的采集格，立即取走其中全部资源。",
				a16: "放置时，将一个未被对手优先占取的采集格内全部资源移到正交相邻格。目标格可以被占取。",
				a17: "收入时，每只捕获老鼠额外获得 1 分。结束酿制后自动结算此能力。",
				a18: "放置时，直接捕获自己蟾蜍周围四个采集格中的全部老鼠，不受对手占取影响。"
			},
			recipeNames: {
				a1: "毒性分层",
				a2: "邪恶沉积",
				a3: "渗流团块",
				a4: "蔓延疫病",
				a5: "污浊表层",
				a6: "诅咒凝块",
				a7: "腐化连接",
				a8: "蜿蜒毒液"
			},
			recipeDescriptions: {
				a1: "同一行横向四枚，每组 4 分。",
				a2: "包含列最底格的纵向三枚，每组 2 分。",
				a3: "最大正交连通区域，每两枚 1 分。",
				a4: "每个含目标材料的列 1 分。",
				a5: "边缘目标材料，每两枚 1 分。",
				a6: "两行两列的目标材料方阵，每组 3 分。",
				a7: "不同试管连接两端的目标材料，每对 2 分。",
				a8: "L 形试管内目标材料，每两枚 1 分。"
			}
		},
		en: {
			name: "Drops of Evil",
			desc: "Send familiars into the forest, fill your vials, and brew the deadliest poison.",
			rules: "Goal: After three rounds, the most Poison Points wins. Ties go to the player earlier in the final turn order.\nRound sequence:\n· In turn order, place one pawn in its matching position:\n· Crow: on a light clearing space.\n· Cat: on a double arrow.\n· Toad: on four arrows.\n· Snake: above a column.\n· Coin Pouch: on an Assistant.\nOccupied positions cannot be used.\n· After all pawns are placed, Snakes from left to right set the next turn order, including in the final round for ties.\n· Gather in order: Crows, Cats, Toads, then Snakes. They collect all resources from one, two, four, or an entire column of spaces. Each empty space yields exactly one Worm instead.\nBrewing:\n· Players brew simultaneously. Claws, Wings, Eyes, Tails, Worms, and Spiders go in the Brewer. Mushrooms go in the Distiller. Rats enter the Free Rats area.\n· Each space holds one Ingredient. Each Vial must contain only one type, except for wildcard Spiders. Every used Vial must contain at least one non-Spider Ingredient.\n· New Ingredients may be returned and rearranged during this round. Ingredients from earlier rounds cannot move. Ingredients that unlock a bonus become locked immediately. All Ingredients lock when Brewing ends.\n· Complete a Brewer column to gain all bonuses below it and reveal its Income. Place every resource if possible; discard remaining resources only when they have no legal space.\n· Fill Distiller Vials from bottom to top, with capacities 1, 2, 2, and 2. Completing a Vial lets you take one remaining bonus at its level or below. The top Vial repeats for every pair of Mushrooms. Each Distiller bonus reveals one Income icon.\n· Bonuses grant extra resources or Scrolls. A Scroll raises its resource Toxicity by one; a second matching Scroll grants one additional step. Each Cheese captures one Free Rat. Unused extra resources are discarded at round end.\n· Use your hired Assistant once per round. Placement abilities may be used before or after your pawn placement on your own turn. Before Brewing ends, you may forgo the ability for one Worm or one Cheese. Select an Assistant to read its complete effect.\nIncome and next round:\n· Gain one point per revealed Income icon and lose one per Free Rat, to a minimum of zero points. Retrieve pawns and add one random resource to every forest space. Uncollected resources accumulate. Do not refill after round three.\nFinal scoring:\n· Add accumulated Income points, current ingredient Toxicity for each completed Vial, current Rat Toxicity for each Captured Rat, and both Recipes. Incomplete Vials score nothing.\nRecipe patterns:\n· Four horizontally adjacent Ingredients score 4.\n· Three vertical Ingredients including the bottom space score 2.\n· Each pair in the largest orthogonal group scores 1.\n· Each occupied column scores 1.\n· Each pair on the Brewer edge scores 1.\n· A 2×2 square scores 3.\n· A pair across a connection between different Vials scores 2.\n· Each pair in L-shaped Vials scores 1.\n· An Ingredient may count only once per Recipe. Spiders may represent different Ingredients for each Recipe, independently of their Vial's Ingredient type.",
			claw: "Owl Claw",
			wing: "Bat Wing",
			eye: "Salamander Eye",
			tail: "Scorpion Tail",
			spider: "Spider",
			worm: "Worm",
			mushroom: "Mushroom",
			rat: "Rat",
			cheese: "Cheese",
			crow: "Crow",
			cat: "Cat",
			toad: "Toad",
			snake: "Snake",
			pouch: "Coin Pouch",
			placement: "Placement",
			gather: "Gathering",
			brewing: "Brewing",
			income: "Income",
			refill: "Next round",
			done: "Final score",
			round: "Round {{n}} / 3",
			turn: "{{name}}’s turn",
			yourTurn: "Select a familiar, then a forest position",
			brewPrompt: "Select an Ingredient, then a Vial space",
			waiting: "Waiting for other players",
			forest: "Forest",
			lab: "Alchilab",
			distiller: "Distiller",
			brewer: "Brewer",
			assistants: "Assistants",
			recipes: "Recipes",
			toxicity: "Toxicity",
			freeRats: "Free Rats",
			capturedRats: "Captured Rats",
			endTurn: "End placement turn",
			ready: "Finish Brewing",
			special: "Use placement ability",
			useAssistant: "Use Assistant",
			tradeWorm: "Take one Worm instead",
			tradeCheese: "Take one Cheese instead",
			cancel: "Cancel",
			close: "Close",
			chooseBonus: "Take one Distiller bonus",
			returnPiece: "Return new Ingredient",
			placed: "Placed",
			used: "Used",
			available: "Available",
			locked: "Locked",
			cell: "Space {{n}}",
			resourceCount: "{{name}}: {{n}}",
			spot: "{{pawn}} position {{n}}",
			selectTarget: "Choose Assistant targets",
			bonus: "Bonus",
			scroll: "Scroll",
			incomePoints: "Income {{n}}",
			points: "{{n}} points",
			total: "Total",
			vialPoints: "Completed Vials",
			ratPoints: "Captured Rats",
			recipePoints: "Recipes",
			incomeScore: "Income earned",
			winner: "Winner",
			review: "Review Alchilabs",
			result: "Show results",
			again: "Play again",
			lobby: "Back to lobby",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm lobby",
			hostWait: "Waiting for host",
			hintCount: "Hints: {{n}}",
			autopilot: "Autopilot {{n}}%",
			twoPlayerSide: "Two-player forest",
			sideA: "Side A (regular)",
			sideB: "Side B (variant)",
			brewHint: "Place {{resource}} in space {{n}}",
			placeHint: "Place your {{pawn}}",
			actionHint: "Perform the selected legal action",
			invalidAction: "This action is unavailable. Check the phase, resources, and targets.",
			assistantNames: {
				a1: "Apothecary",
				a2: "Swindler",
				a3: "Hutkeeper",
				a4: "Raven Master",
				a5: "Worm Herder",
				a6: "Pathfinder",
				a7: "Ash Sweeper",
				a8: "Cat Lady",
				a9: "Grim Merchant",
				a10: "Trickster",
				a11: "Butcher",
				a12: "Rat Catcher",
				a13: "Scavenger",
				a14: "Sage",
				a15: "Snake Charmer",
				a16: "Beast Tamer",
				a17: "Surgeon",
				a18: "Poacher"
			},
			assistantDescriptions: {
				a1: "Brewing: place one Free or Captured Rat in your Brewer as a Spider.",
				a2: "Brewing: swap any two unclaimed bonuses, even across areas, then gain one Worm.",
				a3: "Brewing: double your Distiller Income this round.",
				a4: "Placement: your Crow may use a double-arrow space and gather as a Cat.",
				a5: "Brewing: gain two Worms.",
				a6: "Placement: place your Crow in the underbrush and gain one Worm.",
				a7: "Brewing: choose an incomplete column missing at most two Ingredients and take all its bonuses.",
				a8: "Placement: your Cat may use a four-arrow space and gather as a Toad.",
				a9: "Each round, store one non-Rat resource from the bag here. Brewing: take all stored resources.",
				a10: "Brewing: stretch one Spider from your pool across two empty spaces in one Vial. Each counts as a Spider.",
				a11: "Brewing: use one Worm from your pool or one Free or Captured Rat as a Mushroom in your Distiller.",
				a12: "Brewing: capture all your Free Rats.",
				a13: "Brewing: take all resources from any one forest space that still contains resources.",
				a14: "Placement: retrieve one of your placed Familiars, excluding your Coin Pouch. You gain an extra placement this round.",
				a15: "Placement: take all resources from one space in your Snake’s column that is not claimed by an opponent.",
				a16: "Placement: move all resources from a space not claimed by an opponent to an orthogonally adjacent space. The destination may be claimed.",
				a17: "Income: gain one additional point per Captured Rat. Resolves automatically after Brewing.",
				a18: "Placement: capture all Rats in the four spaces surrounding your Toad, even if opponents claim those spaces."
			},
			recipeNames: {
				a1: "Toxic Layers",
				a2: "Wicked Sediment",
				a3: "Oozing Mass",
				a4: "Spreading Blight",
				a5: "Tainted Patina",
				a6: "Cursed Clumps",
				a7: "Corrupted Bonds",
				a8: "Winding Venom"
			},
			recipeDescriptions: {
				a1: "Four horizontally adjacent Ingredients: 4 points per group.",
				a2: "Three vertical Ingredients including the bottom space: 2 points per group.",
				a3: "Largest orthogonal group: 1 point per pair.",
				a4: "1 point per column containing the Ingredient.",
				a5: "Brewer edge: 1 point per pair.",
				a6: "2×2 square: 3 points per group.",
				a7: "Across a connection between different Vials: 2 points per pair.",
				a8: "L-shaped Vials: 1 point per pair."
			}
		}
	}
};
//#endregion
export { He as default };
