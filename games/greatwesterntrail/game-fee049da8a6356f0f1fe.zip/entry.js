import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { SheetFxProbe as o, SheetView as s } from "@bgparty/sdk/sheet-view";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { seatName as u } from "@bgparty/sdk/ui/player-strip";
import { useI18nSettings as d } from "@bgparty/sdk/i18n";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as v, OptionSection as y, OptionSwitch as ee } from "@bgparty/sdk/ui/game-options";
//#region src/games/greatwesterntrail/meta.ts
var te = {
	id: "greatwesterntrail",
	tier: "alpha",
	mechanics: [
		"deck-bag-building",
		"hand-management",
		"route-building",
		"engine-building",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.greatwesterntrail.name",
	descKey: "games.greatwesterntrail.desc",
	rulesKey: "games.greatwesterntrail.rules",
	icon: "🐂",
	iconImg: "games/greatwesterntrail.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/2128570108371842667/888D1135BF4A768EA63F5C89AC53BCA4D45A4E39/" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [3],
	accent: "#476d57",
	releasedAt: "2026-11-04T22:36:54+08:00",
	search: {
		py: "da xi bu kai tuo zhe",
		init: "dxbktz"
	},
	hotseat: "cover",
	botDelayMs: 600
}, b = [
	"cowboy",
	"builder",
	"engineer"
], x = (e, t = 1, n, r) => ({
	kind: e,
	n: t,
	arg: n,
	cost: r
}), S = (e, t, n) => ({
	kind: "discard",
	arg: e,
	n: t,
	then: n
}), C = {
	A: [
		[S("galloway", 1, [x("money", 2)])],
		[x("hire")],
		[x("hire", 1, void 0, 2)]
	],
	B: [[S("santa", 1, [x("money", 2)])], [x("build", 2)]],
	C: [[x("cert"), x("objective")], [x("train", 0, "engineer")]],
	D: [[x("bounty"), x("train", 2, void 0, 2)], [x("aux", 2)]],
	E: [[S("pair", 2, [x("money", 4)])], [x("hazard", 1, void 0, 7)]],
	F: [[S("pineywoods", 1, [x("money", 2)])], [x("market")]],
	G: [[x("train", 0, "engineer")], [x("aux", 2)]]
}, w = {
	"1a": {
		builders: 1,
		vp: 1,
		hands: "g",
		actions: [[x("money", 2, "woods")]]
	},
	"2a": {
		builders: 1,
		vp: 1,
		hands: "",
		actions: [[S("galloway", 1, [x("money", 4)])], [x("market")]]
	},
	"3a": {
		builders: 1,
		vp: 1,
		hands: "",
		actions: [[S("pair", 2, [x("money", 3)])], [x("herder", 1)]]
	},
	"4a": {
		builders: 2,
		vp: 3,
		hands: "b",
		actions: [[x("hazard", 1, void 0, 5)], [x("herder", 2)]]
	},
	"5a": {
		builders: 3,
		vp: 4,
		hands: "",
		actions: [[S("value3", 1, [x("money", 7)])], [x("aux", 2)]]
	},
	"6a": {
		builders: 4,
		vp: 5,
		hands: "",
		actions: [[x("hire", 1, void 0, -1)], [x("train", 0, "engineer")]]
	},
	"7a": {
		builders: 5,
		vp: 6,
		hands: "bg",
		actions: [[x("pairs")]]
	},
	"8a": {
		builders: 5,
		vp: 6,
		hands: "g",
		actions: [[x("bounty"), x("aux", 2)], [x("train", 2)]]
	},
	"9a": {
		builders: 7,
		vp: 9,
		hands: "",
		actions: [[x("train", 3)], [x("extraDelivery")]]
	},
	"10a": {
		builders: 9,
		vp: 13,
		hands: "b",
		actions: [[x("cert", 6)], [x("herder", 5)]]
	},
	"11a": {
		builders: 12,
		vp: 20,
		hands: "",
		actions: [[x("hazard", 1, void 0, 2)], [x("hazard", 1, void 0, 2)]]
	},
	"12a": {
		builders: 4,
		vp: 5,
		hands: "",
		actions: [[x("money", 1, "builder")], [x("herder", 1)]]
	},
	"1b": {
		builders: 1,
		vp: 1,
		hands: "g",
		actions: [[S("objective", 1, [x("cert", 2)])], [x("backMoney", 1)]]
	},
	"2b": {
		builders: 1,
		vp: 1,
		hands: "",
		actions: [[S("santa", 1, [x("train", 2)])], [S("criollo", 1, [x("money", 2)])]]
	},
	"3b": {
		builders: 2,
		vp: 3,
		hands: "",
		actions: [[x("aux", 2)], [x("herder", 1)]]
	},
	"4b": {
		builders: 2,
		vp: 3,
		hands: "bg",
		actions: [[x("cycle", 0, "cowboy")], [x("herder", 3)]]
	},
	"5b": {
		builders: 3,
		vp: 4,
		hands: "",
		actions: [[S("pineywoods", 1, [x("cert", 2)])], [x("money", 1, "engineer")]]
	},
	"6b": {
		builders: 4,
		vp: 5,
		hands: "",
		actions: [[x("copy")]]
	},
	"7b": {
		builders: 5,
		vp: 6,
		hands: "bg",
		actions: [[x("train", 0, "woods")]]
	},
	"8b": {
		builders: 6,
		vp: 8,
		hands: "",
		actions: [[S("cattle", 1, [x("money", 6), x("objective", 1, "hand")])]]
	},
	"9b": {
		builders: 6,
		vp: 8,
		hands: "",
		actions: [[x("stationBehind")]]
	},
	"10b": {
		builders: 8,
		vp: 11,
		hands: "b",
		actions: [
			[x("money", 4)],
			[x("train", 4)],
			[x("herder", 4)]
		]
	},
	"11b": {
		builders: 5,
		vp: 10,
		hands: "",
		actions: [[x("train", 0, "hazards")]]
	},
	"12b": {
		builders: 3,
		vp: 4,
		hands: "",
		actions: [[x("money", 2, "stations")], [x("exchange")]]
	}
}, ne = [];
function T(e, t, n, r, i = "building", a = {}) {
	ne.push({
		id: e,
		x: t,
		y: n,
		next: r,
		type: i,
		...a
	});
}
T("start", 950, 950, ["A"], "start"), T("A", 824, 826, ["a1", "f1"], "neutral"), T("a1", 710, 810, ["a2"]), T("a2", 595, 795, ["a3"]), T("a3", 484, 783, ["B"]);
for (let e = 1; e <= 4; e++) T(`f${e}`, 885 - e * 65, 930 - e * 4, [e === 4 ? "a4" : `f${e + 1}`], "hazard", {
	region: "flood",
	index: e - 1
});
T("a4", 540, 900, ["a5"], "building", { risk: "cattle" }), T("a5", 432, 895, ["B"], "building", {
	woods: !0,
	risk: "criollo"
}), T("B", 325, 895, ["b1", "d1"], "neutral"), T("b1", 350, 752, ["b2"], "building", { woods: !0 }), T("b2", 365, 652, ["b3"]), T("b3", 430, 563, ["C"]);
for (let e = 1; e <= 4; e++) T(`d${e}`, 250 + e * 4, 855 - e * 70, [e === 4 ? "b4" : `d${e + 1}`], "hazard", {
	region: "drought",
	index: e - 1
});
T("b4", 290, 490, ["C"], "building", { risk: "cattle" }), T("C", 480, 465, ["c1", "D"], "neutral"), T("c1", 590, 435, ["c2"], "building", { woods: !0 }), T("c2", 700, 427, ["E"], "building", { woods: !0 }), T("D", 590, 545, ["c0", "o4"], "neutral"), T("c0", 700, 530, ["E"]), [
	[610, 630],
	[680, 630],
	[735, 630],
	[480, 690],
	[535, 700],
	[590, 715],
	[640, 725],
	[695, 725],
	[750, 715]
].forEach(([e, t], n) => T(`o${n + 1}`, e, t, n < 3 ? [] : [n === 8 ? "c3" : `o${n + 2}`], "outlaw", { index: n })), T("c3", 820, 685, ["c4"], "building", { risk: "cattle" }), T("c4", 820, 585, ["E"], "building", { risk: "criollo" }), T("E", 820, 480, ["e1", "r1"], "neutral"), T("e1", 735, 335, ["e2"]), T("e2", 610, 335, ["F"], "building", { woods: !0 });
for (let e = 1; e <= 4; e++) T(`r${e}`, 850 - Math.max(0, e - 3) * 35, 435 - e * 62, [e === 4 ? "e3" : `r${e + 1}`], "hazard", {
	region: "rockfall",
	index: e - 1
});
T("e3", 720, 215, ["e4"], "building", { risk: "cattle" }), T("e4", 610, 215, ["F"], "building", {
	woods: !0,
	risk: "criollo"
}), T("F", 500, 245, ["f5", "f6"], "neutral"), T("f5", 397, 255, ["G"]), T("f6", 470, 375, ["G"], "building", { woods: !0 }), T("G", 350, 345, ["g1"], "neutral"), T("g1", 240, 325, ["g2"]), T("g2", 275, 210, ["kc"]), T("kc", 170, 165, [], "kc");
var E = ne, D = Object.fromEntries(ne.map((e) => [e.id, e])), re = [
	{
		name: "kansas",
		value: 0,
		dark: !1
	},
	{
		name: "fulton",
		value: 1,
		dark: !1
	},
	{
		name: "stlouis",
		value: 4,
		dark: !1
	},
	{
		name: "bloomington",
		value: 6,
		dark: !1
	},
	{
		name: "peoria",
		value: 8,
		dark: !1
	},
	{
		name: "chicago",
		value: 10,
		dark: !0
	},
	{
		name: "toledo",
		value: 12,
		dark: !0
	},
	{
		name: "pittsburgh",
		value: 14,
		dark: !1
	},
	{
		name: "philadelphia",
		value: 16,
		dark: !1
	},
	{
		name: "newyork",
		value: 18,
		dark: !0
	}
], ie = [
	0,
	-3,
	0,
	0,
	0,
	6,
	8,
	4,
	6
], ae = {
	1: "objective",
	2: "exchange",
	3: "objective",
	4: "objective"
}, O = [
	3.5,
	4.5,
	5.5,
	7.5,
	9.5,
	10.5,
	11.5,
	13.5,
	15.5,
	16.5
], k = [
	4,
	7,
	10,
	13,
	16,
	21,
	25,
	29,
	33,
	39
].map((e, t) => ({
	at: e,
	cost: [
		2,
		2,
		4,
		4,
		6,
		8,
		7,
		6,
		5,
		3
	][t],
	vp: [
		1,
		1,
		2,
		2,
		3,
		5,
		6,
		7,
		8,
		9
	][t],
	dark: t >= 4
})), oe = [
	6,
	6,
	7,
	5,
	7,
	9,
	6,
	8,
	10,
	6,
	5,
	4
], se = [
	"exchange",
	1,
	2,
	3,
	4,
	5,
	6,
	8,
	10
], ce = [
	"money1",
	"cycle1",
	"cert0",
	"cert1",
	"train0",
	"train1",
	"thin0",
	"thin1",
	"move0",
	"move1",
	"hand0",
	"hand1",
	"limit4",
	"limit6"
], le = /* @__PURE__ */ new Set([
	"move0",
	"move1",
	"hand0",
	"hand1",
	"limit6"
]), A = {
	criollo: {
		breed: "criollo",
		value: 1,
		vp: 0,
		color: "#c8c4b7"
	},
	santa: {
		breed: "santa",
		value: 2,
		vp: 0,
		color: "#779252"
	},
	pineywoods: {
		breed: "pineywoods",
		value: 2,
		vp: 0,
		color: "#333f3a"
	},
	galloway: {
		breed: "galloway",
		value: 2,
		vp: 0,
		color: "#ede5cd"
	},
	longhorn: {
		breed: "longhorn",
		value: 3,
		vp: 2,
		color: "#e1b946"
	},
	angus: {
		breed: "angus",
		value: 3,
		vp: 1,
		color: "#b94439"
	},
	corriente: {
		breed: "corriente",
		value: 3,
		vp: 3,
		color: "#4e91b0"
	},
	shorthorn3: {
		breed: "shorthorn",
		value: 4,
		vp: 3,
		color: "#8c6941"
	},
	shorthorn4: {
		breed: "shorthorn",
		value: 4,
		vp: 4,
		color: "#8c6941"
	},
	shorthorn5: {
		breed: "shorthorn",
		value: 4,
		vp: 5,
		color: "#8c6941"
	},
	hereford5: {
		breed: "hereford",
		value: 5,
		vp: 5,
		color: "#675080"
	},
	hereford6: {
		breed: "hereford",
		value: 5,
		vp: 6,
		color: "#675080"
	},
	hereford7: {
		breed: "hereford",
		value: 5,
		vp: 7,
		color: "#675080"
	},
	simmental1: {
		breed: "simmental",
		value: 2,
		vp: 3,
		color: "#cf7240"
	},
	simmental2: {
		breed: "simmental",
		value: 4,
		vp: 4,
		color: "#cf7240"
	},
	simmental3: {
		breed: "simmental",
		value: 5,
		vp: 5,
		color: "#cf7240"
	}
}, j = (e, t, n, r, i = []) => ({
	image: e,
	tasks: t,
	vp: n,
	penalty: r,
	immediate: i
}), M = {
	s0: j(24, {
		cow3: 1,
		cow4: 1,
		building: 1
	}, 3, 0),
	s1: j(26, {
		station: 2,
		green: 1
	}, 3, 0),
	s2: j(27, {
		orange: 1,
		hazard: 2
	}, 3, 0),
	s3: j(28, {
		building: 2,
		hazard: 1
	}, 3, 0),
	q0: j(65, {
		building: 1,
		orange: 1,
		hazard: 2
	}, 5, 3, [x("train", 3)]),
	q1: j(66, {
		station: 2,
		building: 2
	}, 5, 2, [x("ride", 3)]),
	q2: j(67, {
		station: 2,
		hazard: 1
	}, 3, 2, [x("money", 2)]),
	q3: j(68, { ny: 1 }, 5, 3, [x("aux", 2)]),
	q4: j(69, {
		building: 1,
		green: 1,
		orange: 1
	}, 3, 2, [x("money", 2)]),
	q5: j(70, {
		cow3: 3,
		building: 1
	}, 4, 2, [x("money", 2)]),
	q6: j(71, {
		building: 1,
		orange: 2
	}, 3, 2, [x("money", 2)]),
	q7: j(72, {
		station: 2,
		orange: 2
	}, 5, 2, [x("ride", 3)]),
	q8: j(73, {
		cow5: 1,
		hazard: 1
	}, 3, 2, [x("cycle", 3)]),
	q9: j(74, {
		cow3: 1,
		cow4: 1,
		cow5: 1
	}, 5, 3, [x("train", 2)]),
	q10: j(75, {
		cow4: 2,
		station: 1,
		green: 1
	}, 5, 3, [x("train", 2)]),
	q11: j(76, {
		building: 2,
		hazard: 1
	}, 3, 2, [x("cycle", 3)]),
	q12: j(77, { ny: 1 }, 5, 3, [x("aux", 2)]),
	q13: j(78, {
		cow4: 1,
		hazard: 2
	}, 3, 2, [x("money", 2)]),
	q14: j(79, { ny: 1 }, 5, 3, [x("aux", 2)]),
	q15: j(80, { ny: 1 }, 5, 3, [x("aux", 2)]),
	q16: j(81, {
		cow3: 3,
		station: 1
	}, 4, 2, [x("cycle", 3)]),
	q17: j(82, {
		cow3: 1,
		cow4: 1,
		cow5: 1
	}, 5, 2, [x("ride", 3)]),
	q18: j(83, {
		cow3: 1,
		cow4: 1,
		hazard: 2
	}, 5, 2, [x("ride", 3)]),
	q19: j(84, {
		station: 1,
		green: 2
	}, 3, 2, [x("cycle", 3)]),
	q20: j(85, {
		station: 1,
		green: 1,
		orange: 1
	}, 3, 2, [x("cycle", 3)]),
	q21: j(86, {
		building: 2,
		green: 2
	}, 5, 3, [x("train", 2)]),
	q22: j(87, {
		building: 2,
		hazard: 2
	}, 5, 2, [x("ride", 3)]),
	q23: j(88, {
		station: 2,
		hazard: 2
	}, 5, 3, [x("train", 3)])
}, N = [
	{
		image: 186,
		permanent: 2,
		score: "none",
		action: []
	},
	{
		image: 188,
		permanent: 1,
		score: "stations",
		action: []
	},
	{
		image: 189,
		permanent: 1,
		score: "certificates",
		action: []
	},
	{
		image: 190,
		permanent: 0,
		score: "none",
		action: [x("money", 12)]
	},
	{
		image: 191,
		permanent: 1,
		score: "hazards",
		action: []
	},
	{
		image: 192,
		permanent: 0,
		score: "objectives",
		action: [x("masterChoice")]
	},
	{
		image: 193,
		permanent: 0,
		score: "workers",
		action: [x("money", 2)]
	},
	{
		image: 194,
		permanent: 0,
		score: "buildings",
		action: [x("cert", 2)]
	},
	{
		image: 195,
		permanent: 1,
		score: "outlaws",
		action: []
	}
], P = [
	{
		id: 1,
		move: 1,
		action: "hireCheap"
	},
	{
		id: 2,
		move: 1,
		action: "hireSpecial"
	},
	{
		id: 3,
		move: 2,
		action: "market"
	},
	{
		id: 4,
		move: 2,
		action: "build"
	},
	{
		id: 5,
		move: 1,
		action: "train"
	},
	{
		id: 6,
		move: 2,
		action: "train"
	},
	{
		id: 7,
		move: 1,
		action: "objective"
	},
	{
		id: 8,
		move: 1,
		action: "bounty"
	},
	{
		id: 9,
		move: 1,
		action: "hazard"
	},
	{
		id: 10,
		move: -1,
		action: "marketSpecial"
	},
	{
		id: 11,
		move: -1,
		action: "buildSpecial"
	},
	{
		id: 12,
		move: -1,
		action: "trainSpecial"
	},
	{
		id: 13,
		move: -2,
		action: "marketAlternative"
	},
	{
		id: 14,
		move: -2,
		action: "buildAlternative"
	},
	{
		id: 15,
		move: -2,
		action: "trainAlternative"
	}
], F = t.object({
	buildings: t.enum([
		"a",
		"b",
		"mixed"
	]).default("a"),
	randomNeutral: t.boolean().default(!1),
	simmental: t.boolean().default(!1),
	soloDifficulty: t.enum([
		"easy",
		"medium",
		"hard"
	]).default("medium")
}).default({
	buildings: "a",
	randomNeutral: !1,
	simmental: !1,
	soloDifficulty: "medium"
}), I = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().min(1).max(2e3)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), ue = t.object({
	id: t.string(),
	kind: t.string(),
	target: t.string().default(""),
	group: t.string().default(""),
	amount: t.number().default(0),
	cost: t.number().default(0),
	cards: t.array(t.string()).default([]),
	path: t.array(t.string()).default([]),
	detail: t.string().default("")
}), L = t.object({
	id: t.string(),
	kind: t.enum([
		"cowboy",
		"builder",
		"engineer",
		"orange",
		"green",
		"flood",
		"drought",
		"rockfall"
	]),
	hand: t.string(),
	vp: t.int(),
	bag: t.int()
}), de = t.object({
	rid: t.string(),
	sam: t.boolean(),
	money: t.int(),
	exchange: t.int(),
	position: t.string(),
	train: t.number(),
	workers: t.record(t.string(), t.int()),
	certificates: t.int(),
	permanent: t.int(),
	discs: t.array(t.string()),
	cities: t.array(t.int()),
	stations: t.array(t.int()),
	masters: t.array(t.int()),
	hazards: t.array(L),
	outlaws: t.array(L),
	buildings: t.array(t.string()),
	removedBuildings: t.array(t.string()),
	objectives: t.array(t.string()),
	handCount: t.int(),
	deckCount: t.int(),
	discard: t.array(t.string()),
	first: t.boolean(),
	specialization: t.string(),
	deliveries: t.int()
}), fe = t.object({
	rid: t.string(),
	categories: t.array(t.int()),
	total: t.int(),
	objectives: t.array(t.object({
		card: t.string(),
		success: t.boolean(),
		points: t.int()
	}))
}), pe = t.object({
	config: F,
	players: t.array(de),
	turn: t.string(),
	turnNumber: t.int(),
	phase: t.string(),
	task: t.string(),
	motionTask: t.string().optional(),
	taskAmount: t.number(),
	local: t.string(),
	used: t.array(t.string()),
	buildings: t.record(t.string(), t.object({
		owner: t.string(),
		tile: t.string()
	})),
	neutral: t.record(t.string(), t.string()),
	sides: t.array(t.string()),
	hazards: t.record(t.string(), L),
	outlaws: t.record(t.string(), L),
	jobs: t.array(L.nullable()),
	jobProgress: t.int(),
	market: t.array(t.string()),
	marketLayout: t.array(t.string()),
	marketLeft: t.int(),
	foresight: t.array(t.array(L.nullable())),
	objectives: t.array(t.string()),
	objectiveLayout: t.array(t.string()),
	objectiveLeft: t.int(),
	stationMasters: t.array(t.int().nullable()),
	stationWorkers: t.array(t.string().nullable()),
	finalTrigger: t.string().nullable(),
	finalTurns: t.array(t.string()),
	income: t.int(),
	revealed: t.array(t.string()),
	samCard: t.int().nullable(),
	scores: t.array(fe),
	log: t.array(t.object({
		turn: t.int(),
		rid: t.string(),
		kind: t.string(),
		target: t.string(),
		amount: t.number(),
		cards: t.array(t.string())
	}))
}), me = t.object({
	hand: t.array(t.string()),
	handLayout: t.array(t.string()),
	choices: t.array(ue),
	interrupt: t.boolean()
}), R = {
	move: 550,
	card: 650,
	upgrade: 1e3,
	event: 400,
	sam: 650,
	end: 700
}, z = "$sam", B = (e) => e.split("~")[0], V = (e) => A[B(e)], H = (e) => M[B(e)], U = (e) => e.order[e.turnIndex], W = (e) => e.p[U(e)];
function G(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function he(e, t) {
	return `${t}~${e.serial++}`;
}
var ge = (e) => 4 + Number(!e.discs.includes("hand0")) + Number(!e.discs.includes("hand1")), _e = (e) => e.discs.includes("limit4") ? 3 : e.discs.includes("limit6") ? 4 : 6, ve = (e, t) => (t === 4 ? 4 : 3) + (e.discs.includes("move0") ? 0 : t === 2 ? 1 : 2) + Number(!e.discs.includes("move1")), ye = (e) => e.masters.reduce((e, t) => e + N[t].permanent, 0);
function be(e, t, n) {
	let r = [];
	for (let i = 0; i < n; i++) {
		if (!t.deck.length) {
			if (!t.discard.length) break;
			t.deck = G(e, t.discard), t.discard = [];
		}
		r.push(t.deck.shift());
	}
	return t.hand.push(...r), r;
}
var K = (e, t, n = "", r = 0, i = [], a = U(e)) => {
	e.log.push({
		turn: e.turnNumber,
		rid: a,
		kind: t,
		target: n,
		amount: r,
		cards: i
	}), e.log.length > 120 && e.log.shift();
};
function xe(e, t) {
	e.certificates = Math.min(_e(e), e.certificates + t);
}
function Se(e, t, n = !1) {
	e.hand = e.hand.filter((e) => !t.includes(e)), n || e.discard.push(...t);
}
function Ce(e, t) {
	return Object.entries(e.buildings).filter(([e, n]) => n.owner === t && D[e].woods).length;
}
var we = (e, t) => t === "kc" || D[t].type === "neutral" || t in e.buildings || t in e.hazards || t in e.outlaws;
function Te(e, t, n) {
	let r = e.buildings[n], i = r ? r.owner === t ? "" : w[r.tile].hands : (e.hazards[n] || e.outlaws[n])?.hand || "", a = e.order.length;
	return [...i].reduce((e, t) => e + (t === "g" ? a === 4 ? 1 : 2 : a === 3 ? 1 : 2), 0);
}
function Ee(e, t, n, r = !0) {
	let i = [];
	function a(o, s, c, l) {
		for (let u of D[o].next) {
			let o = [...s, u], d = c + Number(we(e, u)), f = l + Te(e, t, u);
			d > n || !r && u === "kc" || (we(e, u) && i.push({
				at: u,
				path: o,
				cost: f,
				steps: d
			}), u !== "kc" && a(u, o, d, f));
		}
	}
	return a(e.p[t].position, [], 0, 0), i;
}
function De(e, t, n, r = !1) {
	e.lastPath = n;
	for (let i of n) {
		let n = r ? 0 : Te(e, t.rid, i);
		if (n) {
			let r = t.sam ? n : Math.min(t.money, n);
			t.sam || (t.money -= r);
			let a = e.buildings[i]?.owner;
			a && a !== t.rid && a !== "$sam" && (e.p[a].money += r);
		}
	}
	t.position = n[n.length - 1], K(e, "move", t.position, 0, [], t.rid);
}
function Oe(e, t) {
	e.local = t, e.used = [], e.phase = t === "kc" ? "foresight" : "local", e.localTile = e.buildings[t]?.tile || e.neutral[t] || "", e.localOwner = e.buildings[t]?.owner || "", t === "kc" && (e.kcStep = 0, e.income = 0, e.revealed = []);
}
function ke(e, t) {
	if (e % 1) return [t > 0 ? Math.ceil(e) : Math.floor(e)];
	let n = e + t, r = n >= 0 && n <= 39 ? [n] : [];
	return t > 0 && k.some((t) => t.at === e && e !== 39) && r.push(e + .5), t < 0 && k.some((e) => e.at === n && n !== 39) && r.push(n + .5), r;
}
function Ae(e, t, n, r = 1, i = !1) {
	let a = new Set(e.order.filter((e) => e !== t).map((t) => e.p[t].train).filter((e) => e > 0)), o = /* @__PURE__ */ new Map();
	function s(e, t, n) {
		if (t) for (let c of ke(e, r)) {
			let e = +!a.has(c);
			e && (!i || t === 1) && o.set(c, n + e), s(c, t - e, n + e);
		}
	}
	return s(e.p[t].train, n, 0), [...o].map(([e, t]) => ({
		at: e,
		n: t
	}));
}
function je(e, t, n, r = 0) {
	let i = e.discs.filter((t) => (n || !le.has(t) || !e.discs.some((e) => !le.has(e))) && e.money >= r + (t.startsWith("hand") ? 5 : 0));
	return t.startsWith("station:") ? !i.length && e.money >= r && e.stations.includes(Number(t.slice(8))) : i.includes(t);
}
var Me = (e) => [...e.discs, ...e.stations.map((e) => `station:${e}`)];
function Ne(e, t) {
	if (t.startsWith("station:")) {
		e.stations = e.stations.filter((e) => e !== Number(t.slice(8)));
		return;
	}
	e.discs.splice(e.discs.indexOf(t), 1), t.startsWith("hand") && (e.money -= 5), t === "move0" && (e.money += 3);
}
function q(e, t, n = !0) {
	e.tasks.unshift(...t.map((e) => ({
		...e,
		optional: n
	})));
}
function Pe(e, t) {
	e.market.push(...e.marketDeck.splice(0, t));
}
function Fe(e, t, n = !1) {
	if (b.includes(t.kind)) {
		if (e.jobProgress >= e.jobs.length) return !1;
		e.jobs[e.jobProgress++] = t;
		let r = e.jobProgress / e.order.length;
		return Number.isInteger(r) && [6, 9].includes(r) && Pe(e, Math.max(0, e.order.length * 3 + 1 + (e.config.simmental ? 2 : 0) - e.market.length)), e.jobProgress === e.jobs.length && !n && (e.finalTrigger = U(e), e.finalTurns = [...e.order], K(e, "final")), !0;
	}
	let r = E.find((n) => n.type === (["orange", "green"].includes(t.kind) ? "outlaw" : "hazard") && (n.type === "outlaw" || n.region === t.kind) && !(n.id in e.hazards) && !(n.id in e.outlaws));
	return r ? (r.type === "outlaw" ? e.outlaws[r.id] = t : e.hazards[r.id] = t, !0) : !1;
}
function Ie(e) {
	for (let t = 0; t < 3; t++) {
		let n = e.foresight[t].filter((e) => e !== null);
		e.foresight[t] = [e.bags[t].shift() || null, n[0] || null];
	}
}
function Le(e, t) {
	let n = e.localTile;
	if (!n || e.localOwner && e.localOwner !== t) return [];
	let r = (e.localOwner ? w[n].actions : C[n]).map((e, t) => ({
		key: `${n}:${t}`,
		options: e
	}));
	return e.localOwner && D[e.local].risk && r.push({
		key: `risk:${e.local}`,
		options: [{
			kind: "discard",
			n: 1,
			arg: D[e.local].risk,
			then: [{
				kind: "cert",
				n: 1
			}, ...D[e.local].risk === "criollo" ? [{
				kind: "money",
				n: 2
			}] : []]
		}]
	}), r;
}
function Re(e) {
	let t = W(e);
	if (t.sam || be(e, t, Math.max(0, ge(t) - t.hand.length)), e.finalTrigger && (e.finalTurns = e.finalTurns.filter((e) => e !== t.rid), !e.finalTurns.length)) {
		e.phase = "done", e.scores = ot(e);
		return;
	}
	e.turnIndex = (e.turnIndex + 1) % e.order.length, e.turnNumber++, e.phase = "move", e.local = "", e.used = [], e.usedBuilding = [], e.tasks = [], e.revealed = [], e.samBeat = 0;
	let n = W(e);
	n.first && !n.sam && n.hand.length > 4 && e.tasks.push({
		kind: "discardInitial",
		n: n.hand.length - 4,
		optional: !1
	});
}
function ze(e, t) {
	let n = k.findIndex((e) => e.at === (t === 39 ? 39 : t - .5));
	t === 39 && e.tasks.unshift({
		kind: "railReturn",
		optional: !1
	}), n >= 0 && e.tasks.unshift({
		kind: "station",
		n,
		optional: !0
	});
}
function Be(e) {
	let t = {};
	for (let n of e.hand) {
		let e = V(n);
		e && (t[e.breed] = Math.max(t[e.breed] || 0, e.value));
	}
	return Object.values(t).reduce((e, t) => e + t, 0) + ye(e);
}
function Ve(e, t, n, r, i) {
	let a = new Set(t.cities);
	t.sam ? t.discs.length ? t.discs.pop() : t.stations.shift() : Ne(t, r), t.cities.push(n), t.deliveries++, n === 0 && !t.sam && (t.money += 4), i && !t.sam && (t.money -= O.filter((e) => e > t.train && e < re[n].value).length);
	let o = [];
	for (let r of [n - 1, n + 1]) {
		let i = Math.min(n, r);
		a.has(r) && !a.has(n) && ae[i] && (ae[i] === "exchange" ? t.sam || (t.exchange += 2) : t.sam ? Qe(e) : o.push({
			kind: "objective",
			n: 1
		}));
	}
	o.length && q(e, o, !1), K(e, "delivery", String(n), 0, [], t.rid);
}
function He(e) {
	let t = W(e);
	t.position = "start", Ie(e), Re(e);
}
function Ue(e) {
	e.phase === "foresight" && e.kcStep >= 3 && (e.phase = "income");
}
function We(t, n, r) {
	let i = F.parse(t), a = n.length === 1 ? [...n, z] : [...n], o = {
		config: i,
		humans: n,
		order: a,
		p: {},
		turnIndex: 0,
		turnNumber: 1,
		phase: "move",
		local: "",
		localTile: "",
		localOwner: "",
		used: [],
		usedBuilding: [],
		tasks: [],
		buildings: {},
		neutral: {},
		sides: [],
		hazards: {},
		outlaws: {},
		jobs: Array(12 * a.length).fill(null),
		jobProgress: 0,
		bags: [
			[],
			[],
			[]
		],
		marketDeck: [],
		market: [],
		objectiveDeck: [],
		objectives: [],
		stationMasters: Array(10).fill(null),
		stationWorkers: Array(10).fill(null),
		finalTrigger: null,
		finalTurns: [],
		income: 0,
		revealed: [],
		foresight: [
			[],
			[],
			[]
		],
		kcStep: 0,
		exchangePending: null,
		samDeck: [],
		samDiscard: [],
		samCard: null,
		samBeat: 0,
		samDelivery: i.soloDifficulty === "hard" ? 4 : 3,
		seed: r,
		cursor: 0,
		serial: 0,
		beat: 0,
		log: [],
		scores: []
	}, s = i.randomNeutral ? G(o, Object.keys(C)) : Object.keys(C);
	"ABCDEFG".split("").forEach((e, t) => {
		o.neutral[e] = s[t];
	}), o.sides = Array.from({ length: 12 }, (t, n) => `${n + 1}${i.buildings === "mixed" ? e(r, o.cursor++, 2) ? "b" : "a" : i.buildings}`);
	let c = (e, t, n = "", r = 0) => ({
		id: `t${o.serial++}`,
		kind: e,
		bag: t,
		hand: n,
		vp: r
	});
	for (let e of [
		"flood",
		"drought",
		"rockfall"
	]) for (let [t, n] of [
		[4, "g"],
		[4, "g"],
		[3, "g"],
		[3, "b"],
		[2, "g"],
		[2, "b"]
	]) o.bags[0].push(c(e, 1, n, t));
	for (let [e, t] of [["orange", 8], ["green", 9]]) for (let n = 0; n < t; n++) o.bags[0].push(c(e, 1, e === "green" ? "g" : "b"));
	for (let e of b) {
		for (let t = 0; t < 11; t++) o.bags[1].push(c(e, 2));
		for (let t = 0; t < 7; t++) o.bags[2].push(c(e, 3));
	}
	for (let [e, t] of [["orange", 3], ["green", 2]]) for (let n = 0; n < t; n++) o.bags[2].push(c(e, 3, e === "green" ? "g" : "b"));
	o.bags = o.bags.map((e) => G(o, e));
	let l = 0;
	for (; l < 7;) {
		let e = o.bags[0].shift();
		Fe(o, e, !0) ? l++ : o.bags[0].push(e);
	}
	for (let e = 0; e < a.length * 2 - 1; e++) Fe(o, o.bags[1].shift(), !0);
	for (let [e, t] of Object.entries({
		longhorn: 7,
		angus: 7,
		corriente: 7,
		shorthorn3: 3,
		shorthorn4: 3,
		shorthorn5: 3,
		hereford5: 2,
		hereford6: 2,
		hereford7: 2,
		...i.simmental ? { simmental1: 8 } : {}
	})) for (let n = 0; n < t; n++) o.marketDeck.push(he(o, e));
	o.marketDeck = G(o, o.marketDeck), Pe(o, a.length * 3 + 1 + (i.simmental ? 2 : 0)), o.objectiveDeck = G(o, Array.from({ length: 24 }, (e, t) => `q${t}`)), o.objectives = o.objectiveDeck.splice(0, 4);
	let u = G(o, [
		"s0",
		"s1",
		"s2",
		"s3"
	]), d = G(o, Array.from({ length: 9 }, (e, t) => t));
	for (let e = 0; e < 5; e++) o.stationMasters[e] = d[e];
	a.forEach((e, t) => {
		let n = {
			rid: e,
			sam: e === z,
			money: e === "$sam" ? 0 : 6 + t,
			exchange: e === "$sam" ? 0 : 1,
			position: "start",
			train: 0,
			workers: {
				cowboy: 1,
				builder: 1,
				engineer: 1
			},
			certificates: 0,
			discs: [...ce],
			cities: [],
			stations: [],
			masters: [],
			hazards: [],
			outlaws: [],
			buildings: [],
			removedBuildings: [],
			objectives: [u[t]],
			hand: [],
			deck: [],
			discard: [],
			first: e !== z,
			specialization: "cowboy",
			deliveries: 0
		};
		if (e !== "$sam") {
			for (let [e, t] of Object.entries({
				criollo: 5,
				santa: 3,
				pineywoods: 3,
				galloway: 3
			})) for (let r = 0; r < t; r++) n.deck.push(he(o, e));
			n.deck = G(o, n.deck), be(o, n, 4 + t);
		} else {
			let e = o.bags[1].shift();
			if (n.workers[e.kind]++, n.specialization = e.kind, i.soloDifficulty === "hard") for (let e of b) {
				let t = o.bags[1].findIndex((t) => t.kind === e);
				if (t >= 0) o.bags[1].splice(t, 1);
				else {
					let t = o.bags[2].findIndex((t) => t.kind === e);
					o.bags[2].splice(t, 1);
				}
				n.workers[e]++;
			}
		}
		o.p[e] = n;
	}), o.samDeck = G(o, P.filter((e) => i.soloDifficulty !== "easy" || e.id <= 12).map((e) => e.id));
	for (let e = 0; e < 3; e++) o.foresight[e] = [o.bags[e].shift() || null, o.bags[e].shift() || null];
	return {
		state: o,
		fx: []
	};
}
function Ge(e, t) {
	if (t === 0) return [[]];
	if (t < 0 || t > e.length) return [];
	let n = [];
	return e.forEach((r, i) => {
		for (let a of Ge(e.slice(i + 1), t - 1)) n.push([r, ...a]);
	}), n;
}
function Ke(e, t = "cattle") {
	return e.hand.filter((e) => t === "any" || t === "objective" ? t === "any" || !!H(e) : V(e) && (t === "cattle" || t === "pair" || B(e) === t || t === "value3" && V(e).value === 3 && V(e).breed !== "simmental"));
}
function qe(e, t, n) {
	return Ge(Ke(e, t), n).filter((e) => t !== "pair" || V(e[0]).breed === V(e[1]).breed);
}
function Je(e, t, n) {
	if ([
		"money",
		"cert",
		"exchange",
		"pairs"
	].includes(n.kind)) return !0;
	if (n.kind === "train" && e.p[t].money < (n.cost || 0)) return !1;
	let r = structuredClone(e);
	return J(r, n), Ye(r, t).some((e) => ![
		"exchange",
		"skip",
		"continue"
	].includes(e.choice.kind));
}
function Ye(e, t) {
	if (!e.p[t] || e.p[t].sam || e.phase === "done" || e.beat) return [];
	let n = e.p[t], r = [], i = (e, t = e.op, n = e.a || "", i = e.n || 0, a = 0, o = "", s = "") => {
		r.push({
			cmd: e,
			choice: {
				id: JSON.stringify(e),
				kind: t,
				target: n,
				amount: i,
				cost: a,
				group: o,
				cards: e.cards || [],
				path: e.path || [],
				detail: s
			}
		});
	};
	if (e.exchangePending) {
		if (e.exchangePending.rid === t) for (let t of Ge(n.hand, e.exchangePending.n)) i({
			op: "exchangeDiscard",
			cards: t
		}, "discard");
		return r;
	}
	if (n.exchange && n.deck.length + n.discard.length) for (let e = 1; e <= Math.min(2, n.deck.length + n.discard.length); e++) i({
		op: "exchange",
		n: e
	}, "exchange", "", e, 1);
	if (t !== U(e) || U(e) === "$sam") return r;
	let a = e.tasks[0];
	if (a) {
		let o = a.n || 0;
		switch (a.optional && i({ op: "skip" }, "skip"), a.kind) {
			case "discardInitial":
			case "discardCycle":
			case "thinCards":
			case "discard": {
				let e = a.kind === "discard" ? a.arg || "cattle" : "any";
				for (let t of qe(n, e, o)) i({
					op: "cards",
					cards: t
				}, a.kind === "thinCards" ? "thin" : "discard", "", o, 0, "", (a.then || []).map((e) => `${e.kind}:${e.n || 0}`).join(","));
				break;
			}
			case "hire":
				e.jobs.forEach((t, r) => {
					let o = Math.max(0, oe[Math.floor(r / e.order.length)] + (a.cost || 0));
					t && Math.floor(r / e.order.length) < Math.floor(e.jobProgress / e.order.length) && n.workers[t.kind] < 6 && n.money >= o && i({
						op: "hire",
						n: r
					}, "hire", t.kind, 1, o);
				});
				break;
			case "build":
				for (let r of e.sides) if (!(n.buildings.includes(r) || n.removedBuildings.includes(r))) for (let a of E.filter((e) => e.type === "building")) {
					let s = e.buildings[a.id];
					if (s && s.owner !== t) continue;
					let c = w[r].builders - (s ? w[s.tile].builders : 0), l = c * o;
					c > 0 && c <= n.workers.builder && n.money >= l && i({
						op: "build",
						a: r,
						b: a.id
					}, "build", a.id, c, l, r);
				}
				break;
			case "hazard":
				for (let [t, r] of Object.entries(e.hazards)) n.money >= (a.cost || 0) && i({
					op: "hazard",
					a: t
				}, "hazard", t, r.vp, a.cost || 0);
				break;
			case "bounty":
				for (let [t, n] of Object.entries(e.outlaws)) i({
					op: "bounty",
					a: t
				}, "bounty", t, typeof se[D[t].index] == "number" ? se[D[t].index] : 0, 0, "", n.kind);
				break;
			case "objective":
				e.objectiveDeck.length && i({
					op: "objective",
					a: "deck"
				}, "objective", "deck"), e.objectives.forEach((e) => i({
					op: "objective",
					a: e
				}, "objective", e));
				break;
			case "market": {
				let t = o;
				for (let r of e.market) {
					let e = V(r);
					(e.breed === "simmental" ? [[1, 8], [2, 5]] : e.value === 3 ? [[1, 6], [2, 3]] : e.value === 4 ? [[1, 12], [3, 6]] : [[2, 12], [4, 6]]).forEach(([e, a]) => {
						e <= t && n.money >= a && i({
							op: "buy",
							a: r,
							n: e,
							m: a
						}, "buy", r, e, a);
					});
				}
				for (let [r, a, o] of [[
					3,
					3,
					5
				], [
					4,
					5,
					8
				]]) if (t >= a && n.money >= o) for (let t of Ge(e.market.filter((e) => V(e).value === r && V(e).breed !== "simmental"), 2)) i({
					op: "buy",
					cards: t,
					n: a,
					m: o
				}, "buy", t[0], a, o);
				t > 0 && e.marketDeck.length && i({ op: "marketDraw" }, "marketDraw", "deck", 2);
				break;
			}
			case "train":
				for (let n of Ae(e, t, o)) i({
					op: "rail",
					n: n.at
				}, "train", String(n.at), n.n);
				break;
			case "backMoney":
			case "backCert":
			case "backThin":
				for (let r of Ae(e, t, o, -1, !0)) n.money >= (a.cost || 0) && (a.kind !== "backThin" || n.hand.length >= o) && i({
					op: "railBack",
					n: r.at
				}, a.kind, String(r.at), o, a.cost || 0);
				break;
			case "extraDelivery":
			case "railReturn":
				for (let r of Ae(e, t, 55, -1)) {
					let o = Math.max(0, Math.floor(n.train) - Math.floor(r.at) - e.order.filter((i) => i !== t && e.p[i].train < n.train && e.p[i].train > r.at && e.p[i].train % 1 == 0).length);
					(a.kind === "railReturn" || re.some((e, t) => e.value <= o && (t === 0 || t === 9 || !n.cities.includes(t)) && Me(n).some((t) => je(n, t, e.dark)))) && i({
						op: "railExtra",
						n: r.at,
						m: o
					}, a.kind, String(r.at), o);
				}
				break;
			case "station":
			case "stationBehind": {
				let e = a.kind === "station" ? [o] : k.map((e, t) => ({
					t: e,
					i: t
				})).filter(({ t: e }) => e.at < n.train).map(({ i: e }) => e);
				for (let t of e) for (let e of Me(n)) !n.stations.includes(t) && je(n, e, k[t].dark, k[t].cost) && i({
					op: "station",
					n: t,
					a: e
				}, "station", String(t), 0, k[t].cost + (e.startsWith("hand") ? 5 : 0), e);
				break;
			}
			case "master":
				for (let e of b) n.workers[e] > 1 && i({
					op: "master",
					a: e,
					n: o
				}, "master", String(o), 1, 0, e);
				break;
			case "delivery":
				for (let e = 0; e < re.length; e++) {
					let t = re[e];
					if (t.value > o || e !== 0 && e !== 9 && n.cities.includes(e)) continue;
					let r = a.arg === "free" ? 0 : O.filter((e) => e > n.train && e < t.value).length;
					for (let a of Me(n)) je(n, a, t.dark, r) && i({
						op: "delivery",
						n: e,
						a
					}, "delivery", String(e), 0, r + (a.startsWith("hand") ? 5 : 0), a);
				}
				break;
			case "herder":
			case "ride":
				for (let n of Ee(e, t, o, a.kind !== "ride")) i({
					op: "travel",
					path: n.path
				}, a.kind, n.at, n.steps, a.kind === "ride" ? 0 : n.cost);
				break;
			case "aux":
				for (let r of [
					"money",
					"cycle",
					"cert",
					"train",
					"thin"
				]) {
					let a = r === "money" || r === "cycle" ? 1 + Number(!n.discs.includes(`${r}1`)) : Number(!n.discs.includes(`${r}0`)) + Number(!n.discs.includes(`${r}1`));
					for (let s = 1; s <= Math.min(o, a); s++) (r === "cert" || r === "train") && n.money < s || (r !== "cert" && r !== "thin" || Ae(e, t, s, -1, !0).length) && (r === "thin" && n.hand.length < s || i({
						op: "aux",
						a: r,
						n: s
					}, "aux", r, s, r === "cert" || r === "train" ? s : 0));
				}
				break;
			case "cycle":
				for (let e = 1; e <= Math.min(o, n.deck.length + n.discard.length); e++) i({
					op: "cycle",
					n: e
				}, "cycle", "", e);
				break;
			case "copy": {
				let t = D[e.local];
				for (let n of E.filter((e) => t.next.includes(e.id) || e.next.includes(t.id))) {
					let t = e.buildings[n.id]?.tile || e.neutral[n.id];
					t && t !== "6b" && i({
						op: "copy",
						a: n.id
					}, "copy", n.id, 0, 0, t);
				}
				break;
			}
			case "copiedLocal": {
				let n = a.arg;
				(w[n]?.actions || C[n]).forEach((r, o) => {
					e.usedBuilding.includes(`${n}:${o}`) || r.forEach((r, s) => {
						Je(e, t, r) && i({
							op: "copied",
							a: String(o),
							n: s
						}, r.kind, a.source, r.n || 0, r.cost || 0, `${n}:${o}`, r.arg || "");
					});
				});
				break;
			}
			case "masterChoice":
				i({
					op: "masterChoice",
					a: "hazard"
				}, "hazard"), i({
					op: "masterChoice",
					a: "bounty"
				}, "bounty");
				break;
			case "simmental": for (let e of n.hand.filter((e) => ["simmental1", "simmental2"].includes(B(e)))) i({
				op: "simmental",
				a: e
			}, "simmental", e);
		}
		return !r.some((e) => e.cmd.op !== "exchange" && e.cmd.op !== "skip") && !a.optional && i({ op: "skip" }, "continue"), r;
	}
	if (e.phase === "move" || e.phase === "local") for (let e of n.hand.filter((e) => H(e))) i({
		op: "playObjective",
		a: e
	}, "playObjective", e);
	if (e.phase === "move") {
		if (n.first) for (let e of "ABCDEFG") i({
			op: "start",
			a: e
		}, "move", e);
		else for (let r of Ee(e, t, ve(n, e.order.length))) i({
			op: "travel",
			path: r.path
		}, "move", r.at, r.steps, r.cost);
	} else if (e.phase === "local") {
		for (let n of Le(e, t)) !e.used.includes(n.key) && !e.usedBuilding.includes(n.key) && n.options.forEach((r, a) => {
			Je(e, t, r) && i({
				op: "local",
				a: n.key,
				n: a
			}, r.kind, e.local, r.n || 0, r.cost || 0, n.key, r.arg || "");
		});
		e.used.length || i({ op: "localAux" }, "aux", e.local, 1), i({ op: "end" }, "end");
	} else if (e.phase === "foresight") e.foresight[e.kcStep].forEach((t, n) => {
		t && !(b.includes(t.kind) && e.jobProgress >= e.jobs.length) && i({
			op: "foresight",
			n
		}, "foresight", String(n), 0, 0, String(e.kcStep), t.kind);
	}), r.some((e) => e.cmd.op === "foresight") || i({ op: "foresightSkip" }, "continue");
	else if (e.phase === "income") for (let e = 0; e <= n.certificates; e++) i({
		op: "income",
		n: e
	}, "income", "", Be(n) + e, e);
	else e.phase === "delivery" && i({ op: "finishKC" }, "continue");
	return r;
}
function J(e, t) {
	let n = W(e), r = t.n || 0;
	switch (t.kind) {
		case "money":
			n.money += r * (t.arg === "woods" ? Ce(e, n.rid) : t.arg === "stations" ? n.stations.length : t.arg && b.includes(t.arg) ? n.workers[t.arg] : 1);
			break;
		case "cert":
			xe(n, r);
			break;
		case "exchange":
			n.exchange += r;
			break;
		case "pairs": {
			let e = Math.min(n.outlaws.filter((e) => e.kind === "orange").length, n.outlaws.filter((e) => e.kind === "green").length);
			xe(n, e * 2), n.money += e * 2;
			break;
		}
		default: {
			let r = {
				...t,
				optional: !0
			};
			if (t.kind === "market" && (r.n = n.workers.cowboy), ["train", "cycle"].includes(t.kind) && t.arg && (r.n = t.arg === "woods" ? Ce(e, n.rid) : t.arg === "hazards" ? n.hazards.length : n.workers[t.arg]), t.cost && t.kind === "train") {
				if (n.money < t.cost) return;
				n.money -= t.cost;
			}
			e.tasks.unshift(r);
		}
	}
}
function Xe(e, t) {
	let n = W(e).workers[t];
	t === "cowboy" && n === 4 && q(e, [{
		kind: "hazard",
		cost: 0
	}]), t === "cowboy" && n === 5 && q(e, [{ kind: "bounty" }]), t === "builder" && (n === 4 || n === 5) && q(e, [{
		kind: "build",
		n: 1
	}]), t === "engineer" && (n === 4 ? q(e, [{
		kind: "hire",
		cost: -2
	}]) : q(e, [{
		kind: "discard",
		arg: "criollo",
		n: 1,
		then: n === 2 ? [{
			kind: "cert",
			n: 1
		}] : n === 3 ? [{
			kind: "money",
			n: 2
		}] : n === 5 ? [{
			kind: "cert",
			n: 2
		}] : [{
			kind: "money",
			n: 4
		}]
	}]));
}
function Ze(e, t) {
	let n = W(e), r = e.tasks[0], i = t.n || 0;
	if (t.op === "skip") {
		e.tasks.shift();
		return;
	}
	if (t.op === "cards") e.tasks.shift(), Se(n, t.cards, r.kind === "thinCards"), r.then && q(e, r.then), K(e, r.kind === "thinCards" ? "thin" : "discard", "", t.cards.length, t.cards);
	else if (t.op === "start") n.first = !1, n.position = t.a, e.lastPath = [t.a], Oe(e, t.a);
	else if (t.op === "travel") {
		let i = r?.kind;
		r && e.tasks.shift(), De(e, n, t.path, i === "ride"), i === "ride" ? e.phase === "local" && Re(e) : (e.tasks = [], Oe(e, n.position));
	} else if (t.op === "local") {
		let r = Le(e, n.rid).find((e) => e.key === t.a);
		e.used.push(r.key), e.usedBuilding.push(r.key), J(e, r.options[i]), K(e, "local", t.a);
	} else if (t.op === "localAux") e.used.push("aux"), J(e, {
		kind: "aux",
		n: 1
	});
	else if (t.op === "end") Re(e);
	else if (t.op === "hire") {
		e.tasks.shift();
		let t = e.jobs[i];
		n.money -= Math.max(0, oe[Math.floor(i / e.order.length)] + (r.cost || 0)), e.jobs[i] = null, n.workers[t.kind]++, K(e, "hire", t.kind), Xe(e, t.kind);
	} else if (t.op === "build") {
		e.tasks.shift();
		let i = e.buildings[t.b], a = w[t.a].builders - (i ? w[i.tile].builders : 0);
		n.money -= a * (r.n || 0), i && (n.buildings = n.buildings.filter((e) => e !== i.tile), n.removedBuildings.push(i.tile)), n.buildings.push(t.a), e.buildings[t.b] = {
			owner: n.rid,
			tile: t.a
		}, K(e, "build", t.b, 0, [t.a]);
	} else if (t.op === "hazard") e.tasks.shift(), n.money -= r.cost || 0, n.hazards.push(e.hazards[t.a]), delete e.hazards[t.a], K(e, "hazard", t.a);
	else if (t.op === "bounty") {
		e.tasks.shift(), n.outlaws.push(e.outlaws[t.a]), delete e.outlaws[t.a];
		let r = se[D[t.a].index];
		r === "exchange" ? n.exchange++ : n.money += r, K(e, "bounty", t.a);
	} else if (t.op === "objective") {
		e.tasks.shift();
		let i;
		t.a === "deck" ? i = e.objectiveDeck.shift() : (i = t.a, e.objectives.splice(e.objectives.indexOf(i), 1), e.objectiveDeck.length && e.objectives.unshift(e.objectiveDeck.shift())), r.arg === "hand" ? n.hand.push(i) : n.discard.push(i), K(e, "objective", t.a === "deck" && r.arg === "hand" ? "deck" : i);
	} else if (t.op === "buy") {
		let a = t.cards || [t.a];
		r.n -= i, n.money -= t.m, e.market = e.market.filter((e) => !a.includes(e)), n.discard.push(...a), K(e, "buy", "", t.m, a);
	} else if (t.op === "marketDraw") r.n--, Pe(e, 2), K(e, "marketDraw");
	else if (t.op === "rail") e.tasks.shift(), n.train = i, ze(e, i), K(e, "train", String(i));
	else if (t.op === "railBack") e.tasks.shift(), n.train = i, n.money -= r.cost || 0, r.kind === "backMoney" && (n.money += (r.n || 0) * 3), r.kind === "backCert" && xe(n, r.n || 0), r.kind === "backThin" && (n.money += r.n || 0, e.tasks.unshift({
		kind: "thinCards",
		n: r.n,
		optional: !1
	})), ze(e, i), K(e, "train", String(i));
	else if (t.op === "railExtra") e.tasks.shift(), n.train = i, r.kind === "railReturn" ? (n.money += 3, ze(e, i)) : e.tasks.unshift({
		kind: "delivery",
		n: t.m,
		arg: "free",
		optional: !1
	}, {
		kind: "stationAfter",
		n: i
	}), K(e, "train", String(i));
	else if (t.op === "station") e.tasks.shift(), n.money -= k[i].cost, Ne(n, t.a), n.stations.push(i), e.stationMasters[i] !== null && e.tasks.unshift({
		kind: "master",
		n: i,
		optional: !0
	}), K(e, "station", String(i));
	else if (t.op === "master") {
		e.tasks.shift();
		let r = e.stationMasters[i];
		e.stationMasters[i] = null, e.stationWorkers[i] = t.a, n.workers[t.a]--, n.masters.push(r), q(e, N[r].action), K(e, "master", String(r));
	} else if (t.op === "delivery") e.tasks.shift(), Ve(e, n, i, t.a, r.arg !== "free");
	else if (t.op === "aux") e.tasks.shift(), t.a === "money" ? n.money += i : t.a === "cycle" ? J(e, {
		kind: "cycle",
		n: i
	}) : t.a === "train" ? J(e, {
		kind: "train",
		n: i,
		cost: i
	}) : e.tasks.unshift({
		kind: t.a === "cert" ? "backCert" : "backThin",
		n: i,
		cost: t.a === "cert" ? i : 0,
		optional: !0
	});
	else if (t.op === "cycle") {
		e.tasks.shift();
		let t = be(e, n, i);
		t.length && e.tasks.unshift({
			kind: "discardCycle",
			n: t.length,
			optional: !1
		}), K(e, "draw", "", t.length);
	} else if (t.op === "copy") {
		e.tasks.shift();
		let n = e.buildings[t.a]?.tile || e.neutral[t.a];
		e.tasks.unshift({
			kind: "copiedLocal",
			arg: n,
			source: t.a,
			optional: !0
		});
	} else if (t.op === "copied") {
		let n = r.arg, a = w[n]?.actions || C[n];
		e.usedBuilding.push(`${n}:${t.a}`), J(e, a[Number(t.a)][i]);
	} else if (t.op === "masterChoice") e.tasks.shift(), J(e, {
		kind: t.a,
		cost: 0
	});
	else if (t.op === "simmental") {
		let r = n.hand.indexOf(t.a), i = B(t.a);
		n.hand.splice(r, 1), n.discard.push(he(e, i === "simmental1" ? "simmental2" : "simmental3")), K(e, "simmental", "", 0, [t.a]);
	} else t.op === "playObjective" ? (Se(n, [t.a], !0), n.objectives.push(t.a), q(e, H(t.a).immediate), K(e, "playObjective", t.a)) : t.op === "foresight" || t.op === "foresightSkip" ? (t.op === "foresight" && (Fe(e, e.foresight[e.kcStep][i]), e.foresight[e.kcStep][i] = null), e.kcStep++) : t.op === "income" ? (e.income = Be(n) + i, n.certificates -= i, n.money += e.income, e.revealed = [...n.hand], e.phase = "delivery", e.tasks.push({
		kind: "discardIncome",
		optional: !1
	}, {
		kind: "delivery",
		n: e.income,
		optional: !1
	}), e.config.simmental && n.hand.some((e) => ["simmental1", "simmental2"].includes(B(e))) && e.tasks.unshift({
		kind: "simmental",
		optional: !0
	}), K(e, "income", "", e.income, n.hand)) : t.op === "finishKC" && He(e);
}
function Qe(e) {
	let t = e.objectives.pop() || e.objectiveDeck.shift();
	t && e.p[z].objectives.push(t), e.objectiveDeck.length && e.objectives.length < 4 && e.objectives.unshift(e.objectiveDeck.shift());
}
function $e(e, t) {
	let n = e.p[z], r = e.jobs.map((t, n) => ({
		t,
		i: n,
		cost: oe[Math.floor(n / e.order.length)]
	})).filter((t) => t.t && Math.floor(t.i / e.order.length) < Math.floor(e.jobProgress / e.order.length) && n.workers[t.t.kind] < 6);
	r.sort((e, r) => {
		let i = e.t.kind, a = r.t.kind;
		return t ? Number(a === n.specialization) - Number(i === n.specialization) || n.workers[a] - n.workers[i] || e.cost - r.cost || e.i - r.i : e.cost - r.cost || Number(a === n.specialization) - Number(i === n.specialization) || e.i - r.i;
	});
	let i = r[0];
	i && (n.workers[i.t.kind]++, e.jobs[i.i] = null, n.workers[i.t.kind] > n.workers[n.specialization] && (n.specialization = i.t.kind), K(e, "hire", i.t.kind, 1, [], z));
}
function et(e, t) {
	let n = e.p[z], r = t || n.workers.builder, i = Array.from({ length: 12 }, (e, t) => `${t + 1}b`).filter((e) => !n.buildings.includes(e) && !n.removedBuildings.includes(e)), a = /* @__PURE__ */ new Set(), o = [...D[e.p[e.humans[0]].position].next], s = [];
	for (; o.length;) {
		let t = o.shift();
		a.has(t) || (a.add(t), D[t].type === "building" && !D[t].risk && !e.buildings[t] && s.push(t), o.push(...D[t].next));
	}
	s.length || s.push(...E.filter((t) => t.type === "building" && !t.risk && !e.buildings[t.id]).map((e) => e.id));
	let c = [];
	if (s.length) for (let e of i) w[e].builders <= r && c.push({
		tile: e,
		at: s[0],
		used: w[e].builders,
		old: null
	});
	if (!c.length) {
		for (let [t, n] of Object.entries(e.buildings)) if (n.owner === "$sam") for (let e of i) {
			let i = w[e].builders - w[n.tile].builders;
			i > 0 && i <= r && c.push({
				tile: e,
				at: t,
				used: i,
				old: n.tile
			});
		}
	}
	c.sort((e, t) => t.used - e.used || (e.old ? w[t.tile].builders - w[e.tile].builders : 0) || w[t.tile].hands.length - w[e.tile].hands.length || e.tile.localeCompare(t.tile));
	let l = c[0];
	l && (l.old && (n.buildings = n.buildings.filter((e) => e !== l.old), n.removedBuildings.push(l.old)), n.buildings.push(l.tile), e.buildings[l.at] = {
		owner: z,
		tile: l.tile
	}, K(e, "build", l.at, 0, [l.tile], z));
}
function tt(e, t = !1, n) {
	let r = e.p[z];
	if (r.train < 0) return;
	let i = Ae(e, z, t ? 60 : n || r.workers.engineer), a = i.filter((e) => e.at % 1 || e.at === 39), o = t ? a.sort((e, t) => e.at - t.at)[0] : a.sort((e, t) => t.at - e.at)[0] || i.sort((e, t) => t.at - e.at)[0];
	if (!o) return;
	r.train = o.at;
	let s = k.findIndex((e) => e.at === (o.at === 39 ? 39 : o.at - .5));
	s >= 0 && !r.stations.includes(s) && (r.discs.length ? r.discs.pop() : r.stations.shift(), r.stations.push(s), e.stationMasters[s] = null), K(e, "train", String(r.train), 0, [], z), o.at === 39 && (r.train = -1);
}
function nt(e) {
	let t = e.p[z], n = t.workers.cowboy, r = (e, t, n) => {
		let r = [];
		for (let i of e) {
			let e = V(i);
			if (e.breed === "simmental") continue;
			let a = e.value === 3 ? [[1, 6], [2, 3]] : e.value === 4 ? [[1, 12], [3, 6]] : [[2, 12], [4, 6]];
			for (let [o, s] of a) t >= o && n >= s && r.push({
				cards: [i],
				workers: o,
				cost: s,
				vp: e.vp
			});
		}
		for (let [i, a, o] of [[
			3,
			3,
			5
		], [
			4,
			5,
			8
		]]) if (t >= a && n >= o) for (let t of Ge(e.filter((e) => V(e).value === i && V(e).breed !== "simmental"), 2)) r.push({
			cards: t,
			workers: a,
			cost: o,
			vp: t.reduce((e, t) => e + V(t).vp, 0)
		});
		return r;
	};
	for (; n && !r(e.market, n, 8).length && e.marketDeck.length;) n--, Pe(e, 2);
	let i = {
		cards: [],
		workers: 0,
		vp: 0,
		high: 0
	};
	function a(e, t, n, o, s, c) {
		let l = Math.max(0, ...o.map((e) => V(e).vp));
		(c > i.vp || c === i.vp && l > i.high) && (i = {
			cards: o,
			workers: s,
			vp: c,
			high: l
		});
		for (let i of r(e, t, n)) a(e.filter((e) => !i.cards.includes(e)), t - i.workers, n - i.cost, [...o, ...i.cards], s + i.workers, c + i.vp);
	}
	a(e.market, n, 8, [], 0, 0), e.market = e.market.filter((e) => !i.cards.includes(e)), t.discard.push(...i.cards), Pe(e, (n - i.workers) * 2), K(e, "buy", "", i.vp, i.cards, z);
}
function rt(e) {
	let t = e.p[z], n = P[e.samCard - 1], r = t.specialization;
	switch (n.action) {
		case "hireCheap":
			$e(e, !1);
			break;
		case "hireSpecial":
			$e(e, !0);
			break;
		case "market":
			nt(e);
			break;
		case "build":
			et(e);
			break;
		case "train":
			tt(e);
			break;
		case "objective":
			Qe(e);
			break;
		case "bounty": {
			let n = Object.keys(e.outlaws).sort((e, t) => D[t].index - D[e].index)[0];
			n && (t.outlaws.push(e.outlaws[n]), delete e.outlaws[n], K(e, "bounty", n, 0, [], z));
			break;
		}
		case "hazard": {
			let n = [
				"flood",
				"drought",
				"rockfall"
			].map((t) => ({
				region: t,
				entries: Object.entries(e.hazards).filter(([, e]) => e.kind === t).sort((e, t) => t[1].vp - e[1].vp)
			})).sort((e, t) => t.entries.length - e.entries.length || (t.entries[0]?.[1].vp || 0) - (e.entries[0]?.[1].vp || 0))[0].entries[0];
			n && (t.hazards.push(n[1]), delete e.hazards[n[0]], K(e, "hazard", n[0], 0, [], z));
			break;
		}
		case "marketSpecial":
			r === "cowboy" && nt(e);
			break;
		case "buildSpecial":
			r === "builder" && et(e);
			break;
		case "trainSpecial":
			r === "engineer" && tt(e);
			break;
		case "marketAlternative":
			if (r === "cowboy") Pe(e, 2), nt(e);
			else {
				let n = e.market.filter((e) => V(e).value === 3).sort((e, t) => V(t).vp - V(e).vp)[0];
				n && (e.market.splice(e.market.indexOf(n), 1), t.discard.push(n), K(e, "buy", "", 0, [n], z));
			}
			break;
		case "buildAlternative":
			et(e, r === "builder" ? void 0 : 1);
			break;
		case "trainAlternative": tt(e, r === "engineer", 1);
	}
}
function it(e) {
	let t = e.p[z];
	if (e.samBeat === 0) e.samDeck.length || (e.samDeck = G(e, e.samDiscard), e.samDiscard = []), e.samCard = e.samDeck.shift(), e.samBeat = 1;
	else if (e.samBeat === 1) {
		let n = P[e.samCard - 1], r = Ee(e, z, n.move > 0 ? n.move : Math.min(5, Math.max(1, n.move === -1 ? Math.max(...e.order.map((t) => e.p[t].buildings.length)) : t.workers[t.specialization]))), i = (t) => t === "kc" ? 0 : Math.min(...D[t].next.map((t) => Number(we(e, t)) + i(t)));
		r.sort((t, n) => i(t.at) - i(n.at) || t.cost - n.cost || t.path.filter((t) => e.buildings[t]?.owner === e.humans[0]).reduce((t, n) => t + Te(e, "$sam", n), 0) - n.path.filter((t) => e.buildings[t]?.owner === e.humans[0]).reduce((t, n) => t + Te(e, "$sam", n), 0) || t.at.localeCompare(n.at)), r[0] && De(e, t, r[0].path), e.samBeat = 2;
	} else if (e.samBeat === 2) rt(e), e.samBeat = 3, e.kcStep = 0;
	else if (t.position === "kc" && e.kcStep < 3) {
		let t = e.foresight[e.kcStep], n = [1, 0].find((n) => t[n] && !(e.jobProgress >= e.jobs.length && b.includes(t[n].kind)));
		n !== void 0 && (Fe(e, t[n]), t[n] = null), e.kcStep++;
	} else t.position === "kc" && e.samBeat === 3 ? (Ve(e, t, Math.min(9, e.samDelivery++), "", !1), e.samBeat = 4) : t.position === "kc" ? (t.position = "start", Ie(e), e.samBeat = 5) : (e.samDiscard.push(e.samCard), Re(e));
}
function at(e) {
	let t = [...e.objectives], n = [
		...e.hand,
		...e.deck,
		...e.discard
	].filter((e) => H(e));
	if (e.sam) return {
		total: t.reduce((e, t) => e + H(t).vp, 0),
		selected: t.map((e) => ({
			card: e,
			success: !0,
			points: H(e).vp
		}))
	};
	let r = [
		...e.hand,
		...e.deck,
		...e.discard
	], i = {
		building: e.buildings.length,
		station: e.stations.length,
		hazard: e.hazards.length,
		orange: e.outlaws.filter((e) => e.kind === "orange").length,
		green: e.outlaws.filter((e) => e.kind === "green").length,
		cow3: r.filter((e) => V(e)?.value === 3 && V(e)?.breed !== "simmental").length,
		cow4: r.filter((e) => V(e)?.breed === "shorthorn").length,
		cow5: r.filter((e) => V(e)?.breed === "hereford").length,
		ny: e.cities.filter((e) => e === 9).length
	}, a = [...t, ...n], o = e.masters.some((e) => N[e].score === "objectives"), s = /* @__PURE__ */ new Map(), c = Object.keys(i);
	function l(e, n, r) {
		if (e === a.length) return {
			utility: 0,
			points: 0,
			selected: []
		};
		let i = `${e}/${c.map((e) => n[e]).join(",")}/${r % 2}`, u = s.get(i);
		if (u) return u;
		let d = a[e], f = H(d), p = e < t.length, m = !p && o && r % 2 ? 3 : 0, h = [];
		p || h.push(l(e + 1, n, r));
		let g = l(e + 1, n, r + Number(!p));
		if (h.push({
			utility: g.utility - f.penalty + m,
			points: g.points - f.penalty,
			selected: [{
				card: d,
				success: !1,
				points: -f.penalty
			}, ...g.selected]
		}), Object.entries(f.tasks).every(([e, t]) => n[e] >= t)) {
			let t = { ...n };
			for (let [e, n] of Object.entries(f.tasks)) t[e] -= n;
			let i = l(e + 1, t, r + Number(!p));
			h.push({
				utility: i.utility + f.vp + m,
				points: i.points + f.vp,
				selected: [{
					card: d,
					success: !0,
					points: f.vp
				}, ...i.selected]
			});
		}
		let _ = h.sort((e, t) => t.utility - e.utility)[0];
		return s.set(i, _), _;
	}
	let u = l(0, i, t.length);
	return {
		total: u.points,
		selected: u.selected
	};
}
function ot(e) {
	return e.order.map((t) => {
		let n = e.p[t], r = at(n), i = [
			...n.hand,
			...n.deck,
			...n.discard
		], a = new Set(n.cities), o = [
			n.sam ? 0 : Math.floor(n.money / 5),
			n.buildings.reduce((e, t) => e + w[t].vp, 0),
			n.cities.filter((e) => e === 0).length * -6 + n.cities.filter((e) => e === 9).length * 9 + ie.reduce((e, t, n) => e + (a.has(n) && a.has(n + 1) ? t : 0), 0),
			n.stations.reduce((e, t) => e + k[t].vp, 0),
			n.hazards.reduce((e, t) => e + t.vp, 0),
			i.reduce((e, t) => e + (V(t)?.vp || 0), 0),
			r.total,
			n.sam ? 0 : n.masters.reduce((e, t) => {
				let i = N[t].score;
				return e + (i === "workers" ? Object.values(n.workers).reduce((e, t) => e + t, 0) : i === "buildings" ? n.buildings.length * 2 : i === "stations" ? Math.floor(n.stations.length / 2) * 3 : i === "hazards" ? Math.floor(n.hazards.length / 2) * 3 : i === "certificates" ? Math.floor((n.certificates + ye(n)) / 2) * 3 : i === "objectives" ? Math.floor(r.selected.length / 2) * 3 : i === "outlaws" ? Math.min(n.outlaws.filter((e) => e.kind === "orange").length, n.outlaws.filter((e) => e.kind === "green").length) * 3 : 0);
			}, 0),
			Object.values(n.workers).reduce((e, t) => e + Math.max(0, t - 4) * 4, 0),
			n.sam || n.discs.includes("move1") ? 0 : 3,
			e.finalTrigger === t ? 2 : 0
		];
		return {
			rid: t,
			categories: o,
			total: o.reduce((e, t) => e + t, 0),
			objectives: r.selected
		};
	});
}
function st(e) {
	let t = e.tasks[0];
	if (!t) return !1;
	if ([
		"money",
		"cert",
		"exchange",
		"pairs"
	].includes(t.kind)) return e.tasks.shift(), J(e, t), !0;
	if (t.kind === "discardIncome") {
		e.tasks.shift();
		let t = W(e);
		return t.discard.push(...t.hand), t.hand = [], !0;
	}
	return t.kind === "stationAfter" && (e.tasks.shift(), ze(e, t.n), !0);
}
function ct(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine") return { code: "games.greatwesterntrail.errAction" };
		let t = structuredClone(e);
		if (t.beat = 0, t.motion = void 0, t.lastPath = [], t.exchangePending || t.phase === "done") return {
			state: t,
			fx: []
		};
		U(t) === "$sam" ? it(t) : st(t), Ue(t);
		let r = U(e);
		if (JSON.stringify({
			...e,
			beat: 0,
			motion: void 0,
			lastPath: []
		}) === JSON.stringify(t)) return {
			state: t,
			fx: []
		};
		t.beat = U(e) === "$sam" ? R.sam : R.card, t.motion = {
			rid: r,
			hand: e.p[r].hand,
			market: e.market,
			objectives: e.objectives,
			task: e.tasks[0]?.kind || (e.phase === "foresight" ? "foresight" : "")
		};
		let i = lt(e, t, r, "settle");
		if (r === "$sam") {
			let n = i.data.kind;
			t.motion.task = e.p.$sam.position === "kc" && e.samBeat === 3 && e.kcStep < 3 ? "foresight" : {
				train: "train",
				delivery: "delivery",
				buy: "market",
				hire: "hire",
				build: "build",
				objective: "objective"
			}[n] || "";
		}
		return {
			state: t,
			fx: [i]
		};
	}
	let r = Ye(e, n.by).find((e) => e.choice.id === t.id);
	if (!r) return { code: "games.greatwesterntrail.errAction" };
	let i = structuredClone(e);
	if (i.lastPath = [], r.cmd.op === "exchange") {
		let e = i.p[n.by];
		e.exchange--;
		let t = be(i, e, r.cmd.n);
		i.exchangePending = {
			rid: n.by,
			n: t.length
		}, K(i, "exchange", "", t.length, [], n.by);
	} else r.cmd.op === "exchangeDiscard" ? (Se(i.p[n.by], r.cmd.cards), i.exchangePending = null) : Ze(i, r.cmd);
	return Ue(i), i.beat = r.choice.kind === "simmental" ? R.upgrade : r.choice.kind === "move" || r.choice.kind === "herder" || r.choice.kind === "ride" ? R.move : R.card, i.motion = {
		rid: n.by,
		hand: e.p[n.by].hand,
		market: e.market,
		objectives: e.objectives,
		task: e.tasks[0]?.kind || (e.phase === "foresight" ? "foresight" : "")
	}, {
		state: i,
		fx: [lt(e, i, n.by, r.choice.kind)]
	};
}
function lt(e, t, n, r) {
	let i = t.log.at(-1), a = JSON.stringify(i) !== JSON.stringify(e.log.at(-1)), o = e.p[n], s = t.p[n], c = s.hand.filter((e) => !o.hand.includes(e)), l = o.hand.filter((e) => !s.hand.includes(e)), u = a ? i.kind : l.length ? "discard" : r, d = u === "buy" || u === "build" ? i.cards : l, f = a ? i.target : "", p = Object.entries({
		...t.hazards,
		...t.outlaws
	}).filter(([t]) => !(t in e.hazards) && !(t in e.outlaws)).map(([e, t]) => ({
		to: `node:${e}`,
		tile: t
	}));
	t.jobs.forEach((t, n) => {
		t && !e.jobs.some((e) => e?.id === t.id) && p.push({
			to: `job:${n}`,
			tile: t
		});
	});
	let m = e.foresight.flatMap((e, n) => e.flatMap((e, r) => e && !t.foresight.flat().some((t) => t?.id === e.id) ? [{
		id: e.id,
		anchor: `foresight:${n}:${r}`
	}] : [])), h = e.jobs.findIndex((e, n) => e && !t.jobs[n]), g = [
		...s.hand,
		...s.discard,
		...s.objectives
	].filter((e) => H(e) && ![
		...o.hand,
		...o.discard,
		...o.objectives
	].includes(e));
	return {
		kind: "gwtAction",
		rid: n,
		for: [n],
		secret: { drawCards: c },
		data: {
			kind: u,
			target: f,
			cards: d,
			faceDown: s.sam,
			drawCount: u === "objective" ? 0 : c.length,
			upgraded: u === "simmental" && s.discard.find((e) => !o.discard.includes(e)) || "",
			masters: s.masters.filter((e) => !o.masters.includes(e)),
			masterFrom: e.tasks[0]?.kind === "master" ? e.tasks[0].n ?? -1 : -1,
			exchange: s.exchange - o.exchange,
			money: s.money - o.money,
			certificates: s.certificates - o.certificates,
			fromNode: o.position,
			toNode: s.position,
			path: t.lastPath?.length ? t.lastPath : [s.position],
			fromTrain: o.train,
			toTrain: s.train,
			samCard: e.samBeat === 0 && t.samBeat === 1 ? t.samCard : null,
			hired: h,
			discIndex: s.cities.length - 1,
			takenTile: e.hazards[f] || e.outlaws[f] || null,
			tiles: p.map((e) => ({
				...e,
				from: m.find((t) => t.id === e.tile.id)?.anchor || ""
			})),
			marketAdded: t.market.filter((t) => !e.market.includes(t)),
			objectivesAdded: t.objectives.filter((t) => !e.objectives.includes(t)),
			gainedObjectives: g.map((t) => s.sam || s.hand.includes(t) && !e.objectives.includes(t) ? "" : t)
		}
	};
}
function ut(e, t) {
	let n = e.order.map((t) => {
		let { hand: n, deck: r, ...i } = e.p[t];
		return {
			...i,
			permanent: ye(i),
			handCount: n.length,
			deckCount: r.length,
			...i.sam && e.phase !== "done" ? {
				objectives: [],
				discard: []
			} : {}
		};
	}), r = {
		config: e.config,
		players: n,
		turn: U(e),
		turnNumber: e.turnNumber,
		phase: e.phase,
		task: e.tasks[0]?.kind || "",
		motionTask: e.motion?.task,
		taskAmount: e.tasks[0]?.n || 0,
		local: e.local,
		used: e.used,
		buildings: e.buildings,
		neutral: e.neutral,
		sides: e.sides,
		hazards: e.hazards,
		outlaws: e.outlaws,
		jobs: e.jobs,
		jobProgress: e.jobProgress,
		market: e.market,
		marketLayout: e.motion ? [.../* @__PURE__ */ new Set([...e.motion.market, ...e.market])] : e.market,
		marketLeft: e.marketDeck.length,
		foresight: e.foresight,
		objectives: e.objectives,
		objectiveLayout: e.motion ? [.../* @__PURE__ */ new Set([...e.motion.objectives, ...e.objectives])] : e.objectives,
		objectiveLeft: e.objectiveDeck.length,
		stationMasters: e.stationMasters,
		stationWorkers: e.stationWorkers,
		finalTrigger: e.finalTrigger,
		finalTurns: e.finalTurns,
		income: e.income,
		revealed: e.revealed,
		samCard: e.samCard,
		scores: e.scores,
		log: e.phase === "done" ? e.log : e.log.map((e) => e.rid === "$sam" && ["buy", "objective"].includes(e.kind) ? {
			...e,
			target: "",
			cards: []
		} : e)
	}, i = e.p[t]?.hand || [];
	return {
		public: r,
		private: {
			hand: i,
			handLayout: e.motion?.rid === t ? [.../* @__PURE__ */ new Set([...e.motion.hand, ...i])] : i,
			choices: Ye(e, t).map((e) => e.choice),
			interrupt: e.exchangePending?.rid === t
		}
	};
}
function dt(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.scores].sort((e, t) => t.total - e.total).map((e) => e.rid), n = Object.fromEntries(e.scores.map((e) => [e.rid, e.total])), r = n[t[0]];
	return {
		phase: "done",
		ranking: t,
		scores: n,
		winner: t.filter((e) => n[e] === r)
	};
}
function ft(e) {
	return e.phase === "done" || e.exchangePending ? e.beat || null : e.beat ? e.beat : U(e) === "$sam" ? R.sam : [
		"money",
		"cert",
		"exchange",
		"pairs",
		"discardIncome",
		"stationAfter"
	].includes(e.tasks[0]?.kind || "") ? R.card : null;
}
var pt = {
	meta: te,
	saveCompatibility: { version: "1" },
	schemas: {
		action: I,
		publicView: pe,
		privateView: me,
		config: F
	},
	setup: We,
	reduce: ct,
	viewFor: ut,
	status: dt,
	nextTickIn: ft
}, mt = {
	name: "大西部开拓者",
	desc: "经营牛群，建造西部小镇，沿铁路将优质牛群运往东部。",
	rules: "版本：\n2021 年《大西部开拓者：第二版》，包含官方 Sam 单人模式与可选 Simmental。基础版默认关闭 Simmental；不含北方铁路。\n目标：\n游戏结束后总分最高者获胜，同分共享胜利。\n回合：\nA 移动牧人；B 使用到达地点；C 补牌至手牌上限。首次行动可选择任意中立建筑，之后从当前位置沿箭头前进 1 至步数上限。仅占用地点消耗步数，空地不消耗。经过或停在带手掌的地点时支付费用；钱不足也可移动，只支付现有金额。\n地点：\n自己或中立建筑的每组行动可各执行一次，任意顺序；组内“或”只能选一项。全部放弃时可改做一次单辅助行动。其他玩家建筑、灾害、匪徒地点只能做一次单辅助行动。私人建筑的风险行动同样计入当地行动。移动牧人的建筑会在新地点再次执行 B；目标卡移动则不使用新地点，且不能进入堪萨斯城。\n手牌与牛群：\n通常手牌上限 4，可解锁至 6。回合末补足。抽牌堆耗尽时洗混弃牌堆。行动所弃牌置入弃牌堆，只有明确移除的牌离开游戏。交换标记可在任意玩家回合中花费一个，先抽 1 或 2 张，再弃相同数量。\n雇工：\n只能雇佣市场标记所在行上方的工人，支付对应行费用及行动修正。各职业最多 6 人，包括玩家板印刷的一人。新工人进入带奖励格时可执行该奖励；任命站长会让工人数减少，之后重新填入可再次获得奖励。\n建造：\n选择未使用的本方建筑，建筑师数必须足够；按所需建筑师支付费用。可升级自己的建筑，只需补足建筑师差额与费用；旧建筑移出游戏。本次停留不能使用刚替换的新建筑行动。树林与风险地块按原版地图生效。\n买牛：\n使用可用牛仔及现金，从市场购买并放入弃牌堆；可拆分使用牛仔。\n· 购买普通价值 3 的牛牌时，可以使用 1 名牛仔支付 6 美元购买一张，使用 2 名牛仔支付 3 美元购买一张，或使用 3 名牛仔支付 5 美元购买两张。\n· 购买价值 4 的牛牌时，可以使用 1 名牛仔支付 12 美元购买一张，使用 3 名牛仔支付 6 美元购买一张，或使用 5 名牛仔支付 8 美元购买两张。\n· 购买价值 5 的牛牌时，可以使用 2 名牛仔支付 12 美元购买一张，或使用 4 名牛仔支付 6 美元购买一张。\n也可用一位牛仔向市场增添 2 张牌。\n铁路：\n前进至多指定步数，至少一步；忽略被其他火车占用的格。侧线算额外一格。停在车站侧线时可支付费用，从玩家板取圆片升级该站；每人每站一次。可用一个已雇工人交换尚在的站长。到 39 格后必须后退至少一格并获得 3 美元，还可升级落点车站。\n堪萨斯城：\n依次从三个展望区各选一块，立即放入对应区域；工人填满所在行才推动市场标记，填满第 6、9 行时补牛市场。然后展示整手牌，每种牛只计算一张最高繁殖值，加永久证书及自愿消耗的临时证书；获得相同美元并弃掉手牌。按该繁殖值或以下城市交付，放一个玩家板圆片，支付火车至城市之间每个运输十字 1 美元。除堪萨斯城和纽约外，每城限一次。相邻城市都有本方圆片时获得连接奖励或分数。交付后牧人返回起点，补展望区，再补手牌。\n圆片：\n黑角圆片通常只能放黑角城市或车站，白角可任意放。移除提高手牌上限的圆片时，须额外支付 5 美元。仅余黑角圆片时可放白角；无可支付的圆片时可从车站回收。解锁 6 证书前仍须先解锁 4，才提高证书上限。\n目标：\n自己回合移动前或执行当地行动期间可打出手中目标，获得一次性行动并承诺其任务。终局每件资源仅可满足一张目标；已打出目标失败会扣分。未打出的目标可选择加入或移除。目标按符合规则且总分最高的方案自动结算，并逐张显示计分明细。\n终局：\n填满工作市场最后一格的玩家领取市场标记，并完成自己的最后一个回合；随后，其他玩家各再行动一次。依次计算现金、建筑、城市连接、车站、灾害、牛牌、目标、站长、工人第 5/6 格、步数解锁与市场标记共 11 项得分。\nSam：\n单人按双人设置，Sam 使用官方 15 张行动卡（简单移除 13–15），独立移动并执行卡牌行动，按专长购买、建造和前进铁路；不使用钱币或牛群抽牌。普通从布卢明顿开始交付，困难从皮奥里亚开始并增加三种工人各一。Sam 所有目标都视为完成，且不计现金、站长和玩家板解锁分。\nSimmental：\n市场增加 8 张一阶段牛及 2 张展示容量。购买一张一阶段牛牌时，可以使用 1 名牛仔支付 8 美元，或使用 2 名牛仔支付 5 美元。堪萨斯城领取收入后，可将手中的一、二阶段牛分别升级一阶段并放弃牌堆。同一品种各阶段计算收入时只算一张；指定普通价值 3/4/5 的目标与弃牌条件不包含 Simmental。",
	continue: "继续",
	confirm: "确认",
	cancel: "取消选择",
	skip: "放弃此行动",
	end: "结束回合",
	map: "赶牛路",
	ledger: "牧场账册",
	market: "牛市场",
	jobs: "工作市场",
	rail: "铁路与城市",
	ranch: "玩家板",
	objectives: "目标",
	buildings: "私人建筑",
	hand: "手牌",
	discardPile: "弃牌堆",
	deck: "抽牌堆",
	money: "美元",
	vp: "分",
	turn: "回合",
	wait: "等待行动",
	choose: "选择行动",
	chooseRoute: "选择牧人目的地",
	chooseCards: "选择手牌，再确认弃牌",
	chooseBuild: "选择建筑，再选择地图上的地块",
	chooseCity: "选择交付城市和要移除的圆片",
	chooseDisc: "选择要移除的圆片",
	step: "步",
	cost: "支付",
	income: "牛群收入",
	certificate: "临时证书",
	permanent: "永久证书",
	exchange: "交换标记",
	available: "可用",
	locked: "未解锁",
	roundEnd: "最后一轮",
	sam: "Sam",
	samCard: "Sam 行动卡",
	samAction: {
		hireCheap: "雇佣最便宜的工人",
		hireSpecial: "按专长雇佣工人",
		market: "购买牛牌",
		build: "建造建筑",
		train: "推进火车",
		objective: "取得最远端目标",
		bounty: "领取最高赏金",
		hazard: "清除灾害",
		marketSpecial: "牛仔专长：购买牛牌",
		buildSpecial: "建筑师专长：建造",
		trainSpecial: "工程师专长：推进火车",
		marketAlternative: "牛仔专长购牛；其他专长取一张牛牌",
		buildAlternative: "建筑师专长建造；其他专长使用一名建筑师",
		trainAlternative: "工程师专长前往下一车站；其他专长前进一格"
	},
	specialization: "专长",
	result: "铁路总账",
	winner: "获胜",
	total: "总分",
	review: "回看最终局面",
	returnResult: "返回计分纸",
	again: "再开一局",
	lobby: "返回大厅",
	waitingHost: "等待主机决定",
	details: "计分明细",
	history: "行动记录",
	close: "关闭",
	empty: "暂无",
	faceDown: "张背面牌",
	starting: "起点",
	location: "地点",
	neutral: "中立建筑",
	neutralHint: "每组行动各可执行一次，顺序自选；同组的“或”只能选一项。也可放弃全部建筑行动，改做一次单辅助行动。",
	neutralActions: {
		A: [
			"弃 1 张加洛韦牛牌，获得 2 美元。",
			"雇佣 1 名工人，支付市场标价。",
			"额外雇佣 1 名工人，在市场标价外另付 2 美元。"
		],
		B: ["弃 1 张圣格特鲁迪斯牛牌，获得 2 美元。", "建造或升级自己的建筑，每名所需建筑师支付 2 美元。"],
		C: ["获得 1 张临时证书，或获得 1 张目标卡。", "火车前进至多等于工程师人数的步数。"],
		D: ["领取 1 次匪徒赏金，或支付 2 美元使火车前进至多 2 步。", "执行 1 次单辅助行动或双辅助行动。"],
		E: ["弃 2 张同品种牛牌，获得 4 美元。", "支付 7 美元，移除 1 块灾害板块。"],
		F: ["弃 1 张松林牛牌，获得 2 美元。", "使用牛仔在牛市场买牛，也可使用牛仔补充市场牛牌。"],
		G: ["火车前进至多等于工程师人数的步数。", "执行 1 次单辅助行动或双辅助行动。"]
	},
	risk: "风险行动",
	woods: "树林",
	woodsBuilding: "树林中的本方建筑",
	masterScore: {
		none: "",
		stations: "每 2 座车站得 3 分",
		certificates: "每 2 张证书得 3 分",
		hazards: "每 2 块灾害得 3 分",
		objectives: "每 2 张纳入计分的目标得 3 分",
		workers: "每名工人得 1 分",
		buildings: "每座本方建筑得 2 分",
		outlaws: "每对橙色与绿色匪徒得 3 分"
	},
	toll: "途经费用",
	value: "繁殖值",
	transport: "运输费",
	noChoice: "正在结算",
	objectiveSuccess: "完成",
	objectiveFail: "未完成",
	notSelected: "未纳入",
	master: "站长",
	workers: "工人",
	buyPair: "选择两张同值牛牌",
	cards: "张牌",
	source: "来源",
	railPosition: "火车位置",
	unlock: "解锁",
	back: "后退",
	forward: "前进",
	draw: "抽取",
	remove: "移除",
	pay: "支付",
	gain: "获得",
	or: "或",
	and: "并",
	buildingCost: "建筑师",
	handLimit: "手牌上限",
	moveLimit: "步数上限",
	certLimit: "证书上限",
	hint: "{{action}}：{{target}}",
	errAction: "此行动当前不可执行。",
	breed: {
		criollo: "克里奥罗牛",
		santa: "圣格特鲁迪斯牛",
		pineywoods: "松林牛",
		galloway: "加洛韦牛",
		longhorn: "长角牛",
		angus: "黑安格斯牛",
		corriente: "科连特牛",
		shorthorn: "短角牛",
		hereford: "赫里福德牛",
		simmental: "西门塔尔牛"
	},
	resource: {
		cowboy: "牛仔",
		builder: "建筑师",
		engineer: "工程师",
		orange: "橙色匪徒",
		green: "绿色匪徒",
		flood: "洪水",
		drought: "干旱",
		rockfall: "落石",
		building: "建筑",
		station: "车站",
		hazard: "灾害",
		cow3: "繁殖值 3 牛牌",
		cow4: "短角牛",
		cow5: "赫里福德牛",
		ny: "纽约圆片",
		cattle: "任意牛牌",
		criollo: "克里奥罗牛",
		pair: "两张同品种牛牌",
		any: "任意牌",
		objective: "目标牌",
		value3: "普通繁殖值 3 牛牌"
	},
	city: {
		kansas: "堪萨斯城",
		fulton: "富尔顿",
		stlouis: "圣路易斯",
		bloomington: "布卢明顿",
		peoria: "皮奥里亚",
		chicago: "芝加哥",
		toledo: "托莱多",
		pittsburgh: "匹兹堡",
		philadelphia: "费城",
		newyork: "纽约"
	},
	action: {
		skip: "放弃此行动",
		continue: "继续",
		end: "结束回合",
		exchange: "使用交换标记",
		discard: "弃牌",
		thin: "移除手牌",
		hire: "雇佣工人",
		build: "建造建筑",
		buy: "购买牛牌",
		marketDraw: "向市场增添牛牌",
		market: "购买牛牌",
		hazard: "清除灾害",
		bounty: "领取匪徒赏金",
		objective: "获得目标牌",
		train: "移动火车",
		railReturn: "火车返回",
		extraDelivery: "特别交付",
		station: "升级车站",
		stationBehind: "升级后方车站",
		master: "任命站长",
		delivery: "交付牛群",
		income: "领取收入",
		simmental: "升级西门塔尔牛",
		playObjective: "打出目标牌",
		aux: "辅助行动",
		cycle: "抽牌后弃牌",
		cert: "获得临时证书",
		money: "获得美元",
		pairs: "领取匪徒配对奖励",
		backCert: "火车后退并获得证书",
		backMoney: "火车后退并获得美元",
		backThin: "火车后退并移除牌",
		copy: "复制相邻建筑",
		foresight: "放置展望板块",
		herder: "移动牧人并使用地点",
		ride: "移动牧人",
		move: "移动牧人",
		discardInitial: "弃掉多余起手牌",
		discardCycle: "弃掉刚抽取的同数量牌",
		thinCards: "移除手牌",
		copiedLocal: "使用复制的建筑行动",
		masterChoice: "选择站长奖励",
		discardIncome: "弃掉收入手牌",
		stationAfter: "检查车站",
		draw: "抽牌",
		local: "使用建筑",
		final: "触发最后一轮",
		settle: "结算"
	},
	category: {
		0: "现金",
		1: "私人建筑",
		2: "城市与连接",
		3: "车站",
		4: "灾害",
		5: "牛牌",
		6: "目标",
		7: "站长",
		8: "工人",
		9: "步数解锁",
		10: "工作市场标记"
	},
	options: {
		buildings: "私人建筑面",
		a: "全部 A 面",
		b: "全部 B 面",
		mixed: "随机混合",
		neutral: "中立建筑顺序",
		fixed: "推荐顺序",
		random: "随机顺序",
		simmental: "西门塔尔牛变体",
		off: "关闭",
		on: "启用",
		difficulty: "Sam 难度（仅单人）",
		easy: "简单",
		medium: "普通",
		hard: "困难"
	}
}, ht = {
	name: "Great Western Trail",
	desc: "Build your ranch, improve your herd and deliver cattle to the cities of the East.",
	rules: "Edition: Great Western Trail: Second Edition (2021). Includes official Sam solo mode and optional Simmental. Rails to the North is not included.\nGoal: highest final score wins; ties share victory.\nTurn:\nComplete these three steps in order:\n· Move your herder.\n· Use the location you reach.\n· Refill your hand.\nOn your first turn, start at any neutral building. Later follow the arrows forward 1 to your movement limit. Empty spaces cost no steps. Pay the fees shown by hand symbols along the route; if short of money, pay only what you have.\nLocations: use each local action group once, in any order; choose one alternative in an OR group. If you use none, you may take one single auxiliary action instead. On opponents’ buildings, hazards and outlaws you may only take one single auxiliary action. Risk actions count as local actions. A building herder movement lets you use the new location; objective movement does not, and cannot enter Kansas City.\nHerd: hand limit starts at 4 and can reach 6. Refill at turn end. Reshuffle your discard pile only when you need to draw from an empty stack. Discarded cards remain in your herd unless explicitly removed. Exchange tokens can interrupt any turn: spend one, draw 1 or 2, then discard the same number.\nHire: hire from rows above the job market token, paying row cost plus the action adjustment. Each worker type has at most six including the printed starting worker. Filling bonus spaces allows their immediate actions; hiring again after appointing a station master can trigger them again.\nBuild: use sufficient builders and pay the cost per builder. Replacing your own building only uses and pays the difference; the replaced tile leaves play. You cannot use a newly replaced building during the current stop. Woods and risk spaces retain their board effects.\nBuy cattle: assign cowboys and pay the purchase price. Acquired cards go to your discard pile.\n· For a value-3 cow, use 1 cowboy and pay $6 for one card, use 2 cowboys and pay $3 for one card, or use 3 cowboys and pay $5 for two cards.\n· For a value-4 cow, use 1 cowboy and pay $12 for one card, use 3 cowboys and pay $6 for one card, or use 5 cowboys and pay $8 for two cards.\n· For a value-5 cow, use 2 cowboys and pay $12 for one card, or use 4 cowboys and pay $6 for one card.\nYou may split your cowboys between purchases, or use one cowboy to add two cards to the market.\nRailroad: move at least one and up to the allowed spaces; ignore occupied spaces. A turnout is an extra space. On a turnout you may pay to upgrade the station by placing a player disc, once per player per station. You may appoint a hired worker to acquire its available station master. Reaching space 39 forces a backward movement and awards $3; you may also upgrade the station where you land.\nKansas City: choose one tile in each foresight pair, placing it immediately. Workers advance the job market; filling rows 6/9 refills cattle. Reveal your entire hand: count only the highest value of each breed, plus permanent certificates and any temporary certificates you spend. Gain that many dollars and discard your hand. Deliver to a city at or below that value, place a player board disc and pay $1 per transport cross beyond your engine. Each city is once only except Kansas City and New York. Adjacent delivered cities unlock links. Return to the trail start, refill foresight, then refill your hand.\nDiscs: dark-corner discs normally require dark-corner destinations. Hand-limit discs cost $5 to clear. If only dark discs remain, white destinations are allowed. If no disc can be removed, reuse a station disc. Clearing the 6-certificate space only works after clearing the 4-certificate space.\nObjectives: play from hand before movement or during local actions to take their immediate action and commit to the tasks. Each resource can fulfil only one objective. Played failures lose points. At scoring, unplayed objectives may be added or removed. The game automatically selects the highest legal score allocation and lists every included objective and result.\nEnd: filling the final job space triggers the final round. That player completes their last turn; each other player gets one final turn. Score eleven categories: money, buildings, cities/links, stations, hazards, cattle, objectives, station masters, fifth/sixth worker slots, movement unlock and job market token.\nSam: solo uses two-player setup and official action cards; easy removes cards 13–15. Sam moves and acts according to the card and his specialization, without money or a herd draw deck. Deliveries start at Bloomington (Peoria on hard, with one extra worker of each type). All Sam objectives succeed; he scores no money, station master or player-board unlock points.\nSimmental: add eight stage-1 cards and two market spaces. To buy one stage-1 cow, use one cowboy and pay $8, or use two cowboys and pay $5. After taking Kansas City income, upgrade any stage-1/2 cards in your hand by one stage and put the new cards in your discard pile. All stages are one breed for income. Specific ordinary value-3/4/5 tasks exclude Simmental.",
	continue: "Continue",
	confirm: "Confirm",
	cancel: "Clear selection",
	skip: "Forfeit this action",
	end: "End turn",
	map: "Cattle trail",
	ledger: "Ranch ledger",
	market: "Cattle market",
	jobs: "Job market",
	rail: "Railroad & cities",
	ranch: "Player board",
	objectives: "Objectives",
	buildings: "Private buildings",
	hand: "Hand",
	discardPile: "Discard pile",
	deck: "Draw stack",
	money: "Dollars",
	vp: "VP",
	turn: "Turn",
	wait: "Waiting",
	choose: "Choose an action",
	chooseRoute: "Choose a herder destination",
	chooseCards: "Select hand cards, then confirm",
	chooseBuild: "Choose a building, then its trail space",
	chooseCity: "Choose a city and the disc to clear",
	chooseDisc: "Choose a disc to clear",
	step: "steps",
	cost: "Pay",
	income: "Herd income",
	certificate: "Temporary certificates",
	permanent: "Permanent certificates",
	exchange: "Exchange tokens",
	available: "Available",
	locked: "Locked",
	roundEnd: "Final round",
	sam: "Sam",
	samCard: "Sam action card",
	samAction: {
		hireCheap: "Hire cheapest worker",
		hireSpecial: "Hire by specialization",
		market: "Buy cattle",
		build: "Build",
		train: "Advance engine",
		objective: "Take farthest objective",
		bounty: "Collect highest bounty",
		hazard: "Remove hazard",
		marketSpecial: "Cowboy specialization: buy cattle",
		buildSpecial: "Builder specialization: build",
		trainSpecial: "Engineer specialization: advance engine",
		marketAlternative: "Cowboy: buy cattle; otherwise take one",
		buildAlternative: "Builder: build; otherwise use one builder",
		trainAlternative: "Engineer: next station; otherwise one space"
	},
	specialization: "Specialization",
	result: "The railroad ledger",
	winner: "Winner",
	total: "Total",
	review: "Review final board",
	returnResult: "Return to scores",
	again: "Play again",
	lobby: "Back to lobby",
	waitingHost: "Waiting for the host",
	details: "Score details",
	history: "Action log",
	close: "Close",
	empty: "None",
	faceDown: "face-down cards",
	starting: "Trail start",
	location: "Location",
	neutral: "Neutral building",
	neutralHint: "Use each action group once, in any order. Choose one option within an OR group. You may instead forfeit all building actions to take one single auxiliary action.",
	neutralActions: {
		A: [
			"Discard 1 Galloway to gain $2.",
			"Hire 1 worker at the job market price.",
			"Hire 1 more worker, paying an additional $2."
		],
		B: ["Discard 1 Santa Gertrudis to gain $2.", "Build or upgrade your building, paying $2 per required builder."],
		C: ["Gain 1 temporary certificate OR gain 1 objective card.", "Move your engine up to as many steps as you have engineers."],
		D: ["Collect 1 outlaw bounty OR pay $2 to move your engine up to 2 steps.", "Take 1 single or double auxiliary action."],
		E: ["Discard 2 cattle of the same breed to gain $4.", "Pay $7 to remove 1 hazard tile."],
		F: ["Discard 1 Pineywoods to gain $2.", "Use cowboys to buy cattle and/or add cattle cards to the market."],
		G: ["Move your engine up to as many steps as you have engineers.", "Take 1 single or double auxiliary action."]
	},
	risk: "Risk action",
	woods: "Woods",
	woodsBuilding: "own building in woods",
	masterScore: {
		none: "",
		stations: "3 VP per 2 stations",
		certificates: "3 VP per 2 certificates",
		hazards: "3 VP per 2 hazards",
		objectives: "3 VP per 2 included objectives",
		workers: "1 VP per worker",
		buildings: "2 VP per own building",
		outlaws: "3 VP per orange/green outlaw pair"
	},
	toll: "Route fees",
	value: "Breeding value",
	transport: "Transport",
	noChoice: "Resolving",
	objectiveSuccess: "Completed",
	objectiveFail: "Failed",
	notSelected: "Excluded",
	master: "Station master",
	workers: "Workers",
	buyPair: "Choose two cattle of the same value",
	cards: "cards",
	source: "Source",
	railPosition: "Engine position",
	unlock: "Unlock",
	back: "Move back",
	forward: "Move forward",
	draw: "Draw",
	remove: "Remove",
	pay: "Pay",
	gain: "Gain",
	or: "OR",
	and: "and",
	buildingCost: "Builders",
	handLimit: "Hand limit",
	moveLimit: "Movement limit",
	certLimit: "Certificate limit",
	hint: "{{action}}: {{target}}",
	errAction: "That action is not currently available.",
	breed: {
		criollo: "Criollo",
		santa: "Santa Gertrudis",
		pineywoods: "Pineywoods",
		galloway: "Galloway",
		longhorn: "Longhorn",
		angus: "Black Angus",
		corriente: "Corriente",
		shorthorn: "Shorthorn",
		hereford: "Hereford",
		simmental: "Simmental"
	},
	resource: {
		cowboy: "Cowboy",
		builder: "Builder",
		engineer: "Engineer",
		orange: "Orange outlaw",
		green: "Green outlaw",
		flood: "Flood",
		drought: "Drought",
		rockfall: "Rockfall",
		building: "Building",
		station: "Station",
		hazard: "Hazard",
		cow3: "Value-3 cattle",
		cow4: "Shorthorn",
		cow5: "Hereford",
		ny: "New York disc",
		cattle: "Any cattle",
		criollo: "Criollo",
		pair: "Two cattle of one breed",
		any: "Any card",
		objective: "Objective",
		value3: "Ordinary value-3 cattle"
	},
	city: {
		kansas: "Kansas City",
		fulton: "Fulton",
		stlouis: "St. Louis",
		bloomington: "Bloomington",
		peoria: "Peoria",
		chicago: "Chicago",
		toledo: "Toledo",
		pittsburgh: "Pittsburgh",
		philadelphia: "Philadelphia",
		newyork: "New York"
	},
	action: {
		skip: "Forfeit this action",
		continue: "Continue",
		end: "End turn",
		exchange: "Use exchange token",
		discard: "Discard cards",
		thin: "Remove cards",
		hire: "Hire a worker",
		build: "Build",
		buy: "Buy cattle",
		marketDraw: "Add market cards",
		market: "Buy cattle",
		hazard: "Remove a hazard",
		bounty: "Collect a bounty",
		objective: "Gain an objective",
		train: "Move engine",
		railReturn: "Return engine",
		extraDelivery: "Extraordinary delivery",
		station: "Upgrade station",
		stationBehind: "Upgrade a station behind",
		master: "Appoint station master",
		delivery: "Deliver cattle",
		income: "Take income",
		simmental: "Upgrade Simmental",
		playObjective: "Play objective",
		aux: "Auxiliary action",
		cycle: "Draw then discard",
		cert: "Gain certificates",
		money: "Gain dollars",
		pairs: "Collect outlaw-pair rewards",
		backCert: "Move back and gain certificates",
		backMoney: "Move back and gain dollars",
		backThin: "Move back and remove cards",
		copy: "Copy adjacent building",
		foresight: "Place foresight tile",
		herder: "Move herder and use location",
		ride: "Move herder",
		move: "Move herder",
		discardInitial: "Discard excess starting cards",
		discardCycle: "Discard the number drawn",
		thinCards: "Remove hand cards",
		copiedLocal: "Use copied local actions",
		masterChoice: "Choose station master reward",
		discardIncome: "Discard income hand",
		stationAfter: "Check station",
		draw: "Draw cards",
		local: "Use building",
		final: "Trigger final round",
		settle: "Resolve"
	},
	category: {
		0: "Money",
		1: "Buildings",
		2: "Cities & links",
		3: "Stations",
		4: "Hazards",
		5: "Cattle",
		6: "Objectives",
		7: "Station masters",
		8: "Workers",
		9: "Movement unlock",
		10: "Job market token"
	},
	options: {
		buildings: "Private building sides",
		a: "All A sides",
		b: "All B sides",
		mixed: "Random mix",
		neutral: "Neutral building order",
		fixed: "Recommended",
		random: "Random",
		simmental: "Simmental variant",
		off: "Off",
		on: "On",
		difficulty: "Sam difficulty (solo only)",
		easy: "Easy",
		medium: "Medium",
		hard: "Hard"
	}
}, Y = () => d((e) => e.locale) === "zh" ? mt : ht, X = (e, t) => typeof e[t] == "string" ? e[t] : t;
function gt(e, t) {
	let n = V(e);
	return n ? X(t.breed, n.breed) : `${t.objectives} ${B(e).toUpperCase()}`;
}
function _t(e, t, n) {
	return e === "kc" ? t.city.kansas : e === "start" ? t.starting : D[e]?.type === "neutral" ? `${t.neutral} ${n?.[e] || e}` : D[e]?.region ? `${X(t.resource, D[e].region)} ${D[e].index + 1}` : D[e]?.type === "outlaw" ? `${t.action.bounty} ${D[e].index + 1}` : t.location;
}
function vt(e, t) {
	if (e.startsWith("station:")) return `${t.source} ${t.master} ${Number(e.slice(8)) + 1}`;
	if (e.startsWith("hand")) return `${t.unlock} ${t.handLimit} ${e === "hand0" ? 5 : 6}`;
	if (e.startsWith("move")) return `${t.unlock} ${t.moveLimit} ${e === "move0" ? "Ⅰ" : "Ⅱ"}`;
	if (e.startsWith("limit")) return `${t.unlock} ${t.certLimit} ${e.slice(5)}`;
	let n = e.replace(/\d/g, "");
	return `${t.unlock} ${n === "cert" ? t.certificate : X(t.action, n)} ${e.endsWith("0") ? "Ⅰ" : "Ⅱ"}`;
}
function yt(e, t) {
	let n = e.n || 0;
	return e.kind === "discard" ? `${t.action.discard} ${n} · ${X(e.arg && e.arg in t.breed ? t.breed : t.resource, e.arg || "cattle")} → ${(e.then || []).map((e) => yt(e, t)).join(` ${t.and} `)}` : e.kind === "money" ? `${t.gain} ${n} ${t.money}${e.arg ? ` / ${e.arg === "woods" ? t.woodsBuilding : X(t.resource, e.arg === "stations" ? "station" : e.arg)}` : ""}` : e.kind === "train" && e.arg ? `${t.action.train} · ${e.arg === "woods" ? t.woods : X(t.resource, e.arg === "hazards" ? "hazard" : e.arg)}` : `${X(t.action, e.kind)}${n ? ` ${n}` : ""}${e.cost ? ` · ${t.pay} ${e.cost} ${t.money}` : ""}`;
}
function bt(e, t, n) {
	let r = JSON.parse(e.id);
	if (r.op === "local" || r.op === "copied") {
		let [n, i] = e.group.split(":"), a = (w[n]?.actions || C[n])?.[Number(i)]?.[r.n || 0];
		if (a) return yt(a, t);
	}
	let i = X(t.action, e.kind);
	return e.kind === "delivery" ? `${t.city[re[Number(e.target)].name]} · ${vt(e.group, t)} · ${t.pay} ${e.cost}` : e.kind === "hire" ? `${i} · ${X(t.resource, e.target)} · ${t.pay} ${e.cost}` : e.kind === "station" ? `${i} ${Number(e.target) + 1} · ${vt(e.group, t)} · ${t.pay} ${e.cost}` : e.kind === "master" ? `${i} · ${X(t.resource, e.group)}` : [
		"move",
		"herder",
		"ride",
		"copy",
		"hazard",
		"bounty"
	].includes(e.kind) ? `${i} · ${_t(e.target, t, n)}${e.amount ? ` · ${e.amount} ${e.kind === "hazard" ? t.vp : e.kind === "bounty" ? t.money : t.step}` : ""}${e.cost ? ` · ${t.pay} ${e.cost}` : ""}` : e.kind === "buy" ? `${i} · ${t.pay} ${e.cost} ${t.money} · ${e.amount} ${t.resource.cowboy}` : e.kind === "build" ? `${e.group.toUpperCase()} · ${_t(e.target, t)} · ${t.pay} ${e.cost}` : e.kind === "income" ? `${t.gain} ${e.amount} ${t.money} · ${t.certificate} ${e.cost}` : [
		"objective",
		"playObjective",
		"simmental"
	].includes(e.kind) ? `${i} · ${e.target === "deck" ? t.deck : gt(e.target, t)}` : e.kind === "foresight" ? `${i} ${Number(e.group) + 1} · ${X(t.resource, e.detail)}` : e.kind === "aux" ? `${i} · ${X(t.action, e.target)} ${e.amount}${e.cost ? ` · ${t.pay} ${e.cost}` : ""}` : [
		"train",
		"backMoney",
		"backCert",
		"backThin",
		"extraDelivery",
		"railReturn"
	].includes(e.kind) ? `${i} → ${e.target} · ${e.amount} ${t.step}` : `${i}${e.amount ? ` ${e.amount}` : ""}${e.cost ? ` · ${t.pay} ${e.cost}` : ""}`;
}
function xt(e, t) {
	return Object.entries(M[B(e)]?.tasks || {}).map(([e, n]) => `${X(t.resource, e)} ${n}`).join(" · ");
}
function St(e, t) {
	let n = N[e];
	return [
		n.permanent ? `${t.permanent} ${n.permanent}` : "",
		X(t.masterScore, n.score),
		...n.action.map((e) => yt(e, t))
	].filter(Boolean).join(" · ");
}
//#endregion
//#region src/games/greatwesterntrail/token-paths.ts
var Ct = {
	train: {
		path: "M3,19L3,22L1,26L2,28L2,39L4,41L3,43L5,43L9,48L11,48L12,49L11,50L12,49L14,51L18,51L19,52L17,53L47,53L50,55L50,67L48,68L48,71L45,73L42,73L41,72L39,73L36,77L33,79L31,83L27,87L23,97L23,108L24,109L24,138L25,139L25,149L26,150L26,153L30,161L33,164L35,164L36,166L39,166L40,168L60,168L61,167L62,168L62,172L63,171L64,172L65,183L66,184L66,188L68,194L73,201L78,205L78,207L81,208L83,211L87,213L90,213L91,214L137,214L139,212L141,212L145,209L146,207L151,204L165,186L166,187L184,187L185,188L185,191L186,190L187,191L188,196L189,196L191,200L193,201L193,203L198,207L198,209L200,209L204,212L209,214L252,214L255,212L258,212L258,211L261,209L263,209L263,208L266,206L270,201L271,201L272,198L274,197L274,195L278,192L280,193L279,197L291,207L294,211L296,211L299,213L303,213L304,214L330,214L331,213L338,212L340,209L342,209L343,207L346,206L347,204L352,201L352,200L354,199L355,195L357,194L357,192L361,187L382,187L383,185L385,185L386,183L389,182L389,181L392,179L395,173L397,172L398,163L399,162L399,67L398,66L397,58L396,58L395,55L393,54L394,53L392,52L392,50L391,50L389,47L383,42L380,42L379,41L380,40L372,40L370,39L369,37L365,35L365,18L364,19L363,18L362,11L361,12L357,5L354,4L353,2L351,1L347,1L346,0L313,0L307,2L306,4L303,5L303,7L301,8L300,12L299,13L298,12L297,22L295,23L295,31L293,32L292,34L291,32L281,32L276,28L273,24L266,20L265,18L263,18L261,16L258,15L255,15L254,13L248,13L247,12L230,12L229,13L224,13L225,14L224,15L222,15L221,17L218,18L218,19L215,21L214,24L209,28L209,30L206,34L187,34L185,32L185,28L183,27L182,23L180,22L180,19L179,20L178,19L178,16L177,13L175,12L175,10L173,9L169,2L164,0L31,0L30,1L24,2L17,6L15,6L8,12L6,16Z",
		width: 400,
		height: 215
	},
	herder: {
		path: "M64,0L64,73L65,74L64,77L59,82L56,82L51,84L46,84L42,86L27,86L26,87L23,87L18,90L16,94L16,97L14,103L12,106L12,109L10,112L10,115L8,121L4,129L4,133L3,134L2,141L0,144L0,192L1,193L0,211L1,212L1,220L2,221L3,232L6,235L7,238L11,240L14,243L17,244L23,244L24,245L30,245L34,248L32,261L31,262L31,266L29,271L27,285L25,290L25,294L24,295L24,299L23,300L23,304L21,310L88,310L89,299L90,298L90,292L91,291L91,284L92,283L92,277L93,276L93,269L94,268L94,262L95,261L95,254L96,253L96,247L97,246L97,239L99,234L114,234L115,235L125,310L192,310L190,304L188,290L186,285L184,271L182,266L182,262L181,261L179,248L183,245L189,245L190,244L196,244L199,243L202,240L206,238L207,235L210,232L211,221L212,220L212,212L213,211L213,204L212,203L212,193L213,192L213,144L211,141L211,138L209,133L209,129L205,121L203,115L203,112L201,109L201,106L197,97L197,94L195,90L190,87L187,87L186,86L171,86L167,84L162,84L161,83L154,82L149,77L148,74L149,73L149,0Z",
		width: 214,
		height: 311
	}
};
//#endregion
//#region src/games/greatwesterntrail/components.tsx
function wt({ tile: e }) {
	let t = Y(), n = [
		"cowboy",
		"builder",
		"engineer"
	].includes(e.kind);
	return /* @__PURE__ */ m("span", {
		className: "gwt-fx-tile",
		title: t.resource[e.kind],
		style: { background: e.kind === "green" ? "#456048" : e.kind === "orange" ? "#a96539" : "#ba9b72" },
		children: [/* @__PURE__ */ p(Z, {
			kind: n || ["orange", "green"].includes(e.kind) ? e.kind : "hazard",
			size: 24
		}), e.vp || ""]
	});
}
function Z({ kind: e, size: t = 20 }) {
	if (e === "train" || e === "herder") {
		let n = Ct[e];
		return /* @__PURE__ */ p("svg", {
			width: t,
			height: t,
			viewBox: `0 0 ${n.width} ${n.height}`,
			"aria-hidden": "true",
			children: /* @__PURE__ */ p("path", {
				d: n.path,
				fill: "currentColor",
				stroke: "#d6d5be",
				strokeWidth: "4"
			})
		});
	}
	return [
		"money",
		"cert",
		"hand",
		"blackhand",
		"building",
		"exchange",
		"cowboy",
		"builder",
		"engineer",
		"station",
		"hazard",
		"orange",
		"green",
		"cow3",
		"cow4",
		"cow5",
		"ny",
		"reward-aux",
		"reward-cycle",
		"reward-ride",
		"reward-train2",
		"reward-train3",
		"reward-money"
	].includes(e) ? /* @__PURE__ */ p("img", {
		className: "gwt-icon",
		width: t,
		height: t,
		style: {
			width: t,
			height: t
		},
		src: `games/greatwesterntrail/icon-${e}.svg`,
		alt: "",
		"aria-hidden": "true"
	}) : null;
}
function Q({ id: e, selected: t = !1, compact: n = !1 }) {
	let r = Y(), i = V(e), a = M[B(e)], o = i ? i.breed === "simmental" ? B(e) : i.breed : "";
	return a ? /* @__PURE__ */ m("span", {
		className: `gwt-card gwt-objective ${n ? "gwt-card-small" : ""} ${t ? "is-selected" : ""}`,
		title: `${xt(e, r)} · ${a.immediate.map((e) => yt(e, r)).join(" / ")}`,
		children: [
			/* @__PURE__ */ m("span", {
				className: "gwt-objective-head",
				children: [/* @__PURE__ */ p("img", {
					src: "games/greatwesterntrail/icon-trumpet.svg",
					alt: ""
				}), /* @__PURE__ */ p("span", { children: r.objectives })]
			}),
			/* @__PURE__ */ p("span", {
				className: "gwt-objective-reward",
				children: a.immediate.map((e, t) => /* @__PURE__ */ p("span", {
					title: yt(e, r),
					children: /* @__PURE__ */ p(Z, {
						kind: `reward-${e.kind}${e.kind === "train" ? e.n : ""}`,
						size: 27
					})
				}, t))
			}),
			/* @__PURE__ */ p("span", {
				className: "gwt-objective-tasks",
				children: Object.entries(a.tasks).map(([e, t]) => /* @__PURE__ */ m("span", {
					title: r.resource[e],
					children: [/* @__PURE__ */ p(Z, {
						kind: e,
						size: 30
					}), /* @__PURE__ */ m("b", { children: ["×", t] })]
				}, e))
			}),
			/* @__PURE__ */ m("span", {
				className: "gwt-card-bottom",
				children: [/* @__PURE__ */ m("b", { children: [
					a.vp,
					" ",
					r.vp
				] }), a.penalty > 0 && /* @__PURE__ */ m("small", { children: ["−", a.penalty] })]
			})
		]
	}) : /* @__PURE__ */ m("span", {
		className: `gwt-card ${n ? "gwt-card-small" : ""} ${t ? "is-selected" : ""}`,
		style: { "--gwt-card-color": i?.color || "#c3a158" },
		children: [
			/* @__PURE__ */ m("span", {
				className: "gwt-card-top",
				children: [/* @__PURE__ */ p("b", { children: i?.value ?? "" }), /* @__PURE__ */ p("span", { children: gt(e, r) })]
			}),
			i ? /* @__PURE__ */ p("img", {
				src: `games/greatwesterntrail/${o}.svg`,
				alt: "",
				draggable: !1
			}) : /* @__PURE__ */ p("span", {
				className: "gwt-objective-tasks",
				children: xt(e, r)
			}),
			/* @__PURE__ */ p("span", {
				className: "gwt-card-bottom",
				children: /* @__PURE__ */ m("b", { children: [
					i?.vp ?? 0,
					" ",
					r.vp
				] })
			})
		]
	});
}
function Tt({ id: e, selected: t, empty: n = !1 }) {
	let { ref: r, hidden: i } = c(`hand:${e}`);
	return /* @__PURE__ */ p("span", {
		ref: r,
		style: { visibility: i || n ? "hidden" : void 0 },
		children: /* @__PURE__ */ p(Q, {
			id: e,
			selected: t
		})
	});
}
function Et({ tile: e }) {
	let t = Y(), n = w[e];
	return /* @__PURE__ */ m("span", {
		className: "gwt-building",
		children: [/* @__PURE__ */ p("img", {
			src: `games/greatwesterntrail/building-${e}.svg`,
			alt: e.toUpperCase()
		}), n && /* @__PURE__ */ m("span", { children: [
			/* @__PURE__ */ p(Z, {
				kind: "builder",
				size: 16
			}),
			n.builders,
			/* @__PURE__ */ m("b", { children: [
				n.vp,
				" ",
				t.vp
			] })
		] })]
	});
}
function $({ name: e, children: t, className: n, inline: r = !1, style: i }) {
	let { ref: a, hidden: o } = c(e);
	return /* @__PURE__ */ p("div", {
		ref: a,
		className: n,
		style: {
			display: r ? "inline-flex" : void 0,
			...i,
			visibility: o ? "hidden" : i?.visibility
		},
		children: t
	});
}
function Dt({ name: e, children: t }) {
	let { ref: n, hidden: r } = c(e);
	return /* @__PURE__ */ p("g", {
		ref: n,
		style: { visibility: r ? "hidden" : void 0 },
		children: t
	});
}
function Ot({ rid: e, x: t, y: n, color: r, label: i }) {
	let a = Ct.herder;
	return /* @__PURE__ */ p("foreignObject", {
		x: t,
		y: n,
		width: "35",
		height: "44",
		children: /* @__PURE__ */ p($, {
			name: `herder:${e}`,
			children: /* @__PURE__ */ m("svg", {
				width: "35",
				height: "44",
				viewBox: `0 0 ${a.width} ${a.height}`,
				children: [/* @__PURE__ */ p("path", {
					d: a.path,
					fill: r,
					stroke: "#fff6d5",
					strokeWidth: "10"
				}), /* @__PURE__ */ p("text", {
					x: a.width / 2,
					y: a.height * .69,
					textAnchor: "middle",
					fontSize: "70",
					fill: "white",
					children: i
				})]
			})
		})
	});
}
//#endregion
//#region src/games/greatwesterntrail/view-player.tsx
var kt = [
	"train",
	"backMoney",
	"backCert",
	"backThin",
	"railReturn",
	"extraDelivery"
], At = [
	"move",
	"herder",
	"ride",
	"hazard",
	"bounty",
	"copy",
	"build"
], jt = (e) => ["local", "copied"].includes(JSON.parse(e.id).op), Mt = (e, t, n, r) => ({
	x: e - 130,
	y: t - 130,
	w: n,
	h: r
});
function Nt(e) {
	let t = Y(), n = d((e) => e.locale), r = e.public, c = e.private, [h, g] = i("map"), [_, v] = i(""), [y, ee] = i([]), [te, x] = i(""), [S, C] = i(-1), [ne, T] = i("auto"), [ie, ae] = i(!1), O = c?.choices || [], se = r.players.find((t) => t.rid === e.myRid), le = r.players.find((e) => e.rid === r.turn), A = (r) => r === "$sam" ? t.sam : e.members.find((e) => e.rid === r) ? u(e.members.find((e) => e.rid === r), n) : r, j = (t) => t === "$sam" ? "#604b34" : l[(e.members.find((e) => e.rid === t)?.colorIndex || 0) % l.length].hex, N = (t) => {
		e.send({
			type: "choose",
			id: t.id
		}), v(""), ee([]);
	}, P = O.find((e) => e.id === _), F = O.filter((e) => !jt(e) && At.includes(e.kind) && (!e.group || e.kind !== "build" || e.group === te)), I = O.filter((e) => e.cards.length && ["discard", "thin"].includes(e.kind)), ue = I.find((e) => e.cards.length === y.length && e.cards.every((e) => y.includes(e))), L = (e) => /* @__PURE__ */ p("button", {
		className: `gwt-button ${P?.id === e.id ? "is-active" : ""}`,
		onClick: () => N(e),
		children: bt(e, t, r.neutral)
	}, e.id), de = O.filter((e) => jt(e) || !At.includes(e.kind) && !kt.includes(e.kind) && ![
		"buy",
		"hire",
		"delivery",
		"station",
		"objective",
		"playObjective",
		"simmental",
		"foresight"
	].includes(e.kind) && !I.includes(e)), fe = r.task ? X(t.action, r.task) : r.phase === "move" ? t.chooseRoute : r.phase === "local" ? _t(r.local, t, r.neutral) : r.phase === "income" ? t.income : r.phase === "foresight" ? t.action.foresight : r.phase === "done" ? t.result : t.chooseCity, pe = r.motionTask ?? r.task, me = r.phase === "foresight" || pe === "foresight" ? "foresight" : pe === "hire" ? "jobs" : pe === "market" ? "market" : [
		"delivery",
		"station",
		"stationBehind",
		"master",
		...kt
	].includes(pe) ? "rail" : pe === "objective" ? "objectives" : pe === "build" ? "buildings" : "market", R = ne === "auto" ? me : ne, z = r.neutral[P?.target || (r.phase === "local" ? r.local : "")];
	return /* @__PURE__ */ p("div", {
		className: "gwt-screen",
		children: /* @__PURE__ */ p(a, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ m("header", {
				className: "gwt-header",
				children: [/* @__PURE__ */ m("div", {
					className: "gwt-title",
					children: [
						/* @__PURE__ */ p("small", { children: "GREAT WESTERN TRAIL · II" }),
						/* @__PURE__ */ p("strong", { children: t.name }),
						/* @__PURE__ */ m("span", { children: [
							t.turn,
							" ",
							r.turnNumber,
							" · ",
							r.finalTrigger ? t.roundEnd : A(r.turn)
						] })
					]
				}), /* @__PURE__ */ p("div", {
					className: "gwt-seats",
					children: r.players.map((e) => /* @__PURE__ */ p(Ft, {
						p: e,
						name: A(e.rid),
						color: j(e.rid),
						active: r.turn === e.rid
					}, e.rid))
				})]
			}),
			actionsHeight: "gwt-hand-height",
			actions: /* @__PURE__ */ m("div", {
				className: "gwt-hand-area",
				children: [
					/* @__PURE__ */ m("div", {
						className: "gwt-hand-label",
						children: [
							/* @__PURE__ */ m("strong", { children: [
								t.hand,
								" ",
								c?.hand.length || 0
							] }),
							/* @__PURE__ */ p("span", { children: I.length ? t.chooseCards : se ? `${t.deck} ${se.deckCount} · ${t.discardPile} ${se.discard.length}` : t.wait }),
							ue && /* @__PURE__ */ m("button", {
								className: "gwt-button gwt-primary",
								onClick: () => N(ue),
								children: [
									t.confirm,
									" · ",
									t.action[ue.kind]
								]
							})
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "gwt-hand-rail",
						children: [c?.handLayout.map((e) => /* @__PURE__ */ p("button", {
							disabled: !c.hand.includes(e) || !I.length && !O.some((t) => ["playObjective", "simmental"].includes(t.kind) && t.target === e),
							className: "gwt-card-pick",
							"aria-pressed": y.includes(e),
							"aria-label": gt(e, t),
							onClick: () => ee(y.includes(e) ? y.filter((t) => t !== e) : I.length ? [...y, e] : [e]),
							children: /* @__PURE__ */ p(Tt, {
								id: e,
								selected: y.includes(e),
								empty: !c.hand.includes(e)
							})
						}, e)), !c && /* @__PURE__ */ p("span", { children: t.wait })]
					}),
					y.length > 0 && !I.length && /* @__PURE__ */ m("div", {
						className: "gwt-hand-context",
						children: [O.filter((e) => ["playObjective", "simmental"].includes(e.kind) && y.includes(e.target)).map(L), /* @__PURE__ */ p("button", {
							className: "gwt-button",
							onClick: () => ee([]),
							children: t.cancel
						})]
					})
				]
			}),
			children: /* @__PURE__ */ m("div", {
				className: `gwt-workspace ${h === "ledger" ? "gwt-show-ledger" : ""}`,
				children: [
					/* @__PURE__ */ m("nav", {
						className: "gwt-mobile-tabs",
						children: [/* @__PURE__ */ p("button", {
							className: h === "map" ? "is-active" : "",
							onClick: () => g("map"),
							children: t.map
						}), /* @__PURE__ */ m("button", {
							className: h === "ledger" ? "is-active" : "",
							onClick: () => {
								g("ledger"), T("auto");
							},
							children: [t.ledger, O.length > 0 && r.task ? " •" : ""]
						})]
					}),
					/* @__PURE__ */ m("section", {
						className: "gwt-map-panel",
						children: [
							/* @__PURE__ */ m("div", {
								className: "gwt-map-caption",
								children: [
									/* @__PURE__ */ p("strong", { children: t.map }),
									/* @__PURE__ */ p("button", {
										className: "gwt-link",
										onClick: () => {
											g("ledger"), T("neutral");
										},
										children: t.neutral
									}),
									/* @__PURE__ */ p("button", {
										className: "gwt-link",
										onClick: () => ae(!ie),
										children: t.history
									})
								]
							}),
							/* @__PURE__ */ m(s, {
								sheetW: 870,
								sheetH: 870,
								fitKey: "gwt-trail",
								clampToSheet: !0,
								eligible: [...new Set(F.map((e) => e.target))].filter((e) => D[e]).map((e) => ({
									key: e,
									rect: Mt(D[e].x - 27, D[e].y - 27, 54, 54)
								})),
								onTapEligible: (e) => {
									let t = F.filter((t) => t.target === e);
									v(t.sort((e, t) => e.cost - t.cost || e.amount - t.amount)[0].id);
								},
								readOnly: !F.length,
								highlight: "inset",
								children: [/* @__PURE__ */ m("g", {
									transform: "translate(-130 -130)",
									children: [
										/* @__PURE__ */ p("image", {
											href: "games/greatwesterntrail/map.svg",
											x: "0",
											y: "0",
											width: "1000",
											height: "1000"
										}),
										/* @__PURE__ */ p("rect", {
											x: "130",
											y: "130",
											width: "870",
											height: "870",
											fill: "#eee6c4",
											opacity: ".14"
										}),
										E.flatMap((e) => e.next.map((t) => /* @__PURE__ */ p("path", {
											d: `M${e.x},${e.y} L${D[t].x},${D[t].y}`,
											stroke: "#f5e7bd",
											strokeWidth: "11",
											fill: "none"
										}, `${e.id}:${t}`))),
										E.flatMap((e) => e.next.map((t) => /* @__PURE__ */ p("path", {
											d: `M${e.x},${e.y} L${D[t].x},${D[t].y}`,
											stroke: "#8c7151",
											strokeWidth: "1.4",
											strokeDasharray: "3 5",
											fill: "none"
										}, `${e.id}:${t}`))),
										P?.path.length ? /* @__PURE__ */ p("path", {
											d: `M${le.position === "start" ? D.start.x : D[le.position].x},${D[le.position].y} ${P.path.map((e) => `L${D[e].x},${D[e].y}`).join(" ")}`,
											fill: "none",
											stroke: "#fff4b7",
											strokeWidth: "9",
											strokeLinecap: "round"
										}) : null,
										E.filter((e) => e.type !== "start").map((e) => {
											let t = r.buildings[e.id], n = t?.tile || r.neutral[e.id], i = r.hazards[e.id] || r.outlaws[e.id], a = n || i || e.id === "kc", o = n ? 70 : 42, s = n ? 58 : 38;
											return /* @__PURE__ */ m(Dt, {
												name: `place:${e.id}`,
												children: [
													/* @__PURE__ */ p("rect", {
														x: e.x - o / 2,
														y: e.y - s / 2,
														width: o,
														height: s,
														rx: "3",
														fill: n ? "#f0e2bb" : i ? i.kind === "orange" ? "#a96539" : i.kind === "green" ? "#456048" : "#ba9b72" : "#e7ddbd",
														stroke: t ? j(t.owner) : "#746952",
														strokeWidth: t ? 4 : 1.5,
														strokeDasharray: a ? void 0 : "3 4",
														opacity: a ? 1 : .75
													}),
													n && /* @__PURE__ */ p("foreignObject", {
														x: e.x - 33,
														y: e.y - 27,
														width: "66",
														height: "43",
														children: /* @__PURE__ */ p($, {
															name: `building:${e.id}`,
															children: /* @__PURE__ */ p("img", {
																src: `games/greatwesterntrail/building-${n}.svg`,
																width: "66",
																height: "43",
																alt: ""
															})
														})
													}),
													/* @__PURE__ */ p("text", {
														x: e.x,
														y: e.y + (n ? 26 : 4),
														fontSize: n ? 13 : 12,
														textAnchor: "middle",
														fontWeight: "bold",
														fill: i ? "#fff3da" : "#403b2d",
														children: n ? n.toUpperCase() : e.id === "kc" ? "KANSAS CITY" : ""
													}),
													i && /* @__PURE__ */ p("foreignObject", {
														x: e.x - 21,
														y: e.y - 19,
														width: "42",
														height: "38",
														children: /* @__PURE__ */ p(wt, { tile: i })
													}),
													e.woods && !n && /* @__PURE__ */ p("text", {
														x: e.x + 15,
														y: e.y - 15,
														fontSize: "13",
														fill: "#406a41",
														children: "♠"
													}),
													[...i?.hand || t && w[t.tile].hands || ""].map((t, n) => /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("image", {
														href: `games/greatwesterntrail/icon-${t === "g" ? "hand" : "blackhand"}.svg`,
														x: e.x - 25 + n * 26,
														y: e.y - 24,
														width: "17",
														height: "21"
													}), /* @__PURE__ */ p("text", {
														x: e.x - 11 + n * 26,
														y: e.y - 8,
														fontSize: "11",
														fontWeight: "bold",
														fill: "#fff8db",
														stroke: "#302b21",
														strokeWidth: "2",
														paintOrder: "stroke",
														children: t === "g" ? r.players.length === 4 ? 1 : 2 : r.players.length === 3 ? 1 : 2
													})] }, n))
												]
											}, e.id);
										}),
										r.players.map((e, t) => {
											let n = D[e.position], i = r.players.filter((t) => t.position === e.position).findIndex((t) => t.rid === e.rid) * 14;
											return /* @__PURE__ */ p(Ot, {
												rid: e.rid,
												x: n.x - 19 + i,
												y: n.y - 43 - t % 2 * 3,
												color: j(e.rid),
												label: e.rid === "$sam" ? "S" : String(t + 1)
											}, e.rid);
										})
									]
								}), E.map((e) => /* @__PURE__ */ p(o, {
									name: `node:${e.id}`,
									r: Mt(e.x - 22, e.y - 22, 44, 44)
								}, e.id))]
							}),
							/* @__PURE__ */ m("div", {
								className: "gwt-context",
								children: [
									/* @__PURE__ */ m("div", {
										className: "gwt-context-title",
										children: [/* @__PURE__ */ p("strong", { children: fe }), /* @__PURE__ */ p("span", { children: r.turn === e.myRid || c?.interrupt ? t.choose : `${t.wait} · ${A(r.turn)}` })]
									}),
									z && /* @__PURE__ */ p(Pt, {
										tile: z,
										showTitle: fe !== `${t.neutral} ${z}`
									}),
									P && At.includes(P.kind) && /* @__PURE__ */ m("div", {
										className: "gwt-confirm",
										children: [
											/* @__PURE__ */ p("span", { children: bt(P, t, r.neutral) }),
											/* @__PURE__ */ p("button", {
												className: "gwt-button gwt-primary",
												onClick: () => N(P),
												children: t.confirm
											}),
											/* @__PURE__ */ p("button", {
												className: "gwt-button",
												onClick: () => v(""),
												children: t.cancel
											})
										]
									}),
									/* @__PURE__ */ m("div", {
										className: "gwt-local-actions",
										children: [
											de.map(L),
											I.length > 0 && /* @__PURE__ */ p("span", { children: t.chooseCards }),
											O.some((e) => e.kind === "build") && /* @__PURE__ */ p("button", {
												className: "gwt-button",
												onClick: () => {
													g("ledger"), T("buildings");
												},
												children: t.chooseBuild
											}),
											O.some((e) => [
												"buy",
												"hire",
												"delivery",
												"station",
												"objective",
												"foresight",
												...kt
											].includes(e.kind)) && /* @__PURE__ */ m("button", {
												className: "gwt-button gwt-primary",
												onClick: () => {
													g("ledger"), T("auto");
												},
												children: [fe, " →"]
											}),
											!O.length && r.phase !== "done" && /* @__PURE__ */ p("span", { children: t.noChoice })
										]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ m("aside", {
						className: "gwt-ledger",
						children: [/* @__PURE__ */ p("nav", {
							className: "gwt-ledger-tabs",
							children: [
								"auto",
								"market",
								"jobs",
								"rail",
								"ranch",
								"objectives",
								"buildings",
								"neutral"
							].map((e) => /* @__PURE__ */ p("button", {
								className: ne === e ? "is-active" : "",
								onClick: () => T(e),
								children: e === "auto" ? t.choose : X(t, e)
							}, e))
						}), /* @__PURE__ */ m("div", {
							className: "gwt-ledger-scroll",
							children: [
								/* @__PURE__ */ m("div", {
									className: "gwt-ledger-heading",
									children: [/* @__PURE__ */ p("small", { children: "GREAT WESTERN TRAIL" }), /* @__PURE__ */ p("h2", { children: R === "foresight" ? t.action.foresight : X(t, R) })]
								}),
								R === "market" && /* @__PURE__ */ m(f, { children: [
									/* @__PURE__ */ p("div", {
										className: "gwt-market-grid",
										children: r.marketLayout.map((e) => /* @__PURE__ */ p(It, {
											id: e,
											empty: !r.market.includes(e),
											choices: O.filter((t) => t.kind === "buy" && (t.cards.includes(e) || t.target === e)),
											pick: _,
											setPick: v
										}, e))
									}),
									P?.kind === "buy" && /* @__PURE__ */ m("div", {
										className: "gwt-purchase",
										children: [
											/* @__PURE__ */ p("div", { children: bt(P, t, r.neutral) }),
											P.cards.map((e) => /* @__PURE__ */ m("span", { children: [gt(e, t), " · "] }, e)),
											/* @__PURE__ */ p("button", {
												className: "gwt-button gwt-primary",
												onClick: () => N(P),
												children: t.confirm
											})
										]
									}),
									O.filter((e) => e.kind === "marketDraw").map(L),
									/* @__PURE__ */ p($, {
										name: "market-deck",
										children: /* @__PURE__ */ m("span", {
											className: "gwt-muted",
											children: [
												t.deck,
												" ",
												r.marketLeft
											]
										})
									})
								] }),
								R === "jobs" && /* @__PURE__ */ p($, {
									name: "jobs",
									className: "gwt-jobs",
									children: oe.map((e, n) => /* @__PURE__ */ m("div", {
										className: `gwt-job-row ${Math.floor(r.jobProgress / r.players.length) === n ? "is-current" : ""}`,
										children: [/* @__PURE__ */ m("strong", { children: ["$", e] }), r.jobs.slice(n * r.players.length, (n + 1) * r.players.length).map((e, i) => {
											let a = O.find((e) => e.kind === "hire" && JSON.parse(e.id).n === n * r.players.length + i);
											return /* @__PURE__ */ p("button", {
												className: `gwt-worker ${a ? "is-legal" : ""}`,
												disabled: !a,
												onClick: () => a && N(a),
												children: /* @__PURE__ */ p($, {
													name: `job:${n * r.players.length + i}`,
													inline: !0,
													children: e ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(Z, { kind: e.kind }), /* @__PURE__ */ p("span", { children: X(t.resource, e.kind) })] }) : /* @__PURE__ */ p("span", { children: "—" })
												})
											}, i);
										})]
									}, n))
								}),
								R === "rail" && /* @__PURE__ */ m(f, { children: [
									/* @__PURE__ */ p("div", {
										className: "gwt-cities",
										children: re.map((e, n) => /* @__PURE__ */ m("button", {
											className: `gwt-city ${S === n ? "is-active" : ""} ${e.dark ? "gwt-dark" : ""}`,
											onClick: () => C(n),
											children: [
												/* @__PURE__ */ p("span", { children: t.city[e.name] }),
												/* @__PURE__ */ p("b", { children: e.value }),
												/* @__PURE__ */ p("span", { children: /* @__PURE__ */ p($, {
													inline: !0,
													name: `delivery:${n}`,
													children: r.players.flatMap((e) => e.cities.flatMap((t, r) => t === n ? [/* @__PURE__ */ p($, {
														inline: !0,
														name: `delivery-disc:${e.rid}:${r}`,
														children: /* @__PURE__ */ p("i", {
															style: { background: j(e.rid) },
															title: A(e.rid),
															children: A(e.rid).slice(0, 1)
														})
													}, `${e.rid}:${r}`)] : []))
												}) })
											]
										}, e.name))
									}),
									S >= 0 && O.filter((e) => e.kind === "delivery" && Number(e.target) === S).map(L),
									/* @__PURE__ */ p("div", {
										className: "gwt-rail-track",
										children: Array.from({ length: 40 }, (e, n) => /* @__PURE__ */ m($, {
											name: `rail:${n}`,
											className: "gwt-rail-step",
											children: [
												/* @__PURE__ */ p("b", { children: n }),
												r.players.filter((e) => Math.floor(e.train) === n).map((e) => /* @__PURE__ */ m($, {
													name: `train:${e.rid}`,
													style: { color: j(e.rid) },
													children: [/* @__PURE__ */ p("span", { children: A(e.rid) }), /* @__PURE__ */ p(Z, { kind: "train" })]
												}, e.rid)),
												O.filter((e) => kt.includes(e.kind) && Math.floor(Number(e.target)) === n).map((e) => /* @__PURE__ */ p("button", {
													className: `gwt-rail-pick ${_ === e.id ? "is-active" : ""}`,
													onClick: () => v(e.id),
													"aria-label": bt(e, t, r.neutral),
													children: Number(e.target) % 1 ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(Z, {
														kind: "station",
														size: 17
													}), t.master] }) : t.confirm
												}, e.id))
											]
										}, n))
									}),
									P && kt.includes(P.kind) && /* @__PURE__ */ m("div", {
										className: "gwt-purchase",
										children: [
											/* @__PURE__ */ p("span", { children: bt(P, t, r.neutral) }),
											/* @__PURE__ */ p("button", {
												className: "gwt-button gwt-primary",
												onClick: () => N(P),
												children: t.confirm
											}),
											/* @__PURE__ */ p("button", {
												className: "gwt-button",
												onClick: () => v(""),
												children: t.cancel
											})
										]
									}),
									/* @__PURE__ */ p("div", {
										className: "gwt-stations",
										children: k.map((e, n) => /* @__PURE__ */ m($, {
											name: `station:${n}`,
											className: "gwt-station",
											children: [
												/* @__PURE__ */ m("strong", { children: [
													t.master,
													" ",
													n + 1,
													" · ",
													e.at,
													" · $",
													e.cost,
													" · ",
													e.vp,
													" ",
													t.vp
												] }),
												r.stationMasters[n] !== null && /* @__PURE__ */ p("span", { children: St(r.stationMasters[n], t) }),
												r.players.filter((e) => e.stations.includes(n)).map((e) => /* @__PURE__ */ m($, {
													inline: !0,
													name: `station-disc:${e.rid}:${n}`,
													children: [/* @__PURE__ */ p("i", {
														className: "gwt-player-disc",
														style: { background: j(e.rid) }
													}), A(e.rid)]
												}, e.rid)),
												O.filter((e) => e.kind === "station" && Number(e.target) === n).map(L)
											]
										}, n))
									}),
									O.filter((e) => e.kind === "master").map(L)
								] }),
								R === "ranch" && r.players.map((e) => /* @__PURE__ */ m("div", {
									className: "gwt-ranch",
									children: [
										/* @__PURE__ */ p("h3", { children: A(e.rid) }),
										/* @__PURE__ */ m("div", {
											className: "gwt-ranch-resources",
											children: [
												/* @__PURE__ */ m("span", { children: [
													/* @__PURE__ */ p(Z, { kind: "cert" }),
													e.certificates,
													"/",
													_e(e)
												] }),
												/* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p(Z, { kind: "exchange" }), e.exchange] }),
												/* @__PURE__ */ m("span", { children: [
													t.handLimit,
													" ",
													ge(e)
												] }),
												/* @__PURE__ */ m("span", { children: [
													t.moveLimit,
													" ",
													ve(e, r.players.length)
												] })
											]
										}),
										b.map((n) => /* @__PURE__ */ m("div", {
											className: "gwt-worker-track",
											children: [
												/* @__PURE__ */ p(Z, { kind: n }),
												/* @__PURE__ */ p("span", { children: X(t.resource, n) }),
												Array.from({ length: 6 }, (t, r) => /* @__PURE__ */ p("b", {
													className: e.workers[n] > r ? "is-filled" : "",
													children: r + 1
												}, r))
											]
										}, n)),
										/* @__PURE__ */ p("div", {
											className: "gwt-discs",
											children: ce.map((n) => /* @__PURE__ */ m("span", {
												className: e.discs.includes(n) ? "is-locked" : "",
												children: [
													e.discs.includes(n) ? "●" : "○",
													" ",
													vt(n, t)
												]
											}, n))
										}),
										/* @__PURE__ */ m("p", { children: [
											t.action.hazard,
											" ",
											e.hazards.length,
											" · ",
											t.resource.orange,
											" ",
											e.outlaws.filter((e) => e.kind === "orange").length,
											" · ",
											t.resource.green,
											" ",
											e.outlaws.filter((e) => e.kind === "green").length
										] }),
										/* @__PURE__ */ m("details", { children: [/* @__PURE__ */ m("summary", { children: [
											t.discardPile,
											" ",
											e.discard.length
										] }), /* @__PURE__ */ p("div", {
											className: "gwt-card-list",
											children: e.discard.map((e) => /* @__PURE__ */ p(Q, {
												id: e,
												compact: !0
											}, e))
										})] }),
										/* @__PURE__ */ m("details", { children: [/* @__PURE__ */ m("summary", { children: [
											t.objectives,
											" ",
											e.objectives.length
										] }), e.objectives.map((e) => /* @__PURE__ */ p("p", { children: xt(e, t) }, e))] })
									]
								}, e.rid)),
								R === "objectives" && /* @__PURE__ */ m(f, { children: [
									/* @__PURE__ */ p($, {
										name: "objective-deck",
										children: /* @__PURE__ */ m("span", {
											className: "gwt-muted",
											children: [
												t.deck,
												" ",
												r.objectiveLeft
											]
										})
									}),
									/* @__PURE__ */ p("div", {
										className: "gwt-market-grid",
										children: r.objectiveLayout.map((e) => /* @__PURE__ */ p($, {
											name: `objective:${e}`,
											style: { visibility: r.objectives.includes(e) ? void 0 : "hidden" },
											children: /* @__PURE__ */ p("button", {
												className: `gwt-card-pick ${O.some((t) => t.kind === "objective" && t.target === e) ? "is-legal" : ""}`,
												disabled: !O.some((t) => t.kind === "objective" && t.target === e),
												onClick: () => N(O.find((t) => t.kind === "objective" && t.target === e)),
												children: /* @__PURE__ */ p(Q, { id: e })
											}, e)
										}, e))
									}),
									O.filter((e) => e.kind === "objective" && e.target === "deck").map(L),
									r.players.map((e) => /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ m("summary", { children: [
										A(e.rid),
										" · ",
										t.objectives,
										" ",
										e.objectives.length
									] }), e.objectives.map((e) => /* @__PURE__ */ m("p", { children: [
										xt(e, t),
										" · ",
										M[B(e)].vp,
										"/",
										-M[B(e)].penalty
									] }, e))] }, e.rid))
								] }),
								R === "buildings" && /* @__PURE__ */ p("div", {
									className: "gwt-building-grid",
									children: r.sides.map((e) => /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("button", {
										className: `gwt-building-pick ${te === e ? "is-active" : ""}`,
										onClick: () => {
											x(e), g("map");
										},
										disabled: !O.some((t) => t.kind === "build" && t.group === e),
										children: /* @__PURE__ */ p($, {
											name: `supply:${e}`,
											children: /* @__PURE__ */ p(Et, { tile: e })
										})
									}), /* @__PURE__ */ p("div", {
										className: "gwt-building-rules",
										children: w[e].actions.map((e, n) => /* @__PURE__ */ p("p", { children: e.map((e) => yt(e, t)).join(` ${t.or} `) }, n))
									})] }, e))
								}),
								R === "neutral" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("p", {
									className: "gwt-neutral-hint",
									children: t.neutralHint
								}), /* @__PURE__ */ p("div", {
									className: "gwt-neutral-list",
									children: Object.keys(t.neutralActions).map((e) => /* @__PURE__ */ m("article", { children: [/* @__PURE__ */ p(Et, { tile: e }), /* @__PURE__ */ p(Pt, { tile: e })] }, e))
								})] }),
								(r.phase === "foresight" || r.motionTask === "foresight") && /* @__PURE__ */ p("div", {
									className: "gwt-foresight",
									children: r.foresight.map((e, t) => /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("strong", { children: t + 1 }), e.map((e, n) => {
										let r = O.find((e) => e.kind === "foresight" && Number(e.group) === t && Number(e.target) === n);
										return /* @__PURE__ */ p("button", {
											disabled: !r,
											className: `gwt-button ${r ? "is-legal" : ""}`,
											onClick: () => r && N(r),
											children: /* @__PURE__ */ p($, {
												inline: !0,
												name: `foresight:${t}:${n}`,
												children: e ? /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p(wt, { tile: e }) }) : "—"
											})
										}, n);
									})] }, t))
								}),
								O.some((e) => ["delivery", "station"].includes(e.kind)) && /* @__PURE__ */ p("p", {
									className: "gwt-muted",
									children: t.chooseDisc
								})
							]
						})]
					}),
					ie && /* @__PURE__ */ m("div", {
						className: "gwt-history",
						children: [/* @__PURE__ */ p("button", {
							className: "gwt-button",
							onClick: () => ae(!1),
							children: t.close
						}), r.log.slice().reverse().map((e, n) => /* @__PURE__ */ m("p", { children: [
							e.turn,
							" · ",
							A(e.rid),
							" · ",
							X(t.action, e.kind),
							" ",
							e.target && D[e.target] ? _t(e.target, t, r.neutral) : X(t.resource, e.target),
							" ",
							e.amount || ""
						] }, n))]
					})
				]
			})
		})
	});
}
function Pt({ tile: e, showTitle: t = !0 }) {
	let n = Y(), r = n.neutralActions[e];
	return r && /* @__PURE__ */ m("div", {
		className: "gwt-neutral-info",
		children: [t && /* @__PURE__ */ m("strong", { children: [
			n.neutral,
			" ",
			e
		] }), /* @__PURE__ */ p("ul", { children: r.map((e) => /* @__PURE__ */ p("li", { children: e }, e)) })]
	});
}
function Ft({ p: e, name: t, color: n, active: r }) {
	let { ref: i } = c(`seat:${e.rid}`), a = Y();
	return /* @__PURE__ */ m("div", {
		ref: i,
		className: `gwt-seat ${r ? "is-active" : ""}`,
		style: { "--gwt-player": n },
		children: [
			/* @__PURE__ */ p("strong", { children: t }),
			/* @__PURE__ */ m("span", { children: [
				/* @__PURE__ */ p(Z, {
					kind: "money",
					size: 17
				}),
				e.money,
				/* @__PURE__ */ p(Z, {
					kind: "cert",
					size: 17
				}),
				e.certificates
			] }),
			/* @__PURE__ */ p("span", { children: b.map((t) => /* @__PURE__ */ m("i", { children: [/* @__PURE__ */ p(Z, {
				kind: t,
				size: 16
			}), e.workers[t]] }, t)) }),
			/* @__PURE__ */ m("small", { children: [
				/* @__PURE__ */ p($, {
					inline: !0,
					name: `deck:${e.rid}`,
					children: /* @__PURE__ */ m("span", { children: [
						a.deck,
						" ",
						e.deckCount
					] })
				}),
				" · ",
				/* @__PURE__ */ p($, {
					inline: !0,
					name: `discard:${e.rid}`,
					children: /* @__PURE__ */ m("span", { children: [
						a.discardPile,
						" ",
						e.discard.length
					] })
				})
			] }),
			/* @__PURE__ */ m("small", { children: [
				/* @__PURE__ */ m($, {
					inline: !0,
					name: `played:${e.rid}`,
					children: [
						a.objectives,
						" ",
						e.objectives.length
					]
				}),
				" · ",
				e.sam ? `${a.specialization} · ${X(a.resource, e.specialization)}` : `${a.hand} ${e.handCount}`
			] })
		]
	});
}
function It({ id: e, choices: t, pick: n, setPick: r, empty: i }) {
	let { ref: a, hidden: o } = c(`market:${e}`), s = Y();
	return /* @__PURE__ */ m("div", {
		className: "gwt-market-item",
		style: { visibility: i || o ? "hidden" : void 0 },
		children: [/* @__PURE__ */ p("button", {
			ref: a,
			className: `gwt-card-pick ${t.length ? "is-legal" : ""}`,
			disabled: !t.length,
			"aria-label": gt(e, s),
			onClick: () => r(t[0].id),
			children: /* @__PURE__ */ p(Q, {
				id: e,
				selected: t.some((e) => e.id === n)
			})
		}), t.some((e) => e.id === n) && t.map((e) => /* @__PURE__ */ m("button", {
			className: `gwt-price ${e.id === n ? "is-active" : ""}`,
			onClick: () => r(e.id),
			children: [
				"$",
				e.cost,
				" · ",
				e.amount,
				/* @__PURE__ */ p(Z, {
					kind: "cowboy",
					size: 14
				})
			]
		}, e.id))]
	});
}
//#endregion
//#region src/games/greatwesterntrail/bot.ts
function Lt(e, t, n, r, i = !0) {
	let a = t.players.find((e) => e.rid === r), o = n.hand, s = e.id.startsWith("{") ? JSON.parse(e.id) : {}, c = new Set(o.map((e) => V(e)?.breed).filter(Boolean)), l = [...c].reduce((e, t) => e + Math.max(...o.filter((e) => V(e)?.breed === t).map((e) => V(e).value)), 0) + a.permanent + a.certificates;
	switch (e.kind) {
		case "skip": return -100;
		case "continue": return 0;
		case "end": return -80;
		case "exchange": return -120;
		case "discard":
		case "thin": return 10 - e.cards.reduce((t, n) => {
			let r = V(n);
			return t + (r ? r.value + r.vp * (e.kind === "thin" ? 2 : .1) - (o.filter((e) => V(e)?.breed === r.breed).length > 1 ? 3 : 0) : -1);
		}, 0);
		case "hire": {
			if (s.op === "local" || s.op === "copied") return 15;
			let n = a.workers[e.target];
			return 18 - e.cost * .6 - n * 1.5 + (n === 3 || n === 4 ? 4 : 0) + (e.target === "cowboy" && t.market.length ? 2 : 0);
		}
		case "build": return 18 + (w[e.group]?.vp || 0) * 1.5 - e.cost * .45 + (D[e.target]?.woods ? 1.5 : 0);
		case "buy": return 12 + (e.cards.length ? e.cards : [e.target]).reduce((e, t) => e + (V(t)?.vp || 0) + (c.has(V(t)?.breed) ? 0 : 2), 0) - e.cost * .55 - e.amount * .25;
		case "marketDraw": return 1;
		case "market": return a.money >= 6 ? 15 : -2;
		case "hazard": return 9 + e.amount * 1.7 - e.cost * .6;
		case "bounty": return 9 + e.amount;
		case "objective": return s.op === "local" || s.op === "copied" ? 4 : e.target === "deck" ? -1 : 1 + (M[B(e.target)]?.tasks.building ? a.buildings.length : 0);
		case "train": return 5 + e.amount * 1.1 + (e.target.includes(".") ? 2 : 0);
		case "railReturn": return Number(e.target) * .2;
		case "extraDelivery": return e.amount + 3;
		case "station": return 10 + Number(e.target) * .8 - e.cost * .5 + (e.group.startsWith("hand") ? 4 : 0);
		case "master": return 15 - a.workers[e.group] * -.5;
		case "delivery": return Number(e.target) * 2 + (e.group.startsWith("hand") ? i ? 5 : 1 : 0) + (e.group === "move0" ? 3 : 0) + (e.group === "train0" || e.group === "thin0" ? 2 : 0) - e.cost * .35;
		case "income": return Math.min(18, e.amount) - e.cost * .1;
		case "simmental": return 20;
		case "playObjective": {
			let t = M[B(e.target)];
			return Object.entries(t.tasks).every(([e, t]) => e === "building" ? a.buildings.length >= t : e === "station" ? a.stations.length >= t : e === "hazard" ? a.hazards.length >= t : e === "ny" ? a.cities.includes(9) : e === "orange" || e === "green" ? a.outlaws.filter((t) => t.kind === e).length >= t : o.filter((t) => V(t)?.value === Number(e.slice(3))).length >= t) ? 15 : -110;
		}
		case "aux": return e.target === "money" ? a.money < 6 ? 3 : 1 : e.target === "thin" ? 4 : e.target === "train" ? 2 : 0;
		case "cycle": return 3 + e.amount * .1;
		case "cert": return a.certificates < 2 ? 4 : 1;
		case "money": return 8 + e.amount;
		case "pairs": return a.outlaws.length ? 12 : 0;
		case "backCert": return 1;
		case "backMoney": return 4 + Number(e.target) * .01;
		case "backThin": return 8 + Number(e.target) * .01;
		case "copy": return 5;
		case "foresight": return [
			"cowboy",
			"builder",
			"engineer"
		].includes(e.detail) ? 4 + +(a.workers[e.detail] < 3) : 2;
		case "herder":
		case "ride":
		case "move": {
			let n = e.target;
			if (n === "kc") return 12 + Math.min(18, l) * .65 + (a.money < 5 ? 6 : 0) - e.cost * .4;
			let i = t.neutral[n], o = i === "A" ? a.money >= 6 ? 18 : 5 : i === "B" ? a.money >= 2 ? 14 : 4 : i === "F" ? a.money >= 6 ? 17 : 3 : i === "C" || i === "G" ? 9 : i === "D" ? 11 : 5, s = t.buildings[n];
			s?.owner === r && (o = 11 + w[s.tile].vp * .3), (s && s.owner !== r || t.hazards[n] || t.outlaws[n]) && (o = 0);
			let c = (1e3 - (D[n]?.y || 0)) / 1e3;
			return o + c * 2 + e.amount * .7 - e.cost * .8;
		}
		default: return 0;
	}
}
var Rt = (e, t) => {
	let n = e.private;
	if (!n?.choices.length) return null;
	let r = n.choices.filter((e) => e.kind !== "exchange");
	return { action: {
		type: "choose",
		id: (r.length ? r : n.choices).map((r) => ({
			c: r,
			value: Lt(r, e.public, n, t.rid, t.difficulty !== "weak")
		})).sort((e, t) => t.value - e.value || e.c.id.localeCompare(t.c.id))[0].c.id
	} };
};
//#endregion
//#region src/games/greatwesterntrail/fx.tsx
function zt({ points: e, ms: t, color: i }) {
	let a = r(null), o = Ct.herder;
	return n(() => {
		let n = e[0], r = a.current?.animate(e.map((t, r) => ({
			transform: `translate(${t.x - n.x}px,${t.y - n.y}px)`,
			offset: r / (e.length - 1)
		})), {
			duration: t,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => r?.cancel();
	}, [e, t]), /* @__PURE__ */ p("div", {
		ref: a,
		style: {
			position: "absolute",
			left: e[0].x,
			top: e[0].y,
			width: e[0].w,
			height: e[0].h
		},
		children: /* @__PURE__ */ p("svg", {
			width: "100%",
			height: "100%",
			viewBox: `0 0 ${o.width} ${o.height}`,
			children: /* @__PURE__ */ p("path", {
				d: o.path,
				fill: i,
				stroke: "#fff6d5",
				strokeWidth: "10"
			})
		})
	});
}
function Bt() {
	return /* @__PURE__ */ p("span", {
		className: "gwt-card gwt-card-back",
		children: "GWT"
	});
}
function Vt({ from: e, to: t, ms: i }) {
	let a = r(null), o = r(null);
	return n(() => {
		let e = a.current?.animate([{
			opacity: 1,
			transform: "rotateY(0)"
		}, {
			opacity: 0,
			transform: "rotateY(90deg)"
		}], {
			duration: i * .55,
			fill: "forwards"
		}), t = o.current?.animate([{
			opacity: 0,
			transform: "rotateY(-90deg)"
		}, {
			opacity: 1,
			transform: "rotateY(0)"
		}], {
			duration: i * .45,
			delay: i * .55,
			fill: "both"
		});
		return () => {
			e?.cancel(), t?.cancel();
		};
	}, [i]), /* @__PURE__ */ m("span", {
		className: "gwt-changing-card",
		children: [/* @__PURE__ */ p("span", {
			ref: a,
			children: /* @__PURE__ */ p(Q, { id: e })
		}), t && /* @__PURE__ */ p("span", {
			ref: o,
			children: /* @__PURE__ */ p(Q, { id: t })
		})]
	});
}
function Ht({ points: e, ms: t, color: i }) {
	let a = r(null);
	return n(() => {
		let n = e[0], r = a.current?.animate(e.map((t, r) => ({
			transform: `translate(${t.x - n.x}px,${t.y - n.y}px)`,
			offset: r / (e.length - 1)
		})), {
			duration: t,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => r?.cancel();
	}, [e, t]), /* @__PURE__ */ p("div", {
		ref: a,
		style: {
			position: "absolute",
			left: e[0].x,
			top: e[0].y,
			color: i
		},
		children: /* @__PURE__ */ p(Z, {
			kind: "train",
			size: 24
		})
	});
}
function Ut({ at: e, card: t }) {
	let i = r(null), a = Y();
	return n(() => {
		let e = i.current?.animate([
			{
				transform: "rotateY(90deg) scale(.7)",
				opacity: 0
			},
			{
				transform: "rotateY(0) scale(1)",
				opacity: 1,
				offset: .4
			},
			{
				transform: "rotateY(0) scale(1)",
				opacity: 1
			}
		], {
			duration: R.sam,
			fill: "both"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ m("div", {
		ref: i,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: 125,
			minHeight: 90,
			background: "#e8d4a9",
			border: "3px solid #795a37",
			borderRadius: 5,
			padding: 8,
			display: "grid",
			placeItems: "center",
			color: "#493d2a",
			font: "bold 14px Georgia"
		},
		children: [
			"SAM ",
			t,
			/* @__PURE__ */ p("span", { children: X(a.samAction, P[t - 1].action) })
		]
	});
}
var Wt = { gwtAction(e, t) {
	let n = e.data, r = e.secret, i = (e) => {
		let n = t.anchor(e);
		return n && n.w > 0 && n.h > 0 ? n : void 0;
	}, a = i(`seat:${e.rid}`);
	if (!a) return null;
	let o = n.kind === "simmental" ? R.upgrade : e.rid === "$sam" ? R.sam : n.fromNode === n.toNode ? R.card : R.move, s = e.rid === "$sam" ? "#604b34" : l[(t.member(e.rid || "")?.colorIndex || 0) % l.length].hex, c = i(`discard:${e.rid}`) || a, u = [], d = [];
	if (n.fromNode !== n.toNode) {
		let r = [n.fromNode, ...n.path].map((e) => t.anchor(`node:${e}`)), i = t.anchor(`herder:${e.rid}`);
		if (i && r.every((e) => e && e.w > 0)) {
			let n = r.at(-1), a = r.map((e) => ({
				...i,
				x: i.x + e.x - n.x,
				y: i.y + e.y - n.y
			}));
			u.push(/* @__PURE__ */ p(zt, {
				points: a,
				ms: o,
				color: s
			}, "herder")), t.queued || d.push(`herder:${e.rid}`);
		}
	}
	let f = (e, n, r, a, s, c = [110, 156], l = 0) => {
		let f = Math.min(1, r.w / c[0], r.h / c[1]), m = c[0] * f, h = c[1] * f, _ = {
			x: r.x + (r.w - m) / 2,
			y: r.y + (r.h - h) / 2,
			w: m,
			h
		};
		u.push(/* @__PURE__ */ p(g, {
			from: n,
			to: _,
			ms: o - l,
			delay: l,
			children: a
		}, e)), s && !t.queued && i(s) && d.push(s);
	};
	if (n.kind === "buy" && n.cards.forEach((e) => f(`buy:${e}`, i(`market:${e}`) || a, c, n.faceDown ? /* @__PURE__ */ p(Bt, {}) : /* @__PURE__ */ p(Q, { id: e }))), ["discard", "income"].includes(n.kind) && n.cards.forEach((e) => f(`discard:${e}`, i(`hand:${e}`) || a, c, /* @__PURE__ */ p(Q, { id: e }))), n.kind === "playObjective" && n.cards.forEach((t) => f(`played:${t}`, i(`hand:${t}`) || a, i(`played:${e.rid}`) || a, /* @__PURE__ */ p(Q, { id: t }))), n.kind === "thin" && n.cards.forEach((e) => {
		let t = i(`hand:${e}`) || a;
		f(`remove:${e}`, t, {
			...t,
			y: t.y - 80
		}, /* @__PURE__ */ p(Vt, {
			from: e,
			ms: o
		}));
	}), n.kind === "simmental" && n.cards[0] && f("upgrade", i(`hand:${n.cards[0]}`) || a, c, /* @__PURE__ */ p(Vt, {
		from: n.cards[0],
		to: n.upgraded,
		ms: 500
	}), void 0, [110, 156], 500), n.drawCount && Array.from({ length: n.drawCount }, (n, o) => {
		let s = r?.drawCards[o], c = s && t.myRid === e.rid && i(`hand:${s}`) || a;
		f(`draw:${o}`, i(`deck:${e.rid}`) || a, c, s ? /* @__PURE__ */ p(Q, { id: s }) : /* @__PURE__ */ p(Bt, {}), s ? `hand:${s}` : void 0);
	}), n.kind === "build" && n.cards[0]) {
		let e = i(`building:${n.target}`) || a;
		f("build", i(`supply:${n.cards[0]}`) || a, e, /* @__PURE__ */ p("img", {
			style: {
				width: 66,
				height: 43
			},
			src: `games/greatwesterntrail/building-${n.cards[0]}.svg`,
			alt: ""
		}), `building:${n.target}`, [66, 43]);
	}
	if (n.kind === "delivery" || n.kind === "station") {
		let t = n.kind === "delivery" ? `delivery-disc:${e.rid}:${n.discIndex}` : `station-disc:${e.rid}:${n.target}`;
		f("disc", a, i(t) || i(`${n.kind}:${n.target}`) || a, /* @__PURE__ */ p("span", {
			className: "gwt-player-disc",
			style: { background: s }
		}), t, [18, 18]);
	}
	if (n.fromTrain !== n.toTrain) {
		let r = Math.max(0, Math.floor(n.fromTrain)), c = Math.max(0, Math.floor(n.toTrain)), l = c >= r ? 1 : -1, m = Array.from({ length: Math.abs(c - r) + 1 }, (e, t) => i(`rail:${r + t * l}`)).filter((e) => !!e).map((e) => ({
			...e,
			x: e.x + e.w / 2 - 12,
			y: e.y + e.h / 2 - 12
		}));
		m.length > 1 ? (u.push(/* @__PURE__ */ p(Ht, {
			points: m,
			ms: o,
			color: s
		}, "train")), t.queued || d.push(`train:${e.rid}`)) : f("train", i(`rail:${r}`) || a, i(`train:${e.rid}`) || a, /* @__PURE__ */ p("span", {
			style: { color: s },
			children: /* @__PURE__ */ p(Z, {
				kind: "train",
				size: 24
			})
		}), `train:${e.rid}`, [24, 24]);
	}
	return n.kind === "hire" && f("hire", i(`job:${n.hired}`) || a, a, /* @__PURE__ */ p(Z, {
		kind: n.target,
		size: 25
	}), void 0, [25, 25]), ["hazard", "bounty"].includes(n.kind) && n.takenTile && f("tile", i(`node:${n.target}`) || a, a, /* @__PURE__ */ p(wt, { tile: n.takenTile }), void 0, [42, 38]), n.tiles.forEach(({ to: e, from: t, tile: n }) => f(n.id, i(t) || a, i(e) || a, /* @__PURE__ */ p(wt, { tile: n }), e.startsWith("node:") ? e.replace("node:", "place:") : e, [42, 38])), n.marketAdded.forEach((e) => f(`market-add:${e}`, i("market-deck") || a, i(`market:${e}`) || a, /* @__PURE__ */ p(Q, { id: e }), `market:${e}`)), n.objectivesAdded.forEach((e) => f(`objective-add:${e}`, i("objective-deck") || a, i(`objective:${e}`) || a, /* @__PURE__ */ p(Q, { id: e }), `objective:${e}`)), n.gainedObjectives.forEach((e, t) => {
		let o = e || (n.faceDown ? "" : r?.drawCards[t]) || "", s = o && r?.drawCards.includes(o) ? i(`hand:${o}`) : void 0;
		f(`objective-gain:${t}`, i(`objective:${o}`) || i("objective-deck") || a, s || c, o ? /* @__PURE__ */ p(Q, { id: o }) : /* @__PURE__ */ p(Bt, {}), s ? `hand:${o}` : void 0);
	}), n.samCard && u.push(/* @__PURE__ */ p(Ut, {
		at: a,
		card: n.samCard
	}, "sam")), n.masters.forEach((e) => f(`master:${e}`, i(`station:${n.masterFrom}`) || a, a, /* @__PURE__ */ p(Z, {
		kind: "station",
		size: 30
	}), void 0, [30, 30])), n.exchange && u.push(/* @__PURE__ */ p(h, {
		at: {
			...a,
			y: a.y + 45
		},
		ms: o,
		children: /* @__PURE__ */ m("span", {
			className: "gwt-button",
			children: [
				/* @__PURE__ */ p(Z, { kind: "exchange" }),
				n.exchange > 0 ? "+" : "",
				n.exchange
			]
		})
	}, "exchange")), u.length || u.push(/* @__PURE__ */ p(_, {
		at: t.anchor(`node:${n.target}`) || a,
		ms: o
	}, "pulse")), n.money && u.push(/* @__PURE__ */ p(h, {
		at: a,
		ms: o,
		children: /* @__PURE__ */ m("span", {
			className: "gwt-button",
			children: [
				n.money > 0 ? "+" : "",
				"$",
				n.money
			]
		})
	}, "amount")), n.certificates && u.push(/* @__PURE__ */ p(h, {
		at: {
			...a,
			y: a.y + 25
		},
		ms: o,
		children: /* @__PURE__ */ m("span", {
			className: "gwt-button",
			children: [
				/* @__PURE__ */ p(Z, { kind: "cert" }),
				n.certificates > 0 ? "+" : "",
				n.certificates
			]
		})
	}, "cert")), {
		ms: o,
		node: /* @__PURE__ */ p("div", {
			style: { display: "contents" },
			"data-gwt-fx-kind": n.kind,
			"data-gwt-fx-count": u.length,
			children: u
		}),
		hide: d
	};
} };
//#endregion
//#region src/games/greatwesterntrail/game-over.tsx
function Gt(e) {
	let [t, n] = i(!1), r = Y(), a = d((e) => e.locale), o = e.public, s = (t) => t === "$sam" ? r.sam : e.members.find((e) => e.rid === t) ? u(e.members.find((e) => e.rid === t), a) : t, c = [...o.scores].sort((e, t) => t.total - e.total);
	return /* @__PURE__ */ m("div", {
		className: `gwt-over-stage ${t ? "is-review" : ""}`,
		children: [
			/* @__PURE__ */ p("div", {
				className: `gwt-ending-board ${t ? "" : "is-covered"}`,
				inert: !t,
				children: /* @__PURE__ */ p(Nt, {
					public: o,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {}
				})
			}),
			t && /* @__PURE__ */ p("button", {
				className: "gwt-button gwt-primary gwt-over-review",
				onClick: () => n(!1),
				children: r.returnResult
			}),
			/* @__PURE__ */ p("div", {
				className: `gwt-ending-dialog ${t ? "is-hidden" : ""}`,
				inert: t,
				children: /* @__PURE__ */ m("div", {
					className: "gwt-over",
					children: [
						/* @__PURE__ */ m("header", {
							className: "gwt-over-title",
							children: [/* @__PURE__ */ p("h1", { children: r.result }), /* @__PURE__ */ m("p", { children: [
								r.winner,
								" · ",
								e.result.winner.map(s).join(" · ")
							] })]
						}),
						/* @__PURE__ */ m("div", {
							className: "gwt-over-scroll",
							children: [/* @__PURE__ */ m("table", {
								className: "gwt-score-table",
								children: [
									/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: r.details }), c.map((e) => /* @__PURE__ */ p("th", { children: s(e.rid) }, e.rid))] }) }),
									/* @__PURE__ */ p("tbody", { children: Array.from({ length: 11 }, (e, t) => /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: X(r.category, String(t)) }), c.map((e) => /* @__PURE__ */ p("td", { children: e.categories[t] }, e.rid))] }, t)) }),
									/* @__PURE__ */ p("tfoot", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: r.total }), c.map((e) => /* @__PURE__ */ p("td", { children: e.total }, e.rid))] }) })
								]
							}), c.map((e) => /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ m("summary", { children: [
								s(e.rid),
								" · ",
								r.objectives
							] }), e.objectives.map((e) => /* @__PURE__ */ m("p", { children: [
								xt(e.card, r),
								" · ",
								e.success ? r.objectiveSuccess : r.objectiveFail,
								" · ",
								e.points,
								" ",
								r.vp
							] }, e.card))] }, e.rid))]
						}),
						/* @__PURE__ */ m("footer", {
							className: "gwt-over-controls",
							children: [
								/* @__PURE__ */ p("button", {
									className: "gwt-button",
									onClick: () => n(!0),
									children: r.review
								}),
								e.onPlayAgain && /* @__PURE__ */ p("button", {
									className: "gwt-button gwt-primary",
									onClick: e.onPlayAgain,
									children: r.again
								}),
								e.onBackToLobby && /* @__PURE__ */ p("button", {
									className: "gwt-button",
									onClick: e.onBackToLobby,
									children: r.lobby
								}),
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ p("span", { children: r.waitingHost })
							]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/greatwesterntrail/options.tsx
function Kt({ value: e, onChange: t }) {
	let n = Y(), r = F.safeParse(e), i = r.success ? r.data : F.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "gwt-options",
		children: [
			/* @__PURE__ */ p(y, {
				title: n.options.buildings,
				columns: 3,
				children: [
					"a",
					"b",
					"mixed"
				].map((e) => /* @__PURE__ */ p(v, {
					name: "gwt-buildings",
					value: e,
					checked: i.buildings === e,
					label: n.options[e],
					accent: te.accent,
					onChange: () => t({
						...i,
						buildings: e
					})
				}, e))
			}),
			/* @__PURE__ */ p(ee, {
				checked: i.randomNeutral,
				label: n.options.neutral,
				hint: i.randomNeutral ? n.options.random : n.options.fixed,
				onChange: () => t({
					...i,
					randomNeutral: !i.randomNeutral
				})
			}),
			/* @__PURE__ */ p(ee, {
				checked: i.simmental,
				label: n.options.simmental,
				onChange: () => t({
					...i,
					simmental: !i.simmental
				})
			}),
			/* @__PURE__ */ p(y, {
				title: n.options.difficulty,
				columns: 3,
				children: [
					"easy",
					"medium",
					"hard"
				].map((e) => /* @__PURE__ */ p(v, {
					name: "gwt-sam",
					value: e,
					checked: i.soloDifficulty === e,
					label: n.options[e],
					accent: te.accent,
					onChange: () => t({
						...i,
						soloDifficulty: e
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region src/games/greatwesterntrail/guide.tsx
function qt() {
	let e = Y();
	return /* @__PURE__ */ p("div", {
		className: "gwt-guide",
		style: {
			height: "auto",
			overflow: "visible"
		},
		children: /* @__PURE__ */ p("div", {
			className: "gwt-guide-icons",
			children: [
				"cowboy",
				"builder",
				"engineer",
				"building",
				"station",
				"hazard",
				"orange",
				"green",
				"cow3",
				"cow4",
				"cow5",
				"ny"
			].map((t) => /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p(Z, {
				kind: t,
				size: 32
			}), X(e.resource, t)] }, t))
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/greatwesterntrail/entry.tsx
var Jt = {
	definition: pt,
	View: Nt,
	bot: Rt,
	fx: Wt,
	OverView: Gt,
	Options: Kt,
	Guide: qt,
	locales: {
		zh: mt,
		en: ht
	}
};
//#endregion
export { Jt as default };
