import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useEffect as r, useLayoutEffect as i, useRef as a, useState as o } from "react";
import { botAvatarOf as s } from "@bgparty/sdk/lobby";
import { BottomSheet as c } from "@bgparty/sdk/bottom-sheet";
import { AVATARS as l } from "@bgparty/sdk/avatars";
import { useFxAnchor as u } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as d, useI18nSettings as f, useT as p } from "@bgparty/sdk/i18n";
import { IconLog as m } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as h } from "@bgparty/sdk/player-colors";
import { playSettle as g, playTurn as _, useSoundEdge as v } from "@bgparty/sdk/sfx";
import { GameScreen as y } from "@bgparty/sdk/ui/game-screen";
import { Fragment as b, jsx as x, jsxs as S } from "react/jsx-runtime";
import { botPersonality as C } from "@bgparty/sdk/bot-personality";
import { Flash as ee, Floater as w, FlySprite as T, PulseBox as E } from "@bgparty/sdk/fx/primitives";
import { Confetti as te } from "@bgparty/sdk/ui/confetti";
//#region src/games/dmd/cards.ts
var D = [
	"anchor",
	"cannon",
	"chest",
	"hook",
	"key",
	"kraken",
	"map",
	"mermaid",
	"oracle",
	"sword"
], O = {
	anchor: "⚓",
	cannon: "💣",
	chest: "💰",
	hook: "🪝",
	key: "🗝️",
	kraken: "🐙",
	map: "🗺️",
	mermaid: "🧜",
	oracle: "🔮",
	sword: "🗡️"
}, k = {
	anchor: "games.dmd.suitAnchor",
	cannon: "games.dmd.suitCannon",
	chest: "games.dmd.suitChest",
	hook: "games.dmd.suitHook",
	key: "games.dmd.suitKey",
	kraken: "games.dmd.suitKraken",
	map: "games.dmd.suitMap",
	mermaid: "games.dmd.suitMermaid",
	oracle: "games.dmd.suitOracle",
	sword: "games.dmd.suitSword"
}, A = {
	anchor: "#617d8a",
	cannon: "#b75336",
	chest: "#d39745",
	hook: "#7d6299",
	key: "#b98b42",
	kraken: "#a45f83",
	map: "#648666",
	mermaid: "#319b9a",
	oracle: "#7b8bc3",
	sword: "#637798"
}, ne = {
	anchor: "games.dmd.suitDesc.anchor",
	cannon: "games.dmd.suitDesc.cannon",
	chest: "games.dmd.suitDesc.chest",
	hook: "games.dmd.suitDesc.hook",
	key: "games.dmd.suitDesc.key",
	kraken: "games.dmd.suitDesc.kraken",
	map: "games.dmd.suitDesc.map",
	mermaid: "games.dmd.suitDesc.mermaid",
	oracle: "games.dmd.suitDesc.oracle",
	sword: "games.dmd.suitDesc.sword"
};
function re() {
	let e = [];
	for (let t of D) {
		let n = t === "mermaid" ? 4 : 2, r = t === "mermaid" ? 9 : 7;
		for (let i = n; i <= r; i += 1) e.push({
			suit: t,
			value: i
		});
	}
	return e;
}
var j = {
	anchor: 2,
	cannon: 2,
	chest: 2,
	hook: 2,
	key: 2,
	kraken: 2,
	map: 2,
	mermaid: 4,
	oracle: 2,
	sword: 2
}, ie = [
	"goldenScales",
	"casanova",
	"plunderer",
	"treasureHunter",
	"navigator",
	"masterGunner",
	"scavenger",
	"mystic",
	"swordsman",
	"miser",
	"captainHook",
	"safeHarbor",
	"fisherman",
	"beastmaster",
	"misfire",
	"parry",
	"jonesLocker"
], ae = {
	goldenScales: "games.dmd.traitGoldenScales",
	casanova: "games.dmd.traitCasanova",
	plunderer: "games.dmd.traitPlunderer",
	treasureHunter: "games.dmd.traitTreasureHunter",
	navigator: "games.dmd.traitNavigator",
	masterGunner: "games.dmd.traitMasterGunner",
	scavenger: "games.dmd.traitScavenger",
	mystic: "games.dmd.traitMystic",
	swordsman: "games.dmd.traitSwordsman",
	miser: "games.dmd.traitMiser",
	captainHook: "games.dmd.traitCaptainHook",
	safeHarbor: "games.dmd.traitSafeHarbor",
	fisherman: "games.dmd.traitFisherman",
	beastmaster: "games.dmd.traitBeastmaster",
	misfire: "games.dmd.traitMisfire",
	parry: "games.dmd.traitParry",
	jonesLocker: "games.dmd.traitJonesLocker"
}, oe = {
	goldenScales: "games.dmd.traitGoldenScalesDesc",
	casanova: "games.dmd.traitCasanovaDesc",
	plunderer: "games.dmd.traitPlundererDesc",
	treasureHunter: "games.dmd.traitTreasureHunterDesc",
	navigator: "games.dmd.traitNavigatorDesc",
	masterGunner: "games.dmd.traitMasterGunnerDesc",
	scavenger: "games.dmd.traitScavengerDesc",
	mystic: "games.dmd.traitMysticDesc",
	swordsman: "games.dmd.traitSwordsmanDesc",
	miser: "games.dmd.traitMiserDesc",
	captainHook: "games.dmd.traitCaptainHookDesc",
	safeHarbor: "games.dmd.traitSafeHarborDesc",
	fisherman: "games.dmd.traitFishermanDesc",
	beastmaster: "games.dmd.traitBeastmasterDesc",
	misfire: "games.dmd.traitMisfireDesc",
	parry: "games.dmd.traitParryDesc",
	jonesLocker: "games.dmd.traitJonesLockerDesc"
}, M = {
	id: "dmd",
	tier: "released",
	mechanics: ["push-your-luck"],
	interactionTags: [],
	nameKey: "games.dmd.name",
	descKey: "games.dmd.desc",
	rulesKey: "games.dmd.rules",
	icon: "🏴‍☠️",
	iconImg: "games/dmd.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/dmd/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#0d6875",
	releasedAt: "2026-09-15",
	search: {
		py: "wang zhe shen chou",
		init: "wzsc"
	},
	hotseat: "cover"
}, N = t.enum(D), P = t.enum(ie), F = t.object({
	suit: N,
	value: t.int().min(2).max(9)
}), se = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("pickTrait"),
		trait: P
	}),
	t.object({
		type: t.literal("pickJones"),
		target: t.string()
	}),
	t.object({ type: t.literal("draw") }),
	t.object({ type: t.literal("collect") }),
	t.object({
		type: t.literal("cannon"),
		target: t.string(),
		suit: N
	}),
	t.object({
		type: t.literal("hook"),
		suit: N
	}),
	t.object({
		type: t.literal("sword"),
		target: t.string(),
		suit: N
	}),
	t.object({
		type: t.literal("mapPick"),
		index: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("plunder"),
		target: t.string()
	})
]), I = t.string(), ce = t.object({
	card: F,
	safe: t.boolean()
}), L = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("cannon"),
		self: t.boolean()
	}),
	t.object({ kind: t.literal("hook") }),
	t.object({ kind: t.literal("sword") }),
	t.object({
		kind: t.literal("map"),
		options: t.array(F)
	}),
	t.object({ kind: t.literal("navMap") }),
	t.object({ kind: t.literal("oracle") }),
	t.object({
		kind: t.literal("plunder"),
		count: t.int().positive()
	})
]), R = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("draw"),
		card: F
	}),
	t.object({
		kind: t.literal("bust"),
		card: F,
		kept: t.int().nonnegative(),
		jones: I.nullable()
	}),
	t.object({
		kind: t.literal("collect"),
		count: t.int().nonnegative(),
		bonus: t.int().nonnegative()
	}),
	t.object({
		kind: t.literal("cannon"),
		target: I,
		suit: N,
		count: t.int().positive(),
		taken: t.boolean()
	}),
	t.object({
		kind: t.literal("steal"),
		from: I,
		card: F
	}),
	t.object({
		kind: t.literal("hooked"),
		card: F
	}),
	t.object({
		kind: t.literal("mapped"),
		card: F
	}),
	t.object({
		kind: t.literal("plundered"),
		from: I,
		count: t.int().nonnegative()
	}),
	t.object({
		kind: t.literal("fizzle"),
		suit: N
	}),
	t.object({ kind: t.literal("turnStart") })
]), le = t.object({
	rid: I,
	ev: R
}), ue = t.object({
	phase: t.enum([
		"traits",
		"jones",
		"turn",
		"done"
	]),
	players: t.array(I),
	current: I,
	deckCount: t.int().nonnegative(),
	discard: t.array(F),
	river: t.array(ce),
	banks: t.record(I, t.record(t.string(), t.array(t.int()))),
	krakenLeft: t.int().nonnegative(),
	busting: N.nullable(),
	staged: t.boolean(),
	pending: L.nullable(),
	traits: t.record(I, P.nullable()),
	traitPicked: t.array(I),
	jonesTarget: I.nullable(),
	scores: t.record(I, t.int()),
	last: R.nullable(),
	log: t.array(le)
}), de = t.object({
	myOffers: t.array(P).nullable(),
	myPicked: P.nullable(),
	oraclePeek: t.array(F).nullable()
}), z = {
	draw: 850,
	kraken: 1400,
	ability: 600,
	direct: 600,
	bustHold: 1300
}, B = (e) => e.players[e.current], V = (e, t, n) => e.traits[t] === n, H = (e, t, n) => e.players.some((r) => r !== t && e.traits[r] === n), fe = 60;
function U(e, t, n) {
	e.last = n, e.log.push({
		rid: t,
		ev: n
	}), e.log.length > fe && e.log.splice(0, e.log.length - fe);
}
function W(e, t, n) {
	let r = e.banks[t], i = r[n.suit] ??= [], a = 0;
	for (; a < i.length && i[a] > n.value;) a += 1;
	i.splice(a, 0, n.value);
}
function G(e) {
	return Object.values(e).reduce((e, t) => e + (t?.length ?? 0), 0);
}
function pe(t, n, r) {
	let i = [];
	for (let a = 0; a < r && t.discard.length > 0; a += 1) {
		let r = e(t.seed, t.rngCursor, t.discard.length);
		t.rngCursor += 1;
		let [a] = t.discard.splice(r, 1);
		W(t, n, a), i.push(a);
	}
	return i;
}
function me(t, n, r) {
	let i = 0, a = re(), o = [], s = a.filter((e) => e.value !== j[e.suit] || (o.push(e), !1));
	for (let t = s.length - 1; t > 0; --t) {
		let n = e(r, i, t + 1);
		i += 1, [s[t], s[n]] = [s[n], s[t]];
	}
	let c = [...ie];
	for (let t = c.length - 1; t > 0; --t) {
		let n = e(r, i, t + 1);
		i += 1, [c[t], c[n]] = [c[n], c[t]];
	}
	let l = {};
	return n.forEach((e, t) => {
		l[e] = [c[t * 2], c[t * 2 + 1]];
	}), {
		state: {
			players: n,
			phase: "traits",
			traitOffers: l,
			traits: Object.fromEntries(n.map((e) => [e, null])),
			jonesTarget: null,
			current: e(r, i, n.length),
			deck: s,
			discard: o,
			banks: Object.fromEntries(n.map((e) => [e, {}])),
			river: [],
			staged: null,
			busting: null,
			krakenLeft: 0,
			hookQueue: 0,
			safeHarborLeft: 0,
			pending: null,
			last: null,
			log: [],
			seed: r,
			rngCursor: i + 1
		},
		fx: [{ kind: "gameStart" }]
	};
}
function he(e) {
	return e.jonesTarget === B(e) ? e.players.find((t) => e.traits[t] === "jonesLocker") ?? null : null;
}
function ge(e, t, n) {
	let r = B(e);
	e.busting = n.suit, U(e, r, {
		kind: "bust",
		card: n,
		kept: e.river.filter((e) => e.safe).length,
		jones: he(e)
	}), t.push({
		kind: "bust",
		rid: r
	});
}
function _e(e, t) {
	let n = B(e), r = e.river.map((e) => ({
		card: e.card,
		safe: e.safe
	})), i = he(e);
	for (let t of e.river) t.safe ? W(e, n, t.card) : i ? W(e, i, t.card) : e.discard.push(t.card);
	e.river = [], e.busting = null, t.push({
		kind: "bustSweep",
		rid: n,
		data: {
			river: r,
			jones: i
		}
	}), K(e);
}
function K(e) {
	e.krakenLeft = 0, e.hookQueue = 0, e.safeHarborLeft = 0, e.pending = null, e.deck.length === 0 ? e.phase = "done" : e.current = (e.current + 1) % e.players.length;
}
function ve(e, t, n) {
	let r = [];
	for (let i of e.players) if (!(n ? i !== t : i === t)) for (let [t, n] of Object.entries(e.banks[i])) n && n.length > 0 && r.push({
		target: i,
		suit: t
	});
	return r;
}
function ye(e, t) {
	let n = H(e, t, "parry"), r = V(e, t, "swordsman"), i = [];
	for (let a of e.players) if (a !== t) for (let [o, s] of Object.entries(e.banks[a])) s && s.length !== 0 && (n && o !== "kraken" || (r || !e.banks[t][o]?.length) && i.push({
		target: a,
		suit: o
	}));
	return i;
}
function be(t, n, r) {
	let i = B(t), a = t.river[n].card, o = () => {
		U(t, i, {
			kind: "fizzle",
			suit: a.suit
		});
	};
	switch (a.suit) {
		case "anchor":
			for (let e = 0; e < n; e += 1) t.river[e].safe = !0;
			V(t, i, "safeHarbor") && (t.river[n].safe = !0, t.safeHarborLeft = 2);
			break;
		case "cannon": {
			let e = H(t, i, "misfire");
			ve(t, i, e).length === 0 ? o() : t.pending = {
				kind: "cannon",
				self: e
			};
			break;
		}
		case "hook":
			G(t.banks[i]) === 0 ? o() : (V(t, i, "miser") && (t.river[n].safe = !0), V(t, i, "captainHook") && (t.hookQueue = 1), t.pending = { kind: "hook" });
			break;
		case "sword":
			ye(t, i).length === 0 ? (H(t, i, "parry") && (t.river.splice(n, 1), t.discard.push(a)), o()) : t.pending = { kind: "sword" };
			break;
		case "map":
			if (t.discard.length === 0) o();
			else if (V(t, i, "navigator")) t.pending = { kind: "navMap" };
			else {
				let n = Math.min(3, t.discard.length), r = [];
				for (; r.length < n;) {
					let n = e(t.seed, t.rngCursor, t.discard.length);
					t.rngCursor += 1, r.includes(n) || r.push(n);
				}
				t.pending = {
					kind: "map",
					options: r.map((e) => t.discard[e])
				};
			}
			break;
		case "oracle":
			t.deck.length === 0 ? o() : t.pending = { kind: "oracle" };
			break;
		case "kraken": t.krakenLeft += H(t, i, "beastmaster") ? 4 : 2;
	}
}
function xe(e) {
	e.staged || e.busting || (e.pending === null && e.hookQueue > 0 && (G(e.banks[B(e)]) > 0 ? (--e.hookQueue, e.pending = { kind: "hook" }) : e.hookQueue = 0), e.deck.length === 0 && (e.krakenLeft = 0), e.pending === null && e.deck.length === 0 && e.river.length === 0 && K(e));
}
function Se(e, t) {
	let n = e.staged;
	if (!n) return;
	e.staged = null;
	let r = B(e);
	if (U(e, r, n.note), n.direct) {
		W(e, r, n.card), xe(e);
		return;
	}
	let i = n.forceSafe || e.safeHarborLeft > 0;
	if (e.safeHarborLeft > 0 && --e.safeHarborLeft, e.krakenLeft > 0 && --e.krakenLeft, e.river.push({
		card: n.card,
		safe: i
	}), e.river.some((e) => e.card !== n.card && e.card.suit === n.card.suit)) {
		ge(e, t, n.card);
		return;
	}
	be(e, e.river.length - 1, t), xe(e);
}
function Ce(e, t) {
	let n = B(e), r = e.river.map((e) => e.card);
	for (let t of r) W(e, n, t);
	e.river = [];
	let i = new Set(r.map((e) => e.suit)), a = 0;
	if (i.has("key") && i.has("chest") && (a = r.length * (V(e, n, "treasureHunter") ? 2 : 1)), U(e, n, {
		kind: "collect",
		count: r.length,
		bonus: a
	}), t.push({
		kind: "bank",
		rid: n,
		data: {
			count: r.length,
			bonus: a
		}
	}), a > 0) {
		let t = V(e, n, "plunderer"), r = e.players.filter((t) => t !== n && G(e.banks[t]) > 0);
		if (t) {
			if (r.length > 0) {
				e.pending = {
					kind: "plunder",
					count: a
				};
				return;
			}
		} else pe(e, n, a);
	}
	K(e);
}
function we(t, n, r) {
	let i = structuredClone(t), a = [];
	if (n.type === "tick") return i.staged ? (Se(i, a), {
		state: i,
		fx: a
	}) : i.busting ? (_e(i, a), {
		state: i,
		fx: a
	}) : {
		state: t,
		fx: []
	};
	if (n.type === "pickTrait") return i.phase !== "traits" || !(r.by in i.traitOffers) || i.traits[r.by] !== null ? {
		state: t,
		fx: []
	} : i.traitOffers[r.by].includes(n.trait) ? (i.traits[r.by] = n.trait, i.players.every((e) => i.traits[e] !== null) && (i.phase = i.players.some((e) => i.traits[e] === "jonesLocker") ? "jones" : "turn", i.last = { kind: "turnStart" }, a.push({ kind: "traitReveal" })), {
		state: i,
		fx: a
	}) : { code: "games.dmd.errBadTarget" };
	if (n.type === "pickJones") return i.phase !== "jones" || i.traits[r.by] !== "jonesLocker" ? {
		state: t,
		fx: []
	} : !i.players.includes(n.target) || n.target === r.by ? { code: "games.dmd.errBadTarget" } : (i.jonesTarget = n.target, i.phase = "turn", {
		state: i,
		fx: a
	});
	if (i.phase !== "turn" || r.by !== B(i) || i.staged || i.busting) return {
		state: t,
		fx: []
	};
	switch (n.type) {
		case "draw": {
			if (i.pending !== null && i.pending.kind !== "oracle") return {
				state: t,
				fx: []
			};
			if (i.deck.length === 0) return { code: "games.dmd.errDeckEmpty" };
			i.pending = null;
			let e = i.deck.pop(), n = e.suit === "kraken" && V(i, r.by, "fisherman") || e.suit === "mermaid" && V(i, r.by, "casanova");
			return i.staged = {
				card: e,
				forceSafe: !1,
				direct: n,
				ms: e.suit === "kraken" && !n ? z.kraken : n ? z.direct : z.draw,
				note: {
					kind: "draw",
					card: e
				}
			}, a.push({
				kind: n ? "directBank" : "toRiver",
				rid: r.by,
				data: { card: e }
			}), {
				state: i,
				fx: a
			};
		}
		case "collect": return i.pending !== null && i.pending.kind !== "oracle" ? {
			state: t,
			fx: []
		} : i.river.length === 0 ? { code: "games.dmd.errBadPhase" } : i.krakenLeft > 0 ? { code: "games.dmd.errKraken" } : (i.pending = null, Ce(i, a), {
			state: i,
			fx: a
		});
		case "cannon": {
			if (i.pending?.kind !== "cannon") return {
				state: t,
				fx: []
			};
			if (i.pending.self ? n.target !== r.by : n.target === r.by) return { code: "games.dmd.errBadTarget" };
			let e = i.banks[n.target][n.suit];
			if (!e || e.length === 0) return { code: "games.dmd.errBadTarget" };
			i.pending = null;
			let o = V(i, r.by, "masterGunner") ? e.length : 1, s = e.splice(0, o);
			e.length === 0 && delete i.banks[n.target][n.suit];
			let c = V(i, r.by, "scavenger");
			for (let e of s) c ? W(i, r.by, {
				suit: n.suit,
				value: e
			}) : i.discard.push({
				suit: n.suit,
				value: e
			});
			return U(i, r.by, {
				kind: "cannon",
				target: n.target,
				suit: n.suit,
				count: o,
				taken: c
			}), a.push({
				kind: "cannon",
				rid: r.by,
				data: {
					target: n.target,
					suit: n.suit,
					count: o,
					taken: c
				}
			}), xe(i), {
				state: i,
				fx: a
			};
		}
		case "hook": {
			if (i.pending?.kind !== "hook") return {
				state: t,
				fx: []
			};
			let e = i.banks[r.by][n.suit];
			if (!e || e.length === 0) return { code: "games.dmd.errBadTarget" };
			i.pending = null;
			let o = e.shift();
			e.length === 0 && delete i.banks[r.by][n.suit];
			let s = {
				suit: n.suit,
				value: o
			};
			return i.staged = {
				card: s,
				forceSafe: V(i, r.by, "miser"),
				direct: !1,
				ms: z.ability,
				note: {
					kind: "hooked",
					card: s
				}
			}, a.push({
				kind: "hooked",
				rid: r.by,
				data: { card: s }
			}), {
				state: i,
				fx: a
			};
		}
		case "sword": {
			if (i.pending?.kind !== "sword") return {
				state: t,
				fx: []
			};
			if (!ye(i, r.by).some((e) => e.target === n.target && e.suit === n.suit)) return { code: "games.dmd.errBadTarget" };
			i.pending = null;
			let e = i.banks[n.target][n.suit], o = e.shift();
			e.length === 0 && delete i.banks[n.target][n.suit];
			let s = {
				suit: n.suit,
				value: o
			};
			return i.staged = {
				card: s,
				forceSafe: !1,
				direct: !1,
				ms: z.ability,
				note: {
					kind: "steal",
					from: n.target,
					card: s
				}
			}, a.push({
				kind: "steal",
				rid: r.by,
				data: {
					from: n.target,
					card: s
				}
			}), {
				state: i,
				fx: a
			};
		}
		case "mapPick": {
			if (i.pending?.kind !== "map" && i.pending?.kind !== "navMap") return {
				state: t,
				fx: []
			};
			let e = i.pending, o;
			if (e.kind === "map") {
				let t = e.options[n.index];
				if (!t || (o = i.discard.findIndex((e) => e.suit === t.suit && e.value === t.value), o < 0)) return { code: "games.dmd.errBadTarget" };
			} else {
				if (n.index >= i.discard.length) return { code: "games.dmd.errBadTarget" };
				o = n.index;
			}
			i.pending = null;
			let [s] = i.discard.splice(o, 1);
			return i.staged = {
				card: s,
				forceSafe: !1,
				direct: !1,
				ms: z.ability,
				note: {
					kind: "mapped",
					card: s
				}
			}, a.push({
				kind: "mapped",
				rid: r.by,
				data: { card: s }
			}), {
				state: i,
				fx: a
			};
		}
		case "plunder": {
			if (i.pending?.kind !== "plunder") return {
				state: t,
				fx: []
			};
			if (n.target === r.by || !i.players.includes(n.target)) return { code: "games.dmd.errBadTarget" };
			let o = i.pending.count;
			i.pending = null;
			let s = [];
			for (let [e, t] of Object.entries(i.banks[n.target])) for (let n of t ?? []) s.push({
				suit: e,
				value: n
			});
			let c = 0;
			for (let t = 0; t < o && s.length > 0; t += 1) {
				let t = e(i.seed, i.rngCursor, s.length);
				i.rngCursor += 1;
				let [a] = s.splice(t, 1), o = i.banks[n.target][a.suit];
				o.splice(o.indexOf(a.value), 1), o.length === 0 && delete i.banks[n.target][a.suit], W(i, r.by, a), c += 1;
			}
			return U(i, r.by, {
				kind: "plundered",
				from: n.target,
				count: c
			}), a.push({
				kind: "plundered",
				rid: r.by,
				data: {
					from: n.target,
					count: c
				}
			}), K(i), {
				state: i,
				fx: a
			};
		}
		default: return {
			state: t,
			fx: []
		};
	}
}
function Te(e, t) {
	let n = 0, r = e.banks[t];
	for (let e of Object.values(r)) e && e.length && (n += e[0]);
	return V(e, t, "goldenScales") && r.mermaid?.length && (n += 5), n;
}
function Ee(e, t) {
	let n = e.phase !== "traits", r = e.pending?.kind === "oracle" && t === B(e) ? V(e, t, "mystic") ? 3 : 1 : 0;
	return {
		public: {
			phase: e.phase,
			players: e.players,
			current: B(e),
			deckCount: e.deck.length,
			discard: e.discard,
			river: e.river,
			banks: e.banks,
			krakenLeft: e.krakenLeft,
			busting: e.busting,
			staged: e.staged !== null,
			pending: e.pending,
			traits: Object.fromEntries(e.players.map((t) => [t, n ? e.traits[t] : null])),
			traitPicked: e.players.filter((t) => e.traits[t] !== null),
			jonesTarget: e.jonesTarget,
			scores: Object.fromEntries(e.players.map((t) => [t, Te(e, t)])),
			last: e.last,
			log: e.log
		},
		private: {
			myOffers: e.phase === "traits" ? e.traitOffers[t] ?? null : null,
			myPicked: e.traits[t] ?? null,
			oraclePeek: r > 0 ? e.deck.slice(-r).reverse() : null
		}
	};
}
function De(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => ({
		score: Te(e, t),
		cards: G(e.banks[t])
	}), n = [...e.players].sort((e, n) => {
		let r = t(e), i = t(n);
		return i.score - r.score || i.cards - r.cards;
	}), r = t(n[0]);
	return {
		phase: "done",
		winner: n.filter((e) => {
			let n = t(e);
			return n.score === r.score && n.cards === r.cards;
		}),
		ranking: n,
		scores: Object.fromEntries(e.players.map((t) => [t, Te(e, t)]))
	};
}
function Oe(e) {
	return e.staged ? e.staged.ms : e.busting ? z.bustHold : null;
}
var ke = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: M,
	schemas: {
		action: se,
		publicView: ue,
		privateView: de
	},
	setup: me,
	reduce: we,
	viewFor: Ee,
	status: De,
	nextTickIn: Oe
};
//#endregion
//#region src/games/dmd/skull-icon.tsx
function Ae({ size: e, color: t, hole: n }) {
	return /* @__PURE__ */ S("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ x("path", {
				d: "M12 2.5c-4.7 0-8 3.4-8 7.9 0 2.7 1.3 4.8 3.1 6v3.1c0 .8.7 1.5 1.5 1.5h6.8c.8 0 1.5-.7 1.5-1.5v-3.1c1.8-1.2 3.1-3.3 3.1-6 0-4.5-3.3-7.9-8-7.9Z",
				fill: t
			}),
			/* @__PURE__ */ x("ellipse", {
				cx: 8.6,
				cy: 10.4,
				rx: 2,
				ry: 2.4,
				fill: n
			}),
			/* @__PURE__ */ x("ellipse", {
				cx: 15.4,
				cy: 10.4,
				rx: 2,
				ry: 2.4,
				fill: n
			}),
			/* @__PURE__ */ x("path", {
				d: "M12 13.6l-1.1 2.2h2.2Z",
				fill: n
			}),
			/* @__PURE__ */ x("path", {
				d: "M10 18.4v2M14 18.4v2",
				stroke: n,
				strokeWidth: 1.1,
				strokeLinecap: "round"
			})
		]
	});
}
//#endregion
//#region src/games/dmd/suit-mark.tsx
function q({ suit: e, className: t = "" }) {
	let n = {
		stroke: "#15323b",
		strokeWidth: 2.5,
		strokeLinejoin: "round",
		strokeLinecap: "round"
	}, r;
	switch (e) {
		case "anchor":
			r = /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("path", {
				d: "M30 6v29M22 12h16M12 27q0 17 18 17t18-17M10 27l4-3 4 4m24 0 4-4 4 3",
				fill: "none",
				stroke: "#577482",
				strokeWidth: "5",
				strokeLinecap: "round"
			}), /* @__PURE__ */ x("circle", {
				cx: "30",
				cy: "6",
				r: "4",
				fill: "#fffaf0",
				stroke: "#577482",
				strokeWidth: "3"
			})] });
			break;
		case "cannon":
			r = /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x("path", {
					d: "M9 19 46 9l6 13-36 11Z",
					fill: "#57636a",
					...n
				}),
				/* @__PURE__ */ x("ellipse", {
					cx: "48",
					cy: "15",
					rx: "6",
					ry: "8",
					transform: "rotate(-17 48 15)",
					fill: "#243841",
					...n
				}),
				/* @__PURE__ */ x("path", {
					d: "M19 31h29l-5 8H14Z",
					fill: "#a96339",
					...n
				}),
				/* @__PURE__ */ x("circle", {
					cx: "20",
					cy: "41",
					r: "6",
					fill: "#a96339",
					...n
				}),
				/* @__PURE__ */ x("circle", {
					cx: "41",
					cy: "41",
					r: "6",
					fill: "#a96339",
					...n
				}),
				/* @__PURE__ */ x("path", {
					d: "m9 10-4-5m6 3 1-5",
					fill: "none",
					stroke: "#eead42",
					strokeWidth: "2.5",
					strokeLinecap: "round"
				})
			] });
			break;
		case "chest":
			r = /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x("path", {
					d: "M7 20V12Q30-1 53 12v8",
					fill: "#c48139",
					...n
				}),
				/* @__PURE__ */ x("path", {
					d: "M6 19h48v26H6Z",
					fill: "#a75c30",
					...n
				}),
				/* @__PURE__ */ x("path", {
					d: "M8 27h44M17 19v26m26-26v26",
					fill: "none",
					stroke: "#f2c35e",
					strokeWidth: "4"
				}),
				/* @__PURE__ */ x("rect", {
					x: "26",
					y: "19",
					width: "8",
					height: "11",
					rx: "2",
					fill: "#ffe17a",
					stroke: "#15323b",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ x("circle", {
					cx: "16",
					cy: "10",
					r: "5",
					fill: "#f7cc55",
					stroke: "#15323b",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ x("circle", {
					cx: "27",
					cy: "6",
					r: "5",
					fill: "#f7cc55",
					stroke: "#15323b",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ x("circle", {
					cx: "39",
					cy: "9",
					r: "5",
					fill: "#f7cc55",
					stroke: "#15323b",
					strokeWidth: "2"
				})
			] });
			break;
		case "hook":
			r = /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x("path", {
					d: "M31 5v25c0 10 7 15 15 10 5-3 6-9 3-13",
					fill: "none",
					stroke: "#7d6299",
					strokeWidth: "7",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ x("path", {
					d: "M24 8h14M49 27l-5 5",
					fill: "none",
					stroke: "#d4b469",
					strokeWidth: "4",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ x("circle", {
					cx: "31",
					cy: "6",
					r: "4",
					fill: "#e7d7af",
					stroke: "#15323b",
					strokeWidth: "2"
				})
			] });
			break;
		case "key":
			r = /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x("circle", {
					cx: "18",
					cy: "18",
					r: "10",
					fill: "#e8be62",
					...n
				}),
				/* @__PURE__ */ x("circle", {
					cx: "18",
					cy: "18",
					r: "3",
					fill: "#fffaf0",
					stroke: "#15323b",
					strokeWidth: "1.8"
				}),
				/* @__PURE__ */ x("path", {
					d: "m26 25 22 18 4-5-5-4 4-4-5-4-4 4-12-11",
					fill: "#e8be62",
					...n
				})
			] });
			break;
		case "kraken":
			r = /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x("path", {
					d: "M30 8c-10 0-16 8-16 19 0 8 6 14 16 14s16-6 16-14C46 16 40 8 30 8Z",
					fill: "#a45f83",
					...n
				}),
				/* @__PURE__ */ x("circle", {
					cx: "24",
					cy: "24",
					r: "2.5",
					fill: "#15323b"
				}),
				/* @__PURE__ */ x("circle", {
					cx: "36",
					cy: "24",
					r: "2.5",
					fill: "#15323b"
				}),
				/* @__PURE__ */ x("path", {
					d: "M18 37q-11-2-11 7m17-5q-7 8-14 4m23-4q6 8 14 3m-5-6q11-1 11 8",
					fill: "none",
					stroke: "#a45f83",
					strokeWidth: "5",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ x("path", {
					d: "M23 31q7 5 14 0",
					fill: "none",
					stroke: "#15323b",
					strokeWidth: "2"
				})
			] });
			break;
		case "map":
			r = /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x("path", {
					d: "M7 11 22 6l16 5 15-5v34l-15 5-16-5-15 5Z",
					fill: "#d9ce95",
					...n
				}),
				/* @__PURE__ */ x("path", {
					d: "M22 6v34m16-29v34",
					fill: "none",
					stroke: "#8d7852",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ x("path", {
					d: "M13 32q9-16 17-9t13-6",
					fill: "none",
					stroke: "#d67652",
					strokeWidth: "2.5",
					strokeDasharray: "3 3"
				}),
				/* @__PURE__ */ x("path", {
					d: "m39 14 7 8m0-8-7 8",
					fill: "none",
					stroke: "#b75336",
					strokeWidth: "3"
				})
			] });
			break;
		case "mermaid":
			r = /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x("path", {
					d: "M7 41q12-8 23-1t23 0",
					fill: "none",
					stroke: "#53a8a5",
					strokeWidth: "4",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ x("path", {
					d: "M30 36Q45 16 31 9q-3 17-14 15Q18 34 30 36Z",
					fill: "#44a09b",
					...n
				}),
				/* @__PURE__ */ x("path", {
					d: "M18 23Q7 14 5 7q13-3 23 5M31 10Q41 0 55 3q-1 15-14 20",
					fill: "#81c6bb",
					...n
				}),
				/* @__PURE__ */ x("path", {
					d: "M18 27q12 4 20-4M16 33q14 4 19-5",
					fill: "none",
					stroke: "#f4d884",
					strokeWidth: "2"
				})
			] });
			break;
		case "oracle":
			r = /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x("path", {
					d: "M7 28q23-26 46 0-23 25-46 0Z",
					fill: "#d9d7ef",
					...n
				}),
				/* @__PURE__ */ x("circle", {
					cx: "30",
					cy: "28",
					r: "10",
					fill: "#7b8bc3",
					...n
				}),
				/* @__PURE__ */ x("circle", {
					cx: "30",
					cy: "28",
					r: "4",
					fill: "#15323b"
				}),
				/* @__PURE__ */ x("path", {
					d: "M30 2v8M9 8l5 6m37-6-5 6",
					fill: "none",
					stroke: "#b1a1d4",
					strokeWidth: "3",
					strokeLinecap: "round"
				})
			] });
			break;
		case "sword": r = /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("path", {
			d: "M43 4 52 2l-2 10-26 26-7-7Z",
			fill: "#c5d7d0",
			...n
		}), /* @__PURE__ */ x("path", {
			d: "m13 27 17 17M13 38l11-11M11 39l6 5",
			fill: "none",
			stroke: "#b17c3b",
			strokeWidth: "5",
			strokeLinecap: "round"
		})] });
	}
	return /* @__PURE__ */ x("svg", {
		className: t,
		viewBox: "0 0 60 50",
		"aria-hidden": "true",
		focusable: "false",
		children: r
	});
}
function J({ className: e = "" }) {
	return /* @__PURE__ */ S("svg", {
		className: e,
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ x("circle", {
				cx: "16",
				cy: "16",
				r: "13",
				fill: "#e8c671",
				stroke: "#15323b",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ x("path", {
				d: "m16 5 4 11-4 11-4-11Z",
				fill: "#0d6875",
				stroke: "#15323b",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ x("circle", {
				cx: "16",
				cy: "16",
				r: "2.3",
				fill: "#15323b"
			})
		]
	});
}
//#endregion
//#region src/games/dmd/card.tsx
function je(e, t) {
	if (e && t) return {
		width: e,
		height: t,
		"--dmd-name-font": `${e * .145}px`,
		"--dmd-name-line": `${t * .15}px`,
		"--dmd-art-top": `${t * .19}px`,
		"--dmd-art-height": `${t * .53}px`,
		"--dmd-value-font": `${e * .42}px`,
		"--dmd-value-line": `${e * .47}px`,
		"--dmd-safe-size": `${e * .3}px`,
		"--dmd-safe-font": `${e * .19}px`
	};
}
function Y({ card: e, safe: t = !1, size: n = "md", shadow: r = "table", w: i, h: a }) {
	let o = p();
	return /* @__PURE__ */ S("div", {
		role: "img",
		"aria-label": `${o(k[e.suit])} ${e.value}`,
		className: `dmd-card dmd-card--${n} dmd-card--${r}`,
		style: {
			"--dmd-suit-color": A[e.suit],
			...je(i, a)
		},
		children: [
			/* @__PURE__ */ x("span", {
				className: "dmd-card-name",
				"aria-hidden": !0,
				children: o(k[e.suit])
			}),
			/* @__PURE__ */ x(q, {
				suit: e.suit,
				className: "dmd-card-art"
			}),
			/* @__PURE__ */ x("span", {
				className: "dmd-card-value font-display tabular-nums",
				"aria-hidden": !0,
				children: e.value
			}),
			t && /* @__PURE__ */ x("span", {
				className: "dmd-card-safe",
				"aria-label": o("games.dmd.safeCard"),
				children: "◆"
			})
		]
	});
}
function Me({ size: e = "md", shadow: t = "stack", w: n, h: r }) {
	return /* @__PURE__ */ S("span", {
		className: `dmd-card-back dmd-card--${e} dmd-card--${t}`,
		style: je(n, r),
		"aria-hidden": !0,
		children: [/* @__PURE__ */ S("svg", {
			className: "dmd-card-back-lines",
			viewBox: "0 0 40 56",
			preserveAspectRatio: "none",
			children: [/* @__PURE__ */ x("path", {
				d: "M-12 14 L52 -6 M-12 32 L52 12 M-12 50 L52 30 M-12 68 L52 48",
				fill: "none",
				stroke: "#80b9b5",
				strokeWidth: "3",
				opacity: ".42"
			}), /* @__PURE__ */ x("rect", {
				x: "3",
				y: "3",
				width: "34",
				height: "50",
				rx: "2",
				fill: "none",
				stroke: "#b8d6bb",
				strokeWidth: "1.5",
				opacity: ".8"
			})]
		}), /* @__PURE__ */ x(Ae, {
			size: n ? n * .48 : e === "sm" ? 17 : e === "lg" ? 31 : 27,
			color: "#fffaf0",
			hole: "#0d6875"
		})]
	});
}
//#endregion
//#region src/games/dmd/view-player.tsx
function Ne(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ x(Pe, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Pe({ pub: e, priv: t, members: r, myRid: c, send: g }) {
	let C = p(), ee = f((e) => e.locale), w = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? s(t.rid) === null ? t.name : d(ee, t.avatar) : e;
	}, { ref: T } = u("deck"), { ref: E } = u("discard"), { ref: te } = u("river"), { ref: D } = u("riverSlot"), { ref: O } = u("riverGeometry"), A = a(null), ne = n((e) => {
		A.current = e, te(e);
	}, [te]);
	i(() => {
		let t = A.current;
		t && (t.scrollLeft = e.river.length > 0 || e.staged ? t.scrollWidth - t.clientWidth : 0);
	}, [e.river.length, e.staged]);
	let re = e.phase === "turn" && e.current === c, j = re ? e.pending : null, ie = e.banks[c] ?? {}, M = e.traits[c], [N, P] = o(!1), F = e.log.length > 0 ? Ve(C, e.log[e.log.length - 1], w) : Ue(e, w, C), se = e.players.some((t) => t !== c && e.traits[t] === "parry"), I = M === "swordsman", ce = (t, n) => {
		if (!j) return null;
		let r = e.banks[t]?.[n];
		return !r || r.length === 0 ? null : j.kind === "hook" ? t === c ? "hook" : null : j.kind === "cannon" ? j.self ? t === c ? "cannon" : null : t === c ? null : "cannon" : j.kind === "sword" ? t === c || se && n !== "kraken" || !I && ie[n]?.length ? null : "sword" : null;
	}, L = "info", R;
	return e.phase === "traits" ? t?.myPicked ? R = C("games.dmd.pickTraitWaiting", { n: e.players.length - e.traitPicked.length }) : (L = "accent", R = C("games.dmd.pickTrait")) : e.phase === "jones" ? (L = M === "jonesLocker" ? "accent" : "info", R = M === "jonesLocker" ? C("games.dmd.jonesYou") : C("games.dmd.jonesWait", { name: w(e.players.find((t) => e.traits[t] === "jonesLocker") ?? e.current) })) : e.phase === "done" ? R = C("games.dmd.done") : e.busting ? (L = "warn", R = C("games.dmd.busting")) : e.staged ? R = C("games.dmd.cardInFlight") : re ? (L = "accent", j?.kind === "cannon" ? R = C(j.self ? "games.dmd.cannonSelfHint" : "games.dmd.cannonHint") : j?.kind === "hook" ? R = C("games.dmd.hookHint") : j?.kind === "sword" ? R = C("games.dmd.swordHint") : j?.kind === "map" ? R = C("games.dmd.mapHint") : j?.kind === "navMap" ? R = C("games.dmd.navMapHint") : j?.kind === "oracle" ? R = C("games.dmd.oracleHint") : j?.kind === "plunder" ? R = C("games.dmd.plunderHint", { n: j.count }) : e.krakenLeft > 0 ? (L = "warn", R = C("games.dmd.krakenHint")) : R = C("games.dmd.turnYou")) : R = C("games.dmd.turnOther", { name: w(e.current) }), v(L === "accent", _), /* @__PURE__ */ S("div", {
		className: "dmd-screen",
		children: [/* @__PURE__ */ x(y, {
			adaptive: !0,
			className: "dmd-adaptive",
			banner: /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ S("header", {
				className: L === "warn" ? "dmd-header dmd-header--warn" : "dmd-header",
				role: "status",
				children: [
					/* @__PURE__ */ x(J, { className: "dmd-header-compass" }),
					/* @__PURE__ */ S("div", {
						className: "dmd-header-copy",
						children: [/* @__PURE__ */ x("strong", { children: C("games.dmd.name") }), /* @__PURE__ */ x("span", {
							className: "tile-enter",
							children: R
						}, R)]
					}),
					/* @__PURE__ */ x("span", {
						className: "dmd-header-count font-mono tabular-nums",
						children: C("games.dmd.deckShort", { n: e.deckCount })
					}),
					/* @__PURE__ */ x("span", {
						className: "dmd-header-menu-plate",
						"aria-hidden": !0
					})
				]
			}), /* @__PURE__ */ x("ul", {
				className: "dmd-seats",
				"aria-label": C("games.dmd.playerSeats"),
				children: e.players.map((t) => {
					let n = r.find((e) => e.rid === t), i = e.phase === "turn" ? e.current === t : e.phase === "traits" && !e.traitPicked.includes(t), a = e.phase === "traits" && e.traitPicked.includes(t);
					return /* @__PURE__ */ S("li", {
						className: i ? "dmd-seat dmd-seat--active" : "dmd-seat",
						children: [
							/* @__PURE__ */ x("span", {
								className: "dmd-seat-avatar",
								style: { backgroundColor: h[(n?.colorIndex ?? 0) % h.length].hex },
								children: n && /* @__PURE__ */ x("img", {
									src: l[n.avatar % l.length],
									alt: "",
									draggable: !1
								})
							}),
							/* @__PURE__ */ S("span", {
								className: "dmd-seat-copy",
								children: [/* @__PURE__ */ x("strong", { children: w(t) }), /* @__PURE__ */ x("small", { children: n?.online ? C(a ? "lobby.done" : i ? "games.dmd.seatActing" : "games.dmd.seatWaiting") : C("lobby.offline") })]
							}),
							/* @__PURE__ */ x("span", {
								className: "dmd-seat-score font-mono tabular-nums",
								"aria-label": C("games.dmd.scoreAria", { n: e.scores[t] ?? 0 }),
								children: e.scores[t] ?? 0
							})
						]
					}, t);
				})
			})] }),
			actionsHeight: "dmd-actions-slot",
			actions: /* @__PURE__ */ x("div", {
				className: "dmd-actions",
				children: /* @__PURE__ */ x(Re, {
					pub: e,
					priv: t,
					myRid: c,
					nameOf: w,
					send: g
				})
			}),
			scroll: !1,
			children: /* @__PURE__ */ S("div", {
				className: "dmd-board",
				children: [
					/* @__PURE__ */ S("section", {
						className: "dmd-chart",
						"aria-label": C("games.dmd.routeTitle"),
						children: [
							/* @__PURE__ */ x("span", {
								ref: O,
								className: "dmd-river-geometry",
								"aria-hidden": !0
							}),
							/* @__PURE__ */ S("div", {
								className: "dmd-chart-heading",
								children: [/* @__PURE__ */ S("span", {
									className: "dmd-chart-heading-title",
									children: [/* @__PURE__ */ x(J, { className: "dmd-chart-compass" }), e.phase === "traits" && !t?.myPicked ? C("games.dmd.traitStageTitle") : C("games.dmd.routeTitle")]
								}), /* @__PURE__ */ x("span", { children: e.river.length > 0 ? C("games.dmd.routeRisk", {
									n: e.river.length,
									points: e.river.reduce((e, t) => e + t.card.value, 0)
								}) : C("games.dmd.routeEmptyShort") })]
							}),
							e.phase === "traits" && !t?.myPicked && t?.myOffers ? /* @__PURE__ */ x("ul", {
								className: "dmd-trait-offers",
								children: t.myOffers.map((e) => /* @__PURE__ */ x("li", { children: /* @__PURE__ */ S("button", {
									type: "button",
									onClick: () => g({
										type: "pickTrait",
										trait: e
									}),
									className: "dmd-trait-card",
									children: [
										/* @__PURE__ */ x("span", {
											className: "dmd-trait-seal",
											children: /* @__PURE__ */ x(J, {})
										}),
										/* @__PURE__ */ x("strong", { children: C(ae[e]) }),
										/* @__PURE__ */ x("span", { children: C(oe[e]) }),
										/* @__PURE__ */ x("em", { children: C("games.dmd.pickTrait") })
									]
								}) }, e))
							}) : /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ S("div", {
								className: "dmd-route",
								children: [
									/* @__PURE__ */ S("div", {
										"aria-label": C("games.dmd.deckAria", { n: e.deckCount }),
										className: "dmd-pile dmd-pile--deck",
										children: [/* @__PURE__ */ S("span", {
											ref: T,
											className: "dmd-pile-face",
											children: [/* @__PURE__ */ x(Me, {}), /* @__PURE__ */ x("span", {
												className: "dmd-pile-count font-mono tabular-nums",
												children: e.deckCount
											})]
										}), /* @__PURE__ */ x("strong", { children: C("games.dmd.deckLabel") })]
									}),
									/* @__PURE__ */ x("div", {
										ref: ne,
										className: "dmd-river",
										"aria-label": C("games.dmd.riverLabel"),
										children: e.river.length > 0 || e.staged ? /* @__PURE__ */ S("ul", {
											className: "dmd-river-cards",
											children: [e.river.map((t, n) => /* @__PURE__ */ x("li", { children: /* @__PURE__ */ x(Fe, {
												card: t.card,
												safe: t.safe,
												busted: e.busting === t.card.suit
											}) }, t.card.suit + "-" + t.card.value + "-" + n)), e.staged && /* @__PURE__ */ x("li", {
												"aria-hidden": !0,
												children: /* @__PURE__ */ x("div", {
													ref: D,
													className: "dmd-river-slot"
												})
											})]
										}) : /* @__PURE__ */ S("div", {
											className: "dmd-river-empty",
											children: [/* @__PURE__ */ x(J, {}), /* @__PURE__ */ x("span", { children: C("games.dmd.riverEmpty") })]
										})
									}),
									/* @__PURE__ */ S("div", {
										"aria-label": C("games.dmd.discardAria", { n: e.discard.length }),
										className: "dmd-pile dmd-pile--discard",
										children: [/* @__PURE__ */ S("span", {
											ref: E,
											className: "dmd-pile-face",
											children: [e.discard.length > 0 ? /* @__PURE__ */ x(Y, {
												card: e.discard[e.discard.length - 1],
												shadow: "stack"
											}) : /* @__PURE__ */ x("span", {
												className: "dmd-pile-empty",
												children: "∅"
											}), /* @__PURE__ */ x("span", {
												className: "dmd-pile-count font-mono tabular-nums",
												children: e.discard.length
											})]
										}), /* @__PURE__ */ x("strong", { children: C("games.dmd.discardLabel") })]
									})
								]
							}), /* @__PURE__ */ x("div", {
								className: "dmd-route-note",
								children: e.krakenLeft > 0 ? /* @__PURE__ */ x("strong", {
									className: "dmd-kraken-warning",
									children: C("games.dmd.krakenLeft", { n: e.krakenLeft })
								}) : /* @__PURE__ */ x("span", { children: C("games.dmd.routeRule") })
							})] })
						]
					}),
					j?.kind === "navMap" ? /* @__PURE__ */ S("div", {
						className: "dmd-bank-scroll dmd-discard-choice",
						children: [/* @__PURE__ */ x("p", { children: C("games.dmd.navMapHint") }), /* @__PURE__ */ x("ul", { children: e.discard.map((e, t) => /* @__PURE__ */ x("li", { children: /* @__PURE__ */ x("button", {
							type: "button",
							"aria-label": C("games.dmd.pickCardAria", {
								suit: C(k[e.suit]),
								value: e.value
							}),
							onClick: () => g({
								type: "mapPick",
								index: t
							}),
							children: /* @__PURE__ */ x(Y, {
								card: e,
								shadow: "lift"
							})
						}) }, e.suit + "-" + e.value + "-" + t)) })]
					}) : /* @__PURE__ */ x("div", {
						className: "dmd-bank-scroll",
						children: [c, ...e.players.filter((e) => e !== c)].map((t) => /* @__PURE__ */ x(Ie, {
							pub: e,
							rid: t,
							mine: t === c,
							name: w(t),
							member: r.find((e) => e.rid === t),
							targetable: (e) => ce(t, e),
							onPick: (e) => {
								let n = ce(t, e);
								n === "hook" ? g({
									type: "hook",
									suit: e
								}) : n === "cannon" ? g({
									type: "cannon",
									target: t,
									suit: e
								}) : n === "sword" && g({
									type: "sword",
									target: t,
									suit: e
								});
							}
						}, t))
					}),
					/* @__PURE__ */ S("button", {
						type: "button",
						onClick: () => P(!0),
						"aria-label": C("games.dmd.logAria"),
						className: "dmd-log-ticker",
						children: [/* @__PURE__ */ x(m, {
							size: 15,
							"aria-hidden": !0
						}), /* @__PURE__ */ x("span", { children: F ?? C("games.dmd.logEmpty") })]
					}),
					j?.kind === "map" ? /* @__PURE__ */ x("div", {
						className: "dmd-choice-popover",
						"aria-label": C("games.dmd.mapHint"),
						children: j.options.map((e, t) => /* @__PURE__ */ x("button", {
							type: "button",
							"aria-label": C("games.dmd.pickCardAria", {
								suit: C(k[e.suit]),
								value: e.value
							}),
							onClick: () => g({
								type: "mapPick",
								index: t
							}),
							children: /* @__PURE__ */ x(Y, {
								card: e,
								shadow: "lift"
							})
						}, e.suit + "-" + e.value + "-" + t))
					}) : t?.oraclePeek ? /* @__PURE__ */ x("div", {
						className: "dmd-choice-popover",
						"aria-label": C("games.dmd.oracleHint"),
						children: t.oraclePeek.map((e, t) => /* @__PURE__ */ x(Y, {
							card: e,
							size: "sm",
							shadow: "lift"
						}, e.suit + "-" + e.value + "-" + t))
					}) : null
				]
			})
		}), /* @__PURE__ */ x(He, {
			open: N,
			log: e.log,
			nameOf: w,
			onClose: () => P(!1)
		})]
	});
}
function Fe({ card: e, safe: t, busted: n }) {
	return /* @__PURE__ */ x("div", {
		className: n ? "stage-shake rounded-xl ring-2 ring-danger" : void 0,
		children: /* @__PURE__ */ x(Y, {
			card: e,
			safe: t
		})
	});
}
function Ie({ pub: e, rid: t, mine: n, name: r, member: i, targetable: a, onPick: o }) {
	let s = p(), { ref: c } = u("seat:" + t), d = e.banks[t] ?? {}, f = e.traits[t], m = D.filter((e) => (d[e]?.length ?? 0) > 0);
	return /* @__PURE__ */ S("section", {
		"aria-label": s("games.dmd.bankAria", { name: r }),
		className: n ? "dmd-bank dmd-bank--mine" : "dmd-bank",
		children: [/* @__PURE__ */ S("header", {
			className: "dmd-bank-head",
			children: [
				/* @__PURE__ */ x("span", {
					ref: c,
					className: "dmd-bank-avatar",
					style: { backgroundColor: h[(i?.colorIndex ?? 0) % h.length].hex },
					children: i ? /* @__PURE__ */ x("img", {
						src: l[i.avatar % l.length],
						alt: "",
						draggable: !1
					}) : /* @__PURE__ */ x(J, {})
				}),
				/* @__PURE__ */ S("span", {
					className: "dmd-bank-name",
					children: [/* @__PURE__ */ x("strong", { children: n ? s("games.dmd.myBank") : s("games.dmd.otherBank", { name: r }) }), f && /* @__PURE__ */ x("small", {
						title: s(oe[f]),
						children: s(ae[f])
					})]
				}),
				/* @__PURE__ */ x("span", {
					className: "dmd-bank-score font-mono tabular-nums",
					children: s("games.dmd.scoreShort", { n: e.scores[t] ?? 0 })
				})
			]
		}), m.length > 0 ? /* @__PURE__ */ x("ul", {
			className: "dmd-bank-stacks",
			children: m.map((e) => {
				let n = d[e] ?? [], i = a(e), c = /* @__PURE__ */ x(Le, {
					rid: t,
					suit: e,
					top: n[0],
					count: n.length
				});
				return /* @__PURE__ */ x("li", { children: i ? /* @__PURE__ */ S("button", {
					type: "button",
					"aria-label": s("games.dmd.targetAria", {
						suit: s(k[e]),
						name: r
					}),
					onClick: () => o(e),
					className: "dmd-stack-button",
					children: [/* @__PURE__ */ x("span", {
						className: "dmd-stack-target",
						children: s(i === "cannon" ? "games.dmd.targetCannon" : i === "hook" ? "games.dmd.targetHook" : "games.dmd.targetSword")
					}), c]
				}) : c }, e);
			})
		}) : /* @__PURE__ */ S("div", {
			className: "dmd-bank-empty",
			children: [/* @__PURE__ */ x("div", {
				className: "dmd-bank-empty-marks",
				"aria-hidden": !0,
				children: [
					"anchor",
					"cannon",
					"chest",
					"mermaid",
					"sword"
				].map((e) => /* @__PURE__ */ x("span", { children: /* @__PURE__ */ x(q, { suit: e }) }, e))
			}), /* @__PURE__ */ x("small", { children: s(n ? "games.dmd.emptyMyBank" : "games.dmd.emptyOtherBank") })]
		})]
	});
}
function Le({ rid: e, suit: t, top: n, count: r }) {
	let i = p(), { ref: a, hidden: o } = u("bank:" + e + ":" + t);
	return /* @__PURE__ */ S("div", {
		ref: a,
		"aria-label": i("games.dmd.stackAria", {
			suit: i(k[t]),
			value: n,
			n: r
		}),
		className: "dmd-bank-cell",
		style: {
			"--dmd-suit-color": A[t],
			visibility: o ? "hidden" : void 0
		},
		children: [
			/* @__PURE__ */ x(q, { suit: t }),
			/* @__PURE__ */ x("span", {
				className: "dmd-bank-cell-value font-display tabular-nums",
				children: n
			}),
			/* @__PURE__ */ S("span", {
				className: "dmd-bank-cell-count font-mono tabular-nums",
				children: ["×", r]
			})
		]
	});
}
function Re({ pub: e, priv: t, myRid: n, nameOf: r, send: i }) {
	let a = p(), o = e.phase === "turn" && e.current === n, s = o ? e.pending : null;
	if (e.busting) return /* @__PURE__ */ x("p", {
		className: "dmd-action-message dmd-action-message--danger",
		children: a("games.dmd.busting")
	});
	if (e.staged) return /* @__PURE__ */ x("p", {
		className: "dmd-action-message",
		children: a("games.dmd.cardInFlight")
	});
	if (e.phase === "traits") {
		let n = a("games.dmd.pickTraitWaiting", { n: e.players.length - e.traitPicked.length });
		return /* @__PURE__ */ x("p", {
			className: "dmd-action-message",
			children: t?.myPicked || !t?.myOffers ? n : a("games.dmd.pickTrait")
		});
	}
	if (e.phase === "jones") return e.traits[n] === "jonesLocker" ? /* @__PURE__ */ x("div", {
		className: "dmd-action-choice",
		children: e.players.filter((e) => e !== n).map((e) => /* @__PURE__ */ S("button", {
			type: "button",
			onClick: () => i({
				type: "pickJones",
				target: e
			}),
			className: "dmd-action-mini",
			children: [
				/* @__PURE__ */ x("span", {
					"aria-hidden": !0,
					children: "⚰️"
				}),
				" ",
				r(e)
			]
		}, e))
	}) : /* @__PURE__ */ x("p", {
		className: "dmd-action-message",
		children: a("games.dmd.jonesWait", { name: r(e.players.find((t) => e.traits[t] === "jonesLocker") ?? e.current) })
	});
	if (!o) return /* @__PURE__ */ x("p", {
		className: "dmd-action-message",
		children: e.phase === "turn" ? a("games.dmd.turnOther", { name: r(e.current) }) : ""
	});
	if (s?.kind === "plunder") return /* @__PURE__ */ x("div", {
		className: "dmd-action-choice",
		children: e.players.filter((e) => e !== n).map((t) => {
			let n = Object.values(e.banks[t] ?? {}).reduce((e, t) => e + (t?.length ?? 0), 0);
			return /* @__PURE__ */ S("button", {
				type: "button",
				disabled: n === 0,
				onClick: () => i({
					type: "plunder",
					target: t
				}),
				className: "dmd-action-mini disabled:opacity-40",
				children: [/* @__PURE__ */ x("span", { children: r(t) }), /* @__PURE__ */ x("span", {
					className: "font-mono text-[10px] tabular-nums opacity-70",
					children: a("games.dmd.plunderCount", { n })
				})]
			}, t);
		})
	});
	if (s && s.kind !== "oracle") {
		let e = s.kind === "cannon" ? "cannon" : s.kind === "hook" ? "hook" : s.kind === "sword" ? "sword" : "map", t = s.kind === "cannon" ? a("games.dmd.cannonActionTitle") : s.kind === "hook" ? a("games.dmd.hookActionTitle") : s.kind === "sword" ? a("games.dmd.swordActionTitle") : a("games.dmd.mapActionTitle");
		return /* @__PURE__ */ S("div", {
			className: "dmd-action-guidance",
			children: [/* @__PURE__ */ x("span", {
				className: "dmd-action-medal",
				children: /* @__PURE__ */ x(q, { suit: e })
			}), /* @__PURE__ */ S("span", { children: [/* @__PURE__ */ x("strong", { children: t }), /* @__PURE__ */ x("small", { children: ze(s, a) })] })]
		});
	}
	let c = e.river.length > 0 && e.krakenLeft === 0;
	return /* @__PURE__ */ S("div", {
		className: "dmd-action-pair",
		children: [/* @__PURE__ */ S("button", {
			type: "button",
			"aria-label": a("games.dmd.drawAria"),
			disabled: e.deckCount === 0,
			onClick: () => i({ type: "draw" }),
			className: "dmd-action-button dmd-action-button--draw disabled:opacity-40",
			style: { background: M.accent },
			children: [
				/* @__PURE__ */ x(J, {}),
				" ",
				a("games.dmd.draw")
			]
		}), /* @__PURE__ */ S("button", {
			type: "button",
			"aria-label": a("games.dmd.collectAria"),
			disabled: !c,
			onClick: () => i({ type: "collect" }),
			className: "dmd-action-button dmd-action-button--collect disabled:opacity-40",
			children: [
				/* @__PURE__ */ x(q, { suit: "chest" }),
				" ",
				e.krakenLeft > 0 ? a("games.dmd.krakenLeft", { n: e.krakenLeft }) : e.river.length > 0 ? a("games.dmd.collectN", { n: e.river.length }) : a("games.dmd.collect")
			]
		})]
	});
}
function ze(e, t) {
	switch (e.kind) {
		case "cannon": return t(e.self ? "games.dmd.cannonSelfHint" : "games.dmd.cannonHint");
		case "hook": return t("games.dmd.hookHint");
		case "sword": return t("games.dmd.swordHint");
		case "map": return t("games.dmd.mapHint");
		case "navMap": return t("games.dmd.navMapHint");
		case "oracle": return t("games.dmd.oracleHint");
		case "plunder": return t("games.dmd.plunderHint", { n: e.count });
	}
}
function Be(e) {
	switch (e.ev.kind) {
		case "draw": return O[e.ev.card.suit];
		case "bust": return "💥";
		case "collect": return "🏦";
		case "cannon": return O.cannon;
		case "steal": return O.sword;
		case "hooked": return O.hook;
		case "mapped": return O.map;
		case "plundered": return "🏴‍☠️";
		case "fizzle": return "🫧";
		default: return "";
	}
}
function Ve(e, t, n) {
	let r = n(t.rid), i = (t) => e(k[t]);
	switch (t.ev.kind) {
		case "draw": return e("games.dmd.logDraw", {
			name: r,
			suit: i(t.ev.card.suit),
			value: t.ev.card.value
		});
		case "bust": return t.ev.kept > 0 ? e("games.dmd.logBustKept", {
			name: r,
			n: t.ev.kept
		}) : e("games.dmd.logBust", { name: r });
		case "collect": return t.ev.bonus > 0 ? e("games.dmd.logCollectBonus", {
			name: r,
			count: t.ev.count,
			bonus: t.ev.bonus
		}) : e("games.dmd.logCollect", {
			name: r,
			n: t.ev.count
		});
		case "cannon": return e(t.ev.taken ? "games.dmd.logCannonTaken" : "games.dmd.logCannon", {
			name: r,
			target: n(t.ev.target),
			suit: i(t.ev.suit),
			n: t.ev.count
		});
		case "steal": return e("games.dmd.logSteal", {
			name: r,
			target: n(t.ev.from),
			suit: i(t.ev.card.suit),
			value: t.ev.card.value
		});
		case "hooked": return e("games.dmd.logHooked", {
			name: r,
			suit: i(t.ev.card.suit),
			value: t.ev.card.value
		});
		case "mapped": return e("games.dmd.logMapped", {
			name: r,
			suit: i(t.ev.card.suit),
			value: t.ev.card.value
		});
		case "plundered": return e("games.dmd.logPlundered", {
			name: r,
			target: n(t.ev.from),
			n: t.ev.count
		});
		case "fizzle": return e("games.dmd.logFizzle", {
			name: r,
			suit: i(t.ev.suit)
		});
		default: return "";
	}
}
function He({ open: e, log: t, nameOf: n, onClose: r }) {
	let i = p();
	return /* @__PURE__ */ S(c, {
		open: e,
		onClose: r,
		label: i("games.dmd.logAria"),
		children: [/* @__PURE__ */ x("p", {
			className: "font-display text-lg font-extrabold",
			children: i("games.dmd.logAria")
		}), t.length === 0 ? /* @__PURE__ */ x("p", {
			className: "text-xs font-bold opacity-60",
			children: i("games.dmd.logEmpty")
		}) : /* @__PURE__ */ x("ul", {
			className: "flex flex-col gap-1",
			children: [...t].reverse().map((e, r) => /* @__PURE__ */ S("li", {
				className: "flex items-baseline gap-1.5 text-sm font-bold",
				children: [/* @__PURE__ */ x("span", {
					"aria-hidden": !0,
					className: "flex-none",
					children: Be(e)
				}), /* @__PURE__ */ x("span", {
					className: "min-w-0",
					children: Ve(i, e, n)
				})]
			}, t.length - 1 - r))
		})]
	});
}
function Ue(e, t, n) {
	let r = e.last;
	if (!r) return;
	let i = (e) => n(k[e]);
	switch (r.kind) {
		case "bust": return r.kept > 0 ? n("games.dmd.bustKeptText", { n: r.kept }) : n("games.dmd.bustText");
		case "collect": return r.bonus > 0 ? n("games.dmd.collectBonusText", {
			count: r.count,
			bonus: r.bonus
		}) : n("games.dmd.collectText", { n: r.count });
		case "cannon": return n(r.taken ? "games.dmd.cannonTakenText" : "games.dmd.cannonText", {
			target: t(r.target),
			suit: i(r.suit),
			n: r.count
		});
		case "steal": return n("games.dmd.stealText", {
			target: t(r.from),
			suit: i(r.card.suit),
			value: r.card.value
		});
		case "hooked": return n("games.dmd.hookedText", {
			suit: i(r.card.suit),
			value: r.card.value
		});
		case "mapped": return n("games.dmd.mappedText", {
			suit: i(r.card.suit),
			value: r.card.value
		});
		case "plundered": return n("games.dmd.plunderedText", {
			target: t(r.from),
			n: r.count
		});
		case "fizzle": return n("games.dmd.fizzleText", { suit: i(r.suit) });
		default: return;
	}
}
//#endregion
//#region src/games/dmd/bot.ts
function We() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function Ge(e) {
	let t = j[e];
	return Array.from({ length: 6 }, (e, n) => t + n);
}
function Ke(e) {
	let t = {};
	for (let e of D) t[e] = Ge(e);
	let n = (e, n) => {
		let r = t[e], i = r?.indexOf(n);
		r && i !== void 0 && i >= 0 && r.splice(i, 1);
	};
	for (let t of e.discard) n(t.suit, t.value);
	for (let t of e.river) n(t.card.suit, t.card.value);
	for (let t of e.players) for (let [r, i] of Object.entries(e.banks[t] ?? {})) for (let e of i ?? []) n(r, e);
	return t;
}
var qe = [
	"treasureHunter",
	"navigator",
	"mystic",
	"scavenger",
	"miser",
	"safeHarbor",
	"goldenScales",
	"casanova",
	"swordsman",
	"masterGunner",
	"fisherman",
	"plunderer",
	"captainHook",
	"beastmaster",
	"parry",
	"misfire",
	"jonesLocker"
];
function Je(e, t) {
	return Object.values(e.banks[t] ?? {}).reduce((e, t) => e + (t?.length ?? 0), 0);
}
function Ye(e, t) {
	let n = null;
	for (let [r, i] of Object.entries(e.banks[t] ?? {})) i && i.length !== 0 && (n === null || i[0] > (e.banks[t][n]?.[0] ?? 0)) && (n = r);
	return n;
}
var Xe = (e, t) => {
	let n = e.public, r = e.private, i = t.rid, a = C(s(i)), o = t.difficulty === "weak";
	if (n.phase === "traits") return !r?.myOffers || r.myPicked ? null : o ? { action: {
		type: "pickTrait",
		trait: r.myOffers[Math.floor(We() * r.myOffers.length)]
	} } : { action: {
		type: "pickTrait",
		trait: [...r.myOffers].sort((e, t) => qe.indexOf(e) - qe.indexOf(t))[0]
	} };
	if (n.phase === "jones") {
		if (n.traits[i] !== "jonesLocker") return null;
		let e = n.players.filter((e) => e !== i);
		return { action: {
			type: "pickJones",
			target: e[Math.floor(We() * e.length)]
		} };
	}
	if (n.phase !== "turn" || n.current !== i || n.busting || n.staged) return null;
	let c = n.pending, l = new Set(n.river.map((e) => e.card.suit)), u = n.banks[i] ?? {};
	if (c?.kind === "cannon") {
		if (c.self) {
			let e = null;
			for (let [t, n] of Object.entries(u)) n && n.length !== 0 && (e === null || n[0] < (u[e]?.[0] ?? 99)) && (e = t);
			return e ? { action: {
				type: "cannon",
				target: i,
				suit: e
			} } : null;
		}
		let e = n.players.filter((e) => e !== i && Je(n, e) > 0).sort((e, t) => (n.scores[t] ?? 0) - (n.scores[e] ?? 0));
		for (let t of e) {
			let e = Ye(n, t);
			if (e) return { action: {
				type: "cannon",
				target: t,
				suit: e
			} };
		}
		return null;
	}
	if (c?.kind === "hook") {
		let e = null;
		for (let [t, n] of Object.entries(u)) n && n.length !== 0 && !l.has(t) && (e === null || n[0] > (u[e]?.[0] ?? 0)) && (e = t);
		return e === null && (e = Object.keys(u).find((e) => (u[e]?.length ?? 0) > 0) ?? null), e ? { action: {
			type: "hook",
			suit: e
		} } : null;
	}
	if (c?.kind === "sword") {
		let e = n.players.some((e) => e !== i && n.traits[e] === "parry"), t = n.traits[i] === "swordsman", r = null;
		for (let a of n.players) if (a !== i) for (let [i, o] of Object.entries(n.banks[a] ?? {})) o && o.length !== 0 && (e && i !== "kraken" || !t && (u[i]?.length ?? 0) > 0 || (r === null || o[0] > (n.banks[r.target][r.suit]?.[0] ?? 0)) && (r = {
			target: a,
			suit: i
		}));
		return r ? { action: {
			type: "sword",
			target: r.target,
			suit: r.suit
		} } : null;
	}
	if (c?.kind === "map") {
		let e = c.options.filter((e) => !l.has(e.suit)), t = (e.length ? e : c.options).reduce((e, t) => t.value > e.value ? t : e);
		return { action: {
			type: "mapPick",
			index: c.options.indexOf(t)
		} };
	}
	if (c?.kind === "navMap") {
		let e = 0;
		return n.discard.forEach((t, r) => {
			let i = n.discard[e], a = !l.has(i.suit), o = !l.has(t.suit);
			(o === a ? t.value > i.value : o) && (e = r);
		}), { action: {
			type: "mapPick",
			index: e
		} };
	}
	if (c?.kind === "plunder") {
		let e = n.players.filter((e) => e !== i && Je(n, e) > 0).sort((e, t) => (n.scores[t] ?? 0) - (n.scores[e] ?? 0));
		return e.length ? { action: {
			type: "plunder",
			target: e[0]
		} } : null;
	}
	if (n.river.length === 0) return n.deckCount > 0 ? { action: { type: "draw" } } : null;
	if (n.deckCount === 0) return { action: { type: "collect" } };
	let d = c?.kind === "oracle" ? r?.oraclePeek ?? null : null;
	if (d && d.length > 0) return l.has(d[0].suit) && n.krakenLeft === 0 ? { action: { type: "collect" } } : { action: { type: "draw" } };
	if (n.krakenLeft > 0) return { action: { type: "draw" } };
	if (o) {
		let e = .3 + .4 * a.risk + (a.noise - .5) * .15;
		return { action: { type: We() < e ? "draw" : "collect" } };
	}
	let f = Ke(n), p = 0, m = 0;
	for (let e of D) {
		let t = (f[e] ?? []).length;
		p += t, l.has(e) && (m += t);
	}
	let h = 0;
	for (let e of D) {
		if (l.has(e)) continue;
		let t = 0;
		for (let n of f[e] ?? []) t += Math.max(0, n - (u[e]?.[0] ?? 0));
		h += t / Math.max(1, p);
	}
	let g = {};
	for (let e of n.river) e.safe || (g[e.card.suit] = Math.max(g[e.card.suit] ?? 0, e.card.value));
	let _ = 0;
	for (let [e, t] of Object.entries(g)) _ += Math.max(0, t - (u[e]?.[0] ?? 0));
	l.has("key") && l.has("chest") && (_ += n.river.length), n.traits[i] === "goldenScales" && l.has("mermaid") && !u.mermaid?.length && (_ += 5), n.jonesTarget === i && (_ *= 2);
	let v = p > 0 ? m / p : 1, y = h / (h + _ + 1e-6), b = (n.scores[i] ?? 0) - Math.max(0, ...n.players.filter((e) => e !== i).map((e) => n.scores[e] ?? 0)), x = Math.min(1, Math.max(0, -b / 25)) * a.compete;
	return { action: { type: v < y * (.9 + 1 * a.risk + .4 * a.greed + .5 * x + (a.noise - .5) * .2) ? "draw" : "collect" } };
}, Ze = (e, t, n) => {
	let r = t.public;
	switch (e.type) {
		case "pickTrait": return n("games.dmd.hintPickTrait", { trait: n(ae[e.trait]) });
		case "pickJones": return n("games.dmd.hintPickJones");
		case "cannon": return r.pending?.kind === "cannon" && r.pending.self ? n("games.dmd.hintCannonSelf", { suit: n(k[e.suit]) }) : n("games.dmd.hintCannon", { suit: n(k[e.suit]) });
		case "hook": return n("games.dmd.hintHook", { suit: n(k[e.suit]) });
		case "sword": return n("games.dmd.hintSword", { suit: n(k[e.suit]) });
		case "mapPick": {
			let t = r.pending?.kind === "map" ? r.pending.options[e.index] : r.discard[e.index];
			return t ? n("games.dmd.pickCardAria", {
				suit: n(k[t.suit]),
				value: t.value
			}) : "";
		}
		case "plunder": return n("games.dmd.hintPlunder", { n: r.pending?.kind === "plunder" ? r.pending.count : 1 });
		case "draw": return n("games.dmd.drawAria");
		case "collect": return n("games.dmd.collectN", { n: r.river.length });
		case "tick": return "";
	}
};
//#endregion
//#region src/games/dmd/fx.tsx
function X(e) {
	return e && typeof e == "object" && "suit" in e && "value" in e ? e : null;
}
function Z(e) {
	let t = e.anchor("riverGeometry");
	return {
		w: t?.w ?? 56,
		h: t?.h ?? 80
	};
}
function Q(e) {
	let t = e.anchor("riverSlot");
	if (t) return t;
	let n = e.anchor("river");
	if (!n) return null;
	let { w: r, h: i } = Z(e);
	return {
		x: n.x + (n.w - r) / 2,
		y: n.y + (n.h - i) / 2,
		w: r,
		h: i
	};
}
function $(e, t, n, r, i, a = 0) {
	if (!e || !t) return null;
	let o = i.w > 60, s = o ? i.w : 36, c = o ? i.h : 48, l = Math.min(s, t.w), u = l * c / s, d = {
		x: t.x + (t.w - l) / 2,
		y: t.y + (t.h - u) / 2,
		w: l,
		h: u
	};
	return /* @__PURE__ */ x(T, {
		from: e,
		to: d,
		ms: r,
		delay: a,
		children: /* @__PURE__ */ x(Y, {
			card: n,
			size: o ? "md" : "sm",
			shadow: "lift",
			w: o ? s : void 0,
			h: o ? c : void 0
		})
	});
}
function Qe() {
	return /* @__PURE__ */ S("svg", {
		className: "h-9 w-9",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ x("path", {
			d: "m20 2 4 9 10-5-4 10 9 4-9 4 4 10-10-5-4 9-4-9-10 5 4-10-9-4 9-4L6 6l10 5Z",
			fill: "#dca64a",
			stroke: "#15323b",
			strokeWidth: "2"
		}), /* @__PURE__ */ x("path", {
			d: "m16 14 8 12m0-12-8 12",
			stroke: "#b75336",
			strokeWidth: "3",
			strokeLinecap: "round"
		})]
	});
}
function $e({ from: e, to: t, card: n, ms: r, shake: o = !1 }) {
	let s = a(null), c = a(null), l = t.w > 60, u = l ? t.w * 1.16 : 64, d = l ? t.h * 1.16 : 96;
	return i(() => {
		let n = s.current, i = c.current;
		if (!n || !i) return;
		n.style.left = `${e.x + (e.w - u) / 2}px`, n.style.top = `${e.y + (e.h - d) / 2}px`;
		let a = t.x + t.w / 2 - (e.x + e.w / 2), l = t.y + t.h / 2 - (e.y + e.h / 2), f = t.w / u, p = o ? .55 : .82, m = o ? [
			{ transform: "translate(0px, 0px) scale(1)" },
			{
				transform: `translate(${a * .5}px, ${l * .5 - 18}px) scale(1)`,
				offset: p * .6
			},
			{
				transform: `translate(${a}px, ${l}px) scale(${f * 1.1})`,
				offset: p
			},
			{
				transform: `translate(${a - 4}px, ${l}px) scale(${f * 1.06})`,
				offset: p + .09
			},
			{
				transform: `translate(${a + 4}px, ${l}px) scale(${f * 1.06})`,
				offset: p + .18
			},
			{
				transform: `translate(${a - 3}px, ${l}px) scale(${f})`,
				offset: p + .27
			},
			{
				transform: `translate(${a + 2}px, ${l}px) scale(${f})`,
				offset: p + .35
			},
			{ transform: `translate(${a}px, ${l}px) scale(${f})` }
		] : [
			{ transform: "translate(0px, 0px) scale(1)" },
			{
				transform: `translate(${a * .55}px, ${l * .55 - 14}px) scale(1)`,
				offset: p * .65
			},
			{
				transform: `translate(${a}px, ${l}px) scale(${f * 1.06})`,
				offset: p
			},
			{ transform: `translate(${a}px, ${l}px) scale(${f})` }
		], h = n.animate(m, {
			duration: r,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		}), g = i.animate([
			{ transform: "rotateY(180deg)" },
			{
				transform: "rotateY(180deg)",
				offset: p * .3
			},
			{
				transform: "rotateY(360deg)",
				offset: p * .9
			},
			{ transform: "rotateY(360deg)" }
		], {
			duration: r,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => {
			h.cancel(), g.cancel();
		};
	}, [
		e,
		t,
		r,
		o,
		u,
		d
	]), /* @__PURE__ */ x("div", {
		ref: s,
		className: "absolute",
		style: {
			left: e.x,
			top: e.y
		},
		children: /* @__PURE__ */ x("div", {
			style: { perspective: "500px" },
			children: /* @__PURE__ */ S("div", {
				ref: c,
				className: "relative",
				style: {
					width: u,
					height: d,
					transformStyle: "preserve-3d"
				},
				children: [/* @__PURE__ */ x("div", {
					className: "absolute inset-0",
					style: { backfaceVisibility: "hidden" },
					children: /* @__PURE__ */ x(Y, {
						card: n,
						size: "lg",
						shadow: "lift",
						w: l ? u : void 0,
						h: l ? d : void 0
					})
				}), /* @__PURE__ */ x("div", {
					"aria-hidden": !0,
					className: "absolute inset-0",
					style: {
						transform: "rotateY(180deg)",
						backfaceVisibility: "hidden"
					},
					children: /* @__PURE__ */ x(Me, {
						size: "lg",
						shadow: "lift",
						w: l ? u : void 0,
						h: l ? d : void 0
					})
				})]
			})
		})
	});
}
var et = {
	gameStart(e, t) {
		let n = t.anchor("deck");
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ x(E, {
				at: n,
				ms: 700
			})
		} : null;
	},
	traitReveal: () => null,
	toRiver(e, t) {
		let n = X(e.data?.card), r = t.anchor("deck"), i = Q(t);
		if (!n || !r || !i) return null;
		let a = n.suit === "kraken", o = a ? z.kraken : z.draw;
		return a && navigator.vibrate?.(150), {
			ms: o,
			node: /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x($e, {
					from: r,
					to: i,
					card: n,
					ms: o,
					shake: a
				}),
				a && /* @__PURE__ */ x(E, {
					at: i,
					ms: 700,
					delay: o * .55
				}),
				a && /* @__PURE__ */ x(w, {
					at: i,
					ms: 900,
					delay: o * .55,
					children: /* @__PURE__ */ x(q, {
						suit: "kraken",
						className: "h-9 w-9"
					})
				})
			] })
		};
	},
	directBank(e, t) {
		let n = X(e.data?.card), r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: z.direct,
			node: $(t.anchor("deck"), r, n, z.direct - 50, Z(t))
		} : null;
	},
	bust(e, t) {
		g(), navigator.vibrate?.(200);
		let n = t.anchor("river"), r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return {
			ms: z.bustHold,
			node: /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x(ee, { ms: 600 }),
				n && /* @__PURE__ */ x(E, {
					at: n,
					ms: 900
				}),
				r && /* @__PURE__ */ x(w, {
					at: r,
					ms: 900,
					delay: 250,
					children: /* @__PURE__ */ x(Qe, {})
				})
			] })
		};
	},
	bustSweep(e, t) {
		let n = e.data, r = (Array.isArray(n?.river) ? n.river : []).map((e) => {
			let t = X(e?.card);
			return t ? {
				card: t,
				safe: e.safe === !0
			} : null;
		}).filter((e) => e !== null), i = t.anchor("river"), a = e.rid ? t.anchor(`seat:${e.rid}`) : null, o = typeof n?.jones == "string" ? n.jones : null, { w: s, h: c } = Z(t), l = s * 6 / 56, u = s * 4 / 56, d = (e) => {
			let t = Math.min(s, e.w), n = c * t / s;
			return {
				x: e.x + (e.w - t) / 2,
				y: e.y + (e.h - n) / 2,
				w: t,
				h: n
			};
		}, f = (e) => {
			if (!i) return null;
			let t = 2 * u + r.length * s + Math.max(0, r.length - 1) * l, n = Math.max(0, t - i.w), a = i.x + u, o = Math.max(a, i.x + i.w - s - u);
			return {
				x: Math.min(o, Math.max(a, a + e * (s + l) - n)),
				y: i.y + (i.h - c) / 2,
				w: s,
				h: c
			};
		}, p = (t) => t.safe ? e.rid ? `bank:${e.rid}:${t.card.suit}` : null : o ? `bank:${o}:${t.card.suit}` : "discard", m = (e) => {
			let n = p(e), r = n ? t.anchor(n) : null;
			if (r) return d(r);
			let i = e.safe ? a : o ? t.anchor(`seat:${o}`) : null;
			return i ? d(i) : null;
		}, h = [...new Set(r.map(p).filter((e) => e !== null && t.anchor(e) !== null))], g = o ? t.anchor(`seat:${o}`) : null, _ = r.filter((e) => e.safe).length, v = r.length - _;
		return {
			ms: 300 + r.length * 70 + 500,
			hide: h.length ? h : void 0,
			node: /* @__PURE__ */ S(b, { children: [
				r.map((e, t) => {
					let n = f(t), r = m(e);
					return n && r ? /* @__PURE__ */ x(T, {
						from: n,
						to: r,
						ms: 500,
						delay: 300 + t * 70,
						children: /* @__PURE__ */ x(Y, {
							card: e.card,
							size: "md",
							shadow: "lift",
							w: s > 60 ? s : void 0,
							h: s > 60 ? c : void 0
						})
					}, `${e.card.suit}-${e.card.value}`) : null;
				}),
				a && _ > 0 && /* @__PURE__ */ x(w, {
					at: a,
					ms: 900,
					delay: 300 + r.length * 70,
					children: /* @__PURE__ */ S("span", {
						className: "text-done-ink",
						children: ["+", _]
					})
				}),
				v > 0 && o && g && /* @__PURE__ */ x(w, {
					at: g,
					ms: 900,
					delay: 300 + r.length * 70,
					children: /* @__PURE__ */ S("span", {
						className: "text-done-ink",
						children: ["+", v]
					})
				}),
				v > 0 && !o && a && /* @__PURE__ */ x(w, {
					at: a,
					ms: 900,
					delay: 300 + r.length * 70,
					children: /* @__PURE__ */ S("span", {
						className: "text-danger",
						children: ["-", v]
					})
				})
			] })
		};
	},
	bank(e, t) {
		let n = t.anchor("river"), r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!n || !r) return null;
		let i = e.data?.count;
		return {
			ms: 800,
			node: /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x(T, {
				from: n,
				to: r,
				ms: 550,
				children: /* @__PURE__ */ x("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ x(q, {
						suit: "chest",
						className: "h-9 w-9"
					})
				})
			}), typeof i == "number" && /* @__PURE__ */ x(w, {
				at: r,
				ms: 900,
				delay: 450,
				children: /* @__PURE__ */ S("span", {
					className: "text-done-ink",
					children: ["+", i]
				})
			})] })
		};
	},
	cannon(e, t) {
		let n = e.data, r = typeof n?.target == "string" && typeof n?.suit == "string" ? t.anchor(`bank:${n.target}:${n.suit}`) : null, i = n?.taken && e.rid ? t.anchor(`seat:${e.rid}`) : t.anchor("discard"), a = typeof n?.suit == "string" ? n.suit : null;
		return {
			ms: 700,
			node: /* @__PURE__ */ S(b, { children: [r && i && a && /* @__PURE__ */ x(T, {
				from: r,
				to: i,
				ms: 500,
				children: /* @__PURE__ */ x("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ x(q, {
						suit: "cannon",
						className: "h-9 w-9"
					})
				})
			}), r && /* @__PURE__ */ x(E, {
				at: r,
				ms: 600
			})] })
		};
	},
	hooked(e, t) {
		let n = X(e.data?.card), r = n && e.rid ? t.anchor(`bank:${e.rid}:${n.suit}`) : null, i = Q(t);
		return !n || !r || !i ? null : {
			ms: z.ability,
			node: $(r, i, n, z.ability - 50, Z(t))
		};
	},
	steal(e, t) {
		let n = e.data, r = X(n?.card), i = r && typeof n?.from == "string" ? t.anchor(`bank:${n.from}:${r.suit}`) : null, a = Q(t);
		return !r || !i || !a ? null : {
			ms: z.ability,
			node: $(i, a, r, z.ability - 50, Z(t))
		};
	},
	mapped(e, t) {
		let n = X(e.data?.card), r = Q(t);
		return !n || !r ? null : {
			ms: z.ability,
			node: $(t.anchor("discard"), r, n, z.ability - 50, Z(t))
		};
	},
	plundered(e, t) {
		let n = e.data, r = typeof n?.from == "string" ? t.anchor(`seat:${n.from}`) : null, i = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!r || !i) return null;
		let a = typeof n?.count == "number" ? n.count : 0;
		return {
			ms: 900,
			node: /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x(T, {
				from: r,
				to: i,
				ms: 550,
				children: /* @__PURE__ */ x("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ x(q, {
						suit: "chest",
						className: "h-9 w-9"
					})
				})
			}), /* @__PURE__ */ x(w, {
				at: i,
				ms: 900,
				delay: 450,
				children: /* @__PURE__ */ S("span", {
					className: "text-done-ink",
					children: ["+", a]
				})
			})] })
		};
	}
};
//#endregion
//#region src/games/dmd/game-over.tsx
function tt(e, t, n, r) {
	let i = {
		cols: n,
		w: 0
	};
	for (let a = 1; a <= n; a += 1) {
		let o = Math.ceil(n / a), s = Math.min(r, (e - 12 * (a - 1)) / a, ((t - 12 * (o - 1)) / o - 29) * 56 / 80);
		s > i.w && (i = {
			cols: a,
			w: s
		});
	}
	if (i.w < 80) {
		let t = Math.max(1, Math.min(n, Math.floor((e + 12) / 92)));
		i = {
			cols: t,
			w: Math.min(r, (e - 12 * (t - 1)) / t)
		};
	}
	let a = Math.max(1, Math.floor(i.w * 10) / 10), o = a * 80 / 56, s = Math.ceil(n / i.cols);
	return {
		cols: i.cols,
		w: a,
		h: o,
		contentHeight: s * (o + 29) + 12 * (s - 1)
	};
}
function nt({ rid: e, rank: t, member: n, name: i, won: s, bank: c, score: u, playerCount: d }) {
	let f = p(), m = a(null), g = a(null), _ = a(null), [v, y] = o(null), b = D.filter((e) => (c[e]?.length ?? 0) > 0), C = b.reduce((e, t) => e + (c[t]?.length ?? 0), 0);
	r(() => {
		let e = m.current, t = g.current, n = _.current, r = e?.closest(".dmd-over-rankings");
		if (!e || !t || !n || !r || b.length === 0) return;
		let i = () => {
			let i = getComputedStyle(r);
			if (i.getPropertyValue("--dmd-result-large").trim() !== "1") {
				y((e) => e === null ? e : null);
				return;
			}
			let a = (e) => parseFloat(e) || 0, o = getComputedStyle(e), s = getComputedStyle(n), c = Math.ceil(d / 2), l = (r.clientHeight - a(i.paddingTop) - a(i.paddingBottom) - (c - 1) * a(i.rowGap)) / c, u = a(o.paddingTop) + a(o.paddingBottom) + a(o.borderTopWidth) + a(o.borderBottomWidth) + t.getBoundingClientRect().height + a(s.paddingTop) + a(s.paddingBottom), f = tt(n.clientWidth - a(s.paddingLeft) - a(s.paddingRight), l - u, b.length, d <= 2 ? 170 : 132), p = f.contentHeight + u;
			y((e) => e?.w === f.w && e.cols === f.cols && e.minHeight === p ? e : {
				...f,
				minHeight: p
			});
		}, a = new ResizeObserver(i);
		return a.observe(r), a.observe(e), a.observe(t), a.observe(n), i(), () => a.disconnect();
	}, [d, b.length]);
	let ee = v ? {
		"--dmd-result-card-w": `${v.w}px`,
		"--dmd-result-card-h": `${v.h}px`,
		"--dmd-result-cols": v.cols,
		minHeight: v.minHeight
	} : void 0;
	return /* @__PURE__ */ S("section", {
		ref: m,
		"data-rid": e,
		style: ee,
		className: s ? "dmd-over-bank dmd-over-bank--winner" : "dmd-over-bank",
		children: [/* @__PURE__ */ S("header", {
			ref: g,
			children: [
				/* @__PURE__ */ x("span", {
					className: "dmd-over-rank font-display",
					children: s ? "★" : t
				}),
				/* @__PURE__ */ x("span", {
					className: "dmd-over-avatar",
					style: { backgroundColor: h[(n?.colorIndex ?? 0) % h.length].hex },
					children: n && /* @__PURE__ */ x("img", {
						src: l[n.avatar % l.length],
						alt: "",
						draggable: !1
					})
				}),
				/* @__PURE__ */ x("strong", { children: i }),
				/* @__PURE__ */ x("small", { children: f("games.dmd.finalCards", { n: C }) }),
				/* @__PURE__ */ x("span", {
					className: "dmd-over-score font-display tabular-nums",
					children: f("games.dmd.scoreShort", { n: u })
				})
			]
		}), b.length > 0 ? /* @__PURE__ */ x("ul", {
			ref: _,
			className: "dmd-over-loot",
			children: b.map((e) => /* @__PURE__ */ S("li", { children: [/* @__PURE__ */ x(Y, {
				card: {
					suit: e,
					value: c[e][0]
				},
				size: "sm",
				shadow: "stack"
			}), /* @__PURE__ */ S("span", {
				className: "font-mono tabular-nums",
				children: ["×", c[e].length]
			})] }, e))
		}) : /* @__PURE__ */ x("p", {
			className: "dmd-over-empty",
			children: f("games.dmd.finalEmpty")
		})]
	});
}
function rt({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let a = p(), o = f((e) => e.locale), c = t, l = r ?? i;
	return /* @__PURE__ */ x(y, {
		adaptive: !0,
		scroll: !1,
		className: "dmd-over-adaptive",
		children: /* @__PURE__ */ S("div", {
			className: "dmd-over",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ x(te, {}),
				/* @__PURE__ */ S("header", {
					className: "dmd-over-header",
					children: [/* @__PURE__ */ x(J, {}), /* @__PURE__ */ S("span", { children: [/* @__PURE__ */ x("strong", { children: a("games.dmd.finalTitle") }), /* @__PURE__ */ x("small", { children: a("games.dmd.finalSubtitle") })] })]
				}),
				/* @__PURE__ */ x("div", {
					className: "dmd-over-rankings",
					children: e.ranking.map((t, r) => {
						let i = n.find((e) => e.rid === t), a = i ? s(i.rid) === null ? i.name : d(o, i.avatar) : t, l = e.winner.includes(t), u = c.banks[t] ?? {};
						return /* @__PURE__ */ x(nt, {
							rid: t,
							rank: r + 1,
							member: i,
							name: a,
							won: l,
							bank: u,
							score: e.scores?.[t] ?? 0,
							playerCount: e.ranking.length
						}, t);
					})
				}),
				l ? /* @__PURE__ */ S("div", {
					className: "dmd-over-actions",
					children: [r && /* @__PURE__ */ x("button", {
						type: "button",
						className: "dmd-action-button dmd-action-button--draw",
						onClick: r,
						children: a("session.result.playAgain")
					}), i && /* @__PURE__ */ x("button", {
						type: "button",
						className: "dmd-action-button dmd-action-button--collect",
						onClick: i,
						children: a("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ x("p", {
					className: "dmd-over-wait",
					children: a("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/games/dmd/guide.tsx
function it() {
	let e = p();
	return /* @__PURE__ */ S("div", {
		className: "flex w-full flex-col gap-2",
		children: [/* @__PURE__ */ x("ul", {
			className: "flex w-full flex-col gap-2",
			children: D.map((t) => /* @__PURE__ */ S("li", {
				className: "frame flex items-center gap-3 p-2",
				children: [/* @__PURE__ */ x(q, {
					suit: t,
					className: "size-9 flex-none"
				}), /* @__PURE__ */ S("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ x("p", {
						className: "text-sm font-extrabold",
						children: e(k[t])
					}), /* @__PURE__ */ x("p", {
						className: "text-xs leading-5 font-bold opacity-70",
						children: e(ne[t])
					})]
				})]
			}, t))
		}), /* @__PURE__ */ x("p", {
			className: "frame p-2 text-xs leading-5 font-bold opacity-70",
			children: e("games.dmd.guideCombo")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/dmd/entry.tsx
var at = {
	definition: ke,
	View: Ne,
	bot: Xe,
	describe: Ze,
	fx: et,
	OverView: rt,
	Guide: it,
	locales: {
		zh: {
			name: "亡者神抽",
			desc: "海盗赌运:翻牌进河道攒花色能力,爆掉之前见好就收",
			rules: "游戏目标:\n抽牌堆耗尽后，完成当前回合，再计算各位玩家银行中卡牌的分数。总分最高的玩家获胜。\n\n游戏准备:\n· 游戏共有60张卡牌，分为10种花色，每种花色各有6张。美人鱼的牌面点数为4至9，其他花色的牌面点数为2至7。\n· 将每种花色中点数最低的一张牌正面朝上放入弃牌堆，再将其余卡牌洗混，组成抽牌堆。\n· 每位玩家从发给自己的两张特性卡中选择一张。所选特性在整局游戏中持续生效。\n\n回合流程:\n轮到你时，从抽牌堆顶逐张翻开卡牌，放入称为“河道”的本回合公共区域。根据翻出的花色，按以下方式处理：\n· 如果河道中尚未出现该花色，立即发动该花色的能力；具体效果见下方图鉴。\n· 如果河道中已有该花色，本回合立即失败。弃置河道中的卡牌，然后结束回合；船锚能够保护在它之前进入河道的卡牌，使这些牌仍可存入你的银行。\n· 如果没有能力要求你继续翻牌，你可以选择收手，将河道中的全部卡牌存入自己的银行，并结束回合。\n\n最终计分:\n· 对每一种花色，只计算你的银行中该花色点数最高的一张卡牌，合计这些卡牌的点数，得到总分。\n· 总分相同时，银行中卡牌数量较多的玩家获胜；卡牌数量也相同时，共享胜利。",
			pickTrait: "选一张特性卡,全场生效",
			pickTraitWaiting: "等 {{n}} 人亮出特性…",
			jonesYou: "深海魔柜:选择要盯防的对手",
			jonesWait: "等 {{name}} 选择盯防目标…",
			done: "本局结束",
			turnYou: "轮到你:抽牌,还是收手?",
			turnOther: "{{name}} 的回合…",
			draw: "抽牌",
			collect: "收手",
			collectN: "收手({{n}} 张)",
			krakenHint: "海怪缠身!还不能收手",
			krakenLeft: "还须 {{n}} 张进河道",
			busting: "爆掉了!河道即将被卷走…",
			cardInFlight: "牌飞行中…",
			cannonHint: "大炮!点选对手的一叠轰掉",
			cannonSelfHint: "哑火!点选自己的一叠弃掉",
			hookHint: "钩子!点选自己银行里的一叠钩回",
			swordHint: "佩剑!点选对手的一叠偷来",
			mapHint: "藏宝图:三选一,必须选",
			navMapHint: "航海家:从弃牌堆任选一张",
			oracleHint: "预言生效:看完再决定抽不抽",
			plunderHint: "掠夺者:选一名对手,从 TA 银行里抢 {{n}} 张",
			tapTarget: "点选上方发亮的花色栈",
			deckShort: "剩 {{n}}",
			deckAria: "抽牌堆,剩 {{n}} 张",
			discardAria: "弃牌堆,共 {{n}} 张",
			riverEmpty: "河道空空,先抽一张牌",
			playerSeats: "本局玩家",
			seatActing: "当前行动",
			seatWaiting: "等待中",
			routeTitle: "掠夺航线",
			traitStageTitle: "船长契约",
			routeRisk: "{{n}} 种花色 · {{points}} 点在险",
			routeEmptyShort: "尚未翻牌",
			routeRule: "新花色留在航线 · 重复花色立即爆掉",
			deckLabel: "抽牌堆",
			riverLabel: "当前牌河",
			discardLabel: "弃牌堆",
			myBank: "你的战利品",
			otherBank: "{{name}}的战利品",
			scoreShort: "{{n}} 分",
			emptyMyBank: "收手后在对应花色积累战利品",
			emptyOtherBank: "对手的公开战利品也会显示在这里",
			targetCannon: "可轰击",
			targetHook: "可钩回",
			targetSword: "可偷取",
			cannonActionTitle: "大炮开火",
			hookActionTitle: "钩回战利品",
			swordActionTitle: "佩剑偷取",
			mapActionTitle: "按图寻宝",
			safeCard: "防爆",
			finalTitle: "藏宝结算",
			finalSubtitle: "每种花色只计栈顶最高的一张",
			finalCards: "{{n}} 张战利品",
			finalEmpty: "没有收入战利品",
			bankAria: "{{name}} 的银行",
			stackAria: "{{suit}},栈顶 {{value}},共 {{n}} 张",
			targetAria: "选择 {{name}} 的 {{suit}}",
			pickCardAria: "选择 {{suit}} {{value}}",
			scoreAria: "当前得分 {{n}}",
			drawAria: "从抽牌堆抽一张牌",
			collectAria: "收手,把河道收进银行",
			plunderCount: "银行内 {{n}} 张",
			bustText: "爆掉了!河道全弃",
			bustKeptText: "爆掉!保住 {{n}} 张,其余全弃",
			collectText: "收手进银行 {{n}} 张",
			collectBonusText: "收手 {{count}} 张,钥匙+宝箱再搬 {{bonus}} 张",
			cannonText: "轰掉了 {{target}} 的 {{suit}} ×{{n}}",
			cannonTakenText: "轰走并抢下 {{target}} 的 {{suit}}",
			stealText: "偷走了 {{target}} 的 {{suit}} {{value}}",
			hookedText: "钩回 {{suit}} {{value}}",
			mappedText: "从弃牌堆翻出 {{suit}} {{value}}",
			plunderedText: "从 {{target}} 银行里抢走 {{n}} 张",
			fizzleText: "{{suit}} 放空,无效果",
			logAria: "对局日志",
			logEmpty: "还没有事件",
			logDraw: "{{name}} 翻出 {{suit}} {{value}}",
			logBust: "{{name}} 爆掉了!河道全弃",
			logBustKept: "{{name}} 爆掉!保住 {{n}} 张,其余全弃",
			logCollect: "{{name}} 收手进银行 {{n}} 张",
			logCollectBonus: "{{name}} 收手 {{count}} 张,钥匙+宝箱再搬 {{bonus}} 张",
			logCannon: "{{name}} 轰掉了 {{target}} 的 {{suit}} ×{{n}}",
			logCannonTaken: "{{name}} 轰走并抢下 {{target}} 的 {{suit}}",
			logSteal: "{{name}} 偷走了 {{target}} 的 {{suit}} {{value}}",
			logHooked: "{{name}} 钩回 {{suit}} {{value}}",
			logMapped: "{{name}} 从弃牌堆翻出 {{suit}} {{value}}",
			logPlundered: "{{name}} 从 {{target}} 银行里抢走 {{n}} 张",
			logFizzle: "{{name}} 的 {{suit}} 放空,无效果",
			suitAnchor: "船锚",
			suitCannon: "大炮",
			suitChest: "宝箱",
			suitHook: "钩子",
			suitKey: "钥匙",
			suitKraken: "海怪",
			suitMap: "藏宝图",
			suitMermaid: "美人鱼",
			suitOracle: "预言",
			suitSword: "佩剑",
			suitDesc: {
				anchor: "如果本回合翻出重复花色而失败，在船锚之前进入河道的卡牌仍会存入你的银行，不会进入弃牌堆。",
				cannon: "选择一名对手银行中的一个花色牌叠，弃置其最上方的一张牌。",
				chest: "宝箱没有独立能力；与钥匙在同一回合存入银行时，触发下方所述的组合效果。",
				hook: "选择自己银行中的一个花色牌叠，将其最上方的一张牌移入河道。",
				key: "钥匙没有独立能力；与宝箱在同一回合存入银行时，触发下方所述的组合效果。",
				kraken: "必须再使2张牌进入河道，之后才可以收手。",
				map: "从弃牌堆随机抽取3张牌并展示，选择其中1张移入河道；弃牌不足3张时，展示全部剩余弃牌。",
				mermaid: "美人鱼没有特殊能力，其牌面数值为4至9，高于其他花色的数值范围。",
				oracle: "查看牌堆最上方的一张牌，再决定是否将其翻开并移入河道。",
				sword: "选择一名对手银行中的一个花色牌叠，将其最上方的一张牌移入河道；不能选择自己银行中已有的花色。"
			},
			guideCombo: "在同一回合收手时，如果存入银行的牌同时包含钥匙和宝箱，则从弃牌堆随机额外取得与本次存入银行的牌数相同的牌，存入你的银行；弃牌不足时，取得全部剩余弃牌。",
			traitGoldenScales: "黄金天秤",
			traitGoldenScalesDesc: "美人鱼花色额外 +5 分",
			traitCasanova: "情圣",
			traitCasanovaDesc: "你抽到的美人鱼直接进银行,不占用海怪强制补翻的张数",
			traitPlunderer: "掠夺者",
			traitPlundererDesc: "钥匙+宝箱的奖励改为从一名对手库中随机抢",
			traitTreasureHunter: "寻宝猎人",
			traitTreasureHunterDesc: "钥匙+宝箱的奖励翻倍",
			traitNavigator: "航海家",
			traitNavigatorDesc: "藏宝图改为从整个弃牌堆任选一张",
			traitMasterGunner: "炮术大师",
			traitMasterGunnerDesc: "你的大炮轰掉整叠而非栈顶",
			traitScavenger: "拾荒者",
			traitScavengerDesc: "你的大炮轰掉的牌进自己的银行",
			traitMystic: "秘术师",
			traitMysticDesc: "预言改看接下来 3 张",
			traitSwordsman: "剑术大师",
			traitSwordsmanDesc: "你的佩剑可偷自己已有的花色",
			traitMiser: "守财奴",
			traitMiserDesc: "你的钩子与钩回的牌防爆",
			traitCaptainHook: "铁钩船长",
			traitCaptainHookDesc: "你的钩子必须连钩 2 张",
			traitSafeHarbor: "安全港",
			traitSafeHarborDesc: "你的船锚与其后 2 张都防爆",
			traitFisherman: "渔夫",
			traitFishermanDesc: "你抽到的海怪直接进银行,不触发补牌",
			traitBeastmaster: "驯兽师",
			traitBeastmasterDesc: "对手抽中海怪须补 4 张",
			traitMisfire: "哑火",
			traitMisfireDesc: "对手的大炮只能轰他们自己的银行",
			traitParry: "格挡",
			traitParryDesc: "对手的佩剑只能偷海怪,偷不到就弃掉",
			traitJonesLocker: "深海魔柜",
			traitJonesLockerDesc: "指定一名对手:他爆掉的牌归你",
			errBadTarget: "这个目标选不了",
			errBadPhase: "现在不能这么做",
			errKraken: "海怪缠身,还不能收手",
			errDeckEmpty: "抽牌堆已空",
			hintPickTrait: "选特性「{{trait}}」",
			hintPickJones: "指定一名对手盯防",
			hintCannon: "轰掉对手的 {{suit}} 栈",
			hintCannonSelf: "哑火:弃掉自己的 {{suit}} 栈",
			hintHook: "钩回自己的 {{suit}} 栈顶",
			hintSword: "偷对手的 {{suit}} 栈顶",
			hintPlunder: "从对手银行里抢 {{n}} 张"
		},
		en: {
			name: "Dead Man's Draw",
			desc: "Pirate push-your-luck: flip loot, chain suit powers, bank before you bust",
			rules: "Objective:\nWhen the draw pile is empty, finish the current turn and calculate the value of the cards in each player's bank. The player with the highest total score wins.\n\nSetup:\n· The game contains 60 cards in 10 suits, with 6 cards in each suit. Mermaid cards have values from 4 to 9; cards in every other suit have values from 2 to 7.\n· Place the lowest card of each suit face-up in the discard pile. Shuffle the remaining cards to form the draw pile.\n· Each player chooses one of the two trait cards dealt to them. Their chosen trait remains in effect throughout the game.\n\nTaking a turn:\nOn your turn, reveal cards from the top of the draw pile one at a time and place them in the river, the shared play area for the current turn. Resolve each card according to its suit:\n· If its suit is not already present in the river, immediately resolve that suit's power. The reference below explains each power.\n· If its suit is already present in the river, you bust and your turn ends. Discard the cards in the river, except that an Anchor protects cards that entered the river before it, allowing those cards to be added to your bank.\n· If no power requires you to continue revealing cards, you may choose to stop. Add all cards in the river to your bank and end your turn.\n\nFinal scoring:\n· For each suit, score only the highest-value card of that suit in your bank. Add the values of those cards to obtain your total score.\n· If players have equal scores, the tied player with more cards in their bank wins. If the number of cards is also equal, those players share the victory.",
			pickTrait: "Pick one trait — it lasts all game",
			pickTraitWaiting: "{{n}} still picking…",
			jonesYou: "Davy Jones' Locker: choose who to watch",
			jonesWait: "Waiting for {{name}} to choose a target…",
			done: "Game over",
			turnYou: "Your turn: draw, or bank it?",
			turnOther: "{{name}}'s turn…",
			draw: "Draw",
			collect: "Bank",
			collectN: "Bank ({{n}})",
			krakenHint: "Kraken! No banking yet",
			krakenLeft: "Need {{n}} more into the river",
			busting: "Bust! The river is about to be swept away…",
			cardInFlight: "Card in flight…",
			cannonHint: "Cannon! Tap an opponent's stack to blast",
			cannonSelfHint: "Misfire! Discard one of your own stacks",
			hookHint: "Hook! Pull one of your stacks back",
			swordHint: "Sword! Steal an opponent's stack top",
			mapHint: "Map: pick one of three (must pick)",
			navMapHint: "Navigator: pick any card from the discard",
			oracleHint: "Oracle: peek, then decide",
			plunderHint: "Plunderer: steal {{n}} cards from one opponent",
			tapTarget: "Tap a highlighted stack above",
			deckShort: "{{n}} left",
			deckAria: "Draw pile, {{n}} left",
			discardAria: "Discard pile, {{n}} cards",
			riverEmpty: "River is empty — draw a card",
			playerSeats: "Players",
			seatActing: "Taking a turn",
			seatWaiting: "Waiting",
			routeTitle: "Loot Route",
			traitStageTitle: "Captain's Contract",
			routeRisk: "{{n}} suits · {{points}} at risk",
			routeEmptyShort: "No cards drawn",
			routeRule: "New suits stay · a repeated suit busts",
			deckLabel: "Draw pile",
			riverLabel: "Current play area",
			discardLabel: "Discard",
			myBank: "Your loot",
			otherBank: "{{name}}'s loot",
			scoreShort: "{{n}} pts",
			emptyMyBank: "Banked suits will collect here",
			emptyOtherBank: "Public loot will appear here",
			targetCannon: "Blast",
			targetHook: "Hook",
			targetSword: "Steal",
			cannonActionTitle: "Fire the cannon",
			hookActionTitle: "Hook back loot",
			swordActionTitle: "Steal with the sword",
			mapActionTitle: "Follow the map",
			safeCard: "Bust-proof",
			finalTitle: "Loot Reckoning",
			finalSubtitle: "Only the top card of each suit scores",
			finalCards: "{{n}} loot cards",
			finalEmpty: "No loot banked",
			bankAria: "{{name}}'s bank",
			stackAria: "{{suit}}, top {{value}}, {{n}} cards",
			targetAria: "Target {{name}}'s {{suit}}",
			pickCardAria: "Pick {{suit}} {{value}}",
			scoreAria: "Current score {{n}}",
			drawAria: "Draw a card from the deck",
			collectAria: "Bank everything in the river",
			plunderCount: "{{n}} in bank",
			bustText: "Bust! The river is lost",
			bustKeptText: "Bust! {{n}} saved, the rest is lost",
			collectText: "Banked {{n}} cards",
			collectBonusText: "Banked {{count}} — Key+Chest hauls {{bonus}} more",
			cannonText: "Blasted {{target}}'s {{suit}} ×{{n}}",
			cannonTakenText: "Blasted and grabbed {{target}}'s {{suit}}",
			stealText: "Stole {{target}}'s {{suit}} {{value}}",
			hookedText: "Hooked back {{suit}} {{value}}",
			mappedText: "Mapped {{suit}} {{value}} from the discard",
			plunderedText: "Plundered {{n}} cards from {{target}}",
			fizzleText: "{{suit}} fizzles — no effect",
			logAria: "Game log",
			logEmpty: "Nothing yet",
			logDraw: "{{name}} flipped {{suit}} {{value}}",
			logBust: "{{name}} busted! The river is lost",
			logBustKept: "{{name}} busted! {{n}} saved, the rest is lost",
			logCollect: "{{name}} banked {{n}} cards",
			logCollectBonus: "{{name}} banked {{count}} — Key+Chest hauls {{bonus}} more",
			logCannon: "{{name}} blasted {{target}}'s {{suit}} ×{{n}}",
			logCannonTaken: "{{name}} blasted and grabbed {{target}}'s {{suit}}",
			logSteal: "{{name}} stole {{target}}'s {{suit}} {{value}}",
			logHooked: "{{name}} hooked back {{suit}} {{value}}",
			logMapped: "{{name}} mapped {{suit}} {{value}} from the discard",
			logPlundered: "{{name}} plundered {{n}} cards from {{target}}",
			logFizzle: "{{name}}'s {{suit}} fizzles — no effect",
			suitAnchor: "Anchor",
			suitCannon: "Cannon",
			suitChest: "Chest",
			suitHook: "Hook",
			suitKey: "Key",
			suitKraken: "Kraken",
			suitMap: "Map",
			suitMermaid: "Mermaid",
			suitOracle: "Oracle",
			suitSword: "Sword",
			suitDesc: {
				anchor: "If you bust this turn, the cards that entered the river before the Anchor are still added to your bank instead of the discard pile.",
				cannon: "Choose a suit stack in an opponent’s bank and discard its top card.",
				chest: "The Chest has no independent power. Banking it with a Key in the same turn activates the combination explained below.",
				hook: "Pull the top card of one of your own bank stacks into the river.",
				key: "The Key has no independent power. Banking it with a Chest in the same turn activates the combination explained below.",
				kraken: "Two more cards must enter the river before you may bank.",
				map: "Reveal 3 random cards from the discard pile and move 1 of them into the river. If fewer than 3 cards remain, reveal all remaining cards.",
				mermaid: "The Mermaid has no special power. Its printed values range from 4 to 9, higher than the values in any other suit.",
				oracle: "Peek at the top card of the deck before deciding whether to flip it.",
				sword: "Choose a suit stack in an opponent’s bank and move its top card into the river. You cannot choose a suit already present in your own bank."
			},
			guideCombo: "If you bank a Key and a Chest in the same turn, take additional cards at random from the discard pile equal to the number of cards you have just banked, and add them to your bank. If fewer cards remain, take all remaining cards.",
			traitGoldenScales: "Golden Scales",
			traitGoldenScalesDesc: "Mermaids score +5",
			traitCasanova: "Casanova",
			traitCasanovaDesc: "Mermaids you draw go straight to your bank, without counting toward the Kraken's forced extra draws",
			traitPlunderer: "Plunderer",
			traitPlundererDesc: "Key+Chest bonus is stolen at random from one opponent's bank",
			traitTreasureHunter: "Treasure Hunter",
			traitTreasureHunterDesc: "Key+Chest bonus is doubled",
			traitNavigator: "Navigator",
			traitNavigatorDesc: "Map: pick any card from the whole discard pile",
			traitMasterGunner: "Master Gunner",
			traitMasterGunnerDesc: "Your Cannon discards the whole stack",
			traitScavenger: "Scavenger",
			traitScavengerDesc: "Cards your Cannon discards go to your bank",
			traitMystic: "Mystic",
			traitMysticDesc: "Oracle reveals the next 3 cards",
			traitSwordsman: "Swordsman",
			traitSwordsmanDesc: "Your Sword may steal suits you already banked",
			traitMiser: "Miser",
			traitMiserDesc: "Your Hook and the card it pulls are bust-proof",
			traitCaptainHook: "Captain's Hook",
			traitCaptainHookDesc: "Your Hook must pull two cards",
			traitSafeHarbor: "Safe Harbor",
			traitSafeHarborDesc: "Your Anchor and the next two cards are bust-proof",
			traitFisherman: "Fisherman",
			traitFishermanDesc: "Krakens you draw go straight to your bank",
			traitBeastmaster: "Beastmaster",
			traitBeastmasterDesc: "Opponents add 4 cards for a Kraken",
			traitMisfire: "Misfire",
			traitMisfireDesc: "Opponents' Cannons hit their own bank",
			traitParry: "Parry",
			traitParryDesc: "Opponents' Swords can only steal a Kraken, else fizzle",
			traitJonesLocker: "Davy Jones' Locker",
			traitJonesLockerDesc: "Pick one opponent: their busted cards go to you",
			errBadTarget: "Invalid target",
			errBadPhase: "Not right now",
			errKraken: "The Kraken won't let you bank yet",
			errDeckEmpty: "The deck is empty",
			hintPickTrait: "Pick trait {{trait}}",
			hintPickJones: "Mark a rival with the Locker",
			hintCannon: "Blast a rival's {{suit}} stack",
			hintCannonSelf: "Misfire: discard your own {{suit}} stack",
			hintHook: "Hook back your {{suit}} top card",
			hintSword: "Steal a rival's {{suit}} top card",
			hintPlunder: "Plunder {{n}} cards from a rival"
		}
	}
};
//#endregion
export { at as default };
