import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useT as r } from "@bgparty/sdk/i18n";
import { PhaseBanner as i } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as a } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { GameOverScreen as u } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as d, OptionSection as f } from "@bgparty/sdk/ui/game-options";
//#region src/games/growingseason/cards.ts
var p = (e, t, n, r, i, a) => ({
	id: e,
	icon: t,
	track: n,
	sickle: r,
	price: i,
	count: a
}), m = [
	p("carrot", "🥕", [null, null], 5, 2, 4),
	p("grape", "🍇", [1, 1], 2, 2, 4),
	p("tomato", "🍅", [
		null,
		2,
		2
	], 2, 2, 4),
	p("watermelon", "🍉", [
		null,
		null,
		null,
		null
	], 7, 2, 3),
	p("beet", "", [null], 2, 1, 4),
	p("banana", "🍌", [
		null,
		null,
		3,
		3
	], 3, 2, 2),
	p("pineapple", "🍍", [
		null,
		null,
		1,
		2
	], 5, 2, 3),
	p("pepper", "🌶️", [
		null,
		null,
		null,
		null
	], 9, 3, 3),
	p("potato", "🥔", [
		null,
		null,
		4,
		null
	], 4, 3, 3),
	p("daikon", "", [null, null], 4, 2, 4),
	p("melon", "🍈", [
		null,
		null,
		null
	], 7, 2, 4),
	p("apple", "🍎", [null, 1], 3, 1, 4),
	p("mango", "🥭", [
		null,
		null,
		null,
		null
	], 10, 3, 2),
	p("corn", "🌽", [
		null,
		2,
		2,
		2
	], 2, 3, 3),
	p("lemon", "🍋", [
		null,
		2,
		null,
		2,
		null
	], 6, 3, 2),
	p("cabbage", "🥬", [
		null,
		null,
		2
	], 4, 1, 4),
	p("peas", "🫛", [2], 2, 2, 4),
	p("strawberry", "🍓", [null, 2], 2, 2, 4),
	p("cauliflower", "", [
		null,
		null,
		null
	], 6, 2, 4),
	p("pumpkin", "🎃", [
		null,
		null,
		null,
		null
	], 8, 2, 2),
	p("coffee", "🫘", [
		1,
		1,
		2,
		4,
		2
	], 2, 4, 1),
	p("broccoli", "🥦", [null], 5, 3, 3),
	p("eggplant", "🍆", [
		null,
		3,
		null
	], 3, 2, 4),
	p("garlic", "🧄", [null], 3, 1, 4)
], h = {
	id: "wheat2",
	icon: "🌾",
	track: [null],
	sickle: 2,
	price: 0
}, g = {
	id: "wheat3",
	icon: "🌾",
	track: [null],
	sickle: 3,
	price: 0
}, _ = /* @__PURE__ */ new Map();
for (let e of m) _.set(e.id, e);
_.set(h.id, h), _.set(g.id, g);
function v(e) {
	let t = _.get(e);
	if (!t) throw Error(`unknown crop ${e}`);
	return t;
}
var y = (e) => v(e).track.length + 1, b = (e) => v(e).track.length + 1, x = (e, t, n, r, i, a = !1) => ({
	id: e,
	water: t,
	harvest: n,
	fish: r,
	price: i,
	adv: a
}), S = x("w1", 1, 0, .5, null), C = x("h1", 0, 1, .5, null), w = [
	[x("w5f3", 5, 0, 3, 3), 3],
	[x("w3f2", 3, 0, 2, 2), 4],
	[x("w3f1", 3, 0, 1, 2), 1],
	[x("w2f1", 2, 0, 1, 1), 7],
	[x("w2f2", 2, 0, 2, 1), 1],
	[x("h2f2", 0, 2, 2, 1), 3],
	[x("h2f3", 0, 2, 3, 1), 1]
], T = [
	[x("myth2", 1, 1, 2, 1, !0), 2],
	[x("myth1", 1, 1, 1, 1, !0), 4],
	[x("irid3", 2, 2, 3, 2, !0), 3],
	[x("irid2", 2, 2, 2, 2, !0), 1]
], E = /* @__PURE__ */ new Map();
for (let e of [S, C]) E.set(e.id, e);
for (let [e] of [...w, ...T]) E.set(e.id, e);
function D(e) {
	let t = E.get(e);
	if (!t) throw Error(`unknown tool ${e}`);
	return t;
}
var O = [
	1,
	1,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0
], k = [
	{
		v: 8,
		f: 5
	},
	{
		v: 5,
		f: 4
	},
	{
		v: 3,
		f: 3
	},
	{
		v: 3,
		f: 3
	},
	{
		v: 3,
		f: 3
	},
	{
		v: 2,
		f: 3
	},
	{
		v: 2,
		f: 2
	},
	{
		v: 2,
		f: 2
	},
	{
		v: 2,
		f: 1
	},
	{
		v: 2,
		f: 1
	},
	{
		v: 1,
		f: 2
	},
	{
		v: 1,
		f: 2
	},
	{
		v: 1,
		f: 1
	},
	{
		v: 1,
		f: 1
	},
	{
		v: 1,
		f: 1
	},
	{
		v: 1,
		f: 1
	},
	{
		v: 1,
		f: 1
	},
	{
		v: 1,
		f: 1
	},
	{
		v: 1,
		f: 1
	},
	{
		v: 1,
		f: 1
	}
], A = (e, t, n, r = {}) => ({
	id: e,
	icon: t,
	kind: n,
	...r
}), j = [
	[A("cow", "🐄", "animal", { cycle: [
		1,
		2,
		3
	] }), 1],
	[A("sheep", "🐑", "animal", { cycle: [1, 3] }), 1],
	[A("hen", "🐔", "animal", { cycle: [2] }), 1],
	[A("pig", "🐷", "animal", { cycle: [0, 4] }), 1],
	[A("plot23", "🟫", "plot", {
		plotTier: "23",
		bonus: 2
	}), 2],
	[A("plot4", "🟫", "plot", {
		plotTier: "4",
		bonus: 3
	}), 1],
	[A("plot56", "🟫", "plot", {
		plotTier: "56",
		bonus: 4
	}), 1],
	[A("sprinkler", "💦", "sprinkler"), 2],
	[A("harvester", "🚜", "harvester"), 1],
	[A("fertilizer", "💩", "fertilizer"), 1]
], M = /* @__PURE__ */ new Map();
for (let [e] of j) M.set(e.id, e);
function N(e) {
	let t = M.get(e);
	if (!t) throw Error(`unknown upgrade ${e}`);
	return t;
}
var P = /* @__PURE__ */ new Set(["sprinkler", "harvester"]), F = {
	standard: [
		"barn",
		"barn",
		"barn",
		"plain",
		"barn",
		"barn",
		"plain",
		"barn",
		"plain",
		"plain"
	],
	quick: [
		"barn",
		"barn",
		"barn",
		"barn",
		"barn",
		"barn",
		"plain",
		"plain",
		"plain",
		"plain"
	],
	long: [
		"tool",
		"barn",
		"tool",
		"barn",
		"barn",
		"barn",
		"barn",
		"plain",
		"barn",
		"barn",
		"barn",
		"plain",
		"plain",
		"plain",
		"plain"
	],
	asym: [
		"barn",
		"barn",
		"barn",
		"barn",
		"barn",
		"barn",
		"plain",
		"plain",
		"plain",
		"plain"
	]
}, I = {
	id: "growingseason",
	tier: "alpha",
	mechanics: ["deck-bag-building", "engine-building"],
	interactionTags: [],
	nameKey: "games.growingseason.name",
	descKey: "games.growingseason.desc",
	rulesKey: "games.growingseason.rules",
	icon: "🌾",
	iconImg: "games/growingseason.webp",
	rulesUrl: { es: "https://rules.bgparty.uuppi.com/growingseason/es.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#16a34a",
	releasedAt: "2026-09-16",
	search: {
		py: "feng shou ji jie",
		init: "fsjj"
	},
	hotseat: "cover"
}, L = t.object({
	deck: t.enum(["mine", "fish"]).catch("mine"),
	advancedTools: t.boolean().catch(!1),
	board: t.enum([
		"standard",
		"quick",
		"long"
	]).catch("standard"),
	asym: t.enum([
		"off",
		"first",
		"second"
	]).catch("off")
}).default({
	deck: "mine",
	advancedTools: !1,
	board: "standard",
	asym: "off"
}), R = t.int().nonnegative(), z = t.string(), ee = t.union([
	t.object({
		type: t.literal("water"),
		hand: R,
		plot: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("harvest"),
		hand: R,
		plot: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("discard"),
		cards: t.array(R).min(1)
	}),
	t.object({
		type: t.literal("mine"),
		cards: t.tuple([R, R])
	}),
	t.object({
		type: t.literal("fishStart"),
		cards: t.array(R).min(1)
	}),
	t.object({ type: t.literal("fishFlip") }),
	t.object({ type: t.literal("fishStop") }),
	t.object({
		type: t.literal("buyCrop"),
		slot: t.int().nonnegative(),
		plot: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("buyTool"),
		slot: t.int().nonnegative(),
		replace: R
	}),
	t.object({ type: t.literal("invest") }),
	t.object({
		type: t.literal("chooseUpgrade"),
		slot: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("draftPick"),
		keep: t.string(),
		drop: t.string()
	}),
	t.object({ type: t.literal("endTurn") })
]), te = t.object({
	u: R,
	d: t.string(),
	w: t.int().nonnegative()
}), B = t.object({
	u: R,
	d: t.string()
}), V = t.object({
	u: R,
	d: t.string(),
	wu: t.int().nonnegative(),
	hu: t.int().nonnegative()
}), ne = t.object({
	rid: z,
	coins: t.int().nonnegative(),
	boardPos: t.int().nonnegative(),
	board: t.array(t.enum([
		"barn",
		"plain",
		"tool"
	])),
	plots: t.array(te.nullable()),
	plotKinds: t.array(t.string()),
	upgrades: t.array(t.string()),
	animalPos: t.record(t.string(), t.int().nonnegative()),
	handCount: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	discardCount: t.int().nonnegative(),
	harvested: t.array(t.string())
}), re = t.object({
	phase: t.enum([
		"draft",
		"play",
		"done"
	]),
	turn: z.nullable(),
	cfg: t.object({
		deck: t.enum(["mine", "fish"]),
		advancedTools: t.boolean(),
		board: t.enum([
			"standard",
			"quick",
			"long"
		]),
		asym: t.enum([
			"off",
			"first",
			"second"
		])
	}),
	store: t.array(t.string().nullable()),
	cropDeckCount: t.int().nonnegative(),
	blacksmith: t.array(t.string().nullable()),
	upgradeDisplay: t.array(t.string().nullable()),
	upgradeDeckCount: t.int().nonnegative(),
	sideDeckCount: t.int().nonnegative(),
	fishing: t.object({
		remaining: t.number(),
		caught: t.array(t.number()),
		last: t.object({
			v: t.number(),
			f: t.number()
		}).nullable()
	}).nullable(),
	pendingUpgrade: t.boolean(),
	draftPicked: t.array(z).nullable(),
	players: t.array(ne)
}), ie = t.object({
	hand: t.array(V),
	discard: t.array(B),
	draftHand: t.array(t.string()).nullable()
}), H = {
	notYourTurn: { code: "games.growingseason.errNotYourTurn" },
	over: { code: "games.growingseason.errOver" },
	phase: { code: "games.growingseason.errPhase" },
	handNotEmpty: { code: "games.growingseason.errHandNotEmpty" },
	badCard: { code: "games.growingseason.errBadCard" },
	badPlot: { code: "games.growingseason.errBadPlot" },
	cantAfford: { code: "games.growingseason.errCantAfford" },
	noReplace: { code: "games.growingseason.errNoReplace" },
	badMine: { code: "games.growingseason.errBadMine" },
	badFish: { code: "games.growingseason.errBadFish" },
	badUpgrade: { code: "games.growingseason.errBadUpgrade" },
	badDraft: { code: "games.growingseason.errBadDraft" },
	fishing: { code: "games.growingseason.errFishing" }
};
function U(t, n) {
	for (let r = n.length - 1; r > 0; --r) {
		let i = e(t.seed, t.cursor, r + 1);
		t.cursor += 1, [n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function W(e, t) {
	return e.board === "standard" && (e.asym === "first" && t === 0 || e.asym === "second" && t === 1) ? F.asym : F[e.board];
}
function G() {
	return {
		deck: [],
		hand: [],
		discard: [],
		coins: 3,
		plots: Array.from({ length: 3 }, () => null),
		plotKinds: Array.from({ length: 3 }, () => "basic"),
		boardPos: 0,
		upgrades: [],
		animalPos: {},
		harvested: []
	};
}
function K(e) {
	let t = e.ps[e.players[e.turnIdx]];
	for (; t.hand.length < 5;) {
		if (t.deck.length === 0) {
			if (t.discard.length === 0) break;
			t.deck = U(e, t.discard), t.discard = [];
		}
		let n = t.deck.pop();
		t.hand.push({
			...n,
			wu: 0,
			hu: 0
		});
	}
	return ae(e);
}
function ae(e) {
	let t = e.players[e.turnIdx], n = e.ps[t], r = [];
	if (n.upgrades.includes("sprinkler")) {
		for (let e of n.plots) {
			if (!e || e.w >= b(e.d)) continue;
			e.w += 1;
			let i = v(e.d).track[e.w - 1];
			typeof i == "number" && (n.coins += i, r.push({
				kind: "gather",
				rid: t,
				data: {
					crop: e.d,
					amount: i,
					auto: 1
				}
			}));
		}
		r.push({
			kind: "sprinkler",
			rid: t,
			data: {}
		});
	}
	if (n.upgrades.includes("harvester")) for (let e = 0; e < n.plots.length; e += 1) {
		let i = n.plots[e];
		if (!i || i.w < b(i.d)) continue;
		let a = q(n, e, i.d);
		n.coins += a, n.harvested.push(i.d), n.plots[e] = null, r.push({
			kind: "harvest",
			rid: t,
			data: {
				crop: i.d,
				amount: a,
				auto: 1
			}
		});
	}
	for (let e of n.upgrades) {
		let i = N(e);
		if (i.kind !== "animal" || !i.cycle) continue;
		let a = e in n.animalPos ? (n.animalPos[e] + 1) % i.cycle.length : 0;
		n.animalPos[e] = a;
		let o = i.cycle[a];
		o > 0 && (n.coins += o, r.push({
			kind: "animal",
			rid: t,
			data: {
				upgrade: e,
				amount: o
			}
		}));
	}
	return r;
}
function q(e, t, n) {
	let r = v(n).sickle;
	e.upgrades.includes("fertilizer") && (r += 1);
	let i = e.plotKinds[t];
	if (i !== "basic") {
		let e = N(i), t = y(n);
		(e.plotTier === "23" && (t === 2 || t === 3) || e.plotTier === "4" && t === 4 || e.plotTier === "56" && t >= 5) && (r += e.bonus ?? 0);
	}
	return r;
}
function J(e, t) {
	let n = e.hand.findIndex((e) => e.u === t);
	if (n < 0) return;
	let r = e.hand[n], i = D(r.d);
	r.wu >= i.water && r.hu >= i.harvest && (e.hand.splice(n, 1), e.discard.push({
		u: r.u,
		d: r.d
	}));
}
function oe(e, t, n) {
	let r = e.ps[t], i = N(n);
	r.upgrades.push(n), i.kind === "plot" && (r.plots.push(null), r.plotKinds.push(n));
}
function se(e, t) {
	return !(P.has(t) && e.upgrades.includes(t));
}
function ce(e, t) {
	let n = D(e), r = D(t);
	return n.water > 0 && r.water > 0 || n.harvest > 0 && r.harvest > 0;
}
function le(t, n, r) {
	let i = {
		players: n,
		cfg: t,
		seed: r,
		cursor: 0,
		uidSeq: 1,
		turnIdx: 0,
		phase: "play",
		cropDeck: [],
		store: [],
		blacksmithDeck: [],
		blacksmith: [],
		upgradeDeck: [],
		upgradeDisplay: [],
		mineDeck: [],
		mineDiscard: [],
		fishDeck: [],
		fishDiscard: [],
		fishing: null,
		pendingUpgrade: !1,
		draft: null,
		winner: null,
		ps: {}
	};
	i.turnIdx = e(r, i.cursor, n.length), i.cursor += 1;
	for (let e of n) i.ps[e] = G();
	for (let [e, t] of n.entries()) {
		let n = i.ps[t];
		for (let e = 0; e < 10; e += 1) n.deck.push({
			u: i.uidSeq++,
			d: S.id
		});
		for (let e = 0; e < 5; e += 1) n.deck.push({
			u: i.uidSeq++,
			d: C.id
		});
		U(i, n.deck);
		let r = e === i.turnIdx ? h : g;
		n.plots[0] = {
			u: i.uidSeq++,
			d: r.id,
			w: 0
		};
	}
	if (i.cropDeck = U(i, m.flatMap((e) => Array.from({ length: e.count }, () => e.id))), i.store = Array.from({ length: 5 }, () => i.cropDeck.pop() ?? null), i.blacksmithDeck = U(i, [...t.advancedTools ? T : [], ...w].flatMap(([e, t]) => Array.from({ length: t }, () => e.id))), i.blacksmith = Array.from({ length: 3 }, () => i.blacksmithDeck.pop() ?? null), i.upgradeDeck = U(i, j.flatMap(([e, t]) => Array.from({ length: t }, () => e.id))), t.deck === "mine" ? i.mineDeck = U(i, [...O]) : i.fishDeck = U(i, [...k]), t.board === "quick") {
		i.phase = "draft", i.draft = {
			hands: {},
			kept: {},
			dropped: [],
			picked: []
		};
		for (let e of n) i.draft.hands[e] = i.upgradeDeck.splice(0, 6), i.draft.kept[e] = [];
	} else i.upgradeDisplay = Array.from({ length: 3 }, () => i.upgradeDeck.pop() ?? null);
	return {
		state: i,
		fx: t.board === "quick" ? [] : K(i)
	};
}
function ue(e, t, n) {
	if (e.phase === "done") return H.over;
	let r = n.by;
	if (e.phase === "draft") {
		if (t.type !== "draftPick" || !e.draft) return H.phase;
		let n = e.draft;
		if (!e.players.includes(r) || n.picked.includes(r)) return H.badDraft;
		let i = n.hands[r], a = i.indexOf(t.keep);
		if (a < 0 || !i.filter((e, t) => t !== a).includes(t.drop)) return H.badDraft;
		let o = structuredClone(e), s = o.draft, c = s.hands[r].indexOf(t.keep);
		if (s.hands[r].splice(c, 1), s.hands[r].splice(s.hands[r].indexOf(t.drop), 1), s.kept[r].push(t.keep), s.dropped.push(t.drop), s.picked.push(r), s.picked.length === o.players.length) {
			if (s.kept[r].length >= 3) {
				for (let e of o.players) for (let t of s.kept[e]) oe(o, e, t);
				return o.upgradeDeck = U(o, [...o.upgradeDeck, ...s.dropped]), o.upgradeDisplay = Array.from({ length: 3 }, () => o.upgradeDeck.pop() ?? null), o.draft = null, o.phase = "play", {
					state: o,
					fx: [{
						kind: "draft",
						data: {}
					}, ...K(o)]
				};
			}
			let [e, t] = o.players;
			[s.hands[e], s.hands[t]] = [s.hands[t], s.hands[e]], s.picked = [];
		}
		return {
			state: o,
			fx: []
		};
	}
	if (e.players[e.turnIdx] !== r) return H.notYourTurn;
	if (e.pendingUpgrade && t.type !== "chooseUpgrade") return H.phase;
	if (e.fishing && t.type !== "fishFlip" && t.type !== "fishStop") return H.fishing;
	let i = e.ps[r], a = W(e.cfg, e.turnIdx);
	switch (t.type) {
		case "water": {
			let n = i.hand.find((e) => e.u === t.hand), a = i.plots[t.plot];
			if (!n || !a) return H.badCard;
			let o = D(n.d);
			if (n.wu >= o.water || a.w >= b(a.d)) return H.badCard;
			let s = structuredClone(e), c = s.ps[r], l = c.plots[t.plot], u = c.hand.find((e) => e.u === t.hand);
			l.w += 1, u.wu += 1;
			let d = [{
				kind: "water",
				rid: r,
				data: { crop: l.d }
			}], f = v(l.d).track[l.w - 1];
			return typeof f == "number" && (c.coins += f, d.push({
				kind: "gather",
				rid: r,
				data: {
					crop: l.d,
					amount: f
				}
			})), J(c, u.u), {
				state: s,
				fx: d
			};
		}
		case "harvest": {
			let n = i.hand.find((e) => e.u === t.hand), a = i.plots[t.plot];
			if (!n || !a) return H.badCard;
			let o = D(n.d);
			if (n.hu >= o.harvest || a.w < b(a.d)) return H.badCard;
			let s = structuredClone(e), c = s.ps[r], l = q(c, t.plot, a.d);
			c.coins += l, c.harvested.push(a.d), c.plots[t.plot] = null;
			let u = c.hand.find((e) => e.u === t.hand);
			return u.hu += 1, J(c, u.u), {
				state: s,
				fx: [{
					kind: "harvest",
					rid: r,
					data: {
						crop: a.d,
						amount: l
					}
				}]
			};
		}
		case "discard": {
			if (t.cards.some((e) => !i.hand.some((t) => t.u === e))) return H.badCard;
			let n = structuredClone(e), a = n.ps[r];
			for (let e of t.cards) {
				let t = a.hand.findIndex((t) => t.u === e), n = a.hand[t];
				a.hand.splice(t, 1), a.discard.push({
					u: n.u,
					d: n.d
				});
			}
			return {
				state: n,
				fx: []
			};
		}
		case "mine": {
			if (e.cfg.deck !== "mine") return H.badMine;
			let [n, a] = t.cards, o = i.hand.find((e) => e.u === n), s = i.hand.find((e) => e.u === a);
			if (n === a || !o || !s || o.wu + o.hu > 0 || s.wu + s.hu > 0) return H.badMine;
			let c = structuredClone(e), l = c.ps[r];
			for (let e of [n, a]) {
				let t = l.hand.findIndex((t) => t.u === e), n = l.hand[t];
				l.hand.splice(t, 1), l.discard.push({
					u: n.u,
					d: n.d
				});
			}
			c.mineDeck.length === 0 && (c.mineDeck = U(c, c.mineDiscard), c.mineDiscard = []);
			let u = c.mineDeck.pop();
			return c.mineDiscard.push(u), l.coins += u, {
				state: c,
				fx: [{
					kind: "mine",
					rid: r,
					data: { amount: u }
				}]
			};
		}
		case "fishStart": {
			if (e.cfg.deck !== "fish" || e.fishing || t.cards.some((e) => {
				let t = i.hand.find((t) => t.u === e);
				return !t || t.wu + t.hu > 0;
			}) || new Set(t.cards).size !== t.cards.length) return H.badFish;
			let n = structuredClone(e), a = n.ps[r], o = 0;
			for (let e of t.cards) {
				let t = a.hand.findIndex((t) => t.u === e), n = a.hand[t];
				o += D(n.d).fish, a.hand.splice(t, 1), a.discard.push({
					u: n.u,
					d: n.d
				});
			}
			return n.fishing = {
				remaining: o,
				caught: [],
				last: null
			}, {
				state: n,
				fx: [{
					kind: "fishStart",
					rid: r,
					data: { value: o }
				}]
			};
		}
		case "fishFlip": {
			if (!e.fishing) return H.badFish;
			let t = structuredClone(e);
			t.fishDeck.length === 0 && (t.fishDeck = U(t, t.fishDiscard), t.fishDiscard = []);
			let n = t.fishDeck.pop();
			t.fishDiscard.push(n);
			let i = t.fishing, a = [];
			if (n.f < i.remaining) i.remaining -= n.f, i.caught.push(n.v), i.last = n, a.push({
				kind: "fishCatch",
				rid: r,
				data: {
					v: n.v,
					f: n.f,
					remaining: i.remaining
				}
			});
			else {
				i.caught.pop();
				let e = i.caught.reduce((e, t) => e + t, 0);
				t.ps[r].coins += e, t.fishing = null, a.push({
					kind: "fishBust",
					rid: r,
					data: {
						f: n.f,
						gain: e
					}
				});
			}
			return {
				state: t,
				fx: a
			};
		}
		case "fishStop": {
			if (!e.fishing) return H.badFish;
			let t = structuredClone(e), n = t.fishing.caught.reduce((e, t) => e + t, 0);
			return t.ps[r].coins += n, t.fishing = null, {
				state: t,
				fx: [{
					kind: "fishStop",
					rid: r,
					data: { gain: n }
				}]
			};
		}
		case "buyCrop": {
			if (i.hand.length > 0) return H.handNotEmpty;
			let n = e.store[t.slot];
			if (n == null) return H.badCard;
			if (t.plot >= i.plots.length || i.plots[t.plot] !== null) return H.badPlot;
			let a = v(n).price;
			if (i.coins < a) return H.cantAfford;
			let o = structuredClone(e);
			return o.ps[r].coins -= a, o.ps[r].plots[t.plot] = {
				u: o.uidSeq++,
				d: n,
				w: 0
			}, o.store[t.slot] = null, {
				state: o,
				fx: [{
					kind: "plant",
					rid: r,
					data: {
						crop: n,
						slot: t.slot
					}
				}]
			};
		}
		case "buyTool": {
			if (i.hand.length > 0) return H.handNotEmpty;
			let n = e.blacksmith[t.slot];
			if (n == null) return H.badCard;
			let a = D(n);
			if (a.price == null || i.coins < a.price) return H.cantAfford;
			let o = i.discard.findIndex((e) => e.u === t.replace);
			if (o < 0 || !ce(n, i.discard[o].d)) return H.noReplace;
			let s = structuredClone(e), c = s.ps[r];
			return c.coins -= a.price, c.discard.splice(c.discard.findIndex((e) => e.u === t.replace), 1), c.discard.push({
				u: s.uidSeq++,
				d: n
			}), s.blacksmith[t.slot] = null, {
				state: s,
				fx: [{
					kind: "buyTool",
					rid: r,
					data: {
						tool: n,
						slot: t.slot
					}
				}]
			};
		}
		case "invest": {
			if (i.hand.length > 0) return H.handNotEmpty;
			if (i.coins < 10) return H.cantAfford;
			if (i.boardPos >= a.length) return H.phase;
			let t = structuredClone(e), n = t.ps[r];
			n.coins -= 10, n.boardPos += 1;
			let o = a[n.boardPos - 1], s = [{
				kind: "invest",
				rid: r,
				data: {
					pos: n.boardPos,
					square: o
				}
			}];
			if (o === "barn") t.upgradeDisplay.some((e) => e != null && se(n, e)) && (t.pendingUpgrade = !0);
			else if (o === "tool") for (let e = 0; e < t.blacksmith.length; e += 1) {
				let i = t.blacksmith[e];
				if (i == null) continue;
				let a = n.discard.filter((e) => ce(i, e.d));
				a.length !== 0 && (a.sort((e, t) => {
					let n = D(e.d), r = D(t.d);
					return n.water + n.harvest - (r.water + r.harvest) || n.fish - r.fish;
				}), n.discard.splice(n.discard.findIndex((e) => e.u === a[0].u), 1), n.discard.push({
					u: t.uidSeq++,
					d: i
				}), t.blacksmith[e] = null, s.push({
					kind: "buyTool",
					rid: r,
					data: {
						tool: i,
						slot: e,
						free: 1
					}
				}));
			}
			return n.boardPos >= a.length && (t.phase = "done", t.winner = r, s.push({
				kind: "win",
				rid: r,
				data: {}
			})), {
				state: t,
				fx: s
			};
		}
		case "chooseUpgrade": {
			if (!e.pendingUpgrade) return H.badUpgrade;
			let n = e.upgradeDisplay[t.slot];
			if (n == null || !se(i, n)) return H.badUpgrade;
			let a = structuredClone(e);
			return oe(a, r, n), a.upgradeDisplay[t.slot] = a.upgradeDeck.pop() ?? null, a.pendingUpgrade = !1, {
				state: a,
				fx: [{
					kind: "upgrade",
					rid: r,
					data: { upgrade: n }
				}]
			};
		}
		case "endTurn": {
			if (e.fishing) return H.fishing;
			let t = structuredClone(e), n = t.ps[r];
			for (let e of n.hand) n.discard.push({
				u: e.u,
				d: e.d
			});
			n.hand = [];
			for (let e = 0; e < t.store.length; e += 1) t.store[e] ?? (t.store[e] = t.cropDeck.pop() ?? null);
			for (let e = 0; e < t.blacksmith.length; e += 1) t.blacksmith[e] ?? (t.blacksmith[e] = t.blacksmithDeck.pop() ?? null);
			t.turnIdx = (t.turnIdx + 1) % t.players.length;
			let i = K(t);
			return {
				state: t,
				fx: [{
					kind: "endTurn",
					rid: r,
					data: {}
				}, ...i]
			};
		}
		default: return H.phase;
	}
}
function de(e, t) {
	let n = (t) => W(e.cfg, e.players.indexOf(t));
	return {
		public: {
			phase: e.phase,
			turn: e.phase === "play" ? e.players[e.turnIdx] : null,
			cfg: {
				deck: e.cfg.deck,
				advancedTools: e.cfg.advancedTools,
				board: e.cfg.board,
				asym: e.cfg.asym
			},
			store: [...e.store],
			cropDeckCount: e.cropDeck.length,
			blacksmith: [...e.blacksmith],
			upgradeDisplay: [...e.upgradeDisplay],
			upgradeDeckCount: e.upgradeDeck.length,
			sideDeckCount: e.cfg.deck === "mine" ? e.mineDeck.length : e.fishDeck.length,
			fishing: e.fishing ? {
				remaining: e.fishing.remaining,
				caught: [...e.fishing.caught],
				last: e.fishing.last ? { ...e.fishing.last } : null
			} : null,
			pendingUpgrade: e.pendingUpgrade,
			draftPicked: e.draft ? [...e.draft.picked] : null,
			players: e.players.map((t) => {
				let r = e.ps[t];
				return {
					rid: t,
					coins: r.coins,
					boardPos: r.boardPos,
					board: n(t),
					plots: r.plots.map((e) => e ? { ...e } : null),
					plotKinds: [...r.plotKinds],
					upgrades: [...r.upgrades],
					animalPos: { ...r.animalPos },
					handCount: r.hand.length,
					deckCount: r.deck.length,
					discardCount: r.discard.length,
					harvested: [...r.harvested]
				};
			})
		},
		private: {
			hand: e.ps[t]?.hand.map((e) => ({ ...e })) ?? [],
			discard: e.ps[t]?.discard.map((e) => ({ ...e })) ?? [],
			draftHand: e.draft?.hands[t] ? [...e.draft.hands[t]] : null
		}
	};
}
function fe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => {
		let r = e.ps[t], i = e.ps[n];
		return i.boardPos - r.boardPos || i.coins - r.coins;
	}), n = {};
	for (let t of e.players) n[t] = e.ps[t].boardPos;
	return {
		phase: "done",
		winner: e.winner ? [e.winner] : [t[0]],
		ranking: t,
		scores: n
	};
}
var pe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: I,
	schemas: {
		action: ee,
		publicView: re,
		privateView: ie,
		config: L
	},
	setup: le,
	reduce: ue,
	viewFor: de,
	status: fe
}, Y = {
	carrot: "games.growingseason.crop.carrot",
	grape: "games.growingseason.crop.grape",
	tomato: "games.growingseason.crop.tomato",
	watermelon: "games.growingseason.crop.watermelon",
	beet: "games.growingseason.crop.beet",
	banana: "games.growingseason.crop.banana",
	pineapple: "games.growingseason.crop.pineapple",
	pepper: "games.growingseason.crop.pepper",
	potato: "games.growingseason.crop.potato",
	daikon: "games.growingseason.crop.daikon",
	melon: "games.growingseason.crop.melon",
	apple: "games.growingseason.crop.apple",
	mango: "games.growingseason.crop.mango",
	corn: "games.growingseason.crop.corn",
	lemon: "games.growingseason.crop.lemon",
	cabbage: "games.growingseason.crop.cabbage",
	peas: "games.growingseason.crop.peas",
	strawberry: "games.growingseason.crop.strawberry",
	cauliflower: "games.growingseason.crop.cauliflower",
	pumpkin: "games.growingseason.crop.pumpkin",
	coffee: "games.growingseason.crop.coffee",
	broccoli: "games.growingseason.crop.broccoli",
	eggplant: "games.growingseason.crop.eggplant",
	garlic: "games.growingseason.crop.garlic",
	wheat2: "games.growingseason.crop.wheat",
	wheat3: "games.growingseason.crop.wheat"
}, X = {
	cow: "games.growingseason.up.cow",
	sheep: "games.growingseason.up.sheep",
	hen: "games.growingseason.up.hen",
	pig: "games.growingseason.up.pig",
	plot23: "games.growingseason.up.plot23",
	plot4: "games.growingseason.up.plot4",
	plot56: "games.growingseason.up.plot56",
	sprinkler: "games.growingseason.up.sprinkler",
	harvester: "games.growingseason.up.harvester",
	fertilizer: "games.growingseason.up.fertilizer"
}, me = {
	cow: "games.growingseason.upDesc.cow",
	sheep: "games.growingseason.upDesc.sheep",
	hen: "games.growingseason.upDesc.hen",
	pig: "games.growingseason.upDesc.pig",
	plot23: "games.growingseason.upDesc.plot23",
	plot4: "games.growingseason.upDesc.plot4",
	plot56: "games.growingseason.upDesc.plot56",
	sprinkler: "games.growingseason.upDesc.sprinkler",
	harvester: "games.growingseason.upDesc.harvester",
	fertilizer: "games.growingseason.upDesc.fertilizer"
}, he = {
	barn: "🛖",
	plain: "",
	tool: "🔧"
};
function ge(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ c(xe, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function _e({ defId: e, wu: t, hu: n, selected: r, disabled: i, dimmed: a, onClick: o }) {
	let s = D(e);
	return /* @__PURE__ */ l("button", {
		type: "button",
		onClick: o,
		disabled: i,
		className: `gs-tool-card flex min-h-11 flex-none cursor-pointer flex-col items-center justify-center ${a ? "opacity-40" : ""}`,
		style: r ? {
			borderColor: I.accent,
			boxShadow: `3px 3px 0 ${I.accent}`
		} : void 0,
		children: [
			s.water > 0 && /* @__PURE__ */ l("span", {
				className: "gs-tool-value font-mono font-extrabold tabular-nums",
				children: [
					"💧",
					s.water - t,
					"/",
					s.water
				]
			}),
			s.harvest > 0 && /* @__PURE__ */ l("span", {
				className: "gs-tool-value font-mono font-extrabold tabular-nums",
				children: [
					"🧺",
					s.harvest - n,
					"/",
					s.harvest
				]
			}),
			/* @__PURE__ */ l("span", {
				className: "gs-tool-detail font-mono tabular-nums opacity-70",
				children: ["🐟", s.fish]
			})
		]
	});
}
function ve({ defId: e, w: t, price: n, small: i, highlight: a, selected: o, onClick: u }) {
	let d = r(), f = v(e), p = t >= b(e), m = [];
	m.push(/* @__PURE__ */ c("span", {
		className: `gs-crop-step grid place-items-center rounded-full border font-mono font-extrabold tabular-nums ${p ? "border-ink bg-amber-300 text-ink" : "border-ink/40 bg-surface text-ink/70"}`,
		children: f.sickle
	}, "s"));
	for (let e = f.track.length - 1; e >= 0; --e) {
		let n = f.track[e], r = t >= e + 1;
		m.push(/* @__PURE__ */ c("span", {
			className: `gs-crop-step grid place-items-center rounded-full border font-mono tabular-nums ${r ? "border-ink bg-sky-300 text-ink" : "border-ink/40 bg-surface text-ink/60"}`,
			children: n ?? ""
		}, e));
	}
	let h = /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c("span", {
			className: "gs-crop-icon",
			"aria-hidden": !0,
			children: f.icon || "🌱"
		}),
		/* @__PURE__ */ c("span", {
			className: "gs-crop-track flex flex-col-reverse items-center",
			children: m
		}),
		n && /* @__PURE__ */ l("span", {
			className: "gs-crop-price font-mono font-extrabold tabular-nums",
			children: ["🪙", f.price]
		}),
		/* @__PURE__ */ c("span", {
			className: "sr-only",
			children: d(Y[e])
		})
	] }), g = `gs-crop-card flex ${i ? "gs-crop-small" : "gs-crop-full"} flex-none flex-col items-center border-2 ${a ? "border-ink bg-done-soft" : "border-ink/30 bg-surface"} ${o ? "ring-2 ring-ink" : ""}`;
	return u ? /* @__PURE__ */ c("button", {
		type: "button",
		onClick: u,
		className: `${g} cursor-pointer`,
		children: h
	}) : /* @__PURE__ */ c("span", {
		className: g,
		children: h
	});
}
function ye({ id: e, selected: t, mark: n, disabled: i, onClick: a }) {
	let o = r(), s = N(e);
	return /* @__PURE__ */ l("button", {
		type: "button",
		onClick: a,
		disabled: i,
		className: `gs-upgrade-card flex flex-none flex-col items-center border-2 ${n === "keep" ? "border-ink bg-done-soft" : n === "drop" ? "border-ink bg-rose-200" : "border-ink/30 bg-surface"} ${a ? "cursor-pointer" : ""} ${i ? "opacity-40" : ""}`,
		style: t ? { boxShadow: `3px 3px 0 ${I.accent}` } : void 0,
		children: [
			/* @__PURE__ */ c("span", {
				className: "gs-upgrade-icon",
				"aria-hidden": !0,
				children: s.icon
			}),
			/* @__PURE__ */ c("span", {
				className: "gs-upgrade-name text-center font-extrabold",
				children: o(X[e])
			}),
			/* @__PURE__ */ c("span", {
				className: "gs-upgrade-desc text-center text-ink/70",
				children: o(me[e])
			})
		]
	});
}
function be({ board: e, pos: t, canInvest: n, onInvest: r }) {
	return /* @__PURE__ */ c("div", {
		className: "gs-board-track flex items-center overflow-x-auto",
		children: e.map((e, i) => {
			let a = i < t;
			return i === t && r ? /* @__PURE__ */ c("button", {
				type: "button",
				onClick: r,
				disabled: !n,
				className: `gs-board-square grid flex-none cursor-pointer place-items-center rounded-lg border-2 border-ink font-mono font-extrabold tabular-nums ${n ? "bg-amber-300" : "bg-surface opacity-60"}`,
				children: "🪙"
			}, i) : /* @__PURE__ */ c("span", {
				className: `gs-board-square grid flex-none place-items-center rounded-lg border-2 ${a ? "border-ink bg-emerald-300" : "border-ink/30 bg-surface"}`,
				children: a ? "✓" : he[e]
			}, i);
		})
	});
}
function xe({ pub: e, priv: t, members: u, myRid: d, send: f }) {
	let p = r(), m = (e) => u.find((t) => t.rid === e)?.name ?? e, h = e.players.find((e) => e.rid === d), g = e.players.find((e) => e.rid !== d), _ = e.phase === "play" && e.turn === d, y = t?.hand ?? [], x = y.length === 0, [S, C] = n(null), [w, T] = n("idle"), [E, O] = n([]), [k, A] = n(null), [j, M] = n(null), [P, F] = n(null), [L, R] = n(null), z = `${e.phase}|${e.turn}|${e.pendingUpgrade}|${y.map((e) => `${e.u}:${e.wu}:${e.hu}`).join(".")}|${e.store.join(".")}|${e.blacksmith.join(".")}`, [ee, te] = n(z);
	ee !== z && (te(z), T("idle"), O([]), A(null), M(null), F(null), R(null), S != null && !y.some((e) => e.u === S) && C(null));
	let B = S == null ? void 0 : y.find((e) => e.u === S), V = B ? D(B.d) : null, ne = !!B && !!V && B.wu < V.water, re = !!B && !!V && B.hu < V.harvest, ie = y.filter((e) => e.wu + e.hu === 0).map((e) => e.u), H = _ && e.cfg.deck === "mine" && ie.length >= 2 && !e.pendingUpgrade, U = _ && e.cfg.deck === "fish" && ie.length >= 1 && !e.pendingUpgrade && !e.fishing, W = _ && x && !e.pendingUpgrade && !e.fishing, G = () => {
		T("idle"), O([]), A(null), M(null);
	}, K = (t) => {
		if (!_ || e.pendingUpgrade || e.fishing) return;
		let n = y.find((e) => e.u === t);
		if (n) {
			if (w !== "idle") {
				if (w !== "discard" && n.wu + n.hu > 0) return;
				O((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]);
				return;
			}
			A(null), M(null), C((e) => e === t ? null : t);
		}
	}, ae = (t) => {
		if (!_ || !h || e.pendingUpgrade || e.fishing) return;
		if (k != null) {
			h.plots[t] === null && (f({
				type: "buyCrop",
				slot: k,
				plot: t
			}), A(null));
			return;
		}
		let n = h.plots[t];
		if (!n || S == null || !B || !V) return;
		let r = n.w >= b(n.d);
		!r && ne ? f({
			type: "water",
			hand: S,
			plot: t
		}) : r && re && (f({
			type: "harvest",
			hand: S,
			plot: t
		}), C(null));
	}, q = (t) => {
		if (!W || !h) return;
		let n = e.store[t];
		if (n == null || h.coins < v(n).price) return;
		let r = h.plots.map((e, t) => e === null ? t : -1).filter((e) => e >= 0);
		if (r.length !== 0) {
			if (r.length === 1) {
				f({
					type: "buyCrop",
					slot: t,
					plot: r[0]
				});
				return;
			}
			M(null), A((e) => e === t ? null : t);
		}
	}, J = (t) => {
		if (!W || !h) return;
		let n = e.blacksmith[t];
		if (n == null) return;
		let r = D(n);
		r.price == null || h.coins < r.price || (A(null), M((e) => e === t ? null : t));
	}, oe = (e) => {
		j != null && (f({
			type: "buyTool",
			slot: j,
			replace: e
		}), M(null));
	}, se = () => {
		e.cfg.deck === "mine" ? E.length === 2 && f({
			type: "mine",
			cards: [E[0], E[1]]
		}) : E.length >= 1 && f({
			type: "fishStart",
			cards: E
		}), G();
	}, ce = () => {
		E.length >= 1 && f({
			type: "discard",
			cards: E
		}), G();
	};
	if (e.phase === "draft") {
		let n = t?.draftHand ?? [], r = e.draftPicked?.includes(d) ?? !1;
		return /* @__PURE__ */ c(o, {
			adaptive: !0,
			className: "gs-screen gs-draft-screen",
			scroll: !1,
			banner: /* @__PURE__ */ l("div", {
				className: "gs-header",
				children: [/* @__PURE__ */ c(i, {
					tone: "accent",
					accent: I.accent,
					text: p("games.growingseason.draftTitle"),
					sub: p(r ? "games.growingseason.draftWaiting" : "games.growingseason.draftHint")
				}), /* @__PURE__ */ c(a, {
					members: u,
					myRid: d,
					variant: "plate",
					action: (t) => e.draftPicked?.includes(t) ? "done" : "pending"
				})]
			}),
			actionsHeight: "gs-draft-actions-slot",
			actions: /* @__PURE__ */ c("button", {
				type: "button",
				className: "btn-base gs-draft-confirm",
				disabled: r || P == null || L == null,
				onClick: () => {
					P != null && L != null && f({
						type: "draftPick",
						keep: P,
						drop: L
					});
				},
				children: p("games.growingseason.draftConfirm")
			}),
			children: /* @__PURE__ */ c("div", {
				className: "frame gs-draft-card-grid",
				children: n.map((e) => /* @__PURE__ */ c(ye, {
					id: e,
					mark: P === e ? "keep" : L === e ? "drop" : null,
					disabled: r,
					onClick: () => {
						r || (P === e ? F(null) : L === e ? R(null) : P == null ? F(e) : L == null ? R(e) : F(e));
					}
				}, e))
			})
		});
	}
	let le = e.pendingUpgrade ? p("games.growingseason.upgradeTitle") : e.fishing ? p("games.growingseason.fishingTitle") : _ ? p("games.growingseason.yourTurn") : p("games.growingseason.waitTurn", { name: m(e.turn ?? "") }), ue = _ && !e.pendingUpgrade && !e.fishing ? p("games.growingseason.yourTurnSub") : void 0;
	return /* @__PURE__ */ c(o, {
		adaptive: !0,
		className: "gs-screen",
		scroll: !1,
		banner: /* @__PURE__ */ l("div", {
			className: "gs-header",
			children: [/* @__PURE__ */ c(i, {
				tone: _ ? "accent" : "info",
				accent: I.accent,
				text: le,
				sub: ue
			}), /* @__PURE__ */ c(a, {
				members: u,
				myRid: d,
				variant: "plate",
				action: (t) => e.turn === t ? "pending" : null,
				status: (t) => {
					let n = e.players.find((e) => e.rid === t);
					return n ? /* @__PURE__ */ l("span", {
						className: "gs-player-status flex items-center font-mono font-extrabold tabular-nums",
						children: [/* @__PURE__ */ l("span", { children: ["🪙", n.coins] }), /* @__PURE__ */ c("span", { children: p("games.growingseason.boardGoal", {
							pos: n.boardPos,
							n: n.board.length
						}) })]
					}) : null;
				}
			})]
		}),
		actionsHeight: "gs-actions-slot",
		actions: /* @__PURE__ */ l("div", {
			className: "gs-footer",
			children: [/* @__PURE__ */ l("div", {
				className: "gs-hand",
				children: [y.map((e) => {
					let t = w === "discard" || e.wu + e.hu === 0;
					return /* @__PURE__ */ c(_e, {
						defId: e.d,
						wu: e.wu,
						hu: e.hu,
						selected: S === e.u || E.includes(e.u),
						disabled: !_ || w !== "idle" && !t,
						onClick: () => K(e.u)
					}, e.u);
				}), x && _ && /* @__PURE__ */ c("span", {
					className: "gs-buy-hint px-1 text-ink/60",
					children: p("games.growingseason.buyHint")
				})]
			}), _ && /* @__PURE__ */ l("div", {
				className: "gs-actions flex",
				children: [
					w === "idle" && /* @__PURE__ */ l(s, { children: [
						e.cfg.deck === "mine" ? /* @__PURE__ */ c("button", {
							type: "button",
							className: "btn-quiet min-h-11 flex-none",
							disabled: !H,
							onClick: () => T("side"),
							children: p("games.growingseason.actMine")
						}) : /* @__PURE__ */ c("button", {
							type: "button",
							className: "btn-quiet min-h-11 flex-none",
							disabled: !U,
							onClick: () => T("side"),
							children: p("games.growingseason.actFish")
						}),
						/* @__PURE__ */ c("button", {
							type: "button",
							className: "btn-quiet min-h-11 flex-none",
							disabled: y.length === 0 || !!e.fishing || e.pendingUpgrade,
							onClick: () => T("discard"),
							children: p("games.growingseason.actDiscard")
						}),
						/* @__PURE__ */ c("button", {
							type: "button",
							className: "btn-base min-h-12 flex-1",
							disabled: !!e.fishing || e.pendingUpgrade,
							onClick: () => f({ type: "endTurn" }),
							children: p("games.growingseason.actEndTurn")
						})
					] }),
					w === "side" && /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("button", {
						type: "button",
						className: "btn-quiet min-h-11 flex-1",
						onClick: G,
						children: p("games.growingseason.cancel")
					}), /* @__PURE__ */ c("button", {
						type: "button",
						className: "btn-base min-h-12 flex-1",
						disabled: e.cfg.deck === "mine" ? E.length !== 2 : E.length < 1,
						onClick: se,
						children: p("games.growingseason.confirm")
					})] }),
					w === "discard" && /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("button", {
						type: "button",
						className: "btn-quiet min-h-11 flex-1",
						onClick: G,
						children: p("games.growingseason.cancel")
					}), /* @__PURE__ */ c("button", {
						type: "button",
						className: "btn-base min-h-12 flex-1",
						disabled: E.length < 1,
						onClick: ce,
						children: p("games.growingseason.confirm")
					})] })
				]
			})]
		}),
		children: /* @__PURE__ */ l("div", {
			className: "gs-table",
			children: [/* @__PURE__ */ l("div", {
				className: "gs-farm-column",
				children: [
					g && /* @__PURE__ */ l("div", {
						className: "gs-opponent flex items-start overflow-x-auto",
						children: [g.plots.map((e, t) => e ? /* @__PURE__ */ c(ve, {
							defId: e.d,
							w: e.w,
							small: !0
						}, e.u) : /* @__PURE__ */ c("span", { className: "gs-crop-empty flex-none rounded-lg border-2 border-dashed border-ink/20" }, t)), /* @__PURE__ */ c("span", {
							className: "gs-opponent-upgrades flex-none opacity-70",
							children: g.upgrades.map((e) => N(e).icon).join(" ")
						})]
					}),
					h && /* @__PURE__ */ c(be, {
						board: h.board,
						pos: h.boardPos,
						canInvest: W && h.coins >= 10 && h.boardPos < h.board.length,
						onInvest: () => f({ type: "invest" })
					}),
					/* @__PURE__ */ l("div", {
						className: "frame gs-farm",
						children: [h?.plots.map((e, t) => {
							let n = h.plotKinds[t];
							return /* @__PURE__ */ l("div", {
								className: "gs-plot flex flex-col items-center",
								children: [/* @__PURE__ */ c("button", {
									type: "button",
									onClick: () => ae(t),
									disabled: !(k != null && e === null || S != null && e !== null),
									className: `gs-plot-button grid cursor-pointer place-items-center rounded-xl border-2 ${k != null && e === null ? "border-ink bg-done-soft" : "border-ink/25 bg-surface"}`,
									children: e ? /* @__PURE__ */ c(ve, {
										defId: e.d,
										w: e.w,
										highlight: S != null
									}) : /* @__PURE__ */ c("span", {
										className: "gs-soil opacity-30",
										children: "🟫"
									})
								}), n !== "basic" && /* @__PURE__ */ c("span", {
									className: "gs-plot-kind text-center font-bold text-ink/60",
									children: p(X[n])
								})]
							}, t);
						}), h && h.upgrades.length > 0 && /* @__PURE__ */ c("div", {
							className: "gs-installed flex flex-wrap items-center",
							children: h.upgrades.map((e, t) => {
								let n = N(e), r = h.animalPos[e];
								return /* @__PURE__ */ l("span", {
									className: "gs-installed-upgrade flex items-center rounded-lg border-2 border-ink/25 bg-surface",
									title: p(X[e]),
									children: [/* @__PURE__ */ c("span", {
										"aria-hidden": !0,
										children: n.icon
									}), n.cycle && n.cycle.length > 1 && /* @__PURE__ */ c("span", {
										className: "flex gap-px",
										children: n.cycle.map((e, t) => /* @__PURE__ */ c("span", {
											className: `gs-animal-step grid place-items-center rounded-full font-mono tabular-nums ${r === t ? "bg-amber-300 font-extrabold" : "opacity-50"}`,
											children: e
										}, t))
									})]
								}, `${e}-${t}`);
							})
						})]
					})
				]
			}), /* @__PURE__ */ l("div", {
				className: "gs-market-column",
				children: [
					e.pendingUpgrade && _ && /* @__PURE__ */ c("div", {
						className: "frame gs-upgrade-choice",
						children: e.upgradeDisplay.map((e, t) => e ? /* @__PURE__ */ c(ye, {
							id: e,
							onClick: () => f({
								type: "chooseUpgrade",
								slot: t
							})
						}, `${e}-${t}`) : /* @__PURE__ */ c("span", { className: "gs-upgrade-empty flex-none rounded-lg border-2 border-dashed border-ink/20" }, t))
					}),
					e.fishing && /* @__PURE__ */ l("div", {
						className: "frame gs-fishing",
						children: [/* @__PURE__ */ l("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ c("p", {
								className: "gs-fish-value font-mono font-extrabold tabular-nums",
								children: p("games.growingseason.fishRemaining", { n: e.fishing.remaining })
							}), /* @__PURE__ */ l("p", {
								className: "gs-fish-detail text-ink/70",
								children: [p("games.growingseason.fishCaught", { n: e.fishing.caught.reduce((e, t) => e + t, 0) }), e.fishing.last ? ` · ${p("games.growingseason.lastFish", { n: e.fishing.last.f })}` : ""]
							})]
						}), _ && /* @__PURE__ */ l("div", {
							className: "gs-fish-actions flex",
							children: [/* @__PURE__ */ c("button", {
								type: "button",
								className: "btn-quiet min-h-11",
								onClick: () => f({ type: "fishStop" }),
								children: p("games.growingseason.fishStop", { n: e.fishing.caught.reduce((e, t) => e + t, 0) })
							}), /* @__PURE__ */ c("button", {
								type: "button",
								className: "btn-base min-h-11",
								onClick: () => f({ type: "fishFlip" }),
								children: p("games.growingseason.fishFlip")
							})]
						})]
					}),
					/* @__PURE__ */ l("div", {
						className: "frame gs-market",
						children: [
							/* @__PURE__ */ l("div", {
								className: "gs-market-crops",
								children: [
									/* @__PURE__ */ c("span", {
										className: "section-label flex-none",
										children: p("games.growingseason.storeLabel")
									}),
									e.store.map((e, t) => e ? /* @__PURE__ */ c(ve, {
										defId: e,
										w: 0,
										price: !0,
										small: !0,
										selected: k === t,
										onClick: () => q(t)
									}, `${e}-${t}`) : /* @__PURE__ */ c("span", { className: "gs-crop-empty flex-none rounded-lg border-2 border-dashed border-ink/20" }, t)),
									/* @__PURE__ */ c("span", {
										className: "gs-deck-count flex-none font-mono tabular-nums opacity-60",
										children: p("games.growingseason.deckLeft", { n: e.cropDeckCount })
									})
								]
							}),
							/* @__PURE__ */ l("div", {
								className: "gs-market-tools",
								children: [/* @__PURE__ */ c("span", {
									className: "section-label flex-none",
									children: p("games.growingseason.blacksmithLabel")
								}), e.blacksmith.map((e, t) => {
									if (e == null) return /* @__PURE__ */ c("span", { className: "gs-tool-empty flex-none rounded-md border-2 border-dashed border-ink/20" }, t);
									let n = D(e), r = W && h != null && n.price != null && h.coins >= n.price;
									return /* @__PURE__ */ l("button", {
										type: "button",
										onClick: () => J(t),
										disabled: !r,
										className: `gs-tool-card flex flex-none cursor-pointer flex-col items-center justify-center ${r ? "" : "opacity-50"} ${j === t ? "ring-2 ring-ink" : ""}`,
										children: [
											n.water > 0 && /* @__PURE__ */ l("span", {
												className: "gs-tool-value font-mono font-extrabold tabular-nums",
												children: ["💧", n.water]
											}),
											n.harvest > 0 && /* @__PURE__ */ l("span", {
												className: "gs-tool-value font-mono font-extrabold tabular-nums",
												children: ["🧺", n.harvest]
											}),
											/* @__PURE__ */ l("span", {
												className: "gs-tool-detail font-mono tabular-nums opacity-70",
												children: [
													"🐟",
													n.fish,
													" · 🪙",
													n.price
												]
											})
										]
									}, `${e}-${t}`);
								})]
							}),
							/* @__PURE__ */ l("div", {
								className: "gs-market-upgrades",
								children: [/* @__PURE__ */ c("span", {
									className: "section-label flex-none",
									children: p("games.growingseason.upgradesLabel")
								}), e.upgradeDisplay.map((e, t) => e ? /* @__PURE__ */ c("span", {
									className: "gs-upgrade-mini grid flex-none place-items-center rounded-lg border-2 border-ink/25 bg-surface",
									title: p(X[e]),
									children: N(e).icon
								}, `${e}-${t}`) : /* @__PURE__ */ c("span", { className: "gs-crop-empty flex-none rounded-lg border-2 border-dashed border-ink/20" }, t))]
							})
						]
					}),
					j != null && t && /* @__PURE__ */ l("div", {
						className: "frame gs-replace",
						children: [
							/* @__PURE__ */ c("span", {
								className: "section-label",
								children: p("games.growingseason.pickReplace")
							}),
							t.discard.filter((t) => {
								let n = e.blacksmith[j];
								if (!n) return !1;
								let r = D(n), i = D(t.d);
								return r.water > 0 && i.water > 0 || r.harvest > 0 && i.harvest > 0;
							}).map((e) => /* @__PURE__ */ c(_e, {
								defId: e.d,
								wu: 0,
								hu: 0,
								onClick: () => oe(e.u)
							}, e.u)),
							/* @__PURE__ */ c("button", {
								type: "button",
								className: "btn-quiet min-h-11",
								onClick: () => M(null),
								children: p("games.growingseason.cancel")
							})
						]
					})
				]
			})]
		}, "play-table")
	});
}
//#endregion
//#region src/games/growingseason/bot.ts
function Se(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
}
function Ce() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32;
}
function Z(e) {
	return e[Se(e.length)];
}
var we = {
	sprinkler: 10,
	harvester: 9,
	hen: 7,
	cow: 6.5,
	sheep: 6,
	pig: 5,
	plot23: 4.5,
	plot4: 4,
	plot56: 3.5,
	fertilizer: 2
}, Q = (e) => we[e] ?? 0, Te = (e, t) => !(P.has(t) && e.upgrades.includes(t));
function Ee(e, t) {
	if (e === "basic") return !1;
	let n = N(e), r = y(t);
	return n.plotTier === "23" && (r === 2 || r === 3) || n.plotTier === "4" && r === 4 || n.plotTier === "56" && r >= 5;
}
function De(e, t, n) {
	let r = v(n).sickle;
	return e.upgrades.includes("fertilizer") && (r += 1), Ee(e.plotKinds[t], n) && (r += N(e.plotKinds[t]).bonus ?? 0), r;
}
function Oe(e, t) {
	let n = D(e), r = D(t);
	return n.water > 0 && r.water > 0 || n.harvest > 0 && r.harvest > 0;
}
function ke(e, t, n) {
	let r = e.plots[t];
	if (!r) return -Infinity;
	let i = b(r.d);
	if (r.w >= i) return -Infinity;
	let a = v(r.d).track[r.w], o = r.w + 1 >= i, s = De(e, t, r.d);
	return (typeof a == "number" ? a : 0) + (o ? s * (n ? 1 : .5) : 0) + s / i;
}
function Ae(e, t) {
	return [...e].sort((e, n) => (e.wu + e.hu > 0 ? 0 : 1) - (n.wu + n.hu > 0 ? 0 : 1) || t(n) - t(e))[0];
}
function je(e, t) {
	let n = v(e), r = n.track.reduce((e, t) => e + (t ?? 0), 0), i = Ee(t, e) ? N(t).bonus ?? 0 : 0;
	return (r + n.sickle + i) / n.price - b(e) * .05;
}
var $ = (e) => {
	let t = D(e);
	return t.water + t.harvest + t.fish * .5;
};
function Me(e, t) {
	if (t.length === 0) return !0;
	let n = k.filter((t) => t.f < e);
	return n.reduce((e, t) => e + t.v, 0) / k.length > (1 - n.length / k.length) * t[t.length - 1];
}
var Ne = (e, t) => {
	let n = e.public;
	if (n.phase === "done") return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = t.difficulty === "weak";
	if (n.phase === "draft") {
		if (n.draftPicked?.includes(t.rid)) return null;
		let r = e.private?.draftHand ?? [];
		if (r.length < 2) return null;
		if (i) {
			let e = Se(r.length), t = Se(r.length - 1);
			return t >= e && (t += 1), { action: {
				type: "draftPick",
				keep: r[e],
				drop: r[t]
			} };
		}
		let a = [...r].sort((e, t) => Q(t) - Q(e));
		return { action: {
			type: "draftPick",
			keep: a[0],
			drop: a[a.length - 1]
		} };
	}
	if (n.turn !== t.rid) return null;
	if (n.pendingUpgrade) {
		let e = n.upgradeDisplay.map((e, t) => ({
			id: e,
			i: t
		})).filter((e) => e.id != null && Te(r, e.id));
		return e.length === 0 ? null : { action: {
			type: "chooseUpgrade",
			slot: (i ? Z(e) : e.reduce((e, t) => Q(e.id) >= Q(t.id) ? e : t)).i
		} };
	}
	if (n.fishing) {
		let e = n.fishing;
		return { action: { type: (i ? e.caught.length === 0 || Ce() < .5 : Me(e.remaining, e.caught)) ? "fishFlip" : "fishStop" } };
	}
	let a = e.private?.hand ?? [], o = e.private?.discard ?? [], s = a.filter((e) => e.wu < D(e.d).water), c = r.plots.map((e, t) => e && e.w < b(e.d) ? t : -1).filter((e) => e >= 0);
	if (s.length > 0 && c.length > 0) {
		if (i) return { action: {
			type: "water",
			hand: Z(s).u,
			plot: Z(c)
		} };
		let e = a.reduce((e, t) => e + Math.max(0, D(t.d).harvest - t.hu), 0) > 0 || r.upgrades.includes("harvester"), t = c[0], n = -Infinity;
		for (let i of c) {
			let a = ke(r, i, e);
			a > n && (n = a, t = i);
		}
		return { action: {
			type: "water",
			hand: Ae(s, (e) => D(e.d).water - e.wu).u,
			plot: t
		} };
	}
	let l = a.filter((e) => e.hu < D(e.d).harvest), u = r.plots.map((e, t) => e && e.w >= b(e.d) ? t : -1).filter((e) => e >= 0);
	if (l.length > 0 && u.length > 0) {
		if (i) return { action: {
			type: "harvest",
			hand: Z(l).u,
			plot: Z(u)
		} };
		let e = u.reduce((e, t) => De(r, e, r.plots[e]?.d ?? "") >= De(r, t, r.plots[t]?.d ?? "") ? e : t);
		return { action: {
			type: "harvest",
			hand: Ae(l, (e) => D(e.d).harvest - e.hu).u,
			plot: e
		} };
	}
	let d = a.filter((e) => e.wu + e.hu === 0);
	if (n.cfg.deck === "mine" && d.length >= 2) {
		let e = i ? d.slice(0, 2) : [...d].sort((e, t) => $(e.d) - $(t.d)).slice(0, 2);
		return { action: {
			type: "mine",
			cards: [e[0].u, e[1].u]
		} };
	}
	if (n.cfg.deck === "fish" && d.length >= 1) {
		let e = d.reduce((e, t) => e + D(t.d).fish, 0);
		if (i || e >= 1.5) return { action: {
			type: "fishStart",
			cards: d.map((e) => e.u)
		} };
	}
	if (a.length > 0) return { action: {
		type: "discard",
		cards: a.map((e) => e.u)
	} };
	let f = r.coins >= 10 && r.boardPos < r.board.length, p = r.board.length - r.boardPos, m = Math.min(...n.players.filter((e) => e.rid !== t.rid).map((e) => e.board.length - e.boardPos)), h = p <= 3 || m <= 2, g = r.plots.map((e, t) => e === null ? t : -1).filter((e) => e >= 0);
	if (i) {
		if (f && (p <= 1 || Ce() < .4)) return { action: { type: "invest" } };
		let e = n.store.map((e, t) => ({
			id: e,
			i: t
		})).filter((e) => e.id != null && v(e.id).price <= r.coins);
		return g.length > 0 && e.length > 0 ? { action: {
			type: "buyCrop",
			slot: Z(e).i,
			plot: Z(g)
		} } : f ? { action: { type: "invest" } } : { action: { type: "endTurn" } };
	}
	if (f && (p <= 1 || m <= 2)) return { action: { type: "invest" } };
	if (!h) {
		let e = null;
		for (let t of g) for (let i = 0; i < n.store.length; i += 1) {
			let a = n.store[i];
			if (a == null || v(a).price > r.coins) continue;
			let o = je(a, r.plotKinds[t]);
			(!e || o > e.score) && (e = {
				slot: i,
				plot: t,
				score: o
			});
		}
		if (e) return { action: {
			type: "buyCrop",
			slot: e.slot,
			plot: e.plot
		} };
		let t = null;
		for (let e = 0; e < n.blacksmith.length; e += 1) {
			let i = n.blacksmith[e];
			if (i == null) continue;
			let a = D(i);
			if (a.price == null || a.price > r.coins || r.coins - a.price < 10 && r.coins >= 10) continue;
			let s = o.filter((e) => Oe(i, e.d));
			if (s.length === 0) continue;
			let c = s.reduce((e, t) => $(e.d) <= $(t.d) ? e : t), l = $(i) - $(c.d);
			if (l <= 0) continue;
			let u = l / a.price;
			(!t || u > t.score) && (t = {
				slot: e,
				replace: c.u,
				score: u
			});
		}
		if (t) return { action: {
			type: "buyTool",
			slot: t.slot,
			replace: t.replace
		} };
	}
	return f ? { action: { type: "invest" } } : { action: { type: "endTurn" } };
}, Pe = (e, t, n) => {
	let r = t.public, i = r.players.find((e) => e.rid === r.turn) ?? r.players[0];
	switch (e.type) {
		case "water": {
			let t = i?.plots[e.plot]?.d;
			return t ? n("games.growingseason.hintWater", { crop: n(Y[t]) }) : "";
		}
		case "harvest": {
			let t = i?.plots[e.plot]?.d;
			return t ? n("games.growingseason.hintHarvest", { crop: n(Y[t]) }) : "";
		}
		case "discard": return n("games.growingseason.hintDiscard", { n: e.cards.length });
		case "mine": return n("games.growingseason.hintMine");
		case "fishStart": return n("games.growingseason.hintFishStart", { n: e.cards.length });
		case "fishFlip": return n("games.growingseason.hintFishFlip");
		case "fishStop": return n("games.growingseason.hintFishStop");
		case "buyCrop": {
			let t = r.store[e.slot];
			return t ? n("games.growingseason.hintBuyCrop", { crop: n(Y[t]) }) : "";
		}
		case "buyTool": return n("games.growingseason.hintBuyTool");
		case "invest": return n("games.growingseason.hintInvest");
		case "chooseUpgrade": {
			let t = r.upgradeDisplay[e.slot];
			return t ? n("games.growingseason.hintUpgrade", { name: n(X[t]) }) : "";
		}
		case "draftPick": return n("games.growingseason.hintDraft", {
			keep: n(X[e.keep]),
			drop: n(X[e.drop])
		});
		case "endTurn": return n("games.growingseason.hintEndTurn");
		default: return "";
	}
};
//#endregion
//#region src/games/growingseason/game-over.tsx
function Fe({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ c("div", {
		className: "gs-game-over",
		children: /* @__PURE__ */ c(u, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: I.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region src/games/growingseason/options.tsx
function Ie({ value: e, onChange: t }) {
	let n = r(), i = L.safeParse(e), a = i.success ? i.data : L.parse(void 0), o = (e) => t({
		...a,
		...e
	}), s = (e, t, r, i, a, o) => /* @__PURE__ */ c(d, {
		name: e,
		value: o,
		checked: t,
		label: n(i),
		hint: n(a),
		accent: I.accent,
		onChange: r
	}, o);
	return /* @__PURE__ */ l("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ l(f, {
				title: n("games.growingseason.optDeck"),
				children: [s("growingseason-deck", a.deck === "mine", () => o({ deck: "mine" }), "games.growingseason.deckMine", "games.growingseason.deckMineHint", "mine"), s("growingseason-deck", a.deck === "fish", () => o({ deck: "fish" }), "games.growingseason.deckFish", "games.growingseason.deckFishHint", "fish")]
			}),
			/* @__PURE__ */ l(f, {
				title: n("games.growingseason.optAdv"),
				children: [s("growingseason-advanced-tools", !a.advancedTools, () => o({ advancedTools: !1 }), "games.growingseason.advOff", "games.growingseason.advOffHint", "off"), s("growingseason-advanced-tools", a.advancedTools, () => o({ advancedTools: !0 }), "games.growingseason.advOn", "games.growingseason.advOnHint", "on")]
			}),
			/* @__PURE__ */ l(f, {
				title: n("games.growingseason.optBoard"),
				children: [
					s("growingseason-board", a.board === "standard", () => o({ board: "standard" }), "games.growingseason.boardStandard", "games.growingseason.boardStandardHint", "std"),
					s("growingseason-board", a.board === "quick", () => o({ board: "quick" }), "games.growingseason.boardQuick", "games.growingseason.boardQuickHint", "quick"),
					s("growingseason-board", a.board === "long", () => o({ board: "long" }), "games.growingseason.boardLong", "games.growingseason.boardLongHint", "long")
				]
			}),
			a.board === "standard" && /* @__PURE__ */ l(f, {
				title: n("games.growingseason.optAsym"),
				children: [
					s("growingseason-asym", a.asym === "off", () => o({ asym: "off" }), "games.growingseason.asymOff", "games.growingseason.asymOffHint", "off"),
					s("growingseason-asym", a.asym === "first", () => o({ asym: "first" }), "games.growingseason.asymFirst", "games.growingseason.asymHint", "first"),
					s("growingseason-asym", a.asym === "second", () => o({ asym: "second" }), "games.growingseason.asymSecond", "games.growingseason.asymHint", "second")
				]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/growingseason/entry.tsx
var Le = {
	definition: pe,
	View: ge,
	bot: Ne,
	describe: Pe,
	OverView: Fe,
	Options: Ie,
	locales: {
		zh: {
			name: "丰收季节",
			desc: "双人农场牌库构筑:浇水收割赚金币,投资升级农场,先填满版图者胜",
			rules: "游戏目标：\n率先填满自己农场版图的玩家立即获胜。填满版图上的每一格，需要投资 10 枚金币。\n游戏准备：\n· 每名玩家获得 3 块基础地块、3 枚金币和一副由 15 张牌组成的起始牌组，其中包括 10 张浇水卡和 5 张收割卡。\n· 先手玩家预先种植一株收割价值为 2 枚金币的小麦；后手玩家预先种植一株收割价值为 3 枚金币的小麦。\n· 在中央分别翻开 5 张作物牌、3 张铁匠工具牌和 3 张农场升级牌，组成各自的商品陈列区。\n回合流程：\n每个回合依次进行以下阶段：\n· 抽取 5 张牌。自己的牌组始终由 15 张牌组成；抽牌堆用完时，将弃牌堆洗混，组成新的抽牌堆。\n· 结算自动装置和动物的效果。\n· 为作物浇水，并收割成熟作物。\n· 进行挖矿，或弃置手牌。\n· 购买商品。\n· 结束回合。\n浇水与收割：\n· 浇水卡提供的每一点浇水能力，可以分别用于不同的作物。作物已经获得的浇水进度会保留。\n· 轨道上的编号格是集收格。作物到达集收格时，立即获得该格所示的金币，不需要消耗收割卡。\n· 作物到达轨道末端的镰刀格时即为成熟。消耗收割卡提供的 1 点收割能力，可以收割一株成熟作物，并获得等于其收割价值的金币。\n· 一张卡提供多点收割能力时，必须将这些能力分别用于不同的作物。\n· 收割后的作物牌放入独立的作物弃牌堆，不加入玩家自己的牌组。\n挖矿与购买：\n· 进行挖矿时，弃置 2 张本回合尚未使用的手牌，再翻开 1 张矿牌，按照该牌的结果获得金币。若翻出石头，则不获得金币。\n· 购买商品前，必须先使用或弃置全部手牌。店铺陈列区要等到你的回合结束后才补充商品。\n· 购买铁匠工具时，先支付费用，再从自己的弃牌堆中选择 1 张同类型的卡牌，将它移出游戏；随后将新获得的工具牌放入自己的弃牌堆。\n农场与投资：\n· 在购买阶段，每支付 10 枚金币，可以填满自己版图上的一格；同一回合可以填满多格。\n· 填满谷仓格时，从农场升级陈列区选择 1 张升级牌，并立即安装该升级。\n· 在长局中，填满浅蓝色工具格时，免费获得铁匠铺当前陈列的全部工具。\n· 动物从安装后的下一个回合开始，按其产出周期提供收益。\n· 每个回合开始时，洒水器为全部作物各提供 1 点浇水能力，收割机则收割所有成熟作物。\n· 肥料使每次收割额外获得 1 枚金币。阶梯地块只会提高与其阶梯等级相同的作物的收割收益。\n钓鱼变体：\n启用此变体后，以钓鱼代替挖矿。\n· 弃置任意数量本回合尚未使用的手牌，将它们的捕鱼值相加；每张基础卡的捕鱼值为 0.5。随后逐张翻开鱼牌。\n· 鱼牌上的鱼图标数量小于剩余捕鱼值时，捕获这条鱼，并从剩余捕鱼值中扣除相应的图标数量。\n· 鱼牌上的鱼图标数量大于或等于剩余捕鱼值时，发生翻船：失去这条鱼和此前最后捕获的一条鱼，其余已捕获鱼的收益仍可结算。\n高级工具变体：\n· 秘银工具提供 1 点浇水能力和 1 点收割能力；铱金工具提供 2 点浇水能力和 2 点收割能力。\n· 同一张高级工具牌的浇水能力和收割能力必须用于不同的作物。\n· 购买高级工具时，可以选择用它替换水壶或镰刀。\n其他版图变体：\n· 使用快速版图时，在游戏开始前轮流挑选升级牌；每名玩家预先安装 3 个升级。\n· 使用长局版图时，农场版图共有 15 格。填满整块版图共需投资 150 枚金币，过程中可以获得八次升级。",
			optDeck: "副业牌堆",
			deckMine: "挖矿",
			deckMineHint: "弃 2 张翻矿卡,稳健收入",
			deckFish: "钓鱼",
			deckFishHint: "连翻鱼牌,高风险高收益",
			optAdv: "高级工具",
			advOff: "标准工具",
			advOffHint: "只有浇水与镰刀(推荐新手)",
			advOn: "混入秘银/铱金",
			advOnHint: "水收一体的高级工具进铁匠铺",
			optBoard: "版图",
			boardStandard: "标准",
			boardStandardHint: "100 币 · 6 次升级",
			boardQuick: "快速",
			boardQuickHint: "100 币 · 开局轮抽 3 升级",
			boardLong: "长局",
			boardLongHint: "150 币 · 8 次升级 · 工具格",
			optAsym: "非对称让子",
			asymOff: "关闭",
			asymOffHint: "双方同款版图",
			asymFirst: "先手让子",
			asymSecond: "后手让子",
			asymHint: "谷仓格前置,开局节奏更快",
			yourTurn: "你的回合",
			yourTurnSub: "浇水收割 → 挖矿/弃牌 → 清空手牌后购买与投资",
			waitTurn: "等待 {{name}} 行动…",
			draftTitle: "开局升级轮抽",
			draftHint: "点两张牌:先点保留,再点弃掉(共 3 轮)",
			draftWaiting: "等待对手完成轮抽…",
			draftConfirm: "确认选择",
			upgradeTitle: "选择 1 个农场升级",
			fishingTitle: "钓鱼中…",
			fishRemaining: "剩余捕鱼值 {{n}}",
			fishCaught: "已捕获 {{n}} 币",
			lastFish: "上一条 {{n}} 鱼",
			fishFlip: "翻下一张",
			fishStop: "收杆拿 {{n}} 币",
			actMine: "⛏️ 挖矿",
			actFish: "🎣 钓鱼",
			actDiscard: "弃牌",
			actEndTurn: "结束回合",
			confirm: "确认",
			cancel: "取消",
			storeLabel: "种子店",
			blacksmithLabel: "铁匠铺",
			upgradesLabel: "升级",
			deckLeft: "余 {{n}}",
			buyHint: "手牌已空,可以购买与投资",
			pickReplace: "选择被替换的卡(移出游戏)",
			boardGoal: "版图 {{pos}}/{{n}}",
			hintWater: "给 {{crop}} 浇水",
			hintHarvest: "收割 {{crop}}",
			hintDiscard: "弃掉 {{n}} 张用不上的牌",
			hintMine: "弃 2 张废牌挖矿",
			hintFishStart: "弃 {{n}} 张废牌开钓",
			hintFishFlip: "继续翻下一张鱼",
			hintFishStop: "收杆拿走渔获",
			hintBuyCrop: "买入 {{crop}} 种下",
			hintBuyTool: "从铁匠铺换入新工具",
			hintInvest: "投资 10 金币填一格版图",
			hintUpgrade: "选择升级:{{name}}",
			hintDraft: "保留 {{keep}},弃掉 {{drop}}",
			hintEndTurn: "结束回合",
			crop: {
				carrot: "胡萝卜",
				grape: "葡萄",
				tomato: "番茄",
				watermelon: "西瓜",
				beet: "甜菜",
				banana: "香蕉",
				pineapple: "菠萝",
				pepper: "辣椒",
				potato: "土豆",
				daikon: "白萝卜",
				melon: "甜瓜",
				apple: "苹果",
				mango: "芒果",
				corn: "玉米",
				lemon: "柠檬",
				cabbage: "卷心菜",
				peas: "豌豆",
				strawberry: "草莓",
				cauliflower: "花椰菜",
				pumpkin: "南瓜",
				coffee: "咖啡豆",
				broccoli: "西兰花",
				eggplant: "茄子",
				garlic: "大蒜",
				wheat: "小麦"
			},
			up: {
				cow: "奶牛",
				sheep: "绵羊",
				hen: "母鸡",
				pig: "猪",
				plot23: "地块·2/3级",
				plot4: "地块·4级",
				plot56: "地块·5/6级",
				sprinkler: "洒水器",
				harvester: "收割机",
				fertilizer: "肥料"
			},
			upDesc: {
				cow: "每回合循环产出 1→2→3 币",
				sheep: "每回合循环产出 1→3 币",
				hen: "每回合固定产出 2 币",
				pig: "每回合循环产出 0→4 币",
				plot23: "地块增加 1 块;收割 2/3 级作物时多获得 2 币",
				plot4: "地块增加 1 块;收割 4 级作物时多获得 3 币",
				plot56: "地块增加 1 块;收割 5/6 级作物时多获得 4 币",
				sprinkler: "每回合开始给全体作物浇 1 点水(限安装 1 个)",
				harvester: "每回合开始收割所有成熟作物(限安装 1 个)",
				fertilizer: "每次收割多获得 1 币"
			},
			errNotYourTurn: "还没轮到你",
			errOver: "对局已结束",
			errPhase: "当前阶段不能这么做",
			errHandNotEmpty: "购买前须先用完或弃掉手牌",
			errBadCard: "这张卡现在不能用",
			errBadPlot: "这块地不可用",
			errCantAfford: "金币不够",
			errNoReplace: "弃牌堆没有可替换的同类型工具",
			errBadMine: "挖矿需要 2 张未使用的手牌",
			errBadFish: "现在不能钓鱼",
			errBadUpgrade: "不能选择这个升级",
			errBadDraft: "无效的选择",
			errFishing: "钓鱼还没收杆"
		},
		en: {
			name: "Growing Season",
			desc: "A two-player farming deck-builder: water, harvest, invest — first to fill the board wins",
			rules: "Objective:\nThe first player to fill their farm board wins immediately. Filling each square requires an investment of 10 coins.\nSetup:\n· Each player receives 3 basic plots, 3 coins, and a 15-card starting deck containing 10 watering cards and 5 harvest cards.\n· The first player plants wheat with a harvest value of 2 coins; the second player plants wheat with a harvest value of 3 coins.\n· Reveal 5 crop cards, 3 blacksmith tool cards, and 3 farm upgrade cards in their respective displays.\nTurn sequence:\nDuring each turn, complete these phases in order:\n· Draw 5 cards. Your deck always contains 15 cards; when the draw pile runs out, shuffle your discard pile to form a new draw pile.\n· Resolve the effects of machines and animals.\n· Water crops and harvest ripe crops.\n· Mine or discard hand cards.\n· Buy goods.\n· End your turn.\nWatering and harvesting:\n· You may assign each point provided by a watering card to a different crop. Crops retain the watering progress they have already gained.\n· The numbered spaces on a crop’s track are gathering spaces. When a crop reaches one, immediately gain the coins shown there without spending a harvest card.\n· A crop becomes ripe when it reaches the sickle space at the end of its track. Spend 1 harvest point to harvest 1 ripe crop and gain coins equal to its harvest value.\n· If a card provides multiple harvest points, you must use those points on different crops.\n· Put harvested crop cards into a separate crop discard pile rather than your own deck.\nMining and buying:\n· To mine, discard 2 hand cards that you have not used this turn, then reveal 1 mining card and gain coins according to its result. If you reveal a stone, gain no coins.\n· Before buying goods, you must use or discard every card in your hand. Shops refill their displays only after your turn ends.\n· To buy a blacksmith tool, first pay its cost, then Remove 1 card of the same type from your discard pile from the game. Put the new tool into your discard pile.\nFarm investment:\n· During the buying phase, each payment of 10 coins fills 1 square on your board. You may fill multiple squares during the same turn.\n· When you fill a barn square, choose 1 upgrade from the farm upgrade display and install it immediately.\n· In a long game, when you fill a light-blue tool square, gain all tools currently in the blacksmith’s display for free.\n· Animals provide benefits according to their production cycles, starting on the turn after installation.\n· At the start of each turn, the sprinkler provides 1 watering point to every crop, and the harvester harvests every ripe crop.\n· Fertiliser grants 1 additional coin each time you harvest. A tiered plot increases harvest income only for crops of the matching tier.\nFishing variant:\nThis variant replaces mining with fishing.\n· Discard any number of hand cards you have not used this turn and add their fishing values together. Each basic card has a fishing value of 0.5. Then reveal fish cards one at a time.\n· If a card has fewer fish icons than your remaining fishing value, catch that fish and subtract its number of icons from your remaining value.\n· If a card has at least as many fish icons as your remaining value, your boat capsizes. Lose that fish and the fish you caught most recently; you may still collect the income from your other catches.\nAdvanced tool variant:\n· A Mythril tool provides 1 watering point and 1 harvest point. An Iridium tool provides 2 watering points and 2 harvest points.\n· You must use the watering and harvesting provided by the same advanced tool card on different crops.\n· When buying an advanced tool, you may use it to replace either a watering can or a sickle.\nOther board variants:\n· With the quick board, draft upgrade cards before the game and start with 3 upgrades installed per player.\n· With the long-game board, your farm has 15 squares. Filling the whole board requires a total investment of 150 coins and provides eight upgrades along the way.",
			optDeck: "Side deck",
			deckMine: "Mining",
			deckMineHint: "Discard 2 to flip ore; steady income",
			deckFish: "Fishing",
			deckFishHint: "Flip fish in a row; high risk, high reward",
			optAdv: "Advanced tools",
			advOff: "Standard tools",
			advOffHint: "Watering cans and sickles only",
			advOn: "Add Mythril/Iridium",
			advOnHint: "Hybrid water+harvest tools in the shop",
			optBoard: "Board",
			boardStandard: "Standard",
			boardStandardHint: "100 coins · 6 upgrades",
			boardQuick: "Quick",
			boardQuickHint: "100 coins · draft 3 upgrades",
			boardLong: "Long",
			boardLongHint: "150 coins · 8 upgrades · tool squares",
			optAsym: "Asymmetric handicap",
			asymOff: "Off",
			asymOffHint: "Identical boards",
			asymFirst: "First player",
			asymSecond: "Second player",
			asymHint: "Barn squares up front, faster start",
			yourTurn: "Your turn",
			yourTurnSub: "Water & harvest → mine/discard → buy & invest with an empty hand",
			waitTurn: "Waiting for {{name}}…",
			draftTitle: "Opening upgrade draft",
			draftHint: "Tap two cards: first to keep, then to discard (3 rounds)",
			draftWaiting: "Waiting for opponent to draft…",
			draftConfirm: "Confirm",
			upgradeTitle: "Choose 1 farm upgrade",
			fishingTitle: "Fishing…",
			fishRemaining: "Fishing value left: {{n}}",
			fishCaught: "Caught {{n}} coins",
			lastFish: "Last fish: {{n}}",
			fishFlip: "Flip next",
			fishStop: "Stop & take {{n}}",
			actMine: "⛏️ Mine",
			actFish: "🎣 Fish",
			actDiscard: "Discard",
			actEndTurn: "End turn",
			confirm: "Confirm",
			cancel: "Cancel",
			storeLabel: "Seed store",
			blacksmithLabel: "Blacksmith",
			upgradesLabel: "Upgrades",
			deckLeft: "{{n}} left",
			buyHint: "Hand empty — you may buy and invest",
			pickReplace: "Choose the card to replace (removed from game)",
			boardGoal: "Board {{pos}}/{{n}}",
			hintWater: "Water the {{crop}}",
			hintHarvest: "Harvest the {{crop}}",
			hintDiscard: "Discard {{n}} dead cards",
			hintMine: "Discard 2 dead cards to mine",
			hintFishStart: "Discard {{n}} dead cards and start fishing",
			hintFishFlip: "Flip the next fish",
			hintFishStop: "Stop and keep the catch",
			hintBuyCrop: "Buy and plant {{crop}}",
			hintBuyTool: "Swap in a new tool at the blacksmith",
			hintInvest: "Invest 10 coins to fill a board square",
			hintUpgrade: "Take the upgrade: {{name}}",
			hintDraft: "Keep {{keep}}, drop {{drop}}",
			hintEndTurn: "End the turn",
			crop: {
				carrot: "Carrot",
				grape: "Grape",
				tomato: "Tomato",
				watermelon: "Watermelon",
				beet: "Beet",
				banana: "Banana",
				pineapple: "Pineapple",
				pepper: "Chili",
				potato: "Potato",
				daikon: "Daikon",
				melon: "Melon",
				apple: "Apple",
				mango: "Mango",
				corn: "Corn",
				lemon: "Lemon",
				cabbage: "Cabbage",
				peas: "Peas",
				strawberry: "Strawberry",
				cauliflower: "Cauliflower",
				pumpkin: "Pumpkin",
				coffee: "Coffee beans",
				broccoli: "Broccoli",
				eggplant: "Eggplant",
				garlic: "Garlic",
				wheat: "Wheat"
			},
			up: {
				cow: "Cows",
				sheep: "Sheep",
				hen: "Hens",
				pig: "Pigs",
				plot23: "Plot · lv 2/3",
				plot4: "Plot · lv 4",
				plot56: "Plot · lv 5/6",
				sprinkler: "Sprinkler",
				harvester: "Harvester",
				fertilizer: "Fertiliser"
			},
			upDesc: {
				cow: "Cycles 1→2→3 coins each turn",
				sheep: "Cycles 1→3 coins each turn",
				hen: "A steady 2 coins each turn",
				pig: "Cycles 0→4 coins each turn",
				plot23: "Adds 1 plot; lv 2/3 harvests earn 2 extra coins",
				plot4: "Adds 1 plot; lv 4 harvests earn 3 extra coins",
				plot56: "Adds 1 plot; lv 5/6 harvests earn 4 extra coins",
				sprinkler: "Waters all crops once at turn start (max 1)",
				harvester: "Harvests all ripe crops at turn start (max 1)",
				fertilizer: "Earn 1 extra coin on every harvest"
			},
			errNotYourTurn: "Not your turn yet",
			errOver: "The game is over",
			errPhase: "Not allowed in this phase",
			errHandNotEmpty: "Use or discard your hand before buying",
			errBadCard: "This card cannot be used now",
			errBadPlot: "That plot is unavailable",
			errCantAfford: "Not enough coins",
			errNoReplace: "No same-type card in your discard pile",
			errBadMine: "Mining needs 2 unused cards",
			errBadFish: "Cannot fish right now",
			errBadUpgrade: "Cannot choose this upgrade",
			errBadDraft: "Invalid pick",
			errFishing: "Finish fishing first"
		}
	}
};
//#endregion
export { Le as default };
