import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o, useFxAnchorsMaybe as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconClose as u, IconHistory as d } from "@bgparty/sdk/icons";
import { playTurn as f, useSoundEdge as p } from "@bgparty/sdk/sfx";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as h, seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { Floater as y, FlySprite as te, PulseBox as b } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as x } from "@bgparty/sdk/confirm-button";
import { GameOverChime as S } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as C, OptionSection as ne } from "@bgparty/sdk/ui/game-options";
//#region src/games/woo/meta.ts
var w = {
	id: "woo",
	tier: "alpha",
	mechanics: ["hand-management"],
	interactionTags: ["team-based", "communication-limits"],
	nameKey: "games.woo.name",
	descKey: "games.woo.desc",
	rulesKey: "games.woo.rules",
	icon: "🦜",
	iconImg: "games/woo.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/13963922513380248745/75AEFF97EA90255E3BABC70284C7634446C889CF/" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [4],
	playerRange: (e) => ({
		min: e?.mode === "duel" ? 2 : 4,
		max: e?.mode === "duel" ? 2 : 4
	}),
	accent: "#117d8c",
	releasedAt: "2026-11-07T01:12:08+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover",
	botDelayMs: 850
}, T = (e) => Math.floor(e / 6) + 1;
function E(e) {
	let t = e.map(T).sort((e, t) => e - t), n = t.length;
	return n === 1 ? {
		kind: "single",
		value: t[0],
		size: 1
	} : n < 2 || n > 4 ? null : t.every((e) => e === t[0]) ? {
		kind: n === 4 ? "bomb" : "set",
		value: t[0],
		size: n
	} : t.every((e, n) => n === 0 || e === t[n - 1] + 1) ? {
		kind: "run",
		value: t[n - 1],
		size: n
	} : n === 4 && t[0] === t[1] && t[2] === t[3] && t[2] === t[0] + 1 ? {
		kind: "stairs",
		value: t[3],
		size: 4
	} : null;
}
function D(e, t) {
	return t ? e.kind === "bomb" ? t.kind !== "bomb" || e.value > t.value : e.kind === t.kind && e.size === t.size && e.value > t.value : e.kind !== "single";
}
var O = [];
for (let e = 1; e <= 9; e++) {
	for (let t of [
		2,
		3,
		4
	]) O.push({
		meld: {
			kind: t === 4 ? "bomb" : "set",
			size: t,
			value: e
		},
		values: Array(t).fill(e)
	});
	for (let t of [
		2,
		3,
		4
	]) e + t - 1 <= 9 && O.push({
		meld: {
			kind: "run",
			size: t,
			value: e + t - 1
		},
		values: Array.from({ length: t }, (t, n) => e + n)
	});
	e < 9 && O.push({
		meld: {
			kind: "stairs",
			size: 4,
			value: e + 1
		},
		values: [
			e,
			e,
			e + 1,
			e + 1
		]
	});
}
function k(e, t) {
	let n = [...t];
	for (let t of e) {
		let e = n.indexOf(T(t));
		if (e < 0) return null;
		n.splice(e, 1);
	}
	return n;
}
function A(e, t) {
	return e.length < 1 || e.length > 3 ? [] : O.filter(({ meld: n, values: r }) => {
		let i = k(e, r);
		return D(n, t) && i !== null && i.length >= 1 && i.length <= 3;
	});
}
function j(e, t = 1, n = 3) {
	let r = Array.from({ length: 9 }, (t, n) => e.filter((e) => T(e) === n + 1)), i = [];
	function a(e, o) {
		if (e === 9) {
			o.length >= t && i.push(o);
			return;
		}
		for (let t = 0; t <= Math.min(r[e].length, n - o.length); t++) a(e + 1, [...o, ...r[e].slice(0, t)]);
	}
	return a(0, []), i;
}
function M(e, t) {
	let n = [...e], r = [];
	for (let e of t) {
		let t = n.findIndex((t) => T(t) === e);
		if (t < 0) return null;
		r.push(n.splice(t, 1)[0]);
	}
	return r;
}
function N(e, t, n) {
	return A(e, n).flatMap(({ values: n }) => {
		let r = M(t, k(e, n));
		return r ? [r] : [];
	});
}
//#endregion
//#region src/games/woo/schema.ts
var P = t.int().min(0).max(53), F = t.object({
	kind: t.enum([
		"single",
		"set",
		"run",
		"stairs",
		"bomb"
	]),
	value: t.int().min(1).max(9),
	size: t.int().min(1).max(4)
}), I = t.object({ mode: t.enum(["teams", "duel"]).default("teams") }).prefault({}), L = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		cards: t.array(P).min(1).max(4)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("concede"),
		card: P.nullable()
	}),
	t.object({
		type: t.literal("take"),
		card: P,
		recipient: t.string()
	}),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), re = t.object({
	mode: t.enum(["teams", "duel"]),
	phase: t.enum([
		"reserve",
		"lead",
		"complete",
		"return",
		"settle",
		"roundOver",
		"done"
	]),
	turn: t.string(),
	leader: t.string(),
	round: t.int().min(1).max(3),
	players: t.array(t.object({
		rid: t.string(),
		team: t.int().min(0).max(1),
		handCount: t.int().nonnegative(),
		ready: t.boolean()
	})),
	scores: t.array(t.int().min(0).max(2)).length(2),
	board: t.array(P),
	stockCount: t.int().nonnegative(),
	partial: t.array(P),
	target: t.object({
		meld: F,
		cards: t.array(P),
		by: t.string()
	}).nullable(),
	discarded: t.array(P),
	results: t.array(t.object({
		round: t.int(),
		by: t.string(),
		team: t.int(),
		cards: t.array(P)
	})),
	history: t.array(t.object({
		seq: t.int(),
		by: t.string(),
		type: t.enum([
			"play",
			"complete",
			"pass",
			"concede",
			"take"
		]),
		cards: t.array(P),
		recipient: t.string().nullable()
	}))
}), R = t.object({ hand: t.array(P) }), z = {
	play: 480,
	clear: 420,
	score: 750,
	draw: 450
}, B = (e, t, n = 1) => e.players[(e.players.indexOf(t) + n) % e.players.length], V = (e, t) => e.mode === "duel" ? e.players.indexOf(t) : e.players.indexOf(t) % 2, H = (e, t) => e.mode === "duel" ? t : B(e, t, 2), U = (e) => ({ code: e }), W = (e, t) => new Set(t).size === t.length && t.every((t) => e.includes(t)), G = (e, t) => e.filter((e) => !t.includes(e));
function K(e, t, n, r, i = null) {
	e.history.push({
		seq: e.history.length + 1,
		by: t,
		type: n,
		cards: [...r],
		recipient: i
	});
}
function q(e, t, n) {
	e.phase = "settle", e.after = t, e.beat = n;
}
function ie(e, t, n) {
	if (e.hands[t].length) return !1;
	let r = V(e, t);
	return e.scores[r]++, e.results.push({
		round: e.round,
		team: r,
		by: t,
		cards: [...n]
	}), e.ready = [], q(e, e.scores[r] >= 2 ? "done" : "roundOver", z.score), !0;
}
function ae(t) {
	let n = Array.from({ length: 54 }, (e, t) => t);
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function oe(e) {
	let t = ae(e);
	e.hands = Object.fromEntries(e.players.map((e) => [e, t.splice(0, 13)])), e.partial = [], e.target = null, e.discarded = [], e.ready = [], e.reserveStep = 0, e.after = null, e.mode === "duel" ? (e.board = t.splice(0, 4), e.stock = t, e.phase = "lead", e.turn = e.leader) : (e.board = t, e.stock = [], e.phase = "reserve", e.turn = B(e, e.leader));
}
function J(e) {
	e.target && e.discarded.push(...e.target.cards), e.target = null;
}
function se(e, t, n) {
	let r = [...e.partial], i = [...e.target?.cards ?? []], a = [...e.partial, ...t], o = E(a);
	J(e), e.target = {
		cards: a,
		by: e.leader,
		meld: o
	}, e.partial = [], K(e, n, "complete", t);
	let s = {
		kind: "play",
		rid: n,
		data: {
			cards: t,
			partialCards: r,
			previous: i,
			destination: "target",
			source: e.mode === "duel" && r.length > 0 ? "board" : "hand"
		}
	};
	return ie(e, n, a) ? [s, {
		kind: "score",
		rid: n,
		with: !0,
		data: { team: V(e, n) }
	}] : (e.turn = B(e, e.leader), e.leader = e.turn, q(e, e.mode === "duel" ? "refill" : "lead", z.play), [s]);
}
function ce(t, n, r) {
	let i = t.mode;
	if (n.length !== (i === "duel" ? 2 : 4)) throw Error("Woo requires exactly two or four seats matching the configured mode");
	let a = {
		mode: i,
		phase: "lead",
		players: [...n],
		hands: {},
		seed: r,
		cursor: 0,
		round: 1,
		leader: n[e(r, 0, n.length)],
		turn: "",
		scores: [0, 0],
		partial: [],
		target: null,
		board: [],
		stock: [],
		discarded: [],
		ready: [],
		results: [],
		history: [],
		beat: 0,
		after: null,
		reserveStep: 0
	};
	return a.cursor = 1, oe(a), {
		state: a,
		fx: [{
			kind: "deal",
			data: { count: 13 }
		}]
	};
}
function le(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.phase !== "settle") return { state: e };
		let t = structuredClone(e), r = t.after;
		if (t.after = null, r === "refill") {
			let e = t.stock.splice(0, 4 - t.board.length);
			if (t.board.push(...e), e.length) return q(t, "lead", z.draw), {
				state: t,
				fx: [{
					kind: "refill",
					data: { cards: e }
				}]
			};
			t.phase = "lead";
		} else t.phase = r;
		return { state: t };
	}
	if (!e.players.includes(n.by) || e.phase === "done" || e.phase === "settle") return U("games.woo.errTurn");
	if (e.phase === "roundOver") {
		if (t.type !== "next" || e.ready.includes(n.by)) return U("games.woo.errTurn");
		let r = structuredClone(e);
		return r.ready.push(n.by), r.ready.length === r.players.length ? (r.round++, r.leader = B(r, r.results.at(-1).by), oe(r), {
			state: r,
			fx: [{
				kind: "deal",
				data: { count: 13 }
			}]
		}) : { state: r };
	}
	if (n.by !== e.turn) return U("games.woo.errTurn");
	let r = structuredClone(e);
	if (r.phase === "reserve" && t.type === "take") return !r.board.includes(t.card) || ![n.by, H(r, n.by)].includes(t.recipient) ? U("games.woo.errCard") : (r.board = G(r.board, [t.card]), r.hands[t.recipient].push(t.card), K(r, n.by, "take", [t.card], t.recipient), r.reserveStep++, r.reserveStep === 2 ? (r.turn = r.leader, r.phase = "lead") : r.turn = B(r, n.by), {
		state: r,
		fx: [{
			kind: "take",
			rid: t.recipient,
			data: {
				cards: [t.card],
				source: "board"
			}
		}]
	});
	if (r.phase === "return" && t.type === "take") return !r.partial.includes(t.card) || t.recipient !== n.by ? U("games.woo.errCard") : (r.partial = G(r.partial, [t.card]), r.hands[n.by].push(t.card), K(r, n.by, "take", [t.card], n.by), r.partial.length ? r.turn = H(r, n.by) : (r.turn = B(r, H(r, r.leader)), r.leader = r.turn, q(r, "lead", z.clear)), {
		state: r,
		fx: [{
			kind: "take",
			rid: n.by,
			data: {
				cards: [t.card],
				source: "partial"
			}
		}]
	});
	if (r.phase === "lead" && t.type === "concede" && r.target) return r.mode === "teams" && t.card !== null || t.card !== null && !r.board.includes(t.card) ? U("games.woo.errCard") : (t.card !== null && (r.board = G(r.board, [t.card]), r.hands[n.by].push(t.card)), K(r, n.by, "concede", t.card === null ? [] : [t.card]), J(r), r.turn = B(r, n.by), r.leader = r.turn, q(r, "lead", z.clear), {
		state: r,
		fx: [{
			kind: "clear",
			rid: n.by,
			data: {
				cards: e.target.cards,
				source: "target"
			}
		}, ...t.card === null ? [] : [{
			kind: "take",
			rid: n.by,
			with: !0,
			data: {
				cards: [t.card],
				source: "board"
			}
		}]]
	});
	if (r.phase === "complete" && t.type === "pass") return K(r, n.by, "pass", r.partial), J(r), r.partial.length === 1 ? (r.discarded.push(...r.partial), r.partial = [], r.turn = B(r, n.by), r.leader = r.turn, q(r, "lead", z.clear)) : (r.phase = "return", r.turn = r.leader), {
		state: r,
		fx: [{
			kind: "clear",
			rid: n.by,
			data: {
				cards: e.target?.cards ?? [],
				source: "target"
			}
		}, ...e.partial.length === 1 ? [{
			kind: "clear",
			rid: n.by,
			with: !0,
			data: {
				cards: e.partial,
				source: "partial"
			}
		}] : []]
	};
	if (t.type !== "play") return U("games.woo.errMove");
	if (r.phase === "complete") {
		let e = r.mode === "duel" ? r.board : r.hands[n.by], i = E([...r.partial, ...t.cards]);
		return t.cards.length > 3 || !W(e, t.cards) || !i || !D(i, r.target?.meld ?? null) ? U("games.woo.errMeld") : (r.mode === "duel" ? r.board = G(e, t.cards) : r.hands[n.by] = G(e, t.cards), {
			state: r,
			fx: se(r, t.cards, n.by)
		});
	}
	if (r.phase !== "lead" || !W(r.hands[n.by], t.cards)) return U("games.woo.errCard");
	if (r.mode === "duel" && r.board.length === 0) {
		let e = E(t.cards), i = r.target?.meld ?? null, a = j(r.hands[n.by], 2, 4).some((e) => E(e) !== null), o = e?.kind === "single" && (i ? i.kind === "single" && e.value > i.value : !a);
		return !e || !o && !D(e, i) ? U("games.woo.errMeld") : (r.hands[n.by] = G(r.hands[n.by], t.cards), {
			state: r,
			fx: se(r, t.cards, n.by)
		});
	}
	return A(t.cards, r.target?.meld ?? null).length ? (r.hands[n.by] = G(r.hands[n.by], t.cards), r.partial = [...t.cards], K(r, n.by, "play", t.cards), ie(r, n.by, t.cards) ? {
		state: r,
		fx: [{
			kind: "play",
			rid: n.by,
			data: {
				cards: t.cards,
				source: "hand",
				destination: "partial"
			}
		}, {
			kind: "score",
			rid: n.by,
			with: !0,
			data: { team: V(r, n.by) }
		}]
	} : (r.turn = H(r, n.by), q(r, "complete", z.play), {
		state: r,
		fx: [{
			kind: "play",
			rid: n.by,
			data: {
				cards: t.cards,
				source: "hand",
				destination: "partial"
			}
		}]
	})) : U("games.woo.errMeld");
}
function ue(e, t) {
	return {
		public: {
			mode: e.mode,
			phase: e.phase,
			turn: e.turn,
			leader: e.leader,
			round: e.round,
			scores: e.scores,
			board: e.board,
			stockCount: e.stock.length,
			partial: e.partial,
			target: e.target,
			discarded: e.discarded,
			results: e.results,
			history: e.history,
			players: e.players.map((t) => ({
				rid: t,
				team: V(e, t),
				handCount: e.hands[t].length,
				ready: e.ready.includes(t)
			}))
		},
		...e.players.includes(t) ? { private: { hand: e.hands[t] } } : {}
	};
}
var de = {
	meta: w,
	saveCompatibility: { version: "1" },
	schemas: {
		action: L,
		publicView: re,
		privateView: R,
		config: I
	},
	setup: ce,
	reduce: le,
	viewFor: ue,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = e.scores[0] >= 2 ? 0 : 1, n = e.players.filter((n) => V(e, n) === t);
		return {
			phase: "done",
			winner: n,
			ranking: [...n, ...e.players.filter((e) => !n.includes(e))],
			scores: Object.fromEntries(e.players.map((t) => [t, e.scores[V(e, t)]]))
		};
	},
	nextTickIn: (e) => e.phase === "settle" ? e.beat : null
};
function fe(e, t, n) {
	if (e.phase === "roundOver") return e.players.find((e) => e.rid === n)?.ready ? [] : [{ type: "next" }];
	if (e.turn !== n) return [];
	if (e.phase === "reserve") return e.board.flatMap((t) => e.players.filter((t) => t.team === e.players.find((e) => e.rid === n).team).map((e) => ({
		type: "take",
		card: t,
		recipient: e.rid
	})));
	if (e.phase === "return") return e.partial.map((e) => ({
		type: "take",
		card: e,
		recipient: n
	}));
	if (e.phase === "complete") return [{ type: "pass" }, ...N(e.partial, e.mode === "duel" ? e.board : t.hand, e.target?.meld ?? null).map((e) => ({
		type: "play",
		cards: e
	}))];
	if (e.phase !== "lead") return [];
	let r = e.target?.meld ?? null, i = e.target ? [{
		type: "concede",
		card: null
	}] : [];
	if (e.target && e.mode === "duel" && i.push(...e.board.map((e) => ({
		type: "concede",
		card: e
	}))), e.mode === "duel" && !e.board.length) {
		let e = j(t.hand, 2, 4).filter((e) => {
			let t = E(e);
			return t && D(t, r);
		});
		i.push(...e.map((e) => ({
			type: "play",
			cards: e
		}))), (!r && !j(t.hand, 2, 4).some((e) => E(e)) || r?.kind === "single") && i.push(...j(t.hand, 1, 1).filter((e) => !r || E(e).value > r.value).map((e) => ({
			type: "play",
			cards: e
		})));
	} else i.push(...j(t.hand).filter((e) => A(e, r).length).map((e) => ({
		type: "play",
		cards: e
	})));
	return i;
}
//#endregion
//#region src/games/woo/card.tsx
var pe = [
	"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20180%20240'%3e%3cpath%20fill='%23f1df79'%20d='M28%2012%20144%205%20161%20223%2022%20233Z'/%3e%3cpath%20fill='%23f05c37'%20d='M40%2079Q34%2031%2077%2021%20126%2024%20133%2091L155%20119%20146%20196%2047%20195%2018%20134Z'/%3e%3cpath%20fill='%23f3bc60'%20d='m56%20112%2036%2024%2041%2067-85%208Z'/%3e%3cpath%20fill='%23158b83'%20d='M38%20112%2063%20123%2046%20151Z%20M92%20128Q129%20139%20126%20170%20105%20187%2082%20166%2067%20148%2092%20128Z'/%3e%3cpath%20stroke='%23418c52'%20stroke-width='4'%20d='m129%2080%2013-55m-5%2060%2026-48'/%3e%3cellipse%20cx='143'%20cy='22'%20rx='6'%20ry='10'%20fill='%23418c52'%20transform='rotate(-24%20143%2022)'/%3e%3cellipse%20cx='166'%20cy='34'%20rx='6'%20ry='10'%20fill='%23418c52'%20transform='rotate(-24%20166%2034)'/%3e%3cpath%20d='m56%2042-17-9%209%2017'%20fill='%23f6d866'/%3e%3ccircle%20cx='72'%20cy='51'%20r='7'%20fill='%23233336'/%3e%3cpath%20d='m65%20202-5%2021m49-22%207%2020m-62%202%2018-3m34%201%2021%202'%20stroke='%23384846'%20stroke-width='3'%20fill='none'%20stroke-linecap='round'/%3e%3c/svg%3e",
	"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20180%20240'%3e%3cpath%20fill='%238bd0c8'%20d='m19%2014%20147-6%2016%20217-164%208Z'/%3e%3cpath%20fill='%23f7a23e'%20d='M84%20190Q42%20178%2026%20167%200%20156%2023%20143-5%20132%2019%20118-3%20105%2021%2094%204%2076%2031%2072%2015%2047%2046%2052L72%2063%2064%2031%2044%2040%2055%2014%2088%2033%20119%2011%20131%2040%20108%2031%20111%2064Q142%2039%20149%2053%20163%2042%20160%2066%20183%2065%20164%2086%20189%2094%20167%20109%20188%20124%20163%20135%20180%20154%20154%20162%20137%20182%20104%20192L94%20221Z'/%3e%3cpath%20d='M82%20211Q62%20182%2053%20162M101%20210Q122%20186%20132%20165M79%20221Q40%20213%2046%20197%2057%20186%2064%20199%2065%20208%2054%20208M100%20221Q135%20214%20134%20196%20127%20182%20117%20198%20118%20207%20127%20205'%20fill='none'%20stroke='%23233c38'%20stroke-width='4'%20stroke-linecap='round'/%3e%3ccircle%20cx='83'%20cy='202'%20r='4'%20fill='%23243734'/%3e%3ccircle%20cx='103'%20cy='201'%20r='4'%20fill='%23243734'/%3e%3cpath%20d='m85%20218%2012%2015%206-17'%20fill='%23223330'/%3e%3c/svg%3e",
	"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20180%20240'%3e%3cpath%20fill='%23db94b8'%20d='m17%2015%20138-6%2021%20214-157%206Z'/%3e%3cpath%20fill='%2316383d'%20d='M39%2021%20125%2018%20128%2076%20155%2091%20149%20198%2049%20199%2030%20105Z'/%3e%3cpath%20fill='%23142e33'%20d='m124%2037%2022%209-21%206'/%3e%3cpath%20fill='%2335a5bd'%20d='M57%2035Q70%2023%2081%2040%2077%2054%2061%2049Z%20M48%2052Q61%2042%2070%2059%2065%2074%2050%2066Z%20M77%2055Q93%2046%2097%2063%2094%2078%2080%2072Z'/%3e%3cpath%20fill='%23f2d547'%20d='M60%2082Q60%2064%2079%2078%2094%2061%20108%2079%20116%20104%2081%20115%2055%20108%2060%2082Z'/%3e%3cpath%20fill='%23f39534'%20d='M51%20129Q31%20117%2030%20146%2038%20167%2068%20167%2083%20153%2051%20129Z%20M118%20122Q103%20137%20112%20166%20133%20174%20140%20155%20144%20129%20129%20119Z%20M76%20180Q93%20160%20113%20182%20119%20198%2092%20196Z'/%3e%3cpath%20stroke='%23c7d7c9'%20stroke-width='3'%20d='M109%2040q-5%2013-10%200'%20fill='none'/%3e%3cpath%20d='M54%20158Q12%20143%2017%20179%2020%20209%2043%20189%2055%20168%2032%20170%2018%20177%2031%20185M97%20198Q136%20207%20124%20224%2092%20241%2074%20224%2068%20210%20103%20216'%20fill='none'%20stroke='%233b5355'%20stroke-width='3'%20stroke-linecap='round'/%3e%3c/svg%3e",
	"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20180%20240'%3e%3cpath%20fill='%23b2cf7f'%20d='M21%2012%20149%208%20171%20221%2015%20230Z'/%3e%3cpath%20fill='%23173234'%20d='M42%2053Q45%2020%2083%2023%20127%2018%20133%2060L150%2075%20153%20174Q151%20199%20120%20196L111%20212%2095%20197%2072%20200%2058%20211%2048%20195Q23%20199%2023%20172L25%2082Z'/%3e%3cpath%20fill='%23f4c644'%20d='M49%2095Q57%2076%2089%20104%20122%2077%20134%2096%20152%20132%2094%20150%2045%20147%2040%20120Z'/%3e%3cpath%20fill='%23fbac35'%20d='M49%2096Q59%2084%2088%20107%20120%2086%20130%2098L123%20120%2088%20136%2055%20121Z'/%3e%3ccircle%20cx='65'%20cy='47'%20r='5'%20fill='%23f5f4e6'/%3e%3ccircle%20cx='114'%20cy='46'%20r='5'%20fill='%23f5f4e6'/%3e%3cpath%20d='m85%2044%2010%200-6%2026'%20fill='%2382968b'/%3e%3cpath%20d='m58%20202-1%2022-11%207m11-7%2010%206m43-29%201%2023-10%207m10-7%2010%207'%20stroke='%23708878'%20stroke-width='3'%20fill='none'%20stroke-linecap='round'/%3e%3c/svg%3e",
	"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20180%20240'%3e%3cpath%20fill='%23f3846c'%20d='m21%2011%20135-5%2018%20224-158-2Z'/%3e%3cpath%20d='M41%20106Q21%2063%2062%2034%20102%201%20132%2072'%20fill='none'%20stroke='%237a9292'%20stroke-width='5'%20stroke-dasharray='1%2010'%20stroke-linecap='round'/%3e%3cpath%20fill='%2319373b'%20d='M82%2069Q81%2046%20114%2045%20135%2041%20138%2068L158%2072%20139%2079%20150%20102%20134%20155%2067%20160%2047%20122Z'/%3e%3cpath%20fill='%23f5d346'%20d='M84%20104Q108%20119%20138%20104L124%20184%2079%20182Z'/%3e%3cpath%20fill='%2315353a'%20d='M79%2098Q52%2072%2033%2097%2022%20137%2057%20160%2077%20158%2083%20140Z'/%3e%3cpath%20fill='%23f8edc8'%20d='M75%2065h21q9%2014%200%2020H75Z'/%3e%3ccircle%20cx='120'%20cy='67'%20r='5'%20fill='%23fff5df'/%3e%3cpath%20d='m94%20179-2%2029-12%202m33-29%201%2030-12%201'%20fill='none'%20stroke='%23946635'%20stroke-width='3'/%3e%3cpath%20d='m29%20214%20126-7%2011%209-128%2012Z'%20fill='%239c6334'/%3e%3cpath%20d='m37%20216%20117-5'%20fill='none'%20stroke='%23bd8a48'%20stroke-width='3'/%3e%3c/svg%3e",
	"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20180%20240'%3e%3cpath%20fill='%23b5d6b9'%20d='m15%2012%20146-4%2011%20216-157%208Z'/%3e%3cpath%20fill='%23193c40'%20d='M62%2024Q100%2013%20117%2055L132%2078%20151%2099%20142%20174%20121%20196%20109%20220%2084%20208%2060%20215%2057%20194%2031%20188%2020%20124%2040%2085Z'/%3e%3cpath%20fill='%23e8cb55'%20d='m63%2024-18%203%2017%207-15%205%2016%203'/%3e%3ccircle%20cx='85'%20cy='44'%20r='6'%20fill='%23f8f4df'/%3e%3cpath%20fill='%2313aa9d'%20d='M26%2099Q61%2083%2085%20110%20118%2085%20149%20103L142%20134Q97%20174%2043%20140Z'/%3e%3cpath%20fill='%23198d91'%20d='M31%20113Q66%20102%2086%20120%20115%20103%20146%20114L135%20137Q91%20166%2046%20140Z'/%3e%3cpath%20d='m63%20198-1%2028-15%202m59-16-5%2017-15%201'%20fill='none'%20stroke='%23c8975d'%20stroke-width='3'%20stroke-linecap='round'/%3e%3c/svg%3e",
	"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20180%20240'%3e%3cpath%20fill='%2398b5da'%20d='m15%2014%20147-5%2011%20218-159%204Z'/%3e%3cpath%20fill='%23e8592e'%20d='M38%20140Q4%20125%2025%20115%206%20106%2030%2098%2010%2086%2038%2079%2020%2065%2048%2061%2033%2048%2058%2045%2043%2028%2071%2028%2062%2012%2088%2017L127%2031%20129%2088%20145%20109%20132%20153Z'/%3e%3cpath%20d='m75%2023%2045%2012m-55%202%2055%209m-67%203%2069%209m-78%204%2079%208'%20fill='none'%20stroke='%23efc456'%20stroke-width='4'/%3e%3cpath%20fill='%23aa8552'%20d='M31%20132Q50%20117%2092%20144%20119%20125%20139%20146L144%20182%20122%20190%2038%20183Z'/%3e%3cpath%20fill='%2312383c'%20d='M112%20151Q135%20143%20143%20158L137%20180%20119%20175%20107%20174Z'/%3e%3ccircle%20cx='126'%20cy='160'%20r='4'%20fill='%23fff4db'/%3e%3cpath%20d='m137%20174%208%2019%205-20'%20fill='%23172d32'/%3e%3cpath%20d='m49%20183%200%2028%2026%203-3%2016m22-43%205%2019%2022%208-4%2014'%20fill='none'%20stroke='%23b67957'%20stroke-width='3'%20stroke-linecap='round'/%3e%3c/svg%3e",
	"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20180%20240'%3e%3cpath%20fill='%23a4a3ce'%20d='m15%2013%20147-4%2010%20217-155%207Z'/%3e%3cpath%20fill='%23bc966a'%20d='M33%2097%20109%2070%20151%20108%20144%20218%20124%20215%20122%20142%2081%20207%2054%20211%2051%20142Z'/%3e%3cpath%20fill='%23e8c74a'%20d='M45%2097Q81%2066%20116%2092%20155%20130%20128%20204L116%20187%20105%20211%2094%20196%2081%20218%2072%20200%2057%20216%2051%20186%2040%20207%2029%20167Z'/%3e%3cpath%20d='m46%20111%2010%2082m8-92%209%2098m8-104%2010%2094m8-90%2010%2085m8-73%205%2048'%20stroke='%23efdb6a'%20stroke-width='5'%20fill='none'/%3e%3cpath%20fill='%233caa59'%20d='M68%2039Q78%2023%2095%2033L104%2082%2071%2086Z'/%3e%3cpath%20fill='%23a8bd4d'%20d='M92%2033%20113%2039%20116%2082%20101%2086Z'/%3e%3cpath%20d='m72%2039-22%204q-4%208%2016%204'%20fill='%23526263'/%3e%3ccircle%20cx='82'%20cy='48'%20r='5'%20fill='%23153631'/%3e%3cpath%20fill='%23193632'%20d='m31%2099-8-9-1%2026%2024-4Z'/%3e%3cpath%20d='m69%20210%200%2015-13%202m48-20%201%2019-12%201'%20fill='none'%20stroke='%234b6653'%20stroke-width='3'/%3e%3c/svg%3e",
	"data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20180%20240'%3e%3cpath%20fill='%2376c1a1'%20d='m17%2013%20143-5%2011%20218-154%205Z'/%3e%3cpath%20fill='%23293a36'%20d='M24%2092Q27%2043%2071%2035%20116%2016%20129%2077L150%2089%20144%20149%20123%20177%2092%20189%2062%20177%2042%20154%2024%20125%2015%20115Z'/%3e%3cpath%20fill='%2319332f'%20d='m24%2098-11%2022%202%2013%2015-15'/%3e%3cpath%20fill='%238e4899'%20d='M86%2092Q110%2078%20140%2096%20143%20127%20112%20139%2085%20132%2081%20112Z'/%3e%3cpath%20fill='%23edd05b'%20d='M71%20153Q89%20168%20123%20166L130%20184%2083%20194%2060%20181Z'/%3e%3ccircle%20cx='40'%20cy='95'%20r='6'%20fill='%23f8f2d9'/%3e%3cpath%20d='m35%2082%2015%202'%20stroke='%2391a69a'%20stroke-width='4'%20stroke-linecap='round'/%3e%3cpath%20d='m36%20160%203%2040%2096%2012m-54-25%201%2020-20%204m-29-12%209%2016%2098%207'%20fill='none'%20stroke='%239e744a'%20stroke-width='5'%20stroke-linecap='round'/%3e%3c/svg%3e"
];
function me(e) {
	let t = s(), a = i(null), o = i(null), c = n(() => {
		let e = a.current;
		if (e?.isConnected) {
			let t = e.getBoundingClientRect();
			o.current = {
				x: t.left,
				y: t.top,
				w: t.width,
				h: t.height
			};
		}
		return o.current;
	}, []), l = n((e) => {
		c(), a.current = e, c();
	}, [c]);
	return r(() => {
		c(), t?.registerProbe(`origin:${e}`, c);
	}), r(() => {
		for (let e of [
			"scroll",
			"resize",
			"pointerdown",
			"keydown",
			"transitionend"
		]) window.addEventListener(e, c, !0);
		return () => {
			c();
			for (let e of [
				"scroll",
				"resize",
				"pointerdown",
				"keydown",
				"transitionend"
			]) window.removeEventListener(e, c, !0);
		};
	}, [c]), l;
}
function he({ card: e, back: t = !1 }) {
	let n = e === void 0 ? 1 : T(e);
	return /* @__PURE__ */ _("span", {
		className: `woo-card woo-v${n}${t ? " woo-back" : ""}`,
		"aria-hidden": !0,
		children: t ? /* @__PURE__ */ _("span", {
			className: "woo-back-mark",
			children: "W"
		}) : /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("img", {
				src: pe[n - 1],
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ _("b", {
				className: "woo-corner woo-tl",
				children: n
			}),
			/* @__PURE__ */ _("b", {
				className: "woo-corner woo-tr",
				children: n
			}),
			/* @__PURE__ */ _("b", {
				className: "woo-corner woo-bl",
				children: n
			}),
			/* @__PURE__ */ _("b", {
				className: "woo-corner woo-br",
				children: n
			})
		] })
	});
}
function Y({ card: e, zone: t, selected: r = !1, eligible: i = !1, onPick: a }) {
	let s = l(), { ref: c, hidden: u } = o(`${t}:${e}`), d = me(`${t}:${e}`), f = n((e) => {
		c(e), d(e);
	}, [c, d]);
	return /* @__PURE__ */ v("button", {
		type: "button",
		className: `woo-card-button${r ? " is-selected" : ""}${i ? " is-eligible" : ""}`,
		disabled: !a,
		"aria-label": s("games.woo.selectCard", { n: T(e) }),
		"aria-pressed": a ? r : void 0,
		onClick: a,
		"data-card": e,
		"data-zone": t,
		children: [/* @__PURE__ */ _("span", {
			ref: f,
			style: { visibility: u ? "hidden" : void 0 },
			children: /* @__PURE__ */ _(he, { card: e })
		}), i && /* @__PURE__ */ _("svg", {
			className: "woo-ants",
			viewBox: "0 0 100 140",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: /* @__PURE__ */ _("rect", {
				x: "2",
				y: "2",
				width: "96",
				height: "136",
				rx: "7"
			})
		})]
	});
}
//#endregion
//#region src/games/woo/view-player.tsx
function ge(e) {
	return /* @__PURE__ */ _(_e, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function _e({ pub: e, priv: t, members: n, myRid: r, send: i, review: s = !1 }) {
	let y = l(), te = c((e) => e.locale), b = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? ee(t, te) : y("games.woo.unknownPlayer");
	}, [x, S] = a(!1), C = `${r}|${e.round}|${e.phase}|${e.turn}|${e.history.length}`, [ne, w] = a({
		scope: "",
		hand: [],
		board: []
	}), O = ne.scope === C ? ne : {
		scope: C,
		hand: [],
		board: []
	}, k = !s && e.turn === r && [
		"reserve",
		"lead",
		"complete",
		"return"
	].includes(e.phase), j = !s && e.phase === "roundOver" && !e.players.find((e) => e.rid === r)?.ready;
	p(k || j, f);
	let M = [...t?.hand ?? []].sort((e, t) => e - t), N = e.phase === "complete" && e.mode === "duel" ? O.board : O.hand, P = E([...e.partial, ...N]), F = e.phase === "complete" ? N.length > 0 && N.length <= 3 && !!P && D(P, e.target?.meld ?? null) : e.mode === "duel" && !e.board.length ? fe(e, { hand: M }, r).some((e) => e.type === "play" && e.cards.map(T).sort().join() === N.map(T).sort().join()) : A(N, e.target?.meld ?? null).length > 0, I = (t, n) => {
		let r = O[t], i = e.phase === "reserve" || e.phase === "lead" && t === "board" ? 1 : e.mode === "duel" && !e.board.length ? 4 : 3, a = r.includes(n) ? r.filter((e) => e !== n) : i === 1 ? [n] : r.length < i ? [...r, n] : r;
		w({
			...O,
			[t]: a
		});
	}, L = (e) => {
		i?.(e), w({
			scope: "",
			hand: [],
			board: []
		});
	}, re = e.phase === "roundOver" ? y("games.woo.roundOver", { name: b(e.results.at(-1).by) }) : e.phase === "settle" ? y("games.woo.settle") : s ? y("games.woo.review") : k ? y(e.phase === "reserve" ? "games.woo.reserve" : e.phase === "return" ? "games.woo.return" : e.phase === "complete" ? "games.woo.complete" : e.target ? "games.woo.respond" : "games.woo.lead") : y("games.woo.wait", { name: b(e.turn) }), R = k && (e.phase === "reserve" || e.mode === "duel" && (e.phase === "complete" || e.phase === "lead" && !!e.target)), z = k && e.phase === "return", { ref: B } = o("partial"), { ref: V } = o("target"), { ref: H } = o("board"), { ref: U } = o("stock"), { ref: W } = o("discard"), { ref: G } = o("hand"), K = e.players.find((e) => e.rid === r), q = e.players.find((e) => e.team === K?.team && e.rid !== r);
	return /* @__PURE__ */ _(m, {
		adaptive: !0,
		scroll: !1,
		className: "woo-screen",
		actionsHeight: "woo-actions-height",
		banner: /* @__PURE__ */ v("header", {
			className: "woo-header",
			children: [/* @__PURE__ */ v("div", {
				className: "woo-masthead",
				children: [
					/* @__PURE__ */ v("strong", {
						className: "woo-logo",
						children: ["Woo", /* @__PURE__ */ _("span", {
							"aria-hidden": !0,
							children: "♥"
						})]
					}),
					/* @__PURE__ */ _("span", { children: y("games.woo.round", { n: e.round }) }),
					/* @__PURE__ */ _("button", {
						type: "button",
						"aria-label": y("games.woo.history"),
						onClick: () => S(!0),
						children: /* @__PURE__ */ _(d, { size: 20 })
					})
				]
			}), /* @__PURE__ */ _("div", {
				className: "woo-teams",
				children: [0, 1].map((t) => /* @__PURE__ */ v("section", {
					className: `woo-team woo-team-${t}`,
					children: [/* @__PURE__ */ _("div", {
						className: "woo-team-members",
						children: e.players.filter((e) => e.team === t).map((t) => {
							let i = n.find((e) => e.rid === t.rid);
							return /* @__PURE__ */ v("div", {
								className: "woo-seat",
								"data-active": e.turn === t.rid && !s && e.phase !== "roundOver",
								children: [
									i && /* @__PURE__ */ _(h, {
										m: i,
										myRid: r,
										action: k && t.rid === r ? "pending" : t.ready ? "done" : null,
										anchorName: `seat:${t.rid}`,
										box: "size-8",
										img: "size-7"
									}),
									/* @__PURE__ */ _("span", {
										className: "woo-seat-name",
										children: b(t.rid)
									}),
									/* @__PURE__ */ _("small", { children: y("games.woo.cards", { n: t.handCount }) })
								]
							}, t.rid);
						})
					}), /* @__PURE__ */ _(ve, {
						team: t,
						score: e.scores[t]
					})]
				}, t))
			})]
		}),
		actions: /* @__PURE__ */ v("div", {
			className: "woo-bottom",
			children: [/* @__PURE__ */ v("div", {
				className: "woo-controls",
				children: [/* @__PURE__ */ _("span", {
					className: "woo-phase",
					role: "status",
					children: re
				}), /* @__PURE__ */ v("div", {
					className: "woo-buttons",
					children: [
						j && /* @__PURE__ */ _("button", {
							type: "button",
							className: "woo-primary",
							onClick: () => L({ type: "next" }),
							children: y("games.woo.next")
						}),
						k && (e.phase === "lead" || e.phase === "complete" && e.mode === "teams") && /* @__PURE__ */ _("button", {
							type: "button",
							className: "woo-primary",
							disabled: !F,
							onClick: () => L({
								type: "play",
								cards: N
							}),
							children: y(e.phase === "complete" ? "games.woo.add" : "games.woo.play")
						}),
						k && e.phase === "complete" && /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => L({ type: "pass" }),
							children: y("games.woo.pass")
						}),
						k && e.phase === "lead" && e.target && /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => L({
								type: "concede",
								card: null
							}),
							children: y("games.woo.concede")
						}),
						O.hand.length > 0 && /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => w({
								scope: "",
								hand: [],
								board: []
							}),
							children: y("games.woo.clear")
						})
					]
				})]
			}), t && !s && /* @__PURE__ */ v("div", {
				className: "woo-hand-wrap",
				children: [/* @__PURE__ */ v("div", {
					className: "woo-hand-label",
					children: [/* @__PURE__ */ _("span", { children: y("games.woo.hand") }), q && /* @__PURE__ */ _("small", { children: y("games.woo.partner", { name: b(q.rid) }) })]
				}), /* @__PURE__ */ _("div", {
					ref: G,
					className: "woo-hand",
					children: M.map((t, n) => /* @__PURE__ */ _("div", {
						className: n > 0 && T(M[n - 1]) === T(t) ? "woo-duplicate" : "",
						children: /* @__PURE__ */ _(Y, {
							card: t,
							zone: "hand",
							selected: O.hand.includes(t),
							onPick: k && (e.phase === "lead" || e.phase === "complete" && e.mode === "teams") ? () => I("hand", t) : void 0
						})
					}, t))
				})]
			})]
		}),
		overlay: x && /* @__PURE__ */ _("div", {
			className: "woo-shade woo-history-shade",
			children: /* @__PURE__ */ v("section", {
				className: "woo-history",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": y("games.woo.history"),
				children: [/* @__PURE__ */ v("header", { children: [/* @__PURE__ */ _("h2", { children: y("games.woo.history") }), /* @__PURE__ */ _("button", {
					type: "button",
					"aria-label": y("games.woo.close"),
					onClick: () => S(!1),
					children: /* @__PURE__ */ _(u, {})
				})] }), /* @__PURE__ */ _("ol", { children: e.history.map((e) => /* @__PURE__ */ _("li", { children: y(e.type === "play" ? "games.woo.logPlay" : e.type === "complete" ? "games.woo.logComplete" : e.type === "pass" ? "games.woo.logPass" : e.type === "concede" ? "games.woo.logConcede" : "games.woo.logTake", {
					name: b(e.by),
					cards: e.cards.map(T).join(" · "),
					recipient: e.recipient ? b(e.recipient) : ""
				}) }, e.seq)) })]
			})
		}),
		children: /* @__PURE__ */ v("main", {
			className: "woo-table",
			children: [/* @__PURE__ */ v("div", {
				className: "woo-melds",
				children: [/* @__PURE__ */ v("section", {
					className: "woo-meld",
					children: [/* @__PURE__ */ v("h2", { children: [y("games.woo.target"), e.target && /* @__PURE__ */ _("small", { children: y("games.woo.meld", {
						kind: y(`games.woo.${e.target.meld.kind}`),
						n: e.target.meld.size
					}) })] }), /* @__PURE__ */ _("div", {
						ref: V,
						className: "woo-card-row",
						children: e.target?.cards.map((e) => /* @__PURE__ */ _(Y, {
							zone: "target",
							card: e
						}, e)) ?? /* @__PURE__ */ _("span", {
							className: "woo-empty",
							children: "♥"
						})
					})]
				}), /* @__PURE__ */ v("section", {
					className: "woo-meld woo-partial",
					children: [/* @__PURE__ */ _("h2", { children: y("games.woo.partial") }), /* @__PURE__ */ _("div", {
						ref: B,
						className: "woo-card-row",
						children: e.partial.length ? e.partial.map((e) => /* @__PURE__ */ _(Y, {
							zone: "partial",
							card: e,
							eligible: z,
							onPick: z ? () => L({
								type: "take",
								card: e,
								recipient: r
							}) : void 0
						}, e)) : /* @__PURE__ */ _("span", {
							className: "woo-empty",
							children: y("games.woo.empty")
						})
					})]
				})]
			}), /* @__PURE__ */ v("section", {
				className: "woo-board-area",
				children: [/* @__PURE__ */ v("div", {
					className: "woo-board-meta",
					children: [/* @__PURE__ */ _("span", {
						ref: U,
						children: e.mode === "duel" && y("games.woo.stock", { n: e.stockCount })
					}), /* @__PURE__ */ _("span", {
						ref: W,
						children: y("games.woo.discard", { n: e.discarded.length })
					})]
				}), (e.board.length > 0 || e.mode === "duel") && /* @__PURE__ */ v(g, { children: [
					/* @__PURE__ */ _("h2", { children: y("games.woo.board") }),
					/* @__PURE__ */ _("div", {
						ref: H,
						className: "woo-board woo-card-row",
						children: e.board.map((e) => /* @__PURE__ */ _(Y, {
							zone: "board",
							card: e,
							eligible: R,
							selected: O.board.includes(e),
							onPick: R ? () => I("board", e) : void 0
						}, e))
					}),
					/* @__PURE__ */ v("div", {
						className: "woo-board-tools",
						children: [
							k && e.phase === "reserve" && e.players.filter((e) => e.team === K?.team).map((e) => /* @__PURE__ */ _("button", {
								type: "button",
								disabled: O.board.length !== 1,
								onClick: () => L({
									type: "take",
									card: O.board[0],
									recipient: e.rid
								}),
								children: y("games.woo.give", { name: b(e.rid) })
							}, e.rid)),
							k && e.phase === "complete" && e.mode === "duel" && /* @__PURE__ */ _("button", {
								type: "button",
								className: "woo-primary",
								disabled: !F,
								onClick: () => L({
									type: "play",
									cards: O.board
								}),
								children: y("games.woo.add")
							}),
							k && e.phase === "lead" && e.mode === "duel" && e.target && O.board.length === 1 && /* @__PURE__ */ _("button", {
								type: "button",
								onClick: () => L({
									type: "concede",
									card: O.board[0]
								}),
								children: y("games.woo.concedeTake")
							})
						]
					})
				] })]
			})]
		})
	});
}
function ve({ team: e, score: t }) {
	let n = l(), { ref: r, hidden: i } = o(`score:${e}`);
	return /* @__PURE__ */ v("div", {
		ref: r,
		className: "woo-score",
		style: { visibility: i ? "hidden" : void 0 },
		"aria-label": n("games.woo.score", { n: t }),
		children: [/* @__PURE__ */ v("span", {
			"aria-hidden": !0,
			children: [t > 0 ? "♥" : "♡", t > 1 ? "♥" : "♡"]
		}), /* @__PURE__ */ _("b", { children: t })]
	});
}
//#endregion
//#region src/games/woo/bot.ts
var ye = {
	shed: 5,
	completion: 8,
	reserve: .12
};
function be(e = ye) {
	return ({ public: t, private: n }, r) => {
		if (!n) return null;
		let i = fe(t, n, r.rid);
		if (!i.length) return null;
		let a = t.players.find((e) => e.rid === r.rid).team, o = t.players.find((e) => e.team === a && e.rid !== r.rid), s = t.history.reduce((e, t, n) => t.type === "complete" ? n : e, -1), c = new Set(t.history.slice(s + 1).filter((e, t, n) => e.type === "play" && e.by === r.rid && n[t + 1]?.type === "pass").map((e) => e.cards.map(T).sort().join(","))), l = [
			...n.hand,
			...t.discarded,
			...t.partial,
			...t.board,
			...t.target?.cards ?? []
		], u = Array.from({ length: 9 }, (e, t) => 6 - l.filter((e) => T(e) === t + 1).length), d = u.reduce((e, t) => e + t, 0);
		function f(e) {
			return t.mode === "duel" ? +!!N(e, t.board, t.target?.meld ?? null).length : Math.max(0, ...A(e, t.target?.meld ?? null).map(({ values: t }) => {
				let n = k(e, t);
				return Array.from({ length: 9 }, (e, t) => n.filter((e) => e === t + 1).length).reduce((e, t, n) => {
					if (!t) return e;
					let r = Math.min(1, (o?.handCount ?? 0) / Math.max(1, d)), i = u[n], a = 0;
					for (let e = 0; e < t; e++) {
						let t = 1;
						for (let n = 1; n <= e; n++) t *= (i - n + 1) / n;
						a += t * r ** e * (1 - r) ** (i - e);
					}
					return e * Math.max(0, 1 - a);
				}, 1);
			}));
		}
		function p(i) {
			if (i.type === "next") return 0;
			if (i.type === "pass") return -100;
			if (i.type === "concede") return i.card === null ? -90 : -95;
			if (i.type === "take") {
				let e = T(i.card), a = n.hand.filter((t) => T(t) === e).length;
				return t.phase === "reserve" ? i.recipient === r.rid ? 2 * a + e * .1 : (n.hand.length - (o?.handCount ?? 0)) * .5 : r.difficulty === "weak" ? -e : -(e + a * 2);
			}
			if (i.type !== "play") return -1e3;
			let a = t.phase === "lead" && c.has(i.cards.map(T).sort().join(",")) ? 200 : 0, s = t.phase === "complete" && t.mode === "duel" ? 0 : i.cards.length;
			if (s === n.hand.length) return 1e4;
			let l = i.cards.reduce((e, t) => e + T(t), 0);
			if (r.difficulty === "weak") return 10 - i.cards.length * .5 - l * .01;
			if (t.phase === "lead" && (t.mode !== "duel" || t.board.length)) {
				let t = f(i.cards);
				return e.shed * s * t + e.completion * t - (1 - t) * i.cards.length - e.reserve * l - a;
			}
			let u = E([...t.partial, ...i.cards]);
			return 20 + e.shed * s - e.reserve * l - (u?.kind === "bomb" ? .5 : 0);
		}
		let m = i[0], h = -Infinity;
		for (let e of i) {
			let t = p(e);
			t > h && (m = e, h = t);
		}
		return { action: m };
	};
}
var xe = be(), Se = (e, t, n) => e.type === "play" ? n("games.woo.hintPlay", { cards: e.cards.map(T).join(" · ") }) : e.type === "take" ? n("games.woo.hintTake", { n: T(e.card) }) : e.type === "concede" ? n("games.woo.concede") : e.type === "pass" ? n("games.woo.pass") : n("games.woo.next"), X = (e) => e.data && typeof e.data == "object" && !Array.isArray(e.data) ? e.data : {}, Z = (e) => Array.isArray(e) ? e.filter((e) => Number.isInteger(e)) : [];
function Q(e, t, n = 0, r = 1) {
	let i = e.anchor(t);
	if (!i) return null;
	let a = Math.min(t === "board" ? 100 : 142, i.h / 1.4);
	return {
		x: i.x + i.w / 2 + (n - (r - 1) / 2) * (a + 7) - a / 2,
		y: i.y + (i.h - a * 1.4) / 2,
		w: a,
		h: a * 1.4
	};
}
function $({ card: e, from: t, to: n, ms: a, delay: o = 0, back: s = !1, fade: c = !1 }) {
	let l = i(null);
	return r(() => {
		if (!c) return;
		let e = l.current?.animate([
			{ opacity: 1 },
			{
				opacity: 1,
				offset: .6
			},
			{ opacity: 0 }
		], {
			duration: a,
			delay: o,
			fill: "both"
		});
		return () => e?.cancel();
	}, [
		c,
		a,
		o
	]), /* @__PURE__ */ _("div", {
		ref: l,
		style: {
			"--woo-card-w": `${t.w}px`,
			"--woo-card-h": `${t.h}px`
		},
		children: /* @__PURE__ */ _(te, {
			from: t,
			to: n,
			ms: a,
			delay: o,
			children: /* @__PURE__ */ _(he, {
				card: e,
				back: s
			})
		})
	});
}
var Ce = {
	deal(e, t) {
		let n = t.anchor("stock") ?? t.anchor("board") ?? t.anchor("partial"), r = t.anchor("hand") ?? t.anchor(`seat:${t.myRid}`);
		return !n || !r ? null : {
			ms: 430,
			node: [
				0,
				1,
				2,
				3
			].map((e) => /* @__PURE__ */ _($, {
				card: 0,
				from: {
					...n,
					w: 45,
					h: 63
				},
				to: {
					x: r.x + r.w / 2 - 25 + e * 12,
					y: r.y,
					w: 50,
					h: 70
				},
				ms: 300,
				delay: e * 30,
				back: !0,
				fade: !0
			}, e))
		};
	},
	play(e, t) {
		let n = Z(X(e).cards), r = Z(X(e).partialCards), i = Z(X(e).previous), a = X(e).destination === "target" ? "target" : "partial", o = t.queued ? 180 : z.play - 20, s = [...r, ...n].map((i, s) => {
			let c = t.anchor(`${a}:${i}`) ?? Q(t, a, s, n.length + r.length), l = s < r.length ? "partial" : X(e).source === "board" ? "board" : e.rid === t.myRid ? "hand" : `seat:${e.rid}`, u = t.anchor(`origin:${l}:${i}`) ?? t.anchor(`${l}:${i}`) ?? Q(t, l, s < r.length ? s : s - r.length, s < r.length ? r.length : n.length);
			return u && c ? /* @__PURE__ */ _($, {
				card: i,
				from: u,
				to: c,
				ms: o
			}, i) : null;
		}), c = t.anchor("discard");
		return i.forEach((e, n) => {
			let r = t.anchor(`origin:target:${e}`) ?? Q(t, "target", n, i.length);
			r && c && s.push(/* @__PURE__ */ _($, {
				card: e,
				from: r,
				to: {
					...c,
					w: 25,
					h: 35
				},
				ms: o * .8,
				fade: !0
			}, `old${e}`));
		}), {
			ms: o,
			node: s,
			hide: t.queued ? [] : [...r, ...n].map((e) => `${a}:${e}`)
		};
	},
	take(e, t) {
		let n = Z(X(e).cards), r = X(e).source === "partial" ? "partial" : "board", i = t.queued ? 180 : 370;
		return {
			ms: i,
			node: n.map((a, o) => {
				let s = t.anchor(`origin:${r}:${a}`) ?? Q(t, r, o, n.length), c = e.rid === t.myRid ? t.anchor(`hand:${a}`) : null, l = e.rid === t.myRid ? t.anchor("hand") : t.anchor(`seat:${e.rid}`), u = c ?? (l ? {
					...l,
					w: e.rid === t.myRid ? 76 : 30,
					h: e.rid === t.myRid ? 106 : 42
				} : null);
				return s && u ? /* @__PURE__ */ _($, {
					card: a,
					from: s,
					to: u,
					ms: i,
					back: e.rid !== t.myRid
				}, a) : null;
			}),
			hide: !t.queued && e.rid === t.myRid ? n.map((e) => `hand:${e}`) : []
		};
	},
	clear(e, t) {
		let n = Z(X(e).cards), r = X(e).source === "partial" ? "partial" : "target", i = t.anchor("discard"), a = t.queued ? 160 : z.clear - 20;
		return !i || !n.length ? null : {
			ms: a,
			node: n.map((e, o) => {
				let s = t.anchor(`origin:${r}:${e}`) ?? Q(t, r, o, n.length);
				return s ? /* @__PURE__ */ _($, {
					card: e,
					from: s,
					to: {
						...i,
						w: 22,
						h: 31
					},
					ms: a,
					fade: !0
				}, e) : null;
			})
		};
	},
	refill(e, t) {
		let n = Z(X(e).cards), r = t.anchor("stock"), i = t.queued ? 170 : z.draw - 20;
		return r ? {
			ms: i,
			node: n.map((e, n) => {
				let a = t.anchor(`board:${e}`);
				return a ? /* @__PURE__ */ _($, {
					card: e,
					from: {
						...r,
						w: 45,
						h: 63
					},
					to: a,
					ms: i - 30,
					delay: n * 10
				}, e) : null;
			}),
			hide: t.queued ? [] : n.map((e) => `board:${e}`)
		} : null;
	},
	score(e, t) {
		let n = t.anchor(`score:${X(e).team}`);
		return n ? {
			ms: z.score - 20,
			node: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(b, {
				at: n,
				ms: z.score - 20
			}), /* @__PURE__ */ _(y, {
				at: n,
				ms: z.score - 20,
				children: /* @__PURE__ */ _("span", {
					style: {
						color: "#cc5541",
						fontSize: 28
					},
					children: "♥ +1"
				})
			})] })
		} : null;
	}
};
//#endregion
//#region src/games/woo/game-over.tsx
function we({ public: e, private: t, result: n, members: r, myRid: i, hintCount: o, onPlayAgain: s, onBackToLobby: d }) {
	let f = e, p = l(), m = c((e) => e.locale), [h, g] = a(!0), y = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? ee(t, m) : p("games.woo.unknownPlayer");
	};
	return /* @__PURE__ */ v("div", {
		className: "woo-final",
		children: [
			/* @__PURE__ */ _(S, {}),
			/* @__PURE__ */ _("div", {
				inert: h,
				style: { height: "100%" },
				children: /* @__PURE__ */ _(_e, {
					pub: f,
					priv: t,
					members: r,
					myRid: i,
					review: !0
				})
			}),
			/* @__PURE__ */ _("button", {
				className: "woo-final-reopen",
				type: "button",
				hidden: h,
				onClick: () => g(!0),
				children: p("games.woo.result")
			}),
			/* @__PURE__ */ _("div", {
				className: "woo-shade woo-result-shade",
				hidden: !h,
				children: /* @__PURE__ */ v("section", {
					className: "woo-result-panel",
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "woo-result-title",
					children: [
						/* @__PURE__ */ v("header", { children: [/* @__PURE__ */ _("h1", {
							id: "woo-result-title",
							children: p("games.woo.resultTitle")
						}), /* @__PURE__ */ _("button", {
							type: "button",
							"aria-label": p("games.woo.review"),
							onClick: () => g(!1),
							children: /* @__PURE__ */ _(u, {})
						})] }),
						/* @__PURE__ */ v("div", {
							className: "woo-result-content",
							children: [
								/* @__PURE__ */ _("p", {
									className: "woo-winners",
									children: p("games.woo.won", { names: n.winner.map(y).join(" & ") })
								}),
								/* @__PURE__ */ _("div", {
									className: "woo-result-scores",
									children: [0, 1].map((e) => /* @__PURE__ */ v("article", {
										"data-win": f.players.some((t) => t.team === e && n.winner.includes(t.rid)),
										children: [/* @__PURE__ */ _("span", { children: f.players.filter((t) => t.team === e).map((e) => y(e.rid)).join(" & ") }), /* @__PURE__ */ _("strong", {
											"aria-label": p("games.woo.score", { n: f.scores[e] }),
											children: f.scores[e]
										})]
									}, e))
								}),
								f.results.map((e) => /* @__PURE__ */ v("section", {
									className: "woo-round-result",
									children: [/* @__PURE__ */ _("p", { children: p("games.woo.resultRound", {
										n: e.round,
										name: y(e.by)
									}) }), /* @__PURE__ */ _("div", {
										className: "woo-card-row",
										children: e.cards.map((e) => /* @__PURE__ */ _(he, { card: e }, e))
									})]
								}, e.round)),
								/* @__PURE__ */ v("div", {
									className: "woo-result-usage",
									children: [o !== void 0 && /* @__PURE__ */ _("p", { children: p("session.hint.usedCount", { n: o }) }), Object.entries(n.autopilot ?? {}).filter(([, e]) => e > 0).map(([e, t]) => /* @__PURE__ */ v("p", { children: [
										y(e),
										" · ",
										p("session.autopilot.share", { n: Math.round(t * 100) })
									] }, e))]
								})
							]
						}),
						/* @__PURE__ */ v("footer", {
							className: "woo-result-actions",
							children: [
								/* @__PURE__ */ _("button", {
									type: "button",
									onClick: () => g(!1),
									children: p("games.woo.review")
								}),
								s && /* @__PURE__ */ _(x, {
									label: p("session.result.playAgain"),
									confirmLabel: p("games.woo.confirmAgain"),
									onConfirm: s
								}),
								d && /* @__PURE__ */ _(x, {
									label: p("session.result.backToLobby"),
									confirmLabel: p("games.woo.confirmBack"),
									onConfirm: d
								}),
								!s && !d && /* @__PURE__ */ _("span", { children: p("session.result.waitHost") })
							]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/woo/options.tsx
function Te({ value: e, onChange: t }) {
	let n = l(), r = I.safeParse(e), i = r.success ? r.data : I.parse(void 0);
	return /* @__PURE__ */ _(ne, {
		title: n("games.woo.mode"),
		columns: 2,
		children: ["teams", "duel"].map((e) => /* @__PURE__ */ _(C, {
			name: "woo-mode",
			value: e,
			checked: i.mode === e,
			label: n(e === "teams" ? "games.woo.teams" : "games.woo.duel"),
			accent: "#117d8c",
			onChange: () => t({ mode: e })
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/woo/entry.tsx
var Ee = {
	definition: de,
	View: ge,
	bot: xe,
	describe: Se,
	fx: Ce,
	OverView: we,
	Options: Te,
	locales: {
		zh: {
			name: "Woo",
			unknownPlayer: "旅鸟",
			desc: "与搭档补全天堂鸟的求偶牌型，抢先出完手牌。也可通过公共牌区进行双人对战。",
			rules: "目标：\n4 人分为两队，隔座为搭档；2 人各自为战。任意一名玩家出完手牌，其所属方赢得本轮并获得 1 分，先获得 2 分的一方获胜。\n准备：\n54 张牌为数字 1–9 各 6 张。每人发 13 张。4 人时公开剩余 2 张：首攻者左侧的玩家先选 1 张，并决定交给自己或搭档；下一名玩家分配最后一张。首轮随机决定首攻者，以后由上轮出完牌者左侧的玩家首攻。\n牌型：\n· 同点组：2 或 3 张相同数字。\n· 顺子：2–4 张连续数字，不可循环。\n· 连对：两个连续数字各 2 张。\n· 爱情炸弹：4 张相同数字，可压过其他任何牌型；更大的爱情炸弹可压过较小的爱情炸弹。\n出牌流程：\n首攻者打出 1–3 张可由其他牌补全的部分牌型，搭档再添加 1–3 张，使之成为完整牌型；也可以放弃补全。牌型完成后，由首攻者左侧的对手出牌，再由其搭档补全。回应必须组成同种、同张数且数字更大的牌型，也可改用爱情炸弹。顺子与连对比较其中最大的数字。\n放弃与认输：\n无法或不愿补全时，可以放弃。原先打出的部分牌型由首攻者开始，与搭档轮流各取回 1 张，不能讨论如何分配；部分牌型只有 1 张时，改为弃掉该牌。此前完整牌型一并弃掉。面对对方完整牌型时，可直接认输并弃掉此前牌型。放弃或认输者左侧的玩家成为新首攻者。\n双人规则：\n每人 13 张，另翻开 4 张作为公共牌，其余为牌堆。打出 1–3 张手牌后，自己从公共牌中加入至少 1 张、至多 3 张补全。每次完成牌型后，将公共牌补至 4 张，牌堆耗尽后不再补充。认输时可以选取 1 张公共牌加入手牌。放弃补全时，多张部分牌型全部取回；单张仍弃掉。\n公共牌全部耗尽后，直接以自己的手牌组成完整牌型；首攻时如手牌无法组成任何完整牌型，必须领出单张。单张只能由更大的单张或爱情炸弹回应。\n轮末：\n打出最后的手牌后立即赢得本轮，包括合法的部分牌型。未有一方达到 2 分时，全体确认后重新洗牌，开始下一轮。",
			mode: "对战模式",
			teams: "四人搭档",
			duel: "双人对战",
			round: "第 {{n}} 轮",
			score: "{{n}} 分",
			cards: "{{n}} 张",
			stock: "牌堆 {{n}} 张",
			reserve: "分配公开牌",
			lead: "打出部分牌型",
			respond: "回应场上牌型",
			complete: "补全牌型",
			return: "取回 1 张牌",
			wait: "等待 {{name}}",
			turn: "{{name}}行动",
			settle: "结算中",
			roundOver: "{{name}}出完了手牌",
			board: "公共牌",
			partial: "待补全",
			target: "当前牌型",
			hand: "我的手牌",
			discard: "弃牌 {{n}} 张",
			play: "打出所选牌",
			add: "补全所选牌",
			pass: "放弃补全",
			concede: "认输",
			concedeTake: "认输并拿取所选公共牌",
			give: "交给 {{name}}",
			take: "取回此牌",
			next: "下一轮",
			ready: "已准备",
			clear: "取消选择",
			hintPlay: "打出 {{cards}}。",
			hintTake: "选取数字 {{n}} 的牌。",
			errTurn: "当前不能执行此行动。",
			errCard: "请选择当前可用的牌和接收者。",
			errMeld: "所选牌无法组成符合要求的牌型。",
			errMove: "此阶段不能执行该行动。",
			selectCard: "数字 {{n}} 的牌",
			empty: "等待出牌",
			noPrivate: "等待手牌",
			set: "同点组",
			run: "顺子",
			stairs: "连对",
			bomb: "爱情炸弹",
			single: "单张",
			meld: "{{kind}} · {{n}} 张",
			teamMembers: "{{names}}",
			partner: "搭档：{{name}}",
			resultTitle: "求偶成功",
			won: "{{names}}获胜",
			resultRound: "第 {{n}} 轮 · {{name}}先出完手牌",
			review: "查看最终牌桌",
			result: "查看赛果",
			confirmAgain: "确认再来一局",
			confirmBack: "确认返回大厅",
			history: "出牌记录",
			close: "关闭",
			logPlay: "{{name}}打出 {{cards}}",
			logComplete: "{{name}}补全 {{cards}}",
			logPass: "{{name}}放弃补全",
			logConcede: "{{name}}认输",
			logTake: "{{name}}拿取 {{cards}}，交给{{recipient}}"
		},
		en: {
			name: "Woo",
			unknownPlayer: "Wanderer",
			desc: "Finish your partner’s bird-of-paradise melds and shed your hand first. Includes a two-player board variant.",
			rules: "Goal:\nFour players form two partnerships, seated opposite each other; two players compete individually. The first player to shed every card earns their side 1 point. The first side to 2 points wins.\nSetup:\nThe deck contains six copies each of 1–9, for 54 cards. Deal 13 cards per player. With four players, reveal the remaining two cards. The player left of the lead player picks a card and gives it to themselves or their partner. The next player clockwise assigns the final card. The first lead player is chosen randomly. Later rounds are led by the player left of the previous round’s finisher.\nMelds:\n· Set: two or three cards of one value.\n· Run: two to four consecutive values, without wrapping.\n· Stairs: two consecutive pairs.\n· Love Bomb: four cards of one value. A Love Bomb beats any other meld; only a higher Love Bomb beats a Love Bomb.\nPlay:\nThe lead player plays one to three cards that could be completed into a meld. Their partner adds one to three cards to complete a legal meld, or passes. Once completed, the player left of the lead player responds with a partial meld for their partner to complete. Responses must have the same type and size with higher values, or be a Love Bomb. Runs and stairs compare their highest value.\nPassing and conceding:\nAfter a pass, partners draft the partial meld back into their hands, one card at a time, starting with the player who led it. Partners cannot discuss the draft. A one-card partial meld is discarded instead. Previous complete melds are also discarded. The player facing an opposing meld may concede and discard all previous melds. After a pass or concession, the player left of the passing or conceding player leads a new partial meld.\nTwo players:\nDeal 13 cards each, reveal four cards as the Board, and keep the rest as a draw pile. Play one to three hand cards, then complete your own meld using one to three Board cards. Refill the Board to four after each valid meld until the draw pile is empty. When conceding, you may take one Board card into your hand. After passing, return a multi-card partial meld to your own hand; discard a single-card partial meld.\nAfter the Board is empty, form complete melds from your own hand. If the lead player has no valid meld, they must lead a single card. A single card may only be beaten by a higher single or a Love Bomb.\nRound end:\nPlaying your final hand card immediately wins the round, including as part of a legal partial meld. If neither side has 2 points, all players confirm, reshuffle, and start the next round.",
			mode: "Game mode",
			teams: "Four-player teams",
			duel: "Two-player duel",
			round: "Round {{n}}",
			score: "{{n}} points",
			cards: "{{n}} cards",
			stock: "Draw pile: {{n}}",
			reserve: "Assign a revealed card",
			lead: "Lead a partial meld",
			respond: "Respond to the meld",
			complete: "Complete the meld",
			return: "Take back one card",
			wait: "Waiting for {{name}}",
			turn: "{{name}} to play",
			settle: "Resolving",
			roundOver: "{{name}} shed their hand",
			board: "Board",
			partial: "Partial meld",
			target: "Current meld",
			hand: "Your hand",
			discard: "{{n}} discarded",
			play: "Play selected cards",
			add: "Complete selected meld",
			pass: "Pass",
			concede: "Concede",
			concedeTake: "Concede and take selected Board card",
			give: "Give to {{name}}",
			take: "Take this card",
			next: "Next round",
			ready: "Ready",
			clear: "Clear selection",
			hintPlay: "Play {{cards}}.",
			hintTake: "Take a {{n}}.",
			errTurn: "You cannot act right now.",
			errCard: "Choose available cards and a valid recipient.",
			errMeld: "These cards cannot form the required meld.",
			errMove: "That action is unavailable in this phase.",
			selectCard: "Card with value {{n}}",
			empty: "Waiting for a lead",
			noPrivate: "Waiting for your hand",
			set: "Set",
			run: "Run",
			stairs: "Stairs",
			bomb: "Love Bomb",
			single: "Single",
			meld: "{{kind}} · {{n}} cards",
			teamMembers: "{{names}}",
			partner: "Partner: {{name}}",
			resultTitle: "A perfect match",
			won: "{{names}} won",
			resultRound: "Round {{n}} · {{name}} shed first",
			review: "Review the final table",
			result: "Show results",
			confirmAgain: "Play again?",
			confirmBack: "Return to lobby?",
			history: "Play history",
			close: "Close",
			logPlay: "{{name}} played {{cards}}",
			logComplete: "{{name}} completed with {{cards}}",
			logPass: "{{name}} passed",
			logConcede: "{{name}} conceded",
			logTake: "{{name}} took {{cards}} for {{recipient}}"
		}
	}
};
//#endregion
export { Ee as default };
