import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r } from "react";
import { AVATARS as i } from "@bgparty/sdk/avatars";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as o } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as f, seatName as p } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Flash as _, Floater as v, FlySprite as y, PulseBox as b } from "@bgparty/sdk/fx/primitives";
import { playSettle as x } from "@bgparty/sdk/sfx";
import { IconBot as S } from "@bgparty/sdk/icons";
import { Confetti as C } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as w } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/lasvegas/meta.ts
var T = {
	id: "lasvegas",
	tier: "beta",
	mechanics: ["dice-rolling", "area-control"],
	interactionTags: [],
	nameKey: "games.lasvegas.name",
	descKey: "games.lasvegas.desc",
	rulesKey: "games.lasvegas.rules",
	icon: "🎲",
	iconImg: "games/lasvegas.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/lasvegas/en.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#9333ea",
	releasedAt: "2026-09-21",
	search: {
		py: "la si wei jia si",
		init: "lswjs"
	},
	hotseat: "open"
}, E = t.int().min(1).max(6), D = t.int().min(10).max(90), O = t.string(), k = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("place"),
		value: E
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), A = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"play",
		"payout",
		"done"
	]),
	turn: O.nullable(),
	rolled: t.array(E).nullable(),
	casinos: t.tuple([
		t.array(D),
		t.array(D),
		t.array(D),
		t.array(D),
		t.array(D),
		t.array(D)
	]),
	placed: t.tuple([
		t.record(t.string(), t.int().nonnegative()),
		t.record(t.string(), t.int().nonnegative()),
		t.record(t.string(), t.int().nonnegative()),
		t.record(t.string(), t.int().nonnegative()),
		t.record(t.string(), t.int().nonnegative()),
		t.record(t.string(), t.int().nonnegative())
	]),
	players: t.array(t.object({
		rid: O,
		money: t.int().nonnegative(),
		notes: t.int().nonnegative(),
		diceLeft: t.int().nonnegative()
	})),
	payoutIdx: t.int()
}), j = t.object({}), ee = [
	...[
		,
		,
		,
		,
		,
		,
	].fill(10),
	...Array(8).fill(20),
	...Array(8).fill(30),
	...[
		,
		,
		,
		,
		,
		,
	].fill(40),
	...[
		,
		,
		,
		,
		,
		,
	].fill(50),
	...[
		,
		,
		,
		,
		,
	].fill(60),
	...[
		,
		,
		,
		,
		,
	].fill(70),
	...[
		,
		,
		,
		,
		,
	].fill(80),
	...[
		,
		,
		,
		,
		,
	].fill(90)
], M = {
	payout: 1300,
	supply: 900
};
function N(e, t) {
	let n = t.reduce((e, t) => e + t, 0);
	for (; n < 50 && e.length > 0;) {
		let r = e.shift();
		t.push(r), n += r;
	}
	t.sort((e, t) => t - e);
}
function te(t, n, r) {
	let i = [...ee], a = 0;
	for (let t = i.length - 1; t > 0; --t) {
		let n = e(r, a, t + 1);
		a += 1, [i[t], i[n]] = [i[n], i[t]];
	}
	let o = Array.from({ length: 6 }, () => []);
	for (let e of o) N(i, e);
	let s = {}, c = {}, l = {};
	for (let e of n) s[e] = 8, c[e] = 0, l[e] = 0;
	return {
		state: {
			players: n,
			round: 1,
			startIdx: 0,
			turnIdx: 0,
			diceLeft: s,
			rolled: null,
			casinos: o,
			placed: Array.from({ length: 6 }, () => ({})),
			money: c,
			noteCounts: l,
			pile: i,
			phase: "play",
			payoutIdx: -1,
			beatMs: 0,
			seed: r,
			rngCursor: a
		},
		fx: o.map((e, t) => ({
			kind: "supply",
			data: {
				casino: t,
				notes: e
			},
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function ne(e, t) {
	for (let n = 1; n <= e.players.length; n += 1) {
		let r = (t + n) % e.players.length;
		if (e.diceLeft[e.players[r]] > 0) return r;
	}
	return null;
}
function re(e, t) {
	let n = Object.entries(e.placed[t]).filter(([, e]) => e > 0), r = /* @__PURE__ */ new Map();
	for (let [, e] of n) r.set(e, (r.get(e) ?? 0) + 1);
	let i = n.filter(([, e]) => (r.get(e) ?? 0) > 1).map(([e, t]) => ({
		rid: e,
		count: t
	})), a = n.filter(([, e]) => r.get(e) === 1).sort((e, t) => t[1] - e[1]), o = [], s = e.casinos[t];
	for (let t = 0; t < a.length && t < s.length; t += 1) {
		let n = a[t][0];
		e.money[n] += s[t], e.noteCounts[n] += 1, o.push({
			rid: n,
			note: s[t]
		});
	}
	let c = s.slice(o.length);
	for (let t of c) e.pile.push(t);
	return e.casinos[t] = [], e.placed[t] = {}, {
		kind: "payout",
		data: {
			casino: t,
			busted: i,
			awards: o,
			leftover: c
		}
	};
}
function P(t, n, r) {
	if (n.type === "tick") {
		if (t.phase !== "payout") return {
			state: t,
			fx: []
		};
		let e = structuredClone(t), n = [re(e, e.payoutIdx)];
		if (e.payoutIdx += 1, e.payoutIdx < 6) return e.beatMs = M.payout, {
			state: e,
			fx: n
		};
		if (e.payoutIdx = -1, e.round >= 4) return e.phase = "done", e.turnIdx = -1, {
			state: e,
			fx: n
		};
		e.round += 1, e.startIdx = (e.startIdx + 1) % e.players.length, e.turnIdx = e.startIdx;
		for (let t of e.players) e.diceLeft[t] = 8;
		e.placed = Array.from({ length: 6 }, () => ({}));
		for (let t of e.casinos) N(e.pile, t);
		return e.phase = "play", e.beatMs = M.supply, n.push(...e.casinos.map((e, t) => ({
			kind: "supply",
			data: {
				casino: t,
				notes: e
			},
			with: !0
		}))), {
			state: e,
			fx: n
		};
	}
	if (t.phase !== "play") return { code: "games.lasvegas.errNotYourTurn" };
	let i = t.players[t.turnIdx];
	if (r.by !== i) return { code: "games.lasvegas.errNotYourTurn" };
	if (n.type === "roll") {
		if (t.rolled !== null) return { code: "games.lasvegas.errNotYourTurn" };
		let n = t.diceLeft[i], r = structuredClone(t), a = r.rngCursor, o = Array.from({ length: n }, () => e(r.seed, a++, 6) + 1);
		return r.rngCursor = a, r.rolled = o, {
			state: r,
			fx: [{
				kind: "roll",
				rid: i,
				data: { dice: o }
			}]
		};
	}
	let a = t.rolled;
	if (a === null) return { code: "games.lasvegas.errNotYourTurn" };
	let o = a.filter((e) => e === n.value).length;
	if (o === 0) return { code: "games.lasvegas.errBadValue" };
	let s = structuredClone(t), c = n.value - 1;
	s.placed[c][i] = (s.placed[c][i] ?? 0) + o, s.diceLeft[i] -= o, s.rolled = null;
	let l = [{
		kind: "place",
		rid: i,
		data: {
			casino: c,
			count: o
		}
	}], u = ne(s, s.turnIdx);
	return u === null ? (s.phase = "payout", s.payoutIdx = 0, s.turnIdx = -1, s.beatMs = M.payout) : s.turnIdx = u, {
		state: s,
		fx: l
	};
}
function F(e) {
	return {
		public: {
			round: e.round,
			phase: e.phase,
			turn: e.phase === "play" ? e.players[e.turnIdx] : null,
			rolled: e.rolled,
			casinos: e.casinos,
			placed: e.placed,
			players: e.players.map((t) => ({
				rid: t,
				money: e.money[t],
				notes: e.noteCounts[t],
				diceLeft: e.diceLeft[t]
			})),
			payoutIdx: e.payoutIdx
		},
		private: {}
	};
}
function I(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.money[n] - e.money[t] || e.noteCounts[n] - e.noteCounts[t]), n = t[0];
	return {
		phase: "done",
		winner: t.filter((t) => e.money[t] === e.money[n] && e.noteCounts[t] === e.noteCounts[n]),
		ranking: t,
		scores: { ...e.money }
	};
}
function L(e) {
	return e.phase === "payout" ? e.beatMs : null;
}
var R = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: T,
	schemas: {
		action: k,
		publicView: A,
		privateView: j
	},
	setup: te,
	reduce: P,
	viewFor: F,
	status: I,
	nextTickIn: L
};
//#endregion
//#region src/games/lasvegas/view-player.tsx
function z(e) {
	let t = e.public;
	return /* @__PURE__ */ h(H, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function B({ value: e, size: t = 36, hex: n }) {
	let r = {
		1: [[1, 1]],
		2: [[0, 0], [2, 2]],
		3: [
			[0, 0],
			[1, 1],
			[2, 2]
		],
		4: [
			[0, 0],
			[2, 0],
			[0, 2],
			[2, 2]
		],
		5: [
			[0, 0],
			[2, 0],
			[1, 1],
			[0, 2],
			[2, 2]
		],
		6: [
			[0, 0],
			[2, 0],
			[0, 1],
			[2, 1],
			[0, 2],
			[2, 2]
		]
	}, i = t / 3;
	return /* @__PURE__ */ h("svg", {
		width: t,
		height: t,
		viewBox: `0 0 ${t} ${t}`,
		"aria-hidden": !0,
		className: "rounded-lg border-2 border-ink shadow-[2px_2px_0_var(--color-ink)]",
		style: { background: n ?? "var(--color-surface)" },
		children: r[e].map(([e, t], r) => /* @__PURE__ */ h("circle", {
			cx: e * i + i / 2,
			cy: t * i + i / 2,
			r: i * .28,
			fill: n ? "#fff" : "var(--color-ink)"
		}, r))
	});
}
function V() {
	let e = r(null);
	return n(() => {
		let t = e.current, n = t?.querySelector(".game-screen-layout");
		if (!t || !n) return;
		let r = window.matchMedia("(orientation: landscape)"), i = [
			"pad",
			"gap",
			"phase-h",
			"seats-h",
			"action-h",
			"card-pad",
			"card-gap",
			"casino-die",
			"total-font",
			"note-font",
			"note-pad",
			"bet-die",
			"bet-gap",
			"tray-die",
			"tray-gap",
			"name-font",
			"seat-font",
			"avatar",
			"roll-font"
		], a = () => {
			delete t.dataset.lvLayout;
			for (let e of i) n.style.removeProperty(`--lv-${e}`);
		}, o = () => {
			let { width: e, height: o } = t.getBoundingClientRect(), s = r.matches && e >= 900 && o >= 600, c = r.matches && e >= 760 && o >= 308 && o < 600;
			if (!s && !c) {
				a();
				return;
			}
			if (c) {
				t.dataset.lvLayout !== "short" && (t.dataset.lvLayout = "short");
				for (let e of i) n.style.removeProperty(`--lv-${e}`);
				return;
			}
			let l = Math.max(6, Math.min(e, o) * .008), u = l, d = Math.max(52, o * .065), f = Math.max(64, o * .09), p = Math.max(80, o * .16), m = o - 2 * l - d - f - p - 3 * u, h = (e - 4 * l - 4 - 2 * u) / 3, g = (m - 4 - 2 * l - u) / 2, _ = Math.max(6, Math.min(h, g) * .04), v = Math.max(4, g * .025), y = Math.max(40, Math.min(g * .26, h * .14)), b = Math.max(14, Math.min(g * .095, (h - 2 * _ - 4 * v - 40) / 15)), x = Math.max(2, b * .14), S = v, C = Math.max(34, Math.min(g * .28, (h - 2 * _ - 6 - 4 * S) / 6.5)), w = Math.max(6, u), T = Math.max(42, Math.min((e - 2 * l - 16 - 7 * w) / 8, p - 16)), E = {
				pad: l,
				gap: u,
				"phase-h": d,
				"seats-h": f,
				"action-h": p,
				"card-pad": _,
				"card-gap": v,
				"casino-die": y,
				"total-font": Math.max(20, Math.min(g * .19, h * .09)),
				"note-font": b,
				"note-pad": x,
				"bet-die": C,
				"bet-gap": S,
				"tray-die": T,
				"tray-gap": w,
				"name-font": f * .28,
				"seat-font": f * .24,
				avatar: f * .55,
				"roll-font": Math.max(22, p * .25)
			};
			t.dataset.lvLayout !== "wide" && (t.dataset.lvLayout = "wide");
			for (let [e, t] of Object.entries(E)) {
				let r = `${t.toFixed(4)}px`;
				n.style.getPropertyValue(`--lv-${e}`) !== r && n.style.setProperty(`--lv-${e}`, r);
			}
		}, s = new ResizeObserver(o);
		return s.observe(t), r.addEventListener("change", o), o(), () => {
			s.disconnect(), r.removeEventListener("change", o), a();
		};
	}, []), e;
}
function H({ pub: e, members: t, myRid: n, send: r }) {
	let i = c(), a = V(), s = (e) => t.find((t) => t.rid === e)?.name ?? e, l = e.phase === "play" && e.turn === n, p = e.turn ? s(e.turn) : "", m, _;
	e.phase === "payout" ? (m = "info", _ = i("games.lasvegas.payout")) : l ? (m = "accent", _ = e.rolled ? i("games.lasvegas.placePrompt") : i("games.lasvegas.rollPrompt", { n: e.players.find((e) => e.rid === n)?.diceLeft ?? 0 })) : (m = "info", _ = e.rolled ? i("games.lasvegas.waitingPlace", { name: p }) : i("games.lasvegas.waitingRoll", { name: p }));
	let v = /* @__PURE__ */ new Map();
	if (l && e.rolled) for (let t of e.rolled) v.set(t, (v.get(t) ?? 0) + 1);
	return /* @__PURE__ */ h("div", {
		ref: a,
		className: "lv-screen",
		children: /* @__PURE__ */ h(u, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ g("div", {
				className: "lv-banner flex flex-col gap-2",
				children: [/* @__PURE__ */ h(d, {
					tone: m,
					text: _,
					chip: i("games.lasvegas.roundShort", {
						n: e.round,
						total: 4
					}),
					accent: T.accent
				}), /* @__PURE__ */ h("div", {
					className: "lv-players",
					children: /* @__PURE__ */ h(f, {
						variant: "plate",
						members: t,
						myRid: n,
						anchorOf: (e) => `seat:${e}`,
						action: (t) => {
							if (e.phase !== "play") return null;
							let n = e.players.find((e) => e.rid === t);
							return n ? t === e.turn ? "pending" : n.diceLeft === 0 ? "done" : null : null;
						},
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ g("span", {
								className: "lv-seat-status flex items-center gap-1.5 text-xs leading-4.5 font-bold",
								children: [/* @__PURE__ */ g("span", {
									className: "font-mono tabular-nums text-done-ink",
									children: [
										"$",
										/* @__PURE__ */ h(o, {
											value: n.money,
											className: "font-mono tabular-nums"
										}),
										"k"
									]
								}), /* @__PURE__ */ g("span", {
									className: "font-mono tabular-nums text-ink-soft",
									children: ["🎲", n.diceLeft]
								})]
							}) : null;
						}
					})
				})]
			}),
			actionsHeight: "lv-actions-height",
			actions: /* @__PURE__ */ h(K, {
				pub: e,
				myTurn: l,
				onRoll: () => r({ type: "roll" })
			}),
			children: /* @__PURE__ */ h("div", {
				className: "lv-board frame grid min-h-0 flex-1 grid-cols-2 grid-rows-3 gap-1.5 p-1.5",
				children: Array.from({ length: 6 }, (n, i) => /* @__PURE__ */ h(U, {
					index: i,
					notes: e.casinos[i],
					placed: e.placed[i],
					members: t,
					placeCount: v.get(i + 1) ?? 0,
					resolving: e.phase === "payout" && e.payoutIdx === i,
					settled: e.phase === "payout" && e.payoutIdx > i,
					onPlace: () => r({
						type: "place",
						value: i + 1
					})
				}, i))
			})
		})
	});
}
function U({ index: e, notes: t, placed: n, members: r, placeCount: i, resolving: o, settled: s, onPlace: l }) {
	let u = c(), { ref: d } = a(`casino:${e}`), f = i > 0, p = t.reduce((e, t) => e + t, 0), m = Object.entries(n).filter(([, e]) => e > 0);
	return /* @__PURE__ */ g("button", {
		ref: d,
		type: "button",
		disabled: !f,
		"aria-label": f ? u("games.lasvegas.placeDiceAria", {
			count: i,
			value: e + 1
		}) : u("games.lasvegas.casinoAria", { n: e + 1 }),
		onClick: l,
		className: `lv-casino relative flex min-h-0 flex-col gap-0.5 overflow-hidden rounded-xl border-3 p-1.5 text-left transition-transform ${f ? "hint-flash border-ink bg-surface shadow-[3px_3px_0_var(--color-ink)] active:translate-y-0.5" : "border-ink/25 bg-surface/60"} ${o ? "ring-3 ring-warn" : ""} ${s ? "opacity-70" : ""}`,
		children: [
			/* @__PURE__ */ g("span", {
				className: "lv-casino-head flex items-center gap-1.5",
				children: [
					/* @__PURE__ */ h(B, {
						value: e + 1,
						size: 26
					}),
					/* @__PURE__ */ g("span", {
						className: "lv-total font-mono text-xs font-extrabold tabular-nums",
						children: [
							"$",
							p,
							"k"
						]
					}),
					f && /* @__PURE__ */ g("span", {
						className: "lv-choice ml-auto grid size-6 place-items-center rounded-full border-2 border-ink bg-warn font-mono text-xs font-black tabular-nums",
						children: ["×", i]
					})
				]
			}),
			/* @__PURE__ */ g("span", {
				className: "lv-notes flex min-h-5 flex-wrap items-center gap-0.5",
				children: [t.map((e, t) => /* @__PURE__ */ g("span", {
					className: "lv-note rounded-md border-2 border-ink bg-done-soft px-1 font-mono text-[10px] leading-4 font-extrabold tabular-nums text-done-ink",
					children: [
						"$",
						e,
						"k"
					]
				}, t)), t.length === 0 && /* @__PURE__ */ h("span", {
					className: "text-[10px] font-bold text-ink-soft",
					children: "—"
				})]
			}),
			/* @__PURE__ */ h("span", {
				className: "lv-stakes mt-auto flex min-h-6 flex-wrap items-center gap-1",
				children: m.map(([t, n]) => /* @__PURE__ */ h(W, {
					casino: e,
					rid: t,
					value: e + 1,
					n,
					members: r
				}, t))
			})
		]
	});
}
function W({ casino: e, rid: t, value: n, n: r, members: o }) {
	let { ref: s } = a(`bet:${e}:${t}`), c = o.find((e) => e.rid === t), u = l[(c?.colorIndex ?? 0) % l.length];
	return /* @__PURE__ */ g("span", {
		ref: s,
		className: "lv-bet relative flex items-center",
		title: c?.name,
		children: [
			/* @__PURE__ */ h(B, {
				value: n,
				size: 22,
				hex: u.hex
			}),
			/* @__PURE__ */ h("span", {
				className: "lv-bet-count absolute -right-1 -bottom-1 grid size-4 place-items-center rounded-full border border-ink bg-surface font-mono text-[9px] font-black tabular-nums",
				children: r
			}),
			c && /* @__PURE__ */ h("img", {
				src: i[c.avatar % i.length],
				alt: c.name,
				draggable: !1,
				className: "lv-bet-avatar absolute -top-1.5 -left-1.5 size-4 rounded-full border border-ink object-contain",
				style: { backgroundColor: u.hex }
			})
		]
	});
}
function G({ value: e, index: t }) {
	let { ref: n } = a(`rolled:${t}`);
	return /* @__PURE__ */ h("span", {
		ref: n,
		className: "lv-rolled-object",
		children: /* @__PURE__ */ h(B, {
			value: e,
			size: 34
		})
	});
}
function K({ pub: e, myTurn: t, onRoll: n }) {
	let r = c(), { ref: i, hidden: o } = a("tray"), s = e.rolled;
	return /* @__PURE__ */ h("div", {
		className: "lv-actions safe-b",
		children: /* @__PURE__ */ g("div", {
			ref: i,
			className: "lv-tray flex h-16 items-center justify-center gap-2 px-2",
			style: { visibility: o ? "hidden" : void 0 },
			children: [
				e.phase === "play" && t && !s && /* @__PURE__ */ g("button", {
					type: "button",
					onClick: n,
					className: "lv-roll btn-base min-h-12 px-8 font-display text-lg font-extrabold text-white",
					style: { background: T.accent },
					children: ["🎲 ", r("games.lasvegas.roll")]
				}),
				e.phase === "play" && s && /* @__PURE__ */ h("span", {
					className: "lv-rolled flex flex-wrap items-center justify-center gap-1",
					children: [...s].sort((e, t) => e - t).map((e, t) => /* @__PURE__ */ h(G, {
						index: t,
						value: e
					}, t))
				}),
				e.phase === "payout" && /* @__PURE__ */ h("span", {
					className: "text-sm font-bold text-ink-soft",
					children: "💰 …"
				})
			]
		})
	});
}
//#endregion
//#region src/games/lasvegas/bot.ts
function q(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function J(e, t, n) {
	let r = Object.entries(e).filter(([, e]) => e > 0), i = (e[t] ?? 0) + n, a = [...r.filter(([e]) => e !== t).map(([, e]) => e), i], o = /* @__PURE__ */ new Map();
	for (let e of a) o.set(e, (o.get(e) ?? 0) + 1);
	return (o.get(i) ?? 0) > 1 ? -1 : a.filter((e) => o.get(e) === 1).sort((e, t) => t - e).indexOf(i);
}
var Y = (e, t) => {
	let n = e.public;
	if (n.phase !== "play" || n.turn !== t.rid) return null;
	if (n.rolled === null) return { action: { type: "roll" } };
	let r = [...new Set(n.rolled)];
	if (t.difficulty === "weak") return { action: {
		type: "place",
		value: q(r)
	} };
	let i = n.players.find((e) => e.rid === t.rid);
	if (!i) return null;
	let a = i.money, o = Math.max(...n.players.filter((e) => e.rid !== t.rid).map((e) => e.money), 0) - a, s = r[0], c = -Infinity;
	for (let e of r) {
		let r = e - 1, i = n.rolled.filter((t) => t === e).length, a = n.placed[r], l = n.casinos[r], u = J(a, t.rid, i), d;
		if (u < 0) {
			let e = Object.entries(a).filter(([e, n]) => e !== t.rid && n > 0).sort((e, t) => t[1] - e[1])[0], n = (a[t.rid] ?? 0) + i;
			d = -3 + (e && e[1] === n ? l[0] ?? 0 : 0) * Math.min(o / 40, 1.5) / 10;
		} else {
			let e = l[u] ?? 0, n = (a[t.rid] ?? 0) + i, r = Math.max(0, ...Object.entries(a).filter(([e]) => e !== t.rid).map(([, e]) => e));
			d = e + (n > r ? .5 + .3 * Math.min(n - r, 3) : 0) + .05 * l.reduce((e, t) => e + t, 0);
		}
		d -= i * .08, d > c && (c = d, s = e);
	}
	return { action: {
		type: "place",
		value: s
	} };
}, ie = (e, t, n) => e.type === "roll" ? n("games.lasvegas.describeRoll") : e.type === "place" ? n("games.lasvegas.describePlace", {
	count: t.public.rolled?.filter((t) => t === e.value).length ?? 0,
	value: e.value
}) : "", ae = {
	needsAction: (e, t) => e.public.phase === "play" && e.public.turn === t.rid,
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.round}/4 轮。规则:轮到你掷出全部剩余骰子,选一种点数,把该点数的所有骰子放到对应赌场(点数 1-6 → 赌场 1-6)。全部玩家骰子放完后,每家赌场按骰数排名分钞票(并列者跳过,顺位下移),钱最多者胜。`, "六家赌场(序号即点数):"];
		if (n.casinos.forEach((e, i) => {
			let a = Object.entries(n.placed[i]).map(([e, n]) => `${e === t.rid ? "你" : e}×${n}`).join(" ");
			r.push(`  赌场${i + 1}: 钞票 [${e.join(", ")}] 万;已放骰: ${a || "(无)"}`);
		}), r.push(`各人: ${n.players.map((e) => `${e.rid === t.rid ? "你" : e.rid}: ${e.money} 万,剩 ${e.diceLeft} 骰`).join("; ")}`), n.rolled) {
			let e = /* @__PURE__ */ new Map();
			for (let t of n.rolled) e.set(t, (e.get(t) ?? 0) + 1);
			r.push(`你掷出了: ${n.rolled.join(", ")}。可选: ${[...e].map(([e, t]) => `点数${e}(放 ${t} 颗到赌场${e})`).join("; ")}。输出 place 行动。`);
		} else r.push("轮到你掷骰,输出 roll 行动。");
		return r.join("\n");
	},
	actionJsonSchema: { oneOf: [{
		type: "object",
		properties: { type: { const: "roll" } },
		required: ["type"],
		additionalProperties: !1
	}, {
		type: "object",
		properties: {
			type: { const: "place" },
			value: {
				type: "integer",
				minimum: 1,
				maximum: 6,
				description: "必须是刚掷出的点数之一"
			}
		},
		required: ["type", "value"],
		additionalProperties: !1
	}] },
	parseAction(e, t, n) {
		let r = k.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public;
		return a.phase !== "play" || a.turn !== n.rid ? null : i.type === "roll" ? a.rolled === null ? i : null : a.rolled !== null && a.rolled.includes(i.value) ? i : null;
	}
};
//#endregion
//#region src/games/lasvegas/fx.tsx
function oe(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function se(e, t) {
	let n = t ? e.member(t) : null;
	return l[(n?.colorIndex ?? 0) % l.length].hex;
}
function X(e, t = 12) {
	return /* @__PURE__ */ g("span", {
		style: { fontSize: t },
		className: "rounded-md border-2 border-ink bg-done-soft px-1.5 py-0.5 font-mono text-xs font-extrabold tabular-nums text-done-ink shadow-[2px_2px_0_var(--color-ink)]",
		children: [
			"$",
			e,
			"k"
		]
	});
}
var ce = {
	roll(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.dice)) return null;
		let r = t.anchor("tray");
		if (!r) return null;
		let i = [...n.dice].sort((e, t) => e - t), a = t.queued > 0, o = i.length * 40 - 6;
		return {
			ms: a ? 350 : 600 + i.length * 60,
			hide: a ? void 0 : ["tray"],
			node: /* @__PURE__ */ h(m, { children: i.map((e, n) => {
				let i = t.anchor(`rolled:${n}`) ?? {
					x: r.x + r.w / 2 - o / 2 + n * 40,
					y: r.y + r.h / 2 - 17,
					w: 34,
					h: 34
				};
				return /* @__PURE__ */ h(y, {
					from: {
						...i,
						y: r.y - 130
					},
					to: i,
					ms: a ? 200 : 420,
					delay: a ? 0 : n * 60,
					children: /* @__PURE__ */ h("span", {
						className: "lv-flying-die",
						style: {
							width: i.w,
							height: i.h,
							borderRadius: i.w * .19
						},
						children: /* @__PURE__ */ h(B, {
							value: e,
							size: i.w
						})
					})
				}, n);
			}) })
		};
	},
	place(e, t) {
		let n = e.data;
		if (typeof n?.casino != "number" || typeof n?.count != "number") return null;
		let r = t.anchor("tray"), i = t.anchor(`casino:${n.casino}`);
		if (!i) return null;
		let a = t.anchor(`bet:${n.casino}:${e.rid}`), o = a?.w ?? 26, s = se(t, e.rid), c = n.casino + 1, l = n.count, u = t.queued > 0, d = Math.min(l, 5), f = u ? 250 : 480;
		return {
			ms: u ? 350 : 620,
			node: /* @__PURE__ */ g(m, { children: [
				r && Array.from({ length: d }, (e, t) => /* @__PURE__ */ h(y, {
					from: r,
					to: {
						x: (a ?? i).x + (a ?? i).w / 2 - o / 2 + (t - (d - 1) / 2) * o * (12 / 26),
						y: (a ?? i).y + (a ?? i).h / 2 - o / 2,
						w: o,
						h: o
					},
					ms: f,
					delay: u ? 0 : t * 60,
					children: /* @__PURE__ */ h("span", {
						className: "lv-flying-die",
						style: {
							width: o,
							height: o,
							borderRadius: o * .19
						},
						children: /* @__PURE__ */ h(B, {
							value: c,
							size: o,
							hex: s
						})
					})
				}, t)),
				!r && /* @__PURE__ */ h(b, {
					at: i,
					ms: f
				}),
				!u && /* @__PURE__ */ h(v, {
					at: i,
					ms: 800,
					delay: 200,
					children: /* @__PURE__ */ g("span", {
						style: { fontSize: Math.max(14, Math.min(i.w * .05, i.h * .1)) },
						className: "rounded-lg border-2 border-ink bg-surface px-1.5 font-mono text-sm font-black tabular-nums shadow-[2px_2px_0_var(--color-ink)]",
						children: ["×", l]
					})
				})
			] })
		};
	},
	payout(e, t) {
		let n = e.data;
		if (typeof n?.casino != "number") return null;
		let r = t.anchor(`casino:${n.casino}`);
		if (!r) return null;
		let i = Array.isArray(n.busted) ? n.busted : [], a = Array.isArray(n.awards) ? n.awards : [];
		return x(), {
			ms: 900,
			node: /* @__PURE__ */ g(m, { children: [i.length > 0 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(b, {
				at: r,
				ms: 600
			}), /* @__PURE__ */ h(v, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ h("span", {
					className: "font-mono text-sm font-black text-danger-ink",
					children: "✕"
				})
			})] }), a.map((e, n) => {
				let a = oe(t, e.rid);
				return a ? /* @__PURE__ */ h(y, {
					from: r,
					to: a,
					ms: 520,
					delay: i.length > 0 ? 250 + n * 160 : n * 160,
					children: X(e.note, Math.max(12, Math.min(r.w * .05, r.h * .1)))
				}, e.rid) : /* @__PURE__ */ h(v, {
					at: r,
					ms: 700,
					delay: n * 120,
					children: X(e.note, Math.max(12, Math.min(r.w * .05, r.h * .1)))
				}, e.rid);
			})] })
		};
	},
	supply(e, t) {
		let n = e.data;
		if (typeof n?.casino != "number") return null;
		let r = t.anchor(`casino:${n.casino}`);
		return r ? {
			ms: 550,
			node: /* @__PURE__ */ h(b, {
				at: r,
				ms: 550
			})
		} : null;
	},
	win() {
		return {
			ms: 600,
			node: /* @__PURE__ */ h(_, {
				ms: 600,
				className: "bg-warn"
			})
		};
	}
};
//#endregion
//#region src/games/lasvegas/game-over-row.tsx
function Z({ public: e, rid: t }) {
	let n = c(), r = e.players.find((e) => e.rid === t);
	return r ? /* @__PURE__ */ h("div", {
		className: "mt-1 font-mono text-xs tabular-nums text-ink-soft",
		children: n("games.lasvegas.notesLine", { n: r.notes })
	}) : null;
}
//#endregion
//#region src/games/lasvegas/game-over.tsx
var le = [
	"🥇",
	"🥈",
	"🥉"
], Q = (e, t, n) => Math.min(n, Math.max(e, t));
function $(e, t, n, r, i) {
	let a = i && e >= 760 && t >= 300, o = a ? Q(4, Math.min(e, t) * .008, 10) : 0, s = a ? Q(6, t * .008, 12) : 8, c = a ? Q(40, t * .055, 68) : 44, l = a ? Q(52, t * .065, 84) : r === 2 ? 108 : r ? 52 : 44, u = Math.max(0, t - 2 * o - c - l - 2 * s), d = Math.max(a ? t >= 600 ? 104 : 88 : 96, (u - Math.max(0, n - 1) * s - 8) / Math.max(1, n)), f = a ? Q(8, d * .065, 18) : 8, p = d - 2 * f - 6;
	return {
		wide: a,
		pad: o,
		gap: s,
		header: c,
		actions: l,
		body: u,
		row: d,
		rowPad: f,
		avatar: a ? Q(44, Math.min(p * .66, e * .14), 280) : 44,
		name: a ? Q(18, Math.min(p * .3, e * .037), 96) : 18,
		cash: a ? Q(30, Math.min(p * .62, e * .1), 220) : 30,
		notes: a ? Q(14, Math.min(p * .21, e * .027), 56) : 14,
		badge: a ? Q(12, Math.min(p * .13, e * .016), 28) : 12,
		rank: a ? Q(18, Math.min(p * .38, e * .055), 96) : 20,
		cellGap: a ? Q(8, d * .07, 24) : 8
	};
}
function ue(e, t) {
	let i = r(null);
	return n(() => {
		let n = i.current;
		if (!n) return;
		let r = window.matchMedia("(orientation: landscape)"), a = [], o = !0, s = () => {
			if (!o) return;
			let { width: i, height: s } = n.getBoundingClientRect();
			if (i <= 0 || s <= 0) return;
			let c = $(i, s, e, t, r.matches);
			n.dataset.lvOverLayout = c.wide ? "wide" : "stack";
			for (let [e, t] of Object.entries(c)) {
				if (typeof t != "number") continue;
				let r = "--lv-over-" + e;
				a.includes(r) || a.push(r), n.style.setProperty(r, t.toFixed(4) + "px");
			}
		}, c = new ResizeObserver(s);
		return c.observe(n), r.addEventListener("change", s), s(), () => {
			o = !1, c.disconnect(), r.removeEventListener("change", s), delete n.dataset.lvOverLayout;
			for (let e of a) n.style.removeProperty(e);
		};
	}, [e, t]), i;
}
function de(e) {
	let t = A.safeParse(e.public);
	return t.success && t.data.phase === "done" && e.result.ranking.length > 0 && e.result.ranking.every((e) => t.data.players.some((t) => t.rid === e)) ? /* @__PURE__ */ h(fe, {
		...e,
		pub: t.data
	}) : /* @__PURE__ */ h(w, {
		result: e.result,
		members: e.members,
		myRid: e.myRid,
		accent: T.accent,
		onPlayAgain: e.onPlayAgain,
		onBackToLobby: e.onBackToLobby,
		renderRowExtra: t.success ? (n) => /* @__PURE__ */ h(Z, {
			public: t.data,
			rid: n,
			myRid: e.myRid
		}) : void 0
	});
}
function fe({ pub: e, result: t, members: n, myRid: r, onPlayAgain: a, onBackToLobby: o }) {
	let d = c(), f = s((e) => e.locale), m = Number(!!a) + Number(!!o), _ = ue(t.ranking.length, m);
	return /* @__PURE__ */ g("div", {
		ref: _,
		className: "lv-over",
		style: { "--lv-over-accent": T.accent },
		children: [/* @__PURE__ */ h(C, {}), /* @__PURE__ */ h(u, {
			adaptive: !0,
			scroll: !1,
			className: "lv-over-screen",
			actionsHeight: "lv-over-action-height",
			banner: /* @__PURE__ */ h("header", {
				className: "lv-over-heading",
				children: /* @__PURE__ */ h("h1", { children: d("session.result.title") })
			}),
			actions: m ? /* @__PURE__ */ g("div", {
				className: "lv-over-actions",
				children: [a && /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-base text-white",
					style: { background: T.accent },
					onClick: a,
					children: d("session.result.playAgain")
				}), o && /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-quiet",
					onClick: o,
					children: d("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ h("p", {
				className: "lv-over-wait",
				children: d("session.result.waitHost")
			}),
			children: /* @__PURE__ */ h("ol", {
				className: "lv-over-ranking",
				children: t.ranking.map((a, o) => {
					let s = n.find((e) => e.rid === a), c = s ? p(s, f) : a, u = t.winner.includes(a), m = t.scores?.[a], _ = e.players.find((e) => e.rid === a).notes, v = t.autopilot?.[a];
					return /* @__PURE__ */ g("li", {
						"data-winner": u,
						children: [
							/* @__PURE__ */ h("span", {
								className: "lv-over-rank",
								children: le[o] ?? o + 1
							}),
							/* @__PURE__ */ g("span", {
								className: "lv-over-avatar",
								style: { backgroundColor: l[(s?.colorIndex ?? 0) % l.length].hex },
								children: [s && /* @__PURE__ */ h("img", {
									src: i[s.avatar % i.length],
									alt: "",
									draggable: !1
								}), u && /* @__PURE__ */ h("b", {
									"aria-hidden": !0,
									children: "👑"
								})]
							}),
							/* @__PURE__ */ g("span", {
								className: "lv-over-person",
								children: [/* @__PURE__ */ h("strong", {
									title: c,
									children: c
								}), /* @__PURE__ */ g("span", {
									className: "lv-over-identity",
									children: [a === r && /* @__PURE__ */ h("small", { children: d("lobby.you") }), v !== void 0 && v > 0 && /* @__PURE__ */ g("small", { children: [/* @__PURE__ */ h(S, { size: 14 }), d("session.autopilot.share", { n: Math.round(v * 100) })] })]
								})]
							}),
							/* @__PURE__ */ g("span", {
								className: "lv-over-money",
								children: [/* @__PURE__ */ h("b", { children: m === void 0 ? "—" : "$" + m + "k" }), /* @__PURE__ */ h("span", { children: d("games.lasvegas.notesLine", { n: _ }) })]
							})
						]
					}, a);
				})
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/lasvegas/entry.tsx
var pe = {
	definition: R,
	View: z,
	bot: Y,
	describe: ie,
	llm: ae,
	fx: ce,
	OverView: de,
	RowView: Z,
	locales: {
		zh: {
			name: "拉斯维加斯",
			desc: "掷骰抢赌场，钱最多的人赢",
			rules: "目标:四轮结束后,赢得现金最多的玩家获胜;现金总额相同时，持有钞票张数较多的玩家获胜,仍平则并列获胜。\n准备:\n· 六家赌场按编号 1-6 排开;钞票洗混成堆。\n· 给每家赌场翻钞票,直到该家总额达到 $50k 为止。\n· 每人 8 颗骰子。\n流程:\n· 轮到你时,掷出剩余的全部骰子,然后必须选择一个点数,把该点数的所有骰子放到编号相同的赌场。\n· 骰子放完即跳过剩余回合;全员放完 8 颗后,六家赌场依次结算。\n结算:\n· 在同一家赌场中，骰子数量相同的玩家均退出该赌场的钞票分配；这些玩家不能领取该赌场的钞票。\n· 剩余玩家按骰子数从多到少,依次拿走该赌场面值最高的钞票;钞票不够分时,排在后面的人不能领取钞票。\n· 没分出去的钞票放回钞票堆底部。\n· 每轮结束补足六家赌场的钞票(仍从 $50k 起),起始玩家左移一位,共进行四轮。",
			roundShort: "{{n}}/{{total}}",
			rollPrompt: "掷出剩余 {{n}} 颗骰子",
			roll: "掷骰子",
			placePrompt: "选一个点数，该点数的全部骰子放上对应赌场",
			waitingRoll: "等 {{name}} 掷骰…",
			waitingPlace: "等 {{name}} 选点数…",
			payout: "六家赌场依次结算…",
			casinoAria: "{{n}} 号赌场",
			placeDiceAria: "把 {{count}} 颗 {{value}} 点放上 {{value}} 号赌场",
			notesLine: "钞票 {{n}} 张",
			describeRoll: "掷骰子",
			describePlace: "把 {{count}} 颗 {{value}} 点放上 {{value}} 号赌场",
			errNotYourTurn: "现在轮不到你",
			errBadValue: "这次没掷出这个点数"
		},
		en: {
			name: "Las Vegas",
			desc: "Roll dice, grab casino majorities, richest wins",
			rules: "Goal: after four rounds, the player with the most money wins; ties are broken by banknote count, then shared.\nSetup:\n· Six casinos numbered 1-6; shuffle the banknotes into a pile.\n· Deal banknotes to each casino until its total reaches at least $50k.\n· Each player gets 8 dice.\nPlay:\n· On your turn, roll all your remaining dice, then choose one rolled value and place all dice of that value on the matching casino.\n· Out of dice = pass; once everyone has placed all 8, the six casinos pay out in order.\nPayout:\n· Players tied on dice count at a casino are all eliminated from it.\n· Remaining players take that casino’s banknotes in descending dice order, highest-value note first; if notes run out, latecomers get nothing.\n· Undistributed notes go to the bottom of the pile.\n· Casinos are restocked to at least $50k each round; the start player rotates left. Four rounds total.",
			roundShort: "{{n}}/{{total}}",
			rollPrompt: "Roll your remaining {{n}} dice",
			roll: "Roll",
			placePrompt: "Pick a value; all dice of it go to the matching casino",
			waitingRoll: "Waiting for {{name}} to roll…",
			waitingPlace: "Waiting for {{name}} to pick a value…",
			payout: "Paying out the six casinos…",
			casinoAria: "Casino {{n}}",
			placeDiceAria: "Place {{count}} dice showing {{value}} on casino {{value}}",
			notesLine: "{{n}} banknotes",
			describeRoll: "Roll the dice",
			describePlace: "Place {{count}} dice showing {{value}} on casino {{value}}",
			errNotYourTurn: "Not your turn",
			errBadValue: "You did not roll that value"
		}
	}
};
//#endregion
export { pe as default };
