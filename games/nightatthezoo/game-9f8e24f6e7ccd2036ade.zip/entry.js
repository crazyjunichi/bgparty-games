import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { IconBot as c, IconExpand as l, IconInfo as u, IconLog as d } from "@bgparty/sdk/icons";
import { BottomSheet as f } from "@bgparty/sdk/bottom-sheet";
import { useWakeLock as p } from "@bgparty/sdk/use-wake-lock";
import { Texture as m } from "@bgparty/sdk/texture";
import { GameScreen as h } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as g } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as _, seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { LogSheet as v } from "@bgparty/sdk/ui/log-sheet";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { AVATARS as te } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as S } from "@bgparty/sdk/player-colors";
import { Confetti as ne } from "@bgparty/sdk/ui/confetti";
import { OptionCheckbox as C, OptionSection as w } from "@bgparty/sdk/ui/game-options";
//#region src/games/nightatthezoo/data.ts
var T = [
	"rock",
	"grass",
	"sand"
], E = [
	"cheetah",
	"penguin",
	"wolf",
	"snake",
	"butterfly",
	"sloth",
	"turtle",
	"crocodile",
	"monkey",
	"meerkat"
], D = {
	cheetah: {
		moons: 2,
		points: 6,
		emoji: "🐆",
		name: "games.nightatthezoo.cheetah",
		rule: "games.nightatthezoo.ruleCheetah",
		color: "#e5a456"
	},
	penguin: {
		moons: 1,
		points: 5,
		emoji: "🐧",
		name: "games.nightatthezoo.penguin",
		rule: "games.nightatthezoo.rulePenguin",
		color: "#a8b5eb"
	},
	wolf: {
		moons: 1,
		points: 0,
		emoji: "🐺",
		name: "games.nightatthezoo.wolf",
		rule: "games.nightatthezoo.ruleWolf",
		color: "#a6a1bb"
	},
	snake: {
		moons: 3,
		points: 10,
		emoji: "🐍",
		name: "games.nightatthezoo.snake",
		rule: "games.nightatthezoo.ruleSnake",
		color: "#ef8d7a"
	},
	butterfly: {
		moons: 3,
		points: 0,
		emoji: "🦋",
		name: "games.nightatthezoo.butterfly",
		rule: "games.nightatthezoo.ruleButterfly",
		color: "#e7a4ce"
	},
	sloth: {
		moons: 4,
		points: 15,
		emoji: "🦥",
		name: "games.nightatthezoo.sloth",
		rule: "games.nightatthezoo.ruleSloth",
		color: "#8fc6b9"
	},
	turtle: {
		moons: 4,
		points: 8,
		emoji: "🐢",
		name: "games.nightatthezoo.turtle",
		rule: "games.nightatthezoo.ruleTurtle",
		color: "#b1c279"
	},
	crocodile: {
		moons: 3,
		points: 8,
		emoji: "🐊",
		name: "games.nightatthezoo.crocodile",
		rule: "games.nightatthezoo.ruleCrocodile",
		color: "#8eba74"
	},
	monkey: {
		moons: 3,
		points: 7,
		emoji: "🐒",
		name: "games.nightatthezoo.monkey",
		rule: "games.nightatthezoo.ruleMonkey",
		color: "#c6a1d4"
	},
	meerkat: {
		moons: 1,
		points: 6,
		emoji: "🦫",
		name: "games.nightatthezoo.meerkat",
		rule: "games.nightatthezoo.ruleMeerkat",
		color: "#dfa68d"
	}
}, O = {
	rock: "games.nightatthezoo.rock",
	grass: "games.nightatthezoo.grass",
	sand: "games.nightatthezoo.sand"
}, k = [
	"games.nightatthezoo.apple",
	"games.nightatthezoo.berries",
	"games.nightatthezoo.carrot",
	"games.nightatthezoo.meat",
	"games.nightatthezoo.egg",
	"games.nightatthezoo.lettuce",
	"games.nightatthezoo.fish"
], A = [
	0,
	0,
	6,
	8,
	11,
	16,
	22,
	30
], re = {
	move: "games.nightatthezoo.moveEffect",
	discover: "games.nightatthezoo.discoverEffect",
	bonus: "games.nightatthezoo.bonusEffect",
	points: "games.nightatthezoo.pointsEffect"
}, j = (e, t = 1) => ({
	kind: e,
	n: t
}), M = T.flatMap((e, t) => Array.from({ length: 25 }, (n, r) => ({
	id: t * 25 + r,
	terrain: e,
	food: r >= 18 ? r - 18 : null,
	options: r < 8 ? [j("discover")] : r < 13 ? [j("discover"), j("bonus")] : r < 18 ? [j("move", 2)] : []
}))).concat(T.map((e, t) => ({
	id: 75 + t,
	terrain: e,
	options: [],
	food: null
}))), N = (e) => e < 25 ? [e % 5, Math.floor(e / 5)] : P[e - 25].xy, P = [
	{
		xy: [0, -1],
		terrain: "sand",
		direction: 2
	},
	{
		xy: [2, -1],
		terrain: "grass",
		direction: 2
	},
	{
		xy: [4, -1],
		terrain: "rock",
		direction: 2
	},
	{
		xy: [5, 1],
		terrain: "grass",
		direction: 3
	},
	{
		xy: [5, 3],
		terrain: "rock",
		direction: 3
	},
	{
		xy: [3, 5],
		terrain: "sand",
		direction: 0
	},
	{
		xy: [1, 5],
		terrain: "rock",
		direction: 0
	},
	{
		xy: [-1, 3],
		terrain: "grass",
		direction: 1
	},
	{
		xy: [-1, 1],
		terrain: "sand",
		direction: 1
	}
], F = [
	[0, -1],
	[1, 0],
	[0, 1],
	[-1, 0]
], I = (e, t) => {
	let [n, r] = N(e), [i, a] = F[t], o = n + i, s = r + a;
	return o >= 0 && o < 5 && s >= 0 && s < 5 ? s * 5 + o : null;
}, ie = {
	1: { actions: [j("move")] },
	6: {
		actions: [j("move")],
		terrain: "sand"
	},
	7: {
		actions: [j("points", 2)],
		discover: !0
	},
	8: { actions: [j("bonus")] },
	11: {
		actions: [j("points", 2)],
		discover: !0
	},
	13: {
		actions: [j("points", 2)],
		discover: !0
	},
	14: { actions: [j("move")] },
	16: {
		actions: [j("move")],
		terrain: "grass"
	},
	17: {
		actions: [j("points", 2)],
		discover: !0
	},
	18: {
		actions: [j("move")],
		terrain: "rock"
	},
	20: { actions: [j("bonus"), j("points", 2)] },
	24: { actions: [j("move"), j("points", 2)] }
}, L = [
	{
		cells: [3, 4],
		reward: j("move", 2)
	},
	{
		cells: [5, 10],
		reward: j("bonus", 2)
	},
	{
		cells: [22, 23],
		reward: j("points", 5)
	}
], R = [
	{
		letters: [
			1,
			2,
			0,
			1,
			2,
			0,
			1,
			0,
			2
		],
		awake: [
			1,
			5,
			6
		]
	},
	{
		letters: [
			0,
			1,
			2,
			0,
			1,
			2,
			0,
			2,
			1
		],
		awake: [
			2,
			3,
			8
		]
	},
	{
		letters: [
			0,
			1,
			2,
			0,
			1,
			2,
			0,
			2,
			1
		],
		awake: [
			1,
			5,
			6
		]
	},
	{
		letters: [
			1,
			2,
			0,
			1,
			2,
			0,
			1,
			0,
			2
		],
		awake: [
			2,
			3,
			8
		]
	},
	{
		letters: [
			2,
			0,
			1,
			2,
			0,
			1,
			2,
			1,
			0
		],
		awake: [
			1,
			5,
			6
		]
	},
	{
		letters: [
			1,
			2,
			0,
			1,
			2,
			0,
			1,
			0,
			2
		],
		awake: [
			0,
			4,
			7
		]
	},
	{
		letters: [
			2,
			0,
			1,
			2,
			0,
			1,
			2,
			1,
			0
		],
		awake: [
			1,
			3,
			7
		]
	},
	{
		letters: [
			2,
			0,
			1,
			2,
			0,
			1,
			2,
			1,
			0
		],
		awake: [
			2,
			3,
			8
		]
	},
	{
		letters: [
			0,
			1,
			2,
			0,
			1,
			2,
			0,
			2,
			1
		],
		awake: [
			0,
			4,
			7
		]
	}
], ae = [
	{
		priority: [0, 2],
		shuffle: !0
	},
	{
		priority: [1, 2],
		shuffle: !1
	},
	{
		priority: [2, 1],
		shuffle: !1
	},
	{
		priority: [2, 0],
		shuffle: !1
	},
	{
		priority: [1, 0],
		shuffle: !1
	},
	{
		priority: [0, 1],
		shuffle: !1
	}
], oe = {
	id: "nightatthezoo",
	tier: "alpha",
	mechanics: [
		"drafting",
		"tile-placement",
		"grid-movement",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.nightatthezoo.name",
	descKey: "games.nightatthezoo.desc",
	rulesKey: "games.nightatthezoo.rules",
	icon: "🦥",
	iconImg: "games/nightatthezoo.webp",
	minPlayers: 1,
	maxPlayers: 4,
	accent: "#645099",
	releasedAt: "2026-10-29T01:08:20+08:00",
	search: {
		py: "dong wu yuan zhi ye",
		init: "dwyzy"
	},
	hotseat: "cover",
	botDelayMs: 350,
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/10131812153554100584/1B49CDE2E7657640719CE1ED29A9F5DC97D1C92B/" }
}, z = (e) => e.frames[e.frames.length - 1], B = (e) => e.state === "board" ? e.edge === null ? [e.pos] : [e.pos, e.edge] : [], V = (e, t) => t !== null && (t === 12 || e.tiles[t] !== null), se = (e, t, n) => t.species !== "crocodile" && n !== 12 && e.animals.some((e) => e.species === "crocodile" && B(e).includes(n)), H = (e, t, n) => n === 12 || se(e, t, n);
function ce(e, t, n) {
	let r = [], i = (a, o) => {
		if (o.length && r.push(o), !(o.length === n || o.length && H(e, t, a))) for (let t = 0; t < 4; t++) {
			let n = I(a, t);
			V(e, n) && i(n, [...o, n]);
		}
	};
	return i(t.pos, []), r;
}
function le(e, t, n) {
	let r = [];
	for (let i = 0; i < 4; i++) {
		if (n === 1) {
			let [n, a] = N(t.pos), [o, s] = F[i], c = n + 2 * o, l = a + 2 * s, u = c >= 0 && c < 5 && l >= 0 && l < 5 ? l * 5 + c : null;
			V(e, u) && r.push([u]);
			continue;
		}
		for (let a of n === 0 ? [0] : [-1, 1]) {
			let o = t.pos, s = [], c = n === 0 ? [
				i,
				i,
				i
			] : [
				i,
				(i + a + 4) % 4,
				(i + a + 4) % 4
			];
			for (let n of c) {
				let r = I(o, n);
				if (!V(e, r) || (s.push(r), o = r, H(e, t, o))) break;
			}
			(s.length === 3 || s.length && H(e, t, o)) && r.push(s);
		}
	}
	return r;
}
function ue(e) {
	let t = z(e).movement;
	if (!t || !t.left) return [];
	let n = e.animals.filter((e) => e.state === "board" && (t.mode === "normal" || t.eligible.includes(e.id))), r = [];
	for (let i of n) {
		let n = (e, t = {}) => r.push({
			animal: i.id,
			path: e,
			...t
		});
		if (i.species === "sloth" && i.asleep) {
			n([]);
			continue;
		}
		if (i.species === "snake") {
			for (let e = 0; e < 4; e++) e !== i.direction && n([], { direction: e });
			let t = I(i.pos, i.direction);
			V(e, t) && n([t]);
			continue;
		}
		if (i.species === "turtle") {
			if (i.edge !== null) for (let e of B(i)) e < 25 && n([e]);
			else for (let t = 0; t < 4; t++) {
				let r = I(i.pos, t);
				V(e, r) && n([r]);
			}
			continue;
		}
		if (i.species === "penguin") {
			for (let t = 0; t < 4; t++) {
				let r = i.pos, a = [];
				for (;;) {
					let n = I(r, t);
					if (!V(e, n) || (a.push(n), r = n, H(e, i, r))) break;
				}
				a.length && n(a);
			}
			continue;
		}
		let a = i.species === "cheetah" && t.mode === "special" || i.species === "meerkat" && e.animals.some((e) => e.id !== i.id && B(e).some((e) => {
			let [t, n] = N(e), [r, a] = N(i.pos);
			return r === t || a === n;
		}));
		for (let t of ce(e, i, a ? 2 : 1)) n(t);
		if (i.species === "monkey" && t.mode === "special") {
			for (let t = 0; t < 3; t++) if (e.tokens[t]) for (let r of le(e, i, t)) n(r, { token: t });
		}
	}
	return [...new Map(r.map((e) => [de(e), e])).values()];
}
var de = (e) => `${e.animal}:${e.path.join(",")}:${e.direction ?? ""}:${e.token ?? ""}`, fe = t.enum([
	"rock",
	"grass",
	"sand"
]), pe = t.enum([
	"cheetah",
	"penguin",
	"wolf",
	"snake",
	"butterfly",
	"sloth",
	"turtle",
	"crocodile",
	"monkey",
	"meerkat"
]), U = t.object({ latecomers: t.boolean().default(!1) }).default({ latecomers: !1 }), W = t.int().min(0).max(77), G = t.int().min(0).max(8), me = t.int().min(0).max(24), he = t.object({
	kind: t.enum([
		"move",
		"discover",
		"bonus",
		"points"
	]),
	n: t.int().min(1).max(5)
}), ge = t.object({
	animal: G,
	path: t.array(me).max(5),
	direction: t.int().min(0).max(3).optional(),
	token: t.int().min(0).max(2).optional()
}), K = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draft"),
		index: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("place"),
		source: t.int().min(-1).max(1),
		cell: me
	}),
	t.object({ type: t.literal("store") }),
	t.object({
		type: t.literal("discard"),
		source: t.int().min(-1).max(1)
	}),
	t.object({
		type: t.literal("resolve"),
		index: t.int().min(0).max(7),
		choice: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("passEffect"),
		index: t.int().min(0).max(7)
	}),
	t.object({
		type: t.literal("bonus"),
		terrain: fe
	}),
	t.object({
		type: t.literal("discover"),
		animal: G
	}),
	t.object({
		type: t.literal("move"),
		move: ge
	}),
	t.object({ type: t.literal("passMovement") }),
	t.object({ type: t.literal("decline") }),
	t.object({ type: t.literal("finish") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), _e = t.object({
	id: G,
	species: pe,
	entrance: t.int().min(25).max(33),
	pos: t.int().min(0).max(33),
	state: t.enum([
		"hidden",
		"board",
		"home",
		"eaten"
	]),
	direction: t.int().min(0).max(3),
	asleep: t.boolean(),
	pollen: t.int().min(0).max(4),
	edge: t.int().min(0).max(33).nullable()
}), ve = t.object({
	mode: t.enum([
		"normal",
		"special",
		"round"
	]),
	left: t.int().min(0).max(2),
	eligible: t.array(G).max(9)
}), ye = t.object({
	actions: t.array(t.array(he).min(1).max(2)).max(8),
	bonus: t.int().min(0).max(2),
	discover: t.int().min(0).max(1),
	held: W.nullable(),
	movement: ve.nullable()
}), be = t.object({
	rid: t.string(),
	tiles: t.array(W.nullable()).length(25),
	animals: t.array(_e).length(9),
	warehouse: t.array(W).max(2),
	frames: t.array(ye).min(1),
	points: t.int().min(0),
	pairs: t.array(t.boolean()).length(3),
	tokens: t.array(t.boolean()).length(3),
	done: t.boolean(),
	setup: t.int().min(0).max(8)
}), xe = t.object({
	immediate: t.number(),
	animals: t.number(),
	discovered: t.number(),
	food: t.number(),
	foods: t.array(t.int().min(0).max(6)),
	home: t.int(),
	total: t.number()
}), Se = t.object({
	kind: t.enum([
		"draft",
		"place",
		"store",
		"discard",
		"discover",
		"move",
		"home",
		"eaten",
		"points",
		"round",
		"leo"
	]),
	rid: t.string(),
	animal: pe.optional(),
	tile: W.optional(),
	n: t.number().optional(),
	terrain: fe.optional()
}), q = t.object({
	phase: t.enum([
		"draft",
		"place",
		"round",
		"done"
	]),
	config: U,
	draft: t.int().min(1).max(15),
	first: t.string(),
	current: t.string(),
	species: t.array(pe).length(3),
	market: t.array(W.nullable()).min(2).max(5),
	leftovers: t.array(W).max(5),
	supply: t.record(fe, t.int().min(0).max(14)),
	players: t.array(be).min(1).max(4),
	scores: t.record(t.string(), xe),
	roundTerrain: fe.nullable(),
	soloCard: t.int().min(0).max(5).nullable(),
	log: t.array(Se),
	serial: t.int().min(0)
}), J = t.object({}), Y = () => ({
	actions: [],
	bonus: 0,
	discover: 0,
	held: null,
	movement: null
}), X = () => ({ code: "games.nightatthezoo.invalid" });
function Z(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var Ce = (e) => !e.actions.length && !e.bonus && !e.discover && e.held === null && !e.movement, Q = (e) => e.frames.length === 1 && Ce(e.frames[0]), we = (e) => !z(e).movement && !e.done, Te = (e, t) => t >= 25 ? P[t - 25].terrain : e.tiles[t] === null ? null : M[e.tiles[t]].terrain;
function Ee(e, t, n, r) {
	let i = Y();
	i.movement = {
		mode: n,
		left: 1,
		eligible: t.animals.filter((e) => B(e).some((e) => Te(t, e) === r)).map((e) => e.id)
	}, t.frames.push(i), n === "round" && e.log.push({
		kind: "round",
		rid: t.rid,
		terrain: r
	});
}
function De(e) {
	for (;;) {
		let t = z(e);
		if (t.movement && (!t.movement.left || !ue(e).length) && (t.movement = null), t.discover && !e.animals.some((e) => e.state === "hidden") && (t.discover = 0), e.frames.length > 1 && Ce(t)) e.frames.pop();
		else break;
	}
}
function Oe(t, n, r) {
	let i = {
		seed: r,
		cursor: 0,
		config: t,
		phase: "draft",
		draft: 1,
		first: "",
		current: "",
		species: [],
		players: [],
		market: [],
		leftovers: [],
		deck: [],
		supply: {
			rock: 14,
			grass: 14,
			sand: 14
		},
		roundTerrain: null,
		soloCard: null,
		soloDeck: [],
		log: [],
		serial: 0
	};
	do
		i.species = Z(i, t.latecomers ? [...E] : E.slice(0, 6)).slice(0, 3);
	while (i.species.reduce((e, t) => e + D[t].moons, 0) < 6);
	let a = Z(i, R.map((e, t) => t));
	return i.players = n.map((e, t) => {
		let n = R[a[t]];
		return {
			rid: e,
			tiles: Array(25).fill(null),
			warehouse: [],
			frames: [Y()],
			points: 0,
			pairs: [
				!1,
				!1,
				!1
			],
			tokens: [
				!0,
				!0,
				!0
			],
			done: !1,
			setup: a[t],
			animals: n.letters.map((e, t) => ({
				id: t,
				species: i.species[e],
				entrance: 25 + t,
				pos: 25 + t,
				state: n.awake.includes(t) ? "board" : "hidden",
				direction: P[t].direction,
				asleep: !1,
				pollen: 0,
				edge: null
			}))
		};
	}), i.deck = Z(i, Array.from({ length: 75 }, (e, t) => t)), i.first = n.length === 1 ? "$leo" : n[e(i.seed, i.cursor++, n.length)], Ae(i), { state: i };
}
function ke(e) {
	return e.players.length === 1 ? [e.players[0].rid, "$leo"] : e.players.map((e) => e.rid);
}
function Ae(e) {
	e.phase = "draft", e.current = e.first, e.roundTerrain = null, e.market = Array.from({ length: e.players.length === 1 ? 3 : e.players.length + 1 }, () => e.deck.pop());
	for (let t of e.players) t.done = !1, t.frames = [Y()];
	e.players.length === 1 && (e.soloDeck.length || (e.soloDeck = Z(e, [
		0,
		1,
		2,
		3,
		4,
		5
	])), e.soloCard = e.soloDeck.pop());
}
function je(e, t) {
	let n = e.market[t];
	e.market[t] = null, e.current === "$leo" ? e.log.push({
		kind: "leo",
		rid: "$leo",
		tile: n
	}) : (e.players.find((t) => t.rid === e.current).frames[0].held = n, e.log.push({
		kind: "draft",
		rid: e.current,
		tile: n
	}));
	let r = ke(e), i = r[(r.indexOf(e.current) + 1) % r.length];
	if (i !== e.first) {
		e.current = i;
		return;
	}
	e.leftovers.push(e.market.find((e) => e !== null)), e.market = e.market.map(() => null), e.current = "", e.phase = "place", e.soloCard !== null && ae[e.soloCard].shuffle && (e.soloDeck = Z(e, [
		0,
		1,
		2,
		3,
		4,
		5
	]));
}
function Me(e) {
	if (!e.players.every((e) => e.done)) return;
	if (e.phase === "place" && e.draft % 5 == 0) {
		let t = {
			rock: 0,
			grass: 0,
			sand: 0
		};
		for (let n of e.leftovers) t[M[n].terrain]++;
		let n = Math.max(...Object.values(t)), r = M[e.leftovers.find((e) => t[M[e].terrain] === n)].terrain;
		e.roundTerrain = r, e.phase = "round";
		for (let t of e.players) t.done = !1, Ee(e, t, "round", r), De(t), Q(t) && (t.done = !0);
		if (!e.players.every((e) => e.done)) return;
	}
	if (e.draft === 15) {
		e.phase = "done";
		return;
	}
	e.phase === "round" && (e.leftovers = []);
	let t = ke(e);
	e.first = t[(t.indexOf(e.first) + 1) % t.length], e.draft++, Ae(e);
}
function Ne(e, t, n) {
	t.points += n, e.log.push({
		kind: "points",
		rid: t.rid,
		n
	});
}
function Pe(e, t, n) {
	if (n.kind === "points") {
		Ne(e, t, n.n);
		return;
	}
	let r = Y();
	n.kind === "move" && (r.movement = {
		mode: "normal",
		left: n.n,
		eligible: []
	}), n.kind === "discover" && (r.discover = n.n), n.kind === "bonus" && (r.bonus = n.n), t.frames.push(r);
}
function Fe(e, t, n, r) {
	t.tiles[r] = n;
	let i = M[n], a = ie[r], o = Y();
	i.options.length && o.actions.push(i.options), a && (!a.terrain || a.terrain === i.terrain) && (!a.discover || i.options.some((e) => e.kind === "discover")) && o.actions.push(...a.actions.map((e) => [e])), L.forEach((e, n) => {
		if (t.pairs[n] || !e.cells.includes(r)) return;
		let [i, a] = e.cells.map((e) => t.tiles[e]);
		i !== null && a !== null && M[i].terrain === M[a].terrain && (t.pairs[n] = !0, o.actions.push([e.reward]));
	}), t.frames.push(o), e.log.push({
		kind: "place",
		rid: t.rid,
		tile: n
	});
}
function Ie(e, t) {
	let n = t.animals.filter((e) => e.species === "crocodile" && e.state === "board");
	for (let r of t.animals) r.species !== "crocodile" && r.state === "board" && n.some((e) => B(e).some((e) => B(r).includes(e) && e !== 12)) && (r.state = "eaten", r.edge = null, Ne(e, t, 3), e.log.push({
		kind: "eaten",
		rid: t.rid,
		animal: r.species
	}));
}
function Le(e, t, { by: n }) {
	if (e.phase === "done") return X();
	let r = structuredClone(e);
	if (t.type === "tick") {
		if (n !== "$engine" || r.phase !== "draft" || r.current !== "$leo" || r.soloCard === null) return X();
		let [e, t] = ae[r.soloCard].priority;
		return je(r, r.market[e] === null ? t : e), r.serial++, { state: r };
	}
	let i = r.players.find((e) => e.rid === n);
	if (!i) return X();
	if (t.type === "draft") return r.phase !== "draft" || r.current !== n || r.market[t.index] == null ? X() : (je(r, t.index), r.serial++, { state: r });
	if (r.phase !== "place" && r.phase !== "round" || i.done) return X();
	let a = z(i), o = (e) => e === -1 ? a.held : we(i) ? i.warehouse[e] ?? null : null, s = (e) => {
		e === -1 ? a.held = null : i.warehouse.splice(e, 1);
	};
	if (a.movement && !["move", "passMovement"].includes(t.type) || r.phase === "round" && ![
		"move",
		"passMovement",
		"finish"
	].includes(t.type)) return X();
	switch (t.type) {
		case "place": {
			let e = o(t.source);
			if (e === null || t.cell === 12 || i.tiles[t.cell] !== null) return X();
			s(t.source), Fe(r, i, e, t.cell);
			break;
		}
		case "store":
			if (a.held === null || i.warehouse.length >= 2) return X();
			i.warehouse.push(a.held), r.log.push({
				kind: "store",
				rid: n,
				tile: a.held
			}), a.held = null;
			break;
		case "discard": {
			let e = o(t.source);
			if (e === null) return X();
			s(t.source), r.log.push({
				kind: "discard",
				rid: n,
				tile: e
			}), Ee(r, i, "special", M[e].terrain);
			break;
		}
		case "resolve": {
			let e = a.actions[t.index]?.[t.choice];
			if (!e || a.held !== null || a.bonus || a.discover) return X();
			a.actions.splice(t.index, 1), Pe(r, i, e);
			break;
		}
		case "passEffect":
			if (!a.actions[t.index] || a.held !== null || a.bonus || a.discover) return X();
			a.actions.splice(t.index, 1);
			break;
		case "bonus":
			if (!a.bonus || a.held !== null || !r.supply[t.terrain]) return X();
			r.supply[t.terrain]--, a.bonus--, a.held = 75 + [
				"rock",
				"grass",
				"sand"
			].indexOf(t.terrain);
			break;
		case "discover": {
			let e = i.animals[t.animal];
			if (!a.discover || e.state !== "hidden") return X();
			e.state = "board", a.discover--, r.log.push({
				kind: "discover",
				rid: n,
				animal: e.species
			});
			break;
		}
		case "move": {
			if (!a.movement || !ue(i).some((e) => de(e) === de(t.move))) return X();
			let e = i.animals[t.move.animal], { mode: o } = a.movement;
			e.species === "butterfly" && o === "special" && t.move.path.length && (e.pollen = Math.min(4, e.pollen + 1)), t.move.token !== void 0 && (i.tokens[t.move.token] = !1, i.tokens.every((e) => !e) && (i.tokens = [
				!0,
				!0,
				!0
			])), t.move.direction === void 0 ? e.species === "sloth" && (e.asleep = !e.asleep) : e.direction = t.move.direction;
			for (let a of t.move.path) {
				if (e.species === "turtle" && e.edge === null && a !== 12 ? e.edge = a : (e.pos = a, e.edge = null), a === 12) {
					e.state = "home", e.edge = null, r.log.push({
						kind: "home",
						rid: n,
						animal: e.species
					});
					break;
				}
				if (Ie(r, i), e.state === "eaten") break;
			}
			r.log.push({
				kind: "move",
				rid: n,
				animal: e.species
			}), o === "normal" ? a.movement.left-- : a.movement.eligible = a.movement.eligible.filter((t) => t !== e.id);
			break;
		}
		case "passMovement":
			if (!a.movement) return X();
			a.movement = null;
			break;
		case "decline":
			if (!a.bonus && !a.discover || a.held !== null) return X();
			a.bonus = 0, a.discover = 0;
			break;
		case "finish":
			if (!Q(i)) return { code: "games.nightatthezoo.unfinished" };
			i.done = !0;
	}
	return De(i), r.phase === "round" && Q(i) && (i.done = !0), Me(r), r.serial++, { state: r };
}
function Re(e) {
	let t = e.animals.filter((e) => e.state === "home"), n = [
		0,
		7,
		16,
		27
	][t.filter((e) => e.species === "wolf").length];
	for (let e of t) e.species !== "wolf" && (e.species === "butterfly" ? n += [
		0,
		5,
		7,
		9,
		11
	][e.pollen] : n += D[e.species].points + (e.species === "turtle" ? t.length - 1 : 0));
	let r = [...new Set(e.tiles.flatMap((e) => e === null || M[e].food === null ? [] : [M[e].food]))].sort((e, t) => e - t), i = A[r.length], a = e.animals.filter((e) => e.state === "board").length;
	return {
		immediate: e.points,
		animals: n,
		discovered: a,
		food: i,
		foods: r,
		home: t.length,
		total: e.points + n + a + i
	};
}
var ze = (e) => e >= 90 ? 4 : e >= 80 ? 3 : e >= 65 ? 2 : +(e >= 50), Be = {
	meta: oe,
	saveCompatibility: { version: "1" },
	schemas: {
		action: K,
		publicView: q,
		privateView: J,
		config: U
	},
	setup: Oe,
	reduce: Le,
	viewFor(e) {
		return {
			public: {
				phase: e.phase,
				config: e.config,
				draft: e.draft,
				first: e.first,
				current: e.current,
				species: [...e.species],
				market: [...e.market],
				leftovers: [...e.leftovers],
				supply: { ...e.supply },
				players: structuredClone(e.players),
				scores: Object.fromEntries(e.players.map((e) => [e.rid, Re(e)])),
				roundTerrain: e.roundTerrain,
				soloCard: e.soloCard,
				log: [...e.log],
				serial: e.serial
			},
			private: {}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((e) => [e.rid, Re(e)])), n = e.players.map((e) => e.rid).sort((e, n) => t[n].total - t[e].total || t[n].home - t[e].home), r = t[n[0]];
		return {
			phase: "done",
			ranking: n,
			winner: n.filter((e) => t[e].total === r.total && t[e].home === r.home),
			scores: Object.fromEntries(n.map((e) => [e, t[e].total]))
		};
	},
	nextTickIn(e) {
		return e.phase === "draft" && e.current === "$leo" ? 450 : null;
	}
}, Ve = {
	cheetah: "<path d=\"M62 103C40 97 29 106 22 115C11 128 5 121 8 113\" fill=\"none\" stroke=\"#a97344\" stroke-width=\"9\" stroke-linecap=\"round\"/><path d=\"m65 116-10 32-12 26 1 10h15l-4-8 15-22 13-27M130 116l5 28 20 26-2 13h15l-2-17-18-27-1-29\" fill=\"#c99150\" stroke=\"#58434c\" stroke-width=\"2.5\"/><path d=\"M50 113C44 93 60 77 87 79L122 85C135 87 143 76 148 64L162 57 179 62 187 76 177 91 156 96 149 123 150 152 141 175 143 184H127l1-13 9-24-8-24-36-2-11 23-8 33 5 6H61l2-12 6-36Z\" fill=\"#e6b467\" stroke=\"#55404b\" stroke-width=\"2.5\"/><path d=\"M149 66 146 48 159 45 168 57M170 57 178 46 188 51 186 67\" fill=\"#c68c51\" stroke=\"#55404b\" stroke-width=\"2\"/><path d=\"M154 81Q169 98 183 81L177 94 157 97Z\" fill=\"#f4d9a0\"/><path d=\"m167 82 8 1-4 5Z\" fill=\"#453443\"/><path d=\"m157 72 3 7M180 72l-3 7\" stroke=\"#443545\" stroke-width=\"3\"/><circle cx=\"157\" cy=\"68\" r=\"2.6\" fill=\"#342c3f\"/><circle cx=\"180\" cy=\"68\" r=\"2.6\" fill=\"#342c3f\"/><g fill=\"#916147\"><path d=\"m65 91 5-4 5 3-3 5ZM87 87l5-3 4 4-3 4ZM109 96l6-3 4 4-4 4ZM72 109l4-4 4 3-1 5ZM92 105l4-2 4 5-5 2ZM125 110l5-3 4 3-2 5ZM139 93l4-4 3 4-2 4ZM146 112l3-2 3 4-3 3ZM72 144l4-1-1 7-4 1ZM143 146l4 2 1 6-4-1ZM155 58l4-2 3 3-4 3ZM172 59l3-3 4 3-3 2Z\"/><path d=\"m29 111 3 4m-17 3 3 5\" stroke=\"#654b43\" stroke-width=\"4\"/></g><path d=\"M82 115q17-6 37 1\" fill=\"none\" stroke=\"#f2d6a1\" stroke-width=\"4\"/>",
	snake: "<path d=\"M157 158C164 142 148 128 126 135C105 141 94 162 67 159C38 156 36 132 64 123L100 113C126 101 131 81 119 65C109 49 89 52 86 65\" fill=\"none\" stroke=\"#503749\" stroke-width=\"27\" stroke-linecap=\"round\"/><path d=\"M157 158C164 142 148 128 126 135C105 141 94 162 67 159C38 156 36 132 64 123L100 113C126 101 131 81 119 65C109 49 89 52 86 65\" fill=\"none\" stroke=\"#e19c80\" stroke-width=\"21\" stroke-linecap=\"round\"/><path d=\"M54 139C76 147 91 130 117 128M113 104q20-18 9-35\" fill=\"none\" stroke=\"#b66d69\" stroke-width=\"8\" stroke-linecap=\"round\"/><path d=\"M68 50C72 34 98 32 108 44C119 59 99 80 82 79C65 80 61 64 68 50Z\" fill=\"#efb38e\" stroke=\"#503749\" stroke-width=\"2.5\"/><path d=\"M70 68Q85 79 101 65\" fill=\"none\" stroke=\"#9d5b62\" stroke-width=\"2.5\"/><ellipse cx=\"79\" cy=\"49\" rx=\"5\" ry=\"7\" fill=\"#fbddae\"/><ellipse cx=\"97\" cy=\"47\" rx=\"5\" ry=\"7\" fill=\"#fbddae\"/><path d=\"M79 44v10M97 42v10\" stroke=\"#34303e\" stroke-width=\"2.6\"/><path d=\"m80 80-3 12-6 3m6-3 4 6\" stroke=\"#ce6e7e\" stroke-width=\"3\" fill=\"none\"/><g stroke=\"#f8d4a6\" stroke-width=\"3\" stroke-linecap=\"round\"><path d=\"m62 130 3 8m18-15 3 8m18-18 4 7m13-23 6 4m-1-27 7-1m-7 64 3 8m-23 4 5 6m-25 1 1 7m-28-4-3 7\"/></g>",
	butterfly: "<path d=\"M98 95C66 35 31 15 15 48C0 78 36 103 65 112C23 110 15 137 34 158C57 183 83 152 98 126M104 95C134 35 169 15 185 48C200 78 164 103 135 112C177 110 185 137 166 158C143 183 117 152 104 126\" fill=\"#db9dbf\" stroke=\"#63425e\" stroke-width=\"3\"/><path d=\"M88 97C63 61 31 36 26 58C25 78 52 95 88 106M112 97C137 61 169 36 174 58C175 78 148 95 112 106\" fill=\"#b183b6\"/><path d=\"M88 127Q51 125 45 146Q65 160 88 127M112 127Q149 125 155 146Q135 160 112 127\" fill=\"#8f73a6\"/><path d=\"M96 80Q100 72 105 81L108 135Q103 153 98 136Z\" fill=\"#4c3f59\"/><path d=\"M98 84Q90 62 83 59M104 84Q111 62 118 59\" fill=\"none\" stroke=\"#4c3f59\" stroke-width=\"3\" stroke-linecap=\"round\"/><g fill=\"#f7d3aa\"><path d=\"M39 66q11-6 18 9-11 9-18-9M161 66q-11-6-18 9 11 9 18-9M53 140l10-5-4 12ZM147 140l-10-5 4 12Z\"/><circle cx=\"72\" cy=\"96\" r=\"4\"/><circle cx=\"128\" cy=\"96\" r=\"4\"/></g><path d=\"M38 93q28 18 48 19M162 93q-28 18-48 19\" stroke=\"#f1b9ce\" stroke-width=\"3\" fill=\"none\"/>",
	turtle: "<path d=\"m56 126-20 20 1 12 19-1 15-21M123 132l9 22 19 3 1-13-14-20M55 77 38 68l-4 12 15 12M130 75l12-16 15 7-7 17\" fill=\"#87ad80\" stroke=\"#3e5b52\" stroke-width=\"3\"/><path d=\"m41 115-24 7 26-1\" fill=\"#a4c18b\" stroke=\"#3e5b52\" stroke-width=\"2\"/><path d=\"M139 93C143 73 164 69 176 80C188 93 179 112 166 116L143 112Z\" fill=\"#b1cc93\" stroke=\"#3e5b52\" stroke-width=\"3\"/><path d=\"M46 110C39 77 69 51 100 56C132 58 151 85 145 112C136 139 57 142 46 110Z\" fill=\"#658d68\" stroke=\"#34564b\" stroke-width=\"3\"/><path d=\"m82 68 25-1 15 20-11 28-27 4-17-23Z\" fill=\"#91af73\" stroke=\"#42664f\" stroke-width=\"3\"/><path d=\"m82 68-9-9M107 67l12-6M122 87l20-1M111 115l16 15M84 119l-3 16M67 96l-22 4\" fill=\"none\" stroke=\"#42664f\" stroke-width=\"3\"/><path d=\"M58 83Q72 63 94 63\" fill=\"none\" stroke=\"#b7cb8c\" stroke-width=\"4\" stroke-linecap=\"round\"/><circle cx=\"169\" cy=\"87\" r=\"4\" fill=\"#283e3d\"/><path d=\"M164 103q8 2 13-3\" stroke=\"#60816a\" stroke-width=\"2\" fill=\"none\"/>",
	crocodile: "<path d=\"M67 123C44 121 24 137 9 144L26 125 49 112Z\" fill=\"#5b956d\" stroke=\"#334b45\" stroke-width=\"2.5\"/><path d=\"m79 126-9 27-16 9 23 3 15-20M134 120l13 27 15 5 7-5-15-10-6-26\" fill=\"#81b17d\" stroke=\"#334b45\" stroke-width=\"2.5\"/><path d=\"M47 116C51 86 76 83 103 87L132 81L144 64L162 65L174 79 194 81 188 102 160 110 142 128 97 135 64 131Z\" fill=\"#8bb981\" stroke=\"#334b45\" stroke-width=\"2.5\"/><path d=\"M61 104Q98 90 128 96L146 84 189 88\" fill=\"none\" stroke=\"#b7ce91\" stroke-width=\"5\"/><path d=\"m66 89 7-13 10 9 11-13 9 13 12-13 10 12M42 119l-5-9-8 13\" fill=\"#527c60\" stroke=\"#334b45\" stroke-width=\"2\"/><path d=\"M145 97H188L178 109L153 113Z\" fill=\"#d4d8a1\"/><path d=\"m152 98 5 7 5-7 6 7 5-7 5 7 5-8\" stroke=\"#465c4b\" stroke-width=\"2\" fill=\"#f5e6bc\"/><path d=\"M143 79Q143 64 153 69L159 79\" fill=\"#acc589\" stroke=\"#334b45\" stroke-width=\"2\"/><circle cx=\"152\" cy=\"75\" r=\"3\" fill=\"#2c3c39\"/><g stroke=\"#50795d\" stroke-width=\"3\" stroke-linecap=\"round\"><path d=\"m72 108 7 2m8-6 7 2m7-5 7 2m-40 17 7 2m12-7 8 2m10-7 7 2\"/></g>",
	monkey: "<path d=\"M69 128C41 155 17 141 21 119C25 97 43 110 36 120\" fill=\"none\" stroke=\"#4f3657\" stroke-width=\"13\" stroke-linecap=\"round\"/><path d=\"M69 128C41 155 17 141 21 119C25 97 43 110 36 120\" fill=\"none\" stroke=\"#b18ab6\" stroke-width=\"9\" stroke-linecap=\"round\"/><path d=\"M82 116 72 159 63 174 78 178 89 162 101 133M121 119l15 33-2 23 13 4 3-30-13-35\" fill=\"#a17ba7\" stroke=\"#4f3657\" stroke-width=\"2.5\"/><path d=\"M78 83C64 101 61 137 88 144C119 155 145 127 132 100L119 84Z\" fill=\"#b58cba\" stroke=\"#4f3657\" stroke-width=\"2.5\"/><path d=\"M94 101C74 107 79 137 102 137C126 136 128 113 112 103Z\" fill=\"#d9b6b4\"/><path d=\"M76 97 53 80 49 47 39 43 34 53 43 89 69 116M125 96l23-14 14-28 13-1 1 12-17 31-28 21\" fill=\"#b58cba\" stroke=\"#4f3657\" stroke-width=\"2.5\"/><path d=\"M40 44q-7-13-1-18M46 46q-3-13 1-19M167 56q0-13 6-19M173 60q6-11 10-10\" stroke=\"#4f3657\" stroke-width=\"4\" fill=\"none\" stroke-linecap=\"round\"/><ellipse cx=\"73\" cy=\"63\" rx=\"13\" ry=\"15\" fill=\"#b58cba\" stroke=\"#4f3657\" stroke-width=\"2\"/><ellipse cx=\"130\" cy=\"63\" rx=\"13\" ry=\"15\" fill=\"#b58cba\" stroke=\"#4f3657\" stroke-width=\"2\"/><path d=\"M73 53C71 24 127 23 131 53L129 81C121 104 84 101 75 82Z\" fill=\"#b58cba\" stroke=\"#4f3657\" stroke-width=\"2.5\"/><path d=\"M80 56Q86 40 101 51Q117 40 124 56L124 78Q102 101 80 78Z\" fill=\"#eed0b3\"/><ellipse cx=\"90\" cy=\"62\" rx=\"3.4\" ry=\"5\" fill=\"#3e3049\"/><ellipse cx=\"115\" cy=\"62\" rx=\"3.4\" ry=\"5\" fill=\"#3e3049\"/><path d=\"M94 80q8 8 18-1M99 70l5 3 5-3\" fill=\"none\" stroke=\"#775064\" stroke-width=\"2.5\" stroke-linecap=\"round\"/>",
	meerkat: "<path d=\"M106 142C131 164 143 170 153 168\" stroke=\"#76504d\" stroke-width=\"7\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M78 161 72 181 61 187 84 188 91 165M108 163l6 20 21 3-12-10-2-21\" fill=\"#bd9274\" stroke=\"#5d4446\" stroke-width=\"2.5\"/><path d=\"M81 75C77 95 67 113 70 142C70 174 118 181 127 148C133 125 116 93 113 76Z\" fill=\"#d3aa82\" stroke=\"#5d4446\" stroke-width=\"2.5\"/><path d=\"M88 98C82 116 81 144 94 156C103 165 114 153 115 142C115 123 104 108 104 97Z\" fill=\"#eed4a2\"/><path d=\"M77 103 65 119 80 130 97 121M116 103l14 20-20 8-14-10\" fill=\"#c99e7d\" stroke=\"#76534e\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M74 49 64 39 65 26 80 26 88 40M110 39l11-14 15 2 2 13-13 14\" fill=\"#c59a7b\" stroke=\"#5d4446\" stroke-width=\"2.5\"/><path d=\"M71 47C78 29 119 31 129 50C141 77 120 96 98 94C77 96 61 72 71 47Z\" fill=\"#dfb58a\" stroke=\"#5d4446\" stroke-width=\"2.5\"/><path d=\"M71 55Q83 44 93 59L89 70 74 69ZM109 59Q121 44 132 56L128 69 113 70Z\" fill=\"#725456\"/><ellipse cx=\"83\" cy=\"59\" rx=\"3.2\" ry=\"4.8\" fill=\"#f4e3bb\"/><ellipse cx=\"119\" cy=\"59\" rx=\"3.2\" ry=\"4.8\" fill=\"#f4e3bb\"/><path d=\"M88 76Q100 65 113 76L105 86H96Z\" fill=\"#edcc9e\"/><path d=\"m95 74 7 2 6-2-6 7Z\" fill=\"#503c42\"/><path d=\"M95 87q6 3 12-1\" fill=\"none\" stroke=\"#81584e\" stroke-width=\"2\"/>",
	sloth: "\n<path d=\"M8 42Q74 14 187 28L190 38Q87 24 11 52Z\" fill=\"#7c5b78\"/><path d=\"M26 39Q83 23 165 29\" fill=\"none\" stroke=\"#ae8298\" stroke-width=\"3\"/>\n<path d=\"M139 37C128 65 134 79 146 94C166 118 158 154 130 172C103 191 60 177 48 151C36 124 47 103 62 85L64 43L80 36C88 68 78 85 73 103C86 94 101 97 109 103C109 85 116 58 122 36Z\" fill=\"#81baa9\" stroke=\"#193f48\" stroke-width=\"2.4\"/>\n<path d=\"M140 53C133 86 153 101 148 128C144 157 123 175 95 174C124 167 133 139 118 121C108 110 109 92 119 68L127 43Z\" fill=\"#5e9f95\"/>\n<path d=\"M55 125C55 151 79 173 108 165C120 161 130 152 128 138C126 124 112 118 98 115Z\" fill=\"#a3d3bc\"/>\n<path d=\"M66 43Q60 27 65 22Q71 22 72 39M73 41Q69 24 74 22Q81 23 80 40M125 39Q124 23 129 21Q135 22 133 38M134 39Q135 23 140 23Q146 27 141 41\" fill=\"none\" stroke=\"#203f48\" stroke-width=\"5\" stroke-linecap=\"round\"/>\n<g transform=\"rotate(-25 68 106)\"><path d=\"M36 97C34 71 58 62 79 70C103 79 109 107 91 122C68 141 40 125 36 97Z\" fill=\"#bcdfc5\" stroke=\"#244b4c\" stroke-width=\"2\"/>\n<path d=\"M39 87Q55 69 67 88Q82 75 98 94L92 108Q78 113 68 97Q55 111 40 100Z\" fill=\"#285453\"/>\n<ellipse cx=\"54\" cy=\"91\" rx=\"6\" ry=\"9\" fill=\"#f4f2d4\"/><ellipse cx=\"83\" cy=\"96\" rx=\"6\" ry=\"9\" fill=\"#f4f2d4\"/><ellipse cx=\"55\" cy=\"92\" rx=\"3\" ry=\"6\" fill=\"#163b3e\"/><ellipse cx=\"82\" cy=\"96\" rx=\"3\" ry=\"6\" fill=\"#163b3e\"/>\n<path d=\"M62 109Q68 116 76 111M65 101Q71 98 75 103L70 108Z\" fill=\"#204547\" stroke=\"#204547\" stroke-width=\"2\" stroke-linecap=\"round\"/></g>\n<g fill=\"none\" stroke=\"#cee6cd\" stroke-width=\"3\" stroke-linecap=\"round\"><path d=\"m91 132 3 7m9-13 4 7m8-6 3 7m-39 8 5 6m10-2 4 6m11-6 4 6M66 60l-2 8m10-15-1 7m51 4-2 8m5 18 2 7\"/></g>\n<g stroke=\"#3e7c77\" stroke-width=\"2.4\" stroke-linecap=\"round\"><path d=\"m60 145 5 6m12 6 5 3m18-4 7-2m27-11 4-6m-2-27 4 6m-8-63-2 9\"/></g>",
	penguin: "\n<path d=\"M74 91C51 96 21 124 12 150C38 145 59 133 77 116Z\" fill=\"#373051\" stroke=\"#18192e\" stroke-width=\"2.5\"/>\n<path d=\"M121 80C146 92 168 111 185 132C161 133 138 117 117 106Z\" fill=\"#443962\" stroke=\"#18192e\" stroke-width=\"2.5\"/>\n<path d=\"M99 25C74 24 66 44 69 72C72 98 54 129 57 152C60 181 86 190 111 185C137 180 145 162 136 135C126 104 131 89 127 68C125 40 122 27 99 25Z\" fill=\"#332b50\" stroke=\"#191b30\" stroke-width=\"2.5\"/>\n<path d=\"M97 59C90 73 91 92 81 113C64 148 65 171 86 178C106 186 124 175 127 156C130 139 117 111 116 95C116 78 118 68 111 59Z\" fill=\"#d3e7d7\"/>\n<path d=\"M101 79C109 102 111 120 118 139C127 168 109 179 98 181C122 180 135 167 128 142C120 116 119 91 113 75Z\" fill=\"#9ec7c1\"/>\n<path d=\"m121 51 27 11-22 7Z\" fill=\"#ef9a59\" stroke=\"#7c4c56\" stroke-width=\"1.5\"/><path d=\"m128 69 14 0-16 8Z\" fill=\"#d7764e\"/>\n<path d=\"M85 177Q82 179 76 189L61 195L76 196L85 191L87 198L92 189L97 183M112 178L113 187L107 197L119 193L126 196L125 187L136 191L128 180Z\" fill=\"#eb9257\" stroke=\"#8f5459\" stroke-width=\"1.8\" stroke-linejoin=\"round\"/>\n<ellipse cx=\"111\" cy=\"48\" rx=\"6\" ry=\"8\" fill=\"#f1ead7\"/><ellipse cx=\"113\" cy=\"49\" rx=\"3.3\" ry=\"5.4\" fill=\"#222039\"/><circle cx=\"114\" cy=\"47\" r=\"1.2\" fill=\"#fff\"/>\n<path d=\"M82 43Q92 32 102 34M75 57Q74 69 78 78M67 133l-2 15M138 107l13 10\" fill=\"none\" stroke=\"#6e608f\" stroke-width=\"3\" stroke-linecap=\"round\"/>\n<path d=\"M91 109Q85 124 83 140M96 155l1 9\" fill=\"none\" stroke=\"#e6efda\" stroke-width=\"3\" stroke-linecap=\"round\"/>",
	wolf: "\n<path d=\"M61 95C44 97 28 112 19 123L6 127L13 139C29 144 53 126 70 117Z\" fill=\"#544369\" stroke=\"#24243c\" stroke-width=\"2\"/>\n<path d=\"M142 78L134 119L125 148L130 176L122 185L109 184L116 175L112 145L117 120L119 91Z\" fill=\"#4a3c61\" stroke=\"#29243e\" stroke-width=\"2\"/>\n<path d=\"M88 107L83 133L66 151L65 179L57 185L45 183L51 177L52 147L64 120L65 99Z\" fill=\"#504165\" stroke=\"#29243e\" stroke-width=\"2\"/>\n<path d=\"M51 110C53 90 65 77 90 80L122 86C140 75 143 55 157 46L169 31L178 39L170 58L165 75C170 87 168 101 155 115C145 125 130 123 118 119L95 116L86 137L75 152L78 176L71 183L57 182L62 175L61 148L69 126Z\" fill=\"#817494\" stroke=\"#26233b\" stroke-width=\"2.3\"/>\n<path d=\"M140 90C153 78 154 64 163 59L171 54L166 79L157 100L153 122L151 154L157 177L150 185L137 185L143 177L137 151L134 121Z\" fill=\"#b9c5bc\" stroke=\"#514b65\" stroke-width=\"1.5\"/>\n<path d=\"M149 57L143 42L157 47L168 27L183 13L189 17L179 40L170 57Z\" fill=\"#8a83a0\" stroke=\"#29253e\" stroke-width=\"2\"/>\n<path d=\"M145 43L154 50L150 52Z\" fill=\"#c1cebf\"/><path d=\"M168 27L179 24L181 19L176 21L171 17L168 21Z\" fill=\"#b8d8ce\"/>\n<path d=\"M182 13L190 14L187 20L181 20Z\" fill=\"#24253e\"/><path d=\"M169 46L178 39\" fill=\"none\" stroke=\"#25253e\" stroke-width=\"2.3\"/><path d=\"M165 37L170 33\" stroke=\"#202238\" stroke-width=\"2.4\" stroke-linecap=\"round\"/>\n<path d=\"M66 96Q92 86 116 99L132 95M62 106l13-6M43 121l12-5M20 131l14-4\" fill=\"none\" stroke=\"#58486e\" stroke-width=\"5\" stroke-linecap=\"round\"/>\n<g fill=\"none\" stroke=\"#b7c7bc\" stroke-width=\"2.4\" stroke-linecap=\"round\"><path d=\"m146 85-5 9m14-7-5 12m1 7-7 8m-4-1-3 8m-29-20 5 1m-18-5 4 1m-17-2 4-1m-2 18-5 4m-1 11-5 5m-7 22 1 6m80-12 1 7\"/></g>\n<path d=\"M52 180h10M140 183h12M111 182h11\" stroke=\"#36304e\" stroke-width=\"2\"/>"
}, He = {
	empty: "<g transform=\"scale(1)\"><path d=\"M8 4Q23 0 38 4T66 4Q84 0 94 7Q99 21 94 39Q98 53 95 67Q100 86 93 94Q77 99 62 95Q48 98 34 95Q16 99 6 92Q1 76 5 62Q1 46 5 34Q1 14 8 4Z\" fill=\"#151329\" transform=\"translate(0 3)\"/><path d=\"M8 4Q23 0 38 4T66 4Q84 0 94 7Q99 21 94 39Q98 53 95 67Q100 86 93 94Q77 99 62 95Q48 98 34 95Q16 99 6 92Q1 76 5 62Q1 46 5 34Q1 14 8 4Z\" fill=\"#74659c\" stroke=\"#4b3c6b\" stroke-width=\"2\"/><path d=\"M12 11Q26 8 37 11M69 9l18 4M8 71l1 12M15 93l18-1\" fill=\"none\" stroke=\"#a495c2\" stroke-opacity=\".45\" stroke-width=\"2\"/></g>",
	rock: "<g transform=\"scale(1)\"><path d=\"M8 4Q23 0 38 4T66 4Q84 0 94 7Q99 21 94 39Q98 53 95 67Q100 86 93 94Q77 99 62 95Q48 98 34 95Q16 99 6 92Q1 76 5 62Q1 46 5 34Q1 14 8 4Z\" fill=\"#151329\" transform=\"translate(0 3)\"/><path d=\"M8 4Q23 0 38 4T66 4Q84 0 94 7Q99 21 94 39Q98 53 95 67Q100 86 93 94Q77 99 62 95Q48 98 34 95Q16 99 6 92Q1 76 5 62Q1 46 5 34Q1 14 8 4Z\" fill=\"#df694f\" stroke=\"#382842\" stroke-width=\"2\"/><g fill=\"none\" stroke=\"#9b4147\" stroke-width=\"2\"><path d=\"M5 35 30 27 42 3M30 27 42 50 12 70 4 66M42 50 70 43 90 63 96 58M70 43 81 12 95 7M12 70 29 96M90 63 73 87 76 96\"/><path d=\"m48 74 12-10 10 12-7 9-13-2Z\" fill=\"#f18c69\"/></g></g>",
	grass: "<g transform=\"scale(1)\"><path d=\"M8 4Q23 0 38 4T66 4Q84 0 94 7Q99 21 94 39Q98 53 95 67Q100 86 93 94Q77 99 62 95Q48 98 34 95Q16 99 6 92Q1 76 5 62Q1 46 5 34Q1 14 8 4Z\" fill=\"#151329\" transform=\"translate(0 3)\"/><path d=\"M8 4Q23 0 38 4T66 4Q84 0 94 7Q99 21 94 39Q98 53 95 67Q100 86 93 94Q77 99 62 95Q48 98 34 95Q16 99 6 92Q1 76 5 62Q1 46 5 34Q1 14 8 4Z\" fill=\"#4aa183\" stroke=\"#382842\" stroke-width=\"2\"/><g stroke=\"#276d63\" stroke-width=\"2.5\" fill=\"none\"><path d=\"m8 87 5-17 8 14 10-25M18 30l3-15 6 12 7-17M64 84l1-24 9 17 12-31M73 32l8-20 6 15M36 96l7-15 10 13\"/></g><g fill=\"#82c5a0\"><path d=\"m45 39 3-13 6 14-6 7Z\"/><path d=\"m13 52 7-5-1 10Z\"/></g></g>",
	sand: "<g transform=\"scale(1)\"><path d=\"M8 4Q23 0 38 4T66 4Q84 0 94 7Q99 21 94 39Q98 53 95 67Q100 86 93 94Q77 99 62 95Q48 98 34 95Q16 99 6 92Q1 76 5 62Q1 46 5 34Q1 14 8 4Z\" fill=\"#151329\" transform=\"translate(0 3)\"/><path d=\"M8 4Q23 0 38 4T66 4Q84 0 94 7Q99 21 94 39Q98 53 95 67Q100 86 93 94Q77 99 62 95Q48 98 34 95Q16 99 6 92Q1 76 5 62Q1 46 5 34Q1 14 8 4Z\" fill=\"#e8bb70\" stroke=\"#382842\" stroke-width=\"2\"/><g stroke=\"#bc8e51\" stroke-width=\"2\" fill=\"none\"><path d=\"M6 26q15-9 34 0t45 0M15 72q21-10 40 0t43 0M48 12q18 6 30-1M25 84q20 7 34 0\"/></g><g fill=\"#c9995e\"><ellipse cx=\"20\" cy=\"51\" rx=\"3\" ry=\"2\"/><ellipse cx=\"80\" cy=\"51\" rx=\"2\" ry=\"1.6\"/><ellipse cx=\"76\" cy=\"89\" rx=\"3\" ry=\"2\"/></g></g>"
}, Ue = [
	"<path d=\"M30 16C17 8 7 19 10 34C12 50 24 54 30 50C37 55 49 47 51 31C53 18 42 11 30 16Z\" fill=\"#eb7972\" stroke=\"#7a4254\" stroke-width=\"2\"/><path d=\"M30 17 33 5\" stroke=\"#65495a\" stroke-width=\"4\"/><path d=\"M34 11Q38-1 49 4Q48 15 34 11Z\" fill=\"#7cb89c\"/><path d=\"M19 22q-5 7-2 13\" fill=\"none\" stroke=\"#ffd1ae\" stroke-width=\"3\" stroke-linecap=\"round\"/>",
	"<path d=\"M15 18Q30 10 44 17\" fill=\"none\" stroke=\"#a0c39e\" stroke-width=\"3\"/><path d=\"M29 15Q23 0 13 4Q13 17 29 15\" fill=\"#87b098\"/><g fill=\"#a69bd2\" stroke=\"#5d5485\" stroke-width=\"2\"><circle cx=\"20\" cy=\"30\" r=\"12\"/><circle cx=\"40\" cy=\"31\" r=\"12\"/><circle cx=\"30\" cy=\"44\" r=\"12\"/></g><g fill=\"#ddd1ef\"><circle cx=\"17\" cy=\"26\" r=\"3\"/><circle cx=\"37\" cy=\"27\" r=\"3\"/><circle cx=\"27\" cy=\"40\" r=\"3\"/></g>",
	"<path d=\"M15 18Q26 13 39 27Q29 46 7 57Q7 31 15 18Z\" fill=\"#ed9a5d\" stroke=\"#a56051\" stroke-width=\"2\"/><path d=\"M35 22Q30 5 40 3L42 17Q44 2 52 8L46 21Q58 16 57 25L41 29Z\" fill=\"#90bc8b\"/><path d=\"m16 28 8 5m-11 4 7 4m3-18 7 5\" stroke=\"#ba6c51\" stroke-width=\"2.5\"/>",
	"<path d=\"m36 37 13 13M45 49q-4 9 3 9 4 0 6-5 7-1 5-6-2-5-8-2\" fill=\"#ecd9ad\" stroke=\"#c7ad91\" stroke-width=\"5\" stroke-linecap=\"round\"/><path d=\"M34 39C54 26 44 4 26 8C6 12 3 39 17 45Q26 48 34 39Z\" fill=\"#c78379\" stroke=\"#845566\" stroke-width=\"2\"/><path d=\"M15 30q1-13 13-15\" fill=\"none\" stroke=\"#e6aaa0\" stroke-width=\"4\" stroke-linecap=\"round\"/>",
	"<path d=\"M30 6C13 8 4 39 15 49C24 58 43 55 49 43C54 29 41 7 30 6Z\" fill=\"#eee8c9\" stroke=\"#a38c80\" stroke-width=\"2\"/><path d=\"M20 28q-9 19 6 21\" fill=\"none\" stroke=\"#fff7df\" stroke-width=\"4\" stroke-linecap=\"round\"/>",
	"<path d=\"M30 54C16 52 3 43 8 34Q0 20 13 17Q13 2 26 9Q37-3 44 13Q58 10 53 26Q65 36 50 44Q48 58 30 54Z\" fill=\"#95bd81\" stroke=\"#537f68\" stroke-width=\"2\"/><path d=\"M30 48 32 18M31 36 18 25M31 43l14-15\" fill=\"none\" stroke=\"#d0db9b\" stroke-width=\"3\"/>",
	"<path d=\"M9 30Q27 9 47 29L58 18V44L47 34Q27 52 9 30Z\" fill=\"#94bfc1\" stroke=\"#42666f\" stroke-width=\"2\"/><path d=\"m30 20 5-11 8 14M30 40l5 10 8-12\" fill=\"#67a6ad\"/><circle cx=\"19\" cy=\"28\" r=\"3\" fill=\"#253e4f\"/><path d=\"M29 23q-5 8 0 15\" fill=\"none\" stroke=\"#cce2d2\" stroke-width=\"2.5\"/>"
], We = "<g fill=\"currentColor\"><path d=\"M0 6C-2-47-7-70 3-105C10-79 5-42 0 6Z\"/><path d=\"M0-3C-16-9-37-8-51-24C-26-25-10-16 0-3M0-19C-21-26-39-27-48-47C-24-43-8-30 0-19M0-37C-17-44-27-51-31-70C-12-61-4-47 0-37M1-58C-11-65-13-77-12-87C-1-78 2-67 1-58M1-2C18-11 39-12 51-29C27-27 12-15 1-2M1-19C18-27 39-34 43-52C24-47 8-32 1-19M0-39C13-47 24-54 27-73C11-64 4-51 0-39M1-59C10-67 14-82 12-93C4-83 2-70 1-59\"/></g>", Ge = "<g transform=\"translate(0 0) scale(1)\"><path d=\"M7 89H93V96H7Z\" fill=\"#3c3156\"/><path d=\"M20 87V42Q50-2 80 42V87Z\" fill=\"#251f3d\" stroke=\"#d1ac72\" stroke-width=\"2.5\"/><path d=\"M28 87V44Q50 12 72 44V87M28 60H72M50 26V87M39 35V87M61 35V87\" fill=\"none\" stroke=\"#cead7b\" stroke-width=\"2.1\"/><path d=\"M13 84V48M87 84V48\" stroke=\"#75618e\" stroke-width=\"6\"/><path d=\"M9 47h8V36H9Zm74 0h8V36h-8Z\" fill=\"#f3cd7f\" stroke=\"#ba885f\" stroke-width=\"1.5\"/><path d=\"M7 35h12l-6-7ZM81 35h12l-6-7Z\" fill=\"#534366\"/><path d=\"M29 25Q50 5 71 25L66 33Q50 20 34 33Z\" fill=\"#ccb58a\"/><text x=\"50\" y=\"26\" fill=\"#3a3150\" font-size=\"9\" text-anchor=\"middle\" font-weight=\"800\">ZOO</text></g>";
function Ke({ species: e }) {
	return /* @__PURE__ */ b("g", {
		transform: "scale(.32)",
		dangerouslySetInnerHTML: { __html: Ve[e] }
	});
}
function qe({ food: e }) {
	return /* @__PURE__ */ b("g", { dangerouslySetInnerHTML: { __html: Ue[e] } });
}
function Je({ terrain: e = "empty" }) {
	return /* @__PURE__ */ b("g", { dangerouslySetInnerHTML: { __html: He[e] } });
}
function Ye() {
	return /* @__PURE__ */ b("g", { dangerouslySetInnerHTML: { __html: Ge } });
}
function Xe() {
	return /* @__PURE__ */ b("g", { dangerouslySetInnerHTML: { __html: We } });
}
function Ze({ kind: e, n: t = 1 }) {
	return e === "discover" ? /* @__PURE__ */ x("g", {
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "3.2",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ b("circle", {
				cx: "-9",
				cy: "7",
				r: "8"
			}),
			/* @__PURE__ */ b("circle", {
				cx: "9",
				cy: "7",
				r: "8"
			}),
			/* @__PURE__ */ b("path", { d: "m-16 2 4-16h5l3 15m20 1-4-16H7L4 1M-3 4h6" })
		]
	}) : e === "bonus" ? /* @__PURE__ */ x("g", {
		fill: "currentColor",
		children: [
			/* @__PURE__ */ b("path", { d: "M-17-15Q-7-18 1-15Q9-18 17-15L16 1L18 16L0 15L-16 17L-15 0Z" }),
			/* @__PURE__ */ b("path", {
				d: "M-9 0H9M0-9V9",
				stroke: "#423652",
				strokeWidth: "4"
			}),
			t > 1 && /* @__PURE__ */ b("text", {
				x: "17",
				y: "18",
				fontSize: "17",
				fontWeight: "900",
				children: t
			})
		]
	}) : e === "points" ? /* @__PURE__ */ x("g", {
		fill: "currentColor",
		children: [/* @__PURE__ */ b("path", { d: "m0-21 6 14 15 1-11 11 3 15-13-8-13 8 3-15-11-11 15-1Z" }), /* @__PURE__ */ b("text", {
			y: "7",
			textAnchor: "middle",
			fontSize: "18",
			fontWeight: "900",
			fill: "#4b3e62",
			children: t
		})]
	}) : /* @__PURE__ */ b("g", {
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "4.5",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: /* @__PURE__ */ b("path", { d: t === 2 ? "M-18-14-5 0-18 14M-1-14 12 0-1 14" : "M-10-15 5 0-10 15" })
	});
}
function Qe({ terrain: e }) {
	return /* @__PURE__ */ b("g", {
		strokeWidth: "2.5",
		strokeLinejoin: "round",
		children: e === "rock" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("path", {
			d: "M7 42 19 14 40 8 55 35 45 51 18 53Z",
			fill: "#df795e",
			stroke: "#8e414b"
		}), /* @__PURE__ */ b("path", {
			d: "m19 14 9 22 27-1M28 36 18 53M28 36 40 8",
			fill: "none",
			stroke: "#8e414b"
		})] }) : e === "grass" ? /* @__PURE__ */ b("path", {
			d: "M11 51 8 17 25 36 31 4 37 35 56 17 47 52Z",
			fill: "#7cc9a0",
			stroke: "#276f64"
		}) : /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("path", {
			d: "M3 40Q19 20 32 34Q46 22 57 39L54 52H6Z",
			fill: "#efd08d"
		}), /* @__PURE__ */ b("path", {
			d: "M11 43q14-9 25 0M36 48l10-3",
			stroke: "#b78e55",
			fill: "none"
		})] })
	});
}
function $e({ id: e, foodOnly: t = !1 }) {
	let n = M[e];
	return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(Je, { terrain: n.terrain }), n.food === null ? !t && /* @__PURE__ */ x("g", {
		color: "#f7eed8",
		children: [n.options.map((e, t) => /* @__PURE__ */ b("g", {
			transform: `translate(${n.options.length > 1 ? 27 + t * 47 : 50} 51) scale(${n.options.length > 1 ? .88 : 1.2})`,
			children: /* @__PURE__ */ b(Ze, { ...e })
		}, t)), n.options.length > 1 && /* @__PURE__ */ b("path", {
			d: "M50 24V77",
			stroke: "currentColor",
			strokeWidth: "1.5",
			opacity: ".7"
		})]
	}) : /* @__PURE__ */ b("g", {
		transform: t ? "translate(8 7) scale(.57)" : "translate(20 19)",
		children: /* @__PURE__ */ b(qe, { food: n.food })
	})] });
}
function et({ id: e }) {
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 100 104",
		"aria-hidden": "true",
		children: /* @__PURE__ */ b($e, { id: e })
	});
}
var $ = (e) => {
	let [t, n] = N(e);
	return [t * 100 + 50, n * 100 + 50];
};
function tt(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
	for (let r of e.animals) {
		if (r.state === "home" || r.state === "eaten") {
			t.set(r.id, $(12));
			continue;
		}
		if (r.edge !== null) {
			let [e, n] = $(r.pos), [i, a] = $(r.edge);
			t.set(r.id, [(e + i) / 2, (n + a) / 2]);
			continue;
		}
		let e = n.get(r.pos) ?? [];
		e.push(r), n.set(r.pos, e);
	}
	for (let [e, r] of n) {
		let [n, i] = $(e), a = r.length > 4 ? 3 : r.length > 1 ? 2 : 1;
		r.forEach((e, o) => t.set(e.id, [n + (o % a - (a - 1) / 2) * 31, i + (Math.floor(o / a) - (Math.ceil(r.length / a) - 1) / 2) * 31]));
	}
	return {
		positions: t,
		clusters: n
	};
}
function nt({ player: e, serial: t, selectedCell: n, selectedAnimal: a, selectedTile: o, legalCells: s, moving: c, interactive: l, label: u, cellLabel: d, entranceLabel: f, animalLabel: p, onCell: m }) {
	let { positions: h, clusters: g } = tt(e), _ = i(null), ee = i(/* @__PURE__ */ new Map()), v = i(/* @__PURE__ */ new Map()), y = i(t);
	r(() => {
		let n = _.current, r = t === y.current + 1;
		_.current = e, y.current = t;
		let i = [];
		if (!n || n.rid !== e.rid || !r || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		let a = tt(n).positions, o = ue(n);
		for (let t of e.animals) {
			let e = n.animals[t.id], r = ee.current.get(t.id), s = a.get(t.id), c = h.get(t.id);
			if (r && s && c && e.state !== "home" && e.state !== "eaten") {
				if (t.pos !== e.pos || t.edge !== e.edge || t.state !== e.state) {
					let e = o.filter((e) => e.animal === t.id && e.path.length && e.path.at(-1) === (t.edge ?? t.pos)), n = new Set(e.map((e) => e.path.join(","))).size === 1 ? e[0].path : [], a = n.length ? [
						s,
						...n.slice(0, -1).map($),
						c
					] : [];
					a.length ? i.push(r.animate(a.map(([e, n], r) => ({
						transform: `translate(${e}px, ${n}px)`,
						opacity: t.state === "home" && r === a.length - 1 ? 0 : 1
					})), {
						duration: Math.min(300, 180 + n.length * 30),
						easing: "cubic-bezier(.2,.65,.3,1)"
					})) : t.state !== "eaten" && i.push(r.animate([{ opacity: .35 }, { opacity: t.state === "home" ? 0 : 1 }], { duration: 200 }));
				} else (t.asleep !== e.asleep || t.direction !== e.direction || t.pollen !== e.pollen) && i.push(r.animate([{ opacity: .45 }, { opacity: 1 }], { duration: 180 }));
			}
		}
		return e.tiles.forEach((e, t) => {
			if (e !== null && n.tiles[t] === null) {
				let e = v.current.get(t);
				e && i.push(e.animate([{
					opacity: .35,
					transform: "translateY(-8px)"
				}, {
					opacity: 1,
					transform: "translateY(0)"
				}], {
					duration: 250,
					easing: "cubic-bezier(.2,.8,.3,1)"
				}));
			}
		}), () => i.forEach((e) => e.cancel());
	});
	let te = (e, t) => {
		(t === "Enter" || t === " ") && m(e);
	};
	return /* @__PURE__ */ x("svg", {
		className: "natz-board",
		viewBox: "-100 -110 700 730",
		role: "group",
		"aria-label": u,
		children: [
			/* @__PURE__ */ b("path", {
				d: "M-88-94Q240-107 588-91L589 599Q251 615-89 599Z",
				fill: "#211c36"
			}),
			/* @__PURE__ */ b("path", {
				d: "M-72-77H568V584H-72Z",
				fill: "#25203b"
			}),
			/* @__PURE__ */ x("g", {
				pointerEvents: "none",
				children: [Array.from({ length: 12 }, (e, t) => /* @__PURE__ */ x("g", { children: [/* @__PURE__ */ b("g", {
					transform: `translate(${-56 + t * 57} -17) rotate(${[
						-35,
						20,
						-15,
						35
					][t % 4]}) scale(.82)`,
					color: [
						"#3d3557",
						"#514063",
						"#394b55"
					][t % 3],
					children: /* @__PURE__ */ b(Xe, {})
				}), /* @__PURE__ */ b("g", {
					transform: `translate(${-58 + t * 57} 602) rotate(${[
						35,
						-20,
						15,
						-35
					][t % 4]}) scale(.9)`,
					color: [
						"#3a3452",
						"#4b3d60",
						"#3c4f54"
					][t % 3],
					children: /* @__PURE__ */ b(Xe, {})
				})] }, t)), Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ x("g", { children: [/* @__PURE__ */ b("g", {
					transform: `translate(-50 ${t * 61}) rotate(${65 + t % 3 * 15}) scale(.8)`,
					color: "#403657",
					children: /* @__PURE__ */ b(Xe, {})
				}), /* @__PURE__ */ b("g", {
					transform: `translate(550 ${t * 61}) rotate(${-70 - t % 3 * 8}) scale(.85)`,
					color: "#354c52",
					children: /* @__PURE__ */ b(Xe, {})
				})] }, t))]
			}),
			Array.from({ length: 25 }, (t, r) => {
				let [i, a] = N(r), f = e.tiles[r], p = ie[r], h = s.has(r), g = n === r;
				return /* @__PURE__ */ x("g", {
					transform: `translate(${i * 100} ${a * 100})`,
					role: "button",
					tabIndex: 0,
					"aria-disabled": !l || !h && !c,
					"aria-label": r === 12 ? u : d(r),
					onClick: () => m(r),
					onKeyDown: (e) => {
						e.key === " " && e.preventDefault(), te(r, e.key);
					},
					className: "natz-board-cell",
					children: [
						/* @__PURE__ */ b("g", {
							ref: (e) => {
								e ? v.current.set(r, e) : v.current.delete(r);
							},
							children: f === null ? /* @__PURE__ */ b(Je, {}) : /* @__PURE__ */ b($e, {
								id: f,
								foodOnly: !0
							})
						}),
						r === 12 ? /* @__PURE__ */ b(Ye, {}) : f === null && p && /* @__PURE__ */ x("g", {
							color: "#dfd6ed",
							children: [
								p.actions.map((e, t) => /* @__PURE__ */ b("g", {
									transform: `translate(${p.actions.length > 1 ? 29 + t * 42 : 50} 56) scale(.9)`,
									children: /* @__PURE__ */ b(Ze, { ...e })
								}, t)),
								p.terrain && /* @__PURE__ */ b("g", {
									transform: "translate(39 3) scale(.36)",
									children: /* @__PURE__ */ b(Qe, { terrain: p.terrain })
								}),
								p.discover && /* @__PURE__ */ b("g", {
									transform: "translate(50 16) scale(.42)",
									children: /* @__PURE__ */ b(Ze, { kind: "discover" })
								})
							]
						}),
						h && !g && /* @__PURE__ */ b("path", {
							d: "M12 25V13H24M76 13H88V25M12 76V88H24M88 76V88H76",
							fill: "none",
							stroke: "#e4d4b0",
							strokeWidth: "2.3",
							opacity: ".8"
						}),
						g && o !== null && /* @__PURE__ */ b("g", {
							opacity: ".76",
							children: /* @__PURE__ */ b($e, { id: o })
						}),
						g && /* @__PURE__ */ b("path", {
							d: "M8 4Q23 0 38 4T66 4Q84 0 94 7Q99 21 94 39Q98 53 95 67Q100 86 93 94Q77 99 62 95Q48 98 34 95Q16 99 6 92Q1 76 5 62Q1 46 5 34Q1 14 8 4Z",
							fill: "none",
							stroke: "#f7dda2",
							strokeWidth: "4"
						}),
						h && c && /* @__PURE__ */ b("circle", {
							cx: "50",
							cy: "80",
							r: "6",
							fill: "#f7dda2",
							stroke: "#3f3453",
							strokeWidth: "2"
						})
					]
				}, r);
			}),
			L.map((t, n) => {
				let [r, i] = t.cells.map($);
				return /* @__PURE__ */ x("g", {
					transform: `translate(${(r[0] + i[0]) / 2} ${(r[1] + i[1]) / 2})`,
					opacity: e.pairs[n] ? .3 : .95,
					color: "#e5d6ec",
					pointerEvents: "none",
					children: [
						/* @__PURE__ */ b("circle", {
							r: "18",
							fill: "#33283f",
							stroke: "#a996bc",
							strokeWidth: "1.8"
						}),
						/* @__PURE__ */ b("g", {
							transform: "scale(.65)",
							children: /* @__PURE__ */ b(Ze, { ...t.reward })
						}),
						e.pairs[n] && /* @__PURE__ */ b("path", {
							d: "m-7 0 5 5 10-10",
							fill: "none",
							stroke: "#fff5d3",
							strokeWidth: "3"
						})
					]
				}, n);
			}),
			P.map((e, t) => {
				let [n, r] = e.xy;
				return /* @__PURE__ */ x("g", {
					transform: `translate(${n * 100 + 8} ${r * 100 + 8})`,
					role: "button",
					tabIndex: 0,
					"aria-disabled": !l,
					"aria-label": f(t + 1),
					onClick: () => m(25 + t),
					onKeyDown: (e) => {
						e.key === " " && e.preventDefault(), te(25 + t, e.key);
					},
					className: "natz-board-cell",
					children: [/* @__PURE__ */ b("g", {
						transform: "scale(.84)",
						children: /* @__PURE__ */ b(Je, { terrain: e.terrain })
					}), /* @__PURE__ */ b("text", {
						x: "9",
						y: "17",
						fill: "#f9ecd1",
						fontSize: "13",
						fontWeight: "700",
						children: t + 1
					})]
				}, t);
			}),
			/* @__PURE__ */ b("g", {
				pointerEvents: "none",
				children: e.animals.map((e) => {
					let t = h.get(e.id), n = (g.get(e.pos)?.length ?? 0) > 1 ? 38 : 70, r = e.state === "hidden";
					return /* @__PURE__ */ b("g", {
						ref: (t) => {
							t ? ee.current.set(e.id, t) : ee.current.delete(e.id);
						},
						style: {
							transform: `translate(${t[0]}px, ${t[1]}px)`,
							opacity: e.state === "home" || e.state === "eaten" ? 0 : 1
						},
						role: "img",
						"aria-label": p(e),
						children: /* @__PURE__ */ x("g", {
							transform: `translate(${-n / 2} ${-n / 2})`,
							children: [
								r ? /* @__PURE__ */ b("path", {
									d: `M4 9Q${n / 2} -1 ${n - 4} 9V${n - 2}H4Z`,
									fill: "#2e2444",
									stroke: "#ad99bd",
									strokeWidth: "1.2"
								}) : /* @__PURE__ */ b("ellipse", {
									cx: n / 2,
									cy: n - 1,
									rx: n * .4,
									ry: n * .1,
									fill: "#17172b",
									opacity: ".65"
								}),
								a === e.id && c && /* @__PURE__ */ b("ellipse", {
									cx: n / 2,
									cy: n - 1,
									rx: n * .51,
									ry: n * .14,
									fill: "none",
									stroke: "#f7d691",
									strokeWidth: "3"
								}),
								/* @__PURE__ */ b("g", {
									opacity: r ? .72 : 1,
									transform: `scale(${n / 64})`,
									children: /* @__PURE__ */ b(Ke, { species: e.species })
								}),
								r && /* @__PURE__ */ x("g", { children: [/* @__PURE__ */ b("circle", {
									cx: n - 9,
									cy: n - 8,
									r: "10",
									fill: "#3d3156",
									stroke: "#a493b8"
								}), /* @__PURE__ */ b("text", {
									x: n - 9,
									y: n - 3,
									textAnchor: "middle",
									fill: "#f5e8d2",
									fontSize: "15",
									fontWeight: "800",
									children: "?"
								})] }),
								e.species === "snake" && !r && /* @__PURE__ */ x("g", {
									transform: `translate(${n - 6} 5) rotate(${e.direction * 90})`,
									children: [/* @__PURE__ */ b("circle", {
										r: "12",
										fill: "#30263f",
										stroke: "#d6c5ab"
									}), /* @__PURE__ */ b("path", {
										d: "M0 8V-7m-5 5 5-5 5 5",
										fill: "none",
										stroke: "#fff0c9",
										strokeWidth: "2.5"
									})]
								}),
								e.asleep && /* @__PURE__ */ x("g", { children: [/* @__PURE__ */ b("rect", {
									x: n - 15,
									y: "-6",
									width: "29",
									height: "19",
									rx: "7",
									fill: "#3b3155",
									stroke: "#b6a8c9"
								}), /* @__PURE__ */ b("text", {
									x: n - 1,
									y: "8",
									textAnchor: "middle",
									fill: "#fff0c9",
									fontSize: "13",
									fontWeight: "800",
									children: "zZ"
								})] }),
								e.species === "butterfly" && !r && /* @__PURE__ */ x("g", { children: [/* @__PURE__ */ b("rect", {
									x: n - 10,
									y: n - 17,
									width: "20",
									height: "20",
									rx: "7",
									fill: "#f8e6b4"
								}), /* @__PURE__ */ b("text", {
									x: n,
									y: n - 2,
									textAnchor: "middle",
									fill: "#332541",
									fontSize: "14",
									fontWeight: "800",
									children: e.pollen
								})] })
							]
						})
					}, e.id);
				})
			})
		]
	});
}
//#endregion
//#region src/games/nightatthezoo/view-player.tsx
var rt = {
	hidden: "games.nightatthezoo.hidden",
	board: "games.nightatthezoo.onBoard",
	home: "games.nightatthezoo.home",
	eaten: "games.nightatthezoo.eaten"
}, it = [
	"games.nightatthezoo.turnNorth",
	"games.nightatthezoo.turnEast",
	"games.nightatthezoo.turnSouth",
	"games.nightatthezoo.turnWest"
], at = [
	"games.nightatthezoo.straight",
	"games.nightatthezoo.jump",
	"games.nightatthezoo.bend"
], ot = [
	"games.nightatthezoo.rank0",
	"games.nightatthezoo.rank1",
	"games.nightatthezoo.rank2",
	"games.nightatthezoo.rank3",
	"games.nightatthezoo.rank4"
], st = [
	["immediate", "games.nightatthezoo.immediate"],
	["animals", "games.nightatthezoo.animalsScore"],
	["discovered", "games.nightatthezoo.discoveredScore"],
	["food", "games.nightatthezoo.foodScore"],
	["total", "games.nightatthezoo.total"]
], ct = {
	draft: "games.nightatthezoo.logDraft",
	place: "games.nightatthezoo.logPlace",
	store: "games.nightatthezoo.logStore",
	discard: "games.nightatthezoo.logDiscard",
	discover: "games.nightatthezoo.logDiscover",
	move: "games.nightatthezoo.logMove",
	home: "games.nightatthezoo.logHome",
	eaten: "games.nightatthezoo.logEaten",
	points: "games.nightatthezoo.logPoints",
	round: "games.nightatthezoo.logRound",
	leo: "games.nightatthezoo.logLeo"
};
function lt({ public: e, members: t, myRid: n, send: r }) {
	p();
	let i = s(), o = e, c = o.phase === "done", [l, ee] = a({
		owner: n,
		rid: n
	}), te = l.owner === n ? l.rid : n, S = o.players.find((e) => e.rid === te) ?? o.players[0], ne = S.rid === n, C = ne && !S.done && (o.phase === "place" || o.phase === "round"), w = o.phase === "draft" && o.current === n, E = z(S), A = o.scores[S.rid], [j, P] = a(-1), [F, I] = a(null), [ie, L] = a(null), [R, V] = a("info"), [se, H] = a(!1), [ce, le] = a(!1), [fe, pe] = a(""), U = `${n}:${S.rid}:${o.phase}:${o.draft}:${JSON.stringify(S.frames)}:${S.warehouse.join(",")}`;
	fe !== U && (pe(U), P(-1), I(null), L(null), H(!1));
	let W = (e) => e === "$leo" ? i("games.nightatthezoo.leo") : t.find((t) => t.rid === e)?.name ?? e, G = (e) => i(re[e.kind], { n: e.n }), me = (e) => {
		let t = M[e], n = t.food === null ? t.options.length ? t.options.map(G).join(" / ") : i("games.nightatthezoo.plainTile") : i(k[t.food]);
		return i("games.nightatthezoo.tileLabel", {
			terrain: i(O[t.terrain]),
			effect: n
		});
	}, he = (e) => {
		let [t, n] = N(e);
		return i("games.nightatthezoo.cell", {
			row: n + 1,
			col: t + 1
		});
	}, ge = (e) => i("games.nightatthezoo.animalLabel", {
		animal: i(D[e.species].name),
		n: e.id + 1,
		state: i(rt[e.state])
	}), K = C ? ue(S) : [], _e = K.some((e) => e.animal === ie) ? ie : K[0]?.animal ?? null, ve = K.filter((e) => e.animal === _e), ye = j === -1 ? E.held : S.warehouse[j] ?? null, be = C && o.phase === "place" && !E.movement && ye !== null, xe = new Set(be ? S.tiles.flatMap((e, t) => e === null && t !== 12 ? [t] : []) : ve.flatMap((e) => e.path.length ? [e.path[e.path.length - 1]] : [])), Se = be && F !== null && xe.has(F), q = (e) => {
		H(!1), I(null), r(e);
	}, J = (e) => {
		V(e), H(!0);
	}, Y = (e) => {
		if (C) {
			if (E.movement) {
				let t = ve.filter((t) => t.path.at(-1) === e);
				if (t.length === 1) {
					q({
						type: "move",
						move: t[0]
					});
					return;
				}
				if (t.length > 1) {
					I(e), J("moves");
					return;
				}
				let n = S.animals.find((t) => B(t).includes(e) && K.some((e) => e.animal === t.id));
				n && (L(n.id), I(null));
			} else if (E.discover) {
				let t = S.animals.find((t) => t.entrance === e && t.state === "hidden");
				t && q({
					type: "discover",
					animal: t.id
				});
			} else be && xe.has(e) && I(e);
		}
	}, X = (e) => e.direction === void 0 ? e.path.length ? e.path.map((e) => e === 12 ? i("games.nightatthezoo.zoo") : he(e)).join(" → ") : i("games.nightatthezoo.wakeUp") : i(it[e.direction]), Z = (e) => i(ct[e.kind], {
		name: W(e.rid),
		animal: e.animal ? i(D[e.animal].name) : "",
		n: e.n ?? 0,
		terrain: e.terrain ? i(O[e.terrain]) : e.tile === void 0 ? "" : i(O[M[e.tile].terrain])
	}), Ce = c ? i("games.nightatthezoo.finalBoard") : o.phase === "draft" ? w ? i("games.nightatthezoo.draftPrompt") : i("games.nightatthezoo.waiting", { name: W(o.current) }) : o.players.find((e) => e.rid === n)?.done ? i("games.nightatthezoo.finished") : o.phase === "round" && o.roundTerrain ? i("games.nightatthezoo.roundPrompt", { terrain: i(O[o.roundTerrain]) }) : i("games.nightatthezoo.placePrompt"), Te = C ? E.movement ? i("games.nightatthezoo.chooseAnimal") : E.held === null ? E.discover ? i("games.nightatthezoo.chooseDiscover") : E.bonus ? i("games.nightatthezoo.chooseBonus") : E.actions.length ? i("games.nightatthezoo.chooseAction") : i("games.nightatthezoo.finish") : i("games.nightatthezoo.selectTile") : Ce, Ee = () => {
		Se && F !== null ? q({
			type: "place",
			source: j,
			cell: F
		}) : E.movement ? J("moves") : E.discover ? J("discover") : E.held === null && E.bonus ? J("bonus") : E.actions.length ? J("actions") : Q(S) && q({ type: "finish" });
	}, De = Se ? i("games.nightatthezoo.confirmPlace") : E.movement ? i("games.nightatthezoo.chooseDestination") : E.discover ? i("games.nightatthezoo.chooseDiscover") : E.held === null && E.bonus ? i("games.nightatthezoo.chooseBonus") : E.actions.length ? i("games.nightatthezoo.chooseAction") : i("games.nightatthezoo.finish"), Oe = C && (Se || !!E.movement || !!E.discover || E.held === null && (!!E.bonus || !!E.actions.length) || Q(S)), ke = (e, t, n = !1) => /* @__PURE__ */ x("button", {
		type: "button",
		className: "natz-animal-button",
		"aria-label": ge(e),
		"aria-pressed": n,
		onClick: t,
		children: [
			/* @__PURE__ */ b("svg", {
				viewBox: "0 0 64 64",
				"aria-hidden": "true",
				children: /* @__PURE__ */ b(Ke, { species: e.species })
			}),
			/* @__PURE__ */ x("span", { children: [
				i(D[e.species].name),
				" ",
				e.id + 1
			] }),
			e.asleep && /* @__PURE__ */ b("small", { children: i("games.nightatthezoo.asleep") }),
			e.species === "butterfly" && /* @__PURE__ */ b("small", { children: i("games.nightatthezoo.pollen", { n: e.pollen }) })
		]
	}, e.id), Ae = /* @__PURE__ */ b(y, { children: o.species.map((e) => /* @__PURE__ */ x("article", {
		className: "natz-ability",
		children: [/* @__PURE__ */ b("svg", {
			viewBox: "0 0 64 64",
			"aria-hidden": "true",
			children: /* @__PURE__ */ b(Ke, { species: e })
		}), /* @__PURE__ */ x("div", { children: [
			/* @__PURE__ */ x("h3", { children: [
				i(D[e].name),
				" ",
				/* @__PURE__ */ b("small", { children: "☾".repeat(D[e].moons) })
			] }),
			/* @__PURE__ */ b("p", { children: i(D[e].rule) }),
			e === "monkey" && /* @__PURE__ */ b("div", {
				className: "natz-tokens",
				children: S.tokens.map((e, t) => /* @__PURE__ */ x("span", {
					"data-available": e,
					children: [i(at[t]), /* @__PURE__ */ b("b", { children: e ? "✓" : "×" })]
				}, t))
			})
		] })]
	}, e)) }), je = i(R === "info" ? "games.nightatthezoo.inspect" : R === "bonus" ? "games.nightatthezoo.chooseBonus" : R === "discover" ? "games.nightatthezoo.chooseDiscover" : R === "moves" ? "games.nightatthezoo.chooseDestination" : "games.nightatthezoo.chooseAction");
	return /* @__PURE__ */ x(h, {
		adaptive: !0,
		scroll: !1,
		className: "natz-screen",
		banner: /* @__PURE__ */ x("div", {
			className: "natz-banner",
			children: [/* @__PURE__ */ b(g, {
				tone: w || C ? "accent" : "info",
				accent: oe.accent,
				text: Ce,
				chip: c ? i("session.result.title") : i("games.nightatthezoo.roundDraft", {
					round: Math.ceil(o.draft / 5),
					draft: (o.draft - 1) % 5 + 1
				})
			}), /* @__PURE__ */ b(_, {
				members: t,
				myRid: n,
				variant: "mini",
				adaptive: !0,
				scroll: !0,
				onPick: (e) => ee({
					owner: n,
					rid: e
				}),
				picked: (e) => e === S.rid,
				status: (e) => /* @__PURE__ */ b("span", { children: i("games.nightatthezoo.points", { n: o.scores[e]?.total ?? 0 }) }),
				action: (e) => c ? null : o.phase === "draft" ? e === o.current ? "pending" : null : o.players.find((t) => t.rid === e)?.done ? "done" : "pending"
			})]
		}),
		actionsHeight: "natz-action-height",
		actions: /* @__PURE__ */ x("div", {
			className: `natz-actions${c ? " natz-actions-final" : ""}`,
			children: [/* @__PURE__ */ b("div", {
				className: "natz-action-prompt",
				role: "status",
				children: Te
			}), c ? /* @__PURE__ */ x("button", {
				className: "btn-quiet natz-review-info",
				onClick: () => J("info"),
				children: [/* @__PURE__ */ b(u, { size: 20 }), i("games.nightatthezoo.inspect")]
			}) : /* @__PURE__ */ x("div", {
				className: "natz-controls",
				children: [E.movement ? /* @__PURE__ */ b("div", {
					className: "natz-movers",
					children: S.animals.filter((e) => K.some((t) => t.animal === e.id)).map((e) => ke(e, () => {
						L(e.id), I(null);
					}, e.id === _e))
				}) : /* @__PURE__ */ x("div", {
					className: "natz-held",
					children: [/* @__PURE__ */ b("button", {
						type: "button",
						className: "natz-tile natz-held-tile",
						"aria-label": E.held === null ? i("games.nightatthezoo.noTile") : me(E.held),
						"aria-pressed": j === -1,
						disabled: !C || E.held === null,
						onClick: () => {
							P(-1), I(null);
						},
						children: E.held === null ? /* @__PURE__ */ b("span", { children: "·" }) : /* @__PURE__ */ b(et, { id: E.held })
					}, E.held ?? "empty"), /* @__PURE__ */ x("div", {
						className: "natz-small-actions",
						children: [/* @__PURE__ */ b("button", {
							className: "btn-quiet",
							disabled: !C || E.held === null || S.warehouse.length >= 2,
							onClick: () => q({ type: "store" }),
							children: i("games.nightatthezoo.store")
						}), /* @__PURE__ */ b("button", {
							className: "btn-quiet",
							disabled: !C || ye === null || !we(S) || o.phase === "round",
							onClick: () => q({
								type: "discard",
								source: j
							}),
							children: i("games.nightatthezoo.discard")
						})]
					})]
				}), /* @__PURE__ */ x("div", {
					className: "natz-primary-actions",
					children: [/* @__PURE__ */ b("button", {
						className: "btn-base natz-primary",
						disabled: !Oe,
						onClick: Ee,
						children: De
					}), E.movement ? /* @__PURE__ */ b("button", {
						className: "btn-quiet",
						disabled: !C,
						onClick: () => q({ type: "passMovement" }),
						children: i("games.nightatthezoo.passMovement")
					}) : Se && Q(S) && /* @__PURE__ */ b("button", {
						className: "btn-quiet",
						disabled: !C,
						onClick: () => q({ type: "finish" }),
						children: i("games.nightatthezoo.finish")
					})]
				})]
			})]
		}),
		children: [/* @__PURE__ */ x("div", {
			className: "natz-stage",
			children: [
				/* @__PURE__ */ b(m, {
					kind: "sheen",
					base: "#1c1830",
					className: "natz-texture"
				}),
				/* @__PURE__ */ x("div", {
					className: "natz-table",
					children: [
						/* @__PURE__ */ x("aside", {
							className: "natz-market-area",
							children: [
								/* @__PURE__ */ x("div", {
									className: "natz-area-heading",
									children: [/* @__PURE__ */ b("h2", { children: i("games.nightatthezoo.market") }), !c && /* @__PURE__ */ b("span", { children: i("games.nightatthezoo.nextFirst", { name: W(o.first) }) })]
								}),
								/* @__PURE__ */ b("div", {
									className: "natz-market",
									children: o.market.map((e, t) => /* @__PURE__ */ b("button", {
										type: "button",
										className: "natz-tile natz-market-tile",
										"aria-label": e === null ? i("games.nightatthezoo.empty") : me(e),
										disabled: !w || e === null,
										onClick: () => q({
											type: "draft",
											index: t
										}),
										children: e === null ? /* @__PURE__ */ b("span", { children: t + 1 }) : /* @__PURE__ */ b(et, { id: e })
									}, t))
								}),
								/* @__PURE__ */ x("div", {
									className: "natz-leftovers",
									children: [/* @__PURE__ */ b("h3", { children: i("games.nightatthezoo.leftovers") }), /* @__PURE__ */ b("div", { children: Array.from({ length: 5 }, (e, t) => /* @__PURE__ */ b("div", {
										className: "natz-tile",
										children: o.leftovers[t] !== void 0 && /* @__PURE__ */ b(et, { id: o.leftovers[t] })
									}, t)) })]
								}),
								o.soloCard !== null && /* @__PURE__ */ x("p", {
									className: "natz-leo",
									children: [i("games.nightatthezoo.leoPriority", {
										a: ae[o.soloCard].priority[0] + 1,
										b: ae[o.soloCard].priority[1] + 1
									}), ae[o.soloCard].shuffle && /* @__PURE__ */ b("span", {
										"aria-hidden": !0,
										children: " ↻"
									})]
								}),
								/* @__PURE__ */ x("div", {
									className: "natz-supply natz-public-supply",
									children: [/* @__PURE__ */ b("h3", { children: i("games.nightatthezoo.supply") }), T.map((e) => /* @__PURE__ */ x("span", { children: [
										/* @__PURE__ */ b("svg", {
											viewBox: "0 0 60 60",
											"aria-hidden": "true",
											children: /* @__PURE__ */ b(Qe, { terrain: e })
										}),
										i(O[e]),
										/* @__PURE__ */ b("b", { children: o.supply[e] })
									] }, e))]
								})
							]
						}),
						/* @__PURE__ */ x("section", {
							className: "natz-personal",
							children: [
								/* @__PURE__ */ x("div", {
									className: "natz-area-heading natz-board-heading",
									children: [/* @__PURE__ */ b("h2", { children: ne ? i("games.nightatthezoo.yourBoard") : i("games.nightatthezoo.boardOf", { name: W(S.rid) }) }), /* @__PURE__ */ x("div", { children: [
										/* @__PURE__ */ b("span", { children: i("games.nightatthezoo.homeCount", { n: A.home }) }),
										/* @__PURE__ */ b("button", {
											className: "btn-quiet",
											"aria-label": i("games.nightatthezoo.inspect"),
											onClick: () => J("info"),
											children: /* @__PURE__ */ b(u, { size: 21 })
										}),
										/* @__PURE__ */ b("button", {
											className: "btn-quiet",
											"aria-label": i("common.log.title"),
											onClick: () => le(!0),
											children: /* @__PURE__ */ b(d, { size: 20 })
										})
									] })]
								}),
								/* @__PURE__ */ b("div", {
									className: "natz-board-area",
									children: /* @__PURE__ */ b(nt, {
										player: S,
										serial: o.serial,
										selectedCell: F,
										selectedAnimal: _e,
										selectedTile: be ? ye : null,
										legalCells: xe,
										moving: C && !!E.movement,
										interactive: C,
										label: i("games.nightatthezoo.zoo"),
										cellLabel: he,
										entranceLabel: (e) => i("games.nightatthezoo.entrance", { n: e }),
										animalLabel: ge,
										onCell: Y
									})
								}),
								/* @__PURE__ */ x("div", {
									className: "natz-warehouse",
									children: [
										/* @__PURE__ */ b("h3", { children: i("games.nightatthezoo.warehouse") }),
										Array.from({ length: 2 }, (e, t) => /* @__PURE__ */ b("button", {
											type: "button",
											className: "natz-tile",
											"aria-label": S.warehouse[t] === void 0 ? i("games.nightatthezoo.empty") : me(S.warehouse[t]),
											"aria-pressed": j === t,
											disabled: !C || !we(S) || S.warehouse[t] === void 0 || o.phase === "round",
											onClick: () => {
												P(t), I(null);
											},
											children: S.warehouse[t] !== void 0 && /* @__PURE__ */ b(et, { id: S.warehouse[t] })
										}, t)),
										/* @__PURE__ */ b("div", {
											className: "natz-foods",
											children: A.foods.map((e) => /* @__PURE__ */ b("svg", {
												viewBox: "0 0 60 60",
												role: "img",
												"aria-label": i(k[e]),
												children: /* @__PURE__ */ b(qe, { food: e })
											}, e))
										}),
										/* @__PURE__ */ b("strong", {
											className: "natz-score-number",
											children: i("games.nightatthezoo.points", { n: A.total })
										}, A.total)
									]
								})
							]
						}),
						/* @__PURE__ */ x("aside", {
							className: "natz-abilities",
							children: [
								/* @__PURE__ */ b("h2", { children: i("games.nightatthezoo.animalRules") }),
								Ae,
								/* @__PURE__ */ x("div", {
									className: "natz-home",
									children: [/* @__PURE__ */ b("h3", { children: i("games.nightatthezoo.homeCount", { n: A.home }) }), /* @__PURE__ */ b("div", { children: S.animals.filter((e) => e.state === "home").map((e) => /* @__PURE__ */ b("svg", {
										viewBox: "0 0 64 64",
										role: "img",
										"aria-label": ge(e),
										children: /* @__PURE__ */ b(Ke, { species: e.species })
									}, e.id)) })]
								})
							]
						})
					]
				}),
				ce && /* @__PURE__ */ b("div", {
					className: "natz-log",
					children: /* @__PURE__ */ b(v, {
						log: o.log,
						line: Z,
						onClose: () => le(!1)
					})
				})
			]
		}), /* @__PURE__ */ b(f, {
			open: se,
			onClose: () => H(!1),
			label: je,
			title: je,
			children: /* @__PURE__ */ x("div", {
				className: "natz-sheet",
				children: [
					R === "info" && /* @__PURE__ */ x(y, { children: [
						Ae,
						/* @__PURE__ */ x("div", {
							className: "natz-supply",
							children: [/* @__PURE__ */ b("h3", { children: i("games.nightatthezoo.supply") }), T.map((e) => /* @__PURE__ */ x("span", { children: [
								/* @__PURE__ */ b("svg", {
									viewBox: "0 0 60 60",
									"aria-hidden": "true",
									children: /* @__PURE__ */ b(Qe, { terrain: e })
								}),
								i(O[e]),
								/* @__PURE__ */ b("b", { children: o.supply[e] })
							] }, e))]
						}),
						/* @__PURE__ */ b("div", {
							className: "natz-score",
							children: st.map(([e, t]) => /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("span", { children: i(t) }), /* @__PURE__ */ b("strong", { children: A[e] })] }, e))
						}),
						o.players.length === 1 && /* @__PURE__ */ x("p", {
							className: "natz-solo-rating",
							children: [
								i("games.nightatthezoo.solo"),
								" · ",
								i(ot[ze(A.total)])
							]
						}),
						/* @__PURE__ */ b("div", {
							className: "natz-animal-list",
							children: S.animals.map((e) => /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("svg", {
								viewBox: "0 0 64 64",
								"aria-hidden": "true",
								children: /* @__PURE__ */ b(Ke, { species: e.species })
							}), /* @__PURE__ */ b("span", { children: ge(e) })] }, e.id))
						})
					] }),
					R === "actions" && E.actions.map((e, t) => /* @__PURE__ */ x("div", {
						className: "natz-effect-choice",
						children: [e.map((e, n) => /* @__PURE__ */ x("button", {
							className: "btn-base natz-choice",
							disabled: !C,
							onClick: () => q({
								type: "resolve",
								index: t,
								choice: n
							}),
							children: [/* @__PURE__ */ b("svg", {
								viewBox: "-24 -24 48 48",
								"aria-hidden": "true",
								children: /* @__PURE__ */ b(Ze, { ...e })
							}), G(e)]
						}, n)), /* @__PURE__ */ b("button", {
							className: "btn-quiet",
							disabled: !C,
							onClick: () => q({
								type: "passEffect",
								index: t
							}),
							children: i("games.nightatthezoo.passEffect")
						})]
					}, t)),
					R === "bonus" && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("div", {
						className: "natz-bonus-choices",
						children: T.map((e, t) => /* @__PURE__ */ x("button", {
							className: "natz-choice natz-bonus",
							disabled: !C || !o.supply[e],
							onClick: () => q({
								type: "bonus",
								terrain: e
							}),
							children: [/* @__PURE__ */ b(et, { id: 75 + t }), /* @__PURE__ */ x("span", { children: [
								i(O[e]),
								" · ",
								o.supply[e]
							] })]
						}, e))
					}), /* @__PURE__ */ b("button", {
						className: "btn-quiet",
						disabled: !C,
						onClick: () => q({ type: "decline" }),
						children: i("games.nightatthezoo.decline")
					})] }),
					R === "discover" && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("div", {
						className: "natz-discover-choices",
						children: S.animals.filter((e) => e.state === "hidden").map((e) => ke(e, () => q({
							type: "discover",
							animal: e.id
						})))
					}), /* @__PURE__ */ b("button", {
						className: "btn-quiet",
						disabled: !C,
						onClick: () => q({ type: "decline" }),
						children: i("games.nightatthezoo.passEffect")
					})] }),
					R === "moves" && /* @__PURE__ */ b("div", {
						className: "natz-move-choices",
						children: ve.filter((e) => F === null || e.path.at(-1) === F).map((e) => /* @__PURE__ */ x("button", {
							className: "natz-choice natz-move-choice",
							disabled: !C,
							onClick: () => q({
								type: "move",
								move: e
							}),
							children: [/* @__PURE__ */ b("strong", { children: e.token === void 0 ? i(D[S.animals[e.animal].species].name) : i(at[e.token]) }), /* @__PURE__ */ b("span", { children: X(e) })]
						}, de(e)))
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/games/nightatthezoo/bot.ts
var ut = {
	beam: 5,
	depth: 7,
	placements: 7,
	nodes: 560,
	missingCost: 1.8,
	decay: .18,
	lateDecay: .22,
	hidden: .15,
	pendingMove: .85,
	pendingBonus: 1.7,
	warehouse: 1.2
};
function dt(e, t) {
	return JSON.stringify([
		e.phase,
		e.draft,
		e.supply,
		t
	]);
}
function ft(e, t) {
	let n = {
		...t,
		rid: t.rid + ":idle",
		done: !1
	};
	return {
		...e,
		players: [t, n],
		log: [],
		seed: 0,
		cursor: 0,
		deck: [],
		soloDeck: [],
		current: "",
		phase: e.phase === "draft" ? "place" : e.phase
	};
}
function pt(e, t) {
	let n = Be.reduce(e, t, { by: e.players[0].rid });
	if ("code" in n) throw Error(`Night at the Zoo bot generated an illegal action: ${JSON.stringify(t)}`);
	return n.state.log = [], n.state;
}
function mt(e, t, n) {
	let r = t === "snake", i = r ? 136 : 34, a = Array.from({ length: i }, () => []), o = new Set(t === "crocodile" ? [] : e.animals.filter((e) => e.species === "crocodile").flatMap(B)), s = (t) => t !== 12 && e.tiles[t] === null ? n.missingCost : 0, c = (e, t, n) => a[t].push({
		from: e,
		cost: n
	});
	for (let n = 0; n < 34; n++) if (n !== 12) for (let i = 0; i < 4; i++) {
		let a = I(n, i);
		if (r) for (let e = 0; e < 4; e++) e !== i && c(n * 4 + e, n * 4 + i, 1);
		if (!(a === null || o.has(a))) {
			if (r) c(n * 4 + i, a * 4 + i, 1 + s(a));
			else if (t === "penguin") {
				let t = a, r = 0;
				for (; t !== null && !o.has(t);) {
					r += s(t);
					let a = t === 12 ? null : I(t, i);
					if ((t === 12 || a === null || e.tiles[a] === null) && c(n, t, 1 + r), t === 12) break;
					t = a;
				}
			} else c(n, a, (t === "turtle" || t === "sloth") && a !== 12 ? 2 + s(a) : 1 + s(a));
		}
	}
	let l = Array(i).fill(100), u = new Uint8Array(i);
	for (let e = 0; e < (r ? 4 : 1); e++) l[r ? 48 + e : 12] = 0;
	for (let e = 0; e < i; e++) {
		let e = -1;
		for (let t = 0; t < i; t++) !u[t] && (e < 0 || l[t] < l[e]) && (e = t);
		if (e < 0 || l[e] >= 100) break;
		u[e] = 1;
		for (let t of a[e]) l[t.from] = Math.min(l[t.from], l[e] + t.cost);
	}
	return l;
}
function ht(e) {
	let t = /* @__PURE__ */ new Map();
	return (n) => {
		let r = n.tiles.map((e) => e === null ? "0" : "1").join("") + ":" + n.animals.filter((e) => e.species === "crocodile").flatMap(B).join(",");
		return (i) => {
			let a = r + ":" + i.species, o = t.get(a);
			o || (o = mt(n, i.species, e), t.set(a, o));
			let s = o[i.species === "snake" ? i.pos * 4 + i.direction : i.pos];
			return i.species === "turtle" && i.edge !== null && (s = 1 + Math.min(o[i.pos], o[i.edge])), i.species === "sloth" && i.asleep && (s += 1), i.species === "meerkat" && n.animals.some((e) => e.id !== i.id && B(e).some((e) => {
				let [t, n] = N(e), [r, a] = N(i.pos);
				return r === t || a === n;
			})) && (s *= .7), s;
		};
	};
}
function gt(e, t) {
	return t.species === "wolf" ? 7 + 2 * e.animals.filter((e) => e.species === "wolf" && e.state === "home").length : t.species === "turtle" ? 8 + e.animals.filter((e) => e.state === "home").length : t.species === "butterfly" ? [
		0,
		5,
		7,
		9,
		11
	][t.pollen] : D[t.species].points;
}
function _t(e, t, n) {
	return t.kind === "points" ? t.n : t.kind === "discover" ? e.animals.some((e) => e.state === "hidden") ? 1.6 : 0 : t.kind === "bonus" ? n.pendingBonus * t.n : e.animals.some((e) => e.state === "board") ? n.pendingMove * t.n : 0;
}
function vt(e, t) {
	let n = ht(t), r = (16 - e.draft) / 15, i = t.decay + t.lateDecay * (1 - r), a = e.roundTerrain;
	if (e.draft % 5 == 0 && e.leftovers.length) {
		let t = (t) => e.leftovers.filter((e) => M[e].terrain === t).length;
		a = M[[...e.leftovers].sort((e, n) => t(M[n].terrain) - t(M[e].terrain))[0]].terrain;
	}
	return (e) => {
		let o = e.players[0], s = Re(o), c = n(o), l = s.total;
		for (let e of o.animals) {
			if (e.state !== "board" && e.state !== "hidden") continue;
			let n = gt(o, e) - 1;
			e.species === "butterfly" && (n = Math.max(n, 4 * r) + e.pollen * .25);
			let s = c(e);
			l += Math.max(0, n) * Math.exp(-i * s) * (e.state === "hidden" ? t.hidden : 1), e.state === "board" && e.species === "butterfly" && (l += e.pollen * .45), a && e.state === "board" && B(e).some((e) => (e >= 25 ? P[e - 25].terrain : o.tiles[e] === null ? null : M[o.tiles[e]].terrain) === a) && (l += .12);
		}
		l += s.foods.length * .9 * r;
		for (let e of o.warehouse) l += t.warehouse * r + (M[e].food !== null && !s.foods.includes(M[e].food) ? .6 * r : 0);
		for (let e of o.frames) {
			e.held !== null && (l += .65 * r), l += e.bonus * t.pendingBonus + (e.discover && o.animals.some((e) => e.state === "hidden") ? 1.6 : 0);
			for (let n of e.actions) l += Math.max(...n.map((e) => _t(o, e, t)));
			if (e.movement) {
				let n = o.animals.filter((t) => t.state === "board" && (e.movement.mode === "normal" || e.movement.eligible.includes(t.id)));
				l += (e.movement.mode === "normal" ? Math.min(n.length ? e.movement.left : 0, 2) : n.length) * t.pendingMove * .55;
			}
		}
		return l;
	};
}
function yt(e, t, n, r) {
	let i = M[t], a = ie[n], o = 0;
	a && (!a.terrain || a.terrain === i.terrain) && (!a.discover || i.options.some((e) => e.kind === "discover")) && (o += a.actions.reduce((t, n) => t + _t(e, n, r), 0));
	for (let t = 0; t < L.length; t++) {
		let a = L[t];
		if (!e.pairs[t] && a.cells.includes(n)) {
			let t = e.tiles[a.cells.find((e) => e !== n)];
			o += t !== null && M[t].terrain === i.terrain ? _t(e, a.reward, r) : .25;
		}
	}
	let [s, c] = N(n), l = Math.abs(s - 2) + Math.abs(c - 2);
	for (let t of e.animals) if (t.state === "board") {
		let [e, n] = N(t.edge ?? t.pos);
		Math.abs(e - s) + Math.abs(n - c) === 1 && (o += 1.8 + (l < Math.abs(e - 2) + Math.abs(n - 2) ? 1.4 : 0));
	}
	return o - l * .08;
}
function bt(e, t) {
	let n = e.players[0], r = z(n);
	if (n.done) return [];
	if (r.movement) return [...ue(n).map((e) => ({
		type: "move",
		move: e
	})), { type: "passMovement" }];
	if (e.phase === "round") return Q(n) ? [{ type: "finish" }] : [];
	let i = [], a = [...r.held === null ? [] : [-1], ...n.warehouse.map((e, t) => t)];
	for (let e of a) {
		let a = e === -1 ? r.held : n.warehouse[e], o = n.tiles.flatMap((e, r) => e === null && r !== 12 ? [{
			cell: r,
			value: yt(n, a, r, t)
		}] : []).sort((e, t) => t.value - e.value);
		for (let { cell: n } of o.slice(0, t.placements)) i.push({
			type: "place",
			source: e,
			cell: n
		});
		i.push({
			type: "discard",
			source: e
		});
	}
	if (r.held !== null && n.warehouse.length < 2 && i.push({ type: "store" }), r.held === null) {
		if (r.discover) for (let e of n.animals) e.state === "hidden" && i.push({
			type: "discover",
			animal: e.id
		});
		if (r.bonus) for (let t of T) e.supply[t] && i.push({
			type: "bonus",
			terrain: t
		});
		if (r.discover || r.bonus) i.push({ type: "decline" });
		else for (let e = 0; e < r.actions.length; e++) {
			for (let t = 0; t < r.actions[e].length; t++) i.push({
				type: "resolve",
				index: e,
				choice: t
			});
			i.push({
				type: "passEffect",
				index: e
			});
		}
		Q(n) && i.push({ type: "finish" });
	}
	return i;
}
function xt(e, t, n, r) {
	let i = [{
		state: e,
		actions: [],
		value: n(e)
	}], a, o, s = 0;
	for (let e = 0; e < t.depth && i.length && s < t.nodes && !r?.aborted; e++) {
		let r = [], c = /* @__PURE__ */ new Set();
		for (let o of i) for (let i of bt(o.state, t)) {
			if (s++ >= t.nodes) break;
			let l = pt(o.state, i), u = dt(l, l.players[0]);
			if (c.has(u)) continue;
			c.add(u);
			let d = {
				state: l,
				actions: [...o.actions, i],
				value: n(l) - (e + 1) * .015
			};
			l.players[0].done ? (!a || d.value > a.value) && (a = d) : r.push(d);
		}
		i = r.sort((e, t) => t.value - e.value).slice(0, t.beam), o = i[0];
	}
	let c = !o || a && a.value >= o.value ? a : o;
	if (!c) throw Error("Night at the Zoo bot has no legal plan");
	return c;
}
function St(e = {}) {
	let t = {
		...ut,
		...e
	};
	return ({ public: e }, n) => {
		let r = e.players.find((e) => e.rid === n.rid);
		if (!r || r.done || e.phase === "done" || e.phase === "draft" && e.current !== n.rid || n.signal?.aborted) return null;
		let i = n.difficulty === "weak" ? {
			...t,
			beam: 1,
			depth: 2,
			nodes: 100,
			placements: 4
		} : t, a = n.memory;
		if (e.phase !== "draft" && a?.key === dt(e, r) && a.actions.length) {
			let t = pt(ft(e, r), a.actions[0]);
			return {
				action: a.actions[0],
				memory: {
					key: dt(t, t.players[0]),
					actions: a.actions.slice(1)
				}
			};
		}
		let o = vt(e, i);
		if (e.phase === "draft") {
			let t = -Infinity, a = 0;
			for (let s = 0; s < e.market.length; s++) if (e.market[s] !== null) {
				let c = structuredClone(r);
				c.frames = [Y()], z(c).held = e.market[s];
				let l = xt(ft(e, c), {
					...i,
					depth: Math.min(i.depth, 4),
					nodes: Math.floor(i.nodes / 2)
				}, o, n.signal), u = M[e.market[s]].food, d = Re(r).foods, f = u !== null && !d.includes(u) ? .3 * (A[Math.min(7, d.length + 2)] - A[d.length + 1]) * (16 - e.draft) / 15 : 0;
				l.value + f > t && (t = l.value + f, a = s);
			}
			return { action: {
				type: "draft",
				index: a
			} };
		}
		let s = xt(ft(e, r), i, o, n.signal), c = pt(ft(e, r), s.actions[0]);
		return {
			action: s.actions[0],
			memory: {
				key: dt(c, c.players[0]),
				actions: s.actions.slice(1)
			}
		};
	};
}
var Ct = St(), wt = [
	["immediate", "games.nightatthezoo.immediate"],
	["animals", "games.nightatthezoo.animalsScore"],
	["discovered", "games.nightatthezoo.discoveredScore"],
	["food", "games.nightatthezoo.foodScore"],
	["total", "games.nightatthezoo.total"],
	["home", "games.nightatthezoo.homeNumber"]
], Tt = [
	"games.nightatthezoo.rank0",
	"games.nightatthezoo.rank1",
	"games.nightatthezoo.rank2",
	"games.nightatthezoo.rank3",
	"games.nightatthezoo.rank4"
], Et = () => {};
function Dt(e) {
	let { result: t, members: r, myRid: u, onPlayAgain: d, onBackToLobby: f, hintCount: p } = e, m = e.public, h = s(), g = o((e) => e.locale), [_, v] = a(!0), [y, C] = a(null), w = i(null), T = i(null), E = i(null);
	n(() => {
		w.current?.focus({ preventScroll: !0 });
	}, []), n(() => {
		if (!y) return;
		let e = setTimeout(() => C(null), 5e3);
		return () => clearTimeout(e);
	}, [y]);
	let D = (e) => {
		C(null), v(e), requestAnimationFrame(() => (e ? w : T).current?.focus({ preventScroll: !0 }));
	}, O = (e) => r.find((t) => t.rid === e), k = (e) => {
		let t = O(e);
		return t ? ee(t, g) : e;
	}, A = t.winner.map(k).join(g === "zh" ? "、" : ", "), re = t.ranking.length === 1, j = (e) => {
		y === e ? (C(null), (e === "again" ? d : f)?.()) : C(e);
	};
	return /* @__PURE__ */ x("div", {
		className: "natz-endgame",
		children: [
			/* @__PURE__ */ b("div", {
				className: "natz-final-board",
				inert: _,
				children: /* @__PURE__ */ b(lt, {
					public: m,
					members: r,
					myRid: u,
					send: Et
				})
			}),
			/* @__PURE__ */ b(ne, {}),
			/* @__PURE__ */ b("div", {
				className: "natz-result-overlay",
				hidden: !_,
				children: /* @__PURE__ */ x("section", {
					className: "natz-result-panel",
					ref: E,
					role: "dialog",
					"aria-modal": "true",
					"aria-label": h("session.result.title"),
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), D(!1)), e.key === "Tab") {
							let t = E.current?.querySelectorAll("button:not(:disabled)"), n = t?.[0], r = t?.[t.length - 1];
							e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
						}
					},
					children: [
						/* @__PURE__ */ x("header", {
							className: "natz-result-heading",
							children: [/* @__PURE__ */ b("span", { children: h("games.nightatthezoo.name") }), /* @__PURE__ */ b("button", {
								type: "button",
								ref: w,
								"aria-label": h("games.nightatthezoo.reviewBoard"),
								title: h("games.nightatthezoo.reviewBoard"),
								onClick: () => D(!1),
								children: /* @__PURE__ */ b(l, { size: 21 })
							})]
						}),
						/* @__PURE__ */ x("div", {
							className: "natz-result-scroll",
							children: [
								/* @__PURE__ */ x("div", {
									className: "natz-result-hero",
									children: [
										/* @__PURE__ */ b("svg", {
											viewBox: "0 0 100 100",
											"aria-hidden": "true",
											children: /* @__PURE__ */ b(Ye, {})
										}),
										/* @__PURE__ */ b("h1", { children: h("games.nightatthezoo.resultTitle") }),
										/* @__PURE__ */ b("p", { children: re ? h(Tt[ze(m.scores[t.ranking[0]].total)]) : t.winner.length > 1 ? h("games.nightatthezoo.sharedVictory", { names: A }) : h("games.nightatthezoo.winner", { name: A }) })
									]
								}),
								/* @__PURE__ */ x("table", {
									className: "natz-result-table",
									children: [/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
										scope: "col",
										children: /* @__PURE__ */ b("span", {
											className: "sr-only",
											children: h("games.nightatthezoo.score")
										})
									}), t.ranking.map((e) => {
										let n = O(e), r = t.winner.includes(e);
										return /* @__PURE__ */ x("th", {
											scope: "col",
											"data-winner": r,
											children: [
												/* @__PURE__ */ x("span", {
													className: "natz-result-avatar",
													style: { background: S[(n?.colorIndex ?? 0) % S.length].hex },
													children: [n && /* @__PURE__ */ b("img", {
														src: te[n.avatar % te.length],
														alt: ""
													}), r && !re && /* @__PURE__ */ b("span", {
														className: "natz-result-crown",
														"aria-hidden": "true",
														children: "♛"
													})]
												}),
												/* @__PURE__ */ b("span", {
													className: "natz-result-name",
													title: k(e),
													children: k(e)
												}),
												e === u && /* @__PURE__ */ b("small", { children: h("lobby.you") })
											]
										}, e);
									})] }) }), /* @__PURE__ */ b("tbody", { children: wt.map(([e, n]) => /* @__PURE__ */ x("tr", {
										className: e === "total" ? "natz-result-total" : "",
										children: [/* @__PURE__ */ b("th", {
											scope: "row",
											children: h(n)
										}), t.ranking.map((t) => /* @__PURE__ */ b("td", { children: m.scores[t][e] }, t))]
									}, e)) })]
								}),
								/* @__PURE__ */ x("div", {
									className: "natz-result-notes",
									children: [p !== void 0 && /* @__PURE__ */ b("p", { children: h("session.hint.usedCount", { n: p }) }), t.ranking.filter((e) => (t.autopilot?.[e] ?? 0) > 0).map((e) => /* @__PURE__ */ x("p", { children: [
										/* @__PURE__ */ b(c, { size: 14 }),
										k(e),
										" · ",
										h("session.autopilot.share", { n: Math.round(t.autopilot[e] * 100) })
									] }, e))]
								})
							]
						}),
						/* @__PURE__ */ x("footer", {
							className: "natz-result-footer",
							children: [/* @__PURE__ */ b("button", {
								type: "button",
								className: "natz-result-review",
								onClick: () => D(!1),
								children: h("games.nightatthezoo.reviewBoard")
							}), d || f ? /* @__PURE__ */ x("div", {
								className: "natz-result-host-actions",
								children: [f && /* @__PURE__ */ b("button", {
									type: "button",
									className: y === "lobby" ? "danger-stripes natz-confirm" : "",
									onBlur: () => C(null),
									onClick: () => j("lobby"),
									children: h(y === "lobby" ? "games.nightatthezoo.confirmLobby" : "session.result.backToLobby")
								}), d && /* @__PURE__ */ b("button", {
									type: "button",
									className: `natz-result-again ${y === "again" ? "danger-stripes natz-confirm" : ""}`,
									onBlur: () => C(null),
									onClick: () => j("again"),
									children: h(y === "again" ? "games.nightatthezoo.confirmAgain" : "session.result.playAgain")
								})]
							}) : /* @__PURE__ */ b("p", { children: h("session.result.waitHost") })]
						})
					]
				})
			}),
			/* @__PURE__ */ b("div", {
				className: "natz-result-restore",
				hidden: _,
				children: /* @__PURE__ */ b("button", {
					type: "button",
					ref: T,
					onClick: () => D(!0),
					children: h("games.nightatthezoo.restoreResult")
				})
			})
		]
	});
}
//#endregion
//#region src/games/nightatthezoo/game-over-row.tsx
var Ot = [
	"games.nightatthezoo.rank0",
	"games.nightatthezoo.rank1",
	"games.nightatthezoo.rank2",
	"games.nightatthezoo.rank3",
	"games.nightatthezoo.rank4"
];
function kt({ public: e, rid: t }) {
	let n = s(), r = e, i = r.scores[t];
	return i ? /* @__PURE__ */ x("div", {
		className: "mt-2 flex flex-wrap gap-x-3 gap-y-1 text-xs font-mono tabular-nums",
		children: [
			/* @__PURE__ */ x("span", { children: [
				n("games.nightatthezoo.immediate"),
				" ",
				i.immediate
			] }),
			/* @__PURE__ */ x("span", { children: [
				n("games.nightatthezoo.animalsScore"),
				" ",
				i.animals
			] }),
			/* @__PURE__ */ x("span", { children: [
				n("games.nightatthezoo.discoveredScore"),
				" ",
				i.discovered
			] }),
			/* @__PURE__ */ x("span", { children: [
				n("games.nightatthezoo.foodScore"),
				" ",
				i.food
			] }),
			/* @__PURE__ */ b("span", { children: n("games.nightatthezoo.homeCount", { n: i.home }) }),
			r.players.length === 1 && /* @__PURE__ */ x("strong", { children: [
				n("games.nightatthezoo.solo"),
				" · ",
				n(Ot[ze(i.total)])
			] })
		]
	}) : null;
}
//#endregion
//#region src/games/nightatthezoo/options.tsx
function At({ value: e, onChange: t }) {
	let n = s(), r = U.safeParse(e), i = r.success ? r.data : U.parse(void 0);
	return /* @__PURE__ */ b(w, {
		title: n("games.nightatthezoo.options"),
		children: /* @__PURE__ */ b(C, {
			name: "nightatthezoo-latecomers",
			value: "latecomers",
			checked: i.latecomers,
			label: n("games.nightatthezoo.latecomers"),
			hint: n("games.nightatthezoo.latecomersHint"),
			onChange: () => t({
				...i,
				latecomers: !i.latecomers
			})
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/nightatthezoo/entry.tsx
var jt = {
	definition: Be,
	View: lt,
	bot: Ct,
	OverView: Dt,
	RowView: kt,
	Options: At,
	locales: {
		zh: {
			name: "动物园之夜",
			finalBoard: "最终局面",
			resultTitle: "动物们回家了",
			winner: "{{name}}获胜",
			sharedVictory: "{{names}}共享胜利",
			reviewBoard: "回看动物园",
			restoreResult: "查看结算",
			homeNumber: "归园数量",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			desc: "铺设夜间小径，带各有本领的动物悄悄回家。",
			rules: "目标：\n帮助动物回到个人版图中央的动物园，获得最高总分。游戏共 3 轮，每轮选取 5 次板块；每局随机使用三种动物，难度月亮合计至少为 6。\n准备：\n每人按随机初始布局放置九只动物，其中每种动物各有一只已被发现，位于入口；其余动物需要通过“发现动物”行动进入入口。市场每次展示人数加一枚行动板块，奖励板块按岩石、草地、沙地分为三堆。仓库最多存放两枚板块。\n流程：\n从起始玩家开始，依次从市场选择一枚行动板块。剩余的一枚进入余留区。全部选取后，各自在个人版图上操作，全部结束后补充市场，并将起始玩家标记交给下一位玩家。\n你可以把新获得的板块铺到五行五列区域的任意空格（中央动物园除外），存入仓库，或弃置以进行特殊移动。已铺板块不能移动。仓库中的板块也可以在本阶段铺入或弃置，但不能打断同一次行动的两次移动。\n铺板可以触发板块和所覆盖格的行动，顺序由你选择，但必须完整结算一次行动后才执行另一次。板块若有两个以分隔线隔开的行动，选择其中一个。版图上的两个独立行动均可执行。印有地形条件的格需要匹配地形；印有望远镜条件的格需要行动板块上有“发现动物”符号，即使选择了板块的另一行动也算满足。成对格需要两格均铺上同种地形，整对只奖励一次。\n· 发现动物：选择一只尚未发现的动物，将它放入对应入口。\n· 获得奖励板块：选择一种尚有库存的地形，随后铺入、存储或弃置。奖励板块没有自己的行动，但仍可触发版图行动。\n· 移动：通常一枚箭头让一只动物移动到正交相邻的已铺板块；两枚箭头可以分给两只动物，或用于同一只动物。动物能力可能改变移动方式。除动物园外，不能踏入空格，不能返回外围入口。\n· 得分：立即获得所示分数。\n弃置板块时，让弃置前位于对应地形上的所有已发现动物各进行一次移动，包含入口上的动物；你选择它们的移动顺序。移动到这种地形的其他动物不会因此再获得移动。动物抵达动物园后立即归园，不能再移动。\n每轮结束：\n每第 5 次选取后的铺板阶段结束，余留区数量最多的地形触发一次移动，平手时取最左边的并列地形；所有位于该地形的已发现动物各移动一次，然后清空余留区。这不是弃置板块，不触发仅限弃置的能力。第三轮移动后结束游戏。\n动物能力：\n· 猎豹：弃置板块进行特殊移动时，可额外移动一格；每只归园获得 6 分。\n· 企鹅：沿选择的方向滑到连续板块的最远处，抵达动物园立即停止；每只归园获得 5 分。\n· 狼：归园一、二、三只，合计分别获得 7、16、27 分。\n· 蛇：只能沿当前朝向前进，也可以花一次移动改变朝向；初始朝向版图内部。每只归园获得 10 分。\n· 蝴蝶：弃置板块的特殊移动实际移动时获得一份花粉，最多四份；归园时零至四份花粉分别获得 0、5、7、9、11 分。\n· 树懒：醒着时移动一格后睡着；睡着时消耗一次移动醒来。被发现时醒着；每只归园获得 15 分。\nLatecomers 扩展：\n启用后，额外四种动物加入随机选择池，其他规则不变。\n· 乌龟：移动到相邻格需要两次移动，第一次停在连接边，视为同时占据两格（包括进入动物园）；第二次进入边的一端，不能返回入口。每只归园获得 8 分，并为每只其他归园动物额外获得 1 分。\n· 鳄鱼：任何时刻与其他动物同格，立即吃掉对方并获得 3 分，包含对方移动途中经过时；不吃其他鳄鱼，动物园内也不捕食。每只归园获得 8 分。\n· 猴子：弃置板块的特殊移动可以使用一枚可用的专属标记替代普通移动：直行三格、跳过中间格到两格外，或先走一格再转弯走两格。形状可旋转或镜像；直行与转弯的途经格需要有板块，跳跃不进入中间格。每枚标记只移动一只猴子，三枚全部使用后立即恢复。每只归园获得 7 分。\n· 狐獴：移动前若同一行或同一列有其他动物，本次可额外移动一格；每只归园获得 6 分。\n结算：\n总分包括已获得的即时分、归园动物分、每只已发现但未归园动物的 1 分，以及已铺板块上的食物种类奖励。仓库里的食物不计。不同食物种类为 0、1、2、3、4、5、6、7 种时，分别获得 0、0、6、8、11、16、22、30 分。同分时归园动物更多者获胜；仍相同则共享胜利。\n单人模式：\n使用三格市场和六枚单人优先级板块，Leo 首次先选，此后与你轮换先手。每次展示一枚优先级板块：Leo 取标有“1”的位置，若已被取走则取“2”；Leo 取走的板块移出游戏，最后剩余板块照常进入余留区。带循环箭头的板块使用后，重洗全部六枚。最终按总分评级：0–49 迷路狐猴，50–64 机敏黄鼠狼，65–79 聪明黑猩猩，80–89 出逃猛虎，90 分以上动物园幽灵。",
			rock: "岩石",
			grass: "草地",
			sand: "沙地",
			cheetah: "猎豹",
			penguin: "企鹅",
			wolf: "狼",
			snake: "蛇",
			butterfly: "蝴蝶",
			sloth: "树懒",
			turtle: "乌龟",
			crocodile: "鳄鱼",
			monkey: "猴子",
			meerkat: "狐獴",
			apple: "苹果",
			berries: "浆果",
			carrot: "胡萝卜",
			meat: "肉",
			egg: "蛋",
			lettuce: "生菜",
			fish: "鱼",
			ruleCheetah: "弃板块移动时额外一格；归园 6 分。",
			rulePenguin: "直线滑至最远处，动物园处停止；归园 5 分。",
			ruleWolf: "归园 1／2／3 只，共得 7／16／27 分。",
			ruleSnake: "只能向前；改变朝向也消耗一次移动。归园 10 分。",
			ruleButterfly: "弃板块移动获得花粉，最多 4 份；归园按花粉得 0／5／7／9／11 分。",
			ruleSloth: "移动后睡着，下次移动用于醒来；归园 15 分。",
			ruleTurtle: "两次移动前进一格，连接边视为占据两格；归园 8 分，其他归园动物各加 1 分。",
			ruleCrocodile: "同格即吃掉其他种类动物，每只得 3 分；归园 8 分。",
			ruleMonkey: "弃板块时可用专属移动标记，三枚用完恢复；归园 7 分。",
			ruleMeerkat: "移动前同行或同列有其他动物时额外一格；归园 6 分。",
			moveEffect: "移动 {{n}} 次",
			discoverEffect: "发现动物",
			bonusEffect: "获得 {{n}} 枚奖励板块",
			pointsEffect: "获得 {{n}} 分",
			options: "游戏选项",
			latecomers: "Latecomers 扩展",
			latecomersHint: "加入乌龟、鳄鱼、猴子和狐獴。",
			draftPrompt: "选择一枚行动板块",
			placePrompt: "使用板块并引导动物回园",
			roundPrompt: "{{terrain}}上的动物移动",
			waiting: "等待 {{name}}",
			finished: "已完成，等待其他玩家",
			roundDraft: "第 {{round}} 轮 · {{draft}} / 5",
			market: "板块市场",
			leftovers: "余留区",
			zoo: "动物园",
			warehouse: "仓库",
			supply: "奖励板块",
			yourBoard: "你的动物园",
			boardOf: "{{name}}的动物园",
			animalRules: "动物能力",
			held: "当前板块",
			noTile: "暂无板块",
			empty: "空格",
			tileLabel: "{{terrain}}板块：{{effect}}",
			plainTile: "无板块行动",
			cell: "第 {{row}} 行，第 {{col}} 列",
			entrance: "动物入口 {{n}}",
			animalLabel: "{{animal}} {{n}} · {{state}}",
			hidden: "尚未发现",
			onBoard: "途中",
			home: "已归园",
			eaten: "已被吃掉",
			asleep: "睡着",
			awake: "醒着",
			pollen: "花粉 {{n}} / 4",
			confirmPlace: "铺入此格",
			store: "存入仓库",
			discard: "弃置并移动",
			finish: "结束本次操作",
			passEffect: "放弃此行动",
			passMovement: "结束此次移动",
			decline: "放弃剩余奖励",
			chooseAction: "选择要执行的行动",
			chooseBonus: "选择奖励板块的地形",
			chooseDiscover: "选择要发现的动物",
			chooseAnimal: "选择要移动的动物",
			chooseDestination: "选择移动方式或目的地",
			moveTo: "移动到第 {{row}} 行、第 {{col}} 列",
			movePath: "{{path}}",
			turnNorth: "转向上方",
			turnEast: "转向右方",
			turnSouth: "转向下方",
			turnWest: "转向左方",
			wakeUp: "醒来",
			straight: "直行三格",
			jump: "跳跃",
			bend: "转弯三格",
			normalMove: "普通移动",
			step: "第 {{n}} 格",
			selectTile: "选择板块后点击版图空格",
			inspect: "查看动物与计分",
			close: "关闭",
			points: "{{n}} 分",
			score: "当前计分",
			immediate: "即时分",
			animalsScore: "归园动物",
			discoveredScore: "途中动物",
			foodScore: "食物种类",
			total: "总分",
			homeCount: "已归园 {{n}} / 9",
			solo: "单人评级",
			rank0: "迷路狐猴",
			rank1: "机敏黄鼠狼",
			rank2: "聪明黑猩猩",
			rank3: "出逃猛虎",
			rank4: "动物园幽灵",
			leo: "饲养员 Leo",
			leoPriority: "Leo 优先选择 {{a}}，其次 {{b}}",
			nextFirst: "本次先手：{{name}}",
			invalid: "当前不能执行此操作。",
			unfinished: "请先处理当前板块和行动。",
			logDraft: "{{name}}选择了{{terrain}}板块。",
			logPlace: "{{name}}铺入了{{terrain}}板块。",
			logStore: "{{name}}将板块存入仓库。",
			logDiscard: "{{name}}弃置{{terrain}}板块以移动动物。",
			logDiscover: "{{name}}发现了{{animal}}。",
			logMove: "{{name}}移动了{{animal}}。",
			logHome: "{{name}}的{{animal}}已归园。",
			logEaten: "{{name}}的{{animal}}被鳄鱼吃掉。",
			logPoints: "{{name}}获得 {{n}} 分。",
			logRound: "{{name}}进行{{terrain}}的轮末移动。",
			logLeo: "Leo 取走了{{terrain}}板块。"
		},
		en: {
			finalBoard: "Final board",
			resultTitle: "The animals are home",
			winner: "{{name}} wins",
			sharedVictory: "{{names}} share the victory",
			reviewBoard: "Review the Zoo",
			restoreResult: "View results",
			homeNumber: "Animals home",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			name: "Night at the Zoo",
			desc: "Build moonlit paths and guide your unusual animals safely home.",
			rules: "Goal:\nGuide animals to the Zoo in the center of your board and score the most points. Play three rounds of five drafts each. Each game uses three randomly drawn animal types with at least six difficulty moons in total.\nSetup:\nEach player places nine animals according to a random Setup tile. One of each species begins discovered at its entrance; the others must be discovered first. Each market contains one more Action tile than the number of players. Keep separate supplies of Rock, Grass and Sand Bonus tiles. Your Warehouse holds at most two tiles.\nGameplay:\nStarting with the first player, draft one Action tile each in clockwise order. Put the remaining tile in the Leftover zone. All players then use tiles on their own boards. When everyone finishes, refill the market and pass the First Player token clockwise.\nPlace a newly gained tile on any empty space in the inner 5×5 area except the central Zoo, store it in your Warehouse, or discard it for a special move. Placed tiles cannot move. You may also place or discard Warehouse tiles during this phase, but not between the two movements of the same action.\nPlacement can trigger both tile and board actions. Choose their order, completely resolving one action before another. When an Action tile has two symbols divided by a line, choose one. Separate actions printed on a board space may both be performed. Terrain conditions require the matching terrain. Binocular conditions require an Action tile with a discovery symbol, even if you choose its other action. A paired bonus requires both spaces to contain the same terrain and is awarded only once.\n· Discover: Choose a hidden animal and put it at its entrance.\n· Bonus tile: Choose a terrain still available in the supply, then place, store or discard the tile. Bonus tiles have no actions but can trigger board actions.\n· Move: Normally, each arrow moves one animal onto an orthogonally adjacent tile. Two arrows can move one animal twice or two animals once each. Species abilities modify these rules. Empty spaces cannot be entered except the Zoo, and animals cannot return to outer entrances.\n· Points: Immediately gain the indicated points.\nDiscarding a tile grants one movement to every discovered animal standing on that terrain before any of these movements, including animals at entrances. Choose their order. Animals that subsequently arrive on that terrain do not gain another movement. An animal reaching the Zoo immediately returns home and cannot move again.\nEnd of round:\nAfter every fifth draft's placement phase, the most common terrain in the Leftover zone grants one movement to every discovered animal standing on that terrain. Ties favor the leftmost tied terrain. Clear the Leftover zone afterward. This is not a discard and does not activate discard-only abilities. End the game after the third round's movement.\nAnimal abilities:\n· Cheetah: One additional step on a discard special move. Each scores 6 points at home.\n· Penguin: Slide as far as possible in a chosen straight line, stopping immediately at the Zoo. Each scores 5 points at home.\n· Wolf: One, two or three wolves at home score 7, 16 or 27 points in total.\n· Snake: Move forward in the facing direction, or spend one movement to change direction. Starts facing inward. Each scores 10 points at home.\n· Butterfly: When actually moving on a discard special move, gain one Pollen, up to four. At home, zero through four Pollen score 0, 5, 7, 9 or 11 points.\n· Sloth: When awake, move one step and fall asleep. When asleep, spend the movement waking up. Starts awake. Each scores 15 points at home.\nLatecomers expansion:\nWhen enabled, four additional species join the random pool; all other rules remain unchanged.\n· Turtle: Requires two movements to reach an adjacent tile. The first leaves it on the connecting edge, occupying both tiles for all effects, including entering the Zoo. The next movement reaches either end, without returning to an entrance. Each scores 8 points at home, plus 1 for every other animal at home.\n· Crocodile: Immediately eats any other species sharing its tile, even during movement, gaining 3 points for each. It never eats other Crocodiles or animals in the Zoo. Each scores 8 points at home.\n· Monkey: On a discard special move, may use an available token instead of its normal move: three straight steps, a jump to a tile two spaces away, or one step followed by a turn and two steps. Shapes can rotate or mirror. Straight and turning routes require tiles along the path; a jump does not enter the middle space. Each token moves exactly one Monkey. Refresh all three immediately after using the last token. Each scores 7 points at home.\n· Meerkat: Before moving, if another animal shares its row or column, it may take one additional step. Each scores 6 points at home.\nScoring:\nAdd immediate points, animals at home, 1 point per discovered animal still outside the Zoo, and food diversity on placed tiles. Warehouse food does not count. Zero through seven different foods score 0, 0, 6, 8, 11, 16, 22 or 30 points. Ties favor more animals at home; remaining ties share victory.\nSolo game:\nUse a three-position market and six Solo priority tiles. Leo drafts first initially; alternate first player thereafter. Reveal a priority tile each draft: Leo takes position 1, or position 2 if the first was already taken. Remove Leo's tile from the game and put the final leftover in the Leftover zone. After using the tile with the shuffle icon, reshuffle all six Solo tiles. Rate your final score: 0–49 Lost Lemur, 50–64 Sneaky Weasel, 65–79 Clever Chimp, 80–89 Runaway Tiger, 90+ Zoo Ghost.",
			rock: "Rock",
			grass: "Grass",
			sand: "Sand",
			cheetah: "Cheetah",
			penguin: "Penguin",
			wolf: "Wolf",
			snake: "Snake",
			butterfly: "Butterfly",
			sloth: "Sloth",
			turtle: "Turtle",
			crocodile: "Crocodile",
			monkey: "Monkey",
			meerkat: "Meerkat",
			apple: "Apple",
			berries: "Berries",
			carrot: "Carrot",
			meat: "Meat",
			egg: "Egg",
			lettuce: "Lettuce",
			fish: "Fish",
			ruleCheetah: "One extra step on a discard move. 6 points at home.",
			rulePenguin: "Slide to the furthest tile; stop at the Zoo. 5 points at home.",
			ruleWolf: "1 / 2 / 3 Wolves at home score 7 / 16 / 27 points total.",
			ruleSnake: "Move forward or spend a movement to turn. 10 points at home.",
			ruleButterfly: "Discard moves gain Pollen, up to 4. Score 0 / 5 / 7 / 9 / 11 at home.",
			ruleSloth: "Move, then sleep; the next movement wakes it. 15 points at home.",
			ruleTurtle: "Two movements per tile; an edge occupies both tiles. 8 at home, +1 per other animal home.",
			ruleCrocodile: "Eats other species sharing its tile for 3 points each. 8 at home.",
			ruleMonkey: "Discard moves can use special tokens; refresh after using all three. 7 at home.",
			ruleMeerkat: "One extra step if another animal shares its row or column. 6 at home.",
			moveEffect: "Move {{n}} times",
			discoverEffect: "Discover an animal",
			bonusEffect: "Gain {{n}} Bonus tiles",
			pointsEffect: "Gain {{n}} points",
			options: "Game options",
			latecomers: "Latecomers expansion",
			latecomersHint: "Add Turtle, Crocodile, Monkey and Meerkat.",
			draftPrompt: "Choose an Action tile",
			placePrompt: "Use tiles and guide your animals home",
			roundPrompt: "Move animals on {{terrain}}",
			waiting: "Waiting for {{name}}",
			finished: "Finished; waiting for other players",
			roundDraft: "Round {{round}} · {{draft}} / 5",
			market: "Tile market",
			leftovers: "Leftover zone",
			zoo: "Zoo",
			warehouse: "Warehouse",
			supply: "Bonus tiles",
			yourBoard: "Your Zoo",
			boardOf: "{{name}}’s Zoo",
			animalRules: "Animal abilities",
			held: "Current tile",
			noTile: "No tile",
			empty: "Empty space",
			tileLabel: "{{terrain}} tile: {{effect}}",
			plainTile: "No tile action",
			cell: "Row {{row}}, column {{col}}",
			entrance: "Animal entrance {{n}}",
			animalLabel: "{{animal}} {{n}} · {{state}}",
			hidden: "Undiscovered",
			onBoard: "On the way",
			home: "Home",
			eaten: "Eaten",
			asleep: "Asleep",
			awake: "Awake",
			pollen: "Pollen {{n}} / 4",
			confirmPlace: "Place here",
			store: "Store tile",
			discard: "Discard to move",
			finish: "Finish this draft",
			passEffect: "Skip this action",
			passMovement: "End this movement",
			decline: "Skip remaining rewards",
			chooseAction: "Choose an action",
			chooseBonus: "Choose a Bonus tile terrain",
			chooseDiscover: "Choose an animal to discover",
			chooseAnimal: "Choose an animal to move",
			chooseDestination: "Choose a move or destination",
			moveTo: "Move to row {{row}}, column {{col}}",
			movePath: "{{path}}",
			turnNorth: "Face up",
			turnEast: "Face right",
			turnSouth: "Face down",
			turnWest: "Face left",
			wakeUp: "Wake up",
			straight: "Three straight steps",
			jump: "Jump",
			bend: "Three turning steps",
			normalMove: "Normal move",
			step: "Space {{n}}",
			selectTile: "Select a tile, then choose an empty board space",
			inspect: "Animals and scoring",
			close: "Close",
			points: "{{n}} points",
			score: "Current scoring",
			immediate: "Immediate",
			animalsScore: "Animals home",
			discoveredScore: "Animals outside",
			foodScore: "Food diversity",
			total: "Total",
			homeCount: "{{n}} / 9 home",
			solo: "Solo rating",
			rank0: "Lost Lemur",
			rank1: "Sneaky Weasel",
			rank2: "Clever Chimp",
			rank3: "Runaway Tiger",
			rank4: "Zoo Ghost",
			leo: "Zookeeper Leo",
			leoPriority: "Leo prefers {{a}}, then {{b}}",
			nextFirst: "First player: {{name}}",
			invalid: "That action is not available now.",
			unfinished: "Resolve the current tile and actions first.",
			logDraft: "{{name}} drafted a {{terrain}} tile.",
			logPlace: "{{name}} placed a {{terrain}} tile.",
			logStore: "{{name}} stored a tile.",
			logDiscard: "{{name}} discarded a {{terrain}} tile to move animals.",
			logDiscover: "{{name}} discovered a {{animal}}.",
			logMove: "{{name}} moved a {{animal}}.",
			logHome: "{{name}}’s {{animal}} arrived home.",
			logEaten: "{{name}}’s {{animal}} was eaten by a Crocodile.",
			logPoints: "{{name}} gained {{n}} points.",
			logRound: "{{name}} is taking the {{terrain}} end-of-round movement.",
			logLeo: "Leo removed a {{terrain}} tile."
		}
	}
};
//#endregion
export { jt as default };
