import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useT as s } from "@bgparty/sdk/i18n";
import { IconCheck as c, IconClose as l, IconEye as u } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { Texture as f } from "@bgparty/sdk/texture";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { botAvatarOf as v } from "@bgparty/sdk/lobby";
import { botPersonality as y } from "@bgparty/sdk/bot-personality";
import { Floater as b, FlySprite as x, PulseBox as S } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as C } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/lovecraftletter/cards.ts
var w = {
	braincase: {
		value: 0,
		count: 1,
		insane: !0,
		target: "none",
		insaneTarget: "none",
		guess: !1,
		emoji: "🧠"
	},
	investigators: {
		value: 1,
		count: 5,
		insane: !1,
		target: "other",
		insaneTarget: "none",
		guess: !0,
		emoji: "🔍"
	},
	deepones: {
		value: 1,
		count: 1,
		insane: !0,
		target: "other",
		insaneTarget: "other",
		guess: !0,
		emoji: "🐟"
	},
	cats: {
		value: 2,
		count: 2,
		insane: !1,
		target: "other",
		insaneTarget: "none",
		guess: !1,
		emoji: "🐈"
	},
	goldenmead: {
		value: 2,
		count: 1,
		insane: !0,
		target: "other",
		insaneTarget: "other",
		guess: !1,
		emoji: "🍷"
	},
	greatrace: {
		value: 3,
		count: 2,
		insane: !1,
		target: "other",
		insaneTarget: "none",
		guess: !1,
		emoji: "🔮"
	},
	hound: {
		value: 3,
		count: 1,
		insane: !0,
		target: "other",
		insaneTarget: "other",
		guess: !1,
		emoji: "🐕"
	},
	eldersign: {
		value: 4,
		count: 2,
		insane: !1,
		target: "none",
		insaneTarget: "none",
		guess: !1,
		emoji: "🌿"
	},
	liber: {
		value: 4,
		count: 1,
		insane: !0,
		target: "none",
		insaneTarget: "none",
		guess: !1,
		emoji: "📕"
	},
	armitage: {
		value: 5,
		count: 2,
		insane: !1,
		target: "any",
		insaneTarget: "none",
		guess: !1,
		emoji: "🎓"
	},
	migo: {
		value: 5,
		count: 1,
		insane: !0,
		target: "any",
		insaneTarget: "other",
		guess: !1,
		emoji: "🦟"
	},
	randolph: {
		value: 6,
		count: 1,
		insane: !1,
		target: "other",
		insaneTarget: "none",
		guess: !1,
		emoji: "🌙"
	},
	nyarlathotep: {
		value: 6,
		count: 1,
		insane: !0,
		target: "other",
		insaneTarget: "none",
		guess: !1,
		emoji: "👁️"
	},
	silverkey: {
		value: 7,
		count: 1,
		insane: !1,
		target: "none",
		insaneTarget: "none",
		guess: !1,
		emoji: "🗝️"
	},
	trapezohedron: {
		value: 7,
		count: 1,
		insane: !0,
		target: "none",
		insaneTarget: "none",
		guess: !1,
		emoji: "💠"
	},
	necronomicon: {
		value: 8,
		count: 1,
		insane: !1,
		target: "none",
		insaneTarget: "none",
		guess: !1,
		emoji: "📖"
	},
	cthulhu: {
		value: 8,
		count: 1,
		insane: !0,
		target: "none",
		insaneTarget: "none",
		guess: !1,
		emoji: "🐙"
	}
}, T = [
	"braincase",
	"investigators",
	"deepones",
	"cats",
	"goldenmead",
	"greatrace",
	"hound",
	"eldersign",
	"liber",
	"armitage",
	"migo",
	"randolph",
	"nyarlathotep",
	"silverkey",
	"trapezohedron",
	"necronomicon",
	"cthulhu"
];
function E() {
	return T.flatMap((e) => Array.from({ length: w[e].count }, () => e));
}
var D = {
	braincase: "games.lovecraftletter.card.braincase",
	investigators: "games.lovecraftletter.card.investigators",
	deepones: "games.lovecraftletter.card.deepones",
	cats: "games.lovecraftletter.card.cats",
	goldenmead: "games.lovecraftletter.card.goldenmead",
	greatrace: "games.lovecraftletter.card.greatrace",
	hound: "games.lovecraftletter.card.hound",
	eldersign: "games.lovecraftletter.card.eldersign",
	liber: "games.lovecraftletter.card.liber",
	armitage: "games.lovecraftletter.card.armitage",
	migo: "games.lovecraftletter.card.migo",
	randolph: "games.lovecraftletter.card.randolph",
	nyarlathotep: "games.lovecraftletter.card.nyarlathotep",
	silverkey: "games.lovecraftletter.card.silverkey",
	trapezohedron: "games.lovecraftletter.card.trapezohedron",
	necronomicon: "games.lovecraftletter.card.necronomicon",
	cthulhu: "games.lovecraftletter.card.cthulhu"
}, O = {
	braincase: "games.lovecraftletter.sane.braincase",
	investigators: "games.lovecraftletter.sane.investigators",
	deepones: "games.lovecraftletter.sane.deepones",
	cats: "games.lovecraftletter.sane.cats",
	goldenmead: "games.lovecraftletter.sane.goldenmead",
	greatrace: "games.lovecraftletter.sane.greatrace",
	hound: "games.lovecraftletter.sane.hound",
	eldersign: "games.lovecraftletter.sane.eldersign",
	liber: "games.lovecraftletter.sane.liber",
	armitage: "games.lovecraftletter.sane.armitage",
	migo: "games.lovecraftletter.sane.migo",
	randolph: "games.lovecraftletter.sane.randolph",
	nyarlathotep: "games.lovecraftletter.sane.nyarlathotep",
	silverkey: "games.lovecraftletter.sane.silverkey",
	trapezohedron: "games.lovecraftletter.sane.trapezohedron",
	necronomicon: "games.lovecraftletter.sane.necronomicon",
	cthulhu: "games.lovecraftletter.sane.cthulhu"
}, ee = {
	braincase: "games.lovecraftletter.insane.braincase",
	investigators: "games.lovecraftletter.insane.none",
	deepones: "games.lovecraftletter.insane.deepones",
	cats: "games.lovecraftletter.insane.none",
	goldenmead: "games.lovecraftletter.insane.goldenmead",
	greatrace: "games.lovecraftletter.insane.none",
	hound: "games.lovecraftletter.insane.hound",
	eldersign: "games.lovecraftletter.insane.none",
	liber: "games.lovecraftletter.insane.liber",
	armitage: "games.lovecraftletter.insane.none",
	migo: "games.lovecraftletter.insane.migo",
	randolph: "games.lovecraftletter.insane.none",
	nyarlathotep: "games.lovecraftletter.insane.nyarlathotep",
	silverkey: "games.lovecraftletter.insane.none",
	trapezohedron: "games.lovecraftletter.insane.trapezohedron",
	necronomicon: "games.lovecraftletter.insane.none",
	cthulhu: "games.lovecraftletter.insane.cthulhu"
}, k = "#15803d", A = {
	id: "lovecraftletter",
	tier: "alpha",
	mechanics: ["hand-management", "push-your-luck"],
	interactionTags: [],
	nameKey: "games.lovecraftletter.name",
	descKey: "games.lovecraftletter.desc",
	rulesKey: "games.lovecraftletter.rules",
	icon: "🐙",
	iconImg: "games/lovecraftletter.webp",
	rulesUrl: { en: "https://alderac.com/wp-content/uploads/2016/12/lovecraft_letter_rulebook_v1.3-1.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [4, 5],
	accent: "#6d28d9",
	releasedAt: "2026-09-28",
	search: {
		py: "ke su lu qing shu",
		init: "kslqs"
	},
	hotseat: "cover"
}, j = t.enum([
	"braincase",
	"investigators",
	"deepones",
	"cats",
	"goldenmead",
	"greatrace",
	"hound",
	"eldersign",
	"liber",
	"armitage",
	"migo",
	"randolph",
	"nyarlathotep",
	"silverkey",
	"trapezohedron",
	"necronomicon",
	"cthulhu"
]), M = t.string(), N = t.int().min(1).max(8), P = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: j,
		insane: t.boolean().optional(),
		target: M.optional(),
		guess: N.optional()
	}),
	t.object({
		type: t.literal("followup"),
		card: j,
		insane: t.boolean().optional(),
		target: M.optional(),
		guess: N.optional()
	}),
	t.object({
		type: t.literal("nyarlAssign"),
		deal: t.record(M, j)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), F = t.discriminatedUnion("kind", [t.object({
	kind: t.literal("look"),
	target: M,
	card: j
}), t.object({
	kind: t.literal("compare"),
	opponent: M,
	myCard: j,
	theirCard: j,
	iWon: t.boolean().nullable()
})]), I = t.object({
	kind: t.literal("play"),
	rid: M,
	card: j,
	insane: t.boolean(),
	target: M.nullable(),
	guess: t.int().min(1).max(8).nullable(),
	hit: t.boolean(),
	outRid: M.nullable()
}), L = t.object({
	kind: t.literal("sanity"),
	rid: M,
	revealed: t.array(j),
	failed: t.boolean(),
	survived: t.boolean()
}), R = t.object({
	kind: t.literal("roundEnd"),
	reason: t.enum([
		"lastStanding",
		"deckOut",
		"trap"
	]),
	winner: M.nullable(),
	insane: t.boolean().nullable()
}), te = t.object({
	kind: t.literal("cthulhuWin"),
	rid: M
}), ne = t.discriminatedUnion("kind", [
	I,
	L,
	R,
	te
]), re = t.discriminatedUnion("kind", [
	I,
	L,
	R,
	te,
	t.object({
		kind: t.literal("round"),
		n: t.int().min(1)
	})
]), ie = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"play",
		"settle",
		"roundEnd",
		"done"
	]),
	deckCount: t.int().nonnegative(),
	burnUp: t.array(j),
	braincaseAside: t.boolean(),
	turn: M.nullable(),
	players: t.array(t.object({
		rid: M,
		out: t.boolean(),
		protected: t.boolean(),
		koImmune: t.boolean(),
		insane: t.boolean(),
		tokensSane: t.int().nonnegative(),
		tokensInsane: t.int().nonnegative(),
		handCount: t.int().nonnegative(),
		discards: t.array(j)
	})),
	pending: t.discriminatedUnion("kind", [t.object({
		kind: t.enum(["mead", "migo"]),
		rid: M
	}), t.object({
		kind: t.literal("nyarlathotep"),
		rid: M,
		rids: t.array(M)
	})]).nullable(),
	revealHands: t.record(M, t.array(j)).nullable(),
	winner: M.nullable(),
	last: ne.nullable(),
	log: t.array(re)
}), ae = t.object({
	hand: t.array(j),
	reveal: F.nullable(),
	nyarlPool: t.record(M, j).nullable()
}), oe = 4200, z = {
	play: (e) => e ? 1900 : 1100,
	out: 1400,
	sanity: (e) => 900 + 450 * e
}, B = (e) => e.players.filter((t) => !e.outRids.includes(t)), V = (e, t) => e.discards[t].some((e) => w[e].insane), H = (e, t) => e.discards[t].filter((e) => w[e].insane).length;
function U(e, t, n) {
	let r = B(e).filter((n) => n !== t && !e.protectedRids.includes(n));
	return n === "any" ? [t, ...r] : r;
}
function se(e, t) {
	return e.filter((n, r) => n !== "silverkey" && (n !== "trapezohedron" || t) ? !1 : e.some((e, t) => t !== r && w[e].value > 4));
}
function W(e) {
	for (let t of B(e)) {
		let n = e.hands[t];
		if (V(e, t) && n.includes("trapezohedron") && n.some((e) => e !== "trapezohedron" && w[e].value > 4)) return t;
	}
	return null;
}
function ce(t, n) {
	let r = t.rngCursor;
	for (let i = n.length - 1; i > 0; --i) {
		let a = e(t.seed, r, i + 1);
		r += 1, [n[i], n[a]] = [n[a], n[i]];
	}
	return t.rngCursor = r, n;
}
function G(e) {
	if (e.deck.length > 0) return e.deck.pop();
	if (e.burnDown) {
		let t = e.burnDown;
		return e.burnDown = null, t;
	}
	return null;
}
function K(e, t) {
	return !e.koImmuneRids.includes(t) && (e.discards[t] = [...e.discards[t], ...e.hands[t]], e.hands[t] = [], e.outRids.includes(t) || (e.outRids = [...e.outRids, t]), e.protectedRids = e.protectedRids.filter((e) => e !== t), !0);
}
function q(e, t, n) {
	let r = B(e), i = null;
	if (t === "lastStanding") i = r[0] ?? null;
	else if (t === "trap") i = n ?? null;
	else {
		let t = (t) => e.hands[t].length ? Math.max(...e.hands[t].map((e) => w[e].value)) : -1, n = /* @__PURE__ */ new Map();
		for (let e of r) n.set(t(e), (n.get(t(e)) ?? 0) + 1);
		let a = -1;
		for (let e of r) {
			let r = t(e);
			(n.get(r) ?? 0) === 1 && r > a && (a = r, i = e);
		}
	}
	let a = i ? V(e, i) : null;
	i && (a ? e.tokensInsane[i] += 1 : e.tokensSane[i] += 1);
	let o = {
		kind: "roundEnd",
		reason: t,
		winner: i,
		insane: a
	};
	e.last = o, e.log = [...e.log, o];
	let s = [{
		kind: "roundEnd",
		data: {
			reason: t,
			winner: i,
			insane: a
		}
	}, ...i ? [{
		kind: "token",
		rid: i,
		data: { insane: a }
	}] : []];
	return e.turn = null, e.after = null, e.pending = null, e.stagedReveals = null, i && (e.tokensSane[i] >= 2 || e.tokensInsane[i] >= 3) ? (e.phase = "done", e.winner = i) : (e.phase = "roundEnd", e.beatMs = oe), s;
}
function le(e, t) {
	e.phase = "done", e.winner = t, e.turn = null, e.after = null, e.pending = null, e.stagedReveals = null;
	let n = {
		kind: "cthulhuWin",
		rid: t
	};
	return e.last = n, e.log = [...e.log, n], [{
		kind: "cthulhuWin",
		rid: t,
		data: {}
	}];
}
function ue(e, t) {
	e.deck = ce(e, E().filter((e) => e !== "braincase")), e.braincaseAside = !0, e.burnDown = e.deck.pop() ?? null, e.burnUp = e.players.length === 2 ? [
		e.deck.pop(),
		e.deck.pop(),
		e.deck.pop(),
		e.deck.pop(),
		e.deck.pop()
	] : [], e.hands = Object.fromEntries(e.players.map((t) => [t, [e.deck.pop()]])), e.discards = Object.fromEntries(e.players.map((e) => [e, []])), e.protectedRids = [], e.koImmuneRids = [], e.outRids = [], e.reveals = Object.fromEntries(e.players.map((e) => [e, null])), e.stagedReveals = null, e.pending = null, e.after = null, e.firstIndex = e.players.indexOf(t);
}
function de(e, t) {
	let n = H(e, t), r = [], i = !1;
	for (let t = 0; t < n && e.deck.length !== 0; t += 1) {
		let t = e.deck.pop();
		if (r.push(t), w[t].insane || t === "necronomicon" || t === "cthulhu") {
			i = !0;
			break;
		}
	}
	return e.discards[t] = [...e.discards[t], ...r], {
		revealed: r,
		failed: i
	};
}
function fe(e, t) {
	if (e.deck.length === 0) return e.turn = null, q(e, "deckOut");
	let n = e.deck.pop();
	e.hands[t] = [...e.hands[t], n], e.turn = t, e.phase = "play";
	let r = [{
		kind: "draw",
		rid: t,
		data: {},
		for: [t],
		secret: { card: n }
	}], i = W(e);
	return i ? (e.turn = null, [...r, ...q(e, "trap", i)]) : r;
}
function J(e, t) {
	if (e.protectedRids = e.protectedRids.filter((e) => e !== t), !V(e, t)) return fe(e, t);
	if (e.deck.length === 0) return e.turn = null, q(e, "deckOut");
	let { revealed: n, failed: r } = de(e, t), i = !r || e.koImmuneRids.includes(t);
	r && !i && K(e, t);
	let a = {
		kind: "sanity",
		rid: t,
		revealed: n,
		failed: r,
		survived: i
	};
	e.last = a, e.log = [...e.log, a];
	let o = [{
		kind: "sanity",
		rid: t,
		data: {
			revealed: n,
			failed: r,
			survived: i
		}
	}, ...r && !i ? [{
		kind: "out",
		rid: t
	}] : []];
	return e.beatMs = z.sanity(n.length) + (r && !i ? z.out : 0), e.deck.length === 0 ? (e.turn = null, [...o, ...q(e, "deckOut")]) : r && !i ? B(e).length <= 1 ? (e.turn = null, [...o, ...q(e, "lastStanding")]) : (e.turn = t, e.phase = "settle", e.after = "advance", o) : (e.turn = t, e.phase = "settle", e.after = { turn: t }, o);
}
function Y(e) {
	if (B(e).length <= 1) return e.turn = null, q(e, "lastStanding");
	let t = e.players.indexOf(e.turn);
	for (let n = 1; n <= e.players.length; n += 1) {
		let r = e.players[(t + n) % e.players.length];
		if (!e.outRids.includes(r)) return J(e, r);
	}
	return [];
}
var pe = {
	outRid: null,
	hit: !1,
	dropped: null,
	fxFor: null,
	fxSecret: null,
	pending: null,
	gameWinner: null
};
function me(e, t, n, r, i, a) {
	let o = { ...pe }, s = () => e.hands[t][0];
	switch (n) {
		case "investigators":
			i && a !== null && e.hands[i].length && w[e.hands[i][0]].value === a && (o.hit = !0, K(e, i) && (o.outRid = i));
			break;
		case "deepones":
			if (r) {
				if (i && e.hands[i].length) {
					let t = w[e.hands[i][0]].value;
					(t === 1 || a !== null && a > 1 && t === a) && (o.hit = !0, K(e, i) && (o.outRid = i));
				}
			} else i && a !== null && e.hands[i].length && w[e.hands[i][0]].value === a && (o.hit = !0, K(e, i) && (o.outRid = i));
			break;
		case "cats":
		case "goldenmead":
			if (i && e.hands[i].length) {
				let n = e.hands[i][0];
				e.stagedReveals = {
					...e.stagedReveals ?? {},
					[t]: {
						kind: "look",
						target: i,
						card: n
					}
				}, o.fxFor = [t], o.fxSecret = { peek: n };
			}
			if (n === "goldenmead" && r && i) {
				let n = G(e);
				n && (e.hands[t] = [...e.hands[t], n]), o.pending = {
					kind: "mead",
					rid: t
				};
			}
			break;
		case "greatrace":
		case "hound":
			if (r) i && !V(e, i) && (o.hit = !0, K(e, i) && (o.outRid = i));
			else if (i && e.hands[i].length) {
				if (e.hands[t].length === 0) break;
				let n = s(), r = e.hands[i][0], a = w[n].value - w[r].value;
				if (e.stagedReveals = {
					...e.stagedReveals ?? {},
					[t]: {
						kind: "compare",
						opponent: i,
						myCard: n,
						theirCard: r,
						iWon: a === 0 ? null : a > 0
					},
					[i]: {
						kind: "compare",
						opponent: t,
						myCard: r,
						theirCard: n,
						iWon: a === 0 ? null : a < 0
					}
				}, o.fxFor = [t, i], o.fxSecret = {
					mine: n,
					theirs: r
				}, a !== 0) {
					let n = a < 0 ? t : i;
					o.hit = !0, K(e, n) && (o.outRid = n);
				}
			}
			break;
		case "eldersign":
			e.protectedRids = [...e.protectedRids, t];
			break;
		case "liber":
			r ? e.koImmuneRids = [...e.koImmuneRids, t] : e.protectedRids = [...e.protectedRids, t];
			break;
		case "armitage":
		case "migo":
			if (n === "migo" && r) {
				i && e.braincaseAside && (e.hands[t] = [...e.hands[t], ...e.hands[i]], e.hands[i] = ["braincase"], e.braincaseAside = !1, o.fxFor = [t, i], o.fxSecret = { taken: e.hands[t][e.hands[t].length - 1] }, o.pending = {
					kind: "migo",
					rid: t
				});
				break;
			}
			if (i && e.hands[i].length) {
				let t = e.hands[i][0];
				if (o.dropped = t, e.hands[i] = [], e.discards[i] = [...e.discards[i], t], t === "necronomicon" || t === "cthulhu") {
					if (o.hit = !0, K(e, i)) o.outRid = i;
					else {
						let t = G(e);
						t && (e.hands[i] = [t]);
					}
				} else {
					let t = G(e);
					t && (e.hands[i] = [t]);
				}
			}
			break;
		case "randolph":
		case "nyarlathotep":
			if (n === "nyarlathotep" && r) {
				let n = {};
				for (let r of B(e)) r !== t && e.hands[r].length !== 0 && (n[r] = e.hands[r][0], e.hands[r] = []);
				Object.keys(n).length > 0 && (o.pending = {
					kind: "nyarlathotep",
					rid: t,
					pool: n
				});
				break;
			}
			if (i && e.hands[i].length) {
				e.hands[t].length > 0 && (o.fxFor = [t, i], o.fxSecret = {
					mine: e.hands[t][0],
					theirs: e.hands[i][0]
				});
				let n = e.hands[t];
				e.hands[t] = e.hands[i], e.hands[i] = n;
			}
			break;
		case "necronomicon":
		case "braincase":
			K(e, t) && (o.outRid = t), o.hit = !0;
			break;
		case "cthulhu": r && H(e, t) >= 2 ? o.gameWinner = t : (K(e, t) && (o.outRid = t), o.hit = !0);
	}
	return o;
}
function he(e, t, n) {
	let r = e.hands[t];
	if (!r.includes(n.card)) return { code: "games.lovecraftletter.errBadCard" };
	let i = !!n.insane && w[n.card].insane && V(e, t);
	if (n.insane && !i) return { code: "games.lovecraftletter.errNotInsane" };
	let a = se(r, V(e, t));
	if (a.length > 0 && !a.includes(n.card)) return { code: "games.lovecraftletter.errForced" };
	let o = i ? w[n.card].insaneTarget : w[n.card].target, s = null;
	if (o !== "none") {
		let r = U(e, t, o);
		if (r.length > 0) {
			if (!n.target || !r.includes(n.target)) return { code: "games.lovecraftletter.errBadTarget" };
			s = n.target;
		}
	}
	let c = null;
	if (w[n.card].guess) {
		if (n.guess !== void 0) {
			if (n.guess < 1 || n.guess > 8) return { code: "games.lovecraftletter.errBadGuess" };
			c = n.guess;
		}
		if (!i && c === null && s || !i && c !== null && c < 2) return { code: "games.lovecraftletter.errBadGuess" };
	}
	return {
		card: n.card,
		insane: i,
		target: s,
		guess: c
	};
}
function ge(e, t, n, r, i, a) {
	e.reveals[t] = null, e.hands[t].splice(e.hands[t].indexOf(n), 1);
	let o = me(e, t, n, r, i, a);
	e.discards[t] = [...e.discards[t], n];
	let s = {
		kind: "play",
		rid: t,
		card: n,
		insane: r,
		target: i,
		guess: a,
		hit: o.hit,
		outRid: o.outRid
	}, c = {
		kind: "play",
		rid: t,
		data: {
			card: n,
			insane: r,
			target: i,
			guess: a,
			outRid: o.outRid,
			...o.dropped ? { dropped: o.dropped } : {}
		},
		...o.fxFor && o.fxSecret ? {
			for: o.fxFor,
			secret: o.fxSecret
		} : {}
	};
	if (o.gameWinner) return e.log = [...e.log, s], {
		state: e,
		fx: [c, ...le(e, o.gameWinner)]
	};
	let l = W(e);
	if (l) return e.log = [...e.log, s], {
		state: e,
		fx: [c, ...q(e, "trap", l)]
	};
	e.last = s, e.log = [...e.log, s], e.phase = "settle", e.after = "advance";
	let u = i !== null || o.pending !== null;
	return e.beatMs = z.play(u) + (o.outRid ? z.out : 0), o.pending && (e.pending = o.pending, e.after = null), {
		state: e,
		fx: [c, ...o.outRid ? [{
			kind: "out",
			rid: o.outRid
		}] : []]
	};
}
function _e(t, n, r) {
	let i = {
		players: n,
		round: 1,
		phase: "play",
		deck: [],
		burnDown: null,
		burnUp: [],
		braincaseAside: !0,
		hands: {},
		discards: {},
		protectedRids: [],
		koImmuneRids: [],
		outRids: [],
		turn: null,
		tokensSane: Object.fromEntries(n.map((e) => [e, 0])),
		tokensInsane: Object.fromEntries(n.map((e) => [e, 0])),
		firstIndex: 0,
		reveals: {},
		stagedReveals: null,
		pending: null,
		after: null,
		last: null,
		log: [{
			kind: "round",
			n: 1
		}],
		winner: null,
		beatMs: 0,
		seed: r,
		rngCursor: 0
	};
	return ue(i, n[e(r, i.rngCursor++, n.length)]), {
		state: i,
		fx: [{
			kind: "roundStart",
			data: { round: 1 }
		}, ...J(i, i.players[i.firstIndex])]
	};
}
function ve(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "settle") {
			let t = structuredClone(e);
			if (t.phase = "play", t.beatMs = 0, t.stagedReveals) {
				for (let [e, n] of Object.entries(t.stagedReveals)) t.reveals[e] = n;
				t.stagedReveals = null;
			}
			if (t.pending) return {
				state: t,
				fx: []
			};
			if (t.after === "advance") return t.after = null, {
				state: t,
				fx: Y(t)
			};
			if (t.after && typeof t.after == "object") {
				let e = t.after.turn;
				return t.after = null, {
					state: t,
					fx: fe(t, e)
				};
			}
			return {
				state: t,
				fx: Y(t)
			};
		}
		if (e.phase !== "roundEnd") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = t.last?.kind === "roundEnd" ? t.last : null, r = n?.winner ? n.winner : t.players[(t.firstIndex + 1) % t.players.length];
		t.round += 1, t.phase = "play", t.last = null, t.log = [...t.log, {
			kind: "round",
			n: t.round
		}], t.beatMs = 0, ue(t, r);
		let i = J(t, t.players[t.firstIndex]);
		return {
			state: t,
			fx: [{
				kind: "roundStart",
				data: { round: t.round }
			}, ...i]
		};
	}
	if (e.phase !== "play") return { code: "games.lovecraftletter.errNotYourTurn" };
	if (e.pending?.kind === "nyarlathotep") {
		if (t.type !== "nyarlAssign") return { code: "games.lovecraftletter.errPending" };
		if (e.pending.rid !== n.by) return { code: "games.lovecraftletter.errNotYourTurn" };
		let r = e.pending.pool, i = Object.keys(r).sort(), a = t.deal;
		if (Object.keys(a).sort().join("|") !== i.join("|")) return { code: "games.lovecraftletter.errBadAssign" };
		let o = i.map((e) => r[e]).sort(), s = i.map((e) => a[e]).sort();
		if (o.join("|") !== s.join("|")) return { code: "games.lovecraftletter.errBadAssign" };
		let c = structuredClone(e);
		for (let e of i) c.hands[e] = [a[e]];
		c.pending = null;
		let l = W(c);
		return l ? {
			state: c,
			fx: q(c, "trap", l)
		} : (c.phase = "settle", c.beatMs = z.play(!0), {
			state: c,
			fx: [{
				kind: "nyarlDeal",
				rid: n.by,
				data: { rids: i }
			}]
		});
	}
	if (e.pending) {
		if (t.type !== "followup") return { code: "games.lovecraftletter.errPending" };
		if (e.pending.rid !== n.by) return { code: "games.lovecraftletter.errNotYourTurn" };
		let r = he(e, n.by, t);
		if ("code" in r) return r;
		let i = structuredClone(e);
		return i.pending = null, ge(i, n.by, r.card, r.insane, r.target, r.guess);
	}
	if (e.turn !== n.by || t.type !== "play") return { code: "games.lovecraftletter.errNotYourTurn" };
	let r = he(e, n.by, t);
	return "code" in r ? r : ge(structuredClone(e), n.by, r.card, r.insane, r.target, r.guess);
}
function ye(e, t) {
	let n = e.phase === "roundEnd" || e.phase === "done" ? Object.fromEntries(B(e).map((t) => [t, e.hands[t]])) : null;
	return {
		public: {
			round: e.round,
			phase: e.phase,
			deckCount: e.deck.length,
			burnUp: e.burnUp,
			braincaseAside: e.braincaseAside,
			turn: e.turn,
			players: e.players.map((t) => ({
				rid: t,
				out: e.outRids.includes(t),
				protected: e.protectedRids.includes(t),
				koImmune: e.koImmuneRids.includes(t),
				insane: V(e, t),
				tokensSane: e.tokensSane[t],
				tokensInsane: e.tokensInsane[t],
				handCount: e.hands[t]?.length ?? 0,
				discards: e.discards[t]
			})),
			pending: e.pending?.kind === "nyarlathotep" ? {
				kind: "nyarlathotep",
				rid: e.pending.rid,
				rids: Object.keys(e.pending.pool)
			} : e.pending ? {
				kind: e.pending.kind,
				rid: e.pending.rid
			} : null,
			revealHands: n,
			winner: e.winner,
			last: e.last,
			log: e.log
		},
		private: {
			hand: e.hands[t] ?? [],
			reveal: e.reveals[t] ?? null,
			nyarlPool: e.pending?.kind === "nyarlathotep" && e.pending.rid === t ? e.pending.pool : null
		}
	};
}
function be(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => e.tokensSane[t] + e.tokensInsane[t], n = [...e.players].sort((n, r) => +(r === e.winner) - (n === e.winner) || t(r) - t(n));
	return {
		phase: "done",
		winner: e.winner ? [e.winner] : [],
		ranking: n,
		scores: Object.fromEntries(e.players.map((e) => [e, t(e)]))
	};
}
function xe(e) {
	return e.phase === "settle" || e.phase === "roundEnd" ? e.beatMs : null;
}
var Se = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: A,
	schemas: {
		action: P,
		publicView: ie,
		privateView: ae
	},
	setup: _e,
	reduce: ve,
	viewFor: ye,
	status: be,
	nextTickIn: xe
}, Ce = {
	hand: "h-32 w-22 rounded-md border-2",
	small: "h-14 w-11 rounded border"
}, we = "var(--color-ink)";
function Te({ card: e, size: t }) {
	let n = {
		fill: "none",
		stroke: we,
		strokeWidth: 3.2,
		strokeLinecap: "round",
		strokeLinejoin: "round"
	}, r = {
		...n,
		strokeWidth: 2.2
	}, i = {
		...n,
		strokeWidth: 1.6
	}, a = {
		fill: we,
		stroke: "none"
	}, o = null;
	switch (e) {
		case "braincase":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M20 24 q0-4 4-4 h16 q4 0 4 4 v24 q0 6-6 6 h-12 q-6 0-6-6 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M17 20 v-4 q0-2 2-2 h26 q2 0 2 2 v4 z",
					...n
				}),
				/* @__PURE__ */ g("circle", {
					cx: "32",
					cy: "9.5",
					r: "2",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M25 40 q-3-6 2-9 q-1-4 4-5 q4-1 5 2 q4-1 6 3 q2 4-1 8 q0 4-5 5 h-7 q-4-1-4-4 z",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M30 32 q3 2 1 7 M36 31 q-2 3 0 7",
					...i
				})
			] });
			break;
		case "investigators":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("circle", {
					cx: "27",
					cy: "27",
					r: "13",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M37 37 L48 48",
					...n,
					strokeWidth: 4.2
				}),
				/* @__PURE__ */ g("path", {
					d: "M21 24 q2-4 6-4",
					...r
				})
			] });
			break;
		case "deepones":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M12 34 q10-15 27-11 q10 2 13 9 q-2 9-13 12 q-17 4-27-10 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M34 26 q-4 8 0 15",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M12 34 q4 3 9 3",
					...r
				}),
				/* @__PURE__ */ g("circle", {
					cx: "22",
					cy: "31",
					r: "2.4",
					...a
				}),
				/* @__PURE__ */ g("path", {
					d: "M24 22 q5-7 12-5",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M51 29 l7-6 M51 35 l7 6",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M44 44 q4 4 9 3",
					...i
				})
			] });
			break;
		case "cats":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M19 22 l-3-10 l11 6 M45 22 l3-10 l-11 6",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M16 27 q0-9 16-9 q16 0 16 9 q0 15-16 17 q-16-2-16-17 z",
					...n
				}),
				/* @__PURE__ */ g("circle", {
					cx: "25",
					cy: "31",
					r: "2.4",
					...a
				}),
				/* @__PURE__ */ g("circle", {
					cx: "39",
					cy: "31",
					r: "2.4",
					...a
				}),
				/* @__PURE__ */ g("path", {
					d: "M32 35 v3 M32 38 q-1 3-5 2 M32 38 q1 3 5 2",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M11 33 h6 M12 38 l6-2 M53 33 h-6 M52 38 l-6-2",
					...i
				})
			] });
			break;
		case "goldenmead":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M20 11 h24 q0 16-8 20 v9 h6 v6 h-20 v-6 h6 v-9 q-8-4-8-20 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M22 19 h20",
					...r
				}),
				/* @__PURE__ */ g("circle", {
					cx: "28",
					cy: "15",
					r: "1.3",
					...a
				}),
				/* @__PURE__ */ g("circle", {
					cx: "36",
					cy: "14.5",
					r: "1.1",
					...a
				})
			] });
			break;
		case "greatrace":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M26 54 L30 26 q2-6 4 0 L38 54 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M26 54 q6 3 12 0",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M32 22 v-9",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M28 13 q4-3 8 0 q-4 3-8 0 z",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M31 24 q-8-2-10-10 M33 24 q8-2 10-10",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M21 14 l-3-2 M21 14 l-1-4 M43 14 l3-2 M43 14 l1-4",
					...i
				}),
				/* @__PURE__ */ g("path", {
					d: "M29 40 h6 M28 46 h8",
					...i
				})
			] });
			break;
		case "hound":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M16 23 l11-8 h10 l11 8 l-3 18 l-13 9 l-13-9 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M23 15 l-3-7 l9 5 M41 15 l3-7 l-9 5",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M23 30 l7 2 M41 30 l-7 2",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M32 34 v8 M27 47 l5-5 5 5",
					...r
				})
			] });
			break;
		case "eldersign":
			o = /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("path", {
				d: "M32 55 V15",
				...n
			}), /* @__PURE__ */ g("path", {
				d: "M32 23 L20 15 M32 23 L44 15 M32 33 L17 28 M32 33 L47 28 M32 43 L22 50 M32 43 L42 50",
				...r
			})] });
			break;
		case "liber":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M16 14 h26 q6 0 6 6 v28 q0-6-6-6 h-26 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M16 14 v30 M16 44 q0 6 6 6 h26",
					...r
				}),
				/* @__PURE__ */ g("rect", {
					x: "30",
					y: "24",
					width: "12",
					height: "8",
					rx: "1.5",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M33 28 h6",
					...i
				})
			] });
			break;
		case "armitage":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M12 22 l20-8 20 8 l-20 8 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M23 26 v7 q9 6 18 0 v-7",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M48 24 v9",
					...r
				}),
				/* @__PURE__ */ g("circle", {
					cx: "48",
					cy: "35",
					r: "1.6",
					...a
				}),
				/* @__PURE__ */ g("circle", {
					cx: "25",
					cy: "46",
					r: "5.5",
					...r
				}),
				/* @__PURE__ */ g("circle", {
					cx: "39",
					cy: "46",
					r: "5.5",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M30.5 46 h3",
					...r
				})
			] });
			break;
		case "migo":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("ellipse", {
					cx: "32",
					cy: "36",
					rx: "9",
					ry: "14",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M25 30 q-13-7-15 5 q8 5 15 1 M39 30 q13-7 15 5 q-8 5-15 1",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M28 23 q-2-8-8-9 M36 23 q2-8 8-9",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M26 47 l-6 7 M32 49 v7 M38 47 l6 7",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M29 34 h6 M28 40 h8",
					...i
				})
			] });
			break;
		case "randolph":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M40 12 q-16 4-16 20 q0 16 16 20 q-6-4-6-20 q0-16 6-20 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M44 20 l1.5 4 4 1.5 -4 1.5 -1.5 4 -1.5-4 -4-1.5 4-1.5 z",
					...a
				}),
				/* @__PURE__ */ g("circle", {
					cx: "50",
					cy: "37",
					r: "1.4",
					...a
				})
			] });
			break;
		case "nyarlathotep":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M10 32 q22-20 44 0 q-22 20-44 0 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M33.2 25.1 a7 7 0 0 1 5.4 9.3 M36.5 37.4 a7 7 0 0 1-10.6-1.9 M25.1 33.2 a7 7 0 0 1 5.7-8.1",
					...r
				}),
				/* @__PURE__ */ g("circle", {
					cx: "32",
					cy: "32",
					r: "2.6",
					...a
				}),
				/* @__PURE__ */ g("path", {
					d: "M32 15 v-5 M18 20 l-3.5-3.5 M46 20 l3.5-3.5",
					...r
				})
			] });
			break;
		case "silverkey":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("circle", {
					cx: "22",
					cy: "22",
					r: "9",
					...n
				}),
				/* @__PURE__ */ g("circle", {
					cx: "22",
					cy: "22",
					r: "3.2",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M29 29 L48 48",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M41 41 l5-5 M45 45 l5-5",
					...r
				})
			] });
			break;
		case "trapezohedron":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M32 9 L49 26 L43 51 L21 51 L15 26 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M32 9 L32 30 L49 26 M32 30 L15 26 M32 30 L21 51 M32 30 L43 51",
					...i
				}),
				/* @__PURE__ */ g("path", {
					d: "M52 12 q1 4 4 5 q-3 1-4 5 q-1-4-4-5 q3-1 4-5 z",
					...a
				})
			] });
			break;
		case "necronomicon":
			o = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M16 12 h26 q6 0 6 6 v30 q0-6-6-6 h-26 z",
					...n
				}),
				/* @__PURE__ */ g("path", {
					d: "M16 12 v32 M16 44 q0 6 6 6 h26",
					...r
				}),
				/* @__PURE__ */ g("path", {
					d: "M23 26 q9-8 18 0 q-9 8-18 0 z",
					...r
				}),
				/* @__PURE__ */ g("circle", {
					cx: "32",
					cy: "26",
					r: "2.4",
					...a
				})
			] });
			break;
		case "cthulhu": o = /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "M18 28 q-3-16 14-18 q17 2 14 18",
				...n
			}),
			/* @__PURE__ */ g("path", {
				d: "M18 28 q14-7 28 0",
				...n
			}),
			/* @__PURE__ */ g("circle", {
				cx: "26",
				cy: "22",
				r: "2.4",
				...a
			}),
			/* @__PURE__ */ g("circle", {
				cx: "38",
				cy: "22",
				r: "2.4",
				...a
			}),
			/* @__PURE__ */ g("path", {
				d: "M22 28 q-3 10 1 17 q3 5 4-1 M28 29 q-2 11 2 19 M36 29 q2 11-2 19 M42 28 q3 10-1 17 q-3 5-4-1",
				...r
			})
		] });
	}
	return /* @__PURE__ */ g("svg", {
		width: t,
		height: t,
		viewBox: "0 0 64 64",
		"aria-hidden": !0,
		children: o
	});
}
function Ee({ size: e = 14 }) {
	return /* @__PURE__ */ _("svg", {
		width: e,
		height: e,
		viewBox: "0 0 16 16",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ g("circle", {
				cx: "8",
				cy: "8",
				r: "7",
				fill: k
			}),
			/* @__PURE__ */ g("path", {
				d: "M3.5 8 q4.5-4.5 9 0 q-4.5 4.5-9 0 z",
				fill: "#fff"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "8",
				cy: "8",
				r: "1.8",
				fill: k
			})
		]
	});
}
var De = `color-mix(in srgb, ${A.accent} 12%, #fff)`, Oe = `color-mix(in srgb, ${k} 12%, #fff)`;
function X({ card: e, size: t, selected: n, elevated: r }) {
	let i = s(), a = w[e], o = t === "hand";
	return /* @__PURE__ */ _("span", {
		"aria-label": i(D[e]),
		className: `lcl-card lcl-card-${t} relative inline-flex flex-none flex-col items-stretch border-ink bg-surface ${Ce[t]} ${r ? "shadow-[2px_2px_0_var(--color-ink)]" : ""} ${n ? "-translate-y-2" : ""}`,
		style: n ? {
			borderColor: A.accent,
			boxShadow: `4px 4px 0 ${A.accent}`
		} : void 0,
		children: [
			o && /* @__PURE__ */ g("span", {
				"aria-hidden": !0,
				className: "pointer-events-none absolute inset-1 rounded-[4px] border border-ink/20"
			}),
			/* @__PURE__ */ g("span", {
				className: `lcl-card-value absolute ${o ? "top-1 left-1" : "top-0.5 left-0.5"}`,
				children: /* @__PURE__ */ g("span", {
					className: `grid place-items-center rounded-full border-ink font-mono leading-none font-extrabold tabular-nums text-white ${o ? "size-7 border-2 text-base" : "size-5 border-2 text-[10px]"}`,
					style: { background: A.accent },
					children: a.value
				})
			}),
			a.insane && /* @__PURE__ */ g("span", {
				"aria-hidden": !0,
				className: `lcl-card-insane absolute ${o ? "top-1.5 right-1.5" : "top-0.5 right-0.5"}`,
				children: /* @__PURE__ */ g(Ee, { size: o ? 14 : 10 })
			}),
			/* @__PURE__ */ g("span", {
				className: `lcl-card-art relative flex flex-1 items-end justify-center ${o ? "pb-2.5" : "pb-1"}`,
				children: /* @__PURE__ */ g("span", {
					className: "lcl-card-emblem grid place-items-center rounded-full",
					style: {
						background: a.insane ? Oe : De,
						width: o ? 64 : 24,
						height: o ? 64 : 24
					},
					children: /* @__PURE__ */ g(Te, {
						card: e,
						size: o ? 52 : 20
					})
				})
			}),
			o && /* @__PURE__ */ g("span", {
				className: "lcl-card-title relative truncate border-t-2 border-ink/15 px-1 py-0.5 text-center text-xs leading-tight font-bold",
				style: { background: a.insane ? Oe : De },
				children: i(D[e])
			}),
			n && /* @__PURE__ */ g("span", {
				className: "absolute top-0.5 right-0.5 grid size-4 place-items-center rounded-full border-2 border-ink text-white",
				style: { background: A.accent },
				children: /* @__PURE__ */ g(c, { size: 10 })
			})
		]
	});
}
function ke() {
	return /* @__PURE__ */ _("span", {
		className: "lcl-card-back relative inline-flex flex-none items-center justify-center overflow-hidden rounded border border-ink h-14 w-11",
		style: { background: A.accent },
		children: [/* @__PURE__ */ g("svg", {
			className: "absolute inset-0 size-full",
			viewBox: "0 0 44 64",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: /* @__PURE__ */ g("path", {
				d: "M-10 16 L54 -12 M-10 36 L54 8 M-10 56 L54 28 M-10 76 L54 48",
				stroke: "#ffffff",
				strokeWidth: 5,
				opacity: .14,
				fill: "none"
			})
		}), /* @__PURE__ */ g("svg", {
			className: "lcl-back-emblem",
			width: 20,
			height: 20,
			viewBox: "0 0 64 64",
			"aria-hidden": !0,
			children: /* @__PURE__ */ _("g", {
				fill: "none",
				stroke: "#ffffff",
				strokeWidth: 4,
				strokeLinecap: "round",
				opacity: .9,
				children: [/* @__PURE__ */ g("path", { d: "M18 8 q14-8 28 0" }), /* @__PURE__ */ g("path", { d: "M20 20 q-4 16 2 30 M28 24 q-2 16 2 28 M36 24 q2 16-2 28 M44 20 q4 16-2 30" })]
			})
		})]
	});
}
//#endregion
//#region src/games/lovecraftletter/view-player.tsx
function Ae(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ g(Ne, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function je(e, t, n) {
	let r = e.players.filter((e) => e.rid !== t && !e.out && !e.protected).map((e) => e.rid);
	return n === "any" ? [t, ...r] : r;
}
function Me(e, t) {
	return e.filter((n, r) => n !== "silverkey" && (n !== "trapezohedron" || t) ? !1 : e.some((e, t) => t !== r && w[e].value > 4));
}
function Ne({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let c = s(), l = (e) => n.find((t) => t.rid === e)?.name ?? e, { ref: u } = o("table"), d = e.players.find((e) => e.rid === r)?.insane ?? !1, v = e.phase === "play" && e.pending && e.pending.rid === r ? e.pending : null, y = e.phase === "play" && !e.pending && e.turn === r, b = y || v !== null && v.kind !== "nyarlathotep", x = v?.kind === "nyarlathotep", S = t?.hand ?? [], [C, T] = i(null), [E, k] = i(!1), [j, M] = i(null), [N, P] = i(null), [F, I] = i({}), [L, R] = i(null), [te, ne] = i(!1), re = `${e.round}|${e.turn}|${e.pending?.kind ?? ""}|${e.pending?.rid ?? ""}`, [ie, ae] = i(re);
	ie !== re && (ae(re), T(null), k(!1), M(null), P(null), I({}), R(null));
	let oe = JSON.stringify(t?.reveal ?? null), [z, B] = i(oe);
	z !== oe && (B(oe), ne(!1));
	let V = b ? Me(S, d) : [], H = C ? w[C] : null, U = H ? E && H.insane ? H.insaneTarget : H.target : "none", se = C && U !== "none" ? je(e, r, U) : [], W = C !== null && U !== "none" && se.length > 0, ce = C !== null && w[C].guess && !E && j !== null, G = C !== null && w[C].guess && j !== null, K = C !== null && (!W || j !== null) && (!ce || N !== null), q = () => {
		C && K && (a({
			type: v ? "followup" : "play",
			card: C,
			...E ? { insane: !0 } : {},
			...W && j ? { target: j } : {},
			...G && N ? { guess: N } : {}
		}), T(null), k(!1), M(null), P(null));
	}, le = t?.nyarlPool ?? null, ue = le ? Object.values(le).filter((e) => !Object.values(F).includes(e)) : [], de = e.pending?.kind === "nyarlathotep" ? e.pending.rids : [], fe = de.length > 0 && de.every((e) => F[e]), J, Y;
	return e.phase === "roundEnd" || e.phase === "done" ? (J = "info", Y = c("games.lovecraftletter.roundEnding")) : e.phase === "settle" ? (J = "info", Y = e.last?.kind === "sanity" ? c("games.lovecraftletter.sanityChecking", { name: l(e.last.rid) }) : c("games.lovecraftletter.resolving", { name: l(e.turn ?? e.pending?.rid ?? "") })) : v?.kind === "mead" ? (J = "accent", Y = c("games.lovecraftletter.meadPrompt")) : v?.kind === "migo" ? (J = "accent", Y = c("games.lovecraftletter.migoPrompt")) : x ? (J = "accent", Y = c("games.lovecraftletter.nyarlPrompt")) : e.pending ? (J = "info", Y = c("games.lovecraftletter.resolving", { name: l(e.pending.rid) })) : y ? (J = "accent", Y = c("games.lovecraftletter.yourTurn")) : (J = "info", Y = c("games.lovecraftletter.waiting", { name: l(e.turn ?? "") })), /* @__PURE__ */ g(p, {
		adaptive: !0,
		scroll: !1,
		className: "lcl-screen",
		banner: /* @__PURE__ */ g(m, {
			tone: J,
			text: Y,
			chip: c("games.lovecraftletter.roundChip", { n: e.round }),
			accent: A.accent
		}),
		actionsHeight: t ? "lcl-actions-height" : void 0,
		actions: t ? /* @__PURE__ */ g("div", {
			className: "lcl-actions flex items-center gap-2 px-2",
			"data-assigning": x || void 0,
			children: x && le ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("div", {
				className: "lcl-hand flex items-center gap-1.5",
				children: ue.map((e, t) => /* @__PURE__ */ g("button", {
					type: "button",
					"aria-label": c(D[e]),
					onClick: () => R((t) => t === e ? null : e),
					className: "flex-none transition-transform active:translate-y-0.5",
					children: /* @__PURE__ */ g(X, {
						card: e,
						size: "hand",
						elevated: !0,
						selected: L === e
					})
				}, `${e}:${t}`))
			}), /* @__PURE__ */ _("div", {
				className: "lcl-action-side flex min-w-0 flex-1 flex-col items-center justify-center gap-1.5 self-stretch",
				children: [/* @__PURE__ */ g("div", {
					className: "min-h-0 w-full flex-1 overflow-y-auto",
					children: /* @__PURE__ */ g("p", {
						className: "text-center text-xs leading-4.5 text-ink/70",
						children: c("games.lovecraftletter.nyarlPrompt")
					})
				}), /* @__PURE__ */ g("button", {
					type: "button",
					disabled: !fe,
					onClick: () => a({
						type: "nyarlAssign",
						deal: F
					}),
					className: "btn-base min-h-12 px-6",
					style: { background: A.accent },
					children: c("games.lovecraftletter.nyarlConfirm")
				})]
			})] }) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("div", {
				className: "lcl-hand flex items-center gap-1.5",
				children: S.map((e, t) => {
					let n = !b || V.length > 0 && !V.includes(e);
					return /* @__PURE__ */ g("button", {
						type: "button",
						disabled: n,
						"aria-label": b ? c("games.lovecraftletter.playCardAria", { card: c(D[e]) }) : c(D[e]),
						onClick: () => {
							T((t) => t === e ? null : e), k(!1), M(null), P(null);
						},
						className: "flex-none transition-transform active:translate-y-0.5 disabled:opacity-50",
						children: /* @__PURE__ */ g(X, {
							card: e,
							size: "hand",
							elevated: !0,
							selected: C === e
						})
					}, `${e}:${t}`);
				})
			}), /* @__PURE__ */ g("div", {
				className: "lcl-action-side flex min-w-0 flex-1 flex-col items-center justify-center gap-1.5 self-stretch",
				children: b && C && H && /* @__PURE__ */ _(h, { children: [
					H.insane && d ? /* @__PURE__ */ g("div", {
						className: "lcl-mode-options flex flex-none items-center gap-1.5",
						children: [!1, !0].map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							"aria-pressed": E === e,
							onClick: () => {
								k(e), M(null), P(null);
							},
							className: `min-h-11 rounded-lg border-2 border-ink px-3 text-xs font-bold ${E === e ? "text-white" : "bg-surface"}`,
							style: E === e ? { background: e ? "#15803d" : A.accent } : void 0,
							children: c(e ? "games.lovecraftletter.modeInsane" : "games.lovecraftletter.modeSane")
						}, e ? "insane" : "sane"))
					}) : /* @__PURE__ */ g("p", {
						className: "flex flex-none items-center gap-1 text-xs leading-4 font-bold text-ink/70",
						children: /* @__PURE__ */ g("span", {
							className: "text-ink",
							children: c(D[C])
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "min-h-0 w-full flex-1 overflow-y-auto",
						children: /* @__PURE__ */ g("p", {
							className: "text-center text-xs leading-4.5 text-ink/70",
							children: c(W && !j ? "games.lovecraftletter.selectTarget" : E && H.insane ? ee[C] : O[C])
						})
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						disabled: !K,
						onClick: q,
						className: "btn-base min-h-12 flex-none px-6",
						style: { background: A.accent },
						children: c("games.lovecraftletter.confirm")
					})
				] })
			})] })
		}) : void 0,
		overlay: /* @__PURE__ */ _(h, { children: [t?.reveal && !te && /* @__PURE__ */ g("div", {
			className: "pointer-events-auto mx-2 mb-2",
			children: /* @__PURE__ */ g(Pe, {
				reveal: t.reveal,
				nameOf: l,
				onClose: () => ne(!0)
			})
		}), b && G && /* @__PURE__ */ _("div", {
			className: "lcl-guess pointer-events-auto mx-2 mb-2 flex flex-col items-center gap-1.5 rounded-xl border-2 border-ink bg-surface p-2 shadow-[3px_3px_0_var(--color-ink)]",
			children: [/* @__PURE__ */ g("p", {
				className: "text-xs font-bold text-ink/60",
				children: c("games.lovecraftletter.selectGuess", { name: l(j ?? "") })
			}), /* @__PURE__ */ g("div", {
				className: "flex flex-wrap items-center justify-center gap-1.5",
				children: [
					2,
					3,
					4,
					5,
					6,
					7,
					8
				].map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					onClick: () => P((t) => t === e ? null : e),
					"aria-pressed": N === e,
					"aria-label": c("games.lovecraftletter.guessAria", { n: e }),
					className: `grid size-11 place-items-center rounded-lg border-2 border-ink bg-surface font-mono text-base font-extrabold tabular-nums ${N === e ? "text-white" : ""}`,
					style: N === e ? {
						background: A.accent,
						borderColor: A.accent
					} : void 0,
					children: e
				}, e))
			})]
		})] }),
		children: /* @__PURE__ */ _("div", {
			ref: u,
			className: "lcl-table frame relative flex min-h-0 flex-1 flex-col overflow-hidden",
			children: [/* @__PURE__ */ g(f, {
				kind: "sheen",
				base: "#f2eefb",
				className: "absolute inset-0 size-full"
			}), /* @__PURE__ */ g("div", {
				className: "lcl-table-content relative flex min-h-0 w-full flex-1 flex-col gap-2 p-3",
				children: e.phase === "play" || e.phase === "settle" ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("div", {
					className: "lcl-intel",
					children: [/* @__PURE__ */ g(Fe, { pub: e }), /* @__PURE__ */ g(Ie, {
						log: e.log,
						nameOf: l
					})]
				}), /* @__PURE__ */ g(ze, {
					pub: e,
					members: n,
					picking: W ? {
						eligible: se,
						target: j,
						onPick: (e) => M((t) => t === e ? null : e)
					} : x && L ? {
						eligible: de,
						target: null,
						onPick: (e) => {
							I((t) => {
								let n = Object.fromEntries(Object.entries(t).filter(([, e]) => e !== L));
								return n[e] = L, n;
							}), R(null);
						}
					} : null,
					assign: x ? F : null
				})] }) : /* @__PURE__ */ g(He, {
					pub: e,
					nameOf: l
				})
			})]
		})
	});
}
function Pe({ reveal: e, nameOf: t, onClose: n }) {
	let r = s(), i = e.kind === "look" ? r("games.lovecraftletter.revealLook", {
		name: t(e.target),
		card: r(D[e.card])
	}) : e.iWon === null ? r("games.lovecraftletter.revealCompareTie", {
		name: t(e.opponent),
		card: r(D[e.theirCard])
	}) : r(e.iWon ? "games.lovecraftletter.revealCompareWin" : "games.lovecraftletter.revealCompareLose", {
		name: t(e.opponent),
		card: r(D[e.theirCard])
	});
	return /* @__PURE__ */ _("div", {
		className: "lcl-reveal flex items-center gap-2 rounded-xl border-2 border-ink bg-info-soft px-3 py-1.5 text-sm font-bold",
		children: [
			/* @__PURE__ */ g(u, {
				size: 16,
				className: "flex-none"
			}),
			/* @__PURE__ */ g("span", {
				className: "min-w-0 flex-1",
				children: i
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				onClick: n,
				"aria-label": r("games.lovecraftletter.dismiss"),
				className: "grid size-8 flex-none place-items-center",
				children: /* @__PURE__ */ g(l, { size: 16 })
			})
		]
	});
}
function Fe({ pub: e }) {
	let t = s(), { ref: n } = o("deck");
	return /* @__PURE__ */ _("div", {
		className: "lcl-deck flex flex-none items-center gap-1.5",
		children: [
			/* @__PURE__ */ _("span", {
				ref: n,
				className: "lcl-deck-anchor relative",
				"aria-label": t("games.lovecraftletter.deckAria", { n: e.deckCount }),
				children: [/* @__PURE__ */ g(ke, {}), /* @__PURE__ */ g("span", {
					className: "lcl-deck-count absolute -right-1.5 -bottom-1.5 grid size-6 place-items-center rounded-full border-2 border-ink bg-surface font-mono text-xs leading-none font-extrabold tabular-nums",
					children: e.deckCount
				})]
			}),
			/* @__PURE__ */ g("span", {
				"aria-label": t("games.lovecraftletter.burnDownAria"),
				children: /* @__PURE__ */ g(ke, {})
			}),
			e.burnUp.map((e, n) => /* @__PURE__ */ g("span", {
				"aria-label": t("games.lovecraftletter.burnUpAria"),
				children: /* @__PURE__ */ g(X, {
					card: e,
					size: "small"
				})
			}, `${e}:${n}`)),
			e.braincaseAside && /* @__PURE__ */ g("span", {
				"aria-label": t("games.lovecraftletter.braincaseAsideAria"),
				className: "opacity-80",
				children: /* @__PURE__ */ g(X, {
					card: "braincase",
					size: "small"
				})
			})
		]
	});
}
function Ie({ log: e, nameOf: t }) {
	let i = s(), a = r(null);
	return n(() => {
		let e = a.current;
		e && (e.scrollTop = e.scrollHeight);
	}, [e.length]), /* @__PURE__ */ g("ul", {
		ref: a,
		"aria-label": i("games.lovecraftletter.logAria"),
		className: "lcl-log flex h-24 flex-none flex-col gap-0.5 overflow-y-auto rounded-lg border border-ink/15 px-2 py-1",
		children: e.map((e, n) => /* @__PURE__ */ g(Le, {
			entry: e,
			nameOf: t
		}, n))
	});
}
function Le({ entry: e, nameOf: t }) {
	let n = s();
	if (e.kind === "round") return /* @__PURE__ */ _("li", {
		className: "py-0.5 text-center text-[11px] leading-4 font-extrabold text-ink/50",
		children: [
			"—— ",
			n("games.lovecraftletter.logRound", { n: e.n }),
			" ——"
		]
	});
	if (e.kind === "sanity") {
		let r = e.failed ? e.survived ? "games.lovecraftletter.sanityLineFailImmune" : "games.lovecraftletter.sanityLineFail" : "games.lovecraftletter.sanityLinePass";
		return /* @__PURE__ */ _("li", {
			className: `text-xs leading-4.5 ${e.failed ? "font-bold text-ink/80" : "text-ink/70"}`,
			children: [n(r, { name: t(e.rid) }), e.revealed.length > 0 ? ` (${e.revealed.map((e) => n(D[e])).join("、")})` : ""]
		});
	}
	if (e.kind === "cthulhuWin") return /* @__PURE__ */ g("li", {
		className: "text-xs leading-4.5 font-bold text-ink/80",
		children: n("games.lovecraftletter.cthulhuWinLine", { name: t(e.rid) })
	});
	if (e.kind === "roundEnd") {
		let r = e.winner ? n(e.insane ? "games.lovecraftletter.roundWinInsane" : "games.lovecraftletter.roundWinSane", { name: t(e.winner) }) : n("games.lovecraftletter.roundNoWin");
		return /* @__PURE__ */ g("li", {
			className: "text-xs leading-4.5 font-bold text-ink/80",
			children: r
		});
	}
	let r = e.target && e.guess !== null ? n("games.lovecraftletter.playLineGuess", {
		name: t(e.rid),
		target: t(e.target),
		guess: e.guess
	}) : e.target ? n(e.insane ? "games.lovecraftletter.playLineTargetInsane" : "games.lovecraftletter.playLineTarget", {
		name: t(e.rid),
		target: t(e.target),
		card: n(D[e.card])
	}) : n(e.insane ? "games.lovecraftletter.playLineInsane" : "games.lovecraftletter.playLine", {
		name: t(e.rid),
		card: n(D[e.card])
	});
	return /* @__PURE__ */ _("li", {
		className: "text-xs leading-4.5 text-ink/70",
		children: [r, e.outRid ? ` ${n("games.lovecraftletter.playLineOut", { name: t(e.outRid) })}` : ""]
	});
}
function Re() {
	return /* @__PURE__ */ g("svg", {
		"aria-hidden": !0,
		className: "lcl-ants pointer-events-none absolute inset-0 size-full",
		children: /* @__PURE__ */ g("rect", {
			style: {
				x: 1,
				y: 1,
				width: "calc(100% - 2px)",
				height: "calc(100% - 2px)"
			},
			rx: "10",
			fill: "none",
			stroke: A.accent,
			strokeWidth: "2",
			strokeDasharray: "6 4",
			children: /* @__PURE__ */ g("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-20",
				dur: "0.6s",
				repeatCount: "indefinite"
			})
		})
	});
}
function ze({ pub: e, members: t, picking: n, assign: r }) {
	let i = s();
	return /* @__PURE__ */ g("ul", {
		className: "lcl-players flex flex-1 flex-col gap-1.5",
		"data-count": e.players.length,
		children: e.players.map((o) => {
			let s = t.find((e) => e.rid === o.rid), c = d[(s?.colorIndex ?? 0) % d.length], l = e.turn === o.rid || e.pending?.rid === o.rid, u = n !== null && !o.out && n.eligible.includes(o.rid), f = n?.target === o.rid, p = o.out || n !== null && !u, m = /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g(Be, {
					rid: o.rid,
					children: /* @__PURE__ */ g("img", {
						src: a[(s?.avatar ?? 0) % a.length],
						alt: "",
						draggable: !1,
						className: "lcl-avatar size-8 flex-none rounded-full border-2 border-ink object-contain",
						style: {
							backgroundColor: c.hex,
							...l ? { boxShadow: `0 0 0 3px ${A.accent}` } : void 0
						}
					})
				}),
				/* @__PURE__ */ _("span", {
					className: "lcl-identity flex w-20 flex-none flex-col gap-0.5",
					children: [
						/* @__PURE__ */ g("span", {
							className: "lcl-player-name truncate text-sm leading-5 font-bold",
							title: s?.name ?? o.rid,
							children: s?.name ?? o.rid
						}),
						/* @__PURE__ */ _("span", {
							className: "lcl-player-flags flex items-center gap-1 text-xs leading-4 font-bold",
							children: [
								/* @__PURE__ */ _("span", {
									"aria-label": i("games.lovecraftletter.tokensAria", {
										sane: o.tokensSane,
										insane: o.tokensInsane
									}),
									className: "flex items-center gap-0.5",
									children: [Array.from({ length: o.tokensSane }, (e, t) => /* @__PURE__ */ g("span", {
										className: "inline-block size-3 rounded-full border border-ink",
										style: { background: A.accent },
										"aria-label": i("games.lovecraftletter.saneToken")
									}, `s${t}`)), Array.from({ length: o.tokensInsane }, (e, t) => /* @__PURE__ */ g("span", {
										className: "inline-block size-3 rounded-full border border-ink",
										style: { background: k },
										"aria-label": i("games.lovecraftletter.insaneToken")
									}, `i${t}`))]
								}),
								o.insane && !o.out && /* @__PURE__ */ g("span", {
									className: "rounded-full border border-ink px-1 text-[10px] leading-3.5 font-bold text-white",
									style: { background: "#15803d" },
									children: i("games.lovecraftletter.insaneBadge")
								}),
								o.koImmune && !o.out && /* @__PURE__ */ g("span", {
									className: "rounded-full border border-ink bg-sky-400 px-1 text-[10px] leading-3.5 font-bold text-white",
									children: i("games.lovecraftletter.koImmuneBadge")
								}),
								o.protected && /* @__PURE__ */ g("span", {
									className: "sr-only",
									children: i("games.lovecraftletter.protectedAria")
								}),
								o.out && /* @__PURE__ */ g("span", {
									role: "img",
									"aria-label": i("games.lovecraftletter.outAria"),
									children: "💔"
								})
							]
						}),
						r?.[o.rid] && /* @__PURE__ */ _("span", {
							className: "text-[10px] leading-3.5 font-bold",
							style: { color: "#15803d" },
							children: ["← ", i(D[r[o.rid]])]
						})
					]
				}),
				/* @__PURE__ */ g("span", {
					className: "lcl-discards flex min-w-0 flex-1 items-center",
					"aria-label": i("games.lovecraftletter.discardsAria", { name: s?.name ?? o.rid }),
					children: o.discards.length === 0 ? /* @__PURE__ */ g("span", {
						"aria-hidden": !0,
						className: "lcl-empty-discard h-14 w-11 rounded-md border border-dashed border-ink/30"
					}) : o.discards.map((e, t) => /* @__PURE__ */ g("span", {
						className: "lcl-discard-slot",
						children: t === o.discards.length - 1 ? /* @__PURE__ */ g(Ve, {
							rid: o.rid,
							children: /* @__PURE__ */ g(X, {
								card: e,
								size: "small"
							})
						}) : /* @__PURE__ */ g(X, {
							card: e,
							size: "small"
						})
					}, `${e}:${t}`))
				})
			] }), v = `lcl-player relative flex w-full items-center gap-2 rounded-xl border-2 p-1 text-left ${f ? "" : o.protected ? "border-sky-400" : "border-transparent"} ${p ? "opacity-40" : ""}`;
			return /* @__PURE__ */ g("li", { children: u ? /* @__PURE__ */ _("button", {
				type: "button",
				"aria-pressed": f,
				onClick: () => n.onPick(o.rid),
				className: v,
				style: f ? { borderColor: A.accent } : void 0,
				children: [!f && /* @__PURE__ */ g(Re, {}), m]
			}) : /* @__PURE__ */ g("div", {
				className: v,
				children: m
			}) }, o.rid);
		})
	});
}
function Be({ rid: e, children: t }) {
	let { ref: n } = o(`disc:${e}`);
	return /* @__PURE__ */ g("span", {
		ref: n,
		className: "flex flex-none items-center",
		children: t
	});
}
function Ve({ rid: e, children: t }) {
	let { ref: n, hidden: r } = o(`discTop:${e}`);
	return /* @__PURE__ */ g("span", {
		ref: n,
		className: `flex flex-none items-center ${r ? "opacity-0" : ""}`,
		children: t
	});
}
function He({ pub: e, nameOf: t }) {
	let n = s(), r = e.last?.kind === "roundEnd" ? e.last : null, i = e.last?.kind === "cthulhuWin" ? e.last : null;
	return /* @__PURE__ */ _("div", {
		className: "lcl-summary flex flex-1 flex-col items-center justify-center gap-3 py-2 text-center",
		children: [i ? /* @__PURE__ */ g("p", {
			className: "font-display text-2xl font-extrabold",
			children: n("games.lovecraftletter.cthulhuWinLine", { name: t(i.rid) })
		}) : /* @__PURE__ */ _(h, { children: [r && /* @__PURE__ */ g("p", {
			className: "text-sm font-bold text-ink/60",
			children: n(r.reason === "deckOut" ? "games.lovecraftletter.reasonDeckOut" : r.reason === "trap" ? "games.lovecraftletter.reasonTrap" : "games.lovecraftletter.reasonLastStanding")
		}), /* @__PURE__ */ g("p", {
			className: "font-display text-2xl font-extrabold",
			children: r?.winner ? n(r.insane ? "games.lovecraftletter.roundWinInsane" : "games.lovecraftletter.roundWinSane", { name: t(r.winner) }) : n("games.lovecraftletter.roundNoWin")
		})] }), e.revealHands && /* @__PURE__ */ _("div", {
			className: "lcl-summary-hands flex flex-col items-center gap-1.5",
			children: [/* @__PURE__ */ g("p", {
				className: "section-label",
				children: n("games.lovecraftletter.handReveal")
			}), Object.entries(e.revealHands).map(([e, n]) => /* @__PURE__ */ _("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ g("span", {
					className: "w-16 truncate text-right text-sm font-bold",
					children: t(e)
				}), n.map((e, t) => /* @__PURE__ */ g(X, {
					card: e,
					size: "hand"
				}, `${e}:${t}`))]
			}, e))]
		})]
	});
}
//#endregion
//#region src/games/lovecraftletter/bot.ts
function Ue() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function We(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Z = {
	cthulhu: 100,
	necronomicon: 92,
	trapezohedron: 86,
	silverkey: 84,
	nyarlathotep: 74,
	randolph: 70,
	migo: 60,
	armitage: 55,
	liber: 52,
	eldersign: 46,
	hound: 46,
	greatrace: 40,
	goldenmead: 40,
	cats: 34,
	deepones: 30,
	investigators: 24,
	braincase: 0
};
function Ge(e, t, n) {
	let r = e.round === t.round ? {
		...e,
		seen: { ...e.seen }
	} : {
		round: t.round,
		seen: {},
		lastKey: ""
	}, i = t.last;
	if (i?.kind === "play") {
		let e = `${t.round}:${JSON.stringify(i)}`;
		if (e !== r.lastKey) {
			r.lastKey = e;
			let n = r.seen;
			if (n[i.rid] === i.card && (n[i.rid] = void 0), i.card === "goldenmead" && i.insane && (n[i.rid] = void 0), i.card === "migo" && i.insane && (n[i.rid] = void 0, i.target && i.outRid !== i.target && (n[i.target] = "braincase")), (i.card === "randolph" || i.card === "nyarlathotep" && !i.insane) && i.target) {
				let e = n[i.rid];
				n[i.rid] = n[i.target], n[i.target] = e;
			}
			if (i.card === "nyarlathotep" && i.insane) for (let e of t.players) e.rid !== i.rid && (n[e.rid] = void 0);
			(i.card === "armitage" || i.card === "migo") && !i.insane && i.target && i.outRid !== i.target && (n[i.target] = void 0);
		}
	}
	let a = n?.reveal;
	return a && (a.kind === "look" ? r.seen[a.target] = a.card : r.seen[a.opponent] = a.theirCard), r;
}
function Ke(e, t, n, r) {
	let i = /* @__PURE__ */ new Map();
	for (let e of E()) i.set(e, (i.get(e) ?? 0) + 1);
	let a = (e) => i.set(e, (i.get(e) ?? 0) - 1);
	for (let e of t?.hand ?? []) a(e);
	for (let t of e.players) for (let e of t.discards) a(e);
	for (let t of e.burnUp) a(t);
	for (let [e, t] of Object.entries(n)) e !== r && t && a(t);
	return i.set("braincase", 0), i;
}
function qe(e, t, n, r) {
	let i = n[e];
	if (i) return +(w[i].value === t);
	let a = 0, o = 0;
	for (let [e, n] of r) a += n, w[e].value === t && (o += n);
	return a > 0 ? o / a : 0;
}
function Je(e, t) {
	return e.phase === "play" ? e.pending ? e.pending.rid === t ? e.pending.kind === "nyarlathotep" ? "nyarl" : "followup" : null : e.turn === t ? "play" : null : null;
}
var Ye = (e, t) => {
	let n = e.public, r = e.private, i = n.players.find((e) => e.rid === t.rid);
	if (!i || i.out) return null;
	let a = Je(n, t.rid);
	if (!a) return null;
	let o = Ge(t.memory ?? {
		round: n.round,
		seen: {},
		lastKey: ""
	}, n, r), s = r?.hand ?? [];
	if (s.length === 0 && a !== "nyarl") return null;
	if (a === "nyarl") {
		let e = r?.nyarlPool;
		if (!e) return null;
		let i = Object.keys(e), a = i.map((t) => e[t]);
		if (t.difficulty === "weak") {
			let e = [...a];
			for (let t = e.length - 1; t > 0; --t) {
				let n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % (t + 1);
				[e[t], e[n]] = [e[n], e[t]];
			}
			return {
				action: {
					type: "nyarlAssign",
					deal: Object.fromEntries(i.map((t, n) => [t, e[n]]))
				},
				memory: o
			};
		}
		let s = (e) => e === "braincase" ? -100 : w[e].value, c = [...i].sort((e, t) => {
			let r = (n.players.find((t) => t.rid === e)?.tokensSane ?? 0) + (n.players.find((t) => t.rid === e)?.tokensInsane ?? 0);
			return (n.players.find((e) => e.rid === t)?.tokensSane ?? 0) + (n.players.find((e) => e.rid === t)?.tokensInsane ?? 0) - r;
		}), l = [...a].sort((e, t) => s(e) - s(t)), u = {};
		return c.forEach((e, t) => {
			u[e] = l[t], o.seen[e] = l[t];
		}), {
			action: {
				type: "nyarlAssign",
				deal: u
			},
			memory: o
		};
	}
	let c = n.players.filter((e) => e.rid !== t.rid && !e.out), l = c.filter((e) => !e.protected), u = i.insane, d = i.discards.filter((e) => w[e].insane).length, f = (e) => e === "any" ? [t.rid, ...l.map((e) => e.rid)] : l.map((e) => e.rid), p = s.filter((e, t) => (e === "silverkey" || e === "trapezohedron" && !u) && s.some((e, n) => n !== t && w[e].value > 4)), m = p.length > 0 ? p : s, h = (e, t, n, r) => ({
		type: a === "followup" ? "followup" : "play",
		card: e,
		...t ? { insane: !0 } : {},
		...n ? { target: n } : {},
		...r === void 0 ? {} : { guess: r }
	});
	if (t.difficulty === "weak") {
		let e = We(m), t = w[e].insane && u && Ue() < .5, n = t ? w[e].insaneTarget : w[e].target, r = n === "none" ? [] : f(n), i = r.length > 0 ? We(r) : void 0;
		return {
			action: h(e, t, i, w[e].guess && i ? 2 + crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 7 : void 0),
			memory: o
		};
	}
	let g = y(v(t.rid)), _ = () => (Ue() - .5) * g.noise * 1.6, b = Ke(n, r, o.seen, t.rid), x = (e, t) => qe(e, t, o.seen, b), S = (e) => {
		let t = 1;
		for (let n of c) {
			let r = 0;
			for (let t = 0; t < e; t += 1) r += x(n.rid, t);
			t *= r;
		}
		return t;
	}, C = n.deckCount <= c.length + 1 ? 1 : n.deckCount <= (c.length + 1) * 2 ? .5 : 0, T = (e) => {
		let t = n.players.find((t) => t.rid === e);
		return (t?.tokensSane ?? 0) + (t?.tokensInsane ?? 0);
	}, E = [...c].sort((e, t) => T(t.rid) - T(e.rid))[0], D = (e) => {
		let t = n.players.find((t) => t.rid === e);
		return !!t && (t.tokensSane >= 1 || t.tokensInsane >= 2);
	}, O = (e) => {
		if (e.length === 0) return;
		let t = e.filter(D);
		return t.length > 0 && g.aggression + Ue() * .5 > .35 ? We(t) : E && g.aggression + Ue() * .5 > .6 && e.includes(E.rid) ? E.rid : We(e);
	}, ee = (e) => {
		let t = e.filter((e) => !o.seen[e]);
		return O(t.length > 0 ? t : e);
	}, k = (e) => {
		if (e <= 0 || i.koImmune) return 0;
		let t = 0, r = 0;
		for (let [e, n] of b) t += n, (w[e].insane || e === "necronomicon") && (r += n);
		if (t <= 0 || r <= 0) return 0;
		let a = 1;
		for (let n = 0; n < e; n += 1) a *= Math.max(0, 1 - r / (t - n));
		let o = Math.max(1, n.deckCount / (c.length + 1));
		return 1 - a ** o;
	}, A = k(d), j = i.tokensSane >= 1 ? 2.2 : i.tokensInsane >= 2 ? .35 : i.tokensInsane === 1 ? .75 : 1, M = (e) => {
		if (!w[e].insane) return 0;
		let t = k(d + 1) - A;
		return t <= 0 ? 0 : -t * 4.5 * j * (1.25 - g.risk * .5);
	}, N = (e) => {
		let t = null;
		for (let n of e) {
			let e = 1 + +!!D(n) + (E?.rid === n ? .25 : 0);
			for (let r = 2; r <= 8; r += 1) {
				let i = x(n, r);
				(!t || i * e > t.wp) && (t = {
					target: n,
					guess: r,
					p: i,
					wp: i * e
				});
			}
		}
		return t;
	}, P = [];
	for (let e of m) {
		let r = s.find((t) => t !== e) ?? e, a = w[r].value, l = C > 0 ? S(a) * 2 * C : 0, p = w[e].insane && u ? [!1, !0] : [!1];
		for (let s of p) {
			let u = w[e], p = s ? u.insaneTarget : u.target, m = p === "none" ? [] : f(p), v = (t, n, r) => P.push({
				action: h(e, s, n, r),
				score: t + M(e) + _()
			});
			switch (e) {
				case "necronomicon":
				case "braincase":
					v(i.koImmune ? 1.2 : -999);
					break;
				case "cthulhu":
					v(s && d >= 2 ? 999 : i.koImmune ? 1.2 : -999);
					break;
				case "silverkey":
				case "trapezohedron":
					v(.3 + l);
					break;
				case "investigators":
				case "deepones": {
					if (s) {
						let e = m.filter((e) => x(e, 1) >= 1);
						if (e.length > 0) {
							v(1.2 + 6 * (.6 + g.aggression * .8), O(e));
							break;
						}
						let t = null;
						for (let e of m) {
							let n = x(e, 1), r = N([e]), i = n * 6 + (r ? r.p * 3 : 0);
							(!t || i > t.score) && (t = {
								target: e,
								guess: r?.guess,
								score: i
							});
						}
						t ? v(1.2 + t.score * (.6 + g.aggression * .8), t.target, t.guess) : v(.5);
						break;
					}
					if (m.length === 0) {
						v(.6 + l);
						break;
					}
					let e = N(m);
					if (!e) break;
					let t = .1 + (1 - g.risk) * .2;
					v((e.p > t ? 1.2 + e.p * 3 * (.6 + g.aggression * .8) : .5) + l, e.target, e.guess);
					break;
				}
				case "cats":
					v(1.1 + g.cunning * 1.3 + l, ee(m));
					break;
				case "goldenmead":
					v(s ? 2.4 + g.cunning * 1.2 + l * .5 : 1.1 + g.cunning * 1.3 + l, ee(m));
					break;
				case "greatrace":
				case "hound": {
					if (s) {
						let e = m.filter((e) => !(n.players.find((t) => t.rid === e)?.insane ?? !1)), t = O(e) ?? O(m);
						v(t && e.length > 0 ? 3.2 + g.aggression * 1.5 : .4, t);
						break;
					}
					if (m.length === 0) {
						v(.5 + l);
						break;
					}
					let e = -99, t;
					for (let n of m) {
						let r = 0, i = 0, o = 0;
						for (let e = 0; e <= 8; e += 1) {
							let t = x(n, e);
							e < a ? r += t : e > a ? i += t : o += t;
						}
						let s = 2 * (r + o * .25 - i * (.4 + g.risk)) + g.aggression * .5;
						D(n) && (s += r * 1.2), s > e && (e = s, t = n);
					}
					v(e - l * .8, t);
					break;
				}
				case "eldersign":
					v(1 + Z[r] / 60 + Math.max(0, c.length - 2) * .2 + l);
					break;
				case "liber":
					if (s) {
						if (i.koImmune) {
							v(.2);
							break;
						}
						v(1 + (Z[r] === 0 || r === "necronomicon" || r === "cthulhu" ? 1.6 : 0) + d * .3);
					} else v(1 + Z[r] / 60 + Math.max(0, c.length - 2) * .2 + l);
					break;
				case "armitage":
				case "migo": {
					if (s) {
						if (!n.braincaseAside) {
							v(.1);
							break;
						}
						let e = m.filter((e) => o.seen[e] !== "braincase");
						if (e.length === 0) {
							v(.2, O(m));
							break;
						}
						let t = 2, i = O(e);
						for (let n of e) {
							let e = o.seen[n];
							e && Z[e] >= 70 && Z[e] > Z[r] ? (t = 4, i = n) : D(n) && t < 2.2 && (t = 2.2, i = n);
						}
						v(t + g.aggression * .4, i);
						break;
					}
					let e = .3, i = m[0];
					for (let n of m) {
						let a = n === t.rid ? r : o.seen[n], s;
						s = n === t.rid ? a !== "necronomicon" && a !== "cthulhu" && Z[r] < 30 ? 1.5 : -99 : a === "necronomicon" || a === "cthulhu" || a === "braincase" ? 6 : a && w[a].value >= 6 ? 2.5 : .4 + g.aggression * .9 - (1 - g.risk) * .2 + (E?.rid === n ? g.compete * .6 : 0) + (D(n) ? .8 : 0), s > e && (e = s, i = n);
					}
					v(e, i);
					break;
				}
				case "randolph":
				case "nyarlathotep": {
					if (s) {
						v(1.2 + (60 - Z[r]) / 40 + g.cunning * .8);
						break;
					}
					if (m.length === 0) {
						v(.4);
						break;
					}
					let e = 0, t = 0;
					for (let [n, r] of b) e += r, t += r * w[n].value;
					let n = e > 0 ? t / e : 3.5, i = -99, c;
					for (let e of m) {
						let t = o.seen[e], r = (t ? w[t].value : n) - a, s = .5 + r * .4 + g.cunning * .3 - (r < 0 ? (1 - g.risk) * 1.5 : 0);
						s > i && (i = s, c = e);
					}
					c && (o.seen[c] === "necronomicon" || o.seen[c] === "cthulhu") && (i = 7), v(i, c);
					break;
				}
				default: v(.5);
			}
		}
	}
	if (P.length === 0) return {
		action: h(s[0], !1),
		memory: o
	};
	P.sort((e, t) => t.score - e.score);
	let F = P[0], I = F.action;
	if ((I.type === "play" || I.type === "followup") && !I.insane && (I.card === "randolph" || I.card === "nyarlathotep") && I.target) {
		let e = s.find((e) => e !== I.card);
		e && (o.seen[I.target] = e);
	}
	return {
		action: F.action,
		memory: o
	};
}, Xe = (e, t, n) => {
	if (e.type === "nyarlAssign") return n("games.lovecraftletter.hintNyarl");
	if (e.type === "play" || e.type === "followup") {
		let t = n(D[e.card]);
		return e.type === "followup" ? n("games.lovecraftletter.hintFollowup", { card: t }) : e.guess ? n("games.lovecraftletter.hintGuess", { guess: e.guess }) : n(e.insane ? "games.lovecraftletter.hintPlayInsane" : "games.lovecraftletter.hintPlay", { card: t });
	}
	return "";
}, Q = (e) => typeof e == "string" && e in w ? e : null;
function $({ card: e, width: t }) {
	return /* @__PURE__ */ g("span", {
		className: "lcl-fx-card",
		style: {
			"--lcl-fx-w": `${t}px`,
			width: t,
			height: t * 14 / 11
		},
		children: e ? /* @__PURE__ */ g(X, {
			card: e,
			size: "small"
		}) : /* @__PURE__ */ g(ke, {})
	});
}
var Ze = {
	roundStart(e, t) {
		let n = t.anchor("deck");
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ g(S, {
				at: n,
				ms: 900
			})
		} : null;
	},
	draw(e, t) {
		let n = t.anchor("deck"), r = e.rid ? t.anchor(`disc:${e.rid}`) : null;
		if (!n || !r) return null;
		let i = Q(e.secret?.card);
		return {
			ms: 900,
			node: /* @__PURE__ */ g(x, {
				from: n,
				to: r,
				ms: 800,
				children: /* @__PURE__ */ g($, {
					card: i,
					width: n.w
				})
			})
		};
	},
	play(e, t) {
		let n = e.data, r = Q(n?.card), i = n?.insane === !0, a = e.rid, o = a ? t.anchor(`disc:${a}`) : null, s = a ? t.anchor(`discTop:${a}`) : null;
		if (!r || !o || !s || !a) return null;
		let c = typeof n?.target == "string" ? n.target : null, l = c ? t.anchor(`disc:${c}`) : null, u = typeof n?.guess == "number" ? n.guess : null, d = c !== null && n?.outRid === c, f = e.secret, p = Q(f?.peek), m = Q(f?.mine), v = Q(f?.theirs), y = m !== null && v !== null && (t.myRid === a || t.myRid === c), C = [/* @__PURE__ */ g(x, {
			from: o,
			to: s,
			ms: 800,
			children: /* @__PURE__ */ g($, {
				card: r,
				width: o.w
			})
		}, "fly")], T = [`discTop:${a}`];
		if ((r === "investigators" || r === "deepones") && l) C.push(/* @__PURE__ */ g(b, {
			at: l,
			ms: 950,
			delay: 850,
			children: /* @__PURE__ */ _("span", {
				className: "relative inline-flex",
				children: [/* @__PURE__ */ g("span", {
					className: "grid size-11 place-items-center rounded-lg border-2 border-ink bg-surface font-mono text-base font-extrabold tabular-nums",
					children: u ?? 1
				}), /* @__PURE__ */ g("span", {
					className: `absolute -right-2 -bottom-2 grid size-6 place-items-center rounded-full border-2 border-ink text-sm leading-none font-extrabold ${d ? "bg-emerald-500 text-white" : "bg-surface text-ink/40"}`,
					children: d ? "✓" : "✗"
				})]
			})
		}, "guess"));
		else if ((r === "cats" || r === "goldenmead") && l) {
			if (C.push(/* @__PURE__ */ g(S, {
				at: l,
				ms: 700,
				delay: 850
			}, "pulse")), C.push(/* @__PURE__ */ g(b, {
				at: l,
				ms: 950,
				delay: 850,
				children: p ? /* @__PURE__ */ g($, {
					card: p,
					width: Math.max(44, o.w)
				}) : /* @__PURE__ */ g("span", {
					"aria-hidden": !0,
					className: "text-2xl",
					children: "👁️"
				})
			}, "peek")), r === "goldenmead" && i) {
				let e = t.anchor("deck");
				e && C.push(/* @__PURE__ */ g(x, {
					from: e,
					to: o,
					ms: 500,
					delay: 1e3,
					children: /* @__PURE__ */ g($, { width: e.w })
				}, "mead"));
			}
		} else if ((r === "greatrace" || r === "hound") && l && !i) {
			let e = {
				x: (o.x + o.w / 2 + l.x + l.w / 2) / 2 - 12,
				y: (o.y + o.h / 2 + l.y + l.h / 2) / 2 - 12,
				w: 24,
				h: 24
			};
			C.push(/* @__PURE__ */ g(S, {
				at: o,
				ms: 700,
				delay: 850
			}, "pa")), C.push(/* @__PURE__ */ g(S, {
				at: l,
				ms: 700,
				delay: 850
			}, "pb")), C.push(/* @__PURE__ */ g(b, {
				at: e,
				ms: 950,
				delay: 850,
				children: /* @__PURE__ */ g("span", {
					"aria-hidden": !0,
					className: "text-3xl",
					children: "⚔️"
				})
			}, "vs")), y && C.push(/* @__PURE__ */ g(b, {
				at: t.myRid === a ? l : o,
				ms: 950,
				delay: 950,
				children: /* @__PURE__ */ g($, {
					card: t.myRid === a ? v : m,
					width: Math.max(44, o.w)
				})
			}, "rival"));
		} else if ((r === "armitage" || r === "migo") && l && c && Q(n?.dropped)) {
			let e = t.anchor(`discTop:${c}`);
			e && (T.push(`discTop:${c}`), C.push(/* @__PURE__ */ g(x, {
				from: l,
				to: e,
				ms: 700,
				delay: 850,
				children: /* @__PURE__ */ g($, {
					card: Q(n?.dropped),
					width: l.w
				})
			}, "drop")));
		} else if ((r === "randolph" || r === "nyarlathotep") && l && !i) {
			let e = y ? t.myRid === a ? v : m : null, n = y ? t.myRid === a ? m : v : null;
			C.push(/* @__PURE__ */ g(x, {
				from: l,
				to: o,
				ms: 700,
				delay: 850,
				children: /* @__PURE__ */ g($, {
					card: e,
					width: l.w
				})
			}, "k1")), C.push(/* @__PURE__ */ g(x, {
				from: o,
				to: l,
				ms: 700,
				delay: 850,
				children: /* @__PURE__ */ g($, {
					card: n,
					width: o.w
				})
			}, "k2"));
		} else r === "eldersign" || r === "liber" && !i ? (C.push(/* @__PURE__ */ g(S, {
			at: o,
			ms: 600,
			delay: 500
		}, "hm")), C.push(/* @__PURE__ */ g(b, {
			at: o,
			ms: 600,
			delay: 500,
			children: /* @__PURE__ */ g("span", {
				"aria-hidden": !0,
				className: "text-2xl",
				children: "🛡️"
			})
		}, "hms"))) : C.push(/* @__PURE__ */ g(b, {
			at: o,
			ms: 600,
			delay: 500,
			children: /* @__PURE__ */ g("span", {
				"aria-hidden": !0,
				className: "text-2xl",
				children: w[r].emoji
			})
		}, "self"));
		return {
			ms: z.play(c !== null),
			hide: T,
			node: /* @__PURE__ */ g(h, { children: C })
		};
	},
	sanity(e, t) {
		let n = e.rid ? t.anchor(`disc:${e.rid}`) : null;
		if (!n) return null;
		let r = e.data, i = Array.isArray(r?.revealed) ? r.revealed.map(Q).filter((e) => e !== null) : [], a = r?.failed === !0;
		return navigator.vibrate?.(a ? 160 : 40), {
			ms: z.sanity(Math.max(i.length, 1)),
			node: /* @__PURE__ */ _(h, { children: [i.map((e, t) => /* @__PURE__ */ g(b, {
				at: {
					x: n.x + t * 30 - 15,
					y: n.y - 10,
					w: n.w,
					h: n.h
				},
				ms: 700,
				delay: t * 400,
				children: /* @__PURE__ */ g($, {
					card: e,
					width: Math.max(44, n.w)
				})
			}, `${e}:${t}`)), /* @__PURE__ */ g(b, {
				at: n,
				ms: 700,
				delay: i.length * 400 + 200,
				children: /* @__PURE__ */ g("span", {
					"aria-hidden": !0,
					className: "text-3xl",
					children: a ? "💥" : "✓"
				})
			})] })
		};
	},
	nyarlDeal(e, t) {
		let n = e.rid ? t.anchor(`disc:${e.rid}`) : null;
		if (!n) return null;
		let r = e.data?.rids;
		if (!Array.isArray(r)) return null;
		let i = r.flatMap((e, r) => {
			if (typeof e != "string") return [];
			let i = t.anchor(`disc:${e}`);
			return i ? [/* @__PURE__ */ g(x, {
				from: n,
				to: i,
				ms: 600,
				delay: r * 120,
				children: /* @__PURE__ */ g($, { width: n.w })
			}, e)] : [];
		});
		return i.length ? {
			ms: 900,
			node: /* @__PURE__ */ g(h, { children: i })
		} : null;
	},
	out(e, t) {
		let n = e.rid ? t.anchor(`disc:${e.rid}`) : null;
		return n ? (navigator.vibrate?.(160), {
			ms: z.out,
			node: /* @__PURE__ */ g(b, {
				at: n,
				ms: z.out - 50,
				children: /* @__PURE__ */ g("span", {
					"aria-hidden": !0,
					className: "text-3xl",
					children: "💔"
				})
			})
		}) : null;
	},
	token(e, t) {
		let n = e.rid ? t.anchor(`disc:${e.rid}`) : null;
		if (!n) return null;
		let r = e.data?.insane === !0;
		return {
			ms: 1300,
			node: /* @__PURE__ */ g(b, {
				at: n,
				ms: 1200,
				children: /* @__PURE__ */ g("span", {
					className: "font-bold",
					style: { color: r ? k : A.accent },
					children: r ? "+1🧠" : "+1🙂"
				})
			})
		};
	},
	roundEnd(e, t) {
		let n = t.anchor("table");
		return n ? {
			ms: 1e3,
			node: /* @__PURE__ */ g(S, {
				at: n,
				ms: 1e3
			})
		} : null;
	},
	cthulhuWin(e, t) {
		let n = e.rid ? t.anchor(`disc:${e.rid}`) : null, r = t.anchor("table");
		return navigator.vibrate?.([
			120,
			80,
			200
		]), {
			ms: 1800,
			node: /* @__PURE__ */ _(h, { children: [r && /* @__PURE__ */ g(S, {
				at: r,
				ms: 1400
			}), n && /* @__PURE__ */ g(b, {
				at: n,
				ms: 1600,
				children: /* @__PURE__ */ g("span", {
					"aria-hidden": !0,
					className: "text-4xl",
					children: "🐙"
				})
			})] })
		};
	}
};
//#endregion
//#region src/games/lovecraftletter/game-over.tsx
function Qe({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ g("div", {
		className: "lcl-over",
		children: /* @__PURE__ */ g(C, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: A.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region src/games/lovecraftletter/guide.tsx
function $e() {
	let e = s();
	return /* @__PURE__ */ g("ul", {
		className: "flex w-full flex-col gap-2",
		children: T.map((t) => {
			let n = w[t];
			return /* @__PURE__ */ _("li", {
				className: "frame flex items-center gap-3 p-2",
				children: [/* @__PURE__ */ g(X, {
					card: t,
					size: "hand"
				}), /* @__PURE__ */ _("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ _("p", {
							className: "text-sm font-extrabold",
							children: [e(D[t]), /* @__PURE__ */ _("span", {
								className: "ml-1.5 font-mono text-xs tabular-nums opacity-60",
								children: ["×", n.count]
							})]
						}),
						/* @__PURE__ */ _("p", {
							className: "text-xs leading-5 font-bold opacity-70",
							children: [/* @__PURE__ */ _("span", {
								className: "opacity-60",
								children: [e("games.lovecraftletter.modeSane"), ":"]
							}), e(O[t])]
						}),
						n.insane && /* @__PURE__ */ _("p", {
							className: "text-xs leading-5 font-bold",
							style: { color: "#15803d" },
							children: [
								e("games.lovecraftletter.modeInsane"),
								":",
								e(ee[t])
							]
						})
					]
				})]
			}, t);
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/lovecraftletter/entry.tsx
var et = {
	definition: Se,
	View: Ae,
	bot: Ye,
	describe: Xe,
	fx: Ze,
	OverView: Qe,
	Guide: $e,
	locales: {
		zh: {
			name: "克苏鲁情书",
			desc: "在疯狂边缘递出信件:理智与疯狂双面效果,理智检定随时可能让你出局",
			rules: "目标:通过赢得回合收集理智币。先集齐 2 枚理智币或 3 枚疯狂币的人获胜;\n克苏鲁的疯狂效果可直接赢下整局。\n流程(轮到你):\n· 若你已疯狂,先做理智检定:翻开牌堆顶的牌,张数等于你弃牌堆里的疯狂卡数;翻出疯狂卡、死灵之书或克苏鲁即出局,若翻牌时牌堆被翻空,回合立即结束。\n· 摸一张牌,从手牌中选一张弃置并执行效果;疯狂卡可按你当前状态,二选一执行理智或疯狂效果(各卡效果见图鉴)。\n疯狂:\n· 你的弃牌堆里只要出现过疯狂卡,你即陷入疯狂,直到回合结束。\n· 银钥匙、偏方三八面体与大于 4 的牌同在手时必须弃置;疯狂者持偏方三八面体与大于 4 的牌,则直接赢下回合。\n回合结束:\n· 牌堆耗尽或只剩一人时回合结束。牌堆耗尽时幸存者比手牌:数字相同者全部出局,剩余最大者获得 1 枚理智币(疯狂者亮疯狂面);全部相同则无人得币。",
			roundChip: "第 {{n}} 回合 · 2 理智币 / 3 疯狂币获胜",
			roundEnding: "回合结束,结算中…",
			resolving: "{{name}} 的结算中…",
			yourTurn: "轮到你:选一张牌弃置",
			waiting: "等 {{name}} 行动…",
			selectTarget: "点选一个目标",
			selectGuess: "猜 {{name}} 的手牌数字",
			confirm: "弃置",
			modeSane: "理智效果",
			modeInsane: "疯狂效果",
			meadPrompt: "黄金蜜酒:再从手牌选一张弃置,效果照常生效",
			migoPrompt: "米戈:再从手牌选一张弃置,效果照常生效",
			nyarlPrompt: "奈亚拉托提普:先点一张牌,再点接收它的玩家",
			nyarlConfirm: "确认分配",
			sanityChecking: "{{name}} 的理智检定…",
			sanityPass: "理智检定通过",
			sanityFail: "翻出 {{card}},理智检定失败",
			revealLook: "你偷看了 {{name}} 的手牌:是 {{card}}",
			revealCompareWin: "比大小:你赢了,{{name}} 拿着 {{card}}",
			revealCompareLose: "比大小:你输了,{{name}} 拿着 {{card}}",
			revealCompareTie: "比大小:平手,{{name}} 也拿着 {{card}}",
			dismiss: "知道了",
			playLine: "{{name}} 弃置 {{card}}",
			playLineInsane: "{{name}} 弃置 {{card}}(疯狂)",
			playLineTarget: "{{name}} 对 {{target}} 弃置 {{card}}",
			playLineTargetInsane: "{{name}} 对 {{target}} 弃置 {{card}}(疯狂)",
			playLineGuess: "{{name}} 猜 {{target}} 是 {{guess}}",
			playLineOut: "{{name}} 出局!",
			playLineMiss: "没猜中",
			sanityLinePass: "{{name}} 的理智检定通过",
			sanityLineFail: "{{name}} 理智检定失败,出局",
			sanityLineFailImmune: "{{name}} 理智检定失败,但伊波恩之书护住了他",
			logRound: "第 {{n}} 回合",
			logAria: "对局记录",
			reasonLastStanding: "唯一幸存",
			reasonDeckOut: "牌堆耗尽,比手牌大小",
			reasonTrap: "闪耀的偏方三八面体觉醒",
			roundWinSane: "{{name}} 赢下本回合 +1 理智币",
			roundWinInsane: "{{name}} 赢下本回合 +1 疯狂币",
			roundNoWin: "全员撞车,本回合无人得币",
			cthulhuWinLine: "克苏鲁降临!{{name}} 直接赢下整局",
			handReveal: "幸存手牌",
			insaneBadge: "疯狂",
			koImmuneBadge: "免淘汰",
			protectedAria: "被旧印保护中",
			outAria: "已出局",
			deckAria: "牌堆还剩 {{n}} 张",
			burnDownAria: "暗烧牌:本局移出的未知牌",
			burnUpAria: "明烧牌:本局移出的公开牌",
			braincaseAsideAria: "米戈脑缸在场外待命",
			discardsAria: "{{name}} 的弃牌",
			tokensAria: "{{sane}} 枚理智币,{{insane}} 枚疯狂币",
			saneToken: "理智币",
			insaneToken: "疯狂币",
			playCardAria: "弃置 {{card}}",
			guessAria: "猜 {{n}}",
			errNotYourTurn: "现在轮不到你",
			errBadCard: "手里没有这张牌",
			errBadTarget: "这个目标选不了",
			errBadGuess: "这个数字猜不了",
			errForced: "银钥匙/偏方三八面体与大于 4 的牌同在手时,必须先弃它",
			errPending: "先完成当前效果的后续选择",
			errBadAssign: "分配必须覆盖每位玩家,且不多不少",
			errNotInsane: "你尚未疯狂,不能使用疯狂效果",
			card: {
				braincase: "米戈脑缸",
				investigators: "调查员",
				deepones: "深潜者",
				cats: "乌撒之猫",
				goldenmead: "黄金蜜酒",
				greatrace: "伟大种族",
				hound: "廷达罗斯猎犬",
				eldersign: "旧印",
				liber: "伊波恩之书",
				armitage: "阿米蒂奇教授",
				migo: "米戈",
				randolph: "伦道夫·卡特",
				nyarlathotep: "奈亚拉托提普",
				silverkey: "银钥匙",
				trapezohedron: "偏方三八面体",
				necronomicon: "死灵之书",
				cthulhu: "克苏鲁"
			},
			sane: {
				braincase: "打出或弃置此牌时,你立即出局",
				investigators: "选择一名对手,猜其手牌的数字(不能猜 1)。猜中,该对手立即出局",
				deepones: "选择一名对手,猜其手牌的数字(不能猜 1)。猜中,该对手立即出局",
				cats: "选择一名对手,偷看其手牌。牌面只有你知道",
				goldenmead: "选择一名对手,偷看其手牌。牌面只有你知道",
				greatrace: "选择一名对手,双方暗中比较手牌数字。小的一方立即出局;相同则无事发生",
				hound: "选择一名对手,双方暗中比较手牌数字。小的一方立即出局;相同则无事发生",
				eldersign: "直到你的下个回合开始,其他玩家的卡牌效果不能选择你",
				liber: "直到你的下个回合开始,其他玩家的卡牌效果不能选择你",
				armitage: "选择一名玩家(可以是自己),其弃掉手牌再摸一张;若因此弃掉死灵之书或克苏鲁,该玩家立即出局且不补牌;牌堆空则拿取暗烧牌",
				migo: "选择一名玩家(可以是自己),其弃掉手牌再摸一张;若因此弃掉死灵之书或克苏鲁,该玩家立即出局且不补牌;牌堆空则拿取暗烧牌",
				randolph: "选择一名对手,与其交换手牌",
				nyarlathotep: "选择一名对手,与其交换手牌",
				silverkey: "持有此牌且另一张手牌大于 4 时,必须打出此牌。打出本身无效果",
				trapezohedron: "持有此牌且另一张手牌大于 4 时,必须打出此牌。打出本身无效果",
				necronomicon: "无论因何原因,只要你弃置此牌,立即出局",
				cthulhu: "无论因何原因,只要你弃置此牌,立即出局"
			},
			insane: {
				none: "",
				braincase: "打出或弃置此牌时,你立即出局",
				deepones: "选择一名对手:若其手牌为 1,其立即出局;否则你再猜一个非 1 的数字,猜中则其出局",
				goldenmead: "选择一名对手偷看其手牌,然后你摸一张牌,并再弃置一张(弃牌效果照常生效)",
				hound: "选择一名对手:若其尚未疯狂,立即出局",
				liber: "直到回合结束,你不会被任何效果淘汰,包括理智检定失败",
				migo: "选择一名对手:其手牌归你,其改持场外的米戈脑缸;然后你再弃置一张(效果照常生效)",
				nyarlathotep: "收取所有其他在局玩家的手牌,查看后按你的意愿重新分发,每人一张",
				trapezohedron: "你疯狂时持有此牌与一张大于 4 的牌,立即赢下本回合",
				cthulhu: "打出时若你的弃牌堆已有至少 2 张其他疯狂卡,你直接赢下整局;否则你立即出局"
			},
			hintPlay: "弃置 {{card}}",
			hintPlayInsane: "弃置 {{card}}(疯狂效果)",
			hintGuess: "猜对手手牌是 {{guess}}",
			hintFollowup: "再弃置 {{card}}",
			hintNyarl: "重新分配所有人的手牌"
		},
		en: {
			name: "Lovecraft Letter",
			desc: "Deliver the letter on the brink of madness: dual sane/insane effects, and sanity checks that can knock you out",
			rules: "Goal: win rounds to collect sanity tokens. First to 2 sane-side or 3 insane-side tokens wins;\nthe insane effect of Cthulhu wins the whole game instantly.\nOn your turn:\n· If you are insane, first make a sanity check: reveal a number of deck cards equal to the number of insanity cards in your discard pile; revealing an insanity card, the Necronomicon or Cthulhu knocks you out, and if the deck runs out mid-check the round ends at once.\n· Draw a card, then discard one from your hand and apply its effect; insanity cards offer a choice of their sane or insane effect (see the card gallery).\nInsanity:\n· Once your discard pile contains any insanity card, you are insane until the round ends.\n· The Silver Key and the Trapezohedron must be discarded while held with a card higher than 4; an insane holder of the Trapezohedron with such a card wins the round instead.\nRound end:\n· The round ends when the deck is exhausted or one player remains. On exhaustion, survivors compare hands: all tied numbers are knocked out, the highest remaining card wins 1 token (insane winners flip it to the insane side); if everyone ties, nobody scores.",
			roundChip: "Round {{n}} · 2 sane / 3 insane tokens to win",
			roundEnding: "Round over, settling…",
			resolving: "Resolving {{name}}…",
			yourTurn: "Your turn: discard a card",
			waiting: "Waiting for {{name}}…",
			selectTarget: "Pick a target",
			selectGuess: "Guess {{name}}'s hand",
			confirm: "Discard",
			modeSane: "Sane effect",
			modeInsane: "Insane effect",
			meadPrompt: "Golden Mead: discard one more card from your hand; its effect applies",
			migoPrompt: "Mi-Go: discard one more card from your hand; its effect applies",
			nyarlPrompt: "Nyarlathotep: tap a card, then tap the player who receives it",
			nyarlConfirm: "Confirm deal",
			sanityChecking: "{{name}}'s sanity check…",
			sanityPass: "Sanity check passed",
			sanityFail: "Revealed {{card}} — sanity check failed",
			revealLook: "You peeked at {{name}}'s hand: {{card}}",
			revealCompareWin: "Comparison: you won; {{name}} held {{card}}",
			revealCompareLose: "Comparison: you lost; {{name}} held {{card}}",
			revealCompareTie: "Comparison: tie; {{name}} also held {{card}}",
			dismiss: "Got it",
			playLine: "{{name}} discarded {{card}}",
			playLineInsane: "{{name}} discarded {{card}} (insane)",
			playLineTarget: "{{name}} discarded {{card}} on {{target}}",
			playLineTargetInsane: "{{name}} discarded {{card}} on {{target}} (insane)",
			playLineGuess: "{{name}} guessed {{target}} has {{guess}}",
			playLineOut: "{{name}} is out!",
			playLineMiss: "Miss",
			sanityLinePass: "{{name}} passed the sanity check",
			sanityLineFail: "{{name}} failed the sanity check and is out",
			sanityLineFailImmune: "{{name}} failed the sanity check, but Liber Ivonis protected them",
			logRound: "Round {{n}}",
			logAria: "Game log",
			reasonLastStanding: "Last one standing",
			reasonDeckOut: "Deck exhausted, compare hands",
			reasonTrap: "The Shining Trapezohedron awakens",
			roundWinSane: "{{name}} wins the round, +1 sane token",
			roundWinInsane: "{{name}} wins the round, +1 insane token",
			roundNoWin: "Everyone tied — no token this round",
			cthulhuWinLine: "Cthulhu rises! {{name}} wins the whole game",
			handReveal: "Surviving hands",
			insaneBadge: "Insane",
			koImmuneBadge: "KO-immune",
			protectedAria: "Protected by an Elder Sign",
			outAria: "Out",
			deckAria: "{{n}} cards left in the deck",
			burnDownAria: "Burned face-down: the unknown card removed this round",
			burnUpAria: "Burned face-up: the public cards removed this round",
			braincaseAsideAria: "The Mi-Go Braincase waits aside",
			discardsAria: "{{name}}'s discards",
			tokensAria: "{{sane}} sane tokens, {{insane}} insane tokens",
			saneToken: "Sane token",
			insaneToken: "Insane token",
			playCardAria: "Discard {{card}}",
			guessAria: "Guess {{n}}",
			errNotYourTurn: "Not your turn",
			errBadCard: "That card is not in your hand",
			errBadTarget: "That target cannot be chosen",
			errBadGuess: "You cannot guess that number",
			errForced: "With the Silver Key / Trapezohedron held alongside a card higher than 4, you must discard it first",
			errPending: "Finish the pending effect first",
			errBadAssign: "The deal must give each player exactly one card",
			errNotInsane: "You are not insane yet; the insane effect is unavailable",
			card: {
				braincase: "Mi-Go Braincase",
				investigators: "Investigators",
				deepones: "Deep Ones",
				cats: "Cats of Ulthar",
				goldenmead: "Golden Mead",
				greatrace: "Great Race",
				hound: "Hound of Tindalos",
				eldersign: "Elder Sign",
				liber: "Liber Ivonis",
				armitage: "Prof. Armitage",
				migo: "Mi-Go",
				randolph: "Randolph Carter",
				nyarlathotep: "Nyarlathotep",
				silverkey: "The Silver Key",
				trapezohedron: "The Trapezohedron",
				necronomicon: "The Necronomicon",
				cthulhu: "Cthulhu"
			},
			sane: {
				braincase: "When you play or discard this card, you are immediately out",
				investigators: "Pick an opponent and guess their hand's number (not 1). If right, they are out",
				deepones: "Pick an opponent and guess their hand's number (not 1). If right, they are out",
				cats: "Pick an opponent and peek at their hand. Only you see it",
				goldenmead: "Pick an opponent and peek at their hand. Only you see it",
				greatrace: "Choose an opponent and secretly compare the numbers on your hand cards. The player holding the lower-numbered card is eliminated; if the numbers are equal, nothing happens.",
				hound: "Choose an opponent and secretly compare the numbers on your hand cards. The player holding the lower-numbered card is eliminated; if the numbers are equal, nothing happens.",
				eldersign: "Until your next turn, other players' card effects cannot choose you",
				liber: "Until your next turn, other players' card effects cannot choose you",
				armitage: "Pick any player (even yourself): they discard their hand and draw a new one. Discarding the Necronomicon or Cthulhu this way knocks them out with no redraw; if the deck is empty, they take the face-down burn card",
				migo: "Pick any player (even yourself): they discard their hand and draw a new one. Discarding the Necronomicon or Cthulhu this way knocks them out with no redraw; if the deck is empty, they take the face-down burn card",
				randolph: "Pick an opponent and trade hands with them",
				nyarlathotep: "Pick an opponent and trade hands with them",
				silverkey: "While holding this with a card higher than 4, you must discard it. Playing it has no effect",
				trapezohedron: "While holding this with a card higher than 4, you must discard it. Playing it has no effect",
				necronomicon: "If you ever discard this card for any reason, you are immediately out",
				cthulhu: "If you ever discard this card for any reason, you are immediately out"
			},
			insane: {
				none: "",
				braincase: "When you play or discard this card, you are immediately out",
				deepones: "Pick an opponent: if their hand is a 1, they are out; otherwise guess a number other than 1 — if right, they are out",
				goldenmead: "Peek at an opponent's hand, then draw a card and discard one (its effect applies)",
				hound: "Pick an opponent: if they are not insane, they are out",
				liber: "Until the end of the round, no effect can knock you out — not even a failed sanity check",
				migo: "Pick an opponent: take their hand, and they receive the Mi-Go Braincase from aside; then discard one card (its effect applies)",
				nyarlathotep: "Collect the hands of every other player still in, look at them, and redistribute one card to each as you wish",
				trapezohedron: "While insane, holding this with a card higher than 4 wins you the round instantly",
				cthulhu: "When played, if your discard pile already has 2 or more other insanity cards, you win the whole game; otherwise you are out"
			},
			hintPlay: "Discard {{card}}",
			hintPlayInsane: "Discard {{card}} (insane effect)",
			hintGuess: "Guess the opponent has {{guess}}",
			hintFollowup: "Then discard {{card}}",
			hintNyarl: "Redistribute everyone's hands"
		}
	}
};
//#endregion
export { et as default };
