import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { SheetView as d } from "@bgparty/sdk/sheet-view";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as m, seatName as h } from "@bgparty/sdk/ui/player-strip";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { Floater as y, PulseBox as b } from "@bgparty/sdk/fx/primitives";
import { IconBack as x, IconBot as ee, IconExpand as te, IconLog as S } from "@bgparty/sdk/icons";
import { Confetti as ne } from "@bgparty/sdk/ui/confetti";
import { OptionSwitch as re } from "@bgparty/sdk/ui/game-options";
//#region src/games/fliptown/data.ts
var ie = [
	"H",
	"S",
	"D",
	"C"
];
function ae() {
	let e = [];
	for (let t of ie) for (let n = 1; n <= 13; n++) e.push({
		suit: t,
		rank: n
	});
	return e;
}
var oe = [
	{
		key: "royalFlush",
		cash: 10,
		stars: 9
	},
	{
		key: "straightFlush",
		cash: 9,
		stars: 8
	},
	{
		key: "fourKind",
		cash: 8,
		stars: 7
	},
	{
		key: "fullHouse",
		cash: 7,
		stars: 6
	},
	{
		key: "flush",
		cash: 6,
		stars: 5
	},
	{
		key: "straight",
		cash: 5,
		stars: 4
	},
	{
		key: "threeKind",
		cash: 4,
		stars: 3
	},
	{
		key: "twoPair",
		cash: 3,
		stars: 2
	},
	{
		key: "onePair",
		cash: 2,
		stars: 1
	}
], se = [
	{
		cash: 10,
		stars: 4
	},
	{
		cash: 14,
		stars: 6
	},
	{
		cash: 18,
		stars: 8
	}
], C = [
	{
		rank: 1,
		reward: {
			kind: "stars",
			n: 2
		}
	},
	{
		rank: 2,
		reward: { kind: "tool" }
	},
	{
		rank: 3,
		reward: {
			kind: "cemeteryBonus",
			stars: 1
		}
	},
	{
		rank: 4,
		reward: {
			kind: "stars",
			n: 3,
			wanted: 1
		}
	},
	{
		rank: 5,
		reward: {
			kind: "cash",
			n: 12
		}
	},
	{
		rank: 6,
		reward: {
			kind: "bonus",
			suit: "S"
		}
	},
	{
		rank: 7,
		reward: {
			kind: "stars",
			n: 4,
			wanted: 1
		}
	},
	{
		rank: 8,
		reward: {
			kind: "gold",
			n: 8
		}
	},
	{
		rank: 9,
		reward: {
			kind: "bonus",
			suit: "C"
		}
	},
	{
		rank: 10,
		reward: {
			kind: "stars",
			n: 5,
			wanted: 2
		}
	},
	{
		rank: 11,
		reward: {
			kind: "clearWanted",
			n: 6
		}
	},
	{
		rank: 12,
		reward: {
			kind: "bonus",
			suit: "D"
		}
	},
	{
		rank: 13,
		reward: {
			kind: "stars",
			n: 6,
			wanted: 3
		}
	}
], w = [
	{
		rank: 2,
		row: 0,
		wanted: 1,
		stars: 2,
		cash: 1
	},
	{
		rank: 3,
		row: 0,
		wanted: 1,
		stars: 2,
		cash: 2
	},
	{
		rank: 4,
		row: 0,
		wanted: 1,
		stars: 2,
		cash: 3
	},
	{
		rank: 5,
		row: 1,
		wanted: 2,
		stars: 4,
		cash: 1
	},
	{
		rank: 6,
		row: 1,
		wanted: 2,
		stars: 4,
		cash: 3
	},
	{
		rank: 7,
		row: 1,
		wanted: 2,
		stars: 4,
		cash: 5
	},
	{
		rank: 8,
		row: 2,
		wanted: 3,
		stars: 6,
		cash: 2
	},
	{
		rank: 9,
		row: 2,
		wanted: 3,
		stars: 6,
		cash: 4
	},
	{
		rank: 10,
		row: 2,
		wanted: 3,
		stars: 6,
		cash: 7
	},
	{
		rank: 11,
		row: 3,
		wanted: 4,
		stars: 8,
		cash: 3
	},
	{
		rank: 12,
		row: 3,
		wanted: 4,
		stars: 8,
		cash: 6
	},
	{
		rank: 13,
		row: 3,
		wanted: 4,
		stars: 8,
		cash: 10
	}
], T = [
	"cemetery",
	"D",
	"C",
	"H"
], ce = {
	pistol: 3,
	rifle: 6
}, E = [
	{
		level: 1,
		entries: [{
			from: -1,
			lo: 1,
			hi: 7
		}],
		reward: { kind: "hammerGold" }
	},
	{
		level: 1,
		entries: [{
			from: -1,
			lo: 8,
			hi: 13
		}],
		reward: { kind: "panGold" }
	},
	{
		level: 2,
		entries: [{
			from: 0,
			lo: 1,
			hi: 4
		}],
		reward: {
			kind: "bonus",
			suit: "S",
			gold: 1
		}
	},
	{
		level: 2,
		entries: [{
			from: 0,
			lo: 5,
			hi: 7
		}, {
			from: 1,
			lo: 8,
			hi: 10
		}],
		reward: {
			kind: "bonus",
			suit: "H",
			gold: 1
		}
	},
	{
		level: 2,
		entries: [{
			from: 1,
			lo: 11,
			hi: 13
		}],
		reward: {
			kind: "bonus",
			suit: "C",
			gold: 1
		}
	},
	{
		level: 3,
		entries: [{
			from: 2,
			lo: 1,
			hi: 3
		}],
		reward: {
			kind: "starsGold",
			stars: 1,
			gold: 6,
			wanted: 1
		}
	},
	{
		level: 3,
		entries: [{
			from: 2,
			lo: 4,
			hi: 5
		}, {
			from: 3,
			lo: 6,
			hi: 7
		}],
		reward: {
			kind: "starsGold",
			stars: 2,
			gold: 4,
			wanted: 1
		}
	},
	{
		level: 3,
		entries: [{
			from: 3,
			lo: 8,
			hi: 9
		}, {
			from: 4,
			lo: 10,
			hi: 11
		}],
		reward: {
			kind: "starsGold",
			stars: 3,
			gold: 2,
			wanted: 1
		}
	},
	{
		level: 3,
		entries: [{
			from: 4,
			lo: 12,
			hi: 13
		}],
		reward: {
			kind: "starsGold",
			stars: 4,
			gold: 0,
			wanted: 1
		}
	},
	{
		level: 4,
		entries: [{
			from: 5,
			lo: 1,
			hi: 2
		}],
		reward: {
			kind: "silver",
			wanted: 1,
			per: "tombs"
		}
	},
	{
		level: 4,
		entries: [{
			from: 5,
			lo: 3,
			hi: 4
		}, {
			from: 6,
			lo: 5,
			hi: 6
		}],
		reward: {
			kind: "silver",
			wanted: 2,
			per: "buildings"
		}
	},
	{
		level: 4,
		entries: [{
			from: 6,
			lo: 7,
			hi: 8
		}, {
			from: 7,
			lo: 9,
			hi: 10
		}],
		reward: {
			kind: "silver",
			wanted: 3,
			per: "rooms"
		}
	},
	{
		level: 4,
		entries: [{
			from: 7,
			lo: 10,
			hi: 11
		}, {
			from: 8,
			lo: 11,
			hi: 12
		}],
		reward: {
			kind: "silver",
			wanted: 2,
			per: "stations"
		}
	},
	{
		level: 4,
		entries: [{
			from: 8,
			lo: 12,
			hi: 13
		}],
		reward: {
			kind: "silver",
			wanted: 1,
			per: "targets"
		}
	}
], le = [
	{
		rank: 1,
		key: "undertaker",
		effect: { kind: "undertaker" },
		first: {
			kind: "bonus",
			suit: "D"
		}
	},
	{
		rank: 2,
		key: "bank",
		effect: { kind: "bank" },
		first: {
			kind: "stars",
			n: 1
		}
	},
	{
		rank: 3,
		key: "hideout",
		effect: {
			kind: "hideout",
			maxClear: 4
		},
		first: {
			kind: "stars",
			n: 1
		}
	},
	{
		rank: 4,
		key: "stables",
		effect: { kind: "stables" },
		first: {
			kind: "bonus",
			suit: "cemetery"
		}
	},
	{
		rank: 5,
		key: "store",
		effect: { kind: "store" },
		first: {
			kind: "bonus",
			suit: "H"
		}
	},
	{
		rank: 6,
		key: "church",
		effect: {
			kind: "church",
			maxClear: 8
		},
		first: {
			kind: "stars",
			n: 1
		}
	},
	{
		rank: 7,
		key: "hotel",
		effect: { kind: "hotel" },
		first: {
			kind: "bonus",
			suit: "S"
		}
	},
	{
		rank: 8,
		key: "landOffice",
		effect: { kind: "landOffice" },
		first: {
			kind: "bonus",
			suit: "cemetery"
		}
	},
	{
		rank: 9,
		key: "gunsmith",
		effect: { kind: "gunsmith" },
		first: {
			kind: "bonus",
			suit: "H"
		}
	},
	{
		rank: 10,
		key: "bailBonds",
		effect: { kind: "bailBonds" },
		first: {
			kind: "stars",
			n: 1
		}
	},
	{
		rank: 11,
		key: "sheriff",
		effect: { kind: "sheriff" },
		first: {
			kind: "bonus",
			suit: "D"
		}
	},
	{
		rank: 12,
		key: "saloon",
		effect: {
			kind: "saloon",
			maxStars: 8,
			cashPer: 2
		},
		first: {
			kind: "stars",
			n: 1
		}
	},
	{
		rank: 13,
		key: "prospector",
		effect: {
			kind: "prospector",
			maxStars: 8
		},
		first: {
			kind: "bonus",
			suit: "S"
		}
	}
], D = {
	work: {
		cost: 3,
		stars: 1
	},
	trail: {
		cost: 4,
		mod: 6
	}
}, ue = {
	pan: {
		cost: 3,
		stars: 1
	},
	pickaxe: {
		cost: 2,
		stars: 1
	},
	bandana: {
		cost: 1,
		stars: 0
	}
}, O = {
	pistol: 3,
	rifle: 4
}, k = [
	2,
	7,
	14,
	23
], A = {
	shapes: [
		{
			key: "domino",
			cost: 4,
			cells: [0, 1]
		},
		{
			key: "trio",
			cost: 6,
			cells: [
				0,
				1,
				2
			]
		},
		{
			key: "ell",
			cost: 8,
			cells: [
				0,
				1,
				3
			]
		}
	],
	cellStars: [
		3,
		1,
		1,
		1,
		2,
		1,
		1,
		1,
		3
	],
	fullBonus: 7
}, de = [
	{
		a: 0,
		b: 1,
		reward: {
			kind: "bonus",
			suit: "S"
		}
	},
	{
		a: 1,
		b: 2,
		reward: {
			kind: "stars",
			n: 2
		}
	},
	{
		a: 3,
		b: 4,
		reward: {
			kind: "cash",
			n: 4
		}
	},
	{
		a: 4,
		b: 5,
		reward: {
			kind: "gold",
			n: 2
		}
	},
	{
		a: 6,
		b: 7,
		reward: {
			kind: "stars",
			n: 2
		}
	},
	{
		a: 7,
		b: 8,
		reward: {
			kind: "bonus",
			suit: "C"
		}
	},
	{
		a: 0,
		b: 3,
		reward: {
			kind: "gold",
			n: 4
		}
	},
	{
		a: 3,
		b: 6,
		reward: {
			kind: "bonus",
			suit: "D"
		}
	},
	{
		a: 1,
		b: 4,
		reward: {
			kind: "tool",
			tool: "hammer"
		}
	},
	{
		a: 4,
		b: 7,
		reward: {
			kind: "tool",
			tool: "pan"
		}
	},
	{
		a: 2,
		b: 5,
		reward: {
			kind: "bonus",
			suit: "H"
		}
	},
	{
		a: 5,
		b: 8,
		reward: {
			kind: "cash",
			n: 8
		}
	}
], fe = [
	4,
	4,
	4,
	7,
	7,
	7,
	7,
	7,
	7,
	7,
	7,
	7
], pe = [
	2,
	2,
	2,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4
], j = {
	cash: 4,
	gold: 2
}, M = [
	{
		key: "trailblazer",
		start: {
			cash: 3,
			gold: 4
		},
		skill: {
			kind: "bonus",
			suit: "H"
		}
	},
	{
		key: "cheat",
		start: {
			cash: 7,
			gold: 1
		},
		skill: { kind: "cheat" }
	},
	{
		key: "prospector",
		start: {
			cash: 3,
			gold: 5,
			pans: 1
		},
		skill: { kind: "freeMod" }
	},
	{
		key: "settler",
		start: {
			cash: 7,
			gold: 2
		},
		skill: {
			kind: "bonus",
			suit: "C"
		}
	},
	{
		key: "bandit",
		start: {
			cash: 7,
			gold: 6,
			wanted: 4
		},
		skill: {
			kind: "bonus",
			suit: "S"
		}
	},
	{
		key: "marshal",
		start: {
			cash: 5,
			gold: 2,
			stars: 2
		},
		skill: { kind: "reshow" }
	},
	{
		key: "preacher",
		start: {
			cash: 3,
			gold: 3
		},
		skill: {
			kind: "clearWanted",
			n: 6
		}
	},
	{
		key: "miner",
		start: {
			cash: 1,
			gold: 5
		},
		skill: {
			kind: "bonus",
			suit: "D"
		}
	},
	{
		key: "ranchHand",
		start: {
			cash: 5,
			gold: 1,
			hammers: 1
		},
		skill: {
			kind: "clearWanted",
			per: "hammer",
			n: 2
		}
	},
	{
		key: "graveRobber",
		start: {
			cash: 3,
			gold: 1,
			shovels: 1
		},
		skill: {
			kind: "bonus",
			suit: "cemetery"
		}
	},
	{
		key: "manInBlack",
		start: {
			cash: 3,
			gold: 4,
			wanted: 6,
			stars: 1
		},
		skill: {
			kind: "bonus",
			suit: "any"
		}
	},
	{
		key: "baroness",
		start: {
			cash: 7,
			gold: 1
		},
		skill: { kind: "goldPerWanted" }
	},
	{
		key: "mayor",
		start: {
			cash: 3,
			gold: 1,
			stars: 3
		},
		skill: { kind: "mayor" }
	},
	{
		key: "wildCard",
		start: {
			cash: 4,
			gold: 2
		},
		skill: {
			kind: "wild",
			n: 2
		}
	}
], N = {
	id: "fliptown",
	tier: "alpha",
	mechanics: ["roll-and-write"],
	interactionTags: [],
	nameKey: "games.fliptown.name",
	descKey: "games.fliptown.desc",
	rulesKey: "games.fliptown.rules",
	icon: "🤠",
	iconImg: "games/fliptown.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/fliptown/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#b45309",
	releasedAt: "2026-09-25",
	search: {
		py: "yong chuang pai huang zhen",
		init: "ycphz"
	},
	hotseat: "cover"
}, P = t.enum([
	"H",
	"S",
	"D",
	"C"
]), F = t.object({
	suit: P,
	rank: t.int().min(1).max(13)
}), I = t.int().min(0).max(2), L = t.object({
	characters: t.boolean().optional(),
	holdem: t.boolean().optional()
}).default({}), me = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("assign"),
		suitIdx: I,
		valueIdx: I,
		pokerIdx: I,
		suitAs: P.optional(),
		valueDelta: t.int().min(-12).max(12).optional(),
		valueAs: t.int().min(1).max(13).optional(),
		pickaxe: t.union([t.literal(-2), t.literal(2)]).optional(),
		trailStop: t.int().min(0).max(12).optional(),
		trailSkip: t.array(t.int().min(0).max(12)).optional(),
		mineRoom: t.int().min(0).max(13).optional()
	}),
	t.object({
		type: t.literal("assignCemetery"),
		tomb: t.int().min(0).max(8),
		pokerIdx: I
	}),
	t.object({
		type: t.literal("resolveTool"),
		tool: t.enum(["pan", "hammer"])
	}),
	t.object({
		type: t.literal("bonusTrail"),
		stop: t.int().min(0).max(12),
		skip: t.array(t.int().min(0).max(12)).optional()
	}),
	t.object({
		type: t.literal("bonusBadlands"),
		target: t.int().min(0).max(11)
	}),
	t.object({
		type: t.literal("bonusMine"),
		room: t.int().min(0).max(13)
	}),
	t.object({
		type: t.literal("bonusTown"),
		building: t.int().min(0).max(12)
	}),
	t.object({
		type: t.literal("bonusCemetery"),
		tomb: t.int().min(0).max(8)
	}),
	t.object({
		type: t.literal("bank"),
		color: t.enum(["red", "black"]).nullable()
	}),
	t.object({
		type: t.literal("hideout"),
		n: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("stables"),
		horse: t.enum(["work", "trail"]).nullable()
	}),
	t.object({
		type: t.literal("store"),
		item: t.enum([
			"pan",
			"pickaxe",
			"bandana"
		]).nullable()
	}),
	t.object({
		type: t.literal("church"),
		n: t.int().min(0).max(8)
	}),
	t.object({
		type: t.literal("hotel"),
		buy: t.boolean()
	}),
	t.object({
		type: t.literal("landOffice"),
		shape: t.int().min(0).max(2),
		cells: t.array(t.int().min(0).max(8)).nullable()
	}),
	t.object({
		type: t.literal("gunsmith"),
		item: t.enum(["pistol", "rifle"]).nullable()
	}),
	t.object({
		type: t.literal("bailBonds"),
		rank: t.union([
			t.literal(11),
			t.literal(12),
			t.literal(13)
		]).nullable()
	}),
	t.object({
		type: t.literal("sheriff"),
		choice: t.enum(["stars", "wanted"])
	}),
	t.object({
		type: t.literal("saloon"),
		n: t.int().min(0).max(8)
	}),
	t.object({
		type: t.literal("prospector"),
		n: t.int().min(0).max(8)
	}),
	t.object({
		type: t.literal("bailTrigger"),
		choice: t.enum([
			"cash",
			"gold",
			"wanted"
		])
	}),
	t.object({
		type: t.literal("cheat"),
		cardIndex: t.int().min(0).max(4),
		as: F.nullable()
	}),
	t.object({ type: t.literal("skip") }),
	t.object({ type: t.literal("bribe") }),
	t.object({ type: t.literal("face") }),
	t.object({
		type: t.literal("arrestPay"),
		choice: t.enum(["cash", "stars"])
	}),
	t.object({ type: t.literal("useCharacter") }),
	t.object({
		type: t.literal("useCharacterAny"),
		suit: t.enum([
			"H",
			"S",
			"D",
			"C",
			"cemetery"
		])
	}),
	t.object({
		type: t.literal("useWild"),
		idx: I
	}),
	t.object({ type: t.literal("mayor") }),
	t.object({ type: t.literal("reshow") })
]), he = t.discriminatedUnion("kind", [
	t.object({ kind: t.literal("tool") }),
	t.object({
		kind: t.literal("bonus"),
		suit: t.enum([
			"H",
			"S",
			"D",
			"C",
			"cemetery"
		])
	}),
	t.object({ kind: t.literal("bank") }),
	t.object({ kind: t.literal("hideout") }),
	t.object({ kind: t.literal("stables") }),
	t.object({ kind: t.literal("store") }),
	t.object({ kind: t.literal("church") }),
	t.object({ kind: t.literal("hotel") }),
	t.object({ kind: t.literal("landOffice") }),
	t.object({ kind: t.literal("gunsmith") }),
	t.object({ kind: t.literal("bailBonds") }),
	t.object({ kind: t.literal("sheriff") }),
	t.object({ kind: t.literal("saloon") }),
	t.object({ kind: t.literal("prospector") }),
	t.object({
		kind: t.literal("bailTrigger"),
		rank: t.int().min(11).max(13)
	}),
	t.object({ kind: t.literal("cheat") }),
	t.object({ kind: t.literal("arrest") }),
	t.object({ kind: t.literal("reshow") })
]), ge = t.object({
	cash: t.int(),
	gold: t.int(),
	stars: t.int(),
	wanted: t.int().min(0),
	pans: t.int().min(0),
	hammers: t.int().min(0),
	shovels: t.int().min(0),
	workHorse: t.boolean(),
	trailHorse: t.boolean(),
	pickaxe: t.boolean(),
	bandana: t.boolean(),
	pistol: t.boolean(),
	rifle: t.boolean(),
	trailPos: t.int().min(-1).max(12),
	trailTaken: t.array(t.boolean()).length(13),
	trailLost: t.array(t.boolean()).length(13),
	badlands: t.array(t.boolean()).length(12),
	badlandsRowBonus: t.array(t.boolean()).length(4),
	mine: t.array(t.boolean()).length(14),
	town: t.array(t.boolean()).length(13),
	townFirstUsed: t.array(t.boolean()).length(13),
	hotelLevel: t.int().min(0).max(4),
	landCells: t.array(t.boolean()).length(9),
	bankBets: t.array(t.enum(["red", "black"])),
	bailRanks: t.array(t.int().min(11).max(13)),
	undertaker: t.int().min(0).max(2),
	cemetery: t.array(t.boolean()).length(9),
	cemeteryGaps: t.array(t.boolean()).length(12),
	poker: t.array(F.nullable()).length(5),
	bonusSuitsUsed: t.array(t.enum([
		"H",
		"S",
		"D",
		"C",
		"cemetery"
	])),
	mineGoldEarned: t.int().min(0),
	character: t.int().min(0).max(13).nullable(),
	characterUsed: t.boolean(),
	wildLeft: t.int().min(0).max(2)
}), R = t.object({
	t: t.string(),
	rid: t.string().optional(),
	params: t.record(t.string(), t.union([t.string(), t.number()])).optional()
}), _e = t.object({
	players: t.array(t.string()).min(2).max(4),
	config: L,
	round: t.int().min(1).max(3),
	turn: t.int().min(1).max(5),
	phase: t.enum([
		"turns",
		"poker",
		"arrest",
		"done"
	]),
	lineup: t.array(F).max(3),
	wilds: t.array(t.object({
		idx: I,
		by: t.string()
	})),
	deckCount: t.int().min(0),
	sheriffRevealed: F.nullable(),
	playerPhase: t.record(t.string(), t.enum([
		"trigger",
		"assign",
		"resolve",
		"done"
	])),
	pending: t.record(t.string(), t.array(he)),
	boards: t.record(t.string(), ge),
	arrestDeclared: t.record(t.string(), t.enum(["bribe", "face"])),
	pokerResult: t.record(t.string(), t.object({
		payout: t.int().min(-1).max(8),
		cash: t.int(),
		stars: t.int()
	})),
	bounties: t.array(t.object({
		id: t.int().min(0).max(11),
		firstKey: t.string().nullable(),
		takers: t.array(t.object({
			rid: t.string(),
			stars: t.int()
		}))
	})),
	log: t.array(R)
}).refine((e) => e.lineup.length === (e.phase === "done" ? 0 : 3), {
	path: ["lineup"],
	message: "The lineup must contain three cards during play and be empty after the game ends"
}), ve = t.object({
	sheriffPeek: F.nullable(),
	hole: t.array(F).length(2).nullable()
});
//#endregion
//#region src/games/fliptown/sheet.ts
function z(e) {
	let t = e == null ? null : M[e], n = t?.start ?? j;
	return {
		cash: n.cash,
		gold: n.gold,
		stars: n.stars ?? 0,
		wanted: n.wanted ?? 0,
		pans: n.pans ?? 0,
		hammers: n.hammers ?? 0,
		shovels: n.shovels ?? 0,
		workHorse: !1,
		trailHorse: !1,
		pickaxe: !1,
		bandana: !1,
		pistol: !1,
		rifle: !1,
		trailPos: -1,
		trailTaken: Array(13).fill(!1),
		trailLost: Array(13).fill(!1),
		badlands: Array(12).fill(!1),
		badlandsRowBonus: [
			,
			,
			,
			,
		].fill(!1),
		mine: Array(14).fill(!1),
		town: Array(13).fill(!1),
		townFirstUsed: Array(13).fill(!1),
		hotelLevel: 0,
		landCells: Array(9).fill(!1),
		bankBets: [],
		bailRanks: [],
		undertaker: 0,
		cemetery: Array(9).fill(!1).map((e, t) => t === 4),
		cemeteryGaps: Array(12).fill(!1),
		poker: [
			null,
			null,
			null,
			null,
			null
		],
		bonusSuitsUsed: [],
		mineGoldEarned: 0,
		character: e,
		characterUsed: !1,
		wildLeft: t?.skill.kind === "wild" ? t.skill.n : 0
	};
}
function ye(e, t) {
	let n = e.trailPos;
	for (let r = e.trailPos + 1; r < 13 && !(C[r].rank > t); r++) n = r;
	return n;
}
function be(e, t, n) {
	let { b: r } = e;
	for (let i = r.trailPos + 1; i <= t; i++) {
		if (n.includes(i)) {
			r.trailLost[i] = !0;
			continue;
		}
		r.trailTaken[i] = !0, xe(e, i);
	}
	r.trailPos = Math.max(r.trailPos, t);
}
function xe(e, t) {
	let { b: n, pending: r } = e, i = C[t].reward;
	switch (i.kind) {
		case "stars":
			n.stars += i.n, n.wanted += i.wanted ?? 0;
			break;
		case "tool":
			r.push({ kind: "tool" });
			break;
		case "cash":
			n.cash += i.n;
			break;
		case "gold":
			n.gold += i.n;
			break;
		case "cemeteryBonus":
			n.stars += i.stars, r.push({
				kind: "bonus",
				suit: "cemetery"
			});
			break;
		case "bonus":
			r.push({
				kind: "bonus",
				suit: i.suit
			});
			break;
		case "clearWanted": n.wanted = Math.max(0, n.wanted - i.n);
	}
}
function B(e, t) {
	let n = t.rank;
	return e.rifle ? n += ce.rifle : e.pistol && (n += ce.pistol), n;
}
function V(e, t, n) {
	let { b: r } = e, i = w[t];
	r.badlands[t] = !0;
	let a = B(r, n) >= i.rank, o = i.wanted;
	r.bandana && (o = Math.max(0, o - 1)), r.wanted += o, r.stars += a ? i.stars : i.stars / 2, a && (r.cash += i.cash);
	let s = w.map((e, t) => ({
		x: e,
		i: t
	})).filter(({ x: e }) => e.row === i.row);
	return !r.badlandsRowBonus[i.row] && s.every(({ i: e }) => r.badlands[e]) && (r.badlandsRowBonus[i.row] = !0, e.pending.push({
		kind: "bonus",
		suit: T[i.row]
	})), { success: a };
}
function Se(e, t) {
	let n = [];
	for (let r = 0; r < E.length; r++) e.mine[r] || E[r].entries.some((n) => (n.from === -1 || e.mine[n.from]) && n.lo <= t && t <= n.hi) && n.push(r);
	return n;
}
function Ce(e) {
	let t = [];
	for (let n = 0; n < E.length; n++) e.mine[n] || E[n].entries.some((t) => t.from === -1 || e.mine[t.from]) && t.push(n);
	return t;
}
function we(e, t) {
	let { b: n } = e;
	n.mine[t] = !0;
	let r = E[t].reward;
	switch (r.kind) {
		case "hammerGold":
			n.hammers += 1, n.gold += 1, n.mineGoldEarned += 1;
			break;
		case "panGold":
			n.pans += 1, n.gold += 1, n.mineGoldEarned += 1;
			break;
		case "bonus":
			n.gold += r.gold, n.mineGoldEarned += r.gold, e.pending.push({
				kind: "bonus",
				suit: r.suit
			});
			break;
		case "starsGold":
			n.stars += r.stars, n.gold += r.gold, n.mineGoldEarned += r.gold, n.wanted += r.wanted;
			break;
		case "silver": n.wanted += r.wanted;
	}
}
function Te(e, t) {
	let { b: n, pending: r } = e, i = !n.town[t];
	n.town[t] = !0;
	let a = le[t];
	switch (i && !n.townFirstUsed[t] && (n.townFirstUsed[t] = !0, a.first.kind === "stars" ? n.stars += a.first.n : r.push({
		kind: "bonus",
		suit: a.first.suit
	})), a.effect.kind) {
		case "undertaker":
			n.undertaker = Math.min(2, n.undertaker + 1), n.undertaker === 2 && (n.shovels += 1);
			break;
		case "bank":
			r.push({ kind: "bank" });
			break;
		case "hideout":
			r.push({ kind: "hideout" });
			break;
		case "stables":
			r.push({ kind: "stables" });
			break;
		case "store":
			r.push({ kind: "store" });
			break;
		case "church":
			r.push({ kind: "church" });
			break;
		case "hotel":
			r.push({ kind: "hotel" });
			break;
		case "landOffice":
			r.push({ kind: "landOffice" });
			break;
		case "gunsmith":
			r.push({ kind: "gunsmith" });
			break;
		case "bailBonds":
			r.push({ kind: "bailBonds" });
			break;
		case "sheriff":
			r.push({ kind: "sheriff" });
			break;
		case "saloon":
			r.push({ kind: "saloon" });
			break;
		case "prospector": r.push({ kind: "prospector" });
	}
}
function Ee(e, t) {
	let { b: n } = e;
	n.cemetery[t] = !0, n.undertaker === 0 && (n.wanted += 1), n.shovels > 0 && (n.stars += 1);
	for (let t = 0; t < de.length; t++) {
		if (n.cemeteryGaps[t]) continue;
		let r = de[t];
		if (!n.cemetery[r.a] || !n.cemetery[r.b]) continue;
		n.cemeteryGaps[t] = !0;
		let i = r.reward;
		switch (i.kind) {
			case "bonus":
				e.pending.push({
					kind: "bonus",
					suit: i.suit
				});
				break;
			case "stars":
				n.stars += i.n;
				break;
			case "cash":
				n.cash += i.n;
				break;
			case "gold":
				n.gold += i.n;
				break;
			case "tool": i.tool === "hammer" ? n.hammers += 1 : n.pans += 1;
		}
	}
}
function H(e) {
	let t = U(e), n = -1;
	for (let e of t) {
		let t = De(e);
		t !== -1 && (n === -1 || t < n) && (n = t);
	}
	return n;
}
function U(e) {
	if (e.length === 5) return [e];
	let t = [];
	for (let n = 0; n < e.length - 1; n++) for (let r = n + 1; r < e.length; r++) t.push(e.filter((e, t) => t !== n && t !== r));
	return t;
}
function De(e) {
	let t = e.map((e) => e.rank).sort((e, t) => e - t), n = e.every((t) => t.suit === e[0].suit), r = [...new Set(t)], i = r.length === 5 && (r[4] - r[0] === 4 || r[4] === 13 && r[0] === 1 && r[3] === 4), a = /* @__PURE__ */ new Map();
	for (let e of t) a.set(e, (a.get(e) ?? 0) + 1);
	let o = [...a.values()].sort((e, t) => t - e);
	return i && n && r[0] === 1 && r[4] === 13 ? 0 : i && n ? 1 : o[0] === 4 ? 2 : o[0] === 3 && o[1] === 2 ? 3 : n ? 4 : i ? 5 : o[0] === 3 ? 6 : o[0] === 2 && o[1] === 2 ? 7 : o[0] === 2 ? 8 : -1;
}
function Oe(e) {
	let t = 0;
	for (let n = 0; n < 9; n++) e.landCells[n] && (t += A.cellStars[n]);
	return e.landCells.every(Boolean) && (t += A.fullBonus), t;
}
function ke(e) {
	let t = 0;
	for (let n = 9; n < 14; n++) {
		if (!e.mine[n]) continue;
		let r = E[n].reward;
		if (r.kind === "silver") switch (r.per) {
			case "tombs":
				t += e.cemetery.filter(Boolean).length;
				break;
			case "buildings":
				t += e.town.filter(Boolean).length;
				break;
			case "rooms":
				t += e.mine.filter(Boolean).length;
				break;
			case "stations":
				t += e.trailTaken.filter(Boolean).length;
				break;
			case "targets": t += e.badlands.filter(Boolean).length;
		}
	}
	return t;
}
function Ae(e) {
	return e.hotelLevel > 0 ? k[e.hotelLevel - 1] : 0;
}
function je(e) {
	return Math.floor(e.cash / 4) + Math.floor(e.gold / 2) + ke(e) + Ae(e) + e.stars;
}
//#endregion
//#region src/games/fliptown/rules.ts
var W = {
	badPhase: "games.fliptown.errBadPhase",
	notYourStep: "games.fliptown.errNotYourStep",
	badAssign: "games.fliptown.errBadAssign",
	noGold: "games.fliptown.errNoGold",
	noCash: "games.fliptown.errNoCash",
	badTrail: "games.fliptown.errBadTrail",
	badTarget: "games.fliptown.errBadTarget",
	badMine: "games.fliptown.errBadMine",
	badTomb: "games.fliptown.errBadTomb",
	badPending: "games.fliptown.errBadPending",
	badChoice: "games.fliptown.errBadChoice",
	noSkill: "games.fliptown.errNoSkill",
	over: "games.fliptown.errOver"
};
function G(e) {
	return { code: e };
}
function K(t, n) {
	let r = [...t];
	for (let t = r.length - 1; t > 0; t--) {
		let i = e(n.seed, n.rngCursor++, t + 1);
		[r[t], r[i]] = [r[i], r[t]];
	}
	return r;
}
function q(e) {
	return e.deck.length === 0 && (e.deck = K(e.discard, e), e.discard = []), e.deck.pop();
}
function Me(e) {
	return e.phase === "turns" ? `r${e.round}t${e.turn}` : `r${e.round}${e.phase}`;
}
function Ne(e, t) {
	if (e.deck = K([...e.deck, ...e.discard], e), e.discard = [], e.sheriffCard = q(e), e.sheriffRevealed = null, e.sheriffPeek = {}, e.arrestDeclared = {}, e.arrestJudged = [], e.pokerResult = {}, e.cheatDeclared = {}, e.config.holdem) for (let t of e.players) e.hole[t] = [q(e), q(e)];
	e.phase = "turns", e.turn = 1, Pe(e, t);
}
function Pe(e, t) {
	e.discard.push(...e.lineup), e.lineup = [
		q(e),
		q(e),
		q(e)
	], e.wilds = [], e.bankPaid = [], t.push({
		kind: "lineup",
		data: {
			cards: e.lineup,
			round: e.round,
			turn: e.turn
		}
	}), Fe(e);
	for (let t of e.players) e.playerPhase[t] = e.pending[t].length > 0 ? "trigger" : "assign";
	e.log.push({
		t: "games.fliptown.log.turn",
		params: { n: e.turn }
	});
}
function Fe(e) {
	let t = (e) => e.suit === "H" || e.suit === "D", n = e.lineup.every(t), r = e.lineup.every((e) => !t(e));
	for (let t of e.players) {
		let i = e.boards[t];
		for (let a of ["red", "black"]) (a === "red" ? n : r) && i.bankBets.includes(a) && !e.bankPaid.includes(t) && (i.stars += e.round, e.bankPaid.push(t), e.log.push({
			t: "games.fliptown.log.bank",
			rid: t,
			params: { n: e.round }
		}));
		for (let n of e.lineup) i.bailRanks.includes(n.rank) && e.pending[t].push({
			kind: "bailTrigger",
			rank: n.rank
		});
	}
}
function Ie(e, t) {
	if (e.phase === "turns") {
		if (!e.players.every((t) => e.playerPhase[t] === "done")) return;
		if (e.turn < 5) {
			e.turn++, Pe(e, t);
			return;
		}
		e.phase = "poker";
		for (let t of e.players) {
			let n = e.boards[t];
			n.character != null && !n.characterUsed && M[n.character].skill.kind === "cheat" && n.poker.some(Boolean) && e.pending[t].push({ kind: "cheat" });
		}
		e.players.every((t) => e.pending[t].length === 0) && Le(e, t);
		return;
	}
	if (e.phase === "poker") {
		e.players.every((t) => e.pending[t].length === 0) && Le(e, t);
		return;
	}
	if (e.phase === "arrest") {
		if (e.players.some((t) => !e.arrestDeclared[t])) return;
		if (!e.sheriffRevealed) {
			e.sheriffRevealed = e.sheriffCard, t.push({
				kind: "sheriff",
				data: { card: e.sheriffCard }
			});
			for (let t of e.players) {
				let n = e.boards[t];
				n.character != null && !n.characterUsed && M[n.character].skill.kind === "reshow" && e.pending[t].push({ kind: "reshow" });
			}
			if (e.players.some((t) => e.pending[t].length > 0)) return;
		}
		if (e.players.some((t) => e.pending[t].some((e) => e.kind === "reshow"))) return;
		for (let n of e.players) {
			if (e.arrestDeclared[n] !== "face" || e.arrestJudged.includes(n)) continue;
			e.arrestJudged.push(n);
			let r = e.boards[n];
			if ((e.sheriffRevealed?.rank ?? 13) >= r.wanted) {
				e.log.push({
					t: "games.fliptown.log.arrestPass",
					rid: n
				});
				continue;
			}
			let i = se[e.round - 1];
			r.wanted >= 14 || r.cash < i.cash ? (r.stars = Math.max(0, r.stars - i.stars), e.log.push({
				t: "games.fliptown.log.arrestStars",
				rid: n,
				params: { n: i.stars }
			}), t.push({
				kind: "arrest",
				rid: n,
				data: {
					choice: "stars",
					n: i.stars
				}
			}), J(e, n, t)) : e.pending[n].push({ kind: "arrest" });
		}
		if (e.players.some((t) => e.pending[t].length > 0)) return;
		e.discard.push(...e.lineup), e.lineup = [], e.sheriffCard && e.discard.push(e.sheriffCard), e.sheriffCard = null, e.sheriffRevealed = null;
		for (let t of e.players) {
			let n = e.boards[t];
			n.poker = [
				null,
				null,
				null,
				null,
				null
			], e.hole[t] && (e.discard.push(...e.hole[t]), e.hole[t] = []);
		}
		if (e.round >= 3) {
			e.phase = "done", e.log.push({ t: "games.fliptown.log.gameOver" });
			return;
		}
		e.round++, Ne(e, t);
	}
}
function Le(e, t) {
	for (let n of e.players) {
		let r = e.boards[n], i = r.poker.filter(Boolean), a = e.cheatDeclared[n];
		a?.as && i[a.cardIndex] && (i[a.cardIndex] = a.as), e.config.holdem && e.hole[n]?.length === 2 && i.push(...e.hole[n]);
		let o = i.length === 0 ? -1 : H(i), s = o >= 0 ? oe[o] : {
			cash: 0,
			stars: 0
		};
		r.cash += s.cash, r.stars += s.stars, e.pokerResult[n] = {
			payout: o,
			cash: s.cash,
			stars: s.stars
		}, e.log.push({
			t: "games.fliptown.log.poker",
			rid: n,
			params: {
				payout: o,
				cash: s.cash,
				stars: s.stars
			}
		}), t.push({
			kind: "poker",
			rid: n,
			data: {
				payout: o,
				cash: s.cash,
				stars: s.stars
			}
		}), J(e, n, t);
	}
	for (let n of e.players) {
		let r = e.boards[n];
		(r.pans > 0 || r.hammers > 0) && (r.gold += r.pans, r.cash += r.hammers * 2, e.log.push({
			t: "games.fliptown.log.panning",
			rid: n,
			params: {
				gold: r.pans,
				cash: r.hammers * 2
			}
		})), J(e, n, t);
	}
	e.phase = "arrest";
}
function Re(e, t, n) {
	let r = e.boards[t], i = (e) => e.filter(Boolean).length;
	switch (n) {
		case 0: return i(r.trailTaken) >= 4 && i(r.badlands) >= 4 && i(r.mine) >= 4 && i(r.town) >= 4;
		case 1: return [
			r.pans > 0,
			r.hammers > 0,
			r.workHorse || r.trailHorse,
			r.pickaxe,
			r.pistol || r.rifle
		].filter(Boolean).length >= 4;
		case 2: return r.cash >= 30 || r.gold >= 15;
		case 3: return r.cemetery.filter((e, t) => e && t !== 4).length >= 5;
		case 4: return [
			"H",
			"S",
			"D",
			"C",
			"cemetery"
		].every((e) => r.bonusSuitsUsed.includes(e));
		case 5: return [
			0,
			1,
			2,
			3
		].every((e) => w.some((t, n) => t.row === e && r.badlands[n]));
		case 6: return r.pans + r.hammers >= 5;
		case 7: return le.every((e, t) => e.first.kind !== "stars" || r.townFirstUsed[t]);
		case 8: return [
			2,
			5,
			8,
			11
		].every((e) => r.trailTaken[e]);
		case 9: return r.mineGoldEarned >= 9;
		case 10: return r.trailTaken[12] || r.bailRanks.length >= 2;
		case 11: return r.wanted >= 9;
		default: return !1;
	}
}
function J(e, t, n) {
	let r = Me(e);
	for (let i of e.bounties) {
		if (i.takers.some((e) => e.rid === t) || !Re(e, t, i.id)) continue;
		let a = i.firstKey === null || i.firstKey === r;
		i.firstKey === null && (i.firstKey = r);
		let o = a ? fe[i.id] : pe[i.id];
		i.takers.push({
			rid: t,
			stars: o
		}), e.boards[t].stars += o, e.log.push({
			t: "games.fliptown.log.bounty",
			rid: t,
			params: {
				id: i.id,
				n: o
			}
		}), n.push({
			kind: "bounty",
			rid: t,
			data: {
				id: i.id,
				stars: o
			}
		});
	}
}
function Y(e, t, n) {
	let r = {
		characters: e.characters ?? !1,
		holdem: e.holdem ?? !1
	}, i = {
		players: t,
		config: r,
		round: 1,
		turn: 1,
		phase: "turns",
		deck: [],
		discard: [],
		sheriffCard: null,
		sheriffRevealed: null,
		lineup: [],
		wilds: [],
		hole: {},
		sheriffPeek: {},
		playerPhase: {},
		pending: {},
		boards: {},
		arrestDeclared: {},
		pokerResult: {},
		cheatDeclared: {},
		bounties: [],
		bankPaid: [],
		arrestJudged: [],
		log: [],
		seed: n,
		rngCursor: 0
	}, a = t.map(() => null);
	if (r.characters) {
		let e = K(M.map((e, t) => t), i);
		a = t.map((t, n) => e[n]);
	}
	for (let e = 0; e < t.length; e++) i.boards[t[e]] = z(a[e]), i.pending[t[e]] = [];
	i.bounties = K(fe.map((e, t) => t), i).slice(0, 3).map((e) => ({
		id: e,
		firstKey: null,
		takers: []
	})), i.deck = K(ae(), i);
	let o = [];
	return Ne(i, o), i.log.push({ t: "games.fliptown.log.start" }), {
		state: i,
		fx: o
	};
}
function ze(e, t, n) {
	return e.wilds.some((e) => e.by === t && e.idx === n);
}
function Be(e, t, n, r) {
	if (e.phase !== "turns" || e.playerPhase[t] !== "assign") return G(W.notYourStep);
	if (n.suitIdx === n.valueIdx || n.suitIdx === n.pokerIdx || n.valueIdx === n.pokerIdx || ze(e, t, n.pokerIdx)) return G(W.badAssign);
	let i = e.boards[t], a = ze(e, t, n.suitIdx), o = ze(e, t, n.valueIdx);
	if (a && !n.suitAs || !a && n.suitAs === e.lineup[n.suitIdx].suit || o && n.valueAs == null || !o && n.valueAs != null) return G(W.badAssign);
	let s = n.suitAs ?? e.lineup[n.suitIdx].suit, c = o ? n.valueAs : e.lineup[n.valueIdx].rank, l = n.valueDelta ?? 0, u = c + l;
	if (n.pickaxe != null) {
		if (s !== "D" || !i.pickaxe) return G(W.badChoice);
		u += n.pickaxe;
	}
	if (s === "H" && i.trailHorse && (u += D.trail.mod), u < 1 || u > 13) return G(W.badAssign);
	let d = n.suitAs && !a ? 2 : 0, f = i.character == null ? null : M[i.character];
	if (l !== 0) {
		let e = 0;
		f?.skill.kind === "freeMod" && !i.characterUsed && (e = Math.min(Math.abs(l), i.pans)), d += Math.abs(l) - e, e > 0 && (i.characterUsed = !0);
	}
	if (i.gold < d) return G(W.noGold);
	let p = {
		b: i,
		pending: e.pending[t],
		fx: r,
		rid: t
	}, m, h = -1;
	if (s === "H") {
		let e = ye(i, u), t = n.trailStop ?? e;
		if (t <= i.trailPos || t > e || (n.trailSkip ?? []).some((e) => e <= i.trailPos || e > t)) return G(W.badTrail);
	} else if (s === "S") {
		if (h = w.findIndex((e) => e.rank === u), h === -1 || i.badlands[h]) return G(W.badTarget);
	} else if (s === "D") {
		let e = Se(i, u);
		if (e.length === 0 || e.length > 1 && (n.mineRoom == null || !e.includes(n.mineRoom))) return G(W.badMine);
	}
	i.gold -= d;
	let g = i.poker.indexOf(null);
	if (g === -1) return G(W.badAssign);
	if (i.poker[g] = e.lineup[n.pokerIdx], s === "H") be(p, n.trailStop ?? ye(i, u), n.trailSkip ?? []), e.log.push({
		t: "games.fliptown.log.trail",
		rid: t,
		params: { n: n.trailStop ?? ye(i, u) }
	});
	else if (s === "S") {
		m = q(e);
		let { success: n } = V(p, h, m);
		e.discard.push(m), e.log.push({
			t: n ? "games.fliptown.log.robOk" : "games.fliptown.log.robFail",
			rid: t,
			params: { n: w[h].rank }
		}), r.push({
			kind: "rob",
			rid: t,
			data: {
				target: h,
				card: m,
				success: n
			}
		});
	} else if (s === "D") {
		let r = Se(i, u), a = n.mineRoom ?? r[0];
		we(p, a), e.log.push({
			t: "games.fliptown.log.mine",
			rid: t,
			params: { n: a }
		});
	} else Te(p, u - 1), e.log.push({
		t: "games.fliptown.log.town",
		rid: t,
		params: { n: u - 1 }
	});
	return r.push({
		kind: "circle",
		rid: t,
		data: {
			suit: s,
			value: u
		}
	}), e.playerPhase[t] = e.pending[t].length > 0 ? "resolve" : "done", J(e, t, r), null;
}
function Ve(e, t, n, r) {
	let i = e.pending[t], a = i[0];
	if (!a) return G(W.badPending);
	let o = e.boards[t], s = {
		b: o,
		pending: i,
		fx: r,
		rid: t
	}, c = (t) => t.includes(e.phase) ? null : G(W.badPhase);
	switch (n.type) {
		case "resolveTool":
			if (a.kind !== "tool") return G(W.badPending);
			n.tool === "pan" ? o.pans = Math.min(4, o.pans + 1) : o.hammers = Math.min(4, o.hammers + 1), i.shift();
			break;
		case "bonusTrail": {
			if (a.kind !== "bonus" || a.suit !== "H") return G(W.badPending);
			let r = c(["turns"]);
			if (r) return r;
			if (n.stop <= o.trailPos || (n.skip ?? []).some((e) => e <= o.trailPos || e > n.stop)) return G(W.badTrail);
			i.shift(), He(o, "H"), be(s, n.stop, n.skip ?? []), e.log.push({
				t: "games.fliptown.log.trail",
				rid: t,
				params: { n: n.stop }
			});
			break;
		}
		case "bonusBadlands": {
			if (a.kind !== "bonus" || a.suit !== "S") return G(W.badPending);
			let l = c(["turns"]);
			if (l) return l;
			if (o.badlands[n.target]) return G(W.badTarget);
			i.shift(), He(o, "S");
			let u = q(e), { success: d } = V(s, n.target, u);
			e.discard.push(u), e.log.push({
				t: d ? "games.fliptown.log.robOk" : "games.fliptown.log.robFail",
				rid: t,
				params: { n: w[n.target].rank }
			}), r.push({
				kind: "rob",
				rid: t,
				data: {
					target: n.target,
					card: u,
					success: d
				}
			});
			break;
		}
		case "bonusMine": {
			if (a.kind !== "bonus" || a.suit !== "D") return G(W.badPending);
			let r = c(["turns"]);
			if (r) return r;
			if (!Ce(o).includes(n.room)) return G(W.badMine);
			i.shift(), He(o, "D"), we(s, n.room), e.log.push({
				t: "games.fliptown.log.mine",
				rid: t,
				params: { n: n.room }
			});
			break;
		}
		case "bonusTown": {
			if (a.kind !== "bonus" || a.suit !== "C") return G(W.badPending);
			let r = c(["turns"]);
			if (r) return r;
			i.shift(), He(o, "C"), Te(s, n.building), e.log.push({
				t: "games.fliptown.log.town",
				rid: t,
				params: { n: n.building }
			});
			break;
		}
		case "bonusCemetery": {
			if (a.kind !== "bonus" || a.suit !== "cemetery") return G(W.badPending);
			let e = c(["turns"]);
			if (e) return e;
			if (o.cemetery[n.tomb]) return G(W.badTomb);
			i.shift(), He(o, "cemetery"), Ee(s, n.tomb);
			break;
		}
		case "bank":
			if (a.kind !== "bank") return G(W.badPending);
			if (n.color != null) {
				if (o.bankBets.includes(n.color) || o.cash < 4) return G(W.noCash);
				o.cash -= 4, o.bankBets.push(n.color);
			}
			i.shift();
			break;
		case "hideout":
			if (a.kind !== "hideout") return G(W.badPending);
			o.wanted = Math.max(0, o.wanted - n.n), i.shift();
			break;
		case "stables":
			if (a.kind !== "stables") return G(W.badPending);
			if (n.horse === "work") {
				if (o.workHorse || o.cash < D.work.cost) return G(W.noCash);
				o.cash -= D.work.cost, o.workHorse = !0, o.hammers = Math.min(4, o.hammers + 1), o.stars += D.work.stars;
			} else if (n.horse === "trail") {
				if (o.trailHorse || o.cash < D.trail.cost) return G(W.noCash);
				o.cash -= D.trail.cost, o.trailHorse = !0;
			}
			i.shift();
			break;
		case "store":
			if (a.kind !== "store") return G(W.badPending);
			if (n.item != null) {
				let e = ue[n.item];
				if (o.cash < e.cost) return G(W.noCash);
				if (n.item === "pickaxe" && o.pickaxe || n.item === "bandana" && o.bandana || n.item === "pan" && o.pans >= 4) return G(W.badChoice);
				o.cash -= e.cost, o.stars += e.stars, n.item === "pan" ? o.pans += 1 : n.item === "pickaxe" ? o.pickaxe = !0 : o.bandana = !0;
			}
			i.shift();
			break;
		case "church": {
			if (a.kind !== "church") return G(W.badPending);
			let e = n.n * 1;
			if (o.cash < e) return G(W.noCash);
			o.cash -= e, o.wanted = Math.max(0, o.wanted - n.n), i.shift();
			break;
		}
		case "hotel":
			if (a.kind !== "hotel") return G(W.badPending);
			if (n.buy) {
				if (o.hotelLevel >= 4 || o.cash < 2) return G(W.noCash);
				o.cash -= 2, o.hotelLevel += 1;
			}
			i.shift();
			break;
		case "landOffice": {
			if (a.kind !== "landOffice") return G(W.badPending);
			if (n.cells == null) {
				i.shift();
				break;
			}
			let e = A.shapes[n.shape];
			if (!e || n.cells.length !== e.cells.length) return G(W.badChoice);
			if (o.cash < e.cost) return G(W.noCash);
			if (!Ue(n.cells, n.shape) || n.cells.some((e) => o.landCells[e])) return G(W.badChoice);
			o.cash -= e.cost;
			for (let e of n.cells) o.landCells[e] = !0, o.stars += A.cellStars[e];
			o.landCells.every(Boolean) && (o.stars += A.fullBonus);
			break;
		}
		case "gunsmith":
			if (a.kind !== "gunsmith") return G(W.badPending);
			if (n.item === "pistol") {
				if (o.pistol || o.rifle || o.cash < O.pistol) return G(W.noCash);
				o.cash -= O.pistol, o.pistol = !0;
			} else if (n.item === "rifle") {
				if (!o.pistol || o.rifle || o.cash < O.rifle) return G(W.noCash);
				o.cash -= O.rifle, o.rifle = !0;
			}
			i.shift();
			break;
		case "bailBonds":
			if (a.kind !== "bailBonds") return G(W.badPending);
			if (n.rank != null) {
				if (o.bailRanks.includes(n.rank)) return G(W.badChoice);
				o.bailRanks.push(n.rank);
			}
			i.shift();
			break;
		case "sheriff":
			if (a.kind !== "sheriff") return G(W.badPending);
			e.sheriffPeek[t] = e.sheriffCard, n.choice === "stars" ? o.stars += 1 : o.wanted = Math.max(0, o.wanted - 2), i.shift();
			break;
		case "saloon":
			if (a.kind !== "saloon") return G(W.badPending);
			if (o.cash < n.n * 2) return G(W.noCash);
			o.cash -= n.n * 2, o.stars += n.n, i.shift();
			break;
		case "prospector":
			if (a.kind !== "prospector") return G(W.badPending);
			if (o.gold < n.n) return G(W.noGold);
			o.gold -= n.n, o.stars += n.n, i.shift();
			break;
		case "bailTrigger":
			if (a.kind !== "bailTrigger") return G(W.badPending);
			n.choice === "cash" ? o.cash += 4 : n.choice === "gold" ? o.gold += 2 : o.wanted = Math.max(0, o.wanted - 2), i.shift();
			break;
		case "cheat": {
			if (a.kind !== "cheat") return G(W.badPending);
			let r = c(["poker"]);
			if (r) return r;
			if (n.as != null && !o.poker[n.cardIndex]) return G(W.badChoice);
			e.cheatDeclared[t] = {
				cardIndex: n.cardIndex,
				as: n.as
			}, o.characterUsed = !0, i.shift();
			break;
		}
		case "arrestPay": {
			if (a.kind !== "arrest") return G(W.badPending);
			let s = c(["arrest"]);
			if (s) return s;
			let l = se[e.round - 1];
			if (n.choice === "cash") {
				if (o.wanted >= 14 || o.cash < l.cash) return G(W.noCash);
				o.cash -= l.cash, e.log.push({
					t: "games.fliptown.log.arrestCash",
					rid: t,
					params: { n: l.cash }
				});
			} else o.stars = Math.max(0, o.stars - l.stars), e.log.push({
				t: "games.fliptown.log.arrestStars",
				rid: t,
				params: { n: l.stars }
			});
			r.push({
				kind: "arrest",
				rid: t,
				data: { choice: n.choice }
			}), i.shift();
			break;
		}
		case "reshow": {
			if (a.kind !== "reshow") return G(W.badPending);
			let n = c(["arrest"]);
			if (n) return n;
			e.sheriffCard && e.discard.push(e.sheriffCard), e.sheriffCard = q(e), e.sheriffRevealed = e.sheriffCard, o.characterUsed = !0, e.log.push({
				t: "games.fliptown.log.reshow",
				rid: t
			}), r.push({
				kind: "sheriff",
				data: { card: e.sheriffCard }
			}), i.shift();
			break;
		}
		case "skip":
			if (a.kind !== "bonus" && a.kind !== "reshow") return G(W.badPending);
			i.shift();
			break;
		default: return G(W.badPending);
	}
	return null;
}
function He(e, t) {
	e.bonusSuitsUsed.includes(t) || e.bonusSuitsUsed.push(t);
}
function Ue(e, t) {
	let n = e.map((e) => [Math.floor(e / 3), e % 3]), r = (e) => e.map(([e, t]) => `${e},${t}`).sort().join(";"), i = (e) => {
		let t = Math.min(...e.map((e) => e[0])), n = Math.min(...e.map((e) => e[1]));
		return e.map(([e, r]) => [e - t, r - n]);
	}, a = [[
		[[0, 0], [0, 1]],
		[
			[0, 0],
			[0, 1],
			[0, 2]
		],
		[
			[0, 0],
			[1, 0],
			[1, 1]
		]
	][t]];
	for (let e = 0; e < 3; e++) a.push(a[a.length - 1].map(([e, t]) => [t, -e]));
	let o = r(i(n));
	return a.some((e) => r(i(e)) === o);
}
function We(e, t, n) {
	if (e.phase === "done") return G(W.over);
	let r = n.by;
	if (!e.players.includes(r)) return G(W.notYourStep);
	let i = structuredClone(e), a = [], o = i.boards[r], s = null;
	switch (t.type) {
		case "assign":
			s = Be(i, r, t, a);
			break;
		case "assignCemetery": {
			if (i.phase !== "turns" || i.playerPhase[r] !== "assign") {
				s = G(W.notYourStep);
				break;
			}
			if (ze(i, r, t.pokerIdx) || o.cemetery[t.tomb]) {
				s = G(W.badTomb);
				break;
			}
			let e = o.poker.indexOf(null);
			if (e === -1) {
				s = G(W.badAssign);
				break;
			}
			o.poker[e] = i.lineup[t.pokerIdx], Ee({
				b: o,
				pending: i.pending[r],
				fx: a,
				rid: r
			}, t.tomb), i.log.push({
				t: "games.fliptown.log.cemetery",
				rid: r,
				params: { n: t.tomb }
			}), i.playerPhase[r] = i.pending[r].length > 0 ? "resolve" : "done", J(i, r, a);
			break;
		}
		case "bribe": {
			if (i.phase !== "arrest" || i.arrestDeclared[r]) {
				s = G(W.badPhase);
				break;
			}
			let e = o.wanted * 1;
			if (o.gold < e) {
				s = G(W.noGold);
				break;
			}
			o.gold -= e, i.arrestDeclared[r] = "bribe", i.log.push({
				t: "games.fliptown.log.bribe",
				rid: r,
				params: { n: e }
			});
			break;
		}
		case "face":
			if (i.phase !== "arrest" || i.arrestDeclared[r]) {
				s = G(W.badPhase);
				break;
			}
			i.arrestDeclared[r] = "face";
			break;
		case "useCharacter":
		case "useCharacterAny":
			s = Ge(i, r, t.type === "useCharacterAny" ? t.suit : null, a);
			break;
		case "useWild":
			if (i.phase !== "turns" || o.wildLeft <= 0 || i.playerPhase[r] === "done") {
				s = G(W.noSkill);
				break;
			}
			if (ze(i, r, t.idx)) {
				s = G(W.badChoice);
				break;
			}
			i.wilds.push({
				idx: t.idx,
				by: r
			}), --o.wildLeft, i.log.push({
				t: "games.fliptown.log.wild",
				rid: r,
				params: { n: t.idx }
			});
			break;
		case "mayor": {
			let e = o.character == null ? null : M[o.character];
			if (i.phase !== "turns" || e?.skill.kind !== "mayor" || o.characterUsed || !i.players.every((e) => i.playerPhase[e] === "trigger" || i.playerPhase[e] === "assign")) {
				s = G(W.noSkill);
				break;
			}
			o.characterUsed = !0, i.discard.push(...i.lineup), i.wilds = [];
			for (let e of i.players) i.pending[e] = i.pending[e].filter((e) => e.kind !== "bailTrigger");
			i.lineup = [
				q(i),
				q(i),
				q(i)
			], a.push({
				kind: "lineup",
				data: {
					cards: i.lineup,
					round: i.round,
					turn: i.turn
				}
			}), Fe(i);
			for (let e of i.players) i.playerPhase[e] === "assign" && i.pending[e].length > 0 ? i.playerPhase[e] = "trigger" : i.playerPhase[e] === "trigger" && i.pending[e].length === 0 && (i.playerPhase[e] = "assign");
			i.log.push({
				t: "games.fliptown.log.mayor",
				rid: r
			});
			break;
		}
		default: s = Ve(i, r, t, a);
	}
	return s || (i.phase === "turns" && (i.playerPhase[r] === "trigger" && i.pending[r].length === 0 && (i.playerPhase[r] = "assign"), i.playerPhase[r] === "resolve" && i.pending[r].length === 0 && (i.playerPhase[r] = "done")), J(i, r, a), Ie(i, a), {
		state: i,
		fx: a
	});
}
function Ge(e, t, n, r) {
	let i = e.boards[t];
	if (i.character == null || i.characterUsed) return G(W.noSkill);
	let a = M[i.character].skill, o = () => e.phase === "turns" ? null : G(W.badPhase), s = () => e.phase === "turns" || e.phase === "poker" ? null : G(W.badPhase);
	switch (a.kind) {
		case "bonus": {
			let r = o();
			if (r) return r;
			let i = a.suit === "any" ? n : a.suit;
			if (!i) return G(W.badChoice);
			e.pending[t].push({
				kind: "bonus",
				suit: i
			}), e.playerPhase[t] === "done" && (e.playerPhase[t] = "resolve");
			break;
		}
		case "clearWanted": {
			let e = s();
			if (e) return e;
			i.wanted = Math.max(0, i.wanted - (a.per === "hammer" ? a.n * i.hammers : a.n));
			break;
		}
		case "goldPerWanted": {
			let e = s();
			if (e) return e;
			i.gold += i.wanted;
			break;
		}
		default: return G(W.noSkill);
	}
	return i.characterUsed = !0, e.log.push({
		t: "games.fliptown.log.character",
		rid: t,
		params: { n: i.character }
	}), J(e, t, r), null;
}
function Ke(e, t) {
	return {
		public: {
			players: e.players,
			config: e.config,
			round: e.round,
			turn: e.turn,
			phase: e.phase,
			lineup: e.lineup,
			wilds: e.wilds,
			deckCount: e.deck.length,
			sheriffRevealed: e.sheriffRevealed,
			playerPhase: e.playerPhase,
			pending: e.pending,
			boards: e.boards,
			arrestDeclared: e.arrestDeclared,
			pokerResult: e.pokerResult,
			bounties: e.bounties,
			log: e.log
		},
		private: {
			sheriffPeek: e.sheriffPeek[t] ?? null,
			hole: e.hole[t]?.length === 2 ? e.hole[t] : null
		}
	};
}
function qe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = je(e.boards[n]);
	let n = [...e.players].sort((n, r) => {
		let i = e.boards[n], a = e.boards[r];
		return t[r] - t[n] || i.wanted - a.wanted || a.gold - i.gold || a.cash - i.cash;
	}), r = n[0];
	return {
		phase: "done",
		winner: n.filter((n) => t[n] === t[r] && e.boards[n].wanted === e.boards[r].wanted && e.boards[n].gold === e.boards[r].gold && e.boards[n].cash === e.boards[r].cash),
		ranking: n,
		scores: t
	};
}
var Je = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: N,
	schemas: {
		action: me,
		publicView: _e,
		privateView: ve,
		config: L
	},
	setup: Y,
	reduce: We,
	viewFor: Ke,
	status: qe
}, Ye = {
	H: "games.fliptown.suitH",
	S: "games.fliptown.suitS",
	D: "games.fliptown.suitD",
	C: "games.fliptown.suitC"
}, X = {
	H: "♥",
	S: "♠",
	D: "♦",
	C: "♣"
}, Z = {
	H: "#fee2e2",
	S: "#e2e8f0",
	D: "#ffedd5",
	C: "#dcfce7"
}, Xe = {
	H: "#b91c1c",
	S: "#1e293b",
	D: "#c2410c",
	C: "#15803d"
}, Ze = [
	"games.fliptown.town.undertaker",
	"games.fliptown.town.bank",
	"games.fliptown.town.hideout",
	"games.fliptown.town.stables",
	"games.fliptown.town.store",
	"games.fliptown.town.church",
	"games.fliptown.town.hotel",
	"games.fliptown.town.landOffice",
	"games.fliptown.town.gunsmith",
	"games.fliptown.town.bailBonds",
	"games.fliptown.town.sheriff",
	"games.fliptown.town.saloon",
	"games.fliptown.town.prospector"
], Qe = [
	"games.fliptown.char.trailblazer",
	"games.fliptown.char.cheat",
	"games.fliptown.char.prospector",
	"games.fliptown.char.settler",
	"games.fliptown.char.bandit",
	"games.fliptown.char.marshal",
	"games.fliptown.char.preacher",
	"games.fliptown.char.miner",
	"games.fliptown.char.ranchHand",
	"games.fliptown.char.graveRobber",
	"games.fliptown.char.manInBlack",
	"games.fliptown.char.baroness",
	"games.fliptown.char.mayor",
	"games.fliptown.char.wildCard"
], $e = [
	"games.fliptown.charSkill.trailblazer",
	"games.fliptown.charSkill.cheat",
	"games.fliptown.charSkill.prospector",
	"games.fliptown.charSkill.settler",
	"games.fliptown.charSkill.bandit",
	"games.fliptown.charSkill.marshal",
	"games.fliptown.charSkill.preacher",
	"games.fliptown.charSkill.miner",
	"games.fliptown.charSkill.ranchHand",
	"games.fliptown.charSkill.graveRobber",
	"games.fliptown.charSkill.manInBlack",
	"games.fliptown.charSkill.baroness",
	"games.fliptown.charSkill.mayor",
	"games.fliptown.charSkill.wildCard"
], et = [
	"games.fliptown.bounty.b0",
	"games.fliptown.bounty.b1",
	"games.fliptown.bounty.b2",
	"games.fliptown.bounty.b3",
	"games.fliptown.bounty.b4",
	"games.fliptown.bounty.b5",
	"games.fliptown.bounty.b6",
	"games.fliptown.bounty.b7",
	"games.fliptown.bounty.b8",
	"games.fliptown.bounty.b9",
	"games.fliptown.bounty.b10",
	"games.fliptown.bounty.b11"
], tt = [
	"games.fliptown.poker.royalFlush",
	"games.fliptown.poker.straightFlush",
	"games.fliptown.poker.fourKind",
	"games.fliptown.poker.fullHouse",
	"games.fliptown.poker.flush",
	"games.fliptown.poker.straight",
	"games.fliptown.poker.threeKind",
	"games.fliptown.poker.twoPair",
	"games.fliptown.poker.onePair"
], nt = [
	"A",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"10",
	"J",
	"Q",
	"K"
], Q = (e) => nt[e - 1] ?? "?", rt = (e) => `${X[e.suit]}${Q(e.rank)}`, it = (e) => e === "H" || e === "D", at = 760, ot = 1264, st = 1540, ct = 700, lt = 780, ut = 684;
function dt(e, t) {
	return t && e.rect.y >= ut ? {
		...e,
		rect: {
			...e.rect,
			x: e.rect.x + lt,
			y: e.rect.y - ut
		}
	} : e;
}
function ft() {
	let e = a(null), [t, n] = o({
		paired: !1,
		size: ""
	});
	return r(() => {
		let t = e.current;
		if (!t) return;
		let r = window.matchMedia("(orientation: landscape)"), i = !0, a = () => {
			let e = Math.round(t.clientWidth), a = Math.round(t.clientHeight);
			if (!e || !a) return;
			let o = r.matches && Math.min(e / st, a / ct) > Math.min(e / at, a / ot), s = `${e}:${a}`;
			queueMicrotask(() => {
				i && n((e) => e.paired === o && e.size === s ? e : {
					paired: o,
					size: s
				});
			});
		}, o = new ResizeObserver(a);
		return o.observe(t), r.addEventListener("change", a), a(), () => {
			i = !1, o.disconnect(), r.removeEventListener("change", a);
		};
	}, []), [e, t];
}
var pt = (e) => ({
	x: 8 + e * 58,
	y: 108,
	w: 54,
	h: 72
}), mt = (e) => {
	let t = w[e].row;
	return {
		x: 8 + (e - t * 3) * 168,
		y: 216 + t * 50,
		w: 160,
		h: 42
	};
}, ht = (e) => ({
	x: 512,
	y: 216 + e * 50,
	w: 240,
	h: 42
}), gt = [
	2,
	3,
	4,
	5
], _t = (e) => {
	let t = E[e].level, n = gt.slice(0, t - 1).reduce((e, t) => e + t, 0);
	return {
		x: (at - (gt[t - 1] * 140 - 8)) / 2 + (e - n) * 140,
		y: 452 + (t - 1) * 62,
		w: 132,
		h: 56
	};
}, vt = (e) => {
	let t = e < 7 ? 0 : 1, n = e < 7 ? e : e - 7;
	return {
		x: (at - ((t === 0 ? 7 : 6) * 106 - 6)) / 2 + n * 106,
		y: 724 + t * 104,
		w: 100,
		h: 96
	};
}, yt = (e) => ({
	x: 8 + e % 3 * 94,
	y: 940 + Math.floor(e / 3) * 82,
	w: 76,
	h: 64
}), bt = (e) => ({
	x: 316 + e % 3 * 68,
	y: 940 + Math.floor(e / 3) * 68,
	w: 60,
	h: 60
}), xt = (e) => ({
	x: 8 + e * 108,
	y: 1156,
	w: 100,
	h: 96
}), St = (e) => ({
	x: 560 + e * 88,
	y: 1156,
	w: 80,
	h: 96
});
function Ct(e) {
	let t = yt(e.a), n = yt(e.b);
	return {
		x: (t.x + t.w / 2 + n.x + n.w / 2) / 2,
		y: (t.y + t.h / 2 + n.y + n.h / 2) / 2
	};
}
function wt(e, t) {
	let n = [
		[[0, 0], [0, 1]],
		[
			[0, 0],
			[0, 1],
			[0, 2]
		],
		[
			[0, 0],
			[1, 0],
			[1, 1]
		]
	], r = (e) => {
		let t = Math.min(...e.map((e) => e[0])), n = Math.min(...e.map((e) => e[1]));
		return e.map(([e, r]) => [e - t, r - n]);
	}, i = (e) => e.map(([e, t]) => `${e},${t}`).sort().join(";"), a = [], o = n[e];
	for (let e = 0; e < 4; e++) {
		let e = r(o);
		a.some((t) => i(t) === i(e)) || a.push(e), o = o.map(([e, t]) => [t, -e]);
	}
	let s = [];
	for (let e of a) {
		let n = Math.max(...e.map((e) => e[0])), r = Math.max(...e.map((e) => e[1]));
		for (let i = 0; i + n < 3; i++) for (let n = 0; n + r < 3; n++) {
			let r = e.map(([e, t]) => (e + i) * 3 + (t + n));
			r.every((e) => !t[e]) && s.push(r);
		}
	}
	return s;
}
var Tt = () => ({
	pokerIdx: null,
	suitIdx: null,
	suitAs: null,
	delta: 0,
	valueAs: null,
	pickaxe: 0,
	trailStop: null,
	trailSkip: [],
	mineRoom: null,
	cemetery: !1
});
function Et(e) {
	let t = e.public, n = e.private ?? null;
	return /* @__PURE__ */ _(Dt, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Dt({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let l = u(), [h, g] = o(r), [y, b] = o(Tt), [x, ee] = o(null), [te, S] = o(0), [ne, re] = o(null), [ie, ae] = o(null), [oe, se] = o(null), [C, T] = o(!1), [ce, E] = o(!1), [ue, O] = o(!1), k = e.boards[r], de = e.boards[h] ?? k, j = e.playerPhase[r], P = (e.pending[r] ?? [])[0], F = t?.hole ?? null, I = (t) => e.wilds.some((e) => e.idx === t && e.by === r), L = h === r && e.phase !== "done", me = `${e.phase}:${e.round}:${e.turn}:${j}:${P?.kind ?? ""}:${h}`, [he, ge] = o(me);
	he !== me && (ge(me), b(Tt()), ee(null), S(0), re(null), ae(null), se(null), T(!1), E(!1), O(!1));
	let R = y.pokerIdx != null && y.suitIdx != null ? [
		0,
		1,
		2
	].find((e) => e !== y.pokerIdx && e !== y.suitIdx) : null, _e = y.suitIdx != null && I(y.suitIdx), ve = R != null && I(R), z = y.suitIdx == null ? null : y.suitAs ?? e.lineup[y.suitIdx].suit, be = R == null ? null : ve ? y.valueAs : e.lineup[R].rank, xe = z === "D" && k.pickaxe, B = be == null || z == null ? null : be + y.delta + (xe ? y.pickaxe : 0) + (z === "H" && k.trailHorse ? D.trail.mod : 0), V = B != null && B >= 1 && B <= 13, we = k.character == null ? null : M[k.character], Te = we?.skill.kind === "freeMod" && !k.characterUsed ? Math.min(Math.abs(y.delta), k.pans) : 0, Ee = (y.suitAs && !_e ? 2 : 0) + Math.abs(y.delta) - Te, H = z === "H" && V ? ye(k, B) : -1, U = z === "S" && V ? w.findIndex((e) => e.rank === B) : -1, De = i(() => z === "D" && V ? Se(k, B) : [], [
		z,
		V,
		k,
		B
	]), Oe = !y.cemetery && y.pokerIdx != null && y.suitIdx != null && V && Ee <= k.gold && (!_e || y.suitAs != null) && (!ve || y.valueAs != null) && (z === "H" ? H > k.trailPos : z === "S" ? U >= 0 && !k.badlands[U] : z === "D" ? De.length > 0 && (De.length === 1 || y.mineRoom != null) : z === "C"), ke = i(() => {
		if (L) {
			if (P?.kind === "bonus") return P.suit === "H" ? Array.from({ length: 12 - k.trailPos }, (e, t) => k.trailPos + 1 + t).map((e) => ({
				key: `trail:${e}`,
				rect: pt(e)
			})) : P.suit === "S" ? w.map((e, t) => t).filter((e) => !k.badlands[e]).map((e) => ({
				key: `bad:${e}`,
				rect: mt(e)
			})) : P.suit === "D" ? Ce(k).map((e) => ({
				key: `mine:${e}`,
				rect: _t(e)
			})) : P.suit === "C" ? le.map((e, t) => ({
				key: `town:${t}`,
				rect: vt(t)
			})) : k.cemetery.map((e, t) => e ? null : {
				key: `tomb:${t}`,
				rect: yt(t)
			}).filter((e) => e !== null);
			if (P?.kind === "landOffice" && x != null) {
				let e = wt(x, k.landCells);
				return [...new Set(e.flat())].map((e) => ({
					key: `land:${e}`,
					rect: bt(e)
				}));
			}
			if (e.phase === "turns" && j === "assign" && !P) return y.cemetery ? k.cemetery.map((e, t) => e ? null : {
				key: `tomb:${t}`,
				rect: yt(t)
			}).filter((e) => e !== null) : !V || y.suitIdx == null || y.pokerIdx == null || z == null ? void 0 : z === "H" ? H <= k.trailPos ? [] : Array.from({ length: H - k.trailPos }, (e, t) => k.trailPos + 1 + t).map((e) => ({
				key: `trail:${e}`,
				rect: pt(e)
			})) : z === "S" ? U >= 0 && !k.badlands[U] ? [{
				key: `bad:${U}`,
				rect: mt(U)
			}] : [] : z === "D" ? De.map((e) => ({
				key: `mine:${e}`,
				rect: _t(e)
			})) : [{
				key: `town:${B - 1}`,
				rect: vt(B - 1)
			}];
		}
	}, [
		L,
		P,
		x,
		e.phase,
		j,
		y,
		V,
		z,
		H,
		k,
		U,
		De,
		B
	]), Ae = (e) => {
		let [t, n] = e.split(":"), r = Number(n);
		if (P?.kind === "bonus") {
			t === "trail" ? a({
				type: "bonusTrail",
				stop: r
			}) : t === "bad" ? a({
				type: "bonusBadlands",
				target: r
			}) : t === "mine" ? a({
				type: "bonusMine",
				room: r
			}) : t === "town" ? a({
				type: "bonusTown",
				building: r
			}) : t === "tomb" && a({
				type: "bonusCemetery",
				tomb: r
			});
			return;
		}
		if (P?.kind === "landOffice" && x != null && t === "land") {
			let e = wt(x, k.landCells).filter((e) => e.includes(r));
			if (e.length === 0) return;
			let t = e.reduce((e, t) => t.reduce((e, t) => e + A.cellStars[t], 0) > e.reduce((e, t) => e + A.cellStars[t], 0) ? t : e);
			a({
				type: "landOffice",
				shape: x,
				cells: t
			});
			return;
		}
		if (y.cemetery && t === "tomb") {
			y.pokerIdx != null && a({
				type: "assignCemetery",
				tomb: r,
				pokerIdx: y.pokerIdx
			});
			return;
		}
		if (z === "H" && t === "trail") {
			y.trailStop != null && r < y.trailStop && r > k.trailPos ? b({
				...y,
				trailSkip: y.trailSkip.includes(r) ? y.trailSkip.filter((e) => e !== r) : [...y.trailSkip, r]
			}) : b({
				...y,
				trailStop: r === y.trailStop ? null : r,
				trailSkip: y.trailSkip.filter((e) => e <= r)
			});
			return;
		}
		z === "D" && t === "mine" && b({
			...y,
			mineRoom: r
		});
	}, je = () => {
		Oe && y.pokerIdx != null && y.suitIdx != null && R != null && a({
			type: "assign",
			suitIdx: y.suitIdx,
			valueIdx: R,
			pokerIdx: y.pokerIdx,
			...y.suitAs ? { suitAs: y.suitAs } : {},
			...y.delta ? { valueDelta: y.delta } : {},
			...y.valueAs == null ? {} : { valueAs: y.valueAs },
			...xe && y.pickaxe ? { pickaxe: y.pickaxe } : {},
			...z === "H" ? {
				trailStop: y.trailStop ?? H,
				trailSkip: y.trailSkip
			} : {},
			...z === "D" && y.mineRoom != null ? { mineRoom: y.mineRoom } : {}
		});
	}, W = "info", G, K;
	if (e.phase === "turns") j === "done" ? G = l("games.fliptown.donePrompt") : P ? (W = "accent", G = P.kind === "bonus" ? l("games.fliptown.bonusPrompt", { suit: P.suit === "cemetery" ? l("games.fliptown.cemetery") : l(Ye[P.suit]) }) : l("games.fliptown.resolvePrompt")) : j === "assign" ? (W = "accent", G = l("games.fliptown.assignPrompt"), K = y.pokerIdx == null ? l("games.fliptown.pickPoker") : y.suitIdx == null ? l("games.fliptown.pickSuit") : l("games.fliptown.goTarget")) : G = l("games.fliptown.triggerPrompt");
	else if (e.phase === "poker") {
		W = P ? "accent" : "info", G = l("games.fliptown.phasePoker");
		let t = e.pokerResult[r];
		t && (K = l("games.fliptown.pokerResult", { name: t.payout >= 0 ? l(tt[t.payout]) : l("games.fliptown.poker.none") }));
	} else e.phase === "arrest" ? P?.kind === "arrest" ? (W = "warn", G = l("games.fliptown.arrestChoice")) : e.arrestDeclared[r] ? G = l("games.fliptown.waitingArrest") : (W = "accent", G = l("games.fliptown.arrestPrompt")) : (W = "done", G = l("games.fliptown.phaseDone"));
	let q = we?.skill ?? null, Me = e.phase === "turns" && j !== "done" && !k.characterUsed, Ne = q?.kind === "bonus" && Me, Pe = (q?.kind === "clearWanted" || q?.kind === "goldPerWanted") && (e.phase === "turns" || e.phase === "poker") && !k.characterUsed, Fe = q?.kind === "mayor" && Me && e.players.every((t) => e.playerPhase[t] === "trigger" || e.playerPhase[t] === "assign"), Ie = k.wildLeft > 0 && e.phase === "turns" && j !== "done", Le = (t) => {
		if (C) {
			I(t) || a({
				type: "useWild",
				idx: t
			}), T(!1);
			return;
		}
		if (!(e.phase !== "turns" || j !== "assign" || P)) {
			if (y.cemetery) {
				b({
					...y,
					pokerIdx: y.pokerIdx === t ? null : t
				});
				return;
			}
			y.pokerIdx == null ? b({
				...y,
				pokerIdx: t
			}) : y.suitIdx == null && t !== y.pokerIdx ? b({
				...y,
				suitIdx: t
			}) : t === y.pokerIdx ? b({
				...y,
				pokerIdx: null
			}) : t === y.suitIdx ? b({
				...y,
				suitIdx: null,
				suitAs: null
			}) : b({
				...y,
				suitIdx: t,
				suitAs: null
			});
		}
	}, { ref: Re } = s("lineup"), [J, Y] = ft();
	return /* @__PURE__ */ _(p, {
		adaptive: !0,
		scroll: !1,
		className: "fliptown-screen",
		banner: /* @__PURE__ */ v("div", {
			className: "fliptown-banner",
			"data-players": n.length,
			children: [/* @__PURE__ */ _(f, {
				tone: W,
				text: G,
				sub: K,
				chip: e.phase === "done" ? void 0 : l("games.fliptown.roundShort", {
					r: e.round,
					t: e.turn
				}),
				accent: N.accent
			}), /* @__PURE__ */ _(m, {
				variant: "plate",
				members: n,
				myRid: r,
				anchorOf: (e) => `seat:${e}`,
				onPick: (e) => g(e),
				picked: (e) => e === h,
				action: (t) => e.phase === "turns" ? e.playerPhase[t] === "done" ? "done" : "pending" : e.phase === "poker" ? (e.pending[t]?.length ?? 0) > 0 ? "pending" : "done" : e.phase === "arrest" ? e.arrestDeclared[t] ? "done" : "pending" : null,
				status: (t) => {
					let n = e.boards[t];
					return n ? /* @__PURE__ */ v("span", {
						className: "fliptown-player-resources flex items-center gap-1.5 text-xs leading-4.5 font-bold",
						children: [
							/* @__PURE__ */ v("span", {
								className: "flex items-center gap-0.5",
								children: [/* @__PURE__ */ _("span", {
									"aria-hidden": !0,
									children: "★"
								}), /* @__PURE__ */ _(c, {
									value: n.stars,
									className: "font-mono tabular-nums"
								})]
							}),
							/* @__PURE__ */ v("span", {
								className: "flex items-center gap-0.5",
								children: [/* @__PURE__ */ _("span", {
									"aria-hidden": !0,
									children: "🚨"
								}), /* @__PURE__ */ _(c, {
									value: n.wanted,
									className: "font-mono tabular-nums"
								})]
							}),
							/* @__PURE__ */ v("span", {
								className: "flex items-center gap-0.5",
								children: [/* @__PURE__ */ _("span", {
									"aria-hidden": !0,
									children: "🪙"
								}), /* @__PURE__ */ _(c, {
									value: n.gold,
									className: "font-mono tabular-nums"
								})]
							})
						]
					}) : null;
				}
			})]
		}),
		children: /* @__PURE__ */ v("div", {
			className: "fliptown-main",
			children: [/* @__PURE__ */ _("div", {
				ref: J,
				className: "fliptown-paper",
				"data-paper": Y.paired ? "paired" : "portrait",
				children: /* @__PURE__ */ _(d, {
					sheetW: Y.paired ? st : at,
					sheetH: Y.paired ? ct : ot,
					eligible: ke?.map((e) => dt(e, Y.paired)),
					onTapEligible: Ae,
					readOnly: !L,
					fitKey: `fliptown:${h}:${Y.paired}:${Y.size}`,
					highlight: "inset",
					children: /* @__PURE__ */ _(Ot, {
						b: de,
						hole: L ? F : null,
						sel: L ? y : null,
						suit: z,
						paired: Y.paired
					})
				})
			}), /* @__PURE__ */ v("aside", {
				className: "fliptown-controls",
				children: [
					/* @__PURE__ */ v("div", {
						ref: Re,
						className: "fliptown-lineup frame",
						children: [
							e.phase !== "done" && e.lineup.map((t, n) => {
								let r = I(n), i = y.pokerIdx === n ? l("games.fliptown.slotPoker") : y.suitIdx === n ? l("games.fliptown.slotSuit") : R === n ? l("games.fliptown.slotValue") : null;
								return /* @__PURE__ */ v("button", {
									type: "button",
									onClick: () => Le(n),
									"aria-label": r ? l("games.fliptown.wildShort") : rt(t),
									className: `fliptown-card relative grid place-items-center rounded border-2 border-ink bg-surface font-mono font-black shadow-[2px_2px_0_var(--color-ink)] transition-transform active:translate-y-0.5 ${i ? "ring-3 ring-ink ring-offset-1 ring-offset-paper" : ""}`,
									style: { color: r ? "#7c3aed" : it(t.suit) ? "#b91c1c" : "var(--color-ink)" },
									children: [
										r ? "★" : rt(t),
										r && /* @__PURE__ */ _("span", {
											className: "fliptown-card-label absolute -top-1.5 -right-1.5 rounded-md border border-ink bg-warn-soft px-0.5 font-bold text-warn-ink",
											children: l("games.fliptown.wildShort")
										}),
										i && /* @__PURE__ */ _("span", {
											className: "fliptown-card-label absolute -bottom-1.5 left-1/2 -translate-x-1/2 rounded-md border border-ink bg-info-soft px-1 font-bold whitespace-nowrap text-info-ink",
											children: i
										})
									]
								}, `${e.round}:${e.turn}:${n}`);
							}),
							/* @__PURE__ */ _("span", {
								className: "ml-1 text-xs font-bold text-ink/60",
								children: l("games.fliptown.deckLeft", { n: e.deckCount })
							}),
							t?.sheriffPeek && /* @__PURE__ */ _("span", {
								className: "rounded-lg border-2 border-ink bg-info-soft px-1.5 py-0.5 font-mono text-xs font-black text-info-ink",
								children: l("games.fliptown.sheriffPeeked", { card: rt(t.sheriffPeek) })
							}),
							e.sheriffRevealed && !t?.sheriffPeek && /* @__PURE__ */ _("span", {
								className: "rounded-lg border-2 border-ink bg-surface px-1.5 py-0.5 font-mono text-xs font-black",
								children: rt(e.sheriffRevealed)
							})
						]
					}),
					/* @__PURE__ */ _("div", {
						className: "fliptown-bounties",
						"aria-label": l("games.fliptown.bountyTitle"),
						children: e.bounties.map((e) => {
							let t = e.takers.length > 0, n = e.takers.some((e) => e.rid === r), i = t ? pe[e.id] : fe[e.id];
							return /* @__PURE__ */ v("span", {
								title: l(et[e.id]),
								className: `rounded-lg border-2 border-ink px-1.5 py-0.5 font-bold ${n ? "bg-done-soft text-done-ink" : t ? "bg-surface text-ink/50" : "bg-warn-soft text-warn-ink"}`,
								children: [
									"🏅",
									i,
									"★ ",
									l(et[e.id])
								]
							}, e.id);
						})
					}),
					/* @__PURE__ */ v("div", {
						className: "fliptown-actions",
						children: [
							L && we && /* @__PURE__ */ v("div", {
								className: "flex flex-wrap items-center gap-1.5",
								children: [
									/* @__PURE__ */ v("span", {
										className: "rounded-lg border-2 border-ink bg-surface px-1.5 py-1 text-[11px] leading-4 font-bold",
										title: l($e[k.character]),
										children: [l(Qe[k.character]), k.characterUsed && /* @__PURE__ */ _("span", {
											className: "ml-1 text-ink/50",
											children: l("games.fliptown.skillUsed")
										})]
									}),
									Ne && q.kind === "bonus" && q.suit !== "any" && /* @__PURE__ */ v("button", {
										type: "button",
										onClick: () => a({ type: "useCharacter" }),
										className: "card min-h-11 px-3 text-xs font-black",
										children: ["✨ ", l("games.fliptown.useSkill")]
									}),
									Ne && q.kind === "bonus" && q.suit === "any" && /* @__PURE__ */ v("button", {
										type: "button",
										onClick: () => E(!ce),
										className: "card min-h-11 px-3 text-xs font-black",
										children: ["✨ ", l("games.fliptown.useSkill")]
									}),
									Pe && /* @__PURE__ */ v("button", {
										type: "button",
										onClick: () => a({ type: "useCharacter" }),
										className: "card min-h-11 px-3 text-xs font-black",
										children: ["✨ ", l("games.fliptown.useSkill")]
									}),
									Fe && /* @__PURE__ */ v("button", {
										type: "button",
										onClick: () => O(!ue),
										className: "card min-h-11 px-3 text-xs font-black",
										children: ["✨ ", l("games.fliptown.useSkill")]
									}),
									Ie && /* @__PURE__ */ v("button", {
										type: "button",
										onClick: () => T(!C),
										className: `card min-h-11 px-3 text-xs font-black ${C ? "ring-3 ring-ink" : ""}`,
										children: [
											"★ ",
											l("games.fliptown.wildPick"),
											"(",
											k.wildLeft,
											")"
										]
									})
								]
							}),
							ce && /* @__PURE__ */ v("div", {
								className: "frame flex flex-wrap items-center gap-1.5 p-2",
								children: [
									/* @__PURE__ */ _("span", {
										className: "text-xs font-bold",
										children: l("games.fliptown.anySuitPrompt")
									}),
									[
										"H",
										"S",
										"D",
										"C"
									].map((e) => /* @__PURE__ */ v("button", {
										type: "button",
										onClick: () => a({
											type: "useCharacterAny",
											suit: e
										}),
										className: "card min-h-11 px-3 text-xs font-black",
										children: [
											X[e],
											" ",
											l(Ye[e])
										]
									}, e)),
									/* @__PURE__ */ v("button", {
										type: "button",
										onClick: () => a({
											type: "useCharacterAny",
											suit: "cemetery"
										}),
										className: "card min-h-11 px-3 text-xs font-black",
										children: ["🪦 ", l("games.fliptown.cemetery")]
									})
								]
							}),
							ue && /* @__PURE__ */ v("div", {
								className: "frame flex items-center gap-2 p-2",
								children: [
									/* @__PURE__ */ _("span", {
										className: "flex-1 text-xs font-bold",
										children: l("games.fliptown.mayorConfirm")
									}),
									/* @__PURE__ */ _("button", {
										type: "button",
										onClick: () => a({ type: "mayor" }),
										className: "btn-base min-h-11 px-4 text-sm font-black text-white",
										style: { background: N.accent },
										children: l("games.fliptown.confirm")
									}),
									/* @__PURE__ */ _("button", {
										type: "button",
										onClick: () => O(!1),
										className: "btn-quiet min-h-11 px-3 text-xs font-bold",
										children: l("games.fliptown.cancel")
									})
								]
							}),
							L && P && e.phase !== "done" && /* @__PURE__ */ _(Lt, {
								head: P,
								b: k,
								pub: e,
								landShape: x,
								setLandShape: ee,
								stepper: te,
								setStepper: S,
								cheatIdx: ne,
								setCheatIdx: re,
								cheatSuit: ie,
								setCheatSuit: ae,
								cheatRank: oe,
								setCheatRank: se,
								hole: F,
								send: a
							}),
							L && !P && e.phase === "turns" && j === "assign" && /* @__PURE__ */ _(It, {
								pub: e,
								b: k,
								sel: y,
								setSel: b,
								suit: z,
								suitWild: _e,
								valueWild: ve,
								effValue: B,
								validValue: V,
								modCost: Ee,
								pickaxeOk: xe,
								trailFar: H,
								assignReady: !!Oe,
								onConfirm: je
							}),
							L && !P && e.phase === "arrest" && !e.arrestDeclared[r] && /* @__PURE__ */ v("div", {
								className: "frame flex items-center gap-2 p-2",
								children: [/* @__PURE__ */ _("button", {
									type: "button",
									disabled: k.gold < k.wanted * 1 || k.wanted === 0,
									onClick: () => a({ type: "bribe" }),
									className: "btn-base min-h-12 flex-1 px-3 text-sm font-black text-white disabled:opacity-40",
									style: { background: N.accent },
									children: l("games.fliptown.bribe")
								}), /* @__PURE__ */ _("button", {
									type: "button",
									onClick: () => a({ type: "face" }),
									className: "card min-h-12 flex-1 px-3 text-sm font-black",
									children: l("games.fliptown.face")
								})]
							})
						]
					})
				]
			})]
		})
	});
}
function Ot({ b: e, hole: t, sel: n, suit: r, paired: i }) {
	return /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("rect", {
			x: 0,
			y: 0,
			width: i ? st : at,
			height: i ? ct : ot,
			rx: 24,
			fill: "var(--color-surface)",
			stroke: "var(--color-ink)",
			strokeWidth: 5
		}),
		/* @__PURE__ */ v("g", {
			pointerEvents: "none",
			children: [
				/* @__PURE__ */ _("rect", {
					x: 8,
					y: 8,
					width: 744,
					height: 56,
					rx: 14,
					fill: "var(--color-paper)",
					stroke: "var(--color-ink)",
					strokeWidth: 3
				}),
				/* @__PURE__ */ _(kt, {
					x: 20,
					label: `$${e.cash}`
				}),
				/* @__PURE__ */ _(kt, {
					x: 130,
					label: `🪙${e.gold}`
				}),
				/* @__PURE__ */ _(kt, {
					x: 240,
					label: `★${e.stars}`
				}),
				/* @__PURE__ */ _(kt, {
					x: 350,
					label: `🚨${e.wanted}`,
					alert: e.wanted >= 14
				}),
				/* @__PURE__ */ _("text", {
					x: 470,
					y: 37,
					dominantBaseline: "central",
					fontSize: 20,
					fontWeight: 800,
					fill: "var(--color-ink)",
					children: `盘${e.pans} 锤${e.hammers} 铲${e.shovels}`
				}),
				/* @__PURE__ */ _("text", {
					x: 620,
					y: 37,
					dominantBaseline: "central",
					fontSize: 20,
					fontWeight: 800,
					fill: "var(--color-ink)",
					children: [
						e.workHorse && "役",
						e.trailHorse && "驿",
						e.pickaxe && "锄",
						e.bandana && "巾",
						e.rifle ? "步枪" : e.pistol && "枪"
					].filter(Boolean).join(" ")
				})
			]
		}),
		/* @__PURE__ */ _(At, {
			x: 8,
			y: 88,
			text: "♥",
			tint: Z.H
		}),
		C.map((t, n) => {
			let r = pt(n), i = e.trailTaken[n], a = e.trailLost[n];
			return /* @__PURE__ */ v("g", { children: [
				/* @__PURE__ */ _("rect", {
					x: r.x,
					y: r.y,
					width: r.w,
					height: r.h,
					rx: 10,
					fill: Z.H,
					stroke: "var(--color-ink)",
					strokeWidth: 2.5,
					opacity: a ? .35 : 1
				}),
				/* @__PURE__ */ _("text", {
					x: r.x + r.w / 2,
					y: r.y + 18,
					textAnchor: "middle",
					fontSize: 18,
					fontWeight: 900,
					fill: "var(--color-ink)",
					pointerEvents: "none",
					children: Q(t.rank)
				}),
				/* @__PURE__ */ _("text", {
					x: r.x + r.w / 2,
					y: r.y + 46,
					textAnchor: "middle",
					fontSize: 13,
					fontWeight: 800,
					fill: "var(--color-ink)",
					pointerEvents: "none",
					children: Nt(t.reward)
				}),
				i && /* @__PURE__ */ _("ellipse", {
					cx: r.x + r.w / 2,
					cy: r.y + r.h / 2,
					rx: r.w / 2 - 3,
					ry: r.h / 2 - 3,
					fill: "none",
					stroke: "var(--color-ink)",
					strokeWidth: 5,
					pointerEvents: "none"
				}),
				a && /* @__PURE__ */ v("g", {
					stroke: "var(--color-ink)",
					strokeWidth: 6,
					strokeLinecap: "round",
					pointerEvents: "none",
					children: [/* @__PURE__ */ _("line", {
						x1: r.x + 8,
						y1: r.y + 8,
						x2: r.x + r.w - 8,
						y2: r.y + r.h - 8
					}), /* @__PURE__ */ _("line", {
						x1: r.x + r.w - 8,
						y1: r.y + 8,
						x2: r.x + 8,
						y2: r.y + r.h - 8
					})]
				}),
				n === e.trailPos && /* @__PURE__ */ _("polygon", {
					points: `${r.x + r.w / 2 - 8},${r.y - 4} ${r.x + r.w / 2 + 8},${r.y - 4} ${r.x + r.w / 2},${r.y - 14}`,
					fill: "var(--color-ink)",
					pointerEvents: "none"
				})
			] }, n);
		}),
		/* @__PURE__ */ _(At, {
			x: 8,
			y: 200,
			text: "♠",
			tint: Z.S
		}),
		w.map((t, n) => {
			let r = mt(n), i = e.badlands[n];
			return /* @__PURE__ */ v("g", { children: [
				/* @__PURE__ */ _("rect", {
					x: r.x,
					y: r.y,
					width: r.w,
					height: r.h,
					rx: 10,
					fill: Z.S,
					stroke: "var(--color-ink)",
					strokeWidth: 2.5
				}),
				/* @__PURE__ */ _("text", {
					x: r.x + 22,
					y: r.y + r.h / 2,
					textAnchor: "middle",
					dominantBaseline: "central",
					fontSize: 20,
					fontWeight: 900,
					fill: "var(--color-ink)",
					pointerEvents: "none",
					children: Q(t.rank)
				}),
				/* @__PURE__ */ _("text", {
					x: r.x + 92,
					y: r.y + r.h / 2,
					textAnchor: "middle",
					dominantBaseline: "central",
					fontSize: 14,
					fontWeight: 800,
					fill: "var(--color-ink)",
					pointerEvents: "none",
					children: `🚨${t.wanted} ★${t.stars} $${t.cash}`
				}),
				i && /* @__PURE__ */ _("ellipse", {
					cx: r.x + r.w / 2,
					cy: r.y + r.h / 2,
					rx: r.w / 2 - 3,
					ry: r.h / 2 - 3,
					fill: "none",
					stroke: "var(--color-ink)",
					strokeWidth: 5,
					pointerEvents: "none"
				})
			] }, n);
		}),
		[
			0,
			1,
			2,
			3
		].map((t) => {
			let n = ht(t), r = e.badlandsRowBonus[t], i = T[t];
			return /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("rect", {
				x: n.x,
				y: n.y,
				width: n.w,
				height: n.h,
				rx: 10,
				fill: "var(--color-paper)",
				stroke: "var(--color-ink)",
				strokeWidth: 2.5,
				opacity: r ? .4 : 1
			}), /* @__PURE__ */ _("text", {
				x: n.x + n.w / 2,
				y: n.y + n.h / 2,
				textAnchor: "middle",
				dominantBaseline: "central",
				fontSize: 15,
				fontWeight: 800,
				fill: "var(--color-ink)",
				pointerEvents: "none",
				children: `行奖励:${i === "cemetery" ? "🪦" : X[i]}行动`
			})] }, t);
		}),
		/* @__PURE__ */ _(At, {
			x: 8,
			y: 436,
			text: "♦",
			tint: Z.D
		}),
		E.map((t, n) => {
			let r = _t(n), i = e.mine[n];
			return /* @__PURE__ */ v("g", { children: [
				/* @__PURE__ */ _("rect", {
					x: r.x,
					y: r.y,
					width: r.w,
					height: r.h,
					rx: 12,
					fill: Z.D,
					stroke: "var(--color-ink)",
					strokeWidth: 2.5
				}),
				/* @__PURE__ */ _("text", {
					x: r.x + r.w / 2,
					y: r.y + 16,
					textAnchor: "middle",
					fontSize: 13,
					fontWeight: 800,
					fill: "var(--color-ink)",
					opacity: .7,
					pointerEvents: "none",
					children: t.entries.map((e) => e.lo === e.hi ? Q(e.lo) : `${Q(e.lo)}-${Q(e.hi)}`).join("/")
				}),
				/* @__PURE__ */ _("text", {
					x: r.x + r.w / 2,
					y: r.y + 38,
					textAnchor: "middle",
					fontSize: 14,
					fontWeight: 900,
					fill: "var(--color-ink)",
					pointerEvents: "none",
					children: Pt(t.reward)
				}),
				i && /* @__PURE__ */ _("ellipse", {
					cx: r.x + r.w / 2,
					cy: r.y + r.h / 2,
					rx: r.w / 2 - 3,
					ry: r.h / 2 - 3,
					fill: "none",
					stroke: "var(--color-ink)",
					strokeWidth: 5,
					pointerEvents: "none"
				})
			] }, n);
		}),
		/* @__PURE__ */ v("g", {
			transform: i ? `translate(${lt},-684)` : void 0,
			children: [
				/* @__PURE__ */ _(At, {
					x: 8,
					y: 708,
					text: "♣",
					tint: Z.C
				}),
				le.map((t, n) => {
					let r = vt(n), i = e.town[n];
					return /* @__PURE__ */ v("g", { children: [
						/* @__PURE__ */ _("rect", {
							x: r.x,
							y: r.y,
							width: r.w,
							height: r.h,
							rx: 12,
							fill: Z.C,
							stroke: "var(--color-ink)",
							strokeWidth: 2.5
						}),
						/* @__PURE__ */ _("text", {
							x: r.x + r.w / 2,
							y: r.y + 16,
							textAnchor: "middle",
							fontSize: 16,
							fontWeight: 900,
							fill: "var(--color-ink)",
							pointerEvents: "none",
							children: Q(t.rank)
						}),
						/* @__PURE__ */ _(Mt, {
							x: r.x + r.w / 2,
							y: r.y + 44,
							idx: n
						}),
						/* @__PURE__ */ _("text", {
							x: r.x + r.w / 2,
							y: r.y + 78,
							textAnchor: "middle",
							fontSize: 13,
							fontWeight: 800,
							fill: "var(--color-ink)",
							opacity: e.townFirstUsed[n] ? .35 : .8,
							pointerEvents: "none",
							children: t.first.kind === "stars" ? `首★${t.first.n}` : `首${t.first.suit === "cemetery" ? "🪦" : X[t.first.suit]}行动`
						}),
						i && /* @__PURE__ */ _("ellipse", {
							cx: r.x + r.w / 2,
							cy: r.y + r.h / 2,
							rx: r.w / 2 - 3,
							ry: r.h / 2 - 3,
							fill: "none",
							stroke: "var(--color-ink)",
							strokeWidth: 5,
							pointerEvents: "none"
						})
					] }, n);
				}),
				/* @__PURE__ */ _("text", {
					x: 8,
					y: 928,
					fontSize: 18,
					fontWeight: 900,
					fill: "var(--color-ink)",
					pointerEvents: "none",
					children: "🪦"
				}),
				Array.from({ length: 9 }, (t, n) => {
					let r = yt(n), i = e.cemetery[n];
					return /* @__PURE__ */ v("g", { children: [
						/* @__PURE__ */ _("rect", {
							x: r.x + 8,
							y: r.y + 10,
							width: r.w - 16,
							height: r.h - 10,
							rx: 14,
							fill: "#e7e5e4",
							stroke: "var(--color-ink)",
							strokeWidth: 2.5
						}),
						/* @__PURE__ */ _("rect", {
							x: r.x + 20,
							y: r.y + 26,
							width: r.w - 40,
							height: 4,
							rx: 2,
							fill: "var(--color-ink)",
							opacity: .3
						}),
						/* @__PURE__ */ _("rect", {
							x: r.x + 20,
							y: r.y + 36,
							width: r.w - 40,
							height: 4,
							rx: 2,
							fill: "var(--color-ink)",
							opacity: .3
						}),
						i && /* @__PURE__ */ _("ellipse", {
							cx: r.x + r.w / 2,
							cy: r.y + r.h / 2,
							rx: r.w / 2 - 5,
							ry: r.h / 2 - 5,
							fill: "none",
							stroke: "var(--color-ink)",
							strokeWidth: 5,
							pointerEvents: "none"
						})
					] }, n);
				}),
				de.map((t, n) => {
					let r = Ct(t), i = e.cemeteryGaps[n];
					return /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("circle", {
						cx: r.x,
						cy: r.y,
						r: 13,
						fill: i ? "#fbbf24" : "var(--color-paper)",
						stroke: "var(--color-ink)",
						strokeWidth: 2.5
					}), /* @__PURE__ */ _("text", {
						x: r.x,
						y: r.y,
						textAnchor: "middle",
						dominantBaseline: "central",
						fontSize: 11,
						fontWeight: 900,
						fill: "var(--color-ink)",
						pointerEvents: "none",
						children: Ft(t.reward)
					})] }, n);
				}),
				/* @__PURE__ */ _("text", {
					x: 316,
					y: 928,
					fontSize: 16,
					fontWeight: 900,
					fill: "var(--color-ink)",
					pointerEvents: "none",
					children: `地皮(${Oe(e)}★)`
				}),
				Array.from({ length: 9 }, (t, n) => {
					let r = bt(n), i = e.landCells[n];
					return /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("rect", {
						x: r.x,
						y: r.y,
						width: r.w,
						height: r.h,
						rx: 10,
						fill: i ? "#bbf7d0" : "var(--color-paper)",
						stroke: "var(--color-ink)",
						strokeWidth: 2.5
					}), /* @__PURE__ */ _("text", {
						x: r.x + r.w / 2,
						y: r.y + r.h / 2,
						textAnchor: "middle",
						dominantBaseline: "central",
						fontSize: 18,
						fontWeight: 900,
						fill: "var(--color-ink)",
						opacity: i ? 1 : .45,
						pointerEvents: "none",
						children: A.cellStars[n]
					})] }, n);
				}),
				/* @__PURE__ */ _("text", {
					x: 560,
					y: 928,
					fontSize: 16,
					fontWeight: 900,
					fill: "var(--color-ink)",
					pointerEvents: "none",
					children: `旅馆银星(${Ae(e)}★)`
				}),
				k.map((t, n) => {
					let r = e.hotelLevel > n;
					return /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("circle", {
						cx: 592,
						cy: 966 + n * 52,
						r: 20,
						fill: r ? "#fbbf24" : "var(--color-paper)",
						stroke: "var(--color-ink)",
						strokeWidth: 2.5
					}), /* @__PURE__ */ _("text", {
						x: 592,
						y: 966 + n * 52,
						textAnchor: "middle",
						dominantBaseline: "central",
						fontSize: 15,
						fontWeight: 900,
						fill: "var(--color-ink)",
						pointerEvents: "none",
						children: t
					})] }, n);
				}),
				/* @__PURE__ */ _("text", {
					x: 640,
					y: 980,
					fontSize: 14,
					fontWeight: 800,
					fill: "var(--color-ink)",
					opacity: .7,
					pointerEvents: "none",
					children: `矿银星 ${ke(e)}★`
				}),
				/* @__PURE__ */ _("text", {
					x: 640,
					y: 1010,
					fontSize: 14,
					fontWeight: 800,
					fill: "var(--color-ink)",
					opacity: .7,
					pointerEvents: "none",
					children: `估总分 ${je(e)}`
				}),
				e.poker.map((e, t) => {
					let n = xt(t);
					return /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("rect", {
						x: n.x,
						y: n.y,
						width: n.w,
						height: n.h,
						rx: 12,
						fill: "var(--color-paper)",
						stroke: "var(--color-ink)",
						strokeWidth: 2.5,
						strokeDasharray: e ? "none" : "8 6"
					}), e && /* @__PURE__ */ _(jt, {
						card: e,
						x: n.x,
						y: n.y,
						w: n.w,
						h: n.h
					})] }, t);
				}),
				t && t.map((e, t) => {
					let n = St(t);
					return /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("rect", {
						x: n.x,
						y: n.y,
						width: n.w,
						height: n.h,
						rx: 12,
						fill: "#fef3c7",
						stroke: "var(--color-ink)",
						strokeWidth: 2.5
					}), /* @__PURE__ */ _(jt, {
						card: e,
						x: n.x,
						y: n.y,
						w: n.w,
						h: n.h
					})] }, t);
				})
			]
		}),
		n && r === "H" && n.trailStop != null && /* @__PURE__ */ _("ellipse", {
			cx: pt(n.trailStop).x + 27,
			cy: pt(n.trailStop).y + 36,
			rx: 30,
			ry: 39,
			fill: "none",
			stroke: "#d97706",
			strokeWidth: 6,
			pointerEvents: "none"
		})
	] });
}
function kt({ x: e, label: t, alert: n }) {
	return /* @__PURE__ */ _("text", {
		x: e,
		y: 37,
		dominantBaseline: "central",
		fontSize: 24,
		fontWeight: 900,
		fill: n ? "#b91c1c" : "var(--color-ink)",
		children: t
	});
}
function At({ x: e, y: t, text: n, tint: r }) {
	return /* @__PURE__ */ v("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ _("rect", {
			x: e,
			y: t,
			width: 36,
			height: 28,
			rx: 8,
			fill: r,
			stroke: "var(--color-ink)",
			strokeWidth: 2.5
		}), /* @__PURE__ */ _("text", {
			x: e + 18,
			y: t + 14,
			textAnchor: "middle",
			dominantBaseline: "central",
			fontSize: 18,
			fontWeight: 900,
			fill: "var(--color-ink)",
			children: n
		})]
	});
}
function jt({ card: e, x: t, y: n, w: r, h: i }) {
	let a = it(e.suit) ? "#b91c1c" : "var(--color-ink)";
	return /* @__PURE__ */ v("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ _("text", {
			x: t + r / 2,
			y: n + i / 2 - 12,
			textAnchor: "middle",
			dominantBaseline: "central",
			fontSize: 30,
			fontWeight: 900,
			fill: a,
			children: Q(e.rank)
		}), /* @__PURE__ */ _("text", {
			x: t + r / 2,
			y: n + i / 2 + 20,
			textAnchor: "middle",
			dominantBaseline: "central",
			fontSize: 24,
			fontWeight: 900,
			fill: a,
			children: X[e.suit]
		})]
	});
}
function Mt({ x: e, y: t, idx: n }) {
	let r = u()(Ze[n]);
	if (r.length <= 4) return /* @__PURE__ */ _("text", {
		x: e,
		y: t,
		textAnchor: "middle",
		fontSize: 17,
		fontWeight: 900,
		fill: "var(--color-ink)",
		pointerEvents: "none",
		children: r
	});
	let i = Math.ceil(r.length / 2);
	return /* @__PURE__ */ v("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ _("text", {
			x: e,
			y: t - 11,
			textAnchor: "middle",
			fontSize: 15,
			fontWeight: 900,
			fill: "var(--color-ink)",
			children: r.slice(0, i)
		}), /* @__PURE__ */ _("text", {
			x: e,
			y: t + 11,
			textAnchor: "middle",
			fontSize: 15,
			fontWeight: 900,
			fill: "var(--color-ink)",
			children: r.slice(i)
		})]
	});
}
function Nt(e) {
	switch (e.kind) {
		case "stars": return `★${e.n}${e.wanted ? `🚨${e.wanted}` : ""}`;
		case "tool": return "盘/锤";
		case "cash": return `$${e.n}`;
		case "gold": return `🪙${e.n}`;
		case "cemeteryBonus": return `🪦★${e.stars}`;
		case "bonus": return `${X[e.suit]}行动`;
		case "clearWanted": return `-${e.n}🚨`;
	}
}
function Pt(e) {
	switch (e.kind) {
		case "hammerGold": return "锤+🪙";
		case "panGold": return "盘+🪙";
		case "bonus": return `${X[e.suit]}行动+🪙${e.gold}`;
		case "starsGold": return `★${e.stars}🪙${e.gold}🚨${e.wanted}`;
		case "silver": return `银★/类 🚨${e.wanted}`;
	}
}
function Ft(e) {
	return e.kind === "bonus" ? `${e.suit === "cemetery" ? "🪦" : X[e.suit]}` : e.kind === "stars" ? `★${e.n}` : e.kind === "cash" ? `$${e.n}` : e.kind === "gold" ? `🪙${e.n}` : e.tool === "hammer" ? "锤" : "盘";
}
function It({ pub: e, b: t, sel: n, setSel: r, suit: i, suitWild: a, valueWild: o, effValue: s, validValue: c, modCost: l, pickaxeOk: d, trailFar: f, assignReady: p, onConfirm: m }) {
	let h = u();
	if (n.cemetery) return /* @__PURE__ */ v("div", {
		className: "frame flex items-center gap-2 p-2",
		children: [/* @__PURE__ */ v("span", {
			className: "flex-1 text-xs font-bold",
			children: [
				"🪦 ",
				h("games.fliptown.cemetery"),
				" · ",
				n.pokerIdx == null ? h("games.fliptown.pickPoker") : h("games.fliptown.goTarget")
			]
		}), /* @__PURE__ */ _("button", {
			type: "button",
			onClick: () => r({
				...n,
				cemetery: !1
			}),
			className: "btn-quiet min-h-11 px-3 text-xs font-bold",
			children: h("games.fliptown.cancel")
		})]
	});
	let y = n.pokerIdx != null && n.suitIdx != null;
	return /* @__PURE__ */ v("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [!y && /* @__PURE__ */ v("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ _("span", {
				className: "flex-1 text-xs font-bold",
				children: n.pokerIdx == null ? h("games.fliptown.pickPoker") : h("games.fliptown.pickSuit")
			}), /* @__PURE__ */ v("button", {
				type: "button",
				onClick: () => r({
					...n,
					cemetery: !0
				}),
				className: "btn-quiet min-h-11 px-3 text-xs font-bold",
				children: ["🪦 ", h("games.fliptown.toCemetery")]
			})]
		}), y && /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ v("div", {
				className: "flex items-center gap-1.5",
				children: [
					/* @__PURE__ */ _("span", {
						className: "rounded-lg border-2 border-ink bg-surface px-1.5 py-1 text-xs font-black",
						children: a ? h("games.fliptown.wildShort") : i ? `${X[i]} ${h(Ye[i])}` : ""
					}),
					/* @__PURE__ */ _("span", {
						className: "rounded-lg border-2 border-ink bg-surface px-1.5 py-1 font-mono text-xs font-black",
						children: o ? n.valueAs == null ? "?" : Q(n.valueAs) : s == null ? "?" : Q(Math.min(13, Math.max(1, s)))
					}),
					l > 0 && /* @__PURE__ */ v("span", {
						className: "text-xs font-bold text-warn-ink",
						children: ["-🪙", l]
					}),
					/* @__PURE__ */ _("span", { className: "flex-1" }),
					/* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => r({
							...n,
							cemetery: !0
						}),
						className: "btn-quiet min-h-11 px-3 text-xs font-bold",
						children: ["🪦 ", h("games.fliptown.cemetery")]
					})
				]
			}),
			(a || t.gold >= 2) && /* @__PURE__ */ v("div", {
				className: "flex items-center gap-1.5",
				children: [/* @__PURE__ */ _("span", {
					className: "text-xs font-bold",
					children: h("games.fliptown.modSuit")
				}), [
					"H",
					"S",
					"D",
					"C"
				].map((t) => {
					let i = (n.suitAs ?? (n.suitIdx == null ? null : e.lineup[n.suitIdx].suit)) === t, o = n.suitIdx != null && e.lineup[n.suitIdx].suit === t && !a;
					return /* @__PURE__ */ _("button", {
						type: "button",
						disabled: o,
						onClick: () => r({
							...n,
							suitAs: i && !a ? null : t,
							mineRoom: null,
							trailStop: null,
							trailSkip: [],
							pickaxe: 0
						}),
						className: `card grid min-h-11 min-w-11 place-items-center px-2 text-base font-black disabled:opacity-30 ${i ? "ring-3 ring-ink" : ""}`,
						style: { color: Xe[t] },
						children: X[t]
					}, t);
				})]
			}),
			o ? /* @__PURE__ */ _("div", {
				className: "flex flex-wrap items-center gap-1",
				children: nt.map((e, t) => /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => r({
						...n,
						valueAs: t + 1,
						mineRoom: null,
						trailStop: null,
						trailSkip: []
					}),
					className: `card grid min-h-11 min-w-9 place-items-center px-1 font-mono text-xs font-black ${n.valueAs === t + 1 ? "ring-3 ring-ink" : ""}`,
					children: e
				}, e))
			}) : /* @__PURE__ */ v("div", {
				className: "flex items-center gap-1.5",
				children: [
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.gold < l + 1 || s == null || s <= 1,
						onClick: () => r({
							...n,
							delta: n.delta - 1,
							mineRoom: null,
							trailStop: null,
							trailSkip: []
						}),
						className: "card min-h-11 min-w-11 font-mono text-sm font-black disabled:opacity-30",
						children: "−"
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.gold < l + 1 || s == null || s >= 13,
						onClick: () => r({
							...n,
							delta: n.delta + 1,
							mineRoom: null,
							trailStop: null,
							trailSkip: []
						}),
						className: "card min-h-11 min-w-11 font-mono text-sm font-black disabled:opacity-30",
						children: "+"
					}),
					d && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => r({
							...n,
							pickaxe: n.pickaxe === -2 ? 0 : -2,
							mineRoom: null
						}),
						className: `card min-h-11 px-2 text-xs font-black ${n.pickaxe === -2 ? "ring-3 ring-ink" : ""}`,
						children: "⛏−2"
					}), /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => r({
							...n,
							pickaxe: n.pickaxe === 2 ? 0 : 2,
							mineRoom: null
						}),
						className: `card min-h-11 px-2 text-xs font-black ${n.pickaxe === 2 ? "ring-3 ring-ink" : ""}`,
						children: "⛏+2"
					})] }),
					/* @__PURE__ */ _("span", {
						className: "flex-1 text-right text-[11px] font-bold text-ink/60",
						children: i === "H" && f > t.trailPos ? h("games.fliptown.trailStopPrompt") : h("games.fliptown.goTarget")
					})
				]
			}),
			/* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ v("button", {
					type: "button",
					disabled: !p,
					onClick: m,
					className: "btn-base min-h-12 flex-1 px-4 text-sm font-black text-white disabled:opacity-40",
					style: { background: N.accent },
					children: [h("games.fliptown.confirm"), c && i === "H" && ` → ${Q(C[n.trailStop ?? f]?.rank ?? 0)}`]
				}), /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => r({
						pokerIdx: null,
						suitIdx: null,
						suitAs: null,
						delta: 0,
						valueAs: null,
						pickaxe: 0,
						trailStop: null,
						trailSkip: [],
						mineRoom: null,
						cemetery: !1
					}),
					className: "btn-quiet min-h-11 px-3 text-xs font-bold",
					children: h("games.fliptown.cancel")
				})]
			})
		] })]
	});
}
function Lt({ head: e, b: t, pub: n, landShape: r, setLandShape: i, stepper: a, setStepper: o, cheatIdx: s, setCheatIdx: c, cheatSuit: l, setCheatSuit: d, cheatRank: f, setCheatRank: p, hole: m, send: h }) {
	let g = u(), y = se[n.round - 1], b = (e, t, n) => /* @__PURE__ */ v("div", {
		className: "flex items-center gap-2",
		children: [
			/* @__PURE__ */ _("button", {
				type: "button",
				disabled: a <= 0,
				onClick: () => o(a - 1),
				className: "card min-h-11 min-w-11 font-mono text-sm font-black disabled:opacity-30",
				children: "−"
			}),
			/* @__PURE__ */ _("span", {
				className: "min-w-8 text-center font-mono text-lg font-black",
				children: a
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				disabled: a >= e,
				onClick: () => o(a + 1),
				className: "card min-h-11 min-w-11 font-mono text-sm font-black disabled:opacity-30",
				children: "+"
			}),
			/* @__PURE__ */ _("span", { className: "flex-1" }),
			/* @__PURE__ */ _("button", {
				type: "button",
				onClick: () => n(a),
				className: "btn-base min-h-11 px-4 text-sm font-black text-white",
				style: { background: N.accent },
				children: g(t, { n: a })
			})
		]
	}), x = null;
	switch (e.kind) {
		case "tool":
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _("span", {
						className: "flex-1 text-xs font-bold",
						children: g("games.fliptown.toolPrompt")
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => h({
							type: "resolveTool",
							tool: "pan"
						}),
						className: "card min-h-11 flex-1 px-3 text-sm font-black",
						children: ["🥘 ", g("games.fliptown.itemPan")]
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => h({
							type: "resolveTool",
							tool: "hammer"
						}),
						className: "card min-h-11 flex-1 px-3 text-sm font-black",
						children: ["🔨 ", g("games.fliptown.itemHammer")]
					})
				]
			});
			break;
		case "bonus":
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _("span", {
					className: "flex-1 text-xs font-bold",
					children: g("games.fliptown.bonusPrompt", { suit: e.suit === "cemetery" ? g("games.fliptown.cemetery") : g(Ye[e.suit]) })
				}), /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => h({ type: "skip" }),
					className: "btn-quiet min-h-11 px-3 text-xs font-bold",
					children: g("games.fliptown.skip")
				})]
			});
			break;
		case "bank":
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _("span", {
						className: "flex-1 text-xs font-bold",
						children: g("games.fliptown.bankPrompt")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.cash < 4,
						onClick: () => h({
							type: "bank",
							color: "red"
						}),
						className: "card min-h-11 px-3 text-xs font-black text-rose-700 disabled:opacity-30",
						children: g("games.fliptown.betRed")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.cash < 4,
						onClick: () => h({
							type: "bank",
							color: "black"
						}),
						className: "card min-h-11 px-3 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.betBlack")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "bank",
							color: null
						}),
						className: "btn-quiet min-h-11 px-3 text-xs font-bold",
						children: g("games.fliptown.betNone")
					})
				]
			});
			break;
		case "hideout":
			x = b(Math.min(4, t.wanted), "games.fliptown.clearWantedN", (e) => h({
				type: "hideout",
				n: e
			}));
			break;
		case "stables":
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.cash < D.work.cost || t.workHorse,
						onClick: () => h({
							type: "stables",
							horse: "work"
						}),
						className: "card min-h-11 flex-1 px-2 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.buyWork")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.cash < D.trail.cost || t.trailHorse,
						onClick: () => h({
							type: "stables",
							horse: "trail"
						}),
						className: "card min-h-11 flex-1 px-2 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.buyTrail")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "stables",
							horse: null
						}),
						className: "btn-quiet min-h-11 px-3 text-xs font-bold",
						children: g("games.fliptown.buyNone")
					})
				]
			});
			break;
		case "store":
			x = /* @__PURE__ */ v("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.cash < ue.pan.cost,
						onClick: () => h({
							type: "store",
							item: "pan"
						}),
						className: "card min-h-11 flex-1 px-2 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.buyPan")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.cash < ue.pickaxe.cost || t.pickaxe,
						onClick: () => h({
							type: "store",
							item: "pickaxe"
						}),
						className: "card min-h-11 flex-1 px-2 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.buyPickaxe")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.cash < ue.bandana.cost || t.bandana,
						onClick: () => h({
							type: "store",
							item: "bandana"
						}),
						className: "card min-h-11 flex-1 px-2 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.buyBandana")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "store",
							item: null
						}),
						className: "btn-quiet min-h-11 px-3 text-xs font-bold",
						children: g("games.fliptown.buyNone")
					})
				]
			});
			break;
		case "church":
			x = b(Math.min(8, t.wanted, t.cash), "games.fliptown.clearWantedN", (e) => h({
				type: "church",
				n: e
			}));
			break;
		case "hotel":
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _("span", {
						className: "flex-1 text-xs font-bold",
						children: g("games.fliptown.hotelPrompt")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.cash < 2 || t.hotelLevel >= 4,
						onClick: () => h({
							type: "hotel",
							buy: !0
						}),
						className: "card min-h-11 px-3 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.buySilver")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "hotel",
							buy: !1
						}),
						className: "btn-quiet min-h-11 px-3 text-xs font-bold",
						children: g("games.fliptown.passBuy")
					})
				]
			});
			break;
		case "landOffice": {
			let e = (e) => t.cash >= A.shapes[e].cost && wt(e, t.landCells).length > 0;
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _("span", {
						className: "flex-1 text-xs font-bold",
						children: g("games.fliptown.landPrompt")
					}),
					[
						0,
						1,
						2
					].map((t) => /* @__PURE__ */ _("button", {
						type: "button",
						disabled: !e(t),
						onClick: () => i(r === t ? null : t),
						className: `card min-h-11 px-2 text-xs font-black disabled:opacity-30 ${r === t ? "ring-3 ring-ink" : ""}`,
						children: g([
							"games.fliptown.shapeDomino",
							"games.fliptown.shapeTrio",
							"games.fliptown.shapeEll"
						][t])
					}, t)),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "landOffice",
							shape: 0,
							cells: null
						}),
						className: "btn-quiet min-h-11 px-3 text-xs font-bold",
						children: g("games.fliptown.landEnd")
					})
				]
			});
			break;
		}
		case "gunsmith":
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.cash < O.pistol || t.pistol || t.rifle,
						onClick: () => h({
							type: "gunsmith",
							item: "pistol"
						}),
						className: "card min-h-11 flex-1 px-2 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.buyPistol")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.cash < O.rifle || !t.pistol || t.rifle,
						onClick: () => h({
							type: "gunsmith",
							item: "rifle"
						}),
						className: "card min-h-11 flex-1 px-2 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.buyRifle")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "gunsmith",
							item: null
						}),
						className: "btn-quiet min-h-11 px-3 text-xs font-bold",
						children: g("games.fliptown.buyNone")
					})
				]
			});
			break;
		case "bailBonds":
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _("span", {
						className: "flex-1 text-xs font-bold",
						children: g("games.fliptown.bailPrompt")
					}),
					[
						11,
						12,
						13
					].map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.bailRanks.includes(e),
						onClick: () => h({
							type: "bailBonds",
							rank: e
						}),
						className: "card min-h-11 min-w-11 font-mono text-sm font-black disabled:opacity-30",
						children: Q(e)
					}, e)),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "bailBonds",
							rank: null
						}),
						className: "btn-quiet min-h-11 px-3 text-xs font-bold",
						children: g("games.fliptown.bailNone")
					})
				]
			});
			break;
		case "sheriff":
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _("span", {
						className: "flex-1 text-xs font-bold",
						children: g("games.fliptown.sheriffChoicePrompt")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "sheriff",
							choice: "stars"
						}),
						className: "card min-h-11 flex-1 px-2 text-xs font-black",
						children: g("games.fliptown.takeStar")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.wanted === 0,
						onClick: () => h({
							type: "sheriff",
							choice: "wanted"
						}),
						className: "card min-h-11 flex-1 px-2 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.clear2")
					})
				]
			});
			break;
		case "saloon":
			x = b(Math.min(8, Math.floor(t.cash / 2)), "games.fliptown.convertN", (e) => h({
				type: "saloon",
				n: e
			}));
			break;
		case "prospector":
			x = b(Math.min(8, t.gold), "games.fliptown.convertN", (e) => h({
				type: "prospector",
				n: e
			}));
			break;
		case "bailTrigger":
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ v("span", {
						className: "flex-1 text-xs font-bold",
						children: [
							g("games.fliptown.bailTriggerPrompt"),
							"(",
							Q(e.rank),
							")"
						]
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "bailTrigger",
							choice: "cash"
						}),
						className: "card min-h-11 px-2 text-xs font-black",
						children: g("games.fliptown.bailCash")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "bailTrigger",
							choice: "gold"
						}),
						className: "card min-h-11 px-2 text-xs font-black",
						children: g("games.fliptown.bailGold")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.wanted === 0,
						onClick: () => h({
							type: "bailTrigger",
							choice: "wanted"
						}),
						className: "card min-h-11 px-2 text-xs font-black disabled:opacity-30",
						children: g("games.fliptown.bailWanted2")
					})
				]
			});
			break;
		case "cheat": {
			let e = t.poker.map((e, t) => ({
				c: e,
				i: t
			})).filter((e) => e.c !== null);
			x = /* @__PURE__ */ v("div", {
				className: "flex flex-col gap-1.5",
				children: [/* @__PURE__ */ v("div", {
					className: "flex items-center gap-1.5",
					children: [
						/* @__PURE__ */ _("span", {
							className: "text-xs font-bold",
							children: g("games.fliptown.cheatPick")
						}),
						e.map(({ c: e, i: t }) => /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => c(s === t ? null : t),
							className: `card grid min-h-11 min-w-9 place-items-center font-mono text-xs font-black ${s === t ? "ring-3 ring-ink" : ""}`,
							style: { color: it(e.suit) ? "#b91c1c" : "var(--color-ink)" },
							children: rt(e)
						}, t)),
						m?.map((e, t) => /* @__PURE__ */ _("span", {
							className: "grid min-h-11 min-w-9 place-items-center rounded-lg border-2 border-dashed border-ink/40 font-mono text-xs font-black",
							style: { color: it(e.suit) ? "#b91c1c" : "var(--color-ink)" },
							children: rt(e)
						}, `h${t}`)),
						/* @__PURE__ */ _("span", { className: "flex-1" }),
						/* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => h({
								type: "cheat",
								cardIndex: 0,
								as: null
							}),
							className: "btn-quiet min-h-11 px-3 text-xs font-bold",
							children: g("games.fliptown.cheatNone")
						})
					]
				}), s != null && /* @__PURE__ */ v("div", {
					className: "flex flex-wrap items-center gap-1.5",
					children: [
						[
							"H",
							"S",
							"D",
							"C"
						].map((e) => /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => d(l === e ? null : e),
							className: `card grid min-h-11 min-w-11 place-items-center text-base font-black ${l === e ? "ring-3 ring-ink" : ""}`,
							style: { color: Xe[e] },
							children: X[e]
						}, e)),
						nt.map((e, t) => /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => p(f === t + 1 ? null : t + 1),
							className: `card grid min-h-11 min-w-9 place-items-center font-mono text-xs font-black ${f === t + 1 ? "ring-3 ring-ink" : ""}`,
							children: e
						}, e)),
						/* @__PURE__ */ _("button", {
							type: "button",
							disabled: l == null || f == null,
							onClick: () => h({
								type: "cheat",
								cardIndex: s,
								as: {
									suit: l,
									rank: f
								}
							}),
							className: "btn-base min-h-11 px-4 text-sm font-black text-white disabled:opacity-40",
							style: { background: N.accent },
							children: g("games.fliptown.confirm")
						})
					]
				})]
			});
			break;
		}
		case "arrest":
			x = /* @__PURE__ */ v("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _("span", {
						className: "flex-1 text-xs font-bold",
						children: g("games.fliptown.arrestChoice")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: t.wanted >= 14,
						onClick: () => h({
							type: "arrestPay",
							choice: "cash"
						}),
						className: "card min-h-12 flex-1 px-2 text-sm font-black disabled:opacity-30",
						children: g("games.fliptown.arrestCash", { n: y.cash })
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h({
							type: "arrestPay",
							choice: "stars"
						}),
						className: "card min-h-12 flex-1 px-2 text-sm font-black",
						children: g("games.fliptown.arrestStars", { n: y.stars })
					})
				]
			});
			break;
		case "reshow": x = /* @__PURE__ */ v("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ _("span", {
					className: "flex-1 text-xs font-bold",
					children: g("games.fliptown.reshowPrompt")
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => h({ type: "reshow" }),
					className: "card min-h-11 flex-1 px-2 text-xs font-black",
					children: g("games.fliptown.reshow")
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => h({ type: "skip" }),
					className: "btn-quiet min-h-11 px-3 text-xs font-bold",
					children: g("games.fliptown.keepSheriff")
				})
			]
		});
	}
	return /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: x
	});
}
//#endregion
//#region src/games/fliptown/bot.ts
var Rt = [
	"H",
	"S",
	"D",
	"C"
], $ = {
	star: 1,
	cash: .25,
	gold: .5,
	wanted: -.3,
	pan: 1.6,
	hammer: 1.6,
	bonus: 3,
	silver: 4
};
function zt(e, t) {
	let n = ye(e, t);
	if (n <= e.trailPos) return -1;
	let r = 0;
	for (let t = e.trailPos + 1; t <= n; t++) {
		let n = C[t].reward;
		n.kind === "stars" ? r += n.n * $.star + (n.wanted ?? 0) * $.wanted : n.kind === "tool" ? r += $.pan : n.kind === "cash" ? r += n.n * $.cash : n.kind === "gold" ? r += n.n * $.gold : n.kind === "cemeteryBonus" ? r += n.stars + 1.5 : n.kind === "bonus" ? r += $.bonus : n.kind === "clearWanted" && (r += Math.min(n.n, e.wanted) * -$.wanted);
	}
	return r;
}
function Bt(e, t) {
	let n = w.findIndex((e) => e.rank === t);
	if (n === -1 || e.badlands[n]) return -1;
	let r = w[n], i = e.rifle ? 6 : e.pistol ? 3 : 0, a = Math.min(1, Math.max(0, (13 - r.rank + 1 + i) / 13));
	return a * (r.stars + r.cash * $.cash) + r.stars * (1 - a) * .5 + r.wanted * $.wanted + Vt(e, r.row);
}
function Vt(e, t) {
	return e.badlandsRowBonus[t] ? 0 : w.filter((e) => e.row === t).filter((t) => !e.badlands[w.indexOf(t)]).length === 1 ? $.bonus : 0;
}
function Ht(e, t) {
	let n = Se(e, t), r = -1, i;
	for (let e of n) {
		let t = Ut(e);
		t > r && (r = t, i = e);
	}
	return {
		score: r,
		room: n.length > 1 ? i : void 0
	};
}
function Ut(e) {
	let t = E[e].reward;
	switch (t.kind) {
		case "hammerGold": return $.hammer + $.gold;
		case "panGold": return $.pan + $.gold;
		case "bonus": return $.bonus + t.gold * $.gold;
		case "starsGold": return t.stars + t.gold * $.gold + t.wanted * $.wanted;
		case "silver": return $.silver + t.wanted * $.wanted;
	}
}
function Wt(e, t, n) {
	let r = t - 1, i = le[r], a = e.town[r] ? 0 : i.first.kind === "stars" ? i.first.n : $.bonus, o = 0;
	switch (i.effect.kind) {
		case "undertaker":
			o = e.undertaker === 0 ? 1.5 : 1;
			break;
		case "bank":
			o = e.cash >= 4 && e.bankBets.length < 2 ? 1.5 * n : .5;
			break;
		case "hideout":
			o = Math.min(4, e.wanted) * -$.wanted;
			break;
		case "stables":
			o = !e.trailHorse && e.cash >= 4 ? 3 : !e.workHorse && e.cash >= 3 ? 2 : .3;
			break;
		case "store":
			o = e.pans < 4 && e.cash >= 3 || !e.pickaxe && e.cash >= 2 ? 1.5 : .3;
			break;
		case "church":
			o = Math.min(8, e.wanted, e.cash) * -$.wanted * .8;
			break;
		case "hotel":
			o = e.hotelLevel < 4 && e.cash >= 2 ? 1 + e.hotelLevel : 0;
			break;
		case "landOffice":
			o = e.cash >= 4 ? 2 : .2;
			break;
		case "gunsmith":
			o = !e.pistol && !e.rifle && e.cash >= 3 || e.pistol && !e.rifle && e.cash >= 4 ? 2 : .2;
			break;
		case "bailBonds":
			o = e.bailRanks.length < 3 ? 2.5 : .2;
			break;
		case "sheriff":
			o = 1.5;
			break;
		case "saloon":
			o = Math.min(8, Math.floor(e.cash / 4)) * .9;
			break;
		case "prospector": o = Math.min(8, Math.floor(e.gold / 2)) * .9;
	}
	return a + o;
}
function Gt(e, t) {
	if (e.cemetery[t]) return -1;
	let n = (e.undertaker === 0 ? $.wanted : 0) + +(e.shovels > 0);
	for (let r = 0; r < de.length; r++) {
		if (e.cemeteryGaps[r]) continue;
		let { a: i, b: a, reward: o } = de[r];
		(i === t && e.cemetery[a] || a === t && e.cemetery[i]) && (n += Kt(o));
	}
	return n;
}
function Kt(e) {
	switch (e.kind) {
		case "bonus": return $.bonus;
		case "stars": return e.n;
		case "cash": return e.n * $.cash;
		case "gold": return e.n * $.gold;
		case "tool": return e.tool === "hammer" ? $.hammer : $.pan;
	}
}
function qt(e, t) {
	let n = e.poker.filter(Boolean), r = n.length >= 2 ? H(n) : -1, i = H([...n, t]);
	return r === -1 ? i === -1 ? 0 : (oe.length - i) * .15 : i !== -1 && i < r ? (r - i) * .3 : 0;
}
function Jt(e, t) {
	let n = e.public, r = n.boards[t], i = n.lineup, a = n.wilds.filter((e) => e.by === t).map((e) => e.idx), o = [];
	for (let [e, t, s] of [
		[
			0,
			1,
			2
		],
		[
			0,
			2,
			1
		],
		[
			1,
			0,
			2
		],
		[
			1,
			2,
			0
		],
		[
			2,
			0,
			1
		],
		[
			2,
			1,
			0
		]
	]) {
		if (a.includes(s)) continue;
		let c = a.includes(e), l = a.includes(t), u = i[s], d = c ? Rt.map((e) => ({
			suit: e,
			cost: 0,
			suitAs: e
		})) : [{
			suit: i[e].suit,
			cost: 0
		}, ...Rt.filter((t) => t !== i[e].suit).map((e) => ({
			suit: e,
			cost: 2,
			suitAs: e
		}))], f = i[t].rank, p = l ? Array.from({ length: 13 }, (e, t) => ({
			value: t + 1,
			cost: 0,
			valueAs: t + 1
		})) : [{
			value: f,
			cost: 0
		}, ...[
			-3,
			-2,
			-1,
			1,
			2,
			3
		].map((e) => ({
			value: f + e,
			cost: Math.abs(e),
			delta: e
		})).filter((e) => e.value >= 1 && e.value <= 13)];
		for (let i of d) for (let a of p) {
			if (i.cost + a.cost > r.gold) continue;
			let c = a.value;
			i.suit === "H" && r.trailHorse && (c += 6);
			let l, d;
			if (i.suit === "H") {
				if (c > 13) continue;
				l = zt(r, c);
			} else if (i.suit === "S") l = Bt(r, c);
			else if (i.suit === "D") {
				let e = Ht(r, c);
				l = e.score, d = e.room;
			} else l = Wt(r, c, n.round);
			if (l < 0) continue;
			l -= i.cost * $.gold + a.cost * $.gold, l += qt(r, u);
			let f = {
				type: "assign",
				suitIdx: e,
				valueIdx: t,
				pokerIdx: s,
				...i.suitAs ? { suitAs: i.suitAs } : {},
				...a.delta ? { valueDelta: a.delta } : {},
				...a.valueAs ? { valueAs: a.valueAs } : {},
				...d == null ? {} : { mineRoom: d }
			};
			o.push({
				action: f,
				score: l
			});
		}
		for (let e = 0; e < 9; e++) {
			let t = Gt(r, e) + qt(r, u);
			t > 0 && o.push({
				action: {
					type: "assignCemetery",
					tomb: e,
					pokerIdx: s
				},
				score: t
			});
		}
	}
	return o.sort((e, t) => t.score - e.score);
}
function Yt(e) {
	let t = (t) => !e.landCells[t], n = [];
	for (let e = 0; e < 9; e += 1) {
		let t = Math.floor(e / 3), r = e % 3;
		r < 2 && n.push({
			shape: 0,
			cells: [e, e + 1]
		}), t < 2 && n.push({
			shape: 0,
			cells: [e, e + 3]
		}), r === 0 && n.push({
			shape: 1,
			cells: [
				e,
				e + 1,
				e + 2
			]
		}), t === 0 && n.push({
			shape: 1,
			cells: [
				e,
				e + 3,
				e + 6
			]
		}), t < 2 && r < 2 && (n.push({
			shape: 2,
			cells: [
				e,
				e + 1,
				e + 3
			]
		}), n.push({
			shape: 2,
			cells: [
				e,
				e + 1,
				e + 4
			]
		}), n.push({
			shape: 2,
			cells: [
				e,
				e + 3,
				e + 4
			]
		}), n.push({
			shape: 2,
			cells: [
				e + 1,
				e + 3,
				e + 4
			]
		}));
	}
	for (let r of [
		2,
		1,
		0
	]) {
		let i = A.shapes[r].cost;
		if (e.cash < i) continue;
		let a = n.filter((e) => e.shape === r && e.cells.every(t)).sort((e, t) => t.cells.reduce((e, t) => e + A.cellStars[t], 0) - e.cells.reduce((e, t) => e + A.cellStars[t], 0))[0];
		if (a) return a;
	}
	return null;
}
function Xt(e, t) {
	let n = e.public.boards[t].poker.filter(Boolean);
	if (n.length === 0) return {
		type: "cheat",
		cardIndex: 0,
		as: null
	};
	let r = e.private?.hole ?? [], i = [...n, ...r], a = H(i), o = null;
	for (let e = 0; e < n.length; e++) for (let t of Rt) for (let n = 1; n <= 13; n++) {
		let r = H(i.map((r, i) => i === e ? {
			suit: t,
			rank: n
		} : r));
		r !== -1 && (a === -1 || r < a) && (!o || r < o.payout) && (o = {
			idx: e,
			as: {
				suit: t,
				rank: n
			},
			payout: r
		});
	}
	return o ? {
		type: "cheat",
		cardIndex: o.idx,
		as: o.as
	} : {
		type: "cheat",
		cardIndex: 0,
		as: null
	};
}
function Zt(e, t) {
	let n = e.public, r = n.boards[t], i = n.pending[t]?.[0];
	if (!i) return null;
	switch (i.kind) {
		case "tool": return {
			type: "resolveTool",
			tool: r.pans <= r.hammers && r.pans < 4 ? "pan" : "hammer"
		};
		case "bonus": {
			let e = i.suit;
			if (e === "H") {
				let e = r.trailPos < 12 ? 12 : -1;
				return e === -1 ? { type: "skip" } : {
					type: "bonusTrail",
					stop: e
				};
			}
			if (e === "S") {
				let e = w.map((e, t) => ({
					x: e,
					i: t
				})).filter(({ i: e }) => !r.badlands[e]).sort((e, t) => t.x.row - e.x.row)[0];
				return e ? {
					type: "bonusBadlands",
					target: e.i
				} : { type: "skip" };
			}
			if (e === "D") {
				let e = Ce(r);
				return e.length === 0 ? { type: "skip" } : {
					type: "bonusMine",
					room: e.sort((e, t) => Ut(t) - Ut(e))[0]
				};
			}
			if (e === "C") {
				let e = le.map((e, t) => t).sort((e, t) => Wt(r, t + 1, n.round) - Wt(r, e + 1, n.round))[0];
				return Wt(r, e + 1, n.round) > 0 ? {
					type: "bonusTown",
					building: e
				} : { type: "skip" };
			}
			let t = Array.from({ length: 9 }, (e, t) => t).filter((e) => !r.cemetery[e]).sort((e, t) => Gt(r, t) - Gt(r, e))[0];
			return t != null && Gt(r, t) >= 0 ? {
				type: "bonusCemetery",
				tomb: t
			} : { type: "skip" };
		}
		case "bank": return r.cash < 4 ? {
			type: "bank",
			color: null
		} : r.bankBets.includes("red") ? r.bankBets.includes("black") ? {
			type: "bank",
			color: null
		} : {
			type: "bank",
			color: "black"
		} : {
			type: "bank",
			color: "red"
		};
		case "hideout": return {
			type: "hideout",
			n: Math.min(4, r.wanted)
		};
		case "stables": return !r.trailHorse && r.cash >= 4 ? {
			type: "stables",
			horse: "trail"
		} : !r.workHorse && r.cash >= 3 ? {
			type: "stables",
			horse: "work"
		} : {
			type: "stables",
			horse: null
		};
		case "store": return r.pans < 4 && r.cash >= 3 ? {
			type: "store",
			item: "pan"
		} : !r.pickaxe && r.cash >= 2 ? {
			type: "store",
			item: "pickaxe"
		} : !r.bandana && r.cash >= 1 ? {
			type: "store",
			item: "bandana"
		} : {
			type: "store",
			item: null
		};
		case "church": return {
			type: "church",
			n: Math.min(8, r.wanted, Math.floor(r.cash / 2))
		};
		case "hotel": return {
			type: "hotel",
			buy: r.hotelLevel < 4 && r.cash >= 2
		};
		case "landOffice": {
			let e = Yt(r);
			return e ? {
				type: "landOffice",
				shape: e.shape,
				cells: e.cells
			} : {
				type: "landOffice",
				shape: 0,
				cells: null
			};
		}
		case "gunsmith": return !r.pistol && !r.rifle && r.cash >= 3 ? {
			type: "gunsmith",
			item: "pistol"
		} : r.pistol && !r.rifle && r.cash >= 4 ? {
			type: "gunsmith",
			item: "rifle"
		} : {
			type: "gunsmith",
			item: null
		};
		case "bailBonds": {
			let e = [
				11,
				12,
				13
			].find((e) => !r.bailRanks.includes(e));
			return e ? {
				type: "bailBonds",
				rank: e
			} : {
				type: "bailBonds",
				rank: null
			};
		}
		case "sheriff": return {
			type: "sheriff",
			choice: r.wanted >= 2 ? "wanted" : "stars"
		};
		case "saloon": return {
			type: "saloon",
			n: Math.min(8, Math.floor(r.cash / 4))
		};
		case "prospector": return {
			type: "prospector",
			n: Math.min(8, Math.floor(r.gold / 2))
		};
		case "bailTrigger": return r.wanted >= 2 ? {
			type: "bailTrigger",
			choice: "wanted"
		} : {
			type: "bailTrigger",
			choice: r.gold < 6 ? "gold" : "cash"
		};
		case "cheat": return Xt(e, t);
		case "arrest": return {
			type: "arrestPay",
			choice: "cash"
		};
		case "reshow": {
			let e = n.sheriffRevealed;
			return e && e.rank < r.wanted ? { type: "reshow" } : { type: "skip" };
		}
	}
}
function Qt(e, t) {
	let n = e.public, r = n.boards[t];
	if (r.character == null || r.characterUsed) return null;
	let i = M[r.character].skill;
	if (i.kind === "bonus") {
		if (n.phase !== "turns" || n.playerPhase[t] !== "done") return null;
		let e = i.suit;
		return e === "any" ? {
			type: "useCharacterAny",
			suit: "H"
		} : e === "H" && r.trailPos >= 12 || e === "S" && r.badlands.every(Boolean) || e === "D" && Ce(r).length === 0 || e === "cemetery" && r.cemetery.every(Boolean) ? null : { type: "useCharacter" };
	}
	if (i.kind === "clearWanted" && (n.phase === "turns" || n.phase === "poker")) {
		let e = i.per === "hammer" ? i.n * r.hammers : i.n;
		return r.wanted >= 5 && e > 0 ? { type: "useCharacter" } : null;
	}
	return i.kind === "goldPerWanted" && (n.phase === "turns" || n.phase === "poker") && r.wanted >= 5 ? { type: "useCharacter" } : null;
}
var $t = (e, t) => {
	let n = e.public, r = t.rid;
	if (n.phase === "done") return null;
	let i = n.boards[r], a = Zt(e, r);
	if (a) return { action: a };
	if (n.phase === "arrest") {
		if (n.arrestDeclared[r]) return null;
		let e = [
			4,
			6,
			8
		][n.round - 1], t = (i.wanted - 1) / 13 * e, a = i.wanted * .5;
		return i.wanted >= 1 && i.gold >= i.wanted && a < t ? { action: { type: "bribe" } } : { action: { type: "face" } };
	}
	if (n.phase !== "turns") return null;
	let o = Qt(e, r);
	if (o) return { action: o };
	if (n.playerPhase[r] !== "assign") return null;
	let s = Jt(e, r)[0];
	if (!s || s.score <= .2) {
		let e = Array.from({ length: 9 }, (e, t) => t).find((e) => !i.cemetery[e]);
		return e == null ? null : { action: {
			type: "assignCemetery",
			tomb: e,
			pokerIdx: 0
		} };
	}
	return { action: s.action };
}, en = {
	lineup(e, t) {
		let n = t.anchor("lineup");
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ _(b, {
				at: n,
				ms: 700
			})
		} : null;
	},
	rob(e, t) {
		let n = e.data;
		if (!e.rid || typeof n?.target != "number" || typeof n?.success != "boolean") return null;
		let r = t.anchor(`seat:${e.rid}`);
		if (!r) return null;
		let i = w[n.target];
		return {
			ms: 1100,
			node: /* @__PURE__ */ _(y, {
				at: r,
				ms: 1100,
				children: /* @__PURE__ */ v("span", {
					className: `rounded-lg border-2 border-ink px-2 py-1 text-sm font-black shadow-[2px_2px_0_var(--color-ink)] ${n.success ? "bg-done-soft text-done-ink" : "bg-danger-soft text-danger-ink"}`,
					children: [n.success ? "💰" : "💨", i ? ` +🚨${i.wanted}` : ""]
				})
			})
		};
	},
	circle(e, t) {
		if (!e.rid) return null;
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ _(y, {
				at: n,
				ms: 500,
				children: /* @__PURE__ */ _("span", {
					className: "rounded-md border-2 border-ink bg-surface px-1.5 py-0.5 text-xs font-black",
					children: "✓"
				})
			})
		} : null;
	},
	poker(e, t) {
		let n = e.data;
		if (!e.rid || typeof n?.cash != "number" || typeof n?.stars != "number" || n.cash === 0 && n.stars === 0) return null;
		let r = t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 1400,
			node: /* @__PURE__ */ _(y, {
				at: r,
				ms: 1400,
				children: /* @__PURE__ */ v("span", {
					className: "rounded-lg border-2 border-ink bg-warn-soft px-2 py-1 text-sm font-black text-warn-ink shadow-[2px_2px_0_var(--color-ink)]",
					children: [
						"🂡 +$",
						n.cash,
						" +",
						n.stars,
						"★"
					]
				})
			})
		} : null;
	},
	sheriff(e, t) {
		let n = t.anchor("lineup");
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ _(b, {
				at: n,
				ms: 900
			})
		} : null;
	},
	arrest(e, t) {
		let n = e.data;
		if (!e.rid || typeof n?.n != "number") return null;
		let r = t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 1400,
			node: /* @__PURE__ */ _(y, {
				at: r,
				ms: 1400,
				children: /* @__PURE__ */ v("span", {
					className: "rounded-lg border-2 border-ink bg-danger-soft px-2 py-1 text-sm font-black text-danger-ink shadow-[2px_2px_0_var(--color-ink)]",
					children: ["🚔 ", n.choice === "cash" ? `-$${n.n}` : `-${n.n}★`]
				})
			})
		} : null;
	},
	bounty(e, t) {
		let n = e.data;
		if (!e.rid || typeof n?.stars != "number") return null;
		let r = t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 1400,
			node: /* @__PURE__ */ _(y, {
				at: r,
				ms: 1400,
				children: /* @__PURE__ */ v("span", {
					className: "rounded-lg border-2 border-ink bg-done-soft px-2 py-1 text-sm font-black text-done-ink shadow-[2px_2px_0_var(--color-ink)]",
					children: [
						"🏅 +",
						n.stars,
						"★"
					]
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/fliptown/endgame-review.tsx
function tn({ board: e, renderResult: t, ...n }) {
	let s = u(), [c, l] = o(!0), [d, f] = o(null), p = a(null), m = a(null), h = a(null);
	r(() => {
		if (!d) return;
		h.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let g = (e) => {
		f(null), l(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, y = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), b = {
		...n,
		...y
	};
	return /* @__PURE__ */ v("div", {
		className: "fliptown-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ _("div", {
				className: "fliptown-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ _("div", {
				className: "fliptown-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ v("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), g(!1));
					},
					className: "fliptown-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ v("header", {
							className: "fliptown-endgame-heading",
							children: [/* @__PURE__ */ v("div", {
								className: "fliptown-endgame-brand",
								children: [/* @__PURE__ */ _("span", {
									"aria-hidden": "true",
									children: N.icon
								}), s(N.nameKey)]
							}), /* @__PURE__ */ _("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": s("games.fliptown.reviewHide"),
								title: s("games.fliptown.reviewHide"),
								onClick: () => g(!1),
								children: /* @__PURE__ */ _(te, { size: 19 })
							})]
						}),
						/* @__PURE__ */ _("div", {
							className: "fliptown-endgame-result",
							inert: d !== null,
							children: t(b)
						}),
						d && /* @__PURE__ */ v("div", {
							className: "fliptown-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ _("button", {
								type: "button",
								ref: h,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.fliptown.reviewConfirmAgain" : "games.fliptown.reviewConfirmLobby")
							}), /* @__PURE__ */ _("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: s("games.fliptown.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "fliptown-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ v("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => g(!0),
					children: [
						/* @__PURE__ */ _(S, { size: 18 }),
						s("games.fliptown.reviewShow"),
						/* @__PURE__ */ _(x, { size: 18 })
					]
				})
			})
		]
	});
}
function nn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: c, renderRowExtra: d, summary: f, navigation: p, content: m, afterRanking: y, scoreUnit: b, rankOf: x }) {
	let S = u(), re = l((e) => e.locale), [ie, ae] = o({}), oe = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? h(n, re) : e;
	}, se = (t, n) => x?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), C = e.ranking.some((t) => e.scores?.[t] !== void 0), w = (t, n) => /* @__PURE__ */ v("div", {
		className: "fliptown-score-identity",
		children: [
			/* @__PURE__ */ v("span", {
				className: "fliptown-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ _("span", {
					"aria-label": S("games.fliptown.reviewWinner"),
					children: "♛ "
				}), C && se(t, n)]
			}),
			/* @__PURE__ */ v("span", {
				className: "fliptown-score-name",
				children: [oe(t), t === r && /* @__PURE__ */ _("small", { children: S("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ v("small", {
				className: "fliptown-score-autopilot",
				children: [
					/* @__PURE__ */ _(ee, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), T = (t) => e.ranking.map((n) => /* @__PURE__ */ _("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ v("div", {
		className: "fliptown-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ _(ne, {}),
			p,
			/* @__PURE__ */ v("div", {
				className: "fliptown-score-body",
				children: [
					f && /* @__PURE__ */ _("div", {
						className: "fliptown-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ _("p", {
						className: "fliptown-score-hints",
						children: S("session.hint.usedCount", { n: i })
					}),
					m ?? (c?.length ? /* @__PURE__ */ _("div", {
						className: "fliptown-score-table-scroll",
						children: /* @__PURE__ */ v("table", {
							className: "fliptown-score-table",
							"aria-label": S(N.nameKey),
							children: [
								/* @__PURE__ */ _("thead", { children: /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", { scope: "col" }), /* @__PURE__ */ _(g, { children: e.ranking.map((t, n) => /* @__PURE__ */ _("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: w(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ _("tbody", { children: c.map((e, t) => /* @__PURE__ */ v(n, { children: [/* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ v("button", {
										type: "button",
										"aria-expanded": !!ie[t],
										onClick: () => ae((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ _(te, { size: 15 }), e.label]
									}) : e.label
								}), T(e)] }), ie[t] && e.details?.map((e, t) => /* @__PURE__ */ v("tr", {
									className: "fliptown-score-sub",
									children: [/* @__PURE__ */ _("th", {
										scope: "row",
										children: e.label
									}), T(e)]
								}, t))] }, t)) }),
								C && /* @__PURE__ */ _("tfoot", { children: /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
									scope: "row",
									children: S("games.fliptown.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ _("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ _("ol", {
						className: "fliptown-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ v("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ v("div", {
								className: "fliptown-score-rankline",
								children: [w(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ v("strong", {
									className: "fliptown-score-points",
									children: [e.scores[t], b && /* @__PURE__ */ _("small", { children: b })]
								})]
							}), d?.(t)]
						}, t))
					})),
					y,
					!!c?.length && d && /* @__PURE__ */ _("div", {
						className: "fliptown-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ v("details", { children: [/* @__PURE__ */ _("summary", { children: oe(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ v("footer", {
				className: "fliptown-score-actions",
				children: [
					s && /* @__PURE__ */ _("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: S("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ _("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: S("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ _("p", { children: S("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/fliptown/endgame-scores.tsx
function rn(e) {
	let t = u(), n = e.public, r = (e) => {
		let t = n.boards[e];
		return t ? [
			Math.floor(t.cash / 4),
			Math.floor(t.gold / 2),
			ke(t) + Ae(t),
			t.stars
		] : [];
	}, i = [
		"games.fliptown.scoreCash",
		"games.fliptown.scoreGold",
		"games.fliptown.scoreSilver",
		"games.fliptown.scoreStars"
	].map((e, n) => ({
		label: t(e),
		value: (e) => r(e)[n] ?? "—"
	}));
	return /* @__PURE__ */ _(nn, {
		...e,
		renderRowExtra: void 0,
		rows: i
	});
}
//#endregion
//#region src/games/fliptown/game-over.tsx
function an(e) {
	return /* @__PURE__ */ _(rn, { ...e });
}
function on(e) {
	return /* @__PURE__ */ _(tn, {
		...e,
		board: /* @__PURE__ */ _(Et, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ _(an, { ...e })
	});
}
//#endregion
//#region src/games/fliptown/game-over-row.tsx
function sn({ public: e, rid: t }) {
	let n = u(), r = e.boards[t];
	if (!r) return null;
	let i = [
		{
			key: "games.fliptown.scoreCash",
			v: Math.floor(r.cash / 4)
		},
		{
			key: "games.fliptown.scoreGold",
			v: Math.floor(r.gold / 2)
		},
		{
			key: "games.fliptown.scoreSilver",
			v: ke(r) + Ae(r)
		},
		{
			key: "games.fliptown.scoreStars",
			v: r.stars
		}
	];
	return /* @__PURE__ */ v("div", {
		className: "fliptown-over-details mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs font-bold text-ink-soft",
		children: [i.map((e) => /* @__PURE__ */ v("span", { children: [
			n(e.key),
			" ",
			e.v
		] }, e.key)), /* @__PURE__ */ v("span", {
			className: "font-black text-ink",
			children: [
				n("games.fliptown.scoreTotal"),
				" ",
				je(r)
			]
		})]
	});
}
//#endregion
//#region src/games/fliptown/options.tsx
var cn = [{
	key: "characters",
	label: "games.fliptown.options.characters",
	desc: "games.fliptown.options.charactersDesc"
}, {
	key: "holdem",
	label: "games.fliptown.options.holdem",
	desc: "games.fliptown.options.holdemDesc"
}];
function ln({ value: e, onChange: t }) {
	let n = u(), r = L.safeParse(e), i = r.success ? r.data : L.parse(void 0);
	return /* @__PURE__ */ _("div", {
		className: "flex flex-col gap-2",
		children: cn.map(({ key: e, label: r, desc: a }) => {
			let o = i[e] === !0;
			return /* @__PURE__ */ _(re, {
				checked: o,
				label: n(r),
				hint: n(a),
				accent: N.accent,
				onChange: () => t({
					...i,
					[e]: !o
				})
			}, e);
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/fliptown/entry.tsx
var un = {
	definition: Je,
	View: Et,
	bot: $t,
	fx: en,
	OverView: on,
	RowView: sn,
	Options: ln,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "勇闯牌皇镇",
			desc: "扑克牌驱动的西部拓荒:走商路、抢匪地、下矿洞、逛小镇,别被警长逮住",
			rules: "目标:三轮开拓后总分最高者获胜。\n· 总分构成:现金每 4 元计 1 分,黄金每 2 块计 1 分。\n· 另加银星(矿洞底层与旅馆产出,终局结算)与库存星星。\n· 平分先比通缉值少,再比黄金与现金多。\n准备:标准 52 张扑克牌洗牌;每人 4 元与 2 块黄金,墓地中央墓碑已圈。\n· 从 12 张赏金卡抽 3 张公共展示。\n流程:每轮依次进行六个阶段。\n· 重洗全部牌;扣一张警长卡(不看);进行五个回合。\n· 扑克结算;淘金与做工;警长逮捕。\n· 之后进入下一轮,三轮后游戏结束。\n回合:翻 3 张公共牌,每人同时各自指派三张牌的用途。\n· 一张作花色,决定去哪个区:红桃商路、黑桃匪地、方块矿洞、梅花小镇。\n· 一张作点数,决定去区内哪一点;一张记入本轮 5 格扑克列。\n· 不满意可放弃花色与点数,改去墓地圈一块墓碑(扑克牌仍须记入)。\n改牌:花 2 块黄金可把花色牌改成任意花色。\n· 花 1 块黄金可把点数加减 1(不限次数,A 与 K 之间不环绕)。\n四区:\n· 商路:点数不小于站值才能向右推进,可连续冲过多站。\n· 停下的站才圈下并获得奖励;跳过的站被划掉、永久失去。\n· 匪地:点数圈对应抢劫目标(已圈不可再抢),抽抢劫卡判定。\n· 卡值不小于目标点数则抢劫成功,获得全部通缉、星星与现金;失败只获得通缉与一半星星。\n· 每行三个目标全部圈完,获得行末奖励行动。\n· 矿洞:只能沿连线下降,点数须落在入口值域内;四层矿室,底层产终局银星。\n· 小镇:点数进对应建筑,首次到访另有建筑顶部奖励;已圈建筑可重复到访。\n奖励行动:板上各处会给出某区的奖励行动——免费、不限点数、可以连锁。\n扑克结算:每轮结束按你扑克列的 5 张牌比牌型。\n· 一对获得 2 元与 1 星,最高皇家同花顺获得 10 元与 9 星。\n淘金做工:每个淘金盘获得 1 块黄金,每个锤子获得 2 元。\n逮捕:每个通缉值可花 1 块黄金贿赂免捕;否则翻警长卡,卡值不小于你的通缉值则无事。\n· 否则二选一罚金:第 1/2/3 轮为 10/14/18 元或 4/6/8 星。\n· 通缉值达到 14 必须扣星。\n赏金卡:同一回合内先达成者获得卡面星数,回合结束翻到低档面。\n· 之后达成者获得低档星数;每人每张限一次。",
			roundShort: "第{{r}}轮 · 回合{{t}}/5",
			phasePoker: "扑克结算",
			phaseArrest: "警长逮捕",
			phaseDone: "对局结束",
			triggerPrompt: "回合开始:先处理触发",
			assignPrompt: "指派 3 张牌:花色 / 点数 / 扑克",
			resolvePrompt: "处理奖励与效果",
			donePrompt: "本回合完成,等待其他玩家…",
			arrestPrompt: "贿赂警长还是硬抗?",
			bribe: "贿赂(每通缉 1 黄金)",
			face: "硬抗到底",
			arrestChoice: "被捕!选择罚金",
			arrestCash: "付 ${{n}}",
			arrestStars: "扣 {{n}}★",
			waitingArrest: "等待其他人面对警长…",
			reshowPrompt: "要弃掉警长卡重抽吗?",
			reshow: "重抽警长卡",
			keepSheriff: "维持原卡",
			pokerResult: "扑克结算:{{name}}",
			panningNote: "淘金 +{{gold}} 金 · 做工 +${{cash}}",
			modSuit: "改花色(2 金)",
			modValueUp: "点数加 1(1 金)",
			modValueDown: "点数减 1(1 金)",
			pickaxeMod: "鹤嘴锄加减 2",
			toCemetery: "放弃,去墓地",
			trailStopPrompt: "商路:选择停在哪站",
			skip: "跳过",
			useSkill: "角色技能",
			skillUsed: "已使用",
			mayorConfirm: "弃掉当前公共牌重翻?",
			wildPick: "选择一张公共牌变百搭",
			holeCards: "暗牌",
			sheriffPeeked: "警长卡是 {{card}}",
			bountyTitle: "赏金",
			bountyFirst: "先得 {{n}}★",
			bountyLate: "后到 {{n}}★",
			scoreCash: "现金 ÷4",
			scoreGold: "黄金 ÷2",
			scoreSilver: "银星",
			scoreStars: "星星",
			scoreTotal: "总分",
			suitH: "商路",
			suitS: "匪地",
			suitD: "矿洞",
			suitC: "小镇",
			cemetery: "墓地",
			rankA: "A",
			poker: {
				royalFlush: "皇家同花顺",
				straightFlush: "同花顺",
				fourKind: "四条",
				fullHouse: "葫芦",
				flush: "同花",
				straight: "顺子",
				threeKind: "三条",
				twoPair: "两对",
				onePair: "一对",
				none: "无牌型"
			},
			town: {
				undertaker: "殡仪馆",
				bank: "银行",
				hideout: "藏身所",
				stables: "马厩",
				store: "杂货店",
				church: "教堂",
				hotel: "旅馆",
				landOffice: "土地局",
				gunsmith: "枪店",
				bailBonds: "保释所",
				sheriff: "警长室",
				saloon: "酒吧",
				prospector: "淘金俱乐部"
			},
			townHelp: {
				undertaker: "首访后墓地不再加通缉;再次到访获得铲子(此后圈墓碑时每块多获得 1★)",
				bank: "付 $4 押红或黑:之后每回合公共牌三张全同色系,获得等同于当前轮数的星星",
				hideout: "划掉至多 4 点通缉",
				stables: "买马:役马 $3(附带 1 锤子与 1★)/ 驿马 $4(商路点数加 6)",
				store: "买一件:淘金盘 $3 / 鹤嘴锄 $2 / 头巾 $1",
				church: "每支付 $1 划掉 1 点通缉,至多 8 点",
				hotel: "付 $2 按顺序圈银星(2/7/14/23),终局只计最后一颗",
				landOffice: "买地块填 3x3 地皮:$4 两格 / $6 三格 / $8 L 形;圈下的格获得印有的星星,填满整块多获得 7★",
				gunsmith: "买手枪 $3(抢劫卡点数加 3);再买步枪 $4(改为加 6,替换手枪)",
				bailBonds: "圈一个通缉犯(J/Q/K):之后公共牌出现该点数,三选一:获得 $4、获得 2 块黄金或划掉 2 点通缉",
				sheriff: "偷看警长卡,然后二选一:获得 1★ 或划掉 2 点通缉",
				saloon: "每支付 $2 获得 1★,至多 8★",
				prospector: "每支付 1 块黄金获得 1★,至多 8★"
			},
			bounty: {
				b0: "四区每区至少圈 4 个点",
				b1: "收集任意 4 种道具(淘金盘/锤子/马/鹤嘴锄/手枪)",
				b2: "持有 $30+ 或 15+ 黄金",
				b3: "圈任意 5 块墓碑(不含中央)",
				b4: "五个区域(含墓地)各获得过至少一次奖励行动",
				b5: "鸡/牛/马车/火车各圈至少一个",
				b6: "淘金盘+锤子合计 5+",
				b7: "获得小镇全部 ★ 首访奖励",
				b8: "圈完商路全部 4 个奖励行动站",
				b9: "矿洞里累计获得 9+ 黄金",
				b10: "到达商路 K 站,或在保释所圈两个通缉犯",
				b11: "通缉值达到 9+"
			},
			char: {
				trailblazer: "开拓者",
				cheat: "老千",
				prospector: "淘金客",
				settler: "定居者",
				bandit: "匪徒",
				marshal: "警长",
				preacher: "牧师",
				miner: "矿工",
				ranchHand: "牧场工",
				graveRobber: "盗墓贼",
				manInBlack: "黑衣人",
				baroness: "男爵夫人",
				mayor: "镇长",
				wildCard: "百搭客"
			},
			charSkill: {
				trailblazer: "一次性:商路奖励行动",
				cheat: "一次性:扑克结算时宣称一张扑克牌为任意花色点数",
				prospector: "一次性:按淘金盘数免费改点数",
				settler: "一次性:小镇奖励行动",
				bandit: "一次性:匪地奖励行动",
				marshal: "一次性:逮捕阶段弃警长卡重抽",
				preacher: "一次性:警长逮捕阶段之前,划掉至多 6 点通缉",
				miner: "一次性:矿洞奖励行动",
				ranchHand: "一次性:每个锤子可划掉 2 点通缉",
				graveRobber: "一次性:墓地奖励行动",
				manInBlack: "一次性:任意一区奖励行动",
				baroness: "一次性:获得等于通缉值的黄金",
				mayor: "一次性:任何人行动前弃公共牌重翻 3 张",
				wildCard: "两次:把一张公共牌变百搭(仅自己)"
			},
			options: {
				characters: "角色变体",
				charactersDesc: "每人随机一张角色卡:不同起始资源 + 一次性技能",
				holdem: "Hold'em 变体",
				holdemDesc: "每轮每人发 2 张暗牌,扑克结算 7 选 5"
			},
			log: {
				start: "对局开始",
				turn: "回合 {{n}} 开始",
				trail: "商路推进到站 {{n}}",
				robOk: "抢劫成功(目标 {{n}})",
				robFail: "抢劫失败(目标 {{n}})",
				mine: "矿洞深入 {{n}} 号室",
				town: "到访建筑 {{n}}",
				cemetery: "圈了墓碑 {{n}}",
				bank: "银行押中,+{{n}}★",
				poker: "扑克结算:+$ {{cash}} +{{stars}}★",
				panning: "淘金做工:+{{gold}} 金 +${{cash}}",
				bribe: "贿赂警长,付 {{n}} 金",
				arrestPass: "警长卡放行",
				arrestCash: "被捕,付 ${{n}}",
				arrestStars: "被捕,扣 {{n}}★",
				reshow: "警长卡被重抽",
				bounty: "达成赏金 #{{id}},+{{n}}★",
				character: "使用角色技能",
				wild: "把公共牌 {{n}} 变百搭",
				mayor: "镇长重翻公共牌",
				gameOver: "三轮结束,终局计分"
			},
			confirm: "确认",
			cancel: "取消",
			pickPoker: "先点选一张作扑克牌",
			pickSuit: "再点选一张作花色牌(剩下的是点数牌)",
			slotSuit: "花色",
			slotValue: "点数",
			slotPoker: "扑克",
			goTarget: "点选纸上的高亮目标",
			deckLeft: "牌堆 {{n}} 张",
			resCash: "现金",
			resGold: "黄金",
			resStars: "星星",
			resWanted: "通缉",
			itemPan: "淘金盘",
			itemHammer: "锤子",
			itemShovel: "铲子",
			pickaxe: "鹤嘴锄",
			bandana: "头巾",
			pistol: "手枪",
			rifle: "步枪",
			workHorse: "役马",
			trailHorse: "驿马",
			toolPrompt: "选一件工具",
			bonusPrompt: "奖励行动({{suit}}):点选高亮目标",
			bankPrompt: "银行:押注之后公共牌三张同色系",
			betRed: "押红",
			betBlack: "押黑",
			betNone: "不押",
			clearWantedN: "划掉 {{n}} 通缉",
			buyWork: "役马 $3",
			buyTrail: "驿马 $4",
			buyNone: "不买",
			buyPan: "淘金盘 $3",
			buyPickaxe: "鹤嘴锄 $2",
			buyBandana: "头巾 $1",
			hotelPrompt: "旅馆:付 $2 圈下一颗银星",
			buySilver: "圈银星 $2",
			passBuy: "不圈",
			landPrompt: "土地局:选形状,再点空地放置(可连续买)",
			landEnd: "结束购买",
			shapeDomino: "$4 两格",
			shapeTrio: "$6 三格",
			shapeEll: "$8 L 形",
			buyPistol: "手枪 $3",
			buyRifle: "步枪 $4",
			bailPrompt: "保释所:圈一个通缉犯(J/Q/K)",
			bailNone: "不圈",
			sheriffChoicePrompt: "警长室:获得 1★ 或划掉 2 点通缉",
			takeStar: "拿 1★",
			clear2: "划 2 通缉",
			saloonPrompt: "酒吧:每 $2 换 1★(至多 8★)",
			prospectorPrompt: "淘金俱乐部:每 1 金换 1★(至多 8★)",
			convertN: "换 {{n}}★",
			bailTriggerPrompt: "通缉犯现身:三选一",
			bailCash: "拿 $4",
			bailGold: "拿 2 金",
			bailWanted2: "划 2 通缉",
			cheatPick: "老千:先点选要宣称的扑克牌",
			cheatNone: "不宣称",
			anySuitPrompt: "黑衣人:选一区奖励行动",
			wildShort: "百搭",
			errBadPhase: "当前阶段不能这么做",
			errNotYourStep: "现在轮不到这一步",
			errBadAssign: "指派不合法:三张牌须各派一用",
			errNoGold: "黄金不足",
			errNoCash: "现金不足",
			errBadTrail: "商路停站不合法",
			errBadTarget: "该抢劫目标已被圈",
			errBadMine: "该点数进不了矿洞",
			errBadTomb: "这块墓碑已被圈",
			errBadPending: "先处理当前事项",
			errBadChoice: "选择不合法",
			errNoSkill: "技能不可用或已用完",
			errOver: "对局已结束"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Fliptown",
			desc: "Poker-driven Wild West: ride the trail, rob the badlands, dig the mine, dodge the sheriff",
			rules: "Goal: after three rounds, the highest total wins.\n· Total score: every $4 of cash scores 1 point, every 2 gold scores 1 point.\n· Plus silver stars (from the deepest Mine chamber and the Hotel, scored at the end) and stars in your inventory.\n· Ties break on fewer Wanted, then more gold, then more cash.\nSetup: shuffle a standard 52-card deck; each player starts with $4 and 2 gold, with the center tombstone pre-circled.\n· Reveal 3 of the 12 Bounty cards face up.\nEach round has six phases in order.\n· Reshuffle everything; set aside one Sheriff card face down; play five turns.\n· Score poker hands; pan and work; the Sheriff makes arrests.\n· Then the next round begins; the game ends after round three.\nTurn: 3 shared cards are revealed and every player simultaneously assigns a role to each.\n· One card sets the suit, choosing a region: hearts Trail, spades Badlands, diamonds Mine, clubs Town.\n· One card sets the value, choosing the spot within that region; one goes into your 5-card poker column for the round.\n· You may forgo the suit and value cards and circle a tombstone in the Cemetery instead (the poker card is still recorded).\nModifying cards: pay 2 gold to change the suit card to any suit.\n· Pay 1 gold to adjust the value card by 1 (any number of times, no wrapping between A and K).\nRegions:\n· Trail: your value must meet the station value to advance right; you may rush past several stations.\n· Only the station you stop at is circled for its reward; skipped stations are crossed out forever.\n· Badlands: circle the robbery target matching your value (taken targets are gone); draw a robbery card.\n· If the card value meets or beats the target, the robbery succeeds: gain all its Wanted, stars and cash; otherwise gain only the Wanted and half the stars.\n· Circle all three targets of a row to earn its end-of-row bonus action.\n· Mine: descend along links only; your value must fall within an entry range; four levels, the deepest yields end-game silver stars.\n· Town: enter the building matching your value; the first visit also grants the bonus printed at the top; circled buildings can be revisited.\nBonus actions: many sites grant a bonus action in some region — free, value-free, and they can chain.\nPoker: at round end your 5-card poker column scores by hand rank.\n· One pair earns $2 and 1 star, up to a royal flush earning $10 and 9 stars.\nPanning and work: each gold pan earns 1 gold; each hammer earns $2.\nArrest: pay 1 gold per Wanted to bribe your way out; otherwise reveal the Sheriff card — if its value meets or beats your Wanted you are safe.\n· Otherwise choose a fine (round 1/2/3: $10/$14/$18 or 4/6/8 stars).\n· At 14 Wanted you must lose stars.\nBounties: the first player to meet one within the same turn scores its printed stars, then the card flips to its lower side.\n· Later achievers score the lower amount; each player scores each Bounty once.",
			roundShort: "Round {{r}} · Turn {{t}}/5",
			phasePoker: "Poker scoring",
			phaseArrest: "Sheriff arrests",
			phaseDone: "Game over",
			triggerPrompt: "Turn start: resolve triggers",
			assignPrompt: "Assign the 3 cards: suit / value / poker",
			resolvePrompt: "Resolve rewards and effects",
			donePrompt: "Turn done, waiting for others…",
			arrestPrompt: "Bribe the sheriff or face the card?",
			bribe: "Bribe (1 gold per Wanted)",
			face: "Face it",
			arrestChoice: "Arrested! Choose your fine",
			arrestCash: "Pay ${{n}}",
			arrestStars: "Lose {{n}}★",
			waitingArrest: "Waiting for others to face the sheriff…",
			reshowPrompt: "Discard the sheriff card and redraw?",
			reshow: "Redraw",
			keepSheriff: "Keep it",
			pokerResult: "Poker: {{name}}",
			panningNote: "Panning +{{gold}} gold · work +${{cash}}",
			modSuit: "Change suit (2 gold)",
			modValueUp: "Raise value by 1 (1 gold)",
			modValueDown: "Lower value by 1 (1 gold)",
			pickaxeMod: "Pickaxe: adjust by 2",
			toCemetery: "Pass, go to Cemetery",
			trailStopPrompt: "Trail: choose where to stop",
			skip: "Skip",
			useSkill: "Character skill",
			skillUsed: "Used",
			mayorConfirm: "Discard the lineup and reveal 3 new cards?",
			wildPick: "Pick a lineup card to make wild",
			holeCards: "Hole cards",
			sheriffPeeked: "The sheriff card is {{card}}",
			bountyTitle: "Bounties",
			bountyFirst: "First {{n}}★",
			bountyLate: "Later {{n}}★",
			scoreCash: "Cash ÷4",
			scoreGold: "Gold ÷2",
			scoreSilver: "Silver stars",
			scoreStars: "Stars",
			scoreTotal: "Total",
			suitH: "Trail",
			suitS: "Badlands",
			suitD: "Mine",
			suitC: "Town",
			cemetery: "Cemetery",
			rankA: "A",
			poker: {
				royalFlush: "Royal flush",
				straightFlush: "Straight flush",
				fourKind: "Four of a kind",
				fullHouse: "Full house",
				flush: "Flush",
				straight: "Straight",
				threeKind: "Three of a kind",
				twoPair: "Two pair",
				onePair: "One pair",
				none: "No hand"
			},
			town: {
				undertaker: "Undertaker",
				bank: "Bank",
				hideout: "Hideout",
				stables: "Stables",
				store: "General Store",
				church: "Church",
				hotel: "Hotel",
				landOffice: "Land Office",
				gunsmith: "Gunsmith",
				bailBonds: "Bail Bonds",
				sheriff: "Sheriff's Office",
				saloon: "Saloon",
				prospector: "Prospector's Club"
			},
			townHelp: {
				undertaker: "After the first visit the Cemetery adds no Wanted; a later visit grants a shovel (each tombstone you circle earns 1★ more)",
				bank: "Pay $4 to bet red or black: whenever a lineup is all that color, gain stars equal to the current round number",
				hideout: "Clear up to 4 Wanted",
				stables: "Buy a horse: Work Horse $3 (comes with 1 hammer and 1★) / Trail Horse $4 (+6 to Trail value)",
				store: "Buy one: gold pan $3 / pickaxe $2 / bandana $1",
				church: "Every $1 paid clears 1 Wanted, up to 8",
				hotel: "Pay $2 to circle silver stars in order (2/7/14/23); only the last one counts",
				landOffice: "Buy plots for your 3x3 land: $4 domino / $6 line / $8 L-shape; circled cells earn their printed stars, and filling all 9 earns 7★ more",
				gunsmith: "Buy Pistol $3 (+3 to robbery cards); then Rifle $4 (+6 instead, replacing the Pistol)",
				bailBonds: "Circle an outlaw (J/Q/K): whenever the lineup shows that rank, choose one: gain $4, gain 2 gold, or clear 2 Wanted",
				sheriff: "Peek at the sheriff card, then choose: take 1★ or clear 2 Wanted",
				saloon: "Every $2 paid earns 1★, up to 8★",
				prospector: "Every 1 gold paid earns 1★, up to 8★"
			},
			bounty: {
				b0: "Circle at least 4 sites in each region",
				b1: "Collect any 4 item types (pan/hammer/horse/pickaxe/pistol)",
				b2: "Hold $30+ or 15+ gold",
				b3: "Circle any 5 tombstones (excluding the center)",
				b4: "Gain a bonus action in each of the five regions (Cemetery included)",
				b5: "Circle at least one of each robbery row",
				b6: "Have 5+ pans and hammers in total",
				b7: "Gain every ★ first-visit bonus in Town",
				b8: "Circle all 4 bonus-action stations on the Trail",
				b9: "Earn 9+ gold in the Mine",
				b10: "Reach Trail station K, or circle two outlaws at Bail Bonds",
				b11: "Reach 9+ Wanted"
			},
			char: {
				trailblazer: "Trailblazer",
				cheat: "Cheat",
				prospector: "Prospector",
				settler: "Settler",
				bandit: "Bandit",
				marshal: "Marshal",
				preacher: "Preacher",
				miner: "Miner",
				ranchHand: "Ranch Hand",
				graveRobber: "Grave Robber",
				manInBlack: "Man in Black",
				baroness: "Baroness",
				mayor: "Mayor",
				wildCard: "Wild Card"
			},
			charSkill: {
				trailblazer: "Once: a Trail bonus action",
				cheat: "Once: declare one poker card as any suit and value at scoring",
				prospector: "Once: modify value for free up to your pan count",
				settler: "Once: a Town bonus action",
				bandit: "Once: a Badlands bonus action",
				marshal: "Once: discard the revealed sheriff card and redraw",
				preacher: "Once: clear up to 6 Wanted before the Sheriff arrest phase",
				miner: "Once: a Mine bonus action",
				ranchHand: "Once: clear 2 Wanted per hammer",
				graveRobber: "Once: a Cemetery bonus action",
				manInBlack: "Once: a bonus action in any region",
				baroness: "Once: gain gold equal to your Wanted",
				mayor: "Once: before anyone acts, discard the lineup and reveal 3 new cards",
				wildCard: "Twice: make a lineup card wild (for you only)"
			},
			options: {
				characters: "Characters variant",
				charactersDesc: "Each player gets a random character: different starting resources + a one-shot skill",
				holdem: "Hold'em variant",
				holdemDesc: "Deal 2 hole cards per player each round; poker scores best 5 of 7"
			},
			log: {
				start: "Game start",
				turn: "Turn {{n}} begins",
				trail: "Advanced to Trail station {{n}}",
				robOk: "Robbery succeeded (target {{n}})",
				robFail: "Robbery failed (target {{n}})",
				mine: "Dug into Mine chamber {{n}}",
				town: "Visited building {{n}}",
				cemetery: "Circled tombstone {{n}}",
				bank: "Bank bet hit, +{{n}}★",
				poker: "Poker: +$ {{cash}} +{{stars}}★",
				panning: "Panning and work: +{{gold}} gold +${{cash}}",
				bribe: "Bribed the sheriff for {{n}} gold",
				arrestPass: "The sheriff card let them go",
				arrestCash: "Arrested, paid ${{n}}",
				arrestStars: "Arrested, lost {{n}}★",
				reshow: "Sheriff card redrawn",
				bounty: "Bounty #{{id}} achieved, +{{n}}★",
				character: "Used character skill",
				wild: "Made lineup card {{n}} wild",
				mayor: "The Mayor flipped a new lineup",
				gameOver: "Three rounds done, final scoring"
			},
			confirm: "Confirm",
			cancel: "Cancel",
			pickPoker: "Tap a card for your poker column",
			pickSuit: "Tap another as the suit card (the last one is the value)",
			slotSuit: "Suit",
			slotValue: "Value",
			slotPoker: "Poker",
			goTarget: "Tap a highlighted spot on the sheet",
			deckLeft: "Deck: {{n}}",
			resCash: "Cash",
			resGold: "Gold",
			resStars: "Stars",
			resWanted: "Wanted",
			itemPan: "Pan",
			itemHammer: "Hammer",
			itemShovel: "Shovel",
			pickaxe: "Pickaxe",
			bandana: "Bandana",
			pistol: "Pistol",
			rifle: "Rifle",
			workHorse: "Work Horse",
			trailHorse: "Trail Horse",
			toolPrompt: "Pick a tool",
			bonusPrompt: "Bonus action ({{suit}}): tap a highlighted spot",
			bankPrompt: "Bank: bet the next lineups will be all one color",
			betRed: "Bet red",
			betBlack: "Bet black",
			betNone: "No bet",
			clearWantedN: "Clear {{n}} Wanted",
			buyWork: "Work Horse $3",
			buyTrail: "Trail Horse $4",
			buyNone: "No thanks",
			buyPan: "Gold pan $3",
			buyPickaxe: "Pickaxe $2",
			buyBandana: "Bandana $1",
			hotelPrompt: "Hotel: pay $2 to circle the next silver star",
			buySilver: "Circle a star $2",
			passBuy: "Skip",
			landPrompt: "Land Office: pick a shape, then tap a plot (repeatable)",
			landEnd: "Done buying",
			shapeDomino: "$4 pair",
			shapeTrio: "$6 line",
			shapeEll: "$8 L-shape",
			buyPistol: "Pistol $3",
			buyRifle: "Rifle $4",
			bailPrompt: "Bail Bonds: circle an outlaw (J/Q/K)",
			bailNone: "Skip",
			sheriffChoicePrompt: "Sheriff's Office: take 1★ or clear 2 Wanted",
			takeStar: "Take 1★",
			clear2: "Clear 2 Wanted",
			saloonPrompt: "Saloon: every $2 earns 1★ (max 8★)",
			prospectorPrompt: "Prospector's Club: every 1 gold earns 1★ (max 8★)",
			convertN: "Trade for {{n}}★",
			bailTriggerPrompt: "Outlaw spotted: choose one",
			bailCash: "Take $4",
			bailGold: "Take 2 gold",
			bailWanted2: "Clear 2 Wanted",
			cheatPick: "Cheat: tap the poker card to declare",
			cheatNone: "No declare",
			anySuitPrompt: "Man in Black: pick a region for the bonus action",
			wildShort: "Wild",
			errBadPhase: "Not allowed in this phase",
			errNotYourStep: "Not your step right now",
			errBadAssign: "Invalid assignment: the three cards each need a distinct role",
			errNoGold: "Not enough gold",
			errNoCash: "Not enough cash",
			errBadTrail: "Invalid Trail stop",
			errBadTarget: "That robbery target is already circled",
			errBadMine: "That value cannot enter the Mine",
			errBadTomb: "That tombstone is already circled",
			errBadPending: "Resolve the current matter first",
			errBadChoice: "Invalid choice",
			errNoSkill: "Skill unavailable or already used",
			errOver: "The game is over"
		}
	}
};
//#endregion
export { un as default };
