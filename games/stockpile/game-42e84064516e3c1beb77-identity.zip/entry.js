import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { DeltaNumber as r } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { Texture as s } from "@bgparty/sdk/texture";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as l } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as ee } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as te, seatName as ne } from "@bgparty/sdk/ui/player-strip";
import { useFxAnchor as u } from "@bgparty/sdk/fx/anchors";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Floater as m, PulseBox as h } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as g } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/stockpile/data.ts
var _ = [
	"cosmic",
	"bottomline",
	"leading",
	"automotive",
	"stanford",
	"epic"
], v = {
	cosmic: {
		id: "cosmic",
		emoji: "💻",
		track: "#2563eb"
	},
	bottomline: {
		id: "bottomline",
		emoji: "🏦",
		track: "#16a34a"
	},
	leading: {
		id: "leading",
		emoji: "🔬",
		track: "#9333ea"
	},
	automotive: {
		id: "automotive",
		emoji: "🚗",
		track: "#ea580c"
	},
	stanford: {
		id: "stanford",
		emoji: "🏗️",
		track: "#64748b"
	},
	epic: {
		id: "epic",
		emoji: "⚡",
		track: "#eab308"
	}
}, re = [
	1,
	2,
	4,
	-2,
	-3,
	"$$"
];
function y() {
	let e = [];
	for (let t of _) for (let n = 0; n < 10; n++) e.push({
		kind: "stock",
		company: t
	});
	for (let t of [
		1,
		2,
		3
	]) for (let n = 0; n < 4; n++) e.push({
		kind: "fee",
		amount: t
	});
	for (let t = 0; t < 4; t++) e.push({
		kind: "action",
		action: "boom"
	}), e.push({
		kind: "action",
		action: "bust"
	});
	return e;
}
var b = [
	0,
	1,
	3,
	6,
	10,
	15,
	20,
	25
], ie = {
	3: 7,
	4: 6,
	5: 5
}, x = 1400, S = 1600, C = {
	cosmic: "games.stockpile.compCosmic",
	bottomline: "games.stockpile.compBottomline",
	leading: "games.stockpile.compLeading",
	automotive: "games.stockpile.compAutomotive",
	stanford: "games.stockpile.compStanford",
	epic: "games.stockpile.compEpic"
};
function w(e) {
	return e === "$$" ? "$$" : e > 0 ? `+${e}` : `−${-e}`;
}
//#endregion
//#region src/games/stockpile/meta.ts
var T = {
	id: "stockpile",
	tier: "alpha",
	mechanics: ["auction", "stock-holding"],
	interactionTags: [],
	nameKey: "games.stockpile.name",
	descKey: "games.stockpile.desc",
	rulesKey: "games.stockpile.rules",
	icon: "📈",
	iconImg: "games/stockpile.webp",
	rulesUrl: {
		zh: "https://www.nauvoogames.com/rules/Chinese_Stockpile_Rules.pdf",
		en: "https://www.nauvoogames.com/rules/Stockpile_Rules.pdf"
	},
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [4, 5],
	accent: "#15803d",
	releasedAt: "2026-10-01",
	search: {
		py: "zong heng gu hai",
		init: "zhgh"
	},
	hotseat: "cover"
}, E = t.string(), D = t.enum([
	"cosmic",
	"bottomline",
	"leading",
	"automotive",
	"stanford",
	"epic"
]), O = t.union([
	t.literal(1),
	t.literal(2),
	t.literal(4),
	t.literal(-2),
	t.literal(-3),
	t.literal("$$")
]), k = t.enum(["boom", "bust"]), A = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("stock"),
		company: D
	}),
	t.object({
		kind: t.literal("fee"),
		amount: t.union([
			t.literal(1),
			t.literal(2),
			t.literal(3)
		])
	}),
	t.object({
		kind: t.literal("action"),
		action: k
	})
]), j = t.object({
	company: D,
	forecast: O
}), M = t.partialRecord(D, t.int().min(0)), N = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("place"),
		upCard: t.int().min(0).max(1),
		upPile: t.int().min(0),
		downPile: t.int().min(0)
	}),
	t.object({
		type: t.literal("bid"),
		pile: t.int().min(0),
		slot: t.int().min(0).max(7)
	}),
	t.object({
		type: t.literal("play"),
		card: k,
		company: D
	}),
	t.object({
		type: t.literal("sell"),
		regular: M,
		split: M,
		convert: M
	}),
	t.object({
		type: t.literal("dividend"),
		regular: t.int().min(0),
		split: t.int().min(0)
	})
]), ae = t.object({
	up: t.array(A),
	downCount: t.int().min(0),
	bid: t.object({
		rid: E,
		slot: t.int()
	}).nullable()
}), P = t.object({
	rid: E,
	cash: t.int(),
	split: M,
	regularCount: t.int().min(0),
	feesHeld: t.int().min(0),
	playedActions: t.array(t.object({
		card: k,
		company: D
	})),
	bid: t.object({
		pile: t.int(),
		slot: t.int()
	}).nullable()
}), oe = t.object({
	owner: E.nullable(),
	faceDown: t.boolean(),
	pair: j.nullable()
}), se = t.object({
	rid: E,
	cash: t.int(),
	majority: t.int(),
	sellValue: t.int(),
	feesPaid: t.int(),
	total: t.int()
}), ce = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("bid"),
		rid: E,
		pile: t.int(),
		value: t.int()
	}),
	t.object({
		k: t.literal("settle"),
		rid: E,
		pile: t.int(),
		paid: t.int()
	}),
	t.object({
		k: t.literal("play"),
		rid: E,
		card: k,
		company: D
	}),
	t.object({
		k: t.literal("sell"),
		rid: E,
		gained: t.int()
	}),
	t.object({
		k: t.literal("reveal"),
		owner: E.nullable(),
		company: D,
		forecast: t.string(),
		to: t.int().nullable()
	}),
	t.object({
		k: t.literal("split"),
		company: D,
		to: t.int()
	}),
	t.object({
		k: t.literal("bankrupt"),
		company: D
	}),
	t.object({
		k: t.literal("dividend"),
		rid: E,
		company: D,
		gained: t.int()
	}),
	t.object({
		k: t.literal("round"),
		round: t.int()
	})
]), F = t.object({
	phase: t.enum([
		"supply",
		"demand",
		"settle",
		"action",
		"sell",
		"movement",
		"done"
	]),
	round: t.int().min(1),
	roundsTotal: t.int().min(1),
	order: t.array(E),
	prices: t.record(D, t.int()),
	deckLeft: t.int().min(0),
	piles: t.array(ae),
	players: t.array(P),
	awaiting: t.array(E),
	insiderPublic: j,
	insiderDownCount: t.int().min(0),
	moveQueue: t.array(oe),
	dividend: t.object({
		company: D,
		claimed: t.array(E)
	}).nullable(),
	final: t.array(se).nullable(),
	log: t.array(ce)
}), le = t.object({
	myInsider: j,
	mySupplyHand: t.array(A).nullable(),
	myRegular: M,
	myPendingActions: t.array(k),
	myPlacedDown: t.array(t.object({
		pile: t.int(),
		card: A
	}))
});
//#endregion
//#region src/games/stockpile/rules.ts
function I(e, t) {
	e.log.push(t), e.log.length > 80 && (e.log = e.log.slice(-80));
}
function L(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function R(e, t) {
	return (e.regular[t] ?? 0) + (e.split[t] ?? 0);
}
function z(e, t) {
	e.cash += t;
	let n = Math.min(e.feesHeld, e.cash);
	e.feesHeld -= n, e.cash -= n;
}
function B(e, t, n) {
	let r = e.prices[t], i = r + n;
	if (i < 1) {
		let n = {};
		for (let r of e.order) {
			let i = R(e.ps[r], t);
			i > 0 && (n[r] = i, delete e.ps[r].regular[t], delete e.ps[r].split[t]);
		}
		return e.prices[t] = 5, I(e, {
			k: "bankrupt",
			company: t
		}), {
			from: r,
			to: 5,
			bankrupt: { lost: n }
		};
	}
	if (i > 10) {
		let n = 6 + (i - 10 - 1), a = {}, o = {};
		for (let n of e.order) {
			let r = e.ps[n], i = r.regular[t] ?? 0, s = r.split[t] ?? 0;
			i > 0 && (a[n] = i, r.split[t] = s + i, delete r.regular[t]), s > 0 && (o[n] = s * 10, z(r, s * 10));
		}
		return e.prices[t] = n, I(e, {
			k: "split",
			company: t,
			to: n
		}), {
			from: r,
			to: n,
			split: {
				moved: a,
				payouts: o
			}
		};
	}
	return e.prices[t] = i, {
		from: r,
		to: i
	};
}
function ue(e) {
	let t = e.order.length, n = L(e, [..._]), r = L(e, [...re]), i = n.map((e, t) => ({
		company: e,
		forecast: r[t]
	}));
	e.insider = {
		mine: Object.fromEntries(e.order.map((e, t) => [e, i[t]])),
		pub: i[t],
		down: i.slice(t + 1)
	}, e.piles = Array.from({ length: t }, () => ({
		up: [e.deck.pop()],
		down: []
	}));
	let a = [];
	for (let t of e.order) {
		let n = e.ps[t];
		n.supplyHand = [e.deck.pop(), e.deck.pop()], n.placedDown = [], n.pendingActions = [], n.playedActions = [], n.bid = null, a.push({
			kind: "deal",
			rid: t,
			data: { round: e.round },
			for: [t],
			secret: {
				insider: e.insider.mine[t],
				hand: n.supplyHand
			}
		});
	}
	return e.phase = "supply", e.supplyTurn = 0, e.bidTurn = null, e.settleIdx = 0, e.actionTurn = 0, e.sellTurn = 0, e.moveQueue = [], e.moveRevealed = [], e.dividend = null, a;
}
function V(e, t) {
	let n = e.ps[t].cash, r = [];
	for (let t = 0; t < e.piles.length; t += 1) {
		let i = e.order.map((t) => e.ps[t]).find((e) => e.bid?.pile === t);
		for (let e = 0; e < b.length && !(b[e] > n); e += 1) i && e <= (i.bid?.slot ?? -1) || r.push({
			pile: t,
			slot: e
		});
	}
	return r;
}
function de(e, t) {
	let n = e.order.length, r = e.order.indexOf(t);
	for (let t = 1; t <= n; t += 1) {
		let i = e.order[(r + t) % n];
		if (e.ps[i].bid === null) return e.bidTurn = i, [];
	}
	return e.bidTurn = null, e.phase = "settle", e.settleIdx = 0, e.beatMs = x, [];
}
function H(e) {
	let t = e.settleIdx;
	e.settleIdx += 1;
	let n = e.piles[t], r = e.order.find((n) => e.ps[n].bid?.pile === t), i = e.ps[r], a = b[i.bid?.slot ?? 0];
	i.cash -= a;
	let o = [...n.up, ...n.down], s = [], c = [], l = [];
	for (let e of o) e.kind === "stock" ? (i.regular[e.company] = (i.regular[e.company] ?? 0) + 1, c.push(e.company)) : e.kind === "action" ? (i.pendingActions.push(e.action), l.push(e.action)) : (s.push(e.amount), i.cash >= e.amount ? i.cash -= e.amount : i.feesHeld += e.amount);
	return i.bid = null, e.piles[t] = {
		up: [],
		down: []
	}, I(e, {
		k: "settle",
		rid: r,
		pile: t,
		paid: a
	}), {
		kind: "settle",
		rid: r,
		data: {
			pile: t,
			paid: a,
			fees: s,
			stocks: c.length,
			actions: l.length,
			up: n.up,
			downCount: n.down.length
		},
		for: [r],
		secret: { down: n.down }
	};
}
function fe(e) {
	for (; e.actionTurn < e.order.length && e.ps[e.order[e.actionTurn]].pendingActions.length === 0;) e.actionTurn += 1;
	e.actionTurn >= e.order.length && (e.phase = "sell", e.sellTurn = 0);
}
function pe(e) {
	e.phase = "movement", e.moveQueue = [
		...e.order.map((t) => ({
			owner: t,
			faceDown: !1,
			pair: e.insider.mine[t]
		})),
		{
			owner: null,
			faceDown: !1,
			pair: e.insider.pub
		},
		...e.insider.down.map((e) => ({
			owner: null,
			faceDown: !0,
			pair: e
		}))
	], e.moveRevealed = [], e.dividend = null, e.beatMs = S;
}
function U(e) {
	let t = e.moveQueue[0];
	e.moveQueue = e.moveQueue.slice(1), e.moveRevealed = [...e.moveRevealed, t];
	let { pair: n, owner: r, faceDown: i } = t;
	if (n.forecast === "$$") {
		let t = e.order.filter((t) => R(e.ps[t], n.company) > 0);
		return t.length > 0 && (e.dividend = {
			company: n.company,
			pending: [...t],
			claimed: []
		}), I(e, {
			k: "reveal",
			owner: r,
			company: n.company,
			forecast: "$$",
			to: null
		}), [{
			kind: "reveal",
			rid: r ?? void 0,
			data: {
				owner: r,
				faceDown: i,
				pair: n,
				dividend: !0
			}
		}];
	}
	let a = B(e, n.company, n.forecast);
	return I(e, {
		k: "reveal",
		owner: r,
		company: n.company,
		forecast: n.forecast > 0 ? `+${n.forecast}` : `${n.forecast}`,
		to: a.to
	}), [{
		kind: "reveal",
		rid: r ?? void 0,
		data: {
			owner: r,
			faceDown: i,
			pair: n,
			...a
		}
	}];
}
function W(e) {
	if (e.round >= e.roundsTotal) {
		let t = Object.fromEntries(e.order.map((e) => [e, 0])), n = [];
		for (let r of _) {
			let i = e.order.map((t) => ({
				rid: t,
				n: (e.ps[t].regular[r] ?? 0) + 2 * (e.ps[t].split[r] ?? 0)
			})), a = Math.max(...i.map((e) => e.n));
			if (a === 0) continue;
			let o = i.filter((e) => e.n === a).map((e) => e.rid), s = o.length === 1 ? 10 : 5;
			for (let e of o) t[e] += s;
			n.push({
				company: r,
				winners: o,
				amount: s
			});
		}
		return e.final = e.order.map((n) => {
			let r = e.ps[n], i = _.reduce((t, n) => t + (r.regular[n] ?? 0) * e.prices[n] + 2 * (r.split[n] ?? 0) * e.prices[n], 0), a = r.cash, o = r.feesHeld;
			return r.cash = a + t[n] + i - o, r.feesHeld = 0, {
				rid: n,
				cash: a,
				majority: t[n],
				sellValue: i,
				feesPaid: o,
				total: r.cash
			};
		}), e.phase = "done", [{
			kind: "gameEnd",
			data: { majority: n }
		}];
	}
	return e.round += 1, e.order = [...e.order.slice(1), e.order[0]], I(e, {
		k: "round",
		round: e.round
	}), [{
		kind: "roundEnd",
		data: { round: e.round }
	}, ...ue(e)];
}
function G(e) {
	switch (e.phase) {
		case "supply": return [e.order[e.supplyTurn]];
		case "demand": return e.bidTurn ? [e.bidTurn] : [];
		case "action": return e.actionTurn < e.order.length ? [e.order[e.actionTurn]] : [];
		case "sell": return e.sellTurn < e.order.length ? [e.order[e.sellTurn]] : [];
		case "movement": return e.dividend ? [...e.dividend.pending] : [];
		default: return [];
	}
}
function me(e, t, n) {
	let r = {
		seed: n,
		rngCursor: 0,
		order: [...t],
		ps: Object.fromEntries(t.map((e) => [e, {
			cash: 20,
			regular: {},
			split: {},
			feesHeld: 0,
			supplyHand: null,
			placedDown: [],
			pendingActions: [],
			playedActions: [],
			bid: null
		}])),
		round: 1,
		roundsTotal: ie[t.length],
		phase: "supply",
		prices: Object.fromEntries(_.map((e) => [e, 5])),
		deck: [],
		piles: [],
		insider: {
			mine: {},
			pub: {
				company: "cosmic",
				forecast: 1
			},
			down: []
		},
		supplyTurn: 0,
		bidTurn: null,
		settleIdx: 0,
		actionTurn: 0,
		sellTurn: 0,
		moveQueue: [],
		moveRevealed: [],
		dividend: null,
		beatMs: 0,
		final: null,
		log: []
	};
	r.deck = L(r, y());
	let i = L(r, [..._]);
	t.forEach((e, t) => {
		let n = i[t], a = r.deck.findIndex((e) => e.kind === "stock" && e.company === n);
		r.deck.splice(a, 1), r.ps[e].regular[n] = 1;
	});
	let a = ue(r);
	for (let e of a) if (e.kind === "deal" && e.for) {
		let n = e.for[0];
		e.secret = {
			...e.secret,
			startStock: i[t.indexOf(n)]
		};
	}
	return {
		state: r,
		fx: a
	};
}
function he(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "settle" && e.settleIdx < e.piles.length) {
			let t = structuredClone(e), n = H(t);
			return t.settleIdx >= t.piles.length && (t.phase = "action", t.actionTurn = 0, fe(t)), t.beatMs = x, {
				state: t,
				fx: [n]
			};
		}
		if (e.phase === "movement" && !e.dividend) {
			let t = structuredClone(e);
			if (t.moveQueue.length === 0) {
				let e = W(t);
				return t.beatMs = S, {
					state: t,
					fx: e
				};
			}
			let n = U(t);
			return t.beatMs = S, {
				state: t,
				fx: n
			};
		}
		return {
			state: e,
			fx: []
		};
	}
	if (t.type === "place") {
		if (e.phase !== "supply" || e.order[e.supplyTurn] !== n.by) return { code: "games.stockpile.errNotYourTurn" };
		let r = e.ps[n.by].supplyHand;
		if (!r || r.length !== 2) return { code: "games.stockpile.errNotYourTurn" };
		if (t.upPile >= e.piles.length || t.downPile >= e.piles.length) return { code: "games.stockpile.errBadPile" };
		let i = structuredClone(e), a = i.ps[n.by], o = a.supplyHand?.[t.upCard], s = a.supplyHand?.[1 - t.upCard];
		return i.piles[t.upPile].up.push(o), i.piles[t.downPile].down.push(s), a.placedDown.push({
			pile: t.downPile,
			card: s
		}), a.supplyHand = null, i.supplyTurn += 1, i.supplyTurn >= i.order.length && (i.phase = "demand", i.bidTurn = i.order[0]), {
			state: i,
			fx: [{
				kind: "place",
				rid: n.by,
				data: {
					upPile: t.upPile,
					upCard: o,
					downPile: t.downPile
				},
				for: [n.by],
				secret: { downCard: s }
			}]
		};
	}
	if (t.type === "bid") {
		if (e.phase !== "demand" || e.bidTurn !== n.by) return { code: "games.stockpile.errNotYourTurn" };
		if (t.pile >= e.piles.length) return { code: "games.stockpile.errBadPile" };
		let r = b[t.slot], i = e.order.map((t) => ({
			rid: t,
			bid: e.ps[t].bid
		})).find((e) => e.bid?.pile === t.pile), a = V(e, n.by);
		if (a.length === 0) {
			if (r > e.ps[n.by].cash) return { code: "games.stockpile.errBadBid" };
		} else if (!a.some((e) => e.pile === t.pile && e.slot === t.slot)) return { code: "games.stockpile.errBadBid" };
		let o = structuredClone(e);
		i?.rid && (o.ps[i.rid].bid = null), o.ps[n.by].bid = {
			pile: t.pile,
			slot: t.slot
		}, I(o, {
			k: "bid",
			rid: n.by,
			pile: t.pile,
			value: r
		});
		let s = [{
			kind: "bid",
			rid: n.by,
			data: {
				pile: t.pile,
				slot: t.slot,
				value: r,
				outbid: i?.rid ?? null
			}
		}];
		return s.push(...de(o, n.by)), {
			state: o,
			fx: s
		};
	}
	if (t.type === "play") {
		if (e.phase !== "action" || e.order[e.actionTurn] !== n.by) return { code: "games.stockpile.errNotYourTurn" };
		if (!e.ps[n.by].pendingActions.includes(t.card)) return { code: "games.stockpile.errBadCard" };
		let r = structuredClone(e), i = r.ps[n.by];
		i.pendingActions.splice(i.pendingActions.indexOf(t.card), 1), i.playedActions.push({
			card: t.card,
			company: t.company
		}), I(r, {
			k: "play",
			rid: n.by,
			card: t.card,
			company: t.company
		});
		let a = B(r, t.company, t.card === "boom" ? 2 : -2);
		return fe(r), {
			state: r,
			fx: [{
				kind: "play",
				rid: n.by,
				data: {
					card: t.card,
					company: t.company,
					...a
				}
			}]
		};
	}
	if (t.type === "sell") {
		if (e.phase !== "sell" || e.order[e.sellTurn] !== n.by) return { code: "games.stockpile.errNotYourTurn" };
		let r = e.ps[n.by];
		for (let e of _) {
			let n = t.regular[e] ?? 0, i = t.split[e] ?? 0, a = t.convert[e] ?? 0;
			if (n > (r.regular[e] ?? 0) || i > (r.split[e] ?? 0) || a > (r.split[e] ?? 0) || i + a > (r.split[e] ?? 0)) return { code: "games.stockpile.errBadSell" };
		}
		let i = structuredClone(e), a = i.ps[n.by], o = 0;
		for (let e of _) {
			let n = i.prices[e], r = t.regular[e] ?? 0, s = t.split[e] ?? 0, c = t.convert[e] ?? 0;
			r > 0 && (a.regular[e] = (a.regular[e] ?? 0) - r), s > 0 && (a.split[e] = (a.split[e] ?? 0) - s), c > 0 && (a.split[e] = (a.split[e] ?? 0) - c, a.regular[e] = (a.regular[e] ?? 0) + c), o += r * n + s * 2 * n + c * n;
		}
		z(a, o), i.sellTurn += 1, I(i, {
			k: "sell",
			rid: n.by,
			gained: o
		});
		let s = [{
			kind: "sell",
			rid: n.by,
			data: {
				regular: t.regular,
				split: t.split,
				convert: t.convert,
				gained: o
			}
		}];
		return i.sellTurn >= i.order.length && pe(i), {
			state: i,
			fx: s
		};
	}
	if (e.phase !== "movement" || !e.dividend || !e.dividend.pending.includes(n.by)) return { code: "games.stockpile.errNotYourTurn" };
	let r = e.dividend, i = e.ps[n.by];
	if (t.regular > (i.regular[r.company] ?? 0) || t.split > (i.split[r.company] ?? 0)) return { code: "games.stockpile.errBadDividend" };
	let a = structuredClone(e), o = a.dividend, s = a.ps[n.by], c = 2 * (t.regular + 2 * t.split);
	z(s, c), o.pending = o.pending.filter((e) => e !== n.by), o.claimed.push(n.by), I(a, {
		k: "dividend",
		rid: n.by,
		company: o.company,
		gained: c
	});
	let l = [{
		kind: "dividend",
		rid: n.by,
		data: {
			company: o.company,
			regular: t.regular,
			split: t.split,
			gained: c
		}
	}];
	return o.pending.length === 0 && (a.dividend = null, a.moveQueue.length === 0 && l.push(...W(a))), {
		state: a,
		fx: l
	};
}
function K(e, t) {
	let n = e.ps[t];
	return {
		public: {
			phase: e.phase,
			round: e.round,
			roundsTotal: e.roundsTotal,
			order: e.order,
			prices: e.prices,
			deckLeft: e.deck.length,
			piles: e.piles.map((t, n) => {
				let r = e.order.map((t) => ({
					rid: t,
					bid: e.ps[t].bid
				})).find((e) => e.bid?.pile === n);
				return {
					up: t.up,
					downCount: t.down.length,
					bid: r ? {
						rid: r.rid,
						slot: r.bid?.slot ?? 0
					} : null
				};
			}),
			players: e.order.map((t) => {
				let n = e.ps[t];
				return {
					rid: t,
					cash: n.cash,
					split: n.split,
					regularCount: _.reduce((e, t) => e + (n.regular[t] ?? 0), 0),
					feesHeld: n.feesHeld,
					playedActions: n.playedActions,
					bid: n.bid
				};
			}),
			awaiting: G(e),
			insiderPublic: e.insider.pub,
			insiderDownCount: e.insider.down.length,
			moveQueue: [...e.moveRevealed.map((e) => ({
				owner: e.owner,
				faceDown: e.faceDown,
				pair: e.pair
			})), ...e.moveQueue.map((e) => ({
				owner: e.owner,
				faceDown: e.faceDown,
				pair: null
			}))],
			dividend: e.dividend ? {
				company: e.dividend.company,
				claimed: e.dividend.claimed
			} : null,
			final: e.final,
			log: e.log
		},
		private: {
			myInsider: e.insider.mine[t],
			mySupplyHand: n.supplyHand,
			myRegular: n.regular,
			myPendingActions: n.pendingActions,
			myPlacedDown: n.placedDown
		}
	};
}
function ge(e) {
	if (e.phase !== "done" || !e.final) return { phase: e.phase };
	let t = [...e.order].sort((t, n) => {
		let r = e.final?.find((e) => e.rid === t);
		return (e.final?.find((e) => e.rid === n)?.total ?? 0) - (r?.total ?? 0);
	}), n = e.final.find((e) => e.rid === t[0])?.total ?? 0;
	return {
		phase: "done",
		winner: t.filter((t) => e.final?.find((e) => e.rid === t)?.total === n),
		ranking: t,
		scores: Object.fromEntries(e.final.map((e) => [e.rid, e.total]))
	};
}
function q(e) {
	return e.phase === "settle" && e.settleIdx < e.piles.length || e.phase === "movement" && !e.dividend ? e.beatMs : null;
}
var J = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: T,
	schemas: {
		action: N,
		publicView: F,
		privateView: le
	},
	setup: me,
	reduce: he,
	viewFor: K,
	status: ge,
	nextTickIn: q
};
//#endregion
//#region src/games/stockpile/pieces.tsx
function _e({ company: e, price: t, preview: n, selected: r, dividend: i }) {
	let o = a(), s = v[e], { ref: c } = u(`track:${e}`), l = n ? t + n.delta : null;
	return /* @__PURE__ */ p("div", {
		ref: c,
		className: "stockpile-track",
		"data-selected": r,
		"data-dividend": i,
		style: { "--stock-color": s.track },
		children: [
			/* @__PURE__ */ p("span", {
				className: "stockpile-track__name",
				title: o(C[e]),
				children: [/* @__PURE__ */ f("span", {
					"aria-hidden": !0,
					className: "text-xs",
					children: s.emoji
				}), /* @__PURE__ */ f("span", {
					className: "stockpile-track__name-text",
					children: o(C[e])
				})]
			}),
			/* @__PURE__ */ f("span", {
				"aria-label": o("games.stockpile.bankruptSpace"),
				className: "stockpile-track__endpoint",
				"data-projected": l !== null && l < 1,
				children: "🗑"
			}),
			/* @__PURE__ */ f("div", {
				className: "stockpile-track__rail",
				children: Array.from({ length: 10 }, (e, t) => t + 1).map((e) => /* @__PURE__ */ f("span", {
					className: "stockpile-track__cell",
					"data-current": e === t,
					"data-start": e === 5,
					"data-projected": e === l,
					title: e === l ? n?.label : void 0,
					children: e
				}, e))
			}),
			/* @__PURE__ */ f("span", {
				"aria-label": o("games.stockpile.splitSpace"),
				className: "stockpile-track__endpoint text-done-ink",
				"data-projected": l !== null && l > 10,
				"data-dividend": i,
				children: "$$"
			})
		]
	});
}
var ve = {
	sm: "stockpile-market-card stockpile-market-card--sm h-11 w-8",
	md: "stockpile-market-card stockpile-market-card--md h-16 w-12",
	lg: "stockpile-market-card stockpile-market-card--lg h-20 w-14"
};
function ye({ size: e = "sm" }) {
	return /* @__PURE__ */ f("div", {
		"aria-hidden": !0,
		className: `grid ${ve[e]} place-items-center rounded border-2 border-ink text-white shadow-[0_4px_0_var(--color-ink)]`,
		style: { background: "repeating-linear-gradient(135deg, var(--color-felt) 0 6px, var(--color-felt-deep) 6px 12px)" },
		children: /* @__PURE__ */ f("svg", {
			viewBox: "0 0 32 32",
			className: `stockpile-card-symbol ${e === "sm" ? "size-5" : "size-8"}`,
			fill: "none",
			"aria-hidden": !0,
			children: /* @__PURE__ */ f("path", {
				d: "M4 23 11 17 16 20 27 8M21 8h6v6",
				stroke: "white",
				strokeWidth: "3",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			})
		})
	});
}
function be({ card: e, size: t = "sm" }) {
	let n = a(), r = `relative ${ve[t]} overflow-hidden rounded border-2 border-ink`;
	if (e.kind === "stock") {
		let i = v[e.company];
		return /* @__PURE__ */ p("div", {
			className: `${r} stockpile-certificate ${t === "sm" ? "" : "shadow-[2px_2px_0_var(--color-ink)]"}`,
			style: { "--stock-color": i.track },
			"aria-label": `${n(C[e.company])} ${n("games.stockpile.stockCard")}`,
			children: [/* @__PURE__ */ f("div", {
				className: "relative z-10 h-1.5 w-full",
				style: { background: i.track }
			}), /* @__PURE__ */ p("div", {
				className: "relative z-10 flex h-[calc(100%-0.375rem)] flex-col items-center justify-center gap-0.5 px-0.5",
				children: [/* @__PURE__ */ f("span", {
					className: "stockpile-certificate__seal",
					"aria-hidden": !0,
					children: /* @__PURE__ */ f("span", {
						className: `stockpile-card-symbol ${t === "sm" ? "text-sm" : t === "md" ? "text-xl" : "text-2xl"}`,
						children: i.emoji
					})
				}), t !== "sm" && /* @__PURE__ */ f("span", {
					className: "stockpile-certificate__name w-full truncate text-center text-[8px] font-extrabold leading-none",
					children: n(C[e.company])
				})]
			})]
		});
	}
	if (e.kind === "fee") return /* @__PURE__ */ f("div", {
		className: `${r} grid place-items-center bg-felt-deep`,
		"aria-label": n("games.stockpile.feeCard", { n: e.amount }),
		children: /* @__PURE__ */ p("span", {
			className: `stockpile-card-fee grid place-items-center rounded-full bg-danger font-mono font-black text-white ${t === "sm" ? "size-5 text-[9px]" : "size-8 text-xs"}`,
			children: ["−", e.amount]
		})
	});
	let i = e.action === "boom";
	return /* @__PURE__ */ f("div", {
		className: `${r} grid place-items-center ${i ? "bg-done-soft" : "bg-danger-soft"}`,
		"aria-label": n(i ? "games.stockpile.actionBoom" : "games.stockpile.actionBust"),
		children: /* @__PURE__ */ p("svg", {
			viewBox: "0 0 24 24",
			className: `stockpile-card-symbol ${t === "sm" ? "size-5" : "size-8"}`,
			"aria-hidden": !0,
			children: [/* @__PURE__ */ f("polyline", {
				points: i ? "3,19 9,13 13,16 21,6" : "3,5 9,11 13,8 21,18",
				fill: "none",
				stroke: i ? "var(--color-done-ink)" : "var(--color-danger-ink)",
				strokeWidth: "2.5",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}), /* @__PURE__ */ f("polyline", {
				points: i ? "15,6 21,6 21,12" : "15,18 21,18 21,12",
				fill: "none",
				stroke: i ? "var(--color-done-ink)" : "var(--color-danger-ink)",
				strokeWidth: "2.5",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			})]
		})
	});
}
function xe({ pair: e, label: t }) {
	let n = v[e.company];
	return /* @__PURE__ */ p("span", {
		className: "stockpile-insider-chip inline-flex flex-none items-center gap-1 rounded-lg border-2 border-ink bg-surface px-1.5 py-0.5",
		title: t,
		children: [/* @__PURE__ */ f("span", {
			"aria-hidden": !0,
			className: "text-sm",
			children: n.emoji
		}), /* @__PURE__ */ f("span", {
			className: `rounded px-1 font-mono text-xs font-black ${e.forecast === "$$" || e.forecast > 0 ? "bg-done-soft text-done-ink" : "bg-danger-soft text-danger-ink"}`,
			children: w(e.forecast)
		})]
	});
}
function Se({ n: e }) {
	return /* @__PURE__ */ f("span", {
		className: "inline-flex flex-none items-center gap-0.5",
		children: Array.from({ length: e }, (e, t) => /* @__PURE__ */ f("span", {
			className: "grid size-6 place-items-center rounded border border-ink bg-ink/70 text-[10px] text-white",
			children: "?"
		}, t))
	});
}
function Ce({ index: e, up: t, downCount: n, bid: r, bidColor: i, bidName: o, previewColor: s, previewName: c, active: l, selected: ee, previewSlot: te, previewUp: ne, previewDown: d, onPick: m }) {
	let h = a(), { ref: g } = u(`pile:${e}`);
	return /* @__PURE__ */ p("div", {
		ref: g,
		role: l ? "button" : void 0,
		tabIndex: l ? 0 : void 0,
		"aria-label": l ? h("games.stockpile.pile", { n: e + 1 }) : void 0,
		onClick: l ? m : void 0,
		onKeyDown: l ? (e) => {
			(e.key === "Enter" || e.key === " ") && (e.preventDefault(), m?.());
		} : void 0,
		className: "stockpile-calculator",
		"data-active": l,
		"data-selected": ee,
		style: {
			"--bid-color": i ?? "var(--color-felt)",
			"--preview-color": s ?? "var(--color-felt)"
		},
		children: [
			/* @__PURE__ */ p("div", {
				className: "stockpile-calculator__display",
				children: [/* @__PURE__ */ f("span", {
					className: "font-display text-lg leading-none font-black tabular-nums",
					children: String(e + 1).padStart(2, "0")
				}), te == null ? r ? /* @__PURE__ */ p("span", {
					className: "flex min-w-0 flex-col items-end text-[9px] leading-none font-extrabold",
					title: o,
					children: [/* @__PURE__ */ f("span", {
						className: "max-w-full truncate",
						children: o
					}), /* @__PURE__ */ p("span", {
						className: "font-mono tabular-nums",
						children: [
							"$",
							b[r.slot],
							"K"
						]
					})]
				}) : /* @__PURE__ */ f("span", {
					className: "font-mono text-lg leading-none font-black text-done-ink",
					"aria-label": h(ee ? "games.stockpile.bidSelected" : "games.stockpile.bidOpen"),
					children: ee ? "◎" : "––"
				}) : /* @__PURE__ */ p("span", {
					className: "flex min-w-0 flex-col items-end text-[9px] leading-none font-extrabold",
					title: c,
					children: [/* @__PURE__ */ f("span", {
						className: "max-w-full truncate",
						children: c
					}), /* @__PURE__ */ p("span", {
						className: "font-mono text-xs tabular-nums text-done-ink",
						children: [
							"↑ $",
							b[te],
							"K"
						]
					})]
				})]
			}),
			/* @__PURE__ */ f("div", {
				className: "stockpile-calculator__keys",
				"aria-hidden": !0,
				children: b.map((e, t) => {
					let n = r?.slot === t, i = te === t && !n;
					return /* @__PURE__ */ p("span", {
						className: "stockpile-calculator__key",
						"data-zero": e === 0,
						"data-occupied": n,
						"data-preview": i,
						children: [e, (n || i) && /* @__PURE__ */ p("svg", {
							viewBox: "0 0 14 16",
							className: "stockpile-calculator__pawn",
							"data-preview": i,
							"aria-hidden": !0,
							children: [/* @__PURE__ */ f("circle", {
								cx: "7",
								cy: "4",
								r: "2.5"
							}), /* @__PURE__ */ f("path", { d: "M4.5 7h5l1.8 6.5h-8.6Z" })]
						})]
					}, e);
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "stockpile-calculator__cards",
				children: [
					t.map((e, t) => /* @__PURE__ */ f(be, {
						card: e,
						size: "sm"
					}, t)),
					Array.from({ length: n }, (e, t) => /* @__PURE__ */ f(ye, { size: "sm" }, `d${t}`)),
					ne && /* @__PURE__ */ p("span", {
						className: "relative flex-none opacity-75",
						children: [/* @__PURE__ */ f(be, {
							card: ne,
							size: "sm"
						}), /* @__PURE__ */ f("span", {
							className: "absolute -bottom-1 left-0 rounded bg-done-soft px-0.5 text-[8px] font-black text-done-ink",
							children: h("games.stockpile.supplyUp")
						})]
					}),
					d && /* @__PURE__ */ p("span", {
						className: "relative flex-none opacity-75",
						children: [/* @__PURE__ */ f(ye, { size: "sm" }), /* @__PURE__ */ f("span", {
							className: "absolute -bottom-1 left-0 rounded bg-info-soft px-0.5 text-[8px] font-black text-info-ink",
							children: h("games.stockpile.supplyDown")
						})]
					}),
					t.length === 0 && n === 0 && !ne && !d && /* @__PURE__ */ f("span", {
						className: "grid h-11 w-full place-items-center rounded border border-dashed border-ink/30 text-[10px] font-bold opacity-60",
						children: h("games.stockpile.pileEmpty")
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/stockpile/view-player.tsx
function we(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ f(Y, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: (t) => e.send(t)
	});
}
var Te = {
	regular: {},
	split: {},
	convert: {}
}, Ee = {
	supply: "games.stockpile.phaseSupply",
	demand: "games.stockpile.phaseDemand",
	settle: "games.stockpile.phaseSettle",
	action: "games.stockpile.phaseAction",
	sell: "games.stockpile.phaseSell",
	movement: "games.stockpile.phaseMovement",
	done: "games.stockpile.phaseDone"
};
function Y({ pub: e, priv: t, members: u, myRid: m, send: h }) {
	let g = a(), re = i((e) => e.locale), y = (e) => u.find((t) => t.rid === e)?.name ?? e, ie = (e) => {
		let t = u.find((t) => t.rid === e);
		return t ? o[t.colorIndex % o.length].hex : "#57534e";
	}, x = e.players.find((e) => e.rid === m), S = e.awaiting.includes(m), [w, E] = n(0), [D, O] = n("up"), [k, A] = n(null), [j, M] = n(null), [N, ae] = n(null), [P, oe] = n(null), [se, ce] = n(null), [F, le] = n(Te), [I, L] = n(null), [R, z] = n("regular"), [B, ue] = n(0), [V, de] = n(0), H = `${e.round}:${e.phase}:${e.awaiting.join(",")}`, [fe, pe] = n(H);
	fe !== H && (pe(H), E(0), O("up"), A(null), M(null), ae(null), oe(null), ce(null), le(Te), L(null), z("regular"), ue(0), de(0));
	let U = se === null ? null : t.myPendingActions[se] ?? null, W = U === "boom" ? 2 : U === "bust" ? -2 : null, G = I && W !== null ? e.prices[I] + W : null, me = G === null ? "" : G < 1 ? g("games.stockpile.bankruptSpace") : G > 10 ? g("games.stockpile.splitSpace") : g("games.stockpile.actionPreview", { n: G }), he = /* @__PURE__ */ p("div", {
		className: "stockpile-assets flex h-9 min-w-0 items-center gap-2 overflow-x-auto overflow-y-hidden whitespace-nowrap scrollbar-none wide:short:h-7",
		children: [
			/* @__PURE__ */ p("span", {
				className: "flex-none font-mono text-sm font-black tabular-nums",
				children: [
					"$",
					/* @__PURE__ */ f(r, { value: x?.cash ?? 0 }),
					"K"
				]
			}),
			_.filter((e) => (t.myRegular[e] ?? 0) > 0 || (x?.split[e] ?? 0) > 0).map((e) => /* @__PURE__ */ p("span", {
				className: `flex flex-none items-center gap-0.5 rounded-lg border-2 border-ink bg-surface px-1.5 py-1 text-xs font-bold ${I === e ? "ring-2 ring-felt" : ""}`,
				children: [
					/* @__PURE__ */ f("span", {
						"aria-hidden": !0,
						children: v[e].emoji
					}),
					"×",
					(t.myRegular[e] ?? 0) + (x?.split[e] ?? 0),
					(x?.split[e] ?? 0) > 0 && /* @__PURE__ */ p("span", {
						className: "rounded bg-warn-soft px-0.5 text-[9px] font-black text-warn-ink",
						children: ["×2:", x?.split[e]]
					})
				]
			}, e)),
			t.myPendingActions.length > 0 && /* @__PURE__ */ p("span", {
				className: "flex-none text-[10px] font-bold text-info-ink",
				children: ["🎬×", t.myPendingActions.length]
			})
		]
	}), K = e.awaiting.length > 0 && !S ? y(e.awaiting[0]) : null, ge = "info", q = g(Ee[e.phase]), J;
	S ? (ge = "accent", e.phase === "supply" ? q = g("games.stockpile.supplyPrompt") : e.phase === "demand" ? q = g("games.stockpile.demandPrompt") : e.phase === "action" ? q = g("games.stockpile.actionPrompt") : e.phase === "sell" ? q = g("games.stockpile.sellPrompt") : e.phase === "movement" && (q = g("games.stockpile.dividendPrompt", { company: e.dividend ? g(C[e.dividend.company]) : "" }))) : e.phase === "settle" ? J = g("games.stockpile.settleWaiting") : e.phase === "movement" && !e.dividend ? J = g("games.stockpile.movementWaiting") : e.phase === "movement" && e.dividend ? J = g("games.stockpile.dividendWaiting") : K && (e.phase === "supply" ? J = g("games.stockpile.supplyWaiting", { name: K }) : e.phase === "demand" ? J = g("games.stockpile.demandWaiting", { name: K }) : e.phase === "action" ? J = g("games.stockpile.actionWaiting", { name: K }) : e.phase === "sell" && (J = g("games.stockpile.sellWaiting", { name: K })));
	let ve = /* @__PURE__ */ p("div", {
		className: "stockpile-banner flex flex-col gap-1.5 short:gap-1 wide:short:grid wide:short:grid-cols-[45%_minmax(0,1fr)]",
		children: [
			/* @__PURE__ */ f("div", {
				className: "wide:short:col-span-2",
				children: /* @__PURE__ */ f(ee, {
					tone: ge,
					accent: T.accent,
					chip: g("games.stockpile.roundShort", {
						n: e.round,
						total: e.roundsTotal
					}),
					text: q,
					sub: J
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "min-w-0",
				children: /* @__PURE__ */ f("div", {
					className: "stockpile-seats-scroll overflow-x-auto pt-2 pr-1 pb-0.5 pl-2 scrollbar-none",
					children: /* @__PURE__ */ f("ul", {
						className: "stockpile-seats flex w-max gap-1.5",
						children: u.map((t) => {
							let n = e.players.find((e) => e.rid === t.rid);
							return /* @__PURE__ */ p("li", {
								className: "stockpile-seat",
								children: [/* @__PURE__ */ f(te, {
									m: t,
									myRid: m,
									action: e.awaiting.includes(t.rid) ? "pending" : null,
									anchorName: `seat:${t.rid}`,
									box: "size-9",
									img: "size-7"
								}), /* @__PURE__ */ p("span", {
									className: "flex min-w-0 flex-col leading-tight",
									children: [/* @__PURE__ */ f("span", {
										className: "max-w-20 truncate text-xs font-extrabold",
										children: ne(t, re)
									}), /* @__PURE__ */ p("span", {
										className: "whitespace-nowrap font-mono text-[11px] font-black tabular-nums",
										children: [
											/* @__PURE__ */ f(r, { value: n?.cash ?? 0 }),
											"K",
											n && n.feesHeld > 0 ? /* @__PURE__ */ p("span", {
												className: "text-danger-ink",
												children: [" ⚠", n.feesHeld]
											}) : null
										]
									})]
								})]
							}, t.rid);
						})
					})
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "stockpile-log flex min-w-0 items-center gap-2 wide:short:self-center",
				children: [/* @__PURE__ */ f("div", {
					className: "min-w-0 flex-1",
					children: /* @__PURE__ */ f(l, {
						log: e.log,
						line: (e) => De(e, g, y)
					})
				}), /* @__PURE__ */ f("div", {
					className: "hidden wide:short:block wide:short:w-40",
					children: he
				})]
			})
		]
	}), ye = /* @__PURE__ */ p("div", {
		className: "stockpile-calendar flex items-center gap-1.5",
		children: [
			/* @__PURE__ */ f("span", {
				className: "flex-none text-[10px] font-extrabold",
				children: g("games.stockpile.round", { n: e.round })
			}),
			/* @__PURE__ */ f("span", {
				className: "flex min-w-0 flex-1 items-center gap-0.5",
				children: Array.from({ length: e.roundsTotal }, (t, n) => /* @__PURE__ */ f("span", {
					className: "stockpile-calendar__day",
					"data-current": n + 1 === e.round,
					"data-done": n + 1 < e.round,
					children: n + 1
				}, n))
			}),
			/* @__PURE__ */ f("span", {
				className: "flex-none text-[10px] font-bold",
				children: g("games.stockpile.deckLeft", { n: e.deckLeft })
			})
		]
	}), we = /* @__PURE__ */ p("div", {
		className: "stockpile-table h-full p-1 wide:short:[--stockpile-track-height:22px] wide:short:[--stockpile-cell-height:16px] wide:short:[--stockpile-coin-height:20px]",
		children: [/* @__PURE__ */ f(s, {
			kind: "sheen",
			base: "var(--color-paper)",
			className: "pointer-events-none absolute inset-0 rounded-[inherit]"
		}), /* @__PURE__ */ p("div", {
			className: "stockpile-desk relative flex h-full min-h-0 flex-col gap-1.5 overflow-y-auto wide:short:grid wide:short:grid-cols-[minmax(0,45%)_minmax(0,55%)] wide:short:overflow-hidden",
			children: [/* @__PURE__ */ p("div", {
				className: "stockpile-reference flex min-w-0 flex-none flex-col gap-1.5 wide:short:min-h-0 wide:short:overflow-y-auto",
				children: [
					/* @__PURE__ */ f("div", {
						className: "stockpile-price-board flex-none",
						children: _.map((t) => /* @__PURE__ */ f(_e, {
							company: t,
							price: e.prices[t],
							selected: I === t && S && (e.phase === "action" || e.phase === "sell"),
							dividend: e.phase === "movement" && e.dividend?.company === t,
							preview: e.phase === "action" && I === t && W !== null ? {
								delta: W,
								label: me
							} : null
						}, t))
					}),
					/* @__PURE__ */ f("div", {
						className: "stockpile-insiders flex h-7 flex-none items-center gap-1.5 overflow-x-auto overflow-y-hidden whitespace-nowrap scrollbar-none",
						children: e.phase === "movement" || e.phase === "done" ? e.moveQueue.map((e, t) => e.pair ? /* @__PURE__ */ f(xe, {
							pair: e.pair,
							label: e.owner ? y(e.owner) : void 0
						}, t) : /* @__PURE__ */ f("span", {
							className: "grid size-6 flex-none place-items-center rounded border border-ink/40 bg-ink/60 text-[10px] text-white",
							children: "?"
						}, t)) : /* @__PURE__ */ p(d, { children: [
							/* @__PURE__ */ f("span", {
								className: "flex-none text-[10px] font-bold opacity-60",
								children: g("games.stockpile.insiderPublic")
							}),
							/* @__PURE__ */ f(xe, { pair: e.insiderPublic }),
							e.insiderDownCount > 0 && /* @__PURE__ */ f(Se, { n: e.insiderDownCount }),
							/* @__PURE__ */ p("span", {
								className: "flex-none text-[10px] font-bold opacity-60",
								children: ["· ", g("games.stockpile.insiderYours")]
							}),
							/* @__PURE__ */ f(xe, { pair: t.myInsider })
						] })
					}),
					/* @__PURE__ */ p("div", {
						className: "stockpile-reference-assets",
						children: [he, ye]
					})
				]
			}), /* @__PURE__ */ p("div", {
				className: "stockpile-market-column flex min-w-0 flex-none flex-col gap-1.5 wide:short:min-h-0 wide:short:overflow-y-auto",
				children: [/* @__PURE__ */ f("div", {
					className: "stockpile-piles flex flex-none items-stretch gap-1.5 overflow-x-auto pb-1",
					children: e.piles.map((n, r) => /* @__PURE__ */ f(Ce, {
						index: r,
						up: n.up,
						downCount: n.downCount,
						bid: n.bid,
						bidColor: n.bid ? ie(n.bid.rid) : null,
						bidName: n.bid ? y(n.bid.rid) : void 0,
						previewColor: ie(m),
						previewName: y(m),
						active: S && (e.phase === "demand" || e.phase === "supply"),
						selected: N === r || e.phase === "supply" && (k === r || j === r),
						previewSlot: e.phase === "demand" && N === r ? P : null,
						previewUp: e.phase === "supply" && t.mySupplyHand && k === r ? t.mySupplyHand[w] : null,
						previewDown: e.phase === "supply" && j === r,
						onPick: () => {
							e.phase === "supply" ? D === "up" ? (A(r), O("down")) : M(r) : (ae(r), oe(null));
						}
					}, r))
				}), /* @__PURE__ */ p("div", {
					className: "stockpile-market-assets wide:short:hidden",
					children: [he, ye]
				})]
			})]
		})]
	}), Y = e.log[e.log.length - 1], X = Y && (e.phase === "settle" && Y.k === "settle" || e.phase === "movement" && (Y.k === "reveal" || Y.k === "split" || Y.k === "bankrupt")) ? /* @__PURE__ */ p("div", {
		className: "stockpile-receipt",
		children: [/* @__PURE__ */ f("span", {
			className: "mr-2 opacity-60",
			children: "▤"
		}), De(Y, g, y)]
	}) : null, Z = /* @__PURE__ */ f("div", {
		className: "stockpile-action-tray h-full p-1",
		children: Oe()
	});
	function Oe() {
		return e.phase === "supply" && S && t.mySupplyHand ? Q(t.mySupplyHand) : e.phase === "demand" && S ? ke() : e.phase === "action" && S ? Ae() : e.phase === "sell" && S ? $() : e.phase === "movement" && S && e.dividend ? je(e.dividend.company) : /* @__PURE__ */ p("div", {
			className: "stockpile-waiting",
			children: [/* @__PURE__ */ f("span", {
				className: "stockpile-waiting__pawn",
				"aria-hidden": !0,
				children: "⌛"
			}), /* @__PURE__ */ f("span", {
				className: "text-xs",
				children: J ?? g(Ee[e.phase])
			})]
		});
	}
	function Q(e) {
		let t = k !== null && j !== null;
		return /* @__PURE__ */ p("div", {
			className: "stockpile-supply-actions grid h-full grid-cols-[auto_1fr] items-center gap-1.5 wide:short:flex wide:short:flex-row",
			children: [
				/* @__PURE__ */ f("div", {
					className: "flex flex-none items-center justify-center gap-2",
					children: e.map((e, t) => /* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => {
							E(t), O("up");
						},
						className: `relative min-h-11 rounded-md ${w === t ? "ring-3 ring-felt" : ""}`,
						children: [/* @__PURE__ */ f(be, {
							card: e,
							size: "md"
						}), /* @__PURE__ */ f("span", {
							className: `absolute -top-1.5 -right-1.5 rounded-md border border-ink px-1 text-[9px] font-black ${w === t ? "bg-done-soft text-done-ink" : "bg-ink/70 text-white"}`,
							children: g(w === t ? "games.stockpile.supplyUp" : "games.stockpile.supplyDown")
						})]
					}, t))
				}),
				/* @__PURE__ */ f("div", {
					className: "flex min-w-0 flex-1 items-center justify-center gap-2",
					children: ["up", "down"].map((e) => {
						let t = e === "up" ? k : j;
						return /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => O(e),
							className: `flex min-h-11 min-w-0 flex-1 items-center justify-center gap-1 rounded-lg border-2 border-ink px-1 text-xs font-extrabold ${D === e ? "bg-felt text-white" : "bg-surface"}`,
							children: [g(e === "up" ? "games.stockpile.supplyUp" : "games.stockpile.supplyDown"), /* @__PURE__ */ f("span", {
								className: "font-mono tabular-nums",
								children: t === null ? "→" : String(t + 1).padStart(2, "0")
							})]
						}, e);
					})
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					disabled: !t,
					onClick: () => t && h({
						type: "place",
						upCard: w,
						upPile: k,
						downPile: j
					}),
					className: "btn-base col-span-2 min-h-11 flex-none font-display font-extrabold text-white wide:short:px-4",
					style: { background: T.accent },
					children: g("games.stockpile.supplyConfirm")
				})
			]
		});
	}
	function ke() {
		let t = x?.cash ?? 0;
		if (N === null) return /* @__PURE__ */ p("div", {
			className: "flex h-full items-center justify-center gap-3",
			children: [/* @__PURE__ */ p("svg", {
				viewBox: "0 0 40 46",
				className: "size-11 flex-none fill-felt stroke-ink stroke-[2.5]",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ f("circle", {
					cx: "20",
					cy: "11",
					r: "7"
				}), /* @__PURE__ */ f("path", { d: "M13 21h14l6 20H7Z" })]
			}), /* @__PURE__ */ f("p", {
				className: "max-w-64 text-sm leading-snug font-extrabold",
				children: g("games.stockpile.demandPrompt")
			})]
		});
		let n = e.piles[N].bid;
		return /* @__PURE__ */ p("div", {
			className: "stockpile-demand-actions flex h-full flex-col justify-center gap-1 wide:short:flex-row wide:short:items-center wide:short:gap-2",
			children: [
				/* @__PURE__ */ f("p", {
					className: "sr-only",
					children: g("games.stockpile.pile", { n: N + 1 })
				}),
				/* @__PURE__ */ f("div", {
					className: "grid flex-none grid-cols-4 gap-1 wide:short:grid-cols-8",
					children: b.map((e, r) => {
						let i = r > (n?.slot ?? -1) && e <= t;
						return /* @__PURE__ */ f("button", {
							type: "button",
							disabled: !i,
							onClick: () => oe(r),
							className: `min-h-11 rounded-lg border-2 border-ink font-mono text-sm font-black tabular-nums wide:short:min-w-11 ${P === r ? "bg-felt text-white" : i ? "bg-surface" : "opacity-30"}`,
							children: e
						}, e);
					})
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					disabled: P === null,
					onClick: () => P !== null && h({
						type: "bid",
						pile: N,
						slot: P
					}),
					className: "btn-base min-h-11 flex-none font-display font-extrabold text-white wide:short:px-4",
					style: { background: T.accent },
					children: P === null ? g("games.stockpile.bidChooseSlot") : g("games.stockpile.bidConfirm", { n: b[P] })
				})
			]
		});
	}
	function Ae() {
		let n = t.myPendingActions;
		return /* @__PURE__ */ p("div", {
			className: "stockpile-play-actions grid h-full min-h-0 grid-rows-[auto_1fr_auto] gap-1 wide:short:flex wide:short:items-center wide:short:gap-2",
			children: [
				/* @__PURE__ */ p("div", {
					className: "flex flex-none items-center justify-center gap-2 overflow-x-auto",
					children: [n.map((e, t) => /* @__PURE__ */ f("button", {
						type: "button",
						onClick: () => {
							ce(t), L(null);
						},
						className: `relative grid min-h-11 min-w-11 place-items-center rounded-md ${se === t ? "ring-3 ring-felt" : ""}`,
						"aria-label": g(e === "boom" ? "games.stockpile.actionBoom" : "games.stockpile.actionBust"),
						children: /* @__PURE__ */ f(be, {
							card: {
								kind: "action",
								action: e
							},
							size: "sm"
						})
					}, t)), U && /* @__PURE__ */ p("span", {
						className: "flex-none rounded border border-ink bg-surface px-1.5 py-1 text-xs font-black",
						children: [
							g(U === "boom" ? "games.stockpile.actionBoom" : "games.stockpile.actionBust"),
							" ",
							U === "boom" ? "+2" : "−2"
						]
					})]
				}),
				/* @__PURE__ */ f("div", {
					className: "grid min-h-0 grid-cols-3 gap-1 wide:short:min-w-0 wide:short:flex-1 wide:short:grid-flow-col wide:short:grid-cols-none wide:short:auto-cols-[minmax(72px,1fr)] wide:short:overflow-x-auto",
					children: _.map((t) => {
						let n = W === null ? null : e.prices[t] + W, r = n === null ? "" : n > 10 ? g("games.stockpile.previewSplit") : n < 1 ? g("games.stockpile.previewBankrupt") : String(n);
						return /* @__PURE__ */ p("button", {
							type: "button",
							disabled: !U,
							onClick: () => L(t),
							className: "stockpile-target",
							"data-selected": I === t,
							"aria-label": `${g(C[t])} $${e.prices[t]}K ${r}`,
							title: g(C[t]),
							children: [/* @__PURE__ */ f("span", {
								"aria-hidden": !0,
								children: v[t].emoji
							}), /* @__PURE__ */ p("span", {
								className: "font-mono text-[10px] tabular-nums",
								children: [e.prices[t], n !== null && /* @__PURE__ */ p(d, { children: ["→", r] })]
							})]
						}, t);
					})
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					disabled: !U || !I,
					onClick: () => {
						U && I && (h({
							type: "play",
							card: U,
							company: I
						}), ce(null), L(null));
					},
					className: "btn-base min-h-11 flex-none bg-felt px-3 font-display font-extrabold text-white",
					children: I && U ? g("games.stockpile.actionConfirm", { company: g(C[I]) }) : g("games.stockpile.actionPickTarget")
				})
			]
		});
	}
	function $() {
		let n = _.filter((e) => (t.myRegular[e] ?? 0) > 0 || (x?.split[e] ?? 0) > 0), r = I && n.includes(I) ? I : null, i = (e) => r ? e === "regular" ? t.myRegular[r] ?? 0 : (x?.split[r] ?? 0) - (e === "split" ? F.convert[r] ?? 0 : F.split[r] ?? 0) : 0, a = _.reduce((t, n) => t + (F.regular[n] ?? 0) * e.prices[n] + (F.split[n] ?? 0) * 2 * e.prices[n] + (F.convert[n] ?? 0) * e.prices[n], 0), o = r ? F[R][r] ?? 0 : 0;
		return /* @__PURE__ */ p("div", {
			className: "stockpile-sell-actions flex h-full flex-col justify-center gap-1 wide:short:flex-row wide:short:items-center wide:short:gap-2",
			children: [
				/* @__PURE__ */ f("div", {
					className: "flex flex-none items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
					children: n.map((n) => /* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => L(n),
						className: "stockpile-holding",
						"data-selected": r === n,
						style: { "--stock-color": v[n].track },
						"aria-label": `${g(C[n])} ${(t.myRegular[n] ?? 0) + (x?.split[n] ?? 0)} ${g("games.stockpile.stockCard")} $${e.prices[n]}K`,
						children: [/* @__PURE__ */ f("span", {
							"aria-hidden": !0,
							className: "text-lg",
							children: v[n].emoji
						}), /* @__PURE__ */ p("span", {
							className: "flex min-w-0 flex-col items-start leading-none",
							children: [/* @__PURE__ */ p("span", {
								className: "font-mono text-[11px] font-black tabular-nums",
								children: [
									"×",
									(t.myRegular[n] ?? 0) + (x?.split[n] ?? 0),
									" ",
									/* @__PURE__ */ p("span", {
										className: "opacity-60",
										children: ["$", e.prices[n]]
									})
								]
							}), /* @__PURE__ */ f("span", {
								className: "text-[9px] font-bold",
								children: (F.regular[n] ?? 0) + (F.split[n] ?? 0) + (F.convert[n] ?? 0) > 0 ? `−${(F.regular[n] ?? 0) + (F.split[n] ?? 0) + (F.convert[n] ?? 0)}` : g("games.stockpile.sellPick")
							})]
						})]
					}, n))
				}),
				!r && /* @__PURE__ */ f("p", {
					className: "flex min-h-0 flex-1 items-center justify-center rounded border border-dashed border-ink/30 bg-surface/70 px-2 text-center text-xs font-bold opacity-70 wide:short:hidden",
					children: g("games.stockpile.sellPickCompany")
				}),
				r && /* @__PURE__ */ p("div", {
					className: "flex min-w-0 flex-none items-center gap-1 wide:short:flex-1",
					children: [[
						"regular",
						"split",
						"convert"
					].map((e) => (e === "regular" ? (t.myRegular[r] ?? 0) > 0 : (x?.split[r] ?? 0) > 0) ? /* @__PURE__ */ f("button", {
						type: "button",
						onClick: () => z(e),
						className: `min-h-11 flex-1 rounded-lg border-2 border-ink text-[10px] font-bold ${R === e ? "bg-felt text-white" : "bg-surface"}`,
						children: g(e === "regular" ? "games.stockpile.sellRegular" : e === "split" ? "games.stockpile.sellSplit" : "games.stockpile.sellConvert")
					}, e) : null), /* @__PURE__ */ p("span", {
						className: "flex flex-none items-center gap-1",
						children: [
							/* @__PURE__ */ f("button", {
								type: "button",
								"aria-label": "-",
								onClick: () => le({
									...F,
									[R]: {
										...F[R],
										[r]: Math.max(0, o - 1)
									}
								}),
								className: "size-11 rounded-lg border-2 border-ink bg-surface font-black",
								children: "−"
							}),
							/* @__PURE__ */ f("span", {
								className: "w-6 text-center font-mono text-sm font-black tabular-nums",
								children: o
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								"aria-label": "+",
								onClick: () => le({
									...F,
									[R]: {
										...F[R],
										[r]: Math.min(i(R), o + 1)
									}
								}),
								className: "size-11 rounded-lg border-2 border-ink bg-surface font-black",
								children: "+"
							})
						]
					})]
				}),
				/* @__PURE__ */ p("div", {
					className: "stockpile-sell-confirm mt-auto flex flex-none items-center gap-2 wide:short:mt-0",
					children: [/* @__PURE__ */ f("span", {
						className: "flex-1 text-xs font-bold",
						children: g("games.stockpile.sellGain", { n: a })
					}), /* @__PURE__ */ f("button", {
						type: "button",
						onClick: () => h({
							type: "sell",
							...F
						}),
						className: "btn-base min-h-11 flex-none px-4 font-display font-extrabold text-white",
						style: { background: T.accent },
						children: g("games.stockpile.sellConfirm")
					})]
				})
			]
		});
	}
	function je(e) {
		let n = t.myRegular[e] ?? 0, r = x?.split[e] ?? 0;
		return /* @__PURE__ */ p("div", {
			className: "stockpile-dividend-actions flex h-full flex-col justify-center gap-1.5 wide:short:flex-row wide:short:items-center wide:short:gap-3",
			children: [[[
				g("games.stockpile.dividendRegular", { n: B }),
				B,
				n,
				ue
			], [
				g("games.stockpile.dividendSplit", { n: V }),
				V,
				r,
				de
			]].map(([e, t, n, r], i) => /* @__PURE__ */ p("div", {
				className: "flex flex-none items-center gap-2 wide:short:min-w-0 wide:short:flex-1",
				children: [
					/* @__PURE__ */ f("span", {
						className: "flex-1 text-xs font-bold",
						children: e
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						"aria-label": "-",
						onClick: () => r(Math.max(0, t - 1)),
						className: "size-11 rounded-lg border-2 border-ink bg-surface font-black",
						children: "−"
					}),
					/* @__PURE__ */ f("span", {
						className: "w-6 text-center font-mono text-sm font-black tabular-nums",
						children: t
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						"aria-label": "+",
						onClick: () => r(Math.min(n, t + 1)),
						className: "size-11 rounded-lg border-2 border-ink bg-surface font-black",
						children: "+"
					})
				]
			}, i)), /* @__PURE__ */ f("button", {
				type: "button",
				onClick: () => h({
					type: "dividend",
					regular: B,
					split: V
				}),
				className: "btn-base min-h-11 flex-none font-display font-extrabold text-white",
				style: { background: T.accent },
				children: g("games.stockpile.dividendConfirm", { n: (B + 2 * V) * 2 })
			})]
		});
	}
	return /* @__PURE__ */ f(c, {
		adaptive: !0,
		className: "stockpile-screen",
		scroll: !1,
		banner: ve,
		actions: Z,
		actionsHeight: "stockpile-actions h-48 wide:short:h-20",
		overlay: X,
		children: we
	});
}
function De(e, t, n) {
	switch (e.k) {
		case "bid": return t("games.stockpile.fxBid", {
			name: n(e.rid),
			pile: e.pile + 1,
			n: e.value
		});
		case "settle": return t("games.stockpile.fxSettle", {
			name: n(e.rid),
			pile: e.pile + 1,
			n: e.paid
		});
		case "play": return t("games.stockpile.fxPlay", {
			name: n(e.rid),
			card: e.card === "boom" ? t("games.stockpile.actionBoom") : t("games.stockpile.actionBust"),
			company: t(C[e.company]),
			delta: e.card === "boom" ? t("games.stockpile.deltaUp", { n: 2 }) : t("games.stockpile.deltaDown", { n: 2 })
		});
		case "sell": return t("games.stockpile.fxSell", {
			name: n(e.rid),
			n: e.gained
		});
		case "reveal": return `${e.owner ? `${n(e.owner)}: ` : ""}${t("games.stockpile.fxReveal", {
			company: t(C[e.company]),
			forecast: e.forecast
		})}`;
		case "split": return t("games.stockpile.fxSplit", {
			company: t(C[e.company]),
			n: e.to
		});
		case "bankrupt": return t("games.stockpile.fxBankrupt", { company: t(C[e.company]) });
		case "dividend": return t("games.stockpile.fxDividend", {
			name: n(e.rid),
			m: e.gained
		});
		case "round": return t("games.stockpile.fxRoundEnd", { n: e.round });
	}
}
//#endregion
//#region src/games/stockpile/bot.ts
function X(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Z(e, t) {
	let n = 0, r = [e.private?.myInsider, e.public.insiderPublic];
	for (let e of r) e && e.company === t && (e.forecast === "$$" ? n += 0 : n += e.forecast);
	return n;
}
function Oe(e, t) {
	return t.kind === "stock" ? Math.max(1, e.public.prices[t.company] + Z(e, t.company)) : t.kind === "action" ? 2 : -t.amount;
}
function Q(e, t) {
	let n = e.public.piles[t];
	return n.up.reduce((t, n) => t + Oe(e, n), 0) + n.downCount * 4;
}
var ke = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || !n.awaiting.includes(t.rid)) return null;
	let i = n.players.find((e) => e.rid === t.rid);
	if (!i) return null;
	if (n.phase === "supply") {
		let i = r.mySupplyHand;
		if (!i || i.length !== 2) return null;
		if (t.difficulty === "weak") return { action: {
			type: "place",
			upCard: X([0, 1]),
			upPile: X(n.piles.map((e, t) => t)),
			downPile: X(n.piles.map((e, t) => t))
		} };
		let a = i.map((t) => Oe(e, t)), o = a[0] <= a[1] ? 0 : 1, s = 0, c = 0;
		for (let t = 0; t < n.piles.length; t += 1) Q(e, t) > Q(e, s) && (s = t), Q(e, t) < Q(e, c) && (c = t);
		return { action: {
			type: "place",
			upCard: o,
			upPile: c,
			downPile: s
		} };
	}
	if (n.phase === "demand") {
		let r = [];
		for (let e = 0; e < n.piles.length; e += 1) {
			let t = n.piles[e].bid;
			for (let n = 0; n < b.length && !(b[n] > i.cash); n += 1) t && n <= t.slot || r.push({
				pile: e,
				slot: n
			});
		}
		if (r.length === 0) {
			let e = n.piles.flatMap((e, t) => b.map((e, n) => ({
				pile: t,
				slot: n,
				v: e
			})).filter((e) => e.v <= i.cash));
			if (e.length === 0) return null;
			let t = X(e);
			return { action: {
				type: "bid",
				pile: t.pile,
				slot: t.slot
			} };
		}
		if (t.difficulty === "weak") return { action: {
			type: "bid",
			...X(r)
		} };
		let a = r[0], o = -Infinity;
		for (let t of r) {
			let n = Q(e, t.pile) - b[t.slot];
			n > o && (o = n, a = t);
		}
		return { action: {
			type: "bid",
			...a
		} };
	}
	if (n.phase === "action") {
		let a = r.myPendingActions[0];
		if (!a) return null;
		if (t.difficulty === "weak") return { action: {
			type: "play",
			card: a,
			company: X(Object.keys(v))
		} };
		let o = (e, t) => n.players.find((t) => t.rid === e)?.split[t] ?? 0, s = "cosmic";
		if (a === "boom") {
			let t = -Infinity;
			for (let a of Object.keys(v)) {
				let o = ((r.myRegular[a] ?? 0) + (i.split[a] ?? 0)) * 2 + Z(e, a) + n.prices[a] / 20;
				o > t && (t = o, s = a);
			}
		} else {
			let e = -Infinity;
			for (let a of Object.keys(v)) {
				let c = (r.myRegular[a] ?? 0) + (i.split[a] ?? 0), l = n.players.filter((e) => e.rid !== t.rid).reduce((e, t) => e + o(t.rid, a), 0) * 2 - c * 10 + n.prices[a] / 10;
				l > e && (e = l, s = a);
			}
		}
		return { action: {
			type: "play",
			card: a,
			company: s
		} };
	}
	if (n.phase === "sell") {
		let a = {}, o = {};
		if (t.difficulty !== "weak") for (let t of Object.keys(v)) Z(e, t) + (n.prices[t] >= 9 ? -1 : 0) < 0 && ((r.myRegular[t] ?? 0) > 0 && (a[t] = r.myRegular[t]), (i.split[t] ?? 0) > 0 && (o[t] = i.split[t]));
		return { action: {
			type: "sell",
			regular: a,
			split: o,
			convert: {}
		} };
	}
	if (n.phase === "movement" && n.dividend) {
		let e = n.dividend.company;
		return { action: {
			type: "dividend",
			regular: t.difficulty === "weak" ? 0 : r.myRegular[e] ?? 0,
			split: t.difficulty === "weak" ? 0 : i.split[e] ?? 0
		} };
	}
	return null;
}, Ae = (e, t, n) => {
	if (e.type === "place") {
		let r = t.private?.mySupplyHand ?? [], i = (e) => {
			let t = r[e];
			return t ? t.kind === "stock" ? n(C[t.company]) + n("games.stockpile.stockCard") : t.kind === "fee" ? n("games.stockpile.feeCard", { n: t.amount }) : t.action === "boom" ? n("games.stockpile.actionBoom") : n("games.stockpile.actionBust") : "";
		};
		return n("games.stockpile.botPlace", {
			up: i(e.upCard),
			upPile: e.upPile + 1,
			down: i(1 - e.upCard),
			downPile: e.downPile + 1
		});
	}
	if (e.type === "bid") return n("games.stockpile.botBid", {
		pile: e.pile + 1,
		n: b[e.slot]
	});
	if (e.type === "play") {
		let t = e.card === "boom" ? n("games.stockpile.actionBoom") : n("games.stockpile.actionBust"), r = e.card === "boom" ? n("games.stockpile.deltaUp", { n: 2 }) : n("games.stockpile.deltaDown", { n: 2 });
		return n("games.stockpile.botPlay", {
			card: t,
			company: n(C[e.company]),
			delta: r
		});
	}
	if (e.type === "sell") {
		let r = (e) => Object.values(e).reduce((e, t) => e + (t ?? 0), 0), i = r(e.regular) + r(e.split) + r(e.convert);
		if (i === 0) return n("games.stockpile.botSellSkip");
		let a = 0;
		for (let n of Object.keys(v)) a += (e.regular[n] ?? 0) * t.public.prices[n] + (e.split[n] ?? 0) * 2 * t.public.prices[n] + (e.convert[n] ?? 0) * t.public.prices[n];
		return n("games.stockpile.botSell", {
			n: i,
			m: a
		});
	}
	return e.type === "dividend" ? n("games.stockpile.botDividend", {
		n: e.regular + e.split,
		m: 2 * (e.regular + 2 * e.split)
	}) : "";
};
//#endregion
//#region src/games/stockpile/fx.tsx
function $(e, t) {
	let n = e?.[t];
	return typeof n == "number" ? n : null;
}
function je(e, t, n, r = 900) {
	let i = e.rid ? t.anchor(`seat:${e.rid}`) : null;
	return i ? {
		ms: r,
		node: /* @__PURE__ */ f(m, {
			at: i,
			ms: r,
			children: n
		})
	} : null;
}
var Me = {
	bid(e, t) {
		let n = e.data, r = $(n, "pile"), i = $(n, "value"), a = r === null ? null : t.anchor(`pile:${r}`);
		return !a || i === null ? null : {
			ms: 600,
			node: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(h, {
				at: a,
				ms: 600
			}), /* @__PURE__ */ p(m, {
				at: a,
				ms: 800,
				children: [
					"$",
					i,
					"K"
				]
			})] })
		};
	},
	settle(e, t) {
		let n = e.data, r = $(n, "paid"), i = $(n, "pile"), a = i === null ? null : t.anchor(`pile:${i}`);
		return {
			ms: x,
			node: /* @__PURE__ */ p(d, { children: [a && /* @__PURE__ */ f(h, {
				at: a,
				ms: 700
			}), r !== null && je(e, t, `−$${r}K`)?.node] })
		};
	},
	play(e, t) {
		let n = e.data, r = n?.company, i = n?.card;
		if (!r || !i) return null;
		let a = t.anchor(`track:${r}`);
		return a ? {
			ms: 900,
			node: /* @__PURE__ */ f(m, {
				at: a,
				ms: 900,
				children: /* @__PURE__ */ f("span", {
					className: `font-mono font-black ${i === "boom" ? "text-done-ink" : "text-danger-ink"}`,
					children: i === "boom" ? "+2" : "−2"
				})
			})
		} : null;
	},
	sell(e, t) {
		let n = e.data, r = $(n, "gained");
		return r ? je(e, t, `+$${r}K`) : null;
	},
	reveal(e, t) {
		let n = (e.data ?? {}).pair;
		if (!n) return {
			ms: S,
			node: null
		};
		let r = t.anchor(`track:${n.company}`);
		return r ? {
			ms: S,
			node: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(h, {
				at: r,
				ms: 700
			}), /* @__PURE__ */ f(m, {
				at: r,
				ms: 1100,
				children: /* @__PURE__ */ p("span", {
					className: "font-mono font-black",
					children: [
						v[n.company].emoji,
						" ",
						w(n.forecast)
					]
				})
			})] })
		} : {
			ms: S,
			node: null
		};
	},
	dividend(e, t) {
		let n = e.data, r = $(n, "gained");
		return r ? je(e, t, `+$${r}K`) : null;
	}
};
//#endregion
//#region src/games/stockpile/game-over-row.tsx
function Ne({ public: e, rid: t }) {
	let n = a(), r = e.final?.find((e) => e.rid === t);
	if (!r) return null;
	let i = [
		[
			n("games.stockpile.finalCash"),
			r.cash,
			""
		],
		[
			n("games.stockpile.finalMajority"),
			r.majority,
			"+"
		],
		[
			n("games.stockpile.finalSell"),
			r.sellValue,
			"+"
		],
		[
			n("games.stockpile.finalFees"),
			r.feesPaid,
			"−"
		]
	];
	return /* @__PURE__ */ p("div", {
		className: "stockpile-final-breakdown mt-2 flex flex-wrap gap-1.5 border-t border-dashed border-ink/35 pt-2 text-ink-soft",
		children: [i.map(([e, t, n]) => /* @__PURE__ */ p("span", {
			className: "flex min-w-32 flex-1 items-center justify-between gap-1 rounded border border-ink/30 bg-surface px-1.5 py-1 text-[10px] font-bold",
			children: [/* @__PURE__ */ f("span", {
				className: "truncate",
				children: e
			}), /* @__PURE__ */ p("span", {
				className: "flex-none font-mono tabular-nums",
				children: [
					n,
					"$",
					t,
					"K"
				]
			})]
		}, e)), /* @__PURE__ */ p("span", {
			className: "flex min-w-18 flex-1 items-center justify-between gap-1 rounded border-2 border-ink bg-done-soft px-1.5 py-1 text-[10px] font-black text-done-ink",
			children: [/* @__PURE__ */ f("span", {
				className: "truncate",
				children: n("games.stockpile.finalTotal")
			}), /* @__PURE__ */ p("span", {
				className: "flex-none font-mono tabular-nums",
				children: [
					"$",
					r.total,
					"K"
				]
			})]
		})]
	});
}
//#endregion
//#region src/games/stockpile/game-over.tsx
function Pe(e) {
	return /* @__PURE__ */ f("div", {
		className: "stockpile-over",
		children: /* @__PURE__ */ f(g, {
			...e,
			accent: T.accent,
			renderRowExtra: (t) => /* @__PURE__ */ f(Ne, {
				public: e.public,
				rid: t,
				myRid: e.myRid
			})
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/stockpile/entry.tsx
var Fe = {
	definition: J,
	View: we,
	bot: ke,
	describe: Ae,
	fx: Me,
	OverView: Pe,
	RowView: Ne,
	locales: {
		zh: {
			name: "纵横股海",
			desc: "靠内幕消息竞价抢牌堆,低买高卖争当大股东",
			rules: "目标:经过若干回合的股票买卖,现金最多者获胜。\n准备:\n· 六家公司股价从 5 起步;每人获得 $20K 起始资金与一张随机起始股票。\n· 每回合重新配对公司卡与预测卡:每人一对私有内幕,一对公开,其余暗置。\n流程(每回合):\n· 供应:每个交易区翻一张明牌;每人领两张市场牌,一张面朝上、一张面朝下放进任意交易区。\n· 需求：按行动顺序选择交易区并出价。竞价档位依次为$0K、$1K、$3K、$6K、$10K、$15K、$20K和$25K，新出价必须高于该交易区已有的出价。\n· 出价被超过的玩家，须在之后轮到自己时重新出价。每个交易区都恰好有一名玩家出价后，各玩家支付自己的出价，并拿取该交易区的全部卡牌。\n· 交易费用须立即支付。资金不足的部分记为欠款；之后获得资金时，立即用所得资金偿还欠款。\n· 行动：按行动顺序打出本轮获得的全部行动卡。大涨使股价上升两格，大跌使股价下降两格。\n· 卖出:按顺位卖出任意数量股票,拆股区的股票双倍计价,也可按单倍卖回并转回普通区。\n· 移动：按行动顺序揭示各玩家私有的公司卡与预测卡组合，并相应调整股价；然后依次揭示公开组合与背面朝上的组合，继续调整股价。\n· 预测为 $$ 时分红:每亮出一股获得 $2K(拆股区双倍),亮出几股由自己决定。\n· 股价超过10时，触发拆股：将持有的股票公开移入拆股区。已经拆股的股票再次触发拆股时，每股改为获得$10K。\n· 股价低于 1 则破产:该公司股票全部作废,股价重置为 5。\n结束:\n· 末回合后判定各家多数股东(拆股算双倍):单独多数获得 $10K,并列各获得 $5K。\n· 随后全部股票按最终股价卖回银行,现金最多者获胜,平分则并列获胜。",
			compCosmic: "宇宙电脑",
			compBottomline: "底线银行",
			compLeading: "领先实验室",
			compAutomotive: "美国汽车",
			compStanford: "斯坦福钢铁",
			compEpic: "传奇电力",
			forecastDividend: "分红",
			round: "第 {{n}} 回合",
			roundShort: "{{n}}/{{total}}",
			phaseSupply: "供应阶段",
			phaseDemand: "需求阶段",
			phaseSettle: "结算交易区",
			phaseAction: "行动阶段",
			phaseSell: "卖出阶段",
			phaseMovement: "移动阶段",
			phaseDone: "已结束",
			supplyPrompt: "把两张手牌各选一个交易区:一张明放、一张暗放",
			supplyWaiting: "等 {{name}} 放置市场牌…",
			supplyUp: "明放",
			supplyDown: "暗放",
			supplyConfirm: "确认放置",
			demandPrompt: "点选交易区计算器,再选出价档位",
			demandWaiting: "等 {{name}} 出价…",
			demandOutbid: "你的出价被超过了,请重新出价",
			bidConfirm: "出价 ${{n}}K",
			bidChooseSlot: "选择出价档位",
			bidPreview: "预出价 ${{n}}K",
			bidLocked: "该区已到顶价",
			settleWaiting: "正在结算各交易区…",
			actionPrompt: "打出行动卡:选择一张,再选目标公司",
			actionWaiting: "等 {{name}} 打出行动卡…",
			actionBoom: "大涨",
			actionBust: "大跌",
			actionPickTarget: "先选行动卡和公司",
			actionConfirm: "确认作用于{{company}}",
			actionPreview: "预计股价 {{n}}",
			previewSplit: "拆股",
			previewBankrupt: "破产",
			sellPrompt: "卖出任意数量股票,不卖可直接确认",
			sellPickCompany: "点选一张持股凭条，查看卖出档位",
			sellPick: "点选",
			sellWaiting: "等 {{name}} 卖出股票…",
			sellRegular: "普通区",
			sellSplit: "拆股区",
			sellConvert: "单倍卖回",
			sellConfirm: "确认卖出",
			sellGain: "预计收入 ${{n}}K",
			dividendPrompt: "{{company}} 分红:选择亮出的股数",
			dividendWaiting: "等持股者亮股分红…",
			dividendRegular: "普通区亮 {{n}} 股",
			dividendSplit: "拆股区亮 {{n}} 股",
			dividendConfirm: "亮股分红 +${{n}}K",
			movementWaiting: "正在揭示内幕预测…",
			insiderPublic: "公开内幕",
			insiderDown: "暗置 {{n}} 对",
			insiderYours: "你的内幕",
			stockCard: "股票",
			feeCard: "交易费 -${{n}}K",
			deckLeft: "牌库剩 {{n}}",
			pile: "{{n}} 号交易区",
			pileEmpty: "待放牌",
			bidOpen: "等待竞价",
			bidSelected: "已选目标",
			bankruptSpace: "破产格",
			splitSpace: "拆股格",
			cash: "现金",
			myAssets: "我的资产",
			startStock: "起始股票",
			majority: "多数奖",
			finalCash: "手上现金",
			finalMajority: "多数奖",
			finalSell: "股票清仓",
			finalFees: "补缴交易费",
			finalTotal: "总计",
			fxDeal: "新回合:内幕与手牌已发放",
			fxPlace: "{{name}} 放置了市场牌",
			fxBid: "{{name}} 在 {{pile}} 号交易区出价 ${{n}}K",
			fxOutbid: "{{name}} 被超价",
			fxSettle: "{{name}} 以 ${{n}}K 拿下 {{pile}} 号交易区",
			fxPlay: "{{name}} 打出{{card}}:{{company}} {{delta}}",
			fxSell: "{{name}} 卖出股票收入 ${{n}}K",
			fxReveal: "揭示:{{company}} {{forecast}}",
			fxSplit: "{{company}} 拆股!股价回落 {{n}}",
			fxBankrupt: "{{company}} 破产!股票作废,股价重置 5",
			fxDividend: "{{name}} 分红获得 ${{m}}K",
			fxRoundEnd: "进入第 {{n}} 回合",
			fxGameEnd: "终局结算",
			errNotYourTurn: "现在轮不到你",
			errBadPile: "没有这个交易区",
			errBadBid: "这个档位出不了:必须更高且不超过现金",
			errBadCard: "没有这张行动卡",
			errBadSell: "卖出数量超过持股",
			errBadDividend: "亮股数量超过持股",
			botPlace: "把 {{up}} 明放进 {{upPile}} 号区,{{down}} 暗放进 {{downPile}} 号区",
			botBid: "在 {{pile}} 号交易区出价 ${{n}}K",
			botPlay: "打出{{card}},让{{company}}{{delta}}",
			botSell: "卖出 {{n}} 只股票,收入约 ${{m}}K",
			botSellSkip: "这轮不卖出",
			botDividend: "亮出 {{n}} 股领取分红 ${{m}}K",
			deltaUp: "+{{n}}",
			deltaDown: "-{{n}}"
		},
		en: {
			name: "Stockpile",
			desc: "Bid on stockpiles with insider tips, buy low and sell high",
			rules: "Goal: after several rounds of trading, the richest player wins.\nSetup:\n· Six companies start at price 5; each player gets $20K and one random starting stock.\n· Each round, company and forecast cards are re-paired: one private pair per player, one public pair, the rest face-down.\nEach round:\n· Supply: flip one card face-up per stockpile; each player takes two market cards and places one face-up and one face-down onto any stockpiles.\n· Demand: In turn order, choose a stockpile and bid $0K, $1K, $3K, $6K, $10K, $15K, $20K or $25K. Each new bid must exceed the current bid on that stockpile.\n· Outbid players bid again later; once every stockpile has exactly one bid, pay and take all its cards.\n· Trading fees are paid at once; if you cannot pay, keep them as debt paid off whenever money arrives.\n· Action: in turn order, play all action cards gained this round; Boom raises the share price by 2 spaces, while Bust lowers it by 2 spaces.\n· Sell: in turn order, sell any shares; split shares pay double, or sell a split share at single price and return it to your regular portfolio.\n· Movement: players reveal their insider pairs in turn order and move prices, then the public pair, then the face-down pairs.\n· A $$ forecast pays dividends: $2K per revealed share (double for split shares); you choose how many shares to reveal.\n· Above 10 the stock splits: shares move face-up to the split portfolio; already-split shares pay $10K each instead.\n· Below 1 the company goes bankrupt: all its shares are discarded and the price resets to 5.\nGame end:\n· After the last round, majority holders per company (split counts double) gain $10K, or $5K each when tied.\n· Then all shares are sold at final prices; the richest player wins, ties win together.",
			compCosmic: "Cosmic Computers",
			compBottomline: "Bottomline Bank",
			compLeading: "Leading Laboratories",
			compAutomotive: "American Automotive",
			compStanford: "Stanford Steel",
			compEpic: "Epic Electric",
			forecastDividend: "$$",
			round: "Round {{n}}",
			roundShort: "{{n}}/{{total}}",
			phaseSupply: "Supply",
			phaseDemand: "Demand",
			phaseSettle: "Settling stockpiles",
			phaseAction: "Action",
			phaseSell: "Sell",
			phaseMovement: "Movement",
			phaseDone: "Finished",
			supplyPrompt: "Place your two cards onto stockpiles: one face-up, one face-down",
			supplyWaiting: "Waiting for {{name}} to place cards…",
			supplyUp: "Face-up",
			supplyDown: "Face-down",
			supplyConfirm: "Confirm placement",
			demandPrompt: "Tap a stockpile calculator, then choose a bid",
			demandWaiting: "Waiting for {{name}} to bid…",
			demandOutbid: "You were outbid — place a new bid",
			bidConfirm: "Bid ${{n}}K",
			bidChooseSlot: "Choose a bid",
			bidPreview: "Preview bid ${{n}}K",
			bidLocked: "That stockpile is at the maximum bid",
			settleWaiting: "Settling stockpiles…",
			actionPrompt: "Play an action card, then choose its target company",
			actionWaiting: "Waiting for {{name}} to play action cards…",
			actionBoom: "Boom",
			actionBust: "Bust",
			actionPickTarget: "Choose a card and company",
			actionConfirm: "Confirm on {{company}}",
			actionPreview: "Projected price {{n}}",
			previewSplit: "Split",
			previewBankrupt: "Bust",
			sellPrompt: "Sell any number of shares, or confirm to sell nothing",
			sellPickCompany: "Choose a holding certificate to set a sale",
			sellPick: "Pick",
			sellWaiting: "Waiting for {{name}} to sell…",
			sellRegular: "Regular",
			sellSplit: "Split",
			sellConvert: "Single-price sell-back",
			sellConfirm: "Confirm sales",
			sellGain: "Expected income ${{n}}K",
			dividendPrompt: "{{company}} dividend: choose how many shares to reveal",
			dividendWaiting: "Waiting for shareholders to reveal…",
			dividendRegular: "Reveal {{n}} regular",
			dividendSplit: "Reveal {{n}} split",
			dividendConfirm: "Reveal for +${{n}}K",
			movementWaiting: "Revealing insider forecasts…",
			insiderPublic: "Public insider",
			insiderDown: "{{n}} face-down",
			insiderYours: "Your insider tip",
			stockCard: "Stock",
			feeCard: "Fee -${{n}}K",
			deckLeft: "{{n}} cards left",
			pile: "Stockpile {{n}}",
			pileEmpty: "Awaiting cards",
			bidOpen: "Awaiting bid",
			bidSelected: "Selected",
			bankruptSpace: "Bankruptcy space",
			splitSpace: "Split space",
			cash: "Cash",
			myAssets: "My assets",
			startStock: "Starting stock",
			majority: "Majority bonus",
			finalCash: "Cash in hand",
			finalMajority: "Majority bonuses",
			finalSell: "Final sell-off",
			finalFees: "Fees settled",
			finalTotal: "Total",
			fxDeal: "New round: insider tips and cards dealt",
			fxPlace: "{{name}} placed market cards",
			fxBid: "{{name}} bid ${{n}}K on stockpile {{pile}}",
			fxOutbid: "{{name}} was outbid",
			fxSettle: "{{name}} takes stockpile {{pile}} for ${{n}}K",
			fxPlay: "{{name}} plays {{card}}: {{company}} {{delta}}",
			fxSell: "{{name}} sold shares for ${{n}}K",
			fxReveal: "Revealed: {{company}} {{forecast}}",
			fxSplit: "{{company}} splits! Price falls back to {{n}}",
			fxBankrupt: "{{company}} goes bankrupt! Shares discarded, price resets to 5",
			fxDividend: "{{name}} collects ${{m}}K in dividends",
			fxRoundEnd: "Round {{n}} begins",
			fxGameEnd: "Final scoring",
			errNotYourTurn: "Not your turn right now",
			errBadPile: "No such stockpile",
			errBadBid: "Cannot bid there: must be higher and within your cash",
			errBadCard: "You do not have that action card",
			errBadSell: "Selling more shares than you hold",
			errBadDividend: "Revealing more shares than you hold",
			botPlace: "Place {{up}} face-up on stockpile {{upPile}}, {{down}} face-down on {{downPile}}",
			botBid: "Bid ${{n}}K on stockpile {{pile}}",
			botPlay: "Play {{card}} to move {{company}} {{delta}}",
			botSell: "Sell {{n}} shares for about ${{m}}K",
			botSellSkip: "Sell nothing this round",
			botDividend: "Reveal {{n}} shares for ${{m}}K in dividends",
			deltaUp: "+{{n}}",
			deltaDown: "-{{n}}"
		}
	}
};
//#endregion
export { Fe as default };
