import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useCallback as r, useEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { useT as l } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { HintRing as f } from "@bgparty/sdk/ui/hint-ring";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as m } from "@bgparty/sdk/ui/player-strip";
import { usePrefersReducedMotion as h } from "@bgparty/sdk/fx/use-reduced-motion";
import { ResilientCanvas as ee } from "@bgparty/sdk/three/resilient-canvas";
import { useFrame as g, useThree as _ } from "@react-three/fiber";
import { AnimationClip as te, AnimationMixer as v, Bone as y, Box3 as b, BufferAttribute as x, BufferGeometry as S, CanvasTexture as C, ClampToEdgeWrapping as w, Color as T, ColorManagement as E, DirectionalLight as D, DoubleSide as O, FileLoader as k, FrontSide as ne, Group as A, ImageBitmapLoader as re, InstancedBufferAttribute as ie, InstancedMesh as ae, InterleavedBuffer as oe, InterleavedBufferAttribute as se, Interpolant as ce, InterpolateDiscrete as le, InterpolateLinear as ue, Line as de, LineBasicMaterial as fe, LineLoop as pe, LineSegments as me, LinearFilter as he, LinearMipmapLinearFilter as ge, LinearMipmapNearestFilter as _e, LinearSRGBColorSpace as j, Loader as ve, LoaderUtils as ye, Material as be, MathUtils as xe, Matrix4 as Se, Mesh as Ce, MeshBasicMaterial as M, MeshPhysicalMaterial as N, MeshStandardMaterial as we, MirroredRepeatWrapping as Te, NearestFilter as Ee, NearestMipmapLinearFilter as De, NearestMipmapNearestFilter as Oe, NumberKeyframeTrack as ke, Object3D as Ae, OrthographicCamera as je, PerspectiveCamera as Me, PlaneGeometry as Ne, PointLight as Pe, Points as Fe, PointsMaterial as Ie, PropertyBinding as Le, Quaternion as Re, QuaternionKeyframeTrack as ze, RepeatWrapping as Be, SRGBColorSpace as Ve, Skeleton as He, SkinnedMesh as Ue, Sphere as We, SpotLight as Ge, Texture as Ke, TextureLoader as qe, TriangleFanDrawMode as Je, TriangleStripDrawMode as Ye, TrianglesDrawMode as Xe, Vector2 as Ze, Vector3 as P, VectorKeyframeTrack as Qe } from "three";
import { Fragment as $e, jsx as F, jsxs as I } from "react/jsx-runtime";
import { Floater as et, PulseBox as tt } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as nt } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as rt, OptionSection as it } from "@bgparty/sdk/ui/game-options";
//#region src/games/readysetbet/cards.ts
var L = [
	"2/3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"10",
	"11/12"
], R = [
	"blue",
	"blue",
	"orange",
	"red",
	"black",
	"red",
	"orange",
	"blue",
	"blue"
], at = [
	3,
	3,
	2,
	1,
	0,
	1,
	2,
	3,
	3
];
function ot(e) {
	return e === 2 || e === 3 ? 0 : e === 11 || e === 12 ? 8 : e - 3;
}
var z = [
	{
		show: [[4, 4], [4, 3]],
		place: [[5, 4], [5, 3]],
		win: [
			[7, 2],
			[8, 2],
			[9, 2]
		]
	},
	{
		show: [[3, 1], [3, 0]],
		place: [[4, 1], [4, 0]],
		win: [
			[5, 1],
			[6, 0],
			[7, 0]
		]
	},
	{
		show: [[2, 3], [2, 0]],
		place: [[2, 2], [3, 2]],
		win: [
			[4, 2],
			[4, 0],
			[5, 0]
		]
	},
	{
		show: [[1, 2], [1, 0]],
		place: [[2, 5], [2, 4]],
		win: [
			[3, 2],
			[3, 1],
			[3, 0]
		]
	},
	{
		show: [[1, 3], [1, 1]],
		place: [[2, 6], [2, 5]],
		win: [
			[3, 4],
			[3, 3],
			[3, 2]
		]
	},
	{
		show: [[1, 2], [1, 0]],
		place: [[2, 5], [2, 4]],
		win: [
			[3, 2],
			[3, 1],
			[3, 0]
		]
	},
	{
		show: [[2, 3], [2, 0]],
		place: [[2, 2], [3, 2]],
		win: [
			[4, 2],
			[4, 0],
			[5, 0]
		]
	},
	{
		show: [[3, 1], [3, 0]],
		place: [[4, 1], [4, 0]],
		win: [
			[5, 1],
			[6, 0],
			[7, 0]
		]
	},
	{
		show: [[4, 4], [4, 3]],
		place: [[5, 4], [5, 3]],
		win: [
			[7, 2],
			[8, 2],
			[9, 2]
		]
	}
], B = [
	{
		key: "blue",
		mult: 5,
		penalty: 1
	},
	{
		key: "orange",
		mult: 3,
		penalty: 1
	},
	{
		key: "red",
		mult: 2,
		penalty: 1
	},
	{
		key: "seven5th",
		mult: 4,
		penalty: 0
	}
], st = [
	0,
	1,
	7,
	8
], ct = [2, 6], lt = [
	{
		win: 3,
		loss: 3,
		over: [8],
		under: [2]
	},
	{
		win: 2,
		loss: 1,
		over: [8],
		under: [6]
	},
	{
		win: 4,
		loss: 3,
		over: [8],
		under: [3]
	},
	{
		win: 3,
		loss: 2,
		over: [8],
		under: [5]
	},
	{
		win: 3,
		loss: 3,
		over: [8],
		under: [6]
	},
	{
		win: 2,
		loss: 1,
		over: [8],
		under: [2]
	},
	{
		win: 3,
		loss: 2,
		over: [7],
		under: [5]
	},
	{
		win: 4,
		loss: 3,
		over: [7],
		under: [3]
	},
	{
		win: 2,
		loss: 1,
		over: [7],
		under: [2]
	},
	{
		win: 3,
		loss: 3,
		over: [7],
		under: [2]
	},
	{
		win: 4,
		loss: 4,
		over: [2],
		under: [4]
	},
	{
		win: 2,
		loss: 1,
		over: [6],
		under: [5]
	},
	{
		win: 3,
		loss: 3,
		over: [6],
		under: [3]
	},
	{
		win: 3,
		loss: 3,
		over: [5],
		under: ct
	},
	{
		win: 2,
		loss: 3,
		over: [3],
		under: st
	},
	{
		win: 2,
		loss: 5,
		over: [4],
		under: ct
	},
	{
		win: 2,
		loss: 6,
		over: [4],
		under: st
	},
	{
		win: 3,
		loss: 3,
		over: [3],
		under: ct
	},
	{
		win: 3,
		loss: 5,
		over: [3],
		under: st
	},
	{
		win: 3,
		loss: 2,
		over: [2],
		under: [4]
	},
	{
		win: 3,
		loss: 3,
		over: [6],
		under: [5]
	},
	{
		win: 2,
		loss: 1,
		over: [2],
		under: [3]
	},
	{
		win: 3,
		loss: 2,
		over: [1],
		under: [5]
	},
	{
		win: 4,
		loss: 3,
		over: [1],
		under: [3]
	},
	{
		win: 2,
		loss: 1,
		over: [1],
		under: [6]
	},
	{
		win: 3,
		loss: 3,
		over: [1],
		under: [2]
	},
	{
		win: 4,
		loss: 3,
		over: [0],
		under: [5]
	},
	{
		win: 3,
		loss: 2,
		over: [0],
		under: [3]
	}
], ut = [
	{
		key: "tightRace",
		win: 6,
		loss: 2
	},
	{
		key: "lateStart",
		win: 4,
		loss: 1
	},
	{
		key: "photoFinish",
		win: 5,
		loss: 3
	},
	{
		key: "byANose",
		win: 5,
		loss: 3
	},
	{
		key: "blowOut",
		win: 4,
		loss: 2
	}
], V = [
	...["white", "black"].flatMap((e) => [
		{
			key: "bonus",
			color: e,
			value: 2,
			extraLoss: 0,
			negateLoss: !0
		},
		{
			key: "bonus",
			color: e,
			value: 3,
			extraLoss: 0,
			negateLoss: !1
		},
		{
			key: "bonus",
			color: e,
			value: 4,
			extraLoss: 1,
			negateLoss: !1
		},
		{
			key: "bonus",
			color: e,
			value: 5,
			extraLoss: 2,
			negateLoss: !1
		},
		{
			key: "bonus",
			color: e,
			value: 6,
			extraLoss: 3,
			negateLoss: !1
		},
		{
			key: "bonus",
			color: e,
			value: 7,
			extraLoss: 5,
			negateLoss: !1
		}
	]),
	{ key: "snakeEyes" },
	{ key: "snakeEyes" },
	{ key: "snakeEyes" },
	{ key: "lastSecond" },
	{
		key: "favored",
		horse: 1
	},
	{
		key: "favored",
		horse: 7
	},
	{
		key: "favored",
		horse: 0
	},
	{
		key: "favored",
		horse: 8
	},
	{ key: "highRoller" },
	{ key: "highRoller" },
	{
		key: "sideBet",
		horses: [2, 3],
		pay: [[
			10,
			8,
			3
		], [
			6,
			4,
			2
		]]
	},
	{
		key: "sideBet",
		horses: [5, 6],
		pay: [[
			6,
			4,
			2
		], [
			10,
			8,
			3
		]]
	},
	{ key: "compChips" },
	{ key: "compChips" },
	{ key: "compChips" },
	{
		key: "piggyback",
		token: 2
	},
	{
		key: "piggyback",
		token: 3
	},
	{
		key: "piggyback",
		token: 4
	},
	{ key: "risky" },
	{ key: "risky" }
], dt = [
	9,
	6,
	4
], ft = {
	red: 1,
	orange: 2,
	blue: 3,
	black: 0
}, pt = [
	2,
	3,
	3,
	4,
	5
], mt = [
	2,
	3,
	4,
	5
], ht = {
	id: "readysetbet",
	tier: "beta",
	mechanics: ["betting"],
	interactionTags: [],
	nameKey: "games.readysetbet.name",
	descKey: "games.readysetbet.desc",
	rulesKey: "games.readysetbet.rules",
	icon: "🏇",
	iconImg: "games/readysetbet.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/readysetbet/en.pdf" },
	minPlayers: 2,
	maxPlayers: 8,
	bestPlayers: [
		6,
		7,
		8
	],
	accent: "#15803d",
	releasedAt: "2026-09-28",
	search: {
		py: "sai ma da heng",
		init: "smdh"
	},
	hotseat: "off"
}, gt = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("wps"),
		horse: t.int().min(0).max(8),
		col: t.enum([
			"show",
			"place",
			"win"
		]),
		cell: t.int().min(0).max(2)
	}),
	t.object({
		kind: t.literal("color"),
		key: t.enum([
			"blue",
			"orange",
			"red",
			"seven5th"
		])
	}),
	t.object({
		kind: t.literal("prop"),
		card: t.int().min(0).max(4)
	}),
	t.object({
		kind: t.literal("exotic"),
		card: t.int().min(0).max(3)
	})
]), _t = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("bet"),
		spot: gt,
		tokenId: t.string()
	}),
	t.object({
		type: t.literal("pick"),
		card: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), vt = t.object({ rollMs: t.union([
	t.literal(1500),
	t.literal(2500),
	t.literal(4e3)
]).catch(2500) }).default({ rollMs: 2500 }), yt = t.string(), bt = t.discriminatedUnion("key", [
	t.object({
		key: t.literal("bonus"),
		color: t.enum(["white", "black"]),
		value: t.int().min(2).max(7),
		extraLoss: t.int(),
		negateLoss: t.boolean()
	}),
	t.object({ key: t.literal("snakeEyes") }),
	t.object({ key: t.literal("lastSecond") }),
	t.object({
		key: t.literal("favored"),
		horse: t.int().min(0).max(8)
	}),
	t.object({ key: t.literal("highRoller") }),
	t.object({
		key: t.literal("sideBet"),
		horses: t.tuple([t.int(), t.int()]),
		pay: t.tuple([t.tuple([
			t.int(),
			t.int(),
			t.int()
		]), t.tuple([
			t.int(),
			t.int(),
			t.int()
		])])
	}),
	t.object({ key: t.literal("compChips") }),
	t.object({
		key: t.literal("piggyback"),
		token: t.int().min(2).max(4)
	}),
	t.object({ key: t.literal("risky") })
]), xt = t.object({
	id: t.string(),
	value: t.int().min(2).max(7),
	bonus: t.object({
		color: t.enum(["white", "black"]),
		extraLoss: t.int(),
		negateLoss: t.boolean()
	}).nullable()
}), St = t.object({
	rid: yt,
	spot: gt,
	token: xt,
	piggyback: t.boolean()
}), Ct = t.object({
	race: t.int().min(1).max(4),
	phase: t.enum([
		"racing",
		"settle",
		"draft",
		"done"
	]),
	positions: t.array(t.int()).length(9),
	lastRoll: t.object({
		d1: t.int(),
		d2: t.int(),
		sum: t.int(),
		horse: t.int(),
		bonus: t.boolean()
	}).nullable(),
	noMoreBets: t.boolean(),
	propsOpen: t.array(t.int()),
	exoticsOpen: t.array(t.int()),
	bets: t.array(St),
	players: t.array(t.object({
		rid: yt,
		money: t.int(),
		vipCount: t.int().nonnegative()
	})),
	result: t.object({
		order: t.array(t.int()),
		deltas: t.record(t.string(), t.int())
	}).nullable(),
	draftWaiting: t.array(yt)
}), wt = t.object({
	tokens: t.array(xt),
	vip: t.array(bt),
	favoredAcc: t.int().nonnegative(),
	draftOptions: t.array(bt).nullable(),
	piggybackTokens: t.array(t.int())
}), Tt = 6e3;
function Et(t, n, r) {
	let i = Array.from({ length: t }, (e, t) => t);
	for (let t = i.length - 1; t > 0; --t) {
		let a = e(n, r.at, t + 1);
		r.at += 1, [i[t], i[a]] = [i[a], i[t]];
	}
	return i;
}
function Dt(e) {
	return (e >= 7 ? mt : pt).map((e, t) => ({
		id: `b${t}`,
		value: e,
		bonus: null
	}));
}
function Ot(e, t, n) {
	let r = { at: 0 }, i = Et(lt.length, n, r), a = Et(ut.length, n, r), o = Et(V.length, n, r), s = {}, c = {}, l = {}, u = {}, d = {};
	for (let e of t) s[e] = Dt(t.length), c[e] = 0, l[e] = [], u[e] = 0, d[e] = !1;
	return {
		state: {
			players: t,
			rollMs: e.rollMs,
			seed: n,
			rngCursor: r.at,
			race: 1,
			phase: "racing",
			positions: Array.from({ length: 9 }, () => 0),
			prevSum: null,
			prevBonus: !1,
			lastRoll: null,
			noMoreBets: !1,
			propDeck: i.slice(5),
			propsOpen: i.slice(0, 5),
			exoticOrder: a,
			vipDeck: o,
			vipHands: l,
			draftOptions: {},
			tokensAll: s,
			bets: [],
			money: c,
			favoredAcc: u,
			piggybackUsed: d,
			result: null,
			tokenSeq: 0
		},
		fx: [{
			kind: "raceStart",
			data: { race: 1 }
		}]
	};
}
function kt(e, t) {
	e.race = t, e.phase = "racing", e.positions = Array.from({ length: 9 }, () => 0), e.prevSum = null, e.prevBonus = !1, e.lastRoll = null, e.noMoreBets = !1, e.bets = [], e.propsOpen = e.propDeck.slice(0, 5), e.propDeck = e.propDeck.slice(5);
	for (let t of e.players) e.favoredAcc[t] = 0, e.piggybackUsed[t] = !1;
	e.result = null;
}
var At = (e) => e.exoticOrder.slice(0, e.race), H = (e, t) => (e.vipHands[t] ?? []).map((e) => V[e]);
function jt(e) {
	let t = Array.from({ length: 9 }, (e, t) => t).sort((t, n) => e[n] - e[t] || t - n), n = Array.from({ length: 9 }, () => 1), r = 1;
	for (let i = 0; i < t.length; i += 1) i > 0 && e[t[i]] < e[t[i - 1]] && (r = i + 1), n[t[i]] = r;
	return {
		rank: n,
		order: t
	};
}
function Mt(e) {
	let t = Object.fromEntries(e.players.map((e) => [e, 0])), { rank: n, order: r } = jt(e.positions), i = r[0], a = [...new Set(e.positions)].sort((e, t) => t - e), o = (t, n) => H(e, t).some((e) => e.key === n);
	for (let r of e.bets) {
		let s, c, l;
		if (r.spot.kind === "wps") {
			let { horse: e, col: t, cell: i } = r.spot, a = z[e][t][i], u = t === "win" ? 1 : t === "place" ? 2 : 3;
			s = n[e] <= u;
			let d = a[0];
			s && t === "win" && o(r.rid, "highRoller") && (d += ft[R[e]]), c = r.token.value * d, l = a[1];
		} else if (r.spot.kind === "color") {
			let e = B.find((e) => e.key === r.spot.key);
			if (!e) continue;
			s = e.key === "seven5th" ? n[4] >= 5 : R[i] === e.key, c = r.token.value * e.mult, l = e.penalty;
		} else if (r.spot.kind === "prop") {
			let t = lt[e.propsOpen[r.spot.card]];
			s = Math.min(...t.over.map((t) => e.positions[t])) > Math.max(...t.under.map((t) => e.positions[t])), c = r.token.value * t.win, l = t.loss;
		} else {
			let t = ut[At(e)[r.spot.card]], n = a.length >= 2 ? 15 - a[1] : 0;
			s = t.key === "tightRace" ? e.positions.every((e) => e >= 6) : t.key === "lateStart" ? e.positions.filter((e) => e <= 3).length >= 2 : t.key === "photoFinish" ? a.length >= 3 && 15 - a[2] <= 3 : t.key === "byANose" ? n === 1 : n > 5, c = r.token.value * t.win, l = t.loss;
		}
		if (s) t[r.rid] += c + (o(r.rid, "risky") ? 2 : 0);
		else {
			let e = r.token.bonus?.negateLoss ? 0 : l > 0 ? l + (r.token.bonus?.extraLoss ?? 0) : 0;
			t[r.rid] -= e + +!!o(r.rid, "risky");
		}
	}
	for (let n of e.players) e.favoredAcc[n] > 0 && i !== 4 && (t[n] += e.favoredAcc[n]);
	for (let r of e.players) for (let i of H(e, r)) i.key === "sideBet" && i.horses.forEach((e, a) => {
		let o = n[e];
		o <= 3 && (t[r] += i.pay[a][o - 1]);
	});
	return t;
}
function Nt(t) {
	if (t.vipDeck.length === 0) {
		let n = /* @__PURE__ */ new Set();
		for (let e of t.players) {
			for (let r of t.vipHands[e]) n.add(r);
			for (let r of t.draftOptions[e] ?? []) n.add(r);
		}
		let r = Array.from({ length: V.length }, (e, t) => t).filter((e) => !n.has(e)), i = r.length > 0 ? r : Array.from({ length: V.length }, (e, t) => t);
		for (let n = i.length - 1; n > 0; --n) {
			let r = e(t.seed, t.rngCursor, n + 1);
			t.rngCursor += 1, [i[n], i[r]] = [i[r], i[n]];
		}
		t.vipDeck = i;
	}
	return t.vipDeck.pop();
}
function Pt(e, t) {
	return e.kind === t.kind ? e.kind === "wps" && t.kind === "wps" ? e.horse === t.horse && e.col === t.col && e.cell === t.cell : e.kind === "color" && t.kind === "color" ? e.key === t.key : e.card === t.card : !1;
}
function Ft(t) {
	let n = 1 + e(t.seed, t.rngCursor, 6), r = 1 + e(t.seed, t.rngCursor + 1, 6);
	t.rngCursor += 2;
	let i = n + r, a = ot(i), o = t.prevSum !== null && ot(t.prevSum) === a && !t.prevBonus, s = t.positions[a], c = Math.min(15, s + 1 + (o ? at[a] : 0));
	t.positions[a] = c, t.prevSum = i, t.prevBonus = o, t.lastRoll = {
		d1: n,
		d2: r,
		sum: i,
		horse: a,
		bonus: o
	};
	let l = [{
		kind: "roll",
		data: {
			d1: n,
			d2: r,
			sum: i,
			horse: a,
			from: s,
			to: c,
			bonus: o
		}
	}];
	if (i === 2 || i === 12) for (let e of t.players) {
		let n = H(t, e).filter((e) => e.key === "snakeEyes").length;
		n > 0 && (t.money[e] += n);
	}
	for (let e of t.players) {
		let n = H(t, e).filter((e) => e.key === "favored" && e.horse === a).length;
		n > 0 && (t.favoredAcc[e] += n);
	}
	let u = t.positions.filter((e) => e >= 9).length;
	if (!t.noMoreBets && u >= 3 && (t.noMoreBets = !0, l.push({
		kind: "noMoreBets",
		data: {},
		with: !0
	})), c >= 15) {
		let e = Mt(t);
		for (let n of t.players) t.money[n] = Math.max(0, t.money[n] + e[n]);
		t.result = {
			order: jt(t.positions).order,
			deltas: e
		}, t.phase = "settle", l.push({
			kind: "settle",
			data: {
				winner: a,
				deltas: e
			},
			with: !0
		});
	}
	return {
		state: t,
		fx: l
	};
}
function It(e, t, n) {
	if (t.type === "tick") {
		let t = structuredClone(e);
		if (t.phase === "racing") return Ft(t);
		if (t.phase === "settle") {
			if (t.race >= 4) return t.phase = "done", {
				state: t,
				fx: []
			};
			t.phase = "draft";
			for (let e of t.players) t.draftOptions[e] = [Nt(t), Nt(t)];
			return {
				state: t,
				fx: [{
					kind: "draftDeal",
					data: {}
				}]
			};
		}
		return {
			state: t,
			fx: []
		};
	}
	if (t.type === "pick") {
		if (e.phase !== "draft" || !e.draftOptions[n.by]) return { code: "games.readysetbet.errNotDraft" };
		let r = structuredClone(e), i = r.draftOptions[n.by], a = i[t.card], o = i[1 - t.card];
		delete r.draftOptions[n.by], r.vipHands[n.by] = [...r.vipHands[n.by], a], r.vipDeck.push(o);
		let s = V[a], c = [{
			kind: "vipGain",
			rid: n.by,
			data: { key: s.key }
		}];
		if (s.key === "bonus" && (r.tokenSeq += 1, r.tokensAll[n.by] = [...r.tokensAll[n.by], {
			id: `v${r.tokenSeq}`,
			value: s.value,
			bonus: {
				color: s.color,
				extraLoss: s.extraLoss,
				negateLoss: s.negateLoss
			}
		}]), s.key === "compChips") {
			let e = dt[Math.min(r.vipHands[n.by].length, 3) - 1];
			r.money[n.by] += e, c = [...c, {
				kind: "chipGain",
				rid: n.by,
				data: { amount: e },
				with: !0
			}];
		}
		return Object.keys(r.draftOptions).length === 0 && (kt(r, r.race + 1), c = [...c, {
			kind: "raceStart",
			data: { race: r.race },
			with: !0
		}]), {
			state: r,
			fx: c
		};
	}
	if (e.phase !== "racing") return { code: "games.readysetbet.errNotRacing" };
	let r = H(e, n.by);
	if (e.noMoreBets && !r.some((e) => e.key === "lastSecond")) return { code: "games.readysetbet.errNoMoreBets" };
	let i = new Set(e.bets.filter((e) => e.rid === n.by).map((e) => e.token.id)), a = (e.tokensAll[n.by] ?? []).find((e) => e.id === t.tokenId);
	if (!a || i.has(a.id)) return { code: "games.readysetbet.errNoToken" };
	let o = t.spot;
	if (o.kind === "wps" && o.cell >= z[o.horse][o.col].length) return { code: "games.readysetbet.errBadSpot" };
	let s = e.bets.filter((e) => Pt(e.spot, o)), c = !1;
	if (o.kind === "exotic") {
		if (o.card >= At(e).length || s.some((e) => e.rid === n.by)) return { code: "games.readysetbet.errBadSpot" };
		if (s.length >= 3) return { code: "games.readysetbet.errSpotTaken" };
	} else {
		if (o.kind === "prop" && o.card >= e.propsOpen.length) return { code: "games.readysetbet.errBadSpot" };
		if (s.length > 0) {
			if (s.length !== 1 || s[0].rid === n.by || e.piggybackUsed[n.by] || !r.some((e) => e.key === "piggyback" && e.token === a.value)) return { code: "games.readysetbet.errSpotTaken" };
			c = !0;
		}
	}
	let l = structuredClone(e);
	return c && (l.piggybackUsed[n.by] = !0), l.bets = [...l.bets, {
		rid: n.by,
		spot: o,
		token: a,
		piggyback: c
	}], {
		state: l,
		fx: [{
			kind: "bet",
			rid: n.by,
			data: {
				spot: o,
				value: a.value,
				piggyback: c
			}
		}]
	};
}
function Lt(e, t) {
	let n = new Set(e.bets.filter((e) => e.rid === t).map((e) => e.token.id)), r = H(e, t);
	return {
		public: {
			race: e.race,
			phase: e.phase,
			positions: e.positions,
			lastRoll: e.lastRoll,
			noMoreBets: e.noMoreBets,
			propsOpen: e.propsOpen,
			exoticsOpen: At(e),
			bets: e.bets,
			players: e.players.map((t) => ({
				rid: t,
				money: e.money[t],
				vipCount: e.vipHands[t]?.length ?? 0
			})),
			result: e.result,
			draftWaiting: Object.keys(e.draftOptions)
		},
		private: {
			tokens: (e.tokensAll[t] ?? []).filter((e) => !n.has(e.id)),
			vip: r,
			favoredAcc: e.favoredAcc[t] ?? 0,
			draftOptions: e.draftOptions[t] ? e.draftOptions[t].map((e) => V[e]) : null,
			piggybackTokens: e.piggybackUsed[t] ? [] : r.filter((e) => e.key === "piggyback").map((e) => e.token)
		}
	};
}
function Rt(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.money[n] - e.money[t]), n = e.money[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.money[t] === n),
		ranking: t,
		scores: { ...e.money }
	};
}
function zt(e) {
	return e.phase === "racing" ? e.rollMs : e.phase === "settle" ? Tt : null;
}
var Bt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ht,
	schemas: {
		action: _t,
		publicView: Ct,
		privateView: wt,
		config: vt
	},
	setup: Ot,
	reduce: It,
	viewFor: Lt,
	status: Rt,
	nextTickIn: zt
};
//#endregion
//#region node_modules/three/examples/jsm/utils/BufferGeometryUtils.js
function Vt(e, t) {
	if (t === Xe) return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."), e;
	if (t === Je || t === Ye) {
		let n = e.getIndex();
		if (n === null) {
			let t = [], r = e.getAttribute("position");
			if (r !== void 0) {
				for (let e = 0; e < r.count; e++) t.push(e);
				e.setIndex(t), n = e.getIndex();
			} else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."), e;
		}
		let r = n.count - 2, i = [];
		if (t === Je) for (let e = 1; e <= r; e++) i.push(n.getX(0)), i.push(n.getX(e)), i.push(n.getX(e + 1));
		else for (let e = 0; e < r; e++) e % 2 == 0 ? (i.push(n.getX(e)), i.push(n.getX(e + 1)), i.push(n.getX(e + 2))) : (i.push(n.getX(e + 2)), i.push(n.getX(e + 1)), i.push(n.getX(e)));
		return i.length / 3 !== r && console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles."), e.setIndex(i), e.clearGroups(), e;
	}
	return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:", t), e;
}
//#endregion
//#region node_modules/three/examples/jsm/utils/SkeletonUtils.js
function Ht(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = e.clone();
	return Ut(e, r, function(e, r) {
		t.set(r, e), n.set(e, r);
	}), r.traverse(function(e) {
		if (!e.isSkinnedMesh) return;
		let r = e, i = t.get(e), a = i.skeleton.bones;
		r.skeleton = i.skeleton.clone(), r.bindMatrix.copy(i.bindMatrix), r.skeleton.bones = a.map(function(e) {
			return n.get(e);
		}), r.bind(r.skeleton, r.bindMatrix);
	}), r;
}
function Ut(e, t, n) {
	n(e, t);
	for (let r = 0; r < e.children.length; r++) Ut(e.children[r], t.children[r], n);
}
//#endregion
//#region node_modules/three/examples/jsm/loaders/GLTFLoader.js
var Wt = class extends ve {
	constructor(e) {
		super(e), this.dracoLoader = null, this.ktx2Loader = null, this.meshoptDecoder = null, this.pluginCallbacks = [], this.register(function(e) {
			return new Yt(e);
		}), this.register(function(e) {
			return new Xt(e);
		}), this.register(function(e) {
			return new on(e);
		}), this.register(function(e) {
			return new sn(e);
		}), this.register(function(e) {
			return new cn(e);
		}), this.register(function(e) {
			return new Qt(e);
		}), this.register(function(e) {
			return new $t(e);
		}), this.register(function(e) {
			return new en(e);
		}), this.register(function(e) {
			return new tn(e);
		}), this.register(function(e) {
			return new Jt(e);
		}), this.register(function(e) {
			return new nn(e);
		}), this.register(function(e) {
			return new Zt(e);
		}), this.register(function(e) {
			return new an(e);
		}), this.register(function(e) {
			return new rn(e);
		}), this.register(function(e) {
			return new Kt(e);
		}), this.register(function(e) {
			return new ln(e, W.EXT_MESHOPT_COMPRESSION);
		}), this.register(function(e) {
			return new ln(e, W.KHR_MESHOPT_COMPRESSION);
		}), this.register(function(e) {
			return new un(e);
		});
	}
	load(e, t, n, r) {
		let i = this, a;
		if (this.resourcePath !== "") a = this.resourcePath;
		else if (this.path !== "") {
			let t = ye.extractUrlBase(e);
			a = ye.resolveURL(t, this.path);
		} else a = ye.extractUrlBase(e);
		this.manager.itemStart(e);
		let o = function(t) {
			r ? r(t) : console.error(t), i.manager.itemError(e), i.manager.itemEnd(e);
		}, s = new k(this.manager);
		s.setPath(this.path), s.setResponseType("arraybuffer"), s.setRequestHeader(this.requestHeader), s.setWithCredentials(this.withCredentials), s.load(e, function(n) {
			try {
				i.parse(n, a, function(n) {
					t(n), i.manager.itemEnd(e);
				}, o);
			} catch (e) {
				o(e);
			}
		}, n, o);
	}
	setDRACOLoader(e) {
		return this.dracoLoader = e, this;
	}
	setKTX2Loader(e) {
		return this.ktx2Loader = e, this;
	}
	setMeshoptDecoder(e) {
		return this.meshoptDecoder = e, this;
	}
	register(e) {
		return this.pluginCallbacks.indexOf(e) === -1 && this.pluginCallbacks.push(e), this;
	}
	unregister(e) {
		return this.pluginCallbacks.indexOf(e) !== -1 && this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e), 1), this;
	}
	parse(e, t, n, r) {
		let i, a = {}, o = {}, s = new TextDecoder();
		if (typeof e == "string") i = JSON.parse(e);
		else if (e instanceof ArrayBuffer) {
			if (s.decode(new Uint8Array(e, 0, 4)) === dn) {
				try {
					a[W.KHR_BINARY_GLTF] = new pn(e);
				} catch (e) {
					r && r(e);
					return;
				}
				i = JSON.parse(a[W.KHR_BINARY_GLTF].content);
			} else i = JSON.parse(s.decode(e));
		} else i = e;
		if (i.asset === void 0 || i.asset.version[0] < 2) {
			r && r(/* @__PURE__ */ Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));
			return;
		}
		let c = new Pn(i, {
			path: t || this.resourcePath || "",
			crossOrigin: this.crossOrigin,
			requestHeader: this.requestHeader,
			manager: this.manager,
			ktx2Loader: this.ktx2Loader,
			meshoptDecoder: this.meshoptDecoder
		});
		c.fileLoader.setRequestHeader(this.requestHeader);
		for (let e = 0; e < this.pluginCallbacks.length; e++) {
			let t = this.pluginCallbacks[e](c);
			t.name || console.error("THREE.GLTFLoader: Invalid plugin found: missing name"), o[t.name] = t, a[t.name] = !0;
		}
		if (i.extensionsUsed) for (let e = 0; e < i.extensionsUsed.length; ++e) {
			let t = i.extensionsUsed[e], n = i.extensionsRequired || [];
			switch (t) {
				case W.KHR_MATERIALS_UNLIT:
					a[t] = new qt();
					break;
				case W.KHR_DRACO_MESH_COMPRESSION:
					a[t] = new mn(i, this.dracoLoader);
					break;
				case W.KHR_TEXTURE_TRANSFORM:
					a[t] = new hn();
					break;
				case W.KHR_MESH_QUANTIZATION:
					a[t] = new gn();
					break;
				default: n.indexOf(t) >= 0 && o[t] === void 0 && console.warn("THREE.GLTFLoader: Unknown extension \"" + t + "\".");
			}
		}
		c.setExtensions(a), c.setPlugins(o), c.parse(n, r);
	}
	parseAsync(e, t) {
		let n = this;
		return new Promise(function(r, i) {
			n.parse(e, t, r, i);
		});
	}
};
function Gt() {
	let e = {};
	return {
		get: function(t) {
			return e[t];
		},
		add: function(t, n) {
			e[t] = n;
		},
		remove: function(t) {
			delete e[t];
		},
		removeAll: function() {
			e = {};
		}
	};
}
function U(e, t, n) {
	let r = e.json.materials[t];
	return r.extensions && r.extensions[n] ? r.extensions[n] : null;
}
var W = {
	KHR_BINARY_GLTF: "KHR_binary_glTF",
	KHR_DRACO_MESH_COMPRESSION: "KHR_draco_mesh_compression",
	KHR_LIGHTS_PUNCTUAL: "KHR_lights_punctual",
	KHR_MATERIALS_CLEARCOAT: "KHR_materials_clearcoat",
	KHR_MATERIALS_DISPERSION: "KHR_materials_dispersion",
	KHR_MATERIALS_IOR: "KHR_materials_ior",
	KHR_MATERIALS_SHEEN: "KHR_materials_sheen",
	KHR_MATERIALS_SPECULAR: "KHR_materials_specular",
	KHR_MATERIALS_TRANSMISSION: "KHR_materials_transmission",
	KHR_MATERIALS_IRIDESCENCE: "KHR_materials_iridescence",
	KHR_MATERIALS_ANISOTROPY: "KHR_materials_anisotropy",
	KHR_MATERIALS_UNLIT: "KHR_materials_unlit",
	KHR_MATERIALS_VOLUME: "KHR_materials_volume",
	KHR_TEXTURE_BASISU: "KHR_texture_basisu",
	KHR_TEXTURE_TRANSFORM: "KHR_texture_transform",
	KHR_MESH_QUANTIZATION: "KHR_mesh_quantization",
	KHR_MATERIALS_EMISSIVE_STRENGTH: "KHR_materials_emissive_strength",
	EXT_MATERIALS_BUMP: "EXT_materials_bump",
	EXT_TEXTURE_WEBP: "EXT_texture_webp",
	EXT_TEXTURE_AVIF: "EXT_texture_avif",
	EXT_MESHOPT_COMPRESSION: "EXT_meshopt_compression",
	KHR_MESHOPT_COMPRESSION: "KHR_meshopt_compression",
	EXT_MESH_GPU_INSTANCING: "EXT_mesh_gpu_instancing"
}, Kt = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_LIGHTS_PUNCTUAL, this.cache = {
			refs: {},
			uses: {}
		};
	}
	_markDefs() {
		let e = this.parser, t = this.parser.json.nodes || [];
		for (let n = 0, r = t.length; n < r; n++) {
			let r = t[n];
			r.extensions && r.extensions[this.name] && r.extensions[this.name].light !== void 0 && e._addNodeRef(this.cache, r.extensions[this.name].light);
		}
	}
	_loadLight(e) {
		let t = this.parser, n = "light:" + e, r = t.cache.get(n);
		if (r) return r;
		let i = t.json, a = ((i.extensions && i.extensions[this.name] || {}).lights || [])[e], o, s = new T(16777215);
		a.color !== void 0 && s.setRGB(a.color[0], a.color[1], a.color[2], j);
		let c = a.range === void 0 ? 0 : a.range;
		switch (a.type) {
			case "directional":
				o = new D(s), o.target.position.set(0, 0, -1), o.add(o.target);
				break;
			case "point":
				o = new Pe(s), o.distance = c;
				break;
			case "spot":
				o = new Ge(s), o.distance = c, a.spot = a.spot || {}, a.spot.innerConeAngle = a.spot.innerConeAngle === void 0 ? 0 : a.spot.innerConeAngle, a.spot.outerConeAngle = a.spot.outerConeAngle === void 0 ? Math.PI / 4 : a.spot.outerConeAngle, o.angle = a.spot.outerConeAngle, o.penumbra = 1 - a.spot.innerConeAngle / a.spot.outerConeAngle, o.target.position.set(0, 0, -1), o.add(o.target);
				break;
			default: throw Error("THREE.GLTFLoader: Unexpected light type: " + a.type);
		}
		return o.position.set(0, 0, 0), X(o, a), a.intensity !== void 0 && (o.intensity = a.intensity), o.name = t.createUniqueName(a.name || "light_" + e), r = Promise.resolve(o), t.cache.add(n, r), r;
	}
	getDependency(e, t) {
		if (e === "light") return this._loadLight(t);
	}
	createNodeAttachment(e) {
		let t = this, n = this.parser, r = n.json.nodes[e], i = (r.extensions && r.extensions[this.name] || {}).light;
		return i === void 0 ? null : this._loadLight(i).then(function(e) {
			return n._getNodeRef(t.cache, i, e);
		});
	}
}, qt = class {
	constructor() {
		this.name = W.KHR_MATERIALS_UNLIT;
	}
	getMaterialType() {
		return M;
	}
	extendParams(e, t, n) {
		let r = [];
		e.color = new T(1, 1, 1), e.opacity = 1;
		let i = t.pbrMetallicRoughness;
		if (i) {
			if (Array.isArray(i.baseColorFactor)) {
				let t = i.baseColorFactor;
				e.color.setRGB(t[0], t[1], t[2], j), e.opacity = t[3];
			}
			i.baseColorTexture !== void 0 && r.push(n.assignTexture(e, "map", i.baseColorTexture, Ve));
		}
		return Promise.all(r);
	}
}, Jt = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_MATERIALS_EMISSIVE_STRENGTH;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		return n === null || n.emissiveStrength !== void 0 && (t.emissiveIntensity = n.emissiveStrength), Promise.resolve();
	}
}, Yt = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_MATERIALS_CLEARCOAT;
	}
	getMaterialType(e) {
		return U(this.parser, e, this.name) === null ? null : N;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		if (n === null) return Promise.resolve();
		let r = [];
		if (n.clearcoatFactor !== void 0 && (t.clearcoat = n.clearcoatFactor), n.clearcoatTexture !== void 0 && r.push(this.parser.assignTexture(t, "clearcoatMap", n.clearcoatTexture)), n.clearcoatRoughnessFactor !== void 0 && (t.clearcoatRoughness = n.clearcoatRoughnessFactor), n.clearcoatRoughnessTexture !== void 0 && r.push(this.parser.assignTexture(t, "clearcoatRoughnessMap", n.clearcoatRoughnessTexture)), n.clearcoatNormalTexture !== void 0 && (r.push(this.parser.assignTexture(t, "clearcoatNormalMap", n.clearcoatNormalTexture)), n.clearcoatNormalTexture.scale !== void 0)) {
			let e = n.clearcoatNormalTexture.scale;
			t.clearcoatNormalScale = new Ze(e, e);
		}
		return Promise.all(r);
	}
}, Xt = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_MATERIALS_DISPERSION;
	}
	getMaterialType(e) {
		return U(this.parser, e, this.name) === null ? null : N;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		return n === null || (t.dispersion = n.dispersion === void 0 ? 0 : n.dispersion), Promise.resolve();
	}
}, Zt = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_MATERIALS_IRIDESCENCE;
	}
	getMaterialType(e) {
		return U(this.parser, e, this.name) === null ? null : N;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		if (n === null) return Promise.resolve();
		let r = [];
		return n.iridescenceFactor !== void 0 && (t.iridescence = n.iridescenceFactor), n.iridescenceTexture !== void 0 && r.push(this.parser.assignTexture(t, "iridescenceMap", n.iridescenceTexture)), n.iridescenceIor !== void 0 && (t.iridescenceIOR = n.iridescenceIor), t.iridescenceThicknessRange === void 0 && (t.iridescenceThicknessRange = [100, 400]), n.iridescenceThicknessMinimum !== void 0 && (t.iridescenceThicknessRange[0] = n.iridescenceThicknessMinimum), n.iridescenceThicknessMaximum !== void 0 && (t.iridescenceThicknessRange[1] = n.iridescenceThicknessMaximum), n.iridescenceThicknessTexture !== void 0 && r.push(this.parser.assignTexture(t, "iridescenceThicknessMap", n.iridescenceThicknessTexture)), Promise.all(r);
	}
}, Qt = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_MATERIALS_SHEEN;
	}
	getMaterialType(e) {
		return U(this.parser, e, this.name) === null ? null : N;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		if (n === null) return Promise.resolve();
		let r = [];
		if (t.sheenColor = new T(0, 0, 0), t.sheenRoughness = 0, t.sheen = 1, n.sheenColorFactor !== void 0) {
			let e = n.sheenColorFactor;
			t.sheenColor.setRGB(e[0], e[1], e[2], j);
		}
		return n.sheenRoughnessFactor !== void 0 && (t.sheenRoughness = n.sheenRoughnessFactor), n.sheenColorTexture !== void 0 && r.push(this.parser.assignTexture(t, "sheenColorMap", n.sheenColorTexture, Ve)), n.sheenRoughnessTexture !== void 0 && r.push(this.parser.assignTexture(t, "sheenRoughnessMap", n.sheenRoughnessTexture)), Promise.all(r);
	}
}, $t = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_MATERIALS_TRANSMISSION;
	}
	getMaterialType(e) {
		return U(this.parser, e, this.name) === null ? null : N;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		if (n === null) return Promise.resolve();
		let r = [];
		return n.transmissionFactor !== void 0 && (t.transmission = n.transmissionFactor), n.transmissionTexture !== void 0 && r.push(this.parser.assignTexture(t, "transmissionMap", n.transmissionTexture)), Promise.all(r);
	}
}, en = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_MATERIALS_VOLUME;
	}
	getMaterialType(e) {
		return U(this.parser, e, this.name) === null ? null : N;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		if (n === null) return Promise.resolve();
		let r = [];
		t.thickness = n.thicknessFactor === void 0 ? 0 : n.thicknessFactor, n.thicknessTexture !== void 0 && r.push(this.parser.assignTexture(t, "thicknessMap", n.thicknessTexture)), t.attenuationDistance = n.attenuationDistance || Infinity;
		let i = n.attenuationColor || [
			1,
			1,
			1
		];
		return t.attenuationColor = new T().setRGB(i[0], i[1], i[2], j), Promise.all(r);
	}
}, tn = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_MATERIALS_IOR;
	}
	getMaterialType(e) {
		return U(this.parser, e, this.name) === null ? null : N;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		return n === null ? Promise.resolve() : (t.ior = n.ior === void 0 ? 1.5 : n.ior, t.ior === 0 && (t.ior = 1e3), Promise.resolve());
	}
}, nn = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_MATERIALS_SPECULAR;
	}
	getMaterialType(e) {
		return U(this.parser, e, this.name) === null ? null : N;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		if (n === null) return Promise.resolve();
		let r = [];
		t.specularIntensity = n.specularFactor === void 0 ? 1 : n.specularFactor, n.specularTexture !== void 0 && r.push(this.parser.assignTexture(t, "specularIntensityMap", n.specularTexture));
		let i = n.specularColorFactor || [
			1,
			1,
			1
		];
		return t.specularColor = new T().setRGB(i[0], i[1], i[2], j), n.specularColorTexture !== void 0 && r.push(this.parser.assignTexture(t, "specularColorMap", n.specularColorTexture, Ve)), Promise.all(r);
	}
}, rn = class {
	constructor(e) {
		this.parser = e, this.name = W.EXT_MATERIALS_BUMP;
	}
	getMaterialType(e) {
		return U(this.parser, e, this.name) === null ? null : N;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		if (n === null) return Promise.resolve();
		let r = [];
		return t.bumpScale = n.bumpFactor === void 0 ? 1 : n.bumpFactor, n.bumpTexture !== void 0 && r.push(this.parser.assignTexture(t, "bumpMap", n.bumpTexture)), Promise.all(r);
	}
}, an = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_MATERIALS_ANISOTROPY;
	}
	getMaterialType(e) {
		return U(this.parser, e, this.name) === null ? null : N;
	}
	extendMaterialParams(e, t) {
		let n = U(this.parser, e, this.name);
		if (n === null) return Promise.resolve();
		let r = [];
		return n.anisotropyStrength !== void 0 && (t.anisotropy = n.anisotropyStrength), n.anisotropyRotation !== void 0 && (t.anisotropyRotation = n.anisotropyRotation), n.anisotropyTexture !== void 0 && r.push(this.parser.assignTexture(t, "anisotropyMap", n.anisotropyTexture)), Promise.all(r);
	}
}, on = class {
	constructor(e) {
		this.parser = e, this.name = W.KHR_TEXTURE_BASISU;
	}
	loadTexture(e) {
		let t = this.parser, n = t.json, r = n.textures[e];
		if (!r.extensions || !r.extensions[this.name]) return null;
		let i = r.extensions[this.name], a = t.options.ktx2Loader;
		if (!a) {
			if (n.extensionsRequired && n.extensionsRequired.indexOf(this.name) >= 0) throw Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");
			return null;
		}
		return t.loadTextureImage(e, i.source, a);
	}
}, sn = class {
	constructor(e) {
		this.parser = e, this.name = W.EXT_TEXTURE_WEBP;
	}
	loadTexture(e) {
		let t = this.name, n = this.parser, r = n.json, i = r.textures[e];
		if (!i.extensions || !i.extensions[t]) return null;
		let a = i.extensions[t], o = r.images[a.source], s = n.textureLoader;
		if (o.uri) {
			let e = n.options.manager.getHandler(o.uri);
			e !== null && (s = e);
		}
		return n.loadTextureImage(e, a.source, s);
	}
}, cn = class {
	constructor(e) {
		this.parser = e, this.name = W.EXT_TEXTURE_AVIF;
	}
	loadTexture(e) {
		let t = this.name, n = this.parser, r = n.json, i = r.textures[e];
		if (!i.extensions || !i.extensions[t]) return null;
		let a = i.extensions[t], o = r.images[a.source], s = n.textureLoader;
		if (o.uri) {
			let e = n.options.manager.getHandler(o.uri);
			e !== null && (s = e);
		}
		return n.loadTextureImage(e, a.source, s);
	}
}, ln = class {
	constructor(e, t) {
		this.name = t, this.parser = e;
	}
	loadBufferView(e) {
		let t = this.parser.json, n = t.bufferViews[e];
		if (n.extensions && n.extensions[this.name]) {
			let e = n.extensions[this.name], r = this.parser.getDependency("buffer", e.buffer), i = this.parser.options.meshoptDecoder;
			if (!i || !i.supported) {
				if (t.extensionsRequired && t.extensionsRequired.indexOf(this.name) >= 0) throw Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");
				return null;
			}
			return r.then(function(t) {
				let n = e.byteOffset || 0, r = e.byteLength || 0, a = e.count, o = e.byteStride, s = new Uint8Array(t, n, r);
				return i.decodeGltfBufferAsync ? i.decodeGltfBufferAsync(a, o, s, e.mode, e.filter).then(function(e) {
					return e.buffer;
				}) : i.ready.then(function() {
					let t = new ArrayBuffer(a * o);
					return i.decodeGltfBuffer(new Uint8Array(t), a, o, s, e.mode, e.filter), t;
				});
			});
		}
		return null;
	}
}, un = class {
	constructor(e) {
		this.name = W.EXT_MESH_GPU_INSTANCING, this.parser = e;
	}
	createNodeMesh(e) {
		let t = this.parser.json, n = t.nodes[e];
		if (!n.extensions || !n.extensions[this.name] || n.mesh === void 0) return null;
		let r = t.meshes[n.mesh];
		for (let e of r.primitives) if (e.mode !== K.TRIANGLES && e.mode !== K.TRIANGLE_STRIP && e.mode !== K.TRIANGLE_FAN && e.mode !== void 0) return null;
		let i = n.extensions[this.name].attributes, a = [], o = {};
		for (let e in i) a.push(this.parser.getDependency("accessor", i[e]).then((t) => (o[e] = t, o[e])));
		return a.length < 1 ? null : (a.push(this.parser.createNodeMesh(e)), Promise.all(a).then((e) => {
			let t = e.pop(), n = t.isGroup ? t.children : [t], r = e[0].count, i = [];
			for (let e of n) {
				let t = new Se(), n = new P(), a = new Re(), s = new P(1, 1, 1), c = new ae(e.geometry, e.material, r);
				for (let e = 0; e < r; e++) o.TRANSLATION && n.fromBufferAttribute(o.TRANSLATION, e), o.ROTATION && a.fromBufferAttribute(o.ROTATION, e), o.SCALE && s.fromBufferAttribute(o.SCALE, e), c.setMatrixAt(e, t.compose(n, a, s));
				let l = null;
				for (let e in o) if (e === "_COLOR_0") {
					let t = o[e];
					c.instanceColor = new ie(t.array, t.itemSize, t.normalized);
				} else if (e !== "TRANSLATION" && e !== "ROTATION" && e !== "SCALE") {
					if (l === null) {
						let e = c.geometry;
						l = new S(), l.name = e.name;
						for (let t in e.attributes) l.setAttribute(t, e.attributes[t]);
						for (let t in e.morphAttributes) l.morphAttributes[t] = e.morphAttributes[t];
						e.index !== null && l.setIndex(e.index), l.morphTargetsRelative = e.morphTargetsRelative;
						for (let t of e.groups) l.addGroup(t.start, t.count, t.materialIndex);
						e.boundingBox !== null && (l.boundingBox = e.boundingBox.clone()), e.boundingSphere !== null && (l.boundingSphere = e.boundingSphere.clone()), l.drawRange.start = e.drawRange.start, l.drawRange.count = e.drawRange.count, l.userData = Object.assign({}, e.userData), c.geometry = l;
					}
					let t = o[e];
					l.setAttribute(e, new ie(t.array, t.itemSize, t.normalized));
				}
				Ae.prototype.copy.call(c, e), this.parser.assignFinalMaterial(c), i.push(c);
			}
			return t.isGroup ? (t.clear(), t.add(...i), t) : i[0];
		}));
	}
}, dn = "glTF", G = 12, fn = {
	JSON: 1313821514,
	BIN: 5130562
}, pn = class {
	constructor(e) {
		this.name = W.KHR_BINARY_GLTF, this.content = null, this.body = null;
		let t = new DataView(e, 0, G), n = new TextDecoder();
		if (this.header = {
			magic: n.decode(new Uint8Array(e.slice(0, 4))),
			version: t.getUint32(4, !0),
			length: t.getUint32(8, !0)
		}, this.header.magic !== dn) throw Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");
		if (this.header.version < 2) throw Error("THREE.GLTFLoader: Legacy binary file detected.");
		let r = this.header.length - G, i = new DataView(e, G), a = 0;
		for (; a < r;) {
			let t = i.getUint32(a, !0);
			a += 4;
			let r = i.getUint32(a, !0);
			if (a += 4, r === fn.JSON) {
				let r = new Uint8Array(e, G + a, t);
				this.content = n.decode(r);
			} else if (r === fn.BIN) {
				let n = G + a;
				this.body = e.slice(n, n + t);
			}
			a += t;
		}
		if (this.content === null) throw Error("THREE.GLTFLoader: JSON content not found.");
	}
}, mn = class {
	constructor(e, t) {
		if (!t) throw Error("THREE.GLTFLoader: No DRACOLoader instance provided.");
		this.name = W.KHR_DRACO_MESH_COMPRESSION, this.json = e, this.dracoLoader = t, this.dracoLoader.preload();
	}
	decodePrimitive(e, t) {
		let n = this.json, r = this.dracoLoader, i = e.extensions[this.name].bufferView, a = e.extensions[this.name].attributes, o = {}, s = {}, c = {};
		for (let e in a) {
			let t = Cn[e] || e.toLowerCase();
			o[t] = a[e];
		}
		for (let t in e.attributes) {
			let r = Cn[t] || t.toLowerCase();
			if (a[t] !== void 0) {
				let i = n.accessors[e.attributes[t]];
				c[r] = q[i.componentType].name, s[r] = i.normalized === !0;
			}
		}
		return t.getDependency("bufferView", i).then(function(e) {
			return new Promise(function(t, n) {
				r.decodeDracoFile(e, function(e) {
					for (let t in e.attributes) {
						let n = e.attributes[t], r = s[t];
						r !== void 0 && (n.normalized = r);
					}
					t(e);
				}, o, c, j, n);
			});
		});
	}
}, hn = class {
	constructor() {
		this.name = W.KHR_TEXTURE_TRANSFORM;
	}
	extendTexture(e, t) {
		if ((t.texCoord === void 0 || t.texCoord === e.channel) && t.offset === void 0 && t.rotation === void 0 && t.scale === void 0) return e;
		if (e = e.clone(), t.texCoord !== void 0 && (e.channel = t.texCoord), t.offset !== void 0 && e.offset.fromArray(t.offset), t.rotation !== void 0 && (e.rotation = t.rotation), t.scale !== void 0 && e.repeat.fromArray(t.scale), t.rotation !== void 0) {
			let t = Math.cos(e.rotation), n = Math.sin(e.rotation);
			e.matrix.set(e.repeat.x * t, e.repeat.y * n, e.offset.x, -e.repeat.x * n, e.repeat.y * t, e.offset.y, 0, 0, 1), e.matrixAutoUpdate = !1;
		}
		return e.needsUpdate = !0, e;
	}
}, gn = class {
	constructor() {
		this.name = W.KHR_MESH_QUANTIZATION;
	}
}, _n = class extends ce {
	constructor(e, t, n, r) {
		super(e, t, n, r);
	}
	copySampleValue_(e) {
		let t = this.resultBuffer, n = this.sampleValues, r = this.valueSize, i = e * r * 3 + r;
		for (let e = 0; e !== r; e++) t[e] = n[i + e];
		return t;
	}
	interpolate_(e, t, n, r) {
		let i = this.resultBuffer, a = this.sampleValues, o = this.valueSize, s = o * 2, c = o * 3, l = r - t, u = (n - t) / l, d = u * u, f = d * u, p = e * c, m = p - c, h = -2 * f + 3 * d, ee = f - d, g = 1 - h, _ = ee - d + u;
		for (let e = 0; e !== o; e++) {
			let t = a[m + e + o], n = a[m + e + s] * l, r = a[p + e + o], c = a[p + e] * l;
			i[e] = g * t + _ * n + h * r + ee * c;
		}
		return i;
	}
}, vn = new Re(), yn = class extends _n {
	interpolate_(e, t, n, r) {
		let i = super.interpolate_(e, t, n, r);
		return vn.fromArray(i).normalize().toArray(i), i;
	}
}, K = {
	FLOAT: 5126,
	FLOAT_MAT3: 35675,
	FLOAT_MAT4: 35676,
	FLOAT_VEC2: 35664,
	FLOAT_VEC3: 35665,
	FLOAT_VEC4: 35666,
	LINEAR: 9729,
	REPEAT: 10497,
	SAMPLER_2D: 35678,
	POINTS: 0,
	LINES: 1,
	LINE_LOOP: 2,
	LINE_STRIP: 3,
	TRIANGLES: 4,
	TRIANGLE_STRIP: 5,
	TRIANGLE_FAN: 6,
	UNSIGNED_BYTE: 5121,
	UNSIGNED_SHORT: 5123
}, q = {
	5120: Int8Array,
	5121: Uint8Array,
	5122: Int16Array,
	5123: Uint16Array,
	5125: Uint32Array,
	5126: Float32Array
}, bn = {
	9728: Ee,
	9729: he,
	9984: Oe,
	9985: _e,
	9986: De,
	9987: ge
}, xn = {
	33071: w,
	33648: Te,
	10497: Be
}, Sn = {
	SCALAR: 1,
	VEC2: 2,
	VEC3: 3,
	VEC4: 4,
	MAT2: 4,
	MAT3: 9,
	MAT4: 16
}, Cn = {
	POSITION: "position",
	NORMAL: "normal",
	TANGENT: "tangent",
	TEXCOORD_0: "uv",
	TEXCOORD_1: "uv1",
	TEXCOORD_2: "uv2",
	TEXCOORD_3: "uv3",
	COLOR_0: "color",
	WEIGHTS_0: "skinWeight",
	JOINTS_0: "skinIndex"
}, J = {
	scale: "scale",
	translation: "position",
	rotation: "quaternion",
	weights: "morphTargetInfluences"
}, wn = {
	CUBICSPLINE: void 0,
	LINEAR: ue,
	STEP: le
}, Tn = {
	OPAQUE: "OPAQUE",
	MASK: "MASK",
	BLEND: "BLEND"
};
function En(e) {
	return e.DefaultMaterial === void 0 && (e.DefaultMaterial = new we({
		color: 16777215,
		emissive: 0,
		metalness: 1,
		roughness: 1,
		transparent: !1,
		depthTest: !0,
		side: ne
	})), e.DefaultMaterial;
}
function Y(e, t, n) {
	for (let r in n.extensions) e[r] === void 0 && (t.userData.gltfExtensions = t.userData.gltfExtensions || {}, t.userData.gltfExtensions[r] = n.extensions[r]);
}
function X(e, t) {
	t.extras !== void 0 && (typeof t.extras == "object" ? Object.assign(e.userData, t.extras) : console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, " + t.extras));
}
function Dn(e, t, n) {
	let r = !1, i = !1, a = !1;
	for (let e = 0, n = t.length; e < n; e++) {
		let n = t[e];
		if (n.POSITION !== void 0 && (r = !0), n.NORMAL !== void 0 && (i = !0), n.COLOR_0 !== void 0 && (a = !0), r && i && a) break;
	}
	if (!r && !i && !a) return Promise.resolve(e);
	let o = [], s = [], c = [];
	for (let l = 0, u = t.length; l < u; l++) {
		let u = t[l];
		if (r) {
			let t = u.POSITION === void 0 ? e.attributes.position : n.getDependency("accessor", u.POSITION);
			o.push(t);
		}
		if (i) {
			let t = u.NORMAL === void 0 ? e.attributes.normal : n.getDependency("accessor", u.NORMAL);
			s.push(t);
		}
		if (a) {
			let t = u.COLOR_0 === void 0 ? e.attributes.color : n.getDependency("accessor", u.COLOR_0);
			c.push(t);
		}
	}
	return Promise.all([
		Promise.all(o),
		Promise.all(s),
		Promise.all(c)
	]).then(function(t) {
		let n = t[0], o = t[1], s = t[2];
		return r && (e.morphAttributes.position = n), i && (e.morphAttributes.normal = o), a && (e.morphAttributes.color = s), e.morphTargetsRelative = !0, e;
	});
}
function On(e, t) {
	if (e.updateMorphTargets(), t.weights !== void 0) for (let n = 0, r = t.weights.length; n < r; n++) e.morphTargetInfluences[n] = t.weights[n];
	if (t.extras && Array.isArray(t.extras.targetNames)) {
		let n = t.extras.targetNames;
		if (e.morphTargetInfluences.length === n.length) {
			e.morphTargetDictionary = {};
			for (let t = 0, r = n.length; t < r; t++) e.morphTargetDictionary[n[t]] = t;
		} else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.");
	}
}
function kn(e) {
	let t, n = e.extensions && e.extensions[W.KHR_DRACO_MESH_COMPRESSION];
	if (t = n ? "draco:" + n.bufferView + ":" + n.indices + ":" + An(n.attributes) : e.indices + ":" + An(e.attributes) + ":" + e.mode, e.targets !== void 0) for (let n = 0, r = e.targets.length; n < r; n++) t += ":" + An(e.targets[n]);
	return t;
}
function An(e) {
	let t = "", n = Object.keys(e).sort();
	for (let r = 0, i = n.length; r < i; r++) t += n[r] + ":" + e[n[r]] + ";";
	return t;
}
function jn(e) {
	switch (e) {
		case Int8Array: return 1 / 127;
		case Uint8Array: return 1 / 255;
		case Int16Array: return 1 / 32767;
		case Uint16Array: return 1 / 65535;
		default: throw Error("THREE.GLTFLoader: Unsupported normalized accessor component type.");
	}
}
function Mn(e) {
	return e.search(/\.jpe?g($|\?)/i) > 0 || e.search(/^data\:image\/jpeg/) === 0 ? "image/jpeg" : e.search(/\.webp($|\?)/i) > 0 || e.search(/^data\:image\/webp/) === 0 ? "image/webp" : e.search(/\.ktx2($|\?)/i) > 0 || e.search(/^data\:image\/ktx2/) === 0 ? "image/ktx2" : "image/png";
}
var Nn = new Se(), Pn = class {
	constructor(e = {}, t = {}) {
		this.json = e, this.extensions = {}, this.plugins = {}, this.options = t, this.cache = new Gt(), this.associations = /* @__PURE__ */ new Map(), this.primitiveCache = {}, this.nodeCache = {}, this.meshCache = {
			refs: {},
			uses: {}
		}, this.cameraCache = {
			refs: {},
			uses: {}
		}, this.lightCache = {
			refs: {},
			uses: {}
		}, this.sourceCache = {}, this.textureCache = {}, this.nodeNamesUsed = {};
		let n = !1, r = -1, i = !1, a = -1;
		if (typeof navigator < "u" && navigator.userAgent !== void 0) {
			let e = navigator.userAgent;
			n = /^((?!chrome|android).)*safari/i.test(e) === !0;
			let t = e.match(/Version\/(\d+)/);
			r = n && t ? parseInt(t[1], 10) : -1, i = e.indexOf("Firefox") > -1, a = i ? e.match(/Firefox\/([0-9]+)\./)[1] : -1;
		}
		this.textureLoader = typeof createImageBitmap > "u" || n && r < 17 || i && a < 98 ? new qe(this.options.manager) : new re(this.options.manager), this.textureLoader.setCrossOrigin(this.options.crossOrigin), this.textureLoader.setRequestHeader(this.options.requestHeader), this.fileLoader = new k(this.options.manager), this.fileLoader.setResponseType("arraybuffer"), this.options.crossOrigin === "use-credentials" && this.fileLoader.setWithCredentials(!0);
	}
	setExtensions(e) {
		this.extensions = e;
	}
	setPlugins(e) {
		this.plugins = e;
	}
	parse(e, t) {
		let n = this, r = this.json, i = this.extensions;
		this.cache.removeAll(), this.nodeCache = {}, this._invokeAll(function(e) {
			return e._markDefs && e._markDefs();
		}), Promise.all(this._invokeAll(function(e) {
			return e.beforeRoot && e.beforeRoot();
		})).then(function() {
			return Promise.all([
				n.getDependencies("scene"),
				n.getDependencies("animation"),
				n.getDependencies("camera")
			]);
		}).then(function(t) {
			let a = {
				scene: t[0][r.scene || 0],
				scenes: t[0],
				animations: t[1],
				cameras: t[2],
				asset: r.asset,
				parser: n,
				userData: {}
			};
			return Y(i, a, r), X(a, r), Promise.all(n._invokeAll(function(e) {
				return e.afterRoot && e.afterRoot(a);
			})).then(function() {
				for (let e of a.scenes) e.updateMatrixWorld();
				e(a);
			});
		}).catch(t);
	}
	_markDefs() {
		let e = this.json.nodes || [], t = this.json.skins || [], n = this.json.meshes || [];
		for (let n = 0, r = t.length; n < r; n++) {
			let r = t[n].joints;
			for (let t = 0, n = r.length; t < n; t++) e[r[t]].isBone = !0;
		}
		for (let t = 0, r = e.length; t < r; t++) {
			let r = e[t];
			r.mesh !== void 0 && (this._addNodeRef(this.meshCache, r.mesh), r.skin !== void 0 && (n[r.mesh].isSkinnedMesh = !0)), r.camera !== void 0 && this._addNodeRef(this.cameraCache, r.camera);
		}
	}
	_addNodeRef(e, t) {
		t !== void 0 && (e.refs[t] === void 0 && (e.refs[t] = e.uses[t] = 0), e.refs[t]++);
	}
	_getNodeRef(e, t, n) {
		if (e.refs[t] <= 1) return n;
		let r = n.clone(), i = (e, t) => {
			let n = this.associations.get(e);
			n != null && this.associations.set(t, n);
			for (let [n, r] of e.children.entries()) i(r, t.children[n]);
		};
		return i(n, r), r.name += "_instance_" + e.uses[t]++, r;
	}
	_invokeOne(e) {
		let t = Object.values(this.plugins);
		t.push(this);
		for (let n = 0; n < t.length; n++) {
			let r = e(t[n]);
			if (r) return r;
		}
		return null;
	}
	_invokeAll(e) {
		let t = Object.values(this.plugins);
		t.unshift(this);
		let n = [];
		for (let r = 0; r < t.length; r++) {
			let i = e(t[r]);
			i && n.push(i);
		}
		return n;
	}
	getDependency(e, t) {
		let n = e + ":" + t, r = this.cache.get(n);
		if (!r) {
			switch (e) {
				case "scene":
					r = this.loadScene(t);
					break;
				case "node":
					r = this._invokeOne(function(e) {
						return e.loadNode && e.loadNode(t);
					});
					break;
				case "mesh":
					r = this._invokeOne(function(e) {
						return e.loadMesh && e.loadMesh(t);
					});
					break;
				case "accessor":
					r = this.loadAccessor(t);
					break;
				case "bufferView":
					r = this._invokeOne(function(e) {
						return e.loadBufferView && e.loadBufferView(t);
					});
					break;
				case "buffer":
					r = this.loadBuffer(t);
					break;
				case "material":
					r = this._invokeOne(function(e) {
						return e.loadMaterial && e.loadMaterial(t);
					});
					break;
				case "texture":
					r = this._invokeOne(function(e) {
						return e.loadTexture && e.loadTexture(t);
					});
					break;
				case "skin":
					r = this.loadSkin(t);
					break;
				case "animation":
					r = this._invokeOne(function(e) {
						return e.loadAnimation && e.loadAnimation(t);
					});
					break;
				case "camera":
					r = this.loadCamera(t);
					break;
				default: if (r = this._invokeOne(function(n) {
					return n != this && n.getDependency && n.getDependency(e, t);
				}), !r) throw Error("Unknown type: " + e);
			}
			this.cache.add(n, r);
		}
		return r;
	}
	getDependencies(e) {
		let t = this.cache.get(e);
		if (!t) {
			let n = this, r = this.json[e + (e === "mesh" ? "es" : "s")] || [];
			t = Promise.all(r.map(function(t, r) {
				return n.getDependency(e, r);
			})), this.cache.add(e, t);
		}
		return t;
	}
	loadBuffer(e) {
		let t = this.json.buffers[e], n = this.fileLoader;
		if (t.type && t.type !== "arraybuffer") throw Error("THREE.GLTFLoader: " + t.type + " buffer type is not supported.");
		if (t.uri === void 0 && e === 0) return Promise.resolve(this.extensions[W.KHR_BINARY_GLTF].body);
		let r = this.options;
		return new Promise(function(e, i) {
			n.load(ye.resolveURL(t.uri, r.path), e, void 0, function() {
				i(/* @__PURE__ */ Error("THREE.GLTFLoader: Failed to load buffer \"" + t.uri + "\"."));
			});
		});
	}
	loadBufferView(e) {
		let t = this.json.bufferViews[e];
		return this.getDependency("buffer", t.buffer).then(function(e) {
			let n = t.byteLength || 0, r = t.byteOffset || 0;
			return e.slice(r, r + n);
		});
	}
	loadAccessor(e) {
		let t = this, n = this.json, r = this.json.accessors[e];
		if (r.bufferView === void 0 && r.sparse === void 0) {
			let e = Sn[r.type], t = q[r.componentType], n = r.normalized === !0, i = new t(r.count * e);
			return Promise.resolve(new x(i, e, n));
		}
		let i = [];
		return r.bufferView === void 0 ? i.push(null) : i.push(this.getDependency("bufferView", r.bufferView)), r.sparse !== void 0 && (i.push(this.getDependency("bufferView", r.sparse.indices.bufferView)), i.push(this.getDependency("bufferView", r.sparse.values.bufferView))), Promise.all(i).then(function(e) {
			let i = e[0], a = Sn[r.type], o = q[r.componentType], s = o.BYTES_PER_ELEMENT, c = s * a, l = r.byteOffset || 0, u = r.bufferView === void 0 ? void 0 : n.bufferViews[r.bufferView].byteStride, d = r.normalized === !0, f, p;
			if (u && u !== c) {
				let e = Math.floor(l / u), n = "InterleavedBuffer:" + r.bufferView + ":" + r.componentType + ":" + e + ":" + r.count, c = t.cache.get(n);
				c || (f = new o(i, e * u, r.count * u / s), c = new oe(f, u / s), t.cache.add(n, c)), p = new se(c, a, l % u / s, d);
			} else f = i === null ? new o(r.count * a) : new o(i, l, r.count * a), p = new x(f, a, d);
			if (r.sparse !== void 0) {
				let t = Sn.SCALAR, n = q[r.sparse.indices.componentType], s = r.sparse.indices.byteOffset || 0, c = r.sparse.values.byteOffset || 0, l = new n(e[1], s, r.sparse.count * t), u = new o(e[2], c, r.sparse.count * a);
				i !== null && (p = new x(p.array.slice(), p.itemSize, p.normalized)), p.normalized = !1;
				for (let e = 0, t = l.length; e < t; e++) {
					let t = l[e];
					if (p.setX(t, u[e * a]), a >= 2 && p.setY(t, u[e * a + 1]), a >= 3 && p.setZ(t, u[e * a + 2]), a >= 4 && p.setW(t, u[e * a + 3]), a >= 5) throw Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.");
				}
				p.normalized = d;
			}
			return p;
		});
	}
	loadTexture(e) {
		let t = this.json, n = this.options, r = t.textures[e].source, i = t.images[r], a = this.textureLoader;
		if (i.uri) {
			let e = n.manager.getHandler(i.uri);
			e !== null && (a = e);
		}
		return this.loadTextureImage(e, r, a);
	}
	loadTextureImage(e, t, n) {
		let r = this, i = this.json, a = i.textures[e], o = i.images[t], s = (o.uri || o.bufferView) + ":" + a.sampler;
		if (this.textureCache[s]) return this.textureCache[s];
		let c = this.loadImageSource(t, n).then(function(t) {
			t.flipY = !1, t.name = a.name || o.name || "", t.name === "" && typeof o.uri == "string" && o.uri.startsWith("data:image/") === !1 && (t.name = o.uri);
			let n = (i.samplers || {})[a.sampler] || {};
			return t.magFilter = bn[n.magFilter] || he, t.minFilter = bn[n.minFilter] || ge, t.wrapS = xn[n.wrapS] || Be, t.wrapT = xn[n.wrapT] || Be, t.generateMipmaps = !t.isCompressedTexture && t.minFilter !== Ee && t.minFilter !== he, r.associations.set(t, { textures: e }), t;
		}).catch(function() {
			return null;
		});
		return this.textureCache[s] = c, c;
	}
	loadImageSource(e, t) {
		let n = this, r = this.json, i = this.options;
		if (this.sourceCache[e] !== void 0) return this.sourceCache[e].then((e) => e.clone());
		let a = r.images[e], o = self.URL || self.webkitURL, s = a.uri || "", c = !1;
		if (a.bufferView !== void 0) s = n.getDependency("bufferView", a.bufferView).then(function(e) {
			c = !0;
			let t = new Blob([e], { type: a.mimeType });
			return s = o.createObjectURL(t), s;
		});
		else if (a.uri === void 0) throw Error("THREE.GLTFLoader: Image " + e + " is missing URI and bufferView");
		let l = Promise.resolve(s).then(function(e) {
			return new Promise(function(n, r) {
				let a = n;
				t.isImageBitmapLoader === !0 && (a = function(e) {
					let t = new Ke(e);
					t.needsUpdate = !0, n(t);
				}), t.load(ye.resolveURL(e, i.path), a, void 0, r);
			});
		}).then(function(e) {
			return c === !0 && o.revokeObjectURL(s), X(e, a), e.userData.mimeType = a.mimeType || Mn(a.uri), e;
		}).catch(function(e) {
			throw console.error("THREE.GLTFLoader: Couldn't load texture", s), e;
		});
		return this.sourceCache[e] = l, l;
	}
	assignTexture(e, t, n, r) {
		let i = this;
		return this.getDependency("texture", n.index).then(function(a) {
			if (!a) return null;
			if (n.texCoord !== void 0 && n.texCoord > 0 && (a = a.clone(), a.channel = n.texCoord), i.extensions[W.KHR_TEXTURE_TRANSFORM]) {
				let e = n.extensions === void 0 ? void 0 : n.extensions[W.KHR_TEXTURE_TRANSFORM];
				if (e) {
					let t = i.associations.get(a);
					a = i.extensions[W.KHR_TEXTURE_TRANSFORM].extendTexture(a, e), i.associations.set(a, t);
				}
			}
			return r !== void 0 && (a.colorSpace = r), e[t] = a, a;
		});
	}
	assignFinalMaterial(e) {
		let t = e.geometry, n = e.material, r = t.attributes.tangent === void 0, i = t.attributes.color !== void 0, a = t.attributes.normal === void 0;
		if (e.isPoints) {
			let e = "PointsMaterial:" + n.uuid, t = this.cache.get(e);
			t || (t = new Ie(), be.prototype.copy.call(t, n), t.color.copy(n.color), t.map = n.map, t.sizeAttenuation = !1, this.cache.add(e, t)), n = t;
		} else if (e.isLine) {
			let e = "LineBasicMaterial:" + n.uuid, t = this.cache.get(e);
			t || (t = new fe(), be.prototype.copy.call(t, n), t.color.copy(n.color), t.map = n.map, this.cache.add(e, t)), n = t;
		}
		if (r || i || a) {
			let e = "ClonedMaterial:" + n.uuid + ":";
			r && (e += "derivative-tangents:"), i && (e += "vertex-colors:"), a && (e += "flat-shading:");
			let t = this.cache.get(e);
			t || (t = n.clone(), i && (t.vertexColors = !0), a && (t.flatShading = !0), r && (t.normalScale && (t.normalScale.y *= -1), t.clearcoatNormalScale && (t.clearcoatNormalScale.y *= -1)), this.cache.add(e, t), this.associations.set(t, this.associations.get(n))), n = t;
		}
		e.material = n;
	}
	getMaterialType() {
		return we;
	}
	loadMaterial(e) {
		let t = this, n = this.json, r = this.extensions, i = n.materials[e], a, o = {}, s = i.extensions || {}, c = [];
		if (s[W.KHR_MATERIALS_UNLIT]) {
			let e = r[W.KHR_MATERIALS_UNLIT];
			a = e.getMaterialType(), c.push(e.extendParams(o, i, t));
		} else {
			let n = i.pbrMetallicRoughness || {};
			if (o.color = new T(1, 1, 1), o.opacity = 1, Array.isArray(n.baseColorFactor)) {
				let e = n.baseColorFactor;
				o.color.setRGB(e[0], e[1], e[2], j), o.opacity = e[3];
			}
			n.baseColorTexture !== void 0 && c.push(t.assignTexture(o, "map", n.baseColorTexture, Ve)), o.metalness = n.metallicFactor === void 0 ? 1 : n.metallicFactor, o.roughness = n.roughnessFactor === void 0 ? 1 : n.roughnessFactor, n.metallicRoughnessTexture !== void 0 && (c.push(t.assignTexture(o, "metalnessMap", n.metallicRoughnessTexture)), c.push(t.assignTexture(o, "roughnessMap", n.metallicRoughnessTexture))), a = this._invokeOne(function(t) {
				return t.getMaterialType && t.getMaterialType(e);
			}), c.push(Promise.all(this._invokeAll(function(t) {
				return t.extendMaterialParams && t.extendMaterialParams(e, o);
			})));
		}
		i.doubleSided === !0 && (o.side = O);
		let l = i.alphaMode || Tn.OPAQUE;
		if (l === Tn.BLEND ? (o.transparent = !0, o.depthWrite = !1) : (o.transparent = !1, l === Tn.MASK && (o.alphaTest = i.alphaCutoff === void 0 ? .5 : i.alphaCutoff)), i.normalTexture !== void 0 && a !== M && (c.push(t.assignTexture(o, "normalMap", i.normalTexture)), o.normalScale = new Ze(1, 1), i.normalTexture.scale !== void 0)) {
			let e = i.normalTexture.scale;
			o.normalScale.set(e, e);
		}
		if (i.occlusionTexture !== void 0 && a !== M && (c.push(t.assignTexture(o, "aoMap", i.occlusionTexture)), i.occlusionTexture.strength !== void 0 && (o.aoMapIntensity = i.occlusionTexture.strength)), i.emissiveFactor !== void 0 && a !== M) {
			let e = i.emissiveFactor;
			o.emissive = new T().setRGB(e[0], e[1], e[2], j);
		}
		return i.emissiveTexture !== void 0 && a !== M && c.push(t.assignTexture(o, "emissiveMap", i.emissiveTexture, Ve)), Promise.all(c).then(function() {
			let n = new a(o);
			return i.name && (n.name = i.name), X(n, i), t.associations.set(n, { materials: e }), i.extensions && Y(r, n, i), n;
		});
	}
	createUniqueName(e) {
		let t = Le.sanitizeNodeName(e || "");
		return t in this.nodeNamesUsed ? t + "_" + ++this.nodeNamesUsed[t] : (this.nodeNamesUsed[t] = 0, t);
	}
	loadGeometries(e) {
		let t = this, n = this.extensions, r = this.primitiveCache;
		function i(e) {
			return n[W.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(e, t).then(function(n) {
				return In(n, e, t);
			});
		}
		let a = [];
		for (let n = 0, o = e.length; n < o; n++) {
			let o = e[n], s = kn(o), c = r[s];
			if (c) a.push(c.promise);
			else {
				let e;
				e = o.extensions && o.extensions[W.KHR_DRACO_MESH_COMPRESSION] ? i(o) : In(new S(), o, t), o.mode === K.TRIANGLE_STRIP ? e = e.then((e) => Vt(e, Ye)) : o.mode === K.TRIANGLE_FAN && (e = e.then((e) => Vt(e, Je))), r[s] = {
					primitive: o,
					promise: e
				}, a.push(e);
			}
		}
		return Promise.all(a);
	}
	loadMesh(e) {
		let t = this, n = this.json, r = this.extensions, i = n.meshes[e], a = i.primitives, o = [];
		for (let e = 0, t = a.length; e < t; e++) {
			let t = a[e].material === void 0 ? En(this.cache) : this.getDependency("material", a[e].material);
			o.push(t);
		}
		return o.push(t.loadGeometries(a)), Promise.all(o).then(async function(n) {
			let o = n.slice(0, n.length - 1), s = n[n.length - 1], c = [];
			for (let n = 0, l = s.length; n < l; n++) {
				let l = s[n], u = a[n], d, f = o[n];
				if (u.mode === K.TRIANGLES || u.mode === K.TRIANGLE_STRIP || u.mode === K.TRIANGLE_FAN || u.mode === void 0) {
					let e = i.isSkinnedMesh === !0, t = l.hasAttribute("skinIndex") && l.hasAttribute("skinWeight");
					e && t === !1 && console.warn("THREE.GLTFLoader: Missing skinIndex or skinWeight attributes. Skinning disabled."), d = e && t ? new Ue(l, f) : new Ce(l, f), d.isSkinnedMesh === !0 && d.normalizeSkinWeights();
				} else if (u.mode === K.LINES) d = new me(l, f);
				else if (u.mode === K.LINE_STRIP) d = new de(l, f);
				else if (u.mode === K.LINE_LOOP) d = new pe(l, f);
				else if (u.mode === K.POINTS) d = new Fe(l, f);
				else throw Error("THREE.GLTFLoader: Primitive mode unsupported: " + u.mode);
				Object.keys(d.geometry.morphAttributes).length > 0 && On(d, i), d.name = t.createUniqueName(i.name || "mesh_" + e), X(d, i), u.extensions && Y(r, d, u), t.assignFinalMaterial(d), c.push(d);
			}
			for (let n = 0, r = c.length; n < r; n++) t.associations.set(c[n], {
				meshes: e,
				primitives: n
			});
			if (c.length === 1) return i.extensions && Y(r, c[0], i), c[0];
			let l = new A();
			i.extensions && Y(r, l, i), t.associations.set(l, { meshes: e });
			for (let e = 0, t = c.length; e < t; e++) l.add(c[e]);
			return l;
		});
	}
	loadCamera(e) {
		let t, n = this.json.cameras[e], r = n[n.type];
		if (!r) {
			console.warn("THREE.GLTFLoader: Missing camera parameters.");
			return;
		}
		return n.type === "perspective" ? t = new Me(xe.radToDeg(r.yfov), r.aspectRatio || 1, r.znear || 1, r.zfar || 2e6) : n.type === "orthographic" && (t = new je(-r.xmag, r.xmag, r.ymag, -r.ymag, r.znear, r.zfar)), n.name && (t.name = this.createUniqueName(n.name)), X(t, n), Promise.resolve(t);
	}
	loadSkin(e) {
		let t = this.json.skins[e], n = [];
		for (let e = 0, r = t.joints.length; e < r; e++) n.push(this._loadNodeShallow(t.joints[e]));
		return t.inverseBindMatrices === void 0 ? n.push(null) : n.push(this.getDependency("accessor", t.inverseBindMatrices)), Promise.all(n).then(function(e) {
			let n = e.pop(), r = e, i = [], a = [];
			for (let e = 0, o = r.length; e < o; e++) {
				let o = r[e];
				if (o) {
					i.push(o);
					let t = new Se();
					n !== null && t.fromArray(n.array, e * 16), a.push(t);
				} else console.warn("THREE.GLTFLoader: Joint \"%s\" could not be found.", t.joints[e]);
			}
			return new He(i, a);
		});
	}
	loadAnimation(e) {
		let t = this.json, n = this, r = t.animations[e], i = r.name ? r.name : "animation_" + e, a = [], o = [], s = [], c = [], l = [];
		for (let e = 0, t = r.channels.length; e < t; e++) {
			let t = r.channels[e], n = r.samplers[t.sampler], i = t.target, u = i.node, d = r.parameters === void 0 ? n.input : r.parameters[n.input], f = r.parameters === void 0 ? n.output : r.parameters[n.output];
			i.node !== void 0 && (a.push(this.getDependency("node", u)), o.push(this.getDependency("accessor", d)), s.push(this.getDependency("accessor", f)), c.push(n), l.push(i));
		}
		return Promise.all([
			Promise.all(a),
			Promise.all(o),
			Promise.all(s),
			Promise.all(c),
			Promise.all(l)
		]).then(function(e) {
			let t = e[0], a = e[1], o = e[2], s = e[3], c = e[4], l = [];
			for (let e = 0, r = t.length; e < r; e++) {
				let r = t[e], i = a[e], u = o[e], d = s[e], f = c[e];
				if (r === void 0) continue;
				r.updateMatrix && r.updateMatrix();
				let p = n._createAnimationTracks(r, i, u, d, f);
				if (p) for (let e = 0; e < p.length; e++) l.push(p[e]);
			}
			let u = new te(i, void 0, l);
			return X(u, r), u;
		});
	}
	createNodeMesh(e) {
		let t = this.json, n = this, r = t.nodes[e];
		return r.mesh === void 0 ? null : n.getDependency("mesh", r.mesh).then(function(e) {
			let t = n._getNodeRef(n.meshCache, r.mesh, e);
			return r.weights !== void 0 && t.traverse(function(e) {
				if (e.isMesh) for (let t = 0, n = r.weights.length; t < n; t++) e.morphTargetInfluences[t] = r.weights[t];
			}), t;
		});
	}
	loadNode(e) {
		let t = this.json, n = this, r = t.nodes[e], i = n._loadNodeShallow(e), a = [], o = r.children || [];
		for (let e = 0, t = o.length; e < t; e++) a.push(n.getDependency("node", o[e]));
		let s = r.skin === void 0 ? Promise.resolve(null) : n.getDependency("skin", r.skin);
		return Promise.all([
			i,
			Promise.all(a),
			s
		]).then(function(e) {
			let t = e[0], n = e[1], r = e[2];
			r !== null && t.traverse(function(e) {
				e.isSkinnedMesh && e.bind(r, Nn);
			});
			for (let e = 0, r = n.length; e < r; e++) t.add(n[e]);
			if (t.userData.pivot !== void 0 && n.length > 0) {
				let e = t.userData.pivot, r = n[0];
				t.pivot = new P().fromArray(e), t.position.x -= e[0], t.position.y -= e[1], t.position.z -= e[2], r.position.set(0, 0, 0), delete t.userData.pivot;
			}
			return t;
		});
	}
	_loadNodeShallow(e) {
		let t = this.json, n = this.extensions, r = this;
		if (this.nodeCache[e] !== void 0) return this.nodeCache[e];
		let i = t.nodes[e], a = i.name ? r.createUniqueName(i.name) : "", o = [], s = r._invokeOne(function(t) {
			return t.createNodeMesh && t.createNodeMesh(e);
		});
		return s && o.push(s), i.camera !== void 0 && o.push(r.getDependency("camera", i.camera).then(function(e) {
			return r._getNodeRef(r.cameraCache, i.camera, e);
		})), r._invokeAll(function(t) {
			return t.createNodeAttachment && t.createNodeAttachment(e);
		}).forEach(function(e) {
			o.push(e);
		}), this.nodeCache[e] = Promise.all(o).then(function(t) {
			let o;
			if (o = i.isBone === !0 ? new y() : t.length > 1 ? new A() : t.length === 1 ? t[0] : new Ae(), o !== t[0]) for (let e = 0, n = t.length; e < n; e++) o.add(t[e]);
			if (i.name && (o.userData.name = i.name, o.name = a), X(o, i), i.extensions && Y(n, o, i), i.matrix !== void 0) {
				let e = new Se();
				e.fromArray(i.matrix), o.applyMatrix4(e);
			} else i.translation !== void 0 && o.position.fromArray(i.translation), i.rotation !== void 0 && o.quaternion.fromArray(i.rotation), i.scale !== void 0 && o.scale.fromArray(i.scale);
			if (!r.associations.has(o)) r.associations.set(o, {});
			else if (i.mesh !== void 0 && r.meshCache.refs[i.mesh] > 1) {
				let e = r.associations.get(o);
				r.associations.set(o, { ...e });
			}
			return r.associations.get(o).nodes = e, o;
		}), this.nodeCache[e];
	}
	loadScene(e) {
		let t = this.extensions, n = this.json.scenes[e], r = this, i = new A();
		n.name && (i.name = r.createUniqueName(n.name)), X(i, n), n.extensions && Y(t, i, n);
		let a = n.nodes || [], o = [];
		for (let e = 0, t = a.length; e < t; e++) o.push(r.getDependency("node", a[e]));
		return Promise.all(o).then(function(e) {
			for (let t = 0, n = e.length; t < n; t++) {
				let n = e[t];
				n.parent === null ? i.add(n) : i.add(Ht(n));
			}
			return r.associations = ((e) => {
				let t = /* @__PURE__ */ new Map();
				for (let [e, n] of r.associations) (e instanceof be || e instanceof Ke) && t.set(e, n);
				return e.traverse((e) => {
					let n = r.associations.get(e);
					n != null && t.set(e, n);
				}), t;
			})(i), i;
		});
	}
	_createAnimationTracks(e, t, n, r, i) {
		let a = [], o = e.name ? e.name : e.uuid, s = [];
		function c(e) {
			e.morphTargetInfluences && s.push(e.name ? e.name : e.uuid);
		}
		J[i.path] === J.weights ? (c(e), e.isGroup && e.children.forEach(c)) : s.push(o);
		let l;
		switch (J[i.path]) {
			case J.weights:
				l = ke;
				break;
			case J.rotation:
				l = ze;
				break;
			case J.translation:
			case J.scale:
				l = Qe;
				break;
			default: switch (n.itemSize) {
				case 1:
					l = ke;
					break;
				default: l = Qe;
			}
		}
		let u = r.interpolation === void 0 ? ue : wn[r.interpolation], d = this._getArrayFromAccessor(n);
		for (let e = 0, n = s.length; e < n; e++) {
			let n = new l(s[e] + "." + J[i.path], t.array, d, u);
			r.interpolation === "CUBICSPLINE" && this._createCubicSplineTrackInterpolant(n), a.push(n);
		}
		return a;
	}
	_getArrayFromAccessor(e) {
		let t = e.array;
		if (e.normalized) {
			let e = jn(t.constructor), n = new Float32Array(t.length);
			for (let r = 0, i = t.length; r < i; r++) n[r] = t[r] * e;
			t = n;
		}
		return t;
	}
	_createCubicSplineTrackInterpolant(e) {
		e.createInterpolant = function(e) {
			return new (this instanceof ze ? yn : _n)(this.times, this.values, this.getValueSize() / 3, e);
		}, e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline = !0;
	}
};
function Fn(e, t, n) {
	let r = t.attributes, i = new b();
	if (r.POSITION !== void 0) {
		let e = n.json.accessors[r.POSITION], t = e.min, a = e.max;
		if (t !== void 0 && a !== void 0) {
			if (i.set(new P(t[0], t[1], t[2]), new P(a[0], a[1], a[2])), e.normalized) {
				let t = jn(q[e.componentType]);
				i.min.multiplyScalar(t), i.max.multiplyScalar(t);
			}
		} else {
			console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");
			return;
		}
	} else return;
	let a = t.targets;
	if (a !== void 0) {
		let e = new P(), t = new P();
		for (let r = 0, i = a.length; r < i; r++) {
			let i = a[r];
			if (i.POSITION !== void 0) {
				let r = n.json.accessors[i.POSITION], a = r.min, o = r.max;
				if (a !== void 0 && o !== void 0) {
					if (t.setX(Math.max(Math.abs(a[0]), Math.abs(o[0]))), t.setY(Math.max(Math.abs(a[1]), Math.abs(o[1]))), t.setZ(Math.max(Math.abs(a[2]), Math.abs(o[2]))), r.normalized) {
						let e = jn(q[r.componentType]);
						t.multiplyScalar(e);
					}
					e.max(t);
				} else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");
			}
		}
		i.expandByVector(e);
	}
	e.boundingBox = i;
	let o = new We();
	i.getCenter(o.center), o.radius = i.min.distanceTo(i.max) / 2, e.boundingSphere = o;
}
function In(e, t, n) {
	let r = t.attributes, i = [];
	function a(t, r) {
		return n.getDependency("accessor", t).then(function(t) {
			e.setAttribute(r, t);
		});
	}
	for (let t in r) {
		let n = Cn[t] || t.toLowerCase();
		n in e.attributes || i.push(a(r[t], n));
	}
	if (t.indices !== void 0 && !e.index) {
		let r = n.getDependency("accessor", t.indices).then(function(t) {
			e.setIndex(t);
		});
		i.push(r);
	}
	return E.workingColorSpace !== j && "COLOR_0" in r && console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${E.workingColorSpace}" not supported.`), X(e, t), Fn(e, t, n), Promise.all(i).then(function() {
		return t.targets === void 0 ? e : Dn(e, t.targets, n);
	});
}
//#endregion
//#region src/games/readysetbet/broadcast-scene.tsx
var Ln = "./games/readysetbet/live/horse.glb", Rn = 33.65, zn = .7, Bn = 1300, Vn = [
	[
		174,
		180,
		178
	],
	[
		91,
		74,
		65
	],
	[
		207,
		160,
		88
	],
	[
		167,
		82,
		60
	],
	[
		52,
		55,
		56
	],
	[
		133,
		63,
		48
	],
	[
		179,
		139,
		81
	],
	[
		111,
		119,
		121
	],
	[
		146,
		151,
		150
	]
], Hn = {
	blue: "#2563eb",
	orange: "#ea580c",
	red: "#dc2626",
	black: "#242424"
}, Un = new Ne(.55, .42);
function Z(e, t, n) {
	return Math.max(t, Math.min(n, e));
}
function Wn(e, t) {
	if (!e?.image) return null;
	let n = document.createElement("canvas");
	n.width = 512, n.height = 512;
	let r = n.getContext("2d", { willReadFrequently: !0 });
	if (!r) return null;
	r.drawImage(e.image, 0, 0, n.width, n.height);
	let i = r.getImageData(0, 0, n.width, n.height), a = i.data;
	for (let e = 0; e < a.length; e += 4) {
		let n = a[e], r = a[e + 1], i = a[e + 2], o = Z((n - i - 8) / 37, 0, 1) * Z(((Math.max(n, r, i) - Math.min(n, r, i)) / Math.max(1, n, r, i) - .07) * 6, 0, 1) * .92, s = Z((.3 * n + .59 * r + .11 * i) / 112, .38, 1.45);
		a[e] = n * (1 - o) + t[0] * s * o, a[e + 1] = r * (1 - o) + t[1] * s * o, a[e + 2] = i * (1 - o) + t[2] * s * o;
	}
	r.putImageData(i, 0, 0);
	let o = new C(n);
	return o.flipY = e.flipY, o.colorSpace = e.colorSpace, o.wrapS = e.wrapS, o.wrapT = e.wrapT, o.anisotropy = 4, o;
}
function Gn(e) {
	let t = document.createElement("canvas");
	t.width = 128, t.height = 96;
	let n = t.getContext("2d");
	return n.fillStyle = Hn[R[e]], n.fillRect(4, 4, 120, 88), n.strokeStyle = "#fff7df", n.lineWidth = 7, n.strokeRect(4, 4, 120, 88), n.fillStyle = "#fff7df", n.font = `900 ${L[e].length > 2 ? 39 : 56}px sans-serif`, n.textAlign = "center", n.textBaseline = "middle", n.fillText(L[e], 64, 51), new C(t);
}
function Kn(e) {
	let t = e.scene.getObjectByProperty("isSkinnedMesh", !0)?.material?.map ?? null, n = [];
	return {
		actors: L.map((r, i) => {
			let a = new A(), o = Ht(e.scene);
			a.add(o);
			let s = Wn(t, Vn[i]);
			s && n.push(s);
			let c = [];
			o.traverse((e) => {
				if (!(e instanceof Ce)) return;
				let t = e.material.clone();
				s && (t.map = s), t.needsUpdate = !0, e.material = t, c.push(t);
			});
			let l = Gn(i);
			n.push(l);
			let u = [];
			for (let e of [-1, 1]) {
				let t = new M({
					map: l,
					transparent: !0,
					side: O,
					depthWrite: !1
				}), n = new Ce(Un, t);
				n.position.set(e * .34, .1, -.05), n.rotation.y = e * Math.PI / 2, a.add(n), u.push(t);
			}
			let d = new v(o);
			return d.clipAction(e.animations[0]).play(), d.setTime(34), {
				root: a,
				mixer: d,
				neck: o.getObjectByName("Bip01 Neck_01_19") ?? null,
				materials: c,
				bibMaterials: u
			};
		}),
		textures: n
	};
}
function qn({ shot: e, positions: t }) {
	let { camera: n, invalidate: r } = _();
	return i(() => {
		let i = t.map((e) => -3.15 + e / 15 * 6.3), a = Math.min(...i), o = Math.max(...i), s = (a + o) / 2, c = o - a, l = {
			overview: {
				position: [
					3.85 + c * .14,
					4.1 + c * .31,
					s + 2.9 + c * .27
				],
				target: [
					.55,
					.12,
					s
				],
				fov: 43
			},
			side: {
				position: [
					4.1,
					.8,
					.9
				],
				target: [
					0,
					0,
					0
				],
				fov: 33
			},
			front: {
				position: [
					.5,
					.7,
					3.8
				],
				target: [
					0,
					0,
					0
				],
				fov: 37
			},
			rear: {
				position: [
					.7,
					.9,
					-3.8
				],
				target: [
					0,
					0,
					0
				],
				fov: 37
			},
			close: {
				position: [
					2.4,
					.65,
					3.2
				],
				target: [
					0,
					0,
					0
				],
				fov: 32
			},
			sprint: {
				position: [
					3.25,
					.45,
					2.25
				],
				target: [
					0,
					-.08,
					0
				],
				fov: 37
			},
			finish: {
				position: [
					2.5,
					.72,
					3.2
				],
				target: [
					0,
					0,
					0
				],
				fov: 32
			}
		}[e];
		n.position.set(l.position[0], l.position[1], l.position[2]), n.lookAt(l.target[0], l.target[1], l.target[2]), n instanceof Me && n.setFocalLength(n.getFilmHeight() / (2 * Math.tan(l.fov * Math.PI / 360))), n.updateProjectionMatrix(), r();
	}, [
		n,
		r,
		t,
		e
	]), null;
}
function Jn({ active: e, startedAt: t }) {
	let n = o(null);
	return g(() => {
		if (!n.current || !e || t === null) return;
		let r = Z((performance.now() - t) / Bn, 0, 1);
		n.current.scale.setScalar(.65 + r * 1.15), n.current.position.z = -.15 - r * .45;
	}), /* @__PURE__ */ F("group", {
		ref: n,
		visible: e,
		position: [
			0,
			-1.01,
			-.15
		],
		children: [
			-.36,
			.02,
			.32
		].map((e, t) => /* @__PURE__ */ I("mesh", {
			position: [
				e,
				0,
				t * .12
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ F("circleGeometry", { args: [.18 + t * .05, 12] }), /* @__PURE__ */ F("meshBasicMaterial", {
				color: "#d9bb80",
				transparent: !0,
				opacity: .22,
				depthWrite: !1
			})]
		}, t))
	});
}
function Yn({ shot: e, focusHorse: t, positions: n, sprintAt: r, running: a, onLoaded: c, onFailed: l }) {
	let [u, d] = s([]), f = o([]), p = o(0), { invalidate: m } = _();
	i(() => {
		let e = !0, t = [], n = [];
		return new Wt().load(Ln, (r) => {
			if (e) try {
				let e = new b().setFromObject(r.scene);
				r.scene.position.sub(e.getCenter(new P()));
				let i = Kn(r);
				n = i.actors, t = i.textures, f.current = n, d(n), c(), m();
			} catch {
				l();
			}
		}, void 0, () => {
			e && l();
		}), () => {
			e = !1, f.current = [], n.forEach(({ mixer: e, materials: t, bibMaterials: n }) => {
				e.stopAllAction(), t.forEach((e) => e.dispose()), n.forEach((e) => e.dispose());
			}), t.forEach((e) => e.dispose());
		};
	}, [
		m,
		l,
		c
	]), i(() => {
		let r = e === "overview";
		f.current.forEach(({ root: e }, i) => {
			e.visible = r || i === t, e.scale.setScalar(r ? .55 : 1), e.rotation.x = 0, e.position.set(r ? (i - 4) * .54 : 0, 0, r ? -3.15 + n[i] / 15 * 6.3 : 0);
		}), m();
	}, [
		u,
		t,
		m,
		n,
		e
	]), g((n, i) => {
		if (!a) return;
		let o = e === "sprint" && r !== null, s = o ? Z((performance.now() - r) / Bn, 0, 1) : 0, c = o ? Math.sin(Math.PI * s) : 0;
		p.current += Math.min(i, .1) * (o ? 1.7 : 1), f.current.forEach(({ root: e, mixer: n, neck: r }, i) => {
			e.visible && (n.setTime(Rn + (p.current + i * .07) % zn), o && i === t && (e.rotation.x = .17 * c, e.position.y = -.08 * c, r && (r.rotation.x += .14 * c)));
		});
	});
	let h = e === "overview";
	return /* @__PURE__ */ I($e, { children: [
		/* @__PURE__ */ F(qn, {
			shot: e,
			positions: n
		}),
		/* @__PURE__ */ F("color", {
			attach: "background",
			args: ["#263d34"]
		}),
		/* @__PURE__ */ F("hemisphereLight", { args: [
			"#fff5db",
			"#344436",
			2.5
		] }),
		/* @__PURE__ */ F("directionalLight", {
			color: "#ffe5bd",
			intensity: 2.5,
			position: [
				-3,
				5,
				4
			]
		}),
		/* @__PURE__ */ I("mesh", {
			position: [
				0,
				h ? -.58 : -1.04,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ F("planeGeometry", { args: h ? [8.8, 8.6] : [30, 30] }), /* @__PURE__ */ F("meshStandardMaterial", {
				color: "#685541",
				roughness: 1
			})]
		}),
		h && Array.from({ length: 10 }, (e, t) => /* @__PURE__ */ I("mesh", {
			position: [
				(t - 4.5) * .54,
				-.567,
				0
			],
			children: [/* @__PURE__ */ F("boxGeometry", { args: [
				.018,
				.012,
				7.5
			] }), /* @__PURE__ */ F("meshBasicMaterial", { color: "#bda779" })]
		}, t)),
		u.map(({ root: e }, t) => /* @__PURE__ */ F("primitive", { object: e }, t)),
		/* @__PURE__ */ F(Jn, {
			active: e === "sprint" && a,
			startedAt: r
		})
	] });
}
//#endregion
//#region src/games/readysetbet/broadcast3d.tsx
var Xn = [
	"overview",
	"side",
	"front",
	"rear",
	"close"
], Zn = 2800, Qn = 1300;
function $n() {
	try {
		let e = document.createElement("canvas");
		return !!(e.getContext("webgl2") ?? e.getContext("webgl"));
	} catch {
		return !1;
	}
}
function er({ race: e, positions: t, lastRoll: n, racing: c, reducedMotion: u }) {
	let d = l(), [f] = s($n), [p, m] = s(!1), [h, g] = s(!1), [_, te] = s(() => document.hidden), [v, y] = s(0), [b, x] = s(null), S = o(null), C = o(null), w = r(() => m(!0), []), T = r(() => g(!0), []);
	i(() => {
		let e = () => te(document.hidden);
		return document.addEventListener("visibilitychange", e), () => document.removeEventListener("visibilitychange", e);
	}, []), i(() => {
		if (!c || u || _ || !f || h) return;
		let e = window.setInterval(() => y((e) => e + 1), Zn);
		return () => window.clearInterval(e);
	}, [
		h,
		_,
		c,
		u,
		f
	]);
	let E = n ? `${e}:${n.d1}:${n.d2}:${t[n.horse]}:${n.bonus}` : null;
	i(() => {
		if (!E || !n || !c || u || _ || S.current === E || !(n.bonus && at[n.horse] > 0) && t[n.horse] < 12) return;
		let e = requestAnimationFrame(() => {
			S.current = E, C.current !== null && window.clearTimeout(C.current), x(performance.now()), C.current = window.setTimeout(() => {
				x(null), C.current = null;
			}, Qn);
		});
		return () => cancelAnimationFrame(e);
	}, [
		_,
		n,
		t,
		c,
		u,
		E
	]), i(() => () => {
		C.current !== null && window.clearTimeout(C.current);
	}, []);
	let D = c ? u ? "overview" : b === null ? Xn[v % Xn.length] : "sprint" : "finish", O = a(() => {
		let e = t.indexOf(Math.max(...t)), r = Math.min(...t), i = t.findIndex((e) => e === r);
		return D === "front" ? e : D === "rear" ? i : D === "close" ? Math.floor(v / Xn.length) % t.length : n?.horse ?? e;
	}, [
		n,
		t,
		D,
		v
	]), k = d(D === "overview" ? "games.readysetbet.shotOverview" : D === "side" ? "games.readysetbet.shotSide" : D === "front" ? "games.readysetbet.shotFront" : D === "rear" ? "games.readysetbet.shotRear" : D === "close" ? "games.readysetbet.shotClose" : D === "sprint" ? "games.readysetbet.shotSprint" : "games.readysetbet.shotFinish"), ne = c && !u && !_ && f && !h;
	return /* @__PURE__ */ I("div", {
		className: "rsb-broadcast",
		"data-shot": D,
		role: "img",
		"aria-label": D === "overview" ? d("games.readysetbet.broadcastOverviewAria") : d("games.readysetbet.broadcastAria", {
			horse: L[O],
			shot: k
		}),
		title: "3D horse: abhayexe · CC BY 4.0",
		children: [
			/* @__PURE__ */ I("div", {
				className: `rsb-broadcast-stage ${D === "sprint" ? "rsb-sprint-shot" : ""}`,
				children: [
					f && !h ? /* @__PURE__ */ F(ee, {
						camera: {
							fov: 47,
							near: .1,
							far: 100,
							position: [
								5.7,
								7,
								5.3
							]
						},
						dpr: [1, 1.5],
						shadows: !1,
						frameloop: ne ? "always" : "demand",
						recoveryFallback: /* @__PURE__ */ F("span", {
							className: "rsb-broadcast-fallback",
							children: d("games.readysetbet.broadcastUnavailable")
						}),
						children: /* @__PURE__ */ F(Yn, {
							shot: D,
							focusHorse: O,
							positions: t,
							sprintAt: b,
							running: ne,
							onLoaded: w,
							onFailed: T
						})
					}) : /* @__PURE__ */ F("span", {
						className: "rsb-broadcast-fallback",
						children: d("games.readysetbet.broadcastUnavailable")
					}),
					f && !h && !p && /* @__PURE__ */ F("span", {
						className: "rsb-broadcast-loading",
						children: d("games.readysetbet.broadcastLoading")
					}),
					/* @__PURE__ */ F("span", {
						className: `rsb-live-tag ${c ? "" : "rsb-post-tag"}`,
						children: c ? "● LIVE" : d("games.readysetbet.broadcastPaused")
					}),
					/* @__PURE__ */ F("span", {
						className: "rsb-camera-cut",
						"aria-hidden": "true"
					}, `${D}-${O}`)
				]
			}),
			/* @__PURE__ */ I("div", {
				className: "rsb-broadcast-caption",
				children: [/* @__PURE__ */ F("strong", {
					className: D === "overview" ? "rsb-caption-all" : `rsb-caption-${R[O]}`,
					children: D === "overview" ? d("games.readysetbet.allHorses") : d("games.readysetbet.horseLabel", { horse: L[O] })
				}), /* @__PURE__ */ F("span", { children: k })]
			}),
			/* @__PURE__ */ F("span", {
				className: "rsb-broadcast-credit",
				children: "3D: abhayexe · CC BY 4.0"
			})
		]
	});
}
//#endregion
//#region src/games/readysetbet/dice3d.tsx
var tr = {
	1: [5],
	2: [1, 9],
	3: [
		1,
		5,
		9
	],
	4: [
		1,
		3,
		7,
		9
	],
	5: [
		1,
		3,
		5,
		7,
		9
	],
	6: [
		1,
		3,
		4,
		6,
		7,
		9
	]
}, nr = {
	1: ["0deg", "0deg"],
	2: ["0deg", "-90deg"],
	3: ["-90deg", "0deg"],
	4: ["90deg", "0deg"],
	5: ["0deg", "90deg"],
	6: ["0deg", "180deg"]
};
function rr({ value: e, rollKey: t, reducedMotion: n, pendingLabel: r }) {
	let [i, a] = nr[e ?? 1];
	return /* @__PURE__ */ I("span", {
		className: "rsb-die-shell",
		role: "img",
		"aria-label": e == null ? r : String(e),
		children: [/* @__PURE__ */ F("span", {
			className: `rsb-die ${e == null ? "rsb-die-pending-state" : n ? "" : "rsb-die-rolling"}`,
			style: {
				"--rsb-die-x": i,
				"--rsb-die-y": a
			},
			"aria-hidden": "true",
			children: [
				1,
				2,
				3,
				4,
				5,
				6
			].map((e) => /* @__PURE__ */ F("span", {
				className: `rsb-die-face rsb-die-face-${e}`,
				children: tr[e].map((e) => /* @__PURE__ */ F("i", { className: `rsb-pip rsb-pip-${e}` }, e))
			}, e))
		}, t), e == null && /* @__PURE__ */ F("span", {
			className: "rsb-die-pending",
			"aria-hidden": "true",
			children: "?"
		})]
	});
}
//#endregion
//#region src/games/readysetbet/race-screen.tsx
var Q = {
	blue: "#2563eb",
	orange: "#ea580c",
	red: "#dc2626",
	black: "#262626"
};
function ir({ pub: e }) {
	let t = l(), n = h(), r = e.lastRoll, i = r ? `${e.race}-${r.d1}-${r.d2}-${e.positions[r.horse]}` : `${e.race}-pending`, a = e.positions.filter((e) => e >= 9).length;
	return /* @__PURE__ */ I("section", {
		className: "rsb-race",
		"aria-label": t("games.readysetbet.raceScreen"),
		children: [/* @__PURE__ */ I("div", {
			className: "rsb-race-top",
			children: [/* @__PURE__ */ I("div", {
				className: "rsb-roll-board",
				children: [
					/* @__PURE__ */ I("div", {
						className: "rsb-object-title",
						children: [/* @__PURE__ */ F("span", { children: t("games.readysetbet.rollResult") }), /* @__PURE__ */ F("span", {
							className: "rsb-object-subtitle",
							children: "DICE RESULT"
						})]
					}),
					/* @__PURE__ */ I("div", {
						className: "rsb-roll-main",
						children: [/* @__PURE__ */ I("div", {
							className: "rsb-dice-pair",
							children: [/* @__PURE__ */ F(rr, {
								value: r?.d1 ?? null,
								rollKey: `${i}-1`,
								reducedMotion: n,
								pendingLabel: t("games.readysetbet.dicePending")
							}), /* @__PURE__ */ F(rr, {
								value: r?.d2 ?? null,
								rollKey: `${i}-2`,
								reducedMotion: n,
								pendingLabel: t("games.readysetbet.dicePending")
							})]
						}), /* @__PURE__ */ I("div", {
							className: "rsb-roll-sum",
							children: [/* @__PURE__ */ F("span", { children: t("games.readysetbet.total") }), /* @__PURE__ */ F("strong", { children: r?.sum ?? "—" })]
						})]
					}),
					/* @__PURE__ */ I("div", {
						className: "rsb-roll-foot",
						children: [/* @__PURE__ */ F("span", {
							className: "rsb-roll-horse",
							style: { "--rsb-horse": r ? Q[R[r.horse]] : "#8fa89a" },
							children: r ? t("games.readysetbet.horseLabel", { horse: L[r.horse] }) : t("games.readysetbet.waitingRoll")
						}), r?.bonus && at[r.horse] > 0 && /* @__PURE__ */ I("span", {
							className: "rsb-roll-bonus",
							children: ["⚡", t("games.readysetbet.bonusDash", { n: at[r.horse] })]
						})]
					})
				]
			}), /* @__PURE__ */ F(er, {
				race: e.race,
				positions: e.positions,
				lastRoll: r,
				racing: e.phase === "racing",
				reducedMotion: n
			})]
		}), /* @__PURE__ */ I("div", {
			className: "rsb-track-board",
			children: [
				/* @__PURE__ */ I("div", {
					className: "rsb-track-head",
					children: [/* @__PURE__ */ I("div", {
						className: "rsb-object-title",
						children: [/* @__PURE__ */ F("span", { children: t("games.readysetbet.raceScreen") }), /* @__PURE__ */ F("span", {
							className: "rsb-object-subtitle",
							children: "LIVE TRACK"
						})]
					}), /* @__PURE__ */ F("span", {
						className: "rsb-crossed",
						children: e.noMoreBets ? t("games.readysetbet.betsClosed") : t("games.readysetbet.crossedCount", { n: a })
					})]
				}),
				/* @__PURE__ */ I("div", {
					className: "rsb-track-scale",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ F("span", {}),
						/* @__PURE__ */ F("div", {
							className: "rsb-scale-values",
							children: [
								0,
								3,
								6,
								9,
								12,
								15
							].map((e) => /* @__PURE__ */ F("span", { children: e }, e))
						}),
						/* @__PURE__ */ F("span", {})
					]
				}),
				/* @__PURE__ */ F("div", {
					className: "rsb-track-lanes",
					children: L.map((n, r) => {
						let i = Q[R[r]], a = Math.min(15, e.positions[r]);
						return /* @__PURE__ */ I("div", {
							className: "rsb-track-lane",
							"aria-label": t("games.readysetbet.horseProgress", {
								horse: n,
								n: a
							}),
							children: [
								/* @__PURE__ */ F("span", {
									className: "rsb-lane-number",
									style: { "--rsb-horse": i },
									children: n
								}),
								/* @__PURE__ */ I("div", {
									className: "rsb-lane-line",
									style: {
										"--rsb-horse": i,
										"--rsb-progress": `${a / 15 * 100}%`
									},
									children: [
										/* @__PURE__ */ F("span", {
											className: "rsb-red-line",
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ F("span", {
											className: "rsb-lane-fill",
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ F("span", {
											className: "rsb-lane-marker",
											"aria-hidden": "true"
										})
									]
								}),
								/* @__PURE__ */ F("span", {
									className: "rsb-finish-flag",
									"aria-hidden": "true",
									children: "▦"
								})
							]
						}, r);
					})
				})
			]
		})]
	});
}
//#endregion
//#region src/games/readysetbet/text.ts
var ar = {
	show: "games.readysetbet.colShow",
	place: "games.readysetbet.colPlace",
	win: "games.readysetbet.colWin"
}, or = {
	blue: "games.readysetbet.colorBlue",
	orange: "games.readysetbet.colorOrange",
	red: "games.readysetbet.colorRed",
	seven5th: "games.readysetbet.colorSeven5th"
};
function sr(e, t) {
	switch (e.key) {
		case "bonus": return {
			name: t("games.readysetbet.vipBonus", { n: e.value }),
			desc: e.negateLoss || e.extraLoss === 0 ? t("games.readysetbet.vipBonusNegate") : t("games.readysetbet.vipBonusExtra", { n: e.extraLoss })
		};
		case "snakeEyes": return {
			name: t("games.readysetbet.vipSnakeEyes"),
			desc: t("games.readysetbet.vipSnakeEyesDesc")
		};
		case "lastSecond": return {
			name: t("games.readysetbet.vipLastSecond"),
			desc: t("games.readysetbet.vipLastSecondDesc")
		};
		case "favored": return {
			name: t("games.readysetbet.vipFavored", { horse: L[e.horse] }),
			desc: t("games.readysetbet.vipFavoredDesc")
		};
		case "highRoller": return {
			name: t("games.readysetbet.vipHighRoller"),
			desc: t("games.readysetbet.vipHighRollerDesc")
		};
		case "sideBet": return {
			name: t("games.readysetbet.vipSideBet", { horses: e.horses.map((e) => L[e]).join("&") }),
			desc: t("games.readysetbet.vipSideBetDesc")
		};
		case "compChips": return {
			name: t("games.readysetbet.vipCompChips"),
			desc: t("games.readysetbet.vipCompChipsDesc")
		};
		case "piggyback": return {
			name: t("games.readysetbet.vipPiggyback", { n: e.token }),
			desc: t("games.readysetbet.vipPiggybackDesc", { n: e.token })
		};
		case "risky": return {
			name: t("games.readysetbet.vipRisky"),
			desc: t("games.readysetbet.vipRiskyDesc")
		};
	}
}
function cr(e, t) {
	return e.kind === "wps" ? t("games.readysetbet.spotWps", {
		horse: L[e.horse],
		col: t(ar[e.col])
	}) : e.kind === "color" ? t(or[e.key]) : e.kind === "prop" ? t("games.readysetbet.spotProp", { n: e.card + 1 }) : t("games.readysetbet.spotExotic", { n: e.card + 1 });
}
//#endregion
//#region src/games/readysetbet/view-player.tsx
var lr = {
	blue: Q.blue,
	orange: Q.orange,
	red: Q.red,
	seven5th: Q.black
}, ur = [
	"show",
	"place",
	"win"
], dr = {
	tightRace: "games.readysetbet.exoticTightRace",
	lateStart: "games.readysetbet.exoticLateStart",
	photoFinish: "games.readysetbet.exoticPhotoFinish",
	byANose: "games.readysetbet.exoticByANose",
	blowOut: "games.readysetbet.exoticBlowOut"
}, fr = {
	tightRace: "games.readysetbet.exoticTightRaceDesc",
	lateStart: "games.readysetbet.exoticLateStartDesc",
	photoFinish: "games.readysetbet.exoticPhotoFinishDesc",
	byANose: "games.readysetbet.exoticByANoseDesc",
	blowOut: "games.readysetbet.exoticBlowOutDesc"
};
function pr(e) {
	return e.kind === "wps" ? `wps:${e.horse}:${e.col}:${e.cell}` : e.kind === "color" ? `color:${e.key}` : `${e.kind}:${e.card}`;
}
function mr(e) {
	return /* @__PURE__ */ F(hr, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function hr({ pub: e, priv: t, members: r, myRid: i, send: a }) {
	let o = l(), [f, h] = s(null), { ref: ee } = c("track"), g = (e) => {
		let t = r.find((t) => t.rid === e);
		return u[(t?.colorIndex ?? 0) % u.length].hex;
	}, _ = t?.tokens ?? [], te = t?.vip ?? [], v = t?.draftOptions ?? null, y = te.some((e) => e.key === "lastSecond"), b = e.phase === "racing" && (!e.noMoreBets || y), x = `${e.phase}:${e.race}:${_.map((e) => e.id).join(",")}`, [S, C] = s(x);
	S !== x && (C(x), f && !_.some((e) => e.id === f) && h(null));
	let w = (e) => {
		b && f && a({
			type: "bet",
			spot: e,
			tokenId: f
		});
	}, T = (t) => e.bets.filter((e) => pr(e.spot) === pr(t)), E = t?.piggybackTokens ?? [], D = _.find((e) => e.id === f), O = b && D != null, k = (e) => {
		let t = T(e);
		return e.kind === "exotic" ? t.length < 3 && !t.some((e) => e.rid === i) : t.length === 0 || t.length === 1 && t[0].rid !== i && !!D && E.includes(D.value);
	}, ne = e.phase === "racing" ? "accent" : "info", A = "";
	e.phase === "racing" ? A = e.noMoreBets ? o(y ? "games.readysetbet.lastSecondHint" : "games.readysetbet.noMoreBets") : o("games.readysetbet.racingBanner") : e.phase === "settle" ? A = o("games.readysetbet.settleBanner") : e.phase === "draft" && (ne = v ? "accent" : "info", A = o(v ? "games.readysetbet.draftBanner" : "games.readysetbet.draftWaiting"));
	let re = /* @__PURE__ */ I("div", {
		className: "rsb-banner",
		style: {
			"--rsb-seat-count": r.length,
			"--rsb-seat-columns": Math.min(r.length, 4)
		},
		children: [/* @__PURE__ */ F(p, {
			tone: ne,
			text: A,
			chip: o("games.readysetbet.raceOf", {
				n: e.race,
				total: 4
			}),
			accent: e.phase === "racing" ? "#0b4936" : ht.accent
		}), /* @__PURE__ */ F("div", {
			className: "rsb-players",
			children: /* @__PURE__ */ F(m, {
				variant: "plate",
				members: r,
				myRid: i,
				anchorOf: (e) => `seat:${e}`,
				action: (t) => e.phase === "draft" ? e.draftWaiting.includes(t) ? "pending" : "done" : null,
				status: (t) => {
					let n = e.players.find((e) => e.rid === t);
					if (!n) return null;
					let r = e.result?.deltas[t];
					return /* @__PURE__ */ I("span", {
						className: "rsb-player-money flex items-center gap-1 text-xs leading-4.5 font-bold",
						children: [
							/* @__PURE__ */ I("span", {
								className: "font-mono tabular-nums",
								children: ["$", n.money]
							}),
							r != null && r !== 0 && /* @__PURE__ */ F("span", {
								className: `font-mono tabular-nums ${r > 0 ? "text-done-ink" : "text-danger-ink"}`,
								children: r > 0 ? `+${r}` : r
							}),
							n.vipCount > 0 && /* @__PURE__ */ I("span", {
								className: "opacity-70",
								children: ["🎖️", n.vipCount]
							})
						]
					});
				}
			})
		})]
	}), ie = /* @__PURE__ */ I("div", {
		className: "rsb-token-board flex h-full flex-col gap-1.5",
		children: [/* @__PURE__ */ I("div", {
			className: "rsb-token-row flex h-12 items-center gap-2 overflow-x-auto px-1.5",
			children: [
				/* @__PURE__ */ F("span", {
					className: "rsb-token-label text-[10px] font-bold whitespace-nowrap opacity-70",
					children: o("games.readysetbet.myTokens")
				}),
				_.map((e) => /* @__PURE__ */ F(vr, {
					token: e,
					color: g(i),
					selected: f === e.id,
					disabled: !b,
					ariaLabel: o("games.readysetbet.tokenAria", { n: e.value }),
					onClick: () => h(f === e.id ? null : e.id)
				}, e.id)),
				_.length === 0 && /* @__PURE__ */ F("span", {
					className: "text-xs opacity-50",
					children: "—"
				})
			]
		}), /* @__PURE__ */ I("div", {
			className: "rsb-vip-row flex h-9 items-center gap-1.5 overflow-x-auto",
			children: [te.map((e, n) => /* @__PURE__ */ I("span", {
				className: "rsb-vip flex-none rounded-md border border-ink/40 bg-surface px-1.5 text-[10px] leading-6 font-bold whitespace-nowrap",
				title: sr(e, o).desc,
				children: [
					"🎖️",
					sr(e, o).name,
					e.key === "favored" && (t?.favoredAcc ?? 0) > 0 ? ` $${t?.favoredAcc}` : ""
				]
			}, n)), te.length === 0 && /* @__PURE__ */ F("span", {
				className: "text-[10px] opacity-40",
				children: "🎖️—"
			})]
		})]
	}), ae = /* @__PURE__ */ I($e, { children: [e.phase === "settle" && e.result && /* @__PURE__ */ I("div", {
		className: "rsb-settle mx-2 mb-2 rounded-xl border-2 border-ink bg-surface p-2",
		children: [/* @__PURE__ */ I("p", {
			className: "mb-1 text-xs font-extrabold",
			children: [
				o("games.readysetbet.settleTitle", { n: e.race }),
				" · ",
				o("games.readysetbet.winnerIs", { horse: L[e.result.order[0]] })
			]
		}), /* @__PURE__ */ F("div", {
			className: "flex flex-wrap gap-1",
			children: e.result.order.slice(0, 3).map((e, t) => /* @__PURE__ */ I("span", {
				className: "rounded-md px-1.5 text-[10px] leading-5 font-extrabold",
				style: {
					background: Q[R[e]],
					color: "#fff"
				},
				children: [
					t + 1,
					". ",
					L[e]
				]
			}, e))
		})]
	}), e.phase === "draft" && v && /* @__PURE__ */ F("div", {
		className: "rsb-draft pointer-events-auto mx-2 mb-2 rounded-xl border-2 border-ink bg-surface p-2",
		children: /* @__PURE__ */ F("div", {
			className: "grid grid-cols-2 gap-2",
			children: v.map((e, t) => /* @__PURE__ */ I("button", {
				type: "button",
				className: "rsb-draft-card card min-h-16 cursor-pointer p-2 text-left",
				onClick: () => a({
					type: "pick",
					card: t
				}),
				children: [/* @__PURE__ */ F("p", {
					className: "text-xs font-extrabold",
					children: sr(e, o).name
				}), /* @__PURE__ */ F("p", {
					className: "text-[10px] leading-3.5 text-ink/70",
					children: sr(e, o).desc
				})]
			}, t))
		})
	})] });
	return /* @__PURE__ */ F(d, {
		adaptive: !0,
		className: "rsb-screen",
		banner: re,
		actions: ie,
		actionsHeight: "rsb-actions-height",
		overlay: ae,
		scroll: !1,
		children: /* @__PURE__ */ I("div", {
			className: "rsb-playfield",
			children: [/* @__PURE__ */ F("div", {
				className: "rsb-race-column",
				ref: ee,
				children: /* @__PURE__ */ F(ir, { pub: e })
			}), /* @__PURE__ */ I("div", {
				className: "rsb-bet-board flex flex-col gap-2 px-2 pb-2",
				children: [/* @__PURE__ */ I("div", {
					className: "rsb-bet-main",
					children: [
						/* @__PURE__ */ I("div", {
							className: "rsb-bet-head",
							children: [
								/* @__PURE__ */ F("strong", { children: o("games.readysetbet.bettingBoard") }),
								/* @__PURE__ */ F("span", { children: "BETTING BOARD" }),
								/* @__PURE__ */ F("small", { children: e.noMoreBets ? o(y ? "games.readysetbet.lastSecondOpen" : "games.readysetbet.betsClosed") : o("games.readysetbet.bettingOpen") })
							]
						}),
						/* @__PURE__ */ F("div", {
							className: "rsb-color-grid grid grid-cols-4 gap-1",
							children: B.map((e) => {
								let t = {
									kind: "color",
									key: e.key
								};
								return /* @__PURE__ */ F(_r, {
									mult: e.mult,
									penalty: e.penalty,
									occupants: T(t),
									colorOf: g,
									hint: O && k(t),
									colorBet: e.key,
									onClick: () => w(t),
									children: /* @__PURE__ */ I("span", {
										className: "rsb-color-label text-center text-[10px] leading-3 font-bold",
										children: [/* @__PURE__ */ F("span", {
											className: "rsb-color-dot mr-0.5 inline-block h-2.5 w-2.5 rounded-full border border-ink/30",
											style: { background: lr[e.key] }
										}), o(or[e.key])]
									})
								}, e.key);
							})
						}),
						/* @__PURE__ */ I("div", {
							className: "rsb-wps-grid grid grid-cols-[2rem_repeat(7,minmax(0,1fr))] gap-0.5",
							children: [
								/* @__PURE__ */ F("span", {}),
								ur.map((e) => /* @__PURE__ */ F("span", {
									className: `section-label justify-center ${e === "win" ? "col-span-3" : "col-span-2"}`,
									children: o(ar[e])
								}, e)),
								z.map((e, t) => /* @__PURE__ */ I(n, { children: [/* @__PURE__ */ F("span", {
									className: "rsb-wps-horse flex items-center justify-center font-mono text-[10px] font-extrabold tabular-nums",
									style: { "--rsb-horse": Q[R[t]] },
									children: L[t]
								}), ur.map((n) => e[n].map((e, r) => {
									let i = {
										kind: "wps",
										horse: t,
										col: n,
										cell: r
									};
									return /* @__PURE__ */ F(_r, {
										mult: e[0],
										penalty: e[1],
										occupants: T(i),
										colorOf: g,
										hint: O && k(i),
										onClick: () => w(i)
									}, n + r);
								}))] }, t))
							]
						})
					]
				}), /* @__PURE__ */ I("div", {
					className: "rsb-bet-side",
					children: [/* @__PURE__ */ I("div", { children: [/* @__PURE__ */ F("p", {
						className: "section-label",
						children: o("games.readysetbet.propSection")
					}), /* @__PURE__ */ F("div", {
						className: "grid grid-cols-2 gap-1",
						children: e.propsOpen.map((t, n) => {
							let r = lt[t], i = {
								kind: "prop",
								card: n
							};
							return /* @__PURE__ */ F(_r, {
								mult: r.win,
								penalty: r.loss,
								occupants: T(i),
								colorOf: g,
								hint: O && k(i),
								wide: n === e.propsOpen.length - 1 && e.propsOpen.length % 2 == 1,
								onClick: () => w(i),
								children: /* @__PURE__ */ I("span", {
									className: "rsb-prop-horses flex flex-wrap items-center justify-center gap-x-1 gap-y-0.5",
									children: [
										r.over.map((e) => /* @__PURE__ */ F(gr, { h: e }, e)),
										/* @__PURE__ */ F("span", {
											className: "rsb-prop-vs text-[9px] font-extrabold opacity-50",
											children: "VS"
										}),
										r.under.map((e) => /* @__PURE__ */ F(gr, { h: e }, e))
									]
								})
							}, t);
						})
					})] }), /* @__PURE__ */ I("div", { children: [/* @__PURE__ */ F("p", {
						className: "section-label",
						children: o("games.readysetbet.exoticSection")
					}), /* @__PURE__ */ F("div", {
						className: "grid grid-cols-2 gap-1",
						children: e.exoticsOpen.map((e, t) => {
							let n = ut[e], r = {
								kind: "exotic",
								card: t
							};
							return /* @__PURE__ */ I(_r, {
								mult: n.win,
								penalty: n.loss,
								occupants: T(r),
								colorOf: g,
								hint: O && k(r),
								onClick: () => w(r),
								children: [/* @__PURE__ */ F("span", {
									className: "rsb-exotic-name text-center text-[11px] leading-3.5 font-extrabold",
									children: o(dr[n.key])
								}), /* @__PURE__ */ F("span", {
									className: "rsb-exotic-desc text-center text-[9px] leading-3 opacity-70",
									children: o(fr[n.key])
								})]
							}, e);
						})
					})] })]
				})]
			})]
		})
	});
}
function gr({ h: e }) {
	return /* @__PURE__ */ F("span", {
		className: "rsb-horse-badge rounded px-1 py-px font-mono text-[9px] leading-3.5 font-extrabold text-white tabular-nums",
		style: { background: Q[R[e]] },
		children: L[e]
	});
}
function _r({ mult: e, penalty: t, children: n, occupants: r, colorOf: i, hint: a, wide: o, colorBet: s, onClick: c }) {
	return /* @__PURE__ */ I("button", {
		type: "button",
		onClick: c,
		className: `rsb-bet-cell relative flex min-h-11 min-w-0 w-full flex-1 flex-col items-center justify-center gap-1 rounded-lg border-2 px-0.5 py-1 ${s ? `rsb-color-${s}` : ""} ${o ? "col-span-2" : ""}`,
		children: [
			n,
			/* @__PURE__ */ I("span", {
				className: "rsb-odds-row flex items-center justify-center gap-0.5",
				children: [/* @__PURE__ */ I("span", {
					className: "rsb-mult font-mono text-sm font-extrabold tabular-nums",
					children: [e, "x"]
				}), t > 0 && /* @__PURE__ */ I("span", {
					className: "rsb-penalty flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-0.5 font-mono text-[9px] font-extrabold text-white tabular-nums",
					children: ["-", t]
				})]
			}),
			r.length > 0 && /* @__PURE__ */ F("span", {
				className: "rsb-occupants absolute -top-1.5 -right-1.5 flex -space-x-1",
				children: r.map((e, t) => /* @__PURE__ */ F("span", {
					className: `rsb-occupant flex h-5 w-5 items-center justify-center rounded-full border-2 border-surface font-mono text-[9px] font-extrabold text-white tabular-nums ${e.piggyback ? "ring-2 ring-amber-300" : ""}`,
					style: {
						background: i(e.rid),
						boxShadow: "0 1px 2px rgba(0,0,0,.3)"
					},
					title: e.piggyback ? "🐷" : void 0,
					children: e.token.value
				}, t))
			}),
			a && /* @__PURE__ */ F(f, {
				radius: 6,
				dur: 3.2,
				flash: !1
			})
		]
	});
}
function vr({ token: e, color: t, selected: n, disabled: r, ariaLabel: i, onClick: a }) {
	let o = e.bonus ? e.bonus.color === "white" ? "#fffdf6" : "#262626" : null, s = o === "#fffdf6";
	return /* @__PURE__ */ I("button", {
		type: "button",
		"aria-label": i,
		"aria-pressed": n,
		disabled: r,
		onClick: a,
		className: `rsb-token-chip relative flex h-9 w-9 flex-none items-center justify-center rounded-full transition-all duration-150 ${n ? "-translate-y-0.5 scale-110" : ""} ${r ? "opacity-40" : ""}`,
		style: {
			background: o ?? t,
			boxShadow: n ? `0 0 0 2px var(--color-surface), 0 0 0 5px ${ht.accent}, 0 5px 8px rgba(0,0,0,.3)` : "0 2px 3px rgba(0,0,0,.3)"
		},
		children: [/* @__PURE__ */ F("span", { className: `pointer-events-none absolute inset-1 rounded-full border-2 border-dashed ${s ? "border-ink/40" : "border-white/70"}` }), /* @__PURE__ */ F("span", {
			className: `rsb-token-value font-mono text-sm font-extrabold tabular-nums ${s ? "text-ink" : "text-white"}`,
			style: s ? void 0 : { textShadow: "0 1px 2px rgba(0,0,0,.45)" },
			children: e.value
		})]
	});
}
//#endregion
//#region src/games/readysetbet/bot.ts
var yr = {
	sims: 300,
	evThreshold: 2,
	maxBets: 12
}, br = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32;
function xr(e, t, n) {
	let r = e.slice(), i = t, a = n;
	for (;;) {
		let e = 2 + Math.floor(br() * 6) + Math.floor(br() * 6), t = ot(e), n = i !== null && ot(i) === t && !a;
		if (r[t] = Math.min(15, r[t] + 1 + (n ? at[t] : 0)), i = e, a = n, r[t] >= 15) return r;
	}
}
function Sr(e) {
	let t = Array.from({ length: 9 }, (e, t) => t).sort((t, n) => e[n] - e[t] || t - n), n = Array(9).fill(1), r = 1;
	for (let i = 0; i < 9; i += 1) i > 0 && e[t[i]] < e[t[i - 1]] && (r = i + 1), n[t[i]] = r;
	return {
		rank: n,
		winner: t[0]
	};
}
function Cr(e, t) {
	let n = Array(9).fill(0), r = Array(9).fill(0), i = Array(9).fill(0), a = Array(B.length).fill(0), o = Array(e.propsOpen.length).fill(0), s = Array(e.exoticsOpen.length).fill(0), c = e.lastRoll ? e.lastRoll.sum : null, l = e.lastRoll ? e.lastRoll.bonus : !1;
	for (let u = 0; u < t; u += 1) {
		let t = xr(e.positions, c, l), { rank: u, winner: d } = Sr(t);
		for (let e = 0; e < 9; e += 1) u[e] === 1 && (n[e] += 1), u[e] <= 2 && (r[e] += 1), u[e] <= 3 && (i[e] += 1);
		B.forEach((e, t) => {
			(e.key === "seven5th" ? u[4] >= 5 : R[d] === e.key) && (a[t] += 1);
		}), e.propsOpen.forEach((e, n) => {
			let r = lt[e];
			Math.min(...r.over.map((e) => t[e])) > Math.max(...r.under.map((e) => t[e])) && (o[n] += 1);
		});
		let f = [...new Set(t)].sort((e, t) => t - e), p = f.length >= 2 ? 15 - f[1] : 0;
		e.exoticsOpen.forEach((e, n) => {
			let r = ut[e].key;
			(r === "tightRace" ? t.every((e) => e >= 6) : r === "lateStart" ? t.filter((e) => e <= 3).length >= 2 : r === "photoFinish" ? f.length >= 3 && 15 - f[2] <= 3 : r === "byANose" ? p === 1 : p > 5) && (s[n] += 1);
		});
	}
	let u = (e) => e.map((e) => e / t);
	return {
		win: u(n),
		place: u(r),
		show: u(i),
		color: u(a),
		prop: u(o),
		exotic: u(s)
	};
}
function wr(e, t, n, r, i, a) {
	let o = e * (r.value * (t + i) + (a ? 2 : 0)), s = r.bonus?.negateLoss ? 0 : n > 0 ? n + (r.bonus?.extraLoss ?? 0) : 0;
	return o - (1 - e) * (s + +!!a);
}
var $ = (e) => JSON.stringify(e);
function Tr(e, t) {
	switch (e.key) {
		case "bonus": return 5 + e.value + (e.negateLoss ? 3 : 0) - e.extraLoss;
		case "compChips": return [
			9,
			6,
			4
		][Math.min(t + 1, 3) - 1] + 2;
		case "lastSecond": return 7;
		case "favored": return 4.5;
		case "highRoller": return 4;
		case "sideBet": return 3.5;
		case "piggyback": return 3;
		case "snakeEyes": return 2.5;
		case "risky": return 2;
	}
}
function Er(e = {}) {
	let t = {
		...yr,
		...e
	};
	return (e, n) => {
		let r = e.public, i = e.private;
		if (!i) return null;
		if (r.phase === "draft") {
			if (!i.draftOptions) return null;
			let e = i.vip.length;
			return { action: {
				type: "pick",
				card: Tr(i.draftOptions[0], e) >= Tr(i.draftOptions[1], e) ? 0 : 1
			} };
		}
		if (r.phase !== "racing" || i.tokens.length === 0 || r.noMoreBets && !i.vip.some((e) => e.key === "lastSecond") || r.bets.filter((e) => e.rid === n.rid).length >= t.maxBets) return null;
		if (n.difficulty === "weak") {
			let e = new Set(r.bets.map((e) => $(e.spot))), t = [];
			for (let e = 0; e < 9; e += 1) t.push({
				kind: "wps",
				horse: e,
				col: "win",
				cell: 0
			}, {
				kind: "wps",
				horse: e,
				col: "show",
				cell: 0
			});
			for (let e of B) t.push({
				kind: "color",
				key: e.key
			});
			let n = t.filter((t) => !e.has($(t)));
			return n.length === 0 ? null : { action: {
				type: "bet",
				spot: n[Math.floor(br() * n.length)],
				tokenId: i.tokens[Math.floor(br() * i.tokens.length)].id
			} };
		}
		let a = i.vip.some((e) => e.key === "highRoller"), o = i.vip.some((e) => e.key === "risky"), s = Cr(r, t.sims), c = /* @__PURE__ */ new Map();
		for (let e of r.bets) c.set($(e.spot), (c.get($(e.spot)) ?? 0) + 1);
		let l = new Set(r.bets.filter((e) => e.rid === n.rid).map((e) => $(e.spot))), u = null, d = (e, n, r, a, s = 0) => {
			let d = $(e);
			if (l.has(d)) return;
			let f = c.get(d) ?? 0, p = e.kind !== "exotic" && f === 1 && i.piggybackTokens.length > 0;
			if (!(f > 0 && !p) && !(e.kind === "exotic" && f >= 3)) for (let c of i.tokens) {
				if (f > 0 && !i.piggybackTokens.includes(c.value)) continue;
				let l = wr(n, r, a, c, s, o);
				l > t.evThreshold && (!u || l > u.ev) && (u = {
					spot: e,
					token: c,
					ev: l
				});
			}
		};
		for (let e = 0; e < 9; e += 1) {
			let t = a ? ft[R[e]] : 0;
			z[e].show.forEach((t, n) => d({
				kind: "wps",
				horse: e,
				col: "show",
				cell: n
			}, s.show[e], t[0], t[1])), z[e].place.forEach((t, n) => d({
				kind: "wps",
				horse: e,
				col: "place",
				cell: n
			}, s.place[e], t[0], t[1])), z[e].win.forEach((n, r) => d({
				kind: "wps",
				horse: e,
				col: "win",
				cell: r
			}, s.win[e], n[0], n[1], t));
		}
		if (B.forEach((e, t) => d({
			kind: "color",
			key: e.key
		}, s.color[t], e.mult, e.penalty)), r.propsOpen.forEach((e, t) => {
			let n = lt[e];
			d({
				kind: "prop",
				card: t
			}, s.prop[t], n.win, n.loss);
		}), r.exoticsOpen.forEach((e, t) => {
			let n = ut[e];
			d({
				kind: "exotic",
				card: t
			}, s.exotic[t], n.win, n.loss);
		}), !u) return null;
		let f = u;
		return { action: {
			type: "bet",
			spot: f.spot,
			tokenId: f.token.id
		} };
	};
}
var Dr = Er(), Or = (e, t, n) => {
	if (e.type === "pick") {
		let r = t.private?.draftOptions?.[e.card];
		return n("games.readysetbet.describePick", { name: r ? sr(r, n).name : "?" });
	}
	if (e.type === "bet") {
		let r = t.private?.tokens.find((t) => t.id === e.tokenId);
		return n("games.readysetbet.describeBet", {
			n: r?.value ?? 0,
			spot: cr(e.spot, n)
		});
	}
	return "";
}, kr = {
	settle(e, t) {
		let n = e.data?.deltas;
		if (!n) return null;
		let r = [];
		for (let [e, i] of Object.entries(n)) {
			if (i === 0) continue;
			let n = t.anchor(`seat:${e}`);
			n && r.push(/* @__PURE__ */ F(et, {
				at: n,
				ms: 2400,
				children: /* @__PURE__ */ F("span", {
					className: `font-mono text-xl font-extrabold tabular-nums ${i > 0 ? "text-done-ink" : "text-danger-ink"}`,
					children: i > 0 ? `+$${i}` : `-$${-i}`
				})
			}, e));
		}
		return r.length ? {
			ms: 2500,
			node: r
		} : null;
	},
	chipGain(e, t) {
		let n = e.data?.amount, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || !n ? null : {
			ms: 1400,
			node: /* @__PURE__ */ F(et, {
				at: r,
				ms: 1300,
				children: /* @__PURE__ */ I("span", {
					className: "font-mono text-lg font-extrabold text-done-ink tabular-nums",
					children: ["+$", n]
				})
			})
		};
	},
	vipGain(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 1200,
			node: /* @__PURE__ */ F(et, {
				at: n,
				ms: 1100,
				children: /* @__PURE__ */ F("span", {
					className: "text-xl",
					children: "🎖️"
				})
			})
		} : null;
	},
	noMoreBets(e, t) {
		let n = t.anchor("track");
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ F(tt, {
				at: n,
				ms: 900
			})
		} : null;
	}
};
//#endregion
//#region src/games/readysetbet/game-over.tsx
function Ar(e) {
	return /* @__PURE__ */ F("div", {
		className: "rsb-over",
		children: /* @__PURE__ */ F(nt, {
			...e,
			accent: ht.accent
		})
	});
}
//#endregion
//#region src/games/readysetbet/options.tsx
var jr = [
	{
		ms: 1500,
		key: "games.readysetbet.rollFast"
	},
	{
		ms: 2500,
		key: "games.readysetbet.rollNormal"
	},
	{
		ms: 4e3,
		key: "games.readysetbet.rollSlow"
	}
];
function Mr({ value: e, onChange: t }) {
	let n = l(), r = vt.safeParse(e), i = r.success ? r.data : vt.parse(void 0);
	return /* @__PURE__ */ F(it, {
		title: n("games.readysetbet.optRollMs"),
		columns: 3,
		children: jr.map((e) => /* @__PURE__ */ F(rt, {
			name: "readysetbet-roll-ms",
			value: String(e.ms),
			checked: i.rollMs === e.ms,
			label: n(e.key),
			accent: ht.accent,
			onChange: () => t({ rollMs: e.ms })
		}, e.ms))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/readysetbet/entry.tsx
var Nr = {
	definition: Bt,
	View: mr,
	bot: Dr,
	describe: Or,
	fx: kr,
	OverView: Ar,
	Options: Mr,
	locales: {
		zh: {
			name: "赛马大亨",
			desc: "实时下注的赛马派对,四场比赛谁钱多谁赢",
			rules: "目标:四场比赛后,持有金钱最多的玩家获胜。\n准备:\n· 九匹马根据两颗骰子的点数之和前进：2或3对应同一匹马，11或12对应同一匹马，4至10各对应一匹马。赛道共有15格，所有玩家的初始资金均为0。\n· 每人持有 2、3、3、4、5 五个注码;7 人以上改为 2、3、4、5。\n流程:\n· 比赛自动进行:定时掷两枚骰子,点数和驱动对应的马前进一格。\n· 同一匹马连续两次被驱动时额外冲刺(7 号马无冲刺,连续第三次不触发)。\n· 赛跑期间随时把注码放上投注板空格,先到先得,每格限一枚。\n· 第三匹马越过红线后停止下注;任一马到达终点比赛立即结束。\n· 第一至三场赛后,每人从两张 VIP 卡中选一张保留,效果累积。\n结算:\n· 押中冠军时，该马的头马、前二和前三投注均获胜。\n· 押中亚军时，该马的前二和前三投注获胜。\n· 押中季军时，仅该马的前三投注获胜。\n并列名次的马匹适用相同的投注获胜规则。\n· 投注获胜时，获得的赔付等于注码面值乘以投注格的倍率。投注未获胜时，支付该格红圈内标示的罚金；格内没有红圈时，无须支付罚金。\n· 资金全部用完时，不会产生债务。四场比赛结束后，持有金钱最多的玩家获胜；金额相同时，共同获胜。",
			raceOf: "第 {{n}}/{{total}} 场",
			racingBanner: "比赛进行中,随时下注",
			noMoreBets: "停止下注!",
			lastSecondHint: "压哨下注:你仍可下注",
			settleBanner: "本场结算",
			settleTitle: "第 {{n}} 场结果",
			winnerIs: "冠军 {{horse}}",
			draftBanner: "选一张 VIP 卡保留",
			draftWaiting: "已选,等其他人…",
			pickVip: "保留这张",
			colWin: "头马",
			colPlace: "前二",
			colShow: "前三",
			colorBlue: "蓝马夺冠",
			colorOrange: "橙马夺冠",
			colorRed: "红马夺冠",
			colorSeven5th: "7 号第五名或更差",
			propSection: "预言注",
			exoticSection: "终局注",
			propVs: "{{a}} 跑赢 {{b}}",
			exoticTightRace: "并驾齐驱",
			exoticLateStart: "慢热开局",
			exoticPhotoFinish: "照片判定",
			exoticByANose: "鼻差",
			exoticBlowOut: "一骑绝尘",
			exoticTightRaceDesc: "所有马总移动至少 6 格",
			exoticLateStartDesc: "至少 2 匹马总移动不超过 3 格",
			exoticPhotoFinishDesc: "季军落后不超过 3 格",
			exoticByANoseDesc: "亚军恰好落后 1 格",
			exoticBlowOutDesc: "亚军落后超过 5 格",
			vipBonus: "奖励注码 {{n}}",
			vipBonusNegate: "输注不付罚金",
			vipBonusExtra: "输注罚金 +{{n}}",
			vipSnakeEyes: "蛇眼与车箱",
			vipSnakeEyesDesc: "每次掷出 2 或 12,得 $1",
			vipLastSecond: "压哨下注",
			vipLastSecondDesc: "红线封盘对你无效",
			vipFavored: "心头好 {{horse}}",
			vipFavoredDesc: "每掷出对应点数累积 $1;7 号夺冠则没收",
			vipHighRoller: "大豪客",
			vipHighRollerDesc: "头马列额外赔率:红 +1、橙 +2、蓝 +3",
			vipSideBet: "边注 {{horses}}",
			vipSideBetDesc: "目标马进前三,按名次得钱",
			vipCompChips: "赠品筹码",
			vipCompChipsDesc: "按这是你第几张 VIP,立即得 $9/$6/$4",
			vipPiggyback: "搭注 {{n}}",
			vipPiggybackDesc: "每场一次,把 {{n}} 注码叠到有一枚对手注码的格上",
			vipRisky: "亡命赌徒",
			vipRiskyDesc: "每个赢注额外 +$2,每个输注额外 -$1",
			myTokens: "我的注码",
			favoredAcc: "卡上累积 ${{n}}",
			piggybackMark: "搭注",
			bonusDash: "冲刺 +{{n}}",
			raceScreen: "赛道电子屏",
			bettingBoard: "投注板",
			bettingOpen: "封盘前可下注",
			lastSecondOpen: "压哨可下注",
			rollResult: "掷骰结果",
			dicePending: "待掷骰子",
			waitingRoll: "等待掷骰",
			total: "合计",
			horseLabel: "{{horse}} 号马",
			crossedCount: "已过红线 {{n}}/3",
			betsClosed: "封盘中",
			horseProgress: "{{horse}} 号马，已跑 {{n}}/15 格",
			shotSprint: "冲刺特写",
			shotOverview: "全场斜俯视",
			shotSide: "赛道侧跟",
			shotFront: "领跑正面",
			shotRear: "落后后方",
			shotClose: "单马近景",
			shotFinish: "终点定格",
			broadcastAria: "{{horse}} 号马实况，{{shot}}",
			broadcastOverviewAria: "九匹马全场实况，全景镜头",
			allHorses: "全场",
			broadcastPaused: "赛后",
			broadcastLoading: "正在接入实况…",
			broadcastUnavailable: "3D 转播暂不可用",
			betAria: "用 {{n}} 注码下注",
			tokenAria: "选择 {{n}} 注码",
			optRollMs: "掷骰间隔",
			rollFast: "快(1.5 秒)",
			rollNormal: "标准(2.5 秒)",
			rollSlow: "慢(4 秒)",
			describeBet: "用 {{n}} 注码下 {{spot}}",
			describePick: "保留「{{name}}」",
			spotWps: "{{horse}}·{{col}}",
			spotProp: "预言注 {{n}}",
			spotExotic: "终局注 {{n}}",
			errNotRacing: "现在不在比赛阶段",
			errNoMoreBets: "已停止下注",
			errNoToken: "这枚注码不可用",
			errBadSpot: "这个位置不能下注",
			errSpotTaken: "这格已有注码",
			errNotDraft: "现在不能选卡"
		},
		en: {
			name: "Ready Set Bet",
			desc: "Real-time betting horse-racing party; richest after four races wins",
			rules: "Goal: after four races, the player with the most money wins.\nSetup:\n· The nine horses advance according to the sum of two dice: 2 and 3 share one horse, 11 and 12 share another, and each sum from 4 through 10 has its own horse. The track has 15 spaces, and every player starts with $0.\n· Each player holds bet tokens 2, 3, 3, 4, 5; with 7+ players drop one 3.\nPlay:\n· Races run automatically: two dice roll on a timer and move the matching horse one space.\n· A horse moved twice in a row sprints bonus spaces (not horse 7; never thrice in a row).\n· During the race, place tokens on open board spots at any time, first come first served.\n· Betting closes once three horses cross the red line; the race ends at the finish.\n· After races 1-3, each player keeps one of two dealt VIP cards; effects accumulate.\nScoring:\nWinning bets depend on the horse’s finishing position:\n· First place: WIN, PLACE and SHOW bets on that horse win.\n· Second place: PLACE and SHOW bets on that horse win.\n· Third place: SHOW bets on that horse win.\nTied horses use the same payout rules for their shared position.\n· Winning bets pay token value × spot multiplier; losing bets pay the red-circle penalty.\n· You never go into debt; richest after four races wins, ties share the victory.",
			raceOf: "Race {{n}}/{{total}}",
			racingBanner: "Race in progress — bet anytime",
			noMoreBets: "No more bets!",
			lastSecondHint: "Last-Second Bettor: you can still bet",
			settleBanner: "Race results",
			settleTitle: "Race {{n}} results",
			winnerIs: "Winner: {{horse}}",
			draftBanner: "Keep one VIP card",
			draftWaiting: "Picked. Waiting for others…",
			pickVip: "Keep this card",
			colWin: "WIN",
			colPlace: "PLACE",
			colShow: "SHOW",
			colorBlue: "Blue horse wins",
			colorOrange: "Orange horse wins",
			colorRed: "Red horse wins",
			colorSeven5th: "7 finishes 5th or worse",
			propSection: "Prop Bets",
			exoticSection: "Exotic Finishes",
			propVs: "{{a}} beats {{b}}",
			exoticTightRace: "Tight Race",
			exoticLateStart: "Late Start",
			exoticPhotoFinish: "Photo Finish",
			exoticByANose: "By a Nose",
			exoticBlowOut: "Blow Out",
			exoticTightRaceDesc: "Every horse moves at least 6 spaces",
			exoticLateStartDesc: "At least 2 horses move 3 or fewer spaces",
			exoticPhotoFinishDesc: "3rd place trails by 3 or fewer",
			exoticByANoseDesc: "2nd place trails by exactly 1",
			exoticBlowOutDesc: "2nd place trails by more than 5",
			vipBonus: "Bonus Token {{n}}",
			vipBonusNegate: "Losing bets pay no penalty",
			vipBonusExtra: "Losing bets pay +{{n}} penalty",
			vipSnakeEyes: "Snake Eyes & Boxcars",
			vipSnakeEyesDesc: "Gain $1 whenever a 2 or 12 is rolled",
			vipLastSecond: "Last-Second Bettor",
			vipLastSecondDesc: "The red-line betting freeze does not apply to you",
			vipFavored: "Favored Horse {{horse}}",
			vipFavoredDesc: "Bank $1 per matching roll; lost if horse 7 wins the race",
			vipHighRoller: "High Roller",
			vipHighRollerDesc: "Extra WIN odds: red +1, orange +2, blue +3",
			vipSideBet: "Side Bet {{horses}}",
			vipSideBetDesc: "Pays by finish if a listed horse reaches the top three",
			vipCompChips: "Complimentary Chips",
			vipCompChipsDesc: "Immediately gain $9/$6/$4 as your 1st/2nd/3rd VIP card",
			vipPiggyback: "Piggyback Bet {{n}}",
			vipPiggybackDesc: "Once per race, stack your {{n}} token on a spot holding one rival token",
			vipRisky: "Risky Gambler",
			vipRiskyDesc: "Each winning bet +$2, each losing bet -$1",
			myTokens: "My tokens",
			favoredAcc: "${{n}} banked on card",
			piggybackMark: "Piggyback",
			bonusDash: "Sprint +{{n}}",
			raceScreen: "Live track screen",
			bettingBoard: "Betting board",
			bettingOpen: "Bet until closed",
			lastSecondOpen: "Last-second bet",
			rollResult: "Dice result",
			dicePending: "Dice waiting to roll",
			waitingRoll: "Awaiting roll",
			total: "Total",
			horseLabel: "Horse {{horse}}",
			crossedCount: "{{n}}/3 past red line",
			betsClosed: "Bets closed",
			horseProgress: "Horse {{horse}}, {{n}}/15 spaces",
			shotSprint: "Sprint close-up",
			shotOverview: "Full-field panorama",
			shotSide: "Side tracking",
			shotFront: "Leader head-on",
			shotRear: "Trailing rear view",
			shotClose: "Horse close-up",
			shotFinish: "Finish frame",
			broadcastAria: "Live horse {{horse}}, {{shot}}",
			broadcastOverviewAria: "Full-field live view of all nine horses",
			allHorses: "FIELD",
			broadcastPaused: "POST RACE",
			broadcastLoading: "Connecting live feed…",
			broadcastUnavailable: "3D broadcast unavailable",
			betAria: "Bet with token {{n}}",
			tokenAria: "Select token {{n}}",
			optRollMs: "Dice interval",
			rollFast: "Fast (1.5s)",
			rollNormal: "Normal (2.5s)",
			rollSlow: "Slow (4s)",
			describeBet: "Bet {{n}} on {{spot}}",
			describePick: "Keep \"{{name}}\"",
			spotWps: "{{horse}} {{col}}",
			spotProp: "Prop Bet {{n}}",
			spotExotic: "Exotic Bet {{n}}",
			errNotRacing: "No race is running right now",
			errNoMoreBets: "Betting is closed",
			errNoToken: "That token is not available",
			errBadSpot: "You cannot bet there",
			errSpotTaken: "That spot is taken",
			errNotDraft: "No VIP draft right now"
		}
	}
};
//#endregion
export { Nr as default };
