import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { PhaseBanner as c } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { Texture as u } from "@bgparty/sdk/texture";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { GameOverScreen as ee } from "@bgparty/sdk/ui/game-over-screen";
var te = {
	10: "tree-green",
	11: "tree-red",
	12: "tree-brown",
	13: "tree-teal"
}, m = [
	"tree-green",
	"tree-red",
	"tree-brown",
	"tree-teal"
], ne = {
	0: [[0, 0], [1, 1]],
	1: [[0, 0], [1, -1]],
	3: [[0, 0], [1, 0]],
	2: [[0, 0], [0, 1]],
	5: [
		[0, 0],
		[-1, 0],
		[1, 0]
	],
	4: [
		[0, 0],
		[0, -1],
		[0, 1]
	],
	6: [
		[0, 0],
		[-1, 0],
		[0, -1]
	]
}, re = [
	9,
	9,
	7,
	6
], h = [
	5,
	4,
	3,
	2,
	1,
	0
], ie = [
	26,
	13,
	11,
	11
], g = [
	{
		deck: 4,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			13,
			0,
			1,
			0,
			13,
			0,
			3,
			2,
			3
		]
	},
	{
		deck: 4,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			2,
			0,
			1,
			0,
			3,
			11,
			11,
			3,
			0
		]
	},
	{
		deck: 4,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			12,
			0,
			12,
			2,
			0,
			0,
			3,
			3,
			1
		]
	},
	{
		deck: 4,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			0,
			2,
			1,
			12,
			12,
			1
		]
	},
	{
		deck: 4,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			13,
			0,
			1,
			2,
			0,
			1,
			0,
			1,
			13
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			10,
			10,
			0,
			2,
			0,
			1
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			2,
			0,
			3,
			3,
			10,
			10,
			3
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			3,
			2,
			3,
			3,
			0,
			3,
			11
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			3,
			12,
			12,
			0,
			2,
			3,
			3
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			3,
			2,
			0,
			0,
			0,
			10,
			10
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			13,
			13,
			0,
			0,
			0,
			2,
			3
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			11,
			0,
			2,
			0,
			3,
			0,
			1
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			0,
			0,
			10,
			10,
			1,
			3,
			3,
			0,
			2
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			0,
			2,
			0,
			1,
			13,
			13
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			1,
			2,
			3,
			3,
			0,
			3,
			11
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			0,
			3,
			3,
			2,
			11,
			0,
			0
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			0,
			1,
			12,
			12,
			0,
			2
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			12,
			12,
			0,
			2,
			1,
			3,
			0
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			11,
			1,
			0,
			3,
			0,
			2,
			3
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			13,
			0,
			13,
			1,
			0,
			1,
			0,
			2,
			1
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			0,
			2,
			0,
			11,
			11,
			1
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			3,
			2,
			3,
			3,
			3,
			10,
			10
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			2,
			0,
			3,
			3,
			3,
			1,
			13,
			13,
			3
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			12,
			0,
			2,
			0,
			1,
			0,
			12,
			0,
			3
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			2,
			1,
			0,
			0,
			13,
			13,
			0
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			0,
			3,
			10,
			10,
			0,
			1,
			2
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			10,
			0,
			0,
			2,
			1,
			3,
			10,
			0,
			3
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			1,
			0,
			3,
			0,
			11,
			11,
			3,
			0,
			2
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			0,
			0,
			13,
			13,
			3,
			0,
			2,
			1,
			3
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			10,
			10,
			0,
			2,
			1,
			1
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			2,
			0,
			1,
			0,
			1,
			12,
			12
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			0,
			0,
			11,
			11,
			3,
			3,
			2,
			3,
			3
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			13,
			13,
			0,
			1,
			0,
			2
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			10,
			10,
			3,
			2,
			3,
			3,
			0
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			2,
			3,
			3,
			3,
			0,
			12,
			12
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			0,
			0,
			2,
			1,
			0,
			10,
			10
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			3,
			2,
			3,
			11,
			11,
			0,
			3
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			0,
			0,
			0,
			1,
			2,
			0,
			3,
			12,
			12
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			10,
			0,
			0,
			3,
			3,
			1,
			0,
			2,
			10
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			1,
			0,
			3,
			0,
			3,
			2,
			0,
			12,
			12
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			13,
			0,
			13,
			1,
			2,
			0,
			3,
			0,
			3
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			11,
			3,
			3,
			0,
			0,
			2,
			1
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			2,
			0,
			10,
			10,
			1,
			0,
			1
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			0,
			2,
			11,
			11,
			0,
			1
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			3,
			3,
			0,
			12,
			12,
			3,
			2
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			13,
			0,
			3,
			3,
			13,
			3,
			3,
			2,
			3
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			0,
			0,
			12,
			12,
			0,
			1,
			2
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			2,
			0,
			0,
			13,
			13,
			3,
			3,
			0,
			0
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			11,
			0,
			0,
			1,
			0,
			2,
			0,
			1,
			11
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			0,
			0,
			10,
			10,
			3,
			1,
			2,
			0,
			0
		]
	},
	{
		deck: 1,
		type: "matriarch"
	},
	{
		deck: 1,
		type: "matriarch"
	},
	{
		deck: 1,
		type: "matriarch"
	},
	{
		deck: 1,
		type: "matriarch"
	},
	{
		deck: 1,
		type: "lion"
	},
	{
		deck: 1,
		type: "lion"
	},
	{
		deck: 1,
		type: "lion"
	},
	{
		deck: 2,
		type: "matriarch"
	},
	{
		deck: 2,
		type: "matriarch"
	},
	{
		deck: 2,
		type: "matriarch"
	},
	{
		deck: 2,
		type: "lion"
	},
	{
		deck: 2,
		type: "lion"
	},
	{
		deck: 2,
		type: "lion"
	},
	{
		deck: 3,
		type: "lion"
	},
	{
		deck: 3,
		type: "lion"
	},
	{
		deck: 3,
		type: "lion"
	},
	{
		deck: 3,
		type: "lion"
	},
	{
		deck: 3,
		type: "matriarch"
	},
	{
		deck: 3,
		type: "matriarch"
	}
], _ = [
	[
		0,
		11,
		13,
		10
	],
	[
		1,
		11,
		12,
		13
	],
	[
		2,
		10,
		11,
		12
	],
	[
		3,
		13,
		12,
		10
	],
	[
		4,
		13,
		10,
		11
	],
	[
		5,
		11,
		13,
		12
	]
], v = [
	1,
	2,
	4,
	3,
	3,
	3
], ae = [
	[
		4,
		1,
		0,
		0,
		0,
		1,
		0,
		0,
		0
	],
	[
		4,
		0,
		0,
		1,
		0,
		1,
		0,
		4,
		1
	],
	[
		4,
		0,
		4,
		3,
		3,
		0,
		4,
		4,
		0
	],
	[
		1,
		3,
		4,
		0,
		0,
		1,
		4,
		3,
		4
	],
	[
		4,
		0,
		3,
		4,
		0,
		0,
		3,
		4,
		1
	],
	[
		3,
		4,
		4,
		1,
		1,
		1,
		0,
		0,
		4
	]
], y = [
	{
		type: 1,
		effect: 0,
		arg: "tree-teal"
	},
	{
		type: 1,
		effect: 0,
		arg: "tree-brown"
	},
	{
		type: 0,
		effect: 1,
		arg: "tree-teal"
	},
	{
		type: 0,
		effect: 1,
		arg: "tree-green"
	},
	{
		type: 0,
		effect: 1,
		arg: "tree-brown"
	},
	{
		type: 1,
		effect: 2,
		arg: 5
	},
	{
		type: 0,
		effect: 3
	},
	{
		type: 1,
		effect: 4,
		arg: 1
	},
	{
		type: 1,
		effect: 2,
		arg: 0
	},
	{
		type: 1,
		effect: 5
	},
	{
		type: 0,
		effect: 6
	},
	{
		type: 0,
		effect: 7,
		arg: "lioness"
	},
	{
		type: 0,
		effect: 7,
		arg: "lion"
	},
	{
		type: 0,
		effect: 1,
		arg: "tree-red"
	},
	{
		type: 0,
		effect: 8
	},
	{
		type: 0,
		effect: 9
	},
	{
		type: 1,
		effect: 4,
		arg: 3
	},
	{
		type: 0,
		effect: 10
	},
	{
		type: 1,
		effect: 0,
		arg: "tree-red"
	},
	{
		type: 1,
		effect: 11
	}
], oe = {
	13: {
		destination: {
			x: 9,
			y: 0,
			rotation: 1
		},
		start: {
			x: 0,
			y: 18,
			rotation: 1,
			flipped: !0
		},
		tiles: [
			{
				x: 3,
				y: 0
			},
			{
				x: 0,
				y: 6
			},
			{
				x: 6,
				y: 9
			},
			{
				x: 9,
				y: 15
			},
			{
				x: 3,
				y: 18
			}
		],
		lioness: {
			x: 6,
			y: 9
		}
	},
	14: {
		destination: {
			x: 0,
			y: 0,
			rotation: 3
		},
		start: {
			x: 3,
			y: 24,
			rotation: 0
		},
		tiles: [
			{
				x: 3,
				y: 0
			},
			{
				x: 9,
				y: 0
			},
			{
				x: 6,
				y: 6
			},
			{
				x: 6,
				y: 12
			},
			{
				x: 3,
				y: 18
			},
			{
				x: 9,
				y: 18
			}
		],
		lioness: {
			x: 9,
			y: 6
		}
	},
	1: {
		destination: {
			x: 12,
			y: 0,
			rotation: 0
		},
		start: {
			x: 0,
			y: 24,
			rotation: 0
		},
		tiles: [
			{
				x: 12,
				y: 3
			},
			{
				x: 12,
				y: 9
			},
			{
				x: 6,
				y: 12
			},
			{
				x: 12,
				y: 15
			},
			{
				x: 0,
				y: 18
			},
			{
				x: 6,
				y: 18
			}
		],
		lion: {
			x: 15,
			y: 3
		},
		lioness: {
			x: 15,
			y: 18
		}
	},
	2: {
		destination: {
			x: 0,
			y: 0,
			rotation: 0
		},
		start: {
			x: 9,
			y: 24,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 0,
				y: 3
			},
			{
				x: 0,
				y: 9
			},
			{
				x: 3,
				y: 15
			},
			{
				x: 6,
				y: 6
			},
			{
				x: 9,
				y: 12
			},
			{
				x: 9,
				y: 18
			}
		],
		lion: {
			x: 3,
			y: 12
		},
		lioness: {
			x: 9,
			y: 12
		}
	},
	3: {
		destination: {
			x: 12,
			y: 0,
			rotation: 0
		},
		start: {
			x: 9,
			y: 24,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 0,
				y: 6
			},
			{
				x: 0,
				y: 12
			},
			{
				x: 6,
				y: 6
			},
			{
				x: 6,
				y: 12
			},
			{
				x: 12,
				y: 3
			},
			{
				x: 9,
				y: 18
			}
		],
		lion: {
			x: 15,
			y: 6
		},
		lioness: {
			x: 6,
			y: 15
		}
	},
	4: {
		destination: {
			x: 6,
			y: 0,
			rotation: 0
		},
		start: {
			x: 12,
			y: 21,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 0,
				y: 15
			},
			{
				x: 3,
				y: 9
			},
			{
				x: 6,
				y: 3
			},
			{
				x: 6,
				y: 15
			},
			{
				x: 9,
				y: 9
			},
			{
				x: 12,
				y: 15
			}
		],
		lion: {
			x: 9,
			y: 3
		},
		lioness: {
			x: 0,
			y: 18
		}
	},
	5: {
		destination: {
			x: 18,
			y: 3,
			rotation: 1
		},
		start: {
			x: 0,
			y: 18,
			rotation: 0
		},
		tiles: [
			{
				x: 0,
				y: 12
			},
			{
				x: 3,
				y: 6
			},
			{
				x: 6,
				y: 0
			},
			{
				x: 6,
				y: 15
			},
			{
				x: 9,
				y: 9
			},
			{
				x: 12,
				y: 3
			}
		],
		lion: {
			x: 6,
			y: 9
		},
		lioness: {
			x: 9,
			y: 12
		}
	},
	6: {
		destination: {
			x: 3,
			y: 0,
			rotation: 0
		},
		start: {
			x: 6,
			y: 21,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 3,
				y: 3
			},
			{
				x: 9,
				y: 3
			},
			{
				x: 0,
				y: 9
			},
			{
				x: 6,
				y: 9
			},
			{
				x: 12,
				y: 9
			},
			{
				x: 6,
				y: 15
			}
		],
		lion: {
			x: 3,
			y: 9
		},
		lioness: {
			x: 12,
			y: 9
		}
	},
	7: {
		destination: {
			x: 6,
			y: 0,
			rotation: 0
		},
		start: {
			x: 6,
			y: 21,
			rotation: 0
		},
		tiles: [
			{
				x: 6,
				y: 3
			},
			{
				x: 0,
				y: 6
			},
			{
				x: 12,
				y: 6
			},
			{
				x: 0,
				y: 12
			},
			{
				x: 12,
				y: 12
			},
			{
				x: 6,
				y: 15
			}
		],
		lion: {
			x: 3,
			y: 15
		},
		lioness: {
			x: 12,
			y: 15
		}
	},
	8: {
		destination: {
			x: 18,
			y: 6,
			rotation: 1
		},
		start: {
			x: 0,
			y: 18,
			rotation: 1,
			flipped: !0
		},
		tiles: [
			{
				x: 6,
				y: 0
			},
			{
				x: 0,
				y: 6
			},
			{
				x: 6,
				y: 6
			},
			{
				x: 6,
				y: 12
			},
			{
				x: 3,
				y: 18
			},
			{
				x: 12,
				y: 6
			}
		],
		lion: {
			x: 6,
			y: 12
		},
		lioness: {
			x: 9,
			y: 15
		}
	},
	9: {
		destination: {
			x: 9,
			y: 0,
			rotation: 0
		},
		start: {
			x: 3,
			y: 24,
			rotation: 0
		},
		tiles: [
			{
				x: 0,
				y: 12
			},
			{
				x: 3,
				y: 6
			},
			{
				x: 3,
				y: 18
			},
			{
				x: 9,
				y: 15
			},
			{
				x: 12,
				y: 9
			},
			{
				x: 9,
				y: 3
			}
		],
		lion: {
			x: 3,
			y: 9
		},
		lioness: {
			x: 12,
			y: 15
		}
	},
	10: {
		destination: {
			x: 3,
			y: 0,
			rotation: 0
		},
		start: {
			x: 12,
			y: 18,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 3,
				y: 3
			},
			{
				x: 0,
				y: 9
			},
			{
				x: 6,
				y: 9
			},
			{
				x: 3,
				y: 15
			},
			{
				x: 12,
				y: 6
			},
			{
				x: 12,
				y: 12
			}
		],
		lion: {
			x: 9,
			y: 9
		},
		lioness: {
			x: 9,
			y: 12
		}
	},
	11: {
		destination: {
			x: 6,
			y: 0,
			rotation: 0
		},
		start: {
			x: 6,
			y: 21,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 0,
				y: 3
			},
			{
				x: 6,
				y: 3
			},
			{
				x: 6,
				y: 9
			},
			{
				x: 0,
				y: 15
			},
			{
				x: 6,
				y: 15
			},
			{
				x: 12,
				y: 6
			}
		],
		lion: {
			x: 12,
			y: 9
		},
		lioness: {
			x: 6,
			y: 15
		}
	},
	12: {
		destination: {
			x: 3,
			y: 0,
			rotation: 0
		},
		start: {
			x: 0,
			y: 15,
			rotation: 1,
			flipped: !0
		},
		tiles: [
			{
				x: 3,
				y: 3
			},
			{
				x: 9,
				y: 6
			},
			{
				x: 9,
				y: 12
			},
			{
				x: 15,
				y: 3
			},
			{
				x: 15,
				y: 15
			},
			{
				x: 3,
				y: 15
			}
		],
		lion: {
			x: 9,
			y: 9
		},
		lioness: {
			x: 12,
			y: 15
		}
	}
}, se = {
	id: "tembo",
	tier: "alpha",
	mechanics: ["tile-placement", "hand-management"],
	interactionTags: ["cooperative"],
	nameKey: "games.tembo.name",
	descKey: "games.tembo.desc",
	rulesKey: "games.tembo.rules",
	icon: "🐘",
	iconImg: "games/tembo.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/tembo/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [
		2,
		3,
		4
	],
	accent: "#d97706",
	releasedAt: "2026-10-06",
	search: {
		py: "cao yuan zheng tu",
		init: "cyzt"
	},
	hotseat: "cover"
}, b = t.int().min(0).max(3), x = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("orient"),
		rotation: b
	}),
	t.object({
		type: t.literal("rotateTile"),
		tile: t.int().nonnegative(),
		rotation: b
	}),
	t.object({ type: t.literal("passRotate") }),
	t.object({
		type: t.literal("placeCard"),
		cardId: t.int().nonnegative(),
		x: t.int(),
		y: t.int(),
		rotation: b
	}),
	t.object({
		type: t.literal("placeElephants"),
		cardId: t.int().nonnegative(),
		x: t.int(),
		y: t.int(),
		rotation: b
	}),
	t.object({
		type: t.literal("placeSingle"),
		cardId: t.int().nonnegative(),
		x: t.int(),
		y: t.int()
	}),
	t.object({
		type: t.literal("support"),
		option: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("matriarch"),
		x: t.int().nullable(),
		y: t.int().nullable()
	}),
	t.object({
		type: t.literal("choosePlayer"),
		seat: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("placeSingleFree"),
		x: t.int(),
		y: t.int()
	}),
	t.object({
		type: t.literal("soloMatriarch"),
		discard: t.boolean()
	})
]), S = t.object({
	journey: t.int().min(0).max(14).prefault(0),
	difficulty: t.int().min(0).max(5).prefault(0),
	events: t.boolean().prefault(!1)
}).default({
	journey: 0,
	difficulty: 0,
	events: !1
}), C = t.object({
	x: t.int(),
	y: t.int()
}), ce = t.object({
	rid: t.string(),
	seat: t.int().nonnegative(),
	rotation: b.nullable(),
	rested: t.int().nonnegative(),
	tired: t.int().nonnegative(),
	onBoard: t.int().nonnegative(),
	handCount: t.int().nonnegative(),
	matriarchCount: t.int().nonnegative()
}), le = t.object({
	phase: t.enum([
		"orient",
		"reorient",
		"turn",
		"won",
		"lost"
	]),
	loseReason: t.int().nullable(),
	config: S,
	journey: t.int(),
	solo: t.boolean(),
	energy: t.int().nonnegative(),
	supportTokens: t.int().nonnegative(),
	destinationUnlocked: t.boolean(),
	tiles: t.array(t.object({
		id: t.int(),
		x: t.int(),
		y: t.int(),
		rotation: b
	})),
	start: t.object({
		x: t.int(),
		y: t.int(),
		rotation: t.int(),
		flipped: t.boolean()
	}),
	destination: t.object({
		x: t.int(),
		y: t.int(),
		rotation: t.int()
	}),
	squares: t.array(t.object({
		x: t.int(),
		y: t.int(),
		kind: t.enum(["landmark", "bonus"]),
		ref: t.int(),
		rotation: b,
		card: t.int().nullable(),
		cardRotation: b.nullable()
	})),
	cells: t.record(t.string(), t.int()),
	destinationCells: t.array(C),
	elephants: t.array(t.object({
		x: t.int(),
		y: t.int(),
		seat: t.int().nonnegative()
	})),
	matriarch: C,
	lions: t.array(t.object({
		type: t.enum(["lion", "lioness"]),
		x: t.int(),
		y: t.int(),
		standing: t.boolean()
	})),
	landmarks: t.array(t.object({
		ref: t.int(),
		x: t.int().nullable(),
		y: t.int().nullable()
	})),
	trees: t.record(t.string(), t.boolean()),
	players: t.array(ce),
	deckCount: t.int().nonnegative(),
	discardCount: t.int().nonnegative(),
	events: t.array(t.object({
		id: t.int(),
		older: t.boolean()
	})).nullable(),
	eventDeckCount: t.int().nonnegative(),
	turn: t.int().nonnegative(),
	supportRotate: t.boolean(),
	pending: t.object({
		kind: t.enum([
			"choosePlayer",
			"placeSingleFree",
			"matriarch",
			"soloMatriarch"
		]),
		amount: t.int().optional(),
		count: t.int().optional()
	}).nullable()
}), w = t.object({
	hand: t.array(t.int()),
	patterns: t.record(t.string(), t.array(t.object({
		x: t.int(),
		y: t.int(),
		r: b,
		cells: t.array(C.extend({ amount: t.int() }))
	}))),
	single: t.array(C.extend({ amount: t.int() })),
	singleFree: t.array(C),
	matriarchTargets: t.array(C),
	emptySquares: t.array(C)
}), T = (e) => ({ code: e }), E = (t, n) => e(t.seed, t.cursor++, n);
function D(e, t) {
	for (let n = t.length - 1; n > 0; n--) {
		let r = E(e, n + 1);
		[t[n], t[r]] = [t[r], t[n]];
	}
	return t;
}
var O = (e, t) => `${e},${t}`, k = (e, t) => ({
	x: e - e % 3,
	y: t - t % 3
}), A = [
	[-1, -1],
	[0, -1],
	[1, -1],
	[-1, 0],
	[1, 0],
	[-1, 1],
	[0, 1],
	[1, 1]
], j = [
	[0, -3],
	[3, 0],
	[0, 3],
	[-3, 0]
];
function ue(e, t, n, r) {
	return t === 1 && n === 1 ? e[0] : e[1 + (([
		[
			0,
			1,
			2
		],
		[
			7,
			-1,
			3
		],
		[
			6,
			5,
			4
		]
	][n][t] - 2 * r) % 8 + 8) % 8];
}
function M(e, t, n, r) {
	return ne[e].map(([e, i]) => {
		let a, o;
		return r % 2 == 0 ? (a = r === 0 ? e : -e, o = r === 0 ? i : -i) : (a = r === 1 ? -i : i, o = r === 1 ? e : -e), {
			x: t + a,
			y: n + o
		};
	});
}
function N(e) {
	let t = e.players.length === 1, n = [];
	for (let r of e.tiles) {
		let e = [[_[r.id][0], _[r.id][1]], [_[r.id][2], _[r.id][3]]];
		for (let t = 0; t < r.rotation; t++) e = [[e[1][0], e[0][0]], [e[1][1], e[0][1]]];
		for (let i = 0; i < 2; i++) for (let a = 0; a < 2; a++) {
			let o = e[a][i], s = o >= 0 && o <= 5;
			n.push({
				x: r.x + 3 * i,
				y: r.y + 3 * a,
				kind: s ? "landmark" : "bonus",
				ref: s ? o : t ? 14 : o,
				rotation: r.rotation
			});
		}
	}
	return n;
}
function P(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of N(e)) {
		let r = null, i = 0;
		if (n.kind === "landmark") r = ae[n.ref], i = n.rotation;
		else {
			let t = e.placedCards.find((e) => e.x === n.x && e.y === n.y);
			t && (r = g[t.id].spaces, i = t.rotation);
		}
		if (r) for (let e = 0; e < 3; e++) for (let a = 0; a < 3; a++) t.set(O(n.x + e, n.y + a), ue(r, e, a, i));
	}
	let n = e.destination, [r, i] = n.rotation === 0 ? [n.x + 1, n.y + 2] : n.rotation === 1 ? [n.x, n.y + 1] : [n.x + 2, n.y + 1];
	return t.set(O(r, i), 15), n.rotation % 2 == 0 ? (t.set(O(r + 3, i), 15), t.set(O(r + 1, i), 14), t.set(O(r + 2, i), 14)) : (t.set(O(r, i + 3), 15), t.set(O(r, i + 1), 14), t.set(O(r, i + 2), 14)), t;
}
function F(e) {
	let t = e.destination, [n, r] = t.rotation === 0 ? [t.x + 1, t.y + 2] : t.rotation === 1 ? [t.x, t.y + 1] : [t.x + 2, t.y + 1];
	return t.rotation % 2 == 0 ? [{
		x: n + 1,
		y: r
	}, {
		x: n + 2,
		y: r
	}] : [{
		x: n,
		y: r + 1
	}, {
		x: n,
		y: r + 2
	}];
}
function I(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e.elephants) t.add(O(n.x, n.y));
	t.add(O(e.matriarch.x, e.matriarch.y));
	for (let n of e.lions) t.add(O(n.x, n.y));
	for (let n of e.landmarks) n.x !== null && t.add(O(n.x, n.y));
	return t;
}
function L(e, t) {
	return e.events ? e.events.active.map((e) => y[e]).filter((e) => e.type === 1 && e.effect === t) : [];
}
var R = (e) => {
	let t = L(e, 4);
	return t.length ? t[0].arg : 2;
}, z = (e) => {
	let t = L(e, 2);
	return t.length ? t[0].arg : 3;
}, B = (e, t) => L(e, 0).some((e) => e.arg === t) ? 2 : 1, V = (e) => L(e, 5).length > 0, H = (e) => L(e, 11).length === 0, U = (e, t, n) => e.get(O(t, n)), W = (e, t, n, r, i) => U(t, n, r) === 3 && !i ? R(e) : 1;
function G(e, t, n) {
	let r = P(e), i = I(e), a = /* @__PURE__ */ new Map(), o = [...e.elephants, e.matriarch];
	for (let s of o) for (let [o, c] of A) {
		let l = s.x + o, u = s.y + c, d = U(r, l, u);
		if (d === void 0 || d === 0 || i.has(O(l, u)) || !e.destinationUnlocked && (d === 14 || d === 15)) continue;
		let f = W(e, r, l, u, n || t === null);
		t !== null && e.players[t].rested < f || a.set(O(l, u), {
			x: l,
			y: u,
			amount: f
		});
	}
	return [...a.values()];
}
function K(e) {
	let t = P(e), n = I(e), r = /* @__PURE__ */ new Set();
	for (let [i, a] of t) {
		if (a !== 4 || n.has(i)) continue;
		let [t, o] = i.split(",").map(Number), s = k(t, o), c = N(e).find((e) => e.x === s.x && e.y === s.y);
		if (!c) continue;
		let l = e.landmarks.find((e) => e.ref === c.ref);
		l && l.x === null && r.add(i);
	}
	return r;
}
function de(e, t, n, r, i, a, o) {
	let s = P(e), c = I(e), l = M(t, n, r, i), u = o && !V(e), d = 0, f = !1;
	for (let t of l) {
		let n = U(s, t.x, t.y);
		if (n === void 0 || n === 0 || c.has(O(t.x, t.y))) return !1;
		(n === 14 || n === 15) && (f = !0), d += n === 3 && !u ? R(e) : 1;
	}
	if (d > a) return !1;
	if (f) {
		let t = K(e), n = new Set(l.map((e) => O(e.x, e.y)));
		for (let e of t) if (!n.has(e)) return !1;
	}
	return !0;
}
function fe(e, t, n) {
	let r = g[n];
	if (!r.pattern) return [];
	let i = e.players[t], a = r.pattern.canBeRotated || e.supportRotate ? [
		0,
		1,
		2,
		3
	] : [i.rotation ?? 0], o = new Set(G(e, null, !1).map((e) => O(e.x, e.y))), s = P(e), c = 0, l = 0;
	for (let t of N(e)) c = Math.max(c, t.x + 2), l = Math.max(l, t.y + 2);
	for (let t of e.destinationCells) c = Math.max(c, t.x), l = Math.max(l, t.y);
	let u = [];
	for (let t = 0; t <= c; t++) for (let n = 0; n <= l; n++) for (let c of a) {
		if (!de(e, r.pattern.shape, t, n, c, i.rested, r.pattern.ignoreRough)) continue;
		let a = M(r.pattern.shape, t, n, c);
		if (!a.some((e) => o.has(O(e.x, e.y)))) continue;
		let l = r.pattern.ignoreRough && !V(e);
		u.push({
			x: t,
			y: n,
			r: c,
			cells: a.map((t) => ({
				...t,
				amount: W(e, s, t.x, t.y, l)
			}))
		});
	}
	return u;
}
function pe(e) {
	return N(e).filter((t) => t.kind === "bonus" && !e.placedCards.some((e) => e.x === t.x && e.y === t.y));
}
function q(e, t, n, r = !1) {
	let i = P(e), a = I(e), o = [];
	for (let e = t; e < t + 3; e++) for (let t = n; t < n + 3; t++) {
		let n = i.get(O(e, t));
		if ((n === void 0 || n === 0) && (r || !a.has(O(e, t))) && (o.push({
			x: e,
			y: t
		}), n === void 0)) return o[0];
	}
	return o.length === 0 ? r ? {
		x: t,
		y: n
	} : q(e, t, n, !0) : o[E(e, o.length)];
}
function J(e, t, n) {
	let r = e.players[t];
	if (n >= 0) {
		let e = Math.min(n, r.tired);
		r.tired -= e, r.rested += e;
	} else {
		let e = Math.min(-n, r.rested);
		r.rested -= e, r.tired += e;
	}
}
function Y(e, t) {
	let n = e.players[t];
	n.rested === 0 && n.tired === 0 && !e.elephants.some((e) => e.seat === t) && (e.loseReason = 4);
}
function X(e, t) {
	let n = e.players[t];
	if (n.rested > 0) n.rested--;
	else if (n.tired > 0) n.tired--;
	else return;
	Y(e, t);
}
function Z(e, t) {
	e.energy - t <= 0 && (t = e.energy, e.loseReason = 2), e.energy -= t;
}
function me(e, t, n) {
	let r = P(e), i = I(e), a = n.map((e) => ({
		...e,
		type: U(r, e.x, e.y)
	}));
	for (let n of a) n.type === 2 && J(e, t, z(e));
	let o = /* @__PURE__ */ new Set();
	for (let t of a) {
		if (t.type === void 0 || !(t.type in te)) continue;
		let n = k(t.x, t.y), a = null;
		for (let [e, i] of A) {
			let o = t.x + e, s = t.y + i;
			if (!(o < n.x || o >= n.x + 3 || s < n.y || s >= n.y + 3) && U(r, o, s) === t.type) {
				a = {
					x: o,
					y: s
				};
				break;
			}
		}
		if (!a || o.has(O(a.x, a.y)) || (o.add(O(t.x, t.y)), !i.has(O(a.x, a.y)))) continue;
		let s = te[t.type];
		e.trees[s] && (e.trees[s] = !1, e.energy = Math.min(12, e.energy + (t.type === 10 ? 2 : B(e, s))));
	}
	let s = /* @__PURE__ */ new Set();
	for (let t of a) {
		if (t.type !== 4) continue;
		let n = k(t.x, t.y), a = N(e).find((e) => e.x === n.x && e.y === n.y);
		if (!a || s.has(a.ref)) continue;
		s.add(a.ref);
		let o = e.landmarks.find((e) => e.ref === a.ref);
		if (!o || o.x !== null) continue;
		let c = !0;
		if (v[a.ref] >= 2) for (let e = 0; e < 3 && c; e++) for (let a = 0; a < 3 && c; a++) {
			let o = n.x + e, s = n.y + a;
			(o !== t.x || s !== t.y) && U(r, o, s) === 4 && !i.has(O(o, s)) && (c = !1);
		}
		if (c) {
			let t = q(e, n.x, n.y);
			o.x = t.x, o.y = t.y;
		}
	}
	if (!e.destinationUnlocked && e.landmarks.every((e) => e.x !== null) && (e.destinationUnlocked = !0), e.destinationUnlocked) {
		let t = a.filter((e) => e.type === 14).length;
		(t === 2 || t === 1 && e.destinationCells.every((e) => i.has(O(e.x, e.y)))) && (e.loseReason = 10);
	}
}
function he(e) {
	let t = e.start.rotation % 4;
	return [...j.slice(t), ...j.slice(0, t)];
}
function ge(e, t, n) {
	return N(e).some((e) => e.x === t && e.y === n);
}
function _e(e, t, n) {
	let r = [{
		...t,
		d: 0
	}], i = /* @__PURE__ */ new Set();
	for (; r.length;) {
		let t = r.shift(), a = O(t.x, t.y);
		if (!i.has(a)) {
			if (t.x === n.x && t.y === n.y) return t.d;
			i.add(a);
			for (let [n, a] of j) {
				let o = t.x + n, s = t.y + a;
				ge(e, o, s) && !i.has(O(o, s)) && r.push({
					x: o,
					y: s,
					d: t.d + 1
				});
			}
		}
	}
	return 999;
}
function ve(e, t) {
	if (!t.standing) {
		t.standing = !0;
		return;
	}
	let n = k(t.x, t.y), r = [...e.elephants.map((e) => k(e.x, e.y)), k(e.matriarch.x, e.matriarch.y)], i = he(e), a = r[0], o = Infinity;
	for (let t of r) {
		if (t.x === n.x && t.y === n.y) {
			a = t;
			break;
		}
		let r = _e(e, t, n);
		if (r < o) o = r, a = t;
		else if (r === o) for (let [e, r] of i) {
			if (n.x + e === t.x && n.y + r === t.y) {
				a = t;
				break;
			}
			if (n.x + e === a.x && n.y + r === a.y) break;
		}
	}
	let s = i.filter(([t, r]) => ge(e, n.x + t, n.y + r)), c = _e(e, n, a), l = s.filter(([t, r]) => _e(e, {
		x: n.x + t,
		y: n.y + r
	}, a) < c), u = l.length ? l[0] : [0, 0], d = q(e, n.x + u[0], n.y + u[1]);
	t.x = d.x, t.y = d.y;
}
function ye(e, t) {
	let n = k(t.x, t.y), r = (e, t) => e >= n.x && e < n.x + 3 && t >= n.y && t < n.y + 3, i = e.elephants.filter((e) => r(e.x, e.y)).length;
	e.elephants = e.elephants.filter((e) => !r(e.x, e.y));
	for (let t = 0; t < e.players.length; t++) Y(e, t);
	let a = r(e.matriarch.x, e.matriarch.y);
	if (a) for (let t = 0; t < e.players.length; t++) X(e, t);
	if ((i > 0 || a) && (t.standing = !1), a && e.lions.length > 1) {
		let [t, n] = e.lions.map((e) => k(e.x, e.y));
		t.x === n.x && t.y === n.y && (e.loseReason = 3);
	}
}
function be(e, t, n) {
	for (let r of e.lions) {
		let i = k(r.x, r.y);
		if (i.x === t && i.y === n) {
			let i = q(e, t, n);
			r.x = i.x, r.y = i.y;
		}
	}
}
function xe(e, t) {
	t.hand = t.hand.filter((t) => g[t].type !== "lion" || (e.discard.push(t), !1));
	for (let t of ["lioness", "lion"]) {
		let n = e.lions.find((e) => e.type === t);
		n && (ve(e, n), ye(e, n));
	}
}
function Se(e, t) {
	let n = y[t];
	switch (n.effect) {
		case 1:
			e.trees[n.arg] = !1;
			break;
		case 3:
			for (let t = 0; t < e.players.length; t++) J(e, t, -2);
			break;
		case 6:
			e.supportTokens > 0 && e.supportTokens--;
			break;
		case 7: {
			let t = e.lions.find((e) => e.type === n.arg);
			t && (ve(e, t), ye(e, t));
			break;
		}
		case 8:
			for (let t = 0; t < e.players.length; t++) X(e, t);
			break;
		case 9:
			for (let t of e.lions) t.standing = !1;
			break;
		case 10: e.energy = Math.min(12, e.energy + 1);
	}
}
function Ce(e, t) {
	if (!e.events) return;
	let n = e.events.deck.pop();
	if (n === void 0) return;
	e.events.active.length > 1 && e.events.active.pop();
	let r = e.events.active[0];
	e.events.active = r === void 0 ? [n] : [n, r], r !== void 0 && t && y[r].type === 0 && Se(e, r), y[n].type === 0 && Se(e, n);
}
function we(e, t, n, r) {
	let i = e.players[t], a = i.hand.filter((e) => g[e].type === "matriarch").length;
	i.hand = i.hand.filter((t) => g[t].type !== "matriarch" || (e.discard.push(t), !1)), n !== null && r !== null && (e.matriarch = {
		x: n,
		y: r
	}, me(e, t, [{
		x: n,
		y: r
	}]));
	for (let t of e.elephants) e.players[t.seat].tired++;
	e.elephants = [];
	for (let t of m) e.trees[t] = !0;
	Z(e, a === 2 ? 5 : 2), Ce(e, !0);
}
var Te = (e) => e.players.length === 1 ? 4 : 3;
function Ee(e, t) {
	let n = e.players[t];
	return !!(n.hand.some((e) => g[e].type === "matriarch") || pe(e).length > 0 || n.rested > 0 && G(e, t, !1).length > 0);
}
function De(e) {
	e.phase = e.loseReason === 10 ? "won" : "lost", e.pending = null;
}
function Q(e) {
	for (;;) {
		if (e.loseReason !== null) return De(e);
		let t = e.players[e.turn.seat], n = Te(e) - t.hand.length;
		for (let r = 0; r < n; r++) {
			let n = e.deck.pop();
			if (n === void 0) {
				e.loseReason = 1;
				break;
			}
			t.hand.push(n);
		}
		if (e.loseReason !== null) continue;
		let r = t.hand.filter((e) => g[e].type === "matriarch").length;
		if (r >= 2) {
			e.pending = e.players.length === 1 && !e.soloDiscarded ? { kind: "soloMatriarch" } : {
				kind: "matriarch",
				count: r
			};
			return;
		}
		if (t.hand.some((e) => g[e].type === "lion")) {
			xe(e, t);
			continue;
		}
		if (e.turn.seat = (e.turn.seat + 1) % e.players.length, e.supportRotate = !1, !Ee(e, e.turn.seat)) {
			e.loseReason = 5;
			continue;
		}
		return;
	}
}
function Oe(e, t, n) {
	let r = t.length === 1, i = e.journey === 0 ? r ? 13 : 1 : e.journey, a = oe[i], o = {
		seed: n,
		cursor: 0,
		config: e,
		seats: [...t],
		phase: "orient",
		loseReason: null,
		journey: i,
		tiles: [],
		start: {
			x: a.start.x,
			y: a.start.y,
			rotation: a.start.rotation,
			flipped: a.start.flipped ?? !1
		},
		destination: a.destination,
		destinationCells: [],
		destinationUnlocked: !1,
		placedCards: [],
		elephants: [],
		matriarch: {
			x: 0,
			y: 0
		},
		lions: [],
		landmarks: [],
		trees: {
			"tree-green": !0,
			"tree-red": !0,
			"tree-brown": !0,
			"tree-teal": !0
		},
		players: t.map((e) => ({
			rid: e,
			rotation: null,
			rested: 0,
			tired: 0,
			hand: []
		})),
		deck: [],
		discard: [],
		events: null,
		energy: re[t.length - 1],
		supportTokens: h[e.difficulty],
		supportRotate: !1,
		soloDiscarded: !1,
		turn: { seat: 0 },
		pending: null,
		passRotate: []
	}, s = D(o, [
		0,
		1,
		2,
		3,
		4,
		5
	]);
	o.tiles = a.tiles.map((e, t) => ({
		id: s[t],
		x: e.x,
		y: e.y,
		rotation: E(o, 4)
	})), o.destinationCells = F(o), o.landmarks = o.tiles.map((e) => ({
		ref: e.id,
		x: null,
		y: null
	}));
	for (let e of ["lion", "lioness"]) {
		let t = a[e];
		if (!t) continue;
		let n = q(o, t.x, t.y);
		o.lions.push({
			type: e,
			x: n.x,
			y: n.y,
			standing: !1
		});
	}
	let [c, l] = o.start.rotation === 0 ? o.start.flipped ? [4, 0] : [1, 0] : o.start.flipped ? [2, 4] : [2, 1];
	o.matriarch = {
		x: o.start.x + c,
		y: o.start.y + l
	}, o.players.forEach((e) => {
		e.tired = ie[t.length - 1];
	}), o.players.forEach((e, t) => J(o, t, 3));
	let u = (e) => g.map((e, t) => ({
		c: e,
		id: t
	})).filter(({ c: t }) => t.deck === e).map(({ id: e }) => e);
	for (let e of [
		3,
		2,
		1
	]) o.deck.push(...D(o, u(e)));
	let d = D(o, u(4)).slice(0, h[e.difficulty]);
	return o.deck.push(...d), e.events && (o.events = {
		deck: D(o, y.map((e, t) => t)),
		active: []
	}, Ce(o, !0), Ce(o, !1)), { state: o };
}
function ke(e) {
	let t = D(e, Ae());
	if (e.players.forEach((n) => {
		for (let r = 0; r < Te(e); r++) {
			let e = t.pop();
			e !== void 0 && n.hand.push(e);
		}
	}), e.phase = "turn", e.loseReason !== null) return De(e);
	if (!Ee(e, e.turn.seat)) return e.loseReason = 5, De(e);
}
var Ae = () => g.map((e, t) => ({
	c: e,
	id: t
})).filter(({ c: e }) => e.deck === 0).map(({ id: e }) => e);
function je(e, t, n) {
	let r = structuredClone(e);
	if (r.phase === "won" || r.phase === "lost") return T("games.tembo.errOver");
	let i = r.seats.indexOf(n.by);
	if (i < 0) return T("games.tembo.errNotPlaying");
	if (r.phase === "orient") return t.type === "orient" ? (r.players[i].rotation = t.rotation, r.players.every((e) => e.rotation !== null) && (r.phase = "reorient"), { state: r }) : T("games.tembo.errPhase");
	if (r.phase === "reorient") {
		if (t.type === "rotateTile") {
			let e = r.tiles[t.tile];
			return e ? (e.rotation = t.rotation, Z(r, 2), ke(r), { state: r }) : T("games.tembo.errCell");
		}
		return t.type === "passRotate" ? (r.passRotate.includes(n.by) || r.passRotate.push(n.by), r.passRotate.length === r.players.length && ke(r), { state: r }) : T("games.tembo.errPhase");
	}
	if (i !== r.turn.seat) return T("games.tembo.errNotYourTurn");
	let a = r.players[i];
	if (r.pending) {
		let e = r.pending;
		switch (e.kind) {
			case "choosePlayer": return t.type === "choosePlayer" ? t.seat === i || t.seat >= r.players.length ? T("games.tembo.errCell") : (J(r, t.seat, e.amount), r.pending = null, Q(r), { state: r }) : T("games.tembo.errPending");
			case "placeSingleFree": {
				if (t.type !== "placeSingleFree") return T("games.tembo.errPending");
				if (!G(r, i, !0).some((e) => e.x === t.x && e.y === t.y)) return T("games.tembo.errCell");
				if (a.rested < 1) return T("games.tembo.errElephants");
				a.rested--, r.elephants.push({
					x: t.x,
					y: t.y,
					seat: i
				}), me(r, i, [{
					x: t.x,
					y: t.y
				}]);
				let n = e.then;
				return r.pending = null, n === "endTurn" ? Q(r) : r.loseReason !== null && De(r), { state: r };
			}
			case "matriarch": return t.type === "matriarch" ? t.x === null != (t.y === null) || t.x !== null && !G(r, null, !0).some((e) => e.x === t.x && e.y === t.y) ? T("games.tembo.errCell") : (r.pending = null, we(r, i, t.x, t.y), Q(r), { state: r }) : T("games.tembo.errPending");
			case "soloMatriarch":
				if (t.type !== "soloMatriarch") return T("games.tembo.errPending");
				if (t.discard) {
					let e = a.hand.filter((e) => g[e].type === "matriarch"), t = e[E(r, e.length)];
					a.hand.splice(a.hand.indexOf(t), 1), r.discard.push(t), r.soloDiscarded = !0, r.pending = null, Q(r);
				} else r.pending = {
					kind: "matriarch",
					count: 2
				};
				return { state: r };
		}
	}
	switch (t.type) {
		case "placeCard": {
			let e = g[t.cardId], n = a.hand.indexOf(t.cardId);
			if (n < 0 || !e?.pattern) return T("games.tembo.errCard");
			let o = pe(r).find((e) => e.x === t.x && e.y === t.y);
			if (!o) return T("games.tembo.errCell");
			if (t.rotation !== a.rotation && !(r.supportRotate || H(r) && e.pattern.canBeRotated)) return T("games.tembo.errRotation");
			switch (a.hand.splice(n, 1), r.placedCards.push({
				id: t.cardId,
				x: t.x,
				y: t.y,
				rotation: t.rotation
			}), be(r, t.x, t.y), o.ref) {
				case 10:
					r.players.forEach((e, t) => J(r, t, 2));
					break;
				case 11:
					r.pending = {
						kind: "choosePlayer",
						amount: 4
					};
					break;
				case 12:
					J(r, i, 5), r.pending = {
						kind: "choosePlayer",
						amount: -2
					};
					break;
				case 13:
					J(r, i, 3), G(r, i, !0).length > 0 && a.rested > 0 && (r.pending = {
						kind: "placeSingleFree",
						then: "endTurn"
					});
					break;
				case 14: J(r, i, 4);
			}
			return r.pending || Q(r), { state: r };
		}
		case "placeElephants": {
			let e = g[t.cardId], n = a.hand.indexOf(t.cardId);
			if (n < 0 || !e?.pattern) return T("games.tembo.errCard");
			if (!(e.pattern.canBeRotated || r.supportRotate ? [
				0,
				1,
				2,
				3
			] : [a.rotation ?? 0]).includes(t.rotation)) return T("games.tembo.errRotation");
			if (!de(r, e.pattern.shape, t.x, t.y, t.rotation, a.rested, e.pattern.ignoreRough)) return T("games.tembo.errCell");
			let o = new Set(G(r, null, !1).map((e) => O(e.x, e.y))), s = M(e.pattern.shape, t.x, t.y, t.rotation);
			if (!s.some((e) => o.has(O(e.x, e.y)))) return T("games.tembo.errCell");
			let c = P(r), l = e.pattern.ignoreRough && !V(r), u = s.reduce((e, t) => e + W(r, c, t.x, t.y, l), 0);
			if (u > a.rested) return T("games.tembo.errElephants");
			a.rested -= u, a.hand.splice(n, 1), r.discard.push(t.cardId);
			for (let e of s) for (let t = 0; t < W(r, c, e.x, e.y, l); t++) r.elephants.push({
				x: e.x,
				y: e.y,
				seat: i
			});
			return me(r, i, s), Q(r), { state: r };
		}
		case "placeSingle": {
			let e = g[t.cardId], n = a.hand.indexOf(t.cardId);
			if (n < 0 || !e?.pattern) return T("games.tembo.errCard");
			let o = e.pattern.ignoreRough, s = G(r, i, o).find((e) => e.x === t.x && e.y === t.y);
			if (!s) return T("games.tembo.errCell");
			a.rested -= s.amount, a.hand.splice(n, 1), r.discard.push(t.cardId);
			for (let e = 0; e < s.amount; e++) r.elephants.push({
				x: t.x,
				y: t.y,
				seat: i
			});
			return me(r, i, [{
				x: t.x,
				y: t.y
			}]), Q(r), { state: r };
		}
		case "support":
			if (r.supportTokens <= 0) return T("games.tembo.errSupport");
			switch (r.supportTokens--, t.option) {
				case 0:
					r.energy = Math.min(12, r.energy + 1);
					break;
				case 1:
					J(r, i, 2);
					break;
				case 2:
					r.supportRotate = !0;
					break;
				case 3: G(r, i, !0).length > 0 && a.rested > 0 && (r.pending = {
					kind: "placeSingleFree",
					then: "continue"
				});
			}
			return { state: r };
		case "matriarch": return a.hand.some((e) => g[e].type === "matriarch") ? t.x === null != (t.y === null) || t.x !== null && !G(r, null, !0).some((e) => e.x === t.x && e.y === t.y) ? T("games.tembo.errCell") : (we(r, i, t.x, t.y), Q(r), { state: r }) : T("games.tembo.errCard");
		default: return T("games.tembo.errPhase");
	}
}
function Me(e, t) {
	let n = P(e), r = {};
	for (let [e, t] of n) r[e] = t;
	let i = {
		phase: e.phase,
		loseReason: e.phase === "lost" ? e.loseReason : null,
		config: e.config,
		journey: e.journey,
		solo: e.players.length === 1,
		energy: e.energy,
		supportTokens: e.supportTokens,
		destinationUnlocked: e.destinationUnlocked,
		tiles: e.tiles.map((e) => ({ ...e })),
		start: { ...e.start },
		destination: { ...e.destination },
		squares: N(e).map((t) => {
			let n = e.placedCards.find((e) => e.x === t.x && e.y === t.y);
			return {
				x: t.x,
				y: t.y,
				kind: t.kind,
				ref: t.ref,
				rotation: t.rotation,
				card: n?.id ?? null,
				cardRotation: n?.rotation ?? null
			};
		}),
		cells: r,
		destinationCells: e.destinationCells.map((e) => ({ ...e })),
		elephants: e.elephants.map((e) => ({ ...e })),
		matriarch: { ...e.matriarch },
		lions: e.lions.map((e) => ({ ...e })),
		landmarks: e.landmarks.map((e) => ({ ...e })),
		trees: { ...e.trees },
		players: e.players.map((t, n) => ({
			rid: t.rid,
			seat: n,
			rotation: t.rotation,
			rested: t.rested,
			tired: t.tired,
			onBoard: e.elephants.filter((e) => e.seat === n).length,
			handCount: t.hand.length,
			matriarchCount: t.hand.filter((e) => g[e].type === "matriarch").length
		})),
		deckCount: e.deck.length,
		discardCount: e.discard.length,
		events: e.events ? e.events.active.map((e, t) => ({
			id: e,
			older: t > 0
		})) : null,
		eventDeckCount: e.events ? e.events.deck.length : 0,
		turn: e.turn.seat,
		supportRotate: e.supportRotate,
		pending: e.pending ? {
			kind: e.pending.kind,
			...e.pending.kind === "choosePlayer" ? { amount: e.pending.amount } : {},
			...e.pending.kind === "matriarch" ? { count: e.pending.count } : {}
		} : null
	}, a = e.players.find((e) => e.rid === t), o = a ? e.players.indexOf(a) : -1, s = {
		hand: a ? [...a.hand] : [],
		patterns: {},
		single: [],
		singleFree: [],
		matriarchTargets: [],
		emptySquares: []
	};
	if (a && e.phase === "turn" && e.turn.seat === o) {
		if (s.emptySquares = pe(e).map((e) => ({
			x: e.x,
			y: e.y
		})), e.pending) e.pending.kind === "placeSingleFree" ? s.singleFree = G(e, o, !0) : e.pending.kind === "matriarch" && (s.matriarchTargets = G(e, null, !0));
		else {
			s.single = G(e, o, !1);
			for (let t of a.hand) {
				if (g[t].type !== "savanna") continue;
				let n = fe(e, o, t);
				n.length && (s.patterns[String(t)] = n);
			}
			a.hand.some((e) => g[e].type === "matriarch") && (s.matriarchTargets = G(e, null, !0));
		}
	}
	return {
		public: i,
		private: s
	};
}
function Ne(e) {
	return e.phase === "won" ? {
		phase: "won",
		winner: e.seats,
		ranking: e.seats
	} : e.phase === "lost" ? {
		phase: "lost",
		winner: [],
		ranking: e.seats
	} : { phase: e.phase };
}
var Pe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: se,
	schemas: {
		action: x,
		publicView: le,
		privateView: w,
		config: S
	},
	setup: Oe,
	reduce: je,
	viewFor: Me,
	status: Ne
}, Fe = (e) => {
	switch (e) {
		case void 0:
		case 0: return "is-none";
		case 2: return "is-water";
		case 3: return "is-rough";
		case 4: return "is-landmark";
		case 10: return "is-tree-green";
		case 11: return "is-tree-red";
		case 12: return "is-tree-brown";
		case 13: return "is-tree-teal";
		case 14: return "is-destination";
		case 15: return "is-destination-normal";
		default: return "is-plain";
	}
}, Ie = (e) => {
	let t = Fe(e);
	return t.startsWith("is-tree-") ? "is-tree" : t;
}, Le = [
	"❄️",
	"🌿",
	"🌊",
	"🪨",
	"🏜️",
	"💧"
], Re = [
	"⬆️",
	"➡️",
	"⬇️",
	"⬅️"
], ze = 44;
function Be(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ f(Ve, {
		pub: t,
		priv: n,
		props: e
	});
}
function Ve({ pub: e, priv: t, props: ee }) {
	let m = o(), { members: ne, myRid: re, send: h } = ee, [ie, _] = a(null), [v, ae] = a(null), [y, oe] = a(0), [b, x] = a(null), [S, C] = a(null), [ce, le] = a(!1), [w, T] = a("near"), [E, D] = a({
		w: 375,
		h: 450
	}), O = i(null), k = e.players.findIndex((e) => e.rid === re), A = k >= 0 ? e.players[k] : null, j = e.phase === "turn" && e.turn === k, ue = (e) => ne.find((t) => t.rid === e), M = (e) => ue(e)?.name ?? e, N = (e) => {
		let t = ue(e);
		return t ? s[t.colorIndex % s.length].hex : "#888";
	}, P = t?.hand ?? [], F = ie !== null && P.includes(ie) ? ie : null, I = F === null ? null : g[F], L = !!I?.pattern && (e.supportRotate || I.pattern.canBeRotated), R = r(() => {
		let n = new Map((t?.single ?? []).map((e) => [`${e.x},${e.y}`, e]));
		if (!I?.pattern?.ignoreRough || !A?.rested) return [...n.values()];
		let r = /* @__PURE__ */ new Set([
			...e.elephants.map((e) => `${e.x},${e.y}`),
			...e.lions.map((e) => `${e.x},${e.y}`),
			...e.landmarks.filter((e) => e.x !== null).map((e) => `${e.x},${e.y}`),
			`${e.matriarch.x},${e.matriarch.y}`
		]);
		for (let t of [...e.elephants, e.matriarch]) for (let i = -1; i <= 1; i++) for (let a = -1; a <= 1; a++) {
			if (i === 0 && a === 0) continue;
			let o = t.x + i, s = t.y + a, c = `${o},${s}`;
			e.cells[c] === 3 && !r.has(c) && n.set(c, {
				x: o,
				y: s,
				amount: 1
			});
		}
		return [...n.values()];
	}, [
		t?.single,
		I?.pattern?.ignoreRough,
		A?.rested,
		e.elephants,
		e.lions,
		e.landmarks,
		e.matriarch,
		e.cells
	]), z = r(() => {
		let n = /* @__PURE__ */ new Map();
		if (e.phase !== "turn" || !j || !t) return n;
		let r = e.pending;
		if (r?.kind === "placeSingleFree") {
			for (let e of t.singleFree) n.set(`${e.x},${e.y}`, "cell");
			return n;
		}
		if (r?.kind === "matriarch") {
			for (let e of t.matriarchTargets) n.set(`${e.x},${e.y}`, "cell");
			return n;
		}
		if (r) return n;
		if (v === "build" && F !== null) for (let e of t.emptySquares) n.set(`${e.x},${e.y}`, "square");
		else if (v === "footprint" && F !== null) for (let e of t.patterns[String(F)] ?? []) e.r === y && n.set(`${e.x},${e.y}`, "anchor");
		else if (v === "single" && F !== null) for (let e of R) n.set(`${e.x},${e.y}`, "cell");
		else if (v === "matriarch" && F !== null) for (let e of t.matriarchTargets) n.set(`${e.x},${e.y}`, "cell");
		return n;
	}, [
		e.phase,
		e.pending,
		j,
		t,
		v,
		F,
		y,
		R
	]), B = r(() => {
		let t = Infinity, n = Infinity, r = -Infinity, i = -Infinity, a = (e, a) => {
			t = Math.min(t, e), n = Math.min(n, a), r = Math.max(r, e), i = Math.max(i, a);
		};
		for (let t of Object.keys(e.cells)) {
			let [e, n] = t.split(",").map(Number);
			a(e, n);
		}
		for (let t of e.squares) a(t.x, t.y), a(t.x + 2, t.y + 2);
		return a(e.start.x, e.start.y), a(e.start.x + (e.start.rotation % 2 == 0 ? 5 : 2), e.start.y + (e.start.rotation % 2 == 0 ? 2 : 5)), a(e.matriarch.x, e.matriarch.y), {
			minX: t,
			minY: n,
			w: r - t + 1,
			h: i - n + 1
		};
	}, [e]), V = E.w >= 600 && E.h >= 340 ? Math.max(ze, Math.min(88, E.w / 14, E.h / 8)) : ze, H = w === "near" ? V : Math.max(5, Math.min((E.w - 16) / B.w, (E.h - 16) / B.h)), U = w === "near" ? E.w / 2 : 0, W = w === "near" ? E.h / 2 : 0, G = b && v === "footprint" && F !== null ? (t?.patterns[String(F)] ?? []).find((e) => e.x === b.x && e.y === b.y && e.r === y) : void 0;
	n(() => {
		let e = O.current;
		if (!e) return;
		let t = new ResizeObserver(() => D({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []), n(() => {
		let t = O.current;
		t && w === "near" && t.scrollTo({
			left: U + (e.matriarch.x - B.minX + .5) * H - t.clientWidth / 2,
			top: W + (e.matriarch.y - B.minY + .5) * H - t.clientHeight / 2
		});
	}, [
		w,
		B.minX,
		B.minY,
		H,
		U,
		W,
		e.matriarch.x,
		e.matriarch.y
	]);
	let K = (t) => {
		ae(t), x(null), T("near"), O.current?.scrollTo({
			left: U + (e.matriarch.x - B.minX + .5) * V - O.current.clientWidth / 2,
			top: W + (e.matriarch.y - B.minY + .5) * V - O.current.clientHeight / 2
		});
	}, de = (e, t) => {
		j && w !== "all" && z.get(`${e},${t}`) && x({
			x: e,
			y: t
		});
	}, fe = (t, n) => {
		j && w !== "all" && !e.pending && v === "build" && F !== null && z.get(`${t},${n}`) === "square" && x({
			x: t,
			y: n
		});
	}, pe = (e, t) => {
		(e.key === "Enter" || e.key === " ") && (e.preventDefault(), t());
	}, q = () => {
		if (!b || !j) return;
		let t = `${b.x},${b.y}`;
		if (!z.has(t)) return;
		let n = null;
		e.pending?.kind === "placeSingleFree" ? n = {
			type: "placeSingleFree",
			x: b.x,
			y: b.y
		} : e.pending?.kind === "matriarch" ? n = {
			type: "matriarch",
			x: b.x,
			y: b.y
		} : !e.pending && v === "build" && F !== null && z.get(t) === "square" ? n = {
			type: "placeCard",
			cardId: F,
			x: b.x,
			y: b.y,
			rotation: L ? y : A?.rotation ?? 0
		} : !e.pending && v === "footprint" && F !== null && G ? n = {
			type: "placeElephants",
			cardId: F,
			x: b.x,
			y: b.y,
			rotation: y
		} : !e.pending && v === "single" && F !== null ? n = {
			type: "placeSingle",
			cardId: F,
			x: b.x,
			y: b.y
		} : !e.pending && v === "matriarch" && F !== null && (n = {
			type: "matriarch",
			x: b.x,
			y: b.y
		}), n && (h(n), _(null), ae(null), x(null));
	}, J = /* @__PURE__ */ p("div", {
		className: "tembo-banner flex flex-col gap-1",
		children: [/* @__PURE__ */ f(c, {
			tone: e.phase === "won" ? "done" : e.phase === "lost" ? "warn" : j || e.phase === "orient" || e.phase === "reorient" ? "accent" : "info",
			accent: se.accent,
			text: e.phase === "won" ? m("games.tembo.winText") : e.phase === "lost" ? m(`games.tembo.lose${e.loseReason}`) : e.phase === "orient" ? m("games.tembo.orientTitle") : e.phase === "reorient" ? m("games.tembo.reorientTitle") : j ? m("games.tembo.turnYou") : m("games.tembo.turnWait", { name: M(e.players[e.turn]?.rid ?? "") })
		}), /* @__PURE__ */ p("div", {
			className: "tembo-status-wrap",
			children: [/* @__PURE__ */ p("div", {
				className: "tembo-resource-rail",
				children: [
					/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p("div", {
						className: "tembo-energy-label",
						children: [/* @__PURE__ */ f("span", { children: m("games.tembo.energyLabel") }), /* @__PURE__ */ p("strong", {
							className: "font-mono",
							children: [e.energy, " / 12"]
						})]
					}), /* @__PURE__ */ f("div", {
						className: "tembo-energy-track",
						"aria-hidden": !0,
						children: Array.from({ length: 12 }, (t, n) => /* @__PURE__ */ f("i", { className: n < e.energy ? "is-filled" : "" }, n))
					})] }),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "tembo-resource-chip",
						disabled: !j || !!e.pending || e.supportTokens <= 0,
						onClick: () => le(!0),
						children: [/* @__PURE__ */ f("span", { children: m("games.tembo.supportLabel") }), /* @__PURE__ */ f("strong", {
							className: "font-mono",
							children: e.supportTokens
						})]
					}),
					/* @__PURE__ */ p("div", {
						className: "tembo-resource-chip",
						children: [/* @__PURE__ */ f("span", { children: m("games.tembo.deckLabel") }), /* @__PURE__ */ f("strong", {
							className: "font-mono",
							children: e.deckCount
						})]
					})
				]
			}), /* @__PURE__ */ p("div", {
				className: "tembo-player-rail",
				children: [e.players.map((t) => /* @__PURE__ */ p("div", {
					className: `tembo-player-chip ${t.seat === e.turn && e.phase === "turn" ? "is-active" : ""}`,
					children: [
						/* @__PURE__ */ f("i", {
							className: "tembo-player-dot",
							style: { background: N(t.rid) }
						}),
						M(t.rid),
						" · ",
						t.rested,
						"/",
						t.tired,
						" ",
						t.rotation !== null && Re[t.rotation]
					]
				}, t.rid)), e.supportRotate && /* @__PURE__ */ p("span", {
					className: "tembo-player-chip",
					children: ["↻ ", m("games.tembo.supportRotateOn")]
				})]
			})]
		})]
	}), Y = (e) => U + (e - B.minX) * H, X = (e) => W + (e - B.minY) * H, Z = [];
	for (let t of e.squares) {
		let e = t.kind === "bonus" && t.card === null, n = e && z.get(`${t.x},${t.y}`) === "square", r = n && w === "near", i = b?.x === t.x && b.y === t.y;
		Z.push(/* @__PURE__ */ p("div", {
			onClick: r ? () => fe(t.x, t.y) : void 0,
			onKeyDown: r ? (e) => pe(e, () => fe(t.x, t.y)) : void 0,
			role: r ? "button" : void 0,
			tabIndex: r ? 0 : void 0,
			"aria-label": r ? m(`games.tembo.bonus${t.ref}`) : void 0,
			className: `tembo-square ${e ? "is-bonus is-empty" : ""} ${n ? "is-legal" : ""} ${i ? "is-target" : ""}`,
			style: {
				left: Y(t.x),
				top: X(t.y),
				width: 3 * H,
				height: 3 * H
			},
			children: [t.kind === "landmark" && /* @__PURE__ */ f("span", {
				className: "tembo-landmark-tag",
				children: m(`games.tembo.landmark${t.ref}`)
			}), e && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", {
				className: "tembo-square-rings",
				children: Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ f("i", {}, t))
			}), /* @__PURE__ */ f("span", {
				className: "tembo-square-label",
				children: m(`games.tembo.bonus${t.ref}`)
			})] })]
		}, `sq-${t.x}-${t.y}`));
	}
	let me = e.start.rotation % 2 == 0 ? 6 : 3, he = e.start.rotation % 2 == 0 ? 3 : 6;
	Z.push(/* @__PURE__ */ f("div", {
		className: "tembo-start",
		style: {
			left: Y(e.start.x),
			top: X(e.start.y),
			width: me * H,
			height: he * H
		}
	}, "start")), Z.push(/* @__PURE__ */ f("div", {
		className: "tembo-start-label",
		style: {
			left: Y(e.start.x) + 5,
			top: X(e.start.y) - 9
		},
		children: "START"
	}, "start-label"));
	for (let [t, n] of Object.entries(e.cells)) {
		let [r, i] = t.split(",").map(Number), a = z.get(t), o = a === "cell" || a === "anchor", s = o && w === "near", c = b?.x === r && b.y === i, l = v === "single" ? R.find((e) => e.x === r && e.y === i)?.amount : void 0, u = n in te ? te[n] : null, d = u ? e.trees[u] : !1, ee = (n === 14 || n === 15) && !e.destinationUnlocked;
		Z.push(/* @__PURE__ */ p("div", {
			onClick: s ? () => de(r, i) : void 0,
			onKeyDown: s ? (e) => pe(e, () => de(r, i)) : void 0,
			role: s ? "button" : void 0,
			tabIndex: s ? 0 : void 0,
			"aria-label": s ? `${m("games.tembo.pickCell")} ${r}, ${i}` : void 0,
			className: `tembo-cell ${Fe(n)} ${ee ? "is-locked" : ""} ${o ? "is-legal" : ""} ${c ? "is-target" : ""}`,
			style: {
				left: Y(r),
				top: X(i),
				width: H,
				height: H
			},
			children: [
				u && /* @__PURE__ */ f("span", {
					className: `tembo-cell-icon tembo-tree ${d ? "" : "is-fallen"}`,
					title: m(d ? "games.tembo.treeStanding" : "games.tembo.treeFallen"),
					children: d ? "🌳" : "🪵"
				}),
				n === 4 && /* @__PURE__ */ f("span", {
					className: "tembo-cell-icon",
					children: "★"
				}),
				n === 2 && /* @__PURE__ */ f("span", {
					className: "tembo-cell-icon",
					children: "≈"
				}),
				ee ? /* @__PURE__ */ f("span", {
					className: "tembo-cell-icon",
					title: m("games.tembo.destinationLocked"),
					children: "🔒"
				}) : n === 14 && /* @__PURE__ */ f("span", {
					className: "tembo-cell-icon",
					children: "★"
				}),
				l && /* @__PURE__ */ f("span", {
					className: "tembo-cell-cost",
					children: l
				})
			]
		}, t));
	}
	if (G) for (let e of G.cells) Z.push(/* @__PURE__ */ f("div", {
		className: "tembo-cell tembo-preview",
		style: {
			left: Y(e.x) + 4,
			top: X(e.y) + 4,
			width: H - 8,
			height: H - 8
		},
		children: e.amount
	}, `preview-${e.x}-${e.y}`));
	if (e.phase === "reorient") for (let t = 0; t < e.tiles.length; t++) {
		let n = e.tiles[t];
		Z.push(/* @__PURE__ */ f("button", {
			type: "button",
			className: `tembo-tile-choice ${S === t ? "is-target" : ""}`,
			style: {
				left: Y(n.x),
				top: X(n.y),
				width: 6 * H,
				height: 6 * H
			},
			onClick: () => C(t),
			"aria-label": `${m("games.tembo.rotateThis")} ${t + 1}`
		}, `rotate-${t}`));
	}
	for (let t of e.landmarks) t.x !== null && Z.push(/* @__PURE__ */ f("div", {
		className: "tembo-piece",
		style: {
			left: Y(t.x),
			top: X(t.y),
			width: H,
			height: H
		},
		children: /* @__PURE__ */ f("span", {
			className: "tembo-matriarch",
			children: Le[t.ref]
		})
	}, `lm-${t.ref}`));
	e.elephants.forEach((t, n) => {
		let r = e.players[t.seat]?.rid ?? "";
		Z.push(/* @__PURE__ */ f("div", {
			className: "tembo-piece",
			style: {
				left: Y(t.x),
				top: X(t.y),
				width: H,
				height: H
			},
			children: /* @__PURE__ */ p("span", {
				className: "tembo-meeple",
				style: { "--tembo-player": N(r) },
				children: ["🐘", /* @__PURE__ */ f("small", { children: M(r).slice(0, 1) })]
			})
		}, `e${n}`));
	}), Z.push(/* @__PURE__ */ f("div", {
		className: "tembo-piece",
		style: {
			left: Y(e.matriarch.x),
			top: X(e.matriarch.y),
			width: H,
			height: H
		},
		children: /* @__PURE__ */ f("span", {
			className: "tembo-matriarch",
			children: "👑"
		})
	}, "m")), e.lions.forEach((e) => {
		Z.push(/* @__PURE__ */ f("div", {
			className: "tembo-piece",
			style: {
				left: Y(e.x),
				top: X(e.y),
				width: H,
				height: H
			},
			children: /* @__PURE__ */ f("span", {
				className: `tembo-lion ${e.standing ? "" : "is-down"}`,
				children: e.type === "lion" ? "🦁" : "🐆"
			})
		}, e.type));
	});
	let ge = /* @__PURE__ */ p("div", {
		className: `tembo-board-frame ${w === "all" ? "is-overview" : ""}`,
		children: [
			/* @__PURE__ */ f(u, {
				kind: "sheen",
				base: "#e7cb91",
				className: "absolute inset-0"
			}),
			/* @__PURE__ */ f("div", {
				ref: O,
				className: "tembo-board-scroll",
				children: /* @__PURE__ */ f("div", {
					className: "tembo-board-world",
					style: {
						width: B.w * H + 2 * U,
						height: B.h * H + 2 * W
					},
					children: Z
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "tembo-board-toolbar",
				children: [/* @__PURE__ */ f("span", {
					className: "tembo-journey-chip",
					children: m("games.tembo.journeyProgress", { n: e.landmarks.filter((e) => e.x !== null).length })
				}), /* @__PURE__ */ f("button", {
					type: "button",
					className: "tembo-map-button",
					onClick: () => T(w === "near" ? "all" : "near"),
					children: m(w === "near" ? "games.tembo.mapOverview" : "games.tembo.mapFocus")
				})]
			}),
			e.events?.map((e, t) => /* @__PURE__ */ f("span", {
				className: `tembo-event-chip ${e.older ? "is-older" : ""}`,
				title: m(`games.tembo.ev${e.id}`),
				children: m(`games.tembo.ev${e.id}`)
			}, `${e.id}-${t}`))
		]
	}), _e = G?.cells.reduce((e, t) => e + t.amount, 0), ve = e.phase === "orient" ? m("games.tembo.orientHint") : e.phase === "reorient" ? m("games.tembo.reorientHintShort") : e.phase === "won" || e.phase === "lost" ? m(e.phase === "won" ? "games.tembo.winText" : `games.tembo.lose${e.loseReason}`) : j ? e.pending?.kind === "placeSingleFree" || e.pending?.kind === "matriarch" ? m("games.tembo.pickCell") : v && z.size === 0 ? m("games.tembo.noTargets") : m(v === "build" ? "games.tembo.pickSquare" : v === "footprint" || v === "single" || v === "matriarch" ? "games.tembo.pickCell" : "games.tembo.selectCardHint") : m("games.tembo.waitHint"), ye = /* @__PURE__ */ p("div", {
		className: "tembo-actions",
		children: [
			e.phase === "orient" && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("div", {
					className: "tembo-actions-title",
					children: m("games.tembo.orientTitle")
				}),
				/* @__PURE__ */ f("div", {
					className: "tembo-actions-hint",
					children: A?.rotation === null ? m("games.tembo.orientHint") : m("games.tembo.orientDone")
				}),
				/* @__PURE__ */ f("div", {
					className: "tembo-phase-row",
					children: Re.map((e, t) => /* @__PURE__ */ p("button", {
						type: "button",
						className: `tembo-action-button ${A?.rotation === t ? "is-selected" : ""}`,
						onClick: () => h({
							type: "orient",
							rotation: t
						}),
						children: [
							e,
							" ",
							m(`games.tembo.dir${t}`)
						]
					}, t))
				}),
				/* @__PURE__ */ f("div", {
					className: "tembo-choice-note",
					children: m("games.tembo.orientHint")
				})
			] }),
			e.phase === "reorient" && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("div", {
					className: "tembo-actions-title",
					children: m("games.tembo.reorientTitle")
				}),
				/* @__PURE__ */ f("div", {
					className: "tembo-actions-hint",
					children: m("games.tembo.reorientHintShort")
				}),
				/* @__PURE__ */ f("div", {
					className: "tembo-phase-row",
					children: e.tiles.map((e, t) => /* @__PURE__ */ p("button", {
						type: "button",
						className: `tembo-action-button ${S === t ? "is-selected" : ""}`,
						onClick: () => C(t),
						children: [
							Le[e.id],
							" ",
							m(`games.tembo.landmark${e.id}`)
						]
					}, t))
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-action-row",
					children: [/* @__PURE__ */ f("button", {
						type: "button",
						className: "tembo-action-button is-primary",
						disabled: S === null,
						onClick: () => {
							if (S === null) return;
							let t = e.tiles[S];
							h({
								type: "rotateTile",
								tile: S,
								rotation: (t.rotation + 1) % 4
							}), C(null);
						},
						children: m("games.tembo.confirmRotate")
					}), /* @__PURE__ */ f("button", {
						type: "button",
						className: "tembo-action-button",
						onClick: () => h({ type: "passRotate" }),
						children: m("games.tembo.passRotate")
					})]
				})
			] }),
			e.phase === "turn" && j && e.pending?.kind === "choosePlayer" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("div", {
				className: "tembo-actions-title",
				children: m(e.pending.amount > 0 ? "games.tembo.chooseGain" : "games.tembo.chooseLose", { n: Math.abs(e.pending.amount) })
			}), /* @__PURE__ */ f("div", {
				className: "tembo-phase-row",
				children: e.players.filter((e) => e.seat !== k).map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					className: "tembo-action-button",
					onClick: () => h({
						type: "choosePlayer",
						seat: e.seat
					}),
					children: M(e.rid)
				}, e.rid))
			})] }),
			e.phase === "turn" && j && (e.pending?.kind === "placeSingleFree" || e.pending?.kind === "matriarch") && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("div", {
					className: "tembo-actions-title",
					children: m(e.pending.kind === "placeSingleFree" ? "games.tembo.freePlace" : "games.tembo.matriarchForced")
				}),
				/* @__PURE__ */ f("div", {
					className: "tembo-actions-hint",
					children: m("games.tembo.pickCell")
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-action-row",
					children: [/* @__PURE__ */ f("button", {
						type: "button",
						className: "tembo-action-button is-primary",
						disabled: !b,
						onClick: q,
						children: m("games.tembo.confirmPlace")
					}), e.pending.kind === "matriarch" && /* @__PURE__ */ f("button", {
						type: "button",
						className: "tembo-action-button",
						onClick: () => {
							h({
								type: "matriarch",
								x: null,
								y: null
							}), x(null);
						},
						children: m("games.tembo.matriarchStay")
					})]
				})
			] }),
			e.phase === "turn" && j && e.pending?.kind === "soloMatriarch" && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("div", {
					className: "tembo-actions-title",
					children: m("games.tembo.soloMatriarchTitle")
				}),
				/* @__PURE__ */ f("div", {
					className: "tembo-actions-hint",
					children: m("games.tembo.soloMatriarchHint")
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-action-row",
					children: [/* @__PURE__ */ f("button", {
						type: "button",
						className: "tembo-action-button is-primary",
						onClick: () => h({
							type: "soloMatriarch",
							discard: !0
						}),
						children: m("games.tembo.soloDiscard")
					}), /* @__PURE__ */ f("button", {
						type: "button",
						className: "tembo-action-button",
						onClick: () => h({
							type: "soloMatriarch",
							discard: !1
						}),
						children: m("games.tembo.soloKeep")
					})]
				})
			] }),
			e.phase === "turn" && j && !e.pending && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ p("div", {
					className: "tembo-actions-title",
					children: [/* @__PURE__ */ p("span", { children: [
						m("games.tembo.yourHand"),
						" ",
						P.length
					] }), /* @__PURE__ */ f("span", { children: _e ? m("games.tembo.costElephants", { n: _e }) : "" })]
				}),
				/* @__PURE__ */ f("div", {
					className: "tembo-hand",
					children: P.map((e) => {
						let t = g[e], n = F === e;
						return /* @__PURE__ */ p("button", {
							type: "button",
							className: `tembo-card ${n ? "is-selected" : ""}`,
							onClick: () => {
								_(n ? null : e), ae(null), x(null), oe(A?.rotation ?? 0);
							},
							children: [/* @__PURE__ */ f("span", {
								className: "tembo-card-name",
								children: m(t.type === "savanna" ? "games.tembo.savannaCard" : t.type === "matriarch" ? "games.tembo.matriarch" : "games.tembo.lionCard")
							}), t.type === "savanna" && t.spaces ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("span", {
								className: "tembo-card-pattern",
								children: [qe(t.pattern.shape), t.pattern.canBeRotated ? "↻" : ""]
							}), /* @__PURE__ */ f("span", {
								className: "tembo-card-grid",
								children: He.map((e, n) => /* @__PURE__ */ f("i", { className: Ie(t.spaces[e]) }, n))
							})] }) : /* @__PURE__ */ f("span", {
								className: "tembo-card-figure",
								children: t.type === "matriarch" ? "👑" : "🦁"
							})]
						}, e);
					})
				}),
				/* @__PURE__ */ f("div", {
					className: "tembo-actions-hint",
					children: F === null ? m("games.tembo.selectCardHint") : b ? m("games.tembo.confirmHint") : v ? ve : m("games.tembo.chooseActionHint")
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-action-row",
					children: [
						F === null && /* @__PURE__ */ f("div", {
							className: "tembo-empty-action",
							children: m("games.tembo.selectCardHint")
						}),
						F !== null && b && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
							type: "button",
							className: "tembo-action-button is-primary",
							onClick: q,
							children: m(v === "footprint" || v === "single" ? "games.tembo.confirmElephants" : "games.tembo.confirmPlace")
						}), /* @__PURE__ */ f("button", {
							type: "button",
							className: "tembo-action-button",
							onClick: () => x(null),
							children: m("games.tembo.changeTarget")
						})] }),
						F !== null && !b && I?.type === "savanna" && /* @__PURE__ */ p(d, { children: [
							/* @__PURE__ */ f("button", {
								type: "button",
								className: `tembo-action-button ${v === "build" ? "is-selected" : ""}`,
								disabled: !t?.emptySquares.length,
								onClick: () => K("build"),
								children: m("games.tembo.build")
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								className: `tembo-action-button ${v === "footprint" ? "is-selected" : ""}`,
								disabled: !(t?.patterns[String(F)] ?? []).some((e) => e.r === y),
								onClick: () => K("footprint"),
								children: m("games.tembo.elephants")
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								className: `tembo-action-button ${v === "single" ? "is-selected" : ""}`,
								disabled: !R.length,
								onClick: () => K("single"),
								children: m("games.tembo.single")
							}),
							L && /* @__PURE__ */ p("button", {
								type: "button",
								className: "tembo-action-button",
								onClick: () => {
									oe((y + 1) % 4), x(null);
								},
								"aria-label": m("games.tembo.rotateThis"),
								children: ["↻ ", Re[y]]
							})
						] }),
						F !== null && !b && I?.type === "matriarch" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
							type: "button",
							className: "tembo-action-button is-primary",
							onClick: () => K("matriarch"),
							children: m("games.tembo.matriarch")
						}), /* @__PURE__ */ f("button", {
							type: "button",
							className: "tembo-action-button",
							onClick: () => {
								h({
									type: "matriarch",
									x: null,
									y: null
								}), _(null), ae(null);
							},
							children: m("games.tembo.matriarchStay")
						})] })
					]
				})
			] }),
			e.phase === "turn" && !j && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("div", {
				className: "tembo-actions-title",
				children: m("games.tembo.turnWait", { name: M(e.players[e.turn]?.rid ?? "") })
			}), /* @__PURE__ */ f("div", {
				className: "tembo-choice-note",
				children: m("games.tembo.waitHint")
			})] })
		]
	});
	return /* @__PURE__ */ p("div", {
		className: "tembo-screen",
		children: [/* @__PURE__ */ f(l, {
			adaptive: !0,
			className: "tembo-layout",
			banner: J,
			actions: ye,
			actionsHeight: "tembo-action-slot h-[218px] short:h-[116px]",
			scroll: !1,
			overlay: /* @__PURE__ */ f("div", {
				className: "tembo-board-hint",
				children: ve
			}),
			children: ge
		}), ce && j && !e.pending && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("div", {
			className: "tembo-support-backdrop",
			onClick: () => le(!1)
		}), /* @__PURE__ */ p("div", {
			className: "tembo-support-sheet",
			children: [
				/* @__PURE__ */ p("div", {
					className: "tembo-support-head",
					children: [/* @__PURE__ */ f("span", { children: m("games.tembo.supportTitle") }), /* @__PURE__ */ f("span", { children: m("games.tembo.support", { n: e.supportTokens }) })]
				}),
				/* @__PURE__ */ f("div", {
					className: "tembo-support-options",
					children: Ue.map((e, t) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "tembo-support-option",
						onClick: () => {
							h({
								type: "support",
								option: t
							}), le(!1), x(null);
						},
						children: [/* @__PURE__ */ f("span", {
							className: "tembo-support-symbol",
							children: Ge[t]
						}), /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("strong", { children: m(e) }), /* @__PURE__ */ f("small", { children: m(We[t]) })] })]
					}, e))
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "tembo-action-button mt-3 w-full",
					onClick: () => le(!1),
					children: m("games.tembo.cancel")
				})
			]
		})] })]
	});
}
var He = [
	1,
	2,
	3,
	8,
	0,
	4,
	7,
	6,
	5
], Ue = [
	"games.tembo.supportEnergy",
	"games.tembo.supportElephants",
	"games.tembo.supportRotate",
	"games.tembo.supportPlace"
], We = [
	"games.tembo.supportHint0",
	"games.tembo.supportHint1",
	"games.tembo.supportHint2",
	"games.tembo.supportHint3"
], Ge = [
	"✦",
	"🐘",
	"↻",
	"⌾"
], Ke = {
	0: "╲",
	1: "╱",
	2: "┃",
	3: "━",
	4: "☷",
	5: "☰",
	6: "∟"
}, qe = (e) => Ke[e] ?? "·", Je = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32, Ye = (e) => e[Math.floor(Je() * e.length)], $ = (e, t) => `${e},${t}`;
function Xe(e) {
	let t = new Set(e.landmarks.filter((e) => e.x === null).map((e) => e.ref)), n = new Map(e.squares.filter((e) => e.kind === "landmark" && t.has(e.ref)).map((e) => [$(e.x, e.y), e.ref])), r = /* @__PURE__ */ new Set([...e.elephants.map((e) => $(e.x, e.y)), $(e.matriarch.x, e.matriarch.y)]), i = (e, t) => $(Math.floor(e / 3) * 3, Math.floor(t / 3) * 3), a = /* @__PURE__ */ new Map();
	for (let t of e.elephants) {
		let e = i(t.x, t.y);
		a.set(e, (a.get(e) ?? 0) + 1);
	}
	let o = (t, n, a) => {
		let o = i(t, n);
		for (let s of [
			-1,
			0,
			1
		]) for (let c of [
			-1,
			0,
			1
		]) {
			if (!s && !c) continue;
			let l = t + s, u = n + c;
			if (i(l, u) === o && e.cells[$(l, u)] === a && r.has($(l, u))) return !0;
		}
		return !1;
	};
	return (t, r) => {
		let s = e.cells[$(t, r)];
		if (s === void 0) return 0;
		let c = 1;
		if (e.destinationUnlocked && (s === 14 || s === 15)) c = 100;
		else if (s === 4 && n.has(i(t, r))) {
			let e = n.get(i(t, r));
			c = 20 + 6 * (4 - Math.min(v[e] ?? 4, 4)) + 8 * (a.get(i(t, r)) ?? 0);
		} else s in te && o(t, r, s) ? c = 10 : s === 2 && (c = 4);
		return s === 3 && --c, c;
	};
}
function Ze(e, t, n, r) {
	let i = e.players[n], a = e.pending;
	if (a) switch (a.kind) {
		case "choosePlayer": {
			let t = e.players.filter((e) => e.seat !== n);
			if (!t.length) return null;
			let i = (a.amount ?? 0) > 0, o = [...t].sort((e, t) => (i ? 1 : -1) * (e.rested + e.onBoard - (t.rested + t.onBoard)));
			return {
				type: "choosePlayer",
				seat: r ? Ye(t).seat : o[0].seat
			};
		}
		case "placeSingleFree": {
			if (!t.singleFree.length) return null;
			if (r) return {
				type: "placeSingleFree",
				...Ye(t.singleFree)
			};
			let n = Xe(e), i = [...t.singleFree].sort((e, t) => n(t.x, t.y) - n(e.x, e.y))[0];
			return {
				type: "placeSingleFree",
				x: i.x,
				y: i.y
			};
		}
		case "matriarch": {
			if (!t.matriarchTargets.length) return {
				type: "matriarch",
				x: null,
				y: null
			};
			let n = Xe(e), r = [...t.matriarchTargets].sort((e, t) => n(t.x, t.y) - n(e.x, e.y))[0];
			return n(r.x, r.y) >= 4 ? {
				type: "matriarch",
				x: r.x,
				y: r.y
			} : {
				type: "matriarch",
				x: null,
				y: null
			};
		}
		case "soloMatriarch": return {
			type: "soloMatriarch",
			discard: !0
		};
	}
	let o = t.hand, s = o.filter((e) => g[e].type === "matriarch"), c = o.filter((e) => g[e].type === "savanna");
	if (r) {
		let e = [];
		for (let n of t.emptySquares) c.length && e.push({
			type: "placeCard",
			cardId: c[0],
			x: n.x,
			y: n.y,
			rotation: i.rotation ?? 0
		});
		for (let [n, r] of Object.entries(t.patterns)) for (let t of r) e.push({
			type: "placeElephants",
			cardId: Number(n),
			x: t.x,
			y: t.y,
			rotation: t.r
		});
		for (let n of t.single) c.length && e.push({
			type: "placeSingle",
			cardId: c[0],
			x: n.x,
			y: n.y
		});
		return s.length && e.push({
			type: "matriarch",
			x: null,
			y: null
		}), e.length ? Ye(e) : null;
	}
	if (e.energy <= 4 && e.supportTokens > 0) return {
		type: "support",
		option: 0
	};
	let l = Xe(e);
	if (s.length === 1) {
		let e = t.matriarchTargets.length ? [...t.matriarchTargets].sort((e, t) => l(t.x, t.y) - l(e.x, e.y))[0] : null, n = e ? l(e.x, e.y) : 0;
		if (n >= 8 && i.onBoard <= 4 || i.onBoard <= 2) return n >= 4 && e ? {
			type: "matriarch",
			x: e.x,
			y: e.y
		} : {
			type: "matriarch",
			x: null,
			y: null
		};
	}
	let u = {
		12: 5,
		13: 4,
		11: 3,
		10: 2,
		14: 3
	};
	if (c.length && t.emptySquares.length && i.rested <= 3) {
		let n = [...t.emptySquares].sort((t, n) => {
			let r = u[e.squares.find((e) => e.x === t.x && e.y === t.y)?.ref ?? 0] ?? 0;
			return (u[e.squares.find((e) => e.x === n.x && e.y === n.y)?.ref ?? 0] ?? 0) - r;
		})[0];
		return {
			type: "placeCard",
			cardId: c[0],
			x: n.x,
			y: n.y,
			rotation: i.rotation ?? 0
		};
	}
	let d = null;
	for (let [e, n] of Object.entries(t.patterns)) for (let t of n) {
		let n = t.cells.reduce((e, t) => e + t.amount, 0);
		if (n > i.rested) continue;
		let r = t.cells.reduce((e, t) => e + l(t.x, t.y), 0);
		(!d || r > d.v || r === d.v && n < d.cost) && (d = {
			cardId: Number(e),
			x: t.x,
			y: t.y,
			r: t.r,
			v: r,
			cost: n
		});
	}
	if (d && d.v >= 4) return {
		type: "placeElephants",
		cardId: d.cardId,
		x: d.x,
		y: d.y,
		rotation: d.r
	};
	if (c.length && i.rested > 0 && t.single.length) {
		let e = t.single.filter((e) => e.amount <= i.rested).map((e) => ({
			c: e,
			v: l(e.x, e.y)
		})).sort((e, t) => t.v - e.v)[0];
		if (e && e.v >= 4) return {
			type: "placeSingle",
			cardId: c[0],
			x: e.c.x,
			y: e.c.y
		};
	}
	if (c.length && t.emptySquares.length) {
		let e = t.emptySquares[0];
		return {
			type: "placeCard",
			cardId: c[0],
			x: e.x,
			y: e.y,
			rotation: i.rotation ?? 0
		};
	}
	if (d) return {
		type: "placeElephants",
		cardId: d.cardId,
		x: d.x,
		y: d.y,
		rotation: d.r
	};
	if (c.length && i.rested > 0 && t.single.length) {
		let e = t.single.find((e) => e.amount <= i.rested);
		if (e) return {
			type: "placeSingle",
			cardId: c[0],
			x: e.x,
			y: e.y
		};
	}
	return s.length ? {
		type: "matriarch",
		x: null,
		y: null
	} : null;
}
var Qe = (e, t) => {
	let n = e.public;
	if (n.phase === "won" || n.phase === "lost") return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	if (n.phase === "orient") return r.rotation === null ? { action: {
		type: "orient",
		rotation: 0
	} } : null;
	if (n.phase === "reorient") return { action: { type: "passRotate" } };
	if (n.turn !== r.seat) return null;
	let i = e.private;
	if (!i) return null;
	let a = Ze(n, i, r.seat, t.difficulty === "weak");
	return a ? { action: a } : null;
};
//#endregion
//#region src/games/tembo/game-over.tsx
function $e(e) {
	return /* @__PURE__ */ f("div", {
		className: "tembo-over",
		children: /* @__PURE__ */ f(ee, {
			hintCount: e.hintCount,
			result: e.result,
			members: e.members,
			myRid: e.myRid,
			accent: se.accent,
			onPlayAgain: e.onPlayAgain,
			onBackToLobby: e.onBackToLobby
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tembo/entry.tsx
var et = {
	definition: Pe,
	View: Be,
	bot: Qe,
	OverView: $e,
	locales: {
		zh: {
			name: "草原征途",
			desc: "带领象群穿越草原抵达目的地,合作对抗狮群与枯竭的牌堆",
			rules: "目标:访问全部地标解锁终点板,并让两个终点格上都有象,全员即获胜。\n设置:\n· 按旅程拼好起点板、草原版图块与终点板。\n· 每人领取自己的象群:全部疲惫,先休整 3 只。\n· 按玩家人数设置共享能量，按难度领取支持标记，并将支援卡洗入抽牌堆顶部。\n开局:\n· 每人先选择自己本局的坐向,它决定打出草原卡的默认旋转。\n· 随后，任意玩家可以支付2点能量，旋转一块版图块。有人执行旋转后，立即开始游戏；没有人旋转时，所有玩家确认后开始游戏。\n回合:当前玩家执行一个行动,然后补牌至上限(多人 3 张、单人 4 张):\n· 建设草原：将一张草原卡铺到空的方格，并结算该格的奖励，使象休整或免费放置象。\n· 按脚印放置象：根据草原卡的脚印形状，在版图上放置象；新放置的象必须与版图上已有的象或女族长相邻。\n· 普通格消耗 1 只象、粗糙格 2 只,带红划爪印的卡无视粗糙地形;放完弃掉该卡。\n· 弃牌放置象：弃置一张草原卡，在象群的相邻格放置1只象；粗糙格需要2只象。\n· 打出女族长卡：将女族长移到象群相邻的任意空格。\n· 然后收拢象群，将版图上的象全部收回象群，并转为疲惫状态。将树重新立起，失去2点能量，再翻开一张事件牌。\n· 同时打出两张女族长卡时，失去5点能量。\n支持标记：可以使用任意次数，每次选择以下一种效果。\n· 获得1点能量。\n· 休整2只象。\n· 使下一张卡可以自由旋转。\n· 无视地形，放置1只象。\n放象结算:\n· 盖住水塘休整 3 只象。\n· 覆盖树格，且配对格中已有棋子时，树会倒下。绿树提供 2 点能量，其他树提供 1 点能量。\n· 地标区全部格有象时访问该地标。\n补牌触发:\n· 手牌有两张女族长卡时必须立即打出。\n· 抽到狮子卡时两只狮子依次激活:卧倒的起身,站立的向最近的象或女族长移动一格。\n· 狮子所在方格的象被吃掉;与女族长同格时每人移除 1 只象。\n发生以下任一情况时，所有玩家共同失败：\n· 抽牌堆耗尽。\n· 能量降至零。\n· 两只狮子与女族长位于同一格。\n· 任一玩家的象全部被移除。\n· 轮到某名玩家时，该玩家没有合法行动。",
			orientTitle: "选择坐向",
			orientHint: "坐向决定你打出草原卡的默认旋转,开局后不可更改",
			orientDone: "已选择,等待其他玩家",
			reorientTitle: "调整版图",
			reorientHint: "任何人可支付 2 能量旋转一块版图块;有人旋转或全员放弃即开始",
			rotateThis: "旋转此块",
			reorientHintShort: "选一块版图旋转，消耗 2 能量",
			confirmRotate: "确认旋转",
			passRotate: "保持现状",
			dir0: "朝上",
			dir1: "朝右",
			dir2: "朝下",
			dir3: "朝左",
			energy: "能量 {{n}}",
			support: "支持 {{n}}",
			deck: "牌堆 {{n}}",
			energyLabel: "能量",
			supportLabel: "支持",
			deckLabel: "牌堆",
			journeyProgress: "已访地标 {{n}}",
			mapOverview: "全图",
			mapFocus: "放大",
			turnYou: "轮到你",
			turnWait: "等待 {{name}}",
			supportRotateOn: "本回合卡可自由旋转",
			build: "建草原",
			elephants: "放象",
			single: "弃卡放象",
			matriarch: "打女族长",
			matriarchStay: "不移动",
			cancel: "取消",
			pickSquare: "点选一个空格放置此卡",
			pickCell: "点选一个高亮格",
			noTargets: "当前行动没有合法目标",
			treeStanding: "树木立起",
			treeFallen: "树木倒下",
			destinationLocked: "访问全部地标后解锁终点",
			selectCardHint: "先选一张手牌",
			chooseActionHint: "选择行动，再点选版图目标",
			confirmHint: "确认当前目标",
			waitHint: "观察版图，等待下一回合",
			yourHand: "手牌",
			costElephants: "需要 {{n}} 只象",
			confirmPlace: "确认放置",
			confirmElephants: "确认放象",
			changeTarget: "重新选择",
			savannaCard: "草原",
			lionCard: "狮子",
			supportTitle: "使用支持标记",
			supportHint0: "补充共享能量",
			supportHint1: "休整自己的象群",
			supportHint2: "下一张草原卡可自由旋转",
			supportHint3: "无视粗糙地形放象",
			supportEnergy: "+1 能量",
			supportElephants: "+2 休整象",
			supportRotate: "下张卡自由旋转",
			supportPlace: "无视地形放 1 象",
			chooseGain: "选择一名其他玩家获得 {{n}} 只休整象",
			chooseLose: "选择一名其他玩家失去 {{n}} 只休整象",
			freePlace: "无视粗糙地形放 1 只象",
			matriarchForced: "手牌有两张女族长卡,必须打出",
			soloMatriarchTitle: "两张女族长",
			soloMatriarchHint: "每局一次:可以弃掉一张女族长卡,避免触发双女族长",
			soloDiscard: "弃一张",
			soloKeep: "照常打出",
			bonus10: "全员 +2 象",
			bonus11: "另一玩家 +4 象",
			bonus12: "自己 +5 / 另一玩家 -2",
			bonus13: "自己 +3 并放 1 象",
			bonus14: "+4 象",
			spaceOasis: "水塘",
			spaceRough: "粗糙",
			spaceLandmark: "地标",
			spaceDestination: "终点",
			treeGreen: "绿树",
			treeRed: "红树",
			treeBrown: "棕树",
			treeTeal: "青树",
			landmark0: "雪丘",
			landmark1: "草甸",
			landmark2: "河流",
			landmark3: "岩群",
			landmark4: "峡谷",
			landmark5: "瀑布",
			lionDown: "卧",
			ev0: "持续:青树提供 2 能量",
			ev1: "持续:棕树提供 2 能量",
			ev2: "闪电:青树倒下",
			ev3: "闪电:绿树倒下",
			ev4: "闪电:棕树倒下",
			ev5: "持续:水塘 +5 象",
			ev6: "闪电:全体 -2 休整象",
			ev7: "持续:粗糙地形只需 1 象",
			ev8: "持续:水塘不得象",
			ev9: "持续:不可无视粗糙地形",
			ev10: "闪电:失去 1 枚支持标记",
			ev11: "闪电:母狮激活",
			ev12: "闪电:雄狮激活",
			ev13: "闪电:红树倒下",
			ev14: "闪电:每人移除 1 只象",
			ev15: "闪电:双狮卧倒",
			ev16: "持续:粗糙地形需 3 象",
			ev17: "闪电:+1 能量",
			ev18: "持续:红树提供 2 能量",
			ev19: "持续:草原卡不可旋转",
			winText: "象群抵达目的地,全员获胜!",
			lose1: "抽牌堆耗尽,远征失败",
			lose2: "能量归零,远征失败",
			lose3: "两只狮子追上了女族长,远征失败",
			lose4: "有玩家象群全灭,远征失败",
			lose5: "没有任何合法行动,远征失败",
			errOver: "本局已结束",
			errNotPlaying: "你不在本局座位中",
			errPhase: "当前阶段不能这样做",
			errNotYourTurn: "还没轮到你",
			errCard: "这张卡不在手牌或不能这样用",
			errCell: "目标格不可用",
			errRotation: "这张卡不能这样旋转",
			errElephants: "休整象不足",
			errSupport: "支持标记不足",
			errPending: "请先完成当前抉择"
		},
		en: {
			name: "TEMBO",
			desc: "Lead your elephant herds across the savanna to the destination — a co-op race against lions and a draining deck",
			rules: "Goal: visit every landmark to unlock the destination board, then occupy both destination spaces with elephants to win together.\nSetup:\n· Build the journey with the start board, savanna tiles and destination board.\n· Each player takes their herd: all tired, rest 3 first.\n· Shared energy depends on player count; support tokens and support cards scale with difficulty.\nOpening:\n· Each player picks a sitting direction, which sets the default rotation of the savanna cards they play.\n· Then anyone may pay 2 energy to rotate one savanna tile; the game starts once someone does, or everyone declines.\nTurn: the active player performs one action, then draws back up to the hand limit (3 cards, 4 solo):\n· Build savanna: place a savanna card on an empty square and trigger its bonus (rested elephants or a free placement).\n· Place elephants: use a card’s footprint shape to place elephants adjacent to the herd on the board or the Matriarch.\n· Normal spaces cost 1 elephant, rough spaces cost 2; cards with the red-claw mark ignore rough terrain; discard the card afterwards.\n· Discard to place: discard a savanna card to place 1 elephant on a herd-adjacent space (2 on rough).\n· Play a Matriarch card: optionally move the Matriarch to any herd-adjacent free space.\nAfter resolving the Matriarch card, gather the herd: return all elephants on the board to their home herd and turn them tired. Stand the trees back up, lose 2 energy and reveal an event tile.\n· Playing two Matriarch cards together costs 5 energy.\nSupport tokens:\nYou may spend support tokens any number of times. Each time, choose one effect:\n· Gain 1 energy.\n· Rest 2 elephants.\n· Freely rotate your next card.\n· Place 1 elephant, ignoring terrain.\nPlacement rewards:\n· Covering a water space rests 3 elephants.\n· Covering a tree space whose paired space is already occupied fells the tree: green trees give 2 energy, others 1.\n· Filling every space of a landmark area visits that landmark.\nDraw triggers:\n· Holding two Matriarch cards forces you to play them.\n· A drawn lion card activates both lions in turn: lying lions stand up, standing lions move one square toward the nearest elephant or the Matriarch.\n· Elephants in a lion’s square are eaten; sharing a square with the Matriarch removes 1 elephant per player.\nAll players lose if any of the following occurs:\n· The deck runs out.\n· Energy reaches zero.\n· Both lions share a square with the Matriarch.\n· Any player loses their entire herd.\n· A player has no legal action on their turn.",
			orientTitle: "Choose your seat direction",
			orientHint: "Your direction sets the default rotation of the savanna cards you play; it cannot change later",
			orientDone: "Chosen — waiting for the others",
			reorientTitle: "Adjust the board",
			reorientHint: "Anyone may pay 2 energy to rotate one savanna tile; the game starts once someone does or everyone declines",
			rotateThis: "Rotate this tile",
			reorientHintShort: "Choose a tile to rotate for 2 energy",
			confirmRotate: "Confirm rotation",
			passRotate: "Keep as is",
			dir0: "Up",
			dir1: "Right",
			dir2: "Down",
			dir3: "Left",
			energy: "Energy {{n}}",
			support: "Support {{n}}",
			deck: "Deck {{n}}",
			energyLabel: "Energy",
			supportLabel: "Support",
			deckLabel: "Deck",
			journeyProgress: "{{n}} landmarks visited",
			mapOverview: "Overview",
			mapFocus: "Zoom in",
			turnYou: "Your turn",
			turnWait: "Waiting for {{name}}",
			supportRotateOn: "Cards rotate freely this turn",
			build: "Build",
			elephants: "Herd",
			single: "Place 1",
			matriarch: "Matriarch",
			matriarchStay: "Stay put",
			cancel: "Cancel",
			pickSquare: "Tap an empty square to place this card",
			pickCell: "Tap a highlighted space",
			noTargets: "No legal target for this action",
			treeStanding: "Tree standing",
			treeFallen: "Tree fallen",
			destinationLocked: "Visit every landmark to unlock the destination",
			selectCardHint: "Choose a card first",
			chooseActionHint: "Choose an action, then tap a target on the board",
			confirmHint: "Confirm the selected target",
			waitHint: "Watch the board while you wait for the next turn",
			yourHand: "Hand",
			costElephants: "{{n}} elephants needed",
			confirmPlace: "Confirm placement",
			confirmElephants: "Place elephants",
			changeTarget: "Choose again",
			savannaCard: "Savanna",
			lionCard: "Lion",
			supportTitle: "Use a support token",
			supportHint0: "Restore shared energy",
			supportHint1: "Rest your elephants",
			supportHint2: "Freely rotate your next savanna card",
			supportHint3: "Place an elephant ignoring rough terrain",
			supportEnergy: "+1 energy",
			supportElephants: "+2 rested",
			supportRotate: "Free rotation",
			supportPlace: "Place 1 anywhere",
			chooseGain: "Choose another player to gain {{n}} rested elephants",
			chooseLose: "Choose another player to lose {{n}} rested elephants",
			freePlace: "Place 1 elephant ignoring rough terrain",
			matriarchForced: "Two Matriarch cards in hand — you must play them",
			soloMatriarchTitle: "Two Matriarchs",
			soloMatriarchHint: "Once per game: you may discard one Matriarch card to avoid a double Matriarch",
			soloDiscard: "Discard one",
			soloKeep: "Play both",
			bonus10: "All +2 elephants",
			bonus11: "Another player +4",
			bonus12: "You +5 / another -2",
			bonus13: "You +3 and place 1",
			bonus14: "+4 elephants",
			spaceOasis: "Water",
			spaceRough: "Rough",
			spaceLandmark: "Landmark",
			spaceDestination: "Destination",
			treeGreen: "Green tree",
			treeRed: "Red tree",
			treeBrown: "Brown tree",
			treeTeal: "Teal tree",
			landmark0: "Snow mound",
			landmark1: "Meadow",
			landmark2: "River",
			landmark3: "Rocks",
			landmark4: "Canyon",
			landmark5: "Waterfall",
			lionDown: "down",
			ev0: "Ongoing: teal trees give 2 energy",
			ev1: "Ongoing: brown trees give 2 energy",
			ev2: "Instant: the teal tree falls",
			ev3: "Instant: the green tree falls",
			ev4: "Instant: the brown tree falls",
			ev5: "Ongoing: water gives +5 elephants",
			ev6: "Instant: all players -2 rested elephants",
			ev7: "Ongoing: rough terrain costs 1 elephant",
			ev8: "Ongoing: water gives no elephants",
			ev9: "Ongoing: rough terrain cannot be ignored",
			ev10: "Instant: lose 1 support token",
			ev11: "Instant: the lioness activates",
			ev12: "Instant: the lion activates",
			ev13: "Instant: the red tree falls",
			ev14: "Instant: each player removes 1 elephant",
			ev15: "Instant: both lions lie down",
			ev16: "Ongoing: rough terrain costs 3 elephants",
			ev17: "Instant: +1 energy",
			ev18: "Ongoing: red trees give 2 energy",
			ev19: "Ongoing: savanna cards cannot be rotated",
			winText: "The herds reached their destination — you all win!",
			lose1: "The draw deck ran out — the journey fails",
			lose2: "Energy hit zero — the journey fails",
			lose3: "Both lions caught the Matriarch — the journey fails",
			lose4: "A player lost their whole herd — the journey fails",
			lose5: "No legal action available — the journey fails",
			errOver: "This game is over",
			errNotPlaying: "You are not seated in this game",
			errPhase: "Not allowed in this phase",
			errNotYourTurn: "Not your turn yet",
			errCard: "That card is not in your hand or cannot be used this way",
			errCell: "That space is not available",
			errRotation: "That card cannot be rotated this way",
			errElephants: "Not enough rested elephants",
			errSupport: "Not enough support tokens",
			errPending: "Finish the current choice first"
		}
	}
};
//#endregion
export { et as default };
