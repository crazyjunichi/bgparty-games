import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { AVATARS as n } from "@bgparty/sdk/avatars";
import { useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useT as s } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { Texture as d } from "@bgparty/sdk/texture";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { GameOverScreen as ee } from "@bgparty/sdk/ui/game-over-screen";
var te = {
	10: "tree-green",
	11: "tree-red",
	12: "tree-brown",
	13: "tree-teal"
}, h = [
	"tree-green",
	"tree-red",
	"tree-brown",
	"tree-teal"
], ne = {
	0: [[0, 0], [1, 1]],
	1: [[0, 0], [1, -1]],
	3: [[0, 0], [1, 0]],
	2: [[0, 0], [0, 1]],
	5: [
		[0, 0],
		[-1, 0],
		[1, 0]
	],
	4: [
		[0, 0],
		[0, -1],
		[0, 1]
	],
	6: [
		[0, 0],
		[-1, 0],
		[0, -1]
	]
}, re = [
	9,
	9,
	7,
	6
], g = [
	5,
	4,
	3,
	2,
	1,
	0
], ie = [
	26,
	13,
	11,
	11
], _ = [
	{
		deck: 4,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			13,
			0,
			1,
			0,
			13,
			0,
			3,
			2,
			3
		]
	},
	{
		deck: 4,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			2,
			0,
			1,
			0,
			3,
			11,
			11,
			3,
			0
		]
	},
	{
		deck: 4,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			12,
			0,
			12,
			2,
			0,
			0,
			3,
			3,
			1
		]
	},
	{
		deck: 4,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			0,
			2,
			1,
			12,
			12,
			1
		]
	},
	{
		deck: 4,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			13,
			0,
			1,
			2,
			0,
			1,
			0,
			1,
			13
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			10,
			10,
			0,
			2,
			0,
			1
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			2,
			0,
			3,
			3,
			10,
			10,
			3
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			3,
			2,
			3,
			3,
			0,
			3,
			11
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			3,
			12,
			12,
			0,
			2,
			3,
			3
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			3,
			2,
			0,
			0,
			0,
			10,
			10
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			13,
			13,
			0,
			0,
			0,
			2,
			3
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			11,
			0,
			2,
			0,
			3,
			0,
			1
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			0,
			0,
			10,
			10,
			1,
			3,
			3,
			0,
			2
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			0,
			2,
			0,
			1,
			13,
			13
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			1,
			2,
			3,
			3,
			0,
			3,
			11
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			0,
			3,
			3,
			2,
			11,
			0,
			0
		]
	},
	{
		deck: 0,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			0,
			1,
			12,
			12,
			0,
			2
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			12,
			12,
			0,
			2,
			1,
			3,
			0
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			11,
			1,
			0,
			3,
			0,
			2,
			3
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			13,
			0,
			13,
			1,
			0,
			1,
			0,
			2,
			1
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			0,
			2,
			0,
			11,
			11,
			1
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			3,
			2,
			3,
			3,
			3,
			10,
			10
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			2,
			0,
			3,
			3,
			3,
			1,
			13,
			13,
			3
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			12,
			0,
			2,
			0,
			1,
			0,
			12,
			0,
			3
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			2,
			1,
			0,
			0,
			13,
			13,
			0
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			0,
			3,
			10,
			10,
			0,
			1,
			2
		]
	},
	{
		deck: 1,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			10,
			0,
			0,
			2,
			1,
			3,
			10,
			0,
			3
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			1,
			0,
			3,
			0,
			11,
			11,
			3,
			0,
			2
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			0,
			0,
			13,
			13,
			3,
			0,
			2,
			1,
			3
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			10,
			10,
			0,
			2,
			1,
			1
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			2,
			0,
			1,
			0,
			1,
			12,
			12
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			0,
			0,
			11,
			11,
			3,
			3,
			2,
			3,
			3
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			13,
			13,
			0,
			1,
			0,
			2
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			10,
			10,
			3,
			2,
			3,
			3,
			0
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			2,
			3,
			3,
			3,
			0,
			12,
			12
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			0,
			0,
			2,
			1,
			0,
			10,
			10
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			3,
			2,
			3,
			11,
			11,
			0,
			3
		]
	},
	{
		deck: 2,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			0,
			0,
			0,
			1,
			2,
			0,
			3,
			12,
			12
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			10,
			0,
			0,
			3,
			3,
			1,
			0,
			2,
			10
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 0,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			1,
			0,
			3,
			0,
			3,
			2,
			0,
			12,
			12
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			13,
			0,
			13,
			1,
			2,
			0,
			3,
			0,
			3
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 1,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			11,
			0,
			11,
			3,
			3,
			0,
			0,
			2,
			1
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			2,
			0,
			10,
			10,
			1,
			0,
			1
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 3,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			0,
			0,
			1,
			0,
			2,
			11,
			11,
			0,
			1
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 4,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			3,
			3,
			0,
			12,
			12,
			3,
			2
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 5,
			canBeRotated: !1,
			ignoreRough: !1
		},
		spaces: [
			13,
			0,
			3,
			3,
			13,
			3,
			3,
			2,
			3
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			3,
			0,
			0,
			0,
			12,
			12,
			0,
			1,
			2
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			2,
			0,
			0,
			13,
			13,
			3,
			3,
			0,
			0
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 2,
			canBeRotated: !1,
			ignoreRough: !0
		},
		spaces: [
			11,
			0,
			0,
			1,
			0,
			2,
			0,
			1,
			11
		]
	},
	{
		deck: 3,
		type: "savanna",
		pattern: {
			shape: 6,
			canBeRotated: !0,
			ignoreRough: !1
		},
		spaces: [
			0,
			0,
			10,
			10,
			3,
			1,
			2,
			0,
			0
		]
	},
	{
		deck: 1,
		type: "matriarch"
	},
	{
		deck: 1,
		type: "matriarch"
	},
	{
		deck: 1,
		type: "matriarch"
	},
	{
		deck: 1,
		type: "matriarch"
	},
	{
		deck: 1,
		type: "lion"
	},
	{
		deck: 1,
		type: "lion"
	},
	{
		deck: 1,
		type: "lion"
	},
	{
		deck: 2,
		type: "matriarch"
	},
	{
		deck: 2,
		type: "matriarch"
	},
	{
		deck: 2,
		type: "matriarch"
	},
	{
		deck: 2,
		type: "lion"
	},
	{
		deck: 2,
		type: "lion"
	},
	{
		deck: 2,
		type: "lion"
	},
	{
		deck: 3,
		type: "lion"
	},
	{
		deck: 3,
		type: "lion"
	},
	{
		deck: 3,
		type: "lion"
	},
	{
		deck: 3,
		type: "lion"
	},
	{
		deck: 3,
		type: "matriarch"
	},
	{
		deck: 3,
		type: "matriarch"
	}
], v = [
	[
		0,
		11,
		13,
		10
	],
	[
		1,
		11,
		12,
		13
	],
	[
		2,
		10,
		11,
		12
	],
	[
		3,
		13,
		12,
		10
	],
	[
		4,
		13,
		10,
		11
	],
	[
		5,
		11,
		13,
		12
	]
], y = [
	1,
	2,
	4,
	3,
	3,
	3
], ae = [
	[
		4,
		1,
		0,
		0,
		0,
		1,
		0,
		0,
		0
	],
	[
		4,
		0,
		0,
		1,
		0,
		1,
		0,
		4,
		1
	],
	[
		4,
		0,
		4,
		3,
		3,
		0,
		4,
		4,
		0
	],
	[
		1,
		3,
		4,
		0,
		0,
		1,
		4,
		3,
		4
	],
	[
		4,
		0,
		3,
		4,
		0,
		0,
		3,
		4,
		1
	],
	[
		3,
		4,
		4,
		1,
		1,
		1,
		0,
		0,
		4
	]
], b = [
	{
		type: 1,
		effect: 0,
		arg: "tree-teal"
	},
	{
		type: 1,
		effect: 0,
		arg: "tree-brown"
	},
	{
		type: 0,
		effect: 1,
		arg: "tree-teal"
	},
	{
		type: 0,
		effect: 1,
		arg: "tree-green"
	},
	{
		type: 0,
		effect: 1,
		arg: "tree-brown"
	},
	{
		type: 1,
		effect: 2,
		arg: 5
	},
	{
		type: 0,
		effect: 3
	},
	{
		type: 1,
		effect: 4,
		arg: 1
	},
	{
		type: 1,
		effect: 2,
		arg: 0
	},
	{
		type: 1,
		effect: 5
	},
	{
		type: 0,
		effect: 6
	},
	{
		type: 0,
		effect: 7,
		arg: "lioness"
	},
	{
		type: 0,
		effect: 7,
		arg: "lion"
	},
	{
		type: 0,
		effect: 1,
		arg: "tree-red"
	},
	{
		type: 0,
		effect: 8
	},
	{
		type: 0,
		effect: 9
	},
	{
		type: 1,
		effect: 4,
		arg: 3
	},
	{
		type: 0,
		effect: 10
	},
	{
		type: 1,
		effect: 0,
		arg: "tree-red"
	},
	{
		type: 1,
		effect: 11
	}
], oe = {
	13: {
		destination: {
			x: 9,
			y: 0,
			rotation: 1
		},
		start: {
			x: 0,
			y: 18,
			rotation: 1,
			flipped: !0
		},
		tiles: [
			{
				x: 3,
				y: 0
			},
			{
				x: 0,
				y: 6
			},
			{
				x: 6,
				y: 9
			},
			{
				x: 9,
				y: 15
			},
			{
				x: 3,
				y: 18
			}
		],
		lioness: {
			x: 6,
			y: 9
		}
	},
	14: {
		destination: {
			x: 0,
			y: 0,
			rotation: 3
		},
		start: {
			x: 3,
			y: 24,
			rotation: 0
		},
		tiles: [
			{
				x: 3,
				y: 0
			},
			{
				x: 9,
				y: 0
			},
			{
				x: 6,
				y: 6
			},
			{
				x: 6,
				y: 12
			},
			{
				x: 3,
				y: 18
			},
			{
				x: 9,
				y: 18
			}
		],
		lioness: {
			x: 9,
			y: 6
		}
	},
	1: {
		destination: {
			x: 12,
			y: 0,
			rotation: 0
		},
		start: {
			x: 0,
			y: 24,
			rotation: 0
		},
		tiles: [
			{
				x: 12,
				y: 3
			},
			{
				x: 12,
				y: 9
			},
			{
				x: 6,
				y: 12
			},
			{
				x: 12,
				y: 15
			},
			{
				x: 0,
				y: 18
			},
			{
				x: 6,
				y: 18
			}
		],
		lion: {
			x: 15,
			y: 3
		},
		lioness: {
			x: 15,
			y: 18
		}
	},
	2: {
		destination: {
			x: 0,
			y: 0,
			rotation: 0
		},
		start: {
			x: 9,
			y: 24,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 0,
				y: 3
			},
			{
				x: 0,
				y: 9
			},
			{
				x: 3,
				y: 15
			},
			{
				x: 6,
				y: 6
			},
			{
				x: 9,
				y: 12
			},
			{
				x: 9,
				y: 18
			}
		],
		lion: {
			x: 3,
			y: 12
		},
		lioness: {
			x: 9,
			y: 12
		}
	},
	3: {
		destination: {
			x: 12,
			y: 0,
			rotation: 0
		},
		start: {
			x: 9,
			y: 24,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 0,
				y: 6
			},
			{
				x: 0,
				y: 12
			},
			{
				x: 6,
				y: 6
			},
			{
				x: 6,
				y: 12
			},
			{
				x: 12,
				y: 3
			},
			{
				x: 9,
				y: 18
			}
		],
		lion: {
			x: 15,
			y: 6
		},
		lioness: {
			x: 6,
			y: 15
		}
	},
	4: {
		destination: {
			x: 6,
			y: 0,
			rotation: 0
		},
		start: {
			x: 12,
			y: 21,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 0,
				y: 15
			},
			{
				x: 3,
				y: 9
			},
			{
				x: 6,
				y: 3
			},
			{
				x: 6,
				y: 15
			},
			{
				x: 9,
				y: 9
			},
			{
				x: 12,
				y: 15
			}
		],
		lion: {
			x: 9,
			y: 3
		},
		lioness: {
			x: 0,
			y: 18
		}
	},
	5: {
		destination: {
			x: 18,
			y: 3,
			rotation: 1
		},
		start: {
			x: 0,
			y: 18,
			rotation: 0
		},
		tiles: [
			{
				x: 0,
				y: 12
			},
			{
				x: 3,
				y: 6
			},
			{
				x: 6,
				y: 0
			},
			{
				x: 6,
				y: 15
			},
			{
				x: 9,
				y: 9
			},
			{
				x: 12,
				y: 3
			}
		],
		lion: {
			x: 6,
			y: 9
		},
		lioness: {
			x: 9,
			y: 12
		}
	},
	6: {
		destination: {
			x: 3,
			y: 0,
			rotation: 0
		},
		start: {
			x: 6,
			y: 21,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 3,
				y: 3
			},
			{
				x: 9,
				y: 3
			},
			{
				x: 0,
				y: 9
			},
			{
				x: 6,
				y: 9
			},
			{
				x: 12,
				y: 9
			},
			{
				x: 6,
				y: 15
			}
		],
		lion: {
			x: 3,
			y: 9
		},
		lioness: {
			x: 12,
			y: 9
		}
	},
	7: {
		destination: {
			x: 6,
			y: 0,
			rotation: 0
		},
		start: {
			x: 6,
			y: 21,
			rotation: 0
		},
		tiles: [
			{
				x: 6,
				y: 3
			},
			{
				x: 0,
				y: 6
			},
			{
				x: 12,
				y: 6
			},
			{
				x: 0,
				y: 12
			},
			{
				x: 12,
				y: 12
			},
			{
				x: 6,
				y: 15
			}
		],
		lion: {
			x: 3,
			y: 15
		},
		lioness: {
			x: 12,
			y: 15
		}
	},
	8: {
		destination: {
			x: 18,
			y: 6,
			rotation: 1
		},
		start: {
			x: 0,
			y: 18,
			rotation: 1,
			flipped: !0
		},
		tiles: [
			{
				x: 6,
				y: 0
			},
			{
				x: 0,
				y: 6
			},
			{
				x: 6,
				y: 6
			},
			{
				x: 6,
				y: 12
			},
			{
				x: 3,
				y: 18
			},
			{
				x: 12,
				y: 6
			}
		],
		lion: {
			x: 6,
			y: 12
		},
		lioness: {
			x: 9,
			y: 15
		}
	},
	9: {
		destination: {
			x: 9,
			y: 0,
			rotation: 0
		},
		start: {
			x: 3,
			y: 24,
			rotation: 0
		},
		tiles: [
			{
				x: 0,
				y: 12
			},
			{
				x: 3,
				y: 6
			},
			{
				x: 3,
				y: 18
			},
			{
				x: 9,
				y: 15
			},
			{
				x: 12,
				y: 9
			},
			{
				x: 9,
				y: 3
			}
		],
		lion: {
			x: 3,
			y: 9
		},
		lioness: {
			x: 12,
			y: 15
		}
	},
	10: {
		destination: {
			x: 3,
			y: 0,
			rotation: 0
		},
		start: {
			x: 12,
			y: 18,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 3,
				y: 3
			},
			{
				x: 0,
				y: 9
			},
			{
				x: 6,
				y: 9
			},
			{
				x: 3,
				y: 15
			},
			{
				x: 12,
				y: 6
			},
			{
				x: 12,
				y: 12
			}
		],
		lion: {
			x: 9,
			y: 9
		},
		lioness: {
			x: 9,
			y: 12
		}
	},
	11: {
		destination: {
			x: 6,
			y: 0,
			rotation: 0
		},
		start: {
			x: 6,
			y: 21,
			rotation: 0,
			flipped: !0
		},
		tiles: [
			{
				x: 0,
				y: 3
			},
			{
				x: 6,
				y: 3
			},
			{
				x: 6,
				y: 9
			},
			{
				x: 0,
				y: 15
			},
			{
				x: 6,
				y: 15
			},
			{
				x: 12,
				y: 6
			}
		],
		lion: {
			x: 12,
			y: 9
		},
		lioness: {
			x: 6,
			y: 15
		}
	},
	12: {
		destination: {
			x: 3,
			y: 0,
			rotation: 0
		},
		start: {
			x: 0,
			y: 15,
			rotation: 1,
			flipped: !0
		},
		tiles: [
			{
				x: 3,
				y: 3
			},
			{
				x: 9,
				y: 6
			},
			{
				x: 9,
				y: 12
			},
			{
				x: 15,
				y: 3
			},
			{
				x: 15,
				y: 15
			},
			{
				x: 3,
				y: 15
			}
		],
		lion: {
			x: 9,
			y: 9
		},
		lioness: {
			x: 12,
			y: 15
		}
	}
}, se = {
	id: "tembo",
	tier: "alpha",
	mechanics: ["tile-placement", "hand-management"],
	interactionTags: ["cooperative"],
	nameKey: "games.tembo.name",
	descKey: "games.tembo.desc",
	rulesKey: "games.tembo.rules",
	icon: "🐘",
	iconImg: "games/tembo.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/tembo/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [
		2,
		3,
		4
	],
	accent: "#d97706",
	releasedAt: "2026-10-06",
	search: {
		py: "cao yuan zheng tu",
		init: "cyzt"
	},
	hotseat: "cover"
}, x = t.int().min(0).max(3), S = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("orient"),
		rotation: x
	}),
	t.object({
		type: t.literal("rotateTile"),
		tile: t.int().nonnegative(),
		rotation: x
	}),
	t.object({ type: t.literal("passRotate") }),
	t.object({
		type: t.literal("placeCard"),
		cardId: t.int().nonnegative(),
		x: t.int(),
		y: t.int(),
		rotation: x
	}),
	t.object({
		type: t.literal("placeElephants"),
		cardId: t.int().nonnegative(),
		x: t.int(),
		y: t.int(),
		rotation: x
	}),
	t.object({
		type: t.literal("placeSingle"),
		cardId: t.int().nonnegative(),
		x: t.int(),
		y: t.int()
	}),
	t.object({
		type: t.literal("support"),
		option: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("matriarch"),
		x: t.int().nullable(),
		y: t.int().nullable()
	}),
	t.object({
		type: t.literal("choosePlayer"),
		seat: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("placeSingleFree"),
		x: t.int(),
		y: t.int()
	}),
	t.object({
		type: t.literal("soloMatriarch"),
		discard: t.boolean()
	})
]), C = t.object({
	journey: t.int().min(0).max(14).prefault(0),
	difficulty: t.int().min(0).max(5).prefault(0),
	events: t.boolean().prefault(!1)
}).default({
	journey: 0,
	difficulty: 0,
	events: !1
}), w = t.object({
	x: t.int(),
	y: t.int()
}), ce = t.object({
	rid: t.string(),
	seat: t.int().nonnegative(),
	rotation: x.nullable(),
	rested: t.int().nonnegative(),
	tired: t.int().nonnegative(),
	onBoard: t.int().nonnegative(),
	handCount: t.int().nonnegative(),
	matriarchCount: t.int().nonnegative()
}), le = t.object({
	phase: t.enum([
		"orient",
		"reorient",
		"turn",
		"won",
		"lost"
	]),
	loseReason: t.int().nullable(),
	config: C,
	journey: t.int(),
	solo: t.boolean(),
	energy: t.int().nonnegative(),
	supportTokens: t.int().nonnegative(),
	destinationUnlocked: t.boolean(),
	tiles: t.array(t.object({
		id: t.int(),
		x: t.int(),
		y: t.int(),
		rotation: x
	})),
	start: t.object({
		x: t.int(),
		y: t.int(),
		rotation: t.int(),
		flipped: t.boolean()
	}),
	destination: t.object({
		x: t.int(),
		y: t.int(),
		rotation: t.int()
	}),
	squares: t.array(t.object({
		x: t.int(),
		y: t.int(),
		kind: t.enum(["landmark", "bonus"]),
		ref: t.int(),
		rotation: x,
		card: t.int().nullable(),
		cardRotation: x.nullable()
	})),
	cells: t.record(t.string(), t.int()),
	destinationCells: t.array(w),
	elephants: t.array(t.object({
		x: t.int(),
		y: t.int(),
		seat: t.int().nonnegative()
	})),
	matriarch: w,
	lions: t.array(t.object({
		type: t.enum(["lion", "lioness"]),
		x: t.int(),
		y: t.int(),
		standing: t.boolean()
	})),
	landmarks: t.array(t.object({
		ref: t.int(),
		x: t.int().nullable(),
		y: t.int().nullable()
	})),
	trees: t.record(t.string(), t.boolean()),
	players: t.array(ce),
	deckCount: t.int().nonnegative(),
	discardCount: t.int().nonnegative(),
	events: t.array(t.object({
		id: t.int(),
		older: t.boolean()
	})).nullable(),
	eventDeckCount: t.int().nonnegative(),
	turn: t.int().nonnegative(),
	supportRotate: t.boolean(),
	pending: t.object({
		kind: t.enum([
			"choosePlayer",
			"placeSingleFree",
			"matriarch",
			"soloMatriarch"
		]),
		amount: t.int().optional(),
		count: t.int().optional()
	}).nullable()
}), T = t.object({
	hand: t.array(t.int()),
	patterns: t.record(t.string(), t.array(t.object({
		x: t.int(),
		y: t.int(),
		r: x,
		cells: t.array(w.extend({ amount: t.int() }))
	}))),
	single: t.array(w.extend({ amount: t.int() })),
	singleFree: t.array(w),
	matriarchTargets: t.array(w),
	emptySquares: t.array(w)
}), E = (e) => ({ code: e }), D = (t, n) => e(t.seed, t.cursor++, n);
function O(e, t) {
	for (let n = t.length - 1; n > 0; n--) {
		let r = D(e, n + 1);
		[t[n], t[r]] = [t[r], t[n]];
	}
	return t;
}
var k = (e, t) => `${e},${t}`, A = (e, t) => ({
	x: e - e % 3,
	y: t - t % 3
}), j = [
	[-1, -1],
	[0, -1],
	[1, -1],
	[-1, 0],
	[1, 0],
	[-1, 1],
	[0, 1],
	[1, 1]
], M = [
	[0, -3],
	[3, 0],
	[0, 3],
	[-3, 0]
];
function ue(e, t, n, r) {
	return t === 1 && n === 1 ? e[0] : e[1 + (([
		[
			0,
			1,
			2
		],
		[
			7,
			-1,
			3
		],
		[
			6,
			5,
			4
		]
	][n][t] - 2 * r) % 8 + 8) % 8];
}
function N(e, t, n, r) {
	return ne[e].map(([e, i]) => {
		let a, o;
		return r % 2 == 0 ? (a = r === 0 ? e : -e, o = r === 0 ? i : -i) : (a = r === 1 ? -i : i, o = r === 1 ? e : -e), {
			x: t + a,
			y: n + o
		};
	});
}
function P(e) {
	let t = e.players.length === 1, n = [];
	for (let r of e.tiles) {
		let e = [[v[r.id][0], v[r.id][1]], [v[r.id][2], v[r.id][3]]];
		for (let t = 0; t < r.rotation; t++) e = [[e[1][0], e[0][0]], [e[1][1], e[0][1]]];
		for (let i = 0; i < 2; i++) for (let a = 0; a < 2; a++) {
			let o = e[a][i], s = o >= 0 && o <= 5;
			n.push({
				x: r.x + 3 * i,
				y: r.y + 3 * a,
				kind: s ? "landmark" : "bonus",
				ref: s ? o : t ? 14 : o,
				rotation: r.rotation
			});
		}
	}
	return n;
}
function F(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of P(e)) {
		let r = null, i = 0;
		if (n.kind === "landmark") r = ae[n.ref], i = n.rotation;
		else {
			let t = e.placedCards.find((e) => e.x === n.x && e.y === n.y);
			t && (r = _[t.id].spaces, i = t.rotation);
		}
		if (r) for (let e = 0; e < 3; e++) for (let a = 0; a < 3; a++) t.set(k(n.x + e, n.y + a), ue(r, e, a, i));
	}
	let n = e.destination, [r, i] = n.rotation === 0 ? [n.x + 1, n.y + 2] : n.rotation === 1 ? [n.x, n.y + 1] : [n.x + 2, n.y + 1];
	return t.set(k(r, i), 15), n.rotation % 2 == 0 ? (t.set(k(r + 3, i), 15), t.set(k(r + 1, i), 14), t.set(k(r + 2, i), 14)) : (t.set(k(r, i + 3), 15), t.set(k(r, i + 1), 14), t.set(k(r, i + 2), 14)), t;
}
function I(e) {
	let t = e.destination, [n, r] = t.rotation === 0 ? [t.x + 1, t.y + 2] : t.rotation === 1 ? [t.x, t.y + 1] : [t.x + 2, t.y + 1];
	return t.rotation % 2 == 0 ? [{
		x: n + 1,
		y: r
	}, {
		x: n + 2,
		y: r
	}] : [{
		x: n,
		y: r + 1
	}, {
		x: n,
		y: r + 2
	}];
}
function L(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e.elephants) t.add(k(n.x, n.y));
	t.add(k(e.matriarch.x, e.matriarch.y));
	for (let n of e.lions) t.add(k(n.x, n.y));
	for (let n of e.landmarks) n.x !== null && t.add(k(n.x, n.y));
	return t;
}
function R(e, t) {
	return e.events ? e.events.active.map((e) => b[e]).filter((e) => e.type === 1 && e.effect === t) : [];
}
var z = (e) => {
	let t = R(e, 4);
	return t.length ? t[0].arg : 2;
}, B = (e) => {
	let t = R(e, 2);
	return t.length ? t[0].arg : 3;
}, V = (e, t) => R(e, 0).some((e) => e.arg === t) ? 2 : 1, H = (e) => R(e, 5).length > 0, U = (e) => R(e, 11).length === 0, W = (e, t, n) => e.get(k(t, n)), G = (e, t, n, r, i) => W(t, n, r) === 3 && !i ? z(e) : 1;
function K(e, t, n) {
	let r = F(e), i = L(e), a = /* @__PURE__ */ new Map(), o = [...e.elephants, e.matriarch];
	for (let s of o) for (let [o, c] of j) {
		let l = s.x + o, u = s.y + c, d = W(r, l, u);
		if (d === void 0 || d === 0 || i.has(k(l, u)) || !e.destinationUnlocked && (d === 14 || d === 15)) continue;
		let f = G(e, r, l, u, n || t === null);
		t !== null && e.players[t].rested < f || a.set(k(l, u), {
			x: l,
			y: u,
			amount: f
		});
	}
	return [...a.values()];
}
function de(e) {
	let t = F(e), n = L(e), r = /* @__PURE__ */ new Set();
	for (let [i, a] of t) {
		if (a !== 4 || n.has(i)) continue;
		let [t, o] = i.split(",").map(Number), s = A(t, o), c = P(e).find((e) => e.x === s.x && e.y === s.y);
		if (!c) continue;
		let l = e.landmarks.find((e) => e.ref === c.ref);
		l && l.x === null && r.add(i);
	}
	return r;
}
function fe(e, t, n, r, i, a, o) {
	let s = F(e), c = L(e), l = N(t, n, r, i), u = o && !H(e), d = 0, f = !1;
	for (let t of l) {
		let n = W(s, t.x, t.y);
		if (n === void 0 || n === 0 || c.has(k(t.x, t.y))) return !1;
		(n === 14 || n === 15) && (f = !0), d += n === 3 && !u ? z(e) : 1;
	}
	if (d > a) return !1;
	if (f) {
		let t = de(e), n = new Set(l.map((e) => k(e.x, e.y)));
		for (let e of t) if (!n.has(e)) return !1;
	}
	return !0;
}
function pe(e, t, n) {
	let r = _[n];
	if (!r.pattern) return [];
	let i = e.players[t], a = r.pattern.canBeRotated || e.supportRotate ? [
		0,
		1,
		2,
		3
	] : [i.rotation ?? 0], o = new Set(K(e, null, !1).map((e) => k(e.x, e.y))), s = F(e), c = 0, l = 0;
	for (let t of P(e)) c = Math.max(c, t.x + 2), l = Math.max(l, t.y + 2);
	for (let t of e.destinationCells) c = Math.max(c, t.x), l = Math.max(l, t.y);
	let u = [];
	for (let t = 0; t <= c; t++) for (let n = 0; n <= l; n++) for (let c of a) {
		if (!fe(e, r.pattern.shape, t, n, c, i.rested, r.pattern.ignoreRough)) continue;
		let a = N(r.pattern.shape, t, n, c);
		if (!a.some((e) => o.has(k(e.x, e.y)))) continue;
		let l = r.pattern.ignoreRough && !H(e);
		u.push({
			x: t,
			y: n,
			r: c,
			cells: a.map((t) => ({
				...t,
				amount: G(e, s, t.x, t.y, l)
			}))
		});
	}
	return u;
}
function me(e) {
	return P(e).filter((t) => t.kind === "bonus" && !e.placedCards.some((e) => e.x === t.x && e.y === t.y));
}
function q(e, t, n, r = !1) {
	let i = F(e), a = L(e), o = [];
	for (let e = t; e < t + 3; e++) for (let t = n; t < n + 3; t++) {
		let n = i.get(k(e, t));
		if ((n === void 0 || n === 0) && (r || !a.has(k(e, t))) && (o.push({
			x: e,
			y: t
		}), n === void 0)) return o[0];
	}
	return o.length === 0 ? r ? {
		x: t,
		y: n
	} : q(e, t, n, !0) : o[D(e, o.length)];
}
function J(e, t, n) {
	let r = e.players[t];
	if (n >= 0) {
		let e = Math.min(n, r.tired);
		r.tired -= e, r.rested += e;
	} else {
		let e = Math.min(-n, r.rested);
		r.rested -= e, r.tired += e;
	}
}
function Y(e, t) {
	let n = e.players[t];
	n.rested === 0 && n.tired === 0 && !e.elephants.some((e) => e.seat === t) && (e.loseReason = 4);
}
function X(e, t) {
	let n = e.players[t];
	if (n.rested > 0) n.rested--;
	else if (n.tired > 0) n.tired--;
	else return;
	Y(e, t);
}
function Z(e, t) {
	e.energy - t <= 0 && (t = e.energy, e.loseReason = 2), e.energy -= t;
}
function he(e, t, n) {
	let r = F(e), i = L(e), a = n.map((e) => ({
		...e,
		type: W(r, e.x, e.y)
	}));
	for (let n of a) n.type === 2 && J(e, t, B(e));
	let o = /* @__PURE__ */ new Set();
	for (let t of a) {
		if (t.type === void 0 || !(t.type in te)) continue;
		let n = A(t.x, t.y), a = null;
		for (let [e, i] of j) {
			let o = t.x + e, s = t.y + i;
			if (!(o < n.x || o >= n.x + 3 || s < n.y || s >= n.y + 3) && W(r, o, s) === t.type) {
				a = {
					x: o,
					y: s
				};
				break;
			}
		}
		if (!a || o.has(k(a.x, a.y)) || (o.add(k(t.x, t.y)), !i.has(k(a.x, a.y)))) continue;
		let s = te[t.type];
		e.trees[s] && (e.trees[s] = !1, e.energy = Math.min(12, e.energy + (t.type === 10 ? 2 : V(e, s))));
	}
	let s = /* @__PURE__ */ new Set();
	for (let t of a) {
		if (t.type !== 4) continue;
		let n = A(t.x, t.y), a = P(e).find((e) => e.x === n.x && e.y === n.y);
		if (!a || s.has(a.ref)) continue;
		s.add(a.ref);
		let o = e.landmarks.find((e) => e.ref === a.ref);
		if (!o || o.x !== null) continue;
		let c = !0;
		if (y[a.ref] >= 2) for (let e = 0; e < 3 && c; e++) for (let a = 0; a < 3 && c; a++) {
			let o = n.x + e, s = n.y + a;
			(o !== t.x || s !== t.y) && W(r, o, s) === 4 && !i.has(k(o, s)) && (c = !1);
		}
		if (c) {
			let t = q(e, n.x, n.y);
			o.x = t.x, o.y = t.y;
		}
	}
	if (!e.destinationUnlocked && e.landmarks.every((e) => e.x !== null) && (e.destinationUnlocked = !0), e.destinationUnlocked) {
		let t = a.filter((e) => e.type === 14).length;
		(t === 2 || t === 1 && e.destinationCells.every((e) => i.has(k(e.x, e.y)))) && (e.loseReason = 10);
	}
}
function ge(e) {
	let t = e.start.rotation % 4;
	return [...M.slice(t), ...M.slice(0, t)];
}
function _e(e, t, n) {
	return P(e).some((e) => e.x === t && e.y === n);
}
function ve(e, t, n) {
	let r = [{
		...t,
		d: 0
	}], i = /* @__PURE__ */ new Set();
	for (; r.length;) {
		let t = r.shift(), a = k(t.x, t.y);
		if (!i.has(a)) {
			if (t.x === n.x && t.y === n.y) return t.d;
			i.add(a);
			for (let [n, a] of M) {
				let o = t.x + n, s = t.y + a;
				_e(e, o, s) && !i.has(k(o, s)) && r.push({
					x: o,
					y: s,
					d: t.d + 1
				});
			}
		}
	}
	return 999;
}
function ye(e, t) {
	if (!t.standing) {
		t.standing = !0;
		return;
	}
	let n = A(t.x, t.y), r = [...e.elephants.map((e) => A(e.x, e.y)), A(e.matriarch.x, e.matriarch.y)], i = ge(e), a = r[0], o = Infinity;
	for (let t of r) {
		if (t.x === n.x && t.y === n.y) {
			a = t;
			break;
		}
		let r = ve(e, t, n);
		if (r < o) o = r, a = t;
		else if (r === o) for (let [e, r] of i) {
			if (n.x + e === t.x && n.y + r === t.y) {
				a = t;
				break;
			}
			if (n.x + e === a.x && n.y + r === a.y) break;
		}
	}
	let s = i.filter(([t, r]) => _e(e, n.x + t, n.y + r)), c = ve(e, n, a), l = s.filter(([t, r]) => ve(e, {
		x: n.x + t,
		y: n.y + r
	}, a) < c), u = l.length ? l[0] : [0, 0], d = q(e, n.x + u[0], n.y + u[1]);
	t.x = d.x, t.y = d.y;
}
function be(e, t) {
	let n = A(t.x, t.y), r = (e, t) => e >= n.x && e < n.x + 3 && t >= n.y && t < n.y + 3, i = e.elephants.filter((e) => r(e.x, e.y)).length;
	e.elephants = e.elephants.filter((e) => !r(e.x, e.y));
	for (let t = 0; t < e.players.length; t++) Y(e, t);
	let a = r(e.matriarch.x, e.matriarch.y);
	if (a) for (let t = 0; t < e.players.length; t++) X(e, t);
	if ((i > 0 || a) && (t.standing = !1), a && e.lions.length > 1) {
		let [t, n] = e.lions.map((e) => A(e.x, e.y));
		t.x === n.x && t.y === n.y && (e.loseReason = 3);
	}
}
function xe(e, t, n) {
	for (let r of e.lions) {
		let i = A(r.x, r.y);
		if (i.x === t && i.y === n) {
			let i = q(e, t, n);
			r.x = i.x, r.y = i.y;
		}
	}
}
function Se(e, t) {
	t.hand = t.hand.filter((t) => _[t].type !== "lion" || (e.discard.push(t), !1));
	for (let t of ["lioness", "lion"]) {
		let n = e.lions.find((e) => e.type === t);
		n && (ye(e, n), be(e, n));
	}
}
function Ce(e, t) {
	let n = b[t];
	switch (n.effect) {
		case 1:
			e.trees[n.arg] = !1;
			break;
		case 3:
			for (let t = 0; t < e.players.length; t++) J(e, t, -2);
			break;
		case 6:
			e.supportTokens > 0 && e.supportTokens--;
			break;
		case 7: {
			let t = e.lions.find((e) => e.type === n.arg);
			t && (ye(e, t), be(e, t));
			break;
		}
		case 8:
			for (let t = 0; t < e.players.length; t++) X(e, t);
			break;
		case 9:
			for (let t of e.lions) t.standing = !1;
			break;
		case 10: e.energy = Math.min(12, e.energy + 1);
	}
}
function we(e, t) {
	if (!e.events) return;
	let n = e.events.deck.pop();
	if (n === void 0) return;
	e.events.active.length > 1 && e.events.active.pop();
	let r = e.events.active[0];
	e.events.active = r === void 0 ? [n] : [n, r], r !== void 0 && t && b[r].type === 0 && Ce(e, r), b[n].type === 0 && Ce(e, n);
}
function Te(e, t, n, r) {
	let i = e.players[t], a = i.hand.filter((e) => _[e].type === "matriarch").length;
	i.hand = i.hand.filter((t) => _[t].type !== "matriarch" || (e.discard.push(t), !1)), n !== null && r !== null && (e.matriarch = {
		x: n,
		y: r
	}, he(e, t, [{
		x: n,
		y: r
	}]));
	for (let t of e.elephants) e.players[t.seat].tired++;
	e.elephants = [];
	for (let t of h) e.trees[t] = !0;
	Z(e, a === 2 ? 5 : 2), we(e, !0);
}
var Ee = (e) => e.players.length === 1 ? 4 : 3;
function De(e, t) {
	let n = e.players[t];
	return !!(n.hand.some((e) => _[e].type === "matriarch") || me(e).length > 0 || n.rested > 0 && K(e, t, !1).length > 0);
}
function Oe(e) {
	e.phase = e.loseReason === 10 ? "won" : "lost", e.pending = null;
}
function Q(e) {
	for (;;) {
		if (e.loseReason !== null) return Oe(e);
		let t = e.players[e.turn.seat], n = Ee(e) - t.hand.length;
		for (let r = 0; r < n; r++) {
			let n = e.deck.pop();
			if (n === void 0) {
				e.loseReason = 1;
				break;
			}
			t.hand.push(n);
		}
		if (e.loseReason !== null) continue;
		let r = t.hand.filter((e) => _[e].type === "matriarch").length;
		if (r >= 2) {
			e.pending = e.players.length === 1 && !e.soloDiscarded ? { kind: "soloMatriarch" } : {
				kind: "matriarch",
				count: r
			};
			return;
		}
		if (t.hand.some((e) => _[e].type === "lion")) {
			Se(e, t);
			continue;
		}
		if (e.turn.seat = (e.turn.seat + 1) % e.players.length, e.supportRotate = !1, !De(e, e.turn.seat)) {
			e.loseReason = 5;
			continue;
		}
		return;
	}
}
function ke(e, t, n) {
	let r = t.length === 1, i = e.journey === 0 ? r ? 13 : 1 : e.journey, a = oe[i], o = {
		seed: n,
		cursor: 0,
		config: e,
		seats: [...t],
		phase: "orient",
		loseReason: null,
		journey: i,
		tiles: [],
		start: {
			x: a.start.x,
			y: a.start.y,
			rotation: a.start.rotation,
			flipped: a.start.flipped ?? !1
		},
		destination: a.destination,
		destinationCells: [],
		destinationUnlocked: !1,
		placedCards: [],
		elephants: [],
		matriarch: {
			x: 0,
			y: 0
		},
		lions: [],
		landmarks: [],
		trees: {
			"tree-green": !0,
			"tree-red": !0,
			"tree-brown": !0,
			"tree-teal": !0
		},
		players: t.map((e) => ({
			rid: e,
			rotation: null,
			rested: 0,
			tired: 0,
			hand: []
		})),
		deck: [],
		discard: [],
		events: null,
		energy: re[t.length - 1],
		supportTokens: g[e.difficulty],
		supportRotate: !1,
		soloDiscarded: !1,
		turn: { seat: 0 },
		pending: null,
		passRotate: []
	}, s = O(o, [
		0,
		1,
		2,
		3,
		4,
		5
	]);
	o.tiles = a.tiles.map((e, t) => ({
		id: s[t],
		x: e.x,
		y: e.y,
		rotation: D(o, 4)
	})), o.destinationCells = I(o), o.landmarks = o.tiles.map((e) => ({
		ref: e.id,
		x: null,
		y: null
	}));
	for (let e of ["lion", "lioness"]) {
		let t = a[e];
		if (!t) continue;
		let n = q(o, t.x, t.y);
		o.lions.push({
			type: e,
			x: n.x,
			y: n.y,
			standing: !1
		});
	}
	let [c, l] = o.start.rotation === 0 ? o.start.flipped ? [4, 0] : [1, 0] : o.start.flipped ? [2, 4] : [2, 1];
	o.matriarch = {
		x: o.start.x + c,
		y: o.start.y + l
	}, o.players.forEach((e) => {
		e.tired = ie[t.length - 1];
	}), o.players.forEach((e, t) => J(o, t, 3));
	let u = (e) => _.map((e, t) => ({
		c: e,
		id: t
	})).filter(({ c: t }) => t.deck === e).map(({ id: e }) => e);
	for (let e of [
		3,
		2,
		1
	]) o.deck.push(...O(o, u(e)));
	let d = O(o, u(4)).slice(0, g[e.difficulty]);
	return o.deck.push(...d), e.events && (o.events = {
		deck: O(o, b.map((e, t) => t)),
		active: []
	}, we(o, !0), we(o, !1)), { state: o };
}
function Ae(e) {
	let t = O(e, je());
	if (e.players.forEach((n) => {
		for (let r = 0; r < Ee(e); r++) {
			let e = t.pop();
			e !== void 0 && n.hand.push(e);
		}
	}), e.phase = "turn", e.loseReason !== null) return Oe(e);
	if (!De(e, e.turn.seat)) return e.loseReason = 5, Oe(e);
}
var je = () => _.map((e, t) => ({
	c: e,
	id: t
})).filter(({ c: e }) => e.deck === 0).map(({ id: e }) => e);
function Me(e, t, n) {
	let r = structuredClone(e);
	if (r.phase === "won" || r.phase === "lost") return E("games.tembo.errOver");
	let i = r.seats.indexOf(n.by);
	if (i < 0) return E("games.tembo.errNotPlaying");
	if (r.phase === "orient") return t.type === "orient" ? (r.players[i].rotation = t.rotation, r.players.every((e) => e.rotation !== null) && (r.phase = "reorient"), { state: r }) : E("games.tembo.errPhase");
	if (r.phase === "reorient") {
		if (t.type === "rotateTile") {
			let e = r.tiles[t.tile];
			return e ? (e.rotation = t.rotation, Z(r, 2), Ae(r), { state: r }) : E("games.tembo.errCell");
		}
		return t.type === "passRotate" ? (r.passRotate.includes(n.by) || r.passRotate.push(n.by), r.passRotate.length === r.players.length && Ae(r), { state: r }) : E("games.tembo.errPhase");
	}
	if (i !== r.turn.seat) return E("games.tembo.errNotYourTurn");
	let a = r.players[i];
	if (r.pending) {
		let e = r.pending;
		switch (e.kind) {
			case "choosePlayer": return t.type === "choosePlayer" ? t.seat === i || t.seat >= r.players.length ? E("games.tembo.errCell") : (J(r, t.seat, e.amount), r.pending = null, Q(r), { state: r }) : E("games.tembo.errPending");
			case "placeSingleFree": {
				if (t.type !== "placeSingleFree") return E("games.tembo.errPending");
				if (!K(r, i, !0).some((e) => e.x === t.x && e.y === t.y)) return E("games.tembo.errCell");
				if (a.rested < 1) return E("games.tembo.errElephants");
				a.rested--, r.elephants.push({
					x: t.x,
					y: t.y,
					seat: i
				}), he(r, i, [{
					x: t.x,
					y: t.y
				}]);
				let n = e.then;
				return r.pending = null, n === "endTurn" ? Q(r) : r.loseReason !== null && Oe(r), { state: r };
			}
			case "matriarch": return t.type === "matriarch" ? t.x === null != (t.y === null) || t.x !== null && !K(r, null, !0).some((e) => e.x === t.x && e.y === t.y) ? E("games.tembo.errCell") : (r.pending = null, Te(r, i, t.x, t.y), Q(r), { state: r }) : E("games.tembo.errPending");
			case "soloMatriarch":
				if (t.type !== "soloMatriarch") return E("games.tembo.errPending");
				if (t.discard) {
					let e = a.hand.filter((e) => _[e].type === "matriarch"), t = e[D(r, e.length)];
					a.hand.splice(a.hand.indexOf(t), 1), r.discard.push(t), r.soloDiscarded = !0, r.pending = null, Q(r);
				} else r.pending = {
					kind: "matriarch",
					count: 2
				};
				return { state: r };
		}
	}
	switch (t.type) {
		case "placeCard": {
			let e = _[t.cardId], n = a.hand.indexOf(t.cardId);
			if (n < 0 || !e?.pattern) return E("games.tembo.errCard");
			let o = me(r).find((e) => e.x === t.x && e.y === t.y);
			if (!o) return E("games.tembo.errCell");
			if (t.rotation !== a.rotation && !(r.supportRotate || U(r) && e.pattern.canBeRotated)) return E("games.tembo.errRotation");
			switch (a.hand.splice(n, 1), r.placedCards.push({
				id: t.cardId,
				x: t.x,
				y: t.y,
				rotation: t.rotation
			}), xe(r, t.x, t.y), o.ref) {
				case 10:
					r.players.forEach((e, t) => J(r, t, 2));
					break;
				case 11:
					r.pending = {
						kind: "choosePlayer",
						amount: 4
					};
					break;
				case 12:
					J(r, i, 5), r.pending = {
						kind: "choosePlayer",
						amount: -2
					};
					break;
				case 13:
					J(r, i, 3), K(r, i, !0).length > 0 && a.rested > 0 && (r.pending = {
						kind: "placeSingleFree",
						then: "endTurn"
					});
					break;
				case 14: J(r, i, 4);
			}
			return r.pending || Q(r), { state: r };
		}
		case "placeElephants": {
			let e = _[t.cardId], n = a.hand.indexOf(t.cardId);
			if (n < 0 || !e?.pattern) return E("games.tembo.errCard");
			if (!(e.pattern.canBeRotated || r.supportRotate ? [
				0,
				1,
				2,
				3
			] : [a.rotation ?? 0]).includes(t.rotation)) return E("games.tembo.errRotation");
			if (!fe(r, e.pattern.shape, t.x, t.y, t.rotation, a.rested, e.pattern.ignoreRough)) return E("games.tembo.errCell");
			let o = new Set(K(r, null, !1).map((e) => k(e.x, e.y))), s = N(e.pattern.shape, t.x, t.y, t.rotation);
			if (!s.some((e) => o.has(k(e.x, e.y)))) return E("games.tembo.errCell");
			let c = F(r), l = e.pattern.ignoreRough && !H(r), u = s.reduce((e, t) => e + G(r, c, t.x, t.y, l), 0);
			if (u > a.rested) return E("games.tembo.errElephants");
			a.rested -= u, a.hand.splice(n, 1), r.discard.push(t.cardId);
			for (let e of s) for (let t = 0; t < G(r, c, e.x, e.y, l); t++) r.elephants.push({
				x: e.x,
				y: e.y,
				seat: i
			});
			return he(r, i, s), Q(r), { state: r };
		}
		case "placeSingle": {
			let e = _[t.cardId], n = a.hand.indexOf(t.cardId);
			if (n < 0 || !e?.pattern) return E("games.tembo.errCard");
			let o = e.pattern.ignoreRough, s = K(r, i, o).find((e) => e.x === t.x && e.y === t.y);
			if (!s) return E("games.tembo.errCell");
			a.rested -= s.amount, a.hand.splice(n, 1), r.discard.push(t.cardId);
			for (let e = 0; e < s.amount; e++) r.elephants.push({
				x: t.x,
				y: t.y,
				seat: i
			});
			return he(r, i, [{
				x: t.x,
				y: t.y
			}]), Q(r), { state: r };
		}
		case "support":
			if (r.supportTokens <= 0) return E("games.tembo.errSupport");
			switch (r.supportTokens--, t.option) {
				case 0:
					r.energy = Math.min(12, r.energy + 1);
					break;
				case 1:
					J(r, i, 2);
					break;
				case 2:
					r.supportRotate = !0;
					break;
				case 3: K(r, i, !0).length > 0 && a.rested > 0 && (r.pending = {
					kind: "placeSingleFree",
					then: "continue"
				});
			}
			return { state: r };
		case "matriarch": return a.hand.some((e) => _[e].type === "matriarch") ? t.x === null != (t.y === null) || t.x !== null && !K(r, null, !0).some((e) => e.x === t.x && e.y === t.y) ? E("games.tembo.errCell") : (Te(r, i, t.x, t.y), Q(r), { state: r }) : E("games.tembo.errCard");
		default: return E("games.tembo.errPhase");
	}
}
function Ne(e, t) {
	let n = F(e), r = {};
	for (let [e, t] of n) r[e] = t;
	let i = {
		phase: e.phase,
		loseReason: e.phase === "lost" ? e.loseReason : null,
		config: e.config,
		journey: e.journey,
		solo: e.players.length === 1,
		energy: e.energy,
		supportTokens: e.supportTokens,
		destinationUnlocked: e.destinationUnlocked,
		tiles: e.tiles.map((e) => ({ ...e })),
		start: { ...e.start },
		destination: { ...e.destination },
		squares: P(e).map((t) => {
			let n = e.placedCards.find((e) => e.x === t.x && e.y === t.y);
			return {
				x: t.x,
				y: t.y,
				kind: t.kind,
				ref: t.ref,
				rotation: t.rotation,
				card: n?.id ?? null,
				cardRotation: n?.rotation ?? null
			};
		}),
		cells: r,
		destinationCells: e.destinationCells.map((e) => ({ ...e })),
		elephants: e.elephants.map((e) => ({ ...e })),
		matriarch: { ...e.matriarch },
		lions: e.lions.map((e) => ({ ...e })),
		landmarks: e.landmarks.map((e) => ({ ...e })),
		trees: { ...e.trees },
		players: e.players.map((t, n) => ({
			rid: t.rid,
			seat: n,
			rotation: t.rotation,
			rested: t.rested,
			tired: t.tired,
			onBoard: e.elephants.filter((e) => e.seat === n).length,
			handCount: t.hand.length,
			matriarchCount: t.hand.filter((e) => _[e].type === "matriarch").length
		})),
		deckCount: e.deck.length,
		discardCount: e.discard.length,
		events: e.events ? e.events.active.map((e, t) => ({
			id: e,
			older: t > 0
		})) : null,
		eventDeckCount: e.events ? e.events.deck.length : 0,
		turn: e.turn.seat,
		supportRotate: e.supportRotate,
		pending: e.pending ? {
			kind: e.pending.kind,
			...e.pending.kind === "choosePlayer" ? { amount: e.pending.amount } : {},
			...e.pending.kind === "matriarch" ? { count: e.pending.count } : {}
		} : null
	}, a = e.players.find((e) => e.rid === t), o = a ? e.players.indexOf(a) : -1, s = {
		hand: a ? [...a.hand] : [],
		patterns: {},
		single: [],
		singleFree: [],
		matriarchTargets: [],
		emptySquares: []
	};
	if (a && e.phase === "turn" && e.turn.seat === o) {
		if (s.emptySquares = me(e).map((e) => ({
			x: e.x,
			y: e.y
		})), e.pending) e.pending.kind === "placeSingleFree" ? s.singleFree = K(e, o, !0) : e.pending.kind === "matriarch" && (s.matriarchTargets = K(e, null, !0));
		else {
			s.single = K(e, o, !1);
			for (let t of a.hand) {
				if (_[t].type !== "savanna") continue;
				let n = pe(e, o, t);
				n.length && (s.patterns[String(t)] = n);
			}
			a.hand.some((e) => _[e].type === "matriarch") && (s.matriarchTargets = K(e, null, !0));
		}
	}
	return {
		public: i,
		private: s
	};
}
function Pe(e) {
	return e.phase === "won" ? {
		phase: "won",
		winner: e.seats,
		ranking: e.seats
	} : e.phase === "lost" ? {
		phase: "lost",
		winner: [],
		ranking: e.seats
	} : { phase: e.phase };
}
var Fe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: se,
	schemas: {
		action: S,
		publicView: le,
		privateView: T,
		config: C
	},
	setup: ke,
	reduce: Me,
	viewFor: Ne,
	status: Pe
}, Ie = (e) => {
	switch (e) {
		case void 0:
		case 0: return "is-none";
		case 2: return "is-water";
		case 3: return "is-rough";
		case 4: return "is-landmark";
		case 10: return "is-tree-green";
		case 11: return "is-tree-red";
		case 12: return "is-tree-brown";
		case 13: return "is-tree-teal";
		case 14: return "is-destination";
		case 15: return "is-destination-normal";
		default: return "is-plain";
	}
}, Le = (e) => {
	let t = Ie(e);
	return t.startsWith("is-tree-") ? "is-tree" : t;
}, Re = [
	"❄️",
	"🌿",
	"🌊",
	"🪨",
	"🏜️",
	"💧"
], ze = [
	"⬆️",
	"➡️",
	"⬇️",
	"⬅️"
], Be = 44;
function Ve(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(He, {
		pub: t,
		priv: n,
		props: e
	});
}
function He({ pub: e, priv: t, props: ee }) {
	let h = s(), { members: ne, myRid: re, send: g } = ee, [ie, v] = o(null), [y, ae] = o(null), [b, oe] = o(0), [x, S] = o(null), [C, w] = o(null), [ce, le] = o(!1), [T, E] = o("near"), [D, O] = o({
		w: 375,
		h: 450
	}), k = a(null), A = e.players.findIndex((e) => e.rid === re), j = A >= 0 ? e.players[A] : null, M = e.phase === "turn" && e.turn === A, ue = (e) => ne.find((t) => t.rid === e), N = (e) => ue(e)?.name ?? e, P = (e) => {
		let t = ue(e);
		return t ? c[t.colorIndex % c.length].hex : "#888";
	}, F = t?.hand ?? [], I = ie !== null && F.includes(ie) ? ie : null, L = I === null ? null : _[I], R = !!L?.pattern && (e.supportRotate || L.pattern.canBeRotated), z = i(() => {
		let n = new Map((t?.single ?? []).map((e) => [`${e.x},${e.y}`, e]));
		if (!L?.pattern?.ignoreRough || !j?.rested) return [...n.values()];
		let r = /* @__PURE__ */ new Set([
			...e.elephants.map((e) => `${e.x},${e.y}`),
			...e.lions.map((e) => `${e.x},${e.y}`),
			...e.landmarks.filter((e) => e.x !== null).map((e) => `${e.x},${e.y}`),
			`${e.matriarch.x},${e.matriarch.y}`
		]);
		for (let t of [...e.elephants, e.matriarch]) for (let i = -1; i <= 1; i++) for (let a = -1; a <= 1; a++) {
			if (i === 0 && a === 0) continue;
			let o = t.x + i, s = t.y + a, c = `${o},${s}`;
			e.cells[c] === 3 && !r.has(c) && n.set(c, {
				x: o,
				y: s,
				amount: 1
			});
		}
		return [...n.values()];
	}, [
		t?.single,
		L?.pattern?.ignoreRough,
		j?.rested,
		e.elephants,
		e.lions,
		e.landmarks,
		e.matriarch,
		e.cells
	]), B = i(() => {
		let n = /* @__PURE__ */ new Map();
		if (e.phase !== "turn" || !M || !t) return n;
		let r = e.pending;
		if (r?.kind === "placeSingleFree") {
			for (let e of t.singleFree) n.set(`${e.x},${e.y}`, "cell");
			return n;
		}
		if (r?.kind === "matriarch") {
			for (let e of t.matriarchTargets) n.set(`${e.x},${e.y}`, "cell");
			return n;
		}
		if (r) return n;
		if (y === "build" && I !== null) for (let e of t.emptySquares) n.set(`${e.x},${e.y}`, "square");
		else if (y === "footprint" && I !== null) for (let e of t.patterns[String(I)] ?? []) e.r === b && n.set(`${e.x},${e.y}`, "anchor");
		else if (y === "single" && I !== null) for (let e of z) n.set(`${e.x},${e.y}`, "cell");
		else if (y === "matriarch" && I !== null) for (let e of t.matriarchTargets) n.set(`${e.x},${e.y}`, "cell");
		return n;
	}, [
		e.phase,
		e.pending,
		M,
		t,
		y,
		I,
		b,
		z
	]), V = i(() => {
		let t = Infinity, n = Infinity, r = -Infinity, i = -Infinity, a = (e, a) => {
			t = Math.min(t, e), n = Math.min(n, a), r = Math.max(r, e), i = Math.max(i, a);
		};
		for (let t of Object.keys(e.cells)) {
			let [e, n] = t.split(",").map(Number);
			a(e, n);
		}
		for (let t of e.squares) a(t.x, t.y), a(t.x + 2, t.y + 2);
		return a(e.start.x, e.start.y), a(e.start.x + (e.start.rotation % 2 == 0 ? 5 : 2), e.start.y + (e.start.rotation % 2 == 0 ? 2 : 5)), a(e.matriarch.x, e.matriarch.y), {
			minX: t,
			minY: n,
			w: r - t + 1,
			h: i - n + 1
		};
	}, [e]), H = D.w >= 600 && D.h >= 340 ? Math.max(Be, Math.min(88, D.w / 14, D.h / 8)) : Be, U = T === "near" ? H : Math.max(5, Math.min((D.w - 16) / V.w, (D.h - 16) / V.h)), W = T === "near" ? D.w / 2 : 0, G = T === "near" ? D.h / 2 : 0, K = x && y === "footprint" && I !== null ? (t?.patterns[String(I)] ?? []).find((e) => e.x === x.x && e.y === x.y && e.r === b) : void 0;
	r(() => {
		let e = k.current;
		if (!e) return;
		let t = new ResizeObserver(() => O({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []), r(() => {
		let t = k.current;
		t && T === "near" && t.scrollTo({
			left: W + (e.matriarch.x - V.minX + .5) * U - t.clientWidth / 2,
			top: G + (e.matriarch.y - V.minY + .5) * U - t.clientHeight / 2
		});
	}, [
		T,
		V.minX,
		V.minY,
		U,
		W,
		G,
		e.matriarch.x,
		e.matriarch.y
	]);
	let de = (t) => {
		ae(t), S(null), E("near"), k.current?.scrollTo({
			left: W + (e.matriarch.x - V.minX + .5) * H - k.current.clientWidth / 2,
			top: G + (e.matriarch.y - V.minY + .5) * H - k.current.clientHeight / 2
		});
	}, fe = (e, t) => {
		M && T !== "all" && B.get(`${e},${t}`) && S({
			x: e,
			y: t
		});
	}, pe = (t, n) => {
		M && T !== "all" && !e.pending && y === "build" && I !== null && B.get(`${t},${n}`) === "square" && S({
			x: t,
			y: n
		});
	}, me = (e, t) => {
		(e.key === "Enter" || e.key === " ") && (e.preventDefault(), t());
	}, q = () => {
		if (!x || !M) return;
		let t = `${x.x},${x.y}`;
		if (!B.has(t)) return;
		let n = null;
		e.pending?.kind === "placeSingleFree" ? n = {
			type: "placeSingleFree",
			x: x.x,
			y: x.y
		} : e.pending?.kind === "matriarch" ? n = {
			type: "matriarch",
			x: x.x,
			y: x.y
		} : !e.pending && y === "build" && I !== null && B.get(t) === "square" ? n = {
			type: "placeCard",
			cardId: I,
			x: x.x,
			y: x.y,
			rotation: R ? b : j?.rotation ?? 0
		} : !e.pending && y === "footprint" && I !== null && K ? n = {
			type: "placeElephants",
			cardId: I,
			x: x.x,
			y: x.y,
			rotation: b
		} : !e.pending && y === "single" && I !== null ? n = {
			type: "placeSingle",
			cardId: I,
			x: x.x,
			y: x.y
		} : !e.pending && y === "matriarch" && I !== null && (n = {
			type: "matriarch",
			x: x.x,
			y: x.y
		}), n && (g(n), v(null), ae(null), S(null));
	}, J = /* @__PURE__ */ m("div", {
		className: "tembo-banner flex flex-col gap-1",
		children: [/* @__PURE__ */ p(l, {
			tone: e.phase === "won" ? "done" : e.phase === "lost" ? "warn" : M || e.phase === "orient" || e.phase === "reorient" ? "accent" : "info",
			accent: se.accent,
			text: e.phase === "won" ? h("games.tembo.winText") : e.phase === "lost" ? h(`games.tembo.lose${e.loseReason}`) : e.phase === "orient" ? h("games.tembo.orientTitle") : e.phase === "reorient" ? h("games.tembo.reorientTitle") : M ? h("games.tembo.turnYou") : h("games.tembo.turnWait", { name: N(e.players[e.turn]?.rid ?? "") })
		}), /* @__PURE__ */ m("div", {
			className: "tembo-status-wrap",
			children: [/* @__PURE__ */ m("div", {
				className: "tembo-resource-rail",
				children: [
					/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ m("div", {
						className: "tembo-energy-label",
						children: [/* @__PURE__ */ p("span", { children: h("games.tembo.energyLabel") }), /* @__PURE__ */ m("strong", {
							className: "font-mono",
							children: [e.energy, " / 12"]
						})]
					}), /* @__PURE__ */ p("div", {
						className: "tembo-energy-track",
						"aria-hidden": !0,
						children: Array.from({ length: 12 }, (t, n) => /* @__PURE__ */ p("i", { className: n < e.energy ? "is-filled" : "" }, n))
					})] }),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "tembo-resource-chip",
						disabled: !M || !!e.pending || e.supportTokens <= 0,
						onClick: () => le(!0),
						children: [/* @__PURE__ */ p("span", { children: h("games.tembo.supportLabel") }), /* @__PURE__ */ p("strong", {
							className: "font-mono",
							children: e.supportTokens
						})]
					}),
					/* @__PURE__ */ m("div", {
						className: "tembo-resource-chip",
						children: [/* @__PURE__ */ p("span", { children: h("games.tembo.deckLabel") }), /* @__PURE__ */ p("strong", {
							className: "font-mono",
							children: e.deckCount
						})]
					})
				]
			}), /* @__PURE__ */ m("div", {
				className: "tembo-player-rail",
				children: [e.players.map((t) => /* @__PURE__ */ m("div", {
					className: `tembo-player-chip ${t.seat === e.turn && e.phase === "turn" ? "is-active" : ""}`,
					children: [
						/* @__PURE__ */ p("i", {
							className: "tembo-player-dot",
							style: { background: P(t.rid) }
						}),
						N(t.rid),
						" · ",
						t.rested,
						"/",
						t.tired,
						" ",
						t.rotation !== null && ze[t.rotation]
					]
				}, t.rid)), e.supportRotate && /* @__PURE__ */ m("span", {
					className: "tembo-player-chip",
					children: ["↻ ", h("games.tembo.supportRotateOn")]
				})]
			})]
		})]
	}), Y = (e) => W + (e - V.minX) * U, X = (e) => G + (e - V.minY) * U, Z = [];
	for (let t of e.squares) {
		let e = t.kind === "bonus" && t.card === null, n = e && B.get(`${t.x},${t.y}`) === "square", r = n && T === "near", i = x?.x === t.x && x.y === t.y;
		Z.push(/* @__PURE__ */ m("div", {
			onClick: r ? () => pe(t.x, t.y) : void 0,
			onKeyDown: r ? (e) => me(e, () => pe(t.x, t.y)) : void 0,
			role: r ? "button" : void 0,
			tabIndex: r ? 0 : void 0,
			"aria-label": r ? h(`games.tembo.bonus${t.ref}`) : void 0,
			className: `tembo-square ${e ? "is-bonus is-empty" : ""} ${n ? "is-legal" : ""} ${i ? "is-target" : ""}`,
			style: {
				left: Y(t.x),
				top: X(t.y),
				width: 3 * U,
				height: 3 * U
			},
			children: [t.kind === "landmark" && /* @__PURE__ */ p("span", {
				className: "tembo-landmark-tag",
				children: h(`games.tembo.landmark${t.ref}`)
			}), e && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", {
				className: "tembo-square-rings",
				children: Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ p("i", {}, t))
			}), /* @__PURE__ */ p("span", {
				className: "tembo-square-label",
				children: h(`games.tembo.bonus${t.ref}`)
			})] })]
		}, `sq-${t.x}-${t.y}`));
	}
	let he = e.start.rotation % 2 == 0 ? 6 : 3, ge = e.start.rotation % 2 == 0 ? 3 : 6;
	Z.push(/* @__PURE__ */ p("div", {
		className: "tembo-start",
		style: {
			left: Y(e.start.x),
			top: X(e.start.y),
			width: he * U,
			height: ge * U
		}
	}, "start")), Z.push(/* @__PURE__ */ p("div", {
		className: "tembo-start-label",
		style: {
			left: Y(e.start.x) + 5,
			top: X(e.start.y) - 9
		},
		children: "START"
	}, "start-label"));
	for (let [t, n] of Object.entries(e.cells)) {
		let [r, i] = t.split(",").map(Number), a = B.get(t), o = a === "cell" || a === "anchor", s = o && T === "near", c = x?.x === r && x.y === i, l = y === "single" ? z.find((e) => e.x === r && e.y === i)?.amount : void 0, u = n in te ? te[n] : null, d = u ? e.trees[u] : !1, f = (n === 14 || n === 15) && !e.destinationUnlocked;
		Z.push(/* @__PURE__ */ m("div", {
			onClick: s ? () => fe(r, i) : void 0,
			onKeyDown: s ? (e) => me(e, () => fe(r, i)) : void 0,
			role: s ? "button" : void 0,
			tabIndex: s ? 0 : void 0,
			"aria-label": s ? `${h("games.tembo.pickCell")} ${r}, ${i}` : void 0,
			className: `tembo-cell ${Ie(n)} ${f ? "is-locked" : ""} ${o ? "is-legal" : ""} ${c ? "is-target" : ""}`,
			style: {
				left: Y(r),
				top: X(i),
				width: U,
				height: U
			},
			children: [
				u && /* @__PURE__ */ p("span", {
					className: `tembo-cell-icon tembo-tree ${d ? "" : "is-fallen"}`,
					title: h(d ? "games.tembo.treeStanding" : "games.tembo.treeFallen"),
					children: d ? "🌳" : "🪵"
				}),
				n === 4 && /* @__PURE__ */ p("span", {
					className: "tembo-cell-icon",
					children: "★"
				}),
				n === 2 && /* @__PURE__ */ p("span", {
					className: "tembo-cell-icon",
					children: "≈"
				}),
				f ? /* @__PURE__ */ p("span", {
					className: "tembo-cell-icon",
					title: h("games.tembo.destinationLocked"),
					children: "🔒"
				}) : n === 14 && /* @__PURE__ */ p("span", {
					className: "tembo-cell-icon",
					children: "★"
				}),
				l && /* @__PURE__ */ p("span", {
					className: "tembo-cell-cost",
					children: l
				})
			]
		}, t));
	}
	if (K) for (let e of K.cells) Z.push(/* @__PURE__ */ p("div", {
		className: "tembo-cell tembo-preview",
		style: {
			left: Y(e.x) + 4,
			top: X(e.y) + 4,
			width: U - 8,
			height: U - 8
		},
		children: e.amount
	}, `preview-${e.x}-${e.y}`));
	if (e.phase === "reorient") for (let t = 0; t < e.tiles.length; t++) {
		let n = e.tiles[t];
		Z.push(/* @__PURE__ */ p("button", {
			type: "button",
			className: `tembo-tile-choice ${C === t ? "is-target" : ""}`,
			style: {
				left: Y(n.x),
				top: X(n.y),
				width: 6 * U,
				height: 6 * U
			},
			onClick: () => w(t),
			"aria-label": `${h("games.tembo.rotateThis")} ${t + 1}`
		}, `rotate-${t}`));
	}
	for (let t of e.landmarks) t.x !== null && Z.push(/* @__PURE__ */ p("div", {
		className: "tembo-piece",
		style: {
			left: Y(t.x),
			top: X(t.y),
			width: U,
			height: U
		},
		children: /* @__PURE__ */ p("span", {
			className: "tembo-matriarch",
			children: Re[t.ref]
		})
	}, `lm-${t.ref}`));
	e.elephants.forEach((t, r) => {
		let i = e.players[t.seat]?.rid ?? "";
		Z.push(/* @__PURE__ */ p("div", {
			className: "tembo-piece",
			style: {
				left: Y(t.x),
				top: X(t.y),
				width: U,
				height: U
			},
			children: /* @__PURE__ */ m("span", {
				className: "tembo-meeple",
				style: { "--tembo-player": P(i) },
				children: ["🐘", /* @__PURE__ */ p("small", { children: /* @__PURE__ */ p("img", {
					src: n[(ee.members.find((e) => e.rid === i)?.avatar ?? 0) % n.length],
					alt: "",
					draggable: !1,
					style: {
						width: "1.75em",
						height: "1.75em",
						maxWidth: "100%",
						maxHeight: "100%",
						display: "block",
						objectFit: "contain",
						pointerEvents: "none",
						borderRadius: "inherit"
					}
				}) })]
			})
		}, `e${r}`));
	}), Z.push(/* @__PURE__ */ p("div", {
		className: "tembo-piece",
		style: {
			left: Y(e.matriarch.x),
			top: X(e.matriarch.y),
			width: U,
			height: U
		},
		children: /* @__PURE__ */ p("span", {
			className: "tembo-matriarch",
			children: "👑"
		})
	}, "m")), e.lions.forEach((e) => {
		Z.push(/* @__PURE__ */ p("div", {
			className: "tembo-piece",
			style: {
				left: Y(e.x),
				top: X(e.y),
				width: U,
				height: U
			},
			children: /* @__PURE__ */ p("span", {
				className: `tembo-lion ${e.standing ? "" : "is-down"}`,
				children: e.type === "lion" ? "🦁" : "🐆"
			})
		}, e.type));
	});
	let _e = /* @__PURE__ */ m("div", {
		className: `tembo-board-frame ${T === "all" ? "is-overview" : ""}`,
		children: [
			/* @__PURE__ */ p(d, {
				kind: "sheen",
				base: "#e7cb91",
				className: "absolute inset-0"
			}),
			/* @__PURE__ */ p("div", {
				ref: k,
				className: "tembo-board-scroll",
				children: /* @__PURE__ */ p("div", {
					className: "tembo-board-world",
					style: {
						width: V.w * U + 2 * W,
						height: V.h * U + 2 * G
					},
					children: Z
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "tembo-board-toolbar",
				children: [/* @__PURE__ */ p("span", {
					className: "tembo-journey-chip",
					children: h("games.tembo.journeyProgress", { n: e.landmarks.filter((e) => e.x !== null).length })
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: "tembo-map-button",
					onClick: () => E(T === "near" ? "all" : "near"),
					children: h(T === "near" ? "games.tembo.mapOverview" : "games.tembo.mapFocus")
				})]
			}),
			e.events?.map((e, t) => /* @__PURE__ */ p("span", {
				className: `tembo-event-chip ${e.older ? "is-older" : ""}`,
				title: h(`games.tembo.ev${e.id}`),
				children: h(`games.tembo.ev${e.id}`)
			}, `${e.id}-${t}`))
		]
	}), ve = K?.cells.reduce((e, t) => e + t.amount, 0), ye = e.phase === "orient" ? h("games.tembo.orientHint") : e.phase === "reorient" ? h("games.tembo.reorientHintShort") : e.phase === "won" || e.phase === "lost" ? h(e.phase === "won" ? "games.tembo.winText" : `games.tembo.lose${e.loseReason}`) : M ? e.pending?.kind === "placeSingleFree" || e.pending?.kind === "matriarch" ? h("games.tembo.pickCell") : y && B.size === 0 ? h("games.tembo.noTargets") : h(y === "build" ? "games.tembo.pickSquare" : y === "footprint" || y === "single" || y === "matriarch" ? "games.tembo.pickCell" : "games.tembo.selectCardHint") : h("games.tembo.waitHint"), be = /* @__PURE__ */ m("div", {
		className: "tembo-actions",
		children: [
			e.phase === "orient" && /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("div", {
					className: "tembo-actions-title",
					children: h("games.tembo.orientTitle")
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-actions-hint",
					children: j?.rotation === null ? h("games.tembo.orientHint") : h("games.tembo.orientDone")
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-phase-row",
					children: ze.map((e, t) => /* @__PURE__ */ m("button", {
						type: "button",
						className: `tembo-action-button ${j?.rotation === t ? "is-selected" : ""}`,
						onClick: () => g({
							type: "orient",
							rotation: t
						}),
						children: [
							e,
							" ",
							h(`games.tembo.dir${t}`)
						]
					}, t))
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-choice-note",
					children: h("games.tembo.orientHint")
				})
			] }),
			e.phase === "reorient" && /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("div", {
					className: "tembo-actions-title",
					children: h("games.tembo.reorientTitle")
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-actions-hint",
					children: h("games.tembo.reorientHintShort")
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-phase-row",
					children: e.tiles.map((e, t) => /* @__PURE__ */ m("button", {
						type: "button",
						className: `tembo-action-button ${C === t ? "is-selected" : ""}`,
						onClick: () => w(t),
						children: [
							Re[e.id],
							" ",
							h(`games.tembo.landmark${e.id}`)
						]
					}, t))
				}),
				/* @__PURE__ */ m("div", {
					className: "tembo-action-row",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						className: "tembo-action-button is-primary",
						disabled: C === null,
						onClick: () => {
							if (C === null) return;
							let t = e.tiles[C];
							g({
								type: "rotateTile",
								tile: C,
								rotation: (t.rotation + 1) % 4
							}), w(null);
						},
						children: h("games.tembo.confirmRotate")
					}), /* @__PURE__ */ p("button", {
						type: "button",
						className: "tembo-action-button",
						onClick: () => g({ type: "passRotate" }),
						children: h("games.tembo.passRotate")
					})]
				})
			] }),
			e.phase === "turn" && M && e.pending?.kind === "choosePlayer" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("div", {
				className: "tembo-actions-title",
				children: h(e.pending.amount > 0 ? "games.tembo.chooseGain" : "games.tembo.chooseLose", { n: Math.abs(e.pending.amount) })
			}), /* @__PURE__ */ p("div", {
				className: "tembo-phase-row",
				children: e.players.filter((e) => e.seat !== A).map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "tembo-action-button",
					onClick: () => g({
						type: "choosePlayer",
						seat: e.seat
					}),
					children: N(e.rid)
				}, e.rid))
			})] }),
			e.phase === "turn" && M && (e.pending?.kind === "placeSingleFree" || e.pending?.kind === "matriarch") && /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("div", {
					className: "tembo-actions-title",
					children: h(e.pending.kind === "placeSingleFree" ? "games.tembo.freePlace" : "games.tembo.matriarchForced")
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-actions-hint",
					children: h("games.tembo.pickCell")
				}),
				/* @__PURE__ */ m("div", {
					className: "tembo-action-row",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						className: "tembo-action-button is-primary",
						disabled: !x,
						onClick: q,
						children: h("games.tembo.confirmPlace")
					}), e.pending.kind === "matriarch" && /* @__PURE__ */ p("button", {
						type: "button",
						className: "tembo-action-button",
						onClick: () => {
							g({
								type: "matriarch",
								x: null,
								y: null
							}), S(null);
						},
						children: h("games.tembo.matriarchStay")
					})]
				})
			] }),
			e.phase === "turn" && M && e.pending?.kind === "soloMatriarch" && /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("div", {
					className: "tembo-actions-title",
					children: h("games.tembo.soloMatriarchTitle")
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-actions-hint",
					children: h("games.tembo.soloMatriarchHint")
				}),
				/* @__PURE__ */ m("div", {
					className: "tembo-action-row",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						className: "tembo-action-button is-primary",
						onClick: () => g({
							type: "soloMatriarch",
							discard: !0
						}),
						children: h("games.tembo.soloDiscard")
					}), /* @__PURE__ */ p("button", {
						type: "button",
						className: "tembo-action-button",
						onClick: () => g({
							type: "soloMatriarch",
							discard: !1
						}),
						children: h("games.tembo.soloKeep")
					})]
				})
			] }),
			e.phase === "turn" && M && !e.pending && /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ m("div", {
					className: "tembo-actions-title",
					children: [/* @__PURE__ */ m("span", { children: [
						h("games.tembo.yourHand"),
						" ",
						F.length
					] }), /* @__PURE__ */ p("span", { children: ve ? h("games.tembo.costElephants", { n: ve }) : "" })]
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-hand",
					children: F.map((e) => {
						let t = _[e], n = I === e;
						return /* @__PURE__ */ m("button", {
							type: "button",
							className: `tembo-card ${n ? "is-selected" : ""}`,
							onClick: () => {
								v(n ? null : e), ae(null), S(null), oe(j?.rotation ?? 0);
							},
							children: [/* @__PURE__ */ p("span", {
								className: "tembo-card-name",
								children: h(t.type === "savanna" ? "games.tembo.savannaCard" : t.type === "matriarch" ? "games.tembo.matriarch" : "games.tembo.lionCard")
							}), t.type === "savanna" && t.spaces ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("span", {
								className: "tembo-card-pattern",
								children: [Je(t.pattern.shape), t.pattern.canBeRotated ? "↻" : ""]
							}), /* @__PURE__ */ p("span", {
								className: "tembo-card-grid",
								children: Ue.map((e, n) => /* @__PURE__ */ p("i", { className: Le(t.spaces[e]) }, n))
							})] }) : /* @__PURE__ */ p("span", {
								className: "tembo-card-figure",
								children: t.type === "matriarch" ? "👑" : "🦁"
							})]
						}, e);
					})
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-actions-hint",
					children: I === null ? h("games.tembo.selectCardHint") : x ? h("games.tembo.confirmHint") : y ? ye : h("games.tembo.chooseActionHint")
				}),
				/* @__PURE__ */ m("div", {
					className: "tembo-action-row",
					children: [
						I === null && /* @__PURE__ */ p("div", {
							className: "tembo-empty-action",
							children: h("games.tembo.selectCardHint")
						}),
						I !== null && x && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("button", {
							type: "button",
							className: "tembo-action-button is-primary",
							onClick: q,
							children: h(y === "footprint" || y === "single" ? "games.tembo.confirmElephants" : "games.tembo.confirmPlace")
						}), /* @__PURE__ */ p("button", {
							type: "button",
							className: "tembo-action-button",
							onClick: () => S(null),
							children: h("games.tembo.changeTarget")
						})] }),
						I !== null && !x && L?.type === "savanna" && /* @__PURE__ */ m(f, { children: [
							/* @__PURE__ */ p("button", {
								type: "button",
								className: `tembo-action-button ${y === "build" ? "is-selected" : ""}`,
								disabled: !t?.emptySquares.length,
								onClick: () => de("build"),
								children: h("games.tembo.build")
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								className: `tembo-action-button ${y === "footprint" ? "is-selected" : ""}`,
								disabled: !(t?.patterns[String(I)] ?? []).some((e) => e.r === b),
								onClick: () => de("footprint"),
								children: h("games.tembo.elephants")
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								className: `tembo-action-button ${y === "single" ? "is-selected" : ""}`,
								disabled: !z.length,
								onClick: () => de("single"),
								children: h("games.tembo.single")
							}),
							R && /* @__PURE__ */ m("button", {
								type: "button",
								className: "tembo-action-button",
								onClick: () => {
									oe((b + 1) % 4), S(null);
								},
								"aria-label": h("games.tembo.rotateThis"),
								children: ["↻ ", ze[b]]
							})
						] }),
						I !== null && !x && L?.type === "matriarch" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("button", {
							type: "button",
							className: "tembo-action-button is-primary",
							onClick: () => de("matriarch"),
							children: h("games.tembo.matriarch")
						}), /* @__PURE__ */ p("button", {
							type: "button",
							className: "tembo-action-button",
							onClick: () => {
								g({
									type: "matriarch",
									x: null,
									y: null
								}), v(null), ae(null);
							},
							children: h("games.tembo.matriarchStay")
						})] })
					]
				})
			] }),
			e.phase === "turn" && !M && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("div", {
				className: "tembo-actions-title",
				children: h("games.tembo.turnWait", { name: N(e.players[e.turn]?.rid ?? "") })
			}), /* @__PURE__ */ p("div", {
				className: "tembo-choice-note",
				children: h("games.tembo.waitHint")
			})] })
		]
	});
	return /* @__PURE__ */ m("div", {
		className: "tembo-screen",
		children: [/* @__PURE__ */ p(u, {
			adaptive: !0,
			className: "tembo-layout",
			banner: J,
			actions: be,
			actionsHeight: "tembo-action-slot h-[218px] short:h-[116px]",
			scroll: !1,
			overlay: /* @__PURE__ */ p("div", {
				className: "tembo-board-hint",
				children: ye
			}),
			children: _e
		}), ce && M && !e.pending && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("div", {
			className: "tembo-support-backdrop",
			onClick: () => le(!1)
		}), /* @__PURE__ */ m("div", {
			className: "tembo-support-sheet",
			children: [
				/* @__PURE__ */ m("div", {
					className: "tembo-support-head",
					children: [/* @__PURE__ */ p("span", { children: h("games.tembo.supportTitle") }), /* @__PURE__ */ p("span", { children: h("games.tembo.support", { n: e.supportTokens }) })]
				}),
				/* @__PURE__ */ p("div", {
					className: "tembo-support-options",
					children: We.map((e, t) => /* @__PURE__ */ m("button", {
						type: "button",
						className: "tembo-support-option",
						onClick: () => {
							g({
								type: "support",
								option: t
							}), le(!1), S(null);
						},
						children: [/* @__PURE__ */ p("span", {
							className: "tembo-support-symbol",
							children: Ke[t]
						}), /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p("strong", { children: h(e) }), /* @__PURE__ */ p("small", { children: h(Ge[t]) })] })]
					}, e))
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "tembo-action-button mt-3 w-full",
					onClick: () => le(!1),
					children: h("games.tembo.cancel")
				})
			]
		})] })]
	});
}
var Ue = [
	1,
	2,
	3,
	8,
	0,
	4,
	7,
	6,
	5
], We = [
	"games.tembo.supportEnergy",
	"games.tembo.supportElephants",
	"games.tembo.supportRotate",
	"games.tembo.supportPlace"
], Ge = [
	"games.tembo.supportHint0",
	"games.tembo.supportHint1",
	"games.tembo.supportHint2",
	"games.tembo.supportHint3"
], Ke = [
	"✦",
	"🐘",
	"↻",
	"⌾"
], qe = {
	0: "╲",
	1: "╱",
	2: "┃",
	3: "━",
	4: "☷",
	5: "☰",
	6: "∟"
}, Je = (e) => qe[e] ?? "·", Ye = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32, Xe = (e) => e[Math.floor(Ye() * e.length)], $ = (e, t) => `${e},${t}`;
function Ze(e) {
	let t = new Set(e.landmarks.filter((e) => e.x === null).map((e) => e.ref)), n = new Map(e.squares.filter((e) => e.kind === "landmark" && t.has(e.ref)).map((e) => [$(e.x, e.y), e.ref])), r = /* @__PURE__ */ new Set([...e.elephants.map((e) => $(e.x, e.y)), $(e.matriarch.x, e.matriarch.y)]), i = (e, t) => $(Math.floor(e / 3) * 3, Math.floor(t / 3) * 3), a = /* @__PURE__ */ new Map();
	for (let t of e.elephants) {
		let e = i(t.x, t.y);
		a.set(e, (a.get(e) ?? 0) + 1);
	}
	let o = (t, n, a) => {
		let o = i(t, n);
		for (let s of [
			-1,
			0,
			1
		]) for (let c of [
			-1,
			0,
			1
		]) {
			if (!s && !c) continue;
			let l = t + s, u = n + c;
			if (i(l, u) === o && e.cells[$(l, u)] === a && r.has($(l, u))) return !0;
		}
		return !1;
	};
	return (t, r) => {
		let s = e.cells[$(t, r)];
		if (s === void 0) return 0;
		let c = 1;
		if (e.destinationUnlocked && (s === 14 || s === 15)) c = 100;
		else if (s === 4 && n.has(i(t, r))) {
			let e = n.get(i(t, r));
			c = 20 + 6 * (4 - Math.min(y[e] ?? 4, 4)) + 8 * (a.get(i(t, r)) ?? 0);
		} else s in te && o(t, r, s) ? c = 10 : s === 2 && (c = 4);
		return s === 3 && --c, c;
	};
}
function Qe(e, t, n, r) {
	let i = e.players[n], a = e.pending;
	if (a) switch (a.kind) {
		case "choosePlayer": {
			let t = e.players.filter((e) => e.seat !== n);
			if (!t.length) return null;
			let i = (a.amount ?? 0) > 0, o = [...t].sort((e, t) => (i ? 1 : -1) * (e.rested + e.onBoard - (t.rested + t.onBoard)));
			return {
				type: "choosePlayer",
				seat: r ? Xe(t).seat : o[0].seat
			};
		}
		case "placeSingleFree": {
			if (!t.singleFree.length) return null;
			if (r) return {
				type: "placeSingleFree",
				...Xe(t.singleFree)
			};
			let n = Ze(e), i = [...t.singleFree].sort((e, t) => n(t.x, t.y) - n(e.x, e.y))[0];
			return {
				type: "placeSingleFree",
				x: i.x,
				y: i.y
			};
		}
		case "matriarch": {
			if (!t.matriarchTargets.length) return {
				type: "matriarch",
				x: null,
				y: null
			};
			let n = Ze(e), r = [...t.matriarchTargets].sort((e, t) => n(t.x, t.y) - n(e.x, e.y))[0];
			return n(r.x, r.y) >= 4 ? {
				type: "matriarch",
				x: r.x,
				y: r.y
			} : {
				type: "matriarch",
				x: null,
				y: null
			};
		}
		case "soloMatriarch": return {
			type: "soloMatriarch",
			discard: !0
		};
	}
	let o = t.hand, s = o.filter((e) => _[e].type === "matriarch"), c = o.filter((e) => _[e].type === "savanna");
	if (r) {
		let e = [];
		for (let n of t.emptySquares) c.length && e.push({
			type: "placeCard",
			cardId: c[0],
			x: n.x,
			y: n.y,
			rotation: i.rotation ?? 0
		});
		for (let [n, r] of Object.entries(t.patterns)) for (let t of r) e.push({
			type: "placeElephants",
			cardId: Number(n),
			x: t.x,
			y: t.y,
			rotation: t.r
		});
		for (let n of t.single) c.length && e.push({
			type: "placeSingle",
			cardId: c[0],
			x: n.x,
			y: n.y
		});
		return s.length && e.push({
			type: "matriarch",
			x: null,
			y: null
		}), e.length ? Xe(e) : null;
	}
	if (e.energy <= 4 && e.supportTokens > 0) return {
		type: "support",
		option: 0
	};
	let l = Ze(e);
	if (s.length === 1) {
		let e = t.matriarchTargets.length ? [...t.matriarchTargets].sort((e, t) => l(t.x, t.y) - l(e.x, e.y))[0] : null, n = e ? l(e.x, e.y) : 0;
		if (n >= 8 && i.onBoard <= 4 || i.onBoard <= 2) return n >= 4 && e ? {
			type: "matriarch",
			x: e.x,
			y: e.y
		} : {
			type: "matriarch",
			x: null,
			y: null
		};
	}
	let u = {
		12: 5,
		13: 4,
		11: 3,
		10: 2,
		14: 3
	};
	if (c.length && t.emptySquares.length && i.rested <= 3) {
		let n = [...t.emptySquares].sort((t, n) => {
			let r = u[e.squares.find((e) => e.x === t.x && e.y === t.y)?.ref ?? 0] ?? 0;
			return (u[e.squares.find((e) => e.x === n.x && e.y === n.y)?.ref ?? 0] ?? 0) - r;
		})[0];
		return {
			type: "placeCard",
			cardId: c[0],
			x: n.x,
			y: n.y,
			rotation: i.rotation ?? 0
		};
	}
	let d = null;
	for (let [e, n] of Object.entries(t.patterns)) for (let t of n) {
		let n = t.cells.reduce((e, t) => e + t.amount, 0);
		if (n > i.rested) continue;
		let r = t.cells.reduce((e, t) => e + l(t.x, t.y), 0);
		(!d || r > d.v || r === d.v && n < d.cost) && (d = {
			cardId: Number(e),
			x: t.x,
			y: t.y,
			r: t.r,
			v: r,
			cost: n
		});
	}
	if (d && d.v >= 4) return {
		type: "placeElephants",
		cardId: d.cardId,
		x: d.x,
		y: d.y,
		rotation: d.r
	};
	if (c.length && i.rested > 0 && t.single.length) {
		let e = t.single.filter((e) => e.amount <= i.rested).map((e) => ({
			c: e,
			v: l(e.x, e.y)
		})).sort((e, t) => t.v - e.v)[0];
		if (e && e.v >= 4) return {
			type: "placeSingle",
			cardId: c[0],
			x: e.c.x,
			y: e.c.y
		};
	}
	if (c.length && t.emptySquares.length) {
		let e = t.emptySquares[0];
		return {
			type: "placeCard",
			cardId: c[0],
			x: e.x,
			y: e.y,
			rotation: i.rotation ?? 0
		};
	}
	if (d) return {
		type: "placeElephants",
		cardId: d.cardId,
		x: d.x,
		y: d.y,
		rotation: d.r
	};
	if (c.length && i.rested > 0 && t.single.length) {
		let e = t.single.find((e) => e.amount <= i.rested);
		if (e) return {
			type: "placeSingle",
			cardId: c[0],
			x: e.x,
			y: e.y
		};
	}
	return s.length ? {
		type: "matriarch",
		x: null,
		y: null
	} : null;
}
var $e = (e, t) => {
	let n = e.public;
	if (n.phase === "won" || n.phase === "lost") return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	if (n.phase === "orient") return r.rotation === null ? { action: {
		type: "orient",
		rotation: 0
	} } : null;
	if (n.phase === "reorient") return { action: { type: "passRotate" } };
	if (n.turn !== r.seat) return null;
	let i = e.private;
	if (!i) return null;
	let a = Qe(n, i, r.seat, t.difficulty === "weak");
	return a ? { action: a } : null;
};
//#endregion
//#region src/games/tembo/game-over.tsx
function et(e) {
	return /* @__PURE__ */ p("div", {
		className: "tembo-over",
		children: /* @__PURE__ */ p(ee, {
			hintCount: e.hintCount,
			result: e.result,
			members: e.members,
			myRid: e.myRid,
			accent: se.accent,
			onPlayAgain: e.onPlayAgain,
			onBackToLobby: e.onBackToLobby
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tembo/entry.tsx
var tt = {
	definition: Fe,
	View: Ve,
	bot: $e,
	OverView: et,
	locales: {
		zh: {
			name: "草原征途",
			desc: "带领象群穿越草原抵达目的地,合作对抗狮群与枯竭的牌堆",
			rules: "目标:访问全部地标解锁终点板,并让两个终点格上都有象,全员即获胜。\n设置:\n· 按旅程拼好起点板、草原版图块与终点板。\n· 每人领取自己的象群:全部疲惫,先休整 3 只。\n· 按玩家人数设置共享能量，按难度领取支持标记，并将支援卡洗入抽牌堆顶部。\n开局:\n· 每人先选择自己本局的坐向,它决定打出草原卡的默认旋转。\n· 随后，任意玩家可以支付2点能量，旋转一块版图块。有人执行旋转后，立即开始游戏；没有人旋转时，所有玩家确认后开始游戏。\n回合:当前玩家执行一个行动,然后补牌至上限(多人 3 张、单人 4 张):\n· 建设草原：将一张草原卡铺到空的方格，并结算该格的奖励，使象休整或免费放置象。\n· 按脚印放置象：根据草原卡的脚印形状，在版图上放置象；新放置的象必须与版图上已有的象或女族长相邻。\n· 普通格消耗 1 只象、粗糙格 2 只,带红划爪印的卡无视粗糙地形;放完弃掉该卡。\n· 弃牌放置象：弃置一张草原卡，在象群的相邻格放置1只象；粗糙格需要2只象。\n· 打出女族长卡：将女族长移到象群相邻的任意空格。\n· 然后收拢象群，将版图上的象全部收回象群，并转为疲惫状态。将树重新立起，失去2点能量，再翻开一张事件牌。\n· 同时打出两张女族长卡时，失去5点能量。\n支持标记：可以使用任意次数，每次选择以下一种效果。\n· 获得1点能量。\n· 休整2只象。\n· 使下一张卡可以自由旋转。\n· 无视地形，放置1只象。\n放象结算:\n· 盖住水塘休整 3 只象。\n· 覆盖树格，且配对格中已有棋子时，树会倒下。绿树提供 2 点能量，其他树提供 1 点能量。\n· 地标区全部格有象时访问该地标。\n补牌触发:\n· 手牌有两张女族长卡时必须立即打出。\n· 抽到狮子卡时两只狮子依次激活:卧倒的起身,站立的向最近的象或女族长移动一格。\n· 狮子所在方格的象被吃掉;与女族长同格时每人移除 1 只象。\n发生以下任一情况时，所有玩家共同失败：\n· 抽牌堆耗尽。\n· 能量降至零。\n· 两只狮子与女族长位于同一格。\n· 任一玩家的象全部被移除。\n· 轮到某名玩家时，该玩家没有合法行动。",
			orientTitle: "选择坐向",
			orientHint: "坐向决定你打出草原卡的默认旋转,开局后不可更改",
			orientDone: "已选择,等待其他玩家",
			reorientTitle: "调整版图",
			reorientHint: "任何人可支付 2 能量旋转一块版图块;有人旋转或全员放弃即开始",
			rotateThis: "旋转此块",
			reorientHintShort: "选一块版图旋转，消耗 2 能量",
			confirmRotate: "确认旋转",
			passRotate: "保持现状",
			dir0: "朝上",
			dir1: "朝右",
			dir2: "朝下",
			dir3: "朝左",
			energy: "能量 {{n}}",
			support: "支持 {{n}}",
			deck: "牌堆 {{n}}",
			energyLabel: "能量",
			supportLabel: "支持",
			deckLabel: "牌堆",
			journeyProgress: "已访地标 {{n}}",
			mapOverview: "全图",
			mapFocus: "放大",
			turnYou: "轮到你",
			turnWait: "等待 {{name}}",
			supportRotateOn: "本回合卡可自由旋转",
			build: "建草原",
			elephants: "放象",
			single: "弃卡放象",
			matriarch: "打女族长",
			matriarchStay: "不移动",
			cancel: "取消",
			pickSquare: "点选一个空格放置此卡",
			pickCell: "点选一个高亮格",
			noTargets: "当前行动没有合法目标",
			treeStanding: "树木立起",
			treeFallen: "树木倒下",
			destinationLocked: "访问全部地标后解锁终点",
			selectCardHint: "先选一张手牌",
			chooseActionHint: "选择行动，再点选版图目标",
			confirmHint: "确认当前目标",
			waitHint: "观察版图，等待下一回合",
			yourHand: "手牌",
			costElephants: "需要 {{n}} 只象",
			confirmPlace: "确认放置",
			confirmElephants: "确认放象",
			changeTarget: "重新选择",
			savannaCard: "草原",
			lionCard: "狮子",
			supportTitle: "使用支持标记",
			supportHint0: "补充共享能量",
			supportHint1: "休整自己的象群",
			supportHint2: "下一张草原卡可自由旋转",
			supportHint3: "无视粗糙地形放象",
			supportEnergy: "+1 能量",
			supportElephants: "+2 休整象",
			supportRotate: "下张卡自由旋转",
			supportPlace: "无视地形放 1 象",
			chooseGain: "选择一名其他玩家获得 {{n}} 只休整象",
			chooseLose: "选择一名其他玩家失去 {{n}} 只休整象",
			freePlace: "无视粗糙地形放 1 只象",
			matriarchForced: "手牌有两张女族长卡,必须打出",
			soloMatriarchTitle: "两张女族长",
			soloMatriarchHint: "每局一次:可以弃掉一张女族长卡,避免触发双女族长",
			soloDiscard: "弃一张",
			soloKeep: "照常打出",
			bonus10: "全员 +2 象",
			bonus11: "另一玩家 +4 象",
			bonus12: "自己 +5 / 另一玩家 -2",
			bonus13: "自己 +3 并放 1 象",
			bonus14: "+4 象",
			spaceOasis: "水塘",
			spaceRough: "粗糙",
			spaceLandmark: "地标",
			spaceDestination: "终点",
			treeGreen: "绿树",
			treeRed: "红树",
			treeBrown: "棕树",
			treeTeal: "青树",
			landmark0: "雪丘",
			landmark1: "草甸",
			landmark2: "河流",
			landmark3: "岩群",
			landmark4: "峡谷",
			landmark5: "瀑布",
			lionDown: "卧",
			ev0: "持续:青树提供 2 能量",
			ev1: "持续:棕树提供 2 能量",
			ev2: "闪电:青树倒下",
			ev3: "闪电:绿树倒下",
			ev4: "闪电:棕树倒下",
			ev5: "持续:水塘 +5 象",
			ev6: "闪电:全体 -2 休整象",
			ev7: "持续:粗糙地形只需 1 象",
			ev8: "持续:水塘不得象",
			ev9: "持续:不可无视粗糙地形",
			ev10: "闪电:失去 1 枚支持标记",
			ev11: "闪电:母狮激活",
			ev12: "闪电:雄狮激活",
			ev13: "闪电:红树倒下",
			ev14: "闪电:每人移除 1 只象",
			ev15: "闪电:双狮卧倒",
			ev16: "持续:粗糙地形需 3 象",
			ev17: "闪电:+1 能量",
			ev18: "持续:红树提供 2 能量",
			ev19: "持续:草原卡不可旋转",
			winText: "象群抵达目的地,全员获胜!",
			lose1: "抽牌堆耗尽,远征失败",
			lose2: "能量归零,远征失败",
			lose3: "两只狮子追上了女族长,远征失败",
			lose4: "有玩家象群全灭,远征失败",
			lose5: "没有任何合法行动,远征失败",
			errOver: "本局已结束",
			errNotPlaying: "你不在本局座位中",
			errPhase: "当前阶段不能这样做",
			errNotYourTurn: "还没轮到你",
			errCard: "这张卡不在手牌或不能这样用",
			errCell: "目标格不可用",
			errRotation: "这张卡不能这样旋转",
			errElephants: "休整象不足",
			errSupport: "支持标记不足",
			errPending: "请先完成当前抉择"
		},
		en: {
			name: "TEMBO",
			desc: "Lead your elephant herds across the savanna to the destination — a co-op race against lions and a draining deck",
			rules: "Goal: visit every landmark to unlock the destination board, then occupy both destination spaces with elephants to win together.\nSetup:\n· Build the journey with the start board, savanna tiles and destination board.\n· Each player takes their herd: all tired, rest 3 first.\n· Shared energy depends on player count; support tokens and support cards scale with difficulty.\nOpening:\n· Each player picks a sitting direction, which sets the default rotation of the savanna cards they play.\n· Then anyone may pay 2 energy to rotate one savanna tile; the game starts once someone does, or everyone declines.\nTurn: the active player performs one action, then draws back up to the hand limit (3 cards, 4 solo):\n· Build savanna: place a savanna card on an empty square and trigger its bonus (rested elephants or a free placement).\n· Place elephants: use a card’s footprint shape to place elephants adjacent to the herd on the board or the Matriarch.\n· Normal spaces cost 1 elephant, rough spaces cost 2; cards with the red-claw mark ignore rough terrain; discard the card afterwards.\n· Discard to place: discard a savanna card to place 1 elephant on a herd-adjacent space (2 on rough).\n· Play a Matriarch card: optionally move the Matriarch to any herd-adjacent free space.\nAfter resolving the Matriarch card, gather the herd: return all elephants on the board to their home herd and turn them tired. Stand the trees back up, lose 2 energy and reveal an event tile.\n· Playing two Matriarch cards together costs 5 energy.\nSupport tokens:\nYou may spend support tokens any number of times. Each time, choose one effect:\n· Gain 1 energy.\n· Rest 2 elephants.\n· Freely rotate your next card.\n· Place 1 elephant, ignoring terrain.\nPlacement rewards:\n· Covering a water space rests 3 elephants.\n· Covering a tree space whose paired space is already occupied fells the tree: green trees give 2 energy, others 1.\n· Filling every space of a landmark area visits that landmark.\nDraw triggers:\n· Holding two Matriarch cards forces you to play them.\n· A drawn lion card activates both lions in turn: lying lions stand up, standing lions move one square toward the nearest elephant or the Matriarch.\n· Elephants in a lion’s square are eaten; sharing a square with the Matriarch removes 1 elephant per player.\nAll players lose if any of the following occurs:\n· The deck runs out.\n· Energy reaches zero.\n· Both lions share a square with the Matriarch.\n· Any player loses their entire herd.\n· A player has no legal action on their turn.",
			orientTitle: "Choose your seat direction",
			orientHint: "Your direction sets the default rotation of the savanna cards you play; it cannot change later",
			orientDone: "Chosen — waiting for the others",
			reorientTitle: "Adjust the board",
			reorientHint: "Anyone may pay 2 energy to rotate one savanna tile; the game starts once someone does or everyone declines",
			rotateThis: "Rotate this tile",
			reorientHintShort: "Choose a tile to rotate for 2 energy",
			confirmRotate: "Confirm rotation",
			passRotate: "Keep as is",
			dir0: "Up",
			dir1: "Right",
			dir2: "Down",
			dir3: "Left",
			energy: "Energy {{n}}",
			support: "Support {{n}}",
			deck: "Deck {{n}}",
			energyLabel: "Energy",
			supportLabel: "Support",
			deckLabel: "Deck",
			journeyProgress: "{{n}} landmarks visited",
			mapOverview: "Overview",
			mapFocus: "Zoom in",
			turnYou: "Your turn",
			turnWait: "Waiting for {{name}}",
			supportRotateOn: "Cards rotate freely this turn",
			build: "Build",
			elephants: "Herd",
			single: "Place 1",
			matriarch: "Matriarch",
			matriarchStay: "Stay put",
			cancel: "Cancel",
			pickSquare: "Tap an empty square to place this card",
			pickCell: "Tap a highlighted space",
			noTargets: "No legal target for this action",
			treeStanding: "Tree standing",
			treeFallen: "Tree fallen",
			destinationLocked: "Visit every landmark to unlock the destination",
			selectCardHint: "Choose a card first",
			chooseActionHint: "Choose an action, then tap a target on the board",
			confirmHint: "Confirm the selected target",
			waitHint: "Watch the board while you wait for the next turn",
			yourHand: "Hand",
			costElephants: "{{n}} elephants needed",
			confirmPlace: "Confirm placement",
			confirmElephants: "Place elephants",
			changeTarget: "Choose again",
			savannaCard: "Savanna",
			lionCard: "Lion",
			supportTitle: "Use a support token",
			supportHint0: "Restore shared energy",
			supportHint1: "Rest your elephants",
			supportHint2: "Freely rotate your next savanna card",
			supportHint3: "Place an elephant ignoring rough terrain",
			supportEnergy: "+1 energy",
			supportElephants: "+2 rested",
			supportRotate: "Free rotation",
			supportPlace: "Place 1 anywhere",
			chooseGain: "Choose another player to gain {{n}} rested elephants",
			chooseLose: "Choose another player to lose {{n}} rested elephants",
			freePlace: "Place 1 elephant ignoring rough terrain",
			matriarchForced: "Two Matriarch cards in hand — you must play them",
			soloMatriarchTitle: "Two Matriarchs",
			soloMatriarchHint: "Once per game: you may discard one Matriarch card to avoid a double Matriarch",
			soloDiscard: "Discard one",
			soloKeep: "Play both",
			bonus10: "All +2 elephants",
			bonus11: "Another player +4",
			bonus12: "You +5 / another -2",
			bonus13: "You +3 and place 1",
			bonus14: "+4 elephants",
			spaceOasis: "Water",
			spaceRough: "Rough",
			spaceLandmark: "Landmark",
			spaceDestination: "Destination",
			treeGreen: "Green tree",
			treeRed: "Red tree",
			treeBrown: "Brown tree",
			treeTeal: "Teal tree",
			landmark0: "Snow mound",
			landmark1: "Meadow",
			landmark2: "River",
			landmark3: "Rocks",
			landmark4: "Canyon",
			landmark5: "Waterfall",
			lionDown: "down",
			ev0: "Ongoing: teal trees give 2 energy",
			ev1: "Ongoing: brown trees give 2 energy",
			ev2: "Instant: the teal tree falls",
			ev3: "Instant: the green tree falls",
			ev4: "Instant: the brown tree falls",
			ev5: "Ongoing: water gives +5 elephants",
			ev6: "Instant: all players -2 rested elephants",
			ev7: "Ongoing: rough terrain costs 1 elephant",
			ev8: "Ongoing: water gives no elephants",
			ev9: "Ongoing: rough terrain cannot be ignored",
			ev10: "Instant: lose 1 support token",
			ev11: "Instant: the lioness activates",
			ev12: "Instant: the lion activates",
			ev13: "Instant: the red tree falls",
			ev14: "Instant: each player removes 1 elephant",
			ev15: "Instant: both lions lie down",
			ev16: "Ongoing: rough terrain costs 3 elephants",
			ev17: "Instant: +1 energy",
			ev18: "Ongoing: red trees give 2 energy",
			ev19: "Ongoing: savanna cards cannot be rotated",
			winText: "The herds reached their destination — you all win!",
			lose1: "The draw deck ran out — the journey fails",
			lose2: "Energy hit zero — the journey fails",
			lose3: "Both lions caught the Matriarch — the journey fails",
			lose4: "A player lost their whole herd — the journey fails",
			lose5: "No legal action available — the journey fails",
			errOver: "This game is over",
			errNotPlaying: "You are not seated in this game",
			errPhase: "Not allowed in this phase",
			errNotYourTurn: "Not your turn yet",
			errCard: "That card is not in your hand or cannot be used this way",
			errCell: "That space is not available",
			errRotation: "That card cannot be rotated this way",
			errElephants: "Not enough rested elephants",
			errSupport: "Not enough support tokens",
			errPending: "Finish the current choice first"
		}
	}
};
//#endregion
export { tt as default };
