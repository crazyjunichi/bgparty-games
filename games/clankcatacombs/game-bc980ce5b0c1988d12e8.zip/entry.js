import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useEffect as r, useId as i, useLayoutEffect as a, useMemo as o, useRef as s, useState as c, useSyncExternalStore as l } from "react";
import { BottomSheet as u } from "@bgparty/sdk/bottom-sheet";
import { useT as d } from "@bgparty/sdk/i18n";
import { useWakeLock as f } from "@bgparty/sdk/use-wake-lock";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { PLAYER_COLORS as v } from "@bgparty/sdk/player-colors";
import { SheetView as y } from "@bgparty/sdk/sheet-view";
import { useFxAnchor as b, useFxAnchorsMaybe as x } from "@bgparty/sdk/fx/anchors";
import { usePrefersReducedMotion as S } from "@bgparty/sdk/fx/use-reduced-motion";
import { ResilientCanvas as C } from "@bgparty/sdk/three/resilient-canvas";
import { useFrame as w, useThree as ee } from "@react-three/fiber";
import { BufferGeometry as te, CanvasTexture as T, DoubleSide as E, Float32BufferAttribute as D, LinearFilter as ne, RawShaderMaterial as O, ShapeUtils as k, Vector2 as A, Vector3 as re, Vector4 as ie } from "three";
import { IconClose as ae } from "@bgparty/sdk/icons";
import { OptionRadio as oe, OptionSection as se, OptionSwitch as j } from "@bgparty/sdk/ui/game-options";
//#region src/games/clankcatacombs/card-values.ts
var M = [
	{
		id: "skeleton-priest",
		name: "Skeleton Priest",
		pack: "base",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "darkened-alcove",
		name: "Darkened Alcove",
		pack: "base",
		copies: 2,
		type: "device",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "lie-in-wait",
		name: "Lie in Wait",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 2,
		swords: 1,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "smash-and-grab",
		name: "Smash and Grab",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "bard",
		name: "Bard",
		pack: "base",
		copies: 2,
		type: "companion",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "expert-guide",
		name: "Expert Guide",
		pack: "base",
		copies: 2,
		type: "companion",
		cost: 5,
		skill: 2,
		swords: 0,
		boots: 2,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "skeleton",
		name: "Skeleton",
		pack: "base",
		copies: 3,
		type: "monster",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "robbery",
		name: "Robbery",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 5,
		skill: 0,
		swords: 2,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "swindle",
		name: "Swindle",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "arcoverlord",
		name: "Arcoverlord",
		pack: "base",
		copies: 3,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "pillage",
		name: "Pillage",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 2,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "scavenger",
		name: "Scavenger",
		pack: "base",
		copies: 2,
		type: "companion",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "lightstick",
		name: "Lightstick",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 3,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "sneak-attack",
		name: "Sneak Attack",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 3,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "white-tourmaline",
		name: "White Tourmaline",
		pack: "base",
		copies: 2,
		type: "gem",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "black-tourmaline",
		name: "Black Tourmaline",
		pack: "base",
		copies: 1,
		type: "gem",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 5,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "flamboyance",
		name: "Flamboyance",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "rebel-scribe",
		name: "Rebel Scribe",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 1,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "bandit",
		name: "Bandit",
		pack: "base",
		copies: 2,
		type: "companion",
		cost: 4,
		skill: 1,
		swords: 1,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "underground-river",
		name: "Underground River",
		pack: "base",
		copies: 2,
		type: "device",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "spectral-rider",
		name: "Spectral Rider",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "librarian",
		name: "Librarian",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "rebel-general",
		name: "Rebel General",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 2,
		swords: 1,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "rebel-paladin",
		name: "Rebel Paladin",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 1,
		swords: 1,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "rebel-thief",
		name: "Rebel Thief",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "imp-familiar",
		name: "Imp Familiar",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "floating-skull",
		name: "Floating Skull",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 6,
		skill: 2,
		swords: 1,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "charlatan",
		name: "Charlatan",
		pack: "base",
		copies: 2,
		type: "companion",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "empurror",
		name: "Empurror",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "curator",
		name: "Curator",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "corrupt-advisor",
		name: "Corrupt Advisor",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !0,
		danger: !0,
		trophy: !1
	},
	{
		id: "rose-quartz",
		name: "Rose Quartz",
		pack: "base",
		copies: 2,
		type: "gem",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 4,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "smoky-quartz",
		name: "Smoky Quartz",
		pack: "base",
		copies: 1,
		type: "gem",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "fiery-quartz",
		name: "Fiery Quartz",
		pack: "base",
		copies: 1,
		type: "gem",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 5,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "waystone",
		name: "Waystone",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "brave-hero",
		name: "Brave Hero",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 2,
		swords: 1,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "remove-traps",
		name: "Remove Traps",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 2,
		skill: 1,
		swords: 2,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "sudden-movement",
		name: "Sudden Movement",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 1,
		swords: 0,
		boots: 2,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "souldrinker",
		name: "Souldrinker",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 4,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "shadow-walk",
		name: "Shadow Walk",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "thirst-for-adventure",
		name: "Thirst for Adventure",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 7,
		skill: 0,
		swords: 0,
		boots: 3,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "riot",
		name: "Riot",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 1,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "astral-projection",
		name: "Astral Projection",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "diversion",
		name: "Diversion",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 5,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "elven-sword",
		name: "Elven Sword",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 0,
		swords: 2,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "payoff",
		name: "Payoff",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 1,
		skill: 3,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "double-cross",
		name: "Double Cross",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "blink-spell",
		name: "Blink Spell",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 8,
		skill: 3,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "lute",
		name: "Lute",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "divining-rod",
		name: "Divining Rod",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "expensive-taste",
		name: "Expensive Taste",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 3,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "golden-flute",
		name: "Golden Flute",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "grand-theft",
		name: "Grand Theft",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "boots-of-the-ape-lords",
		name: "Boots of the Ape Lords",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 3,
		points: 3,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "crystal-compass",
		name: "Crystal Compass",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "animated-wall",
		name: "Animated Wall",
		pack: "base",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "ogre-merchant",
		name: "Ogre Merchant",
		pack: "base",
		copies: 2,
		type: "monster",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "keymaster",
		name: "Keymaster",
		pack: "base",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "thieves-shrine",
		name: "Thieves' Shrine",
		pack: "base",
		copies: 2,
		type: "device",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "locked-trunk",
		name: "Locked Trunk",
		pack: "base",
		copies: 1,
		type: "device",
		cost: 100,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "wishing-well",
		name: "Wishing Well",
		pack: "base",
		copies: 1,
		type: "device",
		cost: 100,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !0,
		trophy: !1
	},
	{
		id: "skeletal-ape",
		name: "Skeletal Ape",
		pack: "base",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "the-warden",
		name: "The Warden",
		pack: "base",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !0,
		trophy: !1
	},
	{
		id: "black-market",
		name: "Black Market",
		pack: "base",
		copies: 1,
		type: "device",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "crystal-kobold",
		name: "Crystal Kobold",
		pack: "base",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "skeleton-warlock",
		name: "Skeleton Warlock",
		pack: "base",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "dusty-map",
		name: "Dusty Map",
		pack: "base",
		copies: 1,
		type: "device",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "marble-guardian",
		name: "Marble Guardian",
		pack: "base",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "skulker",
		name: "Skulker",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 2,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "scuffler",
		name: "Scuffler",
		pack: "party",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "royal-brat",
		name: "Royal Brat",
		pack: "party",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 2,
		swords: 2,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "elven-satchel",
		name: "Elven Satchel",
		pack: "party",
		copies: 2,
		type: "basic",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "flawed-emerald",
		name: "Flawed Emerald",
		pack: "party",
		copies: 1,
		type: "gem",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 4,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "assassin",
		name: "Assassin",
		pack: "party",
		copies: 2,
		type: "companion",
		cost: 4,
		skill: 0,
		swords: 2,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "spiritual-healer",
		name: "Spiritual Healer",
		pack: "party",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "walk-it-off",
		name: "Walk It Off",
		pack: "party",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "flawed-sapphire",
		name: "Flawed Sapphire",
		pack: "party",
		copies: 1,
		type: "gem",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "berserker",
		name: "Berserker",
		pack: "party",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 1,
		swords: 1,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "scouting-ahead",
		name: "Scouting Ahead",
		pack: "party",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "one-with-everything",
		name: "One With Everything",
		pack: "party",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 1,
		swords: 1,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "virtuoso-burglar",
		name: "Virtuoso Burglar",
		pack: "party",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "hiding-place",
		name: "Hiding Place",
		pack: "party",
		copies: 2,
		type: "device",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "time-warp",
		name: "Time Warp",
		pack: "party",
		copies: 1,
		type: "basic",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "spotter",
		name: "Spotter",
		pack: "party",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !0,
		trophy: !1
	},
	{
		id: "cutpurse",
		name: "Cutpurse",
		pack: "party",
		copies: 2,
		type: "companion",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "secret-passage",
		name: "Secret Passage",
		pack: "party",
		copies: 1,
		type: "device",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "tactician",
		name: "Tactician",
		pack: "party",
		copies: 1,
		type: "companion",
		cost: 6,
		skill: 3,
		swords: 2,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "too-bad-for-you",
		name: "Too Bad for You",
		pack: "party",
		copies: 2,
		type: "basic",
		cost: 1,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "flawed-ruby",
		name: "Flawed Ruby",
		pack: "party",
		copies: 1,
		type: "gem",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 5,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "pixie-swarm",
		name: "Pixie Swarm",
		pack: "party",
		copies: 2,
		type: "monster",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "ape-lord-phantasm",
		name: "Ape Lord Phantasm",
		pack: "party",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "rebel-herald",
		name: "Rebel Herald",
		pack: "party",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "leprechaun",
		name: "Leprechaun",
		pack: "party",
		copies: 1,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "succubus",
		name: "Succubus",
		pack: "party",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "magic-kazoo",
		name: "Magic Kazoo",
		pack: "lairs",
		copies: 1,
		type: "device",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !0,
		danger: !1,
		trophy: !0
	},
	{
		id: "unlock-potential",
		name: "Unlock Potential",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "thirst-for-knowledge",
		name: "Thirst for Knowledge",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 3,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "tome-of-fire",
		name: "Tome of Fire",
		pack: "lairs",
		copies: 2,
		type: "basic",
		cost: 4,
		skill: 2,
		swords: 2,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "jailer",
		name: "Jailer",
		pack: "lairs",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !0,
		trophy: !1
	},
	{
		id: "amethyst",
		name: "Amethyst",
		pack: "lairs",
		copies: 1,
		type: "gem",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "swashbuckling",
		name: "Swashbuckling",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 2,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "loot-chute",
		name: "Loot Chute",
		pack: "lairs",
		copies: 1,
		type: "device",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "heart-of-the-dark",
		name: "Heart of the Dark",
		pack: "lairs",
		copies: 1,
		type: "device",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !0
	},
	{
		id: "cave-bat-wings",
		name: "Cave Bat Wings",
		pack: "lairs",
		copies: 1,
		type: "device",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !0
	},
	{
		id: "jailbreaker",
		name: "Jailbreaker",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 3,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "pack-rat",
		name: "Pack Rat",
		pack: "lairs",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "false-bottom",
		name: "False Bottom",
		pack: "lairs",
		copies: 1,
		type: "device",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "acrobatics",
		name: "Acrobatics",
		pack: "lairs",
		copies: 2,
		type: "basic",
		cost: 1,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "skeleton-troubadour",
		name: "Skeleton Troubadour",
		pack: "lairs",
		copies: 1,
		type: "monster",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "pit-fiend",
		name: "Pit Fiend",
		pack: "lairs",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "silver-arch",
		name: "Silver Arch",
		pack: "lairs",
		copies: 2,
		type: "device",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "forage",
		name: "Forage",
		pack: "lairs",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 1,
		swords: 1,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "swords-and-sorcery",
		name: "Swords and Sorcery",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 2,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "alarm",
		name: "Alarm",
		pack: "lairs",
		copies: 1,
		type: "device",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !0,
		trophy: !1
	},
	{
		id: "mechanical-donkey",
		name: "Mechanical Donkey",
		pack: "lairs",
		copies: 1,
		type: "device",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !0
	},
	{
		id: "artifact-detector",
		name: "Artifact Detector",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 1,
		swords: 0,
		boots: 2,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "spelunker",
		name: "Spelunker",
		pack: "lairs",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 3,
		swords: 0,
		boots: 1,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "negotiator",
		name: "Negotiator",
		pack: "lairs",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 2,
		swords: 1,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "devotion",
		name: "Devotion",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 7,
		skill: 2,
		swords: 0,
		boots: 2,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "rebel-messenger",
		name: "Rebel Messenger",
		pack: "lairs",
		copies: 1,
		type: "companion",
		cost: 6,
		skill: 1,
		swords: 0,
		boots: 2,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "swap-meet",
		name: "Swap Meet",
		pack: "lairs",
		copies: 2,
		type: "basic",
		cost: 2,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "cavern-prowler",
		name: "Cavern Prowler",
		pack: "lairs",
		copies: 1,
		type: "monster",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "venomous-lurker",
		name: "Venomous Lurker",
		pack: "lairs",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !0
	},
	{
		id: "ape-lord-epaulets",
		name: "Ape Lord Epaulets",
		pack: "lairs",
		copies: 1,
		type: "device",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !0
	},
	{
		id: "golden-hourglass",
		name: "Golden Hourglass",
		pack: "lairs",
		copies: 1,
		type: "device",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !0
	},
	{
		id: "quick-pick",
		name: "Quick Pick",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 2,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "merchants-guild-pin",
		name: "Merchant`s Guild Pin",
		pack: "lairs",
		copies: 1,
		type: "device",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !0,
		danger: !1,
		trophy: !0
	},
	{
		id: "monkey-paw",
		name: "Monkey Paw",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 1,
		swords: 1,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "skeleton-herald",
		name: "Skeleton Herald",
		pack: "lairs",
		copies: 1,
		type: "monster",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !0,
		trophy: !1
	},
	{
		id: "hoard-keeper",
		name: "Hoard Keeper",
		pack: "lairs",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !0
	},
	{
		id: "rebel-guard",
		name: "Rebel Guard",
		pack: "lairs",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 1,
		swords: 1,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "evil-wizard",
		name: "Evil Wizard",
		pack: "lairs",
		copies: 2,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !0
	},
	{
		id: "candelabra",
		name: "Candelabra",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 5,
		skill: 2,
		swords: 1,
		boots: 0,
		points: 3,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "ten-foot-pole",
		name: "Ten-Foot Pole",
		pack: "lairs",
		copies: 1,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "tinkerer",
		name: "Tinkerer",
		pack: "lairs",
		copies: 2,
		type: "companion",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "underworld-guide",
		name: "Underworld Guide",
		pack: "underworld",
		copies: 2,
		type: "companion",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "bunny-mafia",
		name: "Bunny Mafia",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 0,
		swords: 1,
		boots: 2,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "moneychangers-booth",
		name: "Moneychanger`s Booth",
		pack: "underworld",
		copies: 1,
		type: "device",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "catapult",
		name: "Catapult",
		pack: "underworld",
		copies: 1,
		type: "device",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "underground-spring",
		name: "Underground Spring",
		pack: "underworld",
		copies: 1,
		type: "device",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "mystic-elevator",
		name: "Mystic Elevator",
		pack: "underworld",
		copies: 1,
		type: "device",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "magic-mirror",
		name: "Magic Mirror",
		pack: "underworld",
		copies: 1,
		type: "device",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "shifting-shadow",
		name: "Shifting Shadow",
		pack: "underworld",
		copies: 1,
		type: "monster",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "harpy-matriarch",
		name: "Harpy Matriarch",
		pack: "underworld",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !0
	},
	{
		id: "chimera",
		name: "Chimera",
		pack: "underworld",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "cyclops",
		name: "Cyclops",
		pack: "underworld",
		copies: 2,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "wild-boar",
		name: "Wild Boar",
		pack: "underworld",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !0,
		trophy: !1
	},
	{
		id: "abyssal-hydra",
		name: "Abyssal Hydra",
		pack: "underworld",
		copies: 1,
		type: "monster",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "grave-robber",
		name: "Grave Robber",
		pack: "underworld",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "nether-titan",
		name: "Nether Titan",
		pack: "underworld",
		copies: 1,
		type: "monster",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 5,
		dragon: !1,
		danger: !1,
		trophy: !0
	},
	{
		id: "gray-knight",
		name: "Gray Knight",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 2,
		swords: 2,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "underworld-dealer",
		name: "Underworld Dealer",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "george",
		name: "George",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 1,
		swords: 1,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "sculptor",
		name: "Sculptor",
		pack: "underworld",
		copies: 2,
		type: "companion",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "soothsayer",
		name: "Soothsayer",
		pack: "underworld",
		copies: 2,
		type: "companion",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "orpheus",
		name: "Orpheus",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 7,
		skill: 0,
		swords: 0,
		boots: 2,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "hero-of-prophecy",
		name: "Hero of Prophecy",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 6,
		skill: 2,
		swords: 1,
		boots: 1,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "oracle",
		name: "Oracle",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "rebel-tunnel-guide",
		name: "Rebel Tunnel Guide",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 2,
		skill: 0,
		swords: 1,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "rebel-rouser",
		name: "Rebel Rouser",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 1,
		swords: 2,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "spellblade-invoker",
		name: "Spellblade Invoker",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 0,
		swords: 2,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "apprentice-thief",
		name: "Apprentice Thief",
		pack: "underworld",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 1,
		swords: 1,
		boots: 0,
		points: 1,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "polished-garnet",
		name: "Polished Garnet",
		pack: "underworld",
		copies: 1,
		type: "gem",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 4,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "garnet",
		name: "Garnet",
		pack: "underworld",
		copies: 1,
		type: "gem",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "fire-breath",
		name: "Fire Breath",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 2,
		skill: 1,
		swords: 1,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "escape-plan",
		name: "Escape Plan",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 2,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "jet-slippers",
		name: "Jet Slippers",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "tome-of-intellect",
		name: "Tome of Intellect",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "tome-of-the-ape-lords",
		name: "Tome of the Ape Lords",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 3,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "soul-prism",
		name: "Soul Prism",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "ethereal-step",
		name: "Ethereal Step",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "thunderstriker",
		name: "Thunderstriker",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 3,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "slink",
		name: "Slink",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "acid-splash",
		name: "Acid Splash",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "quick-trip",
		name: "Quick Trip",
		pack: "underworld",
		copies: 2,
		type: "basic",
		cost: 5,
		skill: 1,
		swords: 0,
		boots: 2,
		points: 2,
		dragon: !0,
		danger: !1,
		trophy: !1
	},
	{
		id: "burial-urn",
		name: "Burial Urn",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 4,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "wealth-of-knowledge",
		name: "Wealth of Knowledge",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 5,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "lantern",
		name: "Lantern",
		pack: "underworld",
		copies: 2,
		type: "basic",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "utility-knife",
		name: "Utility Knife",
		pack: "underworld",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 1,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "big-ideas",
		name: "Big Ideas",
		pack: "underworld",
		copies: 1,
		type: "basic",
		cost: 2,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "burgle",
		name: "Burgle",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "stumble",
		name: "Stumble",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "sidestep",
		name: "Sidestep",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "scramble",
		name: "Scramble",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "explore",
		name: "Explore",
		pack: "reserve",
		copies: 0,
		type: "basic",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "mercenary",
		name: "Mercenary",
		pack: "reserve",
		copies: 0,
		type: "companion",
		cost: 2,
		skill: 1,
		swords: 2,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "tome",
		name: "Secret Tome",
		pack: "reserve",
		copies: 0,
		type: "basic",
		cost: 7,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 7,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "psyfoot",
		name: "Psyfoot",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "cattitude",
		name: "Cattitude",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "saunter",
		name: "Saunter",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "ransack",
		name: "Ransack",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "scavenge",
		name: "Scavenge",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "wallop",
		name: "Wallop",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 0,
		swords: 2,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "primacy",
		name: "Primacy",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "persist",
		name: "Persist",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "bolt",
		name: "Bolt",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "collection",
		name: "Collection",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "competition",
		name: "Competition",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "exhibit",
		name: "Exhibit",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "rebel-squire",
		name: "Rebel Squire",
		pack: "starter",
		copies: 0,
		type: "companion",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "inspire",
		name: "Inspire",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "defensive-position",
		name: "Defensive Position",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "channel",
		name: "Channel",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "study",
		name: "Study",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	},
	{
		id: "mystic-slide",
		name: "Mystic Slide",
		pack: "starter",
		copies: 0,
		type: "basic",
		cost: 0,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		trophy: !1
	}
], ce = (e) => e.players[e.active], le = (e, t) => e.players.find((e) => e.rid === t);
function ue() {
	return {
		skill: 0,
		swords: 0,
		boots: 0,
		stopped: !1,
		noiseMade: 0,
		goldGained: 0,
		flags: [],
		visited: [],
		underworld: !1,
		defeated: 0,
		negativeClank: 0,
		triggers: [],
		spells: [],
		events: [],
		agnet: !1,
		damaged: [],
		springUsed: !1,
		totals: {},
		moved: 0,
		tunnels: 0,
		freed: 0,
		watchers: []
	};
}
var N = (e, t, n) => ({
	op: "gain",
	resource: e,
	n: t,
	...n ? { who: n } : {}
}), P = (e, t) => ({
	op: "special",
	id: e,
	...t === void 0 ? {} : { n: t }
}), F = (e, ...t) => ({
	op: "when",
	condition: e,
	effects: t
}), de = (e, t) => ({
	op: "choice",
	kind: e,
	options: t.map(([e, t]) => ({
		id: e,
		effects: t
	}))
}), I = (e = 1) => ({
	op: "draw",
	n: e
}), fe = (e) => ({
	op: "flag",
	flag: e
}), pe = {
	stumble: { play: [N("clank", 1)] },
	tome: { tome: !0 },
	"astral-projection": { play: [F("skill6", P("remote-shrine"))] },
	"blink-spell": { play: [de("blink", [["teleport", [P("teleport")]], ["swap", [P("swap-depths")]]])] },
	"boots-of-the-ape-lords": { play: [N("clank", 3), F("idol", fe("ignoreCave"))] },
	"crystal-compass": { play: [I(2), fe("ignoreCave")] },
	diversion: {
		arrive: [P("black", 3)],
		acquire: [P("prisoner")]
	},
	"divining-rod": { play: [F("skill6", N("heal", 1))] },
	"double-cross": {
		play: [N("clank", -2)],
		acquire: [N("clank", 2, "others")]
	},
	"elven-sword": { play: [I()] },
	"expensive-taste": { play: [N("gold", 2)] },
	flamboyance: { play: [I(), F("noise2", N("skill", 2))] },
	"golden-flute": { play: [
		N("gold", 1),
		N("clank", 1),
		P("flute")
	] },
	"grand-theft": {
		play: [de("theft", [["pick", [N("picks", 1)]], ["steal", [P("theft-row")]]])],
		acquire: [P("deck-top")]
	},
	"lie-in-wait": {
		play: [F("cave", N("clank", -2))],
		acquire: [P("deck-top")]
	},
	lightstick: { play: [N("clank", 1)] },
	lute: { play: [
		N("clank", 1),
		I(2),
		P("noise-gold")
	] },
	payoff: { play: [P("trash-self")] },
	pillage: { play: [F("gold3", I())] },
	"remove-traps": { play: [P("replace")] },
	riot: {
		play: [N("clank", 1), F("prisoner3", P("trash"))],
		acquire: [P("prisoner")]
	},
	robbery: {
		play: [N("gold", 2), F("market", P("teleport"))],
		acquire: [P("deck-top")]
	},
	"shadow-walk": { play: [P("trash-burgle")] },
	"smash-and-grab": { play: [N("clank", 2), I(2)] },
	"sneak-attack": {
		play: [N("clank", -2)],
		acquire: [N("swords", 1)]
	},
	souldrinker: { play: [F("defeated", N("heal", 1))] },
	"sudden-movement": { arrive: [P("rotate-lone")] },
	swindle: { play: [N("gold", 3)] },
	"thirst-for-adventure": { acquire: [N("boots", 3)] },
	waystone: { play: [P("waystone")] },
	"black-tourmaline": {
		play: [I()],
		acquire: [N("clank", 2)]
	},
	"white-tourmaline": {
		play: [I()],
		acquire: [N("clank", 2)]
	},
	"rose-quartz": {
		play: [N("clank", -2), I()],
		acquire: [N("clank", 2)]
	},
	"smoky-quartz": {
		play: [N("clank", -2), I()],
		acquire: [N("clank", 2)]
	},
	"fiery-quartz": {
		play: [N("clank", -2), I()],
		acquire: [N("clank", 2)]
	},
	bandit: { acquire: [N("boots", 1), N("swords", 1)] },
	bard: { play: [N("clank", 1), F("noise2", N("heal", 2))] },
	charlatan: { play: [P("discard-draw2")] },
	"corrupt-advisor": { play: [N("clank", 1, "others"), F("crown", N("clank", 1, "others"))] },
	curator: { play: [P("draw-artifacts")] },
	empurror: { play: [de("empurror", [
		["quiet", [N("clank", -2)]],
		["gold", [N("gold", 1)]],
		["caves", [fe("ignoreCave")]]
	]), F("artifact", P("empurror-extra"))] },
	"floating-skull": {
		play: [F("crown", P("teleport"))],
		acquire: [P("teleport")]
	},
	"imp-familiar": { play: [de("familiar", [["pick", [N("picks", 1)]], ["draw", [P("pay-pick-draw2")]]])] },
	librarian: { play: [N("clank", -2), F("tome", I(2))] },
	"rebel-general": { play: [F("companion", I())] },
	"rebel-paladin": { play: [F("companion", I()), F("artifact", I())] },
	"rebel-scribe": { play: [F("companion", I())] },
	"rebel-thief": { play: [N("picks", 1), F("companion", I())] },
	scavenger: { acquire: [P("minor")] },
	"spectral-rider": { play: [F("haunted", P("teleport-any-other-tile"))] },
	skulker: {
		play: [fe("ignoreMonsters")],
		acquire: [fe("ignoreMonsters")]
	},
	"black-market": { play: [P("black-market")] },
	"darkened-alcove": { play: [N("clank", -2)] },
	"dusty-map": { play: [P("place-anywhere")] },
	"locked-trunk": { play: [
		N("picks", -1),
		P("pick-event"),
		P("major")
	] },
	"thieves-shrine": {
		arrive: [P("black", 3)],
		play: [de("shrine", [["gold", [N("gold", 2)]], ["trash", [P("trash-burgle"), P("trash-burgle")]]])]
	},
	"underground-river": { play: [de("river", [["heal", [N("heal", 1)]], ["boot", [N("boots", 1)]]])] },
	"wishing-well": { play: [P("pay3-draw2")] },
	"animated-wall": {
		arrive: [P("rotate-occupied")],
		play: [N("boots", 1), F("portal", N("boots", 1))]
	},
	arcoverlord: {
		arrive: [N("clank", 1, "all")],
		play: [I(2), N("clank", 1, "others")]
	},
	"skeleton-warlock": { play: [P("tome"), N("clank", 1)] },
	"crystal-kobold": {
		cave: !0,
		play: [N("skill", 2)]
	},
	keymaster: { play: [N("picks", 1)] },
	"marble-guardian": { play: [P("place-adjacent")] },
	"the-warden": {
		deep: !0,
		play: [P("prisoner"), P("prisoner")]
	},
	"ogre-merchant": { play: [de("merchant", [["gold", [N("gold", 5)]], ["market", [P("free-market-here")]]])] },
	skeleton: { play: [N("gold", 2), N("clank", 1)] },
	"skeletal-ape": { play: [
		N("skill", 3),
		N("gold", 3),
		N("clank", 3)
	] },
	"skeleton-priest": {
		arrive: [N("clank", 1, "all")],
		play: [N("heal", 1), N("clank", 1)]
	},
	"ape-lord-phantasm": { play: [I(2), P("phantasm")] },
	leprechaun: {
		arrive: [P("leprechaun-all")],
		play: [P("leprechaun")]
	},
	"pixie-swarm": {
		arrive: [P("pixie")],
		play: [N("gold", 1)]
	},
	scuffler: { play: [P("scuffler")] },
	spotter: { play: [N("clank", -2), P("spotter")] },
	succubus: { play: [
		N("heal", 1),
		N("gold", 3),
		P("succubus")
	] },
	"hiding-place": {
		arrive: [P("offer-burgle-all")],
		play: [N("swords", 2)]
	},
	"secret-passage": {
		arrive: [P("offer-tome-all")],
		play: [N("clank", -2), N("boots", 2)]
	},
	assassin: {
		play: [N("clank", -2)],
		react: "monster-arrive"
	},
	berserker: {
		play: [P("noise-swords")],
		react: "goblin"
	},
	cutpurse: {
		play: [de("cutpurse", [["boot", [N("boots", 1)]], ["gold", [N("gold", 2)]]]), P("discard-optional-draw")],
		react: "enter-market"
	},
	"rebel-herald": {
		play: [F("companion", I())],
		react: "row-companions2"
	},
	"royal-brat": {
		play: [F("crown", P("minor"))],
		react: "secrets2"
	},
	"spiritual-healer": {
		play: [F("gem", N("heal", 1), N("clank", 1))],
		arrive: [P("healer-all")]
	},
	tactician: { react: "spaces3" },
	"virtuoso-burglar": {
		arrive: [P("offer-burgle-discard-all")],
		play: [N("clank", -2), P("trash-burgle")]
	},
	"scouting-ahead": {
		play: [fe("ignoreCave")],
		react: "end-cave"
	},
	"time-warp": {
		play: [P("teleport")],
		react: "end-still"
	},
	"flawed-sapphire": {
		play: [I()],
		acquire: [N("clank", 2), N("clank", 1, "others")]
	},
	"flawed-emerald": {
		play: [I()],
		acquire: [N("clank", 2), N("clank", 1, "others")]
	},
	"flawed-ruby": {
		play: [I()],
		acquire: [N("clank", 2), N("clank", 1, "others")]
	},
	"elven-satchel": {
		arrive: [P("offer-draw-all")],
		play: [N("gold", 2), I()]
	},
	"walk-it-off": {
		acquire: [N("heal", 1)],
		react: "dragon-damage"
	},
	"one-with-everything": {
		play: [N("gold", 1)],
		react: "device"
	},
	"too-bad-for-you": { react: "end-noise2" },
	amethyst: {
		play: [N("clank", -2), I()],
		acquire: [N("clank", 2)]
	},
	"ten-foot-pole": { play: [I(), fe("reroll-tile")] },
	"monkey-paw": { play: [N("clank", 1), F("idol", P("trash"))] },
	"thirst-for-knowledge": { play: [N("clank", 1)] },
	"swords-and-sorcery": {
		arrive: [P("return-artifact")],
		play: [I(), F("swords4", P("teleport"))]
	},
	swashbuckling: { play: [P("tunnel-gold")] },
	tinkerer: { play: [fe("device-discount2")] },
	"cave-bat-wings": { trophy: !0 },
	"tome-of-fire": { tome: !0 },
	jailbreaker: { play: [F("freed", I())] },
	"artifact-detector": {
		arrive: [P("return-artifact")],
		play: [fe("reroll-no-artifact")]
	},
	"swap-meet": { play: [P("swap-meet")] },
	"quick-pick": { play: [F("pick-spent", I())] },
	forage: { play: [N("gold", 1)] },
	"rebel-messenger": {
		play: [F("companion", I())],
		acquire: [N("boots", 1)]
	},
	"pack-rat": { play: [P("acquire4-backpack")] },
	"ape-lord-epaulets": {
		trophy: !0,
		play: [N("clank", 3)]
	},
	candelabra: { play: [F("marks3", N("heal", 1))] },
	"unlock-potential": { play: [de("potential", [["draw", [I()]], ["trophy", [P("trash-trophy-draw3")]]])] },
	spelunker: { play: [N("clank", 1)] },
	"rebel-guard": {
		play: [F("companion", I())],
		acquire: [N("swords", 1)]
	},
	negotiator: { play: [fe("market-discount2")] },
	alarm: { play: [N("clank", 1, "others")] },
	"silver-arch": { play: [P("teleport-lair")] },
	"merchants-guild-pin": { trophy: !0 },
	"venomous-lurker": {
		trophy: !0,
		play: [N("gold", 3)]
	},
	"heart-of-the-dark": {
		trophy: !0,
		points: -2
	},
	"false-bottom": { play: [N("picks", 1), F("pit", N("gold", 3))] },
	"magic-kazoo": {
		trophy: !0,
		play: [P("kazoo")]
	},
	"pit-fiend": { play: [
		N("gold", 2),
		N("clank", 1),
		F("pit", P("prisoner"))
	] },
	jailer: { play: [N("picks", 1), P("prisoner")] },
	"hoard-keeper": {
		trophy: !0,
		play: [N("gold", 3), N("clank", 1)]
	},
	"mechanical-donkey": { trophy: !0 },
	"loot-chute": { play: [N("gold", 2), N("boots", 2)] },
	"golden-hourglass": {
		trophy: !0,
		arrive: [P("return-artifact")]
	},
	"skeleton-herald": { play: [N("clank", 1), P("noise-gold-once")] },
	"skeleton-troubadour": { play: [P("minor"), N("clank", 1)] },
	"evil-wizard": { trophy: !0 },
	"cavern-prowler": { play: [P("acquire-any")] },
	"big-ideas": { play: [N("clank", 1), F("skill6", N("silver", 1))] },
	"utility-knife": {
		play: [I()],
		acquire: [N("silver", 1)]
	},
	lantern: { play: [N("silver", 1)] },
	"wealth-of-knowledge": { arrive: [N("silver", 1, "all")] },
	"quick-trip": {
		play: [F("small-artifact", fe("ignoreCave"))],
		acquire: [N("boots", 1), N("clank", 2)]
	},
	"acid-splash": { play: [P("acid")] },
	slink: {
		play: [N("clank", -2), I()],
		acquire: [N("boots", 1), N("clank", -2)]
	},
	thunderstriker: { play: [I()] },
	"ethereal-step": { play: [F("skill6", P("teleport"))] },
	"soul-prism": { acquire: [N("heal", 1)] },
	"tome-of-the-ape-lords": {
		play: [F("idol", fe("counts-tome"))],
		acquire: [N("clank", 3)]
	},
	"tome-of-intellect": {
		tome: !0,
		play: [I(2)]
	},
	"fire-breath": {
		play: [F("noise1", I())],
		acquire: [N("swords", 1)]
	},
	garnet: {
		play: [N("silver", 1), I()],
		acquire: [N("clank", 2)]
	},
	"polished-garnet": {
		play: [N("silver", 1), I()],
		acquire: [N("clank", 2)]
	},
	"apprentice-thief": { acquire: [N("picks", 1)] },
	"spellblade-invoker": { play: [N("clank", 1), P("teleport")] },
	"rebel-rouser": { play: [F("companion", I()), F("noise2", I())] },
	"rebel-tunnel-guide": { play: [F("companion", I())] },
	oracle: { play: [de("oracle", [["draw", [I()]], ["silver", [P("silver-draw2")]]])] },
	"hero-of-prophecy": { play: [F("fate", P("trash"))] },
	orpheus: {
		arrive: [P("black", 3)],
		acquire: [P("prisoner")],
		play: [N("clank", 1), N("silver", 1)]
	},
	soothsayer: {
		arrive: [P("offer-heal-gold-all")],
		play: [F("fate", N("skill", 1))]
	},
	sculptor: { play: [de("sculptor", [["trash", [P("trash-played")]], ["draw", [I()]]])] },
	george: { play: [
		N("clank", 1),
		I(),
		F("idol", N("skill", 1), N("swords", 1), N("clank", 1), I())
	] },
	"underworld-guide": {
		play: [F("underworld", I())],
		acquire: [N("silver", 1)]
	},
	"underworld-dealer": {
		play: [de("dealer", [["silver", [N("silver", 1)]], ["tome", [P("pay3-tome")]]])],
		acquire: [N("silver", 1)]
	},
	"gray-knight": { acquire: [N("silver", 1)] },
	"nether-titan": {
		trophy: !0,
		arrive: [P("titan-reserve")]
	},
	"grave-robber": {
		arrive: [P("rotate-occupied")],
		play: [N("silver", 1)]
	},
	"abyssal-hydra": {
		arrive: [P("hydra-stock")],
		play: [I(2), P("hydra-silver")]
	},
	"wild-boar": { play: [N("clank", 1), I(2)] },
	cyclops: {
		arrive: [N("clank", 1, "all")],
		play: [N("picks", 1), P("trash")]
	},
	chimera: {
		arrive: [N("clank", 1, "all")],
		play: [P("major"), N("clank", 1)]
	},
	"harpy-matriarch": { trophy: !0 },
	"shifting-shadow": { play: [fe("reverse-arrows")] },
	"magic-mirror": { play: [P("mirror")] },
	"mystic-elevator": { play: [N("clank", 1), P("teleport-underworld-market")] },
	"underground-spring": { play: [N("heal", 1), F("underworld", P("trash"))] },
	catapult: { play: [N("clank", 2), P("teleport")] },
	"moneychangers-booth": { play: [N("silver", 2)] },
	"bunny-mafia": { play: [N("gold", 1), P("steal-gold")] },
	psyfoot: { play: [fe("ignoreMonsters")] },
	cattitude: { play: [P("behavior")] },
	saunter: { play: [P("behavior-double")] },
	ransack: { react: "defeat" },
	scavenge: { play: [P("scavenge")] },
	primacy: { play: [F("idol", fe("ignoreCave"))] },
	persist: { play: [N("heal", 1), N("clank", 1)] },
	bolt: { play: [F("artifact", N("gold", 2), N("clank", 1))] },
	collection: {
		play: [N("gold", 1), P("finds-gold")],
		react: "find"
	},
	competition: {
		play: [P("finds-choice")],
		react: "find"
	},
	exhibit: {
		play: [P("finds-choice")],
		react: "find"
	},
	"rebel-squire": { play: [F("companion", I())] },
	inspire: { play: [fe("inspire")] },
	"defensive-position": { play: [F("cave", N("swords", 2))] },
	channel: { play: [N("mana", 1), P("channel")] },
	study: { play: [N("mana", 1), P("study")] },
	"mystic-slide": { play: [P("teleport")] }
}, me = /* @__PURE__ */ new Set([
	"dusty-map",
	"bunny-mafia",
	"jet-slippers",
	"magic-mirror",
	"nether-titan"
]), he = M.filter((e) => !me.has(e.id)).map((e) => ({
	...e,
	deep: !1,
	cave: !1,
	tome: !1,
	play: [],
	arrive: [],
	acquire: [],
	...pe[e.id]
})), L = Object.fromEntries(he.map((e) => [e.id, e])), ge = {
	adventurer: [
		"burgle",
		"sidestep",
		"scramble"
	],
	agnet: [
		"rebel-squire",
		"inspire",
		"defensive-position"
	],
	dallan: [
		"collection",
		"competition",
		"exhibit"
	],
	garignar: [
		"ransack",
		"scavenge",
		"wallop"
	],
	lenara: [
		"channel",
		"study",
		"mystic-slide"
	],
	monkeybot: [
		"primacy",
		"persist",
		"bolt"
	],
	whiskers: [
		"psyfoot",
		"cattitude",
		"saunter"
	]
}, _e = [
	[.5, 0],
	[1, .38],
	[.81, 1],
	[.19, 1],
	[0, .38]
], ve = {
	A: [3, 2],
	B: [4, 3],
	C: [0, 4],
	D: [1, 0],
	E: [2, 1]
};
function ye(e) {
	let t = ve[e];
	return [_e[t[0]], _e[t[1]]];
}
function be(e) {
	if (!/^[A-E][01]$/.test(e)) return;
	let [t, n] = ye(e[0]), r = e[1] === "0" ? .22 : .78;
	return [t[0] + (n[0] - t[0]) * r, t[1] + (n[1] - t[1]) * r];
}
function xe(e, t, n, r) {
	if (!e.slot) return [e.x + t, e.y + n];
	let [i, a] = ye(e.slot), o = a[0] - i[0], s = a[1] - i[1], c = Math.hypot(o, s);
	return [r.x + (i[0] + a[0]) / 2 + (t - .5) * 2 * o - n * .65 * s / c, r.y + (i[1] + a[1]) / 2 + (t - .5) * 2 * s + n * .65 * o / c];
}
//#endregion
//#region src/games/clankcatacombs/tiles.ts
function R(e, t, n, r, i = "") {
	return {
		id: e,
		pack: t,
		safe: i.includes("s"),
		haunted: i.includes("h"),
		width: 1,
		height: i.includes("2") ? 2 : 1,
		underworld: i.includes("u"),
		rooms: n.split(" ").filter(Boolean).map((e) => {
			let [t, n, r, i = ""] = e.split(":");
			return {
				id: t,
				x: n / 100,
				y: r / 100,
				features: i.split(",").filter(Boolean),
				...i.includes("safe") ? { safe: !0 } : {}
			};
		}),
		passages: r.split(" ").filter(Boolean).map((e) => {
			let [t, n, r = ""] = e.split(":");
			return {
				a: t,
				b: n,
				monsters: +(r.match(/m(\d)/)?.[1] ?? 0),
				extraBoots: +(r.match(/b(\d)/)?.[1] ?? 0),
				lock: r.includes("l"),
				oneWay: r.includes(">"),
				barrier: r.includes("a"),
				toll: +(r.match(/t(\d)/)?.[1] ?? 0),
				entry: r.includes("e")
			};
		})
	};
}
var Se = [
	"N0",
	"N1",
	"E0",
	"E1",
	"S1",
	"S0",
	"W1",
	"W0"
], Ce = {
	N0: [.25, 0],
	N1: [.75, 0],
	E0: [1, .25],
	E1: [1, .75],
	S0: [.25, 1],
	S1: [.75, 1],
	W0: [0, .25],
	W1: [0, .75],
	P: [.5, .5],
	Q: [.5, .8],
	R: [.7, .5]
}, z = [
	R("start-front", "base", "crypt:50:100:safe,crypt a:22:25:market b:68:25:idol c:50:137:safe d:50:180:cave,safe", "N1:b:m1 E0:b:> a:b a:W0 a:W1:m1 b:P:m1 E1:b:> crypt:c c:d W2:d:l W3:c:l E2:E3 S0:d:> d:S1", "s2"),
	R("start-back", "base", "crypt:50:100:safe,crypt a:22:25:wayshrine b:68:25:idol c:50:137:safe d:50:180:cave,safe", "N0:N1 N0:W0:m1 E0:b a:b a:W1:m1 a:W0:m1 b:E1:b1 crypt:c c:d W2:d W3:c E2:E3 S0:d:> d:S1:b1", "s2"),
	R("289", "base", "a:30:30:cave,chest b:72:25:minor c:30:75 d:72:75", "N0:W0:m1 N1:b E0:b:m1 a:c a:d c:d W1:c:l c:S0 d:S1 d:E1", "s"),
	R("292", "base", "a:25:25 b:75:30:cave,minor c:25:75 d:75:75:minor", "N0:a W0:a a:d E0:b b:N1:m1 b:c c:W1 d:E1:m1 d:S1:l", "s"),
	R("293", "base", "a:25:25:minor b:75:25:cave c:25:75:cave,chest d:75:75", "N0:a:> N1:b:> a:b a:c b:d b:E0 c:W1:m1 c:S0:> d:E1 S1:d:>", "s"),
	R("294", "base", "a:25:25:market b:75:25:cave,gold1 c:25:75:cave d:75:75:minor", "N0:a W0:a a:d:m1 c:W1 c:S0 d:S1 d:E1:m1", "s"),
	R("295", "base", "a:25:25:cave,minor b:75:25 c:75:75:prison", "W0:a a:b N1:b b:W1 c:W1:m1 c:E1:b1 c:S1:m1", "s"),
	R("296", "base", "a:50:20 b:50:55:cave,heal1 c:25:80 d:75:80:minor", "W0:a a:E0 b:c:> c:d d:b:> d:S1 d:E1:m1 W1:c", "s"),
	R("265", "base", "a:25:25 b:62:25:artifact1 c:25:75", "N0:a W0:a:> a:b:m1 b:N1:l b:E0:l b:E1:m3 a:c c:W1 c:S0 c:P a:S1:m1", ""),
	R("266", "base", "a:25:25:library b:75:25:cave,heal1 c:75:75:prison", "N0:a W0:a a:b b:N1 b:c c:E1:m1 c:S1:m1 W1:S0:m1"),
	R("267", "base", "a:30:25:wayshrine b:30:75:market c:75:75:cave,chest", "N0:a N1:a W0:a:b1 a:E0 a:b b:W1 b:c b:S0:m1 c:S1:m1"),
	R("268", "base", "a:50:50:gold3,chest", "N0:a:> N1:a:> W0:a:m2 W1:a:m2 E0:a:m2 E1:a:m2 S0:a:> S1:a:>"),
	R("269", "base", "a:50:40:artifact0 b:50:77:wayshrine", "N0:N1 W0:E0:m1 a:b:m1 a:b:l b:W1:m1 b:E1:m1 b:S0 b:S1"),
	R("270", "base", "a:50:25:prison b:50:75:prison", "N0:a W0:a a:b:m2 W1:b:m1 E1:b:m1 N1:E0 a:P"),
	R("271", "base", "a:50:36:prison b:50:78:minor", "N0:a:l N1:a:l W0:a:> E0:a:> a:b W1:b:> E1:b:> S0:b:m1 S1:b:m1 b:P", "h"),
	R("272", "base", "a:25:25:market,minor b:67:25:artifact0 c:50:75:wayshrine", "N0:a a:P:m1 N1:E0 b:c:> c:S0 c:S1:m2 E1:c:m2"),
	R("273", "base", "a:30:25:market b:30:75:chest c:75:75:cave,artifact0", "N0:a N1:a W0:a a:b a:c b:S0:b1 c:E0:m1 c:E1:m1 c:S1:m1"),
	R("274", "base", "a:25:25:cave b:70:35:artifact1 c:25:75:library d:75:75:cave,heal1", "N0:a N1:E0 a:b:b1 c:S0 c:b:l c:d d:E1:m1 d:S1:m1"),
	R("275", "base", "a:50:50:cave,heal1", "N0:W0:m1 N1:E0 a:W1 a:E1 a:S0 a:S1", "h"),
	R("276", "base", "a:25:35:artifact2 b:75:25:cave,heal1 c:75:75:cave,chest", "N0:W0:m1 N1:b b:E0 a:b:l> a:W1:m1 a:c:m2 b:c c:E1:m2 c:S1:l"),
	R("277", "base", "a:25:25:cave,minor b:75:25:market c:50:75:artifact0", "N0:a:m1 N1:b:l W0:a:> a:b b:E0 a:c:m1 c:W1:m2 c:E1:b1 c:S0 c:S1"),
	R("278", "base", "a:25:35:library b:50:20:wayshrine c:75:35:library d:50:75:minor", "N0:b N1:b b:a b:c a:W0 a:W1 c:E0 c:E1 a:c:m2 d:S0 d:S1", "h"),
	R("279", "base", "a:50:25:cave,minor b:75:55:library c:50:80:chest", "N0:a N1:a W0:a a:P b:Q c:R E0:b:m1 E1:b:m1 c:S1 c:S0 W1:Q:l"),
	R("280", "base", "a:25:25:chest b:75:25 c:70:75:cave,artifact0", "N0:a W0:a N1:a b:P b:E0 b:c a:S0:l W1:S1 c:E1:m1"),
	R("281", "base", "a:52:20:library,minor b:80:50:market c:22:50:wayshrine d:52:83:chest", "N0:S0:m1 N1:a W0:c W1:c a:d:m1 b:E0 b:E1 b:R:l d:S1"),
	R("305", "base", "a:70:25:wayshrine b:25:75:wayshrine", "N0:W0 N1:a a:b:m2 a:b:l b:W1 b:S0 E1:S1", "h"),
	R("306", "base", "a:25:25:cave,prison b:75:25:market c:50:75:minor,library", "N0:a N1:b a:b a:c:m1 c:b:b1 W1:c:> c:S0 c:S1:m1"),
	R("307", "base", "a:25:25:market b:75:40:cave,prison c:45:75:cave,artifact0", "N0:a N1:a a:b b:E0 c:W1:m1 c:S0:m1 c:S1"),
	R("308", "base", "a:25:25:prison b:75:25:cave,chest c:75:75", "N0:a W0:a:b1 a:j W1:j:m1 j:c b:N1 b:E0:m1 c:P c:E1 c:S1"),
	R("309", "base", "a:25:25:wayshrine b:75:50:library,gold1", "N0:a N1:b:m1 E0:b W0:a a:b b:P W1:S0:m1 S1:E1:m1"),
	R("2098", "lairs", "a:50:75:gold1,chest,prison", "N0:S0 N1:S1 W0:E0:a W1:a:m2 E1:a:m2", "s"),
	R("2109", "lairs", "a:50:25:minor b:25:75 c:70:75:pit", "N0:a W0:a:l E0:a:m1 a:b c:a:> W1:b:e b:S0 S1:c:e>", "s"),
	R("2110", "lairs", "a:50:50:aegis", "N0:a:a N1:P a:S0:e a:S1:e W0:E1:lm2 W1:E0:m1"),
	R("2111", "lairs", "a:50:55:medusa,minor,library,chest", "W0:N0 N1:E0 a:P:m1 a:E1:m2> a:W1:m1 a:S0:e a:S1:e"),
	R("2112", "lairs", "a:50:30:hoard,artifact0,gold5,clank2,chest b:30:75:minor c:75:75:pit,prison", "N0:N1 W0:a:> E0:a:> W1:b:m1 S0:b:e S1:c:e a:b a:c b:c"),
	R("2113", "lairs", "a:25:55:altar b:70:60:pit", "N0:a:> N1:b:e> W0:a:l W1:a a:S0:m2 b:E0 b:E1:l S1:b:e> b:P:m1", "h"),
	R("2114", "lairs", "a:50:35:sphinx,artifact1 b:25:80:cave,heal1 c:75:80:pit,library", "W0:a:m1 E0:a:m1 a:b a:c W1:b b:S0 c:E1 c:S1"),
	R("2115", "lairs", "a:25:25:pit b:50:65:statue,minor", "N0:a N1:E0:m2> a:b b:E0:m2 b:W1 b:E1:l b:S0:> b:S1:>"),
	R("2116", "lairs", "a:50:55:wayshrine,temple", "N0:N1 W0:a:e E0:a:l W1:a:e a:E1 a:S0:m1 S1:S0", "h"),
	R("2117", "lairs", "a:75:25:wayshrine b:30:75:pit", "N0:W0 N1:a a:b:m2 W1:b:e E1:b:l b:S0 b:S1", "h"),
	R("2118", "lairs", "a:50:35:artifact2,prison b:50:80:pit,minor", "N0:W0 N1:a W0:a a:E0 b:W1 b:E1:m1 b:S0:e b:S1:e N1:E1:l"),
	R("2119", "lairs", "a:50:55:bazaar", "N0:W0 N1:E0 a:P:m1 a:W1 a:E1 a:S0 a:S1"),
	R("2124", "underworld", "a:75:25:artifact0,harpy b:50:72:chute", "N0:b:> W0:b:m1 W1:b:> E1:b:> S0:b:m1> S1:b:m1> a:P a:E0"),
	R("2125", "underworld", "a:25:25:minor b:75:25:cave,silver1 c:25:75:ladderA d:75:75:tower", "N0:a W0:a:m1 a:b:m1 b:N1 b:c b:d c:S0 c:d:l d:E1 d:S1:m1"),
	R("2126", "underworld", "a:50:25:lake b:50:75:ladderB", "N0:W0 N1:E0:m1 a:b W1:b E1:b S0:b:m1 S1:b:m1"),
	R("2127", "underworld", "a:50:25:wayshrine b:25:75:market,silver1 c:75:75:cave,ladderC,chest", "N0:a:l N1:a:l W0:a:b1 E0:a:m2 a:c b:W1 b:c b:S0:m1 c:S1:m1", "h"),
	R("2128", "underworld", "a:25:25:artifact0,harpy b:60:75:cave,tower,ladderD,chest", "N0:a W0:a a:N1:b1 a:b W1:b:l E0:b:l E1:b:m1 S1:b:m1"),
	R("2129", "underworld", "a:25:30:ladderE b:75:75:tower,prison", "N0:a N1:P:m1 a:P:> a:b:b1 a:W0 b:W1 b:E1 b:S1:m1"),
	R("uw-center-front", "underworld", "guardian:43:48:guardian lyre:77:47:lyre library:50:24:library,imp prisoner:58:76:free-prisoner market:31:82:market", "A0:market A1:prisoner B0:j B1:market j:market:m1 j:guardian:b1 j:return return:library:b1 C0:library:m1 C1:library:b1 D1:library:> D0:lyre:l E0:lyre:> E1:prisoner guardian:lyre:b1", "u"),
	R("uw-center-back", "underworld", "guardian:78:45:guardian,cave lyre:50:45:lyre library:25:49:library,imp market:50:15:market idol:50:82:idol", "A0:idol:m1 A1:idol:> B0:library:b1 B1:j:b1 j:return j:idol C0:market C1:library:m1 D1:market D0:guardian:l E0:guardian E1:idol:b1 market:lyre:m1 lyre:library:l guardian:return:b1>", "u"),
	R("uw-8c398a", "underworld", "a:20:75:harpy,silver2 ladder:44:74:minor,market b:50:35:cave,minor c:77:75:fate", "I0:b I1:b L:a:m1 R:c:m1 a:ladder ladder:b ladder:c b:c:m1>", "uh"),
	R("uw-2715a9", "underworld", "ladder:24:72:minor a:39:37:fate b:65:35:cave,heal1 c:52:74:lake,harpy d:80:74:silver1", "I0:a:m1 I1:b L:a ladder:a:m1 ladder:c:m1> c:b d:c:b1 d:b R:b:m1 a:b:m1", "uh"),
	R("uw-11f9e9", "underworld", "a:20:75:cave,skill1 b:38:29:lake ladder:47:72:minor c:63:29:tower d:78:72:market,prison", "I0:b I1:c L:j j:b j:a:b1 b:a:m1 ladder:b:m1> ladder:c b:c:m1 c:k k:R k:d:m1", "u"),
	R("uw-8b82c9", "underworld", "a:20:75:cave,heal1 b:37:30:wayshrine ladder:51:74:minor c:66:29:lake d:80:75:cave,minor,harpy", "I0:b I1:c L:j j:b j:a:m1 a:ladder b:ladder c:ladder:b1 c:R:m1> c:d:b1 ladder:d", "u"),
	R("uw-72d322", "underworld", "a:21:74:skill1 b:38:30:wayshrine ladder:65:30:market c:52:75:fate,minor,harpy d:81:75:cave,heal1", "I0:b I1:ladder:m1 L:j j:b j:a:l a:c:m1 b:c c:d ladder:R R:d:l", "u"),
	R("uw-a3b137", "underworld", "a:23:75:skill1 b:30:37:fate c:51:43:wayshrine d:76:28:prison ladder:77:75:market", "I0:c I1:d L:j j:b j:a:> a:c:> c:d:m1 c:ladder:m1 d:R R:ladder:m1 c:b", "uh"),
	R("uw-4cc2f2", "underworld", "a:31:30:minor b:67:30:cave,gold1 ladder:31:74:minor c:53:74:tower d:78:74:prison3", "I0:a I1:b L:j j:a:m1 j:ladder:> a:b a:c c:ladder c:b:> b:R R:d:l> d:c", "u")
], we = Object.fromEntries(z.map((e) => [e.id, e]));
function Te(e, t, n) {
	for (let r = 0; r < n; r++) [e, t] = [1 - t, e];
	return [e, t];
}
function Ee(e, t) {
	let n = Se.indexOf(e);
	return n < 0 ? e : Se[(n + t * 2) % 8];
}
function De(e, t) {
	let n = e.rooms.find((e) => e.id === t);
	if (n) return [n.x, n.y];
	if (e.underworld) return be(t) || ({
		I0: [.36, 0],
		I1: [.64, 0],
		L: [.125, .5],
		R: [.875, .5],
		j: [.2, e.id.startsWith("uw-center") ? .62 : .45],
		k: [.78, .48],
		return: [.15, .5]
	}[t] ?? [.5, .5]);
	let r = Ce[t];
	return r ? t === "S0" || t === "S1" ? [r[0], e.height] : r : t === "j" ? [.25, .65] : t.startsWith("W") ? [0, 1 + (t[1] - 2) * .5 + .25] : [1, 1 + (t[1] - 2) * .5 + .25];
}
function B(e, t) {
	return `${e}/${t}`;
}
function V(e, t) {
	let [n, r] = t.split("/"), i = e.find((e) => e.id === +n), a = we[i.kind];
	return {
		tile: i,
		def: a.rooms.find((e) => e.id === r),
		tileDef: a
	};
}
function H(e, t, n) {
	return V(e, t).def.features.includes(n);
}
function Oe(e, t) {
	let n = V(e, t);
	return !!n.def.safe || n.tileDef.safe && !n.tile.kind.startsWith("start-");
}
//#endregion
//#region src/games/clankcatacombs/bank.ts
var ke = [
	"fool",
	"magician",
	"high-priestess",
	"empress",
	"emperor",
	"hierophant",
	"lovers",
	"chariot",
	"strength",
	"hermit",
	"wheel",
	"justice",
	"hanged-man",
	"death",
	"temperance",
	"imp",
	"tower",
	"star",
	"moon",
	"sun",
	"judgement",
	"world"
], Ae = [
	"egg",
	"egg",
	"egg",
	"pick",
	"pick",
	"pick",
	"spring",
	"spring",
	"heal1",
	"heal1",
	"heal1",
	"boots",
	"boots",
	"swords",
	"swords",
	"puzzlebox",
	"puzzlebox",
	"gold2",
	"gold2",
	"gold2"
], je = [
	"map",
	"chalice",
	"chalice",
	"chalice",
	"skill5",
	"skill5",
	"gold5",
	"gold5",
	"gold5",
	"heal2",
	"heal2"
], Me = [
	"barbarian",
	"barbarian",
	"primatologist",
	"sorceress",
	"sorceress",
	"cleric",
	"cleric",
	"haunted",
	"coupon",
	"warrior",
	"warrior",
	"adventurer",
	"adventurer",
	"prince",
	"princess",
	"monk",
	"peasant",
	"peasant",
	"monkeybot",
	"mayor"
], Ne = [
	"amulet-uw",
	"wind-boots",
	"gauntlets",
	"jester-cap",
	"riverboat"
], Pe = {
	medusa: {
		swords: 2,
		damage: 2
	},
	guardian: {
		swords: 3,
		damage: 2
	},
	harpy: {
		swords: 2,
		damage: 1
	}
}, Fe = (e, t) => V(e.tiles, t.room).tile.zone === "underworld", Ie = (e) => e.items.filter((e) => ["crown", "jester-cap"].includes(e.kind)).length, Le = (e) => e.artifacts.length > 0 || e.trophies.includes("guardian"), Re = (e) => e.gold + e.silver, ze = (e) => 1 + e.items.filter((e) => e.kind === "backpack").length + Number(e.revealedFates.includes("justice"));
function Be(e, t, n = Math.max(0, t - e.gold)) {
	e.silver -= n, e.gold -= t - n;
}
var Ve = (e, t, n) => Object.values(e.rooms).filter((e) => Object.entries(e.marks).some(([e, r]) => r === t.rid && (!n || e.startsWith(n)))).length, He = (e) => e.some((e) => [
	"medusa",
	"statue",
	"sphinx"
].includes(e)), Ue = (e) => e.some((e) => [
	"aegis",
	"altar",
	"bazaar",
	"temple",
	"hoard",
	"fate"
].includes(e)), We = /* @__PURE__ */ new WeakMap(), Ge = (e, t) => e.players.map((n) => ({
	rid: n.rid,
	values: {
		gold: n.gold,
		silver: n.silver,
		picks: n.picks,
		mana: n.mana,
		clank: n.clank,
		health: 10 - n.damage,
		artifact: n.artifacts.length,
		idol: n.idols.length,
		trophy: n.trophies.length,
		item: n.items.length,
		fate: n.fates.length,
		...n.rid === t.rid ? {
			skill: e.turn.skill,
			swords: e.turn.swords,
			boots: e.turn.boots,
			rage: e.rage,
			ghost: e.ghostClank,
			tile: e.tiles.length
		} : {}
	}
})), Ke = (e) => We.get(e)?.origin;
function qe(e, t, n, r = 1, i) {
	let a = Ke(e);
	if (!a || !r) return;
	let o = e.notices ??= [], s = o.find((e) => e.id === a.id);
	s || (s = {
		...a,
		revision: 0,
		results: []
	}, o.push(s));
	let c = s.results.find((e) => e.rid === t && e.kind === n && e.detail === i);
	c ? c.n += r : s.results.push({
		rid: t,
		kind: n,
		n: r,
		...i ? { detail: i } : {}
	}), s.revision = e.noticeSerial = (e.noticeSerial ?? 0) + 1, o.sort((e, t) => e.revision - t.revision), o.length > 24 && o.splice(0, o.length - 24);
}
function Je(e, t) {
	let n = Ge(e, t.origin);
	for (let r = 0; r < n.length; r++) for (let [i, a] of Object.entries(n[r].values)) qe(e, n[r].rid, i, a - t.before[r].values[i]);
}
function Ye(e, t, n) {
	let r = We.get(e);
	r && Je(e, r), t ? We.set(e, {
		origin: t,
		before: Ge(e, t)
	}) : We.delete(e);
	try {
		return n();
	} finally {
		let t = We.get(e);
		t && Je(e, t), r ? (r.before = Ge(e, r.origin), We.set(e, r)) : We.delete(e);
	}
}
function Xe(e, t, n, r, i) {
	let a = e.noticeSerial = (e.noticeSerial ?? 0) + 1, o = {
		id: a,
		rid: t.rid,
		card: n,
		verb: r
	}, s = e.notices ??= [];
	return s.push({
		...o,
		revision: a,
		results: []
	}), s.length > 24 && s.shift(), Ye(e, o, i);
}
var Ze = (e, t) => (e.notices ?? []).filter((e) => e.revision > t).map((e) => ({
	kind: "cc-action-notice",
	rid: e.rid,
	data: structuredClone(e)
})), Qe = [
	2,
	2,
	3,
	3,
	4,
	4,
	5
], $e = [
	2,
	2,
	2,
	2,
	3,
	3,
	4
], et = (t, n) => e(t.seed, t.cursor++, n);
function tt(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = et(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
var nt = (e, t) => ({
	uid: e.uid++,
	kind: t
});
function U(e, t, n, r, i = !1) {
	let a = Ke(e), o = r.map((e) => ({
		rid: t.rid,
		source: n,
		effect: e,
		...a ? { notice: a } : {}
	}));
	i ? e.queue.unshift(...o) : e.queue.push(...o);
}
function rt(e, t, n) {
	let r = 0;
	for (let i = 0; i < n; i++) {
		!t.deck.length && t.discard.length && (t.deck = tt(e, t.discard), t.discard = [], t.trophies.includes("golden-hourglass") && W(e, t, "gold", 1));
		let n = t.deck.shift();
		if (!n) break;
		t.hand.push(n), r++;
	}
	qe(e, t.rid, "draw", r);
}
function it(e, t, n) {
	if (t.state !== "active") return;
	let r = ce(e).rid === t.rid;
	if (n < 0) {
		let i = Math.min(t.clank, -n);
		t.clank -= i, t.supply += i, r && (e.turn.negativeClank += -n - i);
	} else {
		let i = r ? Math.min(e.turn.negativeClank, n) : 0;
		r && (e.turn.negativeClank -= i);
		let a = Math.min(t.supply, n - i);
		t.supply -= a, t.clank += a, r && (e.turn.noiseMade += a), a && G(e, "noise");
	}
}
function W(e, t, n, r) {
	t.state === "active" && (n === "clank" ? it(e, t, r) : n === "heal" ? at(e, t, r) : n === "mana" ? t.mana = Math.min(10, Math.max(0, t.mana + r)) : n === "gold" || n === "silver" || n === "picks" ? (t[n] = Math.max(0, t[n] + r), r > 0 && n === "gold" && t.rid === ce(e).rid && (e.turn.goldGained += r)) : (e.turn[n] = Math.max(0, e.turn[n] + r), r > 0 && (e.turn.totals[n] = (e.turn.totals[n] ?? 0) + r)));
}
function at(e, t, n) {
	if (t.trophies.includes("venomous-lurker") && H(e.tiles, t.room, "cave")) return;
	let r = Math.min(t.damage, n), i = Math.min(t.blackDamage, r);
	t.damage -= r, t.blackDamage -= i, e.blackRemoved += i, t.supply += r - i;
}
function ot(e, t, n = !1) {
	t.state === "active" && (t.state = n ? "escaped" : "knocked", t.mastery = n, e.log.push({
		event: n ? "escape" : "knockout",
		rid: t.rid
	}));
}
function st(e, t, n, r = "room") {
	if (t.state !== "active") {
		r === "bag" && (t.removed += n);
		return;
	}
	let i = Math.min(10 - t.damage, n);
	if (r === "bag") t.removed += n - i;
	else {
		let n = Math.min(t.supply, i);
		t.supply -= n, i > n && (t.blackDamage += i - n, e.blackExtra += Math.max(0, i - n - e.blackRemoved), e.blackRemoved = Math.max(0, e.blackRemoved - (i - n)));
	}
	t.damage += i, r !== "room" && i && G(e, `dragon-damage:${t.rid}`), r !== "room" && t.character === "monkeybot" && !e.turn.damaged.includes(t.rid) && (t.cogs = Math.min(7, t.cogs + 1), e.turn.damaged.push(t.rid)), e.log.push({
		event: "damage",
		rid: t.rid,
		n: i
	}), t.damage >= 10 && ot(e, t);
}
var ct = (e, t) => e.damage + t < 10 && e.supply >= t;
function G(e, t) {
	e.turn.events.includes(t) || e.turn.events.push(t), e.turn.totals[`event:${t}`] = (e.turn.totals[`event:${t}`] ?? 0) + 1;
}
function lt(e) {
	e.ghostBank && (e.ghostBank--, e.ghostClank++);
}
function ut(e, t = 1) {
	e.rage = Math.min(6, Math.max(0, e.rage + t));
}
function K(e, t, n, r, i) {
	if (!i.length) return;
	let a = Ke(e);
	e.choice = {
		rid: t.rid,
		source: n,
		kind: r,
		options: i.map((e) => ({
			action: e.action,
			effects: e.effects ?? []
		})),
		...a ? { notice: a } : {}
	};
}
var q = (e, t = [], n) => ({
	action: {
		type: "choose",
		option: e,
		...n === void 0 ? {} : { target: n }
	},
	effects: t
});
//#endregion
//#region src/games/clankcatacombs/acquire.ts
function dt(e, t) {
	let n = L[t];
	return Math.max(0, n.cost - (n.type === "device" ? e.turn.flags.filter((e) => e === "device-discount2").length * 2 : 0));
}
function ft(e, t, n) {
	let r = L[n];
	return !(r.deep && (Oe(e.tiles, t.room) || Fe(e, t)) || r.cave && !H(e.tiles, t.room, "cave") && !H(e.tiles, t.room, "wayshrine") || n === "locked-trunk" && t.picks < 1 || n === "wishing-well" && t.gold + t.silver < 3 || n === "harpy-matriarch" && !Fe(e, t));
}
function pt(e, t, n, r = "discard") {
	let i = L[n.kind].type;
	Xe(e, t, n.kind, i === "monster" ? "defeat" : i === "device" ? "device" : "acquire", () => mt(e, t, n, r));
}
function mt(e, t, n, r) {
	let i = L[n.kind], a = `${n.kind}#${n.uid}`;
	i.type === "monster" || i.type === "device" ? (i.trophy ? (t.trophies.push(n.kind), t.trophies.includes("heart-of-the-dark") && W(e, t, "clank", -2)) : e.dungeonDiscard.push(n), U(e, t, a, [
		N("skill", i.skill),
		N("swords", i.swords),
		N("boots", i.boots),
		...i.play
	]), i.type === "monster" ? (e.turn.defeated++, G(e, "defeat"), t.character === "garignar" && e.turn.defeated === 1 && U(e, t, a, [P("carnage")])) : G(e, "device")) : (r === "hand" ? t.hand.push(n) : r === "top" ? t.deck.unshift(n) : t.discard.push(n), U(e, t, a, i.acquire), (i.tome || n.kind === "tome-of-the-ape-lords" && t.idols.length) && (G(e, "acquire-tome"), t.imp && U(e, t, a, [P("imp-row"), P("imp-row")])), i.type === "companion" && t.character === "agnet" && t.conscription && r === "discard" && U(e, t, a, [{
		op: "special",
		id: "conscription",
		n: n.uid
	}])), e.log.push({
		event: i.type === "monster" ? "defeat" : i.type === "device" ? "device" : "acquire",
		rid: t.rid,
		card: n.kind
	});
}
function ht(e, t) {
	e.reserve.tome && (e.reserve.tome--, pt(e, t, nt(e, "tome")));
}
function gt(e, t, n, r = !1, i = !1) {
	let a = e.row[n], o = L[a.kind];
	if (r || (e.turn[o.type === "monster" ? "swords" : "skill"] -= dt(e, a.kind)), a.kind === "abyssal-hydra") {
		Xe(e, t, a.kind, "defeat", () => {
			let r = e.reserve.hydra ?? 0;
			if (r) {
				let i = Math.min(2, r);
				e.reserve.hydra -= i, W(e, t, "silver", i), e.reserve.hydra || (e.row[n] = null, e.dungeonDiscard.push(a));
			}
			rt(e, t, 2), e.turn.defeated++, G(e, "defeat"), t.character === "garignar" && e.turn.defeated === 1 && U(e, t, a.kind, [P("carnage")]), e.log.push({
				event: "defeat",
				rid: t.rid,
				card: a.kind
			});
		});
		return;
	}
	e.row[n] = null, pt(e, t, a, i ? "hand" : "discard");
}
var _t = (e, t) => Object.keys(e.market).filter((n) => Ne.includes(n) === Fe(e, t) && e.market[n].length && (!n.startsWith("amulet") || t.damage >= 5));
function vt(e, t, n = "") {
	return Math.max(0, 7 - e.turn.flags.filter((e) => e === "market-discount2").length * 2 - t.trophies.filter((e) => e === "merchants-guild-pin").length - (n === "coupon" ? 5 : n === "dark-iron" ? 3 : n.startsWith("flute:") ? 2 : 0));
}
function yt(e, t, n, r = 0, i = Math.max(0, r - t.gold)) {
	let a = Ie(t);
	Be(t, r, i);
	let o = e.market[n].shift();
	t.items.push({
		kind: n,
		points: o
	}), G(e, "market"), (n === "amulet" || n === "amulet-uw") && at(e, t, 2), n === "kit" && (t.picks += 2), n === "wind-boots" && W(e, t, "boots", 1), n === "river-lamp" && W(e, t, "silver", 3), n === "gauntlets" && U(e, t, n, [P("fate")]), !a && Ie(t) && (G(e, "crown"), G(e, "find")), Le(t) && G(e, "artifact-owned"), e.log.push({
		event: "market",
		rid: t.rid,
		token: n
	});
}
//#endregion
//#region src/games/clankcatacombs/movement.ts
function bt(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
	for (let r of e.tiles) {
		let i = we[r.kind], a = (e) => {
			let n = B(r.id, e);
			return t.has(n) || t.set(n, {
				tile: r,
				local: e,
				room: i.rooms.some((t) => t.id === e),
				portal: e === "return" || !i.underworld && [
					"P",
					"Q",
					"R"
				].includes(e),
				links: []
			}), n;
		};
		for (let e of i.rooms) a(e.id);
		for (let [n, o] of i.passages.entries()) {
			let i = a(o.a), s = a(o.b), c = `${r.id}:${n}`, l = o.lock && !e.openedLocks.includes(c);
			t.get(i).links.push({
				to: s,
				id: c,
				monsters: o.monsters,
				boots: o.extraBoots,
				lock: l,
				barrier: o.barrier,
				toll: o.toll,
				reverse: !1,
				entry: o.entry
			}), t.get(s).links.push({
				to: i,
				id: c,
				monsters: o.monsters,
				boots: o.extraBoots,
				lock: l,
				barrier: o.barrier,
				toll: o.toll,
				reverse: o.oneWay,
				entry: o.entry
			});
		}
		if (r.zone !== "underworld") for (let a of t.values()) {
			if (a.tile.id !== r.id || !/^[NESW]\d$/.test(a.local)) continue;
			let [o, s] = De(i, a.local), [c, l] = i.height === 1 ? Te(o, s, r.rotation) : [o, s], u = Ee(a.local.replace(/[23]$/, (e) => String(e - 2)), r.rotation), d = `${r.x + c},${r.y + l}`, f = n.get(d);
			if (f && f.tile.id !== r.id) {
				let e = t.get(f.key), n = a;
				e.links.push({
					to: B(r.id, a.local),
					id: `join:${d}`,
					monsters: 0,
					boots: 0,
					lock: !1,
					barrier: !1,
					toll: 0,
					reverse: !1,
					entry: !1
				}), n.links.push({
					to: f.key,
					id: `join:${d}`,
					monsters: 0,
					boots: 0,
					lock: !1,
					barrier: !1,
					toll: 0,
					reverse: !1,
					entry: !1
				}), delete e.frontier;
			} else {
				n.set(d, {
					key: B(r.id, a.local),
					worldPort: u,
					tile: r
				});
				let t = u[0], o = t === "W" ? r.x - 1 : t === "E" ? r.x + 1 : Math.floor(r.x + c), s = t === "N" ? r.y - 1 : t === "S" ? r.y + i.height : Math.floor(r.y + l);
				e.tiles.some((e) => e.zone === "catacombs" && o >= e.x && o < e.x + 1 && s >= e.y && s < e.y + we[e.kind].height) || (a.frontier = {
					x: o,
					y: s,
					port: `${{
						N: "S",
						S: "N",
						W: "E",
						E: "W"
					}[t]}${u[1]}`
				});
			}
		}
	}
	let r = [...t.entries()].filter(([, e]) => e.portal);
	for (let [e, t] of r) for (let [n, i] of r) e === n || i.local === "return" || t.tile.zone === "underworld" && t.local !== "return" || t.links.push({
		to: n,
		id: `portal:${e}:${n}`,
		monsters: 0,
		boots: 0,
		lock: !1,
		barrier: !1,
		toll: 0,
		reverse: !1,
		entry: !1
	});
	let i = e.tiles.find((e) => e.kind.startsWith("uw-center"));
	if (i) {
		let n = (t) => e.tiles.find((e) => e.slot === t), r = (e, r) => {
			let a = n(e), o = a ? B(a.id, r) : `uw-${e}/${r}`;
			return t.has(o) || t.set(o, {
				tile: a ?? i,
				local: r,
				room: !1,
				portal: !1,
				links: [],
				...a ? {} : { underworld: {
					slot: e,
					port: r
				} }
			}), o;
		}, a = (e, n) => {
			if (!t.has(e) || !t.has(n)) return;
			let r = {
				id: `uw:${e}:${n}`,
				monsters: 0,
				boots: 0,
				lock: !1,
				barrier: !1,
				toll: 0,
				reverse: !1,
				entry: !1
			};
			t.get(e).links.push({
				...r,
				to: n
			}), t.get(n).links.push({
				...r,
				to: e
			});
		};
		for (let [e, t] of [..."ABCDE"].entries()) {
			for (let e of [0, 1]) a(B(i.id, `${t}${e}`), r(t, `I${e}`));
			let o = "ABCDE"[(e + 1) % 5];
			(n(t) || n(o)) && a(r(t, "L"), r(o, "R"));
		}
	}
	return t;
}
function xt(e, t, n = !1, r) {
	let i = bt(e), a = [], o = r ?? t, s = (e, r, c, l, u, d, f, p, m) => {
		let h = i.get(e);
		if (!h || r.includes(e) || r.length > 60) return;
		let g = [...r, e];
		if (h.underworld) {
			a.push({
				id: g.join(">"),
				to: "",
				edges: c,
				monsters: l,
				boots: 1 + u,
				locks: d,
				toll: f,
				barrier: p,
				descend: h.underworld.slot,
				underworldPort: h.underworld.port
			});
			return;
		}
		if (e !== o && h.room) {
			e !== t && a.push({
				id: g.join(">"),
				to: e,
				edges: c,
				monsters: l,
				boots: 1 + u,
				locks: d,
				toll: f,
				barrier: p
			});
			return;
		}
		h.frontier && a.push({
			id: g.join(">") + ">?",
			to: "",
			edges: c,
			monsters: l,
			boots: 1 + u,
			locks: d,
			toll: f,
			barrier: p,
			discover: h.frontier
		});
		for (let e of h.links) {
			let t = e.id.startsWith("portal:");
			e.reverse && !n || t && m > 0 || s(e.to, g, [...c, e.id], l + e.monsters, u + e.boots, e.lock ? [...d, e.id] : d, f + e.toll, p || e.barrier, m + Number(t));
		}
	};
	return s(o, [], [], 0, 0, [], 0, !1, 0), a;
}
var St = (e, t) => e.items.some((e) => e.kind === t);
function Ct(e, t, n = !1) {
	let r = xt(e, t.room, n || t.tokens.includes("map")), i = V(e.tiles, t.room), a = i.def.features.find((e) => e.startsWith("ladder")), o = Array.isArray(e.rooms) ? e.rooms.find((e) => e.id === t.room) : e.rooms?.[t.room];
	if (i.tile.zone === "catacombs" && (a || i.def.features.includes("chute") || o?.chute)) {
		let t = a ? [a.slice(6)] : [
			"A",
			"B",
			"C",
			"D",
			"E"
		];
		for (let n of t) {
			let t = e.tiles.find((e) => e.slot === n), i = t ? B(t.id, "ladder") : "";
			r.push({
				id: `ladder:${n}`,
				to: i,
				edges: [],
				monsters: 0,
				boots: 1,
				locks: [],
				toll: 0,
				barrier: !1,
				...t ? {} : { descend: n }
			});
		}
	} else if (i.tile.slot && i.def.features.includes("ladder")) for (let t of e.tiles.filter((e) => e.zone === "catacombs")) for (let e of we[t.kind].rooms) e.features.includes(`ladder${i.tile.slot}`) && r.push({
		id: `ascend:${t.id}/${e.id}`,
		to: B(t.id, e.id),
		edges: [],
		monsters: 0,
		boots: 1,
		locks: [],
		toll: 0,
		barrier: !1
	});
	return r;
}
function wt(e, t) {
	let n = we[e], r = n.passages.some((e) => e.entry);
	return [
		0,
		1,
		2,
		3
	].filter((e) => n.passages.some((n) => [n.a, n.b].some((n) => Se.includes(n) && Ee(n, e) === t) && (!r || n.entry)));
}
//#endregion
//#region src/games/clankcatacombs/motion.ts
var Tt = {
	explore: 760,
	place: 620,
	artifact: 660,
	transfer: 520
}, Et = (e) => Math.min(1100, 400 + Math.max(0, e - 2) * 95), Dt = (e, t) => `cc-pawn:${e}:${t}`, Ot = (e) => `cc-node:${e}`, kt = (e, t) => `cc-tile:${e}:${t}`, At = (e, t, n) => `cc-bridge:${e}>${t}:${n}`;
function jt(e, t, n, r, i = !0) {
	let a = e.players.filter((e) => e.room === t.room && e.state === "active"), o = e.pendingMove?.start ? e.pendingMove.route.id.replace(/>\?$/, "").split(">") : [], s = r?.id.replace(/^continue:/, "").replace(/>\?$/, "").split(">") ?? [n], c = [
		t.room,
		...o,
		...s
	].map((t) => t.replace(/^uw-([A-E])\//, (t, n) => `${e.tiles.find((e) => e.slot === n)?.id ?? `uw-${n}`}/`)), l = c.filter((e, t) => e !== c[t - 1]), u = i || !!r?.descend || !!r?.id.match(/^(ladder|ascend):/);
	return {
		kind: "cc-walk",
		rid: t.rid,
		data: {
			from: t.room,
			to: n,
			path: u ? [t.room, n] : l,
			transfer: u,
			seat: e.players.indexOf(t) + 1,
			fromIndex: a.indexOf(t),
			fromCount: a.length
		}
	};
}
function Mt(e, t, n, r) {
	if (n.kind === "cc-walk") {
		let t = n.data, r = bt(e);
		if (!t.transfer && t.path.some((e, n) => n > 0 && !r.get(t.path[n - 1])?.links.some((t) => t.to === e))) return;
	}
	t.push(n), e.motionMs = Math.max(e.motionMs ?? 0, r);
}
//#endregion
//#region src/games/clankcatacombs/schema.ts
var J = t.int().nonnegative(), Nt = t.enum([
	"adventurer",
	"agnet",
	"dallan",
	"garignar",
	"lenara",
	"monkeybot",
	"whiskers"
]), Pt = t.object({
	lairs: t.boolean().default(!1),
	underworld: t.boolean().default(!1),
	party: t.boolean().default(!1),
	characters: t.boolean().default(!1),
	start: t.enum(["front", "back"]).default("front"),
	underworldStart: t.enum(["front", "back"]).default("front")
}).default({
	lairs: !1,
	underworld: !1,
	party: !1,
	characters: !1,
	start: "front",
	underworldStart: "front"
}), Ft = t.object({
	uid: J,
	kind: t.string()
}), It = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: J
	}),
	t.object({
		type: t.literal("row"),
		slot: J.max(5)
	}),
	t.object({
		type: t.literal("reserve"),
		card: t.enum([
			"explore",
			"mercenary",
			"tome"
		])
	}),
	t.object({
		type: t.literal("move"),
		route: t.string(),
		swords: J
	}),
	t.object({
		type: t.literal("orient"),
		rotation: J.max(3)
	}),
	t.object({
		type: t.literal("artifact"),
		room: t.string()
	}),
	t.object({
		type: t.literal("unlock"),
		feature: t.enum([
			"chest",
			"library",
			"prison"
		])
	}),
	t.object({
		type: t.literal("mark"),
		slot: t.string(),
		payment: t.string()
	}),
	t.object({
		type: t.literal("market"),
		item: t.string(),
		discount: t.string(),
		silver: J
	}),
	t.object({
		type: t.literal("fight"),
		monster: t.string(),
		resource: t.enum(["swords", "skill"])
	}),
	t.object({
		type: t.literal("use"),
		token: t.string()
	}),
	t.object({
		type: t.literal("spell"),
		spell: t.enum([
			"transfigure",
			"duplicate",
			"levitate"
		])
	}),
	t.object({
		type: t.literal("choose"),
		option: t.string(),
		target: t.string().optional(),
		n: t.int().optional()
	}),
	t.object({
		type: t.literal("react"),
		card: J
	}),
	t.object({ type: t.literal("pass") }),
	t.object({ type: t.literal("end") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), Lt = t.object({
	id: J,
	kind: t.string(),
	x: t.number(),
	y: t.number(),
	rotation: J,
	zone: t.enum(["catacombs", "underworld"]),
	slot: t.string().optional()
}), Rt = t.object({
	id: t.string(),
	secrets: J,
	artifacts: t.array(J),
	idols: t.array(J),
	opened: t.array(t.string()),
	marks: t.record(t.string(), t.string()),
	monsters: t.array(t.string()),
	prisoner: t.string().nullable(),
	chute: t.boolean()
}), zt = t.object({
	rid: t.string(),
	character: Nt,
	room: t.string(),
	state: t.enum([
		"active",
		"escaped",
		"knocked"
	]),
	damage: J,
	blackDamage: J,
	supply: J,
	clank: J,
	bag: J,
	removed: J,
	gold: J,
	silver: J,
	picks: J,
	artifacts: t.array(t.object({
		value: J,
		room: t.string()
	})),
	idols: t.array(J),
	prisoners: t.array(t.string()),
	tokens: t.array(t.string()),
	items: t.array(t.object({
		kind: t.string(),
		points: J
	})),
	trophies: t.array(t.string()),
	discard: t.array(Ft),
	played: t.array(Ft),
	reacted: t.array(Ft),
	handCount: J,
	deckCount: J,
	fateCount: J,
	revealedFates: t.array(t.string()),
	boat: t.array(Ft),
	mastery: t.boolean(),
	enhancer: t.number(),
	imp: J,
	mana: J,
	conscription: J,
	carnage: J,
	cogs: J,
	behavior: t.array(t.string())
}), Bt = t.object({
	skill: J,
	swords: J,
	boots: J,
	stopped: t.boolean(),
	noiseMade: J,
	goldGained: J,
	flags: t.array(t.string()),
	visited: t.array(t.string()),
	underworld: t.boolean(),
	defeated: J
}), Vt = t.object({
	eligible: t.boolean(),
	artifacts: t.number(),
	gold: t.number(),
	cards: t.number(),
	tokens: t.number(),
	market: t.number(),
	trophies: t.number(),
	fate: t.number(),
	mastery: t.number(),
	total: t.number()
}), Ht = t.object({
	event: t.string(),
	rid: t.string().optional(),
	card: t.string().optional(),
	token: t.string().optional(),
	room: t.string().optional(),
	n: t.number().optional()
}), Ut = t.object({
	rid: t.string(),
	kind: t.enum(/* @__PURE__ */ "skill.swords.boots.gold.silver.picks.mana.clank.health.draw.discard.trash.teleport.prisoner.secret.flag.artifact.idol.trophy.item.rage.ghost.tile.rotate.fate.reveal.top.replace.mirror".split(".")),
	n: t.int(),
	detail: t.string().optional()
});
t.object({
	id: J,
	revision: J,
	rid: t.string(),
	card: t.string(),
	verb: t.enum([
		"play",
		"acquire",
		"defeat",
		"device",
		"arrive",
		"react"
	]),
	results: t.array(Ut)
});
var Wt = t.object({
	config: Pt,
	phase: t.enum([
		"characters",
		"play",
		"refill",
		"dragon",
		"advance",
		"done"
	]),
	active: t.string(),
	turnNumber: J,
	players: t.array(zt),
	tiles: t.array(Lt),
	rooms: t.array(Rt),
	tileCount: J,
	underworldTileCount: J,
	row: t.array(Ft.nullable()).length(6),
	dungeonCount: J,
	reserve: t.record(t.string(), J),
	market: t.record(t.string(), t.array(J)),
	artifacts: t.array(J),
	rage: J,
	blackBag: J,
	blackRemoved: J,
	ghostBag: J,
	ghostClank: J,
	ghostBank: J,
	openedLocks: t.array(t.string()),
	turn: Bt,
	placement: t.object({
		kind: t.string(),
		x: t.number(),
		y: t.number(),
		rotations: t.array(J)
	}).nullable(),
	choice: t.object({
		rid: t.string(),
		kind: t.string(),
		source: t.string()
	}).nullable(),
	reaction: t.object({
		rid: t.string(),
		events: t.array(t.string())
	}).nullable(),
	scores: t.record(t.string(), Vt).nullable(),
	lastDraw: t.array(t.string()),
	log: t.array(Ht)
}), Gt = t.object({
	hand: t.array(Ft),
	fates: t.array(t.string()),
	peek: t.array(Ft),
	actions: t.array(It),
	moves: t.array(t.object({
		id: t.string(),
		to: t.string(),
		boots: J,
		monsters: J,
		picks: J,
		silver: J,
		x: t.number().optional(),
		y: t.number().optional(),
		slot: t.string().optional()
	}))
});
//#endregion
//#region src/games/clankcatacombs/setup.ts
function Kt(e, t, n, r, i = 0, a) {
	let o = we[t], s = {
		id: e.tileUid++,
		kind: t,
		x: n,
		y: r,
		rotation: i,
		zone: o.underworld ? "underworld" : "catacombs",
		...a ? { slot: a } : {}
	};
	e.tiles.push(s), o.haunted && lt(e);
	for (let t of o.rooms) {
		let n = B(s.id, t.id), r = t.features, i = r.includes("minor") ? e.minorBank.splice(0, 2) : [];
		e.secrets[n] = i;
		let a = [], o = r.find((e) => /^artifact\d$/.test(e));
		if (o && e.artifacts.length) {
			let t = +o.slice(-1);
			e.players.length >= 5 ? a.push(...e.artifacts.splice(0, t + 1)) : a.push(...e.artifacts.splice(Math.min(t, e.artifacts.length - 1), 1));
		}
		r.includes("lyre") && a.push(16);
		let c = [
			"medusa",
			"sphinx",
			"guardian",
			"harpy"
		].filter((e) => r.includes(e));
		r.includes("statue") && c.push("statue", "statue", "statue"), e.rooms[n] = {
			id: n,
			secrets: i.length,
			artifacts: a,
			idols: r.includes("idol") ? [
				5,
				5,
				5
			] : [],
			opened: [],
			marks: {},
			monsters: c,
			prisoner: r.includes("free-prisoner") ? e.prisonerBank.shift() ?? null : null,
			chute: r.includes("chute")
		};
	}
	return s;
}
function qt(e, t, n) {
	t.character = n, t.conscription = n === "agnet" ? 4 : 0, t.deck = tt(e, [
		...[
			,
			,
			,
			,
			,
		].fill("burgle"),
		"stumble",
		"stumble",
		...ge[n]
	].map((t) => nt(e, t))), rt(e, t, 5);
}
function Jt(e, t, n) {
	let r = Pt.parse(e);
	if (r.party || (r.characters = !1), t.length < 2 || t.length > (r.party ? 6 : 4)) throw Error("Invalid player count");
	let i = {
		config: r,
		seed: n,
		cursor: 0,
		uid: 1,
		tileUid: 0,
		phase: r.characters ? "characters" : "play",
		players: [],
		active: 0,
		turnNumber: 1,
		turn: ue(),
		tiles: [],
		tileDeck: [],
		underworldDeck: [],
		rooms: {},
		secrets: {},
		minorBank: [],
		majorBank: [],
		prisonerBank: [],
		artifacts: [
			5,
			7,
			10,
			12,
			15,
			17,
			20
		],
		fateDeck: [],
		dungeon: [],
		row: [],
		dungeonDiscard: [],
		reserve: {
			explore: t.length >= 5 ? 19 : 15,
			mercenary: t.length >= 5 ? 19 : 15,
			tome: t.length >= 5 ? 16 : 12
		},
		market: {
			backpack: [5, 5],
			amulet: [7, 7],
			kit: [
				2,
				2,
				2
			],
			crown: [
				10,
				9,
				8
			]
		},
		openedLocks: [],
		rage: Math.max(0, 4 - t.length),
		blackBag: 24,
		blackRemoved: 0,
		blackExtra: 0,
		ghostBag: 0,
		ghostClank: 0,
		ghostBank: 5,
		queue: [],
		choice: null,
		peek: [],
		placement: null,
		pendingMove: null,
		reaction: null,
		attack: null,
		dragonPending: !1,
		scores: null,
		lastDraw: [],
		log: [],
		enhancers: [
			2,
			1.5,
			1.5
		],
		imps: [
			4,
			3,
			2
		],
		availableCharacters: [
			"agnet",
			"dallan",
			"garignar",
			"lenara",
			"monkeybot",
			"whiskers"
		]
	};
	t.length >= 5 && (i.artifacts = [
		...i.artifacts,
		10,
		15,
		20,
		25
	].sort((e, t) => e - t)), t.length >= 5 && (i.market.backpack.push(5), i.market.crown.push(7)), r.party && (i.market.cloak = Array(t.length >= 5 ? 3 : 2).fill(5));
	let a = [...Ae], o = [...je], s = [...Me];
	r.party && t.length >= 5 && (a = [
		...a,
		...[
			,
			,
			,
		].fill("heal1"),
		...[
			,
			,
			,
		].fill("boots"),
		...[
			,
			,
			,
		].fill("swords"),
		...[
			,
			,
			,
		].fill("gold2"),
		...[
			,
			,
			,
		].fill("spring"),
		...[
			,
			,
			,
		].fill("stealth")
	]), r.underworld && (a.push("dark-iron", "dark-iron", "hope", "hope", "chute", "chute"), o.push("book-dead", "book-dead", "greater-hope", "greater-hope", "silver4", "silver4"), s.push("faithful", "faithful", "myrmidon", "soul-elixir"), i.market["river-lamp"] = [5], i.market["amulet-uw"] = [7], i.market["wind-boots"] = [1], i.market.gauntlets = [6], i.market["jester-cap"] = [0], i.market.riverboat = [8], i.fateDeck = tt(i, ke), i.underworldDeck = tt(i, z.filter((e) => e.id.startsWith("uw-") && !e.id.startsWith("uw-center")).map((e) => e.id))), i.minorBank = tt(i, a), i.majorBank = tt(i, o), i.prisonerBank = tt(i, s);
	let c = z.filter((e) => !e.underworld && !e.id.startsWith("start") && (e.pack === "base" || e.pack === "lairs" && r.lairs)), l = tt(i, c.filter((e) => e.safe).map((e) => e.id)).slice(0, r.underworld ? 3 : 4), u = tt(i, c.filter((e) => !e.safe).map((e) => e.id));
	if (r.underworld) {
		let e = tt(i, z.filter((e) => e.pack === "underworld" && !e.underworld).map((e) => e.id)).slice(0, 3);
		u = [...tt(i, [...u.splice(0, 7), ...e]), ...u];
	}
	if (i.tileDeck = [...l, ...u], t.forEach((e, t) => {
		let n = Math.max(0, 3 - t), a = {
			rid: e,
			character: "adventurer",
			room: "0/crypt",
			state: "active",
			damage: 0,
			blackDamage: 0,
			supply: 30 - n,
			clank: n,
			bag: 0,
			removed: 0,
			gold: Math.max(0, t - 3),
			silver: 0,
			picks: 3,
			artifacts: [],
			idols: [],
			prisoners: [],
			tokens: [],
			items: [],
			trophies: [],
			discard: [],
			played: [],
			reacted: [],
			boat: [],
			mastery: !1,
			enhancer: 1,
			imp: 0,
			mana: 0,
			conscription: 0,
			carnage: 0,
			cogs: 0,
			behavior: [],
			deck: [],
			hand: [],
			fates: [],
			revealedFates: [],
			spring: 0
		};
		i.players.push(a), r.characters || qt(i, a, "adventurer");
	}), Kt(i, `start-${r.start}`, 0, 0), r.underworld) {
		let e = Kt(i, `uw-center-${r.underworldStart}`, 5, 0);
		r.underworldStart === "back" && (i.rooms["0/b"].idols = [], i.rooms[B(e.id, "idol")].idols = [
			5,
			5,
			5
		]);
	}
	i.dungeon = tt(i, he.filter((e) => e.pack === "base" || e.pack === "party" && r.party || e.pack === "lairs" && r.lairs || e.pack === "underworld" && r.underworld).flatMap((e) => Array.from({ length: e.copies }, () => nt(i, e.id))));
	let d = [];
	for (; i.row.length < 6;) {
		let e = i.dungeon.shift();
		Yt(e.kind).dragon ? d.push(e) : (i.row.push(e), Yt(e.kind).arrive.length && Xe(i, i.players[0], e.kind, "arrive", () => U(i, i.players[0], e.kind, Yt(e.kind).arrive)));
	}
	return i.dungeon = tt(i, [...i.dungeon, ...d]), i;
}
function Yt(e) {
	return he.find((t) => t.id === e);
}
//#endregion
//#region src/games/clankcatacombs/board.ts
function Xt(e, t, n = !1) {
	if (!e.pendingMove?.start) return Ct(e, e.turn.flags.includes("reverse-arrows") ? {
		...t,
		tokens: [...t.tokens, "map"]
	} : t, n);
	let r = e.pendingMove;
	return xt(e, t.room, n || t.tokens.includes("map") || e.turn.flags.includes("reverse-arrows"), r.start).filter((e) => !e.discover && !e.descend).map((e) => ({
		...e,
		id: `continue:${e.id}`,
		edges: [...r.route.edges, ...e.edges],
		monsters: r.route.monsters + e.monsters,
		boots: r.route.boots + e.boots - 1,
		locks: [.../* @__PURE__ */ new Set([...r.route.locks, ...e.locks])],
		toll: r.route.toll + e.toll,
		barrier: r.route.barrier || e.barrier
	}));
}
function Zt(e, t) {
	let n = e.pendingMove, r = +n.start.split("/")[0], i = e.tiles.find((e) => e.id === r), a = n.route.discover.port, o = we[i.kind].passages.flatMap((e) => [e.a, e.b]).find((e) => Ee(e, t) === a);
	return {
		...e,
		tiles: e.tiles.map((e) => e.id === r ? {
			...e,
			rotation: t
		} : e),
		pendingMove: {
			...n,
			start: B(r, o)
		}
	};
}
function Qt(e, t) {
	return e.turn.flags.includes("ignoreMonsters") || t.trophies.includes("medusa") || St(t, "cloak");
}
function $t(e, t, n, r) {
	if (!n) return !0;
	let i = V(e.tiles, n).def.features, a = e.rooms[n];
	if (i.includes("crypt") && !Le(t)) return !1;
	let o = 0;
	i.includes("pit") && !e.turn.visited.includes(n) && !t.hand.some((e) => e.kind !== "stumble") && o++;
	for (let n of a.monsters) {
		let i = Pe[n];
		i && (r >= i.swords && (n !== "medusa" || en(e, t)) ? r -= i.swords : o += i.damage);
	}
	return o === 0 || ct(t, o);
}
function en(e, t) {
	return e.turn.flags.includes("counts-tome") || t.played.some((e) => L[e.kind].tome || e.kind === "tome-of-the-ape-lords" && t.idols.length > 0);
}
function tn(e, t, n, r, i = !1, a = !0) {
	if (n.discover && (!e.tileDeck.length || !wt(e.tileDeck[0], n.discover.port).length) || n.descend && !e.underworldDeck.length) return !1;
	if (n.descend && n.underworldPort) {
		let r = {
			id: e.tileUid,
			kind: e.underworldDeck[0],
			x: 4 + "ABCDE".indexOf(n.descend) * 1.1,
			y: 2.2,
			rotation: 0,
			zone: "underworld",
			slot: n.descend
		};
		if (!xt({
			...e,
			tiles: [...e.tiles, r]
		}, t.room, i || t.tokens.includes("map") || e.turn.flags.includes("reverse-arrows"), B(r.id, n.underworldPort)).some((a) => a.to.startsWith(`${r.id}/`) ? i ? !0 : n.boots + a.boots - 1 <= e.turn.boots && (/* @__PURE__ */ new Set([...n.locks, ...a.locks])).size <= t.picks && (t.trophies.includes("nether-titan") || n.toll + a.toll <= t.silver) && !((n.barrier || a.barrier) && Le(t)) : !1)) return !1;
	}
	if (i) return $t(e, t, n.to, e.turn.swords) || a && !!e.pendingMove?.start && !nn(e, t, !0);
	if (e.turn.flags.includes("pit-stop") || e.turn.stopped && !e.turn.flags.includes("ignoreCave") && !(t.trophies.includes("cave-bat-wings") && ([...t.played, ...t.discard].some((e) => L[e.kind].tome) || t.fates.includes("magician"))) || e.turn.boots < n.boots || t.picks < n.locks.length || !t.trophies.includes("nether-titan") && t.silver < n.toll || n.barrier && Le(t)) return !1;
	let o = Qt(e, t) ? 0 : n.monsters, s = o - r;
	if (r > Math.min(e.turn.swords, o)) return !1;
	let c = s === 0 || ct(t, s), l = {
		...t,
		damage: t.damage + s,
		supply: t.supply - s
	};
	return c && $t(e, l, n.to, e.turn.swords - r) ? !0 : a && !!e.pendingMove?.start && !nn(e, t, !1);
}
function nn(e, t, n) {
	let r = e.tiles.find((t) => t.id === +e.pendingMove.start.split("/")[0]);
	return (r.zone === "catacombs" ? wt(r.kind, e.pendingMove.route.discover.port).map((t) => Zt(e, t)) : [e]).some((e) => Xt(e, t, n).some((r) => tn(e, t, r, n || Qt(e, t) ? 0 : Math.min(r.monsters, e.turn.swords), n, !1)));
}
function rn(e, t, n, r = []) {
	let i = e.rooms[n];
	if (t.artifacts.length >= ze(t) || !i.artifacts.length) return;
	let a = Math.max(...i.artifacts);
	i.artifacts.splice(i.artifacts.indexOf(a), 1), t.artifacts.push({
		value: a,
		room: n
	}), ut(e), G(e, "artifact"), G(e, "find"), e.log.push({
		event: "artifact",
		rid: t.rid,
		room: n,
		n: a
	}), Mt(e, r, {
		kind: "cc-artifact",
		rid: t.rid,
		data: {
			room: n,
			to: t.room,
			value: a
		}
	}, Tt.artifact), H(e.tiles, n, "hoard") && an(e, t, n);
}
function an(e, t, n) {
	let r = V(e.tiles, n);
	K(e, t, "hoard", "teleport", we[r.tile.kind].rooms.filter((e) => e.id !== r.def.id).map((e) => q("teleport", [{
		op: "special",
		id: "enter",
		target: B(r.tile.id, e.id)
	}], B(r.tile.id, e.id))));
}
function on(e, t, n) {
	t === ce(e) && (e.pendingMove = null), t.room = n, e.turn.moved++, G(e, "move");
	let r = V(e.tiles, n), i = r.def.features, a = e.rooms[n];
	if (i.includes("market") && G(e, "enter-market"), e.turn.underworld ||= r.tile.zone === "underworld", i.includes("cave") && (e.turn.stopped = !0, G(e, "cave")), i.includes("crypt")) {
		e.turn.flags.push("escaping");
		return;
	}
	if (!e.turn.visited.includes(n)) {
		e.turn.visited.push(n);
		for (let n of i) {
			let r = /^(gold|silver|heal|clank|skill)(\d+)$/.exec(n);
			r && W(e, t, r[1], +r[2]);
		}
		if (a.secrets && U(e, t, n, [P("room-minor")]), a.idols.length ? (t.idols.push(a.idols.shift()), G(e, "idol"), G(e, "find")) : e.config.underworld && e.config.underworldStart === "back" && n === "0/b" && (e.config.start === "front" ? W(e, t, "gold", 2) : U(e, t, n, [P("minor")])), i.includes("pit") && U(e, t, n, [P("pit")], !0), i.includes("lake") && U(e, t, n, [P("trash")]), i.includes("fate") && t.fates.length < 1 + Number(St(t, "gauntlets")) && U(e, t, n, [P("fate")]), i.includes("imp") && !t.imp && e.imps.length && (t.imp = e.imps.shift()), a.prisoner) {
			let r = a.prisoner;
			a.prisoner = null, U(e, t, n, [{
				op: "special",
				id: "prisoner-token",
				target: r
			}]);
		}
		i.includes("guardian") && !a.monsters.includes("guardian") && t.enhancer === 1 && e.enhancers.length && (t.enhancer = e.enhancers.shift()), i.includes("wayshrine") && t.tokens.includes("puzzlebox") && (t.tokens.splice(t.tokens.indexOf("puzzlebox"), 1), U(e, t, n, [P("major")]));
	}
	for (let r of a.monsters) Pe[r] && U(e, t, n, [{
		op: "special",
		id: "encounter",
		target: r
	}], !0);
	e.log.push({
		event: "move",
		rid: t.rid,
		room: n
	});
}
function sn(e, t, n, r = !1, i = []) {
	let a = ce(e);
	if (t.discover) {
		let n = e.tileDeck.shift();
		e.placement = {
			kind: n,
			x: t.discover.x,
			y: t.discover.y,
			rotations: wt(n, t.discover.port),
			port: t.discover.port,
			route: t,
			teleport: r
		}, e.pendingMove = {
			route: t,
			teleport: r
		}, Mt(e, i, {
			kind: "cc-explore",
			rid: a.rid,
			data: {
				tile: -1,
				rotation: e.placement.rotations[0],
				entry: t.id.replace(/>\?$/, "").split(">").at(-1)
			}
		}, Tt.explore), wt(e.tileDeck[0] ?? n, t.discover.port).length && (e.turn.flags.includes("reroll-tile") || e.turn.flags.includes("reroll-no-artifact") && we[n].rooms.every((e) => !e.features.some((e) => e.startsWith("artifact")))) && K(e, a, "tile", "reroll", [q("replace", [{
			op: "special",
			id: "redraw-placement"
		}]), q("skip")]);
		return;
	}
	if (t.descend) {
		let n = Kt(e, e.underworldDeck.shift(), 4 + "ABCDE".indexOf(t.descend) * 1.1, 2.2, 0, t.descend);
		if (t.underworldPort) {
			e.pendingMove = {
				route: t,
				teleport: r,
				start: B(n.id, t.underworldPort)
			};
			return;
		}
		t = {
			...t,
			to: B(n.id, "ladder")
		};
	}
	let o = jt(e, a, t.to, t, r);
	if (!r) {
		e.turn.boots -= t.boots, e.turn.swords -= n, a.trophies.includes("nether-titan") || (a.silver -= t.toll), a.picks -= t.locks.length, e.openedLocks.push(...t.locks), t.locks.length && G(e, "pick-spent");
		let r = Qt(e, a) ? 0 : t.monsters;
		r > n && st(e, a, r - n), e.turn.tunnels += n;
	}
	e.pendingMove?.start && e.turn.flags.push("forced-entry"), e.pendingMove = null, on(e, a, t.to), Mt(e, i, o, r || t.descend || /^(ladder|ascend):/.test(t.id) ? Tt.transfer : Et(o.data.path.length)), U(e, a, t.to, [P("clear-forced-entry")]);
}
function cn(e, t, n = []) {
	if (!e.placement) {
		let n = Zt(e, t);
		e.tiles = n.tiles, e.pendingMove = n.pendingMove;
		return;
	}
	let r = e.placement, i = Kt(e, r.kind, r.x, r.y, t), a = we[i.kind];
	e.placement = null;
	let o = a.passages.flatMap((e) => [e.a, e.b]).find((e) => Ee(e, t) === r.port);
	r.route && (e.pendingMove = {
		route: r.route,
		teleport: !!r.teleport,
		start: B(i.id, o)
	}), e.log.push({
		event: "discover",
		room: B(i.id, a.rooms[0].id)
	}), Mt(e, n, {
		kind: "cc-place",
		rid: ce(e).rid,
		data: {
			tile: i.id,
			rotation: t,
			entry: B(i.id, o)
		}
	}, Tt.place);
}
//#endregion
//#region src/games/clankcatacombs/scoring.ts
var ln = (e) => [
	...e.deck,
	...e.hand,
	...e.discard,
	...e.played,
	...e.reacted,
	...e.boat
], un = (e) => ln(e).filter((t) => L[t.kind].tome || t.kind === "tome-of-the-ape-lords" && e.idols.length > 0).length + e.tokens.filter((e) => e === "book-dead").length + Number(e.fates.includes("magician"));
function dn(e, t, n) {
	let r = ln(t), i = (e) => r.filter((t) => t.kind === e).length, a = t.trophies.filter((e) => e === "harpy" || e === "harpy-matriarch").length;
	switch (n) {
		case "fool": return i("stumble") >= 2 ? 10 : 0;
		case "magician":
		case "high-priestess":
		case "tower":
		case "star": return 3;
		case "empress": return Ie(t) ? 6 : 0;
		case "emperor": return t.enhancer > 1 && Ie(t) && t.idols.length ? 12 : 0;
		case "hierophant":
		case "lovers": return 2;
		case "chariot": return -3;
		case "strength": return [
			0,
			3,
			5,
			8
		][Math.min(3, a)];
		case "hermit": return t.idols.length ? 6 : 0;
		case "wheel": return Re(t) >= 10 ? 10 : 0;
		case "hanged-man":
		case "judgement": return 5;
		case "death": return t.state === "knocked" && !Oe(e.tiles, t.room) && !Fe(e, t) ? -5 : 1;
		case "temperance": return 4;
		case "imp": return Math.min(3, r.filter((e) => L[e.kind].type === "gem").length) * 4;
		case "moon": return t.items.filter((e) => Ne.includes(e.kind)).length >= 2 ? 8 : 0;
		case "sun": return t.mastery ? 10 : 0;
		case "world": return t.items.length >= 3 ? 7 : 0;
		default: return 0;
	}
}
function fn(e, t, n) {
	return [
		"barbarian",
		"cleric",
		"peasant"
	].includes(n) ? 2 : ["haunted", "adventurer"].includes(n) ? 3 : ["faithful", "myrmidon"].includes(n) ? 1 : n === "mayor" ? t.mastery ? 5 : 0 : n === "monk" ? Ve(e, t, "wayshrine") : n === "warrior" ? t.prisoners.length : n === "primatologist" ? t.idols.length ? 5 : 0 : n === "prince" || n === "princess" ? Ie(t) ? 5 : 0 : n === "sorceress" && un(t) >= 2 ? 5 : 0;
}
function pn(e, t) {
	let n = t.trophies.includes("mechanical-donkey") && t.state === "knocked" && !Oe(e.tiles, t.room) && !Fe(e, t), r = Le(t) && (t.mastery || Oe(e.tiles, t.room) || (t.fates.includes("death") || n) && !Fe(e, t)), i = t.artifacts.map((e) => e.value), a = Math.max(0, ...i), o = i.reduce((e, t) => e + t, 0) + Math.ceil(a * t.enhancer) - a, s = ln(t).reduce((n, r) => r.kind === "payoff" ? n + 0 : r.kind === "wealth-of-knowledge" || r.kind === "thirst-for-knowledge" ? n + un(t) : r.kind === "brave-hero" ? n + (t.prisoners.length >= 3 ? 5 : 0) : r.kind === "thirst-for-adventure" ? n + 2 * (t.artifacts.length + Number(t.trophies.includes("guardian")) + t.idols.length) : r.kind === "expensive-taste" ? n + (Ie(t) && ln(t).some((e) => L[e.kind].type === "gem") ? 5 : 0) : r.kind === "devotion" ? n + Ve(e, t) : r.kind === "orpheus" ? n + t.prisoners.length : r.kind === "thunderstriker" ? n + t.trophies.filter((e) => e === "harpy" || e === "harpy-matriarch").length : n + L[r.kind].points, 0), c = t.idols.reduce((e, t) => e + t, 0) + t.tokens.reduce((e, t) => e + (t === "egg" ? 3 : t === "chalice" ? 7 : t === "map" || t === "book-dead" ? 5 : t === "dark-iron" ? 2 : +(t === "chute")), 0) + t.prisoners.reduce((n, r) => n + fn(e, t, r), 0) + t.imp * un(t), l = t.items.reduce((e, n) => e + n.points + (n.kind === "jester-cap" ? ln(t).filter((e) => e.kind === "stumble").length * 7 : n.kind === "riverboat" ? t.boat.length : 0), 0), u = t.trophies.reduce((e, r) => r === "cave-bat-wings" ? e + (t.mastery ? 4 : 0) : r === "ape-lord-epaulets" ? e + (t.idols.length && Ie(t) ? 7 : t.idols.length || Ie(t) ? 3 : 0) : r === "mechanical-donkey" ? e + (n ? 8 : 2) : r === "hoard-keeper" ? e + Math.floor(Re(t) / 5) : r === "harpy-matriarch" ? e + t.trophies.filter((e) => e === "harpy" || e === "harpy-matriarch").length : e + (L[r]?.points ?? +!![
		"statue",
		"medusa",
		"sphinx"
	].includes(r)), 0), d = t.fates.reduce((n, r) => n + dn(e, t, r), 0), f = t.mastery ? 20 : 0, p = {
		eligible: r,
		artifacts: o,
		gold: n ? 0 : Re(t),
		cards: s,
		tokens: c,
		market: l,
		trophies: u,
		fate: d,
		mastery: f,
		total: 0
	};
	return p.total = r ? o + p.gold + s + c + l + u + d + f : 0, p;
}
function mn(e) {
	e.phase = "done", e.choice = null, e.reaction = null, e.queue = [], e.placement = null, e.pendingMove = null, e.attack = null, e.scores = Object.fromEntries(e.players.map((t) => [t.rid, pn(e, t)]));
}
function hn(e, t, n) {
	let r = e.players.find((e) => e.rid === t), i = e.players.find((e) => e.rid === n), a = e.scores[t], o = e.scores[n], s = Math.max(0, ...r.artifacts.map((e) => e.value)), c = Math.max(0, ...i.artifacts.map((e) => e.value));
	return Number(o.eligible) - Number(a.eligible) || o.total - a.total || Math.ceil(c * i.enhancer) - Math.ceil(s * r.enhancer) || c - s;
}
//#endregion
//#region src/games/clankcatacombs/dragon.ts
var gn = {
	effect: 70,
	dragon: 450,
	refill: 260,
	advance: 220
}, _n = (e) => e.blackBag + e.ghostBag + e.players.reduce((e, t) => e + t.bag, 0);
function vn(e, t = 0, n = "advance", r) {
	for (let t of e.players) t.bag += t.clank, t.clank = 0;
	e.ghostBag += e.ghostClank, e.ghostClank = 0;
	let i = e.row.filter((e) => e && L[e.kind].danger).length;
	e.attack = {
		remaining: t || (e.players.length >= 5 ? $e : Qe)[e.rage] + i,
		after: n,
		immune: r,
		ghostReturn: 0,
		hits: {},
		resolving: !1
	}, e.phase = "dragon", e.lastDraw = [], e.turn.damaged = [], e.log.push({
		event: "dragon",
		n: e.attack.remaining
	});
}
function yn(e) {
	let t = e.attack;
	if (t.remaining > 0 && _n(e)) {
		let n = et(e, _n(e));
		if (n < e.blackBag) e.blackBag--, e.blackRemoved++, e.lastDraw.push("black");
		else if ((n -= e.blackBag) < e.ghostBag) e.ghostBag--, t.ghostReturn++, e.lastDraw.push("ghost");
		else {
			n -= e.ghostBag;
			for (let r of e.players) {
				if (n >= r.bag) {
					n -= r.bag;
					continue;
				}
				r.bag--, e.lastDraw.push(r.rid), t.hits[r.rid] = (t.hits[r.rid] ?? 0) + 1;
				break;
			}
		}
		t.remaining--;
		return;
	}
	if (!t.resolving) {
		t.resolving = !0;
		for (let n of e.players) {
			let r = t.hits[n.rid] ?? 0;
			r && (n.rid === t.immune ? n.supply += r : n.state === "active" ? n.fates.includes("star") && !n.revealedFates.includes("star") ? U(e, n, "star", [P("star-hit", r)]) : st(e, n, r, "bag") : n.removed += r);
		}
		for (let n = 0; n < t.ghostReturn; n++) for (let t of e.players) t.state === "active" && U(e, t, "ghost", [P("ghost-hit")]);
		return;
	}
	if (e.ghostClank += t.ghostReturn, e.phase = t.after, e.attack = null, !_n(e) || e.players.every((e) => e.state !== "active")) {
		for (let t of e.players) ot(e, t);
		mn(e);
	}
}
//#endregion
//#region src/games/clankcatacombs/effects.ts
var Y = (e, t, n) => ({
	op: "special",
	id: e,
	...t === void 0 ? {} : { target: t },
	...n === void 0 ? {} : { n }
}), bn = () => q("skip"), xn = (e) => e.split("#")[0], Sn = (e) => +e.split("#")[1], Cn = (e, t) => V(e.tiles, t.room), wn = (e) => [
	e.tokens.includes("egg") && "egg",
	e.idols.length > 0 && "idol",
	Ie(e) > 0 && "crown",
	Le(e) && "artifact"
].filter((e) => !!e), Tn = (e, t = !1) => t ? e.hand : [...e.played, ...e.discard];
function En(e, t, n) {
	for (let r of [
		t.hand,
		t.played,
		t.discard
	]) {
		let i = r.findIndex((e) => e.uid === n);
		if (i < 0) continue;
		let [a] = r.splice(i, 1);
		St(t, "riverboat") && t.boat.push(a), G(e, "trash"), e.log.push({
			event: "trash",
			rid: t.rid,
			card: a.kind
		}), qe(e, t.rid, "trash", 1, a.kind);
		let o = {
			"escape-plan": [N("boots", 2), {
				op: "flag",
				flag: "ignoreCave"
			}],
			"jet-slippers": Fe(e, t) ? [P("teleport-ladder")] : [],
			"soul-prism": [P("prisoner")],
			"underworld-guide": [{
				op: "draw",
				n: 1
			}],
			"burial-urn": [N("silver", 4)]
		};
		o[a.kind] && U(e, t, a.kind, o[a.kind], !0);
		return;
	}
}
function Dn(e, t, n, r, i, a = "trash-target", o = [], s = !0) {
	K(e, t, n, r, [...i.map((e) => q(a === "discard-target" ? "discard" : a === "copy-target" ? "copy" : "trash", [Y(a, String(e.uid)), ...o], String(e.uid))), ...s ? [bn()] : []]);
}
function On(e, t, n, r, i = !0) {
	K(e, t, n, "teleport", [...r.filter((n) => n !== t.room && $t(e, t, n, e.turn.swords)).map((e) => q("teleport", [Y("enter", e)], e)), ...i ? [bn()] : []]);
}
function kn(e, t, n) {
	let r = +(e.phase === "refill");
	for (let i = 0; i < e.players.length; i++) {
		let a = e.players[(e.active + i + r) % e.players.length];
		a.state === "active" && U(e, a, t, [P(n)]);
	}
}
function An(e, t, n, r) {
	switch (n) {
		case "skill6": return (e.turn.totals.skill ?? 0) >= 6;
		case "swords4": return (e.turn.totals.swords ?? 0) >= 4;
		case "noise1": return e.turn.noiseMade >= 1;
		case "noise2": return e.turn.noiseMade >= 2;
		case "gold3": return e.turn.goldGained >= 3;
		case "idol": return t.idols.length > 0;
		case "artifact": return Le(t);
		case "small-artifact": return t.artifacts.some((e) => e.value <= 10);
		case "prisoner3": return t.prisoners.length >= 3;
		case "crown": return Ie(t) > 0;
		case "cave": return H(e.tiles, t.room, "cave");
		case "market": return H(e.tiles, t.room, "market");
		case "pit": return H(e.tiles, t.room, "pit");
		case "haunted": return Cn(e, t).tileDef.haunted;
		case "tome": return [...t.played, ...t.discard].some((e) => L[e.kind].tome || e.kind === "tome-of-the-ape-lords" && t.idols.length > 0) || e.turn.flags.includes("counts-tome") || t.fates.includes("magician");
		case "companion": return t.played.some((e) => L[e.kind].type === "companion" && e.uid !== Sn(r));
		case "defeated": return e.turn.defeated > 0;
		case "portal": return e.turn.events.includes("portal");
		case "freed": return e.turn.freed > 0;
		case "pick-spent": return e.turn.events.includes("pick-spent");
		case "marks3": return Ve(e, t) >= 3;
		case "underworld": return Fe(e, t);
		case "fate": return t.fates.length > 0;
		case "gem": return [...t.played, ...t.discard].some((e) => L[e.kind].type === "gem");
		default: throw Error(`Unknown condition: ${n}`);
	}
}
function jn(e) {
	for (let t of e.turn.watchers) Ye(e, t.notice, () => Mn(e, t));
}
function Mn(e, t) {
	let n = le(e, t.rid), r = t.effect;
	if (r.op === "when") {
		let i = `${t.source}:${JSON.stringify(r)}`;
		!e.turn.triggers.includes(i) && An(e, n, r.condition, t.source) && (e.turn.triggers.push(i), U(e, n, t.source, r.effects));
	} else if (r.op === "special") {
		let i = 0, a = "gold";
		r.id === "noise-gold" || r.id === "noise-swords" ? (i = e.turn.noiseMade, a = r.id === "noise-swords" ? "swords" : "gold") : r.id === "tunnel-gold" || r.id === "scavenge" ? i = e.turn.tunnels : r.id === "study" ? (i = e.turn.totals.tomes ?? 0, a = "mana") : r.id === "healer" ? i = n.played.filter((e) => L[e.kind].type === "gem").length : r.id === "finds-gold" ? i = wn(n).length : r.id === "draw-artifacts" ? i = n.artifacts.length + Number(n.trophies.includes("guardian")) : r.id === "channel" && (i = (e.turn.totals["event:secret"] ?? 0) + (e.turn.totals["event:potion"] ?? 0), a = "mana");
		let o = `paid:${t.source}:${r.id}`, s = e.turn.totals[o] ?? 0;
		if (i <= s) return;
		e.turn.totals[o] = i, r.id === "draw-artifacts" ? rt(e, n, i - s) : r.id === "healer" ? (at(e, n, i - s), it(e, n, i - s)) : W(e, n, a, i - s);
	}
}
function Nn(e, t = []) {
	let n = e.queue.shift();
	Ye(e, n.notice, () => Pn(e, n, t));
}
function Pn(e, t, n) {
	let { effect: r, source: i } = t, a = le(e, t.rid);
	if (a.state === "active" || r.op === "special" && (r.id.endsWith("-all") || [
		"pixie",
		"scuffler",
		"spotter",
		"succubus",
		"rotate-lone",
		"rotate-occupied",
		"hydra-stock",
		"titan-reserve"
	].includes(r.id)) || r.op === "gain" && r.who) switch (r.op) {
		case "gain":
			for (let t of r.who ? e.players.filter((e) => e.state === "active" && (r.who === "all" || e.rid !== a.rid)) : [a]) W(e, t, r.resource, r.n);
			break;
		case "draw":
			rt(e, a, r.n);
			break;
		case "flag":
			e.turn.flags.push(r.flag), qe(e, a.rid, "flag", 1, r.flag);
			break;
		case "when":
			e.turn.watchers.push(t);
			break;
		case "choice": {
			let t = r.options.filter((e) => !(e.id === "draw" && xn(i) === "imp-familiar" && !a.picks) && !(e.id === "steal" && xn(i) === "grand-theft" && !a.picks) && !(e.id === "trophy" && !a.trophies.length) && !(e.id === "silver" && xn(i) === "oracle" && !a.silver) && !(e.id === "tome" && xn(i) === "underworld-dealer" && Re(a) < 3));
			xn(i) === "empurror" && Le(a) ? (U(e, a, i, [
				N("clank", -2),
				N("gold", 1),
				{
					op: "flag",
					flag: "ignoreCave"
				}
			], !0), e.turn.triggers.push(`empurror:${i}`)) : K(e, a, i, r.kind, t.map((e) => q(e.id, e.effects)));
			break;
		}
		case "special": Fn(e, a, i, r, t, n);
	}
}
function Fn(e, t, n, r, i, a) {
	let o = r.id, s = r.target, c = r.n ?? 1, l = Cn(e, t), u = l.def.features;
	switch (o) {
		case "trash-target":
			En(e, t, +s);
			break;
		case "pit-trash": {
			let r = t.hand.some((e) => e.uid === +s && e.kind === "acrobatics");
			En(e, t, +s), r && U(e, t, n, [P("acrobatics")], !0);
			break;
		}
		case "discard-target": {
			let n = t.hand.findIndex((e) => e.uid === +s);
			n >= 0 && (t.discard.push(...t.hand.splice(n, 1)), qe(e, t.rid, "discard"));
			break;
		}
		case "trash":
		case "trash-played":
		case "trash-burgle":
		case "discard-draw2":
		case "discard-optional-draw":
			Dn(e, t, n, o.startsWith("discard") ? "discard" : "trash", o.startsWith("discard") ? t.hand : o === "trash-played" ? t.played : Tn(t).filter((e) => o !== "trash-burgle" || e.kind === "burgle"), o.startsWith("discard") ? "discard-target" : "trash-target", o === "discard-draw2" ? [{
				op: "draw",
				n: 2
			}] : o === "discard-optional-draw" ? [{
				op: "draw",
				n: 1
			}] : [], o !== "discard-draw2");
			break;
		case "trash-self":
			En(e, t, Sn(n));
			break;
		case "enter": {
			let n = jt(e, t, s);
			on(e, t, s), Mt(e, a, n, Tt.transfer), G(e, "portal"), qe(e, t.rid, "teleport");
			break;
		}
		case "teleport":
			K(e, t, n, "teleport", [...Xt(e, t, !0).filter((n) => tn(e, t, n, 0, !0)).map((e) => q("teleport", [Y("teleport-route", e.id)], e.id)), bn()]);
			break;
		case "teleport-route":
			sn(e, Xt(e, t, !0).find((e) => e.id === s), 0, !0, a), qe(e, t.rid, "teleport");
			break;
		case "teleport-any-other-tile":
			On(e, t, n, Object.keys(e.rooms).filter((t) => V(e.tiles, t).tile.id !== l.tile.id));
			break;
		case "teleport-lair":
			On(e, t, n, Object.keys(e.rooms).filter((t) => {
				let n = V(e.tiles, t).def.features;
				return He(n) || Ue(n);
			}));
			break;
		case "teleport-lair-forced":
			On(e, t, n, Object.keys(e.rooms).filter((t) => {
				let n = V(e.tiles, t).def.features;
				return He(n) || Ue(n);
			}), !1);
			break;
		case "teleport-underworld-market":
			On(e, t, n, Object.keys(e.rooms).filter((t) => {
				let n = V(e.tiles, t);
				return n.tile.zone === "underworld" && n.def.features.includes("market");
			}));
			break;
		case "teleport-ladder":
			On(e, t, n, Object.keys(e.rooms).filter((t) => {
				let n = V(e.tiles, t);
				return n.tile.zone === "catacombs" && n.def.features.some((e) => e.startsWith("ladder"));
			}));
			break;
		case "waystone":
			u.includes("wayshrine") && K(e, t, n, "waystone", [q("trash", [Y("trash-target", String(Sn(n))), Y("teleport-shrine")]), bn()]);
			break;
		case "teleport-shrine":
			On(e, t, n, Object.keys(e.rooms).filter((t) => H(e.tiles, t, "wayshrine")), !1);
			break;
		case "swap-depths":
			K(e, t, n, "swap", [...e.players.filter((n) => n.rid !== t.rid && n.state === "active" && !Fe(e, n) && !Oe(e.tiles, n.room)).map((e) => q("swap", [Y("swap-player", e.rid)], e.rid)), bn()]);
			break;
		case "swap-player": {
			let n = le(e, s), r = t.room;
			t.room = n.room, n.room = r, (e.players[e.active] === t || e.players[e.active] === n) && (e.pendingMove = null);
			break;
		}
		case "minor":
		case "room-minor": {
			let r = o === "minor" ? e.minorBank : e.secrets[n], i = r?.shift();
			o === "room-minor" && (e.rooms[n].secrets = r.length), i && (G(e, "secret"), Ln(e, t, i));
			break;
		}
		case "major": {
			let n = e.majorBank.shift();
			n && (G(e, "secret"), G(e, "major-secret"), Ln(e, t, n));
			break;
		}
		case "tome":
			ht(e, t);
			break;
		case "prisoner": {
			let n = e.prisonerBank.shift();
			n && Rn(e, t, n);
			break;
		}
		case "prisoner-token":
			Rn(e, t, s);
			break;
		case "pay-pick-draw2":
			t.picks--, rt(e, t, 2), G(e, "pick-spent");
			break;
		case "pay3-draw2":
			Be(t, 3), rt(e, t, 2);
			break;
		case "pay3-tome":
			Re(t) >= 3 && (Be(t, 3), ht(e, t));
			break;
		case "silver-draw2":
			t.silver--, rt(e, t, 2);
			break;
		case "black": {
			let t = Math.min(3, e.blackRemoved);
			e.blackRemoved -= t, e.blackBag += t;
			break;
		}
		case "noise-gold":
		case "noise-swords":
		case "tunnel-gold":
		case "scavenge":
		case "healer":
		case "study":
		case "channel":
		case "finds-gold":
		case "draw-artifacts":
			e.turn.watchers.push(i);
			break;
		case "noise-gold-once":
			W(e, t, "gold", e.turn.noiseMade);
			break;
		case "empurror-extra":
			if (!e.turn.triggers.includes(`empurror:${n}`)) {
				let r = e.turn.triggers.find((e) => e.startsWith(`selected:${n}:`))?.split(":").at(-1);
				U(e, t, n, [
					...r === "quiet" ? [] : [N("clank", -2)],
					...r === "gold" ? [] : [N("gold", 1)],
					{
						op: "flag",
						flag: "ignoreCave"
					}
				], !0);
			}
			break;
		case "theft-row":
			K(e, t, n, "acquire", [...e.row.flatMap((n, r) => n && L[n.kind].type !== "monster" && t.picks && ft(e, t, n.kind) ? [q("acquire", [
				N("picks", -1),
				Y("pick-event"),
				Y("row-free", String(r))
			], String(r))] : []), bn()]);
			break;
		case "pick-event":
			G(e, "pick-spent");
			break;
		case "steal-gold":
			K(e, t, n, "steal", [...e.players.filter((e) => e.rid !== t.rid && e.state === "active" && e.gold >= 1).map((e) => q("steal", [Y("steal-gold-target", e.rid)], e.rid)), bn()]);
			break;
		case "steal-gold-target":
			le(e, s).gold--, W(e, t, "gold", 1), it(e, t, 1);
			break;
		case "deck-top":
		case "conscription": {
			let r = o === "conscription" ? c : Sn(n);
			t.discard.some((e) => e.uid === r) && K(e, t, n, "top", [q("top", [Y("top-card", String(r), Number(o === "conscription"))], String(r)), bn()]);
			break;
		}
		case "top-card": {
			let n = t.discard.findIndex((e) => e.uid === +s);
			n >= 0 && (t.deck.unshift(...t.discard.splice(n, 1)), r.n && t.conscription--, qe(e, t.rid, "top"));
			break;
		}
		case "replace":
		case "imp-row":
			K(e, t, n, o, [...e.row.flatMap((e, t) => e ? [q("replace", [Y(o === "replace" ? "replace-slot" : "remove-slot", String(t))], String(t))] : []), ...o === "replace" ? [bn()] : []]);
			break;
		case "remove-slot": {
			let n = +s;
			e.dungeonDiscard.push(e.row[n]), e.row[n] = null, qe(e, t.rid, "replace");
			break;
		}
		case "replace-slot": {
			let n = +s, r = e.dungeon.shift();
			e.dungeonDiscard.push(e.row[n]), e.row[n] = r ?? null, qe(e, t.rid, "replace"), r && L[r.kind].arrive.length && Xe(e, t, r.kind, "arrive", () => U(e, t, `${r.kind}#${r.uid}`, L[r.kind].arrive, !0));
			break;
		}
		case "free-market-here":
			u.includes("market") && U(e, t, n, [P("free-market")], !0);
			break;
		case "flute":
			e.turn.flags.push(`flute:${n}`);
			break;
		case "free-market":
			K(e, t, n, "market", [..._t(e, t).map((e) => q("market", [Y("market-target", e, 0)], e)), bn()]);
			break;
		case "market-target":
			yt(e, t, s, r.n ?? 0), e.turn.flags.push(`flute-used:${n}`);
			break;
		case "black-market":
			K(e, t, n, "black-market", [
				q("gold", [N("gold", 2), Y("black-market-second", "gold")]),
				q("pick", [N("picks", 1), Y("black-market-second", "pick")]),
				...Tn(t).length ? [q("trash", [P("trash"), Y("black-market-second", "trash")])] : []
			]);
			break;
		case "black-market-second":
			K(e, t, n, "black-market", [
				["gold", N("gold", 2)],
				["pick", N("picks", 1)],
				["trash", P("trash")]
			].filter(([e]) => e !== s).map(([e, t]) => q(e, [t])));
			break;
		case "remote-shrine":
			K(e, t, n, "shrine", [...Object.keys(e.rooms).filter((n) => H(e.tiles, n, "wayshrine") && !Object.values(e.rooms[n].marks).includes(t.rid) && Object.keys(e.rooms[n].marks).filter((e) => e.startsWith("wayshrine")).length < 4 && t.supply > 0).map((e) => q("mark", [Y("mark-remote", e)], e)), bn()]);
			break;
		case "mark-remote":
			Vn(e, t, s, "wayshrine");
			break;
		case "return-artifact":
			K(e, t, n, "artifact", [...Object.values(e.rooms).filter((e) => e.artifacts.some((e) => e !== 16)).map((e) => q("return", [Y("return-artifact-target", e.id)], e.id)), bn()]);
			break;
		case "return-artifact-target": {
			let t = e.rooms[s], n = Math.min(...t.artifacts.filter((e) => e !== 16));
			t.artifacts.splice(t.artifacts.indexOf(n), 1), e.artifacts.unshift(n);
			break;
		}
		case "remote-artifact":
			K(e, t, n, "artifact", [...Object.values(e.rooms).filter((n) => n.artifacts.some((e) => e !== 16) && t.artifacts.length < ze(t) && (e.players.length < 5 || !t.artifacts.some((e) => e.room === n.id))).map((e) => q("artifact", [Y("artifact-target", e.id)], e.id)), bn()]);
			break;
		case "artifact-target":
			rn(e, t, s, a);
			break;
		case "rotate-lone":
		case "rotate-occupied": {
			let r = e.tiles.filter((t) => !t.kind.startsWith("start") && t.zone === "catacombs" && e.players.some((n) => n.state === "active" && V(e.tiles, n.room).tile.id === t.id) && (o !== "rotate-lone" || e.players.filter((n) => n.state === "active" && V(e.tiles, n.room).tile.id === t.id).length === 1));
			if (o === "rotate-lone") for (let t of r) U(e, e.players.find((n) => n.state === "active" && V(e.tiles, n.room).tile.id === t.id), n, [Y("rotate-tile-choice", String(t.id))]);
			else for (let n of r) n.rotation = (n.rotation + 2) % 4, qe(e, t.rid, "rotate");
			break;
		}
		case "rotate-tile-choice": {
			let r = e.tiles.find((e) => e.id === +s);
			K(e, t, n, "rotate", [
				1,
				2,
				3
			].map((e) => q("rotate", [Y("rotate-tile", s, (r.rotation + e) % 4)], String(e))));
			break;
		}
		case "rotate-tile":
			e.tiles.find((e) => e.id === +s).rotation = r.n, qe(e, t.rid, "rotate");
			break;
		case "place-anywhere":
		case "place-adjacent": {
			if (o === "place-adjacent" && Fe(e, t)) {
				let r = l.tile.slot ? [-1, 1].map((e) => "ABCDE"[("ABCDE".indexOf(l.tile.slot) + e + 5) % 5]) : [..."ABCDE"];
				e.underworldDeck.length && K(e, t, n, "place", r.filter((t) => !e.tiles.some((e) => e.slot === t)).map((e) => q("place", [Y("place-underworld", e)], e)));
				break;
			}
			let r = /* @__PURE__ */ new Set();
			for (let t of e.tiles.filter((e) => e.zone === "catacombs" && (o !== "place-adjacent" || e.id === l.tile.id))) for (let [n, i] of [
				[-1, 0],
				[1, 0],
				[0, -1],
				[0, we[t.kind].height]
			]) {
				let a = t.x + n, o = t.y + i;
				e.tiles.some((e) => e.zone === "catacombs" && a === e.x && o >= e.y && o < e.y + we[e.kind].height) || r.add(`${a},${o}`);
			}
			e.tileDeck.length && K(e, t, n, "place", [...r].map((e) => q("place", [Y("place-at", e, Number(o === "place-adjacent"))], e)));
			break;
		}
		case "place-underworld": {
			let r = Kt(e, e.underworldDeck.shift(), 5, 0, 0, s);
			U(e, t, n, [Y("guardian-tile-reward", String(r.id))], !0);
			break;
		}
		case "place-at": {
			let [r, i] = s.split(",").map(Number);
			e.placement = {
				kind: e.tileDeck.shift(),
				x: r,
				y: i,
				rotations: [
					0,
					1,
					2,
					3
				],
				free: !0,
				notice: Ke(e)
			}, c && U(e, t, n, [Y("guardian-tile-reward", String(e.tileUid))]);
			break;
		}
		case "guardian-tile-reward": {
			let r = Object.values(e.rooms).filter((e) => e.id.startsWith(`${s}/`));
			K(e, t, n, "teleport", [q("gold", [N("gold", 2)]), ...r.filter((n) => $t(e, t, n.id, e.turn.swords)).map((e) => q("teleport", [Y("enter", e.id)], e.id))]);
			break;
		}
		case "redraw-placement": {
			let t = e.placement;
			e.tileDeck.push(t.kind), t.kind = e.tileDeck.shift(), t.rotations = wt(t.kind, t.port), e.turn.flags = e.turn.flags.filter((e) => !["reroll-tile", "reroll-no-artifact"].includes(e));
			break;
		}
		case "hoard-exit":
			an(e, t, t.room);
			break;
		case "end-turn":
			e.turn.flags.push("end-ready");
			break;
		case "pit": {
			let r = t.hand.filter((e) => e.kind !== "stumble").map((e) => q("trash", [Y("pit-trash", String(e.uid))], String(e.uid)));
			(ct(t, 1) || e.turn.flags.includes("forced-entry")) && r.push(q("fall", [P("fall")])), K(e, t, n, "pit", r);
			break;
		}
		case "fall":
			st(e, t, 1), e.turn.flags.push("pit-stop");
			break;
		case "encounter": {
			if (!e.rooms[t.room].monsters.includes(s)) break;
			let r = Pe[s], i = [];
			e.turn.swords >= r.swords && (s !== "medusa" || en(e, t)) && i.push(q("fight", [Y("fight-room", s)])), (ct(t, r.damage) || e.turn.flags.includes("forced-entry")) && i.push(q("damage", [Y("room-damage", s)])), K(e, t, n, "encounter", i);
			break;
		}
		case "room-damage":
			st(e, t, Pe[s].damage);
			break;
		case "clear-forced-entry":
			e.turn.flags = e.turn.flags.filter((e) => e !== "forced-entry");
			break;
		case "fight-room":
			Bn(e, t, s, "swords");
			break;
		case "fate": {
			if (t.fates.length >= 1 + Number(St(t, "gauntlets"))) break;
			let n = e.fateDeck.splice(0, 3);
			K(e, t, "fate", "fate", n.map((e) => q("fate", [Y("take-fate", e), ...n.filter((t) => t !== e).map((e) => Y("bottom-fate", e))], e)));
			break;
		}
		case "bottom-fate":
			e.fateDeck.push(s);
			break;
		case "take-fate":
			t.fates.push(s), e.turn.flags.push(`fate-new:${s}`), [
				"lovers",
				"chariot",
				"hanged-man",
				"judgement"
			].includes(s) && zn(e, t, s);
			break;
		case "reveal-fate":
			zn(e, t, s);
			break;
		case "star-hit":
			K(e, t, "star", "star", [q("reveal", [Y("star-save", void 0, c)]), q("damage", [Y("bag-damage", void 0, c)])]);
			break;
		case "star-save":
			t.revealedFates.push("star"), t.supply += c;
			break;
		case "bag-damage":
			st(e, t, c, "bag");
			break;
		case "ghost-hit": {
			let n = Object.values(e.rooms).filter((e) => Object.entries(e.marks).some(([e, n]) => e.startsWith("aegis") && n === t.rid)), r = [...t.hand, ...t.played].filter((e) => ["white-tourmaline", "black-tourmaline"].includes(e.kind));
			n.length || r.length ? K(e, t, "ghost", "ghost", [
				q("damage", [P("ghost-damage")]),
				...n.map((e) => q("aegis", [Y("aegis-save", e.id)], e.id)),
				...r.map((e) => q("discard", [Y("tourmaline-save", String(e.uid))], String(e.uid)))
			]) : st(e, t, 1, "ghost");
			break;
		}
		case "ghost-damage":
			st(e, t, 1, "ghost");
			break;
		case "aegis-save": {
			let n = e.rooms[s], r = Object.keys(n.marks).find((e) => e.startsWith("aegis") && n.marks[e] === t.rid);
			delete n.marks[r], t.supply++;
			break;
		}
		case "tourmaline-save":
			for (let e of [
				t.hand,
				t.played,
				t.discard
			]) {
				let n = e.findIndex((e) => e.uid === +s);
				if (n >= 0) {
					e !== t.discard && t.discard.push(...e.splice(n, 1));
					break;
				}
			}
			rt(e, t, 1);
			break;
		case "titan-reserve": {
			let t = e.row.findIndex((e) => e?.kind === "nether-titan");
			t >= 0 && (e.row[t] = null, e.reserve["nether-titan"] = 1);
			break;
		}
		case "hydra-stock":
			e.reserve.hydra = 10;
			break;
		case "hydra-silver":
			if (e.reserve.hydra) {
				let n = Math.min(2, e.reserve.hydra);
				e.reserve.hydra -= n, W(e, t, "silver", n);
			}
			break;
		case "acid": {
			t.deck.length || (t.deck = tt(e, t.discard), t.discard = []);
			let r = t.deck.shift();
			r && (t.hand.push(r), qe(e, t.rid, "draw"), K(e, t, n, "acid", [q("trash", [Y("trash-target", String(r.uid))], String(r.uid)), q("discard", [Y("discard-target", String(r.uid)), N("swords", 2)], String(r.uid))]));
			break;
		}
		case "mirror": {
			let n = t.deck;
			t.deck = tt(e, t.discard), t.discard = n, qe(e, t.rid, "mirror");
			break;
		}
		case "kazoo":
			e.reserve[`kazoo:${t.rid}`] = 6;
			break;
		case "kazoo-turn":
			U(e, t, n, [Y("kazoo-gold")], !0);
			break;
		case "kazoo-gold": {
			let n = Math.min(2, e.reserve[`kazoo:${t.rid}`]);
			e.reserve[`kazoo:${t.rid}`] -= n, it(e, t, 2), W(e, t, "gold", n);
			break;
		}
		case "played-tome": {
			let n = (e.turn.totals.tomes ?? 0) + 1;
			e.turn.totals.tomes = n;
			let r = t.trophies.filter((e) => e === "evil-wizard").length;
			n === 1 && rt(e, t, r), n === 2 && (it(e, t, 2 * r), t.trophies = t.trophies.filter((e) => e !== "evil-wizard"));
			break;
		}
		case "keep-trophy":
			t.trophies.includes(s) || t.trophies.push(s);
			break;
		case "trash-trophy-draw3":
			K(e, t, n, "trophy", t.trophies.map((e) => q("trash", [Y("trash-trophy", e), {
				op: "draw",
				n: 3
			}], e)));
			break;
		case "trash-trophy":
			t.trophies.splice(t.trophies.indexOf(s), 1);
			break;
		case "acquire-any":
		case "acquire4-backpack":
		case "free-row":
		case "levitate":
		case "acrobatics":
			K(e, t, n, "acquire", [...e.row.flatMap((e, n) => e && !["monster", "device"].includes(L[e.kind].type) && (!["acquire4-backpack", "acrobatics"].includes(o) || L[e.kind].cost <= 4) ? [q("acquire", [Y(o === "levitate" || o === "acrobatics" || o === "acquire4-backpack" && St(t, "backpack") ? "row-hand" : "row-free", String(n))], String(n))] : []), bn()]);
			break;
		case "row-free":
			gt(e, t, +s, !0);
			break;
		case "row-hand":
			gt(e, t, +s, !0, !0);
			break;
		case "swap-meet":
			(He(u) || Ue(u)) && t.trophies.length && K(e, t, n, "trophy", [...t.trophies.map((e) => q("trash", [
				Y("trash-self"),
				Y("trash-trophy", e),
				Y("free-market")
			], e)), bn()]);
			break;
		case "behavior":
		case "behavior-double":
			K(e, t, n, "behavior", [
				"skill",
				"swords",
				"boots"
			].filter((e) => !t.behavior.includes(e)).map((e) => q(e, [Y("flip-behavior", e, o === "behavior-double" && Le(t) ? 2 : 1)])));
			break;
		case "flip-behavior":
			t.behavior.push(s), W(e, t, s, c);
			break;
		case "finds-choice":
			K(e, t, n, "finds", wn(t).map((e) => q(e, e === "egg" ? [N("clank", -2)] : e === "idol" ? [P("trash-burgle")] : e === "crown" ? [{
				op: "flag",
				flag: "ignoreCave"
			}] : [{
				op: "flag",
				flag: "market-anywhere"
			}])));
			break;
		case "carnage": {
			let r = [
				[["gold", [N("gold", 1)]], ["skill", [N("skill", 1)]]],
				[["skill", [N("skill", 1)]], ["boots", [N("boots", 1)]]],
				[["gold", [N("gold", 2)]], ["draw", [{
					op: "draw",
					n: 1
				}]]],
				[["minor", [P("minor")]]],
				[["skill", [N("skill", 2)]], ["heal", [N("heal", 1)]]]
			][t.carnage];
			t.carnage = (t.carnage + 1) % 5, K(e, t, n, "carnage", r.map(([e, t]) => q(e, t)));
			break;
		}
		case "copy-target": {
			let n = t.played.find((e) => e.uid === +s);
			In(e, t, n.kind, `${n.kind}#${e.uid++}`);
			break;
		}
		case "duplicate":
			Dn(e, t, n, "copy", t.played, "copy-target", [], !1);
			break;
		case "transfigure":
			Dn(e, t, n, "discard", t.hand, "discard-target", [{
				op: "draw",
				n: 1
			}], !1);
			break;
		case "inspire":
			Dn(e, t, n, "top", t.played.filter((e) => L[e.kind].type === "companion"), "inspire-top", [], !0);
			break;
		case "inspire-top": {
			let n = t.played.findIndex((e) => e.uid === +s);
			n >= 0 && (t.deck.unshift(...t.played.splice(n, 1)), qe(e, t.rid, "top"));
			break;
		}
		case "leprechaun-all":
			kn(e, n, "leprechaun-arrive");
			break;
		case "leprechaun-arrive":
			K(e, t, n, "leprechaun", [q("quiet", [N("gold", 2), N("clank", 1)]), q("loud", [N("gold", 5), N("clank", 3)])]);
			break;
		case "leprechaun":
			U(e, t, n, [N("gold", 7), N("clank", 4)], !0);
			break;
		case "offer-burgle-all":
		case "offer-tome-all":
		case "offer-burgle-discard-all":
		case "offer-draw-all":
		case "healer-all":
		case "offer-heal-gold-all":
			kn(e, n, o.replace(/-all$/, "-one"));
			break;
		case "offer-burgle-one":
			Dn(e, t, n, "discard", t.hand.filter((e) => e.kind === "burgle"), "discard-target", [N("clank", -2)]);
			break;
		case "offer-burgle-discard-one":
			Dn(e, t, n, "trash", [...t.hand, ...t.discard].filter((e) => e.kind === "burgle"), "trash-target", [N("clank", 1)]);
			break;
		case "offer-tome-one":
			K(e, t, n, "tome", [...Re(t) >= 5 && e.reserve.tome ? [q("tome", [Y("pay5-tome")])] : [], bn()]);
			break;
		case "pay5-tome":
			Be(t, 5), ht(e, t);
			break;
		case "offer-draw-one":
			K(e, t, n, "draw", [q("gold", [N("gold", 1)]), q("draw", [{
				op: "draw",
				n: 1
			}, N("clank", 1)])]);
			break;
		case "healer-one":
			K(e, t, n, "heal", [q("heal", [N("heal", 1), N("clank", 2)]), bn()]);
			break;
		case "offer-heal-gold-one":
			K(e, t, n, "heal", [...Re(t) >= 1 ? [q("heal", [Y("pay1-heal")])] : [], bn()]);
			break;
		case "pay1-heal":
			Be(t, 1), at(e, t, 1);
			break;
		case "pixie":
			kn(e, n, "pixie-one");
			break;
		case "pixie-one":
			K(e, t, n, "reveal", [...t.hand.filter((e) => L[e.kind].swords > 0).map((e) => q("reveal", [N("gold", 1), Y("reveal-card", e.kind)], String(e.uid))), bn()]);
			break;
		case "reveal-card":
			e.log.push({
				event: "reveal",
				rid: t.rid,
				card: s
			}), qe(e, t.rid, "reveal", 1, s);
			break;
		case "scuffler":
			U(e, t, n, [
				N("gold", 2),
				N("clank", -2),
				Y("trash-discard-burgle")
			]);
			for (let r of e.players.filter((e) => e.rid !== t.rid && e.state === "active")) U(e, r, n, [Y("scuffler-one")]);
			break;
		case "trash-discard-burgle":
			Dn(e, t, n, "trash", t.discard.filter((e) => e.kind === "burgle"));
			break;
		case "scuffler-one":
			K(e, t, n, "scuffler", [
				q("quiet", [N("clank", -2)]),
				q("gold", [N("gold", 2)]),
				q("trash", [Y("trash-discard-burgle")])
			]);
			break;
		case "spotter":
			kn(e, n, "spotter-one");
			break;
		case "spotter-one":
			K(e, t, n, "spotter", [q("gold", [N("clank", 1), N("gold", 2)]), bn()]);
			break;
		case "succubus":
			for (let r of e.players.filter((e) => e.rid !== t.rid && e.state === "active")) U(e, r, n, [Y("succubus-one")]);
			break;
		case "succubus-one":
			K(e, t, n, "succubus", [q("gold", [N("gold", 3)]), q("heal", [N("heal", 1)])]);
			break;
		case "phantasm":
			K(e, t, n, "phantasm", [...Object.values(e.rooms).filter((t) => H(e.tiles, t.id, "idol")).flatMap((e) => Array.from({ length: t.idols.length }, (t, n) => q("return", [Y("return-idols", e.id, n + 1)], `${e.id}:${n + 1}`))), bn()]);
			break;
		case "return-idols":
			e.rooms[s].idols.push(...t.idols.splice(0, c));
			for (let n = 0; n < c; n++) ht(e, t);
			break;
		default: throw Error(`Unknown effect: ${o}`);
	}
}
function In(e, t, n, r) {
	let i = L[n];
	Xe(e, t, n, "play", () => U(e, t, r, [
		N("skill", i.skill),
		N("swords", i.swords),
		N("boots", i.boots),
		...i.play,
		...i.tome || n === "tome-of-the-ape-lords" && t.idols.length ? [P("played-tome")] : []
	]));
}
function Ln(e, t, n) {
	[
		"skill5",
		"gold5",
		"gold2",
		"silver4",
		"pick"
	].includes(n) ? W(e, t, n === "pick" ? "picks" : n.startsWith("gold") ? "gold" : n.startsWith("silver") ? "silver" : "skill", n === "pick" ? 1 : +n.at(-1)) : n === "spring" ? t.spring++ : (t.tokens.push(n), n === "egg" && (ut(e), G(e, "egg"), G(e, "find"))), e.log.push({
		event: "secret",
		rid: t.rid,
		token: n
	}), qe(e, t.rid, "secret");
}
function Rn(e, t, n) {
	["coupon", "soul-elixir"].includes(n) ? t.tokens.push(n) : n === "monkeybot" ? (t.idols.push(3), G(e, "idol")) : (t.prisoners.push(n), e.turn.freed++, G(e, "freed")), n === "barbarian" && W(e, t, "swords", 2), n === "cleric" && at(e, t, 1), (n === "haunted" || n === "myrmidon") && lt(e), (n === "adventurer" || n === "soul-elixir") && ut(e), n === "faithful" && W(e, t, "silver", 1), n === "myrmidon" && e.turn.underworld && W(e, t, "swords", 1), e.log.push({
		event: "prisoner",
		rid: t.rid,
		token: n
	}), qe(e, t.rid, "prisoner");
}
function zn(e, t, n) {
	t.revealedFates.includes(n) || (t.revealedFates.push(n), n === "lovers" && at(e, t, 2), n === "hanged-man" && lt(e), n === "judgement" && vn(e, 0, "play"), n === "tower" && W(e, t, "gold", 3), n === "high-priestess" && e.turn.flags.push("ignoreCave"), n === "hierophant" && U(e, t, n, [P("teleport")], !0), n === "chariot" && W(e, t, "boots", 1), e.log.push({
		event: "fate",
		rid: t.rid,
		token: n
	}));
}
function Bn(e, t, n, r) {
	if (n === "goblin") {
		e.turn.swords -= 2, W(e, t, "gold", 1), e.turn.defeated++, G(e, "defeat"), G(e, "goblin"), t.character === "garignar" && e.turn.defeated === 1 && U(e, t, "goblin", [P("carnage")]);
		return;
	}
	if (n === "nether-titan") {
		e.turn.swords -= L[n].cost, e.reserve[n]--, t.trophies.push(n), t.trophies.includes("heart-of-the-dark") && it(e, t, -2), e.turn.defeated++, G(e, "defeat"), t.character === "garignar" && e.turn.defeated === 1 && U(e, t, xn(n), [P("carnage")]), e.log.push({
			event: "defeat",
			rid: t.rid,
			card: n
		});
		return;
	}
	let i = e.rooms[t.room], a = i.monsters.indexOf(n);
	e.turn[r] -= n === "sphinx" ? r === "skill" ? 7 : 4 : n === "statue" ? 3 : Pe[n].swords, i.monsters.splice(a, 1), t.trophies.push(n), t.trophies.includes("heart-of-the-dark") && it(e, t, -2), n === "sphinx" && W(e, t, "gold", 7), n === "medusa" && rt(e, t, 2), n === "guardian" && (t.enhancer = e.enhancers.shift(), ut(e)), n === "harpy" && W(e, t, "silver", t.trophies.filter((e) => e === "harpy" || e === "harpy-matriarch").length), n === "statue" && U(e, t, "statue", [P("teleport-lair-forced")]), e.log.push({
		event: "defeat",
		rid: t.rid,
		token: n
	});
}
function Vn(e, t, n, r, i = "gold") {
	let a = e.rooms[n], o = r.split(":")[0];
	if (t.supply--, a.marks[r] = t.rid, i.startsWith("trophy:") && t.trophies.splice(t.trophies.indexOf(i.slice(7)), 1), o === "wayshrine" && W(e, t, "gold", Ve(e, t, "wayshrine")), o === "altar" && U(e, t, n, [N("gold", 2), P("remote-artifact")]), o === "bazaar" && (i === "gold" && Be(t, 3), r.endsWith("0") && at(e, t, 3), r.endsWith("1") && K(e, t, n, "order", [q("trash", [P("trash"), {
		op: "draw",
		n: 1
	}]), q("draw", [{
		op: "draw",
		n: 1
	}, P("trash")])]), r.endsWith("2") && U(e, t, n, [P("free-row")]), r.endsWith("3") && U(e, t, n, [P("free-market")])), o === "temple") {
		let i = [
			2,
			3,
			5,
			8
		][+r.split(":")[1]];
		Be(t, i), at(e, t, i === 3 ? 2 : 1), i === 2 && t.picks++, i === 5 && U(e, t, n, [P("major")]), i === 8 && U(e, t, n, [P("remote-artifact")]);
	}
}
function Hn(e, t, n) {
	t.picks--, G(e, "pick-spent"), e.rooms[t.room].opened.push(n), n === "chest" && (U(e, t, t.room, [P("major")]), H(e.tiles, t.room, "hoard") && U(e, t, t.room, [P("hoard-exit")])), n === "library" && ht(e, t), n === "prison" && U(e, t, t.room, Array.from({ length: H(e.tiles, t.room, "prison3") ? 3 : 2 }, () => P("prisoner")));
}
function Un(e, t, n) {
	if (n.startsWith("fate:")) {
		zn(e, t, n.slice(5));
		return;
	}
	if (n === "spring") {
		t.spring--, U(e, t, n, [P("trash")]);
		return;
	}
	if (t.tokens.splice(t.tokens.indexOf(n), 1), G(e, "potion"), (n === "heal1" || n === "heal2" || n === "greater-hope") && at(e, t, n === "heal1" || n === "greater-hope" && !Fe(e, t) ? 1 : 2), (n === "boots" || n === "greater-hope" || n === "hope" && Fe(e, t)) && W(e, t, "boots", 1), (n === "swords" || n === "hope") && W(e, t, "swords", n === "swords" ? 2 : 1), n === "stealth") {
		it(e, t, -1);
		for (let n of e.players.filter((e) => e.rid !== t.rid)) it(e, n, 1);
	}
	n === "soul-elixir" && at(e, t, 2), n === "chute" && (e.rooms[t.room].chute = !0);
}
//#endregion
//#region src/games/clankcatacombs/legal.ts
function Wn(e, t, n) {
	let r = L[n].react, i = e.turn.events;
	return !r || t.state !== "active" || t.rid === ce(e).rid && (e.phase === "play" || e.phase === "dragon" && e.attack?.after === "play" || ![
		"monster-arrive",
		"row-companions2",
		"spaces3",
		"dragon-damage"
	].includes(r)) ? !1 : r === "find" ? [
		"egg",
		"idol",
		"crown",
		"artifact"
	].some((e) => i.includes(e) && (e === "egg" ? !t.tokens.includes("egg") : e === "idol" ? !t.idols.length : e === "crown" ? !t.items.some((e) => ["crown", "jester-cap"].includes(e.kind)) : !Le(t))) : r === "crown-without" ? i.includes("crown") && !t.items.some((e) => ["crown", "jester-cap"].includes(e.kind)) : r === "row-companions2" ? e.row.filter((e) => e && L[e.kind].type === "companion").length >= 2 : r === "spaces3" ? e.row.filter((e) => !e).length >= 3 : r === "secrets2" ? (e.turn.totals["event:secret"] ?? 0) >= 2 || i.includes("major-secret") : r === "end-cave" ? e.phase === "refill" && H(e.tiles, ce(e).room, "cave") : r === "end-still" ? e.phase === "refill" && e.turn.moved === 0 : r === "end-noise2" ? e.phase === "refill" && ce(e).clank >= 2 : r === "dragon-damage" ? i.includes(`dragon-damage:${t.rid}`) : i.includes(r);
}
function Gn(e, t) {
	if (e.phase === "done") return [];
	let n = e.players.find((e) => e.rid === t);
	if (!n || n.state !== "active") return [];
	if (e.choice) return e.choice.rid === t ? e.choice.options.map((e) => e.action) : [];
	if (e.phase === "characters") return ce(e).rid === t ? e.availableCharacters.map((e) => ({
		type: "choose",
		option: "character",
		target: e
	})) : [];
	if (e.placement) return ce(e).rid === t ? e.placement.rotations.map((e) => ({
		type: "orient",
		rotation: e
	})) : [];
	if (e.reaction) return e.reaction.seats[e.reaction.at] === t ? [...n.hand.filter((t) => Wn(e, n, t.kind)).map((e) => ({
		type: "react",
		card: e.uid
	})), { type: "pass" }] : [];
	if (e.queue.length || e.phase !== "play" || t !== ce(e).rid) return [];
	let r = n.hand.map((e) => ({
		type: "play",
		card: e.uid
	}));
	e.row.forEach((t, i) => {
		t && ft(e, n, t.kind) && e.turn[L[t.kind].type === "monster" ? "swords" : "skill"] >= dt(e, t.kind) && r.push({
			type: "row",
			slot: i
		});
	});
	for (let t of [
		"explore",
		"mercenary",
		"tome"
	]) e.reserve[t] && e.turn.skill >= L[t].cost && r.push({
		type: "reserve",
		card: t
	});
	if (!e.turn.flags.includes("escaping")) for (let t of Xt(e, n, e.pendingMove?.teleport)) {
		let i = Math.min(t.monsters, e.turn.swords);
		for (let a = 0; a <= i; a++) tn(e, n, t, a, e.pendingMove?.teleport) && r.push({
			type: "move",
			route: t.id,
			swords: a
		});
	}
	if (e.pendingMove) {
		if (e.pendingMove.start) {
			let t = e.tiles.find((t) => t.id === +e.pendingMove.start.split("/")[0]);
			for (let i of t.zone === "catacombs" ? wt(t.kind, e.pendingMove.route.discover.port) : []) if (i !== t.rotation) {
				let t = Zt(e, i);
				Xt(t, n).some((r) => tn(t, n, r, Qt(t, n) ? 0 : Math.min(r.monsters, e.turn.swords), e.pendingMove.teleport)) && r.push({
					type: "orient",
					rotation: i
				});
			}
		}
		return r;
	}
	let i = e.rooms[n.room], a = V(e.tiles, n.room).def.features;
	if (i.artifacts.length && n.artifacts.length < 1 + n.items.filter((e) => e.kind === "backpack").length + Number(n.revealedFates.includes("justice")) && (e.players.length < 5 || !n.artifacts.some((e) => e.room === n.room)) && r.push({
		type: "artifact",
		room: n.room
	}), n.picks) for (let t of [
		"chest",
		"library",
		"prison"
	]) i.opened.includes(t) || !a.includes(t) && !(t === "prison" && a.includes("prison3")) || (t === "chest" ? e.majorBank.length : t === "library" ? e.reserve.tome : e.prisonerBank.length) && r.push({
		type: "unlock",
		feature: t
	});
	if (n.supply) {
		let t = (t, i, a, o = ["gold"]) => {
			let s = e.rooms[t];
			if (!Object.values(s.marks).includes(n.rid)) {
				for (let e = 0; e < a; e++) if (!s.marks[`${i}:${e}`]) for (let n of o) r.push({
					type: "mark",
					slot: `${t}|${i}:${e}`,
					payment: n
				});
			}
		};
		if (a.includes("wayshrine") && t(n.room, "wayshrine", 4), a.includes("aegis") && t(n.room, "aegis", 4), a.includes("altar") && t(n.room, "altar", 1, n.trophies.map((e) => `trophy:${e}`)), a.includes("bazaar") && t(n.room, "bazaar", 4, [...Re(n) >= 3 ? ["gold"] : [], ...n.trophies.map((e) => `trophy:${e}`)]), a.includes("wayshrine")) for (let t of Object.values(e.rooms).filter((t) => H(e.tiles, t.id, "temple") && !Object.values(t.marks).includes(n.rid))) for (let e = 0; e < 4; e++) !t.marks[`temple:${e}`] && Re(n) >= [
			2,
			3,
			5,
			8
		][e] && r.push({
			type: "mark",
			slot: `${t.id}|temple:${e}`,
			payment: "gold"
		});
	}
	let o = e.turn.flags.filter((e) => e.startsWith("flute:"));
	if (a.includes("market") || e.turn.flags.includes("market-anywhere") || o.length) for (let t of _t(e, n)) for (let i of [...a.includes("market") || e.turn.flags.includes("market-anywhere") ? [
		"",
		...n.tokens.includes("coupon") ? ["coupon"] : [],
		...Fe(e, n) && n.tokens.includes("dark-iron") ? ["dark-iron"] : []
	] : [], ...o]) {
		let a = vt(e, n, i);
		for (let e = Math.max(0, a - n.gold); e <= Math.min(a, n.silver); e++) r.push({
			type: "market",
			item: t,
			discount: i,
			silver: e
		});
	}
	e.turn.swords >= 2 && r.push({
		type: "fight",
		monster: "goblin",
		resource: "swords"
	}), e.reserve["nether-titan"] && e.turn.swords >= L["nether-titan"].cost && r.push({
		type: "fight",
		monster: "nether-titan",
		resource: "swords"
	});
	for (let t of new Set(i.monsters)) {
		let i = t === "sphinx" ? 4 : t === "statue" ? 3 : Pe[t]?.swords ?? Infinity;
		e.turn.swords >= i && (t !== "medusa" || en(e, n)) && r.push({
			type: "fight",
			monster: t,
			resource: "swords"
		}), t === "sphinx" && e.turn.skill >= 7 && r.push({
			type: "fight",
			monster: t,
			resource: "skill"
		});
	}
	for (let t of new Set(n.tokens)) ([
		"heal1",
		"heal2",
		"boots",
		"swords",
		"hope",
		"greater-hope",
		"stealth"
	].includes(t) || t === "soul-elixir" && Fe(e, n) || t === "chute" && !Fe(e, n) && !i.chute) && r.push({
		type: "use",
		token: t
	});
	n.spring && r.push({
		type: "use",
		token: "spring"
	});
	for (let t of n.fates) !n.revealedFates.includes(t) && (t === "justice" || ["high-priestess", "hierophant"].includes(t) && !e.turn.flags.includes(`fate-new:${t}`) || t === "tower" && a.includes("tower")) && r.push({
		type: "use",
		token: `fate:${t}`
	});
	if (n.character === "lenara") for (let [t, i, a] of [
		[
			"transfigure",
			3,
			n.hand.length > 0
		],
		[
			"duplicate",
			5,
			n.played.length > 0
		],
		[
			"levitate",
			7,
			e.row.some((e) => e && !["device", "monster"].includes(L[e.kind].type))
		]
	]) a && n.mana >= i && !e.turn.spells.includes(t) && r.push({
		type: "spell",
		spell: t
	});
	return n.hand.length || r.push({ type: "end" }), r;
}
//#endregion
//#region src/games/clankcatacombs/meta.ts
var Kn = {
	id: "clankcatacombs",
	tier: "alpha",
	nameKey: "games.clankcatacombs.name",
	descKey: "games.clankcatacombs.desc",
	rulesKey: "games.clankcatacombs.rules",
	icon: "🐉",
	iconImg: "games/clankcatacombs.webp",
	minPlayers: 2,
	maxPlayers: 6,
	playerRange: (e) => ({
		min: 2,
		max: typeof e == "object" && e && "party" in e && e.party ? 6 : 4
	}),
	mechanics: [
		"deck-bag-building",
		"push-your-luck",
		"race",
		"set-collection"
	],
	interactionTags: [],
	accent: "#635083",
	releasedAt: "2026-10-27T17:30:25+08:00",
	hotseat: "cover",
	search: {
		py: "jin sheng xun bao ji di xia mu xue clank catacombs",
		init: "jsxbjdxmx"
	},
	rulesUrl: { en: "https://d19y2ttatozxjp.cloudfront.net/pdfs/CLANK_CATACOMBS_Rulebook_and_Token_Reference_Guide.pdf" }
};
//#endregion
//#region src/games/clankcatacombs/rules.ts
function qn(e) {
	let t = ce(e);
	e.turn.flags.includes("escaping") && ot(e, t, !0), t.discard.push(...t.played), t.played = [], t.spring = 0, e.turn.events = [], t.character === "whiskers" && t.behavior.length === 3 ? (t.behavior = [], e.turn.flags.push("cat-cleanup"), vn(e, 4, "refill", t.rid)) : (t.state === "active" && rt(e, t, 5), e.phase = "refill"), e.dragonPending = !1;
}
function Jn(e) {
	let t = ce(e);
	e.turn = ue(), e.turnNumber++, e.phase = "play", e.turn.underworld = Fe(e, t), e.turn.underworld && !t.trophies.includes("nether-titan") && (t.silver ? t.silver-- : it(e, t, 2)), H(e.tiles, t.room, "tower") && W(e, t, "boots", 1);
	for (let n of t.items) n.kind === "wind-boots" && W(e, t, "boots", 1);
	if (t.revealedFates.includes("chariot") && W(e, t, "boots", 1), t.character === "monkeybot") for (let n of [
		"swords",
		"boots",
		"skill",
		"swords",
		"boots",
		"skill",
		"swords"
	].slice(0, t.cogs)) W(e, t, n, 1);
	for (let n of t.reacted) t.played.push(n), In(e, t, n.kind, `${n.kind}#${n.uid}`);
	t.reacted = [], t.trophies.includes("magic-kazoo") && e.reserve[`kazoo:${t.rid}`] && U(e, t, "magic-kazoo", [{
		op: "special",
		id: "kazoo-turn"
	}]);
}
function Yn(e) {
	if (!e.config.party || e.phase === "done" || e.phase === "characters" || e.choice || e.placement || e.queue.length || e.reaction) return;
	let t = `${e.log.length}:${e.turn.events.join(",")}:${e.turn.noiseMade}:${e.turn.moved}:${e.turn.defeated}:${e.phase}`, n = e.players.filter((n) => n.hand.some((t) => Wn(e, n, t.kind)) && !e.turn.triggers.includes(`reaction:${n.rid}:${t}`)).map((e) => e.rid);
	if (n.length) {
		for (let r of n) e.turn.triggers.push(`reaction:${r}:${t}`);
		e.reaction = {
			seats: n,
			at: 0,
			events: [...e.turn.events]
		};
	}
}
function Xn(e, t) {
	if (e.motionMs = 0, e.choice || e.placement || e.reaction || e.phase === "done" || e.phase === "characters") return;
	if (e.queue.length) {
		Nn(e, t), jn(e), e.queue.length || Yn(e);
		return;
	}
	let n = ce(e);
	if (e.turn.flags.includes("end-ready")) {
		e.turn.flags = e.turn.flags.filter((e) => e !== "end-ready"), qn(e);
		return;
	}
	if (e.phase === "dragon") {
		yn(e), e.attack?.resolving && Yn(e);
		return;
	}
	if (e.phase === "play" && n.state === "knocked") {
		e.queue = [], qn(e);
		return;
	}
	if (e.phase === "refill") {
		if (e.players.every((e) => e.state !== "active")) {
			mn(e);
			return;
		}
		e.turn.flags.includes("cat-cleanup") && (e.turn.flags = e.turn.flags.filter((e) => e !== "cat-cleanup"), n.state === "active" && rt(e, n, 5));
		let t = e.row.findIndex((e) => !e);
		if (t >= 0) {
			let r = e.dungeon.shift();
			if (!r) {
				for (let t of e.players) ot(e, t);
				mn(e);
				return;
			}
			e.row[t] = r;
			let i = L[r.kind];
			e.dragonPending ||= i.dragon;
			let a = n.state === "active" ? n : [...e.players.slice(e.active + 1), ...e.players.slice(0, e.active)].find((e) => e.state === "active");
			i.arrive.length && Xe(e, a, r.kind, "arrive", () => U(e, a, `${r.kind}#${r.uid}`, i.arrive)), G(e, i.type === "monster" ? "monster-arrive" : "arrive"), Yn(e);
			return;
		}
		e.dragonPending ? vn(e) : e.phase = "advance";
		return;
	}
	if (e.phase === "advance") {
		if (e.players.every((e) => e.state !== "active")) {
			mn(e);
			return;
		}
		if (e.active = (e.active + 1) % e.players.length, ce(e).state !== "active") {
			vn(e, e.players.length === 2 ? 6 : 4, "advance");
			return;
		}
		Jn(e), Yn(e);
	}
}
function Zn(e, t, n) {
	if (t.type === "tick") {
		if (n !== "$engine") return { code: "games.clankcatacombs.invalid" };
		let t = structuredClone(e), r = [];
		return Xn(t, r), {
			state: t,
			fx: [...r, ...Ze(t, e.noticeSerial ?? 0)]
		};
	}
	if (!Gn(e, n).some((e) => JSON.stringify(e) === JSON.stringify(t))) return { code: "games.clankcatacombs.invalid" };
	let r = structuredClone(e), i = r.players.find((e) => e.rid === n), a = [];
	if (r.motionMs = 0, r.phase === "characters" && t.type === "choose") return qt(r, i, t.target), r.availableCharacters.splice(r.availableCharacters.indexOf(t.target), 1), r.active++, r.active >= r.players.length && (r.active = 0, r.phase = "play"), { state: r };
	switch (t.type) {
		case "choose": {
			let e = r.choice, n = e.options.find((e) => JSON.stringify(e.action) === JSON.stringify(t));
			r.choice = null, r.turn.triggers.push(`selected:${e.source}:${t.option}`), Ye(r, e.notice, () => U(r, i, e.source, n.effects, !0)), e.kind === "reroll" && t.option === "replace" && Nn(r, a);
			break;
		}
		case "play": {
			let e = i.hand.splice(i.hand.findIndex((e) => e.uid === t.card), 1)[0];
			i.played.push(e), In(r, i, e.kind, `${e.kind}#${e.uid}`), r.log.push({
				event: "play",
				rid: n,
				card: e.kind
			});
			break;
		}
		case "row":
			gt(r, i, t.slot);
			break;
		case "reserve":
			r.turn.skill -= L[t.card].cost, r.reserve[t.card]--, pt(r, i, nt(r, t.card));
			break;
		case "move": {
			let e = Xt(r, i, r.pendingMove?.teleport).find((e) => e.id === t.route);
			e.edges.some((e) => e.startsWith("portal:")) && G(r, "portal"), sn(r, e, t.swords, r.pendingMove?.teleport, a);
			break;
		}
		case "orient":
			Ye(r, r.placement?.notice, () => cn(r, t.rotation, a));
			break;
		case "artifact":
			rn(r, i, t.room, a);
			break;
		case "unlock":
			Hn(r, i, t.feature);
			break;
		case "market": {
			let e = vt(r, i, t.discount);
			t.discount.startsWith("flute:") ? r.turn.flags.splice(r.turn.flags.indexOf(t.discount), 1) : t.discount && i.tokens.splice(i.tokens.indexOf(t.discount), 1), yt(r, i, t.item, e, t.silver);
			break;
		}
		case "mark": {
			let [e, n] = t.slot.split("|");
			Vn(r, i, e, n, t.payment);
			break;
		}
		case "fight":
			Bn(r, i, t.monster, t.resource);
			break;
		case "use":
			Un(r, i, t.token);
			break;
		case "spell":
			i.mana -= {
				transfigure: 3,
				duplicate: 5,
				levitate: 7
			}[t.spell], r.turn.spells.push(t.spell), U(r, i, t.spell, [P(t.spell)]);
			break;
		case "react": {
			let e = i.hand.splice(i.hand.findIndex((e) => e.uid === t.card), 1)[0];
			i.reacted.push(e), Xe(r, i, e.kind, "react", () => rt(r, i, 1)), r.log.push({
				event: "react",
				rid: n,
				card: e.kind
			});
			break;
		}
		case "pass":
			r.reaction && ++r.reaction.at >= r.reaction.seats.length && (r.reaction = null);
			break;
		case "end": r.turn.flags.includes("inspire") ? (r.turn.flags = r.turn.flags.filter((e) => e !== "inspire"), U(r, i, "inspire", [P("inspire"), P("end-turn")])) : qn(r);
	}
	return jn(r), Yn(r), {
		state: r,
		fx: [...a, ...Ze(r, e.noticeSerial ?? 0)]
	};
}
function Qn(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.turn, i = e.players.map((t) => {
		let { deck: n, hand: r, fates: i, spring: a, ...o } = t;
		return {
			...o,
			handCount: r.length,
			deckCount: n.length,
			fateCount: i.length,
			revealedFates: e.phase === "done" ? i : t.revealedFates
		};
	});
	return {
		public: {
			config: e.config,
			phase: e.phase,
			active: ce(e).rid,
			turnNumber: e.turnNumber,
			players: i,
			tiles: e.tiles,
			rooms: Object.values(e.rooms),
			tileCount: e.tileDeck.length,
			underworldTileCount: e.underworldDeck.length,
			row: e.row,
			dungeonCount: e.dungeon.length,
			reserve: e.reserve,
			market: e.market,
			artifacts: e.artifacts,
			rage: e.rage,
			blackBag: e.blackBag,
			blackRemoved: e.blackRemoved,
			ghostBag: e.ghostBag,
			ghostClank: e.ghostClank,
			ghostBank: e.ghostBank,
			openedLocks: e.openedLocks,
			turn: {
				skill: r.skill,
				swords: r.swords,
				boots: r.boots,
				stopped: r.stopped,
				noiseMade: r.noiseMade,
				goldGained: r.goldGained,
				flags: r.flags.filter((e) => !e.startsWith("fate-new:")),
				visited: r.visited,
				underworld: r.underworld,
				defeated: r.defeated
			},
			placement: e.placement ? {
				kind: e.placement.kind,
				x: e.placement.x,
				y: e.placement.y,
				rotations: e.placement.rotations
			} : null,
			choice: e.choice ? {
				rid: e.choice.rid,
				kind: e.choice.kind,
				source: e.choice.source.split("#")[0]
			} : null,
			reaction: e.reaction ? {
				rid: e.reaction.seats[e.reaction.at],
				events: e.reaction.events
			} : null,
			scores: e.scores,
			lastDraw: e.lastDraw,
			log: e.log.slice(-160)
		},
		private: {
			hand: n?.hand ?? [],
			fates: n?.fates ?? [],
			peek: e.choice?.rid === t ? e.peek : [],
			actions: Gn(e, t),
			moves: n && t === ce(e).rid ? Xt(e, n, e.pendingMove?.teleport).map((t) => ({
				id: t.id,
				to: t.to,
				boots: t.boots,
				monsters: Qt(e, n) ? 0 : t.monsters,
				picks: t.locks.length,
				silver: n.trophies.includes("nether-titan") ? 0 : t.toll,
				...t.discover ? {
					x: t.discover.x,
					y: t.discover.y
				} : {},
				...t.descend ? { slot: t.descend } : {}
			})) : []
		}
	};
}
var $n = {
	saveCompatibility: { version: "2" },
	meta: Kn,
	schemas: {
		action: It,
		publicView: Wt,
		privateView: Gt,
		config: Pt
	},
	setup: (e, t, n) => ({ state: Jt(e, t, n) }),
	reduce: (e, t, n) => Zn(e, t, n.by),
	viewFor: Qn,
	status: (e) => {
		if (e.phase !== "done") return { phase: e.phase };
		let t = e.players.map((e) => e.rid).sort((t, n) => hn(e, t, n));
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((n) => e.scores[n].eligible && hn(e, n, t[0]) === 0),
			scores: Object.fromEntries(t.map((t) => [t, e.scores[t].total]))
		};
	},
	nextTickIn: (e) => e.choice || e.reaction || e.placement || e.phase === "characters" || e.phase === "done" ? null : e.queue.length || e.turn.flags.includes("end-ready") ? Math.max(gn.effect, e.motionMs ?? 0) : e.phase === "dragon" ? gn.dragon : e.phase === "refill" ? gn.refill : e.phase === "advance" || ce(e).state === "knocked" ? gn.advance : null
}, X = {
	confirmAcquire: "games.clankcatacombs.ui.confirmAcquire",
	confirmDefeat: "games.clankcatacombs.ui.confirmDefeat",
	confirmDevice: "games.clankcatacombs.ui.confirmDevice",
	bubbleArtifact: "games.clankcatacombs.ui.bubbleArtifact",
	bubbleIdol: "games.clankcatacombs.ui.bubbleIdol",
	bubbleTrophy: "games.clankcatacombs.ui.bubbleTrophy",
	bubbleItem: "games.clankcatacombs.ui.bubbleItem",
	bubbleFate: "games.clankcatacombs.ui.bubbleFate",
	bubbleGhost: "games.clankcatacombs.ui.bubbleGhost",
	bubbleTile: "games.clankcatacombs.ui.bubbleTile",
	bubbleRotate: "games.clankcatacombs.ui.bubbleRotate",
	bubbleTop: "games.clankcatacombs.ui.bubbleTop",
	bubbleReplace: "games.clankcatacombs.ui.bubbleReplace",
	bubbleMirror: "games.clankcatacombs.ui.bubbleMirror",
	bubbleReveal: "games.clankcatacombs.ui.bubbleReveal",
	bubbleIgnoreMonsters: "games.clankcatacombs.ui.bubbleIgnoreMonsters",
	bubbleReroll: "games.clankcatacombs.ui.bubbleReroll",
	bubbleRerollArtifact: "games.clankcatacombs.ui.bubbleRerollArtifact",
	bubbleDeviceDiscount: "games.clankcatacombs.ui.bubbleDeviceDiscount",
	bubbleMarketDiscount: "games.clankcatacombs.ui.bubbleMarketDiscount",
	bubbleCountsTome: "games.clankcatacombs.ui.bubbleCountsTome",
	bubbleReverse: "games.clankcatacombs.ui.bubbleReverse",
	bubbleInspire: "games.clankcatacombs.ui.bubbleInspire",
	bubbleAcquire: "games.clankcatacombs.ui.bubbleAcquire",
	bubbleDefeat: "games.clankcatacombs.ui.bubbleDefeat",
	bubbleDevice: "games.clankcatacombs.ui.bubbleDevice",
	bubbleArrive: "games.clankcatacombs.ui.bubbleArrive",
	bubbleDraw: "games.clankcatacombs.ui.bubbleDraw",
	bubbleDiscard: "games.clankcatacombs.ui.bubbleDiscard",
	bubbleTrash: "games.clankcatacombs.ui.bubbleTrash",
	bubbleTeleport: "games.clankcatacombs.ui.bubbleTeleport",
	bubblePrisoner: "games.clankcatacombs.ui.bubblePrisoner",
	bubbleSecret: "games.clankcatacombs.ui.bubbleSecret",
	bubbleIgnoreCave: "games.clankcatacombs.ui.bubbleIgnoreCave",
	bubbleMarket: "games.clankcatacombs.ui.bubbleMarket",
	bubbleMana: "games.clankcatacombs.ui.bubbleMana",
	bubbleHealth: "games.clankcatacombs.ui.bubbleHealth",
	bubbleOtherPlayers: "games.clankcatacombs.ui.bubbleOtherPlayers",
	bubbleSource: "games.clankcatacombs.ui.bubbleSource",
	turn: "games.clankcatacombs.ui.turn",
	yourTurn: "games.clankcatacombs.ui.yourTurn",
	waiting: "games.clankcatacombs.ui.waiting",
	resolving: "games.clankcatacombs.ui.resolving",
	dragon: "games.clankcatacombs.ui.dragon",
	choose: "games.clankcatacombs.ui.choose",
	hand: "games.clankcatacombs.ui.hand",
	dungeon: "games.clankcatacombs.ui.dungeon",
	actions: "games.clankcatacombs.ui.actions",
	freedPrisoners: "games.clankcatacombs.ui.freedPrisoners",
	noPrisoners: "games.clankcatacombs.ui.noPrisoners",
	supplies: "games.clankcatacombs.ui.supplies",
	players: "games.clankcatacombs.ui.players",
	log: "games.clankcatacombs.ui.log",
	close: "games.clankcatacombs.ui.close",
	details: "games.clankcatacombs.ui.details",
	catacombs: "games.clankcatacombs.ui.catacombs",
	basicCard: "games.clankcatacombs.ui.basicCard",
	reserveCard: "games.clankcatacombs.ui.reserveCard",
	actionCard: "games.clankcatacombs.ui.actionCard",
	companion: "games.clankcatacombs.ui.companion",
	gem: "games.clankcatacombs.ui.gem",
	monster: "games.clankcatacombs.ui.monster",
	device: "games.clankcatacombs.ui.device",
	danger: "games.clankcatacombs.ui.danger",
	playedCards: "games.clankcatacombs.ui.playedCards",
	deck: "games.clankcatacombs.ui.deck",
	dragonRage: "games.clankcatacombs.ui.dragonRage",
	room: "games.clankcatacombs.ui.room",
	unknown: "games.clankcatacombs.ui.unknown",
	viewMap: "games.clankcatacombs.ui.viewMap",
	locate: "games.clankcatacombs.ui.locate",
	rotate: "games.clankcatacombs.ui.rotate",
	confirm: "games.clankcatacombs.ui.confirm",
	cancel: "games.clankcatacombs.ui.cancel",
	end: "games.clankcatacombs.ui.end",
	play: "games.clankcatacombs.ui.play",
	row: "games.clankcatacombs.ui.row",
	reserve: "games.clankcatacombs.ui.reserve",
	move: "games.clankcatacombs.ui.move",
	artifact: "games.clankcatacombs.ui.artifact",
	unlock: "games.clankcatacombs.ui.unlock",
	mark: "games.clankcatacombs.ui.mark",
	market: "games.clankcatacombs.ui.market",
	fight: "games.clankcatacombs.ui.fight",
	use: "games.clankcatacombs.ui.use",
	react: "games.clankcatacombs.ui.react",
	pass: "games.clankcatacombs.ui.pass",
	chooseTarget: "games.clankcatacombs.ui.chooseTarget",
	noAction: "games.clankcatacombs.ui.noAction",
	skill: "games.clankcatacombs.ui.skill",
	swords: "games.clankcatacombs.ui.swords",
	boots: "games.clankcatacombs.ui.boots",
	gold: "games.clankcatacombs.ui.gold",
	silver: "games.clankcatacombs.ui.silver",
	picks: "games.clankcatacombs.ui.picks",
	noise: "games.clankcatacombs.ui.noise",
	health: "games.clankcatacombs.ui.health",
	deckCount: "games.clankcatacombs.ui.deckCount",
	artifactCount: "games.clankcatacombs.ui.artifactCount",
	rage: "games.clankcatacombs.ui.rage",
	tiles: "games.clankcatacombs.ui.tiles",
	bag: "games.clankcatacombs.ui.bag",
	turnResources: "games.clankcatacombs.ui.turnResources",
	playArea: "games.clankcatacombs.ui.playArea",
	discard: "games.clankcatacombs.ui.discard",
	fates: "games.clankcatacombs.ui.fates",
	chooseCharacter: "games.clankcatacombs.ui.chooseCharacter",
	orient: "games.clankcatacombs.ui.orient",
	movement: "games.clankcatacombs.ui.movement",
	secretCount: "games.clankcatacombs.ui.secretCount",
	safe: "games.clankcatacombs.ui.safe",
	depths: "games.clankcatacombs.ui.depths",
	underworld: "games.clankcatacombs.ui.underworld",
	active: "games.clankcatacombs.ui.active",
	escaped: "games.clankcatacombs.ui.escaped",
	knocked: "games.clankcatacombs.ui.knocked",
	score: "games.clankcatacombs.ui.score",
	eligible: "games.clankcatacombs.ui.eligible",
	ineligible: "games.clankcatacombs.ui.ineligible",
	expansions: "games.clankcatacombs.ui.expansions",
	lairs: "games.clankcatacombs.ui.lairs",
	underworldOption: "games.clankcatacombs.ui.underworldOption",
	party: "games.clankcatacombs.ui.party",
	characters: "games.clankcatacombs.ui.characters",
	startingTile: "games.clankcatacombs.ui.startingTile",
	front: "games.clankcatacombs.ui.front",
	back: "games.clankcatacombs.ui.back",
	underworldTile: "games.clankcatacombs.ui.underworldTile",
	points: "games.clankcatacombs.ui.points",
	acquireEffect: "games.clankcatacombs.ui.acquireEffect",
	arriveEffect: "games.clankcatacombs.ui.arriveEffect",
	reactEffect: "games.clankcatacombs.ui.reactEffect",
	moveCost: "games.clankcatacombs.ui.moveCost",
	payment: "games.clankcatacombs.ui.payment",
	spell: "games.clankcatacombs.ui.spell",
	scoreArtifacts: "games.clankcatacombs.ui.scoreArtifacts",
	scoreCards: "games.clankcatacombs.ui.scoreCards",
	scoreTokens: "games.clankcatacombs.ui.scoreTokens",
	scoreMarket: "games.clankcatacombs.ui.scoreMarket",
	scoreTrophies: "games.clankcatacombs.ui.scoreTrophies",
	scoreFate: "games.clankcatacombs.ui.scoreFate",
	scoreMastery: "games.clankcatacombs.ui.scoreMastery",
	empty: "games.clankcatacombs.ui.empty",
	chooseRoute: "games.clankcatacombs.ui.chooseRoute",
	underworldSlot: "games.clankcatacombs.ui.underworldSlot",
	mana: "games.clankcatacombs.ui.mana",
	cogs: "games.clankcatacombs.ui.cogs",
	conscription: "games.clankcatacombs.ui.conscription",
	carnage: "games.clankcatacombs.ui.carnage",
	behavior: "games.clankcatacombs.ui.behavior",
	ladder: "games.clankcatacombs.ui.ladder",
	placeTarget: "games.clankcatacombs.ui.placeTarget",
	fateHelp: "games.clankcatacombs.ui.fateHelp",
	"log-play": "games.clankcatacombs.ui.log-play",
	"log-react": "games.clankcatacombs.ui.log-react",
	"log-acquire": "games.clankcatacombs.ui.log-acquire",
	"log-device": "games.clankcatacombs.ui.log-device",
	"log-defeat": "games.clankcatacombs.ui.log-defeat",
	"log-trash": "games.clankcatacombs.ui.log-trash",
	"log-move": "games.clankcatacombs.ui.log-move",
	"log-artifact": "games.clankcatacombs.ui.log-artifact",
	"log-secret": "games.clankcatacombs.ui.log-secret",
	"log-prisoner": "games.clankcatacombs.ui.log-prisoner",
	"log-market": "games.clankcatacombs.ui.log-market",
	"log-dragon": "games.clankcatacombs.ui.log-dragon",
	"log-damage": "games.clankcatacombs.ui.log-damage",
	"log-escape": "games.clankcatacombs.ui.log-escape",
	"log-knockout": "games.clankcatacombs.ui.log-knockout",
	"log-discover": "games.clankcatacombs.ui.log-discover",
	"log-reveal": "games.clankcatacombs.ui.log-reveal",
	"log-fate": "games.clankcatacombs.ui.log-fate"
}, er = {
	adventurer: "games.clankcatacombs.names.adventurer",
	agnet: "games.clankcatacombs.names.agnet",
	dallan: "games.clankcatacombs.names.dallan",
	garignar: "games.clankcatacombs.names.garignar",
	lenara: "games.clankcatacombs.names.lenara",
	monkeybot: "games.clankcatacombs.names.monkeybot",
	whiskers: "games.clankcatacombs.names.whiskers",
	backpack: "games.clankcatacombs.names.backpack",
	amulet: "games.clankcatacombs.names.amulet",
	"amulet-uw": "games.clankcatacombs.names.amulet-uw",
	kit: "games.clankcatacombs.names.kit",
	crown: "games.clankcatacombs.names.crown",
	cloak: "games.clankcatacombs.names.cloak",
	"river-lamp": "games.clankcatacombs.names.river-lamp",
	"wind-boots": "games.clankcatacombs.names.wind-boots",
	gauntlets: "games.clankcatacombs.names.gauntlets",
	"jester-cap": "games.clankcatacombs.names.jester-cap",
	riverboat: "games.clankcatacombs.names.riverboat",
	crypt: "games.clankcatacombs.names.crypt",
	cave: "games.clankcatacombs.names.cave",
	minor: "games.clankcatacombs.names.minor",
	major: "games.clankcatacombs.names.major",
	chest: "games.clankcatacombs.names.chest",
	library: "games.clankcatacombs.names.library",
	prison: "games.clankcatacombs.names.prison",
	prison3: "games.clankcatacombs.names.prison3",
	wayshrine: "games.clankcatacombs.names.wayshrine",
	aegis: "games.clankcatacombs.names.aegis",
	altar: "games.clankcatacombs.names.altar",
	bazaar: "games.clankcatacombs.names.bazaar",
	temple: "games.clankcatacombs.names.temple",
	hoard: "games.clankcatacombs.names.hoard",
	medusa: "games.clankcatacombs.names.medusa",
	sphinx: "games.clankcatacombs.names.sphinx",
	statue: "games.clankcatacombs.names.statue",
	guardian: "games.clankcatacombs.names.guardian",
	harpy: "games.clankcatacombs.names.harpy",
	fate: "games.clankcatacombs.names.fate",
	lyre: "games.clankcatacombs.names.lyre",
	imp: "games.clankcatacombs.names.imp",
	market: "games.clankcatacombs.names.market",
	pit: "games.clankcatacombs.names.pit",
	lake: "games.clankcatacombs.names.lake",
	tower: "games.clankcatacombs.names.tower",
	idol: "games.clankcatacombs.names.idol",
	chute: "games.clankcatacombs.names.chute",
	egg: "games.clankcatacombs.names.egg",
	pick: "games.clankcatacombs.names.pick",
	spring: "games.clankcatacombs.names.spring",
	heal1: "games.clankcatacombs.names.heal1",
	heal2: "games.clankcatacombs.names.heal2",
	boots: "games.clankcatacombs.names.boots",
	swords: "games.clankcatacombs.names.swords",
	puzzlebox: "games.clankcatacombs.names.puzzlebox",
	gold2: "games.clankcatacombs.names.gold2",
	gold5: "games.clankcatacombs.names.gold5",
	skill5: "games.clankcatacombs.names.skill5",
	map: "games.clankcatacombs.names.map",
	chalice: "games.clankcatacombs.names.chalice",
	"book-dead": "games.clankcatacombs.names.book-dead",
	"greater-hope": "games.clankcatacombs.names.greater-hope",
	silver4: "games.clankcatacombs.names.silver4",
	"dark-iron": "games.clankcatacombs.names.dark-iron",
	hope: "games.clankcatacombs.names.hope",
	stealth: "games.clankcatacombs.names.stealth",
	coupon: "games.clankcatacombs.names.coupon",
	"soul-elixir": "games.clankcatacombs.names.soul-elixir",
	barbarian: "games.clankcatacombs.names.barbarian",
	primatologist: "games.clankcatacombs.names.primatologist",
	sorceress: "games.clankcatacombs.names.sorceress",
	cleric: "games.clankcatacombs.names.cleric",
	haunted: "games.clankcatacombs.names.haunted",
	warrior: "games.clankcatacombs.names.warrior",
	prince: "games.clankcatacombs.names.prince",
	princess: "games.clankcatacombs.names.princess",
	monk: "games.clankcatacombs.names.monk",
	peasant: "games.clankcatacombs.names.peasant",
	mayor: "games.clankcatacombs.names.mayor",
	faithful: "games.clankcatacombs.names.faithful",
	myrmidon: "games.clankcatacombs.names.myrmidon",
	goblin: "games.clankcatacombs.names.goblin",
	transfigure: "games.clankcatacombs.names.transfigure",
	duplicate: "games.clankcatacombs.names.duplicate",
	levitate: "games.clankcatacombs.names.levitate",
	"fate-fool": "games.clankcatacombs.names.fate-fool",
	"fate-magician": "games.clankcatacombs.names.fate-magician",
	"fate-high-priestess": "games.clankcatacombs.names.fate-high-priestess",
	"fate-empress": "games.clankcatacombs.names.fate-empress",
	"fate-emperor": "games.clankcatacombs.names.fate-emperor",
	"fate-hierophant": "games.clankcatacombs.names.fate-hierophant",
	"fate-lovers": "games.clankcatacombs.names.fate-lovers",
	"fate-chariot": "games.clankcatacombs.names.fate-chariot",
	"fate-strength": "games.clankcatacombs.names.fate-strength",
	"fate-hermit": "games.clankcatacombs.names.fate-hermit",
	"fate-wheel": "games.clankcatacombs.names.fate-wheel",
	"fate-justice": "games.clankcatacombs.names.fate-justice",
	"fate-hanged-man": "games.clankcatacombs.names.fate-hanged-man",
	"fate-death": "games.clankcatacombs.names.fate-death",
	"fate-temperance": "games.clankcatacombs.names.fate-temperance",
	"fate-imp": "games.clankcatacombs.names.fate-imp",
	"fate-tower": "games.clankcatacombs.names.fate-tower",
	"fate-star": "games.clankcatacombs.names.fate-star",
	"fate-moon": "games.clankcatacombs.names.fate-moon",
	"fate-sun": "games.clankcatacombs.names.fate-sun",
	"fate-judgement": "games.clankcatacombs.names.fate-judgement",
	"fate-world": "games.clankcatacombs.names.fate-world",
	"option-skip": "games.clankcatacombs.names.option-skip",
	"option-teleport": "games.clankcatacombs.names.option-teleport",
	"option-swap": "games.clankcatacombs.names.option-swap",
	"option-quiet": "games.clankcatacombs.names.option-quiet",
	"option-loud": "games.clankcatacombs.names.option-loud",
	"option-gold": "games.clankcatacombs.names.option-gold",
	"option-caves": "games.clankcatacombs.names.option-caves",
	"option-pick": "games.clankcatacombs.names.option-pick",
	"option-steal": "games.clankcatacombs.names.option-steal",
	"option-draw": "games.clankcatacombs.names.option-draw",
	"option-trash": "games.clankcatacombs.names.option-trash",
	"option-discard": "games.clankcatacombs.names.option-discard",
	"option-trophy": "games.clankcatacombs.names.option-trophy",
	"option-boot": "games.clankcatacombs.names.option-boot",
	"option-boots": "games.clankcatacombs.names.option-boots",
	"option-heal": "games.clankcatacombs.names.option-heal",
	"option-minor": "games.clankcatacombs.names.option-minor",
	"option-market": "games.clankcatacombs.names.option-market",
	"option-top": "games.clankcatacombs.names.option-top",
	"option-replace": "games.clankcatacombs.names.option-replace",
	"option-mark": "games.clankcatacombs.names.option-mark",
	"option-return": "games.clankcatacombs.names.option-return",
	"option-artifact": "games.clankcatacombs.names.option-artifact",
	"option-rotate": "games.clankcatacombs.names.option-rotate",
	"option-place": "games.clankcatacombs.names.option-place",
	"option-fall": "games.clankcatacombs.names.option-fall",
	"option-fight": "games.clankcatacombs.names.option-fight",
	"option-damage": "games.clankcatacombs.names.option-damage",
	"option-fate": "games.clankcatacombs.names.option-fate",
	"option-reveal": "games.clankcatacombs.names.option-reveal",
	"option-aegis": "games.clankcatacombs.names.option-aegis",
	"option-acquire": "games.clankcatacombs.names.option-acquire",
	"option-skill": "games.clankcatacombs.names.option-skill",
	"option-swords": "games.clankcatacombs.names.option-swords",
	"option-copy": "games.clankcatacombs.names.option-copy",
	"option-silver": "games.clankcatacombs.names.option-silver",
	"option-tome": "games.clankcatacombs.names.option-tome",
	"option-egg": "games.clankcatacombs.names.option-egg",
	"option-idol": "games.clankcatacombs.names.option-idol",
	"option-crown": "games.clankcatacombs.names.option-crown",
	"free-prisoner": "games.clankcatacombs.names.free-prisoner"
}, tr = {
	"skeleton-priest": {
		name: "games.clankcatacombs.cards.skeleton-priest.name",
		text: "games.clankcatacombs.cards.skeleton-priest.text",
		acquire: "games.clankcatacombs.cards.skeleton-priest.acquire",
		arrive: "games.clankcatacombs.cards.skeleton-priest.arrive",
		react: "games.clankcatacombs.cards.skeleton-priest.react"
	},
	"darkened-alcove": {
		name: "games.clankcatacombs.cards.darkened-alcove.name",
		text: "games.clankcatacombs.cards.darkened-alcove.text",
		acquire: "games.clankcatacombs.cards.darkened-alcove.acquire",
		arrive: "games.clankcatacombs.cards.darkened-alcove.arrive",
		react: "games.clankcatacombs.cards.darkened-alcove.react"
	},
	"lie-in-wait": {
		name: "games.clankcatacombs.cards.lie-in-wait.name",
		text: "games.clankcatacombs.cards.lie-in-wait.text",
		acquire: "games.clankcatacombs.cards.lie-in-wait.acquire",
		arrive: "games.clankcatacombs.cards.lie-in-wait.arrive",
		react: "games.clankcatacombs.cards.lie-in-wait.react"
	},
	"smash-and-grab": {
		name: "games.clankcatacombs.cards.smash-and-grab.name",
		text: "games.clankcatacombs.cards.smash-and-grab.text",
		acquire: "games.clankcatacombs.cards.smash-and-grab.acquire",
		arrive: "games.clankcatacombs.cards.smash-and-grab.arrive",
		react: "games.clankcatacombs.cards.smash-and-grab.react"
	},
	bard: {
		name: "games.clankcatacombs.cards.bard.name",
		text: "games.clankcatacombs.cards.bard.text",
		acquire: "games.clankcatacombs.cards.bard.acquire",
		arrive: "games.clankcatacombs.cards.bard.arrive",
		react: "games.clankcatacombs.cards.bard.react"
	},
	"expert-guide": {
		name: "games.clankcatacombs.cards.expert-guide.name",
		text: "games.clankcatacombs.cards.expert-guide.text",
		acquire: "games.clankcatacombs.cards.expert-guide.acquire",
		arrive: "games.clankcatacombs.cards.expert-guide.arrive",
		react: "games.clankcatacombs.cards.expert-guide.react"
	},
	skeleton: {
		name: "games.clankcatacombs.cards.skeleton.name",
		text: "games.clankcatacombs.cards.skeleton.text",
		acquire: "games.clankcatacombs.cards.skeleton.acquire",
		arrive: "games.clankcatacombs.cards.skeleton.arrive",
		react: "games.clankcatacombs.cards.skeleton.react"
	},
	robbery: {
		name: "games.clankcatacombs.cards.robbery.name",
		text: "games.clankcatacombs.cards.robbery.text",
		acquire: "games.clankcatacombs.cards.robbery.acquire",
		arrive: "games.clankcatacombs.cards.robbery.arrive",
		react: "games.clankcatacombs.cards.robbery.react"
	},
	swindle: {
		name: "games.clankcatacombs.cards.swindle.name",
		text: "games.clankcatacombs.cards.swindle.text",
		acquire: "games.clankcatacombs.cards.swindle.acquire",
		arrive: "games.clankcatacombs.cards.swindle.arrive",
		react: "games.clankcatacombs.cards.swindle.react"
	},
	arcoverlord: {
		name: "games.clankcatacombs.cards.arcoverlord.name",
		text: "games.clankcatacombs.cards.arcoverlord.text",
		acquire: "games.clankcatacombs.cards.arcoverlord.acquire",
		arrive: "games.clankcatacombs.cards.arcoverlord.arrive",
		react: "games.clankcatacombs.cards.arcoverlord.react"
	},
	pillage: {
		name: "games.clankcatacombs.cards.pillage.name",
		text: "games.clankcatacombs.cards.pillage.text",
		acquire: "games.clankcatacombs.cards.pillage.acquire",
		arrive: "games.clankcatacombs.cards.pillage.arrive",
		react: "games.clankcatacombs.cards.pillage.react"
	},
	scavenger: {
		name: "games.clankcatacombs.cards.scavenger.name",
		text: "games.clankcatacombs.cards.scavenger.text",
		acquire: "games.clankcatacombs.cards.scavenger.acquire",
		arrive: "games.clankcatacombs.cards.scavenger.arrive",
		react: "games.clankcatacombs.cards.scavenger.react"
	},
	lightstick: {
		name: "games.clankcatacombs.cards.lightstick.name",
		text: "games.clankcatacombs.cards.lightstick.text",
		acquire: "games.clankcatacombs.cards.lightstick.acquire",
		arrive: "games.clankcatacombs.cards.lightstick.arrive",
		react: "games.clankcatacombs.cards.lightstick.react"
	},
	"sneak-attack": {
		name: "games.clankcatacombs.cards.sneak-attack.name",
		text: "games.clankcatacombs.cards.sneak-attack.text",
		acquire: "games.clankcatacombs.cards.sneak-attack.acquire",
		arrive: "games.clankcatacombs.cards.sneak-attack.arrive",
		react: "games.clankcatacombs.cards.sneak-attack.react"
	},
	"white-tourmaline": {
		name: "games.clankcatacombs.cards.white-tourmaline.name",
		text: "games.clankcatacombs.cards.white-tourmaline.text",
		acquire: "games.clankcatacombs.cards.white-tourmaline.acquire",
		arrive: "games.clankcatacombs.cards.white-tourmaline.arrive",
		react: "games.clankcatacombs.cards.white-tourmaline.react"
	},
	"black-tourmaline": {
		name: "games.clankcatacombs.cards.black-tourmaline.name",
		text: "games.clankcatacombs.cards.black-tourmaline.text",
		acquire: "games.clankcatacombs.cards.black-tourmaline.acquire",
		arrive: "games.clankcatacombs.cards.black-tourmaline.arrive",
		react: "games.clankcatacombs.cards.black-tourmaline.react"
	},
	flamboyance: {
		name: "games.clankcatacombs.cards.flamboyance.name",
		text: "games.clankcatacombs.cards.flamboyance.text",
		acquire: "games.clankcatacombs.cards.flamboyance.acquire",
		arrive: "games.clankcatacombs.cards.flamboyance.arrive",
		react: "games.clankcatacombs.cards.flamboyance.react"
	},
	"rebel-scribe": {
		name: "games.clankcatacombs.cards.rebel-scribe.name",
		text: "games.clankcatacombs.cards.rebel-scribe.text",
		acquire: "games.clankcatacombs.cards.rebel-scribe.acquire",
		arrive: "games.clankcatacombs.cards.rebel-scribe.arrive",
		react: "games.clankcatacombs.cards.rebel-scribe.react"
	},
	bandit: {
		name: "games.clankcatacombs.cards.bandit.name",
		text: "games.clankcatacombs.cards.bandit.text",
		acquire: "games.clankcatacombs.cards.bandit.acquire",
		arrive: "games.clankcatacombs.cards.bandit.arrive",
		react: "games.clankcatacombs.cards.bandit.react"
	},
	"underground-river": {
		name: "games.clankcatacombs.cards.underground-river.name",
		text: "games.clankcatacombs.cards.underground-river.text",
		acquire: "games.clankcatacombs.cards.underground-river.acquire",
		arrive: "games.clankcatacombs.cards.underground-river.arrive",
		react: "games.clankcatacombs.cards.underground-river.react"
	},
	"spectral-rider": {
		name: "games.clankcatacombs.cards.spectral-rider.name",
		text: "games.clankcatacombs.cards.spectral-rider.text",
		acquire: "games.clankcatacombs.cards.spectral-rider.acquire",
		arrive: "games.clankcatacombs.cards.spectral-rider.arrive",
		react: "games.clankcatacombs.cards.spectral-rider.react"
	},
	librarian: {
		name: "games.clankcatacombs.cards.librarian.name",
		text: "games.clankcatacombs.cards.librarian.text",
		acquire: "games.clankcatacombs.cards.librarian.acquire",
		arrive: "games.clankcatacombs.cards.librarian.arrive",
		react: "games.clankcatacombs.cards.librarian.react"
	},
	"rebel-general": {
		name: "games.clankcatacombs.cards.rebel-general.name",
		text: "games.clankcatacombs.cards.rebel-general.text",
		acquire: "games.clankcatacombs.cards.rebel-general.acquire",
		arrive: "games.clankcatacombs.cards.rebel-general.arrive",
		react: "games.clankcatacombs.cards.rebel-general.react"
	},
	"rebel-paladin": {
		name: "games.clankcatacombs.cards.rebel-paladin.name",
		text: "games.clankcatacombs.cards.rebel-paladin.text",
		acquire: "games.clankcatacombs.cards.rebel-paladin.acquire",
		arrive: "games.clankcatacombs.cards.rebel-paladin.arrive",
		react: "games.clankcatacombs.cards.rebel-paladin.react"
	},
	"rebel-thief": {
		name: "games.clankcatacombs.cards.rebel-thief.name",
		text: "games.clankcatacombs.cards.rebel-thief.text",
		acquire: "games.clankcatacombs.cards.rebel-thief.acquire",
		arrive: "games.clankcatacombs.cards.rebel-thief.arrive",
		react: "games.clankcatacombs.cards.rebel-thief.react"
	},
	"imp-familiar": {
		name: "games.clankcatacombs.cards.imp-familiar.name",
		text: "games.clankcatacombs.cards.imp-familiar.text",
		acquire: "games.clankcatacombs.cards.imp-familiar.acquire",
		arrive: "games.clankcatacombs.cards.imp-familiar.arrive",
		react: "games.clankcatacombs.cards.imp-familiar.react"
	},
	"floating-skull": {
		name: "games.clankcatacombs.cards.floating-skull.name",
		text: "games.clankcatacombs.cards.floating-skull.text",
		acquire: "games.clankcatacombs.cards.floating-skull.acquire",
		arrive: "games.clankcatacombs.cards.floating-skull.arrive",
		react: "games.clankcatacombs.cards.floating-skull.react"
	},
	charlatan: {
		name: "games.clankcatacombs.cards.charlatan.name",
		text: "games.clankcatacombs.cards.charlatan.text",
		acquire: "games.clankcatacombs.cards.charlatan.acquire",
		arrive: "games.clankcatacombs.cards.charlatan.arrive",
		react: "games.clankcatacombs.cards.charlatan.react"
	},
	empurror: {
		name: "games.clankcatacombs.cards.empurror.name",
		text: "games.clankcatacombs.cards.empurror.text",
		acquire: "games.clankcatacombs.cards.empurror.acquire",
		arrive: "games.clankcatacombs.cards.empurror.arrive",
		react: "games.clankcatacombs.cards.empurror.react"
	},
	curator: {
		name: "games.clankcatacombs.cards.curator.name",
		text: "games.clankcatacombs.cards.curator.text",
		acquire: "games.clankcatacombs.cards.curator.acquire",
		arrive: "games.clankcatacombs.cards.curator.arrive",
		react: "games.clankcatacombs.cards.curator.react"
	},
	"corrupt-advisor": {
		name: "games.clankcatacombs.cards.corrupt-advisor.name",
		text: "games.clankcatacombs.cards.corrupt-advisor.text",
		acquire: "games.clankcatacombs.cards.corrupt-advisor.acquire",
		arrive: "games.clankcatacombs.cards.corrupt-advisor.arrive",
		react: "games.clankcatacombs.cards.corrupt-advisor.react"
	},
	"rose-quartz": {
		name: "games.clankcatacombs.cards.rose-quartz.name",
		text: "games.clankcatacombs.cards.rose-quartz.text",
		acquire: "games.clankcatacombs.cards.rose-quartz.acquire",
		arrive: "games.clankcatacombs.cards.rose-quartz.arrive",
		react: "games.clankcatacombs.cards.rose-quartz.react"
	},
	"smoky-quartz": {
		name: "games.clankcatacombs.cards.smoky-quartz.name",
		text: "games.clankcatacombs.cards.smoky-quartz.text",
		acquire: "games.clankcatacombs.cards.smoky-quartz.acquire",
		arrive: "games.clankcatacombs.cards.smoky-quartz.arrive",
		react: "games.clankcatacombs.cards.smoky-quartz.react"
	},
	"fiery-quartz": {
		name: "games.clankcatacombs.cards.fiery-quartz.name",
		text: "games.clankcatacombs.cards.fiery-quartz.text",
		acquire: "games.clankcatacombs.cards.fiery-quartz.acquire",
		arrive: "games.clankcatacombs.cards.fiery-quartz.arrive",
		react: "games.clankcatacombs.cards.fiery-quartz.react"
	},
	waystone: {
		name: "games.clankcatacombs.cards.waystone.name",
		text: "games.clankcatacombs.cards.waystone.text",
		acquire: "games.clankcatacombs.cards.waystone.acquire",
		arrive: "games.clankcatacombs.cards.waystone.arrive",
		react: "games.clankcatacombs.cards.waystone.react"
	},
	"brave-hero": {
		name: "games.clankcatacombs.cards.brave-hero.name",
		text: "games.clankcatacombs.cards.brave-hero.text",
		acquire: "games.clankcatacombs.cards.brave-hero.acquire",
		arrive: "games.clankcatacombs.cards.brave-hero.arrive",
		react: "games.clankcatacombs.cards.brave-hero.react"
	},
	"remove-traps": {
		name: "games.clankcatacombs.cards.remove-traps.name",
		text: "games.clankcatacombs.cards.remove-traps.text",
		acquire: "games.clankcatacombs.cards.remove-traps.acquire",
		arrive: "games.clankcatacombs.cards.remove-traps.arrive",
		react: "games.clankcatacombs.cards.remove-traps.react"
	},
	"sudden-movement": {
		name: "games.clankcatacombs.cards.sudden-movement.name",
		text: "games.clankcatacombs.cards.sudden-movement.text",
		acquire: "games.clankcatacombs.cards.sudden-movement.acquire",
		arrive: "games.clankcatacombs.cards.sudden-movement.arrive",
		react: "games.clankcatacombs.cards.sudden-movement.react"
	},
	souldrinker: {
		name: "games.clankcatacombs.cards.souldrinker.name",
		text: "games.clankcatacombs.cards.souldrinker.text",
		acquire: "games.clankcatacombs.cards.souldrinker.acquire",
		arrive: "games.clankcatacombs.cards.souldrinker.arrive",
		react: "games.clankcatacombs.cards.souldrinker.react"
	},
	"shadow-walk": {
		name: "games.clankcatacombs.cards.shadow-walk.name",
		text: "games.clankcatacombs.cards.shadow-walk.text",
		acquire: "games.clankcatacombs.cards.shadow-walk.acquire",
		arrive: "games.clankcatacombs.cards.shadow-walk.arrive",
		react: "games.clankcatacombs.cards.shadow-walk.react"
	},
	"thirst-for-adventure": {
		name: "games.clankcatacombs.cards.thirst-for-adventure.name",
		text: "games.clankcatacombs.cards.thirst-for-adventure.text",
		acquire: "games.clankcatacombs.cards.thirst-for-adventure.acquire",
		arrive: "games.clankcatacombs.cards.thirst-for-adventure.arrive",
		react: "games.clankcatacombs.cards.thirst-for-adventure.react"
	},
	riot: {
		name: "games.clankcatacombs.cards.riot.name",
		text: "games.clankcatacombs.cards.riot.text",
		acquire: "games.clankcatacombs.cards.riot.acquire",
		arrive: "games.clankcatacombs.cards.riot.arrive",
		react: "games.clankcatacombs.cards.riot.react"
	},
	"astral-projection": {
		name: "games.clankcatacombs.cards.astral-projection.name",
		text: "games.clankcatacombs.cards.astral-projection.text",
		acquire: "games.clankcatacombs.cards.astral-projection.acquire",
		arrive: "games.clankcatacombs.cards.astral-projection.arrive",
		react: "games.clankcatacombs.cards.astral-projection.react"
	},
	diversion: {
		name: "games.clankcatacombs.cards.diversion.name",
		text: "games.clankcatacombs.cards.diversion.text",
		acquire: "games.clankcatacombs.cards.diversion.acquire",
		arrive: "games.clankcatacombs.cards.diversion.arrive",
		react: "games.clankcatacombs.cards.diversion.react"
	},
	"elven-sword": {
		name: "games.clankcatacombs.cards.elven-sword.name",
		text: "games.clankcatacombs.cards.elven-sword.text",
		acquire: "games.clankcatacombs.cards.elven-sword.acquire",
		arrive: "games.clankcatacombs.cards.elven-sword.arrive",
		react: "games.clankcatacombs.cards.elven-sword.react"
	},
	payoff: {
		name: "games.clankcatacombs.cards.payoff.name",
		text: "games.clankcatacombs.cards.payoff.text",
		acquire: "games.clankcatacombs.cards.payoff.acquire",
		arrive: "games.clankcatacombs.cards.payoff.arrive",
		react: "games.clankcatacombs.cards.payoff.react"
	},
	"double-cross": {
		name: "games.clankcatacombs.cards.double-cross.name",
		text: "games.clankcatacombs.cards.double-cross.text",
		acquire: "games.clankcatacombs.cards.double-cross.acquire",
		arrive: "games.clankcatacombs.cards.double-cross.arrive",
		react: "games.clankcatacombs.cards.double-cross.react"
	},
	"blink-spell": {
		name: "games.clankcatacombs.cards.blink-spell.name",
		text: "games.clankcatacombs.cards.blink-spell.text",
		acquire: "games.clankcatacombs.cards.blink-spell.acquire",
		arrive: "games.clankcatacombs.cards.blink-spell.arrive",
		react: "games.clankcatacombs.cards.blink-spell.react"
	},
	lute: {
		name: "games.clankcatacombs.cards.lute.name",
		text: "games.clankcatacombs.cards.lute.text",
		acquire: "games.clankcatacombs.cards.lute.acquire",
		arrive: "games.clankcatacombs.cards.lute.arrive",
		react: "games.clankcatacombs.cards.lute.react"
	},
	"divining-rod": {
		name: "games.clankcatacombs.cards.divining-rod.name",
		text: "games.clankcatacombs.cards.divining-rod.text",
		acquire: "games.clankcatacombs.cards.divining-rod.acquire",
		arrive: "games.clankcatacombs.cards.divining-rod.arrive",
		react: "games.clankcatacombs.cards.divining-rod.react"
	},
	"expensive-taste": {
		name: "games.clankcatacombs.cards.expensive-taste.name",
		text: "games.clankcatacombs.cards.expensive-taste.text",
		acquire: "games.clankcatacombs.cards.expensive-taste.acquire",
		arrive: "games.clankcatacombs.cards.expensive-taste.arrive",
		react: "games.clankcatacombs.cards.expensive-taste.react"
	},
	"golden-flute": {
		name: "games.clankcatacombs.cards.golden-flute.name",
		text: "games.clankcatacombs.cards.golden-flute.text",
		acquire: "games.clankcatacombs.cards.golden-flute.acquire",
		arrive: "games.clankcatacombs.cards.golden-flute.arrive",
		react: "games.clankcatacombs.cards.golden-flute.react"
	},
	"grand-theft": {
		name: "games.clankcatacombs.cards.grand-theft.name",
		text: "games.clankcatacombs.cards.grand-theft.text",
		acquire: "games.clankcatacombs.cards.grand-theft.acquire",
		arrive: "games.clankcatacombs.cards.grand-theft.arrive",
		react: "games.clankcatacombs.cards.grand-theft.react"
	},
	"boots-of-the-ape-lords": {
		name: "games.clankcatacombs.cards.boots-of-the-ape-lords.name",
		text: "games.clankcatacombs.cards.boots-of-the-ape-lords.text",
		acquire: "games.clankcatacombs.cards.boots-of-the-ape-lords.acquire",
		arrive: "games.clankcatacombs.cards.boots-of-the-ape-lords.arrive",
		react: "games.clankcatacombs.cards.boots-of-the-ape-lords.react"
	},
	"crystal-compass": {
		name: "games.clankcatacombs.cards.crystal-compass.name",
		text: "games.clankcatacombs.cards.crystal-compass.text",
		acquire: "games.clankcatacombs.cards.crystal-compass.acquire",
		arrive: "games.clankcatacombs.cards.crystal-compass.arrive",
		react: "games.clankcatacombs.cards.crystal-compass.react"
	},
	"animated-wall": {
		name: "games.clankcatacombs.cards.animated-wall.name",
		text: "games.clankcatacombs.cards.animated-wall.text",
		acquire: "games.clankcatacombs.cards.animated-wall.acquire",
		arrive: "games.clankcatacombs.cards.animated-wall.arrive",
		react: "games.clankcatacombs.cards.animated-wall.react"
	},
	"ogre-merchant": {
		name: "games.clankcatacombs.cards.ogre-merchant.name",
		text: "games.clankcatacombs.cards.ogre-merchant.text",
		acquire: "games.clankcatacombs.cards.ogre-merchant.acquire",
		arrive: "games.clankcatacombs.cards.ogre-merchant.arrive",
		react: "games.clankcatacombs.cards.ogre-merchant.react"
	},
	keymaster: {
		name: "games.clankcatacombs.cards.keymaster.name",
		text: "games.clankcatacombs.cards.keymaster.text",
		acquire: "games.clankcatacombs.cards.keymaster.acquire",
		arrive: "games.clankcatacombs.cards.keymaster.arrive",
		react: "games.clankcatacombs.cards.keymaster.react"
	},
	"thieves-shrine": {
		name: "games.clankcatacombs.cards.thieves-shrine.name",
		text: "games.clankcatacombs.cards.thieves-shrine.text",
		acquire: "games.clankcatacombs.cards.thieves-shrine.acquire",
		arrive: "games.clankcatacombs.cards.thieves-shrine.arrive",
		react: "games.clankcatacombs.cards.thieves-shrine.react"
	},
	"locked-trunk": {
		name: "games.clankcatacombs.cards.locked-trunk.name",
		text: "games.clankcatacombs.cards.locked-trunk.text",
		acquire: "games.clankcatacombs.cards.locked-trunk.acquire",
		arrive: "games.clankcatacombs.cards.locked-trunk.arrive",
		react: "games.clankcatacombs.cards.locked-trunk.react"
	},
	"wishing-well": {
		name: "games.clankcatacombs.cards.wishing-well.name",
		text: "games.clankcatacombs.cards.wishing-well.text",
		acquire: "games.clankcatacombs.cards.wishing-well.acquire",
		arrive: "games.clankcatacombs.cards.wishing-well.arrive",
		react: "games.clankcatacombs.cards.wishing-well.react"
	},
	"skeletal-ape": {
		name: "games.clankcatacombs.cards.skeletal-ape.name",
		text: "games.clankcatacombs.cards.skeletal-ape.text",
		acquire: "games.clankcatacombs.cards.skeletal-ape.acquire",
		arrive: "games.clankcatacombs.cards.skeletal-ape.arrive",
		react: "games.clankcatacombs.cards.skeletal-ape.react"
	},
	"the-warden": {
		name: "games.clankcatacombs.cards.the-warden.name",
		text: "games.clankcatacombs.cards.the-warden.text",
		acquire: "games.clankcatacombs.cards.the-warden.acquire",
		arrive: "games.clankcatacombs.cards.the-warden.arrive",
		react: "games.clankcatacombs.cards.the-warden.react"
	},
	"black-market": {
		name: "games.clankcatacombs.cards.black-market.name",
		text: "games.clankcatacombs.cards.black-market.text",
		acquire: "games.clankcatacombs.cards.black-market.acquire",
		arrive: "games.clankcatacombs.cards.black-market.arrive",
		react: "games.clankcatacombs.cards.black-market.react"
	},
	"crystal-kobold": {
		name: "games.clankcatacombs.cards.crystal-kobold.name",
		text: "games.clankcatacombs.cards.crystal-kobold.text",
		acquire: "games.clankcatacombs.cards.crystal-kobold.acquire",
		arrive: "games.clankcatacombs.cards.crystal-kobold.arrive",
		react: "games.clankcatacombs.cards.crystal-kobold.react"
	},
	"skeleton-warlock": {
		name: "games.clankcatacombs.cards.skeleton-warlock.name",
		text: "games.clankcatacombs.cards.skeleton-warlock.text",
		acquire: "games.clankcatacombs.cards.skeleton-warlock.acquire",
		arrive: "games.clankcatacombs.cards.skeleton-warlock.arrive",
		react: "games.clankcatacombs.cards.skeleton-warlock.react"
	},
	"marble-guardian": {
		name: "games.clankcatacombs.cards.marble-guardian.name",
		text: "games.clankcatacombs.cards.marble-guardian.text",
		acquire: "games.clankcatacombs.cards.marble-guardian.acquire",
		arrive: "games.clankcatacombs.cards.marble-guardian.arrive",
		react: "games.clankcatacombs.cards.marble-guardian.react"
	},
	skulker: {
		name: "games.clankcatacombs.cards.skulker.name",
		text: "games.clankcatacombs.cards.skulker.text",
		acquire: "games.clankcatacombs.cards.skulker.acquire",
		arrive: "games.clankcatacombs.cards.skulker.arrive",
		react: "games.clankcatacombs.cards.skulker.react"
	},
	scuffler: {
		name: "games.clankcatacombs.cards.scuffler.name",
		text: "games.clankcatacombs.cards.scuffler.text",
		acquire: "games.clankcatacombs.cards.scuffler.acquire",
		arrive: "games.clankcatacombs.cards.scuffler.arrive",
		react: "games.clankcatacombs.cards.scuffler.react"
	},
	"royal-brat": {
		name: "games.clankcatacombs.cards.royal-brat.name",
		text: "games.clankcatacombs.cards.royal-brat.text",
		acquire: "games.clankcatacombs.cards.royal-brat.acquire",
		arrive: "games.clankcatacombs.cards.royal-brat.arrive",
		react: "games.clankcatacombs.cards.royal-brat.react"
	},
	"elven-satchel": {
		name: "games.clankcatacombs.cards.elven-satchel.name",
		text: "games.clankcatacombs.cards.elven-satchel.text",
		acquire: "games.clankcatacombs.cards.elven-satchel.acquire",
		arrive: "games.clankcatacombs.cards.elven-satchel.arrive",
		react: "games.clankcatacombs.cards.elven-satchel.react"
	},
	"flawed-emerald": {
		name: "games.clankcatacombs.cards.flawed-emerald.name",
		text: "games.clankcatacombs.cards.flawed-emerald.text",
		acquire: "games.clankcatacombs.cards.flawed-emerald.acquire",
		arrive: "games.clankcatacombs.cards.flawed-emerald.arrive",
		react: "games.clankcatacombs.cards.flawed-emerald.react"
	},
	assassin: {
		name: "games.clankcatacombs.cards.assassin.name",
		text: "games.clankcatacombs.cards.assassin.text",
		acquire: "games.clankcatacombs.cards.assassin.acquire",
		arrive: "games.clankcatacombs.cards.assassin.arrive",
		react: "games.clankcatacombs.cards.assassin.react"
	},
	"spiritual-healer": {
		name: "games.clankcatacombs.cards.spiritual-healer.name",
		text: "games.clankcatacombs.cards.spiritual-healer.text",
		acquire: "games.clankcatacombs.cards.spiritual-healer.acquire",
		arrive: "games.clankcatacombs.cards.spiritual-healer.arrive",
		react: "games.clankcatacombs.cards.spiritual-healer.react"
	},
	"walk-it-off": {
		name: "games.clankcatacombs.cards.walk-it-off.name",
		text: "games.clankcatacombs.cards.walk-it-off.text",
		acquire: "games.clankcatacombs.cards.walk-it-off.acquire",
		arrive: "games.clankcatacombs.cards.walk-it-off.arrive",
		react: "games.clankcatacombs.cards.walk-it-off.react"
	},
	"flawed-sapphire": {
		name: "games.clankcatacombs.cards.flawed-sapphire.name",
		text: "games.clankcatacombs.cards.flawed-sapphire.text",
		acquire: "games.clankcatacombs.cards.flawed-sapphire.acquire",
		arrive: "games.clankcatacombs.cards.flawed-sapphire.arrive",
		react: "games.clankcatacombs.cards.flawed-sapphire.react"
	},
	berserker: {
		name: "games.clankcatacombs.cards.berserker.name",
		text: "games.clankcatacombs.cards.berserker.text",
		acquire: "games.clankcatacombs.cards.berserker.acquire",
		arrive: "games.clankcatacombs.cards.berserker.arrive",
		react: "games.clankcatacombs.cards.berserker.react"
	},
	"scouting-ahead": {
		name: "games.clankcatacombs.cards.scouting-ahead.name",
		text: "games.clankcatacombs.cards.scouting-ahead.text",
		acquire: "games.clankcatacombs.cards.scouting-ahead.acquire",
		arrive: "games.clankcatacombs.cards.scouting-ahead.arrive",
		react: "games.clankcatacombs.cards.scouting-ahead.react"
	},
	"one-with-everything": {
		name: "games.clankcatacombs.cards.one-with-everything.name",
		text: "games.clankcatacombs.cards.one-with-everything.text",
		acquire: "games.clankcatacombs.cards.one-with-everything.acquire",
		arrive: "games.clankcatacombs.cards.one-with-everything.arrive",
		react: "games.clankcatacombs.cards.one-with-everything.react"
	},
	"virtuoso-burglar": {
		name: "games.clankcatacombs.cards.virtuoso-burglar.name",
		text: "games.clankcatacombs.cards.virtuoso-burglar.text",
		acquire: "games.clankcatacombs.cards.virtuoso-burglar.acquire",
		arrive: "games.clankcatacombs.cards.virtuoso-burglar.arrive",
		react: "games.clankcatacombs.cards.virtuoso-burglar.react"
	},
	"hiding-place": {
		name: "games.clankcatacombs.cards.hiding-place.name",
		text: "games.clankcatacombs.cards.hiding-place.text",
		acquire: "games.clankcatacombs.cards.hiding-place.acquire",
		arrive: "games.clankcatacombs.cards.hiding-place.arrive",
		react: "games.clankcatacombs.cards.hiding-place.react"
	},
	"time-warp": {
		name: "games.clankcatacombs.cards.time-warp.name",
		text: "games.clankcatacombs.cards.time-warp.text",
		acquire: "games.clankcatacombs.cards.time-warp.acquire",
		arrive: "games.clankcatacombs.cards.time-warp.arrive",
		react: "games.clankcatacombs.cards.time-warp.react"
	},
	spotter: {
		name: "games.clankcatacombs.cards.spotter.name",
		text: "games.clankcatacombs.cards.spotter.text",
		acquire: "games.clankcatacombs.cards.spotter.acquire",
		arrive: "games.clankcatacombs.cards.spotter.arrive",
		react: "games.clankcatacombs.cards.spotter.react"
	},
	cutpurse: {
		name: "games.clankcatacombs.cards.cutpurse.name",
		text: "games.clankcatacombs.cards.cutpurse.text",
		acquire: "games.clankcatacombs.cards.cutpurse.acquire",
		arrive: "games.clankcatacombs.cards.cutpurse.arrive",
		react: "games.clankcatacombs.cards.cutpurse.react"
	},
	"secret-passage": {
		name: "games.clankcatacombs.cards.secret-passage.name",
		text: "games.clankcatacombs.cards.secret-passage.text",
		acquire: "games.clankcatacombs.cards.secret-passage.acquire",
		arrive: "games.clankcatacombs.cards.secret-passage.arrive",
		react: "games.clankcatacombs.cards.secret-passage.react"
	},
	tactician: {
		name: "games.clankcatacombs.cards.tactician.name",
		text: "games.clankcatacombs.cards.tactician.text",
		acquire: "games.clankcatacombs.cards.tactician.acquire",
		arrive: "games.clankcatacombs.cards.tactician.arrive",
		react: "games.clankcatacombs.cards.tactician.react"
	},
	"too-bad-for-you": {
		name: "games.clankcatacombs.cards.too-bad-for-you.name",
		text: "games.clankcatacombs.cards.too-bad-for-you.text",
		acquire: "games.clankcatacombs.cards.too-bad-for-you.acquire",
		arrive: "games.clankcatacombs.cards.too-bad-for-you.arrive",
		react: "games.clankcatacombs.cards.too-bad-for-you.react"
	},
	"flawed-ruby": {
		name: "games.clankcatacombs.cards.flawed-ruby.name",
		text: "games.clankcatacombs.cards.flawed-ruby.text",
		acquire: "games.clankcatacombs.cards.flawed-ruby.acquire",
		arrive: "games.clankcatacombs.cards.flawed-ruby.arrive",
		react: "games.clankcatacombs.cards.flawed-ruby.react"
	},
	"pixie-swarm": {
		name: "games.clankcatacombs.cards.pixie-swarm.name",
		text: "games.clankcatacombs.cards.pixie-swarm.text",
		acquire: "games.clankcatacombs.cards.pixie-swarm.acquire",
		arrive: "games.clankcatacombs.cards.pixie-swarm.arrive",
		react: "games.clankcatacombs.cards.pixie-swarm.react"
	},
	"ape-lord-phantasm": {
		name: "games.clankcatacombs.cards.ape-lord-phantasm.name",
		text: "games.clankcatacombs.cards.ape-lord-phantasm.text",
		acquire: "games.clankcatacombs.cards.ape-lord-phantasm.acquire",
		arrive: "games.clankcatacombs.cards.ape-lord-phantasm.arrive",
		react: "games.clankcatacombs.cards.ape-lord-phantasm.react"
	},
	"rebel-herald": {
		name: "games.clankcatacombs.cards.rebel-herald.name",
		text: "games.clankcatacombs.cards.rebel-herald.text",
		acquire: "games.clankcatacombs.cards.rebel-herald.acquire",
		arrive: "games.clankcatacombs.cards.rebel-herald.arrive",
		react: "games.clankcatacombs.cards.rebel-herald.react"
	},
	leprechaun: {
		name: "games.clankcatacombs.cards.leprechaun.name",
		text: "games.clankcatacombs.cards.leprechaun.text",
		acquire: "games.clankcatacombs.cards.leprechaun.acquire",
		arrive: "games.clankcatacombs.cards.leprechaun.arrive",
		react: "games.clankcatacombs.cards.leprechaun.react"
	},
	succubus: {
		name: "games.clankcatacombs.cards.succubus.name",
		text: "games.clankcatacombs.cards.succubus.text",
		acquire: "games.clankcatacombs.cards.succubus.acquire",
		arrive: "games.clankcatacombs.cards.succubus.arrive",
		react: "games.clankcatacombs.cards.succubus.react"
	},
	"magic-kazoo": {
		name: "games.clankcatacombs.cards.magic-kazoo.name",
		text: "games.clankcatacombs.cards.magic-kazoo.text",
		acquire: "games.clankcatacombs.cards.magic-kazoo.acquire",
		arrive: "games.clankcatacombs.cards.magic-kazoo.arrive",
		react: "games.clankcatacombs.cards.magic-kazoo.react"
	},
	"unlock-potential": {
		name: "games.clankcatacombs.cards.unlock-potential.name",
		text: "games.clankcatacombs.cards.unlock-potential.text",
		acquire: "games.clankcatacombs.cards.unlock-potential.acquire",
		arrive: "games.clankcatacombs.cards.unlock-potential.arrive",
		react: "games.clankcatacombs.cards.unlock-potential.react"
	},
	"thirst-for-knowledge": {
		name: "games.clankcatacombs.cards.thirst-for-knowledge.name",
		text: "games.clankcatacombs.cards.thirst-for-knowledge.text",
		acquire: "games.clankcatacombs.cards.thirst-for-knowledge.acquire",
		arrive: "games.clankcatacombs.cards.thirst-for-knowledge.arrive",
		react: "games.clankcatacombs.cards.thirst-for-knowledge.react"
	},
	"tome-of-fire": {
		name: "games.clankcatacombs.cards.tome-of-fire.name",
		text: "games.clankcatacombs.cards.tome-of-fire.text",
		acquire: "games.clankcatacombs.cards.tome-of-fire.acquire",
		arrive: "games.clankcatacombs.cards.tome-of-fire.arrive",
		react: "games.clankcatacombs.cards.tome-of-fire.react"
	},
	jailer: {
		name: "games.clankcatacombs.cards.jailer.name",
		text: "games.clankcatacombs.cards.jailer.text",
		acquire: "games.clankcatacombs.cards.jailer.acquire",
		arrive: "games.clankcatacombs.cards.jailer.arrive",
		react: "games.clankcatacombs.cards.jailer.react"
	},
	amethyst: {
		name: "games.clankcatacombs.cards.amethyst.name",
		text: "games.clankcatacombs.cards.amethyst.text",
		acquire: "games.clankcatacombs.cards.amethyst.acquire",
		arrive: "games.clankcatacombs.cards.amethyst.arrive",
		react: "games.clankcatacombs.cards.amethyst.react"
	},
	swashbuckling: {
		name: "games.clankcatacombs.cards.swashbuckling.name",
		text: "games.clankcatacombs.cards.swashbuckling.text",
		acquire: "games.clankcatacombs.cards.swashbuckling.acquire",
		arrive: "games.clankcatacombs.cards.swashbuckling.arrive",
		react: "games.clankcatacombs.cards.swashbuckling.react"
	},
	"loot-chute": {
		name: "games.clankcatacombs.cards.loot-chute.name",
		text: "games.clankcatacombs.cards.loot-chute.text",
		acquire: "games.clankcatacombs.cards.loot-chute.acquire",
		arrive: "games.clankcatacombs.cards.loot-chute.arrive",
		react: "games.clankcatacombs.cards.loot-chute.react"
	},
	"heart-of-the-dark": {
		name: "games.clankcatacombs.cards.heart-of-the-dark.name",
		text: "games.clankcatacombs.cards.heart-of-the-dark.text",
		acquire: "games.clankcatacombs.cards.heart-of-the-dark.acquire",
		arrive: "games.clankcatacombs.cards.heart-of-the-dark.arrive",
		react: "games.clankcatacombs.cards.heart-of-the-dark.react"
	},
	"cave-bat-wings": {
		name: "games.clankcatacombs.cards.cave-bat-wings.name",
		text: "games.clankcatacombs.cards.cave-bat-wings.text",
		acquire: "games.clankcatacombs.cards.cave-bat-wings.acquire",
		arrive: "games.clankcatacombs.cards.cave-bat-wings.arrive",
		react: "games.clankcatacombs.cards.cave-bat-wings.react"
	},
	jailbreaker: {
		name: "games.clankcatacombs.cards.jailbreaker.name",
		text: "games.clankcatacombs.cards.jailbreaker.text",
		acquire: "games.clankcatacombs.cards.jailbreaker.acquire",
		arrive: "games.clankcatacombs.cards.jailbreaker.arrive",
		react: "games.clankcatacombs.cards.jailbreaker.react"
	},
	"pack-rat": {
		name: "games.clankcatacombs.cards.pack-rat.name",
		text: "games.clankcatacombs.cards.pack-rat.text",
		acquire: "games.clankcatacombs.cards.pack-rat.acquire",
		arrive: "games.clankcatacombs.cards.pack-rat.arrive",
		react: "games.clankcatacombs.cards.pack-rat.react"
	},
	"false-bottom": {
		name: "games.clankcatacombs.cards.false-bottom.name",
		text: "games.clankcatacombs.cards.false-bottom.text",
		acquire: "games.clankcatacombs.cards.false-bottom.acquire",
		arrive: "games.clankcatacombs.cards.false-bottom.arrive",
		react: "games.clankcatacombs.cards.false-bottom.react"
	},
	acrobatics: {
		name: "games.clankcatacombs.cards.acrobatics.name",
		text: "games.clankcatacombs.cards.acrobatics.text",
		acquire: "games.clankcatacombs.cards.acrobatics.acquire",
		arrive: "games.clankcatacombs.cards.acrobatics.arrive",
		react: "games.clankcatacombs.cards.acrobatics.react"
	},
	"skeleton-troubadour": {
		name: "games.clankcatacombs.cards.skeleton-troubadour.name",
		text: "games.clankcatacombs.cards.skeleton-troubadour.text",
		acquire: "games.clankcatacombs.cards.skeleton-troubadour.acquire",
		arrive: "games.clankcatacombs.cards.skeleton-troubadour.arrive",
		react: "games.clankcatacombs.cards.skeleton-troubadour.react"
	},
	"pit-fiend": {
		name: "games.clankcatacombs.cards.pit-fiend.name",
		text: "games.clankcatacombs.cards.pit-fiend.text",
		acquire: "games.clankcatacombs.cards.pit-fiend.acquire",
		arrive: "games.clankcatacombs.cards.pit-fiend.arrive",
		react: "games.clankcatacombs.cards.pit-fiend.react"
	},
	"silver-arch": {
		name: "games.clankcatacombs.cards.silver-arch.name",
		text: "games.clankcatacombs.cards.silver-arch.text",
		acquire: "games.clankcatacombs.cards.silver-arch.acquire",
		arrive: "games.clankcatacombs.cards.silver-arch.arrive",
		react: "games.clankcatacombs.cards.silver-arch.react"
	},
	forage: {
		name: "games.clankcatacombs.cards.forage.name",
		text: "games.clankcatacombs.cards.forage.text",
		acquire: "games.clankcatacombs.cards.forage.acquire",
		arrive: "games.clankcatacombs.cards.forage.arrive",
		react: "games.clankcatacombs.cards.forage.react"
	},
	"swords-and-sorcery": {
		name: "games.clankcatacombs.cards.swords-and-sorcery.name",
		text: "games.clankcatacombs.cards.swords-and-sorcery.text",
		acquire: "games.clankcatacombs.cards.swords-and-sorcery.acquire",
		arrive: "games.clankcatacombs.cards.swords-and-sorcery.arrive",
		react: "games.clankcatacombs.cards.swords-and-sorcery.react"
	},
	alarm: {
		name: "games.clankcatacombs.cards.alarm.name",
		text: "games.clankcatacombs.cards.alarm.text",
		acquire: "games.clankcatacombs.cards.alarm.acquire",
		arrive: "games.clankcatacombs.cards.alarm.arrive",
		react: "games.clankcatacombs.cards.alarm.react"
	},
	"mechanical-donkey": {
		name: "games.clankcatacombs.cards.mechanical-donkey.name",
		text: "games.clankcatacombs.cards.mechanical-donkey.text",
		acquire: "games.clankcatacombs.cards.mechanical-donkey.acquire",
		arrive: "games.clankcatacombs.cards.mechanical-donkey.arrive",
		react: "games.clankcatacombs.cards.mechanical-donkey.react"
	},
	"artifact-detector": {
		name: "games.clankcatacombs.cards.artifact-detector.name",
		text: "games.clankcatacombs.cards.artifact-detector.text",
		acquire: "games.clankcatacombs.cards.artifact-detector.acquire",
		arrive: "games.clankcatacombs.cards.artifact-detector.arrive",
		react: "games.clankcatacombs.cards.artifact-detector.react"
	},
	spelunker: {
		name: "games.clankcatacombs.cards.spelunker.name",
		text: "games.clankcatacombs.cards.spelunker.text",
		acquire: "games.clankcatacombs.cards.spelunker.acquire",
		arrive: "games.clankcatacombs.cards.spelunker.arrive",
		react: "games.clankcatacombs.cards.spelunker.react"
	},
	negotiator: {
		name: "games.clankcatacombs.cards.negotiator.name",
		text: "games.clankcatacombs.cards.negotiator.text",
		acquire: "games.clankcatacombs.cards.negotiator.acquire",
		arrive: "games.clankcatacombs.cards.negotiator.arrive",
		react: "games.clankcatacombs.cards.negotiator.react"
	},
	devotion: {
		name: "games.clankcatacombs.cards.devotion.name",
		text: "games.clankcatacombs.cards.devotion.text",
		acquire: "games.clankcatacombs.cards.devotion.acquire",
		arrive: "games.clankcatacombs.cards.devotion.arrive",
		react: "games.clankcatacombs.cards.devotion.react"
	},
	"rebel-messenger": {
		name: "games.clankcatacombs.cards.rebel-messenger.name",
		text: "games.clankcatacombs.cards.rebel-messenger.text",
		acquire: "games.clankcatacombs.cards.rebel-messenger.acquire",
		arrive: "games.clankcatacombs.cards.rebel-messenger.arrive",
		react: "games.clankcatacombs.cards.rebel-messenger.react"
	},
	"swap-meet": {
		name: "games.clankcatacombs.cards.swap-meet.name",
		text: "games.clankcatacombs.cards.swap-meet.text",
		acquire: "games.clankcatacombs.cards.swap-meet.acquire",
		arrive: "games.clankcatacombs.cards.swap-meet.arrive",
		react: "games.clankcatacombs.cards.swap-meet.react"
	},
	"cavern-prowler": {
		name: "games.clankcatacombs.cards.cavern-prowler.name",
		text: "games.clankcatacombs.cards.cavern-prowler.text",
		acquire: "games.clankcatacombs.cards.cavern-prowler.acquire",
		arrive: "games.clankcatacombs.cards.cavern-prowler.arrive",
		react: "games.clankcatacombs.cards.cavern-prowler.react"
	},
	"venomous-lurker": {
		name: "games.clankcatacombs.cards.venomous-lurker.name",
		text: "games.clankcatacombs.cards.venomous-lurker.text",
		acquire: "games.clankcatacombs.cards.venomous-lurker.acquire",
		arrive: "games.clankcatacombs.cards.venomous-lurker.arrive",
		react: "games.clankcatacombs.cards.venomous-lurker.react"
	},
	"ape-lord-epaulets": {
		name: "games.clankcatacombs.cards.ape-lord-epaulets.name",
		text: "games.clankcatacombs.cards.ape-lord-epaulets.text",
		acquire: "games.clankcatacombs.cards.ape-lord-epaulets.acquire",
		arrive: "games.clankcatacombs.cards.ape-lord-epaulets.arrive",
		react: "games.clankcatacombs.cards.ape-lord-epaulets.react"
	},
	"golden-hourglass": {
		name: "games.clankcatacombs.cards.golden-hourglass.name",
		text: "games.clankcatacombs.cards.golden-hourglass.text",
		acquire: "games.clankcatacombs.cards.golden-hourglass.acquire",
		arrive: "games.clankcatacombs.cards.golden-hourglass.arrive",
		react: "games.clankcatacombs.cards.golden-hourglass.react"
	},
	"quick-pick": {
		name: "games.clankcatacombs.cards.quick-pick.name",
		text: "games.clankcatacombs.cards.quick-pick.text",
		acquire: "games.clankcatacombs.cards.quick-pick.acquire",
		arrive: "games.clankcatacombs.cards.quick-pick.arrive",
		react: "games.clankcatacombs.cards.quick-pick.react"
	},
	"merchants-guild-pin": {
		name: "games.clankcatacombs.cards.merchants-guild-pin.name",
		text: "games.clankcatacombs.cards.merchants-guild-pin.text",
		acquire: "games.clankcatacombs.cards.merchants-guild-pin.acquire",
		arrive: "games.clankcatacombs.cards.merchants-guild-pin.arrive",
		react: "games.clankcatacombs.cards.merchants-guild-pin.react"
	},
	"monkey-paw": {
		name: "games.clankcatacombs.cards.monkey-paw.name",
		text: "games.clankcatacombs.cards.monkey-paw.text",
		acquire: "games.clankcatacombs.cards.monkey-paw.acquire",
		arrive: "games.clankcatacombs.cards.monkey-paw.arrive",
		react: "games.clankcatacombs.cards.monkey-paw.react"
	},
	"skeleton-herald": {
		name: "games.clankcatacombs.cards.skeleton-herald.name",
		text: "games.clankcatacombs.cards.skeleton-herald.text",
		acquire: "games.clankcatacombs.cards.skeleton-herald.acquire",
		arrive: "games.clankcatacombs.cards.skeleton-herald.arrive",
		react: "games.clankcatacombs.cards.skeleton-herald.react"
	},
	"hoard-keeper": {
		name: "games.clankcatacombs.cards.hoard-keeper.name",
		text: "games.clankcatacombs.cards.hoard-keeper.text",
		acquire: "games.clankcatacombs.cards.hoard-keeper.acquire",
		arrive: "games.clankcatacombs.cards.hoard-keeper.arrive",
		react: "games.clankcatacombs.cards.hoard-keeper.react"
	},
	"rebel-guard": {
		name: "games.clankcatacombs.cards.rebel-guard.name",
		text: "games.clankcatacombs.cards.rebel-guard.text",
		acquire: "games.clankcatacombs.cards.rebel-guard.acquire",
		arrive: "games.clankcatacombs.cards.rebel-guard.arrive",
		react: "games.clankcatacombs.cards.rebel-guard.react"
	},
	"evil-wizard": {
		name: "games.clankcatacombs.cards.evil-wizard.name",
		text: "games.clankcatacombs.cards.evil-wizard.text",
		acquire: "games.clankcatacombs.cards.evil-wizard.acquire",
		arrive: "games.clankcatacombs.cards.evil-wizard.arrive",
		react: "games.clankcatacombs.cards.evil-wizard.react"
	},
	candelabra: {
		name: "games.clankcatacombs.cards.candelabra.name",
		text: "games.clankcatacombs.cards.candelabra.text",
		acquire: "games.clankcatacombs.cards.candelabra.acquire",
		arrive: "games.clankcatacombs.cards.candelabra.arrive",
		react: "games.clankcatacombs.cards.candelabra.react"
	},
	"ten-foot-pole": {
		name: "games.clankcatacombs.cards.ten-foot-pole.name",
		text: "games.clankcatacombs.cards.ten-foot-pole.text",
		acquire: "games.clankcatacombs.cards.ten-foot-pole.acquire",
		arrive: "games.clankcatacombs.cards.ten-foot-pole.arrive",
		react: "games.clankcatacombs.cards.ten-foot-pole.react"
	},
	tinkerer: {
		name: "games.clankcatacombs.cards.tinkerer.name",
		text: "games.clankcatacombs.cards.tinkerer.text",
		acquire: "games.clankcatacombs.cards.tinkerer.acquire",
		arrive: "games.clankcatacombs.cards.tinkerer.arrive",
		react: "games.clankcatacombs.cards.tinkerer.react"
	},
	"underworld-guide": {
		name: "games.clankcatacombs.cards.underworld-guide.name",
		text: "games.clankcatacombs.cards.underworld-guide.text",
		acquire: "games.clankcatacombs.cards.underworld-guide.acquire",
		arrive: "games.clankcatacombs.cards.underworld-guide.arrive",
		react: "games.clankcatacombs.cards.underworld-guide.react"
	},
	"moneychangers-booth": {
		name: "games.clankcatacombs.cards.moneychangers-booth.name",
		text: "games.clankcatacombs.cards.moneychangers-booth.text",
		acquire: "games.clankcatacombs.cards.moneychangers-booth.acquire",
		arrive: "games.clankcatacombs.cards.moneychangers-booth.arrive",
		react: "games.clankcatacombs.cards.moneychangers-booth.react"
	},
	catapult: {
		name: "games.clankcatacombs.cards.catapult.name",
		text: "games.clankcatacombs.cards.catapult.text",
		acquire: "games.clankcatacombs.cards.catapult.acquire",
		arrive: "games.clankcatacombs.cards.catapult.arrive",
		react: "games.clankcatacombs.cards.catapult.react"
	},
	"underground-spring": {
		name: "games.clankcatacombs.cards.underground-spring.name",
		text: "games.clankcatacombs.cards.underground-spring.text",
		acquire: "games.clankcatacombs.cards.underground-spring.acquire",
		arrive: "games.clankcatacombs.cards.underground-spring.arrive",
		react: "games.clankcatacombs.cards.underground-spring.react"
	},
	"mystic-elevator": {
		name: "games.clankcatacombs.cards.mystic-elevator.name",
		text: "games.clankcatacombs.cards.mystic-elevator.text",
		acquire: "games.clankcatacombs.cards.mystic-elevator.acquire",
		arrive: "games.clankcatacombs.cards.mystic-elevator.arrive",
		react: "games.clankcatacombs.cards.mystic-elevator.react"
	},
	"shifting-shadow": {
		name: "games.clankcatacombs.cards.shifting-shadow.name",
		text: "games.clankcatacombs.cards.shifting-shadow.text",
		acquire: "games.clankcatacombs.cards.shifting-shadow.acquire",
		arrive: "games.clankcatacombs.cards.shifting-shadow.arrive",
		react: "games.clankcatacombs.cards.shifting-shadow.react"
	},
	"harpy-matriarch": {
		name: "games.clankcatacombs.cards.harpy-matriarch.name",
		text: "games.clankcatacombs.cards.harpy-matriarch.text",
		acquire: "games.clankcatacombs.cards.harpy-matriarch.acquire",
		arrive: "games.clankcatacombs.cards.harpy-matriarch.arrive",
		react: "games.clankcatacombs.cards.harpy-matriarch.react"
	},
	chimera: {
		name: "games.clankcatacombs.cards.chimera.name",
		text: "games.clankcatacombs.cards.chimera.text",
		acquire: "games.clankcatacombs.cards.chimera.acquire",
		arrive: "games.clankcatacombs.cards.chimera.arrive",
		react: "games.clankcatacombs.cards.chimera.react"
	},
	cyclops: {
		name: "games.clankcatacombs.cards.cyclops.name",
		text: "games.clankcatacombs.cards.cyclops.text",
		acquire: "games.clankcatacombs.cards.cyclops.acquire",
		arrive: "games.clankcatacombs.cards.cyclops.arrive",
		react: "games.clankcatacombs.cards.cyclops.react"
	},
	"wild-boar": {
		name: "games.clankcatacombs.cards.wild-boar.name",
		text: "games.clankcatacombs.cards.wild-boar.text",
		acquire: "games.clankcatacombs.cards.wild-boar.acquire",
		arrive: "games.clankcatacombs.cards.wild-boar.arrive",
		react: "games.clankcatacombs.cards.wild-boar.react"
	},
	"abyssal-hydra": {
		name: "games.clankcatacombs.cards.abyssal-hydra.name",
		text: "games.clankcatacombs.cards.abyssal-hydra.text",
		acquire: "games.clankcatacombs.cards.abyssal-hydra.acquire",
		arrive: "games.clankcatacombs.cards.abyssal-hydra.arrive",
		react: "games.clankcatacombs.cards.abyssal-hydra.react"
	},
	"grave-robber": {
		name: "games.clankcatacombs.cards.grave-robber.name",
		text: "games.clankcatacombs.cards.grave-robber.text",
		acquire: "games.clankcatacombs.cards.grave-robber.acquire",
		arrive: "games.clankcatacombs.cards.grave-robber.arrive",
		react: "games.clankcatacombs.cards.grave-robber.react"
	},
	"gray-knight": {
		name: "games.clankcatacombs.cards.gray-knight.name",
		text: "games.clankcatacombs.cards.gray-knight.text",
		acquire: "games.clankcatacombs.cards.gray-knight.acquire",
		arrive: "games.clankcatacombs.cards.gray-knight.arrive",
		react: "games.clankcatacombs.cards.gray-knight.react"
	},
	"underworld-dealer": {
		name: "games.clankcatacombs.cards.underworld-dealer.name",
		text: "games.clankcatacombs.cards.underworld-dealer.text",
		acquire: "games.clankcatacombs.cards.underworld-dealer.acquire",
		arrive: "games.clankcatacombs.cards.underworld-dealer.arrive",
		react: "games.clankcatacombs.cards.underworld-dealer.react"
	},
	george: {
		name: "games.clankcatacombs.cards.george.name",
		text: "games.clankcatacombs.cards.george.text",
		acquire: "games.clankcatacombs.cards.george.acquire",
		arrive: "games.clankcatacombs.cards.george.arrive",
		react: "games.clankcatacombs.cards.george.react"
	},
	sculptor: {
		name: "games.clankcatacombs.cards.sculptor.name",
		text: "games.clankcatacombs.cards.sculptor.text",
		acquire: "games.clankcatacombs.cards.sculptor.acquire",
		arrive: "games.clankcatacombs.cards.sculptor.arrive",
		react: "games.clankcatacombs.cards.sculptor.react"
	},
	soothsayer: {
		name: "games.clankcatacombs.cards.soothsayer.name",
		text: "games.clankcatacombs.cards.soothsayer.text",
		acquire: "games.clankcatacombs.cards.soothsayer.acquire",
		arrive: "games.clankcatacombs.cards.soothsayer.arrive",
		react: "games.clankcatacombs.cards.soothsayer.react"
	},
	orpheus: {
		name: "games.clankcatacombs.cards.orpheus.name",
		text: "games.clankcatacombs.cards.orpheus.text",
		acquire: "games.clankcatacombs.cards.orpheus.acquire",
		arrive: "games.clankcatacombs.cards.orpheus.arrive",
		react: "games.clankcatacombs.cards.orpheus.react"
	},
	"hero-of-prophecy": {
		name: "games.clankcatacombs.cards.hero-of-prophecy.name",
		text: "games.clankcatacombs.cards.hero-of-prophecy.text",
		acquire: "games.clankcatacombs.cards.hero-of-prophecy.acquire",
		arrive: "games.clankcatacombs.cards.hero-of-prophecy.arrive",
		react: "games.clankcatacombs.cards.hero-of-prophecy.react"
	},
	oracle: {
		name: "games.clankcatacombs.cards.oracle.name",
		text: "games.clankcatacombs.cards.oracle.text",
		acquire: "games.clankcatacombs.cards.oracle.acquire",
		arrive: "games.clankcatacombs.cards.oracle.arrive",
		react: "games.clankcatacombs.cards.oracle.react"
	},
	"rebel-tunnel-guide": {
		name: "games.clankcatacombs.cards.rebel-tunnel-guide.name",
		text: "games.clankcatacombs.cards.rebel-tunnel-guide.text",
		acquire: "games.clankcatacombs.cards.rebel-tunnel-guide.acquire",
		arrive: "games.clankcatacombs.cards.rebel-tunnel-guide.arrive",
		react: "games.clankcatacombs.cards.rebel-tunnel-guide.react"
	},
	"rebel-rouser": {
		name: "games.clankcatacombs.cards.rebel-rouser.name",
		text: "games.clankcatacombs.cards.rebel-rouser.text",
		acquire: "games.clankcatacombs.cards.rebel-rouser.acquire",
		arrive: "games.clankcatacombs.cards.rebel-rouser.arrive",
		react: "games.clankcatacombs.cards.rebel-rouser.react"
	},
	"spellblade-invoker": {
		name: "games.clankcatacombs.cards.spellblade-invoker.name",
		text: "games.clankcatacombs.cards.spellblade-invoker.text",
		acquire: "games.clankcatacombs.cards.spellblade-invoker.acquire",
		arrive: "games.clankcatacombs.cards.spellblade-invoker.arrive",
		react: "games.clankcatacombs.cards.spellblade-invoker.react"
	},
	"apprentice-thief": {
		name: "games.clankcatacombs.cards.apprentice-thief.name",
		text: "games.clankcatacombs.cards.apprentice-thief.text",
		acquire: "games.clankcatacombs.cards.apprentice-thief.acquire",
		arrive: "games.clankcatacombs.cards.apprentice-thief.arrive",
		react: "games.clankcatacombs.cards.apprentice-thief.react"
	},
	"polished-garnet": {
		name: "games.clankcatacombs.cards.polished-garnet.name",
		text: "games.clankcatacombs.cards.polished-garnet.text",
		acquire: "games.clankcatacombs.cards.polished-garnet.acquire",
		arrive: "games.clankcatacombs.cards.polished-garnet.arrive",
		react: "games.clankcatacombs.cards.polished-garnet.react"
	},
	garnet: {
		name: "games.clankcatacombs.cards.garnet.name",
		text: "games.clankcatacombs.cards.garnet.text",
		acquire: "games.clankcatacombs.cards.garnet.acquire",
		arrive: "games.clankcatacombs.cards.garnet.arrive",
		react: "games.clankcatacombs.cards.garnet.react"
	},
	"fire-breath": {
		name: "games.clankcatacombs.cards.fire-breath.name",
		text: "games.clankcatacombs.cards.fire-breath.text",
		acquire: "games.clankcatacombs.cards.fire-breath.acquire",
		arrive: "games.clankcatacombs.cards.fire-breath.arrive",
		react: "games.clankcatacombs.cards.fire-breath.react"
	},
	"escape-plan": {
		name: "games.clankcatacombs.cards.escape-plan.name",
		text: "games.clankcatacombs.cards.escape-plan.text",
		acquire: "games.clankcatacombs.cards.escape-plan.acquire",
		arrive: "games.clankcatacombs.cards.escape-plan.arrive",
		react: "games.clankcatacombs.cards.escape-plan.react"
	},
	"tome-of-intellect": {
		name: "games.clankcatacombs.cards.tome-of-intellect.name",
		text: "games.clankcatacombs.cards.tome-of-intellect.text",
		acquire: "games.clankcatacombs.cards.tome-of-intellect.acquire",
		arrive: "games.clankcatacombs.cards.tome-of-intellect.arrive",
		react: "games.clankcatacombs.cards.tome-of-intellect.react"
	},
	"tome-of-the-ape-lords": {
		name: "games.clankcatacombs.cards.tome-of-the-ape-lords.name",
		text: "games.clankcatacombs.cards.tome-of-the-ape-lords.text",
		acquire: "games.clankcatacombs.cards.tome-of-the-ape-lords.acquire",
		arrive: "games.clankcatacombs.cards.tome-of-the-ape-lords.arrive",
		react: "games.clankcatacombs.cards.tome-of-the-ape-lords.react"
	},
	"soul-prism": {
		name: "games.clankcatacombs.cards.soul-prism.name",
		text: "games.clankcatacombs.cards.soul-prism.text",
		acquire: "games.clankcatacombs.cards.soul-prism.acquire",
		arrive: "games.clankcatacombs.cards.soul-prism.arrive",
		react: "games.clankcatacombs.cards.soul-prism.react"
	},
	"ethereal-step": {
		name: "games.clankcatacombs.cards.ethereal-step.name",
		text: "games.clankcatacombs.cards.ethereal-step.text",
		acquire: "games.clankcatacombs.cards.ethereal-step.acquire",
		arrive: "games.clankcatacombs.cards.ethereal-step.arrive",
		react: "games.clankcatacombs.cards.ethereal-step.react"
	},
	thunderstriker: {
		name: "games.clankcatacombs.cards.thunderstriker.name",
		text: "games.clankcatacombs.cards.thunderstriker.text",
		acquire: "games.clankcatacombs.cards.thunderstriker.acquire",
		arrive: "games.clankcatacombs.cards.thunderstriker.arrive",
		react: "games.clankcatacombs.cards.thunderstriker.react"
	},
	slink: {
		name: "games.clankcatacombs.cards.slink.name",
		text: "games.clankcatacombs.cards.slink.text",
		acquire: "games.clankcatacombs.cards.slink.acquire",
		arrive: "games.clankcatacombs.cards.slink.arrive",
		react: "games.clankcatacombs.cards.slink.react"
	},
	"acid-splash": {
		name: "games.clankcatacombs.cards.acid-splash.name",
		text: "games.clankcatacombs.cards.acid-splash.text",
		acquire: "games.clankcatacombs.cards.acid-splash.acquire",
		arrive: "games.clankcatacombs.cards.acid-splash.arrive",
		react: "games.clankcatacombs.cards.acid-splash.react"
	},
	"quick-trip": {
		name: "games.clankcatacombs.cards.quick-trip.name",
		text: "games.clankcatacombs.cards.quick-trip.text",
		acquire: "games.clankcatacombs.cards.quick-trip.acquire",
		arrive: "games.clankcatacombs.cards.quick-trip.arrive",
		react: "games.clankcatacombs.cards.quick-trip.react"
	},
	"burial-urn": {
		name: "games.clankcatacombs.cards.burial-urn.name",
		text: "games.clankcatacombs.cards.burial-urn.text",
		acquire: "games.clankcatacombs.cards.burial-urn.acquire",
		arrive: "games.clankcatacombs.cards.burial-urn.arrive",
		react: "games.clankcatacombs.cards.burial-urn.react"
	},
	"wealth-of-knowledge": {
		name: "games.clankcatacombs.cards.wealth-of-knowledge.name",
		text: "games.clankcatacombs.cards.wealth-of-knowledge.text",
		acquire: "games.clankcatacombs.cards.wealth-of-knowledge.acquire",
		arrive: "games.clankcatacombs.cards.wealth-of-knowledge.arrive",
		react: "games.clankcatacombs.cards.wealth-of-knowledge.react"
	},
	lantern: {
		name: "games.clankcatacombs.cards.lantern.name",
		text: "games.clankcatacombs.cards.lantern.text",
		acquire: "games.clankcatacombs.cards.lantern.acquire",
		arrive: "games.clankcatacombs.cards.lantern.arrive",
		react: "games.clankcatacombs.cards.lantern.react"
	},
	"utility-knife": {
		name: "games.clankcatacombs.cards.utility-knife.name",
		text: "games.clankcatacombs.cards.utility-knife.text",
		acquire: "games.clankcatacombs.cards.utility-knife.acquire",
		arrive: "games.clankcatacombs.cards.utility-knife.arrive",
		react: "games.clankcatacombs.cards.utility-knife.react"
	},
	"big-ideas": {
		name: "games.clankcatacombs.cards.big-ideas.name",
		text: "games.clankcatacombs.cards.big-ideas.text",
		acquire: "games.clankcatacombs.cards.big-ideas.acquire",
		arrive: "games.clankcatacombs.cards.big-ideas.arrive",
		react: "games.clankcatacombs.cards.big-ideas.react"
	},
	burgle: {
		name: "games.clankcatacombs.cards.burgle.name",
		text: "games.clankcatacombs.cards.burgle.text",
		acquire: "games.clankcatacombs.cards.burgle.acquire",
		arrive: "games.clankcatacombs.cards.burgle.arrive",
		react: "games.clankcatacombs.cards.burgle.react"
	},
	stumble: {
		name: "games.clankcatacombs.cards.stumble.name",
		text: "games.clankcatacombs.cards.stumble.text",
		acquire: "games.clankcatacombs.cards.stumble.acquire",
		arrive: "games.clankcatacombs.cards.stumble.arrive",
		react: "games.clankcatacombs.cards.stumble.react"
	},
	sidestep: {
		name: "games.clankcatacombs.cards.sidestep.name",
		text: "games.clankcatacombs.cards.sidestep.text",
		acquire: "games.clankcatacombs.cards.sidestep.acquire",
		arrive: "games.clankcatacombs.cards.sidestep.arrive",
		react: "games.clankcatacombs.cards.sidestep.react"
	},
	scramble: {
		name: "games.clankcatacombs.cards.scramble.name",
		text: "games.clankcatacombs.cards.scramble.text",
		acquire: "games.clankcatacombs.cards.scramble.acquire",
		arrive: "games.clankcatacombs.cards.scramble.arrive",
		react: "games.clankcatacombs.cards.scramble.react"
	},
	explore: {
		name: "games.clankcatacombs.cards.explore.name",
		text: "games.clankcatacombs.cards.explore.text",
		acquire: "games.clankcatacombs.cards.explore.acquire",
		arrive: "games.clankcatacombs.cards.explore.arrive",
		react: "games.clankcatacombs.cards.explore.react"
	},
	mercenary: {
		name: "games.clankcatacombs.cards.mercenary.name",
		text: "games.clankcatacombs.cards.mercenary.text",
		acquire: "games.clankcatacombs.cards.mercenary.acquire",
		arrive: "games.clankcatacombs.cards.mercenary.arrive",
		react: "games.clankcatacombs.cards.mercenary.react"
	},
	tome: {
		name: "games.clankcatacombs.cards.tome.name",
		text: "games.clankcatacombs.cards.tome.text",
		acquire: "games.clankcatacombs.cards.tome.acquire",
		arrive: "games.clankcatacombs.cards.tome.arrive",
		react: "games.clankcatacombs.cards.tome.react"
	},
	psyfoot: {
		name: "games.clankcatacombs.cards.psyfoot.name",
		text: "games.clankcatacombs.cards.psyfoot.text",
		acquire: "games.clankcatacombs.cards.psyfoot.acquire",
		arrive: "games.clankcatacombs.cards.psyfoot.arrive",
		react: "games.clankcatacombs.cards.psyfoot.react"
	},
	cattitude: {
		name: "games.clankcatacombs.cards.cattitude.name",
		text: "games.clankcatacombs.cards.cattitude.text",
		acquire: "games.clankcatacombs.cards.cattitude.acquire",
		arrive: "games.clankcatacombs.cards.cattitude.arrive",
		react: "games.clankcatacombs.cards.cattitude.react"
	},
	saunter: {
		name: "games.clankcatacombs.cards.saunter.name",
		text: "games.clankcatacombs.cards.saunter.text",
		acquire: "games.clankcatacombs.cards.saunter.acquire",
		arrive: "games.clankcatacombs.cards.saunter.arrive",
		react: "games.clankcatacombs.cards.saunter.react"
	},
	ransack: {
		name: "games.clankcatacombs.cards.ransack.name",
		text: "games.clankcatacombs.cards.ransack.text",
		acquire: "games.clankcatacombs.cards.ransack.acquire",
		arrive: "games.clankcatacombs.cards.ransack.arrive",
		react: "games.clankcatacombs.cards.ransack.react"
	},
	scavenge: {
		name: "games.clankcatacombs.cards.scavenge.name",
		text: "games.clankcatacombs.cards.scavenge.text",
		acquire: "games.clankcatacombs.cards.scavenge.acquire",
		arrive: "games.clankcatacombs.cards.scavenge.arrive",
		react: "games.clankcatacombs.cards.scavenge.react"
	},
	wallop: {
		name: "games.clankcatacombs.cards.wallop.name",
		text: "games.clankcatacombs.cards.wallop.text",
		acquire: "games.clankcatacombs.cards.wallop.acquire",
		arrive: "games.clankcatacombs.cards.wallop.arrive",
		react: "games.clankcatacombs.cards.wallop.react"
	},
	primacy: {
		name: "games.clankcatacombs.cards.primacy.name",
		text: "games.clankcatacombs.cards.primacy.text",
		acquire: "games.clankcatacombs.cards.primacy.acquire",
		arrive: "games.clankcatacombs.cards.primacy.arrive",
		react: "games.clankcatacombs.cards.primacy.react"
	},
	persist: {
		name: "games.clankcatacombs.cards.persist.name",
		text: "games.clankcatacombs.cards.persist.text",
		acquire: "games.clankcatacombs.cards.persist.acquire",
		arrive: "games.clankcatacombs.cards.persist.arrive",
		react: "games.clankcatacombs.cards.persist.react"
	},
	bolt: {
		name: "games.clankcatacombs.cards.bolt.name",
		text: "games.clankcatacombs.cards.bolt.text",
		acquire: "games.clankcatacombs.cards.bolt.acquire",
		arrive: "games.clankcatacombs.cards.bolt.arrive",
		react: "games.clankcatacombs.cards.bolt.react"
	},
	collection: {
		name: "games.clankcatacombs.cards.collection.name",
		text: "games.clankcatacombs.cards.collection.text",
		acquire: "games.clankcatacombs.cards.collection.acquire",
		arrive: "games.clankcatacombs.cards.collection.arrive",
		react: "games.clankcatacombs.cards.collection.react"
	},
	competition: {
		name: "games.clankcatacombs.cards.competition.name",
		text: "games.clankcatacombs.cards.competition.text",
		acquire: "games.clankcatacombs.cards.competition.acquire",
		arrive: "games.clankcatacombs.cards.competition.arrive",
		react: "games.clankcatacombs.cards.competition.react"
	},
	exhibit: {
		name: "games.clankcatacombs.cards.exhibit.name",
		text: "games.clankcatacombs.cards.exhibit.text",
		acquire: "games.clankcatacombs.cards.exhibit.acquire",
		arrive: "games.clankcatacombs.cards.exhibit.arrive",
		react: "games.clankcatacombs.cards.exhibit.react"
	},
	"rebel-squire": {
		name: "games.clankcatacombs.cards.rebel-squire.name",
		text: "games.clankcatacombs.cards.rebel-squire.text",
		acquire: "games.clankcatacombs.cards.rebel-squire.acquire",
		arrive: "games.clankcatacombs.cards.rebel-squire.arrive",
		react: "games.clankcatacombs.cards.rebel-squire.react"
	},
	inspire: {
		name: "games.clankcatacombs.cards.inspire.name",
		text: "games.clankcatacombs.cards.inspire.text",
		acquire: "games.clankcatacombs.cards.inspire.acquire",
		arrive: "games.clankcatacombs.cards.inspire.arrive",
		react: "games.clankcatacombs.cards.inspire.react"
	},
	"defensive-position": {
		name: "games.clankcatacombs.cards.defensive-position.name",
		text: "games.clankcatacombs.cards.defensive-position.text",
		acquire: "games.clankcatacombs.cards.defensive-position.acquire",
		arrive: "games.clankcatacombs.cards.defensive-position.arrive",
		react: "games.clankcatacombs.cards.defensive-position.react"
	},
	channel: {
		name: "games.clankcatacombs.cards.channel.name",
		text: "games.clankcatacombs.cards.channel.text",
		acquire: "games.clankcatacombs.cards.channel.acquire",
		arrive: "games.clankcatacombs.cards.channel.arrive",
		react: "games.clankcatacombs.cards.channel.react"
	},
	study: {
		name: "games.clankcatacombs.cards.study.name",
		text: "games.clankcatacombs.cards.study.text",
		acquire: "games.clankcatacombs.cards.study.acquire",
		arrive: "games.clankcatacombs.cards.study.arrive",
		react: "games.clankcatacombs.cards.study.react"
	},
	"mystic-slide": {
		name: "games.clankcatacombs.cards.mystic-slide.name",
		text: "games.clankcatacombs.cards.mystic-slide.text",
		acquire: "games.clankcatacombs.cards.mystic-slide.acquire",
		arrive: "games.clankcatacombs.cards.mystic-slide.arrive",
		react: "games.clankcatacombs.cards.mystic-slide.react"
	}
}, nr = {
	fool: "games.clankcatacombs.fates.fool",
	magician: "games.clankcatacombs.fates.magician",
	"high-priestess": "games.clankcatacombs.fates.high-priestess",
	empress: "games.clankcatacombs.fates.empress",
	emperor: "games.clankcatacombs.fates.emperor",
	hierophant: "games.clankcatacombs.fates.hierophant",
	lovers: "games.clankcatacombs.fates.lovers",
	chariot: "games.clankcatacombs.fates.chariot",
	strength: "games.clankcatacombs.fates.strength",
	hermit: "games.clankcatacombs.fates.hermit",
	wheel: "games.clankcatacombs.fates.wheel",
	justice: "games.clankcatacombs.fates.justice",
	"hanged-man": "games.clankcatacombs.fates.hanged-man",
	death: "games.clankcatacombs.fates.death",
	temperance: "games.clankcatacombs.fates.temperance",
	imp: "games.clankcatacombs.fates.imp",
	tower: "games.clankcatacombs.fates.tower",
	star: "games.clankcatacombs.fates.star",
	moon: "games.clankcatacombs.fates.moon",
	sun: "games.clankcatacombs.fates.sun",
	judgement: "games.clankcatacombs.fates.judgement",
	world: "games.clankcatacombs.fates.world"
}, rr = {
	adventurer: "games.clankcatacombs.characters.adventurer",
	agnet: "games.clankcatacombs.characters.agnet",
	dallan: "games.clankcatacombs.characters.dallan",
	garignar: "games.clankcatacombs.characters.garignar",
	lenara: "games.clankcatacombs.characters.lenara",
	monkeybot: "games.clankcatacombs.characters.monkeybot",
	whiskers: "games.clankcatacombs.characters.whiskers"
}, ir = (e, t) => t(tr[e]?.name ?? X.empty);
function ar(e, t) {
	if (/^ladder[A-E]$/.test(e)) return t(X.ladder, { letter: e.slice(6) });
	let n = /^(gold|silver|heal|clank|skill)(\d+)$/.exec(e);
	return n ? `${t({
		gold: X.gold,
		silver: X.silver,
		heal: er["option-heal"],
		clank: X.noise,
		skill: X.skill
	}[n[1]])} ${n[2]}` : L[e] ? ir(e, t) : t(er[e] ?? X.empty);
}
function or(e, t, n) {
	if (!t || !e.tiles.some((e) => e.id === +t.split("/")[0])) return n(X.unknown);
	let r = V(e.tiles, t), i = r.def.features.find((e) => er[e]);
	return `${n(X.room, { n: `${r.tile.id + 1}.${r.tileDef.rooms.indexOf(r.def) + 1}` })}${i ? ` · ${ar(i, n)}` : ""}`;
}
function sr(e, t, n, r, i = (e) => e) {
	let a = t.players.find((e) => e.rid === t.active), o = [...n?.hand ?? [], ...t.players.flatMap((e) => [...e.played, ...e.discard])];
	switch (e.type) {
		case "play":
		case "react": return r(e.type === "play" ? X.play : X.react, { card: ir(o.find((t) => t.uid === e.card)?.kind ?? "", r) });
		case "row": {
			let n = t.row[e.slot];
			return r(X.row, {
				card: ir(n?.kind ?? "", r),
				n: n ? dt(t, n.kind) : 0,
				resource: r(n && L[n.kind].type === "monster" ? X.swords : X.skill)
			});
		}
		case "reserve": return r(X.reserve, {
			card: ir(e.card, r),
			n: L[e.card].cost
		});
		case "move": {
			let i = n?.moves.find((t) => t.id === e.route);
			return r(X.move, {
				room: i?.slot ? r(X.underworldSlot, { letter: i.slot }) : or(t, i?.to ?? "", r),
				swords: e.swords
			});
		}
		case "orient": return r(X.rotate, { n: e.rotation * 90 });
		case "artifact": return r(X.artifact);
		case "unlock": return r(X.unlock, { item: ar(e.feature, r) });
		case "mark": return r(X.mark, { item: ar(e.slot.split("|")[1].split(":")[0], r) });
		case "market": return r(X.market, {
			item: ar(e.item, r),
			n: vt(t, a, e.discount)
		});
		case "fight": return r(X.fight, {
			item: L[e.monster] ? ir(e.monster, r) : ar(e.monster, r),
			resource: r(X[e.resource])
		});
		case "use": return r(X.use, { item: ar(e.token.replace("fate:", "fate-"), r) });
		case "spell": return r(X.spell, { item: ar(e.spell, r) });
		case "choose": {
			if (e.option === "character") return ar(e.target, r);
			let a = ar(`option-${e.option}`, r);
			if (e.target === void 0) return a;
			let s = ar(e.target, r);
			return e.option === "fate" ? s = ar(`fate-${e.target}`, r) : e.option === "teleport" && (e.target.includes(">") || e.target.startsWith("ladder:") || e.target.startsWith("ascend:")) ? s = e.target.startsWith("ladder:") ? r(X.ladder, { letter: e.target.slice(7) }) : or(t, e.target.split(">").at(-1).replace(/^ascend:/, ""), r) : /^\d+\/[^/:>]+$/.test(e.target) && t.tiles.some((t) => t.id === +e.target.split("/")[0]) ? s = or(t, e.target, r) : [
				"trash",
				"discard",
				"copy",
				"top",
				"reveal"
			].includes(e.option) && /^\d+$/.test(e.target) ? s = ir(o.find((t) => t.uid === +e.target)?.kind ?? "", r) : t.players.some((t) => t.rid === e.target) ? s = i(e.target) : ["replace", "acquire"].includes(e.option) ? s = ir(t.row[+e.target]?.kind ?? "", r) : e.option === "rotate" ? s = `${e.target * 90}°` : e.option === "place" ? s = r(X.placeTarget, { n: (n?.actions.findIndex((t) => t.type === "choose" && t.target === e.target) ?? 0) + 1 }) : e.option === "return" && /^\d+\/[^:]+:\d+$/.test(e.target) && (s = `${or(t, e.target.split(":")[0], r)} · ${e.target.split(":")[1]}`), r(X.chooseTarget, {
				option: a,
				target: s
			});
		}
		case "end": return r(X.end);
		case "pass": return r(X.pass);
		case "tick": return r(X.resolving);
	}
}
var cr = {
	play: X["log-play"],
	react: X["log-react"],
	acquire: X["log-acquire"],
	device: X["log-device"],
	defeat: X["log-defeat"],
	trash: X["log-trash"],
	move: X["log-move"],
	artifact: X["log-artifact"],
	secret: X["log-secret"],
	prisoner: X["log-prisoner"],
	market: X["log-market"],
	dragon: X["log-dragon"],
	damage: X["log-damage"],
	escape: X["log-escape"],
	knockout: X["log-knockout"],
	discover: X["log-discover"],
	reveal: X["log-reveal"],
	fate: X["log-fate"]
};
function lr(e, t, n) {
	return n(cr[e.event] ?? X.resolving, {
		item: e.card ? ir(e.card, n) : e.token ? ar(e.event === "fate" ? `fate-${e.token}` : e.token, n) : e.room ? or(t, e.room, n) : "",
		n: e.n ?? 0
	});
}
//#endregion
//#region src/games/clankcatacombs/illustrations.ts
var ur = {
	ink: "#101321",
	paper: "#ead8ab",
	cream: "#f6e8c4",
	gold: "#d8b66b",
	blue: "#365691",
	muted: "#a6a6b3",
	teal: "#6cc9cc"
}, dr = (e) => Math.round(e * 100) / 100, Z = (e, t = "none", n = "none", r = 1, i = "") => `<path d="${e}" fill="${t}" stroke="${n}" stroke-width="${r}" stroke-linejoin="round" stroke-linecap="round" ${i}/>`, fr = (e, t, n, r, i, a = 0, o = "none", s = 1) => `<rect x="${dr(e)}" y="${dr(t)}" width="${dr(n)}" height="${dr(r)}" rx="${a}" fill="${i}" stroke="${o}" stroke-width="${s}"/>`, pr = (e, t, n, r, i = "none", a = 1) => `<circle cx="${dr(e)}" cy="${dr(t)}" r="${dr(n)}" fill="${r}" stroke="${i}" stroke-width="${a}"/>`, mr = (e, t, n, r, i, a = "none", o = 1) => `<ellipse cx="${dr(e)}" cy="${dr(t)}" rx="${dr(n)}" ry="${dr(r)}" fill="${i}" stroke="${a}" stroke-width="${o}"/>`, hr = (e, t, n, r) => `<g transform="translate(${dr(e)} ${dr(t)}) scale(${n})">${r}</g>`, gr = (e, t, n, r = "0", i = "1") => `<linearGradient id="${e}" x1="0" y1="0" x2="${r}" y2="${i}"><stop stop-color="${t}"/><stop offset="1" stop-color="${n}"/></linearGradient>`;
function _r() {
	return `<defs>${gr("table", "#34384f", "#141d2d", ".3")}${gr("silver", "#d0cfb8", "#686f81", ".3")}${gr("gold", "#f1db98", "#92713f", ".35")}${gr("paper", "#f3e3b9", "#cfb67d", ".15")}${gr("blue", "#526aa7", "#263861", ".2")}${gr("red", "#ae4e4d", "#6c303d", ".2")}${gr("purple", "#765a93", "#43305d", ".2")}${gr("leather", "#6a4b46", "#392d35", ".4")}${gr("stone", "#68718a", "#343c55", ".7")}${gr("cavern", "#3e5477", "#111a30", ".5")}${gr("skin", "#edc69b", "#b88766", ".8")}${gr("cloak", "#64817d", "#273f4f", ".5")}${gr("wood", "#bd9053", "#725035", ".6")}${gr("flame", "#fff5bd", "#e9a544", ".35")}${gr("ice", "#b6f5ef", "#387dba", ".7")}${gr("ruby", "#ffdf89", "#ed704b", ".8")}${gr("rune", "#b4e5df", "#5b8eae", ".5")}
<pattern id="table-weave" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M0 2H10M2 0V10" stroke="#8e96aa" opacity=".045" stroke-width=".65"/></pattern>
<pattern id="paper-fibre" width="19" height="23" patternUnits="userSpaceOnUse"><path d="M2 4H5M11 16H15M4 21H6" stroke="#735c36" opacity=".09" stroke-width=".65"/></pattern></defs>`;
}
function vr(e, t, n, r, i = ur.gold) {
	let a = {
		skill: Z("M16 1 30 16 16 31 2 16Z", i, ur.ink, 1.6) + Z("M16 5 26 16 16 27 6 16Z", "none", "#e7e9d0", .8),
		sword: Z("M6 29 12 21 23 4 28 2 28 8 17 24Z", i, ur.ink, 1.4) + Z("M9 18 21 27M13 23 5 31", "none", "#ead7a5", 3) + Z("M23 7 14 21", "none", "#fff4da", 1),
		boot: Z("M8 3H22L20 16 29 21V28H4V21L11 16Z", i, ur.ink, 1.5) + Z("M10 8H20M7 24H28", "none", "#f9e1ab", 1.3),
		coin: pr(16, 16, 13, "url(#gold)", ur.ink, 1.5) + pr(16, 16, 9, "none", "#f8dda2", 1) + Z("M16 8 22 16 16 24 10 16Z", "none", "#856132", 1.4),
		heart: Z("M16 29 4 17C-3 6 9-1 16 8 23-2 37 7 28 18Z", i, ur.ink, 1.4) + Z("M7 10Q10 6 13 11", "none", "#f4ad9a", 1.5),
		key: pr(11, 10, 6, "none", i, 3) + Z("M15 15 28 28M22 22 26 18M26 26 30 22", "none", i, 3),
		noise: Z("M9 26V8L27 4V23M9 13 27 9", "none", i, 3) + mr(6, 26, 5, 3, i) + mr(24, 24, 5, 3, i),
		cube: Z("M3 9 16 2 29 9V24L16 31 3 24Z", i, ur.ink, 1.1) + Z("M3 9 16 16 29 9M16 16V31", "none", "#f3ddb1", 1),
		book: Z("M4 5 15 2 29 7V30L16 25 4 29Z", i, ur.ink, 1.4) + Z("M16 5V25M8 10 12 9M8 16 12 15M20 11 26 13M20 17 26 19", "none", "#efdcad", 1.2),
		compass: pr(16, 16, 12, "none", i, 1.7) + Z("M16 3 20 13 29 16 19 20 16 29 12 19 3 16 13 12Z", i, ur.ink, 1) + pr(16, 16, 2, ur.ink),
		chevron: Z("M6 10 16 21 27 10", "none", i, 2.6),
		crown: Z("M3 8 10 15 16 3 23 15 30 8 26 27H7Z", i, ur.ink, 1.5) + Z("M9 22H25", "none", "#f6dda5", 1)
	};
	return hr(t, n, r / 32, a[e] ?? a.skill);
}
function yr(e = !1) {
	let t = Z("M0 160 240 151V240H0Z", e ? "#796651" : "#3a485d");
	for (let n = 0; n < 4; n++) for (let r = 0; r < 5; r++) {
		let i = 164 + n * 22, a = r * 60 - n % 2 * 28;
		t += Z(`M${a} ${i} ${a + 55} ${i - 2} ${a + 63} ${i + 18} ${a - 7} ${i + 21}Z`, e ? [
			"#8f7d62",
			"#9c8667",
			"#827158"
		][(r + n) % 3] : [
			"#526076",
			"#48586d",
			"#59677b"
		][(r + n) % 3], "#29354a", .75);
	}
	return t;
}
function br(e = "blue") {
	let t = fr(0, 0, 240, 240, "url(#cavern)");
	t += Z("M40 0H211L179 168 51 165Z", e === "purple" ? "#3c3658" : "#273f5c"), t += Z("M65 164V56Q119-5 175 56V164Z", e === "purple" ? "#1b1b34" : "#182c46"), t += Z("M81 162V65Q119 15 160 65V162Z", e === "purple" ? "#242040" : "#243b55");
	for (let [e, n] of [22, 185].entries()) {
		t += Z(`M${n} 0H${n + 36}V173L${n - 8} 186Z`, "url(#stone)", "#202b42", 1.3);
		for (let e = 0; e < 8; e++) t += Z(`M${n - 3} ${e * 23} ${n + 34} ${e * 23 + 4}`, "none", "#9fa7ac", .65);
		t += Z(`M${n + 8} 0V170`, "none", e ? "#4a5872" : "#87959f", 1.8);
	}
	t += Z("M49 145V52Q120-31 188 52V148", "none", "#81909e", 8), t += Z("M54 144V54Q120-19 183 54V146", "none", "#334358", 2);
	for (let e = 0; e < 9; e++) {
		let n = Math.PI + e / 8 * Math.PI, r = 120 + 70 * Math.cos(n), i = 56 + 60 * Math.sin(n);
		t += Z(`M${r} ${i} ${120 + 62 * Math.cos(n)} ${56 + 51 * Math.sin(n)}`, "none", "#2a344a", 1.3);
	}
	return t += yr(e === "warm"), t += e === "purple" ? Z("M60 60 95 54 80 180 29 211Z", "#8e77ab", "none", 1, "opacity=\".10\"") : Z("M139 10 174 23 152 183 74 229 31 218Z", "#7cbbce", "none", 1, "opacity=\".10\""), t += Z("M4 117 17 112 22 126 10 133Z", "#2e4656") + Z("M201 161 215 149 224 160 232 161 221 174 210 170Z", "#46595b"), t;
}
function xr(e, t, n = 1) {
	return hr(e, t, n, mr(0, 7, 11, 4, "#172338") + Z("M-5 4H6L4-13H-3Z", "#c2af83", "#38394a", 1) + Z("M-2-10V-21", "none", "#493c35", 1) + Z("M0-21Q-8-28 1-40 9-28 0-21Z", "url(#flame)") + Z("M0-24Q-3-29 1-33 4-29 0-24Z", "#fff5d2"));
}
function Sr(e, t, n = 1) {
	return hr(e, t, n, Z("M-39 7 13-4 49 13 0 28Z", "#111d30", "none", 1, "opacity=\".55\"") + Z("M-41-27 8-40 42-22V14L-6 29-41 9Z", "url(#wood)", "#382e30", 2) + Z("M-41-27Q-39-57-17-60L25-46Q40-42 42-22L-6-8Z", "#a17a47", "#382e30", 2) + Z("M-6-8V29L42 14V-22Z", "#7c5838", "#352a2c", 1.5) + Z("M-31-33Q-29-54-17-58M4-42Q22-58 31-28", "none", "#edcc7a", 7) + Z("M-31-21V13M4-10V24", "none", "#d4af63", 6) + Z("M-40-19-6-1 41-15M-39-8-7 8 41-6M-38 3-7 18 40 4", "none", "#61462f", 1) + Z("M-16-5-2-9V5L-16 10Z", "#e7c97d", "#5f4b32", 1.2) + pr(-8, -1, 1.6, "#3c302c") + Z("M-38-29-5-11 40-24", "none", "#f2d68b", 1));
}
function Cr() {
	let e = mr(122, 218, 56, 10, "#111b2b");
	e += Z("M90 152 105 156 113 205 98 215 85 210Z", "#39333b", "#101b2d", 1.5) + Z("M130 150 152 155 152 211 136 218 127 210Z", "#292e39", "#101b2d", 1.5), e += Z("M98 200 110 207 110 219 82 222 79 216Z", "#63513c", "#182333", 1.4) + Z("M137 203 153 205 161 217 137 222 130 217Z", "#63513c", "#182333", 1.4), e += Z("M88 77Q74 83 67 101L74 168Q76 186 84 195L103 176 113 133Q134 157 155 181L167 174 160 91Q153 81 146 76Z", "url(#cloak)", "#102131", 2), e += Z("M84 95 80 155 90 174 106 124M147 93 159 163 145 150 135 108Z", "#344f58"), e += Z("M92 86 113 74 145 83 153 143 130 163 94 151 89 115Z", "#735b47", "#1e2836", 1.5), e += Z("M97 94 130 104 149 94M95 114 131 123 150 115M94 133 132 144 151 135", "none", "#ae9061", 2), e += Z("M90 90 147 141", "none", "#292d33", 13) + Z("M90 88 147 139", "none", "#b49360", 5) + Z("M95 143 153 136 154 148 96 156Z", "#393339", "#192333", 1) + fr(118, 140, 15, 11, "#bd9858", 1, "#272b34", 1) + fr(122, 143, 7, 5, "#4b4540"), e += Z("M83 87Q64 88 59 113L76 145 90 133 76 111 97 101Z", "url(#cloak)", "#132334", 1.6), e += Z("M147 82Q161 82 170 99L177 129 161 134 151 106 138 101Z", "url(#cloak)", "#132334", 1.6), e += Z("M76 128 88 127 100 140 92 151 80 144Z", "#b18d6a", "#272c36", 1.2) + Z("M162 123 176 122 178 143 169 148 161 140Z", "url(#skin)", "#272c36", 1.2), e += Z("M92 57Q88 36 105 27 125 17 138 29 148 41 145 52L137 70Q128 77 118 81L102 70Z", "url(#skin)", "#1a2637", 1.5), e += Z("M86 60Q80 33 111 13 149 14 152 47L144 67 137 43 115 30 98 52 99 72Z", "url(#cloak)", "#142333", 1.7), e += Z("M90 53 111 20 137 29 116 30 98 55Z", "#84958a"), e += Z("M101 60 115 65 140 56 136 75 119 86 104 77Z", "#29414d", "#1b2c39", 1.1), e += Z("M101 49 110 51M127 48 135 46", "none", "#3a302d", 1.4) + pr(108, 52, 1.3, "#172533") + pr(130, 49, 1.2, "#172533"), e += Z("M78 157 143 74 150 70 149 80 87 163Z", "#bfd7d4", "#172638", 1.2) + Z("M146 76 89 154", "none", "#edf3df", 1.5) + Z("M74 146 92 163", "none", "#c4a15e", 4) + Z("M82 156 68 174", "none", "#564334", 6), e += Z("M151 145 163 152 158 173 146 167Z", "#866344", "#222938", 1.3) + pr(150, 155, 2, "#d7b671"), e += Z("M93 94Q90 108 95 120M79 103Q72 117 80 127M152 96Q159 106 161 119M104 164Q100 184 104 197M143 169Q148 190 145 200", "none", "#92a39b", .75), e += Z("M94 88 123 101M96 109 125 120M98 130 126 139", "none", "#c8a778", .75);
	for (let [t, n] of [
		[95, 95],
		[99, 116],
		[100, 137],
		[145, 99],
		[148, 119],
		[149, 139]
	]) e += pr(t, n, 1.3, "#bfa16c", "#524a3e", .4);
	return e += Z("M89 72Q96 82 106 86M143 69 137 79M91 86Q109 93 121 90M93 91Q110 98 127 94", "none", "#203540", 1.3), e += Z("M103 48Q107 46 112 49M126 47Q130 44 135 45", "none", "#b0926d", .8), e += Z("M86 210Q96 211 105 211M137 213 151 211M91 203 95 207M146 203 143 209", "none", "#a88a60", .9), e;
}
function wr() {
	let e = Sr(168, 187, .94) + mr(91, 219, 59, 10, "#142034");
	e += Z("M83 147 105 145 110 192 78 206 66 198 88 180Z", "#4c3d43", "#152133", 1.7) + Z("M106 151 130 153 148 195 138 212 121 202 114 180 95 171Z", "#453941", "#152133", 1.6), e += Z("M69 190 81 200 63 213 43 214 39 209 48 202Z", "#7c5c42", "#182135", 1.4) + Z("M125 196 140 200 151 214 130 219 119 214Z", "#7c5c42", "#182135", 1.4), e += Z("M82 66 109 73 126 112 118 163 76 161 62 134 64 96Z", "url(#blue)", "#152135", 1.8), e += Z("M80 76 64 118 78 145 91 126 105 87Z", "#455d7a") + Z("M101 89 118 126 105 151 89 145Z", "#223e5b"), e += Z("M73 145 119 147 119 157 77 155Z", "#6a4c38", "#192438", 1.1) + fr(95, 146, 12, 11, "url(#gold)", 1, "#35313b", 1), e += Z("M105 85 126 88 137 119 159 142 150 152 122 133 110 112Z", "#41618b", "#172539", 1.6), e += Z("M145 140 155 138 169 150 164 159 153 155 147 152Z", "url(#skin)", "#24303b", 1.2), e += Z("M73 89Q55 85 46 109L50 139 77 153 87 143 65 131 65 117 83 108Z", "#526a8a", "#172539", 1.5), e += Z("M76 141 86 143 102 132 107 139 92 157 80 155Z", "url(#skin)", "#24303b", 1.2), e += Z("M81 49Q82 35 96 32 111 31 120 43L127 56 119 78Q112 86 102 87L86 74Z", "url(#skin)", "#202b39", 1.5), e += Z("M79 65Q68 37 90 23 116 20 129 43L126 58 113 41 99 46 88 62 91 81 80 75Z", "#423f42", "#182333", 1.5), e += Z("M84 40 96 27 116 30 125 42 105 35Z", "#746252") + Z("M94 58 103 57M112 55 120 56", "none", "#514032", 1.5) + pr(99, 60, 1.25, "#172333") + pr(116, 59, 1.25, "#172333"), e += Z("M109 60 111 68 107 70M104 76 114 75", "none", "#9e6f55", 1.1) + Z("M76 77 100 89 112 82 104 100 83 94Z", "#9c7c5f", "#28313b", 1), e += Z("M57 155 70 153 74 179 62 185 53 179Z", "#826344", "#202c3b", 1.2), e += Z("M81 84Q79 102 73 114M86 93 79 117M107 105Q117 127 113 138M77 136Q90 142 104 141", "none", "#8f9eab", .8), e += Z("M86 34 94 30 100 31M90 39 100 35 112 37M79 49 84 41", "none", "#aa8c65", .9), e += Z("M95 65Q98 62 102 65M113 64 119 65M90 69Q92 76 99 79", "none", "#d1a078", .85), e += Z("M149 145 156 149M151 143 159 147M157 151 162 154M88 147 96 138", "none", "#8f654c", .8);
	for (let t = 0; t < 6; t++) e += pr(71 + t * 2, 156 + t * .5, .65, "#c1a36c");
	return e += Z("M91 176 102 169M78 190 88 184M119 172 127 184M132 193 138 199", "none", "#9c7b61", .9), e;
}
function Tr() {
	let e = mr(125, 218, 62, 11, "#14172a");
	e += Z("M90 88 143 78 161 123 170 210 144 219 128 208 107 219 75 208 85 142 66 124Z", "url(#purple)", "#1d1b31", 1.9), e += Z("M107 98 100 161 87 210 111 204 126 139 134 208 152 214 142 145 135 96Z", "#3f365f") + Z("M106 100 119 119 125 97 134 102 135 181 122 201 114 166Z", "#9e8b73", "#343042", 1.1);
	for (let t = 0; t < 6; t++) e += Z(`M113 ${113 + t * 9}Q124 ${120 + t * 9} 132 ${112 + t * 9}`, "none", "#d9cbae", 2);
	e += Z("M86 94 65 102 47 137 62 148 86 127 103 115Z", "#6a537c", "#1d2033", 1.6) + Z("M144 89 166 100 174 132 159 137 145 115 127 109Z", "#6a537c", "#1d2033", 1.6), e += Z("M53 132 61 135 57 146 47 149 42 144Z", "#d1c7a9", "#303045", 1.2) + Z("M162 128 174 128 183 144 178 151 169 145Z", "#c3ba9e", "#303045", 1.2), e += Z("M89 78Q79 48 99 28 126 9 147 35L151 70 136 86Z", "#514868", "#202236", 1.7) + Z("M97 54Q96 34 114 31 136 27 142 47L141 61 133 76 108 79 99 69Z", "#d9d0af", "#2a2c3b", 1.7), e += Z("M104 49Q109 44 115 48L117 56Q113 62 107 60L103 55ZM124 49Q128 44 134 48L135 55Q132 61 126 60L122 55Z", "#1a2734") + Z("M120 59 116 68 124 67Z", "#4a4b49"), e += Z("M108 70 132 68 130 81 110 83Z", "#c4b999", "#333345", 1) + Z("M114 72V81M120 71V80M126 71V79", "none", "#666358", 1), e += Z("M47 213 48 73", "none", "#604837", 7) + Z("M46 211 47 74", "none", "#ac9164", 2), e += Z("M34 78 39 62 50 56 59 65 61 78 48 89Z", "url(#silver)", "#222b3a", 1.5) + pr(47, 70, 8, "#8cd5c5", "#c5e6cf", 1.3), e += Z("M46 65Q25 49 46 20 47 40 59 37 69 55 46 65Z", "#5faaa7", "#9fd8c2", 1) + Z("M45 60Q37 49 48 37 46 50 53 48 56 57 45 60Z", "#d4e8b1"), e += Z("M80 195 95 190M150 192 159 199", "none", "#ad9176", 1.5), e += Z("M102 39Q109 34 118 35M136 44 138 52M101 64 107 69M133 64 138 61", "none", "#f4e6bf", 1), e += Z("M121 35 118 41 120 44M134 59 132 64M107 57 110 62", "none", "#8d8a7a", .75);
	for (let t = 0; t < 5; t++) e += Z(`M${87 + t * 2} ${126 + t * 15}q7 9 5 21`, "none", "#8a7095", .8);
	return e += Z("M143 132Q152 166 158 185M148 135Q154 164 163 182", "none", "#2f294e", 1.4), e += Z("M107 91 116 98 126 91 136 97", "none", "#c6a56a", 2) + pr(122, 100, 3, "#8fc3b5", "#ebd294", .8), e;
}
function Er() {
	let e = Z("M49 213 200 194 193 211 60 235Z", "#15253a") + Z("M40 159 164 132 210 157 85 188Z", "#8c8c83", "#253247", 1.5) + Z("M40 159 85 188V222L41 194Z", "#606d76", "#253247", 1.3) + Z("M85 188 210 157V190L85 222Z", "#47586c", "#253247", 1.3);
	e += Z("M49 160 87 177 196 154 162 140Z", "#a7aca2") + Z("M97 194 193 171M98 207 191 184", "none", "#9babad", .85), e += Z("M70 204 93 177 126 110 160 33 175 19 173 42 144 119 108 187 86 209Z", "url(#silver)", "#17283d", 1.7) + Z("M93 181 132 113 173 24 162 37 127 116 88 189Z", "#e2f0dc"), e += Z("M132 104 141 90M140 85 147 72M149 66 155 52", "none", "#84b5bf", 2) + Z("M78 165Q89 157 103 169L125 186 121 194 101 181 90 177 78 180 69 175Z", "url(#gold)", "#524a36", 1.5), e += Z("M88 184 75 207", "none", "#3c3f41", 11) + Z("M88 184 75 207", "none", "#8b6d4f", 6);
	for (let t = 0; t < 4; t++) e += Z(`M${79 + t * 2} ${202 - t * 5}l7 4`, "none", "#c1a678", 1);
	e += Z("M69 208 78 205 83 214 77 221 69 217Z", "url(#gold)", "#3e3f3b", 1.4) + pr(76, 213, 2, "#78c5c1"), e += Z("M94 171 102 173 100 180 93 179Z", "#5bafc5", "#d0e4be", .8);
	for (let [t, n, r] of [
		[
			42,
			145,
			.6
		],
		[
			206,
			147,
			.5
		],
		[
			30,
			202,
			.7
		]
	]) e += hr(t, n, r, Z("M0 0Q-15-21-9-27 6-18 0 0M0 0Q15-17 21-10 17 5 0 0M0 0Q-17 8-19 0-12-9 0 0", "#426466", "#1e394d", 1));
	return e += xr(198, 128, .65), e;
}
function Dr() {
	let e = Z("M47 165 140 139 207 171 115 210Z", "#93847b", "#293248", 1.5) + Z("M47 165 115 210V240L47 197Z", "#655d66", "#293248", 1.2) + Z("M115 210 207 171V203L115 240Z", "#504959", "#293248", 1.2);
	e += Z("M58 164 139 146 194 170 116 198Z", "#baaa8a") + Z("M63 181 89 193 93 220M142 222 161 207 167 213", "none", "#343b4e", 1.2), e += Z("M64 98 91 53 151 42 184 87 171 151 113 179 69 147Z", "#fa9d4e", "#523345", 1.6), e += Z("M64 98 107 91 91 53Z", "#ffe99c", "#ffe7b3", .9) + Z("M91 53 151 42 139 87 107 91Z", "#fff0b3", "#fff1c6", 1), e += Z("M151 42 184 87 139 87Z", "#ffbe69", "#ffe4a1", 1) + Z("M107 91 139 87 171 151 113 179Z", "#ef7844", "#ffc982", 1.1), e += Z("M139 87 184 87 171 151Z", "#be4c48", "#ffb773", 1) + Z("M64 98 107 91 113 179 69 147Z", "#e78f48", "#ffce89", 1), e += Z("M78 105 96 103 100 140 82 132Z", "#ffd784", "none", 1, "opacity=\".55\"") + Z("M151 69 143 91 150 108", "none", "#fff0c4", 1.6);
	for (let [t, n, r] of [
		[
			46,
			108,
			1
		],
		[
			188,
			67,
			.8
		],
		[
			198,
			130,
			.6
		],
		[
			87,
			37,
			.6
		]
	]) e += hr(t, n, r, Z("M-5 0H5M0-6V6", "none", "#f5e5ad", 1.3));
	return e += Z("M21 196 33 188 41 201 26 207Z", "#7b8a92", "#afb8ab", .7) + Z("M191 213 201 192 213 209 208 224Z", "#67838f", "#9dc2c0", .7), e;
}
function Or() {
	let e = Z("M41 207V58Q119-34 199 57V208L183 219H56Z", "#72738b", "#273048", 1.9);
	e += Z("M66 206V65Q120 5 174 65V204Z", "#101729", "#2c2b45", 3), e += Z("M80 200V74Q120 28 159 74V200Z", "#1d223a") + Z("M97 192V83Q120 53 142 83V192Z", "#121c2b");
	for (let t = 0; t < 7; t++) for (let n of [43, 176]) e += Z(`M${n} ${68 + t * 20}H${n + 20}V${85 + t * 20}H${n}Z`, t % 2 ? "#6b6a7e" : "#7f7b8b", "#384057", .8);
	for (let t = 0; t < 11; t++) {
		let n = Math.PI + t / 10 * Math.PI, r = 120 + 73 * Math.cos(n), i = 61 + 67 * Math.sin(n);
		e += Z(`M${r} ${i} ${120 + 54 * Math.cos(n)} ${61 + 49 * Math.sin(n)}`, "none", "#3a3c54", 1.3);
	}
	e += Z("M111 7H128L137 32 121 43 105 31Z", "#a3a096", "#45455c", 1.2) + Z("M114 24 119 29 116 33M129 23 124 29 127 33", "none", "#505064", 1.7), e += Z("M62 206 177 204 192 217 49 222Z", "#999386", "#3e4458", 1) + Z("M49 222 192 217 210 235 34 239Z", "#716f75", "#3e4458", 1), e += Z("M88 127 89 71M154 129 153 72", "none", "#8d8e8c", 1.2);
	for (let t = 0; t < 9; t++) e += mr(89, 76 + t * 5, 2, 3, "none", "#8c9091", .8) + mr(153, 77 + t * 5, 2, 3, "none", "#777e87", .8);
	return e += Z("M102 178 112 155 125 161 131 180 124 194 108 194Z", "#514756", "#282b40", 1) + Z("M109 170 119 166 124 179 111 182Z", "#7b6c74"), e += xr(185, 199, .7) + Z("M51 169Q41 155 48 150 60 158 51 169M56 179Q61 160 68 166 70 178 56 179", "#52665e", "#344653", .6), e;
}
function kr() {
	let e = Z("M44 171 152 142 209 176 104 215Z", "#71818c", "#27364a", 1.3) + Z("M44 171 104 215V238L44 196Z", "#515e73", "#27364a", 1.2) + Z("M104 215 209 176V201L104 238Z", "#35465d", "#27364a", 1.2);
	e += Z("M60 88 141 64 188 90V177L104 203 61 177Z", "#644259", "#243149", 1.6) + Z("M68 89 140 72 176 92 105 113Z", "#dfce9f", "#5c4c4c", 1.3), e += Z("M106 116 178 96V174L106 195Z", "url(#leather)", "#352d41", 1.3) + Z("M63 94 104 117V199L63 176Z", "#64465a", "#352d41", 1.4), e += Z("M116 126 166 111V166L116 181Z", "none", "#c5a168", 2) + Z("M127 132 155 123V157L127 167Z", "url(#gold)", "#463b3e", 1), e += Z("M142 132 149 143 141 156 133 147Z", "#406f80", "#f3d291", .8);
	for (let t = 0; t < 3; t++) e += Z(`M70 ${111 + t * 26}l25 15`, "none", "#cdac6c", 4);
	return e += Z("M126 84 133 85 127 100 119 106Z", "#a75b54", "#453440", 1) + xr(43, 184, .8), e;
}
function Ar(e = !1) {
	let t = Z("M30 155 124 135 206 167 112 198Z", "#a1a294", "#28364b", 1.5) + Z("M30 155V183L111 226 112 198Z", "#5f6c79", "#28364b", 1.5) + Z("M112 198 206 167V192L111 226Z", "#44566b", "#28364b", 1.5);
	return t += Z(e ? "M63 31 91 29 101 108 79 153 54 142 72 101Z" : "M81 17 108 22 97 103 72 159 48 147 72 91Z", "#576b87", "#1d2b40", 2), t += Z("M132 25 162 20 163 91 188 143 164 158 138 111Z", "#394f71", "#1d2b40", 2), t += Z("M58 123 81 136 86 167 68 186 35 176 29 166 44 160Z", "url(#wood)", "#2b2c35", 1.6) + Z("M158 134 182 123 196 150 193 170 170 178 157 162Z", "url(#wood)", "#2b2c35", 1.6), t += Z("M45 156 70 165M39 174 67 182M169 155 187 149", "none", "#d2ae76", 2), e && (t += Z("M84 186 98 168 126 175 145 203 166 198", "none", "#bd9569", 5) + Z("M115 124 117 137M143 130 137 141M105 139 111 147", "none", "#e6bb65", 2)), t;
}
function jr() {
	let e = fr(0, 0, 240, 240, "url(#cavern)");
	e += Z("M0 0H240V164L217 155 195 109 166 98 154 40 125 56 95 23 57 75 45 122 12 151 0 170Z", "#29364e"), e += Z("M0 0 40 21 57 75 31 62 15 131 0 133Z", "#526079") + Z("M240 0 204 23 195 109 224 80 240 103Z", "#4d5573"), e += Z("M55 0 78 12 81 56 69 36Z", "#768086") + Z("M173 0 162 39 175 61 181 13Z", "#606784"), e += yr(!0);
	for (let [t, n, r] of [
		[
			21,
			174,
			.8
		],
		[
			211,
			160,
			.74
		],
		[
			37,
			208,
			.5
		],
		[
			218,
			218,
			.6
		]
	]) e += hr(t, n, r, Z("M-15 12-12-22 0-42 12-19 17 11 0 20Z", "#6c9cae", "#92bac0", .8) + Z("M0-42 3-13 0 20 17 11 12-19Z", "#49768f", "#92bac0", .6) + Z("M-12-22 3-13 0 20-15 12Z", "#9dc6c4", "#bfd7c9", .5));
	return e += Z("M58 3 94 6 150 176 40 228 0 211Z", "#ccac8b", "none", 1, "opacity=\".10\""), e;
}
function Mr() {
	let e = br("purple");
	for (let [t, n] of [[61, 100], [164, 111]]) e += Z(`M${t} ${n + 39}V${n}q13-17 26 0v39Z`, "#171d31", "#766e83", 1) + Z(`M${t + 5} ${n + 39}v-33q8-12 16 0v33Z`, "#29273d"), e += mr(t + 14, n + 22, 5, 6, "#8b897d") + Z(`M${t + 11} ${n + 23}h2m4 0h1`, "none", "#252c39", 1.1);
	e += Z("M179 0 176 36 191 45 189 99", "none", "#81868b", 1);
	for (let t = 0; t < 10; t++) e += mr(179, t * 4, 2, 2.7, "none", "#7f8389", .7);
	return e += Z("M38 151Q26 129 40 125 53 139 47 159M192 177Q211 152 218 163 218 179 192 177", "#485e5a", "#263747", .8), e;
}
function Nr() {
	return Z("M62 51Q46 41 41 58L29 177Q33 193 50 191L177 171 194 47 69 61Z", "url(#paper)", "#453d36", 2) + Z("M62 51 48 167Q42 182 29 177M177 171Q195 166 199 176L212 58Q211 41 194 47", "none", "#ad8e57", 5) + Z("M67 142 85 102 118 116 145 76 169 92M72 163 117 147 149 160M82 75 91 83M150 122l10 11m-10 0 10-11", "none", "#896c4d", 3) + Z("M111 63Q99 85 110 97T117 134", "none", "#ac6653", 2) + vr("compass", 121, 110, 38, "#567d8c");
}
function Pr() {
	return Z("M60 43 118 25 181 43 175 126Q161 174 121 205 76 178 63 129Z", "#506c81", "#17283b", 3) + Z("M71 52 119 37 168 52 161 124Q148 160 121 184 88 160 76 125Z", "none", "#c2ad7a", 7) + Z("M118 46 147 92 131 117 142 162 119 178 98 154 109 115 91 89Z", "#c7a665", "#263642", 2) + Z("M120 46V176", "none", "#f3d698", 2) + pr(120, 108, 11, "#506d79", "#e0c28a", 3);
}
function Fr() {
	return Z("M85 68 82 165 122 192 165 164 161 68Z", "#c6a065", "#203041", 3) + Z("M95 80 151 80 153 155 122 175 94 155Z", "#745336", "#362f38", 3) + Z("M122 72V176M92 154 152 154", "none", "#e4c081", 4) + Z("M98 70 99 50Q120 27 144 50L146 70M89 67H158M84 171 121 197 163 171", "none", "#b08a55", 8) + Z("M123 146Q95 126 121 93 143 122 123 146Z", "url(#flame)") + Z("M122 143Q112 131 122 117 132 132 122 143Z", "#fff4c4");
}
function Ir(e) {
	let t = mr(120, 213, 65, 11, "#172234");
	return e % 3 == 0 && (t += Z("M67 135 19 110 40 61 91 96M164 135 223 105 197 54 150 98Z", "#756689", "#263043", 3)), t += Z("M70 199 77 125 59 88 82 45 121 27 159 44 181 84 164 121 173 198 146 184 123 215 99 186Z", "#899a8d", "#202b3f", 3), t += Z("M78 56 94 70 109 52 121 72 139 52 159 67 169 88 153 111 145 167 121 187 96 166 86 109 69 88Z", "#4b5668", "#1e2b3d", 2), t += Z("M84 84 108 94 101 108 84 103M157 83 132 94 140 107 158 102", "#d3ae73", "#283243", 2) + Z("M102 140 111 132 120 145 131 131 140 140", "none", "#d9c59a", 5), t += Z("M84 49 62 22 72 65M157 49 184 22 170 66Z", "#c2ae86", "#263344", 3) + Z("M84 166 77 195 64 211 89 214 106 193M150 170 165 197 180 211 151 215 132 192Z", "#657c7c", "#263344", 3), t;
}
function Lr(e, t) {
	let n = e === "fiery-quartz" ? jr() : e === "skeleton-priest" ? Mr() : br(e === "darkened-alcove" || e === "skeleton-priest" ? "purple" : e === "fiery-quartz" ? "warm" : "blue");
	for (let [e, t] of [
		[30, 68],
		[199, 91],
		[27, 137],
		[207, 30]
	]) n += Z(`M${e} ${t}l4 7-2 7 5 3`, "none", "#abb1ad", .6);
	if ((e === "bandit" || e === "explore") && (n += Z("M27 0Q49 31 31 59T37 112Q19 137 31 169", "none", "#49665f", 3) + Z("M33 25Q49 8 53 19 48 34 33 25M29 69Q10 59 14 48 27 46 29 69M35 105Q52 86 57 98 50 112 35 105", "#526e62", "#284349", .6)), e === "burgle" ? n += wr() + xr(38, 171, .65) : e === "bandit" || e === "explore" || e === "mercenary" ? n += Cr() + xr(193, 179, .65) : e === "skeleton-priest" ? n += Tr() : e === "elven-sword" ? n += Er() : e === "fiery-quartz" ? n += Dr() : e === "darkened-alcove" ? n += Or() : e === "tome" ? n += kr() : [
		"sidestep",
		"scramble",
		"stumble"
	].includes(e) || /boots|step|walk|movement|stride|scuffl/.test(e) ? n += Ar(e === "stumble") : L[e]?.tome || /tome|librar|scribe|study/.test(e) ? n += kr() : L[e]?.type === "gem" ? n += Dr() : L[e]?.type === "monster" ? n += /skele|skull|priest|warlock|phantasm/.test(e) ? Tr() : Ir([...e].reduce((e, t) => e + t.charCodeAt(0), 0)) : L[e]?.type === "companion" ? n += Cr() : /map|compass|projection|divin|rod|passage|route|waystone|discover/.test(e) ? n += Nr() : /sword|blade|dagger|soul|attack|mercenar|sneak|ambush|thunder/.test(e) ? n += Er() : /shield|guardian|armor|armour|aegis/.test(e) ? n += Pr() : /light|lamp|flute|lute|torch|fire|mana|magic|spell/.test(e) ? n += Fr() : /trunk|gold|pay|rob|pillage|theft|treasure|swindle|loot|scrounge/.test(e) ? n += Sr(122, 155, 1.6) : L[e]?.type === "device" ? n += Or() : L[e]?.swords ? n += Er() : L[e]?.boots ? n += Ar() : n += Nr() + xr(194, 184, .75), n += Z("M0 0H240V240H0Z", "none", "#101c2b", 6), ![
		"burgle",
		"bandit",
		"explore",
		"mercenary",
		"skeleton-priest",
		"elven-sword",
		"fiery-quartz",
		"darkened-alcove",
		"tome",
		"sidestep",
		"scramble",
		"stumble"
	].includes(e)) {
		let t = [
			["#607f86", "#304c61"],
			["#7f718e", "#483753"],
			["#7b8b68", "#3e554b"],
			["#92796a", "#5b4246"]
		], [r, i] = t[[...e].reduce((e, t) => e + t.charCodeAt(0), 0) % t.length];
		if (n = n.replaceAll("#64817d", r).replaceAll("#273f4f", i), L[e]?.type === "gem") {
			let t = e.includes("rose") ? ["#f0b7b9", "#b96892"] : e.includes("black") || e.includes("smoky") ? ["#918b9e", "#4d4561"] : e.includes("white") ? ["#e2e2ca", "#a5b9bb"] : ["#bfcde0", "#6e85ad"];
			n = n.replaceAll("#ffdf89", t[0]).replaceAll("#ed704b", t[1]);
		}
	}
	return `<g id="${t}">${n}</g>`;
}
function Rr(e = "#6ca7a5") {
	return Z("M8 62 6 42 17 29 12 17 29 24 33 8 43 20 56 12 54 27 68 28 61 39 71 48 53 51 44 63 43 86H15L19 71 28 60 38 48 34 41 27 46 20 43 20 55Z", e, "#172638", 2) + Z("M33 32 40 31M28 51 33 50", "none", "#d8e0bd", 2) + Z("M25 86H48", "none", "#b6cebb", 2);
}
function zr(e, t, n, r = 0) {
	let i = [
		"#e0b28a",
		"#bd936f",
		"#d7ae85",
		"#e7c4a1",
		"#ba9678",
		"#dfb28c"
	][r % 6], a = [
		"#547995",
		"#a16b51",
		"#85719c",
		"#64816b",
		"#9b854e",
		"#5d7981"
	][r % 6], o = pr(0, 0, 39, "#25334a", "#bca76e", 1.4) + Z("M-32 36-26 10-11 0H12L27 12 33 36Z", a, "#172638", 1.5);
	return o += Z("M-18-8-16-27-2-33 16-25 20-6 12 10 2 16-12 7Z", i, "#293041", 1.1), o += Z(r === 2 ? "M-23-6Q-26-39-3-40 27-32 23-4L11-24-14-19-17 7Z" : r === 3 ? "M-26-22-16-42 12-43 23-23 32-16-31-13Z" : "M-21-7Q-28-37-6-41 16-44 23-19L20-3 9-26-11-19Z", r === 2 ? "#66516f" : "#514942", "#233044", 1.3), o += Z("M-10-5-5-6M7-6 12-5", "none", "#494035", 1.3) + Z("M0-1 2 5-1 7M-4 11H5", "none", "#966e54", .9) + Z("M-24 26 23 10", "none", "#d3b578", 5), `<g transform="translate(${e} ${t}) scale(${n / 40})">${o}</g>`;
}
function Br(e, t, n = 1) {
	return hr(e, t, n, mr(0, 59, 42, 9, "#0d1525") + Z("M-21-37H22L16-16Q54 11 40 47 24 65-19 57-52 49-43 21-40 4-16-16Z", "#202b3d", "#101d2c", 2) + Z("M-21-34-10-21 13-23 21-34M-28-10Q0 0 28-10", "none", "#6c7687", 2) + Z("M-18-16Q-49-10-49 12M19-15Q49-5 48 10", "none", "#b7a176", 2) + hr(-17, -4, .51, Rr("#67a6a1")) + Z("M-27 18-30 36M30 12 33 36", "none", "#3f4d60", 2));
}
//#endregion
//#region src/games/clankcatacombs/svg-art.tsx
function Vr({ art: e, kind: t = "", variant: n = 0, color: r, className: a }) {
	let s = i().replace(/[^a-z0-9]/gi, ""), c = o(() => {
		let i = e === "card" ? Lr(t, "picture") : e === "portrait" ? zr(50, 50, 46, n) : e === "dragon" ? Rr(r) : e === "bag" ? Br(50, 60, .9) : vr(t, 0, 0, 32, r);
		return (_r() + i).replaceAll("id=\"", `id="${s}-`).replaceAll("url(#", `url(#${s}-`);
	}, [
		e,
		t,
		n,
		r,
		s
	]);
	return /* @__PURE__ */ g("svg", {
		className: a,
		viewBox: e === "card" ? "0 0 240 240" : e === "dragon" ? "0 0 80 100" : e === "symbol" ? "0 0 32 32" : "0 0 100 100",
		"aria-hidden": "true",
		focusable: "false",
		dangerouslySetInnerHTML: { __html: c }
	});
}
function Hr({ kind: e, color: t }) {
	return /* @__PURE__ */ g(Vr, {
		art: "symbol",
		kind: e,
		color: t,
		className: "cc-icon"
	});
}
//#endregion
//#region src/games/clankcatacombs/art.tsx
function Ur({ kind: e, size: t = 44 }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 100 100",
		width: t,
		height: t,
		"aria-hidden": "true",
		children: /* @__PURE__ */ g("g", {
			stroke: "#33273f",
			strokeWidth: "4",
			strokeLinejoin: "round",
			children: e === "gem" ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("path", {
				d: "M12 35 30 16H70L88 35 50 88Z",
				fill: "#56b6d5"
			}), /* @__PURE__ */ g("path", {
				d: "M12 35H88M30 16 39 35 50 88 61 35 70 16M39 35 50 16 61 35",
				fill: "none",
				stroke: "#c6f4fb",
				strokeWidth: "3"
			})] }) : e === "monster" ? /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M17 27 4 7 38 23 65 19 93 6 81 34 90 55 69 86 30 83 12 56Z",
					fill: "#9ca39c"
				}),
				/* @__PURE__ */ g("path", {
					d: "m25 40 14 7-10 8m46-15-14 7 10 8M37 70l7-10 7 10 7-10 7 10",
					fill: "none"
				}),
				/* @__PURE__ */ g("path", {
					d: "M42 22 55 10 60 26",
					fill: "#cfb785"
				})
			] }) : e === "device" ? /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M22 85V26L50 10 78 26V85Z",
					fill: "#9283ae"
				}),
				/* @__PURE__ */ g("path", {
					d: "M35 84V42Q50 15 65 42V84",
					fill: "#382943"
				}),
				/* @__PURE__ */ g("path", {
					d: "M43 58H58V72H43Z",
					fill: "#e8c879"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "50",
					cy: "52",
					r: "7",
					fill: "none",
					stroke: "#e8c879"
				})
			] }) : e === "companion" ? /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M18 89 25 64 38 52 32 40 34 22 50 13 66 22 68 40 61 52 76 65 83 89Z",
					fill: "#829bb9"
				}),
				/* @__PURE__ */ g("path", {
					d: "M34 36 50 27 66 36 61 51 50 57 39 51Z",
					fill: "#ebc191"
				}),
				/* @__PURE__ */ g("path", {
					d: "M45 39H47M55 39H57",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ g("path", {
					d: "M50 58V87M22 78 78 66",
					stroke: "#daca93",
					strokeWidth: "7"
				})
			] }) : e === "tome" ? /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("path", {
					d: "M18 22 46 16 82 25V85L50 78 18 86Z",
					fill: "#c09159"
				}),
				/* @__PURE__ */ g("path", {
					d: "M50 24V77M24 32 43 28M25 44 42 40M58 35 75 39M58 47 75 51",
					stroke: "#f8e5ad"
				}),
				/* @__PURE__ */ g("path", {
					d: "m37 59 13-8 13 8-13 8Z",
					fill: "#d8e8d8"
				})
			] }) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("path", {
				d: "M21 83 30 44 17 35 24 18 42 25 50 9 58 25 77 18 83 35 70 44 79 83Z",
				fill: "#cfaa65"
			}), /* @__PURE__ */ g("path", {
				d: "M36 47Q50 65 64 47M41 36h1m16 0h1M35 75H65",
				fill: "none",
				strokeWidth: "6",
				strokeLinecap: "round"
			})] })
		})
	});
}
function Wr({ kind: e, compact: t = !1 }) {
	let n = d(), r = L[e], i = tr[e], a = [
		"burgle",
		"stumble",
		"sidestep",
		"scramble"
	].includes(e), o = [
		"explore",
		"mercenary",
		"tome"
	].includes(e), s = a ? "basicCard" : o ? "reserveCard" : r.type === "basic" ? "actionCard" : r.type;
	return /* @__PURE__ */ _("div", {
		className: "cc-card",
		"data-type": r.type,
		"data-starter": a,
		"data-compact": t,
		children: [
			/* @__PURE__ */ g("div", {
				className: "cc-card-picture",
				children: /* @__PURE__ */ g(Vr, {
					art: "card",
					kind: e
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "cc-card-name",
				children: [/* @__PURE__ */ g("span", { children: ir(e, n) }), r.points !== 0 && /* @__PURE__ */ g("b", {
					className: "cc-card-points",
					title: n(X.points, { n: r.points }),
					children: r.points
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: "cc-card-type",
				children: n(X[s])
			}),
			/* @__PURE__ */ g("div", {
				className: "cc-card-resources",
				children: [
					[
						"skill",
						r.skill,
						X.skill
					],
					[
						"sword",
						r.swords,
						X.swords
					],
					[
						"boot",
						r.boots,
						X.boots
					]
				].filter(([, e]) => e > 0).map(([e, t, r]) => /* @__PURE__ */ _("b", {
					"data-resource": e,
					title: `${n(r)} ${t}`,
					children: [/* @__PURE__ */ g(Hr, {
						kind: e,
						color: e === "skill" ? "#6ab5d6" : e === "sword" ? "#c87269" : "#d9bc78"
					}), /* @__PURE__ */ g("span", { children: t })]
				}, e))
			}),
			/* @__PURE__ */ _("div", {
				className: "cc-card-paper",
				children: [
					/* @__PURE__ */ g("div", {
						className: "cc-card-text",
						children: n(i.text) || /* @__PURE__ */ g("span", {
							className: "cc-card-watermark",
							"aria-hidden": "true",
							children: /* @__PURE__ */ g(Hr, { kind: r.tome ? "book" : a ? "key" : "compass" })
						})
					}),
					r.acquire.length > 0 && /* @__PURE__ */ g("div", {
						className: "cc-card-effect",
						children: n(X.acquireEffect, { text: n(i.acquire) })
					}),
					r.arrive.length > 0 && /* @__PURE__ */ g("div", {
						className: "cc-card-effect",
						children: n(X.arriveEffect, { text: n(i.arrive) })
					}),
					r.react && /* @__PURE__ */ g("div", {
						className: "cc-card-effect",
						children: n(X.reactEffect, { text: n(i.react) })
					})
				]
			}),
			/* @__PURE__ */ _("div", {
				className: "cc-card-foot",
				children: [/* @__PURE__ */ _("span", { children: [
					r.dragon && /* @__PURE__ */ g(Vr, { art: "dragon" }),
					r.danger && /* @__PURE__ */ g("span", {
						title: n(X.danger),
						children: "!"
					}),
					r.trophy && /* @__PURE__ */ g(Hr, { kind: "crown" })
				] }), /* @__PURE__ */ _("b", {
					title: `${n(r.type === "monster" ? X.swords : X.skill)} ${r.cost}`,
					children: [/* @__PURE__ */ g(Hr, {
						kind: r.type === "monster" ? "sword" : "skill",
						color: r.type === "monster" ? "#be776a" : "#77b9d8"
					}), /* @__PURE__ */ g("span", { children: r.cost })]
				})]
			})
		]
	});
}
//#endregion
//#region src/games/clankcatacombs/pawn-art.ts
function Gr(e, t = 1, n = 0, r = 0, i) {
	let a = [], o = -.25, s = .66, c = Math.sqrt(1 - s * s), l = .68, u = ([e, t, n]) => [(e * Math.cos(o) - t * Math.sin(o)) * l, (e * Math.sin(o) + t * Math.cos(o)) * s * l - n * c * l], d = (e) => u(e).map((e) => e.toFixed(2)).join(","), f = (e, t, n = "#161d2a") => "#" + [
		1,
		3,
		5
	].map((r) => Math.round(parseInt(e.slice(r, r + 2), 16) * (1 - t) + parseInt(n.slice(r, r + 2), 16) * t).toString(16).padStart(2, "0")).join(""), p = (e, t, n = 1) => {
		let r = e[0], s = e[1], c = e[2], l = s.map((e, t) => e - r[t]), u = c.map((e, t) => e - r[t]), p = [
			l[1] * u[2] - l[2] * u[1],
			l[2] * u[0] - l[0] * u[2],
			l[0] * u[1] - l[1] * u[0]
		], m = Math.hypot(...p), h = Math.max(0, (p[0] * -.6 + p[1] * -.4 + p[2] * .7) / (m || 1)), g = f(f(t, .24), h * .36, "#f6d9a3");
		i?.(e, g, n), a.push({
			depth: e.reduce((e, [t, n, r]) => e + t * Math.sin(o) + n * Math.cos(o) - r * .25, 0) / e.length,
			svg: `<polygon points="${e.map(d).join(" ")}" fill="${g}" stroke="${g}" stroke-width=".16" stroke-linejoin="round" opacity="${n}"/>`
		});
	}, m = (e, t, n, r, i, a, o) => {
		p([
			[
				e,
				t,
				n
			],
			[
				e + r,
				t,
				n
			],
			[
				e + r,
				t,
				n + a
			],
			[
				e,
				t,
				n + a
			]
		], o), p([
			[
				e + r,
				t,
				n
			],
			[
				e + r,
				t + i,
				n
			],
			[
				e + r,
				t + i,
				n + a
			],
			[
				e + r,
				t,
				n + a
			]
		], o), p([
			[
				e + r,
				t + i,
				n
			],
			[
				e,
				t + i,
				n
			],
			[
				e,
				t + i,
				n + a
			],
			[
				e + r,
				t + i,
				n + a
			]
		], o), p([
			[
				e,
				t + i,
				n
			],
			[
				e,
				t,
				n
			],
			[
				e,
				t,
				n + a
			],
			[
				e,
				t + i,
				n + a
			]
		], o), p([
			[
				e,
				t,
				n + a
			],
			[
				e + r,
				t,
				n + a
			],
			[
				e + r,
				t + i,
				n + a
			],
			[
				e,
				t + i,
				n + a
			]
		], o);
	}, h = (e, t, n, r, i, a = 12) => Array.from({ length: a }, (o, s) => [
		e + r * Math.cos(s / a * Math.PI * 2),
		t + i * Math.sin(s / a * Math.PI * 2),
		n
	]), g = (e, t, n, r, i = 10) => {
		let a = t.map((t, n) => t - e[n]), o = Math.hypot(...a), s = a.map((e) => e / o), c = Math.abs(s[2]) > .9 ? [
			1,
			0,
			0
		] : [
			0,
			0,
			1
		], l = [
			s[1] * c[2] - s[2] * c[1],
			s[2] * c[0] - s[0] * c[2],
			s[0] * c[1] - s[1] * c[0]
		], u = Math.hypot(...l);
		l = l.map((e) => e / u);
		let d = [
			s[1] * l[2] - s[2] * l[1],
			s[2] * l[0] - s[0] * l[2],
			s[0] * l[1] - s[1] * l[0]
		], f = (e, t) => e.map((e, r) => e + n * (l[r] * Math.cos(t / i * Math.PI * 2) + d[r] * Math.sin(t / i * Math.PI * 2)));
		for (let n = 0; n < i; n++) p([
			f(e, n),
			f(e, n + 1),
			f(t, n + 1),
			f(t, n)
		], r);
		p(Array.from({ length: i }, (e, n) => f(t, n)), r);
	}, _ = (e, t, n, r, i, a, o, s = 10) => {
		let c = [
			-.86,
			-.5,
			0,
			.5,
			.86
		].map((o) => h(e, t, n + o * a, r * Math.sqrt(1 - o * o), i * Math.sqrt(1 - o * o), s));
		for (let e = 0; e < c.length - 1; e++) for (let t = 0; t < s; t++) p([
			c[e][t],
			c[e][(t + 1) % s],
			c[e + 1][(t + 1) % s],
			c[e + 1][t]
		], o);
		p(c[c.length - 1], o);
	}, v = h(0, 0, 1, 20, 17, 20), y = h(0, 0, 5, 20, 17, 20);
	for (let t = 0; t < 20; t++) p([
		v[t],
		v[(t + 1) % 20],
		y[(t + 1) % 20],
		y[t]
	], f(e, .28));
	p(y, "#4a4843");
	let b = h(0, 0, 5.3, 19, 16, 20), x = h(0, 0, 5.3, 17.3, 14.3, 20);
	for (let t = 0; t < 20; t++) p([
		b[t],
		b[(t + 1) % 20],
		x[(t + 1) % 20],
		x[t]
	], e);
	let S = r * 3, C = -r * 3, w = Math.max(0, r) * 2, ee = Math.max(0, -r) * 2;
	m(-12, -5 + S, 5 + w, 9, 18, 10, "#69513b"), m(3, -4 + C, 5 + ee, 9, 18, 10, "#755c40"), m(-11, 7 + S, 10 + w, 7, 2, 2, "#b19b68"), m(4, 8 + C, 10 + ee, 7, 2, 2, "#b19b68"), g([
		-7,
		S,
		14 + w
	], [
		-8,
		-1,
		37
	], 5, "#424b50"), g([
		7,
		C,
		14 + ee
	], [
		8,
		-1,
		37
	], 5, "#48525a");
	let te = f(e, .34), T = [
		[
			-21,
			-6,
			20
		],
		[
			-16,
			-15,
			23
		],
		[
			0,
			-20,
			19
		],
		[
			18,
			-15,
			24
		],
		[
			22,
			-4,
			22
		],
		[
			14,
			4,
			26
		],
		[
			0,
			0,
			31
		],
		[
			-14,
			3,
			25
		]
	], E = [
		[
			-14,
			-5,
			60
		],
		[
			-11,
			-9,
			62
		],
		[
			0,
			-11,
			64
		],
		[
			12,
			-9,
			61
		],
		[
			15,
			-3,
			60
		],
		[
			11,
			4,
			56
		],
		[
			0,
			6,
			57
		],
		[
			-12,
			4,
			56
		]
	];
	for (let t = 0; t < 8; t++) p([
		T[t],
		T[(t + 1) % 8],
		E[(t + 1) % 8],
		E[t]
	], t % 3 == 0 ? e : te);
	m(-11, -2, 35, 22, 12, 24, e), m(-11, 10, 38, 22, 1.7, 4, "#70523a"), m(-2, 12, 37, 5, 2, 5, "#c3a86e"), p([
		[
			-9,
			11.8,
			59
		],
		[
			0,
			13,
			54
		],
		[
			0,
			13,
			43
		],
		[
			-10,
			11.8,
			47
		]
	], f(e, .05, "#d0ddda")), p([
		[
			1,
			13,
			54
		],
		[
			10,
			11.8,
			58
		],
		[
			10,
			11.8,
			46
		],
		[
			1,
			13,
			43
		]
	], f(e, .22)), g([
		-12,
		2,
		56
	], [
		-18,
		7,
		42
	], 5, e), g([
		-18,
		7,
		42
	], [
		-15,
		13,
		33
	], 4, "#856449"), g([
		12,
		2,
		56
	], [
		18,
		8,
		43
	], 5, e), g([
		18,
		8,
		43
	], [
		19,
		15,
		38
	], 4, "#856449"), _(-15, 13, 33, 3.5, 3.4, 4, "#d2a77d"), _(19, 15, 38, 3.5, 3.4, 4, "#d2a77d"), m(-13, -17, 39, 21, 9, 19, "#96734c"), m(-11, -18, 51, 17, 10, 7, "#b29366"), m(-9, -18.4, 39, 2.2, 1, 18, "#584b3d"), m(3, -18.4, 39, 2.2, 1, 18, "#584b3d"), g([
		-12,
		-15,
		60
	], [
		10,
		-15,
		60
	], 4, "#99927b");
	let D = f(e, .12, "#d7d3c0"), ne = f(e, .56, "#c9c8b9");
	g([
		0,
		1,
		59
	], [
		0,
		1,
		67
	], 5, D), _(0, -1, 73, 12.5, 10.5, 12.5, D, 16);
	let O = Array.from({ length: 20 }, (e, t) => {
		let n = t / 20 * Math.PI * 2;
		return [
			Math.cos(n) * 9.6,
			8.6,
			73 + Math.sin(n) * 10.5
		];
	}), k = Array.from({ length: 20 }, (e, t) => {
		let n = t / 20 * Math.PI * 2;
		return [
			Math.cos(n) * 8.3,
			11,
			73 + Math.sin(n) * 9.1
		];
	});
	for (let e = 0; e < 20; e++) p([
		O[e],
		O[(e + 1) % 20],
		k[(e + 1) % 20],
		k[e]
	], f(D, .1, "#eee1ba"));
	p(k, ne), p([
		[
			-9,
			11.8,
			57
		],
		[
			-7,
			12.1,
			58
		],
		[
			9,
			12.1,
			43
		],
		[
			7,
			12.5,
			41
		]
	], "#a38b5b");
	for (let e of [
		49,
		53,
		57
	]) _(0, 12.5, e, .6, .5, .6, "#c0aa78");
	n % 3 == 2 ? (g([
		19,
		14,
		8
	], [
		19,
		14,
		71
	], 1.7, "#8a6848", 8), _(19, 14, 75, 4.5, 4, 6, "#b8c8b2"), g([
		19,
		14,
		68
	], [
		19,
		14,
		71
	], 3, "#c3a668", 8)) : (g([
		20,
		14,
		32
	], [
		20,
		14,
		46
	], 2.2, "#574536", 8), m(14, 13, 43, 12, 2, 2, "#bd9b57"), p([
		[
			19,
			14,
			46
		],
		[
			21,
			14,
			46
		],
		[
			23,
			14,
			70
		],
		[
			20,
			14,
			79
		],
		[
			18,
			14,
			69
		]
	], "#c1d0ca"), p([
		[
			20,
			14.5,
			47
		],
		[
			21,
			14.5,
			70
		],
		[
			20,
			14.5,
			79
		],
		[
			20,
			14.5,
			56
		]
	], "#e2deba")), a.sort((e, t) => e.depth - t.depth);
	let [A, re] = u([
		0,
		17,
		4
	]);
	return "<ellipse cx=\"3\" cy=\"3\" rx=\"17\" ry=\"8\" fill=\"#02060b\" opacity=\".48\"/>" + a.map((e) => e.svg).join("") + `<text x="${A.toFixed(2)}" y="${(re + 1).toFixed(2)}" font-family="Arial,sans-serif" font-size="6.5" text-anchor="middle" fill="#f1d7a2" stroke="#252331" stroke-width="1.5" paint-order="stroke" font-weight="700">${t}</text>`;
}
function Kr(e) {
	return e <= 3 ? Array.from({ length: e }, (t, n) => [(n - (e - 1) / 2) * 24, Math.abs(n - (e - 1) / 2) * 4]) : [
		[-23, -13],
		[1, -20],
		[25, -11],
		[-25, 16],
		[0, 23],
		[25, 16]
	].slice(0, e);
}
//#endregion
//#region src/games/clankcatacombs/map-icons.ts
var qr = "#101820", Jr = "#fff0cc", Q = (e, t, n = qr, r = 1.6) => `<path d="${e}" fill="${t}" stroke="${n}" stroke-width="${r}" stroke-linecap="round" stroke-linejoin="round"/>`, $ = (e, t, n = 1.6) => Q(e, "none", t, n), Yr = (e, t, n, r, i = qr, a = 1.6) => `<circle cx="${e}" cy="${t}" r="${n}" fill="${r}" stroke="${i}" stroke-width="${a}"/>`, Xr = (e, t, n, r, i = Jr) => `<text x="${e}" y="${t}" text-anchor="middle" font-size="${r}" font-weight="800" fill="${i}" font-family="Microsoft YaHei,Segoe UI,sans-serif">${n}</text>`;
function Zr(e) {
	return `<defs>${Object.entries({
		gold: ["#ffe5a6", "#a87c3c"],
		iron: ["#e1eeec", "#6f929e"],
		red: ["#e28d7f", "#934b53"],
		leather: ["#e7c188", "#9d713e"],
		gem: ["#d3c7ff", "#7764b6"],
		green: ["#c4dccb", "#6b958d"],
		paper: ["#fff0cb", "#c5a16b"],
		steel: ["#657d8b", "#243947"]
	}).map(([t, [n, r]]) => `<linearGradient id="${e}-${t}" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="${n}"/><stop offset="1" stop-color="${r}"/></linearGradient>`).join("")}</defs>`;
}
function Qr(e, t, n, r, i, a = {}) {
	let o = (e) => `url(#${i}-${e})`, s = "";
	switch (e) {
		case "monster":
			s = Q("M12 17 5 14 3 4 17 10M36 17 43 14 45 4 31 10", o("gold")) + Q("M12 10 24 6 36 10 42 24 35 39 24 44 13 39 6 24Z", o("red")) + Q("M10 17 21 21 18 28 11 25ZM38 17 27 21 30 28 37 25Z", qr, "#f5b69a", .8) + Q("M13 31 24 34 35 31 32 38 24 41 16 38Z", "#422d38") + Q("M17 32 18 37 21 34M27 34 30 37 31 32", Jr, Jr, .7) + $("M14 12 22 9M10 27 13 31", "#ffd5ad", 1.5);
			break;
		case "boot":
			s = Q("M12 5H33L31 24 42 30 44 39 39 43H6L5 35 13 27Z", o("leather")) + Q("M11 5H34L33 12H11Z", o("gold")) + Q("M7 37H43V42H6Z", "#4b3a32") + $("M19 17H29M18 23H27M17 29H25", "#5b4431", 2.6) + Q("M27 14H32V20H26Z", o("gold"), "#694f35", 1) + $("M15 14 16 26 9 34M31 28 39 33", "#ffe3af", 1.7);
			break;
		case "lock":
			s = (a.open ? $("M18 24V12C18 1 36 1 36 12V15", "#172630", 10) + $("M18 24V12C18 1 36 1 36 12V15", "#c6d5d2", 6) : $("M13 24V15C13 1 35 1 35 15V24", "#172630", 10) + $("M13 24V15C13 1 35 1 35 15V24", "#c6d5d2", 6)) + Q("M9 21H39V40L34 45H14L9 40Z", o("gold")) + $("M12 24H36M12 26V38", "#fff1c5", 1.2) + Yr(24, 31, 3.4, qr, qr, 1) + Q("M22 32H26L27 39H21Z", qr, qr, 1);
			break;
		case "toll":
			s = Yr(24, 24, 21, o("iron")) + Yr(24, 24, 16, "#536f83", "#e3e7dd", 1.2) + Q("M14 17 19 12H29L34 17V27L29 31V36H19V31L14 27Z", "#e8e9db") + Q("M17 21 22 22 20 26 17 25ZM31 21 26 22 28 26 31 25Z", qr, qr, .5) + $("M22 32V35M26 32V35", "#52697a", 1.5) + $("M12 9 18 6M5 23V19", "#fff6d7", 1.5);
			break;
		case "barrier":
			s = Q("M14 5H34L43 18 24 44 5 18Z", o("gem")) + $("M14 5 18 18 24 44 30 18 34 5M5 18H43", "#efe2ff", 1.3) + Yr(24, 24, 21, "none", "#111e29", 6) + Yr(24, 24, 21, "none", "#dda18a", 3) + $("M9 39 39 9", "#17202b", 7) + $("M9 39 39 9", "#efb19a", 3.8);
			break;
		case "secret":
			s = Q("M14 4 24 8 34 4 31 15H17Z", o("paper")) + Q("M16 15C15 21 5 25 6 36Q7 45 24 45T42 36C43 25 33 21 32 15Z", o("leather")) + $("M16 15H32M15 18H33", "#4d4438", 3) + $("M16 23Q10 28 10 35M32 22Q37 27 38 32", "#f8db9e", 1.5) + Q("M22 16 26 22 32 18", o("gold")) + Xr(24, 38, "?", 23, "#3f302b");
			break;
		case "artifact":
			s = Q("M14 3H34L46 18 24 46 2 18Z", o("gold")) + Q("M15 7H33L41 18 24 40 7 18Z", o("gem")) + Q("M15 7 20 18 24 40 7 18Z", "#a8bbe0", "none") + Q("M15 7 33 7 29 18 20 18Z", "#e0d9ff", "none") + $("M7 18H41M15 7 20 18 24 40 29 18 33 7", "#f2e5ff", 1.2) + Q("M11 13 15 9 17 14 13 18Z", "#fff9e3", "none");
			break;
		case "idol":
			s = Yr(9, 23, 7, o("gold")) + Yr(39, 23, 7, o("gold")) + Q("M13 8 24 3 35 8 38 26 34 39 24 45 14 39 10 26Z", o("gold")) + Q("M14 18Q18 10 24 19 30 10 34 18L32 29H16Z", "#6a5637") + Yr(19, 22, 2, "#fff0bc", "none") + Yr(29, 22, 2, "#fff0bc", "none") + Q("M15 31Q24 25 33 31V37Q24 43 15 37Z", "#f2d28b", "#9a7640", 1) + $("M19 35Q24 38 29 35M16 10 23 7", "#fff0be", 1.4);
			break;
		case "heart":
			s = Q("M24 44 6 26C-5 12 11-1 24 11 37-1 53 12 42 26Z", o("red")) + $("M8 20Q4 11 13 8M13 8Q17 8 19 11", "#ffdcc5", 2.3) + Q("M24 38 39 24Q43 18 40 14L36 26Z", "#a75261", "none");
			break;
		case "library":
			s = Q("M3 12 20 7 24 11 28 7 45 12V42L27 38 24 42 21 38 3 42Z", o("leather")) + Q("M5 7Q15 3 24 9 33 3 43 7V36Q33 32 24 38 15 32 5 36Z", o("paper")) + $("M24 10V36", "#9c774b", 1.6) + $("M9 13Q14 11 19 14M9 19Q14 17 19 20M9 25Q14 23 19 26M29 14Q34 11 39 13M29 20Q34 17 39 19", "#b18b54", 1.2) + Q("M32 6 37 6V28L34.5 25 32 28Z", "#a55452", "#6b3e3c", .6) + $("M7 8Q16 6 22 10", "#fff8e2", 1.4);
			break;
		case "prison":
			s = Q("M5 11 24 3 43 11V44H5Z", o("steel")) + (a.open ? "" : Yr(24, 19, 5, "#d8c8a4", "#10212b", 1) + Q("M16 37V29Q24 22 32 29V37Z", "#8ea6a6")) + Q("M6 11H42V16H6ZM6 38H42V43H6Z", o("iron")) + $(a.open ? "M12 16V38M35 16V38" : "M13 16V38M24 16V38M35 16V38", "#101f29", 5) + $(a.open ? "M12 16V38M35 16V38" : "M13 16V38M24 16V38M35 16V38", "#c4d6d6", 2.5) + (a.open ? Q("M35 16 46 11V35L35 38Z", o("iron")) + $("M40 17V32", "#3a5663", 2) : Q("M31 26H40V34H31Z", o("gold")));
			break;
		case "market":
			s = Q("M17 41H31L35 45H13Z", o("gold")) + $("M24 40V7", "#101d25", 6) + $("M24 40V7", "#dfc88c", 3) + Yr(24, 6, 3, o("gold")) + $("M7 14H41", "#10212a", 5) + $("M7 14H41", "#f1d99c", 2.5) + $("M8 15 2 28M8 15 15 28M40 15 33 28M40 15 46 28", "#bda477", 1.5) + Q("M2 28H15Q13 39 5 34Z", o("gold")) + Q("M33 28H46Q44 39 36 34Z", o("gold")) + $("M4 29H13M35 29H44", "#fff0bc", 1);
			break;
		case "shrine": s = Q("M8 37H40L44 44H4Z", o("gold")) + Q("M15 33V11L24 3 33 11V33Z", o("iron")) + Q("M24 3 33 11V33H24Z", "#66818b", "none") + Q("M16 34H32L36 38H12Z", o("paper")) + Q("M24 12 29 21 24 30 19 21Z", "#c4a8e1", "#293a4e", 1) + $("M24 16 26 21 24 25M18 11V29", "#f0e0ef", 1.4);
	}
	let c = a.count, l = "";
	if (c !== void 0) {
		let e = String(c), t = 36 + (e.length > 1 ? 32 : 23);
		l = Q(`M36 22H${t - 3}L${t} 25V45H36Z`, "#14202c", "#ad9c7b", 1.3) + Xr((36 + t) / 2, 41, e, e.length > 1 ? 21 : 23);
	}
	return `<g transform="translate(${t - r / 2} ${n - r / 2}) scale(${r / 48})"${a.muted ? " opacity=\".35\"" : ""}>${s}${l}</g>`;
}
//#endregion
//#region src/games/clankcatacombs/scene.ts
var $r = "#302f40", ei = (e) => Math.round(e * 100) / 100, ti = (e, t, n, r, i = "none", a = 1) => `<circle cx="${ei(e)}" cy="${ei(t)}" r="${ei(n)}" fill="${r}" stroke="${i}" stroke-width="${a}"/>`, ni = (e, t, n, r, i, a = 0, o = "none", s = 1) => `<rect x="${ei(e)}" y="${ei(t)}" width="${ei(n)}" height="${ei(r)}" rx="${a}" fill="${i}" stroke="${o}" stroke-width="${s}"/>`;
function ri(e) {
	let t = e.features;
	return t.includes("cave") ? {
		kind: "cave",
		base: "#204b63",
		rim: "#4f7e91",
		stones: [
			"#538fa5",
			"#679fb0",
			"#45859e",
			"#77adb8"
		]
	} : t.includes("prison") || t.includes("prison3") ? {
		kind: "prison",
		base: "#303f55",
		rim: "#698397",
		stones: [
			"#7893ab",
			"#6b849f",
			"#8ca2b5",
			"#5d7996"
		]
	} : t.includes("library") ? {
		kind: "library",
		base: "#57402c",
		rim: "#a28150",
		stones: [
			"#b19770",
			"#bba079",
			"#9d825d",
			"#c4a77c"
		]
	} : t.includes("wayshrine") ? {
		kind: "shrine",
		base: "#866326",
		rim: "#c4a64b",
		stones: [
			"#c3a150",
			"#d6b867",
			"#b58c3f",
			"#e0c77c"
		]
	} : t.includes("market") ? {
		kind: "market",
		base: "#703c35",
		rim: "#bd7e62",
		stones: [
			"#ba7965",
			"#cd8a70",
			"#a9695c",
			"#d0927a"
		]
	} : t.some((e) => e.startsWith("artifact")) ? {
		kind: "artifact",
		base: "#3f335e",
		rim: "#8c7bb0",
		stones: [
			"#9784b4",
			"#a995c6",
			"#8275a4",
			"#b4a1ca"
		]
	} : (Number(e.tileKind) + e.id.charCodeAt(0)) % 3 == 1 ? {
		kind: "rubble",
		base: "#354d43",
		rim: "#718c72",
		stones: [
			"#779681",
			"#89a58c",
			"#668a78",
			"#9aad93"
		]
	} : {
		kind: "stone",
		base: "#786c59",
		rim: "#a49476",
		stones: [
			"#c1b195",
			"#cab89d",
			"#b6a78d",
			"#c8b899"
		]
	};
}
var ii = /* @__PURE__ */ new WeakMap(), ai = /* @__PURE__ */ new WeakMap();
function oi(e) {
	return e.tileKind === "266" || e.tileKind === "267" && e.id === "b";
}
function si(e, t = 0) {
	let n = ii.get(e);
	if (!n) {
		let t = ri(e).kind;
		n = t === "cave" ? Array.from({ length: 18 }, (e, t) => {
			let n = t / 18 * Math.PI * 2, r = 1 + [
				.01,
				-.055,
				.02,
				.035,
				-.025,
				.01
			][t % 6];
			return [Math.cos(n) * .192 * r, Math.sin(n) * .171 * r];
		}) : t === "shrine" ? [
			[-.08, -.18],
			[.08, -.18],
			[.08, -.11],
			[.19, -.11],
			[.19, .08],
			[.11, .08],
			[.11, .17],
			[-.11, .17],
			[-.11, .08],
			[-.19, .08],
			[-.19, -.11],
			[-.08, -.11]
		] : t === "prison" ? [
			[-.205, -.13],
			[.17, -.13],
			[.205, -.095],
			[.205, .13],
			[-.17, .13],
			[-.205, .095]
		] : t === "library" ? [
			[-.18, -.175],
			[.18, -.175],
			[.18, .11],
			[.135, .16],
			[-.135, .16],
			[-.18, .11]
		] : t === "artifact" ? [
			[-.1, -.178],
			[.1, -.178],
			[.195, -.08],
			[.195, .08],
			[.1, .178],
			[-.1, .178],
			[-.195, .08],
			[-.195, -.08]
		] : t === "market" ? [
			[-.19, -.17],
			[.15, -.17],
			[.19, -.13],
			[.19, .17],
			[-.19, .17]
		] : t === "rubble" ? [
			[-.195, -.12],
			[-.12, -.17],
			[.17, -.17],
			[.19, -.03],
			[.165, .16],
			[-.12, .17],
			[-.195, .1]
		] : [
			[-.17, -.16],
			[.17, -.16],
			[.19, -.14],
			[.19, .14],
			[.17, .16],
			[-.17, .16],
			[-.19, .14],
			[-.19, -.14]
		], e.id === "crypt" && (n = n.map(([e, t]) => [e * 1.1, t * .95])), n = n.map(([t, n]) => [t * e.size, n * e.size]), ii.set(e, n);
	}
	let r = 1 - t / (.17 * e.size);
	return n.map(([t, n]) => [e.x + t * r, e.y + n * r]);
}
function ci(e, t, n) {
	let r = ai.get(e);
	r || (r = si(e), ai.set(e, r));
	let i = !1, a = 1e6;
	for (let e = 0, o = r.length - 1; e < r.length; o = e++) {
		let s = r[e], c = r[o];
		s[1] > n != c[1] > n && t < (c[0] - s[0]) * (n - s[1]) / (c[1] - s[1]) + s[0] && (i = !i);
		let l = c[0] - s[0], u = c[1] - s[1], d = Math.max(0, Math.min(1, ((t - s[0]) * l + (n - s[1]) * u) / (l * l + u * u))), f = t - s[0] - d * l, p = n - s[1] - d * u;
		a = Math.min(a, f * f + p * p);
	}
	let o = Math.sqrt(a);
	return i ? o : -o;
}
function li(e) {
	let t = e.tiles, n = t.find((e) => e.kind.startsWith("uw-center")), r = (e, t) => {
		if (e.zone === "underworld") return xe(e, t[0], t[1], n);
		let r = we[e.kind].height === 1 ? Te(t[0], t[1], e.rotation) : t;
		return [e.x + r[0], e.y + r[1]];
	}, i = bt({
		tiles: t,
		openedLocks: e.openedLocks
	}), a = (e) => {
		let t = i.get(e);
		if (t) return t.underworld ? xe({
			...n,
			slot: t.underworld.slot
		}, ...De(we["uw-8c398a"], t.local), n) : r(t.tile, De(we[t.tile.kind], t.local));
	}, o = t.flatMap((t, n) => we[t.kind].rooms.map((i) => {
		let a = r(t, [i.x, i.y]), o = B(t.id, i.id);
		return {
			...i,
			tileKind: t.kind,
			x: a[0],
			y: a[1],
			key: o,
			ti: n,
			state: e.rooms.find((e) => e.id === o)
		};
	})), s = o.map((e) => ({
		...e,
		size: Math.max(.55, Math.min(1, ...o.filter((t) => t.key !== e.key).map((t) => Math.hypot(e.x - t.x, e.y - t.y) / .41)))
	})), c = t.flatMap((t, n) => we[t.kind].passages.map((i, a) => ({
		a: r(t, De(we[t.kind], i.a)),
		b: r(t, De(we[t.kind], i.b)),
		ka: B(t.id, i.a),
		kb: B(t.id, i.b),
		ti: n,
		pass: {
			...i,
			lock: i.lock && !e.openedLocks.includes(t.id + ":" + a)
		},
		gaps: []
	})));
	for (let [e, t] of i) for (let n of t.links) {
		if (!n.id.startsWith("uw:") || e >= n.to) continue;
		let t = a(e), r = a(n.to);
		!t || !r || Math.hypot(t[0] - r[0], t[1] - r[1]) < .001 || c.push({
			a: t,
			b: r,
			ka: e,
			kb: n.to,
			ti: -1,
			pass: {
				a: e,
				b: n.to,
				monsters: 0,
				extraBoots: 0,
				lock: !1,
				oneWay: !1,
				barrier: !1,
				toll: 0,
				entry: !1
			},
			gaps: []
		});
	}
	let l = (e, t) => e[0] * t[1] - e[1] * t[0], u = (e, t) => [e[0] - t[0], e[1] - t[1]], d = (e, t, n) => [e[0] + (t[0] - e[0]) * n, e[1] + (t[1] - e[1]) * n];
	function f(e, t, n) {
		let r = n[0] - t[0], i = n[1] - t[1], a = Math.max(0, Math.min(1, ((e[0] - t[0]) * r + (e[1] - t[1]) * i) / (r * r + i * i)));
		return Math.hypot(e[0] - t[0] - a * r, e[1] - t[1] - a * i);
	}
	let p = [];
	for (let e = 0; e < c.length; e++) for (let t = e + 1; t < c.length; t++) {
		let n = c[e], r = c[t];
		if ([n.ka, n.kb].some((e) => e === r.ka || e === r.kb)) continue;
		let i = u(n.b, n.a), a = u(r.b, r.a), o = l(i, a);
		if (Math.abs(o) < 1e-7) continue;
		let f = u(r.a, n.a), m = l(f, a) / o, h = l(f, i) / o;
		if (m < .08 || m > .92 || h < .08 || h > .92) continue;
		let g = d(n.a, n.b, m);
		if (s.some((e) => Math.hypot(e.x - g[0], e.y - g[1]) < .15)) continue;
		let _ = Math.hypot(a[0], a[1]), v = Math.min(.17 / _, h - .02, .98 - h);
		v < .06 || (r.gaps.push([h - v, h + v]), p.push({
			edge: r,
			t: h,
			half: v,
			cross: g
		}));
	}
	let m = [];
	for (let e of c) {
		let t = e.gaps.sort((e, t) => e[0] - t[0]), n = 0;
		for (let [r, i] of t) r > n && m.push({
			a: d(e.a, e.b, n),
			b: d(e.a, e.b, r)
		}), n = Math.max(n, i);
		n < 1 && m.push({
			a: d(e.a, e.b, n),
			b: e.b
		});
	}
	let h = [];
	for (let [e, t] of i) {
		if (!t.frontier && !t.underworld) continue;
		let r = a(e);
		if (!r) continue;
		let i;
		if (t.frontier) {
			let e = Ee(t.local.replace(/[23]$/, (e) => String(e - 2)), t.tile.rotation);
			i = e[0] === "N" ? [0, 1] : e[0] === "S" ? [0, -1] : e[0] === "W" ? [1, 0] : [-1, 0];
		} else {
			let e = t.links.map((e) => a(e.to)).find((e) => e && Math.hypot(e[0] - r[0], e[1] - r[1]) > .001);
			if (e) {
				let t = [e[0] - r[0], e[1] - r[1]], n = Math.hypot(...t);
				i = [t[0] / n, t[1] / n];
			} else {
				let e = xe({
					...n,
					slot: t.underworld.slot
				}, .5, -.12, n), a = Math.hypot(e[0] - r[0], e[1] - r[1]);
				i = [(e[0] - r[0]) / a, (e[1] - r[1]) / a];
			}
		}
		h.some((e) => Math.hypot(e.p[0] - r[0], e.p[1] - r[1]) < .001) || h.push({
			key: e,
			p: r,
			inward: i
		});
	}
	let g = (e) => {
		let t = c.filter((t) => t.ka === e.key || t.kb === e.key), n = [
			[-.13, -.095],
			[.13, -.095],
			[-.13, .095],
			[.13, .095]
		].map(([t, n]) => [t * e.size, n * e.size]);
		return n.sort((n, r) => Math.min(...t.map((t) => f([e.x + r[0], e.y + r[1]], t.a, t.b))) - Math.min(...t.map((t) => f([e.x + n[0], e.y + n[1]], t.a, t.b)))), [e.x + n[0][0], e.y + n[0][1]];
	}, _ = [...m, ...h.map(({ p: e, inward: t }) => ({
		a: e,
		b: [e[0] - t[0] * .26, e[1] - t[1] * .26]
	}))].map((e) => ({
		...e,
		dx: e.b[0] - e.a[0],
		dy: e.b[1] - e.a[1],
		len: Math.hypot(e.b[0] - e.a[0], e.b[1] - e.a[1])
	})), v = /* @__PURE__ */ new Map();
	function y(e, t, n, r, i) {
		for (let a = Math.floor(t / .35); a <= Math.floor(r / .35); a++) for (let t = Math.floor(e / .35); t <= Math.floor(n / .35); t++) {
			let e = t + "," + a, n = v.get(e) ?? {
				rooms: [],
				corridors: []
			};
			i(n), v.set(e, n);
		}
	}
	for (let e of s) y(e.x - .21, e.y - .18, e.x + .21, e.y + .18, (t) => t.rooms.push(e));
	for (let e of _) y(Math.min(e.a[0], e.b[0]) - .055, Math.min(e.a[1], e.b[1]) - .055, Math.max(e.a[0], e.b[0]) + .055, Math.max(e.a[1], e.b[1]) + .055, (t) => t.corridors.push(e));
	function b(e, t) {
		let n = -1e6, r = v.get(Math.floor(e / .35) + "," + Math.floor(t / .35));
		if (!r) return n;
		for (let i of r.rooms) n = Math.max(n, ci(i, e, t));
		for (let i of r.corridors) {
			let { dx: r, dy: a, len: o } = i, s = ((e - i.a[0]) * r + (t - i.a[1]) * a) / o, c = Math.abs((e - i.a[0]) * a - (t - i.a[1]) * r) / o;
			n = Math.max(n, Math.min(.052 - c, s, o - s));
		}
		return n;
	}
	let x = [...s.map((e) => [e.x, e.y]), ..._.flatMap((e) => [e.a, e.b])], S = .015, C = Math.min(...x.map((e) => e[0])) - .25 - 137e-6, w = Math.min(...x.map((e) => e[1])) - .25 - 219e-6, ee = Math.ceil((Math.max(...x.map((e) => e[0])) + .25 - C) / S), te = Math.ceil((Math.max(...x.map((e) => e[1])) + .25 - w) / S), T = Array.from({ length: te + 1 }, (e, t) => Array.from({ length: ee + 1 }, (e, n) => b(C + n * S, w + t * S))), E = [], D = {
		1: [[3, 0]],
		2: [[0, 1]],
		3: [[3, 1]],
		4: [[1, 2]],
		5: [[3, 0], [1, 2]],
		6: [[0, 2]],
		7: [[3, 2]],
		8: [[2, 3]],
		9: [[2, 0]],
		10: [[0, 1], [2, 3]],
		11: [[2, 1]],
		12: [[1, 3]],
		13: [[1, 0]],
		14: [[0, 3]]
	};
	for (let e = 0; e < te; e++) for (let t = 0; t < ee; t++) {
		let n = T[e][t], r = T[e][t + 1], i = T[e + 1][t + 1], a = T[e + 1][t], o = +(n > 0) + (r > 0 ? 2 : 0) + (i > 0 ? 4 : 0) + (a > 0 ? 8 : 0);
		if (!D[o]) continue;
		let s = C + t * S, c = w + e * S, l = [
			n,
			r,
			i,
			a
		], u = [
			[s, c],
			[s + S, c],
			[s + S, c + S],
			[s, c + S]
		], f = (e) => {
			let t = e, n = (e + 1) % 4, r = l[t] / (l[t] - l[n]);
			return d(u[t], u[n], r);
		};
		for (let [e, t] of D[o]) E.push([f(e), f(t)]);
	}
	let ne = (e) => `${Math.round(e[0] * 1e6)},${Math.round(e[1] * 1e6)}`, O = /* @__PURE__ */ new Map();
	for (let [e, t] of E) {
		let n = ne(e), r = ne(t);
		O.has(n) || O.set(n, {
			p: e,
			ns: []
		}), O.has(r) || O.set(r, {
			p: t,
			ns: []
		}), O.get(n).ns.push(r), O.get(r).ns.push(n);
	}
	let k = /* @__PURE__ */ new Set(), A = [];
	for (let e of O.keys()) {
		if (k.has(e)) continue;
		let t = [], n = e, r = "";
		for (let i = 0; i < 1e5 && !k.has(n); i++) {
			k.add(n);
			let i = O.get(n);
			t.push(i.p);
			let a = i.ns.find((e) => e !== r && !k.has(e)) ?? i.ns.find((t) => t === e);
			if (!a) break;
			r = n, n = a;
		}
		t.length > 3 && A.push(t);
	}
	function re(e, t = .0016) {
		if (e.length < 3) return e;
		let n = 0, r = 0;
		for (let t = 1; t < e.length - 1; t++) {
			let i = f(e[t], e[0], e[e.length - 1]);
			i > n && (n = i, r = t);
		}
		return n <= t ? [e[0], e[e.length - 1]] : [...re(e.slice(0, r + 1), t).slice(0, -1), ...re(e.slice(r), t)];
	}
	let ie = A.map((e) => {
		let t = Math.floor(e.length / 2);
		return [...re(e.slice(0, t + 1)).slice(0, -1), ...re([...e.slice(t), e[0]]).slice(0, -1)];
	}), ae = ie.flatMap((e) => e.map((t, n) => [t, e[(n + 1) % e.length]]));
	function oe(n = "3d") {
		let o = e.id, l = s.flatMap((e) => [-.22, .22].flatMap((t) => [-.2, .2].flatMap((n) => [0, .14].map((r) => [
			e.x + t,
			e.y + n,
			r
		])))).concat(_.flatMap((e) => [[...e.a, 0], [...e.b, .06]])), m = e.camera?.center[0] ?? (Math.min(...l.map((e) => e[0])) + Math.max(...l.map((e) => e[0]))) / 2, v = e.camera?.center[1] ?? (Math.min(...l.map((e) => e[1])) + Math.max(...l.map((e) => e[1]))) / 2, y = Math.max(...l.map((e) => e[0])) - Math.min(...l.map((e) => e[0])), x = e.camera?.perspective ?? .12 / Math.max(1, y / 3), S = n === "25d" ? .85 : .66, C = n === "25d" ? -.1 : -.25, w = Math.sqrt(1 - S * S), ee = ([e, t, r]) => {
			e -= m, t -= v;
			let i = e * Math.cos(C) - t * Math.sin(C), a = e * Math.sin(C) + t * Math.cos(C), o = n === "3d" ? 1 / (1 - a * x - r * .04) : 1;
			return [
				i * o,
				(a * S - r * w) * o,
				a - r * .25
			];
		}, te = l.map(ee), T = Math.min(...te.map((e) => e[0])), E = Math.max(...te.map((e) => e[0])), D = Math.min(...te.map((e) => e[1])), ne = Math.max(...te.map((e) => e[1])), O = (E - T + .16) * 300, k = (ne - D + .16) * 300, A = e.camera?.scale ?? Math.min(O / (E - T + .12), k / (ne - D + .15)), re = 0 + O / 2 + 0, oe = 0 + k / 2 - 8, se = e.camera ?? {
			perspective: x,
			scale: A,
			center: [m, v],
			origin: [(T + E) / 2, (D + ne) / 2],
			offset: [re, oe],
			width: O,
			height: k
		}, j = (e) => {
			let t = ee(e);
			return [se.offset[0] + (t[0] - se.origin[0]) * se.scale, se.offset[1] + (t[1] - se.origin[1]) * se.scale];
		}, M = {}, ce = /* @__PURE__ */ new Set([
			"#f4c26a",
			"#fff0b6",
			"#ffdb8a"
		]), le = {
			cave: {
				ambient: [
					.13,
					.3,
					.38
				],
				torch: .22
			},
			prison: {
				ambient: [
					.23,
					.34,
					.49
				],
				torch: .28
			},
			library: {
				ambient: [
					.3,
					.21,
					.12
				],
				torch: .65
			},
			market: {
				ambient: [
					.36,
					.18,
					.15
				],
				torch: .6
			},
			shrine: {
				ambient: [
					.32,
					.26,
					.12
				],
				torch: .32
			},
			artifact: {
				ambient: [
					.28,
					.23,
					.44
				],
				torch: .2
			},
			stone: {
				ambient: [
					.15,
					.17,
					.21
				],
				torch: .94
			},
			rubble: {
				ambient: [
					.17,
					.31,
					.23
				],
				torch: .38
			}
		};
		function ue(e) {
			let t = c.filter((t) => t.ka === e.key || t.kb === e.key), n = [
				[-.11, -.095],
				[.11, -.095],
				[-.11, .095],
				[.11, .095]
			].map(([t, n]) => [t * e.size, n * e.size]);
			n.sort((n, r) => Math.min(...t.map((t) => f([e.x + r[0], e.y + r[1]], t.a, t.b))) - Math.min(...t.map((t) => f([e.x + n[0], e.y + n[1]], t.a, t.b))));
			let [r, i] = n[0];
			return {
				ax: r,
				ay: i,
				x: e.x + r * .88,
				y: e.y + i * .88
			};
		}
		let N = {
			cave: {
				ambient: [
					.44,
					.49,
					.53
				],
				torch: .25
			},
			prison: {
				ambient: [
					.48,
					.51,
					.55
				],
				torch: .35
			},
			library: {
				ambient: [
					.53,
					.49,
					.43
				],
				torch: .38
			},
			market: {
				ambient: [
					.53,
					.48,
					.44
				],
				torch: .32
			}
		}, P = s.map((e) => ({
			r: e,
			kind: ri(e).kind,
			style: (oi(e) ? N : le)[ri(e).kind]
		})), F = [];
		for (let { r: e, kind: t, style: n } of P) {
			let r = ue(e);
			if (oi(e)) {
				let r = (t, n) => [e.x + t * e.size, e.y + n * e.size];
				if (F.push({
					p: g(e),
					radius: .19,
					power: .62 * n.torch,
					color: [
						1.08,
						.94,
						.74
					],
					pool: "#f7ce92",
					alpha: .025,
					halo: 0
				}), t === "cave") for (let e of [[.12, -.075], [.137, .073]]) F.push({
					p: r(e[0], e[1]),
					radius: .14,
					power: .38,
					color: [
						.54,
						.82,
						.94
					],
					pool: "#96d7df",
					alpha: .025,
					halo: 0
				});
				if (t === "prison" && F.push({
					p: r(.125, -.093),
					radius: .15,
					power: .38,
					color: [
						1.06,
						.93,
						.72
					],
					pool: "#eacb91",
					alpha: .025,
					halo: .011
				}), t === "library" && F.push({
					p: r(.148, .103),
					radius: .15,
					power: .54,
					color: [
						1.08,
						.96,
						.77
					],
					pool: "#efcf9c",
					alpha: .03,
					halo: .01
				}), t === "market") for (let e of [[-.075, -.073], [.153, -.074]]) F.push({
					p: r(e[0], e[1]),
					radius: .14,
					power: .44,
					color: [
						1.06,
						.95,
						.78
					],
					pool: "#f0cd98",
					alpha: .025,
					halo: .011
				});
				continue;
			}
			if (F.push({
				p: g(e),
				radius: .4,
				power: .94 * n.torch,
				color: [
					1.14,
					.82,
					.43
				],
				pool: "#ffc57c",
				alpha: .1 * n.torch,
				halo: 0
			}), t === "cave") {
				let t = c.filter((t) => t.ka === e.key || t.kb === e.key);
				for (let [n, r] of si(e, .025 * e.size).entries()) n % 2 || t.some((e) => f(r, e.a, e.b) < .07) || F.push({
					p: r,
					radius: .24,
					power: .26,
					color: [
						.18,
						.91,
						1.3
					],
					pool: "#5adef2",
					alpha: .13,
					halo: .018
				});
			}
			t === "library" && F.push({
				p: [r.x + .034, r.y + .081],
				radius: .23,
				power: .88,
				color: [
					1.32,
					.85,
					.39
				],
				pool: "#ffd18a",
				alpha: .14,
				halo: .02
			}), t === "market" && F.push({
				p: [r.x + .045, r.y + .067],
				radius: .35,
				power: .9,
				color: [
					1.35,
					.77,
					.39
				],
				pool: "#ffb572",
				alpha: .14,
				halo: .023
			}), t === "shrine" && (F.push({
				p: [e.x, e.y],
				radius: .27,
				power: .68,
				color: [
					1.22,
					1.02,
					.37
				],
				pool: "#ffe38b",
				alpha: .11,
				halo: 0
			}), F.push({
				p: [r.x, r.y],
				radius: .14,
				power: .25,
				color: [
					1.2,
					.96,
					.31
				],
				pool: "#ffe7a0",
				alpha: .08,
				halo: .014
			})), t === "artifact" && e.state?.artifacts.length && F.push({
				p: [r.x, r.y],
				radius: .32,
				power: 1.05,
				color: [
					.69,
					.53,
					1.46
				],
				pool: "#ac8cf6",
				alpha: .23,
				halo: .032
			}), t === "rubble" && F.push({
				p: [e.x - .05, e.y],
				radius: .23,
				power: .22,
				color: [
					.35,
					.67,
					.51
				],
				pool: "#8cc8a4",
				alpha: .025,
				halo: 0
			});
		}
		let de = [], I = /* @__PURE__ */ new Map(), fe = [], pe = /* @__PURE__ */ new Map(), me = /* @__PURE__ */ new Map(), he = (e, t) => Math.floor(e / .4) + "," + Math.floor(t / .4), L = (e, t, n, r, i) => {
			for (let a = Math.floor(t / .4); a <= Math.floor(r / .4); a++) for (let t = Math.floor(e / .4); t <= Math.floor(n / .4); t++) {
				let e = t + "," + a, n = me.get(e) ?? {
					profiles: [],
					lights: []
				};
				i(n), me.set(e, n);
			}
		};
		for (let e of P) {
			let t = si(e.r);
			L(Math.min(...t.map((e) => e[0])) - .125, Math.min(...t.map((e) => e[1])) - .125, Math.max(...t.map((e) => e[0])) + .125, Math.max(...t.map((e) => e[1])) + .125, (t) => t.profiles.push(e));
		}
		for (let e of F) L(e.p[0] - e.radius, e.p[1] - e.radius, e.p[0] + e.radius, e.p[1] + e.radius, (t) => t.lights.push(e));
		function ge(e, t) {
			let n = `${Math.round(e * 500)},${Math.round(t * 500)}`, r = I.get(n);
			if (r) return r;
			let i = [
				.105,
				.135,
				.205
			], a = [
				0,
				0,
				0
			], o = 0, s = me.get(he(e, t));
			for (let { r: n, style: r } of s?.profiles ?? []) {
				let i = Math.max(0, Math.min(1, (ci(n, e, t) + .035) / .09));
				o += i;
				for (let e = 0; e < 3; e++) a[e] += i * r.ambient[e];
			}
			let c = i.map((e, t) => e * (1 - Math.min(1, o)) + a[t] / Math.max(1, o));
			for (let n of s?.lights ?? []) {
				let r = Math.hypot(e - n.p[0], t - n.p[1]);
				if (r > n.radius) continue;
				let i = 1;
				for (let r = 1; r < 7; r++) if (b(...d(n.p, [e, t], r / 8)) < -.014) {
					i = .035;
					break;
				}
				let a = Math.max(0, 1 - (r / n.radius) ** 3), o = n.power / (1 + (r / .125) ** 2) * a * i;
				for (let e = 0; e < 3; e++) c[e] += o * n.color[e];
			}
			let l = c.map((e) => Math.min(1.36, e));
			return I.set(n, l), l;
		}
		function _e(e, t) {
			if (!/^#[0-9a-f]{6}$/i.test(e) || ce.has(e)) return e;
			let n = ge(t.reduce((e, t) => e + t[0], 0) / t.length, t.reduce((e, t) => e + t[1], 0) / t.length);
			return "#" + [
				1,
				3,
				5
			].map((t) => parseInt(e.slice(t, t + 2), 16)).map((e, t) => Math.max(0, Math.min(255, Math.round(e * n[t])))).map((e) => e.toString(16).padStart(2, "0")).join("");
		}
		function ve(t, n) {
			if (!/^#[0-9a-f]{6}$/i.test(n) || ce.has(n)) return n;
			let r = [t.reduce((e, t) => e + t[0], 0) / t.length, t.reduce((e, t) => e + t[1], 0) / t.length], i = (e) => e.power / (1 + (Math.hypot(e.p[0] - r[0], e.p[1] - r[1]) / .125) ** 2), a = F[0], s = -Infinity;
			for (let e of F) {
				let t = i(e);
				t >= s && (s = t, a = e);
			}
			let c = a.p, l = [...t].sort((e, t) => Math.hypot(e[0] - c[0], e[1] - c[1]) - Math.hypot(t[0] - c[0], t[1] - c[1])), d = l[0], f = l.at(-1), p = j(d), m = j(f);
			if (Math.hypot(...u(p, m)) < 3) return _e(n, t);
			let h = `${o}-surface-${de.length}`;
			return de.push(`<linearGradient id="${h}" gradientUnits="userSpaceOnUse" x1="${ei(p[0])}" y1="${ei(p[1])}" x2="${ei(m[0])}" y2="${ei(m[1])}"><stop stop-color="${_e(n, [d])}"/><stop offset=".5" stop-color="${_e(n, t)}"/><stop offset="1" stop-color="${_e(n, [f])}"/></linearGradient>`), e.captureThree && pe.set(`url(#${h})`, {
				from: [ei(p[0]), ei(p[1])],
				to: [ei(m[0]), ei(m[1])],
				colors: [
					_e(n, [d]),
					_e(n, t),
					_e(n, [f])
				]
			}), `url(#${h})`;
		}
		let ye = (e, t, n = "none", r = 1) => `<polygon points="${e.map((e) => j(e).map(ei).join(",")).join(" ")}" fill="${ve(e, t)}" stroke="${_e(n, e)}" stroke-width="${r}"/>`, be = (e, t, n, r = "") => `<path d="${e.map((e, t) => `${t ? "L" : "M"}${j(e).map(ei).join(" ")}`).join(" ")}" fill="none" stroke="${_e(t, e)}" stroke-width="${n}" stroke-linecap="round" stroke-linejoin="round" ${r}/>`, xe = (e) => ie.map((t) => t.map((t, n) => `${n ? "L" : "M"}${j([
			t[0],
			t[1],
			e
		]).map(ei).join(" ")}`).join(" ") + "Z").join(" "), R = [], Se = [], Ce = [], z = [], Te = [], Ee = (e, [t, n]) => {
			let r = (t - se.offset[0]) / se.scale + se.origin[0], i = (n - se.offset[1]) / se.scale + se.origin[1], a = (1 - e[2] * (.04 + x * w / S)) / (1 + x * i / S), o = (i * a + e[2] * w) / S;
			return [
				m + r * a * Math.cos(C) + o * Math.sin(C),
				v - r * a * Math.sin(C) + o * Math.cos(C),
				e[2]
			];
		}, De = (t, n, r = 1, i = !1, a = 0) => {
			if (!e.captureThree) return;
			let o = n.match(/fill="([^"]+)"/)?.[1] ?? "none", s = n.match(/stroke="([^"]+)"/)?.[1] ?? "none";
			fe.push({
				points: t,
				paint: pe.get(o) ?? { color: o },
				stroke: s,
				width: Number(n.match(/stroke-width="([^"]+)"/)?.[1] ?? 0),
				opacity: r,
				line: i,
				depth: t.reduce((e, t) => e + ee(t)[2], 0) / t.length + a
			});
		}, B = (e, t, n = "#45434a", r = .55) => {
			let i = ye(e, t, n, r);
			return De(e, i), R.push({
				depth: e.reduce((e, t) => e + ee(t)[2], 0) / e.length,
				body: i
			});
		};
		function V(e, t, n, r, i, a, o, s, c) {
			B([
				[
					e + r,
					t,
					n
				],
				[
					e + r,
					t + i,
					n
				],
				[
					e + r,
					t + i,
					n + a
				],
				[
					e + r,
					t,
					n + a
				]
			], c), B([
				[
					e,
					t + i,
					n
				],
				[
					e + r,
					t + i,
					n
				],
				[
					e + r,
					t + i,
					n + a
				],
				[
					e,
					t + i,
					n + a
				]
			], s), B([
				[
					e,
					t,
					n + a
				],
				[
					e + r,
					t,
					n + a
				],
				[
					e + r,
					t + i,
					n + a
				],
				[
					e,
					t + i,
					n + a
				]
			], o);
		}
		let H = .055;
		Ce.push(`<defs>
    <clipPath id="${o}-floor"><path d="${xe(0)}" fill-rule="evenodd" clip-rule="evenodd"/></clipPath>
    <filter id="${o}-soft" x="-70%" y="-70%" width="240%" height="240%"><feGaussianBlur stdDeviation="${ei(A * .011)}"/></filter>
    <filter id="${o}-halo" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="${ei(A * .014)}"/></filter>
  </defs>`), Ce.push(`<path d="${xe(H)}" fill="none" stroke="#17171b" stroke-width="${ei(A * .025)}" filter="url(#${o}-soft)"/>`), z.push(`<path d="${xe(0)}" fill="#1c2027" fill-rule="evenodd"/>`);
		let Oe = [];
		for (let [e, t] of _.entries()) {
			let n = t.b[0] - t.a[0], r = t.b[1] - t.a[1], i = Math.hypot(n, r), a = n / i, o = r / i, s = -o, c = a, l = Math.ceil(i / .065), u = (e, n) => [
				t.a[0] + a * e + s * n,
				t.a[1] + o * e + c * n,
				.001
			];
			for (let t = 0; t < l; t++) {
				let n = t * i / l + .002, r = (t + 1) * i / l - .002;
				Oe.push(ye([
					u(n, -.046),
					u(r, -.046),
					u(r, .046),
					u(n, .046)
				], [
					"#92938c",
					"#98988e",
					"#8e938e",
					"#9fa095"
				][(t + e) % 4])), Oe.push(be([u(n, -.043), u(n, .043)], "#b8b6a0", .5));
			}
		}
		z.push(`<g clip-path="url(#${o}-floor)">${Oe.join("")}</g>`);
		let ke = (e, t = 0) => si(e, t).map(([e, t]) => [
			e,
			t,
			.002
		]);
		for (let [e, t] of s.entries()) {
			let n = ke(t), r = ke(t, .013 * t.size), i = `${o}-room-${e}`, a = ri(t);
			z.push(ye(n, a.rim), ye(r, a.base)), z.push(`<defs><clipPath id="${i}"><polygon points="${r.map((e) => j(e).map(ei).join(",")).join(" ")}" fill="white"/></clipPath></defs>`);
			let s = [];
			if (!oi(t)) for (let e = -2; e < 3; e++) for (let n = -3; n < 3; n++) {
				let r = t.x + n * .082 + e % 2 * .041, i = t.y + e * .074;
				s.push(ye([
					[
						r + .002,
						i + .002,
						.003
					],
					[
						r + .08,
						i + .002,
						.003
					],
					[
						r + .08,
						i + .071,
						.003
					],
					[
						r + .002,
						i + .071,
						.003
					]
				], a.stones[(n + 3 + e * 3 + 9) % 4])), s.push(be([[
					r + .004,
					i + .004,
					.004
				], [
					r + .077,
					i + .004,
					.004
				]], "#f5e8cb", .45));
			}
			z.push(`<g clip-path="url(#${i})">${s.join("")}</g>`);
			let l = c.filter((e) => e.ka === t.key || e.kb === t.key);
			for (let e = 0; e < n.length; e++) {
				let t = n[e], r = n[(e + 1) % n.length], i = Math.hypot(t[0] - r[0], t[1] - r[1]), a = Math.ceil(i / .016);
				for (let e = 0; e < a; e++) {
					let n = d([t[0], t[1]], [r[0], r[1]], e / a), i = d([t[0], t[1]], [r[0], r[1]], (e + 1) / a), o = d(n, i, .5);
					l.some((e) => f(o, e.a, e.b) < .064) || z.push(be([[
						n[0],
						n[1],
						.005
					], [
						i[0],
						i[1],
						.005
					]], "#f6e8c8", 1));
				}
			}
			if (!t.features.length) {
				let e = t.x, n = t.y;
				z.push(be([
					[
						e - .025,
						n,
						.006
					],
					[
						e,
						n - .025,
						.006
					],
					[
						e + .025,
						n,
						.006
					],
					[
						e,
						n + .025,
						.006
					],
					[
						e - .025,
						n,
						.006
					]
				], "#b4a383", .65));
			}
		}
		z.push(`<g clip-path="url(#${o}-floor)"><path d="${xe(0)}" fill="none" stroke="#05080e" stroke-width="${A * .014}" opacity=".55"/></g>`);
		for (let [e, t] of F.entries()) {
			let [n, r] = j([
				t.p[0],
				t.p[1],
				.002
			]), i = `${o}-pool-${e}`;
			if (z.push(`<defs><radialGradient id="${i}"><stop stop-color="${t.pool}" stop-opacity="${t.alpha}"/><stop offset=".34" stop-color="${t.pool}" stop-opacity="${t.alpha * .45}"/><stop offset="1" stop-color="${t.pool}" stop-opacity="0"/></radialGradient></defs><g clip-path="url(#${o}-floor)"><ellipse cx="${ei(n)}" cy="${ei(r)}" rx="${ei(A * t.radius * .78)}" ry="${ei(A * t.radius * .78 * S)}" fill="url(#${i})"/></g>`), t.halo) {
				let n = `${o}-local-halo-${e}`, [r, i] = j([
					t.p[0],
					t.p[1],
					.06
				]);
				Te.push(`<defs><radialGradient id="${n}"><stop stop-color="${t.pool}" stop-opacity=".42"/><stop offset=".24" stop-color="${t.pool}" stop-opacity=".18"/><stop offset="1" stop-color="${t.pool}" stop-opacity="0"/></radialGradient></defs>${ti(r, i, A * t.halo, `url(#${n})`)}`);
			}
		}
		for (let [e, t] of ae) {
			let n = t[0] - e[0], r = t[1] - e[1], i = Math.hypot(n, r);
			if (i < 3e-4) continue;
			let a = -r / i, o = n / i, s = (e[0] + t[0]) / 2, c = (e[1] + t[1]) / 2, l = b(s + a * .008, c + o * .008) > b(s - a * .008, c - o * .008) ? 1 : -1, u = (a * Math.sin(C) + o * Math.cos(C)) * l, f = [-a * l * .011, -o * l * .011];
			if (B([
				[
					e[0],
					e[1],
					H
				],
				[
					t[0],
					t[1],
					H
				],
				[
					t[0] + f[0],
					t[1] + f[1],
					H
				],
				[
					e[0] + f[0],
					e[1] + f[1],
					H
				]
			], "#d4c3a0", "none", 0), u > -.1 && (B([
				[
					e[0],
					e[1],
					0
				],
				[
					t[0],
					t[1],
					0
				],
				[
					t[0],
					t[1],
					H
				],
				[
					e[0],
					e[1],
					H
				]
			], u > .45 ? "#aa8d67" : "#bca17b", "none", 0), i > .04 && B([
				[
					e[0],
					e[1],
					.046
				],
				[
					t[0],
					t[1],
					.046
				],
				[
					t[0],
					t[1],
					H
				],
				[
					e[0],
					e[1],
					H
				]
			], "#cbb18a", "none", 0), i > .075)) {
				let n = Math.ceil(i / .065);
				for (let r = 1; r < n; r++) {
					let a = d(e, t, r / n - .0015 / i), o = d(e, t, r / n + .0015 / i);
					B([
						[
							a[0],
							a[1],
							.004
						],
						[
							o[0],
							o[1],
							.004
						],
						[
							o[0],
							o[1],
							.046
						],
						[
							a[0],
							a[1],
							.046
						]
					], "#8c7659", "none", 0), B([
						[
							a[0],
							a[1],
							.0553
						],
						[
							o[0],
							o[1],
							.0553
						],
						[
							o[0] + f[0],
							o[1] + f[1],
							.0553
						],
						[
							a[0] + f[0],
							a[1] + f[1],
							.0553
						]
					], "#ae9877", "none", 0);
				}
				B([
					[
						e[0],
						e[1],
						.024
					],
					[
						t[0],
						t[1],
						.024
					],
					[
						t[0],
						t[1],
						.026
					],
					[
						e[0],
						e[1],
						.026
					]
				], "#8f785a", "none", 0);
			}
		}
		Se.push(Zr(`${o}-icons`));
		let Ae = (e, t, n, r, i) => {
			let [a, s] = j([
				e,
				t,
				n
			]);
			Se.push(Qr(r, a, s, 25, `${o}-icons`, { count: i }));
		};
		for (let e of c) {
			let t = e.a, n = e.b, r = Math.hypot(n[0] - t[0], n[1] - t[1]), i = (n[0] - t[0]) / r, a = (n[1] - t[1]) / r, s = d(t, n, .5);
			if (e.pass.oneWay) {
				let e = d(t, n, .62), r = .024;
				z.push(ye([
					[
						e[0] + i * .035,
						e[1] + a * .035,
						.009
					],
					[
						e[0] - i * .024 - a * r,
						e[1] - a * .024 + i * r,
						.009
					],
					[
						e[0] - i * .024 + a * r,
						e[1] - a * .024 - i * r,
						.009
					]
				], "#5f5d62"));
			}
			if (e.pass.lock) {
				let e = -a * .055, t = i * .055;
				for (let n of [-1, 1]) V(s[0] + e * n - .012, s[1] + t * n - .012, 0, .024, .024, .075, "#e0c186", "#a78a56", "#8e724c");
				B([
					[
						s[0] - e,
						s[1] - t,
						.024
					],
					[
						s[0] + e,
						s[1] + t,
						.024
					],
					[
						s[0] + e,
						s[1] + t,
						.065
					],
					[
						s[0] - e,
						s[1] - t,
						.065
					]
				], "#887b66", $r, 1);
			}
			let c = [];
			if (e.pass.lock && c.push({
				kind: "lock",
				p: [
					s[0],
					s[1],
					.09
				]
			}), e.pass.monsters && c.push({
				kind: "monster",
				count: e.pass.monsters,
				p: [
					s[0],
					s[1],
					.016
				]
			}), e.pass.extraBoots && c.push({
				kind: "boot",
				count: "+" + e.pass.extraBoots,
				p: [
					s[0] + a * .04,
					s[1] - i * .04,
					.016
				]
			}), e.pass.toll && c.push({
				kind: "toll",
				count: e.pass.toll,
				p: [
					s[0] - a * .04,
					s[1] + i * .04,
					.016
				]
			}), e.pass.barrier && c.push({
				kind: "barrier",
				p: [
					s[0] + i * .04,
					s[1] + a * .04,
					.016
				]
			}), c.length === 1) {
				let { p: e, kind: t, count: n } = c[0];
				Ae(...e, t, n);
			} else if (c.length > 1) {
				let [e, t] = j([
					s[0],
					s[1],
					.06
				]);
				c.forEach(({ kind: n, count: r }, i) => Se.push(Qr(n, e + (i - (c.length - 1) / 2) * 36, t, 25, `${o}-icons`, { count: r })));
			}
		}
		for (let e of p) {
			let t = e.edge, n = u(t.b, t.a), r = Math.hypot(...n), i = [-n[1] / r * .056, n[0] / r * .056];
			for (let n = 0; n < 10; n++) {
				let r = n / 10, a = (n + 1) / 10, o = d(t.a, t.b, e.t - e.half + r * 2 * e.half), s = d(t.a, t.b, e.t - e.half + a * 2 * e.half), c = (e) => Math.min(1, e * 3.3, (1 - e) * 3.3) * .105, l = c(r), u = c(a);
				B([
					[
						o[0] - i[0],
						o[1] - i[1],
						l
					],
					[
						o[0] + i[0],
						o[1] + i[1],
						l
					],
					[
						s[0] + i[0],
						s[1] + i[1],
						u
					],
					[
						s[0] - i[0],
						s[1] - i[1],
						u
					]
				], "#d3c3a1", "#8d7c67", .7);
				for (let e of [-1, 1]) B([
					[
						o[0] + i[0] * e,
						o[1] + i[1] * e,
						l
					],
					[
						s[0] + i[0] * e,
						s[1] + i[1] * e,
						u
					],
					[
						s[0] + i[0] * e,
						s[1] + i[1] * e,
						u + .015
					],
					[
						o[0] + i[0] * e,
						o[1] + i[1] * e,
						l + .015
					]
				], "#796e6b", "none", 0);
			}
		}
		for (let t of s) {
			let n = g(t), r = n[0], i = n[1], [a, s] = j([
				r,
				i,
				.095
			]), l = `${o}-flame-${t.key.replace(/[^a-z0-9-]/gi, "-")}`;
			Te.push(`<defs><radialGradient id="${l}"><stop stop-color="#fff3c9" stop-opacity=".65"/><stop offset=".12" stop-color="#f8c071" stop-opacity=".34"/><stop offset=".4" stop-color="#ef8e3c" stop-opacity=".12"/><stop offset="1" stop-color="#d65c1f" stop-opacity="0"/></radialGradient></defs>`), Te.push(`<g opacity="${P.find((e) => e.r === t).style.torch}">${ti(a, s, A * (oi(t) ? .024 : .041), `url(#${l})`)}</g>`), V(r - .008, i - .008, .035, .016, .016, .045, "#bd9253", "#73513b", "#524034"), B([
				[
					r - .014,
					i,
					.079
				],
				[
					r - .009,
					i,
					.1
				],
				[
					r + .003,
					i,
					.126
				],
				[
					r + .006,
					i,
					.107
				],
				[
					r + .015,
					i,
					.093
				],
				[
					r + .009,
					i,
					.079
				]
			], "#f4c26a", "#ffdb8a", .45), B([
				[
					r - .006,
					i + .001,
					.081
				],
				[
					r,
					i + .001,
					.111
				],
				[
					r + .007,
					i + .001,
					.086
				]
			], "#fff0b6", "none", 0);
			let u = c.filter((e) => e.ka === t.key || e.kb === t.key), { ax: d, ay: p, x: m, y: h } = ue(t), _ = t.features, v = ri(t), y = (e, n, r = .008) => [
				t.x + e * t.size,
				t.y + n * t.size,
				r
			], b = (e, t, n, r, i, a) => z.push(be(Array.from({ length: 33 }, (i, a) => [
				e + Math.cos(a / 32 * Math.PI * 2) * n,
				t + Math.sin(a / 32 * Math.PI * 2) * n,
				r
			]), i, a)), x = (e, t, n = "none", r = 0) => `<polygon points="${e.map((e) => j(e).map(ei).join(",")).join(" ")}" fill="${t}" stroke="${n}" stroke-width="${r}"/>`, S = (e, t) => {
				let n = x(e, t);
				return De(e, n), R.push({
					depth: e.reduce((e, t) => e + ee(t)[2], 0) / e.length,
					body: n
				});
			}, C = (e, t, n, r = .65) => z.push(`<path d="${e.map((e, t) => `${t ? "L" : "M"}${j(e).map(ei).join(" ")}`).join(" ")}" fill="none" stroke="${t}" stroke-width="${n}" opacity="${r}" stroke-linecap="round"/>`), w = (e, t, n, r = .021) => {
				let i = [
					e + r * .18,
					t - r * .1,
					n
				];
				B([
					[
						e - r,
						t,
						.005
					],
					[
						e,
						t + r * .7,
						.005
					],
					i
				], "#8ad0e3", "#c1e5e7", .35), B([
					[
						e,
						t + r * .7,
						.005
					],
					[
						e + r,
						t,
						.005
					],
					i
				], "#4ba7cb", "#95c8d9", .35), B([
					[
						e + r,
						t,
						.005
					],
					[
						e,
						t - r * .7,
						.005
					],
					i
				], "#477fad", "#78b8cf", .35), S([
					[
						e - r * .2,
						t,
						n * .55
					],
					[
						e + r * .18,
						t - r * .1,
						n
					],
					[
						e - r * .5,
						t,
						n * .22
					]
				], "#a3edf3");
			}, te = (e, t, n, r) => {
				B([
					[
						e - n,
						t,
						.005
					],
					[
						e,
						t + n * .7,
						.005
					],
					[
						e + n * .7,
						t,
						.005
					],
					[
						e + n * .25,
						t - n * .55,
						r
					],
					[
						e - n * .55,
						t - n * .3,
						r * .8
					]
				], "#8e9c9e", "#475f6c", .4), B([
					[
						e,
						t + n * .7,
						.005
					],
					[
						e + n * .7,
						t,
						.005
					],
					[
						e + n * .25,
						t - n * .55,
						r
					]
				], "#60777e", "#475f6c", .4);
			}, T = (e, t, n = !1) => {
				V(e - .044, t - .031, .007, .088, .062, .038, "#bd8e52", "#9f6b3d", "#705035");
				for (let n of [-1, 1]) V(e + n * .027 - .004, t - .033, .009, .008, .066, .035, "#d4b573", "#c4a15c", "#9f7a48");
				if (n) V(e - .044, t - .034, .045, .088, .01, .05, "#bb8e54", "#ae814c", "#795235"), V(e - .035, t - .023, .045, .07, .04, .002, "#392c2d", "#392c2d", "#392c2d");
				else {
					for (let n = 0; n < 7; n++) {
						let r = n / 7 * Math.PI, i = (n + 1) / 7 * Math.PI;
						B([
							[
								e - .044,
								t - .031 * Math.cos(r),
								.045 + .023 * Math.sin(r)
							],
							[
								e + .044,
								t - .031 * Math.cos(r),
								.045 + .023 * Math.sin(r)
							],
							[
								e + .044,
								t - .031 * Math.cos(i),
								.045 + .023 * Math.sin(i)
							],
							[
								e - .044,
								t - .031 * Math.cos(i),
								.045 + .023 * Math.sin(i)
							]
						], [
							"#a37640",
							"#b48749",
							"#c99c58",
							"#d2ad6a",
							"#c99c58",
							"#b48749",
							"#936638"
						][n], "#805c3b", .3);
					}
					V(e - .008, t + .033, .024, .016, .005, .021, "#e0bd77", "#d4ab64", "#967143");
				}
			};
			if (oi(t)) {
				let n = t.size, r = ([e, r, i]) => [
					t.x + e * n,
					t.y + r * n,
					i * n
				], i = (e, t, n = "none", i = 0) => B(e.map(r), t, n, i), a = (e, r, i, a, o, s, c, l, u) => V(t.x + e * n, t.y + r * n, i * n, a * n, o * n, s * n, c, l, u), o = (e, t, n = .7, i = 1) => {
					let a = e.map(r);
					De(a, `<path fill="none" stroke="${t}" stroke-width="${n}"/>`, i, !0, 1e-4), R.push({
						depth: a.reduce((e, t) => e + ee(t)[2], 0) / a.length + 1e-4,
						body: `<path d="${a.map((e, t) => `${t ? "L" : "M"}${j(e).map(ei).join(" ")}`).join(" ")}" fill="none" stroke="${t}" stroke-width="${n}" opacity="${i}" stroke-linecap="round" stroke-linejoin="round"/>`
					});
				}, s = (e, t) => {
					let n = e.map(r);
					De(n, x(n, t), 1, !1, .018), R.push({
						depth: n.reduce((e, t) => e + ee(t)[2], 0) / n.length + .018,
						body: x(n, t)
					});
				}, c = (e, t) => z.push(ye(e.map(r), t)), l = (e, t, n = .6, i = 1) => z.push(`<g opacity="${i}">${be(e.map(r), t, n)}</g>`), u = (e, t, n, r, a, o) => i(Array.from({ length: 25 }, (i, o) => {
					let s = o / 24 * Math.PI * 2;
					return [
						e + Math.cos(s) * r,
						t + Math.sin(s) * a,
						n
					];
				}), o), d = (t, i, a, o = .009, s = "#fff5d3") => {
					let c = r([
						t,
						i,
						a
					]), [l, u] = j(c), d = A * n * o;
					if (e.captureThree) {
						let e = [
							[l, u - d],
							[l + d * .21, u - d * .19],
							[l + d * .8, u],
							[l + d * .21, u + d * .19],
							[l, u + d],
							[l - d * .21, u + d * .19],
							[l - d * .8, u],
							[l - d * .21, u - d * .19]
						].map((e) => Ee(c, e));
						fe.push({
							points: e,
							paint: { color: s },
							stroke: "none",
							width: 0,
							opacity: 1,
							depth: ee(c)[2] + .02
						});
					}
					R.push({
						depth: ee(c)[2] + .02,
						body: `<path d="M${l} ${u - d}L${l + d * .21} ${u - d * .19}L${l + d * .8} ${u}L${l + d * .21} ${u + d * .19}L${l} ${u + d}L${l - d * .21} ${u + d * .19}L${l - d * .8} ${u}L${l - d * .21} ${u - d * .19}Z" fill="${s}"/>`
					});
				}, f = (e, t, n, r, i = .006) => {
					a(e - i / 2, t - i / 2, n, i, i, r, "#a7b9b8", "#576e78", "#283e4b"), o([[
						e - i * .12,
						t + i * .51,
						n + .006
					], [
						e - i * .12,
						t + i * .51,
						n + r - .008
					]], "#b3cbd0", .7, .82);
					for (let a = 0; a < 2; a++) o([[
						e - i * .5,
						t + i * .53,
						n + r * (.24 + a * .41)
					], [
						e + i * .3,
						t + i * .53,
						n + r * (.27 + a * .41)
					]], "#9d6948", .8, .68);
				}, p = (e, t, n) => {
					a(e - .012, t - .01, n, .024, .02, .007, "#c9a65f", "#7f6038", "#4a4334"), a(e - .009, t - .007, n + .007, .018, .014, .03, "#d5b574", "#987443", "#4c473a"), s([
						[
							e - .006,
							t + .0075,
							n + .012
						],
						[
							e + .006,
							t + .0075,
							n + .012
						],
						[
							e + .006,
							t + .0075,
							n + .032
						],
						[
							e - .006,
							t + .0075,
							n + .032
						]
					], "#f3bc69"), s([
						[
							e - .002,
							t + .008,
							n + .014
						],
						[
							e + .003,
							t + .008,
							n + .023
						],
						[
							e,
							t + .008,
							n + .033
						],
						[
							e - .003,
							t + .008,
							n + .021
						]
					], "#fff3d3"), i([
						[
							e - .015,
							t - .011,
							n + .038
						],
						[
							e + .015,
							t - .011,
							n + .038
						],
						[
							e + .011,
							t + .01,
							n + .047
						],
						[
							e - .011,
							t + .01,
							n + .047
						]
					], "#d3b16b"), o([
						[
							e - .009,
							t + .008,
							n + .01
						],
						[
							e - .009,
							t + .008,
							n + .035
						],
						[
							e + .009,
							t + .008,
							n + .035
						]
					], "#ead6a0", .75, .92), o([
						[
							e - .006,
							t - .006,
							n + .048
						],
						[
							e,
							t - .006,
							n + .061
						],
						[
							e + .007,
							t - .006,
							n + .048
						]
					], "#bba16a", .8, .8);
				}, m = (e, t, n, r, s = .045) => {
					let c = .01;
					for (let a = 0; a < 6; a++) {
						let o = a / 6 * Math.PI * 2, l = (a + 1) / 6 * Math.PI * 2;
						i([
							[
								e + Math.cos(o) * c,
								t + Math.sin(o) * c,
								n
							],
							[
								e + Math.cos(l) * c,
								t + Math.sin(l) * c,
								n
							],
							[
								e + Math.cos(l) * c * .72,
								t + Math.sin(l) * c * .72,
								n + s * .69
							],
							[
								e + Math.cos(o) * c * .72,
								t + Math.sin(o) * c * .72,
								n + s * .69
							]
						], a % 3 == 0 ? "#82b7a8" : r);
					}
					a(e - .0035, t - .0035, n + s * .68, .007, .007, s * .31, "#c2bea0", r, "#2f5554"), o([[
						e - .004,
						t + .008,
						n + .006
					], [
						e - .005,
						t + .007,
						n + s * .55
					]], "#dbf3e8", .85, .92), o([[
						e - .002,
						t + .004,
						n + s * .76
					], [
						e - .002,
						t + .004,
						n + s * .93
					]], "#e7f1d9", .55, .78);
				}, h = (e, t, n, r = .023, a = .052) => {
					for (let o = 0; o < 9; o++) {
						let s = o / 9 * Math.PI * 2, c = (o + 1) / 9 * Math.PI * 2;
						i([
							[
								e + Math.cos(s) * r * .84,
								t + Math.sin(s) * r * .84,
								n
							],
							[
								e + Math.cos(c) * r * .84,
								t + Math.sin(c) * r * .84,
								n
							],
							[
								e + Math.cos(c) * r,
								t + Math.sin(c) * r,
								n + a * .5
							],
							[
								e + Math.cos(s) * r,
								t + Math.sin(s) * r,
								n + a * .5
							]
						], [
							"#997047",
							"#b68a56",
							"#89613f"
						][o % 3]), i([
							[
								e + Math.cos(s) * r,
								t + Math.sin(s) * r,
								n + a * .5
							],
							[
								e + Math.cos(c) * r,
								t + Math.sin(c) * r,
								n + a * .5
							],
							[
								e + Math.cos(c) * r * .84,
								t + Math.sin(c) * r * .84,
								n + a
							],
							[
								e + Math.cos(s) * r * .84,
								t + Math.sin(s) * r * .84,
								n + a
							]
						], [
							"#997047",
							"#b68a56",
							"#89613f"
						][o % 3]);
					}
					u(e, t, n + a, r * .84, r * .84, "#c49d6a");
					for (let i of [.014, a - .014]) {
						let a = Array.from({ length: 19 }, (a, o) => {
							let s = o / 18 * Math.PI * 2;
							return [
								e + Math.cos(s) * r * .96,
								t + Math.sin(s) * r * .96,
								n + i
							];
						});
						o(a, "#5b696a", 1.65, .95), o(a.slice(1, 7), "#a4b5b1", .65, .9);
					}
					o([[
						e - r * .55,
						t + .002,
						n + a + 5e-4
					], [
						e + r * .6,
						t + .002,
						n + a + 5e-4
					]], "#654f37", .6, .8);
				};
				if (v.kind === "cave") {
					for (let [e, t] of [
						[
							[
								-.16,
								-.08,
								.007
							],
							[
								-.08,
								-.12,
								.007
							],
							[
								-.025,
								-.085,
								.007
							],
							[
								-.045,
								-.025,
								.007
							],
							[
								-.145,
								-.015,
								.007
							]
						],
						[
							[
								-.045,
								-.11,
								.008
							],
							[
								.025,
								-.14,
								.008
							],
							[
								.077,
								-.08,
								.008
							],
							[
								.039,
								-.015,
								.008
							],
							[
								-.021,
								-.03,
								.008
							]
						],
						[
							[
								.067,
								-.11,
								.007
							],
							[
								.13,
								-.13,
								.007
							],
							[
								.166,
								-.045,
								.007
							],
							[
								.092,
								-.015,
								.007
							],
							[
								.06,
								-.04,
								.007
							]
						],
						[
							[
								-.15,
								.007,
								.006
							],
							[
								-.055,
								-.01,
								.006
							],
							[
								-.035,
								.035,
								.006
							],
							[
								-.115,
								.062,
								.006
							],
							[
								-.167,
								.04,
								.006
							]
						],
						[
							[
								-.02,
								0,
								.008
							],
							[
								.054,
								-.007,
								.008
							],
							[
								.086,
								.044,
								.008
							],
							[
								.029,
								.09,
								.008
							],
							[
								-.03,
								.067,
								.008
							]
						],
						[
							[
								.1,
								.01,
								.009
							],
							[
								.172,
								.015,
								.009
							],
							[
								.145,
								.099,
								.009
							],
							[
								.081,
								.113,
								.009
							],
							[
								.065,
								.065,
								.009
							]
						],
						[
							[
								-.13,
								.08,
								.007
							],
							[
								-.045,
								.064,
								.007
							],
							[
								0,
								.12,
								.007
							],
							[
								-.06,
								.151,
								.007
							],
							[
								-.145,
								.119,
								.007
							]
						]
					].entries()) c(t, [
						"#788e91",
						"#61777e",
						"#8a9c9b",
						"#4e6976"
					][e % 4]);
					c([
						[
							-.126,
							.042,
							.009
						],
						[
							-.056,
							.024,
							.009
						],
						[
							-.006,
							.055,
							.009
						],
						[
							-.024,
							.111,
							.009
						],
						[
							-.088,
							.125,
							.009
						],
						[
							-.139,
							.081,
							.009
						]
					], "#274e60");
					for (let e = 0; e < 5; e++) {
						let t = .054 + e * .011;
						l([
							[
								-.113 + e * .007,
								t,
								.01
							],
							[
								-.085 + e * .01,
								t - .004,
								.01
							],
							[
								-.058 + e * .008,
								t - .001,
								.01
							]
						], "#c8e7e5", e === 2 ? 1.05 : .5, .62);
					}
					let e = (e, t, n, r) => {
						let a = [
							e + .004,
							t - .004,
							n
						], c = n * .7;
						i([
							[
								e - r,
								t,
								.012
							],
							[
								e,
								t + r * .7,
								.012
							],
							[
								e + r * .24,
								t + r * .17,
								c
							],
							a,
							[
								e - r * .43,
								t,
								c
							]
						], "#6bafbe", "#294e63", .4), i([
							[
								e,
								t + r * .7,
								.012
							],
							[
								e + r,
								t,
								.012
							],
							[
								e + r * .44,
								t,
								c
							],
							a,
							[
								e + r * .24,
								t + r * .17,
								c
							]
						], "#377b9b", "#294e63", .4), i([
							[
								e + r,
								t,
								.012
							],
							[
								e,
								t - r * .7,
								.012
							],
							[
								e - r * .02,
								t - r * .27,
								c
							],
							a,
							[
								e + r * .44,
								t,
								c
							]
						], "#244963", "#1f3c55", .4), s([
							[
								e - r * .33,
								t + .001,
								n * .24
							],
							[
								e - r * .13,
								t + .001,
								n * .73
							],
							a,
							[
								e - r * .4,
								t + .001,
								n * .66
							]
						], "#a2e4e8"), s([
							[
								e + r * .1,
								t + r * .3,
								n * .18
							],
							[
								e + r * .28,
								t + r * .17,
								n * .69
							],
							[
								e + r * .13,
								t + r * .11,
								n * .55
							]
						], "#4abfd3"), o([
							[
								e - r * .43,
								t,
								n * .7
							],
							a,
							[
								e + r * .44,
								t,
								n * .7
							]
						], "#d5f4ed", .8, .92), o([[
							e - r * .58,
							t + r * .21,
							.022
						], [
							e - r * .2,
							t + r * .12,
							n * .56
						]], "#9ac6ca", .65, .58);
					};
					for (let [r, i] of [
						[
							.12,
							-.075,
							.174,
							.03
						],
						[
							.15,
							-.052,
							.115,
							.022
						],
						[
							.095,
							-.07,
							.094,
							.019
						],
						[
							.137,
							.073,
							.138,
							.027
						],
						[
							.11,
							.102,
							.083,
							.021
						],
						[
							.16,
							.086,
							.093,
							.018
						]
					].entries()) {
						let [a, o, s, c] = i;
						te(t.x + a * n, t.y + o * n, .026 * n, .023 * n), e(a, o, s, c), (r === 0 || r === 3) && d(a + .004, o - .004, s, .01, "#effffd");
					}
					l([
						[
							-.142,
							-.016,
							.01
						],
						[
							-.047,
							-.028,
							.01
						],
						[
							-.029,
							-.009,
							.01
						]
					], "#b8cdcc", .8, .68), _.includes("heal1") && Ae(t.x, t.y, .02, "heart", 1);
				}
				if (v.kind === "prison") {
					let n = t.state?.opened.includes("prison");
					for (let e = 0; e < 4; e++) for (let t = 0; t < 5; t++) c([
						[
							-.17 + t * .068,
							-.11 + e * .055,
							.008
						],
						[
							-.105 + t * .068,
							-.11 + e * .055,
							.008
						],
						[
							-.105 + t * .068,
							-.058 + e * .055,
							.008
						],
						[
							-.17 + t * .068,
							-.058 + e * .055,
							.008
						]
					], [
						"#798993",
						"#65747e",
						"#536672"
					][(t + e) % 3]);
					c([
						[
							-.164,
							.075,
							.01
						],
						[
							-.055,
							.074,
							.01
						],
						[
							-.025,
							.111,
							.01
						],
						[
							-.155,
							.114,
							.01
						]
					], "#3e555e");
					for (let e = 0; e < 3; e++) l([[
						-.144 + e * .014,
						.091 + e * .006,
						.012
					], [
						-.076 + e * .008,
						.09 + e * .006,
						.012
					]], "#bbd1cb", .7, .63);
					a(-.174, -.116, .011, .131, .225, .014, "#879394", "#4e626c", "#354c58"), a(-.172, -.113, .025, .023, .029, .149, "#a0aaa5", "#68777c", "#414f59"), a(-.067, -.113, .025, .023, .029, .149, "#a0aaa5", "#68777c", "#414f59");
					for (let e = 0; e < 3; e++) o([[
						-.172,
						-.083,
						.061 + e * .038
					], [
						-.149,
						-.083,
						.061 + e * .038
					]], "#394e59", 1, .8);
					for (let e = 0; e < 7; e++) f(-.153 + e * .017, -.086, .031, .132, .006);
					for (let e of [-.157, -.049]) f(e, .099, .031, .132, .008);
					for (let e = 0; e < 10; e++) f(-.047, -.077 + e * .019, .031, .132, .006);
					a(-.165, -.093, .16, .122, .012, .012, "#a0b5ba", "#586e78", "#304753"), a(-.165, .093, .16, .122, .012, .012, "#a0b5ba", "#586e78", "#304753"), a(-.052, -.087, .16, .012, .187, .012, "#a0b5ba", "#586e78", "#304753"), o([
						[
							-.165,
							.106,
							.17
						],
						[
							-.043,
							.106,
							.17
						],
						[
							-.043,
							-.087,
							.17
						]
					], "#c4d4d0", .85, .83);
					for (let e = 0; e < 6; e++) {
						let t = -.145 + (n ? Math.cos(Math.PI * .42) : 1) * e * .017, r = .096 - (n ? Math.sin(Math.PI * .42) : 0) * e * .017;
						f(t, r, .032, .124, .006);
						let i = n ? [
							t + .02,
							r + .034,
							.012
						] : [
							t + .045,
							r + .058,
							.012
						];
						l([[
							t,
							r,
							.012
						], i], "#172833", 2.1, .9);
					}
					let s = [
						-.145 + (n ? Math.cos(Math.PI * .42) : 1) * .085,
						.096 - (n ? Math.sin(Math.PI * .42) : 0) * .085,
						.156
					];
					i([
						[
							-.15,
							.096,
							.148
						],
						[
							s[0],
							s[1],
							.148
						],
						[
							s[0],
							s[1],
							.159
						],
						[
							-.15,
							.096,
							.159
						]
					], "#758f99"), o([[
						-.15,
						.097,
						.16
					], [
						s[0],
						s[1] + .001,
						.16
					]], "#c8d9d6", .9, .9), n || (a(-.075, .102, .079, .02, .012, .027, "#dfbd72", "#b18a46", "#6f5e3e"), o([
						[
							-.074,
							.115,
							.102
						],
						[
							-.058,
							.115,
							.102
						],
						[
							-.058,
							.115,
							.086
						]
					], "#ffedb8", 1, .95), o([[
						-.069,
						.115,
						.09
					], [
						-.063,
						.115,
						.09
					]], "#4a493d", 1.4, .95), d(-.058, .115, .103, .009));
					for (let t = 0; t < 7; t++) {
						let n = r([
							-.152,
							.107,
							.15 - t * .012
						]), [i, a] = j(n);
						e.captureThree && fe.push({
							points: Array.from({ length: 33 }, (e, t) => Ee(n, [i + Math.cos(t / 32 * Math.PI * 2) * A * .004, a + Math.sin(t / 32 * Math.PI * 2) * A * .006])),
							paint: { color: "none" },
							stroke: t % 2 ? "#829b9e" : "#c7d6ca",
							width: 1,
							opacity: 1,
							line: !0,
							depth: ee(n)[2] + 2e-4
						}), R.push({
							depth: ee(n)[2] + 2e-4,
							body: `<ellipse cx="${i}" cy="${a}" rx="${A * .004}" ry="${A * .006}" fill="none" stroke="${t % 2 ? "#829b9e" : "#c7d6ca"}" stroke-width="1"/>`
						});
					}
					for (let e = 0; e < 9; e++) l([[
						-.14 + e * .008,
						-.03 + e % 3 * .019,
						.03
					], [
						-.115 + e * .006,
						-.023 + e % 3 * .019,
						.03
					]], "#9b855a", .7, .65);
					a(.115, -.103, .06, .02, .02, .03, "#89764d", "#6b5b40", "#3e4546"), p(.125, -.093, .092);
				}
				if (v.kind === "library") {
					for (let e = 0; e < 9; e++) {
						let t = -.17 + e * .038;
						c([
							[
								t,
								-.15,
								.007
							],
							[
								t + .035,
								-.15,
								.007
							],
							[
								t + .035,
								.13,
								.007
							],
							[
								t,
								.13,
								.007
							]
						], [
							"#9a7955",
							"#b59063",
							"#826343"
						][e % 3]);
						for (let e = 0; e < 2; e++) l([
							[
								t + .009 + e * .014,
								-.125,
								.008
							],
							[
								t + .012 + e * .012,
								-.02,
								.008
							],
							[
								t + .009 + e * .014,
								.1,
								.008
							]
						], "#d0ad77", .5, .38);
					}
					let e = (e, t, n, r, i = 4) => {
						a(e, t, .011, n, .006, r, "#ac8653", "#493b32", "#3b3330");
						for (let s = 0; s < i; s++) {
							let c = .017 + s * (r - .012) / i;
							a(e - .003, t + .032, c, n + .006, .009, .006, "#c5a06a", "#8f673e", "#5c452f");
							let l = Math.floor(n / .011);
							for (let n = 0; n < l; n++) {
								let l = .007 + n % 3 * 8e-4, u = (r - .012) / i - .008 - n % 4 * .002, d = [
									"#a85f57",
									"#56898a",
									"#b29959",
									"#6a779d",
									"#8c6888",
									"#71916b"
								][(n + s * 2) % 6];
								a(e + .004 + n * .0105, t + .031, c + .006, l, .009, u, d, d, "#3c4245"), (n + s) % 3 == 0 && o([[
									e + .004 + n * .0105,
									t + .0405,
									c + .011
								], [
									e + .004 + n * .0105 + l,
									t + .0405,
									c + .011
								]], "#d9bf80", .55, .8);
							}
						}
						for (let i of [0, n - .007]) a(e + i, t, .011, .007, .043, r + .009, "#c6a470", "#8e673e", "#59452e");
						for (let i of [.011, n - .017]) o([[
							e + i,
							t + .044,
							.023
						], [
							e + i,
							t + .044,
							r
						]], "#c7a56c", .65, .66);
						o([[
							e + .006,
							t + .041,
							r + .019
						], [
							e + n - .006,
							t + .041,
							r + .019
						]], "#e0c593", .9, .82);
					};
					e(-.162, -.147, .102, .154), e(.063, -.147, .098, .144), e(-.169, -.087, .058, .125, 3), c([
						[
							-.05,
							-.05,
							.01
						],
						[
							.057,
							-.05,
							.01
						],
						[
							.057,
							.087,
							.01
						],
						[
							-.05,
							.087,
							.01
						]
					], "#733f43"), l([
						[
							-.043,
							-.043,
							.011
						],
						[
							.049,
							-.043,
							.011
						],
						[
							.049,
							.079,
							.011
						],
						[
							-.043,
							.079,
							.011
						],
						[
							-.043,
							-.043,
							.011
						]
					], "#b69862", 1, .9);
					for (let e = 0; e < 6; e++) l([[
						-.048,
						.089 + e * .0013,
						.01
					], [
						-.044,
						.096 + e * .0013,
						.01
					]], "#a38e6b", .5, .6);
					a(.047, .065, .012, .012, .058, .047, "#88633f", "#604b35", "#423c30"), a(.145, .065, .012, .012, .058, .047, "#88633f", "#604b35", "#423c30"), a(.038, .057, .059, .13, .078, .012, "#c49d69", "#966f43", "#5d4932");
					for (let e = 0; e < 4; e++) o([
						[
							.047,
							.066 + e * .016,
							.0715
						],
						[
							.096,
							.069 + e * .016,
							.0715
						],
						[
							.156,
							.066 + e * .016,
							.0715
						]
					], "#ead1a1", .55, .45);
					i([
						[
							.061,
							.08,
							.073
						],
						[
							.095,
							.073,
							.076
						],
						[
							.102,
							.112,
							.076
						],
						[
							.067,
							.12,
							.073
						]
					], "#dfd1a5"), i([
						[
							.095,
							.073,
							.076
						],
						[
							.126,
							.079,
							.073
						],
						[
							.133,
							.118,
							.073
						],
						[
							.102,
							.112,
							.076
						]
					], "#eadfbd"), o([[
						.095,
						.073,
						.077
					], [
						.102,
						.112,
						.077
					]], "#9a805b", .65, .85);
					for (let e = 0; e < 4; e++) o([[
						.07,
						.086 + e * .006,
						.076
					], [
						.088,
						.083 + e * .006,
						.078
					]], "#736b53", .5, .8);
					for (let e = 0; e < 3; e++) o([[
						.107,
						.085 + e * .008,
						.077
					], [
						.122,
						.088 + e * .008,
						.075
					]], "#736b53", .5, .8);
					a(-.112, .076, .011, .041, .032, .014, "#ba8d75", "#874e4c", "#624445"), a(-.115, .078, .026, .044, .028, .012, "#c6b381", "#9e946f", "#71664d"), a(-.108, .075, .039, .04, .034, .012, "#789899", "#4f7178", "#3e535b"), o([[
						-.108,
						.11,
						.049
					], [
						-.069,
						.11,
						.049
					]], "#e3cf8d", .7, .85), p(.148, .103, .072), d(.138, .112, .11, .0075);
					for (let [e, t, n] of [[
						-.157,
						-.103,
						.127
					], [
						.145,
						-.103,
						.093
					]]) d(e, t, n, .0055, "#ead7a0");
				}
				if (v.kind === "market") {
					for (let e = 0; e < 5; e++) for (let t = 0; t < 6; t++) {
						let n = -.18 + t * .06 + e % 2 * .026, r = -.145 + e * .057;
						n > .17 || c([
							[
								n + .003,
								r + .003,
								.009
							],
							[
								Math.min(.184, n + .056),
								r + .003,
								.009
							],
							[
								Math.min(.184, n + .056),
								r + .053,
								.009
							],
							[
								n + .003,
								r + .053,
								.009
							]
						], [
							"#b38268",
							"#94614e",
							"#bc8a70",
							"#a2715c"
						][(t + e * 2) % 4]);
					}
					let e = (e, t, n) => {
						a(e, t, .012, n, .059, .042, "#bb9361", "#885f40", "#5f4936");
						for (let n = 0; n < 4; n++) o([[
							e + .004 + n * .025,
							t + .06,
							.018
						], [
							e + .004 + n * .025,
							t + .06,
							.051
						]], "#4d4033", .65, .86);
						for (let r of [0, n - .005]) a(e + r, t + .004, .016, .005, .005, .158, "#d2ad73", "#9c7a48", "#5e4c34");
						for (let r = 0; r < 5; r++) {
							let a = e - .007 + r * (n + .014) / 5, s = t - .012, c = (n + .014) / 5, l = r % 2 ? "#ccb58a" : "#a8584f";
							i([
								[
									a,
									s,
									.171
								],
								[
									a + c,
									s,
									.171
								],
								[
									a + c,
									s + .038,
									.167
								],
								[
									a,
									s + .038,
									.167
								]
							], l, "#5e4a3d", .35), i([
								[
									a,
									s + .038,
									.167
								],
								[
									a + c,
									s + .038,
									.167
								],
								[
									a + c,
									s + .087,
									.139
								],
								[
									a,
									s + .087,
									.139
								]
							], r % 2 ? "#d9c49c" : "#b96959", "#5e4a3d", .35), i([
								[
									a,
									s + .087,
									.139
								],
								[
									a + c,
									s + .087,
									.139
								],
								[
									a + c,
									s + .087,
									.127
								],
								[
									a + c * .5,
									s + .087,
									.123
								],
								[
									a,
									s + .087,
									.127
								]
							], r % 2 ? "#b39c74" : "#914c43"), o([[
								a + c * .5,
								s + .043,
								.166
							], [
								a + c * .5,
								s + .079,
								.143
							]], r % 2 ? "#7b6e58" : "#683e39", .6, .43);
						}
						o([[
							e + .004,
							t + .055,
							.055
						], [
							e + n - .004,
							t + .055,
							.055
						]], "#dcbf89", .75, .72);
					};
					e(-.164, -.145, .106), e(.068, -.145, .1);
					for (let e = 0; e < 3; e++) m(-.145 + e * .029, -.088, .055, [
						"#3f8f85",
						"#517da0",
						"#76935c"
					][e], .045 + e % 2 * .01);
					d(-.112, -.078, .098, .007, "#e4fff1"), u(.113, -.093, .057, .027, .018, "#c6a265"), o(Array.from({ length: 19 }, (e, t) => {
						let n = t / 18 * Math.PI * 2;
						return [
							.113 + Math.cos(n) * .027,
							-.093 + Math.sin(n) * .018,
							.059
						];
					}), "#f1d494", .8, .86);
					for (let e = 0; e < 5; e++) u(.095 + e % 3 * .013, -.095 + Math.floor(e / 3) * .012, .06 + e % 2 * .002, .006, .005, "#d4b56c"), o([[
						.092 + e % 3 * .013,
						-.091 + Math.floor(e / 3) * .012,
						.063
					], [
						.099 + e % 3 * .013,
						-.091 + Math.floor(e / 3) * .012,
						.063
					]], "#ffe9a4", .6, .9);
					d(.134, -.089, .061, .007), h(.144, .103, .011, .024, .061), h(.091, .119, .011, .021, .047), a(.119, .039, .011, .051, .038, .036, "#a7845d", "#796043", "#4a4236");
					for (let e = 0; e < 3; e++) o([[
						.121 + e * .016,
						.078,
						.015
					], [
						.121 + e * .016,
						.078,
						.045
					]], "#bba172", .6, .72);
					o([[
						.122,
						.078,
						.015
					], [
						.166,
						.078,
						.044
					]], "#bba172", .9, .75);
					for (let e = 0; e < 3; e++) i([
						[
							-.164 + e * .024,
							-.072,
							.116
						],
						[
							-.146 + e * .024,
							-.072,
							.116
						],
						[
							-.146 + e * .024,
							-.072,
							.093
						],
						[
							-.155 + e * .024,
							-.072,
							.087
						],
						[
							-.164 + e * .024,
							-.072,
							.095
						]
					], [
						"#b87c5b",
						"#9d6860",
						"#b69a67"
					][e]);
					p(-.075, -.073, .089), p(.153, -.074, .089), o([[
						-.075,
						-.073,
						.15
					], [
						-.075,
						-.073,
						.164
					]], "#bcaa79", .9, .8), o([[
						.153,
						-.074,
						.15
					], [
						.153,
						-.074,
						.164
					]], "#bcaa79", .9, .8);
				}
			}
			let E = _.includes("library") ? "library" : _.includes("prison") || _.includes("prison3") ? "prison" : _.includes("market") ? "market" : _.includes("wayshrine") ? "shrine" : void 0;
			if (E) {
				let [e, n] = j([
					t.x + .145 * t.size,
					t.y + .115 * t.size,
					.012
				]), r = E === "prison" && !!t.state?.opened.includes("prison");
				Se.push(Qr(E, e, n, 25, `${o}-icons`, {
					open: r,
					count: E === "prison" && !r && _.includes("prison3") ? 3 : void 0
				}));
			}
			if (M[t.key] = j([
				m,
				h,
				.09
			]), v.kind === "cave" && !oi(t)) {
				let e = si(t, .025 * t.size);
				for (let t = 0; t < e.length; t += 2) {
					let [n, r] = e[t];
					u.some((e) => f([n, r], e.a, e.b) < .07) || (te(n, r, .018, .023), w(n, r, .052 + t % 5 * .013, .014), t % 4 == 0 && w(n + .024, r - .009, .042, .012));
				}
				z.push(ye([
					y(-.06, -.075),
					y(.035, -.1),
					y(.09, -.025),
					y(.06, .05),
					y(-.04, .066),
					y(-.095, .005)
				], "#608793", "none", 0)), z.push(be([
					y(-.055, .02),
					y(-.025, .03),
					y(.022, .025),
					y(.047, .008)
				], "#c1d6ce", .75)), _.includes("heal1") && (b(t.x, t.y, .055, .009, "#b4c8bd", 1), Ae(t.x, t.y, .018, "heart", 1));
			}
			if (v.kind === "library" && !oi(t)) {
				let e = h - .027, t = m - .057;
				V(t, e, .01, .114, .043, .116, "#b58e5e", "#70513b", "#5d4837");
				for (let n = 0; n < 3; n++) {
					V(t - .004, e + .041, .014 + n * .036, .122, .008, .006, "#cfad77", "#ab8250", "#80603e");
					for (let r = 0; r < 10; r++) {
						if (n === 2 && r === 6) continue;
						let i = [
							"#9c5860",
							"#638b8a",
							"#ba9d65",
							"#6b7e9e",
							"#87709c"
						][r % 5], a = .021 + r % 3 * .003;
						V(t + .005 + r * .01, e + .039, .021 + n * .036, .007, .007, a, i, i, i), B([
							[
								t + .006 + r * .01,
								e + .0465,
								.027 + n * .036
							],
							[
								t + .011 + r * .01,
								e + .0465,
								.027 + n * .036
							],
							[
								t + .011 + r * .01,
								e + .0465,
								.029 + n * .036
							],
							[
								t + .006 + r * .01,
								e + .0465,
								.029 + n * .036
							]
						], "#d1bb84", "none", 0);
					}
				}
				for (let n of [0, .107]) V(t + n, e, .01, .007, .048, .119, "#c0a16d", "#977246", "#73543a");
				let n = -d * .55, r = -p * .55;
				z.push(ye([
					y(n - .037, r - .028),
					y(n + .039, r - .028),
					y(n + .037, r + .032),
					y(n - .038, r + .031)
				], "#986e58")), z.push(be([
					y(n - .027, r - .018),
					y(n + .027, r - .018),
					y(n + .026, r + .022),
					y(n - .027, r + .021),
					y(n - .027, r - .018)
				], "#c5ab7c", 1)), V(m + .012, h + .067, .008, .045, .028, .013, "#c5bba0", "#9c8b70", "#927f65");
				let i = m + .034, a = h + .081;
				V(i - .012, a - .009, .023, .024, .018, .005, "#d3b46f", "#ab8748", "#745932"), V(i - .003, a - .003, .028, .006, .006, .025, "#d5b97a", "#ab8748", "#745932"), S([
					[
						i - .006,
						a,
						.052
					],
					[
						i + .002,
						a,
						.073
					],
					[
						i + .007,
						a,
						.053
					]
				], "#ffe5b1");
			}
			if (v.kind === "prison" && !oi(t)) {
				let e = m - .058, n = h - .027, a = t.state?.opened.includes("prison");
				for (let t = 0; t < (a ? 4 : 6); t++) {
					let o = a ? e : e + t * .022, s = a ? n + t * .021 : n + .065, c = o - r, l = s - i, u = Math.hypot(c, l), d = c / u * .11, f = l / u * .11;
					z.push(`<g opacity=".62">${ye([
						[
							o - .003,
							s,
							.006
						],
						[
							o + .003,
							s,
							.006
						],
						[
							o + d + .005,
							s + f,
							.006
						],
						[
							o + d - .005,
							s + f,
							.006
						]
					], "#0d1729")}</g>`);
				}
				V(e - .005, n - .004, .005, .125, .082, .012, "#989a8b", "#6c7471", "#596267");
				for (let t = 0; t < 6; t++) V(e + t * .022, n, .016, .005, .006, .112, "#bac4bf", "#809292", "#596f79");
				for (let t = 0; t < 4; t++) V(e, n + t * .021, .016, .005, .005, .112, "#bac4bf", "#809292", "#596f79");
				if (V(e - .003, n - .003, .123, .122, .07, .008, "#a6b4ae", "#7f969a", "#5c737c"), a) {
					for (let t = 0; t < 5; t++) V(e + .112, n + .065 + t * .018, .017, .005, .005, .103, "#adbbb7", "#84989a", "#576e78");
					V(e + .112, n + .065, .118, .007, .077, .008, "#b9c5bc", "#82989a", "#5d7480");
				} else {
					for (let t = 0; t < 6; t++) V(e + t * .022, n + .065, .016, .005, .005, .112, "#bac4bf", "#8c9d9e", "#647b82");
					V(e - .003, n + .065, .116, .122, .007, .008, "#bac4bf", "#8c9d9e", "#647b82"), V(m - .009, n + .073, .055, .018, .005, .023, "#bca570", "#ae955f", "#7d7257");
				}
				for (let t = 0; t < 5; t++) {
					let [r, i] = j([
						e + .043,
						n + .002,
						.1 - t * .009
					]);
					z.push(`<ellipse cx="${r}" cy="${i}" rx="${A * .003}" ry="${A * .005}" fill="none" stroke="#82989a" stroke-width=".65"/>`);
				}
				z.push(ye([
					y(-.04, .05),
					y(.09, .05),
					y(.09, .085),
					y(-.04, .085)
				], "#626b70"));
			}
			if (v.kind === "shrine") {
				b(t.x, t.y, .104 * t.size, .007, "#b69151", 2), b(t.x, t.y, .084 * t.size, .008, "#ddc894", 1);
				for (let e = 0; e < 8; e++) {
					let t = e / 8 * Math.PI * 2;
					z.push(ye([
						y(Math.cos(t) * .069, Math.sin(t) * .069),
						y(Math.cos(t - .13) * .092, Math.sin(t - .13) * .092),
						y(Math.cos(t + .13) * .092, Math.sin(t + .13) * .092)
					], "#caaa6d"));
				}
				for (let e = 0; e < 8; e++) {
					let t = e / 8 * Math.PI * 2;
					C([y(Math.cos(t) * .074, Math.sin(t) * .074), y(Math.cos(t) * .086, Math.sin(t) * .086)], "#ffe39a", 1.1, .72);
				}
				C(Array.from({ length: 49 }, (e, t) => y(Math.cos(t / 48 * Math.PI * 2) * .084, Math.sin(t / 48 * Math.PI * 2) * .084)), "#f4d879", .8, .42), V(m - .047, h - .037, .005, .094, .074, .018, "#d8c6a1", "#aa8d62", "#887251"), V(m - .034, h - .026, .023, .068, .052, .021, "#d8c9aa", "#b39874", "#927b5e"), B([
					[
						m - .025,
						h,
						.044
					],
					[
						m,
						h - .019,
						.044
					],
					[
						m,
						h,
						.113
					]
				], "#d0b172", "#edd6a4", .65), B([
					[
						m - .025,
						h,
						.044
					],
					[
						m,
						h + .019,
						.044
					],
					[
						m,
						h,
						.113
					]
				], "#b59c70", "#d8c295", .5), B([
					[
						m,
						h + .019,
						.044
					],
					[
						m + .025,
						h,
						.044
					],
					[
						m,
						h,
						.113
					]
				], "#8d7c65", "#b9a47b", .5);
			}
			if (v.kind === "market" && !oi(t)) {
				let e = m - .06, t = h - .032;
				V(e, t, .006, .12, .071, .034, "#b79061", "#9d704b", "#79563d");
				for (let n = 0; n < 6; n++) B([
					[
						e + n * .02,
						t + .072,
						.009
					],
					[
						e + n * .02 + .002,
						t + .072,
						.009
					],
					[
						e + n * .02 + .002,
						t + .072,
						.039
					],
					[
						e + n * .02,
						t + .072,
						.039
					]
				], "#6d503a", "none", 0);
				for (let n of [0, .114]) for (let r of [0, .066]) V(e + n, t + r, .005, .005, .005, .122, "#d3b783", "#9f8358", "#7c6241");
				for (let n = 0; n < 6; n++) {
					let r = e + n * .02;
					B([
						[
							r,
							t - .01,
							.136
						],
						[
							r + .02,
							t - .01,
							.136
						],
						[
							r + .02,
							t + .038,
							.133
						],
						[
							r,
							t + .038,
							.133
						]
					], n % 2 ? "#e0c68d" : "#ab4d41", "#795646", .3), B([
						[
							r,
							t + .038,
							.133
						],
						[
							r + .02,
							t + .038,
							.133
						],
						[
							r + .02,
							t + .085,
							.109
						],
						[
							r,
							t + .085,
							.109
						]
					], n % 2 ? "#f1d79c" : "#cb6652", "#795646", .3), B([
						[
							r,
							t + .085,
							.109
						],
						[
							r + .02,
							t + .085,
							.109
						],
						[
							r + .02,
							t + .085,
							.096
						],
						[
							r,
							t + .085,
							.096
						]
					], n % 2 ? "#c5a56b" : "#99453c", "none", 0);
				}
				for (let n = 0; n < 3; n++) V(e + .015 + n * .031, t + .061, .041, .022, .016, .011, [
					"#799d88",
					"#aa6f67",
					"#bd9c62"
				][n], "#967b52", "#725c40");
				V(e - .034, t + .004, .007, .023, .037, .026, "#ad8252", "#8b643c", "#735137");
				let n = m + .045, r = h + .067;
				V(n - .01, r - .008, .073, .02, .016, .025, "#d7a65e", "#ad7540", "#715338"), S([
					[
						n - .007,
						r + .0085,
						.078
					],
					[
						n + .007,
						r + .0085,
						.078
					],
					[
						n + .007,
						r + .0085,
						.094
					],
					[
						n - .007,
						r + .0085,
						.094
					]
				], "#ffdc96"), V(n - .002, r - .002, .098, .004, .004, .022, "#d7a65e", "#ad7540", "#715338");
			}
			if (v.kind === "artifact") {
				b(t.x, t.y, .118 * t.size, .007, "#a99bb2", 1), b(t.x, t.y, .109 * t.size, .007, "#c3b2b0", .6);
				for (let e = 0; e < 8; e++) {
					let t = e / 8 * Math.PI * 2;
					z.push(be([y(Math.cos(t) * .082, Math.sin(t) * .082), y(Math.cos(t) * .104, Math.sin(t) * .104)], "#ba9f9c", 1));
				}
				if (V(m - .05, h - .041, .005, .1, .082, .02, "#c5b8b9", "#a091a1", "#817488"), V(m - .036, h - .03, .025, .072, .06, .034, "#d2bda3", "#a99585", "#81738a"), V(m - .044, h - .037, .059, .088, .074, .01, "#dec999", "#bfa97d", "#958672"), t.state?.artifacts.length) {
					let e = .078;
					Se.push(x([
						[
							m - .033,
							h,
							e
						],
						[
							m,
							h - .024,
							e
						],
						[
							m + .002,
							h,
							.154
						]
					], "#d2c1ff", "#e2d9ff", .6), x([
						[
							m - .033,
							h,
							e
						],
						[
							m + .033,
							h,
							e
						],
						[
							m + .002,
							h,
							.154
						]
					], "#a18bea", "#e2d9ff", .6), x([
						[
							m + .033,
							h,
							e
						],
						[
							m,
							h + .025,
							e
						],
						[
							m + .002,
							h,
							.154
						]
					], "#7262c5", "#afa0ed", .5)), Ae(m, h, .18, "artifact", Math.max(...t.state.artifacts));
				} else z.push(be([
					[
						m - .017,
						h - .008,
						.071
					],
					[
						m + .017,
						h + .008,
						.071
					],
					[
						m + .017,
						h - .008,
						.071
					],
					[
						m - .017,
						h + .008,
						.071
					]
				], "#8e7b79", .8));
			}
			if (v.kind === "stone" && (z.push(ye([
				y(-.086, -.079),
				y(.083, -.079),
				y(.083, .076),
				y(-.086, .076)
			], "#baaa8c")), z.push(be([
				y(-.079, -.072),
				y(.076, -.072),
				y(.076, .069),
				y(-.079, .069),
				y(-.079, -.072)
			], "#e3d0a4", .8)), z.push(be([
				y(-.014, -.07),
				y(.007, -.04),
				y(-.006, -.012),
				y(.027, .02)
			], "#807863", .8)), V(m - .025, h - .022, .005, .05, .044, .027, "#c7b796", "#a79573", "#8f8066"), V(m - .017, h - .015, .032, .034, .03, .021, "#d1c3a2", "#ae9b79", "#8f8066"), V(m - .031, h - .026, .053, .062, .052, .01, "#c4b28e", "#a59170", "#8a7c64"), te(m + .036, h + .024, .02, .014)), v.kind === "rubble") {
				z.push(ye([
					y(-.13, -.08),
					y(-.04, -.095),
					y(.02, -.038),
					y(.11, .025),
					y(.06, .093),
					y(-.045, .062)
				], "#588569"));
				for (let e = 0; e < 4; e++) z.push(be([y(-.07 + e * .017, -.018 + e * .014), y(-.039 + e * .017, -.024 + e * .014)], "#adc1a6", .65));
				for (let e = 0; e < 7; e++) te(m + (e % 3 - 1) * .024, h + (Math.floor(e / 3) - 1) * .022, .013 + e % 2 * .006, .012 + e % 3 * .005);
				z.push(be([
					y(-.09, -.08),
					y(-.04, -.045),
					y(-.055, 0),
					y(.008, .028),
					y(.06, .09)
				], "#535f5d", 1.1)), z.push(be([
					y(-.045, -.044),
					y(.018, -.055),
					y(.06, -.031)
				], "#8b9b87", .65));
			}
			if (_.includes("chest") && T(m, h, !!t.state?.opened.includes("chest")), _.includes("idol") && t.state?.idols.length && (V(m - .038, h - .032, .004, .076, .064, .019, "#c9b887", "#9c885e", "#7c6e51"), V(m - .017, h - .017, .023, .034, .034, .041, "#d9bb70", "#b29852", "#8e783b"), V(m - .028, h - .018, .064, .056, .037, .031, "#e5c67d", "#c1a25a", "#8f793f"), Ae(m, h, .15, "idol", Math.max(...t.state.idols))), t.state?.artifacts.length && v.kind !== "artifact") {
				let e = t.x - d * .6, n = t.y - p * .6;
				M[t.key] = j([
					e,
					n,
					.09
				]), V(e - .032, n - .026, .005, .064, .052, .014, "#bca8b0", "#93849a", "#6b657d"), B([
					[
						e - .025,
						n,
						.019
					],
					[
						e,
						n - .021,
						.019
					],
					[
						e,
						n,
						.105
					]
				], "#b7c8ef", "#ecddbd", .6), B([
					[
						e - .025,
						n,
						.019
					],
					[
						e + .025,
						n,
						.019
					],
					[
						e,
						n,
						.105
					]
				], "#807cc1", "#ecddbd", .6), Ae(e, n, .14, "artifact", Math.max(...t.state.artifacts));
			}
			if (t.state?.secrets && Ae(t.x - d * .7, t.y - p * .7, .012, "secret", t.state.secrets > 1 ? t.state.secrets : void 0), t.id === "crypt") for (let e = 0; e < 4; e++) V(t.x - .062, t.y + .03 + e * .025, .001, .124, .023, .005 * (4 - e), "#d5c5a4", "#aa987f", "#9a8a78");
		}
		R.sort((e, t) => e.depth - t.depth);
		let je = [], Me = [];
		for (let [e, { p: t, inward: n }] of h.entries()) {
			let r = [t[0] + n[0] * .16, t[1] + n[1] * .16], i = [t[0] - n[0] * .44, t[1] - n[1] * .44], a = j([
				r[0],
				r[1],
				.027
			]), s = j([
				i[0],
				i[1],
				.027
			]), c = `${o}-vanish-${e}`, l = [-n[1] * .13, n[0] * .13];
			je.push(`<linearGradient id="${c}" gradientUnits="userSpaceOnUse" x1="${a[0]}" y1="${a[1]}" x2="${s[0]}" y2="${s[1]}"><stop stop-color="black" stop-opacity="0"/><stop offset=".16" stop-color="black" stop-opacity=".1"/><stop offset=".34" stop-color="black" stop-opacity=".64"/><stop offset=".55" stop-color="black" stop-opacity=".97"/><stop offset=".68" stop-color="black"/><stop offset="1" stop-color="black"/></linearGradient>`), Me.push(ye([
				[
					r[0] + l[0],
					r[1] + l[1],
					.027
				],
				[
					r[0] - l[0],
					r[1] - l[1],
					.027
				],
				[
					i[0] - l[0],
					i[1] - l[1],
					.027
				],
				[
					i[0] + l[0],
					i[1] + l[1],
					.027
				]
			], `url(#${c})`));
		}
		let Ne = l.map(j), Pe = Math.min(...Ne.map((e) => e[0])) - 100, Fe = Math.min(...Ne.map((e) => e[1])) - 100, Ie = Math.max(...Ne.map((e) => e[0])) - Pe + 100, Le = Math.max(...Ne.map((e) => e[1])) - Fe + 100, Re = `<defs>${de.join("")}${je.join("")}<mask id="${o}-depth" maskUnits="userSpaceOnUse" x="${Pe}" y="${Fe}" width="${Ie}" height="${Le}">${ni(Pe, Fe, Ie, Le, "white")}${Me.join("")}</mask></defs><g><g mask="url(#${o}-depth)">${Ce.join("")}${z.join("")}${R.map((e) => e.body).join("")}${Te.join("")}</g>${Se.join("")}</g>`, ze = e.captureThree ? {
			faces: fe,
			floor: `${Ce[0]}<defs>${de.join("")}</defs>${z.join("")}`,
			atmosphere: Ce.join(""),
			foreground: Te.join(""),
			labels: Se.join(""),
			mask: `<defs>${je.join("")}</defs>${ni(Pe, Fe, Ie, Le, "white")}${Me.join("")}`,
			bounds: [
				Pe,
				Fe,
				Ie,
				Le
			]
		} : void 0, Be = Object.fromEntries([...i.keys()].flatMap((e) => {
			let t = a(e);
			return t ? [[e, j([
				t[0],
				t[1],
				0
			])]] : [];
		})), Ve = {};
		for (let e of p) {
			let { edge: t, t: n, half: r } = e, i = Array.from({ length: 7 }, (e, i) => {
				let a = i / 6, o = d(t.a, t.b, n - r + a * 2 * r);
				return j([
					o[0],
					o[1],
					Math.max(0, Math.min(1, a * 3.3, (1 - a) * 3.3)) * .105
				]);
			});
			Ve[`${t.ka}>${t.kb}`] = i, Ve[`${t.kb}>${t.ka}`] = [...i].reverse();
		}
		let He = Object.fromEntries(t.map((e) => [e.id, [
			[-.12, -.12],
			[1.12, -.12],
			[1.12, we[e.kind].height + .12],
			[-.12, we[e.kind].height + .12]
		].map((t) => {
			let n = r(e, t);
			return j([
				n[0],
				n[1],
				.04
			]);
		})])), Ue = Object.fromEntries(s.map((e) => {
			let t = g(e);
			return [e.key, j([
				t[0],
				t[1],
				.095
			])];
		}));
		return {
			markup: Re,
			width: se.width,
			height: se.height,
			camera: se,
			positions: Be,
			project: j,
			artifactPositions: M,
			bridgePaths: Ve,
			tileShapes: He,
			torchPoints: Ue,
			three: ze,
			frontiers: h.map((e) => ({
				key: e.key,
				point: j([
					e.p[0] - e.inward[0] * .08,
					e.p[1] - e.inward[1] * .08,
					0
				])
			}))
		};
	}
	return oe();
}
//#endregion
//#region src/games/clankcatacombs/scene-cache.ts
function ui() {
	let e = "", t, n = /* @__PURE__ */ new Map();
	return { build(r, i) {
		let a = `${i}:${r}`, o = n.get(a);
		if (o) return e = i, t = o.camera, o;
		let s = li({
			...JSON.parse(r),
			camera: e === i ? t : void 0,
			captureThree: !0
		});
		return e = i, t = s.camera, n.set(a, s), n.size > 3 && n.delete(n.keys().next().value), s;
	} };
}
//#endregion
//#region src/games/clankcatacombs/scene-three-geometry.ts
var di = -.25, fi = .66, pi = Math.sqrt(1 - fi * fi);
function mi(e, [t, n, r]) {
	t -= e.center[0], n -= e.center[1];
	let i = t * Math.cos(di) - n * Math.sin(di), a = t * Math.sin(di) + n * Math.cos(di), o = 1 - a * e.perspective - r * .04;
	return [e.offset[0] + (i / o - e.origin[0]) * e.scale, e.offset[1] + ((a * fi - r * pi) / o - e.origin[1]) * e.scale];
}
function hi(e, [t, n], r = 0) {
	let i = (t - e.offset[0]) / e.scale + e.origin[0], a = (n - e.offset[1]) / e.scale + e.origin[1], o = (1 - r * (.04 + e.perspective * pi / fi)) / (1 + e.perspective * a / fi), s = (a * o + r * pi) / fi;
	return [
		e.center[0] + i * o * Math.cos(di) + s * Math.sin(di),
		e.center[1] - i * o * Math.sin(di) + s * Math.cos(di),
		r
	];
}
function gi(e) {
	return [
		1,
		3,
		5
	].map((t) => parseInt(e.slice(t, t + 2), 16) / 255);
}
function _i(e, t) {
	let n = {
		position: [],
		paintFrom: [],
		paintDelta: [],
		colorA: [],
		colorB: [],
		colorC: [],
		alpha: [],
		surfaceDepth: []
	}, r = {
		position: 3,
		paintFrom: 2,
		paintDelta: 2,
		colorA: 3,
		colorB: 3,
		colorC: 3,
		alpha: 1,
		surfaceDepth: 1
	};
	function i(e, t, r, i) {
		n.position.push(...e);
		let a = "color" in t;
		n.paintFrom.push(...a ? [0, 0] : t.from), n.paintDelta.push(...a ? [0, 0] : [t.to[0] - t.from[0], t.to[1] - t.from[1]]), n.colorA.push(...gi(a ? t.color : t.colors[0])), n.colorB.push(...gi(a ? t.color : t.colors[1])), n.colorC.push(...gi(a ? t.color : t.colors[2])), n.alpha.push(r), n.surfaceDepth.push(i);
	}
	let a = [];
	for (let n of e) {
		if (n.stroke !== "none" && n.width > 0 && a.push(n), n.line || "color" in n.paint && n.paint.color === "none") continue;
		let e = n.points.map((e) => mi(t, e)), r = k.triangulateShape(e.map((e) => new A(...e)), []);
		for (let e of r) for (let t of e) i(n.points[t], n.paint, n.opacity, n.depth ?? 0);
	}
	let o = new te();
	for (let [e, t] of Object.entries(n)) o.setAttribute(e, new D(t, r[e]));
	return o.computeBoundingSphere(), {
		geometry: o,
		strokes: a,
		triangles: n.position.length / 9
	};
}
function vi(e) {
	let t = [], n = [], r = [], i = [], a = [], o = [];
	for (let s of e) {
		let e = s.line ? s.points : [...s.points, s.points[0]];
		for (let c = 1; c < e.length; c++) for (let [l, u] of [
			[0, -1],
			[1, -1],
			[1, 1],
			[0, -1],
			[1, 1],
			[0, 1]
		]) t.push(...e[c - 1 + l]), n.push(...e[c - l]), r.push(u, l ? -s.width : s.width), i.push(...gi(s.stroke)), a.push(s.opacity), o.push(s.depth ?? 0);
	}
	let s = new te();
	for (let [e, c, l] of [
		[
			"position",
			t,
			3
		],
		[
			"other",
			n,
			3
		],
		[
			"corner",
			r,
			2
		],
		[
			"strokeColor",
			i,
			3
		],
		[
			"alpha",
			a,
			1
		],
		[
			"surfaceDepth",
			o,
			1
		]
	]) s.setAttribute(e, new D(c, l));
	return s.computeBoundingSphere(), s;
}
//#endregion
//#region src/games/clankcatacombs/pawn-three.ts
function yi(e, t) {
	let n = [];
	return Gr(e.color, e.number, e.number - 1, 0, (r, i, a) => {
		n.push({
			points: r.map(([n, r, i]) => hi(t, [e.x + (n * Math.cos(-.25) - r * Math.sin(-.25)) * .68, e.y + ((n * Math.sin(-.25) + r * Math.cos(-.25)) * .66 - i * Math.sqrt(1 - .66 * .66)) * .68], i * .68 / t.scale)),
			paint: { color: i },
			stroke: i,
			width: .16,
			opacity: a,
			depth: r.reduce((e, [t, n, r]) => e + t * Math.sin(-.25) + n * Math.cos(-.25) - r * .25, 0) / r.length
		});
	}), n.sort((e, t) => e.depth - t.depth), n.unshift({
		points: Array.from({ length: 40 }, (n, r) => hi(t, [e.x + 3 + 17 * Math.cos(r / 40 * Math.PI * 2), e.y + 3 + 8 * Math.sin(r / 40 * Math.PI * 2)])),
		paint: { color: "#02060b" },
		stroke: "none",
		width: 0,
		opacity: .48
	}), n.forEach((t, n) => {
		t.depth = 50 + (e.layer ?? 0) * 2 + n * 1e-4;
	}), n;
}
//#endregion
//#region src/games/clankcatacombs/scene-three-material.ts
var bi = "\nprecision highp float;\nuniform vec2 worldCenter, cameraOrigin, cameraOffset, viewport;\nuniform vec3 view;\nuniform float worldScale, perspective;\nvec4 scenePosition(vec3 p) {\n  vec2 q=p.xy-worldCenter;\n  float a=q.x*.9689124217+q.y*.2474039593;\n  float d=-q.x*.2474039593+q.y*.9689124217;\n  float w=1.-d*perspective-p.z*.04;\n  vec2 projected=vec2(a,d*.66-p.z*.7512655988)*worldScale;\n  vec2 offset=(cameraOffset-cameraOrigin*worldScale-view.xy)*view.z;\n  vec2 clip=2.*(projected*view.z+offset*w)/viewport;\n  return vec4(clip.x,-clip.y,-(d-p.z*.25)*.01,w);\n}\n", xi = "\nprecision highp float;\nuniform vec2 viewport;\nuniform vec3 view;\nuniform float pixelRatio;\nuniform vec4 atlasBounds;\nuniform sampler2D fadeMap;\nvec2 scenePixel() {\n  return (vec2(gl_FragCoord.x/pixelRatio,viewport.y-gl_FragCoord.y/pixelRatio)-viewport*.5)/view.z+view.xy;\n}\nvec2 atlasUv(vec2 p) { return vec2((p.x-atlasBounds.x)/atlasBounds.z,1.-(p.y-atlasBounds.y)/atlasBounds.w); }\nfloat visibility(vec2 p) { return texture2D(fadeMap,atlasUv(p)).r; }\n";
function Si(e, t, n) {
	return {
		worldCenter: { value: new A(...e.center) },
		cameraOrigin: { value: new A(...e.origin) },
		cameraOffset: { value: new A(...e.offset) },
		worldScale: { value: e.scale },
		perspective: { value: e.perspective },
		viewport: { value: new A(1, 1) },
		view: { value: new re(e.width / 2, e.height / 2, 1) },
		pixelRatio: { value: 1 },
		atlasBounds: { value: new ie(...t) },
		fadeMap: { value: n }
	};
}
function Ci(e, t, n) {
	return new O({
		uniforms: Si(e, t, n),
		side: E,
		transparent: !0,
		vertexShader: `${bi}
      attribute vec3 position,colorA,colorB,colorC;
      attribute vec2 paintFrom,paintDelta;
      attribute float alpha,surfaceDepth;
      varying vec3 vA,vB,vC;
      varying vec2 vFrom,vDelta;
      varying float vAlpha;
      void main(){gl_Position=scenePosition(position);gl_Position.z=-surfaceDepth*.01*gl_Position.w;vA=colorA;vB=colorB;vC=colorC;vFrom=paintFrom;vDelta=paintDelta;vAlpha=alpha;}`,
		fragmentShader: `${xi}
      varying vec3 vA,vB,vC;
      varying vec2 vFrom,vDelta;
      varying float vAlpha;
      void main(){
        vec2 p=scenePixel();float len=dot(vDelta,vDelta);
        float t=len>.0001?clamp(dot(p-vFrom,vDelta)/len,0.,1.):0.;
        vec3 color=t<.5?mix(vA,vB,t*2.):mix(vB,vC,(t-.5)*2.);
        gl_FragColor=vec4(color,vAlpha*visibility(p));
      }`
	});
}
function wi(e, t, n) {
	return new O({
		uniforms: Si(e, t, n),
		side: E,
		transparent: !0,
		depthWrite: !1,
		vertexShader: `${bi}
      attribute vec3 position,other,strokeColor;
      attribute vec2 corner;
      attribute float alpha,surfaceDepth;
      varying vec3 vColor;
      varying float vAlpha;
      void main(){
        vec4 a=scenePosition(position),b=scenePosition(other);
        vec2 delta=(b.xy/b.w-a.xy/a.w)*viewport;
        vec2 normal=normalize(vec2(-delta.y,delta.x));
        a.xy+=normal*corner.x*corner.y*view.z/viewport*a.w;
        a.z=-(surfaceDepth*.01+.000001)*a.w;
        gl_Position=a;vColor=strokeColor;vAlpha=alpha;
      }`,
		fragmentShader: `${xi}
      varying vec3 vColor;varying float vAlpha;
      void main(){gl_FragColor=vec4(vColor,vAlpha*visibility(scenePixel()));}`
	});
}
function Ti(e, t, n, r, i = t) {
	return new O({
		uniforms: {
			...Si(e, t, n),
			map: { value: r },
			patchBounds: { value: new ie(...i) }
		},
		side: E,
		transparent: !0,
		depthWrite: !1,
		depthTest: !1,
		vertexShader: `${bi}attribute vec3 position;void main(){gl_Position=scenePosition(position);}`,
		fragmentShader: `${xi}
      uniform sampler2D map;uniform vec4 patchBounds;
      void main(){vec2 p=scenePixel();vec2 uv=vec2((p.x-patchBounds.x)/patchBounds.z,1.-(p.y-patchBounds.y)/patchBounds.w);vec4 color=texture2D(map,uv);gl_FragColor=vec4(color.rgb,color.a*visibility(p));}`
	});
}
//#endregion
//#region src/games/clankcatacombs/floor-texture.ts
var Ei = (e) => (e.match(/[-+]?(?:\d*\.?\d+)(?:e[-+]?\d+)?/gi) ?? []).map(Number), Di = (e) => [...e.matchAll(/url\(#([^)]*)\)/g)].map((e) => e[1]);
function Oi(e) {
	let t = (t) => Number(e.getAttribute(t) ?? 0), n = t("stroke-width") / 2 + 1;
	if (["circle", "ellipse"].includes(e.localName)) {
		let r = t(e.localName === "circle" ? "r" : "rx") + n, i = t(e.localName === "circle" ? "r" : "ry") + n;
		return [
			t("cx") - r,
			t("cy") - i,
			r * 2,
			i * 2
		];
	}
	if (e.localName === "rect") return [
		t("x") - n,
		t("y") - n,
		t("width") + n * 2,
		t("height") + n * 2
	];
	let r;
	if (["polygon", "polyline"].includes(e.localName)) r = Ei(e.getAttribute("points") ?? "");
	else if (e.localName === "path") {
		let t = e.getAttribute("d") ?? "";
		if (t.replace(/[-+]?(?:\d*\.?\d+)(?:e[-+]?\d+)?/gi, "").replace(/[MLZ\s,]/g, "")) return null;
		r = Ei(t);
	} else return null;
	if (!r.length) return null;
	let i = Infinity, a = Infinity, o = -Infinity, s = -Infinity;
	for (let e = 0; e < r.length; e += 2) i = Math.min(i, r[e]), o = Math.max(o, r[e]), a = Math.min(a, r[e + 1]), s = Math.max(s, r[e + 1]);
	return [
		i - n,
		a - n,
		o - i + n * 2,
		s - a + n * 2
	];
}
function ki(e) {
	let t = new DOMParser().parseFromString(`<svg xmlns="http://www.w3.org/2000/svg">${e}</svg>`, "image/svg+xml").documentElement, n = /* @__PURE__ */ new Map(), r = [];
	function i(e, t) {
		if (e.localName === "defs") {
			for (let t of e.children) t.id && n.set(t.id, t.outerHTML);
			return null;
		}
		let r = t || e.hasAttribute("transform") || e.hasAttribute("filter");
		return e.localName === "g" ? {
			markup: e.cloneNode(!1).outerHTML.replace(/\s*\/>$/, ">").replace(/<\/g>$/, ""),
			bounds: null,
			children: [...e.children].map((e) => i(e, r)).filter((e) => e !== null)
		} : {
			markup: e.outerHTML,
			bounds: r ? null : Oi(e)
		};
	}
	for (let e of t.children) {
		let t = i(e, !1);
		t && r.push(t);
	}
	return (e) => {
		let [t, i, a, o] = e, s = (e) => {
			let n = e.bounds;
			return n && (n[0] > t + a || n[0] + n[2] < t || n[1] > i + o || n[1] + n[3] < i) ? "" : e.children ? e.markup + e.children.map(s).join("") + "</g>" : e.markup;
		}, c = r.map(s).join(""), l = new Set(Di(c)), u = [];
		for (let e of l) {
			let t = n.get(e);
			if (t) {
				u.push(t);
				for (let e of Di(t)) l.add(e);
			}
		}
		return `<defs>${u.join("")}</defs>${c}`;
	};
}
//#endregion
//#region src/games/clankcatacombs/scene-three-layers.tsx
function Ai(e, t, n, r, i) {
	for (let a of e) a.uniforms.viewport.value.set(n, r), a.uniforms.view.value.set(t.x, t.y, t.scale), a.uniforms.pixelRatio.value = i;
}
function ji(e, t) {
	let { gl: n, size: i, invalidate: a } = ee();
	r(() => {
		Ai(e, t, i.width, i.height, n.getPixelRatio()), a();
	}, [
		e,
		i,
		t,
		n,
		a
	]), r(() => () => {
		for (let t of e) t.dispose();
	}, [e]);
}
async function Mi(e, t, n) {
	let [r, i, a, o] = t, s = new Image();
	s.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${Math.ceil(a * n)}" height="${Math.ceil(o * n)}" viewBox="${r} ${i} ${a} ${o}">${e}</svg>`)}`, await s.decode();
	let c = document.createElement("canvas");
	c.width = s.width, c.height = s.height, c.getContext("2d").drawImage(s, 0, 0);
	let l = new T(c);
	return l.minFilter = ne, l.magFilter = ne, l.generateMipmaps = !1, l;
}
function Ni(e, t, n) {
	let [i, a] = c(null), [o, s] = c(!1), l = t.join(",");
	if (r(() => {
		let t = !1;
		return Mi(e, l.split(",").map(Number), n).then((e) => {
			t ? e.dispose() : a(e);
		}).catch(() => {
			t || s(!0);
		}), () => {
			t = !0;
		};
	}, [
		e,
		l,
		n
	]), r(() => () => i?.dispose(), [i]), o) throw Error("Scene texture could not be decoded");
	return i;
}
function Pi({ faces: e, scene: t, fade: n, view: i, order: a = 0, visible: s = !0 }) {
	let c = o(() => _i(e, t.camera), [e, t.camera]), l = o(() => vi(c.strokes), [c]), u = o(() => [Ci(t.camera, t.three.bounds, n), wi(t.camera, t.three.bounds, n)], [t, n]);
	return ji(u, i), r(() => () => {
		c.geometry.dispose(), l.dispose();
	}, [c, l]), /* @__PURE__ */ _("group", {
		visible: s,
		children: [/* @__PURE__ */ g("mesh", {
			geometry: c.geometry,
			material: u[0],
			frustumCulled: !1,
			renderOrder: a
		}), /* @__PURE__ */ g("mesh", {
			geometry: l,
			material: u[1],
			frustumCulled: !1,
			renderOrder: a + 1
		})]
	});
}
function Fi({ pawn: e, scene: t, fade: n, view: r }) {
	let { hidden: i } = b(Dt(e.rid, e.room)), a = JSON.stringify(e), s = o(() => yi(JSON.parse(a), t.camera), [a, t.camera]);
	return /* @__PURE__ */ g(Pi, {
		faces: s,
		scene: t,
		fade: n,
		view: r,
		order: 2 + (e.layer ?? e.number) * 2,
		visible: !i
	});
}
function Ii({ scene: e, floorSource: t, fade: n, view: i, bounds: a, resolution: s, tileKey: c, onReady: l, visible: u }) {
	let d = 1 / s, [f, p, m, h] = a, _ = [
		f - d,
		p - d,
		m + d * 2,
		h + d * 2
	], v = Ni(o(() => t([
		f - d,
		p - d,
		m + d * 2,
		h + d * 2
	]), [
		t,
		f,
		p,
		m,
		h,
		d
	]), _, s), y = o(() => {
		let t = [
			[f, p],
			[f + m, p],
			[f + m, p + h],
			[f, p + h]
		].map((t) => hi(e.camera, t));
		return new te().setAttribute("position", new D([
			0,
			1,
			2,
			0,
			2,
			3
		].flatMap((e) => t[e]), 3));
	}, [
		f,
		p,
		m,
		h,
		e.camera
	]), b = o(() => v ? [Ti(e.camera, e.three.bounds, n, v, [
		f - d,
		p - d,
		m + d * 2,
		h + d * 2
	])] : [], [
		v,
		e,
		n,
		f,
		p,
		m,
		h,
		d
	]);
	return ji(b, i), r(() => () => y.dispose(), [y]), r(() => {
		v && l(c);
	}, [
		v,
		l,
		c
	]), b.length ? /* @__PURE__ */ g("mesh", {
		geometry: y,
		material: b[0],
		visible: u,
		frustumCulled: !1,
		renderOrder: -2
	}) : null;
}
function Li({ scene: e, view: t, extraFaces: i, pawns: a, onStats: s }) {
	let { gl: l, size: u, invalidate: d } = ee(), f = e.three, p = o(() => ki(f.floor), [f.floor]), m = Math.min(2, 4096 / Math.max(f.bounds[2], f.bounds[3]), l.capabilities.maxTextureSize / Math.max(f.bounds[2], f.bounds[3])), v = Ni(f.mask, f.bounds, m), y = 2 ** Math.ceil(Math.log2(Math.max(.125, t.scale * l.getPixelRatio()))), b = Math.min(512, 2 ** Math.floor(Math.log2((Math.min(2048, l.capabilities.maxTextureSize) - 2) / y))), [x, S, C, te] = f.bounds, T = b * .15, E = Math.max(Math.floor(x / b), Math.floor((t.x - u.width / t.scale / 2 - T) / b)), D = Math.max(Math.floor(S / b), Math.floor((t.y - u.height / t.scale / 2 - T) / b)), ne = Math.min(Math.floor((x + C) / b), Math.floor((t.x + u.width / t.scale / 2 + T) / b)), O = Math.min(Math.floor((S + te) / b), Math.floor((t.y + u.height / t.scale / 2 + T) / b)), k = [];
	for (let e = D; e <= O; e++) for (let t = E; t <= ne; t++) k.push({
		key: `${y}:${t}:${e}`,
		bounds: [
			t * b,
			e * b,
			b,
			b
		],
		resolution: y
	});
	let [A, re] = c(/* @__PURE__ */ new Map()), ie = n((e) => {
		re((t) => {
			if (t.get(e) === f) return t;
			let n = t.values().next().value === f ? new Map(t) : /* @__PURE__ */ new Map();
			return n.set(e, f), n.size > 256 && n.delete(n.keys().next().value), n;
		}), d();
	}, [f, d]);
	r(() => {
		d();
	}, [A, d]);
	let ae = !!v && k.every((e) => A.get(e.key) === f), oe = k.map((e) => e.key).join("|"), [se, j] = c(null);
	ae && (se?.data !== f || se.key !== oe) && j({
		data: f,
		key: oe,
		patches: k
	});
	let M = se?.data === f ? se.patches : [], ce = new Set(M.map((e) => e.key)), le = new Map([...M, ...k].map((e) => [e.key, e])), ue = new Set(k.map((e) => e.key)), N = JSON.stringify(a), P = o(() => JSON.parse(N), [N]);
	return w(() => {
		ae && s?.({
			triangles: l.info.render.triangles,
			faces: f.faces.length,
			calls: l.info.render.calls,
			textureWidth: b * y + 2,
			textureHeight: b * y + 2
		});
	}), v ? /* @__PURE__ */ _(h, { children: [
		[...le.values()].map((n) => /* @__PURE__ */ g(Ii, {
			tileKey: n.key,
			scene: e,
			floorSource: p,
			fade: v,
			view: t,
			bounds: n.bounds,
			resolution: n.resolution,
			onReady: ie,
			visible: ae ? ue.has(n.key) : M.length ? ce.has(n.key) : ue.has(n.key)
		}, n.key)),
		/* @__PURE__ */ g(Pi, {
			faces: f.faces,
			scene: e,
			fade: v,
			view: t
		}),
		i.length > 0 && /* @__PURE__ */ g(Pi, {
			faces: i,
			scene: e,
			fade: v,
			view: t,
			order: 2
		}),
		P.map((n) => /* @__PURE__ */ g(Fi, {
			pawn: n,
			scene: e,
			fade: v,
			view: t
		}, n.rid))
	] }) : null;
}
//#endregion
//#region src/games/clankcatacombs/board-three.tsx
var Ri = [], zi = [];
function Bi() {
	try {
		let e = document.createElement("canvas").getContext("webgl2");
		return e ? (e.getExtension("WEBGL_lose_context")?.loseContext(), !0) : !1;
	} catch {
		return !1;
	}
}
function Vi({ scene: e, view: t, width: r, height: o, extraFaces: s = Ri, pawns: l = zi, pawnLabels: u = "", onStats: d, onRecoveryChange: f }) {
	let p = i().replace(/[^a-z0-9]/gi, ""), m = e.three, [v] = c(() => Bi()), [y, b] = c(!v);
	a(() => {
		v || f?.(!0);
	}, [v, f]);
	let x = n((e) => {
		b(e), f?.(e);
	}, [f]), S = `${t.x - r / t.scale / 2} ${t.y - o / t.scale / 2} ${r / t.scale} ${o / t.scale}`, w = (e, t, n = "") => /* @__PURE__ */ g("svg", {
		className: "cc-three-overlay",
		width: r,
		height: o,
		viewBox: S,
		"aria-hidden": "true",
		pointerEvents: "none",
		children: t ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ g("mask", {
			id: p + n,
			maskUnits: "userSpaceOnUse",
			x: m.bounds[0],
			y: m.bounds[1],
			width: m.bounds[2],
			height: m.bounds[3],
			children: /* @__PURE__ */ g("g", { dangerouslySetInnerHTML: { __html: m.mask } })
		}) }), /* @__PURE__ */ g("g", {
			mask: `url(#${p + n})`,
			dangerouslySetInnerHTML: { __html: e }
		})] }) : /* @__PURE__ */ g("g", { dangerouslySetInnerHTML: { __html: e } })
	});
	return /* @__PURE__ */ g("div", {
		className: "cc-three-scene",
		"data-renderer": y ? "svg" : "three",
		style: {
			position: "relative",
			width: r,
			height: o,
			overflow: "hidden"
		},
		children: v ? /* @__PURE__ */ _(h, { children: [
			!y && w(m.atmosphere, !0, "atmosphere"),
			/* @__PURE__ */ g(C, {
				recoveryFallback: w(e.markup, !1),
				onRecoveryChange: x,
				frameloop: "demand",
				dpr: [1, 2],
				gl: {
					antialias: !0,
					alpha: !0,
					powerPreference: "high-performance"
				},
				style: {
					position: "absolute",
					inset: 0
				},
				children: /* @__PURE__ */ g(Li, {
					scene: e,
					view: t,
					extraFaces: s,
					pawns: l,
					onStats: d
				})
			}),
			!y && w(m.foreground, !0, "foreground"),
			!y && w(m.labels + u, !1)
		] }) : w(e.markup, !1)
	});
}
//#endregion
//#region src/games/clankcatacombs/board-backdrop.tsx
function Hi({ scene: e, geometry: t, width: n, height: r, pawns: i, onRecoveryChange: o }) {
	let [s, l] = c({
		x: e.width / 2,
		y: e.height / 2,
		scale: 1
	});
	return a(() => {
		let e = t.current, n = e?.parentElement, r = e?.ownerSVGElement;
		if (!e || !n || !r) return;
		let i = () => {
			let t = e.getScreenCTM(), n = r.getBoundingClientRect();
			if (!t || !t.a || !n.width || !n.height) return;
			let i = Math.hypot(t.a, t.b);
			l({
				x: (n.width / 2 - t.e + n.left) / i,
				y: (n.height / 2 - t.f + n.top) / i,
				scale: i
			});
		}, a = new MutationObserver(i);
		return a.observe(n, {
			attributes: !0,
			attributeFilter: ["transform"]
		}), i(), () => a.disconnect();
	}, [
		t,
		n,
		r
	]), /* @__PURE__ */ g("div", {
		className: "cc-three-backdrop",
		children: /* @__PURE__ */ g(Vi, {
			scene: e,
			view: s,
			width: n,
			height: r,
			pawns: i,
			onRecoveryChange: o
		})
	});
}
//#endregion
//#region src/games/clankcatacombs/board-scene.tsx
var Ui = {
	"free-prisoner": "Ⅲ↗",
	aegis: "⛨",
	altar: "♜",
	bazaar: "⚖",
	temple: "♜",
	hoard: "♛",
	medusa: "♟",
	sphinx: "♞",
	statue: "♜",
	guardian: "♟",
	harpy: "♠",
	fate: "☾",
	lyre: "♫",
	imp: "☿",
	pit: "×",
	lake: "≈",
	tower: "♜",
	chute: "⇓"
};
function Wi({ rx: e, ry: t }) {
	let n = S();
	return /* @__PURE__ */ _("g", {
		className: "cc-target-outline",
		pointerEvents: "none",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ g("ellipse", {
			rx: e,
			ry: t,
			fill: "none",
			className: "cc-target-base",
			vectorEffect: "non-scaling-stroke"
		}), /* @__PURE__ */ g("ellipse", {
			rx: e,
			ry: t,
			fill: "none",
			className: "cc-target-march",
			vectorEffect: "non-scaling-stroke",
			strokeDasharray: "6 5",
			children: !n && /* @__PURE__ */ g("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-11",
				dur: "0.8s",
				repeatCount: "indefinite"
			})
		})]
	});
}
function Gi({ name: e, color: t, x: n, y: r }) {
	let i = Array.from(e), a = i.length > 14 ? `${i.slice(0, 13).join("")}…` : e, o = Math.max(24, Array.from(a).reduce((e, t) => e + (/[\u0020-\u007e]/.test(t) ? 3.3 : 5.5), 10));
	return /* @__PURE__ */ _("g", {
		transform: `translate(${n},${r})`,
		pointerEvents: "none",
		"aria-hidden": "true",
		className: "cc-pawn-name",
		children: [/* @__PURE__ */ g("path", {
			d: `M${-o + 4} -13H${o - 4}L${o} -9V5L${o - 4} 9H4L0 13 -4 9H${-o + 4}L${-o} 5V-9Z`,
			fill: t,
			stroke: "#e6d0a2",
			strokeWidth: "1"
		}), /* @__PURE__ */ g("text", {
			y: "2",
			textAnchor: "middle",
			fontSize: "11",
			fill: "#fff2d4",
			fontWeight: "750",
			children: a
		})]
	});
}
function Ki({ rid: e, room: t, children: n }) {
	let { hidden: r } = b(Dt(e, t));
	return /* @__PURE__ */ g("g", {
		visibility: r ? "hidden" : void 0,
		children: n
	});
}
function qi({ pub: e, priv: t, members: n, myRid: l, onRoom: u, onRoute: f, preview: p = 0, selectedRoom: m }) {
	let b = d(), S = i().replace(/[^a-z0-9]/gi, ""), [C, w] = c("catacombs"), [ee, te] = c(0), [T, E] = c(0), D = s(null), [ne, O] = c(""), k = s(null), A = x(), re = s(null), ie = o(() => ui(), []), [ae, oe] = c(!1), [se, j] = c(null), [M, ce] = c(""), [le, ue] = c({
		key: "",
		serial: 0
	});
	r(() => {
		let e = new ResizeObserver(([e]) => O(`${Math.round(e.contentRect.width)}:${Math.round(e.contentRect.height)}`));
		return e.observe(D.current), () => e.disconnect();
	}, []);
	let N = e.players.find((e) => e.rid === l), P = e.placement ? "catacombs" : C, F = JSON.stringify([...e.tiles.filter((e) => e.zone === P), ...e.placement ? [{
		id: -1,
		kind: e.placement.kind,
		x: e.placement.x,
		y: e.placement.y,
		rotation: p,
		zone: "catacombs"
	}] : []]), de = o(() => JSON.parse(F), [F]), I = {
		id: `cc-${S}`,
		tiles: de,
		openedLocks: e.openedLocks,
		rooms: e.rooms.filter((e) => de.some((t) => e.id.startsWith(`${t.id}/`))).map(({ id: e, secrets: t, artifacts: n, idols: r, opened: i }) => ({
			id: e,
			secrets: t,
			artifacts: n,
			idols: r,
			opened: i,
			marks: {},
			monsters: [],
			prisoner: null,
			chute: !1
		}))
	}, fe = `${ee}:${P}:${ne}`, pe = `${ee}:${P}`, me = JSON.stringify(I), he = o(() => ie.build(me, pe), [
		ie,
		me,
		pe
	]);
	a(() => {
		if (!A) return;
		let t = /* @__PURE__ */ new Map();
		for (let [e, n] of Object.entries(he.positions)) t.set(Ot(e), n);
		for (let [e, n] of Object.entries(he.artifactPositions)) t.set(`cc-artifact:${e}`, n);
		for (let [e, n] of Object.entries(he.bridgePaths)) {
			let [r, i] = e.split(">");
			n.forEach((e, n) => t.set(At(r, i, n), e));
		}
		for (let e of de) {
			let n = he.tileShapes[e.id];
			n.forEach((n, r) => t.set(`cc-corner:${e.id}:${r}`, n)), t.set(kt(e.id, e.rotation), n[0]), t.set(`cc-tile:${e.id}`, n[0]);
		}
		for (let n of Object.keys(he.positions)) {
			let r = e.players.filter((e) => e.room === n && e.state === "active"), i = Kr(r.length), a = he.positions[n];
			r.forEach((e, r) => t.set(Dt(e.rid, n), [a[0] + i[r][0], a[1] + i[r][1] + 6]));
		}
		let n = [...t.keys(), "cc-map"];
		for (let [e, [n, r]] of t) A.registerProbe(e, () => {
			let e = k.current?.getScreenCTM();
			return e ? {
				x: n * e.a + r * e.c + e.e,
				y: n * e.b + r * e.d + e.f,
				w: Math.hypot(e.a, e.b),
				h: Math.hypot(e.c, e.d)
			} : null;
		});
		return A.registerProbe("cc-map", () => {
			let e = D.current, t = e?.getBoundingClientRect();
			if (!e || !t) return null;
			let n = e.closest(".cc-screen")?.querySelector(".cc-placement")?.getBoundingClientRect(), r = Math.max(t.top, ...Array.from(e.querySelectorAll(".cc-map-heading,.cc-map-tools")).map((e) => e.getBoundingClientRect().bottom + 3)), i = n && n.top < t.bottom && n.bottom > t.top ? Math.max(r, n.top - 4) : t.bottom;
			return {
				x: t.left,
				y: r,
				w: t.width,
				h: Math.max(0, i - r)
			};
		}), () => {
			for (let e of n) A.registerProbe(e, null);
		};
	}, [
		A,
		he,
		de,
		e.players
	]);
	let L = (t?.moves ?? []).filter((e) => t?.actions.some((t) => t.type === "move" && t.route === e.id)), ge = new Set(L.map((e) => e.to)), _e = de.filter((e) => e.id >= 0).flatMap((e) => we[e.kind].rooms.map((t) => ({
		tile: e,
		room: t,
		key: B(e.id, t.id)
	}))).sort((e, t) => he.positions[e.key][1] - he.positions[t.key][1]), ve = _e.flatMap(({ key: e }) => {
		let t = he.positions[e];
		return t ? [{
			key: `room:${e}`,
			rect: {
				x: t[0] - 48,
				y: t[1] - 34,
				w: 96,
				h: 68
			}
		}] : [];
	}), ye = L.filter((e) => !e.to).flatMap((e) => {
		let t = he.frontiers.find((t) => e.id.split(">").includes(t.key) || e.slot && t.key.startsWith(`uw-${e.slot}/`));
		return t ? [{
			move: e,
			point: t.point
		}] : [];
	});
	for (let { move: e, point: t } of ye) ve.push({
		key: `route:${e.id}`,
		rect: {
			x: t[0] - 24,
			y: t[1] - 24,
			w: 48,
			h: 48
		}
	});
	let be = ve.find((e) => e.key === `room:${N?.room}`)?.rect, xe = [...e.log].reverse().find((e) => e.event === "move" || e.event === "discover"), R = xe?.room ? he.positions[xe.room] : void 0, Se = e.placement ? he.tileShapes[-1] : void 0, Ce = e.placement ? `tile:${e.placement.kind}:${e.placement.x}:${e.placement.y}` : xe?.room ?? "", z = le.serial;
	le.key !== Ce && (z++, ue({
		key: Ce,
		serial: z
	}));
	let Te = Se ? {
		x: Math.min(...Se.map((e) => e[0])),
		y: Math.min(...Se.map((e) => e[1])),
		w: Math.max(...Se.map((e) => e[0])) - Math.min(...Se.map((e) => e[0])),
		h: Math.max(...Se.map((e) => e[1])) - Math.min(...Se.map((e) => e[1]))
	} : R ? {
		x: R[0] - 55,
		y: R[1] - 65,
		w: 110,
		h: 110
	} : null, Ee = T && M === Ce ? be : Te, De = L.find((e) => e.to === m)?.id.split(">") ?? [], V = De.map((e, t) => {
		let n = he.positions[e], r = De[t - 1], i = /\/(P|Q|R|return)$/;
		return n ? `${!r || !he.positions[r] || i.test(r) && i.test(e) ? "M" : "L"}${n.join(" ")}` : "";
	}).join(" "), H = (e) => n.find((t) => t.rid === e)?.name ?? e, Oe = (t) => v[n.find((e) => e.rid === t)?.colorIndex ?? Math.max(0, e.players.findIndex((e) => e.rid === t))].hex, ke = JSON.stringify(e.players.map((e, t) => [Oe(e.rid), t + 1])), Ae = o(() => ae ? JSON.parse(ke).map(([e, t]) => `<symbol id="cc-${S}-pawn-${t}" overflow="visible">${Gr(e, t, t - 1)}</symbol>`).join("") : "", [
		ke,
		S,
		ae
	]), je = _e.flatMap(({ key: t }) => {
		let n = e.players.filter((e) => e.room === t && e.state === "active"), r = Kr(n.length), [i, a] = he.positions[t];
		return n.map((n, o) => ({
			rid: n.rid,
			room: t,
			color: Oe(n.rid),
			number: e.players.indexOf(n) + 1,
			x: i + r[o][0],
			y: a + r[o][1] + 6
		})).sort((e, t) => e.y - t.y);
	}).map((e, t) => ({
		...e,
		layer: t
	})), [Me, Ne] = ne.split(":").map(Number);
	return /* @__PURE__ */ _("section", {
		ref: D,
		className: "cc-map",
		"aria-label": b(X[P]),
		onPointerLeave: () => j(null),
		onPointerDownCapture: () => {
			re.current = null;
		},
		onPointerCancel: () => {
			re.current = null;
		},
		onClickCapture: (e) => {
			let t = re.current;
			re.current = null, e.detail !== 0 && k.current?.ownerSVGElement?.contains(e.target) && (e.stopPropagation(), t?.startsWith("room:") ? u(t.slice(5)) : t?.startsWith("route:") && f(t.slice(6)));
		},
		children: [
			/* @__PURE__ */ _("div", {
				className: "cc-map-heading",
				children: [/* @__PURE__ */ g("strong", { children: b(X[P]) }), /* @__PURE__ */ g("small", { children: b(X.tiles, { n: P === "catacombs" ? e.tileCount : e.underworldTileCount }) })]
			}),
			Me > 0 && Ne > 0 && /* @__PURE__ */ g(Hi, {
				scene: he,
				geometry: k,
				width: Me,
				height: Ne,
				pawns: je,
				onRecoveryChange: oe
			}),
			/* @__PURE__ */ _(y, {
				sheetW: he.width,
				sheetH: he.height,
				fitKey: fe,
				eligible: ve,
				highlight: "off",
				onTapEligible: (e) => {
					re.current = e;
				},
				focus: Ee ? {
					rect: Ee,
					key: T * 1e5 + z
				} : null,
				children: [/* @__PURE__ */ g("defs", { dangerouslySetInnerHTML: { __html: Ae } }), /* @__PURE__ */ _("g", {
					ref: k,
					children: [
						V && /* @__PURE__ */ g("path", {
							d: V,
							fill: "none",
							stroke: "#86cbbb",
							strokeWidth: "4",
							strokeOpacity: ".75",
							strokeLinecap: "round",
							strokeLinejoin: "round",
							pointerEvents: "none"
						}),
						Object.entries(he.positions).filter(([e]) => /\/(P|Q|R|return)$/.test(e)).map(([e, [t, n]]) => /* @__PURE__ */ _("g", {
							transform: `translate(${t},${n})`,
							className: "cc-map-portal",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ g("ellipse", {
								rx: "13",
								ry: "9",
								fill: "#161526",
								stroke: "#9b7fb7",
								strokeWidth: "2"
							}), /* @__PURE__ */ g("path", {
								d: "M-7 3q-9-10 3-12t5 13q-10 8-17-1",
								fill: "none",
								stroke: "#c2a1d8",
								strokeWidth: "2"
							})]
						}, e)),
						_e.map(({ tile: t, room: n, key: r }) => {
							let [i, a] = he.positions[r], o = e.rooms.find((e) => e.id === r), s = e.players.filter((e) => e.room === r && e.state === "active"), c = Kr(s.length), d = s.findIndex((e) => e.rid === l), f = s.findIndex((e) => e.rid === se), p = Math.min(0, ...c.map((e) => e[1])) - 54, v = n.features.find((e) => Ui[e]), y = n.features.find((e) => !/^artifact|safe|minor|chest/.test(e));
							return /* @__PURE__ */ _("g", {
								transform: `translate(${i},${a})`,
								role: "button",
								tabIndex: 0,
								"aria-label": [or(e, r, b), ...s.map((e) => H(e.rid))].join(" · "),
								onClick: () => u(r),
								onKeyDown: (e) => {
									(e.key === "Enter" || e.key === " ") && (e.preventDefault(), u(r));
								},
								className: "cc-map-room",
								"data-legal": ge.has(r),
								"data-selected": m === r,
								children: [
									/* @__PURE__ */ g("title", { children: or(e, r, b) }),
									/* @__PURE__ */ g("ellipse", {
										rx: "48",
										ry: "31",
										fill: "transparent",
										className: "cc-room-hit"
									}),
									ge.has(r) && /* @__PURE__ */ g(Wi, {
										rx: 48,
										ry: 29
									}),
									m === r && /* @__PURE__ */ g("ellipse", {
										rx: "43",
										ry: "25",
										fill: "none",
										stroke: "#e7d5a1",
										strokeWidth: "2"
									}),
									v && /* @__PURE__ */ g("text", {
										x: "19",
										y: "7",
										fill: "#e6d6ac",
										fontSize: "20",
										paintOrder: "stroke",
										stroke: "#16131b",
										strokeWidth: "2",
										children: Ui[v]
									}),
									y && /* @__PURE__ */ g("text", {
										className: "cc-map-room-label",
										y: Math.max(41, ...c.map((e) => e[1] + 29)),
										textAnchor: "middle",
										fill: "#e6d8ba",
										fontSize: "12",
										paintOrder: "stroke",
										stroke: "#080b12",
										strokeWidth: "3",
										children: ar(y, b)
									}),
									o?.chute && !n.features.includes("chute") && /* @__PURE__ */ g("text", {
										x: "27",
										y: "-12",
										fill: "#dfcea8",
										fontSize: "18",
										children: "⇓"
									}),
									n.features.filter((e) => /^ladder[A-E]$/.test(e)).map((e) => /* @__PURE__ */ _("text", {
										x: "-23",
										y: "7",
										fill: "#d8bce0",
										fontSize: "14",
										children: ["↕", e.slice(6)]
									}, e)),
									we[t.kind].haunted && n.id === we[t.kind].rooms[0].id && /* @__PURE__ */ g("path", {
										d: "M-35-19v-10q0-10 8-10t8 10v10l-5-4-4 4-3-4Z",
										fill: "#aac6c0",
										stroke: "#32474b"
									}),
									Object.values(o?.marks ?? {}).map((e, t) => /* @__PURE__ */ g("rect", {
										x: -28 + t * 11,
										y: "18",
										width: "9",
										height: "9",
										fill: Oe(e),
										stroke: "#e8dab7",
										strokeWidth: "1",
										children: /* @__PURE__ */ g("title", { children: H(e) })
									}, t)),
									s.map((e, t) => ({
										player: e,
										point: c[t]
									})).sort((e, t) => e.point[1] - t.point[1]).map(({ player: t, point: [n, i] }) => /* @__PURE__ */ g("g", {
										className: "cc-map-pawn",
										transform: `translate(${n},${i + 6})`,
										onPointerEnter: (e) => {
											e.pointerType !== "touch" && j(t.rid);
										},
										onPointerLeave: () => j(null),
										children: /* @__PURE__ */ _(Ki, {
											rid: t.rid,
											room: r,
											children: [ae ? /* @__PURE__ */ g("use", { href: `#cc-${S}-pawn-${e.players.indexOf(t) + 1}` }) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("ellipse", {
												cy: "-24",
												rx: "19",
												ry: "32",
												fill: "transparent"
											}), /* @__PURE__ */ g("text", {
												x: "2.86",
												y: "6.35",
												textAnchor: "middle",
												fontFamily: "Arial,sans-serif",
												fontSize: "6.5",
												fill: "#f1d7a2",
												stroke: "#252331",
												strokeWidth: "1.5",
												paintOrder: "stroke",
												fontWeight: "700",
												children: e.players.indexOf(t) + 1
											})] }), /* @__PURE__ */ g("title", { children: H(t.rid) })]
										})
									}, t.rid)),
									d >= 0 && /* @__PURE__ */ g(Ki, {
										rid: l,
										room: r,
										children: /* @__PURE__ */ g(Gi, {
											name: H(l),
											color: Oe(l),
											x: c[d][0],
											y: p
										})
									}),
									f >= 0 && se !== l && /* @__PURE__ */ g(Ki, {
										rid: se,
										room: r,
										children: /* @__PURE__ */ g(Gi, {
											name: H(se),
											color: Oe(se),
											x: c[f][0],
											y: p - (d >= 0 ? 28 : 0)
										})
									})
								]
							}, r);
						}),
						ye.map(({ move: e, point: [t, n] }) => /* @__PURE__ */ _("g", {
							role: "button",
							tabIndex: 0,
							"aria-label": b(X.unknown),
							transform: `translate(${t},${n})`,
							className: "cc-map-frontier",
							onClick: () => f(e.id),
							onKeyDown: (t) => {
								(t.key === "Enter" || t.key === " ") && (t.preventDefault(), f(e.id));
							},
							children: [
								/* @__PURE__ */ g("circle", {
									r: "17",
									fill: "#0c121b"
								}),
								/* @__PURE__ */ g(Wi, {
									rx: 17,
									ry: 17
								}),
								/* @__PURE__ */ g("text", {
									y: "6",
									textAnchor: "middle",
									fill: "#ebd6a2",
									fontSize: "20",
									children: "?"
								})
							]
						}, e.id))
					]
				})]
			}),
			/* @__PURE__ */ _("div", {
				className: "cc-map-tools",
				children: [/* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => te(ee + 1),
					title: b(X.viewMap),
					"aria-label": b(X.viewMap),
					children: [/* @__PURE__ */ g(Hr, { kind: "compass" }), /* @__PURE__ */ g("span", { children: b(X.viewMap) })]
				}), /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => {
						let t = e.tiles.find((e) => e.id === Number(N?.room.split("/")[0]));
						t && w(t.zone), E(T + 1), ce(Ce);
					},
					title: b(X.locate),
					"aria-label": b(X.locate),
					children: [/* @__PURE__ */ g(Hr, { kind: "chevron" }), /* @__PURE__ */ g("span", { children: b(X.locate) })]
				})]
			}),
			e.config.underworld && /* @__PURE__ */ g("div", {
				className: "cc-map-zones",
				children: ["catacombs", "underworld"].map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					"data-selected": P === e,
					onClick: () => w(e),
					children: b(X[e])
				}, e))
			})
		]
	});
}
//#endregion
//#region src/games/clankcatacombs/available-outline.tsx
function Ji() {
	let e = S(), t = {
		x: 2,
		y: 2,
		rx: 4,
		fill: "none",
		vectorEffect: "non-scaling-stroke"
	};
	return /* @__PURE__ */ _("svg", {
		className: "cc-available-outline",
		"aria-hidden": "true",
		focusable: "false",
		children: [/* @__PURE__ */ g("rect", {
			...t,
			className: "cc-target-base"
		}), /* @__PURE__ */ g("rect", {
			...t,
			className: "cc-target-march",
			strokeDasharray: "6 5",
			children: !e && /* @__PURE__ */ g("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-11",
				dur: "0.8s",
				repeatCount: "indefinite"
			})
		})]
	});
}
//#endregion
//#region src/games/clankcatacombs/table-art.tsx
function Yi({ player: e, member: t, index: n, active: r, area: i, onClick: a }) {
	let o = d(), s = v[t?.colorIndex ?? n].hex, { ref: c } = b(`cc-seat:${i}:${e.rid}`);
	return /* @__PURE__ */ _("button", {
		ref: c,
		type: "button",
		className: "cc-seat",
		"data-active": r,
		onClick: a,
		children: [/* @__PURE__ */ _("span", {
			className: "cc-seat-portrait",
			children: [/* @__PURE__ */ g(Vr, {
				art: "portrait",
				variant: n
			}), /* @__PURE__ */ g("i", {
				style: { background: s },
				children: n + 1
			})]
		}), /* @__PURE__ */ _("span", {
			className: "cc-seat-info",
			children: [/* @__PURE__ */ g("strong", { children: t?.name ?? e.rid }), e.state === "active" ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", {
				className: "cc-seat-health",
				role: "img",
				"aria-label": o(X.health, { n: 10 - e.damage }),
				children: Array.from({ length: 10 }, (t, n) => /* @__PURE__ */ g("i", { "data-full": n < 10 - e.damage }, n))
			}), /* @__PURE__ */ _("small", { children: [
				/* @__PURE__ */ g(Hr, { kind: "coin" }),
				e.gold,
				/* @__PURE__ */ g(Hr, { kind: "key" }),
				e.picks
			] })] }) : /* @__PURE__ */ g("small", { children: o(X[e.state]) })]
		})]
	});
}
function Xi({ pub: e }) {
	let t = d();
	return /* @__PURE__ */ _("div", {
		className: "cc-rage-board",
		"aria-label": `${t(X.dragonRage)} · ${e.rage}`,
		children: [
			/* @__PURE__ */ g("strong", { children: t(X.dragonRage) }),
			/* @__PURE__ */ g(Vr, {
				art: "dragon",
				color: "#80aaa0"
			}),
			/* @__PURE__ */ g("div", {
				className: "cc-rage-track",
				children: [
					0,
					1,
					2,
					3,
					6,
					5,
					4
				].map((t) => /* @__PURE__ */ g("span", {
					"data-current": t === e.rage,
					children: /* @__PURE__ */ g("b", { children: t })
				}, t))
			})
		]
	});
}
function Zi({ pub: e, player: t }) {
	let n = d(), r = [
		[
			"skill",
			e.turn.skill,
			n(X.skill)
		],
		[
			"sword",
			e.turn.swords,
			n(X.swords)
		],
		[
			"boot",
			e.turn.boots,
			n(X.boots)
		],
		[
			"coin",
			t?.gold ?? 0,
			n(X.gold)
		],
		...e.config.underworld ? [[
			"gem",
			t?.silver ?? 0,
			n(X.silver)
		]] : [],
		[
			"key",
			t?.picks ?? 0,
			n(X.picks)
		],
		[
			"noise",
			t?.clank ?? 0,
			n(X.noise)
		]
	];
	return /* @__PURE__ */ g("div", {
		className: "cc-resources",
		"aria-label": n(X.turnResources),
		children: r.map(([e, t, n]) => /* @__PURE__ */ _("span", {
			title: `${n} ${t}`,
			"aria-label": `${n} ${t}`,
			children: [/* @__PURE__ */ g(Hr, {
				kind: e === "gem" ? "skill" : e,
				color: e === "skill" ? "#76b6d2" : e === "sword" ? "#d0aa7e" : e === "noise" ? "#af9bbe" : e === "gem" ? "#aea2c6" : "#d2b675"
			}), /* @__PURE__ */ g("b", { children: t })]
		}, e))
	});
}
function Qi({ count: e, label: t, onClick: n }) {
	let r = /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("div", {
		className: "cc-deck-back",
		children: [/* @__PURE__ */ g(Vr, {
			art: "dragon",
			color: "#c4a36b"
		}), /* @__PURE__ */ g("b", { children: e })]
	}), /* @__PURE__ */ g("span", { children: t })] });
	return n ? /* @__PURE__ */ g("button", {
		type: "button",
		className: "cc-deck",
		onClick: n,
		"aria-label": `${t} ${e}`,
		children: r
	}) : /* @__PURE__ */ g("div", {
		className: "cc-deck",
		"aria-label": `${t} ${e}`,
		children: r
	});
}
//#endregion
//#region src/games/clankcatacombs/notice-bridge.tsx
var $i = [], ea = 0, ta = /* @__PURE__ */ new Set(), na = (e) => (ta.add(e), () => {
	ta.delete(e);
}), ra = () => $i, ia = () => l(na, ra, ra);
function aa({ notice: e }) {
	return a(() => {
		$i = [...$i.slice(-23), {
			serial: ++ea,
			at: performance.now(),
			notice: e
		}];
		for (let e of ta) e();
	}, [e]), null;
}
//#endregion
//#region src/games/clankcatacombs/action-bubbles.tsx
var oa = 2600, sa = {
	skill: X.skill,
	swords: X.swords,
	boots: X.boots,
	gold: X.gold,
	silver: X.silver,
	picks: X.picks,
	mana: X.bubbleMana,
	clank: X.noise,
	health: X.bubbleHealth,
	artifact: X.bubbleArtifact,
	idol: X.bubbleIdol,
	trophy: X.bubbleTrophy,
	item: X.bubbleItem,
	fate: X.bubbleFate,
	rage: X.dragonRage,
	ghost: X.bubbleGhost,
	tile: X.bubbleTile
}, ca = {
	ignoreCave: X.bubbleIgnoreCave,
	"market-anywhere": X.bubbleMarket,
	ignoreMonsters: X.bubbleIgnoreMonsters,
	"reroll-tile": X.bubbleReroll,
	"reroll-no-artifact": X.bubbleRerollArtifact,
	"device-discount2": X.bubbleDeviceDiscount,
	"market-discount2": X.bubbleMarketDiscount,
	"counts-tome": X.bubbleCountsTome,
	"reverse-arrows": X.bubbleReverse,
	inspire: X.bubbleInspire
}, la = {
	play: X.play,
	acquire: X.bubbleAcquire,
	defeat: X.bubbleDefeat,
	device: X.bubbleDevice,
	arrive: X.bubbleArrive,
	react: X.react
};
function ua(e, t) {
	return e.kind in sa ? `${t(sa[e.kind])} ${e.n > 0 ? "+" : "−"}${Math.abs(e.n)}` : e.kind === "flag" ? ca[e.detail] ? t(ca[e.detail]) : "" : e.kind === "trash" ? t(X.bubbleTrash, { card: ir(e.detail ?? "", t) }) : e.kind === "reveal" ? t(X.bubbleReveal, { card: ir(e.detail ?? "", t) }) : t({
		draw: X.bubbleDraw,
		discard: X.bubbleDiscard,
		teleport: X.bubbleTeleport,
		prisoner: X.bubblePrisoner,
		secret: X.bubbleSecret,
		rotate: X.bubbleRotate,
		top: X.bubbleTop,
		replace: X.bubbleReplace,
		mirror: X.bubbleMirror
	}[e.kind], { n: e.n });
}
var da = [
	"health",
	"trash",
	"teleport",
	"artifact",
	"prisoner",
	"draw",
	"clank"
], fa = (e, t) => da.map((t) => e.find((e) => e.kind === t && e.n)).find(Boolean) ?? (t ? e.find((e) => e.n) : void 0), pa = (e, t) => Math.max(0, Math.min(e.x + e.w + 7, t.x + t.w + 7) - Math.max(e.x, t.x)) * Math.max(0, Math.min(e.y + e.h + 7, t.y + t.h + 7) - Math.max(e.y, t.y)), ma = (e, t, n) => Math.max(t, Math.min(e, Math.max(t, n)));
function ha({ pub: e, members: t, myRid: n }) {
	let r = d(), i = ia(), o = x(), { ref: l } = b("cc-bubble-layer"), [u] = c(() => i.at(-1)?.serial ?? 0), [f, p] = c(() => performance.now()), m = s(/* @__PURE__ */ new Map()), h = /* @__PURE__ */ new Map();
	for (let e of i) e.serial > u && f - e.at < oa && h.set(e.notice.id, e);
	let v = /* @__PURE__ */ new Map();
	for (let { notice: e, at: t } of h.values()) {
		let n = /* @__PURE__ */ new Set([e.rid, ...e.results.filter((e) => e.n).map((e) => e.rid)]);
		for (let r of n) {
			let n = v.get(r) ?? [];
			n.push({
				notice: e,
				at: t,
				recipient: r !== e.rid
			}), v.set(r, n);
		}
	}
	let y = [...v].map(([e, t]) => ({
		rid: e,
		rows: t.sort((e, t) => t.at - e.at).slice(0, 1)
	})).sort((e, t) => t.rows[0].at - e.rows[0].at), S = y.length > 0;
	a(() => {
		if (!S) return;
		let e = window.setInterval(() => p(performance.now()), 90);
		return () => clearInterval(e);
	}, [S]), a(() => {
		if (!S || !o) return;
		let t = 0, r = -100, i = (a) => {
			if (t = requestAnimationFrame(i), a - r < 32) return;
			r = a;
			let s = o.measure("cc-bubble-layer"), c = o.measure("cc-map");
			if (!s || !c) return;
			let l = [], u = e.players.flatMap((e) => {
				let t = o.measure(Dt(e.rid, e.room));
				return t && t.x >= c.x && t.x <= c.x + c.w && t.y >= c.y && t.y <= c.y + c.h ? [{
					x: t.x - 28 * t.w,
					y: t.y - (e.rid === n ? 86 : 63) * t.h,
					w: 56 * t.w,
					h: (e.rid === n ? 96 : 73) * t.h
				}] : [];
			});
			for (let t of y) {
				let r = m.current.get(t.rid), i = e.players.find((e) => e.rid === t.rid);
				if (!r || !i) continue;
				let a = Dt(t.rid, i.room), d = o.measure(a);
				if (o.isBusy(a)) {
					r.style.visibility = "hidden";
					continue;
				}
				let f = d && d.x >= c.x + 4 && d.x <= c.x + c.w - 4 && d.y >= c.y && d.y <= c.y + c.h, p = ["desktop", "mobile"].map((e) => o.measure(`cc-seat:${e}:${t.rid}`)).find((e) => e && e.w > 0 && e.h > 0 && e.x + e.w > s.x && e.x < s.x + s.w && e.y + e.h > s.y && e.y < s.y + s.h), h = f ? d : p;
				if (!h || c.h < 75 || c.w < 100) {
					r.style.visibility = "hidden";
					continue;
				}
				r.style.width = "max-content", r.style.maxWidth = `${Math.min(220, c.w - 12)}px`;
				let g = r.offsetHeight, _ = r.offsetWidth, v = f ? h.x : h.x + Math.min(h.w / 2, 28), y = f ? h.y - (t.rid === n ? 83 : 58) * h.h : h.y + h.h, b = c.x + 6, x = c.x + c.w - 6, S = c.y + 5, C = c.y + c.h - 5, w = v - _ / 2, ee = y - g - 10, te = [];
				for (let e of [
					ee,
					f ? h.y + 16 : y + 15,
					...l.flatMap((e) => [e.y - g - 9, e.y + e.h + 9]),
					...u.flatMap((e) => [e.y - g - 9, e.y + e.h + 9]),
					S,
					C - g
				]) for (let t of [
					w,
					v + 23,
					v - _ - 23,
					b,
					x - _
				]) te.push({
					x: ma(t, b, x - _),
					y: ma(e, S, C - g),
					w: _,
					h: g
				});
				let T = (e) => [...l, ...u].reduce((t, n) => t + pa(e, n) * 1e3, 0) + Math.hypot(e.x - w, e.y - ee), E = te.sort((e, t) => T(e) - T(t))[0];
				l.push(E), r.style.transform = `translate(${Math.round(E.x - s.x)}px,${Math.round(E.y - s.y)}px)`, r.style.visibility = "visible", r.style.opacity = String(ma((oa - (performance.now() - t.rows[0].at)) / 450, 0, 1)), r.dataset.side = y < E.y ? "top" : y > E.y + g ? "bottom" : v < E.x ? "left" : "right", r.style.setProperty("--cc-tip-x", `${ma(v - E.x, 17, _ - 17)}px`), r.style.setProperty("--cc-tip-y", `${ma(y - E.y, 17, g - 17)}px`);
			}
		};
		return i(performance.now()), () => cancelAnimationFrame(t);
	}, [
		S,
		o,
		y,
		e.players,
		n
	]);
	let C = (e) => t.find((t) => t.rid === e)?.name ?? e;
	return /* @__PURE__ */ g("div", {
		ref: l,
		className: "cc-bubble-layer",
		"aria-live": "polite",
		"aria-atomic": "false",
		children: y.map((e) => /* @__PURE__ */ g("div", {
			className: "cc-action-bubble",
			ref: (t) => {
				t ? m.current.set(e.rid, t) : m.current.delete(e.rid);
			},
			style: { visibility: "hidden" },
			children: e.rows.map((t) => {
				let n = fa(t.notice.results.filter((t) => t.rid === e.rid), t.recipient);
				return /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ _("div", {
					className: "cc-bubble-line",
					children: [/* @__PURE__ */ _("span", {
						className: "sr-only",
						children: [C(e.rid), " "]
					}), /* @__PURE__ */ g("strong", { children: t.recipient ? n && ua(n, r) : r(la[t.notice.verb], {
						card: ir(t.notice.card, r),
						item: ir(t.notice.card, r)
					}) })]
				}), !t.recipient && n && /* @__PURE__ */ g("small", {
					className: "cc-bubble-note",
					children: ua(n, r)
				})] }, t.notice.id);
			})
		}, e.rid))
	});
}
//#endregion
//#region src/games/clankcatacombs/card-popover.tsx
function ga({ card: e, anchor: t, action: n, enabled: r, onConfirm: o, onClose: c }) {
	let l = d(), u = i(), f = s(null), p = s(null), m = L[e], h = tr[e], v = (e) => {
		c(), e && t.isConnected && t.focus({ preventScroll: !0 });
	};
	a(() => {
		let e = f.current, n = t.closest(".cc-screen"), r = () => {
			if (!t.isConnected) {
				c();
				return;
			}
			let r = t.getBoundingClientRect(), i = n.getBoundingClientRect(), a = i.left + 8, o = i.top + 48, s = i.right - 8, l = i.bottom - 8;
			if (r.bottom <= o || r.top >= l || r.right <= a || r.left >= s || !r.width || !r.height) {
				c();
				return;
			}
			let u = Math.min(330, s - a);
			e.style.width = `${u}px`, e.style.maxHeight = `${l - o}px`;
			let d = !!t.closest(".cc-hand"), f = r.top - o - 10, p = l - r.bottom - 10, m = !d && r.left - a >= u + 10 ? "left" : !d && s - r.right >= u + 10 ? "right" : d || f >= e.offsetHeight || f >= p ? "above" : "below", h = m === "above" && f >= 150 ? f : m === "below" && p >= 150 ? p : l - o;
			e.style.maxHeight = `${Math.max(110, Math.min(l - o, h))}px`;
			let g = e.offsetHeight, _ = (e, t, n) => Math.max(t, Math.min(e, Math.max(t, n))), v = _(m === "left" ? r.left - u - 10 : m === "right" ? r.right + 10 : r.left, a, s - u), y = _(m === "above" ? r.top - g - 10 : m === "below" ? r.bottom + 10 : r.top, o, l - g);
			e.style.left = `${v}px`, e.style.top = `${y}px`, e.style.visibility = "visible", e.dataset.side = r.top >= y + g ? "bottom" : r.bottom <= y ? "top" : r.left >= v + u ? "right" : r.right <= v ? "left" : "none", e.style.setProperty("--cc-card-tip-x", `${_(r.left + r.width / 2 - v, 16, u - 16)}px`), e.style.setProperty("--cc-card-tip-y", `${_(r.top + r.height / 2 - y, 16, g - 16)}px`);
		};
		r();
		let i = new ResizeObserver(r);
		i.observe(e), i.observe(n), i.observe(t);
		let a = (n) => {
			n.target instanceof Element && n.target.closest(".cc-card-button,.cc-reserves>button,.cc-card-list>button") || n.target instanceof Node && !e.contains(n.target) && !t.contains(n.target) && c();
		}, o = (t) => {
			t.target instanceof Node && !e.contains(t.target) && c();
		}, s = (e) => {
			e.key === "Escape" && (e.preventDefault(), e.stopPropagation(), c(), t.isConnected && t.focus({ preventScroll: !0 }));
		};
		return document.addEventListener("click", a, !0), document.addEventListener("scroll", o, !0), document.addEventListener("keydown", s, !0), (p.current && !p.current.disabled ? p.current : e.querySelector(".cc-card-popover-close"))?.focus({ preventScroll: !0 }), () => {
			i.disconnect(), document.removeEventListener("click", a, !0), document.removeEventListener("scroll", o, !0), document.removeEventListener("keydown", s, !0);
		};
	}, [
		t,
		e,
		c
	]);
	let y = l(h.text);
	return /* @__PURE__ */ _("div", {
		ref: f,
		className: "cc-card-popover",
		role: "dialog",
		"aria-labelledby": u,
		style: { visibility: "hidden" },
		children: [
			/* @__PURE__ */ _("div", {
				className: "cc-card-popover-head",
				children: [
					/* @__PURE__ */ g("strong", {
						id: u,
						children: ir(e, l)
					}),
					m.points !== 0 && /* @__PURE__ */ g("small", { children: l(X.points, { n: m.points }) }),
					/* @__PURE__ */ g("button", {
						type: "button",
						className: "cc-card-popover-close",
						"aria-label": l("common.close"),
						onClick: () => v(!0),
						children: /* @__PURE__ */ g(ae, { size: 16 })
					})
				]
			}),
			/* @__PURE__ */ _("div", {
				className: "cc-card-popover-content",
				children: [
					(m.skill > 0 || m.swords > 0 || m.boots > 0) && /* @__PURE__ */ g("div", {
						className: "cc-card-popover-resources",
						children: [
							[
								"skill",
								m.skill,
								X.skill
							],
							[
								"sword",
								m.swords,
								X.swords
							],
							[
								"boot",
								m.boots,
								X.boots
							]
						].filter(([, e]) => e > 0).map(([e, t, n]) => /* @__PURE__ */ _("span", { children: [
							/* @__PURE__ */ g(Hr, {
								kind: e,
								color: e === "skill" ? "#77bbd4" : e === "sword" ? "#c87269" : "#d8b777"
							}),
							l(n),
							" ",
							t
						] }, e))
					}),
					(y || m.acquire.length > 0 || m.arrive.length > 0 || m.react) && /* @__PURE__ */ _("div", {
						className: "cc-card-popover-paper",
						children: [
							y && /* @__PURE__ */ g("p", { children: y }),
							m.acquire.length > 0 && /* @__PURE__ */ g("p", { children: l(X.acquireEffect, { text: l(h.acquire) }) }),
							m.arrive.length > 0 && /* @__PURE__ */ g("p", { children: l(X.arriveEffect, { text: l(h.arrive) }) }),
							m.react && /* @__PURE__ */ g("p", { children: l(X.reactEffect, { text: l(h.react) }) })
						]
					}),
					/* @__PURE__ */ _("div", {
						className: "cc-card-popover-marks",
						children: [
							!n && /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Hr, { kind: m.type === "monster" ? "sword" : "skill" }), m.cost] }),
							m.dragon && /* @__PURE__ */ g("span", { children: l(X.dragon) }),
							m.danger && /* @__PURE__ */ g("span", { children: l(X.danger) }),
							m.trophy && /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Hr, { kind: "crown" }), l(X.bubbleTrophy)] })
						]
					})
				]
			}),
			n && /* @__PURE__ */ g("div", {
				className: "cc-card-popover-footer",
				children: /* @__PURE__ */ g("button", {
					ref: p,
					type: "button",
					className: "cc-primary",
					disabled: !r,
					onClick: () => {
						let e = t.closest(".cc-hand") ? t.nextElementSibling ?? t.previousElementSibling : null;
						o(), e instanceof HTMLButtonElement && e.focus({ preventScroll: !0 });
					},
					children: n
				})
			})
		]
	});
}
//#endregion
//#region src/games/clankcatacombs/view-player.tsx
function _a(e) {
	f();
	let t = d(), r = e.public, i = e.private, [a, o] = c(null), [s, l] = c(0), [v, y] = c(null), b = n(() => y(null), []), x = i?.actions ?? [], S = r.players.find((t) => t.rid === e.myRid), C = r.players.find((e) => e.rid === r.active), w = (t) => e.members.find((e) => e.rid === t)?.name ?? t, ee = r.choice?.rid === e.myRid || r.reaction?.rid === e.myRid || r.phase === "characters" && r.active === e.myRid, te = r.placement && r.active === e.myRid, T = r.placement?.rotations.includes(s) ? s : r.placement?.rotations[0] ?? 0, E = (t) => {
		e.send(t), o(null), b();
	}, D = (e, t, n, i) => {
		let a = t.currentTarget;
		y((t) => O && t?.anchor === a ? null : {
			card: e,
			anchor: a,
			action: n,
			uid: i,
			turn: r.turnNumber
		});
	}, ne = v?.action, O = !!(v && v.turn === r.turnNumber && (ne?.type === "play" ? i?.hand.some((e) => e.uid === v.uid && e.kind === v.card) : ne?.type !== "row" || r.row[ne.slot]?.uid === v.uid && r.row[ne.slot]?.kind === v.card)) && !ee && !te, k = O && ne !== void 0 && x.some((e) => JSON.stringify(e) === JSON.stringify(ne)), A = (e) => sr(e, r, i, t, w), re = v && ne?.type === "row" ? t(L[v.card].type === "monster" ? X.confirmDefeat : L[v.card].type === "device" ? X.confirmDevice : X.confirmAcquire, {
		card: ir(v.card, t),
		n: dt(r, v.card)
	}) : ne ? A(ne) : void 0, ie = (e, n) => /* @__PURE__ */ _("button", {
		type: "button",
		className: "cc-action",
		onClick: () => E(e),
		children: [
			A(e),
			e.type === "market" && /* @__PURE__ */ g("small", { children: t(X.payment, { item: `${vt(r, C, e.discount) - e.silver} ${t(X.gold)} · ${e.silver} ${t(X.silver)}` }) }),
			e.type === "choose" && e.option === "fate" && /* @__PURE__ */ g("small", { children: t(nr[e.target]) }),
			e.type === "choose" && e.option === "character" && /* @__PURE__ */ g("small", { children: t(rr[e.target]) }),
			e.type === "reserve" && /* @__PURE__ */ g(Ji, {})
		]
	}, n), ae = /* @__PURE__ */ g("div", {
		className: "cc-dungeon",
		children: r.row.map((e, t) => {
			if (!e) return /* @__PURE__ */ g("div", {
				className: "cc-empty-card",
				children: /* @__PURE__ */ g(Ur, { kind: "device" })
			}, t);
			let n = x.some((e) => e.type === "row" && e.slot === t);
			return /* @__PURE__ */ _("button", {
				type: "button",
				className: "cc-card-button",
				"aria-haspopup": "dialog",
				"aria-expanded": O && v?.uid === e.uid,
				"data-selected": O && v?.uid === e.uid,
				"data-available": n,
				onClick: (n) => D(e.kind, n, {
					type: "row",
					slot: t
				}, e.uid),
				children: [/* @__PURE__ */ g(Wr, {
					kind: e.kind,
					compact: !0
				}), n && /* @__PURE__ */ g(Ji, {})]
			}, e.uid);
		})
	}), oe = (t) => /* @__PURE__ */ g("div", {
		className: "cc-seats",
		children: r.players.map((n, i) => /* @__PURE__ */ g(Yi, {
			area: t,
			player: n,
			member: e.members.find((e) => e.rid === n.rid),
			index: i,
			active: n.rid === r.active,
			onClick: () => o({
				kind: "player",
				rid: n.rid
			})
		}, n.rid))
	}), se = te ? t(X.orient) : ee ? r.phase === "characters" ? t(X.chooseCharacter) : t(X.choose) : x.length ? t(X.yourTurn) : r.phase === "dragon" ? t(X.dragon) : r.phase === "play" ? t(X.waiting, { name: w(r.choice?.rid ?? r.reaction?.rid ?? r.active) }) : t(X.resolving), j = a?.kind === "room" ? x.filter((e) => e.type === "move" && i?.moves.find((t) => t.id === e.route)?.to === a.room) : a?.kind === "route" ? x.filter((e) => e.type === "move" && e.route === a.route) : [], M = a?.kind === "player" ? r.players.find((e) => e.rid === a.rid) : null, ce = a?.kind === "room" ? or(r, a.room, t) : a?.kind === "player" ? w(a.rid) : t(X[a?.kind === "route" ? "chooseRoute" : a?.kind === "played" ? "playArea" : a?.kind ?? "details"]), le = /* @__PURE__ */ g("div", {
		className: "cc-reserves",
		children: [
			"explore",
			"mercenary",
			"tome"
		].map((e) => {
			let n = x.some((t) => t.type === "reserve" && t.card === e);
			return /* @__PURE__ */ _("button", {
				type: "button",
				"aria-haspopup": "dialog",
				"aria-expanded": O && ne?.type === "reserve" && ne.card === e,
				"data-selected": O && ne?.type === "reserve" && ne.card === e,
				"data-available": n,
				onClick: (t) => D(e, t, {
					type: "reserve",
					card: e
				}),
				children: [
					/* @__PURE__ */ g(Hr, { kind: e === "explore" ? "compass" : e === "mercenary" ? "sword" : "book" }),
					/* @__PURE__ */ _("span", { children: [ir(e, t), /* @__PURE__ */ _("small", { children: [/* @__PURE__ */ g(Hr, {
						kind: "skill",
						color: "#77b9d8"
					}), L[e].cost] })] }),
					n && /* @__PURE__ */ g(Ji, {})
				]
			}, e);
		})
	});
	return /* @__PURE__ */ _("div", {
		className: "cc-screen",
		children: [
			/* @__PURE__ */ g(m, {
				adaptive: !0,
				scroll: !1,
				className: "cc-layout",
				banner: /* @__PURE__ */ _("div", {
					className: "cc-banner",
					children: [
						/* @__PURE__ */ _("div", {
							className: "cc-banner-line",
							children: [
								/* @__PURE__ */ _("div", {
									className: "cc-brand",
									children: [/* @__PURE__ */ g(Vr, {
										art: "dragon",
										color: "#80aaa0"
									}), /* @__PURE__ */ _("strong", { children: ["CLANK! ", /* @__PURE__ */ g("small", { children: t(X.catacombs) })] })]
								}),
								/* @__PURE__ */ g(p, {
									tone: x.length ? "accent" : "info",
									accent: Kn.accent,
									text: se,
									chip: t(X.turn, { n: r.turnNumber })
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "cc-history",
									onClick: () => o({ kind: "log" }),
									children: t(X.log)
								})
							]
						}),
						/* @__PURE__ */ g("div", {
							className: "cc-mobile-seats",
							children: oe("mobile")
						}),
						/* @__PURE__ */ _("div", {
							className: "cc-status",
							children: [/* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Vr, { art: "dragon" }), t(X.rage, { n: r.rage })] }), /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Vr, { art: "bag" }), t(X.bag, { n: r.blackBag + r.ghostBag + r.players.reduce((e, t) => e + t.bag, 0) })] })]
						})
					]
				}),
				actionsHeight: "cc-actions-height",
				actions: /* @__PURE__ */ _("div", {
					className: "cc-hand-area",
					children: [
						/* @__PURE__ */ g("div", {
							className: "cc-self",
							children: S && /* @__PURE__ */ _(h, { children: [
								/* @__PURE__ */ g(Vr, {
									art: "portrait",
									variant: r.players.indexOf(S)
								}),
								/* @__PURE__ */ g("strong", { children: w(S.rid) }),
								/* @__PURE__ */ g("small", { children: ar(S.character, t) })
							] })
						}),
						/* @__PURE__ */ g(Zi, {
							pub: r,
							player: S
						}),
						/* @__PURE__ */ g("div", {
							className: "cc-hand",
							"aria-label": t(X.hand),
							children: i?.hand.map((e) => /* @__PURE__ */ g("button", {
								type: "button",
								className: "cc-card-button",
								"aria-haspopup": "dialog",
								"aria-expanded": O && v?.uid === e.uid,
								"data-available": x.some((t) => t.type === "play" && t.card === e.uid),
								"data-selected": O && v?.uid === e.uid,
								onClick: (t) => D(e.kind, t, {
									type: "play",
									card: e.uid
								}, e.uid),
								children: /* @__PURE__ */ g(Wr, {
									kind: e.kind,
									compact: !0
								})
							}, e.uid))
						}),
						/* @__PURE__ */ _("div", {
							className: "cc-commands",
							children: [
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "cc-mobile-dungeon",
									onClick: () => o({ kind: "dungeon" }),
									children: t(X.dungeon)
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "cc-played-command",
									onClick: () => o({ kind: "played" }),
									children: t(X.playedCards)
								}),
								/* @__PURE__ */ _("button", {
									type: "button",
									onClick: () => o({ kind: "actions" }),
									children: [/* @__PURE__ */ g(Hr, { kind: "compass" }), t(X.actions)]
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "cc-primary",
									disabled: !x.some((e) => e.type === "end"),
									onClick: () => E({ type: "end" }),
									children: t(X.end)
								})
							]
						}),
						/* @__PURE__ */ _("div", {
							className: "cc-decks",
							children: [/* @__PURE__ */ g(Qi, {
								count: S?.deckCount ?? 0,
								label: t(X.deck)
							}), /* @__PURE__ */ g(Qi, {
								count: S?.discard.length ?? 0,
								label: t(X.discard),
								onClick: () => o({ kind: "discard" })
							})]
						})
					]
				}),
				overlay: te ? /* @__PURE__ */ _("div", {
					className: "cc-placement",
					children: [/* @__PURE__ */ g("span", { children: t(X.orient) }), /* @__PURE__ */ _("div", { children: [r.placement.rotations.map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						"data-selected": T === e,
						onClick: () => l(e),
						children: [e * 90, "°"]
					}, e)), /* @__PURE__ */ g("button", {
						type: "button",
						className: "cc-primary",
						onClick: () => E({
							type: "orient",
							rotation: T
						}),
						children: t(X.confirm)
					})] })]
				}) : void 0,
				children: /* @__PURE__ */ _("div", {
					className: "cc-table",
					children: [
						/* @__PURE__ */ _("aside", {
							className: "cc-player-side",
							children: [
								/* @__PURE__ */ g(Xi, { pub: r }),
								oe("desktop"),
								/* @__PURE__ */ _("div", {
									className: "cc-bag",
									children: [/* @__PURE__ */ g(Vr, { art: "bag" }), /* @__PURE__ */ g("span", { children: t(X.bag, { n: r.blackBag + r.ghostBag + r.players.reduce((e, t) => e + t.bag, 0) }) })]
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									onClick: () => o({ kind: "log" }),
									children: t(X.log)
								})
							]
						}),
						/* @__PURE__ */ g(qi, {
							pub: r,
							priv: i,
							members: e.members,
							myRid: e.myRid,
							preview: T,
							selectedRoom: a?.kind === "room" ? a.room : void 0,
							onRoom: (e) => o({
								kind: "room",
								room: e
							}),
							onRoute: (e) => o({
								kind: "route",
								route: e
							})
						}),
						/* @__PURE__ */ _("aside", {
							className: "cc-dungeon-side",
							children: [
								/* @__PURE__ */ _("div", {
									className: "cc-section-heading",
									children: [/* @__PURE__ */ g("strong", { children: t(X.dungeon) }), /* @__PURE__ */ g("small", { children: t(X.deckCount, { n: r.dungeonCount }) })]
								}),
								ae,
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "cc-supplies-heading",
									onClick: () => o({ kind: "supplies" }),
									children: t(X.supplies)
								}),
								le
							]
						})
					]
				})
			}),
			/* @__PURE__ */ g(u, {
				open: !!a && !ee && !te,
				onClose: () => o(null),
				label: ce,
				title: ce,
				children: /* @__PURE__ */ _("div", {
					className: "cc-panel",
					children: [
						a?.kind === "dungeon" && ae,
						(a?.kind === "actions" || a?.kind === "supplies") && /* @__PURE__ */ _(h, { children: [
							/* @__PURE__ */ g("button", {
								type: "button",
								className: "cc-action",
								onClick: () => o({ kind: a.kind === "actions" ? "supplies" : "actions" }),
								children: t(a.kind === "actions" ? X.supplies : X.actions)
							}),
							x.filter((e) => a.kind === "supplies" ? [
								"reserve",
								"market",
								"fight"
							].includes(e.type) : ![
								"play",
								"row",
								"choose",
								"reserve"
							].includes(e.type)).map(ie),
							a.kind === "actions" && /* @__PURE__ */ _(h, { children: [
								S && /* @__PURE__ */ g("button", {
									type: "button",
									className: "cc-action",
									onClick: () => o({
										kind: "player",
										rid: S.rid
									}),
									children: t(X.freedPrisoners, { n: S.prisoners.length })
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "cc-action",
									onClick: () => o({ kind: "played" }),
									children: t(X.playedCards)
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "cc-action",
									onClick: () => o({ kind: "discard" }),
									children: t(X.discard)
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "cc-action",
									onClick: () => o({ kind: "log" }),
									children: t(X.log)
								})
							] })
						] }),
						(a?.kind === "played" || a?.kind === "discard") && /* @__PURE__ */ g("div", {
							className: "cc-card-gallery",
							children: (a.kind === "played" ? S?.played : S?.discard)?.map((e) => /* @__PURE__ */ g("button", {
								type: "button",
								className: "cc-card-button",
								"aria-haspopup": "dialog",
								"aria-expanded": O && v?.uid === e.uid,
								"data-selected": O && v?.uid === e.uid,
								"data-played": a.kind === "played",
								onClick: (t) => D(e.kind, t, void 0, e.uid),
								children: /* @__PURE__ */ g(Wr, {
									kind: e.kind,
									compact: !0
								})
							}, e.uid))
						}),
						a?.kind === "room" && /* @__PURE__ */ g("div", {
							className: "cc-choice-list",
							children: r.players.filter((e) => e.room === a.room && e.state === "active").map((e) => /* @__PURE__ */ _("button", {
								type: "button",
								className: "cc-action",
								onClick: () => o({
									kind: "player",
									rid: e.rid
								}),
								children: [
									r.players.indexOf(e) + 1,
									". ",
									w(e.rid)
								]
							}, e.rid))
						}),
						(a?.kind === "room" || a?.kind === "route") && /* @__PURE__ */ _(h, { children: [
							a.kind === "room" && /* @__PURE__ */ _(h, { children: [
								/* @__PURE__ */ g("p", { children: V(r.tiles, a.room).def.features.filter((e) => !/^artifact/.test(e)).map((e) => ar(e, t)).filter((e) => e !== t(X.empty)).join(" · ") }),
								/* @__PURE__ */ g("p", { children: t(X.artifactCount, { n: r.rooms.find((e) => e.id === a.room)?.artifacts.join(", ") || t(X.empty) }) }),
								/* @__PURE__ */ g("p", { children: t(X.secretCount, { n: r.rooms.find((e) => e.id === a.room)?.secrets ?? 0 }) })
							] }),
							j.map((e, n) => {
								let r = e.type === "move" ? i?.moves.find((t) => t.id === e.route) : null;
								return /* @__PURE__ */ _("button", {
									type: "button",
									className: "cc-action",
									onClick: () => E(e),
									children: [A(e), r && e.type === "move" && /* @__PURE__ */ g("small", { children: t(X.moveCost, {
										boots: r.boots,
										swords: e.swords,
										damage: Math.max(0, r.monsters - e.swords),
										picks: r.picks,
										silver: r.silver
									}) })]
								}, n);
							}),
							a.kind === "room" && S?.room === a.room && x.filter((e) => [
								"artifact",
								"unlock",
								"mark",
								"fight",
								"market"
							].includes(e.type)).map(ie)
						] }),
						M && /* @__PURE__ */ _(h, { children: [
							/* @__PURE__ */ _("p", { children: [
								ar(M.character, t),
								" · ",
								t(X[M.state])
							] }),
							/* @__PURE__ */ g("p", { children: t(rr[M.character]) }),
							M.character === "lenara" && /* @__PURE__ */ g("p", { children: t(X.mana, { n: M.mana }) }),
							M.character === "monkeybot" && /* @__PURE__ */ g("p", { children: t(X.cogs, { n: M.cogs }) }),
							M.character === "agnet" && /* @__PURE__ */ g("p", { children: t(X.conscription, { n: M.conscription }) }),
							M.character === "garignar" && /* @__PURE__ */ g("p", { children: t(X.carnage, { n: M.carnage }) }),
							M.character === "whiskers" && /* @__PURE__ */ g("p", { children: t(X.behavior, { items: M.behavior.map((e) => t(X[e])).join(" · ") || t(X.empty) }) }),
							/* @__PURE__ */ _("p", { children: [
								t(X.health, { n: 10 - M.damage }),
								" · ",
								t(X.deckCount, { n: M.deckCount })
							] }),
							/* @__PURE__ */ g("p", { children: t(X.artifactCount, { n: M.artifacts.map((e) => e.value).join(", ") || t(X.empty) }) }),
							/* @__PURE__ */ g("p", { children: M.items.map((e) => `${ar(e.kind, t)} (${e.points})`).join(" · ") }),
							/* @__PURE__ */ g("p", { children: [...M.tokens, ...M.trophies].map((e) => ar(e, t) === t(X.empty) ? ir(e, t) : ar(e, t)).join(" · ") }),
							/* @__PURE__ */ _("section", {
								className: "flex flex-col gap-2",
								"aria-label": t(X.freedPrisoners, { n: M.prisoners.length }),
								children: [/* @__PURE__ */ g("h3", { children: t(X.freedPrisoners, { n: M.prisoners.length }) }), M.prisoners.length ? /* @__PURE__ */ g("ul", { children: M.prisoners.map((e, n) => /* @__PURE__ */ g("li", { children: /* @__PURE__ */ g("p", { children: ar(e, t) }) }, n)) }) : /* @__PURE__ */ g("p", { children: t(X.noPrisoners) })]
							}),
							M.rid === e.myRid && /* @__PURE__ */ _(h, { children: [i?.fates.map((e) => /* @__PURE__ */ _("p", { children: [
								/* @__PURE__ */ g("strong", { children: ar(`fate-${e}`, t) }),
								/* @__PURE__ */ g("br", {}),
								t(nr[e])
							] }, e)), x.filter((e) => e.type === "use" || e.type === "spell").map(ie)] }),
							/* @__PURE__ */ g("h3", { children: t(X.playArea) }),
							/* @__PURE__ */ g("div", {
								className: "cc-card-list",
								children: M.played.map((e) => /* @__PURE__ */ g("button", {
									type: "button",
									"aria-haspopup": "dialog",
									"data-selected": O && v?.uid === e.uid,
									onClick: (t) => D(e.kind, t, void 0, e.uid),
									children: /* @__PURE__ */ g(Wr, {
										kind: e.kind,
										compact: !0
									})
								}, e.uid))
							}),
							/* @__PURE__ */ g("h3", { children: t(X.discard) }),
							/* @__PURE__ */ g("div", {
								className: "cc-card-list",
								children: M.discard.map((e) => /* @__PURE__ */ g("button", {
									type: "button",
									"aria-haspopup": "dialog",
									"data-selected": O && v?.uid === e.uid,
									onClick: (t) => D(e.kind, t, void 0, e.uid),
									children: /* @__PURE__ */ g(Wr, {
										kind: e.kind,
										compact: !0
									})
								}, e.uid))
							})
						] }),
						a?.kind === "log" && r.log.slice().reverse().map((e, n) => /* @__PURE__ */ _("p", { children: [
							e.rid ? w(e.rid) : "",
							" · ",
							lr(e, r, t)
						] }, n))
					]
				})
			}),
			/* @__PURE__ */ g(u, {
				open: ee,
				label: r.phase === "characters" ? t(X.chooseCharacter) : t(X.choose),
				title: r.choice?.source && tr[r.choice.source] ? ir(r.choice.source, t) : r.reaction ? t(X.react, { card: "" }) : t(X.choose),
				children: /* @__PURE__ */ _("div", {
					className: "cc-panel",
					children: [r.choice?.source && tr[r.choice.source] && /* @__PURE__ */ g(Wr, { kind: r.choice.source }), /* @__PURE__ */ g("div", {
						className: "cc-choice-list",
						children: x.map(ie)
					})]
				})
			}),
			/* @__PURE__ */ g(ha, {
				pub: r,
				members: e.members,
				myRid: e.myRid
			}),
			O && v && /* @__PURE__ */ g(ga, {
				card: v.card,
				anchor: v.anchor,
				action: re,
				enabled: k,
				onClose: b,
				onConfirm: () => {
					k && ne && E(ne);
				}
			}),
			/* @__PURE__ */ g("span", {
				className: "sr-only",
				children: w(C.rid)
			})
		]
	});
}
//#endregion
//#region src/games/clankcatacombs/bot.ts
var va = {
	artifact: 65,
	extraArtifact: 20,
	explore: 26,
	escape: 24,
	danger: 1.4,
	evacuation: 12,
	wounds: 1.2,
	pick: 1.2,
	cave: 1.1,
	revisit: 8,
	loot: 1,
	distance: 2.5,
	detour: 1.2,
	skill: 1.2,
	boots: 2.8,
	swords: .85,
	draw: 3,
	noise: .65,
	points: 1,
	buyCost: .6,
	engine: 1.6,
	health: 2.5,
	potion: 1.6,
	reservePick: 2
};
function ya(e = {}) {
	let t = {
		...va,
		...e
	}, n = [];
	function r(e, t) {
		let r = JSON.stringify([
			e.tiles,
			e.openedLocks,
			e.rooms.filter((e) => e.chute).map((e) => e.id),
			t.tokens.includes("map") || e.turn.flags.includes("reverse-arrows")
		]), i = n.find((e) => e.key === r);
		if (i) return i.graph;
		let a = new Map(e.rooms.map((n) => [n.id, Ct(e, {
			...t,
			room: n.id,
			tokens: e.turn.flags.includes("reverse-arrows") ? [...t.tokens, "map"] : t.tokens
		})]));
		return n.push({
			key: r,
			graph: a
		}), n.length > 4 && n.shift(), a;
	}
	return ({ public: e, private: n }, i) => {
		if (!n?.actions.length) return null;
		let a = n, o = e.players.find((e) => e.rid === i.rid), s = i.memory, c = s?.turn === e.turnNumber ? s : {
			turn: e.turnNumber,
			moves: [],
			count: 0
		}, l = [
			...a.hand,
			...o.played,
			...o.discard,
			...o.reacted
		], u = Le(o), d = V(e.tiles, o.room).tile.zone === "underworld", f = e.players.filter((e) => e.state !== "active").length, p = e.blackBag + e.ghostBag + e.ghostClank + e.players.reduce((e, t) => e + t.bag + t.clank, 0), m = ((e.players.length >= 5 ? [
			2,
			2,
			2,
			2,
			3,
			3,
			4
		] : [
			2,
			2,
			3,
			3,
			4,
			4,
			5
		])[e.rage] + e.row.filter((e) => e && L[e.kind].danger).length) * (o.bag + o.clank + e.ghostBag + e.ghostClank) / Math.max(1, p), h = t.health * (1 + Math.max(0, o.damage - 3) * .5 + m * .4), g = e.turn.flags.includes("ignoreMonsters") || o.items.some((e) => e.kind === "cloak") || o.trophies.includes("medusa"), _ = r(e, o), v = (n) => n.barrier && u || n.locks.length > o.picks || n.toll > o.silver && !o.trophies.includes("nether-titan") || n.to && !u && H(e.tiles, n.to, "crypt") ? Infinity : n.boots + (g ? 0 : n.monsters) * t.wounds * (.3 + o.damage * .12 + m * .2) + n.locks.length * t.pick + (o.trophies.includes("nether-titan") ? 0 : n.toll * .6) + (n.to && H(e.tiles, n.to, "cave") && !e.turn.flags.includes("ignoreCave") ? t.cave : 0);
		function y(e, t = !0, n = _) {
			let r = Object.fromEntries([...n.keys()].map((t) => [t, e.includes(t) ? 0 : Infinity])), i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Map();
			for (let [e, r] of n) for (let i of r) {
				if (!i.to || !n.has(i.to)) continue;
				let r = t ? i.to : e, o = t ? e : i.to, s = a.get(r) ?? [];
				s.push({
					to: o,
					cost: v(i)
				}), a.set(r, s);
			}
			for (let e = 0; e < n.size; e++) {
				let e = "", t = Infinity;
				for (let [n, a] of Object.entries(r)) a < t && !i.has(n) && (e = n, t = a);
				if (!e) break;
				i.add(e);
				for (let n of a.get(e) ?? []) r[n.to] = Math.min(r[n.to], t + n.cost);
			}
			return r;
		}
		let b = y(e.rooms.filter((t) => H(e.tiles, t.id, "crypt")).map((e) => e.id)), x = y([o.room], !1), S = u ? Math.max(.1, Math.min(2, (b[o.room] ?? 8) / 5 + .3 - o.damage * .055 - f * .2)) : Math.max(.7, 2.5 - e.turnNumber / e.players.length * .08 - o.damage * .08), C = t.pick + (o.picks <= 1 ? t.reservePick : 0);
		function w(n, r, i = !1) {
			return n === "clank" ? -r * t.noise * (1 + m * .35 + o.damage * .08) : n === "heal" ? Math.min(r, i ? o.damage : Math.max(1, o.damage)) * h : n === "gold" || n === "silver" ? r * (n === "silver" && d ? 1.25 : 1) : n === "picks" ? r * C : n === "mana" ? r * (o.character === "lenara" ? 1.1 : 0) : n === "boots" ? r * t.boots * (u ? 1.15 : 1) * (i && e.turn.stopped && !e.turn.flags.includes("ignoreCave") ? .05 : 1) : n === "swords" ? r * t.swords : n === "skill" ? r * t.skill : 0;
		}
		function ee(t) {
			return t === "artifact" ? u ? 1 : .15 : t === "idol" ? o.idols.length ? 1 : .15 : t === "crown" ? Ie(o) ? 1 : .2 : t === "underworld" ? d ? 1 : .15 : t === "companion" ? l.some((e) => L[e.kind].type === "companion") ? .8 : .3 : t === "tome" ? l.some((e) => L[e.kind].tome) ? .8 : .15 : t === "prisoner3" ? o.prisoners.length >= 3 ? 1 : .1 : t === "fate" ? a.fates.length ? 1 : .1 : t === "gem" ? l.some((e) => L[e.kind].type === "gem") ? .9 : .2 : t === "cave" ? H(e.tiles, o.room, "cave") ? 1 : .4 : .55;
		}
		function te(n, r = !1, i = 0) {
			return i > 3 ? 0 : n.reduce((n, a) => a.op === "gain" ? n + (a.who === "others" ? 0 : w(a.resource, a.n, r)) : a.op === "draw" ? n + a.n * t.draw : a.op === "when" ? n + ee(a.condition) * te(a.effects, r, i + 1) : a.op === "choice" ? n + Math.max(0, ...a.options.map((e) => te(e.effects, r, i + 1))) : a.op === "flag" ? n + (a.flag === "ignoreCave" ? 2.5 : a.flag === "ignoreMonsters" ? 2 : a.flag.includes("discount") ? 1.5 : .5) : n + ({
				minor: 3,
				major: 5,
				prisoner: 3.5,
				tome: 5,
				trash: 3,
				"trash-burgle": 3,
				"trash-self": 0,
				"discard-draw2": t.draw * 1.5,
				"discard-optional-draw": 1,
				"pay-pick-draw2": Math.max(0, t.draw * 2 - C),
				"pay3-draw2": t.draw * 2 - 3,
				"silver-draw2": t.draw * 2 - 1,
				"pay3-tome": 4,
				"draw-artifacts": t.draw * o.artifacts.length,
				"noise-gold": 2,
				"noise-swords": 1.5,
				"tunnel-gold": 1.5,
				scavenge: 1.5,
				"finds-gold": .8 * (Number(u) + Number(o.idols.length > 0) + Number(Ie(o) > 0) + Number(o.tokens.includes("egg"))),
				"noise-gold-once": 1.5,
				"steal-gold": .5,
				channel: 1.5,
				study: 2,
				healer: 2,
				teleport: u ? 6 : 4,
				"teleport-any-other-tile": 7,
				"teleport-underworld-market": 3,
				"teleport-lair": 4,
				"acquire-any": 6,
				"acquire4-backpack": 4,
				acrobatics: 4,
				"black-market": 4,
				"free-market-here": H(e.tiles, o.room, "market") ? 8 : 1,
				"free-market": 8,
				"place-adjacent": 3,
				"place-anywhere": 2,
				replace: .5,
				acid: 3,
				behavior: 2,
				"behavior-double": 3,
				"finds-choice": 2,
				flute: 1,
				"empurror-extra": u ? 4 : 0,
				phantasm: Math.max(0, o.idols.length * 1.5)
			}[a.id] ?? (a.id.includes("teleport") ? 4 : a.id.includes("trash") || a.id.includes("draw") ? 2 : 0)), 0);
		}
		function T(t) {
			return t === "wealth-of-knowledge" || t === "thirst-for-knowledge" ? l.filter((e) => L[e.kind].tome).length + 1 : t === "devotion" ? e.rooms.filter((e) => Object.values(e.marks).includes(o.rid)).length : t === "thirst-for-adventure" ? 2 * (o.artifacts.length + o.idols.length + Number(o.trophies.includes("guardian"))) : t === "orpheus" ? o.prisoners.length : t === "brave-hero" ? o.prisoners.length >= 3 ? 5 : 0 : t === "expensive-taste" ? Ie(o) && l.some((e) => L[e.kind].type === "gem") ? 5 : 0 : t === "thunderstriker" ? o.trophies.filter((e) => e.startsWith("harpy")).length : L[t]?.points ?? 0;
		}
		function E(e, t = !1) {
			let n = L[e];
			return n ? w("skill", n.skill, t) + w("boots", n.boots, t) + w("swords", n.swords, t) + te(n.play, t) : 0;
		}
		function D(e) {
			let n = L[e];
			if (!n) return 0;
			let r = E(e, n.type === "monster" || n.type === "device");
			if (n.type === "monster" || n.type === "device") return r + (n.trophy ? T(e) + (e === "cave-bat-wings" ? 3 : e === "merchants-guild-pin" ? S * 1.5 : e === "golden-hourglass" ? S * 2 : e === "hoard-keeper" ? (o.gold + o.silver) / 5 : 0) : 0);
			let i = Math.max(0, 2.5 - r) * S;
			return T(e) * t.points + (r - 2) * S * t.engine + te(n.acquire, !0) - i;
		}
		function ne(n, r = !1) {
			let i = V(e.tiles, n.id).def.features, s = 0;
			if (!r) {
				s += (n.secrets ? 3 : 0) + (n.idols.length ? n.idols[0] : 0) + (n.prisoner ? 3.5 : 0);
				for (let e of i) {
					let t = /^(gold|silver|heal|skill|clank)(\d+)$/.exec(e);
					t && (s += w(t[1], +t[2], !0));
				}
				i.includes("fate") && a.fates.length < 1 + Number(o.items.some((e) => e.kind === "gauntlets")) && (s += 4), i.includes("imp") && !o.imp && (s += l.filter((e) => L[e.kind].tome).length * 3), i.includes("lake") && l.some((e) => ["burgle", "stumble"].includes(e.kind)) && (s += 2.5);
			}
			return o.picks && !n.opened.includes("chest") && i.includes("chest") && (s += Math.max(0, 5 - C)), o.picks && !n.opened.includes("prison") && i.some((e) => e.startsWith("prison")) && (s += Math.max(0, (i.includes("prison3") ? 9 : 6) - C)), o.picks && !n.opened.includes("library") && i.includes("library") && (s += Math.max(0, D("tome") - C)), i.includes("wayshrine") && o.supply && !Object.values(n.marks).includes(o.rid) && (s += 1 + e.rooms.filter((e) => Object.keys(e.marks).some((t) => t.startsWith("wayshrine") && e.marks[t] === o.rid)).length), i.includes("market") && o.gold + o.silver >= vt(e, o) && (s += o.damage >= 5 && e.market[d ? "amulet-uw" : "amulet"]?.length ? h * 2 : 2), s -= n.monsters.reduce((e, t) => e + (Pe[t]?.damage ?? 0) * h * .4, 0), Math.max(0, s) * t.loot;
		}
		let O = new Map(e.rooms.map((t) => [t.id, ne(t, e.turn.visited.includes(t.id))])), k = [], A = b[o.room] ?? Infinity, re = u && (o.damage + m * (A / 2 + 1) * t.danger >= 7 || f > 0 || o.artifacts.length >= ze(o)), ie = Math.max(0, o.damage - 3) * t.danger + m * t.danger * 2 + f * t.evacuation;
		for (let n of e.rooms) {
			V(e.tiles, n.id).def.features.includes("crypt") && u && k.push({
				id: n.id,
				reward: t.escape + ie
			}), n.artifacts.length && o.artifacts.length < ze(o) && (e.players.length < 5 || !o.artifacts.some((e) => e.room === n.id)) && k.push({
				id: n.id,
				reward: (u ? t.extraArtifact : t.artifact) + Math.max(...n.artifacts) * (u ? 1 : .3) - (u ? ie : 0) - (Number.isFinite(b[n.id]) ? b[n.id] * m * .4 : 6)
			});
			let r = O.get(n.id) ?? 0;
			r > 0 && n.id !== o.room && !e.turn.visited.includes(n.id) && k.push({
				id: n.id,
				reward: r - (u ? ie * .3 : 0)
			}), (!u || !Number.isFinite(A)) && e.tileCount && (_.get(n.id) ?? []).some((e) => e.discover && Number.isFinite(v(e))) && k.push({
				id: n.id,
				reward: t.explore - (e.tileCount < 3 ? 5 : 0)
			}), !u && e.config.underworld && !d && (_.get(n.id) ?? []).some((e) => e.descend) && k.push({
				id: n.id,
				reward: t.explore * .6
			});
		}
		let ae = k[0], oe = -Infinity;
		for (let e of k) {
			let n = x[e.id] ?? Infinity, r = e.reward / (t.distance + n) - c.moves.filter((t) => t === e.id).length * .7;
			Number.isFinite(r) && r > oe && (oe = r, ae = e);
		}
		let se = ae?.id ?? o.room, j = {
			from: x,
			home: b,
			target: se,
			distances: y([se]),
			risk: m,
			returning: re,
			rewards: O
		};
		function M(n, r = 0, i = 0, a = 0, s = 0, l = !1) {
			let d = j.distances[o.room], f = n ? j.distances[n] : void 0, p = Number.isFinite(d) && typeof f == "number" && Number.isFinite(f) ? d - f : 0;
			n === se && (p += 1), n || (p = !u || !Number.isFinite(A) ? t.explore / 8 : -20);
			let m = c.moves.filter((e) => e === n).length, g = p * 8 + (n ? O.get(n) ?? 0 : 0) * t.detour - r * .5 - i * h - a * C - s * 1.2 - m * t.revisit;
			return n && H(e.tiles, n, "crypt") && u && (g += 30 + ie), n && H(e.tiles, n, "cave") && !e.turn.stopped && e.turn.boots > r && !e.turn.flags.includes("ignoreCave") && (g -= Math.max(0, e.turn.boots - r) * 2), n && !u && H(e.tiles, n, "crypt") ? -1e3 : l && n === o.room ? -1 : g;
		}
		function ce(t) {
			let n = a.moves.find((e) => e.id === t);
			return n ? {
				to: n.to,
				route: n
			} : { to: e.rooms.some((e) => e.id === t) ? t : "" };
		}
		function le(n, r = 0) {
			let i = (e.market[n]?.[0] ?? 0) - r;
			return n.startsWith("amulet") && (i += Math.min(2, o.damage) * h), n === "backpack" && (i += !re && !o.items.some((e) => e.kind === n) ? t.extraArtifact * .6 : 0), n === "kit" && (i += 2 * C), n === "cloak" && (i += Math.min(8, A) * h * .3), n === "wind-boots" && (i += S * t.boots * 2), n === "gauntlets" && (i += a.fates.length ? 3 : 5), n === "jester-cap" && (i += l.filter((e) => e.kind === "stumble").length * 7), n === "river-lamp" && (i += 3), i;
		}
		function ue(e) {
			if (!e) return -5;
			let n = e.kind;
			return n === "stumble" ? a.fates.includes("fool") && l.filter((e) => e.kind === "stumble").length <= 2 ? -2 : o.items.some((e) => e.kind === "jester-cap") ? -7 : 6 * S + t.noise : n === "burgle" ? 3.5 * S : n === "escape-plan" ? w("boots", 2, !0) + 2 - T(n) : n === "burial-urn" ? 4 - T(n) : n === "soul-prism" ? 3.5 - T(n) : n === "underworld-guide" ? t.draw - T(n) : (2.5 - E(n)) * S - T(n);
		}
		function N(n) {
			let r = n.target ?? "", i = e.choice?.kind, s = e.choice?.source, c = l.find((e) => e.uid === +r);
			if (n.option === "character") return {
				whiskers: 9,
				agnet: 8,
				lenara: 7,
				monkeybot: 6,
				garignar: 5,
				dallan: 4
			}[r] ?? 0;
			if (n.option === "skip") return 0;
			if (n.option === "teleport") {
				let e = ce(r);
				return e.to ? M(e.to, 0, 0, 0, 0, !0) : -1e3;
			}
			if (n.option === "swap") return M(e.players.find((e) => e.rid === r)?.room ?? "");
			if (n.option === "artifact") return 50 + Math.max(...e.rooms.find((e) => e.id === r)?.artifacts ?? [0]);
			if (n.option === "return") return i === "phantasm" ? 2 * (r.split(":")[1] ?? 1) : -(e.rooms.find((e) => e.id === r)?.artifacts[0] ?? 0);
			if (n.option === "aegis") return h + 2;
			if (n.option === "damage") return -h * (i === "encounter" ? 2 : 1);
			if (n.option === "fall") return -h - (e.turn.boots > 0 ? 3 : 0);
			if (n.option === "fight") return 5;
			if (n.option === "trash") return i === "waystone" ? u ? 5 : -3 : i === "trophy" ? 2 * t.draw - (L[r]?.points ?? 3) - (r === "guardian" && !o.artifacts.length ? 100 : 0) : c ? ue(c) - (a.hand.includes(c) && i === "pit" ? E(c.kind, !0) * .3 : 0) : Math.max(0, ...l.map(ue));
			if (n.option === "discard") return i === "ghost" ? h + t.draw + +!!o.played.some((e) => e.uid === +r) : i === "acid" ? w("swords", 2, !0) - (c ? E(c.kind, !0) : 0) : (s === "hiding-place" ? Math.min(2, o.clank) * t.noise : s === "charlatan" ? 2 * t.draw : t.draw) - (c ? Math.max(0, E(c.kind, !0)) : 0);
			if (n.option === "copy") return E(c?.kind ?? "", !0);
			if (n.option === "top") return c ? E(c.kind) - 3 : 0;
			if (n.option === "acquire") return D(e.row[+r]?.kind ?? "");
			if (n.option === "replace") return i === "reroll" ? we[e.placement.kind].rooms.some((e) => e.features.some((e) => e.startsWith("artifact"))) ? -2 : u ? -1 : 3 : 3 - D(e.row[+r]?.kind ?? "");
			if (n.option === "market") return r ? le(r) : H(e.tiles, o.room, "market") ? Math.max(0, ...Object.keys(e.market).map((e) => le(e))) : 0;
			if (n.option === "mark") return 2 + e.rooms.filter((e) => Object.values(e.marks).includes(o.rid)).length;
			if (n.option === "heal") return Math.min(o.damage, s === "succubus" ? 1 : 2) * h - (s === "spiritual-healer" ? 2 * t.noise : +(s === "soothsayer"));
			if (n.option === "fate") return {
				sun: u ? 10 : 6,
				fool: l.filter((e) => e.kind === "stumble").length >= 2 ? 10 : 0,
				wheel: o.gold + o.silver >= 8 ? 10 : 3,
				lovers: 2 + Math.min(2, o.damage) * h,
				chariot: S * t.boots * 2 - 3,
				star: 3 + m * h * 2,
				death: 5,
				hermit: o.idols.length ? 6 : 1,
				empress: Ie(o) ? 6 : 1,
				magician: 4 + o.imp,
				world: o.items.length >= 2 ? 7 : 2,
				imp: l.filter((e) => L[e.kind].type === "gem").length * 4,
				moon: o.items.filter((e) => [
					"amulet-uw",
					"wind-boots",
					"gauntlets",
					"jester-cap",
					"riverboat"
				].includes(e.kind)).length >= 2 ? 8 : 2,
				justice: 3,
				strength: o.trophies.filter((e) => e.startsWith("harpy")).length * 3,
				temperance: 4,
				"high-priestess": 4,
				hierophant: 4,
				tower: 3,
				judgement: 5 - m * h,
				"hanged-man": 5 - h * .5,
				emperor: o.enhancer > 1 && Ie(o) && o.idols.length ? 12 : 0
			}[r] ?? 0;
			if (n.option === "reveal") return i === "star" ? h * 3 : 1;
			if (n.option === "quiet") return s === "leprechaun" ? 2 - t.noise : Math.min(2, Math.max(1, o.clank)) * t.noise;
			if (n.option === "loud") return 5 - 3 * t.noise * (1 + m);
			if (n.option === "caves") return e.turn.stopped && e.turn.boots ? w("boots", e.turn.boots) : 1;
			if (n.option === "boot" || n.option === "boots") return w("boots", 1, !0);
			if (n.option === "swords") return w("swords", 1, !0);
			if (n.option === "skill") return w("skill", 1, !0);
			if (n.option === "gold") return s === "ogre-merchant" ? 5 : s === "succubus" ? 3 : s === "empurror" ? 1 : s === "spotter" ? 2 - t.noise : 2;
			if (n.option === "silver") return s === "oracle" ? o.silver ? t.draw * 2 - 1 : -10 : 1.25;
			if (n.option === "pick") return C;
			if (n.option === "draw") return s === "imp-familiar" ? o.picks ? t.draw * 2 - C : -10 : t.draw;
			if (n.option === "tome") return D("tome") - (s === "underworld-dealer" ? 3 : 5);
			if (n.option === "minor") return 3;
			if (n.option === "steal") return s === "grand-theft" ? Math.max(0, ...e.row.filter((e) => !!e && L[e.kind].type !== "monster").map((e) => D(e.kind))) - C : .5;
			if (n.option === "rotate") {
				let t = V(e.tiles, o.room).tile, n = Ct({
					...e,
					tiles: e.tiles.map((e) => e.id === t.id ? {
						...e,
						rotation: (e.rotation + +r) % 4
					} : e)
				}, o);
				return Math.max(-50, ...n.map((e) => e.to ? M(e.to) : u ? -10 : 5));
			}
			if (n.option === "place") {
				let [t, n] = r.split(",").map(Number), i = V(e.tiles, o.room).tile;
				return Number.isFinite(n) ? -Math.abs(t - i.x) - Math.abs(n - i.y) : +(r === i.slot);
			}
			return 1;
		}
		function P(t) {
			let n = e.placement;
			if (!n) return -1e3;
			let r = Math.max(...e.tiles.map((e) => e.id)) + 1, i = {
				id: r,
				kind: n.kind,
				x: n.x,
				y: n.y,
				rotation: t,
				zone: "catacombs"
			}, a = {
				...e,
				tiles: [...e.tiles, i]
			}, s = we[i.kind], l = c.entry, d = l ? s.passages.flatMap((e) => [e.a, e.b]).find((e) => Ee(e, t) === l) : void 0, f = -100;
			for (let t of s.rooms) {
				let n = B(r, t.id), i = d ? xt(a, o.room, !1, B(r, d)).filter((e) => e.to === n) : [{
					monsters: 0,
					boots: 1,
					locks: [],
					barrier: !1,
					toll: 0
				}];
				if (!i.length) continue;
				let s = Ct(a, {
					...o,
					room: n
				}), c = t.features.some((e) => e.startsWith("artifact")) && !u ? 25 : t.features.includes("minor") || t.features.includes("gold5") || t.features.includes("idol") ? 5 : 0;
				c += s.filter((e) => e.discover).length * (u ? .2 : 1.2), c += Math.max(-10, ...s.filter((e) => e.to && b[e.to] !== void 0).map((e) => Number.isFinite(b[e.to]) ? 8 - b[e.to] - e.boots - e.monsters : -10));
				let l = i.filter((t) => t.locks.length <= o.picks && t.boots <= e.turn.boots && (g || o.damage + t.monsters < 10) && !(t.barrier && u));
				if (d && !l.length) continue;
				let p = Math.min(...(l.length ? l : i).map((e) => (g ? 0 : e.monsters * h) + e.boots + e.locks.length * C + (e.barrier && u ? 100 : 0)));
				f = Math.max(f, c - p);
			}
			return f;
		}
		let F = a.actions.flatMap((t) => t.type === "row" ? [{
			action: t,
			kind: e.row[t.slot].kind
		}] : t.type === "reserve" ? [{
			action: t,
			kind: t.card
		}] : []), de = /* @__PURE__ */ new Map();
		for (let { action: n, kind: r } of F) {
			let i = L[r], a = i.type === "monster" ? "swords" : "skill", o = i.type === "device" ? Math.max(0, i.cost - e.turn.flags.filter((e) => e === "device-discount2").length * 2) : i.cost, s = e.turn[a], c = Array(s + 1).fill(0);
			for (let r of F) {
				if (r.action === n || (L[r.kind].type === "monster" ? "swords" : "skill") !== a) continue;
				let i = L[r.kind], o = i.type === "device" ? Math.max(0, i.cost - e.turn.flags.filter((e) => e === "device-discount2").length * 2) : i.cost, l = D(r.kind) - o * t.buyCost;
				for (let e = s; e >= o; e--) c[e] = Math.max(c[e], c[e - o] + l);
			}
			let l = D(r) - o * t.buyCost;
			de.set(n, l + c[Math.max(0, s - o)] - c[s]);
		}
		let I = (n) => {
			switch (n.type) {
				case "play": {
					let e = a.hand.find((e) => e.uid === n.card), t = L[e.kind], r = t.play.some((e) => e.op === "special" && e.id.includes("teleport"));
					return 300 + (t.play.some((e) => e.op === "special" && [
						"noise-gold",
						"noise-swords",
						"channel",
						"study",
						"finds-gold",
						"draw-artifacts"
					].includes(e.id)) ? 50 : 0) + E(e.kind, !0) + (t.type === "companion" ? 5 : 0) - (r && a.hand.length > 1 ? 60 : 0) + (e.kind === "stumble" ? -40 : 0);
				}
				case "react": return 500;
				case "pass":
				case "end": return 0;
				case "artifact": return 250 + Math.max(...e.rooms.find((e) => e.id === n.room).artifacts);
				case "orient": return P(n.rotation);
				case "choose": return N(n);
				case "move": {
					let e = a.moves.find((e) => e.id === n.route);
					return M(e.to, e.boots, Math.max(0, e.monsters - n.swords), e.picks, e.silver) - n.swords * .25 + (n.route.startsWith("continue:") ? 100 : 0);
				}
				case "row":
				case "reserve": return (de.get(n) ?? -100) * 2 + 4;
				case "unlock": return 8 + (n.feature === "chest" ? 5 : n.feature === "prison" ? H(e.tiles, o.room, "prison3") ? 9 : 6 : D("tome")) - C;
				case "fight": return n.monster === "goblin" ? 1.2 : n.monster === "sphinx" ? 15 : n.monster === "medusa" ? 12 : n.monster === "guardian" ? 10 + Math.max(0, ...o.artifacts.map((e) => e.value)) : n.monster === "statue" ? 2 : 5;
				case "market": return le(n.item, vt(e, o, n.discount)) * 3 + 1 - n.silver * (d ? .03 : -.01) - (n.discount === "dark-iron" ? 2 : 0);
				case "mark": {
					let t = n.slot.split("|")[1], r = n.payment.startsWith("trophy:") ? L[n.payment.slice(7)]?.points ?? 2 : t.startsWith("bazaar") ? 3 : t.startsWith("temple") ? [
						2,
						3,
						5,
						8
					][+t.split(":")[1]] : 0;
					return (t.startsWith("wayshrine") ? 5 : t.startsWith("aegis") ? 2 + m * h : t.startsWith("altar") ? u && o.artifacts.length >= ze(o) ? 2 : 30 : t === "bazaar:0" ? Math.min(o.damage, 3) * h : t === "bazaar:2" ? Math.max(0, ...e.row.filter((e) => !!e).map((e) => D(e.kind))) : t === "bazaar:3" ? 10 : t === "temple:3" && !u ? 50 : 6) - r;
				}
				case "use":
					if (n.token === "spring") return Math.max(0, ...l.map(ue)) + 10;
					if (n.token.startsWith("heal") || n.token === "soul-elixir" || n.token === "greater-hope") return o.damage >= (n.token === "heal1" ? 1 : 2) ? 400 : -10;
					if (n.token === "stealth") return o.clank ? 200 : -5;
					if (n.token === "boots" || n.token === "hope") {
						if (e.turn.stopped || e.turn.flags.includes("escaping")) return -10;
						let n = a.moves.filter((t) => t.boots <= e.turn.boots + 1 && t.boots > e.turn.boots && t.picks <= o.picks && t.silver <= o.silver).map((t) => M(t.to, t.boots, Math.max(0, t.monsters - e.turn.swords), t.picks, t.silver));
						return Math.max(-5, ...n) - t.potion;
					}
					return n.token === "swords" ? a.moves.some((t) => t.monsters > e.turn.swords && M(t.to, t.boots, 0, t.picks, t.silver) > 0) || e.row.some((t) => t && L[t.kind].type === "monster" && L[t.kind].cost > e.turn.swords && L[t.kind].cost <= e.turn.swords + 2) ? 20 : -5 : n.token === "chute" ? !u && d ? 1 : -5 : n.token.startsWith("fate:") ? n.token === "fate:hierophant" ? 10 : n.token === "fate:high-priestess" ? e.turn.stopped && e.turn.boots ? 20 : -1 : 10 : -1;
				case "spell": return n.spell === "duplicate" ? Math.max(0, ...o.played.map((e) => E(e.kind, !0))) * 2 : n.spell === "levitate" ? 15 : a.hand.some((e) => e.kind === "stumble") ? 25 : 1;
				case "tick": return -1e4;
			}
		}, fe = a.actions[0], pe = -Infinity;
		for (let e of a.actions) {
			let t = I(e);
			t > pe && (fe = e, pe = t);
		}
		let me = {
			turn: e.turnNumber,
			moves: [...c.moves],
			count: c.count + 1
		};
		if (fe.type === "move") {
			let e = a.moves.find((e) => e.id === fe.route);
			me.moves.push(o.room), !e.to && e.x !== void 0 && (me.entry = (_.get(o.room)?.find((t) => t.id === e.id))?.discover?.port);
		} else c.entry && (me.entry = c.entry);
		return {
			action: fe,
			memory: me
		};
	};
}
var ba = ya(), xa = (e, t, n) => sr(e, t.public, t.private, n), Sa = (e) => /\/(P|Q|R|return)$/.test(e), Ca = (e, t) => {
	let n = e.anchor(t.anchor);
	return n && {
		x: n.x + (t.dx ?? 0) * n.w,
		y: n.y + (t.dy ?? 0) * n.h,
		scale: n.w
	};
};
function wa(e, t) {
	a(() => {
		let n = performance.now(), r = 0, i = (a) => {
			let o = Math.min(1, (a - n) / e);
			t(o), o < 1 && (r = requestAnimationFrame(i));
		};
		return i(n), () => cancelAnimationFrame(r);
	}, [t, e]);
}
function Ta(e, t) {
	let n = t.anchor("cc-map");
	if (!e || !n) return !1;
	for (let [t, r] of Object.entries({
		x: n.x,
		y: n.y,
		width: n.w,
		height: n.h
	})) e.setAttribute(t, String(r));
	return !0;
}
function Ea({ ctx: e, data: t, samples: n, ms: r }) {
	let a = i().replace(/[^a-z0-9]/gi, ""), o = s(null), c = s(null), l = s(null);
	return wa(r, (t) => {
		let i = n.map((t) => Ca(e, t)), a = c.current;
		if (!a || i.some((e) => !e) || !Ta(o.current, e)) {
			a?.setAttribute("visibility", "hidden");
			return;
		}
		let s = i.slice(1).map((e, t) => n[t + 1].jump ? 55 * e.scale : Math.max(.1, Math.hypot(e.x - i[t].x, e.y - i[t].y))), u = s.reduce((e, t) => e + t, 0) * t, d = 0, f = 0;
		for (; d < s.length - 1 && f + s[d] < u;) f += s[d++];
		let p = Math.min(1, (u - f) / s[d]), m = i[d], h = i[d + 1], g = n[d + 1].jump, _ = g ? Number(p >= .5) : p, v = m.x + (h.x - m.x) * _, y = m.y + (h.y - m.y) * _, b = m.scale + (h.scale - m.scale) * _, x = Math.sin(Math.PI * t), S = Math.sin(t * r / 42);
		a.setAttribute("visibility", "visible"), a.setAttribute("transform", `translate(${v},${y}) scale(${b})`), a.setAttribute("opacity", String(g ? Math.abs(p * 2 - 1) : 1)), l.current?.setAttribute("transform", `translate(0,${g ? 0 : -Math.abs(S) * 2 * x}) rotate(${g ? 0 : S * 2.1 * x})`);
		let C = g || t < .05 || t > .94 ? 0 : [
			0,
			1,
			0,
			2
		][Math.floor(t * r / 95) % 4];
		l.current?.querySelectorAll("[data-cc-stride]").forEach((e, t) => {
			e.style.display = t === C ? "" : "none";
		});
	}), /* @__PURE__ */ _("svg", {
		className: "cc-fx-map",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ g("clipPath", {
			id: a,
			children: /* @__PURE__ */ g("rect", { ref: o })
		}) }), /* @__PURE__ */ g("g", {
			clipPath: `url(#${a})`,
			children: /* @__PURE__ */ g("g", {
				ref: c,
				children: /* @__PURE__ */ g("g", {
					ref: l,
					children: /* @__PURE__ */ g(Da, {
						ctx: e,
						data: t
					})
				})
			})
		})]
	});
}
function Da({ ctx: e, data: t }) {
	let n = e.member(t.rid ?? ""), r = v[n?.colorIndex ?? Math.max(0, t.seat - 1)].hex, i = o(() => [
		0,
		-1,
		1
	].map((e) => Gr(r, t.seat, t.seat - 1, e)), [r, t.seat]), a = n?.name ?? t.rid ?? "", s = Array.from(a).slice(0, 14).join(""), c = Math.max(24, Array.from(s).reduce((e, t) => e + (/[\u0020-\u007e]/.test(t) ? 3.3 : 5.5), 10));
	return /* @__PURE__ */ _(h, { children: [i.map((e, t) => /* @__PURE__ */ g("g", {
		"data-cc-stride": t,
		style: { display: t === 0 ? void 0 : "none" },
		dangerouslySetInnerHTML: { __html: e }
	}, t)), t.rid === e.myRid && /* @__PURE__ */ _("g", {
		transform: "translate(0,-60)",
		children: [/* @__PURE__ */ g("path", {
			d: `M${-c + 4} -13H${c - 4}L${c} -9V5L${c - 4} 9H4L0 13 -4 9H${-c + 4}L${-c} 5V-9Z`,
			fill: r,
			stroke: "#e6d0a2"
		}), /* @__PURE__ */ g("text", {
			y: "2",
			textAnchor: "middle",
			fontSize: "11",
			fill: "#fff2d4",
			fontWeight: "750",
			children: s
		})]
	})] });
}
function Oa({ ctx: e, data: t, ms: n, placing: r }) {
	let a = i().replace(/[^a-z0-9]/gi, ""), o = s(null), c = s(null), l = s(null), u = s(null), d = s(null);
	return wa(n, (n) => {
		let i = [
			0,
			1,
			2,
			3
		].map((n) => e.anchor(`cc-corner:${t.tile}:${n}`)), a = e.anchor(Ot(t.entry)) ?? i[0];
		if (i.some((e) => !e) || !a || !Ta(o.current, e)) return;
		let s = Math.max(...i.map((e) => Math.hypot(e.x - a.x, e.y - a.y)));
		c.current?.setAttribute("points", i.map((e) => `${e.x},${e.y}`).join(" ")), c.current?.setAttribute("opacity", String((r ? .52 : 1) * (1 - n ** 2))), d.current?.setAttribute("stdDeviation", String(Math.max(10, a.w * 16)));
		for (let e of [l.current, u.current]) e?.setAttribute("cx", String(a.x)), e?.setAttribute("cy", String(a.y)), e?.setAttribute("rx", String(Math.max(1, s * (n * 1.6 + .02)))), e?.setAttribute("ry", String(Math.max(1, s * (n * 1.4 + .02))));
		u.current?.setAttribute("opacity", String(Math.sin(Math.PI * n) * .19));
	}), /* @__PURE__ */ _("svg", {
		className: "cc-fx-map",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ _("defs", { children: [
			/* @__PURE__ */ g("clipPath", {
				id: `${a}-clip`,
				children: /* @__PURE__ */ g("rect", { ref: o })
			}),
			/* @__PURE__ */ _("radialGradient", {
				id: `${a}-open`,
				children: [
					/* @__PURE__ */ g("stop", {
						offset: ".35",
						stopColor: "black"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".7",
						stopColor: "#777"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "white"
					})
				]
			}),
			/* @__PURE__ */ _("radialGradient", {
				id: `${a}-light`,
				children: [/* @__PURE__ */ g("stop", {
					stopColor: "#efb35f",
					stopOpacity: ".5"
				}), /* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#b76a30",
					stopOpacity: "0"
				})]
			}),
			/* @__PURE__ */ _("mask", {
				id: `${a}-mask`,
				children: [/* @__PURE__ */ g("rect", {
					width: "100%",
					height: "100%",
					fill: "white"
				}), /* @__PURE__ */ g("ellipse", {
					ref: l,
					fill: `url(#${a}-open)`
				})]
			}),
			/* @__PURE__ */ g("filter", {
				id: `${a}-soft`,
				x: "-30%",
				y: "-30%",
				width: "160%",
				height: "160%",
				children: /* @__PURE__ */ g("feGaussianBlur", {
					ref: d,
					stdDeviation: "16"
				})
			})
		] }), /* @__PURE__ */ _("g", {
			clipPath: `url(#${a}-clip)`,
			children: [/* @__PURE__ */ g("polygon", {
				ref: c,
				fill: "#080b12",
				mask: `url(#${a}-mask)`,
				filter: `url(#${a}-soft)`
			}), /* @__PURE__ */ g("ellipse", {
				ref: u,
				fill: `url(#${a}-light)`
			})]
		})]
	});
}
function ka({ ctx: e, room: t, target: n, value: r, ms: a }) {
	let o = i().replace(/[^a-z0-9]/gi, ""), c = s(null), l = s(null);
	return wa(a, (r) => {
		let i = e.anchor(`cc-artifact:${t}`), a = e.anchor(n), o = l.current;
		if (!i || !a || !o || !Ta(c.current, e)) {
			o?.setAttribute("visibility", "hidden");
			return;
		}
		let s = r * r * (3 - 2 * r), u = i.w * (1 - r * .65);
		o.setAttribute("transform", `translate(${i.x + (a.x - i.x) * s},${i.y + (a.y - 28 * a.h - i.y) * s - Math.sin(Math.PI * r) * 32 * i.h}) scale(${u}) rotate(${Math.sin(Math.PI * r) * 9})`), o.setAttribute("opacity", String(Math.min(1, (1 - r) * 5))), o.setAttribute("visibility", "visible");
	}), /* @__PURE__ */ _("svg", {
		className: "cc-fx-map",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ g("clipPath", {
			id: o,
			children: /* @__PURE__ */ g("rect", { ref: c })
		}) }), /* @__PURE__ */ g("g", {
			clipPath: `url(#${o})`,
			children: /* @__PURE__ */ _("g", {
				ref: l,
				children: [
					/* @__PURE__ */ g("ellipse", {
						rx: "27",
						ry: "20",
						fill: "#eac37c",
						opacity: ".16"
					}),
					/* @__PURE__ */ g("path", {
						d: "M-13 8 0-26 14 8 0 18Z",
						fill: "#a8bfea",
						stroke: "#eed5a0",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ g("path", {
						d: "M0-26V18L14 8Z",
						fill: "#7a85b7"
					}),
					/* @__PURE__ */ g("circle", {
						cx: "20",
						cy: "-13",
						r: "11",
						fill: "#e4bf72",
						stroke: "#302f40"
					}),
					/* @__PURE__ */ g("text", {
						x: "20",
						y: "-9",
						textAnchor: "middle",
						fontSize: "12",
						fill: "#302f40",
						fontWeight: "800",
						children: r
					})
				]
			})
		})]
	});
}
var Aa = {
	"cc-action-notice"(e) {
		return {
			ms: 1,
			node: /* @__PURE__ */ g(aa, { notice: e.data })
		};
	},
	"cc-walk"(e, t) {
		let n = e.data, r = Dt(e.rid, n.to);
		if (t.queued || !t.anchor(r)) return null;
		let i = Kr(n.fromCount)[n.fromIndex] ?? [0, 0], a = [{
			anchor: Ot(n.from),
			dx: i[0],
			dy: i[1] + 6
		}];
		if (n.transfer) a.push({
			anchor: r,
			jump: !0
		});
		else for (let e = 1; e < n.path.length; e++) {
			let i = n.path[e - 1], o = n.path[e];
			for (let e = 0; e < 7; e++) {
				let n = At(i, o, e);
				t.anchor(n) && a.push({
					anchor: n,
					dy: 6
				});
			}
			a.push({
				anchor: e === n.path.length - 1 ? r : Ot(o),
				dy: e === n.path.length - 1 ? 0 : 6,
				jump: Sa(i) && Sa(o)
			});
		}
		if (a.length < 2 || a.some((e) => !Ca(t, e))) return null;
		let o = n.transfer ? Tt.transfer : Et(n.path.length);
		return {
			ms: o,
			hide: [r],
			node: /* @__PURE__ */ g(Ea, {
				ctx: t,
				data: {
					...n,
					rid: e.rid
				},
				samples: a,
				ms: o
			})
		};
	},
	"cc-explore"(e, t) {
		let n = e.data, r = `cc-tile:${n.tile}`;
		return t.queued || !t.anchor(r) ? null : {
			ms: Tt.explore,
			hide: [r],
			node: /* @__PURE__ */ g(Oa, {
				ctx: t,
				data: n,
				ms: Tt.explore,
				placing: !1
			})
		};
	},
	"cc-place"(e, t) {
		let n = e.data, r = kt(n.tile, n.rotation);
		return t.queued || !t.anchor(r) ? null : {
			ms: Tt.place,
			hide: [r],
			node: /* @__PURE__ */ g(Oa, {
				ctx: t,
				data: n,
				ms: Tt.place,
				placing: !0
			})
		};
	},
	"cc-artifact"(e, t) {
		let n = e.data, r = Dt(e.rid, n.to);
		return t.queued || !t.anchor(`cc-artifact:${n.room}`) || !t.anchor(r) ? null : {
			ms: Tt.artifact,
			node: /* @__PURE__ */ g(ka, {
				ctx: t,
				room: n.room,
				target: r,
				value: n.value,
				ms: Tt.artifact
			})
		};
	}
};
//#endregion
//#region src/games/clankcatacombs/game-over-row.tsx
function ja({ public: e, rid: t }) {
	let n = d(), r = e.scores?.[t];
	return r ? /* @__PURE__ */ g("div", {
		className: "flex flex-wrap gap-x-3 gap-y-1 text-xs",
		children: r.eligible ? [
			["artifacts", X.scoreArtifacts],
			["gold", X.gold],
			["cards", X.scoreCards],
			["tokens", X.scoreTokens],
			["market", X.scoreMarket],
			["trophies", X.scoreTrophies],
			["fate", X.scoreFate],
			["mastery", X.scoreMastery]
		].filter(([e]) => r[e] !== 0).map(([e, t]) => /* @__PURE__ */ _("span", { children: [
			n(t),
			" ",
			r[e]
		] }, e)) : n(X.ineligible)
	}) : null;
}
//#endregion
//#region src/games/clankcatacombs/options.tsx
function Ma({ value: e, onChange: t }) {
	let n = d(), r = Pt.safeParse(e), i = r.success ? r.data : Pt.parse(void 0);
	return /* @__PURE__ */ _("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ _(se, {
			title: n(X.expansions),
			children: [[
				["lairs", X.lairs],
				["underworld", X.underworldOption],
				["party", X.party]
			].map(([e, r]) => /* @__PURE__ */ g(j, {
				checked: i[e],
				label: n(r),
				accent: Kn.accent,
				onChange: () => t({
					...i,
					[e]: !i[e],
					characters: e === "party" && i.party ? !1 : i.characters
				})
			}, e)), i.party && /* @__PURE__ */ g(j, {
				checked: i.characters,
				label: n(X.characters),
				accent: Kn.accent,
				onChange: () => t({
					...i,
					characters: !i.characters
				})
			})]
		}), [["start", X.startingTile], ...i.underworld ? [["underworldStart", X.underworldTile]] : []].map(([e, r]) => /* @__PURE__ */ g(se, {
			title: n(r),
			children: ["front", "back"].map((r) => /* @__PURE__ */ g(oe, {
				name: e,
				value: r,
				checked: i[e] === r,
				label: n(X[r]),
				accent: Kn.accent,
				onChange: () => t({
					...i,
					[e]: r
				})
			}, r))
		}, e))]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/clankcatacombs/entry.tsx
var Na = {
	definition: $n,
	View: _a,
	bot: ba,
	describe: xa,
	fx: Aa,
	RowView: ja,
	Options: Ma,
	locales: {
		zh: {
			name: "噤声寻宝记：地下墓穴",
			desc: "探索不断拼接的地下城，构筑牌库，夺取神器并逃出龙穴。",
			invalid: "该操作当前不可用。",
			ui: {
				confirmAcquire: "获得 {{card}} · {{n}} 技能",
				confirmDefeat: "击败 {{card}} · {{n}} 剑",
				confirmDevice: "使用 {{card}} · {{n}} 技能",
				bubbleArtifact: "神器",
				bubbleIdol: "猴神像",
				bubbleTrophy: "战利品",
				bubbleItem: "市场物品",
				bubbleFate: "命运牌",
				bubbleGhost: "噪音区幽灵",
				bubbleTile: "已探索板块",
				bubbleRotate: "旋转 {{n}} 块板块",
				bubbleTop: "将 {{n}} 张牌放到牌库顶",
				bubbleReplace: "移出 {{n}} 张地下城牌",
				bubbleMirror: "交换牌库与弃牌堆",
				bubbleReveal: "展示 {{card}}",
				bubbleIgnoreMonsters: "忽略通道怪物",
				bubbleReroll: "可重抽探索板块",
				bubbleRerollArtifact: "可重抽不含神器的探索板块",
				bubbleDeviceDiscount: "使用装置少付 2 技能",
				bubbleMarketDiscount: "购买市场物品少付 2 金币",
				bubbleCountsTome: "视为打出典籍",
				bubbleReverse: "可逆向通过单向通道",
				bubbleInspire: "回合结束时可将同伴放到牌库顶",
				bubbleAcquire: "获得 {{card}}",
				bubbleDefeat: "击败 {{card}}",
				bubbleDevice: "使用 {{card}}",
				bubbleArrive: "出现：{{card}}",
				bubbleDraw: "抽 {{n}} 张牌",
				bubbleDiscard: "弃 {{n}} 张牌",
				bubbleTrash: "移除 {{card}}",
				bubbleTeleport: "传送",
				bubblePrisoner: "释放 {{n}} 名囚犯",
				bubbleSecret: "获得 {{n}} 个秘密",
				bubbleIgnoreCave: "忽略洞穴停步",
				bubbleMarket: "可在任意房间购买市场物品",
				bubbleMana: "魔力",
				bubbleHealth: "生命",
				bubbleOtherPlayers: "{{n}} 位其他玩家",
				bubbleSource: "{{name}} · {{card}}",
				turn: "第 {{n}} 回合",
				yourTurn: "轮到你行动",
				waiting: "等待 {{name}} 行动",
				resolving: "正在结算",
				dragon: "巨龙袭击",
				choose: "请选择",
				hand: "手牌",
				dungeon: "地下城牌列",
				actions: "行动",
				freedPrisoners: "已释放囚犯（{{n}}）",
				noPrisoners: "暂无",
				supplies: "补给与市场",
				players: "探险者",
				log: "对局记录",
				close: "关闭",
				details: "详情",
				catacombs: "地下墓穴",
				basicCard: "基础牌",
				reserveCard: "常备牌",
				actionCard: "行动",
				companion: "同伴",
				gem: "宝石",
				monster: "怪物",
				device: "装置",
				danger: "危险",
				playedCards: "查看已打出的牌",
				deck: "牌库",
				dragonRage: "巨龙怒气",
				room: "房间 {{n}}",
				unknown: "未知区域",
				viewMap: "查看全图",
				locate: "定位自己",
				rotate: "旋转 {{n}}°",
				confirm: "确认",
				cancel: "取消",
				end: "结束回合",
				play: "打出 {{card}}",
				row: "{{card}} · 使用 {{n}} {{resource}}",
				reserve: "获得 {{card}} · {{n}} 技能",
				move: "前往 {{room}} · {{swords}} 剑",
				artifact: "拿取神器",
				unlock: "开锁：{{item}}",
				mark: "标记：{{item}}",
				market: "购买 {{item}} · {{n}} 金币",
				fight: "击败 {{item}} · {{resource}}",
				use: "使用 {{item}}",
				react: "反应：{{card}}",
				pass: "放弃反应",
				chooseTarget: "{{option}}：{{target}}",
				noAction: "暂无可用行动",
				skill: "技能",
				swords: "剑",
				boots: "靴",
				gold: "金币",
				silver: "冥币",
				picks: "开锁器",
				noise: "噪音",
				health: "生命 {{n}} / 10",
				deckCount: "牌库 {{n}}",
				artifactCount: "神器：{{n}}",
				rage: "怒气 {{n}}",
				tiles: "剩余板块 {{n}}",
				bag: "龙袋 {{n}}",
				turnResources: "本回合资源",
				playArea: "打出区",
				discard: "弃牌堆",
				fates: "命运牌",
				chooseCharacter: "选择角色",
				orient: "选择新板块的朝向",
				movement: "选择目的房间",
				secretCount: "秘密 {{n}}",
				safe: "安全区",
				depths: "深处",
				underworld: "冥界",
				active: "探险中",
				escaped: "已逃出",
				knocked: "已昏迷",
				score: "得分 {{n}}",
				eligible: "可计分",
				ineligible: "未能带回神器",
				expansions: "扩展",
				lairs: "巢穴与失落密室",
				underworldOption: "冥界",
				party: "冒险派对",
				characters: "使用六名角色",
				startingTile: "起始板",
				front: "正面",
				back: "背面",
				underworldTile: "冥界起始板",
				points: "{{n}} 分",
				acquireEffect: "获得：{{text}}",
				arriveEffect: "出现：{{text}}",
				reactEffect: "反应条件：{{text}}",
				moveCost: "{{boots}} 靴 · {{swords}} 剑 · {{damage}} 伤害 · {{picks}} 开锁器 · {{silver}} 冥币",
				payment: "支付：{{item}}",
				spell: "施放 {{item}}",
				scoreArtifacts: "神器",
				scoreCards: "卡牌",
				scoreTokens: "秘密与囚犯",
				scoreMarket: "市场物品",
				scoreTrophies: "战利品",
				scoreFate: "命运",
				scoreMastery: "逃脱奖励",
				empty: "无",
				chooseRoute: "选择路线",
				underworldSlot: "冥界板块 {{letter}}",
				mana: "法力 {{n}}",
				cogs: "已揭示齿轮 {{n}} / 7",
				conscription: "征召标记 {{n}}",
				carnage: "屠戮进度 {{n}} / 5",
				behavior: "已翻转行为：{{items}}",
				ladder: "通往冥界 {{letter}} 的梯子",
				placeTarget: "空位 {{n}}",
				fateHelp: "{{name}}：{{text}}",
				"log-play": "打出 {{item}}",
				"log-react": "保留反应牌 {{item}}",
				"log-acquire": "获得 {{item}}",
				"log-device": "使用 {{item}}",
				"log-defeat": "击败 {{item}}",
				"log-trash": "移除 {{item}}",
				"log-move": "进入 {{item}}",
				"log-artifact": "拿取 {{n}} 分神器",
				"log-secret": "发现 {{item}}",
				"log-prisoner": "释放 {{item}}",
				"log-market": "购买 {{item}}",
				"log-dragon": "巨龙袭击，抽取 {{n}} 枚方块",
				"log-damage": "受到 {{n}} 点伤害",
				"log-escape": "携带神器逃出墓穴",
				"log-knockout": "昏迷",
				"log-discover": "发现 {{item}}",
				"log-reveal": "展示 {{item}}",
				"log-fate": "展示 {{item}}"
			},
			names: {
				adventurer: "冒险者",
				agnet: "阿涅特",
				dallan: "达兰",
				garignar: "加里格纳",
				lenara: "蕾娜拉",
				monkeybot: "猿王机械猴",
				whiskers: "胡须先生",
				backpack: "背包",
				amulet: "血之护符",
				"amulet-uw": "血之护符",
				kit: "盗贼工具包",
				crown: "王冠",
				cloak: "隐形斗篷",
				"river-lamp": "河灯",
				"wind-boots": "风之靴",
				gauntlets: "命运护手",
				"jester-cap": "小丑帽",
				riverboat: "渡河船",
				crypt: "墓穴出口",
				cave: "水晶洞穴",
				minor: "小秘密",
				major: "大秘密",
				chest: "宝箱",
				library: "图书室",
				prison: "监牢",
				prison3: "监牢",
				wayshrine: "路边神龛",
				aegis: "守护神龛",
				altar: "亡灵祭坛",
				bazaar: "奇异集市",
				temple: "黄金神殿",
				hoard: "巨龙宝库",
				medusa: "美杜莎",
				sphinx: "斯芬克斯",
				statue: "活化雕像",
				guardian: "冥界守卫",
				harpy: "鹰身女妖",
				fate: "命运之室",
				lyre: "魔法竖琴",
				imp: "小恶魔助手",
				market: "市场",
				pit: "陷坑",
				lake: "地下湖",
				tower: "高塔",
				idol: "猴神像",
				chute: "滑道",
				egg: "龙蛋",
				pick: "开锁器",
				spring: "魔法泉水",
				heal1: "小治疗药水",
				heal2: "大治疗药水",
				boots: "速度药水",
				swords: "力量药水",
				puzzlebox: "机关盒",
				gold2: "两枚金币",
				gold5: "五枚金币",
				skill5: "五点技能",
				map: "墓穴地图",
				chalice: "圣杯",
				"book-dead": "亡者之书",
				"greater-hope": "大希望药水",
				silver4: "四枚冥币",
				"dark-iron": "黑铁",
				hope: "希望药水",
				stealth: "隐匿药水",
				coupon: "折扣券",
				"soul-elixir": "灵魂灵药",
				barbarian: "野蛮人",
				primatologist: "灵长类学家",
				sorceress: "女巫",
				cleric: "牧师",
				haunted: "闹鬼的囚犯",
				warrior: "战士",
				prince: "王子",
				princess: "公主",
				monk: "僧侣",
				peasant: "农夫",
				mayor: "镇长",
				faithful: "虔信者",
				myrmidon: "幽魂卫士",
				goblin: "哥布林",
				transfigure: "变形术",
				duplicate: "复制术",
				levitate: "浮空术",
				"fate-fool": "愚者",
				"fate-magician": "魔术师",
				"fate-high-priestess": "女祭司",
				"fate-empress": "皇后",
				"fate-emperor": "皇帝",
				"fate-hierophant": "教皇",
				"fate-lovers": "恋人",
				"fate-chariot": "战车",
				"fate-strength": "力量",
				"fate-hermit": "隐士",
				"fate-wheel": "命运之轮",
				"fate-justice": "正义",
				"fate-hanged-man": "倒吊人",
				"fate-death": "死神",
				"fate-temperance": "节制",
				"fate-imp": "小恶魔",
				"fate-tower": "高塔",
				"fate-star": "星星",
				"fate-moon": "月亮",
				"fate-sun": "太阳",
				"fate-judgement": "审判",
				"fate-world": "世界",
				"option-skip": "放弃",
				"option-teleport": "传送",
				"option-swap": "交换位置",
				"option-quiet": "减少噪音",
				"option-loud": "更多金币与噪音",
				"option-gold": "获得金币",
				"option-caves": "无视洞穴停步",
				"option-pick": "获得开锁器",
				"option-steal": "夺取",
				"option-draw": "抽牌",
				"option-trash": "移除卡牌",
				"option-discard": "弃牌",
				"option-trophy": "战利品",
				"option-boot": "获得靴",
				"option-boots": "获得靴",
				"option-heal": "治疗",
				"option-minor": "小秘密",
				"option-market": "市场物品",
				"option-top": "放到牌库顶",
				"option-replace": "移出牌列",
				"option-mark": "标记神龛",
				"option-return": "放回神器堆",
				"option-artifact": "拿取神器",
				"option-rotate": "旋转板块",
				"option-place": "放置板块",
				"option-fall": "跌入陷坑",
				"option-fight": "击败怪物",
				"option-damage": "承受伤害",
				"option-fate": "选择命运",
				"option-reveal": "展示命运牌",
				"option-aegis": "使用守护神龛",
				"option-acquire": "获得卡牌",
				"option-skill": "获得技能",
				"option-swords": "获得剑",
				"option-copy": "复制卡牌",
				"option-silver": "使用冥币",
				"option-tome": "获得秘密典籍",
				"option-egg": "龙蛋：减少噪音",
				"option-idol": "猴神像：移除行窃",
				"option-crown": "王冠：无视洞穴",
				"free-prisoner": "释放囚犯"
			},
			cards: {
				"skeleton-priest": {
					name: "骷髅祭司",
					text: "+1 治疗；+1 噪音",
					acquire: "",
					arrive: "+1 噪音（所有玩家）",
					react: ""
				},
				"darkened-alcove": {
					name: "阴暗壁龛",
					text: "-2 噪音",
					acquire: "",
					arrive: "",
					react: ""
				},
				"lie-in-wait": {
					name: "埋伏",
					text: "位于水晶洞穴：-2 噪音",
					acquire: "可将刚获得的这张牌放到牌库顶",
					arrive: "",
					react: ""
				},
				"smash-and-grab": {
					name: "砸抢",
					text: "+2 噪音；抽 2 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				bard: {
					name: "吟游诗人",
					text: "+1 噪音；本回合制造至少 2 点噪音：+2 治疗",
					acquire: "",
					arrive: "",
					react: ""
				},
				"expert-guide": {
					name: "资深向导",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				skeleton: {
					name: "骷髅",
					text: "+2 金币；+1 噪音",
					acquire: "",
					arrive: "",
					react: ""
				},
				robbery: {
					name: "抢劫",
					text: "+2 金币；位于市场：可传送到相邻房间",
					acquire: "可将刚获得的这张牌放到牌库顶",
					arrive: "",
					react: ""
				},
				swindle: {
					name: "诈骗",
					text: "+3 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				arcoverlord: {
					name: "大魔君",
					text: "抽 2 张牌；+1 噪音（其他玩家）",
					acquire: "",
					arrive: "+1 噪音（所有玩家）",
					react: ""
				},
				pillage: {
					name: "劫掠",
					text: "本回合获得至少 3 金币：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				scavenger: {
					name: "拾荒者",
					text: "",
					acquire: "获得一个小秘密",
					arrive: "",
					react: ""
				},
				lightstick: {
					name: "荧光棒",
					text: "+1 噪音",
					acquire: "",
					arrive: "",
					react: ""
				},
				"sneak-attack": {
					name: "偷袭",
					text: "-2 噪音",
					acquire: "+1 剑",
					arrive: "",
					react: ""
				},
				"white-tourmaline": {
					name: "白碧玺",
					text: "抽 1 张牌",
					acquire: "+2 噪音",
					arrive: "",
					react: ""
				},
				"black-tourmaline": {
					name: "黑碧玺",
					text: "抽 1 张牌",
					acquire: "+2 噪音",
					arrive: "",
					react: ""
				},
				flamboyance: {
					name: "张扬",
					text: "抽 1 张牌；本回合制造至少 2 点噪音：+2 技能",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-scribe": {
					name: "反抗军书记员",
					text: "打出区有另一名伙伴：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				bandit: {
					name: "匪徒",
					text: "",
					acquire: "+1 靴；+1 剑",
					arrive: "",
					react: ""
				},
				"underground-river": {
					name: "地下河",
					text: "选择一项：+1 治疗 / +1 靴",
					acquire: "",
					arrive: "",
					react: ""
				},
				"spectral-rider": {
					name: "幽灵骑手",
					text: "位于闹鬼板块：可传送到其他板块的任意房间",
					acquire: "",
					arrive: "",
					react: ""
				},
				librarian: {
					name: "图书管理员",
					text: "-2 噪音；打出区或弃牌堆有秘密典籍：抽 2 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-general": {
					name: "反抗军将军",
					text: "打出区有另一名伙伴：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-paladin": {
					name: "反抗军圣骑士",
					text: "打出区有另一名伙伴：抽 1 张牌；持有神器：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-thief": {
					name: "反抗军盗贼",
					text: "+1 开锁器；打出区有另一名伙伴：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"imp-familiar": {
					name: "小恶魔魔宠",
					text: "选择一项：+1 开锁器 / 使用一个开锁器，抽两张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"floating-skull": {
					name: "漂浮骷髅",
					text: "持有王冠：可传送到相邻房间",
					acquire: "可传送到相邻房间",
					arrive: "",
					react: ""
				},
				charlatan: {
					name: "江湖骗子",
					text: "弃一张手牌，然后抽两张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				empurror: {
					name: "猫皇",
					text: "选择一项：-2 噪音 / +1 金币 / 本回合无需在水晶洞穴停步；持有神器：若持有神器，获得其余两项奖励",
					acquire: "",
					arrive: "",
					react: ""
				},
				curator: {
					name: "馆长",
					text: "每持有一件神器，抽一张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"corrupt-advisor": {
					name: "腐败顾问",
					text: "+1 噪音（其他玩家）；持有王冠：+1 噪音（其他玩家）",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rose-quartz": {
					name: "蔷薇石英",
					text: "-2 噪音；抽 1 张牌",
					acquire: "+2 噪音",
					arrive: "",
					react: ""
				},
				"smoky-quartz": {
					name: "烟石英",
					text: "-2 噪音；抽 1 张牌",
					acquire: "+2 噪音",
					arrive: "",
					react: ""
				},
				"fiery-quartz": {
					name: "烈焰石英",
					text: "-2 噪音；抽 1 张牌",
					acquire: "+2 噪音",
					arrive: "",
					react: ""
				},
				waystone: {
					name: "道标石",
					text: "位于路边神龛时，可移除此牌并传送到另一处神龛",
					acquire: "",
					arrive: "",
					react: ""
				},
				"brave-hero": {
					name: "英勇斗士",
					text: "已释放至少三名囚犯时，价值 5 分。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"remove-traps": {
					name: "排除陷阱",
					text: "替换一张牌列中的牌，不触发替补牌上的龙袭图标",
					acquire: "",
					arrive: "",
					react: ""
				},
				"sudden-movement": {
					name: "突然行动",
					text: "",
					acquire: "",
					arrive: "每名独占方形板块的玩家必须旋转该板块",
					react: ""
				},
				souldrinker: {
					name: "噬魂剑",
					text: "本回合击败过牌列怪物：+1 治疗",
					acquire: "",
					arrive: "",
					react: ""
				},
				"shadow-walk": {
					name: "暗影步",
					text: "可移除打出区或弃牌堆的一张行窃",
					acquire: "",
					arrive: "",
					react: ""
				},
				"thirst-for-adventure": {
					name: "冒险渴望",
					text: "每件神器及每枚猴神像各值 2 分。",
					acquire: "+3 靴",
					arrive: "",
					react: ""
				},
				riot: {
					name: "暴动",
					text: "+1 噪音；已释放至少三名囚犯：可移除打出区或弃牌堆的一张牌",
					acquire: "释放一名囚犯",
					arrive: "",
					react: ""
				},
				"astral-projection": {
					name: "星界投射",
					text: "本回合累计产生至少 6 点技能：可标记任意路边神龛，如同身处该房间",
					acquire: "",
					arrive: "",
					react: ""
				},
				diversion: {
					name: "声东击西",
					text: "",
					acquire: "释放一名囚犯",
					arrive: "将银行中至多 3 个黑色方块放回龙袋",
					react: ""
				},
				"elven-sword": {
					name: "精灵剑",
					text: "抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				payoff: {
					name: "封口费",
					text: "移除这张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"double-cross": {
					name: "背信弃义",
					text: "-2 噪音",
					acquire: "+2 噪音（其他玩家）",
					arrive: "",
					react: ""
				},
				"blink-spell": {
					name: "闪现术",
					text: "选择一项：可传送到相邻房间 / 可与深处的另一名玩家交换位置",
					acquire: "",
					arrive: "",
					react: ""
				},
				lute: {
					name: "鲁特琴",
					text: "+1 噪音；抽 2 张牌；本回合每制造 1 点噪音，获得 1 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				"divining-rod": {
					name: "探测杖",
					text: "本回合累计产生至少 6 点技能：+1 治疗",
					acquire: "",
					arrive: "",
					react: ""
				},
				"expensive-taste": {
					name: "奢华品味",
					text: "获得 2 金币。若有王冠和宝石，此牌价值 5 分。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"golden-flute": {
					name: "黄金长笛",
					text: "+1 金币；+1 噪音；本回合可在任意位置花 5 金币购买一件市场物品",
					acquire: "",
					arrive: "",
					react: ""
				},
				"grand-theft": {
					name: "大窃案",
					text: "选择一项：+1 开锁器 / 花一个开锁器，免费使用一件装置或获得牌列中的一张牌",
					acquire: "可将刚获得的这张牌放到牌库顶",
					arrive: "",
					react: ""
				},
				"boots-of-the-ape-lords": {
					name: "猿王之靴",
					text: "+3 噪音；持有猴神像：本回合无需在水晶洞穴停步",
					acquire: "",
					arrive: "",
					react: ""
				},
				"crystal-compass": {
					name: "水晶罗盘",
					text: "抽 2 张牌；本回合无需在水晶洞穴停步",
					acquire: "",
					arrive: "",
					react: ""
				},
				"animated-wall": {
					name: "活化墙",
					text: "+1 靴；本回合使用过传送门：+1 靴",
					acquire: "",
					arrive: "将所有有玩家的方形板块旋转 180°",
					react: ""
				},
				"ogre-merchant": {
					name: "食人魔商人",
					text: "选择一项：+5 金币 / 位于市场时，可免费获得一件市场物品",
					acquire: "",
					arrive: "",
					react: ""
				},
				keymaster: {
					name: "钥匙大师",
					text: "+1 开锁器",
					acquire: "",
					arrive: "",
					react: ""
				},
				"thieves-shrine": {
					name: "盗贼神龛",
					text: "选择一项：+2 金币 / 可移除打出区或弃牌堆的一张行窃、可移除打出区或弃牌堆的一张行窃",
					acquire: "",
					arrive: "将银行中至多 3 个黑色方块放回龙袋",
					react: ""
				},
				"locked-trunk": {
					name: "上锁的箱子",
					text: "-1 开锁器；使用开锁器；获得一个大秘密",
					acquire: "",
					arrive: "",
					react: ""
				},
				"wishing-well": {
					name: "许愿井",
					text: "花 3 金币，抽两张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"skeletal-ape": {
					name: "骷髅巨猿",
					text: "+3 技能；+3 金币；+3 噪音",
					acquire: "",
					arrive: "",
					react: ""
				},
				"the-warden": {
					name: "典狱长",
					text: "释放一名囚犯；释放一名囚犯",
					acquire: "",
					arrive: "",
					react: ""
				},
				"black-market": {
					name: "黑市",
					text: "选择两项不同奖励：2 金币、移除一张牌、获得开锁器",
					acquire: "",
					arrive: "",
					react: ""
				},
				"crystal-kobold": {
					name: "水晶狗头人",
					text: "+2 技能",
					acquire: "",
					arrive: "",
					react: ""
				},
				"skeleton-warlock": {
					name: "骷髅术士",
					text: "获得一张秘密典籍；+1 噪音",
					acquire: "",
					arrive: "",
					react: ""
				},
				"marble-guardian": {
					name: "大理石守卫",
					text: "在当前板块旁放置新板块，选择传送过去或获得 2 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				skulker: {
					name: "潜伏者",
					text: "本回合忽略通道怪物",
					acquire: "本回合忽略通道怪物",
					arrive: "",
					react: ""
				},
				scuffler: {
					name: "斗殴者",
					text: "其他玩家各选一项：减少 2 噪音、获得 2 金币、移除弃牌堆的一张行窃。你获得全部三项",
					acquire: "",
					arrive: "",
					react: ""
				},
				"royal-brat": {
					name: "王室顽童",
					text: "持有王冠：获得一个小秘密",
					acquire: "",
					arrive: "",
					react: "对手获得一个大秘密，或同回合获得两个秘密"
				},
				"elven-satchel": {
					name: "精灵挎包",
					text: "+2 金币；抽 1 张牌",
					acquire: "",
					arrive: "每人选获得 1 金币，或制造 1 噪音并抽一张牌",
					react: ""
				},
				"flawed-emerald": {
					name: "瑕疵祖母绿",
					text: "抽 1 张牌",
					acquire: "+2 噪音；+1 噪音（其他玩家）",
					arrive: "",
					react: ""
				},
				assassin: {
					name: "刺客",
					text: "-2 噪音",
					acquire: "",
					arrive: "",
					react: "怪物出现在牌列中"
				},
				"spiritual-healer": {
					name: "灵魂医师",
					text: "打出区或弃牌堆有宝石：+1 治疗；+1 噪音",
					acquire: "",
					arrive: "每人可制造 2 噪音，治疗 1 点",
					react: ""
				},
				"walk-it-off": {
					name: "走走就好",
					text: "",
					acquire: "+1 治疗",
					arrive: "",
					react: "你在龙袭中受到伤害"
				},
				"flawed-sapphire": {
					name: "瑕疵蓝宝石",
					text: "抽 1 张牌",
					acquire: "+2 噪音；+1 噪音（其他玩家）",
					arrive: "",
					react: ""
				},
				berserker: {
					name: "狂战士",
					text: "本回合每制造 1 噪音，获得 1 剑",
					acquire: "",
					arrive: "",
					react: "对手击败哥布林"
				},
				"scouting-ahead": {
					name: "前出侦察",
					text: "本回合无需在水晶洞穴停步",
					acquire: "",
					arrive: "",
					react: "对手在水晶洞穴中结束回合"
				},
				"one-with-everything": {
					name: "样样俱全",
					text: "+1 金币",
					acquire: "",
					arrive: "",
					react: "对手使用装置"
				},
				"virtuoso-burglar": {
					name: "神偷",
					text: "-2 噪音；可移除打出区或弃牌堆的一张行窃",
					acquire: "",
					arrive: "每人可制造 1 噪音，移除手牌或弃牌堆的一张行窃",
					react: ""
				},
				"hiding-place": {
					name: "藏身处",
					text: "+2 剑",
					acquire: "",
					arrive: "每人可弃一张手牌中的行窃，减少 2 噪音",
					react: ""
				},
				"time-warp": {
					name: "时间扭曲",
					text: "可传送到相邻房间",
					acquire: "",
					arrive: "",
					react: "对手在本回合没有移动便结束回合"
				},
				spotter: {
					name: "观察员",
					text: "-2 噪音；每人可制造 1 噪音，获得 2 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				cutpurse: {
					name: "扒手",
					text: "选择一项：+1 靴 / +2 金币；可弃一张手牌，再抽一张",
					acquire: "",
					arrive: "",
					react: "对手进入市场房间"
				},
				"secret-passage": {
					name: "秘密通道",
					text: "-2 噪音；+2 靴",
					acquire: "",
					arrive: "每人可花 5 金币，获得秘密典籍",
					react: ""
				},
				tactician: {
					name: "战术家",
					text: "",
					acquire: "",
					arrive: "",
					react: "牌列中有至少三个空位"
				},
				"too-bad-for-you": {
					name: "算你倒霉",
					text: "",
					acquire: "",
					arrive: "",
					react: "对手结束回合时，噪音区至少有两枚其颜色的方块"
				},
				"flawed-ruby": {
					name: "瑕疵红宝石",
					text: "抽 1 张牌",
					acquire: "+2 噪音；+1 噪音（其他玩家）",
					arrive: "",
					react: ""
				},
				"pixie-swarm": {
					name: "妖精群",
					text: "+1 金币",
					acquire: "",
					arrive: "每人可展示手中一张提供剑的牌，获得 1 金币",
					react: ""
				},
				"ape-lord-phantasm": {
					name: "猿王幻影",
					text: "抽 2 张牌；可将任意数量的猴神像归还到一处猴神像房间，每归还一枚获得一张秘密典籍",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-herald": {
					name: "反抗军传令官",
					text: "打出区有另一名伙伴：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: "牌列中有至少两名伙伴"
				},
				leprechaun: {
					name: "矮妖",
					text: "获得 7 金币，制造 4 点噪音",
					acquire: "",
					arrive: "每人选择 2 金币和 1 噪音，或 5 金币和 3 噪音",
					react: ""
				},
				succubus: {
					name: "魅魔",
					text: "+1 治疗；+3 金币；其他玩家各选获得 3 金币或治疗 1 点",
					acquire: "",
					arrive: "",
					react: ""
				},
				"magic-kazoo": {
					name: "魔法卡祖笛",
					text: "在此牌上放 6 金币。每回合开始时，制造 2 噪音并取走其中 2 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				"unlock-potential": {
					name: "释放潜能",
					text: "选择一项：抽 1 张牌 / 移除一件战利品，抽三张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"thirst-for-knowledge": {
					name: "求知欲",
					text: "制造 1 噪音。每本秘密典籍使此牌价值 1 分。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"tome-of-fire": {
					name: "火焰秘典",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				jailer: {
					name: "狱卒",
					text: "+1 开锁器；释放一名囚犯",
					acquire: "",
					arrive: "",
					react: ""
				},
				amethyst: {
					name: "紫水晶",
					text: "-2 噪音；抽 1 张牌",
					acquire: "+2 噪音",
					arrive: "",
					react: ""
				},
				swashbuckling: {
					name: "勇闯险境",
					text: "本回合在通道中每击败一只怪物，获得 1 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				"loot-chute": {
					name: "战利品滑道",
					text: "+2 金币；+2 靴",
					acquire: "",
					arrive: "",
					react: ""
				},
				"heart-of-the-dark": {
					name: "黑暗之心",
					text: "战利品：每次获得战利品（包括此牌），减少 2 噪音。价值 −2 分。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"cave-bat-wings": {
					name: "洞窟蝠翼",
					text: "战利品：打出区或弃牌堆有秘密典籍时，无需在水晶洞穴停步；有逃脱奖励时价值 4 分。",
					acquire: "",
					arrive: "",
					react: ""
				},
				jailbreaker: {
					name: "劫狱者",
					text: "本回合释放过囚犯：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"pack-rat": {
					name: "囤积鼠",
					text: "免费获得费用不超过 4 的一张牌；有背包时将其放入手牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"false-bottom": {
					name: "暗格",
					text: "+1 开锁器；位于陷坑：+3 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				acrobatics: {
					name: "杂技",
					text: "若陷坑使你从手牌移除此牌，免费获得费用不超过 4 的一张牌并放入手牌。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"skeleton-troubadour": {
					name: "骷髅歌手",
					text: "获得一个小秘密；+1 噪音",
					acquire: "",
					arrive: "",
					react: ""
				},
				"pit-fiend": {
					name: "深坑恶魔",
					text: "+2 金币；+1 噪音；位于陷坑：释放一名囚犯",
					acquire: "",
					arrive: "",
					react: ""
				},
				"silver-arch": {
					name: "银色拱门",
					text: "可传送到另一处巢穴或失落密室",
					acquire: "",
					arrive: "",
					react: ""
				},
				forage: {
					name: "搜寻",
					text: "+1 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				"swords-and-sorcery": {
					name: "剑与魔法",
					text: "抽 1 张牌；本回合累计产生至少 4 剑：可传送到相邻房间",
					acquire: "",
					arrive: "可将房间中价值最低的神器放回神器堆顶（魔法竖琴除外）",
					react: ""
				},
				alarm: {
					name: "警报",
					text: "+1 噪音（其他玩家）",
					acquire: "",
					arrive: "",
					react: ""
				},
				"mechanical-donkey": {
					name: "机械驴",
					text: "战利品：通常价值 2 分；携带神器在深处昏迷时，失去全部金币，但仍计其他分数，此牌改为 8 分。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"artifact-detector": {
					name: "神器探测器",
					text: "本回合探索到无神器板块时可重新抽取",
					acquire: "",
					arrive: "可将房间中价值最低的神器放回神器堆顶（魔法竖琴除外）",
					react: ""
				},
				spelunker: {
					name: "洞穴探险家",
					text: "+1 噪音",
					acquire: "",
					arrive: "",
					react: ""
				},
				negotiator: {
					name: "谈判专家",
					text: "本回合购买市场物品少付 2 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				devotion: {
					name: "虔诚",
					text: "每枚放在地下城中的个人方块使此牌价值 1 分。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-messenger": {
					name: "反抗军信使",
					text: "打出区有另一名伙伴：抽 1 张牌",
					acquire: "+1 靴",
					arrive: "",
					react: ""
				},
				"swap-meet": {
					name: "交换集会",
					text: "位于巢穴或失落密室时，可移除此牌及一件战利品，免费获得一件市场物品",
					acquire: "",
					arrive: "",
					react: ""
				},
				"cavern-prowler": {
					name: "洞穴潜行兽",
					text: "免费获得一张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"venomous-lurker": {
					name: "毒性潜伏者",
					text: "击败：获得 3 金币。战利品：位于水晶洞穴时，不能治疗。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"ape-lord-epaulets": {
					name: "猿王肩章",
					text: "战利品：有猴神像或王冠时价值 3 分；两者都有则价值 7 分。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"golden-hourglass": {
					name: "黄金沙漏",
					text: "战利品：每次洗混牌库，获得 1 金币。",
					acquire: "",
					arrive: "可将房间中价值最低的神器放回神器堆顶（魔法竖琴除外）",
					react: ""
				},
				"quick-pick": {
					name: "迅捷开锁",
					text: "本回合使用过开锁器：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"merchants-guild-pin": {
					name: "商会徽章",
					text: "战利品：购买每件市场物品少付 1 金币。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"monkey-paw": {
					name: "猴爪",
					text: "+1 噪音；持有猴神像：可移除打出区或弃牌堆的一张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"skeleton-herald": {
					name: "骷髅传令官",
					text: "+1 噪音；本回合已制造的每点噪音提供 1 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				"hoard-keeper": {
					name: "宝库守卫",
					text: "击败：获得 3 金币并制造 1 噪音。战利品：每持有 5 金币价值 1 分。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-guard": {
					name: "反抗军卫士",
					text: "打出区有另一名伙伴：抽 1 张牌",
					acquire: "+1 剑",
					arrive: "",
					react: ""
				},
				"evil-wizard": {
					name: "邪恶巫师",
					text: "战利品：每回合第一次打出秘密典籍时抽一张牌；第二次时制造 2 噪音并移除此战利品。",
					acquire: "",
					arrive: "",
					react: ""
				},
				candelabra: {
					name: "烛台",
					text: "已标记至少三处房间：+1 治疗",
					acquire: "",
					arrive: "",
					react: ""
				},
				"ten-foot-pole": {
					name: "十尺长杆",
					text: "抽 1 张牌；本回合探索时可重新抽取一次板块",
					acquire: "",
					arrive: "",
					react: ""
				},
				tinkerer: {
					name: "工匠",
					text: "本回合使用装置少付 2 技能",
					acquire: "",
					arrive: "",
					react: ""
				},
				"underworld-guide": {
					name: "冥界向导",
					text: "位于冥界时，抽一张牌。移除此牌时，抽一张牌。",
					acquire: "+1 冥币",
					arrive: "",
					react: ""
				},
				"moneychangers-booth": {
					name: "兑换摊",
					text: "+2 冥币",
					acquire: "",
					arrive: "",
					react: ""
				},
				catapult: {
					name: "投石机",
					text: "+2 噪音；可传送到相邻房间",
					acquire: "",
					arrive: "",
					react: ""
				},
				"underground-spring": {
					name: "地下泉水",
					text: "+1 治疗；位于冥界：可移除打出区或弃牌堆的一张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"mystic-elevator": {
					name: "神秘升降梯",
					text: "+1 噪音；可传送到冥界市场",
					acquire: "",
					arrive: "",
					react: ""
				},
				"shifting-shadow": {
					name: "游移暗影",
					text: "本回合可逆向通过单向通道",
					acquire: "",
					arrive: "",
					react: ""
				},
				"harpy-matriarch": {
					name: "鹰身女妖主母",
					text: "只能在冥界击败。战利品：每件鹰身女妖战利品（含此牌）价值 1 分；此牌也计入后续鹰身女妖的冥币奖励。",
					acquire: "",
					arrive: "",
					react: ""
				},
				chimera: {
					name: "奇美拉",
					text: "获得一个大秘密；+1 噪音",
					acquire: "",
					arrive: "+1 噪音（所有玩家）",
					react: ""
				},
				cyclops: {
					name: "独眼巨人",
					text: "+1 开锁器；可移除打出区或弃牌堆的一张牌",
					acquire: "",
					arrive: "+1 噪音（所有玩家）",
					react: ""
				},
				"wild-boar": {
					name: "野猪",
					text: "+1 噪音；抽 2 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"abyssal-hydra": {
					name: "深渊九头蛇",
					text: "抽 2 张牌；获得九头蛇上的 2 冥币",
					acquire: "",
					arrive: "在九头蛇上放置冥币",
					react: ""
				},
				"grave-robber": {
					name: "盗墓者",
					text: "+1 冥币",
					acquire: "",
					arrive: "将所有有玩家的方形板块旋转 180°",
					react: ""
				},
				"gray-knight": {
					name: "灰骑士",
					text: "",
					acquire: "+1 冥币",
					arrive: "",
					react: ""
				},
				"underworld-dealer": {
					name: "冥界商贩",
					text: "选择一项：+1 冥币 / 花 3 金币，获得秘密典籍",
					acquire: "+1 冥币",
					arrive: "",
					react: ""
				},
				george: {
					name: "乔治",
					text: "+1 噪音；抽 1 张牌；持有猴神像：+1 技能；+1 剑；+1 噪音；抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				sculptor: {
					name: "雕塑家",
					text: "选择一项：可移除打出区的一张牌 / 抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				soothsayer: {
					name: "预言家",
					text: "持有命运牌：+1 技能",
					acquire: "",
					arrive: "每人可花 1 金币，治疗 1 点",
					react: ""
				},
				orpheus: {
					name: "俄耳甫斯",
					text: "制造 1 噪音，获得 1 冥币；每名已释放囚犯使此牌价值 1 分。",
					acquire: "释放一名囚犯",
					arrive: "将银行中至多 3 个黑色方块放回龙袋",
					react: ""
				},
				"hero-of-prophecy": {
					name: "预言勇者",
					text: "持有命运牌：可移除打出区或弃牌堆的一张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				oracle: {
					name: "神谕者",
					text: "选择一项：抽 1 张牌 / 花 1 冥币，抽两张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-tunnel-guide": {
					name: "反抗军隧道向导",
					text: "打出区有另一名伙伴：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-rouser": {
					name: "反抗军鼓动者",
					text: "打出区有另一名伙伴：抽 1 张牌；本回合制造至少 2 点噪音：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"spellblade-invoker": {
					name: "魔刃召唤师",
					text: "+1 噪音；可传送到相邻房间",
					acquire: "",
					arrive: "",
					react: ""
				},
				"apprentice-thief": {
					name: "学徒盗贼",
					text: "",
					acquire: "+1 开锁器",
					arrive: "",
					react: ""
				},
				"polished-garnet": {
					name: "抛光石榴石",
					text: "+1 冥币；抽 1 张牌",
					acquire: "+2 噪音",
					arrive: "",
					react: ""
				},
				garnet: {
					name: "石榴石",
					text: "+1 冥币；抽 1 张牌",
					acquire: "+2 噪音",
					arrive: "",
					react: ""
				},
				"fire-breath": {
					name: "吐息",
					text: "本回合制造至少 1 点噪音：抽 1 张牌",
					acquire: "+1 剑",
					arrive: "",
					react: ""
				},
				"escape-plan": {
					name: "逃生计划",
					text: "移除此牌时，获得两靴，本回合无需在水晶洞穴停步。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"tome-of-intellect": {
					name: "智慧秘典",
					text: "抽 2 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				"tome-of-the-ape-lords": {
					name: "猿王秘典",
					text: "持有猴神像：本回合视为秘密典籍",
					acquire: "+3 噪音",
					arrive: "",
					react: ""
				},
				"soul-prism": {
					name: "灵魂棱镜",
					text: "移除此牌时，释放一名囚犯。",
					acquire: "+1 治疗",
					arrive: "",
					react: ""
				},
				"ethereal-step": {
					name: "以太步",
					text: "本回合累计产生至少 6 点技能：可传送到相邻房间",
					acquire: "",
					arrive: "",
					react: ""
				},
				thunderstriker: {
					name: "雷霆剑",
					text: "抽一张牌。每件鹰身女妖战利品使此牌价值 1 分。",
					acquire: "",
					arrive: "",
					react: ""
				},
				slink: {
					name: "潜行",
					text: "-2 噪音；抽 1 张牌",
					acquire: "+1 靴；-2 噪音",
					arrive: "",
					react: ""
				},
				"acid-splash": {
					name: "酸液飞溅",
					text: "展示牌库顶牌（必要时洗牌），选择将其移除，或弃掉它并获得 2 剑",
					acquire: "",
					arrive: "",
					react: ""
				},
				"quick-trip": {
					name: "短途旅行",
					text: "持有价值不超过 10 分的神器：本回合无需在水晶洞穴停步",
					acquire: "+1 靴；+2 噪音",
					arrive: "",
					react: ""
				},
				"burial-urn": {
					name: "骨灰瓮",
					text: "移除此牌时，获得 4 冥币。",
					acquire: "",
					arrive: "",
					react: ""
				},
				"wealth-of-knowledge": {
					name: "知识宝藏",
					text: "",
					acquire: "",
					arrive: "+1 冥币（所有玩家）",
					react: ""
				},
				lantern: {
					name: "提灯",
					text: "+1 冥币",
					acquire: "",
					arrive: "",
					react: ""
				},
				"utility-knife": {
					name: "多用刀",
					text: "抽 1 张牌",
					acquire: "+1 冥币",
					arrive: "",
					react: ""
				},
				"big-ideas": {
					name: "奇思妙想",
					text: "+1 噪音；本回合累计产生至少 6 点技能：+1 冥币",
					acquire: "",
					arrive: "",
					react: ""
				},
				burgle: {
					name: "行窃",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				stumble: {
					name: "踉跄",
					text: "+1 噪音",
					acquire: "",
					arrive: "",
					react: ""
				},
				sidestep: {
					name: "侧步",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				scramble: {
					name: "疾行",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				explore: {
					name: "探索",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				mercenary: {
					name: "佣兵",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				tome: {
					name: "秘密典籍",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				psyfoot: {
					name: "猫步",
					text: "本回合忽略通道怪物",
					acquire: "",
					arrive: "",
					react: ""
				},
				cattitude: {
					name: "猫脾气",
					text: "翻转一枚行为标记，获得对应资源",
					acquire: "",
					arrive: "",
					react: ""
				},
				saunter: {
					name: "漫步",
					text: "翻转行为标记；有神器时奖励翻倍",
					acquire: "",
					arrive: "",
					react: ""
				},
				ransack: {
					name: "洗劫",
					text: "",
					acquire: "",
					arrive: "",
					react: "对手击败怪物"
				},
				scavenge: {
					name: "捡拾",
					text: "本回合每击败一只通道怪物，获得 1 金币",
					acquire: "",
					arrive: "",
					react: ""
				},
				wallop: {
					name: "重击",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				primacy: {
					name: "猿王威仪",
					text: "持有猴神像：本回合无需在水晶洞穴停步",
					acquire: "",
					arrive: "",
					react: ""
				},
				persist: {
					name: "坚持",
					text: "+1 治疗；+1 噪音",
					acquire: "",
					arrive: "",
					react: ""
				},
				bolt: {
					name: "飞奔",
					text: "持有神器：+2 金币；+1 噪音",
					acquire: "",
					arrive: "",
					react: ""
				},
				collection: {
					name: "收藏",
					text: "+1 金币；每种已收集的珍品提供 1 金币",
					acquire: "",
					arrive: "",
					react: "对手先获得一种你尚无的珍品"
				},
				competition: {
					name: "竞赛",
					text: "选择一种已收集珍品的奖励",
					acquire: "",
					arrive: "",
					react: "对手先获得一种你尚无的珍品"
				},
				exhibit: {
					name: "展览",
					text: "选择一种已收集珍品的奖励",
					acquire: "",
					arrive: "",
					react: "对手先获得一种你尚无的珍品"
				},
				"rebel-squire": {
					name: "反抗军侍从",
					text: "打出区有另一名伙伴：抽 1 张牌",
					acquire: "",
					arrive: "",
					react: ""
				},
				inspire: {
					name: "鼓舞",
					text: "回合结束时可把打出的伙伴放到牌库顶",
					acquire: "",
					arrive: "",
					react: ""
				},
				"defensive-position": {
					name: "防御阵地",
					text: "位于水晶洞穴：+2 剑",
					acquire: "",
					arrive: "",
					react: ""
				},
				channel: {
					name: "引导法力",
					text: "+1 法力；本回合获得秘密或使用药水可增加法力",
					acquire: "",
					arrive: "",
					react: ""
				},
				study: {
					name: "研习",
					text: "+1 法力；本回合每打出一本秘密典籍，获得 1 法力",
					acquire: "",
					arrive: "",
					react: ""
				},
				"mystic-slide": {
					name: "神秘滑步",
					text: "可传送到相邻房间",
					acquire: "",
					arrive: "",
					react: ""
				}
			},
			rules: "在不断扩展的地下墓穴中构筑牌库、寻找神器，再返回墓穴出口。所有玩家逃出或昏迷后，得分最高者获胜；平分时比较最贵神器的价值。\n\n你的回合:\n自由安排打牌、移动、购牌、使用装置、战斗、开锁和购买市场物品。蓝色技能用于购牌与装置，剑用于战斗，靴用于移动。获得的牌通常进入弃牌堆，怪物和装置的文字立即执行。回合结束前须打完手牌，未花费的资源不会保留。清理打出区，抽五张牌，再补齐六张地下城牌。\n\n地图与探索:\n每次移动到下一间房通常花一靴。通道上的额外脚印、锁、怪物和冥币另行支付；可用剑抵消怪物伤害。自愿承受的伤害不能使你昏迷，且必须有个人方块标记。锁一旦打开，所有人都可通过。进入水晶洞穴或跌入陷坑后，本回合不能继续花靴，传送仍然可用。\n沿地图边缘的通道探索时，先揭示新板块，再选择朝向并完成原移动。可以中断移动打牌或获得资源。传送忽略通道图标和单向箭头，仍然触发房间效果。传送门连接其他传送门，完整的一次移动仍须支付两端通道的图标。\n\n宝藏与房间:\n每回合首次进入一间房可获得该房间奖励；下回合须重新进入才可再获奖励。开锁器还可打开宝箱、图书室或监牢，分别获得大秘密、秘密典籍或释放囚犯。每处神龛每人只能标记一次，放置个人方块并获得等同已标神龛数的金币。一个背包增加一件神器容量。拿取神器会增加巨龙怒气。\n\n龙袭与逃生:\n补入的新牌带龙袭图标时，巨龙袭击一次。把全部噪音方块放入龙袋，再按怒气及危险图标抽取方块。黑色方块移至银行，玩家色方块造成对应玩家伤害；每个白色幽灵方块使仍在探险的所有玩家受伤，随后回到噪音区。\n携带神器返回墓穴出口后，可完成本回合，再退出并获得 20 分逃脱奖励。昏迷时没有神器，或身处深处或冥界，通常得零分；安全区中携带神器昏迷仍可计分。计分包括神器、金币、卡牌、秘密、囚犯、市场物品和其他奖励。已离场玩家的席次改为固定四方块龙袭，两人局为六方块，没有倒计时。牌库不足以补齐牌列或袭击结束时龙袋为空，所有在场玩家立刻昏迷并结算。\n\n可选扩展:\n巢穴与失落密室加入陷坑、魔法屏障、特殊神龛和房间怪物。战利品放在个人供应区，提供持续能力或分数。冥界为独立地图，通过梯子或单向滑道进入；回合从冥界开始时支付一枚冥币，无法支付则制造两点噪音。冥界有专用市场、命运牌、鹰身女妖、神器增强器和小恶魔助手。\n冒险派对加入可选反应：对手满足条件时，可把对应手牌置于反应区并补抽一张，直到自己的下一回合才执行该牌。六角色各有不同的起始牌和能力。五至六人局使用额外神器、补给和隐形斗篷；同一玩家不得从同一房间拿取第二件神器。三个扩展可以独立开关。",
			fates: {
				fool: "持有至少两张踉跄时，价值 10 分。",
				magician: "价值 3 分。此牌视为秘密典籍。",
				"high-priestess": "价值 3 分。在之后的一个回合中展示，此回合无需在水晶洞穴停步。",
				empress: "持有王冠时，价值 6 分。",
				emperor: "同时持有神器增强器、王冠和猴神像时，价值 12 分。",
				hierophant: "价值 2 分。在之后的一个回合中展示，可传送到相邻房间。",
				lovers: "价值 2 分。拿取后立即展示，治疗 2 点。",
				chariot: "价值 −3 分。拿取后立即展示；此后每回合获得一靴。",
				strength: "持有 1 / 2 / 至少 3 件鹰身女妖战利品时，价值 3 / 5 / 8 分。",
				hermit: "持有猴神像时，价值 6 分。",
				wheel: "持有至少 10 金币（含冥币）时，价值 10 分。",
				justice: "可展示此牌，使神器容量永久增加一件。",
				"hanged-man": "价值 5 分。拿取后立即展示，将一个幽灵方块放入噪音区。",
				death: "通常价值 1 分；若携带神器在深处昏迷，仍可计分，但此牌价值 −5 分。不能在冥界救你。",
				temperance: "价值 4 分。",
				imp: "持有 1 / 2 / 至少 3 张宝石时，价值 4 / 8 / 12 分。",
				tower: "价值 3 分。位于高塔时可展示，获得 3 金币。",
				star: "价值 3 分。一次龙袭中可展示，避免本次抽出的所有自己颜色方块的伤害，并将这些方块收回供应区。",
				moon: "持有至少两件冥界市场物品时，价值 8 分。",
				sun: "获得逃脱奖励时，额外价值 10 分。",
				judgement: "价值 5 分。拿取后立即展示，引发一次龙袭。",
				world: "持有至少三件市场物品时，价值 7 分。"
			},
			characters: {
				adventurer: "标准起始牌库。",
				agnet: "获得伙伴时，可花征召标记将其放到牌库顶；共四枚。",
				dallan: "珍品包括龙蛋、猴神像、王冠和神器，起始牌会根据已收集的珍品提供奖励。",
				garignar: "每回合首次击败怪物牌（含哥布林），推进屠戮进度并获得奖励。",
				lenara: "积攒最多 10 法力。每回合可各施放一次：3 法力弃一抽一、5 法力复制打出区的一张牌、7 法力免费获得牌列卡并放入手牌。",
				monkeybot: "每次龙袭受到伤害，揭示最左一枚齿轮；此后每回合获得所有已揭示奖励，依次为剑、靴、技能、剑、靴、技能、剑。",
				whiskers: "翻转行为标记可获得技能、剑或靴。回合结束时若三枚均已翻转，固定抽四方块龙袭，自己的方块不造成伤害并收回供应区，然后重置行为。"
			}
		},
		en: {
			name: "Clank! Catacombs",
			desc: "Explore a changing dungeon, build your deck, steal an artifact, and escape the dragon.",
			invalid: "That action is not available.",
			ui: {
				confirmAcquire: "Acquire {{card}} · {{n}} Skill",
				confirmDefeat: "Defeat {{card}} · {{n}} Swords",
				confirmDevice: "Use {{card}} · {{n}} Skill",
				bubbleArtifact: "Artifacts",
				bubbleIdol: "Idols",
				bubbleTrophy: "Trophies",
				bubbleItem: "Market items",
				bubbleFate: "Fate cards",
				bubbleGhost: "Ghosts in Clank! area",
				bubbleTile: "Explored tiles",
				bubbleRotate: "Rotated {{n}} tile(s)",
				bubbleTop: "Put {{n}} card(s) on deck",
				bubbleReplace: "Removed {{n}} dungeon card(s)",
				bubbleMirror: "Swapped deck and discard pile",
				bubbleReveal: "Revealed {{card}}",
				bubbleIgnoreMonsters: "Ignore tunnel monsters",
				bubbleReroll: "May redraw an explored tile",
				bubbleRerollArtifact: "May redraw a tile without artifacts",
				bubbleDeviceDiscount: "Devices cost 2 less skill",
				bubbleMarketDiscount: "Market items cost 2 less gold",
				bubbleCountsTome: "Counts as playing a tome",
				bubbleReverse: "May reverse one-way tunnels",
				bubbleInspire: "May put a companion on deck at turn end",
				bubbleAcquire: "Acquired {{card}}",
				bubbleDefeat: "Defeated {{card}}",
				bubbleDevice: "Used {{card}}",
				bubbleArrive: "Arrived: {{card}}",
				bubbleDraw: "Drew {{n}} card(s)",
				bubbleDiscard: "Discarded {{n}} card(s)",
				bubbleTrash: "Trashed {{card}}",
				bubbleTeleport: "Teleported",
				bubblePrisoner: "Freed {{n}} prisoner(s)",
				bubbleSecret: "Gained {{n}} secret(s)",
				bubbleIgnoreCave: "Ignore cave stops",
				bubbleMarket: "May shop in any room",
				bubbleMana: "Mana",
				bubbleHealth: "Health",
				bubbleOtherPlayers: "{{n}} other players",
				bubbleSource: "{{name}} · {{card}}",
				turn: "Turn {{n}}",
				yourTurn: "Your turn",
				waiting: "Waiting for {{name}}",
				resolving: "Resolving",
				dragon: "Dragon attack",
				choose: "Choose an option",
				hand: "Hand",
				dungeon: "Dungeon row",
				actions: "Actions",
				freedPrisoners: "Freed prisoners ({{n}})",
				noPrisoners: "None yet",
				supplies: "Reserve and market",
				players: "Adventurers",
				log: "History",
				close: "Close",
				details: "Details",
				catacombs: "Catacombs",
				basicCard: "Starter",
				reserveCard: "Reserve",
				actionCard: "Action",
				companion: "Companion",
				gem: "Gem",
				monster: "Monster",
				device: "Device",
				danger: "Danger",
				playedCards: "Played cards",
				deck: "Deck",
				dragonRage: "Dragon rage",
				room: "Room {{n}}",
				unknown: "Unexplored",
				viewMap: "Full map",
				locate: "Find my pawn",
				rotate: "Rotate {{n}}°",
				confirm: "Confirm",
				cancel: "Cancel",
				end: "End turn",
				play: "Play {{card}}",
				row: "{{card}} · Spend {{n}} {{resource}}",
				reserve: "Acquire {{card}} · {{n}} Skill",
				move: "Move to {{room}} · {{swords}} Swords",
				artifact: "Take an artifact",
				unlock: "Pick the lock: {{item}}",
				mark: "Mark: {{item}}",
				market: "Buy {{item}} · {{n}} Gold",
				fight: "Defeat {{item}} · {{resource}}",
				use: "Use {{item}}",
				react: "React: {{card}}",
				pass: "Pass",
				chooseTarget: "{{option}}: {{target}}",
				noAction: "No actions available",
				skill: "Skill",
				swords: "Swords",
				boots: "Boots",
				gold: "Gold",
				silver: "Undercoins",
				picks: "Lockpicks",
				noise: "Clank!",
				health: "Health {{n}} / 10",
				deckCount: "Deck {{n}}",
				artifactCount: "Artifacts: {{n}}",
				rage: "Rage {{n}}",
				tiles: "Tiles left {{n}}",
				bag: "Dragon bag {{n}}",
				turnResources: "Turn resources",
				playArea: "Play area",
				discard: "Discard pile",
				fates: "Fate cards",
				chooseCharacter: "Choose a character",
				orient: "Choose the new tile’s orientation",
				movement: "Choose a destination",
				secretCount: "Secrets {{n}}",
				safe: "Safe",
				depths: "Depths",
				underworld: "Underworld",
				active: "Exploring",
				escaped: "Escaped",
				knocked: "Knocked out",
				score: "Score {{n}}",
				eligible: "Eligible",
				ineligible: "No recovered artifact",
				expansions: "Expansions",
				lairs: "Lairs & Lost Chambers",
				underworldOption: "Underworld",
				party: "Adventuring Party",
				characters: "Use unique characters",
				startingTile: "Starting tile",
				front: "Front",
				back: "Back",
				underworldTile: "Underworld starting tile",
				points: "{{n}} points",
				acquireEffect: "Acquire: {{text}}",
				arriveEffect: "Arrive: {{text}}",
				reactEffect: "React: {{text}}",
				moveCost: "{{boots}} Boots · {{swords}} Swords · {{damage}} damage · {{picks}} Lockpicks · {{silver}} Undercoins",
				payment: "Payment: {{item}}",
				spell: "Cast {{item}}",
				scoreArtifacts: "Artifacts",
				scoreCards: "Cards",
				scoreTokens: "Secrets and prisoners",
				scoreMarket: "Market items",
				scoreTrophies: "Trophies",
				scoreFate: "Fate",
				scoreMastery: "Mastery",
				empty: "None",
				chooseRoute: "Choose a route",
				underworldSlot: "Underworld tile {{letter}}",
				mana: "Mana {{n}}",
				cogs: "Revealed cogs {{n}} / 7",
				conscription: "Conscription {{n}}",
				carnage: "Carnage {{n}} / 5",
				behavior: "Flipped behaviors: {{items}}",
				ladder: "Ladder to Underworld {{letter}}",
				placeTarget: "Open space {{n}}",
				fateHelp: "{{name}}: {{text}}",
				"log-play": "Played {{item}}",
				"log-react": "Reacted with {{item}}",
				"log-acquire": "Acquired {{item}}",
				"log-device": "Used {{item}}",
				"log-defeat": "Defeated {{item}}",
				"log-trash": "Trashed {{item}}",
				"log-move": "Entered {{item}}",
				"log-artifact": "Took a {{n}}-point artifact",
				"log-secret": "Found {{item}}",
				"log-prisoner": "Freed {{item}}",
				"log-market": "Bought {{item}}",
				"log-dragon": "Dragon attack: draw {{n}} cubes",
				"log-damage": "Took {{n}} damage",
				"log-escape": "Escaped with an artifact",
				"log-knockout": "Knocked out",
				"log-discover": "Discovered {{item}}",
				"log-reveal": "Revealed {{item}}",
				"log-fate": "Revealed {{item}}"
			},
			names: {
				adventurer: "Adventurer",
				agnet: "Agnet",
				dallan: "D’allan",
				garignar: "Garignar",
				lenara: "Lenara",
				monkeybot: "MonkeyBot Prime",
				whiskers: "Whiskers",
				backpack: "Backpack",
				amulet: "Blood Amulet",
				"amulet-uw": "Blood Amulet",
				kit: "Burglar’s Kit",
				crown: "Crown",
				cloak: "Invisibility Cloak",
				"river-lamp": "River Lamp",
				"wind-boots": "Boots of the Wind",
				gauntlets: "Gauntlets of Destiny",
				"jester-cap": "Jester’s Cap",
				riverboat: "Riverboat",
				crypt: "Crypt",
				cave: "Crystal Cave",
				minor: "Minor secret",
				major: "Major secret",
				chest: "Chest",
				library: "Library",
				prison: "Prison",
				prison3: "Prison",
				wayshrine: "Wayshrine",
				aegis: "Aegis Shrine",
				altar: "Altar of the Haunted",
				bazaar: "Bizarre Bazaar",
				temple: "Temple of Gold",
				hoard: "Umbrok Vessna’s Hoard",
				medusa: "Medusa",
				sphinx: "Sphinx",
				statue: "Living Statue",
				guardian: "Underworld Guardian",
				harpy: "Harpy",
				fate: "Fate Room",
				lyre: "Magic Lyre",
				imp: "Imp Assistant",
				market: "Market",
				pit: "Pit Trap",
				lake: "Underground Lake",
				tower: "Tower",
				idol: "Monkey Idol",
				chute: "Chute",
				egg: "Dragon Egg",
				pick: "Lockpick",
				spring: "Magic Spring",
				heal1: "Potion of Healing",
				heal2: "Greater Healing Potion",
				boots: "Potion of Swiftness",
				swords: "Potion of Strength",
				puzzlebox: "Puzzle Box",
				gold2: "Two Gold",
				gold5: "Five Gold",
				skill5: "Five Skill",
				map: "Catacombs Map",
				chalice: "Chalice",
				"book-dead": "Book of the Dead",
				"greater-hope": "Greater Potion of Hope",
				silver4: "Four Undercoins",
				"dark-iron": "Dark Iron",
				hope: "Potion of Hope",
				stealth: "Potion of Stealth",
				coupon: "Discount Coupon",
				"soul-elixir": "Soul Elixir",
				barbarian: "Barbarian",
				primatologist: "Primatologist",
				sorceress: "Sorceress",
				cleric: "Cleric",
				haunted: "Haunted Prisoner",
				warrior: "Warrior",
				prince: "Prince",
				princess: "Princess",
				monk: "Monk",
				peasant: "Peasant",
				mayor: "Mayor",
				faithful: "Faithful",
				myrmidon: "Haunted Myrmidon",
				goblin: "Goblin",
				transfigure: "Transfigure",
				duplicate: "Duplicate",
				levitate: "Levitate",
				"fate-fool": "Fool",
				"fate-magician": "Magician",
				"fate-high-priestess": "High Priestess",
				"fate-empress": "Empress",
				"fate-emperor": "Emperor",
				"fate-hierophant": "Hierophant",
				"fate-lovers": "Lovers",
				"fate-chariot": "Chariot",
				"fate-strength": "Strength",
				"fate-hermit": "Hermit",
				"fate-wheel": "Wheel",
				"fate-justice": "Justice",
				"fate-hanged-man": "Hanged Man",
				"fate-death": "Death",
				"fate-temperance": "Temperance",
				"fate-imp": "Imp",
				"fate-tower": "Tower",
				"fate-star": "Star",
				"fate-moon": "Moon",
				"fate-sun": "Sun",
				"fate-judgement": "Judgement",
				"fate-world": "World",
				"option-skip": "Skip",
				"option-teleport": "Teleport",
				"option-swap": "Swap positions",
				"option-quiet": "Quiet",
				"option-loud": "More Gold and Clank!",
				"option-gold": "Take Gold",
				"option-caves": "Ignore Crystal Caves",
				"option-pick": "Take a Lockpick",
				"option-steal": "Steal",
				"option-draw": "Draw",
				"option-trash": "Trash a card",
				"option-discard": "Discard",
				"option-trophy": "Trophy",
				"option-boot": "Take a Boot",
				"option-boots": "Take a Boot",
				"option-heal": "Heal",
				"option-minor": "Minor secret",
				"option-market": "Market item",
				"option-top": "Place on deck",
				"option-replace": "Remove from row",
				"option-mark": "Mark a Wayshrine",
				"option-return": "Return an artifact",
				"option-artifact": "Take an artifact",
				"option-rotate": "Rotate tile",
				"option-place": "Place a tile",
				"option-fall": "Fall in",
				"option-fight": "Fight",
				"option-damage": "Take damage",
				"option-fate": "Choose fate",
				"option-reveal": "Reveal fate",
				"option-aegis": "Use Aegis Shrine",
				"option-acquire": "Acquire a card",
				"option-skill": "Take Skill",
				"option-swords": "Take Swords",
				"option-copy": "Copy a card",
				"option-silver": "Spend an Undercoin",
				"option-tome": "Take a Secret Tome",
				"option-egg": "Egg: reduce Clank!",
				"option-idol": "Idol: trash a Burgle",
				"option-crown": "Crown: ignore caves",
				"free-prisoner": "Free a prisoner"
			},
			cards: {
				"skeleton-priest": {
					name: "Skeleton Priest",
					text: "+1 Healing; +1 Clank!",
					acquire: "",
					arrive: "+1 Clank! (all players)",
					react: ""
				},
				"darkened-alcove": {
					name: "Darkened Alcove",
					text: "-2 Clank!",
					acquire: "",
					arrive: "",
					react: ""
				},
				"lie-in-wait": {
					name: "Lie in Wait",
					text: "Be in a Crystal Cave：-2 Clank!",
					acquire: "You may put this card on top of your deck",
					arrive: "",
					react: ""
				},
				"smash-and-grab": {
					name: "Smash and Grab",
					text: "+2 Clank!; Draw 2 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				bard: {
					name: "Bard",
					text: "+1 Clank!; Make at least 2 Clank! this turn：+2 Healing",
					acquire: "",
					arrive: "",
					react: ""
				},
				"expert-guide": {
					name: "Expert Guide",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				skeleton: {
					name: "Skeleton",
					text: "+2 Gold; +1 Clank!",
					acquire: "",
					arrive: "",
					react: ""
				},
				robbery: {
					name: "Robbery",
					text: "+2 Gold; Be in a Market：You may teleport to an adjacent room",
					acquire: "You may put this card on top of your deck",
					arrive: "",
					react: ""
				},
				swindle: {
					name: "Swindle",
					text: "+3 Gold",
					acquire: "",
					arrive: "",
					react: ""
				},
				arcoverlord: {
					name: "Arcoverlord",
					text: "Draw 2 card(s); +1 Clank! (other players)",
					acquire: "",
					arrive: "+1 Clank! (all players)",
					react: ""
				},
				pillage: {
					name: "Pillage",
					text: "Gain at least 3 Gold this turn：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				scavenger: {
					name: "Scavenger",
					text: "",
					acquire: "Take a minor secret",
					arrive: "",
					react: ""
				},
				lightstick: {
					name: "Lightstick",
					text: "+1 Clank!",
					acquire: "",
					arrive: "",
					react: ""
				},
				"sneak-attack": {
					name: "Sneak Attack",
					text: "-2 Clank!",
					acquire: "+1 Swords",
					arrive: "",
					react: ""
				},
				"white-tourmaline": {
					name: "White Tourmaline",
					text: "Draw 1 card(s)",
					acquire: "+2 Clank!",
					arrive: "",
					react: ""
				},
				"black-tourmaline": {
					name: "Black Tourmaline",
					text: "Draw 1 card(s)",
					acquire: "+2 Clank!",
					arrive: "",
					react: ""
				},
				flamboyance: {
					name: "Flamboyance",
					text: "Draw 1 card(s); Make at least 2 Clank! this turn：+2 Skill",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-scribe": {
					name: "Rebel Scribe",
					text: "Have another companion in your play area：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				bandit: {
					name: "Bandit",
					text: "",
					acquire: "+1 Boots; +1 Swords",
					arrive: "",
					react: ""
				},
				"underground-river": {
					name: "Underground River",
					text: "Choose one: +1 Healing / +1 Boots",
					acquire: "",
					arrive: "",
					react: ""
				},
				"spectral-rider": {
					name: "Spectral Rider",
					text: "Be on a haunted tile：You may teleport to any room on a different tile",
					acquire: "",
					arrive: "",
					react: ""
				},
				librarian: {
					name: "Librarian",
					text: "-2 Clank!; Have a Secret Tome in your play area or discard pile：Draw 2 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-general": {
					name: "Rebel General",
					text: "Have another companion in your play area：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-paladin": {
					name: "Rebel Paladin",
					text: "Have another companion in your play area：Draw 1 card(s); Have an artifact：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-thief": {
					name: "Rebel Thief",
					text: "+1 Lockpicks; Have another companion in your play area：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"imp-familiar": {
					name: "Imp Familiar",
					text: "Choose one: +1 Lockpicks / Spend a Lockpick to draw two cards",
					acquire: "",
					arrive: "",
					react: ""
				},
				"floating-skull": {
					name: "Floating Skull",
					text: "Have a Crown：You may teleport to an adjacent room",
					acquire: "You may teleport to an adjacent room",
					arrive: "",
					react: ""
				},
				charlatan: {
					name: "Charlatan",
					text: "Discard a card, then draw two cards",
					acquire: "",
					arrive: "",
					react: ""
				},
				empurror: {
					name: "Empurror",
					text: "Choose one: -2 Clank! / +1 Gold / You need not stop in Crystal Caves this turn; Have an artifact：If you have an artifact, gain all three rewards",
					acquire: "",
					arrive: "",
					react: ""
				},
				curator: {
					name: "Curator",
					text: "Draw a card for each artifact you have",
					acquire: "",
					arrive: "",
					react: ""
				},
				"corrupt-advisor": {
					name: "Corrupt Advisor",
					text: "+1 Clank! (other players); Have a Crown：+1 Clank! (other players)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rose-quartz": {
					name: "Rose Quartz",
					text: "-2 Clank!; Draw 1 card(s)",
					acquire: "+2 Clank!",
					arrive: "",
					react: ""
				},
				"smoky-quartz": {
					name: "Smoky Quartz",
					text: "-2 Clank!; Draw 1 card(s)",
					acquire: "+2 Clank!",
					arrive: "",
					react: ""
				},
				"fiery-quartz": {
					name: "Fiery Quartz",
					text: "-2 Clank!; Draw 1 card(s)",
					acquire: "+2 Clank!",
					arrive: "",
					react: ""
				},
				waystone: {
					name: "Waystone",
					text: "In a Wayshrine, you may trash this to teleport to another Wayshrine",
					acquire: "",
					arrive: "",
					react: ""
				},
				"brave-hero": {
					name: "Brave Hero",
					text: "Worth 5 points if you have freed at least three prisoners.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"remove-traps": {
					name: "Remove Traps",
					text: "Replace a card in the row; ignore its replacement’s dragon icon",
					acquire: "",
					arrive: "",
					react: ""
				},
				"sudden-movement": {
					name: "Sudden Movement",
					text: "",
					acquire: "",
					arrive: "Each player alone on a square tile must rotate it",
					react: ""
				},
				souldrinker: {
					name: "Souldrinker",
					text: "Defeat a monster from the row this turn：+1 Healing",
					acquire: "",
					arrive: "",
					react: ""
				},
				"shadow-walk": {
					name: "Shadow Walk",
					text: "You may trash a Burgle in your play area or discard pile",
					acquire: "",
					arrive: "",
					react: ""
				},
				"thirst-for-adventure": {
					name: "Thirst for Adventure",
					text: "Worth 2 points per artifact and Monkey Idol.",
					acquire: "+3 Boots",
					arrive: "",
					react: ""
				},
				riot: {
					name: "Riot",
					text: "+1 Clank!; Have freed at least three prisoners：You may trash a card in your play area or discard pile",
					acquire: "Free a prisoner",
					arrive: "",
					react: ""
				},
				"astral-projection": {
					name: "Astral Projection",
					text: "Generate at least 6 Skill this turn：You may mark any Wayshrine as though you were there",
					acquire: "",
					arrive: "",
					react: ""
				},
				diversion: {
					name: "Diversion",
					text: "",
					acquire: "Free a prisoner",
					arrive: "Return up to 3 black cubes from the Bank to the bag",
					react: ""
				},
				"elven-sword": {
					name: "Elven Sword",
					text: "Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				payoff: {
					name: "Payoff",
					text: "Trash this card",
					acquire: "",
					arrive: "",
					react: ""
				},
				"double-cross": {
					name: "Double Cross",
					text: "-2 Clank!",
					acquire: "+2 Clank! (other players)",
					arrive: "",
					react: ""
				},
				"blink-spell": {
					name: "Blink Spell",
					text: "Choose one: You may teleport to an adjacent room / You may swap places with another player in the Depths",
					acquire: "",
					arrive: "",
					react: ""
				},
				lute: {
					name: "Lute",
					text: "+1 Clank!; Draw 2 card(s); Gain 1 Gold for each Clank! you make this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				"divining-rod": {
					name: "Divining Rod",
					text: "Generate at least 6 Skill this turn：+1 Healing",
					acquire: "",
					arrive: "",
					react: ""
				},
				"expensive-taste": {
					name: "Expensive Taste",
					text: "Gain 2 Gold. Worth 5 points if you have a Crown and a Gem.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"golden-flute": {
					name: "Golden Flute",
					text: "+1 Gold; +1 Clank!; You may buy one market item this turn for 5 Gold from anywhere",
					acquire: "",
					arrive: "",
					react: ""
				},
				"grand-theft": {
					name: "Grand Theft",
					text: "Choose one: +1 Lockpicks / Spend a Lockpick to use a device or acquire a card from the row for free",
					acquire: "You may put this card on top of your deck",
					arrive: "",
					react: ""
				},
				"boots-of-the-ape-lords": {
					name: "Boots of the Ape Lords",
					text: "+3 Clank!; Have a Monkey Idol：You need not stop in Crystal Caves this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				"crystal-compass": {
					name: "Crystal Compass",
					text: "Draw 2 card(s); You need not stop in Crystal Caves this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				"animated-wall": {
					name: "Animated Wall",
					text: "+1 Boots; Use a portal this turn：+1 Boots",
					acquire: "",
					arrive: "Rotate every occupied square tile 180 degrees",
					react: ""
				},
				"ogre-merchant": {
					name: "Ogre Merchant",
					text: "Choose one: +5 Gold / In a Market, you may take a market item for free",
					acquire: "",
					arrive: "",
					react: ""
				},
				keymaster: {
					name: "Keymaster",
					text: "+1 Lockpicks",
					acquire: "",
					arrive: "",
					react: ""
				},
				"thieves-shrine": {
					name: "Thieves' Shrine",
					text: "Choose one: +2 Gold / You may trash a Burgle in your play area or discard pile, You may trash a Burgle in your play area or discard pile",
					acquire: "",
					arrive: "Return up to 3 black cubes from the Bank to the bag",
					react: ""
				},
				"locked-trunk": {
					name: "Locked Trunk",
					text: "-1 Lockpicks; Spend a Lockpick; Take a major secret",
					acquire: "",
					arrive: "",
					react: ""
				},
				"wishing-well": {
					name: "Wishing Well",
					text: "Spend 3 Gold to draw two cards",
					acquire: "",
					arrive: "",
					react: ""
				},
				"skeletal-ape": {
					name: "Skeletal Ape",
					text: "+3 Skill; +3 Gold; +3 Clank!",
					acquire: "",
					arrive: "",
					react: ""
				},
				"the-warden": {
					name: "The Warden",
					text: "Free a prisoner; Free a prisoner",
					acquire: "",
					arrive: "",
					react: ""
				},
				"black-market": {
					name: "Black Market",
					text: "Choose two different rewards: 2 Gold, trash a card, take a Lockpick",
					acquire: "",
					arrive: "",
					react: ""
				},
				"crystal-kobold": {
					name: "Crystal Kobold",
					text: "+2 Skill",
					acquire: "",
					arrive: "",
					react: ""
				},
				"skeleton-warlock": {
					name: "Skeleton Warlock",
					text: "Take a Secret Tome; +1 Clank!",
					acquire: "",
					arrive: "",
					react: ""
				},
				"marble-guardian": {
					name: "Marble Guardian",
					text: "Place a tile next to yours; teleport onto it or take 2 Gold",
					acquire: "",
					arrive: "",
					react: ""
				},
				skulker: {
					name: "Skulker",
					text: "Ignore tunnel monsters this turn",
					acquire: "Ignore tunnel monsters this turn",
					arrive: "",
					react: ""
				},
				scuffler: {
					name: "Scuffler",
					text: "Each opponent chooses -2 Clank!, 2 Gold, or trash a Burgle from their discard pile. You get all three",
					acquire: "",
					arrive: "",
					react: ""
				},
				"royal-brat": {
					name: "Royal Brat",
					text: "Have a Crown：Take a minor secret",
					acquire: "",
					arrive: "",
					react: "An opponent takes a major secret or two secrets in one turn"
				},
				"elven-satchel": {
					name: "Elven Satchel",
					text: "+2 Gold; Draw 1 card(s)",
					acquire: "",
					arrive: "Each player chooses 1 Gold, or 1 Clank! and draw a card",
					react: ""
				},
				"flawed-emerald": {
					name: "Flawed Emerald",
					text: "Draw 1 card(s)",
					acquire: "+2 Clank!; +1 Clank! (other players)",
					arrive: "",
					react: ""
				},
				assassin: {
					name: "Assassin",
					text: "-2 Clank!",
					acquire: "",
					arrive: "",
					react: "A monster arrives in the Dungeon Row"
				},
				"spiritual-healer": {
					name: "Spiritual Healer",
					text: "Have a Gem in your play area or discard pile：+1 Healing; +1 Clank!",
					acquire: "",
					arrive: "Each player may make 2 Clank! to heal 1",
					react: ""
				},
				"walk-it-off": {
					name: "Walk It Off",
					text: "",
					acquire: "+1 Healing",
					arrive: "",
					react: "You take damage in a Dragon Attack"
				},
				"flawed-sapphire": {
					name: "Flawed Sapphire",
					text: "Draw 1 card(s)",
					acquire: "+2 Clank!; +1 Clank! (other players)",
					arrive: "",
					react: ""
				},
				berserker: {
					name: "Berserker",
					text: "Gain 1 Sword for each Clank! you make this turn",
					acquire: "",
					arrive: "",
					react: "An opponent defeats the Goblin"
				},
				"scouting-ahead": {
					name: "Scouting Ahead",
					text: "You need not stop in Crystal Caves this turn",
					acquire: "",
					arrive: "",
					react: "An opponent ends their turn in a Crystal Cave"
				},
				"one-with-everything": {
					name: "One With Everything",
					text: "+1 Gold",
					acquire: "",
					arrive: "",
					react: "An opponent uses a device"
				},
				"virtuoso-burglar": {
					name: "Virtuoso Burglar",
					text: "-2 Clank!; You may trash a Burgle in your play area or discard pile",
					acquire: "",
					arrive: "Each player may make 1 Clank! to trash a Burgle from hand or discard",
					react: ""
				},
				"hiding-place": {
					name: "Hiding Place",
					text: "+2 Swords",
					acquire: "",
					arrive: "Each player may discard a Burgle from hand for -2 Clank!",
					react: ""
				},
				"time-warp": {
					name: "Time Warp",
					text: "You may teleport to an adjacent room",
					acquire: "",
					arrive: "",
					react: "An opponent ends their turn without moving"
				},
				spotter: {
					name: "Spotter",
					text: "-2 Clank!; Each player may make 1 Clank! to gain 2 Gold",
					acquire: "",
					arrive: "",
					react: ""
				},
				cutpurse: {
					name: "Cutpurse",
					text: "Choose one: +1 Boots / +2 Gold; You may discard a card, then draw a card",
					acquire: "",
					arrive: "",
					react: "An opponent enters a Market room"
				},
				"secret-passage": {
					name: "Secret Passage",
					text: "-2 Clank!; +2 Boots",
					acquire: "",
					arrive: "Each player may spend 5 Gold to acquire a Secret Tome",
					react: ""
				},
				tactician: {
					name: "Tactician",
					text: "",
					acquire: "",
					arrive: "",
					react: "There are at least three empty spaces in the Dungeon Row"
				},
				"too-bad-for-you": {
					name: "Too Bad for You",
					text: "",
					acquire: "",
					arrive: "",
					react: "An opponent ends their turn with at least two of their cubes in the Clank! area"
				},
				"flawed-ruby": {
					name: "Flawed Ruby",
					text: "Draw 1 card(s)",
					acquire: "+2 Clank!; +1 Clank! (other players)",
					arrive: "",
					react: ""
				},
				"pixie-swarm": {
					name: "Pixie Swarm",
					text: "+1 Gold",
					acquire: "",
					arrive: "Each player may reveal a card with a Sword from hand to gain 1 Gold",
					react: ""
				},
				"ape-lord-phantasm": {
					name: "Ape Lord Phantasm",
					text: "Draw 2 card(s); You may return any number of Monkey Idols to a Monkey Shrine room to take one Secret Tome per idol",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-herald": {
					name: "Rebel Herald",
					text: "Have another companion in your play area：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: "There are at least two companions in the Dungeon Row"
				},
				leprechaun: {
					name: "Leprechaun",
					text: "Gain 7 Gold and make 4 Clank!",
					acquire: "",
					arrive: "Each player chooses 2 Gold and 1 Clank!, or 5 Gold and 3 Clank!",
					react: ""
				},
				succubus: {
					name: "Succubus",
					text: "+1 Healing; +3 Gold; Each opponent chooses 3 Gold or heal 1",
					acquire: "",
					arrive: "",
					react: ""
				},
				"magic-kazoo": {
					name: "Magic Kazoo",
					text: "Put 6 Gold on this trophy. At the start of each turn, make 2 Clank! and take 2 Gold from it",
					acquire: "",
					arrive: "",
					react: ""
				},
				"unlock-potential": {
					name: "Unlock Potential",
					text: "Choose one: Draw 1 card(s) / Trash a trophy to draw three cards",
					acquire: "",
					arrive: "",
					react: ""
				},
				"thirst-for-knowledge": {
					name: "Thirst for Knowledge",
					text: "Make 1 Clank! Worth 1 point per Secret Tome you have.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"tome-of-fire": {
					name: "Tome of Fire",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				jailer: {
					name: "Jailer",
					text: "+1 Lockpicks; Free a prisoner",
					acquire: "",
					arrive: "",
					react: ""
				},
				amethyst: {
					name: "Amethyst",
					text: "-2 Clank!; Draw 1 card(s)",
					acquire: "+2 Clank!",
					arrive: "",
					react: ""
				},
				swashbuckling: {
					name: "Swashbuckling",
					text: "Gain 1 Gold for each tunnel monster you fight this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				"loot-chute": {
					name: "Loot Chute",
					text: "+2 Gold; +2 Boots",
					acquire: "",
					arrive: "",
					react: ""
				},
				"heart-of-the-dark": {
					name: "Heart of the Dark",
					text: "Trophy: whenever you take a trophy, including this one, make −2 Clank! Worth −2 points.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"cave-bat-wings": {
					name: "Cave Bat Wings",
					text: "Trophy: ignore Crystal Caves while you have a Secret Tome in play or discard. Worth 4 points with Mastery.",
					acquire: "",
					arrive: "",
					react: ""
				},
				jailbreaker: {
					name: "Jailbreaker",
					text: "Free a prisoner this turn：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"pack-rat": {
					name: "Pack Rat",
					text: "Acquire a card costing up to 4 for free; put it in hand if you have a Backpack",
					acquire: "",
					arrive: "",
					react: ""
				},
				"false-bottom": {
					name: "False Bottom",
					text: "+1 Lockpicks; Be in a Pit Trap：+3 Gold",
					acquire: "",
					arrive: "",
					react: ""
				},
				acrobatics: {
					name: "Acrobatics",
					text: "If a Pit Trap makes you trash this from hand, acquire a card costing up to 4 for free and put it in your hand.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"skeleton-troubadour": {
					name: "Skeleton Troubadour",
					text: "Take a minor secret; +1 Clank!",
					acquire: "",
					arrive: "",
					react: ""
				},
				"pit-fiend": {
					name: "Pit Fiend",
					text: "+2 Gold; +1 Clank!; Be in a Pit Trap：Free a prisoner",
					acquire: "",
					arrive: "",
					react: ""
				},
				"silver-arch": {
					name: "Silver Arch",
					text: "You may teleport to another lair or lost chamber",
					acquire: "",
					arrive: "",
					react: ""
				},
				forage: {
					name: "Forage",
					text: "+1 Gold",
					acquire: "",
					arrive: "",
					react: ""
				},
				"swords-and-sorcery": {
					name: "Swords and Sorcery",
					text: "Draw 1 card(s); Generate at least 4 Swords this turn：You may teleport to an adjacent room",
					acquire: "",
					arrive: "You may return the lowest-value artifact from a room to the stack, excluding the Magic Lyre",
					react: ""
				},
				alarm: {
					name: "Alarm",
					text: "+1 Clank! (other players)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"mechanical-donkey": {
					name: "Mechanical Donkey",
					text: "Trophy: worth 2 points. If knocked out in the Depths, lose all your Gold but score your other points; this is then worth 8 points.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"artifact-detector": {
					name: "Artifact Detector",
					text: "You may redraw a discovered tile without an artifact",
					acquire: "",
					arrive: "You may return the lowest-value artifact from a room to the stack, excluding the Magic Lyre",
					react: ""
				},
				spelunker: {
					name: "Spelunker",
					text: "+1 Clank!",
					acquire: "",
					arrive: "",
					react: ""
				},
				negotiator: {
					name: "Negotiator",
					text: "Market items cost 2 less Gold this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				devotion: {
					name: "Devotion",
					text: "Worth 1 point for each of your cubes in the dungeon.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-messenger": {
					name: "Rebel Messenger",
					text: "Have another companion in your play area：Draw 1 card(s)",
					acquire: "+1 Boots",
					arrive: "",
					react: ""
				},
				"swap-meet": {
					name: "Swap Meet",
					text: "In a lair or lost chamber, you may trash this card and a trophy to take a market item for free",
					acquire: "",
					arrive: "",
					react: ""
				},
				"cavern-prowler": {
					name: "Cavern Prowler",
					text: "Acquire a card for free",
					acquire: "",
					arrive: "",
					react: ""
				},
				"venomous-lurker": {
					name: "Venomous Lurker",
					text: "Defeat: gain 3 Gold. Trophy: while in a Crystal Cave, you cannot heal.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"ape-lord-epaulets": {
					name: "Ape Lord Epaulets",
					text: "Trophy: worth 3 points with a Monkey Idol or Crown, or 7 with both.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"golden-hourglass": {
					name: "Golden Hourglass",
					text: "Trophy: gain 1 Gold whenever you reshuffle your deck.",
					acquire: "",
					arrive: "You may return the lowest-value artifact from a room to the stack, excluding the Magic Lyre",
					react: ""
				},
				"quick-pick": {
					name: "Quick Pick",
					text: "Spend a Lockpick this turn：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"merchants-guild-pin": {
					name: "Merchant`s Guild Pin",
					text: "Trophy: each market item costs 1 less Gold.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"monkey-paw": {
					name: "Monkey Paw",
					text: "+1 Clank!; Have a Monkey Idol：You may trash a card in your play area or discard pile",
					acquire: "",
					arrive: "",
					react: ""
				},
				"skeleton-herald": {
					name: "Skeleton Herald",
					text: "+1 Clank!; Gain 1 Gold for each Clank! already made this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				"hoard-keeper": {
					name: "Hoard Keeper",
					text: "Defeat: gain 3 Gold and make 1 Clank! Trophy: worth 1 point per 5 Gold you have.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-guard": {
					name: "Rebel Guard",
					text: "Have another companion in your play area：Draw 1 card(s)",
					acquire: "+1 Swords",
					arrive: "",
					react: ""
				},
				"evil-wizard": {
					name: "Evil Wizard",
					text: "Trophy: draw a card for your first Secret Tome each turn. On the second, make 2 Clank! and trash this trophy.",
					acquire: "",
					arrive: "",
					react: ""
				},
				candelabra: {
					name: "Candelabra",
					text: "Have marked at least three rooms：+1 Healing",
					acquire: "",
					arrive: "",
					react: ""
				},
				"ten-foot-pole": {
					name: "Ten-Foot Pole",
					text: "Draw 1 card(s); You may redraw a tile discovered this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				tinkerer: {
					name: "Tinkerer",
					text: "Devices cost 2 less Skill this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				"underworld-guide": {
					name: "Underworld Guide",
					text: "Draw a card if you are in the Underworld. When you trash this, draw a card.",
					acquire: "+1 Undercoins",
					arrive: "",
					react: ""
				},
				"moneychangers-booth": {
					name: "Moneychanger`s Booth",
					text: "+2 Undercoins",
					acquire: "",
					arrive: "",
					react: ""
				},
				catapult: {
					name: "Catapult",
					text: "+2 Clank!; You may teleport to an adjacent room",
					acquire: "",
					arrive: "",
					react: ""
				},
				"underground-spring": {
					name: "Underground Spring",
					text: "+1 Healing; Be in the Underworld：You may trash a card in your play area or discard pile",
					acquire: "",
					arrive: "",
					react: ""
				},
				"mystic-elevator": {
					name: "Mystic Elevator",
					text: "+1 Clank!; You may teleport to an Underworld Market",
					acquire: "",
					arrive: "",
					react: ""
				},
				"shifting-shadow": {
					name: "Shifting Shadow",
					text: "You may move against one-way arrows this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				"harpy-matriarch": {
					name: "Harpy Matriarch",
					text: "Fight only in the Underworld. Trophy: worth 1 point per harpy trophy, including this. Counts as a harpy for future Undercoin rewards.",
					acquire: "",
					arrive: "",
					react: ""
				},
				chimera: {
					name: "Chimera",
					text: "Take a major secret; +1 Clank!",
					acquire: "",
					arrive: "+1 Clank! (all players)",
					react: ""
				},
				cyclops: {
					name: "Cyclops",
					text: "+1 Lockpicks; You may trash a card in your play area or discard pile",
					acquire: "",
					arrive: "+1 Clank! (all players)",
					react: ""
				},
				"wild-boar": {
					name: "Wild Boar",
					text: "+1 Clank!; Draw 2 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"abyssal-hydra": {
					name: "Abyssal Hydra",
					text: "Draw 2 card(s); Take 2 Undercoins from the Hydra",
					acquire: "",
					arrive: "Stock the Hydra with Undercoins",
					react: ""
				},
				"grave-robber": {
					name: "Grave Robber",
					text: "+1 Undercoins",
					acquire: "",
					arrive: "Rotate every occupied square tile 180 degrees",
					react: ""
				},
				"gray-knight": {
					name: "Gray Knight",
					text: "",
					acquire: "+1 Undercoins",
					arrive: "",
					react: ""
				},
				"underworld-dealer": {
					name: "Underworld Dealer",
					text: "Choose one: +1 Undercoins / Spend 3 Gold to take a Secret Tome",
					acquire: "+1 Undercoins",
					arrive: "",
					react: ""
				},
				george: {
					name: "George",
					text: "+1 Clank!; Draw 1 card(s); Have a Monkey Idol：+1 Skill; +1 Swords; +1 Clank!; Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				sculptor: {
					name: "Sculptor",
					text: "Choose one: You may trash a played card / Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				soothsayer: {
					name: "Soothsayer",
					text: "Have a Fate card：+1 Skill",
					acquire: "",
					arrive: "Each player may spend 1 Gold to heal 1",
					react: ""
				},
				orpheus: {
					name: "Orpheus",
					text: "Make 1 Clank! and gain 1 Undercoin. Worth 1 point per freed prisoner.",
					acquire: "Free a prisoner",
					arrive: "Return up to 3 black cubes from the Bank to the bag",
					react: ""
				},
				"hero-of-prophecy": {
					name: "Hero of Prophecy",
					text: "Have a Fate card：You may trash a card in your play area or discard pile",
					acquire: "",
					arrive: "",
					react: ""
				},
				oracle: {
					name: "Oracle",
					text: "Choose one: Draw 1 card(s) / Spend 1 Undercoin to draw two cards",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-tunnel-guide": {
					name: "Rebel Tunnel Guide",
					text: "Have another companion in your play area：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"rebel-rouser": {
					name: "Rebel Rouser",
					text: "Have another companion in your play area：Draw 1 card(s); Make at least 2 Clank! this turn：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"spellblade-invoker": {
					name: "Spellblade Invoker",
					text: "+1 Clank!; You may teleport to an adjacent room",
					acquire: "",
					arrive: "",
					react: ""
				},
				"apprentice-thief": {
					name: "Apprentice Thief",
					text: "",
					acquire: "+1 Lockpicks",
					arrive: "",
					react: ""
				},
				"polished-garnet": {
					name: "Polished Garnet",
					text: "+1 Undercoins; Draw 1 card(s)",
					acquire: "+2 Clank!",
					arrive: "",
					react: ""
				},
				garnet: {
					name: "Garnet",
					text: "+1 Undercoins; Draw 1 card(s)",
					acquire: "+2 Clank!",
					arrive: "",
					react: ""
				},
				"fire-breath": {
					name: "Fire Breath",
					text: "Make at least 1 Clank! this turn：Draw 1 card(s)",
					acquire: "+1 Swords",
					arrive: "",
					react: ""
				},
				"escape-plan": {
					name: "Escape Plan",
					text: "When you trash this, gain two Boots and ignore Crystal Caves this turn.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"tome-of-intellect": {
					name: "Tome of Intellect",
					text: "Draw 2 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				"tome-of-the-ape-lords": {
					name: "Tome of the Ape Lords",
					text: "Have a Monkey Idol：Counts as a Secret Tome this turn",
					acquire: "+3 Clank!",
					arrive: "",
					react: ""
				},
				"soul-prism": {
					name: "Soul Prism",
					text: "When you trash this, free a prisoner.",
					acquire: "+1 Healing",
					arrive: "",
					react: ""
				},
				"ethereal-step": {
					name: "Ethereal Step",
					text: "Generate at least 6 Skill this turn：You may teleport to an adjacent room",
					acquire: "",
					arrive: "",
					react: ""
				},
				thunderstriker: {
					name: "Thunderstriker",
					text: "Draw a card. Worth 1 point per harpy trophy.",
					acquire: "",
					arrive: "",
					react: ""
				},
				slink: {
					name: "Slink",
					text: "-2 Clank!; Draw 1 card(s)",
					acquire: "+1 Boots; -2 Clank!",
					arrive: "",
					react: ""
				},
				"acid-splash": {
					name: "Acid Splash",
					text: "Reveal your top card, reshuffling if needed. Trash it, or discard it for 2 Swords",
					acquire: "",
					arrive: "",
					react: ""
				},
				"quick-trip": {
					name: "Quick Trip",
					text: "Have an artifact worth 10 or less：You need not stop in Crystal Caves this turn",
					acquire: "+1 Boots; +2 Clank!",
					arrive: "",
					react: ""
				},
				"burial-urn": {
					name: "Burial Urn",
					text: "When you trash this, gain 4 Undercoins.",
					acquire: "",
					arrive: "",
					react: ""
				},
				"wealth-of-knowledge": {
					name: "Wealth of Knowledge",
					text: "",
					acquire: "",
					arrive: "+1 Undercoins (all players)",
					react: ""
				},
				lantern: {
					name: "Lantern",
					text: "+1 Undercoins",
					acquire: "",
					arrive: "",
					react: ""
				},
				"utility-knife": {
					name: "Utility Knife",
					text: "Draw 1 card(s)",
					acquire: "+1 Undercoins",
					arrive: "",
					react: ""
				},
				"big-ideas": {
					name: "Big Ideas",
					text: "+1 Clank!; Generate at least 6 Skill this turn：+1 Undercoins",
					acquire: "",
					arrive: "",
					react: ""
				},
				burgle: {
					name: "Burgle",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				stumble: {
					name: "Stumble",
					text: "+1 Clank!",
					acquire: "",
					arrive: "",
					react: ""
				},
				sidestep: {
					name: "Sidestep",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				scramble: {
					name: "Scramble",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				explore: {
					name: "Explore",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				mercenary: {
					name: "Mercenary",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				tome: {
					name: "Secret Tome",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				psyfoot: {
					name: "Pussyfoot",
					text: "Ignore tunnel monsters this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				cattitude: {
					name: "Cattitude",
					text: "Flip a behavior token to gain its resource",
					acquire: "",
					arrive: "",
					react: ""
				},
				saunter: {
					name: "Saunter",
					text: "Flip a behavior token; double its reward with an artifact",
					acquire: "",
					arrive: "",
					react: ""
				},
				ransack: {
					name: "Ransack",
					text: "",
					acquire: "",
					arrive: "",
					react: "An opponent defeats a monster"
				},
				scavenge: {
					name: "Scavenge",
					text: "Gain 1 Gold per tunnel monster fought this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				wallop: {
					name: "Wallop",
					text: "",
					acquire: "",
					arrive: "",
					react: ""
				},
				primacy: {
					name: "Primacy",
					text: "Have a Monkey Idol：You need not stop in Crystal Caves this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				persist: {
					name: "Persist",
					text: "+1 Healing; +1 Clank!",
					acquire: "",
					arrive: "",
					react: ""
				},
				bolt: {
					name: "Bolt",
					text: "Have an artifact：+2 Gold; +1 Clank!",
					acquire: "",
					arrive: "",
					react: ""
				},
				collection: {
					name: "Collection",
					text: "+1 Gold; Gain 1 Gold for each different find",
					acquire: "",
					arrive: "",
					react: "An opponent gains a find you do not have"
				},
				competition: {
					name: "Competition",
					text: "Choose the reward for one of your finds",
					acquire: "",
					arrive: "",
					react: "An opponent gains a find you do not have"
				},
				exhibit: {
					name: "Exhibit",
					text: "Choose the reward for one of your finds",
					acquire: "",
					arrive: "",
					react: "An opponent gains a find you do not have"
				},
				"rebel-squire": {
					name: "Rebel Squire",
					text: "Have another companion in your play area：Draw 1 card(s)",
					acquire: "",
					arrive: "",
					react: ""
				},
				inspire: {
					name: "Inspire",
					text: "At turn end, you may put a played companion on your deck",
					acquire: "",
					arrive: "",
					react: ""
				},
				"defensive-position": {
					name: "Defensive Position",
					text: "Be in a Crystal Cave：+2 Swords",
					acquire: "",
					arrive: "",
					react: ""
				},
				channel: {
					name: "Channel",
					text: "+1 Mana; Gain bonus mana for secrets or potions this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				study: {
					name: "Study",
					text: "+1 Mana; Gain 1 mana per Secret Tome played this turn",
					acquire: "",
					arrive: "",
					react: ""
				},
				"mystic-slide": {
					name: "Mystic Slide",
					text: "You may teleport to an adjacent room",
					acquire: "",
					arrive: "",
					react: ""
				}
			},
			rules: "Build your deck, explore the changing Catacombs, recover an artifact, and return to the Crypt. When everyone has escaped or been knocked out, the highest eligible score wins. Break ties with the most valuable artifact.\n\nYour turn:\nPlay cards, move, buy cards, use devices, fight, pick locks, and visit the Market in any order. Skill buys cards and devices; Swords defeat monsters; Boots move you. Acquired cards normally enter your discard pile. Devices and defeated monsters resolve immediately. Play every card in hand before ending your turn. Unspent resources expire. Discard your played cards, draw five, and refill the six-card Dungeon Row.\n\nMovement and discovery:\nMoving to the next room normally costs one Boot. Pay for extra footprints, locks, monsters, and Undercoin tolls along the whole tunnel. Swords prevent tunnel monster damage. You cannot voluntarily take damage that would knock you out or that you cannot mark with cubes from your supply. Opened locks stay open for everyone. Entering a Crystal Cave or falling into a Pit Trap stops further Boot movement for the turn, but not teleportation.\nTo explore, reveal the next tile, choose its orientation, and complete your original move. You may pause to play cards or gain resources. Teleportation ignores tunnel icons and arrows but still triggers rooms. Portals connect to other portals; a full move still pays icons at both ends.\n\nTreasure and rooms:\nCollect each room’s entry reward only on your first entry each turn. You must re-enter on a later turn to collect again. A Lockpick opens a chest for a major secret, a library for a Secret Tome, or a prison to free prisoners. Mark each Wayshrine at most once per player, placing a supply cube and taking Gold equal to your marked Wayshrines. A Backpack adds one artifact slot. Taking an artifact increases rage.\n\nDragon attacks and escape:\nA dragon icon on a newly refilled card triggers one attack. Move all Clank! cubes into the bag and draw according to rage plus Danger. Black cubes go to the Bank. Colored cubes damage their player. Each white Ghost damages every active player, then returns to the Clank! area.\nReturn to the Crypt with an artifact, finish your turn, then escape with a 20-point Mastery token. Knocked-out players normally score zero without an artifact or in the Depths or Underworld. An artifact carrier knocked out in safety still scores. Add artifacts, Gold, cards, secrets, prisoners, market items, and other rewards. An eliminated seat causes a fixed four-cube attack on each of its turns, or six cubes in a two-player game. There is no countdown. If the row cannot be refilled, or the bag is empty after an attack, all remaining players are knocked out immediately and the game ends.\n\nOptional expansions:\nLairs & Lost Chambers adds Pit Traps, Magic Barriers, special chambers, and room monsters. Trophies remain in your supply and provide abilities or points. The Underworld is a separate map reached by ladders or one-way chutes. Starting a turn there costs one Undercoin; if you cannot pay, make two Clank! instead. It has its own Market, Fate cards, harpies, artifact enhancers, and Imp Assistants.\nAdventuring Party adds optional reactions: when an opponent meets a condition, place the matching card in your reaction area and draw a replacement. Resolve it on your next turn. Six unique characters have distinct starting decks and abilities. Five- and six-player games add artifacts, reserve cards, and Invisibility Cloaks; a player cannot take two artifacts from the same room. Each expansion can be enabled separately.",
			fates: {
				fool: "Worth 10 points if you have at least two Stumbles.",
				magician: "Worth 3 points. This counts as a Secret Tome.",
				"high-priestess": "Worth 3 points. Reveal on a later turn to ignore Crystal Caves for that turn.",
				empress: "Worth 6 points if you have a Crown.",
				emperor: "Worth 12 points if you have an artifact enhancer, a Crown, and a Monkey Idol.",
				hierophant: "Worth 2 points. Reveal on a later turn to teleport to an adjacent room.",
				lovers: "Worth 2 points. Reveal immediately to heal 2.",
				chariot: "Worth −3 points. Reveal immediately; gain a Boot on each of your turns.",
				strength: "Worth 3 / 5 / 8 points with 1 / 2 / at least 3 harpy trophies.",
				hermit: "Worth 6 points if you have a Monkey Idol.",
				wheel: "Worth 10 points if you have at least 10 Gold, including Undercoins.",
				justice: "You may reveal this to permanently increase your artifact limit by one.",
				"hanged-man": "Worth 5 points. Reveal immediately to add a Ghost cube to the Clank! area.",
				death: "Normally worth 1 point. If knocked out in the Depths with an artifact, you still score, but this is worth −5. Does not save you in the Underworld.",
				temperance: "Worth 4 points.",
				imp: "Worth 4 / 8 / 12 points with 1 / 2 / at least 3 Gems.",
				tower: "Worth 3 points. Reveal while in a Tower to gain 3 Gold.",
				star: "Worth 3 points. Reveal during a Dragon Attack to prevent damage from all your cubes drawn in that attack and return them to your supply.",
				moon: "Worth 8 points if you have at least two Underworld market items.",
				sun: "Worth 10 points if you have a Mastery token.",
				judgement: "Worth 5 points. Reveal immediately and trigger a Dragon Attack.",
				world: "Worth 7 points if you have at least three market items."
			},
			characters: {
				adventurer: "Standard starting deck.",
				agnet: "When acquiring a companion, you may spend one of four Conscription tokens to place it on your deck.",
				dallan: "Your starting cards reward finds: a Dragon Egg, Monkey Idol, Crown, and artifact.",
				garignar: "Advance Carnage and take its reward the first time each turn you defeat a Monster card, including the Goblin.",
				lenara: "Store up to 10 mana. Once per turn per spell: 3 mana to discard and draw, 5 to copy a played card, 7 to acquire a row card into your hand.",
				monkeybot: "After taking damage in a Dragon Attack, reveal the leftmost cog. Gain all revealed rewards on your turns: Sword, Boot, Skill, Sword, Boot, Skill, Sword.",
				whiskers: "Flip behavior tokens for Skill, Swords, or Boots. End with all three flipped to trigger a four-cube attack; your cubes return safely to your supply. Then reset the tokens."
			}
		}
	}
};
//#endregion
export { Na as default };
