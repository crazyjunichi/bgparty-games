import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { ConfirmButton as l } from "@bgparty/sdk/confirm-button";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { IconBack as h, IconBot as g, IconExpand as _, IconLog as v } from "@bgparty/sdk/icons";
import { seatName as y } from "@bgparty/sdk/ui/player-strip";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as x, OptionSection as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/blacksonata/data.ts
var C = [
	"clerkenwell",
	"blackfriars",
	"clink",
	"southwark",
	"london-bridge",
	"eastcheap",
	"bishopsgate",
	"shoreditch",
	"cripplegate",
	"st-pauls",
	"cornhill"
], w = {
	clerkenwell: {
		x: 19.31,
		y: 25.32,
		icons: [6, 4]
	},
	blackfriars: {
		x: 25.13,
		y: 57.75,
		icons: [
			2,
			7,
			5
		]
	},
	clink: {
		x: 40.95,
		y: 81.14,
		icons: [
			2,
			7,
			5
		]
	},
	southwark: {
		x: 73.04,
		y: 84.33,
		icons: [4, 1]
	},
	"london-bridge": {
		x: 78.99,
		y: 74.85,
		icons: [3, 5]
	},
	eastcheap: {
		x: 74.87,
		y: 59.7,
		icons: [1]
	},
	bishopsgate: {
		x: 79.84,
		y: 41.36,
		icons: [2, 4]
	},
	shoreditch: {
		x: 76.44,
		y: 16.11,
		icons: [6, 7]
	},
	cripplegate: {
		x: 44.02,
		y: 33.65,
		icons: [2]
	},
	"st-pauls": {
		x: 33.89,
		y: 49.78,
		icons: [4]
	},
	cornhill: {
		x: 67.03,
		y: 47.74,
		icons: [3]
	}
}, T = {
	clerkenwell: ["blackfriars", "cripplegate"],
	blackfriars: [
		"clerkenwell",
		"clink",
		"st-pauls"
	],
	clink: ["blackfriars", "southwark"],
	southwark: ["clink", "london-bridge"],
	"london-bridge": ["southwark", "eastcheap"],
	eastcheap: [
		"london-bridge",
		"bishopsgate",
		"cornhill"
	],
	bishopsgate: [
		"eastcheap",
		"shoreditch",
		"cornhill"
	],
	shoreditch: ["bishopsgate", "cripplegate"],
	cripplegate: [
		"clerkenwell",
		"shoreditch",
		"st-pauls",
		"cornhill"
	],
	"st-pauls": [
		"blackfriars",
		"cripplegate",
		"cornhill"
	],
	cornhill: [
		"eastcheap",
		"bishopsgate",
		"cripplegate",
		"st-pauls"
	]
}, E = {
	A: {
		location: "eastcheap",
		icon: 1
	},
	B: {
		location: "bishopsgate",
		icon: 2
	},
	C: {
		location: "cornhill",
		icon: 3
	},
	D: {
		location: "st-pauls",
		icon: 4
	},
	E: {
		location: "blackfriars",
		icon: 5
	},
	F: {
		location: "clerkenwell",
		icon: 6
	},
	G: {
		location: "blackfriars",
		icon: 2
	},
	H: {
		location: "clink",
		icon: 5
	},
	I: {
		location: "southwark",
		icon: 1
	},
	J: {
		location: "london-bridge",
		icon: 5
	},
	K: {
		location: "eastcheap",
		icon: 1
	},
	L: {
		location: "bishopsgate",
		icon: 2
	},
	M: {
		location: "cornhill",
		icon: 3
	},
	N: {
		location: "cripplegate",
		icon: 2
	},
	O: {
		location: "shoreditch",
		icon: 6
	},
	P: {
		location: "cripplegate",
		icon: 2
	},
	Q: {
		location: "clerkenwell",
		icon: 4
	},
	R: {
		location: "blackfriars",
		icon: 7
	},
	S: {
		location: "clink",
		icon: 2
	},
	T: {
		location: "southwark",
		icon: 1
	},
	U: {
		location: "clink",
		icon: 7
	},
	V: {
		location: "southwark",
		icon: 4
	},
	W: {
		location: "london-bridge",
		icon: 3
	},
	X: {
		location: "eastcheap",
		icon: 1
	},
	Y: {
		location: "bishopsgate",
		icon: 4
	},
	Z: {
		location: "cornhill",
		icon: 3
	},
	"--X": {
		location: "shoreditch",
		icon: 6
	},
	"-A": {
		location: "london-bridge",
		icon: 3
	},
	"-K": {
		location: "shoreditch",
		icon: 7
	},
	"-L": {
		location: "cripplegate",
		icon: 2
	},
	"-S": {
		location: "st-pauls",
		icon: 4
	},
	"-U": {
		location: "clerkenwell",
		icon: 6
	}
}, D = [
	{
		difficulty: "very-easy",
		movement: "moves",
		cards: /* @__PURE__ */ "J.K.-A.I.U.T.W.X.M.Y.--X.-L.Q.P.Z.D.C.B.A.L.-K.N.F.G.S.R.-S.E.H.V".split(".")
	},
	{
		difficulty: "very-easy",
		movement: "may",
		cards: /* @__PURE__ */ "N.M.Z.B.K.J.X.W.T.U.I.H.V.-A.A.Y.L.--X.O.-L.D.C.P.F.G.S.E.Q.R.-S".split(".")
	},
	{
		difficulty: "easy",
		movement: "moves",
		cards: /* @__PURE__ */ "R.H.V.W.I.J.K.Y.X.B.C.-L.O.N.-S.G.U.T.-A.A.M.L.-K.P.Z.D.E.-U".split(".")
	},
	{
		difficulty: "easy",
		movement: "moves",
		cards: /* @__PURE__ */ "N.-U.E.S.I.-A.K.W.X.Y.-K.L.Z.D.M.P.C.-L.O.B.A.J.T.U.G.F.R.Q".split(".")
	},
	{
		difficulty: "easy",
		movement: "moves",
		cards: /* @__PURE__ */ "I.J.A.M.N.Q.R.D.C.L.K.W.X.B.O.P.-K.-L.--X.Y.Z.-S.G.U.V.H.T.S".split(".")
	},
	{
		difficulty: "easy",
		movement: "may",
		cards: /* @__PURE__ */ "O.P.-U.Q.G.S.U.V.-A.X.L.M.A.B.-K.-L.C.D.-S.E.H.R.F.N.Z.K.Y.--X".split(".")
	},
	{
		difficulty: "easy",
		movement: "may",
		cards: /* @__PURE__ */ "W.V.H.G.D.R.-U.E.F.P.Z.M.C.Y.K.J.T.I.-A.A.B.--X.-L.-S.N.-K.L.X".split(".")
	},
	{
		difficulty: "easy",
		movement: "may",
		cards: /* @__PURE__ */ "T.J.K.M.Y.C.D.Z.-L.-S.R.-U.E.U.G.F.P.Q.N.O.L.--X.B.X.W.V.I.H".split(".")
	},
	{
		difficulty: "moderate",
		movement: "moves",
		cards: /* @__PURE__ */ "G.-S.P.-U.R.F.E.Q.-L.-K.N.Z.Y.O.B.X.M.K.L.C.A.J.T.U.I.S".split(".")
	},
	{
		difficulty: "moderate",
		movement: "moves",
		cards: /* @__PURE__ */ "Q.-L.C.D.Z.N.-U.P.-S.E.U.T.J.A.Y.-K.L.X.W.V.H.I.S.G.F.R".split(".")
	},
	{
		difficulty: "moderate",
		movement: "moves",
		cards: /* @__PURE__ */ "--X.B.M.-S.-L.-K.L.X.J.V.H.E.S.G.U.R.Q.N.O.Y.C.A.W.K.Z.P".split(".")
	},
	{
		difficulty: "moderate",
		movement: "may",
		cards: /* @__PURE__ */ "G.Q.-L.F.E.D.Z.P.M.A.C.B.--X.Y.K.X.L.-K.O.N.-S.R.U.I.V.H".split(".")
	},
	{
		difficulty: "moderate",
		movement: "may",
		cards: /* @__PURE__ */ "B.--X.-K.L.X.C.-S.-L.P.Z.Y.O.N.-U.E.U.I.H.R.S.G.D.M.A.J.K".split(".")
	},
	{
		difficulty: "moderate",
		movement: "may",
		cards: /* @__PURE__ */ "J.T.V.S.G.F.R.-S.N.M.K.L.--X.Y.C.D.P.-L.Q.E.H.I.-A.A.W.X".split(".")
	},
	{
		difficulty: "hard",
		movement: "moves",
		cards: [
			"U",
			"E",
			"D",
			"-L",
			"M",
			"A",
			"C",
			"X",
			"J",
			"I",
			"-A",
			"T",
			"S",
			"V",
			"W",
			"K",
			"B",
			"Z",
			"-S",
			"N",
			"Q",
			"G",
			"-U",
			"R"
		]
	},
	{
		difficulty: "hard",
		movement: "moves",
		cards: [
			"G",
			"D",
			"P",
			"Q",
			"N",
			"--X",
			"Y",
			"-K",
			"L",
			"O",
			"-L",
			"-S",
			"R",
			"S",
			"T",
			"W",
			"A",
			"J",
			"V",
			"-A",
			"I",
			"U",
			"E",
			"H"
		]
	},
	{
		difficulty: "hard",
		movement: "moves",
		cards: [
			"-L",
			"--X",
			"B",
			"X",
			"M",
			"A",
			"-A",
			"T",
			"S",
			"R",
			"-U",
			"N",
			"-S",
			"C",
			"K",
			"Z",
			"Y",
			"-K",
			"P",
			"F",
			"G",
			"U",
			"E",
			"Q"
		]
	},
	{
		difficulty: "hard",
		movement: "may",
		cards: [
			"D",
			"P",
			"F",
			"G",
			"U",
			"I",
			"H",
			"S",
			"T",
			"J",
			"V",
			"W",
			"X",
			"-A",
			"K",
			"M",
			"A",
			"L",
			"B",
			"Z",
			"N",
			"-S",
			"C",
			"-L"
		]
	},
	{
		difficulty: "hard",
		movement: "may",
		cards: [
			"-L",
			"Q",
			"P",
			"-S",
			"N",
			"F",
			"G",
			"D",
			"Z",
			"B",
			"--X",
			"Y",
			"L",
			"C",
			"X",
			"K",
			"J",
			"I",
			"T",
			"W",
			"V",
			"-A",
			"A",
			"M"
		]
	},
	{
		difficulty: "hard",
		movement: "may",
		cards: [
			"X",
			"C",
			"N",
			"-U",
			"R",
			"S",
			"E",
			"U",
			"H",
			"G",
			"-S",
			"P",
			"D",
			"M",
			"A",
			"W",
			"T",
			"V",
			"J",
			"K",
			"Z",
			"Y",
			"-K",
			"L"
		]
	}
], O = [
	"rose",
	"oak",
	"bluebell",
	"acorn",
	"thistle",
	"sage"
], k = [
	"literary",
	"musical",
	"amorous",
	"children",
	"married",
	"court",
	"shakespeare"
], A = (e, t, n, r, i, a) => ({
	rose: e,
	oak: t,
	bluebell: n,
	acorn: r,
	thistle: i,
	sage: a
}), j = [
	{
		id: "mary-fitton",
		suit: "rose",
		traits: [
			"court",
			"shakespeare",
			"children"
		],
		match: A(1, 1, "02", 2, "02", 1)
	},
	{
		id: "elizabeth-vernon",
		suit: "rose",
		traits: [
			"married",
			"court",
			"amorous"
		],
		match: A(1, 1, "02", 2, "02", 1)
	},
	{
		id: "emilia-lanier",
		suit: "oak",
		traits: [
			"musical",
			"married",
			"children"
		],
		match: A(1, 1, 1, "02", 2, "02")
	},
	{
		id: "anne-whateley",
		suit: "oak",
		traits: [
			"shakespeare",
			"amorous",
			"musical"
		],
		match: A(1, 1, 1, "02", 2, "02")
	},
	{
		id: "winifred-burbage",
		suit: "bluebell",
		traits: [
			"shakespeare",
			"literary",
			"children"
		],
		match: A("02", 1, 1, 1, "02", 2)
	},
	{
		id: "aline-florio",
		suit: "bluebell",
		traits: [
			"amorous",
			"literary",
			"married"
		],
		match: A("02", 1, 1, 1, "02", 2)
	},
	{
		id: "lucy-morgan",
		suit: "acorn",
		traits: [
			"amorous",
			"court",
			"shakespeare"
		],
		match: A(2, "02", 1, 1, 1, "02")
	},
	{
		id: "penelope-rich",
		suit: "acorn",
		traits: [
			"children",
			"married",
			"court"
		],
		match: A(2, "02", 1, 1, 1, "02")
	},
	{
		id: "anne-hathaway",
		suit: "thistle",
		traits: [
			"shakespeare",
			"children",
			"musical"
		],
		match: A("02", 2, "02", 1, 1, 1)
	},
	{
		id: "jane-davenant",
		suit: "thistle",
		traits: [
			"married",
			"amorous",
			"musical"
		],
		match: A("02", 2, "02", 1, 1, 1)
	},
	{
		id: "marie-mountjoy",
		suit: "sage",
		traits: [
			"amorous",
			"shakespeare",
			"literary"
		],
		match: A(1, "02", 2, "02", 1, 1)
	},
	{
		id: "jacqueline-field",
		suit: "sage",
		traits: [
			"literary",
			"children",
			"married"
		],
		match: A(1, "02", 2, "02", 1, 1)
	}
], M = (e) => {
	let t = j.find((t) => t.id === e);
	if (!t) throw Error(`unknown clue ${e}`);
	return t;
}, N = [
	"revealClue",
	"moveAnywhere",
	"lookAhead",
	"discardReveal",
	"swapClue",
	"moveNeighbour",
	"advanceTwo",
	"discardSelf",
	"discardFogTop",
	"shuffleLady"
], P = [
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10
], F = (e) => N[e - 1], I = [
	{
		min: 61,
		key: "games.blacksonata.rankBard"
	},
	{
		min: 41,
		key: "games.blacksonata.rankFair"
	},
	{
		min: 20,
		key: "games.blacksonata.rankGolden"
	},
	{
		min: -Infinity,
		key: "games.blacksonata.rankChimney"
	}
], L = {
	id: "blacksonata",
	tier: "beta",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.blacksonata.name",
	descKey: "games.blacksonata.desc",
	rulesKey: "games.blacksonata.rules",
	icon: "🕵️",
	iconImg: "games/blacksonata.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/blacksonata/en.pdf" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#3d5a80",
	releasedAt: "2026-10-01",
	search: {
		py: "hei se zou ming qu",
		init: "hszmq"
	},
	hotseat: "cover"
}, R = t.enum(C), z = t.enum(k), ee = t.enum(O), te = t.int().min(1).max(7), B = [
	"training",
	"easy",
	"standard",
	"advanced",
	"expert"
], V = [
	"random",
	"very-easy",
	"easy",
	"moderate",
	"hard"
], H = [
	"random",
	"moves",
	"may"
], U = t.object({
	difficulty: t.enum(B).default("standard"),
	route: t.enum(V).default("random"),
	movement: t.enum(H).default("random"),
	expertFog: t.int().min(1).max(10).default(3)
}).default({
	difficulty: "standard",
	route: "random",
	movement: "random",
	expertFog: 3
}), ne = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseStart"),
		location: R
	}),
	t.object({
		type: t.literal("move"),
		location: R
	}),
	t.object({ type: t.literal("search") }),
	t.object({ type: t.literal("hitClue") }),
	t.object({ type: t.literal("hitConfront") }),
	t.object({ type: t.literal("fog") }),
	t.object({
		type: t.literal("fogTarget"),
		target: t.string()
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("toggleMark"),
		location: R
	}),
	t.object({
		type: t.literal("setDeduction"),
		trait: z,
		value: t.enum(["yes", "no"]).nullable()
	}),
	t.object({ type: t.literal("revealSuit") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), re = t.union([
	t.object({
		kind: t.literal("stealth"),
		icon: te
	}),
	t.object({ kind: t.literal("fog") }),
	t.object({
		kind: t.literal("countdown"),
		value: t.int()
	})
]), ie = t.object({
	win: t.boolean(),
	reason: t.string(),
	score: t.int().nullable(),
	breakdown: t.object({
		aboveCountdown: t.int(),
		countdownValue: t.int(),
		routeLen: t.int(),
		fogLeft: t.int(),
		adjust: t.int(),
		total: t.int()
	}).nullable(),
	ladyId: t.string()
}), ae = t.object({
	phase: t.enum([
		"setup",
		"play",
		"hitChoice",
		"fogTarget",
		"flee",
		"ladyMove",
		"done"
	]),
	pawn: R.nullable(),
	visited: t.array(R),
	topCard: re,
	deckSize: t.int(),
	countdown: t.int(),
	countdownFromTop: t.int(),
	fogCount: t.int(),
	clueDeckCount: t.int(),
	clues: t.array(t.string()),
	suitRevealed: ee.nullable(),
	deduction: t.array(t.object({
		trait: z,
		value: t.enum(["yes", "no"])
	})),
	marks: t.array(R),
	fleeLeft: t.int(),
	pendingFog: t.enum(N).nullable(),
	searchHit: t.boolean(),
	peek: t.array(re).nullable(),
	usedMove: t.boolean(),
	usedSearch: t.boolean(),
	difficulty: t.enum(B),
	routeLen: t.int(),
	result: ie.nullable()
}), oe = t.object({}), W = {
	flee: 350,
	ladyMove: 700
};
function G(t, n, r) {
	let i = [...t];
	for (let t = i.length - 1; t > 0; --t) {
		let a = e(n, r.n, t + 1);
		r.n += 1, [i[t], i[a]] = [i[a], i[t]];
	}
	return i;
}
var se = (e) => k.filter((t) => e.deduction[t] === "yes"), ce = (e, t) => t.kind === "stealth" ? {
	kind: "stealth",
	icon: E[t.card].icon
} : t.kind === "fog" ? { kind: "fog" } : {
	kind: "countdown",
	value: e.countdown
};
function le(e, t) {
	e.peek = null;
	let n = t;
	for (; n > 0;) {
		let t = e.deck.shift();
		if (e.deck.push(t), t.kind === "countdown") {
			if (e.countdown === 0) return !1;
			--e.countdown;
		} else --n;
	}
	for (; e.deck[0].kind === "countdown";) {
		if (e.countdown === 0) return !1;
		--e.countdown, e.deck.push(e.deck.shift());
	}
	return !0;
}
function K(e, t) {
	return e.phase = "done", e.result = {
		win: !1,
		reason: t,
		score: null,
		breakdown: null
	}, {
		state: e,
		fx: [{
			kind: "lose",
			data: { reason: t }
		}]
	};
}
function ue(e) {
	let t = e.deck.findIndex((e) => e.kind === "countdown"), n = e.countdown, r = e.route.length, i = e.fogDeck.length, a = 0;
	e.config.difficulty === "easy" && (a = -30), e.config.difficulty === "advanced" && (a = 5), e.config.difficulty === "expert" && (a = 5 + 5 * e.expertFog);
	let o = t + n * r + i * 2 + a;
	return e.config.difficulty === "training" && (o = Math.ceil(o / 2)), {
		aboveCountdown: t,
		countdownValue: n,
		routeLen: r,
		fogLeft: i,
		adjust: a,
		total: o
	};
}
function q(e) {
	if (e.clueDeck.length === 0) return null;
	let t = e.clueDeck.shift();
	return e.clues.push(t), t;
}
function de(e, t) {
	let n = [{
		kind: "search",
		data: t
	}], r = e.clues.length;
	return r === 0 ? (e.phase = "ladyMove", e.beatMs = W.ladyMove) : (e.phase = "flee", e.fleeLeft = r, e.beatMs = W.flee), {
		state: e,
		fx: n
	};
}
function J(e) {
	e.phase = "ladyMove", e.beatMs = W.ladyMove;
}
function fe(t, n, r) {
	let i = { n: 0 }, a = [];
	for (let e of D) (t.route === "random" || e.difficulty === t.route) && (t.movement === "random" || e.movement === t.movement) && a.push(e.cards, [...e.cards].reverse());
	let o = a[e(r, i.n, a.length)];
	i.n += 1;
	let s = e(r, i.n, o.length);
	i.n += 1;
	let c = [...o.slice(s), ...o.slice(0, s)], l = c.map((e, t) => ({
		kind: "stealth",
		routeIdx: t,
		card: e
	}));
	l.push({ kind: "countdown" });
	let u = G(j.map((e) => e.id), r, i), d = u[0], f = M(d).suit, p = j.find((e) => e.suit === f && e.id !== d).id, m = O.indexOf(f), h = t.difficulty === "easy" ? O[(m + 2) % 6] : t.difficulty === "advanced" || t.difficulty === "expert" ? O[(m + 1) % 6] : null, g = u.slice(1).filter((e) => e !== p && M(e).suit !== h), _ = t.difficulty === "expert" ? t.expertFog : 0, v = G(P, r, i).slice(_);
	return {
		state: {
			players: n,
			seed: r,
			config: t,
			route: c,
			deck: l,
			countdown: t.difficulty === "easy" ? 3 : 2,
			fogDeck: v,
			expertFog: _,
			ladyId: d,
			suitCardId: p,
			clueDeck: g,
			clues: [],
			suitRevealed: !1,
			visited: [],
			pawn: null,
			deduction: {},
			marks: [],
			phase: "setup",
			pendingFog: null,
			searchHit: !1,
			fleeLeft: 0,
			usedMove: !1,
			usedSearch: !1,
			peek: null,
			result: null,
			beatMs: 0,
			rngCursor: i.n
		},
		fx: []
	};
}
function pe(e, t) {
	if (t.type === "toggleMark") {
		if (e.phase === "done") return { code: "games.blacksonata.errNotNow" };
		let n = structuredClone(e);
		return n.marks = n.marks.includes(t.location) ? n.marks.filter((e) => e !== t.location) : [...n.marks, t.location], {
			state: n,
			fx: []
		};
	}
	if (t.type === "setDeduction") {
		if (e.phase === "done") return { code: "games.blacksonata.errNotNow" };
		if (t.value === "yes" && e.deduction[t.trait] !== "yes" && se(e).length >= 3) return { code: "games.blacksonata.errPinLimit" };
		let n = structuredClone(e);
		return t.value === null ? delete n.deduction[t.trait] : n.deduction[t.trait] = t.value, {
			state: n,
			fx: []
		};
	}
	if (t.type === "revealSuit") {
		if (e.phase === "done" || e.suitRevealed || e.visited.length < C.length) return { code: "games.blacksonata.errNotNow" };
		let t = structuredClone(e);
		return t.suitRevealed = !0, t.clues.push(t.suitCardId), {
			state: t,
			fx: [{
				kind: "suit",
				data: { card: t.suitCardId }
			}]
		};
	}
	if (t.type === "tick") {
		if (e.phase === "ladyMove") {
			let t = structuredClone(e);
			return le(t, 1) ? (t.phase = "play", t.usedMove = !1, t.usedSearch = !1, t.beatMs = 0, {
				state: t,
				fx: [{
					kind: "ladyMove",
					data: { top: ce(t, t.deck[0]) }
				}]
			}) : K(t, "games.blacksonata.reasonTimeout");
		}
		if (e.phase === "flee") {
			let t = structuredClone(e);
			t.peek = null;
			let n = t.deck.shift();
			return t.deck.push(n), n.kind === "countdown" ? t.countdown === 0 ? K(t, "games.blacksonata.reasonTimeout") : (--t.countdown, {
				state: t,
				fx: [{
					kind: "countdown",
					data: { value: t.countdown }
				}]
			}) : (--t.fleeLeft, t.fleeLeft <= 0 && J(t), {
				state: t,
				fx: [{
					kind: "fleeStep",
					data: { left: t.fleeLeft }
				}]
			});
		}
		return {
			state: e,
			fx: []
		};
	}
	if (t.type === "chooseStart") {
		if (e.phase !== "setup") return { code: "games.blacksonata.errNotNow" };
		let n = structuredClone(e);
		return n.pawn = t.location, n.visited = [t.location], J(n), {
			state: n,
			fx: [{
				kind: "start",
				data: { location: t.location }
			}]
		};
	}
	if (t.type === "move") {
		if (e.phase !== "play" || !e.pawn) return { code: "games.blacksonata.errNotNow" };
		if (!T[e.pawn].includes(t.location)) return { code: "games.blacksonata.errNotAdjacent" };
		let n = e.config.difficulty === "training";
		if (n && e.usedMove) return { code: "games.blacksonata.errNotNow" };
		let r = structuredClone(e);
		return r.pawn = t.location, r.visited.includes(t.location) || r.visited.push(t.location), n ? r.usedMove = !0 : J(r), {
			state: r,
			fx: [{
				kind: "move",
				data: { to: t.location }
			}]
		};
	}
	if (t.type === "search") {
		if (e.phase !== "play" || !e.pawn) return { code: "games.blacksonata.errNotNow" };
		let t = e.config.difficulty === "training";
		if (t && e.usedSearch) return { code: "games.blacksonata.errNotNow" };
		let n = e.deck[0];
		if (n.kind !== "stealth") return { code: "games.blacksonata.errTopIsFog" };
		let r = structuredClone(e);
		if (r.fogDeck.length === 0) return K(r, "games.blacksonata.reasonFogEmpty");
		let i = E[n.card].location === r.pawn, a = r.fogDeck.shift();
		return r.deck[0] = {
			kind: "fog",
			routeIdx: n.routeIdx,
			fog: a
		}, t && (r.usedSearch = !0), i && se(r).length === 3 ? (r.phase = "hitChoice", r.searchHit = !0, {
			state: r,
			fx: [{
				kind: "search",
				data: {
					hit: !0,
					choice: !0
				}
			}]
		}) : de(r, {
			hit: i,
			clue: i ? q(r) : null
		});
	}
	if (t.type === "hitClue") {
		if (e.phase !== "hitChoice") return { code: "games.blacksonata.errNotNow" };
		let t = structuredClone(e), n = q(t);
		return t.searchHit = !1, de(t, {
			hit: !0,
			clue: n
		});
	}
	if (t.type === "hitConfront") {
		if (e.phase !== "hitChoice") return { code: "games.blacksonata.errNotNow" };
		let t = se(e);
		if (t.length !== 3) return { code: "games.blacksonata.errNeedThreePins" };
		let n = structuredClone(e), r = M(n.ladyId).traits.every((e) => t.includes(e));
		if (r) {
			let e = ue(n);
			n.result = {
				win: !0,
				reason: "games.blacksonata.reasonWin",
				score: e.total,
				breakdown: e
			};
		} else n.result = {
			win: !1,
			reason: "games.blacksonata.reasonWrongTraits",
			score: null,
			breakdown: null
		};
		return n.phase = "done", {
			state: n,
			fx: [{
				kind: "confront",
				data: {
					win: r,
					lady: n.ladyId
				}
			}]
		};
	}
	if (t.type === "fog") {
		if (e.phase !== "play") return { code: "games.blacksonata.errNotNow" };
		let t = e.config.difficulty === "training";
		if (t && e.usedSearch) return { code: "games.blacksonata.errNotNow" };
		let n = e.deck[0];
		if (n.kind !== "fog") return { code: "games.blacksonata.errTopIsStealth" };
		let r = structuredClone(e);
		if (r.fogDeck.length === 0) return K(r, "games.blacksonata.reasonFogEmpty");
		let i = n.fog, a = r.fogDeck.shift();
		r.deck[0] = {
			kind: "fog",
			routeIdx: n.routeIdx,
			fog: a
		}, t && (r.usedSearch = !0);
		let o = F(i), s = [{
			kind: "fog",
			data: {
				fog: i,
				effect: o
			}
		}], c = () => r.fogDeck.push(i);
		switch (o) {
			case "revealClue": return r.clueDeck.length === 0 ? K(r, "games.blacksonata.reasonCannotPerform") : (q(r), c(), J(r), {
				state: r,
				fx: s
			});
			case "discardReveal": return r.clueDeck.length === 0 ? K(r, "games.blacksonata.reasonCannotPerform") : (q(r), J(r), {
				state: r,
				fx: s
			});
			case "lookAhead": return r.peek = r.deck.slice(1, 6).map((e) => ce(r, e)), c(), J(r), {
				state: r,
				fx: s
			};
			case "advanceTwo": return c(), le(r, 2) ? (J(r), {
				state: r,
				fx: s
			}) : K(r, "games.blacksonata.reasonTimeout");
			case "discardFogTop": return r.fogDeck.length === 0 ? K(r, "games.blacksonata.reasonCannotPerform") : (r.fogDeck.shift(), c(), J(r), {
				state: r,
				fx: s
			});
			case "discardSelf": return J(r), {
				state: r,
				fx: s
			};
			case "shuffleLady": {
				r.clueDeck.push(r.ladyId);
				let e = { n: r.rngCursor };
				return r.clueDeck = G(r.clueDeck, r.seed, e), r.rngCursor = e.n, r.ladyId = r.clueDeck.shift(), c(), J(r), {
					state: r,
					fx: s
				};
			}
			case "moveAnywhere":
			case "moveNeighbour":
			case "swapClue": return o === "swapClue" && (r.clues.length === 0 || r.clueDeck.length === 0) ? K(r, "games.blacksonata.reasonCannotPerform") : (r.pendingFog = {
				fog: i,
				effect: o
			}, r.phase = "fogTarget", {
				state: r,
				fx: s
			});
		}
	}
	if (t.type === "fogTarget") {
		if (e.phase !== "fogTarget" || !e.pendingFog) return { code: "games.blacksonata.errNotNow" };
		let n = structuredClone(e), r = n.pendingFog;
		if (!r) return { code: "games.blacksonata.errNotNow" };
		let { fog: i, effect: a } = r;
		if (a === "swapClue") {
			if (!n.clues.includes(t.target)) return { code: "games.blacksonata.errBadTarget" };
			n.clues = n.clues.filter((e) => e !== t.target), n.clues.push(n.clueDeck.shift());
		} else {
			let e = t.target;
			if (!C.includes(e) || a === "moveNeighbour" && (!n.pawn || !T[n.pawn].includes(e))) return { code: "games.blacksonata.errBadTarget" };
			n.pawn = e, n.visited.includes(e) || n.visited.push(e);
		}
		return n.fogDeck.push(i), n.pendingFog = null, J(n), {
			state: n,
			fx: [{
				kind: "fogDone",
				data: {
					effect: a,
					target: t.target
				}
			}]
		};
	}
	if (e.phase !== "play") return { code: "games.blacksonata.errNotNow" };
	let n = structuredClone(e);
	return J(n), {
		state: n,
		fx: []
	};
}
function me(e) {
	let t = e.deck[0];
	return {
		public: {
			phase: e.phase,
			pawn: e.pawn,
			visited: e.visited,
			topCard: ce(e, t),
			deckSize: e.deck.length,
			countdown: e.countdown,
			countdownFromTop: e.deck.findIndex((e) => e.kind === "countdown"),
			fogCount: e.fogDeck.length,
			clueDeckCount: e.clueDeck.length,
			clues: [...e.clues],
			suitRevealed: e.suitRevealed ? M(e.ladyId).suit : null,
			deduction: k.filter((t) => e.deduction[t]).map((t) => ({
				trait: t,
				value: e.deduction[t]
			})),
			marks: [...e.marks],
			fleeLeft: e.fleeLeft,
			pendingFog: e.pendingFog?.effect ?? null,
			searchHit: e.searchHit,
			peek: e.peek ? [...e.peek] : null,
			usedMove: e.usedMove,
			usedSearch: e.usedSearch,
			difficulty: e.config.difficulty,
			routeLen: e.route.length,
			result: e.result ? {
				...e.result,
				ladyId: e.ladyId
			} : null
		},
		private: {}
	};
}
function he(e) {
	let t = e.players[0];
	return e.phase !== "done" || !e.result ? { phase: e.phase } : {
		phase: "done",
		winner: e.result.win ? [t] : [],
		ranking: [t],
		scores: e.result.win && e.result.score !== null ? { [t]: e.result.score } : void 0
	};
}
function ge(e) {
	return e.phase === "flee" || e.phase === "ladyMove" ? e.beatMs : null;
}
var _e = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: L,
	schemas: {
		action: ne,
		publicView: ae,
		privateView: oe,
		config: U
	},
	setup: fe,
	reduce: pe,
	viewFor: me,
	status: he,
	nextTickIn: ge
}, Y = 2048, X = 1511, ve = 74, Z = {
	clerkenwell: "games.blacksonata.locClerkenwell",
	blackfriars: "games.blacksonata.locBlackfriars",
	clink: "games.blacksonata.locClink",
	southwark: "games.blacksonata.locSouthwark",
	"london-bridge": "games.blacksonata.locLondonBridge",
	eastcheap: "games.blacksonata.locEastcheap",
	bishopsgate: "games.blacksonata.locBishopsgate",
	shoreditch: "games.blacksonata.locShoreditch",
	cripplegate: "games.blacksonata.locCripplegate",
	"st-pauls": "games.blacksonata.locStPauls",
	cornhill: "games.blacksonata.locCornhill"
}, ye = [
	["clerkenwell", "blackfriars"],
	["clerkenwell", "cripplegate"],
	["blackfriars", "clink"],
	["blackfriars", "st-pauls"],
	["clink", "southwark"],
	["southwark", "london-bridge"],
	["london-bridge", "eastcheap"],
	["eastcheap", "bishopsgate"],
	["eastcheap", "cornhill"],
	["bishopsgate", "shoreditch"],
	["bishopsgate", "cornhill"],
	["shoreditch", "cripplegate"],
	["cripplegate", "st-pauls"],
	["cripplegate", "cornhill"],
	["st-pauls", "cornhill"]
], be = {
	clerkenwell: {
		x: 0,
		y: -92
	},
	blackfriars: {
		x: -5,
		y: 122
	},
	clink: {
		x: 0,
		y: 115
	},
	southwark: {
		x: 0,
		y: 120
	},
	"london-bridge": {
		x: 0,
		y: 120
	},
	eastcheap: {
		x: -110,
		y: -98
	},
	bishopsgate: {
		x: -25,
		y: 115
	},
	shoreditch: {
		x: -25,
		y: 115
	},
	cripplegate: {
		x: 0,
		y: -100
	},
	"st-pauls": {
		x: -125,
		y: -80
	},
	cornhill: {
		x: 0,
		y: -95
	}
}, xe = {
	eastcheap: {
		x: -165,
		y: 10
	},
	"london-bridge": {
		x: 235,
		y: 5
	}
}, Q = (e) => ({
	x: w[e].x * Y / 100,
	y: w[e].y * X / 100
}), $ = (e, t, n) => Math.min(n, Math.max(t, e));
function Se({ view: e, locale: t, onLocation: n, initialZoom: i = 1.9 }) {
	let s = c(), l = a(null), u = a(/* @__PURE__ */ new Map()), d = a(0), f = a(0), [h, g] = o({
		w: 0,
		h: 0
	}), [_, v] = o(i), [y, b] = o(() => e.pawn ? Q(e.pawn) : {
		x: Y / 2,
		y: X / 2
	}), [x, S] = o(e.pawn);
	r(() => {
		let e = l.current;
		if (!e) return;
		let t = new ResizeObserver(() => g({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []), x !== e.pawn && (S(e.pawn), e.pawn && b(Q(e.pawn)));
	let C = Math.min((h.w || Y) / Y, (h.h || X) / X), E = Math.max(1.35, 44 / (148 * C)), D = C * Math.max(_, E), O = (h.w || Y) / D, k = (h.h || X) / D, A = {
		x: O >= Y ? Y / 2 : $(y.x, O / 2, Y - O / 2),
		y: k >= X ? X / 2 : $(y.y, k / 2, X - k / 2)
	}, j = A.x - O / 2, M = A.y - k / 2, N = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), u.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), u.current.size === 1 && (d.current = 0), u.current.size === 2) {
			let [e, t] = [...u.current.values()];
			f.current = Math.hypot(e.x - t.x, e.y - t.y), d.current = 99;
		}
	}, P = (e) => {
		let t = u.current.get(e.pointerId);
		if (t) {
			if (u.current.size === 1) {
				let n = e.clientX - t.x, r = e.clientY - t.y;
				d.current += Math.abs(n) + Math.abs(r), d.current >= 6 && b((e) => ({
					x: e.x - n / D,
					y: e.y - r / D
				}));
			} else {
				u.current.set(e.pointerId, {
					x: e.clientX,
					y: e.clientY
				});
				let [t, n] = [...u.current.values()], r = Math.hypot(t.x - n.x, t.y - n.y);
				f.current > 0 && v((e) => $(e * r / f.current, E, 4)), f.current = r, d.current = 99;
			}
			u.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
		}
	}, F = (e) => {
		u.current.delete(e.pointerId), f.current = 0;
	}, I = (e) => {
		if (d.current >= 8) {
			d.current = 0;
			return;
		}
		let t = e.currentTarget.getBoundingClientRect(), r = j + (e.clientX - t.left) / D, i = M + (e.clientY - t.top) / D, a = Object.keys(w).map((e) => ({
			id: e,
			distance: Math.hypot(Q(e).x - r, Q(e).y - i) * D
		})).sort((e, t) => e.distance - t.distance)[0];
		a?.distance <= Math.max(22, ve * D) && n(a.id);
	}, L = e.topCard.kind === "stealth" ? e.topCard.icon : null, R = /* @__PURE__ */ new Set();
	if (e.phase === "setup" || e.phase === "fogTarget" && e.pendingFog === "moveAnywhere") for (let e of Object.keys(w)) R.add(e);
	else if (e.phase === "play" && e.pawn && !(e.difficulty === "training" && e.usedMove) || e.phase === "fogTarget" && e.pendingFog === "moveNeighbour" && e.pawn) for (let t of T[e.pawn]) R.add(t);
	return /* @__PURE__ */ m("div", {
		ref: l,
		className: "bs-map",
		"aria-label": s("games.blacksonata.name"),
		children: [/* @__PURE__ */ m("svg", {
			className: "bs-map-svg",
			viewBox: `${j} ${M} ${O} ${k}`,
			role: "group",
			"aria-label": s("games.blacksonata.name"),
			onPointerDown: N,
			onPointerMove: P,
			onPointerUp: F,
			onPointerCancel: F,
			onClick: I,
			children: [
				/* @__PURE__ */ p("image", {
					href: "./games/blacksonata/map.webp",
					width: Y,
					height: X,
					preserveAspectRatio: "none"
				}),
				ye.map(([e, t]) => {
					let n = Q(e), r = Q(t);
					return /* @__PURE__ */ m("g", {
						className: "bs-route",
						pointerEvents: "none",
						children: [/* @__PURE__ */ p("line", {
							x1: n.x,
							y1: n.y,
							x2: r.x,
							y2: r.y,
							className: "bs-route-ink"
						}), /* @__PURE__ */ p("line", {
							x1: n.x,
							y1: n.y,
							x2: r.x,
							y2: r.y,
							className: "bs-route-gold"
						})]
					}, `${e}-${t}`);
				}),
				Object.keys(w).map((r, i) => {
					let { x: a, y: o } = Q(r), c = t === "en" ? xe[r] ?? be[r] : be[r], l = e.pawn === r, u = L !== null && w[r].icons.includes(L), d = e.marks.includes(r), f = e.visited.includes(r), h = R.has(r);
					return /* @__PURE__ */ m("g", {
						className: "bs-location",
						"data-legal": h || void 0,
						"data-candidate": u || void 0,
						"data-marked": d || void 0,
						"data-current": l || void 0,
						role: "button",
						tabIndex: 0,
						"aria-label": s(Z[r]),
						onKeyDown: (e) => {
							(e.key === "Enter" || e.key === " ") && (e.preventDefault(), n(r));
						},
						children: [
							/* @__PURE__ */ p("circle", {
								cx: a,
								cy: o,
								r: ve,
								fill: "transparent"
							}),
							u && /* @__PURE__ */ p("circle", {
								className: "bs-location-candidate",
								cx: a,
								cy: o,
								r: 104
							}),
							h && /* @__PURE__ */ p("circle", {
								className: "bs-location-legal",
								cx: a,
								cy: o,
								r: 92
							}),
							d && /* @__PURE__ */ p("path", {
								className: "bs-location-mark",
								d: `M${a - 50} ${o - 50}l100 100m0 -100l-100 100`
							}),
							/* @__PURE__ */ p("circle", {
								className: "bs-location-disc",
								cx: a,
								cy: o,
								r: 65,
								fill: l ? "#753e45" : f ? "#d5bd93" : "#f1e2c7"
							}),
							l ? /* @__PURE__ */ p("path", {
								className: "bs-location-pawn",
								d: `M${a} ${o - 31}l31 31-31 31-31-31z`
							}) : /* @__PURE__ */ p("text", {
								className: "bs-location-number",
								x: a,
								y: o + 17,
								textAnchor: "middle",
								children: String(i + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ p("text", {
								className: "bs-location-label",
								x: a + c.x,
								y: o + c.y,
								textAnchor: "middle",
								children: s(Z[r])
							})
						]
					}, r);
				})
			]
		}), /* @__PURE__ */ m("div", {
			className: "bs-map-controls",
			children: [
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => v((e) => $(e - .45, E, 4)),
					"aria-label": s("games.blacksonata.zoomOut"),
					children: "−"
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => v((e) => $(e + .45, E, 4)),
					"aria-label": s("games.blacksonata.zoomIn"),
					children: "+"
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => b(e.pawn ? Q(e.pawn) : {
						x: Y / 2,
						y: X / 2
					}),
					"aria-label": s("games.blacksonata.mapRecenter"),
					children: "◎"
				})
			]
		})]
	});
}
//#endregion
//#region src/games/blacksonata/clue-card.tsx
var Ce = {
	"mary-fitton": "games.blacksonata.clueMaryFitton",
	"elizabeth-vernon": "games.blacksonata.clueElizabethVernon",
	"emilia-lanier": "games.blacksonata.clueEmiliaLanier",
	"anne-whateley": "games.blacksonata.clueAnneWhateley",
	"winifred-burbage": "games.blacksonata.clueWinifredBurbage",
	"aline-florio": "games.blacksonata.clueAlineFlorio",
	"lucy-morgan": "games.blacksonata.clueLucyMorgan",
	"penelope-rich": "games.blacksonata.cluePenelopeRich",
	"anne-hathaway": "games.blacksonata.clueAnneHathaway",
	"jane-davenant": "games.blacksonata.clueJaneDavenant",
	"marie-mountjoy": "games.blacksonata.clueMarieMountjoy",
	"jacqueline-field": "games.blacksonata.clueJacquelineField"
}, we = {
	literary: "games.blacksonata.traitLiterary",
	musical: "games.blacksonata.traitMusical",
	amorous: "games.blacksonata.traitAmorous",
	children: "games.blacksonata.traitChildren",
	married: "games.blacksonata.traitMarried",
	court: "games.blacksonata.traitCourt",
	shakespeare: "games.blacksonata.traitShakespeare"
}, Te = {
	rose: "games.blacksonata.suitRose",
	oak: "games.blacksonata.suitOak",
	bluebell: "games.blacksonata.suitBluebell",
	acorn: "games.blacksonata.suitAcorn",
	thistle: "games.blacksonata.suitThistle",
	sage: "games.blacksonata.suitSage"
}, Ee = {
	rose: "#9b5459",
	oak: "#70805b",
	bluebell: "#6b85a3",
	acorn: "#a07e4f",
	thistle: "#647b79",
	sage: "#927386"
};
function De({ id: e, compact: t = !1, onClick: n }) {
	let r = c(), i = M(e), a = /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ m("div", {
			className: "bs-clue-ribbon",
			children: [/* @__PURE__ */ p("span", { children: "BLACK SONATA" }), /* @__PURE__ */ p("span", { children: r(Te[i.suit]) })]
		}),
		/* @__PURE__ */ p("div", {
			className: "bs-clue-traits",
			children: i.traits.map((e) => /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p("i", { "aria-hidden": !0 }), r(we[e])] }, e))
		}),
		/* @__PURE__ */ p("div", {
			className: "bs-clue-portrait",
			children: /* @__PURE__ */ p("img", {
				src: `./games/blacksonata/clue-${e}.webp`,
				alt: "",
				loading: "lazy"
			})
		}),
		/* @__PURE__ */ p("div", {
			className: "bs-clue-match",
			"aria-label": r("games.blacksonata.matchTitle"),
			children: O.map((e) => /* @__PURE__ */ m("span", {
				style: { color: Ee[e] },
				children: [
					/* @__PURE__ */ p("i", {
						"aria-hidden": !0,
						style: { background: Ee[e] }
					}),
					/* @__PURE__ */ p("span", { children: r(Te[e]) }),
					/* @__PURE__ */ p("b", { children: i.match[e] === "02" ? "0/2" : i.match[e] })
				]
			}, e))
		}),
		/* @__PURE__ */ p("strong", {
			className: "bs-clue-name",
			children: r(Ce[e])
		})
	] }), o = `${r(Ce[e])} · ${r(Te[i.suit])}`;
	return n ? /* @__PURE__ */ p("button", {
		type: "button",
		className: "bs-clue-card",
		"data-compact": t || void 0,
		"aria-label": o,
		onClick: n,
		children: a
	}) : /* @__PURE__ */ p("article", {
		className: "bs-clue-card",
		"data-compact": t || void 0,
		"aria-label": o,
		children: a
	});
}
//#endregion
//#region src/games/blacksonata/view-player.tsx
var Oe = "#753e45", ke = {
	1: "games.blacksonata.icon1",
	2: "games.blacksonata.icon2",
	3: "games.blacksonata.icon3",
	4: "games.blacksonata.icon4",
	5: "games.blacksonata.icon5",
	6: "games.blacksonata.icon6",
	7: "games.blacksonata.icon7"
}, Ae = {
	rose: "games.blacksonata.suitRose",
	oak: "games.blacksonata.suitOak",
	bluebell: "games.blacksonata.suitBluebell",
	acorn: "games.blacksonata.suitAcorn",
	thistle: "games.blacksonata.suitThistle",
	sage: "games.blacksonata.suitSage"
}, je = {
	literary: "games.blacksonata.traitLiterary",
	musical: "games.blacksonata.traitMusical",
	amorous: "games.blacksonata.traitAmorous",
	children: "games.blacksonata.traitChildren",
	married: "games.blacksonata.traitMarried",
	court: "games.blacksonata.traitCourt",
	shakespeare: "games.blacksonata.traitShakespeare"
}, Me = {
	"mary-fitton": "games.blacksonata.clueMaryFitton",
	"elizabeth-vernon": "games.blacksonata.clueElizabethVernon",
	"emilia-lanier": "games.blacksonata.clueEmiliaLanier",
	"anne-whateley": "games.blacksonata.clueAnneWhateley",
	"winifred-burbage": "games.blacksonata.clueWinifredBurbage",
	"aline-florio": "games.blacksonata.clueAlineFlorio",
	"lucy-morgan": "games.blacksonata.clueLucyMorgan",
	"penelope-rich": "games.blacksonata.cluePenelopeRich",
	"anne-hathaway": "games.blacksonata.clueAnneHathaway",
	"jane-davenant": "games.blacksonata.clueJaneDavenant",
	"marie-mountjoy": "games.blacksonata.clueMarieMountjoy",
	"jacqueline-field": "games.blacksonata.clueJacquelineField"
}, Ne = {
	revealClue: "games.blacksonata.fogRevealClue",
	moveAnywhere: "games.blacksonata.fogMoveAnywhere",
	lookAhead: "games.blacksonata.fogLookAhead",
	discardReveal: "games.blacksonata.fogDiscardReveal",
	swapClue: "games.blacksonata.fogSwapClue",
	moveNeighbour: "games.blacksonata.fogMoveNeighbour",
	advanceTwo: "games.blacksonata.fogAdvanceTwo",
	discardSelf: "games.blacksonata.fogDiscardSelf",
	discardFogTop: "games.blacksonata.fogDiscardFogTop",
	shuffleLady: "games.blacksonata.fogShuffleLady"
};
function Pe(e, t) {
	return e.kind === "stealth" ? t(ke[e.icon]) : e.kind === "fog" ? t("games.blacksonata.fogShort") : `${e.value}`;
}
function Fe({ public: e, send: t, review: n = !1 }) {
	let r = e, i = c(), a = s((e) => e.locale), [h, g] = o(null), [_, v] = o(null), [y, b] = o(null), x = r.clues.at(-1) ?? null, [S, C] = o(x), E = r.peek?.map((e) => `${e.kind}:${e.kind === "stealth" ? e.icon : e.kind === "countdown" ? e.value : ""}`).join("|") ?? "", [D, O] = o(E);
	x !== S && (C(x), x && (b(x), g("clues"))), E !== D && (O(E), E && g("peek"));
	let A = r.difficulty === "training", j = r.fogCount === 0, M = r.deduction.filter((e) => e.value === "yes"), N = n ? null : r.result, P = y && r.clues.includes(y) ? y : x, F = N?.score === null || N?.score === void 0 ? null : I.find((e) => N.score >= e.min) ?? I[I.length - 1], L = (e) => {
		if (r.phase === "done") {
			v(e), g("location");
			return;
		}
		if (r.phase === "setup") {
			t({
				type: "chooseStart",
				location: e
			});
			return;
		}
		if (r.phase === "fogTarget") {
			(r.pendingFog === "moveAnywhere" || r.pendingFog === "moveNeighbour" && r.pawn !== null && T[r.pawn].includes(e)) && t({
				type: "fogTarget",
				target: e
			});
			return;
		}
		if (r.phase === "play" && r.pawn && T[r.pawn].includes(e) && !(A && r.usedMove)) {
			t({
				type: "move",
				location: e
			});
			return;
		}
		t({
			type: "toggleMark",
			location: e
		});
	}, R = {
		setup: i("games.blacksonata.phaseSetup"),
		play: i("games.blacksonata.phasePlay"),
		hitChoice: i("games.blacksonata.phaseHitChoice"),
		fogTarget: i("games.blacksonata.phaseFogTarget"),
		flee: i("games.blacksonata.phaseFlee", { n: r.fleeLeft }),
		ladyMove: i("games.blacksonata.phaseLadyMove"),
		done: N ? i(N.reason) : ""
	}, z = [
		"setup",
		"play",
		"hitChoice",
		"fogTarget"
	].includes(r.phase), ee = r.phase === "fogTarget" && r.pendingFog ? i(Ne[r.pendingFog]) : j && r.phase === "play" ? i("games.blacksonata.dangerNoFog") : A && r.phase === "play" ? i("games.blacksonata.trainingNote") : void 0, te = r.topCard.kind !== "stealth" || A && r.usedSearch, B = r.topCard.kind !== "fog" || A && r.usedSearch, V = "bs-action", H = "bs-action bs-action--quiet";
	return /* @__PURE__ */ p(u, {
		adaptive: !0,
		className: "bs-screen",
		scroll: !1,
		banner: /* @__PURE__ */ p("div", {
			className: "bs-banner",
			children: /* @__PURE__ */ p(d, {
				tone: r.phase === "done" ? "done" : z ? "accent" : "info",
				accent: Oe,
				chip: `${i("games.blacksonata.countdownLabel")} ${r.countdown}`,
				text: R[r.phase],
				sub: ee
			})
		}),
		actionsHeight: "bs-action-slot h-16",
		actions: /* @__PURE__ */ m("div", {
			className: "bs-actions",
			children: [
				r.phase === "play" && /* @__PURE__ */ m(f, { children: [
					te ? /* @__PURE__ */ p("button", {
						type: "button",
						className: V,
						disabled: !0,
						children: i("games.blacksonata.actSearch")
					}) : j ? /* @__PURE__ */ p(l, {
						className: `${V} bs-action--danger`,
						label: i("games.blacksonata.actSearch"),
						confirmLabel: i("games.blacksonata.dangerConfirm"),
						ariaLabel: i("games.blacksonata.actSearch"),
						onConfirm: () => t({ type: "search" })
					}) : /* @__PURE__ */ p("button", {
						type: "button",
						className: V,
						onClick: () => t({ type: "search" }),
						children: i("games.blacksonata.actSearch")
					}),
					B ? /* @__PURE__ */ p("button", {
						type: "button",
						className: H,
						disabled: !0,
						children: i("games.blacksonata.actFog")
					}) : j ? /* @__PURE__ */ p(l, {
						className: `${H} bs-action--danger`,
						label: i("games.blacksonata.actFog"),
						confirmLabel: i("games.blacksonata.dangerConfirm"),
						ariaLabel: i("games.blacksonata.actFog"),
						onConfirm: () => t({ type: "fog" })
					}) : /* @__PURE__ */ p("button", {
						type: "button",
						className: H,
						onClick: () => t({ type: "fog" }),
						children: i("games.blacksonata.actFog")
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: H,
						onClick: () => t({ type: "pass" }),
						children: i("games.blacksonata.actPass")
					})
				] }),
				r.phase === "hitChoice" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: H,
					onClick: () => t({ type: "hitClue" }),
					children: i("games.blacksonata.actTakeClue")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: V,
					onClick: () => t({ type: "hitConfront" }),
					children: i("games.blacksonata.actConfront")
				})] }),
				r.phase === "fogTarget" && r.pendingFog === "swapClue" && r.clues.map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: H,
					onClick: () => t({
						type: "fogTarget",
						target: e
					}),
					children: i(Me[e])
				}, e))
			]
		}),
		children: /* @__PURE__ */ m("div", {
			className: "bs-game",
			"data-locale": a,
			"data-panel-open": h || N ? !0 : void 0,
			children: [
				/* @__PURE__ */ p(Se, {
					view: r,
					locale: a,
					onLocation: L
				}),
				/* @__PURE__ */ m("div", {
					className: "bs-decks",
					"aria-label": i("games.blacksonata.landmarkNow"),
					children: [
						r.peek ? /* @__PURE__ */ m("button", {
							type: "button",
							className: "bs-deck bs-deck--top bs-deck--button",
							onClick: () => g("peek"),
							children: [/* @__PURE__ */ p("span", { children: i("games.blacksonata.landmarkNow") }), /* @__PURE__ */ p("b", { children: Pe(r.topCard, i) })]
						}) : /* @__PURE__ */ m("div", {
							className: "bs-deck bs-deck--top",
							children: [/* @__PURE__ */ p("span", { children: i("games.blacksonata.landmarkNow") }), /* @__PURE__ */ p("b", { children: Pe(r.topCard, i) })]
						}),
						/* @__PURE__ */ m("div", {
							className: `bs-deck ${j ? "bs-deck--danger" : ""}`,
							children: [/* @__PURE__ */ p("span", { children: i("games.blacksonata.fogShort") }), /* @__PURE__ */ p("b", { children: r.fogCount })]
						}),
						/* @__PURE__ */ m("div", {
							className: "bs-deck",
							children: [/* @__PURE__ */ p("span", { children: i("games.blacksonata.clueDeckShort") }), /* @__PURE__ */ p("b", { children: r.clueDeckCount })]
						}),
						r.visited.length >= 11 && !r.suitRevealed && r.phase !== "done" ? /* @__PURE__ */ m("button", {
							type: "button",
							className: "bs-deck bs-deck--button",
							onClick: () => t({ type: "revealSuit" }),
							children: [/* @__PURE__ */ p("span", { children: i("games.blacksonata.keyShort") }), /* @__PURE__ */ p("b", { children: i("games.blacksonata.revealShort") })]
						}) : /* @__PURE__ */ m("div", {
							className: "bs-deck",
							children: [/* @__PURE__ */ p("span", { children: i("games.blacksonata.keyShort") }), /* @__PURE__ */ m("b", { children: [r.visited.length, "/11"] })]
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: "bs-evidence",
					children: [/* @__PURE__ */ m("button", {
						type: "button",
						className: "bs-evidence-button bs-evidence-button--clue",
						onClick: () => g("clues"),
						children: [
							/* @__PURE__ */ m("span", {
								className: "bs-evidence-title",
								children: [
									i("games.blacksonata.cluesTitle"),
									" · ",
									r.clues.length
								]
							}),
							x ? /* @__PURE__ */ p("img", {
								className: "bs-evidence-preview",
								src: `./games/blacksonata/clue-${x}.webp`,
								alt: ""
							}) : /* @__PURE__ */ p("span", {
								className: "bs-evidence-empty",
								"aria-hidden": !0,
								children: "?"
							}),
							r.suitRevealed && /* @__PURE__ */ p("span", {
								className: "bs-suit-reveal",
								children: i(Ae[r.suitRevealed])
							})
						]
					}), /* @__PURE__ */ m("button", {
						type: "button",
						className: "bs-evidence-button bs-evidence-button--deduction",
						onClick: () => g("deduction"),
						children: [
							/* @__PURE__ */ p("span", {
								className: "bs-evidence-title",
								children: i("games.blacksonata.deductionTitle")
							}),
							/* @__PURE__ */ m("span", {
								className: "bs-evidence-count",
								children: [M.length, "/3"]
							}),
							/* @__PURE__ */ p("span", {
								className: "bs-evidence-pins",
								"aria-hidden": !0,
								children: [
									0,
									1,
									2
								].map((e) => /* @__PURE__ */ p("span", {
									"data-on": M[e] ? !0 : void 0,
									children: M[e] ? "✓" : "?"
								}, e))
							})
						]
					})]
				}),
				(h || N) && /* @__PURE__ */ m("div", {
					className: "bs-panel",
					role: "dialog",
					"aria-modal": "false",
					"aria-label": i(N ? "games.blacksonata.ladyReveal" : h === "clues" ? "games.blacksonata.cluesTitle" : h === "deduction" ? "games.blacksonata.deductionTitle" : "games.blacksonata.peekTitle"),
					children: [/* @__PURE__ */ m("div", {
						className: "bs-panel-head",
						children: [/* @__PURE__ */ p("span", { children: N ? i(N.reason) : h === "location" && _ ? i(Z[_]) : h === "clues" ? i("games.blacksonata.cluesTitle") : h === "deduction" ? `${i("games.blacksonata.deductionTitle")} · ${M.length}/3` : i("games.blacksonata.peekTitle") }), !N && /* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": i("games.blacksonata.closePanel"),
							onClick: () => g(null),
							children: "×"
						})]
					}), /* @__PURE__ */ p("div", {
						className: "bs-panel-body",
						"data-panel": h ?? void 0,
						children: N ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(De, { id: N.ladyId }), N.score !== null && /* @__PURE__ */ m("div", {
							className: "bs-score",
							children: [/* @__PURE__ */ m("b", { children: [
								N.score,
								" · ",
								F && i(F.key)
							] }), N.breakdown && /* @__PURE__ */ m("span", { children: [
								i("games.blacksonata.bdAbove"),
								" ",
								N.breakdown.aboveCountdown,
								" · ",
								i("games.blacksonata.bdFog"),
								" ",
								N.breakdown.fogLeft * 2
							] })]
						})] }) : h === "location" && _ ? /* @__PURE__ */ m("div", {
							className: "flex flex-col gap-3",
							children: [w[_].icons.map((e) => /* @__PURE__ */ p("p", { children: i(ke[e]) }, e)), /* @__PURE__ */ p("p", { children: T[_].map((e) => i(Z[e])).join(" · ") })]
						}) : h === "clues" ? /* @__PURE__ */ m(f, { children: [P ? /* @__PURE__ */ p(De, { id: P }) : /* @__PURE__ */ p("p", { children: i("games.blacksonata.clueEmpty") }), /* @__PURE__ */ p("div", {
							className: "bs-clue-picker",
							children: r.clues.map((e) => /* @__PURE__ */ p("button", {
								type: "button",
								"data-selected": P === e || void 0,
								onClick: () => b(e),
								children: i(Me[e])
							}, e))
						})] }) : h === "deduction" ? /* @__PURE__ */ p("div", {
							className: "bs-deduction-grid",
							children: k.map((e) => {
								let n = r.deduction.find((t) => t.trait === e)?.value ?? null;
								return /* @__PURE__ */ m("button", {
									type: "button",
									disabled: r.phase === "done",
									"data-state": n ?? void 0,
									onClick: () => t({
										type: "setDeduction",
										trait: e,
										value: n === null ? "yes" : n === "yes" ? "no" : null
									}),
									children: [/* @__PURE__ */ p("b", { children: n === "yes" ? "✓" : n === "no" ? "×" : "?" }), i(je[e])]
								}, e);
							})
						}) : h === "peek" && r.peek ? /* @__PURE__ */ p("div", {
							className: "bs-peek-cards",
							children: r.peek.map((e, t) => /* @__PURE__ */ p("span", { children: Pe(e, i) }, t))
						}) : null
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/games/blacksonata/endgame-review.tsx
function Ie({ board: e, renderResult: t, ...n }) {
	let s = c(), [l, u] = o(!0), [d, f] = o(null), g = a(null), y = a(null), b = a(null);
	r(() => {
		if (!d) return;
		b.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let x = (e) => {
		f(null), u(e), requestAnimationFrame(() => (e ? g : y).current?.focus({ preventScroll: !0 }));
	}, S = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), C = {
		...n,
		...S
	};
	return /* @__PURE__ */ m("div", {
		className: "blacksonata-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ p("div", {
				className: "blacksonata-endgame-board",
				inert: l,
				children: e
			}),
			/* @__PURE__ */ p("div", {
				className: "blacksonata-endgame-overlay",
				hidden: !l,
				children: /* @__PURE__ */ m("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), x(!1));
					},
					className: "blacksonata-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ m("header", {
							className: "blacksonata-endgame-heading",
							children: [/* @__PURE__ */ m("div", {
								className: "blacksonata-endgame-brand",
								children: [/* @__PURE__ */ p("span", {
									"aria-hidden": "true",
									children: L.icon
								}), s(L.nameKey)]
							}), /* @__PURE__ */ p("button", {
								type: "button",
								ref: g,
								className: "btn-quiet",
								"aria-label": s("games.blacksonata.reviewHide"),
								title: s("games.blacksonata.reviewHide"),
								onClick: () => x(!1),
								children: /* @__PURE__ */ p(_, { size: 19 })
							})]
						}),
						/* @__PURE__ */ p("div", {
							className: "blacksonata-endgame-result",
							inert: d !== null,
							children: t(C)
						}),
						d && /* @__PURE__ */ m("div", {
							className: "blacksonata-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ p("button", {
								type: "button",
								ref: b,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.blacksonata.reviewConfirmAgain" : "games.blacksonata.reviewConfirmLobby")
							}), /* @__PURE__ */ p("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), g.current?.focus({ preventScroll: !0 });
								},
								children: s("games.blacksonata.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "blacksonata-endgame-toolbar",
				hidden: l,
				children: /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-base",
					ref: y,
					onClick: () => x(!0),
					children: [
						/* @__PURE__ */ p(v, { size: 18 }),
						s("games.blacksonata.reviewShow"),
						/* @__PURE__ */ p(h, { size: 18 })
					]
				})
			})
		]
	});
}
function Le({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: l, rows: u, renderRowExtra: d, summary: h, navigation: v, content: x, afterRanking: S, scoreUnit: C, rankOf: w }) {
	let T = c(), E = s((e) => e.locale), [D, O] = o({}), k = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? y(n, E) : e;
	}, A = (t, n) => w?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), j = e.ranking.some((t) => e.scores?.[t] !== void 0), M = (t, n) => /* @__PURE__ */ m("div", {
		className: "blacksonata-score-identity",
		children: [
			/* @__PURE__ */ m("span", {
				className: "blacksonata-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ p("span", {
					"aria-label": T("games.blacksonata.reviewWinner"),
					children: "♛ "
				}), j && A(t, n)]
			}),
			/* @__PURE__ */ m("span", {
				className: "blacksonata-score-name",
				children: [k(t), t === r && /* @__PURE__ */ p("small", { children: T("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ m("small", {
				className: "blacksonata-score-autopilot",
				children: [
					/* @__PURE__ */ p(g, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), N = (t) => e.ranking.map((n) => /* @__PURE__ */ p("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ m("div", {
		className: "blacksonata-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ p(b, {}),
			v,
			/* @__PURE__ */ m("div", {
				className: "blacksonata-score-body",
				children: [
					h && /* @__PURE__ */ p("div", {
						className: "blacksonata-score-summary",
						children: h
					}),
					i !== void 0 && /* @__PURE__ */ p("p", {
						className: "blacksonata-score-hints",
						children: T("session.hint.usedCount", { n: i })
					}),
					x ?? (u?.length ? /* @__PURE__ */ p("div", {
						className: "blacksonata-score-table-scroll",
						children: /* @__PURE__ */ m("table", {
							className: "blacksonata-score-table",
							"aria-label": T(L.nameKey),
							children: [
								/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { scope: "col" }), /* @__PURE__ */ p(f, { children: e.ranking.map((t, n) => /* @__PURE__ */ p("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: M(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ p("tbody", { children: u.map((e, t) => /* @__PURE__ */ m(n, { children: [/* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ m("button", {
										type: "button",
										"aria-expanded": !!D[t],
										onClick: () => O((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ p(_, { size: 15 }), e.label]
									}) : e.label
								}), N(e)] }), D[t] && e.details?.map((e, t) => /* @__PURE__ */ m("tr", {
									className: "blacksonata-score-sub",
									children: [/* @__PURE__ */ p("th", {
										scope: "row",
										children: e.label
									}), N(e)]
								}, t))] }, t)) }),
								j && /* @__PURE__ */ p("tfoot", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
									scope: "row",
									children: T("games.blacksonata.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ p("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ p("ol", {
						className: "blacksonata-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ m("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ m("div", {
								className: "blacksonata-score-rankline",
								children: [M(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ m("strong", {
									className: "blacksonata-score-points",
									children: [e.scores[t], C && /* @__PURE__ */ p("small", { children: C })]
								})]
							}), d?.(t)]
						}, t))
					})),
					S,
					!!u?.length && d && /* @__PURE__ */ p("div", {
						className: "blacksonata-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ p("summary", { children: k(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ m("footer", {
				className: "blacksonata-score-actions",
				children: [
					l && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet",
						onClick: l,
						children: T("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: T("session.result.playAgain")
					}),
					!a && !l && /* @__PURE__ */ p("p", { children: T("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/blacksonata/game-over.tsx
function Re(e) {
	let { public: t } = e, n = c(), r = s((e) => e.locale), i = t.result;
	if (!i) return null;
	let a = i.score === null ? null : I.find((e) => i.score >= e.min) ?? I[I.length - 1];
	return /* @__PURE__ */ p(Le, {
		...e,
		content: /* @__PURE__ */ p("div", {
			className: "bs-over bs-result-report",
			"data-locale": r,
			"data-win": i.win || void 0,
			children: /* @__PURE__ */ m("div", {
				className: "bs-over-sheet",
				children: [
					/* @__PURE__ */ m("header", {
						className: "bs-over-head",
						children: [
							/* @__PURE__ */ p("span", { children: "BLACK SONATA" }),
							/* @__PURE__ */ p("h1", { children: n(i.win ? "games.blacksonata.overWin" : "games.blacksonata.overLose") }),
							!i.win && /* @__PURE__ */ p("p", { children: n(i.reason) })
						]
					}),
					/* @__PURE__ */ p("div", {
						className: "bs-over-card",
						children: /* @__PURE__ */ p(De, { id: i.ladyId })
					}),
					i.score !== null && /* @__PURE__ */ m("div", {
						className: "bs-over-meta",
						children: [/* @__PURE__ */ p("strong", { children: i.score }), /* @__PURE__ */ p("span", { children: a && n(a.key) })]
					})
				]
			})
		})
	});
}
function ze(e) {
	return /* @__PURE__ */ p(Ie, {
		...e,
		board: /* @__PURE__ */ p(Fe, {
			review: !0,
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ p(Re, { ...e })
	});
}
//#endregion
//#region src/games/blacksonata/options.tsx
var Be = {
	training: "games.blacksonata.diffTraining",
	easy: "games.blacksonata.diffEasy",
	standard: "games.blacksonata.diffStandard",
	advanced: "games.blacksonata.diffAdvanced",
	expert: "games.blacksonata.diffExpert"
}, Ve = {
	random: "games.blacksonata.routeRandom",
	"very-easy": "games.blacksonata.routeVeryEasy",
	easy: "games.blacksonata.routeEasy",
	moderate: "games.blacksonata.routeModerate",
	hard: "games.blacksonata.routeHard"
}, He = {
	random: "games.blacksonata.moveRandom",
	moves: "games.blacksonata.moveMoves",
	may: "games.blacksonata.moveMay"
};
function Ue({ value: e, onChange: t }) {
	let n = c(), r = U.safeParse(e), i = r.success ? r.data : U.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ p(S, {
				title: n("games.blacksonata.optDifficulty"),
				columns: 3,
				children: B.map((e) => /* @__PURE__ */ p(x, {
					name: "blacksonata-difficulty",
					value: e,
					checked: i.difficulty === e,
					label: n(Be[e]),
					accent: L.accent,
					onChange: () => t({
						...i,
						difficulty: e
					})
				}, e))
			}),
			/* @__PURE__ */ p(S, {
				title: n("games.blacksonata.optRoute"),
				columns: 3,
				children: V.map((e) => /* @__PURE__ */ p(x, {
					name: "blacksonata-route",
					value: e,
					checked: i.route === e,
					label: n(Ve[e]),
					accent: L.accent,
					onChange: () => t({
						...i,
						route: e
					})
				}, e))
			}),
			/* @__PURE__ */ p(S, {
				title: n("games.blacksonata.optMovement"),
				columns: 3,
				children: H.map((e) => /* @__PURE__ */ p(x, {
					name: "blacksonata-movement",
					value: e,
					checked: i.movement === e,
					label: n(He[e]),
					accent: L.accent,
					onChange: () => t({
						...i,
						movement: e
					})
				}, e))
			}),
			i.difficulty === "expert" && /* @__PURE__ */ p(S, {
				title: n("games.blacksonata.optExpertFog"),
				columns: 3,
				children: [
					1,
					2,
					3,
					4,
					5,
					6,
					7,
					8,
					9,
					10
				].map((e) => /* @__PURE__ */ p(x, {
					name: "blacksonata-expert-fog",
					value: String(e),
					checked: i.expertFog === e,
					label: e,
					accent: L.accent,
					onChange: () => t({
						...i,
						expertFog: e
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/blacksonata/entry.tsx
var We = {
	definition: _e,
	View: Fe,
	OverView: ze,
	Options: Ue,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "黑色奏鸣曲",
			desc: "单人隐匿推理:在雾都伦敦追踪莎士比亚笔下的黑夫人",
			rules: "目标:推断黑夫人的三个特征,与她同处一地时搜索命中,完成指认。\n准备:按所选难度暗抽一条隐匿路线组成牌堆并随机切牌;随机指定黑夫人;点选起点落子。\n流程:每回合黑夫人先移动,顶卡卡背的地标暴露她当前所在地点的特征。\n随后从四个行动中选择一个:\n· 移动:棋子走到相邻地点;首次进入取走该地点的钥匙。\n· 搜索:从雾牌堆供一张卡滑入顶卡下;黑夫人在此地则获得一张线索卡。\n· 无论命中与否,该顶卡移出游戏,黑夫人按你持有的线索数逃逸。\n· 雾卡:顶为雾卡时可供出一张雾卡,翻开执行效果,用毕置雾牌堆底。\n· 跳过:本回合不行动。\n线索卡:左侧是卡面人物的三个特征;右侧按黑夫人花色给出她命中的特征数。\n其中 0/2 表示零个或两个,需要结合多张线索卡排除歧义。\n对质:用演绎标记钉死三个特征后,搜索命中时可改为指认;全对获胜,有错落败。\n失败:倒计时卡第三次浮到顶(简单模式第四次)、雾牌堆供不出卡、雾卡效果无法执行或指认错误。\n计分:倒计时上方卡数,加上倒计时值乘路线卡数,加上雾牌堆余量的两倍,再加难度修正;训练档减半。",
			locClerkenwell: "克拉肯",
			locBlackfriars: "黑衣修士",
			locClink: "克林克",
			locSouthwark: "萨瑟克",
			locLondonBridge: "伦敦桥",
			locEastcheap: "东市街",
			locBishopsgate: "主教门",
			locShoreditch: "肖迪奇",
			locCripplegate: "跛子门",
			locStPauls: "圣保罗",
			locCornhill: "玉米山",
			suitRose: "玫瑰",
			suitOak: "橡叶",
			suitBluebell: "蓝铃花",
			suitAcorn: "橡果",
			suitThistle: "蓟花",
			suitSage: "鼠尾草",
			traitLiterary: "文学",
			traitMusical: "音乐",
			traitAmorous: "风流",
			traitChildren: "子女",
			traitMarried: "已婚",
			traitCourt: "宫廷",
			traitShakespeare: "莎翁",
			icon1: "酒馆",
			icon2: "居所",
			icon3: "商业",
			icon4: "教堂",
			icon5: "河岸",
			icon6: "乡野",
			icon7: "剧场",
			clueMaryFitton: "玛丽·菲顿",
			clueElizabethVernon: "伊丽莎白·弗农",
			clueEmiliaLanier: "艾米莉亚·拉尼尔",
			clueAnneWhateley: "安妮·惠特利",
			clueWinifredBurbage: "威妮弗雷德·伯比奇",
			clueAlineFlorio: "艾琳·弗洛里奥",
			clueLucyMorgan: "露西·摩根",
			cluePenelopeRich: "佩内洛普·里奇",
			clueAnneHathaway: "安妮·海瑟薇",
			clueJaneDavenant: "简·达文南特",
			clueMarieMountjoy: "玛丽·芒乔伊",
			clueJacquelineField: "杰奎琳·菲尔德",
			fogRevealClue: "展示一张新线索卡",
			fogMoveAnywhere: "棋子移到任一地点",
			fogLookAhead: "偷看接下来五张卡的卡背",
			fogDiscardReveal: "弃掉此雾卡,展示一张新线索卡",
			fogSwapClue: "弃一张已持线索,从线索牌堆抽一张",
			fogMoveNeighbour: "棋子移到相邻地点",
			fogAdvanceTwo: "隐匿牌堆推进两张",
			fogDiscardSelf: "弃掉此雾卡",
			fogDiscardFogTop: "弃掉雾牌堆顶一张卡",
			fogShuffleLady: "黑夫人卡洗入线索牌堆并重抽一张",
			phaseSetup: "选择起点",
			phasePlay: "追踪黑夫人",
			phaseLadyMove: "黑夫人移动中",
			phaseFlee: "逃逸中 · {{n}}",
			phaseHitChoice: "命中 · 线索或对质",
			phaseFogTarget: "选择目标",
			actSearch: "搜索黑夫人",
			actFog: "使用雾卡",
			actPass: "跳过",
			actTakeClue: "拿取线索",
			actConfront: "对质指认",
			landmarkNow: "当前地标",
			fogShort: "雾牌",
			clueDeckShort: "线索堆",
			keyShort: "钥匙",
			revealShort: "翻花色",
			fogDeckLabel: "雾牌堆 {{n}}",
			clueDeckLabel: "线索堆 {{n}}",
			countdownLabel: "倒计时",
			keysLabel: "钥匙 {{n}}/11",
			cluesTitle: "已持线索",
			clueEmpty: "尚无线索",
			matchTitle: "命中特征数(按黑夫人花色)",
			matchAmbiguous: "0 或 2",
			deductionTitle: "演绎标记",
			deductionHint: "点按切换:确认 → 排除 → 清除;确认最多三个",
			marksHint: "追踪标记:点地点打上或取消",
			peekTitle: "接下来五张卡背",
			zoomIn: "放大地图",
			zoomOut: "缩小地图",
			mapRecenter: "回到当前位置",
			closePanel: "关闭",
			revealSuit: "翻开钥匙下的同花色卡",
			trainingNote: "训练：移动与搜索各一次",
			dangerNoFog: "雾牌耗尽 · 行动将落败",
			dangerConfirm: "确认执行(将判负)",
			searchHitLabel: "命中!获得线索卡",
			searchMissLabel: "她不在这里",
			fogTargetAnywhere: "点选任一地点落子",
			fogTargetNeighbour: "点选一个相邻地点落子",
			fogTargetSwap: "点选一张已持线索弃掉",
			ladyReveal: "黑夫人是",
			overWin: "真相大白",
			overLose: "迷雾未散",
			scoreTitle: "计分明细",
			bdAbove: "倒计时上方卡数",
			bdCountdown: "倒计时值 × 路线卡数",
			bdFog: "雾牌堆余量 × 2",
			bdAdjust: "难度修正",
			bdHalved: "训练档减半",
			rankChimney: "扫烟囱工",
			rankGolden: "金童玉女",
			rankFair: "美少年·美少女",
			rankBard: "不朽诗人",
			reasonWin: "指认正确,真相大白",
			reasonWrongTraits: "指认错误:特征不符",
			reasonTimeout: "倒计时归零,黑夫人消失在雾中",
			reasonFogEmpty: "雾牌堆耗尽,无法掩护行动",
			reasonCannotPerform: "雾卡效果无法执行",
			optDifficulty: "难度",
			diffTraining: "训练",
			diffEasy: "简单",
			diffStandard: "标准",
			diffAdvanced: "进阶",
			diffExpert: "专家",
			optRoute: "路线难度",
			routeRandom: "随机",
			routeVeryEasy: "极易",
			routeEasy: "容易",
			routeModerate: "中等",
			routeHard: "困难",
			optMovement: "移动规则",
			moveRandom: "随机",
			moveMoves: "每回合必动",
			moveMay: "可能不动",
			optExpertFog: "开局弃置雾卡数",
			errNotNow: "现在不能这么做",
			errNotAdjacent: "只能移动到相邻地点",
			errTopIsFog: "隐匿牌堆顶是雾卡,无法搜索",
			errTopIsStealth: "隐匿牌堆顶不是雾卡",
			errPinLimit: "最多钉死三个特征",
			errBadTarget: "这个目标不可选",
			errNeedThreePins: "需要先用演绎标记钉死三个特征"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Black Sonata",
			desc: "A solo hidden-movement deduction: track Shakespeare’s Dark Lady through foggy London",
			rules: "Goal: deduce the Dark Lady’s three traits, catch her with a search at her location, and confront her.\nSetup: a hidden route is drawn for the chosen difficulty and cut; the Dark Lady is assigned; pick a starting location.\nPlay: each round the Lady moves first; the landmark on the top card’s back marks a feature of her location.\nThen choose one of four actions:\n· Move: move your pawn to an adjoining location; first entry claims that location’s key.\n· Search: slide a fog card under the top card; if the Lady is here you gain a clue card.\n· Hit or miss, that top card leaves the game and the Lady flees one card per clue you hold.\n· Fog: when a fog card is on top, slide one in, resolve its effect, then place it under the fog deck.\n· Pass: do nothing this turn.\nClues: the left side lists the pictured lady’s three traits; the right side gives, keyed by the Dark Lady’s suit, how many she shares.\nA 0/2 entry means zero or two; combine several clues to resolve the ambiguity.\nConfront: with three traits pinned by deduction tokens, a successful search may accuse her; all correct wins, any error loses.\nDefeat: the countdown card surfaces a third time (fourth on Easy), the fog deck runs dry, a fog effect cannot be resolved, or a wrong accusation.\nScore: cards above the countdown, plus its value times the route length, plus twice the fog deck remainder, plus the difficulty modifier; halved on Training.",
			locClerkenwell: "Clerkenwell",
			locBlackfriars: "Blackfriars",
			locClink: "The Clink",
			locSouthwark: "Southwark",
			locLondonBridge: "London Bridge",
			locEastcheap: "Eastcheap",
			locBishopsgate: "Bishopsgate",
			locShoreditch: "Shoreditch",
			locCripplegate: "Cripplegate",
			locStPauls: "St Paul’s",
			locCornhill: "Cornhill",
			suitRose: "Rose",
			suitOak: "Oak",
			suitBluebell: "Bluebell",
			suitAcorn: "Acorn",
			suitThistle: "Thistle",
			suitSage: "Sage",
			traitLiterary: "Literary",
			traitMusical: "Musical",
			traitAmorous: "Amorous",
			traitChildren: "Children",
			traitMarried: "Married",
			traitCourt: "Court",
			traitShakespeare: "Shakespeare",
			icon1: "Tavern",
			icon2: "House",
			icon3: "Market",
			icon4: "Church",
			icon5: "River",
			icon6: "Rural",
			icon7: "Theatre",
			clueMaryFitton: "Mary Fitton",
			clueElizabethVernon: "Elizabeth Vernon",
			clueEmiliaLanier: "Emilia Lanier",
			clueAnneWhateley: "Anne Whateley",
			clueWinifredBurbage: "Winifred Burbage",
			clueAlineFlorio: "Aline Florio",
			clueLucyMorgan: "Lucy Morgan",
			cluePenelopeRich: "Penelope Rich",
			clueAnneHathaway: "Anne Hathaway",
			clueJaneDavenant: "Jane Davenant",
			clueMarieMountjoy: "Marie Mountjoy",
			clueJacquelineField: "Jacqueline Field",
			fogRevealClue: "Reveal a new clue card",
			fogMoveAnywhere: "Move your pawn to any location",
			fogLookAhead: "Peek at the backs of the next five cards",
			fogDiscardReveal: "Discard this fog card and reveal a new clue card",
			fogSwapClue: "Discard a clue you hold and draw a new one",
			fogMoveNeighbour: "Move your pawn to an adjoining location",
			fogAdvanceTwo: "Advance the stealth deck by two cards",
			fogDiscardSelf: "Discard this fog card",
			fogDiscardFogTop: "Discard the top card of the fog deck",
			fogShuffleLady: "Shuffle the Dark Lady card into the clue deck and draw a new one",
			phaseSetup: "Choose a start",
			phasePlay: "Track the Dark Lady",
			phaseLadyMove: "The Dark Lady moves",
			phaseFlee: "Fleeing · {{n}}",
			phaseHitChoice: "Hit · clue or confront",
			phaseFogTarget: "Choose a target",
			actSearch: "Search",
			actFog: "Use Fog",
			actPass: "Pass",
			actTakeClue: "Take the clue",
			actConfront: "Confront her",
			landmarkNow: "Landmark",
			fogShort: "Fog",
			clueDeckShort: "Clue deck",
			keyShort: "Keys",
			revealShort: "Reveal suit",
			fogDeckLabel: "Fog deck {{n}}",
			clueDeckLabel: "Clue deck {{n}}",
			countdownLabel: "Countdown",
			keysLabel: "Keys {{n}}/11",
			cluesTitle: "Clues in hand",
			clueEmpty: "No clues yet",
			matchTitle: "Shared traits (by the Dark Lady’s suit)",
			matchAmbiguous: "0 or 2",
			deductionTitle: "Deduction tokens",
			deductionHint: "Tap to cycle: confirm → rule out → clear; at most three confirmed",
			marksHint: "Tracking tokens: tap a location to mark or unmark",
			peekTitle: "Backs of the next five cards",
			zoomIn: "Zoom map in",
			zoomOut: "Zoom map out",
			mapRecenter: "Return to current location",
			closePanel: "Close",
			revealSuit: "Reveal the suit card under the keys",
			trainingNote: "Training: move and search once each",
			dangerNoFog: "No fog left · action will lose",
			dangerConfirm: "Confirm (you will lose)",
			searchHitLabel: "Hit! Gained a clue card",
			searchMissLabel: "She is not here",
			fogTargetAnywhere: "Tap any location to move there",
			fogTargetNeighbour: "Tap an adjoining location to move there",
			fogTargetSwap: "Tap a clue you hold to discard it",
			ladyReveal: "The Dark Lady is",
			overWin: "Case solved",
			overLose: "Lost in the fog",
			scoreTitle: "Score breakdown",
			bdAbove: "Cards above the countdown",
			bdCountdown: "Countdown value × route length",
			bdFog: "Fog cards left × 2",
			bdAdjust: "Difficulty adjustment",
			bdHalved: "Halved on Training",
			rankChimney: "Chimney-sweeper",
			rankGolden: "Golden lad/girl",
			rankFair: "Fair youth/maid",
			rankBard: "Immortal bard",
			reasonWin: "Correct accusation — the truth is out",
			reasonWrongTraits: "Wrong accusation: traits did not match",
			reasonTimeout: "Time ran out; the Lady vanishes into the fog",
			reasonFogEmpty: "The fog deck ran dry and could not cover you",
			reasonCannotPerform: "The fog effect could not be resolved",
			optDifficulty: "Difficulty",
			diffTraining: "Training",
			diffEasy: "Easy",
			diffStandard: "Standard",
			diffAdvanced: "Advanced",
			diffExpert: "Expert",
			optRoute: "Route difficulty",
			routeRandom: "Random",
			routeVeryEasy: "Very easy",
			routeEasy: "Easy",
			routeModerate: "Moderate",
			routeHard: "Hard",
			optMovement: "Movement rule",
			moveRandom: "Random",
			moveMoves: "Moves every turn",
			moveMay: "May not move",
			optExpertFog: "Fog cards discarded at setup",
			errNotNow: "You cannot do that right now",
			errNotAdjacent: "You can only move to an adjoining location",
			errTopIsFog: "A fog card is on top; searching is impossible",
			errTopIsStealth: "The top of the stealth deck is not a fog card",
			errPinLimit: "At most three traits can be pinned",
			errBadTarget: "That target is not available",
			errNeedThreePins: "Pin three traits with deduction tokens first"
		}
	}
};
//#endregion
export { We as default };
