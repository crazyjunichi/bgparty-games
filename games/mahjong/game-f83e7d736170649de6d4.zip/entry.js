import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useState as r, useSyncExternalStore as i } from "react";
import { botAvatarOf as a } from "@bgparty/sdk/lobby";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as s, useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { AVATARS as d } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { Flash as g, Floater as _ } from "@bgparty/sdk/fx/primitives";
import { playSettle as v } from "@bgparty/sdk/sfx";
import { Confetti as y } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as b, OptionSection as x, OptionSwitch as ee } from "@bgparty/sdk/ui/game-options";
function S(e) {
	return e >> 2;
}
function C(e) {
	return e < 9 ? "m" : e < 18 ? "p" : e < 27 ? "s" : null;
}
function w(e) {
	return e < 27 ? e % 9 + 1 : 0;
}
function T(e) {
	return e >= 34;
}
function E(e) {
	return e >= 27 && e < 34;
}
function te(e) {
	if (E(e)) return !0;
	let t = w(e);
	return e < 27 && (t === 1 || t === 9);
}
function D(e) {
	let t = w(e);
	return e < 27 && (t === 1 || t === 9);
}
function O(e) {
	return e >= 27 && e <= 30 ? e - 27 : -1;
}
function k(e) {
	return e >= 31 && e <= 33;
}
function ne(e, t) {
	return e * 4 + t;
}
function A(e) {
	let t = [];
	for (let { face: n, copies: r } of e) for (let e = 0; e < r; e += 1) t.push(ne(n, e));
	return t;
}
function j() {
	let e = [];
	for (let t = 0; t < 34; t += 1) e.push({
		face: t,
		copies: 4
	});
	return e;
}
function M() {
	let e = [];
	for (let t = 0; t < 27; t += 1) e.push({
		face: t,
		copies: 4
	});
	return e;
}
function N(e) {
	let t = Array(42).fill(0);
	for (let n of e) t[n] += 1;
	return t;
}
//#endregion
//#region src/games/mahjong/core/claims.ts
function re(e, t) {
	if (t >= 27) return [];
	let n = [], r = t % 9, i = t - r, a = (t, r) => {
		t < i || r > i + 8 || t === r || e[t] > 0 && e[r] > 0 && n.push([t, r]);
	};
	return a(t - 2, t - 1), r >= 1 && r <= 7 && e[t - 1] > 0 && e[t + 1] > 0 && n.push([t - 1, t + 1]), a(t + 1, t + 2), n;
}
function ie(e, t) {
	return t < 42 && e[t] >= 2;
}
function ae(e, t) {
	return t < 42 && e[t] >= 3;
}
function oe(e, t) {
	let n = [];
	for (let t = 0; t < 42; t += 1) e[t] === 4 && n.push(t);
	return {
		an: n,
		bu: t.filter((t) => e[t] >= 1)
	};
}
//#endregion
//#region src/games/mahjong/core/hand.ts
function se(e) {
	let t = [], n = e.slice(0, 42);
	for (let e = 0; e < 34; e += 1) n[e] < 2 || (n[e] -= 2, ce(n, 0, [], (n) => t.push({
		pair: e,
		melds: n
	})), n[e] += 2);
	return t;
}
function ce(e, t, n, r) {
	let i = t;
	for (; i < 34 && e[i] === 0;) i += 1;
	if (i >= 34) {
		r(n.slice());
		return;
	}
	e[i] >= 3 && (e[i] -= 3, n.push({
		type: "peng",
		tiles: [
			i,
			i,
			i
		]
	}), ce(e, i, n, r), n.pop(), e[i] += 3), i < 27 && i % 9 <= 6 && e[i + 1] > 0 && e[i + 2] > 0 && (--e[i], --e[i + 1], --e[i + 2], n.push({
		type: "chi",
		tiles: [
			i,
			i + 1,
			i + 2
		]
	}), ce(e, i, n, r), n.pop(), e[i] += 1, e[i + 1] += 1, e[i + 2] += 1);
}
function P(e) {
	let t = 0;
	for (let n = 0; n < 34; n += 1) if (e[n] === 2) t += 1;
	else if (e[n] !== 0) return !1;
	return t === 7;
}
var le = (() => {
	let e = [];
	for (let t = 0; t < 34; t += 1) te(t) && e.push(t);
	return e;
})();
function ue(e) {
	let t = 0;
	for (let n of le) {
		if (e[n] === 0) return !1;
		if (e[n] === 2) t += 1;
		else if (e[n] !== 1) return !1;
	}
	return t === 1;
}
function de(e, t) {
	return t === 0 && (P(e) || ue(e)) ? !0 : se(e).length > 0;
}
function fe(e) {
	let t = e.slice(0, 34), n = 8;
	function r(e, i, a, o) {
		for (; e < 34 && t[e] === 0;) e += 1;
		if (e >= 34) {
			let e = i + a > 4 ? 4 - i : a, t = 8 - 2 * i - e - o;
			t < n && (n = t);
			return;
		}
		t[e] >= 3 && (t[e] -= 3, r(e, i + 1, a, o), t[e] += 3), e < 27 && e % 9 <= 6 && t[e + 1] > 0 && t[e + 2] > 0 && (--t[e], --t[e + 1], --t[e + 2], r(e, i + 1, a, o), t[e] += 1, t[e + 1] += 1, t[e + 2] += 1), t[e] >= 2 && o === 0 && (t[e] -= 2, r(e, i, a, 1), t[e] += 2), t[e] >= 2 && (t[e] -= 2, r(e, i, a + 1, o), t[e] += 2), e < 27 && e % 9 <= 7 && t[e + 1] > 0 && (--t[e], --t[e + 1], r(e, i, a + 1, o), t[e] += 1, t[e + 1] += 1), e < 27 && e % 9 <= 6 && t[e + 2] > 0 && (--t[e], --t[e + 2], r(e, i, a + 1, o), t[e] += 1, t[e + 2] += 1), --t[e], r(e, i, a, o), t[e] += 1;
	}
	return r(0, 0, 0, 0), n;
}
function pe(e) {
	let t = 0, n = 0;
	for (let r = 0; r < 34; r += 1) e[r] >= 2 && (t += 1), e[r] > 0 && (n += 1);
	return 6 - t + Math.max(0, 7 - n);
}
function me(e) {
	let t = 0, n = 0;
	for (let r of le) e[r] > 0 && (t += 1), e[r] >= 2 && (n = 1);
	return 13 - t - n;
}
function he(e, t) {
	let n = fe(e);
	return t > 0 ? n : Math.min(n, pe(e), me(e));
}
function ge(e, t) {
	let n = [];
	for (let r = 0; r < 34; r += 1) e[r] >= 4 || (e[r] += 1, de(e, t) && n.push(r), --e[r]);
	return n;
}
function _e(e, t) {
	let n = [];
	for (let r of se(e)) r.pair === t && n.push({
		decomp: r,
		wait: "pair",
		meldIndex: -1
	}), r.melds.forEach((e, i) => {
		if (e.tiles.includes(t)) {
			if (e.type === "peng") n.push({
				decomp: r,
				wait: "triplet",
				meldIndex: i
			});
			else {
				let [a, , o] = e.tiles;
				t === a + 1 ? n.push({
					decomp: r,
					wait: "closed",
					meldIndex: i
				}) : a % 9 == 0 && t === o || o % 9 == 8 && t === a ? n.push({
					decomp: r,
					wait: "edge",
					meldIndex: i
				}) : n.push({
					decomp: r,
					wait: "double",
					meldIndex: i
				});
			}
		}
	});
	return n;
}
//#endregion
//#region src/games/mahjong/meta.ts
var F = {
	id: "mahjong",
	tier: "beta",
	mechanics: ["set-collection", "hand-management"],
	interactionTags: [],
	nameKey: "games.mahjong.name",
	descKey: "games.mahjong.desc",
	rulesKey: "games.mahjong.rules",
	icon: "🀄",
	iconImg: "games/mahjong.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/mahjong/en.pdf" },
	minPlayers: 4,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#0d9488",
	releasedAt: "2026-09-25",
	search: {
		py: "ma jiang",
		init: "mj"
	},
	hotseat: "cover"
}, I = t.string(), L = t.int().min(0).max(41), R = t.int().min(0).max(167), ve = t.discriminatedUnion("ruleset", [
	t.object({
		ruleset: t.literal("classic"),
		hands: t.int().min(1).max(16).catch(4)
	}),
	t.object({
		ruleset: t.literal("sichuan"),
		swap3: t.boolean().catch(!1),
		zimoJiaDi: t.boolean().catch(!0),
		hands: t.int().min(1).max(16).catch(4)
	}),
	t.object({
		ruleset: t.literal("mcr"),
		hands: t.int().min(1).max(16).catch(4)
	}),
	t.object({
		ruleset: t.literal("hongkong"),
		minFan: t.union([
			t.literal(0),
			t.literal(1),
			t.literal(3)
		]).catch(3),
		cap: t.union([
			t.literal(8),
			t.literal(10),
			t.literal(13)
		]).catch(10),
		hands: t.int().min(1).max(16).catch(4)
	}),
	t.object({
		ruleset: t.literal("riichi"),
		length: t.enum(["east", "south"]).catch("east"),
		kuitan: t.boolean().catch(!0),
		aka: t.union([
			t.literal(0),
			t.literal(3),
			t.literal(4)
		]).catch(3),
		multiRon: t.boolean().catch(!0)
	})
]).default({
	ruleset: "sichuan",
	swap3: !1,
	zimoJiaDi: !0,
	hands: 4
}), ye = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("discard"),
		tile: R
	}),
	t.object({
		type: t.literal("claim"),
		kind: t.enum([
			"hu",
			"kan",
			"peng",
			"chi"
		]),
		tiles: t.array(R).max(2).optional()
	}),
	t.object({ type: t.literal("pass") }),
	t.object({ type: t.literal("selfHu") }),
	t.object({
		type: t.literal("kan"),
		kind: t.enum(["an", "bu"]),
		face: L
	}),
	t.object({
		type: t.literal("riichi"),
		tile: R
	}),
	t.object({ type: t.literal("ryukyoku") }),
	t.object({
		type: t.literal("chooseLack"),
		suit: t.enum([
			"m",
			"p",
			"s"
		])
	}),
	t.object({
		type: t.literal("swap"),
		tiles: t.array(R).length(3)
	}),
	t.object({ type: t.literal("confirm") })
]), be = t.object({
	type: t.enum([
		"chi",
		"peng",
		"kanOpen",
		"kanClosed",
		"kanAdded"
	]),
	faces: t.array(L),
	reds: t.array(t.boolean()),
	from: I.nullable()
}), xe = t.object({
	tile: R,
	riichi: t.boolean(),
	claimed: t.boolean()
}), Se = t.object({
	rid: I,
	seat: t.int().min(0).max(3),
	seatWind: t.int().min(0).max(3),
	score: t.int(),
	handCount: t.int(),
	melds: t.array(be),
	discards: t.array(xe),
	flowers: t.array(L),
	riichi: t.boolean(),
	won: t.boolean(),
	lack: t.enum([
		"m",
		"p",
		"s"
	]).nullable()
}), Ce = t.object({
	key: t.string(),
	fan: t.int(),
	n: t.int().optional()
}), we = t.object({
	rid: I,
	lines: t.array(Ce),
	totalFan: t.int(),
	fu: t.int().nullable(),
	points: t.int(),
	tsumo: t.boolean(),
	from: I.nullable()
}), Te = t.object({
	kind: t.enum(["win", "draw"]),
	winners: t.array(we),
	deltas: t.record(t.string(), t.int()),
	tenpai: t.array(I),
	reason: t.string().nullable(),
	hands: t.record(t.string(), t.array(L))
}), Ee = t.object({
	k: t.string(),
	p: t.record(t.string(), t.union([t.string(), t.int()])).optional()
}), De = t.object({
	ruleset: t.enum([
		"classic",
		"sichuan",
		"mcr",
		"hongkong",
		"riichi"
	]),
	phase: t.enum([
		"lack",
		"swap",
		"discard",
		"claim",
		"handEnd",
		"done"
	]),
	handNo: t.int().min(1),
	totalHands: t.int().min(1),
	roundWind: t.int().min(0).max(3),
	dealer: I,
	honba: t.int().min(0),
	kyoutaku: t.int().min(0),
	wallCount: t.int().min(0),
	doraIndicators: t.array(L),
	doraRed: t.array(t.boolean()),
	publicRedIds: t.array(R),
	turn: I,
	lastDiscard: t.object({
		rid: I,
		tile: R
	}).nullable(),
	pendingOn: t.array(I),
	players: t.array(Se),
	log: t.array(Ee),
	lastSettle: Te.nullable(),
	history: t.array(Te),
	confirmed: t.array(I)
}), Oe = t.array(R).length(2), ke = t.object({
	hand: t.array(R),
	handRedIds: t.array(R),
	drawn: R.nullable(),
	waits: t.array(L).nullable(),
	can: t.object({
		discard: t.boolean(),
		selfHu: t.boolean(),
		kans: t.array(t.object({
			kind: t.enum(["an", "bu"]),
			face: L
		})),
		riichi: t.array(R).nullable(),
		claim: t.object({
			hu: t.boolean(),
			kan: t.boolean(),
			peng: t.boolean(),
			chi: t.array(Oe)
		}).nullable(),
		chooseLack: t.boolean(),
		swap: t.boolean(),
		ryukyoku: t.boolean(),
		confirm: t.boolean()
	})
});
//#endregion
//#region src/games/mahjong/rulesets/classic.ts
function Ae() {
	return {
		lines: [],
		totalFan: 0
	};
}
//#endregion
//#region src/games/mahjong/rulesets/shared.ts
function je(e, t) {
	if (t > 0) return !1;
	for (let t = 0; t < 3; t += 1) {
		let n = t * 9, r = [
			3,
			1,
			1,
			1,
			1,
			1,
			1,
			1,
			3
		], i = 0, a = !0;
		for (let t = 0; t < 9; t += 1) {
			let o = e[n + t];
			if (o === r[t] + 1) i += 1;
			else if (o !== r[t]) {
				a = !1;
				break;
			}
		}
		if (a && i === 1) return !0;
	}
	return !1;
}
//#endregion
//#region src/games/mahjong/rulesets/hongkong.ts
function z(e, t, n) {
	return n === void 0 ? {
		key: e,
		fan: t
	} : {
		key: e,
		fan: t,
		n
	};
}
function Me(e, t, n) {
	let r = e.counts, i = [], a = e.melds.length, o = !1;
	if (a === 0 && ue(r)) i.push(z("games.mahjong.fan.hk.shisanyao", n)), o = !0;
	else if (je(r, a)) i.push(z("games.mahjong.fan.hk.jiulian", n)), o = !0;
	else {
		let t = _e(r, e.winFace);
		if (t.length === 0 && !(a === 0 && P(r))) return null;
		a === 0 && P(r) && i.push(z("games.mahjong.fan.hk.qidui", 4));
		let o = [], s = -1;
		for (let r of t) {
			let t = [...e.melds.map((e) => ({
				type: e.type === "chi" ? "chi" : "peng",
				faces: e.faces.slice(0, 3)
			})), ...r.decomp.melds.map((e) => ({
				type: e.type,
				faces: [...e.tiles]
			}))], i = [
				...t.flatMap((e) => e.faces),
				r.decomp.pair,
				r.decomp.pair
			], a = [], c = t.filter((e) => e.type === "peng"), l = t.filter((e) => e.type === "chi"), u = c.filter((e) => O(e.faces[0]) >= 0), d = c.filter((e) => k(e.faces[0])), f = new Set(i.map((e) => C(e)).filter((e) => e !== null)), p = i.some(E);
			u.length === 4 ? a.push(z("games.mahjong.fan.hk.dasixi", n)) : u.length === 3 && O(r.decomp.pair) >= 0 && a.push(z("games.mahjong.fan.hk.xiaosixi", 8)), i.every(E) && a.push(z("games.mahjong.fan.hk.ziyise", n)), i.every((e) => D(e)) && a.push(z("games.mahjong.fan.hk.qingyaojiu", n)), d.length === 3 ? a.push(z("games.mahjong.fan.hk.dasanyuan", 8)) : d.length === 2 && k(r.decomp.pair) && a.push(z("games.mahjong.fan.hk.xiaosanyuan", 4)), i.every((e) => D(e) || E(e)) && p && f.size > 0 && a.push(z("games.mahjong.fan.hk.hunyaojiu", 4)), f.size === 1 && !p ? a.push(z("games.mahjong.fan.hk.qingyise", 6)) : f.size === 1 && p && a.push(z("games.mahjong.fan.hk.hunyise", 3)), c.length === 4 && a.push(z("games.mahjong.fan.hk.pengpenghu", 3));
			let m = k(r.decomp.pair) || O(r.decomp.pair) === e.roundWind || O(r.decomp.pair) === e.seatWind;
			l.length === 4 && !m && r.wait === "double" && a.push(z("games.mahjong.fan.hk.pinghu", 1));
			let h = a.reduce((e, t) => e + t.fan, 0);
			h > s && (s = h, o = a);
		}
		i.push(...o);
	}
	if (i.some((e) => e.fan >= n) && (o = !0), o || (e.menzen && !e.tsumo && i.push(z("games.mahjong.fan.hk.menqianqing", 1)), e.tsumo && i.push(z("games.mahjong.fan.hk.zimo", 1)), e.isTenho ? (i.push(z("games.mahjong.fan.hk.tianhu", n)), o = !0) : e.isChiiho && (i.push(z("games.mahjong.fan.hk.dihu", n)), o = !0), e.afterKan && i.push(z("games.mahjong.fan.hk.gangshanghua", 1)), e.isRobKan && i.push(z("games.mahjong.fan.hk.qianggang", 1)), e.isLastTile && i.push(z(e.tsumo ? "games.mahjong.fan.hk.haidilao" : "games.mahjong.fan.hk.hediyu", 1))), o) return {
		lines: i.filter((e) => e.fan >= n),
		totalFan: n
	};
	let s = 0;
	for (let t of e.flowers) s += t - 34 === e.seatWind || t - 38 === e.seatWind ? 2 : 1;
	s > 0 && i.push(z("games.mahjong.fan.hk.huapai", s, e.flowers.length));
	let c = i.reduce((e, t) => e + t.fan, 0);
	return c < t ? null : {
		lines: i,
		totalFan: Math.min(c, n)
	};
}
function B(e, t, n) {
	return n === void 0 ? {
		key: e,
		fan: t
	} : {
		key: e,
		fan: t,
		n
	};
}
var Ne = {
	dasixi: [
		"sanfengke",
		"pengpenghu",
		"yaojiuke",
		"queyimen"
	],
	dasanyuan: [
		"shuangjianke",
		"jianke",
		"yaojiuke"
	],
	lvyise: ["hunyise"],
	jiulian: [
		"qingyise",
		"menqianqing",
		"siguiyi"
	],
	sigang: [
		"sangang",
		"shuangminggang",
		"shuangangang",
		"angang",
		"minggang"
	],
	lianqidui: [
		"qidui",
		"menqianqing",
		"dandiao"
	],
	shisanyao: [
		"menqianqing",
		"dandiao",
		"wumenqi"
	],
	qingyaojiu: [
		"hunyaojiu",
		"yaojiuke",
		"wuzi",
		"pengpenghu",
		"quandaiyao"
	],
	xiaosixi: [
		"sanfengke",
		"yaojiuke",
		"queyimen"
	],
	xiaosanyuan: [
		"shuangjianke",
		"jianke",
		"queyimen"
	],
	ziyise: [
		"queyimen",
		"hunyaojiu",
		"pengpenghu",
		"yaojiuke"
	],
	sianke: [
		"sananke",
		"shuanganke",
		"menqianqing",
		"pengpenghu",
		"buqiuren"
	],
	yishuanglong: [
		"pinghu",
		"laoshaofu",
		"yibangao"
	],
	sitongshun: [
		"santongshun",
		"yibangao",
		"siguiyi"
	],
	sijiegao: ["sanjiegao", "pengpenghu"],
	sibugao: ["sanbugao", "lianliu"],
	sangang: [
		"shuangminggang",
		"shuangangang",
		"angang",
		"minggang"
	],
	hunyaojiu: ["quandaiyao", "yaojiuke"],
	qidui: ["menqianqing", "dandiao"],
	qixing: [
		"quanbukao",
		"zuhelong",
		"wumenqi",
		"menqianqing",
		"dandiao"
	],
	quanshuangke: [
		"pengpenghu",
		"wuzi",
		"duanyao"
	],
	qingyise: ["queyimen", "wuzi"],
	santongshun: ["yibangao"],
	quanda: ["dayuwu"],
	quanxiao: ["xiaoyuwu"],
	qinglong: ["lianliu", "laoshaofu"],
	sanshuanglong: ["laoshaofu", "xixiangfeng"],
	quandaiwu: ["duanyao"],
	santongke: ["shuangtongke"],
	sananke: ["shuanganke"],
	dayuwu: ["duanyao"],
	xiaoyuwu: ["duanyao"],
	sanfengke: ["yaojiuke"],
	tuibudao: ["queyimen"],
	stongsan: ["xixiangfeng"],
	hunyise: ["queyimen"],
	wumenqi: ["queyimen", "wuzi"],
	quanqiuren: ["dandiao"],
	shuangangang: ["angang", "shuanganke"],
	shuangjianke: ["jianke"],
	quandaiyao: ["yaojiuke"],
	buqiuren: ["zimo", "menqianqing"],
	shuangminggang: ["minggang"],
	jianke: ["yaojiuke"],
	quanfengke: ["yaojiuke"],
	menfengke: ["yaojiuke"],
	pinghu: ["wuzi"],
	miaoshou: ["zimo"]
}, Pe = /* @__PURE__ */ new Set([
	19,
	20,
	21,
	23,
	25,
	32
]), Fe = /* @__PURE__ */ new Set([
	9,
	10,
	11,
	12,
	13,
	16,
	17,
	19,
	20,
	21,
	22,
	23,
	25,
	26,
	32
]);
function Ie(e, t) {
	let n = e.melds.map((e) => ({
		type: e.type === "chi" ? "chi" : "peng",
		faces: e.faces.slice(0, 3),
		concealed: e.type === "kanClosed",
		kan: e.type === "kanClosed" ? "closed" : e.type === "kanOpen" || e.type === "kanAdded" ? "open" : "none"
	})), r = t.decomp.melds.map((n, r) => ({
		type: n.type,
		faces: [...n.tiles],
		concealed: !(r === t.meldIndex && !e.tsumo && t.wait === "triplet"),
		kan: "none"
	}));
	return [...n, ...r];
}
function Le(e) {
	let t = 0, n = /* @__PURE__ */ new Set();
	for (let n = 0; n < 3; n += 1) {
		let r = n * 9, i = [
			0,
			0,
			0
		];
		for (let n = 0; n < 9; n += 1) {
			let a = e[r + n];
			if (a !== 0) {
				if (a > 1) return {
					ok: !1,
					qixing: !1
				};
				i[n % 3] += 1, t += 1;
			}
		}
		if (i.filter((e) => e > 0).length > 1) return {
			ok: !1,
			qixing: !1
		};
	}
	for (let r = 27; r < 34; r += 1) {
		if (e[r] > 1) return {
			ok: !1,
			qixing: !1
		};
		e[r] === 1 && (n.add(r), t += 1);
	}
	return t === 14 ? {
		ok: !0,
		qixing: n.size === 7
	} : {
		ok: !1,
		qixing: !1
	};
}
function Re(e, t) {
	if (t > 0) return !1;
	for (let t = 0; t < 3; t += 1) {
		let n = t * 9, r = [
			3,
			1,
			1,
			1,
			1,
			1,
			1,
			1,
			3
		], i = 0, a = !0;
		for (let t = 0; t < 9; t += 1) {
			let o = e[n + t];
			if (o === r[t] + 1) i += 1;
			else if (o !== r[t]) {
				a = !1;
				break;
			}
		}
		if (a && i === 1) return !0;
	}
	return !1;
}
function ze(e, t) {
	let n = t.melds.length;
	if (n === 0) {
		if (ue(e)) return [B("games.mahjong.fan.mcr.shisanyao", 88)];
		if (P(e)) {
			for (let t = 0; t < 3; t += 1) {
				let n = t * 9, r = 0, i = !1;
				for (let t = 0; t < 9; t += 1) if (e[n + t] === 2) r += 1;
				else if (e[n + t] !== 0) {
					i = !0;
					break;
				}
				if (!i && r === 7) return [B("games.mahjong.fan.mcr.lianqidui", 88)];
			}
			return [B("games.mahjong.fan.mcr.qidui", 24)];
		}
		let t = Le(e);
		if (t.ok) {
			let e = [B("games.mahjong.fan.mcr.quanbukao", 12), B("games.mahjong.fan.mcr.zuhelong", 12)];
			return t.qixing && e.push(B("games.mahjong.fan.mcr.qixing", 24)), e;
		}
	}
	return Re(e, n) ? [B("games.mahjong.fan.mcr.jiulian", 88)] : null;
}
function Be(e, t) {
	let n = Ie(e, t), r = t.decomp.pair, i = [
		...n.flatMap((e) => e.faces),
		r,
		r
	], a = e.counts, o = [], s = n.filter((e) => e.type === "peng"), c = n.filter((e) => e.type === "chi"), l = n.filter((e) => e.kan === "open"), u = n.filter((e) => e.kan === "closed"), d = s.filter((e) => O(e.faces[0]) >= 0), f = s.filter((e) => k(e.faces[0])), p = new Set(i.map((e) => C(e)).filter((e) => e !== null)), m = i.some(E), h = s.filter((e) => e.concealed).length;
	d.length === 4 && o.push(B("games.mahjong.fan.mcr.dasixi", 88)), f.length === 3 && o.push(B("games.mahjong.fan.mcr.dasanyuan", 88)), i.every((e) => Pe.has(e)) && o.push(B("games.mahjong.fan.mcr.lvyise", 88)), n.length === 4 && n.every((e) => e.kan !== "none") && o.push(B("games.mahjong.fan.mcr.sigang", 88)), i.every((e) => D(e)) && o.push(B("games.mahjong.fan.mcr.qingyaojiu", 64)), d.length === 3 && O(r) >= 0 && o.push(B("games.mahjong.fan.mcr.xiaosixi", 64)), f.length === 2 && k(r) && o.push(B("games.mahjong.fan.mcr.xiaosanyuan", 64)), i.every(E) && o.push(B("games.mahjong.fan.mcr.ziyise", 64)), h === 4 && o.push(B("games.mahjong.fan.mcr.sianke", 64)), Ue(c, r) && o.push(B("games.mahjong.fan.mcr.yishuanglong", 64)), Ve(c, 4) && o.push(B("games.mahjong.fan.mcr.sitongshun", 48)), Ge(s, 4) && o.push(B("games.mahjong.fan.mcr.sijiegao", 48)), Ke(c, 4) && o.push(B("games.mahjong.fan.mcr.sibugao", 32)), l.length + u.length === 3 && o.push(B("games.mahjong.fan.mcr.sangang", 32)), m && i.every((e) => D(e) || E(e)) && o.push(B("games.mahjong.fan.mcr.hunyaojiu", 32)), p.size === 1 && !m && o.push(B("games.mahjong.fan.mcr.qingyise", 24)), Ve(c, 3) && o.push(B("games.mahjong.fan.mcr.santongshun", 24)), Ge(s, 3) && o.push(B("games.mahjong.fan.mcr.sanjiegao", 24));
	let g = (e, t) => i.every((n) => n < 27 && w(n) >= e && w(n) <= t);
	g(7, 9) && o.push(B("games.mahjong.fan.mcr.quanda", 24)), g(4, 6) && o.push(B("games.mahjong.fan.mcr.quanzhong", 24)), g(1, 3) && o.push(B("games.mahjong.fan.mcr.quanxiao", 24)), s.length === 4 && i.every((e) => e < 27 && w(e) % 2 == 0) && o.push(B("games.mahjong.fan.mcr.quanshuangke", 24));
	for (let e = 0; e < 3; e += 1) if ([
		0,
		3,
		6
	].every((t) => c.some((n) => n.faces[0] === e * 9 + t))) {
		o.push(B("games.mahjong.fan.mcr.qinglong", 16));
		break;
	}
	We(c, r) && o.push(B("games.mahjong.fan.mcr.sanshuanglong", 16)), Ke(c, 3) && o.push(B("games.mahjong.fan.mcr.sanbugao", 16)), n.length === 4 && i.every((e) => e < 27 && w(e) === 5) && o.push(B("games.mahjong.fan.mcr.quandaiwu", 16)), qe(s, 3) && o.push(B("games.mahjong.fan.mcr.santongke", 16)), h === 3 && o.push(B("games.mahjong.fan.mcr.sananke", 16)), g(6, 9) && o.push(B("games.mahjong.fan.mcr.dayuwu", 12)), g(1, 4) && o.push(B("games.mahjong.fan.mcr.xiaoyuwu", 12)), d.length === 3 && o.push(B("games.mahjong.fan.mcr.sanfengke", 12)), Je(c) && o.push(B("games.mahjong.fan.mcr.hualong", 8)), i.every((e) => Fe.has(e)) && o.push(B("games.mahjong.fan.mcr.tuibudao", 8)), Ye(c) && o.push(B("games.mahjong.fan.mcr.stongsan", 8)), Xe(s) && o.push(B("games.mahjong.fan.mcr.sanjiesan", 8)), e.isLastTile && e.tsumo ? o.push(B("games.mahjong.fan.mcr.miaoshou", 8)) : e.isLastTile && o.push(B("games.mahjong.fan.mcr.haidilao", 8)), e.afterKan && o.push(B("games.mahjong.fan.mcr.gangshanghua", 8)), e.isRobKan && o.push(B("games.mahjong.fan.mcr.qianggang", 8)), s.length === 4 && o.push(B("games.mahjong.fan.mcr.pengpenghu", 6)), p.size === 1 && m && o.push(B("games.mahjong.fan.mcr.hunyise", 6)), Ze(c) && o.push(B("games.mahjong.fan.mcr.ssanbugao", 6)), p.size === 3 && i.some((e) => O(e) >= 0) && i.some(k) && o.push(B("games.mahjong.fan.mcr.wumenqi", 6)), e.melds.length === 4 && e.melds.every((e) => e.from !== null) && !e.tsumo && t.wait === "pair" && o.push(B("games.mahjong.fan.mcr.quanqiuren", 6)), u.length === 2 && o.push(B("games.mahjong.fan.mcr.shuangangang", 6)), f.length === 2 && o.push(B("games.mahjong.fan.mcr.shuangjianke", 6)), [...n.map((e) => e.faces), [r, r]].every((e) => e.some((e) => D(e) || E(e))) && o.push(B("games.mahjong.fan.mcr.quandaiyao", 4)), e.menzen && e.tsumo && o.push(B("games.mahjong.fan.mcr.buqiuren", 4)), l.length === 2 && o.push(B("games.mahjong.fan.mcr.shuangminggang", 4)), e.visibleCounts[e.winFace] === 3 && o.push(B("games.mahjong.fan.mcr.hejuezhang", 4)), f.length === 1 && o.push(B("games.mahjong.fan.mcr.jianke", 2)), d.some((t) => O(t.faces[0]) === e.roundWind) && o.push(B("games.mahjong.fan.mcr.quanfengke", 2)), d.some((t) => O(t.faces[0]) === e.seatWind) && o.push(B("games.mahjong.fan.mcr.menfengke", 2)), e.menzen && !e.tsumo && o.push(B("games.mahjong.fan.mcr.menqianqing", 2)), c.length === 4 && !et(r, e) && t.wait === "double" && o.push(B("games.mahjong.fan.mcr.pinghu", 2));
	for (let e = 0; e < 34; e += 1) a[e] === 4 && !n.some((t) => t.kan !== "none" && t.faces[0] === e) && o.push(B("games.mahjong.fan.mcr.siguiyi", 2));
	qe(s, 2) && o.push(B("games.mahjong.fan.mcr.shuangtongke", 2)), h === 2 && o.push(B("games.mahjong.fan.mcr.shuanganke", 2)), u.length === 1 && o.push(B("games.mahjong.fan.mcr.angang", 2)), i.every((e) => e < 27 && !D(e)) && o.push(B("games.mahjong.fan.mcr.duanyao", 2));
	let _ = He(c);
	_ > 0 && o.push(B("games.mahjong.fan.mcr.yibangao", _, _));
	let v = $e(c);
	v > 0 && o.push(B("games.mahjong.fan.mcr.xixiangfeng", v, v)), Qe(c) && o.push(B("games.mahjong.fan.mcr.lianliu", 1));
	for (let e = 0; e < 3; e += 1) if (c.some((t) => t.faces[0] === e * 9) && c.some((t) => t.faces[0] === e * 9 + 6)) {
		o.push(B("games.mahjong.fan.mcr.laoshaofu", 1));
		break;
	}
	let y = s.filter((e) => D(e.faces[0]) || E(e.faces[0])).length;
	return y > 0 && o.push(B("games.mahjong.fan.mcr.yaojiuke", y, y)), l.length === 1 && o.push(B("games.mahjong.fan.mcr.minggang", 1)), p.size === 2 && !m && o.push(B("games.mahjong.fan.mcr.queyimen", 1)), m || o.push(B("games.mahjong.fan.mcr.wuzi", 1)), t.wait === "edge" && o.push(B("games.mahjong.fan.mcr.bianzhang", 1)), t.wait === "closed" && o.push(B("games.mahjong.fan.mcr.kanzhang", 1)), t.wait === "pair" && o.push(B("games.mahjong.fan.mcr.dandiao", 1)), e.tsumo && o.push(B("games.mahjong.fan.mcr.zimo", 1)), o;
}
function Ve(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t.faces[0], (n.get(t.faces[0]) ?? 0) + 1);
	return [...n.values()].some((e) => e >= t);
}
function He(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.faces[0], (t.get(n.faces[0]) ?? 0) + 1);
	let n = 0;
	for (let e of t.values()) n += Math.floor(e / 2);
	return n;
}
function Ue(e, t) {
	if (t >= 27 || w(t) !== 5) return !1;
	let n = t - t % 9, r = e.filter((e) => e.faces[0] === n).length, i = e.filter((e) => e.faces[0] === n + 6).length;
	return r >= 2 && i >= 2;
}
function We(e, t) {
	if (t >= 27 || w(t) !== 5) return !1;
	let n = Math.floor(t / 9), r = (t) => e.some((e) => e.faces[0] === t * 9) && e.some((e) => e.faces[0] === t * 9 + 6), i = [
		0,
		1,
		2
	].filter((e) => e !== n);
	return r(i[0]) && r(i[1]);
}
function Ge(e, t) {
	let n = e.map((e) => e.faces[0]).filter((e) => e < 27);
	for (let e = 0; e < 3; e += 1) {
		let r = new Set(n.filter((t) => t >= e * 9 && t < e * 9 + 9).map((e) => e % 9)), i = 0;
		for (let e = 0; e < 9; e += 1) if (i = r.has(e) ? i + 1 : 0, i >= t) return !0;
	}
	return !1;
}
function Ke(e, t) {
	for (let n = 0; n < 3; n += 1) {
		let r = new Set(e.map((e) => e.faces[0]).filter((e) => e >= n * 9 && e < n * 9 + 9).map((e) => e % 9));
		for (let e of r) for (let n of [1, 2]) {
			let i = !0;
			for (let a = 1; a < t; a += 1) r.has(e + a * n) || (i = !1);
			if (i) return !0;
		}
	}
	return !1;
}
function qe(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) {
		let e = t.faces[0];
		if (e >= 27) continue;
		let r = e % 9;
		n.has(r) || n.set(r, /* @__PURE__ */ new Set()), n.get(r)?.add(Math.floor(e / 9));
	}
	return [...n.values()].some((e) => e.size >= t);
}
function Je(e) {
	let t = (t, n) => e.some((e) => e.faces[0] === t * 9 + n);
	for (let e of [
		[
			0,
			1,
			2
		],
		[
			0,
			2,
			1
		],
		[
			1,
			0,
			2
		],
		[
			1,
			2,
			0
		],
		[
			2,
			0,
			1
		],
		[
			2,
			1,
			0
		]
	]) if (t(e[0], 0) && t(e[1], 3) && t(e[2], 6)) return !0;
	return !1;
}
function Ye(e) {
	for (let t = 0; t < 7; t += 1) if ([
		0,
		1,
		2
	].every((n) => e.some((e) => e.faces[0] === n * 9 + t))) return !0;
	return !1;
}
function Xe(e) {
	for (let t = 0; t < 8; t += 1) for (let n of [
		[
			0,
			1,
			2
		],
		[
			0,
			2,
			1
		],
		[
			1,
			0,
			2
		],
		[
			1,
			2,
			0
		],
		[
			2,
			0,
			1
		],
		[
			2,
			1,
			0
		]
	]) if (e.some((e) => e.faces[0] === n[0] * 9 + t) && e.some((e) => e.faces[0] === n[1] * 9 + t + 1) && e.some((e) => e.faces[0] === n[2] * 9 + t + 2)) return !0;
	return !1;
}
function Ze(e) {
	for (let t = 0; t < 5; t += 1) for (let n of [
		[
			0,
			1,
			2
		],
		[
			0,
			2,
			1
		],
		[
			1,
			0,
			2
		],
		[
			1,
			2,
			0
		],
		[
			2,
			0,
			1
		],
		[
			2,
			1,
			0
		]
	]) if (e.some((e) => e.faces[0] === n[0] * 9 + t) && e.some((e) => e.faces[0] === n[1] * 9 + t + 1) && e.some((e) => e.faces[0] === n[2] * 9 + t + 2)) return !0;
	return !1;
}
function Qe(e) {
	for (let t = 0; t < 3; t += 1) {
		let n = new Set(e.map((e) => e.faces[0]).filter((e) => e >= t * 9 && e < t * 9 + 9).map((e) => e % 9));
		for (let e = 0; e <= 3; e += 1) if (n.has(e) && n.has(e + 3)) return !0;
	}
	return !1;
}
function $e(e) {
	let t = 0;
	for (let n = 0; n < 7; n += 1) [
		0,
		1,
		2
	].filter((t) => e.some((e) => e.faces[0] === t * 9 + n)).length >= 2 && (t += 1);
	return Math.min(t, 2);
}
function et(e, t) {
	if (k(e)) return !0;
	let n = O(e);
	return n === t.roundWind || n === t.seatWind;
}
function tt(e) {
	let t = new Set(e.map((e) => e.key.replace("games.mahjong.fan.mcr.", "")));
	return e.filter((e) => {
		let n = e.key.replace("games.mahjong.fan.mcr.", "");
		for (let [e, r] of Object.entries(Ne)) if (t.has(e) && r?.includes(n)) return !1;
		return !0;
	});
}
function nt(e, t) {
	return t === 0 && (P(e) || ue(e) || Le(e).ok) || Re(e, t) ? !0 : se(e).length > 0;
}
function rt(e) {
	let t = e.counts, n = ze(t, e);
	if (n) e.tsumo && n.push(B("games.mahjong.fan.mcr.zimo", 1)), e.isLastTile && n.push(B(e.tsumo ? "games.mahjong.fan.mcr.miaoshou" : "games.mahjong.fan.mcr.haidilao", 8)), e.afterKan && n.push(B("games.mahjong.fan.mcr.gangshanghua", 8)), e.isRobKan && n.push(B("games.mahjong.fan.mcr.qianggang", 8)), n = tt(n);
	else {
		let r = -1;
		for (let i of _e(t, e.winFace)) {
			let t = tt(Be(e, i)), a = t.reduce((e, t) => e + t.fan, 0);
			a > r && (r = a, n = t);
		}
		n && n.length === 0 && n.push(B("games.mahjong.fan.mcr.wufanhu", 8));
	}
	if (!n) return null;
	let r = n.reduce((e, t) => e + t.fan, 0);
	return r < 8 ? null : (e.flowers.length > 0 && n.push(B("games.mahjong.fan.mcr.huapai", e.flowers.length, e.flowers.length)), {
		lines: n,
		totalFan: r + e.flowers.length
	});
}
//#endregion
//#region src/games/mahjong/rulesets/riichi.ts
function V(e, t, n) {
	return n === void 0 ? {
		key: e,
		fan: t
	} : {
		key: e,
		fan: t,
		n
	};
}
var it = /* @__PURE__ */ new Set([
	19,
	20,
	21,
	23,
	25,
	32
]);
function at(e, t) {
	let n = e.melds.map((e) => ({
		type: e.type === "chi" ? "chi" : "peng",
		face: e.faces[0],
		concealed: e.type === "kanClosed",
		kan: e.type === "kanClosed" ? "closed" : e.type === "kanOpen" || e.type === "kanAdded" ? "open" : "none"
	})), r = t.decomp.melds.map((n, r) => ({
		type: n.type,
		face: n.tiles[0],
		concealed: !(r === t.meldIndex && !e.tsumo && t.wait === "triplet"),
		kan: "none"
	}));
	return [...n, ...r];
}
function ot(e, t, n, r) {
	let i = 20;
	!r.tsumo && r.menzen && (i += 10), r.tsumo && (i += 2);
	for (let t of e) {
		if (t.type !== "peng") continue;
		let e = D(t.face) || E(t.face), n = t.kan === "none" ? 2 : 8;
		e && (n *= 2), t.concealed && (n *= 2), i += n;
	}
	if (k(t)) i += 2;
	else {
		let e = O(t);
		e >= 0 && (i += e === r.roundWind && e === r.seatWind ? 4 : e === r.roundWind || e === r.seatWind ? 2 : 0);
	}
	return (n.wait === "edge" || n.wait === "closed" || n.wait === "pair") && (i += 2), Math.ceil(i / 10) * 10;
}
function st(e) {
	let t = e.counts, n = e.melds, r = n.length, i = [], a = [...n.flatMap((e) => e.faces), ...ct(t)], o = n.map((e) => ({
		type: e.type,
		face: e.faces[0],
		concealed: e.type === "kanClosed"
	})), s = o.filter((e) => e.type !== "chi" && e.concealed).length;
	e.isTenho && i.push(V("games.mahjong.fan.riichi.tenho", 13)), e.isChiiho && i.push(V("games.mahjong.fan.riichi.chiiho", 13)), r === 0 && ue(t) && i.push(V("games.mahjong.fan.riichi.kokushi", 13)), je(t, r) && i.push(V("games.mahjong.fan.riichi.churen", 13)), n.filter((e) => e.type !== "chi" && e.type !== "peng").length === 4 && i.push(V("games.mahjong.fan.riichi.suukantsu", 13));
	let c = o.filter((e) => e.type !== "chi" && O(e.face) >= 0), l = o.filter((e) => e.type !== "chi" && k(e.face));
	if (c.length === 4 && i.push(V("games.mahjong.fan.riichi.daisuushii", 13)), l.length === 3 && i.push(V("games.mahjong.fan.riichi.daisangen", 13)), a.every(E) && i.push(V("games.mahjong.fan.riichi.tsuuiisou", 13)), a.every((e) => it.has(e)) && i.push(V("games.mahjong.fan.riichi.ryuuiisou", 13)), a.every((e) => D(e)) && a.length > 0 && i.push(V("games.mahjong.fan.riichi.chinroutou", 13)), s === 4 && n.every((e) => e.type === "kanClosed" || e.type === "peng")) {
		for (let n of _e(t, e.winFace)) if (at(e, n).filter((e) => e.type === "peng" && e.concealed).length === 4) {
			i.push(V("games.mahjong.fan.riichi.suuankou", 13));
			break;
		}
	}
	return i;
}
function ct(e) {
	let t = [];
	for (let n = 0; n < e.length; n += 1) for (let r = 0; r < e[n]; r += 1) t.push(n);
	return t;
}
function lt(e, t, n) {
	let r = at(e, t), i = t.decomp.pair, a = [...r.map((e) => e.face), i], o = e.counts, s = [], c = r.filter((e) => e.type === "peng"), l = r.filter((e) => e.type === "chi"), u = e.melds.filter((e) => e.type !== "kanClosed").length > 0, d = (e, t, n) => s.push(V(e, u ? n : t));
	e.riichi.double ? s.push(V("games.mahjong.fan.riichi.doubleRiichi", 2)) : e.riichi.declared && s.push(V("games.mahjong.fan.riichi.riichi", 1)), e.riichi.ippatsu && s.push(V("games.mahjong.fan.riichi.ippatsu", 1)), e.menzen && e.tsumo && s.push(V("games.mahjong.fan.riichi.tsumo", 1));
	let f = l.length === 4 && t.wait === "double" && !k(i) && O(i) !== e.roundWind && O(i) !== e.seatWind && (e.tsumo || e.menzen);
	f && s.push(V("games.mahjong.fan.riichi.pinfu", 1));
	let p = c.filter((e) => O(e.face) >= 0), m = c.filter((e) => k(e.face)), h = m.length + p.filter((t) => O(t.face) === e.roundWind).length + p.filter((t) => O(t.face) === e.seatWind).length;
	m.length > 0 && s.push(V("games.mahjong.fan.riichi.yakuhaiDragon", m.length, m.length));
	let g = h - m.length;
	if (g > 0 && s.push(V("games.mahjong.fan.riichi.yakuhaiWind", g, g)), a.every((e) => e < 27 && !D(e)) && (e.menzen || n) && d("games.mahjong.fan.riichi.tanyao", 1, 1), e.menzen) {
		let e = /* @__PURE__ */ new Map();
		for (let t of l) e.set(t.face, (e.get(t.face) ?? 0) + 1);
		let t = [...e.values()].filter((e) => e >= 2).length;
		t >= 2 ? s.push(V("games.mahjong.fan.riichi.ryanpeikou", 3)) : t === 1 && s.push(V("games.mahjong.fan.riichi.iipeikou", 1));
	}
	for (let e = 0; e < 7; e += 1) if ([
		0,
		1,
		2
	].every((t) => l.some((n) => n.face === t * 9 + e))) {
		d("games.mahjong.fan.riichi.sanshokuDoujun", 2, 1);
		break;
	}
	{
		let e = /* @__PURE__ */ new Map();
		for (let t of c) {
			if (t.face >= 27) continue;
			let n = t.face % 9;
			e.has(n) || e.set(n, /* @__PURE__ */ new Set()), e.get(n)?.add(Math.floor(t.face / 9));
		}
		[...e.values()].some((e) => e.size === 3) && d("games.mahjong.fan.riichi.sanshokuDoukou", 2, 2);
	}
	for (let e = 0; e < 3; e += 1) if ([
		0,
		3,
		6
	].every((t) => l.some((n) => n.face === e * 9 + t))) {
		d("games.mahjong.fan.riichi.ikkitsuukan", 2, 1);
		break;
	}
	let _ = [...r.map((e) => e.type === "chi" ? [e.face, e.face + 2] : [e.face]), [i]].every((e) => e.some((e) => D(e) || E(e))), v = a.some((e) => E(e)) || o.slice(27, 34).some((e) => e > 0);
	_ && (v ? d("games.mahjong.fan.riichi.chanta", 2, 1) : d("games.mahjong.fan.riichi.junchan", 3, 2)), c.length === 4 && s.push(V("games.mahjong.fan.riichi.toitoi", 2)), c.filter((e) => e.concealed).length === 3 && s.push(V("games.mahjong.fan.riichi.sanankou", 2)), r.filter((e) => e.kan !== "none").length === 3 && s.push(V("games.mahjong.fan.riichi.sankantsu", 2)), v && ut(r, i).every((e) => D(e) || E(e)) && s.push(V("games.mahjong.fan.riichi.honroutou", 2)), m.length === 2 && k(i) && s.push(V("games.mahjong.fan.riichi.shousangen", 2));
	let y = new Set(ut(r, i).map((e) => C(e)).filter((e) => e !== null));
	return y.size === 1 && v ? d("games.mahjong.fan.riichi.honiisou", 3, 2) : y.size === 1 && !v && d("games.mahjong.fan.riichi.chiniisou", 6, 5), e.isLastTile && e.tsumo ? s.push(V("games.mahjong.fan.riichi.haitei", 1)) : e.isLastTile && s.push(V("games.mahjong.fan.riichi.houtei", 1)), e.afterKan && s.push(V("games.mahjong.fan.riichi.rinshan", 1)), e.isRobKan && s.push(V("games.mahjong.fan.riichi.chankan", 1)), {
		lines: s,
		isYakuman: !1,
		isPinfuTsumo: f && e.tsumo
	};
}
function ut(e, t) {
	return [
		...e.flatMap((e) => e.type === "chi" ? [
			e.face,
			e.face + 1,
			e.face + 2
		] : [
			e.face,
			e.face,
			e.face
		]),
		t,
		t
	];
}
function dt(e, t) {
	let n = st(e);
	if (n.length > 0) return {
		lines: n,
		totalFan: n.reduce((e, t) => e + t.fan, 0)
	};
	if (e.melds.length === 0 && P(e.counts)) {
		let t = [V("games.mahjong.fan.riichi.chiitoitsu", 2)];
		e.menzen && e.tsumo && t.push(V("games.mahjong.fan.riichi.tsumo", 1)), e.riichi.double ? t.push(V("games.mahjong.fan.riichi.doubleRiichi", 2)) : e.riichi.declared && t.push(V("games.mahjong.fan.riichi.riichi", 1)), e.riichi.ippatsu && t.push(V("games.mahjong.fan.riichi.ippatsu", 1)), e.isLastTile && t.push(V(e.tsumo ? "games.mahjong.fan.riichi.haitei" : "games.mahjong.fan.riichi.houtei", 1)), e.afterKan && t.push(V("games.mahjong.fan.riichi.rinshan", 1)), e.isRobKan && t.push(V("games.mahjong.fan.riichi.chankan", 1)), ft(e.counts) && t.push(V("games.mahjong.fan.riichi.tanyao", 1)), t.push(...pt(e.counts));
		let n = e.dora + e.uraDora + e.redDora;
		n > 0 && t.push(V("games.mahjong.fan.riichi.dora", n, n));
		let r = t.filter((e) => !e.key.endsWith(".dora")).reduce((e, t) => e + t.fan, 0);
		return r === 0 ? null : {
			lines: t,
			totalFan: r + n,
			fu: 25
		};
	}
	let r = _e(e.counts, e.winFace);
	if (r.length === 0) return null;
	let i = null;
	for (let n of r) {
		let r = lt(e, n, t.kuitan), a = r.lines.reduce((e, t) => e + t.fan, 0);
		if (a === 0) continue;
		let o = a + (e.dora + e.uraDora + e.redDora), s = at(e, n), c = r.isPinfuTsumo ? 20 : ot(s, n.decomp.pair, n, e);
		(!i || o > i.fan || o === i.fan && c > i.fu) && (i = {
			lines: r.lines,
			fan: o,
			fu: c
		});
	}
	if (!i) return null;
	let a = e.dora + e.uraDora + e.redDora;
	return a > 0 && i.lines.push(V("games.mahjong.fan.riichi.dora", a, a)), {
		lines: i.lines,
		totalFan: i.fan,
		fu: i.fu
	};
}
function ft(e) {
	for (let t = 0; t < 34; t += 1) if (e[t] > 0 && (t >= 27 || D(t))) return !1;
	return !0;
}
function pt(e) {
	let t = ct(e), n = new Set(t.map((e) => C(e)).filter((e) => e !== null)), r = t.some((e) => e >= 27);
	return n.size === 1 && r ? [V("games.mahjong.fan.riichi.honiisou", 3)] : n.size === 1 && !r ? [V("games.mahjong.fan.riichi.chiniisou", 6)] : [];
}
function mt(e) {
	let t = null, n = [...e.melds.flatMap((e) => e.faces)];
	for (let t = 0; t < 27; t += 1) e.counts[t] > 0 && n.push(t);
	if (n.length === 0) return !1;
	for (let e of n) {
		let n = C(e);
		if (n === null) return !1;
		if (t === null) t = n;
		else if (t !== n) return !1;
	}
	return !0;
}
function ht(e) {
	let t = e.counts.reduce((e, t) => e + t, 0);
	return e.melds.length === 4 && t === 2 && e.melds.every((e) => e.type !== "chi");
}
function gt(e) {
	let t = [], n = e.melds.length === 0 && P(e.counts), r = mt(e);
	n ? t.push({
		key: "games.mahjong.fan.sc.qidui",
		fan: 2
	}) : (e.melds.every((e) => e.type !== "chi") && _e(e.counts, e.winFace).some((e) => e.decomp.melds.every((e) => e.type === "peng")) && t.push({
		key: "games.mahjong.fan.sc.pengpenghu",
		fan: 1
	}), ht(e) && t.push({
		key: "games.mahjong.fan.sc.jingoudiao",
		fan: 1
	})), r && t.push({
		key: "games.mahjong.fan.sc.qingyise",
		fan: 2
	}), e.isTenho ? t.push({
		key: "games.mahjong.fan.sc.tianhu",
		fan: 4
	}) : e.isChiiho && t.push({
		key: "games.mahjong.fan.sc.dihu",
		fan: 4
	}), e.afterKan && t.push({
		key: "games.mahjong.fan.sc.gangshanghua",
		fan: 1
	}), e.isRobKan && t.push({
		key: "games.mahjong.fan.sc.qianggang",
		fan: 1
	}), e.isLastTile && t.push({
		key: e.tsumo ? "games.mahjong.fan.sc.haidilao" : "games.mahjong.fan.sc.hedilao",
		fan: 1
	}), e.afterKanDiscard && t.push({
		key: "games.mahjong.fan.sc.gangshangpao",
		fan: 1
	});
	let i = e.melds.filter((e) => e.type !== "chi" && e.type !== "peng").length;
	return i > 0 && t.push({
		key: "games.mahjong.fan.sc.gen",
		fan: i,
		n: i
	}), t;
}
var _t = (e) => {
	let t = gt(e);
	return t.length === 0 && t.push({
		key: "games.mahjong.fan.sc.pinghu",
		fan: 0
	}), {
		lines: t,
		totalFan: Math.min(5, t.reduce((e, t) => e + t.fan, 0))
	};
};
function vt(e) {
	return 2 ** Math.min(e, 5);
}
//#endregion
//#region src/games/mahjong/rules.ts
var H = {
	classic: {
		wallKind: "honor",
		hasChi: !0,
		chooseLack: !1,
		bloodBattle: !1,
		hasRiichi: !1,
		furiten: !1,
		startScore: 0
	},
	sichuan: {
		wallKind: "suit",
		hasChi: !1,
		chooseLack: !0,
		bloodBattle: !0,
		hasRiichi: !1,
		furiten: !1,
		startScore: 0
	},
	mcr: {
		wallKind: "flower",
		hasChi: !0,
		chooseLack: !1,
		bloodBattle: !1,
		hasRiichi: !1,
		furiten: !1,
		startScore: 0
	},
	hongkong: {
		wallKind: "flower",
		hasChi: !0,
		chooseLack: !1,
		bloodBattle: !1,
		hasRiichi: !1,
		furiten: !1,
		startScore: 0
	},
	riichi: {
		wallKind: "honor",
		hasChi: !0,
		chooseLack: !1,
		bloodBattle: !1,
		hasRiichi: !0,
		furiten: !0,
		startScore: 25e3
	}
}, yt = 14;
function U(e) {
	return { code: e };
}
function bt(e, t, n) {
	let r = xt(e, t, n, {
		handNo: 1,
		roundWind: 0,
		dealer: 0,
		honba: 0,
		kyoutaku: 0,
		scores: null,
		history: [],
		cursor: 0
	});
	if (e.ruleset === "riichi" && e.aka > 0) {
		let t = e.aka === 3 ? [
			4,
			13,
			22
		] : [
			4,
			13,
			13,
			22
		], n = [];
		for (let e of t) {
			let t = r.wall.find((t) => S(t) === e && !n.includes(t));
			t !== void 0 && n.push(t);
		}
		r.reds = n;
	}
	return { state: r };
}
function xt(t, n, r, i) {
	let a = H[t.ruleset], o = A(a.wallKind === "suit" ? M() : a.wallKind === "honor" ? j() : [...j(), ...Array.from({ length: 8 }, (e, t) => ({
		face: 34 + t,
		copies: 1
	}))]), s = i.cursor;
	for (let t = o.length - 1; t > 0; --t) {
		let n = e(r, s, t + 1);
		s += 1, [o[t], o[n]] = [o[n], o[t]];
	}
	let c = o.splice(o.length - yt), l = n.map((e, t) => ({
		rid: e,
		seat: t,
		hand: o.splice(0, 13),
		melds: [],
		discards: [],
		flowers: [],
		score: i.scores ? i.scores[t] : a.startScore,
		lack: null,
		won: !1,
		riichi: !1,
		riichiTurn: -1,
		riichiCalls: 0,
		furitenPerm: !1,
		furitenTemp: !1,
		kanNet: 0
	})), u = {
		config: t,
		seed: r,
		players: l,
		wall: o,
		deadWall: c,
		deadCursor: 0,
		doraRevealed: +(t.ruleset === "riichi"),
		reds: [],
		phase: "discard",
		turn: i.dealer,
		drawn: null,
		pending: null,
		handNo: i.handNo,
		roundWind: i.roundWind,
		dealer: i.dealer,
		honba: i.honba,
		kyoutaku: i.kyoutaku,
		afterKanDraw: !1,
		callsCount: 0,
		drawnCount: [
			0,
			0,
			0,
			0
		],
		firstDiscards: [
			-1,
			-1,
			-1,
			-1
		],
		swapGiven: {},
		swapDir: 0,
		turnSerial: 0,
		lastDrawWasLast: !1,
		winnersThisHand: [],
		firstWinnerSeat: -1,
		kanBy: [],
		handStartScores: l.map((e) => e.score),
		settle: null,
		history: i.history,
		confirmed: [],
		log: [],
		rngCursor: s
	};
	if (a.wallKind === "flower") for (let e of u.players) Ct(u, e);
	return t.ruleset === "sichuan" ? (u.phase = t.swap3 ? "swap" : "lack", t.swap3 && (u.swapDir = e(r, u.rngCursor, 3), u.rngCursor += 1)) : Et(u, i.dealer), u;
}
function St(e) {
	if (e.deadCursor < 4) {
		let t = e.deadWall[e.deadCursor];
		return e.deadCursor += 1, t;
	}
	return e.wall.pop() ?? null;
}
function Ct(e, t) {
	for (;;) {
		let n = t.hand.findIndex((e) => T(S(e)));
		if (n < 0) return;
		let [r] = t.hand.splice(n, 1);
		t.flowers.push(S(r));
		let i = St(e);
		if (i === null) return;
		t.hand.push(i);
	}
}
function wt(e, t) {
	let n = e.players[t];
	if (e.wall.length === 0) return !1;
	let r = e.wall.shift();
	for (e.lastDrawWasLast = e.wall.length === 0, e.drawnCount[t] += 1, e.turnSerial += 1; T(S(r));) {
		n.flowers.push(S(r)), W(e, "games.mahjong.log.flower", { name: n.rid });
		let t = St(e);
		if (t === null) return !1;
		r = t;
	}
	return n.hand.push(r), e.drawn = r, e.afterKanDraw = !1, n.furitenTemp = !1, !0;
}
function Tt(e, t) {
	let n = e.players[t], r = St(e);
	if (r === null) return !1;
	for (e.turnSerial += 1; T(S(r));) {
		n.flowers.push(S(r)), W(e, "games.mahjong.log.flower", { name: n.rid });
		let t = St(e);
		if (t === null) return !1;
		r = t;
	}
	return n.hand.push(r), e.drawn = r, e.afterKanDraw = !0, n.furitenTemp = !1, !0;
}
function W(e, t, n) {
	e.log.push({
		k: t,
		...n ? { p: n } : {}
	}), e.log.length > 100 && e.log.splice(0, e.log.length - 100);
}
function Et(e, t) {
	if (!wt(e, t)) {
		ln(e);
		return;
	}
	e.turn = t, e.phase = "discard";
}
function G(e) {
	return N(e.hand.map(S));
}
function Dt(e) {
	return e.melds.map((e) => ({
		type: e.type,
		faces: e.tiles.map(S),
		concealed: e.type === "kanClosed",
		from: e.from === null ? null : String(e.from)
	}));
}
function Ot(e, t) {
	if (e.config.ruleset === "sichuan" && t.lack) {
		let e = t.hand.filter((e) => C(S(e)) === t.lack);
		if (e.length > 0) return e;
	}
	return t.riichi ? e.drawn === null ? [] : [e.drawn] : [...t.hand];
}
function kt(e, t, n) {
	if (n === null) return !1;
	let r = e.slice();
	--r[S(n)];
	let i = ge(r, 0), a = e.slice();
	a[t] -= 4;
	let o = ge(a, 1);
	return JSON.stringify(i) === JSON.stringify(o);
}
function At(e, t) {
	if (!H[e.config.ruleset].hasRiichi || t.riichi || t.melds.length > 0 || t.score < 1e3 || e.wall.length < 4) return [];
	let n = [], r = G(t);
	for (let e of new Set(t.hand)) {
		let t = S(e);
		--r[t], he(r, 0) === 0 && n.push(e), r[t] += 1;
	}
	return n;
}
function jt(e, t, n) {
	let r = e.players[t];
	return H[e.config.ruleset].furiten ? r.furitenPerm || r.furitenTemp ? !0 : r.discards.some((e) => S(e.tile) === n) : !1;
}
function Mt(e) {
	return e < 27 ? e - e % 9 + (e % 9 + 1) % 9 : e <= 30 ? 27 + (e - 27 + 1) % 4 : e <= 33 ? 31 + (e - 31 + 1) % 3 : e;
}
function Nt(e) {
	let t = [], n = [];
	for (let r = 0; r < e.doraRevealed; r += 1) t.push(Mt(S(e.deadWall[4 + r * 2]))), n.push(Mt(S(e.deadWall[5 + r * 2])));
	return {
		dora: t,
		ura: n
	};
}
function Pt(e, t, n, r, i) {
	let a = e.players[t], o = G(a);
	r || (o[n] += 1);
	let { dora: s, ura: c } = Nt(e), l = [...a.hand.map(S), ...a.melds.flatMap((e) => e.tiles.map(S))];
	r || l.push(n);
	let u = a.riichi ? c : [];
	return {
		counts: o,
		winFace: n,
		tsumo: r,
		melds: Dt(a),
		seatWind: (t - e.dealer + 4) % 4,
		roundWind: e.roundWind,
		isDealer: t === e.dealer,
		isLastTile: r ? e.lastDrawWasLast : e.wall.length === 0,
		afterKan: r && e.afterKanDraw,
		afterKanDiscard: i.afterKanPao === !0,
		isRobKan: i.robKan === !0,
		isTenho: t === e.dealer && e.drawnCount[t] <= 1 && r && e.callsCount === 0,
		isChiiho: t !== e.dealer && e.drawnCount[t] <= 1 && r && e.callsCount === 0,
		riichi: {
			declared: a.riichi,
			ippatsu: a.riichi && e.callsCount === a.riichiCalls && e.turnSerial - a.riichiTurn <= 4,
			double: a.riichi && a.riichiTurn <= 1
		},
		dora: l.filter((e) => s.includes(e)).length,
		uraDora: l.filter((e) => u.includes(e)).length,
		redDora: [...a.hand, ...a.melds.flatMap((e) => e.tiles)].filter((t) => e.reds.includes(t)).length,
		menzen: a.melds.every((e) => e.type === "kanClosed"),
		flowers: a.flowers,
		visibleCounts: N([
			...e.players.flatMap((e) => e.discards.map((e) => S(e.tile))),
			...e.players.flatMap((e) => e.melds.flatMap((e) => e.tiles.map(S))),
			...e.players.flatMap((e) => e.flowers)
		])
	};
}
function Ft(e, t) {
	let n = e.config;
	return n.ruleset === "classic" ? Ae() : n.ruleset === "sichuan" ? _t(t) : n.ruleset === "mcr" ? rt(t) : n.ruleset === "hongkong" ? Me(t, n.minFan, n.cap) : dt(t, { kuitan: n.kuitan });
}
function It(e, t, n, r) {
	let i = e.players[t], a = G(i);
	a[n] += 1;
	let o = e.config.ruleset === "mcr" ? nt(a, i.melds.length) : de(a, i.melds.length);
	return --a[n], !o || e.config.ruleset === "sichuan" && i.lack && [
		...i.hand.map(S),
		...i.melds.flatMap((e) => e.tiles.map(S)),
		n
	].some((e) => C(e) === i.lack) || jt(e, t, n) ? !1 : Ft(e, Pt(e, t, n, !1, r)) !== null;
}
function Lt(e, t) {
	let n = e.players[t];
	if (e.drawn === null) return !1;
	let r = G(n);
	return !(e.config.ruleset === "mcr" ? nt(r, n.melds.length) : de(r, n.melds.length)) || e.config.ruleset === "sichuan" && n.lack && n.hand.some((e) => C(S(e)) === n.lack) ? !1 : Ft(e, Pt(e, t, S(e.drawn), !0, {})) !== null;
}
function Rt(e) {
	return H[e.config.ruleset].bloodBattle ? [
		0,
		1,
		2,
		3
	].filter((t) => !e.players[t].won) : [
		0,
		1,
		2,
		3
	];
}
function zt(e, t) {
	let n = Rt(e);
	for (let e = 1; e <= 4; e += 1) {
		let r = (t + e) % 4;
		if (n.includes(r)) return r;
	}
	return t;
}
function Bt(e, t, n) {
	let r = structuredClone(e), i = r.players.findIndex((e) => e.rid === n.by);
	if (i < 0) return U("games.mahjong.err.notPlayer");
	let a = [];
	switch (t.type) {
		case "chooseLack": {
			if (r.phase !== "lack" || r.config.ruleset !== "sichuan") return U("games.mahjong.err.badPhase");
			let e = r.players[i];
			return e.lack === null ? (e.lack = t.suit, W(r, "games.mahjong.log.lack", { name: e.rid }), r.players.every((e) => e.lack !== null) && Et(r, r.dealer), {
				state: r,
				fx: a
			}) : U("games.mahjong.err.badPhase");
		}
		case "swap": {
			if (r.phase !== "swap" || r.config.ruleset !== "sichuan" || !r.config.swap3) return U("games.mahjong.err.badPhase");
			let e = r.players[i];
			if (r.swapGiven[e.rid]) return U("games.mahjong.err.badPhase");
			if (new Set(t.tiles.map((e) => C(S(e)))).size !== 1) return U("games.mahjong.err.swapSameSuit");
			if (!t.tiles.every((t) => e.hand.includes(t))) return U("games.mahjong.err.noTile");
			if (r.swapGiven[e.rid] = t.tiles, Object.keys(r.swapGiven).length === 4) {
				let e = [
					1,
					2,
					3
				][r.swapDir], t = r.players.map((e) => r.swapGiven[e.rid]);
				for (let e of r.players) for (let t of r.swapGiven[e.rid]) e.hand.splice(e.hand.indexOf(t), 1);
				r.players.forEach((n, r) => n.hand.push(...t[(r + 4 - e) % 4])), W(r, "games.mahjong.log.swapped"), r.phase = "lack";
			}
			return {
				state: r,
				fx: a
			};
		}
		case "discard":
		case "riichi": {
			if (r.phase !== "discard" || r.turn !== i) return U("games.mahjong.err.notYourTurn");
			let e = r.players[i];
			return t.type === "riichi" && !At(r, e).includes(t.tile) ? U("games.mahjong.err.noRiichi") : Ot(r, e).includes(t.tile) ? (Vt(r, i, t.tile, t.type === "riichi"), {
				state: r,
				fx: a
			}) : U("games.mahjong.err.noTile");
		}
		case "selfHu": return r.phase !== "discard" || r.turn !== i ? U("games.mahjong.err.notYourTurn") : Lt(r, i) ? (an(r, [i], S(r.drawn), !0, null, a, {}), {
			state: r,
			fx: a
		}) : U("games.mahjong.err.noHu");
		case "kan": return r.phase !== "discard" || r.turn !== i ? U("games.mahjong.err.notYourTurn") : $t(r, i, t.kind, t.face, a);
		case "claim": return r.phase !== "claim" || !r.pending ? U("games.mahjong.err.badPhase") : rn(r, i, t, a);
		case "pass": {
			if (r.phase !== "claim" || !r.pending) return U("games.mahjong.err.badPhase");
			let e = r.pending;
			if (!Gt(r, e).includes(i) || e.responses[n.by]) return U("games.mahjong.err.badPhase");
			if (e.responses[n.by] = "pass", Kt(r, i, e)) {
				let e = r.players[i];
				e.riichi ? e.furitenPerm = !0 : e.furitenTemp = !0;
			}
			return qt(r, a), {
				state: r,
				fx: a
			};
		}
		case "ryukyoku": {
			if (r.config.ruleset !== "riichi") return U("games.mahjong.err.badPhase");
			if (r.phase !== "discard" || r.turn !== i) return U("games.mahjong.err.notYourTurn");
			let e = r.players[i];
			return r.drawnCount[i] !== 1 || r.callsCount > 0 || new Set(e.hand.map(S).filter((e) => e >= 27 || e % 9 == 0 || e % 9 == 8)).size < 9 ? U("games.mahjong.err.noRyukyoku") : (un(r, "games.mahjong.reason.kyushu"), {
				state: r,
				fx: a
			});
		}
		case "confirm": return r.phase !== "handEnd" || r.confirmed.includes(n.by) ? U("games.mahjong.err.badPhase") : (r.confirmed.push(n.by), r.confirmed.length === r.players.length && fn(r), {
			state: r,
			fx: a
		});
		default: return U("games.mahjong.err.badPhase");
	}
}
function Vt(e, t, n, r) {
	let i = e.players[t];
	if (i.hand.splice(i.hand.indexOf(n), 1), e.drawn === n && (e.drawn = null), i.discards.push({
		tile: n,
		riichi: r,
		claimed: !1
	}), e.config.ruleset === "riichi" && e.callsCount === 0 && e.firstDiscards.includes(-1) && (e.firstDiscards[t] = S(n), !e.firstDiscards.includes(-1))) {
		let n = e.firstDiscards[0];
		if (n >= 27 && n <= 30 && e.firstDiscards.every((e) => e === n)) {
			r && Ht(e, t), un(e, "games.mahjong.reason.suufon");
			return;
		}
	}
	r && (i.score -= 1e3, e.kyoutaku += 1);
	let a = Wt(e, t, n, r, null, e.afterKanDraw);
	a ? (e.phase = "claim", e.pending = a) : (r && Ht(e, t), Ut(e, t));
}
function Ht(e, t) {
	let n = e.players[t];
	n.riichi = !0, n.riichiTurn = e.turnSerial, n.riichiCalls = e.callsCount, W(e, "games.mahjong.log.riichi", { name: n.rid });
}
function Ut(e, t) {
	let n = zt(e, t);
	e.drawn = null, Et(e, n);
}
function Wt(e, t, n, r, i = null, a = !1) {
	let o = {
		tile: n,
		from: t,
		riichiTile: r,
		robKan: i,
		afterKanPao: a,
		responses: {},
		chiChoice: {}
	};
	return Gt(e, o).length > 0 ? o : null;
}
function Gt(e, t) {
	let n = S(t.tile), r = [];
	for (let i of Rt(e)) {
		if (i === t.from) continue;
		let a = e.players[i];
		if (Kt(e, i, t)) {
			r.push(i);
			continue;
		}
		if (t.robKan || a.riichi || e.wall.length === 0) continue;
		let o = G(a);
		(ae(o, n) || ie(o, n) || H[e.config.ruleset].hasChi && i === zt(e, t.from) && re(o, n).length > 0) && r.push(i);
	}
	return r;
}
function Kt(e, t, n) {
	return It(e, t, S(n.tile), {
		robKan: n.robKan !== null,
		afterKanPao: n.afterKanPao === !0
	});
}
function qt(e, t) {
	let n = e.pending;
	if (!n) return;
	let r = Gt(e, n);
	if (!r.every((t) => n.responses[e.players[t].rid])) return;
	let i = (t) => r.filter((r) => n.responses[e.players[r].rid] === t), a = i("hu");
	if (a.length > 0) {
		let r = e.config.ruleset === "sichuan" || e.config.ruleset === "mcr" || e.config.ruleset === "riichi" && e.config.multiRon, i = a;
		if (!r && a.length > 1 && (i = [a.sort((e, t) => (e - n.from + 4) % 4 - (t - n.from + 4) % 4)[0]]), n.riichiTile) {
			let t = e.players[n.from];
			t.score += 1e3, --e.kyoutaku;
			let r = t.discards[t.discards.length - 1];
			r.riichi &&= !1;
		}
		n.robKan && Jt(e, n.robKan), an(e, i, S(n.tile), !1, n.from, t, {
			robKan: n.robKan !== null,
			afterKanPao: n.afterKanPao
		}), e.pending = null;
		return;
	}
	let o = i("kan"), s = i("peng"), c = o[0] ?? s[0];
	if (c !== void 0) {
		Xt(e, n), e.pending = null, e.callsCount += 1, n.riichiTile && Ht(e, n.from), Zt(e, c, n, o.length > 0 ? "kanOpen" : "peng");
		return;
	}
	let l = i("chi");
	if (l.length > 0) {
		Xt(e, n), e.pending = null, e.callsCount += 1, n.riichiTile && Ht(e, n.from), Qt(e, l[0], n);
		return;
	}
	if (n.riichiTile && Ht(e, n.from), e.pending = null, n.robKan) {
		Yt(e, n.robKan);
		return;
	}
	Ut(e, n.from);
}
function Jt(e, t) {
	let n = e.players[t.by].melds.find((e) => e.type === "kanAdded" && S(e.tiles[0]) === t.face);
	n && (n.type = "peng", n.tiles = n.tiles.slice(0, 3));
}
function Yt(e, t) {
	if (e.kanBy.push(t.by), e.callsCount += 1, tn(e, t.by, null), en(e), e.config.ruleset === "riichi" && e.kanBy.length >= 4 && new Set(e.kanBy).size > 1) {
		un(e, "games.mahjong.reason.suukaikan");
		return;
	}
	if (!Tt(e, t.by)) {
		ln(e);
		return;
	}
	e.turn = t.by, e.phase = "discard";
}
function Xt(e, t) {
	let n = e.players[t.from].discards, r = n[n.length - 1];
	r && r.tile === t.tile && (r.claimed = !0);
}
function Zt(e, t, n, r) {
	let i = e.players[t], a = S(n.tile), o = r === "peng" ? 2 : 3, s = [];
	for (let e of [...i.hand]) {
		if (s.length >= o) break;
		S(e) === a && (i.hand.splice(i.hand.indexOf(e), 1), s.push(e));
	}
	if (i.melds.push({
		type: r,
		tiles: [...s, n.tile],
		from: n.from
	}), W(e, r === "peng" ? "games.mahjong.log.peng" : "games.mahjong.log.kan", { name: i.rid }), e.turn = t, e.drawn = null, e.phase = "discard", r === "kanOpen") {
		if (e.kanBy.push(t), tn(e, t, n.from), en(e), e.config.ruleset === "riichi" && e.kanBy.length >= 4 && new Set(e.kanBy).size > 1) {
			un(e, "games.mahjong.reason.suukaikan");
			return;
		}
		if (!Tt(e, t)) {
			ln(e);
			return;
		}
	}
}
function Qt(e, t, n) {
	let r = e.players[t], i = n.chiChoice[r.rid] ?? [];
	for (let e of i) {
		let t = r.hand.indexOf(e);
		t >= 0 && r.hand.splice(t, 1);
	}
	r.melds.push({
		type: "chi",
		tiles: [...i, n.tile],
		from: n.from
	}), W(e, "games.mahjong.log.chi", { name: r.rid }), e.turn = t, e.drawn = null, e.phase = "discard";
}
function $t(e, t, n, r, i) {
	let a = e.players[t], o = G(a);
	if (e.config.ruleset === "riichi" && e.kanBy.length >= 4) return U("games.mahjong.err.noKan");
	if (n === "an") {
		if (o[r] !== 4 || a.riichi && !kt(o, r, e.drawn)) return U("games.mahjong.err.noKan");
		let n = a.hand.filter((e) => S(e) === r);
		return a.hand = a.hand.filter((e) => S(e) !== r), a.melds.push({
			type: "kanClosed",
			tiles: n,
			from: null
		}), W(e, "games.mahjong.log.kanAn", { name: a.rid }), e.kanBy.push(t), e.callsCount += 1, tn(e, t, null), en(e), e.config.ruleset === "riichi" && e.kanBy.length >= 4 && new Set(e.kanBy).size > 1 ? (un(e, "games.mahjong.reason.suukaikan"), {
			state: e,
			fx: i
		}) : Tt(e, t) ? (e.turn = t, e.phase = "discard", {
			state: e,
			fx: i
		}) : (ln(e), {
			state: e,
			fx: i
		});
	}
	let s = a.melds.find((e) => e.type === "peng" && S(e.tiles[0]) === r);
	if (!s || o[r] < 1 || a.riichi) return U("games.mahjong.err.noKan");
	let c = a.hand.find((e) => S(e) === r);
	a.hand.splice(a.hand.indexOf(c), 1), s.type = "kanAdded", s.tiles.push(c), W(e, "games.mahjong.log.kanBu", { name: a.rid });
	let l = Wt(e, t, c, !1, {
		by: t,
		face: r
	});
	return l ? (e.pending = l, e.phase = "claim", {
		state: e,
		fx: i
	}) : (e.kanBy.push(t), e.callsCount += 1, tn(e, t, null), en(e), e.config.ruleset === "riichi" && e.kanBy.length >= 4 && new Set(e.kanBy).size > 1 ? (un(e, "games.mahjong.reason.suukaikan"), {
		state: e,
		fx: i
	}) : Tt(e, t) ? (e.turn = t, e.phase = "discard", {
		state: e,
		fx: i
	}) : (ln(e), {
		state: e,
		fx: i
	}));
}
function en(e) {
	e.config.ruleset === "riichi" && e.doraRevealed < 5 && (e.doraRevealed += 1);
}
function tn(e, t, n) {
	if (e.config.ruleset !== "sichuan") return;
	let r = e.players[t], i = n === null && r.melds[r.melds.length - 1]?.type === "kanClosed";
	if (n !== null) nn(e, n, t, 2);
	else if (i) for (let n of Rt(e)) n !== t && nn(e, n, t, 2);
	else for (let n of Rt(e)) n !== t && nn(e, n, t, 1);
}
function nn(e, t, n, r) {
	e.players[t].score -= r, e.players[n].score += r, e.players[n].kanNet += r, e.players[t].kanNet -= r;
}
function rn(e, t, n, r) {
	let i = e.pending, a = e.players[t];
	if (!Gt(e, i).includes(t) || i.responses[a.rid]) return U("games.mahjong.err.badPhase");
	let o = G(a), s = S(i.tile);
	switch (n.kind) {
		case "hu":
			if (!Kt(e, t, i)) return U("games.mahjong.err.noHu");
			i.responses[a.rid] = "hu";
			break;
		case "kan":
			if (i.robKan || a.riichi || e.wall.length === 0 || !ae(o, s)) return U("games.mahjong.err.noKan");
			i.responses[a.rid] = "kan";
			break;
		case "peng":
			if (i.robKan || a.riichi || e.wall.length === 0 || !ie(o, s)) return U("games.mahjong.err.noPeng");
			i.responses[a.rid] = "peng";
			break;
		case "chi": {
			if (i.robKan || a.riichi || e.wall.length === 0 || !H[e.config.ruleset].hasChi || t !== zt(e, i.from)) return U("games.mahjong.err.noChi");
			let r = n.tiles ?? [];
			if (r.length !== 2 || !r.every((e) => a.hand.includes(e))) return U("games.mahjong.err.noChi");
			let c = r.map(S).sort((e, t) => e - t);
			if (!re(o, s).some(([e, t]) => e === c[0] && t === c[1])) return U("games.mahjong.err.noChi");
			i.responses[a.rid] = "chi", i.chiChoice[a.rid] = r;
			break;
		}
	}
	return qt(e, r), {
		state: e,
		fx: r
	};
}
function an(e, t, n, r, i, a, o) {
	let s = [];
	for (let c of t) {
		let t = Ft(e, Pt(e, c, n, r, o));
		if (!t) continue;
		let l = sn(e, c, t, r, i);
		s.push({
			rid: e.players[c].rid,
			lines: t.lines,
			totalFan: t.totalFan,
			fu: t.fu ?? null,
			points: l,
			tsumo: r,
			from: i === null ? null : e.players[i].rid
		}), e.players[c].won = !0, e.firstWinnerSeat < 0 && (e.firstWinnerSeat = c), a.push({
			kind: r ? "tsumo" : "ron",
			rid: e.players[c].rid,
			data: { totalFan: t.totalFan }
		}), W(e, r ? "games.mahjong.log.tsumo" : "games.mahjong.log.ron", { name: e.players[c].rid });
	}
	if (t.length > 0 && e.kyoutaku > 0 && (e.players[t[0]].score += e.kyoutaku * 1e3, e.kyoutaku = 0), e.winnersThisHand.push(...t.map((t) => e.players[t].rid)), !H[e.config.ruleset].bloodBattle || Rt(e).length <= 1) dn(e, {
		kind: "win",
		winners: s,
		tenpai: [],
		reason: null
	});
	else {
		let n = Object.fromEntries(t.map((t) => [e.players[t].rid, e.players[t].hand.map(S).sort((e, t) => e - t)]));
		e.settle = {
			kind: "win",
			winners: s,
			deltas: on(e),
			tenpai: [],
			reason: null,
			hands: n
		}, e.drawn = null, Et(e, zt(e, i ?? e.turn));
	}
}
function on(e) {
	let t = {};
	return e.players.forEach((n, r) => {
		let i = n.score - e.handStartScores[r];
		i !== 0 && (t[n.rid] = i);
	}), t;
}
function sn(e, t, n, r, i) {
	let a = e.config, o = e.players[t], s = o.score, c = n.totalFan;
	if (a.ruleset === "classic") {
		if (r) for (let n of [
			0,
			1,
			2,
			3
		]) n !== t && (--e.players[n].score, o.score += 1);
		else i !== null && (--e.players[i].score, o.score += 1);
	} else if (a.ruleset === "sichuan") {
		let n = vt(c);
		if (r) {
			let r = a.zimoJiaDi ? n + 1 : n * 2;
			for (let n of Rt(e)) n !== t && (e.players[n].score -= r, o.score += r);
		} else i !== null && (e.players[i].score -= n, o.score += n);
	} else if (a.ruleset === "mcr") {
		let n = c + 8;
		for (let a of [
			0,
			1,
			2,
			3
		]) {
			if (a === t) continue;
			let s = r || a === i ? n : 8;
			e.players[a].score -= s, o.score += s;
		}
	} else if (a.ruleset === "hongkong") {
		let n = 2 ** Math.min(c, a.cap);
		for (let a of [
			0,
			1,
			2,
			3
		]) {
			if (a === t) continue;
			let s = r || a === i ? n * 2 : n;
			e.players[a].score -= s, o.score += s;
		}
	} else {
		let a = cn(n, o.seat === e.dealer);
		if (r) for (let n of [
			0,
			1,
			2,
			3
		]) {
			if (n === t) continue;
			let r = o.seat === e.dealer ? a.tsumoAll : e.players[n].seat === e.dealer ? a.tsumoDealer : a.tsumoChild;
			e.players[n].score -= r + e.honba * 100, o.score += r + e.honba * 100;
		}
		else if (i !== null) {
			let t = a.ron + e.honba * 300;
			e.players[i].score -= t, o.score += t;
		}
	}
	return o.score - s;
}
function cn(e, t) {
	let n = e.totalFan, r = e.fu ?? 20, i;
	i = n >= 13 ? 8e3 : n >= 11 ? 6e3 : n >= 8 ? 4e3 : n >= 6 ? 3e3 : n >= 5 || n === 4 && r >= 40 || n === 3 && r >= 70 ? 2e3 : r * 2 ** (2 + n);
	let a = (e) => Math.ceil(e / 100) * 100;
	return t ? {
		ron: a(i * 6),
		tsumoDealer: 0,
		tsumoChild: 0,
		tsumoAll: a(i * 2)
	} : {
		ron: a(i * 4),
		tsumoDealer: a(i * 2),
		tsumoChild: a(i),
		tsumoAll: 0
	};
}
function ln(e) {
	if (e.config.ruleset === "riichi") {
		let t = [], n = [];
		for (let r of [
			0,
			1,
			2,
			3
		]) {
			let i = e.players[r];
			he(G(i), i.melds.length) === 0 ? t.push(r) : n.push(r);
		}
		if (t.length > 0 && n.length > 0) {
			let r = Math.ceil(3e3 / n.length / 100) * 100, i = Math.ceil(3e3 / t.length / 100) * 100;
			for (let t of n) e.players[t].score -= r;
			for (let n of t) e.players[n].score += i;
		}
		dn(e, {
			kind: "draw",
			winners: [],
			tenpai: t.map((t) => e.players[t].rid),
			reason: "games.mahjong.reason.exhaustive"
		});
		return;
	}
	if (e.config.ruleset === "sichuan") {
		let t = [
			0,
			1,
			2,
			3
		].filter((t) => !e.players[t].won), n = [], r = [], i = [];
		for (let a of t) {
			let t = e.players[a];
			if (t.lack && t.hand.some((e) => C(S(e)) === t.lack)) {
				n.push(a);
				continue;
			}
			he(G(t), t.melds.length) === 0 ? r.push(a) : i.push(a);
		}
		for (let r of [...i, ...n]) {
			let n = e.players[r];
			if (n.kanNet <= 0) continue;
			let i = t.filter((e) => e !== r);
			if (i.length === 0) continue;
			let a = Math.floor(n.kanNet / i.length);
			for (let t of i) e.players[r].score -= a, e.players[t].score += a;
		}
		for (let t of r) {
			let n = e.players[t], r = G(n), a = 1;
			for (let i of ge(r, n.melds.length)) {
				if (n.lack && C(i) === n.lack) continue;
				let r = _t(Pt(e, t, i, !0, {}));
				r && (a = Math.max(a, vt(r.totalFan)));
			}
			for (let n of i) e.players[n].score -= a, e.players[t].score += a;
		}
		for (let r of n) for (let i of t) i === r || n.includes(i) || (e.players[r].score -= 32, e.players[i].score += 32);
		dn(e, {
			kind: "draw",
			winners: [],
			tenpai: r.map((t) => e.players[t].rid),
			reason: "games.mahjong.reason.exhaustive"
		});
		return;
	}
	dn(e, {
		kind: "draw",
		winners: [],
		tenpai: [],
		reason: "games.mahjong.reason.exhaustive"
	});
}
function un(e, t) {
	dn(e, {
		kind: "draw",
		winners: [],
		tenpai: [],
		reason: t
	});
}
function dn(e, t) {
	let n = Object.fromEntries(e.players.map((e) => [e.rid, e.hand.map(S).sort((e, t) => e - t)]));
	e.settle = {
		kind: t.kind,
		winners: t.winners,
		deltas: on(e),
		tenpai: t.tenpai,
		reason: t.reason,
		hands: n
	}, e.history.push(e.settle), e.phase = "handEnd", e.pending = null, e.confirmed = [], W(e, t.kind === "win" ? "games.mahjong.log.handEnd" : "games.mahjong.log.draw");
}
function fn(e) {
	let t = e.config;
	if (t.ruleset === "riichi" && e.players.some((e) => e.score < 0)) {
		e.phase = "done";
		return;
	}
	let n = e.dealer, r = e.roundWind, i = 0, a = e.settle, o = a?.kind === "win" && a.winners.some((t) => t.rid === e.players[e.dealer].rid), s = a?.kind === "draw" && a.tenpai.includes(e.players[e.dealer].rid);
	if (t.ruleset === "sichuan" ? n = e.firstWinnerSeat >= 0 ? e.firstWinnerSeat : e.dealer : t.ruleset === "riichi" ? o || s ? i = e.honba + 1 : (n = (e.dealer + 1) % 4, n === 0 && (r = e.roundWind + 1)) : !o && a?.kind === "win" && (n = (e.dealer + 1) % 4), t.ruleset === "riichi" ? r > (t.length === "east" ? 0 : 1) : e.handNo >= t.hands) {
		e.phase = "done";
		return;
	}
	let c = xt(t, e.players.map((e) => e.rid), e.seed, {
		handNo: e.handNo + 1,
		roundWind: r,
		dealer: n,
		honba: i,
		kyoutaku: e.kyoutaku,
		scores: e.players.map((e) => e.score),
		cursor: e.rngCursor,
		history: e.history
	});
	if (t.ruleset === "riichi" && t.aka > 0) {
		let e = t.aka === 3 ? [
			4,
			13,
			22
		] : [
			4,
			13,
			13,
			22
		], n = [];
		for (let t of e) {
			let e = c.wall.find((e) => S(e) === t && !n.includes(e));
			e !== void 0 && n.push(e);
		}
		c.reds = n;
	}
	Object.assign(e, c);
}
function pn(e, t) {
	let n = e.players.findIndex((e) => e.rid === t), r = {
		ruleset: e.config.ruleset,
		phase: e.phase,
		handNo: e.handNo,
		totalHands: e.config.ruleset === "riichi" ? e.config.length === "east" ? 4 : 8 : e.config.hands,
		roundWind: e.roundWind,
		dealer: e.players[e.dealer].rid,
		honba: e.honba,
		kyoutaku: e.kyoutaku,
		wallCount: e.wall.length,
		doraIndicators: e.deadWall.slice(4, 4 + e.doraRevealed * 2).filter((e, t) => t % 2 == 0).map(S),
		doraRed: e.deadWall.slice(4, 4 + e.doraRevealed * 2).filter((e, t) => t % 2 == 0).map((t) => e.reds.includes(t)),
		publicRedIds: e.reds.filter((t) => e.players.some((e) => e.discards.some((e) => e.tile === t))),
		turn: e.players[e.turn].rid,
		lastDiscard: e.pending ? {
			rid: e.players[e.pending.from].rid,
			tile: e.pending.tile
		} : null,
		pendingOn: e.phase === "claim" && e.pending ? Gt(e, e.pending).filter((t) => !e.pending?.responses[e.players[t].rid]).map((t) => e.players[t].rid) : [],
		players: e.players.map((t) => ({
			rid: t.rid,
			seat: t.seat,
			seatWind: (t.seat - e.dealer + 4) % 4,
			score: t.score,
			handCount: t.hand.length,
			melds: t.melds.map((t) => ({
				type: t.type,
				faces: t.tiles.map(S),
				reds: t.tiles.map((t) => e.reds.includes(t)),
				from: t.from === null ? null : e.players[t.from].rid
			})),
			discards: t.discards,
			flowers: t.flowers,
			riichi: t.riichi,
			won: t.won,
			lack: t.lack
		})),
		log: e.log,
		lastSettle: e.settle,
		history: e.history,
		confirmed: e.confirmed
	}, i = n >= 0 ? e.players[n] : null;
	return {
		public: r,
		private: {
			hand: i ? [...i.hand] : [],
			handRedIds: i ? i.hand.filter((t) => e.reds.includes(t)) : [],
			drawn: i && e.turn === n ? e.drawn : null,
			waits: n >= 0 ? hn(e, n) : null,
			can: n >= 0 ? gn(e, n) : mn()
		}
	};
}
function mn() {
	return {
		discard: !1,
		selfHu: !1,
		kans: [],
		riichi: null,
		claim: null,
		chooseLack: !1,
		swap: !1,
		ryukyoku: !1,
		confirm: !1
	};
}
function hn(e, t) {
	let n = e.players[t];
	if (n.won || (n.hand.length + n.melds.length * 3) % 3 != 1) return null;
	let r = G(n);
	if (e.config.ruleset === "mcr") {
		let e = [];
		for (let t = 0; t < 34; t += 1) r[t] >= 4 || (r[t] += 1, nt(r, n.melds.length) && e.push(t), --r[t]);
		return e.length > 0 ? e : null;
	}
	if (he(r, n.melds.length) !== 0) return null;
	let i = ge(r, n.melds.length);
	return e.config.ruleset === "sichuan" && (i = i.filter((n) => It(e, t, n, {}))), i;
}
function gn(e, t) {
	let n = e.players[t], r = mn();
	if (e.phase === "lack") return r.chooseLack = n.lack === null, r;
	if (e.phase === "swap") return r.swap = !e.swapGiven[n.rid], r;
	if (e.phase === "handEnd") return r.confirm = !e.confirmed.includes(n.rid), r;
	if (e.phase === "discard" && e.turn === t && !n.won) {
		r.discard = !0, r.selfHu = Lt(e, t);
		let i = G(n), a = oe(i, n.melds.filter((e) => e.type === "peng").map((e) => S(e.tiles[0])));
		if (r.kans = [...a.an.map((e) => ({
			kind: "an",
			face: e
		})), ...a.bu.map((e) => ({
			kind: "bu",
			face: e
		}))], e.config.ruleset === "riichi" && e.kanBy.length >= 4 && (r.kans = []), n.riichi && (r.kans = r.kans.filter((t) => t.kind === "an" && kt(i, t.face, e.drawn))), r.riichi = H[e.config.ruleset].hasRiichi ? At(e, n) : null, e.config.ruleset === "riichi") {
			let i = new Set(n.hand.map(S).filter((e) => e >= 27 || e % 9 == 0 || e % 9 == 8));
			r.ryukyoku = e.drawnCount[t] === 1 && e.callsCount === 0 && i.size >= 9;
		}
		return r;
	}
	if (e.phase === "claim" && e.pending && Gt(e, e.pending).includes(t) && !e.pending.responses[n.rid]) {
		let i = e.pending, a = G(n), o = S(i.tile), s = i.robKan !== null || n.riichi || e.wall.length === 0;
		return r.claim = {
			hu: Kt(e, t, i),
			kan: !s && ae(a, o),
			peng: !s && ie(a, o),
			chi: !s && H[e.config.ruleset].hasChi && t === zt(e, i.from) ? re(a, o).map(([e, t]) => {
				let r = n.hand.find((t) => S(t) === e);
				return [r, n.hand.find((e) => e !== r && S(e) === t)];
			}) : []
		}, r;
	}
	return r;
}
function _n(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((e, t) => t.score - e.score).map((e) => e.rid), n = {};
	for (let t of e.players) n[t.rid] = t.score;
	return {
		phase: "done",
		winner: [t[0]],
		ranking: t,
		scores: n
	};
}
var vn = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: F,
	schemas: {
		action: ye,
		publicView: De,
		privateView: ke,
		config: ve
	},
	setup: bt,
	reduce: Bt,
	viewFor: pn,
	status: _n
}, yn = [
	"一",
	"二",
	"三",
	"四",
	"五",
	"六",
	"七",
	"八",
	"九"
], bn = [
	"东",
	"南",
	"西",
	"北"
], K = {
	man: "var(--color-ink)",
	manWan: "var(--color-mj-pip-red)",
	dot: "var(--color-mj-pip-blue)",
	dotRed: "var(--color-mj-pip-red)",
	bamboo: "var(--color-mj-pip-green)",
	bambooRed: "var(--color-mj-pip-red)",
	wind: "var(--color-ink)",
	chun: "var(--color-mj-pip-red)",
	hatsu: "var(--color-mj-pip-green)",
	flower: "var(--color-mj-gold)",
	edge: "var(--color-mj-ivory-deep)",
	face: "var(--color-mj-ivory)",
	back: "var(--color-mj-back)",
	backMark: "var(--color-mj-gold)"
}, q = [
	11,
	20,
	29
], J = [
	12,
	28,
	44
], Y = [14, 26], X = [
	10,
	22,
	34,
	46
], xn = [
	[],
	[[q[0], J[0]], [q[2], J[2]]],
	[
		[q[0], J[0]],
		[q[1], J[1]],
		[q[2], J[2]]
	],
	[
		[q[0], J[0]],
		[q[2], J[0]],
		[q[0], J[2]],
		[q[2], J[2]]
	],
	[
		[q[0], J[0]],
		[q[2], J[0]],
		[q[1], J[1]],
		[q[0], J[2]],
		[q[2], J[2]]
	],
	[
		[Y[0], J[0]],
		[Y[1], J[0]],
		[Y[0], J[1]],
		[Y[1], J[1]],
		[Y[0], J[2]],
		[Y[1], J[2]]
	],
	[
		[q[0], 10],
		[q[0], 26],
		[q[1], 26],
		[q[2], 26],
		[q[0], 42],
		[q[1], 42],
		[q[2], 42]
	],
	[
		[Y[0], X[0]],
		[Y[1], X[0]],
		[Y[0], X[1]],
		[Y[1], X[1]],
		[Y[0], X[2]],
		[Y[1], X[2]],
		[Y[0], X[3]],
		[Y[1], X[3]]
	],
	[
		[q[0], J[0]],
		[q[1], J[0]],
		[q[2], J[0]],
		[q[0], J[1]],
		[q[1], J[1]],
		[q[2], J[1]],
		[q[0], J[2]],
		[q[1], J[2]],
		[q[2], J[2]]
	]
], Sn = [
	[],
	[[q[1], 14], [q[1], 42]],
	[
		[q[1], J[0]],
		[Y[0], J[2]],
		[Y[1], J[2]]
	],
	[
		[q[0], J[0]],
		[q[2], J[0]],
		[q[0], J[2]],
		[q[2], J[2]]
	],
	[
		[q[0], J[0]],
		[q[2], J[0]],
		[q[1], J[1]],
		[q[0], J[2]],
		[q[2], J[2]]
	],
	[
		[q[0], 16],
		[q[1], 16],
		[q[2], 16],
		[q[0], 40],
		[q[1], 40],
		[q[2], 40]
	],
	[
		[q[1], 10],
		[q[0], 26],
		[q[1], 26],
		[q[2], 26],
		[q[0], 42],
		[q[1], 42],
		[q[2], 42]
	],
	[
		[Y[0], X[0]],
		[Y[1], X[0]],
		[Y[0], X[1]],
		[Y[1], X[1]],
		[Y[0], X[2]],
		[Y[1], X[2]],
		[Y[0], X[3]],
		[Y[1], X[3]]
	],
	[
		[q[0], J[0]],
		[q[1], J[0]],
		[q[2], J[0]],
		[q[0], J[1]],
		[q[1], J[1]],
		[q[2], J[1]],
		[q[0], J[2]],
		[q[1], J[2]],
		[q[2], J[2]]
	]
];
function Cn({ rank: e, red: t }) {
	return e === 1 ? /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("circle", {
			cx: 20,
			cy: 28,
			r: 11,
			fill: "none",
			stroke: t ? K.dotRed : K.dot,
			strokeWidth: 3
		}),
		/* @__PURE__ */ m("circle", {
			cx: 20,
			cy: 28,
			r: 5,
			fill: t ? K.dotRed : K.dot
		}),
		/* @__PURE__ */ m("circle", {
			cx: 20,
			cy: 28,
			r: 2,
			fill: K.face
		})
	] }) : /* @__PURE__ */ m("g", { children: xn[e - 1].map(([n, r], i) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
		cx: n,
		cy: r,
		r: 4.2,
		fill: e === 5 && i === 4 || t ? K.dotRed : K.dot
	}), /* @__PURE__ */ m("circle", {
		cx: n,
		cy: r,
		r: 1.3,
		fill: K.face,
		opacity: .88
	})] }, i)) });
}
function wn({ rank: e, red: t }) {
	return e === 1 ? /* @__PURE__ */ h("g", {
		transform: "rotate(-12 20 28)",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M20 10c-6 4-11 2-11 11 5 0 7-2 11-5 4 3 6 5 11 5 0-9-5-7-11-11Z",
				fill: t ? K.bambooRed : K.bamboo
			}),
			/* @__PURE__ */ m("path", {
				d: "M20 16v29M14 29l6 5 6-5",
				fill: "none",
				stroke: K.bamboo,
				strokeWidth: 3.5,
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ m("path", {
				d: "M12 44h16",
				stroke: K.bambooRed,
				strokeWidth: 2
			})
		]
	}) : /* @__PURE__ */ m("g", { children: Sn[e - 1].map(([n, r], i) => /* @__PURE__ */ m("rect", {
		x: n - 2.5,
		y: r - 5,
		width: 5,
		height: 10,
		rx: 2.5,
		fill: e === 5 && i === 4 || e === 7 && i === 0 || t ? K.bambooRed : K.bamboo
	}, i)) });
}
function Tn({ face: e, red: t }) {
	if (e < 9) return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("text", {
		x: 20,
		y: 22,
		textAnchor: "middle",
		fontSize: 17,
		fontWeight: 700,
		fill: K.man,
		fontFamily: "serif",
		children: yn[e]
	}), /* @__PURE__ */ m("text", {
		x: 20,
		y: 44,
		textAnchor: "middle",
		fontSize: 16,
		fontWeight: 700,
		fill: K.manWan,
		fontFamily: "serif",
		children: "萬"
	})] });
	if (e < 18) return /* @__PURE__ */ m(Cn, {
		rank: e - 9 + 1,
		red: t
	});
	if (e < 27) return /* @__PURE__ */ m(wn, {
		rank: e - 18 + 1,
		red: t
	});
	if (e < 31) return /* @__PURE__ */ m("text", {
		x: 20,
		y: 37,
		textAnchor: "middle",
		fontSize: 22,
		fontWeight: 700,
		fill: K.wind,
		fontFamily: "serif",
		children: bn[e - 27]
	});
	if (e === 31) return /* @__PURE__ */ m("rect", {
		x: 9,
		y: 13,
		width: 22,
		height: 30,
		rx: 2,
		fill: "none",
		stroke: K.back,
		strokeWidth: 2.5
	});
	if (e === 32) return /* @__PURE__ */ m("text", {
		x: 20,
		y: 37,
		textAnchor: "middle",
		fontSize: 22,
		fontWeight: 700,
		fill: K.hatsu,
		fontFamily: "serif",
		children: "发"
	});
	if (e === 33) return /* @__PURE__ */ m("text", {
		x: 20,
		y: 37,
		textAnchor: "middle",
		fontSize: 22,
		fontWeight: 700,
		fill: K.chun,
		fontFamily: "serif",
		children: "中"
	});
	let n = [
		"春",
		"夏",
		"秋",
		"冬",
		"梅",
		"兰",
		"竹",
		"菊"
	][e - 34];
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("text", {
		x: 13,
		y: 17,
		textAnchor: "middle",
		fontSize: 10,
		fontWeight: 700,
		fill: K.flower,
		fontFamily: "serif",
		children: e - 33
	}), /* @__PURE__ */ m("text", {
		x: 20,
		y: 40,
		textAnchor: "middle",
		fontSize: 20,
		fontWeight: 700,
		fill: K.flower,
		fontFamily: "serif",
		children: n
	})] });
}
function En({ face: e, down: t, red: n }) {
	return t ? /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("rect", {
			x: 1,
			y: 4,
			width: 38,
			height: 52,
			rx: 4,
			fill: K.back,
			stroke: K.backMark,
			strokeWidth: .7
		}),
		/* @__PURE__ */ m("rect", {
			x: .5,
			y: .5,
			width: 39,
			height: 53,
			rx: 4,
			fill: K.back,
			stroke: "var(--color-mj-back-deep)",
			strokeWidth: 1.5
		}),
		/* @__PURE__ */ m("rect", {
			x: 3.5,
			y: 3.5,
			width: 33,
			height: 47,
			rx: 2.5,
			fill: "none",
			stroke: K.backMark,
			strokeWidth: .8,
			opacity: .8
		}),
		/* @__PURE__ */ m("path", {
			d: "M20 14 28 27 20 40 12 27Z",
			fill: "none",
			stroke: K.backMark,
			strokeWidth: 1.4
		}),
		/* @__PURE__ */ m("circle", {
			cx: 20,
			cy: 27,
			r: 3.4,
			fill: K.backMark
		})
	] }) : /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("rect", {
			x: 1,
			y: 4,
			width: 38,
			height: 52,
			rx: 4,
			fill: K.edge,
			stroke: "var(--color-mj-wood-deep)",
			strokeWidth: .8
		}),
		/* @__PURE__ */ m("rect", {
			x: .5,
			y: .5,
			width: 39,
			height: 53,
			rx: 3.5,
			fill: K.face,
			stroke: "var(--color-mj-wood-deep)",
			strokeWidth: 1
		}),
		/* @__PURE__ */ m("rect", {
			x: 3.5,
			y: 3.5,
			width: 33,
			height: 47,
			rx: 2,
			fill: "none",
			stroke: K.edge,
			strokeWidth: .7
		}),
		/* @__PURE__ */ m(Tn, {
			face: e,
			red: n
		}),
		n && /* @__PURE__ */ m("circle", {
			cx: 35,
			cy: 6,
			r: 3.2,
			fill: K.dotRed
		})
	] });
}
function Dn({ face: e, down: t, red: n, width: r, className: i, ariaLabel: a, onClick: o }) {
	let s = Math.round(r * 1.4), c = /* @__PURE__ */ m("svg", {
		viewBox: "0 0 40 56",
		width: r,
		height: s,
		className: `block ${i ?? ""}`,
		"aria-hidden": o ? !0 : void 0,
		role: o ? void 0 : "img",
		"aria-label": o ? void 0 : a,
		children: /* @__PURE__ */ m(En, {
			face: e,
			down: t,
			red: n
		})
	});
	return o ? /* @__PURE__ */ m("button", {
		type: "button",
		"aria-label": a,
		onClick: o,
		className: "block p-0 border-0 bg-transparent leading-none",
		children: c
	}) : c;
}
//#endregion
//#region src/games/mahjong/table-view.tsx
var Z = {
	felt: "var(--color-mj-felt)",
	deep: "var(--color-mj-felt-deep)",
	light: "var(--color-mj-felt-light)",
	wood: "var(--color-mj-wood)",
	woodDeep: "var(--color-mj-wood-deep)",
	gold: "var(--color-mj-gold)",
	ivory: "var(--color-mj-ivory)",
	ink: "var(--color-ink)",
	back: "var(--color-mj-back)"
};
function On({ x: e, y: t, width: n, face: r, down: i, red: a, ghost: o, highlight: s, riichi: c, claimed: l }) {
	let u = n / 40;
	return c ? /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t})`,
		opacity: l ? .36 : o ? .56 : 1,
		children: [/* @__PURE__ */ m("rect", {
			x: 0,
			y: n * .32,
			width: n,
			height: n * .76,
			rx: 2,
			fill: Z.gold,
			stroke: Z.ink,
			strokeWidth: s ? 2 : .7
		}), /* @__PURE__ */ m("g", {
			transform: `translate(${n / 2} ${n * .7}) rotate(-90) scale(${n / 56}) translate(-20 -28)`,
			children: /* @__PURE__ */ m(En, {
				face: r,
				down: i,
				red: a
			})
		})]
	}) : /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${u})`,
		opacity: l ? .36 : o ? .56 : 1,
		children: [s && /* @__PURE__ */ m("rect", {
			x: -3,
			y: -4,
			width: 46,
			height: 64,
			rx: 5,
			fill: Z.gold,
			stroke: Z.ink,
			strokeWidth: 1.5
		}), /* @__PURE__ */ m(En, {
			face: r,
			down: i,
			red: a
		})]
	});
}
function kn({ x: e, y: t, count: n, width: r, gap: i = 1.2 }) {
	return /* @__PURE__ */ m("g", { children: Array.from({ length: n }, (n, a) => /* @__PURE__ */ m(On, {
		x: e + a * (r + i),
		y: t,
		width: r,
		face: 0,
		down: !0
	}, a)) });
}
function An({ x: e, y: t, player: n, member: r, name: i, wind: a, active: o, dealer: s, self: c, compact: l, clipId: u, english: p }) {
	let g = l ? 17 : 21, _ = f[(r?.colorIndex ?? n.seat) % f.length].hex, v = r ? d[r.avatar % d.length] : void 0, y = g - 3, b = [
		n.riichi ? p ? "R" : "立" : "",
		n.won ? p ? "W" : "和" : "",
		n.lack ? n.lack.toUpperCase() : ""
	].filter(Boolean);
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t})`,
		opacity: r && !r.online ? .56 : 1,
		children: [
			o && /* @__PURE__ */ m("circle", {
				r: g + 5,
				fill: "none",
				stroke: Z.gold,
				strokeWidth: 2.8
			}),
			/* @__PURE__ */ m("circle", {
				cy: 3,
				r: g + 2,
				fill: Z.deep,
				opacity: .48
			}),
			/* @__PURE__ */ m("circle", {
				r: g + 1,
				fill: _,
				stroke: Z.gold,
				strokeWidth: 2.4
			}),
			v && /* @__PURE__ */ m("g", {
				transform: `scale(${g / 21})`,
				children: /* @__PURE__ */ m("image", {
					href: v,
					x: -19,
					y: -19,
					width: 38,
					height: 38,
					clipPath: `url(#${u})`
				})
			}),
			/* @__PURE__ */ m("rect", {
				x: -31,
				y,
				width: 62,
				height: l ? 22 : 25,
				rx: 10,
				fill: Z.ivory,
				stroke: Z.ink,
				strokeWidth: 1.8
			}),
			/* @__PURE__ */ m("text", {
				y: y + (l ? 15 : 17),
				textAnchor: "middle",
				fontSize: l ? 11 : 12,
				fontWeight: 800,
				fill: Z.ink,
				textLength: i.length > 5 ? 52 : void 0,
				lengthAdjust: "spacingAndGlyphs",
				children: i
			}),
			/* @__PURE__ */ h("text", {
				y: g + (l ? 28 : 31),
				textAnchor: "middle",
				fontSize: l ? 8.5 : 9.5,
				fontWeight: 700,
				fill: Z.ivory,
				children: [
					a,
					" · ",
					n.score
				]
			}),
			s && /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
				cx: -g + 1,
				cy: -g + 1,
				r: 9,
				fill: Z.gold,
				stroke: Z.ink,
				strokeWidth: 1.3
			}), /* @__PURE__ */ m("text", {
				x: -g + 1,
				y: -g + 4,
				textAnchor: "middle",
				fontSize: 9,
				fontWeight: 900,
				fill: Z.ink,
				children: p ? "D" : "庄"
			})] }),
			c && /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
				cx: g - 1,
				cy: -g + 1,
				r: 9,
				fill: "var(--color-mj-ivory)",
				stroke: Z.ink,
				strokeWidth: 1.3
			}), /* @__PURE__ */ m("text", {
				x: g - 1,
				y: -g + 4,
				textAnchor: "middle",
				fontSize: p ? 7 : 9,
				fontWeight: 900,
				fill: Z.ink,
				children: p ? "Me" : "我"
			})] }),
			b.map((e, t) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
				cx: -g - 3 + t * 12,
				cy: -g - 11,
				r: 6,
				fill: Z.gold,
				stroke: Z.ink,
				strokeWidth: 1
			}), /* @__PURE__ */ m("text", {
				x: -g - 3 + t * 12,
				y: -g - 8,
				textAnchor: "middle",
				fontSize: 7,
				fontWeight: 900,
				fill: Z.ink,
				children: e
			})] }, t))
		]
	});
}
function jn({ player: e, x: t, y: n, rotate: r = 0, wide: i, redIds: a, target: o, onOpen: s, label: c }) {
	let l = e.discards.length, u = l > 21 ? 8 : l > (i ? 12 : 18) ? 7 : 6, d = i ? l > 21 ? 4 : l > 12 ? 3 : 2 : l > 18 ? 4 : 3, f = i ? l > 21 ? 11 : l > 12 ? 12 : 14 : l > 21 ? 14 : l > 18 ? 16 : l > 12 ? 18 : 20, p = i ? 1 : 1.5, g = i ? 1.2 : 2, _ = u * d, v = Math.max(0, l - _), y = e.discards.slice(v), b = u * (f + p) - p, x = d * (f * 1.4 + g) - g;
	return /* @__PURE__ */ h("g", {
		transform: `translate(${t} ${n}) rotate(${r})`,
		role: "button",
		tabIndex: 0,
		"aria-label": `${c} · ${l}`,
		onClick: s,
		onKeyDown: (e) => {
			(e.key === "Enter" || e.key === " ") && (e.preventDefault(), s());
		},
		style: { cursor: "pointer" },
		children: [
			/* @__PURE__ */ m("rect", {
				x: -2,
				y: -2,
				width: b + 4,
				height: x + 4,
				rx: 4,
				fill: Z.deep,
				opacity: l > (i ? 12 : 18) ? .34 : 0
			}),
			y.map((e, t) => {
				let n = t % u * (f + p), r = Math.floor(t / u) * (f * 1.4 + g);
				return /* @__PURE__ */ m(On, {
					x: n,
					y: r,
					width: f,
					face: S(e.tile),
					red: a.includes(e.tile),
					highlight: o === e.tile,
					riichi: e.riichi,
					claimed: e.claimed
				}, `${e.tile}-${t}`);
			}),
			v > 0 && /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("rect", {
				x: 0,
				y: x - 16,
				width: 43,
				height: 15,
				rx: 7,
				fill: Z.gold,
				stroke: Z.ink,
				strokeWidth: 1
			}), /* @__PURE__ */ h("text", {
				x: 21.5,
				y: x - 5,
				textAnchor: "middle",
				fontSize: 9,
				fontWeight: 800,
				fill: Z.ink,
				children: ["+", v]
			})] }),
			/* @__PURE__ */ m("rect", {
				x: -2,
				y: -2,
				width: b + 4,
				height: x + 4,
				rx: 4,
				fill: "transparent"
			})
		]
	});
}
function Mn({ player: e, x: t, y: n, rotate: r = 0, reveal: i, compact: a }) {
	if (a) return null;
	let o = i ?? Array.from({ length: e.handCount }, () => 0), s = e.melds.flatMap((e) => e.faces), c = e.melds.flatMap((e) => e.reds), l = [
		...o,
		...s,
		...e.flowers
	].slice(0, 17);
	return /* @__PURE__ */ m("g", {
		transform: `translate(${t} ${n}) rotate(${r})`,
		children: l.map((e, t) => /* @__PURE__ */ m(On, {
			x: t * 13.3,
			y: 0,
			width: 12.5,
			face: e,
			down: !i && t < o.length,
			red: t >= o.length && !!c[t - o.length]
		}, t))
	});
}
function Nn({ x: e, y: t, compact: n, dense: r, english: i, roundLabel: a, wallLabel: o, honba: s, kyoutaku: c, dora: l }) {
	let u = n ? 66 : 94, d = n ? r ? 56 : 64 : 90;
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("rect", {
			x: e + 3,
			y: t + 5,
			width: u,
			height: d,
			rx: 12,
			fill: Z.deep,
			opacity: .4
		}),
		/* @__PURE__ */ m("rect", {
			x: e,
			y: t,
			width: u,
			height: d,
			rx: 12,
			fill: Z.wood,
			stroke: Z.woodDeep,
			strokeWidth: 2.3
		}),
		/* @__PURE__ */ m("rect", {
			x: e + 6,
			y: t + 6,
			width: u - 12,
			height: d - 12,
			rx: 8,
			fill: Z.deep,
			stroke: Z.gold,
			strokeWidth: 1.4
		}),
		/* @__PURE__ */ m("text", {
			x: e + u / 2,
			y: t + (n ? r ? 18 : 24 : 29),
			textAnchor: "middle",
			fontSize: n ? 10 : 12,
			fontWeight: 900,
			fill: Z.gold,
			children: a
		}),
		/* @__PURE__ */ m("text", {
			x: e + u / 2,
			y: t + (n ? r ? 39 : 48 : 60),
			textAnchor: "middle",
			fontFamily: "Baloo 2, monospace",
			fontSize: n ? 21 : 28,
			fontWeight: 800,
			fill: Z.ivory,
			children: o
		}),
		/* @__PURE__ */ m("text", {
			x: e + u / 2,
			y: t + d - (r && n ? 4 : 9),
			textAnchor: "middle",
			fontSize: r && n ? 7 : 9,
			fontWeight: 700,
			fill: Z.gold,
			children: s > 0 || c > 0 || l > 0 ? `${s ? `${i ? "H" : "本"}${s} ` : ""}${c ? `${i ? "K" : "供"}${c} ` : ""}${l ? `${i ? "D" : "宝"}${l}` : ""}` : i ? "Tiles" : "余牌"
		}),
		/* @__PURE__ */ m("circle", {
			cx: e + u / 2,
			cy: t - 4,
			r: 7,
			fill: Z.gold,
			stroke: Z.woodDeep,
			strokeWidth: 1.3
		}),
		/* @__PURE__ */ m("text", {
			x: e + u / 2,
			y: t - 1,
			textAnchor: "middle",
			fontSize: 8,
			fontWeight: 900,
			fill: Z.ink,
			children: i ? "E" : "东"
		})
	] });
}
function Pn({ wide: e, id: t, pub: n, members: r, myRid: i, nameOf: a, windOf: o, rulesetName: s, roundLabel: c, wallLabel: l, english: u, selectedFace: d, onOpenRiver: f }) {
	let p = n.players.find((e) => e.rid === i), g = p?.seat ?? 0, _ = (e) => (e.seat - g + 4) % 4, v = n.players.find((e) => _(e) === 2), y = n.players.find((e) => _(e) === 3), b = n.players.find((e) => _(e) === 1), x = n.players.some((t) => t.discards.length > (e ? 12 : 18)), ee = !e && !x && n.players.some((e) => e.discards.length > 12), S = (e, s, c, l) => e ? /* @__PURE__ */ m(An, {
		x: s,
		y: c,
		player: e,
		member: r.find((t) => t.rid === e.rid),
		name: a(e.rid),
		wind: o(e.seatWind),
		active: n.phase === "discard" && n.turn === e.rid,
		dealer: n.dealer === e.rid,
		self: e.rid === i,
		compact: l,
		clipId: `${t}-avatar`,
		english: u
	}) : null, C = (e) => n.phase === "handEnd" || n.phase === "done" ? n.lastSettle?.hands[e.rid] ?? null : null, w = (e) => n.lastDiscard?.rid === e.rid ? n.lastDiscard.tile : null, T = (t, r, i, o = 0) => t ? /* @__PURE__ */ m(jn, {
		player: t,
		x: r,
		y: i,
		rotate: o,
		wide: e,
		redIds: n.publicRedIds,
		target: w(t),
		onOpen: () => f(t.rid),
		label: a(t.rid)
	}) : null, E = x ? Math.min(3, n.wallCount) : Math.min(12, Math.ceil(n.wallCount / 4)), te = v && /* @__PURE__ */ m(Mn, {
		player: v,
		x: e ? 144 : 100,
		y: e ? 134 : 168,
		reveal: C(v),
		compact: x
	}), D = y && /* @__PURE__ */ m(Mn, {
		player: y,
		x: e ? 63 : 25,
		y: e ? 286 : 432,
		rotate: -90,
		reveal: C(y),
		compact: x
	}), O = b && /* @__PURE__ */ m(Mn, {
		player: b,
		x: e ? 359 : 350,
		y: e ? 168 : 252,
		rotate: 90,
		reveal: C(b),
		compact: x
	}), k = e ? {
		x: 6,
		y: 45,
		w: 410,
		h: 339,
		feltX: 17,
		feltY: 55,
		feltW: 388,
		feltH: 319
	} : {
		x: 5,
		y: 55,
		w: 365,
		h: 538,
		feltX: 21,
		feltY: 70,
		feltW: 333,
		feltH: 506
	}, ne = e ? {
		x: 178,
		y: x ? 190 : 198
	} : {
		x: 140.5,
		y: 305
	}, A = x ? e ? {
		top: [163, 119],
		left: [95, 268],
		right: [326, 173],
		bottom: [163, 252]
	} : {
		top: [126, 198],
		left: [27, 405],
		right: [348, 282],
		bottom: [126, 400]
	} : e ? {
		top: [165, 153],
		left: [110, 274],
		right: [312, 182],
		bottom: [165, 273]
	} : {
		top: [ee ? 130 : 120, 211],
		left: [44, 405],
		right: [331, 276],
		bottom: [ee ? 130 : 120, 400]
	};
	return /* @__PURE__ */ h("svg", {
		className: `mj-table-svg ${e ? "mj-table-svg--wide" : "mj-table-svg--portrait"}`,
		viewBox: e ? "0 25 422 374" : "0 55 375 540",
		preserveAspectRatio: "xMidYMid meet",
		role: "group",
		"aria-label": `${s} · ${c} · ${l}`,
		children: [
			/* @__PURE__ */ h("defs", { children: [
				/* @__PURE__ */ h("pattern", {
					id: `${t}-felt`,
					width: 10,
					height: 10,
					patternUnits: "userSpaceOnUse",
					children: [
						/* @__PURE__ */ m("rect", {
							width: 10,
							height: 10,
							fill: Z.felt
						}),
						/* @__PURE__ */ m("path", {
							d: "M0 3 3 0M5 10 10 5",
							stroke: "#c9e4bc",
							strokeWidth: .55,
							opacity: .11
						}),
						/* @__PURE__ */ m("circle", {
							cx: 6,
							cy: 3,
							r: .55,
							fill: "#e2f0d4",
							opacity: .12
						})
					]
				}),
				/* @__PURE__ */ h("pattern", {
					id: `${t}-wood`,
					width: 28,
					height: 28,
					patternUnits: "userSpaceOnUse",
					children: [/* @__PURE__ */ m("rect", {
						width: 28,
						height: 28,
						fill: Z.wood
					}), /* @__PURE__ */ m("path", {
						d: "M0 7c9 3 16-2 28 1M0 18c8 2 17-2 28 0",
						stroke: Z.gold,
						strokeWidth: .8,
						opacity: .24,
						fill: "none"
					})]
				}),
				/* @__PURE__ */ m("clipPath", {
					id: `${t}-avatar`,
					children: /* @__PURE__ */ m("circle", { r: 19 })
				})
			] }),
			/* @__PURE__ */ m("rect", {
				x: k.x,
				y: k.y,
				width: k.w,
				height: k.h,
				rx: e ? 11 : 15,
				fill: Z.woodDeep,
				stroke: Z.ink,
				strokeWidth: 2
			}),
			/* @__PURE__ */ m("rect", {
				x: k.x + 5,
				y: k.y + 4,
				width: k.w - 10,
				height: k.h - 9,
				rx: e ? 9 : 12,
				fill: `url(#${t}-wood)`,
				stroke: Z.gold,
				strokeWidth: 1
			}),
			/* @__PURE__ */ m("rect", {
				x: k.feltX - 4,
				y: k.feltY - 4,
				width: k.feltW + 8,
				height: k.feltH + 8,
				rx: 9,
				fill: Z.deep,
				stroke: Z.woodDeep,
				strokeWidth: 1
			}),
			/* @__PURE__ */ m("rect", {
				x: k.feltX,
				y: k.feltY,
				width: k.feltW,
				height: k.feltH,
				rx: 7,
				fill: `url(#${t}-felt)`,
				stroke: Z.light,
				strokeWidth: 1
			}),
			/* @__PURE__ */ m("rect", {
				x: e ? 25 : 28,
				y: e ? 60 : 78,
				width: e ? 67 : 79,
				height: e ? 19 : 22,
				rx: 9,
				fill: Z.deep,
				stroke: Z.gold,
				strokeWidth: 1
			}),
			/* @__PURE__ */ m("text", {
				x: e ? 58.5 : 67.5,
				y: e ? 74 : 93,
				textAnchor: "middle",
				fontSize: e ? 9 : 10,
				fontWeight: 800,
				fill: Z.ivory,
				children: s
			}),
			/* @__PURE__ */ m("rect", {
				x: e ? 330 : 269,
				y: e ? 60 : 78,
				width: e ? 66 : 78,
				height: e ? 19 : 22,
				rx: 9,
				fill: Z.deep,
				stroke: Z.gold,
				strokeWidth: 1
			}),
			/* @__PURE__ */ m("text", {
				x: e ? 363 : 308,
				y: e ? 74 : 93,
				textAnchor: "middle",
				fontSize: e ? 9 : 10,
				fontWeight: 800,
				fill: Z.ivory,
				children: l
			}),
			n.doraIndicators.length > 0 && /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("text", {
				x: e ? 307 : 244,
				y: e ? 98 : 127,
				textAnchor: "end",
				fontSize: e ? 8 : 9,
				fontWeight: 800,
				fill: Z.ivory,
				children: u ? "Dora" : "宝"
			}), n.doraIndicators.map((t, r) => /* @__PURE__ */ m(On, {
				x: (e ? 314 : 252) + r * (e ? 15 : 18),
				y: e ? 83 : 111,
				width: e ? 12 : 15,
				face: t,
				red: n.doraRed[r]
			}, r))] }),
			!x && /* @__PURE__ */ h("g", { children: [
				te,
				D,
				O,
				/* @__PURE__ */ m(kn, {
					x: e ? 144 : 102,
					y: e ? 134 : 190,
					count: E,
					width: e ? 12 : 13.2
				}),
				/* @__PURE__ */ m(kn, {
					x: e ? 144 : 102,
					y: e ? 315 : 500,
					count: E,
					width: e ? 12 : 13.2
				})
			] }),
			x && /* @__PURE__ */ m(kn, {
				x: e ? 25 : 164,
				y: e ? 113 : 174,
				count: E,
				width: 13.2
			}),
			T(v, A.top[0], A.top[1]),
			T(y, A.left[0], A.left[1], -90),
			T(b, A.right[0], A.right[1], 90),
			T(p, A.bottom[0], A.bottom[1]),
			d !== null && p && !e && /* @__PURE__ */ h("g", { children: [
				/* @__PURE__ */ m("rect", {
					x: 222,
					y: 433,
					width: 27,
					height: 36,
					rx: 5,
					fill: "none",
					stroke: Z.gold,
					strokeWidth: 1.5,
					strokeDasharray: "3 2"
				}),
				/* @__PURE__ */ m(On, {
					x: 224,
					y: 435,
					width: 23,
					face: d,
					ghost: !0
				}),
				/* @__PURE__ */ m("path", {
					d: "M187 480v-14m0 0-5 6m5-6 5 6",
					fill: "none",
					stroke: Z.gold,
					strokeWidth: 2.5,
					strokeLinecap: "round"
				})
			] }),
			/* @__PURE__ */ m(Nn, {
				x: ne.x,
				y: ne.y,
				compact: e,
				dense: x,
				english: u,
				roundLabel: c,
				wallLabel: String(n.wallCount),
				honba: n.honba,
				kyoutaku: n.kyoutaku,
				dora: n.doraIndicators.length
			}),
			S(v, e ? 211 : 187.5, e ? x ? 68 : 85 : 104, e),
			S(y, e ? 43 : 48, e ? 317 : 518, !0),
			S(b, e ? 379 : 327, e ? 317 : 518, !0),
			S(p, e ? 211 : 187.5, e ? 336 : 539, !0)
		]
	});
}
function Fn(e) {
	let t = n().replace(/:/g, ""), r = i(Rn, Ln, () => !1);
	return /* @__PURE__ */ m(Pn, {
		...e,
		wide: r,
		id: `mj-${t}`
	});
}
var In = "(orientation: landscape)";
function Ln() {
	return window.matchMedia(In).matches;
}
function Rn(e) {
	let t = window.matchMedia(In);
	return t.addEventListener("change", e), () => t.removeEventListener("change", e);
}
//#endregion
//#region src/games/mahjong/tile-names.ts
var zn = /* @__PURE__ */ "games.mahjong.tile.m1,games.mahjong.tile.m2,games.mahjong.tile.m3,games.mahjong.tile.m4,games.mahjong.tile.m5,games.mahjong.tile.m6,games.mahjong.tile.m7,games.mahjong.tile.m8,games.mahjong.tile.m9,games.mahjong.tile.p1,games.mahjong.tile.p2,games.mahjong.tile.p3,games.mahjong.tile.p4,games.mahjong.tile.p5,games.mahjong.tile.p6,games.mahjong.tile.p7,games.mahjong.tile.p8,games.mahjong.tile.p9,games.mahjong.tile.s1,games.mahjong.tile.s2,games.mahjong.tile.s3,games.mahjong.tile.s4,games.mahjong.tile.s5,games.mahjong.tile.s6,games.mahjong.tile.s7,games.mahjong.tile.s8,games.mahjong.tile.s9,games.mahjong.tile.we,games.mahjong.tile.ws,games.mahjong.tile.ww,games.mahjong.tile.wn,games.mahjong.tile.dw,games.mahjong.tile.dg,games.mahjong.tile.dr,games.mahjong.tile.f1,games.mahjong.tile.f2,games.mahjong.tile.f3,games.mahjong.tile.f4,games.mahjong.tile.f5,games.mahjong.tile.f6,games.mahjong.tile.f7,games.mahjong.tile.f8".split(","), Bn = {
	m: "games.mahjong.lack.m",
	p: "games.mahjong.lack.p",
	s: "games.mahjong.lack.s"
}, Vn = [
	"games.mahjong.wind.e",
	"games.mahjong.wind.s",
	"games.mahjong.wind.w",
	"games.mahjong.wind.n"
], Hn = {
	classic: "games.mahjong.opt.classic",
	sichuan: "games.mahjong.opt.sichuan",
	mcr: "games.mahjong.opt.mcr",
	hongkong: "games.mahjong.opt.hongkong",
	riichi: "games.mahjong.opt.riichi"
}, Un = {
	classic: "games.mahjong.ui.tags.classic",
	sichuan: "games.mahjong.ui.tags.sichuan",
	mcr: "games.mahjong.ui.tags.mcr",
	hongkong: "games.mahjong.ui.tags.hongkong",
	riichi: "games.mahjong.ui.tags.riichi"
};
function Wn(e) {
	return /* @__PURE__ */ m(u, {
		adaptive: !0,
		className: "mj-screen",
		scroll: !1,
		children: /* @__PURE__ */ m(Gn, {
			pub: e.public,
			priv: e.private,
			members: e.members,
			myRid: e.myRid,
			send: e.send
		})
	});
}
function Gn({ pub: e, priv: t, members: n, myRid: i, send: u }) {
	let d = l(), f = c((e) => e.locale), { ref: g } = o("table"), [_, v] = r(null), [y, b] = r([]), [x, ee] = r(!1), [w, T] = r(!1), [E, te] = r(null), D = t?.can, [O, k] = r(!!D?.discard);
	O !== !!D?.discard && (k(!!D?.discard), D?.discard || (v(null), ee(!1)));
	let [ne, A] = r(!!D?.claim);
	ne !== !!D?.claim && (A(!!D?.claim), D?.claim || T(!1));
	let j = e.players.find((e) => e.rid === i), M = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? a(t.rid) === null ? t.name : s(f, t.avatar) : e;
	}, N = (e) => d(zn[e]), re = e.ruleset === "riichi" ? d(e.roundWind === 0 ? "games.mahjong.status.roundEast" : "games.mahjong.status.roundSouth", { n: (e.handNo - 1) % 4 + 1 }) : d("games.mahjong.status.handNo", { n: e.handNo }), ie = d(Hn[e.ruleset]), ae = d("games.mahjong.status.wall", { n: e.wallCount }), oe = e.phase === "lack" ? d("games.mahjong.phase.lack") : e.phase === "swap" ? d("games.mahjong.phase.swap") : e.phase === "handEnd" ? d("games.mahjong.phase.handEnd") : e.phase === "done" ? d("games.mahjong.phase.done") : e.phase === "claim" ? D?.claim ? d("games.mahjong.ui.respond") : d("games.mahjong.claimWait") : D?.discard ? d("games.mahjong.turnYou") : d("games.mahjong.turnWait", { name: M(e.turn) }), se = (e) => {
		!D?.discard || x && !D.riichi?.includes(e) || (u(x ? {
			type: "riichi",
			tile: e
		} : {
			type: "discard",
			tile: e
		}), v(null), ee(!1));
	}, ce = (e) => {
		if (D?.swap) {
			y.includes(e) ? b(y.filter((t) => t !== e)) : y.length < 3 && (y.length === 0 || C(S(e)) === C(S(y[0]))) && b([...y, e]);
			return;
		}
		!D?.discard || x && !D.riichi?.includes(e) || (_ === e ? se(e) : v(e));
	}, P = _ !== null && t?.hand.includes(_) ? S(_) : null, le = e.players.find((e) => e.rid === E), ue = P === null ? "" : d("games.mahjong.ui.selectedTile", { tile: N(P) });
	return /* @__PURE__ */ h("div", {
		className: "mj-game",
		children: [
			/* @__PURE__ */ h("header", {
				className: "mj-hud",
				children: [
					/* @__PURE__ */ m("span", {
						className: "mj-hud-icon",
						"aria-hidden": !0,
						children: "萬"
					}),
					/* @__PURE__ */ h("div", {
						className: "mj-hud-copy",
						children: [/* @__PURE__ */ m("strong", { children: oe }), /* @__PURE__ */ h("span", { children: [
							ie,
							" · ",
							re
						] })]
					}),
					/* @__PURE__ */ m("span", {
						className: "mj-hud-side",
						children: e.phase === "claim" && e.lastDiscard ? N(S(e.lastDiscard.tile)) : e.phase === "discard" ? d("games.mahjong.ui.fourSeats") : ""
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "mj-workspace",
				children: [/* @__PURE__ */ h("div", {
					ref: g,
					className: "mj-stage",
					children: [/* @__PURE__ */ m(Fn, {
						pub: e,
						members: n,
						myRid: i,
						nameOf: M,
						windOf: (e) => d(Vn[e]),
						rulesetName: d(Un[e.ruleset]),
						roundLabel: re,
						wallLabel: ae,
						english: f === "en",
						selectedFace: P,
						onOpenRiver: te
					}), (e.phase === "handEnd" || e.phase === "done") && e.lastSettle && /* @__PURE__ */ h("div", {
						className: "mj-settle",
						children: [
							/* @__PURE__ */ m("strong", { children: e.lastSettle.kind === "win" ? d("games.mahjong.settle.winner", { name: e.lastSettle.winners.map((e) => M(e.rid)).join("、") }) : d(e.lastSettle.reason ?? "games.mahjong.reason.exhaustive") }),
							e.lastSettle.winners.map((e) => /* @__PURE__ */ h("div", {
								className: "mj-settle-row",
								children: [
									/* @__PURE__ */ h("span", { children: [
										M(e.rid),
										" · ",
										d(e.tsumo ? "games.mahjong.settle.tsumo" : "games.mahjong.settle.ron")
									] }),
									/* @__PURE__ */ h("b", { children: ["+", e.points] }),
									/* @__PURE__ */ h("small", { children: [d("games.mahjong.settle.fan", { n: e.totalFan }), e.fu === null ? "" : ` · ${d("games.mahjong.settle.fu", { n: e.fu })}`] }),
									/* @__PURE__ */ m("small", { children: e.lines.map((e) => `${d(e.key)} ${e.fan}${e.n === void 0 ? "" : `×${e.n}`}`).join(" · ") })
								]
							}, e.rid)),
							e.lastSettle.kind === "draw" && e.lastSettle.tenpai.length > 0 && /* @__PURE__ */ h("p", { children: [
								d("games.mahjong.settle.tenpai"),
								": ",
								e.lastSettle.tenpai.map(M).join("、")
							] }),
							/* @__PURE__ */ m("div", {
								className: "mj-settle-scores",
								children: e.players.map((t) => {
									let n = e.lastSettle?.deltas[t.rid] ?? 0;
									return /* @__PURE__ */ h("span", { children: [
										M(t.rid),
										" ",
										n >= 0 ? "+" : "",
										n
									] }, t.rid);
								})
							})
						]
					})]
				}), /* @__PURE__ */ h("div", {
					className: "mj-tray",
					children: [
						/* @__PURE__ */ h("div", {
							className: "mj-tray-heading",
							children: [/* @__PURE__ */ m("strong", { children: d("games.mahjong.ui.myHand") }), /* @__PURE__ */ m("span", { children: D?.swap ? `${y.length}/3 · ${d("games.mahjong.swap.prompt")}` : D?.discard ? d(P === null ? "games.mahjong.ui.pickTile" : "games.mahjong.ui.tapAgain") : t?.waits?.length ? `${d("games.mahjong.settle.tenpai")}: ${t.waits.map(N).join(" / ")}` : "" })]
						}),
						/* @__PURE__ */ h("div", {
							className: "mj-tray-sub",
							children: [/* @__PURE__ */ h("span", { children: [
								d(Vn[j?.seatWind ?? 0]),
								" · ",
								e.dealer === i ? d("games.mahjong.status.dealer") : d("games.mahjong.ui.player"),
								" ",
								j?.score ?? ""
							] }), /* @__PURE__ */ m("span", { children: j?.riichi ? d("games.mahjong.status.riichi") : j?.lack ? d("games.mahjong.lack.you", { suit: d(Bn[j.lack]) }) : "" })]
						}),
						/* @__PURE__ */ m("div", {
							className: "mj-hand-area",
							children: t && /* @__PURE__ */ m(Kn, {
								priv: t,
								can: D,
								selected: _,
								swapSelected: y,
								riichiArmed: x,
								onTap: ce,
								tileName: N,
								melds: j?.melds ?? [],
								flowers: j?.flowers ?? []
							})
						}),
						/* @__PURE__ */ m("div", {
							className: "mj-hint",
							"aria-live": "polite",
							children: ue || (t?.waits?.length ? `${d("games.mahjong.settle.tenpai")}: ${t.waits.map(N).join(" / ")}` : D?.claim && e.lastDiscard ? `${d("games.mahjong.ui.targetTile")}: ${N(S(e.lastDiscard.tile))}` : "")
						}),
						/* @__PURE__ */ h("div", {
							className: "mj-actions",
							children: [
								D?.chooseLack && [
									"m",
									"p",
									"s"
								].map((e) => /* @__PURE__ */ h("button", {
									className: "mj-action",
									onClick: () => u({
										type: "chooseLack",
										suit: e
									}),
									children: [
										d("games.mahjong.ui.void"),
										" ",
										d(Bn[e])
									]
								}, e)),
								D?.swap && /* @__PURE__ */ m("button", {
									className: "mj-action mj-action--primary",
									disabled: y.length !== 3,
									onClick: () => {
										y.length === 3 && (u({
											type: "swap",
											tiles: y
										}), b([]));
									},
									children: d("games.mahjong.hint.swap")
								}),
								D?.claim && /* @__PURE__ */ h(p, { children: [
									D.claim.hu && /* @__PURE__ */ m("button", {
										className: "mj-action mj-action--primary",
										onClick: () => u({
											type: "claim",
											kind: "hu"
										}),
										children: d("games.mahjong.act.hu")
									}),
									D.claim.kan && /* @__PURE__ */ m("button", {
										className: "mj-action",
										onClick: () => u({
											type: "claim",
											kind: "kan"
										}),
										children: d("games.mahjong.act.kan")
									}),
									D.claim.peng && /* @__PURE__ */ m("button", {
										className: "mj-action",
										onClick: () => u({
											type: "claim",
											kind: "peng"
										}),
										children: d("games.mahjong.act.peng")
									}),
									D.claim.chi.length === 1 && /* @__PURE__ */ m("button", {
										className: "mj-action",
										onClick: () => u({
											type: "claim",
											kind: "chi",
											tiles: D.claim?.chi[0]
										}),
										children: d("games.mahjong.act.chi")
									}),
									D.claim.chi.length > 1 && /* @__PURE__ */ m("button", {
										className: "mj-action",
										onClick: () => T(!w),
										children: d("games.mahjong.act.chi")
									}),
									/* @__PURE__ */ m("button", {
										className: "mj-action mj-action--quiet",
										onClick: () => {
											T(!1), u({ type: "pass" });
										},
										children: d("games.mahjong.act.pass")
									})
								] }),
								D?.discard && /* @__PURE__ */ h(p, { children: [
									D.selfHu && /* @__PURE__ */ m("button", {
										className: "mj-action mj-action--primary",
										onClick: () => u({ type: "selfHu" }),
										children: d("games.mahjong.act.tsumo")
									}),
									D.kans.map((e, t) => /* @__PURE__ */ h("button", {
										className: "mj-action",
										onClick: () => u({
											type: "kan",
											kind: e.kind,
											face: e.face
										}),
										children: [
											d(e.kind === "an" ? "games.mahjong.act.anKan" : "games.mahjong.act.buKan"),
											" ",
											N(e.face)
										]
									}, t)),
									D.riichi && D.riichi.length > 0 && /* @__PURE__ */ m("button", {
										className: `mj-action ${x ? "mj-action--armed" : ""}`,
										onClick: () => {
											ee(!x), v(null);
										},
										children: d("games.mahjong.act.riichi")
									}),
									D.ryukyoku && /* @__PURE__ */ m("button", {
										className: "mj-action mj-action--quiet",
										onClick: () => u({ type: "ryukyoku" }),
										children: d("games.mahjong.act.ryukyoku")
									}),
									/* @__PURE__ */ m("button", {
										className: "mj-action mj-action--primary",
										disabled: P === null,
										onClick: () => {
											_ !== null && se(_);
										},
										children: P === null ? d("games.mahjong.ui.pickToDiscard") : d("games.mahjong.hint.discard", { tile: N(P) })
									})
								] }),
								D?.confirm && /* @__PURE__ */ m("button", {
									className: "mj-action mj-action--primary",
									onClick: () => u({ type: "confirm" }),
									children: d("games.mahjong.act.confirm")
								}),
								e.phase === "handEnd" && !D?.confirm && /* @__PURE__ */ m("span", {
									className: "mj-action-note",
									children: d("games.mahjong.settle.confirmWait")
								})
							]
						}),
						w && D?.claim && /* @__PURE__ */ h("div", {
							className: "mj-chi-menu",
							children: [/* @__PURE__ */ m("strong", { children: d("games.mahjong.chiPick") }), D.claim.chi.map((e, t) => /* @__PURE__ */ m("button", {
								onClick: () => {
									u({
										type: "claim",
										kind: "chi",
										tiles: e
									}), T(!1);
								},
								children: e.map((e) => N(S(e))).join(" + ")
							}, t))]
						})
					]
				})]
			}),
			le && /* @__PURE__ */ m("div", {
				className: "mj-river-backdrop",
				onClick: () => te(null),
				children: /* @__PURE__ */ h("section", {
					className: "mj-river-sheet",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": `${M(le.rid)} ${d("games.mahjong.ui.river")}`,
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ h("strong", { children: [
						M(le.rid),
						" · ",
						d("games.mahjong.ui.river"),
						" ",
						le.discards.length
					] }), /* @__PURE__ */ m("button", {
						onClick: () => te(null),
						"aria-label": d("games.mahjong.ui.close"),
						children: "×"
					})] }), /* @__PURE__ */ m("div", {
						className: "mj-river-list",
						children: le.discards.map((t, n) => /* @__PURE__ */ h("div", {
							className: `mj-river-item ${t.claimed ? "mj-river-item--claimed" : ""}`,
							children: [/* @__PURE__ */ m(Dn, {
								face: S(t.tile),
								red: e.publicRedIds.includes(t.tile),
								width: 32,
								ariaLabel: N(S(t.tile))
							}), /* @__PURE__ */ h("small", { children: [n + 1, t.riichi ? ` · ${d("games.mahjong.status.riichi")}` : ""] })]
						}, `${t.tile}-${n}`))
					})]
				})
			})
		]
	});
}
function Kn({ priv: e, can: t, selected: n, swapSelected: r, riichiArmed: i, onTap: a, tileName: o, melds: s, flowers: c }) {
	let l = [...e.hand].sort((e, t) => S(e) - S(t) || e - t), u = e.drawn !== null && l.includes(e.drawn) ? e.drawn : null, d = u === null ? l : l.filter((e) => e !== u), f = s.reduce((e, t) => e + t.faces.length * 23 + 4, 0) + c.length * 23 + (c.length ? 4 : 0), p = Math.max(0, Math.floor((350 - f - 8) / 47)), g = Math.min(7, d.length, Math.max(d.length + (u === null ? 0 : 1) - 7, p)), _ = [d.slice(0, g), [...d.slice(g), ...u === null ? [] : [u]]];
	return /* @__PURE__ */ m("div", {
		className: "mj-hand-rows",
		children: _.map((l, d) => /* @__PURE__ */ h("div", {
			className: "mj-hand-row",
			children: [d === 0 && f > 0 && /* @__PURE__ */ h("div", {
				className: "mj-melds",
				children: [s.map((e, t) => /* @__PURE__ */ m(qn, {
					meld: e,
					tileName: o
				}, t)), c.map((e, t) => /* @__PURE__ */ m(Dn, {
					face: e,
					width: 22,
					ariaLabel: o(e)
				}, `f${t}`))]
			}), l.map((s) => {
				let c = s === u, l = n === s || r.includes(s), d = C(S(s)), f = t?.discard ? !i || !!t.riichi?.includes(s) : t?.swap ? d !== null && (r.length === 0 || r.includes(s) || r.length < 3 && d === C(S(r[0]))) : !1;
				return /* @__PURE__ */ m("button", {
					type: "button",
					className: `mj-hand-tile ${l ? "mj-hand-tile--selected" : ""} ${c ? "mj-hand-tile--drawn" : ""}`,
					"aria-label": o(S(s)),
					"aria-pressed": l,
					disabled: !f,
					onClick: () => a(s),
					children: /* @__PURE__ */ m(Dn, {
						face: S(s),
						red: e.handRedIds.includes(s),
						width: 40,
						ariaLabel: o(S(s))
					})
				}, s);
			})]
		}, d))
	});
}
function qn({ meld: e, tileName: t }) {
	return /* @__PURE__ */ m("div", {
		className: "mj-meld",
		children: e.faces.map((n, r) => /* @__PURE__ */ m(Dn, {
			face: n,
			red: e.reds[r],
			down: e.type === "kanClosed" && (r === 0 || r === e.faces.length - 1),
			width: 22,
			ariaLabel: t(n)
		}, r))
	});
}
//#endregion
//#region src/games/mahjong/bot.ts
function Q(e) {
	let t = Array(42).fill(0);
	for (let n of e) t[S(n)] += 1;
	return t;
}
var Jn = /* @__PURE__ */ new Map();
function $(e, t) {
	let n = e.join(",") + "|" + t, r = Jn.get(n);
	if (r !== void 0) return r;
	let i = he(e, t);
	return Jn.size > 2e4 && Jn.clear(), Jn.set(n, i), i;
}
function Yn(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Xn(e, t) {
	let n = Q(t.hand);
	for (let t of e.players) {
		for (let e of t.discards) n[S(e.tile)] += 1;
		for (let e of t.melds) for (let t of e.faces) n[t] += 1;
		for (let e of t.flowers) n[e] += 1;
	}
	for (let t of e.doraIndicators) n[t] += 1;
	return n;
}
function Zn(e) {
	let t = [];
	for (let n = 0; n < 34; n += 1) {
		if (e[n] > 0) {
			t.push(n);
			continue;
		}
		if (n >= 27) continue;
		let r = n % 9;
		(r > 0 && e[n - 1] > 0 || r < 8 && e[n + 1] > 0 || r > 1 && e[n - 2] > 0 || r < 7 && e[n + 2] > 0) && t.push(n);
	}
	return t;
}
function Qn(e, t, n) {
	let r = $(e, t), i = 0;
	for (let a of Zn(e)) {
		let o = 4 - n[a];
		o <= 0 || (e[a] += 1, $(e, t) < r && (i += o), --e[a]);
	}
	return i;
}
function $n(e, t, n) {
	if (t.has(e)) return 0;
	if (e >= 27) {
		let t = 4 - n[e];
		return t <= 0 ? 0 : t === 1 ? 1 : t === 2 ? 2 : 4;
	}
	let r = e % 9, i = r >= 3 && t.has(e - 3) || r <= 5 && t.has(e + 3), a = r === 0 || r === 8;
	return i ? a ? .5 : 1.5 : a ? 3 : r <= 1 || r >= 7 ? 4 : 6;
}
function er(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e.doraIndicators) n < 27 ? t.add(n % 9 == 8 ? n - 8 : n + 1) : n < 31 ? t.add(27 + (n - 27 + 1 + 4) % 4) : t.add(31 + (n - 31 + 1 + 3) % 3);
	return t;
}
function tr(e, t, n, r, i, a, o, s = 10) {
	let c = Q(e.hand), l = /* @__PURE__ */ new Map(), u = Infinity;
	for (let e of r) {
		let n = S(e);
		--c[n];
		let r = $(c, t);
		c[n] += 1, l.set(e, r), r < u && (u = r);
	}
	let d = r[0], f = -Infinity;
	for (let p of r) {
		let r = l.get(p), m = S(p), h = 0;
		r === u && r <= 1 && (--c[m], h = Qn(c, t, i), c[m] += 1);
		let g = -r * 1e3 + h * s;
		n && C(m) === n && (g += 500), m >= 27 ? g += c[m] === 1 ? 5 : -20 : (m % 9 == 0 || m % 9 == 8) && (g += 2), o?.has(m) && (g -= 25), a && (g -= a(m) * 8), e.drawn === p && (g -= .5), g > f && (f = g, d = p);
	}
	return d;
}
function nr(e, t, n, r) {
	let i = Q(e.hand), a = n[0], o = -Infinity;
	for (let e of n) {
		let n = S(e);
		--i[n];
		let s = $(i, t);
		i[n] += 1;
		let c = -r(n) * 1e3 - s;
		c > o && (o = c, a = e);
	}
	return a;
}
var rr = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = r.can, a = n.players.find((e) => e.rid === t.rid), o = a?.melds.length ?? 0, s = n.ruleset === "riichi" && t.difficulty !== "weak" ? n.players.filter((e) => e.rid !== t.rid && e.riichi && !e.won) : [];
	if (i.chooseLack) {
		let e = Q(r.hand), t = [
			"m",
			"p",
			"s"
		], n = t.map((t) => e.reduce((e, n, r) => e + (C(r) === t ? n : 0), 0));
		return { action: {
			type: "chooseLack",
			suit: t[n.indexOf(Math.min(...n))]
		} };
	}
	if (i.swap) {
		let e = [
			"m",
			"p",
			"s"
		].map((e) => r.hand.filter((t) => C(S(t)) === e)).map((e, t) => ({
			xs: e,
			i: t
		})).filter((e) => e.xs.length >= 3);
		e.sort((e, t) => e.xs.length - t.xs.length);
		let t = (e[0]?.xs ?? r.hand).slice(0, 3);
		return { action: {
			type: "swap",
			tiles: [
				t[0],
				t[1],
				t[2]
			]
		} };
	}
	if (i.claim) {
		let e = i.claim;
		if (e.hu) return { action: {
			type: "claim",
			kind: "hu"
		} };
		let t = Q(r.hand), c = Xn(n, r), l = $(t, o);
		if (s.length > 0 && l >= 2) return { action: { type: "pass" } };
		if (e.kan) {
			let e = a !== void 0 && n.players.every((e) => e.rid === a.rid || e.score < a.score);
			if (s.length === 0 && !e) return { action: {
				type: "claim",
				kind: "kan"
			} };
		}
		if (e.peng && n.lastDiscard) {
			let e = S(n.lastDiscard.tile), r = t.slice();
			r[e] -= 2;
			let i = $(r, o + 1);
			if (!(n.ruleset === "riichi" && o === 0 && l <= 1) && (i < l || i === l && o > 0)) return { action: {
				type: "claim",
				kind: "peng"
			} };
		}
		if (e.chi.length > 0 && l > 0) {
			let n = null, r = -Infinity;
			for (let i of e.chi) {
				let e = t.slice();
				--e[S(i[0])], --e[S(i[1])];
				let a = $(e, o + 1), s = -a * 100 + (a <= 1 ? Qn(e, o + 1, c) : 0);
				s > r && (r = s, n = i);
			}
			if (n && -r / 100 < l) return { action: {
				type: "claim",
				kind: "chi",
				tiles: n
			} };
		}
		return { action: { type: "pass" } };
	}
	if (i.confirm) return { action: { type: "confirm" } };
	if (i.discard) {
		if (i.selfHu) return { action: { type: "selfHu" } };
		if (i.riichi && i.riichi.length > 0) {
			let e = Xn(n, r), t = i.riichi[0], a = -1;
			for (let n of i.riichi) {
				let i = Q(r.hand);
				--i[S(n)], e[S(n)] += 1;
				let s = ge(i, o).reduce((t, n) => t + Math.max(0, 4 - e[n]), 0);
				--e[S(n)], s > a && (a = s, t = n);
			}
			if (s.length === 0 || a >= 4) return { action: {
				type: "riichi",
				tile: t
			} };
		}
		if (i.kans.length > 0 && t.difficulty !== "weak") {
			let e = $(Q(r.hand), o);
			if (a?.riichi || e > 0 && s.length === 0) {
				let e = i.kans[0];
				return { action: {
					type: "kan",
					kind: e.kind,
					face: e.face
				} };
			}
		}
		if (i.ryukyoku) return { action: { type: "ryukyoku" } };
		let e = a?.lack ?? null, c = a?.riichi && r.drawn !== null ? [r.drawn] : r.hand;
		if (e) {
			let t = c.filter((t) => C(S(t)) === e);
			t.length > 0 && (c = t);
		}
		if (t.difficulty === "weak") return { action: {
			type: "discard",
			tile: Yn(c)
		} };
		let l = Xn(n, r), u = n.doraIndicators.length > 0 ? er(n) : void 0, d = n.ruleset === "sichuan" && n.wallCount <= 12 && $(Q(r.hand), o) > 0 ? 20 : 10;
		if (s.length > 0) {
			let t = s.map((e) => new Set(e.discards.map((e) => S(e.tile)))), n = (e) => Math.max(...t.map((t) => $n(e, t, l)));
			return $(Q(r.hand), o) >= 2 ? { action: {
				type: "discard",
				tile: nr(r, o, c, n)
			} } : { action: {
				type: "discard",
				tile: tr(r, o, e, c, l, n, u)
			} };
		}
		return { action: {
			type: "discard",
			tile: tr(r, o, e, c, l, void 0, u, d)
		} };
	}
	return null;
}, ir = (e, t, n) => {
	switch (e.type) {
		case "discard": return n("games.mahjong.hint.discard", { tile: n(zn[S(e.tile)]) });
		case "riichi": return n("games.mahjong.hint.riichi", { tile: n(zn[S(e.tile)]) });
		case "selfHu": return n("games.mahjong.act.tsumo");
		case "ryukyoku": return n("games.mahjong.act.ryukyoku");
		case "confirm": return n("games.mahjong.act.confirm");
		case "pass": return n("games.mahjong.act.pass");
		case "chooseLack": return n("games.mahjong.hint.lack", { suit: n(Bn[e.suit]) });
		case "swap": return n("games.mahjong.hint.swap");
		case "kan": return n(e.kind === "an" ? "games.mahjong.act.anKan" : "games.mahjong.act.buKan") + " · " + n(zn[e.face]);
		case "claim": return n(e.kind === "hu" ? "games.mahjong.act.hu" : e.kind === "kan" ? "games.mahjong.act.kan" : e.kind === "peng" ? "games.mahjong.act.peng" : "games.mahjong.act.chi");
	}
}, ar = {
	tsumo(e, t) {
		let n = t.anchor("table");
		return n ? (v(), {
			ms: 1200,
			node: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(g, {
				ms: 420,
				className: "bg-done"
			}), /* @__PURE__ */ m(_, {
				at: n,
				ms: 1200,
				children: /* @__PURE__ */ m("span", {
					className: "rounded-lg border-2 border-ink bg-done-soft px-3 py-1 text-2xl font-extrabold text-done-ink shadow-[3px_3px_0_var(--color-ink)]",
					children: "🀄"
				})
			})] })
		}) : null;
	},
	ron(e, t) {
		let n = t.anchor("table");
		return n ? (v(), {
			ms: 1200,
			node: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(g, {
				ms: 420,
				className: "bg-warn"
			}), /* @__PURE__ */ m(_, {
				at: n,
				ms: 1200,
				children: /* @__PURE__ */ m("span", {
					className: "rounded-lg border-2 border-ink bg-warn-soft px-3 py-1 text-2xl font-extrabold text-warn-ink shadow-[3px_3px_0_var(--color-ink)]",
					children: "💥"
				})
			})] })
		}) : null;
	}
};
//#endregion
//#region src/games/mahjong/game-over.tsx
function or({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let a = l(), o = t, s = (e) => n.find((t) => t.rid === e)?.name ?? e, c = r ?? i;
	return /* @__PURE__ */ m("div", {
		className: "mj-over",
		children: /* @__PURE__ */ h("div", {
			className: "mj-over-scroll",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ m(y, {}),
				/* @__PURE__ */ h("h1", {
					className: "mj-over-title flex flex-none items-center gap-2 text-center font-display text-xl font-extrabold",
					children: [/* @__PURE__ */ m("span", {
						"aria-hidden": !0,
						children: F.icon
					}), a("session.result.title")]
				}),
				/* @__PURE__ */ m("div", {
					className: "mj-over-ranking flex w-full flex-none flex-col gap-1.5",
					children: e.ranking.map((t, n) => {
						let r = e.winner.includes(t);
						return /* @__PURE__ */ h("div", {
							className: "mj-over-seat plate flex items-center gap-2 px-2.5 py-1.5",
							children: [
								/* @__PURE__ */ m("span", {
									"aria-hidden": !0,
									className: `w-5 flex-none text-center ${r ? "" : "invisible"}`,
									children: "🏆"
								}),
								/* @__PURE__ */ h("span", {
									className: "mj-over-name min-w-0 flex-1 truncate text-sm font-extrabold",
									children: [
										n + 1,
										". ",
										s(t)
									]
								}),
								/* @__PURE__ */ m("span", {
									className: "mj-over-score flex-none font-mono text-lg font-extrabold tabular-nums",
									children: e.scores?.[t] ?? 0
								})
							]
						}, t);
					})
				}),
				o.history.length > 0 && /* @__PURE__ */ m("div", {
					className: "mj-over-history frame flex w-full flex-none flex-col gap-1 p-2",
					children: o.history.map((e, t) => /* @__PURE__ */ h("div", {
						className: "mj-over-history-row font-bold text-ink/70",
						children: [
							/* @__PURE__ */ m("span", {
								className: "font-mono tabular-nums",
								children: a("games.mahjong.status.handNo", { n: t + 1 })
							}),
							" · ",
							e.kind === "win" ? e.winners.map((e) => `${s(e.rid)} ${a(e.tsumo ? "games.mahjong.settle.tsumo" : "games.mahjong.settle.ron")} ${e.totalFan > 0 ? a("games.mahjong.settle.fan", { n: e.totalFan }) + " " : ""}+${e.points}`).join("、") : a("games.mahjong.settle.exhaustive")
						]
					}, t))
				}),
				c ? /* @__PURE__ */ h("div", {
					className: "mj-over-actions safe-b flex w-full flex-none flex-col gap-2 pb-1",
					children: [r && /* @__PURE__ */ m("button", {
						className: "btn-base w-full cursor-pointer text-white",
						style: { background: F.accent },
						onClick: r,
						children: a("session.result.playAgain")
					}), i && /* @__PURE__ */ m("button", {
						className: "btn-quiet w-full cursor-pointer",
						onClick: i,
						children: a("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ m("p", {
					className: "mj-over-wait flex-none text-sm font-bold text-ink/60",
					children: a("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/games/mahjong/options.tsx
var sr = [
	"classic",
	"sichuan",
	"mcr",
	"hongkong",
	"riichi"
], cr = {
	classic: "games.mahjong.opt.classic",
	sichuan: "games.mahjong.opt.sichuan",
	mcr: "games.mahjong.opt.mcr",
	hongkong: "games.mahjong.opt.hongkong",
	riichi: "games.mahjong.opt.riichi"
}, lr = {
	classic: {
		ruleset: "classic",
		hands: 4
	},
	sichuan: {
		ruleset: "sichuan",
		swap3: !1,
		zimoJiaDi: !0,
		hands: 4
	},
	mcr: {
		ruleset: "mcr",
		hands: 4
	},
	hongkong: {
		ruleset: "hongkong",
		minFan: 3,
		cap: 10,
		hands: 4
	},
	riichi: {
		ruleset: "riichi",
		length: "east",
		kuitan: !0,
		aka: 3,
		multiRon: !0
	}
};
function ur({ value: e, onChange: t }) {
	let n = l(), r = ve.safeParse(e), i = r.success ? r.data : ve.parse(void 0), a = (e) => t(e), o = (e, t, n) => /* @__PURE__ */ m(ee, {
		checked: t,
		label: e,
		accent: F.accent,
		onChange: n
	}), s = (e, t) => /* @__PURE__ */ m(x, {
		title: n("games.mahjong.opt.hands"),
		children: [
			1,
			4,
			8,
			16
		].map((r) => /* @__PURE__ */ m(b, {
			name: "mahjong-hands",
			value: String(r),
			checked: e === r,
			label: n("games.mahjong.opt.handsN", { n: r }),
			accent: F.accent,
			onChange: () => t(r)
		}, r))
	});
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ m(x, {
				title: n("games.mahjong.opt.ruleset"),
				children: sr.map((e) => /* @__PURE__ */ m("div", {
					onClick: i.ruleset === e ? () => a(lr[e]) : void 0,
					children: /* @__PURE__ */ m(b, {
						name: "mahjong-ruleset",
						value: e,
						checked: i.ruleset === e,
						label: n(cr[e]),
						accent: F.accent,
						onChange: () => a(lr[e])
					})
				}, e))
			}),
			i.ruleset === "sichuan" && /* @__PURE__ */ h(p, { children: [
				o(n("games.mahjong.opt.swap3"), i.swap3, () => a({
					...i,
					swap3: !i.swap3
				})),
				o(n("games.mahjong.opt.zimoJiaDi"), i.zimoJiaDi, () => a({
					...i,
					zimoJiaDi: !i.zimoJiaDi
				})),
				s(i.hands, (e) => a({
					...i,
					hands: e
				}))
			] }),
			i.ruleset === "classic" && s(i.hands, (e) => a({
				...i,
				hands: e
			})),
			i.ruleset === "mcr" && s(i.hands, (e) => a({
				...i,
				hands: e
			})),
			i.ruleset === "hongkong" && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m(x, {
					title: n("games.mahjong.opt.minFan"),
					columns: 3,
					children: [
						0,
						1,
						3
					].map((e) => /* @__PURE__ */ m(b, {
						name: "mahjong-min-fan",
						value: String(e),
						checked: i.minFan === e,
						label: n(e === 0 ? "games.mahjong.opt.minFan0" : "games.mahjong.opt.minFanN", { n: e }),
						accent: F.accent,
						onChange: () => a({
							...i,
							minFan: e
						})
					}, e))
				}),
				/* @__PURE__ */ m(x, {
					title: n("games.mahjong.opt.cap"),
					columns: 3,
					children: [
						8,
						10,
						13
					].map((e) => /* @__PURE__ */ m(b, {
						name: "mahjong-cap",
						value: String(e),
						checked: i.cap === e,
						label: n("games.mahjong.opt.capN", { n: e }),
						accent: F.accent,
						onChange: () => a({
							...i,
							cap: e
						})
					}, e))
				}),
				s(i.hands, (e) => a({
					...i,
					hands: e
				}))
			] }),
			i.ruleset === "riichi" && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m(x, {
					title: n("games.mahjong.opt.length"),
					children: ["east", "south"].map((e) => /* @__PURE__ */ m(b, {
						name: "mahjong-length",
						value: e,
						checked: i.length === e,
						label: n(e === "east" ? "games.mahjong.opt.east" : "games.mahjong.opt.south"),
						accent: F.accent,
						onChange: () => a({
							...i,
							length: e
						})
					}, e))
				}),
				o(n("games.mahjong.opt.kuitan"), i.kuitan, () => a({
					...i,
					kuitan: !i.kuitan
				})),
				o(n("games.mahjong.opt.multiRon"), i.multiRon, () => a({
					...i,
					multiRon: !i.multiRon
				})),
				/* @__PURE__ */ m(x, {
					title: n("games.mahjong.opt.aka"),
					columns: 3,
					children: [
						0,
						3,
						4
					].map((e) => /* @__PURE__ */ m(b, {
						name: "mahjong-aka",
						value: String(e),
						checked: i.aka === e,
						label: n("games.mahjong.opt.akaN", { n: e }),
						accent: F.accent,
						onChange: () => a({
							...i,
							aka: e
						})
					}, e))
				})
			] })
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/mahjong/entry.tsx
var dr = {
	definition: vn,
	View: Wn,
	bot: rr,
	describe: ir,
	fx: ar,
	OverView: or,
	Options: ur,
	locales: {
		zh: {
			name: "麻将",
			desc: "推倒和 / 四川血战 / 国标 / 香港 / 日麻,五种规则一桌开打",
			rules: "目标:通过摸打凑成和牌型(4 组面子加 1 对雀头,或七对、十三幺等特殊型),\n按规则集番种计分,总分最高者获胜。\n共通流程:\n· 每人起手 13 张(庄家 14 张),轮流摸一张打一张。\n· 他人打出的牌,可按规则吃(仅下家)/碰/杠/和;多家要和时按规则集裁定。\n· 自己回合可暗杠、加杠;杠后从牌墙末尾补牌。\n推倒和:\n· 最经典的吃碰杠玩法,不计番种;自摸三家各付 1 分,点炮由放铳者付 1 分。\n四川血战到底:\n· 开局选定一门缺门,和牌时手牌不得含缺门;无字牌、不可吃。\n· 一家和牌后不离场,余下玩家继续打,直到三家和牌或牌摸完。\n· 流局时查大叫:未听牌者按听牌者最大番赔付,花猪(未缺完)赔满番。\n国标麻将:\n· 81 个番种,8 番起和,自摸三家各付。\n香港麻将:\n· 清章计番,可选鸡和/一番/三番起和,大四喜等大牌直接爆棚。\n日麻(立直):\n· 门清听牌可宣言立直,立直后只能打出摸到的牌;有振听(舍牌/同巡/立直后见逃)。\n· 和牌需有役,另计符;有宝牌/里宝牌/红宝牌;流局不听罚符。",
			phase: {
				lack: "定缺中",
				swap: "换三张中",
				play: "对局中",
				handEnd: "本局结束",
				done: "全场结束"
			},
			turnYou: "轮到你出牌",
			turnYouDrew: "轮到你出牌(可自摸/杠)",
			ui: {
				tags: {
					classic: "推倒和",
					sichuan: "四川血战",
					mcr: "国标麻将",
					hongkong: "香港麻将",
					riichi: "日麻立直"
				},
				respond: "请选择响应",
				fourSeats: "四方牌桌",
				myHand: "我的手牌",
				player: "玩家",
				tapAgain: "已选中 · 再点牌或按按钮打出",
				pickTile: "摸牌独立 · 点一张牌选择",
				selectedTile: "{{tile}}已选中 · 自家牌河可见落点预览",
				targetTile: "目标牌",
				void: "缺",
				pickToDiscard: "选择一张牌打出",
				river: "完整牌河",
				close: "关闭"
			},
			turnWait: "等 {{name}} 出牌…",
			claimWait: "等其他玩家响应…",
			riichiLocked: "已立直:只能打摸到的牌",
			act: {
				chi: "吃",
				peng: "碰",
				kan: "杠",
				hu: "和",
				pass: "过",
				tsumo: "自摸",
				riichi: "立直",
				anKan: "暗杠",
				buKan: "加杠",
				ryukyoku: "流局",
				confirm: "下一局"
			},
			chiPick: "选择吃法",
			lack: {
				prompt: "选择定缺花色:本局和牌时不能含有它",
				you: "你缺 {{suit}}",
				other: "{{name}} 缺 {{suit}}",
				m: "万",
				p: "筒",
				s: "条"
			},
			swap: {
				prompt: "选 3 张同花色牌交给别家",
				waiting: "换三张:等其他玩家选牌…"
			},
			status: {
				wall: "余 {{n}}",
				honba: "{{n}} 本场",
				kyoutaku: "供托 ×{{n}}",
				dora: "宝牌指示",
				roundEast: "东 {{n}} 局",
				roundSouth: "南 {{n}} 局",
				handNo: "第 {{n}} 局",
				riichi: "已立直",
				won: "已和",
				dealer: "庄",
				concealed: "暗牌"
			},
			badge: {
				riichi: "立",
				won: "和"
			},
			settle: {
				fan: "{{n}} 番",
				fu: "{{n}} 符",
				points: "{{n}} 分",
				tsumo: "自摸",
				ron: "点炮",
				exhaustive: "流局",
				tenpai: "听牌",
				noten: "未听",
				next: "下一局",
				confirmWait: "等其他玩家确认…",
				winner: "{{name}} 和牌"
			},
			wind: {
				e: "东",
				s: "南",
				w: "西",
				n: "北"
			},
			tile: {
				m1: "一万",
				m2: "二万",
				m3: "三万",
				m4: "四万",
				m5: "五万",
				m6: "六万",
				m7: "七万",
				m8: "八万",
				m9: "九万",
				p1: "一筒",
				p2: "二筒",
				p3: "三筒",
				p4: "四筒",
				p5: "五筒",
				p6: "六筒",
				p7: "七筒",
				p8: "八筒",
				p9: "九筒",
				s1: "一条",
				s2: "二条",
				s3: "三条",
				s4: "四条",
				s5: "五条",
				s6: "六条",
				s7: "七条",
				s8: "八条",
				s9: "九条",
				we: "东风",
				ws: "南风",
				ww: "西风",
				wn: "北风",
				dw: "白板",
				dg: "发财",
				dr: "红中",
				f1: "春",
				f2: "夏",
				f3: "秋",
				f4: "冬",
				f5: "梅",
				f6: "兰",
				f7: "竹",
				f8: "菊"
			},
			opt: {
				ruleset: "规则集",
				classic: "推倒和",
				sichuan: "四川血战到底",
				mcr: "国标麻将",
				hongkong: "香港麻将",
				riichi: "日麻(立直)",
				hands: "局数",
				handsN: "{{n}} 局",
				swap3: "换三张",
				zimoJiaDi: "自摸加底(关为加番)",
				minFan: "起和番",
				minFan0: "鸡和(0 番起和)",
				minFanN: "{{n}} 番起和",
				cap: "爆棚上限",
				capN: "{{n}} 番",
				length: "赛制",
				east: "东风战",
				south: "半庄战",
				kuitan: "食断(断幺可副露)",
				aka: "红宝牌",
				akaN: "{{n}} 张",
				multiRon: "一炮多响"
			},
			err: {
				notPlayer: "你不是本局玩家",
				badPhase: "现在不能这么做",
				notYourTurn: "还没轮到你",
				noTile: "手里没有这张牌",
				noChi: "吃不了这张牌",
				noPeng: "碰不了这张牌",
				noKan: "杠不了这张牌",
				noHu: "这副牌和不了",
				noRiichi: "现在不能立直",
				noRyukyoku: "现在不能宣言流局",
				swapSameSuit: "换三张必须是同一花色"
			},
			hint: {
				discard: "打出 {{tile}}",
				riichi: "立直,打出 {{tile}}",
				lack: "定缺 {{suit}}",
				swap: "换出这 3 张"
			},
			log: {
				chi: "{{name}} 吃",
				peng: "{{name}} 碰",
				kan: "{{name}} 杠",
				kanAn: "{{name}} 暗杠",
				kanBu: "{{name}} 加杠",
				riichi: "{{name}} 立直!",
				tsumo: "{{name}} 自摸",
				ron: "{{name}} 和",
				flower: "{{name}} 补花",
				lack: "{{name}} 定缺",
				swapped: "换三张完成",
				handEnd: "本局结束",
				draw: "流局"
			},
			reason: {
				exhaustive: "牌墙摸完",
				kyushu: "九种九牌",
				suufon: "四风连打",
				suukaikan: "四杠散了"
			},
			fan: {
				sc: {
					pinghu: "平胡",
					qidui: "七对",
					pengpenghu: "碰碰胡",
					qingyise: "清一色",
					jingoudiao: "金钩钓",
					tianhu: "天和",
					dihu: "地和",
					gangshanghua: "杠上花",
					qianggang: "抢杠",
					haidilao: "海底捞月",
					hedilao: "河底捞鱼",
					gangshangpao: "杠上炮",
					gen: "根"
				},
				mcr: {
					dasixi: "大四喜",
					dasanyuan: "大三元",
					lvyise: "绿一色",
					jiulian: "九莲宝灯",
					sigang: "四杠",
					lianqidui: "连七对",
					shisanyao: "十三幺",
					qingyaojiu: "清幺九",
					xiaosixi: "小四喜",
					xiaosanyuan: "小三元",
					ziyise: "字一色",
					sianke: "四暗刻",
					yishuanglong: "一色双龙会",
					sitongshun: "一色四同顺",
					sijiegao: "一色四节高",
					sibugao: "一色四步高",
					sangang: "三杠",
					hunyaojiu: "混幺九",
					qidui: "七对",
					qixing: "七星不靠",
					quanshuangke: "全双刻",
					qingyise: "清一色",
					santongshun: "一色三同顺",
					sanjiegao: "一色三节高",
					quanda: "全大",
					quanzhong: "全中",
					quanxiao: "全小",
					qinglong: "清龙",
					sanshuanglong: "三色双龙会",
					sanbugao: "一色三步高",
					quandaiwu: "全带五",
					santongke: "三同刻",
					sananke: "三暗刻",
					quanbukao: "全不靠",
					zuhelong: "组合龙",
					dayuwu: "大于五",
					xiaoyuwu: "小于五",
					sanfengke: "三风刻",
					hualong: "花龙",
					tuibudao: "推不倒",
					stongsan: "三色三同顺",
					sanjiesan: "三色三节高",
					wufanhu: "无番和",
					miaoshou: "妙手回春",
					haidilao: "海底捞月",
					gangshanghua: "杠上开花",
					qianggang: "抢杠和",
					pengpenghu: "碰碰和",
					hunyise: "混一色",
					ssanbugao: "三色三步高",
					wumenqi: "五门齐",
					quanqiuren: "全求人",
					shuangangang: "双暗杠",
					shuangjianke: "双箭刻",
					quandaiyao: "全带幺",
					buqiuren: "不求人",
					shuangminggang: "双明杠",
					hejuezhang: "和绝张",
					jianke: "箭刻",
					quanfengke: "圈风刻",
					menfengke: "门风刻",
					menqianqing: "门前清",
					pinghu: "平和",
					siguiyi: "四归一",
					shuangtongke: "双同刻",
					shuanganke: "双暗刻",
					angang: "暗杠",
					duanyao: "断幺",
					yibangao: "一般高",
					xixiangfeng: "喜相逢",
					lianliu: "连六",
					laoshaofu: "老少副",
					yaojiuke: "幺九刻",
					minggang: "明杠",
					queyimen: "缺一门",
					wuzi: "无字",
					bianzhang: "边张",
					kanzhang: "坎张",
					dandiao: "单钓将",
					zimo: "自摸",
					huapai: "花牌"
				},
				hk: {
					pinghu: "平胡",
					zimo: "自摸",
					menqianqing: "门清",
					huapai: "花牌",
					pengpenghu: "对对胡",
					hunyise: "混一色",
					xiaosanyuan: "小三元",
					hunyaojiu: "混幺九",
					qingyise: "清一色",
					dasanyuan: "大三元",
					xiaosixi: "小四喜",
					qidui: "七对子",
					dasixi: "大四喜",
					ziyise: "字一色",
					qingyaojiu: "清幺九",
					shisanyao: "十三幺",
					jiulian: "九莲宝灯",
					tianhu: "天和",
					dihu: "地和",
					gangshanghua: "杠上开花",
					qianggang: "抢杠",
					haidilao: "海底捞月",
					hediyu: "河底捞鱼"
				},
				riichi: {
					riichi: "立直",
					doubleRiichi: "双立直",
					ippatsu: "一发",
					tsumo: "门前清自摸",
					pinfu: "平和",
					tanyao: "断幺九",
					iipeikou: "一杯口",
					ryanpeikou: "二杯口",
					yakuhaiDragon: "役牌·三元牌",
					yakuhaiWind: "役牌·风牌",
					sanshokuDoujun: "三色同顺",
					sanshokuDoukou: "三色同刻",
					ikkitsuukan: "一气通贯",
					chiitoitsu: "七对子",
					toitoi: "对对和",
					sanankou: "三暗刻",
					sankantsu: "三杠子",
					honroutou: "混老头",
					shousangen: "小三元",
					chanta: "混全带幺九",
					junchan: "纯全带幺九",
					honiisou: "混一色",
					chiniisou: "清一色",
					haitei: "海底摸月",
					houtei: "河底捞鱼",
					rinshan: "岭上开花",
					chankan: "抢杠",
					dora: "宝牌",
					tenho: "天和",
					chiiho: "地和",
					kokushi: "国士无双",
					suuankou: "四暗刻",
					daisangen: "大三元",
					daisuushii: "大四喜",
					tsuuiisou: "字一色",
					ryuuiisou: "绿一色",
					chinroutou: "清老头",
					churen: "九莲宝灯",
					suukantsu: "四杠子"
				}
			}
		},
		en: {
			name: "Mahjong",
			desc: "Classic, Sichuan Bloody, MCR, Hong Kong and Riichi — five rulesets at one table",
			rules: "Goal: build a winning hand (4 melds plus 1 pair, or special shapes like Seven Pairs and Thirteen Orphans) through draws and discards;\nscore by the chosen ruleset and finish with the most points.\nCommon flow:\n· Each player starts with 13 tiles (dealer 14); take turns drawing one and discarding one.\n· You may chi (next player only) / peng / kan / hu on a discard, subject to the ruleset; simultaneous wins follow ruleset tiebreaks.\n· On your turn you may declare concealed or added kans; after a kan you draw a supplement tile from the dead wall.\nClassic (Chicken Hand):\n· The traditional chi/peng/kan game with no scoring patterns: a self-drawn win collects 1 point from each opponent; a discard win is paid 1 point by the discarder.\nSichuan Bloody Battle:\n· At the start each player picks a void suit; the winning hand must not contain it; no honor tiles, no chi.\n· A player who wins steps aside; the rest play on until three players have won or the wall runs out.\n· On exhaustion, non-ready players pay ready players by their best fan; players who failed to void pay the maximum.\nMCR (Chinese Official):\n· 81 fan patterns, 8 fan minimum to win; on a self-drawn win all three opponents pay.\nHong Kong:\n· Clean-pattern scoring; optional 0/1/3 fan minimum; limit hands (e.g. Big Four Winds) score the cap directly.\nRiichi (Japanese):\n· With a closed ready hand you may declare riichi; afterwards you must discard the drawn tile; furiten applies (discard / same-turn / post-riichi pass).\n· A win requires at least one yaku, plus fu calculation; dora / ura dora / red fives apply; exhaustive draw costs non-ready players a noten penalty.",
			phase: {
				lack: "Choosing void suit",
				swap: "Swapping tiles",
				play: "Playing",
				handEnd: "Hand over",
				done: "Match over"
			},
			turnYou: "Your turn — discard a tile",
			turnYouDrew: "Your turn (tsumo/kan available)",
			ui: {
				tags: {
					classic: "Classic",
					sichuan: "Sichuan",
					mcr: "MCR",
					hongkong: "Hong Kong",
					riichi: "Riichi"
				},
				respond: "Choose a response",
				fourSeats: "Four seats",
				myHand: "My hand",
				player: "Player",
				tapAgain: "Selected · tap again or press discard",
				pickTile: "Drawn tile is separate · tap to select",
				selectedTile: "{{tile}} selected · preview on your river",
				targetTile: "Target tile",
				void: "Void",
				pickToDiscard: "Select a tile to discard",
				river: "Full discard river",
				close: "Close"
			},
			turnWait: "Waiting for {{name}} to discard…",
			claimWait: "Waiting for other players…",
			riichiLocked: "Riichi: you must discard the drawn tile",
			act: {
				chi: "Chi",
				peng: "Peng",
				kan: "Kan",
				hu: "Hu",
				pass: "Pass",
				tsumo: "Tsumo",
				riichi: "Riichi",
				anKan: "Concealed kan",
				buKan: "Added kan",
				ryukyoku: "Abortive draw",
				confirm: "Next hand"
			},
			chiPick: "Pick a chi combination",
			lack: {
				prompt: "Pick your void suit: your winning hand must not contain it",
				you: "Your void: {{suit}}",
				other: "{{name}} voids {{suit}}",
				m: "Characters",
				p: "Dots",
				s: "Bamboo"
			},
			swap: {
				prompt: "Pick 3 tiles of one suit to pass on",
				waiting: "Tile swap: waiting for other players…"
			},
			status: {
				wall: "{{n}} left",
				honba: "{{n}} honba",
				kyoutaku: "Riichi sticks ×{{n}}",
				dora: "Dora indicator",
				roundEast: "East {{n}}",
				roundSouth: "South {{n}}",
				handNo: "Hand {{n}}",
				riichi: "Riichi",
				won: "Won",
				dealer: "Dealer",
				concealed: "Concealed tile"
			},
			badge: {
				riichi: "R",
				won: "W"
			},
			settle: {
				fan: "{{n}} fan",
				fu: "{{n}} fu",
				points: "{{n}} pts",
				tsumo: "Tsumo",
				ron: "Ron",
				exhaustive: "Exhaustive draw",
				tenpai: "Tenpai",
				noten: "Noten",
				next: "Next hand",
				confirmWait: "Waiting for confirmations…",
				winner: "{{name}} wins"
			},
			wind: {
				e: "East",
				s: "South",
				w: "West",
				n: "North"
			},
			tile: {
				m1: "1 of Characters",
				m2: "2 of Characters",
				m3: "3 of Characters",
				m4: "4 of Characters",
				m5: "5 of Characters",
				m6: "6 of Characters",
				m7: "7 of Characters",
				m8: "8 of Characters",
				m9: "9 of Characters",
				p1: "1 of Dots",
				p2: "2 of Dots",
				p3: "3 of Dots",
				p4: "4 of Dots",
				p5: "5 of Dots",
				p6: "6 of Dots",
				p7: "7 of Dots",
				p8: "8 of Dots",
				p9: "9 of Dots",
				s1: "1 of Bamboo",
				s2: "2 of Bamboo",
				s3: "3 of Bamboo",
				s4: "4 of Bamboo",
				s5: "5 of Bamboo",
				s6: "6 of Bamboo",
				s7: "7 of Bamboo",
				s8: "8 of Bamboo",
				s9: "9 of Bamboo",
				we: "East wind",
				ws: "South wind",
				ww: "West wind",
				wn: "North wind",
				dw: "White dragon",
				dg: "Green dragon",
				dr: "Red dragon",
				f1: "Spring",
				f2: "Summer",
				f3: "Autumn",
				f4: "Winter",
				f5: "Plum",
				f6: "Orchid",
				f7: "Bamboo",
				f8: "Chrysanthemum"
			},
			opt: {
				ruleset: "Ruleset",
				classic: "Classic (Chicken Hand)",
				sichuan: "Sichuan Bloody Battle",
				mcr: "MCR (Chinese Official)",
				hongkong: "Hong Kong",
				riichi: "Riichi (Japanese)",
				hands: "Hands",
				handsN: "{{n}} hands",
				swap3: "Tile swap (swap 3)",
				zimoJiaDi: "Tsumo bonus base (off = bonus fan)",
				minFan: "Minimum fan",
				minFan0: "Chicken hand (0 fan)",
				minFanN: "{{n}} fan minimum",
				cap: "Limit cap",
				capN: "{{n}} fan",
				length: "Match length",
				east: "East round",
				south: "South round (hanchan)",
				kuitan: "Open tanyao (kuitan)",
				aka: "Red fives",
				akaN: "{{n}} tiles",
				multiRon: "Multi-ron (double/triple ron)"
			},
			err: {
				notPlayer: "You are not in this game",
				badPhase: "Not allowed right now",
				notYourTurn: "Not your turn yet",
				noTile: "That tile is not in your hand",
				noChi: "Cannot chi that tile",
				noPeng: "Cannot peng that tile",
				noKan: "Cannot kan that tile",
				noHu: "That hand cannot win",
				noRiichi: "Cannot declare riichi now",
				noRyukyoku: "Cannot declare an abortive draw now",
				swapSameSuit: "The 3 swapped tiles must share one suit"
			},
			hint: {
				discard: "Discard {{tile}}",
				riichi: "Riichi and discard {{tile}}",
				lack: "Void {{suit}}",
				swap: "Pass these 3 tiles"
			},
			log: {
				chi: "{{name}} chi",
				peng: "{{name}} peng",
				kan: "{{name}} kan",
				kanAn: "{{name}} concealed kan",
				kanBu: "{{name}} added kan",
				riichi: "{{name}} riichi!",
				tsumo: "{{name}} tsumo",
				ron: "{{name}} ron",
				flower: "{{name}} draws a flower",
				lack: "{{name}} picks a void suit",
				swapped: "Tile swap done",
				handEnd: "Hand over",
				draw: "Exhaustive draw"
			},
			reason: {
				exhaustive: "Wall exhausted",
				kyushu: "Nine terminals initial draw",
				suufon: "Four winds discarded",
				suukaikan: "Four kans declared"
			},
			fan: {
				sc: {
					pinghu: "All sequences",
					qidui: "Seven pairs",
					pengpenghu: "All triplets",
					qingyise: "Full flush",
					jingoudiao: "Golden hook",
					tianhu: "Heavenly hand",
					dihu: "Earthly hand",
					gangshanghua: "Win after kan",
					qianggang: "Robbing a kan",
					haidilao: "Last tile tsumo",
					hedilao: "Last tile ron",
					gangshangpao: "Kan discard ron",
					gen: "Root (per kan)"
				},
				mcr: {
					dasixi: "Big Four Winds",
					dasanyuan: "Big Three Dragons",
					lvyise: "All Green",
					jiulian: "Nine Gates",
					sigang: "Four Kongs",
					lianqidui: "Seven Shifted Pairs",
					shisanyao: "Thirteen Orphans",
					qingyaojiu: "All Terminals",
					xiaosixi: "Little Four Winds",
					xiaosanyuan: "Little Three Dragons",
					ziyise: "All Honors",
					sianke: "Four Concealed Pungs",
					yishuanglong: "Pure Double Dragon",
					sitongshun: "Quadruple Chow",
					sijiegao: "Four Shifted Pungs",
					sibugao: "Four-Step Chow",
					sangang: "Three Kongs",
					hunyaojiu: "All Terminals and Honors",
					qidui: "Seven Pairs",
					qixing: "Seven-Star Without",
					quanshuangke: "All Even Pungs",
					qingyise: "Full Flush",
					santongshun: "Triple Chow",
					sanjiegao: "Three Shifted Pungs",
					quanda: "All High",
					quanzhong: "All Middle",
					quanxiao: "All Low",
					qinglong: "Pure Straight",
					sanshuanglong: "Mixed Double Dragon",
					sanbugao: "Three-Step Chow",
					quandaiwu: "All Fives",
					santongke: "Triple Pung",
					sananke: "Three Concealed Pungs",
					quanbukao: "All Without",
					zuhelong: "Combination Dragon",
					dayuwu: "Above Five",
					xiaoyuwu: "Below Five",
					sanfengke: "Three Wind Pungs",
					hualong: "Flower Dragon",
					tuibudao: "Reversible Tiles",
					stongsan: "Mixed Triple Chow",
					sanjiesan: "Mixed Shifted Pungs",
					wufanhu: "Chicken Hand",
					miaoshou: "Last Tile Draw",
					haidilao: "Last Tile Claim",
					gangshanghua: "Out with Replacement",
					qianggang: "Robbing the Kong",
					pengpenghu: "All Pungs",
					hunyise: "Half Flush",
					ssanbugao: "Mixed Three-Step Chow",
					wumenqi: "Five Types",
					quanqiuren: "All Chows from Others",
					shuangangang: "Two Concealed Kongs",
					shuangjianke: "Two Dragon Pungs",
					quandaiyao: "Outside Hand",
					buqiuren: "Fully Concealed",
					shuangminggang: "Two Melded Kongs",
					hejuezhang: "Last of Its Kind",
					jianke: "Dragon Pung",
					quanfengke: "Prevalent Wind",
					menfengke: "Seat Wind",
					menqianqing: "Concealed Hand",
					pinghu: "All Chows",
					siguiyi: "Tile Hog",
					shuangtongke: "Double Pung",
					shuanganke: "Two Concealed Pungs",
					angang: "Concealed Kong",
					duanyao: "All Simples",
					yibangao: "Pure Double Chow",
					xixiangfeng: "Mixed Double Chow",
					lianliu: "Short Straight",
					laoshaofu: "Two Terminal Chows",
					yaojiuke: "Terminal/Honor Pung",
					minggang: "Melded Kong",
					queyimen: "One Voided Suit",
					wuzi: "No Honors",
					bianzhang: "Edge Wait",
					kanzhang: "Closed Wait",
					dandiao: "Single Wait",
					zimo: "Self-Drawn",
					huapai: "Flower Tiles"
				},
				hk: {
					pinghu: "All Chows",
					zimo: "Self-Drawn",
					menqianqing: "Concealed Hand",
					huapai: "Flower Tiles",
					pengpenghu: "All Pungs",
					hunyise: "Half Flush",
					xiaosanyuan: "Little Three Dragons",
					hunyaojiu: "All Terminals and Honors",
					qingyise: "Full Flush",
					dasanyuan: "Big Three Dragons",
					xiaosixi: "Little Four Winds",
					qidui: "Seven Pairs",
					dasixi: "Big Four Winds",
					ziyise: "All Honors",
					qingyaojiu: "All Terminals",
					shisanyao: "Thirteen Orphans",
					jiulian: "Nine Gates",
					tianhu: "Heavenly Hand",
					dihu: "Earthly Hand",
					gangshanghua: "Win after Kan",
					qianggang: "Robbing a Kan",
					haidilao: "Last Tile Tsumo",
					hediyu: "Last Tile Ron"
				},
				riichi: {
					riichi: "Riichi",
					doubleRiichi: "Double Riichi",
					ippatsu: "Ippatsu",
					tsumo: "Fully Concealed Tsumo",
					pinfu: "Pinfu",
					tanyao: "All Simples",
					iipeikou: "Pure Double Chow",
					ryanpeikou: "Twice Pure Double Chow",
					yakuhaiDragon: "Dragon Pung",
					yakuhaiWind: "Value Wind Pung",
					sanshokuDoujun: "Mixed Triple Chow",
					sanshokuDoukou: "Triple Pung",
					ikkitsuukan: "Pure Straight",
					chiitoitsu: "Seven Pairs",
					toitoi: "All Pungs",
					sanankou: "Three Concealed Pungs",
					sankantsu: "Three Kongs",
					honroutou: "All Terminals and Honors",
					shousangen: "Little Three Dragons",
					chanta: "Half Outside Hand",
					junchan: "Fully Outside Hand",
					honiisou: "Half Flush",
					chiniisou: "Full Flush",
					haitei: "Under the Sea",
					houtei: "Under the River",
					rinshan: "After a Kan",
					chankan: "Robbing a Kan",
					dora: "Dora",
					tenho: "Blessing of Heaven",
					chiiho: "Blessing of Earth",
					kokushi: "Thirteen Orphans",
					suuankou: "Four Concealed Pungs",
					daisangen: "Big Three Dragons",
					daisuushii: "Big Four Winds",
					tsuuiisou: "All Honors",
					ryuuiisou: "All Green",
					chinroutou: "All Terminals",
					churen: "Nine Gates",
					suukantsu: "Four Kongs"
				}
			}
		}
	}
};
//#endregion
export { dr as default };
