import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useId as i, useMemo as a, useRef as o, useState as s } from "react";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { useFxAnchor as m } from "@bgparty/sdk/fx/anchors";
import { GameScreen as h } from "@bgparty/sdk/ui/game-screen";
import { PLAYER_COLORS as g } from "@bgparty/sdk/player-colors";
import { Texture as _ } from "@bgparty/sdk/texture";
import { Floater as v, FlySprite as y, PulseBox as b } from "@bgparty/sdk/fx/primitives";
import { IconBack as x, IconBot as ee, IconExpand as S, IconLog as C } from "@bgparty/sdk/icons";
import { seatName as w } from "@bgparty/sdk/ui/player-strip";
import { Confetti as te } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as T, OptionSection as E } from "@bgparty/sdk/ui/game-options";
//#region src/games/queenalice/data.ts
var D = ["red", "white"], O = [
	"cake",
	"tea",
	"toast"
], ne = [
	"heart",
	"spade",
	"club",
	"diamond"
], k = [
	"pawn",
	"knight",
	"bishop",
	"rook",
	"queen",
	"king"
], A = (e, t = 1, n = {}) => ({
	type: e,
	n: t,
	...n
}), j = (e) => e === "red" ? "white" : "red", M = (e) => e === "red" ? "cake" : "toast", re = {
	red: "◆",
	white: "◇",
	cake: "🍰",
	tea: "☕",
	toast: "🍞",
	heart: "♥",
	spade: "♠",
	club: "♣",
	diamond: "♦",
	pink: "❀",
	blue: "✿",
	orange: "❁",
	yellow: "✾",
	time: "◷",
	ip: "✦",
	cat: "🐾",
	alice: "♛",
	crown: "♕",
	black: "⬛",
	book: "▣",
	invite: "✉",
	acquire: "+▤",
	mini: "↪",
	resource: "◈",
	flower: "❀",
	capture: "⚔",
	extraDiscard: "↗▤",
	cardReward: "▤/✉",
	pawn: "♟",
	knight: "♞",
	bishop: "♝",
	rook: "♜",
	queen: "♛",
	king: "♚"
};
function ie(e, t, n, r, i) {
	let a = n === "wild" ? void 0 : n, o = [], s = [];
	return e === 0 ? s = t === "queen" ? [A("invite")] : t === "king" ? [A("acquire", 1, { tier: 1 })] : [A("time")] : (t === "pawn" && (o = [...e > 1 ? [A("resource", 1, { resource: e === 3 ? "any" : r })] : [], A("invite")], s = e === 1 ? [A("resource", 1, { resource: r })] : [A("cat", e === 3 ? 2 : 1, { color: a ? j(a) : void 0 })]), t === "knight" && (o = [A("time", e)], s = e === 1 ? [A("resource", 1, { resource: r })] : [A("time", e + 1)]), t === "bishop" && (o = [A("ip", e * 2)], s = [A("resource", 1, { resource: r }), ...e > 1 ? [A("ip", (e - 1) * 2)] : []]), t === "rook" && (s = [A(e === 3 ? "black" : "resource", 1, { resource: e === 2 ? "any" : r })]), t === "king" && (o = [A("extraDiscard", e)], s = [A("acquire", 1, { tier: e === 3 ? 2 : 1 }), ...e > 1 ? [A("time")] : []]), t === "queen" && (o = [A("capture", e), ...e === 3 ? [A("cat", 2, { color: a ? j(a) : void 0 })] : []], s = [A("invite", e === 3 ? 2 : 1), ...e === 2 ? [A("time")] : []])), {
		id: `${e}-${t}-${n}-${i}`,
		tier: e,
		piece: t,
		color: n,
		resource: r,
		play: o,
		discard: s,
		discountResource: e === 1 ? r === "tea" ? "tea" : M(n) : "any",
		discount: e > 0 && t === "rook" ? e === 3 ? 2 : 1 : 0
	};
}
var N = {}, ae = [];
for (let e of k) {
	let t = e === "queen" || e === "king" ? ["wild"] : [...D];
	for (let n of t) {
		let t = ie(0, e, n, "tea", 0);
		N[t.id] = t, ae.push(t.id);
	}
}
for (let e = 1; e <= 3; e++) for (let t of k) if (t === "king" || t === "queen") for (let n of [...D, "wild"]) {
	let r = ie(e, t, n, "tea", 0);
	N[r.id] = r;
}
else for (let n of D) for (let r = 0; r < 3; r++) {
	let i = ie(e, t, r < 4 - e ? n : "wild", e === 3 ? r === 0 ? M(j(n)) : "tea" : e === 2 && t === "pawn" ? M(n) : [
		"toast",
		"cake",
		"tea"
	][r], n === "red" ? r : r + 3);
	N[i.id] = i;
}
var P = [
	{
		id: 0,
		height: 0,
		x: 50,
		books: [],
		bonus: [],
		cover: !1
	},
	{
		id: 1,
		height: 1,
		x: 50,
		books: ["white", "white"],
		bonus: [],
		cover: !1
	},
	{
		id: 2,
		height: 1,
		x: 50,
		books: ["any"],
		bonus: [],
		cover: !1
	},
	{
		id: 3,
		height: 2,
		x: 4,
		books: ["any"],
		bonus: [],
		cover: !1
	},
	{
		id: 4,
		height: 2,
		x: 27,
		books: ["green"],
		bonus: [A("time", 2)],
		cover: !0
	},
	{
		id: 5,
		height: 2,
		x: 50,
		books: ["white-green", "white"],
		bonus: [],
		cover: !1
	},
	{
		id: 6,
		height: 2,
		x: 73,
		books: ["blue"],
		bonus: [A("resource", 1, { resource: "tea" })],
		cover: !0
	},
	{
		id: 7,
		height: 2,
		x: 96,
		books: ["any"],
		bonus: [],
		cover: !1
	},
	{
		id: 8,
		height: 3,
		x: 4,
		books: ["green-blue"],
		bonus: [A("invite", 2)],
		cover: !0
	},
	{
		id: 9,
		height: 3,
		x: 35,
		books: ["white-green"],
		bonus: [A("black", 1, { resource: "tea" })],
		cover: !0
	},
	{
		id: 10,
		height: 3,
		x: 65,
		books: ["green-blue"],
		bonus: [A("time", 3)],
		cover: !0
	},
	{
		id: 11,
		height: 3,
		x: 96,
		books: ["white-green"],
		bonus: [A("acquire", 1, { tier: 1 })],
		cover: !0
	},
	{
		id: 12,
		height: 3,
		x: 18,
		books: ["any"],
		bonus: [A("cat")],
		cover: !0
	},
	{
		id: 13,
		height: 4,
		x: 50,
		books: ["any", "any"],
		bonus: [A("ip", 6)],
		cover: !0
	},
	{
		id: 14,
		height: 3,
		x: 82,
		books: ["any"],
		bonus: [A("cat")],
		cover: !0
	}
], oe = [...[
	[
		0,
		1,
		1
	],
	[
		0,
		2,
		3
	],
	[
		1,
		3,
		2
	],
	[
		1,
		7,
		2
	],
	[
		2,
		4,
		2
	],
	[
		2,
		6,
		2
	],
	[
		4,
		8,
		3
	],
	[
		4,
		9,
		3
	],
	[
		6,
		10,
		3
	],
	[
		6,
		11,
		3
	],
	[
		3,
		12,
		4
	],
	[
		7,
		14,
		4
	],
	[
		9,
		13,
		4
	],
	[
		10,
		13,
		4
	]
].map(([e, t, n]) => ({
	from: e,
	to: t,
	cost: n,
	tea: !1
})), ...[
	[
		1,
		2,
		1
	],
	[
		4,
		3,
		1
	],
	[
		5,
		4,
		1
	],
	[
		5,
		6,
		1
	],
	[
		6,
		7,
		1
	],
	[
		3,
		8,
		1
	],
	[
		8,
		9,
		2
	],
	[
		11,
		10,
		2
	],
	[
		7,
		11,
		1
	],
	[
		8,
		12,
		1
	],
	[
		11,
		14,
		1
	],
	[
		12,
		13,
		2
	],
	[
		14,
		13,
		2
	]
].map(([e, t, n]) => ({
	from: e,
	to: t,
	cost: n,
	tea: !0
}))], F = [
	{
		id: "time",
		kind: "instant",
		cost: "any2",
		reward: [A("time", 2)]
	},
	...D.map((e) => ({
		id: `cat-${e}`,
		kind: "instant",
		cost: ["white", "white"],
		reward: [A("cat", 2, { color: e })]
	})),
	...["heart", "diamond"].map((e) => ({
		id: `mini-${e}`,
		kind: "instant",
		cost: [
			"white",
			"white",
			"green"
		],
		reward: [A("mini", 1, { suit: e })]
	})),
	...[
		"black",
		"acquire",
		"invite",
		"capture",
		"rescue",
		"alice"
	].map((e) => ({
		id: `event-${e}`,
		kind: "permanent",
		cost: ["white", "green"],
		event: e,
		reward: [A("time", e === "alice" ? 3 : 2)]
	})),
	...[
		"heart",
		"spade",
		"diamond"
	].flatMap((e) => ["own", "tea"].map((t) => ({
		id: `discount-${e}-${t}`,
		kind: "permanent",
		cost: [
			"white",
			"green",
			"green"
		],
		suit: e,
		discount: t
	}))),
	...["cat", "invite"].flatMap((e) => D.map((t) => ({
		id: `score-${e}-${t}`,
		kind: "final",
		cost: ["white", "blue"],
		metric: e,
		color: t,
		factor: 2,
		cap: 10
	}))),
	{
		id: "score-cards",
		kind: "final",
		cost: ["white", "blue"],
		metric: "cards",
		factor: 2,
		cap: 10
	},
	{
		id: "score-black",
		kind: "final",
		cost: [
			"white",
			"blue",
			"blue"
		],
		metric: "black",
		factor: 6,
		cap: 5
	},
	{
		id: "score-time",
		kind: "final",
		cost: [
			"white",
			"blue",
			"blue"
		],
		metric: "time",
		factor: 3,
		cap: 10
	},
	...D.map((e) => ({
		id: `score-alice-${e}`,
		kind: "final",
		cost: [
			"white",
			"blue",
			"blue"
		],
		metric: "alice",
		color: e,
		factor: 8,
		cap: 4
	}))
], I = (e) => [
	[A("resource", 1, { resource: M(j(e)) })],
	[A("acquire", 1, { tier: 2 })],
	[A("alice", 1, { color: e })],
	[A("mini", 1, { suit: e === "red" ? "club" : "spade" })],
	[A("crown", 1, { color: e })]
], se = (e) => [
	[A("time", 2)],
	[A("cat", 1, { color: j(e) })],
	[A("acquire", 1, { tier: 1 })],
	[A("black", 1, { resource: M(j(e)) })],
	[A("invite", 2)]
], ce = (e) => {
	let t = M(j(e)), n = j(e);
	return [
		[A("resource", 1, { resource: t })],
		[A("acquire", 1, { tier: 1 })],
		[A("black", 1, { resource: t })],
		[A("cat", 2, { color: n })],
		[A("black", 1, { resource: "tea" })],
		[A("cat", 2, { color: n })],
		[A("invite")],
		[A("black", 1, { resource: t }), A("resource", 1, { resource: "tea" })],
		[A("cat", 2, { color: n })],
		[A("black", 1, { resource: "tea" })],
		[A("time", 3)],
		[A("acquire", 1, { tier: 2 })],
		[A("black", 1, { resource: t }), A("resource", 1, { resource: "tea" })],
		[A("acquire", 1, { tier: 3 })],
		[A("cat", 3, { color: n })],
		[A("black", 1, { resource: t }), A("time", 2)],
		[A("ip", 8)],
		[A("cat", 3, { color: n })],
		[A("ip", 10)],
		[A("cat", 4, { color: n })]
	];
}, le = [
	0,
	2,
	4,
	5,
	7,
	10,
	13,
	14,
	16,
	19
], ue = (e, t) => t <= 2 ? le.includes(e) : t === 4 || ![
	1,
	9,
	11,
	17
].includes(e), L = (e, t) => {
	let n = (e) => [A("flower", 1, { flower: e })], r = e === "red" ? [
		[
			n("orange"),
			[A("invite", 2), A("cat", 1, { color: "white" })],
			n("yellow")
		],
		[
			n("yellow"),
			[A("cat", t > 2 ? 3 : 2, { color: "white" })],
			n("pink")
		],
		[
			n("blue"),
			[A("black", 1, { resource: "toast" }), A("cat", 1, { color: "white" })],
			n("pink")
		],
		[
			n("orange"),
			[A("cat", 1, { color: "white" }), A("time", 2)],
			n("blue")
		]
	] : [
		[
			n("pink"),
			[A("cat", 2, { color: "red" })],
			n("yellow")
		],
		[
			n("pink"),
			[A("black", 1, { resource: "cake" }), A("cat", 1, { color: "red" })],
			n("blue")
		],
		[
			n("blue"),
			[A("cat", 1, { color: "red" }), A("time", 2)],
			n("orange")
		],
		[
			n("yellow"),
			[A("invite", 2), A("cat", 1, { color: "red" })],
			n("orange")
		]
	], i = e === "red" ? [
		["pink", "blue"],
		["blue", "orange"],
		["orange", "yellow"],
		["yellow", "pink"]
	] : [
		["blue", "orange"],
		["orange", "yellow"],
		["yellow", "pink"],
		["blue", "pink"]
	];
	return t > 2 && r.forEach((e, r) => {
		e.push(n(i[r][0])), t === 4 && e.push(n(i[r][1]));
	}), r;
};
function R(e) {
	let t = j(e);
	return [
		{
			id: 0,
			step: 0,
			branch: 0,
			tier: 1,
			next: [1],
			rewards: []
		},
		{
			id: 1,
			step: 1,
			branch: 0,
			tier: 1,
			next: [2, 3],
			rewards: [A("resource", 1, { resource: M(t) })]
		},
		{
			id: 2,
			step: 2,
			branch: -1,
			tier: 1,
			next: [4, 5],
			rewards: [A("ip", 3)]
		},
		{
			id: 3,
			step: 2,
			branch: 1,
			tier: 1,
			next: [4, 5],
			rewards: [A("cat", 1, { color: t })]
		},
		{
			id: 4,
			step: 3,
			branch: -1,
			tier: 1,
			next: [6],
			rewards: [A("cat", 1, { color: t })]
		},
		{
			id: 5,
			step: 3,
			branch: 1,
			tier: 1,
			next: [6],
			rewards: [A("cardReward", 1, { tier: 1 })]
		},
		{
			id: 6,
			step: 4,
			branch: 0,
			tier: 2,
			next: [7, 8],
			rewards: [A("time", 2)],
			seal: `${e}-outer`
		},
		{
			id: 7,
			step: 5,
			branch: -1,
			tier: 2,
			next: [9],
			rewards: [A("ip", 5)]
		},
		{
			id: 8,
			step: 5,
			branch: 1,
			tier: 2,
			next: [9],
			rewards: [A("black", 1, { resource: M(t) })]
		},
		{
			id: 9,
			step: 6,
			branch: 0,
			tier: 2,
			next: [10],
			rewards: [A("cat", 2, { color: t })]
		},
		{
			id: 10,
			step: 7,
			branch: 0,
			tier: 2,
			next: [11],
			rewards: [A("cardReward", 1, { tier: 2 })]
		},
		{
			id: 11,
			step: 8,
			branch: 0,
			tier: 3,
			next: [12, 13],
			rewards: [A("black", 1, { resource: "tea" })],
			seal: `${e}-center`
		},
		{
			id: 12,
			step: 9,
			branch: -1,
			tier: 3,
			next: [14, 15],
			rewards: [A("time", 3)],
			mini: "diamond"
		},
		{
			id: 13,
			step: 9,
			branch: 1,
			tier: 3,
			next: [14, 15],
			rewards: [A("cardReward", 1, { tier: 3 })],
			mini: "club"
		},
		{
			id: 14,
			step: 10,
			branch: -1,
			tier: 3,
			next: [16],
			rewards: [A("cardReward", 1, { tier: 3 })]
		},
		{
			id: 15,
			step: 10,
			branch: 1,
			tier: 3,
			next: [16],
			rewards: [A("time", 3)]
		},
		{
			id: 16,
			step: 11,
			branch: 0,
			tier: 3,
			next: [17],
			rewards: [A("black", 1, { resource: "tea" })]
		},
		{
			id: 17,
			step: 12,
			branch: 0,
			tier: 3,
			next: [],
			rewards: [A("crown", 1, { color: e })],
			seal: `${e}-end`
		}
	];
}
var de = (e) => e ? [
	0,
	8,
	8,
	8,
	8,
	7,
	7,
	7,
	7,
	6,
	6,
	6
] : [
	0,
	8,
	8,
	8,
	7,
	7,
	7,
	6,
	6
], z = (e) => e ? [4, 8] : [3, 6], fe = [
	[2, 4],
	[5, 9],
	[7, 12],
	[11, 16],
	[1, 2],
	[2, 4],
	[2, 3],
	[5, 8],
	[3, 6],
	[7, 12],
	[1, 2],
	[3, 5],
	[2, 4],
	[5, 9],
	[3, 5],
	[3, 5]
], pe = [
	"pawn",
	"pawn",
	"bishop",
	"bishop",
	"king",
	"rook",
	"rook",
	"knight",
	"knight",
	"queen"
];
//#endregion
//#region src/games/queenalice/information.ts
function me(e, t) {
	return t === 3 ? [A("alice", 1, { color: e })] : t === 4 ? [A("mini", 1, { suit: e === "red" ? "spade" : "heart" })] : t === 5 ? [A("crown", 1, { color: e })] : [];
}
function he(e, t, n) {
	return [...se(e)[t], ...me(e, n)];
}
function ge(e, t, n, r) {
	return !e.dinah || n >= 2 ? I(t)[n] : n === 0 ? [A("resource", r === "expert" ? 2 : 1, { resource: M(j(t)) })] : r === "easy" ? [A("resource", 1, { resource: M(j(t)) })] : [A("cat", r === "normal" ? 1 : 2, { color: j(t) })];
}
function _e(e, t, n) {
	return [...t === 1 ? [A(n === "hard" || n === "expert" ? "black" : "resource", 1, { resource: M(j(e)) })] : t === 2 ? n === "easy" ? [A("resource", 1, { resource: M(j(e)) })] : n === "normal" ? [A("black", 1, { resource: M(j(e)) })] : [A("cat", n === "expert" ? 2 : 1, { color: j(e) })] : [], ...me(e, t)];
}
function ve(e, t) {
	return t === 1 ? [A("time")] : t === 3 ? [A("resource", 1, { resource: M(j(e)) })] : t === 5 ? [A("time", 2)] : t === 7 ? [A("resource", 1, { resource: "tea" })] : t === 9 ? [A("black", 1, { resource: "tea" })] : t === 11 ? [A("time", 3)] : t === 12 ? [A("alice", 1, { color: e }), A("ip", 3)] : [];
}
function ye(e, t) {
	let n = [A("time", e === 9 ? 6 : e === 10 ? 5 : e >= 11 && e !== 13 && e !== 14 ? 4 : e === 13 ? 2 : e === 14 ? 0 : 3), A("resource", 1, { resource: M(t) })];
	return e < 4 && n.push(A("flower", 1, { flower: [
		"pink",
		"blue",
		"orange",
		"yellow"
	][e] })), [8, 15].includes(e) && n.push(A("black", 1, { resource: M(j(t)) })), e === 10 && n.push(A("cat", 1, { color: j(t) })), [
		11,
		12,
		13,
		14
	].includes(e) && n.push(A("acquire", 1, { tier: e === 11 ? 1 : e - 11 })), n;
}
function be(e, t, n) {
	let r = de(e.players.length > 2), i = r.length - 1;
	if (n) {
		let n = r.findIndex((n, r) => r > e.alice[t] && !z(e.players.length > 2).includes(r) && !e.crownSpaces[t].includes(r));
		return {
			at: e.crowns ? n : -1,
			points: !e.crowns || n < 0 ? 10 : r[n] * 2,
			wish: !1,
			removesCrown: !0
		};
	}
	let a = e.alice[t] + 1;
	for (; e.crownSpaces[t].includes(a);) a++;
	let o = a > i || a === i && e.alice[j(t)] === i;
	return {
		at: o ? e.alice[j(t)] === i ? i - 1 : i : a,
		points: o ? 5 : r[a],
		wish: !o && z(e.players.length > 2).includes(a),
		removesCrown: o || a === i || z(e.players.length > 2).includes(a)
	};
}
var xe = (e) => e.flowers.yellow ? 5 : 3, Se = {
	id: "queenalice",
	tier: "alpha",
	nameKey: "games.queenalice.name",
	descKey: "games.queenalice.desc",
	rulesKey: "games.queenalice.rules",
	icon: "♛",
	iconImg: "games/queenalice.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	hotseat: "cover",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/queenalice/en.pdf" },
	mechanics: [
		"deck-bag-building",
		"engine-building",
		"grid-movement"
	],
	interactionTags: [],
	accent: "#a94051",
	releasedAt: "2026-10-26T03:20:00+08:00",
	search: {
		py: "ai li si nv wang",
		init: "alsnw"
	}
}, Ce = t.enum(["red", "white"]), we = t.enum([
	"cake",
	"tea",
	"toast"
]), Te = t.object({
	red: t.int().nonnegative(),
	white: t.int().nonnegative()
}), Ee = t.object({ difficulty: t.enum([
	"easy",
	"normal",
	"hard",
	"expert"
]).default("normal") }).default({ difficulty: "normal" }), De = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(160)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), Oe = t.object({
	type: t.enum([
		"time",
		"ip",
		"resource",
		"black",
		"cat",
		"alice",
		"crown",
		"invite",
		"acquire",
		"mini",
		"book",
		"flower",
		"capture",
		"extraDiscard",
		"cardReward"
	]),
	n: t.number(),
	color: Ce.optional(),
	resource: t.enum([
		"cake",
		"tea",
		"toast",
		"any"
	]).optional(),
	suit: t.enum([
		"heart",
		"spade",
		"club",
		"diamond"
	]).optional(),
	tier: t.number().optional(),
	book: t.enum([
		"white",
		"green",
		"blue",
		"any",
		"white-green",
		"green-blue"
	]).optional(),
	flower: t.enum([
		"pink",
		"blue",
		"orange",
		"yellow"
	]).optional()
}), ke = t.object({
	key: t.string(),
	n: t.number().optional(),
	value: t.string().optional()
}), Ae = t.object({
	id: t.string(),
	kind: t.string(),
	label: t.string(),
	value: t.string().optional(),
	n: t.number().optional(),
	color: Ce.optional(),
	card: t.string().optional(),
	square: t.number().optional(),
	target: t.number().optional(),
	cost: t.array(t.string()).optional(),
	score: t.number(),
	rewards: t.array(Oe).optional(),
	next: t.string().optional(),
	timeCost: t.number().optional(),
	groups: t.array(t.object({
		key: t.string(),
		rewards: t.array(Oe)
	})).optional(),
	notes: t.array(ke).optional(),
	bookCost: t.array(t.string()).optional(),
	result: t.object({
		time: t.number(),
		capacity: t.number(),
		stock: t.array(we)
	}).optional(),
	payment: t.array(t.object({
		origin: t.string().optional(),
		originValue: t.string().optional(),
		id: t.string().optional(),
		kind: t.string(),
		value: t.string().optional(),
		n: t.number().optional()
	})).optional()
}), je = t.object({
	rid: t.string(),
	ip: t.number(),
	time: t.int().min(0).max(10),
	stock: t.array(we),
	capacity: t.int().min(3).max(8),
	hearts: Te,
	diamonds: t.object({
		red: t.array(t.int()),
		white: t.array(t.int())
	}),
	cats: Te,
	messengers: Te,
	twins: Te,
	crowns: Te,
	advances: Te,
	flowers: t.object({
		pink: t.int(),
		blue: t.int(),
		orange: t.int(),
		yellow: t.int()
	}),
	books: t.object({
		white: t.int(),
		green: t.int(),
		blue: t.int()
	}),
	bookmarks: t.array(t.string()),
	used: t.array(t.string()),
	invited: t.array(t.string()),
	discard: t.array(t.string()),
	deckCount: t.int(),
	handCount: t.int(),
	train: t.object({
		id: t.int(),
		color: Ce
	}).nullable(),
	booksTaken: t.int(),
	seals: t.int(),
	dinah: t.boolean(),
	resourceRow: t.int(),
	resourceSide: Ce,
	blackTrack: t.int(),
	final: t.array(t.object({
		label: t.string(),
		n: t.number()
	}))
}), Me = t.object({
	id: t.string(),
	color: Ce,
	type: t.enum([
		"pawn",
		"knight",
		"bishop",
		"rook",
		"queen",
		"king"
	]),
	square: t.int().min(-1).max(39),
	prison: t.string().nullable()
}), Ne = t.object({
	phase: t.enum([
		"setup",
		"playing",
		"done"
	]),
	round: t.int(),
	actor: t.string(),
	prompt: t.string(),
	players: t.array(je),
	pieces: t.array(Me),
	market: t.array(t.array(t.string().nullable())),
	marketCounts: t.array(t.int()),
	crowns: t.int(),
	alice: Te,
	crownSpaces: t.object({
		red: t.array(t.int()),
		white: t.array(t.int())
	}),
	wishes: t.array(t.object({
		id: t.int(),
		color: Ce,
		triggered: t.boolean()
	})),
	gardeners: t.object({
		red: t.int(),
		white: t.int()
	}),
	garden: t.object({
		red: t.array(t.array(t.string().nullable())),
		white: t.array(t.array(t.string().nullable()))
	}),
	wall: t.object({
		red: t.array(t.string().nullable()),
		white: t.array(t.string().nullable())
	}),
	eggs: Te,
	treeBooks: t.array(t.boolean()),
	bookmarks: t.array(t.string()),
	seals: t.array(t.string()),
	pendingWishes: t.array(t.number()).optional(),
	context: Ae.optional(),
	remaining: t.number().optional(),
	mini: t.boolean().optional(),
	source: t.string().optional(),
	sourceCard: t.string().optional(),
	sourceScene: t.string().optional(),
	pendingRewards: t.array(Oe).optional(),
	activeCard: t.string().nullable(),
	activeColor: Ce.nullable(),
	activeSuit: t.string().nullable(),
	finalRound: t.boolean(),
	log: t.array(t.object({
		key: t.string(),
		rid: t.string(),
		n: t.number().optional(),
		value: t.string().optional()
	})),
	difficulty: t.string()
}), Pe = t.object({
	hand: t.array(t.string()),
	trains: t.array(t.int()),
	choices: t.array(Ae)
}), Fe = () => ({
	red: 0,
	white: 0
}), Ie = (e) => e.players.length > 2, B = (e) => e.players.find((t) => t.rid === e.tasks[0]?.rid) ?? e.players[e.turn], V = (e) => e.tasks[0], H = (e, t = {}) => ({
	kind: e,
	...t
}), U = (e, ...t) => {
	e.tasks.unshift(...t);
}, W = (e, ...t) => {
	let n = e.tasks.shift();
	U(e, ...t.map((e) => ({
		source: n?.source,
		sourceCard: n?.sourceCard,
		scene: n?.scene,
		...e,
		rid: e.rid ?? n?.rid
	})));
}, G = (e, t) => H("rewards", {
	rewards: e,
	rid: t
}), Le = (e) => {
	e.tasks = [G([A("time", 2)]), H("rest")];
}, K = {
	card: 620,
	resource: 680,
	move: 620,
	value: 620,
	idle: 70
};
function Re(e, t, n = K.value) {
	e.effects && (e.effects.push({
		...t,
		...e.effects.length ? { with: !0 } : {}
	}), e.beatMs = Math.max(e.beatMs ?? 0, n));
}
function ze(e) {
	let t = e.effects ?? [];
	return delete e.effects, {
		state: e,
		...t.length ? { fx: t } : {}
	};
}
function q(e, t, n, r, i = V(e)?.source, a = {}) {
	Re(e, {
		kind: "token",
		rid: t.rid,
		data: {
			token: n,
			n: r,
			from: i ?? "qa-reward",
			...a
		}
	}, K.resource);
}
function Be(e, t, n, r, i, a = !1) {
	Re(e, {
		kind: "card",
		rid: t.rid,
		data: {
			from: r,
			to: i,
			...a ? {} : { card: n }
		},
		...a ? {
			for: [t.rid],
			secret: { card: n }
		} : {}
	}, K.card);
}
function Ve(e, t, n) {
	t.time -= n, q(e, t, "time", -n);
}
function He(e, t, n) {
	t.stock.splice(t.stock.indexOf(n), 1), q(e, t, n, -1);
}
function J(e, t, n, r, i) {
	e.log.push({
		key: t,
		rid: n.rid,
		...r === void 0 ? {} : { n: r },
		...i === void 0 ? {} : { value: i }
	}), e.log = e.log.slice(-16);
}
function Ue(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function We(e, t) {
	t.deck.length || (t.deck = Ue(e, t.discard), t.discard = []);
	let n = t.deck.pop();
	if (n) {
		let r = t.hand.length;
		t.hand.push(n), Be(e, t, n, `qa-deck:${t.rid}`, `qa-hand:${t.rid}:${r}`, !0);
	}
}
function Ge(e, t, n) {
	if (!t.dinah) for (let r of t.bookmarks) {
		let i = F.find((e) => e.id === r);
		i.event !== n || t.used.includes(r) || (t.used.push(r), e.pendingBonuses.push({
			rid: t.rid,
			rewards: i.reward ?? []
		}));
	}
}
function Ke(e) {
	for (let t of e.pendingBonuses.splice(0)) {
		let n = V(e);
		n?.kind === "rewards" && B(e).rid === t.rid ? n.rewards.push(...t.rewards) : U(e, G(t.rewards, t.rid));
	}
}
function qe(e, t, n) {
	if (t.dinah) {
		let r = n * (e.difficulty === "easy" ? 1 : e.difficulty === "expert" ? 3 : 2);
		t.ip += r, r && q(e, t, "ip", r);
		return;
	}
	let r = Math.min(n, 10 - t.time), i = Math.max(0, t.time + n - 10);
	r && q(e, t, "time", r), i && q(e, t, "ip", i), t.ip += i, t.time = Math.min(10, t.time + n);
}
function Je(e) {
	e.crowns > 0 && e.crowns--, e.crowns || (e.finalRound = !0);
}
function Ye(e, t, n) {
	let r = de(Ie(e)), i = r.length - 1, a = e.alice[n] + 1;
	for (; e.crownSpaces[n].includes(a);) a++;
	let o = e.alice[j(n)] === i;
	if (a > i || a === i && o) {
		e.alice[n] = o ? i - 1 : i, t.ip += 5, Je(e);
		return;
	}
	if (e.alice[n] = a, t.ip += r[a], Ge(e, t, "alice"), z(Ie(e)).includes(a)) {
		let t = e.wishes.findIndex((e) => e.color === n && !e.triggered);
		t >= 0 && (e.wishes[t].triggered = !0, e.pendingWishes.push(t), Je(e));
	}
	a === i && Je(e), J(e, "alice", t, a, n);
}
function Xe(e, t, n) {
	let r = de(Ie(e)), i = r.findIndex((t, r) => r > e.alice[n] && !z(Ie(e)).includes(r) && !e.crownSpaces[n].includes(r));
	!e.crowns || i < 0 ? t.ip += 10 : (t.crowns[n]++, e.crownSpaces[n].push(i), t.ip += r[i] * 2), Je(e), J(e, "crown", t, void 0, n);
}
function Ze(e, t, n) {
	let r = n === "cake" ? "red" : "white";
	if (n !== "tea" && t.resourceSide !== r) {
		t.resourceSide = r;
		return;
	}
	if (t.resourceRow >= 4) t.ip += 4;
	else if (t.resourceRow++, n !== "tea") {
		let n = e.difficulty === "easy" || e.difficulty === "normal" ? 0 : e.difficulty === "hard" ? +(t.resourceRow >= 2) : 1;
		n && U(e, G([A("cat", n, { color: r })], t.rid));
	}
}
function Qe(e, t) {
	t.dinah ? (t.blackTrack++, [
		3,
		5,
		7
	].includes(t.blackTrack) && U(e, ...Array.from({ length: e.difficulty === "expert" ? 2 : 1 }, () => H("acquire", {
		n: (t.blackTrack - 1) / 2,
		rid: t.rid
	})), ...e.difficulty === "easy" ? [] : [G([A("resource", 1, { resource: "tea" })], t.rid)]), t.blackTrack >= 9 && (t.blackTrack = 0, t.ip += 6)) : t.capacity < 8 && (t.capacity++, q(e, t, "black", 1), Ge(e, t, "black"));
}
function $e(e, t, n) {
	if (t.cats[n] >= 12) return [];
	let r = ++t.cats[n];
	return r === 1 ? [A("time")] : r === 3 ? [A("resource", 1, { resource: M(j(n)) })] : r === 5 ? [A("time", 2)] : r === 7 ? [A("resource", 1, { resource: "tea" })] : r === 9 ? [A("black", 1, { resource: "tea" })] : r === 11 ? [A("time", 3)] : r === 12 ? [A("alice", 1, { color: n }), A("ip", 3)] : [];
}
function et(e, t, n) {
	return n.square = -1, n.prison = t.rid, Ge(e, t, "capture"), J(e, "capture", t, void 0, n.type), [
		A("time"),
		...n.type === "pawn" ? [] : [A("resource", 1, { resource: M(j(n.color)) })],
		...["king", "queen"].includes(n.type) ? [A("cat", 1, { color: n.color })] : []
	];
}
function tt(e, t) {
	if (t.square < 0) return [];
	let n = t.square % 5, r = Math.floor(t.square / 5), i = (t, n) => e.pieces.find((e) => e.square === n * 5 + t), a = (e, t) => e >= 0 && e < 5 && t >= 0 && t < 8, o = [];
	if (t.type === "pawn") {
		let e = t.color === "red" ? -1 : 1;
		a(n, r + e) && !i(n, r + e) && o.push((r + e) * 5 + n);
		for (let s of [-1, 1]) a(n + s, r + e) && i(n + s, r + e)?.color === j(t.color) && o.push((r + e) * 5 + n + s);
		return o;
	}
	let s = t.type === "knight" ? [
		[1, 2],
		[-1, 2],
		[1, -2],
		[-1, -2],
		[2, 1],
		[-2, 1],
		[2, -1],
		[-2, -1]
	] : t.type === "rook" ? [
		[1, 0],
		[-1, 0],
		[0, 1],
		[0, -1]
	] : t.type === "bishop" ? [
		[1, 1],
		[-1, 1],
		[1, -1],
		[-1, -1]
	] : [
		[1, 0],
		[-1, 0],
		[0, 1],
		[0, -1],
		[1, 1],
		[-1, 1],
		[1, -1],
		[-1, -1]
	];
	for (let [e, c] of s) for (let s = 1; s <= (t.type === "king" || t.type === "knight" ? 1 : 7); s++) {
		let l = n + e * s, u = r + c * s;
		if (!a(l, u)) break;
		let d = i(l, u);
		if (d?.color === t.color || (o.push(u * 5 + l), d)) break;
	}
	return o;
}
function nt(e, t) {
	let n = Array.from({ length: 40 }, (e, t) => t).filter((t) => !e.pieces.some((e) => e.square === t)), r = n.filter((e) => t === "red" ? e >= 25 : e < 15);
	return r.length ? r : n;
}
function rt(e, t, n, r) {
	let i = n % 4, a, o = t.hearts.red + t.hearts.white, s = (n) => e.wall[n].map((e, t) => ({
		rid: e,
		i: t
	})).filter((e) => e.rid === t.rid);
	if (n < 4) {
		let e = Object.values(t.flowers), n = Math.floor(e.reduce((e, t) => e + t, 0) / 3);
		for (; n > 0 && e.reduce((e, t) => e + Math.min(t, n), 0) < n * 3;) n--;
		a = [
			o,
			Math.min(t.hearts.red, t.hearts.white),
			e.reduce((e, t) => e + Math.floor(t / 2), 0),
			n
		][i];
	} else if (n < 8) {
		let e = R("red")[t.messengers.red].step, n = R("white")[t.messengers.white].step;
		a = [
			e + n,
			Math.min(e, n),
			Math.min(3, e) + Math.max(0, e - 7) + Math.min(3, n) + Math.max(0, n - 7),
			t.seals
		][i];
	} else a = n < 12 ? [
		P[t.twins.red].height + P[t.twins.white].height,
		Math.min(P[t.twins.red].height, P[t.twins.white].height),
		Math.min(20, t.booksTaken),
		Math.min(10, t.bookmarks.filter((e) => F.find((t) => t.id === e)?.kind !== "final").length)
	][i] : [
		t.diamonds.red.length + t.diamonds.white.length,
		Math.min(t.diamonds.red.length, t.diamonds.white.length),
		D.reduce((t, n) => t + s(n).filter((t) => Math.floor(t.i / 4) <= e.eggs[n]).length, 0),
		D.reduce((e, t) => e + new Set(s(t).map((e) => e.i % 4)).size, 0)
	][i];
	return a * fe[n][+!!r];
}
function it(e) {
	return e.invited.reduce((t, n) => {
		let r = N[n], i = ["king", "queen"].includes(r.piece), a = r.color === "wild";
		return r.tier ? r.tier === 1 ? t + (i ? a ? 4 : 3 : 2) : r.tier === 2 ? t + (i ? a ? 6 : 5 : a ? 4 : 2 * e.invited.filter((e) => N[e].piece === r.piece && (N[e].color === r.color || N[e].color === "wild")).length) : r.piece === "king" ? t + [
			...e.deck,
			...e.hand,
			...e.discard,
			...e.invited
		].filter((e) => N[e].tier > 0).length : r.piece === "queen" ? t + e.invited.length : t + (a ? 6 : 2 * e.invited.filter((e) => N[e].piece === r.piece).length) : t + (i ? 2 : 1);
	}, 0);
}
function at(e) {
	return e.dinah ? 0 : e.bookmarks.reduce((t, n) => {
		let r = F.find((e) => e.id === n);
		if (r.kind !== "final") return t;
		let i = r.metric === "cat" ? e.cats[r.color] : r.metric === "invite" ? e.invited.filter((e) => N[e].color === r.color || N[e].color === "wild").length : r.metric === "black" ? e.capacity - 3 : r.metric === "time" ? e.time : r.metric === "alice" ? e.advances[r.color] : 0;
		if (r.metric === "cards") {
			let n = [
				...e.deck,
				...e.hand,
				...e.discard,
				...e.invited
			].map((e) => N[e]);
			return t + 2 * Math.min(10, n.filter((e) => e.tier === 1 || e.tier === 2).length) + 4 * Math.min(5, n.filter((e) => e.tier === 3).length);
		}
		return t + Math.min(r.cap ?? Infinity, i) * (r.factor ?? 0);
	}, 0);
}
function ot(e, t, n) {
	e.final.push({
		label: t,
		n
	}), e.ip += n;
}
function st(e, t, n, r = V(e)?.suit, i = V(e)?.color ?? e.activeColor ?? "red") {
	if (t.dinah || !n.length) return !0;
	let a = [...Array.from({ length: e.discount.n }, () => e.discount.resource), ...Array.from({ length: e.repeatDiscount }, () => "any")];
	for (let e of t.bookmarks) {
		let n = F.find((t) => t.id === e);
		n.discount && n.suit === r && !t.used.includes(e) && a.push(n.discount === "own" ? M(i) : n.discount);
	}
	let o = [...n].sort((e, t) => Number(e === "any") - Number(t === "any")), s = t.flowers.blue ? 2 : 3, c = /* @__PURE__ */ new Set(), l = (e, n, r, i, a, u) => {
		if (e === o.length) return !0;
		let d = `${e}/${n}/${r}/${i}/${a}/${u}`;
		if (c.has(d)) return !1;
		c.add(d);
		let f = o[e];
		for (let t = 0; t < 3; t++) if (n[t] && (f === "any" || f === O[t])) {
			let o = [...n];
			if (o[t]--, l(e + 1, o, r, i, a, u)) return !0;
		}
		for (let t = 0; t < i.length; t++) if ((i[t] === "any" || f === "any" || i[t] === f) && l(e + 1, n, r, i.filter((e, n) => n !== t), a, u)) return !0;
		if (r >= s && l(e + 1, n, r - s, i, a, u)) return !0;
		if (a && u > 3) {
			if (n.reduce((e, t) => e + t, 0) < u) {
				if (l(e + 1, n, r, i, a - 1, u - 1)) return !0;
			} else for (let t = 0; t < 3; t++) if (n[t]) {
				let o = [...n];
				if (o[t]--, l(e + 1, o, r, i, a - 1, u - 1)) return !0;
			}
		}
		if (t.flowers.blue >= 2 && n[1]) {
			let t = [...n];
			if (t[1]--, l(e, t, Math.min(10, r + 2), i, a, u)) return !0;
		}
		return !1;
	};
	return l(0, O.map((e) => t.stock.filter((t) => t === e).length), t.time, a, Math.min(e.blackBudget, t.capacity - 3), t.capacity);
}
function ct(e, t, n, r, i, a) {
	let o = n[0] ? pt(n[0]) : V(e)?.source, s = r ?? (n[0]?.kind === "buy-card" ? "market" : V(e)?.scene);
	U(e, H("pay", {
		cost: t,
		after: n.map((e) => ({
			source: o,
			scene: s,
			...e
		})),
		suit: r,
		rid: i,
		color: a,
		source: o,
		scene: s
	}));
}
function lt(e, t, n, r, i = {}) {
	return {
		id: e,
		kind: t,
		label: n,
		score: 0,
		...i,
		apply: r
	};
}
function ut(e) {
	return H(`reward-${e.type}`, {
		reward: e,
		n: e.n,
		color: e.color,
		resource: e.resource,
		suit: e.suit,
		id: e.tier,
		card: e.book ?? e.flower
	});
}
function dt(e) {
	let t = V(e);
	if (!t || e.phase === "done") return [];
	let n = B(e), r = t.color ?? e.activeColor ?? "red", i = [], a = (e, t, n, r, a = {}) => i.push(lt(e, t, n, r, a)), o = (e) => W(e), s = () => a("skip", "skip", "skip", o, { score: -10 });
	if (t.kind === "dinah-move") for (let n of kt(e, t.color, t.n)) a(`dinah-move-${n.piece.id}-${n.to}`, "move", "dinahMove", (e) => {
		W(e), At(e, n);
	}, {
		color: t.color,
		value: n.piece.id,
		square: n.to
	});
	else if (t.kind === "train") for (let e of n.trains) for (let t of D) a(`train-${e}-${t}`, "train", "train", (n) => {
		let r = B(n);
		r.train = {
			id: e,
			color: t
		};
		let i = r.trains.find((t) => t !== e);
		r.trains = [], n.players.length === 2 && n.players[1].dinah && (n.players[1].train = {
			id: i,
			color: j(t)
		}), W(n, H("setup-next"));
	}, {
		target: e,
		color: t,
		score: e < 4 ? 8 : 4
	});
	else if (t.kind === "discard" || t.kind === "extra-discard" || t.kind === "trim" || t.kind === "play" || t.kind === "invite") {
		let r = t.kind === "invite" ? [...n.hand, ...n.discard] : n.hand, i = r.filter((e, n) => r.indexOf(e) === n && (t.kind !== "extra-discard" || N[e].tier <= (t.n ?? 0)));
		for (let o of i) {
			if (t.kind === "invite" && (n.hand.length + n.discard.length + n.deck.length <= 3 || n.hand.includes(o) && n.hand.length <= 1 && e.tasks.some((e) => e.kind === "play"))) continue;
			let i = r.filter((e) => e === o).length;
			a(`${t.kind}-${o}`, t.kind, t.kind, (e) => {
				let n = B(e), r = N[o], i = n.hand.indexOf(o), a = i < 0 ? `qa-discard:${n.rid}` : `qa-hand:${n.rid}:${i}`;
				if (t.source = t.kind === "invite" ? `qa-guests:${n.rid}` : `qa-discard:${n.rid}`, t.sourceCard = o, t.scene = "board", Be(e, n, o, a, t.source), t.kind === "play") n.hand.splice(n.hand.indexOf(o), 1), n.discard.push(o), e.activeCard = o, e.activeColor = r.color === "wild" ? null : r.color, e.discount = {
					resource: r.discountResource,
					n: r.discount
				}, W(e, ...r.color === "wild" ? [H("play-color", { card: o })] : [G(r.play), H("move", { card: o })]);
				else if (t.kind === "invite") {
					let r = n.hand.includes(o) ? n.hand : n.discard;
					r.splice(r.indexOf(o), 1), n.invited.push(o), Ge(e, n, "invite"), J(e, "invite", n, void 0, o), W(e, ...(t.n ?? 1) > 1 ? [H("invite", { n: t.n - 1 })] : []);
				} else n.hand.splice(n.hand.indexOf(o), 1), n.discard.push(o), t.kind === "trim" ? W(e, H("rest")) : W(e, G(r.discard), ...t.kind === "discard" ? [H("play")] : []);
			}, {
				card: o,
				n: i,
				rewards: t.kind === "play" ? N[o].play : t.kind === "trim" || t.kind === "invite" ? [] : N[o].discard,
				score: t.kind === "play" ? N[o].tier * 3 : t.kind === "invite" ? 5 - N[o].tier : 0
			});
		}
		(t.kind === "invite" || t.kind === "extra-discard") && s();
	} else if (t.kind === "play-color") {
		let e = N[t.card];
		for (let n of D) a(`play-color-${n}`, "color", "color", (r) => {
			r.activeColor = n, W(r, G(e.play.map((t) => t.type === "cat" && !t.color && e.piece === "queen" ? {
				...t,
				color: j(n)
			} : t)), H("move", { card: t.card }));
		}, {
			color: n,
			score: 2
		});
	} else if (t.kind === "rewards") for (let [e, n] of (t.rewards ?? []).entries()) a(`reward-${e}`, "reward", "claim", (r) => {
		r.tasks[0].rewards.splice(e, 1), U(r, {
			...ut(n),
			rid: t.rid,
			source: t.source,
			sourceCard: t.sourceCard,
			scene: t.scene
		});
	}, {
		value: JSON.stringify(n),
		n: n.n,
		score: n.type === "resource" || n.type === "black" ? 6 : n.type === "time" ? 3 : 1
	});
	else if (t.kind === "reward-resource" || t.kind === "reward-black") {
		let r = t.resource === "any" || !t.resource ? O : [t.resource];
		for (let e of r) if (n.dinah || n.stock.length < n.capacity + +(t.kind === "reward-black" && n.capacity < 8)) a(`gain-${e}`, "resource", "gain", (n) => {
			let r = B(n);
			W(n, ...(t.n ?? 1) > 1 ? [{
				...t,
				n: t.n - 1
			}] : []), t.kind === "reward-black" && Qe(n, r), r.dinah ? Ze(n, r, e) : (r.stock.push(e), q(n, r, e, 1, t.source, { slot: r.stock.length - 1 }));
		}, {
			value: e,
			score: 5
		});
		else for (let r of new Set(n.stock)) a(`swap-${e}-${r}`, "replace", "replace", (n) => {
			let i = B(n), a = i.stock.indexOf(r);
			i.stock.splice(a, 1, e), q(n, i, r, -1, `qa-stock:${i.rid}:${r}`), q(n, i, e, 1, t.source, { slot: a }), W(n, ...(t.n ?? 1) > 1 ? [{
				...t,
				n: t.n - 1
			}] : []), t.kind === "reward-black" && Qe(n, i);
		}, {
			value: `${r}:${e}`,
			score: r === e ? 0 : 1
		});
		let i = e.tasks.find((e) => e.kind === "column");
		!n.dinah && t.kind === "reward-resource" && i && i.target % 5 == 2 && !i.starPaid && !n.flowers.pink && a("pay-star", "resource", "payStar", (e) => {
			let n = e.tasks.find((e) => e.kind === "column");
			n.starPaid = !0, W(e, ...(t.n ?? 1) > 1 ? [{
				...t,
				n: t.n - 1
			}] : []);
		}, { score: 7 }), n.dinah || s();
	} else if (t.kind === "reward-cat" || t.kind === "reward-alice" || t.kind === "reward-crown") for (let e of t.color ? [t.color] : D) a(`color-${e}`, "color", "color", (n) => {
		let r = B(n);
		if (q(n, r, t.kind.slice(7), 1, t.source, { color: e }), W(n, ...(t.n ?? 1) > 1 ? [{
			...t,
			n: t.n - 1
		}] : []), t.kind === "reward-cat") {
			let i = $e(n, r, e);
			i.length && U(n, G(i, t.rid));
		} else t.kind === "reward-alice" ? Ye(n, r, e) : Xe(n, r, e);
	}, {
		color: e,
		score: 3
	});
	else if (t.kind === "reward-book") for (let e of t.card && ![
		"any",
		"white-green",
		"green-blue"
	].includes(t.card) ? [t.card] : t.card === "white-green" ? ["white", "green"] : t.card === "green-blue" ? ["green", "blue"] : [
		"white",
		"green",
		"blue"
	]) a(`book-${e}`, "book", "book", (n) => {
		let r = B(n);
		r.books[e]++, r.booksTaken++, q(n, r, "book", 1, t.source, { book: e }), W(n, ...(t.n ?? 1) > 1 ? [{
			...t,
			n: t.n - 1
		}] : []);
	}, {
		value: e,
		score: e === "blue" ? 4 : 3
	});
	else if (t.kind === "reward-capture") {
		for (let n of e.pieces.filter((n) => n.square >= 0 && (!e.activeColor || n.color === j(e.activeColor)) && ((t.n ?? 1) === 1 ? n.type === "pawn" : !["king", "queen"].includes(n.type)))) a(`capture-${n.id}`, "capture", "capture", (e) => {
			W(e, G(et(e, B(e), e.pieces.find((e) => e.id === n.id))));
		}, {
			square: n.square,
			value: n.type,
			color: n.color,
			score: 3
		});
		s();
	} else if (t.kind === "move" || t.kind === "promote") {
		let r = t.card ? N[t.card] : null, i = e.pieces.filter((n) => t.kind === "promote" ? n.id === t.card : n.type === r?.piece && n.color === e.activeColor);
		for (let o of i) {
			let i = o.square < 0, s = t.kind === "promote" || i ? nt(e, o.color) : tt(e, o);
			!s.length && o.square >= 0 && s.push(o.square);
			for (let c of s) a(`move-${o.id}-${c}`, "move", i ? "rescue" : "move", (e) => {
				let n = B(e), r = e.pieces.find((e) => e.id === o.id), a = e.pieces.find((e) => e.square === c && e.id !== o.id), s = a ? et(e, n, a) : [];
				r.prison && (qe(e, e.players.find((e) => e.rid === r.prison), 1), Ge(e, n, "rescue")), Re(e, {
					kind: "piece",
					rid: n.rid,
					data: {
						pieceId: r.id,
						piece: r.type,
						color: r.color,
						from: r.square < 0 ? "qa-prisons" : `qa-square:${r.square}`,
						to: `qa-square:${c}`
					}
				}, K.move), t.source = `qa-square:${c}`, t.sourceCard = void 0, t.scene = "board", r.square = c, r.prison = null, e.activeColor = r.color;
				let l = r.type === "pawn" && (r.color === "red" ? c < 5 : c >= 35) && t.kind !== "promote", u = Math.floor(c / 5), d = [
					"cake",
					"tea",
					"toast",
					"any",
					"any",
					"cake",
					"tea",
					"toast"
				][u], f = n.flowers.pink >= 2 && u >= 2 && u <= 5 ? u === 3 || u === 4 ? 2 : 1 : 0;
				W(e, ...s.length ? [G(s)] : [], G([A("resource", 1, { resource: d }), ...f ? [A("time", f)] : []]), H("column", {
					color: r.color,
					target: c,
					mini: l,
					card: r.id
				})), J(e, i ? "rescue" : "move", n, c + 1, r.type);
			}, {
				square: c,
				value: o.id,
				color: o.color,
				rewards: mt(e, n, o, c),
				next: c % 5 == 2 || r?.piece === "king" ? "any" : [
					"heart",
					"spade",
					"any",
					"club",
					"diamond"
				][c % 5],
				score: (e.pieces.some((e) => e.square === c && e.color !== o.color) ? 5 : 0) + Math.abs(Math.floor(o.square / 5) - Math.floor(c / 5)) / 5
			});
		}
	} else if (t.kind === "column") {
		let i = (t.target ?? 0) % 5, o = e.activeCard && N[e.activeCard].piece === "king";
		for (let s of i === 2 || o ? [
			"heart",
			"spade",
			"club",
			"diamond"
		] : [[
			"heart",
			"spade",
			"heart",
			"club",
			"diamond"
		][i]]) {
			let o = i === 2 && !n.flowers.pink && !t.starPaid ? ["any"] : [];
			st(e, n, o) && a(`column-${s}`, "action", "action", (e) => {
				e.activeSuit = s, e.blackBudget = 5, W(e, ...t.mini ? [H("reward-cat", {
					n: 1,
					color: r
				}), H("promote", { card: t.card })] : [H("repeat", {
					suit: s,
					color: r
				})]), ct(e, o, [H("action", {
					suit: s,
					color: r
				})], s);
			}, {
				value: s,
				color: r,
				cost: o,
				score: 2
			});
		}
		a("pass", "pass", "pass", Le, { score: -6 });
	} else if (t.kind === "pay") {
		let i = t.cost ?? [];
		for (let o of [...new Set(i)]) {
			let i = o === "any" ? O : [o];
			for (let e of i) n.stock.includes(e) && a(`pay-${o}-${e}`, "pay-resource", "pay", (t) => {
				He(t, B(t), e), t.tasks[0].cost.splice(t.tasks[0].cost.indexOf(o), 1);
			}, {
				value: e,
				score: 5
			});
			let s = n.flowers.blue ? 2 : 3;
			if (n.time >= s && a(`pay-time-${o}`, "pay-time", "payTime", (e) => {
				Ve(e, B(e), s), e.tasks[0].cost.splice(e.tasks[0].cost.indexOf(o), 1);
			}, {
				value: o,
				n: s,
				score: 1
			}), n.capacity > 3 && e.blackBudget > 0) for (let e of n.stock.length === n.capacity ? [...new Set(n.stock)] : [null]) a(`pay-black-${o}-${e ?? "empty"}`, "pay-black", "payBlack", (t) => {
				let n = B(t);
				n.capacity--, q(t, n, "black", -1), t.blackBudget--, t.tasks[0].cost.splice(t.tasks[0].cost.indexOf(o), 1), e && He(t, n, e);
			}, {
				value: e ? `${o}:${e}` : o,
				score: -2
			});
			(e.repeatDiscount || e.discount.n && (e.discount.resource === "any" || o === "any" || e.discount.resource === o)) && a(`discount-${o}`, "discount", "discount", (e) => {
				e.repeatDiscount ? e.repeatDiscount-- : e.discount.n--, e.tasks[0].cost.splice(e.tasks[0].cost.indexOf(o), 1);
			}, {
				value: o,
				score: 8
			});
			for (let e of n.bookmarks) {
				let i = F.find((t) => t.id === e);
				!i.discount || i.suit !== t.suit || n.used.includes(e) || o !== "any" && o !== (i.discount === "own" ? M(r) : i.discount) || a(`bookmark-${o}-${e}`, "discount", "discount", (t) => {
					B(t).used.push(e), t.tasks[0].cost.splice(t.tasks[0].cost.indexOf(o), 1);
				}, {
					value: o,
					score: 7
				});
			}
		}
	} else if (t.kind === "drop-resource") for (let e of new Set(n.stock)) a(`drop-${e}`, "drop", "drop", (t) => {
		let n = B(t);
		n.stock.splice(n.stock.indexOf(e), 1), W(t);
	}, { value: e });
	else if (t.kind === "action") {
		let i = r, o = t.suit;
		if (o === "heart") {
			let r = n.hearts[i];
			r < 5 && (t.mini ? a(`heart-mini-${i}`, "mini", "mini", (e) => {
				let t = B(e);
				t.hearts[i]++, W(e, G(vt(e, t, i, r))), r === 2 && t.advances[i]++;
			}, {
				color: i,
				value: o,
				score: 3
			}) : L(i, e.players.length).forEach((t, s) => t.forEach((t, c) => {
				if (e.garden[i][s][c]) return;
				let l = e.gardeners[i], u = l < 0 ? 0 : Math.min(Math.abs(l - s), 4 - Math.abs(l - s)), d = [...Array.from({ length: [
					1,
					2,
					2,
					2,
					3
				][r] }, () => M(i)), ...Array.from({ length: u }, () => "tea")];
				st(e, n, d, o, i) && a(`plant-${s}-${c}`, "garden", "plant", (e) => {
					W(e), ct(e, d, [H("plant", {
						color: i,
						region: s,
						slot: c
					})], o, void 0, i);
				}, {
					color: i,
					target: s,
					n: c,
					rewards: [...vt(e, n, i, r), ...t],
					value: JSON.stringify(t),
					cost: d,
					score: t.some((e) => e.type === "flower") ? 6 : 3
				});
			})));
		} else if (o === "diamond") {
			if (n.diamonds[i].length < 5) for (let r of [
				0,
				1,
				2,
				3,
				4
			].filter((e) => !n.diamonds[i].includes(e))) if (t.mini) a(`diamond-mini-${r}`, "mini", "removeDiamond", (e) => {
				W(e, G(yt(e, B(e), i, r)));
			}, {
				color: i,
				target: r,
				value: JSON.stringify(se(i)[r]),
				score: 3
			});
			else for (let t = 0; t < 4; t++) {
				let s = e.wall[i].findIndex((n, r) => r % 4 === t && !n && ue(r, e.players.length));
				if (s < 0) continue;
				let c = Math.floor(s / 4), l = [...Array.from({ length: [
					1,
					2,
					2,
					3,
					4
				][c] }, () => M(i)), ...[2, 3].includes(t) ? ["tea"] : []];
				st(e, n, l, o, i) && a(`wall-${r}-${s}`, "wall", "build", (e) => {
					W(e), ct(e, l, [H("build", {
						color: i,
						index: r,
						slot: s
					})], o, void 0, i);
				}, {
					color: i,
					target: s,
					n: r,
					rewards: ht(e, n, i, r, s),
					value: JSON.stringify([...se(i)[r], ...ce(i)[s]]),
					cost: l,
					score: c === e.eggs[i] ? 5 : 3
				});
			}
		} else if (o === "club") for (let r of oe.filter((e) => e.from === n.twins[i] && (!t.mini || e.tea))) {
			let s = r.from === n.twins[i] ? r.to : r.from, c = t.mini ? [] : Array.from({ length: r.cost }, () => r.tea ? "tea" : M(i));
			st(e, n, c, o, i) && a(`tree-${s}`, "tree", "climb", (e) => {
				W(e), ct(e, c, [H("climb", {
					color: i,
					target: s
				})], o, void 0, i);
			}, {
				color: i,
				target: s,
				n: P[s].height,
				rewards: gt(e, n, i, s),
				next: "bookmark",
				cost: c,
				score: (P[s].height - P[n.twins[i]].height) * 3 + 2
			});
		}
		else {
			let r = R(i), s = (e, t, n) => t ? r[e].next.flatMap((e) => s(e, t - 1, [...n, e])) : [n];
			for (let r of t.mini ? [1] : [
				1,
				2,
				3
			]) {
				let c = t.mini ? [] : [...Array.from({ length: r === 1 ? 1 : 2 }, () => M(i)), ...r === 3 ? ["tea"] : []];
				if (st(e, n, c, o, i)) for (let l of s(n.messengers[i], r, [])) a(`messenger-${l.join("-")}`, "messenger", "advance", (e) => {
					W(e), ct(e, c, [H("messenger", {
						color: i,
						path: l,
						mini: t.mini
					})], o, void 0, i);
				}, {
					color: i,
					target: l[l.length - 1],
					n: r,
					rewards: _t(e, i, l),
					next: "cardReward",
					cost: c,
					score: r * 2
				});
			}
		}
		t.mini ? s() : a("pass", "pass", "pass", Le, { score: -8 });
	} else if (t.kind === "mini") {
		for (let r of D) ft(e, n, t.suit, r, !0) && a(`mini-${r}`, "action", "mini", (e) => W(e, H("action", {
			suit: t.suit,
			color: r,
			mini: !0
		})), {
			color: r,
			value: t.suit,
			score: 3
		});
		s();
	} else if (t.kind === "acquire") {
		let r = t.n ?? 1;
		for (let i of n.flowers.yellow >= 2 ? [
			1,
			2,
			3
		] : [r]) {
			let o = i - r;
			if (!(o > n.time)) for (let r = 0; r < 3; r++) {
				let s = e.market[i - 1][r], c = r === 2 ? ["any"] : [];
				!s || r === 1 && n.time - o < 1 || !st(e, {
					...n,
					time: Math.min(10, n.time - o) - +(r === 1)
				}, c) || a(`acquire-${i}-${r}`, "acquire", "acquire", (e) => {
					let n = B(e);
					t.source = `qa-market:${i}:${r}`, t.scene = "market", o > 0 ? Ve(e, n, o) : qe(e, n, -o), r === 1 && Ve(e, n, 1), W(e), ct(e, c, [H("buy-card", {
						n: i,
						slot: r,
						card: s
					})], void 0, n.rid);
				}, {
					card: s,
					n: r,
					timeCost: o + +(r === 1),
					cost: c,
					score: i * 3 - r
				});
			}
		}
		s();
	} else if (t.kind === "bookmark") {
		for (let t of e.bookmarks) {
			let e = F.find((e) => e.id === t);
			if (e.cost === "any2") {
				let e = Object.entries(n.books).flatMap(([e, t]) => Array.from({ length: t }, () => e)), r = /* @__PURE__ */ new Set();
				for (let t = 0; t < e.length; t++) for (let n = t + 1; n < e.length; n++) r.add([e[t], e[n]].sort().join(":"));
				for (let e of r) a(`bookmark-${t}-${e}`, "bookmark", "bookmark", (n) => bt(n, t, e.split(":")), {
					value: t,
					score: 2
				});
			} else [
				"white",
				"green",
				"blue"
			].every((t) => n.books[t] >= e.cost.filter((e) => e === t).length) && a(`bookmark-${t}`, "bookmark", "bookmark", (n) => bt(n, t, e.cost), {
				value: t,
				score: e.kind === "permanent" ? 6 : 4
			});
		}
		s();
	} else if (t.kind === "repeat") {
		let i = n.flowers.orange ? 5 : 6;
		n.time >= i && ft(e, n, t.suit, r, !1) && a("repeat", "repeat", "repeat", (e) => {
			Ve(e, B(e), i), e.repeatDiscount = +(B(e).flowers.orange >= 2), e.blackBudget = 5, W(e, H("action", {
				suit: t.suit,
				color: r
			}), H("rest"));
		}, {
			n: i,
			color: r,
			value: t.suit,
			score: n.time >= 9 ? 5 : -1
		}), a("rest", "rest", "rest", (e) => W(e, H("rest")), { score: 0 });
	} else if (t.kind === "final-wish") for (let [t, i] of e.wishes.entries()) {
		if (i.color !== r) continue;
		let o = e.alice[r] > e.alice[j(r)], s = rt(e, n, i.id, o);
		a(`wish-${t}`, "wish", "scoreWish", (e) => {
			ot(B(e), `wish-${i.id}`, s), W(e);
		}, {
			target: i.id,
			n: s,
			score: s
		});
	}
	return !n.dinah && n.flowers.blue >= 2 && n.stock.includes("tea") && ![
		"train",
		"trim",
		"final-wish"
	].includes(t.kind) && a("exchange-tea", "exchange", "exchangeTea", (e) => {
		let t = B(e);
		t.stock.splice(t.stock.indexOf("tea"), 1), qe(e, t, 2);
	}, { score: n.time < 4 ? 2 : -3 }), t.kind === "pay" ? i.filter((t) => {
		let r = structuredClone(e);
		t.apply(r);
		let i = r.tasks.find((e) => e.kind === "pay");
		return !i || st(r, r.players.find((e) => e.rid === n.rid), i.cost ?? [], i.suit, i.color);
	}) : i;
}
function ft(e, t, n, r, i) {
	return n === "heart" ? t.hearts[r] < 5 && (i || e.garden[r].some((e) => e.some((e) => !e))) : n === "diamond" ? t.diamonds[r].length < 5 && (i || e.wall[r].some((t, n) => !t && ue(n, e.players.length))) : n === "spade" ? R(r)[t.messengers[r]].next.length > 0 : oe.some((e) => e.from === t.twins[r] && (!i || e.tea));
}
function pt(e) {
	return e.kind === "plant" ? `qa-garden:${e.color}:${e.region}:${e.slot}` : e.kind === "build" ? `qa-wall:${e.color}:${e.slot}` : e.kind === "climb" ? `qa-tree:${e.color}:${e.target}` : e.kind === "messenger" ? `qa-messenger:${e.color}:${e.path?.at(-1)}` : e.kind === "buy-card" ? `qa-market:${e.n}:${e.slot}` : "qa-reward";
}
function mt(e, t, n, r) {
	let i = e.pieces.find((e) => e.square === r && e.id !== n.id), a = Math.floor(r / 5);
	return [
		...i ? [
			A("time"),
			...i.type === "pawn" ? [] : [A("resource", 1, { resource: M(j(i.color)) })],
			...["king", "queen"].includes(i.type) ? [A("cat", 1, { color: i.color })] : []
		] : [],
		A("resource", 1, { resource: [
			"cake",
			"tea",
			"toast",
			"any",
			"any",
			"cake",
			"tea",
			"toast"
		][a] }),
		...t.flowers.pink >= 2 && a >= 2 && a <= 5 ? [A("time", a === 3 || a === 4 ? 2 : 1)] : []
	];
}
function ht(e, t, n, r, i) {
	let a = structuredClone(e), o = a.players.find((e) => e.rid === t.rid);
	delete a.effects;
	let s = yt(a, o, n, r), c = Math.floor(i / 4);
	return c === e.eggs[n] && s.push(A("ip", e.wall[n].every((t, n) => n === i || Math.floor(n / 4) !== c || !ue(n, e.players.length) || !!t) ? 4 : 2)), [...s, ...ce(n)[i]];
}
function gt(e, t, n, r) {
	let i = P[t.twins[n]], a = P[r];
	return [
		...i.height === 2 && a.height === 3 ? [A("alice", 1, { color: n })] : [],
		...i.height < 4 && a.height === 4 ? [A("crown", 1, { color: n })] : [],
		...a.books.map((e) => A("book", 1, { book: e })),
		...e.treeBooks[r] ? [A("book", 1, { book: "white" })] : a.bonus
	];
}
function _t(e, t, n) {
	let r = R(t), i = [...r[n.at(-1)].rewards], a = new Set(e.seals);
	for (let e of n) {
		let n = r[e], o = n.seal && !a.has(n.seal);
		n.seal && (a.add(n.seal), n.seal.endsWith("outer") && i.push(A("ip", o ? 6 : 3)), n.seal.endsWith("center") && (i.push(A("alice", 1, { color: t })), o && i.push(A("ip", 4))), n.seal.endsWith("end") && i.push(A("cat", o ? 3 : 2, { color: t }))), n.mini && i.push(A("mini", 1, { suit: n.mini }));
	}
	return i;
}
function vt(e, t, n, r) {
	return !t.dinah || r >= 2 ? I(n)[r] : r === 0 ? [A("resource", e.difficulty === "expert" ? 2 : 1, { resource: M(j(n)) })] : e.difficulty === "easy" ? [A("resource", 1, { resource: M(j(n)) })] : [A("cat", e.difficulty === "normal" ? 1 : 2, { color: j(n) })];
}
function yt(e, t, n, r) {
	t.diamonds[n].push(r);
	let i = t.diamonds[n].length, a = i === 3 ? [A("alice", 1, { color: n })] : i === 4 ? [A("mini", 1, { suit: n === "red" ? "spade" : "heart" })] : i === 5 ? [A("crown", 1, { color: n })] : [];
	return i === 3 && t.advances[n]++, t.dinah ? [...i === 1 ? [A(e.difficulty === "hard" || e.difficulty === "expert" ? "black" : "resource", 1, { resource: M(j(n)) })] : i === 2 ? e.difficulty === "easy" ? [A("resource", 1, { resource: M(j(n)) })] : e.difficulty === "normal" ? [A("black", 1, { resource: M(j(n)) })] : [A("cat", e.difficulty === "expert" ? 2 : 1, { color: j(n) })] : [], ...a] : [...se(n)[r], ...a];
}
function bt(e, t, n) {
	let r = B(e), i = F.find((e) => e.id === t);
	for (let e of n) r.books[e]--;
	r.bookmarks.push(t), e.bookmarks.splice(e.bookmarks.indexOf(t), 1), W(e, ...i.reward && i.kind === "instant" ? [G(i.reward)] : []), J(e, "bookmark", r, void 0, t);
}
function xt(e) {
	let t = V(e);
	if (!t || e.phase === "done") return !1;
	let n = B(e), r = t.color ?? e.activeColor ?? "red";
	if (t.kind === "rewards" && (t.rewards?.length ?? 0) <= 1) {
		let n = t.rewards?.[0];
		return W(e, ...n ? [ut(n)] : []), !0;
	}
	if (Et(t)) return dt(e).find((e) => e.kind === "color" || e.kind === "book").apply(e), !0;
	if (t.kind === "reward-time" || t.kind === "reward-ip") return t.kind === "reward-time" ? qe(e, n, t.n ?? 1) : (n.ip += t.n ?? 1, q(e, n, "ip", t.n ?? 1)), W(e), !0;
	if (t.kind === "reward-flower") return n.flowers[t.card] += t.n ?? 1, q(e, n, t.card, t.n ?? 1), W(e), !0;
	if (t.kind === "reward-invite" || t.kind === "reward-acquire" || t.kind === "reward-mini" || t.kind === "reward-extraDiscard" || t.kind === "reward-cardReward") return W(e, H(t.kind === "reward-invite" ? "invite" : t.kind === "reward-acquire" ? "acquire" : t.kind === "reward-mini" ? "mini" : t.kind === "reward-cardReward" ? "card-reward" : "extra-discard", {
		n: t.kind === "reward-acquire" || t.kind === "reward-cardReward" ? t.id : t.n,
		suit: t.suit,
		rid: t.rid
	})), !0;
	if (t.kind === "pay" && (n.dinah || !t.cost?.length)) return W(e, ...t.after ?? []), !0;
	if (t.kind === "setup-next") return e.turn < e.players.length - 1 && !e.players[e.turn + 1].dinah ? (e.turn++, W(e, H("train")), !0) : (e.turn = 0, W(e, ...e.players.map((e) => H("train-benefits", { rid: e.rid })), H("begin")), !0);
	if (t.kind === "train-benefits") {
		W(e);
		let t = n.train, r = t.color, i = t.id, a = [A("time", i === 9 ? 6 : i === 10 ? 5 : i >= 11 && i !== 13 && i !== 14 ? 4 : i === 13 ? 2 : i === 14 ? 0 : 3), A("resource", 1, { resource: M(r) })];
		if (i < 4) {
			let t = [
				"pink",
				"blue",
				"orange",
				"yellow"
			][i];
			n.flowers[t]++, n.hearts[r]++;
			let a = L(r, e.players.length), o = a.findIndex((e) => e.some((e) => e.some((e) => e.flower === t))), s = a[o].findIndex((e) => e.some((e) => e.flower === t));
			e.garden[r][o][s] = n.rid;
		} else if (i < 8) {
			n.twins[r] = 1;
			let t = [
				"event-acquire",
				"event-capture",
				"event-invite",
				"event-black"
			][i - 4];
			n.bookmarks.push(t), e.bookmarks.splice(e.bookmarks.indexOf(t), 1);
		} else if (i < 12) {
			let t = [
				3,
				0,
				1,
				2
			][i - 8], o = [
				7,
				0,
				2,
				6
			][i - 8];
			n.diamonds[r].push(t), e.wall[r][o] = n.rid, i === 8 && a.push(A("black", 1, { resource: M(j(r)) })), i === 10 && a.push(A("cat", 1, { color: j(r) })), i === 11 && a.push(A("acquire", 1, { tier: 1 }));
		} else n.messengers[r] = [
			2,
			2,
			1,
			4
		][i - 12], i < 15 ? a.push(A("acquire", 1, { tier: i - 11 })) : a.push(A("black", 1, { resource: M(j(r)) }));
		return n.dinah && (n.resourceSide = r, n.resourceRow = 0, a.splice(1, 1)), U(e, G(a, n.rid)), !0;
	}
	if (t.kind === "begin") return e.phase = "playing", e.activeCard = null, e.activeColor = null, e.activeSuit = null, e.discount = {
		resource: "any",
		n: 0
	}, e.repeatDiscount = 0, e.blackBudget = 5, e.dinahFallback = 0, W(e, H(n.dinah ? "dinah-begin" : "discard")), !0;
	if (t.kind === "plant") {
		let i = n.hearts[r]++;
		return e.garden[r][t.region][t.slot] = n.rid, e.gardeners[r] = e.garden[r][t.region].every(Boolean) ? -1 : t.region, i === 2 && n.advances[r]++, Re(e, {
			kind: "land",
			rid: n.rid,
			data: { at: pt(t) }
		}, K.move), W(e, G([...vt(e, n, r, i), ...L(r, e.players.length)[t.region][t.slot]])), J(e, "plant", n, void 0, r), !0;
	}
	if (t.kind === "build") {
		Re(e, {
			kind: "land",
			rid: n.rid,
			data: { at: pt(t) }
		}, K.move);
		let i = yt(e, n, r, t.index);
		e.wall[r][t.slot] = n.rid;
		let a = Math.floor(t.slot / 4);
		if (a === e.eggs[r]) {
			let t = e.wall[r].every((t, n) => Math.floor(n / 4) !== a || !ue(n, e.players.length) || !!t);
			n.ip += t ? 4 : 2, t && e.eggs[r]++;
		}
		return W(e, G([...i, ...ce(r)[t.slot]])), J(e, "build", n, t.slot + 1, r), !0;
	}
	if (t.kind === "climb") {
		Re(e, {
			kind: "land",
			rid: n.rid,
			data: { at: pt(t) }
		}, K.move);
		let i = P[n.twins[r]], a = P[t.target], o = [];
		if (i.height === 2 && a.height === 3 && (o.push(A("alice", 1, { color: r })), n.advances[r]++), i.height < 4 && a.height === 4 && o.push(A("crown", 1, { color: r })), n.twins[r] = a.id, n.dinah) e.treeBooks[a.id] = !1;
		else {
			for (let e of a.books) o.push(A("book", 1, { book: e }));
			e.treeBooks[a.id] ? (o.push(A("book", 1, { book: "white" })), e.treeBooks[a.id] = !1) : o.push(...a.bonus);
		}
		return W(e, G(o), H("bookmark")), J(e, "climb", n, a.height, r), !0;
	}
	if (t.kind === "messenger") {
		Re(e, {
			kind: "land",
			rid: n.rid,
			data: { at: pt(t) }
		}, K.move);
		let i = t.path, a = R(r)[i[i.length - 1]], o = [...a.rewards];
		for (let t of i) {
			let i = R(r)[t];
			if (i.seal) {
				let t = !e.seals.includes(i.seal);
				e.seals.push(i.seal), n.seals++, i.seal.endsWith("outer") && o.push(A("ip", t ? 6 : 3)), i.seal.endsWith("center") && (o.push(A("alice", 1, { color: r })), t && o.push(A("ip", 4)), n.advances[r]++), i.seal.endsWith("end") && o.push(A("cat", t ? 3 : 2, { color: r }));
			}
			i.mini && o.push(A("mini", 1, { suit: i.mini }));
		}
		return n.messengers[r] = a.id, n.dinah && !t.mini && n.hand.length && n.invited.push(n.hand.pop()), W(e, G(o), H("card-reward", { n: a.tier })), J(e, "advance", n, a.step, r), !0;
	}
	if (t.kind === "buy-card") return Be(e, n, t.card, `qa-market:${t.n}:${t.slot}`, `qa-hand:${n.rid}:${n.hand.length}`), n.hand.push(t.card), e.market[t.n - 1][t.slot] = null, Ge(e, n, "acquire"), J(e, "acquire", n, void 0, t.card), W(e), !0;
	if (t.kind === "rest") {
		let t = n.flowers.yellow ? 5 : 3;
		if (!n.dinah && n.hand.length > t) return W(e, H("trim")), !0;
		if (!n.dinah && n.hand.length < t && (n.deck.length || n.discard.length)) return We(e, n), !0;
		n.used = [], St(e);
		for (let t of e.pendingWishes) for (let n of e.players) {
			let r = rt(e, n, e.wishes[t].id, !1);
			n.ip += r, J(e, "wish", n, r, `${e.wishes[t].id}`);
		}
		return e.pendingWishes = [], W(e, H("end-turn")), !0;
	}
	if (t.kind === "end-turn") return e.turn === e.players.length - 1 && e.finalRound ? (W(e, H("final")), !0) : (e.turn = (e.turn + 1) % e.players.length, e.turn || e.round++, W(e, H("begin")), !0);
	if (t.kind === "final") {
		let t = [];
		for (let n of e.players) {
			n.final.push({
				label: "during",
				n: n.ip
			});
			let r = e.alice.red === e.alice.white, i = e.alice.red > e.alice.white ? "red" : "white";
			ot(n, "crowns", (r ? n.crowns.red + n.crowns.white : n.crowns[i]) * 8), ot(n, "guests", it(n)), ot(n, "bookmarks", at(n));
			for (let r of D) if (n.cats[r] >= 10) for (let t of e.wishes.filter((e) => e.color === r)) ot(n, `wish-${t.id}`, rt(e, n, t.id, e.alice[r] > e.alice[j(r)]));
			else n.cats[r] >= 6 && t.push(H("final-wish", {
				rid: n.rid,
				color: r
			}));
			if (n.dinah) {
				let t = [
					"easy",
					"normal",
					"hard",
					"expert"
				].indexOf(e.difficulty), r = (e) => [
					"instant",
					"permanent",
					"final"
				].map((t) => n.bookmarks.filter((n) => {
					let r = F.find((e) => e.id === n);
					return r.kind === t && (r.cost === "any2" ? 2 : r.cost.length) === e;
				}).length);
				ot(n, "dinah", Math.min(...r(2)) * [
					3,
					4,
					5,
					6
				][t] + Math.min(...r(3)) * [
					5,
					8,
					9,
					10
				][t] + Object.values(n.flowers).reduce((e, t) => e + t, 0) * [
					3,
					4,
					5,
					6
				][t] + [
					...n.hand,
					...n.deck,
					...n.discard
				].reduce((e, n) => e + [
					[
						0,
						0,
						1,
						2
					],
					[
						0,
						1,
						2,
						4
					],
					[
						0,
						1,
						3,
						5
					],
					[
						0,
						1,
						3,
						5
					]
				][t][N[n].tier], 0));
			}
		}
		return W(e, ...t, H("done")), !0;
	}
	return t.kind === "done" ? (e.phase = "done", e.tasks = [], !0) : t.kind === "dinah-begin" ? (Ot(e), !0) : t.kind === "dinah-action" ? (jt(e, r, t.n ?? 0), !0) : t.kind === "dinah-repeat" ? (n.resourceRow >= (e.difficulty === "easy" ? 4 : e.difficulty === "expert" ? 2 : 3) ? (n.resourceRow = 0, W(e, H("dinah-action", {
		color: e.dinahColor,
		n: e.dinahCard
	}), H("rest"))) : W(e, H("rest")), !0) : (t.kind, !1);
}
function St(e) {
	for (let t = 0; t < 3; t++) {
		let n = e.market[t].filter((e) => !!e);
		for (; n.length < 3 && e.decks[t].length;) n.push(e.decks[t].pop());
		e.market[t] = Array.from({ length: 3 }, (e, t) => n[t] ?? null);
	}
}
function Ct(e) {
	let t = [], n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set(), i = (e, a, o) => {
		let s = B(e), c = V(e)?.cost ?? [], l = JSON.stringify([
			c,
			[...s.stock].sort(),
			s.time,
			s.capacity,
			[...s.used].sort(),
			e.discount,
			e.repeatDiscount,
			e.blackBudget
		]);
		if (!(r.has(l) || o > 12 || r.size > 2500 || t.length >= 24)) {
			if (r.add(l), !c.length) {
				let r = JSON.stringify([
					[...s.stock].sort(),
					s.time,
					s.capacity,
					[...s.used].sort(),
					e.discount,
					e.repeatDiscount
				]);
				if (n.has(r)) return;
				n.add(r), t.push(lt(`payment-${t.length}`, "payment", "confirmPayment", (e) => {
					for (let t of a) dt(e).find((e) => e.id === t.id).apply(e);
				}, {
					payment: a.map((e) => ({
						id: e.id,
						kind: e.kind,
						value: e.value,
						n: e.n,
						origin: e.notes?.[0]?.key,
						originValue: e.notes?.[0]?.value
					})),
					result: {
						time: s.time,
						stock: [...s.stock],
						capacity: s.capacity
					},
					score: a.reduce((e, t) => e + t.score, 0)
				}));
				return;
			}
			for (let t of dt(e).filter((e) => e.kind !== "exchange").sort((e, t) => t.score - e.score)) {
				let n = structuredClone(e);
				delete n.effects, t.apply(n), i(n, [...a, Tt(e, t)], o + 1);
			}
		}
	}, a = structuredClone(e);
	return delete a.effects, i(a, [], 0), t.sort((e, t) => t.score - e.score);
}
function wt(e) {
	let t = V(e), n = B(e);
	return t?.kind === "pay" && t.cost?.length && !n.dinah ? [...Ct(e), ...dt(e)] : t?.kind === "card-reward" ? [
		lt("take-card", "acquire", "takeCard", (e) => W(e, H("acquire", { n: t.n })), {
			n: t.n,
			score: n.dinah && !n.hand.length ? 5 : 2
		}),
		lt("invite-card", "invite", "invite", (e) => W(e, H("invite", { n: 1 })), { score: n.hand.some((e) => N[e].tier === 0) ? 4 : 1 }),
		lt("skip", "skip", "skip", (e) => W(e), { score: -10 })
	] : dt(e);
}
function Tt(e, t) {
	let { apply: n, ...r } = t, i = V(e), a = B(e), o = r.color ?? i?.color ?? e.activeColor ?? "red", s = [];
	if (r.kind === "train" && (r.rewards = ye(r.target, o), s.push({
		key: `trainStart${r.target}`,
		value: o
	}), e.players.some((e) => e.dinah) && s.push({ key: "trainDinah" })), r.kind === "action" && i.kind === "mini" && (i.suit === "heart" && (r.rewards = vt(e, a, o, a.hearts[o])), i.suit === "diamond" && (r.rewards = me(o, a.diamonds[o].length + 1), s.push({ key: "miniChooseDiamond" }))), r.kind === "mini" && i.suit === "heart" && (r.rewards = vt(e, a, o, a.hearts[o])), r.kind === "mini" && i.suit === "diamond" && (r.rewards = he(o, r.target, a.diamonds[o].length + 1)), r.kind === "messenger" && (r.rewards = [...r.rewards ?? [], A("cardReward", 1, { tier: R(o)[r.target].tier })], r.next = void 0), r.kind === "acquire" && r.card) {
		s.push({ key: [
			"marketFeeFree",
			"marketFeeTime",
			"marketFeeResource"
		][r.n] });
		let e = N[r.card].tier - (i.n ?? 1);
		e && s.push({
			key: e > 0 ? "marketUpgrade" : "marketDowngrade",
			n: Math.abs(e)
		}), s.push({ key: "marketHand" });
	}
	if (r.kind === "garden" && (r.groups = [{
		key: "heartRewardSource",
		rewards: vt(e, a, o, a.hearts[o])
	}, {
		key: "spaceRewardSource",
		rewards: L(o, e.players.length)[r.target][r.n]
	}], r.cost?.includes("tea") && s.push({ key: "gardenerTeaSource" })), r.kind === "pass" && s.push({ key: "passRestHelp" }), r.kind === "repeat" && a.flowers.orange >= 2 && s.push({ key: "orangeRepeatHelp" }), r.kind === "bookmark") {
		let e = F.find((e) => e.id === r.value);
		r.bookCost = e.cost === "any2" ? r.id.slice(`bookmark-${e.id}-`.length).split(":") : e.cost;
	}
	if (r.kind === "discount" && s.push({
		key: r.id.startsWith("bookmark-") ? "discountBookmark" : e.repeatDiscount ? "discountRepeat" : "discountCard",
		value: r.id.startsWith("bookmark-") ? r.id.slice(`bookmark-${r.value}-`.length) : void 0
	}), r.kind === "move" && i.kind !== "dinah-move") {
		let t = e.pieces.find((e) => e.id === r.value), n = e.pieces.find((e) => e.square === r.square && e.id !== t.id);
		t.prison && s.push({
			key: "rescuePreview",
			value: t.prison
		}), i.kind === "promote" && s.push({ key: "promotionReturn" }), n && s.push({
			key: "captureTarget",
			value: `${n.color}:${n.type}`
		}), r.square % 5 == 2 && !a.flowers.pink && s.push({ key: "starCost" }), t.type === "pawn" && (t.color === "red" ? r.square < 5 : r.square >= 35) && i.kind !== "promote" && s.push({ key: "promotionPreview" });
	}
	if (r.kind === "capture") {
		let t = e.pieces.find((e) => e.square === r.square);
		r.rewards = [
			A("time"),
			...t.type === "pawn" ? [] : [A("resource", 1, { resource: M(j(t.color)) })],
			...["king", "queen"].includes(t.type) ? [A("cat", 1, { color: t.color })] : []
		];
	}
	if (r.kind === "invite" && r.card && s.push({ key: a.hand.includes(r.card) ? "inviteFromHand" : "inviteFromDiscard" }), r.kind === "color" && i.kind === "reward-cat" && (r.rewards = ve(o, Math.min(a.cats[o] + 1, 13)), s.push({
		key: "catAt",
		n: Math.min(a.cats[o] + 1, 12)
	}), (a.cats[o] === 5 || a.cats[o] === 9) && s.push({ key: a.cats[o] === 5 ? "catOneWish" : "catTwoWishes" })), r.kind === "color" && ["reward-alice", "reward-crown"].includes(i.kind)) {
		let t = be(e, o, i.kind === "reward-crown");
		r.rewards = [A("ip", t.points)], s.push({
			key: t.at < 0 ? "crownFallback" : "progressAt",
			n: t.at
		}), t.wish && s.push({ key: "wishPending" }), e.crowns > 0 && (i.kind === "reward-crown" || t.removesCrown) && s.push({ key: e.crowns === 1 ? "startsFinalRound" : "removesSupplyCrown" });
	}
	return r.notes = s.length ? s : r.notes, r;
}
function Et(e) {
	return [
		"reward-cat",
		"reward-alice",
		"reward-crown"
	].includes(e.kind) && !!e.color || e.kind === "reward-book" && !!e.card && [
		"white",
		"green",
		"blue"
	].includes(e.card);
}
function Dt(e) {
	if (!V(e) || e.phase === "done") return !1;
	let t = V(e).kind;
	return [
		"setup-next",
		"train-benefits",
		"begin",
		"plant",
		"build",
		"climb",
		"messenger",
		"buy-card",
		"rest",
		"end-turn",
		"final",
		"done",
		"dinah-begin",
		"dinah-action",
		"dinah-repeat",
		"reward-time",
		"reward-ip",
		"reward-flower",
		"reward-invite",
		"reward-acquire",
		"reward-mini",
		"reward-extraDiscard",
		"reward-cardReward"
	].includes(t) || Et(V(e)) || t === "rewards" && (V(e).rewards?.length ?? 0) <= 1 || t === "pay" && (B(e).dinah || !V(e).cost?.length);
}
function Ot(e) {
	let t = B(e);
	(e.dinahDiscard.length >= 6 || !e.dinahDeck.length) && (e.dinahDeck = Ue(e, [...e.dinahDeck, ...e.dinahDiscard]), e.dinahDiscard = []);
	let n = e.dinahDeck.pop();
	e.dinahDiscard.push(n), e.dinahCard = n, e.dinahColor = t.resourceSide, e.activeColor = e.dinahColor;
	let r = e.dinahColor;
	W(e, H("dinah-action", {
		color: r,
		n
	}), H("dinah-repeat"));
	let i = kt(e, r, n), a = (e) => e.capture ? ["king", "queen"].includes(e.capture.type) ? 3 : e.capture.type === "pawn" ? 1 : 2 : 0;
	if (i.length > 1 && a(i[0]) > 0 && a(i[0]) === a(i[1])) {
		U(e, H("dinah-move", {
			rid: e.players[0].rid,
			color: r,
			n
		}));
		return;
	}
	i[0] && At(e, i[0]);
}
function kt(e, t, n) {
	let r = pe[n], i = t === "red" ? -1 : 1, a = e.pieces.filter((e) => e.color === t && e.type === r && (r !== "pawn" || e.square >= 0)).flatMap((n) => (n.square < 0 ? nt(e, t) : tt(e, n)).map((r) => ({
		piece: n,
		to: r,
		capture: e.pieces.find((e) => e.square === r && e.color !== t)
	}))), o = (e) => e.capture ? ["king", "queen"].includes(e.capture.type) ? 3 : e.capture.type === "pawn" ? 1 : 2 : 0;
	if (a.some((e) => e.capture)) {
		let e = Math.max(...a.map(o));
		return a.filter((t) => o(t) === e);
	}
	let s = n === 0 ? t === "red" ? [
		2,
		1,
		3,
		4,
		0
	] : [
		2,
		3,
		1,
		0,
		4
	] : t === "red" ? [
		0,
		4,
		1,
		3,
		2
	] : [
		4,
		0,
		3,
		1,
		2
	], c = (n === 3 || n === 6 || n === 8 ? 1 : -1) * (r === "knight" || t === "red" ? 1 : -1), l = (e) => {
		if (e.piece.square < 0) return Math.floor(e.to / 5) * (t === "red" ? -1 : 1) * 10 + (t === "red" ? 4 - e.to % 5 : e.to % 5);
		if (r === "pawn") return s.indexOf(e.piece.square % 5) * 100 + Math.floor(e.piece.square / 5) * i;
		let n = e.to % 5 - e.piece.square % 5, a = Math.floor(e.to / 5) - Math.floor(e.piece.square / 5);
		if (r === "knight") return (a * i > 0 ? 0 : 100) + (n * c > 0 ? 0 : 20) - Math.abs(a);
		let o = (r === "bishop" ? [[c, i], [-c, i]] : r === "rook" ? [
			[0, i],
			[c, 0],
			[-c, 0]
		] : [
			[0, i],
			[i === -1 ? 1 : -1, i],
			[i === -1 ? -1 : 1, i]
		]).findIndex(([e, t]) => Math.sign(n) === e && Math.sign(a) === t);
		return o < 0 ? 1e4 : o * 100 - Math.abs(n) - Math.abs(a);
	};
	return a.filter((e) => l(e) < 1e4).sort((e, t) => l(e) - l(t)).slice(0, 1);
}
function At(e, t) {
	let n = e.players.find((e) => e.dinah), r = t.piece.color, i = [];
	t.capture && i.push(...et(e, n, t.capture)), t.piece.prison && (qe(e, e.players.find((e) => e.rid === t.piece.prison), 1), t.piece.prison = null), t.piece.square = t.to;
	let a = [
		"cake",
		"tea",
		"toast",
		"tea",
		"tea",
		"cake",
		"tea",
		"toast"
	][Math.floor(t.to / 5)];
	if (i.push(A("resource", 1, { resource: a })), t.piece.type === "pawn" && (r === "red" ? t.to < 5 : t.to >= 35)) {
		i.push(A("cat", 1, { color: r }));
		let n = nt(e, r)[0];
		n !== void 0 && (t.piece.square = n);
	}
	U(e, G(i, n.rid)), J(e, "move", n, t.to + 1, t.piece.type);
}
function jt(e, t, n) {
	let r = B(e), i = pe[n];
	if (i === "king" || i === "queen") {
		W(e, ...i === "king" ? [G([A("cat", 2, { color: t })])] : [H("invite", { n: 2 })], H("dinah-action-next", { color: t }));
		return;
	}
	let a = i === "pawn" ? "heart" : i === "bishop" ? "spade" : i === "knight" ? "club" : "diamond";
	if (!ft(e, r, a, t, !1)) {
		W(e, H("dinah-action-next", { color: t }));
		return;
	}
	W(e, H("action", {
		color: t,
		suit: a
	}));
}
function Mt(t) {
	let n = V(t), r = B(t);
	if (!r.dinah || !n) return !1;
	if (n.kind === "dinah-action-next") {
		if (![
			"heart",
			"spade",
			"club",
			"diamond"
		].some((e) => ft(t, r, e, n.color, !1))) return W(t), !0;
		t.dinahDeck.length || (t.dinahDeck = Ue(t, t.dinahDiscard), t.dinahDiscard = []);
		let e = t.dinahDeck.pop();
		return t.dinahDiscard.push(e), t.dinahCard = e, W(t, H("dinah-action", {
			color: n.color,
			n: e
		})), !0;
	}
	if (n.kind === "acquire") {
		let e = n.n ?? 1, i = t.market[e - 1].findIndex(Boolean), a = t.market[e - 1][i];
		return W(t), a && (r.hand.push(a), t.market[e - 1][i] = null, Ge(t, r, "acquire")), !0;
	}
	if (n.kind === "invite") {
		let e = [...r.hand].sort((e, t) => N[t].tier - N[e].tier)[0];
		return W(t, ...(n.n ?? 1) > 1 ? [H("invite", { n: n.n - 1 })] : []), e ? (r.hand.splice(r.hand.indexOf(e), 1), r.invited.push(e), Ge(t, r, "invite")) : U(t, H("acquire", { n: 1 })), !0;
	}
	if (n.kind === "card-reward") return W(t, H(r.hand.length ? "invite" : "acquire", { n: r.hand.length ? 1 : n.n })), !0;
	if (n.kind === "bookmark") {
		let n = (e) => {
			let t = F.find((t) => t.id === e);
			return t.cost === "any2" ? 2 : t.cost.length;
		}, i = (e, t) => r.bookmarks.filter((r) => F.find((e) => e.id === r).kind === e && n(r) === t).length, a = t.bookmarks.map((e) => F.find((t) => t.id === e));
		a.some((e) => n(e.id) === 2) && (a = a.filter((e) => n(e.id) === 2));
		let o = Math.min(...a.map((e) => i(e.kind, n(e.id))));
		a = a.filter((e) => i(e.kind, n(e.id)) === o), a.some((e) => e.kind === "instant") ? (a = a.filter((e) => e.kind === "instant"), a.some((e) => e.reward?.some((e) => e.type === "cat")) && (a = a.filter((e) => e.reward?.some((e) => e.type === "cat")))) : a.some((e) => e.kind === (t.dinahCard === 7 ? "final" : "permanent")) && (a = a.filter((e) => e.kind === (t.dinahCard === 7 ? "final" : "permanent")));
		let s = a.length ? a[e(t.seed, t.cursor++, a.length)] : void 0;
		return W(t), s && (t.bookmarks.splice(t.bookmarks.indexOf(s.id), 1), r.bookmarks.push(s.id), s.kind === "instant" && s.reward && U(t, G(s.reward, r.rid))), !0;
	}
	if (n.kind === "mini") {
		let e = ft(t, r, n.suit, j(t.dinahColor), !0) ? j(t.dinahColor) : t.dinahColor;
		return W(t, ...ft(t, r, n.suit, e, !0) ? [H("action", {
			color: e,
			suit: n.suit,
			mini: !0
		})] : []), !0;
	}
	if (n.kind === "action" && n.suit === "club") {
		let e = oe.filter((e) => e.from === r.twins[n.color] && (n.mini ? e.tea : !e.tea)), i = t.dinahCard === 8, a = e.sort((e, t) => i ? P[t.to].x - P[e.to].x : P[e.to].x - P[t.to].x)[0];
		return W(t, ...a ? [H("climb", {
			color: n.color,
			target: a.from === r.twins[n.color] ? a.to : a.from
		})] : []), !0;
	}
	let i = wt(t).filter((e) => ![
		"skip",
		"pass",
		"exchange"
	].includes(e.kind));
	if (!i.length) return W(t), !0;
	let a;
	if (n.kind === "action" && n.suit === "spade") {
		let e = n.mini ? 1 : r.hand.length ? 2 : 3, o = i.filter((t) => t.n === e);
		a = (o.length ? o : i)[t.dinahCard % 2 ? (o.length ? o : i).length - 1 : 0];
	} else if (n.kind === "action" && n.suit === "heart" && !n.mini) {
		let e = Math.max(0, t.gardeners[n.color]), o = t.dinahCard === 1 ? [
			"orange",
			"blue",
			"cat",
			"black",
			"invite",
			"time",
			"yellow",
			"pink"
		] : [
			"pink",
			"yellow",
			"cat",
			"black",
			"invite",
			"time",
			"blue",
			"orange"
		], s = i.filter((e) => !(e.value?.startsWith("[") ? JSON.parse(e.value) : []).some((e) => e.flower && r.flowers[e.flower] >= 2)).sort((t, n) => {
			let r = (t.target - e + 4) % 4 - (n.target - e + 4) % 4, i = (e) => Math.min(...JSON.parse(e.value).map((e) => o.indexOf(e.flower ?? e.type)).filter((e) => e >= 0));
			return r || i(t) - i(n);
		});
		if (!s.length) return W(t, H("dinah-action-next", { color: n.color })), !0;
		a = s[0];
	} else a = n.kind === "action" && n.suit === "diamond" ? [...i].sort((e, r) => (e.n ?? 0) - (r.n ?? 0) || Math.floor(e.target / 4) - Math.floor(r.target / 4) || (t.dinahCard === 5 == (n.color === "red") ? e.target % 4 - r.target % 4 : r.target % 4 - e.target % 4))[0] : [...i].sort((e, t) => t.score - e.score)[0];
	return a.apply(t), !0;
}
function Nt(t, n, r) {
	let i = Ee.parse(t), a = n.length === 1 ? [...n, "queenalice-dinah"] : n, o = {
		seed: r,
		cursor: 0,
		phase: "setup",
		turn: 0,
		round: 1,
		tasks: [H("train")],
		players: [],
		pieces: [],
		decks: [],
		market: [],
		crowns: a.length + 4,
		alice: Fe(),
		crownSpaces: {
			red: a.length === 3 ? [5] : [],
			white: a.length === 3 ? [5] : []
		},
		wishes: [],
		pendingWishes: [],
		gardeners: {
			red: -1,
			white: -1
		},
		garden: {
			red: [],
			white: []
		},
		wall: {
			red: Array(20).fill(null),
			white: Array(20).fill(null)
		},
		eggs: Fe(),
		treeBooks: P.map((e) => e.cover),
		bookmarks: F.map((e) => e.id),
		seals: [],
		activeCard: null,
		activeColor: null,
		activeSuit: null,
		finalRound: !1,
		log: [],
		difficulty: i.difficulty,
		discount: {
			resource: "any",
			n: 0
		},
		repeatDiscount: 0,
		blackBudget: 0,
		dinahDeck: [],
		dinahDiscard: [],
		dinahCard: 0,
		dinahColor: "red",
		dinahFallback: 0,
		pendingBonuses: []
	}, s = Ue(o, Array.from({ length: 16 }, (e, t) => t));
	for (let e of a) {
		let t = e === "queenalice-dinah", n = {
			rid: e,
			ip: 0,
			time: 0,
			stock: [],
			capacity: 3,
			hearts: Fe(),
			diamonds: {
				red: [],
				white: []
			},
			cats: Fe(),
			messengers: Fe(),
			twins: Fe(),
			crowns: Fe(),
			advances: Fe(),
			flowers: {
				pink: 0,
				blue: 0,
				orange: 0,
				yellow: 0
			},
			books: {
				white: 0,
				green: 0,
				blue: 0
			},
			bookmarks: [],
			used: [],
			invited: [],
			discard: [],
			handCount: 0,
			deckCount: 0,
			deck: t ? [] : Ue(o, ae),
			hand: [],
			train: null,
			trains: t ? [] : [s.pop(), s.pop()],
			booksTaken: 0,
			seals: 0,
			dinah: t,
			resourceRow: 0,
			resourceSide: "red",
			blackTrack: 0,
			final: []
		};
		if (!t) for (let e = 0; e < 3; e++) We(o, n);
		o.players.push(n);
	}
	for (let e of D) o.garden[e] = L(e, o.players.length).map((e) => e.map(() => null));
	for (let e = 1; e <= 3; e++) o.decks.push(Ue(o, Object.values(N).filter((t) => t.tier === e).map((e) => e.id))), o.market.push([]);
	St(o), o.wishes = Ue(o, [
		0,
		1,
		2,
		3
	].map((t) => t * 4 + e(o.seed, o.cursor++, 4))).map((e, t) => ({
		id: e,
		color: t < 2 ? "red" : "white",
		triggered: !1
	}));
	let c = [
		["rook", 7],
		["knight", 3],
		["bishop", 4],
		["king", 1],
		["queen", 0],
		["pawn", 11],
		["pawn", 13],
		["pawn", 17],
		["pawn", 5]
	];
	for (let e of D) for (let [t, [n, r]] of c.entries()) o.pieces.push({
		id: `${e}-${t}`,
		type: n,
		color: e,
		square: e === "white" ? r : 39 - r,
		prison: null
	});
	return o.dinahDeck = Ue(o, Array.from({ length: 10 }, (e, t) => t)), { state: o };
}
var Pt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: Se,
	schemas: {
		action: De,
		publicView: Ne,
		privateView: Pe,
		config: Ee
	},
	setup: Nt,
	reduce(e, t, n) {
		if (t.type === "tick") {
			if (e.phase === "done" || !Dt(e) && !B(e).dinah) return { state: e };
			let t = structuredClone(e);
			return t.effects = [], t.beatMs = K.idle, xt(t) || Mt(t), Ke(t), ze(t);
		}
		if (e.phase === "done" || Dt(e) || B(e).dinah || B(e).rid !== n.by) return { code: "games.queenalice.errTurn" };
		let r = structuredClone(e), i = wt(r).find((e) => e.id === t.id);
		if (!i) return { code: "games.queenalice.errChoice" };
		r.effects = [], r.beatMs = K.idle;
		let a = Tt(r, i);
		return i.apply(r), V(r)?.kind === "pay" && i.kind !== "payment" && e.tasks[0]?.kind !== "pay" && (V(r).preview = a), Ke(r), ze(r);
	},
	viewFor(e, t) {
		let n = e.players.find((e) => e.rid === t);
		return {
			public: {
				phase: e.phase,
				round: e.round,
				actor: B(e).rid,
				prompt: V(e)?.kind ?? "done",
				players: e.players.map((e) => {
					let { deck: t, hand: n, trains: r, ...i } = e;
					return {
						...i,
						deckCount: t.length,
						handCount: n.length
					};
				}),
				pieces: e.pieces,
				market: e.market,
				marketCounts: e.decks.map((e) => e.length),
				crowns: e.crowns,
				alice: e.alice,
				crownSpaces: e.crownSpaces,
				wishes: e.wishes,
				gardeners: e.gardeners,
				garden: e.garden,
				wall: e.wall,
				eggs: e.eggs,
				pendingWishes: e.pendingWishes,
				context: V(e)?.preview,
				remaining: V(e)?.n,
				mini: V(e)?.mini,
				source: V(e)?.source,
				sourceCard: V(e)?.sourceCard,
				sourceScene: V(e)?.scene,
				pendingRewards: V(e)?.rewards ?? (V(e)?.reward ? [{
					...V(e).reward,
					n: V(e).n ?? V(e).reward.n
				}] : void 0),
				treeBooks: e.treeBooks,
				bookmarks: e.bookmarks,
				seals: e.seals,
				activeCard: e.activeCard,
				activeColor: e.activeColor,
				activeSuit: e.activeSuit,
				finalRound: e.finalRound,
				log: e.log,
				difficulty: e.difficulty
			},
			private: {
				hand: n?.hand ?? [],
				trains: n?.trains ?? [],
				choices: !Dt(e) && B(e).rid === t && !B(e).dinah ? wt(e).map(({ apply: t, ...n }) => Tt(e, n)) : []
			}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((e, t) => t.ip - e.ip);
		return {
			phase: "done",
			winner: t.filter((e) => e.ip === t[0].ip).map((e) => e.rid),
			ranking: t.map((e) => e.rid),
			scores: Object.fromEntries(e.players.map((e) => [e.rid, e.ip]))
		};
	},
	nextTickIn(e) {
		return e.phase !== "done" && (Dt(e) || B(e).dinah) ? e.beatMs ?? K.idle : null;
	}
}, Ft = {
	miniChooseDiamond: "games.queenalice.miniChooseDiamond",
	startsFinalRound: "games.queenalice.startsFinalRound",
	removesSupplyCrown: "games.queenalice.removesSupplyCrown",
	dinahDiamondOrder: "games.queenalice.dinahDiamondOrder",
	inviteFromHand: "games.queenalice.inviteFromHand",
	inviteFromDiscard: "games.queenalice.inviteFromDiscard",
	marketFeeFree: "games.queenalice.marketFeeFree",
	marketFeeTime: "games.queenalice.marketFeeTime",
	marketFeeResource: "games.queenalice.marketFeeResource",
	marketUpgrade: "games.queenalice.marketUpgrade",
	marketDowngrade: "games.queenalice.marketDowngrade",
	marketHand: "games.queenalice.marketHand",
	viewCard: "games.queenalice.viewCard",
	cardDetails: "games.queenalice.cardDetails",
	guestFixed: "games.queenalice.guestFixed",
	kingAnyAction: "games.queenalice.kingAnyAction",
	wildColorHelp: "games.queenalice.wildColorHelp",
	bookmarkTime: "games.queenalice.bookmarkTime",
	bookmarkUsed: "games.queenalice.bookmarkUsed",
	bookmarkAvailable: "games.queenalice.bookmarkAvailable",
	anyTwoBooks: "games.queenalice.anyTwoBooks",
	trackTaken: "games.queenalice.trackTaken",
	trackNext: "games.queenalice.trackNext",
	trackFuture: "games.queenalice.trackFuture",
	trackAvailable: "games.queenalice.trackAvailable",
	diamondAnyOrder: "games.queenalice.diamondAnyOrder",
	diamondCount: "games.queenalice.diamondCount",
	extraDiscardHelp: "games.queenalice.extraDiscardHelp",
	trimHelp: "games.queenalice.trimHelp",
	inviteHelp: "games.queenalice.inviteHelp",
	repeatHelp: "games.queenalice.repeatHelp",
	promotionReturn: "games.queenalice.promotionReturn",
	selectCapture: "games.queenalice.selectCapture",
	selectBook: "games.queenalice.selectBook",
	fullStorage: "games.queenalice.fullStorage",
	fullCapacity: "games.queenalice.fullCapacity",
	miniHelp: "games.queenalice.miniHelp",
	afterPayment: "games.queenalice.afterPayment",
	paymentTarget: "games.queenalice.paymentTarget",
	discountCardOrRepeat: "games.queenalice.discountCardOrRepeat",
	discountCard: "games.queenalice.discountCard",
	discountRepeat: "games.queenalice.discountRepeat",
	discountBookmark: "games.queenalice.discountBookmark",
	rescuePreview: "games.queenalice.rescuePreview",
	captureTarget: "games.queenalice.captureTarget",
	promotionPreview: "games.queenalice.promotionPreview",
	catAt: "games.queenalice.catAt",
	progressAt: "games.queenalice.progressAt",
	crownFallback: "games.queenalice.crownFallback",
	wishPending: "games.queenalice.wishPending",
	catCrossingHelp: "games.queenalice.catCrossingHelp",
	noImmediateReward: "games.queenalice.noImmediateReward",
	promptBook: "games.queenalice.promptBook",
	promptCapture: "games.queenalice.promptCapture",
	promptPromote: "games.queenalice.promptPromote",
	aliceEndHelp: "games.queenalice.aliceEndHelp",
	heartRewardSource: "games.queenalice.heartRewardSource",
	spaceRewardSource: "games.queenalice.spaceRewardSource",
	gardenerTeaSource: "games.queenalice.gardenerTeaSource",
	passRestHelp: "games.queenalice.passRestHelp",
	orangeRepeatHelp: "games.queenalice.orangeRepeatHelp",
	trainStart0: "games.queenalice.trainStart0",
	trainStart1: "games.queenalice.trainStart1",
	trainStart2: "games.queenalice.trainStart2",
	trainStart3: "games.queenalice.trainStart3",
	trainStart4: "games.queenalice.trainStart4",
	trainStart5: "games.queenalice.trainStart5",
	trainStart6: "games.queenalice.trainStart6",
	trainStart7: "games.queenalice.trainStart7",
	trainStart8: "games.queenalice.trainStart8",
	trainStart9: "games.queenalice.trainStart9",
	trainStart10: "games.queenalice.trainStart10",
	trainStart11: "games.queenalice.trainStart11",
	trainStart12: "games.queenalice.trainStart12",
	trainStart13: "games.queenalice.trainStart13",
	trainStart14: "games.queenalice.trainStart14",
	trainStart15: "games.queenalice.trainStart15",
	trainDinah: "games.queenalice.trainDinah",
	progressDetails: "games.queenalice.progressDetails",
	trackPosition: "games.queenalice.trackPosition",
	aliceHere: "games.queenalice.aliceHere",
	crownPositions: "games.queenalice.crownPositions",
	crownHelp: "games.queenalice.crownHelp",
	crownFinalHelp: "games.queenalice.crownFinalHelp",
	catHelp: "games.queenalice.catHelp",
	catSteps: "games.queenalice.catSteps",
	catNoWish: "games.queenalice.catNoWish",
	catOneWish: "games.queenalice.catOneWish",
	catTwoWishes: "games.queenalice.catTwoWishes",
	catNext: "games.queenalice.catNext",
	inspectSpaces: "games.queenalice.inspectSpaces",
	finishInspect: "games.queenalice.finishInspect",
	locationDetails: "games.queenalice.locationDetails",
	wishScoringHelp: "games.queenalice.wishScoringHelp",
	wishPlatinumHelp: "games.queenalice.wishPlatinumHelp",
	wishDetail0: "games.queenalice.wishDetail0",
	wishDetail1: "games.queenalice.wishDetail1",
	wishDetail2: "games.queenalice.wishDetail2",
	wishDetail3: "games.queenalice.wishDetail3",
	wishDetail4: "games.queenalice.wishDetail4",
	wishDetail5: "games.queenalice.wishDetail5",
	wishDetail6: "games.queenalice.wishDetail6",
	wishDetail7: "games.queenalice.wishDetail7",
	wishDetail8: "games.queenalice.wishDetail8",
	wishDetail9: "games.queenalice.wishDetail9",
	wishDetail10: "games.queenalice.wishDetail10",
	wishDetail11: "games.queenalice.wishDetail11",
	wishDetail12: "games.queenalice.wishDetail12",
	wishDetail13: "games.queenalice.wishDetail13",
	wishDetail14: "games.queenalice.wishDetail14",
	wishDetail15: "games.queenalice.wishDetail15",
	boardDetails: "games.queenalice.boardDetails",
	boardCurrentOptions: "games.queenalice.boardCurrentOptions",
	boardRows: "games.queenalice.boardRows",
	boardRow: "games.queenalice.boardRow",
	boardRowHelp: "games.queenalice.boardRowHelp",
	boardColumns: "games.queenalice.boardColumns",
	boardColumnHelp: "games.queenalice.boardColumnHelp",
	boardCaptureHelp: "games.queenalice.boardCaptureHelp",
	boardAliceHelp: "games.queenalice.boardAliceHelp",
	boardAlicePoints: "games.queenalice.boardAlicePoints",
	boardBaseCost: "games.queenalice.boardBaseCost",
	boardPaymentHelp: "games.queenalice.boardPaymentHelp",
	boardHeartNumber: "games.queenalice.boardHeartNumber",
	boardGardenHelp: "games.queenalice.boardGardenHelp",
	boardGardenerCost: "games.queenalice.boardGardenerCost",
	boardMoveSteps: "games.queenalice.boardMoveSteps",
	boardMessengerHelp: "games.queenalice.boardMessengerHelp",
	boardTreeHelp: "games.queenalice.boardTreeHelp",
	boardTreeCovered: "games.queenalice.boardTreeCovered",
	boardWallHelp: "games.queenalice.boardWallHelp",
	boardDiamondNumber: "games.queenalice.boardDiamondNumber",
	boardDiamondMilestones: "games.queenalice.boardDiamondMilestones",
	boardSpaces: "games.queenalice.boardSpaces",
	boardOccupied: "games.queenalice.boardOccupied",
	boardBlocked: "games.queenalice.boardBlocked",
	boardSealFirst: "games.queenalice.boardSealFirst",
	boardSealLater: "games.queenalice.boardSealLater",
	boardPassing: "games.queenalice.boardPassing",
	boardEggBonus: "games.queenalice.boardEggBonus",
	boardIcons: "games.queenalice.boardIcons",
	flowerPermanent: "games.queenalice.flowerPermanent",
	flowerThreshold: "games.queenalice.flowerThreshold",
	flowerUnlocked: "games.queenalice.flowerUnlocked",
	flowerLocked: "games.queenalice.flowerLocked",
	flowerPinkOne: "games.queenalice.flowerPinkOne",
	flowerPinkTwo: "games.queenalice.flowerPinkTwo",
	flowerBlueOne: "games.queenalice.flowerBlueOne",
	flowerBlueTwo: "games.queenalice.flowerBlueTwo",
	flowerOrangeOne: "games.queenalice.flowerOrangeOne",
	flowerOrangeTwo: "games.queenalice.flowerOrangeTwo",
	flowerYellowOne: "games.queenalice.flowerYellowOne",
	flowerYellowTwo: "games.queenalice.flowerYellowTwo",
	flowerDinah: "games.queenalice.flowerDinah",
	flowerDinahPoints: "games.queenalice.flowerDinahPoints",
	name: "games.queenalice.name",
	desc: "games.queenalice.desc",
	rules: "games.queenalice.rules",
	round: "games.queenalice.round",
	supply: "games.queenalice.supply",
	finalRound: "games.queenalice.finalRound",
	waiting: "games.queenalice.waiting",
	you: "games.queenalice.you",
	dinah: "games.queenalice.dinah",
	score: "games.queenalice.score",
	resources: "games.queenalice.resources",
	time: "games.queenalice.time",
	capacity: "games.queenalice.capacity",
	hand: "games.queenalice.hand",
	discardPile: "games.queenalice.discardPile",
	invited: "games.queenalice.invited",
	deck: "games.queenalice.deck",
	red: "games.queenalice.red",
	white: "games.queenalice.white",
	wild: "games.queenalice.wild",
	cake: "games.queenalice.cake",
	tea: "games.queenalice.tea",
	toast: "games.queenalice.toast",
	any: "games.queenalice.any",
	pawn: "games.queenalice.pawn",
	knight: "games.queenalice.knight",
	bishop: "games.queenalice.bishop",
	rook: "games.queenalice.rook",
	queen: "games.queenalice.queen",
	king: "games.queenalice.king",
	tier0: "games.queenalice.tier0",
	tier1: "games.queenalice.tier1",
	tier2: "games.queenalice.tier2",
	tier3: "games.queenalice.tier3",
	heart: "games.queenalice.heart",
	spade: "games.queenalice.spade",
	club: "games.queenalice.club",
	diamond: "games.queenalice.diamond",
	board: "games.queenalice.board",
	market: "games.queenalice.market",
	court: "games.queenalice.court",
	books: "games.queenalice.books",
	bookmarks: "games.queenalice.bookmarks",
	wishes: "games.queenalice.wishes",
	logTitle: "games.queenalice.logTitle",
	pink: "games.queenalice.pink",
	blue: "games.queenalice.blue",
	orange: "games.queenalice.orange",
	yellow: "games.queenalice.yellow",
	playEffect: "games.queenalice.playEffect",
	discardEffect: "games.queenalice.discardEffect",
	invitedEffect: "games.queenalice.invitedEffect",
	empty: "games.queenalice.empty",
	free: "games.queenalice.free",
	cost: "games.queenalice.cost",
	paidPosition: "games.queenalice.paidPosition",
	trainTitle: "games.queenalice.trainTitle",
	train: "games.queenalice.train",
	train0: "games.queenalice.train0",
	train1: "games.queenalice.train1",
	train2: "games.queenalice.train2",
	train3: "games.queenalice.train3",
	train4: "games.queenalice.train4",
	train5: "games.queenalice.train5",
	train6: "games.queenalice.train6",
	train7: "games.queenalice.train7",
	train8: "games.queenalice.train8",
	train9: "games.queenalice.train9",
	train10: "games.queenalice.train10",
	train11: "games.queenalice.train11",
	train12: "games.queenalice.train12",
	train13: "games.queenalice.train13",
	train14: "games.queenalice.train14",
	train15: "games.queenalice.train15",
	skip: "games.queenalice.skip",
	claim: "games.queenalice.claim",
	gain: "games.queenalice.gain",
	replace: "games.queenalice.replace",
	color: "games.queenalice.color",
	book: "games.queenalice.book",
	capture: "games.queenalice.capture",
	rescue: "games.queenalice.rescue",
	move: "games.queenalice.move",
	action: "games.queenalice.action",
	pass: "games.queenalice.pass",
	pay: "games.queenalice.pay",
	payTime: "games.queenalice.payTime",
	payBlack: "games.queenalice.payBlack",
	discount: "games.queenalice.discount",
	drop: "games.queenalice.drop",
	mini: "games.queenalice.mini",
	removeDiamond: "games.queenalice.removeDiamond",
	plant: "games.queenalice.plant",
	build: "games.queenalice.build",
	climb: "games.queenalice.climb",
	advance: "games.queenalice.advance",
	acquire: "games.queenalice.acquire",
	takeCard: "games.queenalice.takeCard",
	invite: "games.queenalice.invite",
	extraDiscard: "games.queenalice.extraDiscard",
	bookmark: "games.queenalice.bookmark",
	repeat: "games.queenalice.repeat",
	rest: "games.queenalice.rest",
	scoreWish: "games.queenalice.scoreWish",
	exchangeTea: "games.queenalice.exchangeTea",
	chooseSquare: "games.queenalice.chooseSquare",
	square: "games.queenalice.square",
	noDecision: "games.queenalice.noDecision",
	allPieces: "games.queenalice.allPieces",
	promptTrain: "games.queenalice.promptTrain",
	promptDiscard: "games.queenalice.promptDiscard",
	promptPlay: "games.queenalice.promptPlay",
	promptRewards: "games.queenalice.promptRewards",
	promptResource: "games.queenalice.promptResource",
	promptColor: "games.queenalice.promptColor",
	promptMove: "games.queenalice.promptMove",
	promptColumn: "games.queenalice.promptColumn",
	promptPay: "games.queenalice.promptPay",
	promptAction: "games.queenalice.promptAction",
	promptMini: "games.queenalice.promptMini",
	promptAcquire: "games.queenalice.promptAcquire",
	promptInvite: "games.queenalice.promptInvite",
	promptBookmark: "games.queenalice.promptBookmark",
	promptRepeat: "games.queenalice.promptRepeat",
	promptTrim: "games.queenalice.promptTrim",
	promptFinalWish: "games.queenalice.promptFinalWish",
	easy: "games.queenalice.easy",
	normal: "games.queenalice.normal",
	hard: "games.queenalice.hard",
	expert: "games.queenalice.expert",
	difficulty: "games.queenalice.difficulty",
	difficultyHelp: "games.queenalice.difficultyHelp",
	gardener: "games.queenalice.gardener",
	resting: "games.queenalice.resting",
	region: "games.queenalice.region",
	egg: "games.queenalice.egg",
	treeHeight: "games.queenalice.treeHeight",
	messengerStep: "games.queenalice.messengerStep",
	cats: "games.queenalice.cats",
	crowns: "games.queenalice.crowns",
	advances: "games.queenalice.advances",
	unlocked: "games.queenalice.unlocked",
	instant: "games.queenalice.instant",
	permanent: "games.queenalice.permanent",
	final: "games.queenalice.final",
	"event-black": "games.queenalice.event-black",
	"event-acquire": "games.queenalice.event-acquire",
	"event-invite": "games.queenalice.event-invite",
	"event-capture": "games.queenalice.event-capture",
	"event-rescue": "games.queenalice.event-rescue",
	"event-alice": "games.queenalice.event-alice",
	"discount-heart-own": "games.queenalice.discount-heart-own",
	"discount-spade-own": "games.queenalice.discount-spade-own",
	"discount-diamond-own": "games.queenalice.discount-diamond-own",
	"discount-heart-tea": "games.queenalice.discount-heart-tea",
	"discount-spade-tea": "games.queenalice.discount-spade-tea",
	"discount-diamond-tea": "games.queenalice.discount-diamond-tea",
	"cat-red": "games.queenalice.cat-red",
	"cat-white": "games.queenalice.cat-white",
	"mini-heart": "games.queenalice.mini-heart",
	"mini-diamond": "games.queenalice.mini-diamond",
	"score-cat-red": "games.queenalice.score-cat-red",
	"score-cat-white": "games.queenalice.score-cat-white",
	"score-invite-red": "games.queenalice.score-invite-red",
	"score-invite-white": "games.queenalice.score-invite-white",
	"score-cards": "games.queenalice.score-cards",
	"score-black": "games.queenalice.score-black",
	"score-time": "games.queenalice.score-time",
	"score-alice-red": "games.queenalice.score-alice-red",
	"score-alice-white": "games.queenalice.score-alice-white",
	wish0: "games.queenalice.wish0",
	wish1: "games.queenalice.wish1",
	wish2: "games.queenalice.wish2",
	wish3: "games.queenalice.wish3",
	wish4: "games.queenalice.wish4",
	wish5: "games.queenalice.wish5",
	wish6: "games.queenalice.wish6",
	wish7: "games.queenalice.wish7",
	wish8: "games.queenalice.wish8",
	wish9: "games.queenalice.wish9",
	wish10: "games.queenalice.wish10",
	wish11: "games.queenalice.wish11",
	wish12: "games.queenalice.wish12",
	wish13: "games.queenalice.wish13",
	wish14: "games.queenalice.wish14",
	wish15: "games.queenalice.wish15",
	wishRate: "games.queenalice.wishRate",
	wishTriggered: "games.queenalice.wishTriggered",
	catThreshold: "games.queenalice.catThreshold",
	during: "games.queenalice.during",
	guests: "games.queenalice.guests",
	finalBookmarks: "games.queenalice.finalBookmarks",
	finalCrowns: "games.queenalice.finalCrowns",
	finalWishes: "games.queenalice.finalWishes",
	dinahBonus: "games.queenalice.dinahBonus",
	errTurn: "games.queenalice.errTurn",
	errChoice: "games.queenalice.errChoice",
	logMove: "games.queenalice.logMove",
	logCapture: "games.queenalice.logCapture",
	logRescue: "games.queenalice.logRescue",
	logPlant: "games.queenalice.logPlant",
	logBuild: "games.queenalice.logBuild",
	logClimb: "games.queenalice.logClimb",
	logAdvance: "games.queenalice.logAdvance",
	logAlice: "games.queenalice.logAlice",
	logCrown: "games.queenalice.logCrown",
	logAcquire: "games.queenalice.logAcquire",
	logInvite: "games.queenalice.logInvite",
	logBookmark: "games.queenalice.logBookmark",
	logWish: "games.queenalice.logWish",
	ruleSource: "games.queenalice.ruleSource",
	play: "games.queenalice.play",
	discard: "games.queenalice.discard",
	"extra-discard": "games.queenalice.extra-discard",
	trim: "games.queenalice.trim",
	ip: "games.queenalice.ip",
	resource: "games.queenalice.resource",
	black: "games.queenalice.black",
	cat: "games.queenalice.cat",
	alice: "games.queenalice.alice",
	crown: "games.queenalice.crown",
	flower: "games.queenalice.flower",
	guest0normal: "games.queenalice.guest0normal",
	guest0wild: "games.queenalice.guest0wild",
	guest0king: "games.queenalice.guest0king",
	guest0queen: "games.queenalice.guest0queen",
	guest1normal: "games.queenalice.guest1normal",
	guest1wild: "games.queenalice.guest1wild",
	guest1king: "games.queenalice.guest1king",
	guest1queen: "games.queenalice.guest1queen",
	guest2normal: "games.queenalice.guest2normal",
	guest2wild: "games.queenalice.guest2wild",
	guest2king: "games.queenalice.guest2king",
	guest2queen: "games.queenalice.guest2queen",
	guest3normal: "games.queenalice.guest3normal",
	guest3wild: "games.queenalice.guest3wild",
	guest3king: "games.queenalice.guest3king",
	guest3queen: "games.queenalice.guest3queen",
	payStar: "games.queenalice.payStar",
	promptPlayColor: "games.queenalice.promptPlayColor",
	dinahMove: "games.queenalice.dinahMove",
	promptDinahMove: "games.queenalice.promptDinahMove",
	cardReward: "games.queenalice.cardReward",
	"book-white": "games.queenalice.book-white",
	"book-green": "games.queenalice.book-green",
	"book-blue": "games.queenalice.book-blue",
	"book-any": "games.queenalice.book-any",
	"book-white-green": "games.queenalice.book-white-green",
	"book-green-blue": "games.queenalice.book-green-blue",
	anyResource: "games.queenalice.anyResource",
	rewardCapturePawn: "games.queenalice.rewardCapturePawn",
	rewardCapturePiece: "games.queenalice.rewardCapturePiece",
	rewardAcquire: "games.queenalice.rewardAcquire",
	rewardInvite: "games.queenalice.rewardInvite",
	rewardBlack: "games.queenalice.rewardBlack",
	rewardMini: "games.queenalice.rewardMini",
	rewardExtra: "games.queenalice.rewardExtra",
	rewardCard: "games.queenalice.rewardCard",
	movePiece: "games.queenalice.movePiece",
	playAndMove: "games.queenalice.playAndMove",
	noDiscardReward: "games.queenalice.noDiscardReward",
	receive: "games.queenalice.receive",
	thenAction: "games.queenalice.thenAction",
	selectOnBoard: "games.queenalice.selectOnBoard",
	selectMarket: "games.queenalice.selectMarket",
	selectMove: "games.queenalice.selectMove",
	confirmPayment: "games.queenalice.confirmPayment",
	otherPayments: "games.queenalice.otherPayments",
	paymentPlans: "games.queenalice.paymentPlans",
	paymentCube: "games.queenalice.paymentCube",
	paymentDiscount: "games.queenalice.paymentDiscount",
	fromCard: "games.queenalice.fromCard",
	storeResource: "games.queenalice.storeResource",
	replaceResource: "games.queenalice.replaceResource",
	starCost: "games.queenalice.starCost",
	remainingRewards: "games.queenalice.remainingRewards",
	cardInHand: "games.queenalice.cardInHand"
}, Y = (e) => Ft[e], It = "<svg xmlns=\"http://www.w3.org/2000/svg\"><defs>\n <linearGradient id=\"qa-art-paper\" x2=\".7\" y2=\"1\"><stop stop-color=\"#fff7e3\"/><stop offset=\".55\" stop-color=\"#f4e6c6\"/><stop offset=\"1\" stop-color=\"#dfc9a4\"/></linearGradient>\n <linearGradient id=\"qa-art-coral\" x1=\"0\" y1=\"0\" x2=\".8\" y2=\"1\"><stop stop-color=\"#f49a86\"/><stop offset=\".5\" stop-color=\"#e57167\"/><stop offset=\"1\" stop-color=\"#b74747\"/></linearGradient>\n <linearGradient id=\"qa-art-ivory\" x2=\".9\" y2=\"1\"><stop stop-color=\"#fffdf0\"/><stop offset=\".5\" stop-color=\"#eee9db\"/><stop offset=\"1\" stop-color=\"#aab9b7\"/></linearGradient>\n <linearGradient id=\"qa-art-teal\" x2=\"1\" y2=\"1\"><stop stop-color=\"#c8ddd8\"/><stop offset=\".6\" stop-color=\"#87a7a3\"/><stop offset=\"1\" stop-color=\"#4a6b64\"/></linearGradient>\n <linearGradient id=\"qa-art-gilt\" x2=\"1\" y2=\"1\"><stop stop-color=\"#fff2ae\"/><stop offset=\".4\" stop-color=\"#e4c66b\"/><stop offset=\".65\" stop-color=\"#bda35c\"/><stop offset=\"1\" stop-color=\"#e5d497\"/></linearGradient>\n <linearGradient id=\"qa-art-wood\" x2=\".9\" y2=\"1\"><stop stop-color=\"#443735\"/><stop offset=\".4\" stop-color=\"#302c30\"/><stop offset=\"1\" stop-color=\"#51413c\"/></linearGradient>\n <pattern id=\"qa-art-damask\" width=\"52\" height=\"64\" patternUnits=\"userSpaceOnUse\"><path d=\"M26 3C7 18 6 29 26 43 46 29 45 18 26 3ZM26 13v33M14 28q12-16 24 0M17 36l9-10 9 10M0 59q13-21 26 0 13-21 26 0\" fill=\"none\" stroke=\"#f4c6af\" stroke-width=\"1\" opacity=\".18\"/></pattern>\n <pattern id=\"qa-art-hatch\" width=\"7\" height=\"7\" patternUnits=\"userSpaceOnUse\"><path d=\"m0 7 7-7\" stroke=\"#392d27\" stroke-width=\".8\" opacity=\".13\"/></pattern>\n <pattern id=\"qa-art-grain\" width=\"160\" height=\"120\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 21q40-8 80 0t80 0M0 26q40-8 80 0t80 0M0 87q67-15 160-2M0 92q67-15 160-2\" fill=\"none\" stroke=\"#c6a37c\" stroke-width=\"1\" opacity=\".07\"/></pattern>\n <symbol id=\"qa-art-leaf\" viewBox=\"0 0 60 30\"><path d=\"M2 27C5 4 33-2 56 3 51 23 32 32 2 27Z\" fill=\"url(#qa-art-teal)\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M3 27 49 7M14 22l0-9m8 6 2-10m5 7 8 2m-1-8 8 1\" fill=\"none\" stroke=\"#49695d\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M6 29 17 25 23 27 32 22 40 22\" fill=\"none\" stroke=\"#e4e0b6\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-rose\" viewBox=\"0 0 70 70\"><path d=\"M35 4 48 10 60 12 64 25 67 37 60 50 47 60 32 65 18 57 6 46 5 29 13 15 23 9Z\" fill=\"url(#qa-art-coral)\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M13 30C16 13 37 10 47 20 64 35 45 59 28 50 7 39 23 17 39 24 55 33 38 46 29 36 23 28 37 23 39 32M8 40l11 12 13 4m14-44 11 12M13 26l7-9\" fill=\"none\" stroke=\"#813f3f\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M28 53 43 51 55 40M18 22l9-5 13 1\" fill=\"none\" stroke=\"#f9b2a0\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-flower\" viewBox=\"0 0 64 64\"><g stroke=\"#453c33\" stroke-width=\"1.3\"><path d=\"M32 32C7 18 13-5 30 7 43-8 57 14 32 32Z\" fill=\"currentColor\" transform=\"rotate(0 32 32)\"/><path d=\"M32 32C7 18 13-5 30 7 43-8 57 14 32 32Z\" fill=\"currentColor\" transform=\"rotate(72 32 32)\"/><path d=\"M32 32C7 18 13-5 30 7 43-8 57 14 32 32Z\" fill=\"currentColor\" transform=\"rotate(144 32 32)\"/><path d=\"M32 32C7 18 13-5 30 7 43-8 57 14 32 32Z\" fill=\"currentColor\" transform=\"rotate(216 32 32)\"/><path d=\"M32 32C7 18 13-5 30 7 43-8 57 14 32 32Z\" fill=\"currentColor\" transform=\"rotate(288 32 32)\"/></g><circle cx=\"32\" cy=\"32\" r=\"8\" fill=\"#edca7b\" stroke=\"#453c33\" stroke-width=\"1.5\"/><path d=\"M31 20 32 24\" stroke=\"#584b39\" transform=\"rotate(0 32 32)\"/><path d=\"M31 20 32 24\" stroke=\"#584b39\" transform=\"rotate(36 32 32)\"/><path d=\"M31 20 32 24\" stroke=\"#584b39\" transform=\"rotate(72 32 32)\"/><path d=\"M31 20 32 24\" stroke=\"#584b39\" transform=\"rotate(108 32 32)\"/><path d=\"M31 20 32 24\" stroke=\"#584b39\" transform=\"rotate(144 32 32)\"/><path d=\"M31 20 32 24\" stroke=\"#584b39\" transform=\"rotate(180 32 32)\"/><path d=\"M31 20 32 24\" stroke=\"#584b39\" transform=\"rotate(216 32 32)\"/><path d=\"M31 20 32 24\" stroke=\"#584b39\" transform=\"rotate(252 32 32)\"/><path d=\"M31 20 32 24\" stroke=\"#584b39\" transform=\"rotate(288 32 32)\"/><path d=\"M31 20 32 24\" stroke=\"#584b39\" transform=\"rotate(324 32 32)\"/></symbol>\n <symbol id=\"qa-art-crown\" viewBox=\"0 0 80 68\"><path d=\"M8 17 24 31 40 9 55 31 72 17 64 54H17Z\" fill=\"url(#qa-art-gilt)\" stroke=\"#292d30\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M17 44h47M19 55h42v6H19Z\" fill=\"#d4ae43\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"9\" cy=\"15\" rx=\"3.5\" ry=\"3.5\" fill=\"#8eb4c2\" stroke=\"#292d30\" stroke-width=\"1.4\"/><ellipse cx=\"40\" cy=\"7\" rx=\"3.5\" ry=\"3.5\" fill=\"#8eb4c2\" stroke=\"#292d30\" stroke-width=\"1.4\"/><ellipse cx=\"71\" cy=\"15\" rx=\"3.5\" ry=\"3.5\" fill=\"#8eb4c2\" stroke=\"#292d30\" stroke-width=\"1.4\"/><rect x=\"21\" y=\"38\" width=\"8\" height=\"9\" rx=\"2\" fill=\"#fffdf3\" stroke=\"#292d30\" stroke-width=\"1\"/><rect x=\"36\" y=\"38\" width=\"8\" height=\"9\" rx=\"2\" fill=\"#dd6b61\" stroke=\"#292d30\" stroke-width=\"1\"/><rect x=\"51\" y=\"38\" width=\"8\" height=\"9\" rx=\"2\" fill=\"#fffdf3\" stroke=\"#292d30\" stroke-width=\"1\"/><path d=\"M19 24 22 39M42 17 45 29\" fill=\"none\" stroke=\"#fff4b1\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-paw\" viewBox=\"0 0 52 52\"><path d=\"M9 36Q7 29 19 23 26 15 34 25 46 30 43 40 40 49 26 44 11 50 9 36Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"10\" cy=\"18\" rx=\"5.5\" ry=\"8\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" transform=\"rotate(-25 10 18)\"/><ellipse cx=\"22\" cy=\"10\" rx=\"5.5\" ry=\"8\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" transform=\"rotate(-5 22 10)\"/><ellipse cx=\"35\" cy=\"12\" rx=\"5.5\" ry=\"8\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" transform=\"rotate(20 35 12)\"/><ellipse cx=\"44\" cy=\"22\" rx=\"5.5\" ry=\"8\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" transform=\"rotate(35 44 22)\"/></symbol>\n <symbol id=\"qa-art-clock\" viewBox=\"0 0 70 78\"><ellipse cx=\"35\" cy=\"8\" rx=\"8\" ry=\"6\" fill=\"url(#qa-art-gilt)\" stroke=\"#292d30\" stroke-width=\"1.4\"/><rect x=\"29\" y=\"12\" width=\"12\" height=\"6\" rx=\"2\" fill=\"#d4ae43\" stroke=\"#292d30\" stroke-width=\"1.6\"/><ellipse cx=\"35\" cy=\"45\" rx=\"29\" ry=\"30\" fill=\"url(#qa-art-gilt)\" stroke=\"#292d30\" stroke-width=\"2\"/><ellipse cx=\"35\" cy=\"45\" rx=\"24\" ry=\"25\" fill=\"#fffdf3\" stroke=\"#292d30\" stroke-width=\"1.4\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(0 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(30 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(60 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(90 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(120 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(150 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(180 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(210 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(240 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(270 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(300 35 45)\"/><path d=\"M35 23v3\" stroke=\"#292d30\" transform=\"rotate(330 35 45)\"/><path d=\"M35 28v18l11 7\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"35\" cy=\"46\" rx=\"2\" ry=\"2\" fill=\"#292d30\" stroke=\"#292d30\" stroke-width=\"1.4\"/></symbol>\n <symbol id=\"qa-art-cup\" viewBox=\"0 0 74 68\"><ellipse cx=\"34\" cy=\"55\" rx=\"31\" ry=\"8\" fill=\"#8eb4c2\" stroke=\"#292d30\" stroke-width=\"1.8\"/><path d=\"M10 24h45l-7 25q-18 13-32 0Z\" fill=\"url(#qa-art-ivory)\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M53 28C75 19 76 49 52 47\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M54 30C69 24 68 42 54 43\" fill=\"none\" stroke=\"#fffdf3\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"32\" cy=\"25\" rx=\"22\" ry=\"7\" fill=\"#b39958\" stroke=\"#292d30\" stroke-width=\"1.6\"/><ellipse cx=\"32\" cy=\"24\" rx=\"17\" ry=\"4\" fill=\"#d1bb75\" stroke=\"none\" stroke-width=\"1.4\"/><path d=\"M20 35q1 8 5 11M12 58q25 7 48-1\" fill=\"none\" stroke=\"#6e929f\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-cake\" viewBox=\"0 0 74 68\"><path d=\"M7 32 54 13l13 34-49 17Z\" fill=\"#b54449\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m11 41 49-17m-45 30 49-17\" fill=\"none\" stroke=\"#f4e8c8\" stroke-width=\"6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M7 31 54 13 44 7 5 20Z\" fill=\"#efac92\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"29\" cy=\"14\" rx=\"7\" ry=\"6\" fill=\"#a34342\" stroke=\"#292d30\" stroke-width=\"1\"/><path d=\"M29 9q1-12 12-7\" fill=\"none\" stroke=\"#87988b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M14 35 19 59M57 25l6 18\" fill=\"none\" stroke=\"#f29080\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-toast\" viewBox=\"0 0 74 68\"><path d=\"m7 29 44-16 16 32-46 18Z\" fill=\"#906b49\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m10 24 44-15 11 29-44 18Z\" fill=\"#e5d2ac\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M7 22q-8-10 8-12l26-7q18-6 17 8l7 20-47 17Z\" fill=\"#c39d6b\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M14 23q-6-8 8-9l19-6q12-4 11 6l5 14-33 12Z\" fill=\"#f5e5bd\" stroke=\"#846645\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m26 21 17-5-1 11-12 5Z\" fill=\"#f4d37b\" stroke=\"#ad9864\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-book\" viewBox=\"0 0 64 72\"><path d=\"m8 13 40-7 8 8v44l-41 8-7-7Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m15 21 41-7v39l-41 8Z\" fill=\"#e9e7d8\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m8 13 7 8v40m5-31 29-5m-29 11 29-5m-29 10 29-5\" fill=\"none\" stroke=\"#7c8479\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M8 13v45l7 3\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m13 16 33-6v39l-33 7Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m17 21 25-4v27l-25 4Z\" fill=\"none\" stroke=\"#e5e5bb\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m19 25 7-2m-7 4 3-1m16 12 1 3-4 1\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-openbook\" viewBox=\"0 0 100 70\"><path d=\"M3 13Q24 3 50 17 74 3 97 13v48q-23-9-47 1-25-10-47-1Z\" fill=\"#446b78\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M5 7Q30 1 50 14 72 2 95 7v47q-25-7-45 6-22-13-45-6Z\" fill=\"url(#qa-art-paper)\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M50 14v45M10 49q18-4 35 5M56 54q18-10 34-7M11 14q17-2 30 4M58 18q15-7 30-5\" fill=\"none\" stroke=\"#b1966d\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-envelope\" viewBox=\"0 0 90 60\"><path d=\"M3 8 85 4l2 48-81 5Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m4 9 40 28L85 5M7 53l28-25m48 20L54 29\" fill=\"none\" stroke=\"#7c7460\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><rect x=\"66\" y=\"12\" width=\"14\" height=\"17\" rx=\"1\" fill=\"#f5efdf\" stroke=\"#7c7460\" stroke-width=\"0.8\"/><path d=\"m69 14 8 12m-8 0 8-12\" fill=\"none\" stroke=\"#ad8f63\" stroke-width=\"0.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-alice\" viewBox=\"0 0 90 120\"><path d=\"M20 40C6 29 13 9 26 7 36-5 63 0 69 19q12 15-1 30Z\" fill=\"#c4763b\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m22 40-5 26-10 34q38 24 77-1L69 57 65 40Z\" fill=\"#4d8a9d\" stroke=\"#292d30\" stroke-width=\"1.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m30 45 15 7 14-7 2 21 10 29q-25 10-52 0l10-28Z\" fill=\"#fffdf3\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"45\" cy=\"27\" rx=\"18\" ry=\"21\" fill=\"#f1c2a1\" stroke=\"#292d30\" stroke-width=\"1.3\"/><path d=\"M25 24 31 12q8 4 14-4 7 14 20 13M34 28l5-1m12 0 5 1m-16 12q6 4 11-1\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m35 7-7-7 2 13m24-8 8-4-3 14\" fill=\"url(#qa-art-coral)\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M23 47 18 58 29 69m38-22 5 14-11 8M24 103l-2 11h15l3-9m14 0 2 9h15l-4-12\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M16 84q3-13 9-17m42 20-5-17M25 100l1-12m8 15 1-12m24 11-1-13\" fill=\"none\" stroke=\"#2c5b6b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-cat\" viewBox=\"0 0 150 210\"><path d=\"M41 185C5 197-4 148 18 135c12-8 13 11 2 14-7 22 20 35 33 19\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M47 93q-16 26-20 73-8 32 24 34h59q32-1 17-29l-16-79Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m33 14 8 39q-19 19-5 40 14 23 48 19 35-6 35-34-1-14-11-24l7-39-28 25-29 1Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m42 31 6 23 8-10m44-14-7 19 10 5\" fill=\"none\" stroke=\"#c58e83\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m42 68 22-9 0 13m25-11 18 6-18 7\" fill=\"#e8d88f\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M63 63v8m29-7v7\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m72 78 9-1-4 8m0 0q-9 12-18 1m18-1q7 11 17 1M38 82 7 75m32 15L8 96m105-15 30-5m-31 13 31 10\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m31 108 39-9 48 7-17 21-19-8-29 10Z\" fill=\"url(#qa-art-coral)\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m66 111 10 8-8 8-10-9Z\" fill=\"#a34342\" stroke=\"#292d30\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M48 129q-7 29-1 52m18-48-5 49m33-48 8 46m11-27 7 28M39 190l18-3m37 2 17-1\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M51 138l5 11m-17 7 5 8m24-18-1 14m25-17 3 12m13 4 3 12\" fill=\"none\" stroke=\"#a5b8ad\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><use href=\"#qa-art-crown\" x=\"48\" y=\"0\" width=\"52\" height=\"44\"/></symbol>\n <symbol id=\"qa-art-rabbit\" viewBox=\"0 0 140 180\"><path d=\"M56 63C18 6 36-17 52 10l21 48m5 1C79 9 105-12 107 9l-8 54\" fill=\"url(#qa-art-ivory)\" stroke=\"#292d30\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m47 12 12 39M98 9 86 52\" fill=\"none\" stroke=\"#df9583\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M30 100Q6 124 16 170h115q9-45-24-68Z\" fill=\"#a7c1c6\" stroke=\"#292d30\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m52 100 19 10 17-11 9 68H44Z\" fill=\"#c6a663\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"71\" cy=\"80\" rx=\"44\" ry=\"34\" fill=\"url(#qa-art-ivory)\" stroke=\"#292d30\" stroke-width=\"1.8\"/><path d=\"m39 68 9-2m34-1 12 3M58 86l12-6 9 7-10 6Z\" fill=\"#bb6c5b\" stroke=\"#292d30\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m44 83-35-6m34 13L6 94m87-10 40-7m-39 16 38 5M65 99l12-1\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><use href=\"#qa-art-clock\" x=\"99\" y=\"104\" width=\"30\" height=\"34\"/><path d=\"M28 119 42 160m66-40-5 43M65 113l10 11-15 10\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n <symbol id=\"qa-art-humpty\" viewBox=\"0 0 150 160\"><path d=\"M34 95 17 126l28 8 21-27m34-9 30 34-27 9-21-34\" fill=\"#96775a\" stroke=\"#292d30\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M26 66Q43 2 74 4q31 1 50 62 4 57-49 60T26 66Z\" fill=\"url(#qa-art-paper)\" stroke=\"#292d30\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M26 73 50 90l23 26 26-25 24-20 10 44-21 20H39l-22-19Z\" fill=\"#6e9eae\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m49 90 25 26 26-26-2 42H51Z\" fill=\"url(#qa-art-coral)\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m44 62q10-8 19 0m22-2q11-6 20 2M53 66v3m41-5v3m-19 3 7 8-15 3m-15 9q24 15 45-2\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m41 89 16 14 17-4 14 6 16-15\" fill=\"none\" stroke=\"#d4ae43\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"75\" cy=\"118\" rx=\"2\" ry=\"2\" fill=\"#292d30\" stroke=\"#292d30\" stroke-width=\"1.4\"/></symbol>\n <symbol id=\"qa-art-piece-pawn\" viewBox=\"0 0 70 90\"><g fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linejoin=\"round\"><path d=\"M12 80h46l4 6H8ZM18 71h34l6 8H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"35\" cy=\"24\" rx=\"12\" ry=\"12\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\"/><path d=\"M26 36h18l7 35H19Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M20 75h30M24 82h27\" fill=\"none\" stroke=\"#ffefce\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"qa-art-piece-knight\" viewBox=\"0 0 70 90\"><g fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linejoin=\"round\"><path d=\"M12 80h46l4 6H8ZM18 71h34l6 8H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M18 72 25 44l-13-6 7-16 15-9 2-9 13 15q17 19 1 53Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m25 31 5-1m9-9 9 12-3 26\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M20 75h30M24 82h27\" fill=\"none\" stroke=\"#ffefce\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"qa-art-piece-bishop\" viewBox=\"0 0 70 90\"><g fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linejoin=\"round\"><path d=\"M12 80h46l4 6H8ZM18 71h34l6 8H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M35 4C10 25 17 39 29 42L20 71h30l-9-29C55 35 52 19 35 4Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m39 17-11 15\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M20 75h30M24 82h27\" fill=\"none\" stroke=\"#ffefce\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"qa-art-piece-rook\" viewBox=\"0 0 70 90\"><g fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linejoin=\"round\"><path d=\"M12 80h46l4 6H8ZM18 71h34l6 8H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 12h12v11h7V12h9v11h8V12h11v24l-13 8 3 27H21l3-27-12-8Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M20 75h30M24 82h27\" fill=\"none\" stroke=\"#ffefce\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"qa-art-piece-queen\" viewBox=\"0 0 70 90\"><g fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linejoin=\"round\"><path d=\"M12 80h46l4 6H8ZM18 71h34l6 8H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m13 22 13 13 10-19 10 19 13-13-9 48H22Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"14\" cy=\"18\" rx=\"4\" ry=\"4\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\"/><ellipse cx=\"36\" cy=\"11\" rx=\"4\" ry=\"4\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\"/><ellipse cx=\"58\" cy=\"18\" rx=\"4\" ry=\"4\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\"/><path d=\"M20 75h30M24 82h27\" fill=\"none\" stroke=\"#ffefce\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"qa-art-piece-king\" viewBox=\"0 0 70 90\"><g fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linejoin=\"round\"><path d=\"M12 80h46l4 6H8ZM18 71h34l6 8H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M31 5h9v10h10v8H40v12h-9V23H21v-8h10ZM18 39q17-14 34 0l-8 31H26Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M20 75h30M24 82h27\" fill=\"none\" stroke=\"#ffefce\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol>\n <symbol id=\"qa-art-courtier\" viewBox=\"0 0 120 170\"><g stroke=\"#292d30\" stroke-linejoin=\"round\"><path d=\"M35 93Q10 114 19 165h88q10-45-28-71Z\" fill=\"currentColor\" stroke-width=\"1.9\"/><path d=\"m42 92 16 9 21-10-4 28-16 14-18-12Z\" fill=\"#f8edd7\" stroke-width=\"1.2\"/><path d=\"m30 113 13 37 13-4m30-34-7 41-18-5\" fill=\"none\" stroke-width=\"1.4\"/><path d=\"M36 61q-5 36 23 36 31-1 32-34Z\" fill=\"#e6b28e\" stroke-width=\"1.5\"/><path d=\"m41 58 2 14-12 7 16 2m9-8q10-8 20-2m-24 6h2m19-1h2m-18 9q11 5 19-2\" fill=\"none\" stroke-width=\"1.4\"/><path d=\"M26 52 39 29l-5-9 17-8 5-9 19 11q28 16 14 45L53 67Z\" fill=\"currentColor\" stroke-width=\"1.8\"/><path d=\"m37 31 31-5 18 14-21 7-38 5m17-25 3-7 12-4 17 7m-8 9 10 2\" fill=\"none\" stroke-width=\"1.2\"/><path d=\"M54 22q9-6 15-1l-5 10-11-2Z\" fill=\"#d5d6ba\" stroke-width=\"1.1\"/><path d=\"m28 126 11 5 16-5 7 11-17 12-13-6m53-15-9 5-14-4-9 10 14 10 14-5\" fill=\"#e6b28e\" stroke-width=\"1.5\"/><path d=\"m30 157 5-9m63 12-5-13m-23-2 4 19m-28-17-3 17\" fill=\"none\" stroke-width=\"1\"/><path d=\"M21 159h84v6H19Z\" fill=\"url(#qa-art-hatch)\" stroke=\"none\"/></g></symbol>\n <symbol id=\"qa-art-actor-pawn\" viewBox=\"0 0 70 100\"><g stroke=\"#292d30\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 57Q8 68 11 91h49q5-23-16-34Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M17 62q18 5 37 0l-8 13-12-3-12 4Z\" fill=\"#f1e5ce\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M21 39q-5 21 14 23 19 0 18-24Z\" fill=\"#ebbb98\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m23 43 8-1m8-1 8 1m-21 3 1 1m15-2v1m-7 2 3 5-7 1m-3 5q8 4 15-2\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M16 26Q19 3 37 5 56 7 57 28l9 4-31 10-28-8Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m18 27 35 3 9-4M35 9q-9 6-9 15\" fill=\"none\" stroke=\"#ffdfc2\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m17 73 12 6 12-4 7 6-12 9-14-3m32-14-5 9M15 92h44v5H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M28 80h14M25 92l2-5m23 4-3-4\" fill=\"none\" stroke=\"#f6dab4\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"qa-art-actor-knight\" viewBox=\"0 0 70 100\"><g stroke=\"#292d30\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 57Q8 68 11 91h49q5-23-16-34Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M17 62q18 5 37 0l-8 13-12-3-12 4Z\" fill=\"#f1e5ce\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M21 39q-5 21 14 23 19 0 18-24Z\" fill=\"#ebbb98\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m23 43 8-1m8-1 8 1m-21 3 1 1m15-2v1m-7 2 3 5-7 1m-3 5q8 4 15-2\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M16 38 19 18l9-7 1-10 13 9 17 6 6 15-18 3-10-10-4 13Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m38 16 3-1m14 8 5 1M22 20l7-4v15\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m17 73 12 6 12-4 7 6-12 9-14-3m32-14-5 9M15 92h44v5H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M28 80h14M25 92l2-5m23 4-3-4\" fill=\"none\" stroke=\"#f6dab4\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"qa-art-actor-bishop\" viewBox=\"0 0 70 100\"><g stroke=\"#292d30\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 57Q8 68 11 91h49q5-23-16-34Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M17 62q18 5 37 0l-8 13-12-3-12 4Z\" fill=\"#f1e5ce\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M21 39q-5 21 14 23 19 0 18-24Z\" fill=\"#ebbb98\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m23 43 8-1m8-1 8 1m-21 3 1 1m15-2v1m-7 2 3 5-7 1m-3 5q8 4 15-2\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M14 35C13 22 28 8 35 2 42 9 56 22 56 35L36 41Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M35 6v29M25 24h20\" fill=\"none\" stroke=\"#eeddb0\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M16 35q19-9 39 0\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m17 73 12 6 12-4 7 6-12 9-14-3m32-14-5 9M15 92h44v5H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M28 80h14M25 92l2-5m23 4-3-4\" fill=\"none\" stroke=\"#f6dab4\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"qa-art-actor-rook\" viewBox=\"0 0 70 100\"><g stroke=\"#292d30\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 57Q8 68 11 91h49q5-23-16-34Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M17 62q18 5 37 0l-8 13-12-3-12 4Z\" fill=\"#f1e5ce\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M21 39q-5 21 14 23 19 0 18-24Z\" fill=\"#ebbb98\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m23 43 8-1m8-1 8 1m-21 3 1 1m15-2v1m-7 2 3 5-7 1m-3 5q8 4 15-2\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M14 9h9v8h8V9h10v8h9V9h9v18l-6 4v12H20V31l-6-4Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M20 27h32M27 29v12m16-12v10M23 21h7m10 0h10\" fill=\"none\" stroke=\"#efe3c8\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m17 73 12 6 12-4 7 6-12 9-14-3m32-14-5 9M15 92h44v5H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M28 80h14M25 92l2-5m23 4-3-4\" fill=\"none\" stroke=\"#f6dab4\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"qa-art-actor-queen\" viewBox=\"0 0 70 100\"><g stroke=\"#292d30\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 57Q8 68 11 91h49q5-23-16-34Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M17 62q18 5 37 0l-8 13-12-3-12 4Z\" fill=\"#f1e5ce\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M21 39q-5 21 14 23 19 0 18-24Z\" fill=\"#ebbb98\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m23 43 8-1m8-1 8 1m-21 3 1 1m15-2v1m-7 2 3 5-7 1m-3 5q8 4 15-2\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><use href=\"#qa-art-crown\" x=\"10\" y=\"1\" width=\"51\" height=\"43\"/><path d=\"m17 73 12 6 12-4 7 6-12 9-14-3m32-14-5 9M15 92h44v5H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M28 80h14M25 92l2-5m23 4-3-4\" fill=\"none\" stroke=\"#f6dab4\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"qa-art-actor-king\" viewBox=\"0 0 70 100\"><g stroke=\"#292d30\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 57Q8 68 11 91h49q5-23-16-34Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M17 62q18 5 37 0l-8 13-12-3-12 4Z\" fill=\"#f1e5ce\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M21 39q-5 21 14 23 19 0 18-24Z\" fill=\"#ebbb98\" stroke=\"#292d30\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"m23 43 8-1m8-1 8 1m-21 3 1 1m15-2v1m-7 2 3 5-7 1m-3 5q8 4 15-2\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M17 20q18-10 36 0l2 18H16Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><use href=\"#qa-art-crown\" x=\"10\" y=\"-1\" width=\"51\" height=\"40\"/><path d=\"m17 73 12 6 12-4 7 6-12 9-14-3m32-14-5 9M15 92h44v5H12Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M28 80h14M25 92l2-5m23 4-3-4\" fill=\"none\" stroke=\"#f6dab4\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol>\n <symbol id=\"qa-art-talkingflower\" viewBox=\"0 0 140 170\"><path d=\"M61 168Q87 130 66 72\" fill=\"none\" stroke=\"#536d53\" stroke-width=\"7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><use href=\"#qa-art-leaf\" x=\"64\" y=\"105\" width=\"63\" height=\"32\"/><use href=\"#qa-art-leaf\" x=\"18\" y=\"130\" width=\"60\" height=\"30\"/><path d=\"M69 73C24 74 11 48 34 37 31 10 62 8 72 42 91 8 119 18 110 42 137 54 117 84 80 81Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" transform=\"rotate(0 71 69)\"/><path d=\"M69 73C24 74 11 48 34 37 31 10 62 8 72 42 91 8 119 18 110 42 137 54 117 84 80 81Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" transform=\"rotate(51.4 71 69)\"/><path d=\"M69 73C24 74 11 48 34 37 31 10 62 8 72 42 91 8 119 18 110 42 137 54 117 84 80 81Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" transform=\"rotate(102.8 71 69)\"/><path d=\"M69 73C24 74 11 48 34 37 31 10 62 8 72 42 91 8 119 18 110 42 137 54 117 84 80 81Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" transform=\"rotate(154.2 71 69)\"/><path d=\"M69 73C24 74 11 48 34 37 31 10 62 8 72 42 91 8 119 18 110 42 137 54 117 84 80 81Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" transform=\"rotate(205.6 71 69)\"/><path d=\"M69 73C24 74 11 48 34 37 31 10 62 8 72 42 91 8 119 18 110 42 137 54 117 84 80 81Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" transform=\"rotate(257 71 69)\"/><path d=\"M69 73C24 74 11 48 34 37 31 10 62 8 72 42 91 8 119 18 110 42 137 54 117 84 80 81Z\" fill=\"currentColor\" stroke=\"#292d30\" stroke-width=\"1.4\" transform=\"rotate(308.4 71 69)\"/><ellipse cx=\"71\" cy=\"69\" rx=\"24\" ry=\"29\" fill=\"#f3cfad\" stroke=\"#292d30\" stroke-width=\"1.4\"/><path d=\"M49 58q8-8 14-2m15-1q8-8 14 0m-36 6 3 1m24-2 3-1M70 61l-4 13 9 0M60 81q10 8 21-2\" fill=\"none\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M51 85q10 13 24 15m-41-53 9-14 15-2m31 5 16 14m-6 31-7 9M24 66l9 13m75-18 6 8\" fill=\"none\" stroke=\"#ffe0a8\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></symbol>\n<symbol id=\"qa-art-chess-wide\" viewBox=\"0 0 738 706\"><path d=\"M4 12 29 4 295.2 8 494.46000000000004 3 729 9 735 232.98000000000002 732 697 509.21999999999997 703 258.3 699 8 702 3 444.78000000000003Z\" fill=\"url(#qa-art-paper)\" stroke=\"#acaa9d\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 16Q369 3 723 17M12 692q369 9 714 0\" fill=\"none\" stroke=\"#d5ccbb\" stroke-width=\"0.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g class=\"qa-scenery\"><path d=\"M20 30Q147.6 4 369 65 590.4 4 718 30L710 338.88Q605.16 282.40000000000003 553.5 564.8000000000001L369 686 154.98 564.8000000000001Q147.6 331.82 20 353Z\" fill=\"#dce4d6\" stroke=\"none\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g class=\"qa-decoration\" transform=\"translate(50 30) scale(1.7 1.7)\"><path d=\"M0 0 25 2Q33 60 59 100l-2 20-19-4Q17 82 8 48L-5 19Z\" fill=\"#8a9678\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M8 5Q15 60 48 104l-5 7M20 8q12 47 35 86M3 36l-14 22-11-5 16-28M35 74l33-18 10 5-32 22\" fill=\"#b8bc98\" stroke=\"#5f705b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M6 12 14 43 12 47 22 63 26 78 42 97M28 27l9 15m2 44 6 8\" fill=\"none\" stroke=\"#e5dbad\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(0 16) rotate(-18)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(16 41) rotate(27)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(36 77) rotate(40)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(-18 39) rotate(-41)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(58 53) rotate(-15)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g></g><g class=\"qa-decoration\" transform=\"translate(688 30) scale(-1.7 1.7)\"><path d=\"M0 0 25 2Q33 60 59 100l-2 20-19-4Q17 82 8 48L-5 19Z\" fill=\"#8a9678\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M8 5Q15 60 48 104l-5 7M20 8q12 47 35 86M3 36l-14 22-11-5 16-28M35 74l33-18 10 5-32 22\" fill=\"#b8bc98\" stroke=\"#5f705b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M6 12 14 43 12 47 22 63 26 78 42 97M28 27l9 15m2 44 6 8\" fill=\"none\" stroke=\"#e5dbad\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(0 16) rotate(-18)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(16 41) rotate(27)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(36 77) rotate(40)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(-18 39) rotate(-41)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(58 53) rotate(-15)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g></g><g class=\"qa-decoration\" transform=\"translate(34 338.88) scale(2 2)\"><path d=\"M0 0 25 2Q33 60 59 100l-2 20-19-4Q17 82 8 48L-5 19Z\" fill=\"#8a9678\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M8 5Q15 60 48 104l-5 7M20 8q12 47 35 86M3 36l-14 22-11-5 16-28M35 74l33-18 10 5-32 22\" fill=\"#b8bc98\" stroke=\"#5f705b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M6 12 14 43 12 47 22 63 26 78 42 97M28 27l9 15m2 44 6 8\" fill=\"none\" stroke=\"#e5dbad\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(0 16) rotate(-18)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(16 41) rotate(27)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(36 77) rotate(40)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(-18 39) rotate(-41)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(58 53) rotate(-15)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g></g><g class=\"qa-decoration\" transform=\"translate(704 338.88) scale(-2 2)\"><path d=\"M0 0 25 2Q33 60 59 100l-2 20-19-4Q17 82 8 48L-5 19Z\" fill=\"#8a9678\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M8 5Q15 60 48 104l-5 7M20 8q12 47 35 86M3 36l-14 22-11-5 16-28M35 74l33-18 10 5-32 22\" fill=\"#b8bc98\" stroke=\"#5f705b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M6 12 14 43 12 47 22 63 26 78 42 97M28 27l9 15m2 44 6 8\" fill=\"none\" stroke=\"#e5dbad\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(0 16) rotate(-18)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(16 41) rotate(27)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(36 77) rotate(40)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(-18 39) rotate(-41)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(58 53) rotate(-15)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g></g><path d=\"M36.9 25Q169.74 15 317.34 52L295.2 100Q169.74 63 73.8 142Z\" fill=\"#7f9d94\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M701.1 25Q568.26 15 420.65999999999997 52L442.8 100Q568.26 63 664.2 142Z\" fill=\"#7f9d94\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M81.18 33Q162.36 83 280.44 59M656.82 33Q575.64 83 457.56 59M103.32000000000001 39Q199.26000000000002 79 273.06 72M634.68 39Q538.74 79 464.94 72\" fill=\"none\" stroke=\"#486960\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g class=\"qa-decoration\" transform=\"translate(18 74) scale(0.62 0.62)\"><path d=\"M0 0C48 15 8 66 48 102 81 134 56 172 95 194\" fill=\"none\" stroke=\"#87988b\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(1 10) rotate(0)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(24 45) rotate(14)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(28 90) rotate(-17)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(50 139) rotate(16)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(67 174) rotate(-20)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><use href=\"#qa-art-rose\" x=\"12\" y=\"45\" width=\"47\" height=\"47\"/><use href=\"#qa-art-rose\" x=\"52\" y=\"131\" width=\"40\" height=\"40\"/></g><g class=\"qa-decoration\" transform=\"translate(720 74) scale(-0.62 0.62)\"><path d=\"M0 0C48 15 8 66 48 102 81 134 56 172 95 194\" fill=\"none\" stroke=\"#87988b\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(1 10) rotate(0)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(24 45) rotate(14)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(28 90) rotate(-17)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(50 139) rotate(16)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(67 174) rotate(-20)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><use href=\"#qa-art-rose\" x=\"12\" y=\"45\" width=\"47\" height=\"47\"/><use href=\"#qa-art-rose\" x=\"52\" y=\"131\" width=\"40\" height=\"40\"/></g><g class=\"qa-decoration\" transform=\"translate(20 554) scale(0.62 0.62)\"><path d=\"M0 0C48 15 8 66 48 102 81 134 56 172 95 194\" fill=\"none\" stroke=\"#87988b\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(1 10) rotate(0)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(24 45) rotate(14)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(28 90) rotate(-17)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(50 139) rotate(16)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(67 174) rotate(-20)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><use href=\"#qa-art-rose\" x=\"12\" y=\"45\" width=\"47\" height=\"47\"/><use href=\"#qa-art-rose\" x=\"52\" y=\"131\" width=\"40\" height=\"40\"/></g><g class=\"qa-decoration\" transform=\"translate(718 554) scale(-0.62 0.62)\"><path d=\"M0 0C48 15 8 66 48 102 81 134 56 172 95 194\" fill=\"none\" stroke=\"#87988b\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(1 10) rotate(0)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(24 45) rotate(14)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(28 90) rotate(-17)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(50 139) rotate(16)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(67 174) rotate(-20)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><use href=\"#qa-art-rose\" x=\"12\" y=\"45\" width=\"47\" height=\"47\"/><use href=\"#qa-art-rose\" x=\"52\" y=\"131\" width=\"40\" height=\"40\"/></g><path d=\"M296.5 23Q369 45 441.5 23l-10 101h-125Z\" fill=\"url(#qa-art-coral)\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M308.5 30  321.5 113m21.9-83 0 83m31.9 -83 -13 83\" fill=\"none\" stroke=\"#954b43\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><use href=\"#qa-art-crown\" x=\"328\" y=\"80\" width=\"82\" height=\"70\"/><g transform=\"translate(236.16 146)\"><path d=\"M0 0q47.8224-13 100.9584 0t95.6448 0q37.19520000000001-13 69.0768 0M106.272 0q10-13 20 0t20 0M0 0q-9-14-16-3t13 9m268.68-6q9-14 16-3t-13 9\" fill=\"none\" stroke=\"#b3a692\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g></symbol><symbol id=\"qa-art-chess-phone\" viewBox=\"0 0 359 469\"><path d=\"M4 12 29 4 143.6 8 240.53 3 350 9 356 154.77 353 460 247.70999999999998 466 125.64999999999999 462 8 465 3 295.47Z\" fill=\"url(#qa-art-paper)\" stroke=\"#acaa9d\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 16Q179.5 3 344 17M12 455q179.5 9 335 0\" fill=\"none\" stroke=\"#d5ccbb\" stroke-width=\"0.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g class=\"qa-scenery\"><path d=\"M20 30Q71.8 4 179.5 65 287.2 4 339 30L331 225.12Q294.38 187.60000000000002 269.25 375.20000000000005L179.5 449 75.39 375.20000000000005Q71.8 220.42999999999998 20 234.5Z\" fill=\"#dce4d6\" stroke=\"none\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g class=\"qa-decoration\" transform=\"translate(22 30) scale(0.72 0.72)\"><path d=\"M0 0 25 2Q33 60 59 100l-2 20-19-4Q17 82 8 48L-5 19Z\" fill=\"#8a9678\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M8 5Q15 60 48 104l-5 7M20 8q12 47 35 86M3 36l-14 22-11-5 16-28M35 74l33-18 10 5-32 22\" fill=\"#b8bc98\" stroke=\"#5f705b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M6 12 14 43 12 47 22 63 26 78 42 97M28 27l9 15m2 44 6 8\" fill=\"none\" stroke=\"#e5dbad\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(0 16) rotate(-18)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(16 41) rotate(27)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(36 77) rotate(40)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(-18 39) rotate(-41)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(58 53) rotate(-15)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g></g><g class=\"qa-decoration\" transform=\"translate(337 30) scale(-0.72 0.72)\"><path d=\"M0 0 25 2Q33 60 59 100l-2 20-19-4Q17 82 8 48L-5 19Z\" fill=\"#8a9678\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M8 5Q15 60 48 104l-5 7M20 8q12 47 35 86M3 36l-14 22-11-5 16-28M35 74l33-18 10 5-32 22\" fill=\"#b8bc98\" stroke=\"#5f705b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M6 12 14 43 12 47 22 63 26 78 42 97M28 27l9 15m2 44 6 8\" fill=\"none\" stroke=\"#e5dbad\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(0 16) rotate(-18)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(16 41) rotate(27)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(36 77) rotate(40)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(-18 39) rotate(-41)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(58 53) rotate(-15)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g></g><g class=\"qa-decoration\" transform=\"translate(11 225.12) scale(0.85 0.85)\"><path d=\"M0 0 25 2Q33 60 59 100l-2 20-19-4Q17 82 8 48L-5 19Z\" fill=\"#8a9678\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M8 5Q15 60 48 104l-5 7M20 8q12 47 35 86M3 36l-14 22-11-5 16-28M35 74l33-18 10 5-32 22\" fill=\"#b8bc98\" stroke=\"#5f705b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M6 12 14 43 12 47 22 63 26 78 42 97M28 27l9 15m2 44 6 8\" fill=\"none\" stroke=\"#e5dbad\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(0 16) rotate(-18)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(16 41) rotate(27)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(36 77) rotate(40)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(-18 39) rotate(-41)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(58 53) rotate(-15)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g></g><g class=\"qa-decoration\" transform=\"translate(348 225.12) scale(-0.85 0.85)\"><path d=\"M0 0 25 2Q33 60 59 100l-2 20-19-4Q17 82 8 48L-5 19Z\" fill=\"#8a9678\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M8 5Q15 60 48 104l-5 7M20 8q12 47 35 86M3 36l-14 22-11-5 16-28M35 74l33-18 10 5-32 22\" fill=\"#b8bc98\" stroke=\"#5f705b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M6 12 14 43 12 47 22 63 26 78 42 97M28 27l9 15m2 44 6 8\" fill=\"none\" stroke=\"#e5dbad\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(0 16) rotate(-18)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(16 41) rotate(27)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(36 77) rotate(40)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(-18 39) rotate(-41)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(58 53) rotate(-15)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g></g><path d=\"M17.95 25Q82.57000000000001 15 154.37 52L143.6 100Q82.57000000000001 63 35.9 142Z\" fill=\"#7f9d94\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M341.05 25Q276.43 15 204.63 52L215.4 100Q276.43 63 323.1 142Z\" fill=\"#7f9d94\" stroke=\"#292d30\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M39.49 33Q78.98 83 136.42 59M319.51 33Q280.02 83 222.58 59M50.260000000000005 39Q96.93 79 132.83 72M308.74 39Q262.07 79 226.17 72\" fill=\"none\" stroke=\"#486960\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g class=\"qa-decoration\" transform=\"translate(18 28) scale(0.31 0.31)\"><path d=\"M0 0C48 15 8 66 48 102 81 134 56 172 95 194\" fill=\"none\" stroke=\"#87988b\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(1 10) rotate(0)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(24 45) rotate(14)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(28 90) rotate(-17)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(50 139) rotate(16)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(67 174) rotate(-20)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><use href=\"#qa-art-rose\" x=\"12\" y=\"45\" width=\"47\" height=\"47\"/><use href=\"#qa-art-rose\" x=\"52\" y=\"131\" width=\"40\" height=\"40\"/></g><g class=\"qa-decoration\" transform=\"translate(341 28) scale(-0.31 0.31)\"><path d=\"M0 0C48 15 8 66 48 102 81 134 56 172 95 194\" fill=\"none\" stroke=\"#87988b\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(1 10) rotate(0)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(24 45) rotate(14)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(28 90) rotate(-17)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(50 139) rotate(16)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(67 174) rotate(-20)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><use href=\"#qa-art-rose\" x=\"12\" y=\"45\" width=\"47\" height=\"47\"/><use href=\"#qa-art-rose\" x=\"52\" y=\"131\" width=\"40\" height=\"40\"/></g><g class=\"qa-decoration\" transform=\"translate(20 317) scale(0.31 0.31)\"><path d=\"M0 0C48 15 8 66 48 102 81 134 56 172 95 194\" fill=\"none\" stroke=\"#87988b\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(1 10) rotate(0)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(24 45) rotate(14)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(28 90) rotate(-17)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(50 139) rotate(16)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(67 174) rotate(-20)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><use href=\"#qa-art-rose\" x=\"12\" y=\"45\" width=\"47\" height=\"47\"/><use href=\"#qa-art-rose\" x=\"52\" y=\"131\" width=\"40\" height=\"40\"/></g><g class=\"qa-decoration\" transform=\"translate(339 317) scale(-0.31 0.31)\"><path d=\"M0 0C48 15 8 66 48 102 81 134 56 172 95 194\" fill=\"none\" stroke=\"#87988b\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(1 10) rotate(0)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(24 45) rotate(14)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(28 90) rotate(-17)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(50 139) rotate(16)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(67 174) rotate(-20)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><use href=\"#qa-art-rose\" x=\"12\" y=\"45\" width=\"47\" height=\"47\"/><use href=\"#qa-art-rose\" x=\"52\" y=\"131\" width=\"40\" height=\"40\"/></g><path d=\"M137 23Q179.5 45 222 23l-10 67h-65Z\" fill=\"url(#qa-art-coral)\" stroke=\"#292d30\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M149 30  162 83m8.7-57 0 57m18.7 -57 -13 57\" fill=\"none\" stroke=\"#954b43\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><use href=\"#qa-art-crown\" x=\"156.5\" y=\"53\" width=\"46\" height=\"39\"/><g transform=\"translate(114.88 99)\"><path d=\"M0 0q23.2632-13 49.111200000000004 0t46.5264 0q18.093600000000002-13 33.6024 0M51.696000000000005 0q10-13 20 0t20 0M0 0q-9-14-16-3t13 9m132.24-6q9-14 16-3t-13 9\" fill=\"none\" stroke=\"#b3a692\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g></symbol><symbol id=\"qa-art-bough\" viewBox=\"-30 0 130 130\"><g class=\"qa-decoration\" transform=\"translate(0 0) scale(1 1)\"><path d=\"M0 0 25 2Q33 60 59 100l-2 20-19-4Q17 82 8 48L-5 19Z\" fill=\"#8a9678\" stroke=\"#292d30\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M8 5Q15 60 48 104l-5 7M20 8q12 47 35 86M3 36l-14 22-11-5 16-28M35 74l33-18 10 5-32 22\" fill=\"#b8bc98\" stroke=\"#5f705b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M6 12 14 43 12 47 22 63 26 78 42 97M28 27l9 15m2 44 6 8\" fill=\"none\" stroke=\"#e5dbad\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(0 16) rotate(-18)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(16 41) rotate(27)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(36 77) rotate(40)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(-18 39) rotate(-41)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g><g transform=\"translate(58 53) rotate(-15)\"><use href=\"#qa-art-leaf\" x=\"-9\" y=\"-8\" width=\"39\" height=\"20\"/></g></g></symbol><symbol id=\"qa-art-sprig\" viewBox=\"-20 0 160 210\"><g class=\"qa-decoration\" transform=\"translate(0 0) scale(1 1)\"><path d=\"M0 0C48 15 8 66 48 102 81 134 56 172 95 194\" fill=\"none\" stroke=\"#87988b\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(1 10) rotate(0)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(24 45) rotate(14)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(28 90) rotate(-17)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(50 139) rotate(16)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><g transform=\"translate(67 174) rotate(-20)\"><use href=\"#qa-art-leaf\" x=\"-5\" y=\"-7\" width=\"57\" height=\"28\"/></g><use href=\"#qa-art-rose\" x=\"12\" y=\"45\" width=\"47\" height=\"47\"/><use href=\"#qa-art-rose\" x=\"52\" y=\"131\" width=\"40\" height=\"40\"/></g></symbol></defs></svg>", Lt = {
	tea: "cup",
	cake: "cake",
	toast: "toast",
	time: "clock",
	crown: "crown",
	book: "book",
	cat: "cat",
	alice: "alice",
	rose: "rose",
	leaf: "leaf",
	egg: "humpty",
	invite: "envelope",
	paw: "paw",
	rabbit: "rabbit",
	flower: "flower",
	talkingflower: "talkingflower",
	openbook: "openbook",
	bough: "bough",
	sprig: "sprig"
};
function Rt() {
	return /* @__PURE__ */ f("svg", {
		className: "qa-art-definitions",
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: It.slice(It.indexOf("<defs>"), It.lastIndexOf("</defs>") + 7) }
	});
}
function zt() {
	return /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("svg", {
		className: "qa-chess-scenery qa-scenery-wide",
		viewBox: "0 0 738 706",
		"aria-hidden": "true",
		children: /* @__PURE__ */ f("use", {
			href: "#qa-art-chess-wide",
			width: "738",
			height: "706"
		})
	}), /* @__PURE__ */ f("svg", {
		className: "qa-chess-scenery qa-scenery-phone",
		viewBox: "0 0 359 469",
		"aria-hidden": "true",
		children: /* @__PURE__ */ f("use", {
			href: "#qa-art-chess-phone",
			width: "359",
			height: "469"
		})
	})] });
}
function X({ shape: e = "box" }) {
	let t = e === "flower" ? "M50 96C4 72 0 45 22 22 37 0 61 0 78 22 100 45 96 72 50 96Z" : "M3 3H97V97H3Z";
	return /* @__PURE__ */ p("svg", {
		className: "qa-ant-outline",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ f("path", {
			d: t,
			className: "qa-ant-base",
			vectorEffect: "non-scaling-stroke"
		}), /* @__PURE__ */ f("path", {
			d: t,
			className: "qa-ant-line",
			vectorEffect: "non-scaling-stroke"
		})]
	});
}
function Z({ name: e, className: t = "" }) {
	let n = e.startsWith("actor-") ? e : Lt[e];
	if (n) return /* @__PURE__ */ f("svg", {
		viewBox: e.startsWith("actor-") ? "0 0 70 100" : "0 0 64 64",
		"aria-hidden": "true",
		className: `qa-art ${t}`,
		children: /* @__PURE__ */ f("use", {
			href: `#qa-art-${n}`,
			width: "100%",
			height: "100%"
		})
	});
	if ([
		"pink",
		"blue",
		"orange",
		"yellow"
	].includes(e)) return /* @__PURE__ */ f("svg", {
		viewBox: "0 0 64 64",
		"aria-hidden": "true",
		className: `qa-art qa-flower-art qa-flower-art-${e} ${t}`,
		children: /* @__PURE__ */ f("use", {
			href: "#qa-art-flower",
			width: "64",
			height: "64"
		})
	});
	let r;
	switch (e) {
		case "black":
			r = /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("path", {
					d: "m12 19 24-9 17 10-25 10Z",
					fill: "#657064"
				}),
				/* @__PURE__ */ f("path", {
					d: "M12 19v27l16 11V30Z",
					fill: "#344e44"
				}),
				/* @__PURE__ */ f("path", {
					d: "m28 30 25-10v26l-25 11Z",
					fill: "#4b5e4c"
				})
			] });
			break;
		default: r = /* @__PURE__ */ f("text", {
			x: "32",
			y: "46",
			textAnchor: "middle",
			stroke: "none",
			fill: "currentColor",
			fontSize: "45",
			children: {
				ip: "✦",
				heart: "♥",
				spade: "♠",
				club: "♣",
				diamond: "♦",
				red: "◆",
				white: "◇",
				resource: "◈",
				any: "◈",
				acquire: "▤",
				mini: "↪",
				capture: "⚔",
				extraDiscard: "↗",
				cardReward: "▤",
				flower: "❀"
			}[e] ?? "✦"
		});
	}
	return /* @__PURE__ */ f("svg", {
		viewBox: "0 0 64 64",
		"aria-hidden": "true",
		className: `qa-art ${t}`,
		fill: "none",
		stroke: "#62513a",
		strokeWidth: "1.7",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: r
	});
}
//#endregion
//#region src/games/queenalice/ui.tsx
function Bt({ type: e, color: t }) {
	return /* @__PURE__ */ f(Z, {
		name: `actor-${e}`,
		className: `qa-piece qa-${t}`
	});
}
function Vt({ choice: e }) {
	let t = R(e.color);
	return /* @__PURE__ */ f("span", {
		className: "qa-route-path",
		children: e.id.slice(10).split("-").map((e) => {
			let n = t[Number(e)];
			return `${n.step}${n.branch < 0 ? "‹" : n.branch > 0 ? "›" : ""}`;
		}).join(" → ")
	});
}
function Ht(e, t) {
	let n = e.type === "resource" ? t(Y(e.resource && e.resource !== "any" ? e.resource : "anyResource")) : e.type === "flower" ? t(Y(e.flower)) : e.type === "book" ? t(Y(`book-${e.book ?? "any"}`)) : t(Y(e.type)), r = e.color ? `${t(Y(e.color))} · ` : "";
	return e.type === "acquire" ? t(Y("rewardAcquire"), {
		n: e.n,
		tier: t(Y(`tier${e.tier ?? 1}`))
	}) : e.type === "invite" ? t(Y("rewardInvite"), { n: e.n }) : e.type === "black" ? t(Y("rewardBlack"), {
		n: e.n,
		resource: `${t(Y(e.resource && e.resource !== "any" ? e.resource : "anyResource"))} ×${e.n}`
	}) : e.type === "mini" ? t(Y("rewardMini"), {
		n: e.n,
		suit: e.suit ? t(Y(e.suit)) : ""
	}) : e.type === "extraDiscard" ? t(Y("rewardExtra"), { tier: t(Y(`tier${e.n}`)) }) : e.type === "capture" ? t(Y(e.n === 1 ? "rewardCapturePawn" : "rewardCapturePiece")) : e.type === "cardReward" ? t(Y("rewardCard"), { tier: t(Y(`tier${e.tier ?? 1}`)) }) : `${r}${n} ×${e.n}`;
}
function Q({ rewards: e, text: t = !1 }) {
	let n = u();
	return /* @__PURE__ */ f("span", {
		className: `qa-effects ${t ? "qa-effects-text" : ""}`,
		children: e.map((e, r) => /* @__PURE__ */ p("span", {
			title: Ht(e, n),
			className: e.color ? `qa-${e.color}` : "",
			children: [/* @__PURE__ */ f(Z, { name: e.flower ?? (e.type === "resource" ? e.resource ?? "any" : e.type === "cat" ? "paw" : e.type) }), t ? /* @__PURE__ */ f("span", { children: Ht(e, n) }) : /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("b", { children: e.n }),
				e.type !== "resource" && e.resource && /* @__PURE__ */ f(Z, { name: e.resource }),
				e.suit && /* @__PURE__ */ f(Z, { name: e.suit }),
				e.book && /* @__PURE__ */ f("small", { children: n(Y(`book-${e.book}`)) }),
				e.tier && /* @__PURE__ */ f("sup", { children: [
					"",
					"Ⅰ",
					"Ⅱ",
					"Ⅲ"
				][e.tier] }),
				e.color && /* @__PURE__ */ f("i", { children: re[e.color] })
			] })]
		}, r))
	});
}
function Ut({ id: e, compact: t = !1, mode: n }) {
	let r = u(), i = N[e], a = n === "discard" || n === "extra-discard", o = n === "trim", s = n === "invite", c = i.piece === "king" || i.piece === "queen", l = c && [1, 2].includes(i.tier) ? r(Y("guestFixed"), { n: i.tier === 1 ? i.color === "wild" ? 4 : 3 : i.color === "wild" ? 6 : 5 }) : r(Y(`guest${i.tier}${c ? i.piece : i.color === "wild" ? "wild" : "normal"}`));
	return /* @__PURE__ */ p("div", {
		className: `qa-card qa-card-tier${i.tier} ${t ? "qa-card-summary" : ""}`,
		children: [
			/* @__PURE__ */ p("div", {
				className: "qa-card-head",
				children: [/* @__PURE__ */ f("span", { children: r(Y(`tier${i.tier}`)) }), /* @__PURE__ */ f("span", { children: r(Y(i.color)) })]
			}),
			/* @__PURE__ */ p("div", {
				className: `qa-card-person qa-card-color-${i.color}`,
				children: [
					/* @__PURE__ */ f("span", {
						className: "qa-card-watermark",
						children: /* @__PURE__ */ f(Z, { name: i.resource })
					}),
					/* @__PURE__ */ f(Bt, {
						type: i.piece,
						color: i.color === "wild" ? "red" : i.color
					}),
					/* @__PURE__ */ f("strong", { children: r(Y(i.piece)) }),
					i.color === "wild" && /* @__PURE__ */ f("span", {
						className: "qa-wild",
						children: "◆◇"
					})
				]
			}),
			(!t || !a && !o && !s) && /* @__PURE__ */ p("div", {
				className: `qa-card-effect qa-card-play ${n === "play" ? "qa-card-emphasis" : ""}`,
				children: [/* @__PURE__ */ f("small", { children: r(Y("playEffect")) }), /* @__PURE__ */ p("div", { children: [
					/* @__PURE__ */ f("span", {
						className: "qa-card-move",
						children: r(Y("movePiece"), { piece: r(Y(i.piece)) })
					}),
					i.play.length > 0 && /* @__PURE__ */ f(Q, {
						rewards: i.play,
						text: !0
					}),
					i.piece === "king" && /* @__PURE__ */ f("span", { children: r(Y("kingAnyAction")) }),
					i.color === "wild" && /* @__PURE__ */ f("span", { children: r(Y("wildColorHelp")) }),
					i.discount > 0 && /* @__PURE__ */ p("span", { children: [
						r(Y("paymentDiscount"), { n: i.discount }),
						" · ",
						r(Y(i.discountResource))
					] })
				] })]
			}),
			(!t || a || o) && /* @__PURE__ */ p("div", {
				className: `qa-card-effect qa-card-discard ${a ? "qa-card-emphasis" : ""}`,
				children: [/* @__PURE__ */ f("small", { children: r(Y("discardEffect")) }), o ? /* @__PURE__ */ f("span", { children: r(Y("noDiscardReward")) }) : /* @__PURE__ */ f(Q, {
					rewards: i.discard,
					text: !0
				})]
			}),
			(!t || s) && /* @__PURE__ */ p("div", {
				className: `qa-card-guest ${s ? "qa-card-emphasis" : ""}`,
				children: [/* @__PURE__ */ f("small", { children: r(Y("invitedEffect")) }), /* @__PURE__ */ f("span", { children: l })]
			})
		]
	});
}
//#endregion
//#region src/games/queenalice/information-ui.tsx
function Wt({ id: e }) {
	let t = u(), [n, r] = s(!1);
	return /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
		type: "button",
		className: "qa-card-inspect",
		onClick: () => r(!0),
		children: t(Y("viewCard"))
	}), n && /* @__PURE__ */ f(Gt, {
		id: e,
		close: () => r(!1)
	})] });
}
function Gt({ id: e, close: t }) {
	let n = u(), a = o(null), s = i();
	return r(() => {
		a.current?.showModal();
	}, []), /* @__PURE__ */ p("dialog", {
		ref: a,
		className: "qa-board-details qa-card-details",
		"aria-labelledby": s,
		onClose: t,
		children: [/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("h2", {
			id: s,
			children: n(Y("cardDetails"))
		}), /* @__PURE__ */ f("button", {
			type: "button",
			autoFocus: !0,
			"aria-label": n("common.close"),
			onClick: () => a.current?.close(),
			children: "×"
		})] }), /* @__PURE__ */ f("div", {
			className: "qa-details-scroll",
			children: /* @__PURE__ */ f(Ut, { id: e })
		})]
	});
}
function Kt({ id: e, bookCost: t, used: n }) {
	let r = u(), i = F.find((t) => t.id === e);
	return /* @__PURE__ */ p("span", {
		className: "qa-bookmark-information",
		children: [
			/* @__PURE__ */ f("strong", { children: r(Y(e === "time" ? "bookmarkTime" : e)) }),
			/* @__PURE__ */ p("small", { children: [r(Y(i.kind)), i.kind === "permanent" && ` · ${r(Y(n ? "bookmarkUsed" : "bookmarkAvailable"))}`] }),
			/* @__PURE__ */ p("span", {
				className: "qa-book-price",
				children: [
					r(Y("cost")),
					": ",
					t ? t.map((e, t) => /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: "book" }), r(Y(`book-${e}`))] }, t)) : i.cost === "any2" ? r(Y("anyTwoBooks")) : i.cost.map((e, t) => /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: "book" }), r(Y(`book-${e}`))] }, t))
				]
			})
		]
	});
}
function qt({ choice: e, pub: t, name: n }) {
	let r = u();
	return /* @__PURE__ */ p("span", {
		className: "qa-choice-information",
		children: [
			e.kind === "bookmark" && /* @__PURE__ */ f(Kt, {
				id: e.value,
				bookCost: e.bookCost
			}),
			e.groups ? e.groups.map((e) => /* @__PURE__ */ p("span", {
				className: "qa-benefit-group",
				children: [/* @__PURE__ */ f("small", { children: r(Y(e.key)) }), /* @__PURE__ */ f(Q, {
					rewards: e.rewards,
					text: !0
				})]
			}, e.key)) : e.rewards?.length ? /* @__PURE__ */ f(Q, {
				rewards: e.rewards,
				text: !0
			}) : null,
			e.notes?.map((e, t) => /* @__PURE__ */ f("small", { children: r(Y(e.key), {
				n: e.n ?? 0,
				value: e.key === "rescuePreview" ? n(e.value) : e.key === "captureTarget" ? e.value.split(":").map((e) => r(Y(e))).join(" ") : e.value ? r(Y(e.value)) : ""
			}) }, t)),
			e.kind === "train" && e.target < 4 && /* @__PURE__ */ f("small", { children: r(Y([
				"flowerPinkOne",
				"flowerBlueOne",
				"flowerOrangeOne",
				"flowerYellowOne"
			][e.target])) }),
			e.kind === "color" && t.prompt === "play-color" && /* @__PURE__ */ f("small", { children: r(Y("wildColorHelp")) }),
			e.next && e.kind !== "acquire" && /* @__PURE__ */ f("small", { children: r(Y("thenAction"), { action: r(Y(e.next === "any" ? "action" : e.next)) }) })
		]
	});
}
function Jt({ player: e, color: t, difficulty: n }) {
	let r = u(), i = e.diamonds[t].length;
	return /* @__PURE__ */ p("div", {
		className: "qa-personal-tracks",
		children: [
			/* @__PURE__ */ f("div", {
				className: "qa-track-cards",
				children: I(t).map((i, a) => /* @__PURE__ */ p("article", {
					className: a < e.hearts[t] ? "qa-track-taken" : a === e.hearts[t] ? "qa-track-next" : "",
					children: [
						/* @__PURE__ */ p("strong", { children: [
							/* @__PURE__ */ f(Z, { name: "heart" }),
							a + 1,
							/* @__PURE__ */ f("small", { children: r(Y(a < e.hearts[t] ? "trackTaken" : a === e.hearts[t] ? "trackNext" : "trackFuture")) })
						] }),
						/* @__PURE__ */ p("span", { children: [
							r(Y("cost")),
							": ",
							[
								1,
								2,
								2,
								2,
								3
							][a],
							" ",
							/* @__PURE__ */ f(Z, { name: M(t) })
						] }),
						/* @__PURE__ */ f(Q, {
							rewards: ge(e, t, a, n),
							text: !0
						})
					]
				}, a))
			}),
			/* @__PURE__ */ f("p", { children: r(Y(e.dinah ? "dinahDiamondOrder" : "diamondAnyOrder")) }),
			/* @__PURE__ */ f("div", {
				className: "qa-track-cards",
				children: Array.from({ length: 5 }, (a, o) => /* @__PURE__ */ p("article", {
					className: (e.dinah ? o < i : e.diamonds[t].includes(o)) ? "qa-track-taken" : "",
					children: [/* @__PURE__ */ p("strong", { children: [
						/* @__PURE__ */ f(Z, { name: "diamond" }),
						o + 1,
						/* @__PURE__ */ f("small", { children: r(Y((e.dinah ? o < i : e.diamonds[t].includes(o)) ? "trackTaken" : "trackAvailable")) })
					] }), /* @__PURE__ */ f(Q, {
						rewards: e.dinah ? _e(t, o + 1, n) : he(t, o, 0),
						text: !0
					})]
				}, o))
			}),
			!e.dinah && /* @__PURE__ */ f("div", {
				className: "qa-milestones",
				children: [
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ p("span", {
					className: i >= e ? "qa-track-taken" : "",
					children: [/* @__PURE__ */ p("strong", { children: [r(Y("diamondCount"), { n: e }), i >= e ? " ✓" : ""] }), /* @__PURE__ */ f(Q, {
						rewards: me(t, e),
						text: !0
					})]
				}, e))
			})
		]
	});
}
function Yt({ pub: e, me: t }) {
	let n = u();
	if (!t || e.actor !== t.rid) return null;
	let r = e.prompt === "extra-discard" ? n(Y("extraDiscardHelp"), { tier: n(Y(`tier${e.remaining ?? 1}`)) }) : e.prompt === "trim" ? n(Y("trimHelp"), {
		n: Math.max(0, t.handCount - xe(t)),
		limit: xe(t)
	}) : e.prompt === "invite" ? n(Y("inviteHelp"), { n: e.remaining ?? 1 }) : e.prompt === "repeat" ? n(Y("repeatHelp"), { n: t.flowers.orange ? 5 : 6 }) : e.prompt === "promote" ? n(Y("promotionReturn")) : e.prompt === "reward-capture" ? n(Y("selectCapture")) : e.prompt === "reward-book" ? n(Y("selectBook")) : e.prompt === "reward-resource" && t.stock.length >= t.capacity ? n(Y("fullStorage")) : e.prompt === "reward-black" && t.capacity >= 8 ? n(Y("fullCapacity")) : e.mini && e.prompt === "action" ? n(Y("miniHelp")) : null;
	return r ? /* @__PURE__ */ f("p", {
		className: "qa-context-hint",
		children: r
	}) : null;
}
function Xt({ choice: e }) {
	let t = u(), n = e.result;
	return n ? /* @__PURE__ */ p("span", {
		className: "qa-payment-result",
		children: [
			/* @__PURE__ */ f("small", { children: t(Y("afterPayment")) }),
			/* @__PURE__ */ p("span", { children: [
				/* @__PURE__ */ f(Z, { name: "time" }),
				n.time,
				" · ",
				/* @__PURE__ */ f(Z, { name: "black" }),
				n.stock.length,
				"/",
				n.capacity
			] }),
			/* @__PURE__ */ p("span", { children: [
				D.map((e) => /* @__PURE__ */ p("span", { children: [
					/* @__PURE__ */ f(Z, { name: M(e) }),
					n.stock.filter((t) => t === M(e)).length,
					" "
				] }, e)),
				/* @__PURE__ */ f(Z, { name: "tea" }),
				n.stock.filter((e) => e === "tea").length
			] })
		]
	}) : null;
}
function Zt({ choice: e }) {
	let t = u();
	return /* @__PURE__ */ p("span", {
		className: "qa-choice-target",
		children: [
			t(Y(e.label), { n: e.n ?? 0 }),
			e.card && ` · ${t(Y(`tier${N[e.card].tier}`))} ${t(Y(N[e.card].color))} ${t(Y(N[e.card].piece))}`,
			e.color && ` · ${t(Y(e.color))}`,
			e.square !== void 0 && ` · ${t(Y("square"), { n: e.square + 1 })}`,
			e.kind === "garden" && ` · ${t(Y("region"), { n: e.target + 1 })} · ${e.n + 1}`,
			e.kind === "wall" && ` · ${t(Y("square"), { n: e.target + 1 })} · ♦${e.n + 1}`,
			e.kind === "tree" && ` · ${t(Y("treeHeight"), { n: e.n })} · ${e.target}`,
			e.kind === "messenger" && /* @__PURE__ */ f(Vt, { choice: e })
		]
	});
}
//#endregion
//#region src/games/queenalice/feedback.tsx
function $({ anchor: e, children: t, style: n, ...r }) {
	let { ref: i, hidden: a } = m(e);
	return /* @__PURE__ */ f("button", {
		...r,
		ref: i,
		style: {
			...n,
			visibility: a ? "hidden" : n?.visibility
		},
		children: t
	});
}
function Qt({ anchor: e, children: t, style: n, ...r }) {
	let { ref: i, hidden: a } = m(e);
	return /* @__PURE__ */ f("div", {
		...r,
		ref: i,
		style: {
			...n,
			visibility: a ? "hidden" : n?.visibility
		},
		children: t
	});
}
//#endregion
//#region src/games/queenalice/decisions.tsx
function $t({ cost: e }) {
	let t = u();
	return e?.length ? /* @__PURE__ */ p("span", {
		className: "qa-payment-cost",
		children: [/* @__PURE__ */ f("small", { children: t(Y("cost")) }), [...new Set(e)].map((n) => /* @__PURE__ */ p("span", { children: [
			/* @__PURE__ */ f(Z, { name: n }),
			t(Y(n)),
			" ×",
			e.filter((e) => e === n).length
		] }, n))]
	}) : null;
}
function en({ steps: e }) {
	let t = u(), n = e.filter((e) => e.kind === "pay-resource"), r = e.filter((e) => e.kind === "pay-time").reduce((e, t) => e + (t.n ?? 0), 0), i = e.filter((e) => e.kind === "pay-black"), a = e.filter((e) => e.kind === "discount");
	return /* @__PURE__ */ p("span", {
		className: "qa-payment-items",
		children: [
			O.map((e) => {
				let r = n.filter((t) => t.value === e).length;
				return r ? /* @__PURE__ */ p("span", { children: [
					/* @__PURE__ */ f(Z, { name: e }),
					t(Y(e)),
					" ×",
					r
				] }, e) : null;
			}),
			r > 0 && /* @__PURE__ */ p("span", { children: [
				/* @__PURE__ */ f(Z, { name: "time" }),
				t(Y("time")),
				" ×",
				r
			] }),
			i.map((e, n) => /* @__PURE__ */ p("span", { children: [
				/* @__PURE__ */ f(Z, { name: "black" }),
				t(Y("paymentCube")),
				e.value?.includes(":") && /* @__PURE__ */ p("span", { children: [
					" + ",
					/* @__PURE__ */ f(Z, { name: e.value.split(":")[1] }),
					t(Y("drop"))
				] })
			] }, n)),
			a.map((e, n) => /* @__PURE__ */ p("span", { children: [
				t(Y("paymentDiscount"), { n: 1 }),
				" · ",
				e.origin === "discountBookmark" ? t(Y(e.originValue)) : t(Y(e.origin ?? "discountCardOrRepeat"))
			] }, `discount-${n}`))
		]
	});
}
function tn({ pub: e, priv: t, me: n, prompt: r, selected: i, commit: a, clear: o, renderChoice: l, open: m, myRid: h, name: g }) {
	let _ = u(), v = t?.choices ?? [], y = v.filter((e) => e.card && e.kind !== "acquire"), b = v.filter((e) => e.kind === "payment"), [x, ee] = s(!1), S = [
		"discard",
		"extra-discard",
		"trim",
		"play",
		"invite"
	].includes(e.prompt), C = v.some((e) => [
		"garden",
		"wall",
		"tree",
		"messenger",
		"move",
		"capture"
	].includes(e.kind)), w = v.some((e) => e.kind === "acquire" && e.card), te = v.filter((e) => !e.card && ![
		"garden",
		"wall",
		"tree",
		"messenger",
		"move",
		"capture",
		"payment"
	].includes(e.kind)), T = S ? [...new Set(y.map((e) => e.card))] : t?.hand ?? [], E = e.sourceCard && N[e.sourceCard] ? `${_(Y(`tier${N[e.sourceCard].tier}`))} ${_(Y(N[e.sourceCard].color))} ${_(Y(N[e.sourceCard].piece))}` : null, D = e.pendingRewards ?? [];
	return /* @__PURE__ */ p("div", {
		className: "qa-action-bar qa-experience-dock",
		children: [
			/* @__PURE__ */ p("div", {
				className: "qa-decision",
				children: [/* @__PURE__ */ f("strong", { children: r }), E && /* @__PURE__ */ f("span", { children: _(Y("fromCard"), { card: E }) })]
			}),
			n && /* @__PURE__ */ p("div", {
				className: "qa-court-ribbon",
				"aria-label": _(Y("resources")),
				children: [
					/* @__PURE__ */ p(Qt, {
						anchor: `qa-time:${h}`,
						className: "qa-owned-time",
						children: [/* @__PURE__ */ f(Z, { name: "time" }), /* @__PURE__ */ f(c, { value: n.time })]
					}),
					/* @__PURE__ */ f("div", {
						className: "qa-stock-counters",
						children: O.map((e) => /* @__PURE__ */ p(Qt, {
							anchor: `qa-stock:${h}:${e}`,
							title: _(Y(e)),
							children: [/* @__PURE__ */ f(Z, { name: e }), /* @__PURE__ */ f(c, { value: n.stock.filter((t) => t === e).length })]
						}, e))
					}),
					/* @__PURE__ */ p(Qt, {
						anchor: `qa-black:${h}`,
						className: "qa-owned-storage",
						children: [
							/* @__PURE__ */ f(Z, { name: "black" }),
							/* @__PURE__ */ f(c, { value: n.stock.length }),
							/* @__PURE__ */ f("span", { children: "/" }),
							/* @__PURE__ */ f(c, { value: n.capacity })
						]
					}),
					/* @__PURE__ */ f("div", {
						className: "qa-owned-slots",
						children: Array.from({ length: 8 }, (e, t) => /* @__PURE__ */ f(Qt, {
							anchor: `qa-stock-slot:${h}:${t}`,
							className: `qa-store-cell ${t >= n.capacity ? "qa-store-locked" : ""}`,
							title: t < n.capacity ? n.stock[t] ? _(Y(n.stock[t])) : _(Y("empty")) : _(Y("capacity")),
							children: n.stock[t] ? /* @__PURE__ */ f(Z, { name: n.stock[t] }) : /* @__PURE__ */ f("span", { children: t < n.capacity ? "·" : "▧" })
						}, t))
					}),
					/* @__PURE__ */ p($, {
						type: "button",
						anchor: `qa-deck:${h}`,
						onClick: () => m("court"),
						title: _(Y("deck")),
						children: ["▤ ", /* @__PURE__ */ f(c, { value: n.deckCount })]
					}),
					/* @__PURE__ */ p($, {
						type: "button",
						anchor: `qa-hand:${h}`,
						onClick: () => m("hand"),
						title: _(Y("hand")),
						children: ["▱ ", /* @__PURE__ */ f(c, { value: n.handCount })]
					}),
					/* @__PURE__ */ p($, {
						type: "button",
						anchor: `qa-discard:${h}`,
						onClick: () => m("court"),
						title: _(Y("discardPile")),
						children: ["↗ ", /* @__PURE__ */ f(c, { value: n.discard.length })]
					}),
					/* @__PURE__ */ p($, {
						type: "button",
						anchor: `qa-guests:${h}`,
						onClick: () => m("court"),
						title: _(Y("invited")),
						children: [/* @__PURE__ */ f(Z, { name: "invite" }), /* @__PURE__ */ f(c, { value: n.invited.length })]
					})
				]
			}),
			/* @__PURE__ */ p("div", {
				className: "qa-dock-body",
				children: [/* @__PURE__ */ f("div", {
					className: `qa-direct-hand ${S ? "qa-hand-active" : "qa-hand-passive"}`,
					"aria-label": _(Y("hand")),
					children: Array.from({ length: Math.max(5, T.length) }, (n, r) => {
						let i = T[r], o = i ? y.find((e) => e.card === i) : void 0, s = i ? t?.hand.indexOf(i) ?? r : r;
						return /* @__PURE__ */ p(Qt, {
							anchor: `qa-hand:${h}:${s < 0 ? `discard-${r}` : s}`,
							className: `qa-hand-slot ${i ? "" : "qa-hand-slot-empty"}`,
							children: [i && /* @__PURE__ */ p("button", {
								type: "button",
								className: `qa-hand-card ${o ? "qa-legal" : ""}`,
								disabled: S && !o,
								onClick: () => o ? a(o) : m("hand"),
								"aria-label": o ? `${_(Y(o.label))} · ${_(Y(N[i].color))} ${_(Y(N[i].piece))} · ${(o.rewards ?? []).map((e) => Ht(e, _)).join(" · ")}` : `${_(Y(N[i].piece))} · ${_(Y("hand"))}`,
								children: [/* @__PURE__ */ f(Ut, {
									id: i,
									compact: !0,
									mode: e.prompt
								}), o && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("span", {
									className: "qa-card-use",
									children: [
										_(Y(o.label)),
										e.prompt === "invite" && /* @__PURE__ */ p("small", { children: [" · ", _(Y(o.notes?.[0]?.key ?? "inviteFromHand"))] }),
										o.n > 1 && /* @__PURE__ */ p("small", { children: [" · ", _(Y("cardInHand"), { n: o.n })] })
									]
								}), /* @__PURE__ */ f(X, {})] })]
							}), i && /* @__PURE__ */ f(Wt, { id: i })]
						}, r);
					})
				}), /* @__PURE__ */ p(Qt, {
					anchor: "qa-reward",
					className: `qa-resolution ${S ? "qa-resolution-secondary" : ""}`,
					children: [
						/* @__PURE__ */ f(Yt, {
							pub: e,
							me: n
						}),
						e.prompt === "pay" && e.context && /* @__PURE__ */ p("details", {
							className: "qa-payment-context",
							children: [/* @__PURE__ */ p("summary", { children: [
								_(Y("paymentTarget")),
								" · ",
								/* @__PURE__ */ f(Zt, { choice: e.context })
							] }), /* @__PURE__ */ f(qt, {
								choice: e.context,
								pub: e,
								name: g
							})]
						}),
						i ? /* @__PURE__ */ p("div", {
							className: "qa-selection-preview",
							children: [
								/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("strong", { children: i.card ? `${_(Y(N[i.card].color))} ${_(Y(N[i.card].piece))}` : _(Y(i.label), { n: i.n ?? 0 }) }), /* @__PURE__ */ f("button", {
									type: "button",
									onClick: o,
									"aria-label": _("common.close"),
									children: "×"
								})] }),
								/* @__PURE__ */ p("div", {
									className: "qa-selection-scroll",
									children: [
										["move", "capture"].includes(i.kind) && /* @__PURE__ */ p("span", { children: [
											i.color && _(Y(i.color)),
											" · ",
											_(Y("square"), { n: i.square + 1 })
										] }),
										i.kind === "garden" && /* @__PURE__ */ p("span", { children: [
											_(Y(i.color)),
											" · ",
											_(Y("region"), { n: i.target + 1 }),
											" · ",
											i.n + 1
										] }),
										i.kind === "wall" && /* @__PURE__ */ p("span", { children: [
											_(Y(i.color)),
											" · ",
											_(Y("square"), { n: i.target + 1 }),
											" · ♦",
											i.n + 1
										] }),
										i.kind === "tree" && /* @__PURE__ */ p("span", { children: [
											_(Y(i.color)),
											" · ",
											_(Y("treeHeight"), { n: i.n }),
											" · ",
											i.target
										] }),
										i.kind === "messenger" && /* @__PURE__ */ f(Vt, { choice: i }),
										/* @__PURE__ */ f($t, { cost: i.cost }),
										i.kind === "acquire" && /* @__PURE__ */ p("span", { children: [
											!!i.timeCost && /* @__PURE__ */ p(d, { children: [
												/* @__PURE__ */ f(Z, { name: "time" }),
												i.timeCost > 0 ? _(Y("cost")) : _(Y("receive")),
												" · ",
												_(Y("time")),
												" ×",
												Math.abs(i.timeCost)
											] }),
											" · ",
											_(Y("hand"))
										] }),
										/* @__PURE__ */ f(qt, {
											choice: i,
											pub: e,
											name: g
										})
									]
								}),
								/* @__PURE__ */ p("button", {
									type: "button",
									className: "qa-confirm-action",
									onClick: () => a(i),
									children: [_(Y(i.label), { n: i.n ?? 0 }), /* @__PURE__ */ f(X, {})]
								})
							]
						}) : b.length && !x ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("div", {
							className: "qa-payment-list",
							children: b.map((e) => /* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => a(e),
								className: "qa-payment-plan",
								children: [
									/* @__PURE__ */ f(en, { steps: e.payment }),
									/* @__PURE__ */ f(Xt, { choice: e }),
									/* @__PURE__ */ f("strong", { children: _(Y("confirmPayment")) }),
									/* @__PURE__ */ f(X, {})
								]
							}, e.id))
						}), /* @__PURE__ */ f("button", {
							type: "button",
							className: "qa-quiet-choice",
							onClick: () => ee(!0),
							children: _(Y("otherPayments"))
						})] }) : /* @__PURE__ */ p(d, { children: [
							!S && v.length > 0 && D.length > 0 && e.prompt !== "rewards" && /* @__PURE__ */ f(Q, {
								rewards: D,
								text: !0
							}),
							!S && C && /* @__PURE__ */ f("span", {
								className: "qa-board-instruction",
								children: _(Y(v.some((e) => e.kind === "capture") ? "selectCapture" : v.some((e) => e.kind === "move") ? "selectMove" : "selectOnBoard"))
							}),
							!S && w && /* @__PURE__ */ f("button", {
								type: "button",
								className: "qa-quiet-choice",
								onClick: () => m("market"),
								children: _(Y("selectMarket"))
							}),
							!v.length && D.length > 0 && /* @__PURE__ */ f(Q, {
								rewards: D,
								text: !0
							}),
							/* @__PURE__ */ p("div", {
								className: "qa-local-options",
								children: [te.map((e) => {
									if (e.kind === "reward") return /* @__PURE__ */ p("button", {
										type: "button",
										className: "qa-benefit",
										onClick: () => a(e),
										children: [/* @__PURE__ */ f(Q, {
											rewards: [JSON.parse(e.value)],
											text: !0
										}), /* @__PURE__ */ f(X, {})]
									}, e.id);
									if (e.kind === "resource" && e.value && e.id.startsWith("gain-")) return /* @__PURE__ */ p("button", {
										type: "button",
										className: "qa-resource-choice",
										onClick: () => a(e),
										children: [
											/* @__PURE__ */ f(Z, { name: e.value }),
											/* @__PURE__ */ f("strong", { children: _(Y("storeResource"), { resource: _(Y(e.value)) }) }),
											/* @__PURE__ */ f(X, {})
										]
									}, e.id);
									if (e.kind === "replace") {
										let [t, n] = e.value.split(":");
										return /* @__PURE__ */ p("button", {
											type: "button",
											className: "qa-resource-choice",
											onClick: () => a(e),
											children: [
												/* @__PURE__ */ p("span", { children: [
													/* @__PURE__ */ f(Z, { name: t }),
													" → ",
													/* @__PURE__ */ f(Z, { name: n })
												] }),
												/* @__PURE__ */ f("strong", { children: _(Y("replaceResource"), {
													old: _(Y(t)),
													resource: _(Y(n))
												}) }),
												/* @__PURE__ */ f(X, {})
											]
										}, e.id);
									}
									return l(e);
								}), !v.length && !D.length && /* @__PURE__ */ f("span", {
									className: "qa-wait",
									children: /* @__PURE__ */ f(Z, { name: "cat" })
								})]
							}),
							b.length > 0 && /* @__PURE__ */ f("button", {
								type: "button",
								className: "qa-quiet-choice",
								onClick: () => ee(!1),
								children: _(Y("paymentPlans"))
							})
						] })
					]
				})]
			})
		]
	});
}
//#endregion
//#region src/games/queenalice/board-details.tsx
function nn({ topic: e, pub: t, choices: n, name: r, color: i = "red" }) {
	let a = u(), [o, c] = s(!1);
	return /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
		type: "button",
		className: "qa-board-help",
		onClick: () => c(!0),
		"aria-label": `${a(Y(e))} · ${a(Y("boardDetails"))}`,
		children: a(Y("boardDetails"))
	}), o && /* @__PURE__ */ f(rn, {
		topic: e,
		pub: t,
		choices: n,
		name: r,
		initialColor: i,
		close: () => c(!1)
	})] });
}
function rn({ topic: e, pub: t, choices: n, name: a, initialColor: c, location: l, close: m }) {
	let h = u(), g = o(null), _ = i(), [v, y] = s(e), [b, x] = s(c);
	r(() => {
		g.current?.showModal();
	}, []);
	let ee = R(b), S = {
		board: "move",
		heart: "garden",
		spade: "messenger",
		club: "tree",
		diamond: "wall"
	}[v], C = v === e ? l : void 0, w = n.filter((e) => e.kind === S && (v === "board" || e.color === b) && (!C || e.target === C.target && (C.slot === void 0 || e.n === C.slot))), te = M(b), T = (e, t = 0) => [...Array(e).fill(te), ...Array(t).fill("tea")], E = (e) => e.length > 0 && /* @__PURE__ */ p("div", {
		className: "qa-details-reward",
		children: [/* @__PURE__ */ f("small", { children: h(Y("receive")) }), /* @__PURE__ */ f(Q, {
			rewards: e,
			text: !0
		})]
	}), O = (e) => e ? /* @__PURE__ */ f("small", { children: h(Y("boardOccupied"), { name: a(e) }) }) : null, k = /* @__PURE__ */ p("section", { children: [/* @__PURE__ */ f("h3", { children: h(Y("boardSpaces")) }), /* @__PURE__ */ p("div", {
		className: "qa-details-grid",
		children: [
			v === "heart" && L(b, t.players.length).flatMap((e, n) => e.map((e, r) => {
				if (C && (n !== C.target || r !== C.slot)) return null;
				let i = t.gardeners[b], a = i < 0 ? 0 : Math.min(Math.abs(i - n), 4 - Math.abs(i - n));
				return /* @__PURE__ */ p("article", { children: [
					/* @__PURE__ */ p("strong", { children: [
						h(Y("region"), { n: n + 1 }),
						" · ",
						r + 1
					] }),
					O(t.garden[b][n][r]),
					E(e),
					/* @__PURE__ */ f("small", { children: h(Y("boardGardenerCost")) }),
					a ? /* @__PURE__ */ f($t, { cost: Array(a).fill("tea") }) : /* @__PURE__ */ f("span", { children: h(Y("free")) })
				] }, `${n}:${r}`);
			})),
			v === "spade" && ee.slice(1).filter((e) => !C || e.id === C.target).map((e) => {
				let n = !!e.seal && !t.seals.includes(e.seal), r = e.seal?.endsWith("outer") ? [A("ip", n ? 6 : 3)] : e.seal?.endsWith("center") ? [A("alice", 1, { color: b }), ...n ? [A("ip", 4)] : []] : e.seal?.endsWith("end") ? [A("cat", n ? 3 : 2, { color: b })] : [];
				return /* @__PURE__ */ p("article", { children: [
					/* @__PURE__ */ p("strong", { children: [h(Y("messengerStep"), { n: e.step }), e.branch < 0 ? " ‹" : e.branch > 0 ? " ›" : ""] }),
					E([...e.rewards, A("cardReward", 1, { tier: e.tier })]),
					e.seal && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("small", { children: h(Y(n ? "boardSealFirst" : "boardSealLater")) }), E(r)] }),
					e.mini && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("small", { children: h(Y("boardPassing")) }), E([A("mini", 1, { suit: e.mini })])] })
				] }, e.id);
			}),
			v === "club" && P.slice(1).filter((e) => !C || e.id === C.target).map((e) => /* @__PURE__ */ p("article", { children: [
				/* @__PURE__ */ p("strong", { children: [
					h(Y("treeHeight"), { n: e.height }),
					" · ",
					e.id
				] }),
				E([...e.books.map((e) => A("book", 1, { book: e })), ...t.treeBooks[e.id] ? [A("book", 1, { book: "white" })] : e.bonus]),
				t.treeBooks[e.id] && e.bonus.length > 0 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("small", { children: h(Y("boardTreeCovered")) }), E(e.bonus)] }),
				oe.filter((t) => t.to === e.id).map((e) => /* @__PURE__ */ p("div", {
					className: "qa-details-edge",
					children: [/* @__PURE__ */ p("span", { children: [
						e.from,
						" → ",
						e.to
					] }), /* @__PURE__ */ f($t, { cost: Array(e.cost).fill(e.tea ? "tea" : te) })]
				}, e.from))
			] }, e.id)),
			v === "diamond" && ce(b).map((e, n) => C && n !== C.target ? null : /* @__PURE__ */ p("article", { children: [/* @__PURE__ */ p("strong", { children: [
				h(Y("square"), { n: n + 1 }),
				" · ",
				h(Y("boardRow"), { n: Math.floor(n / 4) + 1 })
			] }), ue(n, t.players.length) ? /* @__PURE__ */ p(d, { children: [
				O(t.wall[b][n]),
				/* @__PURE__ */ f($t, { cost: T([
					1,
					2,
					2,
					3,
					4
				][Math.floor(n / 4)], +(n % 4 > 1)) }),
				E(e),
				Math.floor(n / 4) === t.eggs[b] && /* @__PURE__ */ f("small", { children: h(Y("boardEggBonus")) })
			] }) : /* @__PURE__ */ f("span", { children: h(Y("boardBlocked")) })] }, n))
		]
	})] });
	return /* @__PURE__ */ p("dialog", {
		ref: g,
		className: "qa-board-details",
		"aria-labelledby": _,
		onClose: m,
		children: [
			/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("h2", {
				id: _,
				children: h(Y(C ? "locationDetails" : "boardDetails"))
			}), /* @__PURE__ */ f("button", {
				type: "button",
				autoFocus: !0,
				onClick: () => g.current?.close(),
				"aria-label": h("common.close"),
				children: "×"
			})] }),
			/* @__PURE__ */ f("nav", {
				"aria-label": h(Y("board")),
				children: ["board", ...ne].map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					"aria-pressed": v === e,
					onClick: () => y(e),
					children: [e !== "board" && /* @__PURE__ */ f(Z, { name: e }), h(Y(e))]
				}, e))
			}),
			v !== "board" && /* @__PURE__ */ f("div", {
				className: "qa-details-colors",
				children: D.map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					"aria-pressed": b === e,
					onClick: () => x(e),
					children: h(Y(e))
				}, e))
			}),
			/* @__PURE__ */ p("div", {
				className: "qa-details-scroll",
				children: [
					w.length > 0 && /* @__PURE__ */ p("section", { children: [/* @__PURE__ */ f("h3", { children: h(Y("boardCurrentOptions")) }), /* @__PURE__ */ f("div", {
						className: "qa-details-grid",
						children: w.map((e) => /* @__PURE__ */ p("article", { children: [
							/* @__PURE__ */ p("strong", { children: [
								h(Y(e.label), { n: e.n ?? 0 }),
								e.color && ` · ${h(Y(e.color))}`,
								" · ",
								v === "heart" ? `${h(Y("region"), { n: e.target + 1 })} · ${e.n + 1}` : v === "spade" ? /* @__PURE__ */ f(Vt, { choice: e }) : h(Y("square"), { n: (e.square ?? e.target ?? 0) + (v === "club" ? 0 : 1) })
							] }),
							/* @__PURE__ */ f($t, { cost: e.cost }),
							E(e.rewards ?? []),
							e.next && e.kind !== "messenger" && /* @__PURE__ */ f("small", { children: h(Y("thenAction"), { action: h(Y(e.next === "any" ? "action" : e.next)) }) })
						] }, e.id))
					})] }),
					v === "board" ? /* @__PURE__ */ p(d, { children: [
						/* @__PURE__ */ p("section", { children: [
							/* @__PURE__ */ f("h3", { children: h(Y("boardRows")) }),
							/* @__PURE__ */ f("p", { children: h(Y("boardRowHelp")) }),
							/* @__PURE__ */ f("div", {
								className: "qa-details-grid",
								children: [
									"cake",
									"tea",
									"toast",
									"any",
									"any",
									"cake",
									"tea",
									"toast"
								].map((e, t) => /* @__PURE__ */ p("article", { children: [/* @__PURE__ */ f("strong", { children: h(Y("boardRow"), { n: t + 1 }) }), E([A("resource", 1, { resource: e })])] }, t))
							})
						] }),
						/* @__PURE__ */ p("section", { children: [
							/* @__PURE__ */ f("h3", { children: h(Y("boardColumns")) }),
							/* @__PURE__ */ f("p", { children: h(Y("boardColumnHelp")) }),
							/* @__PURE__ */ f("p", { children: h(Y("boardCaptureHelp")) })
						] }),
						/* @__PURE__ */ p("section", { children: [
							/* @__PURE__ */ f("h3", { children: h(Y("alice")) }),
							/* @__PURE__ */ f("p", { children: h(Y("boardAliceHelp")) }),
							/* @__PURE__ */ f("div", {
								className: "qa-details-grid",
								children: D.map((e) => /* @__PURE__ */ p("article", { children: [/* @__PURE__ */ p("strong", { children: [
									h(Y(e)),
									" · ",
									t.alice[e]
								] }), de(t.players.length > 2).map((n, r) => r > 0 && /* @__PURE__ */ p("span", { children: [
									r,
									" · ",
									h(Y("boardAlicePoints"), { n }),
									z(t.players.length > 2).includes(r) && ` · ${h(Y("wishes"))}`,
									t.crownSpaces[e].includes(r) && ` · ${h(Y("crown"))}`
								] }, r))] }, e))
							})
						] })
					] }) : /* @__PURE__ */ p(d, { children: [
						C && k,
						/* @__PURE__ */ p("section", { children: [
							/* @__PURE__ */ f("h3", { children: h(Y("cost")) }),
							/* @__PURE__ */ f("p", { children: h(Y("boardBaseCost")) }),
							/* @__PURE__ */ f("p", { children: h(Y("boardPaymentHelp")) }),
							v === "heart" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("div", {
								className: "qa-details-grid",
								children: [
									1,
									2,
									2,
									2,
									3
								].map((e, t) => /* @__PURE__ */ p("article", { children: [
									/* @__PURE__ */ f("strong", { children: h(Y("boardHeartNumber"), { n: t + 1 }) }),
									/* @__PURE__ */ f($t, { cost: T(e) }),
									E(I(b)[t])
								] }, t))
							}), /* @__PURE__ */ f("p", { children: h(Y("boardGardenHelp")) })] }),
							v === "spade" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("div", {
								className: "qa-details-grid",
								children: [
									1,
									2,
									3
								].map((e) => /* @__PURE__ */ p("article", { children: [/* @__PURE__ */ f("strong", { children: h(Y("boardMoveSteps"), { n: e }) }), /* @__PURE__ */ f($t, { cost: T(e === 1 ? 1 : 2, +(e === 3)) })] }, e))
							}), /* @__PURE__ */ f("p", { children: h(Y("boardMessengerHelp")) })] }),
							v === "club" && /* @__PURE__ */ f("p", { children: h(Y("boardTreeHelp")) }),
							v === "diamond" && /* @__PURE__ */ p(d, { children: [
								/* @__PURE__ */ f("p", { children: h(Y("boardWallHelp")) }),
								/* @__PURE__ */ f("div", {
									className: "qa-details-grid",
									children: se(b).map((e, t) => /* @__PURE__ */ p("article", { children: [/* @__PURE__ */ f("strong", { children: h(Y("boardDiamondNumber"), { n: t + 1 }) }), E(e)] }, t))
								}),
								/* @__PURE__ */ f("p", { children: h(Y("boardDiamondMilestones")) })
							] })
						] }),
						!C && k
					] }),
					/* @__PURE__ */ p("section", { children: [/* @__PURE__ */ f("h3", { children: h(Y("boardIcons")) }), /* @__PURE__ */ f("div", {
						className: "qa-details-grid",
						children: [
							A("resource", 1, { resource: "any" }),
							A("time"),
							A("ip"),
							A("black", 1, { resource: "tea" }),
							A("cat", 1, { color: b }),
							A("alice", 1, { color: b }),
							A("crown", 1, { color: b }),
							A("acquire", 1, { tier: 1 }),
							A("invite"),
							A("cardReward", 1, { tier: 1 }),
							A("mini", 1, { suit: "heart" }),
							A("book", 1, { book: "any" })
						].map((e, t) => /* @__PURE__ */ f("article", { children: E([e]) }, t))
					})] })
				]
			}, `${v}:${b}`)
		]
	});
}
//#endregion
//#region src/games/queenalice/boards.tsx
var an = [
	96,
	84,
	70,
	52,
	52,
	52,
	52,
	52,
	32,
	32,
	32,
	32,
	14,
	2,
	14
], on = (e) => e === 1 ? 40 : e === 2 ? 60 : 8 + P[e].x * .84, sn = [
	[17, 32],
	[50, 18],
	[83, 32],
	[29, 77],
	[71, 77]
], cn = (e, t) => {
	let n = Math.floor((e - 1) / 3), r = (e - 1) % 3;
	return [16.7 + (n % 2 ? 2 - r : r) * 33.3 + t * 7, 11 + n * 25];
};
function ln({ suit: e, pub: t, choices: n, choose: r, name: a, selected: o }) {
	let c = u(), l = i().replace(/:/g, ""), [m, h] = s(null), g = m?.prompt === t.prompt ? m.color : n.find((t) => t.kind === {
		heart: "garden",
		spade: "messenger",
		club: "tree",
		diamond: "wall"
	}[e] && t.color)?.color ?? t.activeColor ?? "red", [_, v] = s(null), y = n.filter((n) => _?.prompt === t.prompt && n.color === g && n.target === _.id && n.kind === {
		heart: "garden",
		spade: "messenger",
		club: "tree",
		diamond: "wall"
	}[e]), [b, x] = s(!1), [ee, S] = s(null), C = (e) => e.length ? /* @__PURE__ */ f("small", {
		className: "qa-owners",
		children: e.map(a).join(" · ")
	}) : null, w = (e) => e?.cost?.length ? `${c(Y("cost"))}: ${e.cost.map((e) => c(Y(e === "any" ? "any" : e))).join(" · ")}` : "";
	return /* @__PURE__ */ p("section", {
		className: `qa-action-board qa-board-${e} qa-${g} ${b ? "qa-inspecting" : ""}`,
		"aria-label": `${c(Y(e))} · ${c(Y(g))}`,
		children: [
			/* @__PURE__ */ f(Z, {
				name: "bough",
				className: "qa-board-bough qa-board-bough-left"
			}),
			/* @__PURE__ */ f(Z, {
				name: "bough",
				className: "qa-board-bough qa-board-bough-right"
			}),
			/* @__PURE__ */ p("header", {
				className: "qa-board-heading",
				children: [
					/* @__PURE__ */ p("h2", { children: [/* @__PURE__ */ f(Z, { name: e }), c(Y(e))] }),
					/* @__PURE__ */ f(nn, {
						topic: e,
						pub: t,
						choices: n,
						name: a,
						color: g
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "qa-board-help qa-inspect-toggle",
						"aria-pressed": b,
						onClick: () => x(!b),
						children: c(Y(b ? "finishInspect" : "inspectSpaces"))
					}),
					/* @__PURE__ */ f("div", {
						className: "qa-color-switch",
						children: D.map((n) => /* @__PURE__ */ p("button", {
							type: "button",
							"aria-pressed": n === g,
							"aria-label": `${c(Y(e))} · ${c(Y(n))}`,
							onClick: () => h({
								color: n,
								prompt: t.prompt
							}),
							children: [n === "red" ? "◆" : "◇", /* @__PURE__ */ f("span", { children: c(Y(n)) })]
						}, n))
					})
				]
			}),
			e === "heart" && /* @__PURE__ */ p("div", {
				className: "qa-garden-scene",
				children: [
					L(g, t.players.length).map((e, i) => /* @__PURE__ */ p("div", {
						className: `qa-flowerbed ${t.gardeners[g] === i ? "qa-gardener-here" : ""}`,
						children: [
							/* @__PURE__ */ p("svg", {
								viewBox: "0 0 100 100",
								preserveAspectRatio: "none",
								"aria-hidden": "true",
								children: [/* @__PURE__ */ f("path", {
									d: "M4 94Q50 21 96 94Z",
									fill: "#e1e4d6",
									stroke: "#c3cbb8"
								}), e.map((e, t) => /* @__PURE__ */ f("path", {
									d: `M50 94Q${sn[t][0]} 65 ${sn[t][0]} ${sn[t][1]}`,
									fill: "none",
									stroke: "#6b845c",
									strokeWidth: "1.3"
								}, t))]
							}),
							/* @__PURE__ */ p("span", {
								className: "qa-bed-number",
								children: [i + 1, t.gardeners[g] === i ? " ⚑" : ""]
							}),
							e.map((e, s) => {
								let l = n.find((e) => e.kind === "garden" && e.color === g && e.target === i && e.n === s), u = t.garden[g][i][s];
								return /* @__PURE__ */ p($, {
									anchor: `qa-garden:${g}:${i}:${s}`,
									type: "button",
									className: `qa-bloom ${l ? "qa-legal" : ""} ${o && l?.id === o.id ? "qa-target-selected" : ""} ${u ? "qa-occupied" : ""}`,
									style: {
										left: `${sn[s][0]}%`,
										top: `${sn[s][1]}%`
									},
									disabled: !l && !b,
									onClick: () => b ? S({
										target: i,
										slot: s
									}) : l && r(l),
									"aria-label": `${c(Y("region"), { n: i + 1 })} · ${s + 1}${u ? ` · ${a(u)}` : ""}`,
									title: w(l),
									children: [
										/* @__PURE__ */ f(Z, {
											name: "flower",
											className: "qa-bloom-petals"
										}),
										/* @__PURE__ */ f(Q, { rewards: e }),
										l && /* @__PURE__ */ f(X, { shape: "flower" }),
										u && C([u])
									]
								}, s);
							})
						]
					}, i)),
					/* @__PURE__ */ f(Z, {
						name: "talkingflower",
						className: "qa-garden-character qa-garden-character-left"
					}),
					/* @__PURE__ */ f(Z, {
						name: "talkingflower",
						className: "qa-garden-character qa-garden-character-right"
					})
				]
			}),
			e === "club" && /* @__PURE__ */ p("div", {
				className: "qa-tree-scene",
				children: [
					/* @__PURE__ */ f(Z, {
						name: "leaf",
						className: "qa-tree-foliage"
					}),
					/* @__PURE__ */ p("svg", {
						className: "qa-tree-branches",
						viewBox: "0 0 100 100",
						preserveAspectRatio: "none",
						"aria-hidden": "true",
						children: [
							/* @__PURE__ */ f("defs", { children: /* @__PURE__ */ f("marker", {
								id: `qa-arrow-${l}`,
								markerWidth: "4",
								markerHeight: "4",
								refX: "3",
								refY: "2",
								orient: "auto",
								children: /* @__PURE__ */ f("path", {
									d: "M0 0 4 2 0 4",
									fill: "#776942"
								})
							}) }),
							/* @__PURE__ */ f("path", {
								d: "M50 100Q48 62 52 25",
								stroke: "#856741",
								strokeWidth: "2.5",
								fill: "none"
							}),
							oe.map((e, t) => /* @__PURE__ */ f("g", { children: /* @__PURE__ */ f("path", {
								d: `M${on(e.from)} ${an[e.from]}Q${on(e.from)} ${an[e.to] + 4} ${on(e.to)} ${an[e.to]}`,
								stroke: e.tea ? "#526052" : "#b68c3f",
								strokeWidth: e.tea ? .45 : .9,
								fill: "none",
								markerEnd: `url(#qa-arrow-${l})`
							}) }, t))
						]
					}),
					oe.map((e, t) => /* @__PURE__ */ p("span", {
						className: "qa-branch-cost",
						style: {
							left: `${(on(e.from) + on(e.to)) / 2 + 1.5}%`,
							top: `${(an[e.from] + an[e.to]) / 2}%`
						},
						children: [e.cost, /* @__PURE__ */ f(Z, { name: e.tea ? "tea" : M(g) })]
					}, t)),
					P.filter((e) => e.id > 0).map((e) => {
						let i = n.find((t) => t.kind === "tree" && t.color === g && t.target === e.id), a = t.players.filter((t) => t.twins[g] === e.id).map((e) => e.rid);
						return /* @__PURE__ */ p($, {
							anchor: `qa-tree:${g}:${e.id}`,
							type: "button",
							className: `qa-tree-leaf ${i ? "qa-legal" : ""} ${o && i?.id === o.id ? "qa-target-selected" : ""}`,
							style: {
								left: `${on(e.id)}%`,
								top: `${an[e.id]}%`
							},
							disabled: !i && !b,
							onClick: () => b ? S({ target: e.id }) : i && r(i),
							"aria-label": `${c(Y("treeHeight"), { n: e.height })} · ${e.id} · ${e.books.map((e) => c(Y(`book-${e}`))).join(" · ")}`,
							title: w(i),
							children: [
								/* @__PURE__ */ f(Z, {
									name: "openbook",
									className: "qa-node-art"
								}),
								i && /* @__PURE__ */ f(X, {}),
								/* @__PURE__ */ p("span", {
									className: "qa-node-number",
									children: [
										e.id,
										" · ",
										c(Y("treeHeight"), { n: e.height })
									]
								}),
								/* @__PURE__ */ p("span", {
									className: "qa-tree-books",
									children: [e.books.map((e, t) => /* @__PURE__ */ p("span", {
										className: `qa-book-${e}`,
										children: [/* @__PURE__ */ f(Z, { name: "book" }), (e === "any" || e.includes("-")) && /* @__PURE__ */ f("b", { children: "?" })]
									}, t)), t.treeBooks[e.id] && /* @__PURE__ */ f("span", {
										className: "qa-book-white",
										children: /* @__PURE__ */ f(Z, { name: "book" })
									})]
								}),
								!t.treeBooks[e.id] && e.bonus.length > 0 && /* @__PURE__ */ f(Q, { rewards: e.bonus }),
								C(a)
							]
						}, e.id);
					}),
					/* @__PURE__ */ p("span", {
						className: "qa-tree-start",
						children: [/* @__PURE__ */ f(Z, { name: "alice" }), C(t.players.filter((e) => e.twins[g] === 0).map((e) => e.rid))]
					})
				]
			}),
			e === "spade" && /* @__PURE__ */ p("div", {
				className: "qa-messenger-scene",
				children: [
					/* @__PURE__ */ f(Z, {
						name: "rabbit",
						className: "qa-messenger-rabbit"
					}),
					/* @__PURE__ */ p("svg", {
						viewBox: "0 0 100 100",
						preserveAspectRatio: "none",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ f("defs", { children: /* @__PURE__ */ f("marker", {
							id: `qa-route-arrow-${l}`,
							markerWidth: "4",
							markerHeight: "4",
							refX: "4",
							refY: "2",
							orient: "auto",
							children: /* @__PURE__ */ f("path", {
								d: "M0 0 4 2 0 4",
								fill: "#8c7757"
							})
						}) }), R(g).filter((e) => e.id > 0).flatMap((e) => e.next.map((t) => {
							let n = R(g)[t], r = cn(e.step, e.branch), i = cn(n.step, n.branch);
							return /* @__PURE__ */ f("path", {
								d: `M${r[0]} ${r[1]}Q${i[0]} ${r[1]} ${(r[0] + i[0]) / 2} ${(r[1] + i[1]) / 2}T${i[0]} ${i[1]}`,
								fill: "none",
								stroke: "#bba985",
								strokeWidth: "1.2",
								markerMid: `url(#qa-route-arrow-${l})`,
								markerEnd: `url(#qa-route-arrow-${l})`
							}, `${e.id}-${t}`);
						}))]
					}),
					R(g).filter((e) => e.id > 0).map((e) => {
						let i = n.filter((t) => t.kind === "messenger" && t.color === g && t.target === e.id), a = cn(e.step, e.branch);
						return /* @__PURE__ */ p($, {
							anchor: `qa-messenger:${g}:${e.id}`,
							type: "button",
							className: `qa-route-stop qa-tier${e.tier} ${i.length ? "qa-legal" : ""} ${i.some((e) => e.id === o?.id) ? "qa-target-selected" : ""}`,
							style: {
								left: `${a[0]}%`,
								top: `${a[1]}%`
							},
							disabled: !i.length && !b,
							onClick: () => {
								if (b) {
									S({ target: e.id });
									return;
								}
								i.length === 1 ? r(i[0]) : v({
									id: e.id,
									prompt: t.prompt
								});
							},
							"aria-label": `${c(Y("messengerStep"), { n: e.step })}${e.branch < 0 ? " ◀" : e.branch > 0 ? " ▶" : ""}`,
							title: i.map(w).join(" / "),
							children: [
								/* @__PURE__ */ f(Z, {
									name: "invite",
									className: "qa-node-art"
								}),
								i.length > 0 && /* @__PURE__ */ f(X, {}),
								/* @__PURE__ */ p("span", {
									className: "qa-node-number",
									children: [e.step, e.branch < 0 ? "‹" : e.branch > 0 ? "›" : ""]
								}),
								/* @__PURE__ */ f(Q, { rewards: [...e.rewards, {
									type: "cardReward",
									n: 1,
									tier: e.tier
								}] }),
								e.seal && !t.seals.includes(e.seal) && /* @__PURE__ */ p("i", {
									className: "qa-seal",
									children: ["✧", e.seal.endsWith("outer") ? "6/3" : e.seal.endsWith("center") ? "+4" : "3/2"]
								}),
								e.mini && /* @__PURE__ */ f("span", {
									className: "qa-route-mini",
									children: /* @__PURE__ */ f(Z, { name: e.mini })
								}),
								C(t.players.filter((t) => t.messengers[g] === e.id).map((e) => e.rid))
							]
						}, e.id);
					})
				]
			}),
			e === "diamond" && /* @__PURE__ */ p("div", {
				className: "qa-wall-scene",
				children: [
					/* @__PURE__ */ f("div", {
						className: "qa-egg-track",
						children: /* @__PURE__ */ p("span", {
							style: { bottom: `${Math.min(t.eggs[g], 4) * 20}%` },
							children: [/* @__PURE__ */ f(Z, { name: "egg" }), /* @__PURE__ */ p("small", { children: [t.eggs[g] + 1, " · 2/4✦"] })]
						})
					}),
					/* @__PURE__ */ f("div", {
						className: "qa-brickwork",
						children: Array.from({ length: 20 }, (e, i) => {
							let s = (4 - Math.floor(i / 4)) * 4 + i % 4, l = !ue(s, t.players.length), u = t.wall[g][s], m = n.filter((e) => e.kind === "wall" && e.color === g && e.target === s);
							return /* @__PURE__ */ p($, {
								anchor: `qa-wall:${g}:${s}`,
								type: "button",
								className: `qa-wall-brick ${l ? "qa-blocked" : ""} ${m.length ? "qa-legal" : ""} ${m.some((e) => e.id === o?.id) ? "qa-target-selected" : ""} ${u ? "qa-occupied" : ""}`,
								disabled: !m.length && !b,
								onClick: () => {
									if (b) {
										S({ target: s });
										return;
									}
									m.length === 1 ? r(m[0]) : v({
										id: s,
										prompt: t.prompt
									});
								},
								"aria-label": `${c(Y("square"), { n: s + 1 })}${u ? ` · ${a(u)}` : ""}`,
								title: m.map(w).join(" / "),
								children: [
									m.length > 0 && /* @__PURE__ */ f(X, {}),
									/* @__PURE__ */ p("span", {
										className: "qa-node-number",
										children: [
											s + 1,
											" · ",
											[
												1,
												2,
												2,
												3,
												4
											][Math.floor(s / 4)],
											/* @__PURE__ */ f(Z, { name: M(g) }),
											s % 4 > 1 && /* @__PURE__ */ p(d, { children: ["+1", /* @__PURE__ */ f(Z, { name: "tea" })] })
										]
									}),
									l ? /* @__PURE__ */ f("span", {
										"aria-hidden": "true",
										children: "×"
									}) : /* @__PURE__ */ f(Q, { rewards: ce(g)[s] }),
									u && C([u])
								]
							}, s);
						})
					}),
					/* @__PURE__ */ f("div", {
						className: "qa-wall-costs",
						children: [
							0,
							1,
							2,
							3
						].map((e) => /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: M(g) }), e > 1 && /* @__PURE__ */ f(Z, { name: "tea" })] }, e))
					})
				]
			}),
			ee && /* @__PURE__ */ f(rn, {
				topic: e,
				pub: t,
				choices: n,
				name: a,
				initialColor: g,
				location: ee,
				close: () => S(null)
			}),
			y.length > 1 && /* @__PURE__ */ p("div", {
				className: "qa-route-picker",
				children: [/* @__PURE__ */ f("button", {
					type: "button",
					className: "qa-picker-close",
					onClick: () => v(null),
					"aria-label": c("common.close"),
					children: "×"
				}), y.map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => {
						v(null), r(e);
					},
					children: [
						/* @__PURE__ */ p("strong", { children: [c(Y(e.label), { n: e.n ?? 0 }), e.kind === "wall" && /* @__PURE__ */ p(d, { children: [" · ♦", e.n + 1] })] }),
						e.kind === "messenger" && /* @__PURE__ */ f(Vt, { choice: e }),
						/* @__PURE__ */ f(qt, {
							choice: e,
							pub: t,
							name: a
						}),
						/* @__PURE__ */ f("span", { children: w(e) }),
						/* @__PURE__ */ f(X, {})
					]
				}, e.id))]
			})
		]
	});
}
//#endregion
//#region src/games/queenalice/progress-details.tsx
function un({ pub: e, player: t, playerName: n, children: r, className: i = "qa-progress-link", label: a, color: o, space: c }) {
	let [l, u] = s(!1);
	return /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
		type: "button",
		className: i,
		"aria-label": a,
		title: a,
		onClick: () => u(!0),
		children: r
	}), l && /* @__PURE__ */ f(dn, {
		pub: e,
		player: t,
		playerName: n,
		color: o,
		space: c,
		close: () => u(!1)
	})] });
}
function dn({ pub: e, player: t, playerName: n, color: a, space: s, close: c }) {
	let l = u(), d = o(null), m = i();
	r(() => {
		d.current?.showModal();
	}, []);
	let h = de(e.players.length > 2), g = z(e.players.length > 2);
	return /* @__PURE__ */ p("dialog", {
		ref: d,
		className: "qa-board-details",
		"aria-labelledby": m,
		onClose: c,
		children: [/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("h2", {
			id: m,
			children: l(Y("progressDetails"))
		}), /* @__PURE__ */ f("button", {
			type: "button",
			autoFocus: !0,
			"aria-label": l("common.close"),
			onClick: () => d.current?.close(),
			children: "×"
		})] }), /* @__PURE__ */ p("div", {
			className: "qa-details-scroll",
			children: [
				/* @__PURE__ */ f("p", { children: /* @__PURE__ */ f("strong", { children: n }) }),
				a !== void 0 && s !== void 0 && /* @__PURE__ */ p("section", { children: [/* @__PURE__ */ p("h3", { children: [
					l(Y(a)),
					" · ",
					l(Y("trackPosition"), { n: s })
				] }), /* @__PURE__ */ p("p", { children: [
					l(Y("boardAlicePoints"), { n: h[s] }),
					e.alice[a] === s && ` · ${l(Y("aliceHere"))}`,
					e.crownSpaces[a].includes(s) && ` · ${l(Y("crown"))}`,
					g.includes(s) && ` · ${l(Y("wishes"))}`
				] })] }),
				/* @__PURE__ */ p("section", { children: [
					/* @__PURE__ */ p("h3", { children: [
						l(Y("supply")),
						" · ",
						e.crowns
					] }),
					/* @__PURE__ */ f("p", { children: l(Y("crownHelp")) }),
					/* @__PURE__ */ f("p", { children: l(Y("crownFinalHelp")) })
				] }),
				/* @__PURE__ */ p("section", { children: [
					/* @__PURE__ */ f("h3", { children: l(Y("alice")) }),
					/* @__PURE__ */ f("p", { children: l(Y("boardAliceHelp")) }),
					/* @__PURE__ */ f("p", { children: l(Y("aliceEndHelp")) }),
					/* @__PURE__ */ f("div", {
						className: "qa-details-grid",
						children: D.map((n) => /* @__PURE__ */ p("article", { children: [
							/* @__PURE__ */ p("strong", { children: [
								l(Y(n)),
								" · ",
								l(Y("trackPosition"), { n: e.alice[n] })
							] }),
							/* @__PURE__ */ p("span", { children: [
								l(Y("crowns")),
								": ",
								t.crowns[n]
							] }),
							/* @__PURE__ */ p("span", { children: [
								l(Y("advances")),
								": ",
								t.advances[n]
							] }),
							/* @__PURE__ */ p("span", { children: [
								l(Y("crownPositions")),
								": ",
								e.crownSpaces[n].length ? e.crownSpaces[n].join(" · ") : l(Y("empty"))
							] })
						] }, n))
					})
				] }),
				/* @__PURE__ */ p("section", { children: [
					/* @__PURE__ */ p("h3", { children: [
						/* @__PURE__ */ f(Z, { name: "cat" }),
						" ",
						l(Y("cats"))
					] }),
					/* @__PURE__ */ f("p", { children: l(Y("catHelp")) }),
					/* @__PURE__ */ f("div", {
						className: "qa-details-grid",
						children: D.map((e) => {
							let n = t.cats[e], r = n < 6 ? 6 : 10;
							return /* @__PURE__ */ p("article", { children: [
								/* @__PURE__ */ p("strong", { children: [
									l(Y(e)),
									" · ",
									l(Y("catSteps"), { n })
								] }),
								/* @__PURE__ */ f("span", { children: l(Y(n >= 10 ? "catTwoWishes" : n >= 6 ? "catOneWish" : "catNoWish")) }),
								n < 10 && /* @__PURE__ */ f("span", { children: l(Y("catNext"), {
									n: r - n,
									step: r
								}) })
							] }, e);
						})
					}),
					/* @__PURE__ */ f("p", { children: l(Y("catThreshold")) }),
					/* @__PURE__ */ f("p", { children: l(Y("catCrossingHelp")) }),
					/* @__PURE__ */ f("div", {
						className: "qa-details-grid",
						children: D.filter((e) => !a || e === a).map((e) => /* @__PURE__ */ p("article", { children: [/* @__PURE__ */ f("strong", { children: l(Y(e)) }), Array.from({ length: 12 }, (n, r) => /* @__PURE__ */ p("div", {
							className: `qa-cat-track-row ${t.cats[e] === r + 1 ? "qa-track-next" : t.cats[e] > r + 1 ? "qa-track-taken" : ""}`,
							children: [
								/* @__PURE__ */ p("b", { children: [r + 1, t.cats[e] === r + 1 ? " ◀" : ""] }),
								ve(e, r + 1).length ? /* @__PURE__ */ f(Q, {
									rewards: ve(e, r + 1),
									text: !0
								}) : /* @__PURE__ */ f("span", { children: l(Y("noImmediateReward")) }),
								[6, 10].includes(r + 1) && /* @__PURE__ */ f("small", { children: l(Y(r + 1 === 6 ? "catOneWish" : "catTwoWishes")) })
							]
						}, r))] }, e))
					})
				] })
			]
		})]
	});
}
//#endregion
//#region src/games/queenalice/flowers.tsx
var fn = [
	{
		id: "pink",
		abilities: ["flowerPinkOne", "flowerPinkTwo"]
	},
	{
		id: "blue",
		abilities: ["flowerBlueOne", "flowerBlueTwo"]
	},
	{
		id: "orange",
		abilities: ["flowerOrangeOne", "flowerOrangeTwo"]
	},
	{
		id: "yellow",
		abilities: ["flowerYellowOne", "flowerYellowTwo"]
	}
];
function pn({ player: e, difficulty: t }) {
	let n = u(), r = {
		easy: 3,
		normal: 4,
		hard: 5,
		expert: 6
	}[t];
	return /* @__PURE__ */ p("section", {
		className: "qa-flowers",
		"aria-label": n(Y("flower")),
		children: [
			/* @__PURE__ */ f("h3", { children: n(Y("flower")) }),
			/* @__PURE__ */ f("p", {
				className: "qa-flower-note",
				children: n(Y(e.dinah ? "flowerDinah" : "flowerPermanent"), { n: r })
			}),
			/* @__PURE__ */ f("div", {
				className: "qa-flower-cards",
				children: fn.map(({ id: t, abilities: i }) => {
					let a = e.flowers[t];
					return /* @__PURE__ */ p("article", {
						className: "qa-flower-card",
						children: [/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ p("span", {
							className: `qa-flower-${t}`,
							children: [
								/* @__PURE__ */ f(Z, { name: t }),
								" ",
								/* @__PURE__ */ f("strong", { children: n(Y(t)) })
							]
						}), /* @__PURE__ */ p("b", { children: ["×", a] })] }), e.dinah ? /* @__PURE__ */ f("p", { children: n(Y("flowerDinahPoints"), { n: a * r }) }) : /* @__PURE__ */ f("ul", { children: i.map((e, t) => /* @__PURE__ */ p("li", {
							className: a > t ? "qa-flower-unlocked" : "qa-flower-locked",
							children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("b", { children: n(Y("flowerThreshold"), { n: t + 1 }) }), /* @__PURE__ */ f("span", { children: n(Y(a > t ? "flowerUnlocked" : "flowerLocked")) })] }), /* @__PURE__ */ f("p", { children: n(Y(e)) })]
						}, e)) })]
					}, t);
				})
			})
		]
	});
}
//#endregion
//#region src/games/queenalice/view-player.tsx
var mn = {
	train: "Train",
	discard: "Discard",
	play: "Play",
	rewards: "Rewards",
	"reward-resource": "Resource",
	"reward-black": "Resource",
	"reward-cat": "Color",
	"reward-alice": "Color",
	"reward-crown": "Color",
	"reward-book": "Book",
	"reward-capture": "Capture",
	"play-color": "PlayColor",
	"dinah-move": "DinahMove",
	move: "Move",
	promote: "Promote",
	column: "Column",
	pay: "Pay",
	action: "Action",
	mini: "Mini",
	acquire: "Acquire",
	invite: "Invite",
	bookmark: "Bookmark",
	repeat: "Repeat",
	trim: "Trim",
	"extra-discard": "Discard",
	"final-wish": "FinalWish",
	"card-reward": "Acquire"
}, hn = (e) => e?.map((e) => e.id).join("|") ?? "", gn = (e) => {
	if (!e?.startsWith("[") && !e?.startsWith("{")) return [];
	let t = JSON.parse(e);
	return Array.isArray(t) ? t : [t];
};
function _n({ public: e, private: t, members: n, myRid: r, send: i }) {
	let a = e, o = t, l = u(), [m, v] = s(null), y = `${a.round}:${a.actor}:${a.prompt}:${a.activeCard}:${hn(o?.choices)}`, b = m?.key === y ? m.choice : void 0, [x, ee] = s({
		id: "board",
		prompt: a.prompt
	}), [S, C] = s(r), [w, te] = s(null), T = (e) => e === "queenalice-dinah" ? l(Y("dinah")) : n.find((t) => t.rid === e)?.name ?? e, E = a.players.find((e) => e.rid === r), O = a.players.find((e) => e.rid === S) ?? E ?? a.players[0], k = a.phase === "done" ? [] : o?.choices ?? [], A = a.sourceScene && [
		"plant",
		"build",
		"climb",
		"messenger",
		"buy-card",
		"rewards",
		"reward-resource",
		"reward-black",
		"reward-time",
		"reward-book",
		"reward-cat",
		"reward-alice",
		"reward-crown",
		"reward-flower",
		"pay",
		"bookmark",
		"card-reward"
	].includes(a.prompt) ? a.sourceScene : k.some((e) => e.kind === "acquire") ? "market" : k.some((e) => [
		"garden",
		"tree",
		"messenger",
		"wall"
	].includes(e.kind)) || a.prompt === "pay" ? a.activeSuit ?? "board" : "board", j = x.prompt === a.prompt ? x.id : A, M = (e) => ee({
		id: e,
		prompt: a.prompt
	}), ie = (e) => {
		te(null), v(null), i({
			type: "choose",
			id: e.id
		});
	}, N = (e) => {
		if ([
			"garden",
			"wall",
			"tree",
			"messenger",
			"mini",
			"move",
			"capture",
			"train",
			"bookmark"
		].includes(e.kind) || e.kind === "acquire" && e.card) {
			v({
				key: y,
				choice: e
			});
			return;
		}
		ie(e);
	}, ae = a.prompt === "card-reward" ? l(Y("cardReward")) : mn[a.prompt] ? l(Y(`prompt${mn[a.prompt]}`)) : l(Y("noDecision")), oe = (e) => l(Y(e.label), { n: e.n ?? 0 }), I = k.filter((e) => e.kind === "move"), se = w ? I.filter((e) => e.value === w) : I, ce = (e) => {
		let t = se.filter((t) => t.square === e), n = k.find((t) => t.kind === "capture" && t.square === e);
		if (n) {
			N(n);
			return;
		}
		if (t.length === 1 && (w || !a.pieces.some((t) => t.square === e && I.some((e) => e.value === t.id)))) {
			N(t[0]);
			return;
		}
		let r = a.pieces.find((t) => t.square === e);
		r && I.some((e) => e.value === r.id) && te(r.id);
	}, le = (e) => e.cost?.length ? /* @__PURE__ */ p("small", {
		className: "qa-choice-cost",
		"aria-label": `${l(Y("cost"))}: ${e.cost.map((e) => l(Y(e))).join(" · ")}`,
		children: [
			l(Y("cost")),
			": ",
			e.cost.map((e, t) => /* @__PURE__ */ f(Z, { name: e }, t))
		]
	}) : null;
	function ue(e) {
		return /* @__PURE__ */ p("button", {
			type: "button",
			className: `qa-choice qa-choice-${e.kind} ${e.color ? `qa-${e.color}` : ""}`,
			onClick: () => N(e),
			children: [
				e.card ? /* @__PURE__ */ f(Ut, {
					id: e.card,
					compact: !0,
					mode: e.kind
				}) : /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ f("strong", { children: e.kind === "action" && e.value ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Z, { name: e.value }), l(Y(e.value))] }) : oe(e) }),
					e.kind === "acquire" && !e.card && /* @__PURE__ */ f("small", { children: l(Y(`tier${e.n ?? 1}`)) }),
					e.kind === "train" && /* @__PURE__ */ f(Z, { name: e.target < 4 ? "rose" : e.target < 8 ? "book" : e.target < 12 ? "egg" : "invite" }),
					e.kind === "train" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", { children: l(Y(`train${e.target}`)) }), /* @__PURE__ */ f("b", { children: l(Y(e.color)) })] }) : null,
					e.color && e.kind !== "train" && /* @__PURE__ */ p("span", { children: [
						re[e.color],
						" ",
						l(Y(e.color))
					] }),
					e.square !== void 0 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", { children: l(Y("square"), { n: e.square + 1 }) }), e.kind === "move" && e.value && /* @__PURE__ */ f(Bt, {
						type: a.pieces.find((t) => t.id === e.value).type,
						color: a.pieces.find((t) => t.id === e.value).color
					})] }),
					e.kind === "tree" && /* @__PURE__ */ p("span", { children: [
						l(Y("treeHeight"), { n: e.n ?? 0 }),
						" · ",
						e.target
					] }),
					e.kind === "garden" && /* @__PURE__ */ p("span", { children: [
						l(Y("region"), { n: e.target + 1 }),
						" · ",
						(e.n ?? 0) + 1
					] }),
					e.kind === "wall" && /* @__PURE__ */ p("span", { children: [
						l(Y("square"), { n: e.target + 1 }),
						" · ♦",
						(e.n ?? 0) + 1
					] }),
					e.kind === "messenger" && /* @__PURE__ */ f("span", { children: l(Y("messengerStep"), { n: R(e.color)[e.target].step }) }),
					e.kind === "messenger" && /* @__PURE__ */ f(Vt, { choice: e }),
					e.kind === "tree" && /* @__PURE__ */ f("span", {
						className: "qa-tree-books",
						children: P[e.target].books.map((e, t) => /* @__PURE__ */ p("span", {
							className: `qa-book-${e}`,
							children: [/* @__PURE__ */ f(Z, { name: "book" }), /* @__PURE__ */ f("small", { children: l(Y(`book-${e}`)) })]
						}, t))
					}),
					e.kind === "wish" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", { children: l(Y(`wish${e.target}`)) }), /* @__PURE__ */ f("span", { children: l(Y(`wishDetail${e.target}`)) })] }),
					e.value && gn(e.value).length > 0 ? null : e.value && ![
						"move",
						"capture",
						"bookmark"
					].includes(e.kind) ? /* @__PURE__ */ f("span", { children: e.kind === "bookmark" ? l(Y(e.value)) : e.kind === "book" ? l(Y(`book-${e.value}`)) : e.value.includes(":") ? e.value.split(":").map((e) => re[e] ?? l(Y(e))).join(" → ") : re[e.value] ?? l(Y(e.value)) }) : null,
					/* @__PURE__ */ f(qt, {
						choice: e,
						pub: a,
						name: T
					}),
					le(e)
				] }),
				/* @__PURE__ */ f(X, {}),
				e.card && /* @__PURE__ */ p("b", { children: [oe(e), e.kind === "acquire" && /* @__PURE__ */ p("span", { children: [" · ", e.n === 0 ? l(Y("free")) : e.n === 1 ? "◷ 1" : "◈ 1"] })] })
			]
		}, e.id);
	}
	function L() {
		return /* @__PURE__ */ p("section", {
			className: "qa-mirror",
			"aria-label": l(Y("board")),
			children: [
				/* @__PURE__ */ f(zt, {}),
				/* @__PURE__ */ f(Z, {
					name: "cat",
					className: "qa-court-cat qa-court-cat-red"
				}),
				/* @__PURE__ */ f(Z, {
					name: "cat",
					className: "qa-court-cat qa-court-cat-white"
				}),
				/* @__PURE__ */ p("div", {
					className: "qa-mirror-body",
					children: [D.map((e) => /* @__PURE__ */ f("div", {
						className: `qa-coronation qa-coronation-${e}`,
						"aria-label": `${l(Y(e))} · ${l(Y("alice"))}`,
						children: de(a.players.length > 2).map((t, n) => /* @__PURE__ */ p(un, {
							pub: a,
							player: O,
							playerName: T(O.rid),
							color: e,
							space: n,
							label: `${l(Y(e))} · ${l(Y("trackPosition"), { n })} · ${l(Y("boardAlicePoints"), { n: t })}`,
							className: `qa-track-space ${a.alice[e] === n ? "qa-alice-here" : ""}`,
							children: [a.alice[e] === n ? /* @__PURE__ */ f(Z, { name: "alice" }) : a.crownSpaces[e].includes(n) ? /* @__PURE__ */ f(Z, { name: "crown" }) : z(a.players.length > 2).includes(n) ? /* @__PURE__ */ f("span", { children: "▱" }) : t, /* @__PURE__ */ f("small", {
								className: "qa-track-index",
								children: n
							})]
						}, n))
					}, e)), /* @__PURE__ */ p("div", {
						className: "qa-board-frame",
						children: [/* @__PURE__ */ f("div", {
							className: "qa-column-labels",
							children: [
								"heart",
								"spade",
								"any",
								"club",
								"diamond"
							].map((e) => /* @__PURE__ */ f("span", { children: e === "any" ? "★" : /* @__PURE__ */ f(Z, { name: e }) }, e))
						}), /* @__PURE__ */ p("div", {
							className: "qa-chess-wrap",
							children: [/* @__PURE__ */ f("div", {
								className: "qa-rank-labels",
								children: [
									"cake",
									"tea",
									"toast",
									"any",
									"any",
									"cake",
									"tea",
									"toast"
								].map((e, t) => /* @__PURE__ */ f("span", { children: /* @__PURE__ */ f(Z, { name: e }) }, t))
							}), /* @__PURE__ */ f("div", {
								className: "qa-chessboard",
								children: Array.from({ length: 40 }, (e, t) => {
									let n = se.find((e) => e.square === t), r = a.pieces.find((e) => e.square === t), i = se.some((e) => e.square === t) || k.some((e) => e.kind === "capture" && e.square === t), o = r && I.some((e) => e.value === r.id);
									return /* @__PURE__ */ p($, {
										anchor: `qa-square:${t}`,
										type: "button",
										className: `qa-square ${(Math.floor(t / 5) + t % 5) % 2 ? "qa-dark" : "qa-light"} ${i ? "qa-destination" : ""} ${b?.square === t && ["move", "capture"].includes(b.kind) ? "qa-target-selected" : ""} ${w && r?.id === w ? "qa-selected" : ""} ${o ? "qa-selectable" : ""}`,
										title: n ? [...(n.rewards ?? []).map((e) => Ht(e, l)), l(Y("thenAction"), { action: l(Y(n.next === "any" ? "action" : n.next)) })].join(" · ") : void 0,
										disabled: !i && !o,
										onClick: () => ce(t),
										"aria-pressed": !!w && r?.id === w,
										"aria-label": `${l(Y("square"), { n: t + 1 })}${r ? ` · ${l(Y(r.color))} ${l(Y(r.type))}` : ""}`,
										children: [
											/* @__PURE__ */ f("small", { children: t + 1 }),
											r && /* @__PURE__ */ f(Qt, {
												anchor: `qa-piece:${r.id}`,
												className: "qa-piece-holder",
												children: /* @__PURE__ */ f(Bt, {
													type: r.type,
													color: r.color
												})
											}),
											(i || o && r?.id !== w) && /* @__PURE__ */ f(X, {}),
											i && !r && /* @__PURE__ */ f("span", {
												className: "qa-landing-benefit",
												children: /* @__PURE__ */ f(Z, { name: [
													"cake",
													"tea",
													"toast",
													"any",
													"any",
													"cake",
													"tea",
													"toast"
												][Math.floor(t / 5)] })
											})
										]
									}, t);
								})
							})]
						})]
					})]
				}),
				/* @__PURE__ */ f(Qt, {
					anchor: "qa-prisons",
					className: "qa-prisons",
					children: a.pieces.filter((e) => e.square < 0).map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						disabled: !I.some((t) => t.value === e.id),
						onClick: () => te(e.id),
						"aria-label": `${l(Y("rescue"))} ${l(Y(e.color))} ${l(Y(e.type))}`,
						children: [
							/* @__PURE__ */ f(Bt, {
								type: e.type,
								color: e.color
							}),
							/* @__PURE__ */ f("small", { children: T(e.prison) }),
							I.some((t) => t.value === e.id) && w !== e.id && /* @__PURE__ */ f(X, {})
						]
					}, e.id))
				})
			]
		});
	}
	return /* @__PURE__ */ p(h, {
		adaptive: !0,
		className: "qa-screen",
		actionsHeight: "h-64 short:h-40",
		banner: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("div", {
			className: "qa-banner",
			children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p("b", { children: [/* @__PURE__ */ f(Z, { name: "crown" }), l(Y("name"))] }), /* @__PURE__ */ f("span", { children: l(Y("round"), { n: a.round }) })] }), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p(un, {
				pub: a,
				player: O,
				playerName: T(O.rid),
				className: "qa-supply",
				label: l(Y("progressDetails")),
				children: [/* @__PURE__ */ f(Z, { name: "crown" }), /* @__PURE__ */ p("span", { children: [
					l(Y("supply")),
					" ",
					/* @__PURE__ */ f("b", { children: a.crowns })
				] })]
			}), a.finalRound && /* @__PURE__ */ f("strong", { children: l(Y("finalRound")) })] })]
		}), /* @__PURE__ */ f("div", {
			className: "qa-seats",
			children: a.players.map((e) => /* @__PURE__ */ p($, {
				anchor: `qa-seat:${e.rid}`,
				className: `${a.actor === e.rid ? "qa-actor" : ""} ${O.rid === e.rid ? "qa-focus" : ""}`,
				type: "button",
				onClick: () => {
					C(e.rid), M("court");
				},
				children: [
					/* @__PURE__ */ p("strong", { children: [/* @__PURE__ */ f("i", {
						className: "qa-seat-seal",
						style: { background: g[(n.find((t) => t.rid === e.rid)?.colorIndex ?? 0) % g.length].hex },
						children: T(e.rid).slice(0, 1)
					}), T(e.rid)] }),
					/* @__PURE__ */ p("b", { children: ["✦ ", /* @__PURE__ */ f(c, { value: e.ip })] }),
					/* @__PURE__ */ p("span", { children: [
						/* @__PURE__ */ f(Z, { name: "time" }),
						e.time,
						" · ",
						e.stock.map((e, t) => /* @__PURE__ */ f(Z, { name: e }, t)),
						e.dinah ? /* @__PURE__ */ f(Z, { name: "cat" }) : ` / ${e.capacity}`
					] })
				]
			}, e.rid))
		})] }),
		actions: /* @__PURE__ */ f(tn, {
			pub: a,
			priv: o,
			me: E,
			myRid: r,
			name: T,
			selected: b,
			commit: ie,
			clear: () => v(null),
			renderChoice: ue,
			open: M,
			prompt: k.length ? ae : a.actor === r ? l(Y("noDecision")) : l(Y("waiting"), { name: T(a.actor) })
		}),
		children: [
			/* @__PURE__ */ f(Rt, {}),
			/* @__PURE__ */ f(_, {
				kind: "sheen",
				base: "#332d30",
				className: "qa-table-texture"
			}),
			/* @__PURE__ */ p("div", {
				className: "qa-workspace",
				children: [
					/* @__PURE__ */ p("nav", {
						className: "qa-tabs",
						"aria-label": l(Y("board")),
						children: [[
							"board",
							"market",
							...ne,
							"hand",
							"court",
							"wishes",
							"logTitle"
						].map((e) => /* @__PURE__ */ p("button", {
							type: "button",
							"aria-pressed": j === e,
							onClick: () => M(e),
							children: [
								re[e],
								" ",
								l(Y(e))
							]
						}, e)), /* @__PURE__ */ f(nn, {
							topic: "board",
							pub: a,
							choices: k,
							name: T
						})]
					}),
					(j === "board" || ne.includes(j)) && /* @__PURE__ */ p("div", {
						className: `qa-tableau ${j === "board" ? "" : "qa-tableau-action"}`,
						children: [/* @__PURE__ */ f("div", {
							className: `qa-chess-scene ${j === "board" ? "" : "qa-secondary-scene"}`,
							children: L()
						}), ne.map((e) => /* @__PURE__ */ f("div", {
							className: `qa-scene qa-scene-${e} ${j === e ? "qa-current-scene" : ""}`,
							children: /* @__PURE__ */ f(ln, {
								suit: e,
								pub: a,
								choices: k,
								choose: N,
								name: T,
								selected: b
							})
						}, e))]
					}),
					j === "hand" && /* @__PURE__ */ p("section", {
						className: "qa-panel",
						children: [
							/* @__PURE__ */ f("h2", { children: l(Y("hand")) }),
							/* @__PURE__ */ f("div", {
								className: "qa-card-row",
								children: o?.hand.map((e, t) => /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("button", {
									type: "button",
									className: "qa-hand-full",
									disabled: !k.some((t) => t.card === e && t.kind !== "acquire"),
									onClick: () => {
										let t = k.find((t) => t.card === e && t.kind !== "acquire");
										t && ie(t);
									},
									children: /* @__PURE__ */ f(Ut, { id: e })
								}), /* @__PURE__ */ f(Wt, { id: e })] }, `${e}-${t}`))
							}),
							a.activeCard && /* @__PURE__ */ f("div", {
								className: "qa-active-card",
								children: /* @__PURE__ */ f(Ut, { id: a.activeCard })
							})
						]
					}),
					j === "market" && /* @__PURE__ */ f("section", {
						className: "qa-panel",
						children: a.market.map((e, t) => /* @__PURE__ */ p("div", {
							className: "qa-market-tier",
							children: [/* @__PURE__ */ p("h2", { children: [
								l(Y(`tier${t + 1}`)),
								" ",
								/* @__PURE__ */ p("small", { children: ["▤ ", a.marketCounts[t]] })
							] }), /* @__PURE__ */ f("div", {
								className: "qa-card-row",
								children: e.map((e, n) => {
									let r = k.find((t) => t.kind === "acquire" && t.card === e);
									return /* @__PURE__ */ p(Qt, {
										anchor: `qa-market:${t + 1}:${n}`,
										className: "qa-market-card",
										children: [/* @__PURE__ */ f("small", { children: n === 0 ? l(Y("free")) : n === 1 ? "◷ 1" : "◈ 1" }), e ? /* @__PURE__ */ p("button", {
											type: "button",
											disabled: !r,
											className: r ? "qa-legal" : "",
											onClick: () => r && N(r),
											children: [/* @__PURE__ */ f(Ut, { id: e }), r && /* @__PURE__ */ f(X, {})]
										}) : /* @__PURE__ */ f("span", { children: "—" })]
									}, n);
								})
							})]
						}, t))
					}),
					j === "court" && /* @__PURE__ */ p("section", {
						className: "qa-panel",
						children: [
							/* @__PURE__ */ f("h2", { children: T(O.rid) }),
							/* @__PURE__ */ p("div", {
								className: "qa-court-stats",
								children: [
									/* @__PURE__ */ p("span", { children: [
										/* @__PURE__ */ f(Z, { name: "time" }),
										" ",
										O.time
									] }),
									/* @__PURE__ */ p("span", { children: [
										l(Y("capacity")),
										" ",
										O.stock.length,
										"/",
										O.capacity
									] }),
									/* @__PURE__ */ p("span", { children: ["▤ ", O.deckCount] }),
									/* @__PURE__ */ p("span", { children: [
										l(Y("hand")),
										" ",
										O.handCount
									] })
								]
							}),
							/* @__PURE__ */ f("div", {
								className: "qa-storage",
								"aria-label": l(Y("resources")),
								children: Array.from({ length: O.capacity }, (e, t) => /* @__PURE__ */ f("span", {
									className: `qa-resource-slot ${O.stock[t] ? "" : "qa-empty-slot"}`,
									children: O.stock[t] ? /* @__PURE__ */ f(Z, { name: O.stock[t] }) : /* @__PURE__ */ f("span", { children: "·" })
								}, t))
							}),
							/* @__PURE__ */ f(pn, {
								player: O,
								difficulty: a.difficulty
							}),
							/* @__PURE__ */ f("div", {
								className: "qa-court-grid",
								children: D.map((e) => /* @__PURE__ */ p("div", {
									className: `qa-zone qa-${e}`,
									children: [
										/* @__PURE__ */ f("h3", { children: l(Y(e)) }),
										/* @__PURE__ */ f(Jt, {
											player: O,
											color: e,
											difficulty: a.difficulty
										}),
										/* @__PURE__ */ p("div", {
											className: "qa-personal-counters",
											children: [
												/* @__PURE__ */ p(un, {
													pub: a,
													player: O,
													playerName: T(O.rid),
													color: e,
													label: `${l(Y(e))} · ${l(Y("cats"))}`,
													children: [/* @__PURE__ */ f(Z, { name: "cat" }), /* @__PURE__ */ p("span", { children: [l(Y("cats")), /* @__PURE__ */ f("strong", { children: l(Y("catSteps"), { n: O.cats[e] }) })] })]
												}),
												/* @__PURE__ */ p(un, {
													pub: a,
													player: O,
													playerName: T(O.rid),
													color: e,
													label: `${l(Y(e))} · ${l(Y("crowns"))}`,
													children: [/* @__PURE__ */ f(Z, { name: "crown" }), /* @__PURE__ */ p("span", { children: [l(Y("crowns")), /* @__PURE__ */ f("strong", { children: O.crowns[e] })] })]
												}),
												/* @__PURE__ */ p("span", {
													title: l(Y("advances")),
													children: [/* @__PURE__ */ f(Z, { name: "alice" }), O.advances[e]]
												}),
												/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: "spade" }), R(e)[O.messengers[e]].step] }),
												/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: "club" }), P[O.twins[e]].height] })
											]
										})
									]
								}, e))
							}),
							/* @__PURE__ */ p("p", { children: [
								l(Y("books")),
								": ",
								Object.entries(O.books).map(([e, t]) => /* @__PURE__ */ p("span", {
									className: `qa-book-${e}`,
									children: [
										/* @__PURE__ */ f(Z, { name: "book" }),
										" ",
										l(Y(`book-${e}`)),
										" ",
										t,
										" "
									]
								}, e))
							] }),
							/* @__PURE__ */ f("h3", { children: l(Y("bookmarks")) }),
							/* @__PURE__ */ f("div", {
								className: "qa-bookmark-list",
								children: O.bookmarks.map((e, t) => /* @__PURE__ */ f("span", {
									className: O.used.includes(e) ? "qa-used" : "",
									children: /* @__PURE__ */ f(Kt, {
										id: e,
										used: O.used.includes(e)
									})
								}, `${e}-${t}`))
							}),
							/* @__PURE__ */ f("h3", { children: l(Y("invited")) }),
							/* @__PURE__ */ f("div", {
								className: "qa-card-row",
								children: O.invited.map((e, t) => /* @__PURE__ */ f("div", { children: /* @__PURE__ */ f(Ut, { id: e }) }, `${e}-${t}`))
							}),
							/* @__PURE__ */ f("h3", { children: l(Y("discardPile")) }),
							/* @__PURE__ */ f("div", {
								className: "qa-card-row",
								children: O.discard.map((e, t) => /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f(Ut, {
									id: e,
									compact: !0
								}), /* @__PURE__ */ f(Wt, { id: e })] }, `${e}-${t}`))
							}),
							/* @__PURE__ */ p("h3", { children: [
								l(Y("bookmarks")),
								" · ",
								l(Y("market"))
							] }),
							/* @__PURE__ */ f("div", {
								className: "qa-bookmark-list",
								children: a.bookmarks.map((e) => {
									let t = F.find((t) => t.id === e);
									return /* @__PURE__ */ f("div", { children: /* @__PURE__ */ f(Kt, { id: t.id }) }, e);
								})
							})
						]
					}),
					j === "wishes" && /* @__PURE__ */ p("section", {
						className: "qa-panel",
						children: [
							/* @__PURE__ */ f("h2", { children: l(Y("wishes")) }),
							/* @__PURE__ */ f("p", { children: l(Y("wishScoringHelp")) }),
							/* @__PURE__ */ f("p", { children: l(Y("wishPlatinumHelp")) }),
							/* @__PURE__ */ f("div", {
								className: "qa-wishes",
								children: a.wishes.map((e, t) => /* @__PURE__ */ p("article", {
									className: `qa-wish qa-${e.color}`,
									children: [
										/* @__PURE__ */ p("span", { children: [
											re[e.color],
											" ",
											l(Y(e.color))
										] }),
										/* @__PURE__ */ f("h3", { children: l(Y(`wish${e.id}`)) }),
										/* @__PURE__ */ f("p", { children: l(Y(`wishDetail${e.id}`)) }),
										/* @__PURE__ */ f("p", { children: l(Y("wishRate"), {
											a: fe[e.id][0],
											b: fe[e.id][1]
										}) }),
										e.triggered && /* @__PURE__ */ f("small", { children: l(Y(a.pendingWishes?.includes(t) ? "wishPending" : "wishTriggered")) })
									]
								}, t))
							}),
							/* @__PURE__ */ f("p", { children: l(Y("catThreshold")) })
						]
					}),
					j === "logTitle" && /* @__PURE__ */ f("section", {
						className: "qa-panel qa-log",
						children: [...a.log].reverse().map((e, t) => /* @__PURE__ */ f("p", { children: l(Y(`log${e.key[0].toUpperCase()}${e.key.slice(1)}`), {
							name: T(e.rid),
							n: e.n ?? 0
						}) }, t))
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/queenalice/bot-strategy.ts
var vn = {
	red: R("red"),
	white: R("white")
}, yn = [
	"heart",
	"spade",
	"club",
	"diamond"
], bn = (e) => ({
	...e,
	stock: [...e.stock],
	hearts: { ...e.hearts },
	diamonds: {
		red: [...e.diamonds.red],
		white: [...e.diamonds.white]
	},
	cats: { ...e.cats },
	messengers: { ...e.messengers },
	twins: { ...e.twins },
	crowns: { ...e.crowns },
	advances: { ...e.advances },
	flowers: { ...e.flowers },
	books: { ...e.books },
	bookmarks: [...e.bookmarks],
	used: [...e.used],
	invited: [...e.invited],
	discard: [...e.discard]
}), xn = (e) => ({
	player: bn(e.player),
	hand: [...e.hand],
	board: {
		...e.board,
		alice: { ...e.board.alice },
		crownSpaces: {
			red: [...e.board.crownSpaces.red],
			white: [...e.board.crownSpaces.white]
		},
		wall: {
			red: [...e.board.wall.red],
			white: [...e.board.wall.white]
		}
	}
}), Sn = (e) => ({
	garden: "heart",
	wall: "diamond",
	tree: "club",
	messenger: "spade"
})[e];
function Cn(e, t, n, r) {
	return new wn({
		board: e,
		hand: t.hand,
		player: e.players.find((e) => e.rid === n)
	}, r).scores(t.choices);
}
var wn = class e {
	root;
	plan;
	horizon;
	moveCache = /* @__PURE__ */ new Map();
	actionCache = /* @__PURE__ */ new Map();
	paymentCache = /* @__PURE__ */ new Map();
	rootValue;
	constructor(e, t) {
		this.root = e, this.plan = t, this.horizon = e.board.finalRound ? .08 : Math.min(1, e.board.crowns / 3);
	}
	timeValue(e) {
		return (e.bookmarks.includes("score-time") ? 3 : 0) + (e.time <= 6 ? .85 : .65);
	}
	resourceValue(e, t, n) {
		let r = t === "cake" ? "red" : "white", i = t === "tea" || e.hearts[r] < 5 || e.diamonds[r].length < 5 || e.twins[r] !== 13 || e.messengers[r] !== 17;
		return Math.max(.35, (i ? t === "tea" ? 2.6 : 2.8 : 1.1) - n * .5);
	}
	material(e) {
		let t = Math.min(6, e.time) * .85 + Math.max(0, e.time - 6) * .65 + (e.bookmarks.includes("score-time") ? e.time * 3 : 0);
		for (let n of O) for (let r = 0; r < e.stock.filter((e) => e === n).length; r++) t += this.resourceValue(e, n, r);
		for (let n = 3; n < e.capacity; n++) t += (n === 3 ? 4 : n === 4 ? 3 : 1.5) * this.horizon;
		return e.bookmarks.includes("score-black") && (t += (e.capacity - 3) * 6), t;
	}
	wish(e, t, n) {
		let r = e.player, i = t % 4, a;
		if (t < 4) {
			let e = Object.values(r.flowers), t = Math.floor(e.reduce((e, t) => e + t, 0) / 3);
			for (; t > 0 && e.reduce((e, n) => e + Math.min(n, t), 0) < t * 3;) t--;
			a = [
				r.hearts.red + r.hearts.white,
				Math.min(r.hearts.red, r.hearts.white),
				e.reduce((e, t) => e + Math.floor(t / 2), 0),
				t
			][i];
		} else if (t < 8) {
			let e = vn.red[r.messengers.red].step, t = vn.white[r.messengers.white].step;
			a = [
				e + t,
				Math.min(e, t),
				Math.min(3, e) + Math.max(0, e - 7) + Math.min(3, t) + Math.max(0, t - 7),
				r.seals
			][i];
		} else if (t < 12) a = [
			P[r.twins.red].height + P[r.twins.white].height,
			Math.min(P[r.twins.red].height, P[r.twins.white].height),
			Math.min(20, r.booksTaken),
			Math.min(10, r.bookmarks.filter((e) => F.find((t) => t.id === e).kind !== "final").length)
		][i];
		else {
			let t = D.map((t) => e.board.wall[t].flatMap((e, t) => e === r.rid ? [t] : []));
			a = [
				r.diamonds.red.length + r.diamonds.white.length,
				Math.min(r.diamonds.red.length, r.diamonds.white.length),
				t.reduce((t, n, r) => t + n.filter((t) => Math.floor(t / 4) <= e.board.eggs[D[r]]).length, 0),
				t.reduce((e, t) => e + new Set(t.map((e) => e % 4)).size, 0)
			][i];
		}
		return a * fe[t][+!!n];
	}
	guests(e) {
		let t = e.player, n = [
			...e.hand,
			...t.discard,
			...t.invited
		];
		return t.invited.reduce((e, r) => {
			let i = N[r], a = i.color === "wild", o = i.piece === "king" || i.piece === "queen";
			return i.tier ? i.tier === 1 ? e + (o ? a ? 4 : 3 : 2) : i.tier === 2 ? e + (o ? a ? 6 : 5 : a ? 4 : 2 * t.invited.filter((e) => N[e].piece === i.piece && (N[e].color === i.color || N[e].color === "wild")).length) : i.piece === "king" ? e + n.filter((e) => N[e].tier > 0).length + t.deckCount * .4 : i.piece === "queen" ? e + t.invited.length : e + (a ? 6 : 2 * t.invited.filter((e) => N[e].piece === i.piece).length) : e + (o ? 2 : 1);
		}, 0);
	}
	bookmarkValue(e, t) {
		let n = F.find((e) => e.id === t), r = e.player;
		if (n.kind === "instant") return 0;
		if (n.kind === "permanent") return (n.discount ? 7 : n.event === "invite" || n.event === "acquire" ? 6 : 4) * this.horizon;
		let i = n.metric === "cat" ? r.cats[n.color] : n.metric === "invite" ? r.invited.filter((e) => N[e].color === n.color || N[e].color === "wild").length : n.metric === "alice" ? r.advances[n.color] : 0;
		if (n.metric === "black" || n.metric === "time") return 0;
		if (n.metric === "cards") {
			let t = [
				...e.hand,
				...r.discard,
				...r.invited
			].map((e) => N[e]);
			return 2 * Math.min(10, t.filter((e) => e.tier === 1 || e.tier === 2).length + r.deckCount * .3) + 4 * Math.min(5, t.filter((e) => e.tier === 3).length + r.deckCount * .1);
		}
		return Math.min(n.cap ?? Infinity, i) * (n.factor ?? 0);
	}
	utility(e) {
		if (e === this.root && this.rootValue !== void 0) return this.rootValue;
		let t = e.player, n = t.ip + this.material(t) + this.guests(e), r = {
			pink: [5, 5],
			blue: [8, 3],
			orange: [3, 4],
			yellow: [8, 2]
		};
		for (let e of [
			"pink",
			"blue",
			"orange",
			"yellow"
		]) n += r[e].slice(0, t.flowers[e]).reduce((e, t) => e + t, 0) * this.horizon;
		n += Object.entries(t.books).reduce((e, [t, n]) => e + n * (t === "blue" ? 2.8 : 2.2), 0) * this.horizon;
		for (let r of t.bookmarks) n += this.bookmarkValue(e, r);
		for (let r of D) {
			n += ([
				0,
				1.5,
				3.5,
				6,
				10,
				0
			][t.hearts[r]] + [
				0,
				1.5,
				3.5,
				6,
				10,
				0
			][t.diamonds[r].length]) * this.horizon, n += ([
				0,
				2,
				5,
				9,
				0
			][P[t.twins[r]].height] + (t.messengers[r] === 17 ? 0 : vn[r][t.messengers[r]].step * .85)) * this.horizon;
			let i = e.board.wishes.filter((e) => e.color === r).map((t) => this.wish(e, t.id, e.board.alice[r] > e.board.alice[j(r)])).sort((e, t) => t - e), a = t.cats[r], o = a >= 6 ? 1 : a / 6 * .65 * this.horizon, s = a >= 10 ? 1 : Math.max(0, a - 6) / 4 * .65 * this.horizon;
			n += (i[0] ?? 0) * o + (i[1] ?? 0) * s, n += Math.min(12, a) * .45 * this.horizon;
			for (let t of e.board.wishes.filter((e) => e.color === r && !e.triggered)) n += this.wish(e, t.id, !1) * .35 * this.horizon;
			let c = e.board.alice[r] - e.board.alice[j(r)];
			n += t.crowns[r] * (c > 0 ? 8 : c === 0 ? 6 : 2);
		}
		return e === this.root && (this.rootValue = n), n;
	}
	time(e, t) {
		e.player.ip += Math.max(0, e.player.time + t - 10), e.player.time = Math.min(10, e.player.time + t);
	}
	resource(e, t) {
		if (e.player.stock.length < e.player.capacity) e.player.stock.push(t);
		else {
			let n = this.material(e.player), r = -1;
			for (let i = 0; i < e.player.stock.length; i++) {
				let a = [...e.player.stock];
				a[i] = t;
				let o = this.material({
					...e.player,
					stock: a
				});
				o > n && (n = o, r = i);
			}
			r >= 0 && (e.player.stock[r] = t);
		}
	}
	event(e, t) {
		for (let n of e.player.bookmarks) {
			let r = F.find((e) => e.id === n);
			r.event === t && !e.player.used.includes(n) && (e.player.used.push(n), this.rewards(e, r.reward ?? []));
		}
	}
	rewards(e, t, n = 0) {
		for (let r of t) for (let t = 0; t < r.n; t++) {
			let t = e.player, i = r.color ?? e.board.activeColor ?? "red";
			if (r.type === "ip") t.ip++;
			else if (r.type === "time") this.time(e, 1);
			else if (r.type === "resource" || r.type === "black") {
				r.type === "black" && t.capacity < 8 && (t.capacity++, this.event(e, "black"));
				let n = [...r.resource && r.resource !== "any" ? [r.resource] : O].sort((e, n) => this.resourceValue(t, n, t.stock.filter((e) => e === n).length) - this.resourceValue(t, e, t.stock.filter((t) => t === e).length))[0];
				this.resource(e, n);
			} else if (r.type === "flower") t.flowers[r.flower]++;
			else if (r.type === "book") {
				let n = [...r.book === "white-green" ? ["white", "green"] : r.book === "green-blue" ? ["green", "blue"] : r.book === "any" || !r.book ? [
					"white",
					"green",
					"blue"
				] : [r.book]].sort((t, n) => this.bookNeed(e, n) - this.bookNeed(e, t))[0];
				t.books[n]++, t.booksTaken++;
			} else if (r.type === "cat") {
				let r = Math.min(12, t.cats[i] + 1);
				if (r === t.cats[i]) continue;
				t.cats[i] = r;
				let a = r === 1 ? [A("time")] : r === 3 ? [A("resource", 1, { resource: M(j(i)) })] : r === 5 ? [A("time", 2)] : r === 7 ? [A("resource", 1, { resource: "tea" })] : r === 9 ? [A("black", 1, { resource: "tea" })] : r === 11 ? [A("time", 3)] : r === 12 ? [A("alice", 1, { color: i }), A("ip", 3)] : [];
				this.rewards(e, a, n);
			} else if (r.type === "alice" || r.type === "crown") {
				let n = de(e.board.players.length > 2), a = z(e.board.players.length > 2);
				if (r.type === "crown") {
					let r = n.findIndex((t, n) => n > e.board.alice[i] && !a.includes(n) && !e.board.crownSpaces[i].includes(n));
					e.board.crowns > 0 && r >= 0 ? (t.crowns[i]++, e.board.crownSpaces[i].push(r), t.ip += n[r] * 2) : t.ip += 10, e.board.crowns = Math.max(0, e.board.crowns - 1);
				} else {
					let r = e.board.alice[i] + 1;
					for (; e.board.crownSpaces[i].includes(r);) r++;
					if (r >= n.length || r === n.length - 1 && e.board.alice[j(i)] === r) t.ip += 5;
					else if (e.board.alice[i] = r, t.ip += n[r], this.event(e, "alice"), a.includes(r)) {
						let n = e.board.wishes.find((e) => e.color === i && !e.triggered);
						n && (t.ip += this.wish(e, n.id, !1) * .65);
					}
				}
			} else r.type === "acquire" ? t.ip += this.acquireValue(e, r.tier ?? 1) : r.type === "invite" ? t.ip += Math.max(0, ...this.inviteOptions(e).map((t) => this.inviteValue(e, t))) : r.type === "cardReward" ? t.ip += Math.max(this.acquireValue(e, r.tier ?? 1), 0, ...this.inviteOptions(e).map((t) => this.inviteValue(e, t))) : r.type === "mini" && n < 1 ? t.ip += Math.max(0, ...D.map((t) => this.bestAction(e, r.suit, t, !0, [], n + 1))) : r.type === "capture" ? t.ip += Math.max(0, ...e.board.pieces.filter((e) => e.square >= 0 && e.color !== i && (r.n === 1 ? e.type === "pawn" : e.type !== "queen" && e.type !== "king")).map((e) => e.type === "pawn" ? .9 : 3)) / r.n : r.type === "extraDiscard" && (t.ip += .8 * this.horizon);
		}
	}
	bookNeed(e, t) {
		let n = 0;
		for (let r of e.board.bookmarks) {
			let i = F.find((e) => e.id === r);
			if (i.cost === "any2") continue;
			let a = i.cost.filter((t, n, r) => r.slice(0, n + 1).filter((e) => e === t).length > e.player.books[t]);
			a.includes(t) && (n = Math.max(n, (i.kind === "final" ? 6 + this.bookmarkValue(e, r) : 8 * this.horizon) / a.length));
		}
		return n - e.player.books[t] * .3;
	}
	discounts(e, t, n, r) {
		return [...r, ...e.player.bookmarks.flatMap((r) => {
			let i = F.find((e) => e.id === r);
			return i.suit === t && i.discount && !e.player.used.includes(r) ? [i.discount === "own" ? M(n) : i.discount] : [];
		})];
	}
	pay(e, t, n, r, i) {
		let a = this.discounts(e, n, r, i), o = JSON.stringify([
			e.player.stock,
			e.player.time,
			e.player.capacity,
			e.player.flowers.blue,
			e.player.bookmarks,
			t,
			a
		]);
		if (this.paymentCache.has(o)) {
			let t = this.paymentCache.get(o);
			return t ? {
				...e.player,
				stock: [...t.stock],
				time: t.time,
				capacity: t.capacity
			} : null;
		}
		let s = [...t].sort((e, t) => Number(e === "any") - Number(t === "any")), c = /* @__PURE__ */ new Map(), l = (e, t, n) => {
			if (t === s.length) return e;
			let r = `${t}/${[...e.stock].sort()}/${e.time}/${e.capacity}/${n}`;
			if (c.has(r)) return c.get(r);
			let i = s[t], a = [];
			for (let r of new Set(e.stock)) if (i === "any" || i === r) {
				let i = [...e.stock];
				i.splice(i.indexOf(r), 1), a.push(l({
					...e,
					stock: i
				}, t + 1, n));
			}
			for (let r of new Set(n)) if (r === "any" || i === "any" || i === r) {
				let i = [...n];
				i.splice(i.indexOf(r), 1), a.push(l(e, t + 1, i));
			}
			let o = e.flowers.blue ? 2 : 3;
			if (e.time >= o && a.push(l({
				...e,
				time: e.time - o
			}, t + 1, n)), e.capacity > 3) {
				if (e.stock.length < e.capacity) a.push(l({
					...e,
					capacity: e.capacity - 1
				}, t + 1, n));
				else for (let r of new Set(e.stock)) {
					let i = [...e.stock];
					i.splice(i.indexOf(r), 1), a.push(l({
						...e,
						stock: i,
						capacity: e.capacity - 1
					}, t + 1, n));
				}
			}
			if (e.flowers.blue >= 2 && e.stock.includes("tea") && e.time < 10) {
				let r = [...e.stock];
				r.splice(r.indexOf("tea"), 1), a.push(l({
					...e,
					stock: r,
					time: Math.min(10, e.time + 2)
				}, t, n));
			}
			let u = a.filter((e) => e !== null).sort((e, t) => this.material(t) - this.material(e))[0] ?? null;
			return c.set(r, u), u;
		}, u = l(e.player, 0, a);
		return this.paymentCache.set(o, u), u;
	}
	plans(e, t, n, r) {
		let i = e.player, a = e.board, o = M(n);
		if (t === "heart") return i.hearts[n] >= 5 ? [] : r ? [{
			kind: "garden",
			color: n,
			cost: [],
			mini: r
		}] : L(n, a.players.length).flatMap((e, t) => e.flatMap((e, r) => {
			let s = a.gardeners[n], c = s < 0 ? 0 : Math.min(Math.abs(s - t), 4 - Math.abs(s - t));
			return a.garden[n][t][r] ? [] : [{
				kind: "garden",
				color: n,
				target: t,
				index: r,
				cost: [...Array([
					1,
					2,
					2,
					2,
					3
				][i.hearts[n]]).fill(o), ...Array(c).fill("tea")]
			}];
		}));
		if (t === "diamond") return i.diamonds[n].length >= 5 ? [] : [
			0,
			1,
			2,
			3,
			4
		].filter((e) => !i.diamonds[n].includes(e)).flatMap((e) => r ? [{
			kind: "wall",
			color: n,
			cost: [],
			index: e,
			mini: r
		}] : [
			0,
			1,
			2,
			3
		].flatMap((t) => {
			let r = a.wall[n].findIndex((e, n) => !e && n % 4 === t && ue(n, a.players.length));
			return r < 0 ? [] : [{
				kind: "wall",
				color: n,
				index: e,
				target: r,
				cost: [...Array([
					1,
					2,
					2,
					3,
					4
				][Math.floor(r / 4)]).fill(o), ...Array(+(t >= 2)).fill("tea")]
			}];
		}));
		if (t === "club") return oe.filter((e) => e.from === i.twins[n] && (!r || e.tea)).map((e) => ({
			kind: "tree",
			color: n,
			target: e.to,
			cost: r ? [] : Array(e.cost).fill(e.tea ? "tea" : o),
			mini: r
		}));
		let s = (e, t, r) => t ? vn[n][e].next.flatMap((e) => s(e, t - 1, [...r, e])) : [r];
		return (r ? [1] : [
			1,
			2,
			3
		]).flatMap((e) => s(i.messengers[n], e, []).map((t) => ({
			kind: "messenger",
			color: n,
			path: t,
			target: t[t.length - 1],
			mini: r,
			cost: r ? [] : [...Array(e === 1 ? 1 : 2).fill(o), ...Array(+(e === 3)).fill("tea")]
		})));
	}
	actionValue(e, t, n, r = 0, i = this.utility(e)) {
		let a = t.color, o = this.pay(e, t.cost, Sn(t.kind), a, n);
		if (!o) return -Infinity;
		let s = xn(e);
		s.player = bn(o);
		let c = s.player, l = s.board, u = [];
		if (t.kind === "garden") {
			let e = c.hearts[a]++;
			u.push(...I(a)[e]), e === 2 && c.advances[a]++, t.mini || u.push(...L(a, l.players.length)[t.target][t.index]);
		} else if (t.kind === "wall") {
			c.diamonds[a].push(t.index), u.push(...se(a)[t.index]);
			let e = c.diamonds[a].length;
			e === 3 && (c.advances[a]++, u.push(A("alice", 1, { color: a }))), e === 4 && u.push(A("mini", 1, { suit: a === "red" ? "spade" : "heart" })), e === 5 && u.push(A("crown", 1, { color: a })), t.mini || (l.wall[a][t.target] = c.rid, u.push(...ce(a)[t.target]), Math.floor(t.target / 4) === l.eggs[a] && (c.ip += l.wall[a].every((e, t) => Math.floor(t / 4) !== l.eggs[a] || !ue(t, l.players.length) || !!e) ? 4 : 2));
		} else if (t.kind === "tree") {
			let e = P[c.twins[a]], n = P[t.target];
			c.twins[a] = n.id, e.height === 2 && n.height === 3 && (c.advances[a]++, u.push(A("alice", 1, { color: a }))), e.height < 4 && n.height === 4 && u.push(A("crown", 1, { color: a }));
			for (let e of n.books) u.push(A("book", 1, { book: e }));
			u.push(...l.treeBooks[n.id] ? [A("book", 1, { book: "white" })] : n.bonus), c.ip += 1.5 * this.horizon;
		} else {
			let e = vn[a][t.target];
			c.messengers[a] = e.id, u.push(...e.rewards);
			for (let e of t.path) {
				let t = vn[a][e];
				if (t.seal) {
					let e = !l.seals.includes(t.seal);
					c.seals++, t.seal.endsWith("outer") && (c.ip += e ? 6 : 3), t.seal.endsWith("center") && (c.advances[a]++, u.push(A("alice", 1, { color: a })), e && (c.ip += 4)), t.seal.endsWith("end") && u.push(A("cat", e ? 3 : 2, { color: a }));
				}
				t.mini && u.push(A("mini", 1, { suit: t.mini }));
			}
			u.push(A("cardReward", 1, { tier: e.tier }));
		}
		return this.rewards(s, u, r), this.utility(s) - i;
	}
	bestAction(e, t, n, r, i, a = 0, o = !1) {
		let s = JSON.stringify([
			e.player,
			e.hand,
			t,
			n,
			r,
			i,
			a,
			o,
			e.board.alice,
			e.board.wall
		]);
		if (this.actionCache.has(s)) return this.actionCache.get(s);
		let c = this.utility(e), l = Math.max(r ? 0 : -Infinity, ...this.plans(e, t, n, r).map((t) => this.actionValue(e, o ? {
			...t,
			cost: ["any", ...t.cost]
		} : t, i, a, c)));
		return this.actionCache.set(s, l), l;
	}
	cardDiscount(e, t = !1) {
		let n = e ? N[e] : null, r = !t && this.plan?.card === e ? this.plan.usedDiscounts : 0, i = t ? 0 : this.plan?.repeatDiscount ?? 0;
		return [...n ? Array(Math.max(0, n.discount - r)).fill(n.discountResource) : [], ...Array(i).fill("any")];
	}
	column(e, t, n, r, i, a = !1) {
		let o = t % 5, s = o === 2 || r ? yn : [[
			"heart",
			"spade",
			"heart",
			"club",
			"diamond"
		][o]], c = Math.max(...s.map((t) => this.bestAction(e, t, n, !1, i, 0, o === 2 && !e.player.flowers.pink && !a)));
		return Math.max(this.timeValue(e.player) * 2, c);
	}
	moveValue(e, t, n, r, i = !1, a = !1) {
		let o = xn(e), s = e.board.pieces.find((e) => e.square === n && e.id !== t.id), c = t.color;
		s && (this.time(o, 1), this.event(o, "capture"), s.type !== "pawn" && this.resource(o, M(j(s.color))), (s.type === "king" || s.type === "queen") && this.rewards(o, [A("cat", 1, { color: s.color })])), t.prison && this.event(o, "rescue");
		let l = Math.floor(n / 5), u = [
			"cake",
			"tea",
			"toast",
			"any",
			"any",
			"cake",
			"tea",
			"toast"
		][l];
		o.player.flowers.pink >= 2 && l >= 2 && l <= 5 && this.time(o, l === 3 || l === 4 ? 2 : 1);
		let d = n % 5 == 2 && !o.player.flowers.pink ? xn(o) : null;
		this.rewards(o, [A("resource", 1, { resource: u })]);
		let f = N[r], p = this.cardDiscount(r, a), m = this.column(o, n, c, f.piece === "king", p), h = this.utility(o) - this.utility(e) + m;
		if (d && (h = Math.max(h, this.utility(d) - this.utility(e) + this.column(d, n, c, f.piece === "king", p, !0))), !i && t.type === "pawn" && (c === "red" ? n < 5 : n >= 35)) {
			let e = xn(o);
			this.rewards(e, [A("cat", 1, { color: c })]), h += 3 + this.utility(e) - this.utility(o);
		}
		return h;
	}
	bestMove(e, t, n) {
		let r = JSON.stringify([
			t,
			n,
			e.player,
			e.hand
		]);
		if (this.moveCache.has(r)) return this.moveCache.get(r);
		let i = N[t], a = n ? [n] : i.color === "wild" ? D : [i.color], o = -Infinity;
		for (let n of a) for (let r of e.board.pieces.filter((e) => e.type === i.piece && e.color === n)) {
			let i;
			if (r.square < 0) {
				let t = Array.from({ length: 40 }, (e, t) => t).filter((t) => !e.board.pieces.some((e) => e.square === t)), r = t.filter((e) => n === "red" ? e >= 25 : e < 15);
				i = r.length ? r : t;
			} else i = tt(e.board, r), i.length || (i = [r.square]);
			for (let n of i) o = Math.max(o, this.moveValue(e, r, n, t, !1, !0));
		}
		let s = Number.isFinite(o) ? o : 0;
		return this.moveCache.set(r, s), s;
	}
	playValue(e, t) {
		let n = N[t];
		return Math.max(...(n.color === "wild" ? D : [n.color]).map((r) => {
			let i = xn(e);
			return i.board.activeColor = r, this.rewards(i, n.play.map((e) => e.type === "cat" && !e.color ? {
				...e,
				color: n.piece === "queen" ? j(r) : r
			} : e)), this.utility(i) - this.utility(e) + this.bestMove(i, t, r);
		}));
	}
	cardValue(e, t) {
		let n = N[t];
		return (n.tier * 1.1 + +(n.color === "wild") + n.discount * 2 + (n.piece === "bishop" ? n.tier : n.piece === "pawn" || n.piece === "king" ? 1.5 : 0)) * this.horizon + (e.player.bookmarks.includes("score-cards") ? n.tier === 3 ? 4 : n.tier ? 2 : 0 : 0);
	}
	acquireValue(e, t) {
		return Math.max(0, ...e.board.market[t - 1].flatMap((t, n) => t ? [this.cardValue(e, t) + 1.5 * this.horizon - (n === 1 ? this.timeValue(e.player) : n === 2 ? 2.5 : 0)] : []));
	}
	inviteOptions(e) {
		return e.hand.length + e.player.discard.length + e.player.deckCount <= 3 ? [] : [.../* @__PURE__ */ new Set([...e.hand, ...e.player.discard])].filter((t) => e.hand.length > 1 || !e.hand.includes(t));
	}
	inviteValue(e, t) {
		let n = xn(e), r = n.hand.indexOf(t);
		if (r >= 0) n.hand.splice(r, 1);
		else {
			let e = n.player.discard.indexOf(t);
			e >= 0 && n.player.discard.splice(e, 1);
		}
		return n.player.invited.push(t), this.event(n, "invite"), this.utility(n) - this.utility(e) + (N[t].tier === 0 ? 2.5 * this.horizon : -this.cardValue(e, t) * .6);
	}
	scores(t) {
		let n = this.root, r = n.player;
		return t.map((t) => {
			let i = xn(n);
			if (t.kind === "wish") return t.score;
			if (t.kind === "play") return this.playValue(n, t.card);
			if (t.kind === "discard" || t.kind === "extra-discard") return i.hand.splice(i.hand.indexOf(t.card), 1), i.player.discard.push(t.card), this.rewards(i, N[t.card].discard), this.utility(i) - this.utility(n) + (t.kind === "discard" ? Math.max(0, ...i.hand.map((e) => this.playValue(i, e))) : -this.cardValue(n, t.card) * .25);
			if (t.kind === "trim") return -this.cardValue(n, t.card) - this.bestMove(n, t.card) * .15;
			if (t.kind === "move") {
				if (n.board.prompt === "dinah-move") return i.board.pieces = n.board.pieces.map((e) => e.id === t.value ? {
					...e,
					square: t.square,
					prison: null
				} : e.square === t.square ? {
					...e,
					square: -1,
					prison: "queenalice-dinah"
				} : e), Math.max(0, ...n.hand.map((t) => new e(i).bestMove(i, t)));
				let r = n.board.pieces.find((e) => e.id === t.value);
				return this.moveValue(n, r, t.square, n.board.activeCard, n.board.prompt === "promote");
			}
			if (t.kind === "action") {
				let e = !1;
				if (n.board.prompt === "column") {
					let t = [...n.board.log].reverse().find((e) => (e.key === "move" || e.key === "rescue") && e.rid === r.rid);
					e = (this.plan?.square ?? (t?.n ?? 0) - 1) % 5 == 2 && !r.flowers.pink && !this.plan?.starPaid;
				}
				let i = n.board.prompt === "column" && n.board.pieces.some((e) => e.type === "pawn" && e.color === t.color && e.square === this.plan?.square && (e.color === "red" ? e.square < 5 : e.square >= 35));
				return this.bestAction(n, t.value, t.color, n.board.prompt === "mini", this.cardDiscount(n.board.activeCard), 0, e) + (i ? 4 : 0);
			}
			if ([
				"garden",
				"wall",
				"tree",
				"messenger"
			].includes(t.kind) || t.kind === "mini") {
				let e = t.kind === "mini" ? t.value === "heart" ? "garden" : "wall" : t.kind, r = {
					kind: e,
					color: t.color,
					cost: t.cost ?? [],
					target: t.target,
					index: e === "garden" ? t.n : t.kind === "mini" ? t.target : t.n,
					mini: t.kind === "mini" || !t.cost?.length,
					path: e === "messenger" ? t.id.slice(10).split("-").map(Number) : void 0
				};
				return this.actionValue(n, r, this.cardDiscount(n.board.activeCard));
			}
			if (t.kind === "color") {
				if (n.board.prompt === "play-color") {
					let e = N[n.board.activeCard];
					return i.board.activeColor = t.color, this.rewards(i, e.play.map((n) => n.type === "cat" && !n.color ? {
						...n,
						color: e.piece === "queen" ? j(t.color) : t.color
					} : n)), this.utility(i) - this.utility(n) + this.bestMove(i, e.id, t.color);
				}
				let e = n.board.prompt.slice(7);
				this.rewards(i, [A(e, 1, { color: t.color })]);
			} else if (t.kind === "reward") {
				let e = JSON.parse(t.value);
				return this.rewards(i, [e]), (e.type === "black" ? 30 : e.type === "resource" ? r.stock.length < r.capacity ? 20 : -5 : e.type === "acquire" ? 12 : e.type === "invite" ? -1 : 5) + (this.utility(i) - this.utility(n)) * .05;
			} else if (t.kind === "resource") {
				if (t.id === "pay-star") return 3.2;
				n.board.prompt === "reward-black" && i.player.capacity < 8 && (i.player.capacity++, this.event(i, "black")), this.resource(i, t.value);
			} else if (t.kind === "replace") {
				n.board.prompt === "reward-black" && i.player.capacity < 8 && (i.player.capacity++, this.event(i, "black"));
				let [e, r] = t.value.split(":");
				i.player.stock.splice(i.player.stock.indexOf(e), 1, r);
			} else if (t.kind === "book") {
				let e = t.value;
				return i.player.books[e]++, i.player.booksTaken++, this.utility(i) - this.utility(n) + this.bookNeed(n, e);
			} else if (t.kind === "pay-resource" || t.kind === "drop") i.player.stock.splice(i.player.stock.indexOf(t.value), 1);
			else if (t.kind === "pay-time") i.player.time -= t.n;
			else if (t.kind === "pay-black") {
				i.player.capacity--;
				let e = t.value.split(":")[1];
				e && i.player.stock.splice(i.player.stock.indexOf(e), 1);
			} else if (t.kind === "payment") {
				for (let e of t.payment ?? []) if (e.kind === "pay-resource" && i.player.stock.splice(i.player.stock.indexOf(e.value), 1), e.kind === "pay-time" && (i.player.time -= e.n), e.kind === "pay-black") {
					i.player.capacity--;
					let t = e.value?.split(":")[1];
					t && i.player.stock.splice(i.player.stock.indexOf(t), 1);
				}
			} else if (t.kind === "discount") return .3;
			else if (t.kind === "exchange") return i.player.stock.splice(i.player.stock.indexOf("tea"), 1), this.time(i, 2), this.utility(i) - this.utility(n) - .4;
			else if (t.kind === "capture") this.time(i, 1), this.event(i, "capture"), t.value !== "pawn" && this.resource(i, M(j(t.color)));
			else if (t.kind === "invite") return t.card ? this.inviteValue(n, t.card) : Math.max(0, ...this.inviteOptions(n).map((e) => this.inviteValue(n, e)));
			else if (t.kind === "acquire") {
				if (!t.card) return this.acquireValue(n, t.n ?? 1);
				let e = this.plan?.acquireTier ?? N[t.card].tier, a = t.n ?? 0;
				i.player.time = Math.min(10, r.time + e - N[t.card].tier - +(a === 1));
				let o = a === 2 ? this.pay(i, ["any"], n.board.activeSuit, n.board.activeColor ?? "red", this.cardDiscount(n.board.activeCard)) : i.player;
				return o ? (i.player = bn(o), i.hand.push(t.card), this.event(i, "acquire"), this.cardValue(n, t.card) + 1.5 * this.horizon + this.utility(i) - this.utility(n) - +(r.handCount > (r.flowers.yellow ? 5 : 3))) : -Infinity;
			} else if (t.kind === "bookmark") {
				let e = F.find((e) => e.id === t.value), n = e.cost === "any2" ? t.id.slice(`bookmark-${e.id}-`.length).split(":") : e.cost;
				for (let e of n) i.player.books[e]--;
				i.player.bookmarks.push(e.id), e.kind === "instant" && this.rewards(i, e.reward ?? []);
			} else if (t.kind === "repeat") {
				i.player.time -= t.n;
				let e = [...this.cardDiscount(n.board.activeCard), ...Array(+(r.flowers.orange >= 2)).fill("any")];
				return this.utility(i) - this.utility(n) + this.bestAction(i, t.value, t.color, !1, e);
			} else if (t.kind === "pass") return this.time(i, 2), this.utility(i) - this.utility(n);
			else if (t.kind === "rest" || t.kind === "skip") return 0;
			else if (t.kind === "train") return this.trainValue(n, t.target, t.color);
			else return t.score;
			return this.utility(i) - this.utility(n);
		});
	}
	trainValue(e, t, n) {
		let r = xn(e), i = r.player;
		return this.time(r, t === 9 ? 6 : t === 10 ? 5 : t >= 11 && t !== 13 && t !== 14 ? 4 : t === 13 ? 2 : t === 14 ? 0 : 3), this.resource(r, M(n)), t < 4 ? (i.flowers[[
			"pink",
			"blue",
			"orange",
			"yellow"
		][t]]++, i.hearts[n]++) : t < 8 ? (i.twins[n] = 1, i.bookmarks.push([
			"event-acquire",
			"event-capture",
			"event-invite",
			"event-black"
		][t - 4])) : t < 12 ? (i.diamonds[n].push([
			3,
			0,
			1,
			2
		][t - 8]), t === 8 && this.rewards(r, [A("black", 1, { resource: M(j(n)) })]), t === 10 && this.rewards(r, [A("cat", 1, { color: j(n) })]), t === 11 && (i.ip += this.acquireValue(e, 1))) : (i.messengers[n] = [
			2,
			2,
			1,
			4
		][t - 12], t < 15 ? i.ip += this.acquireValue(e, t - 11) : this.rewards(r, [A("black", 1, { resource: M(j(n)) })])), this.utility(r) - this.utility(e);
	}
}, Tn = (e, t) => {
	let n = e.private?.choices;
	if (!n?.length || e.public.actor !== t.rid) return null;
	let r = e.public.players.find((e) => e.rid === t.rid), i = t.memory, a = i?.round === e.public.round && i.card === e.public.activeCard && e.public.prompt !== "discard" ? { ...i } : {
		round: e.public.round,
		card: e.public.activeCard,
		usedDiscounts: 0,
		repeatDiscount: 0
	}, o = Cn(e.public, e.private, t.rid, a), s = n.map((e, t) => ({
		choice: e,
		score: o[t]
	})).sort((e, t) => t.score - e.score), c = s[0].score, l = s.filter((e) => e.score >= c - (t.difficulty === "weak" ? 3 : .05) && (![
		"pass",
		"skip",
		"rest"
	].includes(e.choice.kind) || e.score >= c)), u = JSON.stringify([
		t.rid,
		e.public.round,
		e.public.prompt,
		e.public.pieces,
		r.stock,
		r.time,
		e.private?.hand,
		n.map((e) => e.id)
	]), d = 2166136261;
	for (let e of u) d = Math.imul(d ^ e.charCodeAt(0), 16777619) >>> 0;
	let f = l[d % l.length].choice;
	f.kind === "play" && (a.card = f.card, a.usedDiscounts = 0), f.kind === "move" && (a.square = f.square, a.starPaid = !1), f.id === "pay-star" && (a.starPaid = !0), f.kind === "repeat" && (a.repeatDiscount = +(r.flowers.orange >= 2));
	let p = f.kind === "payment" ? (f.payment ?? []).filter((e) => e.kind === "discount") : f.kind === "discount" ? [f] : [];
	for (let e of p) e.id?.startsWith("discount-") && (a.repeatDiscount ? a.repeatDiscount-- : a.usedDiscounts = Math.min(N[a.card]?.discount ?? 0, a.usedDiscounts + 1));
	if (f.kind === "reward") {
		let e = JSON.parse(f.value);
		(e.type === "acquire" || e.type === "cardReward") && (a.acquireTier = e.tier ?? 1);
	}
	return f.id === "take-card" && (a.acquireTier = f.n), {
		action: {
			type: "choose",
			id: f.id
		},
		memory: a
	};
}, En = (e, t, n) => {
	if (e.type !== "choose") return "";
	let r = t.private?.choices.find((t) => t.id === e.id);
	return r ? n(Y(r.label), { n: r.n ?? 0 }) : "";
};
//#endregion
//#region src/games/queenalice/fx.tsx
function Dn(e, ...t) {
	for (let n of t) {
		let t = n ? e.anchor(n) : null;
		if (t && t.w > 0 && t.h > 0) return t;
	}
	return null;
}
function On({ token: e, n: t }) {
	let n = u();
	return /* @__PURE__ */ p("span", {
		className: "qa-fx-float",
		children: [
			/* @__PURE__ */ f(Z, { name: e }),
			t > 0 ? "+" : "−",
			Math.abs(t),
			" ",
			n(Y(e))
		]
	});
}
var kn = {
	card(e, t) {
		let n = e.data, r = e.secret, i = e.rid === t.myRid, a = r?.card ?? n.card, o = Dn(t, n.from.startsWith("qa-hand:") ? void 0 : n.from, i ? `qa-hand:${e.rid}` : `qa-seat:${e.rid}`, "qa-reward"), s = Dn(t, n.to) ? n.to : i ? `qa-hand:${e.rid}` : `qa-seat:${e.rid}`, c = Dn(t, s);
		return !o || !c ? null : {
			ms: t.queued ? 180 : K.card,
			hide: t.queued ? [] : [s],
			node: /* @__PURE__ */ f(y, {
				from: o,
				to: c,
				ms: t.queued ? 160 : 480,
				children: a ? /* @__PURE__ */ f("div", {
					className: "qa-fx-card",
					children: /* @__PURE__ */ f(Ut, {
						id: a,
						compact: !0,
						mode: "discard"
					})
				}) : /* @__PURE__ */ f("div", {
					className: "qa-fx-back",
					children: /* @__PURE__ */ f(Z, { name: "crown" })
				})
			})
		};
	},
	token(e, t) {
		let n = e.data, r = e.rid === t.myRid, i = n.token === "time" ? `qa-time:${e.rid}` : n.token === "black" ? `qa-black:${e.rid}` : `qa-stock:${e.rid}:${n.token}`, a = r && n.n > 0 && n.slot !== void 0 ? `qa-stock-slot:${e.rid}:${n.slot}` : void 0, o = Dn(t, a, r ? i : void 0, `qa-seat:${e.rid}`), s = Dn(t, n.from, "qa-reward", `qa-seat:${e.rid}`);
		if (!o || !s) return null;
		let c = n.n < 0 ? o : s, l = n.n < 0 ? s : o, u = {
			...l,
			x: l.x + (l.w - 32) / 2,
			y: l.y + (l.h - 32) / 2,
			w: 32,
			h: 32
		};
		return {
			ms: t.queued ? 220 : K.resource,
			hide: a && Dn(t, a) && !t.queued ? [a] : [],
			node: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(y, {
				from: c,
				to: u,
				ms: t.queued ? 140 : 360,
				children: /* @__PURE__ */ f("span", {
					className: "qa-fx-token",
					children: /* @__PURE__ */ f(Z, { name: n.token })
				})
			}), /* @__PURE__ */ f(v, {
				at: o,
				ms: t.queued ? 160 : 350,
				delay: t.queued ? 60 : 280,
				children: /* @__PURE__ */ f(On, {
					token: n.token,
					n: n.n
				})
			})] })
		};
	},
	piece(e, t) {
		let n = e.data, r = Dn(t, n.from), i = Dn(t, n.to);
		return !r || !i ? null : {
			ms: t.queued ? 200 : K.move,
			hide: t.queued ? [] : [`qa-piece:${n.pieceId}`],
			node: /* @__PURE__ */ f(y, {
				from: r,
				to: i,
				ms: t.queued ? 180 : 480,
				children: /* @__PURE__ */ f("div", {
					className: "qa-fx-piece",
					style: {
						width: r.w,
						height: r.h
					},
					children: /* @__PURE__ */ f(Bt, {
						type: n.piece,
						color: n.color
					})
				})
			})
		};
	},
	land(e, t) {
		let n = e.data, r = Dn(t, n.at, "qa-reward");
		return r ? {
			ms: K.move,
			node: /* @__PURE__ */ f(b, {
				at: r,
				ms: K.move
			})
		} : null;
	}
};
//#endregion
//#region src/games/queenalice/endgame-review.tsx
function An({ board: e, renderResult: t, ...n }) {
	let i = u(), [c, l] = s(!0), [d, m] = s(null), h = o(null), g = o(null), _ = o(null);
	r(() => {
		if (!d) return;
		_.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => m(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let v = (e) => {
		m(null), l(e), requestAnimationFrame(() => (e ? h : g).current?.focus({ preventScroll: !0 }));
	}, y = a(() => ({
		onPlayAgain: n.onPlayAgain && (() => m({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => m({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => m({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), b = {
		...n,
		...y
	};
	return /* @__PURE__ */ p("div", {
		className: "queenalice-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ f("div", {
				className: "queenalice-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ f("div", {
				className: "queenalice-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ p("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), v(!1));
					},
					className: "queenalice-endgame-panel",
					"aria-label": i("session.result.title"),
					children: [
						/* @__PURE__ */ p("header", {
							className: "queenalice-endgame-heading",
							children: [/* @__PURE__ */ p("div", {
								className: "queenalice-endgame-brand",
								children: [/* @__PURE__ */ f("span", {
									"aria-hidden": "true",
									children: Se.icon
								}), i(Se.nameKey)]
							}), /* @__PURE__ */ f("button", {
								type: "button",
								ref: h,
								className: "btn-quiet",
								"aria-label": i("games.queenalice.reviewHide"),
								title: i("games.queenalice.reviewHide"),
								onClick: () => v(!1),
								children: /* @__PURE__ */ f(S, { size: 19 })
							})]
						}),
						/* @__PURE__ */ f("div", {
							className: "queenalice-endgame-result",
							inert: d !== null,
							children: t(b)
						}),
						d && /* @__PURE__ */ p("div", {
							className: "queenalice-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || m(null);
							},
							children: [/* @__PURE__ */ f("button", {
								type: "button",
								ref: _,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									m(null), e();
								},
								children: i(d.label === "again" ? "games.queenalice.reviewConfirmAgain" : "games.queenalice.reviewConfirmLobby")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									m(null), h.current?.focus({ preventScroll: !0 });
								},
								children: i("games.queenalice.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "queenalice-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base",
					ref: g,
					onClick: () => v(!0),
					children: [
						/* @__PURE__ */ f(C, { size: 18 }),
						i("games.queenalice.reviewShow"),
						/* @__PURE__ */ f(x, { size: 18 })
					]
				})
			})
		]
	});
}
function jn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: c, renderRowExtra: m, summary: h, navigation: g, content: _, afterRanking: v, scoreUnit: y, rankOf: b }) {
	let x = u(), C = l((e) => e.locale), [T, E] = s({}), D = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? w(n, C) : e;
	}, O = (t, n) => b?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), ne = e.ranking.some((t) => e.scores?.[t] !== void 0), k = (t, n) => /* @__PURE__ */ p("div", {
		className: "queenalice-score-identity",
		children: [
			/* @__PURE__ */ p("span", {
				className: "queenalice-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ f("span", {
					"aria-label": x("games.queenalice.reviewWinner"),
					children: "♛ "
				}), ne && O(t, n)]
			}),
			/* @__PURE__ */ p("span", {
				className: "queenalice-score-name",
				children: [D(t), t === r && /* @__PURE__ */ f("small", { children: x("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ p("small", {
				className: "queenalice-score-autopilot",
				children: [
					/* @__PURE__ */ f(ee, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), A = (t) => e.ranking.map((n) => /* @__PURE__ */ f("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ p("div", {
		className: "queenalice-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ f(te, {}),
			g,
			/* @__PURE__ */ p("div", {
				className: "queenalice-score-body",
				children: [
					h && /* @__PURE__ */ f("div", {
						className: "queenalice-score-summary",
						children: h
					}),
					i !== void 0 && /* @__PURE__ */ f("p", {
						className: "queenalice-score-hints",
						children: x("session.hint.usedCount", { n: i })
					}),
					_ ?? (c?.length ? /* @__PURE__ */ f("div", {
						className: "queenalice-score-table-scroll",
						children: /* @__PURE__ */ p("table", {
							className: "queenalice-score-table",
							"aria-label": x(Se.nameKey),
							children: [
								/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { scope: "col" }), /* @__PURE__ */ f(d, { children: e.ranking.map((t, n) => /* @__PURE__ */ f("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: k(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ f("tbody", { children: c.map((e, t) => /* @__PURE__ */ p(n, { children: [/* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ p("button", {
										type: "button",
										"aria-expanded": !!T[t],
										onClick: () => E((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ f(S, { size: 15 }), e.label]
									}) : e.label
								}), A(e)] }), T[t] && e.details?.map((e, t) => /* @__PURE__ */ p("tr", {
									className: "queenalice-score-sub",
									children: [/* @__PURE__ */ f("th", {
										scope: "row",
										children: e.label
									}), A(e)]
								}, t))] }, t)) }),
								ne && /* @__PURE__ */ f("tfoot", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: x("games.queenalice.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ f("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ f("ol", {
						className: "queenalice-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ p("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ p("div", {
								className: "queenalice-score-rankline",
								children: [k(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ p("strong", {
									className: "queenalice-score-points",
									children: [e.scores[t], y && /* @__PURE__ */ f("small", { children: y })]
								})]
							}), m?.(t)]
						}, t))
					})),
					v,
					!!c?.length && m && /* @__PURE__ */ f("div", {
						className: "queenalice-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: D(e) }), m(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ p("footer", {
				className: "queenalice-score-actions",
				children: [
					o && /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: x("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: x("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ f("p", { children: x("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/queenalice/endgame-scores.tsx
function Mn(e) {
	let t = u(), n = e.public, r = e.result.ranking.includes("queenalice-dinah") ? [...e.members, {
		...e.members[0],
		rid: "queenalice-dinah",
		name: t(Y("dinah"))
	}] : e.members, i = [...new Set(n.players.flatMap((e) => e.final.map((e) => e.label)))].map((e) => ({
		label: t(Y(e.startsWith("wish-") ? `wish${e.slice(5)}` : {
			crowns: "finalCrowns",
			bookmarks: "finalBookmarks",
			dinah: "dinahBonus"
		}[e] ?? e)),
		value: (t) => n.players.find((e) => e.rid === t)?.final.find((t) => t.label === e)?.n ?? 0
	}));
	return /* @__PURE__ */ f(jn, {
		...e,
		renderRowExtra: void 0,
		members: r,
		rows: i
	});
}
//#endregion
//#region src/games/queenalice/game-over.tsx
function Nn(e) {
	return /* @__PURE__ */ f(Mn, { ...e });
}
function Pn(e) {
	return /* @__PURE__ */ f(An, {
		...e,
		board: /* @__PURE__ */ f(_n, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ f(Nn, { ...e })
	});
}
//#endregion
//#region src/games/queenalice/game-over-row.tsx
function Fn({ public: e, rid: t }) {
	let n = u(), r = e.players.find((e) => e.rid === t);
	return /* @__PURE__ */ f("div", {
		className: "qa-score-breakdown",
		children: r?.final.map((e, t) => /* @__PURE__ */ p("span", { children: [
			n(Y(e.label.startsWith("wish-") ? `wish${e.label.slice(5)}` : {
				crowns: "finalCrowns",
				bookmarks: "finalBookmarks",
				dinah: "dinahBonus"
			}[e.label] ?? e.label)),
			": ",
			/* @__PURE__ */ f("b", { children: e.n }),
			" "
		] }, t))
	});
}
//#endregion
//#region src/games/queenalice/options.tsx
function In({ value: e, onChange: t }) {
	let n = u(), r = Ee.safeParse(e), i = r.success ? r.data : Ee.parse(void 0);
	return /* @__PURE__ */ p("div", {
		className: "qa-options",
		children: [/* @__PURE__ */ f(E, {
			title: n(Y("difficulty")),
			children: [
				"easy",
				"normal",
				"hard",
				"expert"
			].map((e) => /* @__PURE__ */ f(T, {
				name: "queenalice-difficulty",
				value: e,
				checked: i.difficulty === e,
				label: n(Y(e)),
				onChange: () => t({ difficulty: e })
			}, e))
		}), /* @__PURE__ */ f("p", { children: n(Y("difficultyHelp")) })]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/queenalice/entry.tsx
var Ln = {
	definition: Pt,
	View: _n,
	bot: Tn,
	describe: En,
	fx: kn,
	OverView: Pn,
	RowView: Fn,
	Options: In,
	locales: {
		zh: {
			miniChooseDiamond: "移去任意一块尚在的同色个人方块，另领取该方块奖励。",
			startsFinalRound: "移去供给中的最后一冠，完成当前整轮后结算。",
			removesSupplyCrown: "从供给中移去一冠。",
			dinahDiamondOrder: "黛娜按本色已移去方块的数量领取下列奖励。",
			inviteFromHand: "来自手牌",
			inviteFromDiscard: "来自弃牌堆",
			marketFeeFree: "市场第1位：无位置费",
			marketFeeTime: "市场第2位：支付一时间",
			marketFeeResource: "市场第3位：支付任意一资源",
			marketUpgrade: "黄花改购更高等级：支付 {{n}} 时间",
			marketDowngrade: "黄花改购更低等级：获得 {{n}} 时间",
			marketHand: "购入后加入手牌",
			viewCard: "查看卡牌",
			cardDetails: "卡牌详情",
			guestFixed: "{{n}} 分",
			kingAnyAction: "落点可任选一种行动；星列费用照付。",
			wildColorHelp: "打出时选择红色或白色，移动该色同类棋子；该选择也决定本牌对应的反色奖励。",
			bookmarkTime: "立即获得两时间",
			bookmarkUsed: "本回合已用",
			bookmarkAvailable: "本回合可用",
			anyTwoBooks: "任意两本书",
			trackTaken: "已移去",
			trackNext: "下一颗",
			trackFuture: "未移去",
			trackAvailable: "可移去",
			diamondAnyOrder: "方块可以任选；数量奖励按本色已移去的总数领取。",
			diamondCount: "移去第 {{n}} 块时另得",
			extraDiscardHelp: "可额外弃置一张{{tier}}或更低等级的手牌，领取弃牌收益；也可跳过。",
			trimHelp: "手牌上限 {{limit}} 张，还需弃置 {{n}} 张；不领取弃牌收益。",
			inviteHelp: "还可邀请 {{n}} 张手牌或弃牌堆中的牌，永久移出牌组；牌组至少保留三张。",
			repeatHelp: "支付 {{n}} 时间后，再执行一次相同行动，仍需另付行动费用。",
			promotionReturn: "重新选择同色出生区落点，出生区全满时可选任意空格；再次领取行资源并执行列行动。",
			selectCapture: "选择相反颜色的可吃棋子",
			selectBook: "选择一本书的颜色",
			fullStorage: "库存已满：替换现有一资源，或跳过本次资源。",
			fullCapacity: "容量已达八格，不再增加；仍可领取附带资源。",
			miniHelp: "微行动免费；只执行该区域允许的微行动部分。",
			afterPayment: "付款后",
			paymentTarget: "本次行动",
			discountCardOrRepeat: "卡牌或重复行动减免",
			discountCard: "卡牌减免",
			discountRepeat: "橙花重复行动减免",
			discountBookmark: "书签减免：{{value}}",
			rescuePreview: "救援：{{value}}获得一时间；落在同色出生区可用格；出生区全满时可选任意空格。",
			captureTarget: "吃掉{{value}}，下列收益已包含吃子奖励。",
			promotionPreview: "兵抵达对侧底线后推进同色猫，再重新选择出生区落点并再次激活。",
			catAt: "本次到达 {{n}} 步",
			progressAt: "本次到达第 {{n}} 格",
			crownFallback: "无可用王冠或合法王冠格，改得十影响力。",
			wishPending: "本回合休整时计分",
			catCrossingHelp: "推进多步时领取经过的每一项奖励；十二步后不再推进。",
			noImmediateReward: "无即时额外奖励",
			promptBook: "选择书的颜色",
			promptCapture: "选择相反颜色的可吃棋子",
			promptPromote: "兵升变：选择出生区落点",
			aliceEndHelp: "越过轨道末端，或另一色爱丽丝占据末格时，本次推进改得五影响力，并从供给移去一冠。",
			heartRewardSource: "个人红心奖励",
			spaceRewardSource: "地点奖励",
			gardenerTeaSource: "茶费用于园丁移动；其余为红心费用。",
			passRestHelp: "随后休整。",
			orangeRepeatHelp: "两朵橙花：本次重复行动另减免一资源。",
			trainStart0: "移去同色第一颗红心，在同色花园的粉花位开局。",
			trainStart1: "移去同色第一颗红心，在同色花园的蓝花位开局。",
			trainStart2: "移去同色第一颗红心，在同色花园的橙花位开局。",
			trainStart3: "移去同色第一颗红心，在同色花园的黄花位开局。",
			trainStart4: "双子从同色节点1开局；永久书签：购牌后得两时间。",
			trainStart5: "双子从同色节点1开局；永久书签：吃子后得两时间。",
			trainStart6: "双子从同色节点1开局；永久书签：邀请后得两时间。",
			trainStart7: "双子从同色节点1开局；永久书签：解锁容量后得两时间。",
			trainStart8: "移去同色4号个人方块；同色蛋墙第8格已有己方砖。",
			trainStart9: "移去同色1号个人方块；同色蛋墙第1格已有己方砖。",
			trainStart10: "移去同色2号个人方块；同色蛋墙第3格已有己方砖。",
			trainStart11: "移去同色3号个人方块；同色蛋墙第7格已有己方砖。",
			trainStart12: "同色信使从第2步左侧开局。",
			trainStart13: "同色信使从第2步左侧开局。",
			trainStart14: "同色信使从第1步开局。",
			trainStart15: "同色信使从第3步左侧开局。",
			trainDinah: "另一张列车交给黛娜，使用与你所选相反的颜色。",
			progressDetails: "王冠与足迹",
			trackPosition: "第 {{n}} 格",
			aliceHere: "爱丽丝当前位置",
			crownPositions: "王冠占用格",
			crownHelp: "获得王冠时，将它放在同色爱丽丝前方首个无冠且非愿望的空格，立即获得该格双倍影响力；没有王冠或没有合法位置时获得十分。最后一冠移走后，完成当前整轮再结算。",
			crownFinalHelp: "终局时，领先颜色的每顶个人王冠再得八分；两色爱丽丝并列时，两色王冠都得八分。轨道上的王冠表示已占用的格子，个人王冠数量见下方。",
			catHelp: "每位玩家分别记录红、白猫的足迹。吃掉王或后、兵升变及部分奖励可推进对应颜色的猫；足迹用于终局结算同色愿望。",
			catSteps: "{{n}} 步",
			catNoWish: "终局尚不能结算此色愿望",
			catOneWish: "终局可选一个同色愿望计分",
			catTwoWishes: "终局两个同色愿望都计分",
			catNext: "再前进 {{n}} 步到达 {{step}} 步门槛",
			inspectSpaces: "查看地点",
			finishInspect: "结束查看",
			locationDetails: "地点详情",
			wishScoringHelp: "愿望格触发后，在本回合休整时为所有玩家按普通倍率计分。终局猫足迹达到六步可选一个同色愿望，达到十步则两个都计分。",
			wishPlatinumHelp: "终局领先颜色的愿望使用白金倍率；两色爱丽丝并列时均使用普通倍率。按下列条件数出数量，再乘以对应倍率。",
			wishDetail0: "每移去一个个人红心计一个，红白两色合计。",
			wishDetail1: "每一红心与一白心组成一对；同一红心不可重复配对。只计已移去的个人红心。",
			wishDetail2: "每两朵同种花组成一对；不同花色分别配对，同一朵花不可重复使用。",
			wishDetail3: "每三朵不同种类的花组成一组；同一朵花不可重复使用，尽可能组成更多组。",
			wishDetail4: "将红、白信使各自已前进的步数相加；起点为零步。",
			wishDetail5: "红、白信使各前进一步组成一对，取两色步数中较小的数。",
			wishDetail6: "只计算两色信使在铜色路段（第1至3步）与金色路段（第8步起）已经前进的步数，银色路段不计。",
			wishDetail7: "每次经过印章并获得印章奖励计一次；两色合计，不要求是首位到达者。",
			wishDetail8: "将红、白双子当前所在高度相加；起点为零。",
			wishDetail9: "红、白双子每各上升一层组成一对，取两色当前高度中较小的数。",
			wishDetail10: "累计每获得一本书计一个，已花掉的书也计入，最多二十本。",
			wishDetail11: "每个即时或永久书签计一个，最多十个；终局书签不计。",
			wishDetail12: "每移去一个个人方块计一个，红白两色合计。",
			wishDetail13: "每移去一个红色方块和一个白色方块组成一对，同一方块不可重复配对。",
			wishDetail14: "每块位于对应颜色蛋人当前高度或更低处的己方砖块计一个，两色合计。",
			wishDetail15: "每个放有至少一块己方砖块的列计一个，红白蛋墙分别计算后相加，最多八列。",
			boardDetails: "奖励与费用",
			boardCurrentOptions: "当前可选行动的完整收益",
			boardRows: "行资源",
			boardRow: "第 {{n}} 行",
			boardRowHelp: "棋子移动后，先领取落点行的一资源。行号从棋盘顶部向下计算；中央两行可任选一种资源。",
			boardColumns: "列行动与吃子",
			boardColumnHelp: "从左至右依次为花园、信使、星列、双子树、蛋墙。行动颜色与棋子相同；红色支付蛋糕，白色支付吐司。星列另付任意一资源，再任选行动；一朵粉花可免除星列费用。王可任选行动，星列费用照常支付。",
			boardCaptureHelp: "吃子获得一时间；吃掉非兵棋子再获一资源：白棋给蛋糕，红棋给吐司。吃掉王或后还推进被吃棋子颜色的猫一步。",
			boardAliceHelp: "推进爱丽丝时跳过已放置王冠的格子，领取到达格的影响力；到达愿望格时从供给移去一冠，并在本回合休整时为所有人结算相应愿望。",
			boardAlicePoints: "{{n}} 影响力",
			boardBaseCost: "下列为基础费用；当前行动的付款方案会计入可用减免、时间和黑方块。先付清费用，再领取奖励。",
			boardPaymentHelp: "每三时间可抵付一资源，拥有蓝花时改为两时间。交回一个已解锁黑方块也可抵付一资源；同一行动内每个方块限用一次。",
			boardHeartNumber: "第 {{n}} 个同色红心",
			boardGardenHelp: "移去个人板最低的同色红心，领取其奖励，再领取所选空花位的奖励。园丁从休息区进入免费；跨相邻区域每步另付一茶。微行动只免费移去红心，不在花园种植。",
			boardGardenerCost: "当前园丁到此区域的额外费用",
			boardMoveSteps: "前进 {{n}} 步",
			boardMessengerHelp: "沿箭头前进，只领取落点印刷奖励，再获得落点等级的卡牌奖励；经过的印章和微行动另行结算。微行动免费前进一步，其余奖励照常领取。",
			boardTreeHelp: "每次沿一条箭头移动。以下列出各节点的入向路径及基础费用；微行动只能沿黑色箭头免费移动。领取分开印刷的各本书；叠印颜色为任选一本。第二高度进入第三高度推进同色爱丽丝，抵达第四高度获得同色王冠，随后可购买一个书签。",
			boardTreeCovered: "白书仍在：除印刷书本外，本次领取额外白书；以下覆盖奖励需白书被取走后才可获得。",
			boardWallHelp: "放在所选列最低的可用空位；以下费用为所在行与列合计。除墙面奖励外，另领取所移去个人方块的奖励。微行动只免费移去个人方块，不放上蛋墙。",
			boardDiamondNumber: "个人方块 {{n}} 的揭示奖励",
			boardDiamondMilestones: "移去第三个同色方块推进爱丽丝；第四个给予微行动（红色给信使、白色给花园）；第五个给予同色王冠。",
			boardSpaces: "版图各位置",
			boardOccupied: "已占用：{{name}}",
			boardBlocked: "本局人数封锁此格",
			boardSealFirst: "经过印章：首位奖励仍可领取",
			boardSealLater: "经过印章：领取后续奖励",
			boardPassing: "经过此处分支",
			boardEggBonus: "蛋人当前行：建造得两影响力；填满该行改得四影响力，并将蛋人升一行。",
			boardIcons: "图标含义",
			flowerPermanent: "花朵能力永久保留；同类超过两朵不再增强。",
			flowerThreshold: "{{n}} 朵",
			flowerUnlocked: "已解锁",
			flowerLocked: "未解锁",
			flowerPinkOne: "在星列选择行动时，无需支付一资源。",
			flowerPinkTwo: "棋子落在中央四行时，额外获得时间：第 3、6 行一时间，第 4、5 行两时间。",
			flowerBlueOne: "支付费用时，每两时间可代替任意一资源。",
			flowerBlueTwo: "可将一茶换成两时间；有茶时可多次兑换。",
			flowerOrangeOne: "重复行动的时间费用由六降为五。",
			flowerOrangeTwo: "重复行动另减免任意一资源。",
			flowerYellowOne: "休整时的手牌上限由三提高至五。",
			flowerYellowTwo: "购牌时可改变等级：每升一级支付一时间，每降一级获得一时间；位置附加费用照常支付。",
			flowerDinah: "黛娜不使用玩家的花朵能力；每朵花在终局获得 {{n}} 分。",
			flowerDinahPoints: "终局花朵得分：{{n}} 分",
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "爱丽丝女王",
			desc: "穿越镜中世界，以棋子行进构筑牌组，种花、传信、攀树和筑墙，助爱丽丝加冕。",
			rules: "目标：争取最多影响力。\n· 所有玩家共用红、白棋子，都能操作两种颜色。\n\n准备：选择起始列车和颜色。\n· 从两张列车卡中选择一张及其颜色面，领取起始奖励。\n· 每人有十张基础牌，起始手牌三张，资源容量三格。\n· 每级市场提供两张陈列牌及牌堆顶。王冠供给为人数加四。\n· 单人对局加入黛娜，可选择四种难度。\n\n回合：弃牌、打牌、移动和行动。\n· 先弃置一张手牌，领取弃牌奖励；再打出另一张，领取打出奖励。\n· 移动与打出牌类型、颜色相符的棋子；通配牌可选择红色或白色。\n· 使用国际象棋走法；兵只前进一步，不使用双步、王车易位或将军限制。\n· 对应棋子无合法移动时，可以原地激活。\n· 可以救出任意监狱中的对应棋子，放在本色出生三行的空格。\n· 出生区没有空格时可放任意空格；监狱主人获得一点时间。\n· 吃子获得一点时间；吃掉非兵棋子，另得白棋对应的蛋糕或红棋对应的吐司。\n· 吃掉王或后，再推进被吃棋子颜色的猫一步。\n· 先领取落点行的资源，再执行所在列的行动；棋子颜色决定行动颜色。\n· 星列支付任意一份资源后选择行动；王牌可选择任意行动，仍须支付星列费用。\n· 可以把刚获得的资源直接用于星列费用；也可放弃行动，获得两点时间。\n· 兵抵达对面底线后推进本色猫一步，返回出生区，再激活一次行列。\n\n支付与奖励：\n· 红色行动支付蛋糕，白色行动支付吐司；部分费用另需茶。\n· 每 3 点时间可以代替任意 1 份资源。时间上限为 10 点，超出上限的每点时间转化为 1 点影响力。\n· 资源满时可替换已有资源；黑方块增加容量，最多解锁五格。\n· 交回一个已解锁黑方块可抵付一份资源；同一行动内每个方块只能使用一次。\n· 先付清费用，再领取奖励；多项奖励的次序由你选择，须在本次行动结清。\n\n♥ 花园：\n· 依次移去第一至第五枚红心时，分别支付 1 份、2 份、2 份、2 份、3 份蛋糕或吐司。每次移去位置最低的一枚同色红心。\n· 园丁跨相邻区域每步支付一份茶；从休息区进入任意区域免费。\n· 获得个人板揭示奖励，再占据该区域的空花位，获得覆盖奖励。\n· 区域满后，园丁回到休息区。\n· 微行动免费移去任意颜色的最低红心，只领取个人板奖励。\n\n♠ 信使：\n· 前进一、二、三步，分别支付一份资源、二份资源、二份资源加一份茶。\n· 获得落点奖励和卡牌奖励；卡牌奖励可获得对应等级的牌，或邀请一张牌。\n· 经过印章另得奖励，首位到达者奖励更多；进入金色路段推进爱丽丝。\n· 终点给予王冠；微行动使任意颜色信使免费前进一步。\n\n♣ 双子树：\n· 沿一条箭头移动；黄色路径支付对应蛋糕或吐司，黑色路径支付茶。\n· 领取落点印刷书本；多种颜色叠印表示任选其中一本，分开印刷则分别领取。\n· 首位到达者还领取实体白书，被白书覆盖的奖励此次不领取。\n· 可用书本购买一个书签；即时书签立即生效，永久书签每回合可用一次。\n· 从第二高度进入第三高度推进爱丽丝，抵达第四高度获得王冠。\n· 微行动使任意双子沿一条相邻黑色箭头免费移动，照常领奖和购买书签。\n\n♦ 蛋墙：\n· 放在所选列最低的可用空位；行费用依次为一、二、二、三、四份资源。\n· 从蛋人向外数第三、第四列另付一份茶；封锁格不参与放置或填满判断。\n· 移去任意同色个人方块，获得揭示奖励和墙面覆盖奖励。\n· 在蛋人当前高度建造时，获得 2 点影响力；如果此次建造填满该行，则改为获得 4 点影响力，并将蛋人向上移动一行。\n· 微行动免费移去任意颜色的个人方块，只领取个人板奖励。\n· 第三、第四、第五个同色红心或方块，分别给予爱丽丝推进、微行动、王冠。\n\n重复与休整：\n· 每回合可支付六点时间，重复一次同色同类行动，重新支付行动费用。\n· 重复时不再出牌、移动棋子、领取行资源或支付星列费用。\n· 休整时补牌或弃牌至手牌上限，牌库空时洗入弃牌。\n· 市场向左滑动补齐，永久书签恢复；本回合触发的愿望为所有人计分。\n\n花朵与卡牌：\n· 拥有一朵粉花时，免除星列费用。拥有两朵粉花时，如果棋子的落点位于中央四行，获得 1 点或 2 点时间。\n· 拥有一朵橙花时，重复行动的费用降为 5 点时间。拥有两朵橙花时，还会减免重复行动所需的 1 份资源。\n· 拥有一朵黄花时，手牌上限提高至 5 张。拥有两朵黄花时，还可以通过支付或获得时间，调整所购买卡牌的等级。\n· 拥有一朵蓝花时，每 2 点时间可以代替 1 份资源。拥有两朵蓝花时，还可以将 1 份茶换成 2 点时间。\n· 同类第三朵起不再增加能力。\n· 市场三个位置的附加费用依次为免费、一点时间、任意一份资源。\n· 获得的牌立即入手；邀请可从手牌或弃牌中选牌，移入宾客区。\n· 保留至少三张未邀请的牌；出牌前不能邀请掉最后一张手牌。\n\n爱丽丝、愿望与终局：\n· 推进爱丽丝时，跳过王冠格，并获得落点所示的影响力。到达愿望格时，从公共供应中移除 1 枚王冠。\n· 获得王冠时，将它放在同色爱丽丝前方的第一个空格；该格不能已有王冠，也不能是愿望格。获得该格所示数值两倍的影响力。\n· 公共供应中没有王冠，或没有合法的王冠放置位置时，改为获得 10 点影响力。最后一枚王冠从公共供应移除后，完成当前整轮。\n· 将领先颜色的愿望翻至白金面；每枚该颜色的王冠额外获得 8 点影响力。\n· 两种颜色的爱丽丝进度相同时，两种颜色的每枚王冠均获得 8 点影响力，愿望不翻面。\n· 每色猫达到第六步可选一个同色愿望计分，达到第十步则两个都计分。\n· 加上宾客和终局书签分；黛娜另按难度结算书签套组、花朵和未邀请牌。\n· 影响力最高者获胜，同分共享胜利。",
			round: "第 {{n}} 轮",
			supply: "王冠余量",
			finalRound: "最后一轮",
			waiting: "等待 {{name}}",
			you: "你",
			dinah: "黛娜",
			score: "影响力",
			resources: "资源",
			time: "时间",
			capacity: "容量",
			hand: "手牌",
			discardPile: "弃牌",
			invited: "宾客",
			deck: "牌库",
			red: "红色",
			white: "白色",
			wild: "通配",
			cake: "蛋糕",
			tea: "茶",
			toast: "吐司",
			any: "任意",
			pawn: "兵",
			knight: "马",
			bishop: "象",
			rook: "车",
			queen: "后",
			king: "王",
			tier0: "基础",
			tier1: "铜牌",
			tier2: "银牌",
			tier3: "金牌",
			heart: "花园",
			spade: "信使",
			club: "双子树",
			diamond: "蛋墙",
			board: "棋盘",
			market: "卡牌市场",
			court: "个人板",
			books: "书籍",
			bookmarks: "书签",
			wishes: "愿望",
			logTitle: "近期记录",
			pink: "粉花",
			blue: "蓝花",
			orange: "橙花",
			yellow: "黄花",
			playEffect: "打出",
			discardEffect: "弃牌",
			invitedEffect: "宾客得分",
			empty: "无",
			free: "免费",
			cost: "费用",
			paidPosition: "位置附加费用",
			trainTitle: "选择列车与颜色",
			train: "选择列车",
			train0: "粉花与花园起步",
			train1: "蓝花与花园起步",
			train2: "橙花与花园起步",
			train3: "黄花与花园起步",
			train4: "双子起步 · 购牌书签",
			train5: "双子起步 · 吃子书签",
			train6: "双子起步 · 邀请书签",
			train7: "双子起步 · 容量书签",
			train8: "蛋墙起步 · 解锁容量",
			train9: "蛋墙起步 · 六时间",
			train10: "蛋墙起步 · 猫足迹",
			train11: "蛋墙起步 · 铜牌",
			train12: "信使两步 · 铜牌",
			train13: "信使两步 · 银牌",
			train14: "信使一步 · 金牌",
			train15: "信使三步 · 解锁容量",
			skip: "跳过",
			claim: "领取奖励",
			gain: "获得资源",
			replace: "替换资源",
			color: "选择颜色",
			book: "选择书籍",
			capture: "吃子",
			rescue: "救援",
			move: "移动",
			action: "执行行动",
			pass: "放弃行动，获得两时间",
			pay: "支付资源",
			payTime: "以 {{n}} 时间抵付",
			payBlack: "交回一容量抵付",
			discount: "使用减免",
			drop: "弃去资源",
			mini: "执行微行动",
			removeDiamond: "移去个人方块",
			plant: "种植",
			build: "筑墙",
			climb: "攀树",
			advance: "前进 {{n}} 步",
			acquire: "购买",
			takeCard: "购买 {{n}} 级卡牌",
			invite: "邀请",
			extraDiscard: "额外弃牌",
			bookmark: "购买书签",
			repeat: "重复行动 · {{n}} 时间",
			rest: "休整",
			scoreWish: "计分 · {{n}}",
			exchangeTea: "一茶换两时间",
			chooseSquare: "选择棋子，再点亮起的目的格",
			square: "第 {{n}} 格",
			noDecision: "正在结算",
			allPieces: "全部棋子",
			promptTrain: "选择起始列车与颜色",
			promptDiscard: "弃一张牌，获得奖励",
			promptPlay: "打出一张牌",
			promptRewards: "选择奖励领取次序",
			promptResource: "选择资源及存放方式",
			promptColor: "选择奖励颜色",
			promptMove: "移动或救援对应棋子",
			promptColumn: "选择行动",
			promptPay: "支付行动费用",
			promptAction: "选择行动位置",
			promptMini: "选择微行动颜色",
			promptAcquire: "选择购买的卡牌",
			promptInvite: "选择要邀请的卡牌",
			promptBookmark: "可购买一个书签",
			promptRepeat: "可重复一次行动",
			promptTrim: "弃牌至手牌上限",
			promptFinalWish: "选择终局愿望",
			easy: "简单",
			normal: "普通",
			hard: "困难",
			expert: "极难",
			difficulty: "黛娜难度",
			difficultyHelp: "仅单人对局使用。黛娜依专用牌组自动行动。",
			gardener: "园丁",
			resting: "休息区",
			region: "区域 {{n}}",
			egg: "蛋的高度",
			treeHeight: "第 {{n}} 层",
			messengerStep: "第 {{n}} 步",
			cats: "猫足迹",
			crowns: "王冠",
			advances: "爱丽丝推进",
			unlocked: "额外容量",
			instant: "即时",
			permanent: "每回合一次",
			final: "终局",
			"event-black": "解锁容量后得两时间",
			"event-acquire": "购买卡牌后得两时间",
			"event-invite": "邀请后得两时间",
			"event-capture": "吃子后得两时间",
			"event-rescue": "救援后得两时间",
			"event-alice": "推进爱丽丝后得三时间",
			"discount-heart-own": "花园减免一蛋糕／吐司",
			"discount-spade-own": "信使减免一蛋糕／吐司",
			"discount-diamond-own": "蛋墙减免一蛋糕／吐司",
			"discount-heart-tea": "花园减免一茶",
			"discount-spade-tea": "信使减免一茶",
			"discount-diamond-tea": "蛋墙减免一茶",
			"cat-red": "红猫两步",
			"cat-white": "白猫两步",
			"mini-heart": "花园微行动",
			"mini-diamond": "蛋墙微行动",
			"score-cat-red": "每红猫足迹两分（最多十步）",
			"score-cat-white": "每白猫足迹两分（最多十步）",
			"score-invite-red": "每红色或通配宾客两分（合计最多十张）",
			"score-invite-white": "每白色或通配宾客两分（合计最多十张）",
			"score-cards": "铜银牌每张两分（合计最多十张）；金牌每张四分（最多五张）",
			"score-black": "每额外容量六分",
			"score-time": "每剩余时间三分",
			"score-alice-red": "每红爱丽丝推进八分（最多四次）",
			"score-alice-white": "每白爱丽丝推进八分（最多四次）",
			wish0: "移去的红心",
			wish1: "红白红心配对",
			wish2: "同种花配对",
			wish3: "三种不同花成组",
			wish4: "信使总步数",
			wish5: "红白信使步数配对",
			wish6: "铜金区域的信使步数",
			wish7: "途经的印章",
			wish8: "双子总高度",
			wish9: "红白双子高度配对",
			wish10: "累计获得的书（最多二十）",
			wish11: "即时及永久书签（最多十）",
			wish12: "移去的方块",
			wish13: "红白方块配对",
			wish14: "不高于蛋的砖块",
			wish15: "筑过砖的不同列",
			wishRate: "普通 ×{{a}} · 白金 ×{{b}}",
			wishTriggered: "已计分",
			catThreshold: "×1：六步 · ×2：十步",
			during: "局中得分",
			guests: "邀请宾客",
			finalBookmarks: "终局书签",
			finalCrowns: "加冕王冠",
			finalWishes: "猫的愿望",
			dinahBonus: "黛娜额外得分",
			errTurn: "现在还未轮到你作出选择。",
			errChoice: "该选择已不可用，请选择当前可用的选项。",
			logMove: "{{name}} 移动棋子至第 {{n}} 格",
			logCapture: "{{name}} 吃子",
			logRescue: "{{name}} 救援棋子至第 {{n}} 格",
			logPlant: "{{name}} 种植花朵",
			logBuild: "{{name}} 筑墙",
			logClimb: "{{name}} 攀至第 {{n}} 层",
			logAdvance: "{{name}} 信使到达第 {{n}} 步",
			logAlice: "{{name}} 推进爱丽丝至第 {{n}} 格",
			logCrown: "{{name}} 获得王冠",
			logAcquire: "{{name}} 购买卡牌",
			logInvite: "{{name}} 邀请宾客",
			logBookmark: "{{name}} 购买书签",
			logWish: "{{name}} 愿望得 {{n}} 分",
			ruleSource: "规则依据：官方 TTS 模组英文草案；采用首局棋子阵形。",
			play: "打出",
			discard: "弃牌",
			"extra-discard": "额外弃牌",
			trim: "弃牌",
			ip: "影响力",
			resource: "资源",
			black: "额外容量",
			cat: "猫足迹",
			alice: "爱丽丝推进",
			crown: "王冠",
			flower: "花朵",
			guest0normal: "1 分",
			guest0wild: "1 分",
			guest0king: "2 分",
			guest0queen: "2 分",
			guest1normal: "2 分",
			guest1wild: "2 分",
			guest1king: "同色 3 分；通配 4 分",
			guest1queen: "同色 3 分；通配 4 分",
			guest2normal: "每个同色同类宾客 2 分（含本牌和同类通配宾客）",
			guest2wild: "4 分",
			guest2king: "同色 5 分；通配 6 分",
			guest2queen: "同色 5 分；通配 6 分",
			guest3normal: "每个同类宾客 2 分（含本牌）",
			guest3wild: "6 分",
			guest3king: "每张获得的铜银金牌 1 分（含宾客）",
			guest3queen: "每位宾客 1 分（含本牌）",
			payStar: "用此资源支付星列费用",
			promptPlayColor: "选择打出牌的棋子颜色",
			dinahMove: "选择黛娜吃掉的棋子",
			promptDinahMove: "同价值吃子：替黛娜选择目标",
			cardReward: "购牌或邀请",
			"book-white": "白书",
			"book-green": "绿书",
			"book-blue": "蓝书",
			"book-any": "任意书",
			"book-white-green": "白书或绿书",
			"book-green-blue": "绿书或蓝书",
			anyResource: "任意资源",
			rewardCapturePawn: "可吃1个相反颜色的兵",
			rewardCapturePiece: "可吃1个相反颜色的兵、马、象或车",
			rewardAcquire: "可购买{{n}}张{{tier}}",
			rewardInvite: "可邀请{{n}}张牌",
			rewardBlack: "解锁{{n}}个储位，获得{{resource}}",
			rewardMini: "可执行{{n}}次{{suit}}微行动",
			rewardExtra: "可额外弃置1张{{tier}}或更低等级的牌",
			rewardCard: "可购买{{tier}}或邀请1张牌",
			movePiece: "移动{{piece}}",
			playAndMove: "打出并移动{{piece}}",
			noDiscardReward: "弃置不获得收益",
			receive: "获得",
			thenAction: "随后：{{action}}",
			selectOnBoard: "点选版图上的可用位置",
			selectMarket: "点选市场中的卡牌",
			selectMove: "点选棋子，再点选落点",
			confirmPayment: "按此方案支付",
			otherPayments: "其他支付方式",
			paymentPlans: "完整支付方案",
			paymentCube: "归还1个储位方块",
			paymentDiscount: "减免{{n}}份资源",
			fromCard: "{{card}}的收益",
			storeResource: "{{resource}}×1 入库",
			replaceResource: "{{old}} → {{resource}}",
			starCost: "星列费用：1份资源",
			remainingRewards: "待处理收益",
			cardInHand: "共{{n}}张可用"
		},
		en: {
			miniChooseDiamond: "Remove any remaining personal diamond of this colour and gain its printed benefit.",
			startsFinalRound: "Remove the last supply Crown. Finish the current round, then score.",
			removesSupplyCrown: "Remove one Crown from the supply.",
			dinahDiamondOrder: "Dinah gains these benefits by the number of diamonds removed in this colour.",
			inviteFromHand: "From hand",
			inviteFromDiscard: "From discard",
			marketFeeFree: "Market slot 1: no position fee",
			marketFeeTime: "Market slot 2: pay one Time",
			marketFeeResource: "Market slot 3: pay any one resource",
			marketUpgrade: "Yellow-flower upgrade: pay {{n}} Time",
			marketDowngrade: "Yellow-flower downgrade: gain {{n}} Time",
			marketHand: "Add the acquired card to your hand",
			viewCard: "View card",
			cardDetails: "Card details",
			guestFixed: "{{n}} IP",
			kingAnyAction: "Choose any action at the destination; the star fee still applies.",
			wildColorHelp: "Choose red or white when played. Move a matching piece of that colour; this also determines opposite-colour benefits on this card.",
			bookmarkTime: "Gain two Time immediately",
			bookmarkUsed: "Used this turn",
			bookmarkAvailable: "Available this turn",
			anyTwoBooks: "Any two books",
			trackTaken: "Removed",
			trackNext: "Next",
			trackFuture: "Remaining",
			trackAvailable: "Available",
			diamondAnyOrder: "Choose any diamond. Count bonuses depend on the total removed in this colour.",
			diamondCount: "Extra for diamond {{n}}",
			extraDiscardHelp: "You may discard one {{tier}} or lower card from your hand for its discard benefit, or skip.",
			trimHelp: "Hand limit: {{limit}}. Discard {{n}} more, without discard benefits.",
			inviteHelp: "Invite up to {{n}} more cards from hand or discard. They leave your deck permanently; keep at least three cards in your deck.",
			repeatHelp: "Pay {{n}} Time to repeat the same action once. Pay its action cost separately.",
			promotionReturn: "Choose the matching birth area, or any empty space if it is full. Gain the row resource and activate the column again.",
			selectCapture: "Select an eligible opposite-colour piece to capture",
			selectBook: "Choose a book colour",
			fullStorage: "Storage is full: replace one stored resource, or skip this gain.",
			fullCapacity: "Capacity is already eight. Gain the accompanying resource without adding capacity.",
			miniHelp: "Mini-actions are free; only the region’s mini-action portion applies.",
			afterPayment: "After payment",
			paymentTarget: "This action",
			discountCardOrRepeat: "Card or repeat discount",
			discountCard: "Card discount",
			discountRepeat: "Orange-flower repeat discount",
			discountBookmark: "Bookmark discount: {{value}}",
			rescuePreview: "Rescue: {{value}} gains one Time. Use the matching birth area, or any empty space if that area is full.",
			captureTarget: "Capture {{value}}. The benefits below include the capture reward.",
			promotionPreview: "Reaching the far edge advances the matching cat, then returns the pawn to its birth area to activate again.",
			catAt: "Reaches step {{n}}",
			progressAt: "Reaches space {{n}}",
			crownFallback: "No Crown or legal Crown space: gain ten Influence instead.",
			wishPending: "Scores at this turn’s rest",
			catCrossingHelp: "A multi-step advance collects every reward passed. Pawprints stop at twelve.",
			noImmediateReward: "No immediate extra benefit",
			promptBook: "Choose a book colour",
			promptCapture: "Choose an opposite-colour piece to capture",
			promptPromote: "Promotion: choose a birth-area space",
			aliceEndHelp: "Advancing beyond the end, or into an end space held by the other Alice, gives five Influence instead and removes one Crown from the supply.",
			heartRewardSource: "Personal heart benefit",
			spaceRewardSource: "Space benefit",
			gardenerTeaSource: "Tea pays for gardener movement; the remaining cost removes the heart.",
			passRestHelp: "Then rest.",
			orangeRepeatHelp: "Two orange flowers: discount one resource on this repeated action.",
			trainStart0: "Remove the first matching heart; start on the matching pink-flower space.",
			trainStart1: "Remove the first matching heart; start on the matching blue-flower space.",
			trainStart2: "Remove the first matching heart; start on the matching orange-flower space.",
			trainStart3: "Remove the first matching heart; start on the matching yellow-flower space.",
			trainStart4: "Start the matching Twin at node 1. Permanent Bookmark: gain two Time after acquiring.",
			trainStart5: "Start the matching Twin at node 1. Permanent Bookmark: gain two Time after capturing.",
			trainStart6: "Start the matching Twin at node 1. Permanent Bookmark: gain two Time after inviting.",
			trainStart7: "Start the matching Twin at node 1. Permanent Bookmark: gain two Time after unlocking storage.",
			trainStart8: "Remove personal diamond 4; start with a brick in matching wall space 8.",
			trainStart9: "Remove personal diamond 1; start with a brick in matching wall space 1.",
			trainStart10: "Remove personal diamond 2; start with a brick in matching wall space 3.",
			trainStart11: "Remove personal diamond 3; start with a brick in matching wall space 7.",
			trainStart12: "Start the matching messenger on step 2, left branch.",
			trainStart13: "Start the matching messenger on step 2, left branch.",
			trainStart14: "Start the matching messenger on step 1.",
			trainStart15: "Start the matching messenger on step 3, left branch.",
			trainDinah: "Dinah takes the other Train in the opposite colour.",
			progressDetails: "Crowns & pawprints",
			trackPosition: "Space {{n}}",
			aliceHere: "Alice is here",
			crownPositions: "Spaces occupied by crowns",
			crownHelp: "Place an earned crown on the first empty non-wish space ahead of Alice of that colour and immediately gain twice its printed influence. Gain 10 influence if no crown or legal space remains. Finish the current round after the last crown is removed.",
			crownFinalHelp: "At game end, each personal crown of the leading colour scores 8 more influence. If both Alices tie, crowns of both colours score 8 each. Crowns on the tracks mark occupied spaces; your personal crown totals are below.",
			catHelp: "Each player tracks red and white pawprints separately. Capturing a king or queen, promoting a pawn and certain rewards advance the corresponding cat. Pawprints unlock wishes of that colour at game end.",
			catSteps: "{{n}} steps",
			catNoWish: "No wish of this colour unlocked yet",
			catOneWish: "Score one wish of this colour at game end",
			catTwoWishes: "Score both wishes of this colour at game end",
			catNext: "{{n}} more steps to the {{step}}-step threshold",
			inspectSpaces: "Inspect spaces",
			finishInspect: "Finish inspecting",
			locationDetails: "Space details",
			wishScoringHelp: "When a wish space is triggered, all players score that wish at its normal rate during rest this turn. At game end, 6 pawprints unlock one wish of that colour; 10 unlock both.",
			wishPlatinumHelp: "Wishes of the leading Alice colour use the platinum rate at game end. If both Alices tie, use normal rates for both colours. Count the units below, then multiply by the applicable rate.",
			wishDetail0: "Count each heart removed from your personal board, combining red and white.",
			wishDetail1: "Pair one removed red heart with one removed white heart. Each heart can belong to only one pair.",
			wishDetail2: "Count pairs of flowers of the same type, separately for each type. Each flower can be used once.",
			wishDetail3: "Make as many sets of three different flower types as possible. Each flower can be used once.",
			wishDetail4: "Add the steps advanced by your red and white messengers. The start is step zero.",
			wishDetail5: "Pair each red messenger step with one white messenger step: use the smaller of the two step totals.",
			wishDetail6: "Count steps advanced in the bronze section (steps 1–3) and gold section (step 8 onward) for both messengers. Ignore the silver section.",
			wishDetail7: "Count each seal reward you have received by passing a seal, across both colours. You need not be the first visitor.",
			wishDetail8: "Add the current heights of your red and white twins. The start has height zero.",
			wishDetail9: "Pair each level of the red twin with one level of the white twin: use the smaller current height.",
			wishDetail10: "Count all books gained during the game, including spent books, up to 20.",
			wishDetail11: "Count your instant and permanent bookmarks, up to 10. Exclude final-scoring bookmarks.",
			wishDetail12: "Count all diamonds removed from your personal board, combining red and white.",
			wishDetail13: "Pair one removed red diamond with one removed white diamond. Each diamond can belong to only one pair.",
			wishDetail14: "Count your bricks at or below the current egg height on their respective wall, combining both colours.",
			wishDetail15: "Count columns containing at least one of your bricks. Count the two walls separately and add them, up to 8 columns.",
			boardDetails: "Rewards & costs",
			boardCurrentOptions: "Full rewards for available actions",
			boardRows: "Row resources",
			boardRow: "Row {{n}}",
			boardRowHelp: "After moving, gain one resource from the destination row. Rows are numbered from the top; either central row grants any one resource.",
			boardColumns: "Column actions & captures",
			boardColumnHelp: "Left to right: Garden, Messengers, Wild, Twins Tree, Wall. Use the piece’s colour: red pays Cake, white pays Toast. The Wild column costs one extra resource of any type, then permits any action; one Pink Flower waives this cost. A King may choose any action but still pays the Wild column cost.",
			boardCaptureHelp: "Capturing grants one Time. A non-Pawn also grants one resource: Cake for a white piece, Toast for red. A King or Queen also advances the Cat of the captured colour once.",
			boardAliceHelp: "Alice skips spaces with placed Crowns and grants the Influence printed on her destination. Reaching a Wish space removes one Crown from the supply and scores that Wish for everyone during this turn’s Rest.",
			boardAlicePoints: "{{n}} Influence",
			boardBaseCost: "These are base costs. Current payment plans account for available discounts, Time and Black Cubes. Pay all costs before gaining rewards.",
			boardPaymentHelp: "Three Time replaces one resource; a Blue Flower reduces this to two Time. Returning an unlocked Black Cube also replaces one resource; each cube may be used once per action.",
			boardHeartNumber: "Matching Heart {{n}}",
			boardGardenHelp: "Remove your lowest matching Heart and gain its reward, then the reward of the chosen empty flower space. Entering from Rest is free; each adjacent zone crossed costs one extra Tea. A mini-action removes a Heart for free without planting in the Garden.",
			boardGardenerCost: "Extra cost from the Gardener’s current zone",
			boardMoveSteps: "Advance {{n}} spaces",
			boardMessengerHelp: "Follow the arrows. Gain only the destination’s printed reward, plus a Card Reward of its tier. Crossed Seals and mini-actions grant additional rewards. A mini-action advances one space for free, with all normal rewards.",
			boardTreeHelp: "Follow one arrow per action. Each node lists incoming paths and their base costs. A mini-action follows only a black arrow for free. Separate printed Books are all gained; overlapping colours mean choose one Book. Moving from height two to three advances matching Alice; reaching height four grants a matching Crown. You may then buy one Bookmark.",
			boardTreeCovered: "The White Book remains: gain the extra Book this visit. The covered reward below becomes available after that Book is taken.",
			boardWallHelp: "Build in the lowest available empty space of your chosen column. Listed costs combine row and column. Gain the removed personal Diamond’s reward as well as the Wall reward. A mini-action removes a personal Diamond for free without building on the Wall.",
			boardDiamondNumber: "Personal Diamond {{n}} reward",
			boardDiamondMilestones: "Your third matching Diamond advances Alice; the fourth grants a mini-action (red: Messengers, white: Garden); the fifth grants a matching Crown.",
			boardSpaces: "Board spaces",
			boardOccupied: "Occupied by {{name}}",
			boardBlocked: "Blocked at this player count",
			boardSealFirst: "Cross this Seal: first-player reward remains",
			boardSealLater: "Cross this Seal: subsequent-player reward",
			boardPassing: "Cross this branch",
			boardEggBonus: "Current Egg row: gain two Influence for building here. Completing the row grants four instead and moves the Egg up one row.",
			boardIcons: "Icon meanings",
			flowerPermanent: "Flower abilities are permanent. Further flowers beyond two of a type add no ability.",
			flowerThreshold: "Flowers: {{n}}",
			flowerUnlocked: "Unlocked",
			flowerLocked: "Locked",
			flowerPinkOne: "Choose an action in the star column without paying one resource.",
			flowerPinkTwo: "Landing in the central four ranks grants extra Time: one in ranks 3 and 6, two in ranks 4 and 5.",
			flowerBlueOne: "When paying costs, two Time may replace any one resource.",
			flowerBlueTwo: "Exchange one Tea for two Time. Repeat while you have Tea.",
			flowerOrangeOne: "The Time cost to repeat an action drops from six to five.",
			flowerOrangeTwo: "The repeated action also receives a discount of any one resource.",
			flowerYellowOne: "Your hand limit at rest increases from three to five.",
			flowerYellowTwo: "When acquiring a card, change its tier: pay one Time per tier up or gain one per tier down. Pay position surcharges as usual.",
			flowerDinah: "Dinah does not use player flower abilities. Each flower scores {{n}} IP at game end.",
			flowerDinahPoints: "Final flower score: {{n}} IP",
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Queen Alice",
			desc: "Build your deck through chess movement, plant flowers, deliver messages, climb the tree and build the wall to crown Alice.",
			rules: "Goal: Earn the most Influence Points (IP).\n· All players share the red and white chess pieces and may use either colour.\n\nSetup: Choose a starting Train and colour.\n· Choose one of two Train cards and its colour, then receive its starting benefits.\n· Each player has ten basic cards, three cards in hand and three resource spaces.\n· Each market tier offers two display cards and its deck top. Crown supply equals player count plus four.\n· Solo play adds Dinah with a choice of four difficulty levels.\n\nTurn: Discard, play, move and act.\n· Discard one hand card for its discard benefit, then play another for its play benefit.\n· Move a piece matching the played card’s type and colour. Wild cards allow either colour.\n· Use chess movement with one-step pawns, no castling and no check restrictions.\n· A matching piece with no legal move may activate its current square.\n· You may rescue a matching piece from any prison into an empty square in its home three ranks.\n· If its home ranks are full, use any empty square. The prison owner gains one Time.\n· Captures grant one Time. A captured non-pawn also grants Cake for white or Toast for red.\n· Capturing a King or Queen also advances the cat of the captured colour one step.\n· Gain the landing rank’s resource, then perform its column action in the moved piece’s colour.\n· Pay any one resource in the star column to choose a suit. Kings may choose any suit but still pay the star fee.\n· A newly gained resource may directly pay the star fee. You may decline the action for two Time.\n· A pawn reaching the opposite edge advances its cat, returns home and activates another square.\n\nCosts and benefits:\n· Red actions cost Cake and white actions cost Toast. Some costs also require Tea.\n· Three Time may replace any one resource. Time is capped at ten; each excess Time becomes one IP.\n· When storage is full you may replace a stored resource. Black cubes unlock up to five extra spaces.\n· Return an unlocked black cube to provide one resource. Each cube may be used once per action.\n· Pay costs before receiving benefits. Choose the order of multiple benefits and resolve them within the action.\n\n♥ Garden:\n· Pay 1, 2, 2, 2 and 3 Cake or Toast for your first through fifth hearts respectively and remove your lowest matching heart.\n· Moving the shared gardener between adjacent regions costs one Tea per step. Entry from rest is free.\n· Gain the revealed personal benefit and cover a free space in that region for its reward.\n· A filled region sends the gardener to rest.\n· The mini-action removes either colour’s lowest heart for free and grants only its personal benefit.\n\n♠ Messengers:\n· To advance 1 step, pay 1 resource. To advance 2 steps, pay 2 resources. To advance 3 steps, pay 2 resources and 1 Tea.\n· Gain the landing benefit and a card reward: acquire from the indicated tier or invite one card.\n· Crossed seals grant extra benefits, larger for the first visitor. Entering the Gold section advances Alice.\n· The end grants a Crown. The mini-action advances either messenger one step for free.\n\n♣ Twins’ Tree:\n· Follow one arrow. Yellow paths cost matching Cake or Toast; black paths cost Tea.\n· Gain the books printed at your destination. If several colours overlap in one book icon, choose one of those colours. If the book icons are separate, gain one book for each icon.\n· The first visitor also takes the physical white book and does not receive the benefit it covered.\n· You may buy one Bookmark with books. Immediate benefits apply now; permanent benefits refresh each turn.\n· Moving from height two to three advances Alice. Reaching height four grants a Crown.\n· The mini-action moves either Twin for free along an adjacent black arrow, with benefits and Bookmark purchase as usual.\n\n♦ Wall:\n· Build in the lowest available space of a column. The first through fifth rows cost 1, 2, 2, 3 and 4 matching resources respectively.\n· The third and fourth columns counted outwards from the egg cost one extra Tea. Blocked spaces are ignored.\n· Remove any matching personal diamond and gain its revealed benefit and the covered wall reward.\n· Building at the egg’s height scores two IP. Completing that row instead scores four IP and raises the egg.\n· The mini-action removes a personal diamond of either colour for free and grants only its personal benefit.\n· The third, fourth and fifth matching hearts or diamonds grant Alice progress, a mini-action and a Crown.\n\nRepeat and rest:\n· Once per turn, pay six Time to repeat the same colour and suit, paying its action costs again.\n· Repetition does not play a card, move a piece, grant a rank resource or repay the star fee.\n· Rest by drawing or discarding to your hand limit, shuffling discards when the deck is empty.\n· Slide and refill the market, refresh permanent Bookmarks and score triggered Wishes for all players.\n\nFlowers and cards:\n· One pink flower removes the star fee. Two grant one or two Time when landing in the central four ranks.\n· One orange flower reduces repetition to five Time. Two also discount one resource from the repeated action.\n· One yellow flower raises the hand limit to five. Two allow changing acquisition tiers by paying or gaining Time.\n· One blue flower reduces resource substitution to two Time. Two allow exchanging one Tea for two Time.\n· Further flowers of a type do not improve these abilities.\n· Market position surcharges are free, one Time and any one resource.\n· Acquired cards enter your hand immediately. Invite a card from hand or discard into the guest area.\n· Keep at least three non-invited cards and do not invite away your last hand card before the mandatory play.\n\nAlice, Wishes and final scoring:\n· Alice skips Crown spaces and scores printed IP. Reaching a Wish removes one Crown from supply.\n· Place an earned Crown in the first empty non-Wish space ahead of matching Alice for double its printed IP.\n· Gain ten IP if no Crown or valid space remains. Finish the current round after the last Crown leaves supply.\n· Turn the leading colour’s Wishes platinum and score eight IP per Crown of that colour.\n· If Alice is tied, all Crowns score eight IP and no Wishes turn platinum.\n· Each cat reaching step six scores one matching Wish of your choice. Reaching step ten scores both.\n· Add guest and final Bookmark points. Dinah uses her difficulty’s Bookmark sets, flowers and acquired-card bonuses.\n· Highest Influence wins. Tied players share victory.",
			round: "Round {{n}}",
			supply: "Crowns left",
			finalRound: "Final round",
			waiting: "Waiting for {{name}}",
			you: "You",
			dinah: "Dinah",
			score: "Influence",
			resources: "Resources",
			time: "Time",
			capacity: "Storage",
			hand: "Hand",
			discardPile: "Discard",
			invited: "Guests",
			deck: "Deck",
			red: "Red",
			white: "White",
			wild: "Wild",
			cake: "Cake",
			tea: "Tea",
			toast: "Toast",
			any: "Any",
			pawn: "Pawn",
			knight: "Knight",
			bishop: "Bishop",
			rook: "Rook",
			queen: "Queen",
			king: "King",
			tier0: "Basic",
			tier1: "Bronze",
			tier2: "Silver",
			tier3: "Gold",
			heart: "Garden",
			spade: "Messengers",
			club: "Twins’ Tree",
			diamond: "Wall",
			board: "Chessboard",
			market: "Card market",
			court: "Courtier",
			books: "Books",
			bookmarks: "Bookmarks",
			wishes: "Wishes",
			logTitle: "Recent events",
			pink: "Pink flower",
			blue: "Blue flower",
			orange: "Orange flower",
			yellow: "Yellow flower",
			playEffect: "Play",
			discardEffect: "Discard",
			invitedEffect: "Guest score",
			empty: "None",
			free: "Free",
			cost: "Cost",
			paidPosition: "Position surcharge",
			trainTitle: "Choose a Train and colour",
			train: "Choose Train",
			train0: "Pink flower · Garden start",
			train1: "Blue flower · Garden start",
			train2: "Orange flower · Garden start",
			train3: "Yellow flower · Garden start",
			train4: "Twins start · Acquisition Bookmark",
			train5: "Twins start · Capture Bookmark",
			train6: "Twins start · Invitation Bookmark",
			train7: "Twins start · Storage Bookmark",
			train8: "Wall start · Extra storage",
			train9: "Wall start · Six Time",
			train10: "Wall start · Pawprint",
			train11: "Wall start · Bronze card",
			train12: "Messenger two steps · Bronze",
			train13: "Messenger two steps · Silver",
			train14: "Messenger one step · Gold",
			train15: "Messenger three steps · Extra storage",
			skip: "Skip",
			claim: "Claim benefit",
			gain: "Gain resource",
			replace: "Replace resource",
			color: "Choose colour",
			book: "Choose book",
			capture: "Capture",
			rescue: "Rescue",
			move: "Move",
			action: "Perform action",
			pass: "Decline for two Time",
			pay: "Pay resource",
			payTime: "Pay {{n}} Time instead",
			payBlack: "Return one storage cube",
			discount: "Use discount",
			drop: "Discard resource",
			mini: "Perform mini-action",
			removeDiamond: "Remove personal diamond",
			plant: "Plant",
			build: "Build",
			climb: "Climb",
			advance: "Advance {{n}} steps",
			acquire: "Acquire",
			takeCard: "Acquire a tier {{n}} card",
			invite: "Invite",
			extraDiscard: "Extra discard",
			bookmark: "Buy Bookmark",
			repeat: "Repeat · {{n}} Time",
			rest: "Rest",
			scoreWish: "Score · {{n}}",
			exchangeTea: "Exchange one Tea for two Time",
			chooseSquare: "Select a piece, then a highlighted destination",
			square: "Square {{n}}",
			noDecision: "Resolving",
			allPieces: "All pieces",
			promptTrain: "Choose your starting Train and colour",
			promptDiscard: "Discard a card for its benefit",
			promptPlay: "Play a card",
			promptRewards: "Choose the order of your benefits",
			promptResource: "Choose resource and storage",
			promptColor: "Choose benefit colour",
			promptMove: "Move or rescue a matching piece",
			promptColumn: "Choose an action",
			promptPay: "Pay the action cost",
			promptAction: "Choose an action space",
			promptMini: "Choose a mini-action colour",
			promptAcquire: "Choose a card to acquire",
			promptInvite: "Choose a card to invite",
			promptBookmark: "You may buy one Bookmark",
			promptRepeat: "You may repeat the action once",
			promptTrim: "Discard to your hand limit",
			promptFinalWish: "Choose a final Wish",
			easy: "Easy",
			normal: "Normal",
			hard: "Difficult",
			expert: "Very difficult",
			difficulty: "Dinah difficulty",
			difficultyHelp: "Used in solo play only. Dinah acts automatically using her own deck.",
			gardener: "Gardener",
			resting: "Rest area",
			region: "Region {{n}}",
			egg: "Egg height",
			treeHeight: "Height {{n}}",
			messengerStep: "Step {{n}}",
			cats: "Pawprints",
			crowns: "Crowns",
			advances: "Alice advances",
			unlocked: "Extra storage",
			instant: "Immediate",
			permanent: "Once per turn",
			final: "Final scoring",
			"event-black": "Two Time after unlocking storage",
			"event-acquire": "Two Time after acquiring a card",
			"event-invite": "Two Time after inviting",
			"event-capture": "Two Time after capturing",
			"event-rescue": "Two Time after rescuing",
			"event-alice": "Three Time after advancing Alice",
			"discount-heart-own": "Garden: discount one Cake/Toast",
			"discount-spade-own": "Messengers: discount one Cake/Toast",
			"discount-diamond-own": "Wall: discount one Cake/Toast",
			"discount-heart-tea": "Garden: discount one Tea",
			"discount-spade-tea": "Messengers: discount one Tea",
			"discount-diamond-tea": "Wall: discount one Tea",
			"cat-red": "Two red pawprints",
			"cat-white": "Two white pawprints",
			"mini-heart": "Hearts mini-action",
			"mini-diamond": "Diamonds mini-action",
			"score-cat-red": "Two IP per red pawprint (max 10)",
			"score-cat-white": "Two IP per white pawprint (max 10)",
			"score-invite-red": "Two IP per red or wild guest (10 combined max)",
			"score-invite-white": "Two IP per white or wild guest (10 combined max)",
			"score-cards": "2 IP per Bronze/Silver (10 combined max); 4 per Gold (5 max)",
			"score-black": "Six IP per extra storage",
			"score-time": "Three IP per remaining Time",
			"score-alice-red": "Eight IP per red Alice advance (max 4)",
			"score-alice-white": "Eight IP per white Alice advance (max 4)",
			wish0: "Removed hearts",
			wish1: "Red/white heart pairs",
			wish2: "Pairs of identical flowers",
			wish3: "Sets of three different flowers",
			wish4: "Total messenger steps",
			wish5: "Red/white messenger step pairs",
			wish6: "Messenger steps in Bronze/Gold",
			wish7: "Crossed seals",
			wish8: "Total Twin heights",
			wish9: "Red/white Twin height pairs",
			wish10: "Books gained (max 20)",
			wish11: "Immediate/permanent Bookmarks (max 10)",
			wish12: "Removed diamonds",
			wish13: "Red/white diamond pairs",
			wish14: "Bricks at or below the egg",
			wish15: "Different columns built in",
			wishRate: "Yellow ×{{a}} · Platinum ×{{b}}",
			wishTriggered: "Scored",
			catThreshold: "×1: six steps · ×2: ten steps",
			during: "During play",
			guests: "Invited guests",
			finalBookmarks: "Final Bookmarks",
			finalCrowns: "Coronation Crowns",
			finalWishes: "Cat Wishes",
			dinahBonus: "Dinah bonus",
			errTurn: "It is not your decision yet.",
			errChoice: "That choice is no longer available. Select a current option.",
			logMove: "{{name}} moved to square {{n}}",
			logCapture: "{{name}} captured a piece",
			logRescue: "{{name}} rescued to square {{n}}",
			logPlant: "{{name}} planted in the garden",
			logBuild: "{{name}} built a brick",
			logClimb: "{{name}} reached height {{n}}",
			logAdvance: "{{name}} reached messenger step {{n}}",
			logAlice: "{{name}} advanced Alice to space {{n}}",
			logCrown: "{{name}} gained a Crown",
			logAcquire: "{{name}} acquired a card",
			logInvite: "{{name}} invited a guest",
			logBookmark: "{{name}} bought a Bookmark",
			logWish: "{{name}} scored {{n}} IP from a Wish",
			ruleSource: "Based on the official TTS English draft, using the first-game chess formation.",
			play: "Play",
			discard: "Discard",
			"extra-discard": "Extra discard",
			trim: "Discard",
			ip: "Influence",
			resource: "Resource",
			black: "Extra storage",
			cat: "Pawprints",
			alice: "Alice advance",
			crown: "Crown",
			flower: "Flower",
			guest0normal: "1 IP",
			guest0wild: "1 IP",
			guest0king: "2 IP",
			guest0queen: "2 IP",
			guest1normal: "2 IP",
			guest1wild: "2 IP",
			guest1king: "3 IP coloured; 4 IP wild",
			guest1queen: "3 IP coloured; 4 IP wild",
			guest2normal: "2 IP per matching colour/type guest (including this and matching wild guests)",
			guest2wild: "4 IP",
			guest2king: "5 IP coloured; 6 IP wild",
			guest2queen: "5 IP coloured; 6 IP wild",
			guest3normal: "2 IP per matching type guest (including this)",
			guest3wild: "6 IP",
			guest3king: "1 IP per acquired card, including guests",
			guest3queen: "1 IP per guest (including this)",
			payStar: "Use this resource for the star fee",
			promptPlayColor: "Choose the played piece’s colour",
			dinahMove: "Choose Dinah’s capture",
			promptDinahMove: "Choose Dinah’s equal-value capture",
			cardReward: "Acquire or invite",
			"book-white": "White book",
			"book-green": "Green book",
			"book-blue": "Blue book",
			"book-any": "Any book",
			"book-white-green": "White or green book",
			"book-green-blue": "Green or blue book",
			anyResource: "Any resource",
			rewardCapturePawn: "May capture 1 opposite-colour pawn",
			rewardCapturePiece: "May capture 1 opposite-colour pawn, knight, bishop or rook",
			rewardAcquire: "May acquire {{n}} {{tier}} card(s)",
			rewardInvite: "May invite {{n}} card(s)",
			rewardBlack: "{{n}} storage + {{resource}}",
			rewardMini: "{{n}} {{suit}} mini-action(s)",
			rewardExtra: "May discard 1 card of {{tier}} tier or below",
			rewardCard: "Acquire {{tier}} or invite",
			movePiece: "Move {{piece}}",
			playAndMove: "Play & move {{piece}}",
			noDiscardReward: "No discard benefit",
			receive: "Benefits",
			thenAction: "Then: {{action}}",
			selectOnBoard: "Select a highlighted space",
			selectMarket: "Select a market card",
			selectMove: "Select a piece, then its destination",
			confirmPayment: "Pay this way",
			otherPayments: "Other payment methods",
			paymentPlans: "Full payment plans",
			paymentCube: "Return 1 storage cube",
			paymentDiscount: "Discount {{n}} resource(s)",
			fromCard: "{{card}} · Benefits",
			storeResource: "Store {{resource}} ×1",
			replaceResource: "{{old}} → {{resource}}",
			starCost: "Star fee: 1 resource",
			remainingRewards: "Benefits remaining",
			cardInHand: "{{n}} available"
		}
	}
};
//#endregion
export { Ln as default };
