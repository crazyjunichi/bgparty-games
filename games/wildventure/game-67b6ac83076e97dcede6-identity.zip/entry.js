import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { AVATARS as n } from "@bgparty/sdk/avatars";
import { useEffect as r, useLayoutEffect as i, useRef as a, useState as o } from "react";
import { useT as s } from "@bgparty/sdk/i18n";
import { IconClose as c, IconPile as l, IconRecenter as u, IconZoomIn as d, IconZoomOut as f } from "@bgparty/sdk/icons";
import { Texture as ee } from "@bgparty/sdk/texture";
import { DeltaNumber as p } from "@bgparty/sdk/fx/delta-number";
import { useFxAnchor as m, useFxAnchorsMaybe as h } from "@bgparty/sdk/fx/anchors";
import { GameScreen as te } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as ne } from "@bgparty/sdk/ui/log-sheet";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { FlySprite as y } from "@bgparty/sdk/fx/primitives";
import { OptionCheckbox as b, OptionRadio as x, OptionSection as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/wildventure/cards.ts
var C = {
	400: {
		id: 400,
		species: "frog",
		kind: "gear",
		cost: 5,
		supplies: 5,
		free: !1,
		group: "core",
		name: "games.wildventure.c400Name",
		text: "games.wildventure.c400Text"
	},
	401: {
		id: 401,
		species: "rabbit",
		kind: "villager",
		cost: 4,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c401Name",
		text: "games.wildventure.c401Text"
	},
	402: {
		id: 402,
		species: "rabbit",
		kind: "villager",
		cost: 8,
		supplies: 4,
		free: !1,
		group: "academy",
		name: "games.wildventure.c402Name",
		text: "games.wildventure.c402Text"
	},
	403: {
		id: 403,
		species: "rabbit",
		kind: "villager",
		cost: 7,
		supplies: 2,
		free: !0,
		group: "tidings",
		name: "games.wildventure.c403Name",
		text: "games.wildventure.c403Text"
	},
	404: {
		id: 404,
		species: "rabbit",
		kind: "villager",
		cost: 6,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c404Name",
		text: "games.wildventure.c404Text"
	},
	405: {
		id: 405,
		species: "crow",
		kind: "villager",
		cost: 1,
		supplies: 3,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c405Name",
		text: "games.wildventure.c405Text"
	},
	406: {
		id: 406,
		species: "frog",
		kind: "villager",
		cost: 4,
		supplies: 2,
		free: !0,
		group: "tidings",
		name: "games.wildventure.c406Name",
		text: "games.wildventure.c406Text"
	},
	407: {
		id: 407,
		species: "frog",
		kind: "villager",
		cost: 6,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c407Name",
		text: "games.wildventure.c407Text"
	},
	408: {
		id: 408,
		species: "frog",
		kind: "villager",
		cost: 0,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c408Name",
		text: "games.wildventure.c408Text"
	},
	409: {
		id: 409,
		species: "frog",
		kind: "villager",
		cost: 7,
		supplies: 2,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c409Name",
		text: "games.wildventure.c409Text"
	},
	410: {
		id: 410,
		species: "frog",
		kind: "villager",
		cost: 2,
		supplies: 2,
		free: !0,
		group: "core",
		name: "games.wildventure.c410Name",
		text: "games.wildventure.c410Text"
	},
	411: {
		id: 411,
		species: "frog",
		kind: "villager",
		cost: 2,
		supplies: 4,
		free: !0,
		group: "core",
		name: "games.wildventure.c411Name",
		text: "games.wildventure.c411Text"
	},
	412: {
		id: 412,
		species: "rabbit",
		kind: "villager",
		cost: 1,
		supplies: 2,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c412Name",
		text: "games.wildventure.c412Text"
	},
	413: {
		id: 413,
		species: "frog",
		kind: "villager",
		cost: 3,
		supplies: 3,
		free: !1,
		group: "academy",
		name: "games.wildventure.c413Name",
		text: "games.wildventure.c413Text"
	},
	414: {
		id: 414,
		species: "crow",
		kind: "villager",
		cost: 1,
		supplies: 1,
		free: !1,
		group: "core",
		name: "games.wildventure.c414Name",
		text: "games.wildventure.c414Text"
	},
	415: {
		id: 415,
		species: "crow",
		kind: "villager",
		cost: 6,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c415Name",
		text: "games.wildventure.c415Text"
	},
	416: {
		id: 416,
		species: "crow",
		kind: "villager",
		cost: 7,
		supplies: 1,
		free: !1,
		group: "academy",
		name: "games.wildventure.c416Name",
		text: "games.wildventure.c416Text"
	},
	417: {
		id: 417,
		species: "crow",
		kind: "gear",
		cost: 4,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c417Name",
		text: "games.wildventure.c417Text"
	},
	418: {
		id: 418,
		species: "frog",
		kind: "gear",
		cost: 3,
		supplies: 2,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c418Name",
		text: "games.wildventure.c418Text"
	},
	419: {
		id: 419,
		species: "crow",
		kind: "villager",
		cost: 6,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c419Name",
		text: "games.wildventure.c419Text"
	},
	420: {
		id: 420,
		species: "crow",
		kind: "villager",
		cost: 4,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c420Name",
		text: "games.wildventure.c420Text"
	},
	421: {
		id: 421,
		species: "crow",
		kind: "villager",
		cost: 8,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c421Name",
		text: "games.wildventure.c421Text"
	},
	422: {
		id: 422,
		species: "crow",
		kind: "gear",
		cost: 2,
		supplies: 5,
		free: !1,
		group: "core",
		name: "games.wildventure.c422Name",
		text: "games.wildventure.c422Text"
	},
	423: {
		id: 423,
		species: "rabbit",
		kind: "villager",
		cost: 3,
		supplies: 1,
		free: !1,
		group: "core",
		name: "games.wildventure.c423Name",
		text: "games.wildventure.c423Text"
	},
	424: {
		id: 424,
		species: "crow",
		kind: "gear",
		cost: 4,
		supplies: 3,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c424Name",
		text: "games.wildventure.c424Text"
	},
	425: {
		id: 425,
		species: "rabbit",
		kind: "villager",
		cost: 6,
		supplies: 5,
		free: !0,
		group: "core",
		name: "games.wildventure.c425Name",
		text: "games.wildventure.c425Text"
	},
	426: {
		id: 426,
		species: "rabbit",
		kind: "gear",
		cost: 1,
		supplies: 1,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c426Name",
		text: "games.wildventure.c426Text"
	},
	427: {
		id: 427,
		species: "rabbit",
		kind: "villager",
		cost: 1,
		supplies: 3,
		free: !1,
		group: "academy",
		name: "games.wildventure.c427Name",
		text: "games.wildventure.c427Text"
	},
	428: {
		id: 428,
		species: "rabbit",
		kind: "villager",
		cost: 0,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c428Name",
		text: "games.wildventure.c428Text"
	},
	429: {
		id: 429,
		species: "rabbit",
		kind: "villager",
		cost: 3,
		supplies: 2,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c429Name",
		text: "games.wildventure.c429Text"
	},
	430: {
		id: 430,
		species: "rabbit",
		kind: "villager",
		cost: 0,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c430Name",
		text: "games.wildventure.c430Text"
	},
	431: {
		id: 431,
		species: "rabbit",
		kind: "villager",
		cost: 2,
		supplies: 1,
		free: !1,
		group: "core",
		name: "games.wildventure.c431Name",
		text: "games.wildventure.c431Text"
	},
	432: {
		id: 432,
		species: "crow",
		kind: "villager",
		cost: 3,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c432Name",
		text: "games.wildventure.c432Text"
	},
	433: {
		id: 433,
		species: "rabbit",
		kind: "building",
		cost: 4,
		supplies: 0,
		free: !1,
		group: "core",
		name: "games.wildventure.c433Name",
		text: "games.wildventure.c433Text"
	},
	434: {
		id: 434,
		species: "frog",
		kind: "building",
		cost: 2,
		supplies: 0,
		free: !1,
		group: "core",
		name: "games.wildventure.c434Name",
		text: "games.wildventure.c434Text"
	},
	435: {
		id: 435,
		species: "frog",
		kind: "building",
		cost: 8,
		supplies: 0,
		free: !1,
		group: "academy",
		name: "games.wildventure.c435Name",
		text: "games.wildventure.c435Text"
	},
	436: {
		id: 436,
		species: "frog",
		kind: "villager",
		cost: 8,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c436Name",
		text: "games.wildventure.c436Text"
	},
	437: {
		id: 437,
		species: "rabbit",
		kind: "villager",
		cost: 4,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c437Name",
		text: "games.wildventure.c437Text"
	},
	438: {
		id: 438,
		species: "frog",
		kind: "building",
		cost: 6,
		supplies: 0,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c438Name",
		text: "games.wildventure.c438Text"
	},
	439: {
		id: 439,
		species: "rabbit",
		kind: "building",
		cost: 3,
		supplies: 0,
		free: !1,
		group: "core",
		name: "games.wildventure.c439Name",
		text: "games.wildventure.c439Text"
	},
	440: {
		id: 440,
		species: "rabbit",
		kind: "gear",
		cost: 3,
		supplies: 2,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c440Name",
		text: "games.wildventure.c440Text"
	},
	441: {
		id: 441,
		species: "crow",
		kind: "gear",
		cost: 5,
		supplies: 4,
		free: !1,
		group: "core",
		name: "games.wildventure.c441Name",
		text: "games.wildventure.c441Text"
	},
	442: {
		id: 442,
		species: "frog",
		kind: "gear",
		cost: 0,
		supplies: 2,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c442Name",
		text: "games.wildventure.c442Text"
	},
	443: {
		id: 443,
		species: "crow",
		kind: "building",
		cost: 5,
		supplies: 0,
		free: !1,
		group: "academy",
		name: "games.wildventure.c443Name",
		text: "games.wildventure.c443Text"
	},
	444: {
		id: 444,
		species: "frog",
		kind: "gear",
		cost: 4,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c444Name",
		text: "games.wildventure.c444Text"
	},
	445: {
		id: 445,
		species: "crow",
		kind: "building",
		cost: 3,
		supplies: 0,
		free: !1,
		group: "core",
		name: "games.wildventure.c445Name",
		text: "games.wildventure.c445Text"
	},
	446: {
		id: 446,
		species: "crow",
		kind: "gear",
		cost: 5,
		supplies: 3,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c446Name",
		text: "games.wildventure.c446Text"
	},
	447: {
		id: 447,
		species: "frog",
		kind: "gear",
		cost: 2,
		supplies: 2,
		free: !1,
		group: "academy",
		name: "games.wildventure.c447Name",
		text: "games.wildventure.c447Text"
	},
	448: {
		id: 448,
		species: "crow",
		kind: "gear",
		cost: 3,
		supplies: 2,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c448Name",
		text: "games.wildventure.c448Text"
	},
	500: {
		id: 500,
		species: "frog",
		kind: "villager",
		cost: 3,
		supplies: 4,
		free: !1,
		group: "core",
		name: "games.wildventure.c500Name",
		text: "games.wildventure.c500Text"
	},
	501: {
		id: 501,
		species: "crow",
		kind: "villager",
		cost: 4,
		supplies: 3,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c501Name",
		text: "games.wildventure.c501Text"
	},
	502: {
		id: 502,
		species: "rabbit",
		kind: "building",
		cost: 6,
		supplies: 0,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c502Name",
		text: "games.wildventure.c502Text"
	},
	503: {
		id: 503,
		species: "crow",
		kind: "building",
		cost: 4,
		supplies: 0,
		free: !1,
		group: "core",
		name: "games.wildventure.c503Name",
		text: "games.wildventure.c503Text"
	},
	504: {
		id: 504,
		species: "crow",
		kind: "gear",
		cost: 5,
		supplies: 3,
		free: !1,
		group: "academy",
		name: "games.wildventure.c504Name",
		text: "games.wildventure.c504Text"
	},
	505: {
		id: 505,
		species: "frog",
		kind: "gear",
		cost: 2,
		supplies: 5,
		free: !1,
		group: "core",
		name: "games.wildventure.c505Name",
		text: "games.wildventure.c505Text"
	},
	506: {
		id: 506,
		species: "rabbit",
		kind: "building",
		cost: 5,
		supplies: 0,
		free: !1,
		group: "core",
		name: "games.wildventure.c506Name",
		text: "games.wildventure.c506Text"
	},
	507: {
		id: 507,
		species: "crow",
		kind: "gear",
		cost: 3,
		supplies: 3,
		free: !1,
		group: "academy",
		name: "games.wildventure.c507Name",
		text: "games.wildventure.c507Text"
	},
	508: {
		id: 508,
		species: "crow",
		kind: "building",
		cost: 7,
		supplies: 0,
		free: !1,
		group: "core",
		name: "games.wildventure.c508Name",
		text: "games.wildventure.c508Text"
	},
	509: {
		id: 509,
		species: "crow",
		kind: "building",
		cost: 4,
		supplies: 0,
		free: !1,
		group: "core",
		name: "games.wildventure.c509Name",
		text: "games.wildventure.c509Text"
	},
	510: {
		id: 510,
		species: "frog",
		kind: "villager",
		cost: 2,
		supplies: 3,
		free: !1,
		group: "academy",
		name: "games.wildventure.c510Name",
		text: "games.wildventure.c510Text"
	},
	511: {
		id: 511,
		species: "crow",
		kind: "villager",
		cost: 5,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c511Name",
		text: "games.wildventure.c511Text"
	},
	512: {
		id: 512,
		species: "crow",
		kind: "villager",
		cost: 2,
		supplies: 4,
		free: !0,
		group: "academy",
		name: "games.wildventure.c512Name",
		text: "games.wildventure.c512Text"
	},
	513: {
		id: 513,
		species: "crow",
		kind: "villager",
		cost: 2,
		supplies: 4,
		free: !0,
		group: "tidings",
		name: "games.wildventure.c513Name",
		text: "games.wildventure.c513Text"
	},
	514: {
		id: 514,
		species: "crow",
		kind: "villager",
		cost: 3,
		supplies: 1,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c514Name",
		text: "games.wildventure.c514Text"
	},
	515: {
		id: 515,
		species: "frog",
		kind: "villager",
		cost: 2,
		supplies: 2,
		free: !1,
		group: "academy",
		name: "games.wildventure.c515Name",
		text: "games.wildventure.c515Text"
	},
	516: {
		id: 516,
		species: "rabbit",
		kind: "villager",
		cost: 1,
		supplies: 2,
		free: !1,
		group: "academy",
		name: "games.wildventure.c516Name",
		text: "games.wildventure.c516Text"
	},
	517: {
		id: 517,
		species: "rabbit",
		kind: "villager",
		cost: 2,
		supplies: 1,
		free: !1,
		group: "core",
		name: "games.wildventure.c517Name",
		text: "games.wildventure.c517Text"
	},
	518: {
		id: 518,
		species: "crow",
		kind: "villager",
		cost: 3,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c518Name",
		text: "games.wildventure.c518Text"
	},
	519: {
		id: 519,
		species: "frog",
		kind: "villager",
		cost: 6,
		supplies: 2,
		free: !1,
		group: "academy",
		name: "games.wildventure.c519Name",
		text: "games.wildventure.c519Text"
	},
	520: {
		id: 520,
		species: "frog",
		kind: "villager",
		cost: 6,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c520Name",
		text: "games.wildventure.c520Text"
	},
	521: {
		id: 521,
		species: "crow",
		kind: "villager",
		cost: 6,
		supplies: 3,
		free: !1,
		group: "academy",
		name: "games.wildventure.c521Name",
		text: "games.wildventure.c521Text"
	},
	522: {
		id: 522,
		species: "frog",
		kind: "villager",
		cost: 9,
		supplies: 4,
		free: !0,
		group: "core",
		name: "games.wildventure.c522Name",
		text: "games.wildventure.c522Text"
	},
	523: {
		id: 523,
		species: "rabbit",
		kind: "villager",
		cost: 2,
		supplies: 1,
		free: !1,
		group: "academy",
		name: "games.wildventure.c523Name",
		text: "games.wildventure.c523Text"
	},
	524: {
		id: 524,
		species: "rabbit",
		kind: "gear",
		cost: 2,
		supplies: 5,
		free: !1,
		group: "academy",
		name: "games.wildventure.c524Name",
		text: "games.wildventure.c524Text"
	},
	525: {
		id: 525,
		species: "frog",
		kind: "gear",
		cost: 2,
		supplies: 3,
		free: !1,
		group: "academy",
		name: "games.wildventure.c525Name",
		text: "games.wildventure.c525Text"
	},
	526: {
		id: 526,
		species: "rabbit",
		kind: "gear",
		cost: 3,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c526Name",
		text: "games.wildventure.c526Text"
	},
	527: {
		id: 527,
		species: "frog",
		kind: "villager",
		cost: 5,
		supplies: 3,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c527Name",
		text: "games.wildventure.c527Text"
	},
	528: {
		id: 528,
		species: "crow",
		kind: "villager",
		cost: 3,
		supplies: 3,
		free: !1,
		group: "academy",
		name: "games.wildventure.c528Name",
		text: "games.wildventure.c528Text"
	},
	529: {
		id: 529,
		species: "crow",
		kind: "villager",
		cost: 7,
		supplies: 2,
		free: !0,
		group: "tidings",
		name: "games.wildventure.c529Name",
		text: "games.wildventure.c529Text"
	},
	530: {
		id: 530,
		species: "rabbit",
		kind: "building",
		cost: 5,
		supplies: 0,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c530Name",
		text: "games.wildventure.c530Text"
	},
	531: {
		id: 531,
		species: "frog",
		kind: "building",
		cost: 3,
		supplies: 0,
		free: !1,
		group: "academy",
		name: "games.wildventure.c531Name",
		text: "games.wildventure.c531Text"
	},
	532: {
		id: 532,
		species: "rabbit",
		kind: "gear",
		cost: 0,
		supplies: 2,
		free: !1,
		group: "academy",
		name: "games.wildventure.c532Name",
		text: "games.wildventure.c532Text"
	},
	533: {
		id: 533,
		species: "rabbit",
		kind: "gear",
		cost: 4,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c533Name",
		text: "games.wildventure.c533Text"
	},
	534: {
		id: 534,
		species: "frog",
		kind: "villager",
		cost: 7,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c534Name",
		text: "games.wildventure.c534Text"
	},
	535: {
		id: 535,
		species: "crow",
		kind: "villager",
		cost: 7,
		supplies: 1,
		free: !1,
		group: "core",
		name: "games.wildventure.c535Name",
		text: "games.wildventure.c535Text"
	},
	536: {
		id: 536,
		species: "crow",
		kind: "building",
		cost: 6,
		supplies: 0,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c536Name",
		text: "games.wildventure.c536Text"
	},
	537: {
		id: 537,
		species: "crow",
		kind: "villager",
		cost: 3,
		supplies: 3,
		free: !0,
		group: "academy",
		name: "games.wildventure.c537Name",
		text: "games.wildventure.c537Text"
	},
	538: {
		id: 538,
		species: "frog",
		kind: "building",
		cost: 5,
		supplies: 0,
		free: !1,
		group: "academy",
		name: "games.wildventure.c538Name",
		text: "games.wildventure.c538Text"
	},
	539: {
		id: 539,
		species: "rabbit",
		kind: "villager",
		cost: 5,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c539Name",
		text: "games.wildventure.c539Text"
	},
	540: {
		id: 540,
		species: "frog",
		kind: "gear",
		cost: 3,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c540Name",
		text: "games.wildventure.c540Text"
	},
	541: {
		id: 541,
		species: "frog",
		kind: "villager",
		cost: 2,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c541Name",
		text: "games.wildventure.c541Text"
	},
	542: {
		id: 542,
		species: "rabbit",
		kind: "gear",
		cost: 4,
		supplies: 2,
		free: !1,
		group: "core",
		name: "games.wildventure.c542Name",
		text: "games.wildventure.c542Text"
	},
	543: {
		id: 543,
		species: "frog",
		kind: "building",
		cost: 3,
		supplies: 0,
		free: !1,
		group: "core",
		name: "games.wildventure.c543Name",
		text: "games.wildventure.c543Text"
	},
	544: {
		id: 544,
		species: "rabbit",
		kind: "gear",
		cost: 3,
		supplies: 4,
		free: !1,
		group: "core",
		name: "games.wildventure.c544Name",
		text: "games.wildventure.c544Text"
	},
	545: {
		id: 545,
		species: "rabbit",
		kind: "building",
		cost: 4,
		supplies: 0,
		free: !1,
		group: "core",
		name: "games.wildventure.c545Name",
		text: "games.wildventure.c545Text"
	},
	546: {
		id: 546,
		species: "rabbit",
		kind: "villager",
		cost: 5,
		supplies: 3,
		free: !1,
		group: "core",
		name: "games.wildventure.c546Name",
		text: "games.wildventure.c546Text"
	},
	547: {
		id: 547,
		species: "frog",
		kind: "villager",
		cost: 8,
		supplies: 2,
		free: !1,
		group: "academy",
		name: "games.wildventure.c547Name",
		text: "games.wildventure.c547Text"
	},
	548: {
		id: 548,
		species: "rabbit",
		kind: "villager",
		cost: 8,
		supplies: 4,
		free: !0,
		group: "tidings",
		name: "games.wildventure.c548Name",
		text: "games.wildventure.c548Text"
	},
	600: {
		id: 600,
		species: "frog",
		kind: "villager",
		cost: 2,
		supplies: 4,
		free: !1,
		group: "tidings",
		name: "games.wildventure.c600Name",
		text: "games.wildventure.c600Text"
	},
	800: {
		id: 800,
		species: "rabbit",
		kind: "villager",
		cost: 2,
		supplies: 2,
		free: !1,
		group: "initiate",
		name: "games.wildventure.c800Name",
		text: "games.wildventure.c800Text"
	},
	900: {
		id: 900,
		species: "frog",
		kind: "villager",
		cost: 2,
		supplies: 2,
		free: !1,
		group: "initiate",
		name: "games.wildventure.c900Name",
		text: "games.wildventure.c900Text"
	},
	3800: {
		id: 3800,
		species: "crow",
		kind: "villager",
		cost: 2,
		supplies: 2,
		free: !1,
		group: "initiate",
		name: "games.wildventure.c3800Name",
		text: "games.wildventure.c3800Text"
	}
}, w = Object.values(C), T = [
	"crow",
	"frog",
	"rabbit"
], re = [
	3800,
	900,
	800
];
function E(e) {
	return C[e];
}
//#endregion
//#region src/games/wildventure/board.ts
var D = [
	[
		"home",
		53,
		86,
		{},
		[
			"l1",
			"m1",
			"r1"
		]
	],
	[
		"l1",
		40,
		83,
		{ gain: 1 },
		["l2"]
	],
	[
		"l2",
		29,
		84,
		{ starter: "crow" },
		["l3", "l9"]
	],
	[
		"l3",
		19,
		82,
		{ gain: 1 },
		["l4"]
	],
	[
		"l4",
		10,
		72,
		{ gain: 2 },
		["l5"]
	],
	[
		"l5",
		9,
		51,
		{ starter: "rabbit" },
		["l6"]
	],
	[
		"l6",
		15,
		38,
		{ gain: 3 },
		["l7"]
	],
	[
		"l7",
		24,
		36,
		{
			gain: 1,
			draw: 1
		},
		["l8", "l12"]
	],
	[
		"l8",
		22,
		26,
		{ gain: 3 },
		["temple"]
	],
	[
		"temple",
		17,
		16,
		{ chest: "gold" },
		[]
	],
	[
		"l9",
		29,
		70,
		{ draw: 1 },
		["l10", "l11"]
	],
	[
		"l10",
		24,
		50,
		{ draw: 1 },
		["l7"]
	],
	[
		"l11",
		36,
		60,
		{ draw: 2 },
		["l10"]
	],
	[
		"l12",
		30,
		22,
		{},
		["temple"]
	],
	[
		"m1",
		50,
		77,
		{},
		["m2"]
	],
	[
		"m2",
		57,
		72,
		{},
		["m3"]
	],
	[
		"m3",
		66,
		70,
		{ gain: 1 },
		["m4", "inn"]
	],
	[
		"inn",
		72,
		60,
		{ chest: "iron" },
		["m4"]
	],
	[
		"m4",
		61,
		60,
		{ gain: 1 },
		["m5"]
	],
	[
		"m5",
		52,
		58,
		{ starter: "frog" },
		["m6"]
	],
	[
		"m6",
		53,
		48,
		{ draw: 1 },
		["m7"]
	],
	[
		"m7",
		51,
		38,
		{ gain: 2 },
		["m8", "m16"]
	],
	[
		"m8",
		43,
		26,
		{ gain: 3 },
		["m9"]
	],
	[
		"m9",
		51,
		21,
		{ draw: 1 },
		["m10"]
	],
	[
		"m10",
		60,
		15,
		{ chest: "gold" },
		["m11"]
	],
	[
		"m11",
		64,
		24,
		{ draw: 1 },
		["m12"]
	],
	[
		"m12",
		69,
		16,
		{},
		["ruby", "m14"]
	],
	[
		"m14",
		78,
		24,
		{ gain: 3 },
		["m15"]
	],
	[
		"m15",
		85,
		17,
		{
			gain: 3,
			draw: 1
		},
		["ruby"]
	],
	[
		"ruby",
		77,
		9,
		{ chest: "ruby" },
		[]
	],
	[
		"m16",
		60,
		34,
		{ gain: 2 },
		["m11", "m17"]
	],
	[
		"m17",
		68,
		38,
		{ chest: "iron" },
		["m18"]
	],
	[
		"m18",
		79,
		34,
		{ gain: 2 },
		["m14"]
	],
	[
		"r1",
		76,
		89,
		{ gain: 5 },
		["r2"]
	],
	[
		"r2",
		85,
		83,
		{ gain: 3 },
		["r3"]
	],
	[
		"r3",
		89,
		72,
		{},
		["r4"]
	],
	[
		"r4",
		90,
		61,
		{},
		["river"]
	],
	[
		"river",
		88,
		50,
		{ chest: "iron" },
		[]
	]
], ie = {
	l1: {},
	l2: { starter: "rabbit" },
	l3: {},
	l4: { draw: 1 },
	l5: { draw: 1 },
	l6: { starter: "crow" },
	l7: {},
	l8: { gain: 3 },
	temple: { chest: "iron" },
	l9: { gain: 2 },
	l10: { gain: 3 },
	l11: { gain: 5 },
	l12: { chest: "iron" },
	m1: { gain: 1 },
	m2: { gain: 1 },
	m6: { gain: 2 },
	m7: { draw: 1 },
	m8: {
		gain: 1,
		draw: 1
	},
	m9: {
		gain: 1,
		draw: 1
	},
	m10: {
		gain: 1,
		draw: 1
	},
	m11: {
		gain: 1,
		draw: 1
	},
	m12: {
		gain: 1,
		draw: 1
	},
	m16: {},
	m17: { gain: 3 },
	m18: { gain: 3 },
	inn: { chest: "gold" },
	r1: { draw: 2 },
	r2: { draw: 1 }
}, O = {
	"l9:l6": { coins: 1 },
	"l9:l10": { trash: 1 },
	"l9:l11": { trash: 2 },
	"l7:l12": { coins: 1 },
	"m3:inn": { coins: 3 },
	"r1:r4": { coins: 3 },
	"m6:m16": { trash: 3 },
	"m7:m16": { coins: 4 }
};
function ae(e) {
	return D.map(([t, n, r, i, a]) => {
		let o = a;
		return e === "autumn" && (t === "l9" && (o = [
			"l6",
			"l10",
			"l11"
		]), t === "m6" && (o = ["m7", "m16"]), t === "r1" && (o = ["r2", "r4"])), {
			id: t,
			x: n,
			y: r,
			reward: e === "autumn" ? ie[t] ?? i : i,
			next: o.map((n) => ({
				to: n,
				...e === "autumn" ? O[`${t}:${n}`] : {}
			})),
			terminal: !o.length
		};
	});
}
function k(e, t) {
	return ae(e).find((e) => e.id === t);
}
//#endregion
//#region src/games/wildventure/state.ts
var A = "$wildventure-otto", j = (e, t) => e.players.find((e) => e.rid === t), M = (e, t) => e.players.find((e) => e.rid !== t), N = (e, t, n) => j(e, t).placed.find((e) => e.id === n), P = (e, t) => e.frames[t.f];
function F(e, ...t) {
	e.queue.unshift(...t);
}
function I(e, t) {
	return t.map((t) => ({
		by: e.by,
		source: e.source,
		f: e.f,
		flags: e.flags,
		origin: e.origin,
		...t
	}));
}
function L(e, t, n = {}) {
	return {
		id: "",
		label: e,
		...n,
		tasks: t
	};
}
function R(e, t, n, r, i) {
	if (!r.length && !i) return;
	let a = ++e.decisionCounter;
	e.decision = {
		by: t,
		prompt: n,
		options: r.map((e, t) => ({
			...e,
			id: `c${a}:${t}`
		})),
		selection: i
	};
}
function z(e, t, n, r = {}) {
	e.scene = {
		seq: ++e.seq,
		kind: t,
		by: n,
		...r
	}, e.log.push(e.scene), e.log.length > 120 && e.log.shift();
}
//#endregion
//#region src/games/wildventure/effects.ts
function B(e, t) {
	let n = t.id ?? t.source, r = ++e.frameCounter;
	e.frames[r] = {
		pool: [],
		last: [],
		path: []
	};
	let i = {
		...t,
		f: r,
		flags: void 0
	}, a = (t) => F(e, ...I(i, t)), o = (e, t, n) => a([
		{
			op: "consider",
			n: e,
			mode: n
		},
		...t.map(([e, t]) => ({
			op: "select",
			mode: e,
			n: t
		})),
		{ op: "returnPool" }
	]);
	switch (n) {
		case 3800:
			a([{
				op: "draw",
				n: 2
			}]);
			break;
		case 800:
			a([{
				op: "gain",
				n: 4
			}]);
			break;
		case 900:
		case 500:
			a([{
				op: "adventure",
				n: 2
			}]);
			break;
		case 401:
			R(e, t.by, "chooseEffect", [
				L("draw", I(i, [{
					op: "draw",
					n: 2
				}]), { n: 2 }),
				L("adventure", I(i, [{
					op: "adventure",
					n: 2
				}]), { n: 2 }),
				...j(e, t.by).coins >= 2 ? [L("both", I(i, [
					{
						op: "pay",
						n: 2
					},
					{
						op: "draw",
						n: 2
					},
					{
						op: "adventure",
						n: 2
					}
				]))] : []
			]);
			break;
		case 402:
			a([{
				op: "special",
				id: n,
				mode: "starter"
			}]);
			break;
		case 403:
		case 529:
			a([{
				op: "special",
				id: n,
				mode: "tutor"
			}]);
			break;
		case 404:
			a([{
				op: "gain",
				n: 5
			}]);
			break;
		case 405:
			a([{
				op: "draw",
				n: 1
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 406:
			a([{
				op: "select",
				mode: "handTrash",
				n: 1
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 407:
			a([{
				op: "adventure",
				n: 3,
				flags: { wizard: !0 }
			}]);
			break;
		case 408:
			a([{
				op: "adventure",
				n: j(e, t.by).placed.filter((e) => E(e.id).kind === "gear").length
			}]);
			break;
		case 409:
			a([{
				op: "special",
				id: n
			}]);
			break;
		case 410:
			a([{
				op: "adventure",
				n: 1,
				flags: { noReward: !0 }
			}]);
			break;
		case 411:
			a([{
				op: "select",
				mode: "handTrash",
				n: 1
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 412:
			a([{
				op: "gain",
				n: 2
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 413:
			a([{
				op: "select",
				mode: "deckTrash",
				n: 1
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 414:
			a([{
				op: "draw",
				n: 3
			}]);
			break;
		case 415:
			a([{
				op: "select",
				mode: "handTrash",
				n: 1
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 416:
			a([{
				op: "special",
				id: n,
				mode: "factor"
			}]);
			break;
		case 419:
			R(e, t.by, "chooseSpecies", T.map((e) => L("chooseSpecies", I(i, [
				{
					op: "consider",
					n: 4,
					species: e
				},
				{
					op: "special",
					id: n,
					species: e
				},
				{ op: "returnPool" }
			]), { species: e })));
			break;
		case 420:
			a([
				{
					op: "consider",
					n: 3
				},
				{
					op: "special",
					id: n
				},
				{ op: "returnPool" }
			]);
			break;
		case 421:
			o(3, [
				["poolTuck", 1],
				["poolDraw", 1],
				["poolTrash", 1]
			]);
			break;
		case 423:
			a([{
				op: "select",
				mode: "playGear",
				n: 1
			}]);
			break;
		case 425:
			a([{
				op: "gain",
				n: 2
			}]);
			break;
		case 427:
			a([
				{
					op: "adventure",
					n: 2
				},
				{
					op: "starter",
					species: "rabbit"
				},
				{
					op: "starter",
					by: M(e, t.by).rid,
					species: "rabbit"
				}
			]);
			break;
		case 428:
			a([{
				op: "special",
				id: n
			}, {
				op: "gain",
				n: 5
			}]);
			break;
		case 429:
			a([
				{
					op: "consider",
					n: 2
				},
				{
					op: "select",
					mode: "poolGive",
					n: 1
				},
				{ op: "returnPool" },
				{
					op: "gain",
					n: 5
				}
			]);
			break;
		case 430:
			a([{
				op: "gain",
				n: 2
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 431:
			a([{
				op: "select",
				mode: "deckTrash",
				n: 1
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 432:
			a([{
				op: "draw",
				n: 1
			}, {
				op: "starter",
				species: "crow"
			}]);
			break;
		case 436:
			a([{
				op: "select",
				mode: "playFree",
				n: 1
			}]);
			break;
		case 437:
		case 501:
			a([{
				op: n === 437 ? "gain" : "draw",
				n: n === 437 ? 4 : 2
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 510:
			a([
				{
					op: "consider",
					n: 3
				},
				{ op: "returnPool" },
				{
					op: "adventure",
					n: 1
				}
			]);
			break;
		case 511:
			a([{
				op: "select",
				mode: "handTrash",
				n: 1
			}, {
				op: "select",
				mode: "handTuck",
				n: 1
			}]);
			break;
		case 512:
			o(1, [["poolTrashOptional", 1]]);
			break;
		case 513:
			j(e, t.by).coins && a([{
				op: "pay",
				n: 1
			}, {
				op: "draw",
				n: 1
			}]);
			break;
		case 514:
			o(3, [
				["poolDraw", 1],
				["poolPlay", 1],
				["poolTrash", 110]
			]);
			break;
		case 515:
			a([{
				op: "select",
				mode: "trashPlayTop",
				n: 1
			}]);
			break;
		case 516:
			o(j(e, t.by).placed.filter((e) => E(e.id).kind === "villager").length, [["poolDraw", 1]]);
			break;
		case 517:
			a([{
				op: "gain",
				n: e.players.reduce((e, t) => e + t.placed.filter((e) => E(e.id).kind === "villager").length, 0)
			}]);
			break;
		case 518:
			a([{
				op: "draw",
				n: 1
			}, {
				op: "gain",
				n: 2
			}]);
			break;
		case 519:
			a([{
				op: "adventure",
				n: 5,
				flags: { chestHand: !0 }
			}, { op: "home" }]);
			break;
		case 520:
			a([{
				op: "adventure",
				n: 3
			}]);
			break;
		case 521:
			o(1, [["poolTuck", 1]]);
			break;
		case 522:
			a([{
				op: "adventure",
				n: 1
			}]);
			break;
		case 523:
			j(e, t.by).coins >= 10 && a([{
				op: "pay",
				n: 10
			}, {
				op: "chest",
				mode: "ruby"
			}]);
			break;
		case 527:
			a([{
				op: "adventure",
				n: 2
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 528:
			a([{
				op: "select",
				mode: "deckTrash",
				n: 1
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 534:
			a([{
				op: "adventure",
				n: 1
			}, {
				op: "adventure",
				n: 1
			}]);
			break;
		case 535:
			a([{
				op: "special",
				id: n
			}]);
			break;
		case 537:
			o(3, []);
			break;
		case 539:
			a([{
				op: "gain",
				n: 4
			}, {
				op: "special",
				id: n,
				mode: "pick"
			}]);
			break;
		case 541:
			a([{
				op: "select",
				mode: "trashTuckTop",
				n: 1
			}]);
			break;
		case 546:
			a([
				{
					op: "gain",
					n: 1
				},
				{
					op: "draw",
					n: 1
				},
				{
					op: "adventure",
					n: 1
				}
			]);
			break;
		case 547:
			o(3, [["poolTuck", 1], ["poolDraw", 1]], "trash");
			break;
		case 548:
			a([{
				op: "select",
				mode: "deckTrash",
				n: 1
			}, {
				op: "special",
				id: n
			}]);
			break;
		case 600: a([{
			op: "adventure",
			n: 1
		}, {
			op: "special",
			id: n
		}]);
	}
}
function oe(e, t) {
	let n = t.id ?? t.source, r = (n) => F(e, ...I(t, n));
	switch (n) {
		case 400:
			r([{
				op: "select",
				mode: "trashTuck",
				n: 1
			}]);
			break;
		case 417:
		case 444:
		case 542:
			r([{
				op: "select",
				mode: "handSpeciesTuck",
				n: 1,
				species: E(n).species
			}]);
			break;
		case 418:
		case 440:
		case 448:
			r([{
				op: "select",
				mode: "supply",
				n: 1,
				species: E(n).species
			}]);
			break;
		case 422:
		case 426:
		case 505:
		case 524:
			r([{
				op: "gain",
				n: 3
			}]);
			break;
		case 424:
			r([{
				op: "select",
				mode: "trashTuckTopFree",
				n: 1
			}]);
			break;
		case 441:
			r([{
				op: "draw",
				n: 3
			}]);
			break;
		case 442:
			r([
				{
					op: "consider",
					n: 3
				},
				{
					op: "select",
					mode: "poolGearDraw",
					n: 1
				},
				{ op: "returnPool" }
			]);
			break;
		case 446:
			r([{
				op: "chest",
				mode: "iron"
			}]);
			break;
		case 447:
			R(e, t.by, "chooseEffect", [L("move", I(t, [{
				op: "arrive",
				to: "m5",
				mode: "portal"
			}]), { node: "m5" }), L("skip", [])]);
			break;
		case 504:
			r([
				{
					op: "consider",
					n: 1
				},
				{
					op: "select",
					mode: "poolTuck",
					n: 1
				},
				{ op: "returnPool" }
			]);
			break;
		case 507:
			r([{
				op: "select",
				mode: "trashDraw",
				n: 1
			}]);
			break;
		case 525:
			r([{
				op: "select",
				mode: "trashPlayTopOptional",
				n: 1
			}]);
			break;
		case 526:
			r([{
				op: "gain",
				n: 4
			}]);
			break;
		case 532:
		case 544:
			r([{
				op: "draw",
				n: 2
			}]);
			break;
		case 533:
			r([{
				op: "gain",
				n: e.players.reduce((e, t) => e + t.placed.filter((e) => E(e.id).kind === "villager").length, 0)
			}]);
			break;
		case 540: r([{
			op: "draw",
			n: 3
		}, {
			op: "select",
			mode: "handTrash",
			n: 3
		}]);
	}
}
function se(e, t) {
	let n = t.source, r = (n) => F(e, ...I(t, n)), i = N(e, t.by, n)?.supplies ?? 0;
	switch (n) {
		case 433:
			r([{
				op: "special",
				id: n,
				mode: "transfer"
			}]);
			break;
		case 434:
			r([{
				op: "adventure",
				n: 3
			}]);
			break;
		case 438:
		case 502:
		case 536:
			r([{
				op: "select",
				mode: "activate",
				n: i
			}]);
			break;
		case 439:
			r([{
				op: "select",
				mode: "relic",
				n: 1
			}]);
			break;
		case 443:
		case 530:
		case 538:
			r([
				{
					op: "consider",
					n: 1
				},
				{
					op: "select",
					mode: "poolPlayDiscount",
					n: i,
					species: E(n).species
				},
				{ op: "returnPool" }
			]);
			break;
		case 445:
		case 543: {
			let i = j(e, t.by).placed.filter((e) => E(e.id).kind === "building").length;
			r([{
				op: "invest",
				n: i
			}, {
				op: n === 445 ? "draw" : "adventure",
				n: i
			}]);
			break;
		}
		case 503:
			r([{
				op: "gain",
				n: 4
			}, {
				op: "starter",
				species: "crow"
			}]);
			break;
		case 506:
			r([{
				op: "gain",
				n: i * 2
			}]);
			break;
		case 508: r([{
			op: "chest",
			mode: "iron"
		}]);
	}
}
function V(e, t) {
	let n = j(e, t.by), r = N(e, t.by, t.source), i = P(e, t), a = (n) => F(e, ...I(t, n));
	switch (t.id) {
		case 402:
			t.mode === "starter" ? R(e, t.by, "chooseStarter", T.map((e) => L("chooseStarter", I(t, [{
				op: "starter",
				species: e
			}, {
				op: "special",
				id: 402,
				mode: "reveal",
				species: e
			}]), { species: e }))) : a([{
				op: "select",
				mode: "census",
				n: 1,
				species: t.species
			}]);
			break;
		case 403:
		case 406:
		case 529:
			a([{
				op: "select",
				mode: "activate",
				n: t.id === 403 ? n.coins : t.id === 529 ? n.hand.length : i.last.length ? E(i.last[0]).cost : -1
			}]);
			break;
		case 405:
			r?.supplies || a([{
				op: "select",
				mode: "handTuck",
				n: 1
			}]);
			break;
		case 409:
			a([{
				op: "select",
				mode: "copyOpponent",
				n: 1
			}]);
			break;
		case 411:
			i.last.length && R(e, t.by, "chooseEffect", [L("gain", I(t, [{
				op: "gain",
				n: 2
			}]), { n: 2 }), L("draw", I(t, [{
				op: "draw",
				n: 1
			}]), { n: 1 })]);
			break;
		case 412:
			r?.supplies || a([{
				op: "adventure",
				n: 4
			}]);
			break;
		case 413:
			i.last.length && E(i.last[0]).kind === "villager" && a([{
				op: "refund",
				id: i.last[0]
			}, {
				op: "ability",
				id: i.last[0]
			}]);
			break;
		case 415:
			if (i.last.length) {
				let e = E(i.last[0]).species;
				a([{
					op: e === "crow" ? "draw" : e === "frog" ? "adventure" : "gain",
					n: e === "rabbit" ? 6 : 3
				}]);
			}
			break;
		case 416:
			a([
				{
					op: "consider",
					n: 4,
					mode: "factor"
				},
				{
					op: "select",
					mode: "factorReveal",
					n: 2
				},
				{
					op: "select",
					mode: "factorChoose",
					n: 1
				},
				{ op: "returnPool" }
			]);
			break;
		case 419: {
			let e = i.pool.filter((e) => E(e).species === t.species), n = i.pool.filter((e) => E(e).species !== t.species);
			a([
				{
					op: "selected",
					mode: "poolDrawReveal",
					ids: e
				},
				{
					op: "select",
					mode: "poolTrash",
					n: 110
				},
				{
					op: "adventure",
					n: n.length
				}
			]);
			break;
		}
		case 420:
			R(e, t.by, "chooseEffect", [L("escDrawTrash", I(t, [{
				op: "select",
				mode: "poolDraw",
				n: 1
			}, {
				op: "select",
				mode: "poolTrash",
				n: 2
			}])), L("escDrawGive", I(t, [{
				op: "select",
				mode: "poolDraw",
				n: 2
			}, {
				op: "select",
				mode: "poolGive",
				n: 1
			}]))]);
			break;
		case 428:
			a([{
				op: "pay",
				n: n.coins,
				mode: "give"
			}]);
			break;
		case 430:
		case 527:
			a([{
				op: n.starterUsed ? "draw" : "gain",
				n: 1
			}]);
			break;
		case 431:
			i.last.length && a([{
				op: "gain",
				n: E(i.last[0]).cost
			}]);
			break;
		case 433:
			a([{
				op: "select",
				mode: "transfer",
				n: 1
			}]);
			break;
		case 437:
		case 501:
			r?.supplies && R(e, t.by, "chooseEffect", [L("removeSupply", I(t, [{
				op: "supply",
				id: t.source,
				n: -1
			}, {
				op: "starter",
				species: "frog"
			}])), L("keepSupply", [])]);
			break;
		case 528:
			a([{
				op: "adventure",
				n: new Set(e.trash.slice(-3).map((e) => E(e).species)).size
			}]);
			break;
		case 535:
			a([{
				op: "select",
				mode: "copyHand",
				n: 1
			}]);
			break;
		case 539:
			t.mode === "pick" ? R(e, t.by, "chooseEffect", [...n.hand.length ? [L("trash", I(t, [{
				op: "select",
				mode: "handTrash",
				n: 1
			}, {
				op: "special",
				id: 539,
				mode: "check"
			}]))] : [], L("trashTop", I(t, [{
				op: "select",
				mode: "deckTrash",
				n: 1
			}, {
				op: "special",
				id: 539,
				mode: "check"
			}]))]) : i.last.length && E(i.last[0]).species === "rabbit" && a([{
				op: "starter",
				species: "rabbit"
			}]);
			break;
		case 548:
			i.last.length && a([{
				op: "starter",
				species: E(i.last[0]).species
			}]);
			break;
		case 600: r?.supplies || a([{
			op: "chest",
			mode: "iron"
		}]);
	}
}
//#endregion
//#region src/games/wildventure/meta.ts
var H = {
	id: "wildventure",
	tier: "beta",
	mechanics: [
		"hand-management",
		"engine-building",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.wildventure.name",
	descKey: "games.wildventure.desc",
	rulesKey: "games.wildventure.rules",
	icon: "🍄",
	iconImg: "games/wildventure.webp",
	minPlayers: 1,
	maxPlayers: 2,
	rulesUrl: {
		zh: "https://rules.bgparty.uuppi.com/wildventure/zh.pdf",
		en: "https://rules.bgparty.uuppi.com/wildventure/en.pdf"
	},
	bestPlayers: [2],
	playerRange: (e) => ({
		min: e?.theme === "mixed" ? 2 : 1,
		max: 2
	}),
	accent: "#397865",
	releasedAt: "2026-10-17T16:40:59+08:00",
	search: {
		py: "huang ye mao xian jia",
		init: "hymxj"
	},
	hotseat: "cover"
}, ce = t.enum([
	"crow",
	"frog",
	"rabbit"
]), U = t.object({
	theme: t.enum([
		"academy",
		"tidings",
		"mixed"
	]).default("academy"),
	season: t.enum(["spring", "autumn"]).default("spring"),
	otto: t.enum([
		"easy",
		"normal",
		"hard"
	]).default("normal"),
	noMemory: t.boolean().default(!1),
	tiebreak: t.boolean().default(!1)
}).prefault({}), le = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("act"),
		id: t.string().max(100)
	}),
	t.object({
		type: t.literal("pick"),
		cards: t.array(t.int()).max(110)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), ue = t.enum(/* @__PURE__ */ "play.activate.enchant.endTurn.skip.gain.draw.adventure.both.tuck.trash.returnTop.invest.upgrade.supply.relic.chooseStarter.chooseSpecies.move.stop.claim.chestHand.chestSpecial.chestConsider.resolveTrigger.copy.trashTop.revealedDraw.revealedTuck.escDrawTrash.escDrawGive.payDraw.removeSupply.keepSupply.continue.workshopTake.chooseInitiate".split(".")), W = t.enum(/* @__PURE__ */ "main.draft.ottoInitiate.trashHand.tuckHand.drawPool.tuckPool.trashPool.orderPool.chooseCard.chooseVillager.chooseBuilding.chooseGear.chooseStarter.chooseSpecies.chooseEffect.chooseTrigger.adventure.claimReward.chest.cleanup.factorReveal.factorChoose.invest.workshop.chooseTrash.jackbot".split(".")), de = t.object({
	id: t.string(),
	label: ue,
	card: t.int().optional(),
	n: t.number().optional(),
	species: ce.optional(),
	node: t.string().optional(),
	free: t.boolean().optional(),
	token: t.int().optional()
}), fe = t.object({
	id: t.int(),
	supplies: t.int().nonnegative(),
	enchanted: t.int().nullable()
}), pe = t.object({
	seq: t.int(),
	kind: t.enum([
		"play",
		"activate",
		"gain",
		"draw",
		"trash",
		"tuck",
		"invest",
		"move",
		"home",
		"enchant",
		"supply",
		"reveal",
		"turn",
		"jackbot",
		"finish"
	]),
	by: t.string(),
	card: t.int().optional(),
	n: t.int().optional(),
	node: t.string().optional()
}), me = t.object({
	villagers: t.tuple([
		t.int(),
		t.int(),
		t.int()
	]),
	villagerScore: t.int(),
	gearCount: t.int(),
	multiplier: t.int(),
	gearScore: t.int(),
	buildingScore: t.int(),
	coinScore: t.int(),
	total: t.int(),
	cards: t.array(t.int())
}), he = t.object({
	phase: t.enum([
		"draft",
		"main",
		"resolve",
		"choose",
		"done"
	]),
	turn: t.string(),
	chooser: t.string().nullable(),
	prompt: W.nullable(),
	turnNumber: t.int(),
	actionsLeft: t.int().nonnegative(),
	finalTurns: t.int().nullable(),
	config: U,
	solo: t.boolean(),
	deckCount: t.int(),
	ottoDeckCount: t.int(),
	trash: t.array(t.int()),
	revealed: t.array(t.int()),
	tokens: t.array(t.object({
		node: t.string(),
		kind: t.enum([
			"nest",
			"gain5",
			"gold",
			"enchant"
		]),
		token: t.int().optional(),
		count: t.int()
	})),
	players: t.array(t.object({
		rid: t.string(),
		coins: t.int().nonnegative(),
		handCount: t.int(),
		tuckedCount: t.int(),
		placed: t.array(fe),
		starters: t.tuple([
			t.boolean(),
			t.boolean(),
			t.boolean()
		]),
		tokens: t.array(t.int()),
		used: t.array(t.string()),
		position: t.string(),
		species: ce.nullable(),
		score: me.nullable()
	})),
	scene: pe.nullable(),
	log: t.array(pe)
}), ge = t.object({
	hand: t.array(t.int()),
	tucked: t.array(t.int()).nullable(),
	moves: t.array(de),
	selection: t.object({
		cards: t.array(t.int()),
		min: t.int(),
		max: t.int(),
		ordered: t.boolean()
	}).nullable(),
	pool: t.array(t.int())
});
function G(e, t, n, r, i, a = []) {
	let { cards: o = [], ...s } = r;
	e.push({
		kind: "wvAction",
		rid: t,
		...e.length ? { with: !0 } : {},
		data: {
			cue: n,
			card: null,
			source: null,
			sourceOwner: t,
			n: 0,
			supplies: 0,
			from: null,
			to: null,
			origin: null,
			cards: i ? a : o,
			token: null,
			...s
		},
		...i ? {
			for: i,
			secret: { cards: o }
		} : {}
	});
}
function K(e, t, n, r, i, a, o, s) {
	r.length && G(e, t.by, n, {
		source: t.source ?? null,
		origin: t.origin ?? null,
		n: r.length,
		cards: r,
		from: i,
		to: a
	}, o, s);
}
function _e(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function q(e, t) {
	let n = e.deck.splice(0, t);
	return !e.deck.length && e.exhaustedAt === null && (e.exhaustedAt = e.turnNumber), n;
}
function J(e) {
	let t = ++e.frameCounter;
	return e.frames[t] = {
		pool: [],
		last: [],
		path: []
	}, t;
}
function Y(e, t, n, r = [], i = {}) {
	return {
		op: "event",
		by: e.by,
		event: {
			kind: t,
			by: e.by,
			source: e.source,
			n,
			cards: r,
			...i
		}
	};
}
function ve(e, t) {
	switch (e) {
		case 400:
		case 507:
		case 525: return t.kind === "trash" && t.n > 0;
		case 417:
		case 444:
		case 542: return t.kind === "home";
		case 418: return t.kind === "starter" && t.species === "frog";
		case 422: return t.kind === "play" && t.species === "crow";
		case 424: return t.kind === "tuck" && !!t.outside;
		case 426: return t.kind === "twoVillagers";
		case 440: return t.kind === "starter" && t.species === "rabbit";
		case 441: return t.kind === "draw" && t.n > 0;
		case 442: return t.kind === "play" && E(t.cards[0]).kind === "gear";
		case 446: return t.kind === "chest";
		case 447:
		case 544: return t.kind === "adventure";
		case 448: return t.kind === "starter" && t.species === "crow";
		case 504:
		case 540: return t.kind === "consider";
		case 505: return t.kind === "play" && t.species === "frog";
		case 524: return t.kind === "play" && t.species === "rabbit";
		case 526: return t.kind === "invest" && t.n > 0;
		case 532: return t.kind === "spend" && t.n > 0;
		case 533: return t.kind === "play" && E(t.cards[0]).kind === "villager";
		default: return !1;
	}
}
function ye(e, t, n, r) {
	let i = N(e, t, n);
	switch (n) {
		case 433: return r.kind === "gain" && r.n > i.supplies;
		case 435:
		case 545: return r.kind === "trash" && (n !== 545 || r.cards.some((e) => E(e).kind === "gear"));
		case 438:
		case 538: return r.kind === "play" && r.species === "frog";
		case 443:
		case 536: return r.kind === "play" && r.species === "crow";
		case 502:
		case 530: return r.kind === "play" && r.species === "rabbit";
		case 445:
		case 543: return r.kind === "play" && E(r.cards[0]).kind === "building";
		case 503: return r.kind === "draw" && !!r.nest && r.n > 0;
		case 506: return r.kind === "play" && E(r.cards[0]).cost > i.supplies;
		case 509: return r.kind === "tuck" && !!r.outside;
		case 531: return r.kind === "home";
		default: return !1;
	}
}
function be(e, t) {
	if (t.by === "$wildventure-otto" || !t.n && [
		"gain",
		"draw",
		"trash",
		"tuck"
	].includes(t.kind)) return;
	let n = e.players.flatMap((n) => n.placed.filter((r) => !(t.kind === "play" && t.cards.includes(r.id)) && (E(r.id).kind === "gear" ? r.supplies > 0 && ve(r.id, t) : n.rid === t.by && E(r.id).kind === "building" && ye(e, n.rid, r.id, t))).map((e) => e.id));
	n.length && F(e, {
		op: "triggers",
		by: t.by,
		ids: n,
		event: t
	});
}
function xe(e, t, n) {
	let r = t.id, i = t.event, a = j(e, t.by), o = e.players.find((e) => e.placed.some((e) => e.id === r)), s = o?.placed.find((e) => e.id === r);
	if (!s) return;
	let c = {
		...t,
		source: r,
		f: J(e)
	};
	if (E(r).kind === "gear") {
		if (!s.supplies) return;
		if (o.rid === t.by && N(e, t.by, 439) && s.supplies >= 2 && t.mode !== "take") {
			R(e, t.by, "workshop", [1, 2].map((e) => L("workshopTake", [{
				...t,
				mode: "take",
				n: e
			}], {
				n: e,
				card: r
			})));
			return;
		}
		let i = Math.min(s.supplies, t.n ?? 1);
		s.supplies -= i, a.coins += i, z(e, "gain", t.by, {
			card: r,
			n: i
		}), G(n, t.by, "gain", {
			source: r,
			sourceOwner: o.rid,
			n: i,
			supplies: -i
		});
		return;
	}
	switch (G(n, t.by, "trigger", { source: r }), r) {
		case 435:
			F(e, ...I(c, [{
				op: "invest",
				n: s.enchanted === null ? 1 : i.n
			}]));
			break;
		case 445:
			F(e, ...I(c, [{
				op: "invest",
				n: 2
			}]));
			break;
		case 509: {
			let t = [];
			s.enchanted !== null && t.push(...I(c, [{
				op: "special",
				id: 509,
				n: i.n
			}])), F(e, ...I(c, [{
				op: "invest",
				n: i.n
			}]), ...t);
			break;
		}
		case 531:
			F(e, ...I(c, [{
				op: "invest",
				n: s.enchanted === null ? 1 : 2
			}]));
			break;
		case 503:
			F(e, ...I(c, [{
				op: "select",
				mode: "telegraph",
				ids: i.cards.filter((e) => a.hand.includes(e)),
				n: 1
			}]));
			break;
		case 543:
			F(e, ...I(c, [{
				op: "gain",
				n: 2
			}, {
				op: "draw",
				n: 1
			}]));
			break;
		case 545:
			F(e, ...I(c, [{
				op: "select",
				mode: "zeroWaste",
				ids: i.cards,
				n: 1
			}]));
			break;
		default: F(e, ...I(c, [{
			op: "invest",
			n: 1
		}]));
	}
}
function Se(e, t, n, r = /* @__PURE__ */ new Set()) {
	if (![
		403,
		409,
		529
	].includes(n)) return !0;
	if (r.has(n)) return !1;
	let i = new Set(r).add(n), a = j(e, t);
	return (n === 409 ? M(e, t).placed : a.placed.filter((e) => E(e.id).cost <= (n === 403 ? a.coins : a.hand.length))).some((n) => E(n.id).kind === "villager" && Se(e, t, n.id, i));
}
function Ce(e, t, n) {
	let r = j(e, t.by), i = P(e, t), a = t.mode, o = t.n ?? 1, s = (n) => F(e, ...I(t, n)), c = (n, r, s = !1, c = o, l = t.by) => {
		let u = Math.min(Math.max(c, 0), n.length);
		if (!u) {
			i && (i.last = []);
			return;
		}
		R(e, l, r, [], {
			cards: n,
			min: s ? 0 : u,
			max: u,
			ordered: a.includes("Trash") || a === "order" || a === "rubyPair",
			task: {
				...t,
				op: "selected"
			}
		});
	}, l = (n, r, i, a = !1, o = {}, s = "chooseCard") => {
		R(e, t.by, s, [...n.map((e) => L(r, I(t, [{
			op: i,
			id: e,
			...o
		}]), { card: e })), ...a ? [L("skip", [])] : []]);
	};
	if (a === "deckTrash") {
		s([{
			op: "selected",
			mode: a,
			ids: q(e, o)
		}]);
		return;
	}
	if (a === "census") {
		let r = q(e, 1);
		r.length && (z(e, "reveal", t.by, { card: r[0] }), K(n, t, "reveal", r, "wv-deck", `wv-pool:${t.by}`), s([{
			op: "selected",
			mode: E(r[0]).species === t.species ? "deckTuck" : "deckDraw",
			ids: r,
			revealed: !0
		}]));
		return;
	}
	if (a === "activate" || a === "supply" || a === "relic" || a === "transfer") {
		l(r.placed.filter((n) => a === "activate" ? E(n.id).kind === "villager" && E(n.id).cost <= o && Se(e, t.by, n.id) : a === "supply" ? E(n.id).kind === "villager" && (!t.species || E(n.id).species === t.species) : a === "relic" ? E(n.id).kind === "gear" : E(n.id).kind === "building" && n.id !== t.source).map((e) => e.id), a === "activate" ? "activate" : a === "supply" ? "supply" : a === "relic" ? "relic" : "invest", a === "activate" ? "activate" : a === "supply" ? "supply" : "selected", !1, a === "relic" || a === "transfer" ? { mode: a } : { n: 1 }, a === "activate" || a === "supply" ? "chooseVillager" : a === "relic" ? "chooseGear" : "chooseBuilding");
		return;
	}
	if (a === "copyOpponent" || a === "copyHand") {
		l(a === "copyOpponent" ? M(e, t.by).placed.filter((n) => E(n.id).kind === "villager" && Se(e, t.by, n.id)).map((e) => e.id) : r.hand.filter((e) => E(e).kind === "villager"), "copy", "selected", a === "copyHand", { mode: a });
		return;
	}
	if (a === "factorReveal") {
		if (e.solo) {
			i.last = i.pool.slice(2), e.revealed = [...i.last], i.poolPublic = [...i.last], K(n, t, "reveal", i.last, `wv-pool:${t.by}`, "wv-revealed");
			return;
		}
		c(i.pool, "factorReveal", !1, 2, M(e, t.by).rid);
		return;
	}
	if (a === "factorChoose") {
		R(e, t.by, "factorChoose", ["revealedDraw", "revealedTuck"].map((e) => L(e, I(t, [{
			op: "selected",
			mode: e
		}]))));
		return;
	}
	if (a.startsWith("hand") && a !== "handSpeciesTuck") {
		c(r.hand, a === "handTrash" ? "trashHand" : "tuckHand");
		return;
	}
	if (a === "handSpeciesTuck") {
		c(r.hand.filter((e) => E(e).species === t.species && E(e).kind === "villager"), "tuckHand", !0);
		return;
	}
	if (a === "order") {
		c(i.pool, "orderPool", !1, i.pool.length);
		return;
	}
	if (a === "rubyPair") {
		c(e.trash, "chooseTrash", !1, 2);
		return;
	}
	if (a.startsWith("pool") && !a.startsWith("poolPlay")) {
		c(a === "poolGearDraw" ? i.pool.filter((e) => E(e).kind === "gear") : i.pool, a.includes("Tuck") ? "tuckPool" : a.includes("Trash") ? "trashPool" : "drawPool", a.endsWith("Optional") || a === "poolGearDraw");
		return;
	}
	if (a === "playGear" || a === "playFree" || a.startsWith("poolPlay") || a === "zeroWaste" || a === "telegraph" || a === "trashPlayTopOptional" || a === "trashPlayTop" || a === "rubyPlay") {
		let n = a.startsWith("pool") ? "pool" : [
			"zeroWaste",
			"trashPlayTopOptional",
			"trashPlayTop",
			"rubyPlay"
		].includes(a) ? "trash" : "hand", s = n === "pool" ? i.pool : n === "trash" ? e.trash : r.hand;
		t.ids && (s = s.filter((e) => t.ids.includes(e))), a.startsWith("trashPlayTop") && (s = e.trash.slice(-1)), (a === "playGear" || a === "zeroWaste") && (s = s.filter((e) => E(e).kind === "gear")), a === "poolPlayDiscount" && (s = s.filter((e) => E(e).species !== t.species));
		let c = a === "playFree" || a === "rubyPlay", l = a === "poolPlayDiscount" ? o : 0;
		s = s.filter((e) => c || r.coins >= Math.max(0, E(e).cost - l));
		let u = a === "playGear" ? I(t, [{
			op: "selected",
			mode: "relic"
		}]) : a === "zeroWaste" && N(e, t.by, t.source)?.enchanted !== null ? I(t, [{
			op: "invest",
			n: 1
		}]) : [], d = s.map((e) => L("play", I(t, [{
			op: "play",
			id: e,
			to: n,
			n: l,
			mode: c ? "free" : "paid",
			steps: u.map((t) => a === "playGear" ? {
				...t,
				id: e
			} : t)
		}]), { card: e }));
		a !== "trashPlayTop" && a !== "playFree" && a !== "playGear" && a !== "rubyPlay" && d.push(L("skip", [])), R(e, t.by, n === "trash" ? "chooseTrash" : "chooseCard", d);
		return;
	}
	if (a.startsWith("trash")) {
		let t = a.includes("Top"), n = t ? e.trash.slice(-1) : e.trash;
		if (!n.length) return;
		let i = a === "trashTuckTop";
		if (i && r.coins < E(n[0]).cost) return;
		if (t) {
			s([...i ? [{
				op: "pay",
				n: E(n[0]).cost
			}] : [], {
				op: "selected",
				mode: a,
				ids: n
			}]);
			return;
		}
		c(n, "chooseTrash");
		return;
	}
}
function we(e, t, n) {
	let r = j(e, t.by), i = P(e, t), a = t.mode, o = t.ids ?? (t.id === void 0 ? [] : [t.id]), s = (n) => F(e, ...I(t, n));
	if (a === "relic") {
		G(n, t.by, "relic", { source: t.id }), oe(e, {
			...t,
			source: t.id,
			f: J(e)
		});
		return;
	}
	if (a === "transfer") {
		let r = N(e, t.by, t.source), i = N(e, t.by, t.id);
		if (r && i) {
			let a = r.supplies;
			i.supplies += a, r.supplies = 0, z(e, "invest", t.by, {
				card: i.id,
				n: i.supplies
			}), a && G(n, t.by, "supply", {
				source: r.id,
				card: i.id,
				supplies: a,
				from: `wv-supply:${r.id}`,
				to: `wv-supply:${i.id}`
			});
		}
		return;
	}
	if (a === "copyHand" || a === "copyOpponent") {
		o.length && s([
			{
				op: "refund",
				id: o[0]
			},
			{
				op: "ability",
				id: o[0]
			},
			...a === "copyHand" ? [{
				op: "selected",
				mode: "handTuckReveal",
				ids: o
			}] : []
		]);
		return;
	}
	if (a === "factorReveal") {
		i.last = [...o], e.revealed = [...o], i.poolPublic = [...o], z(e, "reveal", t.by, { n: o.length }), K(n, t, "reveal", o, `wv-pool:${M(e, t.by).rid}`, "wv-revealed");
		return;
	}
	if (a === "revealedDraw" || a === "revealedTuck") {
		let t = i.last, n = i.pool.filter((e) => !t.includes(e));
		s([{
			op: "selected",
			mode: "poolTuck",
			ids: a === "revealedTuck" ? t : n
		}, {
			op: "selected",
			mode: "poolDraw",
			ids: a === "revealedDraw" ? t : n
		}]), e.revealed = [];
		return;
	}
	if (a === "order") {
		e.deck.unshift(...o), i.pool = [], K(n, t, "return", o, `wv-pool:${t.by}`, "wv-deck", i.poolViewers ?? [t.by]);
		return;
	}
	if (a === "rubyPair") {
		let t = o.filter((t) => e.trash.includes(t));
		e.trash = e.trash.filter((e) => !t.includes(e)), i.pool = t, i.poolPublic = [...t], i.poolFrom = "wv-trash", s([{
			op: "selected",
			mode: "poolTuck",
			ids: t.slice(0, 1)
		}, ...t.length > 1 ? [{
			op: "play",
			id: t[1],
			to: "pool",
			mode: "free"
		}] : []]);
		return;
	}
	let c = a.startsWith("hand") ? r.hand : a.startsWith("trash") ? e.trash : a.startsWith("pool") ? i.pool : null, l = c ? o.filter((e) => c.includes(e)) : o;
	if (c) {
		let t = c.filter((e) => !l.includes(e));
		a.startsWith("hand") ? r.hand = t : a.startsWith("trash") ? e.trash = t : (i.pool = t, c = t);
	}
	if (i && (i.last = [...l]), !l.length) return;
	let u = a.startsWith("hand") ? `wv-hand:${t.by}` : a.startsWith("trash") ? "wv-trash" : a.startsWith("pool") ? `wv-pool:${t.by}` : "wv-deck", d = a.includes("Reveal") || t.revealed || a.startsWith("trash") ? l : l.filter((e) => i?.poolPublic?.includes(e));
	if (a.includes("Reveal") && z(e, "reveal", t.by, {
		card: l[0],
		n: l.length
	}), a.includes("Trash") || a === "deckTrash") {
		e.trash.push(...l), z(e, "trash", t.by, {
			n: l.length,
			card: l.length === 1 ? l[0] : void 0
		}), K(n, t, "trash", l, u, "wv-trash"), F(e, Y(t, "trash", l.length, l));
		return;
	}
	if (a.includes("Tuck") || a === "deckTuck") {
		r.tucked.push(...l), z(e, "tuck", t.by, { n: l.length }), K(n, t, "tuck", l, u, `wv-score:${t.by}`, a.startsWith("pool") ? i.poolViewers ?? [t.by] : [t.by], d), F(e, Y(t, "tuck", l.length, l, { outside: !0 }));
		return;
	}
	if (a === "poolGive") {
		let r = M(e, t.by);
		r.rid === "$wildventure-otto" ? (e.trash.push(...l), F(e, {
			op: "gain",
			by: A,
			n: 1
		})) : (r.hand.push(...l), F(e, Y({
			...t,
			by: r.rid
		}, "draw", l.length, l))), z(e, "draw", r.rid, { n: l.length }), K(n, t, r.rid === "$wildventure-otto" ? "trash" : "give", l, u, r.rid === "$wildventure-otto" ? "wv-trash" : `wv-hand:${r.rid}`, r.rid === "$wildventure-otto" ? void 0 : [t.by, r.rid], d);
		return;
	}
	r.hand.push(...l), z(e, "draw", t.by, { n: l.length }), K(n, t, "draw", l, u, `wv-hand:${t.by}`, [t.by], d), F(e, Y(t, "draw", l.length, l, { nest: t.source === -1 }));
}
function Te(e, t) {
	return I(e, [
		...t.gain ? [{
			op: e.flags?.wizard ? "draw" : "gain",
			n: t.gain
		}] : [],
		...t.draw ? [{
			op: "draw",
			n: t.draw
		}] : [],
		...t.starter ? [{
			op: "reward",
			species: t.starter,
			mode: "starter"
		}] : [],
		...t.chest ? [{
			op: "chest",
			mode: t.chest
		}] : []
	]);
}
function Ee(e, t) {
	let n = j(e, t.by), r = k(e.config.season, n.position), i = t.path ?? [], a = t.n ?? 0, o = a > 0 ? r.next.filter((e) => n.coins >= (e.coins ?? 0) && n.hand.length >= (e.trash ?? 0)) : [];
	if (!o.length) {
		i.length && F(e, {
			...t,
			op: "reward",
			mode: "claim",
			path: i
		});
		return;
	}
	let s = o.map((e) => L("move", I(t, [
		...e.coins ? [{
			op: "pay",
			n: e.coins
		}] : [],
		...e.trash ? [{
			op: "select",
			mode: "handTrash",
			n: e.trash
		}] : [],
		{
			op: "arrive",
			to: e.to
		},
		{
			op: "walk",
			n: a - 1,
			path: [...i, e.to]
		}
	]), {
		node: e.to,
		n: e.coins ?? -(e.trash ?? 0)
	}));
	i.length && s.push(L("stop", [{
		...t,
		op: "reward",
		mode: "claim",
		path: i
	}])), R(e, t.by, "adventure", s);
}
function De(e, t, n) {
	let r = j(e, t.by);
	if (t.flags?.noReward) return;
	if (t.mode === "starter") {
		let n = T.indexOf(t.species);
		R(e, t.by, "chooseStarter", [L("activate", I(t, [{
			op: "starter",
			species: t.species
		}]), { species: t.species }), ...r.starters[n] ? [] : [L("upgrade", I(t, [{
			op: "reward",
			mode: "upgrade",
			species: t.species
		}]), { species: t.species })]]);
		return;
	}
	if (t.mode === "upgrade") {
		let i = T.indexOf(t.species);
		r.starters[i] = !0, z(e, "supply", t.by, {
			card: -i - 1,
			n: 1
		}), G(n, t.by, "upgrade", {
			source: -i - 1,
			origin: t.origin ?? null,
			to: `wv-starter:${t.by}:${i}`
		});
		return;
	}
	if (t.mode === "claim") {
		let n = N(e, t.by, 434) ? [...new Set(t.path ?? [])] : [r.position];
		if (n.length > 1) {
			R(e, t.by, "claimReward", n.map((e) => L("claim", [{
				...t,
				mode: "take",
				to: e
			}], { node: e })));
			return;
		}
		t = {
			...t,
			mode: "take",
			to: r.position
		};
	}
	t = {
		...t,
		origin: `wv-node:${t.to}`
	};
	let i = e.tokens.find((e) => e.node === t.to && e.count > 0), a = k(e.config.season, t.to).reward;
	if (i) {
		if (i.kind === "enchant") {
			r.tokens.includes(i.token) || (r.tokens.push(i.token), i.count--, z(e, "enchant", t.by, { n: i.token }), G(n, t.by, "token", {
				token: i.token,
				from: t.origin,
				to: `wv-tokens:${t.by}`,
				origin: t.origin
			}));
			return;
		}
		a = i.kind === "gold" ? { chest: "gold" } : i.kind === "gain5" ? { gain: 5 } : { starter: "crow" }, i.count--;
	}
	F(e, ...Te(t, a));
}
function Oe(e, t, n) {
	if (t.n !== 1) {
		G(n, t.by, "chest", {
			source: t.source ?? null,
			origin: t.origin ?? null,
			n: t.mode === "iron" ? 1 : t.mode === "gold" ? 2 : 3
		}), F(e, Y(t, "chest", 1), {
			...t,
			n: 1
		});
		return;
	}
	let r = t.mode, i = r === "iron" ? 1 : r === "gold" ? 2 : 3, a = [L("chestHand", I(t, [{
		op: "select",
		mode: "handTuck",
		n: i
	}]), { n: i })];
	t.flags?.chestHand || (a.push(L("chestSpecial", I(t, r === "iron" ? [{
		op: "select",
		mode: "supply",
		n: 1
	}] : r === "gold" ? [{
		op: "select",
		mode: "activate",
		n: 100
	}] : [{
		op: "select",
		mode: "rubyPair",
		n: 2
	}]), { n: i })), a.push(L("chestConsider", I(t, [
		{
			op: "consider",
			n: r === "iron" ? 3 : 5
		},
		...r === "ruby" ? [{
			op: "select",
			mode: "poolTuck",
			n: 1
		}] : [],
		{
			op: "select",
			mode: "poolDraw",
			n: r === "iron" ? 1 : 2
		},
		{
			op: "select",
			mode: "poolTrash",
			n: r === "gold" ? 3 : 2
		},
		{ op: "returnPool" }
	]), { n: i }))), R(e, t.by, "chest", a);
}
function ke(e, t) {
	let n = [
		0,
		0,
		0
	], r = 0, i = 0;
	for (let e of t.tucked) {
		let a = E(e);
		a.kind === "villager" ? n[T.indexOf(a.species)]++ : a.kind === "gear" ? r++ : t.rid === "$wildventure-otto" && (i += a.cost);
	}
	let a = t.placed.filter((e) => e.enchanted !== null).length, o = 0;
	if (t.rid === "$wildventure-otto") {
		if (a = e.config.otto === "hard" ? 3 : 2, e.config.otto === "easy") o = Math.floor(t.coins / 5);
		else for (let r = Math.floor(t.coins / (e.config.otto === "hard" ? 5 : 10)); r > 0; r--) {
			let e = Math.min(...n);
			n[n.indexOf(e)]++;
		}
	} else i = t.placed.filter((e) => E(e.id).kind === "building").reduce((e, t) => e + t.supplies, 0);
	let s = Math.min(...n) * Math.max(...n), c = r * a;
	return {
		villagers: n,
		villagerScore: s,
		gearCount: r,
		multiplier: a,
		gearScore: c,
		buildingScore: i,
		coinScore: o,
		total: s + c + i + o,
		cards: [...t.tucked]
	};
}
function Ae(e, t) {
	if (t.id !== void 0) {
		let n = j(e, t.by), r = t.id;
		if (e.initiates = e.initiates.filter((e) => e !== r), n.species = E(r).species, n.placed.push({
			id: r,
			supplies: t.by === "$wildventure-otto" ? 0 : 2,
			enchanted: null
		}), z(e, "play", t.by, { card: r }), e.solo && t.by !== "$wildventure-otto") {
			F(e, {
				op: "ottoSetup",
				by: A
			});
			return;
		}
		if (e.solo || !e.players.some((e) => !e.species)) {
			e.trash.push(...e.initiates), e.initiates = [], e.drafting = !1, F(e, ...e.config.theme === "mixed" ? e.players.filter((e) => e.rid !== A).map((t) => ({
				op: "select",
				by: t.rid,
				f: J(e),
				mode: "handTrash",
				n: 3
			})) : [], {
				op: "start",
				by: e.players[e.first].rid
			});
			return;
		}
		F(e, {
			op: "draft",
			by: e.players[e.first].rid
		});
		return;
	}
	R(e, t.by === "$wildventure-otto" ? e.players[0].rid : t.by, t.by === "$wildventure-otto" ? "ottoInitiate" : "draft", e.initiates.map((e) => L("chooseInitiate", [{
		...t,
		id: e
	}], { card: e })));
}
function je(t) {
	let n = (t.config.theme === "mixed" ? t.deck : t.ottoDeck).splice(0, 8), r = j(t, A);
	!t.deck.length && t.exhaustedAt === null && (t.exhaustedAt = t.turnNumber);
	for (let i = t.config.otto === "hard" ? 2 : 1; i > 0 && n.length; i--) {
		let i = n.filter((e) => E(e).kind === "villager");
		if (i.length) {
			let e = Math.max(...i.map((e) => E(e).cost));
			i = i.filter((t) => E(t).cost === e);
		} else if (i = n.filter((e) => E(e).kind === "gear"), i.length) {
			let e = Math.max(...i.map((e) => E(e).supplies));
			i = i.filter((t) => E(t).supplies === e);
		} else i = n.filter((e) => E(e).cost === Math.max(...n.map((e) => E(e).cost)));
		let a = i[e(t.seed, t.cursor++, i.length)];
		n.splice(n.indexOf(a), 1), E(a).kind === "building" ? r.tucked.push(a) : r.placed.push({
			id: a,
			supplies: E(a).kind === "gear" ? E(a).supplies : 0,
			enchanted: null
		});
	}
	t.trash.push(..._e(t, n)), z(t, "reveal", A, { n: 8 }), F(t, {
		op: "draft",
		by: A
	});
}
function Me(e, t, n = []) {
	let r = j(e, t.by);
	switch (t.op) {
		case "ability":
			B(e, t);
			break;
		case "special":
			t.id === 509 ? r.coins >= t.n && R(e, t.by, "chooseEffect", [L("payDraw", I(t, [{
				op: "pay",
				n: t.n
			}, {
				op: "draw",
				n: t.n
			}]), { n: t.n }), L("skip", [])]) : V(e, t);
			break;
		case "event":
			be(e, t.event);
			break;
		case "triggers": {
			let n = t.ids.filter((t) => e.players.some((e) => e.placed.some((e) => e.id === t && (E(t).kind !== "gear" || e.supplies > 0)))), r = n.map((e) => L("resolveTrigger", [{
				...t,
				op: "trigger",
				id: e
			}, {
				...t,
				ids: n.filter((t) => t !== e)
			}], { card: e }));
			r.length === 1 ? F(e, ...r[0].tasks) : r.length && R(e, t.by, "chooseTrigger", r);
			break;
		}
		case "trigger":
			xe(e, t, n);
			break;
		case "gain":
			t.n > 0 && (r.coins += t.n, z(e, "gain", t.by, { n: t.n }), F(e, Y(t, "gain", t.n)), G(n, t.by, "gain", {
				source: t.source ?? null,
				origin: t.origin ?? null,
				n: t.n
			}));
			break;
		case "pay":
			if (t.n > 0 && r.coins >= t.n) {
				if (r.coins -= t.n, G(n, t.by, "pay", {
					source: t.source ?? null,
					n: -t.n
				}), t.mode === "give") {
					let r = M(e, t.by);
					r.rid === "$wildventure-otto" ? F(e, {
						op: "gain",
						by: A,
						n: 1
					}) : (r.coins += t.n, z(e, "gain", r.rid, { n: t.n }), G(n, r.rid, "gain", {
						n: t.n,
						from: `wv-coins:${t.by}`
					}));
				}
				r.coins === 0 && F(e, Y(t, "spend", t.n));
			}
			break;
		case "draw": {
			let i = q(e, t.n);
			if (t.by === "$wildventure-otto") {
				e.trash.push(...i), z(e, "trash", A, { n: i.length }), K(n, t, "trash", i, "wv-deck", "wv-trash");
				break;
			}
			r.hand.push(...i), i.length && (z(e, "draw", t.by, { n: i.length }), F(e, Y(t, "draw", i.length, i, { nest: t.source === -1 })), K(n, t, "draw", i, "wv-deck", `wv-hand:${t.by}`, [t.by]));
			break;
		}
		case "select":
			Ce(e, t, n);
			break;
		case "selected":
			we(e, t, n);
			break;
		case "consider": {
			let r = t.mode === "factor" && !e.solo ? M(e, t.by).rid : t.by, i = t.n + +!!N(e, r, 508), a = t.mode === "trash" ? e.trash.splice(Math.max(0, e.trash.length - i)).reverse() : q(e, i);
			P(e, t).pool = a, P(e, t).poolPublic = t.mode === "trash" ? [...a] : [], P(e, t).poolViewers = [r], P(e, t).poolFrom = t.mode === "trash" ? "wv-trash" : "wv-deck", K(n, {
				...t,
				by: r
			}, "consider", a, P(e, t).poolFrom, `wv-pool:${r}`, [r], P(e, t).poolPublic), F(e, Y({
				...t,
				by: r
			}, "consider", i));
			break;
		}
		case "returnPool": {
			let r = P(e, t).pool;
			r.length > 1 ? F(e, {
				...t,
				op: "select",
				mode: "order",
				n: r.length
			}) : (e.deck.unshift(...r), P(e, t).pool = [], K(n, t, "return", r, `wv-pool:${t.by}`, "wv-deck", P(e, t).poolViewers ?? [t.by]));
			break;
		}
		case "play": {
			let i = t.id, a = E(i), o = t.to === "pool" ? P(e, t).pool : t.to === "trash" ? e.trash : r.hand;
			if (!o.includes(i)) break;
			if (t.mode !== "place") {
				let n = t.mode === "free" ? 0 : Math.max(0, a.cost - (t.n ?? 0));
				r.coins >= n && F(e, {
					...t,
					op: "pay",
					n
				}, {
					...t,
					mode: "place"
				});
				break;
			}
			o.splice(o.indexOf(i), 1), r.placed.push({
				id: i,
				supplies: a.kind === "building" ? 0 : a.supplies,
				enchanted: null
			}), z(e, "play", t.by, { card: i }), G(n, t.by, "play", {
				card: i,
				supplies: a.kind === "building" ? 0 : a.supplies,
				from: t.to === "hand" ? `wv-hand:${t.by}` : t.to === "trash" ? "wv-trash" : `wv-pool:${t.by}`
			}), F(e, Y({
				...t,
				source: i
			}, "play", 1, [i], { species: a.species }), ...t.steps ?? []);
			break;
		}
		case "activate": {
			let i = t.mode === "manual" ? t.source ?? t.id : t.id, a = N(e, t.by, i);
			if (!a) break;
			t.mode === "manual" && (a.supplies--, r.used.push(`v${i}`)), z(e, "activate", t.by, { card: i }), G(n, t.by, "activate", {
				source: i,
				supplies: t.mode === "manual" ? -1 : 0
			});
			let o = t.mode === "manual" && t.id && t.id !== i ? t.id : null;
			F(e, {
				...t,
				op: "ability",
				source: i,
				id: o ?? i,
				origin: void 0
			}, ...o && i === 535 ? [{
				...t,
				op: "selected",
				f: J(e),
				mode: "handTuckReveal",
				ids: [o]
			}] : []);
			break;
		}
		case "refund":
			E(t.id).free && e.paidActivation === t.source && (e.actionsLeft++, e.paidActivation = null);
			break;
		case "starter": {
			if (t.by === "$wildventure-otto") {
				F(e, {
					op: "gain",
					by: A,
					n: 1
				});
				break;
			}
			let i = T.indexOf(t.species), a = r.starters[i];
			r.starterUsed = !0;
			let o = J(e), s = -i - 1;
			z(e, "activate", t.by, { card: s }), G(n, t.by, "activate", {
				source: s,
				origin: t.origin ?? null
			}), F(e, Y(t, "starter", 1, [], { species: t.species }), ...I({
				...t,
				f: o,
				source: s,
				origin: void 0
			}, i === 0 ? a ? [
				{
					op: "consider",
					n: 2
				},
				{
					op: "select",
					mode: "poolDraw",
					n: 1
				},
				{ op: "returnPool" }
			] : [{
				op: "draw",
				n: 1
			}] : [{
				op: i === 1 ? "adventure" : "gain",
				n: i === 1 ? a ? 2 : 1 : a ? 3 : 2
			}]));
			break;
		}
		case "supply": {
			let r = N(e, t.by, t.id ?? t.source);
			r && (r.supplies += t.n, z(e, "supply", t.by, {
				card: r.id,
				n: t.n
			}), t.n && G(n, t.by, t.mode === "invest" ? "invest" : "supply", {
				source: t.source ?? null,
				card: r.id,
				origin: t.origin ?? null,
				supplies: t.n,
				from: t.mode === "invest" ? `wv-coins:${t.by}` : null,
				to: `wv-supply:${r.id}`
			}));
			break;
		}
		case "invest": {
			let n = Math.min(r.coins, t.n);
			n > 0 && N(e, t.by, t.source) && R(e, t.by, "invest", Array.from({ length: n + 1 }, (e, n) => L("invest", I(t, [
				{
					op: "pay",
					n
				},
				{
					op: "supply",
					id: t.source,
					n,
					mode: "invest"
				},
				Y(t, "invest", n)
			]), {
				n,
				card: t.source
			})));
			break;
		}
		case "enchant": {
			let r = N(e, t.by, t.source);
			r.enchanted = t.n, z(e, "enchant", t.by, {
				card: r.id,
				n: t.n
			}), G(n, t.by, "enchant", {
				source: r.id,
				card: r.id,
				token: t.n,
				from: `wv-token:${t.by}:${t.n}`,
				to: `wv-enchant:${r.id}`
			}), se(e, {
				...t,
				f: J(e)
			});
			break;
		}
		case "adventure":
			F(e, Y(t, "adventure", t.n), {
				...t,
				op: "walk",
				path: []
			});
			break;
		case "walk":
			Ee(e, t);
			break;
		case "arrive": {
			let i = r.position;
			r.position = t.to, k(e.config.season, t.to).terminal && (r.returnAtEnd = !0), z(e, "move", t.by, { node: t.to }), G(n, t.by, "move", {
				source: t.source ?? null,
				from: `wv-node:${i}`,
				to: `wv-node:${t.to}`
			});
			break;
		}
		case "reward":
			De(e, t, n);
			break;
		case "chest":
			Oe(e, t, n);
			break;
		case "home":
			r.position = "home", r.returnAtEnd = !1, z(e, "home", t.by), F(e, Y(t, "home", 1)), G(n, t.by, "home", { to: "wv-node:home" });
			break;
		case "cleanup": {
			let n = r.placed.filter((e) => e.supplies === 0 && E(e.id).kind !== "building").map((e) => e.id);
			if (!n.length) break;
			R(e, t.by, "cleanup", n.map((n) => L("tuck", [
				...E(n).kind === "gear" ? [{
					op: "selected",
					by: t.by,
					source: n,
					id: n,
					f: J(e),
					mode: "relic"
				}] : [],
				{
					op: "tuckPlayed",
					by: t.by,
					id: n
				},
				t
			], { card: n })));
			break;
		}
		case "tuckPlayed":
			N(e, t.by, t.id) && (r.placed = r.placed.filter((e) => e.id !== t.id), r.tucked.push(t.id), z(e, "tuck", t.by, {
				card: t.id,
				n: 1
			}), K(n, t, "tuck", [t.id], `wv-row:${t.by}:${E(t.id).kind}`, `wv-score:${t.by}`), E(t.id).kind === "villager" && ++e.tuckedVillagers === 2 && F(e, Y(t, "twoVillagers", 2)));
			break;
		case "end":
			if (e.finalTurns === null ? e.exhaustedAt !== null && (e.finalTurns = 2) : e.finalTurns--, e.finalTurns === 0) {
				F(e, {
					op: "finish",
					by: t.by
				});
				break;
			}
			e.turn = 1 - e.turn, e.turnNumber++, F(e, {
				op: "start",
				by: e.players[e.turn].rid
			});
			break;
		case "start":
			e.ending = !1, e.actionsLeft = 2, e.tuckedVillagers = 0, e.paidActivation = null, r.used = [], r.starterUsed = !1, e.frames = {}, e.revealed = [], z(e, "turn", t.by), t.by === "$wildventure-otto" ? F(e, {
				op: "ottoGear",
				by: A
			}, {
				op: "ottoReveal",
				by: A
			}, {
				op: "end",
				by: A
			}) : e.jackbot && (e.jackbot = !1, R(e, t.by, "jackbot", T.map((e) => L("chooseStarter", [{
				op: "starter",
				by: t.by,
				species: e
			}], { species: e }))));
			break;
		case "draft":
			Ae(e, t);
			break;
		case "ottoSetup":
			je(e);
			break;
		case "ottoGear": {
			let i = t.ids ?? e.players.flatMap((e) => e.placed.filter((e) => E(e.id).kind === "gear" && e.supplies > 0).map((e) => e.id));
			if (!i.length) break;
			let a = e.players.flatMap((e) => e.placed).find((e) => e.id === i[0]);
			a.supplies--, r.coins++, z(e, "gain", A, {
				card: a.id,
				n: 1
			});
			let o = r.placed.some((e) => e.id === a.id);
			G(n, A, "gain", {
				source: a.id,
				sourceOwner: e.players.find((e) => e.placed.some((e) => e.id === a.id)).rid,
				n: 1,
				supplies: -1
			}), F(e, ...o && a.supplies === 0 ? [{
				op: "tuckPlayed",
				by: A,
				id: a.id
			}] : [], {
				...t,
				ids: i.slice(1)
			});
			break;
		}
		case "ottoReveal": {
			if (!e.deck.length) break;
			let r = e.ottoDeck.length === 1 ? null : e.ottoDeck.length ? "wv-otto-deck" : "wv-deck", i = [];
			for (let t = 0; t < 2; t++) e.ottoDeck.length ? i.push(e.ottoDeck.shift()) : i.push(...q(e, 1));
			if (e.revealed = i, !i.length) break;
			let a = Math.min(...i.map((e) => E(e).cost)), o = i.filter((e) => E(e).cost === a), s = i.filter((e) => !o.includes(e));
			o.length === 2 && (e.jackbot = !0), z(e, o.length === 2 ? "jackbot" : "reveal", A, { n: i.length }), K(n, t, "reveal", i, r, "wv-revealed"), F(e, ...o.map((e) => ({
				op: "ottoUse",
				by: A,
				id: e
			})), {
				op: "ottoTrash",
				by: A,
				ids: s
			});
			break;
		}
		case "ottoUse":
			E(t.id).kind === "gear" ? r.placed.push({
				id: t.id,
				supplies: E(t.id).supplies,
				enchanted: null
			}) : r.tucked.push(t.id), z(e, E(t.id).kind === "gear" ? "play" : "tuck", A, {
				card: t.id,
				n: 1
			}), E(t.id).kind === "gear" ? G(n, A, "play", {
				card: t.id,
				supplies: E(t.id).supplies,
				from: "wv-revealed"
			}) : K(n, t, "tuck", [t.id], "wv-revealed", `wv-score:${A}`);
			break;
		case "ottoTrash":
			e.trash.push(...t.ids), e.revealed = [], t.ids.length && (z(e, "trash", A, {
				card: t.ids[0],
				n: t.ids.length
			}), K(n, t, "trash", t.ids, "wv-revealed", "wv-trash"));
			break;
		case "finish":
			for (let t of e.players) {
				if (t.rid === "$wildventure-otto") t.tucked.push(...t.placed.map((e) => e.id)), t.placed = [];
				else {
					let e = t.placed.filter((e) => E(e.id).kind === "gear" && e.supplies === 0);
					t.tucked.push(...e.map((e) => e.id)), t.placed = t.placed.filter((t) => !e.includes(t));
				}
				e.trash.push(...t.hand), t.hand = [], t.score = ke(e, t);
			}
			e.done = !0, z(e, "finish", t.by);
	}
}
function Ne(e, t) {
	if (e.done || e.drafting || e.ending || e.queue.length || e.decision || e.players[e.turn].rid !== t || t === "$wildventure-otto") return [];
	let n = j(e, t), r = [];
	if (e.actionsLeft > 0) {
		for (let e of n.hand.filter((e) => E(e).cost <= n.coins)) r.push({
			id: `play:${e}`,
			label: "play",
			card: e,
			tasks: [{
				op: "play",
				by: t,
				id: e,
				to: "hand",
				mode: "paid"
			}]
		});
		for (let e of T) n.used.includes(`s${e}`) || r.push({
			id: `starter:${e}`,
			label: "activate",
			species: e,
			tasks: [{
				op: "starter",
				by: t,
				species: e
			}]
		});
	}
	for (let i of n.placed.filter((e) => E(e.id).kind === "villager" && e.supplies > 0 && !n.used.includes(`v${e.id}`))) {
		let a = E(i.id), o = i.id === 409 ? M(e, t).placed.filter((e) => E(e.id).kind === "villager").map((e) => e.id) : i.id === 535 ? n.hand.filter((e) => E(e).kind === "villager") : [];
		if (o.length) for (let n of o) {
			let a = E(n).free;
			(a || e.actionsLeft > 0) && r.push({
				id: `activate:${i.id}:${n}`,
				label: "copy",
				card: i.id,
				n,
				free: a,
				tasks: [{
					op: "activate",
					by: t,
					source: i.id,
					id: n,
					mode: "manual"
				}]
			});
		}
		else (a.free || e.actionsLeft > 0) && r.push({
			id: `activate:${i.id}`,
			label: "activate",
			card: i.id,
			free: a.free,
			tasks: [{
				op: "activate",
				by: t,
				source: i.id,
				mode: "manual"
			}]
		});
	}
	let i = n.tokens.filter((e) => !n.placed.some((t) => t.enchanted === e));
	for (let e of n.placed.filter((e) => E(e.id).kind === "building" && e.enchanted === null)) for (let n of i) r.push({
		id: `enchant:${e.id}:${n}`,
		label: "enchant",
		card: e.id,
		token: n,
		free: !0,
		tasks: [{
			op: "enchant",
			by: t,
			source: e.id,
			n
		}]
	});
	return e.actionsLeft === 0 && r.push({
		id: "end",
		label: "endTurn",
		tasks: [
			...n.returnAtEnd || k(e.config.season, n.position).terminal ? [{
				op: "home",
				by: t
			}] : [],
			{
				op: "cleanup",
				by: t
			},
			{
				op: "end",
				by: t
			}
		]
	}), r;
}
function Pe(e, t) {
	return e.decision ? e.decision.by === t ? e.decision.options : [] : Ne(e, t);
}
function Fe(t, n, r) {
	let i = n.length === 1, a = {
		config: t,
		seed: r,
		cursor: 0,
		solo: i,
		deck: [],
		ottoDeck: [],
		trash: [],
		revealed: [],
		tokens: [],
		players: (i ? [...n, A] : n).map((e) => ({
			rid: e,
			coins: e === "$wildventure-otto" ? 0 : 5,
			hand: [],
			tucked: [],
			placed: [],
			starters: [
				!1,
				!1,
				!1
			],
			tokens: [],
			used: [],
			position: "home",
			species: null,
			starterUsed: !1,
			returnAtEnd: !1,
			score: null
		})),
		turn: 0,
		first: 0,
		turnNumber: 1,
		actionsLeft: 2,
		finalTurns: null,
		exhaustedAt: null,
		queue: [],
		frames: {},
		frameCounter: 0,
		decisionCounter: 0,
		decision: null,
		drafting: !0,
		ending: !1,
		done: !1,
		initiates: [...re],
		jackbot: !1,
		tuckedVillagers: 0,
		scene: null,
		log: [],
		seq: 0,
		paidActivation: null
	};
	a.deck = _e(a, w.filter((e) => e.group !== "initiate" && (e.group === "core" || t.theme === "mixed" || e.group === t.theme)).map((e) => e.id)), i && t.theme !== "mixed" && (a.ottoDeck = _e(a, w.filter((e) => e.group === (t.theme === "academy" ? "tidings" : "academy")).map((e) => e.id)));
	let o = _e(a, [
		0,
		1,
		2
	]);
	a.players.filter((e) => e.rid !== A).forEach((e) => {
		e.tokens = [o[2]], e.hand = q(a, t.theme === "mixed" ? 8 : 5);
	});
	let s = t.season === "autumn";
	return a.tokens = [
		{
			node: s ? "l7" : "l12",
			kind: "enchant",
			token: o[0],
			count: 2
		},
		{
			node: s ? "m16" : "m12",
			kind: "enchant",
			token: o[1],
			count: 2
		},
		{
			node: s ? "temple" : "m17",
			kind: "gold",
			count: 1
		},
		...(s ? ["l8", "l10"] : ["l6", "l8"]).map((e) => ({
			node: e,
			kind: "gain5",
			count: 1
		})),
		...(s ? [
			"l4",
			"l5",
			"r2"
		] : [
			"l10",
			"m6",
			"m9"
		]).map((e) => ({
			node: e,
			kind: "nest",
			count: 1
		}))
	], a.first = i ? 0 : e(r, a.cursor++, 2), a.turn = a.first, Me(a, {
		op: "draft",
		by: a.players[i ? 0 : 1 - a.first].rid
	}), { state: a };
}
var Ie = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: H,
	schemas: {
		action: le,
		publicView: he,
		privateView: ge,
		config: U
	},
	setup: Fe,
	reduce(e, t, { by: n }) {
		if (t.type === "tick") {
			if (n !== "$engine" || e.done || e.decision || !e.queue.length) return { state: e };
			let t = structuredClone(e), r = t.queue.shift(), i = [];
			Me(t, r, i);
			for (let t of i) {
				let n = t.data, r = e.players.find((e) => e.placed.some((e) => e.id === n.source));
				r && (n.sourceOwner = r.rid);
			}
			return {
				state: t,
				...i.length ? { fx: i } : {}
			};
		}
		if (e.done) return { code: "games.wildventure.errFinished" };
		if (t.type === "pick") {
			let r = e.decision?.by === n ? e.decision.selection : null;
			if (!r || t.cards.length < r.min || t.cards.length > r.max || new Set(t.cards).size !== t.cards.length || t.cards.some((e) => !r.cards.includes(e))) return { code: "games.wildventure.errChoice" };
			let i = structuredClone(e);
			return F(i, {
				...r.task,
				ids: [...t.cards]
			}), i.decision = null, { state: i };
		}
		let r = Pe(e, n).find((e) => e.id === t.id);
		if (!r) return { code: "games.wildventure.errChoice" };
		let i = structuredClone(e);
		return i.decision ? i.decision = null : r.label === "enchant" || (r.label === "endTurn" ? i.ending = !0 : (r.free || i.actionsLeft--, r.species && j(i, n).used.push(`s${r.species}`), i.paidActivation = !r.free && (r.label === "activate" || r.label === "copy") ? r.card ?? null : null)), F(i, ...r.tasks), { state: i };
	},
	viewFor(e, t) {
		let n = e.players.find((e) => e.rid === t), r = e.decision, i = r?.by === t, a = r?.prompt === "factorReveal", o = i && r?.selection ? [...r.selection.cards] : [];
		return {
			public: {
				phase: e.done ? "done" : r ? e.drafting ? "draft" : "choose" : e.queue.length ? "resolve" : "main",
				turn: e.players[e.turn].rid,
				chooser: r?.by ?? null,
				prompt: r?.prompt ?? null,
				turnNumber: e.turnNumber,
				actionsLeft: e.actionsLeft,
				finalTurns: e.finalTurns,
				config: e.config,
				solo: e.solo,
				deckCount: e.deck.length,
				ottoDeckCount: e.ottoDeck.length,
				trash: [...e.trash],
				revealed: [...e.revealed],
				tokens: e.tokens.filter((e) => e.count > 0),
				players: e.players.map((e) => ({
					rid: e.rid,
					coins: e.coins,
					handCount: e.hand.length,
					tuckedCount: e.tucked.length,
					placed: e.placed,
					starters: e.starters,
					tokens: e.tokens,
					used: e.used,
					position: e.position,
					species: e.species,
					score: e.score
				})),
				scene: e.scene,
				log: e.log.slice(-60)
			},
			private: n ? {
				hand: [...n.hand],
				tucked: e.done || e.config.noMemory ? [...n.tucked] : null,
				moves: Pe(e, t).map((e) => ({
					id: e.id,
					label: e.label,
					card: e.card,
					n: e.n,
					species: e.species,
					node: e.node,
					free: e.free,
					token: e.token
				})),
				selection: i && r.selection ? {
					cards: [...r.selection.cards],
					min: r.selection.min,
					max: r.selection.max,
					ordered: r.selection.ordered
				} : null,
				pool: a && !i ? [] : o
			} : void 0
		};
	},
	status(e) {
		if (!e.done) return { phase: e.decision ? "choose" : "playing" };
		let t = [...e.players].sort((t, n) => n.score.total - t.score.total || (e.config.tiebreak ? n.coins - t.coins || n.score.villagerScore - t.score.villagerScore : 0)), n = t[0];
		return {
			phase: "done",
			winner: t.filter((t) => t.score.total === n.score.total && (!e.config.tiebreak || t.coins === n.coins && t.score.villagerScore === n.score.villagerScore)).map((e) => e.rid),
			ranking: t.map((e) => e.rid),
			scores: Object.fromEntries(e.players.map((e) => [e.rid, e.score.total]))
		};
	},
	nextTickIn(e) {
		return !e.done && !e.decision && e.queue.length ? 460 : null;
	}
}, Le = {
	main: "games.wildventure.promptMain",
	draft: "games.wildventure.promptDraft",
	ottoInitiate: "games.wildventure.promptOttoInitiate",
	trashHand: "games.wildventure.promptTrashHand",
	tuckHand: "games.wildventure.promptTuckHand",
	drawPool: "games.wildventure.promptDrawPool",
	tuckPool: "games.wildventure.promptTuckPool",
	trashPool: "games.wildventure.promptTrashPool",
	orderPool: "games.wildventure.promptOrderPool",
	chooseCard: "games.wildventure.promptChooseCard",
	chooseVillager: "games.wildventure.promptChooseVillager",
	chooseBuilding: "games.wildventure.promptChooseBuilding",
	chooseGear: "games.wildventure.promptChooseGear",
	chooseStarter: "games.wildventure.promptChooseStarter",
	chooseSpecies: "games.wildventure.promptChooseSpecies",
	chooseEffect: "games.wildventure.promptChooseEffect",
	chooseTrigger: "games.wildventure.promptChooseTrigger",
	adventure: "games.wildventure.promptAdventure",
	claimReward: "games.wildventure.promptClaimReward",
	chest: "games.wildventure.promptChest",
	cleanup: "games.wildventure.promptCleanup",
	factorReveal: "games.wildventure.promptFactorReveal",
	factorChoose: "games.wildventure.promptFactorChoose",
	invest: "games.wildventure.promptInvest",
	workshop: "games.wildventure.promptWorkshop",
	chooseTrash: "games.wildventure.promptChooseTrash",
	jackbot: "games.wildventure.promptJackbot"
}, Re = {
	play: "games.wildventure.movePlay",
	activate: "games.wildventure.moveActivate",
	enchant: "games.wildventure.moveEnchant",
	endTurn: "games.wildventure.moveEndTurn",
	skip: "games.wildventure.moveSkip",
	gain: "games.wildventure.moveGain",
	draw: "games.wildventure.moveDraw",
	adventure: "games.wildventure.moveAdventure",
	both: "games.wildventure.moveBoth",
	tuck: "games.wildventure.moveTuck",
	trash: "games.wildventure.moveTrash",
	returnTop: "games.wildventure.moveReturnTop",
	invest: "games.wildventure.moveInvest",
	upgrade: "games.wildventure.moveUpgrade",
	supply: "games.wildventure.moveSupply",
	relic: "games.wildventure.moveRelic",
	chooseStarter: "games.wildventure.moveChooseStarter",
	chooseSpecies: "games.wildventure.moveChooseSpecies",
	move: "games.wildventure.moveMove",
	stop: "games.wildventure.moveStop",
	claim: "games.wildventure.moveClaim",
	chestHand: "games.wildventure.moveChestHand",
	chestSpecial: "games.wildventure.moveChestSpecial",
	chestConsider: "games.wildventure.moveChestConsider",
	resolveTrigger: "games.wildventure.moveResolveTrigger",
	copy: "games.wildventure.moveCopy",
	trashTop: "games.wildventure.moveTrashTop",
	revealedDraw: "games.wildventure.moveRevealedDraw",
	revealedTuck: "games.wildventure.moveRevealedTuck",
	escDrawTrash: "games.wildventure.moveEscDrawTrash",
	escDrawGive: "games.wildventure.moveEscDrawGive",
	payDraw: "games.wildventure.movePayDraw",
	removeSupply: "games.wildventure.moveRemoveSupply",
	keepSupply: "games.wildventure.moveKeepSupply",
	continue: "games.wildventure.moveContinue",
	workshopTake: "games.wildventure.moveWorkshopTake",
	chooseInitiate: "games.wildventure.moveChooseInitiate"
}, ze = {
	play: "games.wildventure.scenePlay",
	activate: "games.wildventure.sceneActivate",
	gain: "games.wildventure.sceneGain",
	draw: "games.wildventure.sceneDraw",
	trash: "games.wildventure.sceneTrash",
	tuck: "games.wildventure.sceneTuck",
	invest: "games.wildventure.sceneInvest",
	move: "games.wildventure.sceneMove",
	home: "games.wildventure.sceneHome",
	enchant: "games.wildventure.sceneEnchant",
	supply: "games.wildventure.sceneSupply",
	reveal: "games.wildventure.sceneReveal",
	turn: "games.wildventure.sceneTurn",
	jackbot: "games.wildventure.sceneJackbot",
	finish: "games.wildventure.sceneFinish"
}, Be = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path fill=\"#d9e9df\" stroke=\"none\" d=\"M0 0H200V160H0z\"/><circle cx=\"159\" cy=\"29\" r=\"20\" fill=\"#fff9d9\" stroke=\"none\"/><path d=\"M0 130Q46 105 94 128T200 117V160H0z\" fill=\"#bed6be\" stroke=\"none\"/><path d=\"M11 101q8-18 16-3m148 15q8-21 13-6M24 132l-5-8m142 10 5-8\" stroke=\"#76a896\" stroke-width=\"2\"/>\r\n<path d=\"M79 123l-4 24m30-24 3 23m-40 1h16m17 0h16\" stroke=\"#98713f\" stroke-width=\"4\"/>\r\n<path d=\"M58 83q-24-20-38-5l27 33 30-3m60-29q24-12 42 0l-27 23-23 2\" fill=\"#526b73\"/>\r\n<path d=\"M66 63q-13 33-7 59 37 20 72-4l-4-48z\" fill=\"#67868a\"/>\r\n<path d=\"M78 62q-9 43 6 68l24-2 10-61\" fill=\"#e4c578\"/>\r\n<path d=\"M79 74l27 10 14-12M81 88l22 5\" stroke=\"#a77b40\"/>\r\n<path d=\"M90 78c-31-4-32-39-16-49q13-11 30-1 19 10 15 35l-16 15z\" fill=\"#405962\"/>\r\n<path d=\"M111 46l29 13-30 7\" fill=\"#f4c35f\"/>\r\n<circle cx=\"102\" cy=\"44\" r=\"4.2\" fill=\"#fff9e8\" stroke=\"none\"/><circle cx=\"103\" cy=\"44\" r=\"2\" fill=\"#243f3b\" stroke=\"none\"/>\r\n<path d=\"M68 34l-7-8 19-9 30 5 2 12z\" fill=\"#73b3a5\"/>\r\n<path d=\"M62 35q26 8 55-1\" stroke=\"#294e46\" stroke-width=\"5\"/><path d=\"M80 25h17\" stroke=\"#f5d276\"/>\r\n<path d=\"M62 78l65 45\" stroke=\"#9b663d\" stroke-width=\"6\"/>\r\n<rect x=\"108\" y=\"98\" width=\"36\" height=\"28\" rx=\"5\" fill=\"#ca8e57\"/>\r\n<path d=\"M108 105l17 10 19-10\" stroke=\"#765339\"/><path d=\"M122 113h7v8h-7z\" fill=\"#f5d276\"/>\r\n<path d=\"M39 77l14-2 5 22-20 2z\" fill=\"#fff8e5\"/><path d=\"M39 78l10 8 7-7\" stroke-width=\"1.5\"/>\r\n</g></svg>", Ve = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path fill=\"#e5def2\" stroke=\"none\" d=\"M0 0H200V160H0z\"/><circle cx=\"159\" cy=\"29\" r=\"20\" fill=\"#fff9d9\" stroke=\"none\"/><path d=\"M0 130Q46 105 94 128T200 117V160H0z\" fill=\"#c4dcbf\" stroke=\"none\"/><path d=\"M11 101q8-18 16-3m148 15q8-21 13-6M24 132l-5-8m142 10 5-8\" stroke=\"#76a896\" stroke-width=\"2\"/>\r\n<path d=\"M77 130l-10 17h21m28-17 10 17h-20\" fill=\"#84b578\"/>\r\n<path d=\"M73 76q-14 29-16 59 38 12 75-1-4-39-18-56z\" fill=\"#9b9bc5\"/>\r\n<path d=\"M72 89l24 15 21-17m-17 16-5 29\" stroke=\"#65678f\"/>\r\n<path d=\"M107 110l5-8 3 8 9 2-8 5-1 9-6-7-9 1 4-7z\" fill=\"#ffdb81\" stroke=\"none\"/>\r\n<path d=\"M64 95l-13 12-15-3m85-11 18 11 17-11\" stroke=\"#6a9e70\" stroke-width=\"9\"/>\r\n<path d=\"M155 64l-4 82\" stroke=\"#997b4c\" stroke-width=\"5\"/>\r\n<path d=\"M153 74q-12-11-2-20 18-5 17 9-4 11-13 7\" fill=\"#b2d9c4\"/>\r\n<path d=\"M135 42l-4-8m38 10 7-5m-13-15 1-7\" stroke=\"#b8a1d1\"/>\r\n<path d=\"M65 63q-7-23 13-26 12-7 20 6 15-11 26 0 19 22-7 39-33 14-52-6z\" fill=\"#90bd7a\"/>\r\n<circle cx=\"80\" cy=\"50\" r=\"8\" fill=\"#eaf1bb\"/><circle cx=\"108\" cy=\"50\" r=\"8\" fill=\"#eaf1bb\"/>\r\n<path d=\"M81 48v5m26-5v5m-28 15q15 11 30-1\"/>\r\n<path d=\"M62 43l13-6 21-34 12 30 18 7q-24 13-64 3z\" fill=\"#8d8eb9\"/>\r\n<path d=\"M77 33l25 2\" stroke=\"#d8c9e8\" stroke-width=\"5\"/><path d=\"M91 21l2-4 4 5-5 2z\" fill=\"#ffdb81\" stroke=\"none\"/>\r\n<path d=\"M41 134q-19-7-25 8 14 7 25-8z\" fill=\"#82b28b\"/><path d=\"M44 135l7-13\"/>\r\n</g></svg>", He = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path fill=\"#f7dfd2\" stroke=\"none\" d=\"M0 0H200V160H0z\"/><circle cx=\"159\" cy=\"29\" r=\"20\" fill=\"#fff9d9\" stroke=\"none\"/><path d=\"M0 130Q46 105 94 128T200 117V160H0z\" fill=\"#d5dfb3\" stroke=\"none\"/><path d=\"M11 101q8-18 16-3m148 15q8-21 13-6M24 132l-5-8m142 10 5-8\" stroke=\"#76a896\" stroke-width=\"2\"/>\r\n<path d=\"M77 126l-9 21h21m27-21 10 21h-22\" fill=\"#fff4d9\"/>\r\n<path d=\"M76 75q-19 23-17 59 35 10 70-1 1-36-17-57z\" fill=\"#faf1d8\"/>\r\n<path d=\"M73 79l11 15 19-2 11-14 8 56-56 1z\" fill=\"#7caa9a\"/>\r\n<path d=\"M84 93l-3 19 28-1-5-19m-22 30h26v13H81z\" fill=\"#b8d1b2\"/>\r\n<path d=\"M76 39q-17-35-4-37 12-1 17 35m14 1q8-37 20-33 12 5-7 40\" fill=\"#fff4dc\"/>\r\n<path d=\"M77 27l-4-14m37 15 8-13\" stroke=\"#e5a798\" stroke-width=\"5\"/>\r\n<path d=\"M65 57q-1-26 28-23 34-2 35 28-8 25-34 24-27-1-29-29z\" fill=\"#fff4dc\"/>\r\n<path d=\"M77 55v3m32-3v3\" stroke-width=\"4\"/>\r\n<path d=\"M90 61h8l-4 5z\" fill=\"#d99485\" stroke=\"none\"/><path d=\"M94 66v5m-8-1q8 7 16 0\" stroke-width=\"2\"/>\r\n<path d=\"M61 66l15 1m-14 6 14-2m38-4 17-2m-16 6 14 3\" stroke=\"#b29b78\" stroke-width=\"1.6\"/>\r\n<path d=\"M55 97l-8 13 20 6m57-18 18 12-11 12\" stroke=\"#f6e6c3\" stroke-width=\"10\"/>\r\n<path d=\"M138 121l-2-35m0 18 13-10m-14 4-10-9\" stroke=\"#679b6c\"/>\r\n<path d=\"M123 119h29l-5 25h-19z\" fill=\"#d99165\"/>\r\n<g fill=\"#eaa19a\" stroke=\"#bf777a\" stroke-width=\"1.5\"><circle cx=\"135\" cy=\"81\" r=\"6\"/><circle cx=\"142\" cy=\"85\" r=\"6\"/><circle cx=\"138\" cy=\"92\" r=\"6\"/><circle cx=\"130\" cy=\"90\" r=\"6\"/><circle cx=\"129\" cy=\"83\" r=\"6\"/></g><circle cx=\"136\" cy=\"86\" r=\"4\" fill=\"#f9d675\" stroke=\"none\"/>\r\n</g></svg>", Ue = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path fill=\"#d8e6e2\" stroke=\"none\" d=\"M0 0H200V160H0z\"/><circle cx=\"159\" cy=\"29\" r=\"20\" fill=\"#fff9d9\" stroke=\"none\"/><path d=\"M0 130Q46 105 94 128T200 117V160H0z\" fill=\"#c9d8bd\" stroke=\"none\"/><path d=\"M11 101q8-18 16-3m148 15q8-21 13-6M24 132l-5-8m142 10 5-8\" stroke=\"#76a896\" stroke-width=\"2\"/>\r\n<path d=\"M75 128l-6 19h17m24-19 4 19h15\" stroke=\"#a37a45\" stroke-width=\"4\"/>\r\n<path d=\"M69 74q-15 28-13 61 42 10 79-3-1-40-20-60z\" fill=\"#547b7b\"/>\r\n<path d=\"M81 77l17 22 14-22-5 54-24 1z\" fill=\"#efddae\"/>\r\n<path d=\"M80 75l-8 22 11 7-9 8m39-37 10 22-12 7 9 7\" stroke=\"#345c5a\"/>\r\n<path d=\"M77 75q-25-16-12-39 13-18 33-11 28 9 22 34l-12 15z\" fill=\"#3f5560\"/>\r\n<path d=\"M116 45l26 13-29 4\" fill=\"#efbc5f\"/>\r\n<circle cx=\"103\" cy=\"44\" r=\"5\" fill=\"#fff5d8\" stroke-width=\"1.5\"/><path d=\"M107 49l7 7\" stroke-width=\"1.5\"/>\r\n<path d=\"M65 33V20q24-8 45 2l5 12z\" fill=\"#477b76\"/><path d=\"M64 33h55\" stroke-width=\"5\"/>\r\n<path d=\"M89 23l5-5 5 5-5 5z\" fill=\"#f8d780\" stroke=\"none\"/>\r\n<path d=\"M55 104l-8 12 32 11m55-26 13 16-16 10\" stroke=\"#4e6d73\" stroke-width=\"10\"/>\r\n<path d=\"M64 112l30-11 18 29-31 11z\" fill=\"#d49462\"/><path d=\"M76 115l17-6 10 17-17 6z\" fill=\"#fff2d3\" stroke-width=\"1.5\"/>\r\n<circle cx=\"120\" cy=\"111\" r=\"3\" fill=\"#efc469\" stroke=\"none\"/>\r\n</g></svg>", We = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path fill=\"#f2e3c7\" stroke=\"none\" d=\"M0 0H200V160H0z\"/><circle cx=\"159\" cy=\"29\" r=\"20\" fill=\"#fff9d9\" stroke=\"none\"/><path d=\"M0 130Q46 105 94 128T200 117V160H0z\" fill=\"#d9dfb7\" stroke=\"none\"/><path d=\"M11 101q8-18 16-3m148 15q8-21 13-6M24 132l-5-8m142 10 5-8\" stroke=\"#76a896\" stroke-width=\"2\"/>\r\n<path d=\"M60 90V52q0-29 37-29 41 0 43 35v29\" stroke=\"#aa7149\" stroke-width=\"14\"/>\r\n<path d=\"M61 89V53q0-29 37-29 40 0 41 34v26\" stroke=\"#e2b67e\" stroke-width=\"8\"/>\r\n<path d=\"M59 80l66-15 19 71-74 11z\" fill=\"#bc7a4c\"/>\r\n<path d=\"M59 77q35-14 71-11l8 29q-38 20-73 13z\" fill=\"#dba46c\"/>\r\n<path d=\"M68 106l7 29 59-10-5-23\" stroke=\"#f0c28b\" stroke-width=\"2\"/>\r\n<path d=\"M94 99l13-2 4 22-13 2z\" fill=\"#f3d077\"/><path d=\"M100 105l4-1 1 8-4 1z\" fill=\"#76583c\" stroke=\"none\"/>\r\n<path d=\"M83 72l-6-24 40-9 6 25\" fill=\"#fff9e8\"/><path d=\"M79 49l22 10 15-18\" stroke=\"#acb4a0\" stroke-width=\"2\"/>\r\n<path d=\"M35 77l-7-8m133 41 9-3m-20-64 6-8\" stroke=\"#b49d70\" stroke-width=\"2\"/>\r\n</g></svg>", Ge = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path fill=\"#e6e9ce\" stroke=\"none\" d=\"M0 0H200V160H0z\"/><circle cx=\"159\" cy=\"29\" r=\"20\" fill=\"#fff9d9\" stroke=\"none\"/><path d=\"M0 130Q46 105 94 128T200 117V160H0z\" fill=\"#c9dbb5\" stroke=\"none\"/><path d=\"M11 101q8-18 16-3m148 15q8-21 13-6M24 132l-5-8m142 10 5-8\" stroke=\"#76a896\" stroke-width=\"2\"/>\r\n<path d=\"M53 33h77l14 16v91H53z\" fill=\"#fff8dc\"/><path d=\"M130 33v18h14\" fill=\"#e5c98f\"/>\r\n<path d=\"M67 57h46m-46 12h58m-58 12h44m-44 12h58\" stroke=\"#a9b197\" stroke-width=\"3\"/>\r\n<circle cx=\"112\" cy=\"116\" r=\"13\" fill=\"#d89a78\"/><path d=\"M105 126l-3 20 10-5 8 5-2-19\" fill=\"#d89a78\"/>\r\n<path d=\"M105 115l5 5 9-10\" stroke=\"#fff4da\"/>\r\n<path d=\"M40 110l21-22q9-9 14-5-2 10-14 17l-21 13z\" fill=\"#668f8a\"/><path d=\"M40 110l-4 7\"/>\r\n</g></svg>", Ke = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path fill=\"#dce3ed\" stroke=\"none\" d=\"M0 0H200V160H0z\"/><circle cx=\"159\" cy=\"29\" r=\"20\" fill=\"#fff9d9\" stroke=\"none\"/><path d=\"M0 130Q46 105 94 128T200 117V160H0z\" fill=\"#c2d3c5\" stroke=\"none\"/><path d=\"M11 101q8-18 16-3m148 15q8-21 13-6M24 132l-5-8m142 10 5-8\" stroke=\"#76a896\" stroke-width=\"2\"/>\r\n<path d=\"M61 129l55-78q8-11 18-4l13 9-9 13-13-5-50 74z\" fill=\"#8c9d9c\"/>\r\n<path d=\"M77 118l32-45 12 8-33 45z\" fill=\"#dc9b68\"/>\r\n<path d=\"M81 112l11 8m-5-16 11 8m-5-16 11 8\" stroke=\"#b4744e\" stroke-width=\"2\"/>\r\n<path d=\"M61 129l-7 13 14-3 7-1\" fill=\"#6e8385\"/><path d=\"M125 64l7-8 9 5\" stroke=\"#c5d2ce\" stroke-width=\"3\"/>\r\n<path d=\"M44 58l6-14m-7 5 10 5m105 51 6-13m-9 4 11 4\" stroke=\"#b8aa78\" stroke-width=\"2\"/>\r\n</g></svg>", qe = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path fill=\"#e5eccc\" stroke=\"none\" d=\"M0 0H200V160H0z\"/><circle cx=\"159\" cy=\"29\" r=\"20\" fill=\"#fff9d9\" stroke=\"none\"/><path d=\"M0 130Q46 105 94 128T200 117V160H0z\" fill=\"#c8d5a5\" stroke=\"none\"/><path d=\"M11 101q8-18 16-3m148 15q8-21 13-6M24 132l-5-8m142 10 5-8\" stroke=\"#76a896\" stroke-width=\"2\"/>\r\n<path d=\"M39 83h121v54H39z\" fill=\"#f9e7b1\"/>\r\n<path d=\"M27 85q8-53 73-56 61 3 73 56z\" fill=\"#d68d76\"/>\r\n<path d=\"M34 74q66 18 132 0m-123-14q57 15 113 1\" stroke=\"#b76d60\" stroke-width=\"2\"/>\r\n<path d=\"M83 138V99q16-15 32 0v39\" fill=\"#6c9f91\"/><path d=\"M99 94v43\" stroke=\"#4c7d75\"/>\r\n<circle cx=\"107\" cy=\"117\" r=\"2\" fill=\"#f6d17e\" stroke=\"none\"/>\r\n<path d=\"M49 96h21v22H49zM129 96h21v22h-21z\" fill=\"#a9cdbd\"/><path d=\"M59 97v20m-9-10h19m70-10v20m-9-10h20\" stroke-width=\"1.5\"/>\r\n<path d=\"M85 67h31v16H85z\" fill=\"#fff1ce\"/><path d=\"M86 69l14 8 15-8\" stroke-width=\"1.5\"/>\r\n<path d=\"M141 38V21h13v27\" fill=\"#d4b488\"/>\r\n<path d=\"M19 137h157m-144-8-3-12m4 8 8-8m126 13 5-16\" stroke=\"#72945f\"/>\r\n</g></svg>", Je = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path fill=\"#e3e6dc\" stroke=\"none\" d=\"M0 0H200V160H0z\"/><circle cx=\"159\" cy=\"29\" r=\"20\" fill=\"#fff9d9\" stroke=\"none\"/><path d=\"M0 130Q46 105 94 128T200 117V160H0z\" fill=\"#c6d4ae\" stroke=\"none\"/><path d=\"M11 101q8-18 16-3m148 15q8-21 13-6M24 132l-5-8m142 10 5-8\" stroke=\"#76a896\" stroke-width=\"2\"/>\r\n<path d=\"M32 74h133v65H32z\" fill=\"#e8d6a6\"/><path d=\"M23 76l32-38h79l38 38z\" fill=\"#7d9992\"/>\r\n<path d=\"M48 51h94m-104 13h116\" stroke=\"#567c75\" stroke-width=\"2\"/>\r\n<path d=\"M46 88h37v37H46z\" fill=\"#86b09f\"/><path d=\"M45 106h38m-19-18v36\"/>\r\n<path d=\"M100 91h48v47h-48z\" fill=\"#c08c5b\"/><path d=\"M106 97h36v11h-36zm0 17h36v11h-36z\" fill=\"#775f44\" stroke-width=\"1.5\"/>\r\n<path d=\"M113 101l9 6 12-7m-19 19 8 5 10-7\" stroke=\"#f9ecd0\" stroke-width=\"3\"/>\r\n<path d=\"M79 41V23h28v18\" fill=\"#f3e6b7\"/><circle cx=\"93\" cy=\"29\" r=\"5\" fill=\"#c7d9be\" stroke-width=\"1.5\"/>\r\n<path d=\"M23 139h151m-7-7 5-12m-145 10-4-10\" stroke=\"#7d9d69\"/>\r\n</g></svg>", Ye = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 180 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M25 91q57-20 125 0l-18 38q-45 23-89-1z\" fill=\"#cda66a\"/><path d=\"M27 93q60 26 121 0M35 108q53 20 105 0m-95 15q43 14 86-1\" stroke=\"#997c4c\"/><path d=\"M51 93q-13-39 7-44 22-2 21 46m7-1q-10-39 11-43 20 3 17 44\" fill=\"#fbf3d6\"/><path d=\"M25 84l-9-8m128 4 12-9\"/></g></svg>", Xe = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 180 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><ellipse cx=\"89\" cy=\"113\" rx=\"72\" ry=\"25\" fill=\"#b2d9cf\" stroke=\"none\"/><path d=\"M31 103q5-42 63-39 50 3 54 38-37 31-63 9l-8-25-9 26q-23 7-37-9z\" fill=\"#80b78e\"/><path d=\"M102 73q-21-24-4-39 14 10 16 24 7-18 18-19 14 24-19 37z\" fill=\"#edb8b4\"/><path d=\"M95 69q17-23 33-7-6 20-21 17z\" fill=\"#f8d6c7\"/><path d=\"M47 104l17-9m46 1 17 9\" stroke=\"#578b73\" stroke-width=\"2\"/></g></svg>", Ze = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 180 160\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 132q2-70 63-73 65-9 76 73z\" fill=\"#a2bf8d\"/><path d=\"M57 132v-21q0-34 28-34 31 0 32 34v21z\" fill=\"#b29064\"/><path d=\"M67 132v-21q2-24 18-24 20 0 20 24v21\" fill=\"#405d50\"/><path d=\"M30 104l-10-15m16 7 6-15m96 22 9-14\" stroke=\"#668d66\"/><path d=\"M127 66q-8-25 1-31m-1 16 12-11m-12 4-10-9\" stroke=\"#6f9c69\"/><path d=\"M105 69l36-13-4 17z\" fill=\"#eda96d\"/></g></svg>", Qe = {
	crow: "games.wildventure.crow",
	frog: "games.wildventure.frog",
	rabbit: "games.wildventure.rabbit"
}, $e = {
	villager: "games.wildventure.villager",
	gear: "games.wildventure.gear",
	building: "games.wildventure.building"
}, et = {
	crow: "games.wildventure.nest",
	frog: "games.wildventure.lilypad",
	rabbit: "games.wildventure.warren"
}, tt = {
	crow: ["games.wildventure.nestBasic", "games.wildventure.nestUpgraded"],
	frog: ["games.wildventure.lilypadBasic", "games.wildventure.lilypadUpgraded"],
	rabbit: ["games.wildventure.warrenBasic", "games.wildventure.warrenUpgraded"]
}, nt = {
	crow: Be,
	frog: Ve,
	rabbit: He
}, rt = {
	crow: Ye,
	frog: Xe,
	rabbit: Ze
}, it = {
	crow: "#d6e8e1",
	frog: "#e5def1",
	rabbit: "#f2e3b9"
};
function at(e) {
	let t = E(e);
	return e === 513 ? Ue : t.kind === "villager" ? nt[t.species] : t.kind === "building" ? e === 508 || e === 536 ? Je : qe : [
		441,
		400,
		424,
		447,
		532
	].includes(e) ? We : [
		422,
		504,
		524,
		526,
		540
	].includes(e) ? Ge : Ke;
}
function X({ id: e, species: t, starter: n, className: r = "" }) {
	let i = n ? rt[n] : e === void 0 ? nt[t ?? "crow"] : at(e);
	return /* @__PURE__ */ _("span", {
		className: `wv-art ${r}`,
		"aria-hidden": !0,
		dangerouslySetInnerHTML: { __html: i }
	});
}
function ot({ anchorName: e, ...t }) {
	let { ref: n, hidden: r } = m(e);
	return /* @__PURE__ */ _("button", {
		...t,
		ref: n,
		style: {
			...t.style,
			visibility: r ? "hidden" : void 0
		}
	});
}
function Z({ name: e, className: t = "", children: n }) {
	let { ref: r, hidden: i } = m(e);
	return /* @__PURE__ */ _("span", {
		ref: r,
		className: `wv-fx-anchor ${t}`,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function st({ n: e, animated: t = !1 }) {
	return /* @__PURE__ */ _("span", {
		className: "wv-coin",
		children: t ? /* @__PURE__ */ _(p, { value: e }) : e
	});
}
function ct() {
	return /* @__PURE__ */ v("svg", {
		viewBox: "0 0 72 96",
		className: "wv-card-back",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ _("rect", {
				x: "1",
				y: "1",
				width: "70",
				height: "94",
				rx: "5",
				fill: "#527c68",
				stroke: "#294e46",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ _("rect", {
				x: "6",
				y: "6",
				width: "60",
				height: "84",
				rx: "3",
				fill: "none",
				stroke: "#e7e9c5",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ _("path", {
				d: "M36 18L56 48 36 78 16 48Z",
				fill: "#789779",
				stroke: "#e7e9c5",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ _("path", {
				d: "M24 57l12-30 12 30M29 45h14M22 65h28",
				fill: "none",
				stroke: "#f6edc8",
				strokeWidth: "3",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "36",
				cy: "61",
				r: "3",
				fill: "#f6edc8"
			})
		]
	});
}
function lt({ n: e }) {
	return /* @__PURE__ */ v("svg", {
		viewBox: "0 0 28 28",
		className: "wv-token",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ _("circle", {
				cx: "14",
				cy: "14",
				r: "12",
				fill: [
					"#dbb753",
					"#9e8bc3",
					"#75a18b"
				][e],
				stroke: "#294e46",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ _("path", {
				d: [
					"M8 7l12 14M8 21L20 7",
					"M7 14h14M14 7v14",
					"M8 8l12 12M8 20L20 8"
				][e],
				stroke: "#294e46",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "14",
				cy: "14",
				r: "3",
				fill: "#fff9e4",
				stroke: "#294e46"
			})
		]
	});
}
function Q({ id: e, placed: t, compact: n = !1, selected: r = !1, used: i = !1, anchored: a = !1 }) {
	let o = s(), c = E(e), { ref: l } = m(a && t ? `wv-supply:${e}` : null), { ref: u, hidden: d } = m(a && t ? `wv-enchant:${e}` : null);
	return /* @__PURE__ */ v("span", {
		className: `wv-card ${n ? "wv-card-compact" : ""} ${r ? "wv-card-selected" : ""} ${i ? "wv-card-used" : ""}`,
		style: { "--wv-card-color": it[c.species] },
		children: [
			/* @__PURE__ */ _(X, { id: e }),
			/* @__PURE__ */ _("span", {
				className: "wv-card-cost",
				children: /* @__PURE__ */ _(st, { n: c.cost })
			}),
			(t || c.kind !== "building") && /* @__PURE__ */ _("span", {
				ref: l,
				className: "wv-card-supply",
				"aria-label": o("games.wildventure.supplies", { n: t?.supplies ?? c.supplies }),
				children: a && t ? /* @__PURE__ */ _(p, { value: t.supplies }) : t?.supplies ?? c.supplies
			}),
			/* @__PURE__ */ _("strong", {
				className: "wv-card-name",
				children: o(c.name)
			}),
			/* @__PURE__ */ v("span", {
				className: "wv-card-footer",
				children: [/* @__PURE__ */ _("span", { children: o(Qe[c.species]) }), /* @__PURE__ */ _("span", { children: c.free ? o("games.wildventure.free") : o($e[c.kind]) })]
			}),
			t?.enchanted !== null && t?.enchanted !== void 0 && /* @__PURE__ */ _("span", {
				ref: u,
				style: { visibility: d ? "hidden" : void 0 },
				className: "wv-card-enchanted",
				children: /* @__PURE__ */ _(lt, { n: t.enchanted })
			}),
			i && /* @__PURE__ */ _("span", {
				className: "wv-card-used-mark",
				"aria-label": o("games.wildventure.used"),
				children: "✓"
			})
		]
	});
}
function ut(e, t) {
	return t(e < 0 ? et[[
		"crow",
		"frog",
		"rabbit"
	][-e - 1]] : E(e).name);
}
function dt(e, t) {
	if (e.label === "chestSpecial") return t(e.n === 1 ? "games.wildventure.ironSpecial" : e.n === 2 ? "games.wildventure.goldSpecial" : "games.wildventure.rubySpecial");
	if (e.label === "chestConsider") return t(e.n === 1 ? "games.wildventure.ironConsider" : e.n === 2 ? "games.wildventure.goldConsider" : "games.wildventure.rubyConsider");
	let n = t(Re[e.label], { n: e.n ?? 1 });
	return e.species ? `${t(e.label === "chooseSpecies" ? Qe[e.species] : et[e.species])} · ${n}` : e.label === "copy" && e.n && E(e.n) ? `${n} · ${ut(e.n, t)}` : n;
}
//#endregion
//#region src/games/wildventure/art/landscape.svg?raw
var ft = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 375 282\" fill=\"none\"><g stroke=\"#294e46\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\r\n<path d=\"M0 0h375v282H0z\" fill=\"#e4eac8\" stroke=\"none\"/>\r\n<path d=\"M0 59Q73 7 161 45T375 30V0H0z\" fill=\"#d0dfbf\" stroke=\"none\"/>\r\n<path d=\"M0 139Q40 103 94 136T172 223L135 282H0z\" fill=\"#cedeb8\" stroke=\"none\"/>\r\n<path d=\"M223 283Q189 236 249 191T375 147v136z\" fill=\"#cddfbd\" stroke=\"none\"/>\r\n<path d=\"M212-16Q163 30 192 62T240 106Q260 132 298 150T314 212Q288 247 321 291\" stroke=\"#91bbae\" stroke-width=\"32\"/>\r\n<path d=\"M212-16Q163 30 192 62T240 106Q260 132 298 150T314 212Q288 247 321 291\" stroke=\"#b5dcd1\" stroke-width=\"26\"/>\r\n<path d=\"M203 1q-24 28-10 47m55 70 24 18m47 45q7 18-3 28m-5 45 6 18\" stroke=\"#e1f0d9\" stroke-width=\"2\"/>\r\n<path d=\"M112 35l28-40 41 45z\" fill=\"#a8bdad\" stroke=\"#819f93\" stroke-width=\"1.3\"/>\r\n<path d=\"M130 9l10-14 13 20-13-5-5 5z\" fill=\"#f8f5dd\" stroke=\"none\"/>\r\n<path d=\"M281 33l28-48 42 53z\" fill=\"#abc4b0\" stroke=\"#819f93\" stroke-width=\"1.3\"/>\r\n<path d=\"M298 4l11-19 14 21-13-7-4 8z\" fill=\"#f8f5dd\" stroke=\"none\"/>\r\n<g transform=\"translate(18 40) scale(1.15)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(44 18) scale(0.9)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(230 8) scale(0.9)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(251 29) scale(1.1)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(350 76) scale(1.3)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(369 107) scale(0.9)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(339 189) scale(1.2)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(364 215) scale(0.9)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(36 198) scale(1.3)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(62 223) scale(0.95)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(19 239) scale(1.1)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g><g transform=\"translate(224 177) scale(0.9)\"><path d=\"M0 4v23\" stroke=\"#557d66\" stroke-width=\"3\"/><path d=\"M-17 8-8-9-12-9 0-30 13-9 9-9 18 8z\" fill=\"#7ca990\" stroke=\"#628d75\" stroke-width=\"1.2\"/><path d=\"M0-15v20m0-5 8-5M0-3l-7-6\" stroke=\"#5b8d73\" stroke-width=\"1\"/></g>\r\n<g stroke=\"#788c5b\" stroke-width=\"1.1\"><path d=\"M72 144l-3-7m3 7 4-8M109 188l-4-7m4 7 4-7M270 250l3-7m0 0 4 5M213 77l4-6m0 6 4-4\"/></g>\r\n<g fill=\"#f9e29a\" stroke=\"none\"><circle cx=\"49\" cy=\"151\" r=\"2\"/><circle cx=\"55\" cy=\"148\" r=\"2\"/><circle cx=\"237\" cy=\"234\" r=\"2\"/><circle cx=\"243\" cy=\"238\" r=\"2\"/><circle cx=\"322\" cy=\"51\" r=\"2\"/></g>\r\n<g stroke=\"#78956b\" stroke-width=\"1.1\"><path d=\"M83 262v-22h30v22\" fill=\"#f9e8bc\"/><path d=\"M76 243q1-24 22-25 21 0 24 25z\" fill=\"#cf9a7a\"/><path d=\"M96 262v-13h9v13\" fill=\"#86a38c\"/><path d=\"M50 263v-15h22v15\" fill=\"#f9e8bc\"/><path d=\"M45 248q3-18 16-18 15 0 17 18z\" fill=\"#dbad83\"/></g>\r\n<path d=\"M225 145l23 11m-21-15 23 11m-26-3 24 11\" stroke=\"#b18f60\" stroke-width=\"3\"/>\r\n</g></svg>";
//#endregion
//#region src/games/wildventure/map-view.tsx
function pt(e, t) {
	return [
		e.gain ? t("games.wildventure.rewardGain", { n: e.gain }) : "",
		e.draw ? t("games.wildventure.rewardDraw", { n: e.draw }) : "",
		e.starter ? t(et[e.starter]) : "",
		e.chest ? t({
			iron: "games.wildventure.iron",
			gold: "games.wildventure.gold",
			ruby: "games.wildventure.ruby"
		}[e.chest]) : ""
	].filter(Boolean).join(" · ");
}
function mt(e, t, n) {
	let r = e.tokens.find((e) => e.node === t);
	return r?.kind === "enchant" ? n("games.wildventure.rewardEnchant", { n: r.token + 1 }) : pt(r?.kind === "gold" ? { chest: "gold" } : r?.kind === "gain5" ? { gain: 5 } : r?.kind === "nest" ? { starter: "crow" } : k(e.config.season, t).reward, n) || n("games.wildventure.blankSpace");
}
function ht({ reward: e }) {
	let t = e;
	return /* @__PURE__ */ v("g", {
		className: "wv-reward-icon",
		children: [
			t.gain && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("circle", {
				r: "19",
				fill: "#f3d178",
				stroke: "#a9853b"
			}), /* @__PURE__ */ _("text", {
				y: "7",
				children: t.gain
			})] }),
			t.draw && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("rect", {
				x: t.gain ? 4 : -15,
				y: t.gain ? 7 : -20,
				width: "30",
				height: "38",
				rx: "4",
				fill: "#6c9682",
				stroke: "#fff8df"
			}), /* @__PURE__ */ _("text", {
				x: t.gain ? 19 : 0,
				y: t.gain ? 33 : 7,
				fill: "#fff8df",
				children: t.draw
			})] }),
			t.starter && /* @__PURE__ */ _("text", {
				y: "9",
				fontSize: "29",
				children: t.starter === "crow" ? "◉" : t.starter === "frog" ? "☘" : "⌂"
			}),
			t.chest && /* @__PURE__ */ v(g, { children: [
				/* @__PURE__ */ _("path", {
					d: "M-23 17v-23q0-24 23-24T23-6v23z",
					fill: t.chest === "ruby" ? "#c78a79" : t.chest === "gold" ? "#e4bd5d" : "#b2beb8",
					stroke: "#486755",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ _("path", {
					d: "M-23-3h46M-9-27v44M9-27v44",
					stroke: "#486755",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ _("rect", {
					x: "-5",
					y: "-7",
					width: "10",
					height: "12",
					rx: "2",
					fill: "#fff0b3",
					stroke: "#486755"
				})
			] })
		]
	});
}
function gt({ name: e, ...t }) {
	let n = h(), i = a(null);
	return r(() => (n?.registerProbe(e, () => {
		let e = i.current, t = e?.ownerSVGElement?.getBoundingClientRect(), n = e?.querySelector("circle")?.getBoundingClientRect();
		if (!n || !t) return null;
		let r = Math.max(n.left, t.left), a = Math.max(n.top, t.top), o = Math.min(n.right, t.right) - r, s = Math.min(n.bottom, t.bottom) - a;
		return o > 5 && s > 5 ? {
			x: r,
			y: a,
			w: o,
			h: s
		} : null;
	}), () => n?.registerProbe(e, null)), [n, e]), /* @__PURE__ */ _("g", {
		...t,
		ref: i
	});
}
function _t({ pub: e, myRid: t, moves: n, onMove: i, avatarOf: c }) {
	let l = s(), ee = ae(e.config.season), p = n.filter((e) => e.node), m = e.players.find((e) => e.rid === t) ?? e.players[0], h = p.length ? `${e.prompt}:${m.position}` : "overview", [te, ne] = o(null), y = a(null), [b, x] = o({
		width: 375,
		height: 280
	});
	r(() => {
		let e = y.current;
		if (!e) return;
		let t = new ResizeObserver(([e]) => x({
			width: e.contentRect.width,
			height: e.contentRect.height
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let S = a(null), C = [k(e.config.season, m.position), ...p.map((t) => k(e.config.season, t.node))], w = C.map((e) => e.x * 10), T = C.map((e) => e.y * 7.8), re = Math.min(...w), E = Math.max(...w), D = Math.min(...T), ie = Math.max(...T), O = Math.min(1e3, Math.max(450, E - re + 160, (ie - D + 200) / .78)), A = p.length ? {
		x: Math.max(0, Math.min(1e3 - O, (re + E - O) / 2)),
		y: Math.max(0, Math.min(780 - O * .78, (D + ie - O * .78) / 2)),
		w: O
	} : {
		x: 0,
		y: 0,
		w: 1e3
	}, j = te?.key === h ? te : A, M = Math.max(30, 22 / Math.max(.1, Math.min(b.width / j.w, b.height / (j.w * .78)))), N = (e) => {
		let t = Math.max(300, Math.min(1e3, j.w * e));
		ne({
			key: h,
			x: j.x + (j.w - t) / 2,
			y: j.y + (j.w - t) * .39,
			w: t
		});
	};
	return /* @__PURE__ */ v("div", {
		className: `wv-map-wrap ${e.config.season === "autumn" ? "wv-map-autumn" : ""}`,
		children: [/* @__PURE__ */ v("div", {
			className: "wv-map-head",
			children: [/* @__PURE__ */ _("strong", { children: l(e.config.season === "spring" ? "games.wildventure.spring" : "games.wildventure.autumn") }), /* @__PURE__ */ v("span", {
				className: "wv-map-tools",
				children: [
					/* @__PURE__ */ _("button", {
						type: "button",
						"aria-label": l("games.wildventure.zoomIn"),
						onClick: () => N(.7),
						children: /* @__PURE__ */ _(d, { size: 17 })
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						"aria-label": l("games.wildventure.zoomOut"),
						onClick: () => N(1.4),
						children: /* @__PURE__ */ _(f, { size: 17 })
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						"aria-label": l("games.wildventure.resetMap"),
						onClick: () => ne({
							key: h,
							x: 0,
							y: 0,
							w: 1e3
						}),
						children: /* @__PURE__ */ _(u, { size: 17 })
					})
				]
			})]
		}), /* @__PURE__ */ v("svg", {
			ref: y,
			className: "wv-map-svg",
			viewBox: `${j.x} ${j.y} ${j.w} ${j.w * .78}`,
			"aria-label": l(e.config.season === "spring" ? "games.wildventure.spring" : "games.wildventure.autumn"),
			onPointerDown: (e) => {
				e.target.closest("[data-move]") || (e.currentTarget.setPointerCapture(e.pointerId), S.current = {
					x: e.clientX,
					y: e.clientY,
					ox: j.x,
					oy: j.y,
					w: j.w,
					moved: !1
				});
			},
			onPointerMove: (e) => {
				let t = S.current;
				if (!t) return;
				let n = t.w / e.currentTarget.getBoundingClientRect().width;
				t.moved = !0, ne({
					key: h,
					x: Math.max(-150, Math.min(900, t.ox - (e.clientX - t.x) * n)),
					y: Math.max(-100, Math.min(700, t.oy - (e.clientY - t.y) * n)),
					w: t.w
				});
			},
			onPointerUp: () => {
				S.current = null;
			},
			onPointerCancel: () => {
				S.current = null;
			},
			children: [
				/* @__PURE__ */ _("g", {
					fill: "none",
					transform: "scale(2.66667 2.766)",
					dangerouslySetInnerHTML: { __html: ft.replace(/<svg[^>]*>|<\/svg>/g, "") }
				}),
				/* @__PURE__ */ _("g", {
					className: "wv-map-paths",
					children: ee.flatMap((e) => e.next.map((t) => {
						let n = ee.find((e) => e.id === t.to), r = e.x * 10, i = e.y * 7.8, a = n.x * 10, o = n.y * 7.8;
						return /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("path", {
							d: `M${r} ${i}L${a} ${o}`,
							className: t.coins || t.trash ? "wv-path-cost" : ""
						}), (t.coins || t.trash) && /* @__PURE__ */ v("g", {
							transform: `translate(${(r + a) / 2} ${(i + o) / 2})`,
							children: [/* @__PURE__ */ _("circle", {
								r: "14",
								fill: t.coins ? "#f5d37b" : "#6c9682",
								stroke: "#456653",
								strokeWidth: "2"
							}), /* @__PURE__ */ _("text", {
								y: "5",
								fill: t.coins ? "#456653" : "#fff8df",
								fontSize: "18",
								textAnchor: "middle",
								children: t.coins ?? t.trash
							})]
						})] }, `${e.id}:${t.to}`);
					}))
				}),
				ee.map((t) => {
					let n = e.tokens.find((e) => e.node === t.id), r = n && n.kind !== "enchant" ? n.kind === "gold" ? { chest: "gold" } : n.kind === "gain5" ? { gain: 5 } : { starter: "crow" } : t.reward, a = p.find((e) => e.node === t.id);
					return /* @__PURE__ */ v(gt, {
						name: `wv-node:${t.id}`,
						transform: `translate(${t.x * 10} ${t.y * 7.8})`,
						"data-move": a ? t.id : void 0,
						role: a ? "button" : void 0,
						tabIndex: a ? 0 : void 0,
						"aria-label": a ? `${mt(e, t.id, l)}${a.n ? ` · ${l(a.n > 0 ? "games.wildventure.routeCostCoins" : "games.wildventure.routeCostTrash", { n: Math.abs(a.n) })}` : ""}` : void 0,
						onClick: a ? () => i(a) : void 0,
						onKeyDown: a ? (e) => {
							(e.key === "Enter" || e.key === " ") && (e.preventDefault(), i(a));
						} : void 0,
						className: a ? "wv-map-node wv-map-node-legal" : "wv-map-node",
						children: [
							/* @__PURE__ */ _("circle", { r: t.id === "home" ? 29 : 28 }),
							n?.kind === "enchant" ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("circle", {
								r: "18",
								fill: [
									"#dbb753",
									"#9e8bc3",
									"#75a18b"
								][n.token],
								stroke: "#294e46",
								strokeWidth: "3"
							}), /* @__PURE__ */ _("text", {
								y: "7",
								textAnchor: "middle",
								fontSize: "22",
								fill: "#294e46",
								children: n.token + 1
							})] }) : t.id === "home" ? /* @__PURE__ */ _("text", {
								textAnchor: "middle",
								y: "9",
								fontSize: "30",
								fill: "#456653",
								children: "⌂"
							}) : /* @__PURE__ */ _(ht, { reward: r }),
							a && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("circle", {
								r: M,
								className: "wv-map-hit"
							}), /* @__PURE__ */ _("text", {
								y: -M - 7,
								textAnchor: "middle",
								className: "wv-map-choice",
								children: pt(r, l)
							})] })
						]
					}, t.id);
				}),
				e.players.filter((e) => e.species && e.rid !== "$wildventure-otto").map((t, n) => {
					let r = k(e.config.season, t.position);
					return /* @__PURE__ */ v("g", {
						transform: `translate(${r.x * 10 + (n ? 15 : -15)} ${r.y * 7.8 - 30})`,
						className: "wv-pawn",
						children: [
							/* @__PURE__ */ _("path", {
								d: "M-13 12l4-24h18l4 24z",
								fill: t.species === "crow" ? "#5d7e83" : t.species === "frog" ? "#a294c6" : "#f7ecd0",
								stroke: "#294e46",
								strokeWidth: "3"
							}),
							/* @__PURE__ */ _("circle", {
								cy: "-15",
								r: "9",
								fill: "#f9edc8",
								stroke: "#294e46",
								strokeWidth: "3"
							}),
							/* @__PURE__ */ _("image", {
								href: c(t.rid),
								x: -10,
								y: -10,
								width: 20,
								height: 20,
								preserveAspectRatio: "xMidYMid meet",
								pointerEvents: "none"
							})
						]
					}, t.rid);
				})
			]
		})]
	});
}
//#endregion
//#region src/games/wildventure/view-player.tsx
function vt(e) {
	let t = e.public, r = e.private, u = s(), [d, f] = o(null), [h, y] = o(null), [b, x] = o(!1), [S, C] = o({
		key: "",
		ids: []
	}), [w, re] = o(null), D = t.players.find((t) => t.rid === e.myRid) ?? t.players[0], { ref: ie } = m(`wv-hand:${D.rid}`), { ref: O } = m("wv-camp"), { ref: ae } = m("wv-table-viewport"), { ref: k } = m("wv-hand-viewport"), A = a(null);
	i(() => {
		let e = t.scene;
		if (e?.card === void 0 || ![
			"play",
			"activate",
			"gain",
			"supply",
			"invest",
			"enchant"
		].includes(e.kind)) return;
		let n = A.current?.querySelector(`[data-wv-card="${e.card}"]`), r = n?.parentElement;
		n && r && (n.offsetLeft < r.scrollLeft ? r.scrollLeft = n.offsetLeft : n.offsetLeft + n.offsetWidth > r.scrollLeft + r.clientWidth && (r.scrollLeft = n.offsetLeft + n.offsetWidth - r.clientWidth));
	}, [t.scene]);
	let j = t.players.find((e) => e.rid !== D.rid), M = (t) => t === "$wildventure-otto" ? u("games.wildventure.otto") : e.members.find((e) => e.rid === t)?.name ?? t, N = r?.moves ?? [], P = r?.selection, F = `${t.prompt}:${P?.cards.join(",")}:${N.map((e) => e.id).join(",")}:${t.scene?.seq}`, I = S.key === F ? S.ids : [], L = w?.key === F && P?.cards.includes(w.id) ? w.id : P?.cards[0], R = d !== null && (D.placed.some((e) => e.id === d) || r?.hand.includes(d)) ? d : null, z = R === null ? [] : N.filter((e) => e.card === R), B = t.chooser === e.myRid, oe = B && !P && t.prompt !== "adventure" || b, se = B ? N : b ? z : [], V = (t) => {
		e.send({
			type: "act",
			id: t.id
		}), f(null), x(!1);
	}, H = (e) => {
		re({
			key: F,
			id: e
		});
		let t = I.includes(e) ? I.filter((t) => t !== e) : P?.max === 1 ? [e] : I.length < (P?.max ?? 0) ? [...I, e] : I;
		C({
			key: F,
			ids: t
		});
	}, ce = (e) => {
		let t = {
			name: M(e.by),
			card: e.card === void 0 ? "" : ut(e.card, u),
			n: e.n ?? 0
		};
		return e.kind === "supply" && e.card !== void 0 && e.card < 0 ? u("games.wildventure.logUpgrade", t) : e.kind === "enchant" && e.card === void 0 ? u("games.wildventure.logToken", {
			...t,
			token: (e.n ?? 0) + 1
		}) : u(ze[e.kind], e.kind === "supply" ? {
			...t,
			n: `${t.n > 0 ? "+" : ""}${t.n}`
		} : t);
	}, U = B && t.prompt ? u(Le[t.prompt]) : t.phase === "resolve" ? u("games.wildventure.resolving") : (t.chooser ?? t.turn) === e.myRid ? u("games.wildventure.yourTurn") : u("games.wildventure.waiting", { name: M(t.chooser ?? t.turn) }), le = (e) => /* @__PURE__ */ v(yt, {
		kind: e,
		rid: D.rid,
		children: [D.placed.filter((t) => E(t.id).kind === e).map((t) => /* @__PURE__ */ v(ot, {
			anchorName: `wv-card:${t.id}`,
			type: "button",
			"data-wv-card": t.id,
			className: "wv-piece-button",
			"aria-label": u(E(t.id).name),
			"aria-pressed": R === t.id,
			onClick: () => f(R === t.id ? null : t.id),
			children: [/* @__PURE__ */ _(Q, {
				id: t.id,
				placed: t,
				compact: e !== "villager",
				used: D.used.includes(`v${t.id}`),
				selected: R === t.id,
				anchored: !0
			}), N.some((e) => e.card === t.id) && /* @__PURE__ */ _("span", {
				className: "wv-available",
				"aria-hidden": !0
			})]
		}, t.id)), !D.placed.some((t) => E(t.id).kind === e) && /* @__PURE__ */ _("span", {
			className: "wv-empty-slot",
			"aria-hidden": !0,
			children: e === "villager" ? "♧" : e === "gear" ? "◇" : "⌂"
		})]
	}), ue = () => {
		if (P) return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("span", {
			className: "wv-selection-count",
			children: u("games.wildventure.selectionCount", {
				n: I.length,
				max: P.max
			})
		}), /* @__PURE__ */ _("button", {
			type: "button",
			className: "wv-primary",
			disabled: I.length < P.min || I.length > P.max,
			onClick: () => {
				e.send({
					type: "pick",
					cards: I
				}), C({
					key: "",
					ids: []
				});
			},
			children: u("games.wildventure.confirm")
		})] });
		if (B) {
			let e = N.find((e) => e.label === "stop"), t = N.find((e) => e.label === "skip");
			return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("span", {
				className: "wv-action-prompt",
				children: U
			}), (e || t) && /* @__PURE__ */ _("button", {
				type: "button",
				className: "wv-primary",
				onClick: () => V(e ?? t),
				children: dt(e ?? t, u)
			})] });
		}
		let t = N.find((e) => e.label === "endTurn");
		return z.length ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
			type: "button",
			className: "wv-secondary",
			"aria-label": u("games.wildventure.close"),
			onClick: () => f(null),
			children: /* @__PURE__ */ _(c, { size: 18 })
		}), /* @__PURE__ */ _("button", {
			type: "button",
			className: "wv-primary",
			onClick: () => z.length === 1 ? V(z[0]) : x(!0),
			children: z.length === 1 ? dt(z[0], u) : u("games.wildventure.confirm")
		})] }) : /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("span", {
			className: "wv-action-prompt",
			children: U
		}), t && /* @__PURE__ */ _("button", {
			type: "button",
			className: "wv-primary",
			onClick: () => V(t),
			children: u("games.wildventure.moveEndTurn")
		})] });
	}, W = R === null ? null : E(R), de = D.placed.find((e) => e.id === R), fe = t.log.reduce((e, t, n) => t.kind === "reveal" || t.kind === "jackbot" ? n : e, -1), pe = t.revealed.filter((e) => !t.players.some((t) => t.placed.some((t) => t.id === e)) && !t.log.slice(fe + 1).some((t) => t.card === e && [
		"tuck",
		"trash",
		"play"
	].includes(t.kind))), me = h === "trash" ? [...t.trash].reverse() : h === "score" ? r?.tucked ?? [] : j.placed.map((e) => e.id);
	return /* @__PURE__ */ v("div", {
		className: "wv-screen",
		children: [/* @__PURE__ */ _(te, {
			adaptive: !0,
			className: "wv-adaptive",
			scroll: !1,
			banner: /* @__PURE__ */ v("div", {
				className: "wv-top",
				children: [/* @__PURE__ */ _("div", {
					className: "wv-players",
					children: [D, j].map((e) => /* @__PURE__ */ v(ot, {
						anchorName: `wv-seat:${e.rid}`,
						type: "button",
						className: "wv-player",
						"aria-label": e.rid === D.rid ? M(e.rid) : u("games.wildventure.opponentCamp"),
						onClick: e.rid === D.rid ? void 0 : () => y("opponent"),
						children: [/* @__PURE__ */ _(X, {
							species: e.species ?? "crow",
							className: "wv-avatar"
						}), /* @__PURE__ */ v("span", {
							className: "wv-player-info",
							children: [/* @__PURE__ */ _("strong", { children: M(e.rid) }), /* @__PURE__ */ v("span", { children: [
								/* @__PURE__ */ _(Z, {
									name: `wv-coins:${e.rid}`,
									children: /* @__PURE__ */ _(st, {
										n: e.coins,
										animated: !0
									})
								}),
								/* @__PURE__ */ v(Z, {
									name: `wv-hand-count:${e.rid}`,
									children: ["▱ ", /* @__PURE__ */ _(p, { value: e.handCount })]
								}),
								/* @__PURE__ */ v(Z, {
									name: `wv-score:${e.rid}`,
									children: ["▣ ", /* @__PURE__ */ _(p, { value: e.tuckedCount })]
								})
							] })]
						})]
					}, e.rid))
				}), /* @__PURE__ */ v("div", {
					className: "wv-phase",
					children: [/* @__PURE__ */ _("strong", { children: U }), /* @__PURE__ */ _("span", { children: t.finalTurns === null ? u("games.wildventure.actions", { n: t.actionsLeft }) : u("games.wildventure.finalTurns", { n: t.finalTurns }) })]
				})]
			}),
			children: /* @__PURE__ */ v("div", {
				className: "wv-workspace",
				children: [/* @__PURE__ */ v("div", {
					ref: ae,
					className: "wv-table",
					children: [
						/* @__PURE__ */ v("div", {
							className: "wv-map-slot",
							children: [
								/* @__PURE__ */ _(_t, {
									avatarOf: (t) => n[(e.members.find((e) => e.rid === t)?.avatar ?? 0) % n.length],
									pub: t,
									myRid: e.myRid,
									moves: B ? N : [],
									onMove: V
								}),
								/* @__PURE__ */ v("div", {
									className: "wv-map-footer",
									children: [
										/* @__PURE__ */ _(Z, {
											name: "wv-deck",
											children: u("games.wildventure.deck", { n: t.deckCount })
										}),
										t.solo && t.config.theme !== "mixed" && /* @__PURE__ */ v(Z, {
											name: "wv-otto-deck",
											children: [
												/* @__PURE__ */ _(ct, {}),
												M("$wildventure-otto"),
												" ",
												t.ottoDeckCount
											]
										}),
										/* @__PURE__ */ _("span", { children: u("games.wildventure.turn", { n: t.turnNumber }) })
									]
								}),
								t.revealed.length > 0 && /* @__PURE__ */ _(Z, {
									name: "wv-revealed",
									className: "wv-revealed",
									children: pe.map((e) => /* @__PURE__ */ _(Z, {
										name: `wv-revealed-card:${e}`,
										children: /* @__PURE__ */ _(Q, { id: e })
									}, e))
								}),
								/* @__PURE__ */ _(Z, {
									name: "wv-feedback",
									className: "wv-feedback-slot"
								}),
								W && /* @__PURE__ */ v("div", {
									className: "wv-detail",
									children: [
										/* @__PURE__ */ v("header", { children: [
											/* @__PURE__ */ _(X, { id: W.id }),
											/* @__PURE__ */ _("strong", { children: u(W.name) }),
											/* @__PURE__ */ _("button", {
												type: "button",
												"aria-label": u("games.wildventure.close"),
												onClick: () => f(null),
												children: /* @__PURE__ */ _(c, { size: 18 })
											})
										] }),
										/* @__PURE__ */ _("p", { children: u(W.text) }),
										/* @__PURE__ */ v("footer", { children: [/* @__PURE__ */ v("span", { children: [
											u(Qe[W.species]),
											" · ",
											u($e[W.kind])
										] }), /* @__PURE__ */ v("span", { children: [
											u("games.wildventure.cost", { n: W.cost }),
											" · ",
											u("games.wildventure.supplies", { n: de?.supplies ?? W.supplies })
										] })] })
									]
								})
							]
						}),
						/* @__PURE__ */ v("div", {
							ref: (e) => {
								A.current = e, O(e);
							},
							className: "wv-camp",
							children: [
								/* @__PURE__ */ _(ee, {
									kind: "sheen",
									base: "#e8edda",
									className: "wv-camp-texture"
								}),
								/* @__PURE__ */ v("div", {
									className: "wv-camp-heading",
									children: [
										/* @__PURE__ */ _("strong", { children: u("games.wildventure.camp") }),
										/* @__PURE__ */ _(Z, {
											name: `wv-tokens:${D.rid}`,
											className: "wv-camp-tokens",
											children: D.tokens.map((e) => /* @__PURE__ */ _(Z, {
												name: `wv-token:${D.rid}:${e}`,
												children: /* @__PURE__ */ _(lt, { n: e })
											}, e))
										}),
										/* @__PURE__ */ _("button", {
											type: "button",
											onClick: () => y("score"),
											children: u("games.wildventure.scorePile", { n: D.tuckedCount })
										})
									]
								}),
								le("gear"),
								le("villager"),
								le("building")
							]
						}),
						/* @__PURE__ */ _("div", {
							className: "wv-starters",
							children: T.map((e, t) => {
								let n = N.find((t) => t.species === e && t.label === "activate");
								return /* @__PURE__ */ v(ot, {
									anchorName: `wv-starter:${D.rid}:${t}`,
									type: "button",
									disabled: !n,
									onClick: () => n && V(n),
									className: D.used.includes(`s${e}`) ? "wv-starter wv-starter-used" : "wv-starter",
									"aria-label": `${u(et[e])} · ${u(tt[e][+!!D.starters[t]])}`,
									children: [/* @__PURE__ */ _(X, { starter: e }), /* @__PURE__ */ v("span", { children: [/* @__PURE__ */ v("strong", { children: [u(et[e]), D.starters[t] ? " ↑" : ""] }), /* @__PURE__ */ _("small", { children: u(tt[e][+!!D.starters[t]]) })] })]
								}, e);
							})
						}),
						/* @__PURE__ */ _("div", {
							className: "wv-log",
							children: /* @__PURE__ */ _(ne, {
								log: t.log,
								line: ce
							})
						}),
						(oe || P) && /* @__PURE__ */ v("div", {
							className: "wv-choice-overlay",
							children: [
								/* @__PURE__ */ _(Z, {
									name: `wv-pool:${D.rid}`,
									className: "wv-pool-anchor"
								}),
								/* @__PURE__ */ v("header", { children: [/* @__PURE__ */ _("strong", { children: U }), b && /* @__PURE__ */ _("button", {
									type: "button",
									"aria-label": u("games.wildventure.close"),
									onClick: () => x(!1),
									children: /* @__PURE__ */ _(c, { size: 18 })
								})] }),
								P ? /* @__PURE__ */ v(g, { children: [
									/* @__PURE__ */ _("p", { children: P.ordered ? u(t.prompt === "orderPool" ? "games.wildventure.orderTopHint" : t.prompt === "chooseTrash" ? "games.wildventure.rubyPairHint" : "games.wildventure.orderedHint") : u("games.wildventure.selectionCount", {
										n: I.length,
										max: P.max
									}) }),
									/* @__PURE__ */ _("div", {
										className: "wv-selection-description",
										"aria-live": "polite",
										children: L !== void 0 && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("strong", { children: ut(L, u) }), /* @__PURE__ */ _("p", { children: u(E(L).text) })] })
									}),
									/* @__PURE__ */ _("div", {
										className: "wv-selection-grid",
										children: P.cards.map((e) => /* @__PURE__ */ v("button", {
											type: "button",
											className: "wv-select-card",
											"aria-pressed": I.includes(e),
											onClick: () => H(e),
											children: [/* @__PURE__ */ _(Q, {
												id: e,
												selected: I.includes(e)
											}), I.includes(e) && /* @__PURE__ */ _("span", {
												className: "wv-pick-order",
												children: I.indexOf(e) + 1
											})]
										}, e))
									})
								] }) : /* @__PURE__ */ _("div", {
									className: "wv-choice-list",
									children: se.map((e) => /* @__PURE__ */ v("button", {
										type: "button",
										className: "wv-choice",
										onClick: () => V(e),
										children: [
											e.card !== void 0 && /* @__PURE__ */ _(X, { id: e.card }),
											/* @__PURE__ */ v("span", { children: [
												e.card !== void 0 && /* @__PURE__ */ _("strong", { children: ut(e.card, u) }),
												/* @__PURE__ */ v("span", { children: [e.node ? `${mt(t, e.node, u)} · ` : "", dt(e, u)] }),
												e.card !== void 0 && !["invest", "workshopTake"].includes(e.label) && /* @__PURE__ */ _("small", { children: u(E(e.label === "copy" && e.n ? e.n : e.card).text) })
											] }),
											e.token !== void 0 && /* @__PURE__ */ _(lt, { n: e.token })
										]
									}, e.id))
								})
							]
						})
					]
				}), /* @__PURE__ */ v("div", {
					ref: k,
					className: "wv-bottom",
					children: [
						/* @__PURE__ */ v("div", {
							className: "wv-hand-heading",
							children: [/* @__PURE__ */ _("strong", { children: u("games.wildventure.hand", { n: r?.hand.length ?? 0 }) }), /* @__PURE__ */ v(ot, {
								anchorName: "wv-trash",
								type: "button",
								onClick: () => y("trash"),
								children: [
									/* @__PURE__ */ _(l, { size: 13 }),
									u("games.wildventure.trashPile"),
									" ",
									t.trash.length
								]
							})]
						}),
						/* @__PURE__ */ _("div", {
							ref: ie,
							className: "wv-hand-scroll",
							children: r?.hand.map((e, t) => /* @__PURE__ */ v(ot, {
								anchorName: `wv-hand-card:${e}`,
								type: "button",
								className: "wv-hand-button",
								"aria-pressed": R === e,
								"aria-label": u(E(e).name),
								style: { rotate: `${Math.max(-3, Math.min(3, t - (r.hand.length - 1) / 2))}deg` },
								onClick: () => P?.cards.includes(e) ? H(e) : f(R === e ? null : e),
								children: [/* @__PURE__ */ _(Q, {
									id: e,
									selected: R === e || I.includes(e)
								}), I.includes(e) && /* @__PURE__ */ _("span", {
									className: "wv-pick-order",
									children: I.indexOf(e) + 1
								})]
							}, e))
						}),
						/* @__PURE__ */ _("div", {
							className: "wv-action-bar",
							children: ue()
						})
					]
				})]
			})
		}), h && /* @__PURE__ */ _("div", {
			className: "wv-dialog-backdrop",
			onClick: () => y(null),
			children: /* @__PURE__ */ v("section", {
				className: "wv-gallery",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": u(h === "trash" ? "games.wildventure.trashPile" : h === "score" ? "games.wildventure.scorePile" : "games.wildventure.opponentCamp", { n: D.tuckedCount }),
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ v("header", { children: [/* @__PURE__ */ _("strong", { children: h === "opponent" ? M(j.rid) : u(h === "trash" ? "games.wildventure.trashPile" : "games.wildventure.scorePile", { n: D.tuckedCount }) }), /* @__PURE__ */ _("button", {
					type: "button",
					"aria-label": u("games.wildventure.close"),
					onClick: () => y(null),
					children: /* @__PURE__ */ _(c, { size: 19 })
				})] }), h === "score" && r?.tucked === null ? /* @__PURE__ */ _("p", { children: u("games.wildventure.scoreHidden") }) : me.length ? /* @__PURE__ */ _("div", {
					className: "wv-gallery-cards",
					children: me.map((e) => /* @__PURE__ */ _(bt, {
						id: e,
						placed: h === "opponent" ? j.placed.find((t) => t.id === e) : void 0
					}, e))
				}) : /* @__PURE__ */ _("p", { children: u("games.wildventure.empty") })]
			})
		})]
	});
}
function yt({ kind: e, rid: t, children: n }) {
	let r = s(), { ref: i } = m(`wv-row:${t}:${e}`);
	return /* @__PURE__ */ _("div", {
		ref: i,
		className: `wv-camp-row wv-camp-${e}`,
		"aria-label": r($e[e]),
		children: n
	});
}
function bt({ id: e, placed: t }) {
	let n = s();
	return /* @__PURE__ */ v("article", {
		className: "wv-gallery-card",
		children: [/* @__PURE__ */ _(Q, {
			id: e,
			placed: t
		}), /* @__PURE__ */ _("p", { children: n(E(e).text) })]
	});
}
//#endregion
//#region src/games/wildventure/bot.ts
function xt(e) {
	let t = E(e);
	return t.kind === "villager" ? t.supplies * 1.2 + (t.free ? 2 : 0) + t.cost * .35 : t.kind === "gear" ? t.supplies * .9 + 1 : 3 + t.cost * .3;
}
function St(e, t, n) {
	let r = t.players.find((e) => e.rid === n);
	switch (e.label) {
		case "endTurn": return -10;
		case "skip": return -7;
		case "play": return e.card === void 0 ? 0 : 5 + xt(e.card) - E(e.card).cost * (r.coins < 5 ? 1 : .35);
		case "activate":
		case "copy": {
			if (e.species) return e.species === "crow" ? 6 : e.species === "rabbit" ? r.coins < 5 ? 9 : 3 : 5;
			if (e.card === void 0) return 0;
			let n = E(e.card), i = [
				403,
				406,
				409,
				413,
				529,
				535
			].includes(n.id);
			return 5 + n.cost * .4 + +!!n.free - (i ? 6 : 0) - (t.scene?.card === n.id ? 12 : 0);
		}
		case "chooseInitiate": return E(e.card).species === "crow" ? 9 : E(e.card).species === "rabbit" ? 7 : 6;
		case "enchant": return 12 + (e.card ? xt(e.card) : 0);
		case "invest": return e.n === void 0 ? 1 : e.n * (r.coins - e.n >= 3 ? 1.2 : .6);
		case "move": {
			let n = k(t.config.season, e.node), i = t.tokens.find((e) => e.node === n.id);
			return 6 + (n.reward.chest ? 5 : 0) + (i ? i.kind === "enchant" && r.tokens.includes(i.token) ? -2 : 5 : 0) + (n.reward.draw ?? 0) + (n.reward.gain ?? 0) * .4;
		}
		case "stop": return 0;
		case "claim": {
			let n = k(t.config.season, e.node).reward;
			return (n.chest ? 8 : 0) + (n.draw ?? 0) * 2 + (n.gain ?? 0) + (n.starter ? 4 : 0);
		}
		case "upgrade": return t.deckCount > 20 ? 8 : 1;
		case "chooseStarter": return e.species === "crow" ? 8 : e.species === "rabbit" && r.coins < 5 ? 10 : 6;
		case "chestHand": return r.handCount > (e.n ?? 1) + 2 || t.finalTurns !== null ? 8 : 0;
		case "chestSpecial": return r.placed.some((e) => E(e.id).kind === "villager") ? 4 : -1;
		case "chestConsider": return 6;
		case "keepSupply": return 1;
		case "removeSupply": return 3;
		case "workshopTake": return e.n ?? 0;
		case "escDrawTrash": return 4;
		case "escDrawGive": return 3;
		default: return 2;
	}
}
var Ct = ({ public: e, private: t }, n) => {
	if (!t || e.phase === "done") return null;
	if (t.selection) {
		let n = t.selection, r = [...n.cards], i = [
			"trashHand",
			"trashPool",
			"orderPool"
		].includes(e.prompt ?? "");
		r.sort((e, t) => i ? xt(e) - xt(t) || e - t : xt(t) - xt(e) || e - t);
		let a = n.min === 0 ? Math.min(n.max, e.prompt === "tuckHand" && t.hand.length < 3 ? 0 : 1) : n.min;
		return { action: {
			type: "pick",
			cards: r.slice(0, a)
		} };
	}
	if (!t.moves.length) return null;
	let r = [...t.moves].sort((t, r) => St(r, e, n.rid) - St(t, e, n.rid) || t.id.localeCompare(r.id));
	return { action: {
		type: "act",
		id: (n.difficulty === "weak" && r.length > 2 ? r[1] : r[0]).id
	} };
};
//#endregion
//#region src/games/wildventure/fx.tsx
function wt(e, t) {
	if (!e || !t) return null;
	let n = Math.max(e.x, t.x), r = Math.max(e.y, t.y), i = Math.min(e.x + e.w, t.x + t.w) - n, a = Math.min(e.y + e.h, t.y + t.h) - r;
	return i > 2 && a > 2 ? {
		x: n,
		y: r,
		w: i,
		h: a
	} : null;
}
function Tt(e, t) {
	let n = e.anchor(t);
	return t.startsWith("wv-hand:") || t.startsWith("wv-hand-card:") || t === "wv-trash" ? wt(n, e.anchor("wv-hand-viewport")) : /^wv-(camp|card:|starter:|row:|tokens:|token:|enchant:|deck$|otto-deck$|revealed|pool:|feedback$)/.test(t) ? wt(n, e.anchor("wv-table-viewport")) : n;
}
function Et(e, t, n) {
	if (t === null) return null;
	if (t < 0) return Tt(e, `wv-starter:${n}:${-t - 1}`);
	let r = e.anchor(`wv-card:${t}`), i = Tt(e, "wv-camp");
	if (!r || !i) return null;
	let a = Math.max(r.x, i.x), o = Math.max(r.y, i.y), s = Math.min(r.x + r.w, i.x + i.w) - a, c = Math.min(r.y + r.h, i.y + i.h) - o;
	return s > 8 && c > 8 ? {
		x: a,
		y: o,
		w: s,
		h: c
	} : null;
}
var Dt = {
	draw: "games.wildventure.fxDraw",
	trash: "games.wildventure.fxTrash",
	tuck: "games.wildventure.fxTuck",
	consider: "games.wildventure.fxConsider",
	return: "games.wildventure.fxReturn",
	give: "games.wildventure.fxGive",
	trigger: "games.wildventure.fxTrigger",
	supply: "games.wildventure.fxSupply",
	invest: "games.wildventure.fxInvest",
	enchant: "games.wildventure.fxEnchant",
	token: "games.wildventure.fxToken",
	upgrade: "games.wildventure.fxUpgrade",
	relic: "games.wildventure.fxRelic",
	move: "games.wildventure.fxMove",
	home: "games.wildventure.fxHome",
	reveal: "games.wildventure.fxReveal"
};
function Ot({ at: e, data: t, actor: n, owner: r, cards: i }) {
	let a = s(), o = t.cue === "play" ? t.card : t.source, c = t.cue === "play" ? a(t.card !== null && E(t.card).kind === "building" ? "games.wildventure.fxPlayBuilding" : "games.wildventure.fxPlay", { n: t.supplies }) : t.cue === "activate" ? a(t.supplies < 0 ? "games.wildventure.fxActivateSupply" : "games.wildventure.fxActivate", { n: -t.supplies }) : t.cue === "pay" ? a("games.wildventure.fxPay", { n: -t.n }) : t.cue === "gain" ? a(t.supplies < 0 ? "games.wildventure.fxGearGain" : "games.wildventure.fxGain", {
		n: t.n,
		taken: -t.supplies
	}) : t.cue === "chest" ? a("games.wildventure.fxChest", { chest: a(t.n === 1 ? "games.wildventure.iron" : t.n === 2 ? "games.wildventure.gold" : "games.wildventure.ruby") }) : a(Dt[t.cue], {
		n: t.cue === "supply" ? `${t.supplies > 0 ? "+" : "−"}${Math.abs(t.supplies)}` : t.cue === "invest" ? t.supplies : t.n,
		token: (t.token ?? 0) + 1
	});
	return /* @__PURE__ */ v("div", {
		className: "wv-fx-cue",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: [
			o !== null && (o < 0 ? /* @__PURE__ */ _(X, { starter: T[-o - 1] }) : /* @__PURE__ */ _(X, { id: o })),
			/* @__PURE__ */ v("span", {
				className: "wv-fx-cue-copy",
				children: [/* @__PURE__ */ v("strong", { children: [r === null ? "" : `${r || a("games.wildventure.otto")} · `, o === null ? n || a("games.wildventure.otto") : ut(o, a)] }), /* @__PURE__ */ _("span", { children: c })]
			}),
			t.cue === "gain" && /* @__PURE__ */ _(st, { n: t.n }),
			t.token !== null && /* @__PURE__ */ _(lt, { n: t.token }),
			t.n > 0 && [
				"draw",
				"trash",
				"tuck",
				"consider",
				"return",
				"give",
				"reveal"
			].includes(t.cue) && /* @__PURE__ */ _("span", {
				className: "wv-fx-mini",
				children: Array.from({ length: Math.min(3, t.n) }, (e, t) => /* @__PURE__ */ _("span", { children: i[t] === void 0 ? /* @__PURE__ */ _(ct, {}) : /* @__PURE__ */ _(Q, { id: i[t] }) }, t))
			})
		]
	});
}
function kt({ at: e, supply: t = 0 }) {
	return /* @__PURE__ */ _("div", {
		className: "wv-fx-mark",
		style: {
			left: e.x - 2,
			top: e.y - 2,
			width: e.w + 4,
			height: e.h + 4
		},
		children: t !== 0 && /* @__PURE__ */ v("span", {
			className: "wv-fx-supply-delta",
			children: [t > 0 ? "+" : "−", Math.abs(t)]
		})
	});
}
function $(e, t, n = t) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
function At(e, t, n) {
	let r = e.anchor(t), i = Tt(e, n);
	return r && i && r.x >= i.x - 2 && r.y >= i.y - 2 && r.x + r.w <= i.x + i.w + 2 && r.y + r.h <= i.y + i.h + 2 ? r : null;
}
function jt(e, t) {
	if (!t) return null;
	let n = Tt(e, t);
	return n && n.w > 2 && n.h > 2 ? n : t.startsWith("wv-hand:") ? e.anchor(t.replace("wv-hand:", "wv-hand-count:")) : t.startsWith("wv-tokens:") ? e.anchor(t.replace("wv-tokens:", "wv-seat:")) : null;
}
var Mt = { wvAction(e, t) {
	let n = e.data;
	if (!n || !e.rid) return null;
	let r = t.queued ? 230 : 440, i = Tt(t, "wv-feedback"), a = t.anchor(`wv-coins:${e.rid}`), o = e.secret?.cards ?? n.cards, s = Et(t, n.source, n.sourceOwner), c = n.card === null ? null : Et(t, n.card, e.rid), l = jt(t, n.from), u = jt(t, n.to), d = jt(t, n.origin), f = n.cue === "play" && c && l && !t.queued, ee = e.rid === "$wildventure-otto" ? "" : t.member(e.rid)?.name ?? "", p = n.source !== null && n.sourceOwner !== e.rid ? t.member(n.sourceOwner)?.name ?? "" : null;
	if (!i && !a && !s && !c) return null;
	let m = f ? [`wv-card:${n.card}`] : [], h = [
		"draw",
		"trash",
		"tuck",
		"consider",
		"return",
		"give",
		"reveal"
	].includes(n.cue) && !t.queued ? Array.from({ length: Math.min(3, n.n) }, (e, i) => {
		let a = o[i], s = a !== void 0 && n.to?.startsWith("wv-hand:") ? `wv-hand-card:${a}` : a !== void 0 && n.to === "wv-revealed" ? `wv-revealed-card:${a}` : null, c = s ? At(t, s, n.to) : null, d = c ?? (u ? $(u, 30, 40) : null), f = l ? $(l, d?.w ?? 30, d?.h ?? 40) : null;
		return !d || !f ? null : (c && s && m.push(s), /* @__PURE__ */ _(y, {
			from: {
				...f,
				x: f.x + i * 3
			},
			to: {
				...d,
				x: d.x + (c ? 0 : i * 4)
			},
			ms: r - 60,
			children: /* @__PURE__ */ _("div", {
				className: "wv-fx-card",
				style: {
					width: d.w,
					height: d.h
				},
				children: a === void 0 ? /* @__PURE__ */ _(ct, {}) : /* @__PURE__ */ _(Q, { id: a })
			})
		}, i));
	}) : null, te = n.cue === "enchant" ? u : n.cue === "token" ? jt(t, `wv-token:${e.rid}:${n.token}`) : null, ne = n.token !== null && l && te && !t.queued;
	return ne && m.push(n.cue === "enchant" ? `wv-enchant:${n.card}` : `wv-token:${e.rid}:${n.token}`), {
		ms: r,
		node: /* @__PURE__ */ v("div", {
			className: "wv-fx-root",
			"data-wv-cue": n.cue,
			style: { "--wv-fx-ms": `${r}ms` },
			"aria-hidden": !0,
			children: [
				i && !e.with && /* @__PURE__ */ _(Ot, {
					at: i,
					data: n,
					actor: ee,
					owner: p,
					cards: o
				}),
				s && /* @__PURE__ */ _(kt, {
					at: s,
					supply: ["activate", "gain"].includes(n.cue) ? n.supplies : 0
				}),
				d && /* @__PURE__ */ _(kt, { at: d }),
				u && n.cue !== "enchant" && /* @__PURE__ */ _(kt, {
					at: u,
					supply: ["supply", "invest"].includes(n.cue) ? n.supplies : 0
				}),
				ne && /* @__PURE__ */ _(y, {
					from: $(l, 24),
					to: $(te, 24),
					ms: r - 60,
					children: /* @__PURE__ */ _(lt, { n: n.token })
				}),
				h,
				n.cue === "play" && c && !f && /* @__PURE__ */ _(kt, { at: c }),
				f && /* @__PURE__ */ _(y, {
					from: $(l, c.w, c.h),
					to: c,
					ms: r - 60,
					children: /* @__PURE__ */ _("div", {
						className: `wv-fx-card ${E(n.card).kind === "villager" ? "" : "wv-fx-card-compact"}`,
						style: {
							width: c.w,
							height: c.h
						},
						children: /* @__PURE__ */ _(Q, {
							id: n.card,
							placed: {
								id: n.card,
								supplies: n.supplies,
								enchanted: null
							},
							compact: E(n.card).kind !== "villager"
						})
					})
				}),
				(n.cue === "gain" || n.cue === "pay") && a && /* @__PURE__ */ v(g, { children: [
					/* @__PURE__ */ v("div", {
						className: "wv-fx-resource",
						style: {
							left: a.x + a.w / 2,
							top: a.y + a.h + 5
						},
						children: [n.n > 0 ? "+" : "−", Math.abs(n.n)]
					}),
					/* @__PURE__ */ _(kt, { at: a }),
					n.cue === "gain" && (l || d || s) && !t.queued && /* @__PURE__ */ _(y, {
						from: $(l || d || s, 24),
						to: $(a, 24),
						ms: r - 60,
						children: /* @__PURE__ */ _(st, { n: n.n })
					})
				] }),
				["supply", "invest"].includes(n.cue) && l && u && !t.queued && /* @__PURE__ */ _(y, {
					from: $(l, 22),
					to: $(u, 22),
					ms: r - 60,
					children: /* @__PURE__ */ _("span", {
						className: "wv-fx-supply-piece",
						children: n.supplies
					})
				})
			]
		}),
		...m.length ? { hide: m } : {}
	};
} };
//#endregion
//#region src/games/wildventure/game-over.tsx
function Nt({ public: e, result: t, members: n, onPlayAgain: r, onBackToLobby: i, hintCount: a }) {
	let c = e, l = s(), [u, d] = o(null), f = (e) => e === "$wildventure-otto" ? l("games.wildventure.otto") : n.find((t) => t.rid === e)?.name ?? e;
	return /* @__PURE__ */ v("div", {
		className: "wv-over",
		children: [
			/* @__PURE__ */ v("h1", { children: ["🏆 ", t.winner.length === 1 ? l("games.wildventure.winner", { name: f(t.winner[0]) }) : l("games.wildventure.tie")] }),
			/* @__PURE__ */ _("div", {
				className: "wv-scoreboards",
				children: t.ranking.map((e) => {
					let t = c.players.find((t) => t.rid === e), n = t.score;
					return /* @__PURE__ */ v("section", {
						className: "wv-scoreboard",
						children: [
							/* @__PURE__ */ v("header", { children: [
								/* @__PURE__ */ _(X, { species: t.species ?? "crow" }),
								/* @__PURE__ */ _("strong", { children: f(e) }),
								/* @__PURE__ */ _("span", {
									className: "wv-score-total",
									children: n.total
								})
							] }),
							/* @__PURE__ */ _("div", {
								className: "wv-final-species",
								children: T.map((e, t) => /* @__PURE__ */ v("span", { children: [
									l(Qe[e]),
									" ",
									n.villagers[t]
								] }, e))
							}),
							/* @__PURE__ */ v("dl", { children: [
								/* @__PURE__ */ _("dt", { children: l("games.wildventure.villagerScore") }),
								/* @__PURE__ */ v("dd", { children: [
									Math.min(...n.villagers),
									" × ",
									Math.max(...n.villagers),
									" = ",
									n.villagerScore
								] }),
								/* @__PURE__ */ _("dt", { children: l("games.wildventure.gearScore") }),
								/* @__PURE__ */ v("dd", { children: [
									n.gearCount,
									" × ",
									n.multiplier,
									" = ",
									n.gearScore
								] }),
								/* @__PURE__ */ _("dt", { children: l("games.wildventure.buildingScore") }),
								/* @__PURE__ */ _("dd", { children: n.buildingScore }),
								n.coinScore > 0 && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("dt", { children: l("games.wildventure.coinScore") }), /* @__PURE__ */ _("dd", { children: n.coinScore })] })
							] }),
							/* @__PURE__ */ _("button", {
								type: "button",
								className: "wv-secondary",
								onClick: () => d(u === e ? null : e),
								children: l("games.wildventure.finalCards")
							}),
							u === e && /* @__PURE__ */ _("div", {
								className: "wv-final-cards",
								children: n.cards.map((e) => /* @__PURE__ */ _(Q, { id: e }, e))
							})
						]
					}, e);
				})
			}),
			a !== void 0 && a > 0 && /* @__PURE__ */ _("p", { children: l("session.hint.usedCount", { n: a }) }),
			/* @__PURE__ */ v("div", {
				className: "wv-over-actions",
				children: [r && /* @__PURE__ */ _("button", {
					type: "button",
					className: "wv-primary",
					onClick: r,
					children: l("games.wildventure.again")
				}), i && /* @__PURE__ */ _("button", {
					type: "button",
					className: "wv-secondary",
					onClick: i,
					children: l("games.wildventure.back")
				})]
			})
		]
	});
}
//#endregion
//#region src/games/wildventure/options.tsx
function Pt({ value: e, onChange: t }) {
	let n = s(), r = U.safeParse(e), i = r.success ? r.data : U.parse(void 0), a = {
		academy: "games.wildventure.academy",
		tidings: "games.wildventure.tidings",
		mixed: "games.wildventure.mixed"
	}, o = {
		easy: "games.wildventure.easy",
		normal: "games.wildventure.normal",
		hard: "games.wildventure.hard"
	};
	return /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _(S, {
			title: n("games.wildventure.optTheme"),
			children: [
				"academy",
				"tidings",
				"mixed"
			].map((e) => /* @__PURE__ */ _(x, {
				name: "wv-theme",
				value: e,
				checked: i.theme === e,
				accent: H.accent,
				label: n(a[e]),
				hint: n(e === "mixed" ? "games.wildventure.mixedHint" : "games.wildventure.themeHint"),
				onChange: () => t({
					...i,
					theme: e
				})
			}, e))
		}),
		/* @__PURE__ */ v(S, {
			title: n("games.wildventure.optSeason"),
			children: [/* @__PURE__ */ _(x, {
				name: "wv-season",
				value: "spring",
				checked: i.season === "spring",
				accent: H.accent,
				label: n("games.wildventure.spring"),
				onChange: () => t({
					...i,
					season: "spring"
				})
			}), /* @__PURE__ */ _(x, {
				name: "wv-season",
				value: "autumn",
				checked: i.season === "autumn",
				accent: H.accent,
				label: n("games.wildventure.autumn"),
				hint: n("games.wildventure.autumnHint"),
				onChange: () => t({
					...i,
					season: "autumn"
				})
			})]
		}),
		/* @__PURE__ */ _(S, {
			title: n("games.wildventure.optOtto"),
			children: [
				"easy",
				"normal",
				"hard"
			].map((e) => /* @__PURE__ */ _(x, {
				name: "wv-otto",
				value: e,
				checked: i.otto === e,
				accent: H.accent,
				label: n(o[e]),
				onChange: () => t({
					...i,
					otto: e
				})
			}, e))
		}),
		/* @__PURE__ */ v(S, {
			title: n("games.wildventure.optVariants"),
			children: [/* @__PURE__ */ _(b, {
				name: "wv-memory",
				value: "noMemory",
				checked: i.noMemory,
				label: n("games.wildventure.noMemory"),
				onChange: () => t({
					...i,
					noMemory: !i.noMemory
				})
			}), /* @__PURE__ */ _(b, {
				name: "wv-tiebreak",
				value: "tiebreak",
				checked: i.tiebreak,
				label: n("games.wildventure.tiebreak"),
				onChange: () => t({
					...i,
					tiebreak: !i.tiebreak
				})
			})]
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/wildventure/entry.tsx
var Ft = {
	definition: Ie,
	View: vt,
	bot: Ct,
	fx: Mt,
	OverView: Nt,
	Options: Pt,
	locales: {
		zh: {
			name: "荒野冒险家",
			desc: "招募森林伙伴，穿越荒野，争夺社区杯",
			errFinished: "本局已经结束。",
			errChoice: "该选择已不可用，请重新选择。",
			otto: "奥托",
			crow: "乌鸦",
			frog: "青蛙",
			rabbit: "兔子",
			villager: "村民",
			gear: "装备",
			building: "建筑",
			nest: "鸟巢",
			lilypad: "睡莲",
			warren: "兔穴",
			nestBasic: "抽取1张。",
			nestUpgraded: "检视2张，抽取其中1张。",
			lilypadBasic: "冒险1步。",
			lilypadUpgraded: "冒险2步。",
			warrenBasic: "获得2金币。",
			warrenUpgraded: "获得3金币。",
			spring: "春季荒野",
			autumn: "秋季荒野",
			camp: "营地",
			hand: "手牌 {{n}}",
			trashPile: "公共弃牌堆",
			scorePile: "计分牌 {{n}}",
			scoreHidden: "计分牌不可查看。",
			coins: "金币 {{n}}",
			supplies: "补给 {{n}}",
			deck: "牌库 {{n}}",
			cost: "费用 {{n}}",
			turn: "第 {{n}} 回合",
			actions: "主行动 {{n}}／2",
			yourTurn: "你的回合",
			waiting: "等待 {{name}}",
			resolving: "结算中",
			finalTurns: "最后 {{n}} 个回合",
			close: "关闭",
			zoomIn: "放大地图",
			zoomOut: "缩小地图",
			resetMap: "显示完整地图",
			opponentCamp: "查看对手营地",
			details: "查看卡牌",
			confirm: "确认选择",
			selectionCount: "已选 {{n}}／{{max}} 张",
			orderedHint: "依次点击卡牌；编号表示选择顺序。",
			orderTopHint: "按下一张抽取的顺序选择。",
			rubyPairHint: "先选择收入计分区的牌，再选择免费打出的牌。",
			blankSpace: "空白格",
			rewardEnchant: "附魔标记 {{n}}",
			ironSpecial: "给一名村民添加1补给",
			goldSpecial: "激活一名村民",
			rubySpecial: "从弃牌堆选择两张牌，一张收入计分区，另一张免费打出",
			ironConsider: "检视3张：抽取1张，弃置2张",
			goldConsider: "检视5张：抽取2张，弃置3张",
			rubyConsider: "检视5张：收入计分区1张，抽取2张，弃置2张",
			empty: "暂无卡牌",
			free: "自由行动",
			used: "本回合已激活",
			enchanted: "已附魔",
			chooseToken: "选择附魔标记",
			token: "附魔标记 {{n}}",
			home: "家",
			iron: "铁宝箱",
			gold: "金宝箱",
			ruby: "红宝石宝箱",
			rewardGain: "获得 {{n}} 金币",
			rewardDraw: "抽取 {{n}} 张",
			routeCostCoins: "支付 {{n}} 金币",
			routeCostTrash: "弃置 {{n}} 张手牌",
			promptMain: "选择卡牌或起始牌",
			promptDraft: "选择初始村民",
			promptOttoInitiate: "为奥托选择初始村民",
			promptTrashHand: "选择要弃置的手牌",
			promptTuckHand: "选择收入计分区的手牌",
			promptDrawPool: "选择要抽取的牌",
			promptTuckPool: "选择收入计分区的牌",
			promptTrashPool: "选择要弃置的牌",
			promptOrderPool: "排列剩余牌的抽取顺序",
			promptChooseCard: "选择一张牌",
			promptChooseVillager: "选择一名村民",
			promptChooseBuilding: "选择一栋建筑",
			promptChooseGear: "选择一件装备",
			promptChooseStarter: "选择起始牌效果",
			promptChooseSpecies: "选择一种物种",
			promptChooseEffect: "选择要结算的效果",
			promptChooseTrigger: "选择下一项触发效果",
			promptAdventure: "选择前进方向或停步",
			promptClaimReward: "选择本次领取的奖励",
			promptChest: "选择宝箱奖励",
			promptCleanup: "选择下一张收入计分区的牌",
			promptFactorReveal: "选择向对手展示的两张牌",
			promptFactorChoose: "选择展示牌的去向",
			promptInvest: "选择投资金币数量",
			promptWorkshop: "选择从装备获取的金币数量",
			promptChooseTrash: "从公共弃牌堆选择",
			promptJackbot: "激活一张起始牌",
			movePlay: "打出",
			moveActivate: "激活",
			moveEnchant: "附魔",
			moveEndTurn: "结束回合",
			moveSkip: "跳过",
			moveGain: "获得 {{n}} 金币",
			moveDraw: "抽取 {{n}} 张",
			moveAdventure: "冒险 {{n}} 步",
			moveBoth: "支付2金币，依次执行两项",
			moveTuck: "收入计分区",
			moveTrash: "弃置手牌",
			moveReturnTop: "放回牌库顶",
			moveInvest: "投资 {{n}} 金币",
			moveUpgrade: "升级",
			moveSupply: "添加1补给",
			moveRelic: "结算遗物",
			moveChooseStarter: "激活起始牌",
			moveChooseSpecies: "选择物种",
			moveMove: "前往",
			moveStop: "停步并领取奖励",
			moveClaim: "领取奖励",
			moveChestHand: "收入计分区 {{n}} 张手牌",
			moveChestSpecial: "领取特殊奖励",
			moveChestConsider: "检视 {{n}} 张并选牌",
			moveResolveTrigger: "结算触发效果",
			moveCopy: "复制效果",
			moveTrashTop: "弃置牌库顶牌",
			moveRevealedDraw: "抽取展示牌，其余收入计分区",
			moveRevealedTuck: "展示牌收入计分区，抽取其余",
			moveEscDrawTrash: "抽取1张，弃置2张",
			moveEscDrawGive: "抽取2张，对手抽取1张",
			movePayDraw: "支付 {{n}} 金币以抽取 {{n}} 张",
			moveRemoveSupply: "移除1补给，激活睡莲",
			moveKeepSupply: "保留补给",
			moveContinue: "继续",
			moveWorkshopTake: "获取 {{n}} 金币",
			moveChooseInitiate: "选择村民",
			scenePlay: "{{name}} 打出了 {{card}}",
			sceneActivate: "{{name}} 激活了 {{card}}",
			sceneGain: "{{name}} 获得了 {{n}} 金币",
			sceneDraw: "{{name}} 抽取了 {{n}} 张牌",
			sceneTrash: "{{name}} 弃置了 {{n}} 张牌",
			sceneTuck: "{{name}} 将 {{n}} 张牌收入计分区",
			sceneInvest: "{{name}} 进行了投资",
			sceneMove: "{{name}} 沿路线前进",
			sceneHome: "{{name}} 返回了家",
			sceneEnchant: "{{name}} 为{{card}}附魔",
			sceneSupply: "{{name}} 的{{card}}补给 {{n}}",
			sceneReveal: "{{name}} 展示了卡牌",
			sceneTurn: "轮到 {{name}}",
			sceneJackbot: "奥托使用两张同费牌，你下回合额外激活起始牌",
			sceneFinish: "对局结束",
			optTheme: "主题牌组",
			academy: "学院",
			tidings: "讯息",
			mixed: "混合变体",
			themeHint: "核心牌与所选主题共75张。",
			mixedHint: "双人变体：合并99张牌，开局抽8张后弃置3张。",
			optSeason: "冒险地图",
			autumnHint: "部分路线需要支付金币或弃置手牌。",
			optOtto: "单人对手奥托",
			easy: "简单",
			normal: "普通",
			hard: "困难",
			optVariants: "可选规则",
			noMemory: "可查看本人的计分牌",
			tiebreak: "平分时比较金币，再比较村民分数",
			winner: "{{name}} 获得社区杯",
			tie: "共同获得社区杯",
			finalScore: "最终得分",
			villagerScore: "村民得分",
			gearScore: "装备得分",
			buildingScore: "建筑得分",
			coinScore: "金币得分",
			again: "再来一局",
			back: "返回房间",
			finalCards: "查看计分卡牌",
			fxPlay: "打出卡牌 · 补给 {{n}}",
			fxActivate: "激活能力",
			fxActivateSupply: "激活能力 · 补给 −{{n}}",
			fxGain: "获得 {{n}} 金币",
			fxGearGain: "补给 −{{taken}} · 获得 {{n}} 金币",
			logUpgrade: "{{name}} 升级了{{card}}",
			logToken: "{{name}} 获得附魔标记 {{token}}",
			fxPlayBuilding: "建造建筑",
			fxDraw: "抽取 {{n}} 张牌",
			fxTrash: "弃置 {{n}} 张牌",
			fxTuck: "收入计分区 {{n}} 张牌",
			fxConsider: "检视 {{n}} 张牌",
			fxReturn: "放回牌库顶 {{n}} 张牌",
			fxGive: "交给对手 {{n}} 张牌",
			fxTrigger: "触发建筑能力",
			fxSupply: "补给 {{n}}",
			fxInvest: "投资完成 · 补给 +{{n}}",
			fxEnchant: "建筑附魔完成",
			fxToken: "获得附魔标记 {{token}}",
			fxUpgrade: "起始牌已升级",
			fxRelic: "发动遗物能力",
			fxMove: "冒险者抵达",
			fxHome: "返回家",
			fxChest: "开启{{chest}}",
			fxReveal: "展示 {{n}} 张牌",
			fxPay: "支付 {{n}} 金币",
			rules: "目标：\n· 招募三种村民、收集装备并投资建筑，争夺最高分。\n准备：\n· 核心与所选主题共75张；每人5枚金币、5张手牌。\n· 后手先选初始村民；双方各放置2份补给。\n· 混合变体使用99张牌，开局抽8张后弃置3张。\n流程：\n· 每回合必须执行两次主行动：支付费用打牌，或激活起始牌、普通村民。\n· 同一张牌每回合只能通过主行动激活一次；村民需移除1份补给。\n· 自由行动村民每回合也只能激活一次；附魔建筑是自由行动。\n· 效果激活不移除补给，不占上述次数；零补给村民仍可被效果激活。\n· 装备可被双方触发；触发者从装备取1份补给作为金币。\n· 建筑只由拥有者触发；新打出的牌不触发自身。\n· 同时触发由触发者决定顺序；先完整结算，再继续当前效果。\n· 投资可支付至指定数量的金币；每枚转为该建筑的1份补给。\n· 检视为秘密查看牌顶，依次结算指定效果，再自行排列剩牌放回牌顶。\n· 弃牌堆可随时查看，但不得调整顺序；计分牌默认不可查看。\n冒险：\n· 向前移动至多指定步数，有能力时至少移动1步，只领取落点奖励。\n· 秋季付费路线先支付金币或弃置手牌，完整结算触发后再抵达。\n· 起始牌格可选择激活或升级；附魔标记每种至多持有1个。\n· 铁宝箱：可以将1张手牌收入计分区、给村民增加1份补给，或检视牌堆顶的3张牌，从中抽取1张并弃置其余2张。\n· 金宝箱：可以将2张手牌收入计分区、激活村民，或检视牌堆顶的5张牌，从中抽取2张并弃置其余3张。\n· 红宝石宝箱：可以将3张手牌收入计分区；也可以从弃牌堆中取出两张牌，将其中一张收入计分区，另一张免费打出。\n· 红宝石宝箱还可以检视牌堆顶部的5张牌，依次将其中1张收入计分区、抽取2张，再弃置其余2张。\n回合末与结束：\n· 抵达路线终点后，回合末先返回家，再自选顺序处理零补给牌。\n· 零补给村民收入计分区；装备先结算遗物，再收入计分区。\n· 牌库耗尽后完成当前回合，然后双方各进行一个最终回合。\n· 村民得分为三物种数量中的最小值乘最大值；缺少一种则为0分。\n· 装备得分为计分装备数乘已附魔建筑数；建筑按补给数计分。\n· 金币默认不计分；平分共同获胜，可选金币与村民得分破同分。\n奥托单人模式：\n· 奥托使用另一套主题牌，无手牌与起始牌，忽略卡文并免费使用牌。\n· 每回合先从双方所有装备各取1枚金币；其空装备直接计分，不结算遗物。\n· 奥托翻开2张牌，使用其中费用较低的牌；费用相同时，两张牌均使用。你的下一个回合可以额外激活起始牌。\n· 奥托村民、建筑直接计分，装备正常入场；初始村民保留到终局。\n· 简单模式每5枚金币获得1分；普通每10枚金币、困难每5枚金币增加1名数量最少的物种的村民。\n· 奥托的每件装备在简单或普通难度下获得2分，在困难难度下获得3分；建筑按其费用计分。",
			c400Name: "可回收垃圾桶",
			c400Text: "弃置至少一张牌时触发。遗物：从公共弃牌堆收入一张牌到计分区。",
			c401Name: "兔官僚",
			c401Text: "选择抽取2张或冒险2步。可支付2金币依次执行两项。",
			c402Name: "人口普查员",
			c402Text: "激活一张起始牌，然后展示牌库顶牌。若其物种与该起始牌相同，将其收入计分区；否则抽取它。",
			c403Name: "私人家教",
			c403Text: "自由行动：激活你的一名费用不超过现有金币数量的村民。",
			c404Name: "百万富翁钱多多",
			c404Text: "获得5金币。",
			c405Name: "拖延症研究生",
			c405Text: "抽取1张。若本卡没有补给，再将一张手牌收入计分区。",
			c406Name: "职员训练师",
			c406Text: "自由行动：弃置一张手牌，再激活你的一名费用不超过所弃牌费用的村民。",
			c407Name: "青蛙巫师",
			c407Text: "冒险3步。所领取奖励中的“获得金币”改为“抽取卡牌”。",
			c408Name: "无甲英雄",
			c408Text: "冒险X步，X为你场上的装备数量。",
			c409Name: "变形者",
			c409Text: "选择对手的一名村民，结算其效果。若复制自由行动，本卡也视为自由行动。",
			c410Name: "冒险家学徒",
			c410Text: "自由行动：冒险1步，不领取落点奖励。",
			c411Name: "当铺老板保罗",
			c411Text: "自由行动：弃置一张手牌，再选择获得2金币或抽取1张。",
			c412Name: "兼职员工",
			c412Text: "获得2金币。若本卡没有补给，再冒险4步。",
			c413Name: "赌徒蛙",
			c413Text: "弃置牌库顶牌。若它是村民，结算其效果；若为自由行动，本卡也视为自由行动。",
			c414Name: "乌鸦先祖",
			c414Text: "抽取3张。",
			c415Name: "友善的乌鸦",
			c415Text: "弃置一张手牌。若为乌鸦，抽取3张；若为青蛙，冒险3步；若为兔子，获得6金币。",
			c416Name: "关键羽毛",
			c416Text: "对手检视4张并展示其中2张。选择抽取展示的牌并将其余收入计分区，或反过来；未展示的牌收入计分区前不可查看。",
			c417Name: "链鞭",
			c417Text: "返回家时触发。遗物：可从手牌展示一名乌鸦村民并将其收入计分区。",
			c418Name: "荒野地图",
			c418Text: "激活睡莲时触发。遗物：给你的一名青蛙村民添加1补给。",
			c419Name: "巨翼漫游者",
			c419Text: "选择一种物种，检视4张：展示并抽取该物种的全部牌，弃置其余牌。再冒险X步，X为本次弃牌数。",
			c420Name: "蜗牛鸦",
			c420Text: "检视3张，选择抽取1张并弃置2张，或抽取2张并让对手抽取1张。",
			c421Name: "猜贝壳游戏大师",
			c421Text: "检视3张：收入计分区1张，抽取1张，弃置1张。",
			c422Name: "邮政合同",
			c422Text: "打出乌鸦牌时触发。遗物：获得3金币。",
			c423Name: "大师工匠",
			c423Text: "从手牌打出一件装备并支付费用，然后结算其遗物效果。该装备仍留在场上。",
			c424Name: "附魔失物招领箱",
			c424Text: "将至少一张场外卡牌收入计分区时触发。遗物：将公共弃牌堆顶牌收入计分区。",
			c425Name: "绝佳的投资机会",
			c425Text: "自由行动：获得2金币。",
			c426Name: "24K纯萝卜戒指",
			c426Text: "本回合末有两名村民因零补给收入计分区时触发。遗物：获得3金币。",
			c427Name: "平民圣骑士",
			c427Text: "冒险2步，然后双方依次激活各自兔穴。",
			c428Name: "慈善捐助者",
			c428Text: "将全部金币交给对手，然后获得5金币。",
			c429Name: "懊悔卖家",
			c429Text: "检视2张，展示其中1张并让对手抽取它，然后获得5金币。",
			c430Name: "宅家者",
			c430Text: "获得2金币。若本回合激活过起始牌，抽取1张；否则再获得1金币。",
			c431Name: "顶级店长",
			c431Text: "弃置牌库顶牌，然后获得等同于该牌费用的金币。",
			c432Name: "飞翔的邮递员",
			c432Text: "抽取1张，然后激活鸟巢。",
			c433Name: "银行",
			c433Text: "每次获得X金币时，若X大于本卡补给数，可投资1。附魔：将本卡全部补给移到另一栋建筑。",
			c434Name: "旅游信息处",
			c434Text: "冒险时可改领本次途经格的任一奖励。附魔：冒险3步。",
			c435Name: "废品堆",
			c435Text: "每次弃置X张牌时，可投资1。附魔后可改为投资X。",
			c436Name: "财务自由单身贵蛙",
			c436Text: "从手牌打出一张牌，忽略费用。",
			c437Name: "辛勤的花艺家",
			c437Text: "获得4金币。可再移除本卡1补给以激活睡莲。",
			c438Name: "冒险公会",
			c438Text: "打出青蛙牌时，可投资1。附魔：激活一名费用不超过本卡补给数的己方村民。",
			c439Name: "工坊",
			c439Text: "触发己方装备时，可从该装备取2补给作为金币。附魔：结算一件己方装备的遗物效果。",
			c440Name: "丰厚养老金",
			c440Text: "激活兔穴时触发。遗物：给一名己方兔子村民添加1补给。",
			c441Name: "邮袋",
			c441Text: "每次抽取至少一张牌时触发。遗物：抽取3张。",
			c442Name: "二手剑",
			c442Text: "打出装备时触发。遗物：检视3张，可展示并抽取其中一件装备。",
			c443Name: "野营地",
			c443Text: "打出乌鸦牌时，可投资1。附魔：检视1张，可打出其中一张青蛙或兔子牌，费用减少本卡补给数。",
			c444Name: "非凡棱镜魔杖",
			c444Text: "返回家时触发。遗物：可展示并将手牌中的一名青蛙村民收入计分区。",
			c445Name: "邮局",
			c445Text: "打出建筑时，可投资2。附魔：投资X并抽取X张，X为己方场上建筑数；可少投资，但仍抽取X张。",
			c446Name: "铁鸦撬棍",
			c446Text: "打开任意宝箱时触发。遗物：打开一个铁宝箱。",
			c447Name: "传送卷轴",
			c447Text: "冒险时触发。遗物：可直接移至荒野路线的睡莲格，不领取奖励。",
			c448Name: "睡袋",
			c448Text: "激活鸟巢时触发。遗物：给己方一名乌鸦村民添加1补给。",
			c500Name: "戴夫",
			c500Text: "冒险2步。",
			c501Name: "辛勤的树艺家",
			c501Text: "抽取2张。可再移除本卡1补给以激活睡莲。",
			c502Name: "社区中心",
			c502Text: "打出兔子牌时，可投资1。附魔：激活己方一名费用不超过本卡补给数的村民。",
			c503Name: "电报局",
			c503Text: "激活鸟巢抽到牌时，可立即展示其中的牌并支付费用打出。附魔：获得4金币，然后激活鸟巢。",
			c504Name: "占卜手镯",
			c504Text: "检视卡牌时触发。遗物：检视1张，将其中1张收入计分区。",
			c505Name: "出生点",
			c505Text: "打出青蛙牌时触发。遗物：获得3金币。",
			c506Name: "股市",
			c506Text: "打出费用大于本卡补给数的牌时，可投资1。附魔：获得本卡补给数两倍的金币。",
			c507Name: "钓鱼竿",
			c507Text: "弃置至少一张牌时触发。遗物：从公共弃牌堆抽取一张牌。",
			c508Name: "分拣室",
			c508Text: "你的所有检视数量增加1。附魔：打开一个铁宝箱。",
			c509Name: "天文台",
			c509Text: "将X张场外卡牌收入计分区时，可投资X。附魔后还可支付X金币以抽取X张。",
			c510Name: "暗道探索者",
			c510Text: "检视3张，然后冒险1步。",
			c511Name: "翻垃圾桶者",
			c511Text: "弃置一张手牌，再将另一张手牌收入计分区。",
			c512Name: "生病的皮特",
			c512Text: "自由行动：检视1张，可弃置其中1张。",
			c513Name: "邮政局局长",
			c513Text: "自由行动：支付1金币以抽取1张。",
			c514Name: "乌鸦快递员",
			c514Text: "检视3张：抽取1张，可支付费用打出1张，弃置其余牌。",
			c515Name: "拾荒者",
			c515Text: "支付费用，打出公共弃牌堆顶牌。",
			c516Name: "侃大山",
			c516Text: "检视X张并抽取其中1张，X为你场上的村民数。",
			c517Name: "社区核心",
			c517Text: "获得等同于双方场上村民总数的金币。",
			c518Name: "报童",
			c518Text: "抽取1张，然后获得2金币。",
			c519Name: "内向冒险家",
			c519Text: "冒险5步，宝箱奖励必须选择将手牌收入计分区。然后返回家。",
			c520Name: "大力士乔",
			c520Text: "冒险3步。",
			c521Name: "探测犬罗迪",
			c521Text: "检视1张，将其中1张收入计分区。",
			c522Name: "乔的父亲",
			c522Text: "自由行动：冒险1步。",
			c523Name: "挥金如土的比利",
			c523Text: "支付10金币，打开一个红宝石宝箱。",
			c524Name: "官方授权商品",
			c524Text: "打出兔子牌时触发。遗物：获得3金币。",
			c525Name: "虚空珠宝",
			c525Text: "弃置至少一张牌时触发。遗物：可支付费用打出公共弃牌堆顶牌。",
			c526Name: "打折券",
			c526Text: "投资时触发。遗物：获得4金币。",
			c527Name: "干净的啃老族",
			c527Text: "冒险2步。若本回合激活过起始牌，抽取1张；否则获得1金币。",
			c528Name: "末日预言者",
			c528Text: "弃置牌库顶牌。冒险X步，X为弃牌堆顶3张牌的不同物种数。",
			c529Name: "不错的临时教师",
			c529Text: "自由行动：激活一名费用不超过你手牌数的己方村民。",
			c530Name: "移民局",
			c530Text: "打出兔子牌时，可投资1。附魔：检视1张，可打出其中一张青蛙或乌鸦牌，费用减少本卡补给数。",
			c531Name: "斗士餐馆",
			c531Text: "返回家时，可投资1。附魔后可改为投资2。",
			c532Name: "衔尾蛇巨著",
			c532Text: "实际支付至少1金币后金币变为0时触发。遗物：抽取2张。",
			c533Name: "派对帽",
			c533Text: "打出村民时触发。遗物：获得等同于双方场上村民总数的金币。",
			c534Name: "观光客",
			c534Text: "冒险1步，然后再次冒险1步。",
			c535Name: "乌鸦先生",
			c535Text: "可展示手牌中的一名村民并结算其效果，然后将该牌收入计分区。复制自由行动时，本卡也视为自由行动。",
			c536Name: "传奇殿堂",
			c536Text: "打出乌鸦牌时，可投资1。附魔：激活一名费用不超过本卡补给数的己方村民。",
			c537Name: "占卜师",
			c537Text: "自由行动：检视3张。",
			c538Name: "呱呱温泉",
			c538Text: "打出青蛙牌时，可投资1。附魔：检视1张，可打出其中一张乌鸦或兔子牌，费用减少本卡补给数。",
			c539Name: "社会蛀虫",
			c539Text: "获得4金币。弃置一张手牌或牌库顶牌；若弃置的是兔子牌，激活兔穴。",
			c540Name: "巫师帽",
			c540Text: "检视卡牌时触发。遗物：抽取3张，然后弃置3张手牌。",
			c541Name: "青蛙侦探",
			c541Text: "支付公共弃牌堆顶牌的费用，将其收入计分区。",
			c542Name: "天堂之矛",
			c542Text: "返回家时触发。遗物：可展示并将手牌中的一名兔子村民收入计分区。",
			c543Name: "采石场",
			c543Text: "打出建筑时，获得2金币并抽取1张。附魔：投资X并冒险X步，X为己方场上建筑数；可少投资，仍完整冒险。",
			c544Name: "冒险果汁",
			c544Text: "冒险时触发。遗物：抽取2张。",
			c545Name: "拒绝浪费",
			c545Text: "弃置装备后，可支付费用打出其中一件。附魔后，若这样打出，可再投资1。",
			c546Name: "独眼杰克",
			c546Text: "依次获得1金币、抽取1张并冒险1步。",
			c547Name: "猜贝壳游戏诈骗师",
			c547Text: "从弃牌堆顶检视3张：将1张收入计分区，抽取1张，将其余牌按自选顺序放到主牌库顶。",
			c548Name: "种族平等愤世嫉俗者",
			c548Text: "自由行动：弃置牌库顶牌，再激活与其物种相同的起始牌。",
			c600Name: "荣誉学生",
			c600Text: "冒险1步。若本卡没有补给，打开一个铁宝箱。",
			c800Name: "新手商人",
			c800Text: "获得4金币。",
			c900Name: "新手英雄",
			c900Text: "冒险2步。",
			c3800Name: "新手邮递员",
			c3800Text: "抽取2张。"
		},
		en: {
			name: "A Wild Venture",
			desc: "Recruit woodland friends and venture into the wilds",
			errFinished: "This game has ended.",
			errChoice: "That choice is no longer available.",
			otto: "Otto",
			crow: "Crow",
			frog: "Frog",
			rabbit: "Rabbit",
			villager: "Villager",
			gear: "Gear",
			building: "Building",
			nest: "Nest",
			lilypad: "Lilypad",
			warren: "Warren",
			nestBasic: "Draw 1.",
			nestUpgraded: "Consider 2; Draw 1.",
			lilypadBasic: "Adventure 1.",
			lilypadUpgraded: "Adventure 2.",
			warrenBasic: "Gain 2.",
			warrenUpgraded: "Gain 3.",
			spring: "Spring Wilds",
			autumn: "Autumn Wilds",
			camp: "Camp",
			hand: "Hand {{n}}",
			trashPile: "Trash pile",
			scorePile: "Tucked {{n}}",
			scoreHidden: "Tucked cards cannot be inspected.",
			coins: "Coins {{n}}",
			supplies: "Supplies {{n}}",
			deck: "Deck {{n}}",
			cost: "Cost {{n}}",
			turn: "Turn {{n}}",
			actions: "Main actions {{n}}/2",
			yourTurn: "Your turn",
			waiting: "Waiting for {{name}}",
			resolving: "Resolving",
			finalTurns: "{{n}} final turns left",
			close: "Close",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			resetMap: "Show full map",
			opponentCamp: "Opponent's camp",
			details: "Card details",
			confirm: "Confirm",
			selectionCount: "Selected {{n}}/{{max}}",
			orderedHint: "Tap cards in order; numbers show your sequence.",
			orderTopHint: "Select in the order to be drawn next.",
			rubyPairHint: "Choose the card to Tuck first, then the card to Play for free.",
			blankSpace: "Empty space",
			rewardEnchant: "Enchantment {{n}}",
			ironSpecial: "Add 1 Supply to a Villager",
			goldSpecial: "Activate a Villager",
			rubySpecial: "Choose 2 from Trash: Tuck 1 and Play the other for free",
			ironConsider: "Consider 3: Draw 1, Trash 2",
			goldConsider: "Consider 5: Draw 2, Trash 3",
			rubyConsider: "Consider 5: Tuck 1, Draw 2, Trash 2",
			empty: "No cards",
			free: "Free Action",
			used: "Activated this turn",
			enchanted: "Enchanted",
			chooseToken: "Choose an Enchantment",
			token: "Enchantment {{n}}",
			home: "Home",
			iron: "Iron Chest",
			gold: "Gold Chest",
			ruby: "Ruby Chest",
			rewardGain: "Gain {{n}}",
			rewardDraw: "Draw {{n}}",
			routeCostCoins: "Pay {{n}} coins",
			routeCostTrash: "Trash {{n}} from hand",
			promptMain: "Choose a card or Starter",
			promptDraft: "Choose your Initiate",
			promptOttoInitiate: "Choose Otto's Initiate",
			promptTrashHand: "Choose cards to Trash from hand",
			promptTuckHand: "Choose cards to Tuck from hand",
			promptDrawPool: "Choose cards to Draw",
			promptTuckPool: "Choose cards to Tuck",
			promptTrashPool: "Choose cards to Trash",
			promptOrderPool: "Order cards for the top of the deck",
			promptChooseCard: "Choose a card",
			promptChooseVillager: "Choose a Villager",
			promptChooseBuilding: "Choose a Building",
			promptChooseGear: "Choose a Gear",
			promptChooseStarter: "Choose a Starter effect",
			promptChooseSpecies: "Choose a Species",
			promptChooseEffect: "Choose an effect",
			promptChooseTrigger: "Choose the next triggered effect",
			promptAdventure: "Choose a path or stop",
			promptClaimReward: "Choose a reward to claim",
			promptChest: "Choose a Chest reward",
			promptCleanup: "Choose the next card to Tuck",
			promptFactorReveal: "Choose two cards to reveal",
			promptFactorChoose: "Choose what to do with the revealed cards",
			promptInvest: "Choose how much to Invest",
			promptWorkshop: "Choose coins to take from your Gear",
			promptChooseTrash: "Choose from the Trash pile",
			promptJackbot: "Activate a Starter",
			movePlay: "Play",
			moveActivate: "Activate",
			moveEnchant: "Enchant",
			moveEndTurn: "End turn",
			moveSkip: "Skip",
			moveGain: "Gain {{n}}",
			moveDraw: "Draw {{n}}",
			moveAdventure: "Adventure {{n}}",
			moveBoth: "Pay 2 to do both",
			moveTuck: "Tuck",
			moveTrash: "Trash from hand",
			moveReturnTop: "Return to deck",
			moveInvest: "Invest {{n}}",
			moveUpgrade: "Upgrade",
			moveSupply: "Add 1 Supply",
			moveRelic: "Resolve Relic",
			moveChooseStarter: "Activate Starter",
			moveChooseSpecies: "Choose Species",
			moveMove: "Move",
			moveStop: "Stop and claim",
			moveClaim: "Claim reward",
			moveChestHand: "Tuck {{n}} from hand",
			moveChestSpecial: "Claim special reward",
			moveChestConsider: "Consider {{n}} and choose",
			moveResolveTrigger: "Resolve trigger",
			moveCopy: "Copy effect",
			moveTrashTop: "Trash top of deck",
			moveRevealedDraw: "Draw revealed; Tuck the rest",
			moveRevealedTuck: "Tuck revealed; Draw the rest",
			moveEscDrawTrash: "Draw 1; Trash 2",
			moveEscDrawGive: "Draw 2; opponent Draws 1",
			movePayDraw: "Pay {{n}} to Draw {{n}}",
			moveRemoveSupply: "Remove 1 Supply; activate Lilypad",
			moveKeepSupply: "Keep Supplies",
			moveContinue: "Continue",
			moveWorkshopTake: "Take {{n}} coins",
			moveChooseInitiate: "Choose Initiate",
			scenePlay: "{{name}} played {{card}}",
			sceneActivate: "{{name}} activated {{card}}",
			sceneGain: "{{name}} gained {{n}} coins",
			sceneDraw: "{{name}} drew {{n}} cards",
			sceneTrash: "{{name}} Trashed {{n}} cards",
			sceneTuck: "{{name}} Tucked {{n}} cards",
			sceneInvest: "{{name}} Invested",
			sceneMove: "{{name}} moved along the path",
			sceneHome: "{{name}} returned Home",
			sceneEnchant: "{{name}} Enchanted {{card}}",
			sceneSupply: "{{name}} · {{card}} Supplies: {{n}}",
			sceneReveal: "{{name}} revealed cards",
			sceneTurn: "{{name}}'s turn",
			sceneJackbot: "Jackbot! Activate a Starter at the start of your next turn",
			sceneFinish: "Game over",
			optTheme: "Theme deck",
			academy: "Academy",
			tidings: "Tidings",
			mixed: "An Even Wilder Venture",
			themeHint: "75 cards: Core and one Theme.",
			mixedHint: "Two-player variant: all 99 cards; start with 8 and Trash 3.",
			optSeason: "Adventure board",
			autumnHint: "Some routes cost coins or cards from hand.",
			optOtto: "Solo opponent: Otto",
			easy: "Easy",
			normal: "Normal",
			hard: "Hard",
			optVariants: "Optional rules",
			noMemory: "Inspect your own Tucked cards",
			tiebreak: "Break ties by coins, then Villager score",
			winner: "{{name}} wins the Community Cup",
			tie: "Shared Community Cup",
			finalScore: "Final score",
			villagerScore: "Villager score",
			gearScore: "Gear score",
			buildingScore: "Building score",
			coinScore: "Coin score",
			again: "Play again",
			back: "Back to lobby",
			finalCards: "Inspect scoring cards",
			fxPlay: "Played · Supplies: {{n}}",
			fxActivate: "Ability activated",
			fxActivateSupply: "Activated · −{{n}} Supply",
			fxGain: "Coins gained: {{n}}",
			fxGearGain: "Supply −{{taken}} · coins gained: {{n}}",
			logUpgrade: "{{name}} upgraded {{card}}",
			logToken: "{{name}} collected Enchantment {{token}}",
			fxPlayBuilding: "Building played",
			fxDraw: "Cards drawn: {{n}}",
			fxTrash: "Cards trashed: {{n}}",
			fxTuck: "Cards tucked: {{n}}",
			fxConsider: "Cards considered: {{n}}",
			fxReturn: "Returned to deck: {{n}}",
			fxGive: "Cards given: {{n}}",
			fxTrigger: "Building ability triggered",
			fxSupply: "Supplies: {{n}}",
			fxInvest: "Invested · +{{n}} Supplies",
			fxEnchant: "Building enchanted",
			fxToken: "Enchantment {{token}} collected",
			fxUpgrade: "Starter upgraded",
			fxRelic: "Relic ability activated",
			fxMove: "Adventurer arrived",
			fxHome: "Returned Home",
			fxChest: "Opened {{chest}}",
			fxReveal: "Cards revealed: {{n}}",
			fxPay: "Coins paid: {{n}}",
			rules: "Goal:\n· Recruit three Species, collect Gear, and Invest to score.\nSetup:\n· Use 75 Core and Theme cards; start with 5 coins and 5 cards.\n· The second player chooses an Initiate first; add 2 Supplies.\n· The mixed variant uses 99 cards. Draw 8 cards, then Trash 3 of them.\nPlay:\n· Take two Main Actions: pay to Play, or Activate a Starter or normal Villager.\n· Each card can be Activated once by a Main Action per turn; remove 1 Villager Supply.\n· Free Action Villagers can also be used once per turn; Enchanting is a Free Action.\n· Effect Activations cost no Supplies or actions, even on empty Villagers.\n· Either player can trigger Gear, taking 1 Supply from it as a coin.\n· Buildings trigger only for their owner; a newly played card cannot trigger itself.\n· The triggering player orders simultaneous triggers; resolve each before continuing.\n· Invest up to the specified number of coins as Supplies on that Building.\n· Consider secretly, resolve the listed effects, then order the remainder atop the deck.\n· Inspect the Trash pile without reordering; Tucked cards normally cannot be inspected.\nAdventure:\n· Move forward up to the stated distance, at least 1 if able; claim only the final reward.\n· Pay Autumn route costs and resolve their triggers before arriving.\n· Starter spaces allow Activation or upgrading; hold at most one Enchantment of each type.\n· Iron chest: Choose one option: Tuck 1 hand card, add 1 Supply to a Villager, or Consider the top 3 cards of the deck and Draw 1 and Trash the other 2.\n· Gold chest: Choose one option: Tuck 2 hand cards, Activate a Villager, or Consider the top 5 cards of the deck and Draw 2 and Trash the other 3.\n· Ruby chest: Tuck 3 cards from your hand, or take 2 cards from your Trash pile, Tuck one and Play the other for free.\n· A Ruby chest also lets you Consider the top 5 cards of the deck, then Tuck 1, Draw 2 and Trash the other 2, in that order.\nTurn end and scoring:\n· At turn end, return Home from a path end, then order your empty cards.\n· Tuck empty Villagers; resolve each empty Gear Relic before Tucking it.\n· When the deck empties, finish this turn, then take one final turn each.\n· Villagers score the smallest Species count times the largest; a missing Species scores zero.\n· Your Tucked Gear score their quantity multiplied by the number of your Enchanted Buildings. Each Building scores according to its Supplies.\n· Coins normally score nothing; share ties, or optionally break them by coins then Villagers.\nSolo with Otto:\n· Otto uses the other Theme, has no hand or Starters, ignores card text, and uses cards for free.\n· Each turn Otto takes 1 coin from every Gear; his empty Gear are Tucked without Relics.\n· Otto reveals 2 cards and uses the cheaper card. If their costs are equal, he uses both, and you may activate your Starter one extra time on your next turn.\n· Otto Tucks Villagers and Buildings, plays Gear, and keeps setup Villagers until game end.\n· On Easy, Otto scores 1 point per 5 coins. On Normal, add one Villager of his least-common Species per 10 coins; on Hard, add one per 5 coins.\n· Each of Otto’s Gear scores 2 points on Easy or Normal and 3 points on Hard. Each of his Buildings scores points equal to its cost.",
			c400Name: "Recycle Bin",
			c400Text: "Triggers when you Trash one or more cards. Relic: Tuck any card from the Trash pile.",
			c401Name: "Bunny Bureaucrat",
			c401Text: "Choose Draw 2 or Adventure 2. You may pay 2 coins to do both, in order.",
			c402Name: "Census Taker",
			c402Text: "Activate a Starter, then reveal the top card of the deck. Tuck it if its Species matches the Starter; otherwise Draw it.",
			c403Name: "Private Tutor",
			c403Text: "Free Action: Activate one of your Villagers costing no more than your coins.",
			c404Name: "Maxi Millions",
			c404Text: "Gain 5.",
			c405Name: "Procrastinating Postgrad",
			c405Text: "Draw 1. Then, if this card has no Supplies, Tuck a card from your hand.",
			c406Name: "Personnel Trainer",
			c406Text: "Free Action: Trash a card from your hand. Activate one of your Villagers costing no more than the Trashed card.",
			c407Name: "Frog Wizard",
			c407Text: "Adventure 3. In the reward you claim, read Gain as Draw.",
			c408Name: "Gearless Hero",
			c408Text: "Adventure X, where X is your Gear in play.",
			c409Name: "Shapechanger",
			c409Text: "Choose an opponent's Villager and resolve its effects. If it is a Free Action, so is this card.",
			c410Name: "Apprentice Adventurer",
			c410Text: "Free Action: Adventure 1 without claiming a reward.",
			c411Name: "Pawn Shop Paul",
			c411Text: "Free Action: Trash a card from your hand, then choose Gain 2 or Draw 1.",
			c412Name: "Part-Timer",
			c412Text: "Gain 2. Then, if this card has no Supplies, Adventure 4.",
			c413Name: "Frog Gambler",
			c413Text: "Trash the top card of the deck. If it is a Villager, resolve its effects. If it is a Free Action, so is this card.",
			c414Name: "Crow Ancestor",
			c414Text: "Draw 3.",
			c415Name: "Friendly Crow",
			c415Text: "Trash a card from your hand. If Crow, Draw 3; if Frog, Adventure 3; if Rabbit, Gain 6.",
			c416Name: "Factor Feather",
			c416Text: "Your opponent Considers 4 and reveals 2. Choose to Draw the revealed cards and Tuck the others, or Tuck the revealed cards and Draw the others. Do not inspect unrevealed cards before Tucking them.",
			c417Name: "Chainwhip",
			c417Text: "Triggers when you return Home. Relic: You may reveal and Tuck a Crow Villager from your hand.",
			c418Name: "Map of the Wilds",
			c418Text: "Triggers when you activate your Lilypad. Relic: Add 1 Supply to one of your Frog Villagers.",
			c419Name: "Greatwing Wanderer",
			c419Text: "Choose a Species. Consider 4: reveal and Draw all cards of that Species, Trash the others. Then Adventure X, where X is the number Trashed.",
			c420Name: "Escarcrow",
			c420Text: "Consider 3: choose Draw 1 and Trash 2, or Draw 2 and let your opponent Draw 1.",
			c421Name: "Shell Game Master",
			c421Text: "Consider 3: Tuck 1, Draw 1, Trash 1.",
			c422Name: "Postal Contract",
			c422Text: "Triggers when you play a Crow card. Relic: Gain 3.",
			c423Name: "Master Craftsman",
			c423Text: "Play a Gear from your hand, paying its cost, then resolve its Relic effect without Tucking it.",
			c424Name: "Enchanted Lost-and-Found Box",
			c424Text: "Triggers when you Tuck one or more cards from outside play. Relic: Tuck the top card of the Trash pile.",
			c425Name: "Excellent Investment Opportunity",
			c425Text: "Free Action: Gain 2.",
			c426Name: "24 Carrot Ring",
			c426Text: "Triggers when two Villagers are Tucked from play for having no Supplies at the end of a turn. Relic: Gain 3.",
			c427Name: "Paladin of the Populace",
			c427Text: "Adventure 2, then both players activate their Warren, you first.",
			c428Name: "Charitable Giver",
			c428Text: "Give all your coins to your opponent, then Gain 5.",
			c429Name: "Remorseful Seller",
			c429Text: "Consider 2: reveal 1 for your opponent to Draw, then Gain 5.",
			c430Name: "Homebody",
			c430Text: "Gain 2. If you activated a Starter this turn, Draw 1; otherwise Gain 1.",
			c431Name: "Top Shopkeep",
			c431Text: "Trash the top card of the deck, then Gain coins equal to its cost.",
			c432Name: "Soaring Postie",
			c432Text: "Draw 1, then activate your Nest.",
			c433Name: "Bank",
			c433Text: "When you Gain X, if X exceeds the Supplies here, Invest 1. Enchant: Move all Supplies here to another Building.",
			c434Name: "Tourist Information",
			c434Text: "When Adventuring, you may claim a reward you passed over instead of your destination. Enchant: Adventure 3.",
			c435Name: "Scrapheap",
			c435Text: "When you Trash X cards, Invest 1. While Enchanted, you may Invest X instead.",
			c436Name: "Independently Wealthy Frog",
			c436Text: "Play a card from your hand, ignoring its cost.",
			c437Name: "Hardworking Florist",
			c437Text: "Gain 4. You may remove 1 Supply from this card to activate your Lilypad.",
			c438Name: "Adventure Guild",
			c438Text: "When you play a Frog card, Invest 1. Enchant: Activate one of your Villagers costing no more than the Supplies here.",
			c439Name: "Workshop",
			c439Text: "When you trigger your own Gear, you may take 2 Supplies as coins instead of 1. Enchant: Resolve one of your Gear's Relic effects.",
			c440Name: "Generous Pension",
			c440Text: "Triggers when you activate your Warren. Relic: Add 1 Supply to one of your Rabbit Villagers.",
			c441Name: "Mailbag",
			c441Text: "Triggers once per Draw effect. Relic: Draw 3.",
			c442Name: "Second-Hand Sword",
			c442Text: "Triggers when you play Gear. Relic: Consider 3; you may reveal and Draw a Gear.",
			c443Name: "Campsite",
			c443Text: "When you play a Crow card, Invest 1. Enchant: Consider 1; you may play a Frog or Rabbit card, discounted by the Supplies here.",
			c444Name: "The Excellent Prismatic Wand",
			c444Text: "Triggers when you return Home. Relic: You may reveal and Tuck a Frog Villager from your hand.",
			c445Name: "Post Office",
			c445Text: "When you play a Building, Invest 2. Enchant: Invest X and Draw X, where X is your Buildings in play. Drawing is not reduced by investing less.",
			c446Name: "Crowbar",
			c446Text: "Triggers when you open any Chest. Relic: Open an Iron Chest.",
			c447Name: "Portal Scroll",
			c447Text: "Triggers when you Adventure. Relic: You may move directly to the Lilypad on the Wilds path without claiming its reward.",
			c448Name: "Sleeping Bag",
			c448Text: "Triggers when you activate your Nest. Relic: Add 1 Supply to one of your Crow Villagers.",
			c500Name: "Dave",
			c500Text: "Adventure 2.",
			c501Name: "Hardworking Arborist",
			c501Text: "Draw 2. You may remove 1 Supply from this card to activate your Lilypad.",
			c502Name: "Community Centre",
			c502Text: "When you play a Rabbit card, Invest 1. Enchant: Activate one of your Villagers costing no more than the Supplies here.",
			c503Name: "Telegraph Office",
			c503Text: "When your Nest Draws cards, you may immediately reveal and play them, paying their cost. Enchant: Gain 4, then activate your Nest.",
			c504Name: "Scrying Bracelet",
			c504Text: "Triggers when you Consider. Relic: Consider 1; Tuck 1.",
			c505Name: "Spawn Point",
			c505Text: "Triggers when you play a Frog card. Relic: Gain 3.",
			c506Name: "Stock Market",
			c506Text: "When you play a card costing more than the Supplies here, Invest 1. Enchant: Gain twice its Supplies.",
			c507Name: "Fishing Rod",
			c507Text: "Triggers when you Trash one or more cards. Relic: Draw any card from the Trash pile.",
			c508Name: "Sorting Room",
			c508Text: "Increase all your Consider values by 1. Enchant: Open an Iron Chest.",
			c509Name: "Observatory",
			c509Text: "When you Tuck X cards from outside play, Invest X. While Enchanted, you may also pay X coins to Draw X.",
			c510Name: "Dowsing Roddie",
			c510Text: "Consider 3, then Adventure 1.",
			c511Name: "Bin Raker",
			c511Text: "Trash a card from your hand, then Tuck another card from your hand.",
			c512Name: "Poorly Pete",
			c512Text: "Free Action: Consider 1; you may Trash 1.",
			c513Name: "Postmaster Crownelius",
			c513Text: "Free Action: Pay 1 coin to Draw 1.",
			c514Name: "Escrow Courier",
			c514Text: "Consider 3: Draw 1; you may play 1, paying its cost. Trash the rest.",
			c515Name: "Litter Picker",
			c515Text: "Play the top card of the Trash pile, paying its cost.",
			c516Name: "Auld Blether",
			c516Text: "Consider X and Draw 1, where X is your Villagers in play.",
			c517Name: "Heart of the Community",
			c517Text: "Gain coins equal to both players' Villagers in play.",
			c518Name: "Paperboy",
			c518Text: "Draw 1, then Gain 2.",
			c519Name: "Introvert Adventurer",
			c519Text: "Adventure 5; choose the Tuck-from-hand option for Chests. Then return Home.",
			c520Name: "The Mighty Joe",
			c520Text: "Adventure 3.",
			c521Name: "Detecting Roddie",
			c521Text: "Consider 1; Tuck 1.",
			c522Name: "Joe's Father",
			c522Text: "Free Action: Adventure 1.",
			c523Name: "Billy Bigspend",
			c523Text: "Pay 10 coins to open a Ruby Chest.",
			c524Name: "Official Merchandise",
			c524Text: "Triggers when you play a Rabbit card. Relic: Gain 3.",
			c525Name: "Void Jewel",
			c525Text: "Triggers when you Trash one or more cards. Relic: You may play the top card of the Trash pile, paying its cost.",
			c526Name: "Rebate Coupon",
			c526Text: "Triggers when you Invest. Relic: Gain 4.",
			c527Name: "Neat NEET",
			c527Text: "Adventure 2. If you activated a Starter this turn, Draw 1; otherwise Gain 1.",
			c528Name: "Doomsayer",
			c528Text: "Trash the top card of the deck. Adventure X, where X is the distinct Species among the top 3 Trash cards.",
			c529Name: "Substitute Teacher",
			c529Text: "Free Action: Activate one of your Villagers costing no more than your hand size.",
			c530Name: "Immigration Office",
			c530Text: "When you play a Rabbit card, Invest 1. Enchant: Consider 1; you may play a Frog or Crow card, discounted by the Supplies here.",
			c531Name: "Fighter's Inn",
			c531Text: "When you return Home, Invest 1. While Enchanted, you may Invest 2 instead.",
			c532Name: "Ouroboros Tome",
			c532Text: "Triggers after you spend at least 1 coin and have none left. Relic: Draw 2.",
			c533Name: "Party Hat",
			c533Text: "Triggers when you play a Villager. Relic: Gain coins equal to both players' Villagers in play.",
			c534Name: "Sightseer",
			c534Text: "Adventure 1, then Adventure 1 again.",
			c535Name: "Mr. Crow",
			c535Text: "You may reveal a Villager from your hand and resolve its effects, then Tuck it. If it is a Free Action, so is this card.",
			c536Name: "Hall of Legends",
			c536Text: "When you play a Crow card, Invest 1. Enchant: Activate one of your Villagers costing no more than its Supplies.",
			c537Name: "Diviner",
			c537Text: "Free Action: Consider 3.",
			c538Name: "Croak Soak",
			c538Text: "When you play a Frog card, Invest 1. Enchant: Consider 1; you may play a Crow or Rabbit card, discounted by the Supplies here.",
			c539Name: "Societal Leech",
			c539Text: "Gain 4. Trash a card from your hand or the top of the deck. If it is Rabbit, activate your Warren.",
			c540Name: "Wizard Hat",
			c540Text: "Triggers when you Consider. Relic: Draw 3, then Trash 3 cards from your hand.",
			c541Name: "Frog Finder",
			c541Text: "Pay the cost of the top Trash card to Tuck it.",
			c542Name: "Spear of the Heavens",
			c542Text: "Triggers when you return Home. Relic: You may reveal and Tuck a Rabbit Villager from your hand.",
			c543Name: "Quarry",
			c543Text: "When you play a Building, Gain 2 and Draw 1. Enchant: Invest X and Adventure X, where X is your Buildings in play.",
			c544Name: "Adventure Juice",
			c544Text: "Triggers when you Adventure. Relic: Draw 2.",
			c545Name: "Zero Waste",
			c545Text: "After you Trash Gear, you may play one of them, paying its cost. While Enchanted, you may then Invest 1.",
			c546Name: "One-eyed Jack",
			c546Text: "Gain 1, Draw 1, then Adventure 1.",
			c547Name: "Shell Game Trickster",
			c547Text: "Consider 3 from the Trash pile: Tuck 1, Draw 1, and return the rest to the main deck in any order.",
			c548Name: "Equal Opportunity Misanthrope",
			c548Text: "Free Action: Trash the top card of the deck, then activate the Starter matching its Species.",
			c600Name: "Honour Student",
			c600Text: "Adventure 1. If this card has no Supplies, open an Iron Chest.",
			c800Name: "Initiate Trader",
			c800Text: "Gain 4.",
			c900Name: "Initiate Hero",
			c900Text: "Adventure 2.",
			c3800Name: "Initiate Postie",
			c3800Text: "Draw 2."
		}
	}
};
//#endregion
export { Ft as default };
