import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { IconClose as l, IconInfo as u, IconRecenter as d, IconRotate as f } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as p } from "@bgparty/sdk/player-colors";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { SheetFxProbe as v, SheetView as y } from "@bgparty/sdk/sheet-view";
import { FlySprite as b, PulseBox as x } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as te, OptionSection as ne, OptionSwitch as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/saboteur20/data.ts
var C = {
	11: [[0, 2]],
	12: [[0, 2]],
	13: [[0, 2]],
	14: [[
		0,
		1,
		2,
		3
	]],
	15: [[
		0,
		1,
		2,
		3
	]],
	16: [[
		0,
		1,
		2,
		3
	]],
	17: [[
		0,
		1,
		2,
		3
	]],
	18: [[
		0,
		1,
		2,
		3
	]],
	19: [[3]],
	20: [[1, 3]],
	21: [[1, 3]],
	22: [[
		0,
		1,
		2
	]],
	23: [[
		0,
		2,
		3
	]],
	24: [[
		0,
		2,
		3
	]],
	25: [[1], [3]],
	26: [[
		0,
		1,
		2
	]],
	27: [[
		0,
		1,
		2
	]],
	28: [
		[0],
		[1],
		[2],
		[3]
	],
	29: [
		[0],
		[1],
		[3]
	],
	30: [[2]],
	31: [[
		0,
		1,
		3
	]],
	32: [[
		0,
		1,
		3
	]],
	33: [[
		0,
		1,
		3
	]],
	34: [[
		1,
		2,
		3
	]],
	35: [[
		0,
		1,
		3
	]],
	36: [[0], [2]],
	37: [
		[0],
		[2],
		[3]
	],
	38: [[1], [2]],
	39: [[2], [3]],
	40: [[0, 1]],
	41: [[0, 1]],
	42: [[2, 3]],
	43: [[1, 2]],
	44: [[0, 1]],
	45: [[2, 3]],
	46: [[0, 3]],
	47: [[1, 2]]
}, w = {
	8: [[0, 2], [1, 3]],
	9: [[0, 1], [2]],
	10: [[0, 1], [2, 3]],
	11: [[0, 3], [1, 2]],
	12: [
		[0],
		[1, 3],
		[2]
	],
	13: [[1, 2]],
	14: [[1, 3]],
	15: [[0, 2]],
	16: [[2, 3]],
	17: [[
		0,
		1,
		2,
		3
	]],
	18: [[1, 3]],
	19: [[1, 3], [2]],
	20: [[0, 2]],
	21: [[0, 3]],
	22: [[0, 2]],
	23: [[
		0,
		2,
		3
	]],
	24: [[3]],
	25: [[
		1,
		2,
		3
	]],
	26: [[0, 2], [1]],
	27: [
		[0, 2],
		[1],
		[3]
	],
	28: [[1, 2]],
	29: [[
		0,
		1,
		2
	]],
	30: [[3]],
	31: [[2]],
	32: [[0, 1]],
	33: [[0], [1, 2]]
}, T = [];
function E(e, t, n, r, i = {}) {
	for (let a = 0; a < t; a++) T.push({
		id: T.length,
		kind: e,
		groups: [],
		tools: [],
		set: n,
		crystal: 0,
		source: r,
		...i
	});
}
for (let [e, t] of [
	"cart",
	"lamp",
	"pick"
].map((e, t) => [e, t])) E("break", 3, "base", `125:${t}`, { tools: [e] }), E("repair", 2, "base", `125:${t + 3}`, { tools: [e] });
E("repair", 1, "base", "125:6", { tools: ["cart", "lamp"] }), E("repair", 1, "base", "125:7", { tools: ["lamp", "pick"] }), E("repair", 1, "base", "125:8", { tools: ["cart", "pick"] }), E("rockfall", 3, "base", "125:9"), E("map", 6, "base", "125:10");
for (let [e, t] of Object.entries(C)) E("path", [
	12,
	20,
	46
].includes(Number(e)) ? 2 : 1, "base", `125:${e}`, { groups: t });
for (let [e, t] of [
	["rockfall", 1],
	["trap", 3],
	["handsOff", 3],
	["freedom", 4],
	["theft", 4],
	["inspect", 2],
	["hats", 2],
	["hands", 2]
]) E(e, t, "expansion", `126:${e}`);
for (let [e, t] of Object.entries(w)) {
	let n = Number(e);
	E("path", n === 8 || n === 13 ? 2 : n === 25 ? 3 : 1, "expansion", `126:${n}`, {
		groups: t,
		crystal: +!![
			17,
			19,
			23,
			25,
			29,
			30,
			31,
			33
		].includes(n),
		...[
			14,
			15,
			16
		].includes(n) ? { door: "blue" } : {},
		...[
			18,
			20,
			28
		].includes(n) ? { door: "green" } : {},
		...[
			21,
			22,
			24,
			32
		].includes(n) ? { ladder: !0 } : {}
	});
}
for (let e of [
	"goals",
	"trove",
	"veto",
	"reverse",
	"master",
	"pathfinder",
	"diversion"
]) E(e, 1, "special", `2017-2023:${e}`);
var D = [
	{
		kind: "gold",
		groups: [[
			1,
			2,
			3
		]],
		gold: 0
	},
	{
		kind: "rock",
		groups: [[0], [2, 3]],
		gold: 0
	},
	{
		kind: "rock",
		groups: [[0], [1, 2]],
		gold: 0
	},
	{
		kind: "spider",
		groups: [[3]],
		gold: 0
	},
	{
		kind: "sack",
		groups: [[1, 2]],
		gold: 2
	},
	{
		kind: "sack",
		groups: [[1, 2]],
		gold: 1
	},
	{
		kind: "dragon",
		groups: [[2]],
		gold: -1
	},
	{
		kind: "sack",
		groups: [[2, 3]],
		gold: 2
	}
], re = [
	[[2]],
	[[2]],
	[[1, 2]],
	[[2, 3]],
	[[0, 3]],
	[[
		0,
		1,
		2,
		3
	]],
	[[
		0,
		1,
		3
	]]
], ie = [
	"stealCard",
	"extra",
	"gold",
	"skip",
	"burn",
	"inspect",
	"discard",
	"noMap",
	"draw",
	"moveGoal"
], O = [
	[0, -1],
	[1, 0],
	[0, 1],
	[-1, 0]
];
function k(e, t) {
	return e.map((e) => e.map((e) => (e + (t ? 2 : 0)) % 4));
}
var A = (e) => T[e], j = t.object({
	mode: t.enum([
		"base",
		"expansion",
		"tournament"
	]).default("base"),
	specials: t.boolean().default(!1),
	greedy: t.boolean().default(!1),
	toll: t.boolean().default(!1),
	postcard: t.enum([
		"none",
		"costume",
		"party"
	]).default("none"),
	newGoals: t.boolean().default(!1),
	chests: t.boolean().default(!1),
	sabotaged: t.boolean().default(!1)
}).prefault({}), M = t.object({
	type: t.enum([
		"place",
		"act",
		"discard",
		"escape",
		"toll",
		"choose",
		"react",
		"next",
		"tick"
	]),
	card: t.int().nonnegative().optional(),
	cards: t.array(t.int().nonnegative()).max(3).optional(),
	x: t.int().optional(),
	y: t.int().optional(),
	flip: t.boolean().optional(),
	target: t.string().optional(),
	tool: t.enum([
		"cart",
		"lamp",
		"pick",
		"trap",
		"theft"
	]).optional(),
	index: t.int().optional(),
	goal: t.int().optional(),
	goal2: t.int().optional(),
	yes: t.boolean().optional(),
	tile: t.string().optional(),
	payer: t.string().optional(),
	now: t.number().optional()
}), N = t.object({
	key: t.string(),
	x: t.int(),
	y: t.int(),
	card: t.int(),
	flip: t.boolean(),
	kind: t.enum([
		"path",
		"start",
		"goal",
		"chest",
		"postcard"
	]),
	groups: t.array(t.array(t.int())),
	revealed: t.boolean(),
	goal: t.int().nullable(),
	chest: t.string().nullable(),
	crystal: t.int(),
	door: t.enum(["blue", "green"]).nullable(),
	ladder: t.boolean(),
	triggered: t.boolean()
}), ae = t.enum([
	"miner",
	"saboteur",
	"blue",
	"green",
	"boss",
	"profiteer",
	"geologist",
	"greedy"
]), oe = t.object({
	config: j,
	round: t.int(),
	phase: t.enum([
		"play",
		"react",
		"resolve",
		"reveal",
		"choice",
		"reward",
		"round",
		"done"
	]),
	turn: t.string(),
	direction: t.int(),
	tiles: t.array(N),
	players: t.array(t.object({
		rid: t.string(),
		hand: t.int(),
		broken: t.array(t.enum([
			"cart",
			"lamp",
			"pick"
		])),
		trap: t.boolean(),
		theft: t.boolean(),
		role: ae.nullable(),
		gold: t.int().nullable()
	})),
	deckCount: t.int(),
	discardCount: t.int(),
	reactions: t.array(t.string()),
	pending: t.object({
		by: t.string(),
		card: t.int(),
		action: M
	}).nullable(),
	choice: t.object({
		kind: t.string(),
		rid: t.string()
	}).nullable(),
	chain: t.int(),
	noMap: t.boolean(),
	lastPath: t.string().nullable(),
	tolls: t.array(t.object({
		id: t.int(),
		x: t.int(),
		y: t.int(),
		owner: t.string(),
		used: t.boolean()
	})),
	history: t.array(t.object({
		round: t.int(),
		roles: t.record(t.string(), ae),
		gains: t.record(t.string(), t.int()),
		reason: t.string()
	})),
	event: t.object({
		seq: t.int(),
		kind: t.string(),
		by: t.string(),
		card: t.int().nullable(),
		tile: t.string().nullable(),
		target: t.string().nullable()
	})
}), P = t.object({
	hand: t.array(t.int()),
	role: ae,
	gold: t.int(),
	known: t.record(t.string(), t.string()),
	legal: t.array(M),
	choices: t.array(t.int()),
	reward: t.array(t.int())
}), F = {
	id: "saboteur20",
	tier: "alpha",
	nameKey: "games.saboteur20.name",
	descKey: "games.saboteur20.desc",
	rulesKey: "games.saboteur20.rules",
	icon: "⛏️",
	iconImg: "games/saboteur20.webp",
	mechanics: [
		"hand-management",
		"tile-placement",
		"route-building",
		"deduction"
	],
	interactionTags: ["hidden-roles", "team-based"],
	minPlayers: 3,
	maxPlayers: 10,
	playerRange: (e) => {
		let t = j.parse(e);
		return t.mode === "expansion" ? {
			min: 2,
			max: 12
		} : t.mode === "tournament" ? {
			min: 5,
			max: 9
		} : {
			min: 3,
			max: 10
		};
	},
	accent: "#9b682f",
	releasedAt: "2026-11-10T02:46:00+08:00",
	search: {
		py: "ai ren jue jin er shi zhou nian ji nian ban",
		init: "arjjesznjnb"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/2461858042253371136/3B74E9F721385AD398C2F557A7F479CBD103519A/" }
}, I = {
	reveal: 800,
	place: 650,
	action: 600
}, L = (e, t) => `${e},${t}`, se = (e, t, n) => e.tiles.find((e) => e.x === t && e.y === n), ce = (e) => e.groups.flat();
function R(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function z(e, t, n = e.turn, r = null, i = null, a = null) {
	e.event = {
		seq: e.event.seq + 1,
		kind: t,
		by: n,
		card: r,
		tile: i,
		target: a
	};
	let o = e.tiles.find((e) => e.key === i);
	e.effects.push({
		kind: "event",
		rid: n,
		data: {
			kind: t,
			card: r,
			tile: i,
			target: a,
			flip: o?.flip ?? !1,
			...(t === "reveal" || t === "moveGoal") && o ? { face: o.revealed ? {
				...o,
				chest: null
			} : {
				...o,
				card: -1,
				groups: [],
				goal: null,
				chest: null
			} } : {}
		}
	});
}
function B(e, t = "flow", n = null) {
	e.resolution = {
		kind: t,
		tile: n
	}, e.phase = "resolve";
}
function le(e, t, n) {
	return e.players[(e.players.indexOf(t) + n + e.players.length) % e.players.length];
}
function V(e, t, n, r = []) {
	return {
		key: L(e, t),
		x: e,
		y: t,
		kind: n,
		groups: r,
		card: -1,
		flip: !1,
		revealed: !0,
		goal: null,
		chest: null,
		crystal: 0,
		door: null,
		ladder: !1,
		triggered: !1
	};
}
function H(e, t, n, r = !1) {
	let i = A(e);
	return {
		...V(t, n, "path", k(i.groups, r)),
		card: e,
		flip: r,
		crystal: i.crystal,
		door: i.door ?? null,
		ladder: i.ladder ?? !1
	};
}
function ue(e, t) {
	let n = /* @__PURE__ */ new Set(), r = [], i = new Map(e.map((e) => [L(e.x, e.y), e])), a = (e) => t && e.door && e.door !== t, o = (e, t) => {
		let i = `${e.key}/${t}`;
		!n.has(i) && !a(e) && (n.add(i), r.push(i));
	};
	for (let t of e) (t.kind === "start" || t.ladder) && t.groups.forEach((e, n) => o(t, n));
	for (let e = 0; e < r.length; e++) {
		let [t, n] = r[e].split("/"), a = i.get(t), s = Number(n);
		for (let e of a.groups[s]) {
			let [t, n] = O[e], r = i.get(L(a.x + t, a.y + n));
			if (!r?.revealed) continue;
			let s = r.groups.findIndex((t) => t.includes((e + 2) % 4));
			s >= 0 && o(r, s);
		}
	}
	return n;
}
function de(e, t, n = ue(t)) {
	return O.some(([r, i], a) => {
		let o = t.find((t) => t.x === e.x + r && t.y === e.y + i);
		return o?.revealed && o.groups.some((e, t) => e.includes((a + 2) % 4) && n.has(`${o.key}/${t}`));
	});
}
function fe(e, t) {
	let n = !1;
	for (let r = 0; r < 4; r++) {
		let [i, a] = O[r], o = t.find((t) => t.x === e.x + i && t.y === e.y + a);
		if (o && (n = !0, e.ladder && o.kind === "goal" || o.revealed && ce(e).includes(r) !== ce(o).includes((r + 2) % 4))) return !1;
	}
	if (!n) return !1;
	if (e.ladder) return !0;
	let r = ue([...t, e]);
	return e.groups.some((t, n) => r.has(`${e.key}/${n}`));
}
function pe(e) {
	let t = /* @__PURE__ */ new Map(), n = new Set(e.map((e) => L(e.x, e.y)));
	for (let r of e) for (let [e, i] of O) {
		let a = r.x + e, o = r.y + i, s = L(a, o);
		n.has(s) || t.set(s, {
			x: a,
			y: o
		});
	}
	return [...t.values()];
}
function U(e, t) {
	if (e.mode === "expansion") return [
		...[
			,
			,
			,
			,
		].fill("blue"),
		...[
			,
			,
			,
			,
		].fill("green"),
		...[
			,
			,
			,
		].fill("saboteur"),
		"boss",
		"profiteer",
		"geologist",
		"geologist"
	];
	if (e.mode === "tournament") {
		let [e, n, r] = {
			5: [
				1,
				3,
				1
			],
			6: [
				2,
				3,
				1
			],
			7: [
				2,
				3,
				2
			],
			8: [
				3,
				3,
				2
			],
			9: [
				3,
				4,
				2
			]
		}[t];
		return [
			...Array(e).fill("saboteur"),
			...Array(n).fill("miner"),
			...Array(r).fill("greedy")
		];
	}
	let [n, r] = {
		3: [1, 3],
		4: [1, 4],
		5: [2, 4],
		6: [2, 5],
		7: [3, 5],
		8: [3, 6],
		9: [3, 7],
		10: [4, 7]
	}[t], i = [...Array(n).fill("saboteur"), ...Array(r).fill("miner")];
	return e.greedy && (i[i.length - 1] = "greedy"), i;
}
function W(e, t, n) {
	let r = e.deck.splice(0, Math.max(0, n));
	e.people[t].hand.push(...r), r.length && e.effects.push({
		kind: "draw",
		rid: t,
		data: { count: r.length },
		for: [t],
		secret: { cards: r }
	});
}
function G(e, t, n) {
	let r = e.people[t].gold;
	e.people[t].gold = Math.max(0, r + n), r !== e.people[t].gold && e.effects.push({
		kind: "gold",
		rid: t,
		data: {}
	});
}
function me(e, t) {
	let n = (t, r) => {
		if (r === 0) return [];
		for (let i = t; i < e.length; i++) {
			if (e[i] > r) continue;
			let t = n(i + 1, r - e[i]);
			if (t) return [i, ...t];
		}
		return null;
	};
	return n(0, t);
}
function he(e, t, n) {
	let r = me(e.goldDeck, n);
	for (; !r;) {
		let t = !1;
		for (let n = 0; n < e.goldDeck.length && !t; n++) for (let r of Object.values(e.goldCards)) {
			let i = me(r.map((t) => t < e.goldDeck[n] ? t : e.goldDeck[n] + 1), e.goldDeck[n]);
			if (!i || i.length < 2) continue;
			let a = i.map((e) => r[e]), o = e.goldDeck[n];
			for (let e of [...i].reverse()) r.splice(e, 1);
			r.push(o), e.goldDeck.splice(n, 1, ...a), t = !0;
			break;
		}
		if (!t) throw Error("Insufficient gold denominations");
		r = me(e.goldDeck, n);
	}
	let i = r.map((t) => e.goldDeck[t]);
	for (let t of [...r].reverse()) e.goldDeck.splice(t, 1);
	(e.goldCards[t] ??= []).push(...i), G(e, t, n);
}
function ge(t) {
	let n = t.config, r = t.players.length, i = R(t, U(n, r));
	t.unused = i.slice(r), t.tiles = [{
		...V(0, 0, "start", [[
			0,
			1,
			2,
			3
		]]),
		ladder: !0
	}];
	let a = n.newGoals ? R(t, [0, ...R(t, [
		1,
		2,
		3,
		4,
		5,
		6,
		7
	]).slice(0, 4)]) : R(t, [
		0,
		1,
		2
	]), o = n.newGoals ? [
		[8, -2],
		[10, -1],
		[8, 0],
		[10, 1],
		[8, 2]
	] : [
		[8, -2],
		[8, 0],
		[8, 2]
	];
	if (a.forEach((e, n) => t.tiles.push({
		...V(o[n][0], o[n][1], "goal"),
		goal: e,
		revealed: !1
	})), n.postcard === "costume" ? t.tiles.push(V(5, 0, "postcard", [[1, 3]]), V(6, 0, "postcard", [[0, 3]])) : n.postcard === "party" && t.tiles.push(V(4, 2, "postcard", [[0, 1]]), V(5, 2, "postcard", [[1, 3]])), n.chests) {
		let e = R(t, [
			0,
			1,
			2,
			3,
			4,
			5,
			6
		]), n = R(t, ie);
		[
			[2, -1],
			[4, 1],
			[6, -1],
			[6, 2]
		].forEach(([r, i], a) => t.tiles.push({
			...V(r, i, "chest"),
			card: -100 - e[a],
			chest: n[a],
			revealed: !1
		}));
	}
	if (t.deck = R(t, T.filter((e) => e.set === "base" || e.set === "expansion" && n.mode === "expansion" || e.set === "special" && n.specials).map((e) => e.id)), n.mode === "expansion" && t.deck.splice(0, 10), n.mode === "tournament") {
		let n = t.deck.filter((e) => A(e).kind === "path"), r = n[e(t.seed, t.cursor++, n.length)];
		t.deck.splice(t.deck.indexOf(r), 1), t.tiles.push(H(r, 4, 0));
	}
	t.baseline = Object.fromEntries(t.players.map((e) => [e, t.people[e].gold]));
	for (let [e, a] of t.players.entries()) t.people[a] = {
		...t.people[a],
		hand: [],
		role: i[e],
		broken: {},
		trap: null,
		theft: null,
		theftOrder: 0,
		known: {}
	}, W(t, a, n.mode === "expansion" || r <= 5 ? 6 : r <= 7 ? 5 : 4);
	t.phase = "play", t.discard = [], t.pending = null, t.choice = null, t.reactions = [], t.flow = null, t.chain = 0, t.noMap = !1, t.lastPath = null, t.tolls = n.toll ? [0, 1].map((e) => ({
		id: e,
		x: 0,
		y: 0,
		owner: "",
		used: !1
	})) : [], t.rewardPool = [], t.rewardQueue = [], t.theftQueue = [], t.reason = "", t.direction = 1, z(t, "round");
}
function _e(e, t, n) {
	let r = j.parse(e), i = t.length, a = r.mode === "expansion" ? [2, 12] : r.mode === "tournament" ? [5, 9] : [3, 10];
	if (i < a[0] || i > a[1]) throw Error("Unsupported player count");
	r.mode !== "base" && (r.greedy = !1, r.sabotaged = !1);
	let o = Object.fromEntries(t.map((e) => [e, {
		hand: [],
		role: "miner",
		gold: +!!r.toll,
		broken: {},
		trap: null,
		theft: null,
		theftOrder: 0,
		known: {}
	}])), s = {
		config: r,
		players: [...t],
		people: o,
		seed: n,
		cursor: 0,
		round: 1,
		phase: "play",
		turn: t[0],
		direction: 1,
		tiles: [],
		deck: [],
		discard: [],
		unused: [],
		goldDeck: [],
		goldCards: {},
		baseline: {},
		pending: null,
		reactions: [],
		choice: null,
		flow: null,
		chain: 0,
		tolls: [],
		noMap: !1,
		lastPath: null,
		serial: 0,
		history: [],
		event: {
			seq: 0,
			kind: "round",
			by: t[0],
			card: null,
			tile: null,
			target: null
		},
		rewardPool: [],
		rewardQueue: [],
		theftQueue: [],
		reason: "",
		lastActor: t[0],
		effects: [],
		resolution: {
			kind: "flow",
			tile: null
		}
	};
	return s.goldDeck = R(s, [
		...Array(16).fill(1),
		...Array(8).fill(2),
		...[
			,
			,
			,
			,
		].fill(3)
	]), ge(s), {
		state: s,
		fx: s.effects
	};
}
function K(e, t, n, r = [], i = {}) {
	e.choice = {
		kind: t,
		rid: n,
		pool: r,
		...i
	}, e.phase = "choice";
}
function ve(e, t, n, r = !0) {
	let i = e.people[t].hand;
	i.splice(i.indexOf(n), 1), r && e.discard.unshift(n);
}
function ye(e, t) {
	for (let n of Object.values(e.people)) delete n.known[`role:${t}`];
}
function be(e, t) {
	if (!e.unused.length) return;
	let n = e.people[t].role;
	e.people[t].role = e.unused.shift(), e.unused.push(n), ye(e, t);
}
function xe(e) {
	let t = ue(e.tiles);
	for (let n of e.tiles.filter((e) => e.kind === "postcard" && !e.triggered)) if (n.groups.some((e, r) => t.has(`${n.key}/${r}`))) {
		for (let t of e.tiles) t.kind === "postcard" && (t.triggered = !0);
		if (e.config.postcard === "costume") be(e, e.turn);
		else {
			let t = R(e, e.players.map((t) => e.people[t].role));
			e.players.forEach((n, r) => {
				e.people[n].role = t[r], ye(e, n);
			});
		}
		return z(e, e.config.postcard, e.turn, null, n.key), B(e), !0;
	}
	return e.tiles.some((n) => (n.kind === "goal" || n.kind === "chest") && !n.revealed && de(n, e.tiles, t)) ? (e.phase = "reveal", !0) : !1;
}
function Se(e) {
	if (e.lastActor = e.turn, e.players.every((t) => !e.people[t].hand.length)) {
		Oe(e, "empty");
		return;
	}
	do
		e.turn = le(e, e.turn, e.direction);
	while (!e.people[e.turn].hand.length);
	e.phase = "play", e.flow = null, e.chain = 0, e.choice = null;
}
function Ce(e) {
	let t = e.flow;
	if (!t) {
		Se(e);
		return;
	}
	if (!xe(e)) {
		if (t.chain > 0) {
			e.chain = t.chain, e.phase = "play";
			return;
		}
		if (t.endDraw === "steal") {
			if (e.players.some((n) => n !== t.by && e.people[n].hand.length)) {
				K(e, "stealCard", t.by);
				return;
			}
		} else if (t.endDraw === "draw") {
			let n = e.deck.splice(0, 3);
			if (n.length) {
				K(e, "drawPick", t.by, n, { source: "deck" });
				return;
			}
		} else W(e, t.drawTo, t.draw);
		Se(e);
	}
}
function we(e, t, n = 1) {
	e.flow ||= {
		by: t,
		draw: n,
		drawTo: t,
		chain: 0,
		endDraw: "normal",
		reward: !1
	};
}
function Te(e, t, n) {
	let r = e.people[t], i = n === "trap" ? r.trap : n === "theft" ? r.theft : r.broken[n];
	i != null && e.discard.unshift(i), n === "trap" ? r.trap = null : n === "theft" ? r.theft = null : delete r.broken[n];
}
function Ee(e) {
	let t = e.players.filter((t) => e.people[t].theft !== null && e.people[t].trap === null), n = t.sort((t, n) => e.people[n].theftOrder - e.people[t].theftOrder)[0];
	e.theftQueue = n ? Array.from({ length: e.players.length }, (t, r) => e.players[(e.players.indexOf(n) + r) % e.players.length]).filter((e) => t.includes(e)) : [], De(e);
}
function De(e) {
	if (e.theftQueue.length) {
		K(e, "theft", e.theftQueue.shift());
		return;
	}
	let t = Object.fromEntries(e.players.map((t) => [t, e.people[t].gold - e.baseline[t]]));
	e.history.push({
		round: e.round,
		roles: Object.fromEntries(e.players.map((t) => [t, e.people[t].role])),
		gains: t,
		reason: e.reason
	}), e.phase = e.round === 3 ? "done" : "round", e.choice = null, e.flow = null, e.chain = 0, z(e, "reward");
}
function Oe(e, t) {
	e.reason = t, e.lastActor = e.turn, e.pending = null, e.choice = null, e.chain = 0, e.flow = null;
	let n = e.config, r = t === "gold", i = e.people[e.turn].role;
	if (n.mode === "expansion") {
		let t = e.tiles.find((e) => e.kind === "goal" && e.goal === 0), n = (n) => t.groups.some((r, i) => ue(e.tiles, n).has(`${t.key}/${i}`)), a = [];
		r && (a = (i === "blue" || i === "green") && n(i) ? [i] : ["blue", "green"].filter(n));
		let o = e.players.filter((t) => e.people[t].trap === null && (e.people[t].role === "profiteer" || (r ? a.includes(e.people[t].role) || e.people[t].role === "boss" : e.people[t].role === "saboteur"))), s = o.length <= 1 ? 5 : o.length === 2 ? 4 : o.length === 3 ? 3 : o.length === 4 ? 2 : 1;
		for (let t of o) G(e, t, Math.max(0, s - (e.people[t].role === "boss" ? 1 : e.people[t].role === "profiteer" ? 2 : 0)));
		let c = e.players.filter((t) => e.people[t].role === "geologist");
		for (let t of c) e.people[t].trap === null && G(e, t, Math.floor(e.tiles.reduce((e, t) => e + t.crystal, 0) / c.length));
		Ee(e);
		return;
	}
	if (r && i === "greedy") {
		n.mode === "base" ? he(e, e.turn, 4) : G(e, e.turn, 4), Ee(e);
		return;
	}
	let a = e.players.filter((t) => e.people[t].role === "miner");
	if (n.mode === "tournament") {
		for (let t of e.players) r && e.people[t].role === "miner" ? G(e, t, t === e.turn ? 3 : 2) : !r && e.people[t].role === "saboteur" && G(e, t, e.players.length === 5 ? 4 : 3);
		Ee(e);
		return;
	}
	if (r) {
		let t = a.filter((t) => !n.sabotaged || !Object.keys(e.people[t].broken).length);
		if (e.rewardPool = e.goldDeck.splice(0, a.length), t.length && e.rewardPool.length) {
			let n = e.turn;
			if (!t.includes(n)) do
				n = le(e, n, -e.direction);
			while (!t.includes(n));
			e.rewardQueue = [];
			for (let r = 0; r < e.rewardPool.length; r++) {
				e.rewardQueue.push(n);
				do
					n = le(e, n, -e.direction);
				while (!t.includes(n));
			}
			e.phase = "reward";
			return;
		}
		e.goldDeck.push(...e.rewardPool), e.rewardPool = [];
	} else {
		let t = e.players.filter((t) => e.people[t].role === "saboteur"), n = t.length;
		for (let r of t) he(e, r, n === 1 ? 4 : n === 4 ? 2 : 3);
	}
	Ee(e);
}
function ke(e, t, n) {
	we(e, n);
	let r = A(t.card);
	if (t.type === "place") {
		let r = H(t.card, t.x, t.y, t.flip);
		e.tiles.push(r), e.lastPath = r.key, z(e, "path", n, t.card, r.key);
		let i = e.tolls.find((e) => e.owner && e.x === t.x && e.y === t.y);
		i && (G(e, t.payer ?? n, -1), G(e, i.owner, 1), i.owner = ""), e.chain > 0 && (e.flow.chain = e.chain - 1, e.chain = 0), B(e);
		return;
	}
	z(e, r.kind, n, t.card, t.tile ?? null, t.target ?? null);
	let i = t.target ? e.people[t.target] : e.people[n];
	switch (r.kind) {
		case "break":
			i.broken[r.tools[0]] = t.card, e.discard.splice(e.discard.indexOf(t.card), 1);
			break;
		case "repair":
		case "master":
			Te(e, t.target, t.tool);
			break;
		case "trap":
			i.trap = t.card, e.discard.splice(e.discard.indexOf(t.card), 1);
			break;
		case "freedom":
			Te(e, t.target, "trap");
			break;
		case "theft":
			i.theft = t.card, i.theftOrder = ++e.serial, e.discard.splice(e.discard.indexOf(t.card), 1);
			break;
		case "handsOff":
			Te(e, t.target, "theft");
			break;
		case "rockfall": {
			let r = e.tiles.find((e) => e.key === t.tile);
			e.effects.push({
				kind: "remove",
				rid: n,
				data: { face: r.revealed ? {
					...r,
					chest: null
				} : {
					...r,
					card: -1,
					groups: [],
					goal: null,
					chest: null
				} }
			}), r.card >= 0 && e.discard.unshift(r.card), e.tiles = e.tiles.filter((n) => n !== e.tiles.find((e) => e.key === t.tile)), e.lastPath === t.tile && (e.lastPath = null);
			for (let n of Object.values(e.people)) delete n.known[t.tile];
			break;
		}
		case "map": {
			let r = e.tiles.find((e) => e.key === t.tile);
			e.people[n].known[r.key] = r.kind === "goal" ? `goal:${r.goal}` : `chest:${-100 - r.card}:${r.chest}`;
			break;
		}
		case "inspect":
			e.people[n].known[`role:${t.target}`] = i.role;
			break;
		case "hats":
			be(e, t.target);
			break;
		case "hands": {
			let r = e.people[n].hand;
			e.people[n].hand = i.hand, i.hand = r, e.flow.drawTo = t.target;
			break;
		}
		case "goals": {
			let n = e.tiles.filter((e) => e.kind === "goal"), r = n[t.goal], i = n[t.goal2];
			if (t.yes) {
				[r.goal, i.goal] = [i.goal, r.goal];
				for (let t of Object.values(e.people)) delete t.known[r.key], delete t.known[i.key];
			}
			break;
		}
		case "trove": {
			let r = e.discard.filter((e) => e !== t.card).slice(0, 5);
			if (r.length) {
				K(e, "trove", n, r, { source: "discard" }), e.flow.draw = 0;
				return;
			}
			e.flow.draw = 0;
			break;
		}
		case "reverse":
			e.direction = -e.direction;
			break;
		case "pathfinder":
			e.flow.chain = 2, e.flow.draw = 2;
			break;
		case "diversion": {
			let r = e.tiles.find((t) => t.key === e.lastPath);
			e.tiles = e.tiles.filter((e) => e !== r);
			let i = H(r.card, t.x, t.y, t.flip);
			e.tiles.push(i), e.lastPath = i.key, z(e, "diversion", n, r.card, i.key, r.key);
			break;
		}
	}
	B(e);
}
function Ae(e, t) {
	let n = e.flow, r = e.turn, i = t.chest;
	if (t.chest = null, z(e, i ?? "reveal", r, null, t.key), i === "gold") e.config.mode === "base" ? he(e, r, 1) : G(e, r, 1);
	else if (i === "extra") n.draw++;
	else if (i === "skip") n.draw = 0;
	else if (i === "burn") e.discard.unshift(...e.deck.splice(0, 5));
	else if (i === "noMap") e.noMap = !0;
	else if (i === "stealCard") n.endDraw = "steal";
	else if (i === "draw") n.endDraw = "draw";
	else if (i === "inspect") {
		K(e, "inspect", r);
		return;
	} else if (i === "moveGoal") {
		if (e.tiles.some((t) => t.kind === "goal" && !t.revealed && !se(e, t.x + 1, t.y))) {
			K(e, "moveGoal", r);
			return;
		}
	} else if (i === "discard") {
		if (e.discard = R(e, e.discard), e.discard.length) {
			n.draw = 0, K(e, "trove", r, e.discard.slice(0, 5), { source: "discard" });
			return;
		}
		n.draw = 0;
	}
	B(e);
}
function je(e, t) {
	t.revealed = !0, t.groups = t.kind === "goal" ? k(D[t.goal].groups, !1) : k(re[-100 - t.card], !1), z(e, "reveal", e.turn, null, t.key), K(e, "orient", e.turn, [], { tile: t.key });
}
function Me(e, t) {
	let n = e.tiles.filter((e) => e !== t), r = t.kind === "goal" ? D[t.goal].groups : re[-100 - t.card], i = (e) => {
		let i = {
			...t,
			groups: k(r, e)
		}, a = 0;
		for (let [e, [r, o]] of O.entries()) {
			let s = n.find((e) => e.x === t.x + r && e.y === t.y + o);
			s?.revealed && ce(s).includes((e + 2) % 4) === ce(i).includes(e) && a++;
		}
		return a;
	}, a = i(!1), o = i(!0);
	return a === o ? [!1, !0] : [!(a > o)];
}
function Ne(t, n, r) {
	let i = t.choice;
	if (t.choice = null, i.kind === "pay") {
		if (!n.yes) {
			t.phase = "play";
			return;
		}
		let e = i.action;
		Le(t, e, t.turn);
		return;
	}
	if (i.kind === "orient") {
		let e = t.tiles.find((e) => e.key === i.tile);
		e.flip = n.flip ?? !1, e.groups = k(e.kind === "goal" ? D[e.goal].groups : re[-100 - e.card], e.flip), B(t, e.kind === "goal" ? "goal" : "chest", e.key);
		return;
	}
	if (i.kind === "trove" || i.kind === "drawPick") {
		let e = i.pool[n.index];
		t.people[r].hand.push(e), t.effects.push({
			kind: "draw",
			rid: r,
			data: {
				count: 1,
				source: i.source ?? "deck"
			},
			for: [r],
			secret: { cards: [e] }
		}), i.source === "discard" ? t.discard.splice(t.discard.indexOf(e), 1) : t.discard.unshift(...i.pool.filter((t) => t !== e)), i.kind === "drawPick" && (t.flow.endDraw = "normal"), t.flow.draw = 0;
	} else if (i.kind === "inspect") t.people[r].known[`role:${n.target}`] = t.people[n.target].role;
	else if (i.kind === "stealCard") {
		let i = t.people[n.target].hand, a = e(t.seed, t.cursor++, i.length);
		t.people[r].hand.push(i.splice(a, 1)[0]), t.flow.endDraw = "normal", t.flow.draw = 0, t.effects.push({
			kind: "draw",
			rid: r,
			data: {
				count: 1,
				source: n.target ?? "deck"
			}
		});
	} else if (i.kind === "moveGoal") {
		let e = t.tiles.find((e) => e.key === n.tile), i = e.key;
		e.x++, e.key = L(e.x, e.y);
		for (let n of Object.values(t.people)) n.known[i] && (n.known[e.key] = n.known[i], delete n.known[i]);
		z(t, "moveGoal", r, null, e.key, i);
	} else if (i.kind === "theft") {
		n.target && t.people[n.target].gold > 0 && (G(t, n.target, -1), G(t, r, 1)), De(t);
		return;
	}
	B(t);
}
function Pe(e, t) {
	return t === 0 ? [[]] : e.flatMap((n, r) => Pe(e.slice(r + 1), t - 1).map((e) => [n, ...e]));
}
function Fe(e, t) {
	let n = e.people[t];
	if (!n || e.phase === "done") return [];
	if (e.phase === "round") return t === e.turn ? [{ type: "next" }] : [];
	if (e.phase === "react") {
		if (!e.reactions.includes(t)) return [];
		let r = n.hand.find((e) => A(e).kind === "veto");
		return [{
			type: "react",
			yes: !1
		}, ...r === void 0 ? [] : [{
			type: "react",
			yes: !0,
			card: r
		}]];
	}
	if (e.phase === "reward") return e.rewardQueue[0] === t ? e.rewardPool.map((e, t) => ({
		type: "choose",
		index: t
	})) : [];
	if (e.phase === "choice") {
		let r = e.choice;
		return r.rid === t ? r.kind === "pay" ? [{
			type: "choose",
			yes: !1
		}, ...n.gold > 0 ? [{
			type: "choose",
			yes: !0
		}] : []] : r.kind === "orient" ? Me(e, e.tiles.find((e) => e.key === r.tile)).map((e) => ({
			type: "choose",
			flip: e
		})) : r.kind === "trove" || r.kind === "drawPick" ? r.pool.map((e, t) => ({
			type: "choose",
			index: t
		})) : r.kind === "moveGoal" ? e.tiles.filter((t) => t.kind === "goal" && !t.revealed && !se(e, t.x + 1, t.y)).map((e) => ({
			type: "choose",
			tile: e.key
		})) : r.kind === "theft" ? [...e.players.filter((e) => e !== t).map((e) => ({
			type: "choose",
			target: e
		})), {
			type: "choose",
			yes: !1
		}] : e.players.filter((n) => n !== t && (r.kind !== "stealCard" || e.people[n].hand.length > 0)).map((e) => ({
			type: "choose",
			target: e
		})) : [];
	}
	if (e.phase === "reveal") {
		if (t !== e.turn) return [];
		let n = ue(e.tiles);
		return e.tiles.filter((t) => !t.revealed && de(t, e.tiles, n)).map((e) => ({
			type: "choose",
			tile: e.key
		}));
	}
	if (e.phase !== "play" || t !== e.turn) return [];
	let r = [], i = pe(e.tiles), a = !Object.keys(n.broken).length && n.trap === null;
	for (let o of n.hand) {
		let s = A(o);
		if (s.kind === "path" && a) {
			for (let { x: a, y: s } of i) for (let i of [!1, !0]) if (fe(H(o, a, s, i), e.tiles)) {
				if (!e.tolls.find((e) => e.owner && e.x === a && e.y === s)) r.push({
					type: "place",
					card: o,
					x: a,
					y: s,
					flip: i
				});
				else {
					n.gold > 0 && r.push({
						type: "place",
						card: o,
						x: a,
						y: s,
						flip: i,
						payer: t
					});
					for (let n of e.players.filter((e) => e !== t)) r.push({
						type: "place",
						card: o,
						x: a,
						y: s,
						flip: i,
						payer: n
					});
				}
			}
		}
		if (e.chain > 0) continue;
		let c = {
			type: "act",
			card: o
		};
		if (s.kind === "break") for (let n of e.players) n !== t && e.people[n].broken[s.tools[0]] === void 0 && r.push({
			...c,
			target: n
		});
		if (s.kind === "repair" || s.kind === "master") for (let t of e.players) for (let n of s.kind === "master" ? [
			"cart",
			"lamp",
			"pick"
		] : s.tools) e.people[t].broken[n] !== void 0 && r.push({
			...c,
			target: t,
			tool: n
		});
		if (s.kind === "rockfall") for (let t of e.tiles) (t.kind === "path" || t.kind === "chest") && r.push({
			...c,
			tile: t.key
		});
		if (s.kind === "map") for (let t of e.tiles) !t.revealed && (t.kind === "chest" || t.kind === "goal" && !e.noMap) && r.push({
			...c,
			tile: t.key
		});
		if (s.kind === "theft" && n.theft === null && r.push({
			...c,
			target: t
		}), s.kind === "trap") for (let n of e.players) n !== t && e.people[n].trap === null && r.push({
			...c,
			target: n
		});
		if (s.kind === "freedom") for (let t of e.players) e.people[t].trap !== null && r.push({
			...c,
			target: t
		});
		if (s.kind === "handsOff") for (let t of e.players) e.people[t].theft !== null && r.push({
			...c,
			target: t
		});
		if (s.kind === "inspect" || s.kind === "hands") for (let n of e.players) n !== t && r.push({
			...c,
			target: n
		});
		if (s.kind === "hats" && e.unused.length) for (let t of e.players) r.push({
			...c,
			target: t
		});
		if (s.kind === "goals") {
			let t = e.tiles.filter((e) => e.kind === "goal");
			for (let e = 0; e < t.length; e++) for (let n = e + 1; n < t.length; n++) if (!t[e].revealed && !t[n].revealed) for (let t of [!1, !0]) r.push({
				...c,
				goal: e,
				goal2: n,
				yes: t
			});
		}
		if ((s.kind === "reverse" || s.kind === "trove") && r.push(c), s.kind === "pathfinder" && a && n.hand.filter((e) => A(e).kind === "path").length >= 2 && r.push(c), s.kind === "diversion" && e.lastPath) {
			let t = e.tiles.find((t) => t.key === e.lastPath);
			if (t && t.card >= 0) {
				let n = e.tiles.filter((e) => e !== t);
				for (let { x: i, y: a } of pe(n)) for (let o of [!1, !0]) L(i, a) !== t.key && !e.tolls.some((e) => e.owner && e.x === i && e.y === a) && fe(H(t.card, i, a, o), n) && r.push({
					...c,
					x: i,
					y: a,
					flip: o
				});
			}
		}
	}
	if (e.chain > 0) return r.length || r.push({
		type: "choose",
		yes: !1
	}), r;
	for (let t = 1; t <= (e.config.mode === "expansion" ? 3 : 1); t++) for (let e of Pe(n.hand, t)) r.push({
		type: "discard",
		cards: e
	});
	if (e.config.mode === "expansion") for (let e of Pe(n.hand, 2)) for (let t of [
		...Object.keys(n.broken),
		...n.trap === null ? [] : ["trap"],
		...n.theft === null ? [] : ["theft"]
	]) r.push({
		type: "escape",
		cards: e,
		tool: t
	});
	if (e.tolls.some((e) => !e.used)) for (let t of n.hand) for (let { x: n, y: a } of i) !e.tolls.some((e) => e.owner && e.x === n && e.y === a) && e.tiles.some((e) => O.some(([t, r], i) => e.x + t === n && e.y + r === a && ce(e).includes(i))) && r.push({
		type: "toll",
		card: t,
		x: n,
		y: a
	});
	return r;
}
function Ie(e, t) {
	let n = (e) => Object.fromEntries(Object.entries(e).filter(([e, t]) => e !== "now" && t !== void 0).sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => [e, e === "cards" ? [...t].sort((e, t) => e - t) : t]));
	return JSON.stringify(n(e)) === JSON.stringify(n(t));
}
function Le(e, t, n) {
	ve(e, n, t.card, t.type !== "place"), e.pending = {
		by: n,
		card: t.card,
		action: t
	}, e.config.specials ? (e.phase = "react", e.reactions = e.players.filter((e) => e !== n)) : (e.pending = null, ke(e, t, n));
}
function Re(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine") return { code: "games.saboteur20.errAction" };
		if (e.phase !== "resolve") return { state: e };
		let t = structuredClone(e);
		if (t.effects = [], t.resolution.kind === "flow") Ce(t);
		else {
			let e = t.tiles.find((e) => e.key === t.resolution.tile);
			if (t.resolution.kind === "chest") Ae(t, e);
			else {
				let n = D[e.goal];
				n.kind === "gold" || n.kind === "spider" ? Oe(t, n.kind) : (G(t, t.turn, n.gold), z(t, n.kind, t.turn, null, e.key), B(t));
			}
		}
		return {
			state: t,
			fx: t.effects
		};
	}
	if (!Fe(e, n.by).some((e) => Ie(t, e))) return { code: "games.saboteur20.errAction" };
	let r = structuredClone(e), i = n.by;
	if (r.effects = [], r.phase === "round") return r.round++, r.turn = le(r, r.lastActor, 1), ge(r), {
		state: r,
		fx: r.effects
	};
	if (r.phase === "reward") {
		let e = r.rewardPool.splice(t.index, 1)[0];
		return (r.goldCards[i] ??= []).push(e), G(r, i, e), r.rewardQueue.shift(), r.rewardQueue.length || Ee(r), {
			state: r,
			fx: r.effects
		};
	}
	if (r.phase === "react") {
		if (t.yes) {
			let e = r.pending;
			ve(r, i, t.card), r.discard.includes(e.card) || r.discard.unshift(e.card), W(r, e.by, 1), W(r, i, 1), r.pending = null, r.reactions = [], r.chain = 0, r.flow = null, z(r, "veto", i, t.card, null, e.by), Se(r);
		} else if (r.reactions = r.reactions.filter((e) => e !== i), !r.reactions.length) {
			let e = r.pending;
			r.pending = null, ke(r, e.action, e.by);
		}
		return {
			state: r,
			fx: r.effects
		};
	}
	if (r.phase === "choice") return Ne(r, t, i), {
		state: r,
		fx: r.effects
	};
	if (r.phase === "reveal") return je(r, r.tiles.find((e) => e.key === t.tile)), {
		state: r,
		fx: r.effects
	};
	if (t.type === "choose") return r.chain = 0, r.flow.chain = 0, Ce(r), {
		state: r,
		fx: r.effects
	};
	if (t.type === "place" && t.payer && t.payer !== i) return K(r, "pay", t.payer, [], { action: t }), {
		state: r,
		fx: r.effects
	};
	if (t.type === "place" || t.type === "act") return Le(r, t, i), {
		state: r,
		fx: r.effects
	};
	if (we(r, i), t.type === "toll") {
		ve(r, i, t.card);
		let e = r.tolls.find((e) => !e.used);
		Object.assign(e, {
			x: t.x,
			y: t.y,
			owner: i,
			used: !0
		}), r.flow.draw = 0, z(r, "toll", i, null, L(t.x, t.y));
	} else {
		for (let e of t.cards) ve(r, i, e);
		t.type === "escape" && Te(r, i, t.tool), r.flow.draw = t.type === "discard" ? t.cards.length : 1, z(r, t.type, i), r.effects.push({
			kind: "discardCards",
			rid: i,
			data: { count: t.cards.length }
		});
	}
	return Ce(r), {
		state: r,
		fx: r.effects
	};
}
function ze(e, t) {
	let n = [
		"reward",
		"round",
		"done"
	].includes(e.phase) || e.choice?.kind === "theft", r = e.people[t];
	return {
		public: {
			config: e.config,
			round: e.round,
			phase: e.phase,
			turn: e.turn,
			direction: e.direction,
			tiles: e.tiles.map((e) => e.revealed ? e.kind === "chest" ? {
				...e,
				chest: null
			} : e : {
				...e,
				card: -1,
				groups: [],
				goal: null,
				chest: null
			}),
			players: e.players.map((t) => ({
				rid: t,
				hand: e.people[t].hand.length,
				broken: Object.keys(e.people[t].broken),
				trap: e.people[t].trap !== null,
				theft: e.people[t].theft !== null,
				role: n ? e.people[t].role : null,
				gold: e.phase === "done" ? e.people[t].gold : null
			})),
			deckCount: e.deck.length,
			discardCount: e.discard.length,
			reactions: e.reactions,
			pending: e.pending,
			choice: e.choice ? {
				kind: e.choice.kind,
				rid: e.choice.rid
			} : e.phase === "reward" ? {
				kind: "reward",
				rid: e.rewardQueue[0]
			} : null,
			chain: e.chain,
			noMap: e.noMap,
			lastPath: e.lastPath,
			tolls: e.tolls,
			history: e.phase === "done" ? e.history : [],
			event: e.event
		},
		...r ? { private: {
			hand: r.hand,
			role: r.role,
			gold: r.gold,
			known: r.known,
			legal: Fe(e, t),
			choices: e.choice?.rid === t ? e.choice.pool : [],
			reward: e.phase === "reward" && e.rewardQueue[0] === t ? e.rewardPool : []
		} } : {}
	};
}
function Be(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.people[n].gold - e.people[t].gold), n = Object.fromEntries(e.players.map((t) => [t, e.people[t].gold]));
	return {
		phase: e.phase,
		ranking: t,
		winner: t.filter((e) => n[e] === n[t[0]]),
		scores: n
	};
}
var Ve = {
	meta: F,
	saveCompatibility: { version: "1" },
	schemas: {
		action: M,
		publicView: oe,
		privateView: P,
		config: j
	},
	setup: _e,
	reduce: Re,
	viewFor: ze,
	status: Be,
	nextTickIn: (e) => e.phase === "resolve" ? I.action : null
}, He = {
	cave: "<rect x=\"0\" y=\"0\" width=\"300\" height=\"440\" rx=\"0\" fill=\"#a2b2b2\" stroke=\"none\" stroke-width=\"2\"/><path d=\"M55 311 49 152Q44 85 98 55L152 32 221 58Q265 105 251 170L261 327Z\" fill=\"#485259\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M86 302 81 161Q71 115 110 88L157 73 209 95 219 170 229 318Z\" fill=\"#333e44\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 0H100L92 54 58 81 45 144 42 204 17 237 0 219Z\" fill=\"#c3cecb\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 82 31 101 57 82M29 100 24 151 45 163M0 176 24 183 17 237M61 2 72 40 92 54M0 24 39 33 56 80\" fill=\"none\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M107 0 101 35 145 39 178 23 218 56 251 54 271 102 300 110V0Z\" fill=\"#b3c2c0\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M118 1 128 18 101 35M177 23 190 3M219 56 229 17M253 55 269 35 300 48M271 103 276 139 300 145\" fill=\"none\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M300 110 269 101 251 150 258 196 244 243 256 307 300 334Z\" fill=\"#879fA5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M269 103 286 119 281 167 258 195M282 168 300 185M244 243 278 239 290 270 300 267M278 239 270 214M256 307 277 287 300 301\" fill=\"none\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 228 30 243 45 286 56 313 95 323 139 308 185 325 229 304 264 311 300 332V440H0Z\" fill=\"#c2c5ba\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 358 43 347 72 350 117 335 152 345 189 329 237 345 300 333M0 416 42 399 101 396 142 376 202 375 242 357 300 367\" fill=\"none\" stroke=\"#798b8c\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M17 286 41 280 62 291 57 306 28 310 10 301Z\" fill=\"#93a6a5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M22 287 28 301 56 303M41 280 43 296\" fill=\"none\" stroke=\"#39464b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M245 352 263 341 281 349 290 371 259 376 243 366Z\" fill=\"#94a7a8\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M264 342 263 359 287 369M245 353 263 359 258 375\" fill=\"none\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	miner: "<path d=\"M174 302 211 300 214 343 199 365 174 352Z\" fill=\"#bc8a44\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M211 305 248 305 253 350 239 370 214 353Z\" fill=\"#dfa846\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M177 351 198 357 195 394 175 398Z\" fill=\"#a84b3c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M216 352 240 359 241 397 220 400Z\" fill=\"#ad503d\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M177 369 194 373M176 380 194 384M219 373 240 379M221 385 241 390\" fill=\"none\" stroke=\"#e2ad70\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M175 390Q189 394 196 389L202 407 194 417 164 416Q158 406 168 399Z\" fill=\"#746044\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M220 392Q231 399 241 392L247 406 269 414Q275 426 261 428L222 426 216 417Z\" fill=\"#665841\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M163 414 194 415M222 422 267 423\" fill=\"none\" stroke=\"#b49a68\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><rect x=\"176\" y=\"400\" width=\"13\" height=\"9\" rx=\"1\" fill=\"#c5ad73\" stroke=\"#423e32\" stroke-width=\"1.6\"/><rect x=\"229\" y=\"405\" width=\"12\" height=\"9\" rx=\"1\" fill=\"#c5ad73\" stroke=\"#423e32\" stroke-width=\"1.6\"/><path d=\"M168 214Q151 211 122 226L92 246 72 262 86 279 110 267 139 254 177 251Z\" fill=\"#526582\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M148 223 128 242 101 254M110 267 96 258\" fill=\"none\" stroke=\"#8092ac\" stroke-width=\"2.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M71 260Q61 257 56 265L51 277Q52 284 59 282L65 274 66 285Q71 289 77 283L85 273 83 266Z\" fill=\"#e9b887\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M61 267 57 278M69 270 65 281M75 272 70 281\" fill=\"none\" stroke=\"#9a684f\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M170 209Q192 199 218 212L245 222Q271 239 276 270L268 311 246 333 207 329 178 315 164 284 158 247Z\" fill=\"#576c95\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M239 225Q260 243 260 270L246 301 216 311 208 328 246 333 268 311 276 270Q270 238 245 222Z\" fill=\"#405478\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M176 219 181 243 195 255M251 286 232 301 212 302M261 300 249 315 224 321M172 296 190 306\" fill=\"none\" stroke=\"#8c9fb9\" stroke-width=\"2.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M188 211 202 219 215 213 215 234 200 248 183 233Z\" fill=\"#e5d6ad\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"214\" cy=\"268\" rx=\"3.1\" ry=\"3.6\" fill=\"#baa266\" stroke=\"#39464b\" stroke-width=\"1.2\"/><ellipse cx=\"217\" cy=\"287\" rx=\"3.1\" ry=\"3.6\" fill=\"#baa266\" stroke=\"#39464b\" stroke-width=\"1.2\"/><path d=\"M169 151Q156 151 160 167L170 175 178 162Z\" fill=\"#dda77c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M223 151Q236 144 235 158L225 171 218 163Z\" fill=\"#dda77c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M169 139Q167 124 194 126L219 137 228 166 221 186 229 193 216 193 220 205 206 201 198 224 184 211 169 213 176 196 162 190 166 175 156 173 165 160Z\" fill=\"#f5ecd6\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M177 142Q190 133 208 139L221 153 218 176 207 191 188 188 175 173 171 156Z\" fill=\"#ebba86\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M213 148 217 164 208 176 202 188 211 185 220 174 223 154Z\" fill=\"#cd9169\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M175 168Q181 178 193 176L203 181 215 173 218 182 213 199 205 214 197 234 187 222 177 219 178 203 170 198 174 186 168 178Z\" fill=\"#fff1d5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M176 185 182 195 182 209M190 199 190 217M205 198 198 218M211 182 209 192\" fill=\"none\" stroke=\"#c9b793\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M178 153Q184 147 191 151M201 150Q209 146 214 152\" fill=\"none\" stroke=\"#f9efdb\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M179 157Q184 152 189 157Q185 161 179 159Z\" fill=\"#fff7e7\" stroke=\"#39464b\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M202 156Q207 151 212 155Q208 160 202 159Z\" fill=\"#fff7e7\" stroke=\"#39464b\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"186\" cy=\"156\" rx=\"1.7\" ry=\"2.1\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"208\" cy=\"155\" rx=\"1.7\" ry=\"2.1\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><path d=\"M194 155 190 166Q190 172 201 171L205 167Q200 161 199 156\" fill=\"#efb681\" stroke=\"#966c52\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M181 173Q188 169 193 174M202 174Q209 166 215 170\" fill=\"none\" stroke=\"#fff2d9\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M186 178Q198 185 209 175\" fill=\"none\" stroke=\"#724f40\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M191 180 200 181 199 184 193 183Z\" fill=\"#fff3df\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M164 140Q171 111 189 101L205 77Q211 62 204 52Q198 39 211 30Q209 44 220 50Q233 61 225 78L225 115 230 140Z\" fill=\"#b84e3c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M211 54Q226 66 216 88L215 118 224 138 230 140 225 115 225 78Q233 61 220 50Z\" fill=\"#8d3f35\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M163 136Q193 127 229 137L228 149Q191 141 163 150Z\" fill=\"#b77a4d\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M168 141Q195 136 224 143\" fill=\"none\" stroke=\"#e0a260\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M179 130 178 100 183 102 186 98 190 101 190 130Z\" fill=\"#f5e2a7\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M181 105 181 117M187 106 187 123\" fill=\"none\" stroke=\"#d5b66a\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M183 100Q174 91 184 80Q189 89 186 99Z\" fill=\"#e9b955\" stroke=\"#a87635\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M184 96Q181 91 185 87Q187 93 184 96Z\" fill=\"#fff3c2\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M55 288 226 246 229 252 58 294Z\" fill=\"#a77a48\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M57 287Q51 277 41 275L27 280 48 281 54 296 63 294 67 279 85 270Q68 270 57 287Z\" fill=\"#aebbc0\" stroke=\"#39464b\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M232 241Q226 253 211 264L181 282 159 288 148 270 165 256 191 243 205 226Z\" fill=\"#60779e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M220 249 203 254 175 272M162 260 168 281\" fill=\"none\" stroke=\"#8e9fb8\" stroke-width=\"2.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M150 267 159 264 170 282 159 288 148 279Z\" fill=\"#d1c9ad\" stroke=\"#39464b\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M150 269Q143 259 134 262L126 269Q121 274 124 282L127 295Q132 300 135 293L135 280 140 297Q146 300 146 293L143 277 149 291Q155 293 156 287L151 273 159 279Q166 278 160 271Z\" fill=\"#edba87\" stroke=\"#39464b\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M132 268 135 280M139 268 143 277M147 270 151 279\" fill=\"none\" stroke=\"#a87453\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M54 440 177 301 198 306 94 440Z\" fill=\"#944e37\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M78 440 193 307 201 312 104 440Z\" fill=\"#bd7650\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M90 421 111 404M119 384 141 361M151 348 173 324\" fill=\"none\" stroke=\"#d79c68\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 358 24 338 53 344 67 363 52 380 11 381Z\" fill=\"#b3bbb3\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M24 339 30 359 12 380M30 359 65 364\" fill=\"none\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M1 387 23 382 41 397 39 416 0 429Z\" fill=\"#8c9c9c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M23 383 19 402 39 414\" fill=\"none\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	saboteur: "<path d=\"M105 329 133 331 129 385 143 401Q148 415 133 417H91Q82 411 90 400L103 386Z\" fill=\"#97713e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M177 329 203 323 208 383 232 400Q241 412 225 416L183 414 175 403Z\" fill=\"#80613d\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M93 409H136M184 407l44 2\" fill=\"none\" stroke=\"#c6a471\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M106 270 148 258 163 310 128 352 102 341Z\" fill=\"#aa783f\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M160 279 190 263 209 331 178 350 154 324Z\" fill=\"#c09143\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M105 203 143 190 187 208 210 274 181 308 133 292 103 266Z\" fill=\"#788a48\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M163 206 184 207 210 274 180 307 163 294Z\" fill=\"#566b3c\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M104 208 85 189 83 153 100 144 121 190Z\" fill=\"#8c9c58\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(85 148) rotate(-28)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M177 216 197 172 217 144 232 158 212 204 199 242Z\" fill=\"#8e6591\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(220 148) rotate(32)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><ellipse cx=\"124\" cy=\"173\" rx=\"8\" ry=\"13\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"178\" cy=\"171\" rx=\"8\" ry=\"12\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M124 152Q144 130 175 150L180 182 166 203 140 203 122 181Z\" fill=\"#edbc8a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M123 177Q137 189 149 182Q166 191 180 174L174 203 164 213 152 235 137 217 126 216Z\" fill=\"#efe2c0\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M134 195l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M144 195l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M158 195l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M169 195l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M130 164q7-6 13-2M158 162q7-5 13-1\" fill=\"none\" stroke=\"#efe2c0\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"138\" cy=\"170\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"165\" cy=\"169\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><path d=\"M152 166l-7 15q1 8 14 3\" fill=\"none\" stroke=\"#9c6b50\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M133 188q10-10 19-1q11-9 21-4\" fill=\"none\" stroke=\"#efe2c0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M143 194q10 7 20-2\" fill=\"none\" stroke=\"#755341\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M119 145Q128 97 162 80Q187 65 174 35Q206 55 191 82L185 145Z\" fill=\"#b74d3b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M174 44q22 31 8 52L176 140\" fill=\"none\" stroke=\"#d78056\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M118 142Q153 133 186 142L186 155Q153 147 118 155Z\" fill=\"#a97746\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M60 108 237 137\" fill=\"none\" stroke=\"#95663f\" stroke-width=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M64 105 237 134\" fill=\"none\" stroke=\"#d1a26b\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M68 83Q38 100 52 159L58 126 76 115 75 96 120 100Z\" fill=\"#b8c6c4\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M53 107 68 98 88 99\" fill=\"none\" stroke=\"#edf0dd\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M15 438 52 303 68 301 43 438Z\" fill=\"#9b593c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	boss: "<path d=\"M105 329 133 331 129 385 143 401Q148 415 133 417H91Q82 411 90 400L103 386Z\" fill=\"#97713e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M177 329 203 323 208 383 232 400Q241 412 225 416L183 414 175 403Z\" fill=\"#80613d\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M93 409H136M184 407l44 2\" fill=\"none\" stroke=\"#c6a471\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M111 286 143 289 143 352 111 357Z\" fill=\"#83a54b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M160 285 197 282 200 354 165 358Z\" fill=\"#6d9644\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M102 192 142 178 189 190 207 294 168 316 111 301 97 252Z\" fill=\"#50759a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M105 202Q129 191 159 217L198 215 208 238 157 247 114 225Z\" fill=\"#6f90b1\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M195 194 205 217 157 246 107 230 104 209 154 222Z\" fill=\"#597da2\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(157 223) rotate(74)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(111 216) rotate(-78)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M173 239 169 409\" fill=\"none\" stroke=\"#795b36\" stroke-width=\"7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M174 244 171 401\" fill=\"none\" stroke=\"#d2ac71\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"126\" cy=\"149\" rx=\"8\" ry=\"13\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"180\" cy=\"147\" rx=\"8\" ry=\"12\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M126 128Q146 106 177 126L182 158 168 179 142 179 124 157Z\" fill=\"#edbc8a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M125 153Q139 165 151 158Q168 167 182 150L176 179 166 189 154 211 139 193 128 192Z\" fill=\"#f4e8cc\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M136 171l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M146 171l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M160 171l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M171 171l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M132 140q7-6 13-2M160 138q7-5 13-1\" fill=\"none\" stroke=\"#f4e8cc\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"140\" cy=\"146\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"167\" cy=\"145\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><path d=\"M154 142l-7 15q1 8 14 3\" fill=\"none\" stroke=\"#9c6b50\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M135 164q10-10 19-1q11-9 21-4\" fill=\"none\" stroke=\"#f4e8cc\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M145 170q10 7 20-2\" fill=\"none\" stroke=\"#755341\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M117 123Q126 75 160 58Q185 43 172 13Q204 33 189 60L183 123Z\" fill=\"#ba543f\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M172 22q22 31 8 52L174 118\" fill=\"none\" stroke=\"#d78056\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M116 120Q151 111 184 120L184 133Q151 125 116 133Z\" fill=\"#a97746\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M177 98 202 111 206 144 186 165\" fill=\"none\" stroke=\"#d3bd5b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	profiteer: "<path d=\"M113 324 141 324 133 392 118 400 99 392Z\" fill=\"#b7863f\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M174 327 200 321 222 390 203 400 177 391Z\" fill=\"#c3924b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M99 389 129 392 142 407 134 417H83Q77 404 99 389Z\" fill=\"#795e41\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M200 388 221 384 237 410 221 420 190 412Z\" fill=\"#765d41\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M114 193 170 184 207 210 200 302 175 350 133 341 105 280Z\" fill=\"#b66873\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M182 211 207 210 200 304 175 350 163 338 177 290Z\" fill=\"#8c4c65\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M116 209 99 223 94 262 120 285 143 279 132 255 123 239Z\" fill=\"#d29299\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(132 258) rotate(65)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M193 205 214 222 189 258 154 250 152 226 179 234Z\" fill=\"#b66873\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(155 226) rotate(-60)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><ellipse cx=\"126\" cy=\"162\" rx=\"8\" ry=\"13\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"180\" cy=\"160\" rx=\"8\" ry=\"12\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M126 141Q146 119 177 139L182 171 168 192 142 192 124 170Z\" fill=\"#edbc8a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M125 166Q139 178 151 171Q168 180 182 163L176 192 166 202 154 224 139 206 128 205Z\" fill=\"#e7d3a4\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M136 184l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M146 184l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M160 184l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M171 184l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M132 153q7-6 13-2M160 151q7-5 13-1\" fill=\"none\" stroke=\"#e7d3a4\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"140\" cy=\"159\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"167\" cy=\"158\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><path d=\"M154 155l-7 15q1 8 14 3\" fill=\"none\" stroke=\"#9c6b50\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M135 177q10-10 19-1q11-9 21-4\" fill=\"none\" stroke=\"#e7d3a4\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M145 183q10 7 20-2\" fill=\"none\" stroke=\"#755341\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M124 134Q133 86 167 69Q192 54 179 24Q211 44 196 71L190 134Z\" fill=\"#a9473c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M179 33q22 31 8 52L181 129\" fill=\"none\" stroke=\"#d78056\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M123 131Q158 122 191 131L191 144Q158 136 123 144Z\" fill=\"#a97746\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M99 148Q105 112 122 112L123 169 111 180Z\" fill=\"#f1dcc1\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M86 214 104 209 118 244 98 253Z\" fill=\"#b4d9d2\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M89 215 100 239 104 210\" fill=\"none\" stroke=\"#f5f2d3\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M115 143 144 136 173 139 191 150 175 165 151 156 128 168Z\" fill=\"none\" stroke=\"#cbb465\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	geologist: "<path d=\"M125 271 206 258 237 300 208 328 150 326Z\" fill=\"#b3a25a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M109 214Q139 191 183 212L218 263 175 292 118 270 96 250Z\" fill=\"#a35c59\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M123 237 92 268 71 278 76 296 113 290 143 262Z\" fill=\"#c18173\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M181 232 209 241 200 298 177 313 159 299 176 278Z\" fill=\"#b66c66\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M51 352Q101 333 146 350Q189 331 247 346L235 404Q189 390 146 413Q100 394 49 406Z\" fill=\"#eadcb6\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M146 350V413M63 368Q103 355 134 369M65 383Q101 371 133 385M160 367 224 357M159 381l61-10\" fill=\"none\" stroke=\"#9c8c6a\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(98 310) rotate(75)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(182 319) rotate(-60)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><ellipse cx=\"112\" cy=\"214\" rx=\"8\" ry=\"13\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"166\" cy=\"212\" rx=\"8\" ry=\"12\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M112 193Q132 171 163 191L168 223 154 244 128 244 110 222Z\" fill=\"#edbc8a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M111 218Q125 230 137 223Q154 232 168 215L162 244 152 254 140 276 125 258 114 257Z\" fill=\"#e6d6b7\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M122 236l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M132 236l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M146 236l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M157 236l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M118 205q7-6 13-2M146 203q7-5 13-1\" fill=\"none\" stroke=\"#e6d6b7\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"126\" cy=\"211\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"153\" cy=\"210\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><path d=\"M140 207l-7 15q1 8 14 3\" fill=\"none\" stroke=\"#9c6b50\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M121 229q10-10 19-1q11-9 21-4\" fill=\"none\" stroke=\"#e6d6b7\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M131 235q10 7 20-2\" fill=\"none\" stroke=\"#755341\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M108 185Q118 154 151 163L181 193 166 203 145 186 116 198Z\" fill=\"#c4aa76\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"121\" cy=\"174\" rx=\"3\" ry=\"2\" fill=\"#a54e43\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"138\" cy=\"171\" rx=\"3\" ry=\"2\" fill=\"#a54e43\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"153\" cy=\"179\" rx=\"3\" ry=\"2\" fill=\"#a54e43\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"164\" cy=\"188\" rx=\"3\" ry=\"2\" fill=\"#a54e43\" stroke=\"none\" stroke-width=\"2\"/><path d=\"M116 210 135 210 137 225 118 225ZM141 210 160 211 159 225 141 225ZM137 216h4\" fill=\"none\" stroke=\"#685d47\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(211 323) scale(.52)\"><path d=\"M-8-37 7-48 20-23 11 31-9 40-20 14Z\" fill=\"#bcdce1\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-8-37 1-17-9 40M1-17 20-23M1-17l10 48\" fill=\"none\" stroke=\"#628f9b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-21-6-34-15-42 3-20 31-9 40Z\" fill=\"#86b8c4\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M18-3 33-10 44 8 11 31Z\" fill=\"#e1ebdf\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	greedy: "<path d=\"M105 329 133 331 129 385 143 401Q148 415 133 417H91Q82 411 90 400L103 386Z\" fill=\"#97713e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M177 329 203 323 208 383 232 400Q241 412 225 416L183 414 175 403Z\" fill=\"#80613d\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M93 409H136M184 407l44 2\" fill=\"none\" stroke=\"#c6a471\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M101 211 146 192 194 209 221 294 185 343 128 333 94 291Z\" fill=\"#8c587c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(148 290) scale(1.6)\"><path d=\"M-21-37-8-32 12-38 23-33 12-18Q46 7 35 36Q21 52-15 43Q-43 36-35 11L-14-17Z\" fill=\"#bd9456\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-15-18 13-19M-22 8Q-28 25-18 32M12-14 23 14\" fill=\"none\" stroke=\"#e0bd7d\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"18\" cy=\"27\" rx=\"14\" ry=\"10\" fill=\"#e6b64e\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M10 26 17 20 26 24 21 33Z\" fill=\"#f2d581\" stroke=\"#39464b\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M101 219 83 254 107 300 132 292 112 260 132 229Z\" fill=\"#ac7795\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(126 284) rotate(70)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M190 215 213 238 201 290 172 303 159 281 181 270 172 236Z\" fill=\"#986586\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(178 282) rotate(-60)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><ellipse cx=\"123\" cy=\"168\" rx=\"8\" ry=\"13\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"177\" cy=\"166\" rx=\"8\" ry=\"12\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M123 147Q143 125 174 145L179 177 165 198 139 198 121 176Z\" fill=\"#edbc8a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M122 172Q136 184 148 177Q165 186 179 169L173 198 163 208 151 230 136 212 125 211Z\" fill=\"#e7d0a8\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M133 190l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M143 190l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M157 190l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M168 190l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M129 159q7-6 13-2M157 157q7-5 13-1\" fill=\"none\" stroke=\"#e7d0a8\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"137\" cy=\"165\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"164\" cy=\"164\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><path d=\"M151 161l-7 15q1 8 14 3\" fill=\"none\" stroke=\"#9c6b50\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M132 183q10-10 19-1q11-9 21-4\" fill=\"none\" stroke=\"#e7d0a8\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M142 189q10 7 20-2\" fill=\"none\" stroke=\"#755341\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M114 142Q123 94 157 77Q182 62 169 32Q201 52 186 79L180 142Z\" fill=\"#a36f3c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M169 41q22 31 8 52L171 137\" fill=\"none\" stroke=\"#d78056\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M113 139Q148 130 181 139L181 152Q148 144 113 152Z\" fill=\"#a97746\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M132 189q18 9 34-2\" fill=\"none\" stroke=\"#6f493d\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	cart: "<path d=\"M53 223 91 176 168 163 248 191 234 244 103 271Z\" fill=\"#d5d9ca\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M77 209 84 185 107 177 123 191 117 212Z\" fill=\"#a9b8b4\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M118 195 137 169 163 171 181 191 161 214Z\" fill=\"#e0dec9\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M170 192 182 176 205 184 214 208 193 218Z\" fill=\"#b4c0b8\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M207 206 218 188 239 194 246 212 225 225Z\" fill=\"#8ca4a5\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M94 224 114 209 143 215 152 236 115 246Z\" fill=\"#b9c6bd\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M154 226 168 207 188 213 196 232 178 245Z\" fill=\"#d9ddcc\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M106 193 119 186 130 193 125 206 110 207Z\" fill=\"#e7b657\" stroke=\"#39464b\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M187 205 198 198 210 205 207 217 192 216Z\" fill=\"#e7b657\" stroke=\"#39464b\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M48 227 103 249 243 217 246 235 103 272 49 246Z\" fill=\"#b67b43\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M52 246 103 270 231 239 213 329 103 364 69 340Z\" fill=\"#aa6536\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M103 270 231 239 213 329 103 364Z\" fill=\"#ce8743\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M70 277 103 292 226 262M75 305 103 319 220 289M82 333 103 344 214 315\" fill=\"none\" stroke=\"#6f4b34\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M111 279 207 255M112 306 203 284M116 333 197 312\" fill=\"none\" stroke=\"#e1a463\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M86 259 96 263 107 353 98 357Z\" fill=\"#5f6b69\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M200 246 210 244 190 336 180 339Z\" fill=\"#5f6b69\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"92\" cy=\"277\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"99\" cy=\"331\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"201\" cy=\"264\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"186\" cy=\"320\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><path d=\"M86 343 207 311 209 322 88 358Z\" fill=\"#665240\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"101\" cy=\"354\" rx=\"24\" ry=\"32\" fill=\"#795a3a\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"98\" cy=\"353\" rx=\"15\" ry=\"24\" fill=\"#b08045\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"98\" cy=\"353\" rx=\"4\" ry=\"6\" fill=\"#e3c687\" stroke=\"#39464b\" stroke-width=\"1.4\"/><ellipse cx=\"201\" cy=\"329\" rx=\"21\" ry=\"29\" fill=\"#70573c\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"198\" cy=\"328\" rx=\"13\" ry=\"21\" fill=\"#b08045\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"198\" cy=\"328\" rx=\"4\" ry=\"6\" fill=\"#e3c687\" stroke=\"#39464b\" stroke-width=\"1.4\"/><path d=\"M97 332 99 346M86 348 92 350M105 367 101 360M198 309 199 321M189 324 193 327M204 342 201 335\" fill=\"none\" stroke=\"#654c36\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"cart-broken": "<g transform=\"translate(20 35) rotate(-20 140 260)\"><path d=\"M53 223 91 176 168 163 248 191 234 244 103 271Z\" fill=\"#d5d9ca\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M77 209 84 185 107 177 123 191 117 212Z\" fill=\"#a9b8b4\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M118 195 137 169 163 171 181 191 161 214Z\" fill=\"#e0dec9\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M170 192 182 176 205 184 214 208 193 218Z\" fill=\"#b4c0b8\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M207 206 218 188 239 194 246 212 225 225Z\" fill=\"#8ca4a5\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M94 224 114 209 143 215 152 236 115 246Z\" fill=\"#b9c6bd\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M154 226 168 207 188 213 196 232 178 245Z\" fill=\"#d9ddcc\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M106 193 119 186 130 193 125 206 110 207Z\" fill=\"#e7b657\" stroke=\"#39464b\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M187 205 198 198 210 205 207 217 192 216Z\" fill=\"#e7b657\" stroke=\"#39464b\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M48 227 103 249 243 217 246 235 103 272 49 246Z\" fill=\"#b67b43\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M52 246 103 270 231 239 213 329 103 364 69 340Z\" fill=\"#aa6536\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M103 270 231 239 213 329 103 364Z\" fill=\"#ce8743\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M70 277 103 292 226 262M75 305 103 319 220 289M82 333 103 344 214 315\" fill=\"none\" stroke=\"#6f4b34\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M111 279 207 255M112 306 203 284M116 333 197 312\" fill=\"none\" stroke=\"#e1a463\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M86 259 96 263 107 353 98 357Z\" fill=\"#5f6b69\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M200 246 210 244 190 336 180 339Z\" fill=\"#5f6b69\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"92\" cy=\"277\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"99\" cy=\"331\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"201\" cy=\"264\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"186\" cy=\"320\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><path d=\"M86 343 207 311 209 322 88 358Z\" fill=\"#665240\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"101\" cy=\"354\" rx=\"24\" ry=\"32\" fill=\"#795a3a\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"98\" cy=\"353\" rx=\"15\" ry=\"24\" fill=\"#b08045\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"98\" cy=\"353\" rx=\"4\" ry=\"6\" fill=\"#e3c687\" stroke=\"#39464b\" stroke-width=\"1.4\"/><ellipse cx=\"201\" cy=\"329\" rx=\"21\" ry=\"29\" fill=\"#70573c\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"198\" cy=\"328\" rx=\"13\" ry=\"21\" fill=\"#b08045\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"198\" cy=\"328\" rx=\"4\" ry=\"6\" fill=\"#e3c687\" stroke=\"#39464b\" stroke-width=\"1.4\"/><path d=\"M97 332 99 346M86 348 92 350M105 367 101 360M198 309 199 321M189 324 193 327M204 342 201 335\" fill=\"none\" stroke=\"#654c36\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M74 367 93 357 105 364 94 376Z\" fill=\"#aebfbd\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	lamp: "<path d=\"M127 199C126 176 129 141 145 141C160 139 169 171 174 197\" fill=\"none\" stroke=\"#556c62\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M130 196C130 176 133 147 145 146C157 145 165 174 170 196\" fill=\"none\" stroke=\"#cad3b6\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M96 216 151 195 209 210 154 231Z\" fill=\"#96b09b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M96 216 154 231 209 210 207 221 154 243 98 228Z\" fill=\"#638978\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M104 233 153 248 199 231 196 339 153 359 110 344Z\" fill=\"#e8d896\" stroke=\"#728c77\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M112 241 147 252 147 347 117 337Z\" fill=\"#f6e9b7\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M161 251 190 240 188 332 161 345Z\" fill=\"#ddca7e\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M124 245 124 337M178 245 176 339\" fill=\"none\" stroke=\"#fff0c8\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(-12 0)\"><path d=\"M140 331 141 282 146 285 151 280 158 283 158 332Z\" fill=\"#e2ad42\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M148 284Q138 274 149 260Q157 273 151 283Z\" fill=\"#ecbb4c\" stroke=\"#aa7c32\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M149 280Q145 274 150 268Q153 275 149 280Z\" fill=\"#fff3c1\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M105 231 113 234 118 344 110 346Z\" fill=\"#789b83\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M150 244 157 243 158 355 150 358Z\" fill=\"#8da57e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M193 230 201 227 198 341 191 344Z\" fill=\"#789b83\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M109 341 153 356 198 339 203 349 153 370 106 354Z\" fill=\"#9fb398\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M107 354 153 369 204 349 202 359 153 379 108 365Z\" fill=\"#5d8271\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M111 357 153 371 199 353\" fill=\"none\" stroke=\"#d2d8b3\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"lamp-broken": "<path d=\"M82 277 153 248 227 269 165 301Z\" fill=\"#b6c9b6\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M82 277 86 332 164 357 165 301Z\" fill=\"#d2dcd1\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M165 301 227 269 220 335 164 357Z\" fill=\"#8ba996\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M94 285 99 320 129 329 125 293M181 297 178 337 206 326 212 281\" fill=\"none\" stroke=\"#e7e6cf\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M90 332 162 355 221 332 221 343 162 369 89 346Z\" fill=\"#799787\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M99 370 118 359 131 382Z\" fill=\"#d9e7dd\" stroke=\"#39464b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M199 370 216 356 225 381 208 390Z\" fill=\"#d9e7dd\" stroke=\"#39464b\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	pick: "<path d=\"M88 352 173 214 184 220 101 359Z\" fill=\"#ac7a42\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M96 348 177 219\" fill=\"none\" stroke=\"#ddb577\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M104 217Q159 172 219 220L182 208 175 227 162 224 159 207Z\" fill=\"#aebfc0\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M109 213Q161 183 214 216\" fill=\"none\" stroke=\"#dde1d3\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"pick-broken": "<path d=\"M77 367 115 310 127 314 90 372Z\" fill=\"#ac7a42\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M132 297 173 214 184 220 145 303 141 296 137 303Z\" fill=\"#b5864b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M104 217Q159 172 219 220L182 208 175 227 162 224 159 207Z\" fill=\"#aebfc0\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M109 213Q161 183 214 216\" fill=\"none\" stroke=\"#dde1d3\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	map: "<path d=\"M59 277 110 262 161 277 213 260 233 333 177 353 125 337 75 355Z\" fill=\"#efe2bc\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M110 262 125 337M161 277 177 353\" fill=\"none\" stroke=\"#b9a77e\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M82 315Q108 287 130 306T170 303T210 300\" fill=\"none\" stroke=\"#788f83\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M95 291 105 295 110 307 101 314 89 307Z\" fill=\"#c8ceb8\" stroke=\"#39464b\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M185 313 197 305 211 314 207 329 190 329Z\" fill=\"#a8bcb0\" stroke=\"#39464b\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	rockfall: "<g transform=\"translate(85 164) rotate(-15) scale(0.8)\"><path d=\"M-41 14-32-22-2-38 31-20 44 18 17 35-21 33Z\" fill=\"#869ea5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-32-22-10 3 31-20M-10 3l-11 30M-10 3 17 35 44 18\" fill=\"none\" stroke=\"#4f6973\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(191 202) rotate(30) scale(0.9)\"><path d=\"M-41 14-32-22-2-38 31-20 44 18 17 35-21 33Z\" fill=\"#869ea5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-32-22-10 3 31-20M-10 3l-11 30M-10 3 17 35 44 18\" fill=\"none\" stroke=\"#4f6973\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(127 285) rotate(12) scale(1.1)\"><path d=\"M-41 14-32-22-2-38 31-20 44 18 17 35-21 33Z\" fill=\"#869ea5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-32-22-10 3 31-20M-10 3l-11 30M-10 3 17 35 44 18\" fill=\"none\" stroke=\"#4f6973\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(227 332) rotate(20) scale(0.5)\"><path d=\"M-41 14-32-22-2-38 31-20 44 18 17 35-21 33Z\" fill=\"#869ea5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-32-22-10 3 31-20M-10 3l-11 30M-10 3 17 35 44 18\" fill=\"none\" stroke=\"#4f6973\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(56 340) rotate(12) scale(0.6)\"><path d=\"M-41 14-32-22-2-38 31-20 44 18 17 35-21 33Z\" fill=\"#869ea5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-32-22-10 3 31-20M-10 3l-11 30M-10 3 17 35 44 18\" fill=\"none\" stroke=\"#4f6973\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M82 105l-10 25M185 122l15 28M242 240l-10 20\" fill=\"none\" stroke=\"#e1c99c\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	trap: "<path d=\"M75 356V183Q75 110 154 111T230 183V356Z\" fill=\"#805d3e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M86 346V184Q86 125 154 125T218 184V346Z\" fill=\"#453e34\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M87 238H216V346H87Z\" fill=\"#ad7c47\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M95 233V164M122 233V140M150 233V134M179 233V140M205 233V163\" fill=\"none\" stroke=\"#b7c6bb\" stroke-width=\"7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(123 224) rotate(0)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(186 221) rotate(0)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M83 252H222M83 328H222\" fill=\"none\" stroke=\"#b9c5b9\" stroke-width=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"94\" cy=\"252\" rx=\"3\" ry=\"3\" fill=\"#576c64\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"208\" cy=\"252\" rx=\"3\" ry=\"3\" fill=\"#576c64\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"94\" cy=\"328\" rx=\"3\" ry=\"3\" fill=\"#576c64\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"208\" cy=\"328\" rx=\"3\" ry=\"3\" fill=\"#576c64\" stroke=\"none\" stroke-width=\"2\"/>",
	freedom: "<path d=\"M75 356V183Q75 110 154 111T230 183V356Z\" fill=\"#805d3e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M86 346V184Q86 125 154 125T218 184V346Z\" fill=\"#453e34\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M86 185 167 150V335L86 347Z\" fill=\"#a17344\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M111 177V339M139 165V334\" fill=\"none\" stroke=\"#614c35\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M83 252H222M83 328H222\" fill=\"none\" stroke=\"#b9c5b9\" stroke-width=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"94\" cy=\"252\" rx=\"3\" ry=\"3\" fill=\"#576c64\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"208\" cy=\"252\" rx=\"3\" ry=\"3\" fill=\"#576c64\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"94\" cy=\"328\" rx=\"3\" ry=\"3\" fill=\"#576c64\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"208\" cy=\"328\" rx=\"3\" ry=\"3\" fill=\"#576c64\" stroke=\"none\" stroke-width=\"2\"/>",
	theft: "<g transform=\"translate(150 326) scale(1.25)\"><path d=\"M-21-37-8-32 12-38 23-33 12-18Q46 7 35 36Q21 52-15 43Q-43 36-35 11L-14-17Z\" fill=\"#bd9456\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-15-18 13-19M-22 8Q-28 25-18 32M12-14 23 14\" fill=\"none\" stroke=\"#e0bd7d\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"18\" cy=\"27\" rx=\"14\" ry=\"10\" fill=\"#e6b64e\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M10 26 17 20 26 24 21 33Z\" fill=\"#f2d581\" stroke=\"#39464b\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M299 174 252 187 196 246 176 256 185 278 215 265 270 224 300 219Z\" fill=\"#a4b66c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(183 257) rotate(-80)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	handsOff: "<g transform=\"translate(150 326) scale(1.25)\"><path d=\"M-21-37-8-32 12-38 23-33 12-18Q46 7 35 36Q21 52-15 43Q-43 36-35 11L-14-17Z\" fill=\"#bd9456\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-15-18 13-19M-22 8Q-28 25-18 32M12-14 23 14\" fill=\"none\" stroke=\"#e0bd7d\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"18\" cy=\"27\" rx=\"14\" ry=\"10\" fill=\"#e6b64e\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M10 26 17 20 26 24 21 33Z\" fill=\"#f2d581\" stroke=\"#39464b\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M299 174 252 187 196 246 176 256 185 278 215 265 270 224 300 219Z\" fill=\"#a4b66c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(183 257) rotate(-80)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M0 191 54 205 104 244 116 254 103 275 73 254 32 238 0 239Z\" fill=\"#a174a2\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(115 250) rotate(100)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	inspect: "<g transform=\"translate(0 10)\"><ellipse cx=\"123\" cy=\"173\" rx=\"8\" ry=\"13\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"177\" cy=\"171\" rx=\"8\" ry=\"12\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M123 152Q143 130 174 150L179 182 165 203 139 203 121 181Z\" fill=\"#edbc8a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M122 177Q136 189 148 182Q165 191 179 174L173 203 163 213 151 235 136 217 125 216Z\" fill=\"#f4e8cc\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M133 195l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M143 195l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M157 195l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M168 195l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M129 164q7-6 13-2M157 162q7-5 13-1\" fill=\"none\" stroke=\"#f4e8cc\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"137\" cy=\"170\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"164\" cy=\"169\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><path d=\"M151 166l-7 15q1 8 14 3\" fill=\"none\" stroke=\"#9c6b50\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M132 188q10-10 19-1q11-9 21-4\" fill=\"none\" stroke=\"#f4e8cc\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M142 194q10 7 20-2\" fill=\"none\" stroke=\"#755341\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M117 146Q126 98 160 81Q185 66 172 36Q204 56 189 83L183 146Z\" fill=\"#b74d3b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M172 45q22 31 8 52L174 141\" fill=\"none\" stroke=\"#d78056\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M116 143Q151 134 184 143L184 156Q151 148 116 156Z\" fill=\"#a97746\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M101 222 148 211 207 236 187 335 121 345Z\" fill=\"#7c9a51\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(152 302) rotate(-9)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#ecdfbb\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(114 309) rotate(80)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(187 302) rotate(-70)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g>",
	hats: "<g transform=\"rotate(-28 150 270)\"><path d=\"M111 255Q120 207 154 190Q179 175 166 145Q198 165 183 192L177 255Z\" fill=\"#ddaa48\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M166 154q22 31 8 52L168 250\" fill=\"none\" stroke=\"#d78056\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M110 252Q145 243 178 252L178 265Q145 257 110 265Z\" fill=\"#a97746\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(126 278) rotate(110)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M270 149 229 208 210 242 188 239 198 205 235 132Z\" fill=\"#e0b765\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(212 239) rotate(24)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	hands: "<g transform=\"translate(103 238) rotate(-18)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(203 311) rotate(12)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#ecdfbb\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(70 283) rotate(60)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(225 348) rotate(-80)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(200 196) rotate(25)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(101 352) rotate(200)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	goals: "<g transform=\"translate(78 276) rotate(-8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(222 276) rotate(8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(152 176) rotate(0)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(150 360) rotate(180)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	trove: "<g transform=\"translate(90 268) rotate(-6)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(102 257) rotate(-6)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(114 246) rotate(-6)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(126 235) rotate(-6)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(138 224) rotate(-6)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(227 311) rotate(10)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#ecdfbb\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(190 229) rotate(30)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#be5948\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	veto: "<g transform=\"translate(150 277) rotate(-8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#ecdfbb\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M74 356 229 196\" fill=\"none\" stroke=\"#b84f42\" stroke-width=\"17\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M94 194 208 356\" fill=\"none\" stroke=\"#b84f42\" stroke-width=\"17\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	reverse: "<g transform=\"translate(148 236) rotate(0)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(149 313) rotate(180)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	master: "<g transform=\"translate(-7 92) scale(.65)\"><path d=\"M53 223 91 176 168 163 248 191 234 244 103 271Z\" fill=\"#d5d9ca\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M77 209 84 185 107 177 123 191 117 212Z\" fill=\"#a9b8b4\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M118 195 137 169 163 171 181 191 161 214Z\" fill=\"#e0dec9\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M170 192 182 176 205 184 214 208 193 218Z\" fill=\"#b4c0b8\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M207 206 218 188 239 194 246 212 225 225Z\" fill=\"#8ca4a5\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M94 224 114 209 143 215 152 236 115 246Z\" fill=\"#b9c6bd\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M154 226 168 207 188 213 196 232 178 245Z\" fill=\"#d9ddcc\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M106 193 119 186 130 193 125 206 110 207Z\" fill=\"#e7b657\" stroke=\"#39464b\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M187 205 198 198 210 205 207 217 192 216Z\" fill=\"#e7b657\" stroke=\"#39464b\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M48 227 103 249 243 217 246 235 103 272 49 246Z\" fill=\"#b67b43\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M52 246 103 270 231 239 213 329 103 364 69 340Z\" fill=\"#aa6536\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M103 270 231 239 213 329 103 364Z\" fill=\"#ce8743\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M70 277 103 292 226 262M75 305 103 319 220 289M82 333 103 344 214 315\" fill=\"none\" stroke=\"#6f4b34\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M111 279 207 255M112 306 203 284M116 333 197 312\" fill=\"none\" stroke=\"#e1a463\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M86 259 96 263 107 353 98 357Z\" fill=\"#5f6b69\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M200 246 210 244 190 336 180 339Z\" fill=\"#5f6b69\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"92\" cy=\"277\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"99\" cy=\"331\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"201\" cy=\"264\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"186\" cy=\"320\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><path d=\"M86 343 207 311 209 322 88 358Z\" fill=\"#665240\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"101\" cy=\"354\" rx=\"24\" ry=\"32\" fill=\"#795a3a\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"98\" cy=\"353\" rx=\"15\" ry=\"24\" fill=\"#b08045\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"98\" cy=\"353\" rx=\"4\" ry=\"6\" fill=\"#e3c687\" stroke=\"#39464b\" stroke-width=\"1.4\"/><ellipse cx=\"201\" cy=\"329\" rx=\"21\" ry=\"29\" fill=\"#70573c\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"198\" cy=\"328\" rx=\"13\" ry=\"21\" fill=\"#b08045\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"198\" cy=\"328\" rx=\"4\" ry=\"6\" fill=\"#e3c687\" stroke=\"#39464b\" stroke-width=\"1.4\"/><path d=\"M97 332 99 346M86 348 92 350M105 367 101 360M198 309 199 321M189 324 193 327M204 342 201 335\" fill=\"none\" stroke=\"#654c36\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(146 2) scale(.54)\"><path d=\"M127 199C126 176 129 141 145 141C160 139 169 171 174 197\" fill=\"none\" stroke=\"#556c62\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M130 196C130 176 133 147 145 146C157 145 165 174 170 196\" fill=\"none\" stroke=\"#cad3b6\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M96 216 151 195 209 210 154 231Z\" fill=\"#96b09b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M96 216 154 231 209 210 207 221 154 243 98 228Z\" fill=\"#638978\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M104 233 153 248 199 231 196 339 153 359 110 344Z\" fill=\"#e8d896\" stroke=\"#728c77\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M112 241 147 252 147 347 117 337Z\" fill=\"#f6e9b7\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M161 251 190 240 188 332 161 345Z\" fill=\"#ddca7e\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M124 245 124 337M178 245 176 339\" fill=\"none\" stroke=\"#fff0c8\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(-12 0)\"><path d=\"M140 331 141 282 146 285 151 280 158 283 158 332Z\" fill=\"#e2ad42\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M148 284Q138 274 149 260Q157 273 151 283Z\" fill=\"#ecbb4c\" stroke=\"#aa7c32\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M149 280Q145 274 150 268Q153 275 149 280Z\" fill=\"#fff3c1\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M105 231 113 234 118 344 110 346Z\" fill=\"#789b83\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M150 244 157 243 158 355 150 358Z\" fill=\"#8da57e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M193 230 201 227 198 341 191 344Z\" fill=\"#789b83\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M109 341 153 356 198 339 203 349 153 370 106 354Z\" fill=\"#9fb398\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M107 354 153 369 204 349 202 359 153 379 108 365Z\" fill=\"#5d8271\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M111 357 153 371 199 353\" fill=\"none\" stroke=\"#d2d8b3\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(50 -45) scale(.85)\"><path d=\"M88 352 173 214 184 220 101 359Z\" fill=\"#ac7a42\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M96 348 177 219\" fill=\"none\" stroke=\"#ddb577\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M104 217Q159 172 219 220L182 208 175 227 162 224 159 207Z\" fill=\"#aebfc0\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M109 213Q161 183 214 216\" fill=\"none\" stroke=\"#dde1d3\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	pathfinder: "<g transform=\"translate(89 279) rotate(-8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(211 279) rotate(8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M90 241V309M211 240V308\" fill=\"none\" stroke=\"#eee2c4\" stroke-width=\"20\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(151 180) rotate(0)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	diversion: "<rect x=\"52\" y=\"256\" width=\"70\" height=\"109\" rx=\"4\" fill=\"none\" stroke=\"#d9dfd2\" stroke-width=\"3\"/><g transform=\"translate(218 203) rotate(8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(150 260) rotate(-48)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"deck-back": "<rect x=\"0\" y=\"0\" width=\"300\" height=\"440\" rx=\"0\" fill=\"#eee8d9\" stroke=\"none\" stroke-width=\"2\"/><rect x=\"0\" y=\"0\" width=\"300\" height=\"440\" rx=\"12\" fill=\"#eee7d8\" stroke=\"none\" stroke-width=\"2\"/><rect x=\"12\" y=\"12\" width=\"276\" height=\"416\" rx=\"9\" fill=\"#87989b\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M27 72 22 27 94 22 151 26 210 22 276 31 270 84M26 365 24 411 103 416 176 412 271 411 274 352\" fill=\"none\" stroke=\"#526b72\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M29 112 40 133 33 161M266 267 256 283 262 313M74 24 67 45 81 67M214 412 208 386 220 369\" fill=\"none\" stroke=\"#667e85\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M95 282 207 151\" fill=\"none\" stroke=\"#4d5146\" stroke-width=\"18\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M95 279 207 148\" fill=\"none\" stroke=\"#ced6cf\" stroke-width=\"11\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M92 157 206 282\" fill=\"none\" stroke=\"#4d5146\" stroke-width=\"18\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M92 154 206 279\" fill=\"none\" stroke=\"#ced6cf\" stroke-width=\"11\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M167 143Q211 115 250 159L217 146 202 167 192 159 195 143Z\" fill=\"#ced6cf\" stroke=\"#39464b\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M65 124 100 116 120 144 94 171 68 150Z\" fill=\"#ced6cf\" stroke=\"#39464b\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"goal-back": "<rect x=\"0\" y=\"0\" width=\"300\" height=\"440\" rx=\"0\" fill=\"#eee8d9\" stroke=\"none\" stroke-width=\"2\"/><rect x=\"0\" y=\"0\" width=\"300\" height=\"440\" rx=\"12\" fill=\"#eee7d8\" stroke=\"none\" stroke-width=\"2\"/><rect x=\"12\" y=\"12\" width=\"276\" height=\"416\" rx=\"9\" fill=\"#b17f3a\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M27 72 22 27 94 22 151 26 210 22 276 31 270 84M26 365 24 411 103 416 176 412 271 411 274 352\" fill=\"none\" stroke=\"#655b46\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M29 112 40 133 33 161M266 267 256 283 262 313M74 24 67 45 81 67M214 412 208 386 220 369\" fill=\"none\" stroke=\"#836137\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M95 282 207 151\" fill=\"none\" stroke=\"#4d5146\" stroke-width=\"18\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M95 279 207 148\" fill=\"none\" stroke=\"#f0c66e\" stroke-width=\"11\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M92 157 206 282\" fill=\"none\" stroke=\"#4d5146\" stroke-width=\"18\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M92 154 206 279\" fill=\"none\" stroke=\"#f0c66e\" stroke-width=\"11\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M167 143Q211 115 250 159L217 146 202 167 192 159 195 143Z\" fill=\"#f0c66e\" stroke=\"#39464b\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M65 124 100 116 120 144 94 171 68 150Z\" fill=\"#f0c66e\" stroke=\"#39464b\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"object-gold": "<path d=\"M-39 15-26-20-1-33 23-23 39 7 24 29-16 34Z\" fill=\"#e6ad3e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-26-20-8 5 23-23M-8 5l-8 29M-8 5 24 29 39 7M-1-33-8 5\" fill=\"none\" stroke=\"#a97433\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-22-18-14-4 0-20Z\" fill=\"#ffe09a\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"object-sack": "<path d=\"M-21-37-8-32 12-38 23-33 12-18Q46 7 35 36Q21 52-15 43Q-43 36-35 11L-14-17Z\" fill=\"#bd9456\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-15-18 13-19M-22 8Q-28 25-18 32M12-14 23 14\" fill=\"none\" stroke=\"#e0bd7d\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"18\" cy=\"27\" rx=\"14\" ry=\"10\" fill=\"#e6b64e\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M10 26 17 20 26 24 21 33Z\" fill=\"#f2d581\" stroke=\"#39464b\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"object-rock": "<path d=\"M-41 14-32-22-2-38 31-20 44 18 17 35-21 33Z\" fill=\"#869ea5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-32-22-10 3 31-20M-10 3l-11 30M-10 3 17 35 44 18\" fill=\"none\" stroke=\"#4f6973\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"object-crystal": "<path d=\"M-8-37 7-48 20-23 11 31-9 40-20 14Z\" fill=\"#bcdce1\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-8-37 1-17-9 40M1-17 20-23M1-17l10 48\" fill=\"none\" stroke=\"#628f9b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-21-6-34-15-42 3-20 31-9 40Z\" fill=\"#86b8c4\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M18-3 33-10 44 8 11 31Z\" fill=\"#e1ebdf\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"object-spider": "<path d=\"M-12 -17Q-35 -29 -42 -43L-53 -36\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-12 -5Q-35 -17 -42 -22L-53 -15\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-12 8Q-35 -4 -42 18L-53 25\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-12 19Q-35 7 -42 44L-53 51\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 -17Q35 -29 42 -43L53 -36\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 -5Q35 -17 42 -22L53 -15\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 8Q35 -4 42 18L53 25\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 19Q35 7 42 44L53 51\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"0\" cy=\"8\" rx=\"19\" ry=\"29\" fill=\"#455b43\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"0\" cy=\"-22\" rx=\"15\" ry=\"13\" fill=\"#758657\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M-13 0 0-11 13 0 6 15-7 17Z\" fill=\"#c8c688\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"-6\" cy=\"-24\" rx=\"3.5\" ry=\"4\" fill=\"#f1d890\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"6\" cy=\"-24\" rx=\"3.5\" ry=\"4\" fill=\"#f1d890\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"-6\" cy=\"-24\" rx=\"1.5\" ry=\"2\" fill=\"#39464b\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"6\" cy=\"-24\" rx=\"1.5\" ry=\"2\" fill=\"#39464b\" stroke=\"#39464b\" stroke-width=\"2\"/>",
	"object-dragon": "<path d=\"M-7 3Q-43-25-31-51L-11-29 1-51 16-18 34-21 25 5Z\" fill=\"#96a36d\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-24-35-14-12 1-30 12-6\" fill=\"none\" stroke=\"#596e49\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-16Q37-41 44-10Q44 12 16 17Q-10 21-17 39Q-23 54-42 41Q-25 60 3 39Q12 29 31 30Q60 21 56-10Q53-42 24-42Q-3-44-14-24Z\" fill=\"#7eaa59\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M28-40 37-26 51-24M43-18 54-12M47 1l9 7M34 15l9 12\" fill=\"none\" stroke=\"#c64d39\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-13-27-29-20-34-6-15 1 1-11Z\" fill=\"#94b66b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"-22\" cy=\"-17\" rx=\"3\" ry=\"3\" fill=\"#e4c36e\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"-22\" cy=\"-17\" rx=\"1.3\" ry=\"2\" fill=\"#39464b\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M-32-7-16-8M-31-3l-5 7\" fill=\"none\" stroke=\"#454c39\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"object-chest": "<path d=\"M-42-5Q-43-41 0-41T42-5V38H-42Z\" fill=\"#9a613a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-42-5H42M-27-32V37M27-32V37\" fill=\"none\" stroke=\"#c7a45d\" stroke-width=\"8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-38 11H38M-38 26H38\" fill=\"none\" stroke=\"#613f30\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><rect x=\"-9\" y=\"-10\" width=\"18\" height=\"27\" rx=\"2\" fill=\"#e0bb6f\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"0\" cy=\"2\" rx=\"3\" ry=\"4\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/>",
	costume: "<g transform=\"rotate(-38 130 255) scale(.8)\"><path d=\"M84 275Q93 227 127 210Q152 195 139 165Q171 185 156 212L150 275Z\" fill=\"#b74d3b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M139 174q22 31 8 52L141 270\" fill=\"none\" stroke=\"#d78056\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M83 272Q118 263 151 272L151 285Q118 277 83 285Z\" fill=\"#a97746\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(-41 95) scale(.8)\"><path d=\"M88 352 173 214 184 220 101 359Z\" fill=\"#ac7a42\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M96 348 177 219\" fill=\"none\" stroke=\"#ddb577\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M104 217Q159 172 219 220L182 208 175 227 162 224 159 207Z\" fill=\"#aebfc0\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M109 213Q161 183 214 216\" fill=\"none\" stroke=\"#dde1d3\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M198 308Q219 283 237 313L224 356 211 407 191 399 203 358Z\" fill=\"#b9523d\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	party: "<path d=\"M28 74Q85 144 123 311T267 389M41 353Q137 334 259 89\" fill=\"none\" stroke=\"#495d56\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M49 112l27 9-20 20Z\" fill=\"#b75243\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M76 159l27 9-20 20Z\" fill=\"#d4ae4a\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M95 212l27 9-20 20Z\" fill=\"#72976c\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M116 267l27 9-20 20Z\" fill=\"#5c91a0\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M158 337l27 9-20 20Z\" fill=\"#b75243\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M199 361l27 9-20 20Z\" fill=\"#d4ae4a\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M231 142l27 9-20 20Z\" fill=\"#b75243\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M205 198l27 9-20 20Z\" fill=\"#72976c\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M57 301 84 295 91 331 63 336Z\" fill=\"#d0ad4d\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"170\" cy=\"188\" rx=\"19\" ry=\"28\" fill=\"#e9d6a5\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M163 180h15v17h-15Z\" fill=\"#9e7247\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M172 190 206 240\" fill=\"none\" stroke=\"#a77c46\" stroke-width=\"7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M94 365q-14-24-28-10t4 23q14 8 24-13Z\" fill=\"#ba8a48\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	toll: "<g transform=\"translate(24 74) scale(.83)\"><path d=\"M105 329 133 331 129 385 143 401Q148 415 133 417H91Q82 411 90 400L103 386Z\" fill=\"#97713e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M177 329 203 323 208 383 232 400Q241 412 225 416L183 414 175 403Z\" fill=\"#80613d\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M93 409H136M184 407l44 2\" fill=\"none\" stroke=\"#c6a471\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M101 211 146 192 194 209 221 294 185 343 128 333 94 291Z\" fill=\"#8c587c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(148 290) scale(1.6)\"><path d=\"M-21-37-8-32 12-38 23-33 12-18Q46 7 35 36Q21 52-15 43Q-43 36-35 11L-14-17Z\" fill=\"#bd9456\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-15-18 13-19M-22 8Q-28 25-18 32M12-14 23 14\" fill=\"none\" stroke=\"#e0bd7d\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"18\" cy=\"27\" rx=\"14\" ry=\"10\" fill=\"#e6b64e\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M10 26 17 20 26 24 21 33Z\" fill=\"#f2d581\" stroke=\"#39464b\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M101 219 83 254 107 300 132 292 112 260 132 229Z\" fill=\"#ac7795\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(126 284) rotate(70)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M190 215 213 238 201 290 172 303 159 281 181 270 172 236Z\" fill=\"#986586\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(178 282) rotate(-60)\"><path d=\"M-17 9Q-23-4-16-11L-10-20Q-4-22-4-13V-4L0-22Q6-27 8-20L6-3 12-18Q19-23 20-16L15 1 22-10Q28-13 29-7L23 10 12 21-4 24Z\" fill=\"#eaba88\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-4-6 10M6-3 3 12M15 1 10 15\" fill=\"none\" stroke=\"#a87152\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><ellipse cx=\"123\" cy=\"168\" rx=\"8\" ry=\"13\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"177\" cy=\"166\" rx=\"8\" ry=\"12\" fill=\"#dfa67b\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M123 147Q143 125 174 145L179 177 165 198 139 198 121 176Z\" fill=\"#edbc8a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M122 172Q136 184 148 177Q165 186 179 169L173 198 163 208 151 230 136 212 125 211Z\" fill=\"#e7d0a8\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M133 190l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M143 190l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M157 190l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M168 190l-2 18\" fill=\"none\" stroke=\"#b9a68d\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M129 159q7-6 13-2M157 157q7-5 13-1\" fill=\"none\" stroke=\"#e7d0a8\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"137\" cy=\"165\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"164\" cy=\"164\" rx=\"2.4\" ry=\"3\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/><path d=\"M151 161l-7 15q1 8 14 3\" fill=\"none\" stroke=\"#9c6b50\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M132 183q10-10 19-1q11-9 21-4\" fill=\"none\" stroke=\"#e7d0a8\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M142 189q10 7 20-2\" fill=\"none\" stroke=\"#755341\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M114 142Q123 94 157 77Q182 62 169 32Q201 52 186 79L180 142Z\" fill=\"#a36f3c\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M169 41q22 31 8 52L171 137\" fill=\"none\" stroke=\"#d78056\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M113 139Q148 130 181 139L181 152Q148 144 113 152Z\" fill=\"#a97746\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M132 189q18 9 34-2\" fill=\"none\" stroke=\"#6f493d\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"rock-bed": "<path d=\"M0 0H106L122 34 89 69 49 59 30 89 0 78Z\" fill=\"#b9cbd0\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M109 0H216L211 39 170 67 124 34Z\" fill=\"#8faab4\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M217 0H300V92L267 73 242 93 210 40Z\" fill=\"#b9cbd0\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 80 32 91 50 136 31 178 0 192Z\" fill=\"#799ba8\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M52 62 89 70 118 122 104 159 55 166 50 135Z\" fill=\"#a9c1c7\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M268 75 300 93V192L274 177 249 142Z\" fill=\"#7596a2\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 268 41 260 69 307 48 344 0 336Z\" fill=\"#b9cdd0\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 338 49 347 77 395 63 440H0Z\" fill=\"#819fac\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M69 311 105 303 123 351 96 389 77 393 49 345Z\" fill=\"#9eb9c1\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M199 303 241 294 269 342 245 387 203 378 181 345Z\" fill=\"#a9c2c8\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M272 264 300 276V372L269 345 243 295Z\" fill=\"#7596a2\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M99 390 139 382 169 411 154 440H65L77 395Z\" fill=\"#b6ccd0\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M247 389 271 344 300 374V440H219L206 414Z\" fill=\"#93b0ba\" stroke=\"#39464b\" stroke-width=\"2.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M18 16 38 31 47 58M75 6 68 27 89 49M147 16 158 37 148 51M272 5 259 31 276 50M11 116 21 129 14 157M288 117 278 138 287 159M13 290 28 307 20 326M83 333 88 349 77 366M225 325 216 344 229 360M275 392 261 406 271 425M113 414 134 424\" fill=\"none\" stroke=\"#587887\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"icon-cart": "<g transform=\"translate(50 50) scale(1.5)\"><ellipse cx=\"0\" cy=\"0\" rx=\"29\" ry=\"29\" fill=\"#f1eee1\" stroke=\"#5f9473\" stroke-width=\"3\"/><path d=\"M-19-12-14 10 12 10 20-12Z\" fill=\"#47534e\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-12-10-8 5M-3-10-1 5M7-10 5 5\" fill=\"none\" stroke=\"#ebe8d8\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"-9\" cy=\"17\" rx=\"4\" ry=\"4\" fill=\"#47534e\" stroke=\"none\" stroke-width=\"2\"/><ellipse cx=\"10\" cy=\"17\" rx=\"4\" ry=\"4\" fill=\"#47534e\" stroke=\"none\" stroke-width=\"2\"/></g>",
	"icon-lamp": "<g transform=\"translate(50 50) scale(1.5)\"><ellipse cx=\"0\" cy=\"0\" rx=\"29\" ry=\"29\" fill=\"#f1eee1\" stroke=\"#5f9473\" stroke-width=\"3\"/><path d=\"M-12-12H12L10 17H-10Z\" fill=\"#47534e\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-7-12V-18Q0-25 7-18V-12\" fill=\"none\" stroke=\"#47534e\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-5-5H5L3 10H-3Z\" fill=\"#eae6d2\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-pick": "<g transform=\"translate(50 50) scale(1.5)\"><ellipse cx=\"0\" cy=\"0\" rx=\"29\" ry=\"29\" fill=\"#f1eee1\" stroke=\"#5f9473\" stroke-width=\"3\"/><path d=\"M-13 19 9-13\" fill=\"none\" stroke=\"#47534e\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-17-5Q0-25 21-9L4-12-3-2-6-9Z\" fill=\"#47534e\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-map": "<g transform=\"translate(50 50) scale(1.5)\"><ellipse cx=\"0\" cy=\"0\" rx=\"29\" ry=\"29\" fill=\"#f1eee1\" stroke=\"#5f9473\" stroke-width=\"3\"/><path d=\"M-18-10-7-15 6-9 18-14V13L6 18-7 12-18 17Z\" fill=\"none\" stroke=\"#4f5f57\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-7-15V12M6-9V18\" fill=\"none\" stroke=\"#4f5f57\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-gold": "<g transform=\"translate(50 50) scale(.83)\"><path d=\"M-39 15-26-20-1-33 23-23 39 7 24 29-16 34Z\" fill=\"#e6ad3e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-26-20-8 5 23-23M-8 5l-8 29M-8 5 24 29 39 7M-1-33-8 5\" fill=\"none\" stroke=\"#a97433\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-22-18-14-4 0-20Z\" fill=\"#ffe09a\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-sack": "<g transform=\"translate(50 50) scale(.83)\"><path d=\"M-21-37-8-32 12-38 23-33 12-18Q46 7 35 36Q21 52-15 43Q-43 36-35 11L-14-17Z\" fill=\"#bd9456\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-15-18 13-19M-22 8Q-28 25-18 32M12-14 23 14\" fill=\"none\" stroke=\"#e0bd7d\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"18\" cy=\"27\" rx=\"14\" ry=\"10\" fill=\"#e6b64e\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M10 26 17 20 26 24 21 33Z\" fill=\"#f2d581\" stroke=\"#39464b\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-rock": "<g transform=\"translate(50 50) scale(.83)\"><path d=\"M-41 14-32-22-2-38 31-20 44 18 17 35-21 33Z\" fill=\"#869ea5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-32-22-10 3 31-20M-10 3l-11 30M-10 3 17 35 44 18\" fill=\"none\" stroke=\"#4f6973\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-crystal": "<g transform=\"translate(50 50) scale(.83)\"><path d=\"M-8-37 7-48 20-23 11 31-9 40-20 14Z\" fill=\"#bcdce1\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-8-37 1-17-9 40M1-17 20-23M1-17l10 48\" fill=\"none\" stroke=\"#628f9b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-21-6-34-15-42 3-20 31-9 40Z\" fill=\"#86b8c4\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M18-3 33-10 44 8 11 31Z\" fill=\"#e1ebdf\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-spider": "<g transform=\"translate(50 50) scale(.83)\"><path d=\"M-12 -17Q-35 -29 -42 -43L-53 -36\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-12 -5Q-35 -17 -42 -22L-53 -15\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-12 8Q-35 -4 -42 18L-53 25\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-12 19Q-35 7 -42 44L-53 51\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 -17Q35 -29 42 -43L53 -36\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 -5Q35 -17 42 -22L53 -15\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 8Q35 -4 42 18L53 25\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M12 19Q35 7 42 44L53 51\" fill=\"none\" stroke=\"#384a40\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"0\" cy=\"8\" rx=\"19\" ry=\"29\" fill=\"#455b43\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"0\" cy=\"-22\" rx=\"15\" ry=\"13\" fill=\"#758657\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M-13 0 0-11 13 0 6 15-7 17Z\" fill=\"#c8c688\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"-6\" cy=\"-24\" rx=\"3.5\" ry=\"4\" fill=\"#f1d890\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"6\" cy=\"-24\" rx=\"3.5\" ry=\"4\" fill=\"#f1d890\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"-6\" cy=\"-24\" rx=\"1.5\" ry=\"2\" fill=\"#39464b\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"6\" cy=\"-24\" rx=\"1.5\" ry=\"2\" fill=\"#39464b\" stroke=\"#39464b\" stroke-width=\"2\"/></g>",
	"icon-dragon": "<g transform=\"translate(50 50) scale(.83)\"><path d=\"M-7 3Q-43-25-31-51L-11-29 1-51 16-18 34-21 25 5Z\" fill=\"#96a36d\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-24-35-14-12 1-30 12-6\" fill=\"none\" stroke=\"#596e49\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4-16Q37-41 44-10Q44 12 16 17Q-10 21-17 39Q-23 54-42 41Q-25 60 3 39Q12 29 31 30Q60 21 56-10Q53-42 24-42Q-3-44-14-24Z\" fill=\"#7eaa59\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M28-40 37-26 51-24M43-18 54-12M47 1l9 7M34 15l9 12\" fill=\"none\" stroke=\"#c64d39\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-13-27-29-20-34-6-15 1 1-11Z\" fill=\"#94b66b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"-22\" cy=\"-17\" rx=\"3\" ry=\"3\" fill=\"#e4c36e\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"-22\" cy=\"-17\" rx=\"1.3\" ry=\"2\" fill=\"#39464b\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M-32-7-16-8M-31-3l-5 7\" fill=\"none\" stroke=\"#454c39\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-chest": "<g transform=\"translate(50 50) scale(.83)\"><path d=\"M-42-5Q-43-41 0-41T42-5V38H-42Z\" fill=\"#9a613a\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-42-5H42M-27-32V37M27-32V37\" fill=\"none\" stroke=\"#c7a45d\" stroke-width=\"8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-38 11H38M-38 26H38\" fill=\"none\" stroke=\"#613f30\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><rect x=\"-9\" y=\"-10\" width=\"18\" height=\"27\" rx=\"2\" fill=\"#e0bb6f\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"0\" cy=\"2\" rx=\"3\" ry=\"4\" fill=\"#39464b\" stroke=\"none\" stroke-width=\"2\"/></g>",
	"icon-ladder": "<path d=\"M27 10 32 90M68 10 73 90\" fill=\"none\" stroke=\"#6f5238\" stroke-width=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M29 24h40M30 42h40M31 60h40M32 78h40\" fill=\"none\" stroke=\"#d1a36b\" stroke-width=\"8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"icon-rockfall": "<g transform=\"translate(50 50) scale(.83)\"><path d=\"M-41 14-32-22-2-38 31-20 44 18 17 35-21 33Z\" fill=\"#869ea5\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-32-22-10 3 31-20M-10 3l-11 30M-10 3 17 35 44 18\" fill=\"none\" stroke=\"#4f6973\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-inspect": "<path d=\"M7 50Q49 3 93 50Q50 95 7 50Z\" fill=\"#e7e5ce\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"50\" cy=\"50\" rx=\"17\" ry=\"20\" fill=\"#718d7d\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"50\" cy=\"50\" rx=\"7\" ry=\"11\" fill=\"#384b43\" stroke=\"none\" stroke-width=\"2\"/>",
	"icon-reverse": "<g transform=\"translate(50 31) rotate(0)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(50 72) rotate(180)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-trap": "<rect x=\"17\" y=\"11\" width=\"66\" height=\"78\" rx=\"8\" fill=\"#e6e6d4\" stroke=\"#b45143\" stroke-width=\"5\"/><path d=\"M30 23V77M50 23V77M70 23V77M22 39H78M22 66H78\" fill=\"none\" stroke=\"#485d53\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"icon-freedom": "<rect x=\"17\" y=\"11\" width=\"66\" height=\"78\" rx=\"8\" fill=\"#e6e6d4\" stroke=\"#68936d\" stroke-width=\"5\"/><path d=\"M29 21 64 32V82L29 73Z\" fill=\"#80967b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M38 29V72M53 33V76\" fill=\"none\" stroke=\"#e6e6d4\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"icon-theft": "<ellipse cx=\"65\" cy=\"35\" rx=\"23\" ry=\"20\" fill=\"#dbb355\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M12 65 32 44 48 45 42 60 70 54 80 62 47 84H12Z\" fill=\"#d7b78e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"icon-handsOff": "<ellipse cx=\"65\" cy=\"35\" rx=\"23\" ry=\"20\" fill=\"#dbb355\" stroke=\"#39464b\" stroke-width=\"2\"/><path d=\"M12 65 32 44 48 45 42 60 70 54 80 62 47 84H12Z\" fill=\"#d7b78e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M15 85 85 15\" fill=\"none\" stroke=\"#b45143\" stroke-width=\"8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />",
	"icon-hats": "<g transform=\"translate(-49 -10) scale(.67)\"><path d=\"M114 142Q123 94 157 77Q182 62 169 32Q201 52 186 79L180 142Z\" fill=\"#b74d3b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M169 41q22 31 8 52L171 137\" fill=\"none\" stroke=\"#d78056\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M113 139Q148 130 181 139L181 152Q148 144 113 152Z\" fill=\"#a97746\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-hands": "<rect x=\"12\" y=\"15\" width=\"30\" height=\"47\" rx=\"3\" fill=\"#a86b50\" stroke=\"#39464b\" stroke-width=\"2\"/><rect x=\"58\" y=\"39\" width=\"30\" height=\"47\" rx=\"3\" fill=\"#d7d8c3\" stroke=\"#39464b\" stroke-width=\"2\"/><g transform=\"translate(65 20) rotate(0)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(34 81) rotate(180)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-goals": "<g transform=\"translate(0 -10) scale(.32)\"><g transform=\"translate(78 276) rotate(-8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(222 276) rotate(8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(152 176) rotate(0)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(150 360) rotate(180)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g>",
	"icon-trove": "<g transform=\"translate(0 -10) scale(.32)\"><g transform=\"translate(90 268) rotate(-6)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(102 257) rotate(-6)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(114 246) rotate(-6)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(126 235) rotate(-6)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(138 224) rotate(-6)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(227 311) rotate(10)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#ecdfbb\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(190 229) rotate(30)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#be5948\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g>",
	"icon-veto": "<g transform=\"translate(0 -10) scale(.32)\"><g transform=\"translate(150 277) rotate(-8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#ecdfbb\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M74 356 229 196\" fill=\"none\" stroke=\"#b84f42\" stroke-width=\"17\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M94 194 208 356\" fill=\"none\" stroke=\"#b84f42\" stroke-width=\"17\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g>",
	"icon-master": "<g transform=\"translate(0 -10) scale(.32)\"><g transform=\"translate(-7 92) scale(.65)\"><path d=\"M53 223 91 176 168 163 248 191 234 244 103 271Z\" fill=\"#d5d9ca\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M77 209 84 185 107 177 123 191 117 212Z\" fill=\"#a9b8b4\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M118 195 137 169 163 171 181 191 161 214Z\" fill=\"#e0dec9\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M170 192 182 176 205 184 214 208 193 218Z\" fill=\"#b4c0b8\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M207 206 218 188 239 194 246 212 225 225Z\" fill=\"#8ca4a5\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M94 224 114 209 143 215 152 236 115 246Z\" fill=\"#b9c6bd\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M154 226 168 207 188 213 196 232 178 245Z\" fill=\"#d9ddcc\" stroke=\"#39464b\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M106 193 119 186 130 193 125 206 110 207Z\" fill=\"#e7b657\" stroke=\"#39464b\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M187 205 198 198 210 205 207 217 192 216Z\" fill=\"#e7b657\" stroke=\"#39464b\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M48 227 103 249 243 217 246 235 103 272 49 246Z\" fill=\"#b67b43\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M52 246 103 270 231 239 213 329 103 364 69 340Z\" fill=\"#aa6536\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M103 270 231 239 213 329 103 364Z\" fill=\"#ce8743\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M70 277 103 292 226 262M75 305 103 319 220 289M82 333 103 344 214 315\" fill=\"none\" stroke=\"#6f4b34\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M111 279 207 255M112 306 203 284M116 333 197 312\" fill=\"none\" stroke=\"#e1a463\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M86 259 96 263 107 353 98 357Z\" fill=\"#5f6b69\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M200 246 210 244 190 336 180 339Z\" fill=\"#5f6b69\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"92\" cy=\"277\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"99\" cy=\"331\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"201\" cy=\"264\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><ellipse cx=\"186\" cy=\"320\" rx=\"2.3\" ry=\"2.4\" fill=\"#c2c6b6\" stroke=\"#39464b\" stroke-width=\"1\"/><path d=\"M86 343 207 311 209 322 88 358Z\" fill=\"#665240\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><ellipse cx=\"101\" cy=\"354\" rx=\"24\" ry=\"32\" fill=\"#795a3a\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"98\" cy=\"353\" rx=\"15\" ry=\"24\" fill=\"#b08045\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"98\" cy=\"353\" rx=\"4\" ry=\"6\" fill=\"#e3c687\" stroke=\"#39464b\" stroke-width=\"1.4\"/><ellipse cx=\"201\" cy=\"329\" rx=\"21\" ry=\"29\" fill=\"#70573c\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"198\" cy=\"328\" rx=\"13\" ry=\"21\" fill=\"#b08045\" stroke=\"#39464b\" stroke-width=\"2\"/><ellipse cx=\"198\" cy=\"328\" rx=\"4\" ry=\"6\" fill=\"#e3c687\" stroke=\"#39464b\" stroke-width=\"1.4\"/><path d=\"M97 332 99 346M86 348 92 350M105 367 101 360M198 309 199 321M189 324 193 327M204 342 201 335\" fill=\"none\" stroke=\"#654c36\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(146 2) scale(.54)\"><path d=\"M127 199C126 176 129 141 145 141C160 139 169 171 174 197\" fill=\"none\" stroke=\"#556c62\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M130 196C130 176 133 147 145 146C157 145 165 174 170 196\" fill=\"none\" stroke=\"#cad3b6\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M96 216 151 195 209 210 154 231Z\" fill=\"#96b09b\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M96 216 154 231 209 210 207 221 154 243 98 228Z\" fill=\"#638978\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M104 233 153 248 199 231 196 339 153 359 110 344Z\" fill=\"#e8d896\" stroke=\"#728c77\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M112 241 147 252 147 347 117 337Z\" fill=\"#f6e9b7\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M161 251 190 240 188 332 161 345Z\" fill=\"#ddca7e\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M124 245 124 337M178 245 176 339\" fill=\"none\" stroke=\"#fff0c8\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(-12 0)\"><path d=\"M140 331 141 282 146 285 151 280 158 283 158 332Z\" fill=\"#e2ad42\" stroke=\"#39464b\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M148 284Q138 274 149 260Q157 273 151 283Z\" fill=\"#ecbb4c\" stroke=\"#aa7c32\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M149 280Q145 274 150 268Q153 275 149 280Z\" fill=\"#fff3c1\" stroke=\"none\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M105 231 113 234 118 344 110 346Z\" fill=\"#789b83\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M150 244 157 243 158 355 150 358Z\" fill=\"#8da57e\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M193 230 201 227 198 341 191 344Z\" fill=\"#789b83\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M109 341 153 356 198 339 203 349 153 370 106 354Z\" fill=\"#9fb398\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M107 354 153 369 204 349 202 359 153 379 108 365Z\" fill=\"#5d8271\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M111 357 153 371 199 353\" fill=\"none\" stroke=\"#d2d8b3\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(50 -45) scale(.85)\"><path d=\"M88 352 173 214 184 220 101 359Z\" fill=\"#ac7a42\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M96 348 177 219\" fill=\"none\" stroke=\"#ddb577\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M104 217Q159 172 219 220L182 208 175 227 162 224 159 207Z\" fill=\"#aebfc0\" stroke=\"#39464b\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M109 213Q161 183 214 216\" fill=\"none\" stroke=\"#dde1d3\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g>",
	"icon-pathfinder": "<g transform=\"translate(0 -10) scale(.32)\"><g transform=\"translate(89 279) rotate(-8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(211 279) rotate(8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M90 241V309M211 240V308\" fill=\"none\" stroke=\"#eee2c4\" stroke-width=\"20\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><g transform=\"translate(151 180) rotate(0)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g>",
	"icon-diversion": "<g transform=\"translate(0 -10) scale(.32)\"><rect x=\"52\" y=\"256\" width=\"70\" height=\"109\" rx=\"4\" fill=\"none\" stroke=\"#d9dfd2\" stroke-width=\"3\"/><g transform=\"translate(218 203) rotate(8)\"><rect x=\"-31\" y=\"-47\" width=\"62\" height=\"94\" rx=\"4\" fill=\"#71888b\" stroke=\"#e1d9bc\" stroke-width=\"3\"/><path d=\"M-17-24 18 25M17-24-18 25\" fill=\"none\" stroke=\"#d5cdb0\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(150 260) rotate(-48)\"><path d=\"M-30-8H8V-22L35 0 8 22V8H-30Z\" fill=\"#77a576\" stroke=\"#39464b\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></g>"
};
//#endregion
//#region src/games/saboteur20/art.tsx
function q({ name: e }) {
	return /* @__PURE__ */ g("g", { dangerouslySetInnerHTML: { __html: He[e] ?? "" } });
}
function Ue() {
	return /* @__PURE__ */ g("rect", {
		x: "3",
		y: "3",
		width: "294",
		height: "434",
		rx: "10",
		fill: "none",
		stroke: "#ddd6c5",
		strokeWidth: "5"
	});
}
function J({ kind: e, size: t = 30 }) {
	return /* @__PURE__ */ g("svg", {
		width: t,
		height: t,
		viewBox: "0 0 100 100",
		"aria-hidden": !0,
		children: /* @__PURE__ */ g(q, { name: `icon-${e}` })
	});
}
function We({ kind: e, broken: t = !1, x: n = 52 }) {
	return /* @__PURE__ */ _("g", {
		transform: `translate(${n - 30} 18) scale(.6)`,
		children: [
			/* @__PURE__ */ g("circle", {
				cx: "50",
				cy: "50",
				r: "46",
				fill: "#f1eee1",
				stroke: t ? "#b34c42" : "#5f9473",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g(q, { name: `icon-${e}` }),
			t && /* @__PURE__ */ g("path", {
				d: "M18 82 82 18",
				stroke: "#b34c42",
				strokeWidth: "8"
			})
		]
	});
}
function Y({ goal: e = !1, style: t, className: n = "" }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 300 440",
		className: n,
		style: t,
		"aria-hidden": !0,
		children: /* @__PURE__ */ g(q, { name: e ? "goal-back" : "deck-back" })
	});
}
function Ge({ role: e, damaged: t = !1 }) {
	let n = e === "green" ? He.miner.replaceAll("#576c95", "#5c894b").replaceAll("#405478", "#3f663c").replaceAll("#60779e", "#7a9d58").replaceAll("#526582", "#56754a").replaceAll("#8c9fb9", "#a1b583").replaceAll("#8e9fb8", "#a3b889") : He[e === "blue" || e === "green" ? "miner" : e];
	return /* @__PURE__ */ _("svg", {
		viewBox: "0 0 300 440",
		className: "sab20-role-art",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ g(q, { name: "cave" }),
			/* @__PURE__ */ g("g", { dangerouslySetInnerHTML: { __html: n } }),
			/* @__PURE__ */ g(Ue, {}),
			t && /* @__PURE__ */ _("g", {
				transform: "translate(219 355)",
				children: [/* @__PURE__ */ g("circle", {
					r: "38",
					fill: "#f1e8d3",
					stroke: "#b34c42",
					strokeWidth: "4"
				}), /* @__PURE__ */ g("path", {
					d: "M-21-21 21 21M21-21-21 21",
					stroke: "#b34c42",
					strokeWidth: "7"
				})]
			})
		]
	});
}
var X = [
	[150, -18],
	[318, 220],
	[150, 458],
	[-18, 220]
], Ke = [
	[150, 109],
	[255, 220],
	[150, 331],
	[45, 220]
];
function qe(e) {
	if (e.length === 1) {
		let t = X[e[0]], n = Ke[e[0]];
		return `M${t[0]} ${t[1]}L${n[0]} ${n[1]}`;
	}
	if (e.length === 2) {
		if (e.includes(0) && e.includes(2)) return "M150-18C150 65 157 115 148 195S146 354 150 458";
		if (e.includes(1) && e.includes(3)) return "M-18 220C44 220 81 226 143 217S252 216 318 220";
		let [t, n] = e.map((e) => X[e]);
		return `M${t[0]} ${t[1]}Q150 220 ${n[0]} ${n[1]}`;
	}
	return e.map((e) => `M150 220Q${(X[e][0] + 150) / 2} ${(X[e][1] + 220) / 2} ${X[e][0]} ${X[e][1]}`).join(" ");
}
function Je() {
	return /* @__PURE__ */ _("g", {
		transform: "translate(176 55) rotate(39)",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M0 0V105M41 0V105",
				stroke: "#654e36",
				strokeWidth: "10"
			}),
			/* @__PURE__ */ g("path", {
				d: "M0 0V105M41 0V105",
				stroke: "#bd834d",
				strokeWidth: "6"
			}),
			[
				14,
				33,
				52,
				71,
				90
			].map((e) => /* @__PURE__ */ g("path", {
				d: `M1 ${e}H40`,
				stroke: "#e3b36f",
				strokeWidth: "7"
			}, e))
		]
	});
}
function Ye({ groups: e, ladder: t, door: n, crystal: r = 0, hidden: i, goal: a, goalValue: o = 0, chest: s, postcard: c, start: l = !1, party: u = !1 }) {
	let d = e.some((e) => e.length === 2 && e.includes(0) && e.includes(2)) && e.some((e) => e.length === 2 && e.includes(1) && e.includes(3));
	return /* @__PURE__ */ g("svg", {
		width: "78",
		height: "112",
		viewBox: "0 0 300 440",
		preserveAspectRatio: "none",
		overflow: "hidden",
		"aria-hidden": !0,
		children: i ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(q, { name: "goal-back" }), s && /* @__PURE__ */ g("g", {
			transform: "translate(150 220) scale(1.9)",
			children: /* @__PURE__ */ g(q, { name: "object-chest" })
		})] }) : /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("rect", {
				width: "300",
				height: "440",
				fill: "#9fb7bd"
			}),
			/* @__PURE__ */ g(q, { name: "rock-bed" }),
			e.map((e, t) => /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("path", {
				d: qe(e),
				fill: "none",
				stroke: "#5e7378",
				strokeWidth: "91",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}), /* @__PURE__ */ g("path", {
				d: qe(e),
				fill: "none",
				stroke: "#f3e6ca",
				strokeWidth: "84",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			})] }, t)),
			d && /* @__PURE__ */ _("g", { children: [
				/* @__PURE__ */ g("path", {
					d: "M104 171H196V268H104Z",
					fill: "#9a6a42",
					stroke: "#5c5847",
					strokeWidth: "3"
				}),
				[
					180,
					200,
					220,
					240,
					260
				].map((e) => /* @__PURE__ */ g("path", {
					d: `M105 ${e}H195`,
					stroke: "#d4aa6d",
					strokeWidth: "9"
				}, e)),
				/* @__PURE__ */ g("path", {
					d: "M104 170V269M196 170V269",
					stroke: "#6b5439",
					strokeWidth: "7"
				})
			] }),
			n && /* @__PURE__ */ _("g", {
				transform: "translate(150 220) rotate(12)",
				children: [
					/* @__PURE__ */ g("path", {
						d: "M-47-65Q0-96 47-65V65Q0 84-47 65Z",
						fill: n === "blue" ? "#5c80a5" : "#7f9e49",
						stroke: "#435863",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ g("path", {
						d: "M-25-73V74M0-80V78M25-73V74",
						stroke: n === "blue" ? "#3e5d82" : "#587336",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ g("path", {
						d: "M-43-43H43M-43 42H43",
						stroke: "#c1b17a",
						strokeWidth: "8"
					}),
					/* @__PURE__ */ g("circle", {
						cx: "27",
						cy: "7",
						r: "6",
						fill: "#e1c482",
						stroke: "#6a6745",
						strokeWidth: "2"
					})
				]
			}),
			(t || l) && /* @__PURE__ */ g(Je, {}),
			r > 0 && /* @__PURE__ */ g("g", {
				transform: "translate(229 132) rotate(-22) scale(.8)",
				children: /* @__PURE__ */ g(q, { name: "object-crystal" })
			}),
			a && /* @__PURE__ */ g("g", {
				transform: `translate(150 ${a === "dragon" || a === "spider" ? 216 : 247}) scale(${a === "dragon" ? 1.8 : a === "spider" ? 1.35 : 1.1})`,
				children: /* @__PURE__ */ g(q, { name: `object-${a}` })
			}),
			o !== 0 && /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("rect", {
				x: "174",
				y: "22",
				width: "104",
				height: "52",
				rx: "6",
				fill: "#f0e5c8",
				stroke: "#805332",
				strokeWidth: "2"
			}), /* @__PURE__ */ _("text", {
				x: "226",
				y: "61",
				textAnchor: "middle",
				fontSize: "42",
				fontWeight: "700",
				fill: "#493723",
				children: [o > 0 ? "+" : "", o]
			})] }),
			s && /* @__PURE__ */ g("g", {
				transform: "translate(38 402) scale(.5)",
				children: /* @__PURE__ */ g(q, { name: "object-chest" })
			}),
			c && /* @__PURE__ */ g("g", {
				opacity: ".98",
				children: /* @__PURE__ */ g(q, { name: u ? "party" : "costume" })
			}),
			/* @__PURE__ */ g("rect", {
				x: "1",
				y: "1",
				width: "298",
				height: "438",
				rx: "5",
				fill: "none",
				stroke: "#d2d8cc",
				strokeWidth: "2"
			})
		] })
	});
}
function Xe({ tile: e }) {
	return /* @__PURE__ */ g(Ye, {
		groups: e.groups,
		hidden: !e.revealed,
		chest: e.kind === "chest",
		ladder: e.ladder,
		start: e.kind === "start",
		door: e.door,
		crystal: e.crystal,
		goal: e.kind === "goal" && e.goal !== null ? D[e.goal].kind : void 0,
		goalValue: e.goal === null ? 0 : D[e.goal].gold,
		postcard: e.kind === "postcard",
		party: e.kind === "postcard" && e.y === 2
	});
}
function Ze({ id: e, flip: t = !1 }) {
	let n = A(e);
	return n.kind === "path" ? /* @__PURE__ */ g(Ye, {
		groups: k(n.groups, t),
		ladder: n.ladder,
		door: n.door,
		crystal: n.crystal
	}) : /* @__PURE__ */ _("svg", {
		width: "78",
		height: "112",
		viewBox: "0 0 300 440",
		preserveAspectRatio: "none",
		overflow: "hidden",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ g(q, { name: "cave" }),
			n.tools.length ? n.tools.map((e, t) => /* @__PURE__ */ g("g", {
				transform: n.tools.length > 1 ? `translate(${t * 120 - 15} ${t === 0 ? 28 : 90}) scale(.66)` : void 0,
				children: /* @__PURE__ */ g(q, { name: `${e}${n.kind === "break" ? "-broken" : ""}` })
			}, e)) : /* @__PURE__ */ g(q, { name: n.kind }),
			/* @__PURE__ */ g(Ue, {}),
			[52, 248].map((e) => /* @__PURE__ */ g(We, {
				x: e,
				kind: n.tools[0] ?? n.kind,
				broken: n.kind === "break" || n.kind === "handsOff" || n.kind === "veto"
			}, e)),
			n.tools.length > 1 && /* @__PURE__ */ g("g", {
				transform: "translate(150 48) scale(.6)",
				children: /* @__PURE__ */ g(q, { name: `icon-${n.tools[1]}` })
			}),
			n.kind === "trove" && /* @__PURE__ */ _("g", {
				fill: "#f3e8d0",
				stroke: "#39464b",
				strokeWidth: "1",
				children: [/* @__PURE__ */ g("text", {
					x: "83",
					y: "290",
					fontSize: "58",
					textAnchor: "middle",
					children: "5"
				}), /* @__PURE__ */ g("text", {
					x: "224",
					y: "333",
					fontSize: "58",
					fill: "#39464b",
					stroke: "none",
					textAnchor: "middle",
					children: "1"
				})]
			}),
			n.kind === "pathfinder" && /* @__PURE__ */ g("text", {
				x: "150",
				y: "182",
				fontSize: "47",
				textAnchor: "middle",
				fill: "#f3e8d0",
				children: "2"
			})
		]
	});
}
function Qe({ id: e, flip: t = !1, label: n, style: r }) {
	return /* @__PURE__ */ _("div", {
		className: "sab20-card",
		style: r,
		children: [/* @__PURE__ */ g(Ze, {
			id: e,
			flip: t
		}), n && /* @__PURE__ */ g("span", {
			className: "sab20-card-name",
			children: n
		})]
	});
}
function $e() {
	return /* @__PURE__ */ g("svg", {
		width: "44",
		height: "66",
		viewBox: "0 0 300 440",
		"aria-hidden": !0,
		children: /* @__PURE__ */ g(q, { name: "toll" })
	});
}
function et({ tool: e, broken: t = !1 }) {
	return /* @__PURE__ */ _("span", {
		className: `sab20-tool${t ? " sab20-tool-broken" : ""}`,
		children: [/* @__PURE__ */ g(J, {
			kind: e,
			size: 24
		}), t && /* @__PURE__ */ g("svg", {
			viewBox: "0 0 28 28",
			"aria-hidden": !0,
			children: /* @__PURE__ */ g("path", {
				d: "M5 23 23 5",
				stroke: "#b34c42",
				strokeWidth: "3"
			})
		})]
	});
}
//#endregion
//#region src/games/saboteur20/labels.ts
var tt = {
	miner: "games.saboteur20.roles.miner",
	saboteur: "games.saboteur20.roles.saboteur",
	blue: "games.saboteur20.roles.blue",
	green: "games.saboteur20.roles.green",
	boss: "games.saboteur20.roles.boss",
	profiteer: "games.saboteur20.roles.profiteer",
	geologist: "games.saboteur20.roles.geologist",
	greedy: "games.saboteur20.roles.greedy"
}, nt = {
	cart: "games.saboteur20.toolCart",
	lamp: "games.saboteur20.toolLamp",
	pick: "games.saboteur20.toolPick",
	trap: "games.saboteur20.trap",
	theft: "games.saboteur20.theft"
}, rt = {
	path: "games.saboteur20.cards.path",
	break: "games.saboteur20.cards.break",
	repair: "games.saboteur20.cards.repair",
	rockfall: "games.saboteur20.cards.rockfall",
	map: "games.saboteur20.cards.map",
	theft: "games.saboteur20.cards.theft",
	handsOff: "games.saboteur20.cards.handsOff",
	trap: "games.saboteur20.cards.trap",
	freedom: "games.saboteur20.cards.freedom",
	inspect: "games.saboteur20.cards.inspect",
	hats: "games.saboteur20.cards.hats",
	hands: "games.saboteur20.cards.hands",
	goals: "games.saboteur20.cards.goals",
	trove: "games.saboteur20.cards.trove",
	veto: "games.saboteur20.cards.veto",
	reverse: "games.saboteur20.cards.reverse",
	master: "games.saboteur20.cards.master",
	pathfinder: "games.saboteur20.cards.pathfinder",
	diversion: "games.saboteur20.cards.diversion"
}, it = {
	path: "games.saboteur20.help.path",
	break: "games.saboteur20.help.break",
	repair: "games.saboteur20.help.repair",
	rockfall: "games.saboteur20.help.rockfall",
	map: "games.saboteur20.help.map",
	theft: "games.saboteur20.help.theft",
	handsOff: "games.saboteur20.help.handsOff",
	trap: "games.saboteur20.help.trap",
	freedom: "games.saboteur20.help.freedom",
	inspect: "games.saboteur20.help.inspect",
	hats: "games.saboteur20.help.hats",
	hands: "games.saboteur20.help.hands",
	goals: "games.saboteur20.help.goals",
	trove: "games.saboteur20.help.trove",
	veto: "games.saboteur20.help.veto",
	reverse: "games.saboteur20.help.reverse",
	master: "games.saboteur20.help.master",
	pathfinder: "games.saboteur20.help.pathfinder",
	diversion: "games.saboteur20.help.diversion"
}, at = {
	gold: "games.saboteur20.goals.gold",
	rock: "games.saboteur20.goals.rock",
	spider: "games.saboteur20.goals.spider",
	sack: "games.saboteur20.goals.sack",
	dragon: "games.saboteur20.goals.dragon"
};
function ot(e, t) {
	let n = D[e];
	return n.kind === "sack" ? t("games.saboteur20.goals.sackValue", { n: n.gold }) : t(at[n.kind]);
}
var st = {
	stealCard: "games.saboteur20.chestEffects.stealCard",
	extra: "games.saboteur20.chestEffects.extra",
	gold: "games.saboteur20.chestEffects.gold",
	skip: "games.saboteur20.chestEffects.skip",
	burn: "games.saboteur20.chestEffects.burn",
	inspect: "games.saboteur20.chestEffects.inspect",
	discard: "games.saboteur20.chestEffects.discard",
	noMap: "games.saboteur20.chestEffects.noMap",
	draw: "games.saboteur20.chestEffects.draw",
	moveGoal: "games.saboteur20.chestEffects.moveGoal"
};
function ct(e, t) {
	let n = A(e);
	return t(rt[n.kind]) + (n.tools.length ? ` · ${n.tools.map((e) => t(nt[e])).join(" / ")}` : "");
}
function lt(e, t, n, r) {
	let i = e.card === void 0 ? n(e.type === "toll" ? "games.saboteur20.tollAction" : e.type === "escape" ? "games.saboteur20.escape" : "games.saboteur20.confirm") : ct(e.card, n);
	if (e.type === "react") return n(e.yes ? "games.saboteur20.vetoAction" : "games.saboteur20.passReaction");
	if (e.type === "next") return n("games.saboteur20.next");
	if (e.type === "choose" && t.choice?.kind === "pay") return n(e.yes ? "games.saboteur20.yes" : "games.saboteur20.no");
	if (e.goal !== void 0) return n("games.saboteur20.swapGoals", {
		a: e.goal + 1,
		b: (e.goal2 ?? 0) + 1,
		choice: n(e.yes ? "games.saboteur20.swap" : "games.saboteur20.keep")
	});
	if (e.target) return n("games.saboteur20.targetAction", {
		action: e.tool ? n(nt[e.tool]) : i,
		name: r(e.target)
	});
	if (e.tile) {
		let r = t.tiles.find((t) => t.key === e.tile);
		return n("games.saboteur20.actionAt", {
			name: i,
			x: r?.x ?? 0,
			y: r?.y ?? 0
		});
	}
	return e.x === void 0 ? e.type === "choose" && e.yes === !1 ? n(t.choice?.kind === "theft" ? "games.saboteur20.noTheft" : "games.saboteur20.skip") : e.tool ? n(nt[e.tool]) : i : n("games.saboteur20.actionAt", {
		name: i,
		x: e.x,
		y: e.y ?? 0
	});
}
//#endregion
//#region src/games/saboteur20/board.tsx
var Z = {
	w: 80,
	h: 114,
	ox: 128,
	oy: 356
};
function Q(e, t) {
	return {
		x: Z.ox + e * Z.w,
		y: Z.oy + t * Z.h,
		w: 78,
		h: 112
	};
}
function ut(e) {
	let t = e.map((e) => Q(e.x, e.y)), n = Math.min(...t.map((e) => e.x)) - 42, r = Math.min(...t.map((e) => e.y)) - 36;
	return {
		x: n,
		y: r,
		w: Math.max(...t.map((e) => e.x + e.w)) - n + 42,
		h: Math.max(...t.map((e) => e.y + e.h)) - r + 44
	};
}
function dt({ tile: e }) {
	let { ref: t, hidden: n } = o(`tile:${e.key}`), r = Q(e.x, e.y);
	return /* @__PURE__ */ g("g", {
		ref: (e) => t(e),
		transform: `translate(${r.x} ${r.y})`,
		children: /* @__PURE__ */ g("g", {
			style: { visibility: n ? "hidden" : void 0 },
			children: /* @__PURE__ */ g(Xe, { tile: e })
		})
	});
}
function ft({ pub: e, actions: t = [], onPick: n, fit: r, preview: a }) {
	let o = c(), s = /* @__PURE__ */ new Map(), l = `${e.round}:${r}`, [u, d] = i(() => ({
		inputKey: l,
		bounds: ut(e.tiles),
		zoom: 1
	}));
	u.inputKey !== l && d({
		inputKey: l,
		bounds: ut(e.tiles),
		zoom: 1
	});
	let { bounds: f, zoom: p } = u, m = f.w / p, ee = f.h / p;
	for (let n of t) {
		let t = n.tile ? e.tiles.find((e) => e.key === n.tile) : null, r = n.x ?? t?.x, i = n.y ?? t?.y;
		if (r === void 0 || i === void 0) continue;
		let a = `${r},${i}`;
		s.set(a, [...s.get(a) ?? [], n]);
	}
	let h = [...s.keys()].map((e) => {
		let [t, n] = e.split(",").map(Number);
		return {
			key: e,
			rect: Q(t, n)
		};
	});
	return /* @__PURE__ */ _("div", {
		className: "sab20-mine",
		children: [
			/* @__PURE__ */ g(y, {
				sheetW: m,
				sheetH: ee,
				fitKey: `${l}:${p}`,
				eligible: h.map((e) => ({
					...e,
					rect: {
						...e.rect,
						x: e.rect.x - f.x - f.w / 2 + m / 2,
						y: e.rect.y - f.y - f.h / 2 + ee / 2
					}
				})),
				onTapEligible: (e) => n?.(s.get(e) ?? []),
				readOnly: !n,
				highlight: "inset",
				children: /* @__PURE__ */ _("g", {
					transform: `translate(${-f.x - f.w / 2 + m / 2} ${-f.y - f.h / 2 + ee / 2})`,
					children: [
						e.tiles.map((e) => /* @__PURE__ */ g(dt, { tile: e }, e.key)),
						e.tiles.filter((e) => e.kind === "goal" || e.kind === "start").map((e) => {
							let t = Q(e.x, e.y);
							return /* @__PURE__ */ g("text", {
								x: t.x + 39,
								y: t.y + 130,
								textAnchor: "middle",
								fontSize: "13",
								fill: "#c9d2ce",
								children: e.kind === "start" ? o("games.saboteur20.start") : e.revealed && e.goal !== null ? ot(e.goal, o) : o("games.saboteur20.goal")
							}, `label:${e.key}`);
						}),
						e.tolls.filter((e) => e.owner).map((e) => {
							let t = Q(e.x, e.y);
							return /* @__PURE__ */ _("g", {
								transform: `translate(${t.x + 18} ${t.y + 25})`,
								children: [
									/* @__PURE__ */ g($e, {}),
									/* @__PURE__ */ g("circle", {
										cx: "36",
										cy: "53",
										r: "10",
										fill: "#ead09a",
										stroke: "#805332"
									}),
									/* @__PURE__ */ g("text", {
										x: "36",
										y: "58",
										textAnchor: "middle",
										fill: "#493723",
										fontSize: "14",
										children: "1"
									})
								]
							}, e.id);
						}),
						a?.x !== void 0 && a.card !== void 0 && /* @__PURE__ */ g("g", {
							opacity: ".55",
							transform: `translate(${Q(a.x, a.y ?? 0).x} ${Q(a.x, a.y ?? 0).y})`,
							children: /* @__PURE__ */ g(Ze, {
								id: a.card,
								flip: a.flip
							})
						}),
						/* @__PURE__ */ g(v, {
							name: "mine-origin",
							r: {
								x: 0,
								y: 0,
								w: Z.w,
								h: Z.h
							}
						})
					]
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "sab20-zoom",
				children: [/* @__PURE__ */ g("button", {
					type: "button",
					"aria-label": o("games.saboteur20.zoomIn"),
					disabled: p >= 4,
					onClick: () => d({
						...u,
						zoom: Math.min(4, p * 1.5)
					}),
					children: "+"
				}), /* @__PURE__ */ g("button", {
					type: "button",
					"aria-label": o("games.saboteur20.zoomOut"),
					disabled: p <= 1,
					onClick: () => d({
						...u,
						zoom: Math.max(1, p / 1.5)
					}),
					children: "−"
				})]
			}),
			h.length > 0 && /* @__PURE__ */ _("details", {
				className: "sab20-board-access",
				children: [/* @__PURE__ */ g("summary", { children: o("games.saboteur20.chooseTarget") }), /* @__PURE__ */ g("div", { children: [...s].map(([e, t]) => /* @__PURE__ */ g("button", {
					type: "button",
					onClick: () => n?.(t),
					children: o("games.saboteur20.tileAt", {
						x: Number(e.split(",")[0]),
						y: Number(e.split(",")[1])
					})
				}, e)) })]
			})
		]
	});
}
//#endregion
//#region src/games/saboteur20/view-player.tsx
function pt({ id: e, label: t, flip: n, selected: r, disabled: i, onClick: a, onRotate: s }) {
	let l = c(), { ref: u, hidden: d } = o(`card:${e}`);
	return /* @__PURE__ */ _("div", {
		className: "sab20-hand-item",
		children: [/* @__PURE__ */ g("button", {
			type: "button",
			ref: u,
			className: `sab20-hand-card${r ? " sab20-selected" : ""}`,
			onClick: a,
			"aria-label": t,
			"aria-pressed": r,
			disabled: i,
			style: { visibility: d ? "hidden" : void 0 },
			children: /* @__PURE__ */ g(Qe, {
				id: e,
				label: t,
				flip: r && n
			})
		}), r && s && /* @__PURE__ */ g("button", {
			type: "button",
			className: "sab20-card-rotate",
			onClick: s,
			"aria-label": l("games.saboteur20.rotate"),
			children: /* @__PURE__ */ g(f, { size: 18 })
		})]
	});
}
function mt({ player: e, member: t, name: n, active: r, actions: i, onPick: s }) {
	let l = c(), { ref: u } = o(`seat:${e.rid}`), d = p[(t?.colorIndex ?? 0) % p.length];
	return /* @__PURE__ */ _("button", {
		type: "button",
		ref: u,
		className: `sab20-seat${r ? " sab20-seat-active" : ""}${i.length ? " sab20-eligible" : ""}`,
		onClick: () => {
			i.length && s(i);
		},
		disabled: !i.length,
		style: { borderColor: d.hex },
		"aria-label": n,
		children: [
			/* @__PURE__ */ g("span", {
				className: "sab20-avatar",
				style: { background: d.hex },
				children: /* @__PURE__ */ g("img", {
					src: a[(t?.avatar ?? 0) % a.length],
					alt: ""
				})
			}),
			/* @__PURE__ */ _("span", {
				className: "sab20-seat-copy",
				children: [/* @__PURE__ */ g("b", { children: n }), /* @__PURE__ */ g("span", { children: e.role ? l(tt[e.role]) : l("games.saboteur20.handCount", { n: e.hand }) })]
			}),
			/* @__PURE__ */ _("span", {
				className: "sab20-tools",
				children: [
					[
						"cart",
						"lamp",
						"pick"
					].map((t) => /* @__PURE__ */ g("span", {
						title: `${l(nt[t])} · ${l(e.broken.includes(t) ? "games.saboteur20.broken" : "games.saboteur20.intact")}`,
						children: /* @__PURE__ */ g(et, {
							tool: t,
							broken: e.broken.includes(t)
						})
					}, t)),
					e.trap && /* @__PURE__ */ g("span", {
						title: l("games.saboteur20.trap"),
						children: /* @__PURE__ */ g(J, {
							kind: "trap",
							size: 22
						})
					}),
					e.theft && /* @__PURE__ */ g("span", {
						title: l("games.saboteur20.theft"),
						children: /* @__PURE__ */ g(J, {
							kind: "theft",
							size: 22
						})
					})
				]
			}),
			i.length > 0 && /* @__PURE__ */ g("svg", {
				className: "sab20-seat-outline",
				preserveAspectRatio: "none",
				viewBox: "0 0 240 60",
				"aria-hidden": !0,
				children: /* @__PURE__ */ g("rect", {
					x: "2",
					y: "2",
					width: "236",
					height: "56",
					rx: "8",
					pathLength: "100",
					fill: "none",
					stroke: "#f5deb0",
					strokeWidth: "2",
					strokeDasharray: "5 3",
					children: /* @__PURE__ */ g("animate", {
						attributeName: "stroke-dashoffset",
						from: "0",
						to: "-16",
						dur: ".7s",
						repeatCount: "indefinite"
					})
				})
			})
		]
	});
}
function ht({ public: e, private: t, members: n, myRid: r, send: a }) {
	let f = e, v = t, y = c(), b = s((e) => e.locale), [x, te] = i({
		rid: r,
		ids: [],
		mode: "play",
		flip: !1,
		pending: [],
		detail: !1,
		known: !1
	}), [ne, S] = i(0), C = x.rid === r, w = C ? x.ids.filter((e) => v?.hand.includes(e)) : [], T = C ? x.mode : "play", E = C ? x.flip : !1, ie = v?.legal ?? [], O = w[0], k = O === void 0 ? null : A(O), j = C ? x.pending.filter((e) => ie.some((t) => JSON.stringify(e) === JSON.stringify(t))) : [], M = (e) => te({
		...x,
		rid: r,
		ids: w,
		mode: T,
		flip: E,
		pending: [],
		detail: C && x.detail,
		known: C && x.known,
		...e
	}), N = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? ee(t, b) : y(p[0].nameKey);
	}, ae = (e) => lt(e, f, y, N), oe = (e) => M({ pending: e }), P = (e) => {
		a(e), M({
			ids: [],
			pending: [],
			mode: "play",
			flip: !1
		});
	}, F = ie.filter((e) => T === "discard" ? (e.type === "discard" || e.type === "escape") && e.cards?.length === w.length && w.every((t) => e.cards.includes(t)) : T === "toll" ? e.type === "toll" && e.card === O : e.card === O && (e.type === "place" || e.type === "act")), I = ie.filter((e) => [
		"choose",
		"react",
		"next"
	].includes(e.type)), L = F.length ? F : I, se = L.filter((e) => (e.x !== void 0 || e.tile !== void 0) && (e.flip === void 0 || e.flip === E)), ce = L.filter((e) => e.target), R = L.filter((e) => e.x === void 0 && e.tile === void 0 && !e.target && e.index === void 0 && (e.type !== "choose" || e.flip === void 0)), { ref: z } = o("deck"), { ref: B } = o("discard"), { ref: le } = o("hand"), V = y("games.saboteur20.chooseCard");
	if (f.phase === "resolve") V = y("games.saboteur20.resolve");
	else if (f.phase === "round") V = y("games.saboteur20.roundEnd");
	else if (f.phase === "react") V = y("games.saboteur20.reactPrompt");
	else if (f.phase === "reward") V = y("games.saboteur20.rewardPrompt");
	else if (f.phase === "reveal") V = y("games.saboteur20.revealPrompt");
	else if (f.choice) {
		let e = f.choice.kind;
		V = e === "pay" ? y("games.saboteur20.payPrompt", { name: N(f.turn) }) : y(e === "orient" ? "games.saboteur20.orientPrompt" : e === "stealCard" ? "games.saboteur20.stealCard" : e === "inspect" ? "games.saboteur20.inspect" : e === "moveGoal" ? "games.saboteur20.moveGoal" : e === "trove" ? "games.saboteur20.trove" : e === "drawPick" ? "games.saboteur20.drawPick" : "games.saboteur20.theftPrompt");
	} else f.chain ? V = y("games.saboteur20.chain", { n: f.chain }) : k && (V = se.length ? y("games.saboteur20.placePrompt") : F.length ? y("games.saboteur20.chooseTarget") : y("games.saboteur20.noTargets"));
	let H = ie.length > 0, ue = f.choice?.rid ?? (f.phase === "react" ? r : f.turn), de = H ? V : y("games.saboteur20.wait", { name: N(ue) }), fe = y("games.saboteur20.turn", { name: N(f.turn) }), pe = v && (f.phase === "reward" && v.reward.length || v.choices.length || f.choice?.kind === "orient" && H), U = f.event, W = U.card === null && U.tile !== null && f.tiles.some((e) => e.key === U.tile && e.kind === "chest") && st[U.kind] ? y(st[U.kind]) : U.kind === "costume" ? y("games.saboteur20.events.costume", { name: N(U.by) }) : U.kind === "party" ? y("games.saboteur20.events.party") : U.kind === "sack" || U.kind === "dragon" || U.kind === "spider" ? y("games.saboteur20.events.reveal", {
		name: N(U.by),
		card: y(at[U.kind])
	}) : null;
	return /* @__PURE__ */ _(m, {
		adaptive: !0,
		scroll: !1,
		className: "sab20-screen",
		actionsHeight: "sab20-desk-height",
		banner: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("header", {
			className: "sab20-header",
			children: [/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("span", {
				className: "sab20-title",
				children: y("games.saboteur20.name")
			}), /* @__PURE__ */ _("span", {
				className: "sab20-round",
				children: [
					y("games.saboteur20.round", { n: f.round }),
					" · ",
					f.direction === 1 ? "↻" : "↺"
				]
			})] }), /* @__PURE__ */ _("div", {
				className: "sab20-piles",
				children: [/* @__PURE__ */ _("div", {
					ref: z,
					children: [/* @__PURE__ */ g(Y, { className: "sab20-deck-stack" }), y("games.saboteur20.deck", { n: f.deckCount })]
				}), /* @__PURE__ */ _("div", {
					ref: B,
					children: [/* @__PURE__ */ g(Y, { className: "sab20-discard-stack" }), y("games.saboteur20.discardPile", { n: f.discardCount })]
				})]
			})]
		}), /* @__PURE__ */ g("div", {
			className: "sab20-seats",
			children: f.players.map((e) => /* @__PURE__ */ g(mt, {
				player: e,
				member: n.find((t) => t.rid === e.rid),
				name: N(e.rid),
				active: e.rid === f.turn,
				actions: ce.filter((t) => t.target === e.rid),
				onPick: oe
			}, e.rid))
		})] }),
		overlay: /* @__PURE__ */ _("div", {
			className: "sab20-board-bottom",
			children: [/* @__PURE__ */ g("button", {
				type: "button",
				className: "sab20-icon-button",
				onClick: () => S(ne + 1),
				"aria-label": y("games.saboteur20.recenter"),
				children: /* @__PURE__ */ g(d, { size: 20 })
			}), f.noMap && /* @__PURE__ */ g("span", { children: y("games.saboteur20.noMap") })]
		}),
		actions: /* @__PURE__ */ _("div", {
			className: "sab20-desk",
			children: [v && /* @__PURE__ */ _("aside", {
				className: "sab20-private-role",
				children: [/* @__PURE__ */ g(Ge, {
					role: v.role,
					damaged: f.config.sabotaged && !!f.players.find((e) => e.rid === r)?.broken.length
				}), /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("b", { children: y(tt[v.role]) }), /* @__PURE__ */ _("span", {
					title: y("games.saboteur20.privateGold"),
					children: [/* @__PURE__ */ g(J, {
						kind: "gold",
						size: 25
					}), y("games.saboteur20.gold", { n: v.gold })]
				})] })]
			}), /* @__PURE__ */ _("div", {
				className: "sab20-workspace",
				children: [
					/* @__PURE__ */ _("div", {
						className: "sab20-prompt",
						children: [/* @__PURE__ */ g("span", {
							role: "status",
							children: de
						}), /* @__PURE__ */ _("div", {
							className: "sab20-desk-controls",
							children: [
								k && /* @__PURE__ */ g("button", {
									type: "button",
									className: "sab20-icon-button",
									"aria-label": y("games.saboteur20.viewRules"),
									onClick: () => M({ detail: !(C && x.detail) }),
									children: /* @__PURE__ */ g(u, { size: 19 })
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "sab20-small-button",
									onClick: () => M({ known: !(C && x.known) }),
									children: y("games.saboteur20.known")
								}),
								H && f.phase === "play" && /* @__PURE__ */ _("div", {
									className: "sab20-mode-buttons",
									children: [/* @__PURE__ */ g("button", {
										type: "button",
										onClick: () => M({
											mode: T === "discard" ? "play" : "discard",
											ids: []
										}),
										"aria-pressed": T === "discard",
										children: y("games.saboteur20.discard")
									}), f.config.toll && /* @__PURE__ */ g("button", {
										type: "button",
										onClick: () => M({
											mode: T === "toll" ? "play" : "toll",
											ids: []
										}),
										"aria-pressed": T === "toll",
										children: y("games.saboteur20.tollAction")
									})]
								})
							]
						})]
					}),
					/* @__PURE__ */ g("div", {
						className: "sab20-hand",
						ref: le,
						"aria-label": y("games.saboteur20.hand"),
						children: v?.hand.map((e) => /* @__PURE__ */ g(pt, {
							id: e,
							label: ct(e, y),
							selected: w.includes(e),
							flip: E,
							onRotate: w.includes(e) && T === "play" && ["path", "diversion"].includes(A(e).kind) ? () => M({ flip: !E }) : void 0,
							disabled: f.phase !== "play" || !H,
							onClick: () => M({ ids: T === "discard" ? w.includes(e) ? w.filter((t) => t !== e) : [...w, e].slice(-(f.config.mode === "expansion" ? 3 : 1)) : w[0] === e ? [] : [e] })
						}, e))
					}),
					/* @__PURE__ */ g("div", {
						className: "sab20-action-strip",
						children: R.map((e, t) => /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => P(e),
							children: e.type === "discard" ? y("games.saboteur20.discard") : ae(e)
						}, t))
					})
				]
			})]
		}),
		children: [/* @__PURE__ */ _("div", {
			className: "sab20-table",
			"aria-label": fe,
			children: [/* @__PURE__ */ g(ft, {
				pub: f,
				actions: se,
				onPick: oe,
				fit: ne,
				preview: j[0]
			}), W && /* @__PURE__ */ g("div", {
				className: "sab20-event",
				role: "status",
				children: W
			})]
		}), (j.length > 0 || pe || C && (x.detail && k || x.known)) && /* @__PURE__ */ g("div", {
			className: "sab20-dialog-layer",
			children: /* @__PURE__ */ _("section", {
				className: "sab20-dialog",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": V,
				children: [/* @__PURE__ */ _("header", { children: [/* @__PURE__ */ g("b", { children: V }), !pe && /* @__PURE__ */ g("button", {
					type: "button",
					className: "sab20-icon-button",
					"aria-label": y("games.saboteur20.close"),
					onClick: () => M({
						detail: !1,
						known: !1,
						pending: []
					}),
					children: /* @__PURE__ */ g(l, { size: 20 })
				})] }), /* @__PURE__ */ _("div", {
					className: "sab20-dialog-body",
					children: [
						j.length > 0 && /* @__PURE__ */ _(h, { children: [j[0].card !== void 0 && /* @__PURE__ */ g(Qe, {
							id: j[0].card,
							label: ct(j[0].card, y),
							flip: j[0].flip
						}), /* @__PURE__ */ g("div", {
							className: "sab20-choice-buttons",
							children: j.map((e, t) => /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => P(e),
								children: e.payer ? `${ae(e)} · ${y("games.saboteur20.payer")} ${N(e.payer)}` : ae(e)
							}, t))
						})] }),
						v?.reward.map((e, t) => /* @__PURE__ */ _("button", {
							type: "button",
							className: "sab20-gold-choice",
							onClick: () => P(I.find((e) => e.index === t)),
							children: [/* @__PURE__ */ g(J, {
								kind: "gold",
								size: 44
							}), /* @__PURE__ */ g("b", { children: y("games.saboteur20.gold", { n: e }) })]
						}, t)),
						v?.choices.map((e, t) => /* @__PURE__ */ g("button", {
							type: "button",
							className: "sab20-hand-card",
							onClick: () => P(I.find((e) => e.index === t)),
							children: /* @__PURE__ */ g(Qe, {
								id: e,
								label: ct(e, y)
							})
						}, e)),
						f.choice?.kind === "orient" && H && I.map((e, t) => {
							let n = f.tiles.find((e) => e.key === f.event.tile);
							return /* @__PURE__ */ _("button", {
								type: "button",
								className: "sab20-orient",
								onClick: () => P(e),
								children: [/* @__PURE__ */ g("svg", {
									viewBox: "0 0 78 112",
									children: /* @__PURE__ */ g("g", {
										transform: e.flip ? "translate(78 112) rotate(180)" : void 0,
										children: n && /* @__PURE__ */ g(Ye, {
											groups: n.groups,
											goal: n.goal === null ? void 0 : D[n.goal].kind,
											goalValue: n.goal === null ? 0 : D[n.goal].gold
										})
									})
								}), /* @__PURE__ */ g("span", { children: e.flip ? y("games.saboteur20.rotate") : y("games.saboteur20.keep") })]
							}, t);
						}),
						C && x.detail && k && /* @__PURE__ */ g("p", { children: y(it[k.kind]) }),
						C && x.known && v && /* @__PURE__ */ _("div", {
							className: "sab20-knowledge",
							children: [Object.entries(v.known).map(([e, t]) => {
								let n = t.split(":");
								return /* @__PURE__ */ _("div", {
									className: "sab20-knowledge-row",
									children: [
										/* @__PURE__ */ g("b", { children: e.startsWith("role:") ? N(e.slice(5)) : y("games.saboteur20.tileAt", {
											x: Number(e.split(",")[0]),
											y: Number(e.split(",")[1])
										}) }),
										!e.startsWith("role:") && /* @__PURE__ */ g("svg", {
											viewBox: "0 0 78 112",
											width: "62",
											height: "89",
											children: /* @__PURE__ */ g(Ye, {
												groups: n[0] === "goal" ? D[Number(n[1])].groups.map((e) => [...e]) : re[Number(n[1])],
												goal: n[0] === "goal" ? D[Number(n[1])].kind : void 0,
												goalValue: n[0] === "goal" ? D[Number(n[1])].gold : 0
											})
										}),
										/* @__PURE__ */ g("span", { children: e.startsWith("role:") ? y(tt[t]) : n[0] === "goal" ? ot(Number(n[1]), y) : y(st[n[2]]) })
									]
								}, e);
							}), !Object.keys(v.known).length && /* @__PURE__ */ g("p", { children: y("games.saboteur20.noKnowledge") })]
						})
					]
				})]
			})
		})]
	});
}
//#endregion
//#region src/games/saboteur20/bot.ts
function gt(e) {
	let t = Math.floor(4294967296 / e.length) * e.length, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return e[n[0] % e.length];
}
function _t(e, t, n) {
	let r = e.public, i = e.private, a = i.role === "saboteur", o = r.players.find((e) => e.rid === t), s = (e) => i.known[`role:${e}`], c = (e) => e === t || s(e) === i.role || i.role === "boss" && ["blue", "green"].includes(s(e));
	if (n.type === "next") return 1e3;
	if (n.type === "react") return n.yes ? -5 : 0;
	if (r.phase === "reward") return i.reward[n.index ?? 0] ?? 0;
	if (n.type === "choose") {
		if (r.choice?.kind === "pay") return n.yes ? -5 : 0;
		if (r.choice?.kind === "orient") return +!n.flip;
		if (n.index !== void 0) {
			let e = A(i.choices[n.index]);
			return e ? e.kind === "path" ? e.groups.some((e) => e.length >= 3) ? 20 : 5 : [
				"repair",
				"master",
				"rockfall",
				"theft"
			].includes(e.kind) ? 15 : 3 : 0;
		}
		if (r.choice?.kind === "theft") return n.target ? 5 + +(s(n.target) === "saboteur" && !a) : 0;
		if (n.tile) {
			let e = i.known[n.tile], t = e?.startsWith("goal:") ? D[Number(e.split(":")[1])] : null;
			return t?.kind === "gold" ? a ? -100 : 100 : t?.kind === "spider" ? a ? 100 : -100 : t?.kind === "sack" ? 50 : 0;
		}
		return n.target ? 5 : 0;
	}
	if (n.type === "discard") return -15 - (n.cards ?? []).reduce((e, t) => e + (A(t).kind === "veto" ? 5 : A(t).kind === "path" && A(t).groups.some((e) => e.length >= 3) ? 15 : 0), 0);
	if (n.type === "escape") return o.trap || o.broken.length ? 40 : -10;
	if (n.type === "toll") return -20;
	let l = A(n.card);
	if (n.type === "place" || l.kind === "diversion") {
		let e = k((l.kind === "diversion" ? A(r.tiles.find((e) => e.key === r.lastPath).card) : l).groups, n.flip ?? !1), t = n.x, o = n.y, s = r.tiles.filter((e) => e.kind === "goal" && (i.known[e.key] === "goal:0" || !e.revealed && !i.known[e.key])), c = Math.min(...(s.length ? s : r.tiles.filter((e) => e.kind === "goal")).map((e) => Math.abs(t - e.x) + Math.abs(o - e.y))), u = Math.max(0, ...r.tiles.filter((e) => e.kind === "path").map((e) => e.x)), d = e.every((e) => e.length === 1);
		if (a) return d && t >= u ? 45 + t : 10 - c + (d ? 15 : -20);
		let f = 35 - c * 4 + (e.some((e) => e.includes(1)) ? 4 : 0) + Math.min(t, 8) * .1;
		return d && (f -= 45), e.length > 1 && (f -= 6), f;
	}
	if (l.kind === "repair" || l.kind === "master" || l.kind === "freedom") return n.target === t ? 50 : c(n.target) ? 30 : -8;
	if (l.kind === "break" || l.kind === "trap") return c(n.target) ? -30 : s(n.target) === "saboteur" ? a ? -30 : 40 : a ? 32 : 1;
	if (l.kind === "theft") return 38;
	if (l.kind === "handsOff") return c(n.target) ? -20 : 20;
	if (l.kind === "map") return i.known[n.tile] ? -12 : 4;
	if (l.kind === "inspect") return i.known[`role:${n.target}`] ? -10 : 0;
	if (l.kind === "rockfall") {
		let e = r.tiles.find((e) => e.key === n.tile);
		if (!e.revealed) return a ? 5 : -5;
		let t = e.groups.every((e) => e.length === 1);
		return a ? t ? -20 : 20 + e.x : t ? 22 + e.x : -25;
	}
	return l.kind === "pathfinder" ? 40 : l.kind === "trove" ? 12 : l.kind === "hats" ? n.target === t && i.role === "saboteur" && r.deckCount < 8 ? 25 : -10 : l.kind === "hands" ? r.players.find((e) => e.rid === n.target).hand > i.hand.length ? 25 : -10 : l.kind === "goals" && n.yes && a ? 5 : -5;
}
function vt(e, t) {
	let n = e.private?.legal ?? [], r = null, i = -Infinity;
	for (let a of n) {
		let n = _t(e, t, a);
		n > i && (i = n, r = a);
	}
	return r;
}
var yt = (e, t) => {
	let n = e.private?.legal ?? [];
	return n.length ? { action: t.difficulty === "weak" ? gt(n) : vt(e, t.rid) } : null;
}, bt = (e, t, n) => lt(e, t.public, n, (e) => {
	let r = t.public.players.find((t) => t.rid === e);
	return r?.role ? n(r.role === "blue" ? "games.saboteur20.roles.blue" : r.role === "green" ? "games.saboteur20.roles.green" : "games.saboteur20.chooseTarget") : n("games.saboteur20.chooseTarget");
});
//#endregion
//#region src/games/saboteur20/fx.tsx
function $(e, t) {
	let n = e.anchor("mine-origin");
	if (!n || !t) return null;
	let [r, i] = t.split(",").map(Number);
	if (!Number.isFinite(r) || !Number.isFinite(i)) return null;
	let a = Q(r, i), o = n.w / Z.w, s = n.h / Z.h;
	return {
		x: n.x + a.x * o,
		y: n.y + a.y * s,
		w: a.w * o,
		h: a.h * s
	};
}
function xt({ face: e, width: t }) {
	return /* @__PURE__ */ g("div", {
		style: {
			width: t,
			height: t * 112 / 78
		},
		children: /* @__PURE__ */ g("svg", {
			viewBox: "0 0 78 112",
			style: {
				width: "100%",
				height: "100%"
			},
			children: /* @__PURE__ */ g(Xe, { tile: e })
		})
	});
}
function St({ face: e, at: t, ms: i }) {
	let a = r(null), o = r(null), s = r(null);
	return n(() => {
		let e = a.current?.animate([
			{ transform: "scaleX(1)" },
			{
				transform: "scaleX(0)",
				offset: .5
			},
			{ transform: "scaleX(1)" }
		], {
			duration: i,
			easing: "ease-in-out",
			fill: "both"
		}), t = o.current?.animate([
			{ opacity: 0 },
			{
				opacity: 0,
				offset: .49
			},
			{
				opacity: 1,
				offset: .5
			},
			{ opacity: 1 }
		], {
			duration: i,
			fill: "both"
		}), n = s.current?.animate([
			{ opacity: 1 },
			{
				opacity: 1,
				offset: .49
			},
			{
				opacity: 0,
				offset: .5
			},
			{ opacity: 0 }
		], {
			duration: i,
			fill: "both"
		});
		return () => {
			e?.cancel(), t?.cancel(), n?.cancel();
		};
	}, [i]), /* @__PURE__ */ _("div", {
		ref: a,
		style: {
			position: "absolute",
			left: t.x,
			top: t.y,
			width: t.w,
			height: t.h
		},
		children: [/* @__PURE__ */ g("svg", {
			ref: s,
			viewBox: "0 0 78 112",
			style: {
				position: "absolute",
				width: "100%",
				height: "100%"
			},
			children: /* @__PURE__ */ g(Ye, {
				groups: [],
				hidden: !0,
				chest: e.kind === "chest"
			})
		}), /* @__PURE__ */ g("svg", {
			ref: o,
			viewBox: "0 0 78 112",
			style: {
				position: "absolute",
				width: "100%",
				height: "100%",
				opacity: 0
			},
			children: /* @__PURE__ */ g(Xe, { tile: e })
		})]
	});
}
var Ct = {
	draw(e, t) {
		let n = e.data.source, r = t.anchor(n === "discard" ? "discard" : n && n !== "deck" ? `seat:${n}` : "deck"), i = e.rid === t.myRid ? t.anchor("hand") : t.anchor(`seat:${e.rid}`);
		if (!r || !i) return null;
		let a = e.secret?.cards, o = e.data.count, s = I.action;
		return {
			ms: s,
			node: Array.from({ length: Math.min(o, 6) }, (e, t) => /* @__PURE__ */ g(b, {
				from: {
					...r,
					w: 38,
					h: 56
				},
				to: {
					...i,
					x: i.x + Math.min(t * 28, i.w - 40),
					w: 38,
					h: 56
				},
				ms: s - 100,
				delay: t * 12,
				children: a?.[t] === void 0 ? /* @__PURE__ */ g(Y, { style: {
					width: 38,
					height: 56
				} }) : /* @__PURE__ */ g(Qe, {
					id: a[t],
					style: { width: 38 }
				})
			}, t))
		};
	},
	event(e, t) {
		let n = e.data, r = n.kind === "reveal" ? I.reveal : I.place, i = t.anchor(`seat:${e.rid}`), a = e.rid === t.myRid ? t.anchor("hand") : i;
		if (n.kind === "path" || n.kind === "diversion") {
			let e = $(t, n.tile), i = n.kind === "diversion" ? $(t, n.target) : a;
			return !e || !i || n.card === null ? null : {
				ms: r,
				hide: t.queued ? [] : [`tile:${n.tile}`],
				node: /* @__PURE__ */ g(b, {
					from: {
						...i,
						w: e.w,
						h: e.h
					},
					to: e,
					ms: r,
					children: /* @__PURE__ */ g(Qe, {
						id: n.card,
						flip: n.flip,
						style: { width: e.w }
					})
				})
			};
		}
		if (n.kind === "reveal") {
			let e = $(t, n.tile);
			return e && n.face ? {
				ms: r,
				hide: t.queued ? [] : [`tile:${n.tile}`],
				node: /* @__PURE__ */ g(St, {
					at: e,
					face: n.face,
					ms: r
				})
			} : null;
		}
		if (n.kind === "moveGoal" && n.face) {
			let e = $(t, n.target), i = $(t, n.tile);
			return e && i ? {
				ms: r,
				hide: t.queued ? [] : [`tile:${n.tile}`],
				node: /* @__PURE__ */ g(b, {
					from: e,
					to: i,
					ms: r,
					children: /* @__PURE__ */ g(xt, {
						face: n.face,
						width: e.w
					})
				})
			} : null;
		}
		if (n.kind === "hands" && a) {
			let e = t.anchor(`seat:${n.target}`);
			return e ? {
				ms: r,
				node: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(b, {
					from: {
						...a,
						w: 38,
						h: 55
					},
					to: {
						...e,
						w: 38,
						h: 55
					},
					ms: r,
					children: /* @__PURE__ */ g(Y, { style: {
						width: 38,
						height: 55,
						display: "block"
					} })
				}), /* @__PURE__ */ g(b, {
					from: {
						...e,
						w: 38,
						h: 55
					},
					to: {
						...a,
						w: 38,
						h: 55
					},
					ms: r,
					children: /* @__PURE__ */ g(Y, { style: {
						width: 38,
						height: 55,
						display: "block"
					} })
				})] })
			} : null;
		}
		if (n.kind === "round" || n.kind === "reward") return {
			ms: I.action,
			node: null
		};
		let o = (n.target ? t.anchor(`seat:${n.target}`) : n.tile ? $(t, n.tile) : t.anchor("discard")) ?? i;
		return !o || !a ? null : {
			ms: r,
			node: n.card === null ? /* @__PURE__ */ g(x, {
				at: o,
				ms: r
			}) : /* @__PURE__ */ g(b, {
				from: {
					...a,
					w: 44,
					h: 64
				},
				to: {
					...o,
					w: 44,
					h: 64
				},
				ms: r,
				children: /* @__PURE__ */ g(Qe, {
					id: n.card,
					flip: n.flip,
					style: { width: 44 }
				})
			})
		};
	},
	remove(e, t) {
		let n = e.data.face, r = $(t, n.key), i = t.anchor("discard");
		return r && i ? {
			ms: I.place,
			node: /* @__PURE__ */ g(b, {
				from: r,
				to: {
					...i,
					w: 38,
					h: 55
				},
				ms: I.place - 150,
				delay: 150,
				children: /* @__PURE__ */ g(xt, {
					face: n,
					width: r.w
				})
			})
		} : null;
	},
	discardCards(e, t) {
		let n = e.rid === t.myRid ? t.anchor("hand") : t.anchor(`seat:${e.rid}`), r = t.anchor("discard");
		return n && r ? {
			ms: I.action,
			node: Array.from({ length: e.data.count }, (e, t) => /* @__PURE__ */ g(b, {
				from: {
					...n,
					x: n.x + t * 12,
					w: 38,
					h: 55
				},
				to: {
					...r,
					w: 38,
					h: 55
				},
				ms: I.action - t * 20,
				delay: t * 20,
				children: /* @__PURE__ */ g(Y, { style: {
					width: 38,
					height: 55,
					display: "block"
				} })
			}, t))
		} : null;
	},
	gold(e, t) {
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: I.action,
			node: /* @__PURE__ */ g(b, {
				from: {
					...n,
					y: n.y - 40,
					w: 28,
					h: 28
				},
				to: {
					...n,
					w: 28,
					h: 28
				},
				ms: I.action,
				children: /* @__PURE__ */ g(J, {
					kind: "gold",
					size: 28
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/saboteur20/game-over.tsx
function wt({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: o }) {
	let l = t, u = c(), d = s((e) => e.locale), [f, m] = i(!1), [h, v] = i(0), [y, b] = i(null), x = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? ee(t, d) : u(p[0].nameKey);
	};
	return /* @__PURE__ */ _("div", {
		className: "sab20-over sab20-screen",
		children: [
			/* @__PURE__ */ _("header", {
				className: "sab20-over-heading",
				children: [/* @__PURE__ */ g("h1", { children: u("games.saboteur20.result") }), /* @__PURE__ */ _("p", { children: [
					e.winner.map(x).join(" · "),
					" · ",
					u("games.saboteur20.winner")
				] })]
			}),
			/* @__PURE__ */ g("div", {
				className: "sab20-over-scroll",
				children: /* @__PURE__ */ g("div", {
					className: "sab20-result-grid",
					children: e.ranking.map((t) => {
						let r = n.find((e) => e.rid === t);
						return /* @__PURE__ */ _("section", {
							className: `sab20-result-card${e.winner.includes(t) ? " sab20-result-winner" : ""}`,
							children: [
								/* @__PURE__ */ _("div", {
									className: "sab20-result-person",
									children: [
										/* @__PURE__ */ g("span", {
											className: "sab20-avatar",
											style: { background: p[(r?.colorIndex ?? 0) % p.length].hex },
											children: /* @__PURE__ */ g("img", {
												src: a[(r?.avatar ?? 0) % a.length],
												alt: ""
											})
										}),
										/* @__PURE__ */ g("b", { children: x(t) }),
										e.winner.includes(t) && /* @__PURE__ */ g(J, {
											kind: "gold",
											size: 26
										})
									]
								}),
								/* @__PURE__ */ _("div", {
									className: "sab20-result-total",
									children: [/* @__PURE__ */ g(J, {
										kind: "gold",
										size: 34
									}), u("games.saboteur20.gold", { n: e.scores?.[t] ?? 0 })]
								}),
								/* @__PURE__ */ _("div", {
									className: "sab20-result-breakdown",
									children: [l.config.toll && /* @__PURE__ */ _("p", { children: [/* @__PURE__ */ g("span", { children: u("games.saboteur20.initialGold") }), /* @__PURE__ */ g("span", { children: "1" })] }), l.history.map((e) => /* @__PURE__ */ _("p", { children: [
										/* @__PURE__ */ g(Ge, { role: e.roles[t] }),
										/* @__PURE__ */ _("span", { children: [
											u("games.saboteur20.roundGain", { n: e.round }),
											" · ",
											u(tt[e.roles[t]])
										] }),
										/* @__PURE__ */ _("b", { children: [e.gains[t] > 0 ? "+" : "", e.gains[t]] })
									] }, e.round))]
								})
							]
						}, t);
					})
				})
			}),
			/* @__PURE__ */ _("footer", {
				className: "sab20-over-actions",
				children: [
					/* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => m(!0),
						children: u("games.saboteur20.finalMine")
					}),
					r && /* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => b("again"),
						children: u("games.saboteur20.again")
					}),
					o && /* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => b("lobby"),
						children: u("games.saboteur20.lobby")
					}),
					!r && !o && /* @__PURE__ */ g("span", { children: u("session.result.waitHost") })
				]
			}),
			/* @__PURE__ */ _("div", {
				className: `sab20-over-mine${f ? " sab20-open" : ""}`,
				"aria-hidden": !f,
				inert: !f,
				children: [/* @__PURE__ */ g(ft, {
					pub: l,
					fit: h
				}), /* @__PURE__ */ _("div", {
					className: "sab20-over-mine-toolbar",
					children: [/* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => m(!1),
						children: u("games.saboteur20.scores")
					}), /* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => v(h + 1),
						children: u("games.saboteur20.recenter")
					})]
				})]
			}),
			y && /* @__PURE__ */ g("div", {
				className: "sab20-dialog-layer",
				children: /* @__PURE__ */ g("section", {
					className: "sab20-dialog",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": u(y === "again" ? "games.saboteur20.confirmAgain" : "games.saboteur20.confirmLobby"),
					children: /* @__PURE__ */ _("div", {
						className: "sab20-dialog-body",
						children: [/* @__PURE__ */ g("p", { children: u(y === "again" ? "games.saboteur20.confirmAgain" : "games.saboteur20.confirmLobby") }), /* @__PURE__ */ _("div", {
							className: "sab20-choice-buttons",
							children: [/* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => {
									y === "again" ? r?.() : o?.();
								},
								children: u("games.saboteur20.confirm")
							}), /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => b(null),
								children: u("games.saboteur20.cancel")
							})]
						})]
					})
				})
			})
		]
	});
}
//#endregion
//#region src/games/saboteur20/options.tsx
function Tt({ value: e, onChange: t }) {
	let n = c(), r = j.safeParse(e), i = r.success ? r.data : j.parse(void 0), a = (e) => t({
		...i,
		...e
	});
	return /* @__PURE__ */ _("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ g(ne, {
				title: n("games.saboteur20.mode"),
				columns: 3,
				children: [
					"base",
					"expansion",
					"tournament"
				].map((e) => /* @__PURE__ */ g(te, {
					name: "sab20-mode",
					value: e,
					checked: i.mode === e,
					label: n(e === "base" ? "games.saboteur20.base" : e === "expansion" ? "games.saboteur20.expansion" : "games.saboteur20.tournament"),
					accent: F.accent,
					onChange: () => a({
						mode: e,
						...e === "base" ? {} : {
							greedy: !1,
							sabotaged: !1
						}
					})
				}, e))
			}),
			/* @__PURE__ */ g(S, {
				checked: i.specials,
				label: n("games.saboteur20.specials"),
				accent: F.accent,
				onChange: () => a({ specials: !i.specials })
			}),
			/* @__PURE__ */ g(S, {
				checked: i.greedy,
				disabled: i.mode !== "base",
				label: n("games.saboteur20.greedy"),
				hint: n("games.saboteur20.baseOnly"),
				accent: F.accent,
				onChange: () => a({ greedy: !i.greedy })
			}),
			/* @__PURE__ */ g(S, {
				checked: i.toll,
				label: n("games.saboteur20.toll"),
				accent: F.accent,
				onChange: () => a({ toll: !i.toll })
			}),
			/* @__PURE__ */ g(ne, {
				title: n("games.saboteur20.postcard"),
				columns: 3,
				children: [
					"none",
					"costume",
					"party"
				].map((e) => /* @__PURE__ */ g(te, {
					name: "sab20-postcard",
					value: e,
					checked: i.postcard === e,
					label: n(e === "none" ? "games.saboteur20.none" : e === "costume" ? "games.saboteur20.costume" : "games.saboteur20.party"),
					accent: F.accent,
					onChange: () => a({ postcard: e })
				}, e))
			}),
			/* @__PURE__ */ g(S, {
				checked: i.newGoals,
				label: n("games.saboteur20.newGoals"),
				accent: F.accent,
				onChange: () => a({ newGoals: !i.newGoals })
			}),
			/* @__PURE__ */ g(S, {
				checked: i.chests,
				label: n("games.saboteur20.chests"),
				accent: F.accent,
				onChange: () => a({ chests: !i.chests })
			}),
			/* @__PURE__ */ g(S, {
				checked: i.sabotaged,
				disabled: i.mode !== "base",
				label: n("games.saboteur20.sabotaged"),
				hint: n("games.saboteur20.baseOnly"),
				accent: F.accent,
				onChange: () => a({ sabotaged: !i.sabotaged })
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/saboteur20/entry.tsx
var Et = {
	definition: Ve,
	View: ht,
	bot: yt,
	describe: bt,
	fx: Ct,
	OverView: wt,
	Options: Tt,
	locales: {
		zh: {
			name: "矮人掘金：20周年纪念版",
			desc: "暗藏身份，在交错矿道中寻金、设障与争夺宝藏。",
			rules: "游戏目标：\n三轮结束后，拥有最多金币的玩家获胜；金币相同的玩家并列获胜。每轮重新分配秘密身份，金币会保留到下一轮。\n\n基础版准备与身份（3至10人）：\n起点与三个暗置目标之间相隔七张牌的宽度。三个目标中，一个藏有黄金，两个只有黑石。将40张路径牌与27张行动牌洗匀；3至5人时每人发6张，6至7人时每人发5张，8至10人时每人发4张。牌库用尽后不再摸牌，也不回收弃牌。\n根据人数准备身份牌，洗匀后每人发一张，多余一张暗置：\n· 3人使用1名破坏者与3名矿工；4人使用1名破坏者与4名矿工。\n· 5人使用2名破坏者与4名矿工；6人使用2名破坏者与5名矿工。\n· 7人使用3名破坏者与5名矿工；8人使用3名破坏者与6名矿工。\n· 9人使用3名破坏者与7名矿工；10人使用4名破坏者与7名矿工。\n矿工争取连通起点与黄金；破坏者争取让大家在找到黄金前耗尽手牌。你可以查看自己的身份和金币，其他人的身份与金币在规定揭示前保持秘密。首轮由首位玩家开始，随后顺时针行动。\n\n每回合的行动：\n轮到你时，选择下列一项行动，随后摸一张牌：\n· 打出一张路径牌。路径牌必须竖放，可以旋转180度，不能旋转90度。新牌至少有一条通道连通起点，且与所有相邻明牌的通道边缘吻合。矿道可以向任意方向延伸。\n· 打出一张行动牌，并完成对应效果。\n· 弃置一张手牌，跳过本次出牌。\n手牌与牌库都用尽的玩家会被跳过。地图、检视以及选牌窗口内的秘密内容，只会显示给执行者。若同时连通多个暗置目标或宝箱，由当前玩家决定逐一揭示的顺序。揭示后选择能尽量吻合相邻通道的朝向；目标牌在确实无法全部吻合时可以例外。\n\n基础行动牌：\n· 破坏工具：将红色工具牌放在另一名玩家面前。同一种工具不能重复破坏。只要矿车、提灯或镐中的任一种损坏，该玩家就不能打出路径牌。\n· 修理工具：移除自己或他人面前一张对应的破坏牌。双工具修理牌只能选择其中一种工具修理，不能预先保护工具。\n· 落石：移除一张已经铺设的路径牌。不能移除起点、目标或明信片。被移除的路径和落石一起弃置。\n· 地图：秘密查看一个暗置目标，然后将其放回原处。\n\n基础版轮末与金币：\n连通黄金时，矿工获胜。抽取与本轮矿工人数相同数量的金币牌，由打通黄金的矿工先挑选一张，其余依次向回合方向的反方向传递。若破坏者打通黄金，则从其右侧第一名矿工开始。金币牌共有16张1金币、8张2金币及4张3金币。\n若所有手牌耗尽而黄金仍未连通，则破坏者获胜：本轮只有一名破坏者时，其获得4金币；有两名或三名时，各获得3金币；有四名时，各获得2金币。若没有破坏者，则无人获得本轮奖励。若剩余金币牌的面值无法凑成固定奖励，可与已领取的金币牌等值换零；所有人的金币总数不因换零改变。\n轮末揭示所有身份。下一轮重新准备身份、矿道和手牌，由上一轮最后出牌者左侧的玩家开始。第三轮结束后比较累计金币。\n\nSaboteur 2 扩展（2至12人）：\n将基础版与扩展的全部路径牌和行动牌洗匀，每轮移开顶端10张，每人发6张手牌。每轮使用全部15张身份牌：蓝队矿工与绿队矿工各4张、破坏者3张、地质学家2张、老板与投机者各1张。未发出的身份牌组成备用身份牌堆。\n· 蓝队和绿队分别争取黄金。若某队矿工完成连接，且该队存在可通过的完整路径，则只有该队获胜；若该队被异色门挡住，则另一支能够抵达的队伍获胜。若由其他身份完成连接，则所有能够抵达的矿工队伍获胜。\n· 蓝门仅允许蓝队通过，绿门仅允许绿队通过。门不妨碍铺设路径，只在轮末判定获胜队伍。老板、投机者和地质学家可以通过所有门。\n· 老板随获胜矿工队伍获胜，但所获奖励减少1金币；投机者始终随获胜方获胜，但所获奖励减少2金币。若黄金已连通而两个矿工队都被门挡住，则老板和投机者仍可获胜；若其中只有一人在场，老板获得4金币或投机者获得3金币。若没有连通黄金且没有破坏者，投机者独自获得3金币。\n· 每名地质学家按矿道中所有可见水晶的总数获得金币。若有两名地质学家，各获得总数的一半，向下取整。\n扩展中的回合还允许弃置1至3张牌并摸取等量牌，或者弃置2张牌以移除自己面前任意一张行动牌，随后只摸1张牌。\n\n扩展路径与行动：\n· 桥梁和双弯道上的两条通道彼此独立，不能在交叉处转弯。至少一条通道必须连通起点。\n· 梯子与起点及所有其他梯子直接连通。梯子可以邻接任意路径，但不能邻接目标，且仍需吻合相邻通道。\n· 盗窃：放在自己面前。轮末分配奖励后，可从一名其他玩家处偷取1金币；该玩家没有金币时无法偷到。最近打出盗窃的玩家先执行，其余按顺时针顺序执行。\n· 住手：移除任意玩家面前的一张盗窃牌。\n· 陷阱：放在其他玩家面前。被困的玩家不能铺路，轮末不能获得任何奖励，也不能执行盗窃；计算获胜人数时也不包括该玩家。\n· 自由：移除任意玩家面前的一张陷阱牌。\n· 检视：秘密查看另一名玩家的身份。\n· 更换帽子：选择包括自己在内的一名玩家，其取备用身份牌堆顶牌作为新身份，旧身份放到牌堆底。\n· 交换手牌：与另一名玩家交换全部手牌。行动结束后由对方摸1张牌，你不摸牌。\n每名未被困的获胜者按获胜总人数领奖：1人时5金币，2人时各4金币，3人时各3金币，4人时各2金币，5人及以上时各1金币；随后应用老板与投机者的扣减，最低为零。\n\n赛事特别牌（可选）：\n· 贪婪矮人（2016）：仅用于基础版，以一张贪婪矮人替换一名矿工。只有自己打通黄金时，才独自获得4金币；否则不获奖励。\n· 交换目标（2017）：选择两个暗置目标，在不查看正面的情况下决定交换或保持原位。\n· 宝藏堆（2018）：代替正常摸牌，秘密查看弃牌堆顶至多5张，选择一张加入手牌，其余保持顺序放回。刚打出的宝藏堆不能被自己取回。\n· 否决（2019）：另一名玩家打出路径牌或行动牌后，在其生效前打出。将双方卡牌弃置，原行动者先摸1张并结束回合，然后否决者摸1张。其他玩家根据提示选择否决或允许该牌生效。\n· 逆转方向（2020）：立即反转本轮行动方向；基础版金币分配也相应反向。\n· 工匠大师（2021）：修理任意一名玩家的一种损坏工具。\n· 探路者（2022）：本回合依次打出两张路径牌，结束后摸2张牌；你会比之前少一张手牌。如果中途已无合法路径，则结束剩余铺路。\n· 改道（2023）：将最近铺设的路径牌移到另一个合法位置，可以旋转180度。\n\n迷你扩展（可选）：\n· 隧道收费：每人开局额外获得1金币。每轮有两名收费矮人，各只能使用一次。你可以弃置一张手牌，把一名尚未使用的收费矮人放在开放通道尽头，不摸牌。想在该处铺路的玩家须向放置者支付1金币，随后移走收费矮人；可以请求其他玩家代付，对方须明确同意。下一轮两名收费矮人恢复可用，但不会重新发初始金币。\n· 换装间：明信片预置于矿道中。第一名将其连通起点的玩家，立即与备用身份牌交换身份。\n· 隧道派对：使用明信片的另一面。第一次连通时，将所有玩家当前身份洗匀后重新分发。换装间与隧道派对只能选择一种。明信片占据两个相邻格，第一次连通任一部分便会触发。\n· 新目标：改用8张新目标中的黄金目标和随机4张其他目标，按五目标布局摆放。巨蛛使本轮立即结束并由破坏者获胜；钱袋立即给予发现者1或2金币；飞龙使发现者立即失去1金币（没有则不支付）；黑石没有效果。若同次连接多个目标，揭示顺序可能决定本轮结果。\n· 宝箱：将7张暗置路径和10张宝箱分别洗匀，随机配成4组，放在互不相邻的固定位置。连通时，先揭示路径并适配朝向，再执行宝箱效果。地图可以秘密查看路径及其下宝箱；落石可以移除整组暗牌。宝箱由触发者选择牌或对象，并立即执行下列对应效果：\n· 金币：立即获得1金币。\n· 加倍补给：本回合额外摸1张牌。\n· 无补给：本回合不摸牌。\n· 烧毁：弃置牌库顶的至多5张牌。\n· 检视：秘密查看另一名玩家的身份。\n· 禁用地图：本轮不能用地图查看目标，仍可查看宝箱。\n· 抽取手牌：在回合末从另一名玩家手中随机抽1张牌，代替正常摸牌。\n· 三选一：回合末摸3张牌，选择1张加入手牌，弃置其余牌，代替正常摸牌。\n· 弃牌寻宝：洗匀弃牌堆，查看顶端至多5张牌，选择1张加入手牌，本回合不再正常摸牌。\n· 移动目标：将一个暗置目标向远离起点的方向推移一格。\n\n变体（可选）：\n· 受损矿工：仅用于基础版。矿工获胜时，有工具损坏的矿工不能领取金币牌，但仍按全部矿工人数抽牌。分配时跳过受损矿工，因此完好矿工可能挑选多张；若全部受损，则无人领奖。\n锦标赛（5至9人）：\n使用金币片计分，不使用金币牌。根据人数分配以下身份：\n· 5人使用1名破坏者、3名矿工与1名贪婪矮人。\n· 6人使用2名破坏者、3名矿工与1名贪婪矮人。\n· 7人使用2名破坏者、3名矿工与2名贪婪矮人。\n· 8人使用3名破坏者、3名矿工与2名贪婪矮人。\n· 9人使用3名破坏者、4名矿工与2名贪婪矮人。\n每轮另抽一张随机基础路径放在起点与中间目标的正中。轮末按下列方式分配金币：\n· 矿工获胜时，打通者获得3金币，其他矿工各获得2金币。\n· 贪婪矮人打通黄金时，其独自获得4金币。\n· 破坏者获胜时，各获得3金币；5人局唯一破坏者获得4金币。",
			base: "基础版",
			expansion: "Saboteur 2",
			tournament: "锦标赛",
			mode: "游戏模式",
			extras: "可选内容",
			specials: "赛事行动牌",
			greedy: "贪婪矮人",
			toll: "隧道收费",
			postcard: "明信片",
			none: "不使用",
			costume: "换装间",
			party: "隧道派对",
			newGoals: "新目标",
			chests: "宝箱",
			sabotaged: "受损矿工",
			baseOnly: "仅用于基础版。",
			handCount: "手牌 {{n}} 张",
			zoomIn: "放大矿道",
			zoomOut: "缩小矿道",
			noKnowledge: "目前没有已知情报。",
			round: "第 {{n}} / 3 轮",
			deck: "牌库 {{n}}",
			discardPile: "弃牌 {{n}}",
			hand: "你的手牌",
			gold: "{{n}} 金币",
			role: "你的身份",
			turn: "轮到 {{name}}",
			wait: "等待 {{name}}",
			chooseCard: "选择一张手牌。",
			chooseTarget: "选择要作用的玩家或牌。",
			placePrompt: "选择矿道中的虚线落点。",
			revealPrompt: "选择先揭示的目标或宝箱。",
			orientPrompt: "选择路径朝向。",
			reactPrompt: "是否否决这次出牌？",
			resolve: "正在结算…",
			rewardPrompt: "选择一张金币牌。",
			roundEnd: "本轮结束",
			next: "开始下一轮",
			confirm: "确认",
			cancel: "取消",
			rotate: "旋转180°",
			recenter: "回到全景",
			details: "查看详情",
			close: "收起",
			discard: "弃牌",
			escape: "弃两张解除",
			tollAction: "设置收费",
			play: "打出",
			passReaction: "不否决",
			vetoAction: "打出否决",
			yes: "同意",
			no: "拒绝",
			keep: "保持原位",
			swap: "交换位置",
			skip: "结束剩余铺路",
			initialGold: "初始金币",
			result: "掘金结束",
			winner: "获胜",
			finalMine: "查看最终矿道",
			scores: "金币明细",
			again: "再来一局",
			lobby: "返回大厅",
			confirmAgain: "重新开局会结束当前结果展示。确定继续吗？",
			confirmLobby: "确定返回大厅吗？",
			known: "已知情报",
			hidden: "未揭示",
			start: "起点",
			goal: "目标",
			chest: "宝箱",
			path: "路径",
			toolCart: "矿车",
			toolLamp: "提灯",
			toolPick: "镐",
			trap: "陷阱",
			theft: "盗窃",
			broken: "已损坏",
			intact: "完好",
			blueDoor: "蓝门",
			greenDoor: "绿门",
			ladder: "梯子",
			crystal: "水晶",
			bridge: "独立通道",
			payPrompt: "{{name}} 请求你代付1金币。",
			payer: "支付者",
			choosePayer: "选择自己支付，或向其他玩家请求代付。",
			request: "请求代付",
			selectCount: "已选 {{n}} 张",
			tileAt: "矿道位置（{{x}}，{{y}}）",
			pickCard: "选择：{{name}}",
			actionAt: "{{name}}（{{x}}，{{y}}）",
			targetAction: "{{action}}：{{name}}",
			swapGoals: "目标（{{a}}）与（{{b}}）· {{choice}}",
			privateGold: "金币对他人保密",
			noMap: "本轮禁止地图查看目标",
			chain: "继续铺路 · 剩余 {{n}} 张",
			reasonGold: "黄金已连通",
			reasonSpider: "发现巨蛛",
			reasonEmpty: "手牌已耗尽",
			roundGain: "本轮 {{n}}",
			noTargets: "选择另一张牌，或弃牌。",
			stealCard: "选择一名玩家，随机抽取其一张手牌。",
			inspect: "选择一名玩家，秘密查看其身份。",
			moveGoal: "选择向远处推移的暗置目标。",
			trove: "选择一张加入手牌。",
			drawPick: "选择一张保留，其余弃置。",
			theftPrompt: "选择偷取1金币的对象。",
			noTheft: "不执行盗窃",
			viewRules: "牌面说明",
			errAction: "此动作当前不可执行。",
			roles: {
				miner: "矿工",
				saboteur: "破坏者",
				blue: "蓝队矿工",
				green: "绿队矿工",
				boss: "老板",
				profiteer: "投机者",
				geologist: "地质学家",
				greedy: "贪婪矮人"
			},
			cards: {
				path: "铺设路径",
				break: "破坏工具",
				repair: "修理工具",
				rockfall: "落石",
				map: "地图",
				theft: "盗窃",
				handsOff: "住手",
				trap: "陷阱",
				freedom: "自由",
				inspect: "检视",
				hats: "更换帽子",
				hands: "交换手牌",
				goals: "交换目标",
				trove: "宝藏堆",
				veto: "否决",
				reverse: "逆转方向",
				master: "工匠大师",
				pathfinder: "探路者",
				diversion: "改道"
			},
			goals: {
				gold: "黄金",
				rock: "黑石",
				spider: "巨蛛",
				sack: "钱袋",
				sackValue: "钱袋（+{{n}} 金币）",
				dragon: "飞龙"
			},
			chestEffects: {
				stealCard: "回合末从他人手中随机抽1张，代替摸牌。",
				extra: "本回合额外摸1张。",
				gold: "立即获得1金币。",
				skip: "本回合不摸牌。",
				burn: "弃置牌库顶5张。",
				inspect: "秘密查看他人的身份。",
				discard: "洗匀弃牌，从顶端至多5张中选1张；本回合不再摸牌。",
				noMap: "本轮不能再用地图查看目标。",
				draw: "回合末摸3张，保留1张并弃置其余，代替正常摸牌。",
				moveGoal: "将一个暗置目标向远离起点的方向推移一格。"
			},
			help: {
				path: "匹配相邻边缘，并使至少一条通道连通起点。",
				break: "破坏另一名玩家的一种工具。",
				repair: "修理一名玩家的一种匹配工具。",
				rockfall: "移除一张普通路径或宝箱路径。",
				map: "秘密查看暗置目标或宝箱。",
				theft: "放在自己面前，轮末可偷取1金币。",
				handsOff: "移除任意玩家面前的盗窃牌。",
				trap: "困住另一名玩家，使其不能铺路或领奖。",
				freedom: "移除一名玩家面前的陷阱。",
				inspect: "秘密查看另一名玩家的身份。",
				hats: "使选定玩家换取一张备用身份。",
				hands: "与另一名玩家交换手牌，对方摸1张。",
				goals: "不看牌面，决定是否交换两个暗置目标。",
				trove: "从弃牌顶至多5张中选1张，代替正常摸牌。",
				veto: "在他人卡牌生效前打出，取消那张牌；双方各摸1张。",
				reverse: "反转本轮的行动和金币分配方向。",
				master: "修理任意一种工具。",
				pathfinder: "依次铺设两张路径，回合末摸2张。",
				diversion: "将最近铺设的路径移到另一个合法位置。"
			},
			events: {
				path: "{{name}} 铺设了路径。",
				action: "{{name}} 使用了{{card}}。",
				discard: "{{name}} 弃置了手牌。",
				reveal: "{{name}} 揭示了{{card}}。",
				reward: "本轮金币已分配。",
				toll: "{{name}} 设置了收费。",
				costume: "{{name}} 进入换装间并更换身份。",
				party: "隧道派对使所有玩家重新分配了身份。",
				veto: "{{name}} 否决了出牌。",
				round: "新的掘金轮次开始了。"
			}
		},
		en: {
			name: "Saboteur: 20th Anniversary Edition",
			desc: "Keep your role secret as you dig, sabotage and compete for gold.",
			rules: "Objective:\nPlay three rounds. The player with the most gold wins; tied players share victory. Roles are redealt each round, while gold carries over.\n\nBase game setup (3–10 players):\nLeave seven card widths between the start and the three face-down goals. One goal contains gold; two contain black rocks. Shuffle 40 path cards with 27 action cards. Deal six cards each with 3–5 players, five with 6–7, or four with 8–10. Never reshuffle the discard pile when the deck runs out.\nShuffle the following role pool and deal one role to each player, leaving one unused:\n· 3 players: 1 Saboteur and 3 Miners; 4 players: 1 Saboteur and 4 Miners.\n· 5 players: 2 Saboteurs and 4 Miners; 6 players: 2 Saboteurs and 5 Miners.\n· 7 players: 3 Saboteurs and 5 Miners; 8 players: 3 Saboteurs and 6 Miners.\n· 9 players: 3 Saboteurs and 7 Miners; 10 players: 4 Saboteurs and 7 Miners.\nMiners try to connect the start to the gold. Saboteurs try to exhaust everyone's cards before this happens. Your role and gold remain private until the appropriate reveal. In this digital edition, the first seat begins; play then proceeds clockwise.\n\nTaking a turn:\nChoose one action, then draw one card:\n· Play a path card. Keep it upright; a 180° rotation is allowed, but a 90° rotation is not. At least one passage must connect to the start, and every edge must match adjacent face-up cards. Tunnels may extend in any direction.\n· Play an action card and resolve its effect.\n· Discard one card to pass.\nPlayers with empty hands are skipped once the draw deck is empty. Maps, inspections and private card choices are only shown to the acting player. If several hidden goals or chests become connected together, choose their reveal order. Orient each revealed path to match as many adjacent edges as possible; goal cards may exceptionally have mismatched edges when no complete match is possible.\n\nBase action cards:\n· Sabotage: place a broken tool in front of another player. A tool cannot be broken twice. A player with any broken cart, lantern or pick cannot play paths.\n· Repair: remove one matching broken tool from yourself or another player. A repair showing two tools still repairs only one. Repairs cannot be played preemptively.\n· Rockfall: remove a path card. The start, goals and postcard cannot be removed. Discard both the removed path and the Rockfall.\n· Map: secretly inspect one face-down goal and return it to the same position.\n\nEnding a base round and distributing gold:\nWhen the gold is connected, the Miners win. Draw as many gold cards as there are Miners in the round. The Miner who connected the gold chooses one and passes the rest in the opposite direction to the turn order. If a Saboteur completed the path, begin with the first Miner to their right. There are sixteen 1-gold cards, eight 2-gold cards and four 3-gold cards.\nIf every hand is exhausted without reaching gold, the Saboteurs win. A sole Saboteur receives 4 gold; two or three Saboteurs each receive 3; four each receive 2. If no Saboteur is present, nobody receives a reward. If the remaining denominations cannot pay a fixed reward, exchange equal values with previously awarded gold cards; no player’s gold total changes.\nReveal all roles at the end of the round. Prepare fresh roles, tunnels and hands. The player to the left of the last player to act starts the next round. Compare total gold after the third round.\n\nSaboteur 2 (2–12 players):\nShuffle all base and expansion path and action cards, set aside the top ten each round, and deal six cards each. Shuffle all fifteen roles: four Blue Miners, four Green Miners, three Saboteurs, two Geologists, one Boss and one Profiteer. The undealt roles form a reserve deck.\n· Blue and Green Miners compete for the gold. If a Miner connects it and their team has an accessible route, only that team wins. If that team is blocked by an opposing door, the other team wins if it can reach the gold. If another role completes the connection, all teams with an accessible route win.\n· Blue doors admit Blue Miners; green doors admit Green Miners. Doors only affect victory, not path placement. The Boss, Profiteer and Geologists pass any door.\n· The Boss wins with the winning Miners but receives 1 less gold. The Profiteer wins with either winning side but receives 2 less. If both teams are blocked, the Boss and Profiteer can still win; a lone Boss gets 4 gold, or a lone Profiteer gets 3. A Profiteer also wins alone for 3 gold if no gold connection and no Saboteurs exist.\n· Each Geologist receives gold for all visible crystals in the tunnel network. Two Geologists split that total, rounding down.\nOn a turn you may instead discard one to three cards and draw the same number, or discard two cards to remove any one action card from in front of yourself, then draw only one.\n\nExpansion paths and actions:\n· Bridges and double bends contain independent passages. You cannot turn at a crossing. At least one passage must connect to the start.\n· Ladders connect directly to the start and all other ladders. They may be placed beside a path without another connection to the start, but never beside a goal. Adjacent edges must still match.\n· Theft: place it in front of yourself. After rewards, steal 1 gold from another player if they have any. The most recently played Theft acts first; the remaining thieves follow clockwise.\n· Hands off: remove one face-up Theft.\n· Trapped: place it in front of another player. A trapped player cannot build paths, receive any round reward or carry out a Theft. They do not count in the winning group.\n· Freedom: remove one Trapped card.\n· Inspection: secretly inspect another player's role.\n· Change Hats: choose any player, including yourself. They draw the top reserve role and place their old role at the bottom.\n· Swap Hands: exchange all cards with another player. That player draws one card; you do not.\nEach eligible winner receives gold according to the winning group's size: one winner gets 5; two get 4 each; three get 3 each; four get 2 each; five or more get 1 each. Apply the Boss and Profiteer reductions afterwards, with a minimum of zero.\n\nWorld Championship cards (optional):\n· Greedy Dwarf (2016): base game only. Replace one Miner in the role pool. This dwarf wins 4 gold alone only if they personally connect the gold; otherwise they receive nothing.\n· Goal Swap (2017): choose two hidden goals and decide whether to exchange them, without looking at their faces.\n· Treasure Trove (2018): instead of drawing, inspect up to five cards from the top of the discard pile and take one. Return the rest in their original order. The Trove just played cannot take itself.\n· Veto (2019): react to another player's path or action before it resolves. Discard both cards. The original player draws one and ends their turn, then the vetoing player draws one. Other players follow the prompt to veto the card or allow it to resolve.\n· Reverse (2020): reverse the turn order for the remainder of the round. Base-game gold distribution reverses too.\n· Master Crafter (2021): repair any one broken tool for any player.\n· Pathfinder (2022): play two paths consecutively, then draw two cards. You retain one fewer card. If no legal path remains, end the remaining build sequence.\n· Diversion (2023): move the last path played to a different legal position, optionally rotating it 180°.\n\nMini expansions (optional):\n· Tunnel Toll: each player begins the game with one extra gold. Two toll dwarves are available each round, each used once. Discard one card to place an unused dwarf at an open tunnel end; do not draw. To build there, pay 1 gold to its owner and remove the dwarf. You may request another player to pay, but they must consent. Dwarves reset next round; starting gold is not given again.\n· Costume Department: a postcard is placed in the network. The first player to connect it to the start must immediately exchange their role with the reserve.\n· Tunnel Party: use the other side of the postcard. On the first connection, shuffle all current player roles and redeal them. Choose only one postcard side. The postcard occupies two adjacent cells; connecting either part triggers it.\n· New Goals: use the gold goal and four random cards from the other seven, in the five-goal layout. A giant spider immediately ends the round with a Saboteur victory. Sacks immediately give the explorer 1 or 2 gold. A dragon immediately takes 1 gold if they have any. Rocks do nothing. Reveal order can decide the outcome if several goals are reached together.\n· Treasure Chests: separately shuffle seven hidden paths and ten chests, then pair four of each at fixed nonadjacent positions. When connected, reveal and orient the path first, then resolve its chest. A Map may inspect both layers; a Rockfall may remove an entire hidden pair. The explorer chooses cards and targets for the matching effect:\n· Gold: immediately gain 1 gold.\n· Extra supply: draw one additional card this turn.\n· No supply: do not draw this turn.\n· Burn: discard up to five cards from the top of the deck.\n· Inspect: secretly inspect another player’s role.\n· No maps: maps cannot inspect goals for the rest of the round; they can still inspect chests.\n· Take a card: at turn end, take a random card from another player instead of drawing.\n· Choose from three: at turn end, draw three cards, keep one and discard the rest instead of the normal draw.\n· Discard treasure: shuffle the discard pile, inspect its top five cards and keep one; skip the normal draw.\n· Move a goal: push a hidden goal one space further from the start.\n\nVariants (optional):\n· Sabotaged Dwarf: base game only. Broken-tool Miners do not receive gold cards after a Miner victory. Still draw for the full Miner count, skipping damaged Miners when passing cards. Eligible Miners may receive several cards; if all are damaged, none receives a reward.\nTournament (5–9 players):\nUse gold pieces instead of gold cards. Deal the following roles:\n· 5 players use 1 Saboteur, 3 Miners and 1 Greedy Dwarf.\n· 6 players use 2 Saboteurs, 3 Miners and 1 Greedy Dwarf.\n· 7 players use 2 Saboteurs, 3 Miners and 2 Greedy Dwarves.\n· 8 players use 3 Saboteurs, 3 Miners and 2 Greedy Dwarves.\n· 9 players use 3 Saboteurs, 4 Miners and 2 Greedy Dwarves.\nPlace a random base path midway between start and central goal each round. Distribute gold as follows:\n· After a Miner victory the connecting Miner receives 3 gold; other Miners receive 2 gold each.\n· A Greedy Dwarf who connects the gold receives 4 gold alone.\n· Winning Saboteurs receive 3 gold each, except the sole Saboteur in a five-player game receives 4 gold.",
			base: "Base game",
			expansion: "Saboteur 2",
			tournament: "Tournament",
			mode: "Game mode",
			extras: "Optional content",
			specials: "Championship actions",
			greedy: "Greedy Dwarf",
			toll: "Tunnel Toll",
			postcard: "Postcard",
			none: "None",
			costume: "Costume Department",
			party: "Tunnel Party",
			newGoals: "New Goals",
			chests: "Treasure Chests",
			sabotaged: "Sabotaged Dwarf",
			baseOnly: "Base game only.",
			handCount: "{{n}} cards",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			noKnowledge: "No information known yet.",
			round: "Round {{n}} / 3",
			deck: "Deck {{n}}",
			discardPile: "Discard {{n}}",
			hand: "Your hand",
			gold: "{{n}} gold",
			role: "Your role",
			turn: "{{name}}'s turn",
			wait: "Waiting for {{name}}",
			chooseCard: "Choose a card.",
			chooseTarget: "Choose the player or card to affect.",
			placePrompt: "Choose a dashed space in the mine.",
			revealPrompt: "Choose which goal or chest to reveal first.",
			orientPrompt: "Choose the path orientation.",
			reactPrompt: "Veto this card before it resolves?",
			resolve: "Resolving…",
			rewardPrompt: "Choose a gold card.",
			roundEnd: "Round complete",
			next: "Start next round",
			confirm: "Confirm",
			cancel: "Cancel",
			rotate: "Rotate 180°",
			recenter: "Fit mine",
			details: "Details",
			close: "Close",
			discard: "Discard",
			escape: "Discard two to remove",
			tollAction: "Set a toll",
			play: "Play",
			passReaction: "Allow",
			vetoAction: "Play Veto",
			yes: "Agree",
			no: "Decline",
			keep: "Keep positions",
			swap: "Swap positions",
			skip: "End remaining paths",
			initialGold: "Starting gold",
			result: "The dig is over",
			winner: "Winner",
			finalMine: "View final mine",
			scores: "Gold breakdown",
			again: "Play again",
			lobby: "Back to lobby",
			confirmAgain: "Start a new game and leave these results?",
			confirmLobby: "Return to the lobby?",
			known: "Known information",
			hidden: "Hidden",
			start: "Start",
			goal: "Goal",
			chest: "Chest",
			path: "Path",
			toolCart: "Cart",
			toolLamp: "Lantern",
			toolPick: "Pick",
			trap: "Trapped",
			theft: "Theft",
			broken: "Broken",
			intact: "Intact",
			blueDoor: "Blue door",
			greenDoor: "Green door",
			ladder: "Ladder",
			crystal: "Crystal",
			bridge: "Separate passages",
			payPrompt: "{{name}} requests 1 gold for a toll.",
			payer: "Payer",
			choosePayer: "Pay yourself or request a sponsor.",
			request: "Request payment",
			selectCount: "{{n}} selected",
			tileAt: "Mine space ({{x}}, {{y}})",
			pickCard: "Choose {{name}}",
			actionAt: "{{name}} ({{x}}, {{y}})",
			targetAction: "{{action}}: {{name}}",
			swapGoals: "Goals ({{a}}) and ({{b}}) · {{choice}}",
			privateGold: "Your gold is private",
			noMap: "Maps cannot inspect goals this round",
			chain: "Continue building · {{n}} left",
			reasonGold: "Gold connected",
			reasonSpider: "Giant spider found",
			reasonEmpty: "Hands exhausted",
			roundGain: "Round {{n}}",
			noTargets: "Choose another card, or discard.",
			stealCard: "Choose a player and take one random hand card.",
			inspect: "Choose a player to inspect their role.",
			moveGoal: "Choose a hidden goal to push away.",
			trove: "Choose one card for your hand.",
			drawPick: "Keep one card and discard the rest.",
			theftPrompt: "Choose a player to steal 1 gold from.",
			noTheft: "Skip theft",
			viewRules: "Card details",
			errAction: "That action is not available now.",
			roles: {
				miner: "Gold Miner",
				saboteur: "Saboteur",
				blue: "Blue Miner",
				green: "Green Miner",
				boss: "Boss",
				profiteer: "Profiteer",
				geologist: "Geologist",
				greedy: "Greedy Dwarf"
			},
			cards: {
				path: "Build path",
				break: "Break tool",
				repair: "Repair tool",
				rockfall: "Rockfall",
				map: "Map",
				theft: "Theft",
				handsOff: "Hands off",
				trap: "Trapped",
				freedom: "Freedom",
				inspect: "Inspection",
				hats: "Change Hats",
				hands: "Swap Hands",
				goals: "Goal Swap",
				trove: "Treasure Trove",
				veto: "Veto",
				reverse: "Reverse",
				master: "Master Crafter",
				pathfinder: "Pathfinder",
				diversion: "Diversion"
			},
			goals: {
				gold: "Gold",
				rock: "Rock",
				spider: "Giant spider",
				sack: "Gold sack",
				sackValue: "Gold sack (+{{n}} gold)",
				dragon: "Dragon"
			},
			chestEffects: {
				stealCard: "Take a random card from another player's hand instead of drawing.",
				extra: "Draw one additional card this turn.",
				gold: "Immediately gain 1 gold.",
				skip: "Do not draw this turn.",
				burn: "Discard the top five deck cards.",
				inspect: "Secretly inspect another player's role.",
				discard: "Shuffle the discard pile and choose one of its top five cards; skip the normal draw.",
				noMap: "Maps cannot inspect goals for the rest of this round.",
				draw: "At turn end, draw three and keep one instead of the normal draw.",
				moveGoal: "Push one hidden goal one space further from the start."
			},
			help: {
				path: "Match adjacent edges and connect at least one passage to the start.",
				break: "Break one of another player's tools.",
				repair: "Repair one matching tool for any player.",
				rockfall: "Remove an ordinary path or chest path.",
				map: "Secretly inspect a hidden goal or chest.",
				theft: "Keep in front of yourself to steal 1 gold at round end.",
				handsOff: "Remove any player's Theft.",
				trap: "Trap another player, preventing paths and rewards.",
				freedom: "Remove a Trapped card.",
				inspect: "Secretly inspect another player's role.",
				hats: "The chosen player exchanges their role with the reserve.",
				hands: "Swap hands with another player; they draw one.",
				goals: "Decide whether to exchange two hidden goals without looking.",
				trove: "Choose one of the top five discards instead of drawing.",
				veto: "Cancel another player's card before it resolves; each draws one.",
				reverse: "Reverse this round’s turns and gold passing.",
				master: "Repair any one broken tool.",
				pathfinder: "Play two paths in succession, then draw two.",
				diversion: "Move the last path played to a different legal space."
			},
			events: {
				path: "{{name}} built a path.",
				action: "{{name}} played {{card}}.",
				discard: "{{name}} discarded cards.",
				reveal: "{{name}} revealed {{card}}.",
				reward: "Round rewards have been distributed.",
				toll: "{{name}} set a toll.",
				costume: "{{name}} entered the Costume Department and changed role.",
				party: "The Tunnel Party redealt all player roles.",
				veto: "{{name}} vetoed the card.",
				round: "A new round has begun."
			}
		}
	}
};
//#endregion
export { Et as default };
