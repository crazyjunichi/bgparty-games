import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { IconBack as d, IconBot as f, IconClose as p, IconExpand as m, IconLog as h } from "@bgparty/sdk/icons";
import { LogSheet as g, LogTicker as _ } from "@bgparty/sdk/ui/log-sheet";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { usePrefersReducedMotion as x } from "@bgparty/sdk/fx/use-reduced-motion";
import { Floater as S, FlySprite as C, PulseBox as w } from "@bgparty/sdk/fx/primitives";
import { seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { Confetti as te } from "@bgparty/sdk/ui/confetti";
//#region src/games/underfallingskies/data.ts
var T = { t: "empty" }, E = (e) => ({
	t: "explosion",
	n: e
}), D = {
	t: "arrow",
	dir: -1
}, O = {
	t: "arrow",
	dir: 1
}, k = { t: "ship" }, A = { t: "none" }, j = [
	{
		easy: {
			research: [
				11,
				3,
				1,
				5
			],
			cells: [
				[
					T,
					T,
					T,
					O,
					T
				],
				[
					T,
					D,
					O,
					T,
					T
				],
				[
					k,
					T,
					E(1),
					T,
					T
				],
				[
					E(2),
					T,
					D,
					T,
					E(4)
				]
			],
			actions: [
				{
					t: "reinforce",
					n: 1
				},
				{
					t: "excavator",
					n: 2
				},
				{
					t: "reinforce",
					n: 1
				},
				A
			],
			skullRow: null
		},
		threat: {
			research: [
				12,
				1,
				5,
				3
			],
			cells: [
				[
					T,
					E(1),
					T,
					T,
					T
				],
				[
					T,
					T,
					D,
					O,
					T
				],
				[
					O,
					T,
					T,
					T,
					E(2)
				],
				[
					T,
					D,
					E(3),
					k,
					T
				]
			],
			actions: [
				{
					t: "excavator",
					n: 1
				},
				{
					t: "reinforce",
					n: 2
				},
				{
					t: "excavator",
					n: 2
				},
				{ t: "damage" }
			],
			skullRow: null
		}
	},
	{
		easy: {
			research: [
				3,
				1,
				6,
				1
			],
			cells: [
				[
					k,
					O,
					T,
					E(4),
					T
				],
				[
					T,
					k,
					T,
					T,
					T
				],
				[
					E(4),
					E(3),
					T,
					D,
					E(2)
				],
				[
					O,
					T,
					E(6),
					T,
					D
				]
			],
			actions: [
				{
					t: "reinforce",
					n: 1
				},
				{
					t: "excavator",
					n: 1
				},
				{
					t: "research",
					n: 1
				},
				A
			],
			skullRow: null
		},
		threat: {
			research: [
				2,
				4,
				3,
				2
			],
			cells: [
				[
					O,
					T,
					E(2),
					T,
					D
				],
				[
					k,
					k,
					T,
					D,
					E(3)
				],
				[
					E(4),
					O,
					T,
					E(5),
					T
				],
				[
					T,
					D,
					O,
					T,
					k
				]
			],
			actions: [
				{
					t: "excavator",
					n: 3
				},
				{
					t: "research",
					n: 2
				},
				{
					t: "reinforce",
					n: 2
				},
				{
					t: "research",
					n: 1
				}
			],
			skullRow: null
		}
	},
	{
		easy: {
			research: [
				2,
				3,
				1,
				4
			],
			cells: [
				[
					T,
					T,
					E(4),
					O,
					T
				],
				[
					E(5),
					T,
					D,
					T,
					T
				],
				[
					T,
					k,
					O,
					T,
					E(6)
				],
				[
					k,
					E(3),
					T,
					E(4),
					k
				]
			],
			actions: [
				{
					t: "research",
					n: 1
				},
				{
					t: "reinforce",
					n: 1
				},
				A,
				A
			],
			skullRow: 3
		},
		threat: {
			research: [
				7,
				3,
				1,
				3
			],
			cells: [
				[
					E(6),
					T,
					D,
					T,
					k
				],
				[
					k,
					E(4),
					E(7),
					O,
					T
				],
				[
					T,
					O,
					T,
					k,
					E(7)
				],
				[
					T,
					T,
					k,
					E(4),
					T
				]
			],
			actions: [
				{ t: "damage" },
				A,
				A,
				A
			],
			skullRow: 2
		}
	},
	{
		easy: {
			research: [
				1,
				3,
				1,
				3
			],
			cells: [
				[
					E(3),
					O,
					T,
					k,
					T
				],
				[
					T,
					E(6),
					T,
					D,
					E(4)
				],
				[
					O,
					T,
					E(3),
					T,
					D
				],
				[
					T,
					E(5),
					k,
					E(4),
					T
				]
			],
			actions: [
				A,
				A,
				A,
				A
			],
			skullRow: null
		},
		threat: {
			research: [
				5,
				1,
				2,
				3
			],
			cells: [
				[
					k,
					E(5),
					k,
					T,
					D
				],
				[
					T,
					T,
					E(4),
					k,
					E(5)
				],
				[
					E(4),
					k,
					T,
					E(6),
					k
				],
				[
					k,
					E(7),
					k,
					k,
					T
				]
			],
			actions: [
				A,
				A,
				A,
				A
			],
			skullRow: null
		}
	}
], ne = (e) => ({
	room: e,
	type: "aa",
	cost: 0,
	mod: 0
}), M = (e, t, n, r = 0) => ({
	room: e,
	type: t,
	cost: n,
	mod: r
}), N = [
	[
		ne(0),
		ne(1),
		ne(2),
		ne(3),
		ne(4)
	],
	[
		M(5, "fighter", 1, -1),
		M(6, "research", 2),
		M(7, "tunnel", 0),
		M(8, "energy", 0, -3),
		M(8, "energy", 0, -3)
	],
	[
		M(9, "energy", 0),
		M(10, "fighter", 2),
		M(10, "fighter", 2),
		M(11, "research", 1, -1),
		M(12, "garage", 0)
	],
	[
		M(13, "research", 0, -1),
		M(14, "tunnel", 0),
		M(15, "research", 2),
		M(15, "research", 2),
		M(16, "fighter", 2)
	],
	[
		M(17, "fighter", 2, 1),
		M(18, "energy", 0, 1),
		M(19, "fighter", 1),
		M(20, "tunnel", 0),
		M(21, "research", 1)
	],
	[
		M(22, "tunnel", 0),
		M(23, "research", 2),
		M(23, "research", 2),
		M(23, "research", 2),
		M(24, "tunnel", 0)
	]
], P = [
	[2, 4],
	[2, 3],
	[2, 2],
	[2, 1],
	[2, 0],
	[3, 0],
	[3, 1],
	[3, 2],
	[3, 3],
	[3, 4],
	[4, 4],
	[4, 3],
	[4, 2],
	[4, 1],
	[4, 0],
	[5, 0],
	[5, 1],
	[5, 2],
	[5, 3],
	[5, 4]
], F = {
	id: "underfallingskies",
	tier: "beta",
	mechanics: ["dice-rolling"],
	interactionTags: [],
	nameKey: "games.underfallingskies.name",
	descKey: "games.underfallingskies.desc",
	rulesKey: "games.underfallingskies.rules",
	icon: "🛸",
	iconImg: "games/underfallingskies.webp",
	rulesUrl: {
		zh: "https://rules.bgparty.uuppi.com/underfallingskies/zh.pdf",
		en: "https://rules.bgparty.uuppi.com/underfallingskies/en.pdf"
	},
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#405f72",
	releasedAt: "2026-09-16",
	search: {
		py: "zhui kong zhi xia",
		init: "zkzx"
	},
	hotseat: "cover"
}, re = t.int().min(0).max(5), I = t.int().min(0).max(4), ie = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("placeDie"),
		die: t.int().min(0).max(4),
		row: re,
		col: I
	}),
	t.object({
		type: t.literal("resolveRoom"),
		row: re,
		col: I,
		use: t.boolean().default(!0),
		research: t.int().min(0).max(16).default(0)
	}),
	t.object({ type: t.literal("endRooms") }),
	t.object({
		type: t.literal("chooseSpawn"),
		col: I
	})
]), ae = t.object({ threat: t.int().min(0).max(4).catch(1) }).default({ threat: 1 }), oe = t.object({
	id: t.int(),
	color: t.enum(["p", "w"]),
	col: I,
	row: t.int().min(0).max(22)
}), L = t.object({
	value: t.int().min(1).max(6),
	color: t.enum(["g", "w"]),
	placed: t.object({
		row: re,
		col: I
	}).nullable()
}), se = t.object({
	round: t.int().positive(),
	kind: t.enum(/* @__PURE__ */ "roll.place.descend.noDescent.drift.blocked.shadow.cityHit.reroll.roomsStart.pay.energy.research.shoot.noTargets.excavate.discard.aa.tunnel.endRooms.mothership.excavatorBack.researchBack.reinforce.noReinforce.noAction.damage.spawn.spawnChoice.spawnFull.win.lose".split(".")),
	params: t.record(t.string(), t.union([t.string(), t.number()])),
	room: t.enum([
		"aa",
		"energy",
		"research",
		"fighter",
		"tunnel",
		"garage",
		"excavator"
	]).optional()
}), ce = t.object({
	phase: t.enum([
		"dice",
		"rooms",
		"mothership",
		"done"
	]),
	resolving: t.boolean(),
	log: t.array(se),
	round: t.int().min(1),
	threatened: t.tuple([
		t.boolean(),
		t.boolean(),
		t.boolean(),
		t.boolean()
	]),
	dice: t.tuple([
		L,
		L,
		L,
		L,
		L
	]),
	ships: t.array(oe),
	momRow: t.int().min(0).max(16),
	skullRow: t.int(),
	poolPurple: t.int().nonnegative(),
	poolWhite: t.int().nonnegative(),
	whiteReserve: t.int().min(0).max(4),
	excavator: t.int().min(0).max(19),
	energy: t.int().min(0).max(7),
	damage: t.int().min(0).max(7),
	research: t.int().min(0).max(16),
	pendingSpawn: t.array(I).nullable(),
	result: t.enum(["win", "lose"]).nullable(),
	loseReason: t.string().nullable()
}), le = t.object({}), R = {
	place: 600,
	normal: 1300,
	move: 1100,
	room: 1600,
	end: 2e3
};
function z(e) {
	return e === "place" ? R.place : e === "win" || e === "lose" ? R.end : [
		"descend",
		"drift",
		"mothership",
		"excavate",
		"excavatorBack",
		"spawn"
	].includes(e) ? R.move : [
		"energy",
		"research",
		"shoot",
		"noTargets",
		"pay"
	].includes(e) ? R.room : R.normal;
}
var B = (e) => ({ code: e });
function ue(e, t) {
	return e[t] ? j[t].threat : j[t].easy;
}
function de(e, t, n) {
	return ue(e, Math.floor((t - 1) / 4)).cells[(t - 1) % 4][n];
}
function fe(e) {
	return e[2] ? 11 : 12;
}
function pe(e) {
	return [
		0,
		1,
		2,
		3
	].flatMap((t) => ue(e, t).research).reverse();
}
function me(e, t) {
	return ue(e, Math.floor((t - 1) / 4)).actions[(t - 1) % 4];
}
var he = (e, t) => P.findIndex(([n, r]) => n === e && r === t);
function V(e, t, n) {
	if (t <= 1) return !0;
	let r = he(t, n);
	return r >= 0 && r <= e;
}
function ge(t) {
	t.dice = [
		"g",
		"g",
		"g",
		"w",
		"w"
	].map((n) => ({
		value: e(t.seed, t.rngCursor++, 6) + 1,
		color: n,
		placed: null
	}));
}
function H(e, t, n, r = {}, i = {}, a) {
	let o = {
		round: e.round,
		kind: n,
		params: r,
		...a ? { room: a } : {}
	};
	e.log.push(o), t.push({
		kind: n,
		data: {
			...i,
			params: r,
			...a ? { room: a } : {}
		}
	}), e.beatMs = z(n);
}
function _e(e, t, n) {
	e.result = t, e.loseReason = n ?? null, e.pendingSpawn = null, e.queue = [{ type: "finishGame" }], e.ships = e.ships.filter((e) => e.row <= 16);
}
function ve(e, t) {
	let n = e.momRow;
	e.momRow += 1;
	let r = e.ships.filter((t) => t.row === e.momRow);
	e.ships = e.ships.filter((t) => t.row !== e.momRow);
	for (let t of r) t.color === "p" ? e.poolPurple += 1 : e.poolWhite += 1;
	H(e, t, "mothership", {
		from: n,
		to: e.momRow,
		n: r.length
	}, {
		from: n,
		to: e.momRow
	}), e.momRow >= fe(e.threatened) && _e(e, "lose", "games.underfallingskies.loseMothership");
}
function ye(e, t, n) {
	let r = e.poolPurple > 0 ? "p" : "w", i = e.nextShipId++;
	e.ships.push({
		id: i,
		color: r,
		col: t,
		row: e.momRow
	}), r === "p" ? --e.poolPurple : --e.poolWhite, H(e, n, "spawn", {
		color: r,
		col: t + 1,
		row: e.momRow
	}, {
		id: i,
		color: r,
		col: t,
		row: e.momRow
	}), e.queue = [{ type: "spawn" }];
}
function be(e, t) {
	return Math.min(...e.ships.filter((e) => e.col === t).map((e) => e.row)) - e.momRow;
}
function xe(t, n, r) {
	let i = {
		seed: r,
		rngCursor: 0,
		host: n[0],
		phase: "dice",
		round: 1,
		threat: t.threat,
		threatened: [
			!1,
			!1,
			!1,
			!1
		],
		dice: [],
		ships: [
			0,
			1,
			2,
			3,
			4
		].map((e) => ({
			id: e,
			color: "p",
			col: e,
			row: 0
		})),
		nextShipId: 5,
		momRow: 0,
		poolPurple: 0,
		poolWhite: 0,
		whiteReserve: 4,
		excavator: 0,
		energy: 2,
		damage: 0,
		research: 0,
		pendingSpawn: null,
		result: null,
		loseReason: null,
		queue: [],
		beatMs: 0,
		log: []
	}, a = [
		0,
		1,
		2,
		3
	];
	for (let t = a.length - 1; t > 0; t--) {
		let n = e(i.seed, i.rngCursor++, t + 1);
		[a[t], a[n]] = [a[n], a[t]];
	}
	for (let e = 0; e < t.threat; e++) i.threatened[a[e]] = !0;
	return ge(i), i.log.push({
		round: 1,
		kind: "roll",
		params: {
			n: 1,
			dice: i.dice.map((e) => e.value).join(" · ")
		}
	}), { state: i };
}
function Se(e, t, n) {
	let r = e.dice[t.die];
	if (r.placed) return B("games.underfallingskies.errDiePlaced");
	if (e.dice.some((e) => e.placed?.col === t.col)) return B("games.underfallingskies.errColTaken");
	let i = N[t.row][t.col];
	if (i.type === "garage") return B("games.underfallingskies.errGarage");
	let a = !V(e.excavator, t.row, t.col);
	if (a) {
		let n = he(t.row, t.col);
		if (n < 0) return B("games.underfallingskies.errNotOnPath");
		if (r.value < n - e.excavator) return B("games.underfallingskies.errExcavatorFar");
		if (e.dice.some((t) => t.placed && !V(e.excavator, t.placed.row, t.placed.col))) return B("games.underfallingskies.errTwoAhead");
	}
	return r.placed = {
		row: t.row,
		col: t.col
	}, H(e, n, "place", {
		value: r.value,
		row: t.row + 1,
		col: t.col + 1
	}, {
		row: t.row,
		col: t.col,
		die: t.die,
		value: r.value,
		color: r.color
	}, a ? "excavator" : i.type), e.queue = [{
		type: "moveShips",
		col: t.col,
		distance: r.value - +(i.type === "aa")
	}], r.color === "w" && e.queue.push({ type: "reroll" }), e.queue.push({ type: "finishPlacement" }), null;
}
function Ce(e, t, n, r) {
	let i = 0;
	for (let a of e.dice) a.placed && (r ? a.placed.row === t && a.placed.col === n : N[a.placed.row][a.placed.col].room === N[t][n].room) && (a.placed = null, i += 1);
	return i;
}
function we(e, t, n) {
	let { row: r, col: i, excavate: a } = t, o = N[r][i], s = e.dice.filter((e) => e.placed && N[e.placed.row][e.placed.col].room === o.room).reduce((e, t) => e + t.value, o.mod);
	Ce(e, r, i, a);
	let c = {
		row: r,
		col: i
	};
	if (a) {
		let t = e.excavator;
		e.excavator = he(r, i), H(e, n, "excavate", {
			from: t,
			to: e.excavator,
			n: e.excavator - t
		}, {
			...c,
			from: t,
			to: e.excavator
		});
	} else if (o.type === "energy") {
		let t = e.energy;
		e.energy = Math.max(0, Math.min(7, t + s));
		let r = e.energy - t;
		H(e, n, "energy", {
			value: s,
			from: t,
			to: e.energy,
			delta: r > 0 ? `+${r}` : r
		}, c);
	} else if (o.type === "research") {
		let r = e.research;
		e.research += t.research, H(e, n, "research", {
			from: r,
			to: e.research,
			n: t.research
		}, c), e.research >= 16 && _e(e, "win");
	} else if (o.type === "fighter") {
		let t = e.ships.filter((t) => {
			if (t.row < 1 || t.row > 16) return !1;
			let n = de(e.threatened, t.row, t.col);
			return n.t === "explosion" && n.n <= s;
		}), r = t.filter((e) => e.color === "p").length;
		e.ships = e.ships.filter((e) => !t.some((t) => t.id === e.id)), e.poolPurple += r, H(e, n, t.length ? "shoot" : "noTargets", {
			value: s,
			n: t.length,
			purple: r,
			white: t.length - r
		}, {
			...c,
			ships: t.map((e) => ({ ...e }))
		});
	}
}
function Te(e, t, n) {
	let { row: r, col: i } = t;
	if (!e.dice.some((e) => e.placed?.row === r && e.placed.col === i)) return B("games.underfallingskies.errNoDie");
	let a = N[r][i], o = !V(e.excavator, r, i), s = o ? "excavator" : a.type;
	if (e.queue = [{ type: "release" }], !t.use || !o && (a.type === "aa" || a.type === "tunnel")) {
		let t = Ce(e, r, i, o);
		return H(e, n, !o && a.type === "aa" ? "aa" : !o && a.type === "tunnel" ? "tunnel" : "discard", { n: t }, {
			row: r,
			col: i
		}, s), null;
	}
	if (!o) {
		if (!N.every((t, n) => t.every((t, r) => t.room !== a.room || e.dice.some((e) => e.placed?.row === n && e.placed.col === r)))) return B("games.underfallingskies.errRoomIncomplete");
		if (a.type === "research") {
			let n = e.dice.filter((e) => e.placed && N[e.placed.row][e.placed.col].room === a.room).reduce((e, t) => e + t.value, a.mod), r = pe(e.threatened).slice(e.research, e.research + t.research).reduce((e, t) => e + t, 0);
			if (t.research < 1 || e.research + t.research > 16 || r > n) return B("games.underfallingskies.errResearchCost");
		}
	}
	let c = o ? 1 : a.cost;
	if (e.energy < c) return B("games.underfallingskies.errNoEnergy");
	let l = {
		type: "roomEffect",
		row: r,
		col: i,
		research: t.research,
		excavate: o
	};
	if (c > 0) {
		let t = e.energy;
		e.energy -= c, H(e, n, "pay", {
			from: t,
			to: e.energy,
			cost: c
		}, {
			row: r,
			col: i
		}, s), e.queue.unshift(l);
	} else we(e, l, n);
	return null;
}
function Ee(t, n) {
	for (; t.queue.length && n.length === 0;) {
		let r = t.queue.shift();
		if (r.type !== "release") {
			if (r.type === "finishGame") {
				let e = t.result === "win" ? "win" : "lose";
				t.log.at(-1)?.kind === e ? t.phase = "done" : (H(t, n, e, t.loseReason ? { reason: t.loseReason } : {}), t.queue = [{ type: "finishGame" }]);
			} else if (r.type === "moveShips") {
				let e = t.ships.filter((e) => e.col === r.col);
				if (r.distance === 0 || e.length === 0) {
					H(t, n, "noDescent", {
						col: r.col + 1,
						distance: r.distance,
						n: e.length
					}, { col: r.col });
					continue;
				}
				let i = e.map((e) => ({
					id: e.id,
					color: e.color,
					fromRow: e.row,
					fromCol: e.col,
					toRow: e.row + r.distance,
					toCol: e.col
				}));
				for (let t of e) t.row += r.distance;
				let a = e.filter((e) => e.row > 16).map((e) => ({
					type: "cityHit",
					id: e.id
				})), o = e.filter((e) => e.row <= 16).sort((e, t) => e.row - t.row).map((e) => ({
					type: "landShip",
					id: e.id
				}));
				t.queue.unshift(...a, ...o), H(t, n, "descend", {
					col: r.col + 1,
					distance: r.distance,
					n: e.length
				}, { moves: i });
			} else if (r.type === "cityHit") {
				let e = t.ships.find((e) => e.id === r.id);
				if (!e) continue;
				t.ships = t.ships.filter((t) => t.id !== e.id), e.color === "p" ? t.poolPurple += 1 : t.poolWhite += 1;
				let i = t.damage;
				t.damage += 1, H(t, n, "cityHit", {
					col: e.col + 1,
					from: i,
					to: t.damage
				}, { col: e.col }), t.damage >= 7 && _e(t, "lose", "games.underfallingskies.loseDamage");
			} else if (r.type === "landShip") {
				let e = t.ships.find((e) => e.id === r.id);
				if (!e) continue;
				let i = de(t.threatened, e.row, e.col);
				if (i.t === "arrow") {
					let r = e.col, a = r + i.dir;
					t.ships.some((t) => t.id !== e.id && t.row === e.row && t.col === a) ? H(t, n, "blocked", {
						row: e.row,
						col: r + 1
					}, {
						row: e.row,
						col: r
					}) : (e.col = a, H(t, n, "drift", {
						row: e.row,
						from: r + 1,
						to: a + 1
					}, { moves: [{
						id: e.id,
						color: e.color,
						fromRow: e.row,
						fromCol: r,
						toRow: e.row,
						toCol: a
					}] }));
				} else i.t === "ship" && (H(t, n, "shadow", {
					row: e.row,
					col: e.col + 1
				}, {
					row: e.row,
					col: e.col
				}), t.queue.unshift({ type: "mothershipMove" }));
			} else if (r.type === "reroll") {
				let r = t.dice.filter((e) => !e.placed);
				if (!r.length) continue;
				for (let n of r) n.value = e(t.seed, t.rngCursor++, 6) + 1;
				H(t, n, "reroll", {
					n: r.length,
					dice: r.map((e) => e.value).join(" · ")
				});
			} else if (r.type === "finishPlacement") t.dice.every((e) => e.placed) && (t.phase = "rooms", H(t, n, "roomsStart"), t.queue.push({ type: "release" }));
			else if (r.type === "roomEffect") we(t, r, n);
			else if (r.type === "mothershipMove") ve(t, n);
			else if (r.type === "mothershipAction") {
				let e = me(t.threatened, t.momRow);
				if (e.t === "excavator") {
					let r = t.excavator;
					t.excavator = Math.max(0, r - e.n), H(t, n, "excavatorBack", {
						from: r,
						to: t.excavator,
						n: r - t.excavator
					}, {
						from: r,
						to: t.excavator
					});
				} else if (e.t === "research") {
					let r = t.research;
					t.research = Math.max(0, r - e.n), H(t, n, "researchBack", {
						from: r,
						to: t.research,
						n: r - t.research
					});
				} else if (e.t === "reinforce") {
					let r = Math.min(e.n, t.whiteReserve);
					t.whiteReserve -= r, t.poolWhite += r, H(t, n, r ? "reinforce" : "noReinforce", { n: r });
				} else if (e.t === "damage") {
					let e = t.damage;
					t.damage += 1, H(t, n, "damage", {
						from: e,
						to: t.damage
					}), t.damage >= 7 && _e(t, "lose", "games.underfallingskies.loseDamage");
				} else H(t, n, "noAction", { row: t.momRow });
			} else if (r.type === "spawn") {
				if (t.poolPurple + t.poolWhite === 0) {
					t.queue.push({ type: "nextRound" });
					continue;
				}
				let e = [
					0,
					1,
					2,
					3,
					4
				].filter((e) => !t.ships.some((n) => n.col === e && n.row === t.momRow));
				if (!e.length) {
					H(t, n, "spawnFull", { n: t.poolPurple + t.poolWhite }), t.queue.push({ type: "nextRound" });
					continue;
				}
				let r = e.filter((e) => !t.ships.some((t) => t.col === e)), i = r.length ? 0 : Math.max(...e.map((e) => be(t, e))), a = r.length ? r : e.filter((e) => be(t, e) === i);
				a.length > 1 ? (t.pendingSpawn = a, H(t, n, "spawnChoice", { cols: a.map((e) => e + 1).join(" / ") })) : ye(t, a[0], n);
			} else r.type === "nextRound" && (t.round += 1, t.phase = "dice", t.pendingSpawn = null, ge(t), H(t, n, "roll", {
				n: t.round,
				dice: t.dice.map((e) => e.value).join(" · ")
			}), t.queue = [{ type: "release" }]);
		}
	}
}
function De(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine") return B("games.underfallingskies.errNotPlayer");
		if (!e.queue.length || e.phase === "done") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), r = [];
		return Ee(t, r), {
			state: t,
			fx: r
		};
	}
	if (n.by !== e.host) return B("games.underfallingskies.errNotPlayer");
	if (e.phase === "done") return B("games.underfallingskies.errDone");
	if (e.queue.length) return B("games.underfallingskies.errResolving");
	let r = structuredClone(e), i = [];
	if (t.type === "placeDie") {
		if (r.phase !== "dice") return B("games.underfallingskies.errPhase");
		let e = Se(r, t, i);
		if (e) return e;
	} else if (t.type === "resolveRoom") {
		if (r.phase !== "rooms") return B("games.underfallingskies.errPhase");
		let e = Te(r, t, i);
		if (e) return e;
	} else if (t.type === "endRooms") {
		if (r.phase !== "rooms") return B("games.underfallingskies.errPhase");
		let e = r.dice.filter((e) => e.placed).length;
		for (let e of r.dice) e.placed = null;
		r.phase = "mothership", H(r, i, "endRooms", { n: e }), r.queue = [
			{ type: "mothershipMove" },
			{ type: "mothershipAction" },
			{ type: "spawn" }
		];
	} else {
		if (r.phase !== "mothership" || !r.pendingSpawn) return B("games.underfallingskies.errPhase");
		if (!r.pendingSpawn.includes(t.col)) return B("games.underfallingskies.errSpawnCol");
		r.pendingSpawn = null, ye(r, t.col, i);
	}
	return {
		state: r,
		fx: i
	};
}
function Oe(e) {
	return {
		public: {
			phase: e.phase,
			resolving: e.queue.length > 0,
			log: e.log,
			round: e.round,
			threatened: [
				e.threatened[0],
				e.threatened[1],
				e.threatened[2],
				e.threatened[3]
			],
			dice: e.dice.map((e) => ({
				value: e.value,
				color: e.color,
				placed: e.placed ? { ...e.placed } : null
			})),
			ships: e.ships.map((e) => ({ ...e })),
			momRow: e.momRow,
			skullRow: fe(e.threatened),
			poolPurple: e.poolPurple,
			poolWhite: e.poolWhite,
			whiteReserve: e.whiteReserve,
			excavator: e.excavator,
			energy: e.energy,
			damage: e.damage,
			research: e.research,
			pendingSpawn: e.pendingSpawn ? [...e.pendingSpawn] : null,
			result: e.result,
			loseReason: e.loseReason
		},
		private: {}
	};
}
function ke(e) {
	return e.phase === "done" ? {
		phase: "done",
		winner: e.result === "win" ? [e.host] : [],
		ranking: [e.host]
	} : { phase: e.phase };
}
var Ae = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: F,
	schemas: {
		action: ie,
		publicView: ce,
		privateView: le,
		config: ae
	},
	setup: xe,
	reduce: De,
	viewFor: Oe,
	status: ke,
	nextTickIn: (e) => e.queue.length && e.phase !== "done" ? e.beatMs : null
}, U = "./games/underfallingskies/";
function W({ type: e }) {
	return /* @__PURE__ */ b("svg", {
		className: "ufs-facility-mark",
		viewBox: "0 0 16 16",
		"aria-hidden": !0,
		fill: "currentColor",
		stroke: "currentColor",
		strokeWidth: ".6",
		children: [
			e === "energy" && /* @__PURE__ */ y("path", { d: "M10 1 3 10h5l-2 5 8-8H9Z" }),
			e === "research" && /* @__PURE__ */ b("g", {
				fill: "none",
				children: [/* @__PURE__ */ y("path", {
					d: "m8 1 6 3.5v7L8 15l-6-3.5v-7Z",
					strokeWidth: "1.8"
				}), /* @__PURE__ */ y("circle", {
					cx: "8",
					cy: "8",
					r: "2.5",
					strokeWidth: "1.4"
				})]
			}),
			e === "aa" && /* @__PURE__ */ b("g", {
				fill: "none",
				children: [/* @__PURE__ */ y("circle", {
					cx: "8",
					cy: "8",
					r: "4.5",
					strokeWidth: "1.4"
				}), /* @__PURE__ */ y("path", {
					d: "M8 0v5m0 6v5M0 8h5m6 0h5",
					strokeWidth: "1.8"
				})]
			}),
			e === "fighter" && /* @__PURE__ */ y("path", { d: "m8 1 2 6 5 3v2l-5-2-1 4 2 1v1l-3-1-3 1v-1l2-1-1-4-5 2v-2l5-3Z" }),
			e === "tunnel" && /* @__PURE__ */ y("path", {
				d: "M2 14V7a6 6 0 0 1 12 0v7M5 14V8a3 3 0 0 1 6 0v6M1 14h14",
				fill: "none",
				strokeWidth: "1.5"
			}),
			e === "garage" && /* @__PURE__ */ y("path", {
				d: "m1 6 7-5 7 5v9H1Zm3 9V8h8v7M5 10h6m-6 2h6",
				fill: "none",
				strokeWidth: "1.5"
			}),
			e === "excavator" && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("rect", {
				x: "1",
				y: "10",
				width: "13",
				height: "5",
				rx: "2"
			}), /* @__PURE__ */ y("path", {
				d: "M3 9V5h6v4M8 6l3-3 4 4v3",
				fill: "none",
				strokeWidth: "2"
			})] }),
			e === "white" && /* @__PURE__ */ y("path", { d: "M2 10q0-4 3-4 0-5 3-5t3 5q3 0 3 4l-3 4H5Z" }),
			e === "skull" && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("path", { d: "M3 10C-1 4 3 0 8 0s9 4 5 10v5H3Z" }), /* @__PURE__ */ b("g", {
				fill: "#433139",
				stroke: "none",
				children: [
					/* @__PURE__ */ y("circle", {
						cx: "5",
						cy: "7",
						r: "2"
					}),
					/* @__PURE__ */ y("circle", {
						cx: "11",
						cy: "7",
						r: "2"
					}),
					/* @__PURE__ */ y("path", { d: "M5 12h2v4H5m4-4h2v4H9" })
				]
			})] }),
			e === "damage" && /* @__PURE__ */ y("path", {
				d: "M2 1h12v14H2ZM9 1 6 6l4 3-4 6",
				fill: "none",
				strokeWidth: "1.5"
			})
		]
	});
}
var je = {
	1: [[1, 1]],
	2: [[0, 0], [2, 2]],
	3: [
		[0, 0],
		[1, 1],
		[2, 2]
	],
	4: [
		[0, 0],
		[2, 0],
		[0, 2],
		[2, 2]
	],
	5: [
		[0, 0],
		[2, 0],
		[1, 1],
		[0, 2],
		[2, 2]
	],
	6: [
		[0, 0],
		[2, 0],
		[0, 1],
		[2, 1],
		[0, 2],
		[2, 2]
	]
};
function Me({ value: e }) {
	return /* @__PURE__ */ y("svg", {
		className: "ufs-die-face",
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		children: je[e].map(([e, t]) => /* @__PURE__ */ y("circle", {
			cx: 6 + e * 6,
			cy: 6 + t * 6,
			r: "1.85",
			fill: "currentColor"
		}, `${e}:${t}`))
	});
}
//#endregion
//#region src/games/underfallingskies/target-ants.tsx
function G() {
	let e = x();
	return /* @__PURE__ */ b("svg", {
		className: "ufs-target-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		focusable: "false",
		children: [/* @__PURE__ */ y("rect", {
			className: "ufs-target-ants-base",
			x: "1",
			y: "1",
			width: "98",
			height: "98",
			rx: "7",
			fill: "none",
			vectorEffect: "non-scaling-stroke"
		}), /* @__PURE__ */ y("rect", {
			className: "ufs-target-ants-march",
			x: "1",
			y: "1",
			width: "98",
			height: "98",
			rx: "7",
			fill: "none",
			vectorEffect: "non-scaling-stroke",
			strokeDasharray: "6 5",
			children: !e && /* @__PURE__ */ y("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-11",
				dur: "0.8s",
				repeatCount: "indefinite"
			})
		})]
	});
}
//#endregion
//#region src/games/underfallingskies/room-resolution.tsx
var Ne = {
	aa: "games.underfallingskies.room.aa",
	energy: "games.underfallingskies.room.energy",
	research: "games.underfallingskies.room.research",
	fighter: "games.underfallingskies.room.fighter",
	tunnel: "games.underfallingskies.room.tunnel",
	garage: "games.underfallingskies.room.garage"
};
function Pe({ info: e, energy: t, steps: n, researchFrom: r, costs: i, onSteps: a, onResolve: o, onClose: s }) {
	let c = l(), u = e.unexcavated ? c("games.underfallingskies.room.excavator") : c(Ne[e.cell.type]), d = u.indexOf("("), f = d < 0 ? u : u.slice(0, d).trim(), p = d < 0 ? null : u.slice(d + 1, u.endsWith(")") ? -1 : void 0), m = t >= e.cell.cost, h = e.unexcavated ? 1 : e.cell.cost, g = Math.max(0, Math.min(7, t + e.value));
	return /* @__PURE__ */ b("div", {
		className: "ufs-resolution",
		"data-type": e.unexcavated ? "excavator" : e.cell.type,
		role: "dialog",
		"aria-label": u,
		onKeyDown: (e) => {
			e.key === "Escape" && s();
		},
		children: [
			/* @__PURE__ */ b("div", {
				className: "ufs-resolution-head",
				children: [
					/* @__PURE__ */ y("span", {
						className: "ufs-resolution-symbol",
						children: /* @__PURE__ */ y(W, { type: e.unexcavated ? "excavator" : e.cell.type })
					}),
					/* @__PURE__ */ b("div", { children: [
						/* @__PURE__ */ y("strong", { children: f }),
						p && /* @__PURE__ */ y("small", {
							className: "ufs-resolution-detail",
							children: p
						}),
						/* @__PURE__ */ y("small", { children: e.size > 1 ? c("games.underfallingskies.roomFill", {
							n: e.filled,
							total: e.size,
							value: e.value
						}) : c("games.underfallingskies.roomValue", { n: e.value }) })
					] }),
					/* @__PURE__ */ y("button", {
						type: "button",
						className: "ufs-resolution-close",
						"aria-label": c("games.underfallingskies.closeRoom"),
						autoFocus: !0,
						onClick: s,
						children: "×"
					})
				]
			}),
			h > 0 && /* @__PURE__ */ b("span", {
				className: "ufs-resolution-energy",
				"aria-label": c("games.underfallingskies.roomCost", {
					n: h,
					energy: t
				}),
				children: [
					/* @__PURE__ */ y(W, { type: "energy" }),
					" ",
					t >= h && (e.unexcavated || e.filled === e.size) ? `${t} → ${t - h}` : `−${h}`
				]
			}),
			e.unexcavated && /* @__PURE__ */ y("p", {
				className: "ufs-resolution-explain",
				children: c("games.underfallingskies.excavateHelp")
			}),
			e.unexcavated && t < 1 && /* @__PURE__ */ y("p", {
				className: "ufs-resolution-warning",
				children: c("games.underfallingskies.noEnergy")
			}),
			!e.unexcavated && e.filled === e.size && e.cell.type === "energy" && /* @__PURE__ */ y("p", {
				className: "ufs-resolution-explain",
				children: c("games.underfallingskies.energyPreview", {
					from: t,
					to: g,
					delta: g > t ? `+${g - t}` : g - t
				})
			}),
			!e.unexcavated && e.filled === e.size && e.cell.type === "fighter" && /* @__PURE__ */ y("p", {
				className: "ufs-resolution-explain",
				children: c("games.underfallingskies.shootHelp", {
					n: e.shotCount,
					value: e.value
				})
			}),
			e.unexcavated ? /* @__PURE__ */ b("div", {
				className: "ufs-resolution-actions",
				children: [/* @__PURE__ */ b("button", {
					type: "button",
					className: "btn-base",
					disabled: t < 1,
					onClick: () => o(!0),
					children: [c("games.underfallingskies.doExcavate"), t >= 1 && /* @__PURE__ */ y(G, {})]
				}), /* @__PURE__ */ b("button", {
					type: "button",
					className: "btn-quiet",
					onClick: () => o(!1),
					children: [c("games.underfallingskies.doDiscard"), /* @__PURE__ */ y(G, {})]
				})]
			}) : e.cell.type === "aa" || e.cell.type === "tunnel" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "btn-quiet ufs-resolution-full",
				onClick: () => o(!1),
				children: [c("games.underfallingskies.doRemove"), /* @__PURE__ */ y(G, {})]
			}) : e.filled < e.size ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("p", {
				className: "ufs-resolution-warning",
				children: c("games.underfallingskies.roomIncomplete")
			}), /* @__PURE__ */ b("button", {
				type: "button",
				className: "btn-quiet ufs-resolution-full",
				onClick: () => o(!1),
				children: [c("games.underfallingskies.doDiscard"), /* @__PURE__ */ y(G, {})]
			})] }) : e.cell.type === "research" ? /* @__PURE__ */ b(v, { children: [e.maxSteps > 0 && m ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ b("div", {
				className: "ufs-research-steps",
				"aria-label": c("games.underfallingskies.researchSteps"),
				children: [/* @__PURE__ */ y("span", { children: c("games.underfallingskies.advanceSpaces") }), Array.from({ length: e.maxSteps }, (e, t) => t + 1).map((e) => /* @__PURE__ */ b("button", {
					type: "button",
					"aria-pressed": n === e,
					onClick: () => a(e),
					children: [e, n !== e && /* @__PURE__ */ y(G, {})]
				}, e))]
			}), /* @__PURE__ */ b("p", {
				className: "ufs-research-total",
				children: [
					c("games.underfallingskies.researchTotal"),
					" ",
					/* @__PURE__ */ b("strong", { children: [
						i.slice(r, r + n).join(" + "),
						" = ",
						i.slice(r, r + n).reduce((e, t) => e + t, 0)
					] })
				]
			})] }) : /* @__PURE__ */ y("p", {
				className: "ufs-resolution-warning",
				children: c(m ? "games.underfallingskies.researchShort" : "games.underfallingskies.noEnergy")
			}), /* @__PURE__ */ b("div", {
				className: "ufs-resolution-actions",
				children: [e.maxSteps > 0 && m && /* @__PURE__ */ b("button", {
					type: "button",
					className: "btn-base",
					onClick: () => o(!0),
					children: [c(n === 1 ? "games.underfallingskies.doResearchOne" : "games.underfallingskies.doResearch", { n }), /* @__PURE__ */ y(G, {})]
				}), /* @__PURE__ */ b("button", {
					type: "button",
					className: "btn-quiet",
					onClick: () => o(!1),
					children: [c("games.underfallingskies.doDiscard"), /* @__PURE__ */ y(G, {})]
				})]
			})] }) : /* @__PURE__ */ b(v, { children: [!m && /* @__PURE__ */ y("p", {
				className: "ufs-resolution-warning",
				children: c("games.underfallingskies.noEnergy")
			}), /* @__PURE__ */ b("div", {
				className: "ufs-resolution-actions",
				children: [/* @__PURE__ */ b("button", {
					type: "button",
					className: "btn-base",
					disabled: !m,
					onClick: () => o(!0),
					children: [c(e.cell.type === "energy" ? "games.underfallingskies.doEnergy" : "games.underfallingskies.doShoot", {
						n: e.value,
						delta: g > t ? `+${g - t}` : g - t
					}), m && /* @__PURE__ */ y(G, {})]
				}), /* @__PURE__ */ b("button", {
					type: "button",
					className: "btn-quiet",
					onClick: () => o(!1),
					children: [c("games.underfallingskies.doDiscard"), /* @__PURE__ */ y(G, {})]
				})]
			})] })
		]
	});
}
//#endregion
//#region src/games/underfallingskies/event-text.ts
var Fe = {
	roll: "games.underfallingskies.log.roll",
	place: "games.underfallingskies.log.place",
	descend: "games.underfallingskies.log.descend",
	noDescent: "games.underfallingskies.log.noDescent",
	drift: "games.underfallingskies.log.drift",
	blocked: "games.underfallingskies.log.blocked",
	shadow: "games.underfallingskies.log.shadow",
	cityHit: "games.underfallingskies.log.cityHit",
	reroll: "games.underfallingskies.log.reroll",
	roomsStart: "games.underfallingskies.log.roomsStart",
	pay: "games.underfallingskies.log.pay",
	energy: "games.underfallingskies.log.energy",
	research: "games.underfallingskies.log.research",
	shoot: "games.underfallingskies.log.shoot",
	noTargets: "games.underfallingskies.log.noTargets",
	excavate: "games.underfallingskies.log.excavate",
	discard: "games.underfallingskies.log.discard",
	aa: "games.underfallingskies.log.aa",
	tunnel: "games.underfallingskies.log.tunnel",
	endRooms: "games.underfallingskies.log.endRooms",
	mothership: "games.underfallingskies.log.mothership",
	excavatorBack: "games.underfallingskies.log.excavatorBack",
	researchBack: "games.underfallingskies.log.researchBack",
	reinforce: "games.underfallingskies.log.reinforce",
	noReinforce: "games.underfallingskies.log.noReinforce",
	noAction: "games.underfallingskies.log.noAction",
	damage: "games.underfallingskies.log.damage",
	spawn: "games.underfallingskies.log.spawn",
	spawnChoice: "games.underfallingskies.log.spawnChoice",
	spawnFull: "games.underfallingskies.log.spawnFull",
	win: "games.underfallingskies.log.win",
	lose: "games.underfallingskies.log.lose"
}, Ie = {
	aa: "games.underfallingskies.roomBoard.aa",
	energy: "games.underfallingskies.roomBoard.energy",
	research: "games.underfallingskies.roomBoard.research",
	fighter: "games.underfallingskies.roomBoard.fighter",
	tunnel: "games.underfallingskies.roomBoard.tunnel",
	garage: "games.underfallingskies.roomBoard.garage",
	excavator: "games.underfallingskies.room.excavator"
};
function Le(e, t) {
	return t(Fe[e.kind], {
		...e.params,
		...e.room ? { room: t(Ie[e.room]) } : {},
		...e.kind === "lose" ? { reason: t(e.params.reason) } : {},
		...e.kind === "spawn" ? { color: t(e.params.color === "p" ? "games.underfallingskies.purpleShip" : "games.underfallingskies.whiteShip") } : {}
	});
}
//#endregion
//#region src/games/underfallingskies/view-player.tsx
var Re = {
	aa: "games.underfallingskies.roomBoard.aa",
	energy: "games.underfallingskies.roomBoard.energy",
	research: "games.underfallingskies.roomBoard.research",
	fighter: "games.underfallingskies.roomBoard.fighter",
	tunnel: "games.underfallingskies.roomBoard.tunnel",
	garage: "games.underfallingskies.roomBoard.garage"
};
function ze(e) {
	return /* @__PURE__ */ y(Be, {
		pub: e.public,
		send: e.send
	});
}
function Be({ pub: e, send: t }) {
	let n = l(), [r, i] = o(null), a = r?.round === e.round ? r.index : null, s = (t) => i(t === null ? null : {
		round: e.round,
		index: t
	}), [c, d] = o(null), [f, p] = o(null), [m, _] = o(!1), x = pe([...e.threatened]), S = new Set(e.dice.filter((e) => e.placed).map((e) => e.placed.col)), C = e.phase === "dice" && !e.resolving && a !== null && !e.dice[a]?.placed ? e.dice[a] : null, w = n(e.phase === "dice" ? "games.underfallingskies.phaseDice" : e.phase === "rooms" ? "games.underfallingskies.phaseRooms" : e.phase === "mothership" ? e.pendingSpawn ? "games.underfallingskies.phaseSpawn" : "games.underfallingskies.phaseMothership" : e.result === "win" ? "games.underfallingskies.overWin" : "games.underfallingskies.overLose"), ee = (t, n) => {
		if (e.phase !== "dice" || e.resolving || !C || S.has(n) || N[t][n].type === "garage") return !1;
		if (V(e.excavator, t, n)) return !0;
		let r = P.findIndex(([e, r]) => e === t && r === n);
		return r < 0 || C.value < r - e.excavator ? !1 : !e.dice.some((t) => t.placed && !V(e.excavator, t.placed.row, t.placed.col));
	}, te = (e, n) => {
		a !== null && ee(e, n) && t({
			type: "placeDie",
			die: a,
			row: e,
			col: n
		});
	}, T = (() => {
		if (!c || e.phase !== "rooms" || e.resolving) return null;
		let t = N[c.row][c.col];
		if (!e.dice.find((e) => e.placed?.row === c.row && e.placed.col === c.col)) return null;
		let n = [];
		N.forEach((e, r) => e.forEach((e, i) => {
			e.room === t.room && n.push([r, i]);
		}));
		let r = n.filter(([t, n]) => e.dice.some((e) => e.placed?.row === t && e.placed.col === n)).length, i = e.dice.filter((e) => e.placed && N[e.placed.row][e.placed.col].room === t.room).reduce((e, t) => e + t.value, t.mod), a = 0, o = 0;
		for (; e.research + a < 16 && o + x[e.research + a] <= i;) o += x[e.research + a], a += 1;
		let s = e.ships.filter((t) => {
			if (t.row < 1 || t.row > 16) return !1;
			let n = de([...e.threatened], t.row, t.col);
			return n.t === "explosion" && n.n <= i;
		}).length;
		return {
			cell: t,
			filled: r,
			size: n.length,
			value: i,
			maxSteps: a,
			shotCount: s,
			unexcavated: !V(e.excavator, c.row, c.col)
		};
	})(), E = Math.min(f ?? T?.maxSteps ?? 0, T?.maxSteps ?? 0), D = T && !T.unexcavated && T.cell.type === "research" && T.filled === T.size && e.energy >= T.cell.cost && E > 0 ? e.research + E : null, O = T && !T.unexcavated && T.cell.type === "fighter" && T.filled === T.size && e.energy >= T.cell.cost ? T.value : null, k = c && T?.unexcavated && e.energy >= 1 ? P.findIndex(([e, t]) => e === c.row && t === c.col) : -1;
	return /* @__PURE__ */ b("div", {
		className: "ufs-game",
		style: {
			"--ufs-accent": F.accent,
			"--ufs-sky-art": `url("${U}sky.webp")`,
			"--ufs-city-art": `url("${U}city.webp")`,
			"--ufs-mother-art": `url("${U}mothership.webp")`
		},
		children: [/* @__PURE__ */ y(u, {
			adaptive: !0,
			banner: /* @__PURE__ */ b("header", {
				className: "ufs-command",
				children: [
					/* @__PURE__ */ b("div", {
						className: "ufs-phase",
						children: [/* @__PURE__ */ y("span", { children: n("games.underfallingskies.round", { n: e.round }) }), /* @__PURE__ */ y("strong", { children: w })]
					}),
					/* @__PURE__ */ y(Ze, { pub: e }),
					/* @__PURE__ */ y("button", {
						type: "button",
						className: "ufs-log-button",
						"aria-label": n("common.log.title"),
						onClick: () => _(!0),
						children: /* @__PURE__ */ y(h, { size: 19 })
					}),
					/* @__PURE__ */ y("span", {
						className: "ufs-menu-recess",
						"aria-hidden": !0
					})
				]
			}),
			scroll: !1,
			children: /* @__PURE__ */ b("div", {
				className: "ufs-center",
				children: [
					/* @__PURE__ */ b("div", {
						className: "ufs-battlefield",
						children: [/* @__PURE__ */ y(Ve, {
							pub: e,
							costs: x,
							researchTarget: D,
							attackValue: O,
							hasSelection: !!C,
							placedCols: S,
							send: t
						}), /* @__PURE__ */ b("div", {
							className: "ufs-base",
							children: [/* @__PURE__ */ b("div", {
								className: "ufs-base-head",
								children: [/* @__PURE__ */ y("span", { children: n("games.underfallingskies.baseLabel") }), /* @__PURE__ */ y(et, {
									pub: e,
									disabled: !!T,
									onEnd: () => {
										d(null), t({ type: "endRooms" });
									}
								})]
							}), /* @__PURE__ */ y("div", {
								className: "ufs-base-grid",
								children: N.map((t, n) => t.map((t, r) => /* @__PURE__ */ y(qe, {
									row: n,
									col: r,
									cell: t,
									pub: e,
									canPlace: ee(n, r),
									hasSelection: !!C,
									digPreview: P.some(([t, i], a) => t === n && i === r && a > e.excavator && a <= k),
									selected: c?.row === n && c.col === r,
									panelOpen: !!T,
									onPlace: () => te(n, r),
									onSelect: () => {
										d({
											row: n,
											col: r
										}), p(null);
									}
								}, `${n}:${r}`)))
							})]
						})]
					}),
					e.phase === "dice" && /* @__PURE__ */ y($e, {
						pub: e,
						selDie: a,
						onSelectDie: s
					}),
					e.resolving && e.log.at(-1) && /* @__PURE__ */ y("div", {
						className: "ufs-settlement",
						role: "status",
						children: Le(e.log.at(-1), n)
					}),
					T && /* @__PURE__ */ y("div", {
						className: "ufs-room-overlay",
						"data-dock": c && c.row >= 2 ? "top" : "bottom",
						children: /* @__PURE__ */ y(Pe, {
							info: T,
							energy: e.energy,
							steps: E,
							researchFrom: e.research,
							costs: x,
							onSteps: p,
							onResolve: (e) => {
								c && (t({
									type: "resolveRoom",
									row: c.row,
									col: c.col,
									use: e,
									research: E
								}), d(null), p(null));
							},
							onClose: () => d(null)
						})
					})
				]
			})
		}), m && /* @__PURE__ */ y("div", {
			className: "ufs-log-overlay",
			children: /* @__PURE__ */ y(g, {
				log: e.log,
				line: (e) => /* @__PURE__ */ b(v, { children: [n("games.underfallingskies.logRound", { n: e.round }), Le(e, n)] }),
				onClose: () => _(!1)
			})
		})]
	});
}
function Ve({ pub: e, costs: t, researchTarget: n, attackValue: r, hasSelection: i, placedCols: a, send: o }) {
	let s = l(), u = c((e) => e.locale);
	return /* @__PURE__ */ b("div", {
		className: "ufs-sky",
		children: [
			/* @__PURE__ */ b("div", {
				className: "ufs-sky-head",
				lang: u,
				children: [
					/* @__PURE__ */ b("span", {
						title: s("games.underfallingskies.researchLabel"),
						"aria-label": s("games.underfallingskies.researchLabel"),
						children: [/* @__PURE__ */ y("span", { children: s("games.underfallingskies.researchLabel") }), /* @__PURE__ */ y(W, { type: "research" })]
					}),
					/* @__PURE__ */ y("div", {
						className: "ufs-launch-row",
						children: Array.from({ length: 5 }, (t, n) => /* @__PURE__ */ b(nt, {
							col: n,
							children: [e.pendingSpawn?.includes(n) && !e.resolving ? /* @__PURE__ */ b("button", {
								type: "button",
								className: "ufs-launch-choice",
								"aria-label": s("games.underfallingskies.spawnCol", { n: n + 1 }),
								onClick: () => o({
									type: "chooseSpawn",
									col: n
								}),
								children: [
									"↓",
									n + 1,
									/* @__PURE__ */ y(G, {})
								]
							}) : /* @__PURE__ */ y("span", {
								className: "ufs-launch-port",
								"data-taken": a.has(n) || void 0,
								children: n + 1
							}), e.ships.filter((e) => e.row === 0 && e.col === n).map((e) => /* @__PURE__ */ y(Ge, { ship: e }, e.id))]
						}, n))
					}),
					/* @__PURE__ */ b("span", {
						title: s("games.underfallingskies.mothershipLabel"),
						"aria-label": s("games.underfallingskies.mothershipLabel"),
						children: [/* @__PURE__ */ y("span", { children: s("games.underfallingskies.mothershipLabel") }), /* @__PURE__ */ y("i", {
							className: "ufs-rail-mother",
							"aria-hidden": !0
						})]
					})
				]
			}),
			/* @__PURE__ */ b("div", {
				className: "ufs-air-body",
				children: [
					/* @__PURE__ */ y(Ke, {
						pub: e,
						costs: t,
						target: n
					}),
					/* @__PURE__ */ b("div", {
						className: "ufs-air-map",
						children: [/* @__PURE__ */ b("div", {
							className: "ufs-sky-grid-shell",
							children: [/* @__PURE__ */ y("div", {
								className: "ufs-sky-grid",
								children: Array.from({ length: 16 }, (e, t) => t + 1).map((t) => /* @__PURE__ */ y("div", {
									className: "ufs-sky-row",
									"data-board-end": t % 4 == 0 || void 0,
									"data-skull": t === e.skullRow || void 0,
									"data-mother": t === e.momRow || void 0,
									children: Array.from({ length: 5 }, (n, o) => /* @__PURE__ */ y(We, {
										row: t,
										col: o,
										pub: e,
										attackValue: r,
										available: i && !a.has(o)
									}, o))
								}, t))
							}), /* @__PURE__ */ y("div", {
								className: "ufs-mother-position",
								"aria-label": s("games.underfallingskies.mothershipPosition", {
									n: e.momRow,
									limit: e.skullRow
								}),
								style: { top: `${Math.max(0, (e.momRow - .5) / 16 * 100)}%` },
								children: /* @__PURE__ */ y(tt, { children: /* @__PURE__ */ y("span", {
									className: "ufs-mother-shape",
									"aria-hidden": !0
								}) })
							})]
						}), /* @__PURE__ */ b("div", {
							className: "ufs-city",
							"data-damaged": e.damage > 0 || void 0,
							children: [/* @__PURE__ */ y("span", {
								className: "ufs-city-anchors",
								"aria-hidden": !0,
								children: Array.from({ length: 5 }, (e, t) => /* @__PURE__ */ y(rt, { col: t }, t))
							}), /* @__PURE__ */ y("span", {
								className: "ufs-city-label",
								children: s("games.underfallingskies.cityLabel")
							})]
						})]
					}),
					/* @__PURE__ */ y(Ue, { pub: e })
				]
			}),
			/* @__PURE__ */ y("div", {
				className: "ufs-city-strip",
				"aria-hidden": !0
			})
		]
	});
}
var He = {
	none: "games.underfallingskies.motherEffectNone",
	reinforce: "games.underfallingskies.motherEffectReinforce",
	excavator: "games.underfallingskies.motherEffectExcavator",
	research: "games.underfallingskies.motherEffectResearch",
	damage: "games.underfallingskies.motherEffectDamage"
};
function Ue({ pub: e }) {
	let t = l(), [n, r] = o(null), i = j.flatMap((t, n) => (e.threatened[n] ? t.threat : t.easy).actions), a = (n, r) => r === e.skullRow ? t("games.underfallingskies.loseMothership") : n.t === "excavator" && n.n === 1 ? t("games.underfallingskies.motherEffectExcavatorOne") : n.t === "research" && n.n === 1 ? t("games.underfallingskies.motherEffectResearchOne") : t(He[n.t], { n: "n" in n ? n.n : 1 });
	return /* @__PURE__ */ b("div", {
		className: "ufs-mother-rail",
		children: [/* @__PURE__ */ y("ol", { children: Array.from({ length: 8 }, (o, s) => /* @__PURE__ */ y("li", { children: /* @__PURE__ */ y("button", {
			type: "button",
			className: "ufs-mother-pair",
			"aria-expanded": n === s,
			"aria-label": [0, 1].map((e) => t("games.underfallingskies.motherEffectRow", {
				row: s * 2 + e + 1,
				effect: a(i[s * 2 + e], s * 2 + e + 1)
			})).join("; "),
			onClick: () => r(n === s ? null : s),
			children: [0, 1].map((t) => {
				let n = s * 2 + t + 1, r = i[n - 1];
				return /* @__PURE__ */ y("span", {
					className: "ufs-mother-effect",
					"data-current": n === e.momRow || void 0,
					"data-skull": n === e.skullRow || void 0,
					children: n === e.skullRow ? /* @__PURE__ */ y(W, { type: "skull" }) : r.t === "none" ? "–" : /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(W, { type: r.t === "reinforce" ? "white" : r.t }), "n" in r ? `${r.t === "reinforce" ? "+" : "−"}${r.n}` : "+1"] })
				}, n);
			})
		}) }, s)) }), n !== null && /* @__PURE__ */ b("div", {
			className: "ufs-mother-detail",
			role: "dialog",
			"aria-label": t("games.underfallingskies.mothershipLabel"),
			children: [
				/* @__PURE__ */ y("button", {
					type: "button",
					"aria-label": t("common.qr.close"),
					onClick: () => r(null),
					children: /* @__PURE__ */ y(p, { size: 18 })
				}),
				/* @__PURE__ */ y("p", { children: t("games.underfallingskies.reserve", { n: e.whiteReserve }) }),
				/* @__PURE__ */ y("p", { children: t("games.underfallingskies.mothershipPool", {
					purple: e.poolPurple,
					white: e.poolWhite
				}) }),
				[0, 1].map((e) => {
					let r = n * 2 + e + 1;
					return /* @__PURE__ */ y("p", { children: t("games.underfallingskies.motherEffectRow", {
						row: r,
						effect: a(i[r - 1], r)
					}) }, r);
				})
			]
		})]
	});
}
function We({ row: e, col: t, pub: n, available: r, attackValue: i }) {
	let { ref: a } = s(`sky:${e}:${t}`), o = de([...n.threatened], e, t), c = n.ships.filter((n) => n.row === e && n.col === t), l = i !== null && o.t === "explosion" && o.n <= i && c.length > 0;
	return /* @__PURE__ */ b("div", {
		ref: a,
		className: "ufs-sky-cell",
		"data-effect": o.t,
		"data-available": r || void 0,
		"data-target": l || void 0,
		"aria-hidden": !0,
		children: [
			o.t === "explosion" && /* @__PURE__ */ y("span", {
				className: "ufs-blast",
				children: o.n
			}),
			o.t === "arrow" && /* @__PURE__ */ y("span", {
				className: "ufs-arrow",
				children: o.dir === 1 ? "›" : "‹"
			}),
			o.t === "ship" && /* @__PURE__ */ y("span", {
				className: "ufs-ship-shadow",
				children: "◇"
			}),
			c.map((e) => /* @__PURE__ */ y(Ge, { ship: e }, e.id)),
			c.length > 1 && /* @__PURE__ */ y("span", {
				className: "ufs-ship-count",
				children: c.length
			})
		]
	});
}
function Ge({ ship: e }) {
	let { ref: t, hidden: n } = s(`ship:${e.id}`);
	return /* @__PURE__ */ y("span", {
		ref: t,
		className: "ufs-ship",
		"data-color": e.color,
		style: { visibility: n ? "hidden" : void 0 }
	});
}
function Ke({ pub: e, costs: t, target: n }) {
	let r = l(), { ref: i } = s("research");
	return /* @__PURE__ */ y("div", {
		ref: i,
		className: "ufs-research-rail",
		"aria-label": r("games.underfallingskies.researchProgress", { n: e.research }),
		children: /* @__PURE__ */ y("ol", { children: t.map((t, i) => {
			let a = i + 1;
			return /* @__PURE__ */ y("li", {
				"aria-label": r(a === n ? "games.underfallingskies.researchDestination" : "games.underfallingskies.researchSpace", {
					n: a,
					cost: t
				}),
				"aria-current": a === e.research ? "step" : void 0,
				"data-complete": a <= e.research || void 0,
				"data-current": a === e.research || void 0,
				"data-preview": n !== null && a > e.research && a <= n || void 0,
				"data-target": a === n || void 0,
				children: t
			}, a);
		}) })
	});
}
function qe({ row: e, col: t, cell: n, pub: r, canPlace: i, hasSelection: a, selected: o, digPreview: c, panelOpen: u, onPlace: d, onSelect: f }) {
	let p = l(), { ref: m } = s(`cell:${e}:${t}`), h = V(r.excavator, e, t), g = r.dice.findIndex((n) => n.placed?.row === e && n.placed.col === t), _ = r.dice[g], x = P[r.excavator][0] === e && P[r.excavator][1] === t, S = N.flat().filter((e) => e.room === n.room).length, C = r.dice.filter((e) => e.placed && N[e.placed.row][e.placed.col].room === n.room).length, w = !u && !r.resolving && (r.phase === "dice" ? i : r.phase === "rooms" && !!_), ee = p(Re[n.type]);
	return /* @__PURE__ */ b("button", {
		ref: m,
		type: "button",
		disabled: !w,
		className: "ufs-room",
		"aria-label": p("games.underfallingskies.roomSpaceAria", {
			row: e + 1,
			col: t + 1,
			name: ee
		}),
		"aria-pressed": o || void 0,
		onClick: () => r.phase === "dice" ? d() : f(),
		"data-type": n.type,
		"data-buried": !h || void 0,
		"data-legal": i || void 0,
		"data-dim": a && !i || void 0,
		"data-selected": o || void 0,
		"data-occupied": !!_ || void 0,
		"data-dig-preview": c || void 0,
		"data-joined-left": t > 0 && N[e][t - 1].room === n.room || void 0,
		"data-joined-right": t < 4 && N[e][t + 1].room === n.room || void 0,
		children: [
			/* @__PURE__ */ y("span", {
				className: "ufs-room-equipment",
				"aria-hidden": !0,
				children: /* @__PURE__ */ y(W, { type: n.type })
			}),
			/* @__PURE__ */ y("span", {
				className: "ufs-room-name",
				children: ee
			}),
			(n.cost > 0 || n.type === "aa") && /* @__PURE__ */ y("span", {
				className: "ufs-room-cost",
				children: n.type === "aa" ? "−1" : /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(W, { type: "energy" }), n.cost] })
			}),
			n.mod !== 0 && /* @__PURE__ */ b("span", {
				className: "ufs-room-mod",
				children: [n.mod > 0 ? "+" : "−", Math.abs(n.mod)]
			}),
			S > 1 && C > 0 && /* @__PURE__ */ b("span", {
				className: "ufs-room-fill",
				children: [
					C,
					"/",
					S
				]
			}),
			!h && /* @__PURE__ */ y("span", {
				className: "ufs-rubble",
				"aria-hidden": !0,
				children: "▰"
			}),
			x && /* @__PURE__ */ y(Xe, {}),
			_ && /* @__PURE__ */ y(Je, {
				die: _,
				index: g
			}),
			i && /* @__PURE__ */ y("span", {
				className: "ufs-landing-mark",
				"aria-hidden": !0,
				children: "＋"
			}),
			w && !o && /* @__PURE__ */ y(G, {})
		]
	});
}
function Je({ die: e, index: t }) {
	let { ref: n, hidden: r } = s(`placedDie:${t}`);
	return /* @__PURE__ */ y("span", {
		ref: n,
		className: "ufs-placed-die",
		"data-color": e.color,
		"aria-label": String(e.value),
		style: { visibility: r ? "hidden" : void 0 },
		children: /* @__PURE__ */ y(Me, { value: e.value })
	});
}
function Ye({ die: e, index: t, selected: n, disabled: r, onClick: i }) {
	let a = l(), { ref: o } = s(`die:${t}`);
	return /* @__PURE__ */ b("button", {
		ref: o,
		type: "button",
		className: "ufs-die",
		"data-color": e.color,
		"data-selected": n || void 0,
		disabled: r,
		"aria-label": a(e.color === "w" ? "games.underfallingskies.dieWhite" : "games.underfallingskies.dieGray", { n: e.value }),
		"aria-pressed": n,
		onClick: i,
		children: [
			/* @__PURE__ */ y(Me, { value: e.value }),
			e.color === "w" && /* @__PURE__ */ y("span", {
				"aria-hidden": !0,
				children: "↻"
			}),
			!r && !n && /* @__PURE__ */ y(G, {})
		]
	});
}
function Xe() {
	let { ref: e, hidden: t } = s("excavator");
	return /* @__PURE__ */ y("span", {
		ref: e,
		className: "ufs-excavator",
		style: { visibility: t ? "hidden" : void 0 },
		"aria-hidden": !0,
		children: "▰"
	});
}
function Ze({ pub: e }) {
	let t = l();
	return /* @__PURE__ */ b("div", {
		className: "ufs-status-tracks",
		children: [
			/* @__PURE__ */ b("div", {
				className: "ufs-track ufs-track-research",
				"aria-label": t("games.underfallingskies.researchProgress", { n: e.research }),
				children: [/* @__PURE__ */ y(W, { type: "research" }), /* @__PURE__ */ b("strong", { children: [e.research, /* @__PURE__ */ y("small", { children: "/16" })] })]
			}),
			/* @__PURE__ */ y(it, {
				name: "energy",
				children: /* @__PURE__ */ y(Qe, {
					label: t("games.underfallingskies.energyLabel"),
					value: e.energy,
					kind: "energy"
				})
			}),
			/* @__PURE__ */ y(it, {
				name: "damage",
				children: /* @__PURE__ */ y(Qe, {
					label: t("games.underfallingskies.damageLabel"),
					value: e.damage,
					kind: "damage"
				})
			})
		]
	});
}
function Qe({ label: e, value: t, kind: n }) {
	return /* @__PURE__ */ b("div", {
		className: "ufs-track",
		"data-kind": n,
		"aria-label": `${e} ${t}/7`,
		children: [/* @__PURE__ */ y(W, { type: n }), /* @__PURE__ */ b("strong", { children: [t, /* @__PURE__ */ y("small", { children: "/7" })] })]
	});
}
function $e({ pub: e, selDie: t, onSelectDie: n }) {
	let r = l(), { ref: i } = s("dice"), a = t !== null && (!e.dice[t]?.placed || e.resolving) ? e.dice[t] : null;
	return /* @__PURE__ */ b("div", {
		ref: i,
		className: "ufs-actions",
		"data-collapsed": !!a || void 0,
		"data-resolving": e.resolving || void 0,
		children: [
			/* @__PURE__ */ y("span", {
				className: "ufs-actions-hint",
				role: "status",
				children: r(a ? a.color === "w" ? "games.underfallingskies.whiteSelected" : "games.underfallingskies.placeDieHint" : "games.underfallingskies.pickDieHint", { n: a?.value ?? 0 })
			}),
			/* @__PURE__ */ y("div", {
				className: "ufs-dice-row",
				children: e.dice.map((r, i) => /* @__PURE__ */ y("div", {
					className: "ufs-die-slot",
					"data-hidden": !!a && t !== i || void 0,
					children: /* @__PURE__ */ y(Ye, {
						die: r,
						index: i,
						selected: t === i && !r.placed,
						disabled: !!r.placed || e.resolving,
						onClick: () => n(t === i ? null : i)
					})
				}, i))
			}),
			a && /* @__PURE__ */ y("button", {
				type: "button",
				className: "ufs-change-die",
				onClick: () => n(null),
				children: r("games.underfallingskies.changeDie")
			})
		]
	});
}
function et({ pub: e, disabled: t, onEnd: n }) {
	let r = l(), [i, a] = o(!1), s = e.dice.filter((e) => e.placed).length;
	return /* @__PURE__ */ b("button", {
		type: "button",
		className: "ufs-end-button",
		"data-confirm": i || void 0,
		disabled: t || e.resolving || e.phase !== "rooms",
		onBlur: () => a(!1),
		onClick: () => {
			if (s && !i) {
				a(!0);
				return;
			}
			a(!1), n();
		},
		children: [r(i ? "games.underfallingskies.endRoomsConfirm" : "games.underfallingskies.endRooms", { n: s }), !t && !e.resolving && e.phase === "rooms" && !s && /* @__PURE__ */ y(G, {})]
	});
}
function tt({ children: e }) {
	let { ref: t, hidden: n } = s("mom");
	return /* @__PURE__ */ y("span", {
		ref: t,
		className: "ufs-mother-anchor",
		style: { visibility: n ? "hidden" : void 0 },
		children: e
	});
}
function nt({ col: e, children: t }) {
	let { ref: n } = s(`drop:${e}`);
	return /* @__PURE__ */ y("div", {
		ref: n,
		className: "ufs-drop-anchor",
		children: t
	});
}
function rt({ col: e }) {
	let { ref: t } = s(`city:${e}`);
	return /* @__PURE__ */ y("span", { ref: t });
}
function it({ name: e, children: t }) {
	let { ref: n } = s(e);
	return /* @__PURE__ */ y("div", {
		ref: n,
		className: "ufs-track-anchor",
		children: t
	});
}
//#endregion
//#region src/games/underfallingskies/fx.tsx
var K = (e, t) => Number(e.data?.[t] ?? 0), at = (e) => e.data?.params ?? {}, ot = (e, t = 16, n = t) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), q = (e, t, n, r) => {
	let i = r === void 0 ? null : e.anchor(`ship:${r}`);
	return ot(t, i ? i.w / (n === "w" ? 1 : Math.SQRT2) : 15 * (e.anchor("excavator")?.w ?? 22) / 22);
}, J = (e, t, n) => e.anchor(t === 0 ? `drop:${n}` : t > 16 ? `city:${n}` : `sky:${t}:${n}`), st = (e, t) => t.anchor(`cell:${K(e, "row")}:${K(e, "col")}`), Y = (e, t, n) => e ? /* @__PURE__ */ y(w, {
	at: e,
	ms: t
}, n) : null, X = (e, t, n, r) => e ? /* @__PURE__ */ y(S, {
	at: e,
	ms: n,
	children: /* @__PURE__ */ y("span", {
		className: "ufs-fx-number",
		children: t
	})
}, r) : null;
function Z(e, t, n) {
	return {
		ms: z(e.kind),
		node: t,
		...n?.length ? { hide: n } : {}
	};
}
function ct(e, t, n, r) {
	let i = z(e.kind);
	return Z(e, [
		Y(st(e, t), i, "source"),
		Y(t.anchor(n), i, "target"),
		X(t.anchor(n), r, i, "value")
	]);
}
function lt(e, t) {
	let n = e.data?.moves ?? [], r = z(e.kind), i = [];
	return Z(e, n.map((e) => {
		let n = J(t, e.fromRow, e.fromCol), a = J(t, e.toRow, e.toCol);
		return !n || !a ? null : (t.queued || i.push(`ship:${e.id}`), /* @__PURE__ */ y(C, {
			from: q(t, n, e.color, e.id),
			to: q(t, a, e.color, e.id),
			ms: r,
			children: /* @__PURE__ */ y("span", {
				className: "ufs-fx-ship",
				"data-color": e.color
			})
		}, e.id));
	}), i);
}
function ut(e, t) {
	let n = P[K(e, "from")], r = P[K(e, "to")], i = n && t.anchor(`cell:${n[0]}:${n[1]}`), a = r && t.anchor(`cell:${r[0]}:${r[1]}`), o = z(e.kind), s = t.anchor("excavator");
	return Z(e, [i && a && /* @__PURE__ */ y(C, {
		from: ot(i, s?.w ?? 22, s?.h ?? 17),
		to: ot(a, s?.w ?? 22, s?.h ?? 17),
		ms: o,
		children: /* @__PURE__ */ y("span", {
			className: "ufs-fx-excavator",
			children: "▰"
		})
	}, "dig"), Y(a, o, "path")], i && a && !t.queued ? ["excavator"] : []);
}
var Q = (e) => (t, n) => Z(t, Y(n.anchor(e), z(t.kind), e)), $ = (e, t) => Z(e, Y(st(e, t), z(e.kind), "room")), dt = {
	roll: Q("dice"),
	reroll: Q("dice"),
	place(e, t) {
		let n = t.anchor(`die:${K(e, "die")}`), r = t.anchor(`placedDie:${K(e, "die")}`);
		return !n || !r ? $(e, t) : Z(e, /* @__PURE__ */ y(C, {
			from: n,
			to: r,
			ms: z("place"),
			children: /* @__PURE__ */ y("span", {
				className: "ufs-fx-die",
				"data-color": e.data.color,
				children: /* @__PURE__ */ y(Me, { value: K(e, "value") })
			})
		}), t.queued ? [] : [`placedDie:${K(e, "die")}`]);
	},
	descend: lt,
	drift: lt,
	noDescent: (e, t) => Z(e, Y(t.anchor(`drop:${K(e, "col")}`), z("noDescent"), "col")),
	blocked: (e, t) => Z(e, Y(J(t, K(e, "row"), K(e, "col")), z("blocked"), "blocked")),
	shadow: (e, t) => Z(e, [Y(J(t, K(e, "row"), K(e, "col")), z("shadow"), "shadow"), Y(t.anchor("mom"), z("shadow"), "mom")]),
	mothership(e, t) {
		let n = t.anchor("mom"), r = J(t, 1, 2), i = J(t, 2, 2);
		if (!n || !r || !i) return null;
		let a = {
			...n,
			y: n.y - (K(e, "to") - K(e, "from")) * (i.y - r.y)
		}, o = z("mothership");
		return Z(e, /* @__PURE__ */ y(C, {
			from: a,
			to: n,
			ms: o,
			children: /* @__PURE__ */ y("span", {
				className: "ufs-mother-shape",
				style: {
					width: "100%",
					height: "100%",
					backgroundImage: `url("${U}mothership.webp")`
				}
			})
		}), t.queued ? [] : ["mom"]);
	},
	cityHit(e, t) {
		let n = z("cityHit");
		return Z(e, [
			X(t.anchor(`city:${K(e, "col")}`), "💥", n, "hit"),
			X(t.anchor("damage"), "+1", n, "damage"),
			Y(t.anchor("damage"), n, "track")
		]);
	},
	damage: (e, t) => Z(e, [Y(t.anchor("damage"), z("damage"), "track"), X(t.anchor("damage"), "+1", z("damage"), "damage")]),
	pay: (e, t) => ct(e, t, "energy", `⚡−${at(e).cost}`),
	energy: (e, t) => ct(e, t, "energy", `⚡${at(e).delta}`),
	research: (e, t) => ct(e, t, "research", `⌬+${at(e).n}`),
	researchBack: (e, t) => Z(e, [Y(t.anchor("research"), z("researchBack"), "track"), X(t.anchor("research"), `⌬−${at(e).n}`, z("researchBack"), "value")]),
	excavate: ut,
	excavatorBack: ut,
	shoot(e, t) {
		let n = e.data?.ships ?? [], r = z("shoot");
		return Z(e, [Y(st(e, t), r, "source"), ...n.flatMap((e, n) => {
			let i = J(t, e.row, e.col), a = t.anchor("mom");
			return [X(i, "💥", r, `hit:${n}`), e.color === "p" && i && a ? /* @__PURE__ */ y(C, {
				from: q(t, i, e.color),
				to: q(t, a, e.color),
				ms: r,
				children: /* @__PURE__ */ y("span", {
					className: "ufs-fx-ship",
					"data-color": "p"
				})
			}, `return:${n}`) : null];
		})]);
	},
	noTargets: $,
	discard: $,
	aa: $,
	tunnel: $,
	endRooms: Q("dice"),
	roomsStart: Q("dice"),
	reinforce: (e, t) => Z(e, X(t.anchor("mom"), `◇+${at(e).n}`, z("reinforce"), "ships")),
	noReinforce: Q("mom"),
	noAction: Q("mom"),
	spawnChoice: Q("mom"),
	spawnFull: Q("mom"),
	spawn(e, t) {
		let n = t.anchor("mom"), r = J(t, K(e, "row"), K(e, "col"));
		if (!n || !r) return null;
		let i = e.data.color ?? "p";
		return Z(e, /* @__PURE__ */ y(C, {
			from: q(t, n, i, K(e, "id")),
			to: q(t, r, i, K(e, "id")),
			ms: z("spawn"),
			children: /* @__PURE__ */ y("span", {
				className: "ufs-fx-ship",
				"data-color": e.data.color
			})
		}), t.queued ? [] : [`ship:${K(e, "id")}`]);
	},
	win: (e, t) => Z(e, X(t.anchor("research"), "★", z("win"), "win")),
	lose: (e, t) => Z(e, [Y(t.anchor("mom"), z("lose"), "mother"), Y(t.anchor("damage"), z("lose"), "damage")])
};
//#endregion
//#region src/games/underfallingskies/endgame-review.tsx
function ft({ board: e, renderResult: t, ...n }) {
	let s = l(), [c, u] = o(!0), [f, p] = o(null), g = a(null), _ = a(null), v = a(null);
	r(() => {
		if (!f) return;
		v.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => p(null), 5e3);
		return () => clearTimeout(e);
	}, [f]);
	let x = (e) => {
		p(null), u(e), requestAnimationFrame(() => (e ? g : _).current?.focus({ preventScroll: !0 }));
	}, S = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => p({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => p({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => p({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), C = {
		...n,
		...S
	};
	return /* @__PURE__ */ b("div", {
		className: "underfallingskies-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ y("div", {
				className: "underfallingskies-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ y("div", {
				className: "underfallingskies-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ b("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), x(!1));
					},
					className: "underfallingskies-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ b("header", {
							className: "underfallingskies-endgame-heading",
							children: [/* @__PURE__ */ b("div", {
								className: "underfallingskies-endgame-brand",
								children: [/* @__PURE__ */ y("span", {
									"aria-hidden": "true",
									children: F.icon
								}), s(F.nameKey)]
							}), /* @__PURE__ */ y("button", {
								type: "button",
								ref: g,
								className: "btn-quiet",
								"aria-label": s("games.underfallingskies.reviewHide"),
								title: s("games.underfallingskies.reviewHide"),
								onClick: () => x(!1),
								children: /* @__PURE__ */ y(m, { size: 19 })
							})]
						}),
						/* @__PURE__ */ y("div", {
							className: "underfallingskies-endgame-result",
							inert: f !== null,
							children: t(C)
						}),
						f && /* @__PURE__ */ b("div", {
							className: "underfallingskies-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || p(null);
							},
							children: [/* @__PURE__ */ y("button", {
								type: "button",
								ref: v,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = f.run;
									p(null), e();
								},
								children: s(f.label === "again" ? "games.underfallingskies.reviewConfirmAgain" : "games.underfallingskies.reviewConfirmLobby")
							}), /* @__PURE__ */ y("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									p(null), g.current?.focus({ preventScroll: !0 });
								},
								children: s("games.underfallingskies.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ y("div", {
				className: "underfallingskies-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ b("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => x(!0),
					children: [
						/* @__PURE__ */ y(h, { size: 18 }),
						s("games.underfallingskies.reviewShow"),
						/* @__PURE__ */ y(d, { size: 18 })
					]
				})
			})
		]
	});
}
function pt({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: u, renderRowExtra: d, summary: p, navigation: h, content: g, afterRanking: _, scoreUnit: x, rankOf: S }) {
	let C = l(), w = c((e) => e.locale), [T, E] = o({}), D = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? ee(n, w) : e;
	}, O = (t, n) => S?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), k = e.ranking.some((t) => e.scores?.[t] !== void 0), A = (t, n) => /* @__PURE__ */ b("div", {
		className: "underfallingskies-score-identity",
		children: [
			/* @__PURE__ */ b("span", {
				className: "underfallingskies-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ y("span", {
					"aria-label": C("games.underfallingskies.reviewWinner"),
					children: "♛ "
				}), k && O(t, n)]
			}),
			/* @__PURE__ */ b("span", {
				className: "underfallingskies-score-name",
				children: [D(t), t === r && /* @__PURE__ */ y("small", { children: C("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ b("small", {
				className: "underfallingskies-score-autopilot",
				children: [
					/* @__PURE__ */ y(f, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), j = (t) => e.ranking.map((n) => /* @__PURE__ */ y("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ b("div", {
		className: "underfallingskies-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ y(te, {}),
			h,
			/* @__PURE__ */ b("div", {
				className: "underfallingskies-score-body",
				children: [
					p && /* @__PURE__ */ y("div", {
						className: "underfallingskies-score-summary",
						children: p
					}),
					i !== void 0 && /* @__PURE__ */ y("p", {
						className: "underfallingskies-score-hints",
						children: C("session.hint.usedCount", { n: i })
					}),
					g ?? (u?.length ? /* @__PURE__ */ y("div", {
						className: "underfallingskies-score-table-scroll",
						children: /* @__PURE__ */ b("table", {
							className: "underfallingskies-score-table",
							"aria-label": C(F.nameKey),
							children: [
								/* @__PURE__ */ y("thead", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", { scope: "col" }), /* @__PURE__ */ y(v, { children: e.ranking.map((t, n) => /* @__PURE__ */ y("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: A(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ y("tbody", { children: u.map((e, t) => /* @__PURE__ */ b(n, { children: [/* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ b("button", {
										type: "button",
										"aria-expanded": !!T[t],
										onClick: () => E((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ y(m, { size: 15 }), e.label]
									}) : e.label
								}), j(e)] }), T[t] && e.details?.map((e, t) => /* @__PURE__ */ b("tr", {
									className: "underfallingskies-score-sub",
									children: [/* @__PURE__ */ y("th", {
										scope: "row",
										children: e.label
									}), j(e)]
								}, t))] }, t)) }),
								k && /* @__PURE__ */ y("tfoot", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
									scope: "row",
									children: C("games.underfallingskies.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ y("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ y("ol", {
						className: "underfallingskies-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ b("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ b("div", {
								className: "underfallingskies-score-rankline",
								children: [A(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ b("strong", {
									className: "underfallingskies-score-points",
									children: [e.scores[t], x && /* @__PURE__ */ y("small", { children: x })]
								})]
							}), d?.(t)]
						}, t))
					})),
					_,
					!!u?.length && d && /* @__PURE__ */ y("div", {
						className: "underfallingskies-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ b("details", { children: [/* @__PURE__ */ y("summary", { children: D(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ b("footer", {
				className: "underfallingskies-score-actions",
				children: [
					s && /* @__PURE__ */ y("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: C("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ y("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: C("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ y("p", { children: C("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/underfallingskies/game-over.tsx
function mt(e) {
	let { result: t, public: n } = e, r = l(), i = n, a = t.winner.length > 0, o = i.threatened.filter(Boolean).length;
	return /* @__PURE__ */ y(pt, {
		...e,
		content: /* @__PURE__ */ y("div", {
			className: "ufs-result-report",
			children: /* @__PURE__ */ b("div", {
				className: "ufs-result",
				"data-win": a,
				style: {
					"--ufs-sky-art": `url("${U}sky.webp")`,
					"--ufs-city-art": `url("${U}city.webp")`,
					"--ufs-mother-art": `url("${U}mothership.webp")`
				},
				children: [/* @__PURE__ */ b("div", {
					className: "ufs-result-scene",
					"aria-hidden": !0,
					children: [
						/* @__PURE__ */ b("div", {
							className: "ufs-result-sky",
							children: [
								/* @__PURE__ */ y("span", {
									className: "ufs-result-mother",
									children: /* @__PURE__ */ y("span", { className: "ufs-mother-shape" })
								}),
								/* @__PURE__ */ y("span", {
									className: "ufs-result-research",
									children: /* @__PURE__ */ y(W, { type: "research" })
								}),
								/* @__PURE__ */ y("span", { className: "ufs-result-beam" })
							]
						}),
						/* @__PURE__ */ y("div", { className: "ufs-result-city" }),
						/* @__PURE__ */ b("div", {
							className: "ufs-result-ground",
							children: [
								/* @__PURE__ */ y("span", { children: /* @__PURE__ */ y(W, { type: "energy" }) }),
								/* @__PURE__ */ y("span", { children: /* @__PURE__ */ y(W, { type: "research" }) }),
								/* @__PURE__ */ y("span", { children: /* @__PURE__ */ y(W, { type: "fighter" }) })
							]
						})
					]
				}), /* @__PURE__ */ b("div", {
					className: "ufs-result-details",
					children: [
						/* @__PURE__ */ b("div", {
							className: "ufs-result-copy",
							children: [
								/* @__PURE__ */ y("span", {
									className: "ufs-result-kicker",
									children: r("games.underfallingskies.cityLabel")
								}),
								/* @__PURE__ */ y("h1", {
									className: "font-display text-2xl font-extrabold",
									children: r(a ? "games.underfallingskies.overWin" : "games.underfallingskies.overLose")
								}),
								!a && i.loseReason && /* @__PURE__ */ y("p", {
									className: "ufs-result-reason text-sm font-bold",
									children: r(i.loseReason)
								}),
								/* @__PURE__ */ y("p", {
									className: "text-sm font-bold opacity-70",
									children: r("games.underfallingskies.overStats", {
										round: i.round,
										threat: o
									})
								})
							]
						}),
						/* @__PURE__ */ b("div", {
							className: "ufs-result-tracks",
							children: [
								/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y("small", { children: r("games.underfallingskies.researchLabel") }), /* @__PURE__ */ b("b", { children: [i.research, "/16"] })] }),
								/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y("small", { children: r("games.underfallingskies.damageLabel") }), /* @__PURE__ */ b("b", { children: [i.damage, "/7"] })] }),
								/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y("small", { children: r("games.underfallingskies.mothershipLabel") }), /* @__PURE__ */ b("b", { children: [
									i.momRow,
									"/",
									i.skullRow
								] })] })
							]
						}),
						/* @__PURE__ */ y("div", {
							className: "ufs-result-log",
							children: /* @__PURE__ */ y(_, {
								log: i.log,
								line: (e) => /* @__PURE__ */ b(v, { children: [r("games.underfallingskies.logRound", { n: e.round }), Le(e, r)] })
							})
						})
					]
				})]
			})
		})
	});
}
function ht(e) {
	return /* @__PURE__ */ y(ft, {
		...e,
		board: /* @__PURE__ */ y(ze, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ y(mt, { ...e })
	});
}
//#endregion
//#region src/games/underfallingskies/options.tsx
function gt({ value: e, onChange: t }) {
	let n = l(), r = ae.safeParse(e), i = r.success ? r.data : ae.parse(void 0);
	return /* @__PURE__ */ b("div", {
		className: "ufs-options flex flex-col gap-2",
		children: [
			/* @__PURE__ */ y("p", {
				className: "section-label",
				children: n("games.underfallingskies.optThreat")
			}),
			/* @__PURE__ */ y("div", {
				className: "ufs-threat-options",
				children: [
					0,
					1,
					2,
					3,
					4
				].map((e) => {
					let r = i.threat === e;
					return /* @__PURE__ */ b("button", {
						type: "button",
						onClick: () => t({ threat: e }),
						className: "ufs-threat-option",
						"aria-pressed": r,
						style: { "--ufs-accent": F.accent },
						children: [/* @__PURE__ */ y("strong", { children: n(`games.underfallingskies.optThreat${e}`) }), /* @__PURE__ */ y("span", {
							className: "ufs-threat-tiles",
							"aria-hidden": !0,
							children: Array.from({ length: 4 }, (t, n) => /* @__PURE__ */ y("i", { "data-threatened": n < e || void 0 }, n))
						})]
					}, e);
				})
			}),
			/* @__PURE__ */ y("p", {
				className: "text-sm text-ink/70",
				children: n("games.underfallingskies.optThreatHint")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/underfallingskies/entry.tsx
var _t = {
	definition: Ae,
	View: ze,
	fx: dt,
	OverView: ht,
	Options: gt,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "坠空之下",
			desc: "单人防御游戏：使用骰子调度地下基地，在外星母舰抵达前完成研究",
			rules: "目标与胜负：\n· 研究标记达到研究轨第 16 格时获胜。\n· 基地损伤达到 7，或母舰抵达骷髅行时失败。\n· 任意阶段达到胜负条件时，游戏立即结束。\n初始设置：\n· 4 块天空板按颜色由深到浅排列，5 艘紫色飞船位于母舰投放点。\n· 每轮使用 3 颗灰色骰子和 2 颗白色骰子。\n回合流程：\n· 每轮依次进行骰子阶段、房间阶段和母舰阶段。\n· 自动结算完成后可继续操作，已发生的事件可通过对局日志查看。\n一、骰子阶段：\n· 系统掷出 5 颗骰子。选择一颗骰子，再选择基地中可放置的房间。\n· 每列限放一颗骰子，车库不能放置骰子。\n· 放置后，该列所有飞船自动下降与骰子点数相同的格数，再结算所在格的效果。\n· 放置在高射炮中时，下降距离减少 1 格。\n· 下降距离为 0 时，不移动飞船，也不触发所在格的效果。\n· 放置白色骰子后，系统重掷所有尚未放置的骰子。\n· 未开挖格须位于挖掘机路径上，骰子点数不得小于挖掘机到该格的路径距离。\n· 未开挖区域同时最多放置一颗骰子。\n· 5 颗骰子全部放置并结算完毕后，自动进入房间阶段。\n二、房间阶段：\n· 选择基地中已放置的骰子，按任意顺序使用房间或弃置骰子。\n· 房间数值等于该房间内骰子点数之和加上房间修正值。\n· 多格房间须在每格放置骰子后才能使用。\n· 使用房间须支付标示的能量消耗；能量不足或选择不使用时，可以弃置骰子。\n· 能源房按房间数值调整能量，能量上限为 7。\n· 使用研究房时，先选择前进格数，再确认使用。\n· 经过各格的研究费用总和不得超过房间数值。\n· 战机房击落爆炸格上的所有飞船，条件是该格数值不超过房间数值。\n· 被击落的紫色飞船返回母舰，白色飞船移出游戏。\n· 未开挖格中的骰子用于挖掘：支付 1 能量，将挖掘机推进至该格。\n· 挖掘后开通沿途房间，本次不执行该房间的效果。\n· 高射炮的减速效果已在骰子阶段生效，隧道没有房间效果，均只需移除骰子。\n· 完成房间操作后，选择“结束房间阶段”。提前结束须再次确认弃置剩余骰子。\n三、母舰阶段：\n· 系统依次结算母舰下降一行、收回该行飞船、执行该行效果及投放飞船。\n· 行效果包括挖掘机后退、研究标记后退、白色飞船增援或基地受损。\n· 先投放紫色飞船，再投放白色飞船，优先选择没有飞船的列。\n· 各列均有飞船时，选择母舰与该列最高飞船距离最远的列。\n· 多个列同时符合投放条件时，由玩家选择。\n· 投放点全部被占用时，剩余飞船留在母舰。\n· 投放结束后，系统开始下一轮并重新掷骰。\n图例：\n· 天空箭头（‹、›）：飞船沿指示方向横移一格，目标格已有飞船时不移动。\n· 天空船影（◇）：飞船下降至该格时，触发母舰立即下降一行。\n· 爆炸格：格内数字用于判断战机的攻击条件，飞船不会自动被击落。\n· 城市：飞船抵达城市时，基地损伤增加 1，飞船返回母舰。\n· 基地符号：⌖ 高射炮；⚡ 能源房；⌬ 研究房；✦ 战机房；▨ 隧道；▰ 车库或挖掘机。\n· 房间旁的 ⚡ 数字表示使用房间所需能量，带正负号的数字表示房间修正值。",
			round: "第 {{n}} 轮",
			reserve: "储备 ⚪{{n}}",
			skyLabel: "天空战线",
			mothershipLabel: "母舰",
			mothershipPool: "待投放：紫色 {{purple}} 艘，白色 {{white}} 艘",
			motherEffectRow: "第 {{row}} 行：{{effect}}",
			motherEffectNone: "无额外效果",
			motherEffectReinforce: "增加 {{n}} 艘白色飞船增援",
			motherEffectExcavator: "挖掘机后退 {{n}} 格",
			motherEffectExcavatorOne: "挖掘机后退 1 格",
			motherEffectResearch: "研究标记后退 {{n}} 格",
			motherEffectResearchOne: "研究标记后退 1 格",
			motherEffectDamage: "基地损伤增加 1",
			changeDie: "更换骰子",
			advanceSpaces: "前进格数",
			researchTotal: "所需研究点数",
			baseLabel: "地下基地",
			cityLabel: "罗斯威尔 · 最后防线",
			mothershipPosition: "母舰 {{n}}/{{limit}}",
			excavatorProgress: "挖掘机 {{n}}/{{total}}",
			researchProgress: "研究进度 {{n}}/16",
			researchSpace: "研究轨第 {{n}} 格，所需研究点数 {{cost}}",
			researchDestination: "研究轨第 {{n}} 格，所需研究点数 {{cost}}，本次研究落点",
			researchLabel: "研究",
			nextResearchCost: "下一格研究费用 {{n}}",
			energyLabel: "能量",
			damageLabel: "损伤",
			roomSpaceAria: "基地第 {{row}} 行第 {{col}} 列，{{name}}",
			roomFill: "已放置骰子 {{n}}/{{total}} · 房间数值 {{value}}",
			closeRoom: "关闭房间操作",
			researchSteps: "选择研究前进格数",
			pickDieHint: "选择一颗骰子",
			placeDieHint: "选择可放置的房间",
			phaseDice: "骰子阶段",
			phaseDiceSub: "放置后自动结算飞船移动与白色骰子重掷",
			phaseRooms: "房间阶段",
			phaseRoomsSub: "选择基地中的骰子，使用房间或弃置骰子",
			phaseMothership: "母舰阶段",
			phaseSpawn: "选择投放列",
			phaseSpawnSub: "多个列符合投放条件，请选择其中一列",
			spawnCol: "投放到第 {{n}} 列",
			room: {
				aa: "高射炮(放置骰子时，本列飞船的下降距离减少 1 格)",
				energy: "能源房",
				research: "研究房",
				fighter: "战机房",
				tunnel: "隧道(无效果)",
				garage: "车库",
				excavator: "未开挖格"
			},
			roomBoard: {
				aa: "高射炮",
				energy: "能源房",
				research: "研究房",
				fighter: "战机房",
				tunnel: "隧道",
				garage: "车库"
			},
			roomValue: "房间数值 {{n}}",
			roomIncomplete: "多格房间须在每格放置骰子后才能使用",
			researchShort: "房间数值不足以支付下一格的研究费用",
			noEnergy: "当前能量不足以支付所需消耗",
			doExcavate: "挖掘（⚡1）",
			doDiscard: "弃置骰子",
			doRemove: "移除骰子",
			doResearch: "推进研究 {{n}} 格",
			doResearchOne: "推进研究 1 格",
			doEnergy: "使用能源房（{{delta}}）",
			doShoot: "击落飞船（≤{{n}}）",
			endRooms: "结束房间阶段",
			resolving: "正在自动结算，完成后可继续操作",
			diceRemaining: "剩余 {{n}} 颗骰子待放置 · 选择骰子后选择房间",
			whiteSelected: "放置后重掷未放置骰子",
			graySelected: "灰色骰子 {{n}} 点 · 选择可放置的房间",
			roomsRemaining: "剩余 {{n}} 颗骰子待结算 · 选择基地中的骰子",
			roomsFinished: "房间结算完成 · 选择“结束房间阶段”进入母舰阶段",
			spawnRemaining: "选择投放列 · 待投放：紫色 {{purple}} 艘，白色 {{white}} 艘",
			endRoomsRemaining: "弃置剩余 {{n}} 颗骰子并结束阶段",
			endRoomsConfirm: "再次点击以确认弃置 {{n}} 颗骰子",
			cancelEnd: "取消结束阶段",
			roomCost: "所需能量 ⚡{{n}} · 当前能量 {{energy}}",
			roomFree: "无需消耗能量 · 当前能量 {{energy}}",
			excavateHelp: "将挖掘机推进至此格，开通沿途房间；本次不执行该房间的效果。",
			researchHelp: "研究标记可前进 1–{{n}} 格，选择格数后使用研究房。",
			shootHelp: "可击落 {{n}} 艘飞船：须位于爆炸格，且该格数值不超过 {{value}}。",
			energyPreview: "使用后能量 {{from}} → {{to}} · 变化 {{delta}}（上限 7）",
			logRound: "第 {{n}} 轮 · ",
			errResolving: "自动结算尚未完成，请稍候",
			log: {
				roll: "掷出骰子，点数为 {{dice}}。",
				place: "{{value}} 点骰子已放置于基地第 {{row}} 行、第 {{col}} 列的{{room}}。",
				descend: "第 {{col}} 列 {{n}} 艘飞船同时下降 {{distance}} 格。",
				noDescent: "第 {{col}} 列飞船未移动（计算下降距离 {{distance}} 格，飞船数量 {{n}} 艘）。",
				drift: "第 {{row}} 行箭头效果：飞船由第 {{from}} 列横移至第 {{to}} 列。",
				blocked: "第 {{row}} 行、第 {{col}} 列的箭头指向已被占用的格子，飞船未横移。",
				shadow: "飞船位于第 {{row}} 行、第 {{col}} 列的船影格，触发母舰下降一行。",
				cityHit: "第 {{col}} 列飞船抵达城市：损伤增加 1（{{from}} → {{to}}），飞船返回母舰。",
				reroll: "白色骰子已放置，重掷其余 {{n}} 颗骰子，点数为 {{dice}}。",
				roomsStart: "5 颗骰子全部放置完毕，进入房间阶段。",
				pay: "{{room}}结算：已支付 {{cost}} 能量（{{from}} → {{to}}）。",
				energy: "能源房数值为 {{value}}，能量变化 {{delta}}（{{from}} → {{to}}，上限 7）。",
				research: "使用研究房，研究标记前进 {{n}} 格（{{from}} → {{to}}，目标 16）。",
				shoot: "战机房数值为 {{value}}，击落 {{n}} 艘飞船：{{purple}} 艘紫色飞船返回母舰，{{white}} 艘白色飞船移出游戏。",
				noTargets: "战机房数值为 {{value}}，没有符合攻击条件的飞船，本次未击落飞船。",
				excavate: "挖掘机前进 {{n}} 格（{{from}} → {{to}}），沿途房间已开通。",
				discard: "已弃置{{room}}中的 {{n}} 颗骰子，未执行房间效果。",
				aa: "高射炮中的骰子已移除，其减速效果已在骰子阶段生效。",
				tunnel: "隧道没有房间效果，骰子已移除。",
				endRooms: "房间阶段结束，剩余 {{n}} 颗骰子已弃置，进入母舰阶段。",
				mothership: "母舰由第 {{from}} 行下降至第 {{to}} 行，收回该行 {{n}} 艘飞船。",
				excavatorBack: "母舰行效果：挖掘机后退 {{n}} 格（{{from}} → {{to}}）。",
				researchBack: "母舰行效果：研究标记后退 {{n}} 格（{{from}} → {{to}}）。",
				reinforce: "母舰行效果：新增 {{n}} 艘白色飞船，等待投放。",
				noReinforce: "白色飞船储备已耗尽，本次未增加增援。",
				noAction: "母舰第 {{row}} 行无额外效果，进入飞船投放。",
				damage: "母舰行效果：基地损伤增加 1（{{from}} → {{to}}，上限 7）。",
				spawn: "{{color}}飞船已投放至第 {{col}} 列、第 {{row}} 行。",
				spawnChoice: "符合投放条件的列：{{cols}}。等待选择投放列。",
				spawnFull: "所有投放点均已被占用，剩余 {{n}} 艘飞船留在母舰，本轮投放结束。",
				win: "研究达到第 16 格，本局获胜。",
				lose: "本局失败：{{reason}}。"
			},
			purpleShip: "紫色",
			whiteShip: "白色",
			dieWhite: "白色骰子 {{n}} 点",
			dieGray: "灰色骰子 {{n}} 点",
			optThreat: "威胁度",
			optThreat0: "0",
			optThreat1: "1",
			optThreat2: "2",
			optThreat3: "3",
			optThreat4: "4",
			optThreatHint: "将对应数量的随机天空板翻至威胁面，改变研究费用、天空格效果及母舰行效果，提高游戏难度。",
			overWin: "研究完成，本局获胜",
			overLose: "城市陷落，本局失败",
			overStats: "第 {{round}} 轮 · 威胁度 {{threat}}",
			loseDamage: "基地损伤达到 7",
			loseMothership: "母舰抵达骷髅行",
			errDone: "本局已结束",
			errNotPlayer: "当前玩家未参与本局游戏",
			errPhase: "当前阶段无法执行此操作",
			errDiePlaced: "该骰子已放置",
			errColTaken: "该列已放置骰子",
			errGarage: "车库不能放置骰子",
			errNotOnPath: "未开挖区域的骰子须放置在挖掘机路径上",
			errExcavatorFar: "骰子点数小于挖掘机到目标格的路径距离",
			errTwoAhead: "未开挖区域同时最多放置一颗骰子",
			errNoDie: "该格未放置骰子",
			errRoomIncomplete: "多格房间须在每格放置骰子后才能使用",
			errNoEnergy: "能量不足",
			errResearchCost: "所选前进格数超出研究轨范围，或研究费用超过房间数值",
			errSpawnCol: "请选择符合投放条件的列"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Under Falling Skies",
			desc: "Solo defense: roll dice to run your underground base and finish the research before the mothership arrives",
			rules: "Goal and game end:\n· Advance the research marker to space 16 to win.\n· You lose if base damage reaches 7 or the mothership reaches the skull row.\n· The game ends immediately when either condition is met, in any phase.\nSetup:\n· Arrange the 4 sky tiles from darkest to lightest, with 5 purple ships at the mothership drop points.\n· Each round uses 3 grey dice and 2 white dice.\nRound sequence:\n· Each round has a dice phase, a rooms phase and a mothership phase, in that order.\n· Continue when automatic resolution finishes. The game log records resolved events.\n1. Dice phase:\n· The game rolls 5 dice. Select a die, then select a room where it can be placed.\n· Each column can hold one die. Dice cannot be placed in the garage.\n· All ships in that column automatically descend by the die value, then resolve their landing effects.\n· Placing a die in an AA gun reduces the descent distance by 1.\n· If the distance is 0, ships do not move or trigger effects.\n· After a white die is placed, the game rerolls all unplaced dice.\n· An unexcavated space must be on the excavator path. The die value must cover the path distance from the excavator to that space.\n· Only one die can occupy the unexcavated area at a time.\n· Once all 5 dice have been placed and resolved, the rooms phase begins automatically.\n2. Rooms phase:\n· Select a die in the base to use its room or discard its dice, in any order.\n· The room value is the sum of its dice plus its modifier.\n· A multi-space room requires a die in every space before it can be used.\n· Using a room requires its displayed energy cost. Discard its dice if you cannot pay or choose not to use it.\n· Energy rooms adjust energy by their room value. The energy limit is 7.\n· To use a research room, select the number of spaces to advance, then confirm.\n· The total research cost of the spaces entered cannot exceed the room value.\n· Fighter rooms shoot down all ships on explosion spaces numbered no higher than the room value.\n· Purple ships shot down return to the mothership. White ships shot down are removed from the game.\n· A die in an unexcavated space is used for excavation: pay 1 energy to move the excavator to that space.\n· Excavation opens the rooms along the path. This does not apply the room effect.\n· AA guns have already reduced descent during the dice phase. Tunnels have no room effect. Remove their dice.\n· Select “End rooms phase” when finished. Ending early requires confirmation to discard the remaining dice.\n3. Mothership phase:\n· The game automatically moves the mothership down one row, collects ships in that row, applies its row effect and spawns ships, in that order.\n· Row effects can move the excavator or research marker back, add white reinforcements or damage the base.\n· Purple ships spawn before white ships. Empty columns take priority.\n· If every column contains ships, use the column with the greatest distance between the mothership and its highest ship.\n· Choose a column when several meet the spawning conditions.\n· If all drop points are occupied, the remaining ships stay on the mothership.\n· After spawning ends, the game starts the next round and rolls the dice again.\nSymbols:\n· Sky arrows (‹, ›): move a ship one space in the indicated direction. It does not move if the target space is occupied.\n· Sky silhouette (◇): a ship landing here makes the mothership descend one row immediately.\n· Explosion spaces: the number determines fighter targeting; ships are not shot down automatically.\n· City: a ship reaching the city adds 1 base damage and returns to the mothership.\n· Base symbols: ⌖ AA gun; ⚡ energy room; ⌬ research room; ✦ fighter room; ▨ tunnel; ▰ garage or excavator.\n· The ⚡ number beside a room is its energy cost. A signed number is its room modifier.",
			round: "Round {{n}}",
			reserve: "Reserve ⚪{{n}}",
			skyLabel: "Sky front",
			mothershipLabel: "Mothership",
			mothershipPool: "Awaiting spawn: {{purple}} purple, {{white}} white",
			motherEffectRow: "Row {{row}}: {{effect}}",
			motherEffectNone: "No additional effect",
			motherEffectReinforce: "White reinforcements: +{{n}}",
			motherEffectExcavator: "Move excavator back {{n}} spaces",
			motherEffectExcavatorOne: "Move excavator back 1 space",
			motherEffectResearch: "Move research marker back {{n}} spaces",
			motherEffectResearchOne: "Move research marker back 1 space",
			motherEffectDamage: "Add 1 base damage",
			changeDie: "Change die",
			advanceSpaces: "Advance",
			researchTotal: "Research cost",
			baseLabel: "Underground base",
			cityLabel: "Roswell · last line",
			mothershipPosition: "Mothership {{n}}/{{limit}}",
			excavatorProgress: "Excavator {{n}}/{{total}}",
			researchProgress: "Research {{n}}/16",
			researchSpace: "Research space {{n}}, research cost {{cost}}",
			researchDestination: "Research space {{n}}, research cost {{cost}}, destination for this action",
			researchLabel: "Research",
			nextResearchCost: "Next research cost: {{n}}",
			energyLabel: "Energy",
			damageLabel: "Damage",
			roomSpaceAria: "Base row {{row}}, column {{col}}, {{name}}",
			roomFill: "Dice placed {{n}}/{{total}} · room value {{value}}",
			closeRoom: "Close room actions",
			researchSteps: "Choose research steps",
			pickDieHint: "Choose a die",
			placeDieHint: "Select a room where this die can be placed",
			phaseDice: "Dice phase",
			phaseDiceSub: "Placement automatically resolves ship movement and white die rerolls",
			phaseRooms: "Rooms phase",
			phaseRoomsSub: "Select a base die to use its room or discard its dice",
			phaseMothership: "Mothership phase",
			phaseSpawn: "Choose spawn column",
			phaseSpawnSub: "Several columns qualify; select one for spawning",
			spawnCol: "Spawn in column {{n}}",
			room: {
				aa: "AA gun (reduces ship descent in this column by 1 during placement)",
				energy: "Energy room",
				research: "Research room",
				fighter: "Fighter room",
				tunnel: "Tunnel (no effect)",
				garage: "Garage",
				excavator: "Unexcavated space"
			},
			roomBoard: {
				aa: "AA gun",
				energy: "Energy",
				research: "Research",
				fighter: "Fighter",
				tunnel: "Tunnel",
				garage: "Garage"
			},
			roomValue: "Room value {{n}}",
			roomIncomplete: "A multi-space room requires a die in every space before use",
			researchShort: "The room value is below the cost of the next research space",
			noEnergy: "Current energy is below the required cost",
			doExcavate: "Excavate (⚡1)",
			doDiscard: "Discard dice",
			doRemove: "Remove die",
			doResearch: "Advance research {{n}} spaces",
			doResearchOne: "Advance research 1 space",
			doEnergy: "Use energy room ({{delta}})",
			doShoot: "Shoot down ships (≤{{n}})",
			endRooms: "End rooms phase",
			resolving: "Resolving automatically; continue when complete",
			diceRemaining: "{{n}} dice to place · select a die, then a room",
			whiteSelected: "Placement rerolls unplaced dice",
			graySelected: "Grey die {{n}} · select a room for placement",
			roomsRemaining: "{{n}} dice to resolve · select a die in the base",
			roomsFinished: "Rooms resolved · select “End rooms phase” to begin the mothership phase",
			spawnRemaining: "Select a column · awaiting spawn: {{purple}} purple, {{white}} white",
			endRoomsRemaining: "Discard {{n}} remaining dice and end phase",
			endRoomsConfirm: "Select again to confirm discarding {{n}} dice",
			cancelEnd: "Cancel ending phase",
			roomCost: "Required energy ⚡{{n}} · current energy {{energy}}",
			roomFree: "No energy cost · energy {{energy}}",
			excavateHelp: "Move the excavator to this space and open the rooms along the path. This does not apply the room effect.",
			researchHelp: "Research can advance 1–{{n}} spaces. Select the distance, then use the room.",
			shootHelp: "{{n}} ships can be shot down: each must be on an explosion space numbered no higher than {{value}}.",
			energyPreview: "Energy after use: {{from}} → {{to}} · change {{delta}} (limit 7)",
			logRound: "Round {{n}} · ",
			errResolving: "Automatic resolution is still in progress; please wait",
			log: {
				roll: "Rolled dice with values {{dice}}.",
				place: "Placed a die showing {{value}} in {{room}}, base row {{row}}, column {{col}}.",
				descend: "{{n}} ships in column {{col}} descend {{distance}} spaces together.",
				noDescent: "Ships in column {{col}} did not move (calculated distance {{distance}}, {{n}} ships).",
				drift: "Arrow in row {{row}}: ship shifts from column {{from}} to {{to}}.",
				blocked: "Arrow in row {{row}}, column {{col}} is blocked by another ship.",
				shadow: "A ship on the silhouette in row {{row}}, column {{col}} triggers mothership descent by one row.",
				cityHit: "A ship in column {{col}} reached the city: damage increases by 1 ({{from}} → {{to}}); the ship returns to the mothership.",
				reroll: "A white die was placed. Rerolled {{n}} unplaced dice with values {{dice}}.",
				roomsStart: "All 5 dice have been placed. The rooms phase begins.",
				pay: "{{room}} resolution: paid {{cost}} energy ({{from}} → {{to}}).",
				energy: "Energy room value {{value}}: energy changes by {{delta}} ({{from}} → {{to}}, limit 7).",
				research: "Used a research room to advance {{n}} spaces ({{from}} → {{to}}, goal 16).",
				shoot: "Fighter room value {{value}}: {{n}} ships shot down; {{purple}} purple ships return to the mothership and {{white}} white ships leave the game.",
				noTargets: "Fighter value {{value}}: no ships on eligible explosion spaces; no ships shot.",
				excavate: "Excavator advances {{n}} spaces ({{from}} → {{to}}), opening the path.",
				discard: "Discarded {{n}} dice from {{room}} without activating it.",
				aa: "The AA gun die was removed. Its descent reduction applied during the dice phase.",
				tunnel: "Tunnels have no room effect; the die is removed.",
				endRooms: "The rooms phase ends with {{n}} remaining dice discarded. The mothership phase begins.",
				mothership: "Mothership descends from row {{from}} to {{to}}, collecting {{n}} ships.",
				excavatorBack: "Mothership row effect: the excavator moves back {{n}} spaces ({{from}} → {{to}}).",
				researchBack: "Mothership row effect: the research marker moves back {{n}} spaces ({{from}} → {{to}}).",
				reinforce: "Mothership row effect: added {{n}} white ships awaiting spawning.",
				noReinforce: "Mothership action: no white ships remain in reserve; no reinforcements.",
				noAction: "Mothership row {{row}} has no additional effect. Ship spawning begins.",
				damage: "Mothership row effect: base damage increases by 1 ({{from}} → {{to}}, limit 7).",
				spawn: "{{color}} ship spawned in column {{col}}, row {{row}}.",
				spawnChoice: "Eligible spawn columns: {{cols}}. Awaiting column selection.",
				spawnFull: "All drop points are occupied. {{n}} ships remain on the mothership; spawning ends for this round.",
				win: "Research reached space 16. The game is won.",
				lose: "The game is lost: {{reason}}."
			},
			purpleShip: "Purple",
			whiteShip: "White",
			dieWhite: "White die {{n}}",
			dieGray: "Grey die {{n}}",
			optThreat: "Threat level",
			optThreat0: "0",
			optThreat1: "1",
			optThreat2: "2",
			optThreat3: "3",
			optThreat4: "4",
			optThreatHint: "Flips the selected number of random sky tiles to their threat side, changing research costs, sky space effects and mothership row effects to increase difficulty.",
			overWin: "Research complete. The game is won.",
			overLose: "The city has fallen. The game is lost.",
			overStats: "Round {{round}} · Threat {{threat}}",
			loseDamage: "Base damage reached 7",
			loseMothership: "The mothership reached the skull row",
			errDone: "This game is over",
			errNotPlayer: "You are not in this game",
			errPhase: "This action is unavailable in the current phase",
			errDiePlaced: "That die is already placed",
			errColTaken: "That column already has a die",
			errGarage: "The garage can’t hold a die",
			errNotOnPath: "Unexcavated dice must go on the excavator’s path",
			errExcavatorFar: "The die value is below the path distance from the excavator to the target space",
			errTwoAhead: "Only one die may sit ahead of the excavator",
			errNoDie: "No die on that space",
			errRoomIncomplete: "A multi-space room requires a die in every space before use",
			errNoEnergy: "Not enough energy",
			errResearchCost: "The selected distance exceeds the research track or the total cost exceeds the room value",
			errSpawnCol: "Select a column that meets the spawning conditions"
		}
	}
};
//#endregion
export { _t as default };
