import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { useEffect as n, useLayoutEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useT as s } from "@bgparty/sdk/i18n";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { useFxAnchor as u } from "@bgparty/sdk/fx/anchors";
import { SheetFxProbe as d, SheetView as f } from "@bgparty/sdk/sheet-view";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { Floater as g, FlySprite as _, PulseBox as ee } from "@bgparty/sdk/fx/primitives";
import { GameOverChime as te } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as v, OptionSection as y, OptionSwitch as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/deckers/meta.ts
var ne = {
	id: "deckers",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"deck-bag-building",
		"grid-movement",
		"dice-rolling",
		"action-points"
	],
	interactionTags: ["cooperative"],
	nameKey: "games.deckers.name",
	descKey: "games.deckers.desc",
	rulesKey: "games.deckers.rules",
	icon: "💾",
	iconImg: "games/deckers.webp",
	rulesUrl: { en: "https://cdn.pegasus.de/public/media/54/84/46/1759821920/deckers-rules.pdf?ts=1759822156" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#54c6da",
	releasedAt: "2026-11-01T12:43:00+08:00",
	search: {
		py: "hai ke qian xing",
		init: "hkqx"
	},
	hotseat: "cover",
	botDelayMs: 450
}, re = e.enum([
	"b",
	"g",
	"y",
	"r",
	"p"
]), ie = e.enum([
	"b",
	"g",
	"y",
	"r",
	"p",
	"black",
	"white"
]), ae = e.object({
	smc: e.enum([
		"alphaMoby",
		"spider",
		"glom",
		"logi",
		"viking",
		"sentinel",
		"mother"
	]).default("alphaMoby"),
	introductory: e.boolean().default(!0),
	network: e.enum(["preset", "choose"]).default("preset"),
	fragmented: e.boolean().default(!1),
	upgraded: e.enum([
		"none",
		"2.0",
		"2.1"
	]).default("none"),
	packets: e.boolean().default(!1)
}).default({
	smc: "alphaMoby",
	introductory: !0,
	network: "preset",
	fragmented: !1,
	upgraded: "none",
	packets: !1
}), oe = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("tick"),
		now: e.number()
	}),
	e.object({
		type: e.literal("choose"),
		prompt: e.int().nonnegative(),
		option: e.int().nonnegative()
	}),
	e.object({
		type: e.literal("act"),
		kind: e.enum([
			"upload",
			"install",
			"move",
			"shift",
			"modify",
			"infect",
			"upgrade",
			"execute",
			"reveal",
			"leiko",
			"tokyo",
			"shellshock"
		]),
		pay: e.array(e.int()).max(12),
		color: re.default("b"),
		count: e.int().min(1).max(40).default(1),
		card: e.int().default(0),
		avatar: e.int().min(0).max(1).default(0),
		ghost: e.int().min(-1).max(29).default(-1),
		purple: re.default("b")
	}),
	e.object({
		type: e.literal("endTurn"),
		keep: e.array(e.int()).max(3)
	}),
	e.object({ type: e.literal("finish") }),
	e.object({
		type: e.literal("move"),
		to: e.int().min(0).max(29),
		carry: e.array(e.int()).max(4)
	}),
	e.object({
		type: e.literal("shift"),
		piece: e.int().nonnegative(),
		to: e.int().min(-1).max(29)
	}),
	e.object({
		type: e.literal("ghost"),
		to: e.int().min(0).max(29)
	}),
	e.object({
		type: e.literal("interrupt"),
		card: e.int(),
		target: e.int().default(0),
		value: e.int().min(0).max(6).default(0)
	}),
	e.object({ type: e.literal("pass") }),
	e.object({
		type: e.literal("packet"),
		id: e.int().min(0).max(9)
	})
]), se = e.object({
	id: e.int(),
	kind: e.enum([
		"program",
		"installation",
		"spark",
		"guardian"
	]),
	color: ie,
	at: e.union([e.int(), e.enum([
		"supply",
		"objective",
		"removed",
		"captured",
		"palace",
		"trojan",
		"ghostReserve"
	])]),
	captive: e.int().nullable()
}), ce = e.object({
	id: e.int(),
	tile: re,
	color: re,
	n: e.int(),
	q: e.int(),
	r: e.int()
}), le = e.object({
	label: e.string(),
	at: e.int().optional(),
	piece: e.int().optional(),
	card: e.int().optional(),
	profile: e.string().optional(),
	color: ie.optional(),
	n: e.number().optional(),
	q: e.number().optional(),
	r: e.number().optional(),
	rid: e.string().optional()
}), ue = e.object({
	kind: e.string(),
	at: e.int(),
	to: e.int(),
	piece: e.int().nullable(),
	color: ie,
	n: e.number()
}), de = e.object({
	config: ae,
	busy: e.boolean(),
	focus: e.int(),
	storedOrder: e.array(e.int()),
	phase: e.string(),
	step: e.string(),
	active: e.string(),
	cycle: e.int(),
	objectives: e.array(e.int()),
	results: e.array(e.object({
		id: e.int(),
		success: e.boolean()
	})),
	objectiveSuccess: e.boolean().nullable(),
	cells: e.array(ce),
	tiles: e.array(e.object({
		color: re,
		q: e.int(),
		r: e.int()
	})),
	pieces: e.array(se),
	market: e.array(e.int()),
	upgradeCount: e.int(),
	players: e.array(e.object({
		rid: e.string(),
		profile: e.string(),
		color: re,
		starting: re,
		avatars: e.array(e.int()),
		handCount: e.int(),
		deckCount: e.int(),
		discard: e.array(e.int()),
		turns: e.int(),
		packets: e.array(e.int())
	})),
	prompt: e.object({
		id: e.int(),
		owner: e.string(),
		text: e.string()
	}).nullable(),
	action: e.object({
		kind: e.string(),
		actor: e.string(),
		avatar: e.int(),
		ghost: e.int().nullable(),
		at: e.int(),
		points: e.int(),
		pay: e.array(e.int()),
		purple: re,
		carried: e.array(e.int()),
		password: e.array(e.int()),
		lighthouse: e.int().nullable(),
		lighthouseTo: e.int().nullable(),
		path: e.array(e.int())
	}).nullable(),
	battle: e.object({
		at: e.int(),
		red: e.int(),
		black: e.int(),
		paid: e.int(),
		infect: e.number(),
		resistance: e.number(),
		automatic: e.boolean(),
		bonus: e.number()
	}).nullable(),
	reaction: e.object({
		kind: e.string(),
		passed: e.array(e.string()),
		target: e.int().nullable()
	}).nullable(),
	spawnRoll: e.object({
		server: e.int(),
		n: e.int()
	}).nullable(),
	packets: e.array(e.object({
		id: e.int(),
		type: e.string(),
		at: e.union([e.int(), e.string()])
	})),
	activity: ue.nullable(),
	swarm: re.nullable(),
	palaceAt: e.int().nullable(),
	trojanAt: e.int().nullable(),
	ghostId: e.int().nullable(),
	ghostHealth: e.number(),
	hackman: e.int().nullable(),
	won: e.boolean(),
	reason: e.string(),
	log: e.array(e.object({
		key: e.string(),
		rid: e.string(),
		at: e.int(),
		n: e.number()
	}))
}), fe = e.object({
	hand: e.array(e.int()),
	options: e.array(le),
	revealed: e.array(e.int()),
	root: e.string(),
	starting: e.boolean(),
	search: e.array(e.int()),
	interrupts: e.array(e.object({
		card: e.int(),
		target: e.int(),
		value: e.int()
	})),
	usablePackets: e.array(e.int())
}), x = [
	"b",
	"g",
	"y",
	"r",
	"p"
], pe = [
	{
		id: 1021456,
		key: "intercept",
		commands: "y",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021324,
		key: "infiltrate",
		commands: "rr",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021333,
		key: "decrypt",
		commands: "bb",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021320,
		key: "sabotage",
		commands: "rp",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021438,
		key: "focus",
		commands: "gg",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021342,
		key: "dataScan",
		commands: "bp",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021321,
		key: "sabotage",
		commands: "rp",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021410,
		key: "dataSteal",
		commands: "b",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021331,
		key: "apprentice",
		commands: "r",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021469,
		key: "reroute",
		commands: "yp",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021447,
		key: "bypass",
		commands: "g",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021437,
		key: "memorySteal",
		commands: "gp",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021458,
		key: "diversion",
		commands: "yy",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021329,
		key: "apprentice",
		commands: "r",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021328,
		key: "infiltrate",
		commands: "rr",
		cost: "",
		ability: "",
		type: "basic",
		home: "r"
	},
	{
		id: 1021627,
		key: "memorySteal",
		commands: "gp",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021546,
		key: "dataScan",
		commands: "bp",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021530,
		key: "sabotage",
		commands: "rp",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021628,
		key: "bypass",
		commands: "g",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021545,
		key: "decrypt",
		commands: "bb",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021547,
		key: "dataScan",
		commands: "bp",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021523,
		key: "decrypt",
		commands: "bb",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021659,
		key: "diversion",
		commands: "yy",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021512,
		key: "apprentice",
		commands: "r",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021653,
		key: "reroute",
		commands: "yp",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021543,
		key: "dataSteal",
		commands: "b",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021657,
		key: "intercept",
		commands: "y",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021629,
		key: "focus",
		commands: "gg",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021534,
		key: "infiltrate",
		commands: "rr",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021522,
		key: "dataSteal",
		commands: "b",
		cost: "",
		ability: "",
		type: "basic",
		home: "b"
	},
	{
		id: 1021850,
		key: "bypass",
		commands: "g",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021839,
		key: "focus",
		commands: "gg",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021756,
		key: "decrypt",
		commands: "bb",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021701,
		key: "apprentice",
		commands: "r",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021707,
		key: "intercept",
		commands: "y",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021836,
		key: "memorySteal",
		commands: "gp",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021846,
		key: "bypass",
		commands: "g",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021702,
		key: "sabotage",
		commands: "rp",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021709,
		key: "diversion",
		commands: "yy",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021866,
		key: "reroute",
		commands: "yp",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021755,
		key: "dataSteal",
		commands: "b",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021835,
		key: "memorySteal",
		commands: "gp",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021834,
		key: "focus",
		commands: "gg",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021754,
		key: "dataScan",
		commands: "bp",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1021704,
		key: "infiltrate",
		commands: "rr",
		cost: "",
		ability: "",
		type: "basic",
		home: "g"
	},
	{
		id: 1022045,
		key: "intercept",
		commands: "y",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1021918,
		key: "apprentice",
		commands: "r",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1022040,
		key: "diversion",
		commands: "yy",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1022041,
		key: "reroute",
		commands: "yp",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1021919,
		key: "infiltrate",
		commands: "rr",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1021958,
		key: "memorySteal",
		commands: "gp",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1021941,
		key: "decrypt",
		commands: "bb",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1022042,
		key: "diversion",
		commands: "yy",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1022048,
		key: "bypass",
		commands: "g",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1022030,
		key: "focus",
		commands: "gg",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1022044,
		key: "intercept",
		commands: "y",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1021940,
		key: "dataSteal",
		commands: "b",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1021944,
		key: "dataScan",
		commands: "bp",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1021906,
		key: "sabotage",
		commands: "rp",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1022043,
		key: "reroute",
		commands: "yp",
		cost: "",
		ability: "",
		type: "basic",
		home: "y"
	},
	{
		id: 1022200,
		key: "reroute",
		commands: "yp",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022225,
		key: "infiltrate",
		commands: "rr",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022132,
		key: "focus",
		commands: "gg",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022226,
		key: "sabotage",
		commands: "rp",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022116,
		key: "blackHat",
		commands: "p",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022252,
		key: "dataSteal",
		commands: "b",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022251,
		key: "decrypt",
		commands: "bb",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022115,
		key: "blackHat",
		commands: "p",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022205,
		key: "intercept",
		commands: "y",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022114,
		key: "blackHat",
		commands: "p",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022250,
		key: "dataScan",
		commands: "bp",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022203,
		key: "diversion",
		commands: "yy",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022227,
		key: "apprentice",
		commands: "r",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022131,
		key: "memorySteal",
		commands: "gp",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022133,
		key: "bypass",
		commands: "g",
		cost: "",
		ability: "",
		type: "basic",
		home: "p"
	},
	{
		id: 1022308,
		key: "deceptionSpike",
		commands: "yp",
		cost: "yy",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022465,
		key: "deceptionSpike",
		commands: "yp",
		cost: "yy",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022310,
		key: "catalyst",
		commands: "r",
		cost: "r",
		ability: "interrupt",
		type: "advanced",
		home: ""
	},
	{
		id: 1022314,
		key: "catalyst",
		commands: "r",
		cost: "r",
		ability: "interrupt",
		type: "advanced",
		home: ""
	},
	{
		id: 1022461,
		key: "catalyst",
		commands: "r",
		cost: "r",
		ability: "interrupt",
		type: "advanced",
		home: ""
	},
	{
		id: 1022311,
		key: "emitEMP",
		commands: "rp",
		cost: "rr",
		ability: "paid",
		type: "advanced",
		home: ""
	},
	{
		id: 1022463,
		key: "emitEMP",
		commands: "rp",
		cost: "rr",
		ability: "paid",
		type: "advanced",
		home: ""
	},
	{
		id: 1022313,
		key: "livewireVoodoo",
		commands: "rr",
		cost: "rr",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022315,
		key: "livewireVoodoo",
		commands: "rr",
		cost: "rr",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022316,
		key: "sidekick",
		commands: "rr",
		cost: "r",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022317,
		key: "sidekick",
		commands: "rr",
		cost: "r",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022332,
		key: "dataShift",
		commands: "bb",
		cost: "b",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022349,
		key: "dataShift",
		commands: "bb",
		cost: "b",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022335,
		key: "hologate",
		commands: "bpp",
		cost: "bbb",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022336,
		key: "readRequestIntercept",
		commands: "bp",
		cost: "bb",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022339,
		key: "readRequestIntercept",
		commands: "bp",
		cost: "bb",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022337,
		key: "piedPiper",
		commands: "bb",
		cost: "bb",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022338,
		key: "piedPiper",
		commands: "bb",
		cost: "bb",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022348,
		key: "nydamShip",
		commands: "b",
		cost: "b",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022353,
		key: "nydamShip",
		commands: "b",
		cost: "b",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022357,
		key: "nydamShip",
		commands: "b",
		cost: "b",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022400,
		key: "viralSplash",
		commands: "ry",
		cost: "ry",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022401,
		key: "viralSplash",
		commands: "ry",
		cost: "ry",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022402,
		key: "neuralSplash",
		commands: "gb",
		cost: "gb",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022403,
		key: "neuralSplash",
		commands: "gb",
		cost: "gb",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022404,
		key: "pingNexus",
		commands: "p",
		cost: "ry",
		ability: "both",
		type: "advanced",
		home: ""
	},
	{
		id: 1022406,
		key: "pingNexus",
		commands: "p",
		cost: "ry",
		ability: "both",
		type: "advanced",
		home: ""
	},
	{
		id: 1022405,
		key: "exoticSoftware",
		commands: "ppp",
		cost: "rgyb",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022407,
		key: "copycat",
		commands: "ppp",
		cost: "rgyb",
		ability: "reveal",
		type: "advanced",
		home: ""
	},
	{
		id: 1022408,
		key: "consoleCowboy",
		commands: "pppp",
		cost: "ppp",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022409,
		key: "microbionix",
		commands: "ppp",
		cost: "rgyb",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022411,
		key: "nootropicBloom",
		commands: "p",
		cost: "gb",
		ability: "both",
		type: "advanced",
		home: ""
	},
	{
		id: 1022413,
		key: "nootropicBloom",
		commands: "p",
		cost: "gb",
		ability: "both",
		type: "advanced",
		home: ""
	},
	{
		id: 1022412,
		key: "dniReboot",
		commands: "pp",
		cost: "p",
		ability: "reveal",
		type: "advanced",
		home: ""
	},
	{
		id: 1022417,
		key: "digitalTattoo",
		commands: "g",
		cost: "g",
		ability: "paid",
		type: "advanced",
		home: ""
	},
	{
		id: 1022419,
		key: "digitalTattoo",
		commands: "g",
		cost: "g",
		ability: "paid",
		type: "advanced",
		home: ""
	},
	{
		id: 1022423,
		key: "digitalTattoo",
		commands: "g",
		cost: "g",
		ability: "paid",
		type: "advanced",
		home: ""
	},
	{
		id: 1022418,
		key: "adrenalinSurge",
		commands: "gg",
		cost: "g",
		ability: "paid",
		type: "advanced",
		home: ""
	},
	{
		id: 1022424,
		key: "adrenalinSurge",
		commands: "gg",
		cost: "g",
		ability: "paid",
		type: "advanced",
		home: ""
	},
	{
		id: 1022420,
		key: "rootAccess",
		commands: "ppp",
		cost: "rgyb",
		ability: "reveal",
		type: "advanced",
		home: ""
	},
	{
		id: 1022421,
		key: "magneticPulse",
		commands: "gpp",
		cost: "ggg",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022422,
		key: "gingerCool",
		commands: "gp",
		cost: "gg",
		ability: "interrupt",
		type: "advanced",
		home: ""
	},
	{
		id: 1022449,
		key: "gingerCool",
		commands: "gp",
		cost: "gg",
		ability: "interrupt",
		type: "advanced",
		home: ""
	},
	{
		id: 1022425,
		key: "psionicScatter",
		commands: "gg",
		cost: "gg",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022426,
		key: "psionicScatter",
		commands: "gg",
		cost: "gg",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022451,
		key: "duality",
		commands: "y",
		cost: "y",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022454,
		key: "duality",
		commands: "y",
		cost: "y",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022455,
		key: "duality",
		commands: "y",
		cost: "y",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022452,
		key: "replicantJar",
		commands: "ypp",
		cost: "yyy",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022460,
		key: "decoyDuck",
		commands: "yy",
		cost: "y",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022464,
		key: "decoyDuck",
		commands: "yy",
		cost: "y",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022462,
		key: "resetSpark",
		commands: "rpp",
		cost: "rrr",
		ability: "execute",
		type: "advanced",
		home: ""
	},
	{
		id: 1022467,
		key: "carbonClone",
		commands: "yy",
		cost: "yy",
		ability: "interrupt",
		type: "advanced",
		home: ""
	},
	{
		id: 1022468,
		key: "carbonClone",
		commands: "yy",
		cost: "yy",
		ability: "interrupt",
		type: "advanced",
		home: ""
	}
], S = Object.fromEntries(pe.map((e) => [e.id, e])), me = [
	{
		id: 3022,
		key: "knowledgeIsThePriceOfFreedom",
		level: 0,
		arrows: [
			["b", "-"],
			["g", "+"],
			["r", "+"],
			["p", "-"]
		]
	},
	{
		id: 3023,
		key: "hotWire",
		level: 0,
		arrows: [
			["b", "-"],
			["g", "+"],
			["y", "-"],
			["r", "+"]
		]
	},
	{
		id: 3024,
		key: "keycode",
		level: 0,
		arrows: [
			["p", "-"],
			["r", "+"],
			["b", "-"],
			["y", "+"]
		]
	},
	{
		id: 3029,
		key: "404NotFound",
		level: 0,
		arrows: [
			["g", "+"],
			["g", "+"],
			["b", "+"],
			["b", "+"]
		]
	},
	{
		id: 3025,
		key: "clockworkPlague",
		level: 0,
		arrows: [
			["g", "+"],
			["p", "-"],
			["y", "+"],
			["b", "-"]
		]
	},
	{
		id: 3026,
		key: "doubleSwitch",
		level: 0,
		arrows: [
			["g", "+"],
			["r", "-"],
			["y", "-"],
			["b", "+"]
		]
	},
	{
		id: 3027,
		key: "garbageDetail",
		level: 0,
		arrows: [
			["r", "+"],
			["r", "+"],
			["y", "+"],
			["y", "+"]
		]
	},
	{
		id: 3028,
		key: "accessDenied",
		level: 0,
		arrows: [
			["b", "+"],
			["g", "+"],
			["y", "+"],
			["r", "+"]
		]
	},
	{
		id: 3030,
		key: "alertToOurPresence",
		level: 0,
		arrows: [
			["g", "-"],
			["y", "+"],
			["p", "-"],
			["b", "+"]
		]
	},
	{
		id: 3031,
		key: "romanCandle",
		level: 0,
		arrows: [
			["b", "-"],
			["g", "-"],
			["y", "-"],
			["r", "-"]
		]
	},
	{
		id: 3032,
		key: "misdirection",
		level: 0,
		arrows: [
			["y", "+"],
			["r", "-"],
			["g", "+"],
			["p", "-"]
		]
	},
	{
		id: 3033,
		key: "shatteredGlass",
		level: 0,
		arrows: [
			["y", "+"],
			["p", "-"],
			["b", "+"],
			["r", "-"]
		]
	},
	{
		id: 3110,
		key: "nullVoid",
		level: 1,
		arrows: [
			["g", "+"],
			["b", "+"],
			["p", "-"],
			["p", "-"]
		]
	},
	{
		id: 3111,
		key: "neuralMatrix",
		level: 1,
		arrows: [
			["y", "-"],
			["b", "+"],
			["r", "+"],
			["g", "-"]
		]
	},
	{
		id: 3112,
		key: "fireworks",
		level: 1,
		arrows: [
			["r", "-"],
			["p", "+"],
			["b", "+"],
			["y", "-"]
		]
	},
	{
		id: 3113,
		key: "jacobSLadder",
		level: 1,
		arrows: []
	},
	{
		id: 3114,
		key: "hackerSPalace",
		level: 1,
		arrows: [
			["p", "+"],
			["g", "-"],
			["y", "+"],
			["r", "-"]
		]
	},
	{
		id: 3115,
		key: "scrambler",
		level: 1,
		arrows: [
			["p", "+"],
			["p", "+"],
			["b", "-"],
			["g", "-"]
		]
	},
	{
		id: 3116,
		key: "viralOverload",
		level: 1,
		arrows: [
			["p", "+"],
			["y", "-"],
			["r", "-"],
			["g", "+"]
		]
	},
	{
		id: 3117,
		key: "swarm",
		level: 1,
		arrows: [
			["b", "+"],
			["g", "-"],
			["p", "+"],
			["y", "-"]
		]
	},
	{
		id: 3118,
		key: "dreamsInVermilion",
		level: 1,
		arrows: [
			["r", "-"],
			["y", "-"],
			["r", "-"],
			["p", "+"]
		]
	},
	{
		id: 3119,
		key: "accessShutdown",
		level: 1,
		arrows: [
			["p", "-"],
			["b", "+"],
			["y", "-"],
			["g", "+"]
		]
	},
	{
		id: 3120,
		key: "reductOrReboot",
		level: 1,
		arrows: [
			["b", "+"],
			["g", "+"],
			["y", "+"],
			["r", "+"]
		]
	},
	{
		id: 3121,
		key: "dataOverload",
		level: 1,
		arrows: [
			["g", "+"],
			["y", "+"],
			["r", "+"],
			["b", "+"]
		]
	},
	{
		id: 2900,
		key: "messageQueue",
		level: 2,
		arrows: []
	},
	{
		id: 2901,
		key: "simsmudge",
		level: 2,
		arrows: []
	},
	{
		id: 2902,
		key: "romanRoad",
		level: 2,
		arrows: []
	},
	{
		id: 2903,
		key: "blackout",
		level: 2,
		arrows: []
	},
	{
		id: 2904,
		key: "distributedDefense",
		level: 2,
		arrows: []
	},
	{
		id: 2905,
		key: "waterfall",
		level: 2,
		arrows: []
	},
	{
		id: 2906,
		key: "mirrorMap",
		level: 2,
		arrows: []
	},
	{
		id: 2907,
		key: "neutrinoScanner",
		level: 2,
		arrows: []
	},
	{
		id: 2908,
		key: "insertMisinformation",
		level: 2,
		arrows: []
	},
	{
		id: 2909,
		key: "hackman",
		level: 2,
		arrows: []
	},
	{
		id: 2934,
		key: "flashFlood",
		level: 2,
		arrows: []
	},
	{
		id: 2935,
		key: "dniWeb",
		level: 2,
		arrows: []
	},
	{
		id: 2836,
		key: "tsunami",
		level: 2,
		arrows: []
	},
	{
		id: 2837,
		key: "shellshock",
		level: 2,
		arrows: []
	},
	{
		id: 2838,
		key: "tempest",
		level: 2,
		arrows: []
	},
	{
		id: 2839,
		key: "titanium",
		level: 2,
		arrows: []
	}
], he = Object.fromEntries(me.map((e) => [e.id, e])), ge = [
	"hettie",
	"tokyo",
	"monty",
	"kelly",
	"tilda",
	"twins",
	"oshin",
	"angel",
	"leiko",
	"rupert"
], _e = {
	hettie: "b",
	tokyo: "b",
	monty: "g",
	kelly: "g",
	tilda: "y",
	twins: "y",
	oshin: "r",
	angel: "r",
	leiko: "p",
	rupert: "p"
}, C = {
	alphaMoby: {
		cycles: [
			1,
			1,
			1
		],
		spawn: [
			0,
			1,
			1
		],
		white: [
			!1,
			!1,
			!1
		]
	},
	spider: {
		cycles: [
			1,
			1,
			1
		],
		spawn: [
			1,
			2,
			3
		],
		white: [
			!1,
			!1,
			!1
		]
	},
	glom: {
		cycles: [
			1,
			1,
			1
		],
		spawn: [
			1,
			2,
			2
		],
		white: [
			!1,
			!1,
			!0
		]
	},
	logi: {
		cycles: [
			2,
			1,
			1
		],
		spawn: [
			1,
			2,
			2
		],
		white: [
			!0,
			!0,
			!0
		]
	},
	viking: {
		cycles: [
			1,
			1,
			1
		],
		spawn: [
			1,
			2,
			2
		],
		white: [
			!1,
			!1,
			!0
		]
	},
	sentinel: {
		cycles: [
			2,
			2,
			1
		],
		spawn: [
			1,
			2,
			2
		],
		white: [
			!1,
			!1,
			!1
		]
	},
	mother: {
		cycles: [
			1,
			2,
			1
		],
		spawn: [
			1,
			2,
			2
		],
		white: [
			!1,
			!1,
			!0
		]
	}
}, w = [
	"alert",
	"alert",
	"alert",
	"alert",
	"tagTeam",
	"lighthouse",
	"interference",
	"password",
	"exploit",
	"vulnerability"
], ve = [
	[1, -1],
	[0, -1],
	[-1, 0],
	[-1, 1],
	[0, 1],
	[0, 0]
], T = {
	b: "brpygb",
	g: "gpybrg",
	y: "ybrgpy",
	r: "rygpbr",
	p: "pgbryp"
};
function E(e, t, n) {
	for (let r = 0; r < n; r++) [e, t] = [-t, e + t];
	return [e, t];
}
function D(e, t) {
	return e.flatMap((e) => ve.map(([n, r], i) => {
		let [a, o] = E(n, r, e.color === "g" ? 2 : e.color === "r" ? 3 : 0);
		return {
			id: x.indexOf(e.color) * 6 + i,
			tile: e.color,
			color: t ? T[e.color][i] : e.color,
			n: i + 1,
			q: e.q + a,
			r: e.r + o
		};
	}));
}
var ye = (e, t) => Math.max(Math.abs(e.q - t.q), Math.abs(e.r - t.r), Math.abs(e.q + e.r - t.q - t.r)) === 1, O = (e, t) => e.cells.filter((n) => ye(e.cells.find((e) => e.id === t), n)).map((e) => e.id), k = (e, t) => O(e, t).length === 6, A = (e, t, n) => e.cells.find((e) => e.color === t && e.n === n).id, j = (e, t) => e.cells.filter((e) => e.color === t).map((e) => e.id);
function be(e, t) {
	let n = D(e, !1);
	if (!n.length) return [{
		color: t,
		q: 0,
		r: 0
	}];
	let r = [], i = n.map((e) => e.q), a = n.map((e) => e.r);
	for (let e = Math.min(...i) - 2; e <= Math.max(...i) + 2; e++) for (let i = Math.min(...a) - 2; i <= Math.max(...a) + 2; i++) {
		let a = {
			color: t,
			q: e,
			r: i
		}, o = D([a], !1);
		o.some((e) => n.some((t) => t.q === e.q && t.r === e.r)) || o.filter((e) => n.some((t) => ye(e, t))).length >= 2 && r.push(a);
	}
	return r.sort((e, t) => e.q * e.q + e.r * e.r + e.q * e.r - (t.q * t.q + t.r * t.r + t.q * t.r));
}
function xe(e) {
	if (!e.length) return !0;
	let t = D(e, !1), n = /* @__PURE__ */ new Set([e[0].color]);
	for (let r = 0; r < e.length; r++) for (let e of t) if (n.has(e.tile)) for (let r of t) ye(e, r) && n.add(r.tile);
	return n.size === e.length;
}
//#endregion
//#region src/games/deckers/core.ts
var M = (e, t = e.active) => e.players.find((e) => e.rid === t), N = (e) => e.objectives[e.cycle], P = (e) => he[N(e)]?.level ?? 2, Se = (e) => e.action?.at ?? M(e).avatars[e.focus], F = (e, t, n, r) => e.pieces.filter((e) => e.at === t && (!n || e.kind === n) && (!r || e.color === r)), I = (e, t) => e.pieces.filter((e) => e.at === t && (e.kind === "spark" || e.kind === "guardian")), L = (e, t, n, r) => F(e, t, n, r).length, R = (e, t) => e.cells.find((e) => e.id === t), Ce = (e, t) => t.color === "white" || t.kind === "guardian" && N(e) === 2909, we = (e) => e.players.map((e) => e.color), z = (e, t) => A(e, t.color, 6);
function Te(e, n) {
	let r = t(e.seed, e.rngCursor, n);
	return e.rngCursor++, r;
}
function Ee(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = Te(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function De(e) {
	let t = Te(e, 6);
	return t === 5 ? R(e, Se(e)).color : x[t];
}
var Oe = (e) => A(e, De(e), Te(e, 6) + 1);
function B(e, ...t) {
	e.tasks.unshift(...t);
}
function ke(e, t, n = -1, r = 0, i = e.active) {
	e.log.push({
		key: t,
		at: n,
		n: r,
		rid: i
	});
}
function Ae(e, t) {
	e.phase = "done", e.won = !1, e.reason = t, e.tasks = [], e.prompt = null, e.action = null, e.reaction = null, ke(e, t);
}
function je(e) {
	e.phase = "done", e.won = !0, e.reason = "victory", e.tasks = [], e.prompt = null, e.action = null, e.reaction = null, ke(e, "victory");
}
function V(e, t, n, r = e.active) {
	n.length && (e.serial++, e.prompt = {
		id: e.serial,
		owner: r,
		text: t,
		options: n
	});
}
var H = (e, t, n = {}) => ({
	label: e,
	tasks: t,
	...n
}), U = (e, t, n, r = 1) => ({
	op: "placeMany",
	kind: e,
	color: t,
	at: n,
	count: r
}), Me = (e, t) => ({
	op: "enter",
	id: e,
	to: t
}), W = (e) => ({
	op: "remove",
	id: e
}), G = (e, t, n) => ({
	op: "select",
	text: e,
	options: t,
	rid: n
}), Ne = (e, t, n, r, i, a) => G(t, n.map((e) => H("space", r(e), {
	at: e,
	color: i
})), a), Pe = (e, t) => t.id !== e.ghostId || ![
	2837,
	2838,
	2839
].includes(N(e)), Fe = (e, t = "chooseOrder") => ({
	op: "ordered",
	tasks: e,
	text: t
});
function Ie(e) {
	return M(e).profile === "rupert";
}
function Le(e, t, n) {
	return F(e, "supply", t, n)[0] || e.pieces.find((e) => e.at === "supply" && e.kind === t && (t === "program" && ((n === "b" || n === "g") && (e.color === "b" || e.color === "g") || (n === "y" || n === "r") && (e.color === "y" || e.color === "r")) || t === "spark" || t === "guardian"));
}
function Re(e, t, n) {
	return L(e, t, "program", n) + (e.action && e.action.purple === n ? L(e, t, "program", "p") : 0);
}
function ze(e, t, n) {
	let r = e.action?.lighthouse;
	if (r != null) {
		let i = e.pieces.find((e) => e.id === r);
		if (i && i.color === n && e.action?.lighthouseTo === t) return !0;
	}
	return F(e, t, "installation", n).some((e) => e.id !== r);
}
function Be(e, t, n = !1) {
	if (t.at === "supply" || t.at === "removed" || !n && e.config.smc === "glom" && e.step === "smcAttack" && t.kind === "program" && t.color === "g" && t.at !== "captured") return;
	let r = t.at;
	if (t.captive !== null && (Be(e, e.pieces.find((e) => e.id === t.captive), n), t.captive = null), t.at = !n && N(e) === 3110 && (t.kind === "spark" && e.step === "action" || t.kind === "program" && e.step === "smcAttack") ? "objective" : "supply", t.id === e.hackman) {
		e.hackman = null;
		let t = e.pieces.find((e) => e.at === "ghostReserve" && e.kind === "installation");
		t && (t.at = "supply");
	}
	t.id === e.ghostId && r !== "ghostReserve" && (e.ghostId = null, B(e, { op: "ghostDefeated" }));
}
function Ve(e, t) {
	let n = F(e, t, "spark", "white").find((e) => e.captive === null), r = F(e, t, "program");
	n && r.length && V(e, "capture", r.map((e) => H("piece", [{
		op: "capture",
		id: n.id,
		value: e.id
	}, {
		op: "settle",
		at: t
	}], {
		piece: e.id,
		at: t
	})));
}
function He() {
	let e = [];
	function t(t, n, r) {
		for (let i = 0; i < r; i++) e.push({
			id: e.length,
			kind: t,
			color: n,
			at: "supply",
			captive: null
		});
	}
	t("program", "b", 15), t("program", "y", 15), t("program", "p", 7), t("spark", "black", 25);
	for (let e of x.slice(0, 4)) t("installation", e, 5);
	return t("guardian", "black", 5), e;
}
function Ue(e, t, n) {
	t.hand = t.hand.filter((e) => !n.includes(e)), t.discard.push(...n), n.length && (e.activity = {
		kind: "discard",
		at: -1,
		to: -1,
		piece: null,
		color: t.color,
		n: n.length,
		cards: n,
		owner: t.rid,
		source: "hand:" + t.rid,
		target: "discard:" + t.rid
	});
}
var We = (e, t) => typeof t.at == "number" ? "slot:" + t.at + ":" + F(e, t.at).findIndex((e) => e.id === t.id) : [
	"objective",
	"trojan",
	"palace",
	"ghostReserve"
].includes(String(t.at)) ? String(t.at) : "supply";
function Ge(e, t, n = 0) {
	let r = t.avatars[n], i = R(e, r);
	return t.profile === "monty" && (L(e, r, "program", "g") || ze(e, r, "g")) ? e.cells.filter((t) => L(e, t.id, "installation") || j(e, t.color).some((t) => ze(e, t, "g"))).map((e) => e.id) : ze(e, r, "g") ? j(e, i.color) : [];
}
function Ke(e, t, n, r = null) {
	e.reaction = {
		kind: t,
		passed: [],
		resume: n,
		target: r
	};
}
function qe(e, t) {
	let n = t.at ?? -1;
	switch (t.op) {
		case "select":
			V(e, t.text, t.options, t.rid);
			break;
		case "ordered": {
			let n = t.tasks ?? [];
			n.length === 1 ? B(e, n[0]) : n.length > 1 && V(e, t.text ?? "chooseOrder", n.map((e, r) => H(e.text ?? e.op, [e, {
				...t,
				tasks: n.filter((e, t) => r !== t)
			}], {
				at: e.at,
				color: e.color,
				piece: e.id,
				n: e.count
			})));
			break;
		}
		case "remove": {
			let n = e.pieces.find((e) => e.id === t.id);
			if (!n || n.id === e.ghostId && [
				2837,
				2838,
				2839
			].includes(N(e)) && t.text !== "ghostAllowed" || ["supply", "removed"].includes(String(n.at))) break;
			if (n.captive !== null) {
				let r = n.captive;
				n.captive = null, B(e, {
					op: "remove",
					id: r,
					flag: t.flag
				}, t);
				break;
			}
			let r = We(e, n), i = n.at;
			Be(e, n, t.flag), n.at !== i && (e.activity = {
				kind: "remove",
				at: typeof i == "number" ? i : -1,
				to: -1,
				piece: n.id,
				color: n.color,
				n: 1,
				pieceKind: n.kind,
				source: r,
				target: n.at === "objective" ? "objective" : "supply"
			});
			break;
		}
		case "placeMany": {
			let r = t.count ?? 1;
			r > 0 && B(e, {
				op: "enter",
				kind: t.kind,
				color: t.color,
				to: n
			}, ...r > 1 ? [{
				...t,
				count: r - 1
			}] : []);
			break;
		}
		case "enter": {
			if (t.kind === "spark" && !t.checked && e.players.some((t) => t.packets.some((t) => e.packets[t].type === "interference")) && P(e) > 0) {
				Ke(e, "placement", [{
					...t,
					checked: !0
				}]);
				break;
			}
			let n = t.id === void 0 ? Le(e, t.kind, t.color) : e.pieces.find((e) => e.id === t.id);
			if (!n) {
				(t.kind === "spark" || t.kind === "guardian") && Ae(e, t.kind === "spark" ? "sparkSupply" : "guardianSupply");
				break;
			}
			let r = t.to, i = n.at, a = We(e, n), o = r, s = n.kind === "spark";
			if (s && N(e) === 3029 && [
				"action",
				"start",
				"spawn",
				"end"
			].includes(e.step) && R(e, o).n === 6 && (o = A(e, R(e, o).color, 4)), s && e.step === "spawn" && e.config.smc === "viking" && !I(e, o).length) {
				let n = O(e, o).filter((t) => L(e, t, "spark")), r = Math.max(...n.map((t) => R(e, t).n)), i = n.filter((t) => R(e, t).n === r);
				if (i.length && !t.flag) {
					B(e, Fe(i.map((e) => ({
						...t,
						to: e,
						flag: !0
					}))));
					break;
				}
			}
			if (s && !t.text) {
				let n = e.players.find((e) => e.profile === "angel" && e.avatars.includes(o));
				if (n) {
					V(e, "angelRedirect", [H("acceptSpark", [{
						...t,
						to: o,
						text: "accepted"
					}], { at: o }), ...O(e, o).map((e) => H("redirectSpark", [{
						...t,
						to: e,
						text: "redirected"
					}], { at: e }))], n.rid);
					break;
				}
			}
			if (n.kind === "program" && n.color === "p" && i === "supply" && !Ie(e)) break;
			if (t.color && (n.color = t.color), n.at = o, e.activity = {
				kind: i === "supply" ? "place" : "move",
				at: typeof i == "number" ? i : -1,
				to: o,
				piece: n.id,
				color: n.color,
				n: 1,
				pieceKind: n.kind,
				source: a,
				target: "piece:" + n.id
			}, n.kind === "program" && L(e, o, "program", n.color) > (n.color === "p" ? 1 : 3)) {
				Be(e, n, !0);
				break;
			}
			if (n.kind === "installation" && L(e, o, "installation") > 1) {
				Be(e, n, !0);
				break;
			}
			if (n.kind === "guardian") B(e, ...F(e, o).filter((e) => e !== n).map((e) => e.id).map(W), {
				op: "settle",
				at: o
			});
			else if (s) {
				if (L(e, o, "guardian")) {
					let t = n.color;
					Be(e, n);
					let r = O(e, o).filter((t) => e.step !== "spawn" || e.config.smc !== "viking" || R(e, t).n % 2 == 1);
					e.activity = {
						kind: "explode",
						at: o,
						to: o,
						piece: null,
						color: t,
						n: r.length
					}, ke(e, "explosion", o), B(e, Fe(r.map((e) => U("spark", t, e)), "explosionOrder"));
				} else L(e, o, "spark") >= 3 ? (B(e, {
					op: "enter",
					kind: "guardian",
					color: L(e, o, "spark", "white") ? "white" : "black",
					to: o
				}), ke(e, "transformation", o)) : B(e, {
					op: "settle",
					at: o
				});
			} else B(e, {
				op: "settle",
				at: o
			});
			break;
		}
		case "settle": {
			let r = F(e, n, "guardian")[0];
			if (r && Ce(e, r)) {
				let r = e.players.find((e) => e.avatars.includes(n));
				if (r) {
					B(e, {
						op: "avatar",
						rid: r.rid,
						id: r.avatars.indexOf(n),
						to: Oe(e)
					}, { ...t });
					break;
				}
			}
			if (N(e) === 2836 && e.ghostId !== null && typeof e.pieces[e.ghostId].at == "number" && O(e, e.pieces[e.ghostId].at).includes(n)) {
				let r = e.players.find((e) => e.avatars.includes(n));
				if (r) {
					B(e, {
						op: "avatar",
						rid: r.rid,
						id: r.avatars.indexOf(n),
						to: Oe(e)
					}, { ...t });
					break;
				}
			}
			if (e.palaceAt === n) {
				if (r) {
					e.palaceAt = null, B(e, ...F(e, "palace").map((e) => ({
						op: "transfer",
						id: e.id,
						text: "supply",
						at: n
					})));
					break;
				}
				let i = F(e, n, "spark")[0];
				if (i) {
					B(e, W(i.id), { op: "palaceAbsorb" }, t);
					break;
				}
			}
			Ve(e, n);
			break;
		}
		case "capture": {
			let n = e.pieces.find((e) => e.id === t.id), r = e.pieces.find((e) => e.id === t.value), i = We(e, r);
			n.captive = r.id, r.at = "captured", e.activity = {
				kind: "capture",
				at: typeof n.at == "number" ? n.at : -1,
				to: -1,
				piece: r.id,
				color: r.color,
				n: 1,
				pieceKind: r.kind,
				source: i,
				target: "piece:" + n.id
			}, ke(e, "captured", typeof n.at == "number" ? n.at : -1);
			break;
		}
		case "palaceAbsorb": {
			let t = Le(e, "installation", "r");
			t ? (t.color = "r", B(e, {
				op: "transfer",
				id: t.id,
				text: "palace"
			})) : (e.palaceAt = null, B(e, ...F(e, "palace").map((e) => ({
				op: "transfer",
				id: e.id,
				text: "supply"
			}))));
			break;
		}
		case "avatar": {
			let n = M(e, t.rid), r = n.avatars[t.id ?? 0];
			n.avatars[t.id ?? 0] = t.to, e.activity = {
				kind: "avatar",
				at: r,
				to: t.to,
				piece: null,
				color: n.color,
				n: 1,
				owner: n.rid,
				profile: n.profile,
				source: "avatarSlot:" + n.rid + ":" + (t.id ?? 0) + ":" + r,
				target: "avatar:" + n.rid + ":" + (t.id ?? 0)
			}, B(e, {
				op: "settle",
				at: t.to
			});
			break;
		}
		case "flip": {
			let n = e.pieces.find((e) => e.id === t.id);
			if (n.color = {
				b: "g",
				g: "b",
				y: "r",
				r: "y",
				black: "white",
				white: "black",
				p: "p"
			}[n.color], n.captive !== null && n.color === "black") {
				let t = n.captive;
				n.captive = null, B(e, typeof n.at == "number" ? {
					op: "enter",
					id: t,
					to: n.at
				} : {
					op: "remove",
					id: t
				});
			}
			e.activity = {
				kind: "flip",
				at: typeof n.at == "number" ? n.at : -1,
				to: typeof n.at == "number" ? n.at : -1,
				piece: n.id,
				color: n.color,
				n: 1,
				pieceKind: n.kind,
				target: typeof n.at == "number" ? "piece:" + n.id : We(e, n)
			}, typeof n.at == "number" && B(e, {
				op: "settle",
				at: n.at
			});
			break;
		}
		case "choosePlace": {
			if (t.count !== void 0 && t.count <= 0) break;
			let n = t.cells ?? e.cells.map((e) => e.id), r = t.color ? [t.color] : x.filter((t) => t !== "p" || Ie(e));
			if ((t.kind === "spark" || t.kind === "guardian") && !r.some((n) => Le(e, t.kind, n))) {
				Ae(e, t.kind === "spark" ? "sparkSupply" : "guardianSupply");
				break;
			}
			V(e, t.text ?? "placePiece", r.filter((n) => Le(e, t.kind, n)).flatMap((e) => n.map((n) => H("placePiece", [U(t.kind, e, n), ...t.count && t.count > 1 ? [{
				...t,
				count: t.count - 1
			}] : []], {
				at: n,
				color: e
			}))));
			break;
		}
		case "chooseRelocate": {
			let n = (t.ids ?? e.pieces.filter((e) => typeof e.at == "number" && (!t.kind || e.kind === t.kind) && (!t.color || e.color === t.color)).map((e) => e.id)).filter((t) => e.pieces[t].at !== "supply" && e.pieces[t].at !== "removed");
			V(e, t.text ?? "choosePiece", n.map((n) => H("piece", [Ne(e, "destination", t.cells ?? e.cells.map((e) => e.id), (e) => [Me(n, e), ...t.count && t.count > 1 ? [{
				...t,
				count: t.count - 1
			}] : []])], {
				piece: n,
				at: typeof e.pieces[n].at == "number" ? e.pieces[n].at : void 0
			})));
			break;
		}
		case "chooseRemove": {
			let n = (t.ids ?? e.pieces.filter((e) => typeof e.at == "number" && (!t.kind || e.kind === t.kind) && (!t.color || e.color === t.color)).map((e) => e.id)).filter((t) => e.pieces[t].at !== "supply" && e.pieces[t].at !== "removed" && Pe(e, e.pieces[t]));
			V(e, t.text ?? "chooseRemove", n.map((n) => H("piece", [W(n), ...t.count && t.count > 1 ? [{
				...t,
				count: t.count - 1
			}] : []], {
				piece: n,
				at: typeof e.pieces[n].at == "number" ? e.pieces[n].at : void 0
			})));
			break;
		}
		case "store":
		case "transfer": {
			let n = e.pieces[t.id], r = t.at === void 0 ? We(e, n) : "cell:" + t.at;
			n.at = t.text ?? "objective", e.activity = {
				kind: "store",
				at: -1,
				to: -1,
				piece: n.id,
				color: n.color,
				n: 1,
				pieceKind: n.kind,
				source: r,
				target: We(e, n)
			};
			break;
		}
		case "setStep":
			e.step = t.text;
			break;
		case "setPhase":
			e.phase = t.text;
			break;
		case "note":
			ke(e, t.text, n, t.count);
			break;
		case "win":
			je(e);
			break;
		case "lose":
			Ae(e, t.text);
			break;
		case "discard":
			Ue(e, M(e, t.rid), t.ids ?? []);
			break;
		case "draw": {
			let n = M(e, t.rid), r = n.deck.splice(0, t.count ?? 1);
			n.hand.push(...r), r.length && (e.activity = {
				kind: "draw",
				at: -1,
				to: -1,
				piece: null,
				color: n.color,
				n: r.length,
				cards: r,
				owner: n.rid,
				source: "deck:" + n.rid,
				target: "hand:" + n.rid,
				private: !0
			});
			break;
		}
		case "profile": {
			let n = M(e, t.rid);
			n.profile = t.text, n.color = _e[t.text], n.starting = n.profile === "rupert" ? "p" : n.color, n.avatars = Array.from({ length: n.profile === "twins" ? 2 : 1 }, () => z(e, n));
			break;
		}
		case "reveal":
			M(e).revealed.push(t.id);
			break;
		case "restock":
			if (e.market.length < e.marketSize && e.upgradeDeck.length) {
				let t = e.upgradeDeck.shift();
				e.market.push(t), e.activity = {
					kind: "acquire",
					at: -1,
					to: -1,
					piece: null,
					color: "p",
					n: 1,
					cards: [t],
					source: "upgradeDeck",
					target: "card:" + t
				}, B(e, { op: "restock" });
			}
			break;
		case "setFocus":
			e.focus = t.value;
			break;
		case "resumeReaction":
			e.reaction = t.reaction;
			break;
		case "reaction":
			Ke(e, t.text, t.tasks ?? [], t.id ?? null);
			break;
		case "returnCards": {
			let n = M(e);
			n.deck.push(...t.ids), n.hand = n.hand.filter((e) => !t.ids.includes(e)), e.activity = {
				kind: "returnCards",
				at: -1,
				to: -1,
				piece: null,
				color: n.color,
				n: t.ids.length,
				cards: t.ids,
				owner: n.rid,
				source: "hand:" + n.rid,
				target: "deck:" + n.rid,
				private: !0
			};
			break;
		}
		case "rebootMarket": {
			let n = t.ids ?? [...e.market];
			e.upgradeDeck.push(...n), e.market = e.market.filter((e) => !n.includes(e)), e.activity = {
				kind: "returnCards",
				at: -1,
				to: -1,
				piece: null,
				color: "p",
				n: n.length,
				cards: n,
				source: "market",
				target: "upgradeDeck"
			}, B(e, { op: "restock" });
			break;
		}
		case "root":
			e.root[e.active] = t.text ?? "";
			break;
		default: return !1;
	}
	return !0;
}
//#endregion
//#region src/games/deckers/payment.ts
function Je(e, t = "", n = [], r = !1, i = {}) {
	return e.map((e) => (S[e].commands + (r && S[e].key === "digitalTattoo" ? "p" : "") + (i[e] ?? "")).repeat(n.includes(e) ? 2 : 1)).join("") + t;
}
function Ye(e, t) {
	let n = Object.fromEntries(x.map((t) => [t, [...e].filter((e) => e === t).length])), r = Object.fromEntries(x.map((e) => [e, [...t].filter((t) => t === e).length])), i = r.p;
	for (let e of x) if (e !== "p") {
		let t = Math.min(n[e], r[e]);
		n[e] -= t, i += r[e] - t;
	}
	let a = Math.min(n.p, i);
	return n.p -= a, i -= a, i === 0 || x.reduce((e, t) => e + n[t], 0) >= i * 3;
}
//#endregion
//#region src/games/deckers/effects.ts
var K = (e, t) => e.pieces.filter((e) => typeof e.at == "number" && (!t || e.kind === t)), Xe = (e, t, n, r, i = !1) => V(e, t, [...i ? [H("finish", [])] : [], ...n.map((t) => H("piece", r(t), {
	piece: t,
	at: typeof e.pieces[t].at == "number" ? e.pieces[t].at : void 0
}))]), Ze = (e, t = e.length) => ({
	op: "flipList",
	ids: e,
	count: t
}), Qe = (e, t, n = e.length, r = !1) => ({
	op: "relocateList",
	ids: e,
	cells: t,
	count: n,
	flag: r
});
function $e(e, t) {
	let n = S[t]?.key, r = Se(e), i = j(e, R(e, r).color), a = (t, n = e.cells.map((e) => e.id)) => K(e, t).some((e) => n.includes(e.at));
	switch (n) {
		case "deceptionSpike": return a("spark", [r]);
		case "sidekick": return a("spark", [r, ...O(e, r)]);
		case "piedPiper": return a("program");
		case "nydamShip": return !k(e, r) && e.cells.some((t) => t.id !== r && !k(e, t.id) && !F(e, t.id, "guardian").some((t) => Ce(e, t)));
		case "pingNexus": return a("installation");
		case "nootropicBloom": return K(e, "program").some((e) => e.color !== "p");
		case "exoticSoftware": return L(e, r, "program") >= 2 && !L(e, r, "installation");
		case "copycat": return M(e).hand.some((n) => n !== t && ["execute", "both"].includes(S[n].ability) && $e(e, n));
		case "consoleCowboy":
		case "resetSpark": return F(e, r).some((t) => ["spark", "guardian"].includes(t.kind) && Pe(e, t));
		case "rootAccess": return M(e).deck.length > 0;
		case "magneticPulse": return a("installation") || a("guardian");
		case "duality": return F(e, r, "program").some((e) => e.color !== "p");
		case "decoyDuck": return a("program", i) && a("spark", i);
		default: return !0;
	}
}
function et(e, t) {
	let n = Se(e), r = M(e), i = e.action;
	switch (t.op) {
		case "cardEffect": {
			let a = S[t.id].key, o = j(e, R(e, n).color);
			switch (a) {
				case "deceptionSpike":
					Xe(e, "chooseSpark", F(e, n, "spark").map((e) => e.id), (e) => [W(e), G("optionalProgram", [H("skip", []), H("placePiece", [U("program", "y", n)], {
						at: n,
						color: "y"
					})])]);
					break;
				case "livewireVoodoo":
					B(e, Ze(K(e, "spark").filter((e) => o.includes(e.at)).map((e) => e.id), 3));
					break;
				case "sidekick":
					Xe(e, "chooseSpark", K(e, "spark").filter((t) => [n, ...O(e, n)].includes(t.at)).map((e) => e.id), (e) => [W(e)]);
					break;
				case "dataShift":
					B(e, Qe(K(e, "program").filter((t) => O(e, n).includes(t.at)).map((e) => e.id), [n], 3));
					break;
				case "hologate":
					B(e, {
						op: "hologatePick",
						ids: F(e, n).filter((e) => ["program", "spark"].includes(e.kind)).map((e) => e.id),
						data: []
					});
					break;
				case "readRequestIntercept":
					B(e, {
						op: "interceptPick",
						id: t.id,
						ids: [],
						count: 2
					});
					break;
				case "piedPiper":
					Xe(e, "chooseProgram", K(e, "program").map((e) => e.id), (e) => [{
						op: "enter",
						id: e,
						to: n
					}]);
					break;
				case "nydamShip":
					k(e, n) || (i.kind = "nydamShip", e.phase = "action");
					break;
				case "viralSplash":
				case "neuralSplash":
					B(e, U("spark", "black", n, 2), {
						op: "splash",
						color: a === "viralSplash" ? "r" : "g",
						cells: e.cells.filter((t) => !k(e, t.id)).map((e) => e.id),
						count: 3
					});
					break;
				case "pingNexus":
					Xe(e, "chooseInstallation", K(e, "installation").map((e) => e.id), (t) => [W(t), {
						op: "splash",
						color: e.pieces[t].color,
						cells: [e.pieces[t].at],
						count: 3,
						flag: !0
					}]);
					break;
				case "nootropicBloom":
					Xe(e, "chooseProgram", K(e, "program").filter((e) => e.color !== "p").map((e) => e.id), (e) => [{
						op: "flip",
						id: e
					}]);
					break;
				case "exoticSoftware":
					B(e, {
						op: "exoticRemove",
						count: 2
					});
					break;
				case "copycat":
					V(e, "copyCard", r.hand.filter((n) => n !== t.id && ["execute", "both"].includes(S[n].ability) && $e(e, n)).map((e) => H("card", [{
						op: "showCard",
						id: e
					}, {
						op: "cardEffect",
						id: e
					}], { card: e })));
					break;
				case "consoleCowboy":
					V(e, "chooseSMC", [...L(e, n, "spark") ? [H("removeSparks", F(e, n, "spark").map((e) => W(e.id)), { at: n })] : [], ...F(e, n, "guardian").filter((t) => Pe(e, t)).map((e) => H("piece", [W(e.id)], {
						at: n,
						piece: e.id
					}))]);
					break;
				case "microbionix":
					B(e, Qe(K(e, "spark").filter((e) => o.includes(e.at)).map((e) => e.id), e.cells.filter((t) => !L(e, t.id, "guardian")).map((e) => e.id)));
					break;
				case "dniReboot":
					B(e, {
						op: "dniPick",
						ids: []
					});
					break;
				case "rootAccess": {
					let t = r.deck[r.deck.length - 1];
					t !== void 0 && V(e, "rootPosition", [H("top", [{
						op: "rootChoice",
						id: t,
						flag: !0
					}], { card: t }), H("bottom", [{
						op: "rootChoice",
						id: t
					}], { card: t })]);
					break;
				}
				case "magneticPulse":
					Xe(e, "choosePiece", K(e).filter((e) => ["installation", "guardian"].includes(e.kind)).map((e) => e.id), (e) => [{
						op: "enter",
						id: e,
						to: n
					}]);
					break;
				case "psionicScatter":
					B(e, Qe(K(e, "program").filter((e) => e.color === "g").map((e) => e.id), [], void 0, !0));
					break;
				case "duality":
					Xe(e, "chooseProgram", F(e, n, "program").filter((e) => e.color !== "p").map((e) => e.id), (e) => [{
						op: "flip",
						id: e
					}]);
					break;
				case "replicantJar":
					B(e, Ze(K(e, "program").filter((e) => e.color !== "p" && o.includes(e.at)).map((e) => e.id)));
					break;
				case "decoyDuck": {
					let t = K(e, "program").filter((e) => o.includes(e.at)), n = K(e, "spark").filter((e) => o.includes(e.at));
					Xe(e, "chooseProgram", t.map((e) => e.id), (e) => [G("chooseSpark", n.map((t) => H("piece", [{
						op: "swapPieces",
						id: e,
						value: t.id
					}], {
						piece: t.id,
						at: t.at
					})))]);
					break;
				}
				case "resetSpark": V(e, "resetSpark", [...L(e, n, "spark") ? [H("removeSparks", F(e, n, "spark").map((e) => W(e.id)), { at: n })] : [], ...F(e, n, "guardian").filter((t) => Pe(e, t)).map((e) => H("piece", [W(e.id), U("spark", e.color, n)], {
					at: n,
					piece: e.id
				}))]);
			}
			break;
		}
		case "showCard":
			e.activity = {
				kind: "revealCard",
				at: -1,
				to: -1,
				piece: null,
				color: r.color,
				n: 1,
				cards: [t.id],
				owner: r.rid,
				source: "card:" + t.id,
				target: "cell:" + n
			};
			break;
		case "flipList": {
			let n = t.ids ?? [], r = t.count ?? n.length;
			r > 0 && Xe(e, "flipPiece", n.filter((t) => typeof e.pieces[t].at == "number"), (e) => [{
				op: "flip",
				id: e
			}, {
				...t,
				ids: n.filter((t) => t !== e),
				count: r - 1
			}], !0);
			break;
		}
		case "relocateList": {
			let n = (t.ids ?? []).filter((t) => typeof e.pieces[t].at == "number"), r = t.count ?? n.length;
			r > 0 && Xe(e, "choosePiece", n, (i) => [Ne(e, "destination", t.flag ? O(e, e.pieces[i].at) : t.cells ?? e.cells.map((e) => e.id), (e) => [{
				op: "enter",
				id: i,
				to: e
			}, {
				...t,
				ids: n.filter((e) => e !== i),
				count: r - 1
			}])], !0);
			break;
		}
		case "splash": {
			if (!t.count) break;
			let n = t.cells.filter((t) => !L(e, t, "guardian"));
			V(e, "placePiece", [H("finish", []), ...n.map((e) => H("placePiece", [U("program", t.color, e), {
				...t,
				cells: t.flag ? t.cells : n.filter((t) => t !== e),
				count: t.count - 1
			}], {
				at: e,
				color: t.color
			}))]);
			break;
		}
		case "exoticRemove":
			t.count ? Xe(e, "chooseProgram", F(e, n, "program").map((e) => e.id), (e) => [W(e), {
				...t,
				count: t.count - 1
			}]) : B(e, {
				op: "choosePlace",
				kind: "installation",
				cells: [n]
			});
			break;
		case "hologatePick": {
			let r = t.ids, i = t.data;
			V(e, "hologatePieces", [H("finish", [Ne(e, "destination", e.cells.filter((t) => t.id !== n && !F(e, t.id, "guardian").some((t) => Ce(e, t))).map((e) => e.id), (e) => [{
				op: "hologateMove",
				to: e,
				ids: i
			}])]), ...r.map((e) => H("piece", [{
				...t,
				ids: r.filter((t) => t !== e),
				data: [...i, e]
			}], {
				piece: e,
				at: n
			}))]);
			break;
		}
		case "hologateMove": {
			let n = r.avatars[i.avatar], a = t.to;
			r.avatars[i.avatar] = a, i.ghost === null && (i.at = a), e.activity = {
				kind: "avatar",
				at: n,
				to: a,
				piece: null,
				color: r.color,
				n: 1,
				owner: r.rid,
				profile: r.profile,
				source: "avatarSlot:" + r.rid + ":" + i.avatar + ":" + n,
				target: "avatar:" + r.rid + ":" + i.avatar
			}, B(e, ...t.ids.map((e) => ({
				op: "enter",
				id: e,
				to: a
			})), {
				op: "settle",
				at: a
			});
			break;
		}
		case "interceptPick": {
			let n = t.ids, i = r.hand.filter((e) => !n.includes(e));
			V(e, "interceptCards", [H("finish", [{
				op: "interceptFinish",
				ids: [t.id, ...n]
			}]), ...t.count ? i.map((e) => H("card", [{
				...t,
				ids: [...n, e],
				count: t.count - 1
			}], { card: e })) : []]);
			break;
		}
		case "interceptFinish": {
			let n = t.ids;
			r.discard = r.discard.filter((e) => !n.includes(e)), r.hand = r.hand.filter((e) => !n.includes(e)), r.deck.push(...n), e.activity = {
				kind: "returnCards",
				at: -1,
				to: -1,
				piece: null,
				color: r.color,
				n: n.length,
				cards: n,
				owner: r.rid,
				source: "hand:" + r.rid,
				target: "deck:" + r.rid,
				private: !0
			}, B(e, {
				op: "draw",
				rid: r.rid,
				count: n.length
			});
			break;
		}
		case "dniPick": {
			let n = t.ids;
			V(e, "rebootCards", [H("finish", [{
				op: "rebootMarket",
				ids: n
			}]), ...e.market.filter((e) => !n.includes(e)).map((e) => H("card", [{
				...t,
				ids: [...n, e]
			}], { card: e }))]);
			break;
		}
		case "rootChoice":
			t.flag && (r.deck = r.deck.filter((e) => e !== t.id), r.deck.unshift(t.id)), e.root[r.rid] = S[t.id].commands;
			break;
		case "swapPieces": {
			let n = e.pieces[t.id], r = e.pieces[t.value], i = n.at, a = r.at;
			n.at = "objective", r.at = "objective", B(e, Fe([{
				op: "enter",
				id: n.id,
				to: a
			}, {
				op: "enter",
				id: r.id,
				to: i
			}]));
			break;
		}
		default: return !1;
	}
	return !0;
}
x.slice(0, 4);
var tt = (e) => typeof e.at == "number", nt = (e, t) => new Set(t).size === t.length && t.every((t) => M(e).hand.includes(t)), rt = (e, t, n) => F(e, t, "program").filter((t) => t.color === n || t.color === "p" && e.action?.purple === n).map((e) => e.id);
function it(e, t, n) {
	let r = e.action;
	if (!e.cells.some((e) => e.id === t) || t === r.at || r.ghost === null && F(e, t, "guardian").some((t) => Ce(e, t)) || r.ghost === null && N(e) === 2903 && [
		1,
		3,
		5
	].includes(R(e, t).n) || r.ghost === null && N(e) === 2935 && R(e, t).color !== R(e, r.at).color && !ze(e, r.at, "b")) return null;
	if (r.kind === "nydamShip") return k(e, t) || k(e, r.at) ? null : 0;
	if (!O(e, r.at).includes(t) && !ze(e, r.at, "b")) return null;
	let i = (t) => ze(e, t, "b") || r.password.includes(t) || F(e, t, "program").some((e) => !n.includes(e.id) && (e.color === "b" || e.color === "p" && r.purple === "b"));
	return i(r.at) && i(t) ? 0 : 1;
}
function at(e, t) {
	let n = e.action, r = M(e);
	if (new Set(t).size !== t.length || t.some((t) => !e.pieces[t] || e.pieces[t].at !== n.at)) return !1;
	let i = t.map((t) => e.pieces[t]), a = (e) => !e.length || e.length === 1 && e[0].kind === "program" && e[0].color === "p" || e.length <= 3 && e.every((t) => t.kind === "program" && t.color !== "p" && t.color === e[0].color);
	return a(i) || r.profile === "hettie" && i.some((e, t) => ["program", "spark"].includes(e.kind) && a(i.filter((e, n) => t !== n)));
}
function ot(e) {
	let t = e.action, n = [];
	if (t.points < 1) return n;
	for (let r of e.pieces.filter(tt)) if (["program", "spark"].includes(r.kind) && (r.at === t.at || Re(e, r.at, "g") || ze(e, r.at, "g"))) {
		for (let t of O(e, r.at)) n.push({
			piece: r.id,
			to: t
		});
		if (N(e) === 2900) {
			let t = e.storedOrder.map((t) => e.pieces[t]), i = [
				"r",
				"y",
				"b",
				"g",
				"spark"
			][t.length % 5];
			(i === "spark" ? r.kind === "spark" && t.every((e) => e.kind !== "spark" || e.color === r.color) : r.kind === "program" && r.color === i) && n.push({
				piece: r.id,
				to: -1
			});
		}
	}
	if (e.trojanAt !== null && (e.trojanAt === t.at || Re(e, e.trojanAt, "g") || ze(e, e.trojanAt, "g"))) for (let t of O(e, e.trojanAt)) n.push({
		piece: 1e6,
		to: t
	});
	return n;
}
function st(e, t) {
	let n = M(e);
	if (e.phase !== "action" || e.action || e.prompt || e.reaction || e.tasks.length || !nt(e, t.pay) || t.avatar >= n.avatars.length) return !1;
	let r = n.avatars[t.avatar], i = t.ghost < 0 ? null : t.ghost;
	if (i !== null && !Ge(e, n, t.avatar).includes(i)) return !1;
	let a = i ?? r, o = {
		kind: t.kind,
		actor: n.rid,
		avatar: t.avatar,
		ghost: i,
		at: a,
		points: t.count,
		pay: t.pay,
		purple: t.purple,
		carried: [],
		used: [],
		bonus: [],
		path: [a],
		clone: [],
		enhanced: {},
		extraCommands: e.root[n.rid] ?? "",
		rootBefore: e.root[n.rid] ?? "",
		password: [],
		lighthouse: null,
		lighthouseTo: null
	};
	e.action = o;
	let s = "", c = !0, l = Re(e, a, "y"), u = L(e, a, "spark"), d = ["r", "y"].includes(t.color) && ze(e, a, t.color);
	switch (t.kind) {
		case "upload":
			s = t.color.repeat(d ? t.count : n.profile === "tilda" && t.color === "y" ? 2 : 3), c = (d || t.count === 1 && !I(e, a).length) && !!Le(e, "program", t.color) && (t.color !== "p" || Ie(e));
			break;
		case "install":
			s = t.color, c = t.color !== "p" && !I(e, a).length && !L(e, a, "installation") && Re(e, a, t.color) >= 3 && !!Le(e, "installation", t.color);
			break;
		case "move":
			s = "b".repeat(t.count);
			break;
		case "shift":
			s = "g".repeat(t.count), c = ot(e).length > 0;
			break;
		case "modify":
			s = "y" + t.color, c = l > 0 && u > 0 && (l > u || l === u && j(e, R(e, a).color).some((t) => ze(e, t, "y"))) && !!Le(e, "program", t.color) && (t.color !== "p" || Ie(e));
			break;
		case "infect":
			s = "r".repeat(t.count), c = Re(e, a, "r") > 0;
			break;
		case "upgrade":
			s = S[t.card]?.cost ?? "", c = (e.market.includes(t.card) || e.searchUpgrade && e.upgradeDeck.includes(t.card)) && t.pay.length > 0 && (N(e) !== 3022 || e.pieces.some((e) => e.kind === "program" && e.color === n.starting && typeof e.at == "number"));
			break;
		case "execute":
		case "reveal": {
			let r = S[t.card];
			c = !!r && n.hand.includes(t.card) && !t.pay.length && (t.kind === "execute" ? ["execute", "both"].includes(r.ability) : r.ability === "reveal" && !n.revealed.includes(t.card)) && $e(e, t.card);
			break;
		}
		case "leiko":
			s = "pp", c = n.profile === "leiko" && j(e, R(e, a).color).some((t) => I(e, t).some((t) => Pe(e, t)));
			break;
		case "tokyo":
			s = "bp", c = n.profile === "tokyo" && xe(e.tiles.filter((t) => t.color !== R(e, a).tile));
			break;
		case "shellshock": s = "rryyggbb", c = N(e) === 2837 && e.ghostId !== null && typeof e.pieces[e.ghostId].at == "number" && O(e, e.pieces[e.ghostId].at).every((n) => Re(e, n, t.color) > 0) && O(e, e.pieces[e.ghostId].at).reduce((t, n) => t + L(e, n, "program"), 0) >= 3;
	}
	let f = Je(t.pay, o.extraCommands, [], t.kind === "upgrade"), p = e.players.filter((e) => e !== n).some((e) => e.hand.some((e) => ["pingNexus", "nootropicBloom"].includes(S[e].key))) || n.packets.some((t) => e.packets[t].type === "exploit"), m = e.players.some((e) => e.hand.some((e) => !t.pay.includes(e) && S[e].key === "carbonClone"));
	if (!c || !Ye(f, s) && !p && !m) return e.action = null, !1;
	let h = {
		op: "performAction",
		text: t.kind,
		color: t.color,
		count: t.count,
		id: t.card
	};
	return e.phase = "resolve", ["execute", "reveal"].includes(t.kind) || (e.root[n.rid] = ""), t.kind === "execute" || t.kind === "reveal" ? B(e, h) : (o.bonus.push(s), Ke(e, "payment", [h])), !0;
}
function ct(e, t) {
	let n = e.pieces[t], r = e.action;
	if (N(e) === 2900) {
		let t = e.storedOrder.map((t) => e.pieces[t]), r = [
			"r",
			"y",
			"b",
			"g",
			"spark"
		][t.length % 5];
		if (r === "spark" ? n.kind !== "spark" || t.some((e) => e.kind === "spark" && e.color !== n.color) : n.kind !== "program" || n.color !== r) return !1;
	} else return !1;
	let i = We(e, n);
	return n.at = "objective", e.storedOrder.push(n.id), r.points--, e.activity = {
		kind: "store",
		at: -1,
		to: -1,
		piece: n.id,
		color: n.color,
		n: 1,
		pieceKind: n.kind,
		source: i,
		target: "objective"
	}, ke(e, "stored", r.at), !0;
}
function lt(e, t, n) {
	let r = e.action;
	if (!r || !["move", "nydamShip"].includes(r.kind) || e.tasks.length || e.prompt || e.reaction || !at(e, n)) return !1;
	let i = it(e, t, n);
	return i === null || i > r.points ? !1 : (r.points -= i, r.carried = n, r.path.push(t), B(e, {
		op: "actionMove",
		to: t,
		ids: n
	}), !0);
}
function ut(e, t, n) {
	return !e.action || e.action.kind !== "shift" || e.tasks.length || e.prompt || e.reaction || !ot(e).some((e) => e.piece === t && e.to === n) ? !1 : n === -1 ? ct(e, t) : (e.action.points--, B(e, t === 1e6 ? {
		op: "setTrojan",
		at: n
	} : {
		op: "enter",
		id: t,
		to: n
	}), !0);
}
function dt(e, t) {
	let n = e.action, r = M(e), i = n?.at ?? r.avatars[e.focus];
	switch (t.op) {
		case "performAction": {
			if (!n) break;
			let a = t.text, o = t.color, s = n.bonus[0] ?? "";
			if (!["execute", "reveal"].includes(a) && !Ye(Je(n.pay, n.extraCommands, n.clone, a === "upgrade", n.enhanced), s)) {
				B(e, { op: "cancelAction" });
				break;
			}
			if (a === "execute" || a === "reveal") {
				a === "execute" ? Ue(e, r, [t.id]) : (r.revealed.push(t.id), e.activity = {
					kind: "revealCard",
					at: -1,
					to: -1,
					piece: null,
					color: r.color,
					n: 1,
					cards: [t.id],
					owner: r.rid,
					source: "card:" + t.id,
					target: "cell:" + i
				}), B(e, {
					op: "cardEffect",
					id: t.id
				}, { op: "finishEffect" });
				break;
			}
			if (ke(e, a, i, t.count), a === "move" || a === "shift") {
				e.phase = "action", n.points = t.count;
				break;
			}
			if (a === "upload") {
				let r = n.pay.filter((e) => S[e].key === "adrenalinSurge").length;
				B(e, U("program", o, i, t.count), {
					op: "adrenalinOffer",
					color: o,
					count: r
				}, { op: "finishAction" });
				break;
			}
			if (a === "install") {
				V(e, "installPrograms", rt(e, i, o).map((e) => H("piece", [W(e), {
					op: "installConsume",
					color: o,
					count: 2
				}], {
					piece: e,
					at: i
				})));
				break;
			}
			if (a === "modify") {
				V(e, "chooseSpark", F(e, i, "spark").map((t) => H("piece", [W(t.id), G("chooseProgram", rt(e, i, "y").map((e) => H("piece", [
					W(e),
					U("program", o, i),
					{ op: "modifyStored" },
					{ op: "finishAction" }
				], {
					piece: e,
					at: i
				})))], {
					piece: t.id,
					at: i
				})));
				break;
			}
			if (a === "infect") {
				B(e, {
					op: "battleStart",
					at: i,
					count: t.count
				});
				break;
			}
			if (a === "upgrade") {
				e.market = e.market.filter((e) => e !== t.id), e.upgradeDeck = e.upgradeDeck.filter((e) => e !== t.id), r.hand.push(t.id), e.activity = {
					kind: "acquire",
					at: -1,
					to: -1,
					piece: null,
					color: r.color,
					n: 1,
					cards: [t.id],
					owner: r.rid,
					source: "market",
					target: "card:" + t.id
				}, N(e) === 3022 && B(e, G("knowledgeDeposit", e.pieces.filter((e) => e.kind === "program" && e.color === r.starting && typeof e.at == "number").map((e) => H("piece", [{
					op: "store",
					id: e.id
				}], {
					piece: e.id,
					at: e.at
				})))), e.tasks.push({ op: "finishAction" }), V(e, "sacrifice", n.pay.map((e) => H("card", [{
					op: "sacrifice",
					id: e
				}], { card: e })));
				break;
			}
			if (a === "leiko") {
				V(e, "chooseSMC", j(e, R(e, i).color).flatMap((t) => I(e, t)).filter((t) => Pe(e, t)).map((e) => H("piece", [
					W(e.id),
					{
						op: "choosePlace",
						kind: "program",
						cells: [e.at]
					},
					{ op: "finishAction" }
				], {
					piece: e.id,
					at: e.at
				})));
				break;
			}
			if (a === "tokyo") {
				let t = R(e, i).tile;
				V(e, "repositionTile", be(e.tiles.filter((e) => e.color !== t), t).map((e) => H("tilePosition", [{
					op: "reposition",
					color: t,
					at: e.q,
					to: e.r
				}, { op: "finishAction" }], {
					color: t,
					q: e.q,
					r: e.r
				})));
				break;
			}
			if (a === "shellshock") {
				B(e, {
					op: "shellshockRemove",
					count: 3
				});
				break;
			}
			break;
		}
		case "adrenalinOffer":
			t.count && Le(e, "program", t.color) && L(e, i, "program", t.color) < 3 && V(e, "adrenalinSurge", [H("skip", []), H("placePiece", [U("program", t.color, i), {
				...t,
				count: t.count - 1
			}], {
				color: t.color,
				at: i
			})]);
			break;
		case "finishEffect":
			n?.kind !== "nydamShip" && B(e, { op: "finishAction" });
			break;
		case "cancelAction":
			e.root[r.rid] = n?.rootBefore ?? "", e.action = null, e.phase = "action";
			break;
		case "installConsume": {
			let n = rt(e, i, t.color), r = t.count;
			r ? V(e, "installPrograms", n.map((e) => H("piece", [W(e), {
				...t,
				count: r - 1
			}], {
				piece: e,
				at: i
			}))) : B(e, U("installation", t.color, i), { op: "finishAction" });
			break;
		}
		case "sacrifice":
			e.activity = {
				kind: "sacrifice",
				at: -1,
				to: -1,
				piece: null,
				color: r.color,
				n: 1,
				cards: [t.id],
				owner: r.rid,
				source: "hand:" + r.rid,
				target: S[t.id].type === "advanced" ? "market" : "supply"
			}, r.hand = r.hand.filter((e) => e !== t.id), n.pay = n.pay.filter((e) => e !== t.id), e.searchUpgrade ? (e.upgradeDeck = Ee(e, [...e.upgradeDeck, t.id]), e.searchUpgrade = !1) : S[t.id].type === "advanced" && e.market.push(t.id);
			break;
		case "actionMove": {
			let i = t.to;
			n.at = i, n.ghost === null ? r.avatars[n.avatar] = i : n.ghost = i, e.activity = {
				kind: "avatar",
				at: n.path[n.path.length - 2],
				to: i,
				piece: null,
				color: r.color,
				n: 1,
				owner: r.rid,
				profile: r.profile,
				ghost: n.ghost !== null,
				source: n.ghost === null ? "avatarSlot:" + r.rid + ":" + n.avatar + ":" + n.path[n.path.length - 2] : "ghostSlot:" + n.path[n.path.length - 2],
				target: n.ghost === null ? "avatar:" + r.rid + ":" + n.avatar : "ghost"
			}, B(e, ...t.ids.map((e) => ({
				op: "enter",
				id: e,
				to: i
			})), {
				op: "settle",
				at: i
			}), n.kind === "nydamShip" && B(e, { op: "finishAction" });
			break;
		}
		case "modifyStored": {
			if (N(e) !== 3033) break;
			let t = Le(e, "program", "y");
			t ? (t.color = "y", B(e, {
				op: "store",
				id: t.id
			})) : V(e, "chooseProgram", e.pieces.filter((e) => e.kind === "program" && e.color === "y" && tt(e)).map((e) => H("piece", [{
				op: "store",
				id: e.id
			}], {
				piece: e.id,
				at: e.at
			})));
			break;
		}
		case "flashFloodOffer": {
			let t = e.pieces.filter((e) => e.kind === "program" && e.color === "b" && tt(e)).map((e) => e.id);
			V(e, "flashFlood", [H("skip", [{ op: "finishAction" }]), ...t.map((t) => H("piece", [{
				op: "store",
				id: t
			}, { op: "finishAction" }], {
				piece: t,
				at: e.pieces[t].at
			}))]);
			break;
		}
		case "finishAction":
			if (!n) break;
			if (N(e) === 2934 && n.kind === "move" && n.path[0] === z(e, r) && n.at === z(e, r) && new Set(n.path.filter((t) => R(e, t).n === 6 && R(e, t).color !== r.color).map((t) => R(e, t).color)).size >= 3 && !n.bonus.includes("flood")) {
				n.bonus.push("flood"), B(e, { op: "flashFloodOffer" });
				break;
			}
			if (N(e) === 2904 && ["move", "nydamShip"].includes(n.kind) && R(e, n.at).color !== r.color && !n.bonus.includes("defense")) {
				n.bonus.push("defense"), B(e, U("spark", "black", n.at, 3), { op: "finishAction" });
				break;
			}
			Ue(e, r, n.pay), B(e, {
				op: "collectPackets",
				at: n.at,
				rid: r.rid
			}, { op: "clearAction" });
			break;
		case "clearAction":
			e.action = null, e.battle = null, e.phase = "action";
			break;
		default: return !1;
	}
	return !0;
}
function ft(e, t) {
	let n = e.reaction, r = M(e, t), i = [];
	if (!n || n.passed.includes(t)) return i;
	for (let a of r.hand) {
		if (e.action?.pay.includes(a)) continue;
		let r = S[a].key;
		if (n.kind === "spawn" && r === "gingerCool") {
			if (!["logi", "sentinel"].includes(e.config.smc) && (!e.spawnServer || e.config.upgraded === "none") && ![3117, 3118].includes(N(e))) for (let e = 0; e < 6; e++) i.push({
				card: a,
				target: 0,
				value: e
			});
			if (![
				"logi",
				"spider",
				"glom"
			].includes(e.config.smc)) for (let e = 1; e <= 6; e++) i.push({
				card: a,
				target: 1,
				value: e
			});
		}
		if (n.kind === "infect" && r === "catalyst" && i.push({
			card: a,
			target: 0,
			value: 0
		}), n.kind === "payment" && e.action) {
			if (r === "carbonClone") for (let t of e.action.pay.filter((t) => !e.action.clone.includes(t))) i.push({
				card: a,
				target: t,
				value: 0
			});
			t !== e.active && ["pingNexus", "nootropicBloom"].includes(r) && i.push({
				card: a,
				target: 0,
				value: 0
			});
		}
	}
	return i;
}
function pt(e, t, n, r, i) {
	if (!ft(e, t).some((e) => e.card === n && e.target === r && e.value === i)) return !1;
	let a = S[n].key;
	return Ue(e, M(e, t), [n]), e.reaction.passed = [], a === "gingerCool" && (r === 0 ? e.spawnRoll.server = i : e.spawnRoll.n = i), a === "catalyst" && (e.battle.bonus += 2), a === "carbonClone" && e.action.clone.push(r), (a === "pingNexus" || a === "nootropicBloom") && (e.action.extraCommands += "p"), !0;
}
//#endregion
//#region src/games/deckers/objectives.ts
var mt = x.slice(0, 4), ht = (e) => e.players.length, gt = (e, t) => t[ht(e) - 1], _t = (e) => e.players.flatMap((e) => e.avatars), vt = (e) => we(e).flatMap((t) => j(e, t)), yt = (e) => e.players.every((t) => t.avatars.every((n) => n === z(e, t))), q = (e, t, n) => L(e, t, "program", n), bt = (e, t, n) => q(e, t, n) + L(e, t, "installation", n), xt = (e, t) => L(e, t, "spark") + L(e, t, "guardian") === 0;
function St(e, t) {
	if (!bt(e, t, "b")) return [];
	let n = /* @__PURE__ */ new Set([t]), r = [t];
	for (; r.length;) {
		let t = r.pop();
		for (let i of O(e, t)) !n.has(i) && bt(e, i, "b") && (n.add(i), r.push(i));
	}
	return [...n];
}
function Ct(e, t = N(e)) {
	let n = ht(e), r = we(e), i = e.cells, a = 0, o = 1, s = !1, c = (e) => {
		a = e.filter(Boolean).length, o = e.length, s = a === o;
	}, l = (e, t) => {
		a = e, o = t, s = e >= t;
	};
	switch (t) {
		case 3022:
			c(e.players.map((t) => L(e, "objective", "program", t.starting) >= 3));
			break;
		case 3023:
			c(r.map((t) => j(e, t).filter((t) => q(e, t, "g")).length >= 2));
			break;
		case 3024:
			c(r.map((t) => {
				let n = F(e, A(e, t, 1), "program");
				return n.length === 4 && new Set(n.map((e) => e.color)).size === 4;
			}));
			break;
		case 3029:
			c(r.map((t) => xt(e, A(e, t, 4))));
			break;
		case 3025:
			c(r.map((t) => j(e, t).filter((t) => q(e, t, "r")).length >= 3));
			break;
		case 3026:
			c(r.map((t) => L(e, A(e, t, 4), "spark") === 2));
			break;
		case 3027:
			c(_t(e).map((t) => k(e, t) && [t, ...O(e, t).filter((t) => R(e, t).n % 2 == 0)].every((t) => !L(e, t, "spark"))));
			break;
		case 3028:
			c([
				1,
				2,
				3,
				4
			].map((t) => bt(e, A(e, "p", t), "b") >= (t <= n ? 2 : 1)));
			break;
		case 3030:
			l(x.filter((t) => j(e, t).some((t) => L(e, t, "installation", "g"))).length, gt(e, [
				1,
				2,
				2,
				3
			]));
			break;
		case 3031:
			c(r.map((t) => j(e, t).some((t) => L(e, t, "installation"))));
			break;
		case 3032:
			l(x.filter((t) => q(e, A(e, t, 6), "y")).length, n + 1);
			break;
		case 3033:
			l(L(e, "objective", "program", "y"), n * 2);
			break;
		case 3110:
			l(Math.min(L(e, "objective", "program"), L(e, "objective", "spark")), 2 * n + 1);
			break;
		case 3111:
			l(x.filter((t) => [
				1,
				3,
				5
			].every((n) => bt(e, A(e, t, n), "g"))).length, n + 1);
			break;
		case 3112:
			l(x.filter((t) => j(e, t).some((t) => L(e, t, "installation", "r"))).length, gt(e, [
				2,
				3,
				3,
				4
			]));
			break;
		case 3113:
			c(r.map((t) => {
				let n = A(e, t, 2), r = A(e, t, 3);
				return L(e, n, "spark") === 1 && L(e, r, "spark") === 1 || L(e, n, "guardian") === 1 && L(e, r, "guardian") === 1;
			}));
			break;
		case 3114:
			l(j(e, "p").filter((t) => L(e, t, "installation")).length, gt(e, [
				2,
				3,
				4,
				4
			]));
			break;
		case 3115:
			l(x.filter((t) => q(e, A(e, t, 5), t) >= 2).length, gt(e, [
				2,
				3,
				4,
				4
			]));
			break;
		case 3116:
			l(i.filter((t) => !k(e, t.id) && q(e, t.id, "r")).length, gt(e, [
				5,
				8,
				11,
				14
			]));
			break;
		case 3117:
			c(j(e, e.swarm).map((t) => xt(e, t)));
			break;
		case 3118:
			l(i.filter((t) => L(e, t.id, "installation", "g") && (t.color === "r" || O(e, t.id).some((t) => R(e, t).color === "r"))).length, gt(e, [
				1,
				2,
				2,
				3
			]));
			break;
		case 3119:
			c(r.map((t) => !!q(e, A(e, t, 6), "r")));
			break;
		case 3120:
			a = i.reduce((t, n) => t + (q(e, n.id, n.color) ? n.n : 0), 0), o = gt(e, [
				18,
				25,
				32,
				39
			]), s = a === o;
			break;
		case 3121: {
			let t = x.filter((t) => Array.from({ length: n + 1 }, (n, r) => A(e, t, r + 1)).every((t) => bt(e, t, "b"))), r = t.some((r, i) => t.slice(i + 1).some((t) => {
				let i = St(e, A(e, r, 1));
				return [r, t].every((t) => Array.from({ length: n + 1 }, (n, r) => A(e, t, r + 1)).every((e) => i.includes(e))) && i.some((n) => ![r, t].includes(R(e, n).color));
			}));
			c([t.length >= 2, r]);
			break;
		}
		case 2900: {
			let t = e.storedOrder.map((t) => e.pieces[t].color), r = Array.from({ length: n }, () => [
				"r",
				"y",
				"b",
				"g",
				"spark"
			]).flat();
			c([
				t.length >= 5 * n,
				r.every((e, n) => e === "spark" ? ["black", "white"].includes(t[n]) : t[n] === e),
				yt(e),
				new Set(t.filter((e) => e === "white" || e === "black")).size <= 1
			]);
			break;
		}
		case 2901:
			c([...i.filter((t) => k(e, t.id)).map((t) => L(e, t.id, "program") > 0), ...vt(e).filter((t) => R(e, t).n % 2 == 1).map((t) => !!q(e, t, "g"))]);
			break;
		case 2902:
			c(e.players.map((t) => {
				let n = St(e, z(e, t));
				return n.includes(A(e, "p", 6)) && x.filter((r) => r !== t.color && r !== "p" && n.includes(A(e, r, 6))).length >= (t.color === "p" ? 2 : 1);
			}).concat([yt(e)]));
			break;
		case 2903:
			c(vt(e).filter((t) => R(e, t).n % 2 == 1).map((t) => !!bt(e, t, "b")).concat([yt(e)]));
			break;
		case 2904:
			c(_t(e).map((t) => L(e, t, "installation", "g") + L(e, t, "installation", "r") > 0));
			break;
		case 2905:
			c(i.filter((e) => e.n <= 2).map((t) => xt(e, t.id)));
			break;
		case 2906: {
			let t = (t) => JSON.stringify(j(e, t).sort((t, n) => R(e, t).n - R(e, n).n).map((t) => [
				...x.map((n) => q(e, t, n)),
				L(e, t, "spark", "black"),
				L(e, t, "spark", "white")
			])), i = t(r[0]), a = x.filter((e) => t(e) === i);
			c([
				r.every((e) => a.includes(e)),
				a.length >= n + 1,
				a.every((t) => mt.every((n) => j(e, t).some((t) => q(e, t, n))))
			]);
			break;
		}
		case 2907:
			c(e.players.map((t) => xt(e, z(e, t))));
			break;
		case 2908:
			c([e.trojanAt === null, yt(e)]);
			break;
		case 2909:
			c([e.hackman === null, yt(e)]);
			break;
		case 2934:
			c([
				L(e, "objective", "program", "b") >= n,
				...e.players.map((t) => !!q(e, z(e, t), "b")),
				yt(e)
			]);
			break;
		case 2935:
			l(x.filter((t) => new Set(F(e, A(e, t, 2), "program").map((e) => e.color)).size >= 3).length, n + 1);
			break;
		case 2836:
		case 2837:
		case 2839:
			c(e.players.map((t) => L(e, "objective", "program", t.color) > 0));
			break;
		case 2838: c([e.ghostId === null]);
	}
	return {
		have: a,
		need: o,
		complete: s
	};
}
var J = (e, t, n = 1, r, i = "placePiece") => ({
	op: "choosePlace",
	kind: e,
	color: t,
	count: n,
	cells: r,
	text: i
}), wt = (e, t) => t.map(W), Tt = (e, t, n, r = 1) => Fe(n.map((n) => U(e, t, n, r))), Et = (e, t) => e.pieces.filter((e) => e.kind === "installation" && typeof e.at == "number" && (!t || e.color === t));
function Dt(e) {
	let t = N(e);
	ht(e);
	let n = [];
	if (t === 3030 || t === 3033) for (let r of e.players) {
		let i = F(e, z(e, r), "program");
		i.length && n.push(G("replaceStarting", [H("skip", []), ...i.map((n) => H("piece", [W(n.id), U("program", t === 3030 ? "g" : "y", z(e, r))], { piece: n.id }))], r.rid));
	}
	if (t === 3027 && !e.cells.some((t) => k(e, t.id)) && n.push({ op: "repositionSetup" }), t === 3112 || t === 3118) {
		let r = t === 3112 ? "r" : "g";
		for (let t of Et(e, r)) n.push(G("replaceInstallation", mt.filter((e) => e !== r).map((e) => H("color", [W(t.id), U("installation", e, t.at)], {
			at: t.at,
			color: e
		}))));
	}
	if (t === 3114) {
		let t = e.cells.filter((t) => t.color !== "p" && !O(e, t.id).some((t) => R(e, t).color === "p")).map((e) => e.id);
		for (let r of Et(e).filter((t) => R(e, t.at).color === "p")) n.push({
			op: "chooseRelocate",
			ids: [r.id],
			cells: t
		});
	}
	return t === 3117 && (e.swarm = De(e), n.push(Tt("spark", "black", j(e, e.swarm).filter((t) => xt(e, t))))), t === 2903 && n.push(...wt(e, vt(e).filter((t) => R(e, t).n % 2 == 1).flatMap((t) => F(e, t, "program", "b").map((e) => e.id)))), t === 2935 && n.push(...e.pieces.filter((e) => e.kind === "program" && ["b", "g"].includes(e.color) && typeof e.at == "number").map((e) => W(e.id)), Tt("program", "g", e.cells.filter((e) => e.n % 2 == 1).map((e) => e.id))), t === 2908 && n.push({ op: "setupTrojan" }), t === 2909 && n.push({ op: "setupHackman" }), [
		2836,
		2837,
		2838,
		2839
	].includes(t) && n.push({
		op: "setupGhost",
		id: t
	}), n;
}
function Ot(e) {
	let t = N(e), n = Ct(e).complete, r = ht(e), i = we(e), a = e.cells;
	if (e.objectiveSuccess = n, e.results.push({
		id: t,
		success: n
	}), e.config.smc === "sentinel" && !n && t !== 3120) return [{
		op: "lose",
		text: "failedObjective"
	}];
	if (he[t].level === 2) return [{
		op: n ? e.cycle === e.objectives.length - 1 ? "win" : "goldContinue" : "lose",
		text: "failedObjective"
	}];
	let o = [], s = (e, t = 1) => Tt("spark", "black", e, t);
	switch (t) {
		case 3022:
			if (n) o.push({ op: "redistributeStored" });
			else for (let t of e.players) o.push({
				op: "knowledgeFail",
				rid: t.rid
			});
			break;
		case 3023:
			n ? o.push(J("installation", "g")) : o.push(s(i.flatMap((t) => j(e, t).filter((t) => !q(e, t, "g")))));
			break;
		case 3024:
			n ? o.push({
				op: "choosePlace",
				kind: "installation",
				cells: [...j(e, "b"), ...j(e, "g")]
			}) : o.push(s(x.map((t) => A(e, t, 1))));
			break;
		case 3029:
			n ? o.push(Tt("program", "g", x.map((t) => A(e, t, 4)))) : o.push(s(x.filter((t) => !xt(e, A(e, t, 4)) || !xt(e, A(e, t, 5))).map((t) => A(e, t, 6))));
			break;
		case 3025:
			n ? o.push(J("installation", "y")) : o.push(...i.filter((t) => j(e, t).filter((t) => q(e, t, "r")).length <= 1).map((t) => J("spark", "black", 3, j(e, t))));
			break;
		case 3026:
			n ? o.push({ op: "doubleSwitch" }) : o.push(s(mt.map((t) => A(e, t, 4))));
			break;
		case 3027:
			if (n) o.push(J("installation", "b"));
			else for (let t of e.players) for (let n of t.avatars) o.push(s([n]), J("spark", "black", 2, O(e, n)));
			break;
		case 3028:
			n ? o.push(J("program", "r", 1, j(e, "p")), J("installation", "b", 1, j(e, "p"))) : o.push(s(j(e, "p").filter((t) => !bt(e, t, "b"))));
			break;
		case 3030:
			n ? o.push(J("installation", "b")) : o.push(s(x.filter((t) => !j(e, t).some((t) => L(e, t, "installation", "g"))).map((t) => A(e, t, Te(e, 6) + 1))));
			break;
		case 3031:
			n ? o.push(G("chooseServer", i.map((t) => H("color", j(e, t).map((e) => ({
				op: "choosePlace",
				kind: "program",
				at: e,
				cells: [e]
			})), { color: t })))) : o.push(s(x.filter((t) => !j(e, t).some((t) => L(e, t, "installation"))).map((t) => A(e, t, 6))));
			break;
		case 3032:
			n ? o.push(J("installation", "r")) : o.push(Ne(e, "placePiece", x.filter((t) => !q(e, A(e, t, 6), "y")).map((t) => A(e, t, 6)), (e) => [U("spark", "black", e, 2)]), s(i.map((t) => A(e, t, 6))));
			break;
		case 3033:
			n ? o.push({ op: "flipStoredRed" }, { op: "redistributeStored" }, J("installation", "y", 1, a.filter((e) => e.color !== "p").map((e) => e.id))) : o.push({ op: "returnStored" }, s([A(e, "y", 1), ...[
				"r",
				"b",
				"p"
			].map((t) => A(e, t, 6))]));
			break;
		case 3110:
			if (n) o.push({ op: "redistributeStored" });
			else {
				let t = Math.max(0, 2 * r + 1 - L(e, "objective", "spark")) + Math.max(0, 2 * r + 1 - L(e, "objective", "program"));
				o.push({ op: "permanentStored" }, ...i.map((n) => J("spark", "black", t, j(e, n))));
			}
			break;
		case 3111: {
			let t = De(e);
			n ? o.push(s(j(e, t).filter((t) => xt(e, t) && !bt(e, t, "g")))) : o.push(s(i.filter((t) => !j(e, t).some((t) => bt(e, t, "g"))).map((t) => A(e, t, 6)), 2), s(j(e, t).filter((t) => !L(e, t, "guardian"))));
			break;
		}
		case 3112:
			n ? o.push(G("chooseInstallation", Et(e, "r").map((t) => H("piece", [J("spark", "black", 3, O(e, t.at))], {
				piece: t.id,
				at: t.at
			})))) : o.push(s(j(e, "p")));
			break;
		case 3113:
			n ? o.push(J("spark", "black", r + 1, a.filter((e) => e.n === 1).map((e) => e.id))) : o.push(s(i.map((t) => A(e, t, 1))), s(i.map((t) => A(e, t, 6)), 2));
			break;
		case 3114:
			n ? o.push({ op: "buildPalace" }) : o.push(s([
				"r",
				"y",
				"g",
				"p"
			].map((t) => A(e, t, 3)), 2));
			break;
		case 3115:
			n ? o.push(J("spark", "black", r + 1, a.filter((e) => e.n === 5).map((e) => e.id))) : o.push(s(a.filter((t) => t.n === 5 && q(e, t.id, t.color) < 2).map((e) => e.id)), J("spark", "black", r + 3, a.filter((e) => e.n === 5).map((e) => e.id)));
			break;
		case 3116: {
			let t = (t) => s(j(e, t).filter((t) => !q(e, t, "r")));
			n ? o.push(G("chooseServer", ["y", "r"].map((e) => H("color", [t(e)], { color: e })))) : o.push(t("y"), t("r"));
			break;
		}
		case 3117:
			o.push(s(j(e, e.swarm).filter((t) => !n || R(e, t).n % 2 == 1)));
			break;
		case 3118:
			n ? o.push({
				op: "chooseRemove",
				kind: "installation",
				color: "g"
			}, G("chooseColor", ["b", "g"].map((e) => H("color", [{
				op: "dreamReward",
				color: e
			}], { color: e })))) : o.push(...a.filter((t) => t.color === "r" || O(e, t.id).some((t) => R(e, t).color === "r")).flatMap((t) => F(e, t.id, "program", "g").map((e) => W(e.id))), s(j(e, "r")));
			break;
		case 3119:
			n ? o.push(Tt("program", "r", i.map((t) => A(e, t, 6)))) : o.push(s([...new Set(_t(e))], 2));
			break;
		case 3120:
			n ? o.push(s(j(e, M(e).color).filter((t) => !L(e, t, "guardian") && !q(e, t, R(e, t).color)))) : o.push({ op: "rebootCycle" });
			break;
		case 3121: n ? o.push(s(["r", "y"].flatMap((t) => [1, 3].map((n) => A(e, t, n))))) : o.push(s(i.map((t) => A(e, t, 1))), s(["r", "y"].flatMap((t) => [
			1,
			3,
			5
		].map((n) => A(e, t, n)))));
	}
	return o;
}
function kt(e, t) {
	switch (t.op) {
		case "setupObjective":
			B(e, ...Dt(e));
			break;
		case "resolveObjective":
			B(e, ...Ot(e), { op: "returnStored" }, { op: "moveArrows" }), e.activity = {
				kind: "objective",
				at: -1,
				to: -1,
				piece: null,
				color: "y",
				n: 1,
				target: "objective"
			};
			break;
		case "returnStored":
			B(e, ...F(e, "objective").map((e) => ({
				op: "transfer",
				id: e.id,
				text: "supply"
			}))), e.storedOrder = [];
			break;
		case "permanentStored":
			B(e, ...F(e, "objective").map((e) => ({
				op: "transfer",
				id: e.id,
				text: "removed"
			})));
			break;
		case "flipStoredRed":
			B(e, ...F(e, "objective").filter((e) => e.color === "y").map((e) => ({
				op: "flip",
				id: e.id
			})));
			break;
		case "redistributeStored": {
			let t = F(e, "objective");
			t.length && V(e, "redistribute", t.map((e) => H("piece", [{
				op: "chooseRelocate",
				ids: [e.id]
			}, { op: "redistributeStored" }], {
				piece: e.id,
				color: e.color
			})));
			break;
		}
		case "knowledgeFail": {
			let n = F(e, "objective", "program", M(e, t.rid).starting);
			V(e, "reducePenalty", Array.from({ length: Math.min(2, n.length) + 1 }, (t, r) => H("removePrograms", [...n.slice(0, r).map((e) => W(e.id)), J("spark", "black", 2 - r, j(e, "g"))], { n: r })));
			break;
		}
		case "doubleSwitch": {
			let t = e.pieces.filter((t) => t.kind === "spark" && typeof t.at == "number" && R(e, t.at).n === 4);
			V(e, "doubleSwitch", [H("finish", []), ...t.map((e) => H("piece", [
				W(e.id),
				U("program", "g", e.at),
				{ op: "doubleSwitch" }
			], {
				piece: e.id,
				at: e.at
			}))]);
			break;
		}
		case "buildPalace": {
			let t = Et(e).filter((t) => R(e, t.at).color === "p");
			V(e, "buildPalace", t.flatMap((n, r) => t.slice(r + 1).map((t) => H("installations", [
				{
					op: "store",
					id: n.id,
					text: "palace"
				},
				{
					op: "store",
					id: t.id,
					text: "palace"
				},
				Ne(e, "palaceDestination", e.cells.filter((e) => e.n === 3).map((e) => e.id), (e) => [{
					op: "palace",
					at: e
				}])
			], {
				piece: n.id,
				n: t.id
			}))));
			break;
		}
		case "palace":
			e.palaceAt = t.at, B(e, {
				op: "settle",
				at: t.at
			});
			break;
		case "dreamReward":
			B(e, Ne(e, "placePiece", e.cells.map((e) => e.id), (n) => [U("installation", t.color, n), Tt("spark", "black", O(e, n))], t.color));
			break;
		case "rebootCycle": {
			let t = Ee(e, e.unused.filter((e) => he[e].level === 1))[0];
			t === void 0 ? Ae(e, "noSilverObjective") : (e.unused = e.unused.filter((e) => e !== t), e.objectives.splice(e.cycle + 1, 0, t));
			break;
		}
		case "goldContinue":
			B(e, { op: "returnStored" });
			break;
		case "moveArrows": {
			if (e.config.smc === "spider") {
				B(e, { op: "refreshStart" });
				break;
			}
			let t = he[N(e)].arrows.map(([e, t]) => ({
				c: e,
				d: t === "+" ? 1 : -1
			}));
			e.objectiveSuccess || t.reverse().forEach((e) => e.d *= -1), B(e, ...t.map((e) => ({
				op: "arrow",
				color: e.c,
				value: e.d
			})), { op: "refreshStart" });
			break;
		}
		case "arrow": {
			let n = j(e, t.color).filter((t) => L(e, t, "spark")).sort((n, r) => (R(e, n).n - R(e, r).n) * t.value);
			n.length && B(e, {
				op: "numericMove",
				at: n[0],
				value: t.value,
				ids: F(e, n[0], "spark").map((e) => e.id),
				flag: !0
			});
			break;
		}
		case "numericMove": {
			let n = (t.ids ?? []).filter((n) => e.pieces[n].at === t.at);
			if (!n.length) break;
			let r = R(e, t.at), i = t.value, a = r.n, o = r.id;
			for (let n = 0; n < 6 && (a = (a - 1 + i + 6) % 6 + 1, o = A(e, r.color, a), L(e, o, "guardian")); n++) if (!t.flag) return !0;
			if (o === r.id) break;
			V(e, "moveSpark", n.map((e) => H("piece", [{
				op: "enter",
				id: e,
				to: o
			}, {
				...t,
				ids: n.filter((t) => t !== e)
			}], {
				piece: e,
				at: r.id
			})));
			break;
		}
		default: return !1;
	}
	return !0;
}
//#endregion
//#region src/games/deckers/turns.ts
var At = x.slice(0, 4), Y = (e, t = 1) => Fe(e.map((e) => U("spark", "black", e, t)));
function jt() {
	return [
		{
			op: "networkSetup",
			ids: [
				0,
				1,
				2,
				3,
				4
			]
		},
		{
			op: "chooseProfiles",
			value: 0
		},
		{ op: "initializeDecks" },
		{ op: "smcSetup" },
		{ op: "freeBlue" },
		{ op: "packetSetup" },
		{ op: "restock" },
		{ op: "intelStart" }
	];
}
function Mt(e) {
	e.tiles = [];
	for (let t of [
		"p",
		"r",
		"g",
		"b",
		"y"
	]) {
		let n = be(e.tiles, t).sort((t, n) => {
			let r = (t) => {
				let n = D([...e.tiles, t], !1);
				return n.reduce((e, t) => e + (k({ cells: n }, t.id) ? 10 : 0), 0) * 100 - (Math.max(...n.map((e) => e.q)) - Math.min(...n.map((e) => e.q))) * (Math.max(...n.map((e) => e.r)) - Math.min(...n.map((e) => e.r)));
			};
			return r(n) - r(t);
		})[0];
		e.tiles.push(n);
	}
	e.cells = D(e.tiles, e.config.fragmented);
}
function Nt(e) {
	let t = j(e, "p"), n = e.players.map((t) => z(e, t)), r = e.cells;
	switch (e.config.smc) {
		case "alphaMoby": return [Y(t), Y(n)];
		case "spider": return [Y(t), Y(we(e).flatMap((t) => j(e, t).filter((t) => R(e, t).n % 2 == 1)))];
		case "glom":
			for (let t of e.pieces) typeof t.at == "number" && t.kind === "program" && (t.color = "g");
			return [Y(r.filter((t) => t.n % 2 == 0 && !k(e, t.id)).map((e) => e.id)), { op: "glomSetupPurple" }];
		case "logi": return [Y(r.filter((t) => k(e, t.id)).map((e) => e.id), 2), Y(t.filter((t) => R(e, t).n % 2 == 1))];
		case "viking": return [Y(r.filter((e) => [2, 4].includes(e.n)).map((e) => e.id)), Y(r.filter((t) => t.n === 5 && !k(e, t.id)).map((e) => e.id), 2)];
		case "sentinel": return [Y(r.filter((t) => ["y", "r"].includes(t.color) && !k(e, t.id)).map((e) => e.id), 2), Y(t.filter((t) => !k(e, t)))];
		case "mother": return [
			Y(t),
			Y(r.filter((t) => O(e, t.id).some((t) => R(e, t).color === "p")).map((e) => e.id)),
			{ op: "motherSetupClosed" }
		];
	}
}
function Pt(e) {
	let t = [], n = Se(e);
	switch (e.config.smc === "alphaMoby" && t.push({
		...U("spark", "black", n),
		text: "alphaMoby"
	}), e.config.smc === "mother" && t.push({
		...U("spark", "black", z(e, M(e))),
		text: "mother"
	}), N(e)) {
		case 3031:
			t.push({
				...U("spark", "black", Oe(e)),
				text: "romanCandle"
			});
			break;
		case 2904:
			t.push({
				...U("spark", "black", A(e, M(e).color === "p" ? "g" : "p", 1)),
				text: "distributedDefense"
			});
			break;
		case 2934:
			t.push({
				...U("spark", "black", z(e, M(e))),
				text: "flashFlood"
			});
			break;
		case 2909: t.push({
			op: "hackmanStart",
			text: "hackMan"
		});
	}
	return t;
}
function Ft(e) {
	let t = [];
	switch (e.config.smc === "spider" && t.push({
		op: "spiderEnd",
		text: "spider"
	}), e.config.smc === "glom" && t.push({
		op: "glomEnd",
		text: "glom"
	}), N(e)) {
		case 3113:
			t.push({
				op: "jacobEnd",
				text: "jacobSLadder"
			});
			break;
		case 3115:
			t.push({
				op: "scramblerEnd",
				text: "scrambler"
			});
			break;
		case 3119:
			t.push({
				op: "accessShutdownEnd",
				text: "accessShutdown"
			});
			break;
		case 2901:
			t.push({
				op: "smcAttackStart",
				flag: !0,
				text: "simSmudge"
			});
			break;
		case 2905:
			t.push({
				op: "waterfallEnd",
				text: "waterfall"
			});
			break;
		case 2907: t.push({
			op: "neutrinoEnd",
			text: "neutrinoScanner"
		});
	}
	return t;
}
function It(e) {
	return e.firstTurn ? (e.firstTurn = !1, []) : N(e) === 2907 ? [] : (e.spawnCount = C[e.config.smc].spawn[P(e)] + +(e.config.upgraded === "2.1" && P(e) === 0), e.spawnServer = null, [{
		op: "setStep",
		text: "spawn"
	}, { op: "spawnRoll" }]);
}
function Lt(e, t, n, r) {
	let i = Te(e, 6) + 1, a = N(e) === 2839 && e.ghostId !== null && e.pieces[e.ghostId].at === t ? 0 : Te(e, 6) + 1, o = L(e, t, "program", "r") + (e.action?.purple === "r" ? L(e, t, "program", "p") : 0), s = ze(e, t, "r") ? 4 : 0, c = O(e, t), l = +!!e.players.some((n) => n.profile === "oshin" && (n.avatars.includes(t) || e.action?.actor === n.rid && e.action.ghost === t)), u = i + n + o + s + c.filter((t) => ze(e, t, "r")).length + l, d = a + L(e, t, "spark") + 4 * L(e, t, "guardian") + c.reduce((t, n) => t + L(e, n, "guardian"), 0);
	N(e) === 2839 && e.ghostId !== null && e.pieces[e.ghostId].at === t && (d = 16, u += j(e, R(e, t).color).reduce((t, n) => t + 4 * L(e, n, "installation"), 0)), e.battle = {
		at: t,
		red: i,
		black: a,
		paid: n,
		infect: u,
		resistance: d,
		automatic: r,
		bonus: 0
	}, e.activity = {
		kind: "dice",
		at: t,
		to: t,
		piece: null,
		color: "r",
		n: u - d
	}, ke(e, "battle", t, u - d), r ? B(e, { op: "battleResult" }) : Ke(e, "infect", [{ op: "battleResult" }]);
}
function Rt(e, t) {
	let n = e.config.smc;
	if (![
		"spider",
		"logi",
		"glom"
	].includes(n)) return e.spawnRoll.n;
	let r = j(e, t).filter((t) => n === "glom" || !L(e, t, "guardian")), i = n === "spider" ? "spark" : "program", a = n === "logi" ? "r" : n === "glom" ? "g" : void 0;
	return r.sort((t, r) => L(e, t, i, a) - L(e, r, i, a) + (R(e, t).n - R(e, r).n) * (n === "logi" ? -.01 : .01)), r.length ? R(e, r[0]).n : 1;
}
function zt(e, t) {
	let n = M(e), r = e.players.length;
	if ([
		"turnStart",
		"spawnRoll",
		"glomEnd",
		"jacobEnd",
		"waterfallEnd"
	].includes(t.op) && !t.checked && new Set(n.avatars).size > 1) return V(e, "chooseAvatar", n.avatars.map((e, n) => H("space", [{
		op: "setFocus",
		value: n
	}, {
		...t,
		checked: !0
	}], {
		at: e,
		n: n + 1
	}))), !0;
	switch (t.op) {
		case "networkSetup": {
			if (e.config.network === "preset") {
				Mt(e);
				break;
			}
			if (!t.ids?.length) break;
			let n = x[t.ids[0]];
			V(e, "placeTile", be(e.tiles, n).map((e) => H("tilePosition", [{
				op: "placeTile",
				color: n,
				at: e.q,
				to: e.r
			}, {
				...t,
				ids: t.ids.slice(1)
			}], {
				color: n,
				q: e.q,
				r: e.r
			})));
			break;
		}
		case "placeTile":
			e.tiles.push({
				color: t.color,
				q: t.at,
				r: t.to
			}), e.cells = D(e.tiles, e.config.fragmented);
			break;
		case "chooseProfiles": {
			let n = t.value ?? 0;
			if (n >= r) break;
			let i = e.players[n], a = e.players.filter((e) => e.profile).map((e) => e.color);
			V(e, "chooseProfile", ge.filter((t) => !a.includes(_e[t]) && (!e.config.introductory || [
				"hettie",
				"monty",
				"tilda",
				"oshin"
			].includes(t))).map((e) => H("profile", [
				{
					op: "profile",
					rid: i.rid,
					text: e
				},
				...e === "leiko" ? [{
					op: "leikoStarting",
					rid: i.rid
				}] : [],
				{
					op: "chooseProfiles",
					value: n + 1
				}
			], { profile: e })), i.rid);
			break;
		}
		case "leikoStarting":
			V(e, "startingType", At.map((e) => H("color", [{
				op: "starting",
				rid: t.rid,
				color: e
			}], { color: e })), t.rid);
			break;
		case "starting":
			M(e, t.rid).starting = t.color;
			break;
		case "initializeDecks":
			for (let t of e.players) t.deck = Ee(e, pe.filter((e) => e.home === t.color).map((e) => e.id)), t.hand = t.deck.splice(0, 5), B(e, U("program", t.starting, z(e, t)));
			e.upgradeDeck = Ee(e, pe.filter((e) => e.type === "advanced").map((e) => e.id));
			break;
		case "smcSetup":
			B(e, ...Nt(e));
			break;
		case "glomSetupPurple":
			B(e, Y(j(e, "p").filter((t) => !L(e, t, "spark"))));
			break;
		case "motherSetupClosed":
			B(e, Y(e.cells.filter((t) => k(e, t.id) && !L(e, t.id, "spark", "black")).map((e) => e.id)));
			break;
		case "freeBlue":
			B(e, {
				op: "choosePlace",
				kind: "program",
				color: e.config.smc === "glom" ? "g" : "b",
				count: 5 - new Set(e.players.flatMap((t) => t.avatars.map((t) => R(e, t).tile))).size
			});
			break;
		case "packetSetup": {
			if (!e.config.packets) break;
			let t = Ee(e, w), n = e.cells.filter((e) => [2, 5].includes(e.n)).map((e) => e.id);
			e.packets = n.map((e, n) => ({
				id: n,
				type: t[n],
				at: e
			})), B(e, ...n.map((e) => ({
				op: "packetBlue",
				at: e
			})));
			break;
		}
		case "packetBlue": {
			let n = t.at;
			if (L(e, n, "program", "b") || L(e, n, "program", "g")) break;
			Le(e, "program", "b") ? B(e, U("program", "b", n)) : B(e, {
				op: "chooseRelocate",
				ids: e.pieces.filter((t) => t.kind === "program" && ["b", "g"].includes(t.color) && typeof t.at == "number" && !e.packets.some((e) => e.at === t.at)).map((e) => e.id),
				cells: [n]
			});
			break;
		}
		case "intelStart":
			e.phase = "resolve", e.step = "intel", e.objectiveSuccess = null, e.swarm = null;
			for (let t of e.packets.filter((e) => e.at === "discard")) t.at = Oe(e);
			B(e, { op: "setupObjective" }, G("firstDecker", e.players.map((e) => H("decker", [{
				op: "setActive",
				rid: e.rid
			}, { op: "turnStart" }], { rid: e.rid }))));
			break;
		case "setActive":
			e.active = t.rid, e.focus = 0, e.activity = {
				kind: "handoff",
				at: -1,
				to: -1,
				piece: null,
				color: M(e).color,
				n: 1,
				target: "seat:" + e.active
			};
			break;
		case "turnStart":
			e.phase = "resolve", e.step = "start", n.revealed = [], e.root[n.rid] = "", e.action = null, e.battle = null, B(e, Fe(Pt(e), "startOrder"), { op: "spawnStart" }, { op: "actionStart" });
			break;
		case "spawnStart": {
			let t = It(e);
			t.length && Ke(e, "beforeSpawn", t);
			break;
		}
		case "spawnRoll": {
			if (e.spawnCount <= 0) break;
			let t = P(e), r = e.config.smc, i, a, o = 0;
			if (e.config.upgraded !== "none" && e.spawnServer ? i = e.spawnServer : r === "logi" || r === "sentinel" ? i = R(e, n.avatars[e.focus]).color : (o = Te(e, 6), i = o === 5 ? R(e, n.avatars[e.focus]).color : x[o]), N(e) === 3117 && (i = e.swarm), N(e) === 3118 && (i = "r"), r === "spider" || r === "logi") {
				let t = r === "spider" ? "spark" : "program", n = r === "spider" ? void 0 : "r", o = j(e, i).filter((t) => !L(e, t, "guardian")).sort((i, a) => L(e, i, t, n) - L(e, a, t, n) + (r === "spider" ? (R(e, i).n - R(e, a).n) / 100 : (R(e, a).n - R(e, i).n) / 100));
				a = o.length ? R(e, o[0]).n : 1;
			} else a = r === "glom" ? R(e, j(e, i).sort((t, n) => L(e, t, "program", "g") - L(e, n, "program", "g") + (R(e, t).n - R(e, n).n) / 100)[0]).n : Te(e, 6) + 1;
			e.spawnRoll = {
				server: o,
				n: a
			}, e.activity = {
				kind: "spawnRoll",
				at: A(e, i, a),
				to: A(e, i, a),
				piece: null,
				color: C[r].white[t] ? "white" : "black",
				n: a
			}, Ke(e, "spawn", [{
				op: "spawnPlace",
				color: i
			}], null);
			break;
		}
		case "spawnPlace": {
			let r = e.spawnServer ?? t.color, i = e.spawnRoll.server, a = r;
			!e.spawnServer && e.config.smc !== "logi" && e.config.smc !== "sentinel" && (a = i === 5 ? R(e, n.avatars[e.focus]).color : x[i]), N(e) === 3117 && (a = e.swarm), N(e) === 3118 && (a = "r");
			let o = Rt(e, a);
			e.config.upgraded !== "none" && (e.spawnServer = a);
			let s = C[e.config.smc].white[P(e)] || e.config.upgraded !== "none" && P(e) === 2;
			e.spawnCount--, B(e, U("spark", s ? "white" : "black", A(e, a, o)), { op: "spawnRoll" });
			break;
		}
		case "actionStart":
			e.phase = "action", e.step = "action", e.spawnRoll = null;
			break;
		case "endEffects":
			e.step = "end", B(e, Fe(Ft(e), "endOrder"), { op: "turnDraw" });
			break;
		case "turnDraw":
			n.turns++, n.turns === 3 && Ue(e, n, [...n.hand]), B(e, ...n.turns < 3 ? [{
				op: "draw",
				rid: n.rid,
				count: 5
			}] : [], { op: "restock" }, { op: "handoff" });
			break;
		case "handoff": {
			let t = e.players.filter((e) => e.turns < 3);
			t.length ? V(e, "nextDecker", t.map((e) => H("decker", [{
				op: "setActive",
				rid: e.rid
			}, { op: "turnStart" }], { rid: e.rid }))) : B(e, { op: "smcAttackStart" }, {
				op: "setStep",
				text: "objective"
			}, { op: "resolveObjective" });
			break;
		}
		case "smcAttackStart":
			e.step = "smcAttack", B(e, {
				op: "smcBattles",
				flag: t.flag
			}, {
				op: "smcCleanup",
				flag: t.flag
			});
			break;
		case "smcBattles": {
			let n = e.cells.filter((t) => L(e, t.id, "program", "r") && I(e, t.id).length).map((e) => e.id);
			if (!n.length) break;
			if (e.config.smc === "sentinel") {
				let r = n.find((t) => L(e, t, "guardian"));
				if (r !== void 0) {
					B(e, ...F(e, r, "program", "r").map((e) => W(e.id)), { ...t });
					break;
				}
				V(e, "smcBattle", n.map((e) => H("space", [{
					op: "sentinelTrade",
					at: e
				}, { ...t }], { at: e })));
			} else V(e, "smcBattle", n.map((e) => H("space", [{
				op: "battleStart",
				at: e,
				flag: !0
			}, { ...t }], { at: e })));
			break;
		}
		case "sentinelTrade": {
			let n = t.at, r = F(e, n, "program", "r"), i = F(e, n, "spark");
			r.length && i.length && V(e, "removeSpark", i.map((e) => H("piece", [W(r[0].id), W(e.id)], {
				piece: e.id,
				at: n
			})));
			break;
		}
		case "smcCleanup":
			B(e, ...e.pieces.filter((t) => typeof t.at == "number" && t.kind === "program" && I(e, t.at).length && (e.config.smc !== "glom" || t.color !== "g") || typeof t.at == "number" && t.kind === "installation" && L(e, t.at, "guardian")).map((e) => e.id).map(W), ...t.flag ? [{
				op: "setStep",
				text: "end"
			}] : []);
			break;
		case "battleStart":
			Lt(e, t.at, t.count ?? 0, t.flag ?? !1);
			break;
		case "battleResult": {
			let t = e.battle, n = t.at, r = t.infect + t.bonus > t.resistance;
			if (e.ghostId !== null && e.pieces[e.ghostId].at === n && N(e) === 2838 && !t.automatic ? (e.ghostHealth -= t.infect + t.bonus - t.resistance, e.ghostHealth <= 0 && B(e, {
				op: "remove",
				id: e.ghostId,
				text: "ghostAllowed"
			})) : r && B(e, ...I(e, n).filter((n) => n.id !== e.ghostId || ![
				2837,
				2838,
				2839
			].includes(N(e)) || N(e) === 2839 && !t.automatic).map((t) => ({
				...W(t.id),
				text: t.id === e.ghostId ? "ghostAllowed" : void 0
			}))), !r) {
				let t = F(e, n, "program", "r");
				e.action?.purple === "r" && t.push(...F(e, n, "program", "p")), t.length && V(e, "infectLoss", t.map((e) => H("piece", [W(e.id)], {
					piece: e.id,
					at: n
				})));
			}
			r && e.action?.pay.some((e) => pe.find((t) => t.id === e)?.key === "emitEMP") && B(e, Bt(e, n)), t.automatic || B(e, { op: "finishAction" });
			break;
		}
		case "spiderEnd":
			B(e, ...e.pieces.filter((t) => typeof t.at == "number" && ["program", "installation"].includes(t.kind) && O(e, t.at).every((t) => I(e, t).length)).map((e) => e.id).map(W));
			break;
		case "glomEnd": {
			let t = j(e, R(e, n.avatars[e.focus]).color).filter((t) => R(e, t).n <= 5 && L(e, t, "spark")).sort((t, n) => R(e, t).n - R(e, n).n);
			t.length && B(e, Fe(F(e, t[0], "spark").map((n) => ({
				op: "enter",
				id: n.id,
				to: A(e, R(e, t[0]).color, R(e, t[0]).n + 1)
			}))));
			break;
		}
		case "jacobEnd":
			B(e, Fe(x.filter((t) => t !== R(e, n.avatars[e.focus]).color).map((e) => ({
				op: "jacobServer",
				color: e
			}))));
			break;
		case "jacobServer":
			B(e, ...[
				2,
				3,
				4,
				5,
				6
			].map((n) => ({
				op: "numericMove",
				at: A(e, t.color, n),
				value: -1,
				ids: F(e, A(e, t.color, n), "spark").map((e) => e.id),
				flag: !1
			})));
			break;
		case "scramblerEnd":
			B(e, ...j(e, De(e)).flatMap((t) => F(e, t, "program").map((e) => ({
				op: "flip",
				id: e.id
			}))));
			break;
		case "accessShutdownEnd": {
			let t = e.pieces.filter((e) => e.kind === "program" && e.color === "r" && typeof e.at == "number").map((e) => e.id);
			B(e, t.length ? {
				op: "chooseRemove",
				ids: t
			} : U("spark", "black", z(e, n), 2));
			break;
		}
		case "waterfallEnd": {
			let t = R(e, n.avatars[e.focus]).color;
			B(e, ...[
				2,
				3,
				4,
				5,
				6
			].map((n) => ({
				op: "waterfallMove",
				at: A(e, t, n),
				ids: F(e, A(e, t, n), "spark").map((e) => e.id)
			})), ...L(e, n.avatars[e.focus], "installation", "y") ? [] : [U("spark", "black", n.avatars[e.focus])]);
			break;
		}
		case "waterfallMove": {
			let n = (t.ids ?? []).filter((n) => e.pieces[n].at === t.at);
			if (!n.length) break;
			let r = R(e, t.at), i = j(e, r.color).filter((t) => R(e, t).n < r.n && !L(e, t, "guardian")).sort((t, n) => R(e, n).n - R(e, t).n);
			i.length && V(e, "moveSpark", n.map((e) => H("piece", [{
				op: "enter",
				id: e,
				to: i[0]
			}, {
				...t,
				ids: n.filter((t) => t !== e)
			}], {
				piece: e,
				at: r.id
			})));
			break;
		}
		case "neutrinoEnd":
			B(e, Fe([
				1,
				2,
				3
			].map((t) => ({
				op: "neutrinoMove",
				at: A(e, n.color, t),
				to: z(e, n)
			}))), G("chooseHome", e.players.filter((e) => r === 1 || e !== n).map((t) => H("decker", [Y([
				1,
				2,
				3
			].map((n) => A(e, t.color, n)))], { rid: t.rid }))));
			break;
		case "neutrinoMove": {
			let n = F(e, t.at, "spark");
			n.length && V(e, "moveSpark", n.map((e) => H("piece", [{
				op: "enter",
				id: e.id,
				to: t.to
			}], {
				piece: e.id,
				at: t.at
			})));
			break;
		}
		case "refreshStart":
			e.step = "refresh", V(e, "refreshMarket", [H("keepMarket", [{ op: "newCycle" }]), H("refreshMarket", [{ op: "shuffleMarket" }, { op: "newCycle" }])]);
			break;
		case "shuffleMarket":
			e.upgradeDeck.push(...Ee(e, e.market)), e.market = [], B(e, { op: "restock" });
			break;
		case "newCycle":
			e.cycle++, B(e, ...e.players.map((e) => ({
				op: "refreshPlayer",
				rid: e.rid
			})), { op: "intelStart" });
			break;
		case "refreshPlayer": {
			let n = M(e, t.rid);
			n.deck = Ee(e, [
				...n.deck,
				...n.hand,
				...n.discard
			]), n.hand = [], n.discard = [], n.turns = 0, e.activity = {
				kind: "refreshDeck",
				at: -1,
				to: -1,
				piece: null,
				color: n.color,
				n: 15,
				owner: n.rid,
				source: "discard:" + n.rid,
				target: "deck:" + n.rid
			}, B(e, {
				op: "draw",
				rid: n.rid,
				count: 5
			});
			break;
		}
		case "repositionSetup": {
			let t = e.tiles[e.tiles.length - 1], n = e.tiles.slice(0, -1), r = be(n, t.color).filter((t) => D([...n, t], e.config.fragmented).some((r) => k({ cells: D([...n, t], e.config.fragmented) }, r.id)));
			r.length && V(e, "repositionTile", r.map((e) => H("tilePosition", [{
				op: "reposition",
				color: e.color,
				at: e.q,
				to: e.r
			}], {
				q: e.q,
				r: e.r,
				color: e.color
			})));
			break;
		}
		case "reposition": {
			let n = e.tiles.find((e) => e.color === t.color);
			n.q = t.at, n.r = t.to, e.cells = D(e.tiles, e.config.fragmented);
			break;
		}
		default: return !1;
	}
	return !0;
}
function Bt(e, t) {
	return G("emitEMP", [H("skip", []), ...O(e, t).map((t) => H("space", F(e, t, "spark").map((e) => W(e.id)), { at: t }))]);
}
function Vt(e) {
	[
		"setup",
		"refresh",
		"intel"
	].includes(e.step) || [
		2836,
		2837,
		2838,
		2839
	].includes(N(e)) && Ct(e).complete && (e.results.some((t) => t.id === N(e)) || e.results.push({
		id: N(e),
		success: !0
	}), je(e));
}
//#endregion
//#region src/games/deckers/specials.ts
function Ht(e, t, n, r, i) {
	return {
		op: "reserveChoice",
		kind: t,
		color: n,
		text: String(r),
		flag: i
	};
}
function Ut(e, t, n, r, i) {
	let a = e.pieces.filter((e) => e.kind === t && (e.color === n || t === "guardian") && (e.at === "supply" || typeof e.at == "number")), o = Le(e, t, n), s = o ? [o, ...a.filter((e) => e.id !== o.id)] : a;
	return G("reservePiece", (i && o ? [o] : s).map((e) => H("piece", [{
		op: "reserve",
		id: e.id,
		color: n,
		text: String(r)
	}], {
		piece: e.id,
		color: n,
		at: typeof e.at == "number" ? e.at : void 0
	})));
}
function Wt(e, t) {
	let n = M(e);
	switch (t.op) {
		case "reserveChoice":
			B(e, Ut(e, t.kind, t.color, t.text, t.flag ?? !1));
			break;
		case "reserve": {
			let n = e.pieces[t.id], r = We(e, n);
			n.captive !== null && Be(e, e.pieces[n.captive], !0), n.captive = null, n.color = t.color, n.at = t.text, e.activity = {
				kind: "store",
				at: -1,
				to: -1,
				piece: n.id,
				color: n.color,
				n: 1,
				pieceKind: n.kind,
				source: r,
				target: t.text
			};
			break;
		}
		case "setupTrojan":
			B(e, ...e.players.map((t) => Ht(e, "program", t.color, "trojan", !1)), Ht(e, "spark", "black", "trojan", !0), Ht(e, "spark", "black", "trojan", !0), { op: "trojanPosition" });
			break;
		case "trojanPosition": {
			let t = R(e, z(e, n)), r = (n) => {
				let r = R(e, n);
				return Math.max(Math.abs(r.q - t.q), Math.abs(r.r - t.r), Math.abs(r.q + r.r - t.q - t.r));
			}, i = e.cells.filter((e) => e.n === 1).map((e) => e.id), a = Math.max(...i.map(r));
			V(e, "trojanDestination", i.filter((e) => r(e) === a).map((e) => H("space", [{
				op: "setTrojan",
				at: e,
				flag: !0
			}], { at: e })));
			break;
		}
		case "setTrojan": {
			let n = e.trojanAt;
			e.trojanAt = t.at, t.flag && (e.trojanStart = t.at), e.activity = {
				kind: "trojan",
				at: n ?? -1,
				to: t.at,
				piece: null,
				color: "y",
				n: 1,
				source: n === null ? "objective" : "trojanSlot:" + n,
				target: "trojan",
				tokens: F(e, "trojan").map((e) => ({
					color: e.color,
					kind: e.kind
				}))
			};
			let r = R(e, t.at), i = F(e, "trojan", "program", r.color);
			r.n === 6 && e.players.some((e) => e.color === r.color) ? B(e, ...i.map((e) => ({
				op: "transfer",
				id: e.id,
				text: "supply"
			})), { op: "checkTrojan" }) : B(e, { op: "checkTrojan" });
			break;
		}
		case "checkTrojan":
			!F(e, "trojan", "program").length && e.trojanAt === e.trojanStart && (e.trojanAt = null, B(e, ...F(e, "trojan").map((e) => ({
				op: "transfer",
				id: e.id,
				text: "supply"
			}))));
			break;
		case "setupHackman":
			B(e, Ht(e, "installation", "y", "ghostReserve", !0), Ht(e, "guardian", "white", "ghostReserve", !0), { op: "setHackman" });
			break;
		case "setHackman":
			e.hackman = F(e, "ghostReserve", "guardian")[0]?.id ?? null;
			break;
		case "hackmanStart":
			e.hackman !== null && B(e, {
				op: "enter",
				id: e.hackman,
				to: Se(e)
			});
			break;
		case "setupGhost": {
			let t = e.pieces.length;
			e.pieces.push({
				id: t,
				kind: "guardian",
				color: "white",
				at: "ghostReserve",
				captive: null
			}), e.ghostId = t, e.ghostHealth = 4 * e.players.length + 4;
			let n = N(e) === 2837 ? A(e, R(e, Se(e)).color, 6) : Se(e);
			B(e, {
				op: "enter",
				id: t,
				to: n
			}, ...N(e) === 2836 ? [Fe(O(e, n).flatMap((t) => F(e, t).map((e) => W(e.id))))] : []);
			break;
		}
		case "ghostDefeated":
			if (N(e) === 2838) break;
			B(e, Ht(e, "program", n.color, "objective", !1), { op: "ghostRespawn" });
			break;
		case "ghostRespawn": {
			let t = e.pieces.find((e) => e.kind === "guardian" && e.id >= 87 && e.at === "supply");
			t && (e.ghostId = t.id, B(e, {
				op: "enter",
				id: t.id,
				to: N(e) === 2837 ? A(e, R(e, Se(e)).color, 6) : Se(e)
			}));
			break;
		}
		case "shellshockRemove":
			if (t.count) {
				let n = e.pieces[e.ghostId];
				V(e, "chooseProgram", O(e, n.at).flatMap((t) => F(e, t, "program").map((e) => e.id)).map((n) => H("piece", [W(n), {
					...t,
					count: t.count - 1
				}], {
					piece: n,
					at: e.pieces[n].at
				})));
			} else B(e, {
				op: "remove",
				id: e.ghostId,
				text: "ghostAllowed"
			}, { op: "finishAction" });
			break;
		case "collectPackets": {
			let n = e.packets.filter((n) => n.at === t.at && (n.type !== "alert" || e.action?.ghost === null || e.action?.ghost === void 0)), r = M(e, t.rid), i = n.filter((t) => ["alert", "tagTeam"].includes(t.type) || t.type === "vulnerability" && P(e) === 0);
			B(e, ...n.map((e) => ({
				op: "collectPacket",
				id: e.id,
				rid: r.rid
			})), Fe(i.map((e) => ({
				op: "packetImmediate",
				id: e.id,
				at: t.at,
				rid: r.rid,
				text: e.type
			}))));
			break;
		}
		case "collectPacket": {
			let n = e.packets[t.id], r = M(e, t.rid), i = n.at;
			n.at = r.rid, r.packets.push(n.id), e.activity = {
				kind: "packet",
				at: typeof i == "number" ? i : -1,
				to: -1,
				piece: n.id,
				color: r.color,
				n: 1,
				packetType: n.type,
				source: "packetSlot:" + i,
				target: "packet:" + n.id,
				owner: r.rid
			};
			break;
		}
		case "packetImmediate": {
			let n = e.packets[t.id], r = M(e, t.rid);
			if (r.packets = r.packets.filter((e) => e !== n.id), n.type === "vulnerability") {
				n.at = "removed", e.activity = {
					kind: "packet",
					at: -1,
					to: -1,
					piece: n.id,
					color: r.color,
					n: 1,
					packetType: n.type,
					source: "packetDock:" + r.rid,
					target: "supply",
					owner: r.rid
				};
				break;
			}
			n.at = Oe(e), e.activity = {
				kind: "packet",
				at: -1,
				to: n.at,
				piece: n.id,
				color: r.color,
				n: 1,
				packetType: n.type,
				source: "packetDock:" + r.rid,
				target: "packet:" + n.id,
				owner: r.rid
			}, n.type === "alert" && B(e, U("spark", P(e) === 2 ? "white" : "black", t.at)), n.type === "tagTeam" && (r.profile = ge.filter((e) => _e[e] === r.color && e !== r.profile)[0], r.avatars = Array.from({ length: r.profile === "twins" ? 2 : 1 }, () => t.at), B(e, {
				op: "profileChanged",
				rid: r.rid
			}, {
				op: "settle",
				at: t.at
			}));
			break;
		}
		case "profileChanged":
			e.activity = {
				kind: "handoff",
				at: -1,
				to: -1,
				piece: null,
				color: n.color,
				n: 1,
				target: "profile:" + t.rid
			};
			break;
		case "exploitCard":
			e.action.enhanced[t.id] = (e.action.enhanced[t.id] ?? "") + "p".repeat(t.count);
			break;
		case "passwordSpaces":
			if (!t.count) break;
			V(e, "passwordSpace", [H("finish", []), ...e.cells.filter((t) => !e.action.password.includes(t.id)).map((e) => H("space", [{
				op: "passwordAdd",
				at: e.id
			}, {
				...t,
				count: t.count - 1
			}], { at: e.id }))], t.rid);
			break;
		case "passwordAdd":
			e.action.password.push(t.at);
			break;
		case "lighthouseInstallation":
			V(e, "chooseInstallation", e.pieces.filter((e) => e.kind === "installation" && typeof e.at == "number").map((n) => H("piece", [Ne(e, "destination", O(e, n.at), (e) => [{
				op: "lighthousePosition",
				id: n.id,
				to: e
			}], void 0, t.rid)], {
				piece: n.id,
				at: n.at
			})), t.rid);
			break;
		case "lighthousePosition":
			e.action.lighthouse = t.id, e.action.lighthouseTo = t.to;
			break;
		default: return !1;
	}
	return !0;
}
function Gt(e, t, n) {
	let r = e.packets[n];
	if (!r || r.at !== t || e.prompt || e.tasks.length) return !1;
	let i = e.reaction?.kind, a = e.action, o = t === e.active;
	switch (r.type) {
		case "interference": return i === "beforeSpawn" && P(e) < 2 || i === "placement" && P(e) > 0;
		case "exploit": return o && i === "payment" && !!a?.pay.length;
		case "password": return o && a?.kind === "move" && ["action", "payment"].includes(i ?? e.phase);
		case "lighthouse": return !!a && e.pieces.some((e) => e.kind === "installation" && typeof e.at == "number");
		case "vulnerability": return o && e.phase === "action" && !a && P(e) > 0;
	}
	return !1;
}
function Kt(e, t, n) {
	if (!Gt(e, t, n)) return !1;
	let r = e.packets[n], i = M(e, t);
	return r.at = r.type === "vulnerability" ? "removed" : "discard", i.packets = i.packets.filter((e) => e !== n), e.activity = {
		kind: "packet",
		at: -1,
		to: -1,
		piece: n,
		color: i.color,
		n: 1,
		packetType: r.type,
		owner: i.rid,
		source: "packetDock:" + i.rid,
		target: "supply"
	}, r.type === "interference" && (e.reaction?.kind === "beforeSpawn" && (e.spawnCount = 0), e.reaction?.kind === "placement" && (e.reaction.resume = [])), r.type === "exploit" && B(e, G("exploitCard", e.action.pay.map((t) => H("card", [{
		op: "exploitCard",
		id: t,
		count: 3 - P(e)
	}], { card: t })), t)), r.type === "password" && B(e, {
		op: "passwordSpaces",
		count: 3 - P(e),
		rid: t
	}), r.type === "lighthouse" && B(e, {
		op: "lighthouseInstallation",
		rid: t
	}), r.type === "vulnerability" && (P(e) === 1 ? (e.marketSize = 5, B(e, { op: "restock" })) : e.searchUpgrade = !0), ke(e, "packet", -1, n, t), !0;
}
//#endregion
//#region src/games/deckers/rules.ts
function qt(e, t, n) {
	let r = {
		config: ae.parse(e),
		seed: n,
		rngCursor: 0,
		players: t.map((e, t) => ({
			rid: e,
			profile: "",
			color: x[t],
			starting: x[t],
			avatars: [],
			hand: [],
			deck: [],
			discard: [],
			turns: 0,
			revealed: [],
			packets: []
		})),
		active: t[0],
		focus: 0,
		storedOrder: [],
		phase: "resolve",
		step: "setup",
		tiles: [],
		cells: [],
		pieces: He(),
		tasks: [],
		prompt: null,
		serial: 0,
		activity: null,
		beatMs: 0,
		action: null,
		battle: null,
		reaction: null,
		objectives: [],
		unused: [],
		cycle: 0,
		results: [],
		objectiveSuccess: null,
		market: [],
		upgradeDeck: [],
		marketSize: 4,
		firstTurn: !0,
		spawnCount: 0,
		spawnServer: null,
		spawnRoll: null,
		packets: [],
		root: {},
		searchUpgrade: !1,
		swarm: null,
		palaceAt: null,
		trojanAt: null,
		trojanStart: null,
		ghostId: null,
		ghostHealth: 0,
		hackman: null,
		won: !1,
		reason: "",
		log: []
	};
	for (let e = 0; e < 3; e++) {
		let t = Ee(r, me.filter((t) => t.level === e && t.id > 2899).map((e) => e.id)), n = [
			3022,
			3111,
			2902
		][e];
		r.config.introductory && (t.splice(t.indexOf(n), 1), t.unshift(n));
		let i = C[r.config.smc].cycles[e];
		r.objectives.push(...t.slice(0, i)), r.unused.push(...t.slice(i));
	}
	return r.config.upgraded !== "none" && r.objectives.push(Ee(r, [
		2836,
		2837,
		2838,
		2839
	])[0]), r.tasks = jt(), Yt(r), {
		state: r,
		fx: []
	};
}
function Jt(e, t) {
	return ft(e, t).length > 0 || M(e, t).packets.some((n) => Gt(e, t, n));
}
function Yt(e) {
	if (e.activity) {
		e.beatMs = 440;
		return;
	}
	for (let t = 0; t < 300; t++) {
		if (e.phase === "done" || e.prompt) return;
		if (e.reaction) {
			let t = e.reaction;
			if (e.players.some((n) => !t.passed.includes(n.rid) && Jt(e, n.rid))) return;
			e.reaction = null, B(e, ...t.resume);
		}
		let t = e.tasks.shift();
		if (!t) return;
		if (!qe(e, t) && !zt(e, t) && !dt(e, t) && !et(e, t) && !kt(e, t) && !Wt(e, t)) throw Error("Unknown Deckers task: " + t.op);
		if (e.step !== "setup" && e.cells.length && Vt(e), e.activity) {
			e.beatMs = 440;
			return;
		}
	}
}
function Xt(e) {
	let t = e.activity;
	if (!t) return [];
	let { cards: n, private: r, ...i } = t;
	return [{
		kind: "network",
		rid: t.owner ?? e.active,
		data: {
			...i,
			...!r && n ? { cards: n } : {}
		},
		...r ? {
			for: [t.owner ?? e.active],
			secret: { cards: n ?? [] }
		} : {}
	}];
}
function Zt(e, t, n) {
	let r = { code: "games.deckers.errAction" };
	if (e.phase === "done") return r;
	let i = structuredClone(e);
	if (i.activity = null, t.type === "tick") return i.prompt || i.reaction && i.players.some((e) => !i.reaction.passed.includes(e.rid) && Jt(i, e.rid)) || !i.tasks.length && !i.reaction ? {
		state: e,
		fx: []
	} : (Yt(i), {
		state: i,
		fx: Xt(i)
	});
	if (!i.players.some((e) => e.rid === n.by)) return r;
	if (t.type === "choose") {
		let e = i.prompt;
		return !e || e.owner !== n.by || e.id !== t.prompt || !e.options[t.option] ? r : (i.prompt = null, B(i, ...e.options[t.option].tasks), Yt(i), {
			state: i,
			fx: Xt(i)
		});
	}
	if (t.type === "interrupt") return pt(i, n.by, t.card, t.target, t.value) ? (Yt(i), {
		state: i,
		fx: Xt(i)
	}) : r;
	if (t.type === "packet") {
		if (!Gt(i, n.by, t.id)) return r;
		let e = i.reaction, a = i.tasks;
		return i.tasks = [], Kt(i, n.by, t.id) ? (i.reaction = null, i.tasks.push(...e ? [{
			op: "resumeReaction",
			reaction: e
		}] : [], ...a), Yt(i), {
			state: i,
			fx: Xt(i)
		}) : r;
	}
	if (t.type === "pass") return !i.reaction || i.reaction.passed.includes(n.by) ? r : (i.reaction.passed.push(n.by), Yt(i), {
		state: i,
		fx: Xt(i)
	});
	if (n.by !== i.active || i.prompt || i.reaction || i.tasks.length) return r;
	if (t.type === "act") {
		if (!st(i, t)) return r;
	} else if (t.type === "move") {
		if (!lt(i, t.to, t.carry)) return r;
	} else if (t.type === "shift") {
		if (!ut(i, t.piece, t.to)) return r;
	} else if (t.type === "ghost") {
		if (i.action?.kind !== "shift" || i.action.ghost === null || !Ge(i, M(i), i.action.avatar).includes(t.to)) return r;
		let e = i.action.at, n = M(i);
		i.action.at = t.to, i.action.ghost = t.to, i.activity = {
			kind: "avatar",
			at: e,
			to: t.to,
			piece: null,
			color: n.color,
			n: 1,
			owner: n.rid,
			profile: n.profile,
			ghost: !0,
			source: "ghostSlot:" + e,
			target: "ghost"
		};
	} else if (t.type === "finish") {
		if (!i.action || ![
			"move",
			"shift",
			"nydamShip"
		].includes(i.action.kind)) return r;
		B(i, { op: "finishAction" });
	} else if (t.type === "endTurn") {
		let e = M(i), n = e.turns === 2 ? 0 : e.profile === "kelly" ? 3 : 1;
		if (i.phase !== "action" || i.action || new Set(t.keep).size !== t.keep.length || t.keep.length > n || t.keep.some((t) => !e.hand.includes(t))) return r;
		Ue(i, e, e.hand.filter((e) => !t.keep.includes(e))), i.phase = "resolve", ke(i, "endTurn"), B(i, { op: "endEffects" });
	} else return r;
	return Yt(i), {
		state: i,
		fx: Xt(i)
	};
}
function Qt(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.prompt;
	return {
		public: de.parse({
			...e,
			busy: e.tasks.length > 0,
			players: e.players.map((e) => ({
				rid: e.rid,
				profile: e.profile,
				color: e.color,
				starting: e.starting,
				avatars: e.avatars,
				discard: e.discard,
				turns: e.turns,
				packets: e.packets,
				handCount: e.hand.length,
				deckCount: e.deck.length
			})),
			upgradeCount: e.upgradeDeck.length,
			prompt: r ? {
				id: r.id,
				owner: r.owner,
				text: r.text
			} : null
		}),
		private: fe.parse({
			hand: n?.hand ?? [],
			options: r?.owner === t ? r.options : [],
			revealed: n?.revealed ?? [],
			root: e.root[t] ?? "",
			starting: n?.profile === "",
			search: e.searchUpgrade && t === e.active ? [...e.upgradeDeck].sort((e, t) => e - t) : [],
			interrupts: n ? ft(e, t) : [],
			usablePackets: n ? n.packets.filter((n) => Gt(e, t, n)) : []
		})
	};
}
var $t = {
	meta: ne,
	saveCompatibility: { version: "1" },
	schemas: {
		action: oe,
		config: ae,
		publicView: de,
		privateView: fe
	},
	setup: qt,
	reduce: Zt,
	viewFor: Qt,
	status: (e) => e.phase === "done" ? {
		phase: "done",
		winner: e.won ? e.players.map((e) => e.rid) : [],
		ranking: e.players.map((e) => e.rid),
		scores: Object.fromEntries(e.players.map((t) => [t.rid, e.results.filter((e) => e.success).length]))
	} : { phase: e.phase },
	nextTickIn: (e) => e.phase !== "done" && !e.prompt && (!e.reaction || !e.players.some((t) => !e.reaction.passed.includes(t.rid) && Jt(e, t.rid))) && (e.tasks.length || e.reaction) ? e.beatMs : null
}, en = {
	name: "games.deckers.name",
	desc: "games.deckers.desc",
	errAction: "games.deckers.errAction",
	selection: "games.deckers.selection",
	network: "games.deckers.network",
	objective: "games.deckers.objective",
	market: "games.deckers.market",
	hand: "games.deckers.hand",
	commands: "games.deckers.commands",
	cost: "games.deckers.cost",
	ability: "games.deckers.ability",
	basic: "games.deckers.basic",
	advanced: "games.deckers.advanced",
	pay: "games.deckers.pay",
	choosePay: "games.deckers.choosePay",
	clear: "games.deckers.clear",
	close: "games.deckers.close",
	inspect: "games.deckers.inspect",
	usePacket: "games.deckers.usePacket",
	act: "games.deckers.act",
	upload: "games.deckers.upload",
	install: "games.deckers.install",
	move: "games.deckers.move",
	shift: "games.deckers.shift",
	modify: "games.deckers.modify",
	infect: "games.deckers.infect",
	upgrade: "games.deckers.upgrade",
	execute: "games.deckers.execute",
	reveal: "games.deckers.reveal",
	leiko: "games.deckers.leiko",
	leikoAction: "games.deckers.leikoAction",
	tokyoAction: "games.deckers.tokyoAction",
	shellshock: "games.deckers.shellshock",
	endTurn: "games.deckers.endTurn",
	finish: "games.deckers.finish",
	finishAction: "games.deckers.finishAction",
	skip: "games.deckers.skip",
	cancel: "games.deckers.cancel",
	confirm: "games.deckers.confirm",
	waiting: "games.deckers.waiting",
	resolving: "games.deckers.resolving",
	turn: "games.deckers.turn",
	cycle: "games.deckers.cycle",
	copper: "games.deckers.copper",
	silver: "games.deckers.silver",
	gold: "games.deckers.gold",
	program: "games.deckers.program",
	installation: "games.deckers.installation",
	spark: "games.deckers.spark",
	guardian: "games.deckers.guardian",
	b: "games.deckers.b",
	g: "games.deckers.g",
	y: "games.deckers.y",
	r: "games.deckers.r",
	p: "games.deckers.p",
	black: "games.deckers.black",
	white: "games.deckers.white",
	spaceName: "games.deckers.spaceName",
	supply: "games.deckers.supply",
	stored: "games.deckers.stored",
	removed: "games.deckers.removed",
	captured: "games.deckers.captured",
	avatar: "games.deckers.avatar",
	ghost: "games.deckers.ghost",
	realAvatar: "games.deckers.realAvatar",
	actingSpace: "games.deckers.actingSpace",
	purpleAs: "games.deckers.purpleAs",
	count: "games.deckers.count",
	points: "games.deckers.points",
	carry: "games.deckers.carry",
	carryNone: "games.deckers.carryNone",
	chooseCarry: "games.deckers.chooseCarry",
	shiftPiece: "games.deckers.shiftPiece",
	storeHere: "games.deckers.storeHere",
	boardHint: "games.deckers.boardHint",
	chooseHand: "games.deckers.chooseHand",
	pass: "games.deckers.pass",
	interrupt: "games.deckers.interrupt",
	reaction: "games.deckers.reaction",
	payment: "games.deckers.payment",
	spawn: "games.deckers.spawn",
	beforeSpawn: "games.deckers.beforeSpawn",
	placement: "games.deckers.placement",
	keepCards: "games.deckers.keepCards",
	none: "games.deckers.none",
	returnOverview: "games.deckers.returnOverview",
	players: "games.deckers.players",
	profile: "games.deckers.profile",
	smc: "games.deckers.smc",
	log: "games.deckers.log",
	packet: "games.deckers.packet",
	packets: "games.deckers.packets",
	introductory: "games.deckers.introductory",
	fragmented: "games.deckers.fragmented",
	upgraded: "games.deckers.upgraded",
	networkSetup: "games.deckers.networkSetup",
	preset: "games.deckers.preset",
	choose: "games.deckers.choose",
	noUpgrade: "games.deckers.noUpgrade",
	victory: "games.deckers.victory",
	loss: "games.deckers.loss",
	report: "games.deckers.report",
	viewBoard: "games.deckers.viewBoard",
	showReport: "games.deckers.showReport",
	success: "games.deckers.success",
	failure: "games.deckers.failure",
	failedObjective: "games.deckers.failedObjective",
	sparkSupply: "games.deckers.sparkSupply",
	guardianSupply: "games.deckers.guardianSupply",
	noSilverObjective: "games.deckers.noSilverObjective",
	chooseProfile: "games.deckers.chooseProfile",
	chooseAvatar: "games.deckers.chooseAvatar",
	startingType: "games.deckers.startingType",
	firstDecker: "games.deckers.firstDecker",
	nextDecker: "games.deckers.nextDecker",
	placeTile: "games.deckers.placeTile",
	tilePosition: "games.deckers.tilePosition",
	repositionTile: "games.deckers.repositionTile",
	chooseOrder: "games.deckers.chooseOrder",
	startOrder: "games.deckers.startOrder",
	endOrder: "games.deckers.endOrder",
	explosionOrder: "games.deckers.explosionOrder",
	capture: "games.deckers.capture",
	angelRedirect: "games.deckers.angelRedirect",
	acceptSpark: "games.deckers.acceptSpark",
	redirectSpark: "games.deckers.redirectSpark",
	choosePiece: "games.deckers.choosePiece",
	piece: "games.deckers.piece",
	space: "games.deckers.space",
	color: "games.deckers.color",
	card: "games.deckers.card",
	decker: "games.deckers.decker",
	chooseProgram: "games.deckers.chooseProgram",
	chooseSpark: "games.deckers.chooseSpark",
	chooseInstallation: "games.deckers.chooseInstallation",
	chooseRemove: "games.deckers.chooseRemove",
	chooseSMC: "games.deckers.chooseSMC",
	placePiece: "games.deckers.placePiece",
	destination: "games.deckers.destination",
	optionalProgram: "games.deckers.optionalProgram",
	installPrograms: "games.deckers.installPrograms",
	knowledgeDeposit: "games.deckers.knowledgeDeposit",
	sacrifice: "games.deckers.sacrifice",
	flashFlood: "games.deckers.flashFlood",
	copyCard: "games.deckers.copyCard",
	resetSpark: "games.deckers.resetSpark",
	rootPosition: "games.deckers.rootPosition",
	flipPiece: "games.deckers.flipPiece",
	hologatePieces: "games.deckers.hologatePieces",
	interceptCards: "games.deckers.interceptCards",
	rebootCards: "games.deckers.rebootCards",
	top: "games.deckers.top",
	bottom: "games.deckers.bottom",
	replaceStarting: "games.deckers.replaceStarting",
	replaceInstallation: "games.deckers.replaceInstallation",
	chooseServer: "games.deckers.chooseServer",
	chooseColor: "games.deckers.chooseColor",
	redistribute: "games.deckers.redistribute",
	reducePenalty: "games.deckers.reducePenalty",
	removePrograms: "games.deckers.removePrograms",
	doubleSwitch: "games.deckers.doubleSwitch",
	buildPalace: "games.deckers.buildPalace",
	installations: "games.deckers.installations",
	palaceDestination: "games.deckers.palaceDestination",
	moveSpark: "games.deckers.moveSpark",
	smcBattle: "games.deckers.smcBattle",
	removeSpark: "games.deckers.removeSpark",
	infectLoss: "games.deckers.infectLoss",
	chooseHome: "games.deckers.chooseHome",
	refreshMarket: "games.deckers.refreshMarket",
	keepMarket: "games.deckers.keepMarket",
	emitEMP: "games.deckers.emitEMP",
	reservePiece: "games.deckers.reservePiece",
	trojanDestination: "games.deckers.trojanDestination",
	passwordSpace: "games.deckers.passwordSpace",
	exploitCard: "games.deckers.exploitCard",
	accept: "games.deckers.accept",
	explosion: "games.deckers.explosion",
	transformation: "games.deckers.transformation",
	battle: "games.deckers.battle",
	palace: "games.deckers.palace",
	trojan: "games.deckers.trojan",
	health: "games.deckers.health",
	progress: "games.deckers.progress",
	archives: "games.deckers.archives",
	hiddenBack: "games.deckers.hiddenBack",
	card_apprentice: "games.deckers.card_apprentice",
	card_infiltrate: "games.deckers.card_infiltrate",
	card_sabotage: "games.deckers.card_sabotage",
	card_dataSteal: "games.deckers.card_dataSteal",
	card_decrypt: "games.deckers.card_decrypt",
	card_dataScan: "games.deckers.card_dataScan",
	card_bypass: "games.deckers.card_bypass",
	card_focus: "games.deckers.card_focus",
	card_memorySteal: "games.deckers.card_memorySteal",
	card_intercept: "games.deckers.card_intercept",
	card_diversion: "games.deckers.card_diversion",
	card_reroute: "games.deckers.card_reroute",
	card_blackHat: "games.deckers.card_blackHat",
	card_deceptionSpike: "games.deckers.card_deceptionSpike",
	card_catalyst: "games.deckers.card_catalyst",
	card_emitEMP: "games.deckers.card_emitEMP",
	card_livewireVoodoo: "games.deckers.card_livewireVoodoo",
	card_sidekick: "games.deckers.card_sidekick",
	card_dataShift: "games.deckers.card_dataShift",
	card_hologate: "games.deckers.card_hologate",
	card_readRequestIntercept: "games.deckers.card_readRequestIntercept",
	card_piedPiper: "games.deckers.card_piedPiper",
	card_nydamShip: "games.deckers.card_nydamShip",
	card_viralSplash: "games.deckers.card_viralSplash",
	card_neuralSplash: "games.deckers.card_neuralSplash",
	card_pingNexus: "games.deckers.card_pingNexus",
	card_exoticSoftware: "games.deckers.card_exoticSoftware",
	card_copycat: "games.deckers.card_copycat",
	card_consoleCowboy: "games.deckers.card_consoleCowboy",
	card_microbionix: "games.deckers.card_microbionix",
	card_nootropicBloom: "games.deckers.card_nootropicBloom",
	card_dniReboot: "games.deckers.card_dniReboot",
	card_digitalTattoo: "games.deckers.card_digitalTattoo",
	card_adrenalinSurge: "games.deckers.card_adrenalinSurge",
	card_rootAccess: "games.deckers.card_rootAccess",
	card_magneticPulse: "games.deckers.card_magneticPulse",
	card_gingerCool: "games.deckers.card_gingerCool",
	card_psionicScatter: "games.deckers.card_psionicScatter",
	card_duality: "games.deckers.card_duality",
	card_replicantJar: "games.deckers.card_replicantJar",
	card_decoyDuck: "games.deckers.card_decoyDuck",
	card_resetSpark: "games.deckers.card_resetSpark",
	card_carbonClone: "games.deckers.card_carbonClone",
	effect_deceptionSpike: "games.deckers.effect_deceptionSpike",
	effect_catalyst: "games.deckers.effect_catalyst",
	effect_emitEMP: "games.deckers.effect_emitEMP",
	effect_livewireVoodoo: "games.deckers.effect_livewireVoodoo",
	effect_sidekick: "games.deckers.effect_sidekick",
	effect_dataShift: "games.deckers.effect_dataShift",
	effect_hologate: "games.deckers.effect_hologate",
	effect_readRequestIntercept: "games.deckers.effect_readRequestIntercept",
	effect_piedPiper: "games.deckers.effect_piedPiper",
	effect_nydamShip: "games.deckers.effect_nydamShip",
	effect_viralSplash: "games.deckers.effect_viralSplash",
	effect_neuralSplash: "games.deckers.effect_neuralSplash",
	effect_pingNexus: "games.deckers.effect_pingNexus",
	effect_exoticSoftware: "games.deckers.effect_exoticSoftware",
	effect_copycat: "games.deckers.effect_copycat",
	effect_consoleCowboy: "games.deckers.effect_consoleCowboy",
	effect_microbionix: "games.deckers.effect_microbionix",
	effect_nootropicBloom: "games.deckers.effect_nootropicBloom",
	effect_dniReboot: "games.deckers.effect_dniReboot",
	effect_digitalTattoo: "games.deckers.effect_digitalTattoo",
	effect_adrenalinSurge: "games.deckers.effect_adrenalinSurge",
	effect_rootAccess: "games.deckers.effect_rootAccess",
	effect_magneticPulse: "games.deckers.effect_magneticPulse",
	effect_gingerCool: "games.deckers.effect_gingerCool",
	effect_psionicScatter: "games.deckers.effect_psionicScatter",
	effect_duality: "games.deckers.effect_duality",
	effect_replicantJar: "games.deckers.effect_replicantJar",
	effect_decoyDuck: "games.deckers.effect_decoyDuck",
	effect_resetSpark: "games.deckers.effect_resetSpark",
	effect_carbonClone: "games.deckers.effect_carbonClone",
	profile_hettie: "games.deckers.profile_hettie",
	profileEffect_hettie: "games.deckers.profileEffect_hettie",
	profile_tokyo: "games.deckers.profile_tokyo",
	profileEffect_tokyo: "games.deckers.profileEffect_tokyo",
	profile_monty: "games.deckers.profile_monty",
	profileEffect_monty: "games.deckers.profileEffect_monty",
	profile_kelly: "games.deckers.profile_kelly",
	profileEffect_kelly: "games.deckers.profileEffect_kelly",
	profile_tilda: "games.deckers.profile_tilda",
	profileEffect_tilda: "games.deckers.profileEffect_tilda",
	profile_twins: "games.deckers.profile_twins",
	profileEffect_twins: "games.deckers.profileEffect_twins",
	profile_oshin: "games.deckers.profile_oshin",
	profileEffect_oshin: "games.deckers.profileEffect_oshin",
	profile_angel: "games.deckers.profile_angel",
	profileEffect_angel: "games.deckers.profileEffect_angel",
	profile_leiko: "games.deckers.profile_leiko",
	profileEffect_leiko: "games.deckers.profileEffect_leiko",
	profile_rupert: "games.deckers.profile_rupert",
	profileEffect_rupert: "games.deckers.profileEffect_rupert",
	objective_3022: "games.deckers.objective_3022",
	goal_3022: "games.deckers.goal_3022",
	objective_3023: "games.deckers.objective_3023",
	goal_3023: "games.deckers.goal_3023",
	objective_3024: "games.deckers.objective_3024",
	goal_3024: "games.deckers.goal_3024",
	objective_3029: "games.deckers.objective_3029",
	goal_3029: "games.deckers.goal_3029",
	objective_3025: "games.deckers.objective_3025",
	goal_3025: "games.deckers.goal_3025",
	objective_3026: "games.deckers.objective_3026",
	goal_3026: "games.deckers.goal_3026",
	objective_3027: "games.deckers.objective_3027",
	goal_3027: "games.deckers.goal_3027",
	objective_3028: "games.deckers.objective_3028",
	goal_3028: "games.deckers.goal_3028",
	objective_3030: "games.deckers.objective_3030",
	goal_3030: "games.deckers.goal_3030",
	objective_3031: "games.deckers.objective_3031",
	goal_3031: "games.deckers.goal_3031",
	objective_3032: "games.deckers.objective_3032",
	goal_3032: "games.deckers.goal_3032",
	objective_3033: "games.deckers.objective_3033",
	goal_3033: "games.deckers.goal_3033",
	objective_3110: "games.deckers.objective_3110",
	goal_3110: "games.deckers.goal_3110",
	objective_3111: "games.deckers.objective_3111",
	goal_3111: "games.deckers.goal_3111",
	objective_3112: "games.deckers.objective_3112",
	goal_3112: "games.deckers.goal_3112",
	objective_3113: "games.deckers.objective_3113",
	goal_3113: "games.deckers.goal_3113",
	objective_3114: "games.deckers.objective_3114",
	goal_3114: "games.deckers.goal_3114",
	objective_3115: "games.deckers.objective_3115",
	goal_3115: "games.deckers.goal_3115",
	objective_3116: "games.deckers.objective_3116",
	goal_3116: "games.deckers.goal_3116",
	objective_3117: "games.deckers.objective_3117",
	goal_3117: "games.deckers.goal_3117",
	objective_3118: "games.deckers.objective_3118",
	goal_3118: "games.deckers.goal_3118",
	objective_3119: "games.deckers.objective_3119",
	goal_3119: "games.deckers.goal_3119",
	objective_3120: "games.deckers.objective_3120",
	goal_3120: "games.deckers.goal_3120",
	objective_3121: "games.deckers.objective_3121",
	goal_3121: "games.deckers.goal_3121",
	objective_2900: "games.deckers.objective_2900",
	goal_2900: "games.deckers.goal_2900",
	objective_2901: "games.deckers.objective_2901",
	goal_2901: "games.deckers.goal_2901",
	objective_2902: "games.deckers.objective_2902",
	goal_2902: "games.deckers.goal_2902",
	objective_2903: "games.deckers.objective_2903",
	goal_2903: "games.deckers.goal_2903",
	objective_2904: "games.deckers.objective_2904",
	goal_2904: "games.deckers.goal_2904",
	objective_2905: "games.deckers.objective_2905",
	goal_2905: "games.deckers.goal_2905",
	objective_2906: "games.deckers.objective_2906",
	goal_2906: "games.deckers.goal_2906",
	objective_2907: "games.deckers.objective_2907",
	goal_2907: "games.deckers.goal_2907",
	objective_2908: "games.deckers.objective_2908",
	goal_2908: "games.deckers.goal_2908",
	objective_2909: "games.deckers.objective_2909",
	goal_2909: "games.deckers.goal_2909",
	objective_2934: "games.deckers.objective_2934",
	goal_2934: "games.deckers.goal_2934",
	objective_2935: "games.deckers.objective_2935",
	goal_2935: "games.deckers.goal_2935",
	objective_2836: "games.deckers.objective_2836",
	goal_2836: "games.deckers.goal_2836",
	objective_2837: "games.deckers.objective_2837",
	goal_2837: "games.deckers.goal_2837",
	objective_2838: "games.deckers.objective_2838",
	goal_2838: "games.deckers.goal_2838",
	objective_2839: "games.deckers.objective_2839",
	goal_2839: "games.deckers.goal_2839",
	back_3022: "games.deckers.back_3022",
	back_3023: "games.deckers.back_3023",
	back_3024: "games.deckers.back_3024",
	back_3029: "games.deckers.back_3029",
	back_3025: "games.deckers.back_3025",
	back_3026: "games.deckers.back_3026",
	back_3027: "games.deckers.back_3027",
	back_3028: "games.deckers.back_3028",
	back_3030: "games.deckers.back_3030",
	back_3031: "games.deckers.back_3031",
	back_3032: "games.deckers.back_3032",
	back_3033: "games.deckers.back_3033",
	back_3110: "games.deckers.back_3110",
	back_3111: "games.deckers.back_3111",
	back_3112: "games.deckers.back_3112",
	back_3113: "games.deckers.back_3113",
	back_3114: "games.deckers.back_3114",
	back_3115: "games.deckers.back_3115",
	back_3116: "games.deckers.back_3116",
	back_3117: "games.deckers.back_3117",
	back_3118: "games.deckers.back_3118",
	back_3119: "games.deckers.back_3119",
	back_3120: "games.deckers.back_3120",
	back_3121: "games.deckers.back_3121",
	back_2900: "games.deckers.back_2900",
	back_2901: "games.deckers.back_2901",
	back_2902: "games.deckers.back_2902",
	back_2903: "games.deckers.back_2903",
	back_2904: "games.deckers.back_2904",
	back_2905: "games.deckers.back_2905",
	back_2906: "games.deckers.back_2906",
	back_2907: "games.deckers.back_2907",
	back_2908: "games.deckers.back_2908",
	back_2909: "games.deckers.back_2909",
	back_2934: "games.deckers.back_2934",
	back_2935: "games.deckers.back_2935",
	back_2836: "games.deckers.back_2836",
	back_2837: "games.deckers.back_2837",
	back_2838: "games.deckers.back_2838",
	back_2839: "games.deckers.back_2839",
	alphaMoby: "games.deckers.alphaMoby",
	smcEffect_alphaMoby: "games.deckers.smcEffect_alphaMoby",
	spider: "games.deckers.spider",
	smcEffect_spider: "games.deckers.smcEffect_spider",
	glom: "games.deckers.glom",
	smcEffect_glom: "games.deckers.smcEffect_glom",
	logi: "games.deckers.logi",
	smcEffect_logi: "games.deckers.smcEffect_logi",
	viking: "games.deckers.viking",
	smcEffect_viking: "games.deckers.smcEffect_viking",
	sentinel: "games.deckers.sentinel",
	smcEffect_sentinel: "games.deckers.smcEffect_sentinel",
	mother: "games.deckers.mother",
	smcEffect_mother: "games.deckers.smcEffect_mother",
	alert: "games.deckers.alert",
	packetEffect_alert: "games.deckers.packetEffect_alert",
	tagTeam: "games.deckers.tagTeam",
	packetEffect_tagTeam: "games.deckers.packetEffect_tagTeam",
	lighthouse: "games.deckers.lighthouse",
	packetEffect_lighthouse: "games.deckers.packetEffect_lighthouse",
	interference: "games.deckers.interference",
	packetEffect_interference: "games.deckers.packetEffect_interference",
	password: "games.deckers.password",
	packetEffect_password: "games.deckers.packetEffect_password",
	exploit: "games.deckers.exploit",
	packetEffect_exploit: "games.deckers.packetEffect_exploit",
	vulnerability: "games.deckers.vulnerability",
	packetEffect_vulnerability: "games.deckers.packetEffect_vulnerability",
	rules: "games.deckers.rules",
	repositionGhost: "games.deckers.repositionGhost",
	adrenalinSurge: "games.deckers.adrenalinSurge"
}, X = (e, t, n) => e(en[t] ?? "games.deckers.selection", n), Z = {
	b: "#25bde6",
	g: "#9bbf23",
	y: "#f5d52d",
	r: "#ed4935",
	p: "#bd50b3",
	black: "#36424b",
	white: "#e2e8e9"
};
function Q({ color: e, kind: t = "program", size: n = 25 }) {
	return /* @__PURE__ */ h("svg", {
		width: n,
		height: n,
		viewBox: "0 0 40 40",
		"aria-hidden": !0,
		className: "deckers-token",
		children: [
			t === "installation" || t === "guardian" ? /* @__PURE__ */ m("rect", {
				x: "2",
				y: "2",
				width: "36",
				height: "36",
				rx: "3",
				fill: Z[e],
				stroke: "#07101a",
				strokeWidth: "3"
			}) : /* @__PURE__ */ m("circle", {
				cx: "20",
				cy: "20",
				r: "18",
				fill: Z[e],
				stroke: "#07101a",
				strokeWidth: "3"
			}),
			t === "installation" || t === "guardian" ? /* @__PURE__ */ m("rect", {
				x: "6",
				y: "6",
				width: "28",
				height: "28",
				rx: "1",
				fill: "#11191d"
			}) : /* @__PURE__ */ m("circle", {
				cx: "20",
				cy: "20",
				r: "14",
				fill: "#11191d"
			}),
			/* @__PURE__ */ m("image", {
				href: `games/deckers/glyph-${e}.svg`,
				x: "6",
				y: "6",
				width: "28",
				height: "28"
			})
		]
	});
}
function tn({ value: e }) {
	return /* @__PURE__ */ m("span", {
		className: "deckers-commands",
		children: [...e].map((e, t) => /* @__PURE__ */ m(Q, { color: e }, t))
	});
}
function nn({ type: e, size: t = 24 }) {
	return /* @__PURE__ */ m("img", {
		src: `games/deckers/packet-${e}.svg`,
		alt: "",
		width: t,
		height: t * 1.4,
		draggable: !1
	});
}
function rn({ tokens: e, width: t = 64, height: n = 40 }) {
	let r = s();
	return /* @__PURE__ */ h("svg", {
		width: t,
		height: n,
		viewBox: "0 0 64 40",
		children: [e.map((e, t) => /* @__PURE__ */ m("svg", {
			x: t * 16,
			y: "0",
			width: "16",
			height: "16",
			children: /* @__PURE__ */ m(Q, {
				kind: e.kind,
				color: e.color,
				size: 16
			})
		}, t)), /* @__PURE__ */ m("text", {
			x: "8",
			y: "34",
			fill: "#fff",
			fontSize: "13",
			children: X(r, "trojan")
		})]
	});
}
function an({ id: e, selected: t, onClick: n, onDetails: r, compact: i = !1, anchor: a = !0 }) {
	let o = s(), c = S[e], { ref: l, hidden: d } = u(a ? `card:${e}` : null);
	return c ? /* @__PURE__ */ h("div", {
		ref: l,
		className: `deckers-card${i ? " is-compact" : ""}${t ? " is-selected" : ""}`,
		style: {
			visibility: d ? "hidden" : void 0,
			"--card-tint": Z[c.commands[0] ?? "b"]
		},
		children: [/* @__PURE__ */ h("button", {
			className: "deckers-card-face",
			onClick: n,
			disabled: !n,
			"aria-pressed": t,
			"aria-label": X(o, "card_" + c.key),
			children: [
				/* @__PURE__ */ m("img", {
					className: "deckers-card-art",
					src: `games/deckers/card-${c.key}.svg`,
					alt: "",
					draggable: !1
				}),
				c.cost && /* @__PURE__ */ m("span", {
					className: "deckers-card-cost",
					title: X(o, "cost"),
					children: /* @__PURE__ */ m(tn, { value: c.cost })
				}),
				/* @__PURE__ */ m("strong", { children: X(o, "card_" + c.key) }),
				/* @__PURE__ */ h("span", {
					className: "deckers-card-body",
					children: [/* @__PURE__ */ m(tn, { value: c.commands }), c.ability && /* @__PURE__ */ m("small", { children: X(o, c.ability === "reveal" ? "reveal" : c.ability === "interrupt" ? "interrupt" : "ability") })]
				})
			]
		}), r && /* @__PURE__ */ m("button", {
			className: "deckers-card-details",
			onClick: r,
			"aria-label": X(o, "inspect") + " · " + X(o, "card_" + c.key),
			children: "ⓘ"
		})]
	}) : null;
}
function $({ name: e, children: t, className: n }) {
	let { ref: r, hidden: i } = u(e);
	return /* @__PURE__ */ m("div", {
		ref: r,
		className: n,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
//#endregion
//#region src/games/deckers/board.tsx
var on = 80, sn = (e, t, n = on, r = 0) => Array.from({ length: 6 }, (i, a) => `${e + n * Math.cos(a * Math.PI / 3 + r)},${t + n * Math.sin(a * Math.PI / 3 + r)}`).join(" ");
function cn(e) {
	let t = e.map((e) => ({
		id: e.id,
		x: 1.5 * on * e.q,
		y: Math.sqrt(3) * on * (e.r + e.q / 2)
	})), n = Math.min(0, ...t.map((e) => e.x)) - on - 8, r = Math.min(0, ...t.map((e) => e.y)) - on - 8;
	return {
		w: Math.max(0, ...t.map((e) => e.x)) - n + on + 8,
		h: Math.max(0, ...t.map((e) => e.y)) - r + on + 8,
		coords: Object.fromEntries(t.map((e) => [e.id, {
			x: e.x - n,
			y: e.y - r
		}]))
	};
}
function ln({ name: e, x: t, y: n, piece: r, size: i = 28, captiveColor: a, selected: o }) {
	let { hidden: s } = u(e);
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m(d, {
		name: e,
		r: {
			x: t,
			y: n,
			w: i,
			h: i
		}
	}), /* @__PURE__ */ h("g", {
		visibility: s ? "hidden" : void 0,
		children: [
			o && /* @__PURE__ */ m("rect", {
				x: t - 2,
				y: n - 2,
				width: i + 4,
				height: i + 4,
				rx: "3",
				fill: "none",
				stroke: "#e4f5ef",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m("svg", {
				x: t,
				y: n,
				width: i,
				height: i,
				children: /* @__PURE__ */ m(Q, {
					color: r.color,
					kind: r.kind,
					size: i
				})
			}),
			r.captive !== null && /* @__PURE__ */ m("circle", {
				cx: t + i * .78,
				cy: n + i * .8,
				r: i * .18,
				fill: Z[a ?? "p"],
				stroke: "#e6eceb",
				strokeWidth: i * .04
			})
		]
	})] });
}
function un({ x: e, y: t }) {
	let { hidden: n } = u("ghost");
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m(d, {
		name: "ghost",
		r: {
			x: e,
			y: t,
			w: 28,
			h: 28
		}
	}), /* @__PURE__ */ m("circle", {
		visibility: n ? "hidden" : void 0,
		cx: e + 14,
		cy: t + 14,
		r: "14",
		fill: "none",
		stroke: "#e3f5ee",
		strokeDasharray: "4 3",
		strokeWidth: "3"
	})] });
}
function dn({ id: e, type: t, x: n, y: r }) {
	let { hidden: i } = u("packet:" + e);
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m(d, {
		name: "packet:" + e,
		r: {
			x: n,
			y: r,
			w: 18,
			h: 25
		}
	}), /* @__PURE__ */ m("image", {
		visibility: i ? "hidden" : void 0,
		href: `games/deckers/packet-${t}.svg`,
		x: n,
		y: r,
		width: "18",
		height: "25"
	})] });
}
function fn({ tokens: e, x: t, y: n }) {
	let { hidden: r } = u("trojan");
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m(d, {
		name: "trojan",
		r: {
			x: t,
			y: n,
			w: 64,
			h: 40
		}
	}), /* @__PURE__ */ m("g", {
		visibility: r ? "hidden" : void 0,
		children: /* @__PURE__ */ m("svg", {
			x: t,
			y: n,
			width: "64",
			height: "40",
			children: /* @__PURE__ */ m(rn, { tokens: e })
		})
	})] });
}
function pn({ name: e, x: t, y: n, w: r, h: i, profile: a, color: o }) {
	let { hidden: s } = u(e);
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m(d, {
		name: e,
		r: {
			x: t,
			y: n,
			w: r,
			h: i
		}
	}), /* @__PURE__ */ h("g", {
		visibility: s ? "hidden" : void 0,
		children: [/* @__PURE__ */ m("rect", {
			x: t - 2,
			y: n - 2,
			width: r + 4,
			height: i + 4,
			rx: "3",
			fill: Z[o],
			stroke: "#e2e8e9",
			strokeWidth: "1.3"
		}), /* @__PURE__ */ m("image", {
			href: `games/deckers/${a}.svg`,
			x: t,
			y: n,
			width: r,
			height: i,
			preserveAspectRatio: "xMidYMid slice"
		})]
	})] });
}
function mn({ pub: e, selected: t, selectedPiece: r, legal: c = [], onCell: l }) {
	let u = s(), p = a(null), [g, _] = o(!1), [ee, te] = o(0);
	n(() => {
		let e = p.current;
		if (!e) return;
		let t = new ResizeObserver(([e]) => _(e.contentRect.height < 300 && e.contentRect.width > e.contentRect.height * 2));
		return t.observe(e), () => t.disconnect();
	}, []);
	let v = i(() => {
		let t = cn(e.cells);
		return g ? {
			w: t.h,
			h: t.w,
			coords: Object.fromEntries(Object.entries(t.coords).map(([e, n]) => [e, {
				x: n.y,
				y: t.w - n.x
			}]))
		} : t;
	}, [e.cells, g]), y = (e, t, n) => sn(e, t, n, g ? Math.PI / 2 : 0), b = e.players.flatMap((e) => e.avatars.map((t, n) => ({
		p: e,
		at: t,
		i: n
	}))).map((e, t) => ({
		...e,
		slot: t
	})), ne = e.cells.map((e) => {
		let t = v.coords[e.id];
		return {
			key: String(e.id),
			rect: {
				x: t.x - on * .72,
				y: t.y - on * .72,
				w: on * 1.44,
				h: on * 1.44
			}
		};
	});
	return /* @__PURE__ */ h("div", {
		ref: p,
		className: "deckers-board",
		children: [/* @__PURE__ */ h(f, {
			sheetW: v.w,
			sheetH: v.h,
			eligible: ne,
			onTapEligible: (e) => l(Number(e)),
			fitKey: ee + ":" + g,
			highlight: "off",
			clampToSheet: !0,
			children: [/* @__PURE__ */ m("defs", { children: /* @__PURE__ */ h("radialGradient", {
				id: "deckers-cell",
				children: [/* @__PURE__ */ m("stop", { stopColor: "#233548" }), /* @__PURE__ */ m("stop", {
					offset: "1",
					stopColor: "#101d2d"
				})]
			}) }), e.cells.map((n) => {
				let { x: i, y: a } = v.coords[n.id], o = e.pieces.filter((e) => e.at === n.id), s = b.filter((e) => e.at === n.id), l = c.includes(n.id), f = g ? Math.min(25, 56 / Math.max(1, Math.ceil(o.length / 4))) : Math.min([
					28,
					25,
					21,
					18
				][Math.max(0, Math.min(3, Math.ceil(o.length / 4) - 1))], 72 / Math.max(1, Math.ceil(o.length / 4))), p = a + (g ? -4 : -8), _ = i + (g ? 31 : 33), ee = a + (g ? 4 : 27), te = i + (g ? -9 : 34), ne = a + (g ? 16 : 30), re = (e) => {
					let t = [...s, ...s.some((t) => t.slot === e) ? [] : b.filter((t) => t.slot === e)].sort((e, t) => e.slot - t.slot), n = t.findIndex((t) => t.slot === e), r = Math.min(g ? 14 : 22, 68 / t.length - 2);
					return {
						x: i + (g ? -34 : -52) + n * (r + 2),
						y: a + (g ? -32 : -55),
						w: r,
						h: r * 34 / 22
					};
				};
				return /* @__PURE__ */ h("g", { children: [
					/* @__PURE__ */ m("title", { children: X(u, "spaceName", {
						color: X(u, n.color),
						n: n.n
					}) }),
					/* @__PURE__ */ m("polygon", {
						points: y(i, a, 79),
						fill: "url(#deckers-cell)",
						stroke: Z[n.color],
						strokeWidth: t === n.id ? 5 : 2
					}),
					/* @__PURE__ */ m("polygon", {
						points: y(i, a, 75),
						fill: Z[n.color],
						opacity: ".035"
					}),
					/* @__PURE__ */ m("path", {
						d: `M${i - 42} ${a + 26}h24l20-26h31`,
						fill: "none",
						stroke: Z[n.color],
						strokeOpacity: ".13"
					}),
					/* @__PURE__ */ m("text", {
						x: i - 53,
						y: a - 28,
						fontSize: "26",
						fontWeight: "800",
						fill: Z[n.color],
						children: n.n
					}),
					o.map((t, n) => /* @__PURE__ */ m(ln, {
						piece: t,
						selected: t.id === r,
						captiveColor: t.captive === null ? void 0 : e.pieces[t.captive].color,
						name: `piece:${t.id}`,
						size: f,
						x: i - 2 * f + n % 4 * f,
						y: p + Math.floor(n / 4) * f
					}, t.id)),
					s.map(({ p: e, i: t, slot: n }) => /* @__PURE__ */ m(pn, {
						name: `avatar:${e.rid}:${t}`,
						...re(n),
						profile: e.profile,
						color: e.color
					}, e.rid + ":" + t)),
					/* @__PURE__ */ m(d, {
						name: `ghostSlot:${n.id}`,
						r: {
							x: _,
							y: ee,
							w: 28,
							h: 28
						}
					}),
					e.action?.ghost === n.id && /* @__PURE__ */ m(un, {
						x: _,
						y: ee
					}),
					/* @__PURE__ */ m(d, {
						name: `packetSlot:${n.id}`,
						r: {
							x: te,
							y: a - 65,
							w: 18,
							h: 25
						}
					}),
					e.packets.filter((e) => e.at === n.id).map((e, t) => /* @__PURE__ */ m(dn, {
						id: e.id,
						type: e.type,
						x: te - t * 18,
						y: a - 65
					}, e.id)),
					/* @__PURE__ */ m(d, {
						name: `trojanSlot:${n.id}`,
						r: {
							x: i - 32,
							y: ne,
							w: 64,
							h: 40
						}
					}),
					e.trojanAt === n.id && /* @__PURE__ */ m(fn, {
						x: i - 32,
						y: ne,
						tokens: e.pieces.filter((e) => e.at === "trojan")
					}),
					e.palaceAt === n.id && /* @__PURE__ */ h("g", { children: [
						/* @__PURE__ */ m(d, {
							name: "palace",
							r: {
								x: i - 30,
								y: a + 30,
								w: 60,
								h: 24
							}
						}),
						/* @__PURE__ */ m("text", {
							x: i - 24,
							y: a + 65,
							fill: "#f5d52d",
							fontSize: "13",
							children: X(u, "palace")
						}),
						e.pieces.filter((e) => e.at === "palace").map((e, t) => /* @__PURE__ */ m("svg", {
							x: i - 26 + t * 18,
							y: a + 30,
							width: "18",
							height: "18",
							children: /* @__PURE__ */ m(Q, {
								kind: e.kind,
								color: e.color,
								size: 18
							})
						}, e.id))
					] }),
					b.map(({ p: e, i: t, slot: r }) => /* @__PURE__ */ m(d, {
						name: `avatarSlot:${e.rid}:${t}:${n.id}`,
						r: re(r)
					}, e.rid + ":" + t)),
					Array.from({ length: 20 }, (e, t) => /* @__PURE__ */ m(d, {
						name: `slot:${n.id}:${t}`,
						r: {
							x: i - 2 * f + t % 4 * f,
							y: p + Math.floor(t / 4) * f,
							w: f,
							h: f
						}
					}, "slot" + t)),
					/* @__PURE__ */ m(d, {
						name: `cell:${n.id}`,
						r: {
							x: i - 20,
							y: a - 20,
							w: 40,
							h: 40
						}
					}),
					l && /* @__PURE__ */ h("g", {
						pointerEvents: "none",
						children: [/* @__PURE__ */ m("polygon", {
							points: y(i, a, 75),
							fill: "#fff",
							fillOpacity: ".08",
							stroke: "#e4f5ef",
							strokeWidth: "5"
						}), /* @__PURE__ */ m("polygon", {
							points: y(i, a, 75),
							fill: "none",
							stroke: "#182a2f",
							strokeWidth: "3",
							strokeDasharray: "14 10",
							children: /* @__PURE__ */ m("animate", {
								attributeName: "stroke-dashoffset",
								from: "0",
								to: "-24",
								dur: ".8s",
								repeatCount: "indefinite"
							})
						})]
					})
				] }, n.id);
			})]
		}), /* @__PURE__ */ m("button", {
			className: "deckers-overview",
			onClick: () => te(ee + 1),
			children: X(u, "returnOverview")
		})]
	});
}
function hn({ pub: e, color: t, q: n, r }) {
	let i = D([...e.tiles.filter((e) => e.color !== t), {
		color: t,
		q: n,
		r
	}], e.config.fragmented), a = cn(i);
	return /* @__PURE__ */ m("svg", {
		className: "deckers-tile-preview",
		viewBox: `0 0 ${a.w} ${a.h}`,
		"aria-hidden": !0,
		children: i.map((e) => {
			let n = a.coords[e.id], r = e.tile === t;
			return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("polygon", {
				points: sn(n.x, n.y, 77),
				fill: r ? Z[e.color] : "#172b3b",
				stroke: r ? "#f1faf7" : Z[e.color],
				strokeWidth: r ? 5 : 2
			}), /* @__PURE__ */ m("text", {
				x: n.x,
				y: n.y + 12,
				textAnchor: "middle",
				fill: r ? "#08121b" : Z[e.color],
				fontSize: "34",
				fontWeight: "700",
				children: e.n
			})] }, e.id);
		})
	});
}
//#endregion
//#region src/games/deckers/legality.ts
function gn(e, t, n) {
	return {
		...e,
		seed: 0,
		rngCursor: 0,
		tasks: e.busy ? [{ op: "pending" }] : [],
		serial: e.prompt?.id ?? 0,
		beatMs: 0,
		players: e.players.map((e) => ({
			...e,
			hand: e.rid === n ? t.hand : [],
			deck: [],
			revealed: e.rid === n ? t.revealed : []
		})),
		prompt: e.prompt ? {
			...e.prompt,
			options: []
		} : null,
		action: e.action ? {
			...e.action,
			used: [],
			bonus: [],
			clone: [],
			enhanced: {},
			extraCommands: "",
			rootBefore: ""
		} : null,
		reaction: e.reaction ? {
			...e.reaction,
			resume: []
		} : null,
		unused: [],
		upgradeDeck: t.search,
		marketSize: 4,
		firstTurn: !1,
		spawnCount: 0,
		spawnServer: null,
		root: { [n]: t.root },
		searchUpgrade: t.search.length > 0,
		trojanStart: null
	};
}
function _n(e) {
	if (!e.action) return [[]];
	let t = e.pieces.filter((t) => t.at === e.action.at && ["program", "spark"].includes(t.kind)).map((e) => e.id), n = [[]], r = (i, a) => {
		if (!(a.length && (at(e, a) && n.push(a), a.length === 4))) for (let e = i; e < t.length; e++) r(e + 1, [...a, t[e]]);
	};
	return r(0, []), n;
}
function vn(e) {
	return !e.action || e.tasks.length ? [] : _n(e).flatMap((t) => e.cells.filter((n) => {
		let r = it(e, n.id, t);
		return r !== null && r <= e.action.points;
	}).map((e) => ({
		type: "move",
		to: e.id,
		carry: t
	})));
}
function yn(e) {
	let t = [], n = (r, i) => {
		if (r === e.length) {
			t.push(i);
			return;
		}
		n(r + 1, i), n(r + 1, [...i, e[r]]);
	};
	return n(0, []), t.sort((e, t) => e.length - t.length || e.reduce((e, t) => e + (S[t].type === "advanced" ? 4 : 0) + S[t].commands.length, 0) - t.reduce((e, t) => e + (S[t].type === "advanced" ? 4 : 0) + S[t].commands.length, 0));
}
function bn(e) {
	if (e.phase !== "action" || e.prompt || e.reaction || e.tasks.length) return [];
	if (e.action) return ["move", "nydamShip"].includes(e.action.kind) ? [...vn(e), { type: "finish" }] : e.action.kind === "shift" ? [
		...ot(e).map((e) => ({
			type: "shift",
			...e
		})),
		...Ge(e, e.players.find((t) => t.rid === e.active), e.action.avatar).filter((t) => t !== e.action.at && e.action.ghost !== null).map((e) => ({
			type: "ghost",
			to: e
		})),
		{ type: "finish" }
	] : [];
	let t = e.players.find((t) => t.rid === e.active), n = yn(t.hand), r = [], i = (i, a) => {
		let o = i.kind === "execute" || i.kind === "reveal" ? [] : n.find((n) => n.length > 0 && Ye(Je(n, e.root[t.rid] ?? "", [], i.kind === "upgrade"), a));
		if (!o) return;
		i = {
			...i,
			pay: o
		};
		let s = structuredClone(e);
		if (!st(s, i)) return;
		let c = s.action?.bonus[0] ?? "";
		(["execute", "reveal"].includes(i.kind) || Ye(Je(o, e.root[t.rid] ?? "", [], i.kind === "upgrade"), c)) && r.push(i);
	};
	for (let n = 0; n < t.avatars.length; n++) for (let r of [-1, ...Ge(e, t, n)]) {
		let a = {
			type: "act",
			kind: "move",
			pay: [],
			avatar: n,
			ghost: r,
			color: "b",
			count: 1,
			card: 0,
			purple: "b"
		};
		for (let n of e.pieces.some((e) => e.kind === "program" && e.color === "p") ? x : ["b"]) {
			let r = {
				...a,
				purple: n
			};
			for (let e of x) i({
				...r,
				kind: "upload",
				color: e
			}, e.repeat(t.profile === "tilda" && e === "y" ? 2 : 3)), i({
				...r,
				kind: "upload",
				color: e
			}, e), i({
				...r,
				kind: "install",
				color: e
			}, e), i({
				...r,
				kind: "modify",
				color: e
			}, "y" + e);
			for (let [e, t] of [
				["move", "b"],
				["shift", "g"],
				["infect", "r"]
			]) for (let n of [
				1,
				2,
				3,
				5,
				8
			]) i({
				...r,
				kind: e,
				count: n
			}, t.repeat(n));
			for (let t of [...e.market, ...e.upgradeDeck]) i({
				...r,
				kind: "upgrade",
				card: t
			}, S[t].cost);
			for (let e of t.hand) for (let t of ["execute", "reveal"]) i({
				...r,
				kind: t,
				card: e
			}, "");
			i({
				...r,
				kind: "leiko"
			}, "pp"), i({
				...r,
				kind: "tokyo"
			}, "bp");
			for (let e of x) i({
				...r,
				kind: "shellshock",
				color: e
			}, "rryyggbb");
		}
	}
	let a = t.turns === 2 ? 0 : t.profile === "kelly" ? 3 : 1;
	return r.push({
		type: "endTurn",
		keep: [...t.hand].sort((e, t) => S[t].commands.length - S[e].commands.length).slice(0, a)
	}), r.filter((e, t, n) => n.findIndex((t) => JSON.stringify(e) === JSON.stringify(t)) === t);
}
//#endregion
//#region src/games/deckers/view-player.tsx
var xn = {
	hand: [],
	options: [],
	revealed: [],
	root: "",
	starting: !1,
	search: [],
	interrupts: [],
	usablePackets: []
}, Sn = [
	"upload",
	"install",
	"move",
	"shift",
	"modify",
	"infect",
	"upgrade"
];
function Cn(e) {
	return /* @__PURE__ */ m(wn, { ...e });
}
function wn({ public: e, private: t, members: n, myRid: r, send: a }) {
	c();
	let u = s(), d = e, f = t ?? xn, [g, _] = o(null), [ee, te] = o([]), [v, y] = o(null), [b, ne] = o(null), [re, ie] = o([]), [ae, oe] = o("b"), [se, ce] = o("b"), [le, ue] = o(1), [de, fe] = o(0), [pe, me] = o(-1), [ge, _e] = o(!1), C = i(() => gn(d, f, r), [
		d,
		f,
		r
	]), w = d.players.find((e) => e.rid === r), ve = d.players.find((e) => e.rid === d.active), T = d.active === r && d.phase === "action" && !d.busy && !d.prompt && !d.reaction, E = ee.filter((e) => f.hand.includes(e)), D = re.filter((e) => d.pieces[e]?.at === d.action?.at), ye = d.prompt?.owner === r, O = d.phase === "done", k = (e) => n.find((t) => t.rid === e)?.name ?? e, A = (e) => {
		let t = d.cells.find((t) => t.id === e);
		return t ? X(u, "spaceName", {
			color: X(u, t.color),
			n: t.n
		}) : X(u, "supply");
	}, j = (e) => te(E.includes(e) ? E.filter((t) => t !== e) : [...E, e]), be = (e, t = 0) => {
		a({
			type: "act",
			kind: e,
			pay: ["execute", "reveal"].includes(e) ? [] : E,
			color: ae,
			count: le,
			card: t,
			avatar: Math.min(de, (w?.avatars.length ?? 1) - 1),
			ghost: pe,
			purple: se
		}), _(null), ne(null);
	}, xe = (e) => {
		ye && (a({
			type: "choose",
			prompt: d.prompt.id,
			option: e
		}), y(null), ne(null));
	}, M = f.options.map((e, t) => ({
		...e,
		index: t
	})), N = d.action?.kind === "shift" && T ? ot(C) : [], P = T && d.action?.kind === "shift" && d.action.ghost !== null ? Ge(C, C.players.find((e) => e.rid === r), d.action.avatar).filter((e) => e !== d.action.at) : [], Se = ge && P.length ? P : ye ? M.flatMap((e) => e.at === void 0 ? [] : [e.at]) : T && d.action ? d.action.kind === "shift" ? N.filter((e) => e.piece === b).map((e) => e.to) : ["move", "nydamShip"].includes(d.action.kind) ? d.cells.filter((e) => {
		let t = it(C, e.id, D);
		return t !== null && t <= d.action.points && at(C, D);
	}).map((e) => e.id) : [] : [], F = (e) => {
		if (ge && P.includes(e)) {
			a({
				type: "ghost",
				to: e
			}), _e(!1), y(null), ne(null);
			return;
		}
		if (ye) {
			let t = M.filter((t) => t.at === e);
			if (t.length === 1) {
				xe(t[0].index);
				return;
			}
		}
		if (T && d.action && Se.includes(e)) {
			d.action.kind === "shift" && b !== null ? a({
				type: "shift",
				piece: b,
				to: e
			}) : ["move", "nydamShip"].includes(d.action.kind) && a({
				type: "move",
				to: e,
				carry: D
			}), y(null);
			return;
		}
		if (y(e), w && !d.action) {
			let t = w.avatars.indexOf(e);
			if (t >= 0) fe(t), me(-1);
			else {
				let t = w.avatars.findIndex((t, n) => Ge(C, C.players.find((e) => e.rid === r), n).includes(e));
				t >= 0 && (fe(t), me(e));
			}
		}
	}, I = d.objectives[d.cycle], L = he[I]?.level ?? 0, R = d.cells.length ? Ct(C) : null, Ce = (e) => /* @__PURE__ */ h(p, { children: [
		e.q !== void 0 && e.r !== void 0 && e.color && /* @__PURE__ */ m(hn, {
			pub: d,
			color: e.color,
			q: e.q,
			r: e.r
		}),
		e.profile && /* @__PURE__ */ m("img", {
			className: "deckers-profile-thumb",
			src: `games/deckers/${e.profile}.svg`,
			alt: ""
		}),
		e.piece !== void 0 && d.pieces[e.piece] && /* @__PURE__ */ m(Q, {
			color: d.pieces[e.piece].color,
			kind: d.pieces[e.piece].kind
		}),
		e.color && /* @__PURE__ */ m(Q, { color: e.color }),
		/* @__PURE__ */ h("span", { children: [e.profile ? X(u, "profile_" + e.profile) : e.rid ? k(e.rid) : e.piece !== void 0 && d.pieces[e.piece] ? X(u, d.pieces[e.piece].kind) : X(u, e.label, e.n === void 0 ? void 0 : { n: e.n }), e.at !== void 0 && /* @__PURE__ */ m("small", { children: A(e.at) })] }),
		e.label === "installations" && e.n !== void 0 && d.pieces[e.n] && /* @__PURE__ */ m(Q, {
			color: d.pieces[e.n].color,
			kind: "installation"
		})
	] }), we = (e) => e.card ? /* @__PURE__ */ m(an, {
		id: e.card,
		onClick: () => xe(e.index),
		onDetails: () => _({
			type: "card",
			id: e.card
		}),
		compact: !0,
		anchor: !1
	}, e.index) : /* @__PURE__ */ m("button", {
		className: "deckers-choice",
		onClick: () => xe(e.index),
		children: Ce(e)
	}, e.index), z = ye ? M.filter((e) => e.at === void 0 || e.at === v) : [], Te = O ? X(u, d.won ? "victory" : "loss") : d.prompt ? ye ? X(u, d.prompt.text) : X(u, "waiting", { name: k(d.prompt.owner) }) : d.reaction ? X(u, "reaction", { kind: X(u, d.reaction.kind) }) : d.busy ? X(u, "resolving") : ve ? X(u, "turn", {
		name: k(ve.rid),
		n: ve.turns + 1
	}) : X(u, "resolving"), Ee = () => d.market.concat(f.search).map((e) => /* @__PURE__ */ m(an, {
		id: e,
		compact: !0,
		onClick: () => _({
			type: "card",
			id: e
		}),
		onDetails: () => _({
			type: "card",
			id: e
		})
	}, e)), De = (e) => /* @__PURE__ */ m("button", {
		onClick: () => e === "upgrade" ? _({ type: "market" }) : be(e),
		disabled: !T || !!d.action,
		children: X(u, e)
	}, e), Oe = v !== null && d.cells.some((e) => e.id === v) && /* @__PURE__ */ h("section", {
		className: "deckers-inspector",
		children: [
			/* @__PURE__ */ h("div", {
				className: "deckers-heading",
				children: [/* @__PURE__ */ m("strong", { children: A(v) }), /* @__PURE__ */ m("button", {
					onClick: () => y(null),
					"aria-label": X(u, "close"),
					children: "×"
				})]
			}),
			d.pieces.filter((e) => e.at === v).map((e) => /* @__PURE__ */ h("button", {
				className: `deckers-choice${b === e.id || D.includes(e.id) ? " is-selected" : ""}`,
				onClick: () => {
					if (T && d.action?.kind === "shift") {
						ne(e.id), y(null);
						return;
					}
					if (T && d.action && ["move", "nydamShip"].includes(d.action.kind) && e.at === d.action.at) {
						let t = D.includes(e.id) ? D.filter((t) => t !== e.id) : [...D, e.id];
						at(C, t) && ie(t);
						return;
					}
					ne(e.id);
				},
				children: [/* @__PURE__ */ m(Q, {
					color: e.color,
					kind: e.kind
				}), /* @__PURE__ */ h("span", { children: [
					X(u, e.color),
					" ",
					X(u, e.kind),
					e.captive !== null && /* @__PURE__ */ h("small", { children: [
						X(u, "captured"),
						": ",
						X(u, d.pieces[e.captive].color),
						" ",
						X(u, "program")
					] })
				] })]
			}, e.id)),
			d.trojanAt === v && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("button", {
				onClick: () => {
					ne(1e6), y(null);
				},
				children: X(u, "trojan")
			}), /* @__PURE__ */ m("div", {
				className: "deckers-stored",
				children: d.pieces.filter((e) => e.at === "trojan").map((e) => /* @__PURE__ */ m(Q, {
					kind: e.kind,
					color: e.color
				}, e.id))
			})] }),
			d.packets.filter((e) => e.at === v).map((e) => /* @__PURE__ */ h("p", { children: [
				/* @__PURE__ */ m(nn, { type: e.type }),
				X(u, e.type),
				" · ",
				X(u, "packetEffect_" + e.type)
			] }, e.id)),
			d.players.flatMap((e) => e.avatars.filter((e) => e === v).map((t, n) => /* @__PURE__ */ h("button", {
				onClick: () => _({
					type: "profile",
					profile: e.profile
				}),
				children: [
					k(e.rid),
					" · ",
					X(u, "profile_" + e.profile)
				]
			}, e.rid + n))),
			T && !d.action && (w?.avatars.includes(v) || pe === v) && /* @__PURE__ */ h("button", {
				className: "is-primary",
				onClick: () => _({ type: "action" }),
				children: [
					X(u, "act"),
					" · ",
					pe < 0 ? X(u, "realAvatar") : X(u, "ghost")
				]
			}),
			T && d.action && ["move", "nydamShip"].includes(d.action.kind) && v === d.action.at && /* @__PURE__ */ m("p", { children: X(u, "chooseCarry") })
		]
	});
	return /* @__PURE__ */ m("div", {
		className: "deckers-screen",
		children: /* @__PURE__ */ h(l, {
			adaptive: !0,
			scroll: !1,
			className: "deckers-shell",
			banner: /* @__PURE__ */ h("header", {
				className: "deckers-header",
				children: [
					/* @__PURE__ */ h("button", {
						className: "deckers-brand",
						onClick: () => _({ type: "smc" }),
						children: [/* @__PURE__ */ m("b", { children: "DECKERS" }), /* @__PURE__ */ m("small", { children: X(u, d.config.smc) })]
					}),
					/* @__PURE__ */ h("button", {
						className: "deckers-objective-link",
						onClick: () => _({
							type: "objective",
							id: I
						}),
						children: [/* @__PURE__ */ h("small", { children: [
							X(u, "cycle", { n: d.cycle + 1 }),
							" · ",
							X(u, [
								"copper",
								"silver",
								"gold"
							][L])
						] }), /* @__PURE__ */ m("b", { children: X(u, "objective_" + I) })]
					}),
					/* @__PURE__ */ h("div", {
						className: "deckers-top-tools",
						children: [/* @__PURE__ */ m($, {
							name: "market",
							children: /* @__PURE__ */ m($, {
								name: "upgradeDeck",
								children: /* @__PURE__ */ m("button", {
									onClick: () => _({ type: "market" }),
									children: X(u, "market")
								})
							})
						}), /* @__PURE__ */ m("button", {
							onClick: () => _({ type: "players" }),
							children: X(u, "players")
						})]
					})
				]
			}),
			actionsHeight: "deckers-bottom-height",
			actions: /* @__PURE__ */ h("div", {
				className: "deckers-bottom",
				children: [/* @__PURE__ */ h("div", {
					className: "deckers-status",
					children: [
						/* @__PURE__ */ h("span", {
							"aria-live": "polite",
							children: [Te, d.action && /* @__PURE__ */ h(p, { children: [
								" · ",
								X(u, d.action.kind === "nydamShip" ? "move" : d.action.kind),
								" · ",
								X(u, "points", { n: d.action.points })
							] })]
						}),
						P.length > 0 && /* @__PURE__ */ m("button", {
							className: ge ? "is-selected" : "",
							onClick: () => {
								_e(!ge), ne(null), y(null);
							},
							children: X(u, ge ? "cancel" : "repositionGhost")
						}),
						N.some((e) => e.piece === b && e.to === -1) && /* @__PURE__ */ m("button", {
							className: "is-primary",
							onClick: () => a({
								type: "shift",
								piece: b,
								to: -1
							}),
							children: X(u, "storeHere")
						}),
						T && d.action && [
							"move",
							"shift",
							"nydamShip"
						].includes(d.action.kind) && /* @__PURE__ */ m("button", {
							onClick: () => {
								a({ type: "finish" }), ie([]), ne(null), _e(!1);
							},
							children: X(u, "finishAction")
						}),
						T && !d.action && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("button", {
							onClick: () => _({ type: "action" }),
							children: X(u, "act")
						}), /* @__PURE__ */ m("button", {
							onClick: () => _({ type: "keep" }),
							children: X(u, "endTurn")
						})] })
					]
				}), /* @__PURE__ */ h("div", {
					className: "deckers-hand",
					"aria-label": X(u, "hand"),
					children: [/* @__PURE__ */ m($, {
						name: `hand:${r}`,
						className: "deckers-hand-anchor"
					}), f.hand.map((e) => /* @__PURE__ */ m(an, {
						id: e,
						selected: E.includes(e),
						onClick: O || !T || d.action ? () => _({
							type: "card",
							id: e
						}) : () => j(e),
						onDetails: () => _({
							type: "card",
							id: e
						})
					}, e))]
				})]
			}),
			children: [
				/* @__PURE__ */ h("div", {
					className: "deckers-main",
					children: [
						/* @__PURE__ */ h("aside", {
							className: "deckers-left",
							children: [
								/* @__PURE__ */ h("div", {
									className: "deckers-objective-panel",
									children: [
										/* @__PURE__ */ m("small", { children: X(u, "objective") }),
										/* @__PURE__ */ m("button", {
											onClick: () => _({
												type: "objective",
												id: I
											}),
											children: /* @__PURE__ */ m("h2", { children: X(u, "objective_" + I) })
										}),
										/* @__PURE__ */ m("p", { children: X(u, "goal_" + I) }),
										R && /* @__PURE__ */ m("p", { children: X(u, "progress", {
											have: R.have,
											need: R.need
										}) }),
										/* @__PURE__ */ m("div", {
											className: "deckers-stored",
											children: (d.storedOrder.length ? d.storedOrder : d.pieces.filter((e) => e.at === "objective").map((e) => e.id)).map((e) => /* @__PURE__ */ m($, {
												name: `piece:${e}`,
												children: /* @__PURE__ */ m(Q, {
													color: d.pieces[e].color,
													kind: d.pieces[e].kind
												})
											}, e))
										})
									]
								}),
								ve?.profile && /* @__PURE__ */ h($, {
									name: `profile:${ve.rid}`,
									className: "deckers-profile-panel",
									children: [/* @__PURE__ */ h("button", {
										onClick: () => _({
											type: "profile",
											profile: ve.profile
										}),
										children: [/* @__PURE__ */ m("img", {
											src: `games/deckers/${ve.profile}.svg`,
											alt: ""
										}), /* @__PURE__ */ m("h3", { children: X(u, "profile_" + ve.profile) })]
									}), /* @__PURE__ */ m("p", { children: X(u, "profileEffect_" + ve.profile) })]
								}),
								/* @__PURE__ */ m("button", {
									onClick: () => _({ type: "supply" }),
									children: X(u, "supply")
								}),
								d.trojanAt === null && /* @__PURE__ */ m($, {
									name: "trojan",
									className: "deckers-stored",
									children: d.pieces.filter((e) => e.at === "trojan").map((e) => /* @__PURE__ */ m(Q, {
										kind: e.kind,
										color: e.color
									}, e.id))
								}),
								/* @__PURE__ */ m($, {
									name: "ghostReserve",
									className: "deckers-stored",
									children: d.pieces.filter((e) => e.at === "ghostReserve").map((e) => /* @__PURE__ */ m(Q, {
										kind: e.kind,
										color: e.color
									}, e.id))
								})
							]
						}),
						/* @__PURE__ */ h($, {
							name: "network",
							className: "deckers-network",
							children: [
								/* @__PURE__ */ m(mn, {
									pub: d,
									selected: v,
									selectedPiece: b,
									legal: Se,
									onCell: F
								}),
								/* @__PURE__ */ m("div", {
									className: "deckers-seat-strip",
									children: d.players.map((e) => /* @__PURE__ */ h($, {
										name: `seat:${e.rid}`,
										children: [/* @__PURE__ */ m($, {
											name: `packetSeat:${e.rid}`,
											children: /* @__PURE__ */ m($, {
												name: `deck:${e.rid}`,
												children: /* @__PURE__ */ h("button", {
													onClick: () => e.profile && _({
														type: "profile",
														profile: e.profile
													}),
													children: [
														k(e.rid),
														" ",
														/* @__PURE__ */ h("small", { children: [
															e.turns,
															"／3 · ",
															e.handCount
														] })
													]
												})
											})
										}), /* @__PURE__ */ m($, {
											name: `discard:${e.rid}`,
											className: "deckers-discard-dock"
										})]
									}, e.rid))
								}),
								/* @__PURE__ */ m($, {
									name: "supply",
									className: "deckers-supply-dock",
									children: /* @__PURE__ */ h("button", {
										onClick: () => _({ type: "supply" }),
										children: [/* @__PURE__ */ m(Q, {
											color: "black",
											size: 20
										}), X(u, "supply")]
									})
								}),
								/* @__PURE__ */ m($, {
									name: "objective",
									className: "deckers-objective-dock",
									children: /* @__PURE__ */ h("button", {
										onClick: () => _({
											type: "objective",
											id: I
										}),
										children: [
											X(u, "stored"),
											" ",
											d.pieces.filter((e) => e.at === "objective").length
										]
									})
								}),
								d.battle && /* @__PURE__ */ h($, {
									name: "battle",
									className: "deckers-battle",
									children: [
										/* @__PURE__ */ m("b", { children: X(u, "infect") }),
										/* @__PURE__ */ m("span", {
											className: "deckers-die red",
											children: d.battle.red
										}),
										/* @__PURE__ */ m("span", { children: d.battle.infect + d.battle.bonus }),
										/* @__PURE__ */ m("span", { children: "／" }),
										/* @__PURE__ */ m("span", {
											className: "deckers-die",
											children: d.battle.black
										}),
										/* @__PURE__ */ m("span", { children: d.battle.resistance })
									]
								}),
								d.ghostId !== null && /* @__PURE__ */ m("span", {
									className: "deckers-health",
									children: d.objectives[d.cycle] === 2838 && X(u, "health", { n: d.ghostHealth })
								}),
								ye ? /* @__PURE__ */ h("div", {
									className: "deckers-decision",
									children: [
										/* @__PURE__ */ h("div", {
											className: "deckers-heading",
											children: [/* @__PURE__ */ m("strong", { children: X(u, d.prompt.text) }), v !== null && /* @__PURE__ */ m("button", {
												onClick: () => y(null),
												"aria-label": X(u, "close"),
												children: "×"
											})]
										}),
										/* @__PURE__ */ m("div", {
											className: "deckers-choice-list",
											children: z.map(we)
										}),
										M.some((e) => e.at !== void 0) && v === null && /* @__PURE__ */ m("p", { children: X(u, "boardHint") })
									]
								}) : Oe,
								d.reaction && !d.reaction.passed.includes(r) && !O && /* @__PURE__ */ h("div", {
									className: "deckers-decision",
									children: [/* @__PURE__ */ m("strong", { children: X(u, "reaction", { kind: X(u, d.reaction.kind) }) }), /* @__PURE__ */ h("div", {
										className: "deckers-choice-list",
										children: [
											f.interrupts.map((e, t) => /* @__PURE__ */ h("button", {
												onClick: () => a({
													type: "interrupt",
													...e
												}),
												children: [
													X(u, "card_" + S[e.card].key),
													" ",
													e.target > 1 ? X(u, "card_" + S[e.target].key) : e.target === 0 ? X(u, "chooseServer") : X(u, "count"),
													" ",
													e.value || ""
												]
											}, t)),
											f.usablePackets.map((e) => /* @__PURE__ */ h("button", {
												onClick: () => a({
													type: "packet",
													id: e
												}),
												children: [/* @__PURE__ */ m(nn, { type: d.packets[e].type }), X(u, d.packets[e].type)]
											}, e)),
											/* @__PURE__ */ m("button", {
												onClick: () => a({ type: "pass" }),
												children: X(u, "pass")
											})
										]
									})]
								})
							]
						}),
						/* @__PURE__ */ h("aside", {
							className: "deckers-right",
							children: [
								/* @__PURE__ */ m("h3", { children: X(u, "market") }),
								/* @__PURE__ */ m($, {
									name: "marketDisplay",
									children: /* @__PURE__ */ m("div", {
										className: "deckers-market",
										children: Ee()
									})
								}),
								/* @__PURE__ */ m("button", {
									onClick: () => _({ type: "log" }),
									children: X(u, "log")
								})
							]
						})
					]
				}),
				g && /* @__PURE__ */ m("div", {
					className: "deckers-modal-backdrop",
					children: /* @__PURE__ */ h("section", {
						className: `deckers-modal${g.type === "market" ? " is-wide" : ""}`,
						role: "dialog",
						"aria-modal": "true",
						children: [/* @__PURE__ */ h("div", {
							className: "deckers-heading",
							children: [/* @__PURE__ */ m("strong", { children: g.type === "card" ? X(u, "card_" + S[g.id].key) : g.type === "objective" ? X(u, "objective_" + g.id) : g.type === "profile" ? X(u, "profile_" + g.profile) : X(u, g.type === "action" ? "act" : g.type === "keep" ? "endTurn" : g.type) }), /* @__PURE__ */ m("button", {
								onClick: () => _(null),
								"aria-label": X(u, "close"),
								children: "×"
							})]
						}), /* @__PURE__ */ h("div", {
							className: "deckers-modal-body",
							children: [
								g.type === "card" && /* @__PURE__ */ h(p, { children: [
									/* @__PURE__ */ m(an, {
										id: g.id,
										anchor: !1
									}),
									/* @__PURE__ */ m("h4", { children: X(u, "commands") }),
									/* @__PURE__ */ m(tn, { value: S[g.id].commands }),
									S[g.id].cost && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("h4", { children: X(u, "cost") }), /* @__PURE__ */ m(tn, { value: S[g.id].cost })] }),
									S[g.id].ability && /* @__PURE__ */ m("p", { children: X(u, "effect_" + S[g.id].key) }),
									T && !d.action && f.hand.includes(g.id) && /* @__PURE__ */ h("div", {
										className: "deckers-choice-list",
										children: [["execute", "both"].includes(S[g.id].ability) && /* @__PURE__ */ m("button", {
											onClick: () => be("execute", g.id),
											children: X(u, "execute")
										}), S[g.id].ability === "reveal" && !f.revealed.includes(g.id) && /* @__PURE__ */ m("button", {
											onClick: () => be("reveal", g.id),
											children: X(u, "reveal")
										})]
									}),
									T && !d.action && (d.market.includes(g.id) || f.search.includes(g.id)) && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(tn, { value: E.map((e) => S[e].commands).join("") + f.root }), /* @__PURE__ */ m("button", {
										className: "is-primary",
										onClick: () => be("upgrade", g.id),
										disabled: !E.length,
										children: X(u, "upgrade")
									})] })
								] }),
								g.type === "objective" && /* @__PURE__ */ h(p, { children: [
									/* @__PURE__ */ m("p", { children: X(u, "goal_" + g.id) }),
									d.results.some((e) => e.id === g.id) ? /* @__PURE__ */ m("p", { children: X(u, "back_" + g.id) }) : /* @__PURE__ */ m("p", {
										className: "deckers-muted",
										children: X(u, "hiddenBack")
									}),
									/* @__PURE__ */ m("h4", { children: X(u, "archives") }),
									d.objectives.map((e, t) => /* @__PURE__ */ h("button", {
										onClick: () => _({
											type: "objective",
											id: e
										}),
										children: [
											X(u, [
												"copper",
												"silver",
												"gold"
											][he[e].level]),
											" · ",
											X(u, "objective_" + e)
										]
									}, t))
								] }),
								g.type === "profile" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("img", {
									className: "deckers-portrait",
									src: `games/deckers/${g.profile}.svg`,
									alt: ""
								}), /* @__PURE__ */ m("p", { children: X(u, "profileEffect_" + g.profile) })] }),
								g.type === "packet" && /* @__PURE__ */ h(p, { children: [
									/* @__PURE__ */ m(nn, { type: d.packets[g.id].type }),
									/* @__PURE__ */ m("h3", { children: X(u, d.packets[g.id].type) }),
									/* @__PURE__ */ m("p", { children: X(u, "packetEffect_" + d.packets[g.id].type) }),
									f.usablePackets.includes(g.id) && /* @__PURE__ */ m("button", {
										className: "is-primary",
										onClick: () => {
											a({
												type: "packet",
												id: g.id
											}), _(null);
										},
										children: X(u, "usePacket")
									})
								] }),
								g.type === "smc" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("h3", { children: X(u, d.config.smc) }), /* @__PURE__ */ m("p", { children: X(u, "smcEffect_" + d.config.smc) })] }),
								g.type === "market" && /* @__PURE__ */ m("div", {
									className: "deckers-market-modal",
									children: Ee()
								}),
								g.type === "players" && d.players.map((e) => /* @__PURE__ */ m($, {
									name: `playerDetail:${e.rid}`,
									children: /* @__PURE__ */ h("button", {
										className: "deckers-choice",
										onClick: () => _({
											type: "profile",
											profile: e.profile
										}),
										children: [e.profile && /* @__PURE__ */ m("img", {
											className: "deckers-profile-thumb",
											src: `games/deckers/${e.profile}.svg`,
											alt: ""
										}), /* @__PURE__ */ h("span", { children: [
											k(e.rid),
											" · ",
											e.profile && X(u, "profile_" + e.profile),
											/* @__PURE__ */ h("small", { children: [
												X(u, "hand"),
												" ",
												e.handCount,
												" · ",
												X(u, "cycle", { n: d.cycle + 1 }),
												" · ",
												e.turns,
												"／3"
											] })
										] })]
									})
								}, e.rid)),
								g.type === "supply" && /* @__PURE__ */ m("div", {
									className: "deckers-supply",
									children: [
										"program",
										"installation",
										"spark",
										"guardian"
									].flatMap((e) => (e === "program" ? [
										["b", "g"],
										["y", "r"],
										["p"]
									] : e === "installation" ? [
										["b"],
										["g"],
										["y"],
										["r"]
									] : [["black", "white"]]).map((t) => /* @__PURE__ */ h("div", { children: [
										t.map((t) => /* @__PURE__ */ m(Q, {
											kind: e,
											color: t
										}, t)),
										t.map((e) => X(u, e)).join("／"),
										" ",
										X(u, e),
										" · ",
										d.pieces.filter((n) => n.at === "supply" && n.kind === e && t.includes(n.color)).length
									] }, e + t.join(""))))
								}),
								g.type === "log" && d.log.map((e, t) => /* @__PURE__ */ h("p", { children: [
									k(e.rid),
									" · ",
									X(u, e.key),
									" ",
									e.at >= 0 ? A(e.at) : "",
									" ",
									e.n || ""
								] }, t)),
								g.type === "keep" && /* @__PURE__ */ h(p, { children: [
									/* @__PURE__ */ m("p", { children: X(u, "keepCards", { n: w?.turns === 2 ? 0 : w?.profile === "kelly" ? 3 : 1 }) }),
									/* @__PURE__ */ m("div", {
										className: "deckers-market-modal",
										children: f.hand.map((e) => /* @__PURE__ */ m(an, {
											id: e,
											selected: E.includes(e),
											anchor: !1,
											onClick: () => j(e),
											compact: !0
										}, e))
									}),
									/* @__PURE__ */ m("button", {
										onClick: () => te([]),
										children: X(u, "clear")
									}),
									/* @__PURE__ */ m("button", {
										className: "is-primary",
										disabled: E.length > (w?.turns === 2 ? 0 : w?.profile === "kelly" ? 3 : 1),
										onClick: () => {
											a({
												type: "endTurn",
												keep: E
											}), _(null), te([]);
										},
										children: X(u, "endTurn")
									})
								] }),
								g.type === "action" && /* @__PURE__ */ h(p, { children: [
									/* @__PURE__ */ h("p", { children: [
										X(u, "actingSpace"),
										": ",
										w && A(pe < 0 ? w.avatars[Math.min(de, w.avatars.length - 1)] : pe)
									] }),
									/* @__PURE__ */ h("div", {
										className: "deckers-choice-list",
										children: [w?.avatars.map((e, t) => /* @__PURE__ */ h("button", {
											className: de === t && pe < 0 ? "is-selected" : "",
											onClick: () => {
												fe(t), me(-1);
											},
											children: [
												X(u, "avatar"),
												" ",
												t + 1,
												" · ",
												A(e)
											]
										}, t)), w && Ge(C, C.players.find((e) => e.rid === r), Math.min(de, w.avatars.length - 1)).map((e) => /* @__PURE__ */ h("button", {
											className: pe === e ? "is-selected" : "",
											onClick: () => me(e),
											children: [
												X(u, "ghost"),
												" · ",
												A(e)
											]
										}, "ghost" + e))]
									}),
									/* @__PURE__ */ m("h4", { children: X(u, "choosePay") }),
									/* @__PURE__ */ m(tn, { value: E.map((e) => S[e].commands).join("") + f.root }),
									/* @__PURE__ */ m("div", {
										className: "deckers-market-modal",
										children: f.hand.map((e) => /* @__PURE__ */ m(an, {
											id: e,
											selected: E.includes(e),
											anchor: !1,
											onClick: () => j(e),
											compact: !0
										}, e))
									}),
									/* @__PURE__ */ m("h4", { children: X(u, "color") }),
									/* @__PURE__ */ m("div", {
										className: "deckers-choice-list",
										children: x.map((e) => /* @__PURE__ */ h("button", {
											className: ae === e ? "is-selected" : "",
											onClick: () => oe(e),
											children: [/* @__PURE__ */ m(Q, { color: e }), X(u, e)]
										}, e))
									}),
									d.pieces.some((e) => e.color === "p" && e.kind === "program" && typeof e.at == "number") && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("h4", { children: X(u, "purpleAs") }), /* @__PURE__ */ m("div", {
										className: "deckers-choice-list",
										children: x.map((e) => /* @__PURE__ */ h("button", {
											onClick: () => ce(e),
											className: se === e ? "is-selected" : "",
											children: [/* @__PURE__ */ m(Q, { color: e }), X(u, e)]
										}, e))
									})] }),
									/* @__PURE__ */ h("label", {
										className: "deckers-amount",
										children: [X(u, "count"), /* @__PURE__ */ m("input", {
											type: "number",
											min: "1",
											max: "40",
											value: le,
											onChange: (e) => ue(Math.max(1, Math.min(40, Number(e.target.value) || 1)))
										})]
									}),
									/* @__PURE__ */ h("div", {
										className: "deckers-choice-list",
										children: [
											Sn.map(De),
											w?.profile === "leiko" && /* @__PURE__ */ m("button", {
												onClick: () => be("leiko"),
												children: X(u, "leikoAction")
											}),
											w?.profile === "tokyo" && /* @__PURE__ */ m("button", {
												onClick: () => be("tokyo"),
												children: X(u, "tokyoAction")
											}),
											I === 2837 && /* @__PURE__ */ m("button", {
												onClick: () => be("shellshock"),
												children: X(u, "shellshock")
											})
										]
									})
								] })
							]
						})]
					})
				}),
				/* @__PURE__ */ m($, {
					name: "packetDock:" + r,
					className: "deckers-packets",
					children: w?.packets.map((e) => /* @__PURE__ */ h("button", {
						onClick: () => _({
							type: "packet",
							id: e
						}),
						children: [/* @__PURE__ */ m($, {
							name: "packet:" + e,
							children: /* @__PURE__ */ m(nn, { type: d.packets[e].type })
						}), X(u, d.packets[e].type)]
					}, e))
				})
			]
		})
	});
}
//#endregion
//#region src/games/deckers/bot.ts
var Tn = {
	objective: 5,
	defense: 2,
	economy: 1,
	travel: 1
}, En = (e) => e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length], Dn = (e) => S[e].commands.length + (S[e].ability ? .7 : 0);
function On(e, t, n) {
	let r = N(e), i = R(e, t), a = e.players.length, o = e.players.some((e) => e.color === i.color);
	switch (r) {
		case 3022: return +(n === M(e).starting);
		case 3023: return o && n === "g" && !L(e, t, "program", "g") ? 2 : 0;
		case 3024: return o && i.n === 1 && !L(e, t, "program", n) ? 2.5 : 0;
		case 3025: return o && n === "r" && !L(e, t, "program", "r") ? 2 : 0;
		case 3028: return i.color === "p" && i.n <= 4 && n === "b" && L(e, t, "program", "b") + L(e, t, "installation", "b") < (i.n <= a ? 2 : 1) ? 2.5 : 0;
		case 3032: return i.n === 6 && n === "y" && !L(e, t, "program", "y") ? 2 : 0;
		case 3033: return +(n === "y");
		case 3111: return i.n % 2 == 1 && n === "g" && !L(e, t, "program", "g") && !L(e, t, "installation", "g") ? 2 : 0;
		case 3115: return i.n === 5 && n === i.color && L(e, t, "program", n) < 2 ? 2.5 : 0;
		case 3116: return O(e, t).length < 6 && n === "r" && !L(e, t, "program", "r") ? 2 : 0;
		case 3119: return o && i.n === 6 && n === "r" && !L(e, t, "program", "r") ? 3 : 0;
		case 3120: return n === i.color && !L(e, t, "program", n) ? i.n * .35 : 0;
		case 2901: return O(e, t).length === 6 && !L(e, t, "program") || o && i.n % 2 == 1 && n === "g" && !L(e, t, "program", "g") ? 2 : 0;
		case 2902:
		case 3121: return n === "b" && !L(e, t, "program", "b") ? 1.5 : 0;
		case 2903: return o && i.n % 2 == 1 && n === "b" && !L(e, t, "program", "b") ? 3 : 0;
		case 2934: return o && i.n === 6 && n === "b" && !L(e, t, "program", "b") ? 2.5 : 0;
		case 2935: return i.n === 2 && !L(e, t, "program", n) ? 2 : 0;
		case 2837: return e.ghostId !== null && typeof e.pieces[e.ghostId].at == "number" && O(e, e.pieces[e.ghostId].at).includes(t) && !L(e, t, "program", n) ? 2 : 0;
		default: return .15;
	}
}
function kn(e, t, n) {
	let r = N(e), i = R(e, t), a = e.players.some((e) => e.color === i.color);
	return r === 3030 && n === "g" && !e.pieces.some((t) => t.kind === "installation" && t.color === "g" && typeof t.at == "number" && R(e, t.at).color === i.color) || r === 3031 && a && !e.pieces.some((t) => t.kind === "installation" && typeof t.at == "number" && R(e, t.at).color === i.color) || r === 3112 && n === "r" && !e.pieces.some((t) => t.kind === "installation" && t.color === "r" && typeof t.at == "number" && R(e, t.at).color === i.color) || r === 3114 && i.color === "p" || r === 3118 && n === "g" && (i.color === "r" || O(e, t).some((t) => R(e, t).color === "r")) ? 3 : r === 2904 && ["g", "r"].includes(n) && e.players.some((e) => e.avatars.includes(t)) ? 4 : .5;
}
function An(e = Tn) {
	return (t, n) => {
		let r = t.public, i = t.private;
		if (!i || r.phase === "done") return null;
		let a = gn(r, i, n.rid), o = a.players.find((e) => e.rid === n.rid);
		if (r.prompt) {
			if (r.prompt.owner !== n.rid || !i.options.length) return null;
			let t = (t) => {
				let n = t.at, i = t.piece === void 0 ? void 0 : a.pieces[t.piece], o = 0;
				return t.profile && (o += t.profile === "hettie" ? 2 : t.profile === "oshin" ? 1.5 : 1), t.card && (o += (r.prompt.text === "sacrifice" ? -1 : 1) * Dn(t.card)), (t.label === "skip" || t.label === "finish") && (o -= .3), t.label === "keepMarket" && (o += 1), i && r.prompt.text === "knowledgeDeposit" && (o -= On(a, i.at, i.color)), i && [
					"chooseSMC",
					"chooseSpark",
					"removeSpark"
				].includes(r.prompt.text) && (o += i.color === "white" ? 2 : 1), t.color && n !== void 0 && (o += On(a, n, t.color) * e.objective), n !== void 0 && (r.prompt.text === "explosionOrder" && (o -= L(a, n, "guardian") * 100), ["destination", "placePiece"].includes(r.prompt.text) && (o -= L(a, n, "guardian") * e.defense + L(a, n, "spark") * .4), r.prompt.text === "placePiece" && t.color && i?.kind === "installation" && (o += kn(a, n, t.color) * e.objective)), t.rid && r.prompt.text === "nextDecker" && (o += r.players.find((e) => e.rid === t.rid)?.handCount ?? 0), o;
			}, o = n.difficulty === "weak" ? crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % i.options.length : i.options.map((e, n) => ({
				i: n,
				v: t(e)
			})).sort((e, t) => t.v - e.v || e.i - t.i)[0].i;
			return { action: {
				type: "choose",
				prompt: r.prompt.id,
				option: o
			} };
		}
		if (r.reaction) {
			if (r.reaction.passed.includes(n.rid)) return null;
			let e = i.interrupts.find((e) => S[e.card].key === "catalyst" && r.battle && r.battle.infect + r.battle.bonus <= r.battle.resistance && r.battle.infect + r.battle.bonus + 2 > r.battle.resistance);
			if (e) return { action: {
				type: "interrupt",
				...e
			} };
			let t = i.usablePackets.find((e) => r.packets[e].type === "exploit");
			return t === void 0 ? { action: { type: "pass" } } : { action: {
				type: "packet",
				id: t
			} };
		}
		if (r.busy || r.active !== n.rid || r.phase !== "action") return null;
		let s = bn(a);
		if (!s.length) return null;
		if (n.difficulty === "weak") return { action: En(s) };
		let c = n.memory ?? {
			signature: "",
			visited: [],
			turnKey: "",
			upgrades: [],
			executed: []
		}, l = r.action ? JSON.stringify([
			o.turns,
			r.cycle,
			r.action.pay,
			r.action.kind
		]) : "", u = l === c.signature ? c.visited : [], d = l === c.signature ? c.moves ?? [] : [], f = (e) => JSON.stringify([
			r.action?.at,
			e.to,
			[...e.carry].sort((e, t) => e - t)
		]), p = r.cycle + ":" + o.turns, m = c.turnKey === p ? c.upgrades : [], h = c.turnKey === p ? c.executed : [], g = (t) => {
			if (t.type === "endTurn") return -1;
			if (t.type === "finish") return -.2;
			if (t.type === "ghost") return -.5;
			if (t.type === "shift") {
				if (t.to === -1) return 30;
				if (t.piece === 1e6) return r.players.map((e) => z(a, a.players.find((t) => t.rid === e.rid))).includes(t.to) ? 8 : 0;
				let n = a.pieces[t.piece], i = n.at;
				return n.kind === "program" ? (On(a, t.to, n.color) - On(a, i, n.color)) * e.objective - (u.includes(t.to) ? 3 : 0) - .2 : (N(a) === 2905 && R(a, i).n <= 2 && R(a, t.to).n > 2 ? 8 : 0) + L(a, t.to, "guardian") * -3 - .8;
			}
			if (t.type === "move") {
				if (d.includes(f(t))) return -100;
				let n = -.5 - (u.includes(t.to) ? 8 : 0);
				for (let r of t.carry) {
					let i = a.pieces[r];
					i.kind === "program" && (n += (On(a, t.to, i.color) - On(a, a.action.at, i.color)) * e.objective);
				}
				let r = a.cells.filter((e) => [
					"b",
					"g",
					"y",
					"r"
				].some((t) => On(a, e.id, t) > 1.5)), i = (e, t) => {
					let n = R(a, e), r = R(a, t);
					return Math.max(Math.abs(n.q - r.q), Math.abs(n.r - r.r), Math.abs(n.q + n.r - r.q - r.r));
				};
				return r.length && (n += (Math.min(...r.map((e) => i(a.action.at, e.id))) - Math.min(...r.map((e) => i(t.to, e.id)))) * e.travel), he[N(a)].level === 2 && [
					2900,
					2902,
					2903,
					2908,
					2909,
					2934
				].includes(N(a)) && (n += (i(a.action.at, z(a, o)) - i(t.to, z(a, o))) * 1.5), n -= L(a, t.to, "spark") * .15, n;
			}
			if (t.type !== "act") return 0;
			let n = t.ghost < 0 ? o.avatars[t.avatar] : t.ghost, i = t.pay.length * .45;
			if (t.kind === "upload") return On(a, n, t.color) * e.objective + 1 - i;
			if (t.kind === "install") return kn(a, n, t.color) * e.objective + .7 - i;
			if (t.kind === "modify") return On(a, n, t.color) * e.objective + L(a, n, "spark") * .8 - i;
			if (t.kind === "infect") {
				let r = L(a, n, "spark") + 4 * L(a, n, "guardian"), o = L(a, n, "program", "r") + 4 * L(a, n, "installation", "r") + t.count;
				return r ? (o - r) * .3 + r * e.defense - i : N(a) === 2838 ? 3 - i : -3;
			}
			return t.kind === "upgrade" && m.includes(t.card) ? -100 : t.kind === "upgrade" ? (Dn(t.card) - Math.min(...t.pay.map(Dn))) * e.economy + 1 + (N(a) === 3022 ? 3 : 0) - i : t.kind === "shellshock" ? 50 : t.kind === "leiko" ? 4 - i : t.kind === "tokyo" ? -3 : (t.kind === "execute" || t.kind === "reveal") && h.includes(t.card) ? -100 : t.kind === "execute" || t.kind === "reveal" ? [
				"sidekick",
				"deceptionSpike",
				"consoleCowboy",
				"resetSpark"
			].includes(S[t.card].key) ? 4 : 1 : t.kind === "move" ? u.length ? -2 : .1 - i * .1 : t.kind === "shift" ? N(a) === 2900 ? 4 : 0 - i * .1 : -2;
		}, _ = s.map((e) => ({
			action: e,
			score: g(e)
		})).sort((e, t) => t.score - e.score)[0].action;
		return {
			action: _,
			memory: {
				signature: l,
				visited: (_.type === "move" ? [
					...u,
					r.action.at,
					_.to
				] : _.type === "shift" ? [...u, _.to] : u).slice(-40),
				moves: _.type === "move" ? [...d, f(_)] : d,
				turnKey: p,
				upgrades: _.type === "act" && _.kind === "upgrade" ? [...m, _.card] : m,
				executed: _.type === "act" && ["execute", "reveal"].includes(_.kind) ? [...h, _.card] : h
			}
		};
	};
}
var jn = An(), Mn = (e, t, n) => {
	if (e.type === "act") return X(n, e.kind) + (e.card ? " · " + X(n, "card_" + S[e.card].key) : "");
	if (e.type === "choose") return X(n, t.public.prompt?.text ?? "selection");
	if (e.type === "move") {
		let r = t.public.cells.find((t) => t.id === e.to);
		return X(n, "move") + " · " + X(n, "spaceName", {
			color: X(n, r.color),
			n: r.n
		});
	}
	return X(n, e.type === "finish" ? "finishAction" : e.type);
};
//#endregion
//#region src/games/deckers/fx.tsx
function Nn({ color: e, kind: t }) {
	let n = a(null);
	return r(() => {
		let e = n.current?.animate([{ transform: "rotateY(0)" }, { transform: "rotateY(180deg)" }], {
			duration: 360,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ h("div", {
		ref: n,
		className: "deckers-flipper",
		children: [/* @__PURE__ */ m("span", { children: /* @__PURE__ */ m(Q, {
			color: {
				b: "g",
				g: "b",
				y: "r",
				r: "y",
				p: "p",
				black: "white",
				white: "black"
			}[e],
			kind: t,
			size: 28
		}) }), /* @__PURE__ */ m("span", {
			style: { transform: "rotateY(180deg)" },
			children: /* @__PURE__ */ m(Q, {
				color: e,
				kind: t,
				size: 28
			})
		})]
	});
}
function Pn({ at: e, ms: t, color: n }) {
	let i = a(null);
	return r(() => {
		let e = i.current?.animate([
			{
				transform: "scale(.6)",
				opacity: 0
			},
			{
				opacity: .9,
				offset: .2
			},
			{
				transform: "scale(1.65)",
				opacity: 0
			}
		], {
			duration: t,
			fill: "both",
			easing: "ease-out"
		});
		return () => e?.cancel();
	}, [t]), /* @__PURE__ */ m("div", {
		ref: i,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			border: "2px solid " + n,
			borderRadius: "50%"
		}
	});
}
function Fn() {
	return /* @__PURE__ */ m("div", {
		className: "deckers-card-back",
		children: /* @__PURE__ */ m("span", { children: "DECKERS" })
	});
}
var In = { network(e, t) {
	let n = e.data;
	if (!n) return null;
	let r = t.anchor(n.source ?? `cell:${n.at}`) ?? t.anchor(`seat:${e.rid}`) ?? t.anchor("supply"), i = t.anchor(n.target ?? (n.piece === null ? `cell:${n.to}` : `piece:${n.piece}`)) ?? t.anchor(`cell:${n.to}`) ?? t.anchor("network");
	if ([
		"discard",
		"draw",
		"acquire",
		"sacrifice",
		"revealCard",
		"returnCards",
		"refreshDeck"
	].includes(n.kind)) {
		let a = n.cards ?? e.secret?.cards ?? [], o = r ?? t.anchor("market"), s = i ?? t.anchor(`seat:${e.rid}`);
		if (!o || !s) return null;
		let c = a.length || Math.min(n.n, 5), l = [], u = [];
		for (let r = 0; r < c; r++) {
			let i = a[r], c = (n.kind === "draw" || n.kind === "acquire") && i ? t.anchor("card:" + i) ?? s : s;
			(n.kind === "draw" || n.kind === "acquire") && i && t.myRid === e.rid && l.push("card:" + i);
			let d = i && n.kind === "revealCard" ? t.anchor("card:" + i) ?? o : o;
			u.push(/* @__PURE__ */ m(_, {
				from: {
					...d,
					w: Math.min(d.w, 95),
					h: Math.min(d.h, 130)
				},
				to: c,
				ms: 290,
				delay: r * 28,
				children: /* @__PURE__ */ m("div", {
					className: "deckers-screen deckers-fx-card",
					children: i ? /* @__PURE__ */ m(an, {
						id: i,
						anchor: !1
					}) : /* @__PURE__ */ m(Fn, {})
				})
			}, r));
		}
		return {
			ms: 440,
			node: u,
			hide: l
		};
	}
	if (n.kind === "avatar") return !r || !i ? null : {
		ms: 440,
		hide: n.target ? [n.target] : [],
		node: /* @__PURE__ */ m(_, {
			from: r,
			to: i,
			ms: 360,
			children: /* @__PURE__ */ m("div", {
				className: "deckers-fx-avatar",
				style: {
					borderColor: n.ghost ? "transparent" : Z[n.color],
					borderWidth: +!n.ghost,
					width: r.w,
					height: r.h
				},
				children: n.ghost ? /* @__PURE__ */ m("svg", {
					viewBox: "0 0 28 28",
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ m("circle", {
						cx: "14",
						cy: "14",
						r: "12",
						fill: "none",
						stroke: "#e3f5ee",
						strokeDasharray: "4 3",
						strokeWidth: "3"
					})
				}) : n.profile ? /* @__PURE__ */ m("img", {
					src: `games/deckers/${n.profile}.svg`,
					alt: ""
				}) : /* @__PURE__ */ m(Q, {
					kind: n.pieceKind ?? "program",
					color: n.color,
					size: r.w
				})
			})
		})
	};
	if (n.kind === "packet") {
		if (!r || !i || !n.packetType) return null;
		let e = {
			...r,
			w: Math.min(r.w, 24),
			h: Math.min(r.w, 24) * 1.4
		};
		return {
			ms: 440,
			hide: n.piece === null ? [] : ["packet:" + n.piece],
			node: /* @__PURE__ */ m(_, {
				from: e,
				to: i,
				ms: 350,
				children: /* @__PURE__ */ m("div", {
					style: {
						width: e.w,
						height: e.h
					},
					children: /* @__PURE__ */ m(nn, {
						type: n.packetType,
						size: e.w
					})
				})
			})
		};
	}
	if (n.kind === "trojan") return !r || !i ? null : {
		ms: 440,
		hide: ["trojan"],
		node: /* @__PURE__ */ m(_, {
			from: r,
			to: i,
			ms: 350,
			children: /* @__PURE__ */ m("div", {
				style: {
					width: r.w,
					height: r.h
				},
				children: /* @__PURE__ */ m(rn, {
					tokens: n.tokens ?? [],
					width: r.w,
					height: r.h
				})
			})
		})
	};
	if (n.kind === "flip") {
		let e = (n.piece === null ? void 0 : t.anchor("piece:" + n.piece)) ?? i;
		return e ? {
			ms: 440,
			hide: ["piece:" + n.piece],
			node: /* @__PURE__ */ m("div", {
				style: {
					position: "absolute",
					left: e.x,
					top: e.y,
					width: 28,
					height: 28,
					perspective: 400,
					transform: `scale(${Math.min(e.w, 28) / 28})`,
					transformOrigin: "top left"
				},
				children: /* @__PURE__ */ m(Nn, {
					color: n.color,
					kind: n.pieceKind ?? "spark"
				})
			})
		} : null;
	}
	if (n.kind === "objective" || n.kind === "handoff") {
		let e = t.anchor(n.target ?? "objective");
		return e ? {
			ms: 440,
			node: /* @__PURE__ */ m(ee, {
				at: e,
				ms: 420
			})
		} : null;
	}
	if (n.kind === "dice" || n.kind === "spawnRoll") {
		let e = t.anchor(n.kind === "dice" ? "battle" : `cell:${n.at}`) ?? i;
		return e ? {
			ms: 440,
			node: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Pn, {
				at: e,
				ms: 380,
				color: Z[n.color]
			}), /* @__PURE__ */ m(g, {
				at: e,
				ms: 420,
				children: /* @__PURE__ */ m("span", {
					className: "deckers-fx-die",
					style: { background: Z[n.color] },
					children: n.kind === "spawnRoll" ? n.n : n.n > 0 ? "+" + n.n : n.n
				})
			})] })
		} : null;
	}
	if (n.kind === "explode") {
		let e = t.anchor(`cell:${n.at}`);
		return e ? {
			ms: 440,
			node: /* @__PURE__ */ m(Pn, {
				at: {
					x: e.x - 22,
					y: e.y - 22,
					w: e.w + 44,
					h: e.h + 44
				},
				ms: 420,
				color: Z[n.color]
			})
		} : null;
	}
	if (!r || !i) return null;
	let a = n.kind === "capture" ? {
		x: i.x + i.w / 4,
		y: i.y + i.h / 4,
		w: i.w / 2,
		h: i.h / 2
	} : i, o = Math.min(r.w, 28), s = {
		...r,
		w: o,
		h: o
	};
	return {
		ms: 440,
		hide: [
			"place",
			"move",
			"store"
		].includes(n.kind) && n.piece !== null ? ["piece:" + n.piece] : [],
		node: /* @__PURE__ */ m(_, {
			from: s,
			to: a,
			ms: 350,
			children: /* @__PURE__ */ m("div", {
				style: {
					width: o,
					height: o
				},
				children: /* @__PURE__ */ m(Q, {
					color: n.color,
					kind: n.pieceKind ?? "program",
					size: o
				})
			})
		})
	};
} };
//#endregion
//#region src/games/deckers/game-over.tsx
function Ln(e) {
	let t = s(), n = e.public, [r, i] = o(!0), [a, c] = o(null), l = (t) => e.members.find((e) => e.rid === t)?.name ?? t;
	return /* @__PURE__ */ h("div", {
		className: "deckers-ending deckers-screen",
		children: [
			/* @__PURE__ */ m(te, {}),
			/* @__PURE__ */ m(wn, {
				public: e.public,
				private: e.private,
				members: e.members,
				myRid: e.myRid,
				send: () => {}
			}),
			r ? /* @__PURE__ */ m("div", {
				className: "deckers-ending-backdrop",
				children: /* @__PURE__ */ h("section", {
					className: "deckers-report",
					role: "dialog",
					"aria-modal": "true",
					children: [
						/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ h("small", { children: ["DECKERS / ", X(t, "report")] }), /* @__PURE__ */ m("h1", { children: X(t, n.won ? "victory" : "loss") })] }), /* @__PURE__ */ m("button", {
							onClick: () => i(!1),
							"aria-label": X(t, "viewBoard"),
							children: "⌄"
						})] }),
						/* @__PURE__ */ h("div", {
							className: "deckers-report-content",
							children: [
								!n.won && /* @__PURE__ */ m("p", { children: X(t, n.reason) }),
								e.hintCount !== void 0 && /* @__PURE__ */ m("p", { children: t("session.hint.usedCount", { n: e.hintCount }) }),
								/* @__PURE__ */ m("ol", { children: n.results.map((e, n) => /* @__PURE__ */ h("li", { children: [
									/* @__PURE__ */ m("span", { children: X(t, "cycle", { n: n + 1 }) }),
									/* @__PURE__ */ m("strong", { children: X(t, "objective_" + e.id) }),
									/* @__PURE__ */ m("b", {
										className: e.success ? "is-success" : "is-failure",
										children: X(t, e.success ? "success" : "failure")
									})
								] }, n)) }),
								/* @__PURE__ */ m("div", {
									className: "deckers-team",
									children: n.players.map((n) => /* @__PURE__ */ h("article", { children: [/* @__PURE__ */ m("img", {
										src: `games/deckers/${n.profile}.svg`,
										alt: ""
									}), /* @__PURE__ */ h("div", { children: [
										/* @__PURE__ */ m("b", { children: l(n.rid) }),
										/* @__PURE__ */ m("small", { children: X(t, "profile_" + n.profile) }),
										(e.result.autopilot?.[n.rid] ?? 0) > 0 && /* @__PURE__ */ m("small", { children: t("session.autopilot.share", { n: Math.round(e.result.autopilot[n.rid] * 100) }) })
									] })] }, n.rid))
								})
							]
						}),
						/* @__PURE__ */ m("footer", { children: a ? /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ h("p", { children: [t(a === "again" ? "session.result.playAgain" : "session.result.backToLobby"), "？"] }),
							/* @__PURE__ */ m("button", {
								onClick: () => c(null),
								children: X(t, "cancel")
							}),
							/* @__PURE__ */ m("button", {
								className: "is-primary",
								onClick: () => {
									a === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.();
								},
								children: X(t, "confirm")
							})
						] }) : e.onPlayAgain || e.onBackToLobby ? /* @__PURE__ */ h(p, { children: [e.onPlayAgain && /* @__PURE__ */ m("button", {
							className: "is-primary",
							onClick: () => c("again"),
							children: t("session.result.playAgain")
						}), e.onBackToLobby && /* @__PURE__ */ m("button", {
							onClick: () => c("lobby"),
							children: t("session.result.backToLobby")
						})] }) : /* @__PURE__ */ m("p", { children: t("session.result.waitHost") }) })
					]
				})
			}) : /* @__PURE__ */ m("button", {
				className: "deckers-show-report",
				onClick: () => i(!0),
				children: X(t, "showReport")
			})
		]
	});
}
//#endregion
//#region src/games/deckers/options.tsx
function Rn({ value: e, onChange: t }) {
	let n = s(), r = ae.safeParse(e), i = r.success ? r.data : ae.parse(void 0);
	return /* @__PURE__ */ h("div", { children: [
		/* @__PURE__ */ m(y, {
			title: X(n, "smc"),
			children: Object.keys(C).map((e) => /* @__PURE__ */ m(v, {
				name: "deckers-smc",
				value: e,
				checked: i.smc === e,
				label: X(n, e),
				onChange: () => t({
					...i,
					smc: e
				})
			}, e))
		}),
		/* @__PURE__ */ m(b, {
			checked: i.introductory,
			label: X(n, "introductory"),
			onChange: () => t({
				...i,
				introductory: !i.introductory
			})
		}),
		/* @__PURE__ */ m(b, {
			checked: i.fragmented,
			label: X(n, "fragmented"),
			onChange: () => t({
				...i,
				fragmented: !i.fragmented
			})
		}),
		/* @__PURE__ */ m(b, {
			checked: i.packets,
			label: X(n, "packets"),
			onChange: () => t({
				...i,
				packets: !i.packets
			})
		}),
		/* @__PURE__ */ m(y, {
			title: X(n, "upgraded"),
			children: [
				"none",
				"2.0",
				"2.1"
			].map((e) => /* @__PURE__ */ m(v, {
				name: "deckers-upgraded",
				value: e,
				checked: i.upgraded === e,
				label: e === "none" ? X(n, "noUpgrade") : e,
				onChange: () => t({
					...i,
					upgraded: e
				})
			}, e))
		}),
		/* @__PURE__ */ m(y, {
			title: X(n, "networkSetup"),
			children: ["preset", "choose"].map((e) => /* @__PURE__ */ m(v, {
				name: "deckers-network",
				value: e,
				checked: i.network === e,
				label: X(n, e),
				onChange: () => t({
					...i,
					network: e
				})
			}, e))
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/deckers/entry.tsx
var zn = {
	definition: $t,
	View: Cn,
	bot: jn,
	describe: Mn,
	fx: In,
	OverView: Ln,
	Options: Rn,
	locales: {
		zh: {
			name: "骇客潜行",
			desc: "合作潜入网络，以指令、程序与装置对抗系统防御。",
			errAction: "当前无法执行此操作。",
			selection: "请选择",
			network: "网络",
			objective: "目标",
			market: "升级区",
			hand: "手牌",
			commands: "指令",
			cost: "升级费用",
			ability: "能力",
			basic: "基础牌",
			advanced: "高级牌",
			pay: "使用所选手牌",
			choosePay: "选择用于支付的手牌",
			clear: "清除选择",
			close: "关闭",
			inspect: "查看详情",
			usePacket: "使用数据包",
			act: "行动",
			upload: "上传程序",
			install: "安装装置",
			move: "移动",
			shift: "推移",
			modify: "改写",
			infect: "感染",
			upgrade: "升级",
			execute: "执行",
			reveal: "揭示",
			leiko: "莱科",
			leikoAction: "莱科的能力",
			tokyoAction: "东京的能力",
			shellshock: "震荡",
			endTurn: "结束回合",
			finish: "完成",
			finishAction: "结束行动",
			skip: "跳过",
			cancel: "取消",
			confirm: "确认",
			waiting: "等待 {{name}}",
			resolving: "结算中",
			turn: "{{name}} · 第 {{n}}／3 回合",
			cycle: "周期 {{n}}",
			copper: "铜色",
			silver: "银色",
			gold: "金色",
			program: "程序",
			installation: "装置",
			spark: "火花",
			guardian: "守卫",
			b: "蓝色",
			g: "绿色",
			y: "黄色",
			r: "红色",
			p: "紫色",
			black: "黑色",
			white: "白色",
			spaceName: "{{color}} {{n}} 号格",
			supply: "供应",
			stored: "已存入",
			removed: "已移除",
			captured: "已捕获",
			avatar: "分身",
			ghost: "幽灵",
			realAvatar: "实体分身",
			actingSpace: "行动格",
			purpleAs: "紫色程序视为",
			count: "数量／行动点",
			points: "剩余 {{n}} 点",
			carry: "携带",
			carryNone: "不携带棋件",
			chooseCarry: "选择携带的棋件",
			shiftPiece: "选择要推移的棋件",
			storeHere: "存入目标",
			boardHint: "在网络上选择目标",
			chooseHand: "选择手牌，或查看高级牌能力",
			pass: "放弃响应",
			interrupt: "中断",
			reaction: "响应：{{kind}}",
			payment: "支付",
			spawn: "生成",
			beforeSpawn: "生成前",
			placement: "放置火花",
			keepCards: "选择保留的手牌（最多 {{n}} 张）",
			none: "无",
			returnOverview: "回到全景",
			players: "骇客",
			profile: "角色",
			smc: "系统主控",
			log: "行动记录",
			packet: "数据包",
			packets: "数据包变体",
			introductory: "入门设置",
			fragmented: "碎片化服务器",
			upgraded: "升级版系统主控",
			networkSetup: "网络布局",
			preset: "预设布局",
			choose: "自行拼接",
			noUpgrade: "基础版",
			victory: "入侵成功",
			loss: "入侵失败",
			report: "入侵报告",
			viewBoard: "回看网络",
			showReport: "查看入侵报告",
			success: "成功",
			failure: "失败",
			failedObjective: "未完成最终目标。",
			sparkSupply: "必须放置的火花供应不足。",
			guardianSupply: "必须放置的守卫供应不足。",
			noSilverObjective: "没有可用于重启周期的银色目标。",
			chooseProfile: "选择角色",
			chooseAvatar: "选择当前分身",
			startingType: "选择初始程序颜色",
			firstDecker: "选择本周期的首位骇客",
			nextDecker: "选择下一位行动的骇客",
			placeTile: "放置服务器板块",
			tilePosition: "板块位置",
			repositionTile: "重新放置板块",
			chooseOrder: "选择下一项结算",
			startOrder: "选择回合开始效果",
			endOrder: "选择回合结束效果",
			explosionOrder: "选择爆炸扩散的下一格",
			capture: "选择要捕获的程序",
			angelRedirect: "是否将火花转向相邻格？",
			acceptSpark: "在此放置",
			redirectSpark: "转向此格",
			choosePiece: "选择棋件",
			piece: "棋件",
			space: "格子",
			color: "颜色",
			card: "卡牌",
			decker: "骇客",
			chooseProgram: "选择程序",
			chooseSpark: "选择火花",
			chooseInstallation: "选择装置",
			chooseRemove: "选择要移除的棋件",
			chooseSMC: "选择防御棋件",
			placePiece: "选择颜色与放置位置",
			destination: "选择目的格",
			optionalProgram: "是否在此放置黄色程序？",
			installPrograms: "选择用于安装的程序",
			knowledgeDeposit: "存入一枚本人初始颜色的程序",
			sacrifice: "选择要牺牲的支付牌",
			flashFlood: "是否存入一枚网络中的蓝色程序？",
			copyCard: "选择要复制执行能力的手牌",
			resetSpark: "移除所有火花，或将一枚守卫替换为同色火花",
			rootPosition: "将查看的牌放在牌库顶或底",
			flipPiece: "选择要翻面的棋件",
			hologatePieces: "选择一起传送的程序和火花，完成后选择目的格",
			interceptCards: "选择放至牌库底的其他手牌",
			rebootCards: "选择放至升级牌堆底的牌",
			top: "牌库顶",
			bottom: "牌库底",
			replaceStarting: "是否替换入口处的一枚程序？",
			replaceInstallation: "选择替换装置的颜色",
			chooseServer: "选择服务器",
			chooseColor: "选择颜色",
			redistribute: "选择要重新放回网络的棋件",
			reducePenalty: "移除存入的程序以减少惩罚",
			removePrograms: "移除 {{n}} 枚程序",
			doubleSwitch: "可将任意 4 号格火花逐枚替换为绿色程序",
			buildPalace: "选择紫色服务器上的两枚装置",
			installations: "两枚装置",
			palaceDestination: "选择宫殿所在的 3 号格",
			moveSpark: "选择下一枚移动的火花",
			smcBattle: "选择系统反击的格子",
			removeSpark: "选择要移除的火花",
			infectLoss: "感染失败，选择移除一枚红色程序",
			chooseHome: "选择另一个玩家的主服务器",
			refreshMarket: "是否更换全部升级牌？",
			keepMarket: "保留升级区",
			emitEMP: "可移除一格相邻格中的所有火花",
			reservePiece: "选择预留棋件",
			trojanDestination: "选择木马起点",
			passwordSpace: "选择视为存在蓝色程序的格子",
			exploitCard: "选择获得额外指令的支付牌",
			accept: "接受",
			explosion: "爆炸",
			transformation: "转化为守卫",
			battle: "感染结算",
			palace: "骇客宫殿",
			trojan: "木马",
			health: "生命值 {{n}}",
			progress: "进度 {{have}}／{{need}}",
			archives: "周期目标",
			hiddenBack: "完成系统反击后揭示结果",
			card_apprentice: "学徒",
			card_infiltrate: "渗透",
			card_sabotage: "破坏",
			card_dataSteal: "窃取数据",
			card_decrypt: "解密",
			card_dataScan: "数据扫描",
			card_bypass: "绕过",
			card_focus: "专注",
			card_memorySteal: "窃取内存",
			card_intercept: "拦截",
			card_diversion: "转移注意",
			card_reroute: "改道",
			card_blackHat: "黑帽",
			card_deceptionSpike: "欺骗尖刺",
			card_catalyst: "催化剂",
			card_emitEMP: "电磁脉冲",
			card_livewireVoodoo: "通电巫术",
			card_sidekick: "搭档",
			card_dataShift: "数据迁移",
			card_hologate: "全息门",
			card_readRequestIntercept: "读取请求拦截",
			card_piedPiper: "吹笛人",
			card_nydamShip: "奈达姆之舟",
			card_viralSplash: "病毒飞溅",
			card_neuralSplash: "神经飞溅",
			card_pingNexus: "连接枢纽",
			card_exoticSoftware: "异域软件",
			card_copycat: "模仿者",
			card_consoleCowboy: "控制台牛仔",
			card_microbionix: "微生物机械",
			card_nootropicBloom: "益智绽放",
			card_dniReboot: "DNI 重启",
			card_digitalTattoo: "数字纹身",
			card_adrenalinSurge: "肾上腺素激增",
			card_rootAccess: "根权限",
			card_magneticPulse: "磁脉冲",
			card_gingerCool: "冷静姜",
			card_psionicScatter: "灵能散射",
			card_duality: "两面性",
			card_replicantJar: "复制罐",
			card_decoyDuck: "诱饵鸭",
			card_resetSpark: "重置火花",
			card_carbonClone: "碳素复制",
			effect_deceptionSpike: "移除行动格中的一枚火花。随后可在该格放置一枚黄色程序。",
			effect_catalyst: "任意骇客感染行动掷骰后，中断并弃置本牌，使感染值增加 2。",
			effect_emitEMP: "用于支付成功的感染行动后，可移除一个相邻格中的所有火花。",
			effect_livewireVoodoo: "将当前服务器上的至多三枚火花翻面。",
			effect_sidekick: "移除行动格或一个相邻格中的一枚火花。",
			effect_dataShift: "将相邻格中的至多三枚程序移至行动格。",
			effect_hologate: "将你的实体分身，以及行动格中任意数量的程序和火花，传送至网络上的另一个格子。这不属于移动行动。",
			effect_readRequestIntercept: "将本牌与至多两张其他手牌放至本人牌库底，然后抽取相同数量的牌。",
			effect_piedPiper: "将网络中的一枚程序移至行动格。",
			effect_nydamShip: "从一个开放格移动至网络上的任意其他开放格。属于移动行动，可以携带棋件。",
			effect_viralSplash: "在行动格放置两枚黑色火花，然后在至多三个不同的开放格中各放置一枚红色程序。",
			effect_neuralSplash: "在行动格放置两枚黑色火花，然后在至多三个不同的开放格中各放置一枚绿色程序。",
			effect_pingNexus: "执行：移除网络中的一枚装置，在其原格放置至多三枚同色程序。中断：为另一位骇客的行动提供一枚紫色指令。",
			effect_exoticSoftware: "移除行动格中的两枚程序，然后在该格放置一枚任意基础颜色的装置。",
			effect_copycat: "揭示本牌及另一张手牌，执行另一张牌的执行能力，两张牌均不弃置。本牌每回合只能揭示一次。",
			effect_consoleCowboy: "移除行动格中的所有火花，或其中的一枚守卫。",
			effect_microbionix: "将当前服务器上任意数量的火花分别移至没有守卫的网络格。",
			effect_nootropicBloom: "执行：将网络中的一枚程序翻面。中断：为另一位骇客的行动提供一枚紫色指令。",
			effect_dniReboot: "揭示：将升级区中任意数量的牌放至升级牌堆底，然后补满升级区。每回合一次。",
			effect_digitalTattoo: "用于支付升级行动时，额外提供一枚紫色指令。",
			effect_adrenalinSurge: "用于支付上传行动时，可额外上传一枚同色程序。",
			effect_rootAccess: "揭示：查看本人牌库底牌，将其放回顶部或底部；其指令可用于本回合的下一次行动。每回合一次。",
			effect_magneticPulse: "将网络中的一枚装置或守卫移至行动格。",
			effect_gingerCool: "在任意骇客的生成步骤中，中断并更改一枚实际掷出的骰子的结果。",
			effect_psionicScatter: "将任意数量的绿色程序各移至其一个相邻格。",
			effect_duality: "将行动格中的一枚程序翻面。",
			effect_replicantJar: "将当前服务器中任意数量的程序翻面。",
			effect_decoyDuck: "交换当前服务器中一枚程序与一枚火花的位置。",
			effect_resetSpark: "移除行动格中的所有火花，或将其中一枚守卫替换为一枚同色火花。",
			effect_carbonClone: "任意骇客使用手牌支付指令时，中断并将其中一张牌提供的指令翻倍。",
			profile_hettie: "赫蒂·磁力",
			profileEffect_hettie: "移动时可在正常容量之外，多携带一枚程序或一枚火花。",
			profile_tokyo: "东京·布莱克",
			profileEffect_tokyo: "支付一枚蓝色与一枚紫色指令，可重新放置分身所在实体板块；其余板块必须仍然连通。",
			profile_monty: "蒙蒂·量子",
			profileEffect_monty: "站在绿色程序或装置上时，可在存在任意装置的格子，或存在绿色装置的整个服务器中使用幽灵行动。",
			profile_kelly: "凯莉·奈克瑟斯",
			profileEffect_kelly: "前两个回合结束时可保留至多三张手牌。",
			profile_tilda: "蒂尔达·甜心",
			profileEffect_tilda: "普通上传黄色程序只需要两枚黄色指令；不改变黄色装置提供的改良上传。",
			profile_twins: "科技双子",
			profileEffect_twins: "拥有两个独立行动的分身。每次行动选择其中一个；初始入口相同。",
			profile_oshin: "奥辛·诺罗",
			profileEffect_oshin: "自己分身或幽灵所在格发生感染时，感染值增加 1。",
			profile_angel: "安吉尔·硝酸盐",
			profileEffect_angel: "火花即将进入实体分身所在格时，可将其转向一个相邻格。",
			profile_leiko: "森·玲子",
			profileEffect_leiko: "开局选择一种基础颜色作为初始程序。支付两枚紫色指令，可移除当前服务器的一枚防御棋件，并在原格放置一枚程序。",
			profile_rupert: "鲁珀特·斯坦兹",
			profileEffect_rupert: "初始程序为紫色，只有他可从供应放置紫色程序；每次行动选择紫色程序视为的颜色。",
			objective_3022: "自由的代价",
			goal_3022: "每种参与角色的初始颜色各存入至少三枚程序。升级时须从网络存入一枚本人初始颜色的程序。",
			objective_3023: "热接线",
			goal_3023: "每个主服务器中至少两个格子存在绿色程序。",
			objective_3024: "密钥",
			goal_3024: "每个主服务器的 1 号格恰好存在四枚不同颜色的程序。",
			objective_3029: "404 未找到",
			goal_3029: "每个主服务器的 4 号格没有火花或守卫。指令阶段火花进入 6 号格时，改为进入同服务器的 4 号格。",
			objective_3025: "发条瘟疫",
			goal_3025: "每个主服务器中至少三个格子存在红色程序。",
			objective_3026: "双重切换",
			goal_3026: "每个主服务器的 4 号格恰好存在两枚火花。",
			objective_3027: "垃圾清理",
			goal_3027: "所有分身位于封闭格；分身所在格及相邻偶数格均没有火花。",
			objective_3028: "拒绝访问",
			goal_3028: "紫色服务器的 1 至 4 号格各有蓝色程序或装置；前 N 个格子各至少两枚。N 为玩家人数。",
			objective_3030: "警觉",
			goal_3030: "存在绿色装置的服务器至少达到 1／2／2／3 个，分别对应 1／2／3／4 人。准备时可将入口程序替换为绿色。",
			objective_3031: "罗马烛光",
			goal_3031: "每个主服务器至少有一枚装置。每回合开始时，在随机格放置一枚黑色火花。",
			objective_3032: "误导",
			goal_3032: "至少 N+1 个服务器的 6 号格存在黄色程序。N 为玩家人数。",
			objective_3033: "碎玻璃",
			goal_3033: "目标上存入至少 2N 枚黄色程序。每次改写后，从供应（不足则从网络）存入一枚黄色程序；N 为人数。",
			objective_3110: "归零",
			goal_3110: "目标上存入的程序和火花各至少 2N+1 枚。行动中移除的火花、系统反击中移除的程序均存入本目标。",
			objective_3111: "神经矩阵",
			goal_3111: "至少 N+1 个服务器的 1、3、5 号格均存在绿色程序或装置。N 为人数。",
			objective_3112: "烟火",
			goal_3112: "存在红色装置的服务器至少达到 2／3／3／4 个，分别对应 1／2／3／4 人。准备时替换全部红色装置。",
			objective_3113: "雅各布天梯",
			goal_3113: "每个主服务器的 2、3 号格各恰好一枚火花，或各恰好一枚守卫。每回合结束，当前服务器之外的火花按数字向下移动一格，守卫阻挡。",
			objective_3114: "骇客宫殿",
			goal_3114: "紫色服务器有至少 2／3／4／4 枚装置，分别对应 1／2／3／4 人。准备时将紫色服务器的装置移至不在紫色或其相邻格的位置。",
			objective_3115: "扰频器",
			goal_3115: "至少 2／3／4／4 个服务器的 5 号格存在至少两枚与服务器同色的程序，分别对应 1／2／3／4 人。每回合结束翻转随机服务器全部程序。",
			objective_3116: "病毒过载",
			goal_3116: "至少 5／8／11／14 个开放格存在红色程序，分别对应 1／2／3／4 人。",
			objective_3117: "蜂群",
			goal_3117: "指定蜂群服务器中没有火花或守卫。准备时随机指定服务器并在无防御的格子各放置一枚黑色火花；生成均发生在该服务器。",
			objective_3118: "朱红之梦",
			goal_3118: "位于红色服务器或与其相邻的绿色装置至少达到 1／2／2／3 枚，分别对应 1／2／3／4 人。生成服务器改为红色。",
			objective_3119: "访问关闭",
			goal_3119: "每个主服务器的 6 号格存在红色程序。每回合结束移除网络中一枚红色程序；若没有，在本人入口放置两枚黑色火花。",
			objective_3120: "归约或重启",
			goal_3120: "存在同色程序的格号之和恰好为 18／25／32／39，分别对应 1／2／3／4 人。",
			objective_3121: "数据过载",
			goal_3121: "两个服务器的 1 至 N+1 号格由蓝色通路覆盖，且经至少一个其他服务器的通路连接。N 为人数。",
			objective_2900: "消息队列",
			goal_2900: "按红、黄、蓝、绿、火花的顺序存入 N 组，所有火花必须同色；所有分身回到本人入口。推移可改为存入目标。",
			objective_2901: "模拟污迹",
			goal_2901: "每个封闭格存在程序，且每个主服务器的奇数格存在绿色程序。每回合结束额外进行系统反击。",
			objective_2902: "罗马大道",
			goal_2902: "每个入口经蓝色通路连接紫色 6 号格与另一个其他服务器的 6 号格；紫色角色须连接两个其他服务器。所有分身回到入口。",
			objective_2903: "断电",
			goal_2903: "每个主服务器的 1、3、5 号格存在蓝色程序或装置，所有分身回到入口。实体分身移动不能进入任何奇数格；幽灵与非移动传送不受限。",
			objective_2904: "分布式防御",
			goal_2904: "每个分身与一枚绿色或红色装置同格。回合开始在紫色 1 号格放置黑色火花（紫色角色改为绿色）；移动结束于本人主服务器外时，在行动格放置三枚黑色火花。",
			objective_2905: "瀑布",
			goal_2905: "全部服务器的 1、2 号格没有火花或守卫。回合结束，当前服务器的火花从低号向高号依次向下移动一格，跳过守卫；行动格没有黄色装置时再放一枚黑色火花。",
			objective_2906: "镜像地图",
			goal_2906: "全部主服务器加至少另一个服务器，在每个格号的程序与火花颜色、数量上完全相同；每个这样的服务器都至少存在蓝、绿、黄、红程序各一枚。",
			objective_2907: "中微子扫描",
			goal_2907: "每个入口没有火花或守卫。跳过全部生成。回合结束从本人主服务器的 1、2、3 号格各移一枚火花至入口，然后在另一位玩家主服务器的这些格各放一枚黑色火花。",
			objective_2908: "植入假消息",
			goal_2908: "木马已移除，所有分身回到入口。只可推移木马；将它送到各玩家入口以移除对应程序，再送回起始格。",
			objective_2909: "吃豆骇客",
			goal_2909: "移除吃豆骇客，所有分身回到入口。吃豆骇客与全部黑色守卫均视为白色守卫；每回合开始吃豆骇客移至行动格。",
			objective_2934: "暴洪",
			goal_2934: "目标存入至少 N 枚蓝色程序，每个入口存在蓝色程序，所有分身回到入口。同一次移动从本人入口出发、经过另外三个服务器的 6 号格并返回，可存入一枚网络蓝色程序。",
			objective_2935: "DNI 网络",
			goal_2935: "至少 N+1 个服务器的 2 号格存在至少三种颜色的程序。实体分身移动不可离开当前服务器，蓝色装置传送除外；幽灵及非移动传送不受限。",
			objective_2836: "海啸",
			goal_2836: "每位玩家的角色颜色各存入一枚程序。移除母亲幽灵时存入本人颜色程序，然后它在行动格重生。与幽灵相邻的实体分身立即随机传送。",
			objective_2837: "震荡",
			goal_2837: "每位玩家的角色颜色各存入一枚程序。幽灵所有相邻格须有同一种颜色的程序；支付红黄绿蓝指令各两枚并移除相邻格的三枚程序，才能移除幽灵。",
			objective_2838: "风暴",
			goal_2838: "将母亲幽灵的生命值降至零。初始生命值为 4N+4；感染值与抵抗值之差降低或增加其生命值。",
			objective_2839: "钛金",
			goal_2839: "每位玩家的角色颜色各存入一枚程序。只有感染行动可移除母亲幽灵；其抵抗值固定 16，同服务器每枚装置额外提供 4 点感染值。",
			back_3022: "成功：将全部存入的程序放回网络任意格。失败：每人可移除至多两枚本人初始颜色的存入程序，每少移除一枚，就在绿色服务器自由放置一枚黑色火花。",
			back_3023: "成功：自由放置一枚绿色装置。失败：每个主服务器中没有绿色程序的格子各放一枚黑色火花。",
			back_3024: "成功：在蓝色或绿色服务器放置一枚任意基础色装置。失败：每个服务器的 1 号格各放一枚黑色火花。",
			back_3029: "成功：每个服务器的 4 号格各放一枚绿色程序。失败：4 或 5 号格有防御的服务器，其 6 号格放一枚黑色火花。",
			back_3025: "成功：自由放置一枚黄色装置。失败：存在红色程序的格子不超过一个的主服务器，分别自由放置三枚黑色火花。",
			back_3026: "成功：可将任意 4 号格的火花逐枚替换为绿色程序。失败：红、黄、绿、蓝服务器的 4 号格各放一枚黑色火花。",
			back_3027: "成功：自由放置一枚蓝色装置。失败：每个分身所在格放一枚黑色火花，并在相邻格自由放置两枚黑色火花。",
			back_3028: "成功：在紫色服务器自由放置一枚红色程序和一枚蓝色装置。失败：紫色服务器中没有蓝色程序或装置的格子各放一枚黑色火花。",
			back_3030: "成功：自由放置一枚蓝色装置。失败：每个没有绿色装置的服务器，在随机格各放一枚黑色火花。",
			back_3031: "成功：选择一个主服务器，在其全部六格各放一枚任意颜色的程序。失败：每个没有装置的服务器，其 6 号格放一枚黑色火花。",
			back_3032: "成功：自由放置一枚红色装置。失败：选择没有黄色程序的一个 6 号格，放两枚黑色火花；然后每个主服务器的 6 号格各放一枚黑色火花。",
			back_3033: "成功：存入的黄色程序翻为红色并自由放回网络，再在紫色以外放一枚黄色装置。失败：存入程序归还供应；黄色 1 号格及红、蓝、紫的 6 号格各放一枚黑色火花。",
			back_3110: "成功：将全部存入棋件自由放回网络。失败：存入棋件永久移除；相较目标每少一枚程序或火花，就在每个主服务器自由放一枚黑色火花。",
			back_3111: "成功：随机服务器中，没有防御、绿色程序或绿色装置的格子各放一枚黑色火花。失败：没有绿色程序或装置的主服务器，其入口放两枚黑色火花；随机服务器中没有守卫的格子各放一枚黑色火花。",
			back_3112: "成功：选择一枚红色装置，在其相邻格自由放三枚黑色火花。失败：紫色服务器每格各放一枚黑色火花。",
			back_3113: "成功：在任意 1 号格自由放 N+1 枚黑色火花。失败：每个主服务器 1 号格各放一枚、6 号格各放两枚黑色火花。",
			back_3114: "成功：取紫色服务器两枚装置，叠为宫殿放至任意 3 号格。宫殿每移除同格一枚火花，就加叠一枚供应中的红色装置；供应不足或同格有守卫时移除宫殿。失败：红、黄、绿、紫的 3 号格各放两枚黑色火花。",
			back_3115: "成功：在任意 5 号格自由放 N+1 枚黑色火花。失败：没有至少两枚同色程序的 5 号格各放一枚黑色火花，再在任意 5 号格自由放 N+3 枚。",
			back_3116: "成功：选择黄或红服务器，在其中没有红色程序的格子各放一枚黑色火花。失败：对黄与红两个服务器都如此处理。",
			back_3117: "成功：蜂群服务器每个奇数格各放一枚黑色火花。失败：蜂群服务器每格各放一枚黑色火花。",
			back_3118: "成功：移除任意绿色装置，自由放一枚蓝色或绿色装置，再在新装置全部相邻格各放一枚黑色火花。失败：移除红色及其相邻格全部绿色程序，红色每格各放一枚黑色火花。",
			back_3119: "成功：每个主服务器入口各放一枚红色程序。失败：每个存在分身的不同格子各放两枚黑色火花。",
			back_3120: "成功：本人主服务器中没有守卫、也没有同色程序的格子各放一枚黑色火花。失败：正常准备下一周期，抽取未用银色目标额外进行一个周期；不触发哨兵的目标失败惩罚。",
			back_3121: "成功：红、黄的 1、3 号格各放一枚黑色火花。失败：每个主服务器 1 号格各放一枚，再在红、黄每个奇数格各放一枚。",
			back_2900: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2901: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2902: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2903: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2904: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2905: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2906: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2907: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2908: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2909: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2934: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2935: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2836: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2837: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2838: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			back_2839: "成功：完成入侵；若启用升级版系统主控，则继续最终目标。失败：全队失败。",
			alphaMoby: "阿尔法莫比",
			smcEffect_alphaMoby: "每回合开始，在行动格放一枚黑色火花。三个周期各生成 0、1、1 枚黑色火花。",
			spider: "蜘蛛",
			smcEffect_spider: "生成时只掷服务器骰，放至无守卫且火花最少的格，平手取最小格号。回合结束移除全部被防御完全包围的程序与装置；跳过周期末火花移动。",
			glom: "格洛姆",
			smcEffect_glom: "初始程序均为绿色。生成选择绿色程序最少的格，平手取最小格号。回合结束移动当前服务器最小非空 1 至 5 号格的全部火花至下一格。系统反击不能移除绿色程序。",
			logi: "洛基",
			smcEffect_logi: "不掷生成骰。选择当前服务器无守卫且红色程序最少的格，平手取最大格号。铜色阶段有两个周期，生成均为白色火花。",
			viking: "维京",
			smcEffect_viking: "生成火花进入空防御格时，改为进入相邻且有火花的最大号格；平手在全部并列格放置。生成中的爆炸只扩散至相邻奇数格。",
			sentinel: "哨兵",
			smcEffect_sentinel: "铜、银各两个周期。系统反击时不掷骰，红色程序与火花逐枚交换移除；守卫格移除全部红色程序。目标失败立即输掉游戏，归约或重启除外。",
			mother: "母亲",
			smcEffect_mother: "每回合开始，在本人入口放一枚黑色火花。银色有两个周期；金色生成白色火花。",
			alert: "警报",
			packetEffect_alert: "立即在实体分身格放置火花（铜／银黑色，金白色），然后随机移走本数据包。幽灵忽略本数据包。",
			tagTeam: "换手搭档",
			packetEffect_tagTeam: "立即替换为同色的另一个角色，将新分身放在此格，然后随机移走本数据包。",
			lighthouse: "灯塔",
			packetEffect_lighthouse: "任意骇客行动期间，将网络中的一枚装置临时视为位于它的一个相邻格；堆叠限制仍以原格计算。",
			interference: "干扰",
			packetEffect_interference: "铜／银阶段可跳过任意骇客的生成；银／金阶段可阻止一次火花放置。",
			password: "密码",
			packetEffect_password: "移动期间，选择 3／2／1 个格子视为存在蓝色程序，分别对应铜／银／金。",
			exploit: "漏洞利用",
			packetEffect_exploit: "为一张支付牌添加 3／2／1 枚紫色指令，分别对应铜／银／金。",
			vulnerability: "薄弱环节",
			packetEffect_vulnerability: "铜阶段立即永久移除；银阶段可永久扩展升级区至五张；金阶段可检索升级牌堆进行升级并将牺牲牌洗回牌堆。",
			rules: "目标：\n合作完成最终金色目标；必须放置的火花或守卫供应不足时立即失败。\n准备：\n选择系统主控与角色，拼接五块服务器板块。每位角色拥有十五张基础牌，洗牌抽五张，在本人服务器 6 号入口放初始程序；按系统主控布置防御，并自由补放规定数量的蓝色程序。\n周期：\n先查看目标并选择首位骇客。每人每周期行动三个回合，顺序自由选择。回合开始结算效果并生成火花，使用手牌行动，结束时前两回合可保留一张牌（凯莉三张）并抽五张；第三回合不能保留。全体完成后进行系统反击、检查目标、按箭头移动火花，最后准备下一周期。整局首回合跳过生成。\n指令：\n一张手牌可支付其全部指令，或改用其能力；同一次行动可组合多张牌，多余指令作废。紫色可代替任意颜色，任意三枚指令可换一枚紫色。高级牌按标记执行、揭示或中断；揭示牌不弃置且每回合一次。\n行动：\n· 上传：支付三枚同色指令，在行动格放一枚同色程序；有红／黄装置时可按一枚同色指令一枚程序上传对应颜色。\n· 安装：支付一枚同色指令，移除行动格三枚同色程序，放一枚同色装置。普通上传与安装不能在有防御棋件的格进行；红／黄装置提供的改良上传允许该格存在防御棋件。\n· 移动：每枚蓝色指令提供1点移动力。移动至相邻格消耗1点移动力；从蓝色程序或装置到蓝色程序或装置免费。从蓝色装置可直接前往任意格。可携带至多三枚同色基础程序，或一枚紫色程序。不可进入白色守卫格。\n· 推移：每枚绿色指令可将一个程序或火花移至相邻格；来源须为行动格，或存在绿色程序／装置的格。\n· 改写：支付1枚黄色指令和1枚目标颜色的指令，移除行动格一枚火花与一枚黄色程序，放一枚目标颜色程序。该格黄色程序数须大于火花数；相等时该服务器须有黄色装置。\n· 感染：所在格须有红色程序，并至少支付1枚红色指令。感染值为红骰加支付数、红色程序数、同格红色装置四点及每枚相邻红色装置一点。抵抗值为黑骰加火花数、同格每枚守卫四点及每枚相邻守卫一点。严格大于时移除该格全部防御，否则移除一枚红色程序。\n· 升级：支付公开高级牌标明的费用，将该牌加入手牌，并牺牲一张支付牌；高级牺牲牌进入公开升级区，基础牺牲牌退出游戏。\n程序与装置：\n· 蓝色程序和装置提供免费的移动通路；蓝色装置还允许传送。\n· 绿色程序和装置提供推移的来源位置；绿色装置还允许在同一服务器上执行幽灵行动。\n· 黄色程序用于满足改写条件；黄色装置还提供黄色改良上传。\n· 红色程序和装置增强感染；红色装置还提供红色改良上传。\n幽灵行动的当前格与服务器以幽灵位置计算，明确写实体分身的效果仍指实体。\n防御：\n三枚火花转化为守卫，有白色火花则转为白色。火花进入守卫格时爆炸，在相邻格各放同色火花。白色火花捕获同格程序，白色守卫移除同格其他棋件并随机传送实体分身。每格每种基础程序最多三枚、紫色一枚、装置一枚；程序与装置供应不足则跳过放置，捕获的程序仍占用供应。\n系统反击：\n红色程序与防御同格时反复进行不支付指令的感染，直至一方清空。随后火花移除同格程序，守卫移除同格程序与装置。系统主控、目标及数据包的特殊规则优先，详情可在对局中查看。",
			repositionGhost: "重新放置幽灵",
			adrenalinSurge: "是否额外放置一枚程序？"
		},
		en: {
			name: "Deckers",
			desc: "Infiltrate a network together using commands, programs and installations.",
			errAction: "This action is not available.",
			selection: "Choose an option",
			network: "Network",
			objective: "Objective",
			market: "Upgrade market",
			hand: "Hand",
			commands: "Commands",
			cost: "Upgrade cost",
			ability: "Ability",
			basic: "Basic",
			advanced: "Advanced",
			pay: "Use selected cards",
			choosePay: "Select cards to pay",
			clear: "Clear selection",
			close: "Close",
			inspect: "Details",
			usePacket: "Use Packet",
			act: "Action",
			upload: "Upload",
			install: "Install",
			move: "Move",
			shift: "Shift",
			modify: "Modify",
			infect: "Infect",
			upgrade: "Upgrade",
			execute: "Execute",
			reveal: "Reveal",
			leiko: "Leiko",
			leikoAction: "Leiko’s ability",
			tokyoAction: "Tokyo’s ability",
			shellshock: "Shellshock",
			endTurn: "End turn",
			finish: "Finish",
			finishAction: "Finish action",
			skip: "Skip",
			cancel: "Cancel",
			confirm: "Confirm",
			waiting: "Waiting for {{name}}",
			resolving: "Resolving",
			turn: "{{name}} · Turn {{n}}/3",
			cycle: "Cycle {{n}}",
			copper: "Copper",
			silver: "Silver",
			gold: "Gold",
			program: "Program",
			installation: "Installation",
			spark: "Spark",
			guardian: "Guardian",
			b: "Blue",
			g: "Green",
			y: "Yellow",
			r: "Red",
			p: "Purple",
			black: "Black",
			white: "White",
			spaceName: "{{color}} {{n}}",
			supply: "Supply",
			stored: "Stored",
			removed: "Removed",
			captured: "Captured",
			avatar: "Avatar",
			ghost: "Ghost",
			realAvatar: "Avatar",
			actingSpace: "Acting space",
			purpleAs: "Purple programs count as",
			count: "Amount / action points",
			points: "{{n}} points left",
			carry: "Carry",
			carryNone: "Carry no pieces",
			chooseCarry: "Choose pieces to carry",
			shiftPiece: "Choose a piece to shift",
			storeHere: "Store on objective",
			boardHint: "Choose a target on the network",
			chooseHand: "Select cards or inspect an advanced ability",
			pass: "Pass",
			interrupt: "Interrupt",
			reaction: "Reaction: {{kind}}",
			payment: "Payment",
			spawn: "Spawn",
			beforeSpawn: "Before spawn",
			placement: "Spark placement",
			keepCards: "Keep up to {{n}} cards",
			none: "None",
			returnOverview: "Overview",
			players: "Deckers",
			profile: "Profile",
			smc: "System Master Controller",
			log: "Activity",
			packet: "Packet",
			packets: "Packets variant",
			introductory: "Introductory setup",
			fragmented: "Fragmented servers",
			upgraded: "Upgraded SMC",
			networkSetup: "Network setup",
			preset: "Preset",
			choose: "Build your network",
			noUpgrade: "Standard",
			victory: "Network infiltrated",
			loss: "Infiltration failed",
			report: "Infiltration report",
			viewBoard: "Review network",
			showReport: "Show report",
			success: "Success",
			failure: "Failure",
			failedObjective: "The required objective was not completed.",
			sparkSupply: "A required Spark could not be placed from supply.",
			guardianSupply: "A required Guardian could not be placed from supply.",
			noSilverObjective: "No unused Silver objective remains for the repeated cycle.",
			chooseProfile: "Choose a Decker",
			chooseAvatar: "Choose the acting avatar",
			startingType: "Choose your starting program color",
			firstDecker: "Choose the first Decker this cycle",
			nextDecker: "Choose the next Decker",
			placeTile: "Place a server tile",
			tilePosition: "Tile position",
			repositionTile: "Reposition a tile",
			chooseOrder: "Choose the next effect",
			startOrder: "Choose a start-of-turn effect",
			endOrder: "Choose an end-of-turn effect",
			explosionOrder: "Choose the next explosion destination",
			capture: "Choose a program to capture",
			angelRedirect: "Redirect the Spark to an adjacent space?",
			acceptSpark: "Place here",
			redirectSpark: "Redirect here",
			choosePiece: "Choose a piece",
			piece: "Piece",
			space: "Space",
			color: "Color",
			card: "Card",
			decker: "Decker",
			chooseProgram: "Choose a program",
			chooseSpark: "Choose a Spark",
			chooseInstallation: "Choose an installation",
			chooseRemove: "Choose a piece to remove",
			chooseSMC: "Choose a defense piece",
			placePiece: "Choose color and destination",
			destination: "Choose a destination",
			optionalProgram: "Place a yellow program here?",
			installPrograms: "Choose a program for the installation",
			knowledgeDeposit: "Deposit a program of your starting color",
			sacrifice: "Choose a paid card to sacrifice",
			flashFlood: "Store a blue program from the network?",
			copyCard: "Choose an Execute ability to copy",
			resetSpark: "Remove all Sparks, or replace a Guardian with a matching Spark",
			rootPosition: "Place the inspected card on top or bottom",
			flipPiece: "Choose a piece to flip",
			hologatePieces: "Choose programs and Sparks to relocate, then finish to choose a destination",
			interceptCards: "Choose other cards to put under your deck",
			rebootCards: "Choose market cards to put under the upgrade deck",
			top: "Top of deck",
			bottom: "Bottom of deck",
			replaceStarting: "Replace a program at your entry?",
			replaceInstallation: "Choose the replacement installation color",
			chooseServer: "Choose a server",
			chooseColor: "Choose a color",
			redistribute: "Choose a stored piece to return to the network",
			reducePenalty: "Remove stored programs to reduce the penalty",
			removePrograms: "Remove {{n}} programs",
			doubleSwitch: "Optionally replace Sparks on space 4 with green programs",
			buildPalace: "Choose two installations on the purple server",
			installations: "Two installations",
			palaceDestination: "Choose a space 3 for the Palace",
			moveSpark: "Choose the next Spark to move",
			smcBattle: "Choose the next SMC battle",
			removeSpark: "Choose a Spark to remove",
			infectLoss: "Infect failed: remove a red program",
			chooseHome: "Choose another Decker’s home server",
			refreshMarket: "Refresh the entire upgrade market?",
			keepMarket: "Keep market",
			emitEMP: "Optionally remove every Spark in one adjacent space",
			reservePiece: "Choose a piece to reserve",
			trojanDestination: "Choose the Trojan’s starting space",
			passwordSpace: "Choose a space treated as having a blue program",
			exploitCard: "Choose a paid card to gain extra commands",
			accept: "Accept",
			explosion: "Explosion",
			transformation: "Transform into a Guardian",
			battle: "Infect resolution",
			palace: "Hacker’s Palace",
			trojan: "Trojan",
			health: "Health {{n}}",
			progress: "Progress {{have}}/{{need}}",
			archives: "Cycle objectives",
			hiddenBack: "Outcome is revealed after the SMC attack",
			card_apprentice: "Apprentice",
			card_infiltrate: "Infiltrate",
			card_sabotage: "Sabotage",
			card_dataSteal: "Data Steal",
			card_decrypt: "Decrypt",
			card_dataScan: "Data Scan",
			card_bypass: "Bypass",
			card_focus: "Focus",
			card_memorySteal: "Memory Steal",
			card_intercept: "Intercept",
			card_diversion: "Diversion",
			card_reroute: "Reroute",
			card_blackHat: "Black Hat",
			card_deceptionSpike: "Deception Spike",
			card_catalyst: "Catalyst",
			card_emitEMP: "Emit EMP",
			card_livewireVoodoo: "Livewire Voodoo",
			card_sidekick: "Sidekick",
			card_dataShift: "Data Shift",
			card_hologate: "Hologate",
			card_readRequestIntercept: "Read Request Intercept",
			card_piedPiper: "Pied Piper",
			card_nydamShip: "Nydam Ship",
			card_viralSplash: "Viral Splash",
			card_neuralSplash: "Neural Splash",
			card_pingNexus: "Ping Nexus",
			card_exoticSoftware: "Exotic Software",
			card_copycat: "Copycat",
			card_consoleCowboy: "Console Cowboy",
			card_microbionix: "Microbionix",
			card_nootropicBloom: "Nootropic Bloom",
			card_dniReboot: "DNI Reboot",
			card_digitalTattoo: "Digital Tattoo",
			card_adrenalinSurge: "Adrenalin Surge",
			card_rootAccess: "Root Access",
			card_magneticPulse: "Magnetic Pulse",
			card_gingerCool: "Ginger Cool",
			card_psionicScatter: "Psionic Scatter",
			card_duality: "Duality",
			card_replicantJar: "Replicant Jar",
			card_decoyDuck: "Decoy Duck",
			card_resetSpark: "Reset Spark",
			card_carbonClone: "Carbon Clone",
			effect_deceptionSpike: "Execute: Remove one Spark from your acting space. You may then place one yellow Program there.",
			effect_catalyst: "Interrupt after the dice are rolled during any Decker’s Infect action. Discard this card to add 2 to the Infect value.",
			effect_emitEMP: "When this card pays for a successful Infect action, you may remove all Sparks from one adjacent space.",
			effect_livewireVoodoo: "Execute: Flip up to three Sparks on your current server. Flipping a white Spark releases its captured Program; normal stacking limits apply.",
			effect_sidekick: "Execute: Remove one Spark from your acting space or an adjacent space.",
			effect_dataShift: "Execute: Relocate up to three Programs from adjacent spaces to your acting space.",
			effect_hologate: "Execute: Relocate your avatar and any number of Programs and Sparks from your acting space to any other network space. This is a relocation rather than a Move action.",
			effect_readRequestIntercept: "Execute: Put this card and up to two other cards from your hand on the bottom of your deck, then draw the same number of cards.",
			effect_piedPiper: "Execute: Relocate one Program from anywhere on the network to your acting space.",
			effect_nydamShip: "Execute on an open space: Move to any other open space. This counts as a Move action and allows normal carrying.",
			effect_viralSplash: "Execute: Place two black Sparks on your acting space. Then place one red Program on each of up to three different open spaces.",
			effect_neuralSplash: "Execute: Place two black Sparks on your acting space. Then place one green Program on each of up to three different open spaces.",
			effect_pingNexus: "Interrupt: Contribute one purple command to another Decker’s action. Execute: Remove one Installation from the network and place up to three Programs of its color on that space.",
			effect_exoticSoftware: "Execute: Remove two Programs of any colors from your acting space, then place a blue, green, yellow or red Installation there.",
			effect_copycat: "Reveal once per turn together with another card in your hand. Perform that card’s Execute ability without discarding it.",
			effect_consoleCowboy: "Execute: Remove either all Sparks or one Guardian from your acting space.",
			effect_microbionix: "Execute: Relocate any number of Sparks from your current server to network spaces without Guardians.",
			effect_nootropicBloom: "Interrupt: Contribute one purple command to another Decker’s action. Execute: Flip one Program anywhere on the network.",
			effect_dniReboot: "Reveal once per turn: Put any number of market cards on the bottom of the upgrade deck, then refill the market.",
			effect_digitalTattoo: "When this card pays for an Upgrade, it provides one additional purple command.",
			effect_adrenalinSurge: "When this card pays for an Upload, you may place one additional Program of the uploaded color.",
			effect_rootAccess: "Reveal once per turn: Inspect the bottom card of your deck and leave it there or put it on top. Add its commands to your next action this turn.",
			effect_magneticPulse: "Execute: Relocate one Installation or Guardian from anywhere on the network to your acting space.",
			effect_gingerCool: "Interrupt during any Spawn step: Change the face of one die that was rolled.",
			effect_psionicScatter: "Execute: Relocate any number of green Programs, each from its current space to one adjacent space.",
			effect_duality: "Execute: Flip one Program on your acting space: blue and green are opposite sides, as are yellow and red.",
			effect_replicantJar: "Execute: Flip any number of Programs on your current server.",
			effect_decoyDuck: "Execute: Exchange the positions of one Program and one Spark on your current server.",
			effect_resetSpark: "Execute: Remove all Sparks from your acting space, or replace one Guardian there with one Spark of the same color.",
			effect_carbonClone: "Interrupt when any Decker plays a card for commands: Discard this card to double the commands provided by that card.",
			profile_hettie: "Hettie Magnetic",
			profileEffect_hettie: "Carry one extra program or Spark beyond normal capacity.",
			profile_tokyo: "Tokyo Black",
			profileEffect_tokyo: "Pay one blue and one purple command to reposition your physical tile; the other tiles must remain connected.",
			profile_monty: "Monty Quantum",
			profileEffect_monty: "From a green program or installation, ghost at any installation or on any server with a green installation.",
			profile_kelly: "Kelly Nexus",
			profileEffect_kelly: "Keep up to three cards at the end of your first two turns.",
			profile_tilda: "Tilda Sweet",
			profileEffect_tilda: "A normal yellow Upload costs two yellow commands; improved Upload is unchanged.",
			profile_twins: "The Techno Twins",
			profileEffect_twins: "Two independent avatars share an entry. Choose one avatar for each action.",
			profile_oshin: "Oshin Noro",
			profileEffect_oshin: "Add one Infect where your avatar or ghost is located.",
			profile_angel: "Angel Nitrate",
			profileEffect_angel: "Redirect an incoming Spark from your avatar’s space to an adjacent space.",
			profile_leiko: "Leiko Mori",
			profileEffect_leiko: "Choose a basic starting program color. Pay two purple commands to remove one SMC piece on your server and place a program there.",
			profile_rupert: "Rupert Stanz",
			profileEffect_rupert: "Starts with purple programs. Only Rupert may place them from supply; choose their color for each action.",
			objective_3022: "Knowledge is the Price of Freedom",
			goal_3022: "Store at least three Programs of each participating starting color on this objective. Each Upgrade also requires storing one Program of your starting color from the network.",
			objective_3023: "Hot-Wire",
			goal_3023: "Each home server must have green Programs on at least two different spaces.",
			objective_3024: "Keycode",
			goal_3024: "Each home server’s space 1 must contain exactly four Programs of different colors.",
			objective_3029: "404 Not Found",
			goal_3029: "Each home server’s space 4 must be clear of Sparks and Guardians. During the Command phase, Sparks entering space 6 enter space 4 of the same server instead.",
			objective_3025: "Clockwork Plague",
			goal_3025: "Each home server must have red Programs on at least three different spaces.",
			objective_3026: "Double-Switch",
			goal_3026: "Each home server’s space 4 must contain exactly two Sparks.",
			objective_3027: "Garbage Detail",
			goal_3027: "Every avatar must be on a closed space. That space and all adjacent even-numbered spaces must be clear of Sparks. If setup has no closed spaces, reposition the last tile.",
			objective_3028: "Access Denied",
			goal_3028: "Purple spaces 1–4 must each have a blue Program or Installation. Spaces 1 through the number of Deckers must each have at least two such pieces.",
			objective_3030: "Alert to Our Presence",
			goal_3030: "Green Installations must be present on at least 1 / 2 / 2 / 3 servers with 1 / 2 / 3 / 4 Deckers. At setup, each Decker may replace an entry Program with a green one.",
			objective_3031: "Roman Candle",
			goal_3031: "Each home server must contain an Installation. At the start of every turn, place one black Spark on a random network space.",
			objective_3032: "Misdirection",
			goal_3032: "Yellow Programs must be present on space 6 of at least one more server than the number of Deckers.",
			objective_3033: "Shattered Glass",
			goal_3033: "Store at least two yellow Programs per Decker on this objective. After each Modify, store one yellow Program from supply, or from the network if supply is empty. At setup, each Decker may replace an entry Program with yellow.",
			objective_3110: "Null & Void",
			goal_3110: "Store at least twice the number of Deckers plus one Program, and the same number of Sparks. Sparks removed during actions and Programs removed during the SMC Attack are stored here. Captured Programs removed with a white Spark count.",
			objective_3111: "Neural Matrix",
			goal_3111: "Spaces 1, 3 and 5 must each have a green Program or Installation on at least one more server than the number of Deckers.",
			objective_3112: "Fireworks",
			goal_3112: "Red Installations must be present on at least 2 / 3 / 3 / 4 servers with 1 / 2 / 3 / 4 Deckers. At setup, replace every red Installation with a chosen blue, green or yellow one.",
			objective_3113: "Jacob's Ladder",
			goal_3113: "Each home server’s spaces 2 and 3 must each contain exactly one Spark, or each exactly one Guardian. At each turn’s end, move Sparks on every other server down one number, processing spaces 2 through 6; Guardians block movement.",
			objective_3114: "Hacker's Palace",
			goal_3114: "The purple server must contain at least 2 / 3 / 4 / 4 Installations with 1 / 2 / 3 / 4 Deckers. At setup, relocate its Installations to spaces neither on nor adjacent to the purple server.",
			objective_3115: "Scrambler",
			goal_3115: "Space 5 must contain at least two Programs matching its server on at least 2 / 3 / 4 / 4 servers with 1 / 2 / 3 / 4 Deckers. At each turn’s end, flip all Programs on a random server.",
			objective_3116: "Viral Overload",
			goal_3116: "Red Programs must be present on at least 5 / 8 / 11 / 14 open spaces with 1 / 2 / 3 / 4 Deckers.",
			objective_3117: "Swarm",
			goal_3117: "Clear the designated Swarm Server of all Sparks and Guardians. At setup, randomly choose that server and place a black Spark on each space without SMC pieces. All Spawn targets that server.",
			objective_3118: "Dreams in Vermilion",
			goal_3118: "At least 1 / 2 / 2 / 3 green Installations must be on or adjacent to the red server with 1 / 2 / 3 / 4 Deckers. At setup, replace all green Installations with a chosen other basic color. All Spawn targets red.",
			objective_3119: "Access Shutdown",
			goal_3119: "Every home server’s space 6 must contain a red Program. At each turn’s end, remove one red Program from anywhere; if none exists, place two black Sparks on the active Decker’s entry.",
			objective_3120: "Reduct or Reboot",
			goal_3120: "Add the space numbers of all spaces containing a Program matching their server. The total must equal exactly 18 / 25 / 32 / 39 with 1 / 2 / 3 / 4 Deckers.",
			objective_3121: "Data Overload",
			goal_3121: "Form blue Pathways through spaces 1 to the number of Deckers plus one on two servers. Connect those Pathways through at least one additional server.",
			objective_2900: "Message Queue",
			goal_2900: "Store red, yellow, blue and green Programs, then a Spark, in that order once per Decker. All stored Sparks must share one color and all avatars must return to their entries. Shift can store a piece instead of moving it.",
			objective_2901: "SimSmudge",
			goal_2901: "Every closed space must have a Program, and every odd-numbered home space a green Program. Resolve an additional SMC Attack at the end of every turn.",
			objective_2902: "Roman Road",
			goal_2902: "Connect each entry by blue Pathways to purple space 6 and space 6 of another server. A purple Decker needs two other servers. All avatars must return to their entries.",
			objective_2903: "Blackout",
			goal_2903: "Every odd-numbered home space must have a blue Program or Installation, and all avatars must return to their entries. At setup, remove blue Programs from those spaces. Avatar Move actions cannot enter odd-numbered spaces; ghosts are exempt.",
			objective_2904: "Distributed Defense",
			goal_2904: "Every avatar must share a space with a green or red Installation. At turn start, place one black Spark on purple space 1, or green space 1 if active home is purple. A Move ending outside your home places three black Sparks on the acting space.",
			objective_2905: "Waterfall",
			goal_2905: "Every server’s spaces 1 and 2 must be clear of Sparks and Guardians. At turn end, move Sparks on your current server down one number, skipping Guardians, in ascending source order. Then place one black Spark at your space unless a yellow Installation is present.",
			objective_2906: "Mirror Map",
			goal_2906: "All home servers and at least one other server must have identical Program and Spark counts and colors on corresponding spaces. Each must include blue, green, yellow and red Programs. Ignore Installations and Guardians.",
			objective_2907: "Neutrino-Scanner",
			goal_2907: "Clear all entries of Sparks and Guardians. Skip all Spawn steps. At turn end, move one Spark from each of your home spaces 1–3 to your entry, then place one black Spark on spaces 1–3 of another home server, or your own when solo.",
			objective_2908: "Insert Misinformation",
			goal_2908: "Remove the Trojan and return all avatars to their entries. The Trojan starts on the space 1 furthest from the active entry. Shift it to every home entry to return its matching Program, then to its starting space to remove it.",
			objective_2909: "HackMan",
			goal_2909: "Remove HackMan and return all avatars to their entries. At turn start, HackMan relocates to your acting space. HackMan and every black Guardian act as white Guardians throughout this cycle.",
			objective_2934: "Flash Flood",
			goal_2934: "Store at least one blue Program per Decker, place a blue Program on every entry, and return all avatars to their entries. A Move starting and ending at your entry and visiting space 6 on three other servers may store a blue Program. At turn start, place a black Spark on your entry.",
			objective_2935: "DNI Web",
			goal_2935: "Space 2 must contain at least three different Program colors on at least one more server than the number of Deckers. At setup, remove all blue and green Programs and place a green Program on every odd space. Avatars can leave a server during Move only by blue Installation teleport; ghosts are exempt.",
			objective_2836: "Tsunami",
			goal_2836: "Store at least one Program of each Decker’s color. The Ghost starts at the active space and clears adjacent pieces once. Avatars adjacent to it relocate randomly. Whenever it is removed, store a Program of the acting Decker’s color and respawn it at that Decker’s space.",
			objective_2837: "Shellshock",
			goal_2837: "Store at least one Program of each Decker’s color. Only Shellshock removes the Ghost: every adjacent space must contain a Program of one shared color. Pay two commands of each basic color and remove three adjacent Programs. On removal, store your color and respawn it on current-server space 6.",
			objective_2838: "Tempest",
			goal_2838: "Reduce the Ghost’s Health to zero with Infect actions. Initial Health is four times the number of Deckers plus four. Subtract Infect minus Resistance from Health, so failed actions can increase it beyond its initial value.",
			objective_2839: "Titanium",
			goal_2839: "Store at least one Program of each Decker’s color. Only an Infect action removes the Ghost. Its Resistance is exactly 16. Each Installation on its server adds four Infect in addition to normal bonuses. On removal, store your color and respawn it at your acting space.",
			back_3022: "Success: Redistribute all stored Programs anywhere on the network. Failure: Each Decker places two black Sparks on the green server, reduced by one for each of up to two stored Programs of their starting color that they remove. Return the rest to supply. Spark arrows on success: blue down, green up, red up, purple down. Reverse their order and directions on failure.",
			back_3023: "Success: Place a green Installation anywhere. Failure: Place a black Spark on every home-server space without a green Program. Spark arrows on success: blue down, green up, yellow down, red up. Reverse their order and directions on failure.",
			back_3024: "Success: Place any basic Installation on the blue or green server. Failure: Place a black Spark on space 1 of every server. Spark arrows on success: purple down, red up, blue down, yellow up. Reverse their order and directions on failure.",
			back_3029: "Success: Place a green Program on space 4 of every server. Failure: Place a black Spark on space 6 of every server with SMC pieces on space 4 or 5. Spark arrows on success: green up, green up, blue up, blue up. Reverse their order and directions on failure.",
			back_3025: "Success: Place a yellow Installation anywhere. Failure: Each home server with red Programs on no more than one space receives three black Sparks, freely placed there. Spark arrows on success: green up, purple down, yellow up, blue down. Reverse their order and directions on failure.",
			back_3026: "Success: You may repeatedly replace a Spark on any space 4 with a green Program. Failure: Place a black Spark on space 4 of the red, yellow, green and blue servers. Spark arrows on success: green up, red down, yellow down, blue up. Reverse their order and directions on failure.",
			back_3027: "Success: Place a blue Installation anywhere. Failure: For every avatar, place a black Spark on its space and two black Sparks on adjacent spaces of your choice. Spark arrows on success: red up, red up, yellow up, yellow up. Reverse their order and directions on failure.",
			back_3028: "Success: Place a red Program and a blue Installation on chosen purple spaces. Failure: Place a black Spark on every purple space without a blue Program or Installation. Spark arrows on success: blue up, green up, yellow up, red up. Reverse their order and directions on failure.",
			back_3030: "Success: Place a blue Installation anywhere. Failure: Place one black Spark on a random space of each server without a green Installation. Spark arrows on success: green down, yellow up, purple down, blue up. Reverse their order and directions on failure.",
			back_3031: "Success: Choose a home server and place one Program of a chosen color on each of its six spaces. Failure: Place a black Spark on space 6 of each server without an Installation. Spark arrows on success: blue down, green down, yellow down, red down. Reverse their order and directions on failure.",
			back_3032: "Success: Place a red Installation anywhere. Failure: Choose a space 6 without a yellow Program and place two black Sparks there, then place one black Spark on each home entry. Spark arrows on success: yellow up, red down, green up, purple down. Reverse their order and directions on failure.",
			back_3033: "Success: Flip stored yellow Programs to red and redistribute them anywhere, then place a yellow Installation outside the purple server. Failure: Return stored Programs to supply, then place a black Spark on yellow space 1 and red, blue and purple space 6. Spark arrows on success: yellow up, purple down, blue up, red down. Reverse their order and directions on failure.",
			back_3110: "Success: Redistribute all stored Programs and Sparks anywhere. Failure: Permanently remove stored pieces. For each Program and each Spark missing from the required totals, place one black Spark on every home server. Spark arrows on success: green up, blue up, purple down, purple down. Reverse their order and directions on failure.",
			back_3111: "Success: Choose a random server and place a black Spark on each space without SMC pieces or green software. Failure: Place two black Sparks on each home entry whose server has no green Program or Installation, then place a black Spark on every space without a Guardian on a random server. Spark arrows on success: yellow down, blue up, red up, green down. Reverse their order and directions on failure.",
			back_3112: "Success: Choose a red Installation and freely place three black Sparks on adjacent spaces. Failure: Place a black Spark on every purple space. Spark arrows on success: red down, purple up, blue up, yellow down. Reverse their order and directions on failure.",
			back_3113: "Success: Freely place one more black Spark than the number of Deckers on spaces numbered 1. Failure: Place one black Spark on every home space 1 and two on every home entry.",
			back_3114: "Success: Stack two purple-server Installations on a chosen space 3 to form the Palace. Whenever a Spark shares its space, remove that Spark and add a red Installation from supply to the stack. Remove the Palace if supply cannot provide one or a Guardian shares its space. Failure: Place two black Sparks on red, yellow, green and purple space 3. Spark arrows on success: purple up, green down, yellow up, red down. Reverse their order and directions on failure.",
			back_3115: "Success: Freely place one more black Spark than the number of Deckers on spaces numbered 5. Failure: Place a black Spark on each space 5 lacking two Programs matching its server, then freely place three more black Sparks than the number of Deckers on spaces numbered 5. Spark arrows on success: purple up, purple up, blue down, green down. Reverse their order and directions on failure.",
			back_3116: "Success: Choose the red or yellow server and place a black Spark on each space without a red Program. Failure: Apply that placement on both servers. Spark arrows on success: purple up, yellow down, red down, green up. Reverse their order and directions on failure.",
			back_3117: "Success: Place a black Spark on every odd-numbered Swarm Server space. Failure: Place a black Spark on every Swarm Server space. Spark arrows on success: blue up, green down, purple up, yellow down. Reverse their order and directions on failure.",
			back_3118: "Success: Remove a green Installation, then place a blue or green Installation anywhere and a black Spark on every adjacent space. Failure: Remove all green Programs on or adjacent to red, then place a black Spark on every red space. Spark arrows on success: red down, yellow down, red down, purple up. Reverse their order and directions on failure.",
			back_3119: "Success: Place a red Program on every home entry. Failure: Place two black Sparks on each distinct avatar-occupied space. Spark arrows on success: purple down, blue up, yellow down, green up. Reverse their order and directions on failure.",
			back_3120: "Success: Place a black Spark on each space of the active Decker’s home server without a Guardian or a Program matching its server. Failure: Repeat the cycle with a newly drawn unused Silver objective; Sentinel does not lose for this failure. Refresh normally. Spark arrows on success: blue up, green up, yellow up, red up. Reverse their order and directions on failure.",
			back_3121: "Success: Place a black Spark on spaces 1 and 3 of red and yellow. Failure: Place a black Spark on every home space 1, then on all odd-numbered spaces of red and yellow. Spark arrows on success: green up, yellow up, red up, blue up. Reverse their order and directions on failure.",
			back_2900: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2901: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2902: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2903: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2904: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2905: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2906: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2907: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2908: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2909: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2934: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2935: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2836: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2837: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2838: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			back_2839: "Success: win, or continue to the added final objective with upgraded SMC. Failure: the team loses.",
			alphaMoby: "Alpha-Moby",
			smcEffect_alphaMoby: "One Copper, one Silver and one Gold cycle. Spawn 0 / 1 / 1 black Sparks in those levels. Setup: Place a black Spark on every purple space and every entry. At turn start, place a black Spark at the active space.",
			spider: "Spider",
			smcEffect_spider: "One cycle at each level. Spawn 1 / 2 / 3 black Sparks. Setup: Place one black Spark on every purple space and odd-numbered home space. Spawn rolls only the server; use its space with the fewest Sparks and no Guardian, breaking ties by lowest number. At turn end, remove all Programs and Installations whose every adjacent space has SMC pieces. Skip cycle-end Spark arrows.",
			glom: "Glom",
			smcEffect_glom: "One cycle at each level. Spawn one black Spark in Copper, two black in Silver and two white in Gold. Setup: All starting and free Programs are green; place a black Spark on every even open space, then every purple space without a Spark. Spawn rolls only the server; use its space with the fewest green Programs, breaking ties by lowest number. At turn end, move all Sparks from the lowest occupied space 1–5 on the active server to the next number. Green Programs cannot be removed during SMC Attack.",
			logi: "Logi",
			smcEffect_logi: "Two Copper cycles, then one Silver and one Gold. Spawn 1 / 2 / 2 white Sparks. Setup: Place two black Sparks on every closed space, then one on every odd purple space. Spawn rolls no dice; use the active server’s space without a Guardian and with the fewest red Programs, breaking ties by highest number.",
			viking: "Viking",
			smcEffect_viking: "One cycle at each level. Spawn one black Spark in Copper, two black in Silver and two white in Gold. Setup: Place one black Spark on every space 2 and 4, and two on every open space 5. During Spawn, a Spark entering a space without SMC pieces redirects to the highest-numbered adjacent space with Sparks; place one on every tied space. If none qualifies, use the original space. Spawn explosions spread only to odd-numbered spaces.",
			sentinel: "Sentinel",
			smcEffect_sentinel: "Two Copper, two Silver and one Gold cycle. Spawn 1 / 2 / 2 black Sparks. Setup: Place two black Sparks on every open red and yellow space, and one on every open purple space. Spawn rolls only the number on the active server. SMC Attack first removes all red Programs on Guardian spaces; elsewhere, repeatedly remove one red Program and one chosen Spark together. Resolve normal cleanup afterward. Any failed objective loses immediately, except Reduct or Reboot.",
			mother: "Mother",
			smcEffect_mother: "One Copper, two Silver and one Gold cycle. Spawn one black Spark in Copper, two black in Silver and two white in Gold. Setup: Place a black Spark on every purple space, every space adjacent to purple, then every closed space without a black Spark. At turn start, place a black Spark on the active Decker’s entry.",
			alert: "Alert",
			packetEffect_alert: "Resolve immediately: Place a black Spark at your avatar in Copper or Silver, or a white Spark in Gold, then move this token to a random space. Ghosts ignore Alert.",
			tagTeam: "Tag Team",
			packetEffect_tagTeam: "Resolve immediately: Replace your profile and avatars with the alternate profile of the same color, placing its avatars here. Move this token to a random space.",
			lighthouse: "Lighthouse",
			packetEffect_lighthouse: "Spend during any Decker’s action: Treat one Installation as being on an adjacent space until that action ends. Stacking still counts at its original space.",
			interference: "Interference",
			packetEffect_interference: "Spend in Copper to skip any Decker’s Spawn. In Silver, skip Spawn or prevent one Spark placement. In Gold, prevent one Spark placement.",
			password: "Password",
			packetEffect_password: "Spend during your Move: Treat up to 3 / 2 / 1 spaces as having blue Programs in Copper / Silver / Gold.",
			exploit: "Exploit",
			packetEffect_exploit: "Spend during your payment: Add 3 / 2 / 1 purple commands to one paid card in Copper / Silver / Gold.",
			vulnerability: "Vulnerability",
			packetEffect_vulnerability: "Copper: Remove immediately. Silver: Spend to permanently expand the market to five cards. Gold: Spend to search the upgrade deck for an Upgrade, then shuffle the sacrificed card into it. Spending permanently removes this token.",
			rules: "Goal:\nWork together to complete the final Gold objective. The team loses immediately if a required Spark or Guardian cannot be placed from supply.\nCycle:\nChoose the first Decker. Each Decker takes three turns per cycle in any chosen order. Resolve start effects and Spawn, perform actions, then keep up to one card (Kelly three) and draw five; no cards are kept after the third turn. After all Deckers finish, resolve the SMC Attack, objective, Spark arrows, and Refresh. The first turn of the whole game skips Spawn.\nCommands:\nCombine cards for one action; excess commands are lost. Purple is wild, and any three commands exchange for one purple. Advanced cards may instead Execute, Reveal once per turn without discarding, or Interrupt at their printed timing.\nActions:\n· Upload: pay three matching commands for one program at your space. A red/yellow installation improves the matching Upload to one command per program.\n· Install: pay one matching command and remove three matching programs to place an installation. Normal Upload and Install require no defense at that space. Improved Upload through a red or yellow Installation is allowed even with defense present.\n· Move: blue commands give movement points; adjacent movement costs one, blue pathways are free, and a blue installation allows teleporting to any space. Carry up to three programs of one basic color or one purple program. White Guardians block avatar entry.\n· Shift: each green command moves a program or Spark one adjacent space, from your space or any space with green software.\n· Modify: pay one yellow command and one command of the desired color, remove a Spark and a yellow program, and place a program of the desired color; yellow programs must outnumber Sparks, or tie with a yellow installation on that server.\n· Infect: requires a red program and at least one red command; compare red die plus paid commands, red programs, four per local red installation, one per adjacent red installation, against black die plus Sparks, four per local Guardian, one per adjacent Guardian. Strictly greater removes all defense; otherwise lose one red program.\n· Upgrade: pay a market card’s cost, add it to your hand, and sacrifice one paid card; an advanced sacrifice enters the market, a basic sacrifice leaves play.\nNetwork:\nGreen installations allow Ghost actions on their server. Ghosts define your acting space/server, while explicit avatar effects still affect the actual avatar. Three Sparks transform into a Guardian; any white Spark makes it white. A Spark entering a Guardian explodes to adjacent spaces. White Sparks capture programs; white Guardians clear other pieces and randomly relocate avatars. Each space holds up to three programs per basic color, one purple, and one installation. Captured programs still occupy physical supply.\nSMC Attack:\nRed programs repeatedly Infect defense without paid commands until one side is clear. Then Sparks remove programs and Guardians remove programs and installations. SMC, objective and Packet rules override these defaults; inspect their details during play.",
			repositionGhost: "Reposition ghost",
			adrenalinSurge: "Place an additional program?"
		}
	}
};
//#endregion
export { zn as default };
