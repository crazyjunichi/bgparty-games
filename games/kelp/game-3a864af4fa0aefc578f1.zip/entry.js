import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useWakeLock as a } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as s } from "@bgparty/sdk/assets";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { useT as l } from "@bgparty/sdk/i18n";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { OptionRadio as p, OptionSection as m } from "@bgparty/sdk/ui/game-options";
//#region src/games/kelp/data.ts
var h = [
	"crab",
	"lobster",
	"snail",
	"abalone"
];
[...h];
var g = (e) => h.includes(e), _ = (e) => e.endsWith("Trap"), v = (e, t) => Math.abs(e % 3 - t % 3) + Math.abs(Math.floor(e / 3) - Math.floor(t / 3)) === 1, y = Array.from({ length: 9 }, (e, t) => t), b = [], x = (e, t) => t * 4 + e;
for (let e = 0; e <= 3; e++) for (let t = 0; t < 3; t++) (e !== 0 && e !== 3 || t === 1) && b.push({
	ends: [x(t, e), x(t + 1, e)],
	x: t + .5,
	y: e,
	zones: [e > 0 ? (e - 1) * 3 + t : -1, e < 3 ? e * 3 + t : -1].filter((e) => e >= 0)
});
for (let e = 0; e < 3; e++) for (let t = 0; t <= 3; t++) (t !== 0 && t !== 3 || e === 1) && b.push({
	ends: [x(t, e), x(t, e + 1)],
	x: t,
	y: e + .5,
	zones: [t > 0 ? e * 3 + t - 1 : -1, t < 3 ? e * 3 + t : -1].filter((e) => e >= 0)
});
for (let [e, t, n, r] of [
	[
		0,
		0,
		0,
		0
	],
	[
		3,
		0,
		2,
		0
	],
	[
		0,
		3,
		0,
		2
	],
	[
		3,
		3,
		2,
		2
	]
]) b.push({
	ends: [x(e === 0 ? 1 : 2, t), x(e, t === 0 ? 1 : 2)],
	x: e === 0 ? .28 : 2.72,
	y: t === 0 ? .28 : 2.72,
	zones: [r * 3 + n]
});
var S = b.map((e, t) => ({
	...e,
	id: t
})), C = {
	day: [
		16,
		17,
		18,
		19
	],
	night: [
		3,
		6,
		14,
		15
	]
}, w = {
	day: [
		5,
		4,
		5,
		4,
		2,
		4,
		5,
		4,
		5
	],
	night: [
		4,
		4,
		5,
		4,
		3,
		2,
		5,
		2,
		6
	]
}, ee = (e, t) => S[e].ends.filter((e) => e !== t).flatMap((t) => S.filter((n) => n.id !== e && n.ends.includes(t)).map((e) => ({
	node: e.id,
	entry: t
}))), T = [
	{
		name: "fastLearning",
		cost: 1,
		group: "learn",
		power: 2
	},
	{
		name: "nimbleDodge",
		cost: 1,
		group: "move",
		power: 1
	},
	{
		name: "sneakingBy",
		cost: 2,
		group: "move",
		power: 2
	},
	{
		name: "disguised",
		cost: 0,
		group: "hide",
		power: 2
	},
	{
		name: "newTactics",
		cost: 1,
		group: "learn",
		power: 1
	},
	{
		name: "sneakingBy",
		cost: 2,
		group: "move",
		power: 2
	},
	{
		name: "nimbleDodge",
		cost: 1,
		group: "move",
		power: 1
	},
	{
		name: "camouflaged",
		cost: 0,
		group: "hide",
		power: 1
	},
	{
		name: "moreTricks",
		cost: 2,
		group: "learn",
		power: 3
	},
	{
		name: "craftyIdeas",
		cost: 1,
		group: "learn",
		power: 2
	},
	{
		name: "sharpSenses",
		cost: 2,
		group: "learn",
		power: 2
	},
	{
		name: "cloudOfInk",
		cost: 3,
		group: "move",
		power: 3
	},
	{
		name: "suddenEvasion",
		cost: 2,
		group: "move",
		power: 2
	},
	{
		name: "takingChances",
		cost: 2,
		group: "move",
		power: 3
	},
	{
		name: "inPlainSight",
		cost: 0,
		group: "hide",
		power: 2
	},
	{
		name: "trickOfTheLight",
		cost: 0,
		group: "hide",
		power: 2
	},
	{
		name: "intoTheShadows",
		cost: 0,
		group: "hide",
		power: 2
	},
	...h.map((e) => ({
		name: e,
		cost: 0,
		group: "eat",
		power: 0
	}))
], E = [
	[
		"agile",
		4,
		"b"
	],
	[
		"hostile",
		10,
		"b"
	],
	[
		"swift",
		4,
		"b"
	],
	[
		"agile",
		5,
		"by"
	],
	[
		"ruthless",
		5,
		"by"
	],
	[
		"swift",
		5,
		"by"
	],
	[
		"observant",
		6,
		"br"
	],
	[
		"reactive",
		7,
		"br"
	],
	[
		"relentless",
		6,
		"br"
	],
	[
		"vigilant",
		7,
		"br"
	],
	[
		"daring",
		6,
		"br"
	],
	[
		"observant",
		4,
		"y"
	],
	[
		"ruthless",
		6,
		"y"
	],
	[
		"vigilant",
		8,
		"y"
	],
	[
		"hungry",
		8,
		"yr"
	],
	[
		"reactive",
		8,
		"yr"
	],
	[
		"daring",
		7,
		"r"
	],
	[
		"hungry",
		7,
		"r"
	],
	[
		"relentless",
		7,
		"r"
	],
	[
		"aggressive",
		10,
		"rr"
	]
].map(([e, t, n]) => ({
	name: e,
	cost: t,
	dice: n.split("").map((e) => ({
		b: "blue",
		y: "yellow",
		r: "red"
	})[e])
})), te = [
	"flight",
	"fight",
	"flinch"
], D = t.object({
	board: t.enum(["day", "night"]).default("day"),
	firstRole: t.enum(["octopus", "shark"]).default("octopus")
}).prefault({}), ne = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	revision: t.number().int().nonnegative(),
	id: t.string().max(30)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), O = t.object({
	id: t.number().int(),
	color: t.enum([
		"blue",
		"yellow",
		"red"
	]),
	value: t.number().int().min(0).max(6)
}), k = t.object({
	id: t.string(),
	kind: t.string(),
	card: t.number().optional(),
	zones: t.array(t.number()).optional(),
	nodes: t.array(t.number()).optional(),
	dice: t.array(t.number()).optional(),
	n: t.number().optional(),
	block: t.string().optional(),
	mode: t.string().optional(),
	entry: t.number().nullable().optional()
}), re = t.object({
	kind: t.string().nullable(),
	revealed: t.boolean()
}).nullable(), ie = t.object({
	players: t.array(t.string()),
	roles: t.object({
		octopus: t.string(),
		shark: t.string()
	}),
	config: D,
	revision: t.number(),
	turn: t.number(),
	phase: t.string(),
	prompt: t.string(),
	promptN: t.number().nullable(),
	actor: t.string().nullable(),
	board: t.array(re),
	spare: t.array(t.string()),
	eaten: t.array(t.object({
		kind: t.string(),
		used: t.boolean()
	})),
	actions: t.number(),
	handSize: t.number(),
	handCount: t.number(),
	deckCount: t.number(),
	discard: t.array(t.number()),
	octTrash: t.array(t.number()),
	played: t.array(t.number()),
	market: t.array(t.number().nullable()),
	marketCounts: t.array(t.number()),
	learnedEat: t.boolean(),
	pool: t.array(O),
	saved: t.array(t.object({
		die: O,
		turn: t.number()
	})),
	activeSaved: t.array(O),
	currents: t.array(O.nullable()),
	hunger: t.array(O),
	growth: t.array(O),
	growthLevel: t.number(),
	usedGrowth: t.array(O),
	energy: t.array(O),
	supply: t.object({
		blue: t.number(),
		yellow: t.number(),
		red: t.number()
	}),
	bagCount: t.number(),
	sharkMarket: t.array(t.number()),
	sharkHand: t.array(t.number()),
	sharkTrash: t.array(t.number()),
	sharkDiscard: t.array(t.number()),
	sharkNode: t.number(),
	entry: t.number().nullable(),
	attacks: t.array(t.object({
		zone: t.number(),
		die: O
	})),
	budget: t.number(),
	bought: t.boolean(),
	confront: t.object({
		available: t.array(t.number()),
		selected: t.array(t.boolean()),
		last: t.tuple([t.number(), t.number()]).nullable()
	}),
	winner: t.string().nullable(),
	reason: t.string().nullable(),
	events: t.array(t.object({
		key: t.string(),
		seq: t.number(),
		n: t.number().optional(),
		zones: t.array(t.number()).optional()
	}))
}), ae = t.object({
	role: t.enum(["octopus", "shark"]),
	hand: t.array(t.number()),
	board: t.array(re),
	bag: t.array(O),
	choices: t.array(k),
	confrontation: t.number().nullable(),
	inspectCards: t.array(t.number())
}), oe = {
	id: "kelp",
	tier: "alpha",
	releasedAt: "2026-11-04T21:03:00+08:00",
	mechanics: ["deduction", "deck-bag-building"],
	interactionTags: [],
	nameKey: "games.kelp.name",
	descKey: "games.kelp.desc",
	rulesKey: "games.kelp.rules",
	icon: "🐙",
	iconImg: "games/kelp.webp",
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#10a99e",
	search: {
		py: "zao ying zhui lie",
		init: "zyzl"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://drive.google.com/file/d/1V7YOUSt2n5tkr4Y9rZnk-z3Ts9hWQn9v/view" }
}, se = (e) => structuredClone(e);
function A(t, n) {
	return e(t.seed, t.cursor++, n);
}
function j(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = A(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function M(e, t) {
	return t === 0 ? [[]] : e.flatMap((n, r) => M(e.slice(r + 1), t - 1).map((e) => [n, ...e]));
}
var N = (e) => y.filter((t) => e.board[t] && !e.board[t].revealed), P = (e) => y.filter((t) => e.board[t]?.revealed), F = (e) => P(e).filter((t) => e.board[t].kind !== "octopus" && !g(e.board[t].kind)), I = (e) => e.board.findIndex((e) => e?.kind === "octopus"), ce = (e, t) => [...e.pool, ...e.activeSaved].find((e) => e.id === t);
function L(e, t) {
	let n = ce(e, t);
	return e.pool = e.pool.filter((e) => e.id !== t), e.activeSaved = e.activeSaved.filter((e) => e.id !== t), n;
}
function R(e, t, n, r) {
	e.events = [...e.events.slice(-23), {
		key: t,
		seq: e.revision + 1,
		...n === void 0 ? {} : { n },
		...r ? { zones: r } : {}
	}];
}
function z(e, t, n) {
	e.winner = t, e.reason = n, e.phase = "over", e.beat = 0;
}
function le(e, t) {
	e.hunger.push(t), R(e, "hunger", e.hunger.length), e.hunger.length >= 7 && z(e, "octopus", "exhaustion");
}
function B(e, t) {
	for (let n = 0; n < t && (e.deck.length || (e.deck = j(e, e.discard), e.discard = []), e.deck.length); n++) e.hand.push(e.deck.shift());
}
function ue(e) {
	return F(e).length && e.spare.some((e) => !g(e)) ? 99 : e.market.slice(0, 3).reduce((e, t) => e + t.length, 0) + (!e.learnedEat && F(e).length && e.market[3].length ? 1 : 0);
}
function de(e, t) {
	let n = T[t].name, r = N(e), i = P(e);
	if (T[t].group === "learn") return ue(e) >= T[t].power;
	if (t >= 17) {
		let n = e.board.findIndex((e) => e?.kind === h[t - 17]);
		return n >= 0 && v(I(e), n) && e.spare.includes("shell");
	}
	return n === "sneakingBy" ? r.length >= 2 : n === "cloudOfInk" ? r.filter((t) => t !== I(e)).length >= 2 : n === "takingChances" ? r.filter((e) => e !== 4).length >= 2 : n === "disguised" || n === "intoTheShadows" ? i.length >= 2 : T[t].group !== "hide" || i.length >= 1;
}
function V(e, t) {
	let n = T[t].cost;
	return n ? N(e).flatMap((e, t, n) => M(n, t + 1)).filter((r) => {
		let i = r.reduce((t, n) => t + (e.board[n].kind === "double" ? 2 : 1), 0);
		return i < n || r.some((t) => i - (e.board[t].kind === "double" ? 2 : 1) >= n) ? !1 : de({
			...e,
			board: e.board.map((e, t) => e && {
				...e,
				revealed: e.revealed || r.includes(t)
			})
		}, t);
	}) : de(e, t) ? [[]] : [];
}
function H(e, ...t) {
	e.tasks.unshift(...t);
}
function fe(e, t) {
	let n = T[t].name;
	if (T[t].group === "learn") H(e, {
		kind: "learn",
		n: T[t].power,
		card: t,
		gained: []
	});
	else if (n === "nimbleDodge" || n === "suddenEvasion") H(e, {
		kind: "swap",
		n: n === "suddenEvasion" ? 2 : 1
	});
	else if (n === "sneakingBy") H(e, {
		kind: "shuffle",
		n: 2
	});
	else if (n === "takingChances") H(e, {
		kind: "shuffle",
		n: 3,
		zones: [4]
	});
	else if (n === "cloudOfInk") {
		let t = I(e);
		e.board[t].revealed = !0, R(e, "octopusRevealed", t + 1, [t]), H(e, {
			kind: "inkHide",
			zones: [t]
		});
	} else if (T[t].group === "hide") H(e, {
		kind: "hide",
		n: T[t].power,
		min: [14, 15].includes(t) ? 1 : T[t].power,
		card: t
	});
	else if (t >= 17) {
		let n = h[t - 17], r = e.board.findIndex((e) => e?.kind === n);
		e.board[I(e)].revealed = !0, e.board[r] = {
			kind: "shell",
			revealed: !0
		}, e.spare.splice(e.spare.indexOf("shell"), 1), e.eaten.push({
			kind: n,
			used: !1
		}), e.octTrash.push(t), e.played = e.played.filter((e) => e !== t), R(e, "ate", t - 17), e.eaten.length === 4 && z(e, "octopus", "food");
	}
}
function pe(e) {
	e.discard.push(...e.played), e.played = [], e.phase = "draw", e.pool = [], e.activeSaved = [], e.rerolls = +(e.growthLevel >= 1) + +(e.growthLevel >= 3), e.extraMove = 0, H(e, {
		kind: "drawDice",
		role: "shark",
		n: e.growthLevel >= 4 ? 3 : 2
	});
}
function me(e) {
	e.phase = "octopus", e.actions = 2, e.learnedEat = !1, e.turn++, e.bought = !1, e.refreshed = !1, e.budget = -1, ![
		...e.bag,
		...e.pool,
		...e.activeSaved,
		...e.saved.map((e) => e.die)
	].some((e) => e.color === "red") && e.hunger.length === 6 && z(e, "octopus", "noStrike");
}
function he(e) {
	let t = e.energy.reduce((e, t) => e + t.value, 0);
	return t + (e.growthLevel >= 2 && t > 0 && t <= 5 ? 5 : 0);
}
function ge(e) {
	e.phase = "energy", e.energy.push(...e.pool, ...e.activeSaved), e.pool = [], e.activeSaved = [], e.budget = -1, e.bought = !1, e.refreshed = !1, e.energy.length > 3 && H(e, {
		kind: "overflow",
		role: "shark"
	});
}
function _e(e) {
	let t = [], n = 1 + e.extraMove;
	function r(n, i, a, o, s, c, l) {
		for (let u of ee(n, i)) {
			let n = e.currents[u.node], i = `${u.node}:${u.entry}:${a}:${o}`;
			if (l.includes(i)) continue;
			let d = [...s, u.node], f = [...c, u.entry];
			if (n) {
				if (n.value >= o) continue;
				r(u.node, u.entry, a, n.value, d, f, [...l, i]);
			} else a === 1 ? u.node !== e.sharkNode && t.push({
				id: "",
				kind: "swim",
				nodes: d,
				entry: u.entry
			}) : r(u.node, u.entry, a - 1, 7, d, f, [...l, i]);
		}
	}
	if (r(e.sharkNode, e.entry, n, 7, [], [], []), t.length) return t;
	let i = [{
		node: e.sharkNode,
		entry: e.entry,
		path: []
	}], a = 0, o = /* @__PURE__ */ new Set();
	for (; i.length && a++ < 30;) {
		let t = i.flatMap((e) => ee(e.node, e.entry).map((t) => ({
			...t,
			path: [...e.path, t.node]
		}))).filter((e) => {
			let t = `${e.node}:${e.entry}`;
			return !o.has(t) && (o.add(t), !0);
		}), n = t.filter((t) => e.currents[t.node]);
		if (n.length) return n.map((e) => ({
			id: "",
			kind: "forcedSwim",
			nodes: e.path,
			entry: e.entry
		}));
		i = t;
	}
	return [];
}
function ve(e) {
	return e.phase === "over" || e.beat || e.tasks[0]?.kind === "inkHide" ? null : e.tasks.length ? e.tasks[0].role ?? "octopus" : ["den", "octopus"].includes(e.phase) ? "octopus" : "shark";
}
function ye(e, t) {
	if (e.winner || e.beat) return [];
	let n = e.tasks[0];
	if (n?.kind === "confront") return e.confront[t] === null ? e.confront.available.map((e) => ({
		kind: "confront",
		n: e
	})) : [];
	if (ve(e) !== t) return [];
	let r = [...e.pool, ...e.activeSaved], i = [];
	if (n) {
		let t = n.card, r = n.n ?? 0;
		switch (n.kind) {
			case "pay": return V(e, t).map((e) => ({
				kind: "pay",
				zones: e,
				card: t
			}));
			case "hide": {
				let t = P(e).filter((e) => !n.zones?.includes(e));
				for (let e = n.min ?? r; e <= Math.min(r, t.length); e++) i.push(...M(t, e).map((e) => ({
					kind: "hide",
					zones: e
				})));
				return i;
			}
			case "swap": return y.flatMap((e) => y.filter((t) => e < t && v(e, t) && (!n.zones || n.zones.includes(e) || n.zones.includes(t))).map((t) => ({
				kind: "swap",
				zones: [e, t]
			}))).concat(n.optional ? [{
				kind: "skip",
				zones: []
			}] : []);
			case "shuffle": {
				let t = n.zones ?? [];
				return i.push(...M(N(e).filter((e) => !t.includes(e)), r - t.length).map((e) => ({
					kind: "shuffle",
					zones: [...t, ...e].sort((e, t) => e - t)
				}))), n.optional && i.push({ kind: "skip" }), i;
			}
			case "placeShuffled": return y.filter((t) => !e.board[t]).map((e) => ({
				kind: "placeShuffled",
				zones: [e]
			}));
			case "learn": return e.market.forEach((t, n) => {
				t.length && (n !== 3 || !e.learnedEat && F(e).length) && (n === 3 && r > 1 && F(e).length === 1 && e.market.slice(0, 3).reduce((e, t) => e + t.length, 0) < r - 1 || i.push({
					kind: "learnCard",
					card: t[0],
					n
				}));
			}), F(e).length && [...new Set(e.spare)].filter((e) => !g(e)).forEach((e) => i.push({
				kind: "learnBlock",
				block: e
			})), n.optional && i.push({ kind: "skip" }), i;
			case "replace": return F(e).flatMap((t) => {
				let r = e.tasks.find((e, t) => t > 0 && e.kind === "learn"), i = n.card === 9 && (!r || r.optional || (r.n ?? 0) <= e.market.slice(0, 3).reduce((e, t) => e + t.length, 0) || F(e).length > 1);
				return [{
					kind: "replace",
					zones: [t],
					block: n.block
				}, ...i ? [{
					kind: "replace",
					zones: [t],
					block: n.block,
					mode: "hidden"
				}] : []];
			});
			case "top": return [...(n.gained ?? []).filter((t) => e.discard.includes(t)).map((e) => ({
				kind: "top",
				card: e
			})), { kind: "skip" }];
			case "gainHand": return [...(n.gained ?? []).filter((t) => t < 17 && e.discard.includes(t)).map((e) => ({
				kind: "gainHand",
				card: e
			})), { kind: "skip" }];
			case "trash": return [
				...e.hand.map((e) => ({
					kind: "trash",
					card: e,
					mode: "hand"
				})),
				...e.discard.map((e) => ({
					kind: "trash",
					card: e,
					mode: "discard"
				})),
				{ kind: "skip" }
			];
			case "extraDraw": return [{ kind: "extraDraw" }, { kind: "skip" }];
			case "retrieveCard": return [...e.deck.map((e) => ({
				kind: "retrieveCard",
				card: e,
				mode: "deck"
			})), ...e.discard.map((e) => ({
				kind: "retrieveCard",
				card: e,
				mode: "discard"
			}))];
			case "removeCurrent": return [...e.currents.flatMap((e, t) => e ? [{
				kind: "removeCurrent",
				nodes: [t]
			}] : []), { kind: "skip" }];
			case "den": {
				let t = C[e.config.board], n = t.filter((t) => !e.currents[t]);
				return (n.length ? n : t).map((e) => ({
					kind: "den",
					nodes: [e]
				}));
			}
			case "drawDice": return e.bag.length >= r ? [{ kind: "drawDice" }] : e.currents.flatMap((e, t) => e ? [{
				kind: "recoverCurrent",
				nodes: [t]
			}] : []);
			case "reactive": return [...new Set(e.bag.map((e) => e.color))].map((e) => ({
				kind: "replacementDie",
				block: e
			}));
			case "trap": return [{ kind: "triggerTrap" }, ...e.sharkHand.filter((e) => E[e].name === "observant").map((e) => ({
				kind: "ignoreTrap",
				card: e
			}))];
			case "overflow": return M(e.energy.map((e) => e.id), 3).map((e) => ({
				kind: "keepEnergy",
				dice: e
			}));
			case "hungerPayment": return e.energy.map((e) => ({
				kind: "hungerPayment",
				dice: [e.id]
			}));
			default: return [];
		}
	}
	if (e.phase === "den") return C[e.config.board].map((e) => ({
		kind: "den",
		nodes: [e]
	}));
	if (e.phase === "octopus") return e.eaten.forEach((e, t) => {
		e.used || i.push({
			kind: "foodAbility",
			block: e.kind,
			n: t
		});
	}), e.actions === 0 ? [...i, { kind: "endTurn" }] : (e.hand.length < e.handSize && i.push({ kind: "drawCards" }), e.hand.length && (i.push(...e.hand.filter((t) => V(e, t).length).map((e) => ({
		kind: "play",
		card: e
	}))), i.push(...e.hand.map((e) => ({
		kind: "discard",
		card: e
	})))), i);
	let a = e.saved.filter((t) => t.turn < e.turn).map((e) => ({
		kind: "useSaved",
		dice: [e.die.id]
	}));
	if (e.phase === "draw") return i.push({ kind: "roll" }), e.sharkHand.filter((e) => E[e].name === "reactive").forEach((t) => i.push(...M(e.pool.map((e) => e.id), 2).map((e) => ({
		kind: "reactive",
		card: t,
		dice: e
	})))), i;
	if (e.phase === "roll") return i.push({ kind: "finishRoll" }), e.rerolls > 0 && i.push(...e.pool.map((e) => ({
		kind: "reroll",
		dice: [e.id]
	}))), e.sharkHand.forEach((t) => {
		let n = E[t].name;
		if (n === "hungry" && i.push({
			kind: "hungry",
			card: t
		}), n === "relentless") for (let n of [1, 2]) i.push(...M(e.pool.map((e) => e.id), n).map((e) => ({
			kind: "relentless",
			card: t,
			dice: e
		})));
	}), i;
	if (e.phase === "currents") return i.push({ kind: "finishCurrents" }, ...a), r.filter((e) => e.color === "blue").forEach((t) => e.currents.forEach((n, r) => {
		!n && r !== e.sharkNode && i.push({
			kind: "current",
			dice: [t.id],
			nodes: [r]
		});
	})), e.sharkHand.forEach((t) => {
		let n = E[t].name;
		n === "agile" && e.entry !== null && i.push({
			kind: "agile",
			card: t
		}), n === "swift" && i.push({
			kind: "swift",
			card: t
		}), n === "vigilant" && i.push(...e.pool.map((e) => ({
			kind: "vigilant",
			card: t,
			dice: [e.id]
		}))), n === "ruthless" && e.pool.forEach((e) => {
			for (let n = 1; n <= Math.min(t === 4 ? 3 : 2, 6 - e.value); n++) i.push({
				kind: "ruthless",
				card: t,
				dice: [e.id],
				n
			});
		}), n === "daring" && e.pool.filter((e) => e.color === "red").forEach((n) => e.pool.filter((e) => e.id !== n.id).forEach((e) => i.push({
			kind: "daring",
			card: t,
			dice: [n.id, e.id]
		})));
	}), i;
	if (e.phase === "move") return _e(e);
	if (e.phase === "attack") return i.push({ kind: "resolveAttacks" }, ...a), e.attacks.length < 2 && r.filter((e) => e.color !== "blue").forEach((t) => S[e.sharkNode].zones.forEach((n) => {
		let r = e.board[n];
		r && !e.attacks.some((e) => e.zone === n) && t.value >= w[e.config.board][n] && (!r.revealed || t.color === "red" && r.kind === "octopus") && i.push({
			kind: "assignAttack",
			dice: [t.id],
			zones: [n]
		});
	})), i.push(...e.attacks.map((e, t) => ({
		kind: "unassign",
		n: t,
		zones: [e.zone]
	}))), i;
	if (e.phase === "resolve") return e.attacks.map((e, t) => ({
		kind: "reveal",
		n: t,
		zones: [e.zone]
	}));
	if (e.phase === "energy") {
		if (e.budget < 0) {
			let t = he(e), n = e.sharkMarket.filter((e) => e >= 0 && E[e].cost <= t);
			return (e.energy.length < 3 || !n.length) && i.push({ kind: "storeEnergy" }), n.length && i.push({ kind: "spendEnergy" }), [...i, ...a];
		}
		return e.sharkMarket.forEach((t, n) => {
			t >= 0 && E[t].cost <= e.budget && i.push({
				kind: "buy",
				card: t,
				n
			});
		}), e.bought && i.push({ kind: "finishBuying" }), !e.bought && !e.refreshed && e.sharkDeck.length && e.energy.filter((e) => e.value > 1).forEach((t) => e.sharkMarket.forEach((n, r) => {
			let a = e.sharkMarket.filter((t) => t >= 0 && E[t].cost <= e.budget);
			(a.length !== 1 || a[0] !== n) && e.sharkMarket.some((t, n) => n !== r && t >= 0 && E[t].cost <= e.budget - 1) && i.push({
				kind: "refresh",
				dice: [t.id],
				n: r
			});
		})), i;
	}
	return i;
}
function be(e, t) {
	return ye(e, t).map((e, t) => ({
		...e,
		id: String(t)
	}));
}
function xe(e, t) {
	t.card === 0 && t.gained?.length && H(e, {
		kind: "top",
		gained: t.gained
	}), t.card === 10 && t.gained?.some((e) => e < 17) && H(e, {
		kind: "gainHand",
		gained: t.gained
	}), (t.card === 4 || t.card === 8) && H(e, { kind: "trash" });
}
function U(e, t) {
	e.sharkHand.splice(e.sharkHand.indexOf(t), 1), e.sharkTrash.push(t);
}
function Se(e, t) {
	let n = j(e, t.map((t) => ({
		...e.board[t],
		revealed: !1
	})));
	t.forEach((t) => {
		e.board[t] = null;
	}), R(e, "shuffled", void 0, t), H(e, ...n.map((e) => ({
		kind: "placeShuffled",
		role: "shark",
		block: e.kind
	})));
}
function Ce(e, t) {
	t.color === "red" ? le(e, t) : e.usedGrowth.push(t);
}
function we(e) {
	if (e.winner) return;
	let t = e.tasks[0];
	if (t?.kind === "attackDone") {
		e.tasks.shift(), Ce(e, t.die);
		return;
	}
	if (t?.kind === "inkHide") {
		let n = t.zones[0];
		e.tasks.shift(), e.board[n].revealed = !1, H(e, {
			kind: "shuffle",
			n: 3,
			zones: [n]
		});
		return;
	}
	if (e.phase === "growth" && !e.tasks.length) {
		if (e.usedGrowth.length) {
			let t = e.usedGrowth.shift();
			e.growthLevel >= 4 ? e.bag.push(t) : (e.growth.push(t), e.growth.length === 3 && (e.growthLevel++, e.bag.push(...e.growth), e.growth = [], R(e, "growth", e.growthLevel)));
		} else ge(e);
	}
}
function Te(e, t, n) {
	let r = e.tasks[0], i = t.card, a = t.zones ?? [], o = t.dice ?? [], s = t.nodes ?? [], c = () => e.tasks.shift(), l = (t, r = {}) => {
		n.push({
			kind: t,
			data: r
		}), e.beat = 540;
	};
	switch (t.kind) {
		case "skip":
			c();
			break;
		case "den": {
			let t = s[0];
			e.currents[t] && (e.bag.push(e.currents[t]), e.currents[t] = null);
			let n = e.sharkNode;
			e.sharkNode = t, e.entry = null, r ? c() : e.phase = "octopus", l("swim", { nodes: [n, t] });
			break;
		}
		case "play": {
			e.hand.splice(e.hand.indexOf(i), 1), e.played.push(i), e.actions--, R(e, "played", i);
			let t = V(e, i);
			if (T[i].cost ? H(e, {
				kind: "pay",
				card: i
			}) : fe(e, i), !t.length) throw Error("Legal card has no complete payment");
			l("card", { card: i });
			break;
		}
		case "pay":
			a.forEach((t) => {
				e.board[t].revealed = !0;
			}), c(), fe(e, i), l("blocks", { zones: a });
			break;
		case "drawCards":
			B(e, Math.max(0, e.handSize - e.hand.length)), e.actions--, l("draw");
			break;
		case "discard":
			e.hand.splice(e.hand.indexOf(i), 1), e.discard.push(i), e.actions--, P(e).length && H(e, {
				kind: "hide",
				n: 1
			}), l("card", { card: i });
			break;
		case "endTurn":
			pe(e);
			break;
		case "hide":
			a.forEach((t) => {
				e.board[t].revealed = !1;
			}), c(), r?.card === 7 && H(e, {
				kind: "swap",
				n: 1,
				zones: a,
				optional: !0
			}), r?.card === 14 && H(e, { kind: "extraDraw" }), r?.card === 15 && H(e, { kind: "trash" }), r?.card === 16 && Se(e, a), l("blocks", { zones: a });
			break;
		case "swap":
			[e.board[a[0]], e.board[a[1]]] = [e.board[a[1]], e.board[a[0]]], (r.n ?? 1) > 1 ? r.n-- : c(), R(e, "swapped", void 0, a), l("swap", { zones: a });
			break;
		case "shuffle":
			c(), Se(e, a), l("shuffle", { zones: a });
			break;
		case "placeShuffled":
			e.board[a[0]] = {
				kind: r.block,
				revealed: !1
			}, c(), l("blocks", { zones: a });
			break;
		case "learnCard": {
			let n = t.n, i = e.market[n].shift();
			r.gained.push(i), r.n--, e.discard.push(i), r.n === 0 && (c(), xe(e, r)), n === 3 && (e.learnedEat = !0, H(e, {
				kind: "replace",
				block: h[i - 17],
				card: r.card
			})), l("learn", { card: i });
			break;
		}
		case "learnBlock":
			r.n--, r.n === 0 && (c(), xe(e, r)), H(e, {
				kind: "replace",
				block: t.block,
				card: r.card
			});
			break;
		case "replace": {
			let n = a[0], r = t.block;
			e.spare.splice(e.spare.indexOf(r), 1), e.spare.push(e.board[n].kind), e.board[n] = {
				kind: r,
				revealed: t.mode !== "hidden"
			}, c(), l("blocks", { zones: a });
			break;
		}
		case "top":
			e.discard.splice(e.discard.indexOf(i), 1), e.deck.unshift(i), c();
			break;
		case "gainHand":
			e.discard.splice(e.discard.indexOf(i), 1), e.hand.push(i), c(), l("draw");
			break;
		case "trash": {
			let n = t.mode === "hand" ? e.hand : e.discard;
			n.splice(n.indexOf(i), 1), e.octTrash.push(i), c(), l("card", { card: i });
			break;
		}
		case "extraDraw":
			B(e, 1), c(), l("draw");
			break;
		case "foodAbility":
			e.eaten[t.n].used = !0, t.block === "crab" && (e.handSize = 5, B(e, Math.max(0, 5 - e.hand.length))), t.block === "lobster" && e.board.forEach((e) => {
				e && (e.revealed = !1);
			}), t.block === "snail" && (e.deck.length || e.discard.length) && H(e, { kind: "retrieveCard" }), t.block === "abalone" && H(e, {
				kind: "learn",
				n: 3,
				gained: [],
				optional: !0
			}), l("food", { n: t.n });
			break;
		case "retrieveCard": {
			let n = t.mode === "deck" ? e.deck : e.discard;
			n.splice(n.indexOf(i), 1), e.hand.push(i), t.mode === "deck" && (e.deck = j(e, e.deck)), c(), l("draw");
			break;
		}
		case "removeCurrent":
			e.bag.push(e.currents[s[0]]), e.currents[s[0]] = null, r.n--, (!r.n || !e.currents.some(Boolean)) && c(), l("current", { nodes: s });
			break;
		case "recoverCurrent":
			e.bag.push(e.currents[s[0]]), e.currents[s[0]] = null, l("current", { nodes: s });
			break;
		case "drawDice":
			for (let t = 0; t < r.n; t++) {
				let t = A(e, e.bag.length), n = e.bag.splice(t, 1)[0];
				n.value = r.mode === "rolled" ? A(e, 6) + 1 : 0, e.pool.push(n);
			}
			c(), e.phase === "draw" && (e.phase = "draw"), l("dice");
			break;
		case "reactive":
			U(e, i), o.forEach((t) => e.bag.push(L(e, t))), H(e, {
				kind: "reactive",
				role: "shark"
			});
			break;
		case "replacementDie": {
			let n = e.bag.findIndex((e) => e.color === t.block), r = e.bag.splice(n, 1)[0];
			r.value = 0, e.pool.push(r), c();
			break;
		}
		case "roll":
			e.pool.forEach((t) => {
				t.value = A(e, 6) + 1;
			}), e.phase = "roll", l("dice");
			break;
		case "reroll":
			e.rerolls--, e.pool.find((e) => e.id === o[0]).value = A(e, 6) + 1, l("dice");
			break;
		case "relentless":
			U(e, i), o.forEach((t) => {
				e.pool.find((e) => e.id === t).value = A(e, 6) + 1;
			}), l("dice");
			break;
		case "hungry":
			U(e, i), H(e, {
				kind: "drawDice",
				role: "shark",
				n: 1,
				mode: "rolled"
			});
			break;
		case "finishRoll":
			e.phase = "currents";
			break;
		case "useSaved": {
			let t = e.saved.findIndex((e) => e.die.id === o[0]), n = e.saved.splice(t, 1)[0].die;
			e.phase === "energy" ? (e.energy.push(n), e.energy.length > 3 && H(e, {
				kind: "overflow",
				role: "shark"
			})) : e.activeSaved.push(n);
			break;
		}
		case "current":
			e.currents[s[0]] = L(e, o[0]), l("current", { nodes: s });
			break;
		case "agile":
			e.entry = S[e.sharkNode].ends.find((t) => t !== e.entry), U(e, i);
			break;
		case "swift":
			e.extraMove++, U(e, i);
			break;
		case "vigilant":
			e.saved.push({
				die: L(e, o[0]),
				turn: e.turn
			}), U(e, i);
			break;
		case "ruthless":
			e.pool.find((e) => e.id === o[0]).value += t.n, U(e, i), l("dice");
			break;
		case "daring": {
			let t = e.pool.find((e) => e.id === o[0]);
			t.value = 6, le(e, L(e, o[1])), U(e, i), l("dice");
			break;
		}
		case "finishCurrents":
			e.phase = "move";
			break;
		case "swim":
		case "forcedSwim": {
			let n = e.sharkNode, r = s.find((t) => e.currents[t]);
			if (t.kind === "forcedSwim") {
				let t = s[s.length - 1];
				e.bag.push(e.currents[t]), e.currents[t] = null;
			} else r !== void 0 && (e.usedGrowth.push(e.currents[r]), e.currents[r] = null);
			e.sharkNode = s[s.length - 1], e.entry = t.entry, e.phase = "attack", l("swim", { nodes: [n, ...s] });
			break;
		}
		case "assignAttack":
			e.attacks.push({
				zone: a[0],
				die: L(e, o[0])
			});
			break;
		case "unassign":
			e.pool.push(e.attacks.splice(t.n, 1)[0].die);
			break;
		case "resolveAttacks":
			e.phase = e.attacks.length ? "resolve" : "growth";
			break;
		case "reveal": {
			let n = e.attacks.splice(t.n, 1)[0], r = e.board[n.zone];
			if (!S[e.sharkNode].zones.includes(n.zone)) {
				e.bag.push(n.die);
				break;
			}
			let i = !r.revealed;
			r.revealed = !0, H(e, {
				kind: "attackDone",
				role: "shark",
				die: n.die
			}), r.kind === "octopus" && n.die.color === "red" ? (e.confront.octopus = null, e.confront.shark = null, H(e, {
				kind: "confront",
				role: "shark"
			})) : i && _(r.kind) && H(e, {
				kind: "trap",
				role: "shark",
				block: r.kind,
				zones: [n.zone]
			}), R(e, "revealed", n.zone), l("blocks", { zones: [n.zone] });
			break;
		}
		case "ignoreTrap":
			U(e, i), c();
			break;
		case "triggerTrap":
			c(), r.block === "hideTrap" && H(e, {
				kind: "hide",
				n: 2,
				min: 0,
				zones: r.zones
			}), (r.block === "currentTrap" || r.block === "currentsTrap") && H(e, {
				kind: "removeCurrent",
				n: r.block === "currentTrap" ? 1 : 2
			}), r.block === "denTrap" && H(e, { kind: "den" });
			break;
		case "keepEnergy": {
			let t = new Set(o);
			e.bag.push(...e.energy.filter((e) => !t.has(e.id))), e.energy = e.energy.filter((e) => t.has(e.id)), c();
			break;
		}
		case "storeEnergy":
			e.energy.length === 3 && (e.bag.push(...e.energy), e.energy = []), me(e);
			break;
		case "spendEnergy":
			e.budget = he(e);
			break;
		case "refresh":
			e.energy.find((e) => e.id === o[0]).value--, e.budget--, e.sharkDiscard.push(e.sharkMarket[t.n]), e.sharkMarket[t.n] = e.sharkDeck.shift(), e.refreshed = !0, l("market");
			break;
		case "buy":
			e.budget -= E[i].cost, e.bought = !0, e.sharkMarket[t.n] = e.sharkDeck.shift() ?? -1, E[i].dice.forEach((t) => {
				if (e.supply[t] > 0) {
					let n = 100 + {
						blue: 0,
						yellow: 30,
						red: 60
					}[t] + e.supply[t]--;
					e.bag.push({
						id: n,
						color: t,
						value: 0
					});
				}
			}), E[i].name === "hostile" ? (e.sharkTrash.push(i), e.confront.available.length > 1 && e.confront.available.splice(A(e, e.confront.available.length), 1)) : E[i].name === "aggressive" ? e.sharkTrash.push(i) : e.sharkHand.push(i), R(e, "bought", i), l("market");
			break;
		case "finishBuying":
			H(e, {
				kind: "hungerPayment",
				role: "shark"
			});
			break;
		case "hungerPayment": {
			let t = e.energy.findIndex((e) => e.id === o[0]);
			le(e, e.energy.splice(t, 1)[0]), e.bag.push(...e.energy), e.energy = [], c(), e.winner || me(e);
			break;
		}
	}
}
function Ee(e, t) {
	let n = e.confront.octopus, r = e.confront.shark;
	if (n !== null && r !== null) {
		if (e.confront.last = [n, r], e.tasks.shift(), n === r) z(e, "shark", "caught");
		else {
			if (e.confront.available = e.confront.available.filter((e) => e !== n), n === 0) {
				let t = I(e);
				e.board[t].revealed = !1, N(e).length >= 2 && H(e, {
					kind: "shuffle",
					n: 2,
					zones: [t],
					optional: !0
				});
			}
			n === 1 && H(e, { kind: "den" }), n === 2 && H(e, {
				kind: "swap",
				n: 1,
				zones: [I(e)]
			}), R(e, "escaped", n);
		}
		t.push({
			kind: "confront",
			data: { cards: [n, r] }
		}), e.beat = 540;
	}
}
var De = {
	meta: oe,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ne,
		publicView: ie,
		privateView: ae,
		config: D
	},
	setup(e, t, n) {
		let r = {
			players: t,
			roles: e.firstRole === "octopus" ? {
				octopus: t[0],
				shark: t[1]
			} : {
				octopus: t[1],
				shark: t[0]
			},
			config: e,
			seed: n,
			cursor: 0,
			revision: 0,
			turn: 1,
			phase: "den",
			board: [],
			spare: [
				"shell",
				"double",
				"currentTrap",
				"currentsTrap",
				"denTrap",
				...h
			],
			eaten: [],
			hand: [0],
			deck: [],
			discard: [],
			octTrash: [],
			played: [],
			market: [],
			learnedEat: !1,
			actions: 2,
			handSize: 4,
			bag: Array.from({ length: 11 }, (e, t) => ({
				id: t,
				color: t < 7 ? "blue" : t < 10 ? "yellow" : "red",
				value: 0
			})),
			supply: {
				blue: 8,
				yellow: 7,
				red: 9
			},
			pool: [],
			activeSaved: [],
			saved: [],
			currents: Array(20).fill(null),
			hunger: [],
			growth: [],
			growthLevel: 0,
			usedGrowth: [],
			energy: [],
			sharkDeck: [],
			sharkMarket: [],
			sharkHand: [],
			sharkTrash: [],
			sharkDiscard: [],
			sharkNode: C[e.board][0],
			entry: null,
			rerolls: 0,
			extraMove: 0,
			budget: -1,
			bought: !1,
			refreshed: !1,
			attacks: [],
			tasks: [],
			confront: {
				available: [
					0,
					1,
					2
				],
				octopus: null,
				shark: null,
				last: null
			},
			winner: null,
			reason: null,
			beat: 0,
			events: []
		};
		return r.board = j(r, [
			"octopus",
			"hideTrap",
			...Array(7).fill("shell")
		]).map((e) => ({
			kind: e,
			revealed: !1
		})), r.deck = j(r, [
			1,
			2,
			3,
			4,
			5,
			6,
			7
		]), B(r, 3), r.market = [
			j(r, [
				11,
				12,
				13
			]),
			j(r, [
				14,
				15,
				16
			]),
			j(r, [
				8,
				9,
				10
			]),
			j(r, [
				17,
				18,
				19,
				20
			])
		], r.sharkDeck = j(r, Array.from({ length: 20 }, (e, t) => t)), r.sharkMarket = r.sharkDeck.splice(0, 4), { state: r };
	},
	reduce(e, t, n) {
		if (e.winner) return { code: "games.kelp.invalidAction" };
		let r = se(e), i = [];
		if (t.type === "tick") {
			if (n.by !== "$engine" || !r.beat && !Oe(r)) return { code: "games.kelp.invalidAction" };
			if (r.beat) r.beat = 0;
			else {
				let e = r.tasks[0]?.kind === "inkHide" ? "blocks" : r.tasks[0]?.kind === "attackDone" && r.tasks[0].die?.color === "red" ? "hunger" : "growth";
				we(r), i.push({ kind: e }), r.winner || (r.beat = 540);
			}
		} else {
			if (t.revision !== r.revision) return { code: "games.kelp.staleAction" };
			let e = n.by === r.roles.octopus ? "octopus" : n.by === r.roles.shark ? "shark" : null;
			if (!e) return { code: "games.kelp.invalidAction" };
			let a = be(r, e).find((e) => e.id === t.id);
			if (!a) return { code: "games.kelp.invalidAction" };
			a.kind === "confront" ? (r.confront[e] = a.n, Ee(r, i)) : Te(r, a, i);
		}
		!r.winner && r.phase === "resolve" && !r.tasks.length && !r.attacks.length && (r.phase = "growth"), !r.winner && r.hunger.length === 6 && ![
			...r.bag,
			...r.pool,
			...r.activeSaved,
			...r.saved.map((e) => e.die),
			...r.attacks.map((e) => e.die)
		].some((e) => e.color === "red") && z(r, "octopus", "noStrike");
		let a = y.filter((t) => JSON.stringify(e.board[t]) !== JSON.stringify(r.board[t]));
		if (a.length && !i.length && i.push({
			kind: "blocks",
			data: { zones: a }
		}), i.length) {
			let t = (e) => a.map((t) => ({
				zone: t,
				kind: e.board[t]?.revealed ? e.board[t].kind : null,
				revealed: e.board[t]?.revealed ?? !1,
				empty: !e.board[t]
			})), n = (e) => a.map((t) => ({
				zone: t,
				kind: e.board[t]?.kind ?? null,
				revealed: e.board[t]?.revealed ?? !1,
				empty: !e.board[t]
			}));
			i.forEach((i) => {
				i.data = {
					...i.data,
					before: t(e),
					after: t(r),
					dice: r.pool,
					fromNode: e.sharkNode,
					toNode: r.sharkNode,
					entry: r.entry
				}, a.length && (i.for = [r.roles.octopus], i.secret = {
					before: n(e),
					after: n(r)
				});
			}), r.winner || (r.beat = 540);
		}
		return r.revision++, {
			state: r,
			...i.length ? { fx: i } : {}
		};
	},
	viewFor(e, t) {
		let n = t === e.roles.octopus ? "octopus" : t === e.roles.shark ? "shark" : null, r = e.tasks[0], i = r?.kind === "confront" ? null : ve(e), a = {
			players: e.players,
			roles: e.roles,
			config: e.config,
			revision: e.revision,
			turn: e.turn,
			phase: e.phase,
			prompt: e.beat ? "animating" : r?.kind ?? e.phase,
			promptN: r?.n ?? null,
			actor: i ? e.roles[i] : null,
			board: e.board.map((t) => t && {
				kind: t.revealed || e.winner ? t.kind : null,
				revealed: t.revealed
			}),
			spare: e.spare,
			eaten: e.eaten,
			actions: e.actions,
			handSize: e.handSize,
			handCount: e.hand.length,
			deckCount: e.deck.length,
			discard: e.discard,
			octTrash: e.octTrash,
			played: e.played,
			market: e.market.map((t, n) => n === 3 && e.learnedEat ? null : t[0] ?? null),
			marketCounts: e.market.map((e) => e.length),
			learnedEat: e.learnedEat,
			pool: e.pool,
			activeSaved: e.activeSaved,
			saved: e.saved,
			currents: e.currents,
			hunger: e.hunger,
			growth: e.growth,
			growthLevel: e.growthLevel,
			usedGrowth: e.usedGrowth,
			energy: e.energy,
			supply: e.supply,
			bagCount: e.bag.length,
			sharkMarket: e.sharkMarket,
			sharkHand: e.sharkHand,
			sharkTrash: e.sharkTrash,
			sharkDiscard: e.sharkDiscard,
			sharkNode: e.sharkNode,
			entry: e.entry,
			attacks: e.attacks,
			budget: e.budget,
			bought: e.bought,
			confront: {
				available: e.confront.available,
				selected: [e.confront.octopus !== null, e.confront.shark !== null],
				last: e.confront.last
			},
			winner: e.winner,
			reason: e.reason,
			events: e.events
		};
		return n ? {
			public: a,
			private: {
				role: n,
				hand: n === "octopus" ? e.hand : [],
				board: n === "octopus" ? e.board : a.board,
				bag: n === "shark" ? e.bag : [],
				choices: be(e, n),
				confrontation: e.confront[n],
				inspectCards: n === "octopus" ? r?.kind === "retrieveCard" ? [...e.deck, ...e.discard] : r?.kind === "gainHand" ? (r.gained ?? []).filter((t) => t < 17 && e.discard.includes(t)) : [] : []
			}
		} : { public: a };
	},
	status(e) {
		return e.winner ? {
			phase: "over",
			winner: [e.roles[e.winner]],
			ranking: [e.roles[e.winner], e.roles[e.winner === "shark" ? "octopus" : "shark"]]
		} : { phase: e.phase };
	},
	nextTickIn(e) {
		return e.winner ? null : e.beat || (Oe(e) ? 60 : null);
	}
};
function Oe(e) {
	return !e.winner && (e.tasks[0]?.kind === "attackDone" || e.tasks[0]?.kind === "inkHide" || e.phase === "growth" && !e.tasks.length);
}
//#endregion
//#region src/games/kelp/components.tsx
function W() {
	let e = l();
	return (t, n) => e(`games.kelp.${t}`, n);
}
var G = (e) => s(`games/kelp/${e}.svg`);
function K() {
	return /* @__PURE__ */ d("svg", {
		className: "kelp-legal-ring",
		"aria-hidden": !0,
		children: /* @__PURE__ */ d("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "7"
		})
	});
}
function q({ name: e, className: t, style: n, children: r }) {
	let { ref: i, hidden: a } = c(`kelp:${e}`);
	return /* @__PURE__ */ d("div", {
		ref: i,
		className: t,
		style: {
			...n,
			visibility: a ? "hidden" : void 0
		},
		children: r
	});
}
function J({ kind: e, revealed: t = !0 }) {
	return /* @__PURE__ */ f("span", {
		className: "kelp-block-face",
		"data-revealed": t,
		children: [/* @__PURE__ */ d("img", {
			src: G(`icon-${e ?? "hidden"}`),
			alt: "",
			draggable: !1
		}), e && !t && /* @__PURE__ */ d("span", {
			className: "kelp-secret-mark",
			"aria-hidden": !0,
			children: "◈"
		})]
	});
}
function Y({ die: e }) {
	let t = W();
	return /* @__PURE__ */ f("span", {
		className: "kelp-die",
		"data-color": e.color,
		"aria-label": `${t(e.color)} ${e.value || "?"}`,
		children: [
			/* @__PURE__ */ d("svg", {
				viewBox: "0 0 30 30",
				"aria-hidden": !0,
				children: ([
					[],
					[4],
					[0, 8],
					[
						0,
						4,
						8
					],
					[
						0,
						2,
						6,
						8
					],
					[
						0,
						2,
						4,
						6,
						8
					],
					[
						0,
						2,
						3,
						5,
						6,
						8
					]
				][e.value] ?? []).map((e) => /* @__PURE__ */ d("circle", {
					cx: 7 + e % 3 * 8,
					cy: 7 + Math.floor(e / 3) * 8,
					r: "2.1"
				}, e))
			}),
			e.value === 0 && /* @__PURE__ */ d("span", { children: "?" }),
			/* @__PURE__ */ d("small", {
				"aria-hidden": !0,
				children: e.color === "blue" ? "≈" : e.color === "yellow" ? "◉" : "▲"
			})
		]
	});
}
function ke({ card: e, role: t }) {
	let n = W(), r = t === "octopus" ? T[e] : E[e], i = r.name, a = t === "octopus" ? T[e].group : "shark";
	return /* @__PURE__ */ f("span", {
		className: "kelp-card",
		"data-group": a,
		children: [
			/* @__PURE__ */ f("span", {
				className: "kelp-card-art",
				children: [/* @__PURE__ */ d("img", {
					src: G(`${t}-${e}`),
					alt: "",
					draggable: !1
				}), /* @__PURE__ */ f("b", {
					className: "kelp-price",
					title: n(t === "octopus" ? "cost" : "price", { n: r.cost }),
					children: [t === "octopus" && /* @__PURE__ */ d("span", {
						"aria-hidden": !0,
						children: "◧"
					}), r.cost]
				})]
			}),
			/* @__PURE__ */ f("span", {
				className: "kelp-card-title",
				children: [n(i), /* @__PURE__ */ d("small", { children: n(a) })]
			}),
			t === "shark" && /* @__PURE__ */ d("span", {
				className: "kelp-card-dice",
				children: E[e].dice.map((e, t) => /* @__PURE__ */ d(Y, { die: {
					color: e,
					value: 0,
					id: t
				} }, t))
			}),
			/* @__PURE__ */ d("span", {
				className: "kelp-card-effect",
				children: n(`e_${i}`, { n: e === 4 ? 3 : 2 })
			})
		]
	});
}
//#endregion
//#region src/games/kelp/view-player.tsx
function Ae(e) {
	return a(), /* @__PURE__ */ d(je, {
		pub: e.public,
		priv: e.private,
		...e
	});
}
function je({ pub: e, priv: t, members: n, send: r }) {
	let a = W(), [s, c] = i(null), [l, p] = i(!1), [m, h] = i(null), g = t?.choices ?? [], _ = s?.revision === e.revision ? s : null, v = _ ? g.filter((e) => _.ids.includes(e.id)) : g, y = (e) => n.find((t) => t.rid === e)?.name ?? e, b = (t) => {
		c(null), h(null), r({
			type: "choose",
			revision: e.revision,
			id: t.id
		});
	};
	function x(t, n) {
		if (t.length) {
			if (!(t.length > 1 || t[0].zones && t[0].zones.length > 1 || t[0].dice && t[0].dice.length > 1 || t[0].nodes && t[0].nodes.length > 1) && !_) {
				b(t[0]);
				return;
			}
			c({
				revision: e.revision,
				zones: _?.zones ?? [],
				dice: _?.dice ?? [],
				nodes: _?.nodes ?? [],
				..._,
				...n,
				ids: t.map((e) => e.id)
			});
		}
	}
	let S = (e, t) => v.filter((n) => e === "nodes" && ["swim", "forcedSwim"].includes(n.kind) ? n.nodes?.at(-1) === t : e === "dice" && n.kind === "daring" ? n.dice?.[_?.dice.length ?? 0] === t : n[e]?.includes(t)), C = (e, t) => x(S(e, t), { [e]: [.../* @__PURE__ */ new Set([..._?.[e] ?? [], t])] }), w = (n, r, i) => r !== t?.role || i === "trash" ? [] : v.filter((t) => i === "discard" && ![
		"trash",
		"top",
		"retrieveCard",
		"gainHand"
	].includes(t.kind) ? !1 : (t.card === n || i === "market" && r === "shark" && t.kind === "refresh" && e.sharkMarket[t.n] === n) && (i === "hand" && r === "octopus" && e.prompt === "octopus" ? t.kind === (l ? "discard" : "play") : i !== "market" || [
		"buy",
		"learnCard",
		"refresh"
	].includes(t.kind))), ee = _ ? v.filter((t) => {
		if (t.kind === "refresh" && _.card !== e.sharkMarket[t.n]) return !1;
		let n = !t.zones?.length || t.zones.every((e) => _.zones.includes(e)), r = !t.dice?.length || t.dice.every((e) => _.dice.includes(e)), i = !t.nodes?.length || (["swim", "forcedSwim"].includes(t.kind) ? _.nodes.includes(t.nodes.at(-1)) : t.nodes.every((e) => _.nodes.includes(e)));
		return n && r && i;
	}) : [], D = (e) => [
		a(`c_${e.kind}`, { n: e.n ?? 0 }),
		e.mode ? a(`mode_${e.mode}`) : "",
		e.nodes && e.nodes.length > 1 ? e.nodes.map((e) => e + 1).join(" → ") : ""
	].filter(Boolean).join(" · "), ne = (e) => !e.card && e.card !== 0 && !e.zones?.length && !e.dice?.length && !e.nodes?.length && !e.block && e.kind !== "confront", O = (e, t, n) => /* @__PURE__ */ d("div", {
		className: "kelp-cards",
		children: e.filter((e) => e >= 0).map((e, r) => {
			let i = w(e, t, n);
			return /* @__PURE__ */ f("button", {
				type: "button",
				className: "kelp-card-object",
				"data-legal": i.length > 0,
				"data-selected": _?.card === e,
				onClick: () => i.length ? x(i, { card: e }) : h(`${t}:${e}`),
				"aria-label": `${a((t === "octopus" ? T : E)[e].name)}${i.length ? ` · ${D(i[0])}` : ""}`,
				children: [/* @__PURE__ */ d(ke, {
					card: e,
					role: t
				}), /* @__PURE__ */ d(K, {})]
			}, `${e}:${r}`);
		})
	}), k = (e, t) => /* @__PURE__ */ d(q, {
		name: t,
		className: "kelp-dice-row",
		children: e.map((e) => /* @__PURE__ */ f("button", {
			type: "button",
			"data-legal": S("dice", e.id).length > 0,
			"data-selected": _?.dice.includes(e.id),
			onClick: () => C("dice", e.id),
			"aria-label": `${a(e.color)} ${e.value || "?"}`,
			children: [/* @__PURE__ */ d(Y, { die: e }), /* @__PURE__ */ d(K, {})]
		}, e.id))
	}), re = t?.board ?? e.board;
	return /* @__PURE__ */ f("div", {
		className: "kelp-root",
		"data-board": e.config.board,
		children: [/* @__PURE__ */ d(o, {
			adaptive: !0,
			scroll: !1,
			className: "kelp-screen",
			banner: /* @__PURE__ */ f("header", {
				className: "kelp-header",
				children: [/* @__PURE__ */ f("div", {
					className: "kelp-brand",
					children: [
						/* @__PURE__ */ d("strong", { children: "KELP" }),
						/* @__PURE__ */ d("span", { children: a("turn", { n: e.turn }) }),
						/* @__PURE__ */ d("button", {
							type: "button",
							onClick: () => h("history"),
							children: a("inspect")
						})
					]
				}), /* @__PURE__ */ d("div", {
					className: "kelp-seats",
					children: ["octopus", "shark"].map((t) => /* @__PURE__ */ f("div", {
						className: "kelp-seat",
						"data-active": e.actor === e.roles[t],
						children: [
							/* @__PURE__ */ d("b", { children: a(t) }),
							/* @__PURE__ */ d("span", {
								title: y(e.roles[t]),
								children: y(e.roles[t])
							}),
							/* @__PURE__ */ d("strong", { children: t === "octopus" ? `${e.eaten.length}/4` : `${e.hunger.length}/7` }),
							/* @__PURE__ */ d("small", { children: a(t === "octopus" ? "food" : "hunger") })
						]
					}, t))
				})]
			}),
			children: /* @__PURE__ */ f("main", {
				className: "kelp-layout",
				children: [/* @__PURE__ */ f("section", {
					className: "kelp-scene",
					children: [
						/* @__PURE__ */ f("div", {
							className: "kelp-scene-caption",
							children: [/* @__PURE__ */ d("span", { children: a(e.config.board) }), /* @__PURE__ */ d("span", { children: t?.role === "octopus" ? a("actions", { n: e.actions }) : a("growth") + ` ${e.growthLevel}/4` })]
						}),
						/* @__PURE__ */ d("div", {
							className: "kelp-sea",
							children: /* @__PURE__ */ d(Me, {
								pub: e,
								board: re,
								legalZone: (e) => S("zones", e).length > 0,
								legalNode: (e) => S("nodes", e).length > 0,
								chosenZones: _?.zones ?? [],
								chosenNodes: v.length === 1 && _ ? v[0].nodes ?? [] : _?.nodes ?? [],
								onZone: (e) => C("zones", e),
								onNode: (e) => C("nodes", e)
							})
						}),
						/* @__PURE__ */ f("div", {
							className: "kelp-tracks",
							children: [/* @__PURE__ */ f(q, {
								name: "hunger",
								className: "kelp-track",
								children: [/* @__PURE__ */ d("b", { children: a("hunger") }), Array.from({ length: 7 }, (t, n) => /* @__PURE__ */ d("span", {
									className: "kelp-track-slot",
									children: e.hunger[n] ? /* @__PURE__ */ d(Y, { die: e.hunger[n] }) : /* @__PURE__ */ d("small", { children: n + 1 })
								}, n))]
							}), /* @__PURE__ */ f(q, {
								name: "food",
								className: "kelp-track",
								children: [/* @__PURE__ */ d("b", { children: a("food") }), Array.from({ length: 4 }, (t, n) => /* @__PURE__ */ d("button", {
									className: "kelp-food-slot",
									type: "button",
									"aria-label": e.eaten[n] ? a(e.eaten[n].used ? "foodAbilityUsed" : "foodAbilityUnused", { name: a(e.eaten[n].kind) }) : a("emptyFoodSlot", { n: n + 1 }),
									"data-used": e.eaten[n]?.used,
									"data-legal": g.some((e) => e.kind === "foodAbility" && e.n === n),
									onClick: () => {
										let e = g.find((e) => e.kind === "foodAbility" && e.n === n);
										e && b(e);
									},
									children: e.eaten[n] ? /* @__PURE__ */ d(J, { kind: e.eaten[n].kind }) : /* @__PURE__ */ d("small", { children: n + 1 })
								}, n))]
							})]
						})
					]
				}), /* @__PURE__ */ f("aside", {
					className: "kelp-side",
					children: [
						/* @__PURE__ */ f("div", {
							className: "kelp-prompt",
							"aria-live": "polite",
							children: [/* @__PURE__ */ d("strong", { children: _ && v.every((e) => e.kind === "daring") ? a(_.dice.length ? "daringSacrifice" : "daringRed") : a(`p_${e.prompt}`, { n: e.promptN ?? e.actions }) }), /* @__PURE__ */ d("span", { children: g.length ? t && a(t.role) : e.actor ? a("waiting", { name: y(e.actor) }) : e.prompt === "confront" ? a("p_confront") : a("resolving") })]
						}),
						/* @__PURE__ */ f("div", {
							className: "kelp-controls",
							children: [
								_ && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => c(null),
									children: a("cancel")
								}), ee.map((e) => /* @__PURE__ */ f("button", {
									type: "button",
									className: "kelp-primary",
									onClick: () => b(e),
									children: [
										a("confirm"),
										" · ",
										D(e)
									]
								}, e.id))] }),
								!_ && g.filter(ne).map((e) => /* @__PURE__ */ d("button", {
									type: "button",
									className: [
										"drawCards",
										"roll",
										"spendEnergy"
									].includes(e.kind) ? "kelp-primary" : "",
									onClick: () => b(e),
									children: D(e)
								}, e.id)),
								_ && v.length > 1 && /* @__PURE__ */ d("span", { children: a("choices", { n: v.length }) })
							]
						}),
						/* @__PURE__ */ f("div", {
							className: "kelp-side-scroll",
							children: [
								e.prompt === "confront" && /* @__PURE__ */ d("div", {
									className: "kelp-confrontations",
									children: e.confront.available.map((e) => {
										let n = g.find((t) => t.kind === "confront" && t.n === e);
										return /* @__PURE__ */ f("button", {
											type: "button",
											"data-color": e,
											disabled: !n,
											onClick: () => n && b(n),
											children: [/* @__PURE__ */ d("b", { children: a(te[e]) }), /* @__PURE__ */ d("span", { children: t?.role === "octopus" ? a(`e_${te[e]}`) : a("c_confront") })]
										}, e);
									})
								}),
								e.budget >= 0 && /* @__PURE__ */ d("p", {
									className: "kelp-budget",
									children: a("remainingEnergy", { n: e.budget })
								}),
								t?.role === "octopus" ? /* @__PURE__ */ f(u, { children: [
									/* @__PURE__ */ f("div", {
										className: "kelp-section-heading",
										children: [
											/* @__PURE__ */ d("h2", { children: a("hand") }),
											/* @__PURE__ */ d("span", { children: a("handSize", { n: e.handSize }) }),
											e.prompt === "octopus" && /* @__PURE__ */ d("button", {
												type: "button",
												"aria-pressed": l,
												onClick: () => {
													p((e) => !e), c(null);
												},
												children: a(l ? "discardMode" : "playMode")
											})
										]
									}),
									/* @__PURE__ */ d(q, {
										name: "hand",
										children: O(t.hand, "octopus", "hand")
									}),
									t.inspectCards.length > 0 && O(t.inspectCards, "octopus", "retrieve"),
									/* @__PURE__ */ d("h2", { children: a("market") }),
									O(e.market.filter((e) => e !== null), "octopus", "market"),
									/* @__PURE__ */ d("h2", { children: a("spare") }),
									/* @__PURE__ */ d("div", {
										className: "kelp-spares",
										children: [...new Set(e.spare)].map((t) => {
											let n = v.filter((e) => e.block === t && e.kind === "learnBlock");
											return /* @__PURE__ */ f("button", {
												type: "button",
												"data-legal": n.length > 0,
												onClick: () => x(n, {}),
												title: a(t),
												"aria-label": a("spareCount", {
													name: a(t),
													n: e.spare.filter((e) => e === t).length
												}),
												children: [
													/* @__PURE__ */ d(J, { kind: t }),
													/* @__PURE__ */ d(K, {}),
													/* @__PURE__ */ d("small", { children: e.spare.filter((e) => e === t).length })
												]
											}, t);
										})
									})
								] }) : /* @__PURE__ */ f(u, { children: [
									/* @__PURE__ */ d("h2", { children: a("dice") }),
									k([...e.pool, ...e.activeSaved], "dice"),
									/* @__PURE__ */ d("h2", { children: a("energy") }),
									k(e.energy, "energy"),
									e.saved.length > 0 && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("h2", { children: a("saved") }), k(e.saved.map((e) => e.die), "saved")] }),
									e.prompt === "reactive" && /* @__PURE__ */ d("div", {
										className: "kelp-dice-row",
										children: [
											"blue",
											"yellow",
											"red"
										].map((e) => {
											let t = v.find((t) => t.block === e);
											return /* @__PURE__ */ d("button", {
												type: "button",
												disabled: !t,
												"aria-label": a(`die_${e}`),
												onClick: () => t && b(t),
												children: /* @__PURE__ */ d(Y, { die: {
													id: -1,
													color: e,
													value: 0
												} })
											}, e);
										})
									}),
									/* @__PURE__ */ d("h2", { children: a("abilities") }),
									O(e.sharkHand, "shark", "ability"),
									/* @__PURE__ */ d("h2", { children: a("sharkMarket") }),
									/* @__PURE__ */ d(q, {
										name: "market",
										children: O(e.sharkMarket, "shark", "market")
									}),
									/* @__PURE__ */ d(q, {
										name: "growth",
										className: "kelp-growth",
										children: [
											1,
											2,
											3,
											4
										].map((t) => /* @__PURE__ */ f("div", {
											"data-unlocked": e.growthLevel >= t,
											children: [
												/* @__PURE__ */ d("b", { children: t }),
												/* @__PURE__ */ d("span", { children: a(`growth${t}`) }),
												e.growthLevel === t - 1 && /* @__PURE__ */ f("small", { children: [e.growth.length, "/3"] })
											]
										}, t))
									}),
									t && /* @__PURE__ */ f("details", {
										className: "kelp-bag",
										children: [/* @__PURE__ */ d("summary", { children: a("bag", { n: e.bagCount }) }), k(t.bag, "bag")]
									})
								] })
							]
						})
					]
				})]
			})
		}), m && /* @__PURE__ */ d("div", {
			className: "kelp-sheet-shade",
			role: "presentation",
			onClick: () => h(null),
			children: /* @__PURE__ */ f("section", {
				className: "kelp-sheet",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": a("inspect"),
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ f("header", { children: [/* @__PURE__ */ d("b", { children: a("inspect") }), /* @__PURE__ */ d("button", {
					type: "button",
					onClick: () => h(null),
					children: a("close")
				})] }), /* @__PURE__ */ d("div", {
					className: "kelp-sheet-scroll",
					children: m.includes(":") ? /* @__PURE__ */ d(ke, {
						card: Number(m.split(":")[1]),
						role: m.split(":")[0]
					}) : /* @__PURE__ */ f(u, { children: [
						/* @__PURE__ */ d("h2", { children: a("discardPile") }),
						O(e.discard, "octopus", "discard"),
						/* @__PURE__ */ d("h2", { children: a("trashPile") }),
						O(e.octTrash, "octopus", "trash"),
						O(e.sharkTrash, "shark", "trash"),
						/* @__PURE__ */ d("h2", { children: a("history") }),
						e.events.map((e, t) => /* @__PURE__ */ d("p", { children: a(`log_${e.key}`, { n: e.key === "revealed" ? (e.n ?? 0) + 1 : e.n ?? 0 }) }, t))
					] })
				})]
			})
		})]
	});
}
function Me({ pub: e, board: t = e.board, legalZone: n = () => !1, legalNode: r = () => !1, chosenZones: i = [], chosenNodes: a = [], onZone: o = () => {}, onNode: s = () => {} }) {
	let c = W(), l = (e, t) => ({
		left: `${9 + e / 3 * 82}%`,
		top: `${9 + t / 3 * 82}%`
	});
	return /* @__PURE__ */ f(q, {
		name: "board",
		className: "kelp-board",
		children: [
			/* @__PURE__ */ d("div", {
				className: "kelp-underwater",
				style: { backgroundImage: `url(${G("background")})` }
			}),
			/* @__PURE__ */ f("svg", {
				viewBox: "0 0 100 100",
				className: "kelp-routes",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ d("g", { children: S.map((e) => {
					let [t, n] = e.ends.map((e) => ({
						x: 9 + e % 4 / 3 * 82,
						y: 9 + Math.floor(e / 4) / 3 * 82
					}));
					return /* @__PURE__ */ d("path", { d: `M${t.x},${t.y} Q${9 + e.x / 3 * 82},${9 + e.y / 3 * 82} ${n.x},${n.y}` }, e.id);
				}) }), a.length > 1 && /* @__PURE__ */ d("polyline", {
					points: a.map((e) => `${9 + S[e].x / 3 * 82},${9 + S[e].y / 3 * 82}`).join(" "),
					className: "kelp-route-preview"
				})]
			}),
			y.map((r) => /* @__PURE__ */ f("div", {
				className: "kelp-zone",
				style: l(r % 3 + .5, Math.floor(r / 3) + .5),
				children: [
					/* @__PURE__ */ f("span", {
						className: "kelp-zone-value",
						children: [w[e.config.board][r], /* @__PURE__ */ d("small", { children: "+" })]
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						"data-legal": n(r),
						"data-selected": i.includes(r),
						"aria-label": `${c("zone", { n: r + 1 })} · ${t[r] ? c(t[r].kind ?? "hidden") : c("empty")}`,
						onClick: () => o(r),
						children: [/* @__PURE__ */ d(q, {
							name: `zone:${r}`,
							children: t[r] ? /* @__PURE__ */ d(J, {
								kind: t[r].kind,
								revealed: t[r].revealed
							}) : /* @__PURE__ */ d("span", { className: "kelp-block-empty" })
						}), /* @__PURE__ */ d(K, {})]
					}),
					e.attacks.filter((e) => e.zone === r).map((e) => /* @__PURE__ */ d("span", {
						className: "kelp-assigned",
						children: /* @__PURE__ */ d(Y, { die: e.die })
					}, e.die.id))
				]
			}, r)),
			S.map((t) => /* @__PURE__ */ d("div", {
				className: "kelp-current-node",
				style: l(t.x, t.y),
				children: /* @__PURE__ */ f("button", {
					type: "button",
					"data-legal": r(t.id),
					"data-selected": a.includes(t.id),
					"aria-label": `${c("node", { n: t.id + 1 })}${C[e.config.board].includes(t.id) ? ` · ${c("den")}` : ""}`,
					onClick: () => s(t.id),
					children: [/* @__PURE__ */ d(q, {
						name: `node:${t.id}`,
						children: e.currents[t.id] ? /* @__PURE__ */ d(Y, { die: e.currents[t.id] }) : /* @__PURE__ */ d("span", {
							className: "kelp-water-symbol",
							"data-den": C[e.config.board].includes(t.id),
							children: C[e.config.board].includes(t.id) ? "◇" : "≈"
						})
					}), /* @__PURE__ */ d(K, {})]
				})
			}, t.id)),
			/* @__PURE__ */ f(q, {
				name: "shark",
				className: "kelp-shark-piece",
				style: l(S[e.sharkNode].x, S[e.sharkNode].y),
				children: [/* @__PURE__ */ d("img", {
					src: G("shark-0"),
					alt: c("shark")
				}), /* @__PURE__ */ d("span", {
					className: "kelp-heading-arrow",
					style: { transform: `rotate(${e.entry === null ? 0 : Math.atan2(S[e.sharkNode].y - Math.floor(e.entry / 4), S[e.sharkNode].x - e.entry % 4) * 180 / Math.PI}deg)` },
					"aria-hidden": !0,
					children: "➤"
				})]
			})
		]
	});
}
//#endregion
//#region src/games/kelp/bot.ts
var Ne = {
	food: 16,
	safety: 4,
	hunt: 14,
	growth: 3,
	redDice: 5,
	strikeRisk: .3,
	noise: .3
}, Pe = (e, t) => Math.abs(e % 3 - t % 3) + Math.abs(Math.floor(e / 3) - Math.floor(t / 3)), Fe = (e, t) => {
	let n = e + 17;
	for (let e of t) n = Math.imul(n ^ e.charCodeAt(0), 16777619);
	return (n >>> 0) / 4294967296;
};
function Ie(e, t) {
	let n = t?.belief.length === 9 ? [...t.belief] : Array(9).fill(1 / 9);
	for (let r of e.events.filter((e) => e.seq > (t?.seq ?? -1))) {
		let e = r.zones ?? [];
		if (r.key === "swapped" && ([n[e[0]], n[e[1]]] = [n[e[1]], n[e[0]]]), r.key === "octopusRevealed" && (n = n.map((t, n) => Number(n === e[0]))), r.key === "shuffled") {
			let t = e.reduce((e, t) => e + n[t], 0);
			e.forEach((r) => {
				n[r] = t / e.length;
			});
		}
	}
	let r = e.board.findIndex((e) => e?.kind === "octopus");
	if (r >= 0) n = n.map((e, t) => Number(t === r));
	else {
		e.board.forEach((e, t) => {
			e?.kind && (n[t] = 0);
		}), n.reduce((e, t) => e + t, 0) || (n = e.board.map((e) => +!e?.kind));
		let t = n.reduce((e, t) => e + t, 0) || 1;
		n = n.map((e) => e / t);
	}
	return {
		seq: e.revision,
		belief: n
	};
}
function Le(e = {}) {
	let t = {
		...Ne,
		...e
	};
	return (e, n) => {
		let r = e.public, i = e.private;
		if (!i?.choices.length) return null;
		let a = Ie(r, n.memory), o = i.choices;
		if (n.difficulty === "weak") {
			let e = o[Math.floor(Fe(r.revision, n.rid) * o.length)];
			return {
				action: {
					type: "choose",
					revision: r.revision,
					id: e.id
				},
				memory: a
			};
		}
		let s = i.board, c = s.findIndex((e) => e?.kind === "octopus"), l = S[r.sharkNode].zones, u = s.flatMap((e, t) => e?.kind && g(e.kind) ? [t] : []), d = u.filter((e) => i.hand.includes(17 + h.indexOf(s[e].kind))), f = d.length ? d : u, p = (e) => f.length ? Math.min(...f.map((t) => Pe(e, t))) : 2, m = [
			...r.pool,
			...r.activeSaved,
			...r.energy,
			...r.saved.map((e) => e.die)
		], _ = [...i.bag, ...m].filter((e) => e.color === "red").length, v = (e) => m.find((t) => t.id === e), y = (e) => S[e].zones.reduce((e, t) => e + a.belief[t] * (r.board[t]?.kind === "octopus" ? 3 : 1), 0), b = (e) => {
			let n = e.zones ?? [], o = (e.dice ?? []).map(v).filter((e) => e !== void 0), u = e.card, d = e.n ?? 0, f = e.nodes?.at(-1);
			switch (e.kind) {
				case "play": {
					let e = T[u];
					return e.group === "eat" ? t.food * 3 : e.group === "learn" ? t.food * .8 + e.power * 2 - e.cost * 1.3 : e.group === "hide" ? (s[c]?.revealed ? t.safety * 3 : 1) + s.filter((e) => e?.revealed).length - e.cost : p(c) > 1 ? t.food * .7 - e.cost : s[c]?.revealed && l.includes(c) ? t.safety * 2 : 1;
				}
				case "pay": return -n.reduce((e, n) => e + (n === c ? t.safety * (l.includes(n) ? 3 : 1) : g(s[n].kind) ? 2 : 0) + 1, 0);
				case "drawCards": return i.hand.length === 0 ? 40 : (r.handSize - i.hand.length) * 3;
				case "discard": return s[c]?.revealed && l.includes(c) ? t.safety * 2 - T[u].power : -8 - T[u].power;
				case "hide": return n.reduce((e, n) => e + (n === c ? t.safety * 4 : g(s[n].kind) ? 2 : .5), 0);
				case "swap": {
					let e = n.includes(c) ? n.find((e) => e !== c) : c;
					return (p(c) - p(e)) * t.food + (l.includes(c) && !l.includes(e) ? t.safety : 0) + +!!n.includes(c);
				}
				case "shuffle": return n.includes(c) ? t.safety * 2 : 0;
				case "learnCard": return u >= 17 ? t.food * 2 : T[u].group === "learn" ? t.food * .6 + T[u].power : 2 + (T[u].group === "move" ? 3 : 0);
				case "learnBlock": return e.block === "double" ? 8 : e.block === "denTrap" ? 5 : 3;
				case "replace": return g(e.block) ? -Math.abs(Pe(c, n[0]) - 1) * t.food + (e.mode === "hidden" ? 2 : 0) : (l.includes(n[0]) ? 2 : 0) + (e.mode === "hidden" ? 3 : 0);
				case "foodAbility": return e.block === "crab" ? i.hand.length <= 3 ? 30 : 5 : e.block === "lobster" ? s[c]?.revealed ? 25 : -10 : e.block === "snail" ? i.hand.some((e) => e >= 17) ? -2 : 12 : 20;
				case "gainHand":
				case "retrieveCard": return u >= 17 ? t.food * 2 : T[u].group === "learn" ? 8 : 4;
				case "top": return u >= 17 ? 10 : T[u].power;
				case "trash": return T[u].group === "eat" ? -40 : T[u].power <= 1 ? 5 : -3;
				case "extraDraw": return 8;
				case "skip": return -1;
				case "den": return i.role === "octopus" ? -y(f) * t.safety : y(f);
				case "roll":
				case "drawDice":
				case "endTurn": return 1;
				case "reroll": return o[0]?.value < 4 ? 10 - o[0].value : -5;
				case "relentless": return o.reduce((e, t) => e + 3.5 - t.value, 0) - 1;
				case "hungry": return r.hunger.length < 6 ? 5 : -5;
				case "reactive": return o.every((e) => e.color === "blue") ? 5 : -8;
				case "replacementDie": return e.block === "red" ? 8 : e.block === "yellow" ? 5 : 1;
				case "finishRoll": return 0;
				case "current": return _ ? t.growth + y(f) * t.hunt - (o[0]?.value ?? 0) * 2 : -20;
				case "finishCurrents": return 0;
				case "swift": return 1;
				case "agile": return -.2;
				case "vigilant": return o[0]?.value === 6 ? 3 : -2;
				case "ruthless": return o[0]?.color === "blue" ? -3 : d * 2;
				case "daring": return r.hunger.length >= 6 ? -100 : o[1]?.color === "blue" && o[0]?.value < 5 ? 4 : -5;
				case "swim":
				case "forcedSwim": return S[f].zones.reduce((e, t) => e + a.belief[t] * Math.max(0, ...[...r.pool, ...r.activeSaved].filter((e) => e.color !== "blue" && e.value >= w[r.config.board][t]).map((e) => e.color === "red" ? 2 : .7)), 0) * t.hunt + y(f) + (e.nodes?.some((e) => r.currents[e]) ? t.growth : 0);
				case "assignAttack": return t.hunt * (o[0]?.color === "red" ? a.belief[n[0]] * 4 - (1 - a.belief[n[0]]) * t.strikeRisk : a.belief[n[0]] + .3) + (o[0]?.color === "yellow" ? t.growth : 0) - (r.hunger.length >= 6 && o[0]?.color === "red" && a.belief[n[0]] < .5 ? 30 : 0);
				case "unassign": return -20;
				case "resolveAttacks": return 0;
				case "reveal": return a.belief[n[0]] * 5;
				case "triggerTrap": return 0;
				case "ignoreTrap": return 5;
				case "removeCurrent": return y(f) * -3 + (r.currents[f]?.value ?? 0) * .1;
				case "recoverCurrent": return -y(f);
				case "keepEnergy": return o.reduce((e, t) => e + t.value, 0);
				case "useSaved": return r.phase === "currents" && o[0]?.color !== "blue" ? 6 : r.phase === "attack" && o[0]?.color !== "blue" && S[r.sharkNode].zones.some((e) => o[0].value >= w[r.config.board][e] && a.belief[e] > .1) ? 5 : r.phase === "energy" && o[0]?.color === "blue" ? 1 : -3;
				case "spendEnergy": return r.hunger.length < 6 ? 5 : -30;
				case "storeEnergy": return 0;
				case "buy": return E[u].dice.reduce((e, n) => e + (n === "red" ? t.redDice : n === "yellow" ? 2 : 1), 0) + (E[u].name === "hostile" ? 5 : 1) - E[u].cost * .1;
				case "refresh": return -2;
				case "finishBuying": return 0;
				case "hungerPayment": return o[0]?.color === "red" ? -5 : o[0]?.color === "yellow" ? -1 : 1;
				case "confront": return 0;
				default: return 0;
			}
		}, x = o.reduce((e, i) => b(i) + Fe(r.revision, `${n.rid}/${i.id}`) * t.noise > b(e) + Fe(r.revision, `${n.rid}/${e.id}`) * t.noise ? i : e);
		return {
			action: {
				type: "choose",
				revision: r.revision,
				id: x.id
			},
			memory: a
		};
	};
}
var Re = Le(), ze = (e, t, n) => {
	let r = e.type === "choose" ? t.private?.choices.find((t) => t.id === e.id) : void 0;
	return r ? n(`games.kelp.c_${r.kind}`, { n: r.n ?? 0 }) : "";
}, X = (e) => ({
	...e.data,
	...e.secret
});
function Z({ boxes: e, ms: t, mode: i, children: a, follow: o }) {
	let s = r(null), c = e[0], l = e.at(-1);
	return n(() => {
		let n = s.current;
		if (!n) return;
		let r = (e) => ({
			left: `${e.x}px`,
			top: `${e.y}px`,
			width: `${e.w}px`,
			height: `${e.h}px`
		}), a = e.map((e) => ({
			...r(e),
			opacity: 1
		}));
		i === "flip" && (a = [{
			...r(c),
			transform: "scaleX(0.02)"
		}, {
			...r(l),
			transform: "scaleX(1)"
		}]), i === "roll" && (a = [
			{
				...r(c),
				transform: "translateY(-12px) rotate(-160deg) scale(.7)",
				opacity: .4
			},
			{
				...r(l),
				transform: "translateY(3px) rotate(12deg)",
				offset: .72
			},
			{
				...r(l),
				transform: "none",
				opacity: 1
			}
		]), i === "pulse" && (a = [
			{
				...r(c),
				transform: "scale(.86)",
				opacity: .2
			},
			{
				...r(l),
				transform: "scale(1.07)",
				opacity: 1,
				offset: .55
			},
			{
				...r(l),
				transform: "scale(1)",
				opacity: 0
			}
		]), i === "out" && (a = [{
			...r(c),
			opacity: 1
		}, {
			...r(l),
			transform: "scale(.2) rotate(25deg)",
			opacity: 0
		}]);
		let u = n.animate(a, {
			duration: t,
			easing: "cubic-bezier(.24,.65,.3,1)",
			fill: "both"
		}), d = performance.now(), f = [u], p = () => {
			let e = o?.(), i = t - (performance.now() - d);
			if (!e || i < 35) return;
			let a = n.getBoundingClientRect(), s = n.parentElement.getBoundingClientRect(), c = {
				x: a.left - s.left,
				y: a.top - s.top,
				w: a.width,
				h: a.height
			};
			u.cancel(), u = n.animate([r(c), r(e)], {
				duration: i,
				easing: "ease-out",
				fill: "both"
			}), f.push(u);
		};
		return document.addEventListener("scroll", p, !0), window.addEventListener("resize", p), () => {
			f.forEach((e) => e.cancel()), document.removeEventListener("scroll", p, !0), window.removeEventListener("resize", p);
		};
	}, [
		e,
		c,
		l,
		t,
		i,
		o
	]), /* @__PURE__ */ d("div", {
		ref: s,
		className: "kelp-fx-sprite",
		style: {
			position: "absolute",
			left: c.x,
			top: c.y,
			width: c.w,
			height: c.h,
			pointerEvents: "none"
		},
		children: a
	});
}
function Q(e, t) {
	let n = X(e), r = n.after ?? [], i = n.before ?? [], a = t.queued ? 180 : 540, o = [], s = r.map((n) => {
		let s = `kelp:zone:${n.zone}`, c = t.anchor(s), l = i.find((e) => e.zone === n.zone);
		if (!c) return null;
		let u = c, f = n.empty ? "out" : "flip";
		if (e.kind === "swap" && r.length === 2) {
			let e = i.find((e) => e.zone !== n.zone);
			u = e && t.anchor(`kelp:zone:${e.zone}`) || c, f = "move";
		}
		t.queued || o.push(s);
		let p = n.empty ? l : n;
		return /* @__PURE__ */ d(Z, {
			boxes: [u, c],
			ms: a,
			mode: f,
			follow: () => t.anchor(s),
			children: /* @__PURE__ */ d(J, {
				kind: p?.kind ?? null,
				revealed: p?.revealed
			})
		}, n.zone);
	});
	return s.some(Boolean) ? {
		ms: a,
		hide: o,
		node: /* @__PURE__ */ d(u, { children: s })
	} : $("board", t);
}
function $(e, t) {
	let n = t.anchor(`kelp:${e}`), r = t.queued ? 160 : 540;
	return n ? {
		ms: r,
		node: /* @__PURE__ */ d(Z, {
			boxes: [n],
			ms: r,
			mode: "pulse",
			children: /* @__PURE__ */ d("div", { style: {
				width: "100%",
				height: "100%",
				border: "3px solid #f4d789",
				borderRadius: 14,
				boxShadow: "inset 0 0 30px #c4ebad66"
			} })
		})
	} : null;
}
var Be = {
	blocks: Q,
	swap: Q,
	shuffle: Q,
	swim(e, t) {
		let n = X(e), r = t.anchor("kelp:shark"), i = t.queued ? 180 : 540;
		if (!r || !n.nodes?.length) return null;
		let a = n.nodes.flatMap((e) => {
			let n = t.anchor(`kelp:node:${e}`);
			return n ? [{
				x: n.x + (n.w - r.w) / 2,
				y: n.y + (n.h - r.h) / 2,
				w: r.w,
				h: r.h
			}] : [];
		});
		return a.length ? {
			ms: i,
			hide: t.queued ? [] : ["kelp:shark"],
			node: /* @__PURE__ */ d(Z, {
				boxes: a,
				ms: i,
				mode: "move",
				follow: () => t.anchor("kelp:shark"),
				children: /* @__PURE__ */ d("div", {
					className: "kelp-fx-shark",
					children: /* @__PURE__ */ d("img", {
						src: G("shark-0"),
						alt: ""
					})
				})
			})
		} : null;
	},
	dice(e, t) {
		let n = t.anchor("kelp:dice"), r = X(e).dice ?? [], i = t.queued ? 180 : 540;
		return n ? {
			ms: i,
			hide: t.queued ? [] : ["kelp:dice"],
			node: /* @__PURE__ */ d(u, { children: r.map((e, t) => /* @__PURE__ */ d(Z, {
				boxes: [{
					x: n.x + t * 48,
					y: n.y,
					w: 38,
					h: 38
				}],
				ms: i,
				mode: "roll",
				children: /* @__PURE__ */ d(Y, { die: e })
			}, e.id)) })
		} : $("board", t);
	},
	card: (e, t) => X(e).after?.length ? Q(e, t) : $("hand", t) ?? $("board", t),
	draw: (e, t) => $("hand", t) ?? $("board", t),
	learn: (e, t) => $("hand", t) ?? $("board", t),
	market: (e, t) => $("market", t),
	current: (e, t) => $("board", t),
	growth: (e, t) => $("growth", t),
	hunger: (e, t) => $("hunger", t),
	food: Q,
	confront(e, t) {
		let n = t.anchor("kelp:board"), r = X(e).cards, i = t.queued ? 180 : 540;
		return !n || !r ? null : {
			ms: i,
			node: /* @__PURE__ */ d(Z, {
				boxes: [{
					x: n.x + n.w * .2,
					y: n.y + n.h * .35,
					w: n.w * .6,
					h: n.h * .25
				}],
				ms: i,
				mode: "flip",
				children: /* @__PURE__ */ d("div", {
					className: "kelp-fx-confront",
					children: r.map((e, t) => /* @__PURE__ */ d("span", {
						"data-color": e,
						children: [
							"≈",
							"▲",
							"◉"
						][e]
					}, t))
				})
			})
		};
	}
};
//#endregion
//#region src/games/kelp/game-over.tsx
function Ve({ public: e, private: t, members: n, onPlayAgain: r, onBackToLobby: a }) {
	let o = e, s = W(), [c, l] = i(!1), [p, m] = i(null), h = o.winner === "shark" ? "shark" : "octopus", g = n.find((e) => e.rid === o.roles[h])?.name ?? s(h);
	return c ? /* @__PURE__ */ f("div", {
		className: "kelp-over-review",
		children: [/* @__PURE__ */ d(je, {
			pub: o,
			priv: t,
			members: n,
			send: () => {}
		}), /* @__PURE__ */ d("button", {
			type: "button",
			onClick: () => l(!1),
			children: s("close")
		})]
	}) : /* @__PURE__ */ d("div", {
		className: "kelp-root",
		children: /* @__PURE__ */ f("div", {
			className: "kelp-over",
			children: [
				/* @__PURE__ */ f("header", {
					className: "kelp-over-heading",
					children: [
						/* @__PURE__ */ d("span", { children: "KELP" }),
						/* @__PURE__ */ d("h1", { children: s("winner", { name: g }) }),
						/* @__PURE__ */ d("p", { children: s(o.reason === "food" ? "foodWin" : o.reason ?? "exhaustion") })
					]
				}),
				/* @__PURE__ */ f("div", {
					className: "kelp-over-main",
					children: [/* @__PURE__ */ d("div", {
						className: "kelp-over-portrait",
						children: /* @__PURE__ */ d("img", {
							src: G(`${h}-0`),
							alt: s(h)
						})
					}), /* @__PURE__ */ f("div", { children: [
						/* @__PURE__ */ f("h2", { children: [
							s(h),
							" · ",
							s("turn", { n: o.turn })
						] }),
						/* @__PURE__ */ f("div", {
							className: "kelp-over-stats",
							children: [
								/* @__PURE__ */ f("span", { children: [s("food"), /* @__PURE__ */ f("b", { children: [o.eaten.length, "/4"] })] }),
								/* @__PURE__ */ f("span", { children: [s("hunger"), /* @__PURE__ */ f("b", { children: [o.hunger.length, "/7"] })] }),
								/* @__PURE__ */ f("span", { children: [s("growth"), /* @__PURE__ */ f("b", { children: [o.growthLevel, "/4"] })] })
							]
						}),
						/* @__PURE__ */ d("div", {
							className: "kelp-over-actions",
							style: { marginTop: 28 },
							children: /* @__PURE__ */ d("button", {
								type: "button",
								onClick: () => l(!0),
								children: s("reviewBoard")
							})
						})
					] })]
				}),
				/* @__PURE__ */ d("div", {
					className: "kelp-over-actions",
					children: p ? /* @__PURE__ */ f(u, { children: [
						/* @__PURE__ */ d("span", { children: s(p === "again" ? "confirmAgain" : "confirmBack") }),
						/* @__PURE__ */ d("button", {
							type: "button",
							onClick: () => {
								let e = p === "again" ? r : a;
								m(null), e?.();
							},
							children: s("confirm")
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							onClick: () => m(null),
							children: s("cancel")
						})
					] }) : /* @__PURE__ */ f(u, { children: [
						r && /* @__PURE__ */ d("button", {
							type: "button",
							onClick: () => m("again"),
							children: s("playAgain")
						}),
						a && /* @__PURE__ */ d("button", {
							type: "button",
							onClick: () => m("back"),
							children: s("backLobby")
						}),
						!r && !a && /* @__PURE__ */ d("span", { children: s("waiting", { name: n[0]?.name ?? "" }) })
					] })
				})
			]
		})
	});
}
//#endregion
//#region src/games/kelp/options.tsx
function He({ value: e, onChange: t }) {
	let n = W(), r = D.safeParse(e), i = r.success ? r.data : D.parse(void 0);
	return /* @__PURE__ */ f("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ d(m, {
			title: n("boardOption"),
			columns: 2,
			children: ["day", "night"].map((e) => /* @__PURE__ */ d(p, {
				name: "kelp-board",
				value: e,
				checked: i.board === e,
				label: n(e),
				accent: "#10a99e",
				onChange: () => t({
					...i,
					board: e
				})
			}, e))
		}), /* @__PURE__ */ d(m, {
			title: n("roleOption"),
			columns: 2,
			children: ["octopus", "shark"].map((e) => /* @__PURE__ */ d(p, {
				name: "kelp-role",
				value: e,
				checked: i.firstRole === e,
				label: n(e),
				accent: "#10a99e",
				onChange: () => t({
					...i,
					firstRole: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/kelp/entry.tsx
var Ue = {
	definition: De,
	View: Ae,
	bot: Re,
	describe: ze,
	fx: Be,
	OverView: Ve,
	Options: He,
	locales: {
		zh: {
			name: "藻影追猎",
			desc: "章鱼藏身海藻林，鲨鱼循流追猎。两种截然不同的生存策略。",
			octopus: "章鱼",
			shark: "鲨鱼",
			day: "日间版图",
			night: "夜间版图",
			boardOption: "版图",
			roleOption: "首位玩家身份",
			turn: "第 {{n}} 回合",
			actions: "剩余 {{n}} 个行动",
			waiting: "等待 {{name}} 行动",
			watching: "观察对局",
			resolving: "正在结算",
			hand: "手牌",
			market: "学习牌堆",
			sharkMarket: "鲨鱼市场",
			abilities: "一次性能力",
			spare: "备用方块",
			dice: "骰池",
			bag: "骰袋（{{n}}）",
			deck: "抽牌堆（{{n}}）",
			discardPile: "弃牌堆",
			trashPile: "移除牌",
			history: "对局记录",
			inspect: "查看牌堆",
			close: "关闭",
			hunger: "饥饿",
			food: "食物",
			foodAbilityUsed: "{{name}}：能力已使用",
			foodAbilityUnused: "{{name}}：能力尚未使用",
			emptyFoodSlot: "第 {{n}} 个食物空位",
			spareCount: "{{name}}，剩余 {{n}} 个",
			die_blue: "蓝色水流骰子",
			die_yellow: "黄色搜索骰子",
			die_red: "红色攻击骰子",
			growth: "成长",
			energy: "能量",
			saved: "保留骰子",
			handSize: "手牌上限 {{n}}",
			blue: "水流",
			yellow: "搜索",
			red: "攻击",
			hidden: "隐藏方块",
			revealed: "已公开",
			privateBlock: "仅你可见",
			zone: "区域 {{n}}",
			node: "水流位置 {{n}}",
			empty: "空位",
			den: "鲨鱼巢穴",
			shell: "贝壳",
			double: "双贝壳",
			hideTrap: "隐藏陷阱",
			currentTrap: "移除水流陷阱",
			currentsTrap: "移除双水流陷阱",
			denTrap: "返回巢穴陷阱",
			crab: "红岩蟹",
			lobster: "岩龙虾",
			snail: "海螺",
			abalone: "南非鲍",
			fastLearning: "快速学习",
			nimbleDodge: "灵巧闪避",
			sneakingBy: "悄然经过",
			disguised: "伪装",
			newTactics: "新战术",
			camouflaged: "隐蔽潜行",
			moreTricks: "更多技巧",
			craftyIdeas: "巧妙构想",
			sharpSenses: "敏锐感知",
			cloudOfInk: "墨云",
			suddenEvasion: "突然闪避",
			takingChances: "冒险一试",
			inPlainSight: "藏于眼前",
			trickOfTheLight: "光影幻术",
			intoTheShadows: "潜入暗影",
			agile: "敏捷",
			hostile: "敌意",
			swift: "迅捷",
			ruthless: "无情",
			observant: "警觉",
			reactive: "应变",
			relentless: "紧追",
			vigilant: "戒备",
			daringRed: "选择要变为六点的红骰",
			daringSacrifice: "选择移至饥饿轨的另一个骰子",
			daring: "大胆",
			hungry: "饥饿难耐",
			aggressive: "好斗",
			flight: "逃离",
			fight: "反击",
			flinch: "退缩",
			e_fastLearning: "学习 2。可以将其中一张新牌放在抽牌堆顶。",
			e_nimbleDodge: "交换两个正交相邻方块，保留各自公开状态。",
			e_sneakingBy: "洗混两个隐藏方块，由鲨鱼逐块选择落位。",
			e_disguised: "隐藏两个已公开方块。",
			e_newTactics: "学习 1，然后可以从手牌或弃牌堆移除一张牌。",
			e_camouflaged: "隐藏一个方块，然后可以将它与相邻方块交换。",
			e_moreTricks: "学习 3，然后可以从手牌或弃牌堆移除一张牌。",
			e_craftyIdeas: "学习 2。新获得的方块放入版图后可以隐藏。",
			e_sharpSenses: "学习 2。可以将一张新获得的非进食牌加入手牌。",
			e_cloudOfInk: "公开章鱼（若尚未公开），再隐藏它，与另外两个隐藏方块洗混。",
			e_suddenEvasion: "交换两个相邻方块，再交换两个相邻方块。可以再次使用同一方块。",
			e_takingChances: "将中央方块与另外两个隐藏方块洗混，全部隐藏入场。",
			e_inPlainSight: "隐藏一个或两个方块，然后可以抽一张牌。",
			e_trickOfTheLight: "隐藏一个或两个方块，然后可以从手牌或弃牌堆移除一张牌。",
			e_intoTheShadows: "隐藏两个方块，然后将这两个方块洗混。",
			e_crab: "与章鱼相邻时进食。能力：手牌上限变为 5，立即补满。",
			e_lobster: "与章鱼相邻时进食。能力：隐藏所有已公开方块。",
			e_snail: "与章鱼相邻时进食。能力：从抽牌堆或弃牌堆检索一张牌加入手牌。",
			e_abalone: "与章鱼相邻时进食。能力：免费学习至多 3。",
			e_agile: "移动前：掉头。",
			e_hostile: "立即随机移除一对同色对峙牌，保留最后一对。",
			e_swift: "移动时：额外移动一个空水流位置。",
			e_ruthless: "移动前：将骰池中的一个骰子增加至多 {{n}} 点，不超过 6。",
			e_observant: "揭示陷阱后：忽略该陷阱效果。",
			e_reactive: "投骰前：将骰池中的两个骰子放回袋中，再从袋中任选一个替代。",
			e_relentless: "投骰阶段：将一个或两个骰子各重投一次。",
			e_vigilant: "移动前：保留一个骰子，在后续回合额外使用，不改变点数。",
			e_daring: "移动前：将另一个骰池骰子移至饥饿轨，把一个红骰变为 6。",
			e_hungry: "投骰阶段：额外抽取并投掷一个骰子。",
			e_aggressive: "仅获得所示骰子。",
			e_flight: "隐藏章鱼，可以与另一个隐藏方块洗混。",
			e_fight: "将鲨鱼移至一个空巢穴。",
			e_flinch: "交换章鱼与一个相邻方块。",
			p_den: "选择鲨鱼的起始巢穴",
			p_octopus: "选择行动，或使用已进食食物的能力",
			p_pay: "选择方块，支付牌面的公开费用",
			p_hide: "选择要隐藏的方块",
			p_swap: "选择两个相邻方块交换",
			p_shuffle: "选择要洗混的方块",
			p_placeShuffled: "选择一个空位，放入抽出的隐藏方块",
			p_learn: "还可以学习 {{n}} 项",
			p_replace: "选择一个已公开的非章鱼、非食物方块替换",
			p_top: "可以将一张新牌放在抽牌堆顶",
			p_gainHand: "可以将一张新获得的非进食牌加入手牌",
			p_inkHide: "章鱼即将隐藏并与其他方块洗混",
			p_trash: "可以从手牌或弃牌堆移除一张牌",
			p_extraDraw: "可以额外抽一张牌",
			p_retrieveCard: "选择要加入手牌的牌",
			p_removeCurrent: "可以移除水流，放回鲨鱼骰袋",
			p_drawDice: "从袋中抽取 {{n}} 个骰子；不足时先取回水流",
			p_draw: "投掷骰子，或使用应变",
			p_reactive: "从骰袋中选择一个替代骰子",
			p_roll: "可以重投骰子，再进入水流阶段",
			p_currents: "可以放置水流或使用移动前能力",
			p_move: "选择游动路线",
			p_attack: "分配搜索和攻击骰子，然后确认揭示",
			p_resolve: "选择先揭示的区域",
			p_trap: "陷阱已揭示，可以使用警觉",
			p_confront: "秘密选择一张对峙牌",
			p_attackDone: "结算已使用的骰子",
			p_growth: "结算成长",
			p_energy: "保留能量，或购买市场牌",
			p_overflow: "选择保留的三个能量骰子",
			p_hungerPayment: "选择一个能量骰子移至饥饿轨",
			p_animating: "行动结算中",
			p_over: "对局结束",
			c_play: "打出",
			c_pay: "公开所选方块",
			c_discard: "弃一张手牌并隐藏方块",
			c_drawCards: "补满手牌",
			c_endTurn: "结束回合",
			c_hide: "隐藏所选方块",
			c_swap: "交换所选方块",
			c_shuffle: "洗混所选方块",
			c_placeShuffled: "放置隐藏方块",
			c_learnCard: "学习此牌",
			c_learnBlock: "学习此方块",
			c_replace: "替换方块",
			c_top: "放到抽牌堆顶",
			c_gainHand: "加入手牌",
			c_trash: "移除此牌",
			c_extraDraw: "抽一张牌",
			c_retrieveCard: "加入手牌",
			c_removeCurrent: "移除水流",
			c_den: "前往巢穴",
			c_foodAbility: "使用食物能力",
			c_drawDice: "抽取骰子",
			c_recoverCurrent: "取回水流",
			c_replacementDie: "选择替代骰子",
			c_roll: "投掷骰子",
			c_finishRoll: "进入水流阶段",
			c_reroll: "重投一次",
			c_relentless: "使用紧追",
			c_hungry: "额外抽取并投骰",
			c_reactive: "使用应变",
			c_finishCurrents: "开始移动",
			c_useSaved: "取用保留骰子",
			c_current: "放置水流",
			c_agile: "掉头",
			c_swift: "增加一步移动",
			c_vigilant: "保留骰子",
			c_ruthless: "增加 {{n}} 点",
			c_daring: "使用大胆",
			c_swim: "沿所选路线游动",
			c_forcedSwim: "取回阻挡水流并游到该处",
			c_assignAttack: "分配骰子",
			c_unassign: "收回骰子",
			c_resolveAttacks: "开始揭示",
			c_reveal: "揭示此区域",
			c_triggerTrap: "触发陷阱",
			c_ignoreTrap: "忽略陷阱",
			c_confront: "选择对峙牌",
			c_keepEnergy: "保留所选能量骰子",
			c_hungerPayment: "移至饥饿轨",
			c_storeEnergy: "结束回合并保留能量",
			c_spendEnergy: "使用能量购买",
			c_buy: "购买此牌",
			c_finishBuying: "结束购买",
			c_refresh: "降低骰子一点，刷新此市场牌",
			c_skip: "跳过可选效果",
			select: "选择",
			confirm: "确认",
			cancel: "取消选择",
			choices: "还有 {{n}} 种选择",
			mode_hand: "加入手牌",
			mode_hidden: "隐藏入场",
			mode_deck: "来自抽牌堆",
			mode_discard: "来自弃牌堆",
			remainingEnergy: "剩余能量 {{n}}",
			cost: "公开费用 {{n}}",
			price: "能量费用 {{n}}",
			gainDice: "立即获得",
			starter: "初始牌",
			used: "已使用",
			learn: "学习",
			move: "移动",
			hide: "隐藏",
			eat: "进食",
			playMode: "打牌",
			discardMode: "弃牌",
			winner: "{{name}} 获胜",
			caught: "鲨鱼成功捕获章鱼",
			exhaustion: "鲨鱼耗尽体力，章鱼成功生存",
			foodWin: "章鱼吃完四种食物",
			noStrike: "鲨鱼已无可用红骰，且仅剩一个饥饿空位",
			reviewBoard: "查看最终版图",
			playAgain: "再来一局",
			backLobby: "返回大堂",
			confirmAgain: "确认重新开始？",
			confirmBack: "确认返回大堂？",
			invalidAction: "当前不能执行这个行动",
			staleAction: "局面已经更新，请重新选择",
			log_swapped: "交换了两个相邻方块",
			log_shuffled: "洗混了所选方块",
			log_played: "章鱼打出了一张牌",
			log_revealed: "揭示了区域 {{n}}",
			log_octopusRevealed: "章鱼在区域 {{n}} 公开现身",
			log_ate: "章鱼吃下了一种食物",
			log_bought: "鲨鱼购买了一张牌",
			log_hunger: "饥饿轨已有 {{n}} 个骰子",
			log_growth: "解锁了第 {{n}} 项成长能力",
			log_escaped: "章鱼从对峙中逃脱",
			growth1: "每回合可以重投一个骰子。",
			growth2: "使用能量时，原总点数为 1–5 则额外获得 5 点。",
			growth3: "每回合可以额外重投一次。",
			growth4: "每回合额外抽取一个骰子。",
			rules: "目标：鲨鱼必须用红骰攻击章鱼，并在秘密对峙中选中同色牌。章鱼吃完四种食物，或使鲨鱼的第七个骰子进入饥饿轨，便立即获胜。\n准备：章鱼以八张初始牌组成牌组，快速学习和随机三张牌为起手。九个隐藏方块包括章鱼、隐藏陷阱和七个贝壳。鲨鱼的骰袋内有七颗蓝色骰子、三颗黄色骰子和一颗红色骰子；市场展示四张牌。章鱼选择起始巢穴并先行。\n章鱼回合：\n章鱼每回合必须执行两次行动，可以重复选择同一种行动。\n· 打出卡牌：打出 1 张手牌，并公开足够数量的方块来支付全部费用；双贝壳方块按两个方块计算。只有能够完成卡牌的全部必选效果时，才能打出该牌。\n· 补充手牌：抽牌至手牌上限。没有手牌时，必须选择此行动。\n· 弃置手牌：弃置 1 张手牌。如果场上有已公开的方块，还必须将其中 1 个转为隐藏状态。\n打出的卡牌直到回合结束时才进入弃牌堆。抽牌堆不足时，将弃牌堆洗混，组成新的抽牌堆。\n交换与洗混：交换仅限正交相邻方块，保留各自公开状态。洗混会将指定隐藏方块收入袋中随机抽出，由鲨鱼逐块选择空位，鲨鱼看不到身份。\n学习：\n每消耗 1 点学习能力，获得 1 张牌或 1 个方块。选择卡牌时，只能获得对应牌堆顶的牌，新牌通常放入弃牌堆。\n获得新方块时，用它替换版图上一个已公开的方块；不能替换章鱼或食物方块。新方块以公开状态放入版图。\n学习一张进食牌并同时获得对应食物方块，只需消耗 1 点学习能力。每回合最多学习 1 张进食牌，下一张进食牌要到回合结束时才公开。\n进食：章鱼与匹配食物正交相邻，打出对应进食牌，公开二者，用公开贝壳替换食物并移除该牌。食物的一次能力可在本方两个行动之前、之间或之后免费使用，也可留待以后。\n· 红岩蟹将手牌上限提高到五张，并将手牌补至上限。\n· 龙虾使版图上的全部方块转为隐藏状态。\n· 海螺允许从抽牌堆或弃牌堆中检索 1 张牌。\n· 南非鲍允许免费学习至多三项内容。\n鲨鱼回合：先随机抽两骰并投掷，成长可能允许重投或多抽。投骰前可用应变，投骰后可重投；接着在任意空水流位置放蓝骰，也可保留骰子作为能量。移动前可使用对应一次能力。\n游动：必须沿面朝方向移动，不能后退、掉头或原地停留。通常进入下一个空水流位置；遇到水流时，必须越过该位置；连续越过多个水流时，水流骰子的点数必须逐个减小。只移除本次游动中越过的第一枚蓝色骰子，稍后将它放入成长轨。巢穴起步可以任选两个方向。无法合法移动时，选择最近的阻挡水流，收回并游到该处。\n搜索与攻击：向鲨鱼相邻的一或两个区域分配黄／红骰，点数至少达到区域数值，每区域一个；必须先分配完，再决定揭示顺序。黄骰只能搜索隐藏方块，红骰可以攻击隐藏方块或已公开章鱼。揭示陷阱仅在由鲨鱼揭示时触发。若陷阱使鲨鱼离开另一待揭区域旁，那个骰子回袋。用过的黄骰进入成长，红骰攻击失败或逃脱后立即进入饥饿。\n陷阱：按其效果执行以下对应操作：\n· 隐藏至多两个其他方块。\n· 收回一个或至多两个水流。\n· 将鲨鱼送回一个空巢穴。如果所有巢穴都有水流，先收回其中一个水流。\n成长与能量：\n成长轨每填入 3 枚骰子，就解锁下一项能力，再将这 3 枚骰子放回骰袋。\n将骰池中尚未使用的全部骰子放入能量区。如果超过 3 枚，选择保留其中 3 枚，其余放回骰袋。\n· 能量区有 1 枚或 2 枚骰子时，可以选择购买卡牌；有 3 枚骰子时，必须购买。如果有 3 枚骰子却无法支付任何卡牌的费用，将全部能量骰子放回骰袋，不增加饥饿。\n· 使用能量骰子的点数总和购买卡牌，可以依次购买多张，每次购买后立即补充市场。购买卡牌后，将牌面所示的骰子加入骰袋；获得的能力保留到之后一次性使用。\n· 每次购买阶段结束后，选择 1 枚能量骰子放入饥饿轨，其余能量骰子放回骰袋。\n· 购买前，可以使 1 枚能量骰子的点数减少 1，以更换市场中的 1 张牌。不能将骰子点数降到 1 以下，也不能更换唯一能够购买的牌；使用此方式更换卡牌后，必须进行购买。\n对峙：双方秘密选择一张剩余对峙牌，选同色则鲨鱼立即获胜；不同色则章鱼执行逃脱效果，移除章鱼所选牌及同色鲨鱼牌。\n· 选择「逃离」时，将章鱼转为隐藏状态，并且可以将它与另一个隐藏方块一起洗混。\n· 选择「反击」时，将鲨鱼送回巢穴。\n· 选择「退缩」时，交换章鱼与一个相邻方块的位置。\n日间与夜间版图可在开局选项切换。所有方块只正交相邻。公共弃牌和移除牌可随时查看；鲨鱼可查自己的骰袋，章鱼不可查看。\n操作：点击牌、骰子、方块或路径选择行动；多目标行动显示预览后确认。可以取消尚未提交的选择。规则依据：2024 基础版、Wonderbow v1.3。"
		},
		en: {
			name: "Kelp: Shark vs Octopus",
			desc: "A hidden octopus and a prowling shark compete in an asymmetric kelp forest.",
			octopus: "Octopus",
			shark: "Shark",
			day: "Day board",
			night: "Night board",
			boardOption: "Board",
			roleOption: "First seat role",
			turn: "Turn {{n}}",
			actions: "{{n}} actions left",
			waiting: "Waiting for {{name}}",
			watching: "Watching the game",
			resolving: "Resolving",
			hand: "Hand",
			market: "Learning piles",
			sharkMarket: "Shark market",
			abilities: "One-time abilities",
			spare: "Spare blocks",
			dice: "Dice pool",
			bag: "Bag ({{n}})",
			deck: "Draw pile ({{n}})",
			discardPile: "Discard pile",
			trashPile: "Trashed cards",
			history: "Game log",
			inspect: "Inspect piles",
			close: "Close",
			hunger: "Hunger",
			food: "Food",
			foodAbilityUsed: "{{name}}: ability used",
			foodAbilityUnused: "{{name}}: ability not used",
			emptyFoodSlot: "Empty food slot {{n}}",
			spareCount: "{{name}}, {{n}} remaining",
			die_blue: "Blue Current die",
			die_yellow: "Yellow Search die",
			die_red: "Red Strike die",
			growth: "Growth",
			energy: "Energy",
			saved: "Saved dice",
			handSize: "Hand limit {{n}}",
			blue: "Current",
			yellow: "Search",
			red: "Strike",
			hidden: "Hidden block",
			revealed: "Revealed",
			privateBlock: "Only you can see this",
			zone: "Zone {{n}}",
			node: "Current space {{n}}",
			empty: "Empty space",
			den: "Shark den",
			shell: "Shell",
			double: "Double shell",
			hideTrap: "Hide trap",
			currentTrap: "Discard-current trap",
			currentsTrap: "Discard-two-currents trap",
			denTrap: "Return-to-den trap",
			crab: "Red Rock Crab",
			lobster: "Cape Rock Lobster",
			snail: "Sea Snail",
			abalone: "South African Abalone",
			fastLearning: "Fast Learning",
			nimbleDodge: "Nimble Dodge",
			sneakingBy: "Sneaking By",
			disguised: "Disguised",
			newTactics: "New Tactics",
			camouflaged: "Camouflaged",
			moreTricks: "More Tricks",
			craftyIdeas: "Crafty Ideas",
			sharpSenses: "Sharp Senses",
			cloudOfInk: "Cloud Of Ink",
			suddenEvasion: "Sudden Evasion",
			takingChances: "Taking Chances",
			inPlainSight: "In Plain Sight",
			trickOfTheLight: "Trick Of The Light",
			intoTheShadows: "Into The Shadows",
			agile: "Agile",
			hostile: "Hostile",
			swift: "Swift",
			ruthless: "Ruthless",
			observant: "Observant",
			reactive: "Reactive",
			relentless: "Relentless",
			vigilant: "Vigilant",
			daringRed: "Choose the red die to turn to six",
			daringSacrifice: "Choose another die to place on Hunger",
			daring: "Daring",
			hungry: "Hungry",
			aggressive: "Aggressive",
			flight: "Flight",
			fight: "Fight",
			flinch: "Flinch",
			e_fastLearning: "Learn 2. You may put one gained card on top of your draw pile.",
			e_nimbleDodge: "Swap two orthogonally adjacent blocks, preserving their revealed states.",
			e_sneakingBy: "Shuffle two hidden blocks. The Shark chooses their empty spaces one at a time.",
			e_disguised: "Hide two revealed blocks.",
			e_newTactics: "Learn 1, then you may trash a card from your hand or discard pile.",
			e_camouflaged: "Hide one block. You may then swap it with an adjacent block.",
			e_moreTricks: "Learn 3, then you may trash a card from your hand or discard pile.",
			e_craftyIdeas: "Learn 2. You may hide gained blocks after putting them in play.",
			e_sharpSenses: "Learn 2. You may add one gained non-Eat card to your hand.",
			e_cloudOfInk: "Reveal the Octopus if necessary, then hide it and shuffle it with two other hidden blocks.",
			e_suddenEvasion: "Swap two adjacent blocks, then swap two adjacent blocks again. You may reuse a block.",
			e_takingChances: "Shuffle the centre block with two other hidden blocks. All return hidden.",
			e_inPlainSight: "Hide one or two blocks, then you may draw one card.",
			e_trickOfTheLight: "Hide one or two blocks, then you may trash one card from your hand or discard pile.",
			e_intoTheShadows: "Hide two blocks, then shuffle those two blocks.",
			e_crab: "Eat when adjacent to the Octopus. Ability: raise the hand limit to 5 and refill immediately.",
			e_lobster: "Eat when adjacent to the Octopus. Ability: hide all revealed blocks.",
			e_snail: "Eat when adjacent to the Octopus. Ability: retrieve a card from your draw or discard pile.",
			e_abalone: "Eat when adjacent to the Octopus. Ability: learn up to 3 for free.",
			e_agile: "Before moving: make a 180° turn.",
			e_hostile: "Immediately trash a random matching pair of confrontation cards, keeping the last pair.",
			e_swift: "During movement: move one additional empty Current space.",
			e_ruthless: "Before moving: increase a pool die by up to {{n}}, to a maximum of 6.",
			e_observant: "After revealing a trap: ignore its effect.",
			e_reactive: "Before rolling: return two pool dice to the bag, then choose one replacement die.",
			e_relentless: "During Draw & Roll: reroll one or two dice once each.",
			e_vigilant: "Before moving: save a die for use on a later turn, without changing its value.",
			e_daring: "Before moving: put another pool die on Hunger and turn a red pool die to 6.",
			e_hungry: "During Draw & Roll: draw and roll one extra die.",
			e_aggressive: "Gain the shown dice only.",
			e_flight: "Hide the Octopus. You may shuffle it with another hidden block.",
			e_fight: "Return the Shark to a free den.",
			e_flinch: "Swap the Octopus with an adjacent block.",
			p_den: "Choose the Shark’s starting den",
			p_octopus: "Choose an action or activate an eaten food ability",
			p_pay: "Choose blocks to pay the card’s reveal cost",
			p_hide: "Choose blocks to hide",
			p_swap: "Choose adjacent blocks to swap",
			p_shuffle: "Choose blocks to shuffle",
			p_placeShuffled: "Choose an empty space for the drawn hidden block",
			p_learn: "Learn {{n}} more item(s)",
			p_replace: "Replace a revealed non-Octopus, non-food block",
			p_top: "You may put a gained card on top of your draw pile",
			p_gainHand: "You may add one gained non-Eat card to your hand",
			p_inkHide: "The Octopus will hide and shuffle with other blocks",
			p_trash: "You may trash a card from your hand or discard pile",
			p_extraDraw: "You may draw one extra card",
			p_retrieveCard: "Choose a card to retrieve into your hand",
			p_removeCurrent: "You may return Currents to the Shark’s bag",
			p_drawDice: "Draw {{n}} dice; recover Currents first if needed",
			p_draw: "Roll the dice or use Reactive",
			p_reactive: "Choose a replacement die from the bag",
			p_roll: "You may reroll dice, then proceed to Currents",
			p_currents: "You may place Currents or use before-move abilities",
			p_move: "Choose a swimming path",
			p_attack: "Assign Search and Strike dice, then reveal",
			p_resolve: "Choose which zone to reveal first",
			p_trap: "Trap revealed; you may use Observant",
			p_confront: "Secretly choose a confrontation card",
			p_attackDone: "Resolve the used die",
			p_growth: "Resolve Growth",
			p_energy: "Store Energy or buy market cards",
			p_overflow: "Choose three Energy dice to keep",
			p_hungerPayment: "Choose an Energy die for Hunger",
			p_animating: "Resolving action",
			p_over: "Game over",
			c_play: "Play",
			c_pay: "Reveal selected blocks",
			c_discard: "Discard a card and hide a block",
			c_drawCards: "Refill hand",
			c_endTurn: "End turn",
			c_hide: "Hide selected blocks",
			c_swap: "Swap selected blocks",
			c_shuffle: "Shuffle selected blocks",
			c_placeShuffled: "Place hidden block",
			c_learnCard: "Learn this card",
			c_learnBlock: "Learn this block",
			c_replace: "Replace block",
			c_top: "Put on draw pile",
			c_gainHand: "Add to hand",
			c_trash: "Trash this card",
			c_extraDraw: "Draw one card",
			c_retrieveCard: "Retrieve card",
			c_removeCurrent: "Remove Current",
			c_den: "Go to den",
			c_foodAbility: "Activate food ability",
			c_drawDice: "Draw dice",
			c_recoverCurrent: "Recover Current",
			c_replacementDie: "Choose replacement die",
			c_roll: "Roll dice",
			c_finishRoll: "Proceed to Currents",
			c_reroll: "Reroll once",
			c_relentless: "Use Relentless",
			c_hungry: "Draw and roll an extra die",
			c_reactive: "Use Reactive",
			c_finishCurrents: "Start movement",
			c_useSaved: "Retrieve saved die",
			c_current: "Place Current",
			c_agile: "Turn around",
			c_swift: "Add one movement space",
			c_vigilant: "Save die",
			c_ruthless: "Increase by {{n}}",
			c_daring: "Use Daring",
			c_swim: "Swim along selected path",
			c_forcedSwim: "Recover blocking Current and move there",
			c_assignAttack: "Assign die",
			c_unassign: "Take back die",
			c_resolveAttacks: "Begin revealing",
			c_reveal: "Reveal this zone",
			c_triggerTrap: "Trigger trap",
			c_ignoreTrap: "Ignore trap",
			c_confront: "Choose confrontation card",
			c_keepEnergy: "Keep selected Energy dice",
			c_hungerPayment: "Move to Hunger",
			c_storeEnergy: "End turn and store Energy",
			c_spendEnergy: "Spend Energy",
			c_buy: "Buy this card",
			c_finishBuying: "Finish buying",
			c_refresh: "Lower die by one and replace market card",
			c_skip: "Skip optional effect",
			select: "Select",
			confirm: "Confirm",
			cancel: "Clear selection",
			choices: "{{n}} choices remain",
			mode_hand: "Add to hand",
			mode_hidden: "Enter hidden",
			mode_deck: "From draw pile",
			mode_discard: "From discard pile",
			remainingEnergy: "{{n}} Energy remaining",
			cost: "Reveal cost {{n}}",
			price: "Energy cost {{n}}",
			gainDice: "Gain immediately",
			starter: "Starter",
			used: "Used",
			learn: "Learn",
			move: "Move",
			hide: "Hide",
			eat: "Eat",
			playMode: "Play cards",
			discardMode: "Discard cards",
			winner: "{{name}} wins",
			caught: "The Shark caught the Octopus",
			exhaustion: "The Shark is exhausted; the Octopus survives",
			foodWin: "The Octopus ate all four foods",
			noStrike: "No usable Strike dice remain, with only one Hunger space left",
			reviewBoard: "View final board",
			playAgain: "Play again",
			backLobby: "Back to lobby",
			confirmAgain: "Start a new game?",
			confirmBack: "Return to the lobby?",
			invalidAction: "That action is not available now",
			staleAction: "The position has changed; choose again",
			log_swapped: "Two adjacent blocks were swapped.",
			log_shuffled: "The selected blocks were shuffled.",
			log_played: "The Octopus played a card",
			log_revealed: "Revealed zone {{n}}",
			log_octopusRevealed: "The Octopus revealed itself in zone {{n}}",
			log_ate: "The Octopus ate a food",
			log_bought: "The Shark bought a card",
			log_hunger: "Hunger now holds {{n}} dice",
			log_growth: "Unlocked Growth ability {{n}}",
			log_escaped: "The Octopus escaped the confrontation",
			growth1: "Reroll one die per turn.",
			growth2: "When spending Energy with a total of 1–5, gain 5 extra Energy.",
			growth3: "Reroll one additional time per turn.",
			growth4: "Draw one extra die per turn.",
			rules: "Goal: The Shark must strike the Octopus and choose the matching confrontation colour. The Octopus wins immediately by eating four foods or when the seventh die enters Hunger.\nSetup: The Octopus starts with a deck of eight starter cards. Its opening hand contains Fast Learning and three randomly drawn cards. Nine hidden blocks contain the Octopus, a hide trap and seven shells. The Shark bag begins with seven blue, three yellow and one red die. Reveal four market cards. The Octopus chooses a starting den and takes the first turn.\nOctopus: Take two actions, which may repeat. Play a card, revealing blocks to pay its full cost; a double shell counts as two. You must complete all mandatory effects. Alternatively refill to your hand limit, or discard one hand card and hide one revealed block if possible. With an empty hand you must refill. Played cards enter the discard pile only at turn end. Shuffle discards when the draw pile runs out.\nSwap and shuffle: Swap orthogonally adjacent blocks, preserving revealed states. Shuffling randomises specified hidden blocks in the bag; the Shark chooses an empty space for each drawn block without seeing its identity.\nLearn: Spend each point on a top card or spare block. Gained cards normally enter discards. Gained blocks replace revealed non-Octopus, non-food blocks and enter revealed. An Eat card with its matching food costs one Learn point. Learn at most one Eat card per turn; reveal the next Eat card only at turn end.\nEat:\nPlay the matching Eat card while the Octopus is adjacent to that food. Reveal both blocks, replace the food with a revealed spare shell, and Remove the Eat card from the game. Each food grants a one-time free ability. You may use it before, between, or after your two actions, during the current turn or a later turn.\n· Crab raises your hand limit to five cards and refills your hand to that limit.\n· Lobster turns every block on the board face down.\n· Snail retrieves one card from your draw pile or discard pile.\n· Abalone allows you to Learn up to three items for free.\nShark: Draw two random dice and roll; Growth can add rerolls or a die. Use Reactive before rolling, then optional rerolls. Place blue dice on any empty Current spaces, or keep them for Energy. Use before-move abilities before swimming.\nMovement: Move forwards along connected paths, never backwards, reversing or standing still. Normally end at the next empty Current space. Skip Currents; a chain must strictly decrease. Remove only the first traversed Current for Growth later. At a den choose either direction. With no legal movement, recover a nearest blocking Current and move to that space.\nSearch and Strike: Assign yellow/red dice to one or two adjacent zones, one die per zone, meeting the zone value. Assign both before choosing reveal order. Yellow searches hidden blocks. Red strikes hidden blocks or a revealed Octopus. Traps trigger only when revealed by the Shark. If a trap moves the Shark away from the other assigned zone, return that die to the bag. Used yellow dice go to Growth; red misses and escaped strikes immediately go to Hunger.\nTraps:\nResolve the effect of the revealed trap:\n· Hide up to two other blocks.\n· Recover one Current, or up to two Currents, as specified by the trap.\n· Send the Shark to an empty den. If all dens contain Currents, recover one of those Currents first.\nGrowth and Energy: Every three Growth dice unlock the next ability, then return to the bag. Put all unused pool dice into Energy, keeping three if overflowing and returning the rest. With one or two Energy dice you may buy; with three you must buy. If three cannot afford any card, return all without Hunger. Spend total pips on any number of cards, refilling the market immediately. Gain shown dice into the bag; keep one-time abilities for later. After buying, choose exactly one Energy die for Hunger; return the others. Before buying, lower one Energy die by one to refresh a market card. Do not lower below one or discard the only affordable card; you must then buy.\nConfrontation:\nBoth players secretly choose one of their remaining confrontation cards. Matching colours give the Shark an immediate win. Otherwise, resolve the Octopus’s chosen escape effect and Remove its selected card and the matching Shark card from the game.\n· Flight hides the Octopus and allows it to be shuffled with another hidden block.\n· Fight returns the Shark to a den.\n· Flinch swaps the Octopus with an adjacent block.\nChoose day or night board in setup. Adjacency is orthogonal. Discards and trash are public; only the Shark may inspect its bag.\nControls: Select cards, dice, blocks or paths directly. Multi-target actions show a preview for confirmation. Cancel clears an unsubmitted selection. Based on the 2024 base game and Wonderbow rules v1.3."
		}
	}
};
//#endregion
export { Ue as default };
