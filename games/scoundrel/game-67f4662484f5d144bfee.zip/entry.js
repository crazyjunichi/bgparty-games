import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as o } from "@bgparty/sdk/fx/delta-number";
import { IconClose as s } from "@bgparty/sdk/icons";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { useWakeLock as u } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g } from "@bgparty/sdk/fx/primitives";
//#region src/games/scoundrel/cards.ts
var _ = {
	spades: "♠",
	clubs: "♣",
	hearts: "♥",
	diamonds: "♦"
}, v = {
	spades: "games.scoundrel.monsterType",
	clubs: "games.scoundrel.monsterType",
	diamonds: "games.scoundrel.weaponType",
	hearts: "games.scoundrel.potionType"
}, y = (e) => e.suit === "spades" || e.suit === "clubs", b = (e) => ({
	11: "J",
	12: "Q",
	13: "K",
	14: "A"
})[e] ?? String(e), x = (e) => `${e.suit}:${e.value}`, S = (e) => `${_[e.suit]}${b(e.value)}`, C = [
	"spades",
	"clubs",
	"hearts",
	"diamonds"
].flatMap((e) => Array.from({ length: e === "spades" || e === "clubs" ? 13 : 9 }, (t, n) => ({
	suit: e,
	value: n + 2
})));
function w(e, t, n) {
	return !!e && y(n) && (!t.length || n.value < t[t.length - 1].value);
}
//#endregion
//#region src/games/scoundrel/meta.ts
var T = {
	id: "scoundrel",
	tier: "beta",
	mechanics: ["hand-management", "push-your-luck"],
	interactionTags: [],
	nameKey: "games.scoundrel.name",
	descKey: "games.scoundrel.desc",
	rulesKey: "games.scoundrel.rules",
	icon: "🗝️",
	iconImg: "games/scoundrel.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/scoundrel/en.pdf" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#b99555",
	releasedAt: "2026-10-18T11:30:17+08:00",
	search: {
		py: "e gun pai",
		init: "egp"
	},
	hotseat: "open",
	precacheAssets: ["candle-table.webp"]
}, E = t.object({
	suit: t.enum([
		"spades",
		"clubs",
		"hearts",
		"diamonds"
	]),
	value: t.int().min(2).max(14)
}), D = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("take"),
		slot: t.int().min(0).max(3),
		method: t.enum([
			"bare",
			"weapon",
			"use"
		])
	}),
	t.object({ type: t.literal("escape") }),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), O = t.object({
	player: t.string(),
	phase: t.enum([
		"play",
		"resolve",
		"escape",
		"deal",
		"done"
	]),
	hp: t.int(),
	room: t.array(E.nullable()).length(4),
	deckCount: t.int().nonnegative(),
	weapon: E.nullable(),
	defeated: t.array(E),
	discard: t.array(E),
	used: t.int().min(0).max(3),
	potionUsed: t.boolean(),
	canEscape: t.boolean(),
	result: t.object({
		win: t.boolean(),
		score: t.int(),
		remaining: t.int(),
		bonus: t.int()
	}).nullable()
}), k = t.object({}), A = {
	resolve: 720,
	escape: 480,
	deal: 460
};
function j(e) {
	return e.phase === "play" && e.used === 0 && !e.escapedLast && e.room.every(Boolean);
}
function M(e) {
	let t = [];
	for (let n = 0; n < 4 && e.deck.length; n++) {
		if (e.room[n]) continue;
		let r = e.deck.shift();
		e.room[n] = r, t.push({
			slot: n,
			card: r
		});
	}
	return e.phase = "deal", t.length ? [{
		kind: "scDeal",
		data: { cards: t }
	}] : [];
}
function N(e) {
	let t = e.hp > 0, n = [...e.deck, ...e.room.filter((e) => !!e)].filter(y).reduce((e, t) => e + t.value, 0), r = t && e.hp === 20 && e.lastCard?.suit === "hearts" ? e.lastCard.value : 0;
	e.result = {
		win: t,
		score: t ? e.hp + r : e.hp - n,
		remaining: t ? 0 : n,
		bonus: r
	}, e.phase = "done";
}
var P = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: T,
	schemas: {
		action: D,
		publicView: O,
		privateView: k
	},
	setup(t, n, r) {
		let i = C.map((e) => ({ ...e }));
		for (let t = i.length - 1, n = 0; t > 0; t--, n++) {
			let a = e(r, n, t + 1);
			[i[t], i[a]] = [i[a], i[t]];
		}
		return { state: {
			player: n[0],
			phase: "deal",
			hp: 20,
			room: [
				null,
				null,
				null,
				null
			],
			deck: i,
			weapon: null,
			defeated: [],
			discard: [],
			used: 0,
			potionUsed: !1,
			escapedLast: !1,
			lastCard: null,
			result: null
		} };
	},
	reduce(e, t, n) {
		let r = (e) => ({ code: e });
		if (t.type === "tick") {
			if (n.by !== "$engine") return r("games.scoundrel.errorTurn");
			if (e.phase === "play" || e.phase === "done") return { state: e };
			let t = structuredClone(e);
			return t.phase === "deal" ? t.room.every((e) => !e) && t.deck.length ? {
				state: t,
				fx: M(t)
			} : (t.phase = "play", { state: t }) : t.phase === "escape" ? {
				state: t,
				fx: M(t)
			} : t.hp <= 0 || !t.deck.length && t.room.every((e) => !e) ? (N(t), { state: t }) : (t.used === 3 || t.room.every((e) => !e)) && (t.used = 0, t.potionUsed = !1, t.escapedLast = !1, t.deck.length) ? {
				state: t,
				fx: M(t)
			} : (t.phase = "play", { state: t });
		}
		if (n.by !== e.player || e.phase !== "play") return r("games.scoundrel.errorTurn");
		if (t.type === "escape") {
			if (!j(e)) return r("games.scoundrel.errorEscape");
			let t = structuredClone(e), n = t.room.map((e, t) => ({
				card: e,
				slot: t
			}));
			return t.deck.push(...n.map(({ card: e }) => e)), t.room = [
				null,
				null,
				null,
				null
			], t.escapedLast = !0, t.phase = "escape", {
				state: t,
				fx: [{
					kind: "scEscape",
					data: { cards: n }
				}]
			};
		}
		let i = e.room[t.slot];
		if (!i) return r("games.scoundrel.errorCard");
		if (y(i)) {
			if (t.method === "use" || t.method === "weapon" && !w(e.weapon, e.defeated, i)) return r("games.scoundrel.errorWeapon");
		} else if (t.method !== "use") return r("games.scoundrel.errorCard");
		let a = structuredClone(e), o = a.weapon, s = [...a.defeated], c = a.hp;
		a.room[t.slot] = null, a.used++, a.lastCard = i, a.phase = "resolve";
		let l = "sc-discard";
		return y(i) ? (a.hp -= t.method === "weapon" ? Math.max(0, i.value - a.weapon.value) : i.value, t.method === "weapon" ? (a.defeated.push(i), l = "sc-defeated") : a.discard.push(i)) : i.suit === "hearts" ? (a.potionUsed || (a.hp = Math.min(20, a.hp + i.value), l = "sc-health"), a.potionUsed = !0, a.discard.push(i)) : (a.weapon && a.discard.push(a.weapon, ...a.defeated), a.weapon = i, a.defeated = [], l = "sc-weapon"), {
			state: a,
			fx: [{
				kind: "scTake",
				data: {
					card: i,
					slot: t.slot,
					target: l,
					delta: a.hp - c,
					oldWeapon: i.suit === "diamonds" ? o : null,
					oldDefeated: i.suit === "diamonds" ? s : [],
					defeatedCount: a.defeated.length
				}
			}]
		};
	},
	viewFor(e) {
		return { public: {
			player: e.player,
			phase: e.phase,
			hp: e.hp,
			room: e.room.map((e) => e && { ...e }),
			deckCount: e.deck.length,
			weapon: e.weapon && { ...e.weapon },
			defeated: e.defeated.map((e) => ({ ...e })),
			discard: e.discard.map((e) => ({ ...e })),
			used: e.used,
			potionUsed: e.potionUsed,
			canEscape: j(e),
			result: e.result && { ...e.result }
		} };
	},
	status(e) {
		return e.result ? {
			phase: e.phase,
			winner: e.result.win ? [e.player] : [],
			ranking: [e.player],
			scores: { [e.player]: e.result.score }
		} : { phase: e.phase };
	},
	nextTickIn(e) {
		return e.phase === "play" || e.phase === "done" ? null : A[e.phase];
	}
}, F = {
	2: [[50, 38], [50, 102]],
	3: [
		[50, 38],
		[50, 70],
		[50, 102]
	],
	4: [
		[34, 38],
		[66, 38],
		[34, 102],
		[66, 102]
	],
	5: [
		[34, 38],
		[66, 38],
		[50, 70],
		[34, 102],
		[66, 102]
	],
	6: [
		[34, 38],
		[66, 38],
		[34, 70],
		[66, 70],
		[34, 102],
		[66, 102]
	],
	7: [
		[34, 38],
		[66, 38],
		[50, 54],
		[34, 70],
		[66, 70],
		[34, 102],
		[66, 102]
	],
	8: [
		[34, 38],
		[66, 38],
		[50, 54],
		[34, 70],
		[66, 70],
		[50, 86],
		[34, 102],
		[66, 102]
	],
	9: [
		[34, 35],
		[66, 35],
		[34, 58],
		[66, 58],
		[50, 70],
		[34, 82],
		[66, 82],
		[34, 105],
		[66, 105]
	],
	10: [
		[34, 35],
		[66, 35],
		[50, 46],
		[34, 58],
		[66, 58],
		[34, 82],
		[66, 82],
		[50, 94],
		[34, 105],
		[66, 105]
	]
};
function I({ card: e, compact: t = !1 }) {
	let n = l(), r = e.suit === "hearts" || e.suit === "diamonds", i = _[e.suit];
	return /* @__PURE__ */ m("svg", {
		className: "sc-card-face",
		viewBox: "0 0 100 140",
		"aria-hidden": "true",
		"data-red": r || void 0,
		children: [
			/* @__PURE__ */ p("rect", {
				className: "sc-card-paper",
				x: "1",
				y: "1",
				width: "98",
				height: "138",
				rx: "5"
			}),
			/* @__PURE__ */ p("rect", {
				className: "sc-card-inset",
				x: "3.2",
				y: "3.2",
				width: "93.6",
				height: "133.6",
				rx: "3.4"
			}),
			!t && /* @__PURE__ */ m("g", {
				className: "sc-card-type",
				"data-suit": e.suit,
				children: [/* @__PURE__ */ p("rect", {
					x: "54",
					y: "7",
					width: "39",
					height: "16",
					rx: "1.5"
				}), /* @__PURE__ */ p("text", {
					x: "73.5",
					y: "18.5",
					textAnchor: "middle",
					fontFamily: "'Microsoft YaHei', sans-serif",
					fontSize: "9",
					children: n(v[e.suit])
				})]
			}),
			/* @__PURE__ */ m("g", {
				className: "sc-card-ink",
				fontFamily: "Georgia, 'Times New Roman', serif",
				fontWeight: "bold",
				textAnchor: "middle",
				children: [
					/* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("text", {
						x: "12",
						y: "20",
						fontSize: "18",
						children: b(e.value)
					}), /* @__PURE__ */ p("text", {
						x: "12",
						y: "36",
						fontSize: "15",
						children: i
					})] }),
					!t && /* @__PURE__ */ m("g", {
						transform: "rotate(180 50 70)",
						children: [/* @__PURE__ */ p("text", {
							x: "12",
							y: "20",
							fontSize: "18",
							children: b(e.value)
						}), /* @__PURE__ */ p("text", {
							x: "12",
							y: "36",
							fontSize: "15",
							children: i
						})]
					}),
					t ? /* @__PURE__ */ p("text", {
						x: "53",
						y: "90",
						fontSize: "53",
						children: i
					}) : e.value <= 10 ? F[e.value].map(([e, t], n) => /* @__PURE__ */ p("text", {
						x: e,
						y: t + 7,
						fontSize: "24",
						transform: t > 70 ? `rotate(180 ${e} ${t})` : void 0,
						children: i
					}, n)) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("text", {
						x: "52",
						y: "78",
						fontSize: "52",
						children: b(e.value)
					}), /* @__PURE__ */ p("text", {
						x: "52",
						y: "111",
						fontSize: "31",
						children: i
					})] })
				]
			})
		]
	});
}
function L() {
	return /* @__PURE__ */ m("svg", {
		className: "sc-card-face sc-card-back",
		viewBox: "0 0 100 140",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("rect", {
				className: "sc-card-paper",
				x: "1",
				y: "1",
				width: "98",
				height: "138",
				rx: "5"
			}),
			/* @__PURE__ */ p("rect", {
				className: "sc-back-fill",
				x: "7",
				y: "7",
				width: "86",
				height: "126",
				rx: "2"
			}),
			/* @__PURE__ */ p("path", {
				className: "sc-back-lines",
				d: "M8 30 30 8M8 55 55 8M8 80 80 8M8 105 92 21M8 130 92 46M28 132 92 68M52 132 92 92M76 132 92 116"
			}),
			/* @__PURE__ */ p("text", {
				className: "sc-back-symbol",
				x: "50",
				y: "85",
				textAnchor: "middle",
				fontSize: "55",
				children: "♠"
			})
		]
	});
}
function R() {
	return /* @__PURE__ */ p("svg", {
		className: "sc-ants",
		"aria-hidden": "true",
		children: /* @__PURE__ */ p("rect", {
			x: "1",
			y: "1",
			width: "calc(100% - 2px)",
			height: "calc(100% - 2px)",
			rx: "7",
			vectorEffect: "non-scaling-stroke"
		})
	});
}
//#endregion
//#region src/games/scoundrel/view-player.tsx
function z({ card: e, slot: t, active: n, selected: r, showHint: i, onSelect: o }) {
	let s = l(), { ref: c } = a(`sc-slot:${t}`), { ref: u, hidden: d } = a(e ? `sc-card:${x(e)}` : null);
	return /* @__PURE__ */ p("div", {
		className: "sc-slot",
		ref: c,
		children: e && /* @__PURE__ */ m("button", {
			type: "button",
			ref: u,
			className: "sc-room-card",
			"data-selected": r || void 0,
			style: { visibility: d ? "hidden" : void 0 },
			disabled: !n,
			"aria-label": s("games.scoundrel.chooseCard", {
				card: S(e),
				type: s(v[e.suit])
			}),
			"aria-pressed": r,
			onClick: o,
			children: [/* @__PURE__ */ p(I, { card: e }), n && i && /* @__PURE__ */ p(R, {})]
		})
	});
}
function B({ v: e }) {
	let t = l(), { ref: n, hidden: r } = a("sc-weapon"), { ref: i, hidden: o } = a("sc-defeated"), s = e.defeated.length ? e.defeated[e.defeated.length - 1].value - 1 : null;
	return /* @__PURE__ */ m("div", {
		className: "sc-equipment",
		children: [
			/* @__PURE__ */ p("div", {
				className: "sc-equipped",
				ref: n,
				style: { visibility: r ? "hidden" : void 0 },
				children: e.weapon ? /* @__PURE__ */ p(I, {
					card: e.weapon,
					compact: !0
				}) : /* @__PURE__ */ p("span", {
					className: "sc-weapon-empty",
					children: "♦"
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "sc-kills",
				ref: i,
				children: e.defeated.slice(-2).map((e, t, n) => /* @__PURE__ */ p("div", {
					className: "sc-kill",
					style: {
						left: `${t * 35}%`,
						top: `${(1 - t) * 14}%`,
						visibility: o && t === n.length - 1 ? "hidden" : void 0
					},
					children: /* @__PURE__ */ p(I, {
						card: e,
						compact: !0
					})
				}, x(e)))
			}),
			/* @__PURE__ */ p("div", {
				className: "sc-limit",
				children: e.weapon ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { children: t("games.scoundrel.attackLimit") }), /* @__PURE__ */ p("strong", { children: s === null ? t("games.scoundrel.anyMonster") : s < 2 ? t("games.scoundrel.none") : t("games.scoundrel.limit", { n: s }) })] }) : /* @__PURE__ */ p("span", { children: t("games.scoundrel.noWeapon") })
			})
		]
	});
}
function V({ public: e, myRid: t, send: n }) {
	u();
	let r = l(), h = c((e) => e.locale), g = e, [_, v] = i(null), b = g.phase === "play" && t === g.player, S = b && _ && g.room[_.slot] && x(g.room[_.slot]) === _.id ? _.slot : null, C = S === null ? null : g.room[S], T = a("sc-health"), E = a("sc-deck"), D = a("sc-discard"), O = (e) => {
		S !== null && (v(null), n({
			type: "take",
			slot: S,
			method: e
		}));
	}, k = (e) => r(e ? "games.scoundrel.lose" : "games.scoundrel.noLoss", { n: e }), A = (e, t, n, r = !1) => /* @__PURE__ */ m("button", {
		className: "sc-action",
		type: "button",
		disabled: r,
		onClick: () => O(e),
		children: [
			/* @__PURE__ */ p("span", { children: t }),
			/* @__PURE__ */ p("small", { children: n }),
			!r && /* @__PURE__ */ p(R, {})
		]
	});
	return /* @__PURE__ */ p("div", {
		className: "sc-game",
		"data-locale": h,
		onKeyDown: (e) => {
			e.key === "Escape" && v(null);
		},
		children: /* @__PURE__ */ p(d, {
			adaptive: !0,
			className: "sc-layout",
			scroll: !1,
			children: /* @__PURE__ */ m("div", {
				className: "sc-scene",
				style: { backgroundImage: "url(\"./games/scoundrel/candle-table.webp\")" },
				children: [
					/* @__PURE__ */ m("div", {
						className: "sc-top",
						children: [
							/* @__PURE__ */ m("div", {
								className: "sc-health",
								ref: T.ref,
								role: "status",
								"aria-label": r("games.scoundrel.health", { n: g.hp }),
								children: [
									/* @__PURE__ */ p("span", {
										className: "sc-heart",
										"aria-hidden": "true",
										children: "♥"
									}),
									/* @__PURE__ */ p(o, {
										value: g.hp,
										className: "sc-health-value font-mono tabular-nums"
									}),
									/* @__PURE__ */ p("small", { children: "/20" })
								]
							}),
							/* @__PURE__ */ p("span", {
								className: "sc-progress",
								"aria-live": "polite",
								children: r(g.phase === "play" ? "games.scoundrel.remaining" : g.phase === "deal" ? "games.scoundrel.entering" : g.phase === "escape" ? "games.scoundrel.escaping" : "games.scoundrel.resolving", { n: Math.min(3 - g.used, g.room.filter(Boolean).length) })
							}),
							/* @__PURE__ */ m("div", {
								className: "sc-deck",
								"aria-label": r("games.scoundrel.deck", { n: g.deckCount }),
								children: [/* @__PURE__ */ p("div", {
									className: "sc-deck-pile",
									ref: E.ref,
									children: /* @__PURE__ */ p(L, {})
								}), /* @__PURE__ */ p("span", {
									className: "font-mono tabular-nums",
									children: g.deckCount
								})]
							})
						]
					}),
					/* @__PURE__ */ p("div", {
						className: "sc-room",
						children: g.room.map((e, t) => /* @__PURE__ */ p(z, {
							card: e,
							slot: t,
							active: b,
							selected: S === t,
							showHint: S === null,
							onSelect: () => v(e && S !== t ? {
								slot: t,
								id: x(e)
							} : null)
						}, t))
					}),
					/* @__PURE__ */ p("div", {
						className: "sc-discard",
						ref: D.ref,
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ m("div", {
						className: "sc-side",
						children: [/* @__PURE__ */ p(B, { v: g }), /* @__PURE__ */ p("div", {
							className: "sc-controls",
							children: C && S !== null ? /* @__PURE__ */ m("div", {
								className: "sc-choice",
								children: [/* @__PURE__ */ p("button", {
									type: "button",
									className: "sc-cancel",
									"aria-label": r("games.scoundrel.cancel"),
									onClick: () => v(null),
									children: /* @__PURE__ */ p(s, { size: 18 })
								}), y(C) ? /* @__PURE__ */ m(f, { children: [A("bare", r("games.scoundrel.bare"), k(C.value)), A("weapon", r("games.scoundrel.armed"), w(g.weapon, g.defeated, C) ? k(Math.max(0, C.value - g.weapon.value)) : r("games.scoundrel.unavailable"), !w(g.weapon, g.defeated, C))] }) : C.suit === "diamonds" ? A("use", r("games.scoundrel.equip"), r(g.weapon ? "games.scoundrel.replace" : "games.scoundrel.fresh")) : A("use", r(g.potionUsed ? "games.scoundrel.discardPotion" : "games.scoundrel.potion"), r(g.potionUsed ? "games.scoundrel.potionSpent" : g.hp === 20 ? "games.scoundrel.full" : "games.scoundrel.heal", { n: Math.min(C.value, 20 - g.hp) }))]
							}, x(C)) : b && g.canEscape ? /* @__PURE__ */ p("button", {
								className: "sc-escape",
								type: "button",
								onClick: () => n({ type: "escape" }),
								children: r("games.scoundrel.escape")
							}) : null
						})]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/scoundrel/bot.ts
function H(e) {
	return e.room.flatMap((t, n) => t ? y(t) ? [{
		type: "take",
		slot: n,
		method: "bare"
	}, ...w(e.weapon, e.defeated, t) ? [{
		type: "take",
		slot: n,
		method: "weapon"
	}] : []] : [{
		type: "take",
		slot: n,
		method: "use"
	}] : []);
}
function U(e, t) {
	let n = structuredClone(e), r = n.room[t.slot];
	return n.room[t.slot] = null, n.used++, y(r) ? (n.hp -= t.method === "weapon" ? Math.max(0, r.value - n.weapon.value) : r.value, t.method === "weapon" ? n.defeated.push(r) : n.discard.push(r)) : r.suit === "diamonds" ? (n.weapon && n.discard.push(n.weapon, ...n.defeated), n.weapon = r, n.defeated = []) : (n.potionUsed || (n.hp = Math.min(20, n.hp + r.value)), n.potionUsed = !0, n.discard.push(r)), n;
}
function W(e) {
	if (e.hp <= 0) return -1e3 + e.hp;
	let t = e.defeated.length ? e.defeated[e.defeated.length - 1].value - 1 : 14, n = e.weapon ? e.weapon.value * Math.min(1, t / 9) * 1.15 : 0, r = new Set([
		...e.discard,
		...e.defeated,
		...e.weapon ? [e.weapon] : []
	].map(x)), i = 0;
	for (let e of C) r.has(x(e)) || (i += y(e) ? -e.value * .45 : e.value * (e.suit === "hearts" ? .8 : 1.1));
	return e.hp + n + i;
}
function G(e, t) {
	if (t === 0 || e.hp <= 0 || e.used === 3 || e.room.every((e) => !e)) return { score: W(e) };
	let n = { score: -Infinity };
	for (let r of H(e)) {
		let i = G(U(e, r), t - 1).score;
		i > n.score && (n = {
			score: i,
			action: r
		});
	}
	return n;
}
var K = ({ public: e }, t) => {
	if (e.player !== t.rid || e.phase !== "play") return null;
	let n = G(e, t.difficulty === "weak" ? 1 : 3);
	return e.canEscape && n.score < W(e) - 4 ? { action: { type: "escape" } } : n.action ? { action: n.action } : null;
}, q = (e, { public: t }, n) => {
	if (e.type === "escape") return n("games.scoundrel.hintEscape");
	if (e.type !== "take" || !t.room[e.slot]) return "";
	let r = t.room[e.slot], i = e.method === "bare" ? n("games.scoundrel.bare") : e.method === "weapon" ? n("games.scoundrel.armed") : r.suit === "diamonds" ? n("games.scoundrel.equip") : n(t.potionUsed ? "games.scoundrel.discardPotion" : "games.scoundrel.potion");
	return n("games.scoundrel.hintTake", {
		card: S(r),
		action: i
	});
};
//#endregion
//#region src/games/scoundrel/fx.tsx
function J(e) {
	let t = Math.min(e.w, e.h * 5 / 7), n = t * 7 / 5;
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
function Y(e, t) {
	return J({
		x: e.x + t * e.w * .35,
		y: e.y + (1 - t) * e.h * .14,
		w: e.w * .65,
		h: e.h * .88
	});
}
function X({ card: e, from: t, to: i, delay: a }) {
	let o = r(null);
	return n(() => {
		let e = o.current;
		if (!e) return;
		let n = t.x + t.w / 2 - i.x - i.w / 2, r = t.y + t.h / 2 - i.y - i.h / 2, s = t.w / i.w, c = e.animate([
			{ transform: `translate(${n}px, ${r}px) scale(${s})` },
			{
				transform: `translate(${n * .45}px, ${r * .45 - 14}px) scale(${s + (1 - s) * .55})`,
				offset: .55
			},
			{ transform: "translate(0px, 0px) scale(1)" }
		], {
			duration: 300,
			delay: a,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => c.cancel();
	}, [
		t,
		i,
		a
	]), /* @__PURE__ */ p("div", {
		className: "sc-deal-card",
		ref: o,
		style: {
			left: i.x,
			top: i.y,
			width: i.w,
			height: i.h
		},
		children: /* @__PURE__ */ p(I, { card: e })
	});
}
var Z = {
	scDeal(e, t) {
		if (t.queued) return null;
		let n = e.data, r = t.anchor("sc-deck");
		if (!r) return null;
		let i = [], a = n.cards.map(({ card: e }, n) => {
			let a = `sc-card:${x(e)}`, o = t.anchor(a);
			return o ? (i.push(a), /* @__PURE__ */ p(X, {
				card: e,
				from: J(r),
				to: J(o),
				delay: n * 40
			}, a)) : null;
		});
		return {
			ms: A.deal,
			node: a,
			hide: i
		};
	},
	scEscape(e, t) {
		if (t.queued) return null;
		let n = e.data, r = t.anchor("sc-deck");
		if (!r) return null;
		let i = J(r);
		return {
			ms: A.escape,
			node: n.cards.map(({ card: e, slot: n }) => {
				let r = t.anchor(`sc-slot:${n}`), a = r && J(r);
				return a ? /* @__PURE__ */ p(g, {
					from: a,
					to: i,
					ms: A.escape - 40,
					children: /* @__PURE__ */ p("div", {
						className: "sc-fx-card",
						style: {
							width: a.w,
							height: a.h
						},
						children: /* @__PURE__ */ p(I, { card: e })
					})
				}, n) : null;
			})
		};
	},
	scTake(e, t) {
		if (t.queued) return null;
		let n = e.data, r = t.anchor(`sc-slot:${n.slot}`), i = r && J(r), a = t.anchor(n.target), o = t.anchor("sc-health"), s = t.anchor("sc-discard"), c = t.anchor("sc-weapon"), l = c && J(c), u = t.anchor("sc-defeated");
		if (!i || !a) return null;
		let d = n.target === "sc-defeated" ? Y(a, +(n.defeatedCount > 1)) : n.target === "sc-health" ? {
			x: a.x + a.w / 2 - 10,
			y: a.y,
			w: 20,
			h: 28
		} : J(a);
		return {
			ms: A.resolve,
			hide: n.target === "sc-weapon" || n.target === "sc-defeated" ? [n.target] : [],
			node: /* @__PURE__ */ m(f, { children: [
				n.oldWeapon && l && s && /* @__PURE__ */ p(g, {
					from: l,
					to: s,
					ms: 400,
					children: /* @__PURE__ */ p("div", {
						className: "sc-fx-card",
						style: {
							width: l.w,
							height: l.h
						},
						children: /* @__PURE__ */ p(I, {
							card: n.oldWeapon,
							compact: !0
						})
					})
				}),
				n.oldDefeated.slice(-2).map((e, t) => {
					if (!u || !s) return null;
					let n = Y(u, t);
					return /* @__PURE__ */ p(g, {
						from: n,
						to: s,
						ms: 400,
						children: /* @__PURE__ */ p("div", {
							className: "sc-fx-card",
							style: {
								width: n.w,
								height: n.h
							},
							children: /* @__PURE__ */ p(I, {
								card: e,
								compact: !0
							})
						})
					}, x(e));
				}),
				/* @__PURE__ */ p(g, {
					from: i,
					to: d,
					ms: 520,
					children: /* @__PURE__ */ p("div", {
						className: "sc-fx-card",
						style: {
							width: i.w,
							height: i.h
						},
						children: /* @__PURE__ */ p(I, { card: n.card })
					})
				}),
				!!n.delta && o && /* @__PURE__ */ p(h, {
					at: {
						...o,
						y: o.y + o.h + 18
					},
					ms: A.resolve,
					children: /* @__PURE__ */ m("span", {
						className: "sc-fx-delta",
						"data-heal": n.delta > 0 || void 0,
						children: [n.delta > 0 ? "+" : "−", Math.abs(n.delta)]
					})
				})
			] })
		};
	}
};
//#endregion
//#region src/games/scoundrel/game-over.tsx
function Q({ public: e, onPlayAgain: t, onBackToLobby: n }) {
	let r = l(), a = e, [o, s] = i(!1);
	return a.result ? /* @__PURE__ */ p("div", {
		className: "sc-over",
		style: { backgroundImage: "url(\"./games/scoundrel/candle-table.webp\")" },
		children: /* @__PURE__ */ m("div", {
			className: "sc-over-sheet",
			children: [
				/* @__PURE__ */ p("h1", { children: r(a.result.win ? "games.scoundrel.victory" : "games.scoundrel.defeat") }),
				/* @__PURE__ */ p("span", { children: r("games.scoundrel.score") }),
				/* @__PURE__ */ p("strong", {
					className: "sc-over-score font-mono tabular-nums",
					children: a.result.score
				}),
				/* @__PURE__ */ m("dl", { children: [
					/* @__PURE__ */ p("dt", { children: r("games.scoundrel.finalHealth") }),
					/* @__PURE__ */ p("dd", { children: a.hp }),
					!a.result.win && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("dt", { children: r("games.scoundrel.unhandled") }), /* @__PURE__ */ m("dd", { children: ["−", a.result.remaining] })] }),
					!!a.result.bonus && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("dt", { children: r("games.scoundrel.bonus") }), /* @__PURE__ */ m("dd", { children: ["+", a.result.bonus] })] })
				] }),
				o && /* @__PURE__ */ p("p", {
					role: "alert",
					children: r("games.scoundrel.confirmAgain")
				}),
				/* @__PURE__ */ m("div", {
					className: "sc-over-actions",
					children: [
						t && /* @__PURE__ */ p("button", {
							type: "button",
							className: "sc-escape",
							onClick: () => o ? t() : s(!0),
							children: r(o ? "games.scoundrel.confirm" : "session.result.playAgain")
						}),
						o && /* @__PURE__ */ p("button", {
							type: "button",
							className: "sc-escape",
							onClick: () => s(!1),
							children: r("games.scoundrel.cancelRestart")
						}),
						n && !o && /* @__PURE__ */ p("button", {
							type: "button",
							className: "sc-escape",
							onClick: n,
							children: r("session.result.backToLobby")
						}),
						!t && !n && /* @__PURE__ */ p("span", { children: r("session.result.waitHost") })
					]
				})
			]
		})
	}) : null;
}
//#endregion
//#region .bgparty/cache/pack-entry/scoundrel/entry.tsx
var $ = {
	definition: P,
	View: V,
	bot: K,
	describe: q,
	fx: Z,
	OverView: Q,
	locales: {
		zh: {
			name: "恶棍牌（Scoundrel）",
			desc: "用一副扑克牌探索地牢，选择战斗、武器与药水。",
			rules: "目标：\n· 处理全部 44 张牌，并让生命保持在 0 以上。\n准备：\n· 生命初始为 20，上限为 20。\n· 黑桃和梅花为怪物，包含 2 至 A。\n· J、Q、K、A 的点数分别为 11、12、13、14。\n· 方块 2 至 10 为武器，红桃 2 至 10 为药水。\n房间：\n· 每回合补牌至 4 张，自选顺序处理其中 3 张。\n· 留下的牌保留原位，下回合补充其余空位。\n· 牌堆耗尽后，继续处理剩余牌，每回合最多处理 3 张。\n· 开始处理前，可以逃离有 4 张牌的房间。\n· 逃离的牌按房间位置顺序移到牌堆底，不重新洗牌。\n· 不能连续逃离，处理完一个回合后才能再次逃离。\n战斗与装备：\n· 徒手战斗会失去等于怪物点数的生命。\n· 处理武器牌时，必须装备它并弃置旧武器及其击败记录。\n· 武器攻击失去怪物点数超过武器点数的那部分生命。\n· 同一把武器此后只能攻击比上次击败的怪物更弱的怪物。\n· 徒手战斗不会改变已装备武器的攻击限制。\n药水：\n· 每回合只有第一瓶药水生效，恢复等于其点数的生命。\n· 满血时使用第一瓶药水，也会消耗本回合的治疗机会。\n· 同一回合处理的其余药水直接弃置，不恢复生命。\n结束与计分：\n· 生命降至 0 或以下时失败，保留实际生命值。\n· 失败得分为生命减去房间与牌堆中未处理怪物的总点数。\n· 处理全部牌后存活，得分等于剩余生命。\n· 若最终满血且最后处理的是药水，再加上该药水点数。",
			remaining: "还需处理 {{n}} 张",
			resolving: "正在结算",
			entering: "进入房间",
			escaping: "正在逃离",
			deck: "牌堆剩余 {{n}} 张",
			health: "生命 {{n}}，上限 20",
			chooseCard: "选择{{type}} {{card}}",
			monsterType: "怪物",
			weaponType: "武器",
			potionType: "药水",
			bare: "徒手战斗",
			armed: "武器攻击",
			lose: "失去 {{n}} 点生命",
			noLoss: "不失去生命",
			unavailable: "无法攻击此怪物",
			equip: "装备武器",
			replace: "替换当前武器",
			fresh: "攻击限制重置",
			potion: "使用药水",
			heal: "恢复 {{n}} 点生命",
			full: "生命已满",
			discardPotion: "弃置药水",
			potionSpent: "本回合已用过药水",
			escape: "逃离房间",
			cancel: "取消选择",
			attackLimit: "可攻击",
			anyMonster: "任意怪物",
			limit: "{{n}} 及以下",
			none: "无法继续攻击",
			noWeapon: "尚未装备武器",
			empty: "空牌位",
			victory: "走出地牢",
			defeat: "倒在地牢",
			score: "得分",
			finalHealth: "剩余生命",
			unhandled: "未处理怪物",
			bonus: "末张药水奖励",
			confirmAgain: "确定重新开始？",
			confirm: "重新开始",
			cancelRestart: "取消",
			hintEscape: "逃离当前房间，寻找更合适的牌。",
			hintTake: "选择 {{card}}，{{action}}。",
			errorTurn: "请等待当前动作完成。",
			errorEscape: "现在不能逃离这个房间。",
			errorCard: "请选择可用的牌及对应操作。",
			errorWeapon: "当前武器无法攻击这个怪物。"
		},
		en: {
			name: "Scoundrel",
			desc: "Explore a dungeon of playing cards, choosing battles, weapons and potions.",
			rules: "Goal:\n· Resolve all 44 cards while keeping your health above 0.\nSetup:\n· Start with 20 health. The maximum is 20.\n· Spades and clubs from 2 through Ace are monsters.\n· J, Q, K and A have values of 11, 12, 13 and 14.\n· Diamonds 2–10 are weapons; hearts 2–10 are potions.\nRooms:\n· Refill to 4 cards each turn. Resolve 3 in any order.\n· Leave the remaining card in place and refill the empty slots.\n· When the deck runs out, resolve the rest, up to 3 per turn.\n· Before resolving any cards, you may flee a room of 4 cards.\n· Put its cards at the bottom of the deck in slot order, without shuffling.\n· You cannot flee twice in a row. Complete a turn before fleeing again.\nCombat and equipment:\n· Barehanded combat costs health equal to the monster’s value.\n· Resolving a weapon equips it and discards the old weapon and its kills.\n· A weapon attack costs only the monster’s value above the weapon’s value.\n· That weapon may then attack only monsters weaker than its last kill.\n· Barehanded combat does not change your equipped weapon’s limit.\nPotions:\n· Only the first potion each turn heals you, by its value.\n· Using the first potion at full health still spends that turn’s healing.\n· Any further potions resolved that turn are discarded without healing.\nEnding and score:\n· At 0 health or below, you lose. Keep the actual health value.\n· On a loss, subtract all unresolved monster values in the room and deck.\n· If you survive all cards, your score is your remaining health.\n· If you finish at full health with a potion, also add its value.",
			remaining: "Resolve {{n}} more",
			resolving: "Resolving",
			entering: "Entering room",
			escaping: "Fleeing",
			deck: "{{n}} cards in deck",
			health: "{{n}} health, maximum 20",
			chooseCard: "Choose {{type}} {{card}}",
			monsterType: "Monster",
			weaponType: "Weapon",
			potionType: "Potion",
			bare: "Barehanded",
			armed: "Weapon attack",
			lose: "Lose {{n}} health",
			noLoss: "No health lost",
			unavailable: "Cannot attack this monster",
			equip: "Equip weapon",
			replace: "Replace current weapon",
			fresh: "Reset attack limit",
			potion: "Use potion",
			heal: "Restore {{n}} health",
			full: "Health is full",
			discardPotion: "Discard potion",
			potionSpent: "Potion already used this turn",
			escape: "Flee room",
			cancel: "Cancel selection",
			attackLimit: "Can attack",
			anyMonster: "Any monster",
			limit: "{{n}} or below",
			none: "No further attacks",
			noWeapon: "No weapon equipped",
			empty: "Empty card slot",
			victory: "Out of the dungeon",
			defeat: "Lost in the dungeon",
			score: "Score",
			finalHealth: "Health remaining",
			unhandled: "Unresolved monsters",
			bonus: "Final potion bonus",
			confirmAgain: "Start a new game?",
			confirm: "Start again",
			cancelRestart: "Cancel",
			hintEscape: "Flee this room to find a more useful set of cards.",
			hintTake: "Choose {{card}}: {{action}}.",
			errorTurn: "Wait for the current action to finish.",
			errorEscape: "You cannot flee this room now.",
			errorCard: "Choose an available card and its matching action.",
			errorWeapon: "Your weapon cannot attack this monster."
		}
	}
};
//#endregion
export { $ as default };
