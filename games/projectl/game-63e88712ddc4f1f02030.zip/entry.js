import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { cellsOf as t } from "@bgparty/sdk/polyomino";
import { z as n } from "zod";
import { useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as o } from "@bgparty/sdk/fx/delta-number";
import { useT as s } from "@bgparty/sdk/i18n";
import { IconClose as c, IconMirror as l, IconRotate as u, IconShuffle as d } from "@bgparty/sdk/icons";
import { Texture as f } from "@bgparty/sdk/texture";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as h } from "@bgparty/sdk/ui/player-strip";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { botAvatarOf as y } from "@bgparty/sdk/lobby";
import { botPersonality as b } from "@bgparty/sdk/bot-personality";
import { Floater as x, PulseBox as S } from "@bgparty/sdk/fx/primitives";
import { Confetti as C } from "@bgparty/sdk/ui/confetti";
//#region src/games/projectl/meta.ts
var w = {
	id: "projectl",
	tier: "beta",
	mechanics: [
		"tile-placement",
		"engine-building",
		"action-points"
	],
	interactionTags: [],
	nameKey: "games.projectl.name",
	descKey: "games.projectl.desc",
	rulesKey: "games.projectl.rules",
	icon: "🧩",
	iconImg: "games/projectl.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/projectl/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#7c3aed",
	releasedAt: "2026-09-16",
	search: {
		py: "ji hua",
		init: "jh"
	},
	hotseat: "cover"
}, T = [
	"mono",
	"domino",
	"I3",
	"L3",
	"I4",
	"O4",
	"T4",
	"L4",
	"S4"
], E = {
	mono: {
		id: "mono",
		level: 1,
		shape: [[1]],
		color: "#fff200"
	},
	domino: {
		id: "domino",
		level: 2,
		shape: [[1], [1]],
		color: "#00ad4d"
	},
	I3: {
		id: "I3",
		level: 3,
		shape: [
			[1],
			[1],
			[1]
		],
		color: "#007dc4"
	},
	L3: {
		id: "L3",
		level: 3,
		shape: [[1, 0], [1, 1]],
		color: "#f7941c"
	},
	I4: {
		id: "I4",
		level: 4,
		shape: [
			[1],
			[1],
			[1],
			[1]
		],
		color: "#8f4a9c"
	},
	O4: {
		id: "O4",
		level: 4,
		shape: [[1, 1], [1, 1]],
		color: "#ed1459"
	},
	T4: {
		id: "T4",
		level: 4,
		shape: [[
			1,
			1,
			1
		], [
			0,
			1,
			0
		]],
		color: "#ed008c"
	},
	L4: {
		id: "L4",
		level: 4,
		shape: [
			[1, 0],
			[1, 0],
			[1, 1]
		],
		color: "#00abcc"
	},
	S4: {
		id: "S4",
		level: 4,
		shape: [[
			1,
			1,
			0
		], [
			0,
			1,
			1
		]],
		color: "#f27021"
	}
}, D = Object.keys(E);
//#endregion
//#region src/games/projectl/puzzles.ts
function O(e, t, n, r, i) {
	let a = i.split("/"), o = [];
	return a.forEach((e, t) => {
		for (let n = 0; n < e.length; n++) e[n] === "#" && o.push([n, t]);
	}), {
		id: e,
		color: t,
		points: n,
		reward: r,
		cells: o,
		w: Math.max(...a.map((e) => e.length)),
		h: a.length
	};
}
var k = (e, t, n, r) => O(e, "white", t, n, r), A = (e, t, n, r) => O(e, "black", t, n, r), j = [
	k(1, 2, "domino", "#../###/#.."),
	k(2, 2, "L3", "#../###/##./#.."),
	k(3, 2, "I3", "###/##./##."),
	k(4, 2, "S4", "##./###/##./.#."),
	k(5, 2, "I4", "##./###/###/..#"),
	k(6, 2, "L4", ".#./###/###/.#."),
	k(7, 2, "O4", "#./##/##/##/.#"),
	k(8, 2, "T4", "##./##./.##/.##"),
	k(9, 1, "mono", "#/#"),
	k(10, 1, "domino", "#/#/#"),
	k(11, 1, "domino", "##/#."),
	k(12, 1, "domino", "#./##/#."),
	k(13, 1, "L3", "#../##./.##"),
	k(14, 1, "L3", "##/#./##"),
	k(15, 1, "I3", "#/#/#/#/#"),
	k(16, 1, "I3", "##/##/#."),
	k(17, 1, "S4", "#./##/##/#."),
	k(18, 1, "I4", "###/#../##."),
	k(19, 1, "L4", "###/##./#.."),
	k(20, 1, "O4", "###/#../#../#.."),
	k(21, 1, "T4", "##./##./.##"),
	k(22, 0, "domino", "#/#"),
	k(23, 0, "domino", "#/#"),
	k(24, 0, "L3", "##/#."),
	k(25, 0, "L3", "#/#/#"),
	k(26, 0, "I3", "##/#."),
	k(27, 0, "I3", "#/#/#"),
	k(28, 0, "S4", "#./##/.#"),
	k(29, 0, "I4", "#/#/#/#"),
	k(30, 0, "L4", "##/#./#."),
	k(31, 0, "O4", "##/##"),
	k(32, 0, "T4", "#./##/#."),
	A(33, 5, "mono", "..##./####./####./.####/.##.."),
	A(34, 5, "mono", "#..#/####/####/####/.##."),
	A(35, 5, "mono", "###./###./####/###./###."),
	A(36, 5, "mono", "##../####/####/####/..##"),
	A(37, 5, "mono", ".##./####/####/####/.##."),
	A(38, 4, "mono", "###/###/###/##./.#."),
	A(39, 4, "domino", "#.../####/###./###./#..."),
	A(40, 4, "domino", "##../##../###./####/#..."),
	A(41, 4, "L3", "##./###/###/###/##."),
	A(42, 4, "L3", "#..../####./#####/##.../#...."),
	A(43, 4, "I3", "###../#####/#####/#...."),
	A(44, 4, "I3", "####/####/###./##../#..."),
	A(45, 3, "domino", "##/##/##/#./#."),
	A(46, 3, "L3", "##./###/###/#.."),
	A(47, 3, "I3", "###/###/##./#.."),
	A(48, 3, "S4", "####/###./##../#..."),
	A(49, 3, "I4", "##./###/###/##."),
	A(50, 3, "L4", "###/###/##./##."),
	A(51, 3, "O4", "###/###/##./##./.#."),
	A(52, 3, "T4", "###/###/###/##.")
], M = Object.fromEntries(j.map((e) => [e.id, e])), N = {
	2: 12,
	3: 14,
	4: 16
}, P = n.enum(T), F = n.enum(["white", "black"]), I = n.object({
	piece: P,
	x: n.int().min(0).max(4),
	y: n.int().min(0).max(4),
	rot: n.int().min(0).max(3),
	flip: n.boolean()
}), L = I.extend({ puzzle: n.int().min(0).max(3) }), R = n.discriminatedUnion("type", [
	n.object({
		type: n.literal("take"),
		color: F,
		from: n.union([n.literal("deck"), n.int().min(0).max(3)])
	}),
	n.object({
		type: n.literal("recycle"),
		color: F,
		order: n.array(n.int().min(0).max(3)).min(1).max(4)
	}),
	n.object({
		type: n.literal("upgrade"),
		give: P,
		take: P
	}),
	n.object({
		type: n.literal("place"),
		...L.shape
	}),
	n.object({
		type: n.literal("master"),
		placements: n.array(L).min(1).max(4)
	}),
	n.object({ type: n.literal("endTurn") }),
	n.object({
		type: n.literal("ftPlace"),
		...L.shape
	}),
	n.object({ type: n.literal("ftDone") })
]), z = n.string(), B = n.object({
	id: n.int().min(1),
	placed: n.array(I)
}), ee = n.object({
	rid: z,
	supply: n.record(P, n.int().min(0)),
	puzzles: n.array(B).max(4),
	completed: n.array(n.int().min(1)),
	ftPlaced: n.int().min(0)
}), te = n.object({
	rid: z,
	completedPoints: n.number(),
	unfinished: n.number(),
	ft: n.number(),
	completedCount: n.int().min(0),
	leftover: n.int().min(0),
	total: n.number()
}), ne = n.object({
	phase: n.enum([
		"play",
		"finishing",
		"done"
	]),
	whiteRow: n.array(n.int().min(1)),
	blackRow: n.array(n.int().min(1)),
	whiteDeck: n.int().min(0),
	blackDeck: n.int().min(0),
	players: n.array(ee),
	startIdx: n.int().min(0),
	turn: z,
	actionsLeft: n.int().min(0),
	masterUsed: n.boolean(),
	blackTaken: n.int().min(0),
	endTriggered: n.boolean(),
	ftTurn: z.nullable(),
	final: n.array(te).optional()
}), re = n.object({});
//#endregion
//#region src/games/projectl/rules.ts
function V(e) {
	let n = /* @__PURE__ */ new Set();
	for (let r of e.placed) for (let [e, i] of t(E[r.piece].shape, r.rot, r.flip)) n.add(`${r.x + e},${r.y + i}`);
	return n;
}
function H(e, n, r, i, a, o) {
	let s = new Set(M[e.id].cells.map(([e, t]) => `${e},${t}`)), c = V(e);
	for (let [e, l] of t(E[n].shape, a, o)) {
		let t = `${r + e},${i + l}`;
		if (!s.has(t) || c.has(t)) return !1;
	}
	return !0;
}
function U(e) {
	let t = V(e);
	return M[e.id].cells.every(([e, n]) => t.has(`${e},${n}`));
}
function ie(e, t) {
	if (e.reserve[t] > 0) return --e.reserve[t], t;
	let n = E[t].level;
	for (let t of D) if (E[t].level === n && e.reserve[t] > 0) return --e.reserve[t], t;
	for (let t = 1; t <= 3; t += 1) for (let r of [n - t, n + t]) for (let t of D) if (E[t].level === r && e.reserve[t] > 0) return --e.reserve[t], t;
	return null;
}
function W(e, t, n) {
	let r = [], i = [];
	for (let a of t.puzzles) {
		if (!U(a)) {
			i.push(a);
			continue;
		}
		let o = null;
		if (!n) {
			for (let e of a.placed) t.supply[e.piece] += 1;
			o = ie(e, M[a.id].reward), o && (t.supply[o] += 1);
		}
		t.completed.push(a.id), r.push({
			id: a.id,
			points: M[a.id].points,
			reward: o
		});
	}
	return t.puzzles = i, r;
}
function G(e) {
	return e.endTriggered || e.blackDeck.length > 0 ? !1 : (e.endTriggered = !0, e.turnsLeft = 2 * e.players.length, !0);
}
function K(e) {
	if (e.endTriggered && (--e.turnsLeft, e.turnsLeft <= 0)) {
		e.phase = "finishing", e.ftDone = 0;
		return;
	}
	e.turnIdx = (e.turnIdx + 1) % e.players.length, e.actionsLeft = 3, e.masterUsed = !1, e.blackTaken = 0;
}
function q(e) {
	return e.players[(e.startIdx + e.ftDone) % e.players.length].rid;
}
function ae(t, n, r) {
	let i = [...t];
	for (let t = i.length - 1; t > 0; --t) {
		let a = e(n, r.n, t + 1);
		r.n += 1, [i[t], i[a]] = [i[a], i[t]];
	}
	return i;
}
function oe(t, n, r) {
	let i = { n: 0 }, a = ae(Array.from({ length: 32 }, (e, t) => t + 1), r, i), o = ae(Array.from({ length: 20 }, (e, t) => t + 33), r, i).slice(0, N[n.length] ?? 16), s = e(r, i.n, n.length), c = Object.fromEntries(D.map((e) => [e, 15]));
	return c.mono -= n.length, c.domino -= n.length, { state: {
		players: n.map((e) => ({
			rid: e,
			supply: {
				...Object.fromEntries(D.map((e) => [e, 0])),
				mono: 1,
				domino: 1
			},
			puzzles: [],
			completed: [],
			ftPlaced: 0
		})),
		whiteRow: a.splice(0, 4),
		blackRow: o.splice(0, 4),
		whiteDeck: a,
		blackDeck: o,
		reserve: c,
		startIdx: s,
		turnIdx: s,
		actionsLeft: 3,
		masterUsed: !1,
		blackTaken: 0,
		endTriggered: !1,
		turnsLeft: 0,
		ftDone: -1,
		phase: "play"
	} };
}
function J(e, t, n) {
	let r = e.puzzles[t.puzzle];
	return --e.supply[t.piece], r.placed.push({
		piece: t.piece,
		x: t.x,
		y: t.y,
		rot: t.rot,
		flip: t.flip
	}), {
		kind: "place",
		rid: e.rid,
		data: {
			...t,
			ft: n
		}
	};
}
function se(e, t, n) {
	return W(e, t, n).map((e) => ({
		kind: "complete",
		rid: t.rid,
		data: {
			id: e.id,
			points: e.points,
			reward: e.reward,
			ft: n
		}
	}));
}
function Y(e) {
	--e.actionsLeft, e.actionsLeft <= 0 && K(e);
}
function ce(e, t, n) {
	if (n.by !== q(e)) return { code: "games.projectl.errNotYourTurn" };
	if (t.type === "ftDone") {
		let t = structuredClone(e);
		return t.ftDone += 1, t.ftDone >= t.players.length && (t.phase = "done"), {
			state: t,
			fx: []
		};
	}
	if (t.type !== "ftPlace") return { code: "games.projectl.errNotYourTurn" };
	let r = e.players.findIndex((e) => e.rid === n.by), i = e.players[r].puzzles[t.puzzle];
	if (!i) return { code: "games.projectl.errBadPuzzle" };
	if (e.players[r].supply[t.piece] <= 0) return { code: "games.projectl.errNoPiece" };
	if (!H(i, t.piece, t.x, t.y, t.rot, t.flip)) return { code: "games.projectl.errBadPlacement" };
	let a = structuredClone(e), o = a.players[r];
	return o.ftPlaced += 1, {
		state: a,
		fx: [J(o, t, !0), ...se(a, o, !0)]
	};
}
function le(e, t, n) {
	if (e.phase === "finishing") return ce(e, t, n);
	if (e.phase !== "play") return { code: "games.projectl.errNotYourTurn" };
	let r = e.players.findIndex((e) => e.rid === n.by);
	if (r !== e.turnIdx) return { code: "games.projectl.errNotYourTurn" };
	let i = e.players[r];
	if (t.type === "endTurn") {
		let t = structuredClone(e);
		return K(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "ftPlace" || t.type === "ftDone") return { code: "games.projectl.errNotYourTurn" };
	if (t.type === "take") {
		if (i.puzzles.length >= 4) return { code: "games.projectl.errPuzzlesFull" };
		let a = t.color === "white" ? e.whiteRow : e.blackRow, o = t.color === "white" ? e.whiteDeck : e.blackDeck;
		if (t.color === "black" && e.endTriggered && e.blackTaken >= 1) return { code: "games.projectl.errBlackLimit" };
		if (t.from === "deck") {
			if (o.length === 0) return { code: "games.projectl.errDeckEmpty" };
		} else if (t.from >= a.length) return { code: "games.projectl.errBadRow" };
		let s = structuredClone(e), c = s.players[r], l = t.color === "white" ? s.whiteDeck : s.blackDeck, u = t.color === "white" ? s.whiteRow : s.blackRow, d;
		t.from === "deck" ? d = l.shift() : (d = u.splice(t.from, 1)[0], l.length > 0 && !(t.color === "black" && s.endTriggered) && u.push(l.shift())), c.puzzles.push({
			id: d,
			placed: []
		}), t.color === "black" && s.endTriggered && (s.blackTaken += 1);
		let f = [{
			kind: "take",
			rid: n.by,
			data: {
				color: t.color,
				id: d
			}
		}];
		return G(s) && f.push({
			kind: "endTrigger",
			with: !0
		}), Y(s), {
			state: s,
			fx: f
		};
	}
	if (t.type === "recycle") {
		let r = t.color === "white" ? e.whiteRow : e.blackRow;
		if ((t.color === "white" ? e.whiteDeck : e.blackDeck).length === 0) return { code: "games.projectl.errDeckEmpty" };
		if (r.length === 0) return { code: "games.projectl.errBadRow" };
		let i = [...t.order].sort((e, t) => e - t);
		if (t.order.length !== r.length || i.some((e, t) => e !== t)) return { code: "games.projectl.errBadOrder" };
		let a = structuredClone(e), o = t.color === "white" ? a.whiteDeck : a.blackDeck, s = t.color === "white" ? a.whiteRow : a.blackRow;
		return o.push(...t.order.map((e) => s[e])), s.length = 0, s.push(...o.splice(0, 4)), Y(a), {
			state: a,
			fx: [{
				kind: "recycle",
				rid: n.by,
				data: { color: t.color }
			}]
		};
	}
	if (t.type === "upgrade") {
		if (i.supply[t.give] <= 0) return { code: "games.projectl.errNoPiece" };
		if (E[t.take].level > E[t.give].level + 1) return { code: "games.projectl.errBadUpgrade" };
		let a = structuredClone(e), o = a.players[r], s = null;
		if (a.reserve[t.take] > 0) --a.reserve[t.take], s = t.take;
		else for (let e of D) if (E[e].level === E[t.take].level && a.reserve[e] > 0) {
			--a.reserve[e], s = e;
			break;
		}
		return s ? (--o.supply[t.give], a.reserve[t.give] += 1, o.supply[s] += 1, Y(a), {
			state: a,
			fx: [{
				kind: "upgrade",
				rid: n.by,
				data: {
					give: t.give,
					take: s
				}
			}]
		}) : { code: "games.projectl.errReserveEmpty" };
	}
	if (t.type === "place") {
		let n = i.puzzles[t.puzzle];
		if (!n) return { code: "games.projectl.errBadPuzzle" };
		if (i.supply[t.piece] <= 0) return { code: "games.projectl.errNoPiece" };
		if (!H(n, t.piece, t.x, t.y, t.rot, t.flip)) return { code: "games.projectl.errBadPlacement" };
		let a = structuredClone(e), o = a.players[r], s = [J(o, t, !1), ...se(a, o, !1)];
		return Y(a), {
			state: a,
			fx: s
		};
	}
	if (e.masterUsed) return { code: "games.projectl.errMasterUsed" };
	let a = /* @__PURE__ */ new Set(), o = {};
	for (let e of t.placements) {
		if (a.has(e.puzzle)) return { code: "games.projectl.errMasterMulti" };
		if (a.add(e.puzzle), !i.puzzles[e.puzzle]) return { code: "games.projectl.errBadPuzzle" };
		if (o[e.piece] = (o[e.piece] ?? 0) + 1, o[e.piece] > i.supply[e.piece]) return { code: "games.projectl.errNoPiece" };
	}
	let s = structuredClone(e), c = s.players[r], l = [{
		kind: "master",
		rid: n.by
	}];
	for (let e of t.placements) {
		if (!H(c.puzzles[e.puzzle], e.piece, e.x, e.y, e.rot, e.flip)) return { code: "games.projectl.errBadPlacement" };
		l.push({
			...J(c, e, !1),
			with: !0
		});
	}
	return l.push(...se(s, c, !1).map((e) => ({
		...e,
		with: !0
	}))), s.masterUsed = !0, Y(s), {
		state: s,
		fx: l
	};
}
function ue(e) {
	let t = e.completed.reduce((e, t) => e + M[t].points, 0), n = e.puzzles.reduce((e, t) => e + M[t.id].points, 0), r = D.reduce((t, n) => t + e.supply[n], 0);
	return {
		rid: e.rid,
		completedPoints: t,
		unfinished: n,
		ft: e.ftPlaced,
		completedCount: e.completed.length,
		leftover: r,
		total: t - n - e.ftPlaced
	};
}
function de(e) {
	let t = {
		phase: e.phase,
		whiteRow: [...e.whiteRow],
		blackRow: [...e.blackRow],
		whiteDeck: e.whiteDeck.length,
		blackDeck: e.blackDeck.length,
		players: e.players.map((e) => ({
			rid: e.rid,
			supply: { ...e.supply },
			puzzles: e.puzzles,
			completed: [...e.completed],
			ftPlaced: e.ftPlaced
		})),
		startIdx: e.startIdx,
		turn: e.players[e.turnIdx].rid,
		actionsLeft: e.actionsLeft,
		masterUsed: e.masterUsed,
		blackTaken: e.blackTaken,
		endTriggered: e.endTriggered,
		ftTurn: e.phase === "finishing" ? q(e) : null
	};
	return e.phase === "done" && (t.final = e.players.map((e) => ue(e))), {
		public: t,
		private: {}
	};
}
function fe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.map((e) => ue(e)), n = new Map(e.players.map((e, t) => [e.rid, t])), r = (e, t) => t.total - e.total || t.completedCount - e.completedCount || t.leftover - e.leftover || n.get(e.rid) - n.get(t.rid), i = [...t].sort(r).map((e) => e.rid), a = i.filter((e) => {
		let n = t.find((t) => t.rid === e), r = t.find((e) => e.rid === i[0]);
		return n.total === r.total && n.completedCount === r.completedCount && n.leftover === r.leftover;
	}), o = {};
	for (let e of t) o[e.rid] = e.total;
	return {
		phase: "done",
		winner: a,
		ranking: i,
		scores: o
	};
}
var pe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: w,
	schemas: {
		action: R,
		publicView: ne,
		privateView: re
	},
	setup: oe,
	reduce: le,
	viewFor: de,
	status: fe
};
//#endregion
//#region src/games/projectl/piece-view.tsx
function X(e, n, r) {
	let i = t(E[e].shape, n, r);
	return {
		cells: i,
		w: Math.max(...i.map((e) => e[0])) + 1,
		h: Math.max(...i.map((e) => e[1])) + 1
	};
}
function me({ piece: e, rot: t = 0, flip: n = !1, cell: r = 100, ghost: i = !1 }) {
	let { cells: a } = X(e, t, n), o = new Set(a.map(([e, t]) => `${e},${t}`)), s = a.flatMap(([e, t]) => {
		let n = e * r, i = t * r, a = r;
		return [
			o.has(`${e},${t - 1}`) ? "" : `M${n} ${i}h${a}`,
			o.has(`${e + 1},${t}`) ? "" : `M${n + a} ${i}v${a}`,
			o.has(`${e},${t + 1}`) ? "" : `M${n} ${i + a}h${a}`,
			o.has(`${e - 1},${t}`) ? "" : `M${n} ${i}v${a}`
		];
	}).join(" ");
	return /* @__PURE__ */ v("g", {
		opacity: i ? .68 : 1,
		children: [a.map(([t, n], a) => /* @__PURE__ */ v("g", { children: [
			!i && /* @__PURE__ */ _("rect", {
				x: t * r,
				y: n * r + r * .08,
				width: r,
				height: r * .92,
				fill: "var(--color-ink)",
				opacity: .65
			}),
			/* @__PURE__ */ _("rect", {
				x: t * r,
				y: n * r,
				width: r,
				height: r,
				fill: E[e].color
			}),
			/* @__PURE__ */ _("rect", {
				x: t * r + r * .16,
				y: n * r + r * .15,
				width: r * .65,
				height: r * .12,
				rx: r * .06,
				fill: "var(--color-surface)",
				opacity: .34
			})
		] }, a)), /* @__PURE__ */ _("path", {
			d: s,
			fill: "none",
			stroke: "var(--color-ink)",
			strokeWidth: r * .065,
			strokeLinecap: "round",
			strokeLinejoin: "round",
			strokeDasharray: i ? r * .16 : void 0
		})]
	});
}
function Z({ piece: e, size: t = 20 }) {
	let { w: n, h: r } = X(e, 0, !1), i = Math.max(n, r);
	return /* @__PURE__ */ _("svg", {
		viewBox: `0 0 ${n * 100} ${r * 100}`,
		style: {
			width: t * n / i,
			height: t * r / i
		},
		className: "overflow-visible",
		"aria-hidden": !0,
		children: /* @__PURE__ */ _(me, { piece: e })
	});
}
function he({ id: e, placed: t = [], ghost: n = null, dark: r = !1, cell: i = 100 }) {
	let a = M[e], o = r ? "var(--color-pl-black-hole)" : "var(--color-pl-white-hole)", s = r ? "var(--color-pl-black-edge)" : "var(--color-pl-white-edge)";
	return /* @__PURE__ */ v("svg", {
		viewBox: `0 0 ${a.w * i} ${a.h * i}`,
		preserveAspectRatio: "xMidYMid meet",
		className: "pl-puzzle-svg",
		"aria-hidden": !0,
		children: [
			a.cells.map(([e, t]) => /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("rect", {
				x: e * i + i * .04,
				y: t * i + i * .04,
				width: i * .92,
				height: i * .92,
				rx: i * .12,
				fill: o,
				stroke: s,
				strokeWidth: i * .035
			}), /* @__PURE__ */ _("path", {
				d: `M${e * i + i * .17} ${t * i + i * .17}h${i * .66}`,
				fill: "none",
				stroke: r ? "var(--color-pl-black-edge)" : "var(--color-surface)",
				strokeWidth: i * .035,
				opacity: .65
			})] }, `${e},${t}`)),
			t.map((e, t) => /* @__PURE__ */ _("g", {
				transform: `translate(${e.x * i}, ${e.y * i})`,
				children: /* @__PURE__ */ _(me, {
					piece: e.piece,
					rot: e.rot,
					flip: e.flip,
					cell: i
				})
			}, t)),
			n && /* @__PURE__ */ _("g", {
				transform: `translate(${n.x * i}, ${n.y * i})`,
				opacity: n.valid ? 1 : .38,
				children: /* @__PURE__ */ _(me, {
					piece: n.piece,
					rot: n.rot,
					flip: n.flip,
					cell: i,
					ghost: !0
				})
			})
		]
	});
}
function ge({ id: e }) {
	let t = M[e];
	return /* @__PURE__ */ v("span", {
		className: `pl-mini-card ${t.color === "black" ? "is-black" : ""}`,
		title: `#${e}`,
		children: [/* @__PURE__ */ _("svg", {
			viewBox: `0 0 ${t.w * 8} ${t.h * 8}`,
			style: {
				width: `calc(${t.w} * var(--pl-mini-cell, 8px))`,
				height: `calc(${t.h} * var(--pl-mini-cell, 8px))`
			},
			"aria-hidden": !0,
			children: t.cells.map(([e, n]) => /* @__PURE__ */ _("rect", {
				x: e * 8 + .5,
				y: n * 8 + .5,
				width: 7,
				height: 7,
				rx: 1.5,
				fill: t.color === "black" ? "var(--color-pl-black-hole)" : "var(--color-pl-white-hole)",
				stroke: t.color === "black" ? "var(--color-pl-black-edge)" : "var(--color-pl-white-edge)",
				strokeWidth: .5
			}, `${e},${n}`))
		}), t.points > 0 && /* @__PURE__ */ _("span", {
			className: "pl-mini-points absolute -right-1.5 -bottom-1.5 rounded-md border border-ink bg-warn-soft px-0.5 font-mono text-[9px] leading-3 font-bold tabular-nums",
			children: t.points
		})]
	});
}
//#endregion
//#region src/games/projectl/view-player.tsx
var _e = {
	mono: "games.projectl.pieceMono",
	domino: "games.projectl.pieceDomino",
	I3: "games.projectl.pieceI3",
	L3: "games.projectl.pieceL3",
	I4: "games.projectl.pieceI4",
	O4: "games.projectl.pieceO4",
	T4: "games.projectl.pieceT4",
	L4: "games.projectl.pieceL4",
	S4: "games.projectl.pieceS4"
};
function ve(e) {
	let t = e.public;
	return /* @__PURE__ */ _(be, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ye(e, t) {
	let n = M[e.id];
	for (let r of [!1, !0]) for (let i = 0; i < 4; i++) for (let a = 0; a <= n.h; a++) for (let o = 0; o <= n.w; o++) if (H(e, t, o, a, i, r)) return {
		x: o,
		y: a,
		rot: i,
		flip: r
	};
	return null;
}
function be({ pub: e, members: t, myRid: n, send: r }) {
	let l = s(), u = e.players.find((e) => e.rid === n), [d, y] = i(n), [b, x] = i("idle"), [S, C] = i(null), [T, O] = i(null), [k, A] = i([]), [j, N] = i(null), [P, F] = i(null), [I, L] = i(null), R = e.phase === "play" && e.turn === n, z = e.phase === "finishing" && e.ftTurn === n, B = !!u && (R || z) && d === n, ee = u ? D.reduce((e, t) => e + (u.supply[t] ?? 0), 0) : 0, [te, ne] = i(""), re = `${e.phase}|${e.turn}|${e.ftTurn ?? ""}|${e.actionsLeft}|${d}|${ee}|${u?.puzzles.length ?? 0}`;
	te !== re && (ne(re), x("idle"), C(null), O(null), A([]), N(null), F(null), L(null));
	let V = (e) => t.find((t) => t.rid === e)?.name ?? e, U = e.players.find((e) => e.rid === d) ?? u, { ref: ie } = a(U ? `completed:${U.rid}` : null), W = "info", G;
	e.phase === "finishing" ? z ? (W = "accent", G = l("games.projectl.stageFt")) : G = l("games.projectl.waitFt", { name: V(e.ftTurn ?? "") }) : R ? (W = "accent", G = l("games.projectl.stageYourTurn", { n: e.actionsLeft })) : G = l("games.projectl.waitTurn", { name: V(e.turn) });
	let K = R && B && (u?.puzzles.length ?? 4) < 4, q = K && !(e.endTriggered && e.blackTaken >= 1), ae = R && B && !e.masterUsed && (u?.puzzles.length ?? 0) > 0 && ee > 0, oe = (e, t) => {
		I === e ? (t(), L(null)) : L(e);
	}, J = (e) => {
		if (!B || !u) return;
		if (b === "master" && !S) {
			k.some((t) => t.puzzle === e) && A(k.filter((t) => t.puzzle !== e));
			return;
		}
		if (!S || b === "upgrade") return;
		let t = u.puzzles[e];
		if (!t) return;
		let n = ye(t, S);
		n && O({
			piece: S,
			puzzle: e,
			...n
		});
	};
	return /* @__PURE__ */ v(p, {
		adaptive: !0,
		className: "pl-screen",
		banner: /* @__PURE__ */ v("div", {
			className: "pl-banner",
			children: [/* @__PURE__ */ _(m, {
				tone: W,
				text: G,
				chip: e.endTriggered ? l("games.projectl.endChip") : void 0,
				accent: w.accent
			}), /* @__PURE__ */ _("div", {
				className: "pl-players",
				children: /* @__PURE__ */ _(h, {
					members: t.filter((t) => e.players.some((e) => e.rid === t.rid)),
					myRid: n,
					variant: "plate",
					anchorOf: (e) => `seat:${e}`,
					action: (t) => t === (e.phase === "finishing" ? e.ftTurn : e.turn) ? "pending" : null,
					onPick: (e) => y(e),
					picked: (e) => d === e,
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						if (!n) return null;
						let r = n.completed.reduce((e, t) => e + (M[t]?.points ?? 0), 0), i = D.reduce((e, t) => e + (n.supply[t] ?? 0), 0);
						return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("span", {
							"aria-label": l("games.projectl.scoreShort", { n: r }),
							className: "flex items-center gap-0.5 rounded-md border border-ink bg-warn-soft px-1 text-[10px] leading-3.5 font-bold",
							children: [/* @__PURE__ */ _("span", {
								"aria-hidden": !0,
								children: "⭐"
							}), /* @__PURE__ */ _(o, {
								value: r,
								className: "font-mono tabular-nums"
							})]
						}), /* @__PURE__ */ v("span", {
							"aria-label": l("games.projectl.statLeftover", { n: i }),
							className: "flex items-center gap-0.5 rounded-md border border-ink bg-surface px-1 text-[10px] leading-3.5 font-bold",
							children: [/* @__PURE__ */ _("span", {
								"aria-hidden": !0,
								children: "🧱"
							}), /* @__PURE__ */ _(o, {
								value: i,
								className: "font-mono tabular-nums"
							})]
						})] });
					}
				})
			})]
		}),
		actions: /* @__PURE__ */ _(g, { children: /* @__PURE__ */ v("div", {
			className: "pl-footer",
			children: [/* @__PURE__ */ _("div", {
				className: "pl-tray",
				role: "group",
				"aria-label": l("games.projectl.supplyLabel"),
				children: D.map((e) => {
					let t = u?.supply[e] ?? 0, n = t - k.filter((t) => t.piece === e).length, r = j === e, i = P === e, a = !B || (b === "upgrade" ? j === null ? t === 0 : e === j || E[e].level > E[j].level + 1 : n <= 0), o = b === "upgrade" ? r || i : S === e;
					return /* @__PURE__ */ v("button", {
						type: "button",
						"aria-label": l("games.projectl.pieceCountAria", {
							name: l(_e[e]),
							n: t
						}),
						"aria-pressed": o,
						disabled: a,
						onClick: () => {
							b === "upgrade" ? j === null || e === j ? N(j === e ? null : e) : F(i ? null : e) : C(S === e ? null : e);
						},
						className: `pl-piece ${b === "upgrade" ? r ? "is-upgrade-give" : i ? "is-upgrade-take" : "" : o ? "is-selected" : ""}`,
						children: [/* @__PURE__ */ _(Z, {
							piece: e,
							size: 25
						}), /* @__PURE__ */ _("span", {
							className: "pl-piece-count",
							children: b === "master" ? n : t
						})]
					}, e);
				})
			}), /* @__PURE__ */ _("div", {
				className: "pl-controls",
				children: R && B ? b === "upgrade" ? /* @__PURE__ */ v(g, { children: [
					/* @__PURE__ */ _("p", {
						className: "flex min-w-0 flex-1 items-center text-[11px] leading-4 font-bold opacity-70",
						children: l("games.projectl.upgradeHint")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						"aria-label": l("games.projectl.cancel"),
						onClick: () => {
							x("idle"), N(null), F(null);
						},
						className: "btn-quiet grid size-12 flex-none place-items-center",
						children: /* @__PURE__ */ _(c, {
							size: 20,
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: !j || !P,
						onClick: () => {
							r({
								type: "upgrade",
								give: j,
								take: P
							}), x("idle");
						},
						className: "btn-base min-h-12 flex-none px-4 text-sm text-white",
						style: { background: w.accent },
						children: l("games.projectl.upgradeConfirm")
					})
				] }) : b === "master" ? /* @__PURE__ */ v(g, { children: [
					/* @__PURE__ */ _("p", {
						className: "flex min-w-0 flex-1 items-center text-[11px] leading-4 font-bold opacity-70",
						children: l("games.projectl.masterHint")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						"aria-label": l("games.projectl.cancel"),
						onClick: () => {
							x("idle"), A([]);
						},
						className: "btn-quiet grid size-12 flex-none place-items-center",
						children: /* @__PURE__ */ _(c, {
							size: 20,
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: k.length === 0,
						onClick: () => {
							r({
								type: "master",
								placements: k
							}), x("idle"), A([]);
						},
						className: "btn-base min-h-12 flex-none px-3 text-sm text-white",
						style: { background: w.accent },
						children: l("games.projectl.masterConfirm", { n: k.length })
					})
				] }) : /* @__PURE__ */ v(g, { children: [
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: ee === 0,
						onClick: () => {
							x("upgrade"), C(null);
						},
						className: "btn-quiet min-h-12 flex-none px-3 text-sm font-bold",
						children: l("games.projectl.upgrade")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						disabled: !ae,
						onClick: () => x("master"),
						className: "btn-quiet min-h-12 flex-none px-3 text-sm font-bold",
						children: l("games.projectl.master")
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => r({ type: "endTurn" }),
						className: "btn-base min-h-12 flex-1 text-sm text-white",
						style: { background: w.accent },
						children: l("games.projectl.endTurn")
					})
				] }) : z && B ? /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => r({ type: "ftDone" }),
					className: "btn-base min-h-12 flex-1 text-sm text-white",
					style: { background: w.accent },
					children: l("games.projectl.ftDone")
				}) : /* @__PURE__ */ _("div", {
					className: "min-h-12 flex-1",
					"aria-hidden": !0
				})
			})]
		}) }),
		actionsHeight: "pl-actions-height",
		scroll: !1,
		children: [/* @__PURE__ */ v("div", {
			className: "pl-table",
			children: [
				/* @__PURE__ */ _(f, {
					kind: "sheen",
					base: "var(--color-pl-mat)",
					className: "absolute inset-0"
				}),
				/* @__PURE__ */ v("div", {
					className: "pl-market",
					children: [/* @__PURE__ */ _(xe, {
						dark: !1,
						row: e.whiteRow,
						deck: e.whiteDeck,
						canTake: K,
						canBlind: K && e.whiteDeck > 0,
						canRecycle: R && B && e.whiteDeck > 0 && e.whiteRow.length > 0,
						armed: I,
						onTap: (e, t) => oe(e, t),
						send: r
					}), /* @__PURE__ */ _(xe, {
						dark: !0,
						row: e.blackRow,
						deck: e.blackDeck,
						canTake: q,
						canBlind: q && e.blackDeck > 0,
						canRecycle: R && B && e.blackDeck > 0 && e.blackRow.length > 0,
						armed: I,
						onTap: (e, t) => oe(e, t),
						send: r
					})]
				}),
				/* @__PURE__ */ v("div", {
					className: "pl-workbench",
					children: [/* @__PURE__ */ v("div", {
						className: "pl-workbench-head",
						children: [
							/* @__PURE__ */ _("strong", { children: d === n ? l("games.projectl.myPuzzles", { n: U?.puzzles.length ?? 0 }) : l("games.projectl.playerPuzzles", {
								name: V(d),
								n: U?.puzzles.length ?? 0
							}) }),
							/* @__PURE__ */ v("span", {
								ref: ie,
								className: "pl-completed-pile",
								"aria-label": l("games.projectl.completedShort", { n: U?.completed.length ?? 0 }),
								children: ["✓ ", U?.completed.length ?? 0]
							}),
							/* @__PURE__ */ _("span", {
								className: S && B ? "is-active" : "",
								children: b === "upgrade" ? l("games.projectl.upgradeHint") : b === "master" ? l("games.projectl.masterHint") : S && B ? l("games.projectl.tapFitting") : U?.puzzles.length ? "" : l("games.projectl.emptyPuzzles")
							})
						]
					}), /* @__PURE__ */ _("div", {
						className: "pl-slots",
						children: U && [
							0,
							1,
							2,
							3
						].map((e) => {
							let t = U.puzzles[e], n = k.find((t) => t.puzzle === e), r = !!(B && S && t && b !== "upgrade" && ye(t, S));
							return /* @__PURE__ */ _(Ce, {
								anchor: U ? `puzzle:${U.rid}:${e}` : null,
								cardAnchor: U && t ? `card:${U.rid}:${t.id}` : null,
								index: e,
								puzzle: t ?? null,
								queued: n ?? null,
								highlight: r,
								preview: r && S && t ? {
									piece: S,
									puzzle: e,
									...ye(t, S)
								} : null,
								selected: !!(B && S),
								actionable: !!(r || b === "master" && n && !S),
								onTap: () => J(e)
							}, e);
						})
					})]
				})
			]
		}), T && u && d === n && u.puzzles[T.puzzle] && /* @__PURE__ */ _(we, {
			puzzle: u.puzzles[T.puzzle],
			pl: T,
			onChange: O,
			onConfirm: () => {
				T && u && H(u.puzzles[T.puzzle], T.piece, T.x, T.y, T.rot, T.flip) && (e.phase === "finishing" ? r({
					type: "ftPlace",
					...T
				}) : b === "master" ? A([...k.filter((e) => e.puzzle !== T.puzzle), T]) : r({
					type: "place",
					...T
				}), O(null));
			},
			onCancel: () => O(null)
		})]
	});
}
function xe({ dark: e, row: t, deck: n, canTake: r, canBlind: i, canRecycle: o, armed: c, onTap: l, send: u }) {
	let f = s(), p = e ? "black" : "white", { ref: m } = a(`market:${p}`);
	return /* @__PURE__ */ v("div", {
		ref: m,
		role: "group",
		"aria-label": f(e ? "games.projectl.rowBlack" : "games.projectl.rowWhite"),
		className: "pl-market-row",
		children: [/* @__PURE__ */ v("div", {
			className: "pl-market-head",
			children: [
				/* @__PURE__ */ v("span", {
					className: "pl-market-title",
					children: [/* @__PURE__ */ _("strong", { children: f(e ? "games.projectl.rowBlack" : "games.projectl.rowWhite") }), /* @__PURE__ */ _("small", { children: f("games.projectl.deckRemaining", { n }) })]
				}),
				/* @__PURE__ */ v("button", {
					type: "button",
					"aria-label": f("games.projectl.deckAria", { n }),
					disabled: !i,
					onClick: () => l(`deck:${p}`, () => u({
						type: "take",
						color: p,
						from: "deck"
					})),
					className: `pl-market-deck ${e ? "is-black" : "is-white"}`,
					children: [
						/* @__PURE__ */ _("span", {
							className: "pl-market-deck-label",
							children: f("games.projectl.blindShort")
						}),
						/* @__PURE__ */ _("svg", {
							viewBox: "0 0 32 32",
							"aria-hidden": !0,
							children: /* @__PURE__ */ _("path", {
								d: "M7 4v24h23v-7H15V4Z",
								fill: e ? "var(--color-pl-cyan)" : "var(--color-pl-mat)"
							})
						}),
						/* @__PURE__ */ _("em", { children: n }),
						c === `deck:${p}` && /* @__PURE__ */ _(Se, { text: f("games.projectl.takeArm") })
					]
				}),
				/* @__PURE__ */ v("button", {
					type: "button",
					"aria-label": f("games.projectl.recycleAria"),
					disabled: !o,
					onClick: () => l(`recycle:${p}`, () => u({
						type: "recycle",
						color: p,
						order: t.map((e, t) => t)
					})),
					className: "pl-market-recycle",
					children: [
						/* @__PURE__ */ _("span", {
							className: "pl-market-recycle-label",
							children: f("games.projectl.recycleShort")
						}),
						/* @__PURE__ */ _(d, {
							size: 20,
							"aria-hidden": !0
						}),
						c === `recycle:${p}` && /* @__PURE__ */ _(Se, { text: f("games.projectl.recycleShort") })
					]
				})
			]
		}), /* @__PURE__ */ _("div", {
			className: "pl-market-cards",
			children: [
				0,
				1,
				2,
				3
			].map((n) => {
				let i = t[n];
				if (i === void 0) return /* @__PURE__ */ _("div", {
					className: "pl-market-empty",
					"aria-hidden": !0,
					children: f("games.projectl.emptyMarket")
				}, n);
				let a = M[i], o = `take:${p}:${n}`;
				return /* @__PURE__ */ v("button", {
					type: "button",
					"aria-label": `${f("games.projectl.pointsAria", { n: a.points })};${f("games.projectl.rewardAria", { name: f(_e[a.reward]) })}`,
					disabled: !r,
					onClick: () => l(o, () => u({
						type: "take",
						color: p,
						from: n
					})),
					className: `pl-market-card ${e ? "is-black" : ""} ${c === o ? "is-armed" : ""}`,
					children: [
						c === o && /* @__PURE__ */ _(Se, { text: f("games.projectl.takeArm") }),
						/* @__PURE__ */ v("span", {
							className: "pl-market-card-top",
							children: [/* @__PURE__ */ _("span", {
								className: "pl-market-points",
								children: a.points > 0 ? a.points : "·"
							}), /* @__PURE__ */ _(Z, {
								piece: a.reward,
								size: 16
							})]
						}),
						/* @__PURE__ */ _("span", {
							className: "pl-market-art",
							children: /* @__PURE__ */ _(he, {
								id: i,
								dark: e
							})
						})
					]
				}, `${i}:${n}`);
			})
		})]
	});
}
function Se({ text: e }) {
	return /* @__PURE__ */ _("span", {
		className: "pl-market-armed",
		children: e
	});
}
function Ce({ anchor: e, cardAnchor: t, index: n, puzzle: r, queued: i, highlight: o, preview: c, selected: l, actionable: u, onTap: d }) {
	let f = s(), { ref: p } = a(e), { ref: m } = a(t);
	if (!r) return /* @__PURE__ */ _("div", {
		ref: p,
		className: "pl-slot",
		children: /* @__PURE__ */ v("div", {
			className: "pl-slot-empty",
			children: [/* @__PURE__ */ v("span", {
				className: "pl-slot-number",
				children: ["0", n + 1]
			}), /* @__PURE__ */ v("span", {
				className: "pl-slot-empty-inner",
				children: [/* @__PURE__ */ _("svg", {
					viewBox: "0 0 32 32",
					"aria-hidden": !0,
					children: /* @__PURE__ */ _("path", {
						d: "M7 4v24h23v-7H15V4Z",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "3"
					})
				}), /* @__PURE__ */ _("span", { children: f("games.projectl.slotEmpty") })]
			})]
		})
	});
	let h = M[r.id], g = h.color === "black", y = r.placed.reduce((e, t) => e + X(t.piece, t.rot, t.flip).cells.length, 0), b = i ? f("games.projectl.queued") : o ? f("games.projectl.canPlace") : l ? f("games.projectl.cannotFit") : f("games.projectl.filledCount", {
		n: y,
		total: h.cells.length
	});
	return /* @__PURE__ */ _("div", {
		ref: p,
		className: "pl-slot",
		children: /* @__PURE__ */ v("button", {
			ref: m,
			type: "button",
			disabled: !u,
			onClick: d,
			"aria-label": `${f("games.projectl.pointsAria", { n: h.points })}; ${f("games.projectl.rewardAria", { name: f(_e[h.reward]) })}; ${b}`,
			className: `pl-slot-card ${g ? "is-black" : ""} ${o ? "is-fit" : ""} ${l && !o ? "is-dim" : ""}`,
			children: [
				/* @__PURE__ */ v("span", {
					className: "pl-slot-card-head",
					children: [/* @__PURE__ */ _("b", { children: h.points > 0 ? f("games.projectl.pointsShort", { n: h.points }) : f("games.projectl.rewardOnly") }), /* @__PURE__ */ _(Z, {
						piece: h.reward,
						size: 20
					})]
				}),
				/* @__PURE__ */ _("span", {
					className: "pl-slot-art",
					children: /* @__PURE__ */ _(he, {
						id: r.id,
						placed: r.placed,
						dark: g,
						ghost: i ? {
							...i,
							valid: !0
						} : c ? {
							...c,
							valid: !0
						} : null
					})
				}),
				/* @__PURE__ */ _("span", {
					className: "pl-slot-status",
					children: b
				})
			]
		})
	});
}
function we({ puzzle: e, pl: t, onChange: n, onConfirm: i, onCancel: a }) {
	let o = s(), c = M[e.id], d = Math.min(52, Math.floor(240 / Math.max(c.w, c.h))), { w: f, h: p } = X(t.piece, t.rot, t.flip), m = H(e, t.piece, t.x, t.y, t.rot, t.flip), h = r(null), g = r(!1), y = (e, t, n) => Math.max(t, Math.min(n, e)), b = (e) => {
		let t = h.current;
		if (!t) return null;
		let n = t.getScreenCTM();
		if (!n) return null;
		let r = t.createSVGPoint();
		r.x = e.clientX, r.y = e.clientY;
		let i = r.matrixTransform(n.inverse());
		return [Math.floor(i.x / d), Math.floor(i.y / d)];
	}, x = (e, r) => {
		n({
			...t,
			x: y(e - Math.floor(f / 2), 1 - f, c.w - 1),
			y: y(r - Math.floor(p / 2), 1 - p, c.h - 1)
		});
	};
	return /* @__PURE__ */ _("div", {
		className: "pl-place-backdrop",
		onClick: a,
		children: /* @__PURE__ */ v("div", {
			className: "pl-place-panel",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": o("games.projectl.placeConfirm"),
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ v("div", {
					className: "pl-place-title",
					children: [
						/* @__PURE__ */ _(Z, {
							piece: t.piece,
							size: 24
						}),
						/* @__PURE__ */ _("strong", { children: o(_e[t.piece]) }),
						/* @__PURE__ */ _("span", {
							className: m ? "pl-place-valid" : "pl-place-invalid",
							children: o(m ? "games.projectl.canPlace" : "games.projectl.cannotFit")
						})
					]
				}),
				/* @__PURE__ */ _("div", {
					className: `pl-place-canvas ${c.color === "black" ? "is-black" : ""}`,
					children: /* @__PURE__ */ _("svg", {
						ref: h,
						viewBox: `0 0 ${c.w * d} ${c.h * d}`,
						style: {
							width: `calc(${c.w} * var(--pl-place-cell, ${d}px))`,
							height: `calc(${c.h} * var(--pl-place-cell, ${d}px))`
						},
						className: "touch-none",
						onPointerDown: (e) => {
							e.currentTarget.setPointerCapture(e.pointerId), g.current = !0;
							let t = b(e);
							t && x(t[0], t[1]);
						},
						onPointerMove: (e) => {
							if (!g.current) return;
							let t = b(e);
							t && x(t[0], t[1]);
						},
						onPointerUp: () => g.current = !1,
						onPointerCancel: () => g.current = !1,
						children: /* @__PURE__ */ _(he, {
							id: e.id,
							placed: e.placed,
							dark: c.color === "black",
							cell: d,
							ghost: {
								...t,
								valid: m
							}
						})
					})
				}),
				/* @__PURE__ */ _("p", {
					className: "pl-place-help",
					children: o("games.projectl.placeHint")
				}),
				/* @__PURE__ */ v("div", {
					className: "pl-place-tools",
					children: [
						/* @__PURE__ */ _("button", {
							type: "button",
							"aria-label": o("games.projectl.rotate"),
							onClick: () => n({
								...t,
								rot: (t.rot + 1) % 4
							}),
							className: "btn-quiet grid size-12 place-items-center",
							children: /* @__PURE__ */ _(u, {
								size: 20,
								"aria-hidden": !0
							})
						}),
						/* @__PURE__ */ _("button", {
							type: "button",
							"aria-label": o("games.projectl.flip"),
							onClick: () => n({
								...t,
								flip: !t.flip
							}),
							className: "btn-quiet grid size-12 place-items-center",
							children: /* @__PURE__ */ _(l, {
								size: 20,
								"aria-hidden": !0
							})
						}),
						/* @__PURE__ */ _("button", {
							type: "button",
							onClick: a,
							className: "btn-quiet px-2",
							children: o("games.projectl.cancel")
						}),
						/* @__PURE__ */ _("button", {
							type: "button",
							disabled: !m,
							onClick: i,
							className: "btn-base pl-place-confirm text-white",
							style: { background: w.accent },
							children: o("games.projectl.placeConfirm")
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region src/games/projectl/bot.ts
function Q() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function Te(e) {
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let i of [!1, !0]) for (let a = 0; a < 4; a++) {
		let o = t(E[e].shape, a, i), s = o.map((e) => e.join(",")).join("|");
		n.has(s) || (n.add(s), r.push({
			cells: o,
			rot: a,
			flip: i
		}));
	}
	return r;
}
var Ee = Object.fromEntries(D.map((e) => [e, Te(e)])), De = /* @__PURE__ */ new Map();
function Oe(e) {
	let t = De.get(e);
	return t || (t = new Set(M[e].cells.map(([e, t]) => `${e},${t}`)), De.set(e, t)), t;
}
function ke(e) {
	let n = /* @__PURE__ */ new Set();
	for (let r of e) for (let [e, i] of t(E[r.piece].shape, r.rot, r.flip)) n.add(`${r.x + e},${r.y + i}`);
	return n;
}
function Ae(e, t, n) {
	let r = M[e.id], i = Oe(e.id), a = ke(e.placed), o = [];
	for (let e of D) {
		if (n[e] <= 0) continue;
		let s = E[e].shape.flat().filter(Boolean).length;
		for (let n of Ee[e]) for (let c = 0; c <= r.h; c++) for (let l = 0; l <= r.w; l++) {
			let u = !0;
			for (let [e, t] of n.cells) {
				let n = `${l + e},${c + t}`;
				if (!i.has(n) || a.has(n)) {
					u = !1;
					break;
				}
			}
			u && o.push({
				pl: {
					piece: e,
					puzzle: t,
					x: l,
					y: c,
					rot: n.rot,
					flip: n.flip
				},
				completes: a.size + s === r.cells.length,
				cover: s
			});
		}
	}
	return o;
}
function je(e) {
	let t = M[e];
	return t.points + E[t.reward].level * .8;
}
function $(e, t, n) {
	let r = {
		id: e,
		placed: [...t]
	}, i = { ...n }, a = 0;
	for (let e = 0; e < 16 && !U(r); e += 1) {
		let e = Ae(r, 0, i);
		if (e.length === 0) break;
		let t = e.reduce((e, t) => e.cover >= t.cover ? e : t);
		r.placed.push({
			piece: t.pl.piece,
			x: t.pl.x,
			y: t.pl.y,
			rot: t.pl.rot,
			flip: t.pl.flip
		}), --i[t.pl.piece], a += t.cover;
	}
	return a;
}
function Me(e) {
	let t = [];
	for (let n of D) if (!(e[n] < 1)) for (let r of D) {
		if (r === n || E[r].level > E[n].level + 1) continue;
		let i = { ...e };
		--i[n], i[r] += 1, t.push(i);
	}
	return t;
}
function Ne(e, t, n, r) {
	let i = $(e, t, n);
	if (r > 3) return i;
	for (let r of Me(n)) {
		let n = $(e, t, r);
		n > i && (i = n);
	}
	return i;
}
function Pe(e, t, n) {
	let r = {
		id: e.id,
		placed: [...e.placed]
	}, i = { ...n }, a = null, o = 0;
	for (; !U(r);) {
		let e = Ae(r, t, i);
		if (e.length === 0) return null;
		let n = e.reduce((e, t) => e.cover >= t.cover ? e : t);
		if (a ||= n.pl, r.placed.push({
			piece: n.pl.piece,
			x: n.pl.x,
			y: n.pl.y,
			rot: n.pl.rot,
			flip: n.pl.flip
		}), --i[n.pl.piece], o += 1, o > 16) return null;
	}
	return {
		pl: a,
		cost: o
	};
}
function Fe(e, t, n, r) {
	let i = [];
	if (t.puzzles.length >= 4) return i;
	let a = (e, a, o) => {
		let s = M[a], c = (r ? $(a, [], t.supply) : Ne(a, [], t.supply, n)) / s.cells.length;
		c <= 0 || c < 1 && n < 4 || i.push({
			color: e,
			from: o,
			score: je(a) * (.3 + .7 * c) + (c >= 1 ? 3 : 0)
		});
	};
	return e.whiteRow.forEach((e, t) => a("white", e, t)), (!e.endTriggered || e.blackTaken < 1) && e.blackRow.forEach((e, t) => a("black", e, t)), i;
}
var Ie = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = t.difficulty === "weak", a = b(y(t.rid)), o = () => (Q() - .5) * a.noise * 2, s = D.reduce((e, t) => e + r.supply[t], 0);
	if (n.phase === "finishing") {
		if (n.ftTurn !== t.rid) return null;
		let e = null;
		for (let [t, n] of r.puzzles.entries()) {
			let i = Pe(n, t, r.supply);
			if (!i) continue;
			let a = M[n.id].points - i.cost;
			(!e || a > e.gain) && (e = {
				pl: i.pl,
				gain: a
			});
		}
		return e && (i ? Q() < .8 : e.gain > 0) ? { action: {
			type: "ftPlace",
			...e.pl
		} } : { action: { type: "ftDone" } };
	}
	if (n.phase !== "play" || n.turn !== t.rid) return null;
	let c = r.puzzles.map((e, t) => Ae(e, t, r.supply)), l = c.flatMap((e, t) => e.filter((e) => e.completes).map((e) => ({
		...e,
		puzzle: t
	}))), u = c.flatMap((e, t) => e.map((e) => ({
		...e,
		puzzle: t
	}))), d = (e) => M[e.id].cells.length - e.placed.reduce((e, t) => e + E[t.piece].shape.flat().filter(Boolean).length, 0), f = (e, t, n) => i ? $(e, t, n) : Ne(e, t, n, s - 1), p = u.filter((e) => {
		if (e.completes) return !0;
		let t = r.puzzles[e.puzzle], n = {
			...r.supply,
			[e.pl.piece]: r.supply[e.pl.piece] - 1
		};
		return f(t.id, [...t.placed, {
			piece: e.pl.piece,
			x: e.pl.x,
			y: e.pl.y,
			rot: e.pl.rot,
			flip: e.pl.flip
		}], n) >= d(t) - e.cover;
	}), m = Fe(n, r, s, i);
	if (i) {
		let e = (e) => e[Math.floor(Q() * e.length)];
		if (l.length > 0 && Q() < .8) return { action: {
			type: "place",
			...e(l).pl
		} };
		if (p.length > 0 && Q() < .8) return { action: {
			type: "place",
			...e(p).pl
		} };
		if (m.length > 0) {
			let t = e(m);
			return { action: {
				type: "take",
				color: t.color,
				from: t.from
			} };
		}
	} else {
		if (l.length > 0) {
			let e = { ...r.supply }, t = [], i = /* @__PURE__ */ new Set();
			for (let n of [...l].sort((e, t) => je(r.puzzles[t.puzzle].id) - je(r.puzzles[e.puzzle].id))) i.has(n.puzzle) || e[n.pl.piece] <= 0 || (i.add(n.puzzle), --e[n.pl.piece], t.push(n));
			return !n.masterUsed && t.length >= 2 ? { action: {
				type: "master",
				placements: t.map((e) => e.pl)
			} } : { action: {
				type: "place",
				...t[0].pl
			} };
		}
		if (!n.masterUsed) {
			let e = { ...r.supply }, t = [], n = /* @__PURE__ */ new Set();
			for (let r of [...p].sort((e, t) => t.cover - e.cover)) n.has(r.puzzle) || e[r.pl.piece] <= 0 || (n.add(r.puzzle), --e[r.pl.piece], t.push(r));
			let i = s - t.length === 0;
			if (t.length >= 2 && (!i || t.some((e) => e.completes))) return { action: {
				type: "master",
				placements: t.map((e) => e.pl)
			} };
		}
		let e = p.length > 0 ? p : s >= 4 ? u : [];
		if (e.length > 0) return { action: {
			type: "place",
			...e.reduce((e, t) => e.cover + o() >= t.cover ? e : t).pl
		} };
		if (m.length > 0) {
			let e = m.reduce((e, t) => e.score + o() >= t.score ? e : t);
			return { action: {
				type: "take",
				color: e.color,
				from: e.from
			} };
		}
	}
	if (r.puzzles.length > 0 && s > 0) {
		let e = (e) => {
			let t = 0;
			return r.puzzles.forEach((n, r) => {
				Ae(n, r, e).length !== 0 && (t += $(n.id, n.placed, e) >= d(n) ? 10 : 1);
			}), t;
		}, t = null, n = e(r.supply);
		for (let i of D) if (!(r.supply[i] < 1)) for (let a of D) {
			if (a === i || E[a].level > E[i].level + 1) continue;
			let o = e({
				...r.supply,
				[i]: r.supply[i] - 1,
				[a]: r.supply[a] + 1
			});
			o > n && (n = o, t = {
				give: i,
				take: a
			});
		}
		if (t) return { action: {
			type: "upgrade",
			...t
		} };
	}
	return s >= 4 && r.puzzles.length < 4 && n.blackDeck > 0 && (!n.endTriggered || n.blackTaken < 1) ? { action: {
		type: "take",
		color: "black",
		from: "deck"
	} } : n.whiteDeck > 0 && n.whiteRow.length > 0 ? { action: {
		type: "recycle",
		color: "white",
		order: n.whiteRow.map((e, t) => t)
	} } : { action: { type: "endTurn" } };
}, Le = {
	mono: "games.projectl.pieceMono",
	domino: "games.projectl.pieceDomino",
	I3: "games.projectl.pieceI3",
	L3: "games.projectl.pieceL3",
	I4: "games.projectl.pieceI4",
	O4: "games.projectl.pieceO4",
	T4: "games.projectl.pieceT4",
	L4: "games.projectl.pieceL4",
	S4: "games.projectl.pieceS4"
}, Re = {
	white: "games.projectl.rowWhite",
	black: "games.projectl.rowBlack"
}, ze = (e, t, n) => {
	if (e.type === "take") {
		let t = n(Re[e.color]);
		return e.from === "deck" ? n("games.projectl.hintTakeDeck", { row: t }) : n("games.projectl.hintTake", {
			row: t,
			n: e.from + 1
		});
	}
	return e.type === "recycle" ? n("games.projectl.hintRecycle", { row: n(Re[e.color]) }) : e.type === "upgrade" ? n("games.projectl.hintUpgrade", {
		give: n(Le[e.give]),
		take: n(Le[e.take])
	}) : e.type === "place" || e.type === "ftPlace" ? n("games.projectl.hintPlace", {
		piece: n(Le[e.piece]),
		n: e.puzzle + 1
	}) : e.type === "master" ? n("games.projectl.hintMaster", { n: e.placements.length }) : e.type === "endTurn" ? n("games.projectl.endTurn") : e.type === "ftDone" ? n("games.projectl.ftDone") : "";
}, Be = {
	take(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null, i = e.rid && typeof n?.id == "number" ? t.anchor(`card:${e.rid}:${n.id}`) : null;
		return !r && !i ? null : {
			ms: 800,
			node: /* @__PURE__ */ v(g, { children: [i && /* @__PURE__ */ _(S, {
				at: i,
				ms: 600
			}), r && /* @__PURE__ */ _(x, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ _("span", { children: "🧩" })
			})] })
		};
	},
	recycle(e, t) {
		let n = e.data, r = t.anchor(`market:${n?.color === "black" ? "black" : "white"}`);
		return r ? {
			ms: 500,
			node: /* @__PURE__ */ _(S, {
				at: r,
				ms: 500
			})
		} : null;
	},
	upgrade(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return typeof n?.give != "string" || typeof n.take != "string" || !r ? null : {
			ms: 900,
			node: /* @__PURE__ */ _(x, {
				at: r,
				ms: 900,
				children: /* @__PURE__ */ v("span", {
					className: "flex items-center gap-1 rounded-md border-2 border-ink bg-surface px-1.5 py-0.5",
					children: [
						/* @__PURE__ */ _(Z, {
							piece: n.give,
							size: 14
						}),
						/* @__PURE__ */ _("span", {
							"aria-hidden": !0,
							children: "→"
						}),
						/* @__PURE__ */ _(Z, {
							piece: n.take,
							size: 14
						})
					]
				})
			})
		};
	},
	place(e, t) {
		let n = e.data, r = typeof n?.puzzle == "number" && e.rid ? t.anchor(`puzzle:${e.rid}:${n.puzzle}`) : null;
		return r ? {
			ms: 500,
			node: /* @__PURE__ */ _(S, {
				at: r,
				ms: 500
			})
		} : null;
	},
	master(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ _(x, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ _("span", { children: "✨" })
			})
		} : null;
	},
	complete(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null, i = (e.rid ? t.anchor(`completed:${e.rid}`) : null) ?? r;
		return typeof n?.points != "number" || !i ? null : {
			ms: 1100,
			node: /* @__PURE__ */ _(x, {
				at: i,
				ms: 1100,
				children: /* @__PURE__ */ v("span", {
					className: "flex items-center gap-1 rounded-md border-2 border-ink bg-warn-soft px-1.5 py-0.5 font-mono font-extrabold tabular-nums",
					children: [
						"+",
						n.points,
						" ⭐",
						typeof n.reward == "string" && /* @__PURE__ */ _(Z, {
							piece: n.reward,
							size: 14
						})
					]
				})
			})
		};
	},
	endTrigger(e, t) {
		let n = t.anchor("market:black");
		return n ? {
			ms: 1200,
			node: /* @__PURE__ */ _(x, {
				at: n,
				ms: 1200,
				children: /* @__PURE__ */ _("span", { children: "🏁" })
			})
		} : null;
	}
};
//#endregion
//#region src/games/projectl/game-over.tsx
function Ve({ final: e, completedIds: t, won: n, place: r, name: i }) {
	let a = s(), o = [
		{
			label: a("games.projectl.scoreCompleted"),
			value: e.completedPoints
		},
		{
			label: a("games.projectl.scoreUnfinished"),
			value: -e.unfinished
		},
		{
			label: a("games.projectl.scoreFt"),
			value: -e.ft
		}
	];
	return /* @__PURE__ */ v("section", {
		className: `pl-result-card flex flex-col gap-1.5 ${n ? "is-winner" : ""}`,
		children: [
			/* @__PURE__ */ v("header", {
				className: "pl-result-player flex w-full items-center gap-1.5",
				children: [
					/* @__PURE__ */ _("span", {
						"aria-hidden": !0,
						className: n ? "" : "invisible",
						children: "🏆"
					}),
					/* @__PURE__ */ v("span", {
						className: "min-w-0 flex-1 truncate text-sm font-extrabold",
						children: [
							r,
							". ",
							i
						]
					}),
					/* @__PURE__ */ _("span", {
						className: "flex-none font-mono text-lg font-extrabold tabular-nums",
						children: e.total
					})
				]
			}),
			t.length > 0 && /* @__PURE__ */ _("div", {
				className: "pl-result-completed",
				children: t.map((e) => /* @__PURE__ */ _(ge, { id: e }, e))
			}),
			/* @__PURE__ */ v("ul", {
				className: "pl-result-breakdown w-full",
				children: [o.map((e, t) => /* @__PURE__ */ v("li", {
					className: `flex items-baseline justify-between text-xs font-bold ${e.value === 0 ? "opacity-40" : ""}`,
					children: [/* @__PURE__ */ _("span", { children: e.label }), /* @__PURE__ */ _("span", {
						className: "font-mono tabular-nums",
						children: e.value > 0 ? `+${e.value}` : e.value
					})]
				}, t)), /* @__PURE__ */ v("li", {
					className: "flex items-baseline justify-between text-xs font-bold opacity-60",
					children: [/* @__PURE__ */ _("span", { children: a("games.projectl.statLeftover", { n: e.leftover }) }), /* @__PURE__ */ _("span", {
						"aria-hidden": !0,
						children: "🧱"
					})]
				})]
			})
		]
	});
}
function He({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let a = s(), o = t, c = (e) => n.find((t) => t.rid === e)?.name ?? e, l = r ?? i;
	return /* @__PURE__ */ v("div", {
		className: "pl-result",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ _(C, {}),
			/* @__PURE__ */ v("h1", {
				className: "pl-result-heading",
				children: [/* @__PURE__ */ _("span", {
					"aria-hidden": !0,
					children: w.icon
				}), a("session.result.title")]
			}),
			/* @__PURE__ */ _("div", {
				className: "pl-result-board",
				children: e.ranking.map((t, n) => {
					let r = o.final?.find((e) => e.rid === t);
					if (!r) return null;
					let i = o.players.find((e) => e.rid === t)?.completed ?? [];
					return /* @__PURE__ */ _(Ve, {
						final: r,
						completedIds: i,
						won: e.winner.includes(t),
						place: n + 1,
						name: c(t)
					}, t);
				})
			}),
			l ? /* @__PURE__ */ v("div", {
				className: "pl-result-actions safe-b flex w-full flex-none flex-col gap-2 pb-1",
				children: [r && /* @__PURE__ */ _("button", {
					className: "btn-base w-full cursor-pointer text-white",
					style: { background: w.accent },
					onClick: r,
					children: a("session.result.playAgain")
				}), i && /* @__PURE__ */ _("button", {
					className: "btn-quiet w-full cursor-pointer",
					onClick: i,
					children: a("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ _("p", {
				className: "safe-b flex-none pb-1 text-sm font-bold opacity-70",
				children: a("session.result.waitHost")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/projectl/entry.tsx
var Ue = {
	definition: pe,
	View: ve,
	bot: Ie,
	describe: ze,
	fx: Be,
	OverView: He,
	locales: {
		zh: {
			name: "L计划",
			desc: "拿拼图、升拼块,每回合三动拼出最高分",
			rules: "目标:完成拼图得分;黑牌堆耗尽触发终局,补完本轮再打一整轮后结算,总分最高者胜。\n准备:\n· 白拼图 32 张洗混;黑拼图按人数随机取(2 人 12 张 / 3 人 14 张 / 4 人 16 张)洗混。\n· 两种拼图各翻开 4 张,分成两行。\n· 每人起手 1 个 1 级块和 1 个 2 级块。\n流程(每回合 3 个行动,任意组合):\n· 拿拼图:从某行拿取 1 张明置拼图(该行补新),或从牌堆顶盲取 1 张;未完成拼图至多 4 张。\n· 回收:选一行,整行按从左到右顺序放回牌堆底,重翻 4 张。\n· 升级:退回 1 块,换成同级、任意更低等级或高一级的一块。\n· 放置:把 1 块放进自己某张拼图的凹槽(可旋转翻面,放下不可移动)。\n· 大师行动(每回合限 1 次):往自己每张未完成拼图各放至多 1 块。\n完成拼图:\n· 凹槽填满即完成:收回全部拼块、获得卡面奖励块,拼图放入得分堆。\n· 储备里该形状拿完时,改拿同级任意块;同级也拿完时,改拿相邻等级。\n结束:\n· 黑牌堆空触发终局;此后黑拼图不再补充,每人每回合限拿取 1 张黑拼图。\n· 收尾:依次往未完成拼图自由放块,每块扣 1 分;此时完成的拼图计分但无奖励、不回收拼块。\n计分:得分堆总分 − 未完成拼图面值 − 收尾罚分;平分依次比完成张数、剩余拼块数,再平则共享胜利。",
			stageYourTurn: "轮到你:{{n}} 个行动",
			waitTurn: "等 {{name}} 行动…",
			stageFt: "收尾:免费放块,每块 -1 分",
			waitFt: "等 {{name}} 收尾…",
			endChip: "最后一轮",
			rowWhite: "白拼图",
			rowBlack: "黑拼图",
			deckRemaining: "剩 {{n}}",
			blindShort: "盲拿",
			recycleShort: "重翻",
			emptyMarket: "空位",
			myPuzzles: "我的拼图 · {{n}}/4",
			playerPuzzles: "{{name}}的拼图 · {{n}}/4",
			tapFitting: "点亮的拼图可放",
			supplyLabel: "我的拼块",
			slotEmpty: "拿拼图",
			queued: "已加入大师行动",
			canPlace: "可放 ✓",
			cannotFit: "无法放入",
			filledCount: "已填 {{n}}/{{total}}",
			pointsShort: "{{n}} 分",
			rewardOnly: "奖励",
			placeHint: "拖动拼块定位，旋转或翻面后确认",
			deckAria: "牌堆,剩 {{n}} 张",
			blindTake: "盲拿牌堆顶",
			takeArm: "再点一次拿走",
			recycleArm: "再点一次回收整行重翻",
			recycleAria: "回收该行",
			emptyPuzzles: "点上方拼图拿一张,开始建造",
			pieceMono: "单格块",
			pieceDomino: "双格块",
			pieceI3: "直三块",
			pieceL3: "拐三块",
			pieceI4: "直四块",
			pieceO4: "田字块",
			pieceT4: "T 字块",
			pieceL4: "拐四块",
			pieceS4: "S 块",
			pieceCountAria: "{{name}} ×{{n}}",
			pointsAria: "{{n}} 分拼图",
			rewardAria: "完成奖励:{{name}}",
			rotate: "旋转",
			flip: "翻面",
			placeConfirm: "放入",
			cancel: "取消",
			master: "大师",
			masterConfirm: "大师行动({{n}} 块)",
			masterHint: "大师行动:每张拼图各放至多 1 块",
			upgrade: "升级",
			upgradeHint: "先点要退回的块,再点要换的块(同级/更低/高一级)",
			upgradeConfirm: "换",
			endTurn: "结束回合",
			ftDone: "完成收尾",
			scoreShort: "{{n}} 分",
			completedShort: "完成 {{n}} 张",
			scoreCompleted: "完成拼图得分",
			scoreUnfinished: "未完成扣分",
			scoreFt: "收尾罚分",
			statLeftover: "剩余拼块 {{n}}",
			errNotYourTurn: "还没轮到你",
			errPuzzlesFull: "未完成拼图至多 4 张",
			errDeckEmpty: "牌堆已空",
			errBadRow: "这个位置没有拼图",
			errBlackLimit: "终局触发后每回合限拿 1 张黑拼图",
			errBadOrder: "回收顺序无效",
			errNoPiece: "供应区没有这块",
			errReserveEmpty: "储备里这种块已拿完",
			errBadUpgrade: "只能换同级、更低或高一级",
			errBadPuzzle: "目标拼图不存在",
			errBadPlacement: "这块放不进凹槽",
			errMasterUsed: "大师行动每回合限一次",
			errMasterMulti: "大师行动每张拼图限放 1 块",
			hintTake: "拿{{row}}第 {{n}} 张",
			hintTakeDeck: "盲拿{{row}}牌堆顶",
			hintRecycle: "回收{{row}}整行重翻",
			hintUpgrade: "退回{{give}},换成{{take}}",
			hintPlace: "把{{piece}}放进第 {{n}} 张拼图",
			hintMaster: "大师行动:一次放 {{n}} 块"
		},
		en: {
			name: "Project L",
			desc: "Draft puzzles, upgrade pieces — three actions a turn to outscore everyone",
			rules: "Goal: complete puzzles for points. When the black deck runs out, finish the round and play one final round; highest score wins.\nSetup:\n· Shuffle 32 white puzzles; take black puzzles at random by player count (12 for 2P / 14 for 3P / 16 for 4P) and shuffle.\n· Reveal 4 of each into two rows.\n· Everyone starts with one level-1 and one level-2 piece.\nPlay (3 actions per turn, any mix):\n· Take: take 1 face-up puzzle from a row (the row refills) or the top of a deck blind; at most 4 unfinished puzzles.\n· Recycle: send a row's puzzles to the bottom of its deck in left-to-right order, then reveal 4 new ones.\n· Upgrade: return 1 piece, take a piece of the same level, any lower level, or one level higher.\n· Place: put 1 piece into a recess of one of your puzzles (rotate/flip freely; placed pieces cannot move).\n· Master (once per turn): place up to 1 piece into each of your unfinished puzzles.\nCompleting puzzles:\n· A full recess completes the puzzle: take back all its pieces, gain the depicted bonus piece, and stack it into your score pile.\n· If that shape is gone from the reserve, take any piece of the same level; if the level is empty, take an adjacent level.\nGame end:\n· An empty black deck triggers the end; black puzzles no longer refill, and each player may take at most 1 black puzzle per turn.\n· Finishing Touches: in turn order, freely place pieces into unfinished puzzles at a cost of 1 point each; puzzles completed now score but give no bonus and return no pieces.\nScoring: score pile total − face value of unfinished puzzles − finishing penalties. Ties: most completed puzzles, then most pieces left, then shared victory.",
			stageYourTurn: "Your turn: {{n}} actions",
			waitTurn: "Waiting for {{name}}…",
			stageFt: "Finishing touches: place freely, -1 per piece",
			waitFt: "Waiting for {{name}} to finish up…",
			endChip: "Final round",
			rowWhite: "White",
			rowBlack: "Black",
			deckRemaining: "{{n}} left",
			blindShort: "Blind",
			recycleShort: "Redraw",
			emptyMarket: "Empty",
			myPuzzles: "My puzzles · {{n}}/4",
			playerPuzzles: "{{name}}'s puzzles · {{n}}/4",
			tapFitting: "Tap a lit puzzle",
			supplyLabel: "My pieces",
			slotEmpty: "Take a puzzle",
			queued: "Queued for Master",
			canPlace: "Fits ✓",
			cannotFit: "No fit",
			filledCount: "Filled {{n}}/{{total}}",
			pointsShort: "{{n}} pts",
			rewardOnly: "Reward",
			placeHint: "Drag the piece, rotate or flip, then place",
			deckAria: "Deck, {{n}} left",
			blindTake: "Take the top card blind",
			takeArm: "Tap again to take",
			recycleArm: "Tap again to recycle the row",
			recycleAria: "Recycle this row",
			emptyPuzzles: "Take a puzzle from above to start building",
			pieceMono: "monomino",
			pieceDomino: "domino",
			pieceI3: "I-tromino",
			pieceL3: "L-tromino",
			pieceI4: "I-tetromino",
			pieceO4: "O-tetromino",
			pieceT4: "T-tetromino",
			pieceL4: "L-tetromino",
			pieceS4: "S-tetromino",
			pieceCountAria: "{{name}} ×{{n}}",
			pointsAria: "{{n}}-point puzzle",
			rewardAria: "Completion reward: {{name}}",
			rotate: "Rotate",
			flip: "Flip",
			placeConfirm: "Place",
			cancel: "Cancel",
			master: "Master",
			masterConfirm: "Master action ({{n}} pieces)",
			masterHint: "Master: up to 1 piece per puzzle",
			upgrade: "Upgrade",
			upgradeHint: "Tap a piece to return, then a piece to take (same, lower, or one level up)",
			upgradeConfirm: "Swap",
			endTurn: "End turn",
			ftDone: "Done",
			scoreShort: "{{n}} pts",
			completedShort: "{{n}} completed",
			scoreCompleted: "Completed puzzles",
			scoreUnfinished: "Unfinished penalty",
			scoreFt: "Finishing touches",
			statLeftover: "{{n}} pieces left",
			errNotYourTurn: "Not your turn",
			errPuzzlesFull: "At most 4 unfinished puzzles",
			errDeckEmpty: "Deck is empty",
			errBadRow: "No puzzle at this slot",
			errBlackLimit: "After the endgame, at most 1 black puzzle per turn",
			errBadOrder: "Invalid recycle order",
			errNoPiece: "Piece not in your supply",
			errReserveEmpty: "None of that piece left in the reserve",
			errBadUpgrade: "Only same, lower, or one level higher",
			errBadPuzzle: "No such puzzle",
			errBadPlacement: "This piece doesn't fit the recess",
			errMasterUsed: "Master action already used this turn",
			errMasterMulti: "Master: at most 1 piece per puzzle",
			hintTake: "Take card {{n}} from the {{row}}",
			hintTakeDeck: "Blind-take the top of the {{row}} deck",
			hintRecycle: "Recycle the {{row}} and redraw",
			hintUpgrade: "Trade in {{give}} for {{take}}",
			hintPlace: "Place the {{piece}} into puzzle {{n}}",
			hintMaster: "Master action: place {{n}} pieces at once"
		}
	}
};
//#endregion
export { Ue as default };
