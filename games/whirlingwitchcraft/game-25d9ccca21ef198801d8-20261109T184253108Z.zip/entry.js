import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { createPortal as r } from "react-dom";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { seatName as c } from "@bgparty/sdk/ui/player-strip";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { Floater as p, FlySprite as m, PulseBox as h } from "@bgparty/sdk/fx/primitives";
import { OptionSection as g, OptionSwitch as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/whirlingwitchcraft/meta.ts
var v = {
	id: "whirlingwitchcraft",
	tier: "alpha",
	mechanics: [
		"engine-building",
		"drafting",
		"hand-management"
	],
	interactionTags: [],
	nameKey: "games.whirlingwitchcraft.name",
	descKey: "games.whirlingwitchcraft.desc",
	rulesKey: "games.whirlingwitchcraft.rules",
	icon: "⚗️",
	iconImg: "games/whirlingwitchcraft.webp",
	rulesUrl: { en: "https://www.alderac.com/wp-content/uploads/2025/03/WhirlingWitchcraft_Rulebook.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4, 5],
	accent: "#713c91",
	releasedAt: "2026-11-10T02:22:14+08:00",
	search: {
		py: "du dou mo yao shi",
		init: "ddmys"
	},
	hotseat: "cover",
	botDelayMs: 650
}, y = [
	"h",
	"m",
	"r",
	"s",
	"t"
], b = {
	h: 3,
	m: 4,
	r: 9,
	s: 9,
	t: 9
}, x = () => ({
	h: 0,
	m: 0,
	r: 0,
	s: 0,
	t: 0
}), S = (e) => y.reduce((t, n) => t + e[n], 0), C = (e) => y.filter((t) => e[t] > 0).length, w = [
	"potion",
	"raven",
	"book"
], ee = (e) => [...e].map((e) => ({
	P: "potion",
	R: "raven",
	B: "book"
})[e]), T = (e, t, n, r = "", i = !1) => ({
	id: e,
	input: t ? t.split(" ") : [],
	output: n ? n.split(" ") : [],
	reversible: i,
	arcana: ee(r)
}), E = [
	T(1, "h h", "m s s t t"),
	T(2, "", "", "RPB"),
	T(3, "h m s r t", "h h"),
	T(4, "r r", "r s t t", "", !0),
	T(5, "t t", "t r s s", "", !0),
	T(6, "s s", "s t r r", "", !0),
	T(7, "", "s r t", "RR"),
	T(8, "r r st st", "h", "BB"),
	T(9, "m", "s r t", "PP", !0),
	T(10, "t", "m", "RPB"),
	T(11, "r", "m", "RPB"),
	T(12, "s", "m", "RPB"),
	T(13, "t", "m r", "RP"),
	T(14, "r", "m s", "PB"),
	T(15, "s", "m t", "RB"),
	T(16, "rt", "s s", "R", !0),
	T(17, "rs", "t t", "P", !0),
	T(18, "st", "r r", "B", !0),
	T(19, "m t", "m rs", "RB"),
	T(20, "m s", "m rt", "RP"),
	T(21, "m r", "m st", "PB"),
	T(22, "m m", "r r r"),
	T(23, "m m", "s s s"),
	T(24, "m m", "t t t"),
	T(25, "m s s", "h t r", "R"),
	T(26, "m r r", "h t s", "P"),
	T(27, "m t t", "h r s", "B"),
	T(28, "st r", "r rt", "R", !0),
	T(29, "rs t", "t st", "P", !0),
	T(30, "st r", "s rs", "B", !0),
	T(31, "rs", "rt r", "R"),
	T(32, "rt", "st t", "P"),
	T(33, "st", "rs s", "B"),
	T(34, "s s", "r t", "RP", !0),
	T(35, "r r", "s t", "PB", !0),
	T(36, "t t", "r s", "BR", !0),
	T(37, "s r", "m", "RRP", !0),
	T(38, "t r", "m", "PPB", !0),
	T(39, "t s", "m", "BBR", !0),
	T(40, "m s", "h", "R", !0),
	T(41, "m r", "h", "P", !0),
	T(42, "m t", "h", "B", !0),
	T(43, "m s r t", "h t s", "R", !0),
	T(44, "m s r t", "h s r", "P", !0),
	T(45, "m s r t", "h r t", "B", !0),
	T(46, "rs r", "m s t", "R"),
	T(47, "rt t", "m r s", "P"),
	T(48, "st s", "m t r", "B"),
	T(49, "s", "s t r", "RP"),
	T(50, "t", "s t r", "PB"),
	T(51, "r", "s t r", "BR"),
	T(52, "m", "m s s", "R"),
	T(53, "m", "m t t", "P"),
	T(54, "m", "m r r", "B"),
	T(55, "h", "h r s", "R"),
	T(56, "h", "h t s", "P"),
	T(57, "h", "h t r", "B"),
	T(58, "s s", "m t t", "R"),
	T(59, "t t", "m r r", "P"),
	T(60, "r r", "m s s", "B")
], te = Object.fromEntries(E.map((e) => [e.id, e])), D = [
	"initiate",
	"fey",
	"clairvoyant",
	"daredevil",
	"frog",
	"hidden",
	"potionBrewer",
	"scholar",
	"spider",
	"trickster",
	"uncontrolled",
	"whirlwind",
	"allTrades"
], O = (e, t, n, r, i) => ({
	h: e,
	m: t,
	r: n,
	s: r,
	t: i
}), ne = {
	initiate: O(0, 1, 4, 4, 4),
	fey: O(1, 0, 5, 5, 0),
	clairvoyant: O(1, 2, 4, 4, 4),
	daredevil: O(0, 1, 4, 4, 4),
	frog: O(0, 1, 2, 1, 9),
	hidden: O(0, 0, 4, 4, 4),
	potionBrewer: O(0, 2, 4, 4, 4),
	scholar: O(1, 2, 3, 3, 3),
	spider: O(1, 0, 2, 5, 2),
	trickster: O(1, 1, 5, 3, 5),
	uncontrolled: O(0, 0, 2, 2, 2),
	whirlwind: O(0, 0, 5, 5, 5),
	allTrades: O(1, 1, 5, 5, 5)
}, k = {
	fey: T(101, "", "m t"),
	frog: T(102, "t t t", "?", "B"),
	hidden: T(103, "h m s r t", "? ? ?"),
	spider: T(104, "m m", "s s s s s"),
	trickster: T(105, "r r", "t t", "", !0),
	uncontrolled: T(106, "h", "m r")
}, A = (e) => te[e] ?? Object.values(k).find((t) => t.id === e), j = (e, t) => {
	let n = A(e);
	return t ? {
		input: n.output,
		output: n.input
	} : n;
}, M = t.enum(y), N = t.object({
	h: t.int().nonnegative(),
	m: t.int().nonnegative(),
	r: t.int().nonnegative(),
	s: t.int().nonnegative(),
	t: t.int().nonnegative()
}), P = t.object({ personalities: t.boolean().default(!1) }).default({ personalities: !1 }), re = t.object({
	type: M,
	source: t.enum([
		"bench",
		"pool",
		"book"
	])
}), ie = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("role"),
		role: t.enum(D)
	}),
	t.object({
		type: t.literal("prepare"),
		ingredient: M
	}),
	t.object({ type: t.literal("refresh") }),
	t.object({
		type: t.literal("select"),
		card: t.int().min(1).max(60),
		flipped: t.boolean(),
		random: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("arcana"),
		arcana: t.enum([
			"potion",
			"raven",
			"book",
			"wild",
			"brewer"
		]),
		ingredients: t.array(M).max(2),
		effect: t.enum([
			"potion",
			"raven",
			"book"
		]).optional()
	}),
	t.object({
		type: t.literal("brew"),
		card: t.int().min(1).max(106),
		pay: t.array(re).max(5),
		outputs: t.array(M).max(5)
	}),
	t.object({
		type: t.literal("scholar"),
		pay: t.array(re).length(2),
		ingredient: M
	}),
	t.object({
		type: t.literal("finish"),
		bonus: M.optional()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ae = t.object({
	card: t.int(),
	flipped: t.boolean(),
	used: t.boolean()
}), oe = t.object({
	rid: t.string(),
	role: t.enum(D).nullable(),
	roleActive: t.boolean(),
	bench: N,
	pool: N,
	circle: N,
	tableau: t.array(ae),
	arcana: t.object({
		potion: t.int(),
		raven: t.int(),
		book: t.int()
	}),
	pending: t.object({
		potion: t.int(),
		raven: t.int(),
		book: t.int(),
		wild: t.int(),
		brewer: t.int()
	}),
	books: t.array(M),
	ready: t.boolean(),
	picked: t.boolean(),
	prepared: t.boolean(),
	scholarUsed: t.boolean(),
	handCount: t.int()
}), se = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"roles",
		"select",
		"reveal",
		"arcana",
		"brew",
		"pass",
		"check",
		"done"
	]),
	players: t.array(oe),
	deckCount: t.int(),
	last: t.object({
		kind: t.string(),
		rid: t.string(),
		target: t.string().optional(),
		card: t.int().optional(),
		ingredients: N.optional()
	}).nullable()
}), ce = t.object({
	hand: t.array(t.int()),
	roleChoices: t.array(t.enum(D)),
	selected: t.object({
		card: t.int(),
		flipped: t.boolean()
	}).nullable()
}), F = {
	reveal: 700,
	pass: 850,
	check: 700,
	brew: 520
}, le = () => ({
	potion: 0,
	raven: 0,
	book: 0,
	wild: 0,
	brewer: 0
});
function I(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function ue(e) {
	return !e.deck.length && e.discard.length && (e.deck = I(e, e.discard), e.discard = []), e.deck.pop();
}
function L(e, t) {
	let n = t.role === "clairvoyant" ? 5 : 4;
	for (; e.hands[t.rid].length < n;) {
		let n = ue(e);
		if (n === void 0) break;
		e.hands[t.rid].push(n);
	}
	t.handCount = e.hands[t.rid].length;
}
function de(e, t) {
	e.role = t, e.bench = { ...ne[t] }, e.roleActive = !0;
	let n = k[t];
	if (n) {
		e.tableau.push({
			card: n.id,
			flipped: !1,
			used: !1
		});
		for (let t of n.arcana) e.arcana[t]++;
	}
	e.prepared = t !== "uncontrolled";
}
function fe(e, t, n) {
	let r = P.parse(e ?? {}), i = {
		players: [],
		hands: {},
		choices: {},
		selected: {},
		deck: [],
		discard: [],
		seed: n,
		cursor: 0,
		round: 1,
		phase: r.personalities ? "roles" : "select",
		transfer: 0,
		last: null
	};
	i.deck = I(i, E.map((e) => e.id));
	let a = I(i, D.filter((e) => e !== "initiate"));
	return t.forEach((e, t) => {
		let n = {
			rid: e,
			role: null,
			roleActive: !1,
			bench: x(),
			pool: x(),
			circle: x(),
			tableau: [],
			arcana: {
				potion: 0,
				raven: 0,
				book: 0
			},
			pending: le(),
			books: [],
			ready: !1,
			picked: !1,
			prepared: !0,
			scholarUsed: !1,
			handCount: 0
		};
		i.players.push(n), i.hands[e] = [], i.choices[e] = r.personalities ? a.slice(t * 2, t * 2 + 2) : [], r.personalities || de(n, "initiate"), L(i, n);
	}), {
		state: i,
		fx: [{
			kind: "deal",
			data: { count: t.length }
		}]
	};
}
function R(e, t) {
	return A(t).reversible || e.role === "whirlwind";
}
function z(e, t, n) {
	if (t.length !== n.length) return null;
	let r = structuredClone(e);
	for (let e = 0; e < n.length; e++) {
		let i = t[e];
		if (n[e] !== "?" && !n[e].includes(i.type)) return null;
		if (i.source === "book") {
			if (!r.books.includes(i.type)) return null;
		} else {
			if (r[i.source][i.type] <= 0) return null;
			r[i.source][i.type]--;
		}
	}
	return r;
}
function B(e, t) {
	let n = { ...e.bench }, r = { ...e.pool };
	function i(a) {
		if (a === t.length) return [];
		for (let o of [
			"book",
			"bench",
			"pool"
		]) for (let s of y.filter((e) => t[a] === "?" || t[a].includes(e))) {
			let t = o === "bench" ? n : r;
			if (o === "book" ? !e.books.includes(s) : t[s] < 1) continue;
			o !== "book" && t[s]--;
			let c = i(a + 1);
			if (o !== "book" && t[s]++, c) return [{
				source: o,
				type: s
			}, ...c];
		}
		return null;
	}
	return i(0);
}
var V = (e) => B({
	...e,
	books: []
}, ["m", "m"]);
function pe(e) {
	e.players.every((e) => Object.values(e.pending).every((e) => e === 0)) && (e.phase = "brew");
}
function me(e, t) {
	return S(t.circle) - S(e.circle) || C(t.circle) - C(e.circle) || S(e.bench) - S(t.bench);
}
function he(e) {
	let t = [...e.players].sort(me), n = t[0];
	return {
		winner: t.filter((e) => S(e.circle) >= 5 && me(e, n) === 0).map((e) => e.rid),
		ranking: t.map((e) => e.rid),
		scores: Object.fromEntries(t.map((e) => [e.rid, S(e.circle)]))
	};
}
function ge(e, t, n, r) {
	let i = Math.min(r, b[n] - t.bench[n]);
	t.bench[n] += i, i < r && (e.players[(e.players.indexOf(t) - 1 + e.players.length) % e.players.length].circle[n] += r - i);
}
function _e(e) {
	let t = e.players.map((t) => [...e.hands[t.rid]]);
	e.round++, e.selected = {}, e.last = null, e.players.forEach((n, r) => {
		e.hands[n.rid] = t[(r + 1) % t.length], L(e, n), n.ready = !1, n.picked = e.hands[n.rid].length === 0, n.books = [], n.pool = x(), n.pending = le(), n.scholarUsed = !1, n.prepared = n.role !== "uncontrolled", n.tableau.forEach((e) => {
			e.used = !1, e.card === 105 && (e.flipped = !e.flipped);
		});
	}), e.phase = e.players.every((e) => e.picked) ? "reveal" : "select";
}
function ve(t, n, r) {
	if (n.type === "tick") {
		if (![
			"reveal",
			"pass",
			"check"
		].includes(t.phase)) return {
			state: t,
			fx: []
		};
		let e = structuredClone(t);
		if (e.phase === "reveal") {
			for (let t of e.players) {
				let n = e.selected[t.rid];
				if (!n) continue;
				t.tableau.push({
					card: n.card,
					flipped: n.flipped,
					used: !1
				});
				let r = A(n.card);
				for (let e of w) {
					let n = t.arcana[e];
					t.arcana[e] += r.arcana.filter((t) => t === e).length, t.pending[e] += Math.floor(t.arcana[e] / 2) - Math.floor(n / 2);
				}
				n.random && t.pending.wild++, t.role === "potionBrewer" && (t.pending.brewer = r.arcana.filter((e) => e === "potion").length);
			}
			return e.phase = "arcana", pe(e), {
				state: e,
				fx: [{
					kind: "reveal",
					data: { cards: Object.entries(e.selected).map(([e, t]) => ({
						rid: e,
						...t
					})) }
				}]
			};
		}
		if (e.phase === "pass") {
			let t = e.players[e.transfer], n = e.players[(e.transfer + 1) % e.players.length], r = { ...t.pool }, i = x();
			for (let e of y) {
				let a = Math.min(r[e], b[e] - n.bench[e]);
				n.bench[e] += a, i[e] = r[e] - a, t.circle[e] += i[e];
			}
			return t.pool = x(), e.last = {
				kind: "pass",
				rid: t.rid,
				target: n.rid,
				ingredients: r
			}, e.transfer++, e.transfer === e.players.length && (e.phase = "check"), {
				state: e,
				fx: [{
					kind: "pass",
					rid: t.rid,
					data: {
						target: n.rid,
						sent: r,
						overflow: i
					}
				}]
			};
		}
		return e.players.some((e) => S(e.circle) >= 5) ? (e.phase = "done", {
			state: e,
			fx: [{
				kind: "victory",
				data: { winners: he(e).winner }
			}]
		}) : (_e(e), {
			state: e,
			fx: [{
				kind: "deal",
				data: { count: e.players.length }
			}]
		});
	}
	let i = t.players.findIndex((e) => e.rid === r.by);
	if (i < 0 || t.phase === "done") return { code: "games.whirlingwitchcraft.errPhase" };
	let a = structuredClone(t), o = a.players[i], s = [], c = () => ({ code: "games.whirlingwitchcraft.errAction" });
	if (n.type === "role") {
		if (a.phase !== "roles" || o.role || !a.choices[o.rid].includes(n.role)) return c();
		de(o, n.role), a.choices[o.rid] = [], L(a, o), a.players.every((e) => e.role) && (a.phase = "select");
	} else if (n.type === "prepare") {
		if (a.phase !== "select" || o.prepared || o.picked || o.role !== "uncontrolled") return c();
		ge(a, o, n.ingredient, 3), o.prepared = !0, s.push({
			kind: "gain",
			rid: o.rid,
			data: {
				type: n.ingredient,
				count: 3
			}
		});
	} else if (n.type === "refresh") {
		if (a.phase !== "select" || o.picked || o.role !== "initiate" || !o.roleActive) return c();
		a.discard.push(...a.hands[o.rid]), a.hands[o.rid] = [], L(a, o), o.roleActive = !1, s.push({
			kind: "refresh",
			rid: o.rid
		});
	} else if (n.type === "select") {
		if (a.phase !== "select" || o.picked || !o.prepared) return c();
		let t = n.card;
		if (n.random) {
			if (o.role !== "daredevil" || !a.hands[o.rid].length) return c();
			t = a.hands[o.rid][e(a.seed, a.cursor++, a.hands[o.rid].length)];
		}
		if (!a.hands[o.rid].includes(t) || n.flipped && !R(o, t)) return c();
		a.hands[o.rid] = a.hands[o.rid].filter((e) => e !== t), o.handCount = a.hands[o.rid].length, o.picked = !0, a.selected[o.rid] = {
			card: t,
			flipped: n.flipped,
			random: n.random
		}, a.players.every((e) => e.picked) && (a.phase = "reveal"), s.push({
			kind: "select",
			rid: o.rid
		});
	} else if (n.type === "arcana") {
		if (a.phase !== "arcana" || o.pending[n.arcana] < 1) return c();
		let e = n.ingredients;
		if (n.arcana === "wild") {
			if (e.length || !n.effect) return c();
			o.pending.wild--, o.pending[n.effect]++;
		} else if (n.arcana === "raven") {
			let t = x();
			if (e.forEach((e) => t[e]++), y.some((e) => t[e] > o.bench[e])) return c();
			y.forEach((e) => {
				o.bench[e] -= t[e];
			}), o.pending.raven--;
		} else {
			if (e.length > 1) return c();
			if (e[0]) {
				let t = e[0];
				if (n.arcana === "book") o.books.includes(t) || o.books.push(t);
				else if (n.arcana === "brewer") {
					if (!o.bench[t]) return c();
					o.bench[t]--, o.pool[t]++;
				} else o.pool[t]++;
			}
			o.pending[n.arcana]--;
		}
		a.last = {
			kind: "arcana",
			rid: o.rid
		}, pe(a), s.push({
			kind: "arcana",
			rid: o.rid,
			data: {
				arcana: n.arcana,
				ingredients: e
			}
		});
	} else if (n.type === "brew") {
		if (a.phase !== "brew" || o.ready) return c();
		let e = o.tableau.find((e) => e.card === n.card);
		if (!e || e.used) return c();
		let t = j(e.card, e.flipped);
		if (!t.input.length && !t.output.length) return c();
		let r = z(o, n.pay, t.input);
		if (!r || n.outputs.length !== t.output.length || n.outputs.some((e, n) => t.output[n] !== "?" && !t.output[n].includes(e))) return { code: "games.whirlingwitchcraft.errIngredients" };
		o.bench = r.bench, o.pool = r.pool, n.outputs.forEach((e) => o.pool[e]++), e.used = !0, e.card === 103 && (o.tableau = o.tableau.filter((e) => e.card !== 103), o.roleActive = !1), a.last = {
			kind: "brew",
			rid: o.rid,
			card: e.card
		}, s.push({
			kind: "brew",
			rid: o.rid,
			data: {
				card: e.card,
				pay: n.pay,
				outputs: n.outputs
			}
		});
	} else if (n.type === "scholar") {
		if (a.phase !== "brew" || o.ready || o.role !== "scholar" || o.scholarUsed) return c();
		let e = z({
			...o,
			books: []
		}, n.pay, ["m", "m"]);
		if (!e) return c();
		o.bench = e.bench, o.pool = e.pool, o.books.push(n.ingredient), o.scholarUsed = !0, s.push({
			kind: "arcana",
			rid: o.rid,
			data: {
				arcana: "book",
				ingredients: [n.ingredient]
			}
		});
	} else if (n.type === "finish") {
		if (a.phase !== "brew" || o.ready) return c();
		if (o.role === "allTrades" && y.every((e) => o.pool[e] > 0) && n.bonus) {
			if (!o.pool[n.bonus]) return c();
			o.pool[n.bonus]--, o.circle[n.bonus]++;
		} else if (n.bonus) return c();
		o.ready = !0, a.players.every((e) => e.ready) && (a.phase = "pass", a.transfer = 0);
	}
	return {
		state: a,
		fx: s
	};
}
function ye(e, t) {
	let n = e.selected[t];
	return {
		public: {
			round: e.round,
			phase: e.phase,
			players: e.players,
			deckCount: e.deck.length,
			last: e.last
		},
		private: {
			hand: e.hands[t] ?? [],
			roleChoices: e.choices[t] ?? [],
			selected: n ? {
				card: n.card,
				flipped: n.flipped
			} : null
		}
	};
}
var be = {
	meta: v,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ie,
		publicView: se,
		privateView: ce,
		config: P
	},
	setup: fe,
	reduce: ve,
	viewFor: ye,
	status: (e) => e.phase === "done" ? {
		phase: e.phase,
		...he(e)
	} : { phase: e.phase },
	nextTickIn: (e) => e.phase === "reveal" ? F.reveal : e.phase === "pass" ? F.pass : e.phase === "check" ? F.check : null
}, xe = {
	h: "games.whirlingwitchcraft.h",
	m: "games.whirlingwitchcraft.m",
	r: "games.whirlingwitchcraft.r",
	s: "games.whirlingwitchcraft.s",
	t: "games.whirlingwitchcraft.t",
	potion: "games.whirlingwitchcraft.potion",
	raven: "games.whirlingwitchcraft.raven",
	book: "games.whirlingwitchcraft.book",
	initiate: "games.whirlingwitchcraft.initiate",
	fey: "games.whirlingwitchcraft.fey",
	clairvoyant: "games.whirlingwitchcraft.clairvoyant",
	daredevil: "games.whirlingwitchcraft.daredevil",
	frog: "games.whirlingwitchcraft.frog",
	hidden: "games.whirlingwitchcraft.hidden",
	potionBrewer: "games.whirlingwitchcraft.potionBrewer",
	scholar: "games.whirlingwitchcraft.scholar",
	spider: "games.whirlingwitchcraft.spider",
	trickster: "games.whirlingwitchcraft.trickster",
	uncontrolled: "games.whirlingwitchcraft.uncontrolled",
	whirlwind: "games.whirlingwitchcraft.whirlwind",
	allTrades: "games.whirlingwitchcraft.allTrades",
	initiateHelp: "games.whirlingwitchcraft.initiateHelp",
	feyHelp: "games.whirlingwitchcraft.feyHelp",
	clairvoyantHelp: "games.whirlingwitchcraft.clairvoyantHelp",
	daredevilHelp: "games.whirlingwitchcraft.daredevilHelp",
	frogHelp: "games.whirlingwitchcraft.frogHelp",
	hiddenHelp: "games.whirlingwitchcraft.hiddenHelp",
	potionBrewerHelp: "games.whirlingwitchcraft.potionBrewerHelp",
	scholarHelp: "games.whirlingwitchcraft.scholarHelp",
	spiderHelp: "games.whirlingwitchcraft.spiderHelp",
	tricksterHelp: "games.whirlingwitchcraft.tricksterHelp",
	uncontrolledHelp: "games.whirlingwitchcraft.uncontrolledHelp",
	whirlwindHelp: "games.whirlingwitchcraft.whirlwindHelp",
	allTradesHelp: "games.whirlingwitchcraft.allTradesHelp"
};
function H() {
	let e = a();
	return (t) => e(xe[t]);
}
var Se = (e) => `${e}Help`, Ce = {
	h: "#161324",
	m: "#fff8dc",
	r: "#e24b55",
	s: "#36a5d4",
	t: "#88ba37"
};
function U({ type: e, size: t = 28 }) {
	let n = e === "m" ? "#746343" : e === "h" ? "#ddd1e9" : "#241435";
	return /* @__PURE__ */ f("svg", {
		"aria-hidden": "true",
		width: t,
		height: t,
		viewBox: "0 0 48 48",
		className: "ww-ingredient",
		fill: Ce[e],
		stroke: n,
		strokeWidth: "1.5",
		strokeLinejoin: "round",
		children: [
			e === "h" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", { d: "M6 6 16 12Q24 7 32 12L42 6 39 20Q40 31 24 43 8 31 9 20Z" }),
				/* @__PURE__ */ d("path", {
					d: "M14 23Q24 13 34 23 24 33 14 23Z",
					fill: "#eee7f3"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "24",
					cy: "23",
					r: "4",
					fill: "#171221"
				}),
				/* @__PURE__ */ d("path", {
					d: "m19 33 5 4 5-4",
					fill: "none"
				})
			] }),
			e === "m" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", {
					d: "M24 17Q8 18 8 5 19 2 24 15 27 2 40 5 37 17 24 17",
					fill: "#82a36c"
				}),
				/* @__PURE__ */ d("path", { d: "M24 16Q12 18 13 31L6 41 18 37 23 45 28 36 41 40 34 30Q35 19 24 16Z" }),
				/* @__PURE__ */ d("path", {
					d: "m17 25 4 2m6-2 4 2m-9 6h6",
					stroke: "#635741"
				})
			] }),
			e === "r" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", { d: "m15 22-4 20h9l3-20m12-3 3 23h-8l-2-23" }),
				/* @__PURE__ */ d("path", { d: "M2 25Q5 5 19 8 31 12 29 24Z" }),
				/* @__PURE__ */ d("path", { d: "M20 19Q25 1 36 7 46 13 45 22Z" }),
				/* @__PURE__ */ d("path", {
					d: "m9 18 3-3m5 4 4-2m10-5 3-1m4 6 3 1",
					stroke: "#fff1c8",
					strokeWidth: "3"
				})
			] }),
			e === "s" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", {
					d: "m17 19-8-9-4 1m13 12-13-5-3 4m16 5-14 6 1 5m15-7L9 43m22-24 8-9 4 1m-13 12 13-5 3 4m-16 5 14 6-1 5m-15-7 11 12",
					fill: "none",
					stroke: Ce.s,
					strokeWidth: "3"
				}),
				/* @__PURE__ */ d("ellipse", {
					cx: "24",
					cy: "28",
					rx: "9",
					ry: "12"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "24",
					cy: "15",
					r: "6"
				}),
				/* @__PURE__ */ d("path", {
					d: "M21 15h1m4 0h1",
					stroke: "white",
					strokeWidth: "3"
				})
			] }),
			e === "t" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", { d: "m13 25-9 7 4 10 11-5h10l11 5 4-10-9-7" }),
				/* @__PURE__ */ d("ellipse", {
					cx: "24",
					cy: "27",
					rx: "13",
					ry: "12"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "15",
					cy: "15",
					r: "7"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "33",
					cy: "15",
					r: "7"
				}),
				/* @__PURE__ */ d("ellipse", {
					cx: "24",
					cy: "30",
					rx: "8",
					ry: "6",
					fill: "#d2df6e"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "15",
					cy: "15",
					r: "2.5",
					fill: "#201930"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "33",
					cy: "15",
					r: "2.5",
					fill: "#201930"
				})
			] })
		]
	});
}
function W({ type: e, size: t = 25 }) {
	let n = e === "potion" ? "#ef80b7" : e === "raven" ? "#b7bac5" : "#9ee2d0";
	return /* @__PURE__ */ f("svg", {
		width: t,
		height: t,
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ d("circle", {
			cx: "20",
			cy: "20",
			r: "18",
			fill: n,
			stroke: "#32203e",
			strokeWidth: "2"
		}), /* @__PURE__ */ d("g", {
			fill: "#2a1538",
			stroke: "#2a1538",
			strokeWidth: "1.8",
			strokeLinejoin: "round",
			children: e === "potion" ? /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", { d: "M7 20h26Q32 33 20 33 8 33 7 20" }),
				/* @__PURE__ */ d("path", {
					d: "m27 22 6-12",
					fill: "none",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "15",
					cy: "11",
					r: "2"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "21",
					cy: "15",
					r: "1"
				})
			] }) : e === "raven" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", { d: "M9 25Q5 8 24 10L35 17 24 17Q30 29 17 32L20 25Z" }), /* @__PURE__ */ d("circle", {
				cx: "20",
				cy: "13",
				r: "1.2",
				fill: n
			})] }) : /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", {
				d: "M5 12Q12 7 20 12 28 7 35 12V30Q28 25 20 30 12 25 5 30Z",
				fill: "none"
			}), /* @__PURE__ */ d("path", {
				d: "M20 12v18m-10-13 6 2m9-3 5-1m-5 7 5-1",
				fill: "none"
			})] })
		})]
	});
}
function we({ color: e }) {
	return /* @__PURE__ */ f("svg", {
		width: "28",
		height: "28",
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ d("circle", {
				cx: "16",
				cy: "16",
				r: "15",
				fill: e
			}),
			/* @__PURE__ */ d("circle", {
				cx: "16",
				cy: "12",
				r: "5",
				fill: "#fff5d7"
			}),
			/* @__PURE__ */ d("path", {
				d: "M6 27Q7 17 16 18 25 17 26 27",
				fill: "#fff5d7"
			})
		]
	});
}
function Te({ slot: e, small: t = !1 }) {
	let n = H();
	if (e === "?") return /* @__PURE__ */ d("span", {
		className: "ww-wild",
		children: "?"
	});
	let r = y.filter((t) => e.includes(t));
	return /* @__PURE__ */ d("span", {
		className: `ww-slot${r.length > 1 ? " ww-hybrid" : ""}`,
		"aria-label": r.map((e) => n(e)).join(" / "),
		children: r.map((e) => /* @__PURE__ */ d(U, {
			type: e,
			size: t ? 23 : r.length > 1 ? 27 : 34
		}, e))
	});
}
function G({ card: e, flipped: t = !1 }) {
	let n = a(), r = A(e), i = j(e, t);
	return /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ f("div", {
		className: "ww-card-top",
		children: [/* @__PURE__ */ d("span", {
			className: "ww-card-arcanas",
			children: r.arcana.map((e, t) => /* @__PURE__ */ d(W, {
				type: e,
				size: 24
			}, t))
		}), /* @__PURE__ */ d("span", {
			title: n("games.whirlingwitchcraft.initiative", { n: e }),
			children: e <= 60 ? String(e).padStart(2, "0") : "✦"
		})]
	}), /* @__PURE__ */ f("div", {
		className: "ww-scroll",
		children: [
			/* @__PURE__ */ d("div", {
				className: "ww-formula-input",
				children: i.input.length ? i.input.map((e, t) => /* @__PURE__ */ d(Te, { slot: e }, t)) : /* @__PURE__ */ d("span", {
					className: "ww-empty-formula",
					children: n("games.whirlingwitchcraft.free")
				})
			}),
			/* @__PURE__ */ d("div", {
				className: "ww-direction",
				"aria-hidden": !0,
				children: r.reversible ? "↕" : "↓"
			}),
			/* @__PURE__ */ d("div", {
				className: "ww-formula-output",
				children: i.output.length ? i.output.map((e, t) => /* @__PURE__ */ d(Te, { slot: e }, t)) : /* @__PURE__ */ d("span", {
					className: "ww-empty-formula",
					children: n("games.whirlingwitchcraft.noOutput")
				})
			})
		]
	})] });
}
function Ee({ card: e, flipped: t, used: n, available: r, onClick: i, anchor: o, selected: s }) {
	let c = a(), { ref: u } = l(o);
	return /* @__PURE__ */ f("button", {
		ref: u,
		type: "button",
		className: `ww-card${n ? " ww-card-used" : ""}${r ? " ww-available" : ""}${s ? " ww-card-selected" : ""}`,
		onClick: i,
		"aria-label": `${c("games.whirlingwitchcraft.recipe")} ${e <= 60 ? e : "✦"}`,
		"aria-pressed": s || void 0,
		children: [
			/* @__PURE__ */ d(G, {
				card: e,
				flipped: t
			}),
			n && /* @__PURE__ */ f("span", {
				className: "ww-used-label",
				children: ["✓ ", c("games.whirlingwitchcraft.used")]
			}),
			r && /* @__PURE__ */ d("svg", {
				className: "ww-card-ants",
				"aria-hidden": "true",
				viewBox: "0 0 155 214",
				preserveAspectRatio: "none",
				children: /* @__PURE__ */ d("rect", {
					x: "3",
					y: "3",
					width: "149",
					height: "208",
					rx: "9"
				})
			})
		]
	});
}
function K({ stock: e, size: t = 22 }) {
	let n = H();
	return /* @__PURE__ */ d("span", {
		className: "ww-stock-line",
		children: y.map((r) => /* @__PURE__ */ f("span", {
			title: n(r),
			children: [/* @__PURE__ */ d(U, {
				type: r,
				size: t
			}), /* @__PURE__ */ d("b", { children: e[r] })]
		}, r))
	});
}
function De({ stock: e, rid: t }) {
	let n = a(), r = H(), { ref: i } = l(`bench:${t}`);
	return /* @__PURE__ */ f("div", {
		className: "ww-workbench",
		ref: i,
		children: [/* @__PURE__ */ d("h2", { children: n("games.whirlingwitchcraft.bench") }), y.map((t) => /* @__PURE__ */ f("div", {
			className: "ww-bench-row",
			children: [
				/* @__PURE__ */ f("span", {
					className: "ww-bench-label",
					children: [/* @__PURE__ */ d(U, {
						type: t,
						size: 31
					}), /* @__PURE__ */ d("span", { children: r(t) })]
				}),
				/* @__PURE__ */ d("div", {
					className: "ww-capacity",
					children: Array.from({ length: b[t] }, (n, r) => /* @__PURE__ */ d("i", {
						className: r < e[t] ? "ww-filled" : "",
						style: { "--ingredient": Ce[t] }
					}, r))
				}),
				/* @__PURE__ */ f("b", { children: [e[t], /* @__PURE__ */ f("small", { children: ["/", b[t]] })] })
			]
		}, t))]
	});
}
function q({ name: e, children: t, className: n }) {
	let { ref: r } = l(e);
	return /* @__PURE__ */ d("div", {
		ref: r,
		className: n,
		children: t
	});
}
//#endregion
//#region src/games/whirlingwitchcraft/view-player.tsx
function J({ title: e, children: t, close: n }) {
	let i = a();
	return r(/* @__PURE__ */ d("div", {
		className: "ww-modal-shade",
		onClick: n,
		children: /* @__PURE__ */ f("section", {
			className: "ww-modal",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ f("header", { children: [/* @__PURE__ */ d("h2", { children: e }), /* @__PURE__ */ d("button", {
				className: "ww-button ww-quiet",
				onClick: n,
				children: i("games.whirlingwitchcraft.cancel")
			})] }), /* @__PURE__ */ d("div", {
				className: "ww-modal-scroll",
				children: t
			})]
		})
	}), document.body);
}
function Y({ choose: e, disabled: t, selected: n }) {
	let r = H();
	return /* @__PURE__ */ d("div", {
		className: "ww-ingredient-picker",
		children: y.map((i) => /* @__PURE__ */ f("button", {
			className: "ww-ingredient-choice",
			disabled: t?.(i),
			onClick: () => e(i),
			"aria-label": r(i),
			children: [
				/* @__PURE__ */ d(U, {
					type: i,
					size: 37
				}),
				/* @__PURE__ */ d("span", { children: r(i) }),
				n?.filter((e) => e === i).length ? /* @__PURE__ */ d("b", { children: n.filter((e) => e === i).length }) : null
			]
		}, i))
	});
}
function Oe({ player: e, arcana: t, send: r }) {
	let i = a(), o = H(), [s, c] = n([]), l = i(t === "potion" ? "games.whirlingwitchcraft.potionPrompt" : t === "raven" ? "games.whirlingwitchcraft.ravenPrompt" : t === "book" ? "games.whirlingwitchcraft.bookPrompt" : t === "brewer" ? "games.whirlingwitchcraft.brewerPrompt" : "games.whirlingwitchcraft.wildPrompt"), u = (e) => {
		r({
			type: "arcana",
			arcana: t,
			ingredients: e
		}), c([]);
	};
	return /* @__PURE__ */ f("div", {
		className: "ww-arcana-panel",
		children: [
			/* @__PURE__ */ d("p", { children: l }),
			t === "wild" ? /* @__PURE__ */ d("div", {
				className: "ww-arcana-choices",
				children: w.map((e) => /* @__PURE__ */ f("button", {
					className: "ww-button",
					onClick: () => r({
						type: "arcana",
						arcana: t,
						ingredients: [],
						effect: e
					}),
					children: [/* @__PURE__ */ d(W, {
						type: e,
						size: 40
					}), o(e)]
				}, e))
			}) : /* @__PURE__ */ d(Y, {
				selected: t === "raven" ? s : void 0,
				disabled: (n) => t === "brewer" ? e.bench[n] < 1 : t === "raven" ? s.length >= 2 || s.filter((e) => e === n).length >= e.bench[n] : !1,
				choose: (e) => t === "raven" ? c([...s, e]) : u([e])
			}),
			t === "raven" && /* @__PURE__ */ f("div", {
				className: "ww-inline-actions",
				children: [/* @__PURE__ */ d("button", {
					className: "ww-button",
					onClick: () => u(s),
					children: i("games.whirlingwitchcraft.confirm")
				}), /* @__PURE__ */ d("button", {
					className: "ww-button ww-quiet",
					onClick: () => c([]),
					children: i("games.whirlingwitchcraft.cancel")
				})]
			}),
			t !== "wild" && /* @__PURE__ */ d("button", {
				className: "ww-text-button",
				onClick: () => u([]),
				children: i("games.whirlingwitchcraft.skip")
			})
		]
	});
}
function ke({ p: e, card: t, close: r, send: i }) {
	let o = a(), s = H(), c = e.tableau.find((e) => e.card === t), l = j(t, c.flipped), [u, p] = n(() => B(e, l.input) ?? l.input.map((e) => ({
		type: y.find((t) => e.includes(t)) ?? "h",
		source: "bench"
	}))), [m, h] = n(() => l.output.map((e) => y.find((t) => e.includes(t)) ?? "h")), g = z(e, u, l.input) !== null;
	return /* @__PURE__ */ f(J, {
		title: `${o("games.whirlingwitchcraft.recipe")} ${t <= 60 ? t : "✦"}`,
		close: r,
		children: [
			/* @__PURE__ */ d("div", {
				className: "ww-dialog-recipe ww-card",
				children: /* @__PURE__ */ d(G, {
					card: t,
					flipped: c.flipped
				})
			}),
			/* @__PURE__ */ d("h3", { children: o("games.whirlingwitchcraft.input") }),
			l.input.length === 0 && /* @__PURE__ */ d("p", { children: o("games.whirlingwitchcraft.free") }),
			l.input.map((t, n) => /* @__PURE__ */ f("div", {
				className: "ww-pay-row",
				children: [/* @__PURE__ */ d(Te, { slot: t }), /* @__PURE__ */ d("div", {
					className: "ww-pay-options",
					children: y.filter((e) => t === "?" || t.includes(e)).map((t) => /* @__PURE__ */ f("div", {
						className: "ww-payment-type",
						children: [/* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(U, {
							type: t,
							size: 23
						}), s(t)] }), /* @__PURE__ */ d("div", { children: [
							"bench",
							"pool",
							"book"
						].filter((n) => n !== "book" || e.books.includes(t)).map((r) => /* @__PURE__ */ f("button", {
							className: `ww-source${u[n]?.type === t && u[n]?.source === r ? " ww-chosen" : ""}`,
							disabled: r !== "book" && !e[r][t],
							onClick: () => p(u.map((e, i) => i === n ? {
								type: t,
								source: r
							} : e)),
							children: [
								o(r === "bench" ? "games.whirlingwitchcraft.fromBench" : r === "pool" ? "games.whirlingwitchcraft.fromPool" : "games.whirlingwitchcraft.supply"),
								" ",
								r === "book" ? "∞" : e[r][t]
							]
						}, r)) })]
					}, t))
				})]
			}, n)),
			/* @__PURE__ */ d("h3", { children: o("games.whirlingwitchcraft.output") }),
			/* @__PURE__ */ d("div", {
				className: "ww-output-choices",
				children: l.output.map((e, t) => /* @__PURE__ */ d("div", {
					className: "ww-output-choice",
					children: y.filter((t) => e === "?" || e.includes(t)).map((e) => /* @__PURE__ */ d("button", {
						className: `ww-resource-button${m[t] === e ? " ww-chosen" : ""}`,
						"aria-label": s(e),
						"aria-pressed": m[t] === e,
						onClick: () => h(m.map((n, r) => r === t ? e : n)),
						children: /* @__PURE__ */ d(U, {
							type: e,
							size: 32
						})
					}, e))
				}, t))
			}),
			/* @__PURE__ */ d("button", {
				className: "ww-button ww-primary ww-brew-confirm",
				disabled: !g,
				onClick: () => {
					i({
						type: "brew",
						card: t,
						pay: u,
						outputs: m
					}), r();
				},
				children: o("games.whirlingwitchcraft.brew")
			})
		]
	});
}
function Ae(e) {
	return /* @__PURE__ */ d(Me, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function je({ p: e, close: t, send: r }) {
	let i = a(), [o, s] = n(() => V(e) ?? [{
		type: "m",
		source: "bench"
	}, {
		type: "m",
		source: "bench"
	}]), c = z({
		...e,
		books: []
	}, o, ["m", "m"]) !== null;
	return /* @__PURE__ */ f(J, {
		title: i("games.whirlingwitchcraft.scholarAction"),
		close: t,
		children: [
			/* @__PURE__ */ d("h3", { children: i("games.whirlingwitchcraft.source") }),
			o.map((t, n) => /* @__PURE__ */ f("div", {
				className: "ww-pay-row",
				children: [/* @__PURE__ */ d(U, {
					type: "m",
					size: 32
				}), /* @__PURE__ */ d("div", {
					className: "ww-pay-options",
					children: ["bench", "pool"].map((r) => /* @__PURE__ */ f("button", {
						disabled: e[r].m === 0,
						className: `ww-source${t.source === r ? " ww-chosen" : ""}`,
						onClick: () => s(o.map((e, t) => t === n ? {
							type: "m",
							source: r
						} : e)),
						children: [
							i(r === "bench" ? "games.whirlingwitchcraft.fromBench" : "games.whirlingwitchcraft.fromPool"),
							" ",
							e[r].m
						]
					}, r))
				})]
			}, n)),
			/* @__PURE__ */ d("p", { children: i("games.whirlingwitchcraft.bookPrompt") }),
			/* @__PURE__ */ d(Y, {
				disabled: () => !c,
				choose: (e) => {
					r({
						type: "scholar",
						pay: o,
						ingredient: e
					}), t();
				}
			})
		]
	});
}
function Me({ pub: e, priv: t, readOnly: r = !1, ...l }) {
	let p = a(), m = H(), h = i((e) => e.locale), [g, _] = n(null), [v, b] = n(null), [x, C] = n(null), ee = x?.owner === l.myRid ? x.kind : null, T = e.players.findIndex((e) => e.rid === l.myRid), E = e.players[T] ?? e.players[0], te = e.players[(T + 1 + e.players.length) % e.players.length], D = e.players[(T - 1 + e.players.length) % e.players.length], O = (t) => {
		let n = l.members.find((e) => e.rid === t);
		return n ? c(n, h) : p(o[(e.players.findIndex((e) => e.rid === t) + o.length) % o.length].nameKey);
	}, k = (e) => {
		r || l.send(e);
	}, A = g?.owner === l.myRid && !r && (g.mode === "hand" && e.phase === "select" && !E.picked && t?.hand.includes(g.card) || g.mode === "brew" && e.phase === "brew" && !E.ready && E.tableau.some((e) => e.card === g.card && !e.used)) ? g : null, M = [
		"wild",
		"book",
		"brewer",
		"potion",
		"raven"
	].find((e) => E.pending[e] > 0), N = !r && (e.phase === "select" && !E.picked || e.phase === "brew" && !E.ready || e.phase === "arcana" && M), P = e.phase === "roles" ? p("games.whirlingwitchcraft.rolePrompt") : e.phase === "select" ? E.picked ? p("games.whirlingwitchcraft.waiting") : p("games.whirlingwitchcraft.selectPrompt") : e.phase === "arcana" ? p(M ? "games.whirlingwitchcraft.arcanaPrompt" : "games.whirlingwitchcraft.waiting") : e.phase === "brew" ? E.ready ? p("games.whirlingwitchcraft.waiting") : p("games.whirlingwitchcraft.brewing") : p("games.whirlingwitchcraft.resolving"), re = () => {
		E.role === "allTrades" && y.every((e) => E.pool[e] > 0) ? C({
			owner: l.myRid,
			kind: "bonus"
		}) : k({ type: "finish" });
	}, ie = /* @__PURE__ */ f("div", {
		className: "ww-banner",
		children: [/* @__PURE__ */ f("div", {
			className: "ww-round-line",
			children: [/* @__PURE__ */ d("span", { children: p("games.whirlingwitchcraft.round", { n: e.round }) }), /* @__PURE__ */ d("strong", { children: r ? p("games.whirlingwitchcraft.review") : P })]
		}), /* @__PURE__ */ d("div", {
			className: "ww-players",
			children: e.players.map((t, n) => {
				let r = o[(l.members.find((e) => e.rid === t.rid)?.colorIndex ?? n) % o.length].hex;
				return /* @__PURE__ */ d(q, {
					name: `seat:${t.rid}`,
					children: /* @__PURE__ */ f("button", {
						className: `ww-player${t.rid === l.myRid ? " ww-self" : ""}`,
						onClick: () => b(t.rid),
						children: [
							/* @__PURE__ */ d(we, { color: r }),
							/* @__PURE__ */ d("span", { children: O(t.rid) }),
							/* @__PURE__ */ f("b", { children: [S(t.circle), /* @__PURE__ */ d("small", { children: "/5" })] }),
							/* @__PURE__ */ d("i", { children: t.ready || t.picked && e.phase === "select" ? "✓" : "·" })
						]
					})
				}, t.rid);
			})
		})]
	}), ae = /* @__PURE__ */ f("div", {
		className: "ww-actions",
		children: [/* @__PURE__ */ d("span", { children: N && e.phase === "brew" ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("span", {
				className: "ww-small-orb",
				children: "✦"
			}),
			" ",
			p("games.whirlingwitchcraft.count", { n: S(E.pool) })
		] }) : P }), e.phase === "brew" && !E.ready && !r ? /* @__PURE__ */ d("button", {
			className: "ww-button ww-primary",
			onClick: re,
			children: p("games.whirlingwitchcraft.done")
		}) : /* @__PURE__ */ d("span", {
			className: "ww-action-orb",
			"aria-hidden": !0,
			children: "✧"
		})]
	});
	return /* @__PURE__ */ f(s, {
		adaptive: !0,
		className: "ww-root",
		banner: ie,
		actions: ae,
		actionsHeight: "h-[58px]",
		children: [
			/* @__PURE__ */ f("div", {
				className: "ww-table-layout",
				children: [/* @__PURE__ */ f("aside", {
					className: "ww-laboratory",
					children: [
						/* @__PURE__ */ f("div", {
							className: "ww-role-line",
							children: [/* @__PURE__ */ d("span", {
								className: "ww-sigil",
								"aria-hidden": !0,
								children: "☽"
							}), /* @__PURE__ */ f("div", { children: [
								/* @__PURE__ */ d("strong", { children: E.role ? m(E.role) : p("games.whirlingwitchcraft.rolePrompt") }),
								E.role && /* @__PURE__ */ d("p", { children: m(Se(E.role)) }),
								!E.roleActive && E.role && /* @__PURE__ */ d("small", { children: p("games.whirlingwitchcraft.roleSpent") })
							] })]
						}),
						/* @__PURE__ */ d(De, {
							rid: E.rid,
							stock: E.bench
						}),
						/* @__PURE__ */ f(q, {
							name: `pool:${E.rid}`,
							className: "ww-cauldron",
							children: [
								/* @__PURE__ */ d("div", { className: "ww-cauldron-rim" }),
								/* @__PURE__ */ d("h2", { children: p("games.whirlingwitchcraft.cauldron") }),
								/* @__PURE__ */ d(K, {
									stock: E.pool,
									size: 29
								}),
								/* @__PURE__ */ d("p", { children: p("games.whirlingwitchcraft.right", { name: O(te.rid) }) })
							]
						}),
						/* @__PURE__ */ d("div", {
							className: "ww-arcana-track",
							children: w.map((e) => /* @__PURE__ */ f("div", { children: [
								/* @__PURE__ */ d(W, {
									type: e,
									size: 29
								}),
								/* @__PURE__ */ d("span", { children: m(e) }),
								/* @__PURE__ */ d("b", { children: E.arcana[e] }),
								E.books.length && e === "book" ? /* @__PURE__ */ d("span", {
									className: "ww-book-types",
									children: E.books.map((e, t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(U, {
										type: e,
										size: 20
									}), "∞"] }, t))
								}) : null
							] }, e))
						}),
						/* @__PURE__ */ f(q, {
							name: `circle:${E.rid}`,
							className: "ww-circle",
							children: [/* @__PURE__ */ d("span", {
								className: "ww-circle-seal",
								"aria-hidden": !0,
								children: "✷"
							}), /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("h2", { children: [
								p("games.whirlingwitchcraft.circle"),
								" ",
								/* @__PURE__ */ f("b", { children: [S(E.circle), " / 5"] })
							] }), /* @__PURE__ */ d(K, { stock: E.circle })] })]
						}),
						/* @__PURE__ */ d("p", {
							className: "ww-neighbor",
							children: p("games.whirlingwitchcraft.left", { name: O(D.rid) })
						})
					]
				}), /* @__PURE__ */ f("main", {
					className: "ww-recipe-area",
					children: [
						e.phase === "roles" && !E.role && t && /* @__PURE__ */ f("section", {
							className: "ww-role-choice",
							children: [/* @__PURE__ */ d("h2", { children: p("games.whirlingwitchcraft.rolePrompt") }), /* @__PURE__ */ d("div", { children: t.roleChoices.map((e) => /* @__PURE__ */ f("button", {
								className: "ww-personality",
								onClick: () => k({
									type: "role",
									role: e
								}),
								children: [
									/* @__PURE__ */ d("span", {
										className: "ww-personality-seal",
										"aria-hidden": !0,
										children: "✧"
									}),
									/* @__PURE__ */ d("h3", { children: m(e) }),
									/* @__PURE__ */ d("p", { children: m(Se(e)) }),
									/* @__PURE__ */ d(K, { stock: ne[e] })
								]
							}, e)) })]
						}),
						e.phase === "select" && !E.prepared && !r && /* @__PURE__ */ f("section", {
							className: "ww-decision",
							children: [/* @__PURE__ */ d("p", { children: p("games.whirlingwitchcraft.preparePrompt") }), /* @__PURE__ */ d(Y, { choose: (e) => k({
								type: "prepare",
								ingredient: e
							}) })]
						}),
						e.phase === "arcana" && M && !r && /* @__PURE__ */ d("section", {
							className: "ww-decision",
							children: /* @__PURE__ */ d(Oe, {
								player: E,
								arcana: M,
								send: k
							}, `${E.rid}:${M}`)
						}),
						e.phase === "select" && t && !r && /* @__PURE__ */ f("section", {
							className: "ww-hand-section",
							children: [/* @__PURE__ */ f("div", {
								className: "ww-section-title",
								children: [
									/* @__PURE__ */ d("h2", { children: p("games.whirlingwitchcraft.hand") }),
									E.role === "initiate" && E.roleActive && !E.picked && /* @__PURE__ */ d("button", {
										className: "ww-text-button",
										onClick: () => k({ type: "refresh" }),
										children: p("games.whirlingwitchcraft.refresh")
									}),
									E.role === "daredevil" && !E.picked && /* @__PURE__ */ d("button", {
										className: "ww-text-button",
										onClick: () => k({
											type: "select",
											card: t.hand[0],
											flipped: !1,
											random: !0
										}),
										children: p("games.whirlingwitchcraft.random")
									})
								]
							}), /* @__PURE__ */ d(q, {
								name: `hand:${E.rid}`,
								className: "ww-hand",
								children: t.hand.map((e) => /* @__PURE__ */ f("div", {
									className: "ww-hand-card",
									children: [/* @__PURE__ */ d(Ee, {
										card: e,
										flipped: A?.card === e && A.flipped,
										anchor: `hand:${E.rid}:${e}`,
										available: !E.picked && E.prepared,
										selected: A?.card === e,
										onClick: () => {
											!E.picked && E.prepared && _({
												owner: l.myRid,
												card: e,
												flipped: !1,
												mode: "hand"
											});
										}
									}), A?.card === e && A.mode === "hand" && /* @__PURE__ */ f("div", {
										className: "ww-card-tools",
										children: [R(E, e) && /* @__PURE__ */ d("button", {
											className: "ww-button ww-quiet",
											onClick: () => _({
												...A,
												flipped: !A.flipped
											}),
											children: p("games.whirlingwitchcraft.rotate")
										}), /* @__PURE__ */ d("button", {
											className: "ww-button ww-primary",
											onClick: () => {
												k({
													type: "select",
													card: e,
													flipped: A.flipped,
													random: !1
												}), _(null);
											},
											children: p("games.whirlingwitchcraft.play")
										})]
									})]
								}, e))
							})]
						}),
						/* @__PURE__ */ f("section", {
							className: "ww-tableau-section",
							children: [/* @__PURE__ */ f("div", {
								className: "ww-section-title",
								children: [/* @__PURE__ */ f("h2", { children: [
									p("games.whirlingwitchcraft.recipes"),
									" ",
									/* @__PURE__ */ d("span", { children: E.tableau.length })
								] }), e.phase === "brew" && E.role === "scholar" && !E.scholarUsed && !E.ready && !r && /* @__PURE__ */ d("button", {
									className: "ww-text-button",
									disabled: !V(E),
									onClick: () => C({
										owner: l.myRid,
										kind: "scholar"
									}),
									children: p("games.whirlingwitchcraft.scholarAction")
								})]
							}), /* @__PURE__ */ d(q, {
								name: `tableau:${E.rid}`,
								className: "ww-tableau",
								children: E.tableau.map((t) => {
									let n = j(t.card, t.flipped), i = !r && e.phase === "brew" && !E.ready && !t.used && n.input.length + n.output.length > 0 && B(E, n.input) !== null;
									return /* @__PURE__ */ d(Ee, {
										card: t.card,
										flipped: t.flipped,
										used: t.used,
										available: i,
										anchor: `recipe:${E.rid}:${t.card}`,
										onClick: () => {
											i && _({
												owner: l.myRid,
												card: t.card,
												flipped: t.flipped,
												mode: "brew"
											});
										}
									}, t.card);
								})
							})]
						})
					]
				})]
			}),
			A?.mode === "brew" && /* @__PURE__ */ d(ke, {
				p: E,
				card: A.card,
				send: k,
				close: () => _(null)
			}, `${E.rid}:${A.card}`),
			ee === "scholar" && E.role === "scholar" && !r && e.phase === "brew" && !E.ready && /* @__PURE__ */ d(je, {
				p: E,
				send: k,
				close: () => C(null)
			}, E.rid),
			ee === "bonus" && E.role === "allTrades" && !r && e.phase === "brew" && !E.ready && /* @__PURE__ */ f(J, {
				title: p("games.whirlingwitchcraft.allTradesPrompt"),
				close: () => C(null),
				children: [/* @__PURE__ */ d(Y, {
					disabled: (e) => E.pool[e] < 1,
					choose: (e) => {
						k({
							type: "finish",
							bonus: e
						}), C(null);
					}
				}), /* @__PURE__ */ d("button", {
					className: "ww-text-button",
					onClick: () => {
						k({ type: "finish" }), C(null);
					},
					children: p("games.whirlingwitchcraft.skip")
				})]
			}),
			v && /* @__PURE__ */ d(J, {
				title: O(v),
				close: () => b(null),
				children: (() => {
					let t = e.players.find((e) => e.rid === v);
					return /* @__PURE__ */ f(u, { children: [
						/* @__PURE__ */ d("p", { children: t.role && m(t.role) }),
						t.role && /* @__PURE__ */ d("p", { children: m(Se(t.role)) }),
						/* @__PURE__ */ d(De, {
							rid: `inspect:${t.rid}`,
							stock: t.bench
						}),
						/* @__PURE__ */ d("h3", { children: p("games.whirlingwitchcraft.cauldron") }),
						/* @__PURE__ */ d(K, { stock: t.pool }),
						/* @__PURE__ */ d("h3", { children: p("games.whirlingwitchcraft.circle") }),
						/* @__PURE__ */ d(K, { stock: t.circle }),
						/* @__PURE__ */ d("div", {
							className: "ww-tableau ww-inspect-recipes",
							children: t.tableau.map((e) => /* @__PURE__ */ d(Ee, {
								card: e.card,
								flipped: e.flipped,
								used: e.used,
								anchor: `inspect:${t.rid}:${e.card}`
							}, e.card))
						})
					] });
				})()
			})
		]
	});
}
//#endregion
//#region src/games/whirlingwitchcraft/bot.ts
var Ne = {
	depth: 2,
	overflow: 5,
	production: .45,
	clear: .35,
	future: .1
}, Pe = {
	...Ne,
	depth: 0
};
function Fe(e) {
	let t = [[]];
	for (let n of e) t = t.flatMap((e) => y.filter((e) => n === "?" || n.includes(e)).map((t) => [...e, t]));
	return t;
}
function Ie(e, t) {
	let n = [];
	for (let r of Fe(t)) for (let i of [[
		"book",
		"bench",
		"pool"
	], [
		"book",
		"pool",
		"bench"
	]]) {
		let a = structuredClone(e), o = [];
		for (let e of r) {
			let t = i.find((t) => t === "book" ? a.books.includes(e) : a[t][e] > 0);
			if (!t) break;
			o.push({
				source: t,
				type: e
			}), t !== "book" && a[t][e]--;
		}
		o.length === t.length && !n.some((e) => JSON.stringify(e) === JSON.stringify(o)) && n.push(o);
	}
	return n;
}
function Le(e) {
	let t = [];
	for (let n of e.tableau) {
		if (n.used) continue;
		let r = j(n.card, n.flipped);
		if (r.input.length || r.output.length) for (let i of Ie(e, r.input)) for (let a of Fe(r.output)) {
			let o = z(e, i, r.input);
			a.forEach((e) => o.pool[e]++), o.tableau.find((e) => e.card === n.card).used = !0, t.push({
				action: {
					type: "brew",
					card: n.card,
					pay: i,
					outputs: a
				},
				player: o
			});
		}
	}
	return t;
}
function X(e, t, n) {
	return y.reduce((r, i) => r + Math.max(0, e.pool[i] + t.bench[i] - b[i]) * n.overflow + e.pool[i] * n.production * (1 + t.bench[i] / b[i]) - e.bench[i] * n.clear * (e.bench[i] / b[i]), 0) + e.tableau.filter((t) => !t.used && B(e, j(t.card, t.flipped).input)).length * n.future;
}
function Re(e, t, n) {
	let r = X(e, t, n), i = Le(e).map((e) => ({
		...e,
		value: X(e.player, t, n)
	})).sort((e, t) => t.value - e.value), a = i[0], o = r;
	if (!a) return null;
	for (let e of i.slice(0, n.depth ? 8 : 1)) {
		let r = e.value;
		if (n.depth) {
			let i = Le(e.player).map((e) => ({
				...e,
				value: X(e.player, t, n)
			})).sort((e, t) => t.value - e.value);
			if (i[0] && (r = Math.max(r, i[0].value)), n.depth > 1) for (let e of i.slice(0, 3)) for (let i of Le(e.player)) r = Math.max(r, X(i.player, t, n));
		}
		r > o + .001 && (a = e, o = r);
	}
	return o > r + .001 ? {
		action: a.action,
		value: o
	} : null;
}
function ze(e, t, n, r) {
	return [...y].sort((i, a) => {
		let o = (i) => {
			let a = structuredClone(e);
			return r === "book" ? a.books.push(i) : a.pool[i]++, Math.max(X(a, t, n), Re(a, t, {
				...n,
				depth: 0
			})?.value ?? -Infinity);
		};
		return o(a) - o(i);
	})[0];
}
function Be(e = Ne) {
	return (t, n) => {
		let r = t.public, i = t.private, a = r.players.findIndex((e) => e.rid === n.rid);
		if (a < 0 || !i) return null;
		let o = r.players[a], s = r.players[(a + 1) % r.players.length], c = n.difficulty === "weak" ? Pe : e;
		if (r.phase === "roles") {
			if (o.role || !i.roleChoices.length) return null;
			let e = [
				"fey",
				"spider",
				"scholar",
				"whirlwind",
				"daredevil",
				"potionBrewer",
				"trickster",
				"frog",
				"allTrades",
				"clairvoyant",
				"hidden",
				"uncontrolled"
			];
			return { action: {
				type: "role",
				role: [...i.roleChoices].sort((t, n) => e.indexOf(t) - e.indexOf(n))[0]
			} };
		}
		if (r.phase === "select") {
			if (o.picked) return null;
			if (!o.prepared) return { action: {
				type: "prepare",
				ingredient: [...y].sort((e, t) => {
					let n = (e) => 3 - Math.max(0, o.bench[e] + 3 - b[e]) * 10 + o.tableau.reduce((t, n) => t + j(n.card, n.flipped).input.filter((t) => t.includes(e)).length, 0);
					return n(t) - n(e);
				})[0]
			} };
			let e = null, t = -Infinity;
			for (let n of i.hand) for (let r of R(o, n) ? [!1, !0] : [!1]) {
				let i = structuredClone(o), a = A(n);
				i.tableau.push({
					card: n,
					flipped: r,
					used: !1
				});
				let l = Re(i, s, c), u = a.arcana.reduce((e, t) => e + (o.arcana[t] % 2 ? .8 : .25), 0), d = j(n, r).input.reduce((e, t) => e + Math.max(...y.filter((e) => t.includes(e)).map((e) => o.bench[e] / b[e])), 0), f = (l?.value ?? X(i, s, c)) + u + d * .15;
				f > t && (t = f, e = {
					type: "select",
					card: n,
					flipped: r,
					random: !1
				});
			}
			return e ? { action: e } : null;
		}
		if (r.phase === "arcana") {
			if (o.pending.wild) return { action: {
				type: "arcana",
				arcana: "wild",
				ingredients: [],
				effect: "book"
			} };
			if (o.pending.book) return { action: {
				type: "arcana",
				arcana: "book",
				ingredients: [ze(o, s, c, "book")]
			} };
			if (o.pending.brewer) return { action: {
				type: "arcana",
				arcana: "brewer",
				ingredients: y.filter((e) => o.bench[e] > 0).sort((e, t) => s.bench[t] / b[t] - s.bench[e] / b[e]).slice(0, 1)
			} };
			if (o.pending.potion) return { action: {
				type: "arcana",
				arcana: "potion",
				ingredients: [ze(o, s, c, "pool")]
			} };
			if (o.pending.raven) {
				let e = { ...o.bench }, t = [];
				for (let n = 0; n < 2; n++) {
					let n = [...y].sort((t, n) => e[n] / b[n] - e[t] / b[t])[0];
					if (e[n] <= 0) break;
					e[n]--, t.push(n);
				}
				return { action: {
					type: "arcana",
					arcana: "raven",
					ingredients: t
				} };
			}
			return null;
		}
		if (r.phase !== "brew" || o.ready) return null;
		if (o.role === "scholar" && !o.scholarUsed) {
			let e = V(o);
			if (e) return { action: {
				type: "scholar",
				pay: e,
				ingredient: ze(o, s, c, "book")
			} };
		}
		let l = Re(o, s, c);
		if (l) return { action: l.action };
		let u = o.role === "allTrades" && y.every((e) => o.pool[e] > 0) ? [...y].sort((e, t) => +(o.circle[e] > 0) - (o.circle[t] > 0) || s.bench[e] / b[e] - s.bench[t] / b[t])[0] : void 0;
		return { action: {
			type: "finish",
			...u ? { bonus: u } : {}
		} };
	};
}
var Ve = Be(), Z = (e, t = 34) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - t) / 2,
	w: t,
	h: t
}), Q = (e, t, n) => e.anchor(`${n}:${t}`) ?? e.anchor(`seat:${t}`);
function $(e) {
	return /* @__PURE__ */ d("span", {
		className: "ww-fx-token",
		children: /* @__PURE__ */ d(U, {
			type: e,
			size: 28
		})
	});
}
var He = {
	deal(e, t) {
		let n = t.anchor(`hand:${t.myRid}`), r = t.anchor(`seat:${t.myRid}`);
		return !n || !r ? null : {
			ms: 350,
			node: /* @__PURE__ */ d(m, {
				from: Z(r, 70),
				to: Z(n, 70),
				ms: 350,
				children: /* @__PURE__ */ d("div", {
					className: "ww-fx-back",
					children: "☽"
				})
			})
		};
	},
	select(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 300,
			node: /* @__PURE__ */ d(h, {
				at: n,
				ms: 300
			})
		} : null;
	},
	refresh(e, t) {
		let n = e.rid ? Q(t, e.rid, "hand") : null;
		return n ? {
			ms: 350,
			node: /* @__PURE__ */ d(h, {
				at: n,
				ms: 350
			})
		} : null;
	},
	reveal(e, t) {
		let { cards: n } = e.data, r = [], i = n.map((e) => {
			let n = t.anchor(`recipe:${e.rid}:${e.card}`), i = t.anchor(`seat:${e.rid}`);
			return !n || !i ? null : (r.push(`recipe:${e.rid}:${e.card}`), /* @__PURE__ */ d(m, {
				from: {
					...Z(i, n.w),
					h: n.h
				},
				to: n,
				ms: F.reveal,
				children: /* @__PURE__ */ d("div", {
					className: "ww-card ww-fx-card",
					style: {
						width: n.w,
						height: n.h
					},
					children: /* @__PURE__ */ d(G, {
						card: e.card,
						flipped: e.flipped
					})
				})
			}, e.rid));
		});
		return {
			ms: F.reveal,
			node: i,
			hide: r
		};
	},
	brew(e, t) {
		if (!e.rid) return null;
		let n = e.data, r = t.anchor(`recipe:${e.rid}:${n.card}`) ?? Q(t, e.rid, "tableau"), i = Q(t, e.rid, "pool");
		if (!r || !i) return null;
		let a = F.brew * .45;
		return {
			ms: F.brew,
			node: /* @__PURE__ */ f(u, { children: [n.pay.map((n, i) => {
				let o = Q(t, e.rid, n.source === "bench" ? "bench" : n.source === "pool" ? "pool" : "seat");
				return o ? /* @__PURE__ */ d(m, {
					from: Z(o),
					to: Z(r),
					ms: a,
					children: $(n.type)
				}, `in${i}`) : null;
			}), n.outputs.map((e, t) => /* @__PURE__ */ d(m, {
				from: Z(r),
				to: Z(i),
				ms: F.brew - a,
				delay: a,
				children: $(e)
			}, `out${t}`))] })
		};
	},
	arcana(e, t) {
		if (!e.rid) return null;
		let { arcana: n, ingredients: r } = e.data, i = Q(t, e.rid, "pool"), a = Q(t, e.rid, "bench"), o = t.anchor(`seat:${e.rid}`);
		return !i || !a || !o ? null : {
			ms: 420,
			node: /* @__PURE__ */ f(u, { children: [r.map((e, t) => /* @__PURE__ */ d(m, {
				from: Z(n === "raven" || n === "brewer" ? a : o),
				to: Z(n === "raven" ? o : n === "book" ? a : i),
				ms: 420,
				children: $(e)
			}, t)), n === "book" && /* @__PURE__ */ d(p, {
				at: a,
				ms: 420,
				children: /* @__PURE__ */ d(W, {
					type: "book",
					size: 32
				})
			})] })
		};
	},
	gain(e, t) {
		if (!e.rid) return null;
		let n = Q(t, e.rid, "bench"), r = t.anchor(`seat:${e.rid}`), i = e.data;
		return n && r ? {
			ms: 400,
			node: /* @__PURE__ */ d(m, {
				from: Z(r),
				to: Z(n),
				ms: 400,
				children: $(i.type)
			})
		} : null;
	},
	pass(e, t) {
		if (!e.rid) return null;
		let n = e.data, r = Q(t, e.rid, "pool"), i = Q(t, n.target, "bench"), a = Q(t, e.rid, "circle");
		return !r || !i || !a ? null : {
			ms: F.pass,
			node: /* @__PURE__ */ f(u, { children: [y.filter((e) => n.sent[e]).map((e) => /* @__PURE__ */ d(m, {
				from: Z(r),
				to: Z(i),
				ms: 430,
				children: /* @__PURE__ */ f("span", {
					className: "ww-fx-label",
					children: [/* @__PURE__ */ d(U, {
						type: e,
						size: 26
					}), n.sent[e]]
				})
			}, e)), y.filter((e) => n.overflow[e]).map((e) => /* @__PURE__ */ d(m, {
				from: Z(i),
				to: Z(a),
				delay: 430,
				ms: F.pass - 430,
				children: /* @__PURE__ */ f("span", {
					className: "ww-fx-label",
					children: [/* @__PURE__ */ d(U, {
						type: e,
						size: 26
					}), n.overflow[e]]
				})
			}, `over${e}`))] })
		};
	},
	victory(e, t) {
		return {
			ms: 650,
			node: e.data.winners.map((e) => {
				let n = t.anchor(`seat:${e}`);
				return n ? /* @__PURE__ */ d(p, {
					at: n,
					ms: 650,
					children: /* @__PURE__ */ d("span", {
						className: "ww-fx-label",
						children: "✷"
					})
				}, e) : null;
			})
		};
	}
};
//#endregion
//#region src/games/whirlingwitchcraft/game-over.tsx
function Ue(e) {
	let t = a(), r = e.public, s = i((e) => e.locale), [l, u] = n(!0), p = (n) => {
		let i = e.members.find((e) => e.rid === n);
		return i ? c(i, s) : t(o[(r.players.findIndex((e) => e.rid === n) + o.length) % o.length].nameKey);
	}, m = e.result.ranking.map((e) => r.players.find((t) => t.rid === e));
	return /* @__PURE__ */ f("div", {
		className: "ww-over",
		children: [
			/* @__PURE__ */ d("div", {
				className: "ww-over-table",
				inert: l,
				children: /* @__PURE__ */ d(Me, {
					public: r,
					pub: r,
					priv: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {},
					readOnly: !0
				})
			}),
			/* @__PURE__ */ f("section", {
				className: "ww-over-sheet",
				hidden: !l,
				"aria-label": t("games.whirlingwitchcraft.result"),
				children: [
					/* @__PURE__ */ f("header", {
						className: "ww-over-heading",
						children: [/* @__PURE__ */ f("div", { children: [
							/* @__PURE__ */ d("p", { children: t("games.whirlingwitchcraft.name") }),
							/* @__PURE__ */ d("h1", { children: t("games.whirlingwitchcraft.result") }),
							/* @__PURE__ */ d("p", { children: e.result.winner.length > 1 ? t("games.whirlingwitchcraft.jointVictory") : t("games.whirlingwitchcraft.victory", { name: p(e.result.winner[0]) }) })
						] }), /* @__PURE__ */ d("span", {
							"aria-hidden": !0,
							children: "✷"
						})]
					}),
					/* @__PURE__ */ d("div", {
						className: "ww-score-scroll",
						children: /* @__PURE__ */ f("table", {
							className: "ww-score-table",
							children: [/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: t("games.whirlingwitchcraft.round", { n: r.round }) }), m.map((t) => /* @__PURE__ */ d("th", {
								className: e.result.winner.includes(t.rid) ? "ww-score-winner" : "",
								children: /* @__PURE__ */ f("div", {
									className: "ww-score-player",
									children: [
										/* @__PURE__ */ d(we, { color: o[(e.members.find((e) => e.rid === t.rid)?.colorIndex ?? r.players.indexOf(t)) % o.length].hex }),
										/* @__PURE__ */ d("strong", { children: p(t.rid) }),
										e.result.winner.includes(t.rid) && /* @__PURE__ */ d("span", {
											"aria-hidden": !0,
											children: "★"
										})
									]
								})
							}, t.rid))] }) }), /* @__PURE__ */ f("tbody", { children: [
								/* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: t("games.whirlingwitchcraft.finalScore") }), m.map((e) => /* @__PURE__ */ d("td", {
									className: "ww-score-total",
									children: S(e.circle)
								}, e.rid))] }),
								/* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: t("games.whirlingwitchcraft.finalVariety") }), m.map((e) => /* @__PURE__ */ d("td", { children: C(e.circle) }, e.rid))] }),
								/* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: t("games.whirlingwitchcraft.finalBench") }), m.map((e) => /* @__PURE__ */ d("td", { children: S(e.bench) }, e.rid))] })
							] })]
						})
					}),
					/* @__PURE__ */ f("div", {
						className: "ww-over-buttons",
						children: [
							/* @__PURE__ */ d("button", {
								className: "ww-button ww-quiet",
								onClick: () => u(!1),
								children: t("games.whirlingwitchcraft.review")
							}),
							e.onPlayAgain && /* @__PURE__ */ d("button", {
								className: "ww-button ww-primary",
								onClick: () => {
									window.confirm(t("games.whirlingwitchcraft.confirmAgain")) && e.onPlayAgain?.();
								},
								children: t("session.result.playAgain")
							}),
							e.onBackToLobby && /* @__PURE__ */ d("button", {
								className: "ww-button ww-quiet",
								onClick: () => {
									window.confirm(t("games.whirlingwitchcraft.confirmLobby")) && e.onBackToLobby?.();
								},
								children: t("session.result.backToLobby")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ d("p", { children: t("session.result.waitHost") })
						]
					})
				]
			}),
			!l && /* @__PURE__ */ d("button", {
				className: "ww-button ww-primary ww-over-restore",
				onClick: () => u(!0),
				children: t("games.whirlingwitchcraft.showResult")
			})
		]
	});
}
//#endregion
//#region src/games/whirlingwitchcraft/options.tsx
function We({ value: e, onChange: t }) {
	let n = a(), r = P.parse(e ?? {});
	return /* @__PURE__ */ d(g, {
		title: n("games.whirlingwitchcraft.roleOptions"),
		children: /* @__PURE__ */ d(_, {
			checked: r.personalities,
			onChange: () => t({
				...r,
				personalities: !r.personalities
			}),
			label: n("games.whirlingwitchcraft.roleOptions"),
			hint: n("games.whirlingwitchcraft.roleOptionsHelp")
		})
	});
}
//#endregion
//#region src/games/whirlingwitchcraft/guide.tsx
function Ge() {
	let e = a(), t = H();
	return /* @__PURE__ */ f("section", {
		className: "ww-guide",
		children: [
			/* @__PURE__ */ d("h3", { children: e("games.whirlingwitchcraft.guideTitle") }),
			/* @__PURE__ */ d("div", {
				className: "ww-guide-types",
				children: y.map((n) => /* @__PURE__ */ f("span", { children: [
					/* @__PURE__ */ d(U, {
						type: n,
						size: 32
					}),
					/* @__PURE__ */ d("strong", { children: t(n) }),
					/* @__PURE__ */ d("span", { children: e("games.whirlingwitchcraft.guideCapacity", { n: b[n] }) })
				] }, n))
			}),
			/* @__PURE__ */ d("div", {
				className: "ww-guide-arcanas",
				children: w.map((e) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(W, {
					type: e,
					size: 32
				}), t(e)] }, e))
			}),
			/* @__PURE__ */ f("div", {
				className: "ww-guide-card",
				children: [/* @__PURE__ */ d("div", {
					className: "ww-card",
					children: /* @__PURE__ */ d(G, { card: 19 })
				}), /* @__PURE__ */ d("p", { children: e("games.whirlingwitchcraft.guideHybrid") })]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/whirlingwitchcraft/entry.tsx
var Ke = {
	definition: be,
	View: Ae,
	bot: Ve,
	fx: He,
	OverView: Ue,
	Options: We,
	Guide: Ge,
	locales: {
		zh: {
			name: "毒逗魔药师",
			desc: "将原料炼成魔药，传给右邻，让对手的工作台满溢。",
			rules: "游戏目标：\n每位玩家扮演一名魔药师。用配方将原料转化为新的原料，再把产出传给右侧玩家。对方工作台放不下的原料进入你的巫师之环。结算时，至少一人的巫师之环有 5 份原料，游戏便结束。\n\n准备游戏：\n每人有一张工作台、一个魔药锅和 4 张私密配方手牌。工作台最多容纳 3 份阴影之心、4 份曼德拉草，以及蘑菇、蜘蛛和蟾蜍各 9 份。公共供应不受原料数量限制。\n· 初次游戏使用学徒人物，每人从 1 份曼德拉草及蘑菇、蜘蛛、蟾蜍各 4 份开始。\n· 开启人物能力后，每人从随机发到的 2 张人物中选择 1 张。按人物卡取得起始原料，并使用其特殊能力或专属配方。\n\n学习阶段：\n· 所有人同时从手牌暗选 1 张配方。即使本轮无法使用，也必须选择。\n· 带双向箭头的配方可以在打出时旋转，交换输入与产出。揭示后不能再旋转，人物能力另有说明时除外。\n· 所有人选定后一起揭示，将新配方加入各自的配方阵列。配方会保留到以后的轮次。\n\n奥术效果：\n新配方上的魔药、渡鸦和魔法书图示分别增加对应奥术计数。某类计数每到达或越过一个偶数，本轮可使用一次该类效果。一次增加多个图示时，按越过的偶数次数计算。效果可以放弃，但不能留到下一轮。\n· 魔药：从公共供应取任意 1 份原料，放入自己的魔药锅。它可以继续用于本轮配方。\n· 渡鸦：从自己的工作台移除至多 2 份原料，放回公共供应；两份可以同类或不同类。\n· 魔法书：选择一种原料。本轮支付配方输入时，可以直接从公共供应取该类原料，不受次数限制。\n\n炼制阶段：\n所有玩家可以按自己选择的顺序使用配方，每张配方每轮最多使用一次，也可以不使用。\n· 先填满配方的所有输入槽。原料可以取自工作台、之前配方的产出，或本轮魔法书允许使用的公共供应。可以分别选择每份原料的来源。\n· 支付完整输入后，从公共供应取得所有产出。产出保留在魔药锅中，可用来支付下一张配方；未使用的产出将在本轮结束时传出。已支付的原料不会回到工作台。\n· 一个槽里同时出现两种原料时，只需要选择其中一种，数量仍为 1 份。每次使用都可重新选择。没有输入的配方也可以选择使用或不用。\n· 完成想用的配方后，点击“完成炼制”。工作台上未使用的原料继续保留，魔药锅中的剩余产出全部传出。\n通常同时炼制。若互相等待对方选择而必须确定顺序，按本轮新配方的先攻值从小到大决定；先攻值显示在牌面。\n\n传递与胜负：\n· 所有人完成炼制后，将魔药锅传给右侧玩家。接收者把原料放到自己的工作台，先填满对应容量，放不下的部分进入生产者的巫师之环。\n· 全部魔药锅结算后，若至少一人的巫师之环有 5 份原料，比较所有达到条件的玩家：先比较环中原料总数，较多者获胜；仍相同则比较原料种类，较多者获胜；再相同则比较工作台余料，较少者获胜；最后仍相同则共同获胜。\n· 若尚未结束，将剩余手牌全部传给左侧玩家，再从牌库补至各自手牌上限，开始下一轮。通常上限为 4 张。\n\n人物能力：\n· 学徒：选择配方前，可以弃置人物及全部手牌，重新抽取 4 张。整局只能使用一次。\n· 仙灵祝福：每轮可使用一次无输入配方，产出 1 份曼德拉草和 1 份蟾蜍。\n· 先知：手牌上限为 5 张。\n· 冒险者：选择配方时可以改为随机打出一张，并额外触发任意一种奥术效果。\n· 蟾蜍密语者：初始魔法书计数为 1。每轮可用 3 份蟾蜍，产出任意 1 份原料。\n· 隐藏力量：可用五类原料各 1 份，产出任意 3 份原料；使用后弃置这张专属配方。\n· 魔药酿造师：揭示新配方时，每有一个魔药图示，可以将工作台上的任意 1 份原料放入魔药锅。\n· 魔法书学者：每轮炼制时，可以支付 2 份曼德拉草，额外获得一次魔法书效果。原料必须来自工作台或已有产出。\n· 蜘蛛召唤师：每轮可用 2 份曼德拉草，产出 5 份蜘蛛。\n· 捣蛋鬼：专属配方最初用 2 份蘑菇产出 2 份蟾蜍；每次传完手牌后必须旋转，下一轮改用 2 份蟾蜍产出 2 份蘑菇，交替进行。\n· 失控之力：每轮选择配方之前，必须选择一种原料，将该类 3 份原料放上工作台；超出容量的部分进入左侧玩家的巫师之环。另有每轮一次的专属配方，用 1 份阴影之心产出曼德拉草和蘑菇各 1 份。\n· 旋风：打出任何配方时都可以旋转，包括原本只有单向箭头的牌；揭示后仍不能再旋转。\n· 全能魔药师：完成炼制时，如果魔药锅里五类原料都有，可以选择其中 1 份直接移入自己的巫师之环，其余照常传递；也可以放弃本次效果。\n人物能力改变一般规则时，以人物能力为准。",
			h: "阴影之心",
			m: "曼德拉草",
			r: "蘑菇",
			s: "蜘蛛",
			t: "蟾蜍",
			potion: "魔药",
			raven: "渡鸦",
			book: "魔法书",
			wild: "任选奥术",
			brewer: "移动工作台原料",
			initiate: "学徒",
			fey: "仙灵祝福",
			clairvoyant: "先知",
			daredevil: "冒险者",
			frog: "蟾蜍密语者",
			hidden: "隐藏力量",
			potionBrewer: "魔药酿造师",
			scholar: "魔法书学者",
			spider: "蜘蛛召唤师",
			trickster: "捣蛋鬼",
			uncontrolled: "失控之力",
			whirlwind: "旋风",
			allTrades: "全能魔药师",
			initiateHelp: "选择配方前，可弃置人物和全部手牌，重新抽取 4 张。",
			feyHelp: "每轮可免费产出曼德拉草和蟾蜍各 1 份。",
			clairvoyantHelp: "你的手牌上限为 5 张。",
			daredevilHelp: "随机打出配方时，额外触发任意一种奥术。",
			frogHelp: "用 3 份蟾蜍产出任意 1 份原料。",
			hiddenHelp: "五类原料各 1 份，换取任意 3 份原料，使用后弃置。",
			potionBrewerHelp: "新配方每有一个魔药图示，可将工作台的 1 份原料放入锅。",
			scholarHelp: "每轮可支付 2 份曼德拉草，获得魔法书效果。",
			spiderHelp: "用 2 份曼德拉草产出 5 份蜘蛛。",
			tricksterHelp: "专属配方每轮在蘑菇与蟾蜍之间交替方向。",
			uncontrolledHelp: "每轮选牌前，必须向工作台加入同类 3 份原料。",
			whirlwindHelp: "打出任何配方时都可以旋转。",
			allTradesHelp: "完成炼制时，若锅中五类原料都有，可将其中 1 份移入巫师之环。",
			round: "第 {{n}} 轮",
			selectPrompt: "选择一张配方",
			waiting: "等待其他魔药师",
			brewing: "使用配方炼制原料",
			resolving: "魔药锅传递中",
			rolePrompt: "选择你的人物",
			preparePrompt: "选择一种原料，向工作台加入 3 份。",
			bench: "工作台",
			cauldron: "魔药锅",
			circle: "巫师之环",
			recipes: "已学配方",
			hand: "手牌",
			recipe: "配方",
			initiative: "先攻值 {{n}}",
			input: "输入",
			output: "产出",
			any: "任意原料",
			or: "或",
			free: "无需原料",
			noOutput: "仅获得奥术",
			rotate: "旋转配方",
			play: "打出配方",
			brew: "炼制",
			used: "本轮已使用",
			done: "完成炼制",
			cancel: "取消",
			confirm: "确认",
			skip: "放弃本次效果",
			source: "原料来源",
			supply: "奥术供应",
			fromBench: "工作台",
			fromPool: "魔药锅",
			refresh: "使用学徒能力换牌",
			random: "随机打出配方",
			scholarAction: "支付 2 份曼德拉草研习",
			arcanaPrompt: "结算本轮奥术",
			ravenPrompt: "选择要从工作台移除的原料，最多 2 份。",
			potionPrompt: "选择 1 份原料放入魔药锅。",
			bookPrompt: "选择本轮可无限用于配方输入的一种原料。",
			brewerPrompt: "选择工作台上的 1 份原料放入魔药锅。",
			wildPrompt: "选择要触发的奥术。",
			allTradesPrompt: "选择魔药锅中的 1 份原料，移入巫师之环。",
			right: "魔药传给 {{name}}",
			left: "接收 {{name}} 的魔药",
			score: "{{n}} / 5",
			count: "{{n}} 份",
			roleOptions: "人物能力",
			roleOptionsHelp: "关闭时，所有人使用学徒；开启时，各自从两张人物中选一张。",
			roleSpent: "能力已弃置",
			result: "炼金之夜结束",
			victory: "{{name}} 获胜",
			jointVictory: "共同获胜",
			finalScore: "环中原料",
			finalVariety: "环中种类",
			finalBench: "工作台余料",
			review: "回看工作台",
			showResult: "查看胜负",
			finalRecipes: "最终配方",
			confirmAgain: "确认重新开始？",
			confirmLobby: "确认返回大厅？",
			guideTitle: "原料与配方图示",
			guideCapacity: "容量 {{n}} 份",
			guideHybrid: "这个配方需要曼德拉草和蟾蜍各 1 份，产出曼德拉草 1 份，再从蘑菇和蜘蛛中选择 1 份。斜分图示始终只代表 1 份原料。",
			errPhase: "现在无法执行该行动。",
			errAction: "该行动已不可用，请检查当前选择。",
			errIngredients: "原料不足，或输入与产出不符合配方。"
		},
		en: {
			name: "Whirling Witchcraft",
			desc: "Brew ingredients, pass them to your right, and overflow your rival’s workbench.",
			rules: "Goal:\nUse recipes to transform ingredients and pass your output to the player on your right. Ingredients they cannot fit on their workbench go into your Witch’s Circle. The game ends after passing all cauldrons if any Circle contains at least 5 ingredients.\n\nSetup:\nEach player has a workbench, a cauldron, and 4 secret recipe cards. A workbench holds 3 Hearts of Shadow, 4 Mandrakes, and 9 each of Mushrooms, Spiders, and Toads. The general supply is unlimited.\n· For your first game, everyone is an Initiate, starting with 1 Mandrake and 4 each of Mushrooms, Spiders, and Toads.\n· With personalities enabled, choose 1 of 2 randomly dealt personalities. Take its starting ingredients and use its power or personal recipe.\n\nStudy phase:\n· Everyone secretly chooses 1 recipe from their hand, even if they cannot use it this round.\n· A recipe with a two-way direction symbol may be rotated when played, swapping its inputs and outputs. Once revealed, it cannot rotate again unless a personality says otherwise.\n· Reveal all chosen recipes together and add them to your tableau. They remain available in later rounds.\n\nArcana:\nAdd the Potion, Raven, and Book symbols on your new recipe to your corresponding arcana totals. Each time a total reaches or passes an even number, you may use that effect this round. If you cross more than one even number, gain that many uses. You may decline an effect, but cannot save it for a later round.\n· Potion: Take any 1 ingredient from the supply and put it in your cauldron. You may use it as an input this round.\n· Raven: Remove up to 2 ingredients from your workbench and return them to the supply. They may be the same or different types.\n· Book: Choose an ingredient type. For this round, you may take that type directly from the supply whenever filling recipe inputs, without a limit.\n\nBrewing phase:\nUse your recipes in any order. Each recipe may be used once per round, and using a recipe is optional.\n· Fill every input space with a matching ingredient. Each ingredient may come from your workbench, previous recipe output in your cauldron, or a type supplied by an active Book effect. Choose the source for each input separately.\n· After paying all inputs, take every output from the supply. Outputs stay in your cauldron and may be used by subsequent recipes. Paid ingredients do not return to your workbench.\n· A hybrid space showing two types requires only 1 ingredient of either pictured type. Choose again each time you use the recipe. Recipes without inputs are also optional.\n· Select “Finish brewing” when you have used all the recipes you wish. Unused workbench ingredients remain there; all remaining output will be passed.\nBrewing is normally simultaneous. If players are waiting for each other’s choices and timing matters, resolve decisions in increasing initiative order, using the newly played recipe values.\n\nPassing and victory:\n· After everyone finishes brewing, pass cauldrons to the right. Fill the recipient’s corresponding workbench spaces. Ingredients that do not fit go into the producing player’s Witch’s Circle.\n· After all cauldrons resolve, if any Circle has at least 5 ingredients, compare qualifying players: the most Circle ingredients wins; then the most different Circle types; then the fewest total ingredients on the workbench. If still tied, share victory.\n· Otherwise, pass all remaining hand cards to the left, draw up to your hand limit, normally 4, and begin another round.\n\nPersonalities:\n· Initiate: Before choosing a recipe, discard your personality and entire hand, then draw 4 cards. This is usable once per game.\n· Blessed by Fey: Once per round, produce 1 Mandrake and 1 Toad without inputs.\n· Clairvoyant: Your hand limit is 5 cards.\n· Daredevil: You may play a random recipe from your hand and additionally trigger any one arcana effect.\n· Frog Whisperer: Start with 1 Book on your arcana track. Once per round, turn 3 Toads into any 1 ingredient.\n· Hidden Power: Turn 1 ingredient of each of the five types into any 3 ingredients. Discard this personal recipe after use.\n· Potion Brewer: When revealing your recipe, for each Potion symbol on it, you may move 1 ingredient of any type from your workbench to your cauldron.\n· Spellbook Scholar: Once per round during brewing, spend 2 Mandrakes to trigger a Book effect. The ingredients must come from your workbench or existing output.\n· Spider Summoner: Once per round, turn 2 Mandrakes into 5 Spiders.\n· Trickster: Your personal recipe initially turns 2 Mushrooms into 2 Toads. Rotate it after passing hands, so it turns 2 Toads into 2 Mushrooms next round, alternating each round.\n· Uncontrolled Powers: Before playing a recipe each round, you must add 3 ingredients of a single chosen type to your workbench. Any excess goes into the Circle of the player on your left. Your personal recipe also turns 1 Heart of Shadow into 1 Mandrake and 1 Mushroom once per round.\n· Whirlwind: You may rotate any recipe when playing it, including a normally one-way recipe. You still cannot rotate it after revealing it.\n· Witch of All Trades: When finishing brewing, if your cauldron contains all five ingredient types, you may move 1 ingredient of your choice from it into your Witch’s Circle before passing the rest. You may also decline this effect.\nPersonality rules take precedence over the general rules.",
			h: "Heart of Shadow",
			m: "Mandrake",
			r: "Mushroom",
			s: "Spider",
			t: "Toad",
			potion: "Potion",
			raven: "Raven",
			book: "Book",
			wild: "Any arcana",
			brewer: "Move a workbench ingredient",
			initiate: "Initiate",
			fey: "Blessed by Fey",
			clairvoyant: "Clairvoyant",
			daredevil: "Daredevil",
			frog: "Frog Whisperer",
			hidden: "Hidden Power",
			potionBrewer: "Potion Brewer",
			scholar: "Spellbook Scholar",
			spider: "Spider Summoner",
			trickster: "Trickster",
			uncontrolled: "Uncontrolled Powers",
			whirlwind: "Whirlwind",
			allTrades: "Witch of All Trades",
			initiateHelp: "Before choosing a recipe, discard this personality and your hand to draw 4 new cards.",
			feyHelp: "Each round, produce 1 Mandrake and 1 Toad for free.",
			clairvoyantHelp: "Your hand limit is 5.",
			daredevilHelp: "Play a random recipe to trigger an extra arcana of your choice.",
			frogHelp: "Turn 3 Toads into any 1 ingredient.",
			hiddenHelp: "Turn one of each ingredient into any 3, then discard this recipe.",
			potionBrewerHelp: "Each Potion symbol on a new recipe lets you move 1 workbench ingredient into your cauldron.",
			scholarHelp: "Once per round, spend 2 Mandrakes to trigger a Book effect.",
			spiderHelp: "Turn 2 Mandrakes into 5 Spiders.",
			tricksterHelp: "Your personal recipe alternates between Mushrooms and Toads each round.",
			uncontrolledHelp: "Before choosing each round, add 3 ingredients of one type to your workbench.",
			whirlwindHelp: "You may rotate any recipe when playing it.",
			allTradesHelp: "If your cauldron has all five types when finished, you may move 1 ingredient to your Circle.",
			round: "Round {{n}}",
			selectPrompt: "Choose a recipe",
			waiting: "Waiting for the other witches",
			brewing: "Brew with your recipes",
			resolving: "Passing cauldrons",
			rolePrompt: "Choose your personality",
			preparePrompt: "Choose a type and add 3 ingredients to your workbench.",
			bench: "Workbench",
			cauldron: "Cauldron",
			circle: "Witch’s Circle",
			recipes: "Your recipes",
			hand: "Hand",
			recipe: "Recipe",
			initiative: "Initiative {{n}}",
			input: "Input",
			output: "Output",
			any: "Any ingredient",
			or: "or",
			free: "No ingredients needed",
			noOutput: "Arcana only",
			rotate: "Rotate recipe",
			play: "Play recipe",
			brew: "Brew",
			used: "Used this round",
			done: "Finish brewing",
			cancel: "Cancel",
			confirm: "Confirm",
			skip: "Decline this effect",
			source: "Ingredient source",
			supply: "Arcana supply",
			fromBench: "Workbench",
			fromPool: "Cauldron",
			refresh: "Use Initiate to redraw",
			random: "Play a random recipe",
			scholarAction: "Study with 2 Mandrakes",
			arcanaPrompt: "Resolve your arcana",
			ravenPrompt: "Choose up to 2 ingredients to remove from your workbench.",
			potionPrompt: "Choose 1 ingredient to add to your cauldron.",
			bookPrompt: "Choose a type to supply unlimited recipe inputs this round.",
			brewerPrompt: "Choose 1 workbench ingredient to move to your cauldron.",
			wildPrompt: "Choose an arcana to trigger.",
			allTradesPrompt: "Move 1 cauldron ingredient into your Witch’s Circle.",
			right: "Pass to {{name}}",
			left: "Receive from {{name}}",
			score: "{{n}} / 5",
			count: "{{n}} ingredients",
			roleOptions: "Personalities",
			roleOptionsHelp: "Off: everyone is an Initiate. On: each player chooses between two personalities.",
			roleSpent: "Personality discarded",
			result: "The night’s brewing ends",
			victory: "{{name}} wins",
			jointVictory: "Shared victory",
			finalScore: "Circle ingredients",
			finalVariety: "Circle types",
			finalBench: "Workbench remaining",
			review: "Review workbenches",
			showResult: "Show result",
			finalRecipes: "Final recipes",
			confirmAgain: "Start another game?",
			confirmLobby: "Return to the lobby?",
			guideTitle: "Ingredients and recipe symbols",
			guideCapacity: "Capacity: {{n}}",
			guideHybrid: "This recipe uses 1 Mandrake and 1 Toad. It produces 1 Mandrake and your choice of 1 Mushroom or 1 Spider. A split symbol always represents just 1 ingredient.",
			errPhase: "You cannot do that now.",
			errAction: "That action is no longer available. Check your selection.",
			errIngredients: "Insufficient ingredients, or the input and output do not match the recipe."
		}
	}
};
//#endregion
export { Ke as default };
