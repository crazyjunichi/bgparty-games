import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { AVATARS as r } from "@bgparty/sdk/avatars";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { seatName as l } from "@bgparty/sdk/ui/player-strip";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { FlySprite as p, PulseBox as m } from "@bgparty/sdk/fx/primitives";
import { IconBot as h } from "@bgparty/sdk/icons";
import { OptionRadio as g, OptionSection as _, OptionSwitch as v } from "@bgparty/sdk/ui/game-options";
//#region src/games/tanglung/schema.ts
var y = t.enum([
	"rooster",
	"rabbit",
	"butterfly",
	"fish",
	"horse",
	"dragon"
]), b = t.int().min(0).max(15), x = t.object({
	mode: t.enum([
		"duel",
		"solo",
		"coop"
	]).catch("duel"),
	shuffled: t.boolean().catch(!1),
	timed: t.boolean().catch(!1)
}).default({
	mode: "duel",
	shuffled: !1,
	timed: !1
}), S = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		to: b
	}),
	t.object({
		type: t.literal("move"),
		to: b,
		style: t.enum(["rooster", "lantern"])
	}),
	t.object({
		type: t.literal("fan"),
		to: b
	}),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), C = t.enum([
	"light",
	"bump",
	"trapped",
	"time"
]), w = t.object({
	config: x,
	phase: t.enum([
		"place",
		"play",
		"fan",
		"round",
		"done"
	]),
	cells: t.array(t.object({
		kind: y.nullable(),
		lit: t.boolean(),
		gone: t.boolean()
	})).length(16),
	players: t.array(t.object({
		rid: t.string(),
		pos: b.nullable(),
		hits: t.int().min(0).max(2),
		wins: t.int().nonnegative()
	})),
	turn: t.string(),
	fan: b.nullable(),
	round: t.int().min(1),
	moves: t.int().nonnegative(),
	left: t.int().nonnegative(),
	history: t.array(t.object({
		winner: t.string(),
		reason: C
	})),
	outcome: t.object({
		winner: t.string().nullable(),
		reason: C
	}).nullable()
}), T = t.object({}), E = {
	id: "tanglung",
	tier: "alpha",
	mechanics: ["grid-movement"],
	interactionTags: [],
	nameKey: "games.tanglung.name",
	descKey: "games.tanglung.desc",
	rulesKey: "games.tanglung.rules",
	icon: "🏮",
	iconImg: "games/tanglung.webp",
	rulesUrl: {
		en: "https://drive.google.com/file/d/1xiZZxVUjtcgyezYXCNnP97UHsLVFnD5u/view",
		zh: "https://drive.google.com/file/d/1IULwp0RiB1DqPUEIiUhAT6wIjbhI_UVi/view"
	},
	minPlayers: 1,
	maxPlayers: 2,
	bestPlayers: [2],
	playerRange: (e) => x.safeParse(e).data?.mode === "solo" ? {
		min: 1,
		max: 1
	} : {
		min: 2,
		max: 2
	},
	accent: "#f5c84c",
	releasedAt: "2026-11-07T01:13:00+08:00",
	search: {
		py: "deng long",
		init: "dl"
	},
	hotseat: "open",
	botDelayMs: 650
}, D = [
	"rooster",
	"rabbit",
	"butterfly",
	"fish",
	"horse",
	"dragon"
], O = [
	"rooster",
	"rooster",
	...[
		"rabbit",
		"butterfly",
		"fish",
		"horse"
	].flatMap((e) => [
		e,
		e,
		e
	]),
	"dragon",
	"dragon"
], k = (e, t) => e >= 0 && e < 4 && t >= 0 && t < 4;
function A(e, t, n, r, i) {
	if (t === n || !e[n] || e[n].gone || n === i) return !1;
	let a = Math.floor(t / 4), o = t % 4, s = Math.floor(n / 4) - a, c = n % 4 - o, l = Math.abs(s), u = Math.abs(c);
	if (r === "rooster") return l + u === 1;
	if (r === "fish") return Math.max(l, u) === 1;
	if (r === "horse") {
		if (!(l === 1 && u === 2 || l === 2 && u === 1)) return !1;
		let e = [], t = [];
		for (let t = 1; t <= l; t++) e.push((a + Math.sign(s) * t) * 4 + o);
		for (let t = 1; t < u; t++) e.push((a + s) * 4 + o + Math.sign(c) * t);
		for (let e = 1; e <= u; e++) t.push(a * 4 + o + Math.sign(c) * e);
		for (let e = 1; e < l; e++) t.push((a + Math.sign(s) * e) * 4 + o + c);
		return !e.includes(i ?? -1) || !t.includes(i ?? -1);
	}
	let d = s === 0 || c === 0, f = l === u;
	if (r === "rabbit" ? !d : r === "butterfly" ? !f : !(d || f)) return !1;
	let p = Math.max(l, u);
	for (let t = 1; t < p; t++) {
		let n = a + Math.sign(s) * t, l = o + Math.sign(c) * t;
		if (!k(n, l)) return !1;
		let u = n * 4 + l;
		if (u === i || e[u].gone && r !== "dragon") return !1;
	}
	return !0;
}
function j(e) {
	return e.cells.flatMap((t, n) => !t.gone && n !== e.fan && !e.players.some((e) => e.pos === n) ? [n] : []);
}
function M(e, t) {
	if (e.turn !== t || e.phase === "done") return [];
	if (e.phase === "round") return [{ type: "next" }];
	let n = e.players.find((e) => e.rid === t);
	if (!n) return [];
	if (e.phase === "fan") return j(e).map((e) => ({
		type: "fan",
		to: e
	}));
	let r = e.config.mode === "duel";
	if (e.phase === "place") return e.cells.flatMap((t, n) => t.kind === "rooster" && !e.players.some((e) => e.pos === n) ? [{
		type: "place",
		to: n
	}] : []);
	if (n.pos === null) return e.cells.flatMap((t, n) => !t.gone && t.lit && n !== e.fan && !e.players.some((e) => e.pos === n) ? [{
		type: "place",
		to: n
	}] : []);
	let i = n.pos, a = e.cells[i].kind;
	if (!a) return [];
	let o = [], s = r && a !== "rooster" ? ["rooster", "lantern"] : [a === "rooster" && r ? "rooster" : "lantern"];
	for (let n of s) for (let r = 0; r < 16; r++) A(e.cells, i, r, n === "rooster" ? "rooster" : a, e.fan) && (n !== "rooster" || !e.players.some((e) => e.pos === r) && j({
		cells: e.cells.map((e, t) => ({
			...e,
			gone: e.gone || t === i && a === "rooster"
		})),
		players: e.players.map((e) => e.rid === t ? {
			...e,
			pos: r
		} : e),
		fan: e.fan
	}).length) && o.push({
		type: "move",
		to: r,
		style: n
	});
	return o;
}
//#endregion
//#region src/games/tanglung/rules.ts
function N(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function P(e) {
	e.cells = (e.config.mode !== "duel" && e.config.shuffled ? N(e, O) : [
		"rooster",
		...N(e, O.filter((e) => e !== "rooster")),
		"rooster"
	]).map((t, n) => {
		let r = t === "rooster" || e.config.mode === "duel" && [
			5,
			6,
			9,
			10
		].includes(n);
		return {
			kind: t,
			lit: r,
			gone: !1,
			seen: r
		};
	}), e.players.forEach((e) => {
		e.pos = null, e.hits = 0;
	}), e.fan = null, e.phase = "place", e.outcome = null, e.deadline = null, e.left = 120, e.turn = e.players[(e.round - 1) % e.players.length].rid;
}
function F(e, t, n) {
	let r = {
		config: x.parse(e),
		phase: "place",
		cells: [],
		players: t.map((e) => ({
			rid: e,
			pos: null,
			wins: 0,
			hits: 0
		})),
		turn: t[0],
		fan: null,
		round: 1,
		moves: 0,
		left: 120,
		history: [],
		outcome: null,
		seed: n,
		cursor: 0,
		deadline: null
	};
	return P(r), { state: r };
}
function I(e) {
	return {
		public: {
			config: e.config,
			phase: e.phase,
			players: e.players,
			turn: e.turn,
			fan: e.fan,
			round: e.round,
			moves: e.moves,
			left: e.left,
			history: e.history,
			outcome: e.outcome,
			cells: e.cells.map((e) => ({
				kind: e.seen && !e.gone ? e.kind : null,
				lit: e.lit,
				gone: e.gone
			}))
		},
		private: {}
	};
}
function L(e, t, n) {
	if (e.outcome = {
		winner: t,
		reason: n
	}, e.config.mode === "duel" && t) {
		let r = e.players.find((e) => e.rid === t);
		r.wins++, e.history.push({
			winner: t,
			reason: n
		}), e.phase = r.wins >= 2 ? "done" : "round", e.turn = t;
	} else e.phase = "done";
}
function R(e) {
	if (!e.cells.some((e) => !e.gone && !e.lit)) {
		L(e, e.turn, "light");
		return;
	}
	let t = e.players.findIndex((t) => t.rid === e.turn);
	e.turn = e.players[(t + 1) % e.players.length].rid, e.phase = "play", M(I(e).public, e.turn).length || L(e, e.config.mode === "duel" ? e.players[t].rid : null, "trapped");
}
function ee(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine") return { code: "games.tanglung.errTurn" };
		if (e.config.mode === "duel" || !e.config.timed || e.phase !== "play") return { state: e };
		let r = structuredClone(e);
		return r.deadline === null && (r.deadline = t.now + 12e4), r.left = Math.max(0, Math.ceil((r.deadline - t.now) / 1e3)), r.left || L(r, null, "time"), { state: r };
	}
	if (!M(I(e).public, n.by).some((e) => e.type === t.type && (!("to" in e) || "to" in t && e.to === t.to) && (!("style" in e) || "style" in t && e.style === t.style))) return { code: "games.tanglung.errMove" };
	let r = structuredClone(e), i = [], a = r.players.find((e) => e.rid === n.by);
	if (t.type === "next") return r.round++, P(r), {
		state: r,
		fx: [{ kind: "round" }]
	};
	if (t.type === "fan") return i.push({
		kind: "fan",
		rid: n.by,
		data: {
			from: r.fan,
			to: t.to
		}
	}), r.fan = t.to, R(r), {
		state: r,
		fx: i
	};
	if (t.type === "place") {
		if (a.pos = t.to, i.push({
			kind: "move",
			rid: n.by,
			data: {
				from: null,
				to: t.to,
				seat: r.players.indexOf(a),
				hits: a.hits
			}
		}), r.phase === "place") {
			let e = r.players.find((e) => e.pos === null);
			e ? r.turn = e.rid : (r.phase = "play", r.turn = r.players[(r.round - 1) % r.players.length].rid);
		} else r.moves++, R(r);
		return {
			state: r,
			fx: i
		};
	}
	let o = a.pos, s = t.to, c = r.cells[o], l = r.cells[s], u = l.lit;
	if (a.pos = s, r.moves++, l.lit = !0, l.seen = !0, i.push({
		kind: "move",
		rid: n.by,
		data: {
			from: o,
			to: s,
			seat: r.players.indexOf(a),
			hits: a.hits
		}
	}), u || i.push({
		kind: "light",
		data: {
			to: s,
			animal: l.kind
		},
		with: !0
	}), r.config.mode === "duel") {
		(t.style === "lantern" || c.kind === "rooster") && (c.gone = !0, i.push({
			kind: "remove",
			data: {
				from: o,
				animal: c.kind
			},
			with: !0
		}));
		let e = r.players.find((e) => e.rid !== n.by && e.pos === s);
		if (e && (e.hits++, e.pos = null, i.push({
			kind: "bump",
			rid: e.rid,
			data: {
				from: s,
				seat: r.players.indexOf(e),
				hits: e.hits
			},
			with: !0
		}), e.hits >= 2)) return L(r, n.by, "bump"), {
			state: r,
			fx: i
		};
		t.style === "rooster" ? r.phase = "fan" : R(r);
	} else u && c.kind !== "rooster" && (c.lit = !1, i.push({
		kind: "dim",
		data: { to: o },
		with: !0
	})), R(r);
	return {
		state: r,
		fx: i
	};
}
function te(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.config.mode === "duel";
	return {
		phase: "done",
		winner: e.outcome?.winner ? t ? [e.outcome.winner] : e.players.map((e) => e.rid) : [],
		ranking: [...e.players].sort((e, t) => t.wins - e.wins).map((e) => e.rid),
		scores: t ? Object.fromEntries(e.players.map((e) => [e.rid, e.wins])) : void 0
	};
}
var z = {
	meta: E,
	saveCompatibility: { version: "1" },
	schemas: {
		action: S,
		publicView: w,
		privateView: T,
		config: x
	},
	setup: F,
	reduce: ee,
	viewFor: I,
	status: te,
	nextTickIn: (e) => e.config.mode !== "duel" && e.config.timed && e.phase === "play" ? e.deadline === null ? 0 : 1e3 : null
}, B = (e) => `./games/tanglung/${e}.webp`;
function V({ kind: e }) {
	return /* @__PURE__ */ d("img", {
		className: "tg-animal",
		src: B(e),
		alt: "",
		draggable: !1
	});
}
function H({ kind: e }) {
	return e === "rooster" ? /* @__PURE__ */ f("svg", {
		viewBox: "0 0 84 48",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ d("circle", {
				cx: "13",
				cy: "18",
				r: "11"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "13",
				cy: "18",
				r: "3"
			}),
			Array.from({ length: 8 }, (e, t) => /* @__PURE__ */ d("path", {
				d: "M13 7v8",
				transform: `rotate(${t * 45} 13 18)`
			}, t)),
			/* @__PURE__ */ d("path", { d: "M10 29 8 37h10l-2-8M7 40h12M30 24h10m-5-5v10" }),
			/* @__PURE__ */ d("text", {
				x: "45",
				y: "12",
				fill: "currentColor",
				stroke: "none",
				fontSize: "12",
				children: "1"
			}),
			[
				0,
				90,
				180,
				270
			].map((e) => /* @__PURE__ */ d("g", {
				transform: `rotate(${e} 64 24)`,
				children: /* @__PURE__ */ d("path", { d: "M64 24V6m-5 5 5-5 5 5" })
			}, e))
		]
	}) : /* @__PURE__ */ f("svg", {
		viewBox: "0 0 48 48",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.6",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0,
		children: [
			e === "horse" ? /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", { d: "M10 9h24v30M15 4l-5 5 5 5m14 20 5 5 5-5" }),
				/* @__PURE__ */ d("text", {
					x: "2",
					y: "30",
					fill: "currentColor",
					stroke: "none",
					fontSize: "12",
					children: "1"
				}),
				/* @__PURE__ */ d("text", {
					x: "40",
					y: "39",
					fill: "currentColor",
					stroke: "none",
					fontSize: "12",
					children: "2"
				})
			] }) : (e === "rabbit" ? [
				0,
				90,
				180,
				270
			] : e === "butterfly" ? [
				45,
				135,
				225,
				315
			] : [
				0,
				45,
				90,
				135,
				180,
				225,
				270,
				315
			]).map((t) => /* @__PURE__ */ f("g", {
				transform: `rotate(${t} 24 24)`,
				children: [/* @__PURE__ */ d("path", {
					d: e === "dragon" ? "M24 17V6" : "M24 22V6",
					strokeDasharray: e === "rabbit" || e === "butterfly" || e === "dragon" ? "4 4" : void 0
				}), /* @__PURE__ */ d("path", { d: "m19 11 5-5 5 5" })]
			}, t)),
			e === "dragon" && /* @__PURE__ */ f("g", {
				fill: "currentColor",
				stroke: "none",
				children: [Array.from({ length: 12 }, (e, t) => /* @__PURE__ */ d("ellipse", {
					cx: "24",
					cy: "20",
					rx: "2",
					ry: "3",
					transform: `rotate(${t * 30} 24 24)`
				}, t)), /* @__PURE__ */ d("circle", {
					cx: "24",
					cy: "24",
					r: "3.5"
				})]
			}),
			e === "fish" && /* @__PURE__ */ d("text", {
				x: "3",
				y: "12",
				fill: "currentColor",
				stroke: "none",
				fontSize: "11",
				children: "1"
			})
		]
	});
}
function U({ cell: e }) {
	let t = o();
	return /* @__PURE__ */ d("div", {
		className: "tg-card",
		"data-lit": e.lit,
		"data-kind": e.kind ?? "dark",
		"data-gone": e.gone,
		children: !e.gone && (e.lit && e.kind ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ f("span", {
				className: "tg-card-heading",
				children: [t(`games.tanglung.animal.${e.kind}`), /* @__PURE__ */ d(H, { kind: e.kind })]
			}),
			/* @__PURE__ */ d("span", { className: "tg-cord" }),
			/* @__PURE__ */ d(V, { kind: e.kind })
		] }) : /* @__PURE__ */ f("div", {
			className: "tg-back",
			children: [
				/* @__PURE__ */ d("span", {
					className: "tg-back-star",
					children: "✦"
				}),
				/* @__PURE__ */ d("b", { children: t("games.tanglung.name") }),
				/* @__PURE__ */ d("span", {
					className: "tg-back-animals",
					children: "TANGLUNG"
				}),
				e.kind && /* @__PURE__ */ d("small", { children: t("games.tanglung.memory", { name: t(`games.tanglung.animal.${e.kind}`) }) })
			]
		}))
	});
}
function W(e, t = 0) {
	return `box-${e === 0 ? "gold" : "blue"}${t ? "-one" : ""}`;
}
function G({ seat: e, hits: t = 0, style: n }) {
	return /* @__PURE__ */ d("img", {
		className: "tg-box",
		style: n,
		src: B(W(e, t)),
		alt: "",
		draggable: !1
	});
}
function ne({ rid: e, seat: t, hits: n, name: r }) {
	let { ref: a, hidden: o } = i(`piece:${e}`);
	return /* @__PURE__ */ f("span", {
		ref: a,
		className: "tg-piece",
		"data-seat": t,
		style: { visibility: o ? "hidden" : void 0 },
		title: r,
		children: [/* @__PURE__ */ d(G, {
			seat: t,
			hits: n
		}), /* @__PURE__ */ d("span", {
			className: "tg-piece-name",
			children: r
		})]
	});
}
function K() {
	return /* @__PURE__ */ d("img", {
		className: "tg-fan-art",
		src: B("fan"),
		alt: "",
		draggable: !1
	});
}
//#endregion
//#region src/games/tanglung/atmosphere.tsx
function re() {
	return /* @__PURE__ */ f("div", {
		className: "tg-festival",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("svg", {
				className: "tg-festival-sky",
				viewBox: "0 0 1200 800",
				preserveAspectRatio: "none",
				children: [
					/* @__PURE__ */ f("g", {
						fill: "none",
						stroke: "#e2ad6c",
						strokeWidth: "1.3",
						opacity: ".5",
						children: [/* @__PURE__ */ d("path", { d: "M-30 32Q245 205 560 5M700-10Q980 184 1230 30" }), /* @__PURE__ */ d("path", { d: "M-40 165Q110 250 255 178M950 175Q1100 252 1240 145" })]
					}),
					/* @__PURE__ */ f("g", {
						fill: "#ffe6a0",
						children: [
							/* @__PURE__ */ d("circle", {
								cx: "303",
								cy: "43",
								r: "1.8"
							}),
							/* @__PURE__ */ d("circle", {
								cx: "835",
								cy: "64",
								r: "2"
							}),
							/* @__PURE__ */ d("circle", {
								cx: "1064",
								cy: "330",
								r: "1.5"
							}),
							/* @__PURE__ */ d("circle", {
								cx: "112",
								cy: "408",
								r: "2"
							}),
							/* @__PURE__ */ d("circle", {
								cx: "1180",
								cy: "470",
								r: "1.7"
							}),
							/* @__PURE__ */ d("circle", {
								cx: "718",
								cy: "24",
								r: "1.5"
							}),
							/* @__PURE__ */ d("path", { d: "m395 69 2 6 6 2-6 2-2 6-2-6-6-2 6-2Zm506 166 2 5 5 2-5 2-2 5-2-5-5-2 5-2Z" })
						]
					}),
					/* @__PURE__ */ f("g", {
						className: "tg-distant-lamps",
						stroke: "#dfbd80",
						strokeWidth: "1.2",
						children: [
							/* @__PURE__ */ d("path", { d: "M42 76v33m166 13v37m810-44v34m134-67v35" }),
							/* @__PURE__ */ d("ellipse", {
								cx: "42",
								cy: "124",
								rx: "13",
								ry: "20",
								fill: "#ea8c5f"
							}),
							/* @__PURE__ */ d("ellipse", {
								cx: "208",
								cy: "174",
								rx: "11",
								ry: "17",
								fill: "#dba957"
							}),
							/* @__PURE__ */ d("ellipse", {
								cx: "1018",
								cy: "164",
								rx: "12",
								ry: "19",
								fill: "#66b6aa"
							}),
							/* @__PURE__ */ d("ellipse", {
								cx: "1152",
								cy: "132",
								rx: "14",
								ry: "21",
								fill: "#d7729b"
							}),
							/* @__PURE__ */ d("path", { d: "M42 144v9m166 38v8m810-8v9m134-28v10" })
						]
					}),
					/* @__PURE__ */ f("g", {
						className: "tg-festival-horizon",
						children: [/* @__PURE__ */ d("path", {
							d: "M0 725h75v-33l32-22 32 22v43h55v-14l46-31 46 31v22h75v-18l35-24 35 24v28h99v47H0Zm1200 0h-75v-33l-32-22-32 22v43h-55v-14l-46-31-46 31v22h-75v-18l-35-24-35 24v28h-99v47h530Z",
							fill: "#101c34"
						}), /* @__PURE__ */ d("path", {
							d: "M99 706h15v22H99Zm128 24h20v20h-20Zm157 0h13v22h-13Zm702-24h15v22h-15Zm-133 24h20v20h-20Zm-150 0h13v22h-13Z",
							fill: "#f0ad6e",
							opacity: ".35"
						})]
					})
				]
			}),
			/* @__PURE__ */ d("div", {
				className: "tg-hanging-lamp tg-hanging-lamp-left",
				children: /* @__PURE__ */ d(V, { kind: "rabbit" })
			}),
			/* @__PURE__ */ d("div", {
				className: "tg-hanging-lamp tg-hanging-lamp-right",
				children: /* @__PURE__ */ d(V, { kind: "fish" })
			}),
			/* @__PURE__ */ d("div", { className: "tg-festival-ground" })
		]
	});
}
//#endregion
//#region src/games/tanglung/round-result.tsx
function q({ wins: e, earned: t = !1 }) {
	let n = o();
	return /* @__PURE__ */ d("div", {
		className: "tg-victory-matches",
		role: "img",
		"aria-label": n("games.tanglung.matches", { n: e }),
		children: [0, 1].map((n) => /* @__PURE__ */ f("span", {
			className: "tg-victory-stick",
			"data-lit": n < e,
			"data-earned": t && n === e - 1,
			children: [/* @__PURE__ */ d("i", { className: "tg-victory-flame" }), /* @__PURE__ */ d("i", { className: "tg-victory-wood" })]
		}, n))
	});
}
function ie({ pub: e, nameOf: t, canContinue: n, onContinue: r, onClose: i }) {
	let a = o(), s = e.players.find((t) => t.rid === e.outcome?.winner), c = s.pos === null ? "dragon" : e.cells[s.pos].kind ?? "dragon";
	return /* @__PURE__ */ f("section", {
		className: "tg-round-result",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": a("games.tanglung.roundComplete", { n: e.round }),
		children: [
			/* @__PURE__ */ f("header", { children: [/* @__PURE__ */ d("span", { children: a("games.tanglung.roundComplete", { n: e.round }) }), /* @__PURE__ */ d("button", {
				type: "button",
				"aria-label": a("games.tanglung.closeResult"),
				onClick: i,
				children: "⌄"
			})] }),
			/* @__PURE__ */ f("div", {
				className: "tg-round-body",
				children: [
					/* @__PURE__ */ d("div", {
						className: "tg-round-lantern",
						children: /* @__PURE__ */ d(V, { kind: c })
					}),
					/* @__PURE__ */ d("h2", { children: a("games.tanglung.roundWinner", { name: t(s.rid) }) }),
					/* @__PURE__ */ d("p", {
						className: "tg-round-reason",
						children: a(`games.tanglung.roundReason.${e.outcome.reason}`)
					}),
					/* @__PURE__ */ f("div", {
						className: "tg-award",
						children: [
							/* @__PURE__ */ d("span", { children: a("games.tanglung.victoryMatches") }),
							/* @__PURE__ */ d(q, {
								wins: s.wins,
								earned: !0
							}),
							/* @__PURE__ */ f("strong", {
								className: "tg-award-count",
								"aria-label": a("games.tanglung.matches", { n: s.wins }),
								children: [/* @__PURE__ */ d("span", {
									"aria-hidden": "true",
									children: s.wins - 1
								}), /* @__PURE__ */ d("b", {
									"aria-hidden": "true",
									children: s.wins
								})]
							})
						]
					}),
					/* @__PURE__ */ d("div", {
						className: "tg-round-scores",
						children: e.players.map((e) => /* @__PURE__ */ f("div", {
							"data-winner": e.rid === s.rid,
							children: [/* @__PURE__ */ d("strong", { children: t(e.rid) }), /* @__PURE__ */ d("span", { children: a("games.tanglung.matches", { n: e.wins }) })]
						}, e.rid))
					})
				]
			}),
			/* @__PURE__ */ f("footer", { children: [/* @__PURE__ */ d("button", {
				type: "button",
				onClick: i,
				children: a("games.tanglung.review")
			}), n ? /* @__PURE__ */ d("button", {
				type: "button",
				onClick: r,
				children: a("games.tanglung.next")
			}) : /* @__PURE__ */ d("p", { children: a("games.tanglung.waiting", { name: t(e.turn) }) })] })
		]
	});
}
//#endregion
//#region src/games/tanglung/view-player.tsx
function ae(e) {
	return /* @__PURE__ */ d(J, {
		...e,
		pub: e.public
	});
}
function J({ pub: e, members: t, myRid: r, send: i, readOnly: s = !1 }) {
	let p = o(), m = a((e) => e.locale), [h, g] = n(null), [_, v] = n(null), [y, b] = n(null), x = !s && e.phase === "round" && _ !== e.round, S = h?.rid === r ? h.style : "lantern", C = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? l(n, m) : p("games.tanglung.name");
	}, w = e.players.find((t) => t.rid === e.turn), T = w.pos === null ? null : e.cells[w.pos].kind, E = s ? [] : M(e, r), D = T === "rooster" && e.config.mode === "duel" ? "rooster" : S, O = E.filter((e) => e.type !== "move" || e.style === D), k = !s && e.turn === r, A = e.phase === "done" ? "" : e.phase === "round" ? p("games.tanglung.roundWinner", { name: C(e.outcome?.winner ?? e.turn) }) : k ? e.phase === "place" ? p("games.tanglung.choosePlace") : e.phase === "fan" ? p("games.tanglung.chooseFan") : w.pos === null ? p("games.tanglung.reenter") : p("games.tanglung.chooseMove") : p("games.tanglung.waiting", { name: C(e.turn) }), j = e.cells.filter((e) => !e.gone && e.lit).length, N = e.cells.filter((e) => !e.gone).length;
	return /* @__PURE__ */ f("div", {
		className: "tanglung-screen",
		children: [
			/* @__PURE__ */ d(re, {}),
			/* @__PURE__ */ d("div", {
				className: "tg-table-content",
				inert: x,
				children: /* @__PURE__ */ d(c, {
					adaptive: !0,
					scroll: !1,
					banner: /* @__PURE__ */ f("header", {
						className: "tg-top",
						children: [/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("span", {
							className: "tg-kicker",
							children: "TANGLUNG"
						}), /* @__PURE__ */ d("h1", { children: p("games.tanglung.name") })] }), /* @__PURE__ */ f("div", {
							className: "tg-progress",
							children: [/* @__PURE__ */ d("b", { children: p("games.tanglung.lit", {
								n: j,
								total: N
							}) }), /* @__PURE__ */ d("span", { children: e.config.mode === "duel" ? p("games.tanglung.round", { n: e.round }) : e.config.timed ? p("games.tanglung.time", { n: e.left }) : p("games.tanglung.steps", { n: e.moves }) })]
						})]
					}),
					children: /* @__PURE__ */ f("div", {
						className: "tg-layout",
						children: [
							/* @__PURE__ */ d("aside", {
								className: "tg-seats",
								"aria-label": p("games.tanglung.mode"),
								children: e.players.map((n, r) => /* @__PURE__ */ d(oe, {
									p: n,
									seat: r,
									member: t.find((e) => e.rid === n.rid),
									name: C(n.rid),
									active: !s && e.turn === n.rid,
									duel: e.config.mode === "duel"
								}, n.rid))
							}),
							/* @__PURE__ */ d("div", {
								className: "tg-board-slot",
								children: /* @__PURE__ */ d("div", {
									className: "tg-board",
									role: "group",
									"aria-label": p("games.tanglung.review"),
									children: e.cells.map((t, n) => /* @__PURE__ */ d(se, {
										i: n,
										cell: t,
										action: O.find((e) => "to" in e && e.to === n),
										players: e.players,
										fan: e.fan === n,
										nameOf: C,
										onAction: i
									}, n))
								})
							}),
							/* @__PURE__ */ f("aside", {
								className: "tg-tools",
								children: [/* @__PURE__ */ d("div", {
									className: "tg-current-art",
									children: T && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(V, { kind: T }), /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("b", { children: p(`games.tanglung.animal.${T}`) }), /* @__PURE__ */ d(H, { kind: T })] })] })
								}), /* @__PURE__ */ f("div", {
									className: "tg-action-controls",
									children: [
										e.config.mode === "duel" && e.phase === "play" && w.pos !== null && !s && /* @__PURE__ */ d("div", {
											className: "tg-action-switch",
											role: "group",
											"aria-label": p("games.tanglung.chooseMove"),
											children: ["rooster", "lantern"].map((e) => /* @__PURE__ */ d("button", {
												type: "button",
												"aria-pressed": D === e,
												disabled: !k || e === "lantern" && T === "rooster" || !E.some((t) => t.type === "move" && t.style === e),
												onClick: () => g({
													rid: r,
													style: e
												}),
												children: p(e === "rooster" ? "games.tanglung.roosterAction" : "games.tanglung.lanternAction")
											}, e))
										}),
										e.phase === "round" && !s && /* @__PURE__ */ d("button", {
											className: "tg-next",
											type: "button",
											onClick: () => v(null),
											children: p("games.tanglung.showResult")
										}),
										A && /* @__PURE__ */ d("p", {
											className: "tg-prompt",
											"aria-live": "polite",
											children: A
										}),
										T && e.phase === "play" && !s && /* @__PURE__ */ d("p", {
											className: "tg-move-help",
											children: p(`games.tanglung.movement.${D === "rooster" && e.config.mode === "duel" ? "rooster" : T}`)
										})
									]
								})]
							})
						]
					})
				})
			}),
			!s && e.phase === "round" && /* @__PURE__ */ d("div", {
				className: "tg-round-cover",
				hidden: !x,
				"data-replay": y === e.round,
				children: /* @__PURE__ */ d(ie, {
					pub: e,
					nameOf: C,
					canContinue: k,
					onContinue: () => i({ type: "next" }),
					onClose: () => {
						v(e.round), b(e.round);
					}
				})
			})
		]
	});
}
function oe({ p: e, seat: t, member: n, name: a, active: c, duel: l }) {
	let u = o(), { ref: p } = i(`seat:${e.rid}`), { ref: m } = i(`tray:${e.rid}`);
	return /* @__PURE__ */ f("div", {
		ref: p,
		className: "tg-seat",
		"data-active": c,
		style: { "--seat-color": s[(n?.colorIndex ?? t) % s.length].hex },
		children: [
			/* @__PURE__ */ d("span", {
				className: "tg-avatar",
				children: n && /* @__PURE__ */ d("img", {
					src: r[n.avatar % r.length],
					alt: ""
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "tg-seat-info",
				children: [/* @__PURE__ */ d("strong", {
					title: a,
					children: a
				}), l && /* @__PURE__ */ f("span", { children: [u("games.tanglung.matches", { n: e.wins }), /* @__PURE__ */ d("small", { children: u("games.tanglung.lives", { n: 2 - e.hits }) })] })]
			}),
			/* @__PURE__ */ d("div", {
				ref: m,
				className: "tg-seat-box",
				children: /* @__PURE__ */ d(G, {
					seat: t,
					hits: e.hits
				})
			})
		]
	});
}
function se({ i: e, cell: t, action: n, players: r, fan: a, nameOf: s, onAction: c }) {
	let l = o(), { ref: u } = i(`cell:${e}`), { ref: p, hidden: m } = i(`card:${e}`), { ref: h, hidden: g } = i(a ? "fan" : `fan-empty:${e}`), _ = t.gone ? l("games.tanglung.empty") : t.lit && t.kind ? l(`games.tanglung.animal.${t.kind}`) : l("games.tanglung.dark"), v = r.filter((t) => t.pos === e).map((e) => s(e.rid));
	return /* @__PURE__ */ f("button", {
		ref: u,
		type: "button",
		className: "tg-cell",
		disabled: !n,
		"data-target": !!n,
		"data-occupied": v.length > 0,
		"aria-label": `${l(n ? "games.tanglung.moveTo" : "games.tanglung.cell", {
			row: Math.floor(e / 4) + 1,
			col: e % 4 + 1,
			name: _
		})}${v.length ? ` · ${v.join(" / ")}` : ""}${a ? ` · ${l("games.tanglung.fan")}` : ""}`,
		onClick: () => n && c(n),
		children: [
			/* @__PURE__ */ d("div", {
				ref: p,
				className: "tg-card-anchor",
				style: { visibility: m ? "hidden" : void 0 },
				children: /* @__PURE__ */ d(U, { cell: t })
			}),
			n && /* @__PURE__ */ d("svg", {
				className: "tg-target",
				viewBox: "0 0 100 136",
				preserveAspectRatio: "none",
				"aria-hidden": !0,
				children: /* @__PURE__ */ d("rect", {
					x: "2",
					y: "2",
					width: "96",
					height: "132",
					rx: "9"
				})
			}),
			r.map((t, n) => t.pos === e && /* @__PURE__ */ d(ne, {
				rid: t.rid,
				seat: n,
				hits: t.hits,
				name: s(t.rid)
			}, t.rid)),
			a && /* @__PURE__ */ d("span", {
				ref: h,
				className: "tg-fan",
				style: { visibility: g ? "hidden" : void 0 },
				children: /* @__PURE__ */ d(K, {})
			})
		]
	});
}
//#endregion
//#region src/games/tanglung/bot.ts
function Y(e, t) {
	let n = structuredClone(e), r = n.players.find((e) => e.rid === n.turn);
	if (t.type === "fan" && (n.fan = t.to, n.phase = "play"), t.type === "place" && (r.pos = t.to, n.phase = "play"), t.type === "move") {
		let e = r.pos, i = n.cells[t.to], a = i.lit;
		if (n.config.mode === "duel") {
			(t.style === "lantern" || n.cells[e].kind === "rooster") && (n.cells[e].gone = !0);
			for (let e of n.players) e.rid !== r.rid && e.pos === t.to && (e.pos = null, e.hits++);
		} else a && n.cells[e].kind !== "rooster" && (n.cells[e].lit = !1);
		i.lit = !0, r.pos = t.to, n.phase = n.config.mode === "duel" && t.style === "rooster" ? "fan" : "play";
	}
	return n.phase !== "fan" && (n.turn = n.players[(n.players.indexOf(r) + 1) % n.players.length].rid), n;
}
function X(e, t) {
	if (t.type === "next") return 0;
	if (t.type === "tick") return -1;
	if (t.type === "place") return 5 - Math.abs(t.to % 4 - 1.5) - Math.abs(Math.floor(t.to / 4) - 1.5);
	let n = e.players.find((t) => t.rid === e.turn), r = Y(e, t);
	if (t.type === "fan") {
		let e = r.players.find((e) => e.rid !== n.rid);
		return e ? -M(r, e.rid).length : 0;
	}
	let i = e.cells[t.to].lit ? 0 : 8;
	r.cells.some((e) => !e.gone && !e.lit) || (i += 1e3);
	let a = e.players.find((e) => e.rid !== n.rid);
	if (e.config.mode !== "duel") {
		e.cells[t.to].lit && e.cells[n.pos].kind !== "rooster" && (i -= 7);
		let a = e.cells[t.to].kind;
		i += a ? r.cells.filter((e, n) => !e.lit && A(r.cells, t.to, n, a, null)).length : 2;
	} else a?.pos === t.to && t.style === "lantern" && (i += a.hits ? 1e3 : 22);
	return i;
}
function ce(e, t) {
	let n = X(e, t);
	if (e.config.mode !== "duel" || t.type === "next" || t.type === "tick") return n;
	let r = e.players.find((t) => t.rid === e.turn), i = Y(e, t), a = i.players.find((e) => e.rid !== r.rid);
	if (a.hits >= 2) return 1e4;
	if (!i.cells.some((e) => !e.gone && !e.lit)) return 9e3;
	let o = (e) => {
		e.turn = a.rid, e.phase = "play";
		let t = M(e, a.rid);
		if (!t.length) return 8e3;
		let n = e.players.find((e) => e.rid === r.rid).pos, i = t.some((e) => e.type === "move" && e.style === "lantern" && e.to === n), o = e.cells.filter((e) => !e.gone && !e.lit).length === 1 && t.some((t) => t.type === "move" && !e.cells[t.to].lit);
		return -Math.min(30, t.length) * .35 - (i ? r.hits ? 2e3 : 35 : 0) - (o ? 3e3 : 0);
	};
	return i.phase === "fan" ? n + Math.max(...M(i, r.rid).map((e) => o(Y(i, e)))) : n + o(i);
}
var le = (e, t) => {
	let n = e.public, r = M(n, t.rid);
	if (!r.length) return null;
	let i = { ...t.memory?.visits ?? {} }, a = JSON.stringify([
		n.round,
		n.phase,
		n.cells.map((e) => [
			e.kind,
			e.lit,
			e.gone
		]),
		n.players.map((e) => [e.pos, e.hits]),
		n.fan
	]), o = (e) => a + JSON.stringify(e), s = (e) => (t.difficulty === "weak" ? X(n, e) : ce(n, e)) - (i[o(e)] ?? 0) * 12, c = r.map((e) => ({
		a: e,
		score: s(e)
	})).sort((e, t) => t.score - e.score), l = c[0].a;
	if (t.difficulty === "weak") {
		let e = c.filter((e) => e.score >= c[0].score - 9).slice(0, 4);
		l = e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length].a;
	}
	return i[o(l)] = (i[o(l)] ?? 0) + 1, {
		action: l,
		memory: { visits: Object.fromEntries(Object.entries(i).slice(-2048)) }
	};
}, ue = (e, t, n) => {
	if (e.type === "next") return n("games.tanglung.next");
	if (e.type === "tick") return "";
	let r = {
		row: Math.floor(e.to / 4) + 1,
		col: e.to % 4 + 1
	};
	return e.type === "place" ? n("games.tanglung.hintPlace", r) : e.type === "fan" ? n("games.tanglung.hintFan", r) : n("games.tanglung.hintMove", {
		...r,
		style: n(e.style === "rooster" ? "games.tanglung.roosterAction" : "games.tanglung.lanternAction")
	});
}, Z = (e, t) => ({
	x: e.x + (e.w - t.w) / 2,
	y: e.y + (e.h - t.h) / 2,
	w: t.w,
	h: t.h
}), Q = (e, t) => ({
	x: e.x + e.w * (t ? .49 : .29),
	y: e.y + e.h * (t ? .36 : .5),
	w: e.w * .48,
	h: e.h * .49
}), de = (e) => ({
	x: e.x + e.w * .17,
	y: e.y + e.h * .15,
	w: e.w * .66,
	h: e.h * .77
}), $ = (e) => /* @__PURE__ */ d("div", {
	style: {
		position: "absolute",
		inset: 0,
		zIndex: 2
	},
	children: e
}), fe = {
	move(e, t) {
		let n = e.data, r = t.anchor(`tray:${e.rid}`), i = t.anchor(`piece:${e.rid}`), a = n.from === null ? r && r.w && r.h ? r : t.anchor(`seat:${e.rid}`) : t.anchor(`cell:${n.from}`);
		if (!i || !a) return null;
		let o = n.from === null ? Z(a, i) : Q(a, n.seat);
		return {
			ms: 360,
			hide: [`piece:${e.rid}`],
			node: $(/* @__PURE__ */ d(p, {
				from: o,
				to: i,
				ms: 360,
				children: /* @__PURE__ */ d(G, {
					seat: n.seat,
					hits: n.hits,
					style: {
						width: i.w,
						height: i.h
					}
				})
			}))
		};
	},
	fan(e, t) {
		let n = e.data, r = t.anchor("fan"), i = t.anchor(n.from === null ? `seat:${e.rid}` : `cell:${n.from}`);
		return !r || !i ? null : {
			ms: 360,
			hide: ["fan"],
			node: $(/* @__PURE__ */ d(p, {
				from: n.from === null ? Z(i, r) : de(i),
				to: r,
				ms: 360,
				children: /* @__PURE__ */ d("span", {
					style: {
						display: "block",
						width: r.w,
						height: r.h
					},
					children: /* @__PURE__ */ d(K, {})
				})
			}))
		};
	},
	light(e, t) {
		let n = e.data, r = t.anchor(`card:${n.to}`);
		return r ? {
			ms: 420,
			hide: [`card:${n.to}`],
			node: /* @__PURE__ */ d("div", {
				className: "tg-fx-card",
				style: {
					left: r.x,
					top: r.y,
					width: r.w,
					height: r.h
				},
				children: /* @__PURE__ */ d(U, { cell: {
					kind: n.animal,
					lit: !0,
					gone: !1
				} })
			})
		} : null;
	},
	dim(e, t) {
		let { to: n } = e.data, r = t.anchor(`card:${n}`);
		return r ? {
			ms: 420,
			hide: [`card:${n}`],
			node: /* @__PURE__ */ d("div", {
				className: "tg-fx-card",
				style: {
					left: r.x,
					top: r.y,
					width: r.w,
					height: r.h
				},
				children: /* @__PURE__ */ d(U, { cell: {
					kind: null,
					lit: !1,
					gone: !1
				} })
			})
		} : null;
	},
	remove(e, t) {
		let n = e.data, r = t.anchor(`card:${n.from}`);
		return r ? {
			ms: 340,
			node: /* @__PURE__ */ d("div", {
				className: "tg-fx-remove",
				style: {
					left: r.x,
					top: r.y,
					width: r.w,
					height: r.h
				},
				children: /* @__PURE__ */ d(U, { cell: {
					kind: n.animal,
					lit: !0,
					gone: !1
				} })
			})
		} : null;
	},
	bump(e, t) {
		let n = e.data, r = t.anchor(`cell:${n.from}`), i = t.anchor(`tray:${e.rid}`), a = i && i.w && i.h ? i : t.anchor(`seat:${e.rid}`);
		if (!r || !a) return null;
		let o = Q(r, n.seat), s = o, c = Z(a, {
			...o,
			w: o.w * .7,
			h: o.h * .7
		});
		return {
			ms: 460,
			node: $(/* @__PURE__ */ d(p, {
				from: s,
				to: c,
				ms: 460,
				children: /* @__PURE__ */ d(G, {
					seat: n.seat,
					hits: n.hits,
					style: {
						width: o.w,
						height: o.h
					}
				})
			}))
		};
	},
	round(e, t) {
		let n = t.anchor("cell:5");
		return n ? {
			ms: 350,
			node: /* @__PURE__ */ d(m, {
				at: n,
				ms: 350
			})
		} : null;
	}
};
//#endregion
//#region src/games/tanglung/game-over.tsx
function pe(e) {
	let t = e.public, i = o(), s = a((e) => e.locale), [c, p] = n(!0), [m, g] = n(!1), [_, v] = n(!1), y = () => {
		p(!1), v(!0);
	}, b = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? l(n, s) : i("games.tanglung.name");
	}, x = e.result.winner.length > 0, S = t.config.mode === "duel";
	return /* @__PURE__ */ f("div", {
		className: "tg-over-root",
		children: [
			/* @__PURE__ */ d("div", {
				className: "tg-over-board",
				inert: c,
				children: /* @__PURE__ */ d(J, {
					public: t,
					pub: t,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {},
					readOnly: !0
				})
			}),
			/* @__PURE__ */ d("button", {
				type: "button",
				className: "tg-restore",
				hidden: c,
				onClick: () => p(!0),
				children: i("games.tanglung.showResult")
			}),
			/* @__PURE__ */ d("div", {
				className: "tg-result-cover",
				hidden: !c,
				"data-replay": _,
				children: /* @__PURE__ */ f("section", {
					className: "tg-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": i("session.result.title"),
					children: [
						/* @__PURE__ */ f("header", { children: [/* @__PURE__ */ d("h2", { children: i(x ? "games.tanglung.resultWin" : "games.tanglung.resultLoss") }), /* @__PURE__ */ d("button", {
							type: "button",
							"aria-label": i("games.tanglung.closeResult"),
							onClick: y,
							children: "⌄"
						})] }),
						/* @__PURE__ */ f("div", {
							className: "tg-result-body",
							children: [
								/* @__PURE__ */ d("div", {
									className: "tg-result-art",
									children: /* @__PURE__ */ d(V, { kind: x ? "dragon" : "butterfly" })
								}),
								/* @__PURE__ */ d("h3", { children: S ? i("games.tanglung.champion", { name: e.result.winner.map(b).join(" / ") }) : i(x ? "games.tanglung.teamWin" : `games.tanglung.reason.${t.outcome?.reason ?? "time"}`) }),
								S && /* @__PURE__ */ f("div", {
									className: "tg-final-award",
									children: [
										/* @__PURE__ */ f("p", { children: [
											i("games.tanglung.roundComplete", { n: t.round }),
											" · ",
											i(`games.tanglung.roundReason.${t.outcome.reason}`)
										] }),
										/* @__PURE__ */ d("span", { children: i("games.tanglung.victoryMatches") }),
										/* @__PURE__ */ d(q, {
											wins: t.players.find((e) => e.rid === t.outcome?.winner)?.wins ?? 0,
											earned: !0
										})
									]
								}),
								/* @__PURE__ */ f("p", { children: [
									i("games.tanglung.steps", { n: t.moves }),
									" · ",
									i("games.tanglung.lit", {
										n: t.cells.filter((e) => e.lit && !e.gone).length,
										total: t.cells.filter((e) => !e.gone).length
									})
								] }),
								/* @__PURE__ */ d("div", {
									className: "tg-result-people",
									children: e.result.ranking.map((t) => {
										let n = e.members.find((e) => e.rid === t), a = e.result.autopilot?.[t];
										return /* @__PURE__ */ f("div", {
											"data-winner": e.result.winner.includes(t),
											children: [
												n && /* @__PURE__ */ d("img", {
													src: r[n.avatar % r.length],
													alt: ""
												}),
												/* @__PURE__ */ d("strong", { children: b(t) }),
												S && /* @__PURE__ */ d("b", { children: i("games.tanglung.matches", { n: e.result.scores?.[t] ?? 0 }) }),
												a !== void 0 && a > 0 && /* @__PURE__ */ f("small", { children: [/* @__PURE__ */ d(h, { size: 14 }), i("session.autopilot.share", { n: Math.round(a * 100) })] })
											]
										}, t);
									})
								}),
								S && /* @__PURE__ */ d("ol", {
									"aria-label": i("games.tanglung.history"),
									className: "tg-history",
									children: t.history.map((e, t) => /* @__PURE__ */ f("li", { children: [
										/* @__PURE__ */ d("span", { children: i("games.tanglung.round", { n: t + 1 }) }),
										/* @__PURE__ */ d("b", { children: b(e.winner) }),
										/* @__PURE__ */ d("span", { children: i(`games.tanglung.roundReason.${e.reason}`) })
									] }, t))
								}),
								e.hintCount !== void 0 && /* @__PURE__ */ d("p", { children: i("session.hint.usedCount", { n: e.hintCount }) })
							]
						}),
						/* @__PURE__ */ d("footer", { children: m ? /* @__PURE__ */ f(u, { children: [
							/* @__PURE__ */ d("p", { children: i("games.tanglung.confirm") }),
							/* @__PURE__ */ d("button", {
								type: "button",
								onClick: () => g(!1),
								children: i("games.tanglung.cancel")
							}),
							/* @__PURE__ */ d("button", {
								type: "button",
								onClick: e.onBackToLobby,
								children: i("games.tanglung.leave")
							})
						] }) : /* @__PURE__ */ f(u, { children: [
							/* @__PURE__ */ d("button", {
								type: "button",
								onClick: y,
								children: i("games.tanglung.review")
							}),
							e.onPlayAgain && /* @__PURE__ */ d("button", {
								type: "button",
								onClick: e.onPlayAgain,
								children: i("session.result.playAgain")
							}),
							e.onBackToLobby && /* @__PURE__ */ d("button", {
								type: "button",
								onClick: () => g(!0),
								children: i("session.result.backToLobby")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ d("p", { children: i("session.result.waitHost") })
						] }) })
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/tanglung/options.tsx
function me({ value: e, onChange: t }) {
	let n = o(), r = x.safeParse(e).data ?? x.parse(void 0);
	return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ d(_, {
			title: n("games.tanglung.mode"),
			columns: 3,
			children: [
				"duel",
				"solo",
				"coop"
			].map((e) => /* @__PURE__ */ d(g, {
				name: "tanglung-mode",
				value: e,
				checked: r.mode === e,
				label: n(`games.tanglung.${e}`),
				accent: E.accent,
				onChange: () => t({
					...r,
					mode: e
				})
			}, e))
		}),
		/* @__PURE__ */ d(v, {
			checked: r.shuffled,
			disabled: r.mode === "duel",
			label: n("games.tanglung.shuffled"),
			hint: n("games.tanglung.shuffledHint"),
			onChange: () => t({
				...r,
				shuffled: !r.shuffled
			})
		}),
		/* @__PURE__ */ d(v, {
			checked: r.timed,
			disabled: r.mode === "duel",
			label: n("games.tanglung.timed"),
			hint: n("games.tanglung.timedHint"),
			onChange: () => t({
				...r,
				timed: !r.timed
			})
		})
	] });
}
//#endregion
//#region src/games/tanglung/guide.tsx
function he() {
	let e = o();
	return /* @__PURE__ */ f("section", { children: [
		/* @__PURE__ */ d("h3", {
			className: "section-label",
			children: e("games.tanglung.guide")
		}),
		/* @__PURE__ */ d("div", {
			className: "grid gap-2",
			children: D.map((t) => /* @__PURE__ */ f("div", {
				className: "flex items-center gap-3 rounded-lg border border-ink/20 p-2",
				children: [
					/* @__PURE__ */ d("span", {
						className: "block h-12 w-16 [&_img]:h-full [&_img]:w-full [&_img]:object-contain",
						children: /* @__PURE__ */ d(V, { kind: t })
					}),
					/* @__PURE__ */ d("span", {
						className: "block size-10",
						children: /* @__PURE__ */ d(H, { kind: t })
					}),
					/* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d("b", { children: e(`games.tanglung.animal.${t}`) }), /* @__PURE__ */ d("small", {
						className: "block",
						children: e(`games.tanglung.movement.${t}`)
					})] })
				]
			}, t))
		}),
		/* @__PURE__ */ d("p", {
			className: "mt-2 text-sm",
			children: e("games.tanglung.fanRule")
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/tanglung/entry.tsx
var ge = {
	definition: z,
	View: ae,
	bot: le,
	describe: ue,
	fx: fe,
	OverView: pe,
	Options: me,
	Guide: he,
	locales: {
		zh: {
			name: "灯笼",
			desc: "在彩色灯笼之间移动火柴盒，点亮夜空或撞出对手",
			rules: "目标:\n对决中先赢两小局的人获胜。每小局可通过点亮最后一张暗牌、令对手无法行动，或将对手撞出两次获胜。单人和合作模式则要让 16 张灯笼同时亮起。\n准备:\n牌共 16 张：公鸡 2 张，兔、蝴蝶、鱼、马各 3 张，龙 2 张。将两张公鸡放在四行四列牌阵的对角，其余牌洗混后盖放。对决翻亮中央四张，单人和合作只亮公鸡。依次选择公鸡放置自己的火柴盒，由起始玩家开始行动。\n对决流程:\n· 移动前选择公鸡行动或当前灯笼行动。所有行动必须落在现存且没有风扇的牌上，不得越过风扇。\n· 公鸡行动：正交移动一步，不能落在对手的牌上。抵达背面朝上的卡牌时，将其翻至正面。从公鸡出发时移除起点公鸡，从其他动物出发时保留出发位置的卡牌。随后必须把风扇移到另一张没有火柴盒的现存牌上；不能留在原位。无法完成风扇移动时，不能选择此行动。\n· 灯笼行动：按当前动物的走法移动，翻亮目标暗牌，并移除出发位置的卡牌。落在对手处就将其撞出。第一次被撞后，对手下一回合只能将火柴盒放回空置、没有风扇的亮牌；没有这样的牌时，对手输掉该小局。第二次被撞出时，该玩家立即输掉该小局。\n动物走法:\n· 兔：沿正交方向移动任意步数。\n· 蝴蝶：沿对角方向移动任意步数。\n兔和蝴蝶的移动可以经过现存卡牌，但不能跨过空位。\n· 鱼：沿正交或对角方向移动一步。\n· 马先正交一步再垂直两步，或先两步再垂直一步；至少有一条 L 形路径不经过风扇。\n· 龙：沿正交或对角方向移动任意步数。马和龙可以跨过空位，但仍不能越过风扇。\n· 公鸡：沿正交方向移动一步。\n单人和合作:\n只使用当前动物走法，不移除任何牌，也不使用风扇。抵达暗牌时翻亮目标；抵达亮牌时将起牌翻暗，但公鸡永不翻暗。已揭示过的暗牌保留动物记忆提示。合作双方轮流移动自己的火柴盒，允许共处一牌，不发生撞击。\n选项与结算:\n单人或合作可将全部 16 张牌洗混后布阵，仍从公鸡开始；也可启用从布阵完成后开始的两分钟挑战。禅模式没有时间或步数上限。全部 16 张同时亮起即共同成功，限时耗尽则失败。对决每小局重新洗牌，并轮换起始玩家，先赢两小局结束整场。",
			mode: "玩法",
			duel: "双人对决",
			solo: "单人禅模式",
			coop: "双人合作",
			shuffled: "全随机牌阵",
			shuffledHint: "公鸡也参与洗牌，仅适用于单人和合作",
			timed: "两分钟挑战",
			timedHint: "放置完成后开始计时，仅适用于单人和合作",
			animal: {
				rooster: "公鸡",
				rabbit: "兔",
				butterfly: "蝴蝶",
				fish: "鱼",
				horse: "马",
				dragon: "龙"
			},
			movement: {
				rooster: "可以沿正交方向移动1格。",
				rabbit: "可以沿正交方向移动任意格数，但不能跨过空位。",
				butterfly: "可以沿对角线移动任意格数，但不能跨过空位。",
				fish: "可以沿正交方向或对角线移动1格。",
				horse: "先沿正交方向移动1格，再沿与之垂直的方向移动2格；也可以先移动2格，再转向移动1格。移动时可以跨过空位。",
				dragon: "可以沿正交方向或对角线移动任意格数，也可以跨过空位。"
			},
			roosterAction: "公鸡行动",
			lanternAction: "灯笼行动",
			choosePlace: "选择公鸡，放置火柴盒",
			reenter: "选择空置亮牌，放回火柴盒",
			chooseMove: "选择行动，再点击目标灯笼",
			chooseFan: "将风扇放到另一张空置牌上",
			waiting: "等待 {{name}}",
			turn: "{{name}} 的回合",
			round: "第 {{n}} 小局",
			lit: "已点亮 {{n}} / {{total}}",
			steps: "移动 {{n}} 步",
			matches: "胜局 {{n}}",
			lives: "剩余火柴 {{n}}",
			time: "剩余 {{n}} 秒",
			dark: "未点亮",
			empty: "空位",
			memory: "记忆：{{name}}",
			fan: "风扇",
			cell: "{{row}} 行 {{col}} 列，{{name}}",
			moveTo: "移动至 {{row}} 行 {{col}} 列，{{name}}",
			roundWinner: "{{name}} 赢得本小局",
			next: "开始下一小局",
			roundComplete: "第 {{n}} 小局结束",
			victoryMatches: "胜局火柴",
			roundReason: {
				light: "点亮最后一张灯笼",
				bump: "将对手撞出两次",
				trapped: "对手无法行动",
				time: "挑战时间结束"
			},
			resultWin: "夜空为你点亮",
			resultLoss: "这一夜，仍有未亮的灯",
			champion: "{{name}} 赢得整场对决",
			teamWin: "所有灯笼都亮起来了",
			reason: {
				light: "点亮最后一张灯笼",
				bump: "将对手撞出两次",
				trapped: "没有合法行动",
				time: "挑战时间结束"
			},
			review: "查看最终牌阵",
			showResult: "展开结算",
			closeResult: "收起结算",
			history: "小局记录",
			confirm: "确认离开当前结算？",
			cancel: "取消",
			leave: "确认离开",
			guide: "灯笼走法",
			fanRule: "所有走法都不能落入或越过风扇。",
			hintPlace: "将火柴盒放在 {{row}} 行 {{col}} 列",
			hintMove: "使用{{style}}，前往 {{row}} 行 {{col}} 列",
			hintFan: "将风扇移到 {{row}} 行 {{col}} 列",
			errMove: "当前不能执行此行动，请重新选择目标",
			errTurn: "现在不能执行此行动"
		},
		en: {
			name: "Tanglung",
			desc: "Move your matchbox among glowing lanterns to light the night or bump your rival",
			rules: "Goal:\nIn a duel, be the first to win two matches. Win a match by lighting the last dark lantern, leaving your opponent unable to act, or bumping them twice. Solo and cooperative players aim to light all 16 lanterns simultaneously.\nSetup:\nThere are 16 cards: two Roosters, three each of Rabbit, Butterfly, Fish and Horse, and two Dragons. Place Roosters in opposite corners of a 4×4 grid and shuffle the remaining cards face down into the other spaces. In a duel, light the central four cards; in solo and cooperative play, only Roosters begin lit. Choose Roosters in turn for your matchboxes, then the starting player acts.\nDuel turns:\n· Choose a Rooster or Lantern action before moving. All destinations must be existing cards without the Fan. No action may cross the Fan.\n· Rooster action: move one orthogonal step, without landing on your opponent. Light a dark destination. Remove your starting card only if it is a Rooster. Then move the Fan to a different existing card without a matchbox. The Fan cannot stay in place. You cannot choose this action if you cannot complete Fan placement.\n· Lantern action: move using your current animal, light a dark destination, and remove your starting card. Landing on your opponent bumps them out. After their first bump, their next turn is used only to re-enter on an unoccupied lit card without the Fan. If none exists, they lose. A second bump loses immediately.\nAnimal movement:\n· Rabbit: any number of orthogonal steps. Butterfly: any number of diagonal steps. Both may cross existing cards, but not gaps.\n· Fish: one orthogonal or diagonal step.\n· Horse: one orthogonal step then two perpendicular steps, or two then one. At least one L-shaped route must avoid the Fan.\n· Dragon: any number of orthogonal or diagonal steps. Horse and Dragon may cross gaps, but cannot cross the Fan.\n· Rooster: one orthogonal step.\nSolo and cooperative play:\nUse only your current animal. Never remove cards or use the Fan. Moving to a dark card lights it; moving to a lit card turns your starting card dark, except Roosters never turn dark. Previously revealed dark cards retain an animal memory reminder. Cooperative players alternate moving their own matchboxes. They may share a card and never bump each other.\nOptions and ending:\nSolo and cooperative play can shuffle all 16 cards, including Roosters, before setup; still start on Roosters. The optional two-minute challenge begins after placement. Zen mode has no time or move limit. Light all 16 simultaneously to win together; running out of time loses. Duels reshuffle each match and alternate the starting player. Winning two matches ends the duel.",
			mode: "Mode",
			duel: "Duel",
			solo: "Solo zen",
			coop: "Cooperative",
			shuffled: "Fully shuffled grid",
			shuffledHint: "Shuffle Roosters too; solo and cooperative only",
			timed: "Two-minute challenge",
			timedHint: "Starts after placement; solo and cooperative only",
			animal: {
				rooster: "Rooster",
				rabbit: "Rabbit",
				butterfly: "Butterfly",
				fish: "Fish",
				horse: "Horse",
				dragon: "Dragon"
			},
			movement: {
				rooster: "Move one space orthogonally.",
				rabbit: "Move any number of spaces along an orthogonal line, without crossing gaps.",
				butterfly: "Move any number of spaces along a diagonal line, without crossing gaps.",
				fish: "Move one space orthogonally or diagonally.",
				horse: "Move one space orthogonally and then two spaces in a perpendicular direction, or two spaces and then one. You may cross gaps along this L-shaped route.",
				dragon: "Move any number of spaces along an orthogonal or diagonal line. You may cross gaps."
			},
			roosterAction: "Rooster action",
			lanternAction: "Lantern action",
			choosePlace: "Choose a Rooster for your matchbox",
			reenter: "Return to an unoccupied lit lantern",
			chooseMove: "Choose an action, then a destination",
			chooseFan: "Move the Fan to another unoccupied card",
			waiting: "Waiting for {{name}}",
			turn: "{{name}}’s turn",
			round: "Match {{n}}",
			lit: "{{n}} / {{total}} lit",
			steps: "{{n}} moves",
			matches: "Wins: {{n}}",
			lives: "Matchsticks left: {{n}}",
			time: "{{n}} seconds left",
			dark: "Unlit",
			empty: "Gap",
			memory: "Remembered: {{name}}",
			fan: "Fan",
			cell: "Row {{row}}, column {{col}}, {{name}}",
			moveTo: "Move to row {{row}}, column {{col}}, {{name}}",
			roundWinner: "{{name}} wins this match",
			next: "Start next match",
			roundComplete: "Match {{n}} complete",
			victoryMatches: "Victory matches",
			roundReason: {
				light: "Lit the last lantern",
				bump: "Bumped the opponent twice",
				trapped: "The opponent cannot act",
				time: "Time ran out"
			},
			resultWin: "A night of glowing lanterns",
			resultLoss: "Some lanterns still await their light",
			champion: "{{name}} wins the duel",
			teamWin: "Every lantern is glowing",
			reason: {
				light: "Lit the last lantern",
				bump: "Bumped the opponent twice",
				trapped: "No legal action remains",
				time: "Time ran out"
			},
			review: "Review final grid",
			showResult: "Show results",
			closeResult: "Hide results",
			history: "Match history",
			confirm: "Leave these results?",
			cancel: "Cancel",
			leave: "Leave",
			guide: "Lantern movement",
			fanRule: "No move may land on or cross the Fan.",
			hintPlace: "Place your matchbox at row {{row}}, column {{col}}",
			hintMove: "Use the {{style}} to reach row {{row}}, column {{col}}",
			hintFan: "Move the Fan to row {{row}}, column {{col}}",
			errMove: "That action is unavailable. Choose another destination.",
			errTurn: "That action is unavailable now."
		}
	}
};
//#endregion
export { ge as default };
