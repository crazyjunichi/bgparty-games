import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { PLAYER_COLORS as n } from "@bgparty/sdk/player-colors";
import { AVATARS as r } from "@bgparty/sdk/avatars";
import { useCallback as i, useEffect as a, useLayoutEffect as o, useRef as s, useState as c } from "react";
import { BottomSheet as l } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as u, useFxAnchorsMaybe as d } from "@bgparty/sdk/fx/anchors";
import { useT as f } from "@bgparty/sdk/i18n";
import { IconBot as p, IconClose as m, IconHistory as h, IconPile as g } from "@bgparty/sdk/icons";
import { useWakeLock as _ } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { FlySprite as x, PulseBox as S } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as C } from "@bgparty/sdk/confirm-button";
import { Confetti as w } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as T, OptionSection as E, OptionSwitch as D } from "@bgparty/sdk/ui/game-options";
//#region src/games/zenith/data.ts
var te = [
	{
		id: "Elisabeth",
		planet: 2,
		cost: 2,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{ kind: "discard" },
			{
				kind: "zenithium",
				n: 1
			}
		]
	},
	{
		id: "Pkd1ck",
		planet: 4,
		cost: 5,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "influence",
				n: 1
			},
			{
				kind: "condition",
				condition: { kind: "leader" },
				effect: {
					kind: "zenithium",
					n: 1
				}
			}
		]
	},
	{
		id: "AgentEzra",
		planet: 4,
		cost: 1,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "credits",
				n: 4
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: { kind: "giveZenithium" }
				},
				effect: {
					kind: "influence",
					n: 2,
					planet: 1
				}
			}
		]
	},
	{
		id: "DonaldSmooth",
		planet: 4,
		cost: 2,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 4,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: { kind: "discard" }
			},
			effect: { kind: "credits" }
		}]
	},
	{
		id: "Huxl3y",
		planet: 0,
		cost: 5,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "influence",
				n: 1
			},
			{
				kind: "condition",
				condition: { kind: "leader" },
				effect: {
					kind: "credits",
					n: 3
				}
			}
		]
	},
	{
		id: "Titus",
		planet: 3,
		cost: 1,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{
				kind: "giveInfluence",
				except: 3
			},
			{
				kind: "credits",
				n: 10
			}
		]
	},
	{
		id: "Mc4ffr3y",
		planet: 3,
		cost: 4,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "zenithium",
			n: 2
		}]
	},
	{
		id: "Luc4s",
		planet: 1,
		cost: 2,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					planet: 1,
					factors: [
						2,
						4,
						7
					],
					amounts: [
						2,
						4,
						7
					]
				}
			},
			effect: { kind: "zenithium" }
		}]
	},
	{
		id: "Cresus",
		planet: 1,
		cost: 1,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "credits",
			n: 6
		}]
	},
	{
		id: "Atlas",
		planet: 0,
		cost: 3,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{ kind: "discard" },
			{ kind: "leader" }
		]
	},
	{
		id: "PunkMari",
		planet: 0,
		cost: 7,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "discard",
				full: !0
			},
			{
				kind: "influence",
				n: 2
			}
		]
	},
	{
		id: "Septimus",
		planet: 3,
		cost: 3,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					planet: 3,
					factors: [
						1,
						2,
						3
					],
					amounts: [
						2,
						4,
						7
					]
				}
			},
			effect: {
				kind: "influence",
				planet: 3
			}
		}]
	},
	{
		id: "DoubleJoe",
		planet: 0,
		cost: 5,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "zenithium",
				n: 2
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: { kind: "giveLeader" }
				},
				effect: {
					kind: "zenithium",
					n: 2
				}
			}
		]
	},
	{
		id: "DonDune",
		planet: 3,
		cost: 6,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{
				kind: "influence",
				planet: 1,
				n: 1
			},
			{ kind: "leader" }
		]
	},
	{
		id: "V3rn3",
		planet: 2,
		cost: 2,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 2,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					planet: 2,
					factors: [
						2,
						4,
						7
					],
					amounts: [
						2,
						4,
						7
					]
				}
			},
			effect: { kind: "zenithium" }
		}]
	},
	{
		id: "Ch4mb3rs",
		planet: 4,
		cost: 8,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "zenithium",
				n: 3
			},
			{
				kind: "condition",
				condition: { kind: "leader" },
				effect: {
					kind: "zenithium",
					n: 1
				}
			}
		]
	},
	{
		id: "Buj0ld",
		planet: 1,
		cost: 7,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "develop",
			free: !0,
			lowest: !0
		}]
	},
	{
		id: "JackCurry",
		planet: 3,
		cost: 1,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{
				kind: "credits",
				n: 4
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "giveZenithium",
						n: 1
					}
				},
				effect: {
					kind: "influence",
					planet: 0,
					n: 2
				}
			}
		]
	},
	{
		id: "C1x1n",
		planet: 1,
		cost: 4,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "condition",
			condition: { kind: "leader" },
			effect: {
				kind: "influence",
				planet: 1,
				n: 1
			}
		}]
	},
	{
		id: "LadyMoore",
		planet: 3,
		cost: 10,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{
				kind: "condition",
				mandatory: !0,
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						opponent: !0
					}
				},
				effect: {
					kind: "influence",
					n: 1
				}
			},
			{
				kind: "condition",
				mandatory: !0,
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						opponent: !0
					}
				},
				effect: {
					kind: "influence",
					n: 1
				}
			},
			{
				kind: "condition",
				mandatory: !0,
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						opponent: !0
					}
				},
				effect: {
					kind: "influence",
					n: 1
				}
			}
		]
	},
	{
		id: "L0v3cr4ft",
		planet: 2,
		cost: 5,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 2
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						planet: 0
					}
				},
				effect: {
					kind: "zenithium",
					n: 1
				}
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						planet: 1
					}
				},
				effect: {
					kind: "zenithium",
					n: 1
				}
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						planet: 3
					}
				},
				effect: {
					kind: "zenithium",
					n: 1
				}
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						planet: 4
					}
				},
				effect: {
					kind: "zenithium",
					n: 1
				}
			}
		]
	},
	{
		id: "Suleiman",
		planet: 4,
		cost: 1,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 4,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "spendCredits",
					amounts: [
						3,
						7,
						12
					],
					factors: [
						1,
						2,
						3
					]
				}
			},
			effect: {
				kind: "influence",
				except: 4
			}
		}]
	},
	{
		id: "Annie",
		planet: 4,
		cost: 1,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "credits",
				n: 5
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: { kind: "giveLeader" }
				},
				effect: {
					kind: "credits",
					n: 7
				}
			}
		]
	},
	{
		id: "M4th3s0n",
		planet: 2,
		cost: 4,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 2,
			n: 1
		}, {
			kind: "condition",
			condition: { kind: "leader" },
			effect: {
				kind: "influence",
				planet: 2,
				n: 1
			}
		}]
	},
	{
		id: "Gilgamesh",
		planet: 2,
		cost: 9,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{
				kind: "influence",
				n: 2
			},
			{
				kind: "influence",
				n: 2,
				enemySide: !0
			}
		]
	},
	{
		id: "StessyPower",
		planet: 1,
		cost: 3,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "spendZenithium",
					amounts: [
						1,
						2,
						4
					],
					factors: [
						1,
						2,
						3
					]
				}
			},
			effect: {
				kind: "influence",
				except: 1
			}
		}]
	},
	{
		id: "Felis",
		planet: 1,
		cost: 3,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 1,
				n: 1
			},
			{
				kind: "zenithium",
				n: 3
			},
			{
				kind: "zenithium",
				opponent: !0,
				n: 1
			}
		]
	},
	{
		id: "V4nc3",
		planet: 3,
		cost: 2,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "choice",
			left: [{ kind: "transfer" }],
			right: [{
				kind: "zenithium",
				n: 1
			}]
		}]
	},
	{
		id: "Ramses",
		planet: 3,
		cost: 3,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "choice",
			left: [{
				kind: "transfer",
				n: 2
			}],
			right: [{
				kind: "credits",
				n: 8
			}]
		}]
	},
	{
		id: "GuyGambler",
		planet: 0,
		cost: 3,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "credits",
				n: 5
			},
			{
				kind: "condition",
				condition: { kind: "leader" },
				effect: { kind: "bonus" }
			}
		]
	},
	{
		id: "DocWissen",
		planet: 1,
		cost: 6,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "develop",
			discount: 1,
			faction: "human"
		}]
	},
	{
		id: "BaronGoro",
		planet: 2,
		cost: 4,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{
				kind: "giveInfluence",
				except: 2
			},
			{
				kind: "zenithium",
				n: 3
			}
		]
	},
	{
		id: "Ivan",
		planet: 4,
		cost: 1,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 4,
			n: 1
		}, {
			kind: "credits",
			enemyColorCount: 2
		}]
	},
	{
		id: "Br4dbury",
		planet: 1,
		cost: 6,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "develop",
			discount: 1,
			faction: "robot"
		}]
	},
	{
		id: "F4rm3r",
		planet: 2,
		cost: 6,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{
				kind: "influence",
				resetUsed: !0,
				n: 1
			},
			{
				kind: "influence",
				different: !0,
				n: 1
			}
		]
	},
	{
		id: "Zenon",
		planet: 2,
		cost: 1,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{
				kind: "credits",
				n: 8
			},
			{
				kind: "credits",
				opponent: !0,
				n: 2
			}
		]
	},
	{
		id: "Bish0p",
		planet: 3,
		cost: 4,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "condition",
			condition: { kind: "leader" },
			effect: {
				kind: "influence",
				planet: 3,
				n: 1
			}
		}]
	},
	{
		id: "Wul",
		planet: 0,
		cost: 2,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 0,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					planet: 0,
					amounts: [
						2,
						4,
						7
					],
					factors: [
						2,
						4,
						7
					]
				}
			},
			effect: { kind: "zenithium" }
		}]
	},
	{
		id: "Th0mps0n",
		planet: 4,
		cost: 8,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "influence",
				resetUsed: !0,
				n: 2
			},
			{
				kind: "condition",
				condition: {
					kind: "credits",
					min: 6
				},
				effect: {
					kind: "influence",
					different: !0,
					n: 1
				}
			}
		]
	},
	{
		id: "Domitian",
		planet: 3,
		cost: 9,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{
				kind: "condition",
				mandatory: !0,
				condition: {
					kind: "pay",
					effect: { kind: "mobilize" }
				},
				effect: {
					kind: "influence",
					n: 1
				}
			},
			{
				kind: "condition",
				mandatory: !0,
				condition: {
					kind: "pay",
					effect: { kind: "mobilize" }
				},
				effect: {
					kind: "influence",
					n: 1
				}
			},
			{
				kind: "condition",
				mandatory: !0,
				condition: {
					kind: "pay",
					effect: { kind: "mobilize" }
				},
				effect: {
					kind: "influence",
					n: 1
				}
			}
		]
	},
	{
		id: "MasterDin",
		planet: 0,
		cost: 6,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{ kind: "leader" }
		]
	},
	{
		id: "LordCreep",
		planet: 2,
		cost: 5,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{
				kind: "influence",
				n: 1,
				enemySide: !0
			},
			{ kind: "leader" }
		]
	},
	{
		id: "Amytis",
		planet: 0,
		cost: 3,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 0,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					planet: 0,
					amounts: [
						2,
						4,
						7
					],
					factors: [
						1,
						2,
						3
					]
				}
			},
			effect: {
				kind: "influence",
				planet: 0
			}
		}]
	},
	{
		id: "W4ts0n",
		planet: 3,
		cost: 1,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{
				kind: "credits",
				n: 5
			},
			{ kind: "mobilize" }
		]
	},
	{
		id: "Arnulf",
		planet: 4,
		cost: 3,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 4,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					planet: 4,
					amounts: [
						2,
						4,
						7
					],
					factors: [
						1,
						2,
						3
					]
				}
			},
			effect: {
				kind: "influence",
				planet: 4
			}
		}]
	},
	{
		id: "R0bins0n",
		planet: 3,
		cost: 2,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					planet: 3,
					amounts: [
						2,
						4,
						7
					],
					factors: [
						2,
						4,
						7
					]
				}
			},
			effect: { kind: "zenithium" }
		}]
	},
	{
		id: "QueenSuzanne",
		planet: 4,
		cost: 10,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "influence",
				resetUsed: !0,
				n: 2
			},
			{
				kind: "zenithium",
				n: 2
			},
			{
				kind: "leader",
				gold: !0
			}
		]
	},
	{
		id: "H4milt0n",
		planet: 0,
		cost: 2,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "mobilize",
				n: 2
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: { kind: "giveLeader" }
				},
				effect: {
					kind: "mobilize",
					n: 3
				}
			}
		]
	},
	{
		id: "Caesar",
		planet: 3,
		cost: 2,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "choice",
			left: [{ kind: "zenithium" }],
			right: [{
				kind: "credits",
				n: 7
			}]
		}]
	},
	{
		id: "IldaFlores",
		planet: 1,
		cost: 1,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "zenithium",
			techCount: [
				1,
				2,
				3
			]
		}]
	},
	{
		id: "H3rb3rt",
		planet: 2,
		cost: 6,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						planet: 0
					}
				},
				effect: {
					kind: "influence",
					planet: 0,
					n: 1
				}
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						planet: 1
					}
				},
				effect: {
					kind: "influence",
					planet: 1,
					n: 1
				}
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						planet: 3
					}
				},
				effect: {
					kind: "influence",
					planet: 3,
					n: 1
				}
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "exile",
						planet: 4
					}
				},
				effect: {
					kind: "influence",
					planet: 4,
					n: 1
				}
			}
		]
	},
	{
		id: "LisaCharity",
		planet: 4,
		cost: 2,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "zenithium",
				n: 2
			},
			{
				kind: "credits",
				opponent: !0,
				n: 3
			}
		]
	},
	{
		id: "SirSam",
		planet: 2,
		cost: 7,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 2,
			n: 1
		}, { kind: "reset" }]
	},
	{
		id: "HiroshiSun",
		planet: 1,
		cost: 1,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 1,
				n: 1
			},
			{
				kind: "credits",
				n: 4
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "giveZenithium",
						n: 1
					}
				},
				effect: {
					kind: "influence",
					planet: 3,
					n: 2
				}
			}
		]
	},
	{
		id: "Magellan",
		planet: 0,
		cost: 10,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "influence",
				resetUsed: !0,
				n: 1
			},
			{
				kind: "influence",
				different: !0,
				n: 1
			},
			{
				kind: "transfer",
				planet: 0
			},
			{
				kind: "transfer",
				planet: 1
			},
			{
				kind: "transfer",
				planet: 2
			},
			{
				kind: "transfer",
				planet: 3
			},
			{
				kind: "transfer",
				planet: 4
			}
		]
	},
	{
		id: "Bajazet",
		planet: 4,
		cost: 3,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 4,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					opponent: !0
				}
			},
			effect: { kind: "credits" }
		}]
	},
	{
		id: "Geta",
		planet: 4,
		cost: 3,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 4,
			n: 1
		}, {
			kind: "choice",
			left: [{
				kind: "leader",
				gold: !0
			}],
			right: [{
				kind: "credits",
				n: 8
			}]
		}]
	},
	{
		id: "Charlemagne",
		planet: 2,
		cost: 8,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{
				kind: "influence",
				resetUsed: !0,
				n: 1
			},
			{
				kind: "influence",
				different: !0,
				n: 1
			},
			{
				kind: "influence",
				different: !0,
				n: 1
			}
		]
	},
	{
		id: "Caligula",
		planet: 3,
		cost: 5,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "condition",
			mandatory: !0,
			condition: {
				kind: "pay",
				effect: { kind: "transfer" }
			},
			effect: {
				kind: "influence",
				n: 1
			}
		}]
	},
	{
		id: "Tiberius",
		planet: 2,
		cost: 3,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 2,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					planet: 2,
					amounts: [
						2,
						4,
						7
					],
					factors: [
						1,
						2,
						3
					]
				}
			},
			effect: {
				kind: "influence",
				planet: 2
			}
		}]
	},
	{
		id: "And3rs0n",
		planet: 3,
		cost: 6,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "influence",
			center: !0,
			n: 2
		}]
	},
	{
		id: "Orw3ll",
		planet: 0,
		cost: 1,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{ kind: "bonus" },
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: { kind: "giveLeader" }
				},
				effect: {
					kind: "credits",
					n: 7
				}
			}
		]
	},
	{
		id: "As1m0v",
		planet: 1,
		cost: 10,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "develop",
			discount: 2
		}]
	},
	{
		id: "HelenaKerr",
		planet: 2,
		cost: 6,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 2,
			n: 1
		}, {
			kind: "influence",
			n: 2,
			except: 2
		}]
	},
	{
		id: "LittleBob",
		planet: 3,
		cost: 3,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "influence",
			except: 3,
			n: 1
		}]
	},
	{
		id: "Bruss0l0",
		planet: 2,
		cost: 1,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 2,
			n: 1
		}, { kind: "zenithium" }]
	},
	{
		id: "B4rj4v3l",
		planet: 4,
		cost: 2,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 4,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					planet: 4,
					amounts: [
						2,
						4,
						7
					],
					factors: [
						2,
						4,
						7
					]
				}
			},
			effect: { kind: "zenithium" }
		}]
	},
	{
		id: "Augustus",
		planet: 2,
		cost: 10,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 2,
			n: 1
		}, {
			kind: "influence",
			n: 2,
			pattern: [
				1,
				2,
				1
			]
		}]
	},
	{
		id: "LulaSmart",
		planet: 0,
		cost: 1,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "credits",
				n: 4
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "giveZenithium",
						n: 1
					}
				},
				effect: {
					kind: "influence",
					planet: 2,
					n: 2
				}
			}
		]
	},
	{
		id: "CharlizeGun",
		planet: 3,
		cost: 4,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{ kind: "mobilize" },
			{ kind: "transfer" },
			{
				kind: "exile",
				opponent: !0
			}
		]
	},
	{
		id: "ProfessorZed",
		planet: 1,
		cost: 9,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "zenithium",
			n: 4
		}]
	},
	{
		id: "IceJune",
		planet: 2,
		cost: 4,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 2,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: { kind: "discard" }
			},
			effect: {
				kind: "influence",
				n: 1
			}
		}]
	},
	{
		id: "V4nV0gt",
		planet: 1,
		cost: 6,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 1,
				n: 1
			},
			{
				kind: "exile",
				opponent: !0,
				n: 2
			},
			{
				kind: "zenithium",
				n: 2
			}
		]
	},
	{
		id: "KingHarold",
		planet: 1,
		cost: 6,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 1,
				n: 1
			},
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{ kind: "leader" }
		]
	},
	{
		id: "Geronimo",
		planet: 1,
		cost: 2,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "credits",
			colorCount: 2
		}]
	},
	{
		id: "W3lls",
		planet: 0,
		cost: 4,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 0,
			n: 1
		}, {
			kind: "condition",
			condition: { kind: "leader" },
			effect: {
				kind: "influence",
				planet: 0,
				n: 1
			}
		}]
	},
	{
		id: "Nero",
		planet: 0,
		cost: 7,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 0,
			n: 1
		}, {
			kind: "zenithium",
			n: 3
		}]
	},
	{
		id: "Cl4rke",
		planet: 0,
		cost: 9,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "influence",
				resetUsed: !0,
				n: 2
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "giveZenithium",
						n: 1
					}
				},
				effect: {
					kind: "influence",
					different: !0,
					n: 2
				}
			}
		]
	},
	{
		id: "Chaka",
		planet: 0,
		cost: 1,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 0,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					n: 2,
					except: 0
				}
			},
			effect: {
				kind: "credits",
				n: 10
			}
		}]
	},
	{
		id: "M4rt1n",
		planet: 4,
		cost: 4,
		faction: "robot",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 4,
			n: 1
		}, {
			kind: "condition",
			condition: { kind: "leader" },
			effect: {
				kind: "influence",
				planet: 4,
				n: 1
			}
		}]
	},
	{
		id: "Pachacuti",
		planet: 1,
		cost: 3,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					planet: 1,
					amounts: [
						2,
						4,
						7
					],
					factors: [
						1,
						2,
						3
					]
				}
			},
			effect: {
				kind: "influence",
				planet: 1
			}
		}]
	},
	{
		id: "Gibs0n",
		planet: 4,
		cost: 4,
		faction: "robot",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "transfer",
				n: 2
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: { kind: "giveLeader" }
				},
				effect: {
					kind: "transfer",
					n: 2
				}
			}
		]
	},
	{
		id: "HandyLuke",
		planet: 3,
		cost: 4,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 3,
			n: 1
		}, {
			kind: "bonus",
			visible: !0
		}]
	},
	{
		id: "Khan",
		planet: 0,
		cost: 9,
		faction: "animod",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "influence",
				resetUsed: !0,
				n: 2
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: { kind: "giveLeader" }
				},
				effect: {
					kind: "influence",
					n: 2,
					different: !0
				}
			}
		]
	},
	{
		id: "Moussa",
		planet: 1,
		cost: 2,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "credits",
			techCount: [
				4,
				8,
				12
			]
		}]
	},
	{
		id: "Archimedes",
		planet: 1,
		cost: 6,
		faction: "animod",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "develop",
			discount: 1,
			faction: "animod"
		}]
	},
	{
		id: "SneakyJules",
		planet: 2,
		cost: 1,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{
				kind: "credits",
				n: 4
			},
			{
				kind: "condition",
				condition: {
					kind: "pay",
					effect: {
						kind: "giveZenithium",
						n: 1
					}
				},
				effect: {
					kind: "influence",
					n: 2,
					center: !0
				}
			}
		]
	},
	{
		id: "SecretKali",
		planet: 0,
		cost: 2,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 0,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: {
					kind: "giveCredits",
					n: 3
				}
			},
			effect: {
				kind: "influence",
				n: 2,
				except: 0
			}
		}]
	},
	{
		id: "CaptainAndreev",
		planet: 4,
		cost: 4,
		faction: "human",
		expansion: !1,
		effects: [{
			kind: "influence",
			planet: 4,
			n: 1
		}, {
			kind: "condition",
			condition: {
				kind: "pay",
				effect: { kind: "transfer" }
			},
			effect: { kind: "credits" }
		}]
	},
	{
		id: "MiladyJones",
		planet: 4,
		cost: 6,
		faction: "human",
		expansion: !1,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{ kind: "leader" }
		]
	},
	{
		id: "AdmiralJack",
		planet: 4,
		cost: 5,
		faction: "human",
		expansion: !0,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "influence",
				n: 1,
				resetUsed: !0
			},
			{
				kind: "condition",
				condition: {
					kind: "enemyZenithium",
					min: 3
				},
				effect: {
					kind: "influence",
					n: 1,
					different: !0
				}
			}
		]
	},
	{
		id: "Mungo",
		planet: 2,
		cost: 5,
		faction: "animod",
		expansion: !0,
		effects: [{
			kind: "influence",
			planet: 2,
			n: 1
		}, {
			kind: "choice",
			left: [{
				kind: "influence",
				planet: 0,
				n: 1
			}, {
				kind: "influence",
				planet: 1,
				n: 1
			}],
			right: [{
				kind: "influence",
				planet: 3,
				n: 1
			}, {
				kind: "influence",
				planet: 4,
				n: 1
			}]
		}]
	},
	{
		id: "S1mmons",
		planet: 0,
		cost: 0,
		faction: "robot",
		expansion: !0,
		effects: [
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "credits",
				upTo: 8
			},
			{
				kind: "credits",
				upTo: 8,
				opponent: !0
			}
		]
	},
	{
		id: "W1ll1s",
		planet: 3,
		cost: 5,
		faction: "robot",
		expansion: !0,
		effects: [
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{
				kind: "giveInfluence",
				n: 2,
				except: 3,
				resetUsed: !0
			},
			{
				kind: "influence",
				n: 2,
				different: !0
			},
			{
				kind: "leader",
				gold: !0
			}
		]
	},
	{
		id: "PrincessUxmal",
		planet: 0,
		cost: 5,
		faction: "human",
		expansion: !0,
		effects: [{
			kind: "influence",
			planet: 0,
			n: 1
		}, {
			kind: "condition",
			condition: { kind: "enemyLeader" },
			effect: {
				kind: "influence",
				pattern: [1, 1]
			}
		}]
	},
	{
		id: "CelestinPetit",
		planet: 2,
		cost: 0,
		faction: "human",
		expansion: !0,
		effects: [{
			kind: "influence",
			planet: 2,
			n: 1
		}, {
			kind: "develop",
			lowest: !0
		}]
	},
	{
		id: "Ragnar",
		planet: 3,
		cost: 0,
		faction: "animod",
		expansion: !0,
		effects: [
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{
				kind: "zenithium",
				upTo: 2
			},
			{
				kind: "zenithium",
				upTo: 2,
				opponent: !0
			}
		]
	},
	{
		id: "DandyMuller",
		planet: 1,
		cost: 0,
		faction: "human",
		expansion: !0,
		effects: [{
			kind: "influence",
			planet: 1,
			n: 1
		}, {
			kind: "influence",
			enemySide: !0,
			n: 1
		}]
	},
	{
		id: "Boull3",
		planet: 1,
		cost: 5,
		faction: "robot",
		expansion: !0,
		effects: [
			{
				kind: "influence",
				planet: 1,
				n: 1
			},
			{
				kind: "influence",
				n: 1
			},
			{
				kind: "condition",
				condition: {
					kind: "enemyCredits",
					min: 15
				},
				effect: {
					kind: "influence",
					n: 1
				}
			}
		]
	},
	{
		id: "Demetrios",
		planet: 4,
		cost: 0,
		faction: "animod",
		expansion: !0,
		effects: [
			{
				kind: "influence",
				planet: 4,
				n: 1
			},
			{
				kind: "discard",
				full: !0
			},
			{
				kind: "credits",
				n: 5
			}
		]
	}
], O = Object.fromEntries(te.map((e) => [e.id, e])), ne = {
	S: [
		[{
			kind: "credits",
			n: 2
		}],
		[{
			kind: "influence",
			pattern: [1, 1]
		}, {
			kind: "techBonus",
			faction: "animod"
		}],
		[{
			kind: "transfer",
			n: 3
		}],
		[
			{
				kind: "condition",
				mandatory: !0,
				condition: {
					kind: "pay",
					effect: { kind: "mobilize" }
				},
				effect: {
					kind: "influence",
					n: 1
				}
			},
			{
				kind: "condition",
				mandatory: !0,
				condition: {
					kind: "pay",
					effect: { kind: "mobilize" }
				},
				effect: {
					kind: "influence",
					n: 1
				}
			},
			{
				kind: "condition",
				mandatory: !0,
				condition: {
					kind: "pay",
					effect: { kind: "mobilize" }
				},
				effect: {
					kind: "influence",
					n: 1
				}
			}
		],
		[{
			kind: "influence",
			n: 2
		}]
	],
	U: [
		[{
			kind: "influence",
			n: 1
		}],
		[{
			kind: "mobilize",
			n: 2
		}, {
			kind: "techBonus",
			faction: "human"
		}],
		[{
			kind: "stealCredits",
			n: 3
		}],
		[{
			kind: "influence",
			pattern: [
				1,
				1,
				1
			]
		}],
		[{
			kind: "influence",
			n: 2
		}]
	],
	N: [
		[{
			kind: "transfer",
			n: 1
		}],
		[{ kind: "leader" }, {
			kind: "techBonus",
			faction: "robot"
		}],
		[{
			kind: "influence",
			resetUsed: !0,
			n: 2
		}, {
			kind: "influence",
			different: !0,
			n: 1
		}],
		[{
			kind: "credits",
			n: 20
		}],
		[{
			kind: "influence",
			resetUsed: !0,
			n: 2
		}]
	],
	D: [
		[{
			kind: "exile",
			opponent: !0,
			n: 1
		}],
		[{
			kind: "credits",
			n: 5
		}, {
			kind: "techBonus",
			faction: "animod"
		}],
		[{ kind: "bonus" }, {
			kind: "influence",
			n: 1
		}],
		[
			{
				kind: "influence",
				planet: 0,
				n: 1
			},
			{
				kind: "influence",
				planet: 1,
				n: 1
			},
			{
				kind: "influence",
				planet: 2,
				n: 1
			},
			{
				kind: "influence",
				planet: 3,
				n: 1
			},
			{
				kind: "influence",
				planet: 4,
				n: 1
			}
		],
		[{
			kind: "influence",
			n: 2
		}]
	],
	O: [
		[{ kind: "bonus" }],
		[{
			kind: "stealZenithium",
			n: 1
		}, {
			kind: "techBonus",
			faction: "human"
		}],
		[{
			kind: "mobilize",
			n: 3
		}],
		[{
			kind: "influence",
			pattern: [2, 2]
		}],
		[{
			kind: "influence",
			n: 2
		}]
	],
	P: [
		[{
			kind: "mobilize",
			n: 1
		}],
		[
			{
				kind: "mobilize",
				n: 1
			},
			{
				kind: "transfer",
				n: 1
			},
			{
				kind: "exile",
				opponent: !0,
				n: 1
			},
			{
				kind: "techBonus",
				faction: "robot"
			}
		],
		[{
			kind: "credits",
			n: 10
		}],
		[{
			kind: "condition",
			mandatory: !0,
			condition: {
				kind: "pay",
				effect: { kind: "exile" }
			},
			effect: {
				kind: "influence",
				resetUsed: !0,
				n: 2
			}
		}, {
			kind: "condition",
			mandatory: !0,
			condition: {
				kind: "pay",
				effect: {
					kind: "exile",
					different: !0
				}
			},
			effect: {
				kind: "influence",
				n: 2
			}
		}],
		[{
			kind: "influence",
			n: 2
		}]
	]
}, k = {
	Exile2OpponentCards: {
		kind: "exile",
		n: 2,
		opponent: !0
	},
	Mobilize2: {
		kind: "mobilize",
		n: 2
	},
	TakeLeaderBadge: { kind: "leader" },
	Transfer: { kind: "transfer" },
	Win1Zenithium: {
		kind: "zenithium",
		n: 1
	},
	Win3Credits: {
		kind: "credits",
		n: 3
	},
	Win4Credits: {
		kind: "credits",
		n: 4
	},
	WinInfluence: {
		kind: "influence",
		n: 1
	}
}, re = [
	"WinInfluence",
	"WinInfluence",
	"WinInfluence",
	"WinInfluence",
	"Win3Credits",
	"Win3Credits",
	"Win4Credits",
	"Win4Credits",
	"Win1Zenithium",
	"Win1Zenithium",
	"Win1Zenithium",
	"Exile2OpponentCards",
	"Mobilize2",
	"Transfer",
	"TakeLeaderBadge",
	"TakeLeaderBadge"
], A = {
	id: "zenith",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"engine-building",
		"area-control",
		"set-collection"
	],
	interactionTags: ["team-based"],
	nameKey: "games.zenith.name",
	descKey: "games.zenith.desc",
	rulesKey: "games.zenith.rules",
	icon: "🪐",
	iconImg: "games/zenith.webp",
	rulesUrl: { en: "https://www.playpunk.com/src/downloads/RGB/ZE_Rules_EN.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2, 4],
	playerRange: (e) => {
		let t = !!e && typeof e == "object" && "mode" in e && e.mode === "team";
		return {
			min: t ? 4 : 2,
			max: t ? 4 : 2
		};
	},
	accent: "#7455a5",
	releasedAt: "2026-10-29T02:54:09+08:00",
	search: {
		py: "tian ding xing yu",
		init: "tdxy"
	},
	hotseat: "cover"
}, ie = t.object({
	mode: t.enum(["duel", "team"]).catch("duel"),
	secretAgents: t.boolean().catch(!1),
	technology: t.enum(["sun", "random"]).catch("sun")
}).default({
	mode: "duel",
	secretAgents: !1,
	technology: "sun"
}), j = t.enum([
	"animod",
	"human",
	"robot"
]), ae = t.int().min(0).max(4), oe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("teams"),
		order: t.array(t.string()).length(4)
	}),
	t.object({ type: t.literal("start") }),
	t.object({
		type: t.literal("mulligan"),
		cards: t.array(t.string()).max(4)
	}),
	t.object({
		type: t.literal("order"),
		rid: t.string()
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("play"),
		card: t.string(),
		use: t.enum([
			"recruit",
			"develop",
			"leader"
		])
	}),
	t.object({
		type: t.literal("choose"),
		id: t.string()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), se = t.object({
	id: t.string(),
	label: t.enum([
		"planet",
		"card",
		"quantity",
		"technology",
		"left",
		"right",
		"skip",
		"bonus",
		"player",
		"continue",
		"pattern"
	]),
	planet: ae.optional(),
	card: t.string().optional(),
	amount: t.number().optional(),
	faction: j.optional(),
	slot: t.int().optional(),
	rid: t.string().optional(),
	planets: t.array(ae).optional()
}), ce = t.object({
	credits: t.int().nonnegative(),
	zenithium: t.int().nonnegative(),
	columns: t.array(t.array(t.string())).length(5),
	tech: t.array(t.int().min(0).max(5)).length(3),
	discs: t.array(t.int().nonnegative()).length(5),
	rows: t.int().nonnegative()
}), le = t.object({
	phase: t.enum([
		"teams",
		"mulligan",
		"order",
		"turn",
		"resolve",
		"choice",
		"done"
	]),
	mode: t.enum(["duel", "team"]),
	secretAgents: t.boolean(),
	players: t.array(t.object({
		rid: t.string(),
		team: t.int().min(0).max(1),
		role: t.int().min(0).max(1),
		handCount: t.int().nonnegative(),
		mulligan: t.boolean()
	})),
	teams: t.array(ce).length(2),
	activeTeam: t.int().min(0).max(1),
	turn: t.string(),
	turnNumber: t.int().positive(),
	acted: t.array(t.string()),
	planets: t.array(t.int().min(-3).max(3).nullable()).length(5),
	planetBonuses: t.array(t.string().nullable()).length(5),
	techBonuses: t.array(t.string().nullable()).length(3),
	boards: t.array(t.string()).length(3),
	leader: t.object({
		team: t.int().min(0).max(1),
		gold: t.boolean()
	}).nullable(),
	deckCount: t.int().nonnegative(),
	discard: t.array(t.string()),
	bonusCount: t.int().nonnegative(),
	bonusDiscard: t.array(t.string()),
	pending: t.object({
		who: t.string(),
		source: t.string(),
		kind: t.string(),
		optional: t.boolean(),
		effect: t.object({ kind: t.string() }).passthrough().optional(),
		follow: t.object({ kind: t.string() }).passthrough().optional()
	}).nullable(),
	history: t.array(t.object({
		kind: t.enum([
			"recruit",
			"develop",
			"leader",
			"influence",
			"capture",
			"credits",
			"zenithium",
			"exile",
			"transfer",
			"mobilize",
			"discard",
			"bonus",
			"give",
			"mulligan",
			"pass"
		]),
		who: t.string(),
		card: t.string().optional(),
		planet: ae.optional(),
		amount: t.number().optional(),
		faction: j.optional(),
		bonus: t.string().optional()
	})),
	winner: t.int().min(0).max(1).nullable(),
	victory: t.enum([
		"absolute",
		"democratic",
		"popular",
		"draw"
	]).nullable()
}), ue = t.object({
	hand: t.array(t.string()),
	moves: t.array(oe),
	choices: t.array(se)
}), M = [
	0,
	1,
	2,
	3,
	4
], N = [
	"animod",
	"human",
	"robot"
], P = (e, t) => e.players.find((e) => e.rid === t), F = (e, t) => P(e, t).team, de = (e, t) => e.teams[F(e, t)], fe = (e, t) => e.teams[1 - F(e, t)], pe = (e) => e === 0 ? 1 : -1, I = (e) => e.n ?? 1;
function L(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function R(e) {
	return !e.deck.length && e.discard.length && (e.deck = L(e, e.discard.splice(0))), e.deck.pop();
}
function z(e, t) {
	e.history.push(t);
}
function B(e, t, n) {
	let r = ++e.serial;
	return e.frames[r] = { used: [] }, {
		who: t,
		source: n,
		frame: r
	};
}
var V = (e, t) => t.map((t) => ({
	kind: "effect",
	...e,
	effect: structuredClone(t)
}));
function me(e) {
	e.config.mode === "team" ? e.phase = "order" : (e.turn = e.players.find((t) => t.team === e.activeTeam).rid, e.phase = "turn");
}
function H(t, n, r) {
	let i = ie.parse(t);
	if (n.length !== (i.mode === "team" ? 4 : 2)) throw Error("Invalid Zenith player count");
	let a = () => ({
		credits: 12,
		zenithium: 1,
		columns: M.map(() => []),
		tech: [
			0,
			0,
			0
		],
		discs: [
			0,
			0,
			0,
			0,
			0
		],
		rows: 0
	}), o = {
		config: i,
		seed: r,
		cursor: 0,
		phase: i.mode === "team" ? "teams" : "mulligan",
		players: n.map((e, t) => ({
			rid: e,
			team: i.mode === "team" ? Math.floor(t / 2) : t,
			role: t % 2,
			hand: [],
			mulligan: !1
		})),
		teams: [a(), a()],
		activeTeam: 0,
		turn: "",
		acted: [],
		turnNumber: 1,
		deck: [],
		discard: [],
		planets: [
			0,
			0,
			0,
			0,
			0
		],
		planetBonuses: [],
		techBonuses: [],
		bonusDeck: [],
		bonusDiscard: [],
		boards: [],
		leader: null,
		tasks: [],
		pending: null,
		frames: {},
		serial: 0,
		winner: null,
		victory: null,
		history: []
	};
	o.deck = L(o, te.filter((e) => i.secretAgents || !e.expansion).map((e) => e.id)), o.bonusDeck = L(o, [...re]), o.planetBonuses = M.map(() => o.bonusDeck.pop()), o.techBonuses = N.map(() => o.bonusDeck.pop()), o.boards = [
		["S", "D"],
		["U", "O"],
		["N", "P"]
	].map((t) => t[i.technology === "random" ? e(o.seed, o.cursor++, 2) : 0]), o.activeTeam = e(o.seed, o.cursor++, 2);
	for (let e of o.players) for (let t = 0; t < 4; t++) e.hand.push(R(o));
	let s = pe(1 - o.activeTeam);
	return i.mode === "team" ? (o.planets[1] = s, o.planets[3] = s) : o.planets[2] = s, { state: o };
}
function he(e, t) {
	let n = e.teams[t].discs, r = n.some((e) => e >= 3) ? "absolute" : n.filter((e) => e > 0).length >= 4 ? "democratic" : n.reduce((e, t) => e + t, 0) >= 5 ? "popular" : null;
	r && (e.winner = t, e.victory = r, e.phase = "done", e.tasks = [], e.pending = null);
}
function ge(e, t, n) {
	e.bonusDiscard.push(t), z(e, {
		kind: "bonus",
		who: n,
		bonus: t
	}), e.tasks.unshift(...V(B(e, n, `bonus:${t}`), [k[t]]));
}
function _e(e, t, n, r, i) {
	let a = e.planets[n];
	if (a == null) return;
	let o = a + pe(i) * r;
	e.frames[t.frame].used.push(n);
	let s = i === F(e, t.who) ? t.who : e.players.find((e) => e.team === i).rid;
	if (z(e, {
		kind: "influence",
		who: s,
		planet: n,
		amount: r
	}), Math.abs(o) >= 4) {
		if (e.planets[n] = null, e.teams[i].discs[n]++, z(e, {
			kind: "capture",
			who: s,
			planet: n
		}), he(e, i), e.phase === "done") return;
		let t = e.planetBonuses[n];
		t && (e.planetBonuses[n] = null, ge(e, t, s));
	} else e.planets[n] = o;
}
function ve(e, t) {
	let n = t.effect, r = e.frames[t.frame], i = pe(F(e, t.who)), a = M.filter((t) => e.planets[t] != null && (n.planet == null || t === n.planet) && t !== n.except && (!n.different || !r.used.includes(t)) && (!n.center || e.planets[t] === 0));
	return n.enemySide && (a = a.filter((t) => e.planets[t] * i < 0)), a;
}
function ye(e, t, n, r) {
	return r.free ? 0 : Math.max(0, de(e, t).tech[n] + 1 - (r.discount ?? 0));
}
function be(e, t) {
	let n = structuredClone(e);
	return n.kind === "influence" ? t.factor == null ? (n.n ??= t.amount, n.planet ??= t.planet) : n.points = t.factor : (n.kind === "credits" || n.kind === "zenithium") && (n.n ??= t.amount), n;
}
function xe(e, t) {
	if (t.card && O[t.card]) return {
		amount: O[t.card].cost,
		planet: O[t.card].planet
	};
	let n = e.effect;
	if (n.amounts && t.amount != null) {
		let e = n.factors?.[n.amounts.indexOf(t.amount)] ?? 1;
		return n.kind === "exile" ? { amount: e } : { factor: e };
	}
	return { amount: 1 };
}
function Se(e, t) {
	let n = t.effect, r = de(e, t.who), i = fe(e, t.who), a = (e, t = {}) => ({
		id: "",
		label: e,
		...t
	}), o = [];
	switch (n.kind) {
		case "influence":
		case "giveInfluence":
		case "reset":
			if (n.pattern) {
				let t = n.pattern.length;
				o = (t === 3 && n.pattern[1] === 2 ? [
					-1,
					0,
					1,
					2,
					3
				] : M.filter((e) => e + t <= 5)).map((t) => {
					let r = n.pattern.flatMap((n, r) => t + r >= 0 && t + r < 5 && e.planets[t + r] != null ? [t + r] : []);
					return a("pattern", {
						amount: t,
						planets: r
					});
				}).filter((e) => e.planets.length > 0);
			} else o = ve(e, t).map((e) => a("planet", {
				planet: e,
				amount: I(n)
			})), n.points && (o = o.flatMap((e) => Array.from({ length: n.points }, (t, n) => ({
				...e,
				amount: n + 1
			}))));
			break;
		case "exile":
		case "transfer": {
			let s = n.kind === "transfer" || n.opponent ? i.columns : r.columns;
			for (let r of M) if (!(n.planet != null && r !== n.planet || r === n.except || n.different && e.frames[t.frame].used.includes(r))) {
				if (n.amounts) for (let e of n.amounts) s[r].length >= e && o.push(a("quantity", {
					planet: r,
					amount: e
				}));
				else {
					let e = s[r].at(-1);
					e && o.push(a("card", {
						planet: r,
						card: e
					}));
				}
			}
			if (t.follow && !n.amounts) {
				let e = o.reduce((e, t) => e + (n.different ? 1 : s[t.planet].length), 0);
				(t.remaining ?? I(n)) > e && (o = []);
			}
			break;
		}
		case "discard":
			o = n.full ? P(e, t.who).hand.length ? [a("continue")] : [] : P(e, t.who).hand.map((e) => a("card", { card: e }));
			break;
		case "share":
			o = P(e, t.who).hand.map((e) => a("card", { card: e }));
			break;
		case "spendCredits":
		case "spendZenithium": {
			let e = n.kind === "spendCredits" ? r.credits : r.zenithium;
			o = (n.amounts ?? [I(n)]).filter((t) => e >= t).map((e) => a("quantity", { amount: e }));
			break;
		}
		case "giveCredits":
			r.credits >= I(n) && (o = [a("continue")]);
			break;
		case "giveZenithium":
			r.zenithium >= I(n) && (o = [a("continue")]);
			break;
		case "giveLeader":
			e.leader?.team === F(e, t.who) && (o = [a("continue")]);
			break;
		case "develop": {
			let i = Math.min(...r.tech);
			o = N.flatMap((o, s) => r.tech[s] < 5 && (!n.faction || n.faction === o) && (!n.lowest || r.tech[s] === i) && r.zenithium >= ye(e, t.who, s, n) ? [a("technology", {
				faction: o,
				amount: ye(e, t.who, s, n)
			})] : []);
			break;
		}
		case "bonus":
			o = n.visible ? [...e.planetBonuses, ...e.techBonuses].flatMap((e, t) => e ? [a("bonus", {
				slot: t,
				card: e
			})] : []) : e.bonusDeck.length + e.bonusDiscard.length > 0 ? [a("continue")] : [];
			break;
		case "techBonus":
			e.techBonuses[N.indexOf(n.faction)] && (o = [a("continue")]);
			break;
		case "choice":
			o = [a("left"), a("right")];
			break;
		case "mobilize":
			e.deck.length + e.discard.length && (o = [a("continue")]);
			break;
		default: o = [a("continue")];
	}
	return t.follow && (o = o.filter((n) => {
		let r = be(t.follow, xe(t, n));
		return r.kind !== "influence" || r.pattern || ve(e, {
			...t,
			effect: r
		}).length > 0;
	})), (t.optional || n.optional || n.kind === "share") && o.push(a("skip")), o;
}
function Ce(e, t, n) {
	t.follow && e.tasks.unshift({
		...t,
		effect: be(t.follow, n),
		follow: void 0,
		optional: !1,
		remaining: void 0
	});
}
function we(e, t, n) {
	if (n.label === "skip") return;
	let r = t.effect, i = de(e, t.who), a = fe(e, t.who), o = F(e, t.who), s = e.tasks.length, c = xe(t, n), l = !1, u = (n) => {
		let r = (t.remaining ?? n) - 1;
		r > 0 && (e.tasks.unshift({
			...t,
			optional: !1,
			remaining: r
		}), l = !0);
	};
	switch (r.kind) {
		case "influence":
		case "giveInfluence": {
			if (r.pattern) {
				let i = r.pattern.flatMap((t, r) => n.amount + r >= 0 && n.amount + r < 5 && e.planets[n.amount + r] != null ? [{
					planet: n.amount + r,
					amount: t
				}] : []);
				e.tasks.unshift({
					kind: "pattern",
					who: t.who,
					source: t.source,
					frame: t.frame,
					targets: i
				});
				break;
			}
			let i = r.points ? n.amount : I(r);
			r.points && r.points > i && e.tasks.unshift({
				...t,
				effect: {
					...r,
					points: r.points - i
				},
				optional: !1
			}), _e(e, t, n.planet, i, r.kind === "giveInfluence" ? 1 - o : o);
			break;
		}
		case "reset":
			e.planets[n.planet] = 0, z(e, {
				kind: "influence",
				who: t.who,
				planet: n.planet,
				amount: 0
			});
			break;
		case "credits":
		case "zenithium": {
			let n = r.opponent ? a : i, s = I(r);
			r.upTo != null && (s = Math.max(0, r.upTo - n[r.kind])), r.colorCount != null && (s = i.columns.filter((e) => e.length).length * r.colorCount), r.enemyColorCount != null && (s = a.columns.filter((e) => e.length).length * r.enemyColorCount), r.techCount && (s = r.techCount[i.tech.filter((e) => e > 0).length - 1] ?? 0), n[r.kind] += s, z(e, {
				kind: r.kind,
				who: r.opponent ? e.players.find((e) => e.team !== o).rid : t.who,
				amount: s
			});
			break;
		}
		case "giveCredits":
		case "giveZenithium": {
			let n = r.kind === "giveCredits" ? "credits" : "zenithium";
			i[n] -= I(r), a[n] += I(r), z(e, {
				kind: "give",
				who: t.who,
				amount: I(r),
				bonus: n
			});
			break;
		}
		case "spendCredits":
		case "spendZenithium":
			i[r.kind === "spendCredits" ? "credits" : "zenithium"] -= n.amount;
			break;
		case "stealCredits":
		case "stealZenithium": {
			let n = r.kind === "stealCredits" ? "credits" : "zenithium", o = Math.min(a[n], I(r));
			i[n] += o, a[n] -= o, z(e, {
				kind: n,
				who: t.who,
				amount: o
			});
			break;
		}
		case "exile":
		case "transfer": {
			let o = r.kind === "transfer" || r.opponent ? a.columns : i.columns, s = n.planet, c = r.amounts ? n.amount : 1;
			for (let n = 0; n < c; n++) {
				let n = o[s].pop();
				r.kind === "transfer" ? i.columns[s].push(n) : e.discard.push(n), z(e, {
					kind: r.kind,
					who: t.who,
					card: n,
					planet: s
				});
			}
			r.amounts || u(I(r));
			break;
		}
		case "discard": {
			let i = P(e, t.who).hand, a = r.full ? i.splice(0) : i.splice(i.indexOf(n.card), 1);
			e.discard.push(...a);
			for (let n of a) z(e, {
				kind: "discard",
				who: t.who,
				card: n
			});
			break;
		}
		case "mobilize": {
			let n = R(e);
			if (!n) return;
			let s = O[n].planet;
			(r.opponent ? a : i).columns[s].push(n), c = {
				amount: 1,
				planet: s
			}, z(e, {
				kind: "mobilize",
				who: r.opponent ? e.players.find((e) => e.team !== o).rid : t.who,
				card: n,
				planet: s
			}), u(I(r));
			break;
		}
		case "leader":
			e.leader = {
				team: o,
				gold: !!r.gold || e.leader?.team === o
			}, z(e, {
				kind: "leader",
				who: t.who,
				amount: e.leader.gold ? 6 : 5
			});
			break;
		case "giveLeader":
			e.leader = {
				team: 1 - o,
				gold: !1
			}, z(e, {
				kind: "give",
				who: t.who,
				bonus: "leader"
			});
			break;
		case "develop": {
			let a = N.indexOf(n.faction), o = i.tech[a] + 1;
			i.zenithium -= ye(e, t.who, a, r), i.tech[a] = o;
			let s = B(e, t.who, `tech:${e.boards[a]}:${o}`), c = ne[e.boards[a]].slice(0, o).reverse().flat();
			e.tasks.unshift(...V(s, c), {
				kind: "row",
				...s,
				level: Math.min(...i.tech, 3)
			}), z(e, {
				kind: "develop",
				who: t.who,
				faction: n.faction,
				amount: o
			});
			break;
		}
		case "bonus": {
			let i;
			r.visible ? (i = n.slot < 5 ? e.planetBonuses[n.slot] : e.techBonuses[n.slot - 5], n.slot < 5 ? e.planetBonuses[n.slot] = null : e.techBonuses[n.slot - 5] = null) : (e.bonusDeck.length || (e.bonusDeck = L(e, e.bonusDiscard.splice(0))), i = e.bonusDeck.pop()), i && ge(e, i, t.who);
			break;
		}
		case "techBonus": {
			let n = N.indexOf(r.faction), i = e.techBonuses[n];
			i && (e.techBonuses[n] = null, ge(e, i, t.who));
			break;
		}
		case "choice":
			e.tasks.unshift(...V(t, n.label === "left" ? r.left : r.right));
			break;
		case "share": {
			let i = P(e, t.who), a = e.players.find((e) => e.team === o && e.rid !== t.who);
			i.hand.splice(i.hand.indexOf(n.card), 1), a.hand.push(n.card), z(e, {
				kind: "give",
				who: t.who,
				amount: 1,
				bonus: "card"
			}), u(r.n ?? 2);
			break;
		}
	}
	if (!l && e.phase !== "done") {
		let n = e.tasks.length - s, r = e.tasks.splice(0, Math.max(0, n));
		Ce(e, t, c), e.tasks.unshift(...r);
	}
}
function Te(e, t) {
	let n = t.effect.condition, r = de(e, t.who), i = fe(e, t.who), a = F(e, t.who);
	switch (n.kind) {
		case "leader": return e.leader?.team === a;
		case "credits": return r.credits >= n.min;
		case "enemyCredits": return i.credits >= n.min;
		case "enemyZenithium": return i.zenithium >= n.min;
		case "enemyLeader": return e.leader?.team === 1 - a;
		default: return !0;
	}
}
function Ee(e, t) {
	let n = P(e, t), r = e.leader?.team === n.team ? e.leader.gold ? 6 : 5 : 4;
	for (; n.hand.length < r;) {
		let t = R(e);
		if (!t) break;
		n.hand.push(t);
	}
	if (e.planets = e.planets.map((e) => e ?? 0), e.frames = {}, e.pending = null, e.turnNumber++, !e.deck.length && !e.discard.length && e.players.every((e) => !e.hand.length)) {
		e.phase = "done", e.victory = "draw", e.tasks = [];
		return;
	}
	e.acted.push(t);
	let i = e.players.find((t) => t.team === e.activeTeam && !e.acted.includes(t.rid));
	i ? (e.turn = i.rid, e.phase = "turn") : (e.activeTeam = 1 - e.activeTeam, e.acted = [], me(e));
}
function De(e) {
	for (; e.tasks.length && e.phase !== "done";) {
		let t = e.tasks.shift();
		if (t.kind === "end") {
			Ee(e, t.who);
			return;
		}
		if (t.kind === "row") {
			let n = de(e, t.who);
			if (t.level > n.rows) {
				let r = Array.from({ length: t.level - n.rows }, (e, t) => n.rows + t + 1);
				n.rows = t.level, e.tasks.unshift(...V(t, r.map((e) => ({
					kind: "influence",
					n: e
				}))));
			}
			continue;
		}
		if (t.kind === "pattern") {
			let n = t.targets.filter((t) => e.planets[t.planet] != null);
			if (!n.length) continue;
			let r = n.map((t) => ({
				id: String(++e.serial),
				label: "planet",
				planet: t.planet,
				amount: t.amount
			}));
			e.pending = {
				task: {
					...t,
					targets: n
				},
				options: r
			}, e.phase = "choice";
			return;
		}
		let n = t.effect;
		if (n.resetUsed && (e.frames[t.frame].used = [], t.effect = {
			...n,
			resetUsed: !1
		}), n.kind === "condition") {
			n.condition.kind === "pay" ? e.tasks.unshift({
				...t,
				effect: n.condition.effect,
				follow: n.effect,
				optional: !n.mandatory
			}) : Te(e, t) && e.tasks.unshift({
				...t,
				effect: n.effect
			});
			continue;
		}
		let r = Se(e, t);
		if (r.length && !r.every((e) => e.label === "skip")) {
			if (r.length === 1 && !t.optional && n.kind !== "choice" && n.kind !== "share") {
				we(e, t, r[0]);
				return;
			}
			e.pending = {
				task: t,
				options: r.map((t) => ({
					...t,
					id: String(++e.serial)
				}))
			}, e.phase = "choice";
			return;
		}
	}
}
function Oe(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n) return [];
	if (e.phase === "mulligan") return n.mulligan ? [] : [{
		type: "mulligan",
		cards: []
	}];
	if (e.phase === "order") return n.team === e.activeTeam ? e.players.filter((t) => t.team === e.activeTeam).map((e) => ({
		type: "order",
		rid: e.rid
	})) : [];
	if (e.phase === "choice") return e.pending?.task.who === t ? e.pending.options.map((e) => ({
		type: "choose",
		id: e.id
	})) : [];
	if (e.phase !== "turn" || e.turn !== t) return [];
	if (!n.hand.length) return [{ type: "pass" }];
	let r = e.teams[n.team];
	return n.hand.flatMap((t) => {
		let i = O[t], a = [{
			type: "play",
			card: t,
			use: "leader"
		}];
		(e.config.mode === "duel" || (n.role === 0 ? i.planet <= 2 : i.planet >= 2)) && r.credits >= Math.max(0, i.cost - r.columns[i.planet].length) && a.unshift({
			type: "play",
			card: t,
			use: "recruit"
		});
		let o = r.tech[N.indexOf(i.faction)];
		return o < 5 && r.zenithium >= o + 1 && a.push({
			type: "play",
			card: t,
			use: "develop"
		}), a;
	});
}
function ke(e, t, n) {
	let r = e.players.find((e) => e.rid === n.by), i = { code: "games.zenith.errors.illegal" };
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.phase !== "resolve") return i;
		let t = structuredClone(e);
		return De(t), { state: t };
	}
	if (!r) return i;
	if (t.type === "teams" || t.type === "start") {
		if (e.phase !== "teams" || n.by !== e.players[0].rid) return i;
		let r = structuredClone(e);
		if (t.type === "teams") {
			if (new Set(t.order).size !== 4 || t.order.some((e) => !r.players.some((t) => t.rid === e))) return i;
			t.order.forEach((e, t) => {
				let n = P(r, e);
				n.team = Math.floor(t / 2), n.role = t % 2;
			});
		} else r.phase = "mulligan";
		return { state: r };
	}
	if (t.type === "mulligan") {
		if (e.phase !== "mulligan" || r.mulligan || new Set(t.cards).size !== t.cards.length || t.cards.some((e) => !r.hand.includes(e))) return i;
		let a = structuredClone(e), o = P(a, n.by);
		o.hand = o.hand.filter((e) => !t.cards.includes(e)), a.discard.push(...t.cards);
		for (let e = 0; e < t.cards.length; e++) {
			let e = R(a);
			e && o.hand.push(e);
		}
		return o.mulligan = !0, z(a, {
			kind: "mulligan",
			who: n.by,
			amount: t.cards.length
		}), a.players.every((e) => e.mulligan) && me(a), { state: a };
	}
	if (!Oe(e, n.by).some((e) => JSON.stringify(e) === JSON.stringify(t))) return i;
	let a = structuredClone(e);
	if (t.type === "pass") return z(a, {
		kind: "pass",
		who: n.by
	}), Ee(a, n.by), { state: a };
	if (t.type === "order") return a.turn = t.rid, a.phase = "turn", { state: a };
	if (t.type === "choose") {
		let e = a.pending, n = e.options.find((e) => e.id === t.id), r = e.task;
		if (a.pending = null, a.phase = "resolve", r.kind === "pattern") {
			let e = r.targets.filter((e) => e.planet !== n.planet);
			e.length && a.tasks.unshift({
				...r,
				targets: e
			}), _e(a, r, n.planet, n.amount, F(a, r.who));
		} else we(a, r, n);
		return { state: a };
	}
	if (t.type === "play") {
		let e = P(a, n.by), r = O[t.card], i = a.teams[e.team], o = B(a, n.by, t.card);
		if (e.hand.splice(e.hand.indexOf(t.card), 1), a.tasks = [{
			kind: "end",
			who: n.by
		}], a.phase = "resolve", t.use === "recruit") {
			let e = Math.max(0, r.cost - i.columns[r.planet].length);
			i.credits -= e, i.columns[r.planet].push(t.card), a.tasks.unshift(...V(o, r.effects)), z(a, {
				kind: "recruit",
				who: n.by,
				card: t.card,
				amount: e,
				planet: r.planet
			});
		} else if (a.discard.push(t.card), t.use === "develop") a.tasks.unshift(...V(o, [{
			kind: "develop",
			faction: r.faction
		}]));
		else {
			let e = r.faction === "human" ? {
				kind: "credits",
				n: 3
			} : r.faction === "robot" ? {
				kind: "zenithium",
				n: 1
			} : {
				kind: "mobilize",
				n: 2
			};
			a.tasks.unshift(...V(o, [
				{ kind: "leader" },
				e,
				...a.config.mode === "team" ? [{
					kind: "share",
					n: 2
				}] : []
			]));
		}
	}
	return { state: a };
}
function Ae(e, t, n) {
	let r = ke(e, t, n);
	if (!("state" in r)) return r;
	let i = r.state, a = [];
	if (t.type === "play") {
		let r = P(e, n.by);
		a.push({
			kind: "zenPlay",
			rid: n.by,
			data: {
				card: t.card,
				team: r.team,
				use: t.use
			}
		});
	}
	for (let t of M) for (let n = 0; n < 2; n++) i.teams[n].discs[t] > e.teams[n].discs[t] && a.push({
		kind: "zenCapture",
		data: {
			team: n,
			planet: t
		}
	});
	for (let t = 0; t < 2; t++) for (let n = 0; n < 3; n++) i.teams[t].tech[n] > e.teams[t].tech[n] && a.push({
		kind: "zenTech",
		data: {
			team: t,
			track: n
		}
	});
	JSON.stringify(i.leader) !== JSON.stringify(e.leader) && a.push({ kind: "zenLeader" });
	for (let t of i.players) {
		let n = P(e, t.rid).hand.length;
		(e.pending?.task.kind !== "effect" || e.pending.task.effect.kind !== "share") && t.hand.length > n && a.push({
			kind: "zenDraw",
			rid: t.rid,
			data: {
				team: t.team,
				count: t.hand.length - n
			}
		});
	}
	return {
		...r,
		fx: a.map((e, t) => t ? {
			...e,
			with: !0
		} : e)
	};
}
function je(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.pending?.task;
	return {
		public: {
			phase: e.phase,
			mode: e.config.mode,
			secretAgents: e.config.secretAgents,
			players: e.players.map(({ hand: e, ...t }) => ({
				...t,
				handCount: e.length
			})),
			teams: e.teams,
			activeTeam: e.activeTeam,
			turn: e.turn,
			turnNumber: e.turnNumber,
			acted: e.acted,
			planets: e.planets,
			planetBonuses: e.planetBonuses,
			techBonuses: e.techBonuses,
			boards: e.boards,
			leader: e.leader,
			deckCount: e.deck.length,
			discard: e.discard,
			bonusCount: e.bonusDeck.length,
			bonusDiscard: e.bonusDiscard,
			pending: r ? {
				who: r.who,
				source: r.source,
				kind: r.kind === "pattern" ? "influence" : r.effect.kind,
				optional: r.kind === "effect" && !!r.optional,
				effect: r.kind === "pattern" ? void 0 : {
					...r.effect,
					...r.remaining == null ? {} : { n: r.remaining }
				},
				follow: r.kind === "effect" && r.follow ? { ...r.follow } : void 0
			} : null,
			history: e.history,
			winner: e.winner,
			victory: e.victory
		},
		private: {
			hand: n?.hand ?? [],
			moves: Oe(e, t),
			choices: r?.who === t ? e.pending.options : []
		}
	};
}
var Me = {
	meta: A,
	saveCompatibility: { version: "1" },
	schemas: {
		action: oe,
		publicView: le,
		privateView: ue,
		config: ie
	},
	setup: H,
	reduce: Ae,
	viewFor: je,
	nextTickIn: (e) => e.phase === "resolve" ? 240 : null,
	status: (e) => e.phase === "done" ? {
		phase: "done",
		winner: e.players.filter((t) => t.team === e.winner).map((e) => e.rid),
		ranking: [...e.players.filter((t) => t.team === e.winner), ...e.players.filter((t) => t.team !== e.winner)].map((e) => e.rid),
		scores: Object.fromEntries(e.players.map((t) => [t.rid, e.teams[t.team].discs.reduce((e, t) => e + t, 0)]))
	} : { phase: e.phase }
}, Ne = {
	Elisabeth: "games.zenith.agents.Elisabeth",
	Pkd1ck: "games.zenith.agents.Pkd1ck",
	AgentEzra: "games.zenith.agents.AgentEzra",
	DonaldSmooth: "games.zenith.agents.DonaldSmooth",
	Huxl3y: "games.zenith.agents.Huxl3y",
	Titus: "games.zenith.agents.Titus",
	Mc4ffr3y: "games.zenith.agents.Mc4ffr3y",
	Luc4s: "games.zenith.agents.Luc4s",
	Cresus: "games.zenith.agents.Cresus",
	Atlas: "games.zenith.agents.Atlas",
	PunkMari: "games.zenith.agents.PunkMari",
	Septimus: "games.zenith.agents.Septimus",
	DoubleJoe: "games.zenith.agents.DoubleJoe",
	DonDune: "games.zenith.agents.DonDune",
	V3rn3: "games.zenith.agents.V3rn3",
	Ch4mb3rs: "games.zenith.agents.Ch4mb3rs",
	Buj0ld: "games.zenith.agents.Buj0ld",
	JackCurry: "games.zenith.agents.JackCurry",
	C1x1n: "games.zenith.agents.C1x1n",
	LadyMoore: "games.zenith.agents.LadyMoore",
	L0v3cr4ft: "games.zenith.agents.L0v3cr4ft",
	Suleiman: "games.zenith.agents.Suleiman",
	Annie: "games.zenith.agents.Annie",
	M4th3s0n: "games.zenith.agents.M4th3s0n",
	Gilgamesh: "games.zenith.agents.Gilgamesh",
	StessyPower: "games.zenith.agents.StessyPower",
	Felis: "games.zenith.agents.Felis",
	V4nc3: "games.zenith.agents.V4nc3",
	Ramses: "games.zenith.agents.Ramses",
	GuyGambler: "games.zenith.agents.GuyGambler",
	DocWissen: "games.zenith.agents.DocWissen",
	BaronGoro: "games.zenith.agents.BaronGoro",
	Ivan: "games.zenith.agents.Ivan",
	Br4dbury: "games.zenith.agents.Br4dbury",
	F4rm3r: "games.zenith.agents.F4rm3r",
	Zenon: "games.zenith.agents.Zenon",
	Bish0p: "games.zenith.agents.Bish0p",
	Wul: "games.zenith.agents.Wul",
	Th0mps0n: "games.zenith.agents.Th0mps0n",
	Domitian: "games.zenith.agents.Domitian",
	MasterDin: "games.zenith.agents.MasterDin",
	LordCreep: "games.zenith.agents.LordCreep",
	Amytis: "games.zenith.agents.Amytis",
	W4ts0n: "games.zenith.agents.W4ts0n",
	Arnulf: "games.zenith.agents.Arnulf",
	R0bins0n: "games.zenith.agents.R0bins0n",
	QueenSuzanne: "games.zenith.agents.QueenSuzanne",
	H4milt0n: "games.zenith.agents.H4milt0n",
	Caesar: "games.zenith.agents.Caesar",
	IldaFlores: "games.zenith.agents.IldaFlores",
	H3rb3rt: "games.zenith.agents.H3rb3rt",
	LisaCharity: "games.zenith.agents.LisaCharity",
	SirSam: "games.zenith.agents.SirSam",
	HiroshiSun: "games.zenith.agents.HiroshiSun",
	Magellan: "games.zenith.agents.Magellan",
	Bajazet: "games.zenith.agents.Bajazet",
	Geta: "games.zenith.agents.Geta",
	Charlemagne: "games.zenith.agents.Charlemagne",
	Caligula: "games.zenith.agents.Caligula",
	Tiberius: "games.zenith.agents.Tiberius",
	And3rs0n: "games.zenith.agents.And3rs0n",
	Orw3ll: "games.zenith.agents.Orw3ll",
	As1m0v: "games.zenith.agents.As1m0v",
	HelenaKerr: "games.zenith.agents.HelenaKerr",
	LittleBob: "games.zenith.agents.LittleBob",
	Bruss0l0: "games.zenith.agents.Bruss0l0",
	B4rj4v3l: "games.zenith.agents.B4rj4v3l",
	Augustus: "games.zenith.agents.Augustus",
	LulaSmart: "games.zenith.agents.LulaSmart",
	CharlizeGun: "games.zenith.agents.CharlizeGun",
	ProfessorZed: "games.zenith.agents.ProfessorZed",
	IceJune: "games.zenith.agents.IceJune",
	V4nV0gt: "games.zenith.agents.V4nV0gt",
	KingHarold: "games.zenith.agents.KingHarold",
	Geronimo: "games.zenith.agents.Geronimo",
	W3lls: "games.zenith.agents.W3lls",
	Nero: "games.zenith.agents.Nero",
	Cl4rke: "games.zenith.agents.Cl4rke",
	Chaka: "games.zenith.agents.Chaka",
	M4rt1n: "games.zenith.agents.M4rt1n",
	Pachacuti: "games.zenith.agents.Pachacuti",
	Gibs0n: "games.zenith.agents.Gibs0n",
	HandyLuke: "games.zenith.agents.HandyLuke",
	Khan: "games.zenith.agents.Khan",
	Moussa: "games.zenith.agents.Moussa",
	Archimedes: "games.zenith.agents.Archimedes",
	SneakyJules: "games.zenith.agents.SneakyJules",
	SecretKali: "games.zenith.agents.SecretKali",
	CaptainAndreev: "games.zenith.agents.CaptainAndreev",
	MiladyJones: "games.zenith.agents.MiladyJones",
	AdmiralJack: "games.zenith.agents.AdmiralJack",
	Mungo: "games.zenith.agents.Mungo",
	S1mmons: "games.zenith.agents.S1mmons",
	W1ll1s: "games.zenith.agents.W1ll1s",
	PrincessUxmal: "games.zenith.agents.PrincessUxmal",
	CelestinPetit: "games.zenith.agents.CelestinPetit",
	Ragnar: "games.zenith.agents.Ragnar",
	DandyMuller: "games.zenith.agents.DandyMuller",
	Boull3: "games.zenith.agents.Boull3",
	Demetrios: "games.zenith.agents.Demetrios"
}, U = [
	"games.zenith.planets.mercury",
	"games.zenith.planets.venus",
	"games.zenith.planets.terra",
	"games.zenith.planets.mars",
	"games.zenith.planets.jupiter"
], W = {
	animod: "games.zenith.factions.animod",
	human: "games.zenith.factions.human",
	robot: "games.zenith.factions.robot"
}, Pe = {
	absolute: "games.zenith.absolute",
	democratic: "games.zenith.democratic",
	popular: "games.zenith.popular",
	draw: "games.zenith.drawReason"
};
function Fe(e, t) {
	return Ne[e] ? t(Ne[e]) : "";
}
function G(e, t) {
	let n = e.n ?? 1, r = (e.amounts ?? [n]).join(" / "), i = e.planet == null ? "" : t(U[e.planet]), a = e.planet == null ? e.different ? t("games.zenith.effectsText.different") : e.center ? t("games.zenith.effectsText.center") : e.enemySide ? t("games.zenith.effectsText.enemySide") : e.except == null ? t("games.zenith.effectsText.any") : t("games.zenith.effectsText.except", { planet: t(U[e.except]) }) : i, o = e.planet == null ? e.except == null ? e.different ? t("games.zenith.effectsText.differentColumn") : t("games.zenith.effectsText.anyColumn") : t("games.zenith.effectsText.exceptColumn", { planet: t(U[e.except]) }) : i;
	switch (e.kind) {
		case "influence": return e.pattern ? e.pattern.join() === "1,2,1" ? t("games.zenith.effectsText.surrounding") : t("games.zenith.effectsText.pattern", {
			n: e.pattern.length,
			amounts: e.pattern.join(" / ")
		}) : e.points ? t("games.zenith.effectsText.flexible", { n: e.points }) : t("games.zenith.effectsText.influence", {
			n,
			target: a
		});
		case "giveInfluence": return t("games.zenith.effectsText.giveInfluence", {
			n,
			target: a
		});
		case "reset": return t("games.zenith.effectsText.reset");
		case "credits":
		case "zenithium": {
			let r = t(e.kind === "credits" ? "games.zenith.effectsText.credits" : "games.zenith.effectsText.zenithium", { n });
			return e.upTo != null && (r = t(e.kind === "credits" ? "games.zenith.effectsText.upToCredits" : "games.zenith.effectsText.upToZenithium", { n: e.upTo })), e.colorCount && (r = t("games.zenith.effectsText.colorCredits", { n: e.colorCount })), e.enemyColorCount && (r = t("games.zenith.effectsText.enemyColorCredits", { n: e.enemyColorCount })), e.techCount && (r = t(e.kind === "credits" ? "games.zenith.effectsText.techCredits" : "games.zenith.effectsText.techZenithium", { amounts: e.techCount.join(" / ") })), e.opponent ? t("games.zenith.effectsText.enemy", { effect: r }) : r;
		}
		case "giveCredits": return t("games.zenith.effectsText.giveCredits", { n });
		case "giveZenithium": return t("games.zenith.effectsText.giveZenithium", { n });
		case "spendCredits": return t("games.zenith.effectsText.spendCredits", { amounts: r });
		case "spendZenithium": return t("games.zenith.effectsText.spendZenithium", { amounts: r });
		case "stealCredits": return t("games.zenith.effectsText.stealCredits", { n });
		case "stealZenithium": return t("games.zenith.effectsText.stealZenithium", { n });
		case "mobilize": return t("games.zenith.effectsText.mobilize", { n });
		case "exile": return e.amounts ? t("games.zenith.effectsText.scaleExile", {
			target: o,
			amounts: r
		}) : t("games.zenith.effectsText.exile", {
			n,
			target: o,
			owner: t(e.opponent ? "games.zenith.effectsText.opponent" : "games.zenith.effectsText.own")
		});
		case "transfer": return t("games.zenith.effectsText.transfer", {
			n,
			target: o
		});
		case "discard": return t(e.full ? "games.zenith.effectsText.discardAll" : "games.zenith.effectsText.discard");
		case "leader": return t(e.gold ? "games.zenith.effectsText.gold" : "games.zenith.effectsText.leader");
		case "giveLeader": return t("games.zenith.effectsText.giveLeader");
		case "develop": {
			let n = t("games.zenith.effectsText.develop", { faction: e.faction ? t(W[e.faction]) : t(e.lowest ? "games.zenith.effectsText.lowestTech" : "games.zenith.effectsText.anyTech") });
			return e.free && (n = t("games.zenith.effectsText.free", { effect: n })), e.discount && (n = t("games.zenith.effectsText.discount", {
				effect: n,
				n: e.discount
			})), n;
		}
		case "bonus": return t(e.visible ? "games.zenith.effectsText.visibleBonus" : "games.zenith.effectsText.bonus");
		case "techBonus": return t("games.zenith.effectsText.techBonus");
		case "share": return t("games.zenith.effectsText.share", { n });
		case "choice": return t("games.zenith.effectsText.choice", {
			left: e.left.map((e) => G(e, t)).join(" · "),
			right: e.right.map((e) => G(e, t)).join(" · ")
		});
		case "condition": {
			let n = e.condition, r = e.effect, i = G(r, t);
			if (n.kind === "pay") {
				let a = n.effect;
				if (r.n == null && (r.kind === "credits" || r.kind === "zenithium") && !a.factors && (i = t(r.kind === "credits" ? "games.zenith.effectsText.derivedCredits" : "games.zenith.effectsText.derivedZenithium")), r.kind === "influence" && r.planet == null && !a.factors && (i = t("games.zenith.effectsText.influence", {
					n: r.n ?? 1,
					target: t("games.zenith.effectsText.derivedInfluence")
				})), a.factors) {
					let e = a.factors.join(" / ");
					i = r.kind === "influence" ? a.kind === "exile" ? t("games.zenith.effectsText.influence", {
						n: e,
						target: r.planet == null ? t("games.zenith.effectsText.any") : t(U[r.planet])
					}) : t("games.zenith.effectsText.flexible", { n: e }) : t(r.kind === "credits" ? "games.zenith.effectsText.credits" : "games.zenith.effectsText.zenithium", { n: e });
				}
				return t(e.mandatory ? "games.zenith.effectsText.mustPay" : "games.zenith.effectsText.pay", {
					cost: G(a, t),
					effect: i
				});
			}
			return t({
				leader: "games.zenith.effectsText.ifLeader",
				credits: "games.zenith.effectsText.ifCredits",
				enemyCredits: "games.zenith.effectsText.ifEnemyCredits",
				enemyZenithium: "games.zenith.effectsText.ifEnemyZenithium",
				enemyLeader: "games.zenith.effectsText.ifEnemyLeader"
			}[n.kind], {
				n: n.min ?? 0,
				effect: i
			});
		}
	}
}
function Ie(e, t, n) {
	switch (e.label) {
		case "planet": return n("games.zenith.optionPlanet", {
			planet: n(U[e.planet]),
			n: e.amount ?? 1
		});
		case "card": return t?.kind === "share" ? n("games.zenith.giveCard", { card: Fe(e.card, n) }) : Fe(e.card, n);
		case "quantity": return e.planet == null ? n("games.zenith.optionSpend", { n: e.amount }) : n("games.zenith.optionCards", {
			planet: n(U[e.planet]),
			n: e.amount
		});
		case "technology": return n("games.zenith.optionTech", {
			faction: n(W[e.faction]),
			n: e.amount
		});
		case "skip": return n("games.zenith.skip");
		case "continue": return t ? G(t, n) : n("games.zenith.continue");
		case "bonus": return G(k[e.card], n);
		case "left": return t?.left?.map((e) => G(e, n)).join(" · ") ?? n("games.zenith.left");
		case "right": return t?.right?.map((e) => G(e, n)).join(" · ") ?? n("games.zenith.right");
		case "pattern": return n("games.zenith.pattern", { planets: e.planets.map((e) => n(U[e])).join(" · ") });
		default: return n("games.zenith.continue");
	}
}
var Le = {
	recruit: "games.zenith.log.recruit",
	develop: "games.zenith.log.develop",
	leader: "games.zenith.log.leader",
	influence: "games.zenith.log.influence",
	capture: "games.zenith.log.capture",
	credits: "games.zenith.log.credits",
	zenithium: "games.zenith.log.zenithium",
	exile: "games.zenith.log.exile",
	transfer: "games.zenith.log.transfer",
	mobilize: "games.zenith.log.mobilize",
	discard: "games.zenith.log.discard",
	bonus: "games.zenith.log.bonus",
	give: "games.zenith.log.give",
	mulligan: "games.zenith.log.mulligan",
	pass: "games.zenith.log.pass"
};
function Re(e, t, n) {
	let r = e;
	return n(r.kind === "give" && r.bonus === "card" ? "games.zenith.log.giveCard" : r.kind === "give" && r.bonus === "leader" ? "games.zenith.log.giveLeader" : r.kind === "influence" && r.amount === 0 ? "games.zenith.log.reset" : Le[r.kind], {
		name: t,
		card: r.card ? Fe(r.card, n) : "",
		planet: r.planet == null ? "" : n(U[r.planet]),
		n: r.amount ?? 0,
		faction: r.faction ? n(W[r.faction]) : "",
		effect: r.bonus && k[r.bonus] ? G(k[r.bonus], n) : "",
		resource: n(r.bonus === "zenithium" ? "games.zenith.zenithium" : "games.zenith.credits")
	});
}
//#endregion
//#region src/games/zenith/approved-art.ts
var ze = {
	HiroshiSun: "<svg class=\"zen-portrait\" viewBox=\"38 35 204 245\" aria-hidden=\"true\"><path d=\"M29 285V72L66 38h154l30 34v213\" fill=\"#fae7c5\"/><path d=\"M55 285V83l21-19h129l20 20v201\" fill=\"none\" stroke=\"#fffdf1\" stroke-width=\"4\"/><ellipse cx=\"141\" cy=\"128\" rx=\"91\" ry=\"89\" fill=\"none\" stroke=\"#df9036\" stroke-opacity=\".18\" stroke-width=\"2\"/><path d=\"m35 112 13-12m181 72 15-12M55 239l12-10\" stroke=\"#df9036\" stroke-opacity=\".3\" stroke-width=\"3\"/><g stroke=\"#273638\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n  <path d=\"M64 285q-1-47 25-77l35-15 54 1 37 21 25 70\" fill=\"#273137\"/>\n  <path d=\"m105 202-20 25 18 59h27l-3-59zm69-5 25 25-8 63h-26l3-56z\" fill=\"#e7ac40\"/>\n  <path d=\"M87 217q-25 4-29 34l-8 34h31l16-42M210 221q21 10 22 30l11 34h-31l-16-38\" fill=\"#343a3f\"/>\n  <path d=\"m60 256 24 6-5 23H52zm151 6 25-8 8 31h-27z\" fill=\"#e0a942\"/>\n  <path d=\"M117 184v22l28 18 30-21-5-27\" fill=\"#d0a071\"/>\n  <path d=\"m119 196 23 20-13 18-21-27zm49-1-23 21 13 18 24-29z\" fill=\"#f2bf57\"/>\n  <path d=\"M101 104q-13-3-15 11t13 23m78-34q15-5 17 10t-15 25\" fill=\"#e3b784\"/>\n  <path d=\"M102 85q7-25 39-25t40 26l-1 45-10 31-30 22-29-22-14-33z\" fill=\"#ecc697\"/>\n  <path d=\"M104 116q1 39 36 54l21-7-18 20-31-20-14-34z\" fill=\"#c89a70\" stroke=\"none\"/>\n  <path d=\"M97 102q-8-30 14-42l17-4 31 5q22 8 23 34l-10 13-8-30-18-8-17 2-17 10-5 25z\" fill=\"#477581\"/>\n  <path d=\"M122 57q-10-13 1-20l20 1q13-9 22-1 12 17-8 28\" fill=\"#5e8991\"/>\n  <path d=\"m128 42 18 7 13-7M113 76l10-6m37 2 11 10\" fill=\"none\" stroke=\"#a6aaa0\" stroke-width=\"2\"/>\n  <path d=\"M111 99q9-9 18-2m19 0q11-8 20 0\" fill=\"none\" stroke=\"#f6f0e3\" stroke-width=\"6\"/>\n  <path d=\"m112 110 13-2m27 1 13 1\" fill=\"none\" stroke-width=\"2.4\"/><ellipse cx=\"120\" cy=\"110\" rx=\"2\" ry=\"2.5\" fill=\"#304144\" stroke=\"none\"/><ellipse cx=\"158\" cy=\"112\" rx=\"2\" ry=\"2.5\" fill=\"#304144\" stroke=\"none\"/>\n  <path d=\"m139 105-4 24 11 2M108 119l7 3m48-3 9-2\" fill=\"none\" stroke=\"#9e7354\" stroke-width=\"1.8\"/>\n  <path d=\"M138 132q-14-9-30 8 9 14 29 5 13 13 32-3-17-19-31-10z\" fill=\"#f3eee0\"/>\n  <path d=\"m137 143-8 18 13 37 16-35-11-19\" fill=\"#eae7da\"/>\n  <path d=\"m139 151 1 33m5-28 4 13m-31-29 12-1m18 1 11 2\" fill=\"none\" stroke=\"#b4b5a7\" stroke-width=\"1.6\"/>\n  <path d=\"m135 197 16 0-4 8h-8z\" fill=\"#a5afb0\"/>\n  <path d=\"M93 233q13-15 25-13l22 7 22-10q10-1 19 6l18 16-13 18-18-16-16 7q-10 2-20-3l-12-4-12 16-18-4z\" fill=\"#e9bc89\"/>\n  <path d=\"m124 230 17 6 22-9m-27 17 14-5m15 0 11-2\" fill=\"none\" stroke=\"#9c7455\" stroke-width=\"1.6\"/>\n  <path d=\"m85 243 18 14-6 18-25-9zm106-1-13 16 17 17 21-15z\" fill=\"#283239\"/>\n  <path d=\"m122 269 47-1m-35-34 1 31m22-29-2 29\" fill=\"none\" stroke=\"#aa8448\" stroke-width=\"1.5\"/>\n  <circle cx=\"178\" cy=\"211\" r=\"5\" fill=\"#f0bc51\"/><path d=\"m174 211 4-3 3 3-3 3z\" fill=\"#233b3a\" stroke=\"none\"/>\n  </g></svg>",
	Br4dbury: "<svg class=\"zen-portrait\" viewBox=\"38 35 204 245\" aria-hidden=\"true\"><path d=\"M29 285V72L66 38h154l30 34v213\" fill=\"#fae7c5\"/><path d=\"M55 285V83l21-19h129l20 20v201\" fill=\"none\" stroke=\"#fffdf1\" stroke-width=\"4\"/><ellipse cx=\"141\" cy=\"128\" rx=\"91\" ry=\"89\" fill=\"none\" stroke=\"#df9036\" stroke-opacity=\".18\" stroke-width=\"2\"/><path d=\"m35 112 13-12m181 72 15-12M55 239l12-10\" stroke=\"#df9036\" stroke-opacity=\".3\" stroke-width=\"3\"/><g stroke=\"#273638\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n  <path d=\"M77 284q-6-64 24-85l45-12 43 14q35 25 30 83\" fill=\"#e5a43b\"/>\n  <path d=\"m102 204 18-10 14 33-17 51H94zm71-8 15 11 14 70h-25l-17-48z\" fill=\"#f7e6bd\"/>\n  <path d=\"M109 224q32 23 69 0l7 56h-83z\" fill=\"#bc6b31\"/>\n  <path d=\"M116 238h55v24h-55z\" fill=\"#273b3f\"/><path d=\"M125 246h8m8 0h8m8 0h6\" stroke=\"#f6d96c\" stroke-width=\"4\"/>\n  <path d=\"M126 207v-27h38v29l-19 12z\" fill=\"#a1aba4\"/><path d=\"M129 190h33m-33 8h33\" stroke=\"#647875\"/>\n  <path d=\"M96 103q-2-46 48-49 49 2 49 48v45q-2 40-49 43-44-3-48-41z\" fill=\"#f5efe0\"/>\n  <path d=\"M97 104q-5-25 15-42l12 20-4 66 13 36q-35-6-37-37z\" fill=\"#e4a13c\"/>\n  <path d=\"M174 65q20 14 19 43v38q0 28-25 39l-9-17 15-23z\" fill=\"#d38c32\"/>\n  <path d=\"M122 88q17-12 36-2l15 11v50l-18 19-30-6-11-19V107z\" fill=\"#20343c\"/>\n  <path d=\"m122 101 12-8 16-1 16 11\" fill=\"none\" stroke=\"#45636a\" stroke-width=\"4\"/>\n  <path d=\"M135 115v23m20-23v23\" stroke=\"#f1c85c\" stroke-width=\"7\"/>\n  <path d=\"M127 151q16 10 31-2\" fill=\"none\" stroke=\"#688286\" stroke-width=\"2\"/>\n  <ellipse cx=\"94\" cy=\"121\" rx=\"12\" ry=\"23\" fill=\"#b66c37\"/><ellipse cx=\"94\" cy=\"120\" rx=\"7\" ry=\"14\" fill=\"#f3c863\"/>\n  <path d=\"M185 102h11q12 18 0 36h-10\" fill=\"#e1b459\"/><path d=\"M193 110v19\" stroke=\"#8b6642\" stroke-width=\"3\"/>\n  <path d=\"m119 64 17-12h25l12 13m-28-12 1-15\" fill=\"none\"/>\n  <circle cx=\"146\" cy=\"34\" r=\"5\" fill=\"#df7651\"/>\n  <path d=\"M100 204q-20-4-33 17l-13 37 18 13 21-34m94-27q20-5 30 14l14 30-16 15-24-34\" fill=\"#f2cb70\"/>\n  <circle cx=\"78\" cy=\"224\" r=\"15\" fill=\"#df9d37\"/><circle cx=\"78\" cy=\"224\" r=\"7\" fill=\"#546d70\"/>\n  <circle cx=\"207\" cy=\"227\" r=\"14\" fill=\"#d98d31\"/><path d=\"m201 225 12 4m-6-9-2 13\" stroke=\"#f4dc9e\"/>\n  <path d=\"m64 249-18-17-15 10 24 32 20-4z\" fill=\"#b7bdb2\"/>\n  <path d=\"m31 244-9-9 3-12 10-9 8 5-7 10 6 8 8-5 4 8-11 12z\" fill=\"#6c8180\"/>\n  <path d=\"m218 250 20-21 12 14-18 28-18-3z\" fill=\"#a9b4ad\"/>\n  <path d=\"m237 231 2-24 10-9 8 5-7 13 4 15-9 11z\" fill=\"#e6b85f\"/>\n  <path d=\"m248 212 14-16 10 8-12 18z\" fill=\"#4b7378\"/>\n  <path d=\"m107 278 27-7 29 2 26 7m-46-9v14\" fill=\"none\" stroke=\"#7e6237\"/>\n  <circle cx=\"113\" cy=\"215\" r=\"4\" fill=\"#447a7b\"/><path d=\"M151 174h9\" stroke=\"#73817c\"/>\n  </g></svg>",
	Elisabeth: "<svg class=\"zen-portrait\" viewBox=\"38 35 204 245\" aria-hidden=\"true\"><path d=\"M29 285V72L66 38h154l30 34v213\" fill=\"#d9edf3\"/><path d=\"M55 285V83l21-19h129l20 20v201\" fill=\"none\" stroke=\"#fffdf1\" stroke-width=\"4\"/><ellipse cx=\"141\" cy=\"128\" rx=\"91\" ry=\"89\" fill=\"none\" stroke=\"#418eb3\" stroke-opacity=\".18\" stroke-width=\"2\"/><path d=\"m35 112 13-12m181 72 15-12M55 239l12-10\" stroke=\"#418eb3\" stroke-opacity=\".3\" stroke-width=\"3\"/><g stroke=\"#273638\" stroke-width=\"2.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n  <path d=\"M96 284q-4-50 11-78l35-22 40 9q30 13 38 49l6 42\" fill=\"#31596e\"/>\n  <path d=\"m121 199 21-12 17 27-13 47-18-16 4-27-19-5zm50-4 17 8 18 45-36-5-17-29z\" fill=\"#244458\"/>\n  <path d=\"m140 196 16 20 15-19-7 39-11 13-14-29z\" fill=\"#ede5c9\"/>\n  <path d=\"m151 211 8 6 8-8-4 20-8 9-6-14z\" fill=\"#b98864\"/>\n  <path d=\"M139 172v24l15 17 18-20-4-26\" fill=\"#a3927c\"/>\n  <path d=\"M117 70q-13-12-24 1-10 15 1 28m66-34q3-17 16-15 18 8 7 30\" fill=\"#9f8d7c\"/>\n  <path d=\"m100 75-2 11m75-27 1 11\" fill=\"none\" stroke=\"#665b52\" stroke-width=\"4\"/>\n  <path d=\"M114 69q36-16 61 9l15 30q12 33-10 54l-19 20-35-6-18-30-20-24q-18-13-16-28 5-12 20-9z\" fill=\"#b6a38d\"/>\n  <path d=\"M92 85q18-23 41-23l22 3-22 9-13 18-19 2z\" fill=\"#d0c1a8\" stroke=\"none\"/>\n  <path d=\"M174 85q20 34 6 61l-24 31-21-1 15-20 5-36z\" fill=\"#8d8171\" stroke=\"none\"/>\n  <path d=\"M83 97q17-11 35-3l9 18q-11 18-28 13-15-4-22-14z\" fill=\"#d7c7a8\"/>\n  <path d=\"m76 97 13-4 8 7-8 9-11-4z\" fill=\"#384342\"/>\n  <path d=\"M111 86q15-10 28-4\" stroke=\"#625f56\" stroke-width=\"4\" fill=\"none\"/>\n  <path d=\"m119 94 11 0\" stroke=\"#283b3d\" stroke-width=\"3\"/><path d=\"m135 104 14-1m-32 14 14 7\" fill=\"none\" stroke=\"#7e7462\" stroke-width=\"1.6\"/>\n  <path d=\"M91 111q13 9 29 5\" fill=\"none\" stroke=\"#746756\" stroke-width=\"2\"/>\n  <path d=\"m99 106-27-9m28 14-31-2m34 7-26 8m31-8-18 17\" fill=\"none\" stroke=\"#eee5d1\" stroke-width=\"1.8\"/>\n  <path d=\"m161 153 16-11m-20 19 12-3\" fill=\"none\" stroke=\"#796e61\" stroke-width=\"1.6\"/>\n  <path d=\"M117 213q-13 5-20 22l-19-6-11 19q27 26 47 15l24-26\" fill=\"#38647a\"/>\n  <path d=\"m73 225-16-11-12 13 13 18 17 1 10-12z\" fill=\"#eee9da\"/>\n  <path d=\"m52 219-7-9-6 2-1 13 8 9m11-15-2-14-6-1-5 10m18 12 2-14-5-4-6 8\" fill=\"#f2ecdd\"/>\n  <path d=\"M177 220q-15 5-25 24l-15-9-12 18 24 20q13 5 24-7l30-28\" fill=\"#426d7f\"/>\n  <path d=\"m132 234-11-8-12 6 1 14 17 11 14-10z\" fill=\"#efe9da\"/>\n  <path d=\"m114 233-4-12-7 1-2 15 8 10m14-14 0-15-7-1-7 11\" fill=\"#f6f0e0\"/>\n  <g transform=\"translate(-4 17)\"><path d=\"M76 180h34l-3 29H79z\" fill=\"#f7f2e0\"/><path d=\"M110 185h8q9 10-3 17h-7\" fill=\"none\" stroke=\"#e7ddbf\" stroke-width=\"4\"/>\n  <ellipse cx=\"93\" cy=\"180\" rx=\"17\" ry=\"5\" fill=\"#c8b996\"/><ellipse cx=\"93\" cy=\"181\" rx=\"13\" ry=\"2\" fill=\"#756a57\"/>\n  <path d=\"m86 173-2-7q-2-4 1-8m11 15q-5-7-1-13\" fill=\"none\" stroke=\"#c5cbb9\" stroke-width=\"1.5\"/></g>\n  <path d=\"m106 267 14 3m48 7 29-1\" fill=\"none\" stroke=\"#7191a0\" stroke-width=\"2\"/>\n  <circle cx=\"158\" cy=\"267\" r=\"3\" fill=\"#c4ad6e\"/><path d=\"m186 209 9 9-7 10-8-10z\" fill=\"#c4ad6e\"/>\n  </g></svg>",
	Orw3ll: "<svg class=\"zen-portrait\" viewBox=\"38 35 204 245\" aria-hidden=\"true\"><path d=\"M29 285V72L66 38h154l30 34v213\" fill=\"#e9e0ef\"/><path d=\"M55 285V83l21-19h129l20 20v201\" fill=\"none\" stroke=\"#fffdf1\" stroke-width=\"4\"/><ellipse cx=\"141\" cy=\"128\" rx=\"91\" ry=\"89\" fill=\"none\" stroke=\"#8970ab\" stroke-opacity=\".18\" stroke-width=\"2\"/><path d=\"m35 112 13-12m181 72 15-12M55 239l12-10\" stroke=\"#8970ab\" stroke-opacity=\".3\" stroke-width=\"3\"/><g stroke=\"#293d40\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n  <path d=\"M92 285q-8-46 22-61h57q35 13 27 61\" fill=\"#e7ddc8\"/>\n  <path d=\"m114 227 15 22-16 32m56-54-14 22 18 32\" fill=\"none\" stroke=\"#b98c88\" stroke-width=\"8\"/>\n  <path d=\"M146 212v22m-12-21v15m22-17v17\" stroke=\"#637c78\" stroke-width=\"7\"/>\n  <path d=\"M92 90q-24 30-13 78 10 51 65 57 52-2 65-51 15-53-14-88-47-39-103 4z\" fill=\"#e5c4c2\"/>\n  <path d=\"M104 89q-31 35-19 78l20 31 10-16q-18-39 0-74z\" fill=\"#c48c96\" stroke=\"none\"/>\n  <path d=\"M180 88q27 24 24 65l-8 30-18 19-8-13q21-33 8-72z\" fill=\"#c8a3a4\" stroke=\"none\"/>\n  <path d=\"M115 106q26-21 45-8 21 26 10 64l-12 27-28 3-19-24q-9-34 4-62z\" fill=\"#253d42\"/>\n  <path d=\"M124 117q14-11 28-3\" stroke=\"#68858a\" stroke-width=\"3\" fill=\"none\"/>\n  <ellipse cx=\"129\" cy=\"139\" rx=\"5\" ry=\"9\" fill=\"#e3b653\" stroke=\"none\"/><ellipse cx=\"151\" cy=\"137\" rx=\"5\" ry=\"9\" fill=\"#e3b653\" stroke=\"none\"/>\n  <path d=\"m131 166 20-1\" stroke=\"#a6c7c0\" stroke-width=\"3\"/><path d=\"M92 82 76 62l7-13 18 11 9 14m68-2 18-23 15 7-5 23\" fill=\"#99ada5\"/>\n  <path d=\"m91 90-12-4-10 16 7 17 13-1m111-26 14-4 10 19-9 17-10-2\" fill=\"#6f8481\"/>\n  <circle cx=\"85\" cy=\"100\" r=\"4\" fill=\"#d3c4a4\"/><circle cx=\"210\" cy=\"107\" r=\"4\" fill=\"#d3c4a4\"/>\n  <path d=\"M97 188q-33 3-43 30l-7 13 10 10 14-8 11-20 27-6\" fill=\"#a7b6ad\"/>\n  <path d=\"m49 228-17-1-9 10 6 10 17-2 12-7\" fill=\"#e0b7bb\"/><path d=\"m31 232 9 8m-17-3 10 10\" fill=\"none\" stroke=\"#996f7c\" stroke-width=\"2\"/>\n  <path d=\"M192 191q30 7 37 35l7 14-12 10-13-11-10-26-21-9\" fill=\"#91a59e\"/>\n  <path d=\"m227 236 16-5 11 7-1 12-18 3-12-9\" fill=\"#d2a5b0\"/><path d=\"m239 235-1 12m8-11-1 11\" fill=\"none\" stroke=\"#8f6d7a\" stroke-width=\"2\"/>\n  <path d=\"m128 266 11-9 14 3 5 12-13 9z\" fill=\"#c4999d\"/><circle cx=\"145\" cy=\"269\" r=\"4\" fill=\"#e4c56e\"/>\n  <path d=\"m103 98-9 9m91 65-7 13\" stroke=\"#fff3df\" stroke-width=\"3\"/>\n  </g></svg>"
}, Be = [
	"<svg class=\"zen-planet \" viewBox=\"0 0 100 104\" aria-hidden=\"true\"><defs><clipPath id=\"clip-0\"><circle cx=\"50\" cy=\"49\" r=\"42\"/></clipPath></defs><circle cx=\"50\" cy=\"53\" r=\"44\" fill=\"#233938\" opacity=\".24\"/><circle cx=\"50\" cy=\"49\" r=\"44\" fill=\"#8970ab\" stroke=\"#304241\" stroke-width=\"2\"/><g clip-path=\"url(#clip-0)\"><path d=\"M24 28q20-18 40-7l10 7-3 12-22 2-7 16-24-2-4-10z\" fill=\"#b6a3c9\"/><circle cx=\"35\" cy=\"31\" r=\"8\" fill=\"#6d558b\"/><circle cx=\"67\" cy=\"62\" r=\"12\" fill=\"#705791\"/><circle cx=\"36\" cy=\"70\" r=\"5\" fill=\"#695284\"/><path d=\"M29 30q5-7 11 0m19 31q8-8 17-1\" fill=\"none\" stroke=\"#5e4b7b\" stroke-width=\"2\"/><path d=\"M10 25q-10 37 16 61 32 15 56-14-10 28-44 22-38-9-32-45z\" fill=\"#253b3e\" opacity=\".19\"/></g><circle cx=\"50\" cy=\"49\" r=\"38\" fill=\"none\" stroke=\"#fff3da\" stroke-opacity=\".3\" stroke-width=\"1.2\"/><path d=\"M20 36q5-14 18-18\" fill=\"none\" stroke=\"#fff7dc\" stroke-opacity=\".7\" stroke-width=\"3\" stroke-linecap=\"round\"/></svg>",
	"<svg class=\"zen-planet \" viewBox=\"0 0 100 104\" aria-hidden=\"true\"><defs><clipPath id=\"clip-1\"><circle cx=\"50\" cy=\"49\" r=\"42\"/></clipPath></defs><circle cx=\"50\" cy=\"53\" r=\"44\" fill=\"#233938\" opacity=\".24\"/><circle cx=\"50\" cy=\"49\" r=\"44\" fill=\"#df9036\" stroke=\"#304241\" stroke-width=\"2\"/><g clip-path=\"url(#clip-1)\"><path d=\"M8 35q28-24 72-8M8 47q35-24 80-8M13 65q40-23 71-8M25 79q25-19 48-17\" fill=\"none\" stroke=\"#f5c574\" stroke-width=\"8\"/><path d=\"M15 36q32-17 66-9M14 62q36-19 67-10\" fill=\"none\" stroke=\"#af682e\" stroke-width=\"3\"/><path d=\"M29 18q27-4 33 6t-18 9\" fill=\"none\" stroke=\"#ffe0a0\" stroke-width=\"3\"/><path d=\"M10 25q-10 37 16 61 32 15 56-14-10 28-44 22-38-9-32-45z\" fill=\"#253b3e\" opacity=\".19\"/></g><circle cx=\"50\" cy=\"49\" r=\"38\" fill=\"none\" stroke=\"#fff3da\" stroke-opacity=\".3\" stroke-width=\"1.2\"/><path d=\"M20 36q5-14 18-18\" fill=\"none\" stroke=\"#fff7dc\" stroke-opacity=\".7\" stroke-width=\"3\" stroke-linecap=\"round\"/></svg>",
	"<svg class=\"zen-planet \" viewBox=\"0 0 100 104\" aria-hidden=\"true\"><defs><clipPath id=\"clip-2\"><circle cx=\"50\" cy=\"49\" r=\"42\"/></clipPath></defs><circle cx=\"50\" cy=\"53\" r=\"44\" fill=\"#233938\" opacity=\".24\"/><circle cx=\"50\" cy=\"49\" r=\"44\" fill=\"#418eb3\" stroke=\"#304241\" stroke-width=\"2\"/><g clip-path=\"url(#clip-2)\"><path d=\"m25 15 20 1 6 9-6 14-13 1-5 16-14-6-5-14zM54 43l11-9 19 5 9 19-15 4-8 21-14-7-7-15z\" fill=\"#a8c8a0\"/><path d=\"m27 19 12 2 2 8-9 2m28 13 9-2 10 8-15 7-6 13\" fill=\"none\" stroke=\"#d1dfb6\" stroke-width=\"3\"/><path d=\"M19 68q12 5 19 2M58 22l11 4\" fill=\"none\" stroke=\"#a3d3e1\" stroke-width=\"3\"/><path d=\"M10 25q-10 37 16 61 32 15 56-14-10 28-44 22-38-9-32-45z\" fill=\"#253b3e\" opacity=\".19\"/></g><circle cx=\"50\" cy=\"49\" r=\"38\" fill=\"none\" stroke=\"#fff3da\" stroke-opacity=\".3\" stroke-width=\"1.2\"/><path d=\"M20 36q5-14 18-18\" fill=\"none\" stroke=\"#fff7dc\" stroke-opacity=\".7\" stroke-width=\"3\" stroke-linecap=\"round\"/></svg>",
	"<svg class=\"zen-planet \" viewBox=\"0 0 100 104\" aria-hidden=\"true\"><defs><clipPath id=\"clip-3\"><circle cx=\"50\" cy=\"49\" r=\"42\"/></clipPath></defs><circle cx=\"50\" cy=\"53\" r=\"44\" fill=\"#233938\" opacity=\".24\"/><circle cx=\"50\" cy=\"49\" r=\"44\" fill=\"#c85a54\" stroke=\"#304241\" stroke-width=\"2\"/><g clip-path=\"url(#clip-3)\"><path d=\"M9 35q20-20 39-8t40 0v10q-29 19-43 8T7 50zm2 28q22-12 38 0t35-3l-8 15q-23 11-35 0t-24 1\" fill=\"#e79373\"/><path d=\"m22 28 11-7 9 8-7 10-12-1zm34 24 14-6 12 7-5 12-16 3z\" fill=\"#a64c4b\"/><path d=\"m25 27 8-3 5 4m23 24 9-3 6 4\" fill=\"none\" stroke=\"#f7bda0\" stroke-width=\"2\"/><path d=\"M10 25q-10 37 16 61 32 15 56-14-10 28-44 22-38-9-32-45z\" fill=\"#253b3e\" opacity=\".19\"/></g><circle cx=\"50\" cy=\"49\" r=\"38\" fill=\"none\" stroke=\"#fff3da\" stroke-opacity=\".3\" stroke-width=\"1.2\"/><path d=\"M20 36q5-14 18-18\" fill=\"none\" stroke=\"#fff7dc\" stroke-opacity=\".7\" stroke-width=\"3\" stroke-linecap=\"round\"/></svg>",
	"<svg class=\"zen-planet \" viewBox=\"0 0 100 104\" aria-hidden=\"true\"><defs><clipPath id=\"clip-4\"><circle cx=\"50\" cy=\"49\" r=\"42\"/></clipPath></defs><circle cx=\"50\" cy=\"53\" r=\"44\" fill=\"#233938\" opacity=\".24\"/><circle cx=\"50\" cy=\"49\" r=\"44\" fill=\"#448b78\" stroke=\"#304241\" stroke-width=\"2\"/><g clip-path=\"url(#clip-4)\"><path d=\"M8 26q32 13 76 0M6 43q38 14 83-1M9 62q31 11 76-1M20 78q29 7 52-3\" fill=\"none\" stroke=\"#9bc4a7\" stroke-width=\"8\"/><path d=\"M8 34q44 10 79-1M11 55q44 12 75-1M20 73q31 4 58-2\" fill=\"none\" stroke=\"#2d6d64\" stroke-width=\"3\"/><ellipse cx=\"64\" cy=\"56\" rx=\"13\" ry=\"7\" fill=\"#c5b77e\" transform=\"rotate(-10 64 56)\"/><ellipse cx=\"64\" cy=\"55\" rx=\"7\" ry=\"3\" fill=\"#8f9967\"/><path d=\"M10 25q-10 37 16 61 32 15 56-14-10 28-44 22-38-9-32-45z\" fill=\"#253b3e\" opacity=\".19\"/></g><circle cx=\"50\" cy=\"49\" r=\"38\" fill=\"none\" stroke=\"#fff3da\" stroke-opacity=\".3\" stroke-width=\"1.2\"/><path d=\"M20 36q5-14 18-18\" fill=\"none\" stroke=\"#fff7dc\" stroke-opacity=\".7\" stroke-width=\"3\" stroke-linecap=\"round\"/></svg>"
], Ve = {
	HiroshiSun: "<svg class=\"zen-ability-band\" viewBox=\"0 0 1000 450\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"\" data-ability-card=\"HiroshiSun\" data-effect-count=\"3\"><path d=\"m2 34 24-20h669l30-13h248l23 20v405l-24 20H24L2 426z\" fill=\"#dc873b\"/><path d=\"M12 45 32 25h668l30-13h237\" fill=\"none\" stroke=\"#fff0c5\" stroke-opacity=\".45\" stroke-width=\"7\"/><path d=\"M14 425h969\" stroke=\"#203832\" stroke-opacity=\".2\" stroke-width=\"22\"/><g data-effect=\"influence\"><use href=\"#zen-official-planet-1\" x=\"25\" y=\"67\" width=\"220\" height=\"242.00000000000003\"/><use href=\"#zen-official-down\" x=\"77.8\" y=\"289.2\" width=\"114.4\" height=\"83\"/></g><path d=\"M250 17V434\" stroke=\"#f9e7bd\" stroke-width=\"18\"/><path d=\"M260 18V434\" stroke=\"#302b27\" stroke-opacity=\".1\" stroke-width=\"4\"/><g data-effect=\"credits\"><g transform=\"translate(300 150) scale(1.35)\"><use href=\"#zen-official-credit\" x=\"0\" y=\"0\" width=\"100\" height=\"100\"/><text x=\"45\" y=\"75\" text-anchor=\"middle\" fill=\"#182a29\" font-family=\"Impact,Arial Black,sans-serif\" font-size=\"73\" font-weight=\"900\" letter-spacing=\"-3\">4</text></g></g><path d=\"M475 17V434\" stroke=\"#f9e7bd\" stroke-width=\"18\"/><path d=\"M485 18V434\" stroke=\"#302b27\" stroke-opacity=\".1\" stroke-width=\"4\"/><g data-effect=\"condition\" data-condition=\"giveZenithium\"><use href=\"#zen-official-give\" x=\"556\" y=\"67\" width=\"85\" height=\"82\"/><g transform=\"translate(520 161) scale(1.7)\"><use href=\"#zen-official-crystal\" x=\"0\" y=\"0\" width=\"100\" height=\"100\"/><text x=\"48\" y=\"76\" text-anchor=\"middle\" fill=\"#182a29\" font-family=\"Impact,Arial Black,sans-serif\" font-size=\"75\" font-weight=\"900\" letter-spacing=\"-3\">1</text></g><use href=\"#zen-official-next\" x=\"714\" y=\"187\" width=\"50\" height=\"90\"/><use href=\"#zen-official-planet-3\" x=\"780\" y=\"66\" width=\"190\" height=\"209.00000000000003\"/><use href=\"#zen-official-down\" x=\"825.6\" y=\"257.9\" width=\"98.8\" height=\"83\"/><use href=\"#zen-official-down\" x=\"825.6\" y=\"319.9\" width=\"98.8\" height=\"83\"/></g></svg>",
	Br4dbury: "<svg class=\"zen-ability-band\" viewBox=\"0 0 1000 450\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"\" data-ability-card=\"Br4dbury\" data-effect-count=\"2\"><path d=\"m2 34 24-20h669l30-13h248l23 20v405l-24 20H24L2 426z\" fill=\"#dc873b\"/><path d=\"M12 45 32 25h668l30-13h237\" fill=\"none\" stroke=\"#fff0c5\" stroke-opacity=\".45\" stroke-width=\"7\"/><path d=\"M14 425h969\" stroke=\"#203832\" stroke-opacity=\".2\" stroke-width=\"22\"/><g data-effect=\"influence\"><use href=\"#zen-official-planet-1\" x=\"25\" y=\"67\" width=\"220\" height=\"242.00000000000003\"/><use href=\"#zen-official-down\" x=\"77.8\" y=\"289.2\" width=\"114.4\" height=\"83\"/></g><path d=\"M250 17V434\" stroke=\"#f9e7bd\" stroke-width=\"18\"/><path d=\"M260 18V434\" stroke=\"#302b27\" stroke-opacity=\".1\" stroke-width=\"4\"/><g data-effect=\"develop\" data-faction=\"robot\" data-discount=\"1\"><g transform=\"translate(332 142) scale(2.15)\"><use href=\"#zen-official-crystal\" x=\"0\" y=\"0\" width=\"100\" height=\"100\"/><text x=\"48\" y=\"64\" text-anchor=\"middle\" fill=\"#182a29\" font-family=\"Impact,Arial Black,sans-serif\" font-size=\"43\" font-weight=\"900\" letter-spacing=\"-3\">X−1</text></g><use href=\"#zen-official-next\" x=\"580\" y=\"180\" width=\"56\" height=\"100\"/><g transform=\"translate(696 36)\"><rect x=\"0\" y=\"6\" width=\"184\" height=\"361\" rx=\"19\" fill=\"#676637\"/><rect width=\"184\" height=\"358\" rx=\"18\" fill=\"#fff0a5\"/><path d=\"m92 23 39 53H53z\" fill=\"#182a29\"/><path d=\"m44 94 98 0 42 78-43 76H44L3 172z\" fill=\"#fff9db\" stroke=\"#293c32\" stroke-width=\"8\"/><use href=\"#zen-official-robot\" x=\"39\" y=\"118\" width=\"107\" height=\"111\"/></g></g></svg>",
	Elisabeth: "<svg class=\"zen-ability-band\" viewBox=\"0 0 1000 450\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"\" data-ability-card=\"Elisabeth\" data-effect-count=\"3\"><path d=\"m2 34 24-20h669l30-13h248l23 20v405l-24 20H24L2 426z\" fill=\"#347ca2\"/><path d=\"M12 45 32 25h668l30-13h237\" fill=\"none\" stroke=\"#fff0c5\" stroke-opacity=\".45\" stroke-width=\"7\"/><path d=\"M14 425h969\" stroke=\"#203832\" stroke-opacity=\".2\" stroke-width=\"22\"/><g data-effect=\"influence\"><use href=\"#zen-official-planet-2\" x=\"25\" y=\"67\" width=\"220\" height=\"242.00000000000003\"/><use href=\"#zen-official-down\" x=\"77.8\" y=\"289.2\" width=\"114.4\" height=\"83\"/></g><path d=\"M250 17V434\" stroke=\"#f9e7bd\" stroke-width=\"18\"/><path d=\"M260 18V434\" stroke=\"#302b27\" stroke-opacity=\".1\" stroke-width=\"4\"/><g data-effect=\"discard\"><use href=\"#zen-official-discard\" x=\"383\" y=\"32\" width=\"212\" height=\"356\"/></g><g data-effect=\"zenithium\"><g transform=\"translate(719 143) scale(1.85)\"><use href=\"#zen-official-crystal\" x=\"0\" y=\"0\" width=\"100\" height=\"100\"/><text x=\"48\" y=\"76\" text-anchor=\"middle\" fill=\"#182a29\" font-family=\"Impact,Arial Black,sans-serif\" font-size=\"75\" font-weight=\"900\" letter-spacing=\"-3\">1</text></g></g></svg>",
	Orw3ll: "<svg class=\"zen-ability-band\" viewBox=\"0 0 1000 450\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"\" data-ability-card=\"Orw3ll\" data-effect-count=\"3\"><path d=\"m2 34 24-20h669l30-13h248l23 20v405l-24 20H24L2 426z\" fill=\"#887496\"/><path d=\"M12 45 32 25h668l30-13h237\" fill=\"none\" stroke=\"#fff0c5\" stroke-opacity=\".45\" stroke-width=\"7\"/><path d=\"M14 425h969\" stroke=\"#203832\" stroke-opacity=\".2\" stroke-width=\"22\"/><g data-effect=\"influence\"><use href=\"#zen-official-planet-0\" x=\"25\" y=\"67\" width=\"220\" height=\"242.00000000000003\"/><use href=\"#zen-official-down\" x=\"77.8\" y=\"289.2\" width=\"114.4\" height=\"83\"/></g><path d=\"M250 17V434\" stroke=\"#f9e7bd\" stroke-width=\"18\"/><path d=\"M260 18V434\" stroke=\"#302b27\" stroke-opacity=\".1\" stroke-width=\"4\"/><g data-effect=\"bonus\"><use href=\"#zen-official-bonus\" x=\"321\" y=\"154\" width=\"228\" height=\"140\"/></g><path d=\"M625 17V434\" stroke=\"#f9e7bd\" stroke-width=\"18\"/><path d=\"M635 18V434\" stroke=\"#302b27\" stroke-opacity=\".1\" stroke-width=\"4\"/><g data-effect=\"condition\" data-condition=\"giveLeader\"><use href=\"#zen-official-give\" x=\"783\" y=\"8\" width=\"82\" height=\"73\"/><use href=\"#zen-official-leader\" x=\"725\" y=\"82\" width=\"202\" height=\"130\"/><path d=\"m781 226 90 0-45 50z\" fill=\"#eadcc4\"/><g transform=\"translate(751 289) scale(1.57)\"><use href=\"#zen-official-credit\" x=\"0\" y=\"0\" width=\"100\" height=\"100\"/><text x=\"45\" y=\"75\" text-anchor=\"middle\" fill=\"#182a29\" font-family=\"Impact,Arial Black,sans-serif\" font-size=\"73\" font-weight=\"900\" letter-spacing=\"-3\">7</text></g></g></svg>"
}, He = "<svg width=\"0\" height=\"0\" class=\"zen-defs\" aria-hidden=\"true\"><defs>\n<symbol id=\"human\" viewBox=\"0 0 32 32\"><path d=\"M9 18V9q0-3 3-3v10-12q0-3 3-2v13-12q3-2 4 1v12-9q2-3 4 0v13l-2 7H13l-7-8q-3-4 0-5z\" fill=\"currentColor\"/></symbol>\n<symbol id=\"robot\" viewBox=\"0 0 32 32\"><path d=\"m16 3 7 6-4 7 4 7-7 7-7-7 4-7-4-7z\" fill=\"currentColor\"/><path d=\"m7 11-4 4 5 5m17-9 4 4-5 5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\"/></symbol>\n<symbol id=\"animod\" viewBox=\"0 0 32 32\"><ellipse cx=\"16\" cy=\"22\" rx=\"9\" ry=\"7\" fill=\"currentColor\"/><ellipse cx=\"5\" cy=\"13\" rx=\"4\" ry=\"5\" transform=\"rotate(-20 5 13)\" fill=\"currentColor\"/><ellipse cx=\"12\" cy=\"7\" rx=\"4\" ry=\"5\" fill=\"currentColor\"/><ellipse cx=\"22\" cy=\"7\" rx=\"4\" ry=\"5\" fill=\"currentColor\"/><ellipse cx=\"28\" cy=\"14\" rx=\"4\" ry=\"5\" transform=\"rotate(20 28 14)\" fill=\"currentColor\"/></symbol>\n<symbol id=\"crystal\" viewBox=\"0 0 32 32\"><path d=\"m9 3 16 3 5 13-10 11-15-5-4-13z\" fill=\"#f4d963\" stroke=\"#6d623c\" stroke-width=\"1.5\"/><path d=\"m9 3 4 10-8 12m8-12 12-7m-12 7 7 17m-7-17 17 6\" fill=\"none\" stroke=\"#c09f35\" stroke-width=\"1.5\"/><path d=\"m11 6 3 7 8-5\" fill=\"#fff3a5\"/></symbol>\n<symbol id=\"credit\" viewBox=\"0 0 32 32\"><path d=\"M5 3h22l3 5v20H2V8z\" fill=\"#d2d5cd\" stroke=\"#606b67\" stroke-width=\"1.5\"/><path d=\"M7 7h18v17H7z\" fill=\"#f2f0dd\" stroke=\"#a1a79c\"/><path d=\"M15 10h5v12h-5v-9h-3z\" fill=\"#34413e\"/><path d=\"M3 27h26\" stroke=\"#86918a\"/></symbol>\n<symbol id=\"star\" viewBox=\"0 0 32 32\"><path d=\"m16 2 4.2 9.3L30 13l-7 7 1 10-8-5-8 5 1-10-7-7 9.8-1.7z\" fill=\"currentColor\"/></symbol>\n<symbol id=\"arrow\" viewBox=\"0 0 32 32\"><path d=\"M12 3h8v15h7L16 30 5 18h7z\" fill=\"currentColor\"/></symbol>\n<symbol id=\"agent\" viewBox=\"0 0 32 32\"><path d=\"M6 2h20l3 3v25H3V5z\" fill=\"#dce3d4\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linejoin=\"round\"/><path d=\"M7 6h18v20H7z\" fill=\"#fff8e3\"/><circle cx=\"16\" cy=\"12\" r=\"5\" fill=\"currentColor\"/><path d=\"M7 26v-2q0-7 9-7t9 7v2z\" fill=\"currentColor\"/></symbol>\n<symbol id=\"wild\" viewBox=\"0 0 32 32\"><circle cx=\"16\" cy=\"16\" r=\"13\" fill=\"#4d6260\" stroke=\"#243c3c\" stroke-width=\"1.5\"/><circle cx=\"16\" cy=\"16\" r=\"9\" fill=\"none\" stroke=\"#d7ded1\" stroke-width=\"1\"/><path d=\"m16 8 2 5 6 3-6 2-2 6-2-6-6-2 6-3z\" fill=\"#d7ded1\"/></symbol>\n<symbol id=\"transfer\" viewBox=\"0 0 32 32\"><path d=\"M3 3h13v19H3zM17 10h12v19H17z\" fill=\"#d6ded1\" stroke=\"#3d5652\" stroke-width=\"1.5\"/><path d=\"M7 13h15v-4l8 7-8 7v-5H7z\" fill=\"#3d5652\"/></symbol>\n<symbol id=\"medal\" viewBox=\"0 0 32 32\"><path d=\"m2 8 13 4 15-4-4 13-10 8L6 21z\" fill=\"#bcbfaf\" stroke=\"#556553\" stroke-width=\"1.5\"/><circle cx=\"16\" cy=\"15\" r=\"10\" fill=\"#e4dfbf\" stroke=\"#556553\" stroke-width=\"1.5\"/><path d=\"m16 7 2 5 5 1-4 4 1 5-4-3-4 3 1-5-4-4 5-1z\" fill=\"#8e7f4a\"/></symbol>\n</defs></svg><svg width=\"0\" height=\"0\" class=\"zen-defs\" aria-hidden=\"true\"><defs>\n<symbol id=\"zen-official-down\" viewBox=\"0 0 100 80\"><path d=\"M28 4h44v23h25L50 77 3 27h25z\" fill=\"#263c36\"/><path d=\"M28 0h44v22h25L50 70 3 22h25z\" fill=\"#fffbe8\" stroke=\"#f3ebcd\" stroke-width=\"2\"/></symbol>\n<symbol id=\"zen-official-give\" viewBox=\"0 0 100 90\"><path d=\"M34 83V44H9L50 4l41 40H66v39z\" fill=\"#b84c37\" stroke=\"#fff4cf\" stroke-width=\"7\" stroke-linejoin=\"round\"/></symbol>\n<symbol id=\"zen-official-next\" viewBox=\"0 0 60 100\"><path d=\"M2 5 56 50 2 95z\" fill=\"#f5dfa6\"/></symbol>\n<symbol id=\"zen-official-credit\" viewBox=\"0 0 100 100\"><path d=\"m9 9 78-4 10 10-4 78-81 5L3 86V18z\" fill=\"#4b5141\"/><path d=\"m9 9 78-4-4 13H3z\" fill=\"#d7d6b7\"/><path d=\"m3 18 80-5v70L3 88z\" fill=\"#adb29a\"/><path d=\"m83 13 14 2-4 78-10-10z\" fill=\"#737b69\"/><path d=\"m7 21 70-5v62L7 83z\" fill=\"#c6c8aa\"/></symbol>\n<symbol id=\"zen-official-crystal\" viewBox=\"0 0 100 100\"><path d=\"M25 8h52l22 44-23 43H24L1 52z\" fill=\"#7e7937\"/><path d=\"M25 3h51l22 43-23 43H24L2 46z\" fill=\"#eadb51\" stroke=\"#fff4a5\" stroke-width=\"2\"/><path d=\"M29 12h42l18 34-18 34H29L12 46z\" fill=\"#f4e870\" stroke=\"#d3be40\" stroke-width=\"2\"/><path d=\"m27 11 9 13-17 20 10 23 10-9m30-44-5 13 16 19-12 20-8-7\" fill=\"none\" stroke=\"#fff4a0\" stroke-width=\"4\"/></symbol>\n<symbol id=\"zen-official-human\" viewBox=\"0 0 100 100\"><path d=\"M26 50V15q0-8 8-7v37-40q1-8 9-5v44-39q6-7 11-2v42-32q8-4 10 3v37l8-11q8-6 12 1l-9 15v24L51 99 23 84 15 68V38q6-5 11 1z\" fill=\"#182a29\"/></symbol>\n<symbol id=\"zen-official-robot\" viewBox=\"0 0 100 100\"><g fill=\"#182a29\"><path d=\"m19 4 20 9-14 22 20 15-12 17L3 40zM81 4 61 13l14 22-20 15 12 17 30-27z\"/><circle cx=\"50\" cy=\"57\" r=\"13\"/><path d=\"M35 73h30v17H35zm6 18h18v9H41z\"/></g><path d=\"m42 56 8-6 8 6-8 7z\" fill=\"#ecefd7\"/></symbol>\n<symbol id=\"zen-official-animod\" viewBox=\"0 0 100 100\"><g fill=\"#182a29\"><ellipse cx=\"50\" cy=\"75\" rx=\"29\" ry=\"23\"/><ellipse cx=\"15\" cy=\"44\" rx=\"12\" ry=\"17\" transform=\"rotate(-24 15 44)\"/><ellipse cx=\"38\" cy=\"20\" rx=\"12\" ry=\"18\" transform=\"rotate(-8 38 20)\"/><ellipse cx=\"66\" cy=\"20\" rx=\"12\" ry=\"18\" transform=\"rotate(9 66 20)\"/><ellipse cx=\"88\" cy=\"45\" rx=\"11\" ry=\"17\" transform=\"rotate(22 88 45)\"/></g></symbol>\n<symbol id=\"zen-official-discard\" viewBox=\"0 0 120 180\"><path d=\"m23 8 64-6q9 0 8 10l-5 42-24-9-12 16-22-8z\" fill=\"#182a29\" stroke=\"#fff4cf\" stroke-width=\"3\"/><path d=\"m27 65 28-9 14 13 22-8 10 48-64 6z\" fill=\"#182a29\" stroke=\"#fff4cf\" stroke-width=\"3\"/><path d=\"m62 92 5-22q3-12 10-5l8 19 15 14 4 26-15 31v23H57l-2-28-12-24-9-18 17-2 7 14 9 4-9-14z\" fill=\"#182a29\"/><path d=\"m42 76 13-12 15 12 18-8\" fill=\"none\" stroke=\"#fff8d8\" stroke-width=\"3\"/></symbol>\n<symbol id=\"zen-official-bonus\" viewBox=\"0 0 180 110\"><path d=\"M46 10h88q42 0 42 46t-42 46H46Q4 102 4 56t42-46\" fill=\"#4c5140\"/><path d=\"M46 4h88q42 0 42 45t-42 45H46Q4 94 4 49T46 4\" fill=\"#d9d5af\"/><path d=\"M116 5h18q42 0 42 44t-42 45h-45z\" fill=\"#bebd9c\"/><path d=\"m91 24 8 18 20 2-15 14 4 20-17-10-17 10 4-20-15-14 20-2z\" fill=\"#e6b851\" stroke=\"#fff0b6\" stroke-width=\"3\"/></symbol>\n<symbol id=\"zen-official-leader\" viewBox=\"0 0 180 115\"><g stroke=\"#5b5735\" stroke-width=\"3\" stroke-linejoin=\"round\"><path d=\"m13 33 45-6 31-17 34 17 45 6-3 12-26 5 23 4-5 13-27 2 23 6-9 11-28-2-26 20-29-20-28 2-9-11 23-6-27-2-5-13 23-4-26-5z\" fill=\"#d5a64c\"/><ellipse cx=\"90\" cy=\"54\" rx=\"39\" ry=\"43\" fill=\"#f0c564\"/><ellipse cx=\"90\" cy=\"54\" rx=\"30\" ry=\"34\" fill=\"#dac187\"/><path d=\"m99 13-18 81\" stroke-width=\"7\"/><path d=\"m108 9-18 86\" stroke=\"#ffe6a0\" stroke-width=\"3\"/></g></symbol>\n<symbol id=\"zen-official-planet-0\" viewBox=\"0 0 100 110\"><path d=\"M6 41v19a44 36 0 0 0 88 0V41a44 35 0 0 0-88 0z\" fill=\"#51405d\" stroke=\"#fff3d1\" stroke-width=\"3\"/><path d=\"M10 58q39 37 80 0v13q-37 36-80-1z\" fill=\"#172326\" opacity=\".45\"/><ellipse cx=\"50\" cy=\"41\" rx=\"43\" ry=\"35\" fill=\"#51405d\" stroke=\"#fff3d1\" stroke-width=\"2\"/><g fill=\"#a294b1\" transform=\"translate(0 5) scale(1 .78)\"><path d=\"M24 31h13v12H24zm31-9h13v12H55zm6 33h14v15H61zM25 65h13v12H25zM42 44h12v14H42z\"/></g><ellipse cx=\"50\" cy=\"41\" rx=\"37\" ry=\"29\" fill=\"none\" stroke=\"#a294b1\" stroke-width=\"2\"/></symbol><symbol id=\"zen-official-planet-1\" viewBox=\"0 0 100 110\"><path d=\"M6 41v19a44 36 0 0 0 88 0V41a44 35 0 0 0-88 0z\" fill=\"#8a452c\" stroke=\"#fff3d1\" stroke-width=\"3\"/><path d=\"M10 58q39 37 80 0v13q-37 36-80-1z\" fill=\"#172326\" opacity=\".45\"/><ellipse cx=\"50\" cy=\"41\" rx=\"43\" ry=\"35\" fill=\"#db9554\" stroke=\"#fff3d1\" stroke-width=\"2\"/><g fill=\"#db9554\" transform=\"translate(0 5) scale(1 .78)\"><g fill=\"none\" stroke=\"#8a4e2d\" stroke-width=\"4\" stroke-linecap=\"round\"><ellipse cx=\"29\" cy=\"32\" rx=\"8\" ry=\"9\"/><ellipse cx=\"72\" cy=\"35\" rx=\"8\" ry=\"7\"/><ellipse cx=\"50\" cy=\"70\" rx=\"12\" ry=\"8\"/><path d=\"M19 15q22-5 26 20 3 12-14 24T21 81M43 7q20 15 10 34-4 10-11 15m23-46q-16 20 2 39t15 31M38 85q-17-18 5-28t27 19\"/></g></g><ellipse cx=\"50\" cy=\"41\" rx=\"37\" ry=\"29\" fill=\"none\" stroke=\"#92572f\" stroke-width=\"2\"/></symbol><symbol id=\"zen-official-planet-2\" viewBox=\"0 0 100 110\"><path d=\"M6 41v19a44 36 0 0 0 88 0V41a44 35 0 0 0-88 0z\" fill=\"#17445b\" stroke=\"#fff3d1\" stroke-width=\"3\"/><path d=\"M10 58q39 37 80 0v13q-37 36-80-1z\" fill=\"#172326\" opacity=\".45\"/><ellipse cx=\"50\" cy=\"41\" rx=\"43\" ry=\"35\" fill=\"#17445b\" stroke=\"#fff3d1\" stroke-width=\"2\"/><g fill=\"#4388a2\" transform=\"translate(0 5) scale(1 .78)\"><path d=\"M23 24h16v7h10v13H37v13H25v-8H16V33h7zm36 13h13v10h11v15H69v15H56V64h-7V48h10z\"/></g><ellipse cx=\"50\" cy=\"41\" rx=\"37\" ry=\"29\" fill=\"none\" stroke=\"#4388a2\" stroke-width=\"2\"/></symbol><symbol id=\"zen-official-planet-3\" viewBox=\"0 0 100 110\"><path d=\"M6 41v19a44 36 0 0 0 88 0V41a44 35 0 0 0-88 0z\" fill=\"#7d302d\" stroke=\"#fff3d1\" stroke-width=\"3\"/><path d=\"M10 58q39 37 80 0v13q-37 36-80-1z\" fill=\"#172326\" opacity=\".45\"/><ellipse cx=\"50\" cy=\"41\" rx=\"43\" ry=\"35\" fill=\"#7d302d\" stroke=\"#fff3d1\" stroke-width=\"2\"/><g fill=\"#bc5b48\" transform=\"translate(0 5) scale(1 .78)\"><path d=\"M22 24q18-10 21 8t-14 14-7-22zm35-4q22-8 23 13T61 49t-4-29zM32 64q15-18 31-3t-6 21-25-18z\"/></g><ellipse cx=\"50\" cy=\"41\" rx=\"37\" ry=\"29\" fill=\"none\" stroke=\"#bc5b48\" stroke-width=\"2\"/></symbol><symbol id=\"zen-official-planet-4\" viewBox=\"0 0 100 110\"><path d=\"M6 41v19a44 36 0 0 0 88 0V41a44 35 0 0 0-88 0z\" fill=\"#244e43\" stroke=\"#fff3d1\" stroke-width=\"3\"/><path d=\"M10 58q39 37 80 0v13q-37 36-80-1z\" fill=\"#172326\" opacity=\".45\"/><ellipse cx=\"50\" cy=\"41\" rx=\"43\" ry=\"35\" fill=\"#244e43\" stroke=\"#fff3d1\" stroke-width=\"2\"/><g fill=\"#75a18e\" transform=\"translate(0 5) scale(1 .78)\"><path d=\"M13 33q36 14 74 0v10q-40 14-74 0zm0 24q36 14 74 0v10q-40 14-74 0z\"/></g><ellipse cx=\"50\" cy=\"41\" rx=\"37\" ry=\"29\" fill=\"none\" stroke=\"#75a18e\" stroke-width=\"2\"/></symbol></defs></svg>", Ue = {
	stars: "<svg class=\"zen-star-table\" viewBox=\"0 0 1920 1080\" preserveAspectRatio=\"xMidYMid slice\" aria-hidden=\"true\">\n<g fill=\"none\" stroke=\"#86aaa5\" stroke-width=\"1\">\n  <ellipse cx=\"1760\" cy=\"90\" rx=\"460\" ry=\"182\" transform=\"rotate(-29 1760 90)\" opacity=\".25\"/>\n  <ellipse cx=\"1760\" cy=\"90\" rx=\"320\" ry=\"126\" transform=\"rotate(-29 1760 90)\" opacity=\".18\"/>\n  <ellipse cx=\"138\" cy=\"970\" rx=\"400\" ry=\"163\" transform=\"rotate(-29 138 970)\" opacity=\".21\"/>\n  <ellipse cx=\"138\" cy=\"970\" rx=\"295\" ry=\"118\" transform=\"rotate(-29 138 970)\" opacity=\".16\"/>\n  <path d=\"m1440 29 130 39 81-30 101 69 99-24M19 895l83-19 71 40 96-14\" opacity=\".23\"/>\n  <path d=\"M37 38h93m-93 0v93M1883 1042h-93m93 0v-93\" stroke=\"#c5c5a1\" opacity=\".42\"/>\n</g>\n<g fill=\"#e1d7ae\"><circle cx=\"38\" cy=\"214\" r=\"2.5\" opacity=\".65\"/><circle cx=\"92\" cy=\"55\" r=\"1.4\" opacity=\".35\"/><circle cx=\"236\" cy=\"31\" r=\"1.4\" opacity=\".35\"/><circle cx=\"656\" cy=\"39\" r=\"1.4\" opacity=\".65\"/><circle cx=\"1087\" cy=\"25\" r=\"2.5\" opacity=\".35\"/><circle cx=\"1439\" cy=\"29\" r=\"1.4\" opacity=\".35\"/><circle cx=\"1570\" cy=\"68\" r=\"1.4\" opacity=\".65\"/><circle cx=\"1651\" cy=\"38\" r=\"1.4\" opacity=\".35\"/><circle cx=\"1752\" cy=\"107\" r=\"2.5\" opacity=\".35\"/><circle cx=\"1851\" cy=\"83\" r=\"1.4\" opacity=\".65\"/><circle cx=\"1895\" cy=\"298\" r=\"1.4\" opacity=\".35\"/><circle cx=\"1900\" cy=\"730\" r=\"1.4\" opacity=\".35\"/><circle cx=\"1841\" cy=\"1038\" r=\"2.5\" opacity=\".65\"/><circle cx=\"1295\" cy=\"1057\" r=\"1.4\" opacity=\".35\"/><circle cx=\"893\" cy=\"1050\" r=\"1.4\" opacity=\".35\"/><circle cx=\"411\" cy=\"1035\" r=\"1.4\" opacity=\".65\"/><circle cx=\"269\" cy=\"902\" r=\"2.5\" opacity=\".35\"/><circle cx=\"173\" cy=\"916\" r=\"1.4\" opacity=\".35\"/><circle cx=\"102\" cy=\"876\" r=\"1.4\" opacity=\".65\"/><circle cx=\"19\" cy=\"895\" r=\"1.4\" opacity=\".35\"/><circle cx=\"32\" cy=\"670\" r=\"2.5\" opacity=\".35\"/></g>\n<g fill=\"none\" stroke=\"#d7cca0\" stroke-width=\"1.1\" opacity=\".45\"><path d=\"M1791 27v16m-8-8h16M53 1008v20m-10-10h20M1900 511v10m-5-5h10\"/><circle cx=\"1752\" cy=\"107\" r=\"9\"/><circle cx=\"102\" cy=\"876\" r=\"6\"/></g>\n</svg>",
	board: "<svg class=\"zen-panel-surface\" viewBox=\"0 0 1000 400\" preserveAspectRatio=\"none\" aria-hidden=\"true\">\n  <path d=\"M24 5h376l12 9h176l12-9h376l19 19v352l-19 19H24L5 376V24z\" fill=\"#182f33\"/>\n  <path d=\"M24 2h376l12 9h176l12-9h376l19 19v350l-19 19H24L5 371V21z\" fill=\"#f4efd9\" stroke=\"#2b4545\" stroke-width=\"1.4\" vector-effect=\"non-scaling-stroke\"/>\n  <path d=\"M27 10h369l13 9h182l13-9h369l13 14v339l-13 16H27l-13-16V24z\" fill=\"none\" stroke=\"#c1bc9b\" stroke-width=\"1\" vector-effect=\"non-scaling-stroke\"/>\n  <path d=\"M31 16h360m218 0h360M17 30v327M983 30v327\" fill=\"none\" stroke=\"#fff9df\" stroke-width=\"1.3\" opacity=\".8\" vector-effect=\"non-scaling-stroke\"/>\n  <path d=\"M390 5h9l13 9h176l12-9h9\" fill=\"none\" stroke=\"#718c80\" stroke-width=\"1\" vector-effect=\"non-scaling-stroke\"/>\n  <path d=\"M19 199h962M200 24v352M400 24v352M600 24v352M800 24v352\" fill=\"none\" stroke=\"#bbb99a\" stroke-width=\".8\" opacity=\".45\" vector-effect=\"non-scaling-stroke\"/>\n  </svg>",
	deck: "<svg class=\"zen-panel-surface\" viewBox=\"0 0 1000 400\" preserveAspectRatio=\"none\" aria-hidden=\"true\">\n  <path d=\"M24 5h376l12 9h176l12-9h376l19 19v352l-19 19H24L5 376V24z\" fill=\"#182f33\"/>\n  <path d=\"M24 2h376l12 9h176l12-9h376l19 19v350l-19 19H24L5 371V21z\" fill=\"#dfdfca\" stroke=\"#2b4545\" stroke-width=\"1.4\" vector-effect=\"non-scaling-stroke\"/>\n  <path d=\"M27 10h369l13 9h182l13-9h369l13 14v339l-13 16H27l-13-16V24z\" fill=\"none\" stroke=\"#a3b0a0\" stroke-width=\"1\" vector-effect=\"non-scaling-stroke\"/>\n  <path d=\"M31 16h360m218 0h360M17 30v327M983 30v327\" fill=\"none\" stroke=\"#fff9df\" stroke-width=\"1.3\" opacity=\".8\" vector-effect=\"non-scaling-stroke\"/>\n  <path d=\"M390 5h9l13 9h176l12-9h9\" fill=\"none\" stroke=\"#718c80\" stroke-width=\"1\" vector-effect=\"non-scaling-stroke\"/>\n  \n  </svg>",
	tech: "<svg class=\"zen-tech-surface\" viewBox=\"0 0 160 500\" preserveAspectRatio=\"none\" aria-hidden=\"true\">\n<path d=\"M24 6h42V1h28v5h42l18 19v447l-18 21H94v6H66v-6H24L6 474V25z\" fill=\"#273e3c\"/>\n<path d=\"M24 2h42v12h28V2h42l18 19v447l-18 21H94v-12H66v12H24L6 470V21z\" fill=\"#e8c960\" stroke=\"#6f6c46\" stroke-width=\"1.3\" vector-effect=\"non-scaling-stroke\"/>\n<path d=\"M25 10h32v12h46V10h32l11 14v441l-12 15h-31v-12H57v12H25l-11-14V24z\" fill=\"none\" stroke=\"#fff0ad\" stroke-width=\"1\" vector-effect=\"non-scaling-stroke\"/>\n<path d=\"M22 40h116M22 455h116\" fill=\"none\" stroke=\"#b99e4f\" stroke-width=\"1\" vector-effect=\"non-scaling-stroke\"/>\n</svg>",
	senate: "<svg class=\"zen-senate-backdrop\" viewBox=\"0 0 600 200\" preserveAspectRatio=\"none\" aria-hidden=\"true\">\n<path d=\"M4 196V94Q6 4 97 4h406q91 0 93 90v102z\" fill=\"#3b304e\"/>\n<path d=\"M14 196V96q0-80 85-80h402q85 0 85 80v100z\" fill=\"#6c547d\" stroke=\"#a28ba8\" stroke-width=\"1\" vector-effect=\"non-scaling-stroke\"/>\n<path d=\"M34 176v-69q0-69 72-69h388q72 0 72 69v69M55 176v-60q0-56 60-56h370q60 0 60 56v60M76 176v-50q0-45 48-45h352q48 0 48 45v50\" fill=\"none\" stroke=\"#c9aec5\" stroke-width=\"1.1\" opacity=\".45\" vector-effect=\"non-scaling-stroke\"/>\n<path d=\"M121 176V94m61 82V82m61 94V81m114 95V81m61 95V82m61 94V94\" fill=\"none\" stroke=\"#3b304e\" stroke-width=\"1\" opacity=\".3\" vector-effect=\"non-scaling-stroke\"/>\n<path d=\"M236 196v-34q0-30 64-30t64 30v34\" fill=\"#473958\" stroke=\"#b2a5b3\" stroke-width=\"1\" vector-effect=\"non-scaling-stroke\"/>\n</svg>"
}, We = {
	recruit: "<svg class=\"zen-action-emblem\" viewBox=\"0 0 64 64\" aria-hidden=\"true\"><g stroke=\"#29423b\" stroke-width=\"1.5\" stroke-linejoin=\"round\"><path d=\"M14 5h34l6 6v49H8V11z\" fill=\"#e9e1b8\"/><path d=\"M14 13h34v41H14z\" fill=\"#bca762\"/><circle cx=\"31\" cy=\"27\" r=\"9\" fill=\"#f2eac9\"/><path d=\"M17 51v-5q0-12 14-12t14 12v5\" fill=\"#f2eac9\"/><path d=\"M20 9h22\" fill=\"none\" stroke=\"#fff5d4\" stroke-width=\"2\"/></g></svg>",
	develop: "<svg class=\"zen-action-emblem\" viewBox=\"0 0 64 64\" aria-hidden=\"true\"><g stroke=\"#29423b\" stroke-width=\"1.5\" stroke-linejoin=\"round\"><path d=\"M13 60V18l8-8h26l6 8v42z\" fill=\"#b3c5ae\"/><path d=\"M19 18h28v12H19zm0 17h28v9H19zm0 14h28v8H19z\" fill=\"#44685b\"/><path d=\"M26 5h14v10H26z\" fill=\"#e7dba7\"/><path d=\"m33 21 5 4-5 4-5-4z\" fill=\"#e9db9f\"/><path d=\"m15 41 5-7 5 7-5 7z\" fill=\"#f5edca\"/><path d=\"m41 54 5-7 5 7-5 7z\" fill=\"#253d3b\"/></g></svg>",
	leader: "<svg class=\"zen-action-emblem\" viewBox=\"0 0 64 64\" aria-hidden=\"true\"><g stroke=\"#29423b\" stroke-width=\"1.5\" stroke-linejoin=\"round\"><path d=\"m3 17 18 3L32 9l11 11 18-3-4 13-12 3 9 3-3 9-12 1-7 12-9-12-12-1-3-9 10-3-12-3z\" fill=\"#a3c0b1\"/><circle cx=\"32\" cy=\"32\" r=\"19\" fill=\"#d8d5b4\"/><circle cx=\"32\" cy=\"32\" r=\"14\" fill=\"#eef0cc\"/><path d=\"m32 21 3 8 8 3-8 3-3 8-3-8-8-3 8-3z\" fill=\"#81794a\"/></g></svg>"
}, Ge = {
	silver: "<svg class=\"zen-leader\" viewBox=\"0 0 130 85\" aria-hidden=\"true\"><g stroke=\"#293e40\" stroke-width=\"3\" stroke-linejoin=\"round\"><path d=\"m12 21 34 4 18-12 18 12 36-4-4 15-20 4 16 3-6 13-21 1-18 17-19-17-21-1-6-13 16-3-20-4z\" fill=\"#2f4346\"/><path d=\"m16 27 26 4-3 6-23-3zm3 17 23 0 2 6-21 0zm95-17-27 4 3 6 23-3zm-3 17-23 0-2 6 21 0z\" fill=\"#75a5aa\" stroke=\"none\"/><circle cx=\"65\" cy=\"42\" r=\"29\" fill=\"#bac6bf\"/><circle cx=\"65\" cy=\"42\" r=\"22\" fill=\"#e0e2d3\" stroke-width=\"1.5\"/><path d=\"m51 29 24 0-2 7H59v4h9q10 0 10 9-1 11-14 11-11-1-12-9h9q2 4 6 1 3-5-4-5H51z\" fill=\"#3e514e\" stroke=\"none\"/></g></svg>",
	gold: "<svg class=\"zen-leader\" viewBox=\"0 0 130 85\" aria-hidden=\"true\"><g stroke=\"#6d673d\" stroke-width=\"1.5\"><path d=\"m20 40 15-8 12-16 18 4 18-4 12 16 15 8-15 10-12 17-18-4-18 4-12-17z\" fill=\"#d6b865\"/><circle cx=\"65\" cy=\"41\" r=\"30\" fill=\"#ead69c\"/><circle cx=\"65\" cy=\"41\" r=\"24\" fill=\"#f5e8bd\"/><ellipse cx=\"65\" cy=\"41\" rx=\"37\" ry=\"11\" fill=\"none\" transform=\"rotate(-20 65 41)\" stroke=\"#ad8e4c\"/><path d=\"m65 19 5 15 15 7-15 5-5 16-5-16-15-5 15-7z\" fill=\"#ad8e4c\" stroke=\"none\"/><circle cx=\"65\" cy=\"41\" r=\"7\" fill=\"#f9efd0\" stroke=\"none\"/></g></svg>"
}, K = "#172d2c", q = "#fff3ce", Ke = `<svg width="0" height="0" aria-hidden="true"><defs>
<symbol id="zen-effect-card" viewBox="0 0 100 130"><path d="M14 4h70l9 9v112H7V13z" fill="#e1e8ce" stroke="${K}" stroke-width="5"/><path d="M17 18h66v91H17z" fill="#395950"/><circle cx="50" cy="48" r="15" fill="#e3dcb7"/><path d="M24 100q0-32 26-32t26 32" fill="#e3dcb7"/></symbol>
<symbol id="zen-effect-any" viewBox="0 0 100 110"><ellipse cx="50" cy="61" rx="45" ry="39" fill="#172c31" stroke="${q}" stroke-width="3"/><ellipse cx="50" cy="43" rx="45" ry="37" fill="#43535b" stroke="${q}" stroke-width="3"/><path d="M14 43h72M50 8c-28 25-28 46 0 71M50 8c28 25 28 46 0 71" stroke="#b6c1af" fill="none" stroke-width="3"/></symbol>
<symbol id="zen-effect-tech" viewBox="0 0 100 150"><path d="M13 145V15L25 3h52l12 12v130z" fill="#fff2b4" stroke="${K}" stroke-width="4"/><path d="m50 14 18 26H32zM25 54h50v18H25zm0 29h50v18H25zm0 29h50v18H25z" fill="${K}"/></symbol>
<symbol id="zen-effect-reset" viewBox="0 0 100 100"><path d="M84 36A38 38 0 1 0 88 65" fill="none" stroke="${q}" stroke-width="12"/><path d="m64 34 28 8 2-31z" fill="${q}"/><path d="M50 25v50m-25-25h50" stroke="${K}" stroke-width="5"/><circle cx="50" cy="50" r="10" fill="${q}"/></symbol>
<symbol id="zen-effect-exile" viewBox="0 0 130 150"><path d="M12 45h73v100H12z" fill="#f2ebc9" stroke="${K}" stroke-width="5"/><path d="M25 62h47v48H25z" fill="#35514b"/><path d="M59 62V26H42L77 3l36 23H96v36z" fill="${q}" stroke="${K}" stroke-width="4"/><path d="m30 123 33-42m-33 0 33 42" stroke="${K}" stroke-width="6"/></symbol>
<symbol id="zen-effect-transfer" viewBox="0 0 150 130"><path d="M6 4h58v96H6zM87 29h58v96H87z" fill="#e3e4c3" stroke="${K}" stroke-width="5"/><path d="M23 55h65V34l47 34-47 33V80H23z" fill="${q}" stroke="${K}" stroke-width="4"/></symbol>
<symbol id="zen-effect-eye" viewBox="0 0 100 70"><path d="M4 35Q50-20 96 35 50 90 4 35" fill="${q}" stroke="${K}" stroke-width="5"/><circle cx="50" cy="35" r="20" fill="${K}"/><circle cx="44" cy="29" r="5" fill="${q}"/></symbol>
</defs></svg>`, J = (e, t, n, r, i = r) => `<use href="#${e.startsWith("effect-") ? "zen-" : "zen-official-"}${e}" x="${t}" y="${n}" width="${r}" height="${i}"/>`, Y = (e, t, n, r = 80, i = K) => `<text x="${t}" y="${n}" text-anchor="middle" font-family="Impact,Arial Black,sans-serif" font-weight="900" font-size="${r}" fill="${i}">${e}</text>`, X = (e, t, n, r = 1) => `<g transform="translate(${t} ${n}) scale(${r})">${e}</g>`, qe = (e, t, n = 50) => J("next", e, t, n, 90), Je = () => J("give", 78, 4, 75, 75), Ye = (e, t = 20, n = 72, r = 190) => J(e.planet == null ? "effect-any" : "planet-" + e.planet, t, n, r, r * 1.1), Xe = (e, t) => `${J(e, 32, 105, 165)}${Y(t, 110, 228, 103)}`, Ze = (e) => `${e.except == null ? "" : `${J("planet-" + e.except, 142, 9, 64, 70)}<path d="m144 8 62 64" stroke="${q}" stroke-width="10"/>`}${e.enemySide ? `<path d="M30 15h160v40H30z" fill="${K}"/><circle cx="78" cy="35" r="17" fill="${q}"/><path d="M110 11v48" stroke="${q}" stroke-width="5"/>` : ""}${e.center ? `<path d="M40 32h150M115 9v47" stroke="${q}" stroke-width="5"/><circle cx="115" cy="32" r="15" fill="${K}" stroke="${q}" stroke-width="5"/>` : ""}${e.different ? `<path d="M50 33h125m-73-20-14 40m46-40-14 40" stroke="${q}" stroke-width="8"/>` : ""}${e.resetUsed ? J("effect-reset", 5, 8, 54) : ""}`;
function Qe(e, t = !1) {
	let n = e.n ?? (t ? "X" : 1), r = 230, i = "";
	switch (e.kind) {
		case "influence":
		case "giveInfluence":
			e.pattern ? (r = Math.max(370, e.pattern.length * 160), i = e.pattern.map((e, t) => X(`${Ye({ kind: "influence" }, 20, 72, 115)}${Array.from({ length: e }, (e, t) => J("down", 47, 193 + t * 49, 62, 50)).join("")}`, t * 155, 0)).join("") + `<path d="M38 65H${r - 35}" stroke="${q}" stroke-width="8"/>`) : i = `${Ze(e)}${Ye(e)}${e.kind === "giveInfluence" ? Je() : ""}${e.points ? `${Y(e.points, 113, 330, 80, q)}<path d="m42 300 145 0m-124 24-23-24 23-24m101 0 23 24-23 24" stroke="${q}" stroke-width="7" fill="none"/>` : typeof n == "number" && n > 3 ? `${J(e.kind === "giveInfluence" ? "give" : "down", 71, 267, 84, 66)}${Y(n, 113, 409, 76, q)}` : Array.from({ length: typeof n == "number" ? n : 1 }, (t, n) => J(e.kind === "giveInfluence" ? "give" : "down", 71, 267 + n * 48, 84, 66)).join("")}`;
			break;
		case "credits":
		case "zenithium": {
			let t = e.kind === "credits" ? "credit" : "crystal";
			i = Xe(t, e.upTo ?? n), e.upTo != null && (i += `<path d="M15 250V70h190" fill="none" stroke="${q}" stroke-width="8"/>${J("next", 180, 31, 37, 75)}`), (e.colorCount || e.enemyColorCount) && (i = `${[
				0,
				1,
				2,
				3,
				4
			].map((e, t) => J("planet-" + e, 14 + t * 41, 25, 39, 45)).join("")}${Y("×" + (e.colorCount ?? e.enemyColorCount), 112, 96, 50, q)}${i}`, e.enemyColorCount && (i += Je())), e.techCount && (r = 350, i = e.techCount.map((e, n) => X(`${J("effect-tech", 0, 22, 55, 80)}${Y(n + 1, 28, 76, 35, q)}${qe(63, 34, 25)}${X(Xe(t, e), 82, -11, .57)}`, 0, n * 115)).join("")), e.opponent && (i += Je());
			break;
		}
		case "giveCredits":
		case "giveZenithium":
		case "spendCredits":
		case "spendZenithium":
		case "stealCredits":
		case "stealZenithium": {
			let t = e.kind.endsWith("Credits") ? "credit" : "crystal";
			e.amounts ? (r = 280, i = e.amounts.map((e, n) => X(Xe(t, e), 0, n * 110 - 25, .7)).join("")) : i = Xe(t, n), i += e.kind.startsWith("give") ? Je() : e.kind.startsWith("steal") ? `<path d="M24 28h165l-35-24m35 24-35 24" fill="none" stroke="${q}" stroke-width="10"/>` : J("down", 80, 10, 70, 70);
			break;
		}
		case "leader":
		case "giveLeader":
			i = `${e.kind === "giveLeader" ? Je() : ""}${J("leader", 10, 100, 210, 145)}${e.gold ? `<path d="m115 267 16 28 29 6-22 20 4 31-27-15-27 15 4-31-22-20 29-6z" fill="#f7d86c" stroke="${q}" stroke-width="4"/>` : ""}`;
			break;
		case "discard":
			i = J("discard", 42, 25, 150, 310) + (e.full ? `${J("effect-card", 7, 70, 46, 60)}${J("effect-card", 180, 70, 46, 60)}${Y("∀", 110, 365, 54, q)}` : "");
			break;
		case "mobilize":
		case "exile":
		case "transfer":
		case "share": {
			let t = e.kind === "exile" ? "effect-exile" : e.kind === "transfer" || e.kind === "share" ? "effect-transfer" : "effect-card";
			i = `${Ze(e)}${J(t, 39, 91, 155, 200)}${Y(n, 115, 350, 70, q)}`, e.kind === "mobilize" && (i += `${J("down", 175, 155, 48, 70)}<path d="M25 85h142" stroke="${q}" stroke-width="6"/>`), e.opponent && (i += Je()), e.planet != null && (i += J("planet-" + e.planet, 10, 11, 65, 71));
			break;
		}
		case "develop":
			i = `${J("effect-tech", 89, 65, 120, 245)}${e.faction ? J(e.faction, 107, 149, 81, 83) : Y("?", 149, 226, 90)}${X(Xe("crystal", e.free ? 0 : e.discount ? "X−" + e.discount : "X"), -29, 8, .63)}${qe(51, 141, 35)}${e.lowest ? `<path d="M57 330h145m-110-23 33 23-33 23" fill="none" stroke="${q}" stroke-width="8"/>` : ""}`;
			break;
		case "bonus":
		case "techBonus":
			i = `${J("bonus", 4, 112, 222, 145)}${e.visible ? J("effect-eye", 64, 15, 110, 80) : ""}${e.kind === "techBonus" ? `${J("effect-tech", 18, 10, 70, 100)}${Y(2, 54, 72, 42)}` : ""}`;
			break;
		case "reset":
			i = J("effect-reset", 20, 80, 190);
			break;
		case "choice": {
			let t = $e(e.left ?? []), n = $e(e.right ?? []);
			r = t.width + n.width + 110, i = `${t.body}${Y("/", t.width + 48, 250, 116, q)}${X(n.body, t.width + 110, 0)}`;
			break;
		}
		case "condition": {
			let t = e.condition, n = t.effect, a = Qe(e.effect, t.kind === "pay" && e.effect.n == null && !n?.factors);
			if (t.kind === "pay" && n?.amounts) {
				r = 660;
				let t = n.kind === "exile" ? "effect-exile" : n.kind === "spendCredits" ? "credit" : "crystal";
				i = `${Ze(n)}${J(t, 5, 123, 135, 180)}${n.amounts.map((t, r) => `${Y(t, 197, 109 + r * 132, 90, q)}${qe(257, 40 + r * 132, 60)}${Y(n.factors?.[r] ?? e.effect.n ?? "X", 390, 109 + r * 132, 90, q)}`).join("")}${X(Qe({
					...e.effect,
					n: 1
				}).body, 465, 44, .7)}`;
			} else if (t.kind === "pay") {
				let t = Qe(n), o = Math.min(1, 260 / t.width), s = Math.min(1, 260 / a.width);
				r = 600, i = `${X(t.body, 0, 0, o)}${qe(258, 155, 50)}${X(a.body, 325, 0, s)}`, e.mandatory && (i += `<path d="M6 10h575" stroke="${q}" stroke-width="7"/>`);
			} else {
				let e = t.kind === "leader" || t.kind === "enemyLeader";
				r = 350, i = `<path d="M10 12h310v103H10z" fill="#fff0c526" stroke="${q}" stroke-width="4"/>${e ? J("leader", 95, 15, 140, 90) : X(Xe(t.kind === "enemyZenithium" ? "crystal" : "credit", t.min ?? 0), 85, -38, .55)}${t.kind.startsWith("enemy") ? X(Je(), -40, 5, .8) : ""}${qe(141, 116, 40)}${X(a.body, 52, 175, .6)}`;
			}
			break;
		}
	}
	if (!i) throw Error(`Unsupported Zenith effect: ${e.kind}`);
	return {
		width: r,
		body: `<g data-effect="${e.kind}"${e.condition ? ` data-condition="${e.condition.kind}"` : ""}>${i}</g>`
	};
}
function $e(e) {
	let t = e.map((e) => Qe(e)), n = Math.max(1, t.reduce((e, t) => e + t.width + 22, 0)), r = 0;
	return {
		width: n,
		body: t.map((e, t) => {
			let n = r;
			return r += e.width + 22, `${t ? `<path d="M${n - 11} 15v380" stroke="${q}" stroke-width="10"/>` : ""}${X(e.body, n, 0)}`;
		}).join("")
	};
}
//#endregion
//#region src/games/zenith/portraits.tsx
var et = {
	AgentEzra: [
		"helmet",
		"round",
		"visor",
		"scanner"
	],
	DonaldSmooth: [
		"quiff",
		"long",
		"smile",
		"cards"
	],
	PunkMari: [
		"spike",
		"narrow",
		"paint",
		"cards"
	],
	DoubleJoe: [
		"braids",
		"square",
		"beard",
		"glass"
	],
	DonDune: [
		"curls",
		"square",
		"scar",
		"glass"
	],
	JackCurry: [
		"cap",
		"long",
		"beard",
		"glass"
	],
	LadyMoore: [
		"swept",
		"long",
		"stern",
		"device"
	],
	StessyPower: [
		"bun",
		"round",
		"goggles",
		"pipe"
	],
	GuyGambler: [
		"quiff",
		"long",
		"moustache",
		"coin"
	],
	DocWissen: [
		"swept",
		"round",
		"moustache",
		"pipe"
	],
	BaronGoro: [
		"hood",
		"square",
		"beard",
		"device"
	],
	MasterDin: [
		"bald",
		"round",
		"stern",
		"orb"
	],
	LordCreep: [
		"mane",
		"long",
		"beard",
		"claw"
	],
	QueenSuzanne: [
		"curls",
		"round",
		"smile",
		"fan"
	],
	IldaFlores: [
		"braids",
		"narrow",
		"goggles",
		"orb"
	],
	LisaCharity: [
		"bun",
		"narrow",
		"smile",
		"glass"
	],
	SirSam: [
		"bald",
		"square",
		"stern",
		"fists"
	],
	HelenaKerr: [
		"short",
		"square",
		"smile",
		"fists"
	],
	LittleBob: [
		"cap",
		"round",
		"smile",
		"device"
	],
	LulaSmart: [
		"fringe",
		"narrow",
		"visor",
		"cards"
	],
	CharlizeGun: [
		"swept",
		"narrow",
		"paint",
		"device"
	],
	ProfessorZed: [
		"bald",
		"long",
		"beard",
		"orb"
	],
	IceJune: [
		"fringe",
		"long",
		"stern",
		"orb"
	],
	KingHarold: [
		"bald",
		"round",
		"smile",
		"glass"
	],
	HandyLuke: [
		"bald",
		"square",
		"stern",
		"device"
	],
	SneakyJules: [
		"cap",
		"long",
		"moustache",
		"cards"
	],
	SecretKali: [
		"curls",
		"round",
		"paint",
		"coin"
	],
	CaptainAndreev: [
		"cap",
		"square",
		"beard",
		"fists"
	],
	MiladyJones: [
		"bun",
		"long",
		"goggles",
		"fan"
	],
	AdmiralJack: [
		"swept",
		"square",
		"moustache",
		"device"
	],
	PrincessUxmal: [
		"braids",
		"narrow",
		"paint",
		"orb"
	],
	CelestinPetit: [
		"short",
		"round",
		"goggles",
		"scanner"
	],
	DandyMuller: [
		"quiff",
		"long",
		"moustache",
		"glass"
	]
}, tt = {
	Titus: "lizard",
	Cresus: "squirrel",
	Atlas: "mouse",
	Septimus: "hound",
	Suleiman: "toucan",
	Annie: "rooster",
	Gilgamesh: "elephant",
	Felis: "tiger",
	Ramses: "panther",
	Ivan: "woodpecker",
	Zenon: "fox",
	Domitian: "bear",
	Amytis: "fennec",
	Arnulf: "husky",
	Caesar: "baboon",
	Magellan: "lion",
	Bajazet: "boar",
	Geta: "meerkat",
	Charlemagne: "hippo",
	Caligula: "parrot",
	Tiberius: "crocodile",
	Augustus: "gorilla",
	Geronimo: "raccoon",
	Nero: "buffalo",
	Chaka: "otter",
	Pachacuti: "macaw",
	Khan: "panda",
	Moussa: "beetle",
	Archimedes: "hare",
	Mungo: "koala",
	Ragnar: "ram",
	Demetrios: "deer"
}, nt = {
	Pkd1ck: [
		"monitor",
		"mint",
		"book"
	],
	Huxl3y: [
		"orb",
		"violet",
		"arms"
	],
	Mc4ffr3y: [
		"capsule",
		"blue",
		"scanner"
	],
	Luc4s: [
		"wedge",
		"gold",
		"device"
	],
	V3rn3: [
		"diver",
		"blue",
		"globe"
	],
	Ch4mb3rs: [
		"sphere",
		"mint",
		"claw"
	],
	Buj0ld: [
		"cylinder",
		"gold",
		"book"
	],
	C1x1n: [
		"oval",
		"gold",
		"glass"
	],
	L0v3cr4ft: [
		"tentacle",
		"blue",
		"arms"
	],
	M4th3s0n: [
		"monitor",
		"blue",
		"book"
	],
	V4nc3: [
		"monitor",
		"gold",
		"device"
	],
	F4rm3r: [
		"diver",
		"blue",
		"device"
	],
	Bish0p: [
		"cylinder",
		"red",
		"device"
	],
	Wul: [
		"oval",
		"violet",
		"fists"
	],
	Th0mps0n: [
		"sphere",
		"mint",
		"glass"
	],
	W4ts0n: [
		"sphere",
		"red",
		"coin"
	],
	R0bins0n: [
		"monitor",
		"red",
		"fists"
	],
	H4milt0n: [
		"saucer",
		"violet",
		"arms"
	],
	H3rb3rt: [
		"oval",
		"blue",
		"book"
	],
	And3rs0n: [
		"wedge",
		"red",
		"glass"
	],
	As1m0v: [
		"diver",
		"gold",
		"clock"
	],
	Bruss0l0: [
		"saucer",
		"mint",
		"arms"
	],
	B4rj4v3l: [
		"sphere",
		"mint",
		"claw"
	],
	V4nV0gt: [
		"monitor",
		"gold",
		"device"
	],
	W3lls: [
		"capsule",
		"violet",
		"orb"
	],
	Cl4rke: [
		"cylinder",
		"violet",
		"scanner"
	],
	M4rt1n: [
		"cylinder",
		"mint",
		"device"
	],
	Gibs0n: [
		"tentacle",
		"mint",
		"book"
	],
	S1mmons: [
		"capsule",
		"violet",
		"fists"
	],
	W1ll1s: [
		"monitor",
		"red",
		"scanner"
	],
	Boull3: [
		"oval",
		"gold",
		"globe"
	]
}, rt = {
	stroke: "#273638",
	strokeWidth: 2.8,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, it = {
	round: "M99 106q0-52 43-52t44 52l-4 43q-7 40-40 42-34-7-40-42z",
	square: "M100 94q4-40 43-40t43 40v62l-18 28h-50l-18-28z",
	long: "M106 87q8-40 39-36 35 3 35 41l-7 71-27 32-32-33z",
	narrow: "M106 98q-2-43 35-45t41 45l-10 56-29 32-27-29z"
}, at = {
	helmet: "M94 105V83q1-42 49-42t51 42v30l-16-6-7-29h-51l-10 27z",
	quiff: "M100 107q-22-28 6-43-18-30 21-32 14-27 43-10 21-4 17 22 24 21-2 56l-10-27-18 8-28-8-10 34z",
	curls: "M97 118q-25-7-21-32-12-22 9-34-5-28 26-28 12-29 38-12 30-12 38 17 32 0 28 27 23 17 4 37 1 24-24 27l-12-42-16-12-19 8-27-3-13 22z",
	short: "M98 111V76l21-25 40-5 28 25 3 42-16-31-20 3-18-15-20 20-8 25z",
	swept: "M99 115q-21-32 0-51 1-31 33-30 34-25 68 4l24 8-12 14 8 8-39 20-10-11-21 5-33-10-8 45z",
	bun: "M109 65q-18-8-9-29 3-19 25-16 24-15 41 3 25 6 12 27l-17 15M99 110V85q4-35 40-35 37 0 48 34l-6 30-12-35-32-9-24 23-9 23z",
	cap: "M90 92V65l22-28h63l23 24v28zM88 87h115l-7 16-47 7-48-9z",
	spike: "m94 109-8-26 14-19-8-17 29 3 10-31 18 26 30-10-3 25 23 14-18 42-12-29-31-8-26 26z",
	braids: "M99 116q-17-44 5-64 21-24 52-14 31 1 38 35l-14 43-14-39-23-13-23 20-9 36zm-1-7-16 50 5 44 16-9 8-51zm81 0 14 29-4 50 16 16 9-34-9-51z",
	fringe: "M97 113q-13-61 21-73 41-18 67 15l5 56-16-33-4 48-26-52-25 40-8-29z",
	hood: "M78 151q-20-89 29-110 55-27 87 16l16 93-29 31 1-81-34-30-38 23-4 84z",
	mane: "M97 183q-45-17-28-44-30-22-3-45-17-31 15-44-1-27 29-25 28-26 44-8 39-11 47 20 36 15 19 44 26 34-3 53 10 41-27 55l-9-96-34-29-39 27z",
	bald: "M106 82q-5-30 31-35 32-6 44 27l-15-12-28-8-19 16z"
};
function ot({ kind: e, color: t }) {
	return /* @__PURE__ */ y("g", {
		...rt,
		children: [
			"device",
			"scanner",
			"book",
			"cards"
		].includes(e) ? /* @__PURE__ */ b(v, { children: [
			/* @__PURE__ */ y("path", {
				d: "m48 198 41-14 28 62-45 16z",
				fill: e === "cards" ? "#f5e4bb" : "#c4d3c5"
			}),
			/* @__PURE__ */ y("path", {
				d: "m57 202 25-8 16 42-25 9z",
				fill: t
			}),
			/* @__PURE__ */ y("path", {
				d: "m64 211 18-5m-13 16 17-5m-11 17 12-4",
				stroke: "#e7f1d0",
				strokeWidth: "3"
			})
		] }) : e === "glass" || e === "pipe" ? /* @__PURE__ */ b(v, { children: [
			/* @__PURE__ */ y("path", {
				d: "m62 220 25-7 12 35-24 8z",
				fill: "#dae5d3"
			}),
			/* @__PURE__ */ y("path", {
				d: "m70 230 19-5 5 18-18 6z",
				fill: "#d9a353"
			}),
			/* @__PURE__ */ y("path", {
				d: "m83 253 5 20m-16 4 32-8",
				fill: "none"
			}),
			e === "pipe" && /* @__PURE__ */ y("path", {
				d: "m91 217 14-6-7-12 16-10",
				fill: "none",
				stroke: "#eff1d8"
			})
		] }) : e === "fan" ? /* @__PURE__ */ y("path", {
			d: "m53 243 8-58 28-15 26 19 7 49-34 21z",
			fill: "#d6bd68"
		}) : e === "claw" ? /* @__PURE__ */ y("path", {
			d: "m64 251-12-30 7-17 12 14 9-20 15 6 4 34-17 17z",
			fill: "#b5c3b1"
		}) : /* @__PURE__ */ b(v, { children: [
			/* @__PURE__ */ y("circle", {
				cx: "80",
				cy: "229",
				r: "24",
				fill: e === "coin" || e === "clock" ? "#d9b95d" : "#a7c5be"
			}),
			/* @__PURE__ */ y("circle", {
				cx: "80",
				cy: "229",
				r: "17",
				fill: "none",
				stroke: "#f9e9b3"
			}),
			e === "clock" ? /* @__PURE__ */ y("path", {
				d: "M80 216v15l11 7",
				fill: "none"
			}) : /* @__PURE__ */ y("path", {
				d: "m80 213 4 11 11 5-11 4-4 12-4-12-11-4 11-5z",
				fill: "#f3dda0"
			})
		] })
	});
}
function st({ id: e, color: t }) {
	let [n, r, i, a] = et[e], o = r === "square" ? "#b4896d" : i === "paint" ? "#bd916e" : "#e7bb8f";
	return /* @__PURE__ */ b("g", {
		...rt,
		children: [
			/* @__PURE__ */ y("path", {
				d: "M58 286q-4-69 34-85l38-16h27l43 20q39 23 34 81",
				fill: t
			}),
			/* @__PURE__ */ y("path", {
				d: "m91 207 26-13 27 45-20 47H82zm80-11 25 12 15 78h-40l-17-48z",
				fill: "#253e46"
			}),
			/* @__PURE__ */ y("path", {
				d: "M123 169v35l20 23 22-25v-35",
				fill: o
			}),
			/* @__PURE__ */ y("path", {
				d: "m116 197 27 28-16 18-21-33m58-13-21 28 17 16 17-33",
				fill: "#e8cf86"
			}),
			/* @__PURE__ */ y("path", {
				d: it[r],
				fill: o
			}),
			/* @__PURE__ */ y("path", {
				d: "M103 124q4 40 36 56l19-4-16 14-26-23z",
				fill: "#9a7056",
				opacity: ".38",
				stroke: "none"
			}),
			/* @__PURE__ */ y("path", {
				d: at[n],
				fill: n === "swept" || n === "curls" ? "#c6c4b4" : n === "fringe" ? "#995369" : n === "bun" ? "#446b72" : "#40474b"
			}),
			/* @__PURE__ */ y("path", {
				d: "m115 111 13-3m27 1 13 3m-29 3-5 22 13 3",
				fill: "none"
			}),
			/* @__PURE__ */ y("path", {
				d: i === "smile" ? "M124 155q20 14 37-2" : i === "stern" ? "m124 158 34-2" : "m125 151 12-3m13 1 12 3",
				fill: "none",
				strokeWidth: "3"
			}),
			i === "beard" && /* @__PURE__ */ y("path", {
				d: "m108 142 14 6 20 13 25-14 12-9-8 39-29 23-25-24z",
				fill: "#68685b"
			}),
			i === "moustache" && /* @__PURE__ */ y("path", {
				d: "m142 143-16-6-15 13 31 1 30-1-15-13z",
				fill: "#eee6cf"
			}),
			(i === "visor" || i === "goggles") && /* @__PURE__ */ b(v, { children: [
				/* @__PURE__ */ y("path", {
					d: "M106 101h73v24h-73z",
					fill: "#a9c6ba"
				}),
				/* @__PURE__ */ y("path", {
					d: "M111 105h24v16h-24zm37 0h24v16h-24z",
					fill: "#29474a"
				}),
				/* @__PURE__ */ y("path", {
					d: "m116 110 12 0m25 0h12",
					stroke: "#c1ddd2"
				})
			] }),
			i === "paint" && /* @__PURE__ */ y("path", {
				d: "m112 119 15 13m36-14-8 16",
				stroke: "#91bda9",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ y("path", {
				d: "m68 251 21-11 27 16-12 24-30-6m121-40-27 16-15 22 23 10 27-22",
				fill: o
			}),
			/* @__PURE__ */ y(ot, {
				kind: a,
				color: t
			}),
			/* @__PURE__ */ y("circle", {
				cx: "183",
				cy: "215",
				r: "6",
				fill: "#ebc66d"
			}),
			/* @__PURE__ */ y("path", {
				d: "m181 213 5 4m-47 37 22-9",
				stroke: "#e3cb86"
			})
		]
	});
}
function ct({ species: e, color: t }) {
	let n = [
		"toucan",
		"woodpecker",
		"rooster",
		"parrot",
		"macaw"
	].includes(e), r = ["lizard", "crocodile"].includes(e), i = [
		"panther",
		"bear",
		"gorilla",
		"buffalo"
	].includes(e), a = n ? e === "rooster" ? "#bf6b37" : e === "toucan" ? "#294944" : "#caa256" : r ? "#78967e" : i ? "#6b6553" : [
		"fox",
		"squirrel",
		"tiger",
		"lion"
	].includes(e) ? "#cda15d" : e === "hippo" ? "#b39a97" : "#c4b99c", o = [
		"fox",
		"fennec",
		"husky",
		"tiger",
		"raccoon",
		"squirrel",
		"deer",
		"panther"
	].includes(e);
	return /* @__PURE__ */ b("g", {
		...rt,
		children: [
			/* @__PURE__ */ y("path", {
				d: "M63 286q-9-70 35-90l35-12 40 7q44 15 47 95",
				fill: t
			}),
			/* @__PURE__ */ y("path", {
				d: "m103 201 37 29-16 56H86zm62-8-25 37 23 55h42l-21-72z",
				fill: "#293d46"
			}),
			/* @__PURE__ */ y("path", {
				d: "m130 193 11 30 22-29-7 49-16 14-8-34z",
				fill: "#e6d3a5"
			}),
			o && /* @__PURE__ */ y("path", {
				d: e === "fennec" ? "m102 94-26-65 48 27m39 6 51-38-28 83" : e === "deer" ? "m99 94-31-26 11-13 33 19m57-2 28-20 20 9-34 33" : "m102 90-15-44 39 18m33 0 36-26-12 52",
				fill: a
			}),
			[
				"hare",
				"mouse",
				"koala",
				"panda",
				"ram",
				"bear"
			].includes(e) && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("ellipse", {
				cx: "100",
				cy: e === "hare" ? 42 : 75,
				rx: e === "hare" ? 13 : 21,
				ry: e === "hare" ? 51 : 21,
				fill: a,
				transform: "rotate(-17 100 75)"
			}), /* @__PURE__ */ y("ellipse", {
				cx: "176",
				cy: e === "hare" ? 42 : 68,
				rx: e === "hare" ? 14 : 23,
				ry: e === "hare" ? 52 : 21,
				fill: a,
				transform: "rotate(13 176 68)"
			})] }),
			e === "elephant" && /* @__PURE__ */ y(v, { children: /* @__PURE__ */ y("path", {
				d: "M115 75q-65-16-49 65 11 42 43 19m54-80q57-20 50 42-5 44-34 43",
				fill: a
			}) }),
			[
				"ram",
				"buffalo",
				"deer",
				"beetle"
			].includes(e) && /* @__PURE__ */ y("path", {
				d: e === "beetle" ? "M122 76 100 32l24-29 12 47 16 10m15 19 27-41-8-24-17 33" : "M112 84Q59 104 64 55l16-30 4 41 32-5m51 23q55 8 51-30l-18-27-3 39-30-3",
				fill: "#b5b49b"
			}),
			/* @__PURE__ */ y("path", {
				d: n ? "M109 77q24-31 51-5l25 44-11 44-38 29-30-21-14-43z" : r ? "M101 88q30-29 66-7l31 31-5 41-43 38-46-19-19-44z" : e === "hippo" ? "M98 88q41-24 77 6l22 60-16 29-66 6-29-36z" : "M103 86q36-31 71-2l18 42-15 42-36 22-36-25-18-43z",
				fill: a
			}),
			e === "lion" && /* @__PURE__ */ y("path", {
				d: "m101 80-24 24-10 42 16 37 30 16-19-47 18-31 26-16 37 8-18-30z",
				fill: "#aa603d"
			}),
			n ? /* @__PURE__ */ b(v, { children: [
				/* @__PURE__ */ y("path", {
					d: e === "toucan" ? "M112 108Q40 54 23 103l61 21 32 3z" : "M113 112q-43-21-54 4l42 18 16-4z",
					fill: e === "toucan" ? "#d18f43" : "#d7c27e"
				}),
				/* @__PURE__ */ y("path", {
					d: "m108 116-42 0",
					fill: "none"
				}),
				e === "rooster" && /* @__PURE__ */ y("path", {
					d: "M115 78q-19-26 2-34 11-21 23-1 23-4 20 22",
					fill: "#b94d44"
				})
			] }) : e === "elephant" ? /* @__PURE__ */ y("path", {
				d: "M122 132q-10 30-24 46-22 23-22-1l-12 1q-4 41 31 28 39-19 44-68",
				fill: a
			}) : /* @__PURE__ */ y("path", {
				d: r ? "M119 120 59 127q-9 37 33 40l53-15" : "M113 126q-36-7-39 14-4 27 37 34l34-16 5-24z",
				fill: i ? "#a29a7e" : "#e5d7b6"
			}),
			/* @__PURE__ */ y("path", {
				d: "m121 107 14-3m20 3 12 5",
				fill: "none",
				strokeWidth: "4"
			}),
			!n && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("path", {
				d: "m88 137 15 1-7 11z",
				fill: "#363a34"
			}), /* @__PURE__ */ y("path", {
				d: "m98 151 9 8 15-4m-24-9-27 2m28 7-26 6",
				fill: "none",
				strokeWidth: "1.8"
			})] }),
			[
				"tiger",
				"raccoon",
				"panda",
				"husky",
				"meerkat",
				"baboon"
			].includes(e) && /* @__PURE__ */ y("path", {
				d: e === "tiger" ? "m110 91 13 13m28-20-8 14m28 21-13 4m24 18-17 3m-46 17 7 14" : "m111 98 23-3 4 18-26 7zm37-1 25 6-3 18-23-7z",
				fill: i ? "#d6c9a6" : "#4a4c43",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ y("path", {
				d: "m74 245 26-7 18 19-9 24-30-7m104-36-21 15-9 22 22 8 29-18",
				fill: a
			}),
			/* @__PURE__ */ y(ot, {
				kind: n ? "device" : r ? "book" : i ? "fists" : "glass",
				color: t
			}),
			/* @__PURE__ */ y("path", {
				d: "m183 211 10 9-10 9-10-9z",
				fill: "#d6bb62"
			})
		]
	});
}
function lt({ id: e }) {
	let [t, n, r] = nt[e], i = {
		mint: "#73a598",
		gold: "#d9a94e",
		blue: "#6c98ac",
		red: "#c16b56",
		violet: "#9581a2"
	}[n];
	return /* @__PURE__ */ b("g", {
		...rt,
		children: [
			/* @__PURE__ */ y("path", {
				d: t === "saucer" ? "M84 286v-57q-35-15-27-45l48-29 66 2 49 38q8 20-26 34v57" : "M67 286q-6-65 27-83l29-21h38l33 21q33 22 26 83",
				fill: i
			}),
			/* @__PURE__ */ y("path", {
				d: "M100 214h80l12 64H88z",
				fill: "#e8e8cb"
			}),
			/* @__PURE__ */ y("path", {
				d: "M111 231h58v30h-58z",
				fill: "#253e43"
			}),
			/* @__PURE__ */ y("path", {
				d: "M119 242h10m8 0h10m8 0h7",
				stroke: "#edd47d",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ y("path", {
				d: "M127 187v26h32v-26m-32 17h32",
				fill: "#8caaa0"
			}),
			t === "monitor" ? /* @__PURE__ */ b(v, { children: [
				/* @__PURE__ */ y("path", {
					d: "M89 60h90l25 21-8 88-25 20H96l-15-25V81z",
					fill: "#e4e9d1"
				}),
				/* @__PURE__ */ y("path", {
					d: "m97 81 77-1 6 63-76 7z",
					fill: "#273c43"
				}),
				/* @__PURE__ */ y("path", {
					d: "M118 103v25m32-25v25",
					stroke: "#d4cb62",
					strokeWidth: "9"
				})
			] }) : t === "cylinder" ? /* @__PURE__ */ b(v, { children: [
				/* @__PURE__ */ y("path", {
					d: "M114 44h48l16 107-18 38h-44l-20-38z",
					fill: i
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "140",
					cy: "92",
					rx: "19",
					ry: "28",
					fill: "#29434a"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "140",
					cy: "90",
					rx: "10",
					ry: "17",
					fill: "#edcb72"
				}),
				/* @__PURE__ */ y("path", {
					d: "m110 159 59-1",
					stroke: "#f3edcf",
					strokeWidth: "8"
				})
			] }) : t === "wedge" ? /* @__PURE__ */ b(v, { children: [
				/* @__PURE__ */ y("path", {
					d: "m103 57 53-17 40 32-15 102-54 15-34-27z",
					fill: "#e7e6c9"
				}),
				/* @__PURE__ */ y("path", {
					d: "m110 84 53-14 11 48-48 17z",
					fill: "#263d43"
				}),
				/* @__PURE__ */ y("path", {
					d: "m122 96 13 25m11-31 10 23",
					stroke: "#e9bd6c",
					strokeWidth: "7"
				})
			] }) : /* @__PURE__ */ b(v, { children: [
				/* @__PURE__ */ y("path", {
					d: t === "oval" || t === "tentacle" ? "M92 98q-3-59 49-59t53 59v36q1 45-52 53-49-7-50-50z" : "M85 111q-5-61 57-61 63 0 62 59-1 64-62 75-56-11-57-73z",
					fill: i
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "140",
					cy: "116",
					rx: t === "diver" ? 37 : 29,
					ry: t === "capsule" ? 46 : 35,
					fill: "#273d43"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "128",
					cy: "112",
					rx: "5",
					ry: "10",
					fill: "#efcc79"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "152",
					cy: "112",
					rx: "5",
					ry: "10",
					fill: "#efcc79"
				}),
				/* @__PURE__ */ y("path", {
					d: "M123 143q16 9 34-1",
					fill: "none",
					stroke: "#94b6a9"
				}),
				t === "diver" && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("path", {
					d: "M111 57v21m59-21v21M93 109h18m66 0h20",
					stroke: "#e9e3ba",
					strokeWidth: "7"
				}), /* @__PURE__ */ y("circle", {
					cx: "141",
					cy: "116",
					r: "41",
					fill: "none",
					stroke: "#e9dfb8",
					strokeWidth: "5"
				})] })
			] }),
			/* @__PURE__ */ y("path", {
				d: "M140 48V25l12-9",
				fill: "none"
			}),
			/* @__PURE__ */ y("circle", {
				cx: "153",
				cy: "15",
				r: "7",
				fill: "#ce8654"
			}),
			/* @__PURE__ */ y("path", {
				d: "M97 210q-21-4-32 17l-12 30 17 17 25-31m87-30q22-5 32 15l15 30-14 15-27-30",
				fill: i
			}),
			/* @__PURE__ */ y("circle", {
				cx: "79",
				cy: "229",
				r: "14",
				fill: "#c0cbb3"
			}),
			/* @__PURE__ */ y("circle", {
				cx: "206",
				cy: "230",
				r: "14",
				fill: "#c0cbb3"
			}),
			t === "tentacle" && /* @__PURE__ */ y("path", {
				d: "M96 130q-48-22-48 18 0 32 26 41m104-52q52-35 53 8-1 29-18 44",
				fill: "none",
				stroke: "#526e64",
				strokeWidth: "12"
			}),
			/* @__PURE__ */ y(ot, {
				kind: r,
				color: i
			}),
			/* @__PURE__ */ y("path", {
				d: "m186 249 23 13 12-11",
				fill: "none",
				stroke: "#f2d783",
				strokeWidth: "5"
			})
		]
	});
}
function ut({ id: e }) {
	let t = O[e];
	if (ze[e]) return /* @__PURE__ */ y("span", {
		className: "zen-approved-portrait",
		dangerouslySetInnerHTML: { __html: ze[e] }
	});
	let n = [
		"#79709b",
		"#daa446",
		"#43849b",
		"#b86b58",
		"#6b9881"
	][t.planet];
	return /* @__PURE__ */ b("svg", {
		className: "zen-portrait",
		viewBox: "38 35 204 245",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ y("path", {
				d: "M28 286V72l38-34h154l31 34v214z",
				fill: [
					"#e9e0ef",
					"#fae7c5",
					"#d9edf3",
					"#f5ded6",
					"#dcebe0"
				][t.planet]
			}),
			/* @__PURE__ */ y("path", {
				d: "M55 286V83l21-19h129l20 20v202",
				fill: "none",
				stroke: "#fff9df",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ y("ellipse", {
				cx: "140",
				cy: "128",
				rx: "91",
				ry: "89",
				fill: "none",
				stroke: n,
				strokeOpacity: ".2",
				strokeWidth: "2"
			}),
			t.faction === "human" ? /* @__PURE__ */ y(st, {
				id: e,
				color: n
			}) : t.faction === "robot" ? /* @__PURE__ */ y(lt, { id: e }) : /* @__PURE__ */ y(ct, {
				species: tt[e],
				color: n
			})
		]
	});
}
//#endregion
//#region src/games/zenith/visuals.tsx
var dt = [
	"#8970ab",
	"#df9036",
	"#418eb3",
	"#c85a54",
	"#448b78"
], ft = [
	"#e9e0ef",
	"#fae7c5",
	"#d9edf3",
	"#f5ded6",
	"#dcebe0"
], pt = (e) => ({
	"--planet": dt[e],
	"--planet-light": ft[e]
});
function mt({ markup: e, className: t = "" }) {
	return /* @__PURE__ */ y("span", {
		className: `zen-svg ${t}`,
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: e }
	});
}
function ht() {
	return /* @__PURE__ */ y("div", {
		className: "zen-art-defs",
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: He + Ke }
	});
}
function gt({ kind: e }) {
	return /* @__PURE__ */ y(mt, {
		markup: Ue[e],
		className: `zen-art-${e}`
	});
}
function _t({ kind: e }) {
	return /* @__PURE__ */ y(mt, { markup: We[e] });
}
function vt({ gold: e = !1 }) {
	return /* @__PURE__ */ y(mt, {
		markup: e ? Ge.gold : Ge.silver,
		className: "zen-leader-art"
	});
}
function Z({ kind: e, className: t = "" }) {
	return /* @__PURE__ */ y("svg", {
		className: `zen-icon ${t}`,
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: /* @__PURE__ */ y("use", { href: `#${e}` })
	});
}
function yt({ faction: e }) {
	return /* @__PURE__ */ y("svg", {
		className: "zen-icon",
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		children: /* @__PURE__ */ y("use", { href: `#zen-official-${e}` })
	});
}
function Q({ planet: e, size: t = 36 }) {
	return /* @__PURE__ */ y("span", {
		className: "zen-planet zen-planet-art",
		style: {
			width: t,
			height: t * 1.04
		},
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: Be[e] }
	});
}
function bt({ effects: e, planet: t = 0, id: n }) {
	let r = f(), i = e.map((e) => G(e, r)).join("；"), a = $e(e), o = Math.max(1e3, a.width + 30);
	return n && Ve[n] ? /* @__PURE__ */ y("span", {
		className: "zen-ability-image",
		role: "img",
		"aria-label": i,
		dangerouslySetInnerHTML: { __html: Ve[n] }
	}) : /* @__PURE__ */ b("svg", {
		className: "zen-ability-band",
		viewBox: `0 0 ${o} 450`,
		role: "img",
		"aria-label": i,
		"data-effect-count": e.length,
		children: [
			/* @__PURE__ */ y("path", {
				d: `M2 30 25 7h${o - 50}l23 23v394l-23 23H25L2 424z`,
				fill: dt[t]
			}),
			/* @__PURE__ */ y("path", {
				d: `M14 40 35 20H${o - 30}`,
				fill: "none",
				stroke: "#f9edc6",
				strokeOpacity: ".5",
				strokeWidth: "7"
			}),
			/* @__PURE__ */ y("g", {
				transform: `translate(${(o - a.width) / 2} 12)`,
				dangerouslySetInnerHTML: { __html: a.body }
			})
		]
	});
}
function xt({ id: e }) {
	return /* @__PURE__ */ y(bt, {
		id: e,
		effects: O[e].effects,
		planet: O[e].planet
	});
}
function St({ effects: e }) {
	let t = f(), n = $e(e);
	return /* @__PURE__ */ y("svg", {
		className: "zen-effect-icons",
		viewBox: `0 0 ${n.width} 450`,
		role: "img",
		"aria-label": e.map((e) => G(e, t)).join("；"),
		dangerouslySetInnerHTML: { __html: n.body }
	});
}
function Ct({ id: e, selected: t = !1, compact: n = !1, onClick: r, anchorName: i }) {
	let a = f(), o = O[e], { ref: s, hidden: c } = u(i ?? null), l = $e(o.effects), d = Ve[e] ? 1 : Math.max(1, (l.width + 30) / 1e3), p = {
		...pt(o.planet),
		"--zen-card-factor": d,
		visibility: c ? "hidden" : void 0
	}, m = /* @__PURE__ */ b(v, { children: [
		/* @__PURE__ */ b("span", {
			className: "zen-card-heading",
			children: [
				/* @__PURE__ */ y("b", {
					className: "zen-cost",
					children: o.cost
				}),
				/* @__PURE__ */ y("strong", { children: Fe(e, a) }),
				/* @__PURE__ */ y("span", {
					className: "zen-faction",
					children: /* @__PURE__ */ y(yt, { faction: o.faction })
				})
			]
		}),
		/* @__PURE__ */ y("span", {
			className: "zen-card-picture",
			children: /* @__PURE__ */ y(ut, { id: e })
		}),
		/* @__PURE__ */ y("span", {
			className: "zen-card-effects",
			children: /* @__PURE__ */ y(xt, { id: e })
		}),
		t && /* @__PURE__ */ y("span", {
			className: "zen-selected-mark",
			children: "✓"
		})
	] }), h = `zen-agent ${n ? "zen-mini" : "zen-hand-card"}${t ? " is-selected" : ""}`, g = `${Fe(e, a)} · ${o.cost} ${a("games.zenith.credits")} · ${a(W[o.faction])} · ${a(U[o.planet])}`;
	return r ? /* @__PURE__ */ y("button", {
		ref: s,
		type: "button",
		className: h,
		style: p,
		"data-card": e,
		"aria-label": g,
		"aria-pressed": t,
		"aria-haspopup": "dialog",
		onClick: (e) => r(e.currentTarget),
		children: m
	}) : /* @__PURE__ */ y("div", {
		ref: s,
		className: h,
		style: p,
		"data-card": e,
		"aria-label": g,
		children: m
	});
}
//#endregion
//#region src/games/zenith/card-popover.tsx
function wt({ inspection: e, onClose: t }) {
	let n = f(), r = s(null);
	if (o(() => {
		if (!e || !r.current) return;
		let { anchor: n } = e, i = r.current, a = (e = !1) => {
			t(), e && n.focus({ preventScroll: !0 });
		}, o = () => {
			if (!n.isConnected) return a();
			let e = n.closest(".zen-root"), t = e.getBoundingClientRect(), r = n.closest(".zen-hand, .zen-main, .bottom-sheet__content")?.getBoundingClientRect() ?? t, o = n.getBoundingClientRect();
			if (o.right <= Math.max(r.left, t.left) || o.left >= Math.min(r.right, t.right) || o.bottom <= Math.max(r.top, t.top) || o.top >= Math.min(r.bottom, t.bottom)) return a();
			let s = Math.max(t.top + 6, e.querySelector(".zen-top").getBoundingClientRect().bottom + 6), c = e.querySelector(".zen-actions").getBoundingClientRect().top - 8, l = Math.min(400, t.width - 24), u = Math.max(r.left + 8, Math.min(r.right - 8, o.left + o.width / 2)), d = Math.max(t.left + 12, Math.min(t.right - l - 12, u - l / 2));
			i.style.width = l + "px", i.style.maxHeight = "";
			let f = i.getBoundingClientRect().height, p = o.top - s - 12, m = c - o.bottom - 12, h = !n.closest(".zen-hand") && p < f && m > p;
			i.classList.toggle("is-below", h), i.style.maxHeight = Math.max(96, h ? m : Math.min(p, c - s)) + "px", i.style.left = d + "px", i.style.top = (h ? o.bottom + 12 : Math.max(s, Math.min(c, o.top) - i.getBoundingClientRect().height - 12)) + "px", i.style.setProperty("--anchor-x", Math.max(16, Math.min(l - 20, u - d)) + "px");
		}, s = (e) => {
			!i.contains(e.target) && !n.contains(e.target) && a();
		}, c = (e) => {
			e.key === "Escape" && (e.stopPropagation(), a(!0));
		};
		n.setAttribute("aria-expanded", "true"), o();
		let l = new ResizeObserver(o);
		return l.observe(i), window.addEventListener("resize", o), document.addEventListener("scroll", o, !0), document.addEventListener("click", s), document.addEventListener("keydown", c), () => {
			n.setAttribute("aria-expanded", "false"), l.disconnect(), window.removeEventListener("resize", o), document.removeEventListener("scroll", o, !0), document.removeEventListener("click", s), document.removeEventListener("keydown", c);
		};
	}, [e, t]), !e) return null;
	let i = O[e.id];
	return /* @__PURE__ */ b("div", {
		ref: r,
		className: "zen-card-popover",
		role: "dialog",
		"aria-label": Fe(i.id, n),
		style: pt(i.planet),
		children: [/* @__PURE__ */ b("header", { children: [/* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("h2", { children: Fe(i.id, n) }), /* @__PURE__ */ b("div", {
			className: "zen-card-meta",
			children: [
				/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(Z, { kind: "credit" }), i.cost] }),
				/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(yt, { faction: i.faction }), n(W[i.faction])] }),
				/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(Q, { planet: i.planet }), n(U[i.planet])] })
			]
		})] }), /* @__PURE__ */ y("button", {
			type: "button",
			onClick: () => {
				t(), e.anchor.focus({ preventScroll: !0 });
			},
			"aria-label": n("games.zenith.close"),
			children: /* @__PURE__ */ y(m, { size: 22 })
		})] }), /* @__PURE__ */ b("div", {
			className: "zen-card-popover-scroll",
			children: [/* @__PURE__ */ y("div", {
				className: "zen-enlarged-abilities",
				children: /* @__PURE__ */ y(xt, { id: i.id })
			}), /* @__PURE__ */ y("ol", {
				className: "zen-popover-effects",
				children: i.effects.map((e, t) => /* @__PURE__ */ y("li", { children: G(e, n) }, t))
			})]
		})]
	});
}
//#endregion
//#region src/games/zenith/view-player.tsx
function $({ name: e }) {
	let { ref: t } = u(e);
	return /* @__PURE__ */ y("span", {
		ref: t,
		className: "zen-fx-probe"
	});
}
function Tt({ public: e, private: t, members: o, myRid: u, send: p }) {
	_();
	let m = f(), x = e, S = t, C = x.players.find((e) => e.rid === u), w = C?.team ?? 0, T = 1 - w, E = x.teams[w], D = x.teams[T], [te, re] = c(null), [A, ie] = c([]), [j, ae] = c(null), [oe, se] = c(!1), [ce, le] = c(null), [ue, P] = c(null), F = d(), de = s(null), fe = s(null);
	a(() => (F?.registerProbe(`play-origin-${u}`, () => fe.current), () => F?.registerProbe(`play-origin-${u}`, null)), [F, u]);
	let pe = i(() => P(null), []), I = S?.hand ?? [], L = te && I.includes(te) ? O[te] : null, R = S?.choices ?? [], z = R.length > 0 && x.phase !== "done", B = (e) => o.find((t) => t.rid === e)?.name ?? e, V = (e) => x.players.filter((t) => t.team === e).map((e) => B(e.rid)).join(" · "), me = (e, t) => P({
		id: e,
		anchor: t
	}), H = (e) => {
		P(null), ae(e), se(!0);
	}, he = x.pending?.effect, ge = x.pending?.follow, _e = he && ge ? {
		kind: "condition",
		mandatory: !x.pending?.optional,
		condition: {
			kind: "pay",
			effect: he
		},
		effect: ge
	} : he, ve = (e) => {
		z && p({
			type: "choose",
			id: e.id
		}), se(!1), P(null);
	}, ye = x.phase === "turn" && x.turn === u, be = x.phase === "mulligan" && !C?.mulligan, xe = x.phase === "order" && C?.team === x.activeTeam, Se = x.phase === "done" ? m("games.zenith.finished") : x.phase === "teams" ? m("games.zenith.teams") : x.phase === "mulligan" ? m(C?.mulligan ? "games.zenith.mulliganDone" : "games.zenith.mulligan") : x.phase === "order" ? m(xe ? "games.zenith.order" : "games.zenith.waitOrder") : x.phase === "resolve" ? m("games.zenith.resolving") : x.phase === "choice" ? z ? m("games.zenith.yourChoice") : m("games.zenith.waitChoice", { name: B(x.pending.who) }) : ye ? m(I.length ? "games.zenith.yourTurn" : "games.zenith.emptyHand") : m("games.zenith.waiting", { name: B(x.turn) }), Ce = L ? Math.max(0, L.cost - E.columns[L.planet].length) : 0, we = L ? E.tech[N.indexOf(L.faction)] + 1 : 0, Te = (e) => ye && !!L && !!S?.moves.some((t) => t.type === "play" && t.card === L.id && t.use === e), Ee = (e) => {
		if (L && Te(e)) {
			let t = de.current?.getBoundingClientRect();
			t && (fe.current = {
				x: t.x,
				y: t.y,
				w: t.width,
				h: t.height
			}), p({
				type: "play",
				card: L.id,
				use: e
			}), re(null), P(null);
		}
	}, De = (e, t) => {
		de.current = t, re(e), me(e, t), be && ie((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
	}, Oe = j?.kind === "card" ? Fe(j.id, m) : j?.kind === "column" ? m("games.zenith.column", { planet: m(U[j.planet]) }) : j?.kind === "tech" ? m("games.zenith.techTrack", {
		faction: m(W[N[j.index]]),
		board: x.boards[j.index]
	}) : j?.kind === "history" ? m("games.zenith.history") : j?.kind === "discard" ? m("games.zenith.discard") : j?.kind === "bonus" ? m("games.zenith.bonus") : m("games.zenith.choose"), ke = (e) => /* @__PURE__ */ b("div", {
		className: `zen-identity${e === w ? " zen-own" : ""}`,
		children: [
			/* @__PURE__ */ y($, { name: `seat-${e}` }),
			/* @__PURE__ */ y("span", {
				className: "zen-player-mark",
				style: {
					display: "flex",
					width: "auto",
					height: 28,
					minWidth: 28,
					flex: "none",
					gap: 2,
					padding: 2
				},
				children: x.players.filter((t) => t.team === e).map((e) => /* @__PURE__ */ y("span", {
					style: {
						display: "inline-flex",
						width: 24,
						height: 24,
						flex: "none",
						borderRadius: "50%",
						backgroundColor: n[(o.find((t) => t.rid === e.rid)?.colorIndex ?? 0) % n.length].hex
					},
					children: /* @__PURE__ */ y("img", {
						src: r[(o.find((t) => t.rid === e.rid)?.avatar ?? 0) % r.length],
						alt: "",
						draggable: !1,
						style: {
							width: "1.75em",
							height: "1.75em",
							maxWidth: "100%",
							maxHeight: "100%",
							display: "block",
							objectFit: "contain",
							pointerEvents: "none",
							borderRadius: "inherit"
						}
					})
				}, e.rid))
			}),
			/* @__PURE__ */ b("div", {
				className: "zen-player-names",
				children: [/* @__PURE__ */ y("strong", {
					title: V(e),
					children: V(e)
				}), /* @__PURE__ */ y("small", { children: x.players.filter((t) => t.team === e).map((e) => `${B(e.rid)} · ${m("games.zenith.handCount", { n: e.handCount })}`).join(" / ") })]
			}),
			x.leader?.team === e && /* @__PURE__ */ y("span", {
				className: "zen-identity-leader",
				role: "img",
				"aria-label": m(x.leader.gold ? "games.zenith.gold" : "games.zenith.silver"),
				title: m(x.leader.gold ? "games.zenith.gold" : "games.zenith.silver"),
				children: /* @__PURE__ */ y(vt, { gold: x.leader.gold })
			}),
			/* @__PURE__ */ b("div", {
				className: "zen-resources",
				children: [/* @__PURE__ */ b("span", {
					title: m("games.zenith.credits"),
					children: [/* @__PURE__ */ y(Z, { kind: "credit" }), /* @__PURE__ */ y("b", { children: x.teams[e].credits })]
				}), /* @__PURE__ */ b("span", {
					title: m("games.zenith.zenithium"),
					children: [/* @__PURE__ */ y(Z, { kind: "crystal" }), /* @__PURE__ */ y("b", { children: x.teams[e].zenithium })]
				})]
			})
		]
	}), Ae = (e) => /* @__PURE__ */ y("div", {
		className: "zen-collection",
		"aria-label": m("games.zenith.discs"),
		children: M.map((t) => /* @__PURE__ */ b("div", {
			className: "zen-count",
			style: pt(t),
			children: [
				/* @__PURE__ */ y($, { name: `collection-${e}-${t}` }),
				/* @__PURE__ */ y(Q, {
					planet: t,
					size: 28
				}),
				/* @__PURE__ */ y("b", { children: x.teams[e].discs[t] })
			]
		}, t))
	}), je = (e) => /* @__PURE__ */ y("div", {
		className: `zen-columns${e === w ? " zen-own-columns" : ""}`,
		children: M.map((t) => {
			let n = x.teams[e].columns[t], r = n.at(-1), i = r && R.find((e) => e.label === "card" && e.planet === t && e.card === r);
			return /* @__PURE__ */ b("div", {
				className: `zen-column${e === w && L?.planet === t && Te("recruit") ? " is-legal" : ""}${i ? " is-target" : ""}`,
				style: pt(t),
				children: [
					/* @__PURE__ */ y($, { name: `column-${e}-${t}` }),
					n.length > 1 && /* @__PURE__ */ y("span", { className: "zen-stack-line" }),
					r ? /* @__PURE__ */ y(Ct, {
						id: r,
						compact: !0,
						anchorName: `public-${e}-${t}-${r}`,
						onClick: (e) => me(r, e)
					}) : /* @__PURE__ */ y("div", {
						className: "zen-empty-berth",
						"aria-label": m("games.zenith.emptyColumn"),
						children: /* @__PURE__ */ y(Q, { planet: t })
					}),
					r && /* @__PURE__ */ b("button", {
						type: "button",
						className: "zen-stack-count",
						onClick: () => H({
							kind: "column",
							team: e,
							planet: t
						}),
						"aria-label": `${V(e)} · ${m("games.zenith.column", { planet: m(U[t]) })} · ${m("games.zenith.columnCount", { n: n.length })}`,
						children: [/* @__PURE__ */ y(g, { size: 13 }), n.length]
					}),
					i && /* @__PURE__ */ y("button", {
						type: "button",
						className: "zen-column-target",
						onClick: () => ve(i),
						children: m("games.zenith.choose")
					})
				]
			}, t);
		})
	}), Me = /* @__PURE__ */ y(v, { children: [
		"recruit",
		"develop",
		"leader"
	].map((e) => /* @__PURE__ */ b("button", {
		type: "button",
		className: e === "recruit" ? "zen-primary" : "zen-secondary",
		disabled: !Te(e),
		onClick: () => Ee(e),
		children: [
			/* @__PURE__ */ y(_t, { kind: e }),
			/* @__PURE__ */ y("span", { children: m(e === "recruit" ? "games.zenith.recruit" : e === "develop" ? "games.zenith.develop" : "games.zenith.leaderAction") }),
			/* @__PURE__ */ y("span", { children: e === "leader" ? /* @__PURE__ */ b(v, { children: [
				L && /* @__PURE__ */ y(yt, { faction: L.faction }),
				/* @__PURE__ */ y("b", { children: L ? L.faction === "human" ? "+3" : L.faction === "robot" ? "+1" : "+2" : "—" }),
				L && /* @__PURE__ */ y(Z, { kind: L.faction === "human" ? "credit" : L.faction === "robot" ? "crystal" : "agent" })
			] }) : /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(Z, { kind: e === "recruit" ? "credit" : "crystal" }), /* @__PURE__ */ y("b", { children: L ? e === "recruit" ? Ce : we : "—" })] }) })
		]
	}, e)) }), Ne = be ? /* @__PURE__ */ y("button", {
		type: "button",
		className: "zen-primary zen-wide-action",
		onClick: () => {
			P(null), p({
				type: "mulligan",
				cards: A.filter((e) => I.includes(e))
			});
		},
		children: m(A.length ? "games.zenith.replace" : "games.zenith.keep", { n: A.length })
	}) : xe ? x.players.filter((e) => e.team === x.activeTeam).map((e) => /* @__PURE__ */ y("button", {
		type: "button",
		className: "zen-primary",
		onClick: () => p({
			type: "order",
			rid: e.rid
		}),
		children: m("games.zenith.goFirst", { name: B(e.rid) })
	}, e.rid)) : z ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("p", {
		className: "zen-choice-prompt",
		children: _e ? G(_e, m) : Se
	}), /* @__PURE__ */ y("button", {
		type: "button",
		className: "zen-primary",
		onClick: () => H({ kind: "choices" }),
		children: m("games.zenith.choose")
	})] }) : ye && !I.length ? /* @__PURE__ */ y("button", {
		type: "button",
		className: "zen-primary zen-wide-action",
		onClick: () => p({ type: "pass" }),
		children: m("games.zenith.pass")
	}) : Me;
	return /* @__PURE__ */ b("div", {
		className: `zen-root zen-stage${x.phase === "done" ? " is-done" : ""}${!ye && !be && !xe && !z ? " is-waiting" : ""}${z ? " is-choice" : ""}`,
		children: [
			/* @__PURE__ */ y(ht, {}),
			/* @__PURE__ */ y(gt, { kind: "stars" }),
			/* @__PURE__ */ y(ee, {
				adaptive: !0,
				className: "zen-screen",
				scroll: !1,
				banner: /* @__PURE__ */ b("header", {
					className: "zen-top",
					children: [
						/* @__PURE__ */ b("div", {
							className: "zen-wordmark",
							children: ["ZENITH", /* @__PURE__ */ y("small", { children: m("games.zenith.name") })]
						}),
						/* @__PURE__ */ y("div", {
							className: "zen-turn",
							children: m("games.zenith.turn", { n: x.turnNumber })
						}),
						/* @__PURE__ */ b("div", {
							className: "zen-phase",
							role: "status",
							children: [/* @__PURE__ */ y("i", {}), /* @__PURE__ */ y("strong", { children: Se })]
						})
					]
				}),
				actionsHeight: "zen-actions-height",
				actions: /* @__PURE__ */ b("footer", {
					className: "zen-actions",
					children: [/* @__PURE__ */ b("div", {
						className: "zen-hand-header",
						children: [/* @__PURE__ */ b("strong", { children: [
							m("games.zenith.hand"),
							" ",
							/* @__PURE__ */ y("span", { children: I.length })
						] }), x.mode === "team" && C && /* @__PURE__ */ y("span", {
							className: "zen-hand-role",
							children: m(C.role === 0 ? "games.zenith.techRole" : "games.zenith.diplomacyRole")
						})]
					}), /* @__PURE__ */ b("div", {
						className: "zen-hand-layout",
						children: [/* @__PURE__ */ y("div", {
							className: "zen-hand",
							children: I.map((e, t) => /* @__PURE__ */ y(Ct, {
								id: e,
								anchorName: `hand-${u}-${t}`,
								selected: be ? A.includes(e) : L?.id === e,
								onClick: (t) => De(e, t)
							}, e))
						}), /* @__PURE__ */ y("div", {
							className: "zen-action-buttons",
							children: Ne
						})]
					})]
				}),
				children: /* @__PURE__ */ b("main", {
					className: "zen-main",
					children: [/* @__PURE__ */ y("div", {
						className: "zen-board",
						children: /* @__PURE__ */ b("div", {
							className: "zen-board-content",
							children: [
								/* @__PURE__ */ b("div", {
									className: "zen-command-deck",
									children: [
										/* @__PURE__ */ y(gt, { kind: "deck" }),
										ke(T),
										Ae(T),
										je(T)
									]
								}),
								/* @__PURE__ */ b("div", {
									className: "zen-planet-board",
									children: [
										/* @__PURE__ */ y(gt, { kind: "board" }),
										/* @__PURE__ */ b("div", {
											className: "zen-board-ruler",
											children: [/* @__PURE__ */ y("span", { children: "ZENITH" }), /* @__PURE__ */ y("span", { children: "SOLAR SENATE" })]
										}),
										/* @__PURE__ */ y("div", {
											className: "zen-lanes",
											children: M.map((e) => {
												let t = x.planets[e], n = t == null ? 0 : t * (w === 0 ? 1 : -1), r = R.filter((t) => t.label === "planet" && t.planet === e), i = x.planetBonuses[e];
												return /* @__PURE__ */ b("div", {
													className: "zen-lane",
													style: pt(e),
													children: [
														/* @__PURE__ */ y("div", {
															className: "zen-control",
															children: /* @__PURE__ */ y("b", { children: m(U[e]) })
														}),
														/* @__PURE__ */ b("div", {
															className: "zen-track",
															children: [
																/* @__PURE__ */ y($, { name: `planet-${e}` }),
																/* @__PURE__ */ y("div", { className: "zen-track-line" }),
																[
																	-3,
																	-2,
																	-1,
																	0,
																	1,
																	2,
																	3
																].map((e) => /* @__PURE__ */ y("span", {
																	className: `zen-track-stop${e === 0 ? " is-center" : ""}`,
																	style: { "--pos": e }
																}, e)),
																t == null ? /* @__PURE__ */ y("span", {
																	className: "zen-captured",
																	children: "✓"
																}) : /* @__PURE__ */ y("button", {
																	type: "button",
																	className: `zen-disc${r.length ? " is-target" : ""}`,
																	style: { "--pos": n },
																	"aria-label": m("games.zenith.optionPlanet", {
																		planet: m(U[e]),
																		n: r[0]?.amount ?? 1
																	}),
																	disabled: !r.length,
																	onClick: () => r.length === 1 ? ve(r[0]) : H({ kind: "choices" }),
																	children: /* @__PURE__ */ y(Q, { planet: e })
																})
															]
														}),
														/* @__PURE__ */ y("div", {
															className: "zen-control zen-lower-control",
															children: /* @__PURE__ */ y("b", { children: m(U[e]) })
														}),
														/* @__PURE__ */ y("button", {
															type: "button",
															className: "zen-board-bonus",
															disabled: !i,
															onClick: () => i && H({
																kind: "bonus",
																id: i
															}),
															"aria-label": i ? `${m("games.zenith.firstBonus")} · ${G(k[i], m)}` : m("games.zenith.bonus"),
															children: i ? /* @__PURE__ */ y(Z, { kind: "star" }) : /* @__PURE__ */ y("span", { children: "—" })
														})
													]
												}, e);
											})
										})
									]
								}),
								/* @__PURE__ */ b("div", {
									className: "zen-command-deck zen-own-deck",
									children: [
										/* @__PURE__ */ y(gt, { kind: "deck" }),
										je(w),
										Ae(w),
										ke(w)
									]
								})
							]
						})
					}), /* @__PURE__ */ b("aside", {
						className: "zen-sidebar",
						children: [
							/* @__PURE__ */ b("section", {
								className: "zen-science",
								children: [/* @__PURE__ */ b("div", {
									className: "zen-section-heading",
									children: [/* @__PURE__ */ y("span", { children: m("games.zenith.science") }), /* @__PURE__ */ y("span", { children: x.boards.join(" · ") })]
								}), /* @__PURE__ */ y("div", {
									className: "zen-tech-boards",
									children: N.map((e, t) => /* @__PURE__ */ b("div", {
										className: `zen-tech-piece${L?.faction === e && Te("develop") ? " is-legal" : ""}`,
										children: [
											/* @__PURE__ */ y(gt, { kind: "tech" }),
											/* @__PURE__ */ y("span", {
												className: "zen-tech-letter",
												children: x.boards[t]
											}),
											/* @__PURE__ */ y("button", {
												type: "button",
												className: "zen-tech-open",
												onClick: () => H({
													kind: "tech",
													index: t
												}),
												"aria-label": m("games.zenith.techTrack", {
													faction: m(W[e]),
													board: x.boards[t]
												})
											}),
											/* @__PURE__ */ y("div", {
												className: "zen-tech-rows",
												children: [
													5,
													4,
													3,
													2,
													1
												].map((e) => /* @__PURE__ */ b("div", {
													className: "zen-tech-row",
													children: [
														/* @__PURE__ */ y("span", {
															className: "zen-tech-cost",
															children: e
														}),
														/* @__PURE__ */ y("div", {
															className: "zen-tech-effect",
															children: /* @__PURE__ */ y(St, { effects: ne[x.boards[t]][e - 1] })
														}),
														e === E.tech[t] && /* @__PURE__ */ y("span", { className: "zen-tech-marker" }),
														e === D.tech[t] && /* @__PURE__ */ y("span", { className: "zen-tech-marker is-black" }),
														e === 2 && x.techBonuses[t] && /* @__PURE__ */ y("span", {
															className: "zen-tech-reward",
															children: /* @__PURE__ */ y(Z, { kind: "star" })
														})
													]
												}, e))
											}),
											/* @__PURE__ */ b("div", {
												className: "zen-tech-faction",
												children: [/* @__PURE__ */ y(yt, { faction: e }), /* @__PURE__ */ y("b", { children: m(W[e]) })]
											}),
											/* @__PURE__ */ b("div", {
												className: "zen-tech-zero",
												children: [E.tech[t] === 0 && /* @__PURE__ */ y("span", { className: "zen-tech-marker" }), D.tech[t] === 0 && /* @__PURE__ */ y("span", { className: "zen-tech-marker is-black" })]
											}),
											/* @__PURE__ */ y($, { name: `tech-${t}` })
										]
									}, e))
								})]
							}),
							/* @__PURE__ */ b("section", {
								className: `zen-diplomacy${Te("leader") ? " is-legal" : ""}`,
								children: [/* @__PURE__ */ b("div", {
									className: "zen-diplomacy-arch",
									children: [
										/* @__PURE__ */ y(gt, { kind: "senate" }),
										/* @__PURE__ */ y(vt, { gold: x.leader?.gold }),
										/* @__PURE__ */ y("span", {
											className: "zen-leader-owner",
											children: x.leader ? V(x.leader.team) : m("games.zenith.noLeader")
										}),
										/* @__PURE__ */ y($, { name: "leader" })
									]
								}), /* @__PURE__ */ b("div", {
									className: "zen-diplomacy-actions",
									children: [
										/* @__PURE__ */ b("span", { children: [
											/* @__PURE__ */ y(yt, { faction: "human" }),
											/* @__PURE__ */ y("b", { children: "+3" }),
											/* @__PURE__ */ y(Z, { kind: "credit" })
										] }),
										/* @__PURE__ */ b("span", { children: [
											/* @__PURE__ */ y(yt, { faction: "robot" }),
											/* @__PURE__ */ y("b", { children: "+1" }),
											/* @__PURE__ */ y(Z, { kind: "crystal" })
										] }),
										/* @__PURE__ */ b("span", { children: [
											/* @__PURE__ */ y(yt, { faction: "animod" }),
											/* @__PURE__ */ y("b", { children: "+2" }),
											/* @__PURE__ */ y(Z, { kind: "agent" })
										] })
									]
								})]
							}),
							/* @__PURE__ */ b("div", {
								className: "zen-decks",
								children: [
									/* @__PURE__ */ b("span", {
										className: "zen-deck-info",
										children: [
											/* @__PURE__ */ y("span", {
												className: "zen-deck-back",
												children: "Z"
											}),
											x.deckCount,
											/* @__PURE__ */ y($, { name: "deck" })
										]
									}),
									/* @__PURE__ */ b("button", {
										type: "button",
										onClick: () => H({ kind: "discard" }),
										children: [
											/* @__PURE__ */ y("span", {
												className: "zen-discard-face",
												children: /* @__PURE__ */ y(Z, { kind: "agent" })
											}),
											/* @__PURE__ */ b("span", { children: [
												m("games.zenith.discard"),
												" ",
												x.discard.length
											] }),
											/* @__PURE__ */ y($, { name: "discard" })
										]
									}),
									/* @__PURE__ */ b("button", {
										type: "button",
										className: "zen-history-button",
										onClick: () => H({ kind: "history" }),
										children: [/* @__PURE__ */ y(h, { size: 18 }), m("games.zenith.history")]
									})
								]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ b(l, {
				open: x.phase === "teams",
				label: m("games.zenith.teams"),
				title: m("games.zenith.teams"),
				tall: !0,
				children: [
					/* @__PURE__ */ y("p", { children: m("games.zenith.swapHint") }),
					[0, 1].map((e) => /* @__PURE__ */ b("div", {
						className: "zen-setup-team",
						children: [/* @__PURE__ */ y("h3", { children: m("games.zenith.teamNumber", { n: e + 1 }) }), x.players.filter((t) => t.team === e).sort((e, t) => e.role - t.role).map((e) => /* @__PURE__ */ b("button", {
							type: "button",
							className: `zen-quiet${ce === e.rid ? " is-selected" : ""}`,
							disabled: x.players[0].rid !== u,
							onClick: () => {
								if (!ce) le(e.rid);
								else {
									let t = [...x.players].sort((e, t) => e.team - t.team || e.role - t.role).map((e) => e.rid), n = t.indexOf(ce), r = t.indexOf(e.rid);
									[t[n], t[r]] = [t[r], t[n]], p({
										type: "teams",
										order: t
									}), le(null);
								}
							},
							children: [
								ce === e.rid ? "✓ " : "",
								B(e.rid),
								" · ",
								m(e.role === 0 ? "games.zenith.techRole" : "games.zenith.diplomacyRole")
							]
						}, e.rid))]
					}, e)),
					x.players[0].rid === u && /* @__PURE__ */ y("button", {
						type: "button",
						className: "zen-primary",
						onClick: () => p({ type: "start" }),
						children: m("games.zenith.start")
					})
				]
			}),
			/* @__PURE__ */ y(l, {
				open: oe,
				onClose: () => se(!1),
				label: Oe,
				title: Oe,
				tall: !0,
				children: /* @__PURE__ */ b("div", {
					className: "zen-panel",
					children: [
						j?.kind === "card" && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(Ct, { id: j.id }), /* @__PURE__ */ y("div", {
							className: "zen-effect-list",
							children: O[j.id].effects.map((e, t) => /* @__PURE__ */ b("p", { children: [/* @__PURE__ */ y("b", { children: t + 1 }), G(e, m)] }, t))
						})] }),
						j?.kind === "column" && /* @__PURE__ */ b(v, { children: [
							/* @__PURE__ */ y("h3", { children: V(j.team) }),
							[...x.teams[j.team].columns[j.planet]].reverse().map((e, t) => /* @__PURE__ */ b("div", {
								className: "zen-column-detail",
								children: [
									/* @__PURE__ */ y(Ct, {
										id: e,
										onClick: (t) => me(e, t)
									}),
									t === 0 && R.filter((t) => t.card === e && t.planet === j.planet).map((e) => /* @__PURE__ */ y("button", {
										type: "button",
										className: "zen-primary",
										onClick: () => ve(e),
										children: Ie(e, he, m)
									}, e.id)),
									/* @__PURE__ */ y("div", {
										className: "zen-effect-list",
										children: O[e].effects.map((e, t) => /* @__PURE__ */ y("p", { children: G(e, m) }, t))
									})
								]
							}, e)),
							!x.teams[j.team].columns[j.planet].length && /* @__PURE__ */ y("p", { children: m("games.zenith.emptyColumn") })
						] }),
						j?.kind === "tech" && /* @__PURE__ */ b(v, { children: [
							/* @__PURE__ */ y("p", { children: m("games.zenith.currentLevel", {
								own: E.tech[j.index],
								enemy: D.tech[j.index]
							}) }),
							ne[x.boards[j.index]].map((e, t) => /* @__PURE__ */ b("div", {
								className: "zen-tech-detail",
								children: [
									/* @__PURE__ */ b("strong", { children: [
										m("games.zenith.level", { n: t + 1 }),
										" · ",
										m("games.zenith.levelCost", { n: t + 1 })
									] }),
									/* @__PURE__ */ y(St, { effects: e }),
									e.map((e, t) => /* @__PURE__ */ y("p", { children: G(e, m) }, t))
								]
							}, t)),
							x.techBonuses[j.index] && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(bt, { effects: [k[x.techBonuses[j.index]]] }), /* @__PURE__ */ y("p", { children: G(k[x.techBonuses[j.index]], m) })] })
						] }),
						j?.kind === "bonus" && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(bt, { effects: [k[j.id]] }), /* @__PURE__ */ y("p", { children: G(k[j.id], m) })] }),
						j?.kind === "choices" && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("p", {
							className: "zen-choice-effect",
							children: _e ? G(_e, m) : m("games.zenith.yourChoice")
						}), /* @__PURE__ */ y("div", {
							className: "zen-choice-list",
							children: R.map((e) => /* @__PURE__ */ b("button", {
								type: "button",
								className: e.label === "skip" ? "zen-quiet" : "zen-primary",
								onClick: () => ve(e),
								children: [
									e.card && O[e.card] && /* @__PURE__ */ y(Q, {
										planet: O[e.card].planet,
										size: 25
									}),
									e.planet != null && e.label !== "card" && /* @__PURE__ */ y(Q, {
										planet: e.planet,
										size: 25
									}),
									Ie(e, he, m)
								]
							}, e.id))
						})] }),
						j?.kind === "discard" && /* @__PURE__ */ y("div", {
							className: "zen-card-grid",
							children: [...x.discard].reverse().map((e) => /* @__PURE__ */ y(Ct, {
								id: e,
								onClick: (t) => me(e, t)
							}, e))
						}),
						j?.kind === "history" && /* @__PURE__ */ y("ol", {
							className: "zen-history",
							children: x.history.map((e, t) => /* @__PURE__ */ y("li", { children: Re(e, B(e.who), m) }, t))
						})
					]
				})
			}),
			/* @__PURE__ */ y(wt, {
				inspection: ue,
				onClose: pe
			})
		]
	});
}
//#endregion
//#region src/games/zenith/bot.ts
var Et = {
	influence: 1,
	threat: 1,
	credits: 1,
	zenithium: 1,
	columns: 1,
	technology: 1,
	leader: 1,
	leaderRepeat: 3,
	hand: 1,
	beam: 4
}, Dt = (e) => ({
	...e,
	id: ""
}), Ot = (e) => e === 0 ? 1 : -1, kt = (e) => e.some((e) => e >= 3) || e.filter((e) => e > 0).length >= 4 || e.reduce((e, t) => e + t, 0) >= 5;
function At(e) {
	let t = 4294967296, n = t - t % e.length, r;
	do
		r = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (r >= n);
	return e[r % e.length];
}
function jt(e) {
	return JSON.stringify([
		e.teams,
		e.planets,
		e.leader,
		e.hand,
		e.planetBonuses,
		e.techBonuses
	]);
}
function Mt(e, t) {
	let n = t.effect && {
		...t.effect,
		...t.remaining == null ? {} : { n: t.remaining }
	};
	return jt(e) + JSON.stringify([
		t.source,
		n,
		t.follow
	]);
}
function Nt(e, t) {
	let n = { ...e };
	return n.kind === "influence" ? t.factor == null ? (n.n ??= t.amount, n.planet ??= t.planet) : n.points = t.factor : (n.kind === "credits" || n.kind === "zenithium") && (n.n ??= t.amount), n;
}
function Pt(e = {}) {
	let t = {
		...Et,
		...e
	};
	return (e, n) => {
		let r = e.public, i = e.private, a = r.players.find((e) => e.rid === n.rid);
		if (!i || !a) return null;
		if (r.phase === "teams") return r.players[0].rid === n.rid ? { action: { type: "start" } } : null;
		if (r.phase === "mulligan" && a.mulligan) return null;
		if (n.difficulty === "weak") return r.phase === "mulligan" ? { action: {
			type: "mulligan",
			cards: i.hand.filter((e) => O[e].cost > 5).slice(0, 3)
		} } : i.moves.length ? { action: At(i.moves) } : null;
		if (!i.moves.length) return null;
		let o = a.team, s = 1 - o, c = 0;
		for (let e = r.history.length - 1; e >= 0; e--) {
			let t = r.history[e].kind;
			if (t === "recruit" || t === "develop" || t === "influence" || t === "capture" || t === "mobilize" || t === "transfer" || t === "exile") break;
			t === "leader" && c++;
		}
		let l = /* @__PURE__ */ new Set([
			...i.hand,
			...r.discard,
			...r.teams.flatMap((e) => e.columns.flat())
		]), u = te.filter((e) => (r.secretAgents || !e.expansion) && !l.has(e.id)), d = M.map((e) => u.length ? u.filter((t) => t.planet === e).length / u.length : .2), f = [
			...r.planetBonuses,
			...r.techBonuses,
			...r.bonusDiscard
		].filter((e) => e != null), p = [...re];
		for (let e of f) {
			let t = p.indexOf(e);
			t >= 0 && p.splice(t, 1);
		}
		let m = r.bonusCount ? p : r.bonusDiscard, h = () => ({
			teams: structuredClone(r.teams),
			planets: [...r.planets],
			planetBonuses: [...r.planetBonuses],
			techBonuses: [...r.techBonuses],
			leader: r.leader && { ...r.leader },
			hand: [...i.hand],
			handCounts: r.players.map((e) => e.handCount),
			used: { 0: [] },
			serial: 0,
			tasks: [],
			winner: null,
			utility: 0,
			reliable: !0,
			plan: []
		});
		function g(e) {
			if (e.winner != null) return e.winner === o ? 1e6 : -1e6;
			let n = e.utility;
			for (let r = 0; r < 2; r++) {
				let i = e.teams[r], a = r === o ? 1 : -1, s = i.discs.reduce((e, t) => e + t, 0), c = i.discs.filter((e) => e > 0).length, l = s * 24 + c * 5 + Math.max(...i.discs) ** 2 * 2;
				l += t.credits * (Math.min(i.credits, 4) * .9 + Math.min(Math.max(0, i.credits - 4), 8) * .45 + Math.min(Math.max(0, i.credits - 12), 18) * .12), l += t.zenithium * (Math.min(i.zenithium, 4) * 2.2 + Math.min(Math.max(0, i.zenithium - 4), 10) * .7), l += t.columns * i.columns.reduce((e, t) => e + Math.min(t.length, 5) * 1.3 + Math.max(0, t.length - 5) * .35, 0), l += t.technology * (i.tech.reduce((e, t) => e + t * 2.5, 0) + Math.min(...i.tech) * 2), e.leader?.team === r && (l += t.leader * (e.leader.gold ? 7 : 4.5)), n += a * l;
			}
			for (let r of M) {
				let i = (e.planets[r] ?? 0) * Ot(o), a = Math.abs(i);
				n += t.influence * Math.sign(i) * (a * 2.1 + a * a * .45);
				for (let i of [o, s]) {
					let a = [...e.teams[i].discs];
					a[r]++;
					let s = (e.planets[r] ?? 0) * Ot(i);
					kt(a) && s > 0 && (n += (i === o ? 1 : -1) * t.threat * s * s * 3);
				}
			}
			let i = r.players.indexOf(a);
			n += t.hand * (e.handCounts[i] * .65 + e.hand.reduce((t, n) => t + _(e, n), 0) * .12);
			let c = r.players.findIndex((e) => e.team === o && e.rid !== a.rid);
			return c >= 0 && (n += t.hand * Math.min(e.handCounts[c], 6) * .65), n;
		}
		function _(e, t, n = a.role) {
			let i = O[t], s = e.teams[o], c = r.mode === "duel" || (n === 0 ? i.planet <= 2 : i.planet >= 2), l = Math.max(0, i.cost - s.columns[i.planet].length), u = i.effects.reduce((e, t) => e + (t.kind === "influence" ? (t.n ?? t.points ?? t.pattern?.reduce((e, t) => e + t, 0) ?? 1) * 2 : t.kind === "credits" ? (t.n ?? 3) * .3 : t.kind === "zenithium" ? (t.n ?? 1) * 1.2 : 1), 0);
			return (c ? Math.max(0, u - l * .4) : 0) + (s.tech[N.indexOf(i.faction)] < 5 ? .5 : 0);
		}
		let ee = (e) => e === o ? 1 : -1;
		function v(e, t, n, r = !1) {
			let i = r ? ++e.serial : t.frame;
			e.used[i] ??= [], e.tasks.unshift(...n.map((e) => ({
				effect: e,
				owner: t.owner,
				frame: i,
				source: t.source
			})));
		}
		function y(e, t, n) {
			v(e, {
				...n,
				source: `bonus:${t}`
			}, [k[t]], !0);
		}
		function b(e, t, n, r, i = t.owner) {
			if (e.planets[n] == null || e.winner != null) return;
			e.used[t.frame].push(n);
			let a = e.planets[n] + Ot(i) * r;
			if (Math.abs(a) < 4) {
				e.planets[n] = a;
				return;
			}
			if (e.planets[n] = null, e.teams[i].discs[n]++, kt(e.teams[i].discs)) {
				e.winner = i, e.tasks = [];
				return;
			}
			let o = e.planetBonuses[n];
			o && (e.planetBonuses[n] = null, y(e, o, {
				...t,
				owner: i
			}));
		}
		function x(e, t) {
			let n = t.effect;
			return M.filter((r) => e.planets[r] != null && (n.planet == null || r === n.planet) && r !== n.except && (!n.different || !e.used[t.frame].includes(r)) && (!n.center || e.planets[r] === 0) && (!n.enemySide || e.planets[r] * Ot(t.owner) < 0));
		}
		let S = (e, t, n) => t.effect.free ? 0 : Math.max(0, e.teams[t.owner].tech[n] + 1 - (t.effect.discount ?? 0));
		function C(e, t) {
			if (t.card && O[t.card]) return {
				amount: O[t.card].cost,
				planet: O[t.card].planet
			};
			if (e.effect.amounts && t.amount != null) {
				let n = e.effect.factors?.[e.effect.amounts.indexOf(t.amount)] ?? 1;
				return e.effect.kind === "exile" ? { amount: n } : { factor: n };
			}
			return { amount: 1 };
		}
		function w(e, t) {
			let n = (e, t = {}) => ({
				id: "",
				label: e,
				...t
			});
			if (t.targets) return t.targets.filter((t) => e.planets[t.planet] != null).map((e) => n("planet", e));
			let i = t.effect, a = e.teams[t.owner], o = e.teams[1 - t.owner], s = i.n ?? 1, c = [];
			switch (i.kind) {
				case "influence":
				case "giveInfluence":
				case "reset":
					c = i.pattern ? (i.pattern.length === 3 && i.pattern[1] === 2 ? [
						-1,
						0,
						1,
						2,
						3
					] : M.filter((e) => e + i.pattern.length <= 5)).map((t) => n("pattern", {
						amount: t,
						planets: i.pattern.flatMap((n, r) => t + r >= 0 && t + r < 5 && e.planets[t + r] != null ? [t + r] : [])
					})).filter((e) => e.planets.length) : x(e, t).flatMap((e) => i.points ? Array.from({ length: i.points }, (t, r) => n("planet", {
						planet: e,
						amount: r + 1
					})) : [n("planet", {
						planet: e,
						amount: s
					})]);
					break;
				case "exile":
				case "transfer": {
					let r = i.kind === "transfer" || i.opponent ? o.columns : a.columns;
					c = M.flatMap((a) => {
						if (i.planet != null && a !== i.planet || a === i.except || i.different && e.used[t.frame].includes(a)) return [];
						if (i.amounts) return i.amounts.filter((e) => r[a].length >= e).map((e) => n("quantity", {
							planet: a,
							amount: e
						}));
						let o = r[a].at(-1);
						return o ? [n("card", {
							planet: a,
							card: o
						})] : [];
					}), t.follow && !i.amounts && (t.remaining ?? s) > c.reduce((e, t) => e + (i.different ? 1 : r[t.planet].length), 0) && (c = []);
					break;
				}
				case "discard":
					c = i.full ? e.hand.length ? [n("continue")] : [] : e.hand.map((e) => n("card", { card: e }));
					break;
				case "share":
					c = e.hand.map((e) => n("card", { card: e }));
					break;
				case "spendCredits":
				case "spendZenithium":
					c = (i.amounts ?? [s]).filter((e) => a[i.kind === "spendCredits" ? "credits" : "zenithium"] >= e).map((e) => n("quantity", { amount: e }));
					break;
				case "giveCredits":
				case "giveZenithium":
					a[i.kind === "giveCredits" ? "credits" : "zenithium"] >= s && (c = [n("continue")]);
					break;
				case "giveLeader":
					e.leader?.team === t.owner && (c = [n("continue")]);
					break;
				case "develop":
					c = N.flatMap((r, o) => a.tech[o] < 5 && (!i.faction || i.faction === r) && (!i.lowest || a.tech[o] === Math.min(...a.tech)) && a.zenithium >= S(e, t, o) ? [n("technology", {
						faction: r,
						amount: S(e, t, o)
					})] : []);
					break;
				case "bonus":
					c = i.visible ? [...e.planetBonuses, ...e.techBonuses].flatMap((e, t) => e ? [n("bonus", {
						slot: t,
						card: e
					})] : []) : m.length ? [n("continue")] : [];
					break;
				case "techBonus":
					e.techBonuses[N.indexOf(i.faction)] && (c = [n("continue")]);
					break;
				case "choice":
					c = [n("left"), n("right")];
					break;
				case "mobilize":
					r.deckCount + r.discard.length > 0 && (c = [n("continue")]);
					break;
				default: c = [n("continue")];
			}
			return t.follow && (c = c.filter((n) => {
				let r = Nt(t.follow, C(t, n));
				return r.kind !== "influence" || r.pattern || x(e, {
					...t,
					effect: r
				}).length > 0;
			})), (t.optional || i.optional || i.kind === "share") && c.push(n("skip")), c;
		}
		function T(e, t, n) {
			let r = g(e), i = structuredClone(e);
			if (i.tasks = [], i.plan = [], i.reliable = !1, t.kind === "influence") return Math.max(0, ...x(i, {
				...n,
				effect: t
			}).map((e) => {
				let a = structuredClone(i);
				return b(a, n, e, t.n ?? 1), Math.min(100, (g(a) - r) * ee(n.owner));
			})) * ee(n.owner);
			let a = w(i, {
				...n,
				effect: t
			});
			return a.length ? a.reduce((e, a) => {
				let s = structuredClone(i);
				E(s, {
					...n,
					effect: t,
					follow: void 0
				}, a, !1);
				let c = g(s) - r;
				return n.owner === o ? Math.max(e, c) : Math.min(e, c);
			}, n.owner === o ? -Infinity : Infinity) : 0;
		}
		function E(e, n, i, s) {
			if (s && e.reliable && n.owner === o && e.plan.push({
				key: Mt(e, n),
				choice: Dt(i)
			}), i.label === "skip") return;
			if (n.targets) {
				let t = n.targets.filter((e) => e.planet !== i.planet);
				t.length && e.tasks.unshift({
					...n,
					targets: t
				}), b(e, n, i.planet, i.amount);
				return;
			}
			let c = n.effect, l = c.n ?? 1, u = e.teams[n.owner], f = e.teams[1 - n.owner], p = C(n, i), h = !1, g = e.tasks.length, x = (t) => {
				let r = (n.remaining ?? t) - 1;
				r > 0 && (e.tasks.unshift({
					...n,
					remaining: r,
					optional: !1
				}), h = !0);
			};
			switch (c.kind) {
				case "influence":
				case "giveInfluence":
					if (c.pattern) e.tasks.unshift({
						...n,
						effect: void 0,
						targets: c.pattern.flatMap((t, n) => i.amount + n >= 0 && i.amount + n < 5 && e.planets[i.amount + n] != null ? [{
							planet: i.amount + n,
							amount: t
						}] : [])
					});
					else {
						let t = c.points ? i.amount : l;
						c.points && c.points > t && e.tasks.unshift({
							...n,
							optional: !1,
							effect: {
								...c,
								points: c.points - t
							}
						}), b(e, n, i.planet, t, c.kind === "giveInfluence" ? 1 - n.owner : n.owner);
					}
					break;
				case "reset":
					e.planets[i.planet] = 0;
					break;
				case "credits":
				case "zenithium": {
					let e = c.opponent ? f : u, t = c.techCount ? c.techCount[u.tech.filter((e) => e > 0).length - 1] ?? 0 : c.enemyColorCount == null ? c.colorCount == null ? c.upTo == null ? l : Math.max(0, c.upTo - e[c.kind]) : u.columns.filter((e) => e.length).length * c.colorCount : f.columns.filter((e) => e.length).length * c.enemyColorCount;
					e[c.kind] += t;
					break;
				}
				case "spendCredits":
				case "spendZenithium":
					u[c.kind === "spendCredits" ? "credits" : "zenithium"] -= i.amount;
					break;
				case "giveCredits":
				case "giveZenithium": {
					let e = c.kind === "giveCredits" ? "credits" : "zenithium";
					u[e] -= l, f[e] += l;
					break;
				}
				case "stealCredits":
				case "stealZenithium": {
					let e = c.kind === "stealCredits" ? "credits" : "zenithium", t = Math.min(l, f[e]);
					u[e] += t, f[e] -= t;
					break;
				}
				case "exile":
				case "transfer": {
					let e = c.kind === "transfer" || c.opponent ? f.columns : u.columns;
					for (let t = 0; t < (c.amounts ? i.amount : 1); t++) {
						let t = e[i.planet].pop();
						c.kind === "transfer" && u.columns[i.planet].push(t);
					}
					c.amounts || x(l);
					break;
				}
				case "discard":
					e.hand = c.full ? [] : e.hand.filter((e) => e !== i.card), e.handCounts[r.players.indexOf(a)] = e.hand.length;
					break;
				case "mobilize": {
					e.reliable = !1;
					let i = Math.min(l, r.deckCount + r.discard.length);
					e.utility += ee(c.opponent ? 1 - n.owner : n.owner) * t.columns * i * 1.3, n.follow && (e.utility += d.reduce((t, r, i) => t + r * T(e, Nt(n.follow, {
						amount: 1,
						planet: i
					}), n), 0));
					return;
				}
				case "leader":
					e.leader = {
						team: n.owner,
						gold: !!c.gold || e.leader?.team === n.owner
					};
					break;
				case "giveLeader":
					e.leader = {
						team: 1 - n.owner,
						gold: !1
					};
					break;
				case "develop": {
					let t = N.indexOf(i.faction), a = S(e, n, t), o = ++u.tech[t];
					u.zenithium -= a;
					let s = ++e.serial;
					e.used[s] = [];
					let c = {
						...n,
						frame: s,
						source: `tech:${r.boards[t]}:${o}`
					};
					e.tasks.unshift({
						...c,
						effect: void 0,
						row: Math.min(...u.tech, 3),
						follow: void 0
					}), v(e, c, ne[r.boards[t]].slice(0, o).reverse().flat());
					break;
				}
				case "bonus":
					c.visible ? (i.slot < 5 ? e.planetBonuses[i.slot] = null : e.techBonuses[i.slot - 5] = null, y(e, i.card, n)) : (e.reliable = !1, e.utility += m.reduce((t, r) => t + T(e, k[r], n), 0) / Math.max(1, m.length));
					break;
				case "techBonus": {
					let t = N.indexOf(c.faction), r = e.techBonuses[t];
					r && (e.techBonuses[t] = null, y(e, r, n));
					break;
				}
				case "choice":
					v(e, n, i.label === "left" ? c.left : c.right);
					break;
				case "share": {
					let n = r.players.findIndex((e) => e.team === o && e.rid !== a.rid), s = r.players[n], l = _(e, i.card, s.role) - _(e, i.card);
					e.utility += t.hand * l * .4, e.hand = e.hand.filter((e) => e !== i.card), e.handCounts[r.players.indexOf(a)] = e.hand.length, e.handCounts[n]++, x(c.n ?? 2);
					break;
				}
			}
			if (!h && n.follow && e.winner == null) {
				let t = e.tasks.splice(0, Math.max(0, e.tasks.length - g));
				e.tasks.unshift(...t, {
					...n,
					effect: Nt(n.follow, p),
					follow: void 0,
					optional: !1,
					remaining: void 0
				});
			}
		}
		function D(e) {
			let n = [e];
			for (let e = 0; e < 90 && n.some((e) => e.tasks.length && e.winner == null); e++) {
				let e = [];
				for (let t of n) {
					if (!t.tasks.length || t.winner != null) {
						e.push(t);
						continue;
					}
					let n = t.tasks.shift();
					if (t.used[n.frame] ??= [], n.row != null) {
						let r = t.teams[n.owner], i = r.rows;
						r.rows = Math.max(r.rows, n.row), v(t, n, Array.from({ length: Math.max(0, n.row - i) }, (e, t) => ({
							kind: "influence",
							n: i + t + 1
						}))), e.push(t);
						continue;
					}
					let r = n.effect;
					if (r?.resetUsed && (t.used[n.frame] = [], n.effect = {
						...r,
						resetUsed: !1
					}), r?.kind === "condition") {
						let i = r.condition, a = t.teams[n.owner], o = t.teams[1 - n.owner];
						i.kind === "pay" ? t.tasks.unshift({
							...n,
							effect: i.effect,
							follow: r.effect,
							optional: !r.mandatory
						}) : (i.kind === "leader" ? t.leader?.team === n.owner : i.kind === "credits" ? a.credits >= i.min : i.kind === "enemyCredits" ? o.credits >= i.min : i.kind === "enemyZenithium" ? o.zenithium >= i.min : t.leader?.team === 1 - n.owner) && v(t, n, [r.effect]), e.push(t);
						continue;
					}
					let i = w(t, n);
					if (!i.length || i.every((e) => e.label === "skip")) {
						e.push(t);
						continue;
					}
					let a = !!n.targets || i.length > 1 || !!n.optional || r?.kind === "choice" || r?.kind === "share", s = i.map((e) => {
						let r = structuredClone(t);
						return E(r, n, e, a), r;
					});
					n.owner === o ? e.push(...s) : (s.sort((e, t) => g(e) - g(t)), e.push(s[0]));
				}
				e.sort((e, t) => g(t) - g(e)), n = e.slice(0, t.beam);
			}
			return n.sort((e, t) => g(t) - g(e)), n[0];
		}
		function A(e) {
			let t = e.leader?.team === o ? e.leader.gold ? 6 : 5 : 4, n = r.players.indexOf(a);
			return e.handCounts[n] += Math.min(Math.max(0, t - e.handCounts[n]), r.deckCount + r.discard.length + 1), g(e);
		}
		function ie(e) {
			let t = h(), n = O[e.card], i = {
				owner: o,
				frame: 0,
				source: e.card
			};
			return t.hand = t.hand.filter((t) => t !== e.card), t.handCounts[r.players.indexOf(a)]--, e.use === "recruit" ? (t.teams[o].credits -= Math.max(0, n.cost - t.teams[o].columns[n.planet].length), t.teams[o].columns[n.planet].push(n.id), v(t, i, n.effects)) : e.use === "develop" ? v(t, i, [{
				kind: "develop",
				faction: n.faction
			}]) : v(t, i, [
				{ kind: "leader" },
				n.faction === "human" ? {
					kind: "credits",
					n: 3
				} : n.faction === "robot" ? {
					kind: "zenithium",
					n: 1
				} : {
					kind: "mobilize",
					n: 2
				},
				...r.mode === "team" ? [{
					kind: "share",
					n: 2
				}] : []
			]), D(t);
		}
		if (r.phase === "mulligan") {
			let e = h();
			return { action: {
				type: "mulligan",
				cards: i.hand.map((t) => ({
					id: t,
					score: _(e, t)
				})).sort((e, t) => t.score - e.score).slice(1).filter((e) => e.score < 4.5 || O[e.id].cost > 7).map((e) => e.id)
			} };
		}
		if (r.phase === "choice") {
			let e = n.memory, t = e?.turn === r.turnNumber ? e.plan?.[0] : void 0, a = Mt({
				...r,
				hand: i.hand
			}, {
				owner: o,
				frame: 0,
				source: r.pending.source,
				effect: r.pending.effect,
				follow: r.pending.follow
			}), s = t?.key === a ? i.choices.find((e) => JSON.stringify(Dt(e)) === JSON.stringify(t.choice)) : void 0;
			if (s) return {
				action: {
					type: "choose",
					id: s.id
				},
				memory: {
					turn: r.turnNumber,
					plan: e.plan.slice(1)
				}
			};
			let c = {
				owner: o,
				frame: 0,
				source: r.pending.source,
				effect: r.pending.effect,
				follow: r.pending.follow,
				optional: r.pending.optional
			};
			c.effect || (c.targets = i.choices.filter((e) => e.planet != null).map((e) => ({
				planet: e.planet,
				amount: e.amount
			})));
			let l;
			for (let e of i.choices) {
				let t = h();
				E(t, c, e, !1);
				let n = D(t), r = A(n);
				(!l || r > l.score) && (l = {
					c: e,
					s: n,
					score: r
				});
			}
			return l ? {
				action: {
					type: "choose",
					id: l.c.id
				},
				memory: {
					turn: r.turnNumber,
					plan: l.s.plan
				}
			} : null;
		}
		let j = i.moves.filter((e) => e.type === "play");
		if (j.length) {
			let e;
			for (let n of j) {
				let r = ie(n), i = A(r) - (n.use === "leader" && r.winner == null ? Math.max(0, c - 1) * t.leaderRepeat : 0);
				(!e || i > e.score) && (e = {
					action: n,
					s: r,
					score: i
				});
			}
			return {
				action: e.action,
				memory: {
					turn: r.turnNumber,
					plan: e.s.plan
				}
			};
		}
		if (r.phase === "order") {
			let e = r.players.indexOf(a), t = r.players.find((e) => e.team === o && e.rid !== a.rid);
			return { action: {
				type: "order",
				rid: i.hand.some((e) => {
					let t = O[e];
					return (a.role === 0 ? t.planet <= 2 : t.planet >= 2) && t.cost <= r.teams[o].credits + r.teams[o].columns[t.planet].length;
				}) || r.players[e].handCount >= t.handCount ? a.rid : t.rid
			} };
		}
		return { action: i.moves[0] };
	};
}
var Ft = Pt(), It = {
	zenPlay(e, t) {
		let n = e.data;
		if (!n || !O[n.card]) return null;
		let r = n.use === "recruit" ? `public-${n.team}-${O[n.card].planet}-${n.card}` : "discard", i = t.anchor(r), a = t.anchor(`seat-${n.team}`);
		if (!i || !a) return null;
		if (t.queued) return {
			ms: 120,
			node: /* @__PURE__ */ y(S, {
				at: i,
				ms: 120
			})
		};
		let o = (e.rid === t.myRid ? t.anchor(`play-origin-${e.rid}`) : null) ?? {
			x: a.x + a.w / 2 - 36,
			y: a.y,
			w: 72,
			h: 100
		};
		return {
			ms: 240,
			hide: n.use === "recruit" ? [r] : void 0,
			node: /* @__PURE__ */ y(x, {
				from: o,
				to: i,
				ms: 180,
				children: /* @__PURE__ */ y("div", {
					className: "zen-fx-card",
					style: {
						width: o.w,
						height: o.h
					},
					children: /* @__PURE__ */ y(Ct, { id: n.card })
				})
			})
		};
	},
	zenCapture(e, t) {
		let n = e.data, r = t.anchor(`planet-${n.planet}`), i = t.anchor(`collection-${n.team}-${n.planet}`);
		if (!r || !i) return null;
		if (t.queued) return {
			ms: 120,
			node: /* @__PURE__ */ y(S, {
				at: i,
				ms: 120
			})
		};
		let a = {
			x: r.x + r.w / 2 - 22,
			y: i.y < r.y ? r.y : r.y + r.h - 44,
			w: 44,
			h: 46
		}, o = {
			x: i.x + i.w / 2 - 14,
			y: i.y,
			w: 28,
			h: 29
		};
		return {
			ms: 240,
			node: /* @__PURE__ */ y(x, {
				from: a,
				to: o,
				ms: 190,
				children: /* @__PURE__ */ y(Q, {
					planet: n.planet,
					size: 44
				})
			})
		};
	},
	zenTech(e, t) {
		let n = e.data, r = t.anchor(`tech-${n.track}`);
		return r ? {
			ms: 240,
			node: /* @__PURE__ */ y(S, {
				at: r,
				ms: 240
			})
		} : null;
	},
	zenLeader(e, t) {
		let n = t.anchor("leader");
		return n ? {
			ms: 240,
			node: /* @__PURE__ */ y(S, {
				at: n,
				ms: 240
			})
		} : null;
	},
	zenDraw(e, t) {
		let n = e.data, r = t.anchor("deck"), i = t.anchor(`seat-${n.team}`);
		return !r || !i ? null : t.queued ? {
			ms: 120,
			node: /* @__PURE__ */ y(S, {
				at: i,
				ms: 120
			})
		} : {
			ms: 240,
			node: /* @__PURE__ */ y(x, {
				from: {
					x: r.x,
					y: r.y,
					w: 34,
					h: 48
				},
				to: {
					x: i.x + i.w / 2 - 17,
					y: i.y,
					w: 34,
					h: 48
				},
				ms: 180,
				children: /* @__PURE__ */ y("div", {
					className: "zen-deck-back",
					children: "Z"
				})
			})
		};
	}
}, Lt = () => {};
function Rt(e) {
	if (e.winner == null || e.victory === "draw") return [];
	let t = e.teams[e.winner].discs;
	if (e.victory === "absolute") {
		let e = t.findIndex((e) => e >= 3);
		return e < 0 ? [] : [
			e,
			e,
			e
		];
	}
	return e.victory === "democratic" ? M.filter((e) => t[e] > 0).slice(0, 4) : M.flatMap((e) => Array.from({ length: t[e] }, () => e)).slice(0, 5);
}
function zt(e) {
	let { public: t, members: n, result: r, hintCount: i, onPlayAgain: o, onBackToLobby: l } = e, u = f(), d = t, [h, g] = c(!0), _ = s(null), ee = s(null), v = s(null);
	a(() => {
		_.current?.focus({ preventScroll: !0 });
	}, []);
	let x = (e) => {
		g(e), requestAnimationFrame(() => (e ? _ : ee).current?.focus({ preventScroll: !0 }));
	}, S = (e) => n.find((t) => t.rid === e)?.name ?? e, T = (e) => d.players.filter((t) => t.team === e).map((e) => S(e.rid)).join(" · "), E = d.winner == null ? [0, 1] : [d.winner, 1 - d.winner], D = Rt(d);
	return /* @__PURE__ */ b("div", {
		className: "zen-endgame",
		children: [
			/* @__PURE__ */ y("div", {
				className: "zen-final-board",
				inert: h,
				children: /* @__PURE__ */ y(Tt, {
					public: d,
					private: e.private,
					members: n,
					myRid: e.myRid,
					send: Lt
				})
			}),
			/* @__PURE__ */ y(w, {}),
			/* @__PURE__ */ y("div", {
				className: "zen-result-overlay",
				hidden: !h,
				children: /* @__PURE__ */ b("section", {
					ref: v,
					className: "zen-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": u("session.result.title"),
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), x(!1)), e.key === "Tab") {
							let t = v.current?.querySelectorAll("button:not(:disabled), [tabindex=\"0\"]"), n = t?.[0], r = t?.[t.length - 1];
							e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
						}
					},
					children: [
						/* @__PURE__ */ y("button", {
							type: "button",
							className: "zen-collapse",
							ref: _,
							"aria-label": u("games.zenith.reviewBoard"),
							onClick: () => x(!1),
							children: /* @__PURE__ */ y(m, { size: 23 })
						}),
						/* @__PURE__ */ b("div", {
							className: "zen-result-scroll",
							children: [
								/* @__PURE__ */ b("p", {
									className: "zen-result-eyebrow",
									children: ["ZENITH · ", u("games.zenith.finished")]
								}),
								/* @__PURE__ */ y("div", {
									className: "zen-victory-medal",
									children: /* @__PURE__ */ y(vt, { gold: !0 })
								}),
								/* @__PURE__ */ y("p", {
									className: "zen-result-kicker",
									children: d.winner == null ? u("games.zenith.draw") : T(d.winner)
								}),
								/* @__PURE__ */ y("h1", { children: d.winner == null ? u("games.zenith.draw") : u("games.zenith.victory", { n: d.winner + 1 }) }),
								/* @__PURE__ */ y("p", {
									className: "zen-result-victory",
									children: d.victory && u(Pe[d.victory])
								}),
								D.length > 0 && /* @__PURE__ */ y("div", {
									className: "zen-victory-orbit",
									"aria-label": u("games.zenith.winningDiscs"),
									children: D.map((e, t) => /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y(Q, {
										planet: e,
										size: 76
									}), /* @__PURE__ */ y("span", { children: u(U[e]) })] }, t))
								}),
								/* @__PURE__ */ b("table", {
									className: "zen-result-comparison",
									children: [/* @__PURE__ */ y("thead", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
										scope: "col",
										children: u("games.zenith.resultPlanet")
									}), E.map((e) => /* @__PURE__ */ b("th", {
										scope: "col",
										className: e === d.winner ? "is-winner" : "",
										children: [u("games.zenith.teamNumber", { n: e + 1 }), /* @__PURE__ */ y("small", { children: T(e) })]
									}, e))] }) }), /* @__PURE__ */ b("tbody", { children: [M.map((e) => /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ b("th", {
										scope: "row",
										children: [/* @__PURE__ */ y(Q, {
											planet: e,
											size: 30
										}), u(U[e])]
									}), E.map((t) => /* @__PURE__ */ y("td", {
										"data-won": t === d.winner && D.includes(e),
										children: d.teams[t].discs[e]
									}, t))] }, e)), /* @__PURE__ */ b("tr", {
										className: "zen-result-total",
										children: [/* @__PURE__ */ y("th", {
											scope: "row",
											children: u("games.zenith.totalDiscs")
										}), E.map((e) => /* @__PURE__ */ y("td", { children: d.teams[e].discs.reduce((e, t) => e + t, 0) }, e))]
									})] })]
								}),
								/* @__PURE__ */ b("div", {
									className: "zen-result-notes",
									children: [i !== void 0 && /* @__PURE__ */ y("p", { children: u("session.hint.usedCount", { n: i }) }), d.players.filter((e) => (r.autopilot?.[e.rid] ?? 0) > 0).map((e) => /* @__PURE__ */ b("p", { children: [
										/* @__PURE__ */ y(p, { size: 16 }),
										S(e.rid),
										" · ",
										u("session.autopilot.share", { n: Math.round(r.autopilot[e.rid] * 100) })
									] }, e.rid))]
								})
							]
						}),
						/* @__PURE__ */ b("footer", {
							className: "zen-result-footer",
							children: [
								o && /* @__PURE__ */ y(C, {
									className: "zen-primary",
									label: u("games.zenith.again"),
									confirmLabel: u("games.zenith.confirmAgain"),
									onConfirm: o
								}, `again-${h}`),
								l && /* @__PURE__ */ y(C, {
									className: "zen-secondary",
									label: u("games.zenith.lobby"),
									confirmLabel: u("games.zenith.confirmLobby"),
									onConfirm: l
								}, `lobby-${h}`),
								!o && !l && /* @__PURE__ */ y("p", { children: u("games.zenith.waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ y("button", {
				type: "button",
				className: "zen-restore",
				hidden: h,
				ref: ee,
				onClick: () => x(!0),
				children: u("games.zenith.restoreResult")
			})
		]
	});
}
//#endregion
//#region src/games/zenith/options.tsx
function Bt({ value: e, onChange: t }) {
	let n = f(), r = ie.safeParse(e), i = r.success ? r.data : ie.parse(void 0);
	return /* @__PURE__ */ b("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ b(E, {
				title: n("games.zenith.mode"),
				children: [/* @__PURE__ */ y(T, {
					name: "zen-mode",
					value: "duel",
					checked: i.mode === "duel",
					label: n("games.zenith.duel"),
					accent: A.accent,
					onChange: () => t({
						...i,
						mode: "duel"
					})
				}), /* @__PURE__ */ y(T, {
					name: "zen-mode",
					value: "team",
					checked: i.mode === "team",
					label: n("games.zenith.team"),
					accent: A.accent,
					onChange: () => t({
						...i,
						mode: "team"
					})
				})]
			}),
			/* @__PURE__ */ b(E, {
				title: n("games.zenith.technology"),
				children: [/* @__PURE__ */ y(T, {
					name: "zen-tech",
					value: "sun",
					checked: i.technology === "sun",
					label: n("games.zenith.sun"),
					accent: A.accent,
					onChange: () => t({
						...i,
						technology: "sun"
					})
				}), /* @__PURE__ */ y(T, {
					name: "zen-tech",
					value: "random",
					checked: i.technology === "random",
					label: n("games.zenith.random"),
					accent: A.accent,
					onChange: () => t({
						...i,
						technology: "random"
					})
				})]
			}),
			/* @__PURE__ */ y(D, {
				checked: i.secretAgents,
				label: n("games.zenith.expansion"),
				accent: A.accent,
				onChange: () => t({
					...i,
					secretAgents: !i.secretAgents
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/zenith/entry.tsx
var Vt = {
	definition: Me,
	View: Tt,
	bot: Ft,
	fx: It,
	OverView: zt,
	Options: Bt,
	locales: {
		zh: {
			name: "天顶星宇",
			desc: "招募星际特工、发展科技，在五颗星球的影响力争夺中赢得议会。",
			rules: "目标：\n通过招募特工、发展科技与成为领袖争夺五颗星球的影响力。获得同一星球的 3 枚圆片、不同星球的 4 枚圆片，或任意 5 枚圆片，立即获胜；效果尚未完成时也立即结束。\n准备：\n双方各有 12 信用点和 1 泽尼晶。每人抽取 4 张手牌，可以将其中任意数量弃掉并等量重抽一次。手牌保密。后手在地球获得 1 点影响力。科技板可选首次游戏推荐的 S.U.N. 组合，或随机决定三块板的正反面。五颗星球和三条科技轨各放置一枚随机公开奖励，其余奖励背面朝上形成储备。\n回合行动：\n每回合必须使用一张手牌，选择以下一种用途，完成效果后补牌并刷新星球。\n· 招募特工：将牌放入己方对应星球的牌列，支付印刷费用减去该列原有牌数的信用点，最低为 0。按从左到右的顺序执行卡牌效果。\n· 发展科技：弃掉一张手牌，支付相应阵营下一科技等级所需的泽尼晶，逐级升级。费用为新等级数。按从高到低的顺序执行该轨新等级及所有旧等级的效果。\n· 成为领袖：弃掉一张手牌并取得领袖徽章。人类额外获得 3 信用点，机器人额外获得 1 泽尼晶，异兽额外动员 2 张牌。已有银徽章则翻成金徽章；金徽章保持不变。新取得对方徽章时为银面，明确取得金徽章的效果除外。\n影响力与奖励：\n每颗星球的圆片从中央到己方控制区需要移动 4 格。每点影响力向己方拉动一格；某些效果会将圆片推向对方。进入控制区时立即获得圆片。该星球第一次被获得时，获得者立即执行对应奖励，然后弃掉奖励；奖励不补充。圆片在当前玩家回合末才回到中央，在此之前无法继续移动，溢出的影响力作废。自己的行动也可能使对方获得圆片或立即获胜；由对方选择其奖励的目标。\n科技奖励：\n首次到达一条科技轨的二级时，在二级效果结束后、一级效果开始前执行该轨奖励。三条科技都达到一级、二级、三级时，分别获得 1、2、3 点可用于同一颗星球的影响力；每项每队限一次，在本次科技效果结束后执行。\n特工效果：\n· 动员：翻开牌库顶牌放入对应星球牌列，不支付费用且不执行卡牌效果。\n· 流放：弃掉指定牌列最上面的牌。\n· 转移：把对方指定牌列最上面的牌移到己方同星球牌列，不执行其效果。\n每次处理后，下方新露出的牌才成为可选目标。刚招募的牌可以被自身效果选中。获得圆片不会清空牌列。\n带条件的交换效果只有支付完整代价才能获得收益，可以放弃整个交换。其余效果尽可能执行，不能执行的部分略过。消耗 2、4、7 张同星球牌的效果只能选择其中一个档位。支付资源获得若干点自由影响力时，可按提示分配；要求不同星球或相邻星球时须满足对应限制。牌面注明以对方资源、领袖或己方科技数量为条件的效果，在执行到该效果时检查。\n回合结束：\n普通玩家补至 4 张手牌，拥有银徽章的一方补至 5 张，金徽章补至 6 张。超过补牌数量时保留所有手牌且不补牌。然后将本回合获得的星球圆片补回中央。牌库或奖励储备用尽时，将对应弃牌重新洗成新牌库或储备。储备中的信用点、泽尼晶和圆片不限量。\n补充规则：若回合开始时没有手牌，跳过行动，仍按正常回合结束步骤尝试补牌，然后交给下一名玩家。若所有玩家的手牌、牌库和弃牌堆均为空，游戏以和局结束。\n四人组队：\n两队各两人。开局可由主机调整分组和分工：科技侧队员仅能在水星、金星、地球招募，外交侧队员仅能在地球、火星、木星招募。限制只影响招募，任何手牌都可用于发展科技或成为领袖。队友共享资源、牌列、科技、圆片及领袖徽章，手牌各自保密；可以当着对手讨论，但不能展示手牌。后手队伍在金星和火星各获得 1 点影响力，替代地球补偿。\n双方队伍轮流行动。每队每轮协商选择先行动的队员，该队员完成整个回合后，另一名队员完成整个回合，然后交给对方队伍。成为领袖时，可以从自己的剩余手牌中给队友至多 2 张，再为自己补牌。任一胜利条件达成时整队立即获胜。\n秘密特工扩展：\n开启后将 10 张新特工混入牌库。五张费用为 0，五张费用为 5。包括将双方资源补至指定数量、根据对方资源或领袖取得额外收益，以及支付费用发展己方最低等级科技等效果。最低科技并列时自行选择；所有科技已到最高级时无法继续发展。",
			resultPlanet: "星球圆片",
			finished: "对局结束",
			science: "科技",
			reviewBoard: "回看局面",
			restoreResult: "查看结算",
			winningDiscs: "达成胜利的圆片组合",
			totalDiscs: "圆片总数",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			mode: "游戏模式",
			duel: "2 人对战",
			team: "4 人组队",
			expansion: "秘密特工扩展",
			technology: "科技板组合",
			sun: "S.U.N. 推荐组合",
			random: "随机正反面",
			planets: {
				mercury: "水星",
				venus: "金星",
				terra: "地球",
				mars: "火星",
				jupiter: "木星"
			},
			factions: {
				animod: "异兽",
				human: "人类",
				robot: "机器人"
			},
			teams: "分组与分工",
			teamNumber: "第 {{n}} 队",
			techRole: "科技侧",
			diplomacyRole: "外交侧",
			swapHint: "依次选择两名玩家以交换位置。",
			start: "确认分组",
			yourTurn: "轮到你行动",
			waiting: "等待 {{name}} 行动",
			resolving: "正在结算",
			turn: "回合 {{n}}",
			emptyHand: "没有手牌，请补牌并跳过本回合。",
			pass: "补牌并跳过",
			draw: "和局",
			drawReason: "所有玩家均无手牌，且已无牌可补。",
			mulligan: "选择要重抽的手牌，然后确认。",
			mulliganDone: "已确认手牌，等待其他玩家。",
			keep: "保留全部手牌",
			replace: "重抽 {{n}} 张",
			order: "请选择本轮先行动的队员。",
			goFirst: "{{name}} 先行动",
			waitOrder: "等待对方确定行动顺序",
			yourChoice: "请选择效果的目标",
			waitChoice: "等待 {{name}} 选择",
			choose: "选择目标",
			hand: "你的手牌",
			select: "选择一张手牌",
			recruit: "招募特工",
			develop: "发展科技",
			leader: "成为领袖",
			recruitCost: "招募 · {{n}} 信用点",
			developCost: "科技 · {{n}} 泽尼晶",
			leaderAction: "成为领袖",
			credits: "信用点",
			zenithium: "泽尼晶",
			handCount: "{{n}} 张手牌",
			deckCount: "牌库 {{n}}",
			silver: "银领袖 · 补至 5 张",
			gold: "金领袖 · 补至 6 张",
			noLeader: "领袖徽章",
			discs: "已获得的星球圆片",
			discCount: "{{n}} 枚",
			emptyColumn: "尚无特工",
			columnCount: "{{n}} 张",
			column: "{{planet}}牌列",
			history: "对局记录",
			discard: "弃牌堆",
			details: "卡牌详情",
			effects: "卡牌效果",
			close: "关闭",
			techTrack: "{{faction}}科技 · {{board}}",
			level: "等级 {{n}}",
			currentLevel: "己方 {{own}} · 对方 {{enemy}}",
			levelCost: "{{n}} 泽尼晶",
			bonus: "奖励",
			firstBonus: "首次获得奖励",
			techBonus: "二级首达奖励",
			chooseBonus: "取得此奖励",
			skip: "放弃此项",
			continue: "执行效果",
			optionQuantity: "{{n}}",
			optionPlanet: "{{planet}} · {{n}} 点",
			optionCards: "{{planet}} · 流放 {{n}} 张",
			optionSpend: "支付 {{n}}",
			optionTech: "{{faction}} · {{n}} 泽尼晶",
			giveCard: "交给队友：{{card}}",
			pattern: "相邻星球：{{planets}}",
			left: "选择左侧效果",
			right: "选择右侧效果",
			recruitRestricted: "这颗星球不在你的招募区域。",
			insufficient: "资源不足，无法执行此行动。",
			maximum: "该科技已达到最高级。",
			victory: "第 {{n}} 队获胜",
			absolute: "绝对胜利 · 同星球 3 枚",
			democratic: "民主胜利 · 不同星球 4 枚",
			popular: "民众胜利 · 任意 5 枚",
			again: "再来一局",
			lobby: "返回大厅",
			waitHost: "等待主机决定下一局",
			teamMembers: "{{names}}",
			effectsText: {
				influence: "在{{target}}获得 {{n}} 点影响力",
				giveInfluence: "使对方在{{target}}获得 {{n}} 点影响力",
				reset: "将一颗星球的圆片移回中央",
				any: "任意一颗星球",
				except: "除{{planet}}外的一颗星球",
				different: "此前未选的星球",
				center: "圆片位于中央的星球",
				enemySide: "圆片位于对方一侧的星球",
				flexible: "获得 {{n}} 点可自由分配的影响力",
				pattern: "在相邻 {{n}} 颗星球分别获得 {{amounts}} 点影响力",
				surrounding: "在任意一颗星球获得 2 点影响力，并在它两侧的相邻星球各获得 1 点影响力",
				credits: "获得 {{n}} 信用点",
				zenithium: "获得 {{n}} 泽尼晶",
				enemy: "对方：{{effect}}",
				upToCredits: "将信用点补至 {{n}}",
				upToZenithium: "将泽尼晶补至 {{n}}",
				colorCredits: "己方每有一种星球牌，获得 {{n}} 信用点",
				enemyColorCredits: "对方每有一种星球牌，获得 {{n}} 信用点",
				techCredits: "根据已发展的一级科技数量，获得 {{amounts}} 信用点",
				techZenithium: "根据已发展的一级科技数量，获得 {{amounts}} 泽尼晶",
				giveCredits: "给对方 {{n}} 信用点",
				giveZenithium: "给对方 {{n}} 泽尼晶",
				spendCredits: "支付 {{amounts}} 信用点",
				spendZenithium: "支付 {{amounts}} 泽尼晶",
				stealCredits: "从对方取得至多 {{n}} 信用点",
				stealZenithium: "从对方取得至多 {{n}} 泽尼晶",
				mobilize: "动员 {{n}} 张牌",
				exile: "流放{{owner}}{{target}}牌列顶部的 {{n}} 张牌",
				transfer: "转移对方{{target}}牌列顶部的 {{n}} 张牌",
				own: "己方",
				opponent: "对方",
				anyColumn: "任意星球",
				exceptColumn: "除{{planet}}外的星球",
				differentColumn: "此前未选星球",
				scaleExile: "流放己方{{target}}牌列顶部的 {{amounts}} 张牌",
				discard: "弃掉一张手牌",
				discardAll: "弃掉全部手牌",
				leader: "取得领袖徽章",
				gold: "取得金领袖徽章",
				giveLeader: "将领袖徽章交给对方",
				develop: "发展{{faction}}科技",
				anyTech: "任意一条",
				lowestTech: "最低等级的",
				free: "{{effect}}，免付泽尼晶",
				discount: "{{effect}}，少付 {{n}} 泽尼晶",
				bonus: "抽取并执行一枚随机奖励",
				visibleBonus: "选择并执行版图上的一枚公开奖励",
				techBonus: "首次到达二级时执行本轨奖励",
				share: "可给队友至多 {{n}} 张手牌",
				choice: "{{left}}；或{{right}}",
				pay: "可{{cost}}，然后{{effect}}",
				mustPay: "{{cost}}，然后{{effect}}",
				ifLeader: "若己方拥有领袖徽章，{{effect}}",
				ifCredits: "若己方至少有 {{n}} 信用点，{{effect}}",
				ifEnemyCredits: "若对方至少有 {{n}} 信用点，{{effect}}",
				ifEnemyZenithium: "若对方至少有 {{n}} 泽尼晶，{{effect}}",
				ifEnemyLeader: "若对方拥有领袖徽章，{{effect}}",
				derived: "等同于所选牌印刷费用的",
				derivedInfluence: "所选牌对应的星球",
				scalingReward: "{{effect}}（按所选档位获得 {{amounts}}）",
				derivedCredits: "获得等同于所选牌印刷费用的信用点",
				derivedZenithium: "获得等同于所选牌印刷费用的泽尼晶"
			},
			log: {
				pass: "{{name}} 没有手牌，补牌并跳过本回合",
				recruit: "{{name}} 招募了 {{card}}，支付 {{n}} 信用点",
				develop: "{{name}} 将{{faction}}科技发展至 {{n}} 级",
				leader: "{{name}} 取得领袖徽章，补牌数量为 {{n}}",
				influence: "{{name}} 在{{planet}}获得 {{n}} 点影响力",
				reset: "{{name}} 将{{planet}}圆片移回中央",
				capture: "{{name}} 获得一枚{{planet}}圆片",
				credits: "{{name}} 获得 {{n}} 信用点",
				zenithium: "{{name}} 获得 {{n}} 泽尼晶",
				exile: "{{name}} 流放了 {{card}}",
				transfer: "{{name}} 转移了 {{card}}",
				mobilize: "{{name}} 动员了 {{card}}",
				discard: "{{name}} 弃掉了 {{card}}",
				bonus: "{{name}} 获得奖励：{{effect}}",
				give: "{{name}} 向对方交出了 {{n}} {{resource}}",
				giveCard: "{{name}} 给队友一张手牌",
				giveLeader: "{{name}} 将领袖徽章交给对方",
				mulligan: "{{name}} 重抽了 {{n}} 张手牌"
			},
			errors: { illegal: "当前无法执行此操作，请重新选择。" },
			agents: {
				Elisabeth: "Elisabeth",
				Pkd1ck: "Pkd1ck",
				AgentEzra: "Agent Ezra",
				DonaldSmooth: "Donald Smooth",
				Huxl3y: "Huxl3y",
				Titus: "Titus",
				Mc4ffr3y: "Mc4ffr3y",
				Luc4s: "Luc4s",
				Cresus: "Cresus",
				Atlas: "Atlas",
				PunkMari: "Punk Mari",
				Septimus: "Septimus",
				DoubleJoe: "Double Joe",
				DonDune: "Don Dune",
				V3rn3: "V3rn3",
				Ch4mb3rs: "Ch4mb3rs",
				Buj0ld: "Buj0ld",
				JackCurry: "Jack Curry",
				C1x1n: "C1x1n",
				LadyMoore: "Lady Moore",
				L0v3cr4ft: "L0v3cr4ft",
				Suleiman: "Suleiman",
				Annie: "Annie",
				M4th3s0n: "M4th3s0n",
				Gilgamesh: "Gilgamesh",
				StessyPower: "Stessy Power",
				Felis: "Felis",
				V4nc3: "V4nc3",
				Ramses: "Ramses",
				GuyGambler: "Guy Gambler",
				DocWissen: "Doc Wissen",
				BaronGoro: "Baron Goro",
				Ivan: "Ivan",
				Br4dbury: "Br4dbury",
				F4rm3r: "F4rm3r",
				Zenon: "Zenon",
				Bish0p: "Bish0p",
				Wul: "Wul",
				Th0mps0n: "Th0mps0n",
				Domitian: "Domitian",
				MasterDin: "Master Din",
				LordCreep: "Lord Creep",
				Amytis: "Amytis",
				W4ts0n: "W4ts0n",
				Arnulf: "Arnulf",
				R0bins0n: "R0bins0n",
				QueenSuzanne: "Queen Suzanne",
				H4milt0n: "H4milt0n",
				Caesar: "Caesar",
				IldaFlores: "Ilda Flores",
				H3rb3rt: "H3rb3rt",
				LisaCharity: "Lisa Charity",
				SirSam: "Sir Sam",
				HiroshiSun: "Hiroshi Sun",
				Magellan: "Magellan",
				Bajazet: "Bajazet",
				Geta: "Geta",
				Charlemagne: "Charlemagne",
				Caligula: "Caligula",
				Tiberius: "Tiberius",
				And3rs0n: "And3rs0n",
				Orw3ll: "Orw3ll",
				As1m0v: "As1m0v",
				HelenaKerr: "Helena Kerr",
				LittleBob: "Little Bob",
				Bruss0l0: "Bruss0l0",
				B4rj4v3l: "B4rj4v3l",
				Augustus: "Augustus",
				LulaSmart: "Lula Smart",
				CharlizeGun: "Charlize Gun",
				ProfessorZed: "Professor Zed",
				IceJune: "Ice June",
				V4nV0gt: "V4n V0gt",
				KingHarold: "King Harold",
				Geronimo: "Geronimo",
				W3lls: "W3lls",
				Nero: "Nero",
				Cl4rke: "Cl4rke",
				Chaka: "Chaka",
				M4rt1n: "M4rt1n",
				Pachacuti: "Pachacuti",
				Gibs0n: "Gibs0n",
				HandyLuke: "Handy Luke",
				Khan: "Khan",
				Moussa: "Moussa",
				Archimedes: "Archimedes",
				SneakyJules: "Sneaky Jules",
				SecretKali: "Secret Kali",
				CaptainAndreev: "Captain Andreev",
				MiladyJones: "Milady Jones",
				AdmiralJack: "Admiral Jack",
				Mungo: "Mungo",
				S1mmons: "S1mmons",
				W1ll1s: "W1ll1s",
				PrincessUxmal: "Princess Uxmal",
				CelestinPetit: "Celestin Petit",
				Ragnar: "Ragnar",
				DandyMuller: "Dandy Muller",
				Boull3: "Boull3",
				Demetrios: "Demetrios"
			}
		},
		en: {
			name: "Zenith",
			desc: "Recruit agents and develop technology to win the struggle for five planets.",
			rules: "Goal:\nRecruit agents, develop technology and become the Leader to gain planetary influence. Immediately win by collecting three discs from one planet, four discs from different planets, or any five discs. Stop immediately, even during an unresolved effect.\nSetup:\nEach side starts with 12 Credits and one Zenithium. Deal four secret cards to each player. Each player may discard any number and draw the same number once. The second player starts with one Terra Influence. Choose the recommended S.U.N. technology boards or randomize the three double-sided boards. Place one random face-up bonus on each planet and each technology track; remaining bonuses form a face-down reserve.\nTurn action:\nUse one hand card for one of the following actions, then complete end-of-turn steps.\n· Recruit an Agent: Add the card to its planet column. Pay its printed Credit cost minus the number of cards previously in that column, to a minimum of zero. Resolve effects from left to right.\n· Develop a Technology: Discard a card and advance its faction's technology one level, paying Zenithium equal to the new level. Resolve the new level and all previous levels, from highest to lowest.\n· Become the Leader: Discard a card and take the badge. Humans also gain three Credits; Robots gain one Zenithium; Animods mobilize two cards. Upgrade your silver badge to gold. Your gold badge stays gold. Taking the opponent's badge normally gives its silver side, unless the effect explicitly grants gold.\nInfluence and bonuses:\nEach disc takes four steps from the center to your control zone. Influence pulls it toward your side; some effects push it toward your opponent. Capture a disc immediately when it enters a control zone. The first capture of each planet also grants its face-up bonus. Its recipient immediately resolves and discards that bonus, which is never replaced. Captured discs are replaced at the end of the current player's turn; excess movement is lost. Your action may let an opponent capture a disc or win. That opponent chooses targets for their bonus.\nTechnology bonuses:\nThe first side reaching level two on a track resolves its bonus after the level-two effects and before level one. Developing all three tracks to levels one, two and three grants one, two and three Influence respectively, all on one chosen planet. Each row bonus is earned once per side, after the technology effects.\nAgent effects:\n· Mobilize: Reveal the top deck card and add it to its planet column without paying or activating effects.\n· Exile: Discard the top card of the specified column.\n· Transfer: Move the opponent's top column card to your matching column without activating effects.\nEach removed card exposes the next available target. A newly recruited card can target itself. Capturing a planet does not discard its column.\nOptional exchanges require the full cost to receive the reward; you may decline the entire exchange. Otherwise resolve as much as possible and ignore impossible effects. Effects exiling two, four or seven matching cards allow one listed tier. Influence purchased as freely distributable points may be divided as prompted. Respect restrictions requiring different or adjacent planets. Conditions based on resources, the badge or technology are checked when that effect resolves.\nEnd of turn:\nRefill to four cards normally, five with your side's silver badge, or six with gold. Keep excess cards and draw none. Replace captured planetary discs in the center. Shuffle the corresponding discard whenever the agent deck or bonus reserve runs out. Credits, Zenithium and influence discs are unlimited.\nAdditional rule: If you start a turn with no cards in hand, skip the action, attempt to refill normally, and pass play to the next player. If every hand, the agent deck and the agent discard are empty, the game ends in a draw.\nFour-player teams:\nForm two teams of two. The host may adjust teams and roles before play. The technology-side teammate may recruit only on Mercury, Venus and Terra; the diplomacy-side teammate only on Terra, Mars and Jupiter. This only restricts recruitment: any card can develop technology or become the Leader. Share resources, columns, technologies, discs and the badge. Hands remain private. Discuss openly, but never show your hand to your teammate. The second team starts with one Venus and one Mars Influence instead of Terra compensation.\nTeams alternate. Each team agrees which teammate takes their complete turn first, then the other teammate takes a complete turn. Becoming the Leader also allows giving up to two remaining hand cards to your teammate before refilling your own hand. A victory condition immediately wins for the whole team.\nSecret Agents:\nWhen enabled, shuffle ten additional agents into the deck: five cost zero and five cost five. Effects can refill both sides' resources to specified amounts, reward the opponent's resources or badge, or develop your lowest technology at its normal cost. Choose among tied lowest tracks. A track at level five cannot develop further.",
			resultPlanet: "Planet discs",
			finished: "Game over",
			science: "Technology",
			reviewBoard: "Review the board",
			restoreResult: "Show results",
			winningDiscs: "Winning disc combination",
			totalDiscs: "Total discs",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			mode: "Game mode",
			duel: "2-player duel",
			team: "4-player teams",
			expansion: "Secret Agents",
			technology: "Technology boards",
			sun: "S.U.N. recommended",
			random: "Random sides",
			planets: {
				mercury: "Mercury",
				venus: "Venus",
				terra: "Terra",
				mars: "Mars",
				jupiter: "Jupiter"
			},
			factions: {
				animod: "Animod",
				human: "Human",
				robot: "Robot"
			},
			teams: "Teams and roles",
			teamNumber: "Team {{n}}",
			techRole: "Technology side",
			diplomacyRole: "Diplomacy side",
			swapHint: "Select two players to swap their positions.",
			start: "Confirm teams",
			yourTurn: "Your turn",
			waiting: "Waiting for {{name}}",
			resolving: "Resolving effects",
			turn: "Turn {{n}}",
			mulligan: "Select cards to replace, then confirm.",
			mulliganDone: "Hand confirmed. Waiting for other players.",
			keep: "Keep all cards",
			replace: "Replace {{n}} cards",
			emptyHand: "No cards in hand. Refill and skip this turn.",
			pass: "Refill and skip",
			draw: "Draw",
			drawReason: "Every hand is empty and no cards remain to refill.",
			order: "Choose the teammate who acts first this round.",
			goFirst: "{{name}} acts first",
			waitOrder: "Waiting for the other team to choose turn order",
			yourChoice: "Choose an effect target",
			waitChoice: "Waiting for {{name}} to choose",
			choose: "Choose target",
			hand: "Your hand",
			select: "Select a hand card",
			recruit: "Recruit an Agent",
			develop: "Develop Technology",
			leader: "Become the Leader",
			recruitCost: "Recruit · {{n}} Credits",
			developCost: "Develop · {{n}} Zenithium",
			leaderAction: "Become Leader",
			credits: "Credits",
			zenithium: "Zenithium",
			handCount: "{{n}} hand cards",
			deckCount: "Deck {{n}}",
			silver: "Silver Leader · Refill to 5",
			gold: "Gold Leader · Refill to 6",
			noLeader: "Leader badge",
			discs: "Captured planetary discs",
			discCount: "{{n}} discs",
			emptyColumn: "No agents yet",
			columnCount: "{{n}} cards",
			column: "{{planet}} column",
			history: "Game history",
			discard: "Discard pile",
			details: "Card details",
			effects: "Card effects",
			close: "Close",
			techTrack: "{{faction}} technology · {{board}}",
			level: "Level {{n}}",
			currentLevel: "Yours {{own}} · Opponent {{enemy}}",
			levelCost: "{{n}} Zenithium",
			bonus: "Bonus",
			firstBonus: "First capture bonus",
			techBonus: "First to level 2",
			chooseBonus: "Take this bonus",
			skip: "Decline",
			continue: "Resolve effect",
			optionQuantity: "{{n}}",
			optionPlanet: "{{planet}} · {{n}} Influence",
			optionCards: "{{planet}} · Exile {{n}} cards",
			optionSpend: "Pay {{n}}",
			optionTech: "{{faction}} · {{n}} Zenithium",
			giveCard: "Give teammate: {{card}}",
			pattern: "Adjacent: {{planets}}",
			left: "Choose left effects",
			right: "Choose right effects",
			recruitRestricted: "This planet is outside your recruitment area.",
			insufficient: "You do not have the resources for this action.",
			maximum: "This technology is at its highest level.",
			victory: "Team {{n}} wins",
			absolute: "Absolute victory · 3 matching",
			democratic: "Democratic victory · 4 different",
			popular: "Popular victory · any 5",
			again: "Play again",
			lobby: "Back to lobby",
			waitHost: "Waiting for the host",
			teamMembers: "{{names}}",
			effectsText: {
				influence: "Gain {{n}} Influence on {{target}}",
				giveInfluence: "Give your opponent {{n}} Influence on {{target}}",
				reset: "Reset one planetary disc to the center",
				any: "any one planet",
				except: "one planet except {{planet}}",
				different: "a planet not chosen earlier",
				center: "a planet whose disc is centered",
				enemySide: "a planet whose disc is on your opponent's side",
				flexible: "Gain {{n}} freely distributable Influence",
				pattern: "Gain {{amounts}} Influence on {{n}} adjacent planets respectively",
				surrounding: "Gain 2 Influence on any planet and 1 Influence on each of its adjacent planets",
				credits: "Gain {{n}} Credits",
				zenithium: "Gain {{n}} Zenithium",
				enemy: "Opponent: {{effect}}",
				upToCredits: "Refill Credits to {{n}}",
				upToZenithium: "Refill Zenithium to {{n}}",
				colorCredits: "Gain {{n}} Credits per different planet color in your columns",
				enemyColorCredits: "Gain {{n}} Credits per different planet color in your opponent's columns",
				techCredits: "Gain {{amounts}} Credits for one, two or three developed level-one technologies",
				techZenithium: "Gain {{amounts}} Zenithium for one, two or three developed level-one technologies",
				giveCredits: "Give your opponent {{n}} Credits",
				giveZenithium: "Give your opponent {{n}} Zenithium",
				spendCredits: "Spend {{amounts}} Credits",
				spendZenithium: "Spend {{amounts}} Zenithium",
				stealCredits: "Take up to {{n}} Credits from your opponent",
				stealZenithium: "Take up to {{n}} Zenithium from your opponent",
				mobilize: "Mobilize {{n}} cards",
				exile: "Exile {{n}} top cards from {{owner}} {{target}} columns",
				transfer: "Transfer {{n}} top cards from your opponent's {{target}} columns",
				own: "your",
				opponent: "your opponent's",
				anyColumn: "any planet",
				exceptColumn: "planets except {{planet}}",
				differentColumn: "a previously unchosen planet",
				scaleExile: "Exile {{amounts}} top cards from your {{target}} column",
				discard: "Discard one hand card",
				discardAll: "Discard your whole hand",
				leader: "Take the Leader badge",
				gold: "Take the gold Leader badge",
				giveLeader: "Give the Leader badge to your opponent",
				develop: "Develop {{faction}} technology",
				anyTech: "any one",
				lowestTech: "your lowest",
				free: "{{effect}} without paying Zenithium",
				discount: "{{effect}} with a {{n}} Zenithium discount",
				bonus: "Draw and resolve a random bonus",
				visibleBonus: "Choose and resolve one face-up board bonus",
				techBonus: "Resolve this track's bonus if first to level two",
				share: "You may give your teammate up to {{n}} hand cards",
				choice: "{{left}}; OR {{right}}",
				pay: "You may {{cost}}, then {{effect}}",
				mustPay: "{{cost}}, then {{effect}}",
				ifLeader: "If you hold the Leader badge, {{effect}}",
				ifCredits: "If you have at least {{n}} Credits, {{effect}}",
				ifEnemyCredits: "If your opponent has at least {{n}} Credits, {{effect}}",
				ifEnemyZenithium: "If your opponent has at least {{n}} Zenithium, {{effect}}",
				ifEnemyLeader: "If your opponent holds the Leader badge, {{effect}}",
				derived: "the selected card's printed cost in",
				derivedInfluence: "the selected card's planet",
				scalingReward: "{{effect}} (gain {{amounts}} according to the selected tier)",
				derivedCredits: "Gain Credits equal to the selected card's printed cost",
				derivedZenithium: "Gain Zenithium equal to the selected card's printed cost"
			},
			log: {
				pass: "{{name}} had no hand cards, attempted to refill and skipped the turn",
				recruit: "{{name}} recruited {{card}} for {{n}} Credits",
				develop: "{{name}} developed {{faction}} technology to level {{n}}",
				leader: "{{name}} took the Leader badge, refilling to {{n}}",
				influence: "{{name}} gained {{n}} Influence on {{planet}}",
				reset: "{{name}} reset {{planet}} to the center",
				capture: "{{name}} captured a {{planet}} disc",
				credits: "{{name}} gained {{n}} Credits",
				zenithium: "{{name}} gained {{n}} Zenithium",
				exile: "{{name}} exiled {{card}}",
				transfer: "{{name}} transferred {{card}}",
				mobilize: "{{name}} mobilized {{card}}",
				discard: "{{name}} discarded {{card}}",
				bonus: "{{name}} gained a bonus: {{effect}}",
				give: "{{name}} gave the opponent {{n}} {{resource}}",
				giveCard: "{{name}} gave a teammate one hand card",
				giveLeader: "{{name}} gave away the Leader badge",
				mulligan: "{{name}} replaced {{n}} cards"
			},
			errors: { illegal: "That action is unavailable. Please choose again." },
			agents: {
				Elisabeth: "Elisabeth",
				Pkd1ck: "Pkd1ck",
				AgentEzra: "Agent Ezra",
				DonaldSmooth: "Donald Smooth",
				Huxl3y: "Huxl3y",
				Titus: "Titus",
				Mc4ffr3y: "Mc4ffr3y",
				Luc4s: "Luc4s",
				Cresus: "Cresus",
				Atlas: "Atlas",
				PunkMari: "Punk Mari",
				Septimus: "Septimus",
				DoubleJoe: "Double Joe",
				DonDune: "Don Dune",
				V3rn3: "V3rn3",
				Ch4mb3rs: "Ch4mb3rs",
				Buj0ld: "Buj0ld",
				JackCurry: "Jack Curry",
				C1x1n: "C1x1n",
				LadyMoore: "Lady Moore",
				L0v3cr4ft: "L0v3cr4ft",
				Suleiman: "Suleiman",
				Annie: "Annie",
				M4th3s0n: "M4th3s0n",
				Gilgamesh: "Gilgamesh",
				StessyPower: "Stessy Power",
				Felis: "Felis",
				V4nc3: "V4nc3",
				Ramses: "Ramses",
				GuyGambler: "Guy Gambler",
				DocWissen: "Doc Wissen",
				BaronGoro: "Baron Goro",
				Ivan: "Ivan",
				Br4dbury: "Br4dbury",
				F4rm3r: "F4rm3r",
				Zenon: "Zenon",
				Bish0p: "Bish0p",
				Wul: "Wul",
				Th0mps0n: "Th0mps0n",
				Domitian: "Domitian",
				MasterDin: "Master Din",
				LordCreep: "Lord Creep",
				Amytis: "Amytis",
				W4ts0n: "W4ts0n",
				Arnulf: "Arnulf",
				R0bins0n: "R0bins0n",
				QueenSuzanne: "Queen Suzanne",
				H4milt0n: "H4milt0n",
				Caesar: "Caesar",
				IldaFlores: "Ilda Flores",
				H3rb3rt: "H3rb3rt",
				LisaCharity: "Lisa Charity",
				SirSam: "Sir Sam",
				HiroshiSun: "Hiroshi Sun",
				Magellan: "Magellan",
				Bajazet: "Bajazet",
				Geta: "Geta",
				Charlemagne: "Charlemagne",
				Caligula: "Caligula",
				Tiberius: "Tiberius",
				And3rs0n: "And3rs0n",
				Orw3ll: "Orw3ll",
				As1m0v: "As1m0v",
				HelenaKerr: "Helena Kerr",
				LittleBob: "Little Bob",
				Bruss0l0: "Bruss0l0",
				B4rj4v3l: "B4rj4v3l",
				Augustus: "Augustus",
				LulaSmart: "Lula Smart",
				CharlizeGun: "Charlize Gun",
				ProfessorZed: "Professor Zed",
				IceJune: "Ice June",
				V4nV0gt: "V4n V0gt",
				KingHarold: "King Harold",
				Geronimo: "Geronimo",
				W3lls: "W3lls",
				Nero: "Nero",
				Cl4rke: "Cl4rke",
				Chaka: "Chaka",
				M4rt1n: "M4rt1n",
				Pachacuti: "Pachacuti",
				Gibs0n: "Gibs0n",
				HandyLuke: "Handy Luke",
				Khan: "Khan",
				Moussa: "Moussa",
				Archimedes: "Archimedes",
				SneakyJules: "Sneaky Jules",
				SecretKali: "Secret Kali",
				CaptainAndreev: "Captain Andreev",
				MiladyJones: "Milady Jones",
				AdmiralJack: "Admiral Jack",
				Mungo: "Mungo",
				S1mmons: "S1mmons",
				W1ll1s: "W1ll1s",
				PrincessUxmal: "Princess Uxmal",
				CelestinPetit: "Celestin Petit",
				Ragnar: "Ragnar",
				DandyMuller: "Dandy Muller",
				Boull3: "Boull3",
				Demetrios: "Demetrios"
			}
		}
	}
};
//#endregion
export { Vt as default };
