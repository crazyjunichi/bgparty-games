import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { botAvatarOf as r } from "@bgparty/sdk/lobby";
import { AVATARS as i } from "@bgparty/sdk/avatars";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as o, useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { IconCheck as l, IconRotate as u } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, FlySprite as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
//#region src/games/skyteam/meta.ts
var x = {
	id: "skyteam",
	tier: "beta",
	mechanics: ["dice-rolling"],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.skyteam.name",
	descKey: "games.skyteam.desc",
	rulesKey: "games.skyteam.rules",
	icon: "✈️",
	iconImg: "games/skyteam.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/skyteam/en.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#0284c7",
	releasedAt: "2026-09-15",
	search: {
		py: "tian he xiao dui",
		init: "thxd"
	},
	hotseat: "cover"
}, S = [
	"axisBlue",
	"axisOrange",
	"engineBlue",
	"engineOrange",
	"radio0",
	"radio1",
	"radio2",
	"gear0",
	"gear1",
	"gear2",
	"flap0",
	"flap1",
	"flap2",
	"flap3",
	"brake0",
	"brake1",
	"brake2",
	"coffee0",
	"coffee1",
	"coffee2"
], C = t.string(), w = t.int().min(1).max(6), T = t.discriminatedUnion("type", [
	t.object({ type: t.literal("ready") }),
	t.object({
		type: t.literal("place"),
		slot: t.enum(S),
		die: t.int().min(0).max(3),
		coffee: t.int().min(-3).max(3).default(0)
	}),
	t.object({ type: t.literal("rerollToken") }),
	t.object({
		type: t.literal("reroll"),
		dice: t.array(t.int().min(0).max(3)).min(1).max(4)
	})
]), E = t.object({ swapRoles: t.boolean().catch(!1) }).default({ swapRoles: !1 }), D = t.object({
	side: t.enum(["blue", "orange"]),
	value: w
}), O = t.object({
	phase: t.enum([
		"discuss",
		"place",
		"done"
	]),
	round: t.int().min(1).max(7),
	pilot: C,
	copilot: C,
	ready: t.array(C),
	turn: C.nullable(),
	altitudeIdx: t.int().min(0).max(6),
	positionIdx: t.int().min(0).max(6),
	planes: t.tuple([
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative()
	]),
	axis: t.int().min(-2).max(2),
	aeroBlue: t.int(),
	aeroOrange: t.int(),
	gears: t.tuple([
		t.boolean(),
		t.boolean(),
		t.boolean()
	]),
	flaps: t.int().min(0).max(4),
	brakes: t.int().min(0).max(3),
	coffee: t.int().min(0).max(3),
	rerollSupply: t.int().min(0).max(3),
	slots: t.record(t.enum(S), D.nullable()),
	result: t.enum(["win", "lose"]).nullable(),
	loseReason: t.string().nullable()
}), k = t.object({
	dice: t.tuple([
		w.nullable(),
		w.nullable(),
		w.nullable(),
		w.nullable()
	]),
	rerollCredit: t.int().nonnegative()
}), A = [
	"6000",
	"5000",
	"4000",
	"3000",
	"2000",
	"1000",
	"✈"
], j = /* @__PURE__ */ new Set([0, 4]), M = [
	0,
	2,
	4,
	6
], N = { yul: { planes: [
	0,
	0,
	1,
	2,
	1,
	3,
	2
] } }, P = {
	axisBlue: { side: "blue" },
	axisOrange: { side: "orange" },
	engineBlue: { side: "blue" },
	engineOrange: { side: "orange" },
	radio0: { side: "blue" },
	radio1: { side: "orange" },
	radio2: { side: "orange" },
	gear0: {
		side: "blue",
		min: 1,
		max: 2
	},
	gear1: {
		side: "blue",
		min: 3,
		max: 4
	},
	gear2: {
		side: "blue",
		min: 5,
		max: 6
	},
	flap0: {
		side: "orange",
		min: 1,
		max: 2
	},
	flap1: {
		side: "orange",
		min: 2,
		max: 3
	},
	flap2: {
		side: "orange",
		min: 4,
		max: 5
	},
	flap3: {
		side: "orange",
		min: 5,
		max: 6
	},
	brake0: {
		side: "blue",
		min: 2,
		max: 2
	},
	brake1: {
		side: "blue",
		min: 4,
		max: 4
	},
	brake2: {
		side: "blue",
		min: 6,
		max: 6
	},
	coffee0: { side: "both" },
	coffee1: { side: "both" },
	coffee2: { side: "both" }
}, F = (e) => ({ code: e }), I = (e, t) => t === e.pilot ? "blue" : "orange", L = (e, t) => t === e.pilot ? e.copilot : e.pilot, ee = (e) => e.round % 2 == 1 ? e.pilot : e.copilot;
function te(t) {
	for (let n of [t.pilot, t.copilot]) t.dice[n] = [
		0,
		1,
		2,
		3
	].map(() => e(t.seed, t.rngCursor++, 6) + 1);
}
function R(e, t) {
	e.phase = "done", e.result = "lose", e.loseReason = t;
}
function ne(e, t) {
	let n = e.slots.engineBlue.value + e.slots.engineOrange.value;
	if (e.round === 7) {
		n > M[e.brakes] && (R(e, "games.skyteam.loseSpeed"), t.push({
			kind: "crash",
			data: { reason: "speed" }
		}));
		return;
	}
	let r = n * 2 < e.aeroBlue ? 0 : n * 2 > e.aeroOrange ? 2 : 1;
	if (r !== 0) {
		if (e.planes[e.positionIdx] > 0) {
			R(e, "games.skyteam.loseCollision"), t.push({
				kind: "crash",
				data: { reason: "collision" }
			});
			return;
		}
		if (e.positionIdx >= 6) {
			R(e, "games.skyteam.loseOverrun"), t.push({
				kind: "crash",
				data: { reason: "overrun" }
			});
			return;
		}
		e.positionIdx = Math.min(6, e.positionIdx + r), t.push({
			kind: "advance",
			data: {
				steps: r,
				to: e.positionIdx
			}
		});
	}
}
function re(e, t) {
	let n = e.slots.axisBlue.value, r = e.slots.axisOrange.value;
	n !== r && (e.axis += n > r ? n - r : -(r - n), t.push({
		kind: "tilt",
		data: { axis: e.axis }
	}), Math.abs(e.axis) >= 3 && (R(e, "games.skyteam.loseAxis"), t.push({
		kind: "crash",
		data: { reason: "axis" }
	})));
}
function ie(e, t) {
	let { axisBlue: n, axisOrange: r, engineBlue: i, engineOrange: a } = e.slots;
	if (!n || !r || !i || !a) {
		R(e, "games.skyteam.loseMissing"), t.push({
			kind: "crash",
			data: { reason: "missing" }
		});
		return;
	}
	if (e.round === 7) {
		e.planes.some((e) => e > 0) ? (R(e, "games.skyteam.loseTraffic"), t.push({
			kind: "crash",
			data: { reason: "traffic" }
		})) : !e.gears.every(Boolean) || e.flaps < 4 ? (R(e, "games.skyteam.loseConfig"), t.push({
			kind: "crash",
			data: { reason: "config" }
		})) : e.axis === 0 ? (e.phase = "done", e.result = "win", t.push({ kind: "land" })) : (R(e, "games.skyteam.loseLevel"), t.push({
			kind: "crash",
			data: { reason: "level" }
		}));
		return;
	}
	if (j.has(e.altitudeIdx) && e.rerollSupply < 3 && (e.rerollSupply += 1, t.push({ kind: "token" })), e.altitudeIdx += 1, e.altitudeIdx === 6 && e.positionIdx < 6) {
		R(e, "games.skyteam.loseAltitude"), t.push({
			kind: "crash",
			data: { reason: "altitude" }
		});
		return;
	}
	e.round += 1, e.phase = "discuss", e.ready = [], e.turn = null, e.slots = {}, e.placed = 0, e.dice = {
		[e.pilot]: [
			null,
			null,
			null,
			null
		],
		[e.copilot]: [
			null,
			null,
			null,
			null
		]
	}, e.rerollCredit = {
		[e.pilot]: 0,
		[e.copilot]: 0
	};
}
function ae(e, t, n) {
	let r = e.swapRoles ? t[1] : t[0], i = e.swapRoles ? t[0] : t[1];
	return { state: {
		seed: n,
		rngCursor: 0,
		pilot: r,
		copilot: i,
		phase: "discuss",
		round: 1,
		ready: [],
		turn: null,
		altitudeIdx: 0,
		positionIdx: 0,
		planes: [...N.yul.planes],
		axis: 0,
		aeroBlue: 9,
		aeroOrange: 17,
		gears: [
			!1,
			!1,
			!1
		],
		flaps: 0,
		brakes: 0,
		coffee: 0,
		rerollSupply: 0,
		rerollCredit: {
			[r]: 0,
			[i]: 0
		},
		dice: {
			[r]: [
				null,
				null,
				null,
				null
			],
			[i]: [
				null,
				null,
				null,
				null
			]
		},
		slots: {},
		placed: 0,
		result: null,
		loseReason: null
	} };
}
function oe(t, n, r) {
	if (t.phase === "done") return F("games.skyteam.errDone");
	if (r.by !== t.pilot && r.by !== t.copilot) return F("games.skyteam.errNotPlayer");
	if (n.type === "ready") {
		if (t.phase !== "discuss" || t.ready.includes(r.by)) return F("games.skyteam.errPhase");
		let e = structuredClone(t);
		return e.ready.push(r.by), e.ready.length < 2 ? {
			state: e,
			fx: []
		} : (te(e), e.phase = "place", e.turn = ee(e), {
			state: e,
			fx: [e.pilot, e.copilot].map((t, n) => ({
				kind: "roll",
				rid: t,
				data: { round: e.round },
				for: [t],
				secret: { dice: e.dice[t] },
				...n > 0 ? { with: !0 } : {}
			}))
		});
	}
	if (n.type === "rerollToken") {
		if (t.phase !== "place") return F("games.skyteam.errPhase");
		if (t.rerollSupply <= 0) return F("games.skyteam.errNoToken");
		let e = structuredClone(t);
		return --e.rerollSupply, e.rerollCredit[e.pilot] += 1, e.rerollCredit[e.copilot] += 1, {
			state: e,
			fx: [{
				kind: "rerollToken",
				rid: r.by
			}]
		};
	}
	if (n.type === "reroll") {
		if (t.phase !== "place") return F("games.skyteam.errPhase");
		if ((t.rerollCredit[r.by] ?? 0) <= 0) return F("games.skyteam.errNoCredit");
		let i = t.dice[r.by], a = [...new Set(n.dice)];
		if (a.some((e) => i[e] === null || i[e] === void 0)) return F("games.skyteam.errDieUsed");
		let o = structuredClone(t);
		--o.rerollCredit[r.by];
		for (let t of a) o.dice[r.by][t] = e(o.seed, o.rngCursor++, 6) + 1;
		return {
			state: o,
			fx: [{
				kind: "reroll",
				rid: r.by,
				for: [r.by],
				secret: { dice: o.dice[r.by] }
			}]
		};
	}
	if (t.phase !== "place") return F("games.skyteam.errPhase");
	if (r.by !== t.turn) return F("games.skyteam.errTurn");
	let i = P[n.slot], a = I(t, r.by);
	if (i.side !== "both" && i.side !== a) return F("games.skyteam.errSlotSide");
	if (t.slots[n.slot]) return F("games.skyteam.errSlotTaken");
	let o = t.dice[r.by][n.die];
	if (o == null) return F("games.skyteam.errDieUsed");
	if (Math.abs(n.coffee) > t.coffee) return F("games.skyteam.errNoCoffee");
	let s = o + n.coffee;
	if (s < 1 || s > 6) return F("games.skyteam.errCoffeeRange");
	if (i.min !== void 0 && (s < i.min || s > i.max)) return F("games.skyteam.errValue");
	if (n.slot.startsWith("flap") && Number(n.slot.slice(4)) !== t.flaps || n.slot.startsWith("brake") && Number(n.slot.slice(5)) !== t.brakes) return F("games.skyteam.errOrder");
	let c = structuredClone(t);
	c.dice[r.by][n.die] = null, c.coffee -= Math.abs(n.coffee), c.slots[n.slot] = {
		side: a,
		value: s
	}, c.placed += 1;
	let l = [{
		kind: "place",
		rid: r.by,
		data: {
			slot: n.slot,
			value: s,
			side: a
		}
	}];
	if (n.slot.startsWith("coffee")) c.coffee = Math.min(3, c.coffee + 1), l.push({
		kind: "brew",
		with: !0
	});
	else if (n.slot.startsWith("radio")) {
		let e = c.positionIdx + s - 1;
		e <= 6 && c.planes[e] > 0 && (--c.planes[e], l.push({
			kind: "radioClear",
			data: { cell: e },
			with: !0
		}));
	} else if (n.slot.startsWith("gear")) {
		let e = Number(n.slot.slice(4));
		c.gears[e] || (c.gears[e] = !0, c.aeroBlue += 2, l.push({
			kind: "gear",
			data: { index: e },
			with: !0
		}));
	} else n.slot.startsWith("flap") ? (c.flaps += 1, c.aeroOrange += 2, l.push({
		kind: "flap",
		data: { index: c.flaps - 1 },
		with: !0
	})) : n.slot.startsWith("brake") && (c.brakes += 1, l.push({
		kind: "brake",
		data: { index: c.brakes - 1 },
		with: !0
	}));
	return (n.slot === "axisBlue" || n.slot === "axisOrange") && c.slots.axisBlue && c.slots.axisOrange && re(c, l), c.phase !== "done" && (n.slot === "engineBlue" || n.slot === "engineOrange") && c.slots.engineBlue && c.slots.engineOrange && ne(c, l), c.phase !== "done" && (c.turn = L(c, r.by), c.placed >= 8 && ie(c, l)), {
		state: c,
		fx: l
	};
}
function se(e, t) {
	let n = Object.fromEntries(S.map((t) => [t, e.slots[t] ?? null]));
	return {
		public: {
			phase: e.phase,
			round: e.round,
			pilot: e.pilot,
			copilot: e.copilot,
			ready: [...e.ready],
			turn: e.turn,
			altitudeIdx: e.altitudeIdx,
			positionIdx: e.positionIdx,
			planes: [
				e.planes[0],
				e.planes[1],
				e.planes[2],
				e.planes[3],
				e.planes[4],
				e.planes[5],
				e.planes[6]
			],
			axis: e.axis,
			aeroBlue: e.aeroBlue,
			aeroOrange: e.aeroOrange,
			gears: [
				e.gears[0],
				e.gears[1],
				e.gears[2]
			],
			flaps: e.flaps,
			brakes: e.brakes,
			coffee: e.coffee,
			rerollSupply: e.rerollSupply,
			slots: n,
			result: e.result,
			loseReason: e.loseReason
		},
		private: {
			dice: [
				e.dice[t]?.[0] ?? null,
				e.dice[t]?.[1] ?? null,
				e.dice[t]?.[2] ?? null,
				e.dice[t]?.[3] ?? null
			],
			rerollCredit: e.rerollCredit[t] ?? 0
		}
	};
}
function ce(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [e.pilot, e.copilot];
	return {
		phase: "done",
		winner: e.result === "win" ? t : [],
		ranking: t
	};
}
var le = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: x,
	schemas: {
		action: T,
		publicView: O,
		privateView: k,
		config: E
	},
	setup: ae,
	reduce: oe,
	viewFor: se,
	status: ce
};
//#endregion
//#region src/games/skyteam/illustrations.tsx
function z(e) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 48 48",
		fill: "none",
		"aria-hidden": "true",
		...e,
		children: [/* @__PURE__ */ h("path", {
			d: "M24 3c-2 0-3 2-3 5v13L5 29v5l16-4v8l-5 3v4l8-2 8 2v-4l-5-3v-8l16 4v-5l-16-8V8c0-3-1-5-3-5Z",
			fill: "currentColor",
			stroke: "var(--color-ink)",
			strokeWidth: "2",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ h("path", {
			d: "M24 7v29",
			stroke: "white",
			strokeOpacity: ".65",
			strokeWidth: "1.5"
		})]
	});
}
function B(e) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 48 48",
		fill: "none",
		"aria-hidden": "true",
		...e,
		children: [
			/* @__PURE__ */ h("path", {
				d: "M14 4h20l9 40H5L14 4Z",
				fill: "currentColor",
				stroke: "var(--color-ink)",
				strokeWidth: "2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ h("path", {
				d: "M24 7v7m0 5v7m0 5v9",
				stroke: "white",
				strokeWidth: "3",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ h("path", {
				d: "M13 39h22M16 27h16",
				stroke: "white",
				strokeOpacity: ".7",
				strokeWidth: "2"
			})
		]
	});
}
function V({ kind: e, ...t }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		...t,
		children: [
			e === "axis" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("circle", {
				cx: "12",
				cy: "12",
				r: "8"
			}), /* @__PURE__ */ h("path", { d: "M12 2v5m0 10v5M2 12h5m10 0h5M8 15l4-7 4 7-4-2-4 2Z" })] }),
			e === "engine" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("circle", {
					cx: "12",
					cy: "12",
					r: "9"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "12",
					cy: "12",
					r: "2"
				}),
				/* @__PURE__ */ h("path", { d: "M12 10c-1-3 0-5 2-6m0 7c3-1 5 0 6 2m-7 1c1 3 0 5-2 6m0-7c-3 1-5 0-6-2" })
			] }),
			e === "radio" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M12 19v-7m-4 7h8M12 12a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" }), /* @__PURE__ */ h("path", { d: "M6 5a9 9 0 0 0 0 12m12-12a9 9 0 0 1 0 12M9 7a5 5 0 0 0 0 8m6-8a5 5 0 0 1 0 8" })] }),
			e === "gear" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", { d: "M12 3v9m-6 0h12M7 12l-2 5m12-5 2 5" }),
				/* @__PURE__ */ h("circle", {
					cx: "5",
					cy: "19",
					r: "2"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "19",
					cy: "19",
					r: "2"
				})
			] }),
			e === "flap" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M3 8h18l-3 5H6L3 8Zm5 5 2 6h9l-1-6" }), /* @__PURE__ */ h("path", { d: "m11 16 2 2 2-2" })] }),
			e === "brake" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("circle", {
				cx: "12",
				cy: "12",
				r: "8"
			}), /* @__PURE__ */ h("path", { d: "M7 7l10 10M17 7 7 17M3 12h3m12 0h3" })] }),
			e === "coffee" && /* @__PURE__ */ h(m, { children: /* @__PURE__ */ h("path", { d: "M5 9h12v6a5 5 0 0 1-5 5h-2a5 5 0 0 1-5-5V9Zm12 1h2a2 2 0 0 1 0 4h-2M8 3v3m4-3v3m4-3v3" }) })
		]
	});
}
//#endregion
//#region src/games/skyteam/view-player.tsx
function H(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ h(ue, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function U({ value: e, side: t, size: n, dimmed: r, style: i }) {
	return /* @__PURE__ */ h("span", {
		className: "st-die",
		style: i,
		"data-side": t,
		"data-size": n,
		"data-dimmed": r || void 0,
		children: /* @__PURE__ */ h("span", {
			className: "st-die-value",
			children: e
		})
	});
}
function W(e, t, n) {
	if (e === "axisBlue" || e === "engineBlue" || e === "radio0") return t;
	if (e === "axisOrange" || e === "engineOrange" || e === "radio1" || e === "radio2") return n;
	if (e.startsWith("gear") || e.startsWith("flap")) {
		let t = P[e];
		return t.min + "-" + t.max;
	}
	return e.startsWith("brake") ? String(P[e].min) : e.slice(-1);
}
function ue({ pub: e, priv: t, members: r, myRid: i, send: a }) {
	let o = c(), s = (e) => r.find((t) => t.rid === e)?.name ?? e, l = i === e.pilot ? "blue" : "orange", u = e.phase === "place" && e.turn === i, d = e.round === 7, [m, _] = n(null), [v, y] = n(0), [b, S] = n(!1), [C, w] = n([]), [T, E] = n(""), D = String(e.round) + ":" + e.phase;
	D !== T && (E(D), _(null), y(0), S(!1), w([]));
	let O = t && m !== null ? t.dice[m] ?? null : null, k = O === null ? null : O + v, A = (t) => {
		if (!u || k === null || e.slots[t]) return !1;
		let n = P[t];
		return !(n.side !== "both" && n.side !== l || n.min !== void 0 && (k < n.min || k > n.max) || t.startsWith("flap") && Number(t.slice(4)) !== e.flaps || t.startsWith("brake") && Number(t.slice(5)) !== e.brakes);
	}, j = (e) => {
		if (t && t.dice[e] !== null) {
			if (b) {
				w((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
				return;
			}
			u && (_(m === e ? null : e), y(0));
		}
	}, N = (e) => {
		A(e) && m !== null && (a({
			type: "place",
			slot: e,
			die: m,
			coffee: v
		}), _(null), y(0));
	}, F, I;
	if (e.phase === "discuss") {
		let t = e.ready.includes(i), n = i === e.pilot ? e.copilot : e.pilot;
		F = t ? "info" : "accent", I = t ? o("games.skyteam.discussWaiting", { name: s(n) }) : o("games.skyteam.discussPrompt");
	} else e.phase === "place" ? (F = u ? "accent" : "info", I = u ? o("games.skyteam.placeYou") : o("games.skyteam.placeWait", { name: s(e.turn ?? "") })) : (F = e.result === "win" ? "done" : "warn", I = e.result === "win" ? o("games.skyteam.overWin") : o("games.skyteam.overLose"));
	return /* @__PURE__ */ h(f, {
		adaptive: !0,
		scroll: !1,
		className: "st-game",
		actionsHeight: "st-actions",
		banner: /* @__PURE__ */ g("div", {
			className: "st-top",
			children: [/* @__PURE__ */ h(p, {
				tone: F,
				text: I,
				sub: d && e.phase === "place" ? o("games.skyteam.finalHint", { n: M[e.brakes] }) : void 0,
				chip: o("games.skyteam.roundShort", {
					n: e.round,
					total: 7
				}),
				accent: x.accent
			}), /* @__PURE__ */ h(de, {
				pub: e,
				members: r,
				myRid: i
			})]
		}),
		actions: e.phase === "discuss" ? /* @__PURE__ */ h("div", {
			className: "st-dock safe-b st-dock--ready",
			children: /* @__PURE__ */ g("button", {
				type: "button",
				disabled: e.ready.includes(i),
				onClick: () => a({ type: "ready" }),
				className: "btn-base st-ready-button",
				children: [/* @__PURE__ */ h(z, { className: "size-6" }), o("games.skyteam.discussReady")]
			})
		}) : t ? /* @__PURE__ */ h(we, {
			pub: e,
			priv: t,
			mySide: l,
			myTurn: u,
			selDie: m,
			coffee: v,
			adjValue: k,
			rerollMode: b,
			rerollSel: C,
			onPickDie: j,
			onCoffee: y,
			onSpendToken: () => a({ type: "rerollToken" }),
			onToggleReroll: () => {
				S(!b), w([]);
			},
			onConfirmReroll: () => {
				C.length > 0 && a({
					type: "reroll",
					dice: C
				}), S(!1), w([]);
			}
		}) : /* @__PURE__ */ h("div", { className: "st-dock safe-b" }),
		children: /* @__PURE__ */ h("div", {
			className: "st-cockpit",
			children: /* @__PURE__ */ g("div", {
				className: "st-cockpit-inner",
				children: [
					/* @__PURE__ */ h(pe, { pub: e }),
					/* @__PURE__ */ g("div", {
						className: "st-instruments",
						children: [
							/* @__PURE__ */ h(ge, { axis: e.axis }),
							/* @__PURE__ */ h(K, { pub: e }),
							/* @__PURE__ */ h(_e, { pub: e })
						]
					}),
					/* @__PURE__ */ h(xe, {
						pub: e,
						slotLegal: A,
						onPlace: N,
						selected: k !== null
					})
				]
			})
		})
	});
}
function de({ pub: e, members: t, myRid: n }) {
	let i = c(), { locale: a } = s();
	return /* @__PURE__ */ h("div", {
		className: "st-crew",
		children: [e.pilot, e.copilot].map((s) => {
			let c = t.find((e) => e.rid === s), l = s === e.pilot ? "blue" : "orange", u = Object.values(e.slots).filter((e) => e?.side === l).length, d = e.phase === "discuss" ? e.ready.includes(s) ? "done" : "pending" : e.phase === "place" && e.turn === s ? "pending" : null, f = r(s) !== null, p = c ? f ? o(a, c.avatar) : c.name : s;
			return /* @__PURE__ */ g("div", {
				className: "st-crew-member",
				"data-side": l,
				"data-active": d === "pending" || void 0,
				"data-offline": !(!c || c.online) || void 0,
				children: [
					c && /* @__PURE__ */ h(fe, {
						m: c,
						state: d
					}),
					/* @__PURE__ */ g("div", {
						className: "st-crew-copy",
						children: [/* @__PURE__ */ g("p", {
							className: "st-crew-name",
							children: [p, s === n && /* @__PURE__ */ g("span", {
								className: "st-you",
								children: [" · ", i("lobby.you")]
							})]
						}), /* @__PURE__ */ g("p", {
							className: "st-crew-meta",
							children: [/* @__PURE__ */ h("span", {
								className: "st-role",
								children: i(l === "blue" ? "games.skyteam.rolePilot" : "games.skyteam.roleCopilot")
							}), /* @__PURE__ */ h("span", {
								className: "st-dice-left",
								children: i("games.skyteam.diceLeft", { n: 4 - u })
							})]
						})]
					}),
					/* @__PURE__ */ h("span", {
						className: "st-crew-light",
						"aria-hidden": !0
					})
				]
			}, s);
		})
	});
}
function fe({ m: e, state: t }) {
	let { ref: n } = a("seat:" + e.rid), r = d[e.colorIndex % d.length];
	return /* @__PURE__ */ g("span", {
		ref: n,
		className: "st-avatar",
		children: [
			t === "done" && /* @__PURE__ */ h("span", {
				className: "st-avatar-state st-avatar-state--done",
				children: /* @__PURE__ */ h(l, {
					size: 10,
					strokeWidth: 4,
					"aria-hidden": !0
				})
			}),
			t === "pending" && /* @__PURE__ */ h("span", {
				className: "st-avatar-state st-avatar-state--pending",
				"aria-hidden": !0,
				children: "•••"
			}),
			/* @__PURE__ */ h("span", {
				className: "st-avatar-face",
				style: { backgroundColor: r.hex },
				children: /* @__PURE__ */ h("img", {
					src: i[e.avatar % i.length],
					alt: "",
					draggable: !1
				})
			})
		]
	});
}
function pe({ pub: e }) {
	let t = c();
	return /* @__PURE__ */ g("section", {
		className: "st-window",
		"aria-label": t("games.skyteam.approachLabel"),
		children: [
			/* @__PURE__ */ g("div", {
				className: "st-window-sky",
				"aria-hidden": !0,
				children: [
					/* @__PURE__ */ h("i", {}),
					/* @__PURE__ */ h("i", {}),
					/* @__PURE__ */ h("i", {})
				]
			}),
			/* @__PURE__ */ g("div", {
				className: "st-window-heading",
				children: [/* @__PURE__ */ g("span", {
					className: "st-window-title",
					children: [/* @__PURE__ */ h(z, { className: "size-4" }), t("games.skyteam.approachLabel")]
				}), /* @__PURE__ */ g("span", {
					className: "st-window-progress",
					children: [
						e.positionIdx + 1,
						" / ",
						e.planes.length
					]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: "st-route",
				role: "list",
				children: e.planes.map((t, n) => /* @__PURE__ */ h(me, {
					index: n,
					planes: t,
					current: n === e.positionIdx,
					passed: n < e.positionIdx
				}, n))
			})
		]
	});
}
function me({ index: e, planes: t, current: n, passed: r }) {
	let i = c(), { ref: o } = a("track:" + e);
	return /* @__PURE__ */ g("div", {
		ref: o,
		role: "listitem",
		className: "st-route-cell",
		"data-current": n || void 0,
		"data-cleared": r && t === 0 || void 0,
		"data-traffic": t > 0 || void 0,
		"aria-label": i("games.skyteam.trackCellAria", {
			n: e + 1,
			planes: t
		}),
		"aria-current": n ? "step" : void 0,
		children: [
			/* @__PURE__ */ h("span", {
				className: "st-route-node",
				"aria-hidden": !0,
				children: e === 6 ? /* @__PURE__ */ h(B, { className: "st-runway-icon" }) : e === 0 ? /* @__PURE__ */ h("span", {
					className: "st-cloud-icon",
					children: "☁"
				}) : /* @__PURE__ */ h("span", {
					className: "st-route-number",
					children: e + 1
				})
			}),
			t > 0 && /* @__PURE__ */ g("span", {
				className: "st-traffic",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ h(z, { className: "size-3" }), /* @__PURE__ */ g("b", { children: ["×", t] })]
			}),
			n && /* @__PURE__ */ h(he, {})
		]
	});
}
function he() {
	let { ref: e } = a("plane");
	return /* @__PURE__ */ h("span", {
		ref: e,
		className: "st-plane-marker",
		children: /* @__PURE__ */ h(z, { className: "size-6" })
	});
}
function G({ kind: e, label: t }) {
	return /* @__PURE__ */ g("span", {
		className: "st-gauge-heading",
		children: [/* @__PURE__ */ h(V, {
			kind: e,
			className: "size-3.5"
		}), t]
	});
}
function ge({ axis: e }) {
	let t = c(), { ref: n } = a("axis");
	return /* @__PURE__ */ g("div", {
		ref: n,
		className: "st-gauge st-axis",
		"data-danger": Math.abs(e) >= 2 || void 0,
		"aria-label": t("games.skyteam.modAxis"),
		children: [
			/* @__PURE__ */ h(G, {
				kind: "axis",
				label: t("games.skyteam.modAxis")
			}),
			/* @__PURE__ */ g("div", {
				className: "st-axis-dial",
				"aria-hidden": !0,
				children: [
					/* @__PURE__ */ h("div", {
						className: "st-axis-horizon",
						style: { transform: "rotate(" + e * 22 + "deg)" },
						children: /* @__PURE__ */ h("span", {})
					}),
					/* @__PURE__ */ h("span", {
						className: "st-axis-wings",
						children: "⌄"
					}),
					/* @__PURE__ */ h("span", {
						className: "st-axis-cross",
						children: "+"
					})
				]
			}),
			/* @__PURE__ */ h("span", {
				className: "st-axis-readout",
				children: e === 0 ? "●" : e > 0 ? "↗ " + e : "↖ " + Math.abs(e)
			})
		]
	});
}
function K({ pub: e }) {
	let t = c(), { ref: n } = a("speed"), r = e.slots.engineBlue?.value, i = e.slots.engineOrange?.value, o = r !== void 0 && i !== void 0 ? r + i : null, s = (e) => ((e / 2 - 2) / 10 * 100).toFixed(1) + "%";
	return /* @__PURE__ */ g("div", {
		ref: n,
		className: "st-gauge st-speed",
		"aria-label": t("games.skyteam.speedLabel"),
		children: [
			/* @__PURE__ */ g("div", {
				className: "st-speed-head",
				children: [/* @__PURE__ */ h(G, {
					kind: "engine",
					label: t("games.skyteam.speedLabel")
				}), /* @__PURE__ */ h("strong", {
					className: "st-speed-sum",
					children: o === null ? "—" : t("games.skyteam.engineSum", { n: o })
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: "st-speed-track",
				"aria-hidden": !0,
				children: [
					/* @__PURE__ */ h("span", { className: "st-speed-band" }),
					/* @__PURE__ */ h("span", {
						className: "st-speed-marker st-speed-marker--blue",
						style: { left: s(e.aeroBlue) }
					}),
					/* @__PURE__ */ h("span", {
						className: "st-speed-marker st-speed-marker--orange",
						style: { left: s(e.aeroOrange) }
					}),
					e.round === 7 && e.brakes > 0 && /* @__PURE__ */ h("span", {
						className: "st-speed-brake",
						style: { left: s(M[e.brakes] * 2) }
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "st-speed-scale",
				"aria-hidden": !0,
				children: [
					2,
					4,
					6,
					8,
					10,
					12
				].map((e) => /* @__PURE__ */ h("span", { children: e }, e))
			}),
			/* @__PURE__ */ g("div", {
				className: "st-speed-legend",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ h("i", { className: "st-blue-dot" }), /* @__PURE__ */ h("i", { className: "st-orange-dot" })]
			})
		]
	});
}
function _e({ pub: e }) {
	let t = c(), { ref: n } = a("altitude");
	return /* @__PURE__ */ g("div", {
		ref: n,
		className: "st-gauge st-altitude",
		"aria-label": t("games.skyteam.altitudeLabel"),
		children: [/* @__PURE__ */ h(G, {
			kind: "axis",
			label: t("games.skyteam.altitudeLabel")
		}), /* @__PURE__ */ h("div", {
			className: "st-altitude-steps",
			children: A.map((t, n) => /* @__PURE__ */ g("span", {
				className: "st-altitude-step",
				"data-current": n === e.altitudeIdx || void 0,
				"data-passed": n < e.altitudeIdx || void 0,
				children: [/* @__PURE__ */ h("b", { children: t }), (n === 0 || n === 4) && e.altitudeIdx <= n && /* @__PURE__ */ h(u, {
					size: 10,
					"aria-hidden": !0
				})]
			}, t))
		})]
	});
}
var q = {
	axis: "games.skyteam.modAxis",
	engine: "games.skyteam.modEngine",
	radio: "games.skyteam.modRadio",
	gear: "games.skyteam.modGear",
	flap: "games.skyteam.modFlap",
	brake: "games.skyteam.modBrake",
	coffee: "games.skyteam.modCoffee"
};
function ve(e) {
	return e.replace(/[0-9]|Blue|Orange/g, "");
}
function ye(e) {
	let t = P[e];
	return t.min === void 0 ? "1–6" : t.min === t.max ? String(t.min) : t.min + "–" + t.max;
}
function be(e, t) {
	return t.startsWith("gear") ? e.gears[Number(t.slice(4))] : t.startsWith("flap") ? Number(t.slice(4)) < e.flaps : t.startsWith("brake") ? Number(t.slice(5)) < e.brakes : !1;
}
function xe({ pub: e, slotLegal: t, onPlace: n, selected: r }) {
	let i = c(), a = i("games.skyteam.rolePilot"), o = i("games.skyteam.roleCopilot"), s = (s) => /* @__PURE__ */ h(Ce, {
		slot: s,
		placed: e.slots[s],
		legal: t(s),
		selected: r,
		activated: be(e, s),
		label: i("games.skyteam.slotAria", {
			mod: i(q[ve(s)]),
			spec: W(s, a, o)
		}),
		onPlace: n
	}, s), l = (e, t) => /* @__PURE__ */ g("div", {
		className: "st-module-row",
		children: [/* @__PURE__ */ g("span", {
			className: "st-module-label",
			children: [/* @__PURE__ */ h(V, {
				kind: e,
				className: "size-4"
			}), /* @__PURE__ */ h("b", { children: i(q[e]) })]
		}), /* @__PURE__ */ h("span", {
			className: "st-module-slots",
			children: t.map(s)
		})]
	}, e);
	return /* @__PURE__ */ g("section", {
		className: "st-console",
		children: [
			/* @__PURE__ */ g("div", {
				className: "st-console-heading",
				children: [
					/* @__PURE__ */ g("span", {
						className: "st-console-role",
						"data-side": "blue",
						children: [/* @__PURE__ */ h("b", { children: "01" }), a]
					}),
					/* @__PURE__ */ g("span", {
						className: "st-console-role",
						"data-side": "orange",
						children: [/* @__PURE__ */ h("b", { children: "02" }), o]
					}),
					/* @__PURE__ */ h(Se, { pub: e })
				]
			}),
			l("axis", ["axisBlue", "axisOrange"]),
			l("engine", ["engineBlue", "engineOrange"]),
			l("radio", [
				"radio0",
				"radio1",
				"radio2"
			]),
			l("gear", [
				"gear0",
				"gear1",
				"gear2"
			]),
			l("flap", [
				"flap0",
				"flap1",
				"flap2",
				"flap3"
			]),
			l("brake", [
				"brake0",
				"brake1",
				"brake2"
			]),
			l("coffee", [
				"coffee0",
				"coffee1",
				"coffee2"
			])
		]
	});
}
function Se({ pub: e }) {
	let { ref: t } = a("coffeePool");
	return /* @__PURE__ */ g("span", {
		ref: t,
		className: "st-supply",
		children: [
			/* @__PURE__ */ h("span", {
				className: "st-supply-cups",
				"aria-hidden": !0,
				children: [
					0,
					1,
					2
				].map((t) => /* @__PURE__ */ h(V, {
					kind: "coffee",
					className: "size-3.5",
					"data-full": t < e.coffee || void 0
				}, t))
			}),
			/* @__PURE__ */ h("b", {
				className: "st-supply-count",
				children: e.coffee
			}),
			/* @__PURE__ */ h("span", { className: "st-supply-separator" }),
			/* @__PURE__ */ h(u, {
				size: 14,
				"aria-hidden": !0
			}),
			/* @__PURE__ */ h("b", {
				className: "st-supply-count",
				children: e.rerollSupply
			})
		]
	});
}
function Ce({ slot: e, placed: t, legal: n, selected: r, activated: i, label: o, onPlace: s }) {
	let { ref: c } = a("slot:" + e);
	return /* @__PURE__ */ g("button", {
		ref: c,
		type: "button",
		disabled: !n,
		"aria-label": o,
		onClick: () => s(e),
		className: "st-slot",
		"data-legal": n || void 0,
		"data-selected": r || void 0,
		"data-filled": !!t || void 0,
		"data-activated": i || void 0,
		"data-side": P[e].side,
		children: [
			/* @__PURE__ */ h("span", {
				className: "st-slot-side",
				"aria-hidden": !0,
				children: P[e].side === "blue" ? "01" : P[e].side === "orange" ? "02" : "↔"
			}),
			t ? /* @__PURE__ */ h(U, {
				value: t.value,
				side: t.side,
				size: "slot"
			}) : /* @__PURE__ */ h("span", {
				className: "st-slot-range",
				children: ye(e)
			}),
			i && /* @__PURE__ */ h("span", {
				className: "st-slot-check",
				children: /* @__PURE__ */ h(l, {
					size: 10,
					strokeWidth: 4,
					"aria-hidden": !0
				})
			})
		]
	});
}
function we({ pub: e, priv: t, mySide: n, myTurn: r, selDie: i, coffee: o, adjValue: s, rerollMode: l, rerollSel: d, onPickDie: f, onCoffee: p, onSpendToken: _, onToggleReroll: v, onConfirmReroll: y }) {
	let b = c(), { ref: x } = a("dice"), S = i === null ? null : t.dice[i], C = S !== null && o > -Math.min(e.coffee, S - 1), w = S !== null && o < Math.min(e.coffee, 6 - S);
	return /* @__PURE__ */ g("div", {
		className: "st-dock safe-b",
		"data-reroll": l || void 0,
		children: [
			l && /* @__PURE__ */ h("span", {
				className: "st-mode-badge",
				children: b("games.skyteam.rerollMode")
			}),
			/* @__PURE__ */ h("div", {
				className: "st-dock-dice",
				ref: x,
				children: t.dice.map((e, t) => e === null ? /* @__PURE__ */ h("span", {
					className: "st-die-empty",
					"aria-hidden": !0
				}, t) : /* @__PURE__ */ h("button", {
					type: "button",
					disabled: !l && !r,
					"aria-label": b("games.skyteam.dieAria", { n: e }),
					"aria-pressed": l ? d.includes(t) : i === t,
					onClick: () => f(t),
					className: "st-die-button",
					"data-picked": (l ? d.includes(t) : i === t) || void 0,
					children: /* @__PURE__ */ h(U, {
						value: e,
						side: n,
						size: "hand",
						dimmed: l && d.length > 0 && !d.includes(t)
					})
				}, t))
			}),
			/* @__PURE__ */ h("div", {
				className: "st-dock-controls",
				children: i !== null && !l ? /* @__PURE__ */ g("div", {
					className: "st-coffee-adjust",
					children: [
						/* @__PURE__ */ h("button", {
							type: "button",
							disabled: !C,
							"aria-label": b("games.skyteam.coffeeDownAria"),
							onClick: () => p(o - 1),
							children: "−"
						}),
						/* @__PURE__ */ g("span", { children: [
							/* @__PURE__ */ h(V, {
								kind: "coffee",
								className: "size-3.5"
							}),
							/* @__PURE__ */ h("b", { children: o > 0 ? "+" + o : o }),
							s !== null && o !== 0 && /* @__PURE__ */ g("strong", { children: ["→", s] })
						] }),
						/* @__PURE__ */ h("button", {
							type: "button",
							disabled: !w,
							"aria-label": b("games.skyteam.coffeeUpAria"),
							onClick: () => p(o + 1),
							children: "+"
						})
					]
				}) : l && d.length > 0 ? /* @__PURE__ */ g("button", {
					type: "button",
					onClick: y,
					className: "st-tray-button st-tray-button--primary",
					children: [/* @__PURE__ */ h(u, {
						size: 15,
						"aria-hidden": !0
					}), b("games.skyteam.rerollConfirm", { n: d.length })]
				}) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("button", {
					type: "button",
					disabled: e.rerollSupply <= 0,
					"aria-label": b("games.skyteam.rerollSpendAria"),
					onClick: _,
					className: "st-tray-button",
					children: [/* @__PURE__ */ h(u, {
						size: 15,
						"aria-hidden": !0
					}), /* @__PURE__ */ g("span", { children: ["×", e.rerollSupply] })]
				}), (t.rerollCredit > 0 || l) && /* @__PURE__ */ g("button", {
					type: "button",
					"aria-label": b("games.skyteam.rerollModeAria", { n: t.rerollCredit }),
					"aria-pressed": l,
					onClick: v,
					className: "st-tray-button",
					"data-active": l || void 0,
					children: [b("games.skyteam.rerollMode"), /* @__PURE__ */ g("span", { children: ["×", t.rerollCredit] })]
				})] })
			})
		]
	});
}
//#endregion
//#region src/games/skyteam/bot.ts
function Te(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var J = (e) => e === "blue" ? "axisBlue" : "axisOrange", Y = (e) => e === "blue" ? "engineBlue" : "engineOrange";
function Ee(e, t, n, r) {
	if (e.slots[n]) return !1;
	let i = P[n];
	return !(i.side !== "both" && i.side !== t || i.min !== void 0 && (r < i.min || r > i.max) || n.startsWith("flap") && Number(n.slice(4)) !== e.flaps || n.startsWith("brake") && Number(n.slice(5)) !== e.brakes);
}
function X(e) {
	let t = 6 - e.positionIdx, n = 6 - e.round;
	return t <= 0 || n <= 0 ? 0 : t > n ? 2 : 1;
}
var Z = (e, t) => t * 2 < e.aeroBlue ? 0 : t * 2 > e.aeroOrange ? 2 : 1, De = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase === "done" || !r) return null;
	if (n.phase === "discuss") return n.ready.includes(t.rid) ? null : { action: { type: "ready" } };
	if (n.phase !== "place" || n.turn !== t.rid) return null;
	let i = t.rid === n.pilot ? "blue" : "orange", a = n.coffee, o = [];
	if (r.dice.forEach((e, t) => {
		if (e !== null) for (let r of S) {
			let s = P[r];
			if (s.side !== "both" && s.side !== i) continue;
			let c = /* @__PURE__ */ new Set();
			for (let s = -a; s <= a; s += 1) {
				let a = e + s;
				a < 1 || a > 6 || c.has(a) || (c.add(a), Ee(n, i, r, a) && o.push({
					slot: r,
					die: t,
					coffee: s,
					score: 0
				}));
			}
		}
	}), o.length === 0) return null;
	if (t.difficulty === "weak") {
		let e = o.filter((e) => e.coffee === 0 && (e.slot === J(i) || e.slot === Y(i))), t = o.filter((e) => e.coffee === 0), n = Te(e.length > 0 ? e : t);
		return { action: {
			type: "place",
			slot: n.slot,
			die: n.die,
			coffee: 0
		} };
	}
	let s = n.slots[J(i === "blue" ? "orange" : "blue")]?.value, c = n.slots[Y(i === "blue" ? "orange" : "blue")]?.value, l = n.round === 7, u = n.planes[n.positionIdx] > 0, d = n.positionIdx >= 6;
	for (let e of o) {
		let t = -Math.abs(e.coffee) * 3;
		if (e.slot === J(i)) {
			t += 40;
			let r = i === "blue" ? e.die + e.coffee : s ?? 0, a = i === "orange" ? e.die + e.coffee : s ?? 0;
			if (s !== void 0) {
				let i = n.axis + (r - a);
				if (Math.abs(i) >= 3) {
					e.score = -Infinity;
					continue;
				}
				t -= Math.abs(i) * 15, r === a && (t += 10);
			} else t -= Math.abs(e.die + e.coffee - 3.5) * 4, Math.abs(n.axis) >= 2 && (t -= 20);
		} else if (e.slot === Y(i)) {
			t += 40;
			let r = e.die + e.coffee;
			if (l) {
				let i = M[n.brakes];
				if (c !== void 0) {
					if (c + r > i) {
						e.score = -Infinity;
						continue;
					}
				} else t -= r * 3;
			} else if (c !== void 0) {
				let i = Z(n, c + r);
				if ((u || d) && i > 0) {
					e.score = -Infinity;
					continue;
				}
				t -= Math.abs(i - X(n)) * 20, n.positionIdx + i >= 6 && (t += 15);
			} else t -= u || d ? r * 4 : Math.abs(Z(n, r + 3.5) - X(n)) * 10;
		} else if (e.slot.startsWith("radio")) {
			let r = n.positionIdx + e.die + e.coffee - 1;
			r > 6 || n.planes[r] === 0 ? t -= 8 : (t += 12 + Math.max(0, 5 - (r - n.positionIdx)), r === n.positionIdx && (t += 14));
		} else if (e.slot.startsWith("gear")) {
			let r = Number(e.slot.slice(4));
			t += n.gears[r] ? -6 : 24 + (n.round >= 4 ? 8 : 0);
		} else e.slot.startsWith("flap") ? t += 24 + (n.round >= 4 ? 8 : 0) : e.slot.startsWith("brake") ? t += 18 + (n.round >= 4 ? (3 - n.brakes) * 6 : 0) : t += n.coffee >= 3 ? -12 : 8 + (n.coffee === 0 ? 4 : 0);
		e.score = t;
	}
	let f = o.reduce((e, t) => t.score > e.score ? t : e);
	if (f.score === -Infinity) {
		let e = o[0];
		return { action: {
			type: "place",
			slot: e.slot,
			die: e.die,
			coffee: e.coffee
		} };
	}
	return { action: {
		type: "place",
		slot: f.slot,
		die: f.die,
		coffee: f.coffee
	} };
};
//#endregion
//#region src/games/skyteam/fx.tsx
function Q(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function $(e, t, n) {
	let r = e.data, i = typeof r?.index == "number" ? t.anchor(`slot:${n}${r.index}`) : null;
	return i ? {
		ms: 700,
		node: [/* @__PURE__ */ h(y, {
			at: i,
			ms: 600
		}, "p"), /* @__PURE__ */ h(_, {
			at: i,
			ms: 700,
			children: "✅"
		}, "f")]
	} : null;
}
var Oe = {
	roll(e, t) {
		let n = t.anchor("dice");
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: 600
			})
		} : null;
	},
	place(e, t) {
		let n = e.data, r = Q(t, e.rid), i = typeof n?.slot == "string" ? t.anchor(`slot:${n.slot}`) : null;
		if (!r || !i || typeof n?.value != "number") return null;
		let a = Math.max(34, Math.min(90, i.h - 12, i.w - 12));
		return {
			ms: 400,
			node: /* @__PURE__ */ h(v, {
				from: r,
				to: i,
				ms: 380,
				children: /* @__PURE__ */ h(U, {
					value: n.value,
					side: n.side === "orange" ? "orange" : "blue",
					size: "slot",
					style: {
						width: a,
						height: a,
						fontSize: a * .62
					}
				})
			})
		};
	},
	tilt(e, t) {
		let n = t.anchor("axis");
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: 600
			})
		} : null;
	},
	advance(e, t) {
		let n = e.data, r = typeof n?.to == "number" ? t.anchor(`track:${n.to}`) : null;
		return !r || typeof n?.steps != "number" ? null : {
			ms: 800,
			node: [/* @__PURE__ */ h(y, {
				at: r,
				ms: 600
			}, "p"), /* @__PURE__ */ h(_, {
				at: r,
				ms: 800,
				children: `+${n.steps}`
			}, "f")]
		};
	},
	radioClear(e, t) {
		let n = e.data, r = typeof n?.cell == "number" ? t.anchor(`track:${n.cell}`) : null;
		return r ? {
			ms: 800,
			node: /* @__PURE__ */ h(_, {
				at: r,
				ms: 800,
				children: "✈️💨"
			})
		} : null;
	},
	gear(e, t) {
		return $(e, t, "gear");
	},
	flap(e, t) {
		return $(e, t, "flap");
	},
	brake(e, t) {
		return $(e, t, "brake");
	},
	brew(e, t) {
		let n = t.anchor("coffeePool");
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ h(_, {
				at: n,
				ms: 800,
				children: "☕+1"
			})
		} : null;
	},
	rerollToken(e, t) {
		let n = Q(t, e.rid);
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ h(_, {
				at: n,
				ms: 800,
				children: "🔄"
			})
		} : null;
	},
	reroll(e, t) {
		let n = t.anchor("dice");
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: 600
			})
		} : null;
	},
	token(e, t) {
		let n = t.anchor("altitude");
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ h(_, {
				at: n,
				ms: 800,
				children: "🔄+1"
			})
		} : null;
	},
	crash(e, t) {
		let n = t.anchor("plane");
		return n ? {
			ms: 1200,
			node: [/* @__PURE__ */ h(y, {
				at: n,
				ms: 900
			}, "p"), /* @__PURE__ */ h(_, {
				at: n,
				ms: 1200,
				children: "💥"
			}, "f")]
		} : null;
	},
	land(e, t) {
		let n = t.anchor("plane");
		return n ? {
			ms: 1200,
			node: /* @__PURE__ */ h(_, {
				at: n,
				ms: 1200,
				children: "🛬"
			})
		} : null;
	}
};
//#endregion
//#region src/games/skyteam/game-over.tsx
function ke({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i, hintCount: a }) {
	let o = c(), s = t, l = e.winner.length > 0, u = (e) => n.find((t) => t.rid === e)?.name ?? e, d = r ?? i, f = s.planes.reduce((e, t) => e + t, 0);
	return /* @__PURE__ */ h("div", {
		className: "st-result-adaptive",
		children: /* @__PURE__ */ g("div", {
			className: "st-result",
			"data-win": l || void 0,
			children: [
				l && /* @__PURE__ */ h(b, {}),
				/* @__PURE__ */ g("div", {
					className: "st-result-hero",
					children: [/* @__PURE__ */ g("div", {
						className: "st-result-sky",
						"aria-hidden": !0,
						children: [
							/* @__PURE__ */ h("span", { className: "st-result-sun" }),
							/* @__PURE__ */ h("span", { className: "st-result-cloud st-result-cloud--left" }),
							/* @__PURE__ */ h("span", { className: "st-result-cloud st-result-cloud--right" }),
							/* @__PURE__ */ h(B, { className: "st-result-runway" }),
							/* @__PURE__ */ h(z, { className: "st-result-plane" })
						]
					}), /* @__PURE__ */ g("div", {
						className: "st-result-copy",
						children: [
							/* @__PURE__ */ h("span", {
								className: "st-result-kicker",
								children: o("games.skyteam.approachLabel")
							}),
							/* @__PURE__ */ h("h1", {
								className: "st-result-title",
								children: o(l ? "games.skyteam.overWin" : "games.skyteam.overLose")
							}),
							!l && s.loseReason && /* @__PURE__ */ h("p", {
								className: "st-result-reason",
								children: o(s.loseReason)
							})
						]
					})]
				}),
				/* @__PURE__ */ g("div", {
					className: "st-result-details",
					children: [
						a !== void 0 && /* @__PURE__ */ h("p", {
							className: "st-result-hints",
							children: o("session.hint.usedCount", { n: a })
						}),
						/* @__PURE__ */ g("div", {
							className: "st-result-stats",
							children: [/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ g("b", { children: [
								s.positionIdx + 1,
								"/",
								s.planes.length
							] }), o("games.skyteam.resultRoute")] }), /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("b", { children: f }), o("games.skyteam.resultTraffic")] })]
						}),
						/* @__PURE__ */ h("ul", {
							className: "st-result-crew",
							children: e.ranking.map((e) => /* @__PURE__ */ g("li", {
								className: "st-result-member",
								"data-side": e === s.pilot ? "blue" : "orange",
								children: [
									/* @__PURE__ */ h("span", {
										className: "st-result-member-icon",
										children: /* @__PURE__ */ h(z, { className: "size-5" })
									}),
									/* @__PURE__ */ h("span", {
										className: "st-result-member-name",
										children: u(e)
									}),
									/* @__PURE__ */ h("span", {
										className: "st-result-member-role",
										children: o(e === s.pilot ? "games.skyteam.rolePilot" : "games.skyteam.roleCopilot")
									})
								]
							}, e))
						}),
						d ? /* @__PURE__ */ g("div", {
							className: "st-result-actions safe-b",
							children: [r && /* @__PURE__ */ h("button", {
								className: "btn-base st-result-again",
								style: { background: x.accent },
								onClick: r,
								children: o("session.result.playAgain")
							}), i && /* @__PURE__ */ h("button", {
								className: "btn-quiet st-result-back",
								onClick: i,
								children: o("session.result.backToLobby")
							})]
						}) : /* @__PURE__ */ h("p", {
							className: "st-result-wait safe-b",
							children: o("session.result.waitHost")
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region src/games/skyteam/options.tsx
function Ae({ value: e, onChange: t }) {
	let n = c(), r = E.safeParse(e), i = r.success ? r.data : E.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "st-options",
		children: [
			/* @__PURE__ */ h("p", {
				className: "section-label",
				children: n("games.skyteam.optSwap")
			}),
			/* @__PURE__ */ h("div", {
				className: "st-option-grid",
				children: [!1, !0].map((e) => {
					let r = i.swapRoles === e;
					return /* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => t({ swapRoles: e }),
						"aria-pressed": r,
						className: "card st-option-card relative",
						"data-side": e ? "orange" : "blue",
						"data-active": r || void 0,
						children: [
							/* @__PURE__ */ h("span", {
								className: "st-option-icon",
								children: e ? /* @__PURE__ */ h(V, {
									kind: "radio",
									className: "size-7"
								}) : /* @__PURE__ */ h(z, { className: "size-7" })
							}),
							r && /* @__PURE__ */ h("i", {
								"aria-hidden": !0,
								className: "absolute right-2 top-2 grid size-5 place-items-center rounded-full border-2 border-ink bg-surface",
								children: /* @__PURE__ */ h("span", { className: "size-2 rounded-full bg-ink" })
							}),
							n(e ? "games.skyteam.optSwapOn" : "games.skyteam.optSwapOff")
						]
					}, String(e));
				})
			}),
			/* @__PURE__ */ h("p", {
				className: "st-option-hint",
				children: n("games.skyteam.optSwapHint")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/skyteam/entry.tsx
var je = {
	definition: le,
	View: H,
	bot: De,
	fx: Oe,
	OverView: ke,
	Options: Ae,
	locales: {
		zh: {
			name: "天合小队",
			desc: "正副驾驶合作开飞机:管姿态、控速度、清航道,7 轮内安全着陆",
			rules: "目标:机长与副驾驶合作,在 7 轮内让飞机安全着陆。\n流程(每轮):\n· 先讨论战术,双方都点「就绪」后掷骰,此后不得再交谈。\n· 每人 4 颗骰子,轮流将 1 颗放进驾驶盘槽位;先手按高度轨箭头交替。\n· 姿态与引擎为强制位:每人每轮必须各放 1 颗,缺一即坠毁。\n槽位:\n· 姿态:两颗骰的差值使飞机向大的一侧倾斜,触到 ✕ 立即坠毁;倾斜跨轮不回正。\n· 引擎:两颗之和对照速度表的蓝/橙标记前进 0/1/2 格。\n· 当前格有飞机却必须前进即撞机;已在机场仍须前进即冲出跑道。\n· 无线电:清除与当前格距离等于点数的 1 架飞机(1 = 当前格)。\n· 起落架(机长):可按任意顺序展开,每展开 1 个,蓝色速度标记前进 1 格。\n· 襟翼(副驾驶):必须按顺序展开,每展开 1 个,橙色速度标记前进 1 格。\n· 刹车(机长):按 2/4/6 顺序展开;着陆时引擎之和不得超过刹车值。\n· 专注力:获得 1 杯咖啡(至多存 3 杯);放骰时可花 1 杯咖啡,将点数加 1 或减 1。\n· 重掷:高度轨离开 6000、2000 格时各获得 1 枚标记;花 1 枚,双方各重掷一次。\n着陆(第 7 轮):\n· 引擎之和改为与刹车值比较,本轮不再前进。\n· 轮末安全着陆需同时满足:航道无飞机、起落架与襟翼全部展开、姿态回正、速度不超刹车值。",
			roundShort: "{{n}}/{{total}}",
			rolePilot: "机长",
			roleCopilot: "副驾驶",
			diceLeft: "剩 {{n}} 骰",
			discussPrompt: "讨论战术,准备好就点「就绪」",
			discussReady: "就绪,掷骰!",
			discussWaiting: "已就绪,等 {{name}}…",
			placeYou: "轮到你:选骰子放进槽位",
			placeWait: "等 {{name}} 放骰子…",
			finalHint: "着陆轮:引擎之和 ≤ 刹车 {{n}}",
			modAxis: "姿态",
			modEngine: "引擎",
			modRadio: "无线电",
			modGear: "起落架",
			modFlap: "襟翼",
			modBrake: "刹车",
			modCoffee: "专注力",
			approachLabel: "进近航道",
			trackCellAria: "航路第 {{n}} 格，剩 {{planes}} 架飞机",
			altitudeLabel: "高度",
			speedLabel: "速度",
			engineSum: "合计 {{n}}",
			slotAria: "{{mod}}·{{spec}}",
			dieAria: "{{n}} 点骰子",
			coffeeDownAria: "少用 1 枚咖啡",
			coffeeUpAria: "多用 1 枚咖啡",
			rerollSpendAria: "花 1 枚重掷标记,双方各得 1 次重掷机会",
			rerollMode: "重掷",
			rerollModeAria: "重掷自己的骰子,剩 {{n}} 次",
			rerollConfirm: "重掷 {{n}} 颗",
			overWin: "安全着陆!",
			overLose: "没能平安落地…",
			resultRoute: "航路进度",
			resultTraffic: "剩余交通机",
			optSwap: "角色分配",
			optSwapOff: "座位 1 当机长",
			optSwapOn: "座位 1 当副驾驶",
			optSwapHint: "交换两个座位的角色;机长管起落架/刹车,副驾驶管襟翼",
			errDone: "本局已结束",
			errNotPlayer: "你不在这一局里",
			errPhase: "现在不能这么做",
			errTurn: "现在轮不到你",
			errSlotSide: "这个槽位归对方角色",
			errSlotTaken: "这个槽位已有骰子",
			errDieUsed: "这颗骰子已经放过了",
			errNoCoffee: "咖啡不够",
			errCoffeeRange: "咖啡只能把点数调到 1-6",
			errValue: "点数不符合这个槽位",
			errOrder: "这一排必须按顺序放",
			errNoToken: "没有重掷标记了",
			errNoCredit: "本轮的重掷机会用完了",
			loseAxis: "姿态失控,飞机进入螺旋",
			loseCollision: "与航道上的飞机相撞",
			loseOverrun: "冲出了机场",
			loseAltitude: "高度耗尽,没能抵达机场",
			loseMissing: "强制仪表位(姿态/引擎)有空缺",
			loseSpeed: "着陆速度超过刹车极限",
			loseTraffic: "空域里还有飞机没清空",
			loseConfig: "起落架/襟翼没有全部打开",
			loseLevel: "触地时姿态没有回正"
		},
		en: {
			name: "Sky Team",
			desc: "Co-op cockpit: manage tilt, speed and traffic — land in 7 rounds",
			rules: "Goal: pilot and co-pilot work together to land the plane within 7 rounds.\nEach round:\n· Discuss tactics, then both tap \"Ready\" to roll (no talking afterwards!).\n· Each player rolls 4 dice and takes turns placing one into a cockpit slot; the first player alternates by round.\n· Axis and engines are mandatory: each player must place one die on each, or you crash.\nSlots:\n· Axis: the dice difference tilts the plane toward the higher side; reaching ✕ crashes. Tilt does not reset between rounds.\n· Engines: the sum moves you 0/1/2 spaces (vs the blue/orange speed markers).\n· Moving while a plane shares your space is a collision; moving while at the airport is an overshoot.\n· Radio: remove 1 plane at distance = die value (1 = your space).\n· Landing gear (pilot): any order; each one deployed advances the blue speed marker by 1.\n· Flaps (co-pilot): must be deployed in order; each one advances the orange speed marker by 1.\n· Brakes (pilot): 2/4/6 in order; on landing the engine sum must not exceed it.\n· Concentration: gain 1 coffee (max 3 stored); when placing a die, spend 1 coffee to adjust its value up or down by 1.\n· Reroll: leaving the 6000/2000 altitude steps collects a token; spend 1 so both players get one reroll.\nFinal round (round 7):\n· The engine sum is now compared against the brakes, and the plane no longer moves.\n· Land safely only if all hold at round end: no planes left, gear and flaps fully open, axis level, speed within brakes.",
			roundShort: "{{n}}/{{total}}",
			rolePilot: "Pilot",
			roleCopilot: "Co-pilot",
			diceLeft: "{{n}} left",
			discussPrompt: "Discuss tactics, then tap \"Ready\"",
			discussReady: "Ready — roll!",
			discussWaiting: "Ready. Waiting for {{name}}…",
			placeYou: "Your turn: place a die",
			placeWait: "Waiting for {{name}}…",
			finalHint: "Final round: engines ≤ brakes {{n}}",
			modAxis: "Axis",
			modEngine: "Engines",
			modRadio: "Radio",
			modGear: "Gear",
			modFlap: "Flaps",
			modBrake: "Brakes",
			modCoffee: "Coffee",
			approachLabel: "Approach track",
			trackCellAria: "Approach step {{n}}, {{planes}} aircraft remaining",
			altitudeLabel: "Altitude",
			speedLabel: "Speed",
			engineSum: "Sum {{n}}",
			slotAria: "{{mod}} {{spec}}",
			dieAria: "Die showing {{n}}",
			coffeeDownAria: "Use one less coffee",
			coffeeUpAria: "Use one more coffee",
			rerollSpendAria: "Spend 1 reroll token: both players get one reroll",
			rerollMode: "Reroll",
			rerollModeAria: "Reroll your dice, {{n}} left",
			rerollConfirm: "Reroll {{n}}",
			overWin: "Touchdown!",
			overLose: "Crashed…",
			resultRoute: "Approach",
			resultTraffic: "Traffic left",
			optSwap: "Role assignment",
			optSwapOff: "Seat 1 = Pilot",
			optSwapOn: "Seat 1 = Co-pilot",
			optSwapHint: "Swap the two seats: pilot handles gear/brakes, co-pilot handles flaps",
			errDone: "This game is over",
			errNotPlayer: "You are not in this game",
			errPhase: "Not right now",
			errTurn: "Not your turn",
			errSlotSide: "That slot belongs to the other role",
			errSlotTaken: "That slot is taken",
			errDieUsed: "That die is already placed",
			errNoCoffee: "Not enough coffee",
			errCoffeeRange: "Coffee can only adjust within 1-6",
			errValue: "That value doesn't fit this slot",
			errOrder: "This row must be filled in order",
			errNoToken: "No reroll tokens left",
			errNoCredit: "No rerolls left this round",
			loseAxis: "Lost control — the plane spirals down",
			loseCollision: "Collided with traffic on the approach",
			loseOverrun: "Overshot the airport",
			loseAltitude: "Ran out of altitude before reaching the airport",
			loseMissing: "A mandatory slot (axis/engines) was left empty",
			loseSpeed: "Landing speed exceeded the brakes",
			loseTraffic: "Airspace not cleared",
			loseConfig: "Landing gear / flaps not fully deployed",
			loseLevel: "The plane was not level at touchdown"
		}
	}
};
//#endregion
export { je as default };
