import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { BottomSheet as c } from "@bgparty/sdk/bottom-sheet";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { seatName as u } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { FlySprite as h } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as g, OptionSection as _, OptionSwitch as v } from "@bgparty/sdk/ui/game-options";
//#region src/games/mortysorty/data.ts
var y = [
	"mushroom",
	"cloud",
	"eyes",
	"mandrake"
], b = [
	"black",
	"silver",
	"gold",
	"blue"
], x = {
	mushroom: "cloud",
	cloud: "mushroom",
	eyes: "mandrake",
	mandrake: "eyes"
}, S = [
	0,
	1,
	3,
	6,
	10,
	15,
	21,
	28,
	36,
	46,
	60
], C = [
	0,
	2,
	4,
	6,
	8,
	12,
	16,
	20,
	24,
	30
], w = [
	10,
	6,
	4
], T = [
	0,
	2,
	5,
	9,
	15,
	23,
	33,
	45,
	59,
	75
], E = [
	0,
	2,
	5,
	9,
	14,
	20,
	27,
	35,
	45,
	57,
	72
], D = {
	1: 5,
	3: 8,
	5: 11,
	9: 4,
	11: 7,
	14: 13,
	18: 6,
	20: 9,
	22: 14
}, O = {
	0: "mushroom",
	3: "eyes",
	5: "mandrake",
	9: "cloud",
	12: "mushroom",
	15: "eyes",
	18: "mandrake",
	22: "cloud"
}, k = [
	[
		5,
		4,
		2
	],
	[
		5,
		4,
		2
	],
	[
		6,
		5,
		3
	],
	[
		6,
		5,
		3
	],
	[
		7,
		6,
		4
	],
	[
		7,
		6,
		4
	],
	[
		8,
		7,
		5
	],
	[
		8,
		7,
		5
	]
], A = (e, t) => e[Math.min(t, e.length - 1)];
function j() {
	let e = [];
	for (let t of ["mushroom", "eyes"]) for (let n = 0; n < 4; n++) for (let r = n + 1; r <= 16 - n; r++) e.push({
		id: e.length,
		ingredient: t,
		lid: b[n],
		n: r
	});
	return e;
}
var M = (e) => [
	e >= 8 ? e - 8 : -1,
	e < 16 ? e + 8 : -1,
	e % 8 > 0 ? e - 1 : -1,
	e % 8 < 7 ? e + 1 : -1
].filter((e) => e >= 0);
function N(e, t) {
	let n = /* @__PURE__ */ new Set(), r = [];
	return e.forEach((i, a) => {
		if (!i || !t(i) || n.has(a)) return;
		let o = [a];
		n.add(a);
		for (let r = 0; r < o.length; r++) for (let i of M(o[r])) !n.has(i) && e[i] && t(e[i]) && (n.add(i), o.push(i));
		r.push(o);
	}), r;
}
function ee(e, t) {
	return e.shelf.reduce((e, n, r) => e + Number(!!n && (t.side === "A" ? D[r] === n.n : O[r] === n.ingredient)), 0);
}
function te(e, t, n) {
	let r = t.shelf, i = [
		r.slice(0, 8),
		r.slice(8, 16),
		r.slice(16, 24)
	], a = Array.from({ length: 8 }, (e, t) => [
		r[t],
		r[t + 8],
		r[t + 16]
	]);
	switch (e) {
		case 0: return new Set(i[2].filter(Boolean).map((e) => e.ingredient)).size === 4;
		case 1: return ee(t, n) >= 6;
		case 2: return i.every((e, t) => e.filter((e) => e?.lid === "gold").length >= 3 - t);
		case 3: return N(r, (e) => e.lid === "silver").some((e) => e.length >= 5);
		case 4: return i.some((e) => e.some((t, n) => !!t && n <= 4 && [
			1,
			2,
			3
		].every((r) => e[n + r]?.n === t.n + r)));
		case 5: return a.some((e) => e.every((t) => t && t.n === e[0]?.n));
		case 6: return a.some((e) => e.filter((e) => e?.lid === "blue").length >= 2);
		case 7: return a.some((e) => e.every((t) => t && t.ingredient === e[0]?.ingredient));
		default: return !1;
	}
}
//#endregion
//#region src/games/mortysorty/meta.ts
var P = {
	id: "mortysorty",
	tier: "alpha",
	nameKey: "games.mortysorty.name",
	descKey: "games.mortysorty.desc",
	rulesKey: "games.mortysorty.rules",
	icon: "🫙",
	iconImg: "games/mortysorty.webp",
	minPlayers: 2,
	maxPlayers: 4,
	accent: "#b17c32",
	releasedAt: "2026-11-04T20:42:25+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "open",
	rulesUrl: { en: "https://www.schmidtspiele.de/files/Retail/72dpi_PNG/49468_Morty_Sorty_DE_FR_EN.pdf" },
	mechanics: [
		"drafting",
		"tile-placement",
		"set-collection",
		"race"
	],
	interactionTags: [],
	botDelayMs: 500
}, F = t.enum([
	"mushroom",
	"cloud",
	"eyes",
	"mandrake"
]), I = t.enum([
	"black",
	"silver",
	"gold",
	"blue"
]), L = t.object({
	id: t.number().int(),
	n: t.number().int().min(1).max(16),
	lid: I,
	ingredient: F
}), R = t.object({
	side: t.enum(["A", "B"]).default("A"),
	badges: t.boolean().default(!0),
	badgeFaces: t.array(t.number().int().min(0).max(7)).length(2).refine((e) => Math.floor(e[0] / 2) !== Math.floor(e[1] / 2)).optional(),
	mushroom: t.enum([
		"basic",
		"I",
		"II"
	]).default("basic"),
	cloud: t.enum([
		"basic",
		"I",
		"II"
	]).default("basic"),
	eyes: t.enum([
		"basic",
		"I",
		"II"
	]).default("basic"),
	mandrake: t.enum([
		"basic",
		"I",
		"II"
	]).default("basic")
}).prefault({}), z = t.object({
	type: t.literal("place"),
	id: t.number().int(),
	cell: t.number().int().min(0).max(23),
	flip: t.boolean(),
	equal: t.boolean()
}), ne = t.discriminatedUnion("type", [
	z,
	t.object({ type: t.literal("pass") }),
	t.object({ type: t.literal("kitten") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), re = t.object({
	mushroom: t.number(),
	cloud: t.number(),
	eyes: t.number(),
	mandrake: t.number(),
	labels: t.number(),
	rows: t.number(),
	kittens: t.number(),
	badges: t.number(),
	total: t.number(),
	best: t.number()
}), B = t.object({
	rid: t.string(),
	shelf: t.array(L.nullable()).length(24),
	kittens: t.number().int().min(0),
	rows: t.array(t.number().int()),
	columns: t.array(t.number().int())
}), V = t.object({
	id: t.number().int(),
	claims: t.array(t.object({
		rid: t.string(),
		round: t.number().int(),
		ribbon: t.number().int()
	}))
}), ie = t.object({
	kind: t.enum([
		"place",
		"pass",
		"kitten",
		"row",
		"badge",
		"round",
		"end"
	]),
	rid: t.string(),
	n: t.number().optional(),
	cell: t.number().optional(),
	ingredient: F.optional(),
	badge: t.number().optional()
}), ae = t.object({
	config: R,
	phase: t.enum([
		"stock",
		"draft",
		"resolve",
		"bonus",
		"done"
	]),
	round: t.number().int(),
	turn: t.string(),
	starter: t.string(),
	players: t.array(B),
	market: t.array(L),
	special: t.array(L),
	badges: t.array(V),
	supply: t.number().int(),
	scores: t.record(t.string(), re),
	log: t.array(ie)
}), oe = t.object({ moves: t.array(ne) });
//#endregion
//#region src/games/mortysorty/scoring.ts
function H(e, t, n) {
	let r = e.flatMap((e) => N(e.shelf, (e) => e.ingredient === "cloud").filter((e) => e.length >= 2).map((t) => ({
		rid: e.rid,
		size: t.length
	}))), i = [...new Set(r.map((e) => e.size))].sort((e, t) => t - e), a = [
		0,
		1,
		2
	].map((t) => Math.max(...e.map((e) => e.shelf.slice(t * 8, t * 8 + 8).filter((e) => e?.ingredient === "cloud").length)));
	return Object.fromEntries(e.map((e) => {
		let o = e.shelf, s = o.filter((e) => e !== null), c = Object.fromEntries(y.map((e) => [e, s.filter((t) => t.ingredient === e).length])), l = {
			mushroom: 0,
			cloud: 0,
			eyes: 0,
			mandrake: 0,
			labels: 0,
			rows: 0,
			kittens: e.kittens * 2,
			badges: 0,
			total: 0,
			best: 0
		};
		for (let e of y) l[e] = A(S, c[e]);
		t.mushroom === "I" && (l.mushroom = 3 * c.mushroom + [
			0,
			1,
			2
		].reduce((e, t) => e + (o.slice(t * 8, t * 8 + 8).filter((e) => e?.ingredient === "mushroom").length >= 3 ? 10 : 0), 0)), t.mushroom === "II" && (l.mushroom = A(T, o.filter((e, t) => e?.ingredient === "mushroom" && M(t).every((e) => o[e]?.ingredient !== "mushroom")).length)), t.cloud === "I" && (l.cloud = 4 * c.cloud + r.filter((t) => t.rid === e.rid).reduce((e, t) => e + (t.size === i[0] ? 14 : t.size === i[1] ? 6 : 0), 0)), t.cloud === "II" && (l.cloud = 2 * c.cloud + [
			0,
			1,
			2
		].reduce((e, t) => e + (a[t] > 0 && o.slice(t * 8, t * 8 + 8).filter((e) => e?.ingredient === "cloud").length === a[t] ? [
			14,
			10,
			8
		][t] : 0), 0)), t.eyes === "I" && (l.eyes = c.eyes * s.filter((e) => e.lid === "black").length), t.eyes === "II" && (l.eyes = c.eyes * Math.min(s.filter((e) => e.lid === "gold").length, s.filter((e) => e.lid === "silver").length));
		let u = s.filter((e) => e.ingredient === "mandrake"), d = [...new Set(u.map((e) => e.n))];
		return t.mandrake === "I" && (l.mandrake = A(E, d.length)), t.mandrake === "II" && (l.mandrake = 4 * c.mandrake + d.reduce((e, t) => e + [
			0,
			0,
			4,
			12,
			32
		][Math.min(4, u.filter((e) => e.n === t).length)], 0)), l.labels = t.side === "A" ? A(C, ee(e, t)) : y.filter((e) => Object.entries(O).filter(([, t]) => e === t).every(([t]) => o[Number(t)]?.ingredient === e)).length * 6, l.rows = [
			0,
			1,
			2
		].reduce((e, t) => e + (o.slice(t * 8, t * 8 + 8).every(Boolean) ? w[t] : 0), 0), l.badges = n.reduce((t, n) => {
			let r = n.claims.find((t) => t.rid === e.rid);
			return t + (r ? k[n.id][r.ribbon] : 0);
		}, 0), l.best = Math.max(...y.map((e) => l[e])), l.total = y.reduce((e, t) => e + l[t], 0) + l.labels + l.rows + l.kittens + l.badges, [e.rid, l];
	}));
}
//#endregion
//#region src/games/mortysorty/rules.ts
var U = {
	place: 480,
	draw: 220,
	award: 520,
	turn: 220,
	end: 600
};
function W(t, n) {
	return e(t.seed, t.cursor++, n);
}
function G(e, t) {
	e.log.push(t);
}
function se(e, t, n) {
	let { cell: r, flip: i, equal: a } = n, o = Math.floor(r / 8), s = r % 8;
	if (r < 0 || r >= 24 || e.shelf[r] || e.kittens < Number(i) + Number(a) || t.lid === "black" && o !== 2 || t.lid === "silver" && o === 0) return !1;
	let c = e.shelf.slice(o * 8, o * 8 + 8), l = c.some((e) => e?.n === t.n), u = s > 0 && c[s - 1]?.n === t.n || s < 7 && c[s + 1]?.n === t.n;
	return l && (!a || !u) || !l && a ? !1 : c.every((e, n) => !e || (n < s ? e.n <= t.n : e.n >= t.n));
}
function ce(e, t) {
	if (e.turn !== t || e.phase !== "draft" && e.phase !== "bonus") return [];
	let n = e.players.find((e) => e.rid === t);
	if (!n) return [];
	let r = [e.phase === "draft" ? { type: "pass" } : { type: "kitten" }];
	for (let t of e.phase === "draft" ? e.market : e.special) for (let e = 0; e < 24; e++) for (let i of [!1, !0]) for (let a of [!1, !0]) se(n, t, {
		cell: e,
		flip: i,
		equal: a
	}) && r.push({
		type: "place",
		id: t.id,
		cell: e,
		flip: i,
		equal: a
	});
	return r;
}
function le(e) {
	let t = Math.min(1, e.supply);
	return e.players[e.turn].kittens += t, e.supply -= t, t;
}
function ue(e, t) {
	let n = e.players[e.turn], r = Math.floor(t / 8), i = t % 8, a = [];
	!n.rows.includes(r) && n.shelf.slice(r * 8, r * 8 + 8).every(Boolean) && (n.rows.push(r), a.push({
		kind: "row",
		n: r
	}));
	for (let t of e.badges) if (!t.claims.some((e) => e.rid === n.rid) && te(t.id, n, e.config)) {
		let n = [...new Set(t.claims.map((e) => e.round))];
		(n.includes(e.round) || n.length < 3) && a.push({
			kind: "badge",
			n: t.id
		});
	}
	return !n.columns.includes(i) && new Set([
		i,
		i + 8,
		i + 16
	].map((e) => n.shelf[e]?.ingredient)).size === 3 && [
		i,
		i + 8,
		i + 16
	].every((e) => n.shelf[e]) && (n.columns.push(i), a.push({
		kind: "column",
		n: i
	})), a;
}
function de(e) {
	e.acted++, e.acted < e.players.length ? (e.turn = (e.turn + 1) % e.players.length, e.phase = "draft") : (e.discarded.push(...e.market), e.market = [], e.round++, e.starter = (e.starter + 1) % e.players.length, e.turn = e.starter, e.acted = 0, e.phase = "stock", G(e, {
		kind: "round",
		rid: e.players[e.turn].rid,
		n: e.round
	})), e.beat = U.turn;
}
function fe(e) {
	if (e.phase === "stock") {
		let t = e.players.length === 2 ? 4 : 5;
		if (e.market.length === t) return e.phase = "draft", [];
		let n = e.bag.pop();
		if (!n) return e.phase = "done", G(e, {
			kind: "end",
			rid: ""
		}), [{ kind: "finish" }];
		let r = n.lid === "blue";
		return r ? e.special.push(n) : e.market.push(n), e.beat = U.draw, [{
			kind: "draw",
			data: {
				jar: n,
				special: r
			}
		}];
	}
	let t = e.pending.shift();
	if (!t) return de(e), [];
	let n = e.players[e.turn];
	switch (e.beat = U.award, t.kind) {
		case "next": return de(e), [];
		case "column": return e.phase = "bonus", [{
			kind: "column",
			rid: n.rid,
			data: { column: t.n }
		}];
		case "badge": {
			let r = e.badges.find((e) => e.id === t.n), i = [...new Set(r.claims.map((e) => e.round))], a = i.includes(e.round) ? i.indexOf(e.round) : i.length;
			r.claims.push({
				rid: n.rid,
				round: e.round,
				ribbon: a
			});
			let o = a === 0 ? le(e) : 0;
			return G(e, {
				kind: "badge",
				rid: n.rid,
				badge: r.id,
				n: o
			}), [{
				kind: "badge",
				rid: n.rid,
				data: {
					badge: r.id,
					n: o
				}
			}];
		}
		case "row": {
			let r = le(e);
			return G(e, {
				kind: "row",
				rid: n.rid,
				cell: t.n,
				n: r
			}), [{
				kind: "reward",
				rid: n.rid,
				data: {
					row: t.n,
					n: r
				}
			}];
		}
		case "kitten": {
			let t = le(e);
			return G(e, {
				kind: "kitten",
				rid: n.rid,
				n: t
			}), [{
				kind: "kitten",
				rid: n.rid,
				data: { n: t }
			}];
		}
	}
}
function pe(e) {
	return {
		config: e.config,
		phase: e.phase,
		round: e.round,
		turn: e.players[e.turn].rid,
		starter: e.players[e.starter].rid,
		players: e.players,
		market: e.market,
		special: e.special,
		supply: e.supply,
		badges: e.badges,
		scores: H(e.players, e.config, e.badges),
		log: e.log
	};
}
var me = {
	meta: P,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ne,
		config: R,
		publicView: ae,
		privateView: oe
	},
	setup(e, t, n) {
		let r = R.parse(e), i = {
			config: r,
			seed: n,
			cursor: 1,
			phase: "stock",
			round: 1,
			turn: 0,
			starter: 0,
			acted: 0,
			players: t.map((e) => ({
				rid: e,
				shelf: Array(24).fill(null),
				kittens: 2,
				rows: [],
				columns: []
			})),
			bag: j(),
			removed: [],
			discarded: [],
			market: [],
			special: [],
			supply: 16 - 2 * t.length,
			badges: [],
			pending: [],
			beat: U.draw,
			log: []
		};
		for (let e of i.bag) W(i, 2) && (e.ingredient = x[e.ingredient]);
		for (let e = i.bag.length - 1; e > 0; e--) {
			let t = W(i, e + 1);
			[i.bag[e], i.bag[t]] = [i.bag[t], i.bag[e]];
		}
		if (i.removed = i.bag.splice(0, t.length === 2 ? 23 : 4), i.starter = W(i, t.length), i.turn = i.starter, r.badges) {
			let e = [
				0,
				1,
				2,
				3
			], t = e.splice(W(i, 4), 1)[0], n = e[W(i, 3)];
			i.badges = (r.badgeFaces ?? [t * 2 + W(i, 2), n * 2 + W(i, 2)]).map((e) => ({
				id: e,
				claims: []
			}));
		}
		return { state: i };
	},
	reduce(e, t, n) {
		let r = { code: "games.mortysorty.errAction" };
		if (e.phase === "done") return r;
		if (t.type === "tick") {
			if (n.by !== "$engine" || e.phase !== "stock" && e.phase !== "resolve") return r;
			let t = structuredClone(e);
			return {
				state: t,
				fx: fe(t)
			};
		}
		let i = e.players[e.turn];
		if (i.rid !== n.by || e.phase !== "draft" && e.phase !== "bonus" || t.type === "pass" && e.phase !== "draft" || t.type === "kitten" && e.phase !== "bonus") return r;
		if (t.type === "place") {
			let n = (e.phase === "draft" ? e.market : e.special).find((e) => e.id === t.id);
			if (!n || !se(i, n, t)) return r;
			let a = structuredClone(e), o = a.phase === "draft" ? a.market : a.special, s = o.splice(o.findIndex((e) => e.id === t.id), 1)[0], c = Number(t.flip) + Number(t.equal);
			return a.players[a.turn].kittens -= c, a.supply += c, t.flip && (s.ingredient = x[s.ingredient]), a.players[a.turn].shelf[t.cell] = s, a.pending = [...ue(a, t.cell), ...e.phase === "draft" ? [{ kind: "next" }] : a.pending], a.phase = "resolve", a.beat = U.place, G(a, {
				kind: "place",
				rid: i.rid,
				n: s.n,
				ingredient: s.ingredient,
				cell: t.cell
			}), {
				state: a,
				fx: [{
					kind: "place",
					rid: i.rid,
					data: {
						jar: s,
						cell: t.cell,
						source: e.phase === "draft" ? "market" : "special",
						original: n,
						flip: t.flip,
						cost: c
					}
				}]
			};
		}
		let a = structuredClone(e);
		return t.type === "pass" ? (G(a, {
			kind: "pass",
			rid: i.rid
		}), a.pending = [{ kind: "kitten" }, { kind: "next" }]) : a.pending.unshift({ kind: "kitten" }), a.phase = "resolve", a.beat = U.turn, { state: a };
	},
	viewFor(e, t) {
		let n = pe(e);
		return {
			public: n,
			private: { moves: ce(n, t) }
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = H(e.players, e.config, e.badges), n = e.players.map((e) => e.rid).sort((e, n) => t[n].total - t[e].total || t[n].best - t[e].best), r = t[n[0]];
		return {
			phase: "done",
			ranking: n,
			winner: n.filter((e) => t[e].total === r.total && t[e].best === r.best),
			scores: Object.fromEntries(n.map((e) => [e, t[e].total]))
		};
	},
	nextTickIn(e) {
		return e.phase === "stock" || e.phase === "resolve" ? e.beat : null;
	}
}, he = {
	name: "games.mortysorty.name",
	desc: "games.mortysorty.desc",
	errAction: "games.mortysorty.errAction",
	rules: "games.mortysorty.rules",
	mushroom: "games.mortysorty.mushroom",
	cloud: "games.mortysorty.cloud",
	eyes: "games.mortysorty.eyes",
	mandrake: "games.mortysorty.mandrake",
	black: "games.mortysorty.black",
	silver: "games.mortysorty.silver",
	gold: "games.mortysorty.gold",
	blue: "games.mortysorty.blue",
	round: "games.mortysorty.round",
	yourTurn: "games.mortysorty.yourTurn",
	waiting: "games.mortysorty.waiting",
	stock: "games.mortysorty.stock",
	resolving: "games.mortysorty.resolving",
	bonus: "games.mortysorty.bonus",
	done: "games.mortysorty.done",
	market: "games.mortysorty.market",
	special: "games.mortysorty.special",
	pass: "games.mortysorty.pass",
	takeKitten: "games.mortysorty.takeKitten",
	flip: "games.mortysorty.flip",
	equal: "games.mortysorty.equal",
	cost: "games.mortysorty.cost",
	cats: "games.mortysorty.cats",
	supply: "games.mortysorty.supply",
	shelf: "games.mortysorty.shelf",
	ownShelf: "games.mortysorty.ownShelf",
	cell: "games.mortysorty.cell",
	jar: "games.mortysorty.jar",
	place: "games.mortysorty.place",
	top: "games.mortysorty.top",
	middle: "games.mortysorty.middle",
	bottom: "games.mortysorty.bottom",
	rowBonus: "games.mortysorty.rowBonus",
	badges: "games.mortysorty.badges",
	scrolls: "games.mortysorty.scrolls",
	details: "games.mortysorty.details",
	close: "games.mortysorty.close",
	selected: "games.mortysorty.selected",
	noSelected: "games.mortysorty.noSelected",
	log: "games.mortysorty.log",
	points: "games.mortysorty.points",
	labels: "games.mortysorty.labels",
	rows: "games.mortysorty.rows",
	kittens: "games.mortysorty.kittens",
	total: "games.mortysorty.total",
	result: "games.mortysorty.result",
	winner: "games.mortysorty.winner",
	tied: "games.mortysorty.tied",
	review: "games.mortysorty.review",
	showScores: "games.mortysorty.showScores",
	badge0: "games.mortysorty.badge0",
	badge1: "games.mortysorty.badge1",
	badge2: "games.mortysorty.badge2",
	badge3: "games.mortysorty.badge3",
	badge4: "games.mortysorty.badge4",
	badge5: "games.mortysorty.badge5",
	badge6: "games.mortysorty.badge6",
	badge7: "games.mortysorty.badge7",
	ribbon: "games.mortysorty.ribbon",
	unclaimed: "games.mortysorty.unclaimed",
	side: "games.mortysorty.side",
	sideA: "games.mortysorty.sideA",
	sideB: "games.mortysorty.sideB",
	useBadges: "games.mortysorty.useBadges",
	badgeChoice: "games.mortysorty.badgeChoice",
	random: "games.mortysorty.random",
	advanced: "games.mortysorty.advanced",
	basic: "games.mortysorty.basic",
	modeI: "games.mortysorty.modeI",
	modeII: "games.mortysorty.modeII",
	preset: "games.mortysorty.preset",
	custom: "games.mortysorty.custom",
	basicHelp: "games.mortysorty.basicHelp",
	mushroomI: "games.mortysorty.mushroomI",
	mushroomII: "games.mortysorty.mushroomII",
	cloudI: "games.mortysorty.cloudI",
	cloudII: "games.mortysorty.cloudII",
	eyesI: "games.mortysorty.eyesI",
	eyesII: "games.mortysorty.eyesII",
	mandrakeI: "games.mortysorty.mandrakeI",
	mandrakeII: "games.mortysorty.mandrakeII",
	logPlace: "games.mortysorty.logPlace",
	logPass: "games.mortysorty.logPass",
	logKitten: "games.mortysorty.logKitten",
	logRow: "games.mortysorty.logRow",
	logBadge: "games.mortysorty.logBadge",
	logRound: "games.mortysorty.logRound",
	logEnd: "games.mortysorty.logEnd",
	hintPlace: "games.mortysorty.hintPlace",
	hintPass: "games.mortysorty.hintPass",
	hintKitten: "games.mortysorty.hintKitten",
	emptySpecial: "games.mortysorty.emptySpecial",
	rowRestriction: "games.mortysorty.rowRestriction",
	rewardColumn: "games.mortysorty.rewardColumn"
};
function K() {
	let e = o();
	return (t, n) => e(he[t], n);
}
//#endregion
//#region src/games/mortysorty/art.tsx
var q = (e) => `games/mortysorty/${e}.svg`, ge = {
	black: "#22221f",
	silver: "#babdb6",
	gold: "#bd8830",
	blue: "#167c9a"
};
function J({ jar: e, anchor: t }) {
	let { ref: n, hidden: r } = s(t ?? null);
	return /* @__PURE__ */ m("span", {
		ref: n,
		className: "ms-jar",
		style: { visibility: r ? "hidden" : void 0 },
		children: [/* @__PURE__ */ p("img", {
			src: q(e.ingredient),
			alt: "",
			draggable: !1
		}), /* @__PURE__ */ m("svg", {
			viewBox: "0 0 188 303",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ p("path", {
					d: "M28 2H157Q174 3 174 22V50L162 60H29L26 49V20Q26 4 40 2Z",
					fill: ge[e.lid],
					stroke: "#453622",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ p("path", {
					d: "M36 15Q88 4 162 16",
					fill: "none",
					stroke: "#fff2c7",
					strokeOpacity: ".55",
					strokeWidth: "6"
				}),
				/* @__PURE__ */ p("path", {
					d: "M29 50H170",
					stroke: "#352f29",
					strokeWidth: "4"
				}),
				e.lid === "blue" && [
					45,
					76,
					107,
					138
				].map((e) => /* @__PURE__ */ p("path", {
					d: "m0 -9 2.5 6.5 7 .3-5.5 4.5 1.8 6.7L0 5-5.8 9-4 2.3-9.5-2.2-2.5-2.5Z",
					transform: `translate(${e} 34)`,
					fill: "#f7ca62"
				}, e)),
				/* @__PURE__ */ p("ellipse", {
					cx: "94",
					cy: "94",
					rx: "50",
					ry: "33",
					fill: "#fff9df",
					stroke: "#8f8664",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ p("text", {
					x: "94",
					y: "115",
					textAnchor: "middle",
					fill: "#292a22",
					fontFamily: "Georgia,serif",
					fontWeight: "700",
					fontSize: "62",
					children: e.n
				})
			]
		})]
	});
}
function Y({ n: e, anchor: t }) {
	let { ref: n, hidden: r } = s(t ?? null), i = K();
	return /* @__PURE__ */ m("span", {
		ref: n,
		className: "ms-kitten",
		style: { visibility: r ? "hidden" : void 0 },
		"aria-label": e === void 0 ? i("kittens") : i("cats", { n: e }),
		children: [/* @__PURE__ */ p("img", {
			src: q("kitten"),
			alt: ""
		}), e !== void 0 && /* @__PURE__ */ p("b", { children: e })]
	});
}
function X({ lid: e }) {
	let t = K();
	return /* @__PURE__ */ p("span", {
		title: t(e),
		"aria-label": t(e),
		className: `ms-lid ms-lid-${e}`,
		style: { background: ge[e] },
		children: e === "blue" ? "★" : e === "gold" ? "◆" : e === "silver" ? "═" : "━"
	});
}
function _e() {
	return /* @__PURE__ */ p("svg", {
		className: "ms-marching",
		"aria-hidden": "true",
		children: /* @__PURE__ */ p("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "8",
			fill: "none",
			stroke: "#fff1aa",
			strokeWidth: "2",
			strokeDasharray: "5 4",
			children: /* @__PURE__ */ p("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-18",
				dur: "1.1s",
				repeatCount: "indefinite"
			})
		})
	});
}
//#endregion
//#region src/games/mortysorty/board.tsx
function ve({ p: e, i: t, config: n, move: r, preview: i, onPlace: a }) {
	let o = K(), c = e.shelf[t], { ref: l } = s(`cell:${e.rid}:${t}`), u = c && (n.side === "A" ? c.n === D[t] : c.ingredient === O[t]);
	return /* @__PURE__ */ m("button", {
		ref: l,
		type: "button",
		className: `ms-cell${r ? " ms-legal" : ""}${c ? " ms-occupied" : ""}`,
		disabled: !r,
		onClick: () => r && a?.(r),
		"aria-label": c ? o("jar", {
			ingredient: o(c.ingredient),
			lid: o(c.lid),
			n: c.n
		}) : o(r ? "place" : "cell", {
			row: Math.floor(t / 8) + 1,
			col: t % 8 + 1
		}),
		children: [
			c ? /* @__PURE__ */ p(J, {
				jar: c,
				anchor: `jar:${e.rid}:${t}`
			}) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("svg", {
				className: "ms-empty-jar",
				viewBox: "0 0 188 303",
				"aria-hidden": "true",
				children: /* @__PURE__ */ p("path", {
					d: "M28 4H160Q174 4 174 22V52L158 63V79Q158 90 175 113L184 132L174 292Q174 300 165 300H23Q15 300 14 292L4 132L25 102Q35 86 31 63L27 52Z",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "3"
				})
			}), r && i && /* @__PURE__ */ p("span", {
				className: "ms-preview-number",
				children: i.n
			})] }),
			(n.side === "A" ? D[t] !== void 0 : O[t] !== void 0) && /* @__PURE__ */ m("span", {
				className: `ms-label${u ? " ms-hit" : ""}`,
				children: [n.side === "A" ? D[t] : /* @__PURE__ */ p("img", {
					src: q(O[t]),
					alt: o(O[t])
				}), u && /* @__PURE__ */ p("span", { children: "✓" })]
			}),
			r && /* @__PURE__ */ p(_e, {})
		]
	});
}
function ye({ p: e, config: t, moves: n = [], preview: r, onPlace: i }) {
	let a = K();
	return /* @__PURE__ */ m("div", {
		className: "ms-shelf",
		"data-side": t.side,
		children: [[
			0,
			1,
			2
		].map((o) => /* @__PURE__ */ m("section", {
			className: `ms-level ms-level-${o}`,
			children: [/* @__PURE__ */ m("div", {
				className: "ms-level-meta",
				children: [/* @__PURE__ */ p("span", { children: o === 0 ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(X, { lid: "gold" }), /* @__PURE__ */ p(X, { lid: "blue" })] }) : o === 1 ? /* @__PURE__ */ m(f, { children: [
					/* @__PURE__ */ p(X, { lid: "gold" }),
					/* @__PURE__ */ p(X, { lid: "silver" }),
					/* @__PURE__ */ p(X, { lid: "blue" })
				] }) : /* @__PURE__ */ m(f, { children: [
					/* @__PURE__ */ p(X, { lid: "gold" }),
					/* @__PURE__ */ p(X, { lid: "silver" }),
					/* @__PURE__ */ p(X, { lid: "black" }),
					/* @__PURE__ */ p(X, { lid: "blue" })
				] }) }), /* @__PURE__ */ m("span", {
					title: a("rowBonus", { n: w[o] }),
					children: [
						e.rows.includes(o) && "✓ ",
						w[o],
						/* @__PURE__ */ p("span", {
							className: "ms-star",
							children: "★"
						}),
						" ",
						/* @__PURE__ */ p(Y, {})
					]
				})]
			}), /* @__PURE__ */ p("div", {
				className: "ms-spaces",
				children: Array.from({ length: 8 }, (a, s) => {
					let c = o * 8 + s;
					return /* @__PURE__ */ p(ve, {
						i: c,
						p: e,
						config: t,
						move: n.find((e) => e.cell === c),
						preview: r,
						onPlace: i
					}, c);
				})
			})]
		}, o)), /* @__PURE__ */ p("div", {
			className: "ms-column-marks",
			children: Array.from({ length: 8 }, (t, n) => /* @__PURE__ */ p("span", {
				className: e.columns.includes(n) ? "ms-complete-column" : "",
				title: a("rewardColumn"),
				children: e.columns.includes(n) ? "✦" : "◇"
			}, n))
		})]
	});
}
function be({ p: e, name: t, active: n, selected: r, onClick: i, color: a }) {
	let { ref: o } = s(`seat:${e.rid}`);
	return /* @__PURE__ */ m("button", {
		ref: o,
		type: "button",
		className: `ms-player${n ? " ms-active" : ""}${r ? " ms-viewing" : ""}`,
		onClick: i,
		"aria-pressed": r,
		style: { "--ms-seat": a },
		children: [
			/* @__PURE__ */ p("span", { className: "ms-seat-dot" }),
			/* @__PURE__ */ p("strong", { children: t }),
			/* @__PURE__ */ p(Y, {
				n: e.kittens,
				anchor: `cats:${e.rid}`
			})
		]
	});
}
//#endregion
//#region src/games/mortysorty/details.tsx
var Z = [
	"badge0",
	"badge1",
	"badge2",
	"badge3",
	"badge4",
	"badge5",
	"badge6",
	"badge7"
], xe = {
	mushroom: {
		I: "mushroomI",
		II: "mushroomII"
	},
	cloud: {
		I: "cloudI",
		II: "cloudII"
	},
	eyes: {
		I: "eyesI",
		II: "eyesII"
	},
	mandrake: {
		I: "mandrakeI",
		II: "mandrakeII"
	}
};
function Se({ id: e }) {
	let t = K(), n = [
		4,
		6,
		6,
		5,
		4,
		3,
		2,
		3
	][e], r = e === 2 ? [
		0,
		1,
		2,
		3,
		4,
		6
	] : e === 3 ? [
		1,
		3,
		4,
		5,
		7
	] : Array.from({ length: n }, (e, t) => t);
	return /* @__PURE__ */ m("div", {
		className: `ms-badge-art ms-badge-art-${e}`,
		"aria-label": t(Z[e]),
		children: [/* @__PURE__ */ m("svg", {
			viewBox: "0 0 180 150",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ p("path", {
					d: "M35 82 18 149 54 132 75 149 90 100 108 149 130 132 164 149 143 81",
					fill: "#a93e3a",
					stroke: "#5a292b",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "90",
					cy: "64",
					r: "60",
					fill: "#c4953d",
					stroke: "#f4d28a",
					strokeWidth: "5"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "90",
					cy: "64",
					r: "49",
					fill: "#f2d480",
					stroke: "#8c5f29",
					strokeWidth: "2"
				})
			]
		}), /* @__PURE__ */ p("div", {
			className: `ms-badge-diagram ms-badge-grid-${e}`,
			children: r.map((t, n) => e === 1 ? /* @__PURE__ */ p("span", {
				className: "ms-badge-label",
				children: "✓"
			}, n) : /* @__PURE__ */ p("span", {
				style: { gridArea: e === 2 || e === 3 ? `${Math.floor(t / 3) + 1} / ${t % 3 + 1}` : void 0 },
				children: /* @__PURE__ */ p(J, { jar: {
					id: n,
					n: e === 4 ? n + 5 : e === 5 ? 7 : n + 4,
					ingredient: e === 0 ? y[n] : e === 7 ? "mandrake" : "mushroom",
					lid: e === 3 ? "silver" : e === 6 ? "blue" : "gold"
				} })
			}, n))
		})]
	});
}
function Ce({ b: e, nameOf: t }) {
	let n = K(), { ref: r } = s(`badge:${e.id}`);
	return /* @__PURE__ */ m("div", {
		ref: r,
		className: "ms-badge",
		children: [/* @__PURE__ */ p(Se, { id: e.id }), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("h3", { children: n(Z[e.id]) }), /* @__PURE__ */ p("div", {
			className: "ms-ribbons",
			children: k[e.id].map((n, r) => /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ m("b", { children: [n, /* @__PURE__ */ p("span", {
				className: "ms-star",
				children: "★"
			})] }), /* @__PURE__ */ p("span", { children: e.claims.filter((e) => e.ribbon === r).map((e) => t(e.rid)).join(" · ") || "—" })] }, r))
		})] })]
	});
}
function we({ pub: e, nameOf: t }) {
	let n = K(), r = y.filter((t) => e.config[t] === "basic");
	return /* @__PURE__ */ m("div", {
		className: "ms-details",
		children: [
			/* @__PURE__ */ p("h2", { children: n("scrolls") }),
			/* @__PURE__ */ m("div", {
				className: "ms-scrolls",
				children: [r.length > 0 && /* @__PURE__ */ m("section", {
					className: "ms-scroll",
					children: [/* @__PURE__ */ p("div", {
						className: "ms-scroll-ingredients",
						children: r.map((e) => /* @__PURE__ */ p("img", {
							src: q(e),
							alt: n(e)
						}, e))
					}), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("h3", { children: n("basic") }), /* @__PURE__ */ p("p", { children: n("basicHelp") })] })]
				}), y.filter((t) => e.config[t] !== "basic").map((t) => /* @__PURE__ */ m("section", {
					className: "ms-scroll",
					children: [/* @__PURE__ */ p("img", {
						src: q(t),
						alt: ""
					}), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ m("h3", { children: [
						n(t),
						" · ",
						e.config[t]
					] }), /* @__PURE__ */ p("p", { children: n(xe[t][e.config[t]]) })] })]
				}, t))]
			}),
			e.badges.length > 0 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("h2", { children: n("badges") }), e.badges.map((e) => /* @__PURE__ */ p(Ce, {
				b: e,
				nameOf: t
			}, e.id))] }),
			/* @__PURE__ */ p("p", {
				className: "ms-supply",
				children: n("supply", { n: e.supply })
			})
		]
	});
}
//#endregion
//#region src/games/mortysorty/view-player.tsx
function Te({ jar: e, selected: t, available: n, ghost: r = !1, source: i, onClick: a }) {
	let o = K(), { ref: c } = s(`${i}:${e.id}`);
	return /* @__PURE__ */ m("button", {
		ref: c,
		type: "button",
		className: `ms-market-jar${t ? " ms-selected" : ""}${r ? " ms-ghost" : ""}`,
		disabled: !n || r,
		onClick: a,
		"aria-pressed": t,
		"aria-label": o("jar", {
			lid: o(e.lid),
			ingredient: o(e.ingredient),
			n: e.n
		}),
		children: [/* @__PURE__ */ p(J, { jar: e }), n && !t && /* @__PURE__ */ p(_e, {})]
	});
}
function Ee({ public: e, private: t, myRid: n, members: r, send: o }) {
	let h = e, g = t, _ = K(), v = a((e) => e.locale), y = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? u(t, v) : e;
	}, [b, S] = i(n), [C, w] = i(null), [T, E] = i(!1), [D, O] = i(!1), [k, A] = i(null), [j, M] = i({
		round: h.round,
		market: h.market,
		special: h.special
	});
	j.round === h.round ? (h.market.some((e) => !j.market.some((t) => t.id === e.id)) || h.special.some((e) => !j.special.some((t) => t.id === e.id))) && M({
		round: h.round,
		market: [...j.market, ...h.market.filter((e) => !j.market.some((t) => t.id === e.id))],
		special: [...j.special, ...h.special.filter((e) => !j.special.some((t) => t.id === e.id))]
	}) : M({
		round: h.round,
		market: h.market,
		special: h.special
	});
	let N = `${h.phase}:${h.round}:${h.turn}`, [ee, te] = i(N);
	ee !== N && (te(N), w(null), E(!1), O(!1));
	let P = g?.moves ?? [], F = h.players.find((e) => e.rid === n), I = h.players.find((e) => e.rid === b) ?? h.players[0], L = j.round === h.round ? j : {
		market: h.market,
		special: h.special
	}, R = [...h.market, ...h.special].find((e) => e.id === C), z = R ? {
		...R,
		ingredient: T ? x[R.ingredient] : R.ingredient
	} : void 0, ne = I.rid === n ? P.filter((e) => e.type === "place" && e.id === C && e.flip === T && e.equal === D) : [], re = (e, t) => h.turn === n && h.phase === t && P.some((t) => t.type === "place" && t.id === e.id), B = (e) => {
		w(C === e.id ? null : e.id), E(!1), O(!1), S(n);
	}, V = (e) => o(e), ie = h.phase === "stock" ? _("stock") : h.phase === "resolve" ? _("resolving") : h.phase === "done" ? _("done") : h.turn === n ? h.phase === "bonus" ? _("bonus") : _(C === null ? "yourTurn" : "selected") : _("waiting", { name: y(h.turn) }), { ref: ae } = s("market"), { ref: oe } = s("special"), { ref: H } = s("bag"), U = /* @__PURE__ */ m("div", {
		className: "ms-tools",
		children: [
			R && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("button", {
				type: "button",
				"aria-pressed": T,
				disabled: !F || F.kittens < 1 + Number(D),
				onClick: () => E(!T),
				children: [
					_("flip"),
					" ",
					/* @__PURE__ */ p(Y, { n: 1 })
				]
			}), /* @__PURE__ */ m("button", {
				type: "button",
				"aria-pressed": D,
				disabled: !F || F.kittens < 1 + Number(T),
				onClick: () => O(!D),
				children: [
					_("equal"),
					" ",
					/* @__PURE__ */ p(Y, { n: 1 })
				]
			})] }),
			P.some((e) => e.type === "pass") && /* @__PURE__ */ p("button", {
				type: "button",
				className: "ms-pass",
				onClick: () => V({ type: "pass" }),
				children: _("pass")
			}),
			h.phase === "bonus" && h.turn === n && /* @__PURE__ */ p("button", {
				type: "button",
				className: "ms-pass",
				onClick: () => V({ type: "kitten" }),
				children: _("takeKitten")
			})
		]
	});
	return /* @__PURE__ */ m("div", {
		className: "ms-screen",
		children: [/* @__PURE__ */ p(d, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ m("header", {
				className: "ms-header",
				children: [
					/* @__PURE__ */ m("div", {
						className: "ms-title",
						children: [/* @__PURE__ */ p("h1", { children: _("name") }), /* @__PURE__ */ p("span", {
							ref: H,
							className: "ms-round",
							children: _("round", { n: h.round })
						})]
					}),
					/* @__PURE__ */ p("nav", {
						className: "ms-players",
						"aria-label": _("shelf", { name: y(I.rid) }),
						children: h.players.map((e, t) => /* @__PURE__ */ p(be, {
							p: e,
							name: y(e.rid),
							color: l[r.find((t) => t.rid === e.rid)?.colorIndex ?? t].hex,
							active: h.turn === e.rid && h.phase !== "done",
							selected: I.rid === e.rid,
							onClick: () => S(e.rid)
						}, e.rid))
					}),
					/* @__PURE__ */ m("div", {
						className: "ms-status",
						children: [/* @__PURE__ */ p("span", {
							role: "status",
							children: ie
						}), /* @__PURE__ */ m("div", { children: [
							I.rid !== n && F && /* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => S(n),
								children: _("ownShelf")
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => A("details"),
								children: _("details")
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => A("log"),
								children: _("log")
							})
						] })]
					})
				]
			}),
			children: /* @__PURE__ */ m("main", {
				className: "ms-arena",
				children: [/* @__PURE__ */ p("section", {
					className: "ms-shelf-zone",
					"aria-label": _("shelf", { name: y(I.rid) }),
					children: /* @__PURE__ */ p(ye, {
						p: I,
						config: h.config,
						moves: ne,
						preview: z,
						onPlace: V
					})
				}), /* @__PURE__ */ m("div", {
					className: "ms-market-panel",
					children: [
						/* @__PURE__ */ m("div", {
							ref: ae,
							className: "ms-market",
							children: [
								/* @__PURE__ */ p("h2", { children: _("market") }),
								/* @__PURE__ */ p("div", {
									className: "ms-display",
									children: L.market.map((e) => /* @__PURE__ */ p(Te, {
										jar: C === e.id && z ? z : e,
										selected: C === e.id,
										available: re(e, "draft"),
										ghost: !h.market.some((t) => t.id === e.id),
										source: "market",
										onClick: () => B(e)
									}, e.id))
								}),
								h.phase === "bonus" ? /* @__PURE__ */ p("div", { className: "ms-tools" }) : U
							]
						}),
						/* @__PURE__ */ m("div", {
							ref: oe,
							className: `ms-special${h.phase === "bonus" ? " ms-bonus-active" : ""}`,
							children: [
								/* @__PURE__ */ p("h2", { children: _("special") }),
								/* @__PURE__ */ m("div", {
									className: "ms-special-list",
									children: [L.special.map((e) => /* @__PURE__ */ p(Te, {
										jar: C === e.id && z ? z : e,
										selected: C === e.id,
										available: re(e, "bonus"),
										ghost: !h.special.some((t) => t.id === e.id),
										source: "special",
										onClick: () => B(e)
									}, e.id)), L.special.length === 0 && /* @__PURE__ */ p("p", { children: _("emptySpecial") })]
								}),
								h.phase === "bonus" ? U : /* @__PURE__ */ p("div", { className: "ms-tools" })
							]
						}),
						/* @__PURE__ */ p("aside", {
							className: "ms-desktop-details",
							children: /* @__PURE__ */ p(we, {
								pub: h,
								nameOf: y
							})
						})
					]
				})]
			})
		}), /* @__PURE__ */ p(c, {
			open: k !== null,
			onClose: () => A(null),
			label: _(k === "log" ? "log" : "details"),
			title: _(k === "log" ? "log" : "details"),
			children: /* @__PURE__ */ p("div", {
				className: "ms-sheet",
				children: k === "log" ? /* @__PURE__ */ p("ol", {
					className: "ms-log",
					children: h.log.map((e, t) => /* @__PURE__ */ p("li", { children: e.kind === "place" ? _("logPlace", {
						name: y(e.rid),
						ingredient: e.ingredient ? _(e.ingredient) : "",
						n: e.n ?? 0
					}) : e.kind === "pass" ? _("logPass", { name: y(e.rid) }) : e.kind === "kitten" ? _("logKitten", {
						name: y(e.rid),
						n: e.n ?? 0
					}) : e.kind === "row" ? _("logRow", {
						name: y(e.rid),
						n: e.n ?? 0
					}) : e.kind === "badge" ? _("logBadge", {
						name: y(e.rid),
						badge: _(Z[e.badge])
					}) : e.kind === "round" ? _("logRound", { n: e.n ?? 0 }) : _("logEnd") }, t))
				}) : /* @__PURE__ */ p(we, {
					pub: h,
					nameOf: y
				})
			})
		})]
	});
}
//#endregion
//#region src/games/mortysorty/bot.ts
var De = {
	score: 1,
	space: 1.2,
	column: 2.5,
	label: 1.5,
	badge: 2,
	kitten: 1.5,
	placement: 4
};
function Oe(e = De) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid), a = t.private?.moves ?? [];
		if (!i || !a.length) return null;
		let o = a[0], s = -Infinity;
		for (let t of a) {
			if (t.type !== "place") {
				let e = r.supply > 0 ? 2 : 0;
				e > s && (o = t, s = e);
				continue;
			}
			let a = (r.phase === "draft" ? r.market : r.special).find((e) => e.id === t.id), c = {
				...a,
				ingredient: t.flip ? x[a.ingredient] : a.ingredient
			}, l = {
				...i,
				shelf: [...i.shelf],
				kittens: i.kittens - Number(t.flip) - Number(t.equal)
			};
			l.shelf[t.cell] = c;
			let u = Math.floor(t.cell / 8), d = t.cell % 8, f = H(r.players.map((e) => e.rid === l.rid ? l : e), r.config, r.badges)[l.rid].total - r.scores[i.rid].total, p = c.lid === "gold" || c.lid === "blue" ? 3 : c.lid === "silver" ? 2 : 1, m = (c.n - p) * 7 / (17 - 2 * p), h = -Math.abs(d - m), g = l.shelf.slice(u * 8, u * 8 + 8);
			for (let e = 0; e < 8; e++) if (e !== d && g[e]) {
				let t = Math.abs(e - d) - 1, n = Math.abs(g[e].n - c.n) - 1;
				t > n && n >= 0 && (h -= (t - n) * .7);
			}
			let _ = [
				d,
				d + 8,
				d + 16
			].map((e) => l.shelf[e]), v = new Set(_.filter(Boolean).map((e) => e.ingredient)).size, y = v === 3 ? 3 : +(v === 2), b = r.config.side === "A" ? D[t.cell] === c.n : O[t.cell] === c.ingredient, S = r.badges.filter((e) => !e.claims.some((e) => e.rid === i.rid) && te(e.id, l, r.config)).length, C = e.score * f + e.space * h + e.column * y + e.label * Number(b) + e.badge * S + e.placement - e.kitten * (Number(t.flip) + Number(t.equal)), w = n.difficulty === "weak" ? 3 - Math.abs(d - m) - 2 * (Number(t.flip) + Number(t.equal)) : C;
			w > s && (s = w, o = t);
		}
		return { action: o };
	};
}
var ke = Oe();
//#endregion
//#region src/games/mortysorty/fx.tsx
function Q({ at: e, ms: t }) {
	let i = r(null);
	return n(() => {
		let e = i.current?.animate([
			{
				opacity: 0,
				transform: "scale(.9)"
			},
			{
				opacity: .9,
				transform: "scale(1.04)",
				offset: .3
			},
			{
				opacity: 0,
				transform: "scale(1.08)"
			}
		], {
			duration: t,
			easing: "ease-out"
		});
		return () => e?.cancel();
	}, [t]), /* @__PURE__ */ p("div", {
		ref: i,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			border: "3px solid #f4d188",
			borderRadius: 8,
			boxShadow: "0 0 18px #eecf7955"
		}
	});
}
function Ae({ original: e, jar: t, flip: a, ms: o }) {
	let s = r(null), [c, l] = i(!1);
	return n(() => {
		if (!a) return;
		let e = s.current?.animate([
			{ transform: "rotateY(0deg)" },
			{
				transform: "rotateY(90deg)",
				offset: .5
			},
			{ transform: "rotateY(0deg)" }
		], {
			duration: o,
			easing: "ease-in-out"
		}), t = window.setTimeout(() => l(!0), o / 2);
		return () => {
			e?.cancel(), window.clearTimeout(t);
		};
	}, [a, o]), /* @__PURE__ */ p("div", {
		ref: s,
		style: {
			width: "100%",
			height: "100%"
		},
		children: /* @__PURE__ */ p(J, { jar: a && !c ? e : t })
	});
}
var $ = (e, t, n) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), je = {
	place(e, t) {
		let n = e.data, r = t.anchor(`jar:${e.rid}:${n.cell}`) ?? t.anchor(`seat:${e.rid}`), i = t.anchor(`${n.source}:${n.jar.id}`) ?? t.anchor(n.source);
		if (!r || !i) return null;
		let a = $(i, Math.min(i.w, i.h * 188 / 303), Math.min(i.h, i.w * 303 / 188)), o = $(r, Math.min(r.w, r.h * 188 / 303), Math.min(r.h, r.w * 303 / 188)), s = t.queued ? 170 : U.place, c = t.anchor(`cats:${e.rid}`);
		return {
			ms: s,
			hide: t.queued ? [] : [`jar:${e.rid}:${n.cell}`],
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(h, {
				from: a,
				to: o,
				ms: s,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: a.w,
						height: a.h
					},
					children: /* @__PURE__ */ p(Ae, {
						original: n.original,
						jar: n.jar,
						flip: n.flip,
						ms: s
					})
				})
			}), c && n.cost > 0 && /* @__PURE__ */ p(h, {
				from: $(c, 26, 30),
				to: $(i, 26, 30),
				ms: s,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: 26,
						height: 30,
						background: "#e7d3a6",
						borderRadius: 12,
						display: "grid",
						placeItems: "center"
					},
					children: /* @__PURE__ */ p(Y, { n: n.cost })
				})
			})] })
		};
	},
	draw(e, t) {
		let n = e.data, r = `${n.special ? "special" : "market"}:${n.jar.id}`, i = t.anchor(r), a = t.anchor("bag");
		if (!i || !a) return null;
		let o = Math.min(i.w, i.h * 188 / 303), s = o * 303 / 188, c = U.draw;
		return {
			ms: c,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ p(h, {
				from: $(a, o * .5, s * .5),
				to: $(i, o, s),
				ms: c,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: o * .5,
						height: s * .5
					},
					children: /* @__PURE__ */ p(J, { jar: n.jar })
				})
			})
		};
	},
	kitten(e, t) {
		let n = e.data, r = t.anchor(`cats:${e.rid}`), i = t.anchor("special");
		return !r || !i || !n.n ? null : {
			ms: U.award,
			node: /* @__PURE__ */ p(h, {
				from: $(i, 28, 34),
				to: $(r, 28, 34),
				ms: U.award,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: 28,
						height: 34,
						borderRadius: 10,
						background: "#e9d9ab",
						display: "grid",
						placeItems: "center"
					},
					children: /* @__PURE__ */ p(Y, {})
				})
			})
		};
	},
	reward(e, t) {
		let n = e.data, r = t.anchor(`cell:${e.rid}:${n.row * 8 + 7}`), i = t.anchor(`cats:${e.rid}`);
		return i ? {
			ms: U.award,
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(Q, {
				at: r ?? i,
				ms: U.award
			}), r && n.n > 0 && /* @__PURE__ */ p(h, {
				from: $(r, 28, 34),
				to: $(i, 28, 34),
				ms: U.award,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: 28,
						height: 34,
						background: "#e9d9ab",
						borderRadius: 10,
						display: "grid",
						placeItems: "center"
					},
					children: /* @__PURE__ */ p(Y, {})
				})
			})] })
		} : null;
	},
	badge(e, t) {
		let n = e.data, r = t.anchor(`badge:${n.badge}`) ?? t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: U.award,
			node: /* @__PURE__ */ p(Q, {
				at: r,
				ms: U.award
			})
		} : null;
	},
	column(e, t) {
		let n = e.data, r = t.anchor(`cell:${e.rid}:${n.column + 8}`) ?? t.anchor("special");
		return r ? {
			ms: U.award,
			node: /* @__PURE__ */ p(Q, {
				at: r,
				ms: U.award
			})
		} : null;
	},
	finish(e, t) {
		let n = t.anchor("ending") ?? t.anchor("market");
		return n ? {
			ms: U.end,
			node: /* @__PURE__ */ p(Q, {
				at: n,
				ms: U.end
			})
		} : null;
	}
};
//#endregion
//#region src/games/mortysorty/game-over.tsx
function Me({ public: e, result: t, members: n, myRid: r, onPlayAgain: c, onBackToLobby: l }) {
	let d = e, h = K(), g = o(), _ = a((e) => e.locale), { ref: v } = s("ending"), [b, x] = i(!1), [S, C] = i(r), w = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? u(t, _) : e;
	}, T = d.players.find((e) => e.rid === S) ?? d.players[0], E = [
		...y,
		"labels",
		"rows",
		"kittens",
		"badges"
	];
	return /* @__PURE__ */ m("div", {
		className: "ms-screen ms-ending",
		children: [
			/* @__PURE__ */ m("header", {
				ref: v,
				className: "ms-ending-header",
				children: [/* @__PURE__ */ p("span", {
					className: "ms-graduation-seal",
					children: "★"
				}), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("h1", { children: h("result") }), /* @__PURE__ */ p("p", { children: h(t.winner.length > 1 ? "tied" : "winner", { name: t.winner.map(w).join(" · ") }) })] })]
			}),
			/* @__PURE__ */ p("div", {
				className: "ms-ending-body",
				children: b ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("nav", {
					className: "ms-review-tabs",
					children: d.players.map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						"aria-pressed": e.rid === T.rid,
						onClick: () => C(e.rid),
						children: [
							w(e.rid),
							" ",
							/* @__PURE__ */ p(Y, { n: e.kittens })
						]
					}, e.rid))
				}), /* @__PURE__ */ p("div", {
					className: "ms-review-shelf",
					children: /* @__PURE__ */ p(ye, {
						p: T,
						config: d.config
					})
				})] }) : /* @__PURE__ */ p("div", {
					className: "ms-score-scroll",
					children: /* @__PURE__ */ m("table", {
						className: "ms-score-table",
						children: [/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: h("result") }), t.ranking.map((e) => /* @__PURE__ */ m("th", {
							className: t.winner.includes(e) ? "ms-winner" : "",
							children: [t.winner.includes(e) && /* @__PURE__ */ p("span", {
								className: "ms-star",
								children: "★ "
							}), w(e)]
						}, e))] }) }), /* @__PURE__ */ m("tbody", { children: [E.map((e) => /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ m("th", { children: [y.includes(e) && /* @__PURE__ */ p("img", {
							src: q(e),
							alt: ""
						}), h(e)] }), t.ranking.map((t) => /* @__PURE__ */ p("td", { children: d.scores[t][e] }, t))] }, e)), /* @__PURE__ */ m("tr", {
							className: "ms-total",
							children: [/* @__PURE__ */ p("th", { children: h("total") }), t.ranking.map((e) => /* @__PURE__ */ p("td", { children: d.scores[e].total }, e))]
						})] })]
					})
				})
			}),
			/* @__PURE__ */ m("footer", {
				className: "ms-ending-actions",
				children: [
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => x(!b),
						children: h(b ? "showScores" : "review")
					}),
					c && /* @__PURE__ */ p("button", {
						type: "button",
						className: "ms-primary",
						onClick: c,
						children: g("session.result.playAgain")
					}),
					l && /* @__PURE__ */ p("button", {
						type: "button",
						onClick: l,
						children: g("session.result.backToLobby")
					}),
					!c && !l && /* @__PURE__ */ p("p", { children: g("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/mortysorty/options.tsx
function Ne({ value: e, onChange: t }) {
	let n = R.parse(e), r = K(), i = (e) => t({
		...n,
		...e
	});
	return /* @__PURE__ */ m("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ p(_, {
				title: r("side"),
				children: ["A", "B"].map((e) => /* @__PURE__ */ p(g, {
					name: "ms-side",
					value: e,
					checked: n.side === e,
					label: r(e === "A" ? "sideA" : "sideB"),
					onChange: () => i({ side: e })
				}, e))
			}),
			/* @__PURE__ */ p(v, {
				label: r("useBadges"),
				checked: n.badges,
				onChange: () => i({ badges: !n.badges })
			}),
			n.badges && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(v, {
				label: r("random"),
				checked: !n.badgeFaces,
				onChange: () => i({ badgeFaces: n.badgeFaces ? void 0 : [0, 2] })
			}), n.badgeFaces && [0, 1].map((e) => /* @__PURE__ */ p(_, {
				title: r("badgeChoice"),
				children: Z.map((t, a) => /* @__PURE__ */ p(g, {
					name: `ms-badge-${e}`,
					value: String(a),
					label: r(t),
					checked: n.badgeFaces?.[e] === a,
					disabled: Math.floor(n.badgeFaces[1 - e] / 2) === Math.floor(a / 2),
					onChange: () => {
						let t = [...n.badgeFaces];
						t[e] = a, i({ badgeFaces: t });
					}
				}, a))
			}, e))] }),
			/* @__PURE__ */ p(_, {
				title: r("preset"),
				columns: 3,
				children: [
					"basic",
					"I",
					"II"
				].map((e) => /* @__PURE__ */ p(g, {
					name: "ms-preset",
					value: e,
					checked: y.every((t) => n[t] === e),
					label: r(e === "basic" ? "basic" : e === "I" ? "modeI" : "modeII"),
					onChange: () => i({
						mushroom: e,
						cloud: e,
						eyes: e,
						mandrake: e
					})
				}, e))
			}),
			y.map((e) => /* @__PURE__ */ p(_, {
				title: r(e),
				columns: 3,
				children: [
					"basic",
					"I",
					"II"
				].map((t) => /* @__PURE__ */ p(g, {
					name: `ms-mode-${e}`,
					value: t,
					checked: n[e] === t,
					label: r(t === "basic" ? "basic" : t === "I" ? "modeI" : "modeII"),
					hint: t === "basic" ? void 0 : r(xe[e][t]),
					onChange: () => i({ [e]: t })
				}, t))
			}, e))
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/mortysorty/entry.tsx
var Pe = {
	definition: me,
	View: Ee,
	bot: ke,
	fx: je,
	OverView: Me,
	Options: Ne,
	locales: {
		zh: {
			name: "Morty Sorty Magic Shop",
			desc: "在魔法商店的三层货架上整理罐子，借助小猫收集最出色的魔法材料。",
			errAction: "当前不能执行这个动作，请重新选择。",
			rules: "目标：\n在三层货架中按数字顺序摆放魔法材料罐，争取最多星星。2–4 人游戏，使用 Schmidt Spiele 2026 年基础版规则。\n准备：\n所有玩家使用同一面货架，各领取 2 只猫。104 枚双面罐分为蘑菇与云、眼睛与曼德拉草两类配对，正反面数字和盖色相同。每类配对各有黑盖 1–16、银盖 2–15、金盖 3–14、蓝盖 4–13。罐的初始朝向随机，不能免费翻面。随机移除 4 枚罐；2 人时改为移除 23 枚。袋内和盒内的罐不可查看或计数。可使用随机两块徽章，也可在开局设置中选择目标；同一实物徽章的两面不能同时使用。\n每轮流程：\n公开抽出 5 枚普通盖罐组成市场，2 人时为 4 枚。抽到蓝盖罐时，将它移入公共特殊罐区，再继续抽。轮到自己时，从市场拿取 1 枚罐并立即放入货架，或放弃拿罐并领取 1 只猫。每人行动一次后，市场剩余罐永久移除，由下一位玩家成为起始玩家。不能凑齐完整市场时立即结束，不进行不完整轮。\n摆放规则：\n· 罐只能放在空格。每行数字必须从左到右递增，即使中间有空格也必须维持顺序。\n· 金盖和蓝盖可放任意一行，银盖只能放中行或下行，黑盖只能放下行。\n放置新领取的罐时，可以使用以下猫的能力：\n· 返还 1 只猫，将该罐翻至另一种材料的一面。\n· 返还 1 只猫，将该罐放在同数字罐紧邻的左侧空格或右侧空格。\n可以支付 2 只猫，同时使用这两种效果。已经放入货架的罐不能翻面。\n· 填满一行，立即领取 1 只猫；终局该行另获星星：上行 10、中行 6、下行 4。\n· 填满一列且有三种不同材料，立即从特殊罐区拿取 1 枚蓝盖罐并按同样规则摆放，或改领 1 只猫。蓝罐可以继续触发其他列的奖励。每列只奖励一次。\n猫的供应总计 16 只，支付的猫回到供应。供应空时不能领取，也不保留欠账。终局每只剩余猫获得 2 星。\n货架标签：\nA 面按命中数字标签总数计分：0–9 个分别获得 0、2、4、6、8、12、16、20、24、30 星。B 面每种材料各有两个标签，两处都放对该材料时获得 6 星。标签格允许放不匹配的罐。\n徽章：\n达成目标立即领取最左侧空绶带的奖励。同轮达成者共占一条绶带，均获完整奖励；第一条绶带的达成者额外领取 1 只猫。每人每枚徽章只能领取一次，三条绶带占满后不能再领取。\n· 下行拥有全部四种材料，或命中至少 6 个标签：三条绶带的奖励依次为 5 星、4 星和 2 星。\n· 上行至少有 3 枚金盖罐、中行至少有 2 枚金盖罐、下行至少有 1 枚金盖罐，或至少 5 枚银盖罐正交连成一组，即达成该徽章条件。三条绶带的奖励依次为 6 星、5 星和 3 星。\n· 同一行连续四格为连续递增数字，或一列三个数字相同：三条绶带的奖励依次为 7 星、6 星和 4 星。\n· 一列至少两枚蓝盖罐，或一列三枚罐的材料相同：三条绶带的奖励依次为 8 星、7 星和 5 星。\n材料计分：\n基础卷轴中，每种材料有 0–10 枚时分别获得 0、1、3、6、10、15、21、28、36、46、60 星，超过 10 枚仍为 60 星。进阶卷轴可全用 I、全用 II，或按材料混用，也可部分保留基础计分。\n· 蘑菇 I：每枚 3 星，每行至少 3 枚蘑菇额外获得 10 星。\n· 蘑菇 II：只统计上下左右均没有其他蘑菇相邻的蘑菇罐。0–9 枚分别获得 0、2、5、9、15、23、33、45、59、75 星，更多仍为 75 星。\n· 云 I：每枚 4 星，所有玩家中最大的云正交连组额外获得 14 星、第二大的不同大小连组额外获得 6 星。连组至少两枚，同一玩家可获得多项，同大小连组均获对应奖励。\n· 云 II：每枚 2 星，每行云数量最多者额外获得上行 14、中行 10、下行 8 星；正数平手者均获全额，整行没有云则不颁发该行奖励。\n· 眼睛 I：将眼睛罐的数量乘以货架上全部黑盖罐的数量，获得等于计算结果的星星。\n· 眼睛 II：分别统计金盖罐和银盖罐的数量，取两者中较小的数，再乘以眼睛罐的数量，获得等于计算结果的星星。\n· 曼德拉草 I：不同数字有 0–10 种时分别获得 0、2、5、9、14、20、27、35、45、57、72 星，更多仍为 72 星。\n· 曼德拉草 II：每枚获得 4 星。同一数字有两枚时，额外获得 4 星；有三枚时，额外获得 12 星；有四枚时，额外获得 32 星。同一数字只领取与该组总枚数对应的奖励。\n结束与胜负：\n合计四种材料、标签、满行、剩余猫和徽章的星星。总分最高者获胜；平手时比较各自得分最高的一种材料，仍相同则共享胜利。",
			mushroom: "蘑菇",
			cloud: "云",
			eyes: "眼睛",
			mandrake: "曼德拉草",
			black: "黑盖",
			silver: "银盖",
			gold: "金盖",
			blue: "蓝盖",
			round: "第 {{n}} 轮",
			yourTurn: "选择一枚罐子",
			waiting: "等待 {{name}}",
			stock: "补充市场",
			resolving: "发放奖励",
			bonus: "选择一枚特殊罐，或领取猫",
			done: "整理完成",
			market: "本轮市场",
			special: "特殊罐",
			pass: "放弃拿罐，领取猫",
			takeKitten: "改为领取猫",
			flip: "翻面",
			equal: "相同数字",
			cost: "支付 {{n}} 只猫",
			cats: "{{n}} 只猫",
			supply: "猫供应：{{n}}",
			shelf: "{{name}}的货架",
			ownShelf: "返回我的货架",
			cell: "第 {{row}} 行第 {{col}} 格",
			jar: "{{lid}} · {{ingredient}} {{n}}",
			place: "放入第 {{row}} 行第 {{col}} 格",
			top: "上行",
			middle: "中行",
			bottom: "下行",
			rowBonus: "满行 {{n}} 星及 1 只猫",
			badges: "徽章",
			scrolls: "计分卷轴",
			details: "计分与徽章",
			close: "关闭",
			selected: "选择落位",
			noSelected: "先选择市场中的罐子",
			log: "操作记录",
			points: "{{n}} 星",
			labels: "标签",
			rows: "满行",
			kittens: "猫",
			total: "总分",
			result: "学徒结业",
			winner: "{{name}}获胜",
			tied: "{{name}}共享胜利",
			review: "查看最终货架",
			showScores: "返回计分",
			badge0: "下行四种材料",
			badge1: "命中六个标签",
			badge2: "金盖上三中二下一",
			badge3: "五枚银盖相连",
			badge4: "一行四个连续数字",
			badge5: "一列三个相同数字",
			badge6: "一列两枚蓝盖",
			badge7: "一列三枚同种材料",
			ribbon: "第 {{n}} 条绶带",
			unclaimed: "尚未领取",
			side: "货架面",
			sideA: "A · 数字标签",
			sideB: "B · 材料标签",
			useBadges: "使用徽章",
			badgeChoice: "徽章组合",
			random: "随机选择",
			advanced: "材料计分",
			basic: "基础",
			modeI: "进阶 I",
			modeII: "进阶 II",
			preset: "卷轴组合",
			custom: "逐项选择",
			basicHelp: "每种材料 0–10 枚：0 / 1 / 3 / 6 / 10 / 15 / 21 / 28 / 36 / 46 / 60 星。",
			mushroomI: "每枚 3 星；每行至少三枚额外获得 10 星。",
			mushroomII: "只数不正交相邻的蘑菇：0 / 2 / 5 / 9 / 15 / 23 / 33 / 45 / 59 / 75 星。",
			cloudI: "每枚 4 星；最大与次大云连组额外获得 14 / 6 星。",
			cloudII: "每枚 2 星；逐行云最多者额外获得上 14、中 10、下 8 星。",
			eyesI: "眼睛数量乘以全部黑盖罐数量。",
			eyesII: "眼睛数量乘以金盖与银盖罐总数中较小的一项。",
			mandrakeI: "不同数字数计分：0 / 2 / 5 / 9 / 14 / 20 / 27 / 35 / 45 / 57 / 72 星。",
			mandrakeII: "每枚 4 星；同数字两 / 三 / 四枚额外获得 4 / 12 / 32 星。",
			logPlace: "{{name}}放入{{ingredient}} {{n}}。",
			logPass: "{{name}}放弃拿罐。",
			logKitten: "{{name}}领取 {{n}} 只猫。",
			logRow: "{{name}}填满一行，领取 {{n}} 只猫。",
			logBadge: "{{name}}达成「{{badge}}」。",
			logRound: "第 {{n}} 轮开始。",
			logEnd: "市场无法补齐，游戏结束。",
			hintPlace: "将{{ingredient}} {{n}} 放入第 {{row}} 行第 {{col}} 格。",
			hintPass: "放弃拿罐，领取一只猫。",
			hintKitten: "放弃特殊罐，领取一只猫。",
			emptySpecial: "尚无特殊罐",
			rowRestriction: "{{lids}}",
			rewardColumn: "三种材料满列"
		},
		en: {
			name: "Morty Sorty Magic Shop",
			desc: "Stock three magical shelves in number order, using kittens to collect the finest ingredients.",
			errAction: "That action is unavailable. Please choose again.",
			rules: "Goal:\nEarn the most stars by stocking three shelves with magical jars in number order. For 2–4 players, using the Schmidt Spiele 2026 base game.\nSetup:\nEveryone uses the same shelf side and starts with 2 kittens. The 104 double-sided jars pair toadstools with clouds, and eyes with mandrakes. Both sides have the same number and lid. Each pair has black lids 1–16, silver 2–15, gold 3–14 and blue 4–13. Starting faces are random; jars cannot be flipped for free. Remove 4 random jars, or 23 with two players. Never inspect or count jars in the bag or box. Use two random badges or choose their faces in setup; opposite sides of one physical badge cannot both be used.\nRounds:\nDraw a display of 5 ordinary jars, or 4 with two players. Put blue lids in the shared special jar area and keep drawing until the ordinary display is full. On your turn, take and place one ordinary jar, or pass and take one kitten. After everyone acts once, remove the leftovers permanently and pass the starting player clockwise. If a full display cannot be formed, the game ends immediately without playing a partial round.\nPlacement:\n· Use an empty space. Numbers must ascend from left to right on each level, even across gaps.\n· Gold and blue lids fit any level. Silver fits the middle and bottom. Black fits only the bottom.\n· Return one kitten to flip the jar you just took. Return one kitten to place it immediately left or right of a jar with the same number. Pay two kittens to use both effects. Jars already on your shelf cannot be flipped.\n· Filling a level immediately earns one kitten, plus stars at game end: top 10, middle 6, bottom 4.\n· Filling a column with three different ingredients lets you take and place one special blue-lid jar, following the same placement rules, or take one kitten instead. Special jars may trigger further column rewards. Each column rewards only once.\nThere are 16 kittens in total. Spent kittens return to the supply. An empty supply gives no kitten and no debt. Each remaining kitten is worth 2 stars at game end.\nShelf labels:\nSide A awards 0 / 2 / 4 / 6 / 8 / 12 / 16 / 20 / 24 / 30 stars for 0–9 matching number labels. Side B awards 6 stars for each ingredient whose two labelled spaces both contain that ingredient. You may place nonmatching jars on labelled spaces.\nBadges:\nAs soon as you meet a badge, claim its leftmost available ribbon. Players reaching it in the same round share one ribbon and receive its full reward. Claimants of the first ribbon also take one kitten. Each badge can be claimed once per player; after all three ribbons are occupied, no further claims are possible.\n· All four ingredients on the bottom level, or six matching labels: ribbons worth 5 / 4 / 2 stars.\n· At least 3 / 2 / 1 gold lids on the top / middle / bottom level, or an orthogonally connected group of five silver lids: 6 / 5 / 3 stars.\n· Four consecutive spaces on a level with consecutive ascending numbers, or three identical numbers in a column: 7 / 6 / 4 stars.\n· At least two blue lids in a column, or three identical ingredients in a column: 8 / 7 / 5 stars.\nIngredient scoring:\nBasic scrolls award 0 / 1 / 3 / 6 / 10 / 15 / 21 / 28 / 36 / 46 / 60 stars per ingredient for 0–10 jars. Ten or more score 60. Advanced scrolls may all use set I, set II, or be mixed per ingredient, including basic scoring.\n· Toadstool I: 3 stars each, plus 10 per level with at least three toadstools.\n· Toadstool II: count only toadstools with no orthogonally adjacent toadstool; 0–9 score 0 / 2 / 5 / 9 / 15 / 23 / 33 / 45 / 59 / 75. More still score 75.\n· Cloud I: 4 stars each. Across all shelves, the largest connected cloud groups add 14 stars and the next distinct smaller size adds 6. Groups need at least two jars; one player may score multiple groups, and equal sizes receive the same award.\n· Cloud II: 2 stars each; most clouds on each level adds top 14, middle 10, bottom 8. Positive ties receive full awards; an empty level awards nothing.\n· Eyes I: number of eyes multiplied by all black lids on your shelf.\n· Eyes II: number of eyes multiplied by the smaller of your total gold and silver lid counts.\n· Mandrake I: 0–10 distinct numbers score 0 / 2 / 5 / 9 / 14 / 20 / 27 / 35 / 45 / 57 / 72; more still score 72.\n· Mandrake II: each jar scores 4 stars. A group of two jars with the same number scores 4 additional stars; three score 12 additional stars, and four score 32 additional stars. For each number, take only the bonus matching the whole group’s size.\nEnd and victory:\nSum the four ingredients, labels, completed levels, kittens and badges. Highest total wins. Break ties by the highest score for a single ingredient; if still tied, share victory.",
			mushroom: "Toadstool",
			cloud: "Cloud",
			eyes: "Eyes",
			mandrake: "Mandrake",
			black: "Black lid",
			silver: "Silver lid",
			gold: "Gold lid",
			blue: "Blue lid",
			round: "Round {{n}}",
			yourTurn: "Choose a jar",
			waiting: "Waiting for {{name}}",
			stock: "Restocking",
			resolving: "Awarding bonuses",
			bonus: "Choose a special jar or take a kitten",
			done: "Shelves complete",
			market: "Display",
			special: "Special jars",
			pass: "Pass, take kitten",
			takeKitten: "Take kitten instead",
			flip: "Flip",
			equal: "Equal number",
			cost: "Kittens spent: {{n}}",
			cats: "Kittens: {{n}}",
			supply: "Kitten supply: {{n}}",
			shelf: "{{name}}’s shelf",
			ownShelf: "My shelf",
			cell: "Level {{row}}, space {{col}}",
			jar: "{{lid}} · {{ingredient}} {{n}}",
			place: "Place on level {{row}}, space {{col}}",
			top: "Top",
			middle: "Middle",
			bottom: "Bottom",
			rowBonus: "Full: {{n}} stars + 1 kitten",
			badges: "Badges",
			scrolls: "Scoring scrolls",
			details: "Scoring & badges",
			close: "Close",
			selected: "Choose a space",
			noSelected: "Select a jar from the display",
			log: "Action log",
			points: "{{n}} stars",
			labels: "Labels",
			rows: "Full levels",
			kittens: "Kittens",
			total: "Total",
			result: "Apprentice graduation",
			winner: "{{name}} wins",
			tied: "{{name}} share victory",
			review: "View final shelves",
			showScores: "Back to scores",
			badge0: "Four bottom ingredients",
			badge1: "Six matching labels",
			badge2: "Gold: 3 top, 2 middle, 1 bottom",
			badge3: "Five connected silver lids",
			badge4: "Four consecutive numbers",
			badge5: "Three equal numbers in a column",
			badge6: "Two blue lids in a column",
			badge7: "Three same ingredients in a column",
			ribbon: "Ribbon {{n}}",
			unclaimed: "Unclaimed",
			side: "Shelf side",
			sideA: "A · Number labels",
			sideB: "B · Ingredient labels",
			useBadges: "Use badges",
			badgeChoice: "Badge selection",
			random: "Random",
			advanced: "Ingredient scoring",
			basic: "Basic",
			modeI: "Advanced I",
			modeII: "Advanced II",
			preset: "Scroll set",
			custom: "Choose individually",
			basicHelp: "Each ingredient, 0–10 jars: 0 / 1 / 3 / 6 / 10 / 15 / 21 / 28 / 36 / 46 / 60 stars.",
			mushroomI: "3 each; add 10 per level with at least three.",
			mushroomII: "Isolated toadstools: 0 / 2 / 5 / 9 / 15 / 23 / 33 / 45 / 59 / 75.",
			cloudI: "4 each; largest and next largest cloud groups add 14 / 6.",
			cloudII: "2 each; most per level adds top 14, middle 10, bottom 8.",
			eyesI: "Eyes multiplied by all black lids.",
			eyesII: "Eyes multiplied by the lower total of gold and silver lids.",
			mandrakeI: "Distinct numbers: 0 / 2 / 5 / 9 / 14 / 20 / 27 / 35 / 45 / 57 / 72.",
			mandrakeII: "4 each; equal-number groups of 2 / 3 / 4 add 4 / 12 / 32.",
			logPlace: "{{name}} placed {{ingredient}} {{n}}.",
			logPass: "{{name}} passed.",
			logKitten: "{{name}} received kittens: {{n}}.",
			logRow: "{{name}} completed a level. Kittens received: {{n}}.",
			logBadge: "{{name}} earned “{{badge}}”.",
			logRound: "Round {{n}} begins.",
			logEnd: "The display cannot be filled. Game over.",
			hintPlace: "Place {{ingredient}} {{n}} on level {{row}}, space {{col}}.",
			hintPass: "Pass and take a kitten.",
			hintKitten: "Decline the special jar and take a kitten.",
			emptySpecial: "No special jars yet",
			rowRestriction: "{{lids}}",
			rewardColumn: "Three different ingredients"
		}
	}
};
//#endregion
export { Pe as default };
