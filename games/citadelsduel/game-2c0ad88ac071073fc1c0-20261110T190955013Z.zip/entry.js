import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useEffect as r, useId as i, useLayoutEffect as a, useRef as o, useState as s } from "react";
import { AVATARS as c } from "@bgparty/sdk/avatars";
import { useFxAnchor as l, useFxAnchorsMaybe as u } from "@bgparty/sdk/fx/anchors";
import { usePrefersReducedMotion as d } from "@bgparty/sdk/fx/use-reduced-motion";
import { translate as f, useI18nSettings as p } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as m } from "@bgparty/sdk/player-colors";
import { SheetView as h } from "@bgparty/sdk/sheet-view";
import { GameScreen as g } from "@bgparty/sdk/ui/game-screen";
import { seatName as _ } from "@bgparty/sdk/ui/player-strip";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { Floater as x, FlySprite as S, PulseBox as C } from "@bgparty/sdk/fx/primitives";
//#region src/games/citadelsduel/data.ts
var w = [
	"noble",
	"religious",
	"commercial",
	"military",
	"unique"
], ee = {
	noble: "#d0a342",
	religious: "#508cac",
	commercial: "#4c9367",
	military: "#b9524d",
	unique: "#81559f"
}, T = /* @__PURE__ */ "Noble House.Religious House.Commercial House.Military House.Castle.Manor.Palace.Villa.Cathedral.Church.Monastery.Temple.Harbor.Market.Tavern.Trading Post.Barracks.Fortress.Prison.Watchtower.Armory.Capitol.Imperial Treasury.Ivory Tower.Library.Public House.School of Magic.Statue.Thieves’ Den.Wishing Well".split("."), E = [
	1,
	1,
	1,
	1,
	4,
	2,
	3,
	1,
	4,
	2,
	3,
	1,
	4,
	3,
	1,
	2,
	3,
	4,
	2,
	1,
	2,
	2,
	2,
	4,
	4,
	3,
	4,
	2,
	3,
	2
], D = T.map((e, t) => ({
	id: t,
	name: e,
	cost: E[t],
	color: t < 4 ? w[t] : t < 20 ? w[Math.floor((t - 4) / 4)] : "unique"
})), O = [
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9
], k = (e, t) => `${e},${t}`, A = {
	id: "citadelsduel",
	tier: "alpha",
	nameKey: "games.citadelsduel.name",
	descKey: "games.citadelsduel.desc",
	rulesKey: "games.citadelsduel.rules",
	mechanics: [
		"drafting",
		"tile-placement",
		"area-control"
	],
	interactionTags: ["hidden-roles"],
	icon: "🏰",
	iconImg: "games/citadelsduel.webp",
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#625079",
	releasedAt: "2026-11-10T23:54:00+08:00",
	hotseat: "cover",
	search: {
		py: "rong yao zhi cheng dui jue",
		init: "ryzcdj"
	},
	botDelayMs: 850
}, j = t.int(), te = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("select"),
		ids: t.array(j.min(0).max(29)).min(1).max(2)
	}),
	t.object({
		type: t.literal("act"),
		kind: t.enum([
			"skip",
			"gain",
			"guess",
			"steal",
			"guard",
			"coin",
			"build",
			"capture",
			"seats",
			"gold",
			"magic",
			"well"
		]),
		target: t.string().default(""),
		x: j.optional(),
		y: j.optional(),
		discount: t.boolean().optional()
	})
]), M = t.object({
	id: j.min(0).max(29),
	x: j,
	y: j,
	owner: t.string(),
	gold: j.nonnegative()
}), N = t.object({
	kind: t.string(),
	rid: t.string(),
	n: j.optional(),
	discount: j.optional(),
	used: t.array(t.string()).optional(),
	target: t.string().optional()
}), ne = t.object({
	phase: t.enum([
		"setup",
		"keep",
		"discard",
		"resolve",
		"expansion",
		"done"
	]),
	round: j,
	role: j,
	cells: t.array(M),
	guard: t.string().nullable(),
	supply: j.nonnegative(),
	markets: t.array(t.object({
		id: j.nullable(),
		count: j
	})),
	players: t.array(t.object({
		rid: t.string(),
		gold: j.nonnegative(),
		seats: j.min(0).max(9),
		handCount: j,
		uniqueCount: j,
		ready: t.boolean(),
		revealed: t.array(j)
	})),
	task: N.nullable(),
	actor: t.string().nullable(),
	magic: t.string().nullable(),
	last: t.object({
		seq: j,
		kind: t.string(),
		rid: t.string(),
		target: t.string(),
		from: t.string(),
		n: j
	}),
	scores: t.array(t.object({
		rid: t.string(),
		districts: j,
		gold: j,
		seats: j,
		total: j
	}))
}), re = t.object({
	hand: t.array(j),
	uniques: t.array(j),
	options: t.array(j),
	legal: t.array(te),
	passed: t.array(j)
}), P = (e, t) => e.players.find((e) => e !== t), F = (e, t) => e.players[0] === t ? e.seats : 9 - e.seats;
function I(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var L = (e, t, n = {}) => ({
	kind: e,
	rid: t,
	...n
}), R = (e, t = "", n = {}) => ({
	type: "act",
	kind: e,
	target: t,
	...n
});
function z(e, t, n, r = "", i = 0, a = "") {
	e.last = {
		seq: e.last.seq + 1,
		kind: t,
		rid: n,
		target: r,
		n: i,
		from: a
	};
}
function B(e, t, n) {
	let r = Math.min(n, e.supply);
	return e.gold[t] += r, e.supply -= r, r;
}
function V(e, t, n) {
	let r = Math.min(n, 9 - F(e, t));
	return e.seats += e.players[0] === t ? r : -r, r;
}
function H(e, t, n = !1) {
	return t.id === 26 && n && e.magic ? e.magic : D[t.id].color;
}
function U(e, t, n) {
	return e.cells.filter((r) => r.owner === t && H(e, r, !0) === n).length;
}
function W(e, t) {
	return Math.abs(e.x - t.x) + Math.abs(e.y - t.y) === 1;
}
function G(e, t, n) {
	let r = e.find((e) => k(e.x, e.y) === t);
	return !(!r || r !== n && !W(r, n));
}
function K(e, t) {
	return t.id !== 23 && !G(e.cells, e.guard, t);
}
function ie(e) {
	let t = [], n = e.map((e) => e.x), r = e.map((e) => e.y);
	for (let i of e) for (let [a, o] of [
		[1, 0],
		[-1, 0],
		[0, 1],
		[0, -1]
	]) {
		let s = i.x + a, c = i.y + o;
		e.some((e) => e.x === s && e.y === c) || t.some((e) => e.x === s && e.y === c) || Math.max(...n, s) - Math.min(...n, s) < 4 && Math.max(...r, c) - Math.min(...r, c) < 4 && t.push({
			x: s,
			y: c
		});
	}
	return t;
}
function q(e, t, n, r, i) {
	return n === 27 && e.cells.some((e) => e.owner === t && D[e.id].cost === 4 && W(e, r)) ? 0 : Math.max(0, D[n].cost - i);
}
function J(e, t) {
	if (!e.players.includes(t) || e.phase === "done") return [];
	if ([
		"setup",
		"keep",
		"discard"
	].includes(e.phase)) {
		if (e.selected[t]) return [];
		let n = e.phase === "setup" ? e.options[t] : e.hands[t];
		return e.phase === "discard" ? n.map((e) => ({
			type: "select",
			ids: [e]
		})) : n.flatMap((e, t) => n.slice(t + 1).map((t) => ({
			type: "select",
			ids: [e, t]
		})));
	}
	let n = e.tasks[0];
	if (!n || n.rid !== t) return [];
	let r = [
		"expansionGold",
		"treasury",
		"publicHouse",
		"capitol"
	].includes(n.kind) ? [] : [R("skip")], i = e.cells;
	switch (n.kind) {
		case "magic": return w.map((e) => R("magic", e));
		case "gold":
		case "expansionGold":
		case "seats":
		case "capitol":
		case "tribute":
		case "treasury":
		case "publicHouse":
			(n.kind !== "tribute" || e.gold[t] < e.gold[P(e, t)]) && (n.kind !== "publicHouse" || e.gold[t] < 3) && r.push(R("gain"));
			break;
		case "guess":
			O.filter((t) => t > e.role).forEach((e) => r.push(R("guess", String(e))));
			break;
		case "steal":
			e.gold[P(e, t)] > 0 && r.push(R("steal", "wallet")), i.filter((t) => t.gold > 0 && K(e, t)).forEach((e) => r.push(R("steal", k(e.x, e.y))));
			break;
		case "guard":
		case "armory":
			i.filter((t) => k(t.x, t.y) !== e.guard && (!n.target || n.target === k(t.x, t.y))).forEach((e) => r.push(R("guard", k(e.x, e.y))));
			break;
		case "kingCoin":
			e.supply > 0 && r.push(R("coin", n.target));
			break;
		case "merchant":
			e.supply > 0 && i.filter((r) => r.owner === t && H(e, r, !0) === "commercial" && !n.used?.includes(k(r.x, r.y))).forEach((e) => r.push(R("coin", k(e.x, e.y))));
			break;
		case "build": {
			let a = [...e.stacks.flatMap((e) => e.length ? [e[0]] : []), ...e.uniques[t]];
			for (let o of a) for (let a of ie(i)) for (let i of n.discount ? e.role === 6 && n.n !== void 0 ? [!1, !0] : [!0] : [!1]) q(e, t, o, a, n.discount && i ? n.discount : 0) <= e.gold[t] && r.push(R("build", String(o), {
				...a,
				discount: i
			}));
			break;
		}
		case "diplomat":
			r.push(R("seats")), i.filter((n) => n.owner !== t && K(e, n) && D[n.id].cost + n.gold <= F(e, t)).forEach((e) => r.push(R("capture", k(e.x, e.y))));
			break;
		case "warlord":
			i.filter((n) => n.owner !== t && K(e, n) && Math.max(0, D[n.id].cost + n.gold - U(e, t, "military")) <= e.gold[t]).forEach((e) => r.push(R("capture", k(e.x, e.y)))), i.filter((t) => k(t.x, t.y) !== e.guard).forEach((e) => r.push(R("guard", k(e.x, e.y))));
			break;
		case "den":
			i.filter((t) => t.gold > 0 && !G(i, e.guard, t)).forEach((e) => r.push(R("steal", k(e.x, e.y))));
			break;
		case "well":
			e.gold[t] > 0 && r.push(R("well"));
			break;
		case "expansion": r.push(R("gold")), e.cells.length < 16 && r.push(...J({
			...e,
			tasks: [L("build", t)]
		}, t).filter((e) => e.type === "act" && e.kind === "build"));
	}
	return r;
}
function ae(e) {
	e.phase = "keep", e.round++, e.role = 0, e.tasks = [], e.selected = {}, e.magic = null;
	let t = I(e, O);
	e.players.forEach((n, r) => {
		e.hands[n] = t.slice(r * 4, r * 4 + 4), e.revealed[n] = [], e.passed[n] = [];
	}), z(e, "deal", "");
}
function oe(e, t) {
	switch (e.role) {
		case 1:
		case 2: return [L("guess", t)];
		case 3: return [L("seats", t, { n: 1 + U(e, t, "noble") }), L("guard", t)];
		case 4: return [L("tribute", t), L("build", t, { discount: U(e, t, "religious") })];
		case 5: return [L("gold", t, { n: 3 }), L("merchant", t, {
			n: 2,
			used: []
		})];
		case 6: return [L("build", t, {
			n: 2,
			discount: 1
		})];
		case 7: return [L("diplomat", t)];
		case 8: return [L("warlord", t)];
		case 9: return [L("seats", t, { n: new Set(e.cells.filter((e) => e.owner === t).map((t) => H(e, t, !0))).size })];
		default: return [];
	}
}
function se(e, t, n, r) {
	let i = Number(n.target), a = n.x, o = n.y, s = q(e, t, i, {
		x: a,
		y: o
	}, n.discount ? r.discount ?? 0 : 0);
	e.gold[t] -= s, e.supply += s;
	let c = e.stacks.find((e) => e[0] === i);
	c ? c.shift() : e.uniques[t] = e.uniques[t].filter((e) => e !== i);
	let l = {
		id: i,
		x: a,
		y: o,
		owner: t,
		gold: 0
	};
	e.cells.push(l);
	let u = e.cells.filter((t) => t !== l && W(l, t) && H(e, l) === H(e, t)).length * (e.cells.some((e) => e.id === 24 && e.owner === t) ? 2 : 1);
	if (l.gold = Math.min(e.supply, u), e.supply -= l.gold, z(e, "build", t, k(a, o), i, c ? "market" : "unique"), e.cells.length === 16) {
		e.phase = "done", e.tasks = [];
		return;
	}
	(r.n ?? 1) > 1 && e.tasks.unshift({
		...r,
		n: (r.n ?? 1) - 1,
		discount: n.discount ? 0 : r.discount
	});
	let d = [];
	if (i === 20 && d.push(L("armory", t, { target: k(a, o) })), i === 21 && d.push(L("capitol", t, { n: 2 })), i === 22 && d.push(L("treasury", t, {
		target: k(a, o),
		n: 2
	})), i === 25) for (let n of [t, P(e, t)]) e.gold[n] < 3 && d.push(L("publicHouse", n, { n: 2 }));
	i === 28 && d.push(L("den", t)), i === 29 && d.push(L("well", t)), e.tasks.unshift(...d);
}
function ce(e, t) {
	let n = e.tasks.shift(), r = n.rid, i = e.cells.find((e) => k(e.x, e.y) === t.target);
	if (t.kind === "skip") {
		z(e, "skip", r);
		return;
	}
	if (t.kind === "magic") {
		e.magic = t.target, e.tasks.unshift(...oe(e, r)), z(e, "magic", r, t.target);
		return;
	}
	if (t.kind === "gain") {
		let t = 0;
		if ([
			"gold",
			"expansionGold",
			"publicHouse"
		].includes(n.kind) && (t = B(e, r, n.n ?? 0)), n.kind === "treasury") {
			let i = e.cells.find((e) => k(e.x, e.y) === n.target);
			t = Math.min(2, e.supply), i.gold += t, e.supply -= t, z(e, "coin", r, n.target, t);
			return;
		}
		(n.kind === "seats" || n.kind === "capitol") && (t = V(e, r, n.n ?? 0)), n.kind === "tribute" && (e.gold[P(e, r)]--, e.gold[r]++, t = 1), z(e, n.kind === "expansionGold" || n.kind === "publicHouse" ? "gold" : n.kind === "capitol" ? "seats" : n.kind, r, "", t, n.kind === "tribute" ? P(e, r) : "");
		return;
	}
	if (t.kind === "guess") {
		let n = e.hands[P(e, r)].includes(Number(t.target));
		n && e.role === 1 && (e.hands[P(e, r)] = e.hands[P(e, r)].filter((e) => e !== Number(t.target)), e.revealed[P(e, r)].push(Number(t.target))), n && e.role === 2 && e.tasks.unshift(L("steal", r, { n: 3 })), z(e, n ? "hit" : "miss", r, t.target);
		return;
	}
	if (t.kind === "steal") {
		let a = n.kind === "den" ? i.gold : 1;
		i ? i.gold -= a : e.gold[P(e, r)] -= a, e.gold[r] += a, n.kind === "steal" && (n.n ?? 0) > 1 && e.tasks.unshift({
			...n,
			n: n.n - 1
		}), z(e, "steal", r, t.target, a, P(e, r));
		return;
	}
	if (t.kind === "guard") {
		let i = e.guard ?? "council";
		e.guard = t.target, n.kind === "guard" && e.role === 3 && e.tasks.unshift(L("kingCoin", r, { target: t.target })), z(e, "guard", r, t.target, 0, i);
		return;
	}
	if (t.kind === "coin") {
		i.gold++, e.supply--, n.kind === "merchant" && (n.n ?? 0) > 1 && e.tasks.unshift({
			...n,
			n: n.n - 1,
			used: [...n.used ?? [], t.target]
		}), z(e, "coin", r, t.target, 1);
		return;
	}
	if (t.kind === "build") {
		se(e, r, t, n);
		return;
	}
	if (t.kind === "capture") {
		if (n.kind === "diplomat") V(e, P(e, r), D[i.id].cost + i.gold);
		else {
			let t = Math.max(0, D[i.id].cost + i.gold - U(e, r, "military"));
			e.gold[r] -= t, e.supply += t;
		}
		i.owner = r, z(e, "capture", r, t.target);
		return;
	}
	if (t.kind === "seats") {
		z(e, "seats", r, "", V(e, r, 2));
		return;
	}
	if (t.kind === "gold") {
		z(e, "gold", r, "", B(e, r, 2));
		return;
	}
	if (t.kind === "well") {
		e.gold[r]--, e.supply++, e.tasks.unshift(L("build", r)), z(e, "well", r);
		return;
	}
}
function le(e) {
	return e.players.map((t) => {
		let n = e.cells.filter((e) => e.owner === t), r = n.reduce((e, t) => e + D[t.id].cost, 0), i = n.reduce((e, t) => e + t.gold, 0), a = Math.floor((t === e.players[0] ? e.seats : 9 - e.seats) / 2);
		return {
			rid: t,
			districts: r,
			gold: i,
			seats: a,
			total: r + i + a
		};
	});
}
function Y(e) {
	let t = e.last;
	return {
		state: e,
		fx: t.kind === "deal" || t.kind === "exchange" ? e.players.map((n) => ({
			kind: "city",
			rid: n,
			data: {
				...t,
				from: P(e, n)
			}
		})) : [{
			kind: "city",
			rid: t.rid,
			data: t
		}]
	};
}
var ue = {
	meta: A,
	saveCompatibility: { version: "1" },
	schemas: {
		action: te,
		publicView: ne,
		privateView: re
	},
	setup(t, n, r) {
		let i = {
			players: [...n],
			seed: r,
			cursor: 0,
			phase: "setup",
			round: 0,
			role: 0,
			cells: [],
			guard: null,
			supply: 19,
			gold: {},
			seats: 4,
			stacks: [],
			uniques: {},
			hands: {},
			options: {},
			selected: {},
			passed: {},
			revealed: {},
			tasks: [],
			magic: null,
			last: {
				seq: 0,
				kind: "setup",
				rid: "",
				target: "",
				n: 0,
				from: ""
			}
		};
		i.seats = 4 + e(r, i.cursor++, 2);
		let a = I(i, [
			0,
			1,
			2,
			3
		]), o = I(i, [
			20,
			21,
			22,
			23,
			24,
			25,
			26,
			27,
			28,
			29
		]), s = I(i, Array.from({ length: 16 }, (e, t) => t + 4));
		return i.stacks = Array.from({ length: 4 }, (e, t) => s.slice(t * 4, t * 4 + 4)), n.forEach((e, t) => {
			i.cells.push({
				id: a[t],
				x: t,
				y: 0,
				owner: e,
				gold: 0
			}), i.gold[e] = F(i, e) === 5 ? 2 : 4, i.uniques[e] = [], i.hands[e] = [], i.options[e] = o.slice(t * 3, t * 3 + 3), i.passed[e] = [], i.revealed[e] = [];
		}), { state: i };
	},
	reduce(e, t, n) {
		if (t.type === "tick") {
			if (!["resolve", "expansion"].includes(e.phase) || e.tasks.length) return { state: e };
			let t = structuredClone(e);
			if (t.phase === "expansion") return ae(t), Y(t);
			if (t.role === 9) {
				t.phase = "expansion";
				let e = t.players.find((e) => F(t, e) >= 5), n = P(t, e);
				return t.tasks = [
					L("expansionGold", e, { n: 3 }),
					L("build", e),
					L("expansion", n)
				], z(t, "expansion", e), Y(t);
			}
			t.role++, t.magic = null;
			let n = t.players.find((e) => t.hands[e].includes(t.role));
			return n && (t.hands[n] = t.hands[n].filter((e) => e !== t.role), t.revealed[n].push(t.role), t.tasks = t.cells.some((e) => e.owner === n && e.id === 26) ? [L("magic", n)] : oe(t, n)), z(t, "reveal", n ?? "", String(t.role)), Y(t);
		}
		let r = (e) => JSON.stringify(e.type === "select" ? {
			...e,
			ids: [...e.ids].sort((e, t) => e - t)
		} : e);
		if (!J(e, n.by).some((e) => r(e) === r(t))) return { code: "games.citadelsduel.invalid" };
		let i = structuredClone(e);
		return t.type === "select" ? (i.selected[n.by] = t.ids, z(i, "select", n.by), i.players.every((e) => i.selected[e]) && (i.phase === "setup" ? (i.players.forEach((e) => {
			i.uniques[e] = i.selected[e], i.options[e] = [];
		}), ae(i)) : i.phase === "keep" ? (i.players.forEach((e) => {
			i.passed[e] = i.hands[e].filter((t) => !i.selected[e].includes(t));
		}), i.players.forEach((e) => {
			i.hands[e] = [...i.selected[e], ...i.passed[P(i, e)]].sort((e, t) => e - t);
		}), i.selected = {}, i.phase = "discard", z(i, "exchange", "")) : (i.players.forEach((e) => {
			i.hands[e] = i.hands[e].filter((t) => !i.selected[e].includes(t));
		}), i.selected = {}, i.phase = "resolve", i.role = 0, z(i, "ready", "")))) : ce(i, t), Y(i);
	},
	viewFor(e, t) {
		return {
			public: {
				phase: e.phase,
				round: e.round,
				role: e.role,
				cells: e.cells,
				guard: e.guard,
				supply: e.supply,
				markets: e.stacks.map((e) => ({
					id: e[0] ?? null,
					count: e.length
				})),
				players: e.players.map((t) => ({
					rid: t,
					gold: e.gold[t],
					seats: F(e, t),
					handCount: e.hands[t].length,
					uniqueCount: e.uniques[t].length,
					ready: !!e.selected[t],
					revealed: e.revealed[t]
				})),
				task: e.tasks[0] ?? null,
				actor: e.tasks[0]?.rid ?? null,
				magic: e.magic,
				last: e.last,
				scores: le(e)
			},
			private: e.players.includes(t) ? {
				hand: e.hands[t],
				uniques: e.uniques[t],
				options: e.options[t],
				passed: e.passed[t],
				legal: J(e, t)
			} : void 0
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(le(e).map((e) => [e.rid, e.total])), n = (n, r) => t[r] - t[n] || e.gold[r] - e.gold[n] || F(e, r) - F(e, n), r = [...e.players].sort(n);
		return {
			phase: "done",
			scores: t,
			ranking: r,
			winner: r.filter((e) => n(e, r[0]) === 0)
		};
	},
	nextTickIn: (e) => ["resolve", "expansion"].includes(e.phase) && !e.tasks.length ? 750 : null
}, de = {
	name: "Citadels Duel",
	desc: "Draft secret characters, build a shared city, and contest districts and the council.",
	invalid: "That action is not available. Please choose again.",
	rules: "Goal:\nBuild a shared city while competing for district control. The game ends immediately when its 16th district is placed. The highest score wins.\nSetup:\n· Place two random starting districts orthogonally adjacent, one controlled by each player. Each player secretly keeps two of three random unique districts; the others leave this game.\n· Shuffle the 16 basic districts into four stacks of four. Only each top tile is available. Randomly divide nine council seats five to four. The player with five seats starts with 2 gold; the other starts with 4 gold.\n· There are 25 gold coins in total. Gains come from the supply and payments return to it. If the supply runs short, take only what remains. The Guard starts at the council and protects no districts.\nEach round:\n· Draft: shuffle nine characters, deal four to each player, and discard one face down. Simultaneously keep two and pass the other two. Then secretly discard one of your four characters, leaving three each.\n· Resolve: call characters in order from 1 to 9. Whoever holds each character reveals it and resolves its abilities. Skip an absent character. Every ability step is optional. Resolve multiple steps in order; an either/or ability allows just one option.\n· Expansion: the player with a council majority gains 3 gold and may build one district. Then the other player chooses to gain 2 gold or build one district. Begin another round afterward.\nBuilding and protection:\nChoose a top basic district or one of your reserved unique districts, pay its printed cost, and place it orthogonally adjacent to the city under your control. The city's width and height may each span at most four spaces. It may grow in any direction from the starting districts. Discounts never reduce a cost below zero.\n· Place 1 supply gold on a new district for every orthogonally adjacent district of the same printed color, including your opponent's districts.\n· The Guard protects its own district and all orthogonally adjacent districts, regardless of owner. Protected districts cannot be targeted by the Thief, Diplomat, or Warlord.\nCharacters:\n· Assassin (1): name a character. If it is in your opponent's hand, they reveal and discard it without resolving it this round.\n· Thief (2): name a character. If it is in your opponent's hand, take up to 3 gold in total from their wallet and/or any unprotected districts, regardless of owner.\n· King (3): gain 1 council seat plus 1 per Noble district you control. Then you may move the Guard to a different district and place 1 supply gold on its new district.\n· Abbot (4): if your wallet has less gold than your opponent's, take 1 gold from them. Then you may build one district with a discount of 1 gold per Religious district you control.\n· Merchant (5): gain 3 gold. Then place 1 supply gold on each of up to two different Commercial districts you control.\n· Architect (6): build up to two districts. Reduce one build's cost by 1 gold; you may save this discount for the second build.\n· Diplomat (7): gain 2 council seats, or lose seats equal to the value of an unprotected opposing district to take control of it. Value is printed cost plus gold on the district. Its coins remain.\n· Warlord (8): move the Guard, or take an unprotected opposing district by paying its value less 1 gold per Military district you control, to a minimum of zero.\n· Queen (9): gain 1 council seat for each different district color you control, up to five. Seats flip from the opponent within the shared total of nine.\nUnique districts:\n· Armory: after building, you may move the Guard onto this district.\n· Capitol: after building, you may gain 2 council seats.\n· Imperial Treasury: after building, place 2 additional supply gold on this district.\n· Ivory Tower: the Thief, Diplomat, and Warlord cannot target it.\n· Library: while you control it, each matching adjacent district grants 2 build-bonus gold instead of 1. This applies when building the Library itself.\n· Public House: after building, each player with fewer than 3 wallet gold gains 2 supply gold. If supply is short, the builder takes gold first.\n· School of Magic: choose one color for its use throughout each character's abilities. It remains purple for build bonuses.\n· Statue: building it is free when adjacent to a district you control with a printed cost of 4 gold.\n· Thieves’ Den: after building, you may take all gold from one district unprotected by the Guard, regardless of owner.\n· Wishing Well: after building, you may pay 1 gold to build one additional district. This extra build does not inherit character discounts.\nEnd and scoring:\nAfter placing the 16th district and resolving its build bonus, end immediately without resolving its after-built ability.\n· Score each controlled district's printed cost.\n· Score 1 point for every gold coin on your controlled districts.\n· Score 1 point per two council seats you control, rounding down.\nThe highest score wins. Break ties by wallet gold, then by council seats. If all are tied, share victory.",
	districts: /* @__PURE__ */ "Noble House.Religious House.Commercial House.Military House.Castle.Manor.Palace.Villa.Cathedral.Church.Monastery.Temple.Harbor.Market.Tavern.Trading Post.Barracks.Fortress.Prison.Watchtower.Armory.Capitol.Imperial Treasury.Ivory Tower.Library.Public House.School of Magic.Statue.Thieves’ Den.Wishing Well".split("."),
	roles: [
		"",
		"Assassin",
		"Thief",
		"King",
		"Abbot",
		"Merchant",
		"Architect",
		"Diplomat",
		"Warlord",
		"Queen"
	],
	colors: {
		noble: "Noble",
		religious: "Religious",
		commercial: "Commercial",
		military: "Military",
		unique: "Unique"
	},
	effects: [
		"You may move the Guard onto this district.",
		"You may gain 2 council seats.",
		"Place 2 additional supply gold here.",
		"Cannot be targeted by the Thief, Diplomat, or Warlord.",
		"While controlled, each matching neighbor grants 2 build-bonus gold.",
		"Each player with fewer than 3 wallet gold gains 2 supply gold.",
		"Choose one color for each character’s abilities.",
		"Free to build next to your district with a printed cost of 4.",
		"You may take all gold from one unprotected district.",
		"You may pay 1 gold to build one more district."
	],
	abilities: [
		"",
		"Name an opposing character to remove its abilities this round.",
		"Guess an opposing character to take up to 3 gold from their wallet and unprotected districts.",
		"Gain 1 seat plus 1 per Noble district. Then move the Guard and optionally place 1 gold there.",
		"Take 1 opposing gold if you have less. Then build, discounted by your Religious districts.",
		"Gain 3 gold. Then place 1 gold on up to two different Commercial districts you control.",
		"Build up to two districts; one build receives a 1-gold discount.",
		"Gain 2 seats or spend seats equal to an unprotected opposing district’s value to control it.",
		"Move the Guard or pay a district’s value minus your Military districts to take control.",
		"Gain seats equal to the number of district colors you control."
	],
	phases: {
		setup: "Secretly keep two unique districts",
		keep: "Keep two characters and pass the others",
		discard: "Discard one character face down",
		resolve: "Resolve characters",
		expansion: "Expand the city",
		done: "The city is complete"
	},
	tasks: {
		magic: "Choose the School’s color for this character.",
		gold: "You may gain gold.",
		expansionGold: "Gain 3 gold for your council majority.",
		treasury: "Place additional gold on the Imperial Treasury.",
		publicHouse: "Gain the Public House gold.",
		capitol: "Gain the Capitol’s 2 seats.",
		seats: "You may gain council seats.",
		tribute: "Take 1 opposing gold if you have less.",
		guess: "Name a character yet to act.",
		steal: "Choose coin sources, up to 3 coins in total.",
		guard: "Choose a new district for the Guard.",
		armory: "You may move the Guard to the Armory.",
		kingCoin: "You may place 1 gold at the Guard’s new district.",
		merchant: "Choose different Commercial districts you control.",
		build: "Choose a district, then an adjacent empty space.",
		diplomat: "Take an opposing district or gain 2 seats.",
		warlord: "Take an opposing district or choose a new Guard location.",
		den: "Choose an unprotected district holding gold.",
		well: "You may pay 1 gold to build again.",
		expansion: "Gain 2 gold or build one district."
	},
	market: "District row",
	reserve: "Your unique districts",
	hand: "Your characters",
	council: "Council",
	supply: "Supply",
	gold: "Gold",
	seats: "Seats",
	score: "Score",
	round: "Round",
	city: "City",
	confirm: "Confirm",
	skip: "Skip",
	accept: "Gain",
	wait: "Waiting for the other player",
	waitActor: "Waiting for",
	resolving: "Calling characters",
	discount: "Use the 1-gold discount now",
	selectTile: "Choose a district",
	place: "Build at",
	capture: "Take control",
	moveGuard: "Move the Guard",
	steal: "Take gold",
	wallet: "Opponent’s wallet",
	twoSeats: "Gain 2 seats",
	twoGold: "Gain 2 gold",
	well: "Pay 1 gold and build again",
	choose: "Choose",
	details: "District details",
	close: "Close",
	protected: "Guard protected",
	guard: "King’s Guard",
	empty: "Empty",
	completed: "The city is complete",
	winner: "Winner",
	tied: "Shared victory",
	districtScore: "District costs",
	coinScore: "District gold",
	seatScore: "Council points",
	total: "Total",
	walletTie: "Wallet gold",
	viewCity: "View city",
	showResult: "Show results",
	again: "Play again",
	lobby: "Back to lobby",
	waitHost: "Waiting for the host",
	hints: "Hints used",
	autoplay: "Autopilot share",
	remaining: "Builds remaining",
	noRole: "Nobody holds it",
	hit: "Found the character",
	miss: "No match",
	played: "Revealed characters",
	selected: "Confirmed",
	coinsOn: "District gold",
	cost: "Printed cost",
	ownership: "Controlled by",
	confirmLeave: "Leave this game?",
	confirmAgain: "Start a new game?",
	cancel: "Cancel",
	readOnly: "Final city",
	placeGold: "Place 1 gold"
}, fe = {
	name: "荣耀之城：对决",
	desc: "两人秘密招募角色，共建城市，争夺城区与议会。",
	invalid: "当前无法执行这个行动，请重新选择。",
	rules: "目标：\n双方共同建设一座城市，并争夺城区控制权。城市建满16个城区时立即结束，得分最高者获胜。\n准备：\n· 随机放置两个正交相邻的起始城区，双方各控制一个。每人从三个独特城区中秘密保留两个，其余退出本局。\n· 16个基础城区洗成四叠，每叠四个，只有顶端城区可供建设。九个议会席位随机分成五席与四席；五席者获得2枚金币，四席者获得4枚金币。\n· 金币总量为25枚。获得金币时从公共供应领取，支付时归还供应；供应不足时只获得剩余数量。守卫起始位于议会，尚不保护城区。\n每轮流程：\n· 招募：九张角色牌洗牌后各发四张，余下一张暗弃。双方同时保留两张，把另外两张交给对手，再从手中四张牌里暗弃一张。每人最终持有三张角色。\n· 角色行动：依编号1至9逐个叫号。持有该角色的人亮牌并执行能力；无人持有则跳过。所有能力步骤均可跳过；同一角色的多项能力依所列顺序执行，二选一能力只能选一项。\n· 扩张：议会多数者先获得3枚金币，再可以建设一个城区；另一人随后选择获得2枚金币或建设一个城区。之后开始下一轮。\n建设与保护：\n选择一叠顶部的基础城区或本人保留的独特城区，支付印刷费用，把它放到城市的正交相邻空位，并取得控制权。整个城市的横向、纵向跨度各不得超过四格，可以从起始城区向任何方向发展。所有费用折扣最低减至0枚金币。\n· 新建城区每与一个同色城区正交相邻，就在新城区上放置1枚供应金币；对手的同色城区也计算在内。\n· 守卫保护其所在城区及正交相邻的所有城区，不区分归属。受保护城区不能被盗贼、外交官或军阀针对。\n角色能力：\n· 刺客（1）：叫出一个角色。若对手手中持有该角色，对手立即亮出并弃置它，本轮不能执行其能力。\n· 盗贼（2）：叫出一个角色。若对手手中持有该角色，你可以从对手的钱包和任意未受保护城区上合计取走至多3枚金币。可以混合来源，城区可以属于任意一方。\n· 国王（3）：获得1个议会席位，并按本人控制的每个黄色贵族城区再获得1席；然后可以把守卫移动到另一个城区，并可以在新位置放置1枚供应金币。\n· 修道院长（4）：若你的钱包金币少于对手，对手交给你1枚金币；然后你可以建设一个城区，每控制一个蓝色宗教城区，费用减少1枚金币。\n· 商人（5）：获得3枚金币；然后可以选择至多两个不同的、由你控制的绿色商业城区，分别放置1枚供应金币。\n· 建筑师（6）：可以建设至多两个城区，其中一次建设费用减少1枚金币。可以把折扣留给第二次建设。\n· 外交官（7）：选择获得2个议会席位，或失去与一个未受保护的敌方城区价值相等的席位，取得该城区控制权。价值为印刷费用加城区上的金币数，原有金币保留。\n· 军阀（8）：选择移动守卫，或支付一个未受保护敌方城区的价值，取得其控制权。每控制一个红色军事城区，支付费用减少1枚金币，最低为0枚金币。\n· 王后（9）：按你控制的城区中不同颜色的数量获得议会席位，最多获得5席。新增席位从对手的九个共同席位中翻转，不能超过九席。\n独特城区：\n· 军械库：建成后，可以把守卫移动到本城区。\n· 国会大厦：建成后，可以获得2个议会席位。\n· 帝国金库：建成后，在本城区上额外放置2枚供应金币。\n· 象牙塔：不能被盗贼、外交官或军阀针对。\n· 图书馆：控制它时，建设奖励对每个同色相邻城区改放2枚金币；图书馆自身建成时也适用。\n· 公共酒馆：建成后，钱包不足3枚金币的双方各获得2枚供应金币。供应不足时建造者先领取。\n· 魔法学校：在每张角色开始时，可以为本次角色能力把它视为一种颜色；整个角色期间沿用该选择。建设奖励仍按紫色计算。\n· 雕像：若建在本人控制、印刷费用为4枚金币的城区旁，本次建设免费。\n· 盗贼巢穴：建成后，可以把一个未受守卫保护的城区上的全部金币移入自己的钱包；该城区可以属于任意一方。\n· 许愿井：建成后，可以支付1枚金币，再额外建设一个城区。额外建设不继承角色折扣。\n结束与计分：\n放置第16个城区并结算其建设奖励后，游戏立即结束，不再执行该城区的建成后能力。\n· 每个受你控制的城区，获得与印刷费用相等的分数。\n· 受你控制的城区上每枚金币获得1分。\n· 每控制两个议会席位获得1分，余下一席不计分。\n总分较高者获胜。若同分，钱包金币较多者获胜；若仍相同，议会席位较多者获胜。以上均相同则并列获胜。",
	districts: /* @__PURE__ */ "贵族宅邸.宗教宅邸.商业宅邸.军事宅邸.城堡.庄园.宫殿.别墅.大教堂.教堂.修道院.神殿.港口.集市.酒馆.商站.兵营.要塞.监狱.瞭望塔.军械库.国会大厦.帝国金库.象牙塔.图书馆.公共酒馆.魔法学校.雕像.盗贼巢穴.许愿井".split("."),
	roles: [
		"",
		"刺客",
		"盗贼",
		"国王",
		"修道院长",
		"商人",
		"建筑师",
		"外交官",
		"军阀",
		"王后"
	],
	colors: {
		noble: "贵族",
		religious: "宗教",
		commercial: "商业",
		military: "军事",
		unique: "独特"
	},
	effects: [
		"可以把守卫移动到本城区。",
		"可以获得2个议会席位。",
		"本城区额外获得2枚供应金币。",
		"免于盗贼、外交官及军阀的针对。",
		"控制时，每个同色相邻城区的建设奖励改为2枚金币。",
		"钱包不足3枚金币的双方各获得2枚供应金币。",
		"每张角色开始时选择本次能力所用的一种颜色。",
		"建在本人印刷费用为4枚金币的城区旁时免费。",
		"可以取走一个未受保护城区上的全部金币。",
		"可以支付1枚金币，再建设一个城区。"
	],
	abilities: [
		"",
		"叫出对手手中的角色，使它本轮失去能力。",
		"猜中对手角色后，可以从对手钱包及未受保护城区取走至多3枚金币。",
		"获得1席，加每个贵族城区1席；再移动守卫，并可在新位置放1枚金币。",
		"金币少于对手时取走对手1枚金币；再建设一个城区，每个宗教城区减费1枚金币。",
		"获得3枚金币；再给至多两个不同的本人商业城区各放1枚金币。",
		"建设至多两个城区；其中一次减费1枚金币。",
		"获得2席，或支付等于敌方未受保护城区价值的席位取得控制权。",
		"移动守卫，或支付城区价值减本人军事城区数的金币取得敌方城区。",
		"按本人城区不同颜色的数量获得席位。"
	],
	phases: {
		setup: "秘密保留两个独特城区",
		keep: "保留两张角色，其余交给对手",
		discard: "暗弃一张角色",
		resolve: "角色行动",
		expansion: "城市扩张",
		done: "城市落成"
	},
	tasks: {
		magic: "选择魔法学校本次能力的颜色。",
		gold: "可以领取金币。",
		expansionGold: "领取议会多数奖励的3枚金币。",
		treasury: "在帝国金库上放置额外金币。",
		publicHouse: "领取公共酒馆提供的金币。",
		capitol: "获得国会大厦提供的2个席位。",
		seats: "可以翻转议会席位。",
		tribute: "金币少于对手时，可以取得对手1枚金币。",
		guess: "叫出一个尚未行动的角色。",
		steal: "选择金币来源，可以分次选择至多3枚。",
		guard: "点选守卫的新位置。",
		armory: "可以把守卫移到军械库。",
		kingCoin: "可以在守卫的新位置放1枚金币。",
		merchant: "点选不同的本人商业城区放置金币。",
		build: "选择城区，然后点选相邻空位。",
		diplomat: "点选敌方城区取得控制权，或获得2个席位。",
		warlord: "点选敌方城区取得控制权，或选择守卫的新位置。",
		den: "点选一个未受保护的有金币城区。",
		well: "可以支付1枚金币，再额外建设一个城区。",
		expansion: "选择领取2枚金币，或建设一个城区。"
	},
	market: "公共城区",
	reserve: "本人独特城区",
	hand: "本人角色",
	council: "议会",
	supply: "供应",
	gold: "金币",
	seats: "席位",
	score: "分数",
	round: "轮次",
	city: "城市",
	confirm: "确认",
	skip: "跳过",
	accept: "领取",
	wait: "等待对方选择",
	waitActor: "等待",
	resolving: "正在叫号",
	discount: "本次使用1枚金币折扣",
	selectTile: "选择城区",
	place: "建设于",
	capture: "取得控制权",
	moveGuard: "移动守卫",
	steal: "取走金币",
	wallet: "对手钱包",
	twoSeats: "获得2个席位",
	twoGold: "获得2枚金币",
	well: "支付1枚金币，继续建设",
	choose: "选择",
	details: "城区详情",
	close: "关闭",
	protected: "守卫保护",
	guard: "国王守卫",
	empty: "已用尽",
	completed: "城市落成",
	winner: "获胜",
	tied: "并列获胜",
	districtScore: "城区费用",
	coinScore: "城区金币",
	seatScore: "议会得分",
	total: "总分",
	walletTie: "钱包金币",
	viewCity: "回看城市",
	showResult: "查看结算",
	again: "再来一局",
	lobby: "返回大厅",
	waitHost: "等待主机继续",
	hints: "求助次数",
	autoplay: "托管占比",
	remaining: "剩余建设次数",
	noRole: "无人持有",
	hit: "猜中了角色",
	miss: "没有猜中",
	played: "已亮出角色",
	selected: "已确认",
	coinsOn: "城区金币",
	cost: "印刷费用",
	ownership: "控制者",
	confirmLeave: "确定离开本局吗？",
	confirmAgain: "确定开始新的一局吗？",
	cancel: "取消",
	readOnly: "最终城市",
	placeGold: "放置1枚金币"
}, pe = (e) => "./games/citadelsduel/" + e + ".webp";
function me() {
	return p((e) => e.locale) === "zh" ? fe : de;
}
function he(e, t, n) {
	let r = Math.max(0, e.players.findIndex((e) => e.rid === t));
	return f(n, m[r % m.length].nameKey);
}
function X({ name: e, children: t, className: n }) {
	let { ref: r, hidden: i } = l(e);
	return /* @__PURE__ */ y("div", {
		ref: r,
		className: n,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function Z({ id: e, copy: t, selected: n, onClick: r, anchor: i, owner: s, gold: c = 0, guard: l = !1, protected: u = !1, flip: f = 0 }) {
	let p = D[e], m = o(null), h = o(f), g = d();
	a(() => {
		if (h.current === f || (h.current = f, !f || g || !m.current)) return;
		let e = m.current.animate([{ transform: "perspective(500px) rotateY(-85deg)" }, { transform: "perspective(500px) rotateY(0deg)" }], {
			duration: 520,
			easing: "ease-out"
		});
		return () => e.cancel();
	}, [f, g]);
	let _ = /* @__PURE__ */ b("button", {
		ref: m,
		type: "button",
		className: "cd-district",
		"data-selected": n || void 0,
		style: { "--cd-color": ee[p.color] },
		onClick: r,
		"aria-label": `${t.districts[e]}, ${t.cost} ${p.cost}, ${t.colors[p.color]}${s ? ", " + s.name : ""}${c ? ", " + t.coinsOn + " " + c : ""}${l ? ", " + t.guard : ""}${u ? ", " + t.protected : ""}`,
		children: [
			/* @__PURE__ */ y("img", {
				className: "cd-art",
				src: pe("district-" + e),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ y("span", {
				className: "cd-cost",
				"aria-hidden": "true",
				children: p.cost
			}),
			/* @__PURE__ */ y("span", {
				className: "cd-district-name",
				children: t.districts[e]
			}),
			/* @__PURE__ */ y("span", {
				className: "cd-color-label",
				children: t.colors[p.color]
			}),
			s && /* @__PURE__ */ y("span", {
				className: "cd-owner",
				style: { background: s.color },
				title: s.name,
				children: /* @__PURE__ */ y("img", {
					src: s.avatar,
					alt: ""
				})
			}),
			c > 0 && /* @__PURE__ */ y("span", {
				className: "cd-tile-gold",
				children: c
			}),
			l && /* @__PURE__ */ y("span", {
				className: "cd-guard",
				title: t.guard,
				children: "♜"
			}),
			u && /* @__PURE__ */ y("span", {
				className: "cd-protection",
				"aria-hidden": "true"
			})
		]
	});
	return i ? /* @__PURE__ */ y(X, {
		name: i,
		className: "cd-tile-anchor",
		children: _
	}) : _;
}
function Q({ id: e, copy: t, selected: n, onClick: r, compact: i = !1 }) {
	return /* @__PURE__ */ b("button", {
		type: "button",
		className: `cd-character${i ? " cd-character-compact" : ""}`,
		"data-selected": n || void 0,
		onClick: r,
		"aria-label": `${e} ${t.roles[e]}. ${t.abilities[e]}`,
		children: [
			/* @__PURE__ */ y("img", {
				src: pe("role-" + e),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ b("strong", { children: [
				/* @__PURE__ */ y("b", { children: e }),
				" ",
				t.roles[e]
			] }),
			!i && /* @__PURE__ */ y("span", { children: t.abilities[e] })
		]
	});
}
var ge = (e, t) => ({
	x: (e + 2) * 140 + 10,
	y: (t + 3) * 140 + 10,
	w: 130,
	h: 130
});
function _e({ cell: e, copy: t, owner: r, guard: s, protected: c, flip: f, onClick: p }) {
	let m = D[e.id], h = ge(e.x, e.y), g = k(e.x, e.y), _ = i(), x = o(null), S = o(f), C = d(), { hidden: w } = l("cell:" + g), T = u(), E = n((e) => T?.registerProbe("cell:" + g, e ? () => {
		let t = e.getBoundingClientRect();
		return {
			x: t.left,
			y: t.top,
			w: t.width,
			h: t.height
		};
	} : null), [T, g]);
	a(() => {
		if (S.current === f || (S.current = f, !f || C || !x.current)) return;
		let e = x.current.animate([{ transform: "scaleX(.05)" }, { transform: "scaleX(1)" }], {
			duration: 520,
			easing: "ease-out"
		});
		return () => e.cancel();
	}, [f, C]);
	let O = `${t.districts[e.id]}, ${t.cost} ${m.cost}, ${t.colors[m.color]}, ${r.name}${e.gold ? ", " + t.coinsOn + " " + e.gold : ""}${s ? ", " + t.guard : ""}${c ? ", " + t.protected : ""}`;
	return /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("rect", {
		ref: E,
		x: h.x,
		y: h.y,
		width: h.w,
		height: h.h,
		fill: "none",
		pointerEvents: "none"
	}), /* @__PURE__ */ y("g", {
		"data-cd-cell": g,
		transform: `translate(${h.x},${h.y})`,
		role: "button",
		tabIndex: 0,
		"aria-label": O,
		onClick: p,
		onKeyDown: (e) => {
			(e.key === "Enter" || e.key === " ") && (e.preventDefault(), p());
		},
		style: {
			cursor: "pointer",
			visibility: w ? "hidden" : void 0
		},
		children: /* @__PURE__ */ b("g", {
			ref: x,
			style: {
				transformBox: "fill-box",
				transformOrigin: "center"
			},
			children: [
				/* @__PURE__ */ y("defs", { children: /* @__PURE__ */ y("clipPath", {
					id: _,
					children: /* @__PURE__ */ y("rect", {
						x: "5",
						y: "5",
						width: "120",
						height: "84",
						rx: "7"
					})
				}) }),
				/* @__PURE__ */ y("rect", {
					x: "1.5",
					y: "1.5",
					width: "127",
					height: "127",
					rx: "12",
					fill: "#c7cfd8",
					stroke: "#8f9bad",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ y("image", {
					href: pe("district-" + e.id),
					x: "5",
					y: "5",
					width: "120",
					height: "84",
					preserveAspectRatio: "xMidYMid slice",
					clipPath: `url(#${_})`,
					pointerEvents: "none"
				}),
				/* @__PURE__ */ y("rect", {
					x: "5",
					y: "81",
					width: "120",
					height: "29",
					fill: ee[m.color]
				}),
				/* @__PURE__ */ y("text", {
					x: "65",
					y: "100",
					textAnchor: "middle",
					fill: "white",
					fontSize: "13",
					textLength: t.districts[e.id].length > 16 ? 114 : void 0,
					lengthAdjust: "spacingAndGlyphs",
					children: t.districts[e.id]
				}),
				/* @__PURE__ */ y("circle", {
					cx: "19",
					cy: "19",
					r: "12",
					fill: "#e8bf55",
					stroke: "#9a6c24",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ y("text", {
					x: "19",
					y: "24",
					textAnchor: "middle",
					fill: "#4d3914",
					fontSize: "16",
					fontWeight: "bold",
					children: m.cost
				}),
				/* @__PURE__ */ y("text", {
					x: "7",
					y: "123",
					fill: "#253143",
					fontSize: "10",
					children: t.colors[m.color]
				}),
				/* @__PURE__ */ y("circle", {
					cx: "110",
					cy: "113",
					r: "13",
					fill: r.color,
					stroke: "white"
				}),
				/* @__PURE__ */ y("image", {
					href: r.avatar,
					x: "99",
					y: "102",
					width: "22",
					height: "22",
					pointerEvents: "none"
				}),
				e.gold > 0 && /* @__PURE__ */ b("g", { children: [/* @__PURE__ */ y("circle", {
					cx: "108",
					cy: "22",
					r: "13",
					fill: "#f2cf6b",
					stroke: "#ad7c2e",
					strokeWidth: "2"
				}), /* @__PURE__ */ y("text", {
					x: "108",
					y: "28",
					textAnchor: "middle",
					fill: "#513614",
					fontSize: "17",
					fontWeight: "bold",
					children: e.gold
				})] }),
				s && /* @__PURE__ */ y("text", {
					x: "65",
					y: "69",
					textAnchor: "middle",
					fill: "#eff0dd",
					stroke: "#635b49",
					strokeWidth: "1",
					paintOrder: "stroke",
					fontSize: "46",
					children: "♜"
				}),
				c && /* @__PURE__ */ y("rect", {
					x: "5",
					y: "5",
					width: "120",
					height: "120",
					rx: "8",
					fill: "none",
					stroke: "#f9e1a3",
					strokeWidth: "2",
					pointerEvents: "none"
				})
			]
		})
	})] });
}
function ve({ pub: e, copy: t, ownerOf: n, actions: i, onAction: a, onDetails: c, selectedId: l, mode: u }) {
	let d = o(null), f = o(null), p = o(/* @__PURE__ */ new Set()), [m, g] = s("initial");
	r(() => {
		let e = new ResizeObserver(([e]) => g(`${Math.round(e.contentRect.width)}x${Math.round(e.contentRect.height)}`));
		return e.observe(d.current), () => e.disconnect();
	}, []);
	let _ = i.filter((e) => e.kind === "build" ? Number(e.target) === l : e.kind === u), v = _.map((e) => ({
		key: e.kind === "build" ? k(e.x, e.y) : e.target,
		rect: e.kind === "build" ? ge(e.x, e.y) : ge(...e.target.split(",").map(Number))
	})).filter((e, t, n) => n.findIndex((t) => t.key === e.key) === t);
	return /* @__PURE__ */ y("div", {
		ref: d,
		className: "cd-city",
		"aria-label": t.city,
		onPointerDownCapture: (e) => {
			if (p.current.add(e.pointerId), p.current.size > 1) {
				f.current && (f.current.moved = !0);
				return;
			}
			f.current = {
				x: e.clientX,
				y: e.clientY,
				pointer: e.pointerId,
				moved: !1
			};
		},
		onPointerMoveCapture: (e) => {
			let t = f.current;
			t && Math.hypot(e.clientX - t.x, e.clientY - t.y) >= 10 && (t.moved = !0);
		},
		onPointerUpCapture: (e) => {
			p.current.delete(e.pointerId);
		},
		onPointerCancelCapture: (e) => {
			p.current.delete(e.pointerId), f.current = null;
		},
		onClickCapture: (t) => {
			if (!t.detail || f.current?.moved || !(t.target instanceof SVGSVGElement)) return;
			let n = document.elementFromPoint(t.clientX, t.clientY)?.closest("[data-cd-cell]")?.getAttribute("data-cd-cell"), r = e.cells.find((e) => k(e.x, e.y) === n);
			r && !_.some((e) => e.target === n) && c(r), f.current = null;
		},
		children: /* @__PURE__ */ b(h, {
			sheetW: 840,
			sheetH: 980,
			fitKey: `citadelsduel-city:${m}`,
			highlight: "inset",
			eligible: v,
			onTapEligible: (e) => {
				let t = _.find((t) => (t.kind === "build" ? k(t.x, t.y) : t.target) === e);
				t && a(t);
			},
			children: [
				/* @__PURE__ */ y("defs", { children: /* @__PURE__ */ y("pattern", {
					id: "cd-grid",
					width: "140",
					height: "140",
					patternUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ y("path", {
						d: "M 140 0 L 0 0 0 140",
						fill: "none",
						stroke: "#c2cbd8",
						strokeOpacity: ".08"
					})
				}) }),
				/* @__PURE__ */ y("rect", {
					x: "-600",
					y: "-600",
					width: "2200",
					height: "2000",
					fill: "url(#cd-grid)"
				}),
				v.filter((t) => !e.cells.some((e) => k(e.x, e.y) === t.key)).map((e) => /* @__PURE__ */ y("rect", {
					x: e.rect.x,
					y: e.rect.y,
					width: e.rect.w,
					height: e.rect.h,
					rx: "12",
					fill: "#456676",
					fillOpacity: ".45",
					stroke: "#91a69f",
					strokeDasharray: "5 5",
					role: "button",
					tabIndex: 0,
					"aria-label": `${t.place} (${e.key})`,
					onClick: () => {
						let t = _.find((t) => k(t.x, t.y) === e.key);
						t && a(t);
					},
					onKeyDown: (t) => {
						if (t.key === "Enter" || t.key === " ") {
							t.preventDefault();
							let n = _.find((t) => k(t.x, t.y) === e.key);
							n && a(n);
						}
					}
				}, e.key)),
				e.cells.map((r) => {
					let i = k(r.x, r.y);
					return /* @__PURE__ */ y(_e, {
						cell: r,
						copy: t,
						owner: n(r.owner),
						guard: e.guard === i,
						protected: G(e.cells, e.guard, r),
						flip: e.last.kind === "capture" && e.last.target === i ? e.last.seq : 0,
						onClick: () => {
							let e = _.find((e) => e.target === i);
							e ? a(e) : c(r);
						}
					}, i);
				})
			]
		})
	});
}
function ye(e) {
	return /* @__PURE__ */ y(be, { ...e });
}
function be({ public: e, private: t, members: n, myRid: r, send: i }) {
	let a = e, o = t, l = me(), u = p((e) => e.locale), d = o?.legal ?? [], f = d.filter((e) => e.type === "act"), h = `${r}:${a.phase}:${a.round}:${a.role}:${a.task?.kind ?? ""}`, [x, S] = s({
		scope: h,
		ids: []
	}), C = x.scope === h ? x.ids : [], [w, T] = s(null), [E, O] = s(null), [k, A] = s({
		scope: h,
		value: "capture"
	}), [j, te] = s({
		scope: h,
		use: !0
	}), [M, N] = s(null), [ne, re] = s(r);
	ne !== r && (re(r), T(null), O(null), S({
		scope: h,
		ids: []
	}), N(null));
	let P = k.scope === h ? k.value : "capture", F = j.scope !== h || j.use, I = a.role === 6 && a.task?.kind === "build" && a.task.n !== void 0 && a.task.discount === 1, L = f.filter((e) => e.kind !== "build" || e.discount === (a.task?.discount ? !I || F : !1)), R = C.find((e) => L.some((t) => t.kind === "build" && Number(t.target) === e)) ?? null, z = [
		"setup",
		"keep",
		"discard"
	].includes(a.phase), B = (e) => {
		let t = n.find((t) => t.rid === e), r = m[(t?.colorIndex ?? a.players.findIndex((t) => t.rid === e)) % m.length];
		return {
			name: t ? _(t, u) : he(a, e, u),
			avatar: c[(t?.avatar ?? 0) % c.length],
			color: r.hex
		};
	}, V = (e) => {
		N(null), S({
			scope: h,
			ids: []
		}), i(e);
	}, H = (e) => S({
		scope: h,
		ids: C.includes(e) ? C.filter((t) => t !== e) : [...C.slice(-(a.phase === "discard" ? 0 : 1)), e]
	}), U = d.some((e) => e.type === "select" && e.ids.length === C.length && e.ids.every((e) => C.includes(e))), W = (e) => N({
		scope: h,
		action: e
	}), G = a.task?.kind === "warlord" ? P : a.task?.kind === "guard" || a.task?.kind === "armory" ? "guard" : a.task?.kind === "merchant" || a.task?.kind === "kingCoin" ? "coin" : a.task?.kind === "steal" || a.task?.kind === "den" ? "steal" : "capture", K = (a.phase === "resolve" && a.role > 0 ? `${a.role} ${l.roles[a.role]} · ` : "") + (a.phase === "done" ? l.readOnly : z ? l.phases[a.phase] : a.actor === r ? l.tasks[a.task?.kind ?? ""] ?? l.resolving : a.actor ? `${l.waitActor} ${B(a.actor).name}` : l.resolving), ie = a.last.kind === "hit" ? l.hit : a.last.kind === "miss" ? l.miss : "", q = (e) => {
		f.some((t) => t.kind === "build" && Number(t.target) === e) ? S({
			scope: h,
			ids: [e]
		}) : T({
			rid: r,
			id: e
		});
	}, J = M?.scope === h && f.some((e) => JSON.stringify(e) === JSON.stringify(M.action)) ? M.action : null, ae = a.phase === "setup" ? o?.options ?? [] : o?.hand ?? [];
	return /* @__PURE__ */ b("div", {
		className: "cd-root",
		children: [
			/* @__PURE__ */ b(g, {
				adaptive: !0,
				scroll: !1,
				className: "cd-screen",
				banner: /* @__PURE__ */ b("div", {
					className: "cd-header",
					children: [
						/* @__PURE__ */ b("div", {
							className: "cd-meta",
							children: [
								/* @__PURE__ */ b("span", { children: [
									l.round,
									" ",
									a.round || "—"
								] }),
								/* @__PURE__ */ y("strong", { children: l.name }),
								/* @__PURE__ */ b("span", { children: [a.cells.length, "/16"] })
							]
						}),
						/* @__PURE__ */ y("div", {
							className: "cd-players",
							children: a.players.map((e) => {
								let t = B(e.rid);
								return /* @__PURE__ */ b(X, {
									name: "seat:" + e.rid,
									className: "cd-player",
									children: [
										/* @__PURE__ */ y("img", {
											src: t.avatar,
											alt: "",
											style: { background: t.color }
										}),
										/* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("strong", { children: t.name }), /* @__PURE__ */ b("span", { children: [
											l.gold,
											" ",
											/* @__PURE__ */ y("b", { children: e.gold }, e.gold),
											" · ",
											l.seats,
											" ",
											e.seats
										] })] }),
										/* @__PURE__ */ y("small", { children: z && e.ready ? l.selected : l.score + " " + a.scores.find((t) => t.rid === e.rid).total })
									]
								}, e.rid);
							})
						}),
						/* @__PURE__ */ b("div", {
							className: "cd-council",
							children: [/* @__PURE__ */ y(X, {
								name: "council",
								children: /* @__PURE__ */ y("span", {
									className: "cd-seats",
									"aria-label": `${l.council}: ${a.players.map((e) => B(e.rid).name + " " + e.seats).join(", ")}`,
									children: Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ y("i", { style: { background: B(a.players[t < a.players[0].seats ? 0 : 1].rid).color } }, t))
								})
							}), /* @__PURE__ */ y(X, {
								name: "supply",
								children: /* @__PURE__ */ b("small", { children: [
									l.supply,
									" ",
									a.supply
								] })
							})]
						})
					]
				}),
				actionsHeight: "cd-actions-height",
				actions: /* @__PURE__ */ b("div", {
					className: "cd-actions",
					children: [/* @__PURE__ */ b("p", {
						"aria-live": "polite",
						children: [K, ie && /* @__PURE__ */ b("small", { children: [" · ", ie] })]
					}), /* @__PURE__ */ b("div", {
						className: "cd-action-buttons",
						children: [
							z && d.length > 0 && /* @__PURE__ */ b("button", {
								type: "button",
								disabled: !U,
								onClick: () => V({
									type: "select",
									ids: C
								}),
								children: [
									l.confirm,
									" (",
									C.length,
									"/",
									a.phase === "discard" ? 1 : 2,
									")"
								]
							}),
							I && a.actor === r && /* @__PURE__ */ b("label", { children: [/* @__PURE__ */ y("input", {
								type: "checkbox",
								checked: F,
								onChange: (e) => te({
									scope: h,
									use: e.target.checked
								})
							}), l.discount] }),
							a.task?.kind === "warlord" && a.actor === r && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("button", {
								type: "button",
								"data-selected": P === "capture",
								onClick: () => A({
									scope: h,
									value: "capture"
								}),
								children: l.capture
							}), /* @__PURE__ */ y("button", {
								type: "button",
								"data-selected": P === "guard",
								onClick: () => A({
									scope: h,
									value: "guard"
								}),
								children: l.moveGuard
							})] }),
							f.filter((e) => [
								"gain",
								"seats",
								"gold",
								"well"
							].includes(e.kind)).map((e) => /* @__PURE__ */ y("button", {
								type: "button",
								onClick: () => V(e),
								children: e.kind === "seats" ? l.twoSeats : e.kind === "gold" ? l.twoGold : e.kind === "well" ? l.well : `${l.accept} ${a.task?.n ?? 1} ${["seats", "capitol"].includes(a.task?.kind ?? "") ? l.seats : l.gold}`
							}, e.kind)),
							f.some((e) => e.kind === "steal" && e.target === "wallet") && /* @__PURE__ */ b("button", {
								type: "button",
								onClick: () => V(f.find((e) => e.kind === "steal" && e.target === "wallet")),
								children: [
									l.steal,
									" · ",
									l.wallet
								]
							}),
							f.filter((e) => e.kind === "magic").map((e) => /* @__PURE__ */ y("button", {
								type: "button",
								style: { borderColor: ee[e.target] },
								onClick: () => V(e),
								children: l.colors[e.target]
							}, e.target)),
							f.some((e) => e.kind === "skip") && /* @__PURE__ */ y("button", {
								type: "button",
								className: "cd-secondary",
								onClick: () => V(f.find((e) => e.kind === "skip")),
								children: l.skip
							}),
							!z && !!o?.hand.length && /* @__PURE__ */ b("button", {
								type: "button",
								className: "cd-secondary",
								onClick: () => O(r),
								children: [
									l.hand,
									" (",
									o.hand.length,
									")"
								]
							}),
							!d.length && /* @__PURE__ */ y("span", {
								className: "cd-wait",
								children: z ? l.wait : a.task?.rid === r ? "" : l.phases[a.phase]
							})
						]
					})]
				}),
				children: [
					/* @__PURE__ */ b("div", {
						className: "cd-table",
						children: [
							/* @__PURE__ */ b("aside", {
								className: "cd-market",
								children: [
									/* @__PURE__ */ y("h2", { children: l.market }),
									/* @__PURE__ */ y(X, {
										name: "market",
										className: "cd-market-tiles",
										children: a.markets.map((e, t) => /* @__PURE__ */ y("div", {
											className: "cd-stack",
											children: e.id === null ? /* @__PURE__ */ y("span", { children: l.empty }) : /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(Z, {
												id: e.id,
												copy: l,
												selected: R === e.id,
												onClick: () => q(e.id)
											}), /* @__PURE__ */ y("small", { children: e.count })] })
										}, t))
									}),
									/* @__PURE__ */ y("h2", { children: l.reserve }),
									/* @__PURE__ */ y(X, {
										name: "unique",
										className: "cd-reserve",
										children: o?.uniques.map((e) => /* @__PURE__ */ y(Z, {
											id: e,
											copy: l,
											selected: R === e,
											onClick: () => q(e)
										}, e))
									})
								]
							}),
							/* @__PURE__ */ y(ve, {
								pub: a,
								copy: l,
								ownerOf: B,
								actions: L,
								selectedId: R,
								mode: G,
								onAction: W,
								onDetails: (e) => T({
									rid: r,
									id: e.id,
									cell: e
								})
							}),
							/* @__PURE__ */ b("aside", {
								className: "cd-role-panel",
								children: [
									/* @__PURE__ */ y(X, {
										name: "role",
										children: a.role > 0 && a.phase === "resolve" ? /* @__PURE__ */ y(Q, {
											id: a.role,
											copy: l
										}, `${a.round}:${a.role}`) : /* @__PURE__ */ y("div", {
											className: "cd-role-back",
											children: l.phases[a.phase]
										})
									}),
									/* @__PURE__ */ y("h2", { children: l.hand }),
									/* @__PURE__ */ y(X, {
										name: "hand:" + r,
										className: "cd-hand",
										children: o?.hand.map((e) => /* @__PURE__ */ y(Q, {
											id: e,
											copy: l,
											compact: !0,
											onClick: () => T({
												rid: r,
												id: -e
											})
										}, e))
									}),
									/* @__PURE__ */ y("div", {
										className: "cd-revealed",
										children: a.players.map((e) => /* @__PURE__ */ b("details", { children: [/* @__PURE__ */ b("summary", { children: [
											B(e.rid).name,
											" · ",
											l.played,
											" ",
											e.revealed.length
										] }), e.revealed.map((e) => /* @__PURE__ */ b("span", { children: [
											e,
											" ",
											l.roles[e]
										] }, e))] }, e.rid))
									})
								]
							})
						]
					}),
					z && d.length > 0 && /* @__PURE__ */ b("div", {
						className: "cd-draft",
						role: "dialog",
						"aria-label": l.phases[a.phase],
						children: [/* @__PURE__ */ y("h2", { children: l.phases[a.phase] }), /* @__PURE__ */ y("div", {
							className: "cd-draft-cards",
							children: ae.map((e) => /* @__PURE__ */ y("div", { children: a.phase === "setup" ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(Z, {
								id: e,
								copy: l,
								selected: C.includes(e),
								onClick: () => H(e)
							}), /* @__PURE__ */ y("p", { children: l.effects[e - 20] })] }) : /* @__PURE__ */ y(Q, {
								id: e,
								copy: l,
								selected: C.includes(e),
								onClick: () => H(e)
							}) }, e))
						})]
					}),
					a.task?.kind === "guess" && a.actor === r && /* @__PURE__ */ y("div", {
						className: "cd-guesses",
						children: f.filter((e) => e.kind === "guess").map((e) => /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => V(e),
							children: [
								e.target,
								" ",
								l.roles[Number(e.target)]
							]
						}, e.target))
					})
				]
			}),
			J && /* @__PURE__ */ y("div", {
				className: "cd-modal-shade",
				children: /* @__PURE__ */ b("div", {
					className: "cd-confirm",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": l.confirm,
					children: [/* @__PURE__ */ y("h2", { children: J.kind === "build" ? `${l.districts[Number(J.target)]} · ${l.place} (${J.x}, ${J.y})` : J.kind === "guard" ? l.moveGuard : J.kind === "capture" ? l.capture : J.kind === "coin" ? l.placeGold : l.steal }), /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("button", {
						type: "button",
						onClick: () => N(null),
						children: l.cancel
					}), /* @__PURE__ */ y("button", {
						type: "button",
						onClick: () => V(J),
						children: l.confirm
					})] })]
				})
			}),
			w?.rid === r && /* @__PURE__ */ y("div", {
				className: "cd-modal-shade",
				onClick: () => T(null),
				children: /* @__PURE__ */ b("div", {
					className: "cd-detail",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": l.details,
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ y("button", {
						type: "button",
						onClick: () => T(null),
						children: l.close
					}), w.id >= 0 ? /* @__PURE__ */ b(v, { children: [
						/* @__PURE__ */ y(Z, {
							id: w.id,
							copy: l
						}),
						/* @__PURE__ */ y("h2", { children: l.districts[w.id] }),
						/* @__PURE__ */ b("p", { children: [
							l.cost,
							": ",
							D[w.id].cost,
							" ",
							l.gold,
							" · ",
							l.colors[D[w.id].color]
						] }),
						w.id >= 20 && /* @__PURE__ */ y("p", { children: l.effects[w.id - 20] }),
						w.cell && /* @__PURE__ */ b("p", { children: [
							l.ownership,
							": ",
							B(w.cell.owner).name,
							" · ",
							l.coinsOn,
							": ",
							w.cell.gold
						] })
					] }) : /* @__PURE__ */ y(Q, {
						id: -w.id,
						copy: l
					})]
				})
			}),
			E === r && /* @__PURE__ */ y("div", {
				className: "cd-modal-shade",
				children: /* @__PURE__ */ b("div", {
					className: "cd-detail",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": l.hand,
					children: [
						/* @__PURE__ */ y("button", {
							type: "button",
							onClick: () => O(null),
							children: l.close
						}),
						/* @__PURE__ */ y("h2", { children: l.hand }),
						o?.hand.map((e) => /* @__PURE__ */ y(Q, {
							id: e,
							copy: l
						}, e))
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/citadelsduel/bot.ts
function xe(e, t, n) {
	let r = t.cells.filter((e) => e.owner === n), i = t.players.find((e) => e.rid === n)?.gold ?? 0;
	return [
		0,
		2.4,
		2.6,
		4.5,
		3.2 + +(i > 1),
		5.5,
		i >= 3 ? 6 : 2,
		4,
		3.3,
		2 + new Set(r.map((e) => D[e.id].color)).size
	][e];
}
function Se(e, t, n, r) {
	if (e.type === "tick") return -100;
	if (e.type === "select") {
		let n = (e) => t.phase === "setup" ? 4 - D[e].cost * .4 + +(e === 24 || e === 27) : xe(e, t, r);
		return e.ids.reduce((e, t) => e + n(t), 0) * (t.phase === "discard" ? -1 : 1);
	}
	let i = t.cells.find((t) => k(t.x, t.y) === e.target), a = t.players.find((e) => e.rid === r);
	switch (e.kind) {
		case "skip": return -5;
		case "gain": return t.task?.kind === "seats" ? 1.3 * (t.task.n ?? 1) : t.task?.kind === "gold" ? t.task.n ?? 1 : 2;
		case "seats": return a.seats < 5 ? 4 : 2;
		case "gold": return a.gold < 3 ? 4 : 2;
		case "build": {
			let n = D[Number(e.target)], i = t.cells.filter((t) => Math.abs(t.x - e.x) + Math.abs(t.y - e.y) === 1 && D[t.id].color === n.color).length, o = e.discount ? t.task?.discount ?? 0 : 0, s = n.id === 27 && t.cells.some((t) => t.owner === r && D[t.id].cost === 4 && Math.abs(t.x - e.x) + Math.abs(t.y - e.y) === 1) ? 0 : Math.max(0, n.cost - o), c = n.id === 24 ? 2 : n.id === 26 ? 1.5 : n.id === 23 ? 1 : n.id === 22 ? 2 : n.id === 21 ? 1 : n.id === 25 && a.gold - s < 3 ? 1.4 : 0;
			return 3 + n.cost + i + c - s * .75 + (e.discount ? .4 : 0);
		}
		case "capture": return i ? 2 * (D[i.id].cost + i.gold) - (t.task?.kind === "diplomat" ? D[i.id].cost + i.gold : Math.max(0, D[i.id].cost + i.gold - t.cells.filter((e) => e.owner === r && D[e.id].color === "military").length)) * .6 : 0;
		case "coin": return i?.owner === r ? 1.2 : -.5;
		case "steal": return e.target === "wallet" ? 2 : i?.owner === r ? .2 : 2 + (t.task?.kind === "den" ? i?.gold ?? 0 : 0);
		case "guard": return i ? t.cells.filter((e) => e.owner === r && (e === i || Math.abs(e.x - i.x) + Math.abs(e.y - i.y) === 1)).reduce((e, t) => e + D[t.id].cost + t.gold, 0) * .3 : 0;
		case "well": return a.gold >= 2 ? 3 : -1;
		case "magic": {
			let n = t.role, r = n === 3 ? "noble" : n === 4 ? "religious" : n === 5 ? "commercial" : n === 8 ? "military" : "unique";
			return e.target === r ? 3 : 0;
		}
		case "guess": return (n.passed.includes(Number(e.target)) && !n.hand.includes(Number(e.target)) ? 5 : 1) + xe(Number(e.target), t, a.rid) * .05;
	}
}
var Ce = (e, t) => {
	let n = e.private, r = n?.legal ?? [];
	if (!n || !r.length) return null;
	if (t.difficulty === "weak") return { action: r[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % r.length] };
	let i = r[0], a = -Infinity;
	for (let o of r) {
		let r = Se(o, e.public, n, t.rid);
		r > a && (a = r, i = o);
	}
	return { action: i };
}, $ = (e, t, n = t) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), we = { city(e, t) {
	let n = e.data, r = e.rid ?? "", i = t.anchor("seat:" + r), a = t.anchor("cell:" + n.target), o = t.anchor("supply");
	if (n.kind === "build" && a) {
		let e = t.anchor(n.from) ?? o;
		return e ? {
			ms: 650,
			hide: t.queued ? [] : ["cell:" + n.target],
			node: /* @__PURE__ */ y(S, {
				from: e,
				to: a,
				ms: 520,
				children: /* @__PURE__ */ y("div", {
					className: "cd-fx-tile",
					children: /* @__PURE__ */ y(Z, {
						id: n.n,
						copy: p.getState().locale === "zh" ? fe : de
					})
				})
			})
		} : null;
	}
	if (n.kind === "guard" && a) {
		let e = t.anchor(n.from === "council" ? "council" : "cell:" + n.from);
		return e ? {
			ms: 600,
			node: /* @__PURE__ */ y(S, {
				from: $(e, 48),
				to: $(a, 48),
				ms: 500,
				children: /* @__PURE__ */ y("span", {
					className: "cd-fx-guard",
					children: "♜"
				})
			})
		} : null;
	}
	if (n.kind === "capture" && a) return {
		ms: 650,
		node: /* @__PURE__ */ y(C, {
			at: a,
			ms: 650
		})
	};
	if (n.kind === "coin" && a && o) return {
		ms: 520,
		node: /* @__PURE__ */ y(S, {
			from: $(o, 32),
			to: $(a, 32),
			ms: 420,
			children: /* @__PURE__ */ y("span", {
				className: "cd-fx-coin",
				children: n.n
			})
		})
	};
	if (n.kind === "steal" && i) {
		let e = a ?? t.anchor("seat:" + n.from);
		return e ? {
			ms: 600,
			node: /* @__PURE__ */ y(S, {
				from: $(e, 32),
				to: $(i, 32),
				ms: 480,
				children: /* @__PURE__ */ y("span", {
					className: "cd-fx-coin",
					children: n.n
				})
			})
		} : null;
	}
	if ([
		"gold",
		"seats",
		"tribute"
	].includes(n.kind) && i) {
		let e = t.anchor(n.kind === "seats" ? "council" : n.kind === "tribute" ? "seat:" + n.from : "supply");
		return e ? {
			ms: 600,
			node: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(S, {
				from: $(e, 32),
				to: $(i, 32),
				ms: 420,
				children: /* @__PURE__ */ y("span", {
					className: "cd-fx-coin",
					children: n.n
				})
			}), /* @__PURE__ */ y(x, {
				at: i,
				ms: 600,
				children: /* @__PURE__ */ b("span", {
					style: { color: "#edce84" },
					children: ["+", n.n]
				})
			})] })
		} : null;
	}
	if ([
		"deal",
		"exchange",
		"select"
	].includes(n.kind)) {
		let e = t.anchor("council"), a = t.anchor("hand:" + r), o = n.kind === "exchange" ? t.anchor("seat:" + n.from) : e, s = n.kind === "select" ? i : a ?? i;
		return !o || !s || o.w <= 0 || s.w <= 0 ? null : {
			ms: 650,
			node: Array.from({ length: n.kind === "deal" ? 4 : n.kind === "exchange" ? 2 : 1 }, (e, t) => /* @__PURE__ */ y(S, {
				from: $(o, 60, 80),
				to: $(s, 60, 80),
				ms: 380,
				delay: t * 55,
				children: /* @__PURE__ */ y("span", {
					className: "cd-fx-card",
					children: "◆"
				})
			}, t))
		};
	}
	return null;
} };
//#endregion
//#region src/games/citadelsduel/game-over.tsx
function Te(e) {
	let t = e.public, n = me(), r = p((e) => e.locale), [i, a] = s(!0), [o, c] = s(null), l = (n) => {
		let i = e.members.find((e) => e.rid === n);
		return i ? _(i, r) : he(t, n, r);
	}, u = [
		[n.districtScore, (e) => t.scores.find((t) => t.rid === e).districts],
		[n.coinScore, (e) => t.scores.find((t) => t.rid === e).gold],
		[n.seatScore, (e) => t.scores.find((t) => t.rid === e).seats],
		[n.total, (t) => e.result.scores?.[t] ?? 0],
		[n.walletTie, (e) => t.players.find((t) => t.rid === e).gold]
	];
	return /* @__PURE__ */ b("div", {
		className: "cd-root",
		children: [
			/* @__PURE__ */ y(be, {
				public: t,
				private: e.private,
				members: e.members,
				myRid: e.myRid,
				send: () => void 0
			}),
			/* @__PURE__ */ b("div", {
				className: "cd-over",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": n.completed,
				style: { display: i ? "flex" : "none" },
				children: [
					/* @__PURE__ */ y("button", {
						type: "button",
						className: "cd-hide-result",
						"aria-label": n.viewCity,
						onClick: () => a(!1),
						children: "⌄"
					}),
					/* @__PURE__ */ y("h1", { children: n.completed }),
					/* @__PURE__ */ b("p", { children: [
						e.result.winner.map(l).join(" · "),
						" · ",
						e.result.winner.length > 1 ? n.tied : n.winner
					] }),
					/* @__PURE__ */ b("div", {
						className: "cd-score-scroll",
						children: [
							/* @__PURE__ */ b("table", {
								className: "cd-score",
								children: [/* @__PURE__ */ y("thead", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", { children: n.score }), t.players.map((e) => /* @__PURE__ */ y("th", { children: l(e.rid) }, e.rid))] }) }), /* @__PURE__ */ y("tbody", { children: u.map(([e, r]) => /* @__PURE__ */ b("tr", {
									className: e === n.total ? "cd-total" : "",
									children: [/* @__PURE__ */ y("th", {
										scope: "row",
										children: e
									}), t.players.map((e) => /* @__PURE__ */ y("td", { children: r(e.rid) }, e.rid))]
								}, e)) })]
							}),
							e.hintCount !== void 0 && e.onPlayAgain && e.hintCount > 0 && /* @__PURE__ */ b("p", { children: [
								n.hints,
								": ",
								e.hintCount
							] }),
							t.players.filter((t) => (e.result.autopilot?.[t.rid] ?? 0) > 0).map((t) => /* @__PURE__ */ b("p", { children: [
								l(t.rid),
								" · ",
								n.autoplay,
								" ",
								Math.round(e.result.autopilot[t.rid] * 100),
								"%"
							] }, t.rid))
						]
					}),
					/* @__PURE__ */ b("div", {
						className: "cd-over-actions",
						children: [
							/* @__PURE__ */ y("button", {
								type: "button",
								onClick: () => a(!1),
								children: n.viewCity
							}),
							e.onPlayAgain && /* @__PURE__ */ y("button", {
								type: "button",
								onClick: () => c("again"),
								children: n.again
							}),
							e.onBackToLobby && /* @__PURE__ */ y("button", {
								type: "button",
								onClick: () => c("lobby"),
								children: n.lobby
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ y("p", { children: n.waitHost })
						]
					})
				]
			}),
			!i && /* @__PURE__ */ y("button", {
				type: "button",
				className: "cd-show-result",
				onClick: () => a(!0),
				children: n.showResult
			}),
			o && /* @__PURE__ */ y("div", {
				className: "cd-modal-shade",
				children: /* @__PURE__ */ b("div", {
					className: "cd-confirm",
					role: "dialog",
					"aria-modal": "true",
					children: [/* @__PURE__ */ y("h2", { children: o === "again" ? n.confirmAgain : n.confirmLeave }), /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("button", {
						type: "button",
						onClick: () => c(null),
						children: n.cancel
					}), /* @__PURE__ */ y("button", {
						type: "button",
						onClick: () => {
							o === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.();
						},
						children: n.confirm
					})] })]
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/citadelsduel/entry.tsx
var Ee = {
	definition: ue,
	View: ye,
	bot: Ce,
	fx: we,
	OverView: Te,
	locales: {
		zh: fe,
		en: de
	}
};
//#endregion
export { Ee as default };
