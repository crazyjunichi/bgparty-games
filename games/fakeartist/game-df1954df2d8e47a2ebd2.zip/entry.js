import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useRef as n, useState as r } from "react";
import { SquareBox as i } from "@bgparty/sdk/drawing/canvas";
import { useT as a } from "@bgparty/sdk/i18n";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as s } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as c } from "@bgparty/sdk/ui/player-strip";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { AVATARS as p } from "@bgparty/sdk/avatars";
import { Confetti as m } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as h, OptionSection as g } from "@bgparty/sdk/ui/game-options";
//#region src/games/fakeartist/meta.ts
var _ = {
	id: "fakeartist",
	tier: "released",
	mechanics: ["drawing"],
	interactionTags: ["hidden-roles"],
	nameKey: "games.fakeartist.name",
	descKey: "games.fakeartist.desc",
	rulesKey: "games.fakeartist.rules",
	icon: "🕵️",
	iconImg: "games/fakeartist.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/fakeartist/en.pdf" },
	minPlayers: 3,
	maxPlayers: 8,
	bestPlayers: [6, 7],
	accent: "#e14389",
	releasedAt: "2026-09-17",
	search: {
		py: "mao pai yi shu jia chuang niu yue",
		init: "mpysjcny"
	},
	hotseat: "cover"
}, v = 1e3, y = t.array(t.int().min(0).max(v)).min(2).max(1e3).refine((e) => e.length % 2 == 0, "pts 必须是 x,y 点对"), b = t.object({ pts: y }), x = t.string(), S = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("stroke"),
		pts: y
	}),
	t.object({
		type: t.literal("vote"),
		target: x
	}),
	t.object({
		type: t.literal("guess"),
		text: t.string().trim().min(1).max(30)
	})
]), C = [
	1,
	2,
	3
], w = t.object({ rounds: t.union([
	t.literal(1),
	t.literal(2),
	t.literal(3)
]).default(2) }).default({ rounds: 2 }), T = t.object({
	phase: t.enum([
		"draw",
		"vote",
		"guess",
		"over"
	]),
	category: t.string(),
	order: t.array(x),
	rounds: t.int().min(1),
	strokes: t.array(b),
	voted: t.array(x),
	votes: t.record(t.string(), t.string()).nullable(),
	accused: x.nullable(),
	fake: x.nullable(),
	guess: t.string().nullable(),
	guessRight: t.boolean().nullable(),
	word: t.string().nullable()
}), E = t.object({
	isFake: t.boolean(),
	word: t.string().nullable()
}), D = /* @__PURE__ */ JSON.parse("[{\"category\":\"动物\",\"words\":[\"兔子\",\"母鸡\",\"吸血鬼\",\"青蛙\",\"虫子\",\"小狗\",\"豹子\",\"斑马\",\"蜻蜓\",\"火鸡\",\"螃蟹\",\"鸽子\",\"贝壳\",\"企鹅\",\"鱿鱼\",\"蚂蚁\",\"尾巴\",\"长颈鹿\",\"宠物\",\"蜗牛\",\"老鼠\",\"熊猫\",\"大象\",\"蚊子\",\"鸭子\",\"翅膀\",\"小鸡\",\"老虎\",\"猴子\",\"蝌蚪\",\"狮子\",\"大熊猫\",\"蝴蝶\",\"蜘蛛\",\"扇贝\",\"宠物狗\",\"黄鼠狼\",\"浣熊\",\"狐狸\",\"导盲犬\",\"牡蛎\",\"狮子狗\",\"龙虾\",\"臭虫\",\"虱子\",\"蝗虫\",\"海豹\",\"喜鹊\",\"驴子\",\"黑熊\",\"骆驼\",\"绵羊\",\"甲虫\",\"海鸥\",\"草鱼\",\"羊羔\",\"鸳鸯\",\"鼹鼠\",\"蜜蜂\",\"猩猩\",\"母牛\",\"墨鱼\",\"小蜜蜂\",\"野马\",\"黑猩猩\",\"海豚\",\"山羊\",\"爬行动物\",\"奶牛\",\"猎豹\",\"公牛\",\"毛驴\",\"野猪\",\"水牛\",\"触手\",\"小牛\",\"蜂窝\",\"后腿\",\"梅花鹿\",\"大猩猩\",\"动物\",\"触角\",\"河豚\",\"羽毛\",\"蟋蟀\",\"爪子\",\"河马\",\"毛毛虫\",\"羚羊\",\"牲畜\",\"战马\",\"鳞片\",\"信鸽\",\"骏马\",\"海参\",\"章鱼\",\"甲壳\",\"蝙蝠\",\"警犬\",\"老鹰\",\"野兔\",\"小鹿\",\"猫头鹰\",\"马蹄\",\"瓢虫\",\"蚯蚓\",\"蟑螂\",\"鲨鱼\",\"寄居蟹\",\"鸟类\",\"昆虫\",\"耗子\",\"萤火虫\",\"跳蚤\",\"黄蜂\",\"猎物\",\"苍蝇\",\"鲑鱼\",\"水母\",\"金枪鱼\",\"鲸鱼\",\"白蚁\",\"比目鱼\",\"松鼠\",\"海狸\",\"家畜\",\"犀牛\",\"鲶鱼\",\"狼狗\",\"野猫\",\"水獭\",\"鱼类\",\"屎壳郎\",\"海星\",\"豪猪\",\"雄蜂\",\"牦牛\",\"黑豹\",\"蛤蜊\",\"鳗鱼\",\"波斯猫\",\"癞蛤蟆\",\"鬣狗\",\"豺狼\",\"狒狒\",\"犄角\",\"海獭\",\"沙丁鱼\",\"五步蛇\",\"小熊猫\",\"穿山甲\",\"火烈鸟\",\"海象\",\"棕熊\",\"大黄蜂\",\"乌贼\",\"鲈鱼\",\"猎狗\",\"北极熊\",\"蟾蜍\",\"鳕鱼\",\"食蚁兽\",\"鲍鱼\",\"海狮\",\"白鲸\",\"蟒蛇\",\"树懒\",\"美洲豹\",\"豚鼠\",\"蓝鲸\",\"海螺\",\"蚂蚱\",\"猛犸\",\"野驴\",\"白鹭\",\"幼虫\",\"山鸡\",\"米老鼠\",\"螺蛳\",\"驼鹿\",\"野牛\",\"剑齿虎\",\"银鱼\",\"哈巴狗\",\"鹿角\",\"信天翁\",\"牧羊犬\",\"山猫\",\"金龟子\",\"仓鼠\",\"唐老鸭\",\"雪豹\",\"海胆\",\"海葵\",\"猎犬\",\"螳螂\",\"狼犬\",\"土拨鼠\",\"鹈鹕\",\"海牛\",\"白鹅\",\"动物界\",\"胚胎\",\"猿人\"]},{\"category\":\"食物\",\"words\":[\"午餐\",\"奶酪\",\"馒头\",\"葡萄酒\",\"火腿肠\",\"铁观音\",\"绿豆\",\"蛋糕\",\"油条\",\"馄饨\",\"菠萝\",\"西兰花\",\"大蒜\",\"面粉\",\"早饭\",\"红茶\",\"水果\",\"馅饼\",\"黄油\",\"菠菜\",\"香菇\",\"柠檬\",\"四川火锅\",\"小吃\",\"韭菜\",\"豆芽\",\"果子\",\"饮料\",\"豆腐\",\"苹果\",\"番茄\",\"荔枝\",\"奶茶\",\"饼干\",\"花生油\",\"沙拉\",\"零食\",\"果汁\",\"火龙果\",\"啤酒\",\"叉烧包\",\"牛肉\",\"咖啡\",\"巧克力\",\"米线\",\"花生\",\"包子\",\"蜂蜜\",\"椰子\",\"炒面\",\"臭豆腐\",\"冰淇淋\",\"三明治\",\"南瓜\",\"鱼肉\",\"茄子\",\"火锅\",\"香肠\",\"烤肉\",\"蘑菇\",\"萝卜\",\"生菜\",\"冰激凌\",\"酸奶\",\"大米\",\"豆浆\",\"香菜\",\"樱桃\",\"饭菜\",\"青菜\",\"土豆\",\"红薯\",\"金针菇\",\"酱油\",\"火腿\",\"面包\",\"葡萄干\",\"糖果\",\"芒果\",\"牛奶\",\"西红柿\",\"白糖\",\"马铃薯\",\"草莓\",\"核桃\",\"橙子\",\"三文鱼\",\"罐头\",\"卤蛋\",\"午饭\",\"海鲜\",\"香蕉\",\"胡萝卜\",\"木耳\",\"早餐\",\"玉米\",\"牛排\",\"桔子\",\"芝麻\",\"黄瓜\",\"米饭\",\"羊肉\",\"汽水\",\"牛肉面\",\"鸡蛋\",\"蔬菜\",\"奶油\",\"方便面\",\"回锅肉\",\"辣椒\",\"五香牛肉\",\"核桃仁\",\"冰糖葫芦\",\"培根\",\"鸭脖\",\"腊肠\",\"鱼丸\",\"果酱\",\"柑橘\",\"东坡肉\",\"柠檬汁\",\"牛肉干\",\"面团\",\"脐橙\",\"猪肝\",\"稻米\",\"卤牛肉\",\"无花果\",\"大豆\",\"烧肉\",\"扣肉\",\"布丁\",\"比萨\",\"宴席\",\"鲜奶\",\"八宝粥\",\"凉面\",\"香料\",\"谷物\",\"碧螺春\",\"淀粉\",\"海带\",\"豌豆\",\"点心\",\"八宝饭\",\"青梅\",\"方糖\",\"杏仁\",\"冬瓜\",\"四喜丸子\",\"芥末\",\"花菜\",\"生姜\",\"土豆泥\",\"威士忌\",\"腊肉\",\"晚餐\",\"糖浆\",\"五香粉\",\"肉食\",\"龙井茶\",\"黄豆\",\"白粥\",\"腊八粥\",\"咖喱粉\",\"鸭肉\",\"凤爪\",\"南瓜汤\",\"烧酒\",\"菜肴\",\"凉菜\",\"粉条\",\"梨子\",\"石榴\",\"南瓜饼\",\"沙拉酱\",\"汤包\",\"熏肉\",\"快餐\",\"绿豆汤\",\"果肉\",\"棉花糖\",\"肉干\",\"山药\",\"春卷\",\"木瓜\",\"杏子\",\"虾米\",\"紫菜\",\"莲藕\",\"冰沙\",\"普洱茶\",\"咖啡豆\",\"夏威夷果\",\"植物油\",\"土豆饼\",\"肉末\",\"面筋\",\"黑森林\",\"泡菜\",\"牛油\",\"圣女果\",\"粉蒸肉\",\"蛋卷\",\"饮用水\",\"生蚝\",\"自助餐\",\"豆腐干\",\"吐司\",\"伏特加\",\"水蜜桃\",\"山竹\",\"鹌鹑蛋\",\"糖水\",\"切糕\",\"豆腐脑\",\"胡椒\",\"鸡尾酒\",\"葡萄汁\",\"二锅头\",\"菜籽油\",\"食物\",\"烤全羊\",\"涮羊肉\",\"带鱼\",\"番茄酱\",\"炸酱面\",\"梅子\",\"佛跳墙\",\"青团\",\"奇异果\",\"凉皮\",\"豆油\",\"焦糖\",\"蒜苗\",\"米糕\",\"米粥\",\"果实\",\"红葡萄酒\",\"煮鸡蛋\",\"鱼头\",\"辣椒粉\",\"纯净水\",\"冷面\",\"雪梨\",\"面皮\",\"坚果\",\"重庆火锅\",\"柑桔\",\"过桥米线\",\"卡布基诺\",\"豆皮\",\"甜瓜\",\"玉米饼\",\"咖喱\",\"橘子\",\"香槟酒\",\"凉粉\",\"煎饼\",\"花生糖\",\"红椒\",\"通心粉\",\"水煮鱼\",\"燕麦片\",\"冬枣\",\"孜然\",\"芝士\",\"哈密瓜\",\"里脊\",\"洋葱\",\"辣椒酱\",\"糕饼\",\"乌龙茶\",\"苏打水\",\"黑米\",\"咖喱牛肉\",\"烤羊肉\",\"卤味\",\"剁椒鱼头\",\"意大利面\",\"京酱肉丝\",\"苏打\",\"川菜\",\"粤菜\",\"鲁菜\",\"家常菜\",\"姜黄\",\"三杯鸡\",\"薄饼\",\"刀削面\",\"卤面\",\"清汤\",\"牛扒\",\"压缩饼干\",\"椰枣\",\"酥油\",\"白葡萄酒\",\"莴笋\",\"满汉全席\",\"低筋面粉\",\"四川泡菜\",\"凉糕\",\"东坡肘子\",\"茶汤\",\"人参果\",\"口水鸡\",\"牛尾\",\"油茶\",\"凤尾鱼\",\"薏仁\",\"芦笋\",\"多宝鱼\",\"猪血\",\"驴肉\",\"桃酥\",\"锅贴\",\"乳猪\",\"浆果\",\"鹅肉\",\"保健茶\",\"西湖龙井\",\"海蜇\",\"养生汤\",\"辣子\",\"糙米\",\"咖啡糖\",\"麻辣烫\",\"烧鹅\",\"提拉米苏\",\"猕猴桃\",\"橄榄油\",\"云吞面\",\"西米\",\"牛乳\",\"鹅肝\",\"酒酿\",\"丁香\",\"果丹皮\",\"马提尼\",\"蒸饺\",\"肉粥\",\"甜食\",\"老酒\",\"筵席\",\"白茶\",\"啤酒鸭\",\"干红\",\"动物油\",\"豆豉\",\"雪糕\",\"葡萄柚\",\"烤羊肉串\",\"野味\",\"西芹\",\"山核桃\",\"千张\",\"鱼生\",\"乳酪蛋糕\",\"冰粉\",\"花椰菜\",\"芽菜\",\"大肉\",\"白肉\",\"松茸\",\"豆汁\",\"香油\",\"酒肉\",\"信阳毛尖\",\"起司\",\"花卷\",\"吞拿鱼\",\"甜酒\",\"椒盐\",\"酥油茶\",\"啫喱\",\"酸辣汤\",\"红油\",\"菱角\",\"清酒\",\"豆腐乳\",\"叫化鸡\",\"大红袍\",\"米面\",\"鱼子酱\",\"狮子头\",\"蔗糖\",\"杂碎\",\"百香果\",\"甜面酱\",\"冰皮月饼\",\"白斩鸡\",\"萨其马\"]},{\"category\":\"交通工具\",\"words\":[\"出租汽车\",\"汽车\",\"巴士\",\"火车\",\"车轮\",\"直升机\",\"列车\",\"自行车\",\"摩托车\",\"救护车\",\"吉普车\",\"轿车\",\"铁路\",\"卡车\",\"出租车\",\"地铁\",\"飞机\",\"二手车\",\"小船\",\"车窗\",\"轰炸机\",\"雪橇\",\"机车\",\"警车\",\"飞船\",\"游艇\",\"装甲车\",\"车门\",\"游船\",\"货车\",\"战舰\",\"客机\",\"公车\",\"山地车\",\"越野车\",\"铁轨\",\"火车头\",\"车辆\",\"手推车\",\"后座\",\"飞艇\",\"驾驶舱\",\"快艇\",\"机舱\",\"运钞车\",\"车身\",\"新车\",\"船只\",\"航空母舰\",\"机翼\",\"吉普\",\"电车\",\"渔船\",\"直升飞机\",\"机动车\",\"马车\",\"拖车\",\"船舱\",\"船头\",\"自动挡\",\"驱逐舰\",\"长途汽车\",\"童车\",\"水翼船\",\"货舱\",\"皮艇\",\"婴儿车\",\"邮车\",\"划艇\",\"救生船\",\"救生筏\",\"驳船\",\"登陆艇\",\"货船\",\"黄包车\",\"风帆\",\"人力车\",\"吊车\",\"篷车\",\"车体\",\"船体\",\"风挡玻璃\",\"气垫船\",\"叉车\",\"赛艇\",\"机体\",\"旗舰\",\"喷气机\",\"独木舟\",\"商船\",\"缆车\",\"独轮车\",\"渡船\",\"战列舰\",\"巡洋舰\",\"垃圾车\",\"消防车\",\"新干线\",\"船舶\",\"起落架\",\"电动车\",\"甲板\",\"桅杆\",\"救生艇\",\"登月舱\",\"敞篷车\",\"小轿车\",\"舱门\",\"餐车\",\"推土机\",\"牛车\",\"炮艇\",\"护卫舰\",\"邮船\",\"休闲车\",\"底盘\",\"滑翔机\",\"铲车\",\"小舟\",\"大篷车\",\"热气球\",\"轿子\",\"机身\",\"水上飞机\",\"灵车\",\"花车\",\"面包车\",\"老爷车\",\"破冰船\",\"碰碰车\",\"计程车\"]},{\"category\":\"日常物品\",\"words\":[\"背包\",\"裤子\",\"风筝\",\"时钟\",\"光盘\",\"计算器\",\"窗帘\",\"夹克\",\"笔记本\",\"外套\",\"显示器\",\"袖子\",\"毯子\",\"耳机\",\"杆子\",\"饭盒\",\"电视\",\"旗子\",\"钱包\",\"电灯\",\"国旗\",\"计算机\",\"袜子\",\"手机\",\"桌子\",\"玩偶\",\"钉子\",\"筷子\",\"衣服\",\"书桌\",\"西装\",\"抽屉\",\"风扇\",\"扫帚\",\"火柴\",\"地图\",\"围巾\",\"行李\",\"砖头\",\"柜子\",\"梯子\",\"毛衣\",\"饭桌\",\"围裙\",\"信封\",\"地板\",\"柱子\",\"发动机\",\"工具\",\"管子\",\"家具\",\"衬衫\",\"保险箱\",\"前门\",\"钥匙\",\"玩具\",\"耳环\",\"雪茄\",\"刹车\",\"碟子\",\"戒指\",\"架子\",\"菜刀\",\"照片\",\"座位\",\"打印机\",\"骰子\",\"假发\",\"箭头\",\"枕头\",\"键盘\",\"凳子\",\"秋千\",\"电池\",\"绳子\",\"灯笼\",\"瓶子\",\"水桶\",\"开关\",\"杯子\",\"沙发\",\"盖子\",\"药物\",\"篮子\",\"吹风机\",\"墙壁\",\"空调\",\"鞋子\",\"话筒\",\"浴缸\",\"机器人\",\"气球\",\"按钮\",\"电视机\",\"大衣\",\"盒子\",\"香烟\",\"电灯泡\",\"手表\",\"轮胎\",\"烟花\",\"服装\",\"电话\",\"手电筒\",\"毛巾\",\"电梯\",\"短裤\",\"模型\",\"烤箱\",\"雨衣\",\"袋子\",\"图画\",\"口袋\",\"图片\",\"手套\",\"电脑\",\"锤子\",\"窗户\",\"书架\",\"灯泡\",\"相机\",\"餐桌\",\"帘子\",\"后门\",\"镜子\",\"包裹\",\"眼镜\",\"椅子\",\"陷阱\",\"化妆品\",\"外衣\",\"机器\",\"水壶\",\"裙子\",\"项链\",\"帽子\",\"上衣\",\"盘子\",\"箱子\",\"轮子\",\"冰箱\",\"鼠标\",\"餐具\",\"卡片\",\"指南针\",\"口罩\",\"圆圈\",\"互联网\",\"卫星\",\"窗口\",\"暖气\",\"唇膏\",\"指针\",\"堤坝\",\"烛台\",\"门牌\",\"外壳\",\"长袖\",\"壁炉\",\"窗子\",\"夹子\",\"止痛药\",\"洋娃娃\",\"障碍物\",\"衣裳\",\"收割机\",\"餐巾\",\"球鞋\",\"螺旋桨\",\"手提包\",\"解毒剂\",\"纪念品\",\"手绢\",\"砂纸\",\"洗碗机\",\"浴盆\",\"防弹衣\",\"肖像\",\"横幅\",\"手工艺品\",\"硬盘\",\"袖口\",\"铁丝网\",\"圣诞树\",\"控制器\",\"制服\",\"衣橱\",\"链条\",\"肥皂\",\"雕像\",\"胸罩\",\"和服\",\"照相机\",\"板子\",\"香水\",\"起重机\",\"晚礼服\",\"项圈\",\"紧身衣\",\"胶带\",\"窃听器\",\"配件\",\"烟囱\",\"支架\",\"纸杯\",\"膏药\",\"栏杆\",\"拼图\",\"护身符\",\"打火机\",\"套装\",\"首饰\",\"面板\",\"电话线\",\"地基\",\"旗杆\",\"图纸\",\"镜片\",\"车牌\",\"显微镜\",\"火盆\",\"王冠\",\"绳索\",\"踏板\",\"仪器\",\"纸牌\",\"刀子\",\"望远镜\",\"包袱\",\"迷彩服\",\"过滤器\",\"服饰\",\"行李箱\",\"门槛\",\"电锯\",\"锄头\",\"短裙\",\"盆景\",\"卷烟\",\"门铃\",\"用具\",\"成品\",\"衣着\",\"内裤\",\"刺绣\",\"底座\",\"集装箱\",\"摇篮\",\"天线\",\"复制品\",\"扣子\",\"长裙\",\"钩子\",\"烟斗\",\"雕塑\",\"圆盘\",\"木马\",\"腰带\",\"橱柜\",\"闹钟\",\"礼帽\",\"手提箱\",\"门锁\",\"胭脂\",\"赝品\",\"鞭炮\",\"链子\",\"钻头\",\"古董\",\"设计图\",\"容器\",\"炉子\",\"尿布\",\"水槽\",\"吸管\",\"纽扣\",\"阿司匹林\",\"奖品\",\"补丁\",\"麦克风\",\"勺子\",\"邮箱\",\"头盔\",\"栅栏\",\"摊子\",\"挡风玻璃\",\"复印机\",\"喇叭\",\"金牌\",\"毛毯\",\"引擎\",\"招牌\",\"笼子\",\"蜡烛\",\"器具\",\"镰刀\",\"隐形眼镜\",\"文件夹\",\"广告牌\",\"雷管\",\"防毒面具\",\"墓碑\",\"爆竹\",\"鱼缸\",\"病床\",\"腰包\",\"水龙头\",\"床单\",\"钳子\",\"茶几\",\"油门\",\"摄像机\",\"时针\",\"电动机\",\"皮靴\",\"拐杖\",\"衬衣\",\"漏斗\",\"信箱\",\"录音带\",\"垫子\",\"柜台\",\"公文包\",\"艺术品\",\"门框\",\"手镯\",\"篮板\",\"陀螺\",\"盔甲\",\"带子\",\"杂货\",\"工作服\",\"麻醉药\",\"芯片\",\"锅炉\",\"装饰品\",\"监视器\",\"铠甲\",\"长椅\",\"电路板\",\"宝石\",\"陶瓷\",\"把手\",\"名片\",\"火炉\",\"路障\",\"火把\",\"硬件\",\"垃圾袋\",\"电瓶\",\"激光\",\"天平\",\"手铐\",\"篱笆\",\"球门\",\"传感器\",\"对讲机\",\"零部件\",\"棍棒\",\"礼服\",\"雨伞\",\"口红\",\"胶片\",\"绷带\",\"纱布\",\"领带\",\"讲台\",\"棋盘\",\"垃圾箱\",\"斧子\",\"拐角\",\"运动衫\",\"壁橱\",\"假牙\",\"帐篷\",\"记事本\",\"渔网\",\"火箭\",\"麻袋\",\"手杖\",\"镇静剂\",\"算盘\",\"零件\",\"银幕\",\"鞋带\",\"发电机\",\"铁丝\",\"蓄电池\",\"礼物\",\"录音机\",\"酒壶\",\"镜头\",\"怀表\",\"油箱\",\"铁锤\",\"齿轮\",\"诱饵\",\"叉子\",\"橱窗\",\"生产线\",\"附件\",\"床垫\",\"天花板\",\"珠宝\",\"火炬\",\"鞭子\",\"锁链\",\"药丸\",\"收音机\",\"清洁剂\",\"吸尘器\",\"罐子\",\"婚纱\",\"封面\",\"面具\",\"筹码\",\"牛仔裤\",\"宝座\",\"咖啡杯\",\"刷子\",\"珠子\",\"头巾\",\"衣领\",\"奖杯\",\"抗生素\",\"垃圾桶\",\"唱片\",\"刀锋\",\"瓷器\",\"衣柜\",\"面罩\",\"微波炉\",\"爆炸物\",\"药片\",\"塑像\",\"磁盘\",\"工具箱\",\"弹簧\",\"军装\",\"人造卫星\",\"纺织品\",\"电缆\",\"设备\",\"器械\",\"收藏品\",\"牌子\",\"警报器\",\"号角\",\"牌照\",\"闪光灯\",\"刀片\",\"面纱\",\"主机\",\"围栏\",\"烟灰缸\",\"烟头\",\"手帕\",\"棋子\",\"斗篷\",\"靴子\",\"写字台\",\"别针\",\"皮带\",\"战利品\",\"长袍\",\"瓷砖\",\"彩电\",\"证件\",\"桌面\",\"皮包\",\"旗帜\",\"比基尼\",\"天窗\",\"地毯\",\"铁板\",\"相片\",\"刀刃\",\"眼罩\",\"梳子\",\"斧头\",\"披风\",\"电话机\",\"因特网\",\"货物\",\"电路\",\"杰作\",\"标记\",\"图像\",\"有线电视\",\"飞碟\",\"模板\",\"格子\",\"穿着\",\"备份\",\"传真\",\"组件\",\"内存\",\"防线\",\"药品\",\"蓝图\",\"模块\",\"机械\",\"设施\",\"录像\",\"拷贝\",\"框架\",\"终端\",\"王牌\",\"防火墙\",\"遥控\",\"电钻\",\"透镜\",\"榔头\",\"发生器\",\"救生衣\",\"蜡笔\",\"燃烧弹\",\"火箭筒\",\"模子\",\"瓦罐\",\"汤匙\",\"衣帽架\",\"卷尺\",\"星条旗\",\"电热毯\",\"洗衣粉\",\"啤酒杯\",\"砂锅\",\"陶器\",\"磁带\",\"基座\",\"去污剂\",\"铜板\",\"织机\",\"被单\",\"锉刀\",\"羊毛衫\",\"阿莫西林\",\"瓶盖\",\"避雷针\",\"马赛克\",\"鸟笼\",\"穿衣镜\",\"留声机\",\"插座\",\"双层床\",\"古龙水\",\"画架\",\"风景画\",\"元件\",\"电风扇\",\"绳梯\",\"墩布\",\"扶手椅\",\"蜘蛛网\",\"桂冠\",\"高压锅\",\"扳机\",\"奶嘴\",\"尾灯\",\"鼓槌\",\"纸板\",\"横梁\",\"锁孔\",\"戒尺\",\"七巧板\",\"行军床\",\"探照灯\",\"探测器\",\"烧瓶\",\"刨子\",\"赠品\",\"铺盖\",\"集成电路\",\"软膏\",\"弹子\",\"古物\",\"落地窗\",\"传真机\",\"领子\",\"鸭舌帽\",\"铜器\",\"呼吸器\",\"扫把\",\"啤酒瓶\",\"老虎机\",\"管道\",\"凿子\",\"急救箱\",\"灭火器\",\"帷幕\",\"会议桌\",\"担子\",\"底子\",\"花环\",\"古玩\",\"风帽\",\"传送带\",\"沙发椅\",\"反应堆\",\"炉火\",\"汗衫\",\"墨盒\",\"三角裤\",\"暖炉\",\"发簪\",\"玻璃杯\",\"冰袋\",\"饰物\",\"电冰箱\",\"长裤\",\"千斤顶\",\"超短裙\",\"汽笛\",\"纸盒\",\"煤气灶\",\"机关枪\",\"分机\",\"羽绒被\",\"冰镐\",\"工装裤\",\"布告栏\",\"割草机\",\"凉鞋\",\"塞子\",\"布景\",\"平面图\",\"砖块\",\"迷你裙\",\"万花筒\",\"线圈\",\"连衣裙\",\"烙铁\",\"外皮\",\"绞肉机\",\"平底锅\",\"耳塞\",\"发条\",\"淋浴器\",\"花束\",\"导管\",\"喇叭裤\",\"首饰盒\",\"皮帽\",\"筛子\",\"发夹\",\"扶手\",\"蚊帐\",\"存储器\",\"抽水马桶\",\"收银机\",\"脸盆\",\"军旗\",\"量筒\",\"黑匣子\",\"除臭剂\",\"钻井\",\"蒙汗药\",\"立方体\",\"粉笔\",\"护目镜\",\"软垫\",\"软管\",\"体温计\",\"鸟枪\",\"钢盔\",\"保险丝\",\"幻灯片\",\"便帽\",\"长凳\",\"把柄\",\"布洛芬\",\"熨斗\",\"猎刀\",\"信号灯\",\"螺丝钉\",\"云梯\",\"红药水\",\"皮鞭\",\"螺栓\",\"屠刀\",\"枕套\",\"放映机\",\"百叶窗\",\"煤气罐\",\"折叠椅\",\"利器\",\"工事\",\"行囊\",\"铆钉\",\"衣夹\",\"热水袋\",\"马达\",\"披肩\",\"退烧药\",\"缰绳\",\"救生圈\",\"调羹\",\"轴承\",\"纱窗\",\"花边\",\"沙发床\",\"床架\",\"鱼钩\",\"扬声器\",\"套索\",\"脚盆\",\"碗柜\",\"蝴蝶结\",\"眉笔\",\"排水管\",\"鱼饵\",\"水晶球\",\"电唱机\",\"放大镜\",\"警棍\",\"书橱\",\"衣架\",\"裤衩\",\"卡宾枪\",\"便服\",\"胶囊\",\"枷锁\",\"印刷机\",\"开瓶器\",\"闸门\",\"装置\",\"耙子\",\"手锯\",\"高脚杯\",\"夹层\",\"短袖\",\"量杯\",\"魔方\",\"搅拌器\",\"戏装\",\"罩袍\",\"防御工事\",\"镯子\",\"唱机\",\"尖顶\",\"坐垫\",\"电极\",\"花盆\",\"气囊\",\"锥子\",\"蒲团\",\"抹布\",\"短袜\",\"节拍器\",\"点火器\",\"器皿\",\"咖啡壶\",\"药箱\",\"行李袋\",\"扩音器\",\"绞刑架\",\"操纵杆\",\"断头台\",\"指挥棒\",\"镣铐\",\"感冒药\",\"簸箕\",\"杠杆\",\"止泻药\",\"手袋\",\"奶瓶\",\"头饰\",\"浴巾\",\"投票箱\",\"铁锹\",\"缆绳\",\"撬棍\",\"马刀\",\"微处理器\",\"落地灯\",\"瓶塞\",\"核反应堆\",\"缎带\",\"助听器\",\"文件柜\",\"毛瑟枪\",\"靠背\",\"案板\",\"来复枪\",\"丝带\",\"镊子\",\"浴衣\",\"门闩\",\"热水瓶\",\"手柄\",\"吊床\",\"消毒剂\",\"灯笼裤\",\"木桶\",\"贝雷帽\",\"积木\",\"推车\",\"跳板\",\"模具\",\"发卡\",\"棺材\",\"床罩\",\"灯罩\",\"夹板\",\"睡袋\",\"樟脑丸\",\"便装\",\"挂钩\",\"水箱\",\"烤炉\",\"放大器\",\"弹夹\",\"邮筒\",\"鱼叉\",\"激光器\",\"托盘\",\"钓竿\",\"马裤\",\"澡盆\",\"滑梯\",\"折叠床\",\"武器库\",\"燕尾服\",\"泻药\",\"工作台\",\"生物武器\",\"休闲服\",\"安全帽\",\"消防栓\",\"靠垫\",\"双人床\",\"导火线\",\"消费品\",\"支线\",\"染发剂\",\"无线电\",\"药材\",\"盛装\",\"支点\",\"装束\",\"工位\",\"架构\",\"极品\",\"文物\",\"光源\",\"电报\",\"端口\"]},{\"category\":\"运动\",\"words\":[\"潜水\",\"冲浪\",\"篮球\",\"足球\",\"网球\",\"棒球\",\"橄榄球\",\"拳击\",\"游泳\",\"射击\",\"垒球\",\"帆船\",\"冰球\",\"保龄球\",\"奖牌\",\"跆拳道\",\"滑雪\",\"滑板\",\"滑冰\",\"登山\",\"台球\",\"曲棍球\",\"体操\",\"赛车\",\"高尔夫球\",\"赛马\",\"马拉松\",\"跳伞\",\"板球\",\"柔道\",\"乒乓球\",\"摔跤\",\"铜牌\",\"拔河\",\"银牌\",\"排球\",\"鞍马\",\"跳绳\",\"滑雪板\",\"羽毛球\",\"滑翔\",\"马术\",\"水球\",\"标枪\",\"接力赛\",\"壁球\",\"斗牛\",\"速滑\",\"擂台\",\"球网\",\"花剑\",\"跳高\",\"击剑\",\"铅球\",\"溜冰鞋\",\"重剑\",\"跳水\",\"短跑\",\"佩剑\",\"毽子\",\"举重\",\"皮划艇\",\"斯诺克\",\"长跑\",\"手球\",\"接力棒\",\"相扑\",\"跳远\",\"龙舟\",\"射箭\",\"双杠\",\"铁饼\",\"平衡木\",\"吊环\",\"瑜伽\",\"单杠\",\"竞走\",\"杠铃\",\"哑铃\",\"太极拳\",\"冰鞋\",\"帆板\",\"跳马\",\"撑杆跳\",\"跨栏\",\"高低杠\",\"球拍\"]},{\"category\":\"职业\",\"words\":[\"宇航员\",\"模特\",\"护士\",\"消防员\",\"裁判\",\"警察\",\"教师\",\"工人\",\"服务员\",\"歌手\",\"医生\",\"设计师\",\"厨师\",\"农民\",\"医师\",\"经济学家\",\"天文学家\",\"小贩\",\"音乐家\",\"店员\",\"外交官\",\"建筑师\",\"营业员\",\"歌唱家\",\"水手\",\"考古学家\",\"药剂师\",\"技工\",\"技师\",\"农夫\",\"航天员\",\"摄影师\",\"作曲家\",\"律师\",\"矿工\",\"保姆\",\"驾驶员\",\"裁缝\",\"侍者\",\"艺人\",\"编剧\",\"渔民\",\"批评家\",\"评论家\",\"哲学家\",\"大主教\",\"海员\",\"传教士\",\"领班\",\"僧侣\",\"史学家\",\"历史学家\",\"主教\",\"牧师\",\"思想家\",\"分析家\"]},{\"category\":\"自然\",\"words\":[\"瀑布\",\"雨水\",\"柳树\",\"辐射\",\"田野\",\"小河\",\"森林\",\"树枝\",\"海洋\",\"太阳\",\"风暴\",\"彩虹\",\"星星\",\"下雪\",\"月亮\",\"玫瑰\",\"海滩\",\"叶子\",\"草地\",\"地球\",\"风景\",\"雷电\",\"晴天\",\"天气\",\"小雨\",\"天空\",\"星座\",\"土地\",\"地面\",\"阳光\",\"宇宙\",\"烟雾\",\"暴风雨\",\"树皮\",\"灌木\",\"金星\",\"大洋\",\"行星\",\"香草\",\"山谷\",\"百合\",\"海滨\",\"露水\",\"高山\",\"悬崖\",\"山丘\",\"烟草\",\"草药\",\"海湾\",\"沼泽地\",\"树干\",\"洪水\",\"小行星\",\"河边\",\"肉桂\",\"茉莉\",\"山脉\",\"恒星\",\"灌木丛\",\"彗星\",\"斜坡\",\"小麦\",\"岛屿\",\"大气层\",\"陆地\",\"杂草\",\"积雪\",\"高地\",\"稻谷\",\"樱花\",\"绿叶\",\"干草\",\"堤岸\",\"薄荷\",\"荒野\",\"白杨\",\"冰川\",\"树梢\",\"温泉\",\"荒原\",\"荒地\",\"草丛\",\"青草\",\"橡树\",\"野草\",\"水塘\",\"火山\",\"火星\",\"港湾\",\"野外\",\"稻草\",\"海岸\",\"河流\",\"月球\",\"小山\",\"湖泊\",\"洞穴\",\"薄雾\",\"微风\",\"太空\",\"深渊\",\"降雨\",\"水蒸气\",\"景观\",\"光线\",\"日光\",\"光束\",\"热气\",\"蒸汽\",\"天边\",\"蒸气\",\"星光\",\"雾气\",\"地平线\",\"浪花\",\"极光\",\"闪光\",\"金牛座\",\"霹雳\",\"黄花菜\",\"地瓜\",\"檀香\",\"桃树\",\"山冈\",\"雏菊\",\"枣树\",\"葡萄藤\",\"白桦\",\"林地\",\"溪谷\",\"豆角\",\"枸杞\",\"月季\",\"水灾\",\"海草\",\"石窟\",\"果核\",\"年轮\",\"大山\",\"槟榔\",\"阵雨\",\"群岛\",\"葫芦\",\"梨树\",\"橡木\",\"龙眼\",\"藤蔓\",\"金橘\",\"青豆\",\"树莓\",\"酵母\",\"苹果树\",\"沼泽\",\"椰树\",\"爬山虎\",\"山脊\",\"海藻\",\"紫藤\",\"山楂\",\"牵牛花\",\"栀子\",\"鹅卵石\",\"棕榈\",\"晚霞\",\"海棠\",\"榛子\",\"北极光\",\"洞窟\",\"盆栽\",\"人工湖\",\"金银花\",\"芳草\",\"蔷薇\",\"柚子\",\"荞麦\",\"花椒\",\"毛豆\",\"扁豆\",\"红果\",\"甜椒\",\"芭蕉\",\"枫树\",\"垂柳\",\"佛手\",\"湿地\",\"百合花\",\"夜来香\",\"松露\",\"木薯\",\"北冰洋\",\"茴香\",\"桂皮\",\"杏树\",\"郁金香\",\"泉水\",\"沟渠\",\"冰河\",\"花苞\",\"红豆\",\"亚麻\",\"荆棘\",\"藻类\",\"绝壁\",\"蚕豆\",\"茶花\",\"牧草\",\"八角\",\"罗勒\",\"水流\",\"田间\",\"地带\",\"沿岸\",\"天际\"]},{\"category\":\"建筑与地标\",\"words\":[\"码头\",\"厕所\",\"通道\",\"食堂\",\"阳台\",\"马路\",\"入口\",\"医院\",\"事务所\",\"图书馆\",\"酒吧\",\"后院\",\"宾馆\",\"学院\",\"咖啡馆\",\"大厦\",\"花园\",\"沙漠\",\"酒店\",\"工厂\",\"商店\",\"楼梯\",\"机场\",\"影院\",\"游泳池\",\"博物馆\",\"公路\",\"仓库\",\"餐馆\",\"市场\",\"书店\",\"旅馆\",\"道路\",\"夜总会\",\"广场\",\"大楼\",\"大道\",\"健身房\",\"浴室\",\"法院\",\"客厅\",\"药店\",\"大街\",\"农场\",\"卧室\",\"工作室\",\"牢房\",\"饭馆\",\"学校\",\"教室\",\"餐厅\",\"公寓\",\"大厅\",\"车库\",\"球场\",\"人行道\",\"赌场\",\"超市\",\"十字路口\",\"厨房\",\"建筑\",\"门口\",\"饭店\",\"房间\",\"房子\",\"办公室\",\"街道\",\"运河\",\"小巷\",\"密室\",\"地牢\",\"寺庙\",\"操场\",\"动物园\",\"小酒馆\",\"温室\",\"房顶\",\"里弄\",\"公墓\",\"体育馆\",\"药房\",\"小径\",\"庙宇\",\"碉堡\",\"领事馆\",\"军营\",\"牧场\",\"茅屋\",\"客栈\",\"阁楼\",\"防空洞\",\"大使馆\",\"套间\",\"隔间\",\"居住区\",\"休息室\",\"乐园\",\"宿舍\",\"屋檐\",\"病房\",\"游乐场\",\"杂货店\",\"会议室\",\"网吧\",\"门廊\",\"住处\",\"电影院\",\"水库\",\"大学\",\"课堂\",\"水池\",\"洗衣店\",\"赛道\",\"市郊\",\"路口\",\"套房\",\"车道\",\"纪念碑\",\"顶楼\",\"高速公路\",\"疯人院\",\"库房\",\"运动场\",\"观众席\",\"街区\",\"孤儿院\",\"殡仪馆\",\"酒馆\",\"港口\",\"连锁店\",\"收容所\",\"金矿\",\"庭院\",\"法庭\",\"竞技场\",\"医务室\",\"画廊\",\"军事基地\",\"走廊\",\"店铺\",\"起居室\",\"太平间\",\"游乐园\",\"里屋\",\"更衣室\",\"洗衣房\",\"咖啡店\",\"书房\",\"马厩\",\"墓地\",\"储藏室\",\"喷泉\",\"地下室\",\"银行\",\"舞厅\",\"别墅\",\"站台\",\"疗养院\",\"农庄\",\"过道\",\"车间\",\"旅店\",\"草坪\",\"展馆\",\"研究室\",\"控制室\",\"寺院\",\"棚子\",\"陵墓\",\"礼堂\",\"避难所\",\"客房\",\"死胡同\",\"使馆\",\"小屋\",\"谷仓\",\"篮球场\",\"前台\",\"庄园\",\"监狱\",\"驾校\",\"天文台\",\"灯塔\",\"护城河\",\"禁闭室\",\"包厢\",\"坟墓\",\"长城\",\"营地\",\"面包店\",\"舞池\",\"乡下\",\"体育场\",\"跑道\",\"废墟\",\"拘留所\",\"郊外\",\"场地\",\"海关\",\"花店\",\"公园\",\"大路\",\"家里\",\"理发店\",\"精神病院\",\"堡垒\",\"郊区\",\"神殿\",\"矿井\",\"迷宫\",\"校舍\",\"城堡\",\"住所\",\"干洗店\",\"飞机场\",\"煤矿\",\"大本营\",\"集市\",\"角落\",\"战场\",\"舞台\",\"主场\",\"住宅\",\"目的地\",\"屋顶\",\"教堂\",\"隧道\",\"住房\",\"台阶\",\"基地\",\"屋子\",\"桥梁\",\"院子\",\"实验室\",\"住址\",\"建筑物\",\"胡同\",\"都市\",\"围墙\",\"出路\",\"房屋\",\"城镇\",\"望塔\",\"登机口\",\"驾驶室\",\"藏书室\",\"园林\",\"滑冰场\",\"月台\",\"军火库\",\"宫廷\",\"饭厅\",\"闺房\",\"路基\",\"货摊\",\"粮仓\",\"会议厅\",\"战壕\",\"候诊室\",\"售票处\",\"时装店\",\"山寨\",\"接待室\",\"指挥所\",\"纺织厂\",\"宿营地\",\"兵工厂\",\"排水沟\",\"小道\",\"酒吧间\",\"画室\",\"舞场\",\"超级市场\",\"水渠\",\"水沟\",\"门厅\",\"火葬场\",\"五金店\",\"王宫\",\"市政厅\",\"吊桥\",\"遗址\",\"植物园\",\"壕沟\",\"消防站\",\"前院\",\"公馆\",\"苹果园\",\"快车道\",\"沙龙\",\"沙场\",\"研究院\",\"要塞\",\"候车室\",\"制造厂\",\"铸造厂\",\"前庭\",\"车棚\",\"花圃\",\"塔楼\",\"救济院\",\"拱桥\",\"海港\",\"防波堤\",\"弹药库\",\"地穴\",\"衣帽间\",\"零售店\",\"盥洗室\",\"酒窖\",\"岗亭\",\"市集\",\"尖塔\",\"斑马线\",\"农舍\",\"苗圃\",\"会堂\",\"难民营\",\"百货商店\",\"工场\",\"阅览室\",\"冰库\",\"当铺\",\"回廊\",\"会计室\",\"浴场\",\"台球室\",\"澡堂\",\"近郊\",\"磨坊\",\"水闸\",\"冰球场\",\"水坝\",\"弄堂\",\"走道\",\"播音室\",\"小卖部\",\"停机坪\",\"浮桥\",\"旅社\",\"感化院\",\"控制塔\",\"管教所\",\"农贸市场\",\"监牢\",\"男厕\",\"村舍\",\"铁道\",\"档案馆\",\"地窖\",\"纪念堂\",\"修道院\",\"林荫道\",\"前厅\",\"礼品店\",\"种植园\",\"哨所\",\"暗室\",\"卢浮宫\",\"兵营\",\"咖啡屋\",\"赛马场\",\"面包房\",\"宝库\",\"厢房\",\"急救站\",\"美容院\",\"公寓楼\",\"发射台\",\"栈桥\",\"美术馆\",\"棚屋\",\"凉亭\",\"钟楼\",\"产房\",\"溜冰场\",\"水井\",\"机库\",\"养鸡场\",\"天井\",\"班房\",\"候机室\",\"招待所\",\"飞机库\",\"拱门\",\"百货公司\",\"阶梯\",\"糖果店\",\"屠宰场\",\"人行横道\",\"书报摊\",\"交易所\",\"酒廊\",\"前线\",\"维修厂\",\"正门\",\"古墓\",\"总部\",\"要道\",\"航道\",\"指挥部\",\"司令部\",\"宫殿\"]},{\"category\":\"乐器与文娱\",\"words\":[\"剧本\",\"小丑\",\"吉他\",\"漫画\",\"魔术\",\"乐器\",\"钢琴\",\"电视剧\",\"动画片\",\"华尔兹\",\"芭蕾\",\"乐团\",\"现代舞\",\"话剧\",\"萨克斯\",\"迪斯科\",\"摊牌\",\"大提琴\",\"小品\",\"木偶\",\"打牌\",\"国标舞\",\"游戏机\",\"下棋\",\"摇摆舞\",\"霹雳舞\",\"爵士舞\",\"探戈\",\"大号\",\"音乐剧\",\"桑巴\",\"玩牌\",\"交际舞\",\"舞台剧\",\"弹琴\",\"涂鸦\",\"杂技\",\"踢踏舞\",\"恰恰\",\"歌剧\",\"象棋\",\"电子游戏\",\"小提琴\",\"伦巴\",\"拉丁舞\",\"主题曲\",\"图案\",\"画笔\",\"跳棋\",\"横笛\",\"蒙太奇\",\"三弦\",\"骨牌\",\"唢呐\",\"插画\",\"锣鼓\",\"洋琴\",\"石雕\",\"扑克牌\",\"二胡\",\"皮影戏\",\"民族舞\",\"画布\",\"国际象棋\",\"舞剧\",\"管风琴\",\"圆号\",\"小号\",\"京剧\",\"街舞\",\"二人转\",\"多米诺\",\"管乐队\",\"马戏\",\"沙包\",\"围棋\",\"合成器\",\"手鼓\",\"跷跷板\",\"拨浪鼓\",\"印象派\",\"木琴\",\"手风琴\",\"相声\",\"笛子\",\"中提琴\",\"长笛\",\"木偶戏\",\"五子棋\",\"卡祖笛\",\"单簧管\",\"过山车\",\"电子琴\",\"水枪\",\"大鼓\",\"长号\",\"麻将\",\"桥牌\",\"快板\",\"管弦乐队\",\"扬琴\",\"定音鼓\",\"竖琴\",\"贝斯\",\"口琴\",\"木鱼\",\"三角铁\",\"风琴\",\"黑管\",\"班卓琴\",\"钟琴\",\"风笛\",\"琵琶\",\"弹弓\",\"连环画\",\"摩天轮\",\"古筝\",\"画像\",\"雕刻\"]},{\"category\":\"人体\",\"words\":[\"心脏\",\"器官\",\"指甲\",\"基因\",\"拳头\",\"骨头\",\"舌头\",\"肚子\",\"身体\",\"头发\",\"大脑\",\"人体\",\"神经\",\"牙齿\",\"肩膀\",\"耳朵\",\"眼睛\",\"头脑\",\"眼泪\",\"下巴\",\"指头\",\"血液\",\"肌肉\",\"鼻子\",\"嘴唇\",\"手指\",\"脖子\",\"胳膊\",\"皮肤\",\"脸颊\",\"下颚\",\"腰部\",\"眼皮\",\"脑壳\",\"背部\",\"瞳孔\",\"乳房\",\"额头\",\"脚趾\",\"脊椎\",\"胡须\",\"静脉\",\"关节\",\"肝脏\",\"阑尾\",\"血管\",\"喉咙\",\"脸蛋\",\"肾脏\",\"骨骼\",\"脚跟\",\"脚尖\",\"汗水\",\"头顶\",\"躯干\",\"胡子\",\"膝盖\",\"脑袋\",\"辫子\",\"眉毛\",\"手臂\",\"脊柱\",\"嗓子\",\"口腔\",\"胳臂\",\"手腕\",\"脚踝\",\"泪水\",\"面颊\",\"骨架\",\"头骨\",\"脸皮\",\"胸部\",\"大腿\",\"肉眼\",\"毛发\",\"胸腔\",\"胸膛\",\"前额\",\"拇指\",\"肋骨\",\"屁股\",\"相貌\",\"发型\",\"体格\",\"体形\",\"容貌\",\"食指\",\"腹肌\",\"太阳穴\",\"躯体\",\"泪珠\",\"脚后跟\",\"遗体\",\"尸体\",\"臀部\",\"肘部\",\"腹部\",\"腋下\",\"死尸\",\"咽喉\",\"腋窝\",\"雀斑\",\"腮帮子\",\"消化道\",\"臂膀\",\"肉体\"]}]");
//#endregion
//#region src/games/fakeartist/rules.ts
function O(t, n, r) {
	let i = [...r];
	for (let r = i.length - 1; r > 0; --r) {
		let a = e(t, n, r + 1);
		n += 1;
		let o = i[r];
		i[r] = i[a], i[a] = o;
	}
	return {
		out: i,
		cursor: n
	};
}
function k(t, n, r) {
	let i = O(r, 0, n), a = i.cursor, o = D[e(r, a, D.length)];
	a += 1;
	let s = o.words[e(r, a, o.words.length)];
	a += 1;
	let c = i.out[e(r, a, i.out.length)];
	return { state: {
		order: i.out,
		fake: c,
		category: o.category,
		word: s,
		config: t,
		strokes: [],
		votes: {},
		accused: null,
		guess: null,
		guessRight: null,
		phase: "draw"
	} };
}
var A = (e) => e.order.length * e.config.rounds, j = (e) => e.replace(/\s+/g, "").toLowerCase();
function M(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of Object.values(e.votes)) t.set(n, (t.get(n) ?? 0) + 1);
	let n = null, r = 0, i = !1;
	for (let [e, a] of t) a > r ? (n = e, r = a, i = !1) : a === r && (i = !0);
	e.accused = i ? null : n, e.phase = e.accused !== null && e.accused === e.fake ? "guess" : "over";
}
function N(e, t, n) {
	if (t.type === "stroke") {
		if (e.phase !== "draw") return { code: "games.fakeartist.errNotDrawing" };
		if (n.by !== e.order[e.strokes.length % e.order.length]) return { code: "games.fakeartist.errNotYourTurn" };
		let r = structuredClone(e);
		return r.strokes.push({ pts: t.pts }), r.strokes.length >= A(r) && (r.phase = "vote"), { state: r };
	}
	if (t.type === "vote") {
		if (e.phase !== "vote") return { code: "games.fakeartist.errNotVoting" };
		if (!e.order.includes(n.by)) return { code: "games.fakeartist.errNotSeated" };
		if (t.target === n.by) return { code: "games.fakeartist.errSelfVote" };
		if (!e.order.includes(t.target)) return { code: "games.fakeartist.errBadTarget" };
		let r = structuredClone(e);
		return r.votes[n.by] = t.target, Object.keys(r.votes).length === r.order.length && M(r), { state: r };
	}
	if (e.phase !== "guess") return { code: "games.fakeartist.errNotGuessing" };
	if (n.by !== e.fake) return { code: "games.fakeartist.errOnlyFake" };
	let r = structuredClone(e);
	return r.guess = t.text, r.guessRight = j(t.text) === j(r.word), r.phase = "over", { state: r };
}
function P(e, t) {
	let n = e.phase === "guess" || e.phase === "over", r = {
		phase: e.phase,
		category: e.category,
		order: [...e.order],
		rounds: e.config.rounds,
		strokes: structuredClone(e.strokes),
		voted: Object.keys(e.votes),
		votes: n ? { ...e.votes } : null,
		accused: n ? e.accused : null,
		fake: n ? e.fake : null,
		guess: e.guess,
		guessRight: e.guessRight,
		word: e.phase === "over" ? e.word : null
	}, i = t === e.fake;
	return {
		public: r,
		private: {
			isFake: i,
			word: i ? null : e.word
		}
	};
}
function F(e) {
	if (e.phase !== "over") return { phase: e.phase };
	let t = e.accused === null || e.accused !== e.fake || e.guessRight === !0 ? [e.fake] : e.order.filter((t) => t !== e.fake), n = e.order.filter((e) => !t.includes(e));
	return {
		phase: "over",
		winner: t,
		ranking: [...t, ...n]
	};
}
var I = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: _,
	schemas: {
		action: S,
		publicView: T,
		privateView: E,
		config: w
	},
	setup: k,
	reduce: N,
	viewFor: P,
	status: F
};
function L(e, t, n) {
	let r = t.find((t) => t.rid === e[n]);
	return r ? l[r.colorIndex % l.length].hex : "#1c1917";
}
function R({ strokes: e, order: t, members: n }) {
	return /* @__PURE__ */ d(u, { children: e.map((e, r) => /* @__PURE__ */ d(B, {
		pts: e.pts,
		color: L(t, n, t.length > 0 ? r % t.length : 0)
	}, r)) });
}
function z({ strokes: e, order: t, members: n, className: r }) {
	return /* @__PURE__ */ d("svg", {
		viewBox: `0 0 ${v} ${v}`,
		className: r,
		"aria-hidden": !0,
		children: /* @__PURE__ */ d(R, {
			strokes: e,
			order: t,
			members: n
		})
	});
}
function B({ pts: e, color: t }) {
	let n = [];
	for (let t = 0; t + 1 < e.length; t += 2) n.push(`${e[t]},${e[t + 1]}`);
	if (n.length === 1) {
		let [e, r] = n[0].split(",").map(Number);
		return /* @__PURE__ */ d("circle", {
			cx: e,
			cy: r,
			r: 8,
			fill: t
		});
	}
	return /* @__PURE__ */ d("polyline", {
		points: n.join(" "),
		fill: "none",
		stroke: t,
		strokeWidth: 16,
		strokeLinecap: "round",
		strokeLinejoin: "round"
	});
}
//#endregion
//#region src/games/fakeartist/view-player.tsx
function V(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ d(H, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function H({ pub: e, priv: t, members: n, myRid: r, send: l }) {
	let u = a(), p = (e) => n.find((t) => t.rid === e)?.name ?? e, m = e.order.length, h = e.order.map((e) => n.find((t) => t.rid === e)).filter((e) => e !== void 0), g = t?.isFake ?? !1, v = "accent", y = "", b, x;
	if (e.phase === "draw") {
		let n = e.order[e.strokes.length % m];
		y = n === r ? u("games.fakeartist.turnYou") : u("games.fakeartist.turnOther", { name: p(n) }), b = u("games.fakeartist.roundShort", {
			n: Math.floor(e.strokes.length / m) + 1,
			total: e.rounds
		}), x = g ? u("games.fakeartist.myFake") : u("games.fakeartist.myWord", { word: t?.word ?? "" });
	} else if (e.phase === "vote") {
		let t = e.voted.includes(r);
		v = t ? "info" : "accent", y = t ? u("games.fakeartist.voteWaiting", {
			n: e.voted.length,
			total: m
		}) : u("games.fakeartist.votePrompt");
	} else e.phase === "guess" && (v = g ? "warn" : "info", y = g ? u("games.fakeartist.guessPromptYou") : u("games.fakeartist.guessWaiting", { name: p(e.fake ?? "") }));
	return /* @__PURE__ */ f(o, {
		adaptive: !0,
		className: "fakeartist-layout",
		scroll: !1,
		banner: /* @__PURE__ */ d(s, {
			tone: v,
			text: y,
			sub: x,
			chip: b,
			accent: _.accent
		}),
		children: [
			(e.phase === "draw" || e.phase === "guess") && /* @__PURE__ */ f("div", {
				className: "fakeartist-drawing",
				children: [
					/* @__PURE__ */ f("div", {
						className: "fakeartist-roster",
						children: [/* @__PURE__ */ d("div", {
							className: "fakeartist-roster-names",
							children: /* @__PURE__ */ d(c, {
								adaptive: !0,
								scroll: !0,
								variant: "mini",
								members: h,
								myRid: r,
								action: (t) => e.phase === "draw" && t === e.order[e.strokes.length % m] ? "pending" : null
							})
						}), /* @__PURE__ */ d("span", {
							className: "fakeartist-category frame",
							children: u("games.fakeartist.categoryChip", { category: e.category })
						})]
					}),
					/* @__PURE__ */ d("div", {
						className: "fakeartist-drawing-paper",
						children: /* @__PURE__ */ d(i, { children: e.phase === "draw" && e.order[e.strokes.length % m] === r ? /* @__PURE__ */ d(G, {
							strokes: e.strokes,
							order: e.order,
							members: n,
							mySeat: e.strokes.length % m,
							onCommit: (e) => l({
								type: "stroke",
								pts: e
							})
						}) : /* @__PURE__ */ d("div", {
							className: "frame h-full w-full overflow-hidden p-1",
							children: /* @__PURE__ */ d(z, {
								strokes: e.strokes,
								order: e.order,
								members: n,
								className: "h-full w-full rounded-lg bg-white"
							})
						}) })
					}),
					/* @__PURE__ */ d("div", {
						className: "fakeartist-actions-slot",
						children: e.phase === "guess" && g && /* @__PURE__ */ d(K, { onSubmit: (e) => l({
							type: "guess",
							text: e
						}) })
					})
				]
			}),
			e.phase === "vote" && /* @__PURE__ */ d(U, {
				pub: e,
				orderedMembers: h,
				myRid: r,
				members: n,
				send: l
			}),
			e.phase === "over" && /* @__PURE__ */ d("div", {
				className: "fakeartist-drawing",
				children: /* @__PURE__ */ d("div", {
					className: "fakeartist-drawing-paper",
					children: /* @__PURE__ */ d(i, { children: /* @__PURE__ */ d("div", {
						className: "frame h-full w-full overflow-hidden p-1",
						children: /* @__PURE__ */ d(z, {
							strokes: e.strokes,
							order: e.order,
							members: n,
							className: "h-full w-full rounded-lg bg-white"
						})
					}) })
				})
			})
		]
	});
}
function U({ pub: e, orderedMembers: t, myRid: n, members: o, send: s }) {
	let l = a(), [u, p] = r(null);
	return /* @__PURE__ */ f("div", {
		className: "fakeartist-vote",
		children: [/* @__PURE__ */ d("div", {
			className: "fakeartist-vote-paper",
			children: /* @__PURE__ */ d(i, { children: /* @__PURE__ */ d("div", {
				className: "frame h-full w-full overflow-hidden p-1",
				children: /* @__PURE__ */ d(z, {
					strokes: e.strokes,
					order: e.order,
					members: o,
					className: "h-full w-full rounded-lg bg-white"
				})
			}) })
		}), /* @__PURE__ */ f("div", {
			className: "fakeartist-vote-controls",
			children: [/* @__PURE__ */ d("p", {
				className: "fakeartist-vote-hint",
				children: l("games.fakeartist.voteHint")
			}), /* @__PURE__ */ d("div", {
				className: "fakeartist-vote-list",
				children: /* @__PURE__ */ d(c, {
					variant: "plate",
					members: t,
					myRid: n,
					onPick: (e) => {
						e !== n && (p(e), s({
							type: "vote",
							target: e
						}));
					},
					picked: (e) => u === e,
					action: (t) => e.voted.includes(t) ? "done" : null
				})
			})]
		})]
	});
}
var W = 500;
function G({ strokes: e, order: t, members: i, mySeat: a, onCommit: o }) {
	let s = n(null), [c, l] = r(null), u = L(t, i, a), p = (e) => {
		let t = s.current?.getBoundingClientRect();
		if (!t) return [0, 0];
		let n = Math.round((e.clientX - t.left) / t.width * v), r = Math.round((e.clientY - t.top) / t.height * v);
		return [Math.max(0, Math.min(v, n)), Math.max(0, Math.min(v, r))];
	}, m = (e) => {
		if (c) return;
		e.currentTarget.setPointerCapture(e.pointerId);
		let [t, n] = p(e);
		l([t, n]);
	}, h = (e) => {
		if (!c) return;
		let [t, n] = p(e), r = c.length;
		if (r >= W * 2) return;
		let i = t - c[r - 2], a = n - c[r - 1];
		i * i + a * a < 64 || l([
			...c,
			t,
			n
		]);
	}, g = () => {
		c && (o(c), l(null));
	}, _ = [];
	if (c) for (let e = 0; e + 1 < c.length; e += 2) _.push(`${c[e]},${c[e + 1]}`);
	return /* @__PURE__ */ d("div", {
		className: "frame h-full w-full overflow-hidden p-1",
		children: /* @__PURE__ */ f("svg", {
			ref: s,
			viewBox: `0 0 ${v} ${v}`,
			className: "h-full w-full touch-none rounded-lg bg-white",
			onPointerDown: m,
			onPointerMove: h,
			onPointerUp: g,
			onPointerCancel: g,
			children: [/* @__PURE__ */ d(R, {
				strokes: e,
				order: t,
				members: i
			}), c && (_.length === 1 ? /* @__PURE__ */ d("circle", {
				cx: c[0],
				cy: c[1],
				r: 8,
				fill: u
			}) : /* @__PURE__ */ d("polyline", {
				points: _.join(" "),
				fill: "none",
				stroke: u,
				strokeWidth: 16,
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}))]
		})
	});
}
function K({ onSubmit: e }) {
	let t = a(), [n, i] = r(""), o = n.trim();
	return /* @__PURE__ */ f("form", {
		className: "fakeartist-guess-form",
		onSubmit: (t) => {
			t.preventDefault(), o && e(o);
		},
		children: [/* @__PURE__ */ d("input", {
			value: n,
			onChange: (e) => i(e.target.value),
			maxLength: 30,
			placeholder: t("games.fakeartist.guessPlaceholder"),
			"aria-label": t("games.fakeartist.guessPlaceholder"),
			className: "min-h-12 min-w-0 flex-1 rounded-xl border-2 border-ink bg-surface px-3 font-bold"
		}), /* @__PURE__ */ d("button", {
			type: "submit",
			className: "btn-base min-h-12 flex-none cursor-pointer px-6 text-white disabled:opacity-40",
			style: { background: _.accent },
			disabled: !o,
			children: t("games.fakeartist.submit")
		})]
	});
}
//#endregion
//#region src/games/fakeartist/bot.ts
var q = (e, t) => {
	let n = e.public, r = (e) => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
	if (n.phase === "draw") return n.order[n.strokes.length % n.order.length] === t.rid ? { action: {
		type: "stroke",
		pts: J(r)
	} } : null;
	if (n.phase === "vote") {
		if (n.voted.includes(t.rid)) return null;
		let e = n.order.filter((e) => e !== t.rid);
		return { action: {
			type: "vote",
			target: e[r(e.length)]
		} };
	}
	if (n.phase === "guess" && e.private?.isFake) {
		let e = D.find((e) => e.category === n.category) ?? D[0];
		return { action: {
			type: "guess",
			text: e.words[r(e.words.length)]
		} };
	}
	return null;
};
function J(e) {
	let t = 200 + e(600), n = 200 + e(600), r = [t, n], i = 3 + e(4);
	for (let a = 0; a < i; a += 1) t = Math.max(0, Math.min(1e3, t + e(400) - 200)), n = Math.max(0, Math.min(1e3, n + e(400) - 200)), r.push(t, n);
	return r;
}
//#endregion
//#region src/games/fakeartist/game-over.tsx
function Y({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: s }) {
	let c = a(), l = t, u = (e) => n.find((t) => t.rid === e)?.name ?? e, p = (e) => n.find((t) => t.rid === e), h = l.fake !== null && e.winner.length === 1 && e.winner[0] === l.fake, g = r ?? s;
	return /* @__PURE__ */ d(o, {
		adaptive: !0,
		className: "fakeartist-over-layout",
		scroll: !1,
		children: /* @__PURE__ */ f("div", {
			className: "fakeartist-over",
			children: [
				/* @__PURE__ */ d(m, {}),
				/* @__PURE__ */ f("h1", {
					className: "fakeartist-over-title font-display",
					children: [/* @__PURE__ */ d("span", {
						"aria-hidden": !0,
						children: h ? "🕵️" : "🎉"
					}), c(h ? "games.fakeartist.titleFakeWin" : "games.fakeartist.titleArtistsWin")]
				}),
				/* @__PURE__ */ d("div", {
					className: "fakeartist-over-paper",
					children: /* @__PURE__ */ d(i, { children: /* @__PURE__ */ d("div", {
						className: "frame h-full w-full overflow-hidden p-1",
						children: /* @__PURE__ */ d(z, {
							strokes: l.strokes,
							order: l.order,
							members: n,
							className: "h-full w-full rounded-lg bg-white"
						})
					}) })
				}),
				/* @__PURE__ */ f("div", {
					className: "fakeartist-over-info",
					children: [
						/* @__PURE__ */ d("p", {
							className: "fakeartist-over-answer font-display",
							children: c("games.fakeartist.answerLine", {
								category: l.category,
								word: l.word ?? ""
							})
						}),
						/* @__PURE__ */ f("div", {
							className: "fakeartist-over-facts",
							children: [
								l.fake && p(l.fake) && /* @__PURE__ */ f("p", {
									className: "flex items-center justify-center gap-1.5",
									children: [c("games.fakeartist.fakeWas", { name: "" }), /* @__PURE__ */ d(X, {
										rid: l.fake,
										members: n
									})]
								}),
								/* @__PURE__ */ d("p", {
									className: "text-center opacity-80",
									children: l.accused === null ? c("games.fakeartist.escapedLine") : c("games.fakeartist.accusedWas", { name: u(l.accused) })
								}),
								l.guess !== null && /* @__PURE__ */ d("p", {
									className: "text-center opacity-80",
									children: c(l.guessRight ? "games.fakeartist.guessRightLine" : "games.fakeartist.guessWrongLine", { guess: l.guess })
								})
							]
						}),
						g ? /* @__PURE__ */ f("div", {
							className: "fakeartist-over-actions safe-b",
							children: [r && /* @__PURE__ */ d("button", {
								className: "btn-base w-full cursor-pointer text-white",
								style: { background: _.accent },
								onClick: r,
								children: c("session.result.playAgain")
							}), s && /* @__PURE__ */ d("button", {
								className: "btn-quiet w-full cursor-pointer",
								onClick: s,
								children: c("session.result.backToLobby")
							})]
						}) : /* @__PURE__ */ d("p", {
							className: "fakeartist-over-wait safe-b",
							children: c("session.result.waitHost")
						})
					]
				})
			]
		})
	});
}
function X({ rid: e, members: t }) {
	let n = t.find((t) => t.rid === e);
	if (!n) return /* @__PURE__ */ d("span", { children: e });
	let r = l[n.colorIndex % l.length];
	return /* @__PURE__ */ f("span", {
		className: "fakeartist-name-chip",
		children: [/* @__PURE__ */ d("img", {
			src: p[n.avatar % p.length],
			alt: "",
			draggable: !1,
			className: "rounded-full object-contain",
			style: { backgroundColor: r.hex }
		}), n.name]
	});
}
//#endregion
//#region src/games/fakeartist/options.tsx
function Z({ value: e, onChange: t }) {
	let n = a(), r = w.safeParse(e), i = r.success ? r.data : w.parse(void 0);
	return /* @__PURE__ */ d(g, {
		title: n("games.fakeartist.optRounds"),
		columns: 3,
		children: C.map((e) => /* @__PURE__ */ d(h, {
			name: "fakeartist-rounds",
			value: String(e),
			checked: i.rounds === e,
			label: n("games.fakeartist.optRoundN", { n: e }),
			accent: _.accent,
			onChange: () => t({ rounds: e })
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/fakeartist/entry.tsx
var Q = {
	definition: I,
	View: V,
	bot: q,
	OverView: Y,
	Options: Z,
	locales: {
		zh: {
			name: "冒牌艺术家闯纽约",
			desc: "全员共画一幅画,其中一人根本不知道在画什么",
			rules: "目标:艺术家们要找出混在其中的冒牌艺术家;冒牌艺术家要隐藏身份,或在被抓后猜出题目。\n准备:系统抽取一个主题和一个词。主题对所有人公开,词只有艺术家们看得到。\n一名玩家被秘密指定为冒牌艺术家,他只知道主题。\n流程:\n· 所有人按随机顺序轮流在同一张画布上作画,每人使用自己的颜色。\n· 每人每次画一笔,按下到抬笔为一笔。\n· 每人画满指定轮数(默认 2 轮)后,所有人同时暗投一票,指出谁是冒牌艺术家;投齐前可改票。\n· 得票唯一最多的人被指控;平票则无人被指控,冒牌艺术家直接获胜。\n· 被指控者是冒牌艺术家:他获得一次猜词机会。\n· 猜的词与题目完全一致则冒牌艺术家获胜,否则艺术家们获胜。\n· 被指控者不是冒牌艺术家:冒牌艺术家获胜。",
			turnYou: "轮到你,画一笔",
			turnOther: "等 {{name}} 作画",
			roundShort: "第 {{n}}/{{total}} 轮",
			categoryChip: "主题:{{category}}",
			myWord: "你是艺术家,题目是「{{word}}」",
			myFake: "你是冒牌艺术家,只知道主题",
			votePrompt: "谁是冒牌艺术家?",
			voteHint: "点一个名字投票,投齐前可改票",
			voteWaiting: "已投,等其他人 {{n}}/{{total}}…",
			guessPromptYou: "你被抓了!猜出题目就能翻盘",
			guessWaiting: "冒牌艺术家是 {{name}},正在猜题…",
			guessPlaceholder: "写下你猜的词…",
			submit: "提交",
			optRounds: "每人画几轮",
			optRoundN: "{{n}} 轮",
			titleArtistsWin: "艺术家们赢了!",
			titleFakeWin: "冒牌艺术家赢了!",
			answerLine: "主题 {{category}} · 题目「{{word}}」",
			fakeWas: "冒牌艺术家是 {{name}}",
			accusedWas: "被指控的是 {{name}}",
			escapedLine: "投票平票,无人被指控",
			guessRightLine: "他猜了「{{guess}}」,完全一致!",
			guessWrongLine: "他猜了「{{guess}}」,不对",
			errNotDrawing: "现在不是作画阶段",
			errNotYourTurn: "还没轮到你",
			errNotVoting: "现在不是投票阶段",
			errNotSeated: "你不在本局中",
			errSelfVote: "不能投自己",
			errBadTarget: "无效的投票目标",
			errNotGuessing: "现在不是猜词阶段",
			errOnlyFake: "只有冒牌艺术家能猜"
		},
		en: {
			name: "A Fake Artist Goes to NY",
			desc: "Everyone draws one picture together — but one player has no idea what it is",
			rules: "Goal: The artists must identify the fake artist among them; the fake must stay hidden, or guess the word after being caught.\nSetup: The system picks a category and a word. The category is public; only the artists see the word.\nOne player is secretly the fake artist and only knows the category.\nPlay:\n· Players take turns in a random order, each drawing on the shared canvas in their own color.\n· Each turn you draw one stroke, from press to lift.\n· After everyone has drawn the set number of rounds (2 by default), all players secretly vote for who they think the fake is; votes can be changed until everyone has voted.\n· The player with the most votes is accused; on a tie nobody is accused and the fake artist wins.\n· If the accused is the fake artist, they get one chance to guess the word.\n· An exact match wins the game for the fake; otherwise the artists win.\n· If the accused is not the fake artist, the fake artist wins.",
			turnYou: "Your turn — draw one stroke",
			turnOther: "Waiting for {{name}} to draw",
			roundShort: "Round {{n}}/{{total}}",
			categoryChip: "Category: {{category}}",
			myWord: "You are an artist. The word is \"{{word}}\"",
			myFake: "You are the fake artist — you only know the category",
			votePrompt: "Who is the fake artist?",
			voteHint: "Tap a name to vote; you can change it until everyone has voted",
			voteWaiting: "Voted. Waiting for others {{n}}/{{total}}…",
			guessPromptYou: "You were caught! Guess the word to steal the win",
			guessWaiting: "{{name}} is the fake artist and is guessing the word…",
			guessPlaceholder: "Type your guess…",
			submit: "Submit",
			optRounds: "Rounds per player",
			optRoundN: "{{n}}",
			titleArtistsWin: "The artists win!",
			titleFakeWin: "The fake artist wins!",
			answerLine: "Category {{category}} · Word \"{{word}}\"",
			fakeWas: "The fake artist was {{name}}",
			accusedWas: "{{name}} was accused",
			escapedLine: "Vote tied — nobody was accused",
			guessRightLine: "They guessed \"{{guess}}\" — exact match!",
			guessWrongLine: "They guessed \"{{guess}}\" — wrong",
			errNotDrawing: "Not in the drawing phase",
			errNotYourTurn: "Not your turn yet",
			errNotVoting: "Not in the voting phase",
			errNotSeated: "You are not in this game",
			errSelfVote: "You cannot vote for yourself",
			errBadTarget: "Invalid vote target",
			errNotGuessing: "Not in the guessing phase",
			errOnlyFake: "Only the fake artist can guess"
		}
	}
};
//#endregion
export { Q as default };
