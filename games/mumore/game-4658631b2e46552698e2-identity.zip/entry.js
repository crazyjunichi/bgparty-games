import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { useState as n } from "react";
import { useT as r } from "@bgparty/sdk/i18n";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as o } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { Floater as u, FlySprite as d } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as f, OptionSection as p } from "@bgparty/sdk/ui/game-options";
//#region src/games/mumore/data.ts
var m = [
	0,
	1,
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	7,
	8,
	9
], h = [
	0,
	1,
	1,
	1,
	1,
	1,
	2,
	2,
	0,
	0
], g = (e) => Math.floor(e / 12), _ = (e) => m[e % 12], v = (e) => h[_(e)], y = (e) => e.reduce((e, t) => e + v(t), 0), b = {
	kind: "none",
	value: 0
}, x = (e, t) => t.kind === "suit" ? g(e) === t.value : t.kind === "number" && _(e) === t.value, S = (e, t, n) => x(e, t) && x(e, n) ? 3 : x(e, t) ? 2 : +!!x(e, n), C = (e, t, n) => S(e, t, n) ? 5 : g(e);
function w(e, t, n) {
	let r = C(e[0].card, t, n), i = (e) => S(e, t, n) * 100 + (C(e, t, n) === r || S(e, t, n) ? _(e) + 1 : -1);
	return e.reduce((e, t) => i(t.card) > i(e.card) ? t : e).rid;
}
var T = (e, t) => e <= 3 ? 16 + 2 * t : e === 4 ? 28 + 2 * t : e === 5 ? 21 + 3 * t : 16 + 4 * t, E = (e) => e.kind === "none" ? 40 : e.kind === "suit" ? 10 : e.value === 1 || e.value === 7 ? 20 : 30;
function ee(e) {
	let t = e?.mode;
	return t === "don" || t === "roland" ? {
		min: 2,
		max: 2
	} : t === "safaru" ? {
		min: 2,
		max: 4
	} : t === "classic" ? {
		min: 4,
		max: 6
	} : t === "panther" ? {
		min: 3,
		max: 8
	} : {
		min: 3,
		max: 6
	};
}
function D(e) {
	if (e.length < 3 || new Set(e).size !== e.length) return !1;
	let t = e.map(_), n = e.filter((e) => g(e) !== 1), r = e.length - n.length;
	if (new Set(t).size === 1) return e.length <= 5 && r <= 1 && new Set(n.map(g)).size === n.length;
	let i = [...t].sort((e, t) => e - t);
	if (i.some((e, t) => t > 0 && e !== i[t - 1] + 1)) return !1;
	let a = new Set(n.map(g));
	return a.size === 1 ? n.length > e.length / 2 : a.size === n.length && e.length <= 5 && r <= 1;
}
function O(e) {
	let t = e.every((e) => g(e) !== 1), n = e.length;
	if (new Set(e.map(_)).size === 1) {
		let r = n === 3 ? 0 : n === 4 ? t ? 30 : 10 : 50;
		return _(e[0]) === 1 || _(e[0]) === 7 ? r / 2 : r;
	}
	let r = t && new Set(e.map(g)).size === 1;
	return (n === 3 ? r ? 10 : 0 : n === 4 ? r ? 20 : 10 : r ? 40 : 20) + Math.max(0, n - 5) * 10;
}
function te(e, t, n) {
	let r = [];
	function i(a, o, s) {
		o === t && s.length >= n && r.push([...s]);
		for (let n = a; n < e.length; n++) {
			let r = _(e[n]);
			o + r <= t && i(n + 1, o + r, [...s, e[n]]);
		}
	}
	return i(0, 0, []), r;
}
function k(e, t) {
	return [
		...te(t, _(e), 2).map((e) => ({
			kind: 0,
			cards: e
		})),
		...te(t, 17 - _(e), 1).map((e) => ({
			kind: 1,
			cards: e
		})),
		...t.filter((t) => _(t) === _(e)).map((e) => ({
			kind: 2,
			cards: [e]
		}))
	];
}
function ne(e, t, n) {
	let r = k(e, t), i = n.flat();
	if (new Set(i).size !== i.length || i.some((e) => !t.includes(e)) || n.some((e) => !e.length)) return !1;
	if (!n.length) return r.length === 0;
	let a = (e, o) => {
		if (e === n.length) return !(o.has(0) || o.has(1)) || !t.some((e) => _(e) === 0) || i.some((e) => _(e) === 0);
		let s = n[e];
		return r.some((t) => !o.has(t.kind) && t.cards.length === s.length && t.cards.every((e) => s.includes(e)) && a(e + 1, /* @__PURE__ */ new Set([...o, t.kind])));
	};
	return a(0, /* @__PURE__ */ new Set());
}
//#endregion
//#region src/games/mumore/meta.ts
var A = {
	id: "mumore",
	tier: "alpha",
	mechanics: [
		"trick-taking",
		"auction",
		"set-collection",
		"hand-management"
	],
	interactionTags: ["team-based"],
	nameKey: "games.mumore.name",
	descKey: "games.mumore.desc",
	rulesKey: "games.mumore.rules",
	icon: "👑",
	iconImg: "games/mumore.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/13944911683319863340/CB304A3299911E61BBD38D0B933E25309D7943E6/" },
	minPlayers: 2,
	maxPlayers: 8,
	bestPlayers: [4, 5],
	playerRange: ee,
	accent: "#e6c553",
	releasedAt: "2026-11-03T02:41:20+08:00",
	search: {
		py: "duoduoyishanxiudingban",
		init: "ddysxdb"
	},
	hotseat: "cover"
}, j = e.enum([
	"revised",
	"classic",
	"don",
	"roland",
	"wimmuln",
	"rummu",
	"safaru",
	"panther"
]), M = e.object({
	mode: j.catch("revised"),
	hands: e.union([e.literal(3), e.literal(4)]).catch(4)
}).default({
	mode: "revised",
	hands: 4
}), N = e.int().min(0).max(59), P = e.array(N).max(60), F = e.object({
	kind: e.enum([
		"none",
		"suit",
		"number"
	]),
	value: e.int().min(0).max(9)
}), re = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("bid"),
		cards: P
	}),
	e.object({
		type: e.literal("discardKitty"),
		cards: P
	}),
	e.object({
		type: e.literal("trump"),
		trump: F
	}),
	e.object({
		type: e.literal("partner"),
		rid: e.string()
	}),
	e.object({
		type: e.literal("play"),
		card: N
	}),
	e.object({
		type: e.literal("reveal"),
		column: e.int().min(0).max(6)
	}),
	e.object({
		type: e.literal("predict"),
		cards: e.tuple([N, N])
	}),
	e.object({
		type: e.literal("lead"),
		card: N
	}),
	e.object({
		type: e.literal("passCards"),
		cards: P
	}),
	e.object({
		type: e.literal("catch"),
		card: N,
		groups: e.array(P).max(3)
	}),
	e.object({
		type: e.literal("draw"),
		count: e.int().min(0).max(60)
	}),
	e.object({
		type: e.literal("meld"),
		groups: e.array(P).max(20)
	}),
	e.object({
		type: e.literal("extend"),
		group: e.int().min(0).max(60),
		cards: P
	}),
	e.object({
		type: e.literal("trade"),
		group: e.int().min(0).max(60),
		joker: N,
		card: N
	}),
	e.object({
		type: e.literal("discard"),
		card: N
	}),
	e.object({
		type: e.literal("tick"),
		now: e.number()
	})
]), ie = e.enum([
	"bid",
	"kitty",
	"minor",
	"major",
	"partner",
	"reveal",
	"play",
	"trickEnd",
	"predict",
	"lead",
	"pass",
	"fish",
	"draw",
	"takeDiscard",
	"meld",
	"roundEnd",
	"done"
]), ae = e.object({
	rid: e.string(),
	card: N
}), oe = e.object({
	owner: e.string(),
	cards: P
}), se = e.object({
	round: e.int(),
	delta: e.record(e.string(), e.number()),
	points: e.record(e.string(), e.number()),
	bonus: e.record(e.string(), e.number()),
	crown: e.string().nullable(),
	goal: e.number(),
	achieved: e.number(),
	success: e.boolean().nullable()
}), ce = e.object({
	mode: j,
	phase: ie,
	round: e.int(),
	hands: e.int(),
	dealer: e.string(),
	actor: e.string().nullable(),
	players: e.array(e.object({
		rid: e.string(),
		score: e.number(),
		handCount: e.int(),
		display: P,
		columns: e.array(e.object({
			up: P,
			down: e.int()
		})),
		bid: e.int(),
		tricks: e.int(),
		points: e.number(),
		ready: e.boolean(),
		opened: e.boolean(),
		prediction: N.nullable(),
		hiddenPrediction: N.nullable(),
		team: e.string()
	})),
	crown: e.string().nullable(),
	shield: e.string().nullable(),
	partner: e.string().nullable(),
	major: F,
	minor: F,
	goal: e.int(),
	trick: e.array(ae),
	lastWinner: e.string().nullable(),
	side: P,
	wild: P,
	supply: e.int(),
	discard: N.nullable(),
	discardCount: e.int(),
	melds: e.array(oe),
	history: e.array(se),
	leadChoices: P
}), le = e.object({
	hand: P,
	playable: P,
	trumps: e.array(F),
	revealColumns: e.array(e.int()),
	selected: P,
	opening: e.int(),
	bidLimit: e.int()
}), I = (e, t) => Object.fromEntries(e.players.map((e) => [e, t(e)])), L = (e, t) => e.players[(e.players.indexOf(t) + 1) % e.players.length], R = (e, t) => e.bids[t] ?? 0;
function ue(e, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = t(e.seed, e.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var de = () => Array.from({ length: 60 }, (e, t) => t);
function z(e, t) {
	let n = e.players.length, r = e.players.indexOf(t);
	return e.config.mode === "rummu" && (n === 4 || n === 6) || e.config.mode === "safaru" && n === 4 ? e.players[r % (n / 2)] : t;
}
var fe = (e, t) => e.scores[t] < 0 ? 3 : e.scores[t] < (e.players.length % 2 == 0 ? 200 : 100) ? 4 : e.scores[t] < (e.players.length % 2 == 0 ? 400 : 150) ? 5 : 6;
function pe(e, t) {
	return [...e.hands[t] ?? [], ...e.config.mode === "roland" ? (e.columns[t] ?? []).flatMap((e) => e.up) : []];
}
function me(e, t) {
	let n = pe(e, t);
	if (e.phase !== "play" || e.turn !== t) return [];
	if (e.config.mode === "panther" && !e.lastWinner && !e.trick.length) return n.filter((e) => g(e) === 0 && _(e) === 5);
	if (!e.trick.length) return n;
	let r = C(e.trick[0].card, e.major, e.minor), i = n.filter((t) => C(t, e.major, e.minor) === r);
	return i.length ? i : n;
}
function he(e, t) {
	let n = e.config.mode === "roland" ? e.columns[t].flatMap((e) => e.up) : e.displays[t];
	return [
		...e.config.mode === "classic" && e.phase === "minor" ? [] : [b],
		...[...new Set(n.map(g))].map((e) => ({
			kind: "suit",
			value: e
		})),
		...[...new Set(n.map(_))].map((e) => ({
			kind: "number",
			value: e
		}))
	];
}
var ge = (e, t) => S(t, e.major, e.minor) === 3 ? 6 : S(t, e.major, e.minor) === 2 ? 5 : S(t, e.major, e.minor) === 1 ? 4 : g(t), _e = (e, t) => e.columns[t]?.flatMap((e, t) => !e.up.length && e.down.length ? [t] : []) ?? [];
function ve(e) {
	e.phase = "play", e.turn = e.crown ?? e.turn, e.config.mode === "roland" && B(e, e.turn);
}
function B(e, t) {
	let n = e.players.find((t) => _e(e, t).length);
	n ? (e.phase = "reveal", e.turn = n, e.revealResume = t) : (e.phase = "play", e.turn = t);
}
function V(e, t, n) {
	let r = e.hands[t], i = r.indexOf(n);
	if (i >= 0) r.splice(i, 1);
	else for (let r of e.columns[t]) {
		let e = r.up.indexOf(n);
		if (e >= 0) {
			r.up.splice(e, 1);
			break;
		}
	}
	e.displays[t] = e.displays[t].filter((e) => e !== n);
}
var H = (e, t) => new Set(e).size === e.length && e.every((e) => t.includes(e));
function ye(e) {
	let t = e.players.length, n = e.config.mode, r = de();
	(n === "don" || n === "roland" || n === "revised" && t === 3) && (r = r.filter((e) => g(e) !== 4)), n === "wimmuln" && t === 3 && (r = r.filter((e) => g(e) < 3)), n === "panther" && (r = r.filter((e) => t === 3 ? _(e) !== 1 && _(e) !== 2 : t >= 7 ? _(e) !== 2 || g(e) === 1 : !0)), r = ue(e, r), e.hands = I(e, () => []), e.displays = I(e, () => []), e.columns = I(e, () => Array.from({ length: 7 }, () => ({
		up: [],
		down: []
	}))), e.piles = I(e, () => []), e.tricks = I(e, () => 0), e.bids = I(e, () => 0), e.selections = {}, e.predictions = {}, e.crown = null, e.shield = null, e.partner = null, e.major = { ...b }, e.minor = { ...b }, e.passes = 0, e.lastBidder = null, e.bidChanged = !1, e.kitty = [], e.side = [], e.trick = [], e.lastWinner = null, e.goal = 0, e.supply = [], e.wild = [], e.discard = [], e.melds = [], e.opened = [], e.leadChoices = [], e.handWinner = null, e.turn = e.players[e.dealer];
	let i = (n) => {
		for (let i = 0; i < n; i++) for (let n = 0; n < t; n++) e.hands[e.players[(e.dealer + 1 + n) % t]].push(r.shift());
	};
	if (n === "roland") {
		for (let t of e.players) for (let n of [
			0,
			1,
			2,
			3,
			4,
			5
		]) e.columns[t][n].down.push(r.shift());
		for (let t of e.players) for (let n = 0; n < 4; n++) {
			let n = r.shift();
			e.columns[t][g(n)].up.push(n), e.displays[t].push(n);
		}
		i(12), e.kitty = r, e.bids = I(e, () => 4), e.phase = "bid";
	} else if (n === "don") i(15), e.kitty = r.splice(0, 3), e.side = r.splice(0, 6), e.phase = "bid";
	else if (n === "safaru") i(4), e.wild = r.splice(0, 4), e.supply = r, e.turn = L(e, e.turn), e.phase = "fish";
	else if (n === "rummu") i(t === 3 ? 9 : t === 6 ? 7 : 8), e.discard = r.splice(0, 1), e.supply = r, e.turn = L(e, e.turn), e.phase = "draw";
	else if (i(Math.floor(r.length / t)), e.kitty = r, e.phase = n === "panther" ? "pass" : n === "wimmuln" ? "predict" : "bid", n === "wimmuln") {
		let t = e.hands[e.turn], n = t.slice(-2);
		if (_(n[0]) === _(n[1]) || g(n[0]) === g(n[1])) e.leadChoices = n, e.phase = "lead";
		else {
			let r = _(n[0]) < _(n[1]) ? n[0] : n[1], i = n.find((e) => e !== r);
			e.major = {
				kind: "suit",
				value: g(r)
			}, e.trick = [{
				rid: e.turn,
				card: i
			}], t.splice(t.indexOf(i), 1);
		}
	}
}
function be(e, t, n) {
	let r = {
		config: e,
		players: [...t],
		seed: n,
		cursor: 0,
		phase: "bid",
		dealer: 0,
		turn: t[0],
		round: 1,
		hands: {},
		displays: {},
		columns: {},
		scores: Object.fromEntries(t.map((e) => [e, 0])),
		piles: {},
		tricks: {},
		bids: {},
		selections: {},
		predictions: {},
		crown: null,
		shield: null,
		partner: null,
		major: b,
		minor: b,
		passes: 0,
		lastBidder: null,
		bidChanged: !1,
		kitty: [],
		side: [],
		trick: [],
		lastWinner: null,
		goal: 0,
		supply: [],
		wild: [],
		discard: [],
		melds: [],
		opened: [],
		leadChoices: [],
		history: [],
		revealResume: "",
		handWinner: null
	};
	return ye(r), r;
}
function xe(e) {
	e.goal = T(e.players.length, R(e, e.crown));
}
var Se = (e) => g(e) === 1 ? 5 : g(e) === 4 ? -10 : g(e) === 2 && _(e) === 7 ? -50 : 0, Ce = (e, t) => e.piles[t].reduce((t, n) => t + (e.config.mode === "panther" ? Se(n) : v(n)), 0);
//#endregion
//#region src/games/mumore/scoring.ts
function U(e, t = !1) {
	let n = e.config.mode, r = e.players.length, i = I(e, (t) => e.piles[t].reduce((e, t) => e + (n === "panther" ? Se(t) : v(t)), 0)), a = I(e, () => 0), o = 0, s = null;
	if (t) {
		let t = Math.max(...Object.values(e.bids));
		for (let n of e.players) i[n] = 0, e.bids[n] === t && (a[n] = (n === e.lastBidder ? -10 : 5) * t);
	} else if ([
		"revised",
		"classic",
		"don",
		"roland"
	].includes(n)) {
		let t = e.crown, c = [t, ...e.partner ? [e.partner] : []];
		if (o = c.reduce((e, t) => e + i[t], 0) + (n === "don" ? y(e.side) : 0), s = o >= e.goal, n === "roland") {
			for (let t of e.players) i[t] = 0;
			a[s ? t : e.shield] = s ? 10 : 5;
		} else if (n === "classic") {
			if (s) for (let n of c) a[n] = Math.min(100, R(e, t) * 10 + E(e.major) - 10);
			else {
				let n = 0;
				for (; T(r, n + 1) <= o;) n++;
				let i = R(e, t) - n;
				a[t] = -10 * i;
				for (let t of e.players) c.includes(t) || (a[t] = 5 * i);
			}
		} else if (s) for (let n of c) a[n] = R(e, t) * 10 + E(e.major);
		else if (e.shield) for (let t of e.players) c.includes(t) || (a[t] = R(e, e.shield) * 5 + E(e.minor));
	} else if (n === "wimmuln") for (let t of e.players) {
		let [n, r] = e.predictions[t].map(_), i = e.tricks[t];
		a[t] = n === r && i === n ? 25 : i === n || i === r ? (i === Math.min(n, r) ? 5 : 10) * (i === n ? 2 : 1) : 0;
	}
	else if (n === "panther") a[e.lastWinner] = 50;
	else if (n === "rummu") for (let t of e.players) {
		i[t] = e.melds.filter((e) => e.owner === t).reduce((e, t) => e + O(t.cards), 0);
		let n = e.handWinner && e.handWinner !== t && z(e, t) === z(e, e.handWinner);
		a[t] = (t === e.handWinner ? 10 : 0) - (n ? 0 : e.hands[t].reduce((e, t) => e + (g(t) === 1 ? 10 : 5), 0));
	}
	else if (n === "safaru") {
		let t = [...new Set(e.players.map((t) => z(e, t)))], n = new Map(t.map((t) => [t, e.players.filter((n) => z(e, n) === t).flatMap((t) => e.piles[t])]));
		for (let t of e.players) i[t] -= e.piles[t].filter((e) => _(e) === 0).length * 5;
		for (let [e, r] of [[3, 24], [4, 12]]) {
			let i = Math.max(...t.map((t) => n.get(t).filter((t) => g(t) === e).length)), o = t.filter((t) => n.get(t).filter((t) => g(t) === e).length === i);
			for (let e of o) a[e] += r / o.length;
		}
	}
	let c = I(e, (e) => i[e] + a[e]), l = I(e, (t) => e.players.filter((n) => z(e, n) === z(e, t)).reduce((e, t) => e + c[t], 0));
	for (let t of e.players) e.scores[t] += l[t];
	let u = I(e, (t) => e.players.filter((n) => z(e, n) === z(e, t)).reduce((e, t) => e + i[t], 0)), d = I(e, (t) => e.players.filter((n) => z(e, n) === z(e, t)).reduce((e, t) => e + a[t], 0));
	e.history.push({
		round: e.round,
		delta: l,
		points: u,
		bonus: d,
		crown: e.crown,
		goal: e.goal,
		achieved: o,
		success: s
	}), e.phase = "roundEnd";
}
function we(e) {
	let t = Object.values(e.scores);
	switch (e.config.mode) {
		case "revised":
		case "classic":
		case "don": return e.round >= e.config.hands;
		case "roland": return t.some((e) => e >= 30);
		case "wimmuln": return t.some((e) => e >= 200);
		case "panther": return t.some((e) => e <= -250);
		case "safaru": return t.some((e) => e >= 100);
		case "rummu": return t.some((t) => t >= (e.players.length % 2 == 0 ? 500 : 200));
	}
}
//#endregion
//#region src/games/mumore/rules.ts
var Te = {
	trick: 850,
	score: 2800
}, Ee = () => ({ code: "games.mumore.invalid" }), W = (e) => {
	e.turn = L(e, e.turn);
}, De = (e) => {
	e.phase = e.shield ? "minor" : "major", e.turn = e.shield ?? e.crown;
}, Oe = () => [{ kind: "deal" }];
function ke(e) {
	if (e.config.mode === "roland" && !e.bidChanged || !e.players.some((t) => R(e, t))) {
		ye(e);
		return;
	}
	if (e.config.mode === "classic") {
		let t = e.players.map((t) => R(e, t)), n = Math.max(...t), r = e.players.filter((t) => R(e, t) === n);
		if (r.length > 1) {
			U(e, !0);
			return;
		}
		e.crown = r[0];
		let i = e.players.filter((t) => t !== e.crown && R(e, t) > 0), a = (t, n) => {
			let r = [...e.displays[t]].map(_).sort((e, t) => t - e), i = [...e.displays[n]].map(_).sort((e, t) => t - e);
			if (r.length !== i.length) return i.length - r.length;
			for (let e = 0; e < r.length; e++) if (r[e] !== i[e]) return i[e] - r[e];
			return 0;
		};
		i.sort(a), e.shield = i.length && !(i.length > 1 && a(i[0], i[1]) === 0) ? i[0] : null;
	}
	e.config.mode === "roland" && (e.shield = e.players.find((t) => t !== e.crown)), xe(e), e.kitty.length && (e.players.length === 3 || e.config.mode === "don" || e.config.mode === "roland") ? (e.hands[e.crown].push(...e.kitty), e.phase = "kitty", e.turn = e.crown) : De(e);
}
function Ae(e) {
	if (e.players.some((t) => e.hands[t].length)) {
		do
			W(e);
		while (!e.hands[e.turn].length);
		return;
	}
	if (!e.supply.length) {
		U(e);
		return;
	}
	e.dealer = (e.dealer + 1) % e.players.length;
	for (let t = 0; t < 4; t++) for (let t = 1; t <= e.players.length; t++) {
		let n = e.players[(e.dealer + t) % e.players.length];
		e.supply.length && e.hands[n].push(e.supply.shift());
	}
	e.wild.push(...e.supply.splice(0, 4)), e.turn = e.players[(e.dealer + 1) % e.players.length];
}
function je(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "roundEnd") {
			if (we(e)) e.phase = "done";
			else return e.round++, e.dealer = (e.dealer + 1) % e.players.length, ye(e), Oe();
			return [];
		}
		if (e.phase === "trickEnd") {
			let t = e.lastWinner, n = [...e.trick];
			return e.piles[t].push(...e.trick.map((e) => e.card)), e.tricks[t]++, e.trick = [], e.turn = t, e.players.every((t) => !pe(e, t).length) && e.players.every((t) => e.columns[t].every((e) => !e.down.length)) ? U(e) : e.config.mode === "roland" ? B(e, t) : e.phase = "play", [{
				kind: "gather",
				rid: t,
				data: { plays: n }
			}];
		}
		return null;
	}
	if (!e.players.includes(n) || e.phase === "done" || e.phase === "roundEnd" || e.phase === "trickEnd" || e.phase !== "pass" && e.phase !== "predict" && n !== e.turn) return null;
	if (t.type === "bid" && e.phase === "bid") {
		let r = e.hands[n], i = t.cards;
		if (!H(i, r) || i.some((t) => e.displays[n].includes(t))) return null;
		let a = Math.max(...Object.values(e.bids));
		if (e.config.mode === "classic" && R(e, n) + i.length > a + 1) return null;
		if (!i.length) e.passes++;
		else {
			if (e.bidChanged = !0, e.passes = 0, e.bids[n] += i.length, e.displays[n].push(...i), (e.config.mode !== "classic" || e.bids[n] >= a) && (e.lastBidder = n), e.config.mode === "roland") for (let t of i) r.splice(r.indexOf(t), 1), e.columns[n][g(t)].up.push(t);
			e.crown ? n !== e.crown && R(e, n) > R(e, e.crown) ? (e.shield = e.crown, e.crown = n) : n !== e.crown && (!e.shield || R(e, n) > R(e, e.shield)) && (e.shield = n) : e.crown = n;
		}
		return W(e), e.passes >= e.players.length && ke(e), [{
			kind: "bid",
			rid: n,
			data: { cards: i }
		}];
	}
	if (t.type === "discardKitty" && e.phase === "kitty") {
		if (t.cards.length !== e.kitty.length || !H(t.cards, e.hands[n]) || t.cards.some((t) => e.displays[n].includes(t))) return null;
		for (let r of t.cards) V(e, n, r);
		return e.piles[n].push(...t.cards), e.kitty = [], De(e), [{
			kind: "discardPrivate",
			rid: n,
			data: { count: t.cards.length },
			for: [n],
			secret: { cards: t.cards }
		}];
	}
	if (t.type === "trump" && (e.phase === "minor" || e.phase === "major")) {
		if (!he(e, n).some((e) => e.kind === t.trump.kind && e.value === t.trump.value)) return null;
		if (e.phase === "minor") {
			if (e.minor = t.trump, e.config.mode === "roland" && t.trump.kind === "suit") for (let n of e.players) {
				let r = e.columns[n][t.trump.value], i = e.columns[n][4];
				i.up.push(...r.up), i.down.push(...r.down), r.up = [], r.down = [];
			}
			e.phase = "major", e.turn = e.crown;
		} else {
			if (e.major = t.trump, e.config.mode === "roland") for (let t of e.players) {
				let n = e.columns[t].flatMap((e) => e.up);
				e.columns[t].forEach((e) => {
					e.up = [];
				});
				for (let r of n) e.columns[t][ge(e, r)].up.push(r);
			}
			e.players.length > 3 ? (e.phase = "partner", e.turn = e.crown) : ve(e);
		}
		return [{
			kind: "trump",
			rid: n
		}];
	}
	if (t.type === "partner" && e.phase === "partner") return !e.players.includes(t.rid) || t.rid === e.crown || t.rid === e.shield ? null : (e.partner = t.rid, ve(e), [{
		kind: "partner",
		rid: t.rid
	}]);
	if (t.type === "reveal" && e.phase === "reveal") {
		if (!_e(e, n).includes(t.column)) return null;
		let r = e.columns[n][t.column].down.pop();
		return e.columns[n][ge(e, r)].up.push(r), B(e, e.revealResume), [{
			kind: "reveal",
			rid: n,
			data: { card: r }
		}];
	}
	if (t.type === "lead" && e.phase === "lead") return e.leadChoices.includes(t.card) ? (e.trick = [{
		rid: n,
		card: t.card
	}], V(e, n, t.card), e.leadChoices = [], e.phase = "predict", [{
		kind: "play",
		rid: n,
		data: { card: t.card }
	}]) : null;
	if (t.type === "predict" && e.phase === "predict" || t.type === "passCards" && e.phase === "pass") {
		if (n in e.selections || !H(t.cards, e.hands[n]) || t.cards.length !== (e.phase === "predict" || e.players.length === 6 ? 2 : 3)) return null;
		if (e.selections[n] = [...t.cards], Object.keys(e.selections).length === e.players.length) {
			let t = e.phase === "predict";
			for (let t of e.players) for (let n of e.selections[t]) V(e, t, n);
			if (t) e.predictions = structuredClone(e.selections), e.phase = "play", e.turn = L(e, e.players[e.dealer]);
			else {
				for (let t of e.players) {
					let n = e.players[(e.players.indexOf(t) - 1 + e.players.length) % e.players.length];
					e.hands[n].push(...e.selections[t]);
				}
				e.turn = e.players.find((t) => e.hands[t].some((e) => g(e) === 0 && _(e) === 5)), e.phase = "play";
			}
			return e.players.map((n, r) => {
				if (t) return {
					kind: "prediction",
					rid: n,
					data: { card: e.selections[n][0] },
					for: [n],
					secret: { card: e.selections[n][1] },
					with: r > 0
				};
				let i = e.players[(r - 1 + e.players.length) % e.players.length];
				return {
					kind: "exchange",
					rid: n,
					data: {
						to: i,
						count: e.selections[n].length
					},
					for: [n, i],
					secret: { cards: e.selections[n] },
					with: r > 0
				};
			});
		}
		return [];
	}
	if (t.type === "play" && e.phase === "play") {
		if (!me(e, n).includes(t.card)) return null;
		let r = e.displays[n].includes(t.card) || e.config.mode === "roland" && !e.hands[n].includes(t.card);
		return V(e, n, t.card), e.trick.push({
			rid: n,
			card: t.card
		}), W(e), e.trick.length === e.players.length && (e.lastWinner = w(e.trick, e.major, e.minor), e.phase = "trickEnd", e.turn = e.lastWinner), [{
			kind: "play",
			rid: n,
			data: {
				card: t.card,
				displayed: r
			}
		}];
	}
	if (t.type === "catch" && e.phase === "fish") {
		if (!e.hands[n].includes(t.card)) return null;
		let r = k(t.card, e.wild), i = t.groups, a = i.flat();
		if (!ne(t.card, e.wild, i)) return null;
		let o = /* @__PURE__ */ new Set();
		for (let e of i) {
			let t = r.find((t) => !o.has(t.kind) && t.cards.length === e.length && t.cards.every((t) => e.includes(t)));
			if (!t) return null;
			o.add(t.kind);
		}
		return V(e, n, t.card), e.wild = e.wild.filter((e) => !a.includes(e)), e.piles[n].push(...a), o.has(2) ? e.piles[n].push(t.card) : e.wild.push(t.card), Ae(e), [{
			kind: "catch",
			rid: n,
			data: {
				card: t.card,
				taken: a,
				paired: o.has(2)
			}
		}];
	}
	if (t.type === "draw" && (e.phase === "draw" || e.phase === "takeDiscard")) {
		if (t.count > e.discard.length) return null;
		if (e.phase === "takeDiscard" && t.count === 0) return e.phase = "meld", [];
		if (t.count === 0) {
			if (!e.supply.length && e.discard.length > 1) {
				let t = e.discard.pop();
				e.supply = ue(e, e.discard), e.discard = [t];
			}
			if (!e.supply.length) return U(e), [];
			e.hands[n].push(e.supply.shift());
		} else e.hands[n].push(...e.discard.splice(e.discard.length - t.count));
		return e.phase = t.count > 0 && e.discard.length ? "takeDiscard" : "meld", [{
			kind: "draw",
			rid: n,
			data: {
				count: t.count || 1,
				source: t.count ? "discard" : "deck"
			}
		}];
	}
	if (t.type === "meld" && e.phase === "meld") {
		let r = t.groups.flat();
		if (!t.groups.length || t.groups.some((e) => !D(e)) || !H(r, e.hands[n]) || r.length >= e.hands[n].length || !e.opened.includes(n) && r.length < fe(e, n)) return null;
		e.opened = [.../* @__PURE__ */ new Set([...e.opened, n])];
		for (let t of r) V(e, n, t);
		return e.melds.push(...t.groups.map((e) => ({
			owner: n,
			cards: e
		}))), [{
			kind: "meld",
			rid: n,
			data: { cards: r }
		}];
	}
	if (t.type === "extend" && e.phase === "meld") {
		let r = e.melds[t.group];
		if (!e.opened.includes(n) || !r || !t.cards.length || !H(t.cards, e.hands[n]) || t.cards.length >= e.hands[n].length || !D([...r.cards, ...t.cards])) return null;
		for (let r of t.cards) V(e, n, r);
		return r.cards.push(...t.cards), [{
			kind: "meld",
			rid: n,
			data: { cards: t.cards }
		}];
	}
	if (t.type === "trade" && e.phase === "meld") {
		let r = e.melds[t.group];
		if (!e.opened.includes(n) || !r || g(t.joker) !== 1 || g(t.card) === 1 || !r.cards.includes(t.joker) || !e.hands[n].includes(t.card) || _(t.card) !== _(t.joker)) return null;
		let i = r.cards.map((e) => e === t.joker ? t.card : e);
		return D(i) ? (V(e, n, t.card), e.hands[n].push(t.joker), r.cards = i, [{
			kind: "trade",
			rid: n,
			data: {
				card: t.card,
				joker: t.joker
			}
		}]) : null;
	}
	return t.type === "discard" && e.phase === "meld" && e.hands[n].includes(t.card) ? (V(e, n, t.card), e.discard.push(t.card), e.hands[n].length ? (W(e), e.phase = "draw") : (e.handWinner = n, U(e)), [{
		kind: "discard",
		rid: n,
		data: { card: t.card }
	}]) : null;
}
var Me = {
	meta: A,
	saveCompatibility: { version: "1" },
	schemas: {
		action: re,
		config: M,
		publicView: ce,
		privateView: le
	},
	setup(e, t, n) {
		return {
			state: be(e, t, n),
			fx: Oe()
		};
	},
	reduce(e, t, { by: n }) {
		let r = structuredClone(e), i = je(r, t, n);
		return i === null ? Ee() : {
			state: r,
			fx: i
		};
	},
	viewFor(e, t) {
		let n = e.hands[t] ?? [], r = e.turn === t, i = (e) => [...e].sort((e, t) => g(e) - g(t) || _(e) - _(t) || e - t);
		return {
			public: {
				mode: e.config.mode,
				phase: e.phase,
				round: e.round,
				hands: e.config.hands,
				dealer: e.players[e.dealer],
				actor: [
					"pass",
					"predict",
					"roundEnd",
					"done"
				].includes(e.phase) ? null : e.turn,
				players: e.players.map((t) => ({
					rid: t,
					score: e.scores[t],
					handCount: e.hands[t].length,
					display: i(e.displays[t]),
					columns: e.columns[t].map((e) => ({
						up: i(e.up),
						down: e.down.length
					})),
					bid: R(e, t),
					tricks: e.tricks[t],
					points: ["roundEnd", "done"].includes(e.phase) ? Ce(e, t) : 0,
					ready: t in e.selections,
					opened: e.opened.includes(t),
					team: z(e, t),
					prediction: e.predictions[t]?.[0] ?? null,
					hiddenPrediction: e.phase === "roundEnd" || e.phase === "done" ? e.predictions[t]?.[1] ?? null : null
				})),
				crown: e.crown,
				shield: e.shield,
				partner: e.partner,
				major: e.major,
				minor: e.minor,
				goal: e.goal,
				trick: e.trick,
				lastWinner: e.lastWinner,
				side: e.side,
				wild: e.wild,
				supply: e.supply.length,
				discard: e.discard.at(-1) ?? null,
				discardCount: e.discard.length,
				melds: e.melds,
				history: e.history,
				leadChoices: e.leadChoices
			},
			private: {
				hand: i(n),
				playable: me(e, t),
				trumps: r && ["minor", "major"].includes(e.phase) ? he(e, t) : [],
				revealColumns: r && e.phase === "reveal" ? _e(e, t) : [],
				selected: e.selections[t] ?? e.predictions[t] ?? [],
				opening: fe(e, t),
				bidLimit: e.config.mode === "classic" ? Math.max(...Object.values(e.bids)) + 1 - R(e, t) : n.filter((n) => !e.displays[t]?.includes(n)).length
			}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((t) => e.scores[t] === n),
			scores: { ...e.scores }
		};
	},
	nextTickIn(e) {
		return e.phase === "trickEnd" ? Te.trick : e.phase === "roundEnd" ? Te.score : null;
	}
}, G = {
	revised: "games.mumore.mode.revised",
	classic: "games.mumore.mode.classic",
	don: "games.mumore.mode.don",
	roland: "games.mumore.mode.roland",
	wimmuln: "games.mumore.mode.wimmuln",
	rummu: "games.mumore.mode.rummu",
	safaru: "games.mumore.mode.safaru",
	panther: "games.mumore.mode.panther"
}, Ne = {
	bid: "games.mumore.phase.bid",
	kitty: "games.mumore.phase.kitty",
	minor: "games.mumore.phase.minor",
	major: "games.mumore.phase.major",
	partner: "games.mumore.phase.partner",
	reveal: "games.mumore.phase.reveal",
	play: "games.mumore.phase.play",
	trickEnd: "games.mumore.phase.trickEnd",
	predict: "games.mumore.phase.predict",
	lead: "games.mumore.phase.lead",
	pass: "games.mumore.phase.pass",
	fish: "games.mumore.phase.fish",
	draw: "games.mumore.phase.draw",
	takeDiscard: "games.mumore.phase.takeDiscard",
	meld: "games.mumore.phase.meld",
	roundEnd: "games.mumore.phase.roundEnd",
	done: "games.mumore.phase.done"
}, Pe = [
	"games.mumore.suit.green",
	"games.mumore.suit.yellow",
	"games.mumore.suit.purple",
	"games.mumore.suit.blue",
	"games.mumore.suit.red"
], Fe = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20120%20474'%3e%3crect%20width='120'%20height='474'%20fill='%23fff9e9'/%3e%3cpath%20fill='%23f5fbf2'%20stroke='%23f5fbf2'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M38,470%2052,471%2053,472%2054,471%2055,473%2057,473%2058,471%2059,473%2063,471%2057,471%2056,470ZM41,443%2047,450%2056,457ZM45,372%2046,373%2042,386%2044,387%2047,377%2047,374ZM26,361%2024,366%2024,369%2030,365%2029,365ZM47,368%2051,373%2052,372%2061,372%2070,376%2087,380%2096,387%2096,389%2099,393%2098,389%2091,382%2091,381%2095,378%2095,375%2089,371%2086,372%2085,371%2084,372%2081,371%2078,368%2077,365%2073,362%2072,360%2075,359%2076,360%2085,361%2089,363%2092,367%2091,368%20100,376%20101,375%20104,375%20113,378%20106,376%2099,372%2090,364%2089,361%2087,360%2079,360%2073,358%2070,358%2066,360%2073,366%2073,373%2070,375%2065,373%2062,373%2051,368ZM14,357%2014,360%2017,369%2019,371%2021,380%2028,396%2030,404%2032,405%2031,406%2032,408%2034,409%2033,411%2034,413%2036,414%2035,415%2037,416%2032,406%2030,399%2027,395%2027,392%2025,389%2022,378%2019,373%2019,370%2015,362ZM53,354%2052,354%2051,356%2050,364%2053,357%2052,356ZM46,358%2044,357%2041,353%2037,359%2037,362ZM53,350%2056,353%2061,352%2059,347%2056,347%2059,348%2058,350ZM103,345%20104,347%20102,348%20103,349%20101,350%2099,358%20103,355%20103,350%20104,349%20103,348%20104,347ZM76,344%2072,342%2073,343%2072,344%2070,343%2069,344%2069,347ZM86,335%2083,335%2083,339%2087,336ZM27,330%2026,330%2026,332%2022,338%2022,340%2016,353%2026,334ZM63,327%2062,327%2058,340%2056,343%2059,342%2059,339ZM103,323%20101,324%2097,330%20102,325%20103,326ZM101,315%20109,327%20112,329%20118,337%20119,337%20105,321ZM82,315%2074,320%2068,322%2064,322%2063,323%2062,322%2061,323%2055,323%2054,322%2046,321%2040,319%2037,316%2036,318%2041,321%2045,321%2049,323%2055,323%2056,324%2059,323%2060,324%2061,323%2066,323%2075,320ZM37,308%2031,319%2030,323%2031,323%2031,321%2036,312ZM67,291%2066,290%2065,291%2065,294%2063,298%2058,301%2051,301%2048,300%2045,297%2045,298%2051,302%2058,302%2061,301%2065,297ZM44,288%2040,300%2043,294ZM80,281%2084,288%2084,290%2096,308%2096,306%2092,302ZM63,281%2061,283%2061,286%2067,281%2073,281%2077,284%2079,287%2080,296%2074,307%2077,304%2080,298%2080,295%2081,294%2079,286%2073,281%2069,281%2068,280%2067,281ZM69,269%2064,269%2058,271%2053,276%2052,278%2052,286%2053,289%2056,292%2057,292%2058,290%2053,284%2053,278%2054,276%2059,271%2061,271%2064,269ZM76,268%2077,270%2079,270%2087,278%2091,287%2091,294%2092,295%2092,288%2088,278%2081,270ZM5,267%205,277%204,278%205,279%206,292%207,293%208,300%2010,302%2010,305%2016,315%2025,325%2031,329%2033,329%2041,333%2049,334%2041,333%2039,331%2037,331%2029,327%2022,321%2015,312%2012,302%2010,300%2010,298%207,292%207,288%205,283ZM53,264%2051,267%2051,270%2048,276%2045,286%2047,279%2052,270ZM33,262%2030,269%2029,281%2028,283%2029,284%2029,288%2034,300%2037,304%2044,309%2053,312%2055,311%2056,312%2065,311%2052,311%2051,310%2048,310%2042,307%2034,298%2031,292%2030,285%2029,284%2029,274%2031,267%2034,263ZM68,260%2075,273%2069,261%2070,260ZM86,258%2085,258%2092,264%2093,267%2097,271%20101,282%20101,286%20102,287%20102,301%20101,302%20101,305%2095,316%2089,322%2075,331%2064,335%2067,335%2078,331%2083,327%2086,326%2087,324%2098,314%20101,306%20101,303%20103,300%20103,284%20100,278%20100,275%2095,266ZM77,255%2074,256%2066,255%2063,257%2056,258%2051,261%2049,261%2039,272%2037,279%2038,280%2039,290%2040,290%2041,288%2039,286%2039,276%2042,269%2048,263%2055,259%2058,259%2062,257%2067,257%2068,256%2077,256%2078,257ZM83,250%2082,251%2082,257%2081,258%2082,259%2080,266%2081,266%2081,263%2082,262ZM56,245%2050,247%2045,250%2041,254%2046,250%2052,248ZM63,244%2076,244%2077,245%2084,246%2091,249%20101,257%2093,250%2084,245ZM32,244%2032,248%2033,249%2035,259%2037,262%2039,262%2039,258%2036,255ZM49,229%2043,234%2048,236ZM50,224%2048,224%2042,228%2031,239%2023,252%2019,264%2019,268%2018,269%2018,287%2020,291%2020,294%2023,303%2027,310%2030,313%2031,313%2031,312%2024,303%2024,300%2021,294%2021,289%2019,283%2019,266%2020,265%2020,261%2025,249%2031,240%2040,231%2049,226ZM22,221%2013,237%2012,243%209,248%2010,248%2012,241%2016,234%2016,232%2022,224ZM25,217%2026,227%2029,237%2028,230%2026,226ZM66,210%2056,219%2056,221%2061,216%2065,215ZM38,208%2036,210%2038,214%2041,217%2042,216%2045,216%2046,219%2047,219%2044,214ZM44,201%2046,204%2054,228%2056,230%2057,235%2061,241%2059,238%2055,226%2051,219%2045,201ZM43,197%2032,207%2031,210%2027,215%2029,214%2032,209%2034,208ZM59,180%2056,180%2055,179%2054,182%2048,190%2051,188%2055,181%2058,181ZM62,178%2068,183%2069,186%2071,187%2071,189%2071,183%2069,181ZM101,172%20101,178%20102,179%20104,195%20106,200%20108,219%20106,195%20103,186%20103,181%20102,180ZM56,171%2053,173%2051,173%2052,177%2053,177ZM66,152%2063,152%2062,164%2056,177%2061,174%2061,171%2062,170%2061,168%2064,165%2066,155%2067,154ZM7,151%2011,163%2013,153%2012,154ZM78,150%2078,167%2077,168%2077,173%2078,163%2079,162ZM99,141%20107,158%20104,149ZM63,139%2059,138%2059,146%2054,152%2049,155%2045,155%2048,156%2052,155%2053,156%2052,157%2053,157%2059,150%2064,149%2065,148%2064,144%2063,145%2062,144ZM73,138%2068,135%2065,135%2062,133%2057,133%2056,132%2049,132%2046,134%2037,136%2032,139%2031,141%2028,142%2021,152%2019,157%2019,161%2020,162%2018,165%2017,170%2023,167%2023,157%2024,154%2028,149%2029,146%2033,143%2036,139%2037,141%2037,140%2042,136%2044,137%2046,134%2051,133%2052,134%2051,136%2053,133%2055,133%2056,134%2055,136%2056,137%2059,135%2060,136%2062,135%2066,136%2068,138%2067,139%2071,142%2073,141%2074,144ZM51,129%2036,132%2028,137%2021,144%2016,154%2016,157%2014,161%2014,168%2013,169%2014,170%2014,179%2012,181%2012,183%2015,192%2024,198%2030,204%2033,202%2030,198%2031,190%2033,188%2038,189%2055,200%2055,197%2053,195%2050,195%2036,187%2029,179%2026,169%2020,172%2018,175%2019,180%2025,186%2025,190%2026,191%2025,192%2027,198%2025,199%2016,188%2016,183%2014,178%2015,159%2017,153%2021,148%2021,146%2027,139%2038,132ZM25,126%2020,141%2021,139%2030,132%2026,129ZM98,125%20100,128%20108,135%20111,140%20118,146%20119,149%20118,146%20114,142%20111,137ZM62,121%2060,121%2056,126%2062,125%2063,124ZM47,118%2042,122%2041,126%2039,128%2049,126%2049,123%2047,120ZM60,112%2059,113%2060,112%2064,112%2069,118%2068,123%2065,127%2068,127%2072,129%2072,127%2070,124%2070,121%2071,120%2073,121%2077,133%2077,142%2076,124%2078,122%2080,125%2082,126%2082,129%2083,127%2085,127%2080,120%2080,119%2083,117%2084,119%2088,122%2084,118%2085,115%2070,110%2065,110%2062,112ZM69,124%2071,126%2069,128%2067,126ZM71,118%2073,117%2074,119%2072,120ZM115,76%20112,77%20111,82%20105,92%20101,94%20107,92%20107,91%20111,88ZM103,64%20103,67%2098,75%2088,81%2081,82%2080,83%2073,83%2071,81%2068,81%2068,83%2071,83%2072,84%2088,83%2089,84%2089,87%2084,94%2080,95%2073,99%2067,99%2067,100%2073,99%2074,102%2086,96%2092,96%2093,95%2096,96%2099,95%2098,94%2097,95%2091,95%2090,92%2098,86%20104,86%20107,83%20109,77%20108,75%20102,70%20103,69ZM48,58%2042,63%2041,66%2040,77%2039,78%2039,86%2038,87%2038,107%2045,116%2049,114%2051,115%2051,121%2052,124%2053,124%2060,117%2063,116%2058,116%2057,118%2055,117%2052,113%2045,109%2044,106%2045,105%2044,105%2043,102%2040,100%2040,97%2039,96%2039,85%2042,83%2039,82%2041,80%2045,80%2047,82%2048,86%2050,86%2056,75%2064,68%2065,69%2064,73%2072,63%2063,65%2057,73%2054,75%2052,68%2052,59%2051,58ZM62,35%2063,38%2061,42%2063,41%2066,42%2064,40ZM115,34%20108,36%20111,40%20113,46%20114,46%20115,43%20115,36%20116,35ZM45,32%2043,37%2043,41%2041,47%2041,53%2039,58%2038,69%2036,74%2035,86%2034,87%2034,130%2035,129%2035,118%2034,117%2034,112%2035,111%2035,88%2036,87%2037,70%2039,65%2039,59%2041,55%2041,48%2043,44%2043,38ZM75,20%2071,20%2070,21%2066,21%2060,23%2062,24%2061,25%2064,22ZM100,18%2095,22%2095,23%20101,27%20101,18ZM80,13%2076,10%2076,12%2071,17%2076,17%2077,16%2081,17ZM60,4%2055,6%2048,7%2034,15%2035,16%2034,15%2040,11%2043,11%2044,12%2043,13%2044,14%2043,17%2039,21%2042,23%2040,24%2039,27%2040,28%2038,29%2036,33%2036,36%2034,39%2030,51%2030,54%2026,64%2027,65%2022,81%2019,103%2023,80%2024,79%2027,64%2029,60%2029,57%2031,54%2031,51%2033,47%2033,43%2037,36%2037,34%2045,18%2047,17%2048,18%2048,22%2050,15%2054,9%2056,10%2056,12%2053,16%2050,25%2059,20%2056,16%2056,10ZM2,0%200,0%200,473%201,473%201,466%203,464%208,464%209,465%2013,465%2014,466%2023,467%2029,469%2035,469%2032,469%2031,468%2030,469%2027,467%2023,467%2022,466%2020,467%2019,465%203,462%201,460%201,442%202,441%204,441%2019,450%2010,444%206,443%203,441%201,438%201,424%202,423%201,422%202,420%201,419%201,413%202,411%201,410%201,403%200,402%200,399%201,398%208,404%2010,409%2029,429%201,396%201,378%202,377%202,346%201,345%201,341%202,340%201,331%202,330%201,329%201,326%202,325%205,326%207,335%209,339%2011,350%2013,353%2013,355%208,334%207,333%207,330%204,323%204,319%201,312%201,306%202,305%201,298%202,296%201,295%201,278%200,277%201,274%200,273%201,272%200,269%201,268%202,258%203,257%201,248%203,246%205,250%205,254%207,258%207,261%209,264%209,267%2011,271%2013,270%2011,263%209,260%207,249%204,243%203,233%201,230%201,165%202,164%207,168%2010,175%209,171%202,161%202,130%201,129%201,124%202,123%202,114%205,104%205,98%207,94%207,90%2010,81%2015,70%2015,66%2018,61%2018,58%2021,54%2021,52%2024,47%2024,44%2034,28%2021,49%2021,52%2017,59%2016,65%2014,67%2014,70%209,82%205,99%203,100%202,99%202,56%204,52%202,51%202,37%2013,27%2025,19%203,34%202,33%202,16%203,15Z'/%3e%3cpath%20fill='%23548f66'%20stroke='%23548f66'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M89,473%2090,473%2089,472%2091,471%2092,473%2094,473%2095,471%2097,472%2098,471%2097,472%2094,470%2093,472%2092,470%2089,471ZM110,445%20111,448%20109,449%20109,450%20111,451%20110,452%20111,451%20112,453%20113,453%20114,451%20115,452%20116,450%20115,451%20114,450%20115,445ZM107,449%20105,449%20104,448%20104,445%20101,442%2099,442%20100,443%2098,444%2099,445%2097,447%20100,449%2096,451%2095,453%2096,454%2092,457%2091,460%2087,458%2088,456%2086,453%2082,452%2081,451%2082,450%2080,451%2080,454%2081,455%2080,459%2085,462%2082,464%2083,463%2086,463%2089,465%2093,460%2095,462%2094,463%2094,466%2095,466%2094,465%2095,464%20101,463%20100,462%20101,460%20104,462%20102,456%20101,456%20100,458%2098,457%2099,454%2098,454%2097,452%2098,451%20100,452%20103,450%20104,451%20105,449%20107,450ZM98,457%2099,458%2096,460%2095,459ZM97,453%2098,454%2097,457%2095,455ZM88,436%2087,435%2080,437%2077,436%2076,437%2078,438%2077,441%2080,442%2078,441%2078,438%2079,437%2081,438%2083,437%2084,438%2082,440%2084,439%2086,440%2087,438%2086,437ZM111,427%20111,430%20113,434%20111,438%20113,439%20116,438%20117,439%20116,437%20117,436%20116,427%20115,426ZM48,416%2049,417%2048,419%2049,420%2048,421%2046,420%2046,421%2050,422%2051,423%2050,424%2056,427%2057,426%2057,421%2056,420%2056,422%2054,423%2053,422%2054,419%2051,416%2049,417ZM48,401%2049,403%2052,405%2049,407%2049,409%2052,410%2052,412%2051,413%2050,412%2055,416%2054,415%2055,414%2057,415%2058,413%2060,414%2059,415%2061,416%2063,415%2066,410%2067,412%2068,411%2069,412%2069,410%2066,410%2065,409%2068,408%2069,406%2071,406%2073,403%2077,406%2077,409%2079,410%2081,409%2082,411%2085,410%2088,411%2091,409%2092,410%2093,408%2094,409%2094,412%2093,413%2094,414%2090,419%2089,417%2088,418%2083,418%2084,419%2083,420%2081,419%2079,420%2077,418%2075,418%2075,419%2072,421%2073,423%2072,424%2078,422%2080,423%2082,421%2083,422%2084,421%2085,423%2087,423%2088,422%2087,421%2095,414%2096,415%2095,414%2097,413%2096,412%2096,409%2097,408%2096,403%2098,400%2097,402%2094,393%2089,386%2086,386%2084,384%2084,382%2083,383%2076,383%2077,384%2075,386%2072,386%2071,387%2070,385%2074,382%2073,382%2068,386%2068,388%2069,386%2072,388%2075,387%2076,389%2078,390%2077,392%2074,391%2075,392%2073,393%2076,392%2077,393%2077,397%2075,398%2073,401%2072,400%2070,401%2069,404%2065,403%2061,406%2060,404%2057,402%2051,404%2050,402ZM75,421%2078,419%2079,420%2078,422ZM56,407%2057,408%2056,411%2055,410ZM66,405%2067,404%2070,404%2071,405%2070,406%2067,406ZM106,379%20111,385%20112,389%20113,389%20115,392%20115,390%20118,388%20118,387%20117,389%20115,388%20116,387%20115,384%20116,383%20118,384%20118,385%20118,384%20115,382%20111,384%20110,382%20108,381%20109,380%20108,381%20107,379ZM30,356%2028,359%2029,360%2028,362%2029,361%2030,362%2033,360%2034,363%2034,360%2033,359%2034,357%2031,359ZM108,331%20109,337%20108,338%20107,337%20107,340%20108,341%20106,342%20107,345%20106,346%20106,354%20103,359%20104,360%20103,361%2099,361%2099,362%2097,363%2096,362%2097,360%2095,356%2095,354%2096,353%2097,354%2096,351%2099,349%20100,344%20101,343%20102,344%2099,340%20100,337%20102,336%20100,335%2094,342%2092,342%2089,347%2087,345%2088,344%2086,346%2087,345%2088,346%2086,350%2083,350%2082,351%2081,350%2082,352%2079,354%2080,353%2082,356%2081,357%2083,355%2085,357%2084,356%2086,354%2088,357%2094,362%2093,363%2096,365%2095,366%2097,367%2096,368%2097,367%2099,369%20101,369%20103,371%20111,375%20110,376%20111,375%20117,376%20118,374%20118,371%20117,370%20118,369%20117,368%20118,367%20118,353%20117,352%20118,351%20117,349%20118,347%20116,341%20117,340%20114,337%20115,335%20116,336%20115,335%20114,336%20111,333%20110,334%20109,331ZM88,355%2089,354%2091,357%2090,358ZM115,249%20116,251%20115,252%20113,250%20114,251%20112,255%20113,256%20113,264%20115,267%20115,269%20114,270%20112,267%20114,270%20113,271%20116,273%20115,275%20117,276%20115,281%20116,283%20117,281%20117,272%20118,271%20119,272%20119,274%20118,271%20118,266%20119,265%20118,264%20119,263%20118,262%20118,258%20119,257%20116,256%20118,255%20119,250%20117,252%20116,249ZM115,252%20117,255%20115,256%20115,262%20114,263%20113,262%20113,253ZM119,240%20119,244%20118,245%20115,240%20115,245%20116,246%20115,247%20116,246%20117,247%20116,246%20119,244ZM95,226%2096,230%2094,231%2094,232%2095,232%2097,235%2099,231%20100,232%20100,235%20103,236%20101,238%20102,242%20101,243%20100,241%20101,244%20105,244%20106,245%20104,246%20105,247%20106,246%20107,248%20106,246%20107,245%20107,241%20107,244%20106,245%20105,244%20105,240%20107,237%20106,236%20107,233%20106,235%20104,232%20106,231%20105,231%20104,229%20102,229%20101,228%20102,227%20101,228%20100,227%2099,229%2096,229ZM79,186%2078,187%2078,191%2079,192%2076,197%2077,199%2076,200%2078,201%2077,204%2079,199%2078,197%2079,196%2077,195%2080,193%2080,190%2078,189%2080,188ZM32,79%2031,79%2031,82%2032,83%2030,87%2031,88%2033,81ZM59,76%2056,77%2058,80%2056,84%2057,82%2060,84%2058,87%2062,82%2061,83%2059,82%2061,80%2063,80%2064,78%2062,80%2060,80%2058,78ZM119,75%20118,75%20119,78%20118,79%20117,78%20117,82%20115,84%20115,86%20113,89%20114,88%20115,90%20113,91%20110,95%20109,94%20108,97%20106,96%20104,97%20103,96%20104,97%20103,98%20101,97%20100,99%2099,98%2097,100%2096,99%2084,100%2075,105%2076,104%2077,106%2074,110%2078,109%2080,110%2081,112%2082,111%2088,114%2087,115%2088,116%2086,118%2087,119%2086,118%2089,115%2096,119%2095,120%2096,119%20104,128%20107,129%20105,130%20107,130%20108,133%20111,132%20109,133%20107,132%20108,131%20106,127%20107,125%20109,127%20111,124%20113,125%20112,124%20113,123%20115,124%20116,123%20117,124%20115,127%20118,125%20117,124%20118,123%20115,124%20114,122%20119,119%20119,112%20118,111%20119,110%20119,98%20118,97%20119,96%20118,95%20119,94%20119,88%20117,86%20117,83%20118,82%20119,83ZM99,118%20100,117%20103,118%20102,119ZM96,110%2098,111%2097,113%2099,114%2098,116%2096,115%2094,116%2093,115ZM25,56%2022,60%2024,62%2021,66%2023,67%2021,68%2022,69%2021,70%2023,69%2023,65%2024,64%2024,61%2022,60%2024,58%2025,59%2026,57ZM38,50%2037,50%2034,54%2033,53%2035,57%2033,59%2032,66%2032,63%2034,60%2035,62%2034,60%2035,59%2034,58%2035,56%2034,55ZM118,48%20116,48%20117,50%20115,51%20116,54%20115,56%20117,57%20117,53%20118,52%20119,53%20118,52%20119,50ZM53,44%2052,45%2052,48%2049,52%2052,51%2055,47%2053,46ZM86,34%2086,35%2088,35%2091,37%2089,34%2090,32ZM77,32%2072,33%2072,34%2073,33%2080,33%2083,35%2082,36%2075,36%2077,37%2075,39%2072,37%2073,36%2071,39%2068,38%2067,39%2065,37%2065,35%2064,37%2066,40%2069,41%2068,42%2070,41%2077,44%2082,44%2086,46%2089,49%2088,52%2086,53%2081,50%2072,50%2075,52%2074,53%2072,52%2073,54%2072,55%2071,54%2068,59%2066,56%2063,55%2064,53%2063,55%2058,51%2059,50%2058,50%2058,53%2059,52%2060,54%2054,56%2054,57%2056,56%2059,58%2058,59%2055,59%2056,62%2054,64%2055,66%2056,65%2056,62%2058,60%2059,62%2059,60%2063,58%2065,60%2061,63%2060,65%2062,63%2063,64%2062,63%2066,60%2067,61%2076,60%2079,63%2078,64%2079,63%2081,64%2082,66%2082,71%2081,72%2079,69%2078,70%2077,68%2073,67%2072,69%2067,73%2069,71%2071,72%2071,73%2069,74%2071,73%2072,76%2067,79%2068,78%2071,78%2073,81%2074,80%2086,79%2093,75%2096,72%2098,73%2097,71%20101,63%20100,62%20100,58%20101,57%2098,48%2093,45%2091,41%2087,38%2083,37%2082,36%2084,34ZM64,57%2066,56%2067,58%2065,59ZM61,54%2063,55%2063,58%2062,59%2060,57ZM45,6%2047,5%2049,6%2048,5%2049,4%2053,4%2058,2%2059,3%2065,1%2067,2%2068,4%2066,6%2065,5%2061,7%2063,8%2063,10%2060,13%2059,12%2060,10%2059,10%2060,13%2059,15%2060,13%2061,15%2063,16%2062,18%2060,17%2061,18%2060,19%2061,18%2063,19%2068,16%2073,11%2072,7%2074,5%2076,5%2083,12%2083,14%2087,18%2089,18%2091,20%2092,19%2094,20%2098,15%2098,12%20100,11%20102,13%20101,16%20105,19%20104,22%20105,23%20104,25%20104,30%20109,33%20111,31%20113,32%20117,29%20119,31%20118,32%20119,34%20118,33%20119,31%20118,30%20118,16%20116,15%20118,14%20119,12%20118,10%20119,9%20119,0%20117,1%20116,0%2055,0%2052,2%2051,4%2048,3%2047,5ZM111,24%20113,23%20114,25%20112,26ZM113,19%20114,20%20111,22%20110,21ZM110,14%20112,13%20113,15%20111,16Z'/%3e%3cpath%20fill='%239ac09e'%20stroke='%239ac09e'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M4,468%205,470%204,472%205,473%206,472%207,473%2010,473%209,472%2010,470%208,469%2011,468%208,468%207,467ZM41,457%2046,460%2047,459%2052,461%2052,460%2051,461%2048,459%2049,456%2048,455%2047,456%2048,457%2047,459%2044,457%2043,455%2042,455ZM5,448%208,449%207,450%208,452%207,453%204,452%205,454%204,455%205,459%206,457%207,458%209,455%2010,456%2012,455%2013,456%2012,457%2013,456%2016,457%2019,462%2020,460%2023,462%2025,461%2027,462%2028,461%2031,463%2029,464%2031,464%2033,466%2036,466%2037,465%2036,466%2034,465%2033,466%2031,462%2028,461%2031,460%2025,457%2029,460%2027,462%2024,459%2023,460%2021,457%2023,456%2020,458%2018,456%2019,455%2018,456%2017,455%2016,456%2013,456%2012,455%2013,453%2015,454%2014,453%2015,452%2018,453%2012,451%2011,449%209,448%208,449%206,446ZM50,426%2049,428%2051,431%2054,431%2055,433%2051,436%2052,438%2051,436%2054,435%2055,433%2057,435%2055,439%2056,438%2057,439%2057,438%2060,436%2060,434%2060,436%2058,437%2057,436%2058,434%2056,433%2058,432%2057,430%2052,429ZM67,418%2068,419%2067,421%2063,420%2062,422%2062,426%2061,427%2064,432%2062,433%2060,431%2062,433%2062,440%2063,441%2061,443%2067,445%2063,440%2064,438%2063,436%2064,435%2072,436%2070,432%2068,432%2066,430%2067,429%2070,430%2067,425%2067,421%2070,420%2069,421ZM42,411%2041,413%2043,416%2044,416%2045,413ZM24,410%2023,413%2027,415%2026,417%2029,422%2028,424%2029,423%2030,425%2033,427%2032,429%2035,431%2035,433%2038,434%2035,429%2034,430%2033,429%2034,426%2031,424%2031,421%2029,419%2028,420%2027,419%2028,417%2026,414%2027,413%2026,413ZM4,408%205,409%204,410%207,412%204,416%205,417%204,419%205,417%207,418%206,419%206,426%207,428%209,429%208,430%2010,428%2013,431%2012,433%2010,432%209,433%207,432%206,433%205,432%204,433%205,435%204,437%206,439%208,438%2012,443%2013,441%2015,442%2014,441%2017,439%2018,440%2018,443%2016,444%2016,445%2018,445%2019,447%2021,447%2022,449%2029,452%2032,451%2034,453%2033,454%2034,453%2035,455%2037,454%2038,456%2039,456%2040,453%2036,451%2032,446%2033,445%2031,446%2029,444%2027,445%2026,444%2027,443%2024,441%2025,439%2026,440%2024,437%2023,437%2024,438%2023,439%2020,439%2018,437%2019,436%2016,432%2018,431%2015,432%2014,431%2015,428%2016,429%2018,428%2017,429%2015,428%2012,429%2011,428%2013,427%2015,424%2016,425%2017,424%2016,425%2015,424%2014,425%2012,424%207,425%206,424%207,422%2014,417%206,410%207,409ZM31,447%2032,448%2031,451%2030,450ZM20,441%2021,440%2024,441%2023,442ZM10,435%2012,434%2013,435%2012,436%2013,435%2015,437%2015,439%2014,440%2010,437ZM5,416%208,414%2011,416%207,418ZM97,381%2097,383%2099,382%20102,384%20100,386%2099,385%20103,393%20102,390%20104,388%20105,389%20104,388%20102,389%20100,387%20102,385%20103,386%20102,383%20100,381ZM42,373%2041,374%2042,375%2041,377%2038,376%2035,379%2039,382%2041,380%2040,378%2042,376%2041,374ZM38,371%2037,373%2036,371%2032,376%2030,376%2029,378%2028,377%2030,379%2032,379%2032,377%2038,373ZM37,365%2038,366%2036,368%2035,367%2032,369%2031,371%2029,369%2030,370%2029,371%2030,374%2032,372%2032,370%2033,369%2034,370%2033,369%2035,367%2036,369%2038,367ZM62,362%2066,365%2065,366%2066,367%2064,370%2062,369%2064,370%2066,369%2069,371%2070,368ZM65,368%2067,366%2069,368%2068,369ZM12,360%209,362%208,361%206,362%207,363%205,365%206,366%205,367%207,368%207,371%204,375%205,373%207,376%205,378%204,377%205,379%208,381%206,385%208,384%209,385%208,388%2012,391%2010,396%2011,398%2010,403%2011,402%2014,402%2015,403%2014,405%2012,404%2012,405%2015,407%2016,406%2017,407%2017,411%2018,411%2019,413%2019,411%2021,408%2022,410%2021,404%2018,402%2020,399%2017,399%2016,398%2017,396%2012,393%2013,392%2016,392%2015,391%2016,389%2015,390%2013,388%2015,386%2014,387%2011,385%2012,382%2011,381%2012,380%2010,379%2012,376%2014,376%2011,374%2012,373%2010,376%207,372%209,369%2010,372%2011,370%2012,371%2013,370%2012,369%2014,367%2011,364%2012,363ZM15,400%2016,399%2019,399%2020,400%2019,401%2016,401ZM14,396%2016,398%2015,400%2012,398ZM9,385%2010,386%209,389%208,388ZM10,381%2011,382%2010,385%209,384ZM7,363%2011,368%2010,370%206,367%206,364ZM89,341%2088,341%2089,342%2087,343%2085,341%2086,340%2085,341%2086,343%2082,345%2081,344%2082,345%2080,347%2081,348%2080,347%2084,345%2085,346%2083,348%2085,346%2084,345%2088,343ZM44,337%2051,339%2052,338%2054,341%2051,343%2054,342%2055,338%2053,339%2052,338ZM4,333%205,336%204,337%205,339%204,340%205,342%204,348%206,349%204,350%204,354%204,352%207,351%207,348%208,347%206,344%207,343%204,341%206,339%204,338%205,337ZM27,338%2028,338%2028,336%2030,335%2031,333%2033,334%2032,335%2035,335%2036,334%2037,335%2036,337%2037,336%2042,337%2042,336%2031,332%2029,333%2029,335ZM33,324%2034,326%2036,326%2043,330%2046,330%2041,329%2040,328%2044,325%2050,326%2039,324%2037,322%2036,323%2034,322%2035,323ZM92,315%2090,315%2088,318%2086,317%2087,314%2085,315%2084,318%2079,322%2080,323%2077,326ZM85,316%2087,318%2083,321%2082,320ZM40,310%2039,311%2040,312%2038,313%2039,313%2040,315%2041,314%2046,317%2044,316%2045,314%2047,313ZM91,308%2088,312%2091,310%2092,313%2095,311%2094,312%2093,309ZM42,303%2047,306%2049,305%2047,305%2046,303%2043,301%2044,302ZM5,301%205,314%206,315%207,322%208,321%207,318%2012,315%2018,322%2017,324%2014,323%2017,324%2018,323%2019,324%2018,326%2022,331%2021,332%2021,335%2019,336%2018,340%2015,345%2013,343%2014,342%2013,342%2015,345%2014,348%2018,341%2019,337%2023,331%2022,330%2023,329%2022,330%2020,329%2022,327%2024,327%2023,327%2013,316%209,308%207,310%205,309%208,305%206,304ZM6,316%207,313%209,315%207,317ZM7,310%209,309%2011,311%209,313ZM117,299%20117,304%20118,305%20116,307%20118,308%20118,311%20118,303%20117,302%20118,299ZM48,286%2047,289%2048,291%2046,292%2047,295%2048,295%2050,291%2052,294%2053,293%2050,291%2051,290%2049,289ZM25,286%2026,287%2024,291%2026,292%2029,296%2027,297%2025,295%2026,297%2028,298%2027,299%2028,303%2028,300%2027,299%2030,298%2028,297%2029,296%2027,293ZM81,276%2087,287%2087,285%2084,279ZM8,273%208,275%2011,275%2014,277%2013,280%2012,278%2015,282%2013,288%2015,286%2015,282%2014,281%2015,280%2014,279%2015,276%2014,274%2015,273%2014,274ZM66,272%2060,274%2057,277%2059,276%2062,278%2058,280%2056,279%2058,283%2057,282%2059,279%2060,280%2066,276%2067,277%2068,274ZM67,275%2065,277%2062,277%2059,275%2063,273%2064,274%2065,272ZM45,270%2045,273%2043,274%2042,280%2044,280%2045,275%2047,273ZM38,267%2037,268%2034,268%2033,271%2033,275%2034,274%2035,275%2035,277%2034,278%2033,277%2032,279%2034,291%2034,288%2035,287%2036,288%2036,290%2036,288%2034,286%2035,283%2034,282%2035,281%2034,279%2035,278%2035,274%2037,271%2036,269ZM66,262%2064,261%2058,262%2054,271%2057,267%2058,268%2066,265%2067,266%2066,265%2067,264%2065,263ZM57,265%2058,263%2059,264%2060,262%2061,263%2060,262%2061,261%2063,261%2065,263%2063,266%2060,267ZM72,260%2075,261%2073,262%2076,266%2075,265%2076,262%2078,261ZM53,250%2051,252%2050,251%2051,252%2048,254%2047,253%2046,255%2042,258%2043,261%2042,264%2040,265%2041,265%2047,258%2049,258%2051,256%2052,257%2054,253ZM30,250%2030,251%2027,252%2022,268%2022,273%2024,272%2023,270%2025,268%2027,270%2027,272%2024,275%2025,274%2026,276%2027,269%2030,260%2032,258%2031,259%2030,258%2030,255%2031,254%2029,252ZM26,263%2028,265%2025,267%2024,265ZM28,260%2029,262%2027,264%2025,262ZM67,247%2067,249%2069,252%2068,251%2070,250%2071,252%2074,252%2075,251%2077,252%2077,251%2076,252%2075,251%2076,249%2075,249%2074,247%2071,248%2069,247%2069,248%2071,249%2070,250%2068,250ZM20,213%2014,213%2016,214%2017,213%2018,215%2020,214%2021,216%2020,218%2018,219%2018,221%2011,234%2011,236%2010,237%209,236%208,238%206,237%208,238%207,240%206,239%208,243%207,241%208,240%209,241%2010,239%209,240%208,238%2011,236%2013,230%2021,217%2021,214ZM101,204%20100,207%20103,207%20104,208%20101,209%20101,210%20103,210%20104,208ZM26,204%2026,210%2027,210%2028,207ZM119,202%20116,203%20114,207%20115,207%20116,204%20118,210%20118,203ZM95,202%2094,204%2095,205%2094,208%2095,210%2093,213%2093,217%2092,218%2093,219%2092,220%2093,219%2092,218%2094,215%2095,217%2095,215%2093,214%2095,213%2094,212%2095,211ZM8,182%208,183%206,184%206,186%207,185%2010,190%208,193%206,190%204,193%204,201%205,202%204,203%204,212%205,213%204,214%205,215%204,220%205,222%204,223%202,222%203,223%202,224%203,223%204,224%205,233%207,235%209,234%208,232%2010,231%209,229%2010,228%209,228%208,226%2010,223%209,220%2010,219%2011,220%2010,217%2012,216%2010,215%2012,214%2011,210%2012,209%2014,211%2018,211%2019,210%2020,211%2019,204%2017,202%2018,199%2016,198%2017,197%2016,198%2013,196%2014,195%2010,192%2011,191%2010,190%2011,188%209,187ZM13,204%2016,208%2015,211%2012,209%2012,205ZM13,204%2016,203%2017,206%2015,207ZM12,195%2013,196%2012,199%2010,197ZM95,181%2095,184%2096,185%2095,186%2095,192%2096,193%2095,192%2098,190%2099,191%2098,190%2099,188%2098,187%2096,189%2095,188%2096,182ZM85,180%2085,182%2084,183%2083,182%2082,184%2083,185%2082,191%2084,193%2080,195%2080,198%2081,197%2082,199%2078,206%2079,208%2078,210%2079,210%2080,212%2079,213%2078,212%2076,213%2075,215%2077,213%2079,215%2077,216%2079,216%2080,218%2081,217%2083,220%2084,215%2081,210%2082,209%2084,210%2083,209%2084,208%2083,205%2085,204%2083,203%2085,201%2083,195%2084,194%2083,191%2085,189%2085,188%2083,187%2083,184%2084,183%2085,185%2084,183ZM68,159%2067,161%2066,160%2068,164%2065,166%2064,168%2065,169%2063,171%2063,174%2064,174%2063,172%2064,170%2066,169%2066,167%2068,164%2067,161%2069,160ZM102,156%20104,158%20103,160%20105,162%20107,169%20107,173%20108,174%20107,175%20108,176%20107,178%20109,179%20111,184%20110,185%20111,186%20111,191%20113,193%20113,200%20113,198%20116,194%20115,195%20114,194%20114,191%20115,190%20114,187%20115,186%20114,187%20113,186%20112,181%20110,178%20112,177%20110,176%20108,172%20109,169%20106,168%20106,164%20105,163%20106,162%20105,160%20103,159%20104,158ZM66,141%2070,147%2069,150%2072,152%2074,151%2075,152%2074,155%2075,156%2075,151%2072,148%2071,150%2070,149%2070,146%2071,145%2072,146%2073,145%2075,148%2074,146%2075,143%2074,146%2069,142%2068,143%2067,141ZM104,139%20109,147%20109,149%20111,151%20111,154%20115,159%20116,164%20118,164%20118,163%20117,164%20115,160%20116,157%20113,156%20114,154%20116,155%20117,153%20116,152%20117,151%20116,152%20115,151%20116,149%20115,150%20112,148%20113,145%20111,148%20109,146%20110,145%20107,143ZM12,138%2011,139%2012,140%2011,143%2013,145%2012,147%2013,150%2013,140ZM55,141%2052,139%2052,137%2051,139%2050,138%2047,138%2045,141%2043,140%2041,143%2038,142%2035,145%2036,146%2039,142%2040,144%2044,141%2049,141%2050,140%2051,141%2053,140ZM46,139%2047,138%2050,138%2051,139%2050,140%2047,140ZM114,135%20119,143%20118,142%20119,135%20116,137ZM118,135%20119,136%20119,139%20118,140%20116,138ZM37,111%2037,115%2038,116%2037,117%2038,118%2038,122%2039,122%2038,121%2041,119%2039,116%2040,115ZM6,111%205,113%207,110%209,110%2010,111%2010,114%2013,116%2013,113%209,110ZM27,106%2025,107%2024,106%2024,107%2021,109%2020,120%2019,121%2020,122%2018,127%2019,126%2021,127%2019,133%2019,131%2022,126%2020,123%2021,122%2019,121%2020,120%2020,116%2023,112%2022,112%2021,110%2022,109%2023,110%2024,108%2025,110%2026,108%2027,109%2029,108%2031,110%2030,111%2030,113%2031,113%2031,110%2029,107ZM43,86%2045,87%2044,88%2045,91%2044,92%2045,94%2044,99%2048,104%2047,105%2051,111%2055,113%2056,112%2054,111%2057,110%2055,110%2053,106%2051,109%2050,107%2049,108%2048,107%2049,105%2051,105%2050,104%2051,103%2045,93%2046,88ZM14,86%2013,86%2012,88%2011,87%2013,91%2012,92%2010,90%2011,93%209,94%2011,96%208,97%2011,103%2013,102%2012,100%2014,99%2012,100%2011,99%2012,97%2011,96%2013,95%2012,94%2013,92%2012,89ZM9,75%208,75%205,84%205,88ZM16,67%2019,72%2016,76%2016,77%2018,77%2019,72%2018,71%2018,68ZM30,66%2029,69%2030,70%2028,72%2030,74%2029,76%2027,77%2029,79%2026,81%2027,82%2026,88%2028,93%2026,94%2027,95%2025,98%2024,97%2024,98%2026,97%2027,98%2025,101%2028,100%2029,101%2028,102%2029,104%2029,93%2030,92%2031,94%2031,91%2030,92%2029,91%2029,80%2031,74%2030,71%2031,70%2032,71%2032,70%2030,69ZM10,50%208,51%207,53%208,54%207,60%206,61%205,60%206,62%206,73%206,68%209,63%207,57%208,56%209,57%208,56%2010,55%2011,53ZM56,37%2046,46%2046,51%2044,53%2045,54%2045,52%2047,50%2049,50%2050,48%2048,45%2051,42%2053,42%2056,38%2058,39ZM21,26%2013,31%2011,34%2010,33%2011,35%209,36%207,39%206,37%205,38%206,39%205,40%207,39%209,40%207,42%208,43%206,44%205,46%2013,36%2014,31%2017,29%2018,30ZM11,35%2012,37%209,39%208,38ZM68,32%2074,30%2079,30%2080,31%2082,30%2083,31%2084,30%2085,31%2088,31%2087,31%2085,28%2084,29%2081,29%2080,28%2081,26%2079,25%2077,26%2076,25%2076,27%2073,31Z'/%3e%3cpath%20fill='%23466048'%20stroke='%23466048'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M111,431%20111,436%20110,437%20109,436%20110,441%20109,442%20108,441%20109,443%20108,447%20106,448%20105,446%20105,448%20107,448%20108,450%20107,451%20105,450%20104,452%20103,451%20100,453%2098,452%2097,454%2095,452%2096,453%2095,454%2096,455%2095,458%2096,459%2098,458%20102,463%2099,465%2095,465%2096,466%2095,467%2093,466%2091,469%2092,469%2093,471%2093,470%2095,469%2097,471%2095,472%2095,473%20116,473%20117,472%20118,473%20115,471%20117,469%20117,466%20118,465%20117,464%20117,459%20118,458%20117,457%20118,454%20117,453%20117,450%20118,449%20119,452%20118,449%20119,448%20118,446%20116,445%20117,444%20116,442%20117,440%20116,439%20113,440%20110,438%20112,434ZM101,455%20103,456%20104,459%20103,462%20100,460%20101,459%20100,457ZM99,453%20100,455%2099,457%2097,458%2096,457%2097,454ZM110,444%20115,444%20116,445%20115,447%20116,448%20115,449%20116,452%20115,453%20114,452%20113,454%20111,453%20112,451%20111,452%20108,450%20108,449%20110,448%20109,447ZM111,443%20113,441%20116,442%20114,444ZM110,442%20111,439%20113,441%20111,443ZM93,422%2092,423%2090,422%2091,421%2088,423%2089,422%2091,423%2087,426%2086,425%2085,426%2081,426%2082,427%2081,428%2079,427%2078,428%2075,428%2074,427%2073,429%2074,430%2081,430%2082,429%2084,430%2084,427%2085,426%2086,427%2087,426%2088,427%2087,426%2088,425%2091,426%2092,425%2090,424ZM3,282%203,296%203,294%205,292%203,289%204,288%203,287%204,286ZM108,273%20108,280%20109,281%20108,282%20109,284%20109,277%20108,276%20109,273ZM4,267%202,268%202,278%203,277%202,276%203,275%203,269ZM111,209%20112,210%20109,211%20110,212%20110,220%20111,222%20110,220%20111,219%20110,216%20112,210ZM74,197%2075,200%2073,201%2074,203%2072,206%2073,207%2071,209%2072,210%2072,213%2074,213%2074,211%2072,209%2073,207%2074,208%2073,207%2075,203%2076,206%2077,205%2076,204%2077,201%2075,200%2076,199%2075,199ZM77,188%2076,188%2076,194%2075,195%2076,196%2076,194%2078,192%2077,191ZM80,167%2079,168%2079,172%2080,173%2078,175%2078,183%2077,184%2078,186%2079,185%2078,181%2080,179%2079,175%2081,174%2080,173ZM70,153%2069,154%2072,156%2070,159%2071,158%2074,160%2073,162%2076,163%2076,162%2074,161%2073,157%2069,154ZM17,138%2017,145%2019,146%2018,145%2019,144%2018,143%2019,140%2018,140ZM90,134%2092,139%2094,141%2094,145%2096,149%2096,152%2098,153%2097,156%20101,166%20101,169%20103,172%20103,177%20105,181%20105,187%20107,191%20107,194%20109,195%20108,196%20108,205%20110,204%20112,207%20113,204%20111,203%20111,198%20108,191%20109,185%20107,183%20107,180%20105,178%20106,176%20105,173%20106,172%20104,169%20104,167%20102,166%20103,164%20102,164%20101,166%20100,165%20101,162%2099,157%20100,154%2096,144%2097,143%2099,144%2098,143%2095,145%2094,144%2094,142%2096,141%2095,140%2096,138%2093,140%2092,139%2092,136%2094,134%2093,135ZM84,128%2083,129%2085,132%2084,133%2086,138%2087,150%2088,151%2089,187%2090,188%2090,198%2091,199%2089,200%2089,217%2088,218%2089,220%2088,223%2088,221%2090,220%2089,219%2089,216%2090,215%2091,218%2091,216%2089,213%2090,212%2091,213%2093,210%2092,209%2093,206%2092,205%2094,200%2093,201%2092,198%2094,194%2093,195%2092,194%2092,190%2093,189%2092,188%2094,185%2093,186%2092,185%2093,182%2090,182%2089,181%2090,180%2089,179%2090,177%2092,176%2091,174%2092,173%2090,174%2089,173%2089,170%2090,169%2089,166%2091,164%2089,160%2091,157%2090,158%2088,156%2089,154%2090,155%2089,153%2090,152%2089,150%2090,147%2089,146%2091,145%2089,142%2089,140%2087,141%2086,140%2085,135%2086,134%2088,135%2085,133%2086,131%2087,132%2084,131%2085,129ZM89,183%2091,182%2092,184%2090,185ZM78,126%2078,129%2079,130%2079,147%2080,148%2080,163%2081,163%2080,160%2082,158%2085,160%2085,158%2081,156%2082,155%2081,152%2083,150%2082,149%2084,144%2082,143%2082,137%2083,136%2080,134%2080,131%2079,130%2080,128%2079,129%2078,128%2079,126ZM82,119%2087,125%2086,126%2087,125%2088,126%2089,132%2091,132%2092,130%2089,128%2090,127%2089,128ZM88,118%2098,135%2098,137%20100,138%20103,145%20106,149%20110,162%20114,169%20117,181%20118,181%20117,179%20119,178%20119,173%20118,172%20119,170%20117,167%20114,165%20111,160%20112,158%20111,156%20108,155%20109,154%20108,153%20108,150%20107,148%20105,147%20105,144%20103,143%20104,141%20102,140%20102,137%2099,133%2097,132%2098,131%2097,130%2099,129%2097,130%2094,128%2096,126%2094,127%2090,122%2091,120%2092,121%2091,120%2090,121ZM11,109%2011,110%2014,112%2015,114%2015,119%2016,119%2016,115%2015,114%2016,112%2015,114ZM48,56%2052,56%2053,57%2054,70%2054,66%2053,65%2054,63%2054,58%2052,56ZM80,46%2081,45%2084,48%2082,50%2087,52%2085,51%2085,49%2086,48%2088,50%2088,49%2086,47%2085,49%2083,47%2084,46%2083,47%2082,45ZM32,35%2030,38%2031,39%2029,42%2027,41%2029,42%2029,44%2024,56%2025,55%2028,56%2027,56%2026,54%2028,51%2029,52%2028,51%2028,48%2029,46%2031,45%2030,43%2031,42%2032,43%2031,42ZM71,35%2072,36%2073,34%2074,35%2082,35%2085,36%2091,40%2093,44%2097,47%2099,47%2098,46%2097,47%2092,42%2093,40%2097,43%2096,42%2097,41%2094,41%2088,36%2085,35%2083,36%2080,34%2077,35%2073,34ZM103,30%20102,31%20105,35%20105,34%20107,33ZM37,22%2034,22%2033,21%2031,23%2032,24%2031,25%2032,24%2033,25%2034,22%2036,23ZM4,19%203,22%203,31%204,32%203,30%204,27ZM77,19%2082,19%2083,20%2088,19%2089,20%2088,21%2090,20%2087,19%2083,15%2082,15%2085,17%2083,20%2082,19ZM119,13%20119,14%20117,15%20119,16%20119,30%20118,31%20117,30%20116,32%20118,36%20117,37%20119,40%20119,37%20117,33%20119,30Z'/%3e%3cpath%20fill='%2377bf6f'%20stroke='%2377bf6f'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M71,391%2074,392%2077,391%2077,390%2076,390%2075,388%2073,388ZM72,389%2074,388%2075,391%2074,392ZM71,337%2062,340%2062,344%2064,346%2062,347%2065,348%2067,342ZM80,334%2074,336%2073,339%2076,341%2078,341ZM53,340%2052,339%2051,340%2050,339%2046,339%2044,338%2043,336%2042,338%2037,337%2036,335%2035,336%2032,336%2031,335%2032,334%2031,334%2030,336%2028,335%2029,338%2026,340%2027,339%2029,340%2026,343%2024,343%2025,345%2023,346%2023,348%2021,349%2022,350%2020,351%2021,353%2020,354%2019,353%2020,356%2018,357%2019,359%2021,360%2018,361%2021,363%2020,365%2026,356%2027,356%2028,358%2030,355%2031,358%2033,357%2039,349%2040,350%2042,349%2043,351%2046,352%2045,353%2046,354%2048,354%2049,351%2046,346%2049,343%2052,342ZM30,337%2031,336%2034,337%2033,338ZM40,326%2041,328%2040,329%2042,328%2043,329%2042,330%2043,329%2046,329%2047,331%2050,331%2051,332%2057,331%2057,328%2056,327%2053,328%2046,326%2043,327ZM79,323%2078,322%2077,324%2075,323%2074,325%2073,324%2069,326%2068,325%2066,328%2066,330%2069,330%2071,328%2072,329%2077,325%2078,326%2077,325ZM98,318%2097,321%2095,323%2094,322%2092,324%2093,325%2090,326%2087,331%2086,330%2085,332%2089,330%2092,331%2091,330%2093,328%2095,329%2094,328%2095,326%2098,324%2099,321%2097,320ZM10,315%208,318%209,321%207,323%209,322%2011,323%208,327%209,327%2010,330%2011,329%2013,332%2011,335%2012,337%2014,338%2012,339%2012,340%2015,342%2014,345%2017,340%2018,336%2020,335%2020,332%2021,331%2020,330%2023,328%2020,330%2019,329%2020,327%2017,322%2012,316%2011,317ZM14,338%2016,337%2017,339%2015,340ZM13,323%2014,322%2017,323%2016,324ZM44,317%2046,316%2047,318%2049,317%2052,317%2053,318%2051,319%2053,318%2055,319%2061,319%2062,316%2060,315%2057,315%2056,316%2051,315%2050,316%2048,313%2047,314%2045,313%2046,315ZM91,311%2086,314%2087,313%2088,314%2086,318%2085,317%2084,319%2083,318%2082,319%2084,320%2088,317%2088,316%2091,314ZM116,303%20116,306%20112,315%20113,316%20111,317%20111,320%20110,321%20117,330%20116,329%20118,328%20117,327%20118,326%20117,323%20118,322%20118,319%20117,318%20118,317%20118,312%20117,311%20117,308%20115,307%20117,305ZM26,298%2029,300%2029,304%2031,306%2032,304%2029,299ZM84,297%2083,297%2082,300%2083,301%2082,302%2082,305%2075,310%2074,312%2073,311%2073,312%2071,313%2070,315%2072,317%2073,317%2074,315%2075,316%2074,315%2075,314%2077,315%2081,310%2082,307%2085,306%2084,304%2086,303%2085,302%2086,300%2084,299ZM48,293%2049,294%2048,296%2050,297%2051,296%2053,298%2054,296%2057,298%2057,297%2060,295%2060,294%2059,294%2060,295%2059,296%2054,296%2052,295%2050,292%2049,294ZM70,286%2066,286%2066,287%2068,287%2070,290%2070,295%2068,297%2068,299%2064,302%2065,304%2063,306%2062,304%2058,306%2053,305%2056,307%2055,308%2056,307%2062,308%2068,304%2068,301%2069,300%2068,299%2070,298%2069,297%2071,295%2070,292%2072,290ZM8,276%209,277%208,278%209,283%2010,282%2011,283%2010,288%2013,293%2012,294%2015,300%2014,301%2016,302%2015,303%2017,305%2018,310%2020,313%2024,314%2021,310%2021,307%2019,304%2019,302%2016,298%2018,297%2016,295%2014,289%2015,287%2013,285%2014,282%2012,280%2013,277ZM66,275%2065,273%2064,275%2063,274%2060,275%2062,276%2065,276ZM67,272%2069,274%2068,277%2070,276%2072,277%2073,276%2072,275%2071,276%2070,274ZM25,269%2023,271%2024,273%2022,274%2022,276%2024,277%2022,279%2023,280%2022,281%2024,285%2023,287%2025,291%2026,291%2024,289%2026,286%2024,284%2024,280%2023,279%2024,277%2026,278%2024,274%2026,272ZM84,265%2085,266%2084,269%2089,273%2088,274%2090,275%2094,283%2094,287%2095,288%2094,290%2096,292%2095,293%2095,300%2097,304%2098,302%2097,301%2099,300%2098,299%2099,298%2098,297%2099,288%2097,285%2098,282%2096,281%2097,279%2096,279%2094,276%2095,274%2093,273%2089,268%2090,267%2089,268ZM64,263%2061,262%2059,265%2057,263%2058,264%2057,266%2058,265%2060,266%2063,265ZM86,253%2086,255%2089,256%20100,268%20101,272%20103,273%20103,277%20105,280%20105,283%20107,284%20106,285%20107,287%20107,284%20106,283%20107,281%20106,280%20107,277%20106,276%20107,275%20106,273%20107,272%20106,273%20105,272%20106,270%20105,271%20104,270%20105,268%20102,266%20103,265%20101,264%20102,263%20101,264%2099,262%20100,261%2099,262%2097,258%2095,256%2094,257%2091,253%2090,254%2089,253%2088,254ZM54,234%2053,235%2052,233%2051,238%2048,241%2047,240%2046,241%2045,239%2043,238%2039,238%2037,240%2036,239%2035,240%2035,245%2037,248%2037,250%2038,251%2039,249%2041,248%2042,249%2045,247%2046,245%2055,242%2056,241%2054,239%2056,238%2054,237%2055,236ZM23,230%2022,231%2021,230%2013,246%2014,249%2013,251%2014,252%2012,254%2013,255%2012,256%2015,263%2016,257%2021,250%2020,249%2025,241%2025,237%2023,233%2024,231ZM93,225%2091,228%2089,229%2088,238%2087,239%2088,241%2087,243%2091,246%2094,247%2095,246%2096,249%2098,250%20107,260%20107,249%20106,248%20107,246%20105,248%20103,246%20106,244%20106,240%20106,244%20105,245%20101,245%20100,244%20101,242%20100,238%20102,236%2099,235%2099,232%2099,234%2097,236%2096,235%2097,233%2096,232%2095,233%2093,232%2096,228%2099,228%20100,226%20103,228%20102,228%20101,226%2096,225%2097,227%2095,229ZM105,248%20107,251%20105,254%20104,253%20104,249ZM93,228%2094,229%2093,231%2091,232%2090,231%2091,229ZM69,223%2069,226%2068,227%2069,228%2067,232%2067,236%2065,239%2066,240%2065,241%2068,241%2069,240%2070,241%2074,240%2075,242%2077,242%2080,240%2081,241%2081,236%2083,233%2082,232%2083,230%2082,228%2083,227%2081,223%2079,223%2075,226%2074,223ZM62,222%2061,224%2058,225%2058,227%2060,230%2062,230%2064,224ZM33,214%2030,219%2029,218%2030,219%2028,220%2030,224%2030,228%2032,231%2034,231%2039,225%2041,226%2042,225%2041,226%2040,225%2040,222%2038,221%2039,220%2036,218%2037,217ZM116,205%20116,207%20114,208%20113,210%20113,218%20114,219%20112,222%20113,229%20116,228%20118,230%20114,232%20113,231%20113,234%20115,232%20116,234%20118,235%20117,236%20113,236%20114,239%20113,240%20113,243%20114,244%20113,245%20116,247%20114,248%20115,251%20114,249%20115,248%20117,249%20117,251%20118,250%20118,246%20116,245%20115,246%20114,245%20114,240%20115,239%20116,241%20118,242%20117,243%20118,244%20118,239%20117,241%20116,240%20116,237%20119,236%20118,235%20119,233%20118,232%20119,224%20117,222%20119,218%20118,217ZM16,204%2013,205%2013,209%2012,211%2010,212%2012,211%2013,212%2013,214%2011,215%2013,216%2011,217%2010,220%2011,223%209,227%2011,228%2010,229%2011,231%209,232%2010,234%208,235%209,239%208,236%209,235%2010,236%2012,230%2013,229%2014,230%2013,228%2017,221%2017,219%2019,218%2020,215%2018,216%2017,214%2016,215%2013,213%2014,212%2020,212%2019,211%2018,212%2014,212%2013,211%2015,210%2014,207%2016,206ZM35,193%2034,194%2034,199%2038,197%2038,195ZM61,184%2060,184%2058,188%2056,189%2057,190%2054,191%2059,199%2058,203%2057,204%2053,202%2054,203%2053,204%2050,203%2049,205%2053,211%2053,214%2054,215%2053,216%2059,212%2065,205%2065,203%2067,201%2066,200%2067,198%2066,196%2066,192%2067,191%2066,189%2067,188%2065,186%2064,187ZM73,164%2070,165%2072,166%2069,168%2070,169%2068,170%2069,171%2067,173%2068,174%2067,177%2069,177%2071,179%2072,179%2074,176%2073,175%2074,174%2073,173%2073,167%2072,166ZM44,158%2041,160%2040,159%2039,160%2040,161%2039,163%2040,168%2039,169%2041,173%2040,175%2042,180%2041,181%2046,185%2048,183%2046,171%2048,169%2051,169%2052,170%2051,169%2054,167%2055,165%2052,161ZM30,159%2030,170%2031,171%2030,174%2033,177%2034,180%2035,179%2034,177%2034,167%2033,166%2034,164%2032,160%2033,158ZM39,151%2040,153%2041,151%2042,152%2043,151%2044,152%2045,151%2049,151%2052,149%2051,145%2050,146%2044,146%2043,145%2042,147%2041,146%2041,147%2039,148ZM8,111%205,114%206,115%206,123%205,124%204,123%206,128%204,131%205,133%204,134%206,138%206,141%205,142%207,145%206,146%209,148%208,149%2011,150%2012,145%2010,143%2011,140%2010,139%2012,137%2011,136%2011,131%2013,129%2011,126%2013,121%2012,120%2013,117%2010,115%2011,114%2010,115%209,114%209,111ZM29,109%2027,110%2026,109%2025,111%2024,109%2023,111%2022,110%2022,111%2024,112%2021,116%2021,120%2020,121%2019,120%2022,122%2021,123%2022,125%2019,127%2019,130%2025,120%2026,121%2027,120%2029,122%2028,123%2029,125%2028,126%2030,128%2031,127%2031,125%2029,122%2031,121%2030,119%2031,118%2030,116%2031,114%2029,113%2030,110ZM70,72%2066,75%2064,80%2060,82%2062,83%2061,85%2058,84%2056,82%2057,80%2056,80%2055,82%2056,82%2057,84%2056,85%2054,84%2055,86%2053,87%2052,90%2050,91%2050,95%2053,100%2052,101%2055,103%2058,108%2059,107%2060,108%2062,107%2063,108%2064,107%2068,107%2068,106%2067,107%2066,104%2064,104%2063,103%2064,102%2062,101%2063,98%2066,95%2072,95%2077,91%2080,92%2083,90%2083,87%2080,89%2079,88%2078,89%2077,88%2068,87%2063,85%2065,79%2067,77%2071,76ZM59,84%2060,86%2058,88%2057,86ZM74,52%2071,51%2067,55%2065,52%2068,47%2060,47%2057,48%2054,53%2055,54%2054,55%2055,54%2059,54%2059,53%2058,54%2057,53%2057,50%2059,49%2060,50%2059,51%2063,54%2061,55%2062,56%2059,59%2056,57%2055,58%2058,58%2060,60%2059,63%2057,60%2055,62%2056,61%2057,62%2057,65%2055,68%2064,60%2062,58%2062,55%2063,54%2067,56%2065,57%2065,58%2066,58%2067,56%2069,59%2068,58%2069,55ZM59,59%2061,57%2063,59%2062,60ZM5,25%207,27%2022,16%2035,10%2037,7%2038,8%2042,5%2043,6%2046,5%2048,2%2051,2%2054,0%205,0%206,1%206,6%205,7%206,10%206,14%205,15%206,16%205,17%206,19%205,20%207,22Z'/%3e%3cpath%20fill='%2321331e'%20stroke='%2321331e'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M79,458%2079,460%2086,466%2090,466%2091,467%2089,470%2083,471%2080,473%2084,473%2086,471%2090,470%2093,465%2093,462%2090,466%2087,466%2083,464%2080,461ZM119,449%20118,450%20118,453%20119,454%20118,455%20119,458%20118,459%20118,464%20119,465%20118,466%20118,469%20117,470%20118,472%20117,473%20119,466%20119,463%20118,462%20119,460%20118,450ZM78,454%2079,451%2081,449%2083,449%2087,452%2089,455%2089,458%2090,458%2094,454%2095,449%2094,453%2091,456%2090,456%2087,451%2084,449%2080,449ZM49,436%2062,455%2070,462%2074,464%2068,460%2058,450%2057,447%2058,446%2062,448%2063,447%2064,448%2078,448%2064,448%2063,447%2056,446ZM18,419%2021,424%2024,426%2026,430%2034,437%2035,440%2046,452%2060,462%2059,463%2056,463%2062,464%2061,462%2058,461%2049,454%2048,452%2038,443%2034,437%2026,430%2024,426ZM92,411%2090,413%2081,412%2077,410%2074,405%2073,407%2074,412%2071,415%2067,417%2061,417%2060,416%2058,417%2059,426%2061,431%2062,431%2060,429%2059,419%2058,418%2059,416%2060,417%2067,417%2072,415%2074,413%2073,410%2074,407%2075,409%2079,412%2090,413%2091,414%2090,416%2078,416%2077,415%2070,421%2070,426%2071,429%2073,428%2070,426%2070,422%2074,417%2076,416%2084,416%2085,417%2090,416%2092,414ZM46,397%2046,398%2048,399%2047,400%2048,403%2048,412%2047,413%2048,412%2056,419%2048,412%2049,411%2048,410%2047,400%2050,399%2051,400%2058,401%2055,401ZM108,392%20109,400%20110,401%20110,410%20109,411%20109,415%20103,427%20100,431%2091,439%2081,443%2073,444%2072,445%2079,443%2083,443%2092,439%2096,436%20103,428%20110,412%20110,399ZM52,387%2055,392%2063,397%2069,397%2074,394%2076,395%2067,402%2060,402%2068,402%2071,399%2074,398%2076,394%2073,394%2072,396%2069,396%2068,397%2063,397%2057,393%2053,389%2053,387ZM119,381%20111,380%20102,376%20102,377%20105,378%20105,380%20108,383%20111,389%20111,391%20112,391%20117,397%20114,392%20111,390%20107,381%20105,379%20107,378%20111,380%20115,380%20119,383%20119,392%20118,393%20119,394%20119,399%20117,402%20113,404%20114,408%20115,408%20116,410%20114,404%20117,402%20119,405%20119,413%20118,414%20117,412%20118,414%20118,425%20117,426%20114,424%20109,423%20104,432%2099,438%2088,445%2086,445%2083,447%2080,447%2084,447%2087,445%2089,445%2096,440%2097,441%2096,447%2096,444%2099,440%20107,447%20108,443%20106,445%20101,440%2098,439%20102,435%20108,426%20110,428%20110,436%20110,427%20109,426%20110,424%20113,424%20117,426%20119,429%20118,430%20118,445%20119,447%20119,442%20118,441%20118,437%20119,436ZM43,371%2038,374%2033,379%2035,380%2034,382%2036,381%2040,387%2045,390%2046,385%2046,387%2044,389%2041,386%2041,383%2040,386%2034,379%2036,376%2042,372%2044,373%2043,374%2043,377%2044,374ZM90,370%2093,371%2097,375%2096,380%2093,382%2099,388%2095,383%2095,381%2098,377%20101,381%20103,382%20107,390%20104,385%20104,383%2092,370ZM74,361%2076,361%2078,363%2079,362%2084,363%2086,365%2083,368%2080,368%2081,369%2087,370%2088,369%2084,369%2083,368%2086,365%2088,365%2089,367%2090,367%2085,363ZM44,367%2045,370%2049,375%2050,374%2056,374%2058,373%2061,375%2067,376%2073,379%2081,380%2087,383%2089,383%2094,388%2099,399%2099,412%2096,417%2088,424%2085,424%2084,425%2072,425%2073,426%2080,426%2086,424%2087,425%2092,422%2096,418%2099,412%2099,398%2094,388%2089,383%2082,380%2078,380%2074,378%2071,378%2058,373%2050,374%2045,368%2046,366%2050,366%2059,370%2071,373%2072,372%2071,366%2064,361%2066,358%2072,356%2076,358%2087,358%2091,361%2092,363%2091,361%2087,358%2077,358%2073,356%2074,355%2070,355%2069,357%2055,363%2061,360%2064,361%2071,367%2071,372%2070,373%2065,371%2062,371%2060,369%2057,369%2049,365%2048,366%2047,365ZM77,345%2072,348%2070,348%2068,350%2067,349%2067,346%2067,349%2065,351%2063,350%2064,351%2058,355%2056,355%2049,347%2051,349%2051,351%2055,354%2054,356%2056,356ZM105,324%20106,325%20102,329%20103,328%20104,329%20104,327%20106,326%20108,328%20107,331%20107,330%20109,329%20119,341%20119,343%20119,340ZM104,322%20102,321%2097,328%2093,332%2091,332%2089,334%2083,332%2081,336%2081,340%2081,336%2083,333%2086,333%2090,335%2085,340%2096,330%20102,321ZM102,314%20100,312%2099,315%2087,327%2081,331%2069,336%2062,337%2061,340%2063,337%2073,335%2075,333%2077,333%2086,328%2093,322%2098,316%20101,318%2099,316%2099,314%20100,313ZM22,303%2025,310%2028,314%2031,316%2029,321%2027,323%2019,315%2026,323%2028,323%2033,327%2041,331%2048,332%2049,333%2056,333%2045,332%2033,327%2031,325%2033,321%2032,324%2030,325%2028,322%2035,309%2035,307%2037,306%2040,308%2037,313%2038,310%2040,308%2041,309%2035,304%2036,305%2033,313%2030,315%2025,310ZM76,271%2077,272%2076,276%2076,274%2079,272%2080,273%2080,277%2077,281%2075,278%2074,279%2079,282%2081,285%2083,292%2089,300%2086,307%2079,315%2074,318%2071,318%2069,320%2068,317%2070,312%2076,308%2078,305%2073,310%2071,310%2068,319%2065,320%2064,317%2071,299%2069,306%2065,309%2060,309%2065,309%2066,308%2067,309%2067,311%2065,313%2060,313%2064,313%2065,314%2064,319%2062,321%2049,320%2064,321%2065,320%2069,320%2075,318%2082,313%2086,308%2087,303%2089,301%2091,303%2090,308%2079,320%2065,325%2050,325%2036,320%2042,323%2045,323%2050,325%2059,325%2060,326%2060,329%2058,332%2058,334%2060,327%2062,325%2066,325%2078,321%2083,317%2084,314%2088,311%2091,306%2092,306%2096,311%2099,304%2098,308%2095,310%2085,295%2081,287%2081,285%2078,281%2080,278%2082,281%2080,278%2080,275%2081,274%2085,278%2087,282%2085,278%2079,272ZM77,246%2062,246%2060,250%2061,248%2063,250%2064,254%2063,255%2060,255%2059,252%2059,254%2055,257%2054,255%2058,243%2051,245%2056,243%2058,244%2056,248%2049,250%2044,253%2041,257%2049,250%2055,248%2056,251%2054,257%2048,260%2043,264%2039,269%2048,260%2056,256%2070,253%2067,252%2067,253%2065,254%2063,251%2063,249%2061,247%2062,246%2064,246%2065,248%2066,246ZM50,233%2050,235%2048,238%2043,235%2040,235%2039,234%2030,244%2024,256%2029,246%2031,248%2031,250%2030,244%2035,238%2040,235%2043,235%2047,238%2046,240%2049,237ZM54,201%2051,200%2046,196%2036,208%2034,209%2028,218%2033,211%2036,213%2034,210%2042,201%2044,204%2043,200%2046,197%2048,197%2051,200ZM72,192%2070,196%2071,197%2071,200%2067,207%2061,213%2055,217%2054,219%2058,216%2068,205%2069,207ZM57,139%2057,146%2050,153%2043,153%2038,156%2039,157%2037,158%2041,157%2040,155%2043,153%2050,153%2054,150%2057,146ZM103,95%2096,98%2093,97%2092,98%2085,98%2080,101%2078,101%2074,104%2069,103%2071,105%2073,105%2075,103%2085,98%2092,98%2093,97%2096,98ZM102,58%20102,63%2099,71%2090,78%2094,76%20101,68ZM31,18%2028,20%2026,20%2021,24%2025,21%2027,22%2017,33ZM42,15%2038,17%2030,24%2021,34%2018,36%209,47%2026,28%2036,20%2037,21Z'/%3e%3cpath%20fill='%23c4dac4'%20stroke='%23c4dac4'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M20,461%2021,463%2031,465%2029,465%2028,463%2025,462%2023,463ZM6,458%206,459%208,460%209,459%2018,462%2016,458%2014,458%2010,455%2011,454%207,459ZM95,443%2085,448%2091,454%2094,449%2093,447%2095,445ZM17,440%2015,441%2016,442%2015,443%2013,442%2013,443%2015,444%2017,443ZM97,437%2088,443%2080,445%2084,445%2094,440ZM46,435%2053,446%2053,448%2056,453%2059,456%2057,458%2054,456%2058,459%2059,458%2064,464%2063,467%2056,464%2058,468%2057,470%2063,470%2064,471%2061,473%2064,473%2065,472%2067,473%2072,473%2073,472%2074,473%2078,473%2076,472%2075,473%2073,472%2067,473%2066,472%2068,470%2078,470%2079,471%2078,470%2079,469%2082,470%2088,468%2083,466%2078,461%2076,454%2078,449%2077,449%2078,450%2077,451%2075,450%2073,451%2072,450%2065,450%2059,448%2068,458%2076,464%2075,466%2073,466%2065,459%2064,460%2057,450%2053,447%2054,446%2051,444%2051,441%2048,439%2049,438%2047,437%2048,436ZM11,435%2011,437%2014,439%2015,436%2014,437ZM108,428%20108,430%20101,438%20101,439%20106,443%20103,440%20106,439%20106,437%20109,433%20108,432ZM24,425%2040,443%2040,442%2037,440%2038,439%2030,432%2031,431%2027,428%2028,427%2027,426%2026,427ZM39,423%2044,432%2046,433%2044,432%2045,430%2044,431%2043,430%2043,427%2041,426%2042,425%2041,423ZM43,422%2045,424%2045,426%2047,428%2048,432%2050,435%2052,436%2051,437%2052,436%2053,437%2053,439%2056,444%2062,446%2066,446%2067,447%2071,446%2063,445%2060,443%2062,441%2061,440%2061,433%2059,431%2059,432%2057,433%2059,434%2057,437%2058,439%2055,440%2054,438%2056,435%2054,432%2051,432%2048,428%2048,426ZM60,433%2061,434%2060,437%2059,436ZM51,435%2053,433%2055,434%2054,436ZM4,421%204,432%205,433%207,431%208,432%2010,431%2013,433%209,428%208,429%206,428ZM80,413%2077,412%2076,413%2075,412%2076,413%2072,417%2067,419%2061,419%2060,418%2061,426%2061,422%2063,419%2065,419%2068,421%2068,425%2069,426%2068,425%2068,421%2076,414%2080,414ZM115,411%20115,415%20112,420%20112,422%20115,423%20114,422%20116,417ZM20,411%2019,414%2022,416%2029,424%2031,428%2032,428%2032,427%2029,425%2025,417%2025,415%2022,413%2023,411ZM31,397%2035,403%2036,408%2039,414%2042,416%2040,413%2042,410%2043,410%2046,414%2046,407%2045,405%2046,404%2047,405%2047,404%2045,403%2046,402%2044,401%2044,397%2045,396%2051,398%2053,397%2054,399%2057,399%2061,401%2065,401%2070,398%2069,399%2063,399%2061,397%2060,398%2059,396%2058,397%2055,393%2055,396%2054,397%2052,395%2051,396%2049,394%2044,393%2043,391%2042,392%2041,391%2042,389%2041,390%2038,386%2036,387%2035,385%2036,388%2034,390%2035,392%2032,394ZM5,368%205,372%206,373%204,376%205,377%204,378%204,386%205,387%205,394%206,395%205,396%208,400%2010,401%209,400%2010,399%209,396%2011,391%206,389%208,385%209,386%209,388%209,386%206,384%207,381%204,379%205,377%206,378%205,377%207,373%205,372%206,371%206,368ZM9,391%2010,393%208,395%207,393ZM46,363%2044,364%2041,363%2037,366%2034,366%2031,368%2031,370%2029,372%2026,371%2024,373%2025,374%2026,382%2027,377%2031,375%2028,373%2032,368%2034,369%2038,365%2039,366%2042,365%2043,366%2042,364%2043,363%2045,365%2044,364ZM27,372%2028,373%2027,376%2025,374ZM8,348%208,351%205,352%205,354%209,353ZM87,344%2082,347%2079,345%2072,350%2067,351%2064,354%2059,357%2058,356%2056,358%2061,357%2073,349%2080,346%2082,348%2081,349ZM102,326%2094,335%2093,334%2086,341%2088,342%2087,341%2088,340%2090,341%2098,333ZM35,288%2035,292%2036,291%2037,292%2036,294%2037,297%2038,294%2035,290ZM115,285%20113,289%20114,291%20113,292%20114,295%20112,301%20113,302%20111,304%20110,310%20106,317%20107,318%20112,308%20111,305%20113,304%20114,301%20113,300%20115,296ZM40,266%2036,266%2035,267%2038,268%2037,270ZM110,242%20110,262%20111,260%20111,256%20110,255%20111,254%20111,243ZM66,214%2065,216%2061,217%2058,220%2059,221%2058,222%2060,220%2059,219%2061,217%2064,218%2066,216ZM114,185%20116,190%20115,191%20115,194%20116,195%20113,202%20117,199%20118,197ZM4,171%204,192%206,189%208,192%209,189%207,188%207,186%206,187%205,186%205,184%207,183%208,181%2010,187%2010,185%209,184%208,177%206,176%207,174%206,172ZM93,158%2093,162%2094,163%2093,166%2095,171%2095,175%2097,179%2095,180%2097,182%2096,188%2098,186%20100,188%20100,189%2096,192%2097,193%2096,194%2097,196%2096,198%2099,199%20101,197%20102,200%20101,201%2096,201%2096,211%2095,212%2096,213%2094,214%2096,215%2096,217%2095,218%2094,216%2092,219%2093,220%2091,221%2090,223%2097,221%2099,223%20102,223%20105,225%20105,222%20104,221%20105,220%20105,217%20103,214%20104,209%2099,207%2099,205%20101,203%20103,206%20103,202%20101,196%20100,186%2098,184%2099,180%2097,179%2098,175%2096,174%2097,171%2095,170%2095,167%2094,166%2095,165%2094,164%2095,162%2093,159%2094,158ZM100,209%20103,208%20104,210%20101,211ZM57,137%2058,140%2059,137%2061,138%2064,137%2063,136ZM102,135%20104,136%20104,138%20106,141%20110,144%20109,145%20110,146%20112,145%20114,147%20113,148%20114,148%20118,153%20116,156%20114,155%20114,156%20117,157%20116,160%20117,162%20119,163%20119,165%20119,154%20116,151%20115,148%20107,141%20107,139ZM45,136%2045,137%2050,137%2051,138%2049,139%2050,139%2052,136%2053,139%2055,140%2055,137%2054,136%2055,134%2053,134%2052,136%2051,134ZM101,127%20102,128%20101,129%20107,135%20108,134%20109,135%20104,130%20103,131%20101,129%20102,128ZM8,98%208,102%207,103%208,104%207,105%208,107%207,108%209,106%2010,107%2012,106%2011,105%2012,104%2010,103ZM43,83%2040,85%2040,96%2041,97%2041,100%2043,101%2044,104%2046,105%2045,106%2046,109%2048,109%2051,112%2046,105%2047,104%2043,99%2044,96%2043,88%2045,86ZM27,81%2025,84%2025,88%2024,89%2025,91%2023,94%2024,95%2023,96%2023,100%2024,101%2022,102%2022,104%2023,102%2027,103%2028,101%2025,100%2026,99%2025,96%2026,95%2027,96%2025,94%2027,93%2025,88ZM23,99%2024,96%2026,98%2024,100ZM60,44%2062,43%2063,44%2064,43%2070,44%2073,46%2072,48%2075,46%2069,44%2065,40%2067,42%2066,43%2063,42ZM46,37%2047,39%2046,42%2047,43%2045,45%2044,52%2045,51%2045,46%2047,45%2055,36%2058,38%2058,36%2056,35%2058,32%2059,32%2061,35%2061,41%2061,39%2063,36%2062,33%2064,31%2065,32%2066,31%2073,30%2075,27%2077,28%2077,27%2076,28%2075,27%2076,24%2077,25%2079,24%2082,26%2081,28%2084,28%2085,27%2087,30%2091,30%2092,33%2093,33%2096,38%2099,40%2099,42%20100,41%20101,42%2099,45%20100,47%20103,45%20106,50%20106,54%20108,55%20107,56%20107,64%20108,65%20106,66%20106,70%20110,71%20110,66%20109,65%20110,64%20109,62%20110,58%20108,57%20108,54%20109,53%20108,54%20107,53%20108,50%20107,51%20106,50%20107,48%20105,47%20106,45%20103,44%20104,42%20102,39%2099,37%20100,36%2097,33%2096,34%2094,32%2095,31%2094,32%2093,30%2089,27%2086,26%2085,27%2080,24%2072,24%2067,27%2063,28%2062,27%2063,26%2062,27%2060,25%2061,24%2059,23%2058,25%2057,24%2058,25%2056,27%2054,26%2055,25%2054,26%2055,27%2052,29%2049,33%2049,36ZM74,21%2082,21%2085,23%2087,22%2085,23%2084,21%2081,21%2080,20ZM43,12%2040,12%2037,14%2036,13%2037,14%2036,15%2034,14%2032,15%2032,16%2033,15%2035,18%2030,21%2031,22%2038,15%2042,13%2043,14%2042,13Z'/%3e%3cpath%20fill='%237a9b82'%20stroke='%237a9b82'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M8,471%2011,473%2013,472%2014,473%2018,473%2021,471%2023,473%2024,472%2025,473%2024,472%2025,471%2028,471%2021,470%2020,472%2019,471%2016,472%2015,471%2017,469%2016,470%2014,469%2013,471%2012,468%209,469%2011,470%2010,472ZM40,455%2041,456%2041,455%2043,454%2044,456%2047,458%2048,456%2049,459%2051,459%2051,457%2048,454%2046,454%2045,452%2043,452ZM13,454%2013,455%2016,455%2017,454%2020,457%2021,456%2023,459%2024,458%2029,463%2030,463%2028,462%2031,461%2033,465%2034,464%2037,466%2036,467%2038,467%2040,465%2043,467%2043,466%2039,463%2038,464%2037,462%2035,463%2033,462%2032,460%2031,461%2027,460%2025,458%2026,457%2025,458%2024,456%2022,457%2019,454%2017,454%2016,453%2017,452%2015,455ZM45,439%2043,441%2047,445%2048,444%2051,449ZM76,421%2078,421%2078,420%2081,418%2083,419%2080,417%2077,417%2079,419ZM8,419%207,420%208,419%2010,421%207,423%207,424%2012,423%2013,424%2011,426%2014,424%2015,426%2013,428%2015,429%2015,431%2016,430%2019,431%2016,433%2017,432%2020,436%2018,438%2019,437%2020,438%2023,438%2022,437%2024,436%2025,438%2027,439%2026,441%2025,440%2025,441%2028,443%2027,444%2029,443%2031,445%2032,444%2034,445%2031,449%2032,447%2033,448%2034,447%2037,451%2039,452%2042,450%2041,447%2042,449%2041,450%2038,449%2039,448%2039,445%2035,442%2034,440%2033,441%2031,440%2033,438%2032,438%2026,431%2022,429%2021,427%2022,426%2021,427%2017,422%2018,421%2014,419%2015,417%2012,420%2010,419%209,420ZM20,430%2021,431%2020,434%2019,433ZM95,415%2092,418%2090,417%2091,419%2087,422%2090,421ZM42,419%2042,421%2043,420%2047,423%2049,426%2050,425%2052,428%2054,429%2057,429%2058,428%2059,430%2058,431%2059,430%2058,422%2058,427%2055,428%2054,427%2055,426%2053,427%2049,424%2050,423%2045,421%2046,419%2047,420%2049,419%2048,420%2047,419%2049,416%2050,417%2049,415%2046,419%2043,420ZM72,406%2068,409%2065,408%2066,409%2069,409%2070,412%2067,413%2066,411%2065,414%2062,416%2064,416%2068,413%2070,414%2072,413%2071,412%2072,409%2071,410%2070,409ZM48,400%2051,402%2051,403%2049,404%2049,406%2053,404%2051,403%2052,402%2055,402ZM104,387%20102,386%20100,388%20101,387%20104,389%20103,390%20104,393%20103,395%20104,394%20105,395%20104,407%20106,407%20108,410%20105,412%20104,411%20105,409%20104,409%20103,412%20106,411%20107,413%20106,414%20103,414%20100,420%2098,419%2099,417%2098,418%2097,417%2098,418%2096,419%2096,420%2097,419%2098,420%2098,423%2093,427%2092,429%2089,429%2090,430%2089,431%2087,430%2086,431%2076,432%2074,433%2073,431%2072,433%2071,431%2069,430%2070,429%2067,430%2071,432%2070,434%2069,433%2070,434%2068,435%2071,433%2073,436%2072,437%2064,436%2065,438%2064,440%2066,443%2069,444%2067,443%2068,442%2071,442%2072,443%2071,445%2072,443%2075,443%2071,440%2074,437%2076,440%2075,441%2076,441%2077,438%2075,437%2077,435%2078,436%2079,435%2081,437%2079,438%2079,441%2078,442%2079,441%2083,441%2081,440%2084,437%2085,439%2086,438%2088,439%2093,436%2095,433%20101,428%2099,425%20100,424%20102,425%20103,424%20100,424%2099,422%20101,420%20104,422%20105,421%20104,419%20106,418%20105,416%20107,415%20108,413%20107,412%20108,411%20107,406%20109,404%20107,403%20107,397%20106,396%20107,394%20103,388ZM89,436%2086,438%2084,437%2082,438%2080,436%2087,434ZM89,434%2090,433%2093,433%2094,435%2091,436ZM80,433%2081,432%2084,432%2085,434%2082,435ZM29,377%2027,380%2029,382%2028,383%2030,383%2029,382%2031,380%2029,379%2030,378ZM49,378%2050,382%2051,381%2053,382%2050,385%2049,384%2049,385%2047,386%2049,391%2051,392%2048,389%2051,387%2050,385%2051,384%2054,384%2055,385%2054,387%2058,389%2058,392%2060,392%2058,391%2057,388%2059,387%2061,389%2060,390%2062,391%2062,394%2064,396%2066,396%2065,395%2066,393%2067,394%2070,393%2071,395%2072,392%2071,392%2070,390%2072,387%2070,390%2069,388%2068,389%2066,383%2067,382%2072,385%2073,384%2071,385%2068,381%2069,380%2072,382%2073,380%2072,381%2071,379%2070,381%2064,379%2063,378%2064,377%2061,379%2060,377%2058,376%2060,375%2058,376%2053,375%2052,377ZM61,390%2064,389%2065,392%2064,393ZM67,388%2070,390%2068,392%2065,390ZM55,384%2056,383%2058,386%2056,387ZM60,381%2061,382%2060,385%2058,383ZM51,379%2053,377%2056,379%2055,380%2052,380ZM13,369%2014,370%2012,372%2011,371%2010,373%209,371%208,372%209,373%208,375%209,374%2010,375%2011,373%2015,376%2012,377%2011,379%2014,380%2012,381%2013,382%2011,386%2013,385%2015,387%2014,388%2017,392%2016,393%2013,393%2018,396%2017,398%2020,398%2022,400%2021,401%2016,400%2014,397%2015,399%2014,400%2015,401%2016,400%2019,400%2021,403%2020,404%2021,403%2023,407%2021,410%2022,408%2026,408%2027,409%2025,410%2026,412%2027,411%2028,412%2026,415%2027,414%2029,417%2028,419%2029,417%2032,421%2032,424%2035,426%2034,429%2035,428%2039,433%2038,435%2036,434%2038,436%2039,435%2041,437%2040,438%2041,437%2043,438%2044,437%2040,434%2041,432%2037,430%2038,426%2036,423%2036,421%2034,418%2033,420%2031,419%2032,418%2032,414%2031,414%2029,411%2026,410%2029,408%2030,409%2026,407%2028,406%2027,405%2028,404%2026,403%2027,402%2026,399%2023,395%2025,392%2024,393%2022,392%2021,390%2022,389%2021,390%2020,389%2021,386%2019,385%2020,384%2017,383%2019,381%2019,380%2018,381%2016,380%2018,376%2013,372%2015,371%2014,370%2016,368ZM35,420%2036,423%2034,424%2033,422ZM23,401%2024,400%2027,402%2024,403ZM56,364%2057,365%2056,367%2057,367%2058,364%2059,365%2059,368%2060,367%2064,369%2063,370%2065,367%2068,368%2067,367%2066,368%2064,366%2066,364%2065,365%2061,362%2058,363%2057,365ZM11,358%2010,358%209,360%207,358%208,357%206,359%206,361%208,360%209,361%208,362%2011,360ZM80,348%2079,349%2078,348%2075,349%2071,354%2077,352%2078,350%2079,351%2078,350%2080,349ZM22,306%2023,307%2022,310%2025,314%2022,316%2020,314%2023,317%2024,316%2025,318%2028,320%2029,318%2027,319%2025,317%2025,314%2026,313%2024,312%2025,311%2023,309%2024,306%2023,307ZM77,207%2076,212%2078,211%2079,212%2079,211%2077,210%2079,207%2078,208ZM82,181%2082,183%2081,184%2080,183%2081,184%2080,185%2081,187%2081,193%2080,194%2081,196%2080,194%2083,193%2081,191ZM69,151%2073,156%2075,157%2073,155%2074,152%2072,153ZM119,120%20116,121%20114,124%20111,125%20110,124%20111,123%20107,126%20109,132%20112,134%20111,136%20110,135%20112,137%20111,136%20113,135%20116,139%20117,138%20118,139%20118,136%20117,135%20119,134%20118,133%20119,131ZM114,136%20115,135%20117,138%20116,139ZM118,122%20119,125%20116,127%20115,126ZM13,103%2013,108%2012,109%2013,109%2015,112%2013,109%2014,108%2013,107%2015,104%2016,106%2016,105ZM32,88%2031,89%2030,88%2030,91%2031,90%2032,91%2032,94%2031,95%2030,93%2030,101%2032,99%2030,98%2030,96%2032,95ZM20,78%2016,78%2016,80%2017,79%2019,80%2015,83%2014,85%2015,86%2014,87%2014,92%2013,93%2014,95%2013,98%2015,99%2013,100%2013,101%2015,102%2017,96%2016,94%2018,90%2017,88%2018,87%2017,86%2017,83%2018,81%2020,80ZM14,89%2015,88%2018,89%2016,91ZM21,61%2021,63%2019,65%2020,66%2018,72%2019,71%2020,72%2019,75%2021,76%2021,72%2022,71%2020,70%2021,69%2020,69%2019,67%2020,66%2022,67%2020,66%2023,62ZM118,53%20118,57%20116,58%20117,59%20117,66%20116,67%20118,65%20118,60%20119,59ZM38,52%2037,52%2036,54%2036,57%2035,58%2036,59%2033,63%2032,60%2030,59%2033,63%2033,66%2032,67%2031,65%2031,69%2032,69%2033,67%2033,64%2036,63%2036,62%2035,63%2034,62%2037,58%2036,57%2038,55%2039,56%2038,55ZM48,51%2046,52%2045,57%2047,55ZM53,43%2051,43%2048,48%2049,46%2050,46%2051,48%2050,49%2051,48%2051,45ZM65,34%2066,37%2067,34%2070,35%2072,32%2077,31%2078,32%2082,32%2085,34%2090,31%2088,32%2085,32%2084,31%2083,32%2082,31%2081,32%2079,31%2074,31%2070,33%2067,32ZM17,30%2015,31%209,38%2011,39%2012,38%2013,39%2011,36%2013,34%2014,35ZM28,28%2026,32%2025,31%2016,41%2016,43%2012,51%2013,54%2012,55%2011,54%2012,55%208,57%2010,63%208,66%209,67%207,68%207,73%206,74%205,73%205,62%205,76%206,77%205,78%206,79%205,80%205,83%207,75%2010,73%209,71%2011,70%2012,67%2011,65%2012,63%2014,62%2013,61%2014,60%2013,58%2014,57%2015,58%2014,57%2016,55%2015,54%2017,53%2016,52%2016,49%2019,45%2020,46%2019,45%2021,42%2023,44%2021,42%2022,37%2024,36%2025,34%2027,37%2026,36%2027,34%2026,33%2028,32%2027,31ZM11,61%2012,62%2011,65%2010,64Z'/%3e%3c/svg%3e", Ie = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20120%20474'%3e%3crect%20width='120'%20height='474'%20fill='%23fff9e9'/%3e%3cpath%20fill='%23fa6b21'%20stroke='%23fa6b21'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M26,468%2024,468%2016,473%2023,473%2026,470ZM98,434%2096,434%2094,442%2091,447%2091,449%2089,451%2090,458%2093,458%2096,456%20102,449%20104,439ZM94,410%2096,424%20104,428%20106,425%2096,411ZM4,393%204,419%203,420%203,445%204,446%203,447%204,448%204,456%203,457%203,463%204,464%204,473%2012,473%2012,469%2015,465%2024,457%2036,449%2035,448%2023,449%2022,447%2026,442%2045,433%2054,427%2060,420%2059,419%2061,416%2056,413%2053,414%2052,412%2050,412%2047,422%2045,424%2040,424%2038,421%2038,413%2037,414%2035,413%2034,416%2031,418%2027,418%2025,416%2024,410%2028,405%2027,403%2028,401%2022,402%2020,411%2017,413%2015,413%2011,410%2011,401%2010,398%206,393ZM37,392%2046,404%2051,404%2059,407%2063,407%2062,392%2056,382%2055,382%2055,386%2052,390%2046,393ZM80,379%2079,383%2083,388%2083,384ZM101,371%20102,378%20105,381%20107,381%20107,375%20106,373%20103,371ZM50,367%2050,370%2053,374%2054,378%2056,379%2055,380%2057,376%2056,372%2058,369%2057,368%2051,368ZM18,368%2015,372%2016,377%2024,383%2025,382%2027,384%2029,384%2030,382%2030,374%2031,373%2028,370%2027,367%2024,366ZM84,361%2083,362%2085,369%2088,372%2091,373%2092,370%2091,369%2091,366ZM50,352%2049,357%2051,359%2055,359%2063,362%2066,362%2074,366%2076,365%2074,357%2071,355%2062,353%2058,351%2051,351ZM99,347%2099,359%20106,364%20108,364%20108,352%20106,350ZM79,340%2081,350%2085,353%2089,353%2089,344%2083,340ZM56,341%2056,343%2058,344%2061,344%2064,346%2071,348%2072,347%2071,339%2069,336%2061,335ZM99,326%20101,330%2099,333%2099,338%20104,341%20109,342%20111,337%20111,331%20105,328%20101,329ZM79,326%2079,330%2089,333%2089,323%2088,322%2087,325%2086,322%2081,324ZM28,313%2025,312%2024,310%2022,310%2019,312%2018,315%2017,314%2017,317%2021,318%2023,316%2024,317%2027,317%2028,316%2027,314ZM109,284%20110,285%20108,287%20108,289%20110,289%20112,291%20112,293%20103,303%20102,306%20102,315%20106,318%20113,321%20115,319%20115,316%20118,307%20118,304%20117,303%20118,302%20118,285%20114,287%20113,285ZM78,238%2078,242%2079,243%2078,244%2078,256%2081,255%2082,252%2084,251%2086,245%2081,239ZM118,232%20113,232%20112,233%20108,233%20107,232%20106,233%20107,234%20106,236%20101,238%20100,237%2097,238%20102,247%2099,250%2094,250%2092,258%2090,261%2093,260%2094,262%2092,263%2091,265%2093,265%2098,262%20105,255%20107,255%20110,260%2096,278%2096,280%20101,279%20107,269%20108,264%20110,261%20112,260%20113,257%20119,249ZM57,183%2058,184%2056,185%2058,189%2058,203%2063,204%2067,207%2071,207%2072,206%2075,207%2076,206%2074,205%2073,206%2068,205%2066,203%2063,203%2059,200%2061,199%2059,196%2062,194%2061,193%2061,190%2062,189%2059,184%2060,182ZM108,154%20102,160%20107,166%20110,173%20108,175%20102,174%20102,175%20107,180%20108,183%20111,182%20118,183%20119,159%20117,157%20113,157%20112,156%20111,157ZM111,146%20113,149%20113,151%20116,152%20117,151%20116,150%20116,147%20114,148%20113,147%20114,146ZM22,40%2020,44%2020,49%2021,50%2024,49%2023,47%2024,41ZM30,13%2024,19%2022,22%2023,23%2021,24%2023,34%2027,33%2026,32%2027,31%2027,28%2029,27%2030,21%2032,18%2032,16ZM24,6%2021,6%2017,10%2018,12%2020,11ZM118,0%20101,0%2092,8%2091,10%2092,9%2097,9%20109,3%20112,5%20112,7%20110,10%20104,15%2094,21%2087,23%2087,24%2089,25%2094,25%2095,24%20103,23%20106,25%20105,27%2099,31%2092,32%2087,34%2083,34%2077,37%2075,37%2074,38%2075,37%2078,38%2075,41%2074,40%2069,44%2069,46%2065,49%2071,51%2085,51%2086,50%2093,49%2098,46%20104,46%20106,48%20106,51%20103,54%2097,57%2090,57%2089,58%2087,57%2071,57%2070,56%2066,56%2059,54%2054,63%2053,73%2055,74%2055,76%2056,75%2059,76%2062,75%2064,76%2066,74%2071,74%2076,76%2082,81%2084,86%2083,92%2086,94%2085,97%2090,104%2090,106%2093,111%2093,114%2095,119%2095,131%2096,128%2095,125%2098,119%2099,121%20100,118%20101,119%20105,116%20107,117%20109,115%20114,114%20112,113%20112,110%20115,107%20115,105%20119,102%20119,4%20118,3%20119,1ZM64,0%2073,10%2076,1%2075,0Z'/%3e%3cpath%20fill='%23f5ad2c'%20stroke='%23f5ad2c'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M87,443%2085,443%2082,446%2080,446%2081,447%2079,449%2078,447%2077,448%2077,451%2074,453%2073,455%2077,464%2082,465%2079,463%2077,457%2079,456%2081,453%2083,453%2081,452%2083,450%2084,450%2085,453%2086,453%2086,450%2085,449%2087,446ZM112,446%20108,442%20107,443%20107,448%20105,450%20105,452%20103,455%2095,461%2094,463%2093,462%2089,463%2090,464%2091,463%2094,464%2099,461%20106,453%20107,453%20108,455%20110,453%20109,447%20111,445ZM76,410%2074,409%2071,410%2072,414%2070,416%2070,419%2069,420%2070,421%2067,424%2069,427%2069,432%2064,436%2064,438%2063,439%2061,438%2060,440%2059,439%2055,441%2054,443%2051,443%2049,440%2050,438%2049,436%2050,435%2049,434%2053,431%2054,432%2059,429%2059,427%2060,426%2061,427%2063,422%2062,422%2061,424%2052,432%2034,442%2033,444%2034,445%2040,444%2042,448%2039,452%2035,453%2032,457%2031,456%2026,459%2023,463%2022,462%2022,465%2020,467%2027,462%2030,463%2031,461%2033,461%2036,463%2035,466%2029,471%2030,472%2029,473%2027,473%2034,473%2036,472%2037,470%2039,469%2040,470%2041,468%2042,469%2041,468%2045,463%2046,464%2042,461%2039,463%2037,460%2037,458%2039,456%2040,457%2041,456%2040,455%2046,450%2046,448%2044,447%2044,445%2047,443%2048,446%2050,447%2049,448%2051,451%2054,452%2054,454%2058,462%2059,468%2062,470%2063,473%2071,473%2067,471%2065,468%2066,467%2065,468%2063,464%2063,461%2065,457%2065,454%2064,453%2066,452%2064,452%2063,454%2061,451%2063,447%2066,448%2069,445%2070,446%2070,449%2071,449%2071,447%2073,445%2072,444%2072,440%2074,438%2075,441%2075,440%2078,438%2076,436%2078,432%2076,429%2079,424%2079,421%2078,420%2079,419ZM35,444%2036,443%2039,444%2038,445ZM93,400%2095,403%2097,404%2096,405%20101,413%20105,416%20106,419%20107,417%20104,412%20102,411%20102,409%2097,405%2096,403%2097,402%2096,403ZM72,398%2071,398%2071,402%2072,403%2071,408%2071,406%2072,405%2073,407%2074,405%2073,403%2071,402%2071,401%2073,400%2071,399ZM13,388%2015,389%2015,391%2019,397%2021,404%2021,402%2025,400%2028,400%2029,401%2028,403%2029,405%2028,406%2033,403%2035,403%2025,394%2017,390%2016,388%2015,389ZM91,383%2094,390%2096,388%2095,387%2095,384ZM24,382%2036,392%2036,390%2031,384%2031,381%2029,385%2027,385ZM32,350%2030,351%2029,353%2032,357%2031,359%2033,363%2036,363%2036,362%2038,361%2038,354%2039,353ZM20,329%2019,334%2017,335%2016,337%2012,338%2013,339%2019,341%2020,340%2019,339%2021,332ZM6,325%207,326%206,329%207,332%209,333%2010,330%2012,329%209,325ZM100,324%2099,332%20100,330%2099,327%20100,326%20101,328%20105,327%20110,329%20112,331%20112,333%20112,330ZM39,325%2037,324%2030,330%2027,337%2028,339%2027,342%2028,341%2030,343%2033,342%2036,343%2038,337%2037,336%2039,332%2042,330ZM30,314%2028,311%2025,310%2025,311%2027,311%2029,313%2028,314%2029,316%2027,318%2024,318%2023,317%2021,319%2019,319%2018,318%2020,316%2018,319%2020,320%2021,319%2022,320%2027,320%2030,317ZM21,310%2017,310%2016,311%2016,315%2017,313%2018,314%2018,312ZM92,308%2089,310%2088,309%2089,311%2087,312%2090,311%2092,312ZM7,300%206,301%207,303%205,306%207,309%207,311%209,313%2010,312%209,311%2010,310%209,307%2011,305%2013,306%2010,304%2011,303ZM11,297%2015,301%2020,300%2020,298%2016,295%2013,295ZM25,291%2027,291%2029,296%2031,296%2033,298%2032,299%2033,300%2032,302%2037,306%2038,304%2042,304%2042,300%2039,299%2035,294ZM101,283%20101,284%2096,289%2091,292%2090,294%2096,293%2096,292%2098,291%2098,289ZM97,276%2094,278%2090,283%2095,282%2096,281%2095,278ZM27,270%2029,273%2028,276%2029,275%2031,276%2030,275%2031,272%2029,271%2028,272ZM21,268%2021,270%2024,273%2023,272%2024,271%2023,269ZM119,267%20118,267%20113,276%20113,278%20110,282%20110,283%20113,284%20114,286%20119,283ZM93,261%2090,262%2089,264%2090,266%2090,264%2093,262ZM105,260%20101,263%20101,266%2099,267%2099,268%20101,268%20100,267%20103,265%20104,263%20102,262%20105,261ZM54,255%2053,261%2050,266%2041,275%2039,274%2036,275%2039,275%2040,277%2042,278%2044,281%2042,282%2043,283%2042,284%2038,284%2036,282%2033,282%2035,284%2036,283%2037,284%2044,284%2045,285%2046,283%2049,283%2050,284%2050,287%2055,288%2058,292%2058,295%2060,296%2061,301%2065,305%2065,308%2068,308%2070,310%2070,308%2073,305%2078,303%2076,299%2076,295%2080,290%2076,287%2075,289%2076,288%2078,289%2077,290%2078,292%2076,294%2071,290%2072,289%2071,289%2067,284%2069,282%2072,285%2070,283%2073,281%2074,282%2073,281%2075,278%2077,279%2079,272%2079,274%2076,275%2075,273%2069,271%2067,269%2066,265%2062,267%2061,265%2058,263ZM61,282%2063,280%2066,282%2065,283%2062,283ZM48,276%2049,275%2052,275%2053,276%2051,278ZM59,269%2060,270%2058,273%2056,271ZM8,255%209,258%207,259%207,263%208,264%205,270%206,272%205,273%209,276%2011,272%2010,269%2011,266%2013,265%2012,264%2013,263%2012,261%2012,258%2013,257%2012,258ZM15,245%2020,251%2020,256%2019,257%2021,258%2022,257%2024,259%2028,260%2029,258%2028,253%2029,252%2026,251%2028,250%2026,248%2024,249%2021,246%2022,245%2021,246%2019,245%2016,246ZM70,242%2069,243%2071,246%2074,248%2073,247%2074,246%2072,245%2073,244%2071,243%2072,242ZM92,241%2091,244%2092,245%2089,247%2087,251%2091,251%2090,248%2092,246ZM30,235%2033,237%2032,238%2033,237%2034,238%2033,241%2035,242%2031,245%2025,241%2026,240%2025,243%2026,242%2028,244%2028,246%2034,256%2034,259%2032,261%2033,262%2031,264%2030,262%2030,264%2031,264%2033,262%2032,261%2033,260%2037,260%2036,259%2037,257%2041,254%2042,251%2040,247%2041,243%2040,244%2038,242%2035,242%2034,241%2035,239%2034,237ZM92,231%2096,237%2098,236%20101,237%2094,231ZM54,222%2051,231%2054,236%2054,238%2055,238%2056,229%2054,226ZM81,216%2082,218%2082,221%2081,222%2079,221%2076,217%2074,218%2073,221%2074,222%2074,226%2075,225%2076,226%2076,228%2080,234%2080,230%2081,229%2081,224%2080,223%2082,221%2082,217ZM98,219%20100,221%20100,224%20101,226%20104,228%20106,232%20107,231%20108,232%20112,232%20113,231%20118,231%20119,232%20119,226%20112,227%20107,223%20105,218%20102,216%20103,215%20100,215ZM99,191%2098,191%2097,193%2098,195%2096,197%2093,196%2090,197%2089,199%2088,198%2085,200%2087,199%2089,201%2093,199%2096,199%2097,197%2099,197%20101,199%20100,200%20101,200ZM113,185%20110,195%20108,198%20109,206%20110,207%20108,210%20107,208%20106,209%20103,205%20102,207%2095,207%2091,210%2090,213%2091,216%2089,221%2089,223%2091,224%2090,227%2091,226%20101,233%20100,229%2096,224%2095,216%2099,212%20102,211%20108,212%20112,208%20112,205%20114,202%20114,194%20113,192%20116,188%20118,188ZM106,151%20103,152%20102,151%20101,152%20102,151%20103,153%2099,156%2097,155%2098,156%2097,157%2091,156%2087,154%2084,155%2081,154%2080,156%2077,156%2074,161%2075,164%2073,167%2074,168%2073,169%2070,169%2068,166%2067,166%2066,164%2064,164%2061,160%2058,160%2057,157%2056,158%2052,156%2050,157%2047,156%2052,160%2052,164%2050,167%2052,168%2055,172%2055,176%2049,186%2056,187%2055,185%2057,184%2056,183%2060,181%2061,182%2060,184%2061,187%2063,189%2062,190%2062,193%2063,194%2060,196%2062,199%2060,200%2074,206%2077,205%2078,206%2076,210%2077,214%2078,214%2077,208%2079,202%2088,192%2092,192%2093,193%2095,190%2096,191%2096,190%2098,189%2096,187%2097,185%20103,185%20105,182%2093,169%2094,167%2098,166%20104,170%20103,168%20104,167%20105,168%20102,166%20103,165%20101,163%20100,164%2098,163%2089,164%2086,162%2088,160%2090,161%2095,161%2099,159%20102,155%20105,153%20104,152ZM70,199%2072,198%2074,200%2071,201ZM78,196%2079,195%2082,196%2081,197ZM119,121%20117,124%20117,126%20114,128%20112,131%20112,136%20114,138%20112,139%20112,141%20109,144%20109,146%20110,145%20114,145%20115,146%20118,145%20119,146%20118,145%20119,144%20117,141%20118,134%20119,133%20118,130%20119,129ZM108,115%20101,120%20100,119%2099,122%2098,120%2096,125%2097,128%2094,134%2094,138%2092,141%2092,145%2091,146%2091,150%2093,153%2096,153%20101,148%20105,142%20105,138%20106,137%20103,131%20103,121ZM80,106%2079,107%2078,106%2074,109%2080,115%2080,118%2081,119%2080,121%2080,129%2081,130%2079,133%2080,136%2076,139%2073,143%2074,142%2077,146%2083,141%2087,132%2087,129%2086,128%2087,122%2086,123%2084,122%2085,121%2084,119%2086,117%2086,114%2084,109%2082,108%2083,107%2082,108ZM118,103%20113,110%20113,113%20117,113%20119,115%20119,103ZM59,84%2059,91%2058,92%2057,91%2057,86%2058,94%2055,95%2052,99%2053,100%2052,101%2050,100%2048,101%2044,100%2043,101%2044,100%2045,102%2051,105%2054,108%2055,111%2053,114%2048,114%2047,113%2046,114%2044,111%2045,112%2044,113%2044,118%2042,122%2044,126%2044,130%2042,131%2042,134%2040,136%2040,138%2041,136%2043,140%2040,142%2040,143%2049,140%2054,137%2062,129%2065,122%2066,114%2067,113%2066,114%2065,113%2067,109%2066,108%2066,102%2058,92%2059,91ZM53,74%2055,77%2054,78%2056,82%2057,81%2056,80%2058,78%2062,77%2062,76%2060,77%2056,76%2055,77%2054,74ZM12,55%2012,58%2015,62%2015,64%2018,66%2017,67%2019,69%2019,71%2020,69%2024,71%2028,71%2029,70%2025,60%2020,57ZM81,36%2071,40%2068,42%2063,48%2066,48%2068,46%2068,44%2071,41%2072,42%2071,41%2074,39%2075,40%2078,37ZM13,36%208,36%206,38%206,42%208,44%208,46%2010,43%209,41%2011,40ZM82,32%2089,30%2093,30%2093,29%2091,27%2090,29%2089,27%2087,27%2084,25%2089,28%2087,30ZM44,25%2043,28%2042,26%2038,29%2036,33%2037,34%2035,35%2034,57%2039,61%2038,63%2036,61%2038,63%2041,58%2041,53%2042,52%2041,51%2043,45%2042,44%2043,43%2043,39%2045,35%2048,33%2048,31%2047,33%2044,32%2045,31ZM10,9%208,10%207,12%208,13%208,17%209,18%2010,17%2012,18%2011,22%2015,12ZM54,0%2056,0%2058,3%2062,3%2063,6%2067,7%2070,14%2077,19%2078,16%2076,15%2077,13%2075,10%2075,7%2073,11%2063,0Z'/%3e%3cpath%20fill='%23feed24'%20stroke='%23feed24'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M69,446%2066,449%2063,448%2063,450%2061,452%2062,451%2063,452%2062,454%2064,456%2062,454%2064,451%2067,452%2065,453%2066,456%2070,453%2071,454%2068,452%2070,451ZM38,351%2040,353%2039,354%2039,361%2040,361%2040,354%2041,352ZM76,308%2070,315%2069,314%2068,316%2071,318%2069,324%2072,323%2074,320%2075,321%2075,319%2077,317%2075,312%2076,311ZM49,284%2046,284%2048,286%2048,292%2045,295%2037,295%2036,294%2039,298%2041,298%2043,300%2043,304%2042,305%2038,305%2037,307%2039,310%2039,312%2045,315%2045,318%2043,321%2044,329%2040,332%2038,336%2039,337%2038,338%2038,341%2044,341%2046,340%2049,335%2049,327%2052,324%2053,320%2058,316%2058,313%2060,311%2061,313%2061,312%2065,309%2066,310%2068,309%2065,309%2064,308%2064,305%2060,301%2059,296%2057,295%2057,292%2055,289%2050,288%2049,287ZM58,254%2063,259%2068,259%2070,265%2074,269%2076,269%2079,265%2081,265%2083,267%2080,285%2084,285%2086,288%2080,296%2081,298%2085,300%2086,302%2082,305%2083,306%2092,302%2092,299%2088,298%2085,295%2086,294%2085,292%2089,289%2086,285%2087,284%2086,281%2090,275%2091,276%2097,269%2099,269%2097,268%2092,270%2090,269%2089,271%2086,269%2086,264%2085,263%2087,260%2089,252%2087,252%2080,260%2076,260%2074,257%2074,253%2070,250%2068,251%2066,254%2063,254%2062,253%2061,254ZM11,239%2010,241%2012,241%2015,243%2016,245%2019,244%2025,248%2021,245%2022,244%2016,236ZM44,232%2043,232%2045,237%2044,239%2045,241%2042,243%2041,245%2043,251%2042,254%2038,257%2037,259%2038,260%2037,261%2033,261%2034,262%2032,264%2031,263%2032,264%2031,265%2029,264%2024,264%2024,265%2027,267%2030,266%2036,268%2039,265%2039,257%2040,256%2041,257%2044,257%2045,258%2045,261%2046,261%2046,259%2048,256%2047,247%2049,245%2052,246%2054,249%2054,246%2049,243%2052,242%2050,240%2050,238%2046,235ZM34,224%2033,231%2040,237%2040,234%2038,231%2038,229%2036,225ZM39,223%2040,225%2042,226%2042,229%2043,230%2044,227%2042,224ZM45,215%2043,217%2043,220%2044,221%2045,218%2047,217ZM96,203%2093,203%2092,204%2091,203%2087,206%2086,208%2086,214%2084,215%2081,211%2081,209%2083,207%2081,207%2082,208%2081,209%2081,215%2083,217%2083,221%2081,223%2080,222%2082,224%2081,235%2086,240%2089,240%2091,237%2088,230%2090,226%2090,224%2088,223%2090,216%2089,215%2090,210%2095,206%20102,206ZM35,201%2036,202%2035,203%2032,203%2024,209%2020,210%2019,209%2020,208%2018,207%2016,226%2019,222%2026,223%2030,221%2032,216%2031,215%2036,205%2036,202ZM114,117%20110,119%20108,122%20108,129%20109,130%20108,133%20110,138%20109,143%20111,141%20111,139%20113,138%20111,136%20111,131%20112,129%20116,126%20116,124%20118,121%20117,118ZM75,111%2074,126%2071,132%2071,135%2073,137%2072,141%2063,149%2059,151%2046,151%2045,150%2042,150%2040,151%2040,152%2042,153%2042,155%2040,157%2033,161%2030,161%2028,163%2026,163%2026,164%2028,165%2030,163%2039,161%2043,166%2040,173%2042,174%2044,173%2045,174%2045,177%2044,179%2042,180%2043,181%2031,191%2032,192%2026,199%2025,204%2030,200%2034,199%2036,196%2037,197%2036,196%2039,194%2045,194%2046,195%2044,202%2041,205%2039,211%2038,212%2037,211%2038,213%2036,215%2038,216%2037,215%2039,214%2046,206%2050,207%2051,208%2051,213%2050,214%2051,216%2049,218%2050,219%2049,223%2051,222%2052,218%2054,216%2056,216%2057,219%2063,223%2065,230%2065,236%2068,242%2071,241%2070,240%2071,238%2068,230%2070,226%2073,225%2073,222%2072,221%2075,216%2074,214%2071,212%2068,217%2069,219%2068,221%2069,222%2066,223%2063,220%2060,210%2061,209%2060,208%2057,208%2054,210%2052,208%2052,204%2051,203%2052,202%2052,191%2048,191%2046,193%2043,190%2044,185%2050,177%2049,173%2046,173%2045,172%2046,171%2045,168%2048,164%2048,161%2045,160%2044,157%2047,155%2049,156%2052,155%2056,157%2057,156%2059,158%2058,159%2061,159%2063,162%2066,163%2070,168%2073,168%2072,167%2074,164%2073,161%2077,155%2080,155%2081,156%2080,158%2082,156%2080,155%2081,153%2082,154%2085,153%2089,154%2086,149%2087,148%2087,141%2078,149%2078,153%2077,154%2075,153%2075,149%2072,144%2075,139%2079,136%2078,133%2080,130%2079,129%2079,121%2080,120%2079,115ZM28,198%2029,201%2027,202%2026,200ZM8,100%206,101%206,111%207,112%206,120%207,121%206,122%206,147%205,148%205,155%206,156%206,165%205,166%206,167%205,168%206,169%205,171%206,172%206,180%205,181%206,182%206,190%205,191%206,192%205,193%206,194%205,195%206,197%206,219%208,217%208,215%2010,212%209,211%2010,208%209,207%2010,206%2010,201%2013,197%2016,198%2019,203%2025,195%2026,191%2037,181%2035,180%2037,178%2035,180%2033,180%2031,178%2031,175%2037,168%2032,168%2031,167%2022,171%2016,175%2013,173%2014,168%2018,164%2024,160%2026,160%2027,158%2029,157%2030,158%2030,157%2028,156%2030,155%2024,156%2022,154%2022,152%2024,151%2025,149%2029,148%2031,146%2033,146%2038,142%2039,143%2039,142%2042,140%2041,137%2040,139%2039,138%2039,136%2041,134%2041,131%2043,130%2043,126%2041,122%2043,118%2043,113%2044,112%2037,106%2036,107%2033,105%2032,106%2033,107%2033,114%2029,118%2025,118%2022,115%2022,106%2021,107%2017,107%2016,106%2015,107%2014,105ZM17,99%2017,100%2022,104%2022,101%2019,99%2020,98ZM59,79%2057,80%2058,81%2057,82%2058,91%2056,95%2058,91%2059,92%2058,91%2058,84%2059,83%2058,81ZM20,70%2020,72%2023,75%2023,78%2029,93%2031,95%2037,97%2035,93%2035,82%2029,71%2028,72%2024,72ZM14,38%2010,41%2011,42%2010,45%2011,45%2012,43%2013,44%2015,43%2016,40ZM14,17%2011,23%2011,26%2013,28%2014,27%2015,28%2017,24%2017,19ZM42,69%2046,68%2046,62%2047,61%2046,60%2047,57%2050,53%2053,46%2056,43%2056,40%2055,39%2056,32%2060,28%2063,28%2067,25%2070,25%2076,21%2078,24%2078,29%2076,32%2083,31%2088,28%2083,25%2084,21%2087,18%2090,18%2096,15%2098,15%20102,12%20102,11%2099,13%2095,13%2094,14%2088,13%2087,12%2087,8%2090,5%2088,5%2086,3%2087,1%2086,0%2081,0%2079,6%2081,11%2083,12%2084,11%2085,12%2085,15%2077,22%2076,20%2069,14%2067,8%2063,7%2062,4%2058,4%2056,1%2053,0%2038,0%2037,1%2036,0%2030,0%2033,1%2044,1%2045,2%2039,4%2037,3%2031,4%2034,6%2033,8%2031,8%2031,10%2032,9%2034,10%2034,14%2036,16%2035,18%2036,19%2036,24%2038,25%2037,26%2041,22%2042,23%2041,22%2044,21%2048,16%2050,17%2048,22%2048,30%2049,33%2046,35%2044,39%2044,43%2043,44%2044,45%2042,51%2043,52%2042,53%2042,58%2040,61%2043,65%2043,68Z'/%3e%3cpath%20fill='%23f6e46f'%20stroke='%23f6e46f'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M68,462%2068,464%2070,467%2075,469%2080,469%2086,471%20100,471%20104,468%20109,467%20107,466%20108,465%20101,469%2085,470%2084,469%2076,468%2071,461ZM69,461%2070,462%2069,465%2068,464ZM73,446%2071,450%2071,453%2066,457%2064,461%2064,464%2068,471%2072,473%2075,473%2067,469%2065,467%2065,464%2064,463%2068,458%2074,459%2072,455%2074,449ZM89,437%2089,439%2087,442%2088,443%2088,446%2086,449%2090,443%2089,442%2091,441%2089,440ZM107,436%20116,446%20116,442%20118,441%20114,441ZM45,412%2042,412%2042,421%2045,419%2045,415%2046,414ZM27,411%2028,412%2028,415%2031,415%2032,412%2037,409%2055,409%2056,410%2059,410%2063,413%2063,411%2045,406%2034,406ZM39,407%2041,406%2043,408%2041,409ZM99,386%2099,389%20101,390%20100,391%20101,390%20102,391%20101,394%20105,397%20104,398%20102,397%20104,400%20106,407%20108,409%20107,412%20103,410%20103,411%20105,412%20108,417%20107,420%20110,423%20114,423%20110,423%20109,422%20110,416%20108,412%20109,409%20113,410%20113,409%20108,403%20102,391%20102,388ZM105,399%20107,401%20106,404%20104,401ZM8,383%209,383%203,388%208,390%2012,395%2014,399%2014,404%2018,409%2016,410%2018,409%2017,400%2011,389%206,385ZM112,377%20111,379%20113,383%20111,385%20112,386%20113,400%20115,404%20115,407%20116,401%20117,400%20119,401%20115,398%20114,395%20114,389%20113,388%20113,383%20114,382ZM88,376%2088,377%2096,381%2099,381%20101,384%20108,388%20107,385%20102,383%2093,377ZM100,364%20102,367%20113,373%20119,380%20119,377%20116,374%20110,371%20103,366%20102,364ZM49,361%2050,364%2055,364%2059,366%2063,366%2079,373%2077,372%2078,371%2071,367%2066,366%2063,364ZM78,358%2082,373%2087,383%2091,395%2093,396%2092,397%2095,401%2094,402%2095,401%2097,403%2096,404%2097,403%20100,407%2096,402%2095,398%2089,388%2085,376%2082,372%2083,371%2079,361%2080,359ZM9,356%2014,362%2011,366%2011,370%209,374%2012,383%2025,390%2039,403%2038,401%2039,399%2030,390%2023,385%2022,386%2020,383%2019,384%2016,380%2015,381%2012,378%2013,377%2012,378%2011,377%2012,375%2011,376%2010,375%2010,371%2013,367%2021,363%2023,363%2024,361%2025,362%2022,357%2020,358%2017,357%2011,358ZM93,344%2094,345%2093,346%2093,356%2095,362%2094,363%2095,364%2096,375%2099,377%2097,371%2097,362%2095,356%2095,348%2094,347%2095,345ZM11,352%2013,352%2019,349%2024,349%2031,347%2036,347%2037,348%2039,347%2049,347%2050,348%2058,348%2066,351%2069,351%2078,354%2080,356%2085,357%2090,360%2089,357%2087,357%2082,354%2073,352%2070,350%2067,350%2064,348%2061,348%2053,345%2033,346%2032,345%2024,345%2022,344%2021,346%2018,346ZM78,333%2080,336%2093,340%20107,347%20109,349%20110,347%2097,341%2095,339%2090,338%2088,336ZM115,332%20115,337%20114,338%20115,342%20113,344%20113,349%20114,350%20113,353%20114,354%20112,355%20112,358%20113,359%20112,361%20112,366%20113,369%20115,344%20117,337%20117,333ZM65,332%2070,333%2070,331%2066,331ZM75,326%2073,328%2074,342%2076,346%2076,349%2078,350%2077,348%2077,343%2076,342%2075,328%2074,327ZM5,325%205,332%207,334%2012,335%2014,332%2015,333%2016,332%2017,326%2014,326%209,324%206,324ZM5,325%206,324%209,324%2014,328%2012,332%2011,330%2010,333%208,334%206,332%205,329%206,326ZM96,322%2094,322%2093,324%2093,335%2094,336%2096,335%2096,326%2097,325ZM93,318%2098,319%20117,329%20119,332%20119,329%20117,328%20118,327%20113,325%20111,323%2097,317ZM8,316%2011,319%209,322%2013,322%2017,324%2022,324%2023,323%2024,324%2024,323%2020,323%2014,321ZM69,310%2067,311%2065,310%2062,312%2061,314%2060,312%2059,313%2059,316%2054,320%2054,322%2050,327%2050,329%2050,327%2054,322%2055,323%2054,321%2057,318%2060,320%2061,319%2065,319%2069,321%2070,318%2067,316%2069,313%2070,314%2071,313%2069,312ZM5,310%2012,317%2013,315%2012,314%2013,309%2018,306%2022,306%2023,307%2027,307%2034,312%2033,315%2034,314%2037,316%2042,316%2043,315%2038,312%2037,308%2035,308%2033,306%2023,302%2022,303%2021,302%2018,303%2013,307%2011,306%2010,307%2011,309%2010,311%2011,312%209,314%206,311%206,309ZM11,301%209,299%206,299%205,300%205,305%206,303%205,301%207,299%2011,302ZM97,295%2094,297%2088,297%2086,295%2088,297%2092,298%2093,299%2093,302%2083,307%2081,305%2084,303%2081,304%2073,309%2073,310%2076,307%2077,308%2077,311%2076,312%2078,317%2076,319%2076,321%2075,322%2074,321%2072,324%2069,325%2068,323%2066,326%2068,327%2067,328%2069,326%2073,325%2074,323%2075,324%2074,323%2075,322%2078,323%2086,318%2092,316%2092,315%2088,317%2079,317%2077,315%2077,312%2082,308%2093,304%2095,302%2095,299ZM8,293%2010,294%2014,291%2024,288%2033,288%2040,291%2041,288%2040,287%2023,286%2022,287%2017,287%2011,289%208,291ZM97,284%2091,287%2087,285%2090,289%2087,291%2086,293ZM100,269%2097,270%2091,277%2090,276%2087,281ZM102,266%20101,267%20100,264%2091,269%2096,267%2098,268%2099,266%20101,267ZM114,262%20111,266%20110,270%20105,279%20104,285%2099,296%2099,300%2098,301%2099,303%2096,306%2096,313%2097,314%20104,289%20109,279%20108,278%20109,271ZM40,257%2040,265%2036,269%2030,267%2028,268%2031,269%2037,269%2039,268%2041,264ZM17,254%2014,255%2013,258%2014,265%2011,269%2013,273%2011,274%209,277%204,273%205,272%204,270%207,264%206,264%205,266%204,273%205,274%205,277%207,278%208,280%2012,280%2013,281%2017,277%2017,274%2018,273%2017,265%2018,264%2023,265%2026,267%2024,266%2023,264%2024,263%2029,263%2025,263%2020,260%2019,261%2018,260%2016,261%2015,260ZM49,246%2048,247%2049,256%2046,262%2044,261%2044,258%2043,258%2044,260%2044,266%2042,269%2039,271%2042,270%2047,265%2050,260%2050,251%2048,248ZM30,239%2025,233%2022,233%2011,237%207,240%207,243%208,242%2011,242%2015,244%2012,242%2010,242%208,240%2016,235%2025,247%2017,236%2020,234%2023,235%2024,234%2025,237%2030,240ZM28,232%2033,235%2038,241%2040,242%2043,242%2044,240%2043,242%2040,242%2030,232ZM32,225%2029,225%2016,231%208,231%2012,231%2013,232%2012,234%2018,231%2028,229ZM36,219%2038,222%2042,223%2045,227%2045,232%2046,234%2051,238%2051,240%2053,242%2050,243%2052,243%2055,246%2055,249%2054,250%2052,247%2051,247%2056,252%2061,262%2064,263%2066,260%2063,260%2057,254%2062,252%2063,253%2066,253%2063,252%2063,249%2062,248%2062,230%2060,225%2059,225%2058,240%2056,242%2054,242%2051,239%2049,233%2047,234%2045,232%2045,226%2040,221ZM16,219%2015,223%2011,229%2018,227%2018,224%2019,223%2016,227%2015,226%2015,221ZM48,210%2041,219%2042,219%2042,217%2045,214%2047,216ZM48,207%2046,207%2041,213%2038,215%2039,217%2043,211ZM84,201%2082,204%2082,206%2083,206%2086,202ZM15,201%2013,202%2013,214%2012,215%2014,216%2014,218%2016,203%2016,204%2014,205%2013,202ZM42,198%2040,198%2034,202%2036,201%2037,202%2037,205%2035,209%2038,202ZM50,189%2046,192%2048,190%2052,190%2053,191%2053,202%2052,203%2053,203%2054,192%2053,189ZM112,185%20109,187%20110,189%20109,190%20108,189%20108,197%20109,191ZM41,176%2036,180%2038,180ZM51,171%2047,171%2046,172%2049,172%2051,175%2051,177%2045,185%2044,190%2047,183%2051,178%2052,172ZM40,171%2037,173%2034,177%2039,174ZM41,164%2039,162%2036,162%2033,164%2030,164%2028,166%2026,166%2028,166%2031,164%2036,164%2037,163%2040,163ZM37,154%2033,154%2029,156%2031,157ZM108,142%20106,147%20103,150%20104,149%20106,150%20108,147ZM72,137%2071,140%2063,148%2060,148%2059,150%2055,148%2054,149%2051,149%2046,147%2042,147%2041,146%2042,145%2034,149%2032,149%2031,152%2028,151%2026,153%2033,151%2039,151%2042,149%2045,149%2046,150%2059,150%2068,144%2071,141ZM91,135%2089,136%2087,140%2088,141%2088,146%2089,139ZM111,118%20106,122%20106,128%20108,135%20107,133%20108,131%20107,129%20107,122%20108,120ZM31,98%2031,100%2035,101%2047,110%2052,111%2052,110%2046,105ZM12,93%2016,98%2019,98%2023,101%2023,104%2022,105%2023,108%2023,100%2015,96ZM11,85%2011,88%2017,94%2022,96%2020,92%2015,88%2013,84%2014,85%2013,86ZM12,74%2013,79%2018,87ZM17,71%2016,73%2017,74%2015,75%2018,79%2018,81%2026,98%2026,106%2026,104%2028,101%2027,95ZM15,50%2014,52%2015,53%2018,53%2027,58%2034,64%2033,66%2032,65%2033,66%2034,65%2037,68%2039,68%2035,66%2037,63%2017,49ZM103,48%20101,48%2096,51%2087,54%2075,54%2074,53%2069,53%2061,50%2062,51%2061,52%2065,52%2070,54%2097,54%2099,53%2096,51%20101,48ZM19,39%2014,37%2017,40%2016,43%2014,45%2012,44%2012,45%209,46%209,47%2015,47%2017,45ZM5,35%207,33%2014,33%2024,39%2026,38%2026,37%2017,34%2012,30%2013,31%2012,33%207,33ZM77,24%2076,22%2072,25%2067,26%2064,28%2067,26%2074,25%2076,27%2076,30%2077,29ZM35,19%2033,23%2034,24%2034,28%2035,28%2037,25%2035,24ZM30,8%2027,8%2018,18%2017,27%2015,29%2014,28%2016,30%2019,31%2018,22%2020,21%2023,16%2030,10ZM23,0%2016,0%2015,2%2010,5%2010,6%2011,6%2012,4%2014,4%2015,5%2013,6%2013,7%2015,8%2018,4%2020,4%2024,2Z'/%3e%3cpath%20fill='%23fcfaec'%20stroke='%23fcfaec'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M119,460%20117,464%20113,466%20111,465%20108,466%20111,466%20112,467%20110,473%20119,473ZM119,441%20117,442%20117,447%20119,448%20119,451ZM65,429%2062,430%2063,433%2066,430ZM93,423%2092,423%2092,431%2090,435%2090,440%2091,440%2092,438%2092,434%2093,433ZM117,401%20116,408%20114,409%20113,411%20109,410%20109,412%20111,416%20110,422%20114,422%20119,425%20119,402ZM62,369%2060,372%2060,381%2062,386%2066,389%2065,390%2065,394%2067,400%2067,413%2064,420%2065,421%2068,411%2067,410%2068,409%2068,403%2067,402%2068,401%2066,397%2068,395%2073,394%2077,391%2079,391%2084,397%2086,401%2086,404%2090,410%2091,417%2090,409%2081,391%2077,387%2074,390%2069,389%2064,384%2062,380%2062,374%2065,371%2067,371%2070,373%2072,376%2070,378%2068,375%2066,374%2065,375%2065,380%2069,386%2073,387%2076,382%2076,378%2074,374ZM24,352%2026,359%2033,370%2037,367%2042,369%2048,375%2049,378%2049,384%2046,386%2042,385%2040,383%2039,379%2041,378%2042,381%2045,383%2047,380%2046,377%2040,371%2037,370%2034,374%2034,378%2033,379%2035,385%2040,389%2047,389%2051,387%2052,385%2052,380%2050,375%2046,370%2046,355%2048,350%2046,350%2045,352%2045,357%2044,358%2045,363%2043,365%2038,365%2034,367%2032,367%2029,363%2026,355%2026,351ZM67,327%2064,327%2059,330%2057,329%2055,326%2053,330%2057,329%2058,331%2055,333%2049,342%2052,342%2055,337%2061,331ZM59,320%2057,319%2054,323ZM41,317%2037,317%2034,315%2033,318%2026,325%2023,335%2024,337%2023,338%2023,341%2024,342%2024,337%2027,329%2033,323%2038,321ZM44,288%2042,288%2041,291%2043,291ZM119,255%20112,266%20108,279%20119,260ZM28,102%2026,107%2026,112%2025,113%2028,112%2029,113%2030,110%2029,109ZM72,77%2067,77%2062,83%2062,92%2065,97%2069,101%2070,104%2070,115%2067,123%2067,126%2064,131%2056,139%2042,146%2054,148%2052,146%2057,140%2059,139%2065,139%2067,140%2069,137%2068,136%2064,138%2063,136%2068,130%2072,118%2072,111%2070,105%2071,104%2076,104%2079,102%2082,102%2086,106%2089,112%2089,115%2090,116%2090,134%2089,135%2091,134%2092,131%2092,120%2091,119%2089,109%2083,98%2081,96%2078,99%2073,100%2071,99%2066,93%2065,87%2069,82%2075,87%2073,90%2070,85%2068,88%2070,94%2073,97%2078,96%2081,89%2080,83%2076,79ZM103,49%2097,51%20100,52%20102,51ZM72,35%2065,36%2062,33%2060,34%2059,37%2062,36%2064,38%2056,47%2050,60%2050,70%2048,74%2037,76%2034,72%2033,67%2030,64%2033,73%2038,80%2042,77%2047,77%2053,84%2053,88%2048,93%2046,92%2044,89%2045,88%2049,89%2050,87%2049,82%2045,79%2041,81%2039,84%2038,89%2040,94%2044,97%2050,97%2054,92%2053,81%2049,76%2052,60%2054,58%2060,46ZM33,24%2028,39%2028,53%2030,55%2031,39%2034,31ZM10,0%200,0%200,473%201,473%201,470%200,469%200,455%201,454%201,447%200,446%200,418%201,417%201,412%200,411%201,409%200,408%201,407%201,400%200,397%201,396%201,391%200,389%206,384%207,385%206,384%208,382%2011,383%208,374%2010,370%2012,377%2017,382%2011,375%2011,371%2013,368%2011,371%2010,370%2010,366%2013,362%2012,360%209,358%208,355%2011,353%2010,352%2018,345%2021,345%2021,344%2018,344%208,340%202,334%202,329%201,328%202,323%206,321%209,321%2010,319%202,311%202,299%209,294%204,291%2010,283%203,289%202,288%202,282%201,281%201,248%203,241%2012,233%2012,232%208,232%205,230%2011,224%2011,222%2013,219%2013,216%2012,216%2011,220%204,227%202,226%202,206%201,203%202,202%202,191%203,190%202,187%203,185%203,182%202,181%202,170%203,169%203,157%202,156%202,146%203,145%203,94%205,93%2012,99%209,94%206,85%208,83%2010,86%2011,84%2013,85%209,77%209,69%2010,68%2015,74%2017,73%208,57%208,54%2010,52%2013,52%2014,50%2013,51%207,49%203,44%203,37%207,32%2012,32%2012,31%206,26%206,23%205,22%206,19%204,15%204,10%209,6Z'/%3e%3cpath%20fill='%235c2d09'%20stroke='%235c2d09'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M111,467%2099,473%20107,469%20108,470%20107,473%20108,473ZM40,448%2038,446%2029,446%2027,447%2036,446%2038,447%2039,449%2032,453%2029,456%2026,457%2014,469%2025,458%2034,453ZM45,445%2047,447%2047,452%2042,456%2039,461%2042,459%2044,459%2047,461%2047,465%2042,471%2038,473%2044,470%2048,464%2047,460%2042,458%2047,452%2047,446ZM118,451%20113,444%20103,435%2094,430%2094,431%2096,431%20101,434%20105,438%20105,447%20102,452%2096,458%2093,460%2090,460%2088,457%2087,451%2089,449%2092,442%2087,451%2088,458%2089,459%2086,460%2087,461%2092,461%20100,456%20105,448%20106,440%20107,439%20116,449%20116,452%20118,455%20117,460%20113,464%20108,460%20107,455%20106,455%20102,461%2094,466%2086,465%2094,466%2095,467%2094,468%2086,468%2085,467%2077,466%2074,461%2071,459%2069,459%2066,462%2066,465%2068,468%2074,471%2077,471%2078,473%2083,473%2086,472%2079,472%2072,470%2067,466%2067,461%2070,459%2075,463%2076,466%2079,467%2083,467%2084,468%2097,468%20104,466%20109,463%20114,464%20118,459ZM109,462%20107,464%20100,467%2097,467%2096,466%20100,463%20105,457ZM70,409%2069,409%2069,416%2067,419%2067,421%2065,425%2061,428%2065,427%2068,430%2063,435%2061,434%2061,432%2056,432%2051,436%2052,439%2057,439%2064,435%2068,431%2068,429%2065,425%2069,416%2069,413%2070,412%2069,410ZM56,434%2059,433%2060,435%2057,436ZM89,394%2091,400%2096,407%2098,412%20109,425%20107,426%20105,431%2095,425%2093,419%2093,412%2090,405%2093,412%2093,420%2095,425%2094,428%2096,426%20103,430%20115,440%20119,440%20119,427%20115,424%20109,424%2097,410ZM112,424%20113,425%20116,425%20119,429%20119,434%20117,440%20110,436%20106,432%20107,427ZM78,392%2076,394%2068,397%2070,403%2070,407%2069,397%2070,396%2073,396%2078,393%2084,401%2084,404%2088,411%2088,414%2090,419%2090,430%2086,440%2083,443%2076,446%2074,443%2074,441%2073,441%2075,446%2075,452%2076,449%2075,448%2078,445%2080,445%2086,441%2090,432%2090,426%2091,425%2088,409%2086,407%2082,397ZM2,389%202,392%203,390%205,390%2010,395%2012,399%2013,410%2014,411%2018,411%2020,408%2020,405%2017,396%2015,394%2015,392%2010,386%2011,385%2017,387%2030,396%2037,404%2028,407%2025,411%2026,412%2026,415%2028,417%2030,417%2033,415%2034,412%2039,411%2041,413%2040,414%2040,421%2042,423%2045,422%2047,418%2047,413%2046,412%2047,411%2046,410%2035,411%2030,417%2026,414%2026,410%2033,405%2048,405%2049,406%2053,406%2057,408%2060,408%2065,411%2064,414%2055,411%2049,411%2058,412%2064,416%2059,424%2048,433%2030,442%2039,437%2041,437%2054,429%2060,423%2065,414%2065,398%2063,391%2064,399%2065,400%2065,409%2064,410%2053,406%2045,405%2040,398%2033,391%2043,403%2041,405%2039,405%2033,398%2024,391%2011,384%208,384%2014,391%2020,405%2019,410%2018,411%2014,411%2013,410%2013,401%2011,396%207,391ZM42,410%2045,410%2047,413%2047,418%2044,422%2041,422%2040,421%2040,416%2041,415%2040,412ZM65,373%2067,373%2070,376%2070,375%2068,373%2065,373%2063,375%2064,381%2067,386%2070,388%2075,388%2077,385%2079,386%2087,398%2089,403%2086,396%2077,383%2074,388%2070,388%2065,383%2063,378%2063,375ZM66,321%2060,321%2052,327%2051,331%2052,331%2053,333%2047,343%2048,343%2048,341%2053,333%2057,330%2052,331%2051,329%2053,326%2056,325%2057,327%2062,327%2066,325%2067,323ZM57,325%2059,323%2062,323%2063,324%2062,327%2058,327ZM99,292%2096,303%2094,305%2088,307%2079,312%2079,313%2080,312%2084,312%2087,313%2088,315%2094,314%2095,315%2091,318%2077,325%2074,325%2065,330%2056,338%2055,341%2052,344%2050,344%2054,344%2056,338%2061,333%2063,334%2069,334%2072,336%2072,339%2073,340%2072,341%2074,346%2074,349%2073,350%2077,351%2074,349%2074,345%2072,339%2072,332%2071,335%2069,334%2064,334%2063,332%2067,329%2072,330%2072,327%2074,325%2076,325%2077,326%2077,336%2078,338%2079,337%2088,340%2091,343%2091,355%2089,356%2085,354%2090,356%2092,358%2092,362%2091,363%2087,360%2076,355%2055,349%2028,349%2027,350%2021,350%2018,351%2021,350%2023,353%2022,356%2014,356%2012,354%2016,352%2010,355%2023,356%2027,363%2020,365%2013,370%2013,375%2017,380%2024,384%2031,390%2024,384%2017,380%2013,375%2013,370%2016,367%2023,364%2026,364%2033,372%2032,381%2034,386%2039,391%2046,391%2051,389%2053,386%2049,390%2040,391%2034,386%2032,381%2032,376%2036,369%2039,369%2047,376%2047,377%2047,376%2039,369%2036,369%2033,372%2030,369%2023,355%2023,351%2024,350%2027,350%2028,351%2029,359%2033,366%2040,363%2043,363%2043,353%2046,349%2048,349%2049,351%2051,349%2064,351%2076,356%2076,359%2078,364%2078,367%2077,368%2066,364%2075,367%2080,371%2081,374%2079,375%2070,370%2066,369%2076,373%2077,374%2076,375%2077,374%2080,375%2083,378%2088,392%2087,387%2080,372%2076,358%2077,356%2080,357%2084,369%2084,372%2088,379%2091,388%2088,381%2089,380%2091,380%2097,384%2098,392%20104,407%20103,408%20100,405%2095,395%20100,405%20107,411%20100,397%2097,388%2097,385%2098,384%20104,388%20103,389%20106,394%20106,396%20109,402%20114,408%20111,399%20111,394%20110,393%20110,385%20109,384%20110,376%20111,375%20113,376%20115,379%20115,388%20116,389%20116,395%20118,400%20119,399%20119,396%20116,393%20116,390%20119,389%20118,388%20118,385%20119,384%20118,383%20119,381%20111,374%20101,368%2098,363%2099,362%20102,363%2098,360%2099,367%20106,371%20109,374%20109,383%20108,384%20104,382%20101,378%2099,379%2095,376%2094,368%2093,367%2093,362%2092,361%2092,356%2091,355%2091,343%2094,342%20110,351%20111,353%20110,354%20110,366%20108,367%20104,364%20119,375%20119,356%20116,354%20116,351%20116,361%20116,356%20117,355%20118,356%20118,362%20119,363%20118,365%20118,372%20117,373%20115,371%20115,365%20115,370%20114,371%20112,370%20110,367%20111,344%20112,343%20113,333%20114,332%20113,331%20115,330%20119,333%20119,336%20118,337%20119,340%20119,348%20118,349%20117,348%20117,342%20117,349%20119,349%20119,340%20118,339%20119,338%20119,333%20114,329%20104,324%20107,326%20109,326%20114,330%20113,331%20113,338%20112,339%20111,349%20110,350%2094,342%2086,340%2077,336%2077,332%2078,331%2081,332%2077,330%2077,325%2086,320%2091,319%2092,320%2091,335%2090,336%2086,334%2092,336%20103,342%2097,338%2097,334%2097,337%2096,338%2091,335%2092,321%2093,320%2096,320%2098,322%2098,325%2099,322%20102,323%2096,320%2094,320%2092,318%2095,315%20101,317%20100,316%20100,309%20100,314%2098,316%2094,313%2094,308%2097,303%2096,302ZM104,388%20110,392%20110,395%20112,400%20112,403%20111,404%20106,396%20106,394%20103,389ZM116,379%20118,381%20118,387%20117,388%20115,386%20115,380ZM85,374%2087,373%2090,375%2093,375%20102,381%20110,385%20110,389%20108,390%2094,381%2088,379ZM82,358%2090,362%2093,365%2093,371%2094,372%2093,375%2091,375%2084,371%2082,361%2081,360ZM28,350%2029,349%2043,349%2044,350%2043,353%2043,362%2033,365%2030,361%2028,355ZM95,306%2094,307%2094,312%2092,314%2088,314%2081,311%2093,305ZM99,281%2092,285%2090,285%2088,283%2092,279%2089,281%2088,283%2089,285%2095,284%2097,282%20100,283%2088,293%2088,295%2091,295%2089,295%2088,293%20100,283ZM79,278%2077,282%2077,286%2079,288%2082,288%2083,289%2079,293%2078,299%2082,302%2074,306%2071,309%2071,312%2071,310%2073,307%2078,304%2080,304%2084,301%2081,301%2078,299%2078,295%2085,287%2080,288%2077,285%2077,282ZM12,282%2013,282%2014,284%2015,283%2017,286%2019,285%2033,285%2024,285%2021,282%2020,279%2023,284%2022,285%2016,284%2014,282%2019,277%2019,273%2018,278%2014,282ZM119,252%20114,258%20105,276%20108,271%20109,267ZM112,184%20110,184%20108,186%20107,184%20108,187%20106,189%20104,189%2099,186%2099,188%20102,187%20106,191%20106,199%20107,200%20107,206%20108,207%20107,206%20107,200%20106,199%20106,191%20107,188ZM110,147%20106,154%2098,161%20100,161%20108,151%20113,155%20111,154%20109,151ZM70,136%2070,139%2067,142%2064,140%2060,140%2055,144%2058,146%2064,145%2068,142%2070,139ZM64,140%2065,143%2062,146%2060,146%2059,145%2060,144%2058,143%2062,140ZM75,28%2074,27%2070,27%2063,30%2064,32%2065,32%2065,31%2069,28%2070,30%2068,33%2070,33%2072,31%2074,31ZM34,17%2032,20%2031,26%2027,36%2026,51%2027,37Z'/%3e%3cpath%20fill='%23c38837'%20stroke='%23c38837'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M32,465%2026,467%2027,469ZM106,460%20100,465%20106,463%20107,462ZM81,451%2080,452%2081,451%2084,453%2081,454%2080,456%2078,457%2078,459%2080,461%2080,463%2083,465%2082,466%2087,466%2086,466%2085,464%2086,463%2089,464%2088,463%2091,462%2086,462%2085,460%2087,459%2087,455%2086,456%2085,455%2084,451%2082,452ZM49,449%2047,454%2048,455%2046,457%2045,456%2044,457%2046,458%2047,457%2049,459%2049,463%2050,462%2052,464%2049,465%2046,471%2042,473%2062,473%2061,470%2059,469%2057,466%2057,462%2055,459%2053,452%2051,452ZM107,440%20108,444%20109,442%20112,445%20110,447%20111,453%20108,457%20110,458%20109,459%20112,462%20113,461%20114,462%20116,459%20116,454%20114,451%20115,450%20113,446ZM109,427%20110,430%20108,432%20112,435%20113,434%20114,437%20116,438%20118,432%20117,427%20115,426ZM78,394%2074,397%2072,397%2073,398%2072,399%2074,400%2072,401%2071,404%2071,403%2073,402%2075,405%2073,408%2072,406%2071,409%2074,408%2078,411%2079,418%2080,419%2079,420%2080,421%2080,424%2077,429%2079,432%2077,435%2078,437%2077,438%2078,439%2076,440%2075,442%2076,444%2081,443%2085,439%2084,440%2082,438%2080,433%2081,430%2080,427%2081,423%2080,421%2081,419%2079,416%2079,413%2081,412%2079,410%2081,408%2084,410%2083,411%2084,413%2082,414%2083,416%2082,415%2086,412%2087,415%2086,409%2082,403%2082,400%2080,399%2081,398%2080,399%2078,396%2079,395ZM85,408%2086,409%2086,412%2085,413%2083,411ZM105,390%20110,400%20109,398%20109,393ZM96,387%2095,388%2096,389%2094,391%2096,393%20102,405%2098,397%2097,390%2095,388ZM78,382%2078,384%2083,389%2088,397%2093,408%2093,410%2094,409%2095,410%2095,408%2094,409%2092,406%2093,405%2089,399%2088,394%2087,395%2086,394%2087,391%2085,390%2086,389%2084,386%2083,389%2079,385ZM17,291%2019,292%2026,300%2030,301%2032,303%2031,302%2032,301%2031,299%2033,297%2032,298%2029,297%2027,294%2027,292%2024,291%2023,292%2018,292ZM68,282%2069,283%2068,285%2069,285%2070,287%2073,289%2072,290%2076,293%2077,292%2078,293%2081,290%2081,289%2080,289%2077,292%2076,291%2078,288%2076,285%2075,286%2074,284%2077,280%2075,279%2075,280%2070,284ZM21,276%2022,277%2021,280%2022,279%2024,282%2025,280%2027,282%2029,282%2030,280%2031,283%2029,284%2032,283%2033,284%2032,282%2033,281%2036,281%2038,283%2042,283%2041,282%2043,281%2039,276%2033,275%2032,273%2031,275%2032,276%2031,277%2029,276%2028,277%2027,276%2028,273%2027,272%2027,276%2026,277%2023,275ZM13,244%2011,246%208,246%207,245%208,247%206,249%205,247%207,251%206,252%208,253%207,258%207,255%208,254%2012,257%2014,253%2017,255%2015,250%2016,249%2015,250%2011,246ZM99,190%2097,190%2097,191%2095,192%2095,195%2096,196%2097,195%2098,196%2096,193%2097,191ZM102,189%20102,191%20104,194%20104,201%20105,203%20104,191ZM118,187%20119,188%20116,189%20114,192%20115,194%20115,202%20113,205%20113,208%20108,213%20102,212%20104,212%20108,216%20109,221%20114,224%20119,222%20118,221%20119,220%20118,219%20119,216%20116,211%20116,207%20118,203%20117,200%20119,198%20119,195%20118,194%20119,193%20118,191%20119,188ZM106,184%20102,186%20105,188%20106,187ZM39,180%2032,187%2033,186%2034,187ZM118,146%20117,147%20117,150%20118,151%20116,153%20114,153%20111,148%20111,152%20113,154%20115,153%20116,154%20115,155%20119,153%20118,152%20119,151%20119,147ZM87,117%2085,119%2086,121%2085,122%2087,121Z'/%3e%3cpath%20fill='%2393581a'%20stroke='%2393581a'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M107,470%20106,469%20107,470%20104,472%20102,471%20103,470%20102,473%20100,472%2090,472%20106,473ZM25,459%2024,458%2014,468%2015,469%2013,470%2015,471%2014,470%2020,464%2019,463%2023,459%2024,460ZM87,407%2086,408%2085,407%2086,408%2084,411%2081,409%2080,410%2082,412%2080,413%2080,416%2082,419%2081,421%2082,423%2081,425%2082,428%2081,433%2083,438%2085,440%2083,442%2084,443%2083,444%2084,443%2083,442%2085,440%2084,439%2086,438%2086,436%2089,430%2089,419%2087,418%2088,415%2087,416%2085,412%2085,409ZM84,411%2086,413%2082,416%2081,414%2083,413ZM117,359%20117,361%20116,362%20115,361%20115,364%20116,365%20116,371%20118,373%20116,371%20116,366%20118,364ZM98,326%2097,328%2097,333%2099,339%2098,340%2099,339%2098,338ZM15,293%2023,300%2024,299%2025,300%2019,294%2018,295ZM105,263%20103,266%20104,267%2091,279%2093,278%2097,273%2098,274%20100,272%2099,271%20104,267%20105,265%20104,264ZM74,244%2076,247%2075,250%2077,255%2076,258%2077,257%2077,250%2076,249%2077,248%2075,246%2076,245ZM101,214%20105,215%20106,218%20107,218%20106,217%20107,216%20104,213ZM60,205%2063,208%2063,212%2065,219%2065,217%2066,216%2067,217%2064,215%2064,209%2063,207ZM103,187%2099,189%20100,191%20102,192%20101,193%20103,196%20102,197%20102,200%20103,199%20103,194%20101,191%20101,189%20102,188%20105,191%20106,203%20105,204%20104,202%20102,203%2098,200%2098,202%20104,204%20108,208%20107,207%20108,206%20107,207%20106,206%20106,200%20107,199%20106,200%20105,199%20105,191%20103,189%20104,188ZM50,187%2050,188%2053,188%2055,190%2055,198%2056,197%2056,191%2054,188ZM95,168%2095,170%2099,172%2098,173%20102,178%20107,182%20106,183%20107,183%20108,185%20106,188%20108,185%20106,180%2097,170%2098,168%2096,171ZM101,162%20105,166%20107,170%20108,170%20106,166ZM102,150%20101,149%2097,153%2098,152%2099,153ZM27,93%2029,97%2029,100%2030,100%2029,98%2032,97%2050,106%2053,110%2051,106%2044,103%2042,101%2033,98%2031,96%2029,97ZM10,90%2013,98%2020,104%2019,106%2021,105%2012,96%2011,93%2012,92%2016,95%2016,94%2013,93ZM97,49%2096,48%2093,50%2086,51%2085,52%2072,52%2084,53ZM96,30%2090,32%2081,33%2081,34%2091,32%2092,31%2096,31ZM85,22%2086,23%2085,24%2088,26%20101,26%20102,27%20100,28%20101,29%20102,27%20103,28%20104,27%20103,24%2095,25%2094,26%2089,26%2086,24%2087,22%2096,19%2095,18%2094,20%2093,19%2092,20%2089,20%2087,22%2086,21ZM100,0%2099,1%2098,0%2096,2%2092,2%2095,3%2093,5%2094,6%2093,7%2091,6%2088,10%2089,11%20101,10%20100,9%20101,8%2097,10%2092,10%2091,11%2090,9%2095,5%2094,4%2097,1%2098,2Z'/%3e%3c/svg%3e", Le = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20120%20474'%3e%3crect%20width='120'%20height='474'%20fill='%23fff9e9'/%3e%3cpath%20fill='%23fbfbfb'%20stroke='%23fbfbfb'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M59,441%2058,440%2052,443%2044,443%2043,442%2047,444%2054,444ZM79,429%2077,428%2073,431%2077,431%2079,430ZM42,406%2042,413%2044,419%2044,425%2051,421%2052,422%2054,421%2056,424%2059,425%2062,428%2063,428%2062,426%2064,422%2068,422%2073,424%2070,419%2068,418%2068,416%2066,413%2059,407%2054,405%2044,405ZM43,408%2050,405%2054,405%2058,408%2060,411%2053,413%2050,416%2046,416%2044,414ZM28,403%2026,405%2028,406%2029,404%2031,404%2032,406%2030,409%2027,410%2026,409%2025,410%2027,410%2033,415%2034,422%2035,423%2035,429%2031,433%2028,433%2027,434%2022,433%2024,437%2026,438%2031,435%2033,435%2038,439%2033,435%2033,433%2038,429%2040,425%2040,418%2038,414%2038,406%2034,404ZM62,389%2062,391%2063,392%2064,391%2066,393%2065,395%2067,394%2066,391%2064,389ZM6,356%206,363%207,360%2010,361%2016,369%2021,371%2025,375%2028,375%2037,379%2041,379%2044,381%2053,383%2050,383%2044,379%2038,378%2028,374%2023,370%2012,364%2011,361%2010,361ZM43,345%2039,351%2040,359%2042,361%2043,359%2045,362%2044,363%2045,362%2049,367%2054,369%2046,363%2043,358%2042,360%2039,354%2040,350%2042,348%2043,350%2045,347%2044,345ZM83,336%2079,332%2075,336%2071,338%2060,339%2056,341%2053,345%2051,346%2054,349%2054,356%2056,358%2062,358%2062,357%2056,352%2056,347%2060,343%2067,340%2075,340%2079,344%2080,343%2079,339ZM42,329%2042,336%2047,343%2044,339%2043,330ZM115,309%20115,310%20113,311%20114,312%20112,313%20114,314%20112,315%20110,318%20107,318%20108,324%20107,325%20106,324%20109,326%20109,328%20109,321%20111,317%20115,313ZM12,310%2014,310%2017,313%2022,314%2027,317%2026,316%2028,315%2029,318%2032,321%2034,321%2037,323%2042,321%2048,322%2053,330%2053,332%2055,335%2055,338%2061,335%2071,334%2076,330%2076,321%2071,314%2067,311%2066,309%2063,309%2056,306%2048,297%2047,297%2047,300%2046,301%2046,305%2048,309%2051,311%2054,310%2051,310%2048,308%2047,305%2050,301%2058,308%2057,312%2054,314%2049,314%2044,310%2043,306%2038,306%2032,309%2022,310%2021,311%2019,310%2018,311%2017,310ZM69,317%2073,321%2076,326%2074,332%2071,331%2065,332%2064,331%2064,323ZM119,285%20117,291%20111,298%20110,297%20106,299%20107,301%20103,303%20102,305%2099,304%20101,302%2097,305%2098,306%2097,308%2096,308%2095,306%2092,310%2081,312%2076,315%2078,314%2080,315%2078,318%2081,315%2099,307%20108,301%20115,295%20119,289ZM108,283%20109,282%20115,284%20115,283%20111,280%20110,280ZM86,259%2080,259%2073,266%2071,270%2071,289%2074,293%2076,304%2080,299%2082,292%2081,289%2078,287%2081,291%2081,293%2079,296%2075,297%2074,296%2074,287%2077,283%2080,283%2084,287%2086,293%2084,297%2087,295%2088,293%2089,284%2092,277%2094,276%2098,270%2095,268%2090,261ZM82,260%2088,267%2083,270%2079,271%2078,273%2075,275%2073,273%2073,269%2075,267%2075,265%2079,261ZM52,266%2050,264%2044,262%2038,258%2039,259%2037,260%2035,263%2034,261%2035,263%2034,264%2030,264%2028,266%2026,266%2024,264%2025,263%2023,260%2022,264%2019,267%2017,267%2014,264%2014,261%2013,261%2014,264%2013,267%2011,268%207,265%207,261%206,262%207,264%206,265%206,271%209,275%2013,273%2020,273%2024,277%2022,280%2015,285%2012,282%2012,279%2014,277%2020,277%2018,276%2012,277%209,282%209,287%2020,283%2026,283%2032,285%2043,283%2051,276%2052,274ZM50,267%2051,270%2049,275%2042,281%2038,282%2037,279%2039,277%2039,271%2041,268%2041,266%2042,265%2045,265%2048,267ZM27,250%2024,251%2019,256%2018,263%2022,254ZM88,246%2085,247%2082,255%2086,255%2092,258%2098,266%20100,267%20106,267%20107,268%20107,276%20105,280%20100,284%2097,288%20101,286%20107,279%20107,274%20108,273%20107,270%20111,267%20114,267%20114,262%20113,260%20112,260%20111,263%20108,266%20102,266%20100,265%2093,256%2093,253%2095,251%2094,250%2095,248%2092,248%2090,250%2086,250%2085,248%2088,247ZM119,250%20119,246%20112,241%20101,237%2095,237%2094,236%2093,237%2074,237%2073,238%2066,238%2060,240%2055,240%2051,243%2049,242%2043,242%2042,245%2049,245%2063,241%2069,241%2070,240%2082,239%2083,238%2084,239%2087,238%2091,238%2092,239%2093,238%2099,240%20102,239%20106,242%20108,242%20111,244%20114,244ZM29,249%2032,249%2035,247%2037,247%2039,254%2042,257%2046,258%2053,262%2055,266%2063,261%2062,258%2063,260%2061,262%2060,262%2058,259%2058,257%2060,254%2058,255%2051,255%2042,251%2039,248%2039,242%2043,236%2040,236%2038,238%2038,243%2034,248ZM16,211%2013,213%207,224%2011,221%2015,222%2017,224%2019,220%2017,221%2014,218%2015,214%2013,213%2016,212ZM47,196%2045,196%2037,206%2036,209%2025,218%2018,229%2017,237%2020,241%2027,245%2032,245%2033,244%2027,243%2023,240%2020,235%2021,228%2030,216%2044,201ZM80,197%2083,195%2091,195%2096,198%2090,194%2086,194ZM64,194%2062,199%2068,198%2072,201%2073,204%2073,209%2071,213%2071,217%2067,220%2063,220%2063,221%2067,223%2067,225%2065,227%2063,225%2063,229%2067,229%2068,228%2072,228%2072,220%2077,207%2075,200%2078,198%2077,199%2075,198%2072,199%2069,197%2067,194ZM63,185%2062,186%2061,185%2061,186%2057,189%2054,189%2049,191%2048,190%2042,191%2041,190%2040,191%2036,191%2035,190%2031,193%2027,194%2028,195%2025,196%2024,198%2021,197%2017,200%2016,199%2015,200%2017,201%2016,202%2017,203%2016,204%2014,203%209,209%207,209%207,217%2011,210%2025,198%2035,193%2043,193%2044,192%2047,193%2050,191%2057,190ZM117,181%20115,183%20115,187%20113,190%20114,191%20111,196%20112,197%20112,203%20111,204%20107,204%20108,205%20107,206%20103,206%20102,205%20102,201%20103,200%20102,197%20100,197%20101,199%20100,201%2097,202%2098,203%2098,206%2096,208%2091,204%2088,204%2087,203%2082,203%2081,204%2080,201%2083,199%2080,201%2080,210%2078,217%2076,220%2076,227%2078,230%2084,232%2093,232%2096,231%20108,223%20108,222%20119,212%20119,211%20116,209%20111,209%20107,211%20105,214%20108,211%20111,211%20114,214%20112,217%20108,218%20104,221%20101,218%20101,214%20103,210%20108,206%20111,206%20112,205%20113,192ZM77,219%2078,218%2083,219%2090,225%2091,224%2094,227%2091,230%2088,231%2081,230%2079,229%2076,225%2078,222ZM25,179%2046,178%2047,177%2050,177%2050,175%2043,177%2042,176%2041,177%2032,177%2031,176%2030,177%2029,175%2027,175%2028,178ZM69,168%2067,170%2066,169%2060,169%2061,170%2061,173%2066,171ZM92,166%2091,167%2088,165%2080,167%2081,169%2079,171%2077,169%2078,168%2075,170%2080,173%2084,168%2088,168%2089,167%2092,167ZM49,160%2047,163%2050,164%2053,168%2054,171%2054,176%2053,178%2055,175%2056,176%2055,179%2057,178%2057,169%2054,163ZM28,151%2033,155%2041,159%2040,156%2035,152ZM46,143%2042,147%2042,152%2045,159%2046,159%2048,152%2046,154%2042,152%2042,148ZM63,116%2060,113%2057,113%2056,114%2054,113%2042,119%2038,119%2037,120%2032,119%2030,125%2031,126%2031,129%2032,128%2033,129%2033,136%2029,139%2025,136%2024,133%2024,135%2021,140%2022,141%2020,143%2019,141%2016,142%2017,143%2015,144%2014,147%2015,150%2017,148%2027,148%2028,147%2029,148%2034,148%2035,147%2038,148%2039,145%2044,140%2047,139%2049,141%2049,150%2052,144%2056,142%2061,137%2065,129%2065,120%2063,118ZM17,144%2018,143%2021,145%2018,146ZM58,114%2061,115%2064,120%2064,128%2060,133%2058,132%2057,125%2050,119%2052,117%2057,116ZM119,111%20115,111%20112,113%20110,113%2095,121%2084,132%2079,139%2081,140%2083,139%2084,140%2084,137%2086,136%2088,143%2090,145%2095,146%2096,148%2098,148%20101,146%20101,145%2093,146%2089,143%2087,140%2087,135%2089,131%2096,123%20111,115%20119,113ZM60,99%2060,100%2062,101%2061,103%2059,103%2056,100%2056,98%2050,107%2047,109%2037,112%2034,112%2029,108%2030,102%2027,105%2027,108%2030,111%2030,114%2026,122%2027,131%2029,135%2029,132%2027,128%2027,121%2030,115%2033,114%2035,116%2039,116%2052,110%2057,110%2058,109%2060,110%2062,105%2062,100ZM87,88%2090,88%2091,87%2095,88%2098,92%2098,93%2095,95%2098,95%20103,97%20100,91%2097,88%2091,86ZM91,83%2095,83%20100,86%20106,80%20116,74%20117,72%20110,74%20107,73%20105,70%20102,71%2098,70%2098,73%2094,76%2092,75%2093,77%2094,76%2097,78%2095,82%2093,81%2092,82%2091,81ZM56,77%2056,83%2061,90%2066,93%2068,93%2071,95%2093,94%2083,90%2084,86%2089,83%2089,81%2087,80%2086,76%2085,76%2084,73%2082,72%2083,71%2080,72%2079,69%2076,68%2076,66%2069,71%2065,71%2060,73ZM65,72%2067,74%2067,78%2066,79%2066,85%2068,87%2067,89%2063,89%2057,82%2057,77ZM26,55%2012,68%209,74%207,75%207,78%2012,70%2026,57ZM47,68%2047,71%2053,75%2059,70%2071,66%2075,62%2075,60%2077,58%2079,58%2085,61%2087,61%2093,67%2094,71%2095,71%2092,64%2089,61%2084,58%2077,58%2073,55%2072,49%2068,49%2069,51%2071,52%2072,55%2067,62%2062,65%2055,65%2053,63%2051,63%2052,64%2052,68%2050,69%2049,66ZM28,48%2026,49%2031,59%2031,72%2029,74%2029,77%2024,83%2017,95%2015,101%2016,103%2017,103%2017,100%2033,73%2033,69%2034,68%2033,58ZM93,17%2095,15%2093,18%20101,26%20115,36%20115,35%20110,31%20109,28%20106,25%20101,22%2099,22ZM63,6%2053,15%2054,16%2048,21%2041,30%2036,34%2030,41%2018,47%2016,47%2015,45%2012,43%2013,46%2017,49%2031,42%2052,20%2055,15ZM44,6%2037,18%2030,25%2023,30%2021,30%2019,26%2019,29%2021,33%2024,32%2031,26%2042,11ZM71,4%2084,12%2088,9%2087,10%2086,9%2083,9ZM35,2%2032,8%2035,7%2035,4%2036,3ZM103,0%20101,0%2079,24%2071,30%2069,30%2066,32%2063,30%2061,21%2059,17%2062,25%2063,32%2066,33%2069,31%2071,31%2082,24ZM53,0%2055,7%2056,6%2054,0ZM30,0%2028,3%2020,7%2017,11%2022,6%2029,3%2030,1%2031,2ZM4,0%200,0%200,473%201,473%201,446%200,445%201,444%200,442%202,441%201,440%201,406%202,405%201,403%201,391%202,390%201,388%201,380%202,379%202,362%203,361%202,360%202,356%203,355%202,352%205,350%2012,358%2015,359%2022,351%2022,349%2020,351%2018,351%2017,350%2018,349%2017,350%2014,350%2013,349%2010,349%205,346%202,342%202,332%201,331%202,330%202,309%201,307%202,306%202,238%203,237%202,235%203,234%203,227%204,226%203,225%203,219%204,218%204,202%203,201%204,199%204,196%203,195%204,194%204,185%203,184%203,144%204,143%203,142%203,131%204,130%204,125%203,122%204,121%203,118%204,116%209,112%2010,113%2016,113%2024,120%2024,117%2015,109%2011,101%203,94%204,92%204,86%203,85%203,64%204,63%203,62%203,40%204,39%2012,39%2019,42%2021,41%2014,37%204,36%203,35%203,27%205,25%209,17%2011,18%2010,19%2011,18%2011,16%2010,16%205,21%203,18%203,14%204,13ZM17,351%2020,353%2015,359%2013,354Z'/%3e%3cpath%20fill='%23524e6b'%20stroke='%23524e6b'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M84,473%2085,472%2087,473%2088,472%2089,473%2093,473%2094,472%2095,473%2097,472%2098,473%20102,473%20103,472%20104,473%20105,472%20104,471%20101,472%2099,470%2096,470%2094,472%2091,471%2090,472%2089,471%2090,469%2093,470%2091,467%2089,469%2088,468%2089,470%2087,473%2086,472ZM46,462%2048,464%2046,466%2046,468%2047,467%2050,467%2051,468%2049,469%2051,470%2052,468%2053,470%2055,470%2056,467%2059,469%2060,467%2061,468%2060,467%2061,465%2066,467%2065,465%2067,464%2065,461%2067,459%2064,457%2061,459%2058,455%2055,457%2054,456%2056,453%2053,454%2051,457%2050,456%2052,458ZM63,464%2060,466%2057,465%2061,462ZM53,464%2055,462%2058,462%2059,463%2056,465ZM38,448%2039,449%2037,450%2040,449%2042,451%2041,452%2042,453%2039,455%2038,454%2037,456%2036,455%2036,453%2037,456%2040,455%2043,459%2042,457%2044,456%2044,454%2043,455%2042,453%2044,450%2043,451%2042,448%2041,449ZM102,439%20100,444%2098,445%2096,455%2099,458%20101,457%20102,458%20101,459%20103,458%20106,460%20107,459%20108,461%20110,460%20113,462%20114,460%20116,460%20115,459%20116,458%20114,456%20115,454%20117,453%20117,450%20116,449%20117,448%20116,447%20117,444%20113,443%20111,441%20112,442%20111,445%20110,443%20106,445%20105,444%20107,439%20105,444%20104,443%20101,444%20100,443ZM12,408%2011,411%208,414%207,413%206,414%209,413%2011,415%2010,417%208,417%2010,417%2012,420%209,423%209,426%207,427%205,425%207,424%207,422%206,424%204,423%206,426%204,427%204,429%207,431%205,433%207,434%205,435%207,439%206,440%207,439%2010,440%2011,442%2015,445%2014,448%2017,449%2017,454%2016,455%2017,456%2014,461%2016,459%2017,460%2016,463%2017,466%2019,467%2017,469%2020,467%2021,468%2020,469%2022,468%2023,469%2022,470%2023,469%2025,470%2024,472%2025,471%2026,473%2030,473%2031,472%2028,469%2029,467%2027,464%2027,454%2026,453%2028,451%2028,448%2029,447%2028,446%2030,444%2029,443%2031,442%2031,440%2033,438%2032,438%2031,440%2029,441%2028,440%2026,442%2023,441%2018,431%2016,430%2019,429%2020,427%2017,425%2020,423%2021,425%2020,422%2021,421%2022,422%2022,421%2013,418%2015,416%2019,416%2020,418%2021,418%2019,414%2022,413%2022,410%2022,413%2021,414%2017,412%2014,414%2012,411%2013,410%2014,411%2015,409%2017,410%2016,410%2015,408%2014,409ZM6,432%207,431%2010,433%2011,432%2012,434%209,435%207,434ZM9,428%2010,431%208,432%207,431ZM12,420%2015,419%2017,421%2014,423ZM81,400%2086,402%2085,403%2086,405%2084,407%2086,406%2087,407%2086,408%2087,407%2088,408%2088,411%2089,411%2091,414%2092,414%2091,413%2092,411%2089,411%2088,410%2089,409%2092,409%2093,408%2094,410%2095,409%2097,410%2097,412%2099,413%2098,414%20102,417%20100,419%20100,422%2099,423%20100,425%2099,423%20101,421%20100,419%20103,417%20106,418%20106,416%20105,417%20103,414%20105,413%20104,412%20105,410%20103,409%20104,408%20101,411%2099,406%2097,407%2095,405%2093,406%2089,403%2089,400%2087,399%2089,401%2087,403%2084,399ZM102,398%20104,400%20104,402%20107,406%20106,407%20108,409%20109,408%20110,409%20113,409%20118,413%20118,412%20115,411%20117,410%20117,407%20115,406%20114,407%20113,406%20114,403%20113,404%20109,401%20110,400%20107,405%20105,401%20107,399%20106,398%20104,399ZM112,404%20114,408%20113,409%20111,408%20111,405ZM86,397%2084,394%2085,393%2081,396%2082,397ZM8,395%207,398%209,397%2014,399%2013,400%2010,400%208,403%207,402%208,403%207,405%208,403%209,405%2010,404%2012,405%208,403%209,402%2014,402%2015,403%2016,402%2018,403%2021,401%2022,403%2024,402%2023,399%2021,400%2020,402%2019,401%2019,398%2018,397%2019,395%2017,394%2015,397%2013,393%2014,395%2013,396%2011,394%2012,395%2011,397%2010,396%209,397ZM72,392%2072,393%2070,394%2070,399%2068,401%2070,399%2072,403%2069,405%2066,402%2065,403%2066,402%2067,405%2063,407%2065,407%2069,413%2072,415%2071,416%2073,418%2072,421%2073,420%2077,424%2080,424%2081,425%2079,426%2084,427%2086,429%2082,433%2081,432%2078,433%2080,439%2085,442%2083,443%2084,445%2088,448%2088,450%2088,448%2085,445%2087,444%2086,441%2089,437%2089,430%2087,431%2084,425%2086,424%2088,428%2087,426%2088,425%2085,423%2087,422%2086,420%2083,418%2083,415%2076,406%2075,402%2072,398%2073,397%2070,396ZM47,394%2045,395%2043,392%2042,392%2043,393%2041,395%2039,394%2038,395%2037,394%2039,396%2036,401%2037,398%2040,396%2041,399%2045,402ZM43,395%2044,394%2046,397%2045,398ZM25,388%2025,389%2027,390%2025,392%2025,393%2026,392%2027,394%2025,395%2027,394%2028,395%2027,398%2029,399%2026,400%2025,397%2024,397%2027,401%2029,400%2028,397%2030,394%2029,395%2026,392%2026,391%2029,389%2027,388%2026,389ZM118,385%20117,388%20116,386%20116,390%20117,391%20116,393%20117,395%20118,395%20118,391%20116,390%20118,389%20117,388ZM110,364%20111,368%20110,369%20109,368%20107,371%20105,369%20103,372%20104,374%20106,375%20104,376%20105,377%20104,378%20104,381%20105,380%20104,379%20107,377%20108,378%20107,379%20108,378%20110,380%20111,384%20110,385%20107,385%20103,383%20108,386%20108,387%20106,388%20108,390%20107,389%20109,387%20110,388%20110,391%20112,392%20114,395%20112,392%20113,391%20112,388%20113,387%20112,386%20113,384%20115,383%20114,382%20115,380%20113,377%20114,376%20116,377%20117,374%20119,375%20119,371%20118,370%20119,369%20119,366%20113,365%20113,366%20111,367ZM111,379%20112,378%20115,380%20112,381ZM110,375%20112,377%20111,379%20108,377ZM113,370%20116,369%20117,370%20116,371%20117,370%20119,372%20118,373%20115,373ZM109,369%20112,372%20110,373%20111,374%20109,376%20108,373%20106,374%20105,373%20105,371%20106,370%20108,371ZM114,345%20116,347%20115,348%20117,349%20116,351%20114,351%20117,351%20118,352%20116,354%20113,355%20112,354%20115,355%20114,357%20112,357%20112,358%20113,357%20115,359%20113,362%20114,363%20115,362%20117,363%20118,362%20119,363%20118,362%20119,359%20117,353%20118,352%20117,349%20118,347%20115,346%20117,345ZM118,358%20119,360%20117,363%20115,360ZM16,287%2012,288%2011,291%208,290%207,288%206,289%209,290%2010,292%2012,290%2014,290%2015,291%2012,293%2013,294%2014,292%2015,293%2016,289%2014,288ZM96,242%2095,244%2097,244%2099,246%2097,248%2098,247%2099,248%2098,247%2099,246%20103,246%20104,247%20101,248%20104,252%20103,253%20104,254%20103,255%20100,254%20101,255%2099,256%2098,259%2097,257%2095,256%2094,254%20100,263%20103,262%20104,264%20106,265%20105,263%20107,262%20105,260%20107,258%20105,256%20105,254%20106,253%20109,253%20111,256%20110,258%20111,259%20110,257%20112,256%20114,258%20113,259%20116,261%20116,264%20117,265%20117,268%20115,270%20109,271%20109,274%20110,273%20112,274%20111,276%20109,276%20112,278%20111,279%20113,278%20114,279%20113,280%20114,279%20117,280%20118,278%20119,279%20119,255%20117,252%20113,250%20113,248%20104,244%20103,246%20101,246%20100,245%20101,243%2098,242%2099,243%2098,245%2095,243ZM99,259%20100,258%20103,262%20101,263ZM119,215%20118,217%20110,224%20109,223%20108,224%20109,225%20106,228%20104,227%20103,228%20104,230%2099,233%20100,236%20102,234%20104,237%20105,235%20112,240%20113,239%20116,242%20116,240%20118,239%20119,242%20118,243%20119,242%20119,228%20118,227%20119,226%20119,217%20118,216ZM112,231%20113,230%20116,231%20114,233ZM105,229%20106,231%20104,233%20103,231ZM6,207%205,208%206,209%205,210%205,218%206,217%205,215%206,214%205,212%206,211ZM118,186%20117,188%20116,187%20117,190%20115,192%20116,194%20114,196%20114,199%20116,201%20114,204%20115,205%20114,206%20116,207%20117,206%20118,208%20119,208%20119,196%20118,195%20119,194%20119,187ZM22,160%2023,160%2024,162%2025,159%2028,163%2027,165%2025,166%2026,167%2023,168%2025,169%2027,165%2028,166%2027,164%2029,162%2031,162%2032,163%2031,164%2033,162%2035,162%2036,163%2033,165%2035,164%2036,165%2037,164%2038,166%2041,164%2042,162%2043,162%2044,164%2043,162%2039,161%2038,162%2039,163%2037,164%2035,160%2036,159%2035,160%2031,160%2030,159%2029,160%2028,158%2027,160%2025,159ZM15,156%2016,155%2017,157%2020,157%2021,156%2022,157%2024,156%2026,157%2024,155%2021,155%2019,152%2022,151%2019,150%2020,151%2018,152%2019,155%2018,156%2016,155ZM69,144%2064,149%2060,150%2060,152%2058,153%2059,155%2058,156%2061,153%2062,154%2063,153%2062,152%2064,150%2065,153%2066,151%2065,148ZM81,132%2079,130%2076,134%2074,131%2076,135%2075,136%2079,132%2080,133ZM119,118%20115,117%20112,120%20110,119%20111,121%20110,123%20106,121%20104,122%20101,127%2099,125%20100,124%2099,123%20100,124%2098,127%2096,125%2094,127%2095,128%2094,130%2095,128%2096,131%2095,132%2092,132%2093,133%2093,135%2091,137%2093,138%2092,140%2094,141%2095,140%2096,142%2097,141%2099,142%2098,141%2099,140%2097,138%2098,137%20101,137%20102,138%20101,140%20102,138%20104,139%20105,138%20108,138%20109,135%20110,137%20113,134%20114,137%20117,136%20119,134%20119,129%20118,128%20119,127%20118,126%20119,125%20118,124%20119,123%20118,121ZM108,127%20110,130%20108,131%20110,134%20108,136%20106,134%20107,133%20105,129ZM116,119%20117,122%20114,123%20113,121ZM100,99%2099,100%2098,98%2097,99%2093,97%2090,97%2091,98%2090,99%2087,98%2083,102%2079,101%2078,103%2075,102%2076,104%2074,105%2075,106%2073,108%2071,108%2071,112%2070,113%2069,112%2070,113%2068,114%2070,113%2071,115%2071,114%2073,113%2075,115%2073,116%2076,115%2077,116%2074,119%2075,118%2076,119%2078,117%2079,118%2078,117%2079,116%2082,118%2079,122%2077,121%2078,122%2077,124%2075,124%2077,127%2075,129%2076,130%2077,127%2076,126%2078,124%2081,128%2083,129%2082,130%2087,124%2087,121%2085,120%2084,121%2083,118%2086,117%2085,116%2088,114%2086,115%2085,114%2084,115%2081,113%2081,111%2083,108%2085,110%2086,109%2085,109%2083,106%2084,105%2087,105%2088,102%2090,103%2091,102%2092,103%2091,102%2095,100%2098,101ZM78,111%2079,113%2076,115%2075,114ZM35,92%2036,93%2035,94%2036,96%2034,97%2035,99%2036,98%2039,99%2041,97%2043,97%2041,96%2039,99%2038,97%2036,96%2037,92ZM18,85%2017,84%2018,85%2016,87%2014,85%2014,86%2011,88%2012,89%2013,87%2014,90%2015,90%2014,88%2015,87%2018,88%2017,87ZM108,82%20106,85%20101,89%20104,93%20103,94%20104,95%20105,93%20104,93%20103,91%20105,90%20107,86%20108,87%20106,85%20108,84ZM9,79%207,82%208,83%205,84%205,88%205,85%206,84%207,85%207,91%208,93%207,94%205,92%207,94%208,93%209,94%209,97%209,95%2010,94%2011,95%2011,98%2013,101%2012,95%2013,94%2014,96%2015,94%2016,95%2013,94%2014,92%2012,93%2010,92%209,93%207,91%209,85%207,84%208,83%207,82ZM36,70%2035,76%2032,80%2033,82%2035,83%2033,85%2031,85%2030,84%2031,82%2030,83%2029,82%2030,84%2026,89%2028,90%2024,93%2027,94%2028,93%2029,95%2029,93%2031,91%2032,92%2031,97%2027,101%2030,98%2032,99%2030,98%2033,95%2032,96%2031,94%2035,89%2040,92%2038,95%2044,93%2045,96%2046,95%2047,96%2049,95%2050,97%2052,96%2054,98%2053,97%2055,95%2058,97%2059,94%2060,96%2065,100%2065,102%2065,100%2062,97%2063,96%2065,97%2065,95%2061,94%2060,92%2059,94%2057,91%2058,90%2053,84%2053,79%2052,80%2049,78%2048,81%2046,78%2045,79%2044,78%2042,81%2040,79%2045,73%2047,75%2045,73%2046,72%2043,75%2038,77%2038,80%2037,81%2035,78%2037,75%2036,73%2038,72%2037,72ZM52,90%2054,92%2052,94%2050,92ZM43,88%2044,89%2043,92%2042,91ZM48,88%2050,86%2051,87%2053,86%2054,87%2054,90%2051,91ZM44,87%2047,85%2048,86%2047,88ZM35,83%2037,87%2036,88%2033,87%2033,85ZM49,83%2050,80%2053,81%2051,84ZM41,80%2042,83%2043,83%2042,82%2043,80%2046,83%2045,85%2043,86%2042,85%2041,87%2042,88%2041,89%2043,92%2041,93%2038,89%2039,88%2039,82ZM38,80%2039,82%2036,84%2034,82ZM6,45%208,48%207,50%206,49%207,51%206,52%206,57%207,56%206,54%207,51%209,53%209,55%2011,53%2012,54%2011,53%2012,51%2014,53%2012,51%2011,47%209,46%208,48ZM7,50%208,49%2011,49%2012,51%209,52ZM112,48%20109,47%20108,48%20107,47%20108,45%20107,43%20106,45%20104,45%20102,47%20100,46%20100,44%20100,46%2099,47%2098,46%2099,47%2098,48%2099,48%20100,46%20103,49%20104,46%20106,45%20107,46%20106,47%20107,50%20108,49%20110,50%20109,49ZM13,21%2011,22%209,25%2014,33%2012,35%2010,34%2015,36%2016,35%2017,37%2020,38%2019,36%2018,37%2016,35%2015,36%2014,35%2015,32%2018,34%2014,26%2014,24%2013,25%2012,24ZM38,58%2040,59%2039,61%2041,58%2044,59%2046,61%2046,63%2047,61%2048,62%2049,60%2045,57%2048,55%2049,57%2050,56%2055,56%2057,53%2059,56%2060,55%2061,56%2060,58%2061,58%2061,55%2063,54%2060,55%2059,53%2062,48%2061,47%2062,46%2064,47%2065,46%2071,46%2072,47%2074,46%2075,47%2076,46%2077,48%2079,48%2081,50%2081,53%2083,50%2085,50%2087,46%2090,45%2089,44%2091,43%2091,38%2092,37%2091,35%2092,32%2091,33%2085,33%2084,31%2083,32%2081,30%2082,27%2080,29%2078,28%2079,30%2077,31%2077,34%2076,35%2073,33%2074,34%2073,35%2071,34%2069,36%2064,36%2062,38%2059,34%2060,31%2059,33%2058,32%2059,28%2058,29%2057,28%2058,26%2056,25%2057,23%2058,24%2057,22%2054,23%2053,22%2055,21%2053,20%2052,21%2054,23%2052,24%2047,29%2045,33%2040,37%2042,37%2044,40%2043,41%2040,40%2040,41%2042,42%2041,44%2044,40%2048,41%2048,40%2050,39%2052,42%2050,46%2051,48%2049,49%2050,50%2041,57%2040,56%2040,57ZM54,52%2055,51%2058,52%2057,53ZM83,44%2086,47%2084,49%2082,48%2083,47%2082,48%2081,47ZM64,44%2066,43%2069,45%2066,46ZM70,43%2071,42%2074,45%2072,46ZM68,39%2069,42%2067,44%2066,43%2066,40ZM80,15%2077,16%2078,18%2077,19%2075,18%2076,19%2076,22%2077,19%2081,16ZM67,13%2068,15%2067,17%2064,17%2063,16%2065,18%2064,20%2065,19%2068,22%2066,26%2067,27%2068,25%2072,25%2074,21%2072,22%2070,21%2070,19ZM69,18%2070,20%2068,22%2067,20ZM20,25%2021,24%2023,26%2027,23%2029,20%2033,17%2034,14%2038,11%2035,12%2034,14%2030,13%2032,14%2030,16%2027,15%2028,13%2026,11%2025,12%2024,11%2021,11%2022,12%2018,15%2022,22ZM66,10%2061,13%2065,14ZM101,7%20102,9%20106,12%20106,14%20111,18%20114,17%20116,21%20115,24%20117,24%20118,25%20117,26%20119,25%20117,22%20119,19%20118,13%20114,11%20110,12%20109,9%20108,11%20107,9%20105,10ZM51,6%2048,6%2048,8%2046,9%2047,11%2046,12%2045,11%2046,12%2043,14%2044,15%2041,19%2043,22%2047,18%2044,21%2043,19%2048,14%2050,14%2053,10Z'/%3e%3cpath%20fill='%23676683'%20stroke='%23676683'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M106,466%20107,467%20105,468%20105,471%20106,472%20105,473%20117,473%20117,470%20115,468ZM60,459%2063,457%2064,458%2065,457%2068,459%2066,461%2068,464%2066,465%2066,466%2067,466%2072,460%2070,460%2068,457%2065,457%2064,458%2061,457ZM4,454%206,455%206,456%204,457%206,459%205,460%207,461%204,462%205,463%205,466%204,467%207,469%208,472%2010,473%2013,472%2014,473%2015,472%2016,473%2020,473%2018,472%2017,473%2014,468%2015,466%2010,463%2011,461%2010,462%209,461%2010,455%209,457%207,455%207,453ZM6,465%207,464%209,467%207,468ZM57,450%2053,451%2051,456%2052,454%2054,453%2056,450%2057,451ZM14,447%2016,449%2015,450%2015,457%2016,458%2015,457%2016,456%2015,455%2016,454%2016,449%2015,448%2016,447%2015,448ZM41,446%2038,447%2039,450%2037,451%2037,455%2036,456%2036,461%2038,466%2041,464%2043,457%2041,458%2040,456%2038,456%2037,454%2038,453%2039,454%2042,452%2043,454%2044,453%2038,449%2040,447%2041,448%2042,447ZM100,442%20103,444%20102,443%20103,442%20106,444%20110,442%20111,444%20111,442%20108,440%20107,441%20106,439%20103,439%20101,443ZM106,440%20107,441%20106,444%20105,443ZM4,430%205,431%204,434%207,433%2011,434%2011,433%2010,434%207,432%209,431%209,429%207,432%205,430%206,429ZM87,397%2087,398%2090,400%2090,403%2095,404%2097,406%2099,405%20101,407%20101,410%20103,408%20104,409%20106,406%20101,398%20102,397%20104,398%20105,397%20103,397%20101,395%20101,398%20102,399%20100,401%20101,400%20103,401%20102,402%20103,402%20105,405%20104,407%2099,404%2098,405%2094,404%2093,402%2091,401%2092,400%2091,399%2092,397%2090,397%2089,399%2088,397ZM69,388%2068,390%2070,391%2069,392%2072,394%2071,396%2072,396%2071,395%2072,394%2070,392%2071,389ZM81,387%2080,389%2082,393%2081,395%2082,394%2083,395%2082,393%2086,391ZM6,386%205,387%206,390%205,391%205,394%206,395%204,398%204,403%206,406%204,408%205,409%204,410%204,414%205,415%204,416%205,419%204,422%206,423%207,421%208,424%205,426%204,425%204,426%206,425%208,426%208,423%2011,420%2010,418%207,417%2010,416%208,413%2010,411%2011,413%2010,409%2012,407%2014,408%2015,407%2016,408%2014,412%2013,411%2014,413%2013,414%2014,415%2013,414%2014,413%2016,414%2015,412%2017,411%2021,413%2020,415%2022,417%2021,419%2020,419%2019,417%2015,417%2014,418%2020,419%2023,421%2022,423%2021,422%2019,425%2013,428%2018,425%2020,426%2020,424%2024,422%2027,424%2024,425%2027,425%2028,426%2030,425%2031,426%2030,420%2029,422%2027,421%2030,417%2029,418%2026,417%2027,418%2027,421%2026,422%2022,420%2022,417%2020,414%2021,413%2020,410%2024,407%2023,404%2023,406%2022,407%2021,406%2020,400%2023,398%2025,402%2026,401%2025,400%2029,398%2031,401%2034,400%2035,402%2035,400%2037,397%2038,398%2037,401%2038,403%2039,402%2044,402%2043,402%2042,400%2040,399%2040,397%2037,395%2039,393%2041,394%2042,391%2035,389%2034,390%2030,388%2030,391%2029,392%2028,390%2027,391%2024,389%2024,386%2019,386%2018,385%2017,386%2014,386%2013,385%2012,388%2010,386%2011,385%209,387ZM5,414%207,412%209,414%208,415ZM13,406%2015,404%2018,405%2016,407ZM7,406%209,403%2012,404%2010,405%209,407ZM23,397%2025,396%2026,399%2025,400ZM32,397%2034,395%2036,396%2035,398ZM15,395%2016,394%2017,395%2019,394%2020,396%2017,398ZM7,395%208,394%209,396%2010,395%2011,396%2012,394%2013,395%2014,393%2015,394%2014,397%2015,398%2016,397%2018,399%2019,397%2021,402%2018,404%2016,403%2015,404%2014,403%209,403%208,402%209,398%207,397ZM27,392%2029,394%2030,393%2031,394%2028,399%2026,398%2027,397%2026,394ZM26,390%2027,392%2025,394%2024,392ZM13,391%2014,390%2017,391%2016,392ZM31,382%2034,384%2036,383%2037,384%2036,385%2037,384%2039,387%2040,386%2039,387%2038,385%2041,384%2042,386%2045,387%2047,390%2051,393%2050,393%2046,388%2047,386%2044,387%2043,385%2039,383%2037,384%2034,382ZM6,379%209,381%2011,378%2012,379%2014,378%2016,379%2014,378%2017,377%2020,380%2018,382%2016,381%2015,383%2016,382%2023,382%2020,381%2022,379%2027,382%2025,379%2026,378%2024,380%2023,378%2020,380%2019,379%2021,377%2020,376%2019,377%2017,375%2015,376%2012,375%2013,377%2011,378%209,374%207,374ZM5,367%207,372%206,371%209,369ZM59,361%2058,362%2056,361%2058,362%2053,364%2054,365%2055,364%2058,364ZM31,363%2032,364%2031,366%2034,366%2032,365%2034,364%2033,363%2035,362%2037,366%2034,368%2035,369%2034,371%2035,369%2036,370%2038,368%2041,372%2041,371%2043,370%2044,372%2047,374%2047,372%2046,373%2043,369%2040,368%2042,367%2039,366%2038,367%2037,366%2038,364%2036,361%2037,359%2036,360%2035,359%2036,360%2032,364ZM33,351%2031,354%2033,357%2030,358%2029,356%2028,356%2029,357%2028,358%2031,358%2032,360%2033,360%2032,358%2035,356%2036,357%2035,356%2036,355%2033,354ZM90,348%2080,347%2080,348%2076,351%2073,350%2074,351%2071,352%2072,354%2070,358%2069,357%2063,362%2062,361%2063,362%2058,366%2058,367%2059,366%2061,367%2061,370%2060,371%2061,373%2062,371%2063,372%2062,375%2063,376%2062,377%2063,379%2063,384%2066,387%2071,385%2071,381%2072,380%2071,378%2072,377%2073,378%2073,375%2076,370%2078,369%2077,368%2078,367%2075,364%2078,363%2080,365%2079,364%2082,363%2084,359%2083,358%2085,356%2086,357%2085,356%2088,354%2087,353%2090,351%2093,352%2092,351%2089,352%2088,351ZM81,348%2082,349%2081,352%2080,351ZM119,335%20116,337%20115,341%20112,342%20114,344%20117,344%20118,345%20115,347%20114,346%20112,348%20110,345%20112,349%20111,350%20109,348%20110,349%20109,350%20111,352%20109,355%20108,354%20109,355%20109,360%20108,361%20109,363%20108,364%20107,363%20104,364%20110,363%20112,365%20110,368%20113,364%20112,362%20114,359%20111,359%20110,358%20112,356%20114,356%20116,358%20112,352%20115,349%20116,350%20117,348%20119,350%20119,352%20118,353%20115,352%20115,353%20117,352%20118,353%20119,352%20119,346%20118,345%20119,343%20117,342%20119,340ZM114,348%20116,346%20119,347%20118,349%20117,348%20116,349ZM36,334%2035,332%2034,334%2029,334%2027,335%2026,337%2022,334%2021,336%2019,336%2018,334%2015,333%2014,335%2016,333%2018,336%2016,339%2019,340%2015,342%2012,342%2011,341%2010,342%209,341%2010,343%209,345%2011,343%2013,343%2014,344%2013,345%2016,345%2017,344%2022,346%2024,345%2022,344%2025,342%2026,343%2027,341%2028,342%2029,341%2028,340%2029,339%2028,338%2029,336%2031,338%2032,335%2035,333ZM17,343%2018,342%2022,344%2021,345%2018,345ZM19,340%2020,337%2023,339%2020,341ZM25,336%2027,338%2026,340%2023,338ZM8,330%207,332%208,332%209,334%207,335%207,337%2010,336%2012,338%2011,339%2014,340%2014,339%2011,337%2012,336%209,334%2010,332%207,331ZM115,318%20117,318%20114,319%20112,324%20113,327%20117,325%20119,328%20118,329%20115,328%20116,329%20114,330%20119,331%20119,326%20117,325%20118,322%20119,324%20118,321%20119,319%20118,321%20117,320%20115,321%20114,320ZM116,321%20117,323%20115,325%20113,323ZM119,296%20117,296%20117,297%20115,298%20110,304%20108,304%20106,307%20105,306%20106,307%20105,309%20103,308%20102,310%20100,309%20101,310%20100,311%2098,310%20101,312%20100,313%20101,314%20102,313%20105,314%20104,314%20103,312%20104,311%20107,312%20107,310%20112,307%20112,306%20116,303%20114,304%20111,303%20115,300%20117,301%20118,300%20117,299%20119,298ZM108,305%20111,304%20112,306%20111,307ZM113,288%20111,286%20110,286%20109,288%20108,286%20105,287%20106,288%20104,289%20103,292%20105,291%20106,293%20107,293%20108,291%20109,292%20110,290ZM106,287%20107,286%20111,289%20109,291%20107,291%20106,290%20107,289ZM5,291%206,293%205,294%205,298%206,299%205,300%205,304%206,304%207,302%208,304%2010,303%2011,305%209,306%2012,307%2014,306%2015,309%2016,307%2017,308%2021,308%2022,307%2024,308%2027,305%2028,307%2036,303%2037,304%2040,301%2041,302%2040,301%2043,296%2044,298%2044,295%2041,298%2040,297%2041,295%2037,297%2035,296%2032,297%2031,296%2033,295%2032,294%2031,295%2029,291%2030,290%2031,291%2032,289%2034,289%2037,294%2040,292%2039,291%2037,294%2036,293%2037,291%2035,290%2036,289%2039,289%2039,288%2035,290%2033,288%2034,287%2033,288%2031,287%2032,288%2030,289%2029,287%2025,288%2024,287%2025,286%2024,287%2023,286%2015,288%2017,289%2015,294%2013,292%2014,291%2012,291%2011,289%209,291%206,290ZM18,304%2019,303%2024,305%2023,306%2019,306ZM34,301%2036,300%2037,302%2035,303ZM13,299%2016,302%2015,305%2013,304%2014,303%2013,302%2012,303%2011,302ZM40,196%2036,197%2035,199%2032,196%2034,198%2031,200%2029,199%2030,200%2029,201%2027,200%2028,201%2026,202%2022,208%2019,207%2021,209%2021,210%2019,211%2022,212%2023,210%2026,211%2030,207%2032,207%2031,206%2033,205%2036,201%2038,200%2040,201%2039,200ZM80,187%2079,188%2075,188%2076,189%2075,192%2077,194%2076,195%2073,195%2077,195%2078,192%2079,194%2078,189ZM89,173%2085,176%2085,177%2092,182%2093,179%2090,180%2087,178%2087,176ZM43,163%2038,167%2037,165%2036,166%2035,165%2034,166%2032,165%2035,163%2032,164%2029,163%2028,164%2025,161%2028,157%2029,159%2030,158%2031,159%2035,159%2037,161%2037,163%2039,162%2038,160%2036,160%2029,156%2024,151%2023,151%2022,153%2020,152%2021,154%2024,154%2027,157%2026,158%2024,157%2023,158%2021,157%2020,158%2017,158%2016,156%2018,155%2017,152%2018,153%2017,154%2011,155%208,159%207,158%208,159%206,160%208,161%206,162%206,165%207,164%208,166%206,167%208,166%209,169%206,171%206,173%207,171%209,174%209,176%207,178%206,175%205,190%207,192%205,193%206,195%205,196%2013,193%2014,194%2015,192%2019,194%2018,193%2019,192%2023,191%2025,189%2028,190%2027,189%2028,188%2030,189%2029,188%2034,184%2033,185%2032,184%2033,182%2029,182%2030,183%2029,185%2027,182%2026,183%2025,182%2024,184%2025,186%2023,187%2021,183%2021,180%2022,179%2020,181%2018,180%2016,183%2014,184%2013,182%2015,178%2016,179%2016,176%2014,172%2012,171%2013,168%2016,167%2017,168%2016,170%2017,171%2016,170%2019,169%2020,170%2019,171%2020,170%2020,166%2023,164%2024,167%2026,168%2024,166%2025,165%2029,168%2030,166%2032,168%2033,166%2034,168%2038,169%2043,166%2045,166ZM15,184%2016,183%2019,184%2018,185ZM10,183%2011,184%2010,187%209,186ZM9,178%2010,177%2012,180%2011,181ZM23,158%2026,159%2024,163%2023,161%2021,160ZM57,160%2058,161%2057,162%2060,159%2061,160%2060,163%2061,162%2063,164%2062,163%2063,162%2068,162%2069,163%2067,164%2068,165%2069,163%2070,164%2072,162%2073,164%2075,163%2076,164%2076,161%2077,160%2080,164%2083,159%2085,162%2083,163%2088,162%2092,164%2093,163%2098,165%20101,164%20102,166%20105,168%20108,167%20109,169%20112,167%20114,170%20113,169%20114,165%20115,164%20116,165%20116,163%20112,161%20112,162%20110,163%20113,162%20114,164%20111,165%20112,166%20111,168%20109,168%20108,167%20109,165%20106,164%20107,161%20106,160%20104,163%20103,162%20100,163%2098,161%2098,158%2098,162%2097,163%2094,159%2091,160%2090,159%2087,159%2086,158%2087,157%2085,154%2085,149%2082,148%2082,146%2084,145%2080,145%2081,146%2080,147%2078,146%2078,144%2080,143%2078,144%2076,143%2071,147%2070,149%2067,149%2066,153%2062,155%2060,159ZM102,166%20103,165%20106,165%20107,166%20106,167%20103,167ZM75,160%2076,162%2074,164%2073,162ZM60,159%2062,158%2063,161%2062,162ZM77,157%2078,158%2076,161%2075,158ZM66,154%2068,157%2065,160%2063,156ZM73,151%2074,150%2077,151%2076,152ZM82,149%2085,150%2085,154%2084,155%2083,152%2082,154%2081,153%2081,150ZM69,150%2070,149%2073,149%2074,152%2071,153ZM113,128%20112,128%20113,129%20112,130%20110,129%20109,130%20108,128%20106,129%20107,131%20106,133%20109,136%20108,139%20105,139%20104,140%20101,138%2098,138%20100,140%2096,143%2094,140%2092,141%2091,140%2092,138%2091,138%2090,140%2091,141%2090,142%2092,144%20110,138%20112,139%20113,138%20114,139%20113,135%20110,138%20108,135%20109,134%20107,131%20108,130%20110,131%20112,130ZM89,97%2086,98%2084,97%2083,99%2080,98%2079,100%2078,99%2075,100%2074,98%2072,101%2070,98%2068,97%2067,98%2066,96%2065,98%2063,97%2064,98%2063,99%2064,98%2066,100%2065,103%2066,105%2064,108%2063,114%2063,111%2065,110%2066,111%2064,116%2065,115%2067,117%2066,120%2067,119%2068,120%2070,126%2068,128%2069,129%2068,131%2069,135%2065,138%2064,137%2066,139%2064,142%2062,140%2056,145%2057,144%2059,147%2060,146%2061,147%2060,149%2061,149%2062,151%2060,153%2059,151%2060,153%2059,154%2062,151%2061,149%2062,148%2064,148%2069,143%2074,141%2072,140%2074,138%2076,140%2076,138%2083,128%2081,129%2078,125%2076,127%2074,124%2077,123%2081,118%2079,117%2076,120%2074,118%2076,116%2070,112%2070,108%2074,106%2073,105%2075,104%2076,102%2078,102%2079,100%2083,101%2087,97%2090,98ZM62,140%2063,143%2060,145%2059,143ZM68,139%2070,141%2067,143%2066,145%2065,144%2065,141ZM73,136%2074,138%2072,140%2071,138ZM79,129%2081,131%2076,136%2074,133%2075,132%2076,133ZM76,127%2077,128%2076,131%2074,129ZM64,109%2065,108%2068,108%2069,109%2066,111ZM66,99%2067,98%2070,101%2068,102ZM50,87%2049,88%2052,91%2051,92%2052,93%2053,92%2052,91%2053,90%2053,87%2052,88ZM23,64%2024,65%2021,69%2019,67%2020,66%2015,71%2013,77%2012,78%2011,77%207,83%2010,85%207,93%205,94%208,96%207,95%208,94%207,93%208,91%209,92%2010,91%2011,92%2014,91%2015,92%2013,95%2013,98%2013,95%2019,86%2016,89%2015,88%2016,90%2015,91%2013,90%2013,88%2012,90%2010,88%2013,86%2014,84%2016,86%2021,83%2024,79%2025,74%2023,73%2025,72%2023,71%2023,66%2024,65ZM18,79%2019,82%2018,83%2015,83%2014,82ZM16,72%2018,75%2016,78%2014,74ZM19,67%2021,70%2019,72%2018,71%2018,68ZM45,59%2042,60%2039,57%2037,57%2037,65%2038,66%2037,68%2038,70%2037,71%2039,72%2037,73%2038,75%2036,78%2035,77%2038,81%2033,83%2032,82%2033,80%2031,84%2034,85%2034,87%2036,87%2035,84%2038,82%2039,80%2038,81%2037,80%2037,77%2039,76%2040,77%2039,78%2040,77%2042,80%2040,82%2040,88%2037,89%2038,88%2040,91%2039,92%2035,90%2032,94%2031,92%2029,96%2027,93%2022,97%2021,102%2019,105%2020,104%2022,105%2018,110%2017,109%2018,110%2019,109%2021,110%2022,112%2023,111%2024,112%2024,108%2021,106%2023,105%2023,102%2024,101%2026,102%2030,97%2030,94%2031,93%2033,96%2032,97%2038,96%2040,99%2038,102%2033,105%2033,106%2036,107%2036,108%2033,110%2034,109%2035,110%2038,107%2040,108%2041,106%2047,105%2046,104%2048,101%2047,102%2046,99%2044,100%2043,98%2040,97%2041,95%2044,96%2043,95%2044,94%2039,96%2037,95%2040,91%2041,92%2043,91%2043,89%2042,92%2040,89%2041,88%2040,87%2042,84%2043,85%2045,84%2047,86%2045,87%2047,87%2046,85%2048,84%2046,85%2043,81%2044,80%2043,81%2042,79%2044,77%2045,78%2046,77%2048,80%2049,77%2052,79%2053,78%2047,76%2043,71%2042,68%2045,66%2045,61%2044,60ZM40,100%2042,98%2044,100%2043,101ZM35,91%2038,92%2036,97%2034,94ZM41,81%2042,80%2044,83%2042,84ZM39,76%2041,75%2043,77%2041,78ZM44,73%2045,75%2043,77%2041,75ZM41,70%2042,73%2040,74%2039,72ZM67,54%2065,57%2064,54%2062,55%2062,58%2059,59%2058,61%2057,60%2058,62%2060,61%2061,62%2068,57ZM75,55%2076,56%2075,55%2076,54%2078,55%2080,54%2081,55%2082,54%2084,56%2083,57%2085,57%2085,56%2083,55%2085,54%2086,51%2088,52%2087,50%2088,49%2089,50%2088,49%2090,47%2087,47%2086,50%2083,51%2081,54%2080,53%2080,50%2077,49%2076,47%2076,52%2077,53ZM9,42%207,45%206,44%207,45%206,47%209,51%2012,52%2011,50%208,50%207,49%209,45%2010,46%209,45ZM103,42%20100,47%2099,45%20100,48%2099,49%2097,48%2099,50%20100,54%20103,53%20102,52%20103,50%20105,50%20106,51%20105,52%20105,55%20107,56%20110,53%20116,55%20117,57%20116,58%20114,57%20113,61%20116,59%20119,55%20118,49%20117,48%20117,49%20115,50%20113,47%20114,44%20111,42%20110,43%20107,41%20109,42%20107,45%20106,43ZM105,47%20107,45%20108,47%20109,46%20113,48%20110,49%20111,50%20110,51%20108,50%20107,51ZM106,44%20107,45%20105,46%20105,48%20103,50%20100,47%20104,44ZM44,35%2042,38%2039,38%2039,39%2033,44%2036,42%2038,43%2041,42%2040,42%2039,40%2040,39%2043,40%2042,38ZM114,21%20114,25%20118,28%20119,26%20115,25%20114,24%20115,21ZM43,15%2040,19%2039,23%2035,25%2036,28%2035,29%2034,27%2034,32%2033,33%2031,30%2032,29%2027,33%2029,33%2029,32%2031,31%2032,32%2031,35%2037,28%2039,27%2038,26%2042,23%2042,22%2041,23%2040,22%2040,19ZM101,8%20101,10%20104,13%20103,15%20104,14%20107,18%20110,19%20110,18%20105,14%20105,12%20104,12ZM75,0%2077,0%2080,3%2083,3%2087,6%2091,6%2092,4%2089,3%2091,2%2091,0ZM88,5%2089,4%2092,5%2091,6Z'/%3e%3cpath%20fill='%2387899d'%20stroke='%2387899d'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M100,469%20100,470%20101,469%20104,470%20104,468%20106,467%20105,466%20106,465%20112,467%20113,466%20118,470%20118,473%20118,470%20117,469%20118,466%20117,467%20114,467%20111,465%20110,466%20104,464%20105,465%20103,468%20102,467ZM56,447%2058,447%2060,449%2059,450%2057,449%2058,450%2057,452%2058,454%2058,452%2059,451%2060,452%2060,456%2068,456%2069,458%2072,459%2073,457%2076,458%2075,459%2076,458%2073,455%2071,456%2070,454%2066,454%2065,453%2063,456%2061,453%2063,449%2062,448%2063,447%2065,448%2064,451%2065,450%2066,451%2066,449%2068,448%2066,449%2065,448%2065,446%2067,443%2066,443%2066,445%2063,447%2060,447%2059,446%2064,442%2061,443%2059,446%2058,445%2059,446%2058,447ZM37,435%2039,434%2040,437%2044,440%2045,440%2040,437%2041,435%2043,436%2042,435%2043,432%2045,433%2045,435%2048,439%2047,440%2048,439%2051,440%2052,438%2054,439%2053,437%2054,436%2056,438%2055,436%2059,434%2064,437%2063,439%2065,437%2064,435%2063,436%2062,434%2056,435%2055,434%2056,433%2055,431%2054,433%2052,433%2050,431%2048,432%2046,430%2047,428%2046,428%2045,430%2042,429%2043,430%2041,432%2042,433ZM48,434%2050,433%2051,436%2050,437ZM16,380%2018,381%2022,378%2020,379%2019,378%2018,379%2016,378%2017,379ZM5,363%205,366%207,366%209,368%208,369%209,370%206,372%205,375%206,376%205,375%207,371%2010,375%2012,374%2015,375%2017,374%2019,375%2020,374%2021,376%2022,375%2025,377%2024,379%2025,378%2027,380%2026,382%2021,381%2024,382%2023,384%2024,383%2026,385%2027,384%2028,385%2031,383%2032,386%2033,385%2037,387%2040,385%2042,388%2046,390%2046,389%2043,387%2045,385%2048,386%2050,385%2050,384%2047,384%2046,383%2045,384%2039,381%2036,382%2035,380%2032,380%2031,379%2029,381%2028,380%2029,378%2028,377%2027,378%2025,377%2024,375%2022,375%2018,372%2019,373%2018,374%2014,374%2013,373%2015,370%2016,372%2015,370%2012,371%209,367%205,365ZM41,385%2043,384%2044,386%2042,387ZM39,382%2042,384%2039,385%2038,387%2036,384ZM30,382%2031,381%2034,381%2037,383%2034,385ZM63,361%2062,362%2061,361%2058,365%2055,365%2062,372%2062,374%2062,372%2060,370%2060,367%2058,368%2057,366ZM48,349%2047,350%2048,351%2046,352%2046,355%2047,356%2046,357%2047,359%2048,359%2051,363%2057,362%2054,362%2050,357%2051,356%2050,354%2051,350ZM60,351%2063,353%2064,351%2067,351%2068,350%2072,351%2073,349%2076,350%2079,348%2077,349%2072,349%2071,350%2067,348%2070,347%2070,346%2066,346%2065,344%2064,346%2063,345%2060,347%2060,348%2061,347%2062,348ZM33,345%2034,346%2031,348%2030,347%2031,348%2029,350%2028,349%2023,356%2020,358%2020,360%2022,361%2020,362%2020,363%2022,364%2020,365%2022,364%2025,366%2024,367%2025,366%2027,367%2028,370%2029,368%2031,372%2032,371%2033,373%2036,372%2037,374%2038,372%2039,374%2044,376%2049,375%2052,379%2053,379%2052,377%2053,376%2051,373%2048,372%2047,369%2041,368%2044,369%2041,373%2038,369%2035,370%2033,368%2036,366%2037,367%2039,365%2042,366%2037,360%2039,363%2037,367%2035,363%2033,362%2035,360%2034,359%2036,358%2035,357%2036,356%2035,357%2033,356%2035,357%2033,358%2034,359%2033,361%2032,361%2031,359%2028,359%2027,358%2028,355%2031,357%2030,354%2033,350%2034,351%2034,354%2036,354%2035,354%2034,352%2035,351%2036,352%2036,350%2038,347%2037,346%2040,344%2034,346ZM47,371%2048,372%2047,375%2045,373ZM33,362%2035,364%2033,365%2035,366%2034,367%2031,367%2030,366ZM111,342%20104,346%20104,347%20106,348%20103,350%20101,349%20100,353%2096,359%2098,360%2096,361%2096,364%2095,365%2094,364%2095,365%2091,370%2090,369%2090,370%2087,372%2088,373%2084,383%2084,386%2083,387%2082,386%2080,387%2080,388%2081,386%2082,387%2084,386%2086,388%2084,389%2087,391%2086,392%2087,396%2088,396%2089,398%2090,396%2092,396%2093,397%2092,399%2093,400%2092,401%2093,401%2094,403%2095,402%2096,404%2099,403%20103,406%20104,406%20103,403%20101,402%20102,401%20100,400%20101,399%20100,398%20100,395%20101,394%20106,397%20101,393%20102,392%20101,393%20100,391%2098,390%2099,388%2098,389%2095,385%2096,384%2095,385%2091,380%2092,379%2091,374%2098,363%20103,367%20106,367%20107,366%20109,367%20108,355%20110,352%20108,350%20110,348%20111,349%20113,346%20113,344ZM103,364%20104,363%20107,364%20106,365ZM102,357%20103,356%20106,357%20104,359ZM100,354%20101,353%20103,356%20101,357ZM46,331%2048,332%2046,333%2047,334%2047,337%2050,342%2051,342%2050,341%2051,340%2050,337%2048,336%2049,334%2048,332ZM34,331%2031,330%2027,333%2023,334%2024,335%2022,336%2021,334%2020,335%2019,334%2019,335%2021,335%2022,337%2025,335%2026,336%2025,337%2026,339%2025,337%2026,335%2029,333%2034,333ZM6,327%205,328%206,334%209,335%2011,334%2012,335%2010,337%208,337%209,339%208,340%205,338%206,336%205,337%206,339%205,340%206,343%2012,346%2011,345%2013,344%2010,345%208,341%209,340%2011,342%2018,340%2015,339%2016,337%2017,338%2016,337%2017,336%2016,335%2017,333%2015,332%2014,330%2013,332%2011,330%2012,329%209,328%207,329ZM10,339%2013,337%2016,340%2013,341ZM6,331%207,330%2010,331%2011,333%209,335ZM101,323%2097,325%2095,325%2093,323%2091,325%2091,328%2090,329%2087,327%2088,324%2085,327%2085,330%2086,330%2088,333%2087,336%2088,337%2088,341%2082,346%2083,347%2085,346%2086,347%2087,346%2090,347%2091,349%2089,350%2089,351%2091,349%2092,346%2091,345%2093,344%2094,346%2095,346%2095,344%2097,343%2095,342%2097,341%2098,339%2097,338%20100,337%2099,337%2098,335%20100,334ZM86,342%2088,345%2087,346%2084,345ZM91,343%2093,340%2095,341%2094,342%2096,343%2094,345ZM86,307%2084,305%2082,306%2079,305%2082,303%2078,306%2079,305%2080,306%2079,310%2082,309%2081,308%2083,307%2082,306%2083,305ZM43,285%2041,286%2040,288%2039,287%2037,288%2039,287%2040,288%2039,290%2036,290%2035,288%2035,289%2032,290%2031,292%2030,291%2031,294%2032,293%2034,294%2034,295%2032,296%2040,295%2041,297%2042,296%2043,297%2042,300%2039,303%2042,303%2043,302%2042,301%2043,300%2042,299%2043,298%2042,296%2045,292%2048,292%2049,293%2048,296%2049,295%2048,294%2051,292%2051,291%2048,290%2049,289%2045,287%2046,286%2045,287ZM37,290%2038,291%2036,294%2035,291ZM5,276%205,281%206,282%207,281%206,280%207,277ZM57,269%2056,270%2055,269%2057,271%2056,273%2057,274%2055,275%2056,278%2054,280%2053,279%2054,281%2056,281%2059,278%2057,276%2061,274%2060,273%2061,272%2059,274%2056,270ZM54,251%2051,250%2054,249%2050,247%2049,250%2046,248%2044,249%2046,248%2052,252ZM70,249%2073,250%2073,253%2076,252%2078,254%2079,252%2078,250%2079,249%2078,249%2077,247%2074,246ZM14,235%2015,238%2013,239%2015,243%2014,244%2013,243%2017,245%2015,246%2018,247%2018,248%2016,249%2016,251%2018,252%2017,249%2018,248%2019,249%2017,246%2019,244%2017,245%2014,241%2015,239%2016,240%2014,237ZM55,232%2056,235%2057,234%2060,235%2062,232%2064,234%2063,236%2064,236%2063,233%2064,232%2063,233%2060,229%2059,231%2058,230ZM58,232%2060,230%2062,232%2061,233ZM12,226%2010,226%2012,229%2011,230%2012,231%208,235%209,234%2010,235%209,237%2010,238%2011,237%2010,234%2014,232%2012,230%2012,229%2014,228ZM30,208%2026,212%2025,211%2024,212%2023,211%2022,213%2020,212%2021,215%2023,216%2022,217%2023,217%2023,213%2025,212%2026,213%2025,214%2028,212ZM69,202%2067,205%2066,203%2064,204%2063,207%2065,208%2064,210%2067,212%2066,213%2068,214%2066,217%2070,208%2069,206%2070,205%2068,203ZM27,201%2020,206%2019,210%2020,210%2019,208%2021,206%2022,207%2025,202ZM39,184%2040,185%2040,188%2043,187%2042,184%2041,185ZM72,173%2070,173%2071,179%2066,187%2059,192%2060,193%2057,197%2055,195%2057,193%2053,194%2051,198%2047,201%2048,200%2050,203%2052,204%2050,207%2048,204%2047,206%2045,206%2047,206%2049,209%2048,210%2045,210%2044,209%2045,208%2043,208%2041,211%2040,209%2039,211%2040,212%2042,211%2043,213%2044,213%2045,211%2048,212%2049,209%2054,207%2056,210%2060,208%2058,206%2059,205%2056,202%2058,200%2055,199%2059,197%2059,194%2063,189%2065,191%2067,191%2068,189%2072,195%2073,194%2076,194%2074,192%2075,189%2074,188%2075,187%2079,187%2080,188%2079,190%2080,193%2081,193%2081,190%2077,183%2076,186%2074,183%2075,180%2074,181%2073,180%2074,178%2073,176%2072,177%2071,176ZM50,199%2052,196%2054,197%2053,198%2054,197%2055,198%2053,201ZM83,179%2084,181%2086,182%2085,183%2087,186%2088,186%2091,190%2090,189%2091,188%2093,188%2096,186%2096,185%2094,184%2097,179%2098,180%2099,179%20101,180%20103,179%20104,176%20103,177%20101,176%2099,179%2097,177%2099,176%2098,175%2099,174%2098,175%2094,172%2089,172%2088,173%2085,172%2083,175%2084,176ZM91,178%2094,179%2094,181%2092,183%2089,181ZM89,172%2090,174%2088,176%2088,178%2090,179%2087,180%2084,176ZM50,170%2048,169%2049,168%2048,169%2047,168%2048,169%2046,171%2044,170%2045,169%2044,169%2045,171%2044,172%2039,171%2037,174%2036,171%2034,170%2035,171%2032,173%2036,175%2040,173%2042,174%2043,173%2044,174ZM57,161%2059,164%2067,165%2068,166%2073,165%2072,163%2071,164%2070,162%2069,164%2068,163%2063,163%2062,164%2060,162%2060,160%2058,162ZM57,145%2054,147%2053,149%2055,150%2052,151%2053,152%2052,154%2050,155%2051,158%2052,157%2053,159%2054,158%2055,159%2053,156%2054,155%2055,156%2060,147%2059,148ZM56,146%2057,149%2055,150%2054,148ZM119,136%20116,139%20115,138%20114,140%20113,139%20112,140%20110,139%20101,142%20105,144%20104,145%20105,146%20103,147%20105,148%20104,152%20101,154%20100,152%20100,153%2097,155%2090,152%2089,153%2088,151%2090,150%2086,149%2085,148%2086,147%2084,148%2086,149%2086,154%2088,157%2087,158%2090,158%2091,159%2090,160%2092,158%2094,158%2097,161%2097,158%2098,157%20100,162%20100,160%20104,157%20105,160%20102,161%20102,162%20103,161%20104,162%20106,159%20108,161%20107,163%20111,162%20112,160%20115,162%20115,161%20112,159%20117,155%20115,157%20112,157%20111,154%20108,155%20106,153%20108,152%20110,149%20111,152%20112,152%20111,151%20113,148%20114,150%20119,147%20118,145%20119,144%20118,141%20119,140%20118,139ZM110,139%20111,140%20110,143%20109,142ZM67,132%2066,134%2067,135%2065,136%2060,144%2062,143%2063,140%2064,141%2064,138%2068,135ZM14,116%2012,117%2011,116%2010,118%209,116%209,118%207,121%208,122%207,123%208,122%209,123%209,125%207,126%208,127%207,129%208,128%2011,134%209,135%2010,136%2011,135%2012,128%2014,125%2017,127%2019,132%2021,131%2020,129%2021,127%2019,126%2021,122%2015,118%2016,117%2015,118ZM79,62%2080,63%2078,64%2079,66%2082,65%2083,68%2084,67%2085,69%2086,68%2088,70%2089,68%2088,68%2086,65%2083,65%2082,64%2083,63ZM28,61%2027,64%2025,63%2026,62%2025,61%2026,62%2023,63%2024,64%2023,65%2021,65%2019,68%2019,71%2020,70%2019,68%2020,67%2021,68%2023,65%2024,66%2024,71%2026,72%2024,73%2026,74%2027,71%2026,69%2028,66%2027,65%2028,64ZM97,49%2096,51%2096,54%2097,55%2095,58%2096,56%2098,60%20100,60%20101,58%20102,59%20103,58%20106,58%20107,59%20104,61%20108,58%20110,61%20110,64%20112,63%20113,66%20118,66%20118,63%20117,66%20115,65%20114,63%20119,60%20119,56%20119,57%20113,62%20112,61%20113,57%20114,56%20116,57%20116,56%20110,54%20107,57%20104,55%20104,52%20105,51%20103,51%20104,53%20100,55ZM31,32%2030,32%2029,34%2026,34%2023,36%2025,40%2028,36%2030,36ZM100,9%2099,10%20102,13%20102,16%20105,17%20106,19%20109,19%20111,21%20109,24%20117,31%20117,33%20119,33%20119,27%20119,28%20117,29%20113,25%20113,21%20114,20%20113,19%20110,20%20107,19%20104,15%20103,16%20102,15%20103,13ZM71,0%2073,0%2078,4%2081,4%2086,7%2089,7%2090,8%2089,9%2090,7%2087,7%2083,4%2080,4%2077,1ZM42,0%2040,2%2040,5%2037,10%2038,10%2041,4%2040,3Z'/%3e%3cpath%20fill='%23aaaebd'%20stroke='%23aaaebd'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M95,458%2093,462%2095,461%2097,466%2096,467%2097,466%2098,467%2099,466%2097,464%2098,462%2096,460%2097,459ZM84,456%2069,467%2066,471%2065,470%2063,471%2066,471%2067,470%2069,471%2069,470%2067,469%2068,468%2071,468%2074,463%2075,464%2078,462%2080,463%2079,462%2083,460%2082,459%2084,458ZM37,434%2042,432%2045,437%2046,435%2045,436%2044,435%2044,433%2042,432%2043,431%2042,430%2045,429%2046,427%2048,428%2047,429%2049,431%2050,430%2052,432%2049,434%2050,436%2050,434%2052,432%2058,434%2059,436%2057,437%2060,437%2059,435%2061,433%2064,434%2066,436%2063,440%2062,439%2062,442%2064,443%2062,445%2061,444%2062,445%2061,446%2059,445%2057,446%2059,445%2060,446%2065,445%2067,451%2066,452%2064,450%2064,448%2062,449%2063,452%2061,454%2062,453%2063,455%2065,452%2066,453%2070,453%2071,455%2073,454%2076,457%2073,458%2073,460%2077,457%2076,456%2079,453%2081,454%2080,453%2083,450%2081,449%2078,445%2077,446%2076,445%2077,446%2073,448%2072,446%2074,445%2074,444%2071,443%2072,441%2068,436%2062,433%2059,433%2055,430%2051,430%2047,427%2043,427%2042,428%2043,429ZM67,442%2068,443%2066,446%2065,443ZM94,422%2093,423%2092,422%2090,423%2091,426%2094,429%2092,431%2093,432%2093,443%2092,444%2092,448%2090,454%2084,464%2081,467%2081,469%2076,473%2079,472%2081,470%2081,468%2085,466%2085,464%2087,463%2086,461%2088,459%2091,459%2090,456%2091,455%2092,456%2091,455%2092,453%2093,454%2092,452%2094,451%2093,448%2095,447%2094,445%2096,444%2095,443%2097,442%2096,441%2099,439%2098,438%2099,437%2099,434%20100,433%20103,434%20100,428%2098,428%2094,424%2095,423ZM105,334%20102,338%20103,337%20104,339%20100,341%2096,351%2095,352%2094,351%2095,352%2091,355%2092,358%2091,359%2090,358%2085,365%2084,364%2085,365%2084,370%2086,371%2084,374%2082,374%2083,374%2084,376%2081,381%2082,383%2080,384%2080,386%2082,385%2084,388%2085,388%2083,386%2083,383%2087,373%2086,372%2089,370%2090,371%2089,370%2090,368%2091,369%2093,366%2095,368%2095,370%2092,374%2093,377%2092,380%2095,384%2096,383%2097,384%2095,382%2095,379%2094,378%2095,375%2094,374%2095,372%2094,371%2096,370%2098,367%20100,367%20102,369%20105,368%20103,368%2099,364%2098,364%2095,368%2093,366%2095,364%2095,361%2097,360%2095,359%2097,357%20100,349%20101,348%20102,349%20105,348%20104,348%20103,346%20111,341%20111,340%20109,339%20108,340%20106,338%20106,336%20104,335ZM86,364%2088,361%2090,364%2089,365ZM47,329%2046,330%2049,332%2050,334%2049,336%2051,337%2052,339%2051,341%2052,341%2052,337%2053,336%2050,335%2051,333%2050,333ZM40,325%2039,324%2038,325%2036,324%2035,326%2034,325%2033,326%2031,324%2030,327%2027,328%2030,329%2028,331%2027,330%2024,333%2021,330%2023,329%2021,330%2020,329%2020,330%2017,332%2020,334%2021,333%2025,333%2026,331%2030,332%2028,331%2031,329%2038,330%2037,328%2039,327ZM79,321%2079,322%2081,323%2080,324%2081,329%2084,330%2087,335%2086,331%2084,330%2084,327%2087,324%2088,327%2090,328%2090,325%2093,322%2095,324%2094,325%20101,322%20102,323%20102,329%20100,336%20102,331%20102,322%20101,320%2099,319%20100,318%2098,318%2094,313%2093,313%2092,315%2091,314%2087,316%2086,318%2084,317%2085,318%2083,319%2082,321%2081,319%2081,320ZM107,294%20106,295%20103,295%20101,293%20102,289%20100,292%2097,291%2098,292%2097,294%2091,294%2091,296%2087,299%2087,302%2086,303%2087,302%2088,304%2090,301%2093,303%2093,301%2094,300%2095,301%2096,298%2099,300%20101,297%20102,298%20103,296%20105,296ZM102,272%20100,273%20100,275%2098,276%2099,277%2097,278%20100,281%20102,279%20101,276%20102,275%20103,276%20102,275ZM24,256%2025,259%2028,257%2027,256%2028,255%2030,256%2030,258%2033,257%2035,259%2035,255%2033,252%2031,253%2029,252ZM83,243%2079,243%2078,244%2077,243%2076,244%2075,243%2073,244%2072,243%2067,245%2066,244%2065,246%2064,245%2062,246%2060,245%2064,247%2063,248%2064,249%2064,252%2063,253%2066,257%2066,260%2067,261%2064,264%2065,265%2062,267%2060,266%2059,268%2058,267%2056,269%2057,270%2056,272%2057,270%2059,273%2060,272%2062,274%2060,276%2058,276%2060,278%2056,282%2054,282%2052,279%2056,277%2055,278%2054,277%2047,285%2046,284%2044,285%2046,285%2047,287%2050,289%2048,291%2049,290%2052,291%2052,292%2050,293%2050,295%2051,294%2052,295%2052,297%2056,302%2059,301%2064,303%2065,305%2073,312%2074,311%2075,312%2077,311%2079,306%2083,304%2081,304%2076,310%2075,310%2071,305%2072,304%2070,302%2071,300%2072,301%2072,299%2070,296%2071,294%2069,293%2070,292%2068,291%2069,290%2068,291%2067,290%2068,288%2066,286%2068,283%2067,281%2068,280%2067,279%2068,276%2066,274%2068,273%2068,272%2065,271%2067,269%2068,270%2069,268%2068,267%2070,266%2069,265%2071,264%2071,262%2073,261%2075,258%2079,256%2079,253ZM67,306%2068,305%2071,305%2073,308%2071,310%2070,308ZM47,285%2049,284%2050,286%2048,287ZM67,259%2068,258%2071,259%2070,260ZM74,245%2077,246%2078,248%2080,249%2079,250%2080,252%2078,256%2076,253%2073,254%2072,253%2072,250%2069,249ZM26,236%2028,240%2027,238%2028,237%2033,238%2032,236%2033,235%2035,236%2033,234%2030,235%2029,234ZM10,225%207,227%208,229%206,234%207,236%205,243%206,244%205,247%206,246%207,248%205,249%207,253%206,255%208,257%207,258%2011,261%2015,256%2014,254%2015,253%2017,254%2016,253%2018,251%2019,246%2018,249%2017,247%2015,247%2014,246%2015,245%2013,244%2015,241%2018,243%2017,243%2015,240%2014,242%2012,240%2012,239%2014,238%2013,237%2014,234%2013,233%2011,234%2012,235%2011,238%208,237%209,235%208,234%2011,231%2010,230%2011,229%209,226ZM12,251%2013,252%2012,255%2011,254ZM15,249%2017,248%2018,251%2016,252ZM6,242%208,241%209,239%2012,241%208,244ZM24,229%2028,231%2031,231%2032,230%2033,231%2032,229%2033,228%2036,228%2037,229%2036,230%2038,232%2037,235%2039,232%2041,233%2040,232%2043,228%2041,230%2039,230%2038,229%2039,228%2035,225%2036,224%2039,224%2040,225%2042,223%2044,225%2047,225%2044,223%2047,221%2050,225%2050,227%2047,229%2050,233%2048,235%2051,238%2049,236%2050,235%2053,235%2056,237%2057,236%2058,237%2059,236%2062,236%2064,233%2065,235%2068,234%2070,235%2072,234%2081,234%2078,234%2076,232%2074,233%2073,232%2074,231%2072,231%2071,233%2067,234%2066,232%2063,234%2061,232%2057,233%2061,232%2062,234%2060,236%2057,235%2056,236%2054,232%2058,229%2059,230%2058,221%2056,220%2058,217%2059,218%2058,217%2059,212%2060,211%2061,212%2064,208%2056,211%2054,209%2055,207%2053,208%2048,201%2048,202%2042,207%2041,210%2043,207%2046,208%2040,213%2038,211%2035,217%2034,216%2035,218%2034,220%2032,221%2031,225%2030,226%2027,226%2029,226%2030,227%2029,228%2031,227%2032,230%2031,231%2030,230%2028,231%2027,228ZM53,218%2054,216%2057,217%2055,219ZM54,210%2055,213%2053,214%2052,212ZM51,210%2052,213%2050,214%2049,213ZM48,203%2050,206%2051,205%2053,208%2050,209%2048,213%2045,212%2045,213%2043,214%2042,212%2045,209%2048,209%2044,206%2047,205ZM18,196%2017,197%2016,196%2015,197%2013,196%2012,198%2010,197%207,198%207,201%206,202%208,204%208,206%209,205%2010,206%2011,204%2010,203%2012,201%2013,202%2014,201%2013,200%2016,197%2018,197ZM39,185%2038,185%2037,187%2036,186%2033,190%2031,189%2030,191%2029,190%2028,192%2027,191%2027,192%2036,188%2038,188%2039,190ZM55,184%2051,183%2050,184%2051,184%2052,186%2051,187%2047,187%2047,188%2051,187ZM118,180%20117,179%20114,180%20113,179%20109,179%20102,176%20104,177%20104,179%20101,181%20100,180%2098,181%2097,180%2095,184%2096,184%2097,186%2095,188%2091,189%2096,194%2094,192%2096,190%2097,191%2099,190%20101,184%20100,183%20102,181%20105,183%20106,182%20113,184%20115,181ZM71,171%2070,171%2068,174%2064,175%2066,176%2063,178%2066,177%2067,175%2069,176%2069,173%2071,172ZM119,148%20114,151%20113,149%20112,151%20113,152%20112,153%20110,152%20110,150%20110,151%20107,153%20108,154%20111,153%20112,156%20114,156%20119,153ZM105,154%20105,153%20103,152%20104,148%20102,149%20103,150%20102,151%20100,150%2099,152%2098,151%2096,152%2092,150%2089,151%2089,152%2090,151%2093,153%2095,153%2096,154%2095,155%2099,153%20100,151%20101,153%20103,152%20104,153%20103,154%20104,153ZM22,128%2021,129%2022,131%2019,133%2018,132%2019,129%2018,131%2016,127%2014,126%2012,135%2010,137%208,135%2010,134%207,127%208,129%207,130%207,139%208,140%208,143%207,144%209,145%207,148%208,151%207,152%208,151%209,152%208,151%2010,150%2011,146%209,145%2012,143%2011,141%2013,139%2015,139%2019,134%2022,135%2022,133%2024,131%2023,132%2022,131%2023,129ZM119,63%20119,66%20117,67%20115,70%20118,70%20119,68ZM95,59%2097,62%2096,65%2098,65%20102,60%20103,62%20106,62%20107,61%20108,62%20107,65%20108,65%20109,67%20110,66%20115,67%20113,67%20112,64%20111,65%20109,64%20108,59%20107,60%20106,59%20103,59%20102,60%20101,59%20100,61%2098,61%2096,57ZM106,59%20107,60%20104,62%20103,61ZM24,53%2021,53%2020,52%2018,54%2017,53%2014,54%207,60%209,62%207,64%207,67%208,68%206,70%206,75%2014,63%2017,61%2019,61%2018,61%2017,59%2018,58%2019,59%2022,58%2024,55ZM37,46%2031,48%2035,50%2037,49%2036,47ZM98,11%2096,13%2097,14%2096,15%2097,17%20104,20%20116,34%20119,34%20117,34%20116,31%20108,24%20110,21%20109,20%20106,20%20105,18%20101,16%20101,13Z'/%3e%3cpath%20fill='%233b3a4b'%20stroke='%233b3a4b'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M45,457%2044,457%2043,460%2044,462%2046,461%2044,458ZM118,452%20115,456%20117,458%20116,459%20117,460%20114,461%20113,463%20110,461%20108,463%20109,462%20116,463%20115,462%20117,461%20118,464ZM90,437%2086,442%2085,440%2084,442%2083,441%2082,442%2081,440%2079,441%2081,442%2080,443%2081,442%2082,443%2081,445%2083,445%2087,449%2082,443%2085,441%2086,442%2087,441%2088,444%2086,445%2089,447ZM89,410%2092,410%2093,411%2092,413%2093,414%2092,415%2089,413%2091,415%2090,416%2091,415%2093,416%2094,415%2095,417%2096,415%2099,418%2098,421%20101,424%20100,426%20105,427%20106,428%20105,430%20108,431%20107,433%20109,432%20113,435%20116,434%20118,427%20117,424%20118,423%20117,421%20118,419%20118,414%20115,412%20117,411%20115,412%20113,410%20110,410%20109,409%20110,408%20109,409%20106,408%20105,409%20106,411%20105,412%20104,411%20106,413%20104,414%20105,416%20106,415%20107,416%20107,418%20106,419%20103,418%20101,419%20100,418%20101,417%2097,414%2098,413%2096,412%2096,410%2094,411%2093,410%2094,408%2092,410ZM117,424%20118,425%20117,428%20116,427ZM100,418%20102,420%20100,423%2099,422%2099,419ZM107,378%20105,379%20106,380%20104,382%20105,383%20103,384%20105,389%20107,386%20104,384%20105,383%20107,384%20107,383%20109,382%20109,380ZM109,374%20110,376%20109,377%20116,382%20114,380%20117,378%20117,375%20116,374%20117,377%20116,378%20114,377%20115,379%20113,380%20111,378%20112,376ZM118,359%20116,360%20117,362%20114,364%20115,365%20119,365%20117,362ZM78,322%2078,330%2077,331%2078,330%2081,331%2079,328ZM68,309%2073,314%2077,320%2073,313ZM119,77%20117,78%20116,77%20117,76%20116,77%20115,76%20116,77%20115,78%20113,77%20114,78%20113,79%20111,78%20112,80%20110,82%20109,81%20109,84%20107,85%20108,86%20106,89%20105,88%20106,90%20104,91%20103,93%20104,92%20106,93%20105,95%20106,97%20104,99%20103,98%2098,102%2097,101%2091,103%2090,102%2088,103%2087,106%2084,106%2084,107%2087,109%2085,111%2083,109%2082,113%2087,117%2084,118%2084,120%2085,119%2087,120%2089,124%2086,126%2087,127%2086,128%2088,125%2096,118%2096,114%2098,112%2099,113%2098,118%20100,113%20101,116%20103,113%20104,114%20103,113%20105,111%20108,112%20109,110%20111,111%20113,109%20114,110%20115,108%20116,109%20119,108%20118,107%20119,106%20119,101%20118,100%20119,99%20119,80%20118,79ZM91,120%2092,121%2089,124%2088,122ZM88,113%2089,114%2086,116%2085,115ZM88,109%2090,111%2089,113%2086,111ZM112,108%20113,109%20110,111%20109,110ZM85,107%2086,106%2089,107%2088,108ZM54,57%2053,58%2052,57%2050,60%2053,61%2052,59ZM5,53%205,66%206,65%205,64%206,63%205,59%2011,55%206,58%205,57ZM26,52%2024,49%2025,48%2024,47%2025,48%2024,49%2021,49%2018,51%2017,50%2014,51%2013,50%2014,49%2012,48%2014,49%2013,50%2014,52%2013,53%2016,51%2019,51%2024,49ZM90,17%2084,23%2085,25%2084,26%2082,25%2083,26%2082,30%2083,31%2084,30%2085,32%2091,32%2092,31%2094,34%2093,33%2093,28%2094,27%2093,26%2095,25%2092,22%2091,19%2089,18ZM92,21%2089,23%2086,23%2085,22%2087,20%2088,21%2087,20%2089,18ZM15,12%2022,28%2026,26%2026,25%2028,24%2025,23%2026,24%2023,27%2020,24%2021,22%2020,19%2019,19%2017,16%2020,12%2017,15ZM37,12%2035,14%2033,12%2028,12%2027,11%2029,13%2028,15%2030,15%2033,12%2035,14%2034,16%2033,15%2032,16%2033,15%2034,17%2030,20%2029,22%2032,19%2033,20%2032,19ZM109,12%20113,10%20118,12%20116,10%20112,10%20110,9ZM65,7%2062,10%2063,11%2062,12%2066,9%2067,10%2066,14%2065,15%2060,14%2063,20%2065,29%2070,28%2071,26%2072,27%2071,26%2068,26%2067,28%2065,26%2066,23%2070,18%2071,21%2073,20%2075,21%2073,25%2074,26%2075,25%2074,24%2075,23%2075,19%2077,18%2078,21%2083,15%2080,13%2081,12%2078,14%2077,13%2078,14%2076,16%2075,15%2076,16%2074,18%2071,17%2067,22%2065,20%2064,21%2063,20%2064,18%2063,17%2064,16%2067,16%2066,14%2067,12%2069,13%2067,12%2068,9%2067,10%2064,8ZM79,13%2082,16%2078,19%2076,16Z'/%3e%3cpath%20fill='%23d4d7dc'%20stroke='%23d4d7dc'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M43,466%2041,469%2042,471%2041,472%2042,473%2047,473%2044,470ZM81,462%2075,465%2074,464%2071,469%2068,469%2070,470%2069,472%2066,470%2067,471%2066,472%2060,473%2070,473%2071,470%2078,463ZM90,460%2087,461%2088,463%2086,464%2086,466%2082,468%2082,470%2078,473%2080,473%2082,470%2087,466ZM30,459%2030,462%2033,464%2031,465%2033,466%2032,468%2033,466%2035,469%2035,471%2034,472%2033,470%2034,473%2035,472%2037,473%2036,468%2034,467%2035,466%2033,460%2032,459%2033,461%2031,462ZM53,447%2050,448%2049,450%2047,448%2048,447%2046,448%2047,449%2047,453%2050,451ZM36,441%2034,442%2034,444%2032,447%2033,448%2031,449%2033,450%2033,452%2032,453%2030,451%2030,454%2031,455%2030,457%2031,455%2033,457%2033,455%2030,454%2033,453%2034,451%2033,449%2034,448%2035,449%2034,447%2036,446%2035,445%2036,444ZM101,429%20103,431%20103,433%20101,435%20100,434%20100,437%2098,439%20102,435%20103,436%20106,435%20117,441%20116,440%20117,439%20112,438%20106,434ZM43,425%2043,426%2047,426%2051,429%2055,429%2059,432%2062,432%2068,435%2073,441%2072,443%2075,444%2073,447%2078,444%2080,447%2083,449%2076,440%2076,437%2074,436%2075,434%2073,435%2070,435%2069,434%2070,433%2067,434%2066,433%2067,432%2064,428%2062,429%2059,426%2056,425%2054,422%2052,423%2051,422%2044,426ZM105,392%20119,404%20117,401%20118,400%20113,398%20108,393ZM100,371%2098,372%2099,382%20100,382%2099,380%2099,377%20100,376%2099,372ZM50,368%2054,371%2057,379%2055,391%2052,397%2053,400%2054,400%2055,395%2057,394%2059,389%2058,387%2060,385%2059,383%2060,381%2058,378%2058,375%2059,374%2058,375%2056,373%2057,371%2055,373%2054,372%2055,369%2053,370ZM7,361%206,365%209,364%2010,366%2017,370%2012,366%2011,364%2012,363%2011,364%2010,362ZM93,354%2087,360%2082,367%2080,372%2078,373%2079,374%2077,375%2074,383%2074,392%2079,405%2086,415%2089,417%2088,418%2090,419%2089,420%2090,422%2092,421%2098,427%2084,411%2082,404%2080,403%2081,402%2079,401%2080,399%2079,396%2078,397%2077,396%2077,392%2078,391%2076,389%2076,384%2078,383%2077,381%2079,379%2078,375%2079,374%2080,376%2081,375%2082,376%2082,379%2083,375%2081,374%2081,372%2084,368%2084,365%2086,363%2089,364%2087,360%2090,357%2091,358%2091,356ZM19,353%2020,354%2017,352%2014,354%2015,355%2015,358ZM45,346%2041,350%2040,354%2043,360%2042,362%2041,361%2047,366%2047,365%2045,364%2046,362%2045,363%2043,361%2044,359%2043,360%2042,359%2043,357%2042,356%2043,355%2042,354%2043,353%2042,349%2044,347%2045,348%2044,347ZM106,320%20106,323%20107,324%20106,325%20106,330%20107,333%20110,337%20111,336%20113,337%20111,333%20112,332%20111,333%20109,331%20110,329%20109,329%20108,326%20106,325%20107,324ZM7,308%207,310%205,312%205,318%208,319%208,324%209,325%208,327%2010,328%209,326%2012,325%2014,327%2013,330%2015,329%2016,331%2019,332%2018,331%2020,328%2024,332%2027,329%2028,330%2029,329%2026,328%2028,326%2029,327%2031,323%2033,325%2034,324%2035,325%2036,323%2040,326%2038,329%2042,325%2045,326%2046,329%2047,328%2048,330%2052,333%2051,335%2054,336%2053,337%2053,339%2054,339%2054,335%2048,323%2042,322%2037,324%2034,322%2032,322%2028,318%2028,316%2025,317%2022,315%2019,315%2016,313%2017,312%2016,313%2014,311%2012,311%2011,309%2010,311%209,310%208,311ZM118,305%20112,312%20110,313%20108,317%20110,317%20110,316%20113,314%20114,315%20112,317%20117,313%20118,310%20117,308%20118,307%20117,306ZM115,308%20116,309%20116,313%20115,314%20112,311%20114,310ZM107,302%20105,299%20102,301%20100,304%2099,303%20100,304%2097,306%2096,305%2095,308%2094,306%2092,308%2086,310%2092,309%2094,307%2095,308%2097,307%2098,305%20102,304%20102,303%20105,301ZM118,287%20114,292%20108,297%20110,296%20112,298%20114,296%20113,294ZM103,271%20100,271%2099,270%2095,276%2093,277%2090,284%2089,293%2087,296%2085,297%2084,296%2085,297%2083,300%2087,303%2088,302%2090,305%2092,304%2090,302%2087,303%2086,302%2086,299%2090,296%2091,293%2097,293%2092,287%2094,286%2095,283%2098,282%20101,279%2098,280%2096,278%2098,277%2097,276%2099,275%2099,273%20102,271%20103,272%20102,277ZM34,251%2036,255%2036,259%2035,260%2033,258%2030,259%2029,256%2028,256%2029,257%2025,260%2024,259%2025,256%2023,259%2026,263%2025,264%2026,265%2028,265%2030,263%2034,263%2036,260%2039,258%2038,259ZM5,251%205,255%206,256%205,257%205,260%206,261%205,262%207,260%208,261%208,265%207,266%208,265%2012,267%2013,264%2012,261%2015,259%2014,258%2017,253%2015,254%2016,256%2011,262%209,260%2010,259%208,260%206,258%207,257%205,255%206,254ZM36,225%2040,228%2038,230%2039,229%2042,230%2041,232%2044,233%2045,232%2052,238%2055,237%2049,235%2050,234%2046,229%2049,227%2049,225%2047,222%2046,223%2044,222%2048,225%2047,226%2044,226%2042,224%2040,226%2039,225ZM36,214%2035,216%2032,218%2032,220%2030,221%2025,228%2027,227%2028,230%2027,231%2024,230%2023,232%2025,233%2024,236%2027,239%2028,238%2029,240%2032,240%2033,241%2034,240%2035,241%2035,238%2037,234%2037,232%2035,230%2036,229%2033,229%2032,231%2031,228%2029,229%2028,228%2029,227%2026,226%2027,225%2030,225%2031,223%2032,224%2031,221%2033,220ZM25,236%2029,233%2030,234%2033,233%2035,235%2033,236%2034,237%2033,239%2031,238%2028,238%2027,239ZM27,231%2029,229%2032,231%2031,232%2028,232ZM17,212%2014,213%2016,214%2015,218%2017,220%2019,219ZM81,201%2081,203%2082,202%2087,202%2093,204%2096,207%2097,206%2097,203%2095,201%2094,202%2093,200%2092,201%2091,199%2088,200%2087,199%2088,198%2085,198%2083,200%2082,199%2083,200ZM28,191%2029,192%2028,193%2026,192%2023,193%2021,196%2018,195%2017,196%2018,195%2019,197%2016,198%2013,203%2011,201%2012,202%2010,204%2011,205%2010,207%209,206%208,207%207,204%207,208%209,208%2014,202%2015,203%2016,201%2014,200%2016,198%2018,200%2017,199%2021,196%2024,197%2024,196%2027,195%2026,194%2029,193ZM57,185%2055,185%2053,187%2048,189%2042,188%2040,189%2040,190%2041,189%2042,190%2053,189%2055,188ZM115,182%20114,183%20113,182%20111,184%20107,184%20106,183%20105,184%20103,182%20101,183%20100,182%20102,184%20100,190%2097,192%2096,191%2095,192%2099,196%20102,196%20104,199%20103,205%20107,205%20106,204%20107,203%20111,203%20111,197%20110,196%20112,194%20111,193%20113,191%20114,192%20112,190%20114,187%20115,188%20114,187%20114,183ZM51,173%2050,172%2043,176%2048,174%2051,175ZM36,176%2033,176%2029,173%2030,171%2033,171%2032,170%2029,171%2029,173%2025,175%2029,174%2030,176%2031,175%2032,176ZM79,167%2078,169%2077,168%2078,169%2076,171%2074,170%2077,178%2079,179%2078,180%2079,182%2083,186%2084,191%2085,191%2083,187%2084,186%2081,184%2082,183%2081,184%2080,183%2081,181%2080,182%2079,181%2080,174%2076,171%2078,169%2079,170%2080,169ZM79,174%2080,175%2080,178%2079,179%2077,177ZM89,168%20100,171%20107,175%20110,175%20111,176%20116,176%20119,169%20118,170%20116,169%20115,170%20116,171%20113,173%20109,173%20107,171%20106,172%20102,172%2099,170%20100,169%2099,170%2097,169%2096,167%2094,168%2093,166%2092,168ZM59,166%2060,168%2066,168%2067,169%2069,167%2070,168%2071,167%2065,168ZM79,140%2084,143%2086,143%2087,145%2093,148%2095,148%2095,147%2090,146%2087,143%2088,140%2087,141%2086,140%2086,137%2085,137%2085,140%2084,141%2083,140%2082,141ZM23,131%2024,132%2022,136%2019,135%2015,140%2012,141%2011,143%2012,144%2010,145%2012,146%2012,148%2010,151%208,152%207,151%208,152%207,153%2010,153%2011,151%2012,152%2011,151%2012,149%2014,151%2017,149%2022,149%2017,149%2015,151%2013,147%2014,144%2016,143%2015,142%2017,140%2020,141%2018,145%2020,145%2018,144%2020,142%2021,143%2020,140%2024,132ZM77,65%2077,68%2079,68%2080,71%2082,70%2084,71%2083,72%2084,72%2085,75%2087,76%2088,80%2090,81%2090,83%2091,80%2092,81%2093,80%2095,81%2096,78%2094,77%2093,78%2092,76%2094,75%2090,73%2091,72%2090,73%2089,72%2090,70%2088,72%2087,71%2084,71%2081,67%2079,68ZM85,74%2086,73%2089,74%2088,75ZM96,62%2097,64%2098,63%2099,65%2097,66%2098,69%20101,70%20105,69%20107,72%20110,73%20117,71%20118,72%20117,74%20119,72%20119,69%20118,71%20115,71%20114,70%20116,67%20115,68%20112,68%20111,67%20109,68%20108,66%20106,65%20107,62%20106,63%20103,63%20102,61%20100,64ZM96,28%2097,30%2096,31%2099,32%2095,34%2094,45%20104,38%20110,38%20112,39%20106,35%20105,33%20102,34%20100,32%20101,30%20100,31%2097,27ZM94,15%2096,14%2094,15%2095,16%2094,17%2099,21%20101,21%20106,24%20110,28%20111,31%20116,35%20116,37%20119,38%20119,35%20116,35%20104,21%2098,19%2096,16ZM70,12%2072,16%2076,13%2074,14%2072,13%2071,11ZM64,2%2064,3%2065,2%2071,5%2073,4%2085,8%2081,6%2078,6%2068,0%2069,2%2068,3%2066,3%2065,2%2066,1Z'/%3e%3cpath%20fill='%231d1c28'%20stroke='%231d1c28'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M3,440%204,441%203,443%202,442%204,450%208,448%2011,451%2011,460%2016,466%2011,460%2011,450%208,448%205,448%204,449%202,445%203,443%207,446%204,442%204,440ZM119,443%20115,442%20107,437%20101,438%2099,441%20104,437%20119,444%20119,450%20118,451%20119,452%20119,464%20118,465%20117,464%20109,463%20103,460%20100,460%2094,455%2091,463%2085,471%2091,463%2096,469%2098,469%20102,464%20101,461%20102,460%20112,464%20119,465ZM94,456%2098,458%20102,462%20101,466%2098,469%2097,469%2091,462ZM21,434%2022,437%2026,440%2031,437%2034,438%2031,443%2031,447%2029,449%2029,454%2029,450%2034,439%2036,439%2040,443%2038,445%2041,443%2045,448%2045,456%2045,448%2044,447%2045,445%2054,446%2055,447%2049,454%2046,460%2047,457%2055,448%2055,446%2061,442%2061,440%2058,438%2053,441%2044,441%2053,441%2056,439%2059,439%2061,441%2054,446%2048,446%2041,443%2034,437%2031,437%2026,440%2022,437ZM65,424%2065,428%2068,431%2072,432%2068,431%2065,428%2065,425%2068,424%2071,429%2074,429%2075,427%2068,424ZM69,426%2071,425%2075,427%2072,429ZM24,412%2023,413%2024,412%2027,413%2024,417%2023,417%2022,415%2024,418%2028,414%2029,414%2032,418%2033,429%2028,432%2025,431%2024,429%2023,431%2020,430%2021,426%2023,425%2021,426%2020,431%2021,432%2022,431%2028,432%2033,429%2033,423%2032,422%2031,415%2027,412ZM45,409%2046,411%2047,411%2046,409%2048,408%2050,411%2049,414%2046,413%2046,414%2050,414%2053,411%2058,410%2054,407%2050,407ZM49,409%2051,407%2054,407%2056,410%2051,412ZM74,396%2075,401%2078,407%2086,417%2089,423%2090,432%2091,433%2090,434%2091,443%2088,451%2082,446%2088,452%2087,454%2085,453%2081,455%2066,468%2059,472%2056,472%2059,472%2065,469%2079,457%2086,453%2087,456%2084,461%2080,464%2080,466%2073,473%2072,472%2073,473%2076,471%2085,460%2089,452%2089,449%2091,445%2091,429%2089,423%2084,414%2078,407%2075,401ZM68,395%2064,398%2063,397%2059,399%2059,402%2060,402%2061,404%2063,404%2065,399%2068,402%2065,399ZM63,398%2064,401%2062,404%2059,400ZM99,386%20107,397%20119,406%20118,436%20117,437%20113,436%20106,432%20102,427%20100,427%2088,413%2083,403%2087,412%20100,427%20110,435%20118,438%20119,437%20118,436%20119,434%20118,433%20119,430%20119,406%20115,402%20111,400%20103,392ZM61,385%2059,394%2056,398%2055,402%2054,403%2043,403%2041,404%2041,405%2044,403%2057,404%2065,409%2069,414%2065,409%2055,403%2055,401%2057,399%2061,387%2062,386%2066,388ZM119,380%20117,381%20115,385%20115,390%20114,391%20116,395%20115,396%20112,395%20106,389%20106,390%20112,395%20119,399%20119,388%20119,397%20118,398%20115,393%20115,385%20118,381%20119,382%20119,385ZM38,358%2039,361%2054,374%2055,383%2055,377%2053,372%2050,369%2043,365ZM72,341%2074,341%2076,343%2072,346%2076,348%2081,345%2079,346%2074,341ZM73,345%2074,344%2077,344%2079,346%2076,348%2074,347ZM92,20%2096,25%2094,28%2093,42%2094,29%2097,25ZM27,6%2021,9%2017,14%2022,9%2024,9ZM66,5%2066,7%2058,14%2055,19%2032,43%2040,36%2056,17%2057,18%2057,16%2065,8%2068,10%2068,12%2067,9%2068,6ZM47,4%2041,16%2033,26%2027,32%2020,35%2019,32%2020,35%2024,34%2038,21%2045,10ZM119,1%20118,0%20117,1%20116,0%20111,0%20110,1%20109,0%20106,0%2082,26%2075,31%2070,33%2074,32%2087,22%2093,14%20100,8%20102,5%20103,7%20105,8%20106,7%20107,8%20116,9%20119,12%20119,15ZM117,4%20118,6%20116,8%20115,6ZM111,1%20114,5%20112,8%20109,6%20109,2ZM99,0%2094,4%2086,14%2083,14%2078,11%2078,13%2073,17%2079,12%2084,15%2078,22%2071,27%2076,24ZM62,4%2058,4%2058,6%2055,10%2053,8%2051,0%2051,3%2049,4%2051,4%2053,6%2054,11%2040,28%2034,33%2029,39%2041,27%2053,12ZM7,0%206,0%206,12%205,13%206,18%2011,12%2012,13ZM7,1%2010,7%2011,12%206,17%205,16%205,13%206,12%206,2Z'/%3e%3c/svg%3e", Re = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20120%20474'%3e%3crect%20width='120'%20height='474'%20fill='%23fff9e9'/%3e%3cpath%20fill='%232382de'%20stroke='%232382de'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M86,400%2085,402%2084,401%2079,408%2079,426%2082,433%2087,440%2089,447%2092,450%2091,451%2092,452%2092,458%2093,459%2092,461%2092,473%20109,473%20105,465%20105,462%20103,457%20103,445%20104,444%20105,431%20106,430%20106,415%20105,414%20105,410%2099,402%2094,400ZM7,389%208,391%205,392%204,395%205,397%204,398%205,399%204,400%204,405%205,406%203,407%204,409%203,410%204,412%203,413%204,414%203,416%204,419%203,420%203,428%204,429%203,430%204,436%203,437%204,440%204,454%2014,463%2016,463%2017,464%2016,465%2017,464%2019,466%2025,461%2038,455%2037,454%2038,453%2038,449%2035,442%2032,439%2029,433%2025,429%2026,428%2024,427%2023,423%2021,422%2019,418%2019,415%2018,414%2019,412%2017,411%2017,408%2014,402%2016,399%2016,397%2014,396%2015,395%2014,392%2012,392%2010,390%209,391ZM100,385%20100,390%20102,393%20110,400%20111,399%20110,392%20105,386ZM114,344%20109,345%20108,347%20106,347%20105,348%20106,349%20104,352%20104,355%20106,357%20105,358%20108,359%20107,360%20109,361%20108,362%20109,363%20110,362%20112,363%20111,364%20113,365%20112,366%20113,365%20112,364%20113,363%20113,358%20112,357%20113,356%20113,353%20111,352%20113,351%20113,348%20111,347%20114,346ZM87,276%2087,277%2085,278%2086,280%2085,281%2085,284%2086,285%2085,286%2083,285%2083,282%2083,285%2085,287%2084,288%2085,290%2084,293%2086,294%2085,295%2087,296%2086,297%2087,306%2088,307%2087,308%2090,308%2091,309%2087,311%2088,310%2089,311%2089,316%2090,318%2093,320%2094,319%2096,320%2098,318%20100,318%20101,316%20104,314%20104,311%20103,310%20104,309%20104,301%20103,299%20101,302%2097,299%2099,298%20100,296%2099,291%2097,289%2095,284%2092,283%2093,280%2094,282%2094,280%2092,279%2093,278%2092,278%2091,276%2091,279%2090,280%2088,278%2089,277ZM88,300%2089,299%2092,300%2091,301ZM18,100%2019,102%2016,103%2017,103%2018,105%2022,105%2020,103%2020,101ZM19,39%2020,40%2016,45%2017,46%2013,50%2010,47%209,47%209,48%2010,47%2019,55%2025,58%2029,62%2030,61%2034,68%2038,68%2039,70%2037,71%2043,77%2044,81%2048,88%2048,90%2051,93%2050,94%2052,99%2052,106%2053,108%2055,109%2053,117%2054,114%2056,115%2057,113%2058,115%2057,113%2059,106%2057,106%2055,104%2058,102%2059,104%2058,102%2059,100%2058,99%2059,98%2058,96%2059,95%2057,89%2058,87%2057,85%2058,84%2056,83%2056,80%2050,70%2050,68%2051,67%2052,68%2050,66%2047,68%2045,66%2047,64%2046,63%2045,65%2046,68%2044,70%2040,65%2035,63%2037,62%2038,59%2037,60%2033,58%2038,51%2037,49%2036,49%2037,52%2035,54%2032,54%2031,52%2030,54%2031,55%2031,58%2030,59%2023,55%2025,53%2026,54%2026,53%2024,53%2024,54%2022,55%2020,53%2022,50%2023,51%2026,51%2023,50%2026,46%2025,45%2026,44%2030,47%2029,48%2030,50%2031,50%2031,48%2034,47%2033,44%2032,45%2030,41%2029,43%2028,42%2028,40%2026,37%2025,38%2026,37%2027,39%2024,43%2022,40ZM51,97%2052,96%2055,96%2056,97%2055,98%2052,98ZM32,59%2033,60%2034,59%2036,61%2033,65%2031,64%2030,61ZM15,48%2017,47%2019,49%2020,47%2021,50%2017,53%2016,52%2017,50%2016,50ZM22,41%2023,43%2021,46%2020,45%2020,42ZM17,32%2016,37%2018,36%2019,37%2021,35%2023,37%2022,38%2023,37%2021,35%2022,34%2019,32ZM52,13%2051,14%2047,14%2047,16%2045,17%2044,19%2042,16%2043,18%2041,22%2042,21%2043,24%2041,26%2040,24%2039,25%2038,23%2037,25%2035,23%2036,25%2034,27%2032,24%2027,24%2032,28%2034,32%2049,49%2050,52%2058,63%2060,67%2060,70%2064,76%2064,80%2068,91%2068,103%2069,104%2068,105%2069,106%2068,109%2069,110%2069,113%2068,114%2068,124%2067,125%2067,132%2066,133%2067,136%2066,139%2067,140%2063,146%2064,145%2066,146%2067,145%2068,146%2066,144%2072,140%2074,140%2077,138%2079,139%2083,139%2084,138%2086,140%2088,138%2088,137%2086,136%2087,134%2088,135%2087,133%2086,135%2084,132%2084,130%2086,127%2085,125%2085,119%2084,118%2085,117%2085,103%2084,102%2085,99%2084,97%2086,95%2085,93%2087,91%2086,88%2088,87%2087,86%2089,85%2089,82%2091,81%2090,80%2092,79%2093,77%2092,76%2096,71%20100,63%20100,61%20102,59%20103,47%20101,42%20102,40%2097,33%2098,31%2097,32%2093,27%2094,26%2092,24%2090,24%2089,22%2085,19%2083,19%2081,17%2075,15%2071,16%2070,14%2069,15%2065,15%2064,14%2058,15%2057,14%2058,13%2057,14%2056,13%2053,14ZM36,30%2037,29%2040,30%2038,33ZM6,6%2014,11%2011,8%2012,7ZM92,1%2094,4%2094,7%2097,7ZM46,0%2047,1%2048,0%2051,0%2052,1%2053,0%2054,1%2053,3%2050,3%2049,2%2047,5%2046,4%2046,6%2048,5%2068,5%2069,6%2075,6%2076,7%2086,9%2091,12%2095,16%2096,15%2095,14%2095,11%2096,10%2097,13%2097,9%2096,10%2094,9%2092,11%2089,9%2091,7%2090,4%2089,5%2087,3%2085,5%2082,3%2080,0%2064,0%2063,1ZM82,6%2083,3%2085,5%2083,7ZM62,2%2063,1%2066,1%2067,2%2065,4ZM54,2%2055,1%2058,1%2060,3%2059,4%2055,4ZM73,3%2075,2%2076,0%2079,2%2076,5Z'/%3e%3cpath%20fill='%23f7fbfb'%20stroke='%23f7fbfb'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M79,401%2077,404%2075,411%2074,412%2073,410%2072,411%2073,413%2072,414%2072,417%2073,416%2075,417%2075,423%2074,424%2073,423%2074,428%2078,431%2081,437%2077,430%2077,428%2076,429%2075,428%2076,426%2075,424%2075,411%2076,410%2076,407%2080,401ZM20,401%2020,407%2022,404%2024,404ZM119,388%20119,392%20116,393%20117,397%20119,399%20118,401%20119,408ZM4,386%201,387%200,386%200,460%201,458%200,455%201,454%200,453%201,451%201,448%200,447%200,402%201,401%201,390ZM82,396%2083,398%2081,399%2086,396%2096,396%2099,398%20102,398%20103,400%20106,402%20111,411%20111,413%20111,411%20103,398%2098,394%2096,390%2096,384%2096,388%2095,389%2096,390%2093,393%2091,393%2089,395%2086,395%2085,396%2083,395ZM96,395%2098,394%2099,396%2097,397ZM108,369%20109,370%20110,369%20118,379%20119,379%20119,369%20119,375%20118,376%20116,376%20110,369%20109,370ZM43,350%2039,353%2040,354%2036,356%2033,359%2017,368%2012,372%2013,373%2014,371%2020,368%2021,366%2022,367%2035,360%2041,354ZM74,340%2070,344%2068,344%2069,346%2069,351%2063,361%2052,371%2040,375%2048,376%2056,380%2053,377%2054,376%2057,376%2058,377%2057,376%2057,370%2070,354%2071,351%2069,350%2071,348%2072,349ZM50,375%2053,374%2054,376%2051,377ZM0,330%200,381%201,365%208,358%2013,351%2012,349%207,357%205,358%203,361%201,362%200,361%200,356%201,355%200,338%202,336%200,334ZM73,330%2072,328%2066,325%2059,332%2055,332%2049,329%2047,331%2036,334%2033,338%2029,338%2028,337%2028,340%2031,338%2035,338%2036,337%2041,338%2043,340%2043,342%2037,347%2037,348%2041,348%2048,342%2055,342%2056,341%2057,342%2065,342%2071,339%2073,336ZM2,319%203,333%205,335%206,341%2012,343%2015,347%2016,346%2017,347%2016,349%2019,358%2021,359%2016,349%2020,347%2025,352%2024,354%2021,352%2022,354%2025,353%2028,357%2028,358%2024,361%2028,358%2027,354%2015,341%208,327ZM14,343%2015,342%2018,345%2016,346ZM11,342%2012,341%2015,342%2014,343ZM8,328%209,330%208,332%205,334%204,331ZM68,310%2071,314%2075,316%2075,315ZM112,309%20112,312%20108,316%20107,319%20101,323%20102,324%20101,325%20104,324%20108,320%20111,315ZM81,325%2078,322%2072,319%2068,315%2063,315%2059,311%2053,297%2052,300%2055,308%2056,316%2048,324%2036,330%2033,330%2029,333%2032,334%2034,331%2043,329%2050,325%2053,322%2058,320%2065,320%2068,321%2071,324%2072,323%2074,324%2073,323%2076,322ZM55,288%2053,288%2049,297ZM98,281%20104,289%20103,290%20107,297%20111,300%20112,306%20111,299%20107,291%20103,287%20103,285%20101,282ZM119,263%20117,265%20116,274%20115,275%20116,276%20115,279%20116,280%20116,283%20119,290%20119,281%20118,282%20116,279%20116,273%20119,272ZM56,281%2058,282%2067,266%2072,262%2080,263%2097,276%20103,277%20100,276%20101,274%2097,275%2093,273%2084,265%2081,264%2074,258%2072,255%2071,257%2068,252%2067,254%2069,257%2069,259%2068,260%2067,259%2064,268%2060,272ZM4,246%205,254%205,251%207,248ZM0,240%200,317%200,312%203,310%2013,318%2018,326%2018,330%2019,331%2018,333%2019,334%2018,335%2018,339%2019,340%2019,337%2020,336%2020,326%2017,321%2012,316%202,309%201,307%201,302%202,301%205,302%2010,306%2031,316%2035,320%2040,323%2039,324%2040,324%2040,323%2033,316%2020,309%2016,308%2013,305%207,302%203,298%201,294%201,291%200,290%201,284%206,280%2015,279%2024,283%2028,286%2028,285%2024,279%2021,278%2019,279%2018,278%2010,277%203,274%201,272%200,269%201,268%201,264%200,263ZM77,237%2073,243%2073,248%2075,249%2081,249%2085,253%2086,256%2085,261%2087,264%2096,271%20103,271%20105,273%20105,276%20107,276%20108,275%20101,269%20100,265%20102,261%20105,262%20109,262%20109,261%20107,259%20101,259%2096,255%2094,251%2094,243%2091,239%2087,238%2085,236%2079,236ZM48,232%2047,234%2046,233%2047,235%2047,240%2040,247%2039,250%2030,263%2032,264%2030,266%2029,265%2028,266%2029,265%2030,267%2026,271%2025,270%2026,268%2024,270%2015,271%2010,269%208,266%209,268%206,270%204,268%204,270%2010,273%208,272%209,271%2013,271%2015,273%2014,274%2017,275%2023,275%2024,276%2031,275%2036,278%2043,280%2043,278%2038,275%2033,270%2033,263%2043,245%2049,238ZM119,229%20113,232%20114,234%20117,232%20119,232ZM46,226%2040,234%2035,236%2032,234%2032,231%2033,230%2033,226%2032,226%2030,228%2031,234%2021,242%2020,244%2015,244%2010,248%208,254%208,260%2013,267%2017,267%2018,268%2021,267%2022,258%2025,255%2032,254%2034,252%2037,246%2044,238%2043,237%2043,231%2045,229%2047,229ZM103,214%2087,225%2080,233%2086,233%2088,234%2089,229%2093,222%2098,217ZM119,200%20118,203%20113,209%20105,213%20115,209%20119,209ZM21,178%2022,180%2032,183%2043,190%2045,189%2043,186%2040,186%2032,180%2030,180%2024,177ZM113,167%20109,170%20109,176%20113,183%20118,188%20119,192%20119,185%20114,181%20112,177%20113,172%20115,168ZM82,142%2075,144%2070,149%2072,148%2078,148%2079,150%2077,152%2071,152%2070,151%2070,155%2067,159%2069,160%2069,163%2064,169%2062,166%2061,167%2062,169%2060,171%2059,170%2056,173%2057,174%2055,176%2054,175%2055,178%2050,180%2052,185%2065,173%2073,160%2078,156ZM61,141%2059,144%2060,148%2057,154%2058,156%2056,159%2056,164%2055,165%2056,169%2057,167%2057,158%2060,149ZM32,138%2032,141%2030,145%2029,157%2028,158%2028,161%2030,165%2030,152%2031,151%2031,146%2034,139ZM16,122%2015,124%2014,123%2015,126%2017,126ZM17,120%2020,121%2020,126%2024,126%2028,132%2032,133%2036,137%2036,135%2033,134%2032,131%2028,128%2028,126%2030,125%2028,122%2022,121%2018,119ZM119,104%20111,103%20107,105%20103,113%20104,116%20109,120%20113,119%20113,115%20111,113%20111,111%20114,108%20117,108%20119,110ZM23,24%2022,25%2023,27%2027,29%2041,45%2045,52%2048,54%2047,55%2048,54%2050,56%2049,58%2056,68%2056,71%2059,73%2058,76%2060,77%2061,86%2064,94%2063,95%2065,98%2064,99%2065,100%2064,101%2064,104%2065,105%2064,107%2064,114%2065,115%2064,122%2065,123%2063,126%2064,130%2066,108%2065,107%2065,94%2064,93%2065,92%2064,91%2064,87%2063,86%2061,76%2056,67%2056,65%2047,52%2046,49%2025,25ZM119,1%20119,4%20117,5%20114,1%20115,2%20115,8%20117,12%20117,19%20118,20%20118,28%20116,30%20115,30%20113,27%20113,23%20108,12%2099,1%2098,2%20102,5%20101,6%20105,8%20107,12%20106,13%20108,15%20108,17%20113,28%20114,44%20113,46%20111,47%20109,43%20108,36%20105,32%20104,28%2099,22%2095,20%2086,12%2083,12%2074,9%2069,9%2068,8%2051,8%2050,9%2031,13%2015,23%2010,27%205,34%202,36%200,33%200,14%202,11%205,12%2016,19%2017,17%2010,11%208,11%202,8%200,6%201,0%200,0%200,237%209,232%2019,229%2027,228%2021,228%2020,229%2013,230%202,235%201,234%201,226%200,225%200,213%201,212%207,210%2026,210%2042,215%2056,226%2059,231%2057,233%2055,233%2051,230%2051,232%2057,237%2060,241%2060,243%2063,245%2061,255%2057,261%2061,259%2064,254%2064,249%2063,248%2064,246%2061,242%2062,241%2062,233%2063,232%2065,222%2072,207%2092,177%2092,175%2096,167%2097,148%2097,157%2095,159%2096,160%2095,161%2096,162%2095,163%2095,166%2096,167%2093,169%2094,170%2091,173%2090,176%2086,181%2081,185%2079,185%2073,188%2064,187%2062,186%2059,182%2058,186%2063,192%2061,195%2057,193%2056,194%2049,186%2044,174%2043,161%2043,174%2044,175%2044,179%2047,186%2053,193%2057,195%2057,197%2056,198%2048,197%2040,193%2037,190%2035,190%2032,188%2036,194%2051,202%2055,203%2059,207%2059,211%2054,215%2047,215%2023,208%2012,208%205,210%202,210%201,209%201,205%2011,197%206,199%201,199%200,198%200,188%201,187%201,184%200,183%200,165%202,163%206,163%2012,159%2018,158%2013,144%2011,142%2011,140%200,125%200,103%201,102%200,99%200,91%201,90%200,77%202,75%206,75%2013,79%2017,80%2029,92%2033,98%2037,109%2037,115%2038,116%2037,127%2038,126%2038,120%2039,119%2039,114%2038,113%2036,102%2028,89%2020,81%207,73%201,71%200,54%202,52%204,52%2016,58%2028,67%2032,72%2034,73%2035,76%2041,81%2040,82%2045,91%2049,105%2049,121%2048,122%2048,134%2047,135%2048,135%2048,131%2049,130%2049,120%2050,119%2049,117%2049,110%2050,109%2049,108%2048,95%2038,75%2025,61%2016,56%2012,52%208,51%200,46%203,41%203,39%209,31%2022,20%2033,15%2035,15%2038,13%2042,13%2047,11%2053,11%2054,10%2062,10%2063,11%2065,10%2066,11%2071,11%2072,12%2080,13%2090,18%20100,28%20105,38%20105,42%20107,48%20106,59%20102,69%2094,80%2094,81%2096,79%2097,80%2095,84%20103,72%20112,65%20116,63%20119,63%20119,55%20117,56%20115,53%20115,44%20116,42%20119,40ZM1,135%204,136%208,147%208,156%202,163%200,161%200,136Z'/%3e%3cpath%20fill='%234897e2'%20stroke='%234897e2'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M4,472%208,473%208,472%205,470ZM45,464%2042,465%2041,467%2040,466%2040,468%2037,470%2036,473%2043,473%2042,471%2044,469%2041,471%2039,469%2041,468%2042,466%2045,466ZM6,388%204,394%204,392%207,391%206,390%207,388%209,390%2010,389%2012,391%2014,391%2015,392%2014,395%2016,396%2016,394%2013,390%209,388ZM22,382%2021,385%2022,386%2020,389%2021,396%2028,402%2028,400%2030,398%2032,400%2030,401%2030,402%2031,401%2032,403%2035,404%2036,406%2037,405%2041,407%2042,404%2041,404%2035,397%2030,396%2029,398%2026,395%2026,394%2029,392%2024,390%2025,389%2024,381%2023,383ZM14,357%206,364%204,369%205,370%209,370%2012,366%2016,364%2016,361ZM64,347%2059,345%2050,345%2048,346%2043,356%2038,361%2032,365%2033,366%2034,374%2037,372%2040,372%2043,370%2050,368%2058,362%2064,353ZM7,345%204,346%205,347%204,348%205,352%208,348ZM79,338%2078,339%2078,345%2075,350%2076,353%2073,355%2073,357%2071,358%2069,361%2069,363%2064,367%2062,372%2062,375%2064,376%2063,377%2064,379%2065,377%2066,378%2067,389%2068,390%2063,398%2062,397%2065,400%2063,401%2061,406%2062,408%2059,410%2059,413%2056,416%2055,415%2053,418%2050,418%2049,420%2048,419%2049,420%2048,421%2049,424%2047,426%2049,427%2050,429%2047,430%2048,433%2049,432%2051,433%2052,431%2054,435%2052,436%2054,435%2055,438%2056,437%2058,438%2057,437%2058,436%2057,437%2053,434%2054,432%2056,433%2057,431%2059,431%2060,432%2058,434%2060,435%2061,434%2063,435%2062,434%2064,433%2063,431%2060,435%2059,434%2061,429%2063,427%2064,429%2065,429%2065,427%2062,426%2064,424%2065,425%2068,423%2065,425%2064,423%2062,422%2063,421%2066,422%2065,421%2066,420%2069,421%2067,419%2067,418%2069,417%2067,416%2068,412%2067,413%2066,412%2068,408%2067,404%2068,403%2070,405%2069,404%2070,403%2069,404%2068,402%2071,401%2070,399%2073,396%2072,394%2081,382%2083,377%2082,376%2084,375%2084,372%2086,369%2085,368%2086,366%2084,361%2085,360%2084,361%2082,360%2083,361%2081,362%2079,359%2080,357%2079,355%2082,354%2081,353%2082,352%2081,350%2082,347%2079,342%2080,339ZM56,421%2057,420%2060,421%2058,423ZM24,335%2022,344%2029,351%2032,356%2035,352%2033,348%2036,342%2032,342%2031,343%2030,342%2027,344%2025,342%2024,343%2023,342ZM35,325%2033,324%2032,326%2031,325%2025,325%2024,326%2026,327%2024,328%2025,330%2023,333%2024,333%2027,329%2030,327%2033,327ZM12,298%2012,300%2019,306%2024,307%2027,310%2035,314%2043,321%2046,321%2051,316%2051,307%2049,304%2047,306%2045,306%2043,303%2042,304%2035,299%2031,301%2030,303%2027,299%2025,299%2022,297%2020,298%2018,296%2017,298%2014,296%2015,295%2014,297ZM100,292%2099,295%20100,294%20101,296%20100,298%2098,299%20101,301%20103,298%20104,300ZM105,280%20107,285%20108,284%20109,285%20109,288%20110,288%20111,286%20112,287%20113,286%20110,282%20110,279ZM75,266%2077,267%2076,268%2080,270%2080,272%2082,272%2084,274%2083,276%2081,277%2084,278%2082,281%2084,282%2084,285%2083,287%2084,287%2083,286%2085,285%2084,284%2084,281%2085,280%2084,278%2088,275%2090,277%2089,278%2090,279%2090,275%2086,272%2085,270%2079,267%2078,268%2077,266ZM85,273%2086,272%2089,274%2086,275ZM53,239%2051,240%2047,245%2046,248%2047,249%2044,251%2046,253%2045,255%2047,256%2047,259%2049,261%2048,264%2049,264%2049,262%2051,260%2053,260%2056,257%2058,250%2057,243%2056,243%2055,240%2054,241ZM116,238%20114,238%20106,246%20104,251%20104,256%20107,255%20114,261%20114,263%20111,266%20108,265%20107,266%20106,265%20104,266%20105,268%20112,274%20112,278%20112,273%20110,272%20112,271%20113,269%20113,264%20117,258%20116,257%20117,256%20116,255%20117,252%20115,250%20117,249%20116,243%20117,242%20116,241%20117,240ZM117,214%20115,213%20106,216%2098,221%2095,225%2092,231%2092,236%2097,243%2099,242%20100,239%20107,232%20114,228%20117,225%20116,222%20117,221%20116,219ZM34,199%2036,202%2036,205%2037,204%2038,207%2039,206%2041,210%2044,211%2048,211%2049,210%2052,211%2053,210%2052,208%2053,207%2052,206%2051,207%2043,202ZM37,164%2035,165%2034,170%2037,172%2039,172%2039,168%2038,167%2039,165ZM53,156%2051,157%2050,156%2051,157%2050,158%2047,158%2047,161%2046,162%2047,163%2047,168%2046,169%2047,172%2049,171%2050,172%2052,170%2051,168%2052,167%2051,163ZM78,139%2067,144%2065,142%2066,140%2065,137%2066,136%2065,137%2064,144%2065,142%2067,144%2063,147%2061,158%2066,155%2067,146%2070,143ZM86,121%2087,127%2085,130%2085,132%2087,136%2086,137%2084,136%2086,137%2088,136%2089,138%2084,145%2083,148%2084,151%2082,153%2081,157%2076,161%2068,174%2064,178%2063,181%2065,184%2069,184%2070,185%2081,181%2083,178%2086,176%2089,171%2089,168%2091,163%2091,158%2092,157%2091,156%2092,154%2091,151%2092,150%2091,149%2091,143%2089,138%2089,134%2088,132%2086,131%2087,128ZM83,158%2085,157%2087,159%2084,160ZM85,145%2086,144%2089,145%2087,147ZM86,133%2087,132%2089,135%2088,136ZM58,88%2060,95%2059,96%2060,97%2059,99%2060,100%2059,102%2056,104%2060,106%2059,107%2059,112%2057,114%2056,113%2057,114%2056,116%2053,114%2053,111%2054,110%2055,111%2057,108%2055,111%2054,109%2053,109%2054,117%2053,118%2053,124%2052,125%2052,131%2051,132%2051,138%2054,145%2055,145%2057,142%2057,138%2058,137%2058,133%2060,127%2060,121%2061,120%2061,104%2060,103%2060,94ZM58,123%2059,126%2057,127%2056,126ZM54,121%2056,120%2059,122%2058,123%2055,123ZM4,78%204,91%203,92%203,100%204,101%203,102%203,114%204,115%203,116%204,117%203,119%204,120%203,121%203,124%207,128%2017,147%2019,149%2024,149%2027,146%2029,136%2027,134%2025,134%2023,132%2023,130%2021,129%2017,131%2015,130%2010,125%207,118%207,114%2010,112%2012,114%2015,114%2017,116%2023,118%2026,117%2029,120%2030,119%2033,124%2035,118%2034,117%2033,106%2029,99%2029,97%2027,96%2026,93%2021,87%2014,82ZM15,103%2020,100%2023,105%2022,106%2018,106%2017,104ZM18,92%2019,93%2018,95%2020,97%2018,99%2016,96%2016,94ZM51,68%2051,70%2057,80%2057,83%2058,83ZM4,57%204,68%206,70%208,70%2010,72%2017,75%2018,77%2021,78%2023,77%2024,78%2023,79%2027,84%2028,83%2031,88%2037,95%2038,100%2041,104%2040,105%2041,107%2040,109%2042,111%2042,120%2041,121%2041,127%2040,128%2041,131%2043,132%2045,128%2045,120%2046,119%2045,117%2046,115%2046,109%2045,108%2046,106%2043,98%2043,94%2040,90%2039,86%2033,77%2025,68%208,57ZM11,33%205,42%206,47%208,48%208,47%2010,46%2011,47%2010,48%2011,49%2012,48%2014,50%2013,49%2015,47%2016,49%2018,50%2017,52%2016,51%2018,52%2020,50%2020,48%2019,50%2015,47%2016,46%2015,45%2020,39%2022,39%2023,41%2021,42%2021,45%2023,41%2024,42%2027,37%2029,40%2029,42%2030,40%2032,42%2032,44%2033,43%2034,44%2033,46%2034,45%2035,47%2032,48%2032,50%2030,51%2028,48%2029,47%2026,45%2027,46%2024,50%2027,51%2026,52%2023,52%2022,51%2021,53%2022,54%2021,55%2023,54%2030,58%2030,55%2032,53%2035,53%2037,55%2030,63%2031,61%2032,64%2034,63%2035,65%2037,66%2035,64%2038,63%2040,64%2044,69%2046,66%2047,67%2050,65%2046,60%2040,49%2033,41%2031,40%2024,31%2018,27ZM46,62%2048,64%2045,67%2044,65ZM38,58%2039,60%2038,62%2035,64%2034,62ZM33,59%2034,58%2037,59%2035,61ZM42,55%2043,57%2041,59%2040,57ZM39,53%2040,52%2042,55%2041,56ZM23,53%2026,52%2027,54%2024,55ZM35,49%2037,48%2039,51%2037,53ZM15,37%2016,35%2015,34%2017,31%2019,31%2023,34%2019,38%2018,37%2017,38ZM7,17%204,17%204,27%2012,22%2011,19ZM46,15%2042,17%2041,16%2041,19%2040,20%2039,18%2034,18%2026,22%2027,23%2032,23%2033,24%2031,26%2033,24%2035,28%2034,26%2036,23%2037,24%2038,22%2039,24%2040,23%2041,25%2042,24%2042,22%2041,23%2040,21%2043,16%2044,18ZM82,1%2082,2%2084,3%2083,6%2087,2%2089,4%2090,3%2092,7%2090,9%2092,10%2093,9%2096,11%2096,14%2097,15%2096,17%2097,18%2098,17%2099,19%20104,23%20106,23%20106,21%20104,19%20103,15%20101,16%2099,15%20100,12%2098,11%2099,10%2098,8%2094,8%2091,1%2084,1%2083,2ZM97,8%2098,9%2098,13%2097,14%2095,10ZM4,5%206,7%205,6%206,5%2012,6%2013,7%2012,8%2015,12%2017,11%2018,14%2021,15%2025,12%2027,12%2031,8%2035,9%2041,7%2043,5%2044,7%2046,3%2047,4%2049,1%2050,2%2053,2%2053,1%2052,2%2051,1%2048,1%2047,2%2045,0%2044,1%2039,1%2038,0%2037,1%2026,1%2025,0%2024,1%2023,0%2018,1%2017,0%2014,0%2013,1%205,1ZM23,8%2024,11%2022,13%2020,11%2021,9ZM32,8%2033,7%2036,8%2035,9ZM30,4%2031,6%2029,10%2028,9%2028,5ZM21,7%2022,4%2025,6%2022,8Z'/%3e%3cpath%20fill='%235b83a2'%20stroke='%235b83a2'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M106,465%20109,470%20109,472%20112,473ZM33,461%2032,461%2031,463%2030,462%2029,464%2028,463%2029,464%2025,467%2024,466%2025,467%2022,471%2023,471%2024,473%2026,473%2027,470%2029,471%2028,470%2029,468%2028,466%2029,464%2032,463ZM115,443%20114,445%20112,444%20113,445%20111,447%20112,448%20111,449%20112,450%20111,452%20113,453%20111,454%20112,455%20111,456%20114,458%20113,461%20116,465%20115,464%20116,452%20115,452%20116,453%20115,454%20112,452%20116,449%20115,448%20116,447%20116,444ZM70,423%2068,424%2067,421%2063,422%2065,423%2063,426%2065,426%2066,429%2064,430%2063,428%2060,433%2057,432%2056,434%2054,433%2053,435%2052,432%2051,434%2049,433%2048,434%2046,430%2049,429%2049,428%2047,427%2041,428%2036,425%2036,426%2038,427%2036,428%2037,431%2041,434%2044,438%2043,440%2044,439%2049,442%2048,443%2049,442%2051,445%2052,444%2054,447%2057,447%2058,446%2059,447%2058,449%2060,448%2061,449%2059,447%2060,444%2059,443%2061,441%2062,442%2065,441%2066,442%2067,441%2072,444%2076,449%2075,451%2076,453%2073,458%2074,459%2070,462%2061,462%2060,463%2058,461%2057,462%2054,461%2050,463%2049,461%2046,461%2047,462%2046,463%2044,462%2042,463%2038,468%2036,469%2039,468%2041,470%2043,469%2044,470%2043,471%2044,473%2047,473%2048,471%2050,471%2052,473%2054,473%2056,471%2058,473%2061,473%2062,472%2064,473%2066,472%2067,473%2073,473%2074,472%2075,473%2076,471%2077,473%2078,473%2078,472%2075,470%2077,466%2076,465%2078,464%2078,461%2080,459%2079,458%2080,455%2079,454%2078,445%2079,444%2081,446%2076,443%2079,442%2078,440%2076,439%2076,437%2074,436%2074,434%2072,433%2073,432%2071,431%2072,430%2070,429%2071,428%2069,427ZM52,467%2053,466%2056,467%2055,468ZM39,466%2040,465%2042,468%2040,469ZM45,463%2046,466%2045,467%2042,467%2041,465ZM54,438%2055,435%2058,437%2055,439ZM63,430%2065,433%2063,434%2064,435%2062,436%2060,434ZM73,398%2071,399%2070,398%2072,401%2069,402%2068,406%2070,408%2069,405%2072,401%2071,399ZM108,388%20112,395%20112,399%20110,401%20108,400%20108,399%20111,403%20115,412%20114,413%20115,416%20116,416%20115,415%20116,413%20115,412%20114,397%20112,392%20109,388ZM7,378%2010,381%207,383%209,383%2010,385%2012,385%2013,382%2011,381%2014,380%2011,380%2010,381ZM9,382%2011,381%2012,384%2011,385ZM21,370%2021,371%2019,372%2020,373%2020,378%2019,379%2020,380%2020,386%2021,386%2020,385%2021,384%2021,379%2023,377%2024,378%2023,376%2024,375%2024,372%2023,373ZM116,341%20104,347%20114,342%20115,343%20115,346%20114,347%20114,364%20115,365%20112,367%20106,361%20115,369%20116,371%20116,366%20115,365%20116,364%20115,363%20116,362%20116,354%20117,353%20116,352%20117,351%20116,349%20117,347%20116,343%20117,342ZM7,307%208,308%207,309%209,311%2012,312%2013,314%2014,312%2015,313%2015,315%2018,317%2020,321%2021,319%2024,321%2021,323%2022,323%2023,325%2025,324%2031,324%2032,325%2033,322%2030,319%2027,320%2026,319%2028,318%2021,314%2018,316%2017,315%2018,313%2015,313%2013,311%2011,312%2010,311%2011,310ZM20,314%2021,315%2020,318%2019,317ZM84,298%2084,299%2081,301%2081,302%2083,302%2084,304%2083,305%2082,304%2080,305%2082,306%2076,310%2080,308%2081,309%2080,310%2081,311%2080,314%2085,318%2091,320%2089,319%2088,315%2086,314%2088,313%2088,311%2087,313%2086,312%2087,309%2086,308%2086,300%2085,298ZM102,295%20105,299%20105,302%20106,303%20105,304%20107,305%20105,306%20105,308%20107,309%20106,311%20105,310%20106,311%20105,314%20106,314%20105,313%20107,312%20107,309%20105,307%20107,306%20107,304%20105,302%20106,300ZM58,289%2057,292%2057,291%2059,290%2060,292%2062,293%2061,295%2057,298%2059,298%2061,300%2061,302%2064,303%2065,301%2063,300%2064,299%2061,300%2059,298%2062,296%2063,297%2066,296%2063,297%2061,294%2062,293%2063,294%2066,294%2067,293%2069,294%2068,293%2065,294%2063,291ZM3,287%204,293%209,299%208,301%209,300%2013,302%2015,304%2014,305%2015,304%2017,305%2010,299%2013,297%2014,295%2017,297%2016,298%2017,296%2015,296%2014,295%2015,294%2018,294%2020,297%2021,295%2023,297%2027,298%2029,301%2034,299%2034,297%2036,296%2037,297%2036,299%2039,300%2042,303%2045,302%2042,298%2043,297%2046,298%2045,296%2047,295%2046,294%2047,291%2045,287%2045,284%2037,281%2035,282%2030,278%2028,279%2026,277%2031,284%2036,287%2035,290%2032,291%2031,294%2029,293%2030,292%2029,290%2022,285%2019,284%2017,285%2015,282%208,282%207,284%206,283ZM42,294%2043,293%2046,294%2044,296ZM38,293%2039,294%2038,297%2037,296ZM4,293%207,292%208,294%207,295ZM6,286%207,289%204,290%203,289%205,288ZM37,283%2038,284%2037,287%2036,286ZM33,280%2034,281%2033,284%2032,283ZM113,270%20113,271%20110,273%20108,271%20111,274%20111,276%20108,279%20106,279%20110,278%20112,283%20111,284%20112,283%20114,286%20109,289%20108,288%20108,285%20107,286%20104,280%20108,288%20111,290%20110,291%20113,295%20115,301%20115,306%20116,307%20115,310%20116,311%20112,321%20108,325%20105,326%20107,327%20106,326%20107,325%20109,326%20112,324%20111,323%20112,321%20114,322%20117,315%20117,291%20113,284%20113,281%20112,282%20111,281%20112,279%20110,273%20113,272ZM68,267%2069,269%2067,271%2066,270%2067,273%2063,279%2065,278%2066,280%2064,282%2062,281%2064,286%2066,287%2067,286%2071,290%2072,288%2073,289%2075,288%2077,290%2077,292%2074,294%2075,298%2077,299%2074,295%2079,293%2081,295%2079,296%2082,297%2080,299%2081,299%2081,298%2084,296%2082,293%2083,291%2083,288%2081,284%2082,283%2080,282%2080,281%2082,280%2080,277%2082,276%2081,273%2080,273%2079,270%2075,268%2076,267%2074,266%2071,266%2069,268ZM77,290%2079,289%2080,291%2078,292ZM71,282%2072,284%2070,286%2068,284ZM76,279%2078,283%2076,289%2074,287%2075,285%2073,284ZM67,280%2068,279%2071,281%2068,282ZM72,276%2074,281%2073,282%2071,281%2071,279%2070,280%2068,279ZM67,272%2069,271%2070,273%2068,274ZM43,251%2039,257%2040,258%2038,259%2038,262%2036,265%2037,267%2036,269%2043,275%2044,274%2043,275%2042,273%2043,272%2046,272%2050,275%2048,276%2049,278%2051,277%2052,279%2055,277%2056,273%2059,270%2058,271%2056,268%2056,265%2057,264%2056,264%2055,266%2052,261%2050,262%2049,265%2047,264%2049,260%2048,261%2046,259%2046,256%2044,255%2045,253%2044,253ZM28,231%2027,234%2026,231%2023,231%2019,233%2018,232%2016,234%2014,233%2011,234%2012,235%2011,237%2010,236%209,237%207,236%205,238%202,237%203,238%201,239%205,239%207,241%205,243%207,245%209,245%208,244%209,241%2012,243%2013,241%2014,242%2017,240%2019,241%2022,237%2028,233ZM3,214%204,216%203,218%205,219%203,220%203,225%205,226%203,227%204,228%204,231%203,232%205,228%207,230%2010,228%2012,228%2013,226%2015,227%2021,225%2023,227%2025,227%2024,226%2028,224%2029,225%2034,221%2038,223%2037,225%2039,224%2040,225%2043,225%2045,224%2046,222%2050,227%2052,227%2051,227%2047,222%2044,222%2043,219%2042,220%2040,217%2041,216%2039,218%2036,218%2035,217%2037,216%2032,216%2030,219%2029,217%2031,214%2029,216%2027,213%2029,212%2025,214%2024,213%2022,214%2020,212%2021,211%2019,212%2010,211%2013,211%2014,212%205,215ZM111,184%20109,185%20110,187%20108,193%20106,195%20104,195%20105,195%20106,197%20105,199%20102,201%20102,204%20100,207%2097,209%2095,208%2096,209%2092,212%2091,211%2092,212%2089,216%2088,215%2088,216%2076,227%2075,232%2074,233%2071,232%2072,234%2075,235%2073,236%2075,235%2075,233%2078,231%2084,224%2083,222%2087,219%2088,217%2090,219%2089,220%2092,215%2098,214%2099,212%20105,210%20106,207%20107,209%20115,202%20115,200%20117,198%20116,197%20117,193%20114,192%20114,191%20116,190ZM104,202%20104,200%20106,199%20107,201%20105,203ZM115,196%20116,197%20115,200%20114,199ZM4,207%206,206%207,203%209,206%2017,205%2018,206%2017,207%2015,207%2017,207%2019,205%2020,207%2023,205%2024,206%2023,207%2024,206%2029,206%2033,208%2031,209%2035,208%2039,210%2038,211%2040,210%2039,207%2038,209%2037,208%2037,205%2036,206%2034,205%2035,202%2032,200%2033,198%2031,195%2034,193%2036,195%2035,196%2037,198%2034,193%2031,194%2023,190%2025,188%2026,189%2025,187%2026,186%2025,187%2021,187%2020,184%2020,187%2019,188%2020,189%2018,191%2017,196%2016,197%2015,196%2011,201%208,200%209,201ZM22,190%2023,192%2021,194%2020,192ZM23,164%2026,166%2025,167%2026,169%2025,170%2026,169%2025,167%2027,166%2028,167%2028,172%2032,173%2033,175%2034,174%2032,171%2033,170%2030,171%2028,167ZM26,153%2024,154%2022,152%2023,151%2018,153%2017,152%2021,157%2021,159%2018,160%2022,159%2025,161%2024,159%2025,158%2024,157ZM39,140%2039,142%2041,143%2039,147%2038,146%2039,150%2041,147%2040,145%2041,144%2042,145ZM117,119%20112,125%20109,123%20108,124%20107,123%20107,124%20109,125%20108,126%20110,124%20112,125%20111,127%20112,129%20113,128%20114,129%20114,132%20117,135%20118,138%20117,140%20118,141%20117,142%20118,143%20118,148%20117,150%20118,150%20118,141%20117,140%20118,139%20117,136%20118,130%20117,129%20118,128%20118,122%20117,121%20118,120ZM117,70%20118,71%20117,70%20115,72%20114,70%20112,69%20106,74%20107,75%20104,78%20103,77%20101,82%20101,85%2098,87%2098,89%2096,91%2097,92%2094,94%2095,95%2093,99%2094,102%2092,104%2093,106%2092,109%2094,112%2093,118%2095,117%2097,112%2095,111%2095,108%2097,107%2096,104%2098,103%2097,101%2099,98%2098,95%20100,93%20100,91%20104,86%20104,84%20106,81%20110,78ZM102,0%20105,4%20104,5%20101,2%20105,6%20104,5%20105,4%20105,1%20106,0%20108,1%20110,4%20108,7%20111,12%20113,12%20111,8%20110,1%20108,0Z'/%3e%3cpath%20fill='%238fb0d4'%20stroke='%238fb0d4'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M8,462%207,465%208,468%2011,471%2014,470%2015,471%2014,472%2016,473%2016,471%2018,470%2019,473%2021,471%2023,473%2023,472%2021,471%2023,468%2019,470%2017,468%2016,469%2015,468%2013,469%2012,466%2013,465%2014,466%209,463%2010,462%209,463ZM4,458%203,464%204,463%205,464%205,462%207,460%205,461ZM6,374%207,375%204,376%205,378%203,380%204,379%207,380%208,382%209,381%2011,384%2011,382%208,381%207,379%208,378%209,379%2012,378%2010,377%209,375%208,377ZM23,369%2022,370%2023,371%2025,370%2026,371%2026,375%2025,376%2026,378%2025,379%2026,389%2025,390%2028,390%2030,392%2029,393%2027,392%2028,393%2027,395%2029,397%2030,395%2035,396%2038,400%2043,404%2041,408%2037,406%2040,407%2041,409%2042,408%2046,412%2046,414%2049,419%2050,417%2053,417%2055,414%2056,415%2058,413%2058,410%2061,408%2060,406%2062,401%2064,400%2062,398%2065,394%2061,397%2058,398%2057,397%2056,398%2052,393%2056,388%2057,389%2057,388%2055,387%2056,386%2055,384%2052,383%2053,382%2051,381%2050,382%2048,380%2046,380%2045,378%2041,379%2039,377%2038,377%2037,380%2035,379%2032,380%2031,379%2032,377%2031,378%2030,377%2031,371%2031,374%2030,375%2028,372%2029,369%2028,368%2027,369%2025,368%2026,369%2025,370ZM26,389%2027,386%2029,388%2027,390ZM4,343%204,345%207,344%209,346%209,348%205,353%204,351%204,355%209,349%209,345ZM112,329%20108,332%20106,332%20105,334%20101,335%20100,334%20101,333%20100,333%20100,337%20105,335%20107,332ZM83,327%2076,330%2078,334%2078,338%2079,337%2081,339%2080,342%2083,347%2082,349%2083,351%2082,353%2083,354%2081,356%2080,355%2081,357%2080,359%2081,360%2082,359%2086,362%2086,365%2087,366%2086,372%2088,368%2089,360%2090,359%2090,347%2089,346%2090,343%2088,342%2089,340%2087,338%2088,336%2086,335%2087,333%2085,332%2086,331%2083,330%2082,328ZM4,315%204,317%208,319%207,320%2010,322%209,323%2014,333%2015,333%2016,331%2013,323%207,317%205,317ZM64,260%2061,263%2058,264%2060,265%2058,270%2061,267%2061,264ZM21,183%2021,186%2027,185%2028,187%2027,188%2026,187%2027,188%2027,192%2026,193%2025,192%2023,193%2022,191%2020,194%2019,193%2020,194%2022,192%2023,193%2025,192%2026,193%2028,190%2029,192%2031,193%2028,185ZM36,178%2036,180%2037,181%2038,180%2039,183%2041,182%2039,178%2037,179ZM24,163%2019,164%2017,161%2018,162%2017,165%2015,165%2014,164%2015,163%2010,166%209,168%208,167%208,168%205,170%206,172%203,174%206,180%203,184%204,185%204,190%203,191%204,193%203,194%204,194%205,196%2010,193%2011,194%2016,189%2014,187%2015,186%2015,183%2017,181%2018,182%2017,181%2016,182%2014,179%2016,176%2017,179%2018,179%2017,177%2023,173%2024,174%2027,174%2032,177%2035,175%2037,176%2035,174%2033,176%2032,174%2028,173%2027,172%2027,167%2023,165%2025,164ZM13,187%2015,190%2013,192%2011,190ZM9,176%2010,178%208,180%207,178ZM12,174%2014,175%2013,176%2014,177%2013,179%2010,178ZM40,140%2041,142%2039,146%2040,144%2042,147%2039,151%2035,151%2034,150%2035,151%2033,154%2034,158%2035,156%2043,151%2042,152%2040,151%2040,150%2042,149%2042,147%2043,146%2044,148%2045,147%2043,146%2043,144ZM40,143%2041,142%2043,145%2042,146ZM30,126%2031,127%2030,128%2032,129%2034,132%2036,132%2037,134%2040,136%2040,138%2043,140%2046,139%2039,133%2037,133%2036,131ZM117,71%20116,73%20107,81%20105,84%20105,86%20101,91%20101,93%2099,95%20100,98%2098,100%2099,103%2097,104%2098,107%2096,108%2096,111%2097,111%2098,113%2096,117%2093,119%2094,123%2097,128%2096,129%2098,130%2097,132%2097,137%2099,142%2099,146%20101,148%20100,149%20100,157%20102,159%20101,160%20102,162%20100,164%2099,163%20100,164%2098,168%2098,171%2094,180%2091,184%2092,185%2089,189%2088,188%2089,190%2087,193%2086,197%2082,200%2084,203%2083,204%2083,208%2080,210%2082,209%2083,211%2080,212%2076,220%2075,219%2076,220%2076,222%2074,224%2075,226%2074,227%2071,224%2069,225%2068,223%2069,225%2067,226%2068,228%2066,231%2067,232%2067,235%2070,239%2067,241%2068,240%2069,241%2072,236%2074,235%2072,235%2070,232%2071,231%2074,232%2075,227%2077,226%2083,219%2084,220%2085,219%2084,218%2086,217%2088,214%2089,215%2090,213%2095,209%2094,208%2095,207%2097,208%2099,207%20102,200%20104,199%20105,202%20107,199%20105,200%20104,199%20105,196%20103,195%20107,193%20109,187%20108,185%20110,183%20106,177%20106,168%20108,167%20111,163%20112,164%20117,164%20117,155%20116,154%20117,151%20116,150%20117,148%20117,143%20116,142%20117,141%20116,140%20117,138%20115,134%20116,133%20115,134%20113,132%20113,129%20112,130%20110,127%20112,123%20114,122%20110,123%20112,124%20109,126%20107,125%20106,123%20107,122%20108,123%20104,121%20100,116%20100,110%20103,104%20106,101%20114,100%20115,99%20117,101%20115,98%20117,92%20116,91%20116,84%20117,83%20116,80%20117,76%20116,74ZM90,204%2092,203%2094,205%2092,206ZM101,154%20102,155%20101,158%20100,157Z'/%3e%3cpath%20fill='%233c5a77'%20stroke='%233c5a77'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M42,455%2041,456%2040,455%2038,457%2040,455%2041,456%2038,460%2036,458%2033,459%2034,461%2032,464%2030,464%2029,466%2030,468%2029,470%2027,471%2027,473%2032,473%2033,468%2041,461%2044,460%2043,461%2041,458ZM77,443%2080,444%2079,445%2079,448%2080,449%2080,454%2081,455%2080,458%2081,459%2079,461%2079,464%2077,465%2078,466%2076,470%2077,471%2076,473%2077,471%2078,471%2079,473%2081,472%2082,473%2080,471%2083,469%2082,468%2084,467%2084,461%2085,460%2084,459%2085,458%2083,452%2084,449%2083,450%2079,445%2080,444ZM37,432%2039,435%2038,437%2039,436%2042,438%2040,440%2041,439%2043,441%2042,442%2043,441%2047,445%2046,446%2047,445%2054,450%2053,451%2054,450%2059,452%2062,452%2063,451%2062,449%2061,450%2060,449%2058,450%2057,449%2058,447%2057,448%2054,448%2052,445%2051,446%2049,443%2045,441%2041,435ZM115,425%20114,425%20115,426%20114,427%20114,431%20113,432%20112,431%20114,434%20112,437%20111,435%20112,439%20111,440%20110,439%20111,440%20111,446%20110,447%20111,448%20110,447%20114,444%20115,442%20116,443%20115,440%20117,439%20117,434%20116,435%20114,431%20115,430%20117,431%20117,430%20114,429%20115,428ZM33,413%2031,416%2031,418%2034,427%2036,429%2035,428%2036,427%2038,428%2035,426%2035,425%2037,424%2037,422%2037,423%2035,424%2034,423%2035,422%2033,421%2036,420%2037,418%2039,418%2039,417%2036,416%2037,414%2038,415%2039,414%2038,413%2036,415%2035,413%2035,414%2033,415%2032,414ZM4,390%204,391%202,392%202,401%203,402%203,395%202,393ZM13,368%2014,369%2013,368%2010,371%2011,372%2010,374%2011,376%2013,376%2015,378%2012,379%2015,380%2012,381%2014,382%2011,387%2015,386%2016,387%2015,388%2017,387%2016,385%2018,384%2015,383%2017,381%2016,377%2017,376%2019,378%2019,377%2017,375%2018,374%2015,378%2013,375%2012,376%2010,374%2011,372%2010,371ZM2,291%203,294%204,294%206,297%205,298%208,300%203,293%203,291ZM104,282%20103,283%20105,284%20106,286%20105,287%20106,287%20109,291%20112,297%20112,299%20114,301%20113,303%20115,309%20112,295%20105,285ZM55,290%2056,291%2054,292%2055,294%2053,295%2055,295%2056,297%2058,296%2060,298%2056,300%2057,299%2059,300%2058,302%2060,304%2058,305%2060,306%2059,308%2062,309%2061,311%2062,310%2064,312%2063,311%2064,310%2063,311%2062,310%2063,308%2062,307%2066,303%2068,305%2068,307%2067,308%2065,307%2065,308%2068,307%2072,310%2071,311%2072,312%2074,311%2076,313%2075,314%2077,313%2079,315%2078,316%2080,315%2082,317%2081,318%2083,317%2084,318%2083,319%2084,318%2085,320%2087,321%2089,320%2085,319%2079,314%2080,311%2079,310%2080,309%2078,308%2081,306%2082,307%2079,305%2082,303%2083,304%2083,303%2081,303%2080,301%2086,296%2082,298%2078,296%2080,295%2079,294%2078,295%2075,295%2074,297%2073,296%2073,294%2076,292%2075,289%2076,288%2076,284%2078,282%2077,283%2076,280%2073,285%2075,284%2076,285%2075,286%2076,288%2074,290%2072,289%2072,291%2069,293%2070,294%2069,295%2067,294%2066,295%2063,295%2057,290%2058,288%2056,291ZM76,303%2077,304%2077,308%2075,309%2073,307ZM72,301%2073,304%2070,305%2069,304ZM68,298%2071,301%2068,303%2066,300ZM64,298%2065,299%2064,300%2066,301%2064,304%2062,303%2063,302%2062,301%2063,302%2062,303%2060,302%2060,300ZM74,297%2076,296%2078,299%2077,300%2075,299ZM63,296%2064,295%2067,296%2066,297ZM61,293%2063,296%2060,298%2058,296%2060,295ZM23,259%2023,260%2029,263%2028,260%2027,261%2025,258ZM74,255%2075,257%2084,264%2084,263%2082,262%2083,260%2082,262%2079,260%2083,257%2080,259%2079,257%2077,258%2075,257ZM2,240%202,244%204,243%206,246%209,246%2010,247%209,246%2011,244%209,246%207,246%204,243%205,242ZM89,236%2094,240%2096,244%2096,251%2098,252%2097,253%2098,251%2096,249%2096,247%2097,246%2098,247%2098,246%2096,245%2095,241%2090,237%2091,236%2090,237ZM2,226%202,233%204,233%205,231%206,232%205,230%204,232%203,231ZM46,224%2046,225%2049,227%2049,229%2052,228%2053,230%2056,231%2054,229%2055,228%2048,222%2053,227%2050,229%2049,226ZM96,216%2095,215%2091,217%2092,218%2090,220%2088,218%2089,217%2088,219%2084,222%2085,224%2082,227%2089,219%2092,220%2091,219%2093,216%2095,218%2094,217ZM42,192%2050,196%2055,196%2055,195%2053,196%2052,195%2053,194%2052,195%2049,192%2051,194%2050,195%2045,194%2044,193%2045,192ZM50,185%2053,189%2060,193%2060,192%2056,190%2058,188%2055,190%2054,188ZM28,165%2037,175%2040,175%2041,176%2042,171%2041,171%2041,174%2040,175%2036,174ZM18,154%2020,157%2018,159%2019,158%2026,164%2025,162%2026,161%2025,162%2021,160ZM11,138%2017,149%2017,151%2018,152%2019,151%2022,151%2024,153%2024,150%2023,152%2021,150%2018,150%2016,148%2016,146ZM40,131%2039,132%2045,137%2046,135%2045,136%2044,134ZM8,114%208,118%209,117%208,116%2010,114%2021,119%2029,121%2031,124%2035,127%2027,120ZM102,78%2099,82%2098,81%2099,83%2096,88%2096,90%2094,93%2093,92%2095,94%2091,100%2091,103%2093,102%2094,99%2093,96%2095,94%2094,93%2096,92%2095,91%2097,89%2097,87%20100,85%20100,82ZM17,77%2023,81%2032,91%2038,102%2038,104%2038,101%2036,99%2035,95%2029,87%2023,81ZM119,64%20118,64%20119,65%20117,68%20115,67%20113,68%20115,71%20117,69%20118,70%20117,68ZM110,13%20113,20%20115,21%20114,22%20115,22%20116,18%20114,20%20113,19%20114,17%20113,17%20111,15%20111,13ZM71,7%2086,10%2099,20%20106,27%20102,22%2097,19%2088,11%2075,7ZM100,0%20106,6%20109,11%20110,11%20107,6Z'/%3e%3cpath%20fill='%23c6d8e9'%20stroke='%23c6d8e9'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M87,451%2086,451%2087,454%2087,466%2085,473%2086,469%2088,468%2087,467%2089,464%2088,463%2088,460%2089,459%2088,454%2089,453%2088,453ZM76,427%2075,430%2082,442%2083,440%2082,441%2081,440%2082,438%2081,438%2078,434%2079,432%2078,433%2077,432%2078,430%2077,431%2075,429ZM73,417%2072,419%2074,420%2072,422%2074,423%2074,417ZM22,405%2021,410%2024,420%2027,422%2028,427%2032,431%2033,434%2041,445%2044,451%2045,459%2047,459%2049,457%2051,458%2059,458%2060,459%2062,458%2063,459%2064,458%2065,459%2068,458%2069,459%2071,457%2071,454%2072,453%2071,450%2072,449%2070,446%2068,445%2067,446%2063,445%2063,447%2064,445%2066,446%2065,447%2068,450%2068,453%2066,454%2064,457%2062,457%2058,454%2052,452%2045,446%2042,445%2040,441%2036,437%2029,424%2029,421%2028,420%2029,415%2028,414%2030,413%2029,412%2031,410%2032,411%2035,409%2039,412%2041,415%2041,419%2042,420%2040,421%2042,422%2042,425%2045,423%2044,422%2044,418%2045,417%2044,418%2042,415%2043,414%2040,411%2039,412%2034,409%2033,407%2028,406%2025,404ZM105,402%20110,413%20110,421%20111,422%20111,427%20110,428%20111,429%20109,433%20110,434%20107,443%20107,454%20110,462%20110,465%20111,465%20113,467%20113,469%20115,471%20116,470%20118,473%20119,472%20119,412%20119,467%20117,471%20111,465%20108,456%20108,449%20107,448%20108,447%20108,442%20109,441%20109,437%20111,433%20111,428%20112,427%20112,422%20111,421%20112,416%20108,408%20109,406%20108,407%20106,405%20107,403%20108,404%20107,403%20106,404ZM49,374%2048,377%2049,374%2050,374%2051,376%2052,375%2056,379%2055,380%2056,379%2060,384%2062,388%2061,390%2058,391%2060,392%2059,393%2060,394%2064,389%2063,383%2059,380%2060,379%2059,378%2054,377%2053,375ZM14,347%2017,349%2016,350%2017,349%2021,356%2021,358%2019,359%2020,360%2020,363%2027,358%2028,356%2027,357%2024,352%2020,348%2017,349%2016,347%2015,348ZM20,352%2021,351%2024,353%2022,355ZM72,324%2076,329%2079,327%2082,327%2086,332%2082,326%2080,326%2076,323%2074,323%2075,324%2074,325ZM77,316%2076,316%2076,317%2078,318%2089,330%2091,335%2091,339%2094,345%2093,346%2093,362%2092,363%2093,364%2090,370%2091,372%2088,376%2089,375%2090,377%2088,379%2087,378%2087,380%2081,389%2082,391%2079,392%2074,402%2074,405%2073,406%2074,407%2072,410%2073,409%2074,411%2076,404%2078,402%2079,403%2078,401%2081,400%2080,399%2082,398%2081,396%2083,394%2085,395%2086,394%2089,394%2095,390%2094,389%2095,388%2095,384%2097,383%2096,382%2097,380%2099,381%20100,379%20102,380%20103,378%20104,380%20106,380%20111,385%20113,389%20113,385%20111,383%20112,382%20109,380%20110,379%20103,373%20101,373%20100,372%20101,371%2099,369%20101,367%20108,370%20116,377%20115,376%20116,375%20115,376%20110,371%20109,368%20105,364%20104,365%20102,363%20103,361%20102,359%20100,358%20101,355%20100,356%2099,355%20100,352%2099,350%20104,343%20107,342%20108,340%20109,341%20115,338%20115,337%20119,334%20116,336%20115,334%20110,337%20107,337%20106,336%20102,337%20101,336%20102,337%20100,338%2099,337%2099,333%20100,332%20102,333%20101,334%20105,333%20106,331%20108,331%20113,328%20114,326%20108,330%2099,331%2097,330%2095,327%2096,326%2099,326%20101,324%20102,325%20100,323%2098,324%2092,324%2091,323%2089,326%2086,322%2080,318%2078,318ZM108,299%20111,308%20109,314%20111,312%20112,313%20111,312%20111,309%20112,308%20111,303%20112,302%20111,303%20110,300ZM3,260%205,264%204,267%206,269%209,267%2010,268%209,267%208,268%206,266%207,264%206,264%205,261ZM112,233%20107,236%20102,241%20103,242%20101,244%20101,247%2099,250%20100,250%20100,248%20102,246%20103,247%20102,246%20104,245%20113,235ZM66,232%2066,244%2068,249%2067,252%2068,251%2071,256%2072,254%2070,253%2071,252%2069,250%2070,249%2070,241%2073,237%2070,240%2067,237ZM91,185%2073,212%2073,215%2071,217%2068,225%2071,223%2074,226%2072,228%2071,227%2072,228%2071,229%2073,228%2074,226%2073,224%2075,222%2076,223%2075,220%2078,216%2078,213%2080,211%2083,212%2082,210%2081,211%2079,210%2082,208%2082,204%2084,202%2083,203%2081,200%2085,197%2086,193ZM76,210%2077,207%2079,209%2077,211ZM10,194%2017,187%2017,182%2016,181%2019,179%2021,180%2020,179%2021,177%2023,176%2027,177%2030,179%2032,179%2040,185%2043,185%2044,186%2042,183%2041,177%2040,178%2042,182%2040,184%2038,183%2037,180%2036,181%2035,180%2035,178%2029,177%2027,175%2024,175%2023,174%2018,177%2019,178%2018,180%2016,179%2016,177%2014,180%2015,179%2017,182%2015,187%2016,188%2014,190%2013,188%2012,190%2013,191%2011,192ZM57,173%2056,174%2055,173%2050,177%2049,176%2048,177%2050,178%2049,179%2051,180%2050,179%2051,178%2054,178%2054,176ZM22,162%2018,161%2017,162%2014,162%208,166%205,166%203,168%203,173%205,172%204,170%207,168%208,166%209,167%2010,165%2014,163%2017,164%2016,163%2018,161%2019,163ZM68,157%2062,165%2064,168%2068,163%2068,160%2066,159ZM5,150%203,151%204,152%203,153%203,157%205,154%204,152ZM32,130%2033,133%2035,133%2037,135%2037,137%2043,142%2044,146%2046,147%2041,154%2035,157%2034,159%2033,158%2033,163%2034,163%2038,159%2042,158%2043,156%2044,157%2046,154%2048,154%2051,150%2049,149%2049,144%2050,143%2049,144%2048,143%2049,141%2048,141%2047,139%2043,141%2040,139%2039,136%2036,134%2037,132%2034,133ZM10,116%2012,120%2011,121%2013,124%2014,122%2015,123%2015,122%2017,121%2016,120%2017,119ZM96,80%2094,82%2093,81%2092,84%2093,85%2091,86%2092,88%2090,89%2088,96%2088,119%2090,124%2089,125%2090,126%2090,130%2093,137%2094,145%2095,146%2095,158%2096,157%2096,148%2097,147%2095,146%2096,145%2096,142%2095,141%2093,130%2091,128%2092,125%2090,123%2091,120%2089,115%2090,114%2090,107%2089,106%2090,105%2090,101%2089,100%2089,96%2090,95%2091,97%2090,94%2092,93%2092,89%2094,87%2093,86%2095,85%2094,83ZM97,1%20105,12%20106,12%20105,11%20106,9%20108,11%20106,9%20105,10%20104,8%20102,8%20100,6%20102,4%20104,6%20101,3%20100,4%2097,2%2098,1Z'/%3e%3cpath%20fill='%231c2b40'%20stroke='%231c2b40'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M114,419%20113,431%20110,440%20110,444%20109,445%20109,448%20110,449%20109,450%20110,450%20109,447%20110,446%20110,440%20112,436%20112,432%20114,426%20113,425%20114,424ZM118,418%20117,418%20118,419%20117,421%20118,423%20117,424%20118,426%20117,429%20118,430%20117,432%20118,434%20118,439%20117,440%20117,466%20116,467%20112,462%20109,452%20112,463%20116,468%20117,468ZM2,402%202,408%201,409%202,410%202,413%201,414%202,421%201,422%201,426%202,427%202,448%203,449%202,450%202,464%201,465%201,469%202,470%202,473%202,467%203,466%2011,473%2011,472%202,464%202,457%203,456%208,459%2015,466%2019,468%2021,468%2026,463%2033,460%2027,462%2022,467%2019,468%202,455%202,452%203,451%202,448%202,427%201,426%202,425%201,424%202,421%202,417%201,416%202,414ZM86,398%2080,403%2078,408%2080,403%2084,399%2087,398%2094,398%2095,399%2096,398%20100,400%20104,404%20107,409%20108,419%20109,420%20108,421%20108,433%20107,434%20106,443%20105,444%20105,457%20108,466%20114,473%20116,473%20114,472%20108,465%20105,455%20105,448%20106,447%20105,444%20107,439%20108,427%20109,426%20108,425%20109,424%20109,416%20107,409%20103,402%2099,399%2092,398%2091,397%2090,398ZM77,393%2071,406%2071,409%2070,410%2070,421%2071,422%2071,426%2085,453%2085,457%2086,458%2085,459%2086,460%2085,461%2085,467%2083,473%2085,469%2085,463%2086,462%2085,452%2079,439%2072,428%2071,417%2070,416%2072,403ZM99,382%2097,387%2098,384%20102,381%20105,382%20110,387%20115,395%20116,403%20115,395%20109,385%20103,381ZM101,369%20111,378%20116,386%20117,391%20117,379%20107,371ZM108,373%20112,375%20116,379%20117,381%20117,385%20116,386%20113,380%20107,374ZM23,368%2014,374%2011,374%2016,375%2015,374%2017,372%2019,374%2018,375%2019,376%2018,371ZM92,347%2092,357%2091,358%2090,367%2087,373%2086,378%2078,391%2084,382%2090,368%2091,358%2092,357ZM118,335%20116,339%20111,342%20107,343%20104,345%20102,349%20104,345%20112,341%20114,341%20116,339%20118,340%20118,361%20117,362%20118,363%20118,366%20117,367%20117,371%20116,372%20112,369%20104,360%20106,364%20107,364%20117,375%20118,374%20118,369%20117,368%20118,367ZM2,333%203,335%202,343%203,340%2012,346%2010,350%203,358%202,355%203,358%201,360%203,359%2012,347%2015,350%2010,358%203,366%203,365%208,361%2014,352%2016,353%2016,356%2018,360%2018,365%209,373%204,372%203,370%202,371%201,385%203,384%206,386%203,391%205,387%208,386%2017,392%2019,398%2018,399%2018,406%2020,410%2022,419%2025,425%2040,446%2040,448%2042,451%2041,455%2038,458%2035,459%2037,458%2038,459%2042,454%2043,455%2043,460%2044,461%2041,462%2034,468%2033,473%2035,469%2042,462%2046,460%2070,461%2072,459%2074,453%2074,449%2070,444%2067,443%2061,444%2060,447%2066,450%2065,453%2056,452%2049,448%2040,439%2036,432%2036,430%2033,427%2030,418%2031,414%2032,413%2035,415%2032,413%2035,412%2039,415%2040,418%2038,421%2038,425%2041,427%2043,427%2047,423%2047,418%2045,414%2037,407%2025,403%2018,396%2017,390%2016,391%2013,388%206,386%201,382%202,380%202,373%203,372%209,373%2013,370%2014,368%2037,354%2040,350%2045,347%2046,348%2043,354%2035,362%2033,363%2043,354%2046,348%2046,346%2048,344%2050,344%2046,345%2041,350%2038,350%2036,349%2035,347%2042,341%2039,339%2033,339%2030,341%2028,341%2034,339%2039,339%2042,341%2035,347%2035,348%2039,351%2033,357%2019,365%2018,364%2018,359%2016,356%2015,350%2010,344%204,341ZM19,398%2025,403%2037,407%2042,411%2046,416%2047,422%2046,424%2042,427%2038,424%2038,422%2040,419%2040,416%2036,412%2032,412%2030,415%2031,424%2036,432%2036,434%2045,445%2055,452%2061,454%2066,453%2066,450%2061,447%2062,444%2067,443%2072,446%2074,452%2072,458%2068,461%2061,461%2060,460%2045,460%2044,459%2043,453%2040,446%2023,421%2018,406%2018,399ZM117,324%20117,326%20111,332%20107,334%20108,336%20109,335%20112,335%20118,330%20118,325ZM107,334%20108,333%20111,334%20110,335ZM116,327%20117,330%20114,333%20111,334%20110,333%20113,331ZM65,322%2057,322%2045,330%2038,331%2034,333%2031,337%2030,335%2029,336%2032,337%2036,332%2038,331%2043,331%2049,327%2054,329%2056,331%2058,331%2066,323%2072,326%2075,330%2076,333%2075,334%2076,335%2074,338%2069,342%2065,344%2060,344%2059,343%2053,343%2052,344%2054,343%2066,344%2067,345%2066,353%2057,365%2047,371%2040,373%2052,369%2061,361%2067,351%2067,345%2066,344%2070,342%2075,336%2076,337%2076,343%2072,354%2069,359%2059,370%2059,376%2065,383%2066,386%2065,391%2061,395%2056,395%2055,394%2055,392%2060,388%2059,385%2056,382%2049,378%2042,376%2038,376%2037,375%2038,374%2033,377%2032,376%2032,368%2032,376%2033,378%2035,376%2046,377%2054,381%2059,386%2060,388%2055,391%2055,394%2057,396%2062,395%2065,392%2066,386%2064,381%2059,376%2059,371%2070,358%2076,343%2076,333%2074,328%2071,325ZM59,327%2060,329%2058,331%2056,329ZM52,325%2053,324%2056,326%2054,328ZM57,323%2058,322%2064,322%2065,323%2063,326%2060,328ZM66,304%2064,306%2064,309%2066,312%2064,313%2061,309%2062,312%2066,314%2067,313%2072,317%2078,320%2084,326%2089,334%2091,341%2091,345%2092,345%2088,331%2081,322%2071,316%2066,311%2064,307%2066,306%2074,313%2084,319%2069,309ZM54,293%2050,298%2050,300%2048,303%2046,304%2047,304%2050,300%2051,301%2054,315%2050,320%2044,324%2043,324%2039,319%2043,324%2040,326%2031,318%2022,313%2016,311%2014,309%2012,309%203,303%204,304%203,306%203,305%205,304%2012,309%2014,309%2016,311%2022,313%2032,319%2038,325%2036,328%2029,330%2027,333%2026,341%2027,333%2031,329%2037,328%2045,324%2054,316%2053,307%2050,299ZM118,291%20118,303%20119,304%20118,305%20118,319%20108,328%20105,329%2099,329%2098,328%2099,327%20102,327%20107,324%20111,320%20113,314%20111,320%20105,325%20101,327%2097,327%2098,329%20106,329%20109,328%20118,320%20118,316%20119,315%20118,314%20119,311%20118,310%20118,306%20119,305%20118,303%20119,302%20118,300%20119,298%20118,297ZM99,287%20102,293%20107,299%20109,311%20107,314%20107,316%2099,322%2088,321%2091,322%20100,322%20102,321%20107,316%20109,311%20108,301ZM71,291%2063,286%2061,286%2059,284%2065,273%2059,284%2061,286%2068,289%2070,291%2069,292%2053,285%2051,285%2049,282%2050,285%2052,286%2049,292%2045,282%2045,278%2045,281%2043,282%2031,277%2025,278%2024,277%2013,276%2024,277%2028,281%2031,287%2033,288%2030,289%2024,285%2032,290%2034,289%2029,284%2026,279%2027,277%2031,277%2039,281%2045,282%2047,289%2049,292%2048,296%2050,290%2053,286%2055,286%2057,288%2055,291%2058,287%2060,289%2062,289%2067,292%2070,292ZM66,271%2071,265%2077,264%2083,267%2096,277%2096,282%2098,285%2096,281%2097,278%2099,279%20102,279%20103,278%20104,279%20109,277%20109,276%20107,278%20102,278%20101,279%2097,278%2093,274%2078,264%2072,264%2070,265ZM35,253%2032,256%2027,256%2024,258%2025,257%2027,260%2026,258%2028,256%2031,256%2032,257%2024,268%2031,260ZM78,251%2081,251%2084,254%2083,255%2079,255%2077,257%2079,256%2080,257%2079,259%2080,258%2084,260%2083,262%2084,262%2089,268%2094,271%2085,264%2084,262%2084,254%2081,251ZM119,210%20109,213%20115,211%20118,211%20119,212%20119,226%20107,234%20101,240%2099,244%2098,250%20100,242%20106,235%20119,227ZM92,180%2074,207%2068,219%2065,228%2065,231%2067,222%2073,209%2075,207%2077,202%2085,192ZM108,176%20110,182%20116,188%20118,192%20118,199%20110,209%20104,211%2099,215%2097,215%2096,217%2093,218%2081,228%2076,234%2077,235%2075,236%2072,242%2073,239%2078,235%2076,234%2087,223%20101,213%20113,207%20118,200%20118,192%20116,188%20109,180ZM59,158%2059,164%2060,165%2059,167%2055,171%2054,168%2055,171%2053,173%2051,173%2055,172%2061,165%2061,164%2060,165%2059,164ZM79,157%2074,161%2067,173%2053,186%2055,184%2058,190%2060,191%2061,193%2057,188%2056,184%2067,173%2073,163%2077,158ZM118,65%20119,66%20118,68%20119,69%20119,72%20119,66%20118,65%20115,65%20103,74%2095,87%2092,98%2095,88%20102,76%20111,68ZM105,48%20105,55%20104,56%20103,63%2093,78%2092,81%20104,61ZM118,42%20117,45%20118,54Z'/%3e%3c/svg%3e", ze = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20120%20474'%3e%3crect%20width='120'%20height='474'%20fill='%23fff9e9'/%3e%3cpath%20fill='%23f95851'%20stroke='%23f95851'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M34,428%2034,431%2033,432%2035,433%2034,434%2034,444%2035,447%2037,448%2035,451%2033,449%2033,447%2032,447%2031,449%2032,447%2034,450%2032,452%2030,451%2029,452%2027,450%2026,453%2024,451%2025,450%2024,449%2023,459%2025,460%2030,457%2031,458%2030,462%2038,468%2039,467%2039,463%2041,459%2039,458%2041,457%2038,451%2039,450%2037,448ZM106,411%20105,412%20106,413%20104,416%20105,417%20103,419%20104,418%20105,419%20107,418%20109,419%20110,417%20112,418%20113,417%20110,416%20108,417%20107,416%20107,414%20109,413%20108,412%20109,411%20107,412ZM102,379%20102,383%20101,384%2099,383%2098,384%2099,387%2098,388%2097,387%20101,391%20100,390%20102,388%20101,385%20102,384ZM52,370%2050,371%2048,376%2048,379%2050,383%2051,383%2050,377%2051,376%2052,377%2052,375%2051,376%2049,374%2052,373ZM21,337%2019,340%2015,353%2011,358%209,363%203,372%202,388%203,389%203,394%206,395%206,394%208,393%2010,396%2011,394%2013,395%2016,394%2017,395%2020,395%2021,396%2020,398%2021,398%2023,395%2025,396%2026,395%2029,398%2027,396%2028,391%2029,390%2031,392%2030,393%2032,393%2033,391%2033,388%2032,387%2035,385%2036,386%2036,391%2033,398%2034,399%2032,401%2032,404%2030,405%2029,411%2032,407%2036,397%2036,393%2038,387%2038,379%2037,378%2038,379%2036,381%2035,380%2035,377%2034,377%2033,379%2032,378%2029,381%2028,380%2028,384%2027,385%2026,383%2024,385%2020,385%2017,381%2016,382%2011,378%2011,372%2010,371%2010,367%2013,360%2016,356%2023,350%2023,348%2024,347%2025,348%2024,346%2025,345%2028,345%2030,347%2033,346%2032,344%2033,342%2029,344%2028,342%2026,341%2026,339%2024,339ZM28,389%2032,387%2033,388%2032,391ZM3,327%203,357%204,357%2010,345%2012,338%2012,333ZM3,305%202,306%203,307%203,311%202,312%205,318%2012,324%2012,320%209,315%209,313ZM28,299%2028,303%2027,304%2031,312%2037,317%2037,319%2038,319%2040,322%2043,321%2046,324%2047,323%2050,324%2048,322%2049,321%2051,322%2053,321%2055,323%2054,324%2058,320%2059,317%2058,313%2053,309%2045,300%2041,292%2041,295%2042,296%2040,297%2038,300ZM70,291%2077,296%2085,300%2088,300%2090,302%2095,304%2096,306%20101,309%20102,308%20107,315%20108,313%20112,316%20112,320%20113,319%20116,320%20115,321%20118,323%20117,325%20118,325%20119,327%20118,321%20111,312%20105,307%20103,307%20101,305%2098,305%2096,303%2089,300%2086,296%2085,297%2081,294%2082,293%2080,292ZM49,287%2050,288%2049,290%2051,291%2050,292%2052,293%2051,294%2056,299%2059,299%2060,301%2061,301%2059,296%2054,293%2050,289%2051,288ZM32,287%2035,287%2038,290%2037,289%2039,288%2040,290%2038,282ZM3,278%204,286%205,288%207,289%206,292%2020,318%2019,319%2021,324%2021,328%2022,329%2023,326%2024,327%2024,330%2025,329%2027,331%2028,328%2030,329%2030,328%2028,327%2029,324%2017,305%2012,301%2011,296%2010,296%208,293%208,290%206,287%204,286%204,281%203,280%204,278ZM6,260%205,260%205,262%203,265%203,270%204,270%204,266%205,265%204,264ZM69,254%2069,256%2075,267%2075,271%2076,272%2075,277%2082,281%2093,282%20100,280%20108,274%20110,274%20111,275%20111,279%20105,286%2099,289%2098,288%2098,290%20108,293%20118,301%20119,300%20118,262%20111,263%20110,264%20101,264%2096,260%2090,259%2078,253%2076,251%2073,251ZM90,277%2091,274%2094,276%2091,278ZM86,274%2087,273%2089,274%2090,277%2089,278ZM95,265%2096,267%2098,268%2096,272%2094,271%2094,266ZM87,260%2089,262%2088,263%2085,263%2085,265%2086,263%2088,263%2089,264%2088,267%2087,265%2088,268%2087,269%2084,268%2086,269%2082,271%2081,270%2080,272%2079,271%2080,266%2078,269%2077,268%2078,266%2077,263%2078,262%2079,263%2081,261%2086,261ZM9,201%207,202%203,207%203,232%205,237%207,237%2010,233%2016,229%2019,228%2026,229%2030,226%2036,224%2040,224%2041,223%2051,224%2054,226%2059,232%2060,235%2059,237%2057,236%2050,236%2048,237%2046,240%2044,240%2039,248%2034,252%2033,254%2031,254%2025,258%2025,262%2028,265%2037,270%2041,271%2048,260%2048,256%2051,247%2057,240%2061,238%2065,238%2066,239%2064,242%2064,248%2070,243%2069,241%2070,240%2070,237%2072,235%2073,236%2073,234%2067,229%2072,227%2071,223%2067,219%2063,230%2060,231%2053,220%2046,219%2042,216%2040,216%2032,207%2030,201%2031,200%2026,198%2021,199%2016,204%2014,210%2015,218%2013,219%2010,216%208,210ZM110,183%20109,183%20112,189%20112,196%20113,197%20112,203%20113,200%20115,204%20112,206%20111,210%20105,217%20100,219%2092,228%2085,232%2081,233%2081,238%2080,240%2085,241%2090,238%2093,238%2097,236%20105,236%20106,237%20110,237%20114,229%20114,223%20110,216%20110,214%20111,213%20115,214%20119,219%20119,208%20116,208%20114,206%20115,204%20116,204%20117,206%20118,205%20119,206%20116,204%20117,203%20116,204%20114,202%20115,200%20117,201%20116,199%20117,198%20118,199%20119,197%20115,200%20113,198%20114,196%20119,195%20119,190ZM25,182%2017,182%2015,181%206,185%204,188%207,188%209,185%2015,184%2019,182%2020,183%2023,182%2024,183ZM28,181%2034,184%2034,182%2031,182%2029,180ZM53,172%2050,176%2049,182%2054,187%2057,194%2056,195%2056,198%2060,202%2061,205%2069,210%2078,220%2080,217%2079,216%2080,205%2084,197%2082,192%2077,189%2076,190%2073,189%2075,188%2064,188%2061,189%2060,186%2062,184%2072,179%2068,176%2059,175ZM69,194%2070,195%2069,198%2068,197ZM70,195%2071,192%2073,194%2071,196ZM72,192%2075,190%2076,191%2075,193ZM68,189%2070,188%2071,190%2069,191ZM63,179%2064,178%2067,179%2066,180ZM32,162%2032,164%2036,171%2042,176%2045,170ZM83,153%2091,160%2092,162%2097,165%2096,161%2093,156%2092,151%2090,151%2089,154%2092,156%2091,159%2088,158%2087,156ZM104,132%20101,138%20102,139%20101,145%20104,151%20103,157%20110,170%20119,180%20119,132%20116,133%20115,132%20111,132%20110,133%20109,132%20106,134%20105,132ZM114,154%20115,155%20115,159%20117,162%20115,165%20112,159ZM4,128%205,129%204,130%204,138%203,139%203,146%204,147%204,152%203,153%203,159%204,160%203,163%203,172%205,177%2011,174%2027,173%2023,164%2022,152%2011,134ZM61,126%2062,129%2061,130%2061,136%2064,136%2065,137%2064,138%2061,138%2063,142%2063,145%2066,149%2068,147%2066,143%2065,137%2063,135%2062,127ZM46,125%2039,132%2038,136%2036,137%2037,138%2034,142%2033,149%2034,149%2036,152%2035,154%2036,154%2037,156%2044,159%2049,155%2051,158%2057,159%2058,160%2057,162%2060,161%2062,163%2063,162%2065,165%2066,164%2070,164%2073,166%2075,166%2073,166%2067,163%2064,159%2063,160%2061,158%2060,159%2058,157%2059,156%2058,154%2056,154%2055,151%2052,149%2054,148%2050,145%2051,144%2050,145%2049,144%2049,141%2050,140%2049,139%2050,137%2048,139%2047,137%2050,134%2051,135%2052,134%2053,135%2053,139%2053,135%2052,134%2053,130%2052,134%2051,135%2048,133%2049,132%2047,130%2048,128%2049,129%2048,127%2046,128%2045,127ZM4,98%204,101%205,102%204,111%209,114%208,113%209,112%207,108%207,104%205,102%205,99ZM51,89%2051,95%2053,98%2053,95%2052,94%2053,92ZM119,85%20118,85%20119,86%20117,88%20114,87%20113,85%20114,87%20112,91%20114,94%20112,98%20119,87ZM46,76%2044,78%2044,80%2040,82%2038,80%2039,79%2038,78%2039,76%2038,75%2037,77%2036,77%2035,75%2034,77%2033,76%2032,77%2029,76%2027,77%2026,81%2022,83%2023,84%2019,88%2019,91%2018,92%2018,94%2020,95%2019,96%2019,100%2020,101%2019,102%2021,105%2021,108%2023,112%2023,117%2029,122%2032,123%2036,118%2036,113%2034,109%2036,108%2035,107%2037,105%2044,107%2047,113%2048,113%2048,107%2047,106%2048,105%2046,104%2047,103%2044,98%2044,96%2042,94%2042,89%2043,88%2042,85%2044,82%2044,78ZM30,99%2032,98%2033,101%2032,102ZM5,62%204,64%205,67%205,71%204,72%205,74%204,75%205,75%208,67%208,63ZM108,47%20102,47%20103,48%20102,49%2099,49%2097,53%2098,54%2098,61%2097,62%2097,65%2098,66%2097,67%2099,69%2098,70%20100,73%2099,75%20102,79%20101,82%2099,81%20100,88%20102,81%20102,76%20105,69%20105,66%20108,62%20108,59%20110,54%20110,50%20106,48ZM6,45%204,46%204,48%205,49%207,48%209,51%208,52%2010,51%2010,50ZM6,16%205,19%206,21%205,22%204,29%206,28%209,31%2010,30%2011,32%2016,36%2017,34%209,20%206,18Z'/%3e%3cpath%20fill='%23ec3431'%20stroke='%23ec3431'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M116,467%20112,471%20112,473%20116,473%20117,472%20117,468ZM51,461%2049,463%2049,465%2051,469%2055,472%2056,466%2055,464ZM68,451%2068,454%2066,458%2066,462%2068,464%2070,464%2071,457%2070,456%2070,451ZM61,450%2057,453%2058,455%2060,454%2060,451ZM2,447%203,448%202,449%203,450%202,451%203,452%202,454%202,460%203,461%202,463%202,472%2010,472%2011,473%2012,472%2014,473%2018,473%2019,472%2032,473%2034,472%2036,473%2028,466%2024,466%2022,468%2023,470%2021,472%2018,470%2019,469%2017,468%2018,467%2018,461%2017,460%2019,458%2021,451%2021,447%2019,444%2016,443%2012,444%2011,443%2010,444%207,444ZM53,432%2051,432%2049,438%2051,447%2053,446%2059,439ZM33,431%2031,433%2029,432%2027,433%2027,435%2023,441%2023,443%2026,446%2024,447%2026,450%2025,451%2026,452%2027,449%2029,451%2030,450%2032,451%2033,450%2031,447%2032,446%2036,448%2034,447%2033,442%2031,440%2031,437%2030,436%2032,433%2033,434%2034,433%2032,432ZM118,420%20115,420%20111,422%2098,422%2098,438%2099,439%2098,440%2098,452%2097,453%2097,459%2095,466%2095,473%2099,472%20102,469%20104,464%20113,454%20118,445%20118,430%20119,429%20118,427ZM66,417%2059,423%2057,426%2064,432%2065,432%2066,429ZM43,417%2042,417%2040,421%2040,425%2039,426%2039,434%2038,435%2039,436%2038,437%2039,443%2040,443%2040,439%2042,433%2044,431%2046,426%2046,423ZM77,411%2080,415%2081,425%2078,433%2073,440%2079,450%2080,458%2078,465%2074,473%2086,473%2088,467%2088,459%2089,458%2089,450%2090,449%2091,415ZM54,399%2052,399%2049,404%2049,413%2052,419%2064,410ZM30,392%2029,391%2029,394%2027,397%2026,396%2025,397%2022,395%2017,396%2015,394%2016,395%2013,396%2010,394%2012,393%2012,392%209,395%207,394%206,396%203,395%204,396%203,397%203,405%204,408%207,407%2012,410%2013,409%2016,409%2018,407%2023,405%2030,399%2030,395%2031,394%2029,393ZM22,395%2023,396%2022,398%2020,399%2019,398%2020,396ZM66,382%2058,390%2058,393%2060,394%2066,401%2069,402%2069,382ZM79,369%2078,370%2079,371%2075,374%2075,377%2077,378%2081,384%2081,396%2080,397%2081,398%2079,400%2077,405%2079,405%2080,406%2079,407%2080,407%2081,409%2086,410%2087,409%2087,404%2085,397%2085,391%2083,388%2083,384%2081,379%2082,378%2080,376%2081,375ZM93,368%2092,370%2094,373%2094,375%2096,376%2094,380%2095,382%2094,384%2096,386%2095,389%2097,392%2096,395%2097,396%2098,413%2099,416%20102,417%20101,419%20103,418%20104,419%20103,416%20105,413%20104,412%20106,410%20107,411%20108,410%20110,411%20109,412%20110,413%20108,414%20108,416%20110,415%20113,416%20112,409%20107,404%20105,398%20103,397%20101,387%2099,388%2097,385%2099,382%20101,383%20101,376%2099,374%2096,368%2095,369ZM100,387%20102,389%20100,391%2098,389ZM97,377%2098,380%2096,382%2095,380ZM63,360%2060,362%2059,365%2066,370%2069,368%2069,364%2068,363%2069,361ZM118,357%20116,357%20113,359%20111,366%20111,388%20116,397%20118,394%20118,362%20117,361%20118,360%20117,358ZM40,323%2041,324%2044,324%2047,327%2047,329%2049,329%2050,328%2049,327%2051,325%2052,326%2054,323%2053,322%2052,323%2049,322%2046,325%2043,322ZM47,324%2049,322%2051,324%2050,325ZM108,314%20108,316%20110,317%20109,318%20111,319%20110,320%20112,322%20115,331%20115,337%20116,338%20115,347%20117,348%20119,343%20118,342%20119,341%20118,339%20119,337%20118,335%20118,329%20119,328%20118,326%20116,325%20117,323%20114,321%20115,320%20112,321%20111,320%20111,316ZM85,309%2085,313%2087,318%2086,321%2088,326%2088,332%2091,338%2094,342%20101,346%20106,347%20108,345%20108,336%20106,332%20107,331%20103,325%20104,323%20102,322%2095,313%2094,314%2091,312%2090,310%2089,311ZM88,260%2086,262%2081,262%2080,263%2079,262%2077,266%2078,268%2079,267%2080,268%2080,271%2081,269%2082,270%2086,268%2088,269%2087,268%2088,266%2089,267%2088,264%2086,264%2085,266%2084,265%2084,263%2085,262%2088,262%2087,261ZM112,197%20112,200%20113,201%20112,205%20114,204%20116,207%20119,207%20118,206%20119,205%20118,203%20119,201%20119,198%20118,197%20119,196%20114,197%20115,199%20116,198%20117,199%20114,203%20112,200ZM69,189%2069,190%2066,192%2067,191%2070,192%2071,195%2072,194%2070,192%2071,191%2070,189ZM119,131%20113,129%20105,129%20103,131%20100,138%20100,147%20102,150%20102,152%20103,152%20101,148%20100,145%20101,143%20100,142%20102,138%20101,135%20102,134%20103,135%20102,134%20103,132%20105,131%20106,133%20109,131%20110,132%20111,131%20115,131%20116,132ZM49,122%2050,123%2048,125%2047,124%2046,127%2047,126%2049,127%2048,130%2050,132%2049,133%2051,134%2048,137%2048,138%2050,136%2051,137%2050,139%2051,140%2050,141%2050,144%2055,148%2053,149%2056,151%2056,153%2058,153%2053,142%2054,141%2052,139%2052,135%2053,134%2052,132%2053,129%2053,120ZM62,118%2063,120%2061,122%2062,124%2061,125%2063,127%2063,132%2065,136%2064,137%2061,137%2064,137%2065,136%2064,132%2065,131%2066,132%2064,130%2066,127%2067,128%2067,124%2068,123%2064,118%2065,119%2063,120ZM79,116%2080,118%2079,121%2077,122%2078,125%2081,127%2080,128%2082,131%2081,133%2082,135%2081,136%2082,141%2081,142%2080,141%2081,143%2080,148%2082,150%2081,151%2085,153%2088,157%2091,158%2091,156%2088,154%2089,151%2092,150%2088,148%2090,146%2089,145%2090,142%2088,140%2089,137%2087,136%2087,133%2084,125%2085,123%2084,120%2083,121%2082,120%2083,118%2082,119ZM66,103%2064,105%2065,106%2064,107%2065,110%2071,115%2073,114%2074,109%2072,107%2073,106%2072,105%2071,106%2068,104%2069,103%2068,104ZM119,101%20118,106%20117,107%20116,105%20116,107%20119,109ZM46,72%2037,68%2036,69%2033,69%2032,68%2029,69%2028,68%2028,69%2026,70%2025,74%2022,76%2021,80%2019,82%2018,91%2018,88%2022,84%2021,83%2023,81%2025,81%2025,79%2027,76%2029,75%2032,76%2033,75%2035,77%2037,76%2038,74%2040,76%2039,77%2040,79%2039,80%2040,81%2043,80%2043,78%2046,75ZM115,63%20113,67%20112,73%20110,76%20110,94%20109,95%20111,98%20113,94%20111,91%20112,88%20114,86%20117,87%20118,86%20117,85%20119,84%20119,65ZM68,62%2067,64%2065,64%2061,68%2061,71%2064,75%2071,80%2072,79%2071,76%2073,74%2073,69%2070,62%2069,63ZM118,54%20119,55%20117,56%20118,57%20116,58%20116,60%20119,62%20119,54ZM97,50%2095,53%2096,54%2096,87%2099,89%2098,81%20100,80%20101,81%20100,82%20101,79%2099,76%20100,74%2097,70%2098,69%2096,67%2097,66%2096,65%2096,62%2097,61%2097,54%2096,53ZM54,47%2051,52%2053,58%2055,59%2054,60%2057,62%2062,58%2063,56ZM68,34%2060,41%2061,42%2060,43%2068,50%2069,48%2070,49%2069,48%2071,47%2072,44%2072,40%2071,38%2069,37ZM5,29%206,31%209,32%2014,36%2014,35%2010,32%2011,30%209,32ZM52,18%2050,20%2050,30%2053,35%2056,35%2063,28ZM41,5%2041,8%2039,13%2040,14%2039,15%2039,26%2042,36%2044,38%2045,42%2047,43%2048,41%2047,38%2045,36%2046,37%2045,38%2043,37%2044,34%2042,30%2042,16%2045,11ZM119,0%20110,0%20110,3%20108,5%20109,6%20107,7%2098,34%2098,38%2096,44%2098,46%20100,45%20108,45%20112,47%20114,45%20114,43%20116,42%20117,38%20119,37%20118,36%20119,35%20119,3%20118,2ZM102,0%2077,0%2078,6%2080,10%2080,14%2079,15%2080,18%2078,19%2079,20%2076,24%2077,25%2074,27%2074,30%2079,37%2080,45%2077,51%2078,52%2075,54%2075,57%2078,62%2078,64%2081,68%2081,77%2080,78%2081,81%2079,82%2080,84%2079,85%2078,84%2079,87%2078,88%2077,87%2078,88%2077,89%2081,89%2082,90%2084,88%2083,81%2084,80%2084,75%2085,74%2085,71%2084,70%2086,66%2086,58%2087,57%2087,51%2086,50%2088,48%2087,46%2089,44%2091,32%2094,26%2094,23%2096,20%2098,13%2097,12%2099,11%20100,4ZM67,0%2067,1%2058,9%2057,14%2062,19%2067,22%2068,21%2069,22%2072,15%2072,11%2071,10%2072,9%2068,0ZM48,0%2050,5%2052,5%2052,4%2057,0ZM5,0%206,5%209,7%208,8%2011,12%2013,13%2013,15%2016,17%2015,18%2016,17%2018,19%2018,22%2020,23%2019,24%2020,24%2021,26%2025,21%2025,19%2030,9%2033,0Z'/%3e%3cpath%20fill='%23fdf9f6'%20stroke='%23fdf9f6'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M45,465%2045,468%2043,471%2044,473%2046,473%2045,472ZM117,460%20116,460%20113,464%20109,465%20103,473%20106,473ZM71,443%2076,452%2076,458%2075,459%2076,460%2073,467%2070,471%2070,473%2076,460%2076,451ZM8,438%205,440%200,441%200,445%208,439ZM110,394%20111,396%20110,399%20118,408%20119,408%20111,398ZM16,363%2014,369%2014,373%2015,376%2018,378%2015,371%2015,365ZM77,360%2075,365%2074,363%2075,366%2073,367%2074,368%2073,370%2059,383%2055,389%2071,374%2076,366ZM9,354%206,360%201,366%200,363%200,372%201,368%207,360ZM45,342%2045,345%2044,346%2046,347%2046,349%2045,350%2044,349%2045,351%2046,350%2047,353%2047,343ZM0,313%200,322%201,321%203,322%204,324%209,328%2017,332%2017,331%2011,328%202,319ZM74,303%2080,310%2080,315%2082,319%2081,320%2083,325%2083,331%2085,333%2087,339%2096,348%20106,352%20104,355%20101,356%2094,356%2093,357%2080,356%2083,358%2085,357%2091,358%2092,357%20110,355%20119,352%20118,351%20114,352%20113,351%20102,350%2093,345%2089,341%2085,333%2084,322%2083,321%2083,317%2081,311%2077,304ZM47,296%2052,300%2054,303%2057,304%2056,306%2062,310%2062,308%2049,296ZM3,291%207,305%2011,310%2012,313%2011,312%2012,310%2011,308%208,306%209,305ZM24,292%2024,298%2028,294%2031,294%2035,296%2038,295%2036,291%2034,290%2027,290ZM48,273%2050,282%2052,285%2063,295%2066,303%2066,309%2063,319%2059,326%2055,330%2061,324%2066,315%2066,312%2068,308%2067,299%2065,296%2066,294%2070,297%2084,303%2058,288%2053,283%2050,277%2050,275%2052,273%2056,273%2060,277%2062,277%2063,279%2076,288%2090,292%2092,294%2097,293%20100,295%20100,297%20103,296%20107,299%20111,299%20112,300%20102,294%2094,292%2088,287%2090,285%2091,286%2096,286%20102,284%20107,279%20105,281%2095,285%2094,284%2093,285%2085,285%2077,282%2074,279%2066,278%2059,272%2053,269%2051,269ZM24,265%2025,268%2038,275%2040,275%2040,274%2035,272ZM53,266%2055,266%2067,275%2071,276%2073,273%2071,265%2066,257%2067,263%2069,266%2069,268%2071,270%2069,273%2067,271%2062,259%2058,261ZM61,242%2054,248%2052,257%2061,251%2060,250%2061,249%2060,248ZM109,242%20105,239%2098,239%2089,242%20103,242%20104,244%20103,245%2087,245%2086,244%2082,244%2075,242%2073,240%2073,243%2076,248%2087,254%2096,257%2099,251%20104,248ZM20,231%2015,233%208,240%205,248%207,244%2013,238%2017,237%2019,239%2019,243%2016,248%2017,251%2014,255%2010,268%2010,272%2011,273%2012,283%2019,296%2019,298%2023,302%2024,305%2018,288%2018,274%2020,273%2025,279%2030,281%2025,277%2021,268%2021,260%2024,254%2022,249%2024,237%2023,236%2023,232ZM52,228%2046,226%2040,226%2029,230%2027,232%2026,251%2029,252%2033,250%2040,242%2029,251%2028,248%2040,238%2050,233%2056,233ZM117,222%20117,230%20115,236%20112,239%20112,244%20111,246%20100,255%2099,258%20103,261%20113,260%20119,257%20119,255%20115,258%20109,259%20106,256%20107,253%20114,248%20119,239%20119,230%20118,229%20118,224ZM34,201%2035,206%2040,212%2045,215%2050,216%2046,211%2040,206%2040,205%2042,204%2051,212%2060,225%2062,225%2063,223%2063,213%2055,201%2053,200%2046,202%2040,200%2035,200ZM90,196%2086,199%2083,206%2083,212%2082,214%2086,207%2086,205%2089,202%2090,203%2087,213%2082,219%2079,225%2073,230%2075,231%2084,229%2091,225%2097,218%2094,214%2093,204ZM41,162%2042,164%2051,169%2056,169%2058,171%2061,171%2074,175%2081,182%2080,183%2077,183%2076,182%2075,183%2073,182%2069,184%2077,185%2082,188%2086,193%2091,193%2093,195%2096,203%2097,213%2099,215%20102,215%20106,212%20109,207%20109,191%20107,184%20101,174%2095,167%2088,162%2082,156%2078,154%2079,153%2076,150%2075,152%2088,163%2086,165%2077,162%2066,155%2072,161%2077,162%2086,166%2087,165%2091,167%20100,176%20105,184%20105,186%20107,189%20107,193%20109,197%20108,198%20108,206%20104,211%20101,211%2099,209%2099,201%20100,198%2098,197%2098,189%2094,181%2088,176%2082,175%2079,173%2075,173%2066,169%2064,169%2064,170%2062,171%2059,169%2060,167%2054,163%2050,163%2052,165%2051,166%2048,166%2046,164%2044,164ZM52,166%2055,164%2057,165%2059,168%2057,169ZM91,128%2091,134%2093,138%2093,145%2097,157%20109,177%20119,186%20119,184%20111,176%20105,168%20100,158%20100,156%2098,154%2097,150%2097,152%2096,153%2095,152%2095,149%2096,148%2095,147%2096,145%2093,135%2091,134%2092,133ZM77,96%2078,109%2076,116%2071,124%2071,127%2069,130%2069,135%2068,136%2069,142%2071,145%2069,133%2070,132%2070,128%2075,120%2079,108ZM69,95%2068,96%2067,95%2061,102%2060,105%2063,102%2064,99ZM106,79%20102,90%20102,94ZM50,74%2047,80%2047,84%2046,85%2046,92%2048,94%2047,95%2050,100%2047,92%2047,87%2049,83%2049,80%2052,75ZM78,72%2077,72%2076,74%2077,75%2077,79%2075,82%2076,83%2075,85%2078,76ZM56,72%2058,75%2059,74%2062,78%2064,78%2069,85%2068,82ZM89,67%2088,69%2088,74%2087,75%2088,76%2087,78%2088,79%2087,80%2087,86%2086,87%2087,90%2089,88%2089,82%2088,81%2089,80ZM68,58%2067,57%2062,61%2059,66ZM76,47%2075,48%2074,47%2075,48%2073,49%2070,53%2071,55ZM51,44%2046,53%2046,61%2052,68%2052,71%2052,68%2048,61%2048,58%2047,57%2047,54%2049,48%2051,46ZM119,42%20113,54%20113,59%20109,71%20112,60%20119,46ZM94,42%2094,43%2091,45%2090,57%2089,58%2092,51ZM47,15%2046,17%2046,31%2050,36%2052,41%2057,44%2048,33%2046,26%2046,22%2049,16ZM107,0%20105,1%20102,8%20101,15%2099,19%20100,20%20100,18%20103,12%20103,9%20106,4ZM73,0%2072,0%2075,6%2075,16%2072,23%2057,37%2057,39%2060,38%2061,36%2072,26%2075,21%2077,15%2077,11%2076,10%2076,6ZM63,0%2061,0%2061,1%2053,8%2055,9ZM44,0%2046,6%2051,13%2054,15%2051,11%2049,10%2046,4%2045,0ZM38,0%2034,6%2034,8%2025,28%2026,29%2030,18%2032,16%2034,16%2035,17%2034,18%2034,27%2035,28%2034,31%2035,30%2036,31%2035,33%2039,38%2040,44%2044,48%2044,50%2045,47%2040,39%2036,27%2036,12%2039,3%2039,0ZM0,0%200,262%200,253%201,252%200,249%200,241%202,240%203,242%204,242%204,240%200,235%200,187%201,185%206,181%2014,178%2031,177%2042,182%2048,189%2048,193%2047,194%2042,194%2035,189%2036,190%2035,191%2032,191%2029,189%2018,189%2017,190%2016,189%206,197%204,198%203,197%203,202%208,197%2015,194%2017,195%2012,202%2012,206%2011,207%2011,210%2012,211%2012,207%2014,202%2021,196%2027,195%2032,197%2039,196%2044,198%2050,198%2054,195%2052,189%2047,184%2041,181%2033,172%2030,167%2027,157%2027,149%2029,143%2035,133%2039,128%2056,112%2054,111%2044,120%2029,138%2028,143%2025,149%2025,158%2026,159%2027,166%2030,171%2036,177%2034,178%2030,176%2015,176%2014,177%2011,177%202,182%201,181%201,170%200,169%201,167%200,166%200,163%201,162%201,155%200,154%201,153%201,146%200,145%201,126%202,125%205,125%2010,129%2013,130%209,125%201,120%201,107%200,106%201,105%200,102%201,101%201,72%202,71%201,69%201,66%202,65%201,62%202,61%201,60%203,58%209,60%201,53%201,41%204,39%209,43%2013,49%2010,42%207,38%201,33%201,12%203,10%2010,16%2011,19%2017,27%2019,32%2020,32%2015,21%2011,17%207,10%202,5Z'/%3e%3cpath%20fill='%238f3a35'%20stroke='%238f3a35'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M118,463%20117,464%20116,463%20117,464%20113,469%20110,470%20109,473%20111,473%20111,471%20116,466%20118,468%20118,472%20117,473%20118,473ZM43,450%2044,452%2041,453%2042,452%2043,455%2045,456%2046,455ZM43,453%2044,452%2046,455%2044,456ZM62,445%2061,446%2062,447%2060,449%2059,448%2057,450%2058,451%2057,452%2061,448%2062,449%2063,446ZM18,422%2017,423%2015,420%2014,420%2012,423%2011,421%203,431%206,432%205,431%207,430%209,427%2011,428%2013,426%2012,427%2010,425%2011,424%2014,424%2015,425ZM36,413%2037,415%2034,418%2033,417%2034,419%2031,422%2030,421%2028,423%2029,422%2030,424%2026,427%2025,429%2024,428%2023,429%2024,430%2020,435%2018,436%2019,437%2017,438%2016,440%2018,440%2022,443%2022,441%2026,435%2026,433%2029,431%2031,432%2033,430%2031,426%2033,425%2034,427%2033,424%2036,423%2038,415ZM113,410%20114,416%20116,416%20118,414ZM32,400%2031,398%2031,399%2023,406%2018,408%2016,410%2013,410%2012,411%207,408%204,409%202,406%202,402%202,413%207,418%2012,418%2013,417%2014,418%2018,418%2020,417%2023,413%2024,414%2022,412%2023,411%2025,412%2026,411%2025,412%2024,410%2028,404%2029,405%2031,403%2030,401ZM111,389%20112,392%20111,394%20112,393%20114,395%20113,398%20114,397%20115,398%20114,400%20115,399%20118,403%20117,402%20118,401%20118,395%20116,398%20112,393ZM109,365%20110,368%20110,373%20109,374%20108,373%20109,375%20108,376%20109,375%20110,376%20110,379%20109,380%20108,378%20109,380%20108,383%20110,385%20109,389%20110,387%20110,368ZM80,361%2080,362%2078,363%2078,364%2079,363%2080,364%2078,367%2079,366%2080,367%2081,374%2082,375%2081,376%2083,378%2082,379%2084,384%2084,388%2086,391%2086,397%2088,404%2088,409%2087,411%2090,411%2089,410%2090,409%2090,404%2089,403%2090,395%2088,390%2089,388%2088,387%2088,384%2086,383%2087,380%2086,379%2085,370%2083,367%2083,364%2084,363%2083,364%2082,362ZM90,361%2088,365%2089,364%2090,365%2090,368%2092,369%2093,367%2095,368%2096,367%20102,377%20103,376%20101,374%20102,373%20101,369%2097,366%2099,365%2098,363%2093,360ZM91,348%2090,347%2091,348%2090,350%2087,348%2088,347%2085,344%2086,343%2083,341%2084,340%2083,342%2086,343%2083,345%2081,344%2084,348%2082,350%2081,348%2079,349%2078,346%2079,347%2076,348%2077,350%2075,352%2074,351%2075,352%2077,350%2079,350%2084,352%2084,351%2082,350%2083,349%2086,349%2088,351%2089,350%2091,351%2090,350ZM111,328%20113,329%20112,330%20112,332%20114,334%20113,338%20115,340%20112,349%20113,349%20115,342%20115,338%20114,337%20114,331%20113,329ZM40,328%2041,328%2043,331%2042,330%2043,328%2047,334%2052,329%2053,330%2054,329%2053,330%2050,329%2049,332%2046,330%2046,327%2044,325%2042,325%2041,326%2042,327ZM66,321%2063,325%2062,324%2061,325%2062,324%2064,326%2062,328%2061,327%2062,328%2059,330%2058,329%2055,332%2056,333%2053,337%2055,338%2054,339%2055,338%2061,338%2064,341%2062,343%2063,342%2065,343%2068,342%2069,343%2068,342%2069,339%2068,340%2067,339%2065,341%2063,339%2064,338%2063,337%2064,336%2066,337%2065,336%2066,335%2068,336%2069,335%2068,334%2071,330%2070,329%2072,328%2072,327%2070,326%2071,324ZM65,323%2067,327%2066,329%2063,325ZM96,313%20103,320%20104,319%2098,313%2097,314ZM94,305%2093,306%2098,310%2099,309%20100,311%20104,314%20108,320%20109,319%20108,317%20101,310%2099,309%2098,310ZM25,299%2026,299%2024,300%2026,303%2025,305%2030,313%2032,314%2032,316%2035,319%2039,326%2038,324%2039,322%2036,320%2035,317%2029,311%2025,305%2026,304%2024,301ZM50,295%2051,295%2062,307%2058,301ZM1,280%201,291%202,292%201,293%201,300%201,297%203,296%201,295%202,292%201,289%202,288%204,290%2011,304%2011,306%2017,316%209,299%205,293%204,289%201,285%202,284%201,283ZM52,277%2053,280%2058,286%2056,282%2056,279%2055,278%2054,281%2053,280%2053,277ZM14,240%2011,243%2012,244%2010,246%208,245%209,246%205,251%208,248%2011,247%2013,244%2012,242ZM63,239%2062,240%2063,241%2062,251%2063,249%2064,250%2062,247%2064,240ZM58,202%2062,207%2063,210%2064,208%2065,210%2076,220%2075,218%2068,211%2063,208ZM102,185%20102,189%20103,190%20102,196%20104,189%20102,188%20103,187ZM36,182%2036,185%2039,187%2042,187%2040,184%2041,183%2040,182%2038,184%2037,183%2038,181ZM68,154%2077,160%2083,162%2084,161%2083,160%2082,161%2078,160%2076,154%2075,155%2073,153%2071,153%2073,153%2078,158%2077,159%2071,156%2069,153ZM76,146%2081,154%2092,163%2078,150%2077,148%2078,146%2077,147ZM78,95%2081,99%2080,100%2080,108%2082,107%2091,121%2094,134%2094,130%2095,129%2096,130%2097,135%2095,136%2097,142%2097,146%20100,151%20101,155%20100,149%2098,146%2099,143%2098,144%2096,141%2099,139%20100,134%20105,128%20113,128%20114,129%20115,128%20117,130%20119,130%20119,126%20117,123%20115,123%20113,121%20114,119%20116,121%20113,117%20110,115%20109,116%20107,114%20108,113%20107,111%20102,108%20101,106%2095,104%2091,101%2088,101%2090,102%2088,103%2087,106%2085,103%2086,102%2084,101%2085,100%2083,102%2084,101%2085,102%2084,104%2085,105%2081,107%2080,106%2081,104%2080,100%2083,99%2081,99%2079,96%2082,95ZM97,129%2098,130%2098,133%2097,134%2096,133%2096,130ZM97,128%2098,127%20100,130%2099,131ZM90,109%2095,114%2099,120%20104,123%20102,125%20101,124%20102,125%2099,128%2098,127%2099,125%2096,125%2095,124%2096,123%2094,122%2095,121%2094,118%2091,116%2092,115%2090,112%2088,111ZM96,109%2098,107%20100,108%2099,109%20100,108%20101,110%20102,109%20105,113%20106,112%20112,119%20111,120%20108,120%20112,120%20113,121%20112,122%20107,122%20105,119%20103,118%20103,116%2099,113ZM93,107%2095,106%2097,108%2095,110ZM88,104%2090,103%2094,106%2092,107ZM54,82%2052,85%2055,89%2055,92%2054,93%2055,94%2055,100%2054,101%2050,95%2050,91%2049,90%2050,89%2049,87%2050,86%2049,87%2050,89%2049,90%2049,93%2052,100%2057,105%2057,104%2054,102%2055,100%2055,89%2056,88%2054,87ZM108,77%20109,79%20107,80%20108,83%20107,84%20106,83%20107,88%20105,89%20106,90%20106,94%20104,97%20103,96%20104,98%20103,99%20102,98%20109,102%20112,105%20111,103%20112,100%20108,95%20109,94%20109,78ZM55,77%2060,81%2060,83%2062,83%2066,87%2065,88%2062,88%2060,85%2060,89%2061,90%2060,89%2062,88%2065,90%2066,88%2067,89%2066,92%2067,91%2067,88%2065,86%2065,84%2064,83%2063,84%2061,82%2062,81%2061,82%2058,78ZM6,77%202,80%202,85%203,86%202,87%203,89%202,90%203,91%202,93%202,98%203,95%203,82%202,81ZM73,54%2074,55%2073,57%2076,60%2076,62%2079,67%2079,74%2080,75%2079,76%2080,77%2080,73%2079,72%2080,71%2080,68%2077,64%2075,58%2073,57%2074,55ZM3,48%203,52%204,51%208,56%209,55%2011,57%2010,56%2012,55%2012,53%2010,53%209,55%207,54ZM105,46%20100,46%2096,50%2095,49%2096,50%2094,52%2093,51%2094,52%2094,55%2092,58%2094,59%2092,60%2093,61%2093,64%2092,65%2091,64%2091,67%2092,68%2091,69%2092,70%2091,71%2092,73%2091,78%2092,79%2090,80%2091,83%2090,84%2091,85%2090,91%2091,92%2090,93%2085,92%2087,93%2088,92%2096,96%2099,94%20100,95%2098,89%2095,87%2095,54%2094,52%2099,47ZM35,44%2034,48%2038,57%2039,57%2040,59%2036,51%2038,50%2035,48ZM32,41%2031,41%2031,45%2030,46%2030,56%2032,59%2031,60%2032,61%2030,63%2028,62%2027,64%2026,63%2025,66%2022,65%2022,62%2021,61%2023,67%2022,68%2020,67%2021,73%2019,74%2020,75%2018,76%2019,77%2017,81%2017,97%2018,97%2017,94%2018,78%2020,75%2021,77%2021,76%2024,74%2025,70%2027,69%2028,67%2029,68%2030,67%2036,68%2037,67%2047,71%2048,73%2050,70%2051,71%2050,70%2049,71%2047,69%2048,67%2047,68%2044,63%2041,62%2042,61%2041,62%2038,60%2033,60%2031,58%2031,49%2032,48%2031,42ZM3,31%2012,41%2013,45%2017,43%2016,40%2018,38%2019,39%2018,37%2013,38%209,33ZM38,26%2041,37%2045,43%2046,47%2046,44%2041,36ZM38,16%2037,17%2037,22%2038,23Z'/%3e%3cpath%20fill='%23571c17'%20stroke='%23571c17'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M22,452%2019,461%2019,467%2021,470%2021,467%2023,464%2029,465%2039,472%2035,468%2027,464%2023,464%2021,467%2019,466%2019,461ZM119,445%20114,455%20107,462%20102,471%2099,473%20103,470%20107,463%20114,456ZM93,420%2092,421%2093,427%2092,428%2092,440%2091,441%2091,456%2090,457%2088,473%2089,471%2089,466%2090,465%2090,460%2091,459%2091,443%2092,442%2092,431%2093,430%2093,423%2092,422ZM40,385%2039,395%2035,406%2030,415%2010,435%202,439%201,438%201,435%204,432%207,431%2022,417%2024,412%2027,409%2028,405%2031,401%2020,418%2018,419%207,419%201,415%201,389%201,439%203,439%209,436%2014,432%2031,414%2035,407%2035,404%2039,396ZM18,420%2014,425%2012,425%207,431%202,433%201,432%201,425%207,419%2017,419ZM2,416%206,419%202,424%201,423%201,417ZM119,350%20119,349%20114,349%20113,350%20109,348%20110,341%20109,348%20108,349%20102,348%2093,342%2096,345%20105,349ZM67,296%2070,299%2069,304%2069,301%2072,300%2078,303%2080,303%2096,312%20104,320%20108,329%20105,321%2096,312%2085,305%2074,301ZM73,246%2074,248%2070,252%2056,260%2047,270%2047,273%2046,274%2047,276%2046,278%2048,280%2048,282%2054,290%2062,297%2064,301%2064,306%2063,307%2061,305%2064,308%2064,310%2062,313%2048,300%2044,293%2046,298%2062,314%2059,321%2047,335%2038,323%2040,325%2040,327%2042,328%2041,329%2042,328%2046,334%2045,336%2043,336%2040,334%2036,327%2031,322%2026,313%2031,322%2040,333%2039,335%2033,334%2037,334%2038,335%2042,335%2043,336%2047,336%2054,338%2068,346%2066,348%2063,348%2055,343%2049,342%2042,339%2031,338%2030,337%2026,337%2019,335%209,330%203,324%204,326%2014,333%2014,336%2015,333%2019,335%2017,342%2019,335%2026,337%2030,337%2031,338%2041,339%2044,341%2043,342%2043,346%2043,342%2044,341%2048,341%2049,342%2049,345%2050,343%2052,345%2054,350%2054,353%2056,355%2053,360%2051,358%2055,364%2066,372%2066,374%2064,376%2046,361%2042,352%2042,348%2042,352%2044,358%2047,363%2049,364%2047,365%2046,367%2042,358%2034,353%2024,353%2020,355%2015,361%2013,366%2013,375%2017,380%2024,380%2026,378%2024,380%2018,380%2016,379%2013,375%2013,366%2015,361%2020,355%2024,353%2034,353%2039,356%2044,362%2044,367%2045,368%2042,373%2041,372%2041,366%2039,361%2034,357%2031,356%2034,357%2039,362%2041,367%2041,383%2043,384%2045,388%2043,398%2045,390%2046,389%2049,392%2047,394%2043,402%2043,404%2042,405%2041,403%2037,413%2025,428%2016,436%206,442%200,447%200,450%201,451%201,473%201,451%200,450%200,447%205,443%207,443%2010,441%2017,441%2022,445%2023,450%2022,444%2015,440%2016,438%2018,437%2017,436%2019,435%2025,427%2029,424%2036,415%2041,404%2042,405%2042,410%2043,412%2041,415%2039,422%2039,420%2043,413%2048,424%2048,426%2042,436%2042,443%2041,444%2047,455%2045,457%2042,455%2042,453%2039,448%2038,442%2039,448%2044,458%2044,460%2041,465%2041,473%2042,472%2041,469%2042,463%2047,456%2050,458%2047,462%2047,466%2048,467%2047,468%2047,472%2048,473%2047,472%2047,468%2048,467%2053,473%2047,464%2050,459%2054,461%2058,465%2058,469%2056,473%2057,473%2059,466%2063,469%2061,473%2063,469%2068,473%2068,471%2072,465%2072,460%2073,459%2072,450%2069,446%2069,441%2070,440%2075,445%2077,450%2074,443%2071,441%2071,439%2076,434%2078,430%2071,438%2070,437%2070,433%2073,428%2073,419%2072,416%2069,413%2071,410%2073,410%2076,413%2079,419%2079,422%2078,416%2073,409%2073,408%2075,407%2078,410%2083,412%2091,412%2092,413%2092,418%2093,418%2090,386%2088,381%2086,369%2083,363%2083,361%2085,359%2087,360%2088,359%2089,360%2092,360%2093,359%2094,360%2096,359%20100,365%2098,366%20102,369%20103,372%20102,374%20103,373%20104,374%20103,377%20103,382%20104,383%20103,384%20104,385%20103,387%20105,391%20106,397%20116,412%20119,414%20112,420%20100,420%2097,418%2097,412%2097,427%2097,420%2098,419%20102,421%20109,421%20119,418%20119,413%20109,402%20105,394%20104,382%20103,381%20104,380%20104,372%20105,371%20105,367%20107,361%20106,359%20108,357%20110,357%20111,358%20111,361%20111,358%20113,356%20119,354%20105,358%2098,358%2097,359%2091,359%2090,360%2088,359%2082,359%2082,361%2084,364%2084,367%2086,370%2086,374%2088,380%2087,383%2089,384%2089,387%2090,388%2089,390%2090,391%2090,394%2089,395%2090,394%2091,395%2091,400%2090,401%2091,409%2090,410%2091,409%2092,411%2091,412%2085,412%2084,411%2081,411%2076,408%2075,405%2078,399%2073,408%2055,425%2053,423%2062,413%2067,410%2072,404%2075,398%2076,391%2074,385%2069,379%2071,376%2076,380%2079,385%2079,387%2077,381%2072,375%2075,372%2079,364%2073,374%2069,377%2062,385%2055,391%2053,389%2055,385%2069,371%2072,366%2073,358%2069,352%2073,349%2076,352%2079,358%2079,362%2079,357%2077,355%2078,354%2080,355%2093,355%2095,353%2096,354%20102,354%20104,353%20104,352%20100,352%2097,350%2095,350%2090,346%2085,340%2082,333%2078,315%2071,303%2076,311%2076,317%2075,318%2073,316%2075,318%2077,323%2075,318%2077,314%2078,315%2079,322%2082,331%2082,335%2084,337%2084,339%2087,344%2094,349%2091,350%2084,345%2079,339%2073,348%2062,357%2056,364%2053,361%2053,360%2071,343%2074,335%2074,329%2071,322%2067,317%2068,314%2065,321%2059,329%2051,337%2048,337%2047,336%2059,322%2064,310%2064,301%2061,295%2050,285%2047,279%2047,271%2051,268%2051,266%2058,259%2065,255%2067,256%2066,255%2074,248%2081,253%2076,250ZM62,446%2063,449%2061,453%2061,456%2059,458%2055,454ZM64,438%2065,439%2065,442%2063,445%2054,453%2052,451%2052,449ZM49,426%2052,429%2050,432%2052,429%2055,433%2061,438%2053,448%2051,449%2049,447%2049,445%2049,447%2052,452%2069,467%2069,469%2067,472%2055,461%2050,458%2042,446%2042,437%2046,429ZM70,415%2072,418%2072,426%2071,427%2071,432%2070,433%2070,438%2068,447%2070,448%2072,452%2072,464%2070,467%2060,458%2065,443%2065,439%2067,433%2068,416ZM67,415%2068,416%2068,424%2067,425%2066,433%2064,434%2056,425ZM49,393%2052,396%2051,397%2052,396%2066,409%2052,422%2050,418%2054,425%2055,425%2065,436%2063,438%2059,436%2046,421%2045,416%2043,413%2043,410%2042,409%2043,402%2045,400%2046,396ZM72,384%2074,386%2076,393%2074,399%2071,403%2070,401%2071,400%2071,385ZM68,379%2071,382%2071,398%2069,405%2056,392ZM58,371%2063,376%2062,378%2058,381%2057,380%2057,375%2058,374%2057,372ZM52,367%2054,369%2054,374%2053,375%2053,381%2052,383%2053,382%2054,370%2055,369%2057,371%2056,384%2052,388%2051,387%2052,385%2050,386%2047,382%2047,374%2048,371ZM48,365%2050,365%2052,367%2048,371%2047,374%2047,382%2052,389%2068,404%2069,407%2066,409%2043,385%2042,376%2041,375ZM72,359%2073,362%2071,365%2070,364%2070,361ZM99,358%20103,361%20102,360%20103,358%20106,359%20106,363%20105,364%20104,363%20106,366%20104,372%2099,362%2097,360ZM63,357%2070,360%2070,369%2067,372%2061,369%2057,365%2057,363ZM64,356%2068,353%2072,356%2072,358%2069,359%2068,358%2065,358ZM51,344%2052,343%2055,343%2064,349%2062,351%2060,351%2061,352%2057,355%2054,350%2055,349%2058,350%2054,349ZM73,348%2075,346%2080,348%2075,346%2077,342%2079,341%2088,348%2094,351%2093,352%2090,352%2089,351%2088,352%2086,350%2083,350%2082,349%2087,352%2091,352%2094,354%2093,355%2086,355%2085,354%2082,355%2081,354%2078,354ZM58,340%2064,337%2070,343%2068,346ZM72,332%2074,335%2072,340%2069,342%2065,337ZM67,318%2070,321%2073,327%2070,333%2067,336%2061,339%2055,339%2052,337%2054,334%2060,328ZM111,241%20110,244%2099,254%2097,258%2093,258%2083,254%2093,258%2096,258%2099,261%20105,263%20101,262%2098,259%2098,256%20103,250%20109,246ZM71,241%2071,244%2064,251%2051,259%2050,256%2053,247%2062,239%2054,245%2050,255%2050,260%2047,263%2044,269%2048,262%2050,261%2051,259%2056,257%2067,249%2070,245%2072,244ZM87,208%2085,213%2082,216%2081,215%2081,208%2081,219%2077,225%2070,230%2072,232%2076,233%2079,231%2086,230%2091,227%2097,221%2091,227%2086,230%2079,231%2075,233%2071,230%2078,224%2079,221%2084,215ZM79,188%2086,196%2082,204%2082,206%2082,204%2085,198%2090,194%2086,195%2084,192ZM100,180%20102,182%20102,184%20106,191%20106,196%20103,199%20102,197%20102,200%20101,201%20103,200%20106,202%20105,204%20103,203%20106,205%20104,209%20106,207%20106,199%20107,197%20106,196%20106,191%20104,188%20104,186ZM78,144%2076,148%2070,153%2073,152%2081,160%2086,163%2073,152ZM80,109%2078,117%2072,128%2072,132%2071,133%2073,129%2075,134%2075,140%2074,143%2070,147%2068,143%2070,147%2066,150%2067,153%2066,151%2073,145%2075,140%2075,134%2074,133%2073,126%2076,123%2076,120%2080,112%2084,117%2084,119%2086,122%2090,139%2087,125%2084,119%2084,117%2080,112ZM49,103%2053,108%2053,110%2046,117%2045,116%2045,112%2045,116%2033,131%2029,131%2032,132%2028,137%2027,140%2028,137%2035,128%2055,109ZM78,81%2077,85%2070,97%2061,107%2058,106%2061,107%2068,101%2076,108%2074,113%2074,116%2072,118%2071,117%2072,119%2070,122%2061,114%2061,119%2061,116%2062,115%2065,117%2070,124%2068,127%2067,135%2067,131%2069,125%2074,116%2076,109%2076,101%2074,96%2072,94%2075,90%2077,91%2078,90%2075,89ZM72,94%2074,96%2073,98%2074,97%2076,101%2076,105%2075,106%2068,100ZM39,58%2038,61%2040,60%2042,62%2044,62%2050,71%2046,78%2045,84%2046,78%2048,76%2050,71%2047,67%2044,61%2044,59%2044,61%2042,62ZM77,49%2074,54%2064,63%2058,70%2068,60%2070,60ZM119,38%20114,48%20112,49%20113,51%20111,54%20109,63%20106,68%20106,71%20104,75%20104,79%20100,90%2099,97%20100,90%20104,80%20104,75%20106,71%20106,68%20109,63%20111,54%20115,47%20115,45%20119,40ZM33,18%2032,18%2025,35%2026,33%2027,34%2027,37%2025,42%2024,51%2024,48%2026,44%2027,32%2030,27%2031,28%2030,31%2030,45%2030,37%2031,36%2034,45%2031,36%2031,33%2032,32%2033,33%2032,30%2032,21ZM78,15%2078,18%2073,27%2068,33%2058,41%2067,33%2069,33%2073,39%2073,45%2070,51%2065,55%2053,45%2050,50%2050,53%2049,54%2050,56%2051,56%2049,54%2050,53%2050,50%2053,46%2055,46%2065,56%2056,64%2055,64%2054,62%2055,64%2054,67%2067,55%2072,48%2073,39%2069,32%2077,21ZM69,0%2073,7%2073,17%2071,21%2067,24%2067,26%2065,28%2062,25%2064,27%2064,29%2055,37%2070,23%2073,17%2073,6ZM59,0%2058,0%2051,8ZM41,0%2040,5%2040,4%2042,3%2047,11%2045,13%2045,15%2043,18%2043,28%2046,34%2046,36%2048,37%2050,41%2044,52%2044,57%2044,53%2048,45%2051,42%2052,43%2049,40%2049,38%2044,31%2043,18%2047,12%2049,13%2046,10ZM36,0%2035,0%2031,8%2031,10%2029,12%2028,17%2021,33%2019,35%2018,33%2019,38%2017,40%2017,42%2024,27%2024,25%2028,18%2028,16%2032,9%2032,7Z'/%3e%3cpath%20fill='%23f1c6c1'%20stroke='%23f1c6c1'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M20,464%2023,462%2026,462%2027,463%2029,462%2030,464%2032,465%2027,460%2024,462%2022,460ZM47,459%2045,460%2043,464%2043,470%2045,462ZM119,449%20115,457%20113,458%20107,465%20104,470%20109,464%20116,462%20115,460%20118,459%20117,458%20119,456ZM70,442%2070,445%2074,452%2074,463%2075,464%2074,463%2074,461%2075,460%2076,461%2074,459%2075,458%2075,452ZM63,440%2054,450%2056,450%2058,447%2063,443%2062,442ZM95,437%2095,442%2093,443%2093,450%2094,452%2092,453%2094,456%2094,458%2092,459%2092,462%2092,460%2093,459%2094,460%2093,459%2094,458%2093,453%2095,450ZM45,435%2044,437%2044,444%2046,447%2047,452%2050,456%2056,460%2059,464%2062,466%2063,465%2066,468%2068,468%2056,458%2049,450%2046,444%2047,443%2046,442%2046,436%2047,434%2046,436ZM52,456%2053,455%2055,458%2054,459ZM54,428%2057,432%2063,436ZM30,419%2027,420%2027,423%2024,426%2023,425%2021,427%2022,428%2021,429%2019,429%209,437%209,439%2023,428ZM63,414%2055,421%2055,423%2061,418ZM72,411%2071,413%2075,420%2075,427%2074,428%2075,432%2074,433%2072,431%2072,435%2071,436%2073,435%2077,429%2076,427%2078,426%2077,425%2077,420%2075,418%2076,416%2072,414ZM50,395%2048,396%2045,401%2047,402%2044,404%2044,406%2046,407%2044,411%2047,417%2047,420%2050,422%2050,424%2052,426%2052,424%2049,421%2046,414%2046,403%2047,402%2046,400%2047,399%2048,400%2049,398%2048,397ZM92,391%2093,407%2095,411%2094,412%2094,420%2095,421%2094,422%2095,424%2094,425%2094,428%2095,429%2095,426%2094,425%2095,424%2095,421%2094,420%2095,406%2094,405%2093,391ZM108,387%20108,390%20109,391%20107,393%20108,397%20113,405%20119,411%20119,409%20118,409%20115,405%20116,404%20115,405%20109,399%20110,397%20109,394%20110,393%20108,390ZM71,378%2077,388%2077,397%2076,400%2072,405%2073,406%2072,407%2073,406%2072,405%2075,403%2074,402%2076,401%2077,399%2076,398%2078,396%2077,394%2077,388%2078,386%2077,387%2075,383%2076,382%2075,381%2074,382ZM48,367%2043,375%2044,376%2043,377%2043,381%2046,382%2045,385%2046,384%2048,386%2047,387%2048,389%2053,392%2052,393%2067,407%2066,406%2067,405%2066,404%2065,405%2064,402%2059,397%2055,395%2056,394%2050,389%2045,381%2045,375%2048,369ZM86,366%2088,370%2090,383%2092,386%2091,388%2092,389%2090,374%2088,371%2087,366ZM55,366%2056,368%2059,369%2060,371%2064,374%2065,373%2063,371%2062,372ZM42,361%2035,355%2026,354%2021,356%2018,359%2018,361%2016,362%2017,363%2016,365%2016,371%2018,377%2020,376%2021,374%2018,369%2019,362%2024,356%2026,355%2033,355%2037,357%2041,361%2042,366%2043,363%2041,362ZM18,372%2019,373%2018,376%2017,375ZM72,351%2071,353%2074,357%2074,362%2075,364%2073,365%2073,366%2074,366%2077,357%2075,356%2076,355%2075,356%2071,353ZM65,351%2058,356%2055,361%2060,357%2061,354%2062,355%2063,353%2064,354%2066,353ZM44,351%2047,360%2049,362%2050,361%2052,362%2048,357%2049,356%2047,355%2048,354%2046,353%2046,351%2045,352ZM85,336%2086,339%2095,348%2092,345%2093,344%2086,339ZM15,334%2016,338%2014,339%2015,340%2010,351%2011,352%209,353%2010,355%2017,337%2017,335%2016,336ZM60,323%2058,325%2059,327%2057,329%2056,328%2050,334%2052,332%2054,332%2059,327%2058,325ZM72,317%2070,317%2072,318%2076,324%2076,327%2078,332%2076,336%2075,335%2073,341%2074,344%2071,346%2070,348%2069,347%2071,348%2077,340%2076,338%2078,336%2077,326ZM12,311%2013,313%2012,314%2013,316%2015,317%2014,319%2016,320%2015,321%2017,324%2016,327%2018,327%2017,319%2016,317%2014,316%2015,315%2014,316%2013,315%2014,313%2013,311ZM73,302%2073,304%2078,311%2080,317%2079,315%2079,310%2078,309%2079,307%2080,308%2079,307%2077,308ZM109,300%20119,308%20117,305%20118,304%20116,302%20115,303%20112,299ZM63,253%2057,258%2051,261%2048,264%2044,272%2043,287%2045,293%2047,295%2049,295%2053,299%2047,293%2046,294%2045,293%2046,290%2044,288%2045,287%2043,283%2044,282%2043,280%2044,279%2044,275%2046,269%2055,259%2061,255%2063,255%2064,254ZM71,247%2065,252%2066,253%2070,250ZM17,246%2011,253%2012,256%2010,259%2010,262%208,267%209,284%2013,292%2013,294%2016,296%2015,297%2019,304%2021,303%2023,305%2021,307%2020,306%2023,313%2025,314%2028,319%2024,313%2026,311%2030,316%2031,319%2032,318%2033,319%2033,322%2045,335%2039,329%2038,326%2035,324%2036,323%2033,318%2029,315%2029,313%2028,313%2027,310%2025,309%2026,308%2024,307%2025,306%2023,305%2024,304%2023,305%2021,301%2020,304%2017,300%2019,299%2010,280%209,268%2013,255%2016,251%2015,248ZM65,211%2066,214%2072,219%2075,225%2076,223%2068,213ZM3,196%204,197%206,196%2011,191%2016,188%2017,189%2018,188%2029,188%2032,190%2035,190%2034,188%2032,187%2027,187%2020,185%2017,186%2016,185%2013,188%2011,187%204,192%203,191ZM48,172%2045,177%2046,180%2047,178%2046,175%2048,174ZM30,156%2041,164%2039,160%2035,157%2036,158%2035,160%2032,157%2033,155%2032,154ZM77,137%2075,143%2076,144%2075,145%2078,141%2077,140ZM11,127%2013,129%2010,130%2013,133%2014,132%2015,133%2015,135%2018,139%2018,141%2020,142%2019,143%2020,142%2022,145%2021,146%2023,146%2024,145%2022,143%2020,138ZM76,126%2077,127%2075,130%2077,131%2076,135%2077,135%2078,129%2076,128%2077,127ZM22,127%2024,129%2031,129%2032,130%2033,129%2032,128%2027,128%2026,127%2027,126%2025,125%2023,128ZM59,120%2057,121%2057,129%2056,130%2057,141%2060,147%2060,149%2065,156%2069,159%2066,156%2067,155%2065,153%2064,154%2063,153%2064,151%2061,149%2062,147%2061,148%2059,146%2060,143%2058,142%2059,140%2057,139%2058,138%2058,131%2057,130%2058,129ZM82,109%2081,111%2086,117%2087,122%2089,125%2090,132%2090,128%2091,127%2089,121%2087,119%2087,117%2084,112%2081,110ZM42,109%2041,110%2039,109%2042,112%2042,116%2039,118%2039,119%2042,116%2043,117%2042,116%2043,115%2043,110ZM48,99%2056,108%2062,112%2070,120%2070,118%2064,112%2063,113%2051,100%2050,101%2049,99ZM79,92%2080,94%2084,94%2091,97%2094,97%2096,99%20102,101%20112,108%20117,114%20118,113%20119,114%20109,104%20108,105%20106,102%2093,96%2091,97%2090,96%2091,95%2088,96%2087,95%2089,94%2086,94%2085,93%2080,94%2079,93%2081,92ZM14,79%2014,97%2016,102%2015,104%2017,110%2018,106%2016,101%2016,93%2014,91%2015,90ZM56,78%2056,83%2058,88%2058,94%2058,91%2059,90%2058,87%2059,85%2057,84%2057,81%2058,80ZM76,75%2073,83%2074,85%2073,86%2072,85%2071,89%2067,94%2069,96%2065,99%2064,102%2060,106%2059,104%2060,103%2059,104%2060,106%2069,96%2068,95%2070,94%2075,86%2074,84%2075,83%2076,84%2074,82%2076,79ZM53,69%2053,72%2069,86%2066,82%2067,80%2068,81%2064,77%2065,78%2062,79%2061,78%2062,76%2061,75%2060,76%2058,74%2059,73%2057,75ZM60,63%2056,67%2057,69%2060,66%2059,65ZM73,59%2072,60%2074,62%2076,68%2076,73%2076,72%2078,71%2078,68%2077,69%2076,68%2076,64ZM112,56%20112,59%20108,67%20106,74%20106,78%20105,79%20107,78%20106,76%20107,73%20109,72%20108,69%20109,68%20110,69%20109,67%20111,60%20112,59%20113,60%20112,59ZM91,54%2091,57%2090,58%2089,55%2090,58%2089,59%2089,66%2088,68%2090,65ZM70,54%2068,55%2068,57%2071,56ZM20,44%2019,49%2018,50%2017,47%2016,52%2014,54%2014,59%2011,66%2012,68%2011,69%2010,68%2011,69%2010,71%2011,73%2010,75%2010,81%209,82%209,99%2010,100%2010,105%2010,100%2011,99%2011,79%2012,78%2011,72%2013,71%2014,62%2017,56%2015,55%2015,53%2016,52%2017,53%2016,51%2017,49%2019,50ZM15,55%2016,56%2015,59%2014,58ZM54,40%2057,43%2055,44%2062,51%2066,53%2062,48%2061,49%2060,48%2060,46ZM35,34%2036,38%2038,40%2039,44%2042,47%2043,50%2043,48%2039,44%2038,38ZM71,31%2073,32%2071,33%2074,36%2075,39%2075,44%2074,45%2075,47%2073,48%2077,46%2076,44%2077,41%2075,35%2073,32ZM99,20%2098,20%2097,26%2094,31%2095,32%2091,44%2093,43%2095,40%2095,33%20100,22ZM52,12%2053,13%2052,14%2063,24%2066,25%2065,26%2066,25Z'/%3e%3cpath%20fill='%23e68d8d'%20stroke='%23e68d8d'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M41,455%2043,458%2040,463%2040,467%2038,469%2033,465%2033,466%2039,470%2040,470%2040,464%2043,458ZM95,435%2093,436%2094,437%2093,438%2094,441%2093,442%2094,442%2094,437%2095,436%2096,437ZM50,429%2048,429%2047,430%2048,431%2046,432%2045,434%2047,437%2046,434%2048,433%2048,431ZM13,427%207,433%203,434%202,436%203,437%209,434%2011,432%2011,430ZM9,420%207,420%203,425%203,429%202,430%204,427%207,425%209,422ZM70,417%2069,418%2070,419%2069,420%2069,424%2070,425%2068,429%2069,432%2066,440%2067,443%2062,455%2064,457%2066,447%2067,446%2067,440%2069,435%2069,430%2070,429%2070,423%2071,422%2070,421%2071,420ZM28,409%2022,420%2021,419%2022,420%2021,421%2024,420%2023,419%2030,411%2029,412ZM38,403%2037,403%2036,405%2036,409%2034,410%2034,413%2032,414%2036,412%2035,411%2037,410%2036,408ZM73,387%2072,388%2072,395%2074,393%2073,392%2074,390%2072,389ZM43,387%2040,393%2041,396%2039,397%2039,401%2041,395%2042,394%2043,395%2042,394%2042,390%2043,389%2042,388ZM27,384%2027,380%2025,382%2024,381%2025,382%2024,383%2019,382%2020,384%2024,384%2026,382ZM48,359%2050,363%2054,366%2055,365%2052,361%2050,362ZM110,358%20108,358%20109,362%20106,369%20108,370%20106,371%20106,374%20105,375%20106,377%20105,378%20105,387%20107,388%20106,392%20108,391%20107,390%20107,387%20108,386%20106,385%20107,383%20106,382%20107,380%20107,371%20108,370%20107,366%20109,363%20109,359ZM27,358%2026,360%2023,361%2022,363%2023,364%2021,368%2023,369%2023,372%2028,375%2029,380%2032,377%2033,378%2034,376%2036,377%2036,380%2038,378%2039,379%2038,391%2039,379%2040,378%2039,376%2040,374%2039,372%2039,365%2033,358%2030,358%2029,359ZM52,348%2050,349%2052,353%2051,356%2053,357%2052,358%2053,358%2054,356%2051,350ZM70,346%2070,347%2066,350%2067,352%2070,349%2069,348ZM24,338%2026,338%2029,343%2033,341%2034,342%2033,344%2034,346%2032,348%2031,347%2030,348%2028,346%2025,346%2024,350%2017,356%2025,351%2030,351%2031,352%2038,353%2039,355%2042,357%2042,354%2041,353%2041,343%2042,342%2040,340%2037,341%2036,340ZM27,317%2026,318%2030,324%2029,327%2031,328%2030,330%2028,329%2028,331%2037,333%2038,332%2037,333%2034,329%2034,327%2029,320%2026,318ZM68,316%2071,319%2074,325%2075,332%2076,333%2075,334%2076,335%2077,332%2075,327%2075,324%2076,323%2075,324%2071,318ZM99,312%20105,319%20108,324%20108,326%20110,328%20109,329%20112,335%20111,336%20112,337%20111,339%20111,343%20112,344%20110,348%20112,347%20111,346%20113,344%20112,343%20112,335%20110,330%20111,329%20108,325%20109,323%20106,321%20103,316ZM47,283%2048,289%2050,287ZM63,281%2063,283%2069,290%2080,291%2083,293%2082,294%2085,296%2086,295%2089,299%2096,302%2098,304%20101,304%20103,306%20105,306%20111,311%20119,321%20119,324%20119,317%20117,313%20118,311%20114,307%20112,308%20108,304%20109,303%20107,304%20106,303%20107,302%20106,303%20105,301%20104,302%20102,299%20101,300%2099,298%2097,298%2095,294%2096,296%2094,297%2089,294%2079,291%2077,289%2075,289%2070,286%2065,281ZM27,272%2028,276%2031,279%2034,280%2036,283%2035,284%2028,284%2022,280%2021,282%2022,289%2023,289%2024,287%2025,288%2029,286%2033,286%2036,283%2037,285%2036,283%2038,281%2041,290%2040,291%2039,289%2037,288%2040,292%2041,291%2046,300%2051,306%2059,313%2060,316%2061,314%2060,314%2044,297%2041,291%2041,288%2039,283%2040,282%2040,279%2038,278%2037,279%2036,277%2035,278%2033,275%2030,275ZM14,249%209,254%208,258%207,259%206,258%207,261%205,264%206,265%205,266%205,270%203,271%204,272%204,276%203,277%205,278%204,279%205,281%205,286%204,287%205,286%207,287%207,288%205,289%207,291%206,290%207,288%209,290%209,293%2010,295%2012,296%2013,301%2018,305%2022,312%2020,308%2022,305%2021,304%2020,305%2018,304%2019,302%2018,303%2017,302%2018,300%2017,301%2014,297%2015,296%2012,294%2012,292%208,284%207,267%208,266%209,259%2011,256%2010,253ZM16,240%2014,241%2015,242%2014,245%2010,249%207,250%206,252%207,254%206,255%207,254%206,253%208,252%2016,243ZM31,186%2027,183%2024,184%2023,183%2022,184%2019,183%2015,185%209,186%207,189%203,189%204,191%2011,186%2013,187%2016,184%2017,185%2020,184%2021,185ZM42,159%2045,160%2046,162%2047,161%2048,162%2047,164%2050,161%2054,160%2059,164%2062,168%2066,167%2069,169%2075,171%2080,171%2083,173%2090,175%2095,179%2099,186%2099,189%20100,190%2099,191%20100,192%2099,194%20101,198%20100,195%20101,186%2097,178%2094,175%2089,172%2083,171%2081,169%2079,169%2076,167%2073,167%2070,165%2066,165%2065,166%2063,163%2062,164%2060,162%2057,163%2056,162%2057,160%2055,159%2053,160%2051,159%2049,156%2044,160ZM38,110%2039,112%2039,117%2041,116%2041,112ZM17,111%2019,112%2018,113%2019,115%2025,120%2026,123%2027,122%2028,124%2030,123%2032,124%2035,122%2036,119%2032,124%2026,121%2025,119%2022,117%2022,114%2020,112%2019,108ZM70,98%2071,99%2070,100%2073,102%2074,100ZM12,97%2011,105%2010,106%2012,114%2013,113%2016,117%2016,120%2017,121%2016,122%2019,125%2023,127%2022,128%2024,125%2018,120%2019,119%2015,113%2014,108%2012,107%2013,106%2012,104ZM3,97%203,101%204,102%203,105%204,106%203,108%203,113%205,114%203,115%205,116%205,117%203,118%207,121%208,120%2011,124%2010,125%2011,124%2016,128%2023,137%2024,141%2025,141%2024,140%2026,139%2030,132%2023,132%2012,122%2013,121%2012,119%2011,121%209,120%2011,117%2010,115%208,115%207,113%205,113%203,111%203,108%204,107ZM62,90%2063,91%2062,92%2062,97%2063,96%2062,94%2064,92%2065,93%2064,92%2065,91ZM21,50%2020,53%2021,54%2019,56%2020,58%2018,60%2019,61%2018,62%2018,66%2017,67%2016,66%2017,69%2015,71%2015,76%2014,77%2016,88%2015,83%2016,82%2016,78%2019,72%2019,66%2021,59%2020,57%2022,54%2022,51ZM29,48%2029,55%2026,62%2028,60%2030,60%2029,58ZM4,14%204,25%204,22%205,21%204,19%205,18%205,15Z'/%3e%3cpath%20fill='%23ad645e'%20stroke='%23ad645e'%20stroke-width='1.4'%20stroke-linejoin='round'%20fill-rule='evenodd'%20d='M76,345%2077,346%2078,345%2083,348%2082,347%2083,346%2082,347%2079,342%2078,343%2079,344%2077,346ZM80,336%2081,338%2080,340%2083,343%2085,343%2090,348%2085,343%2082,342%2083,340%2084,341%2082,338%2082,336%2081,337ZM71,333%2070,335%2067,337%2067,338%2070,339%2069,340%2070,340%2072,337%2070,336%2072,335ZM70,304%2072,306%2070,309%2070,311%2075,316%2075,312%2071,307%2072,306ZM60,297%2062,301%2060,302%2059,300%2057,300%2058,300%2063,306%2062,305%2063,304%2062,303%2062,300ZM119,251%20118,250%20112,252%20108,257%20110,256%20113,252%20117,252%20118,253%20117,252ZM93,163%2098,169%20100,168%2098,165%2095,166ZM60,156%2063,159%2064,158%2065,160%2069,163%2080,168%2083,168%2076,166%2074,164%2075,163%2072,164%2067,161%2068,159%2066,160%2063,158%2061,155ZM112,114%20111,115%20112,115%20119,123%20117,121%20118,119%20119,120%20113,115%20114,114%20113,115ZM90,110%2089,111%2091,112%2093,115%2092,116%2094,117%2096,120%2095,122%2097,123%2096,124%2098,124%2096,122%2098,120%20101,123%20100,124%20101,122%2098,120ZM89,104%2093,106%2095,109%2096,108%2098,111%20102,114%20103,112%20104,113%20102,111%20101,112%20100,110%2099,111%2098,109ZM98,104%20105,108%20108,111%20109,114%20110,111%20112,112%20100,103%20101,102ZM8,75%206,79%203,81%206,83%204,84%204,95%203,96%206,99%206,102%207,103%206,93%205,92%206,91%206,81ZM33,48%2032,49%2032,58%2034,59%2034,54%2033,54%2032,52%2033,51%2035,52%2033,51%2034,49ZM2,46%202,52%2011,59%2010,60%2011,59%2010,57%2011,56%208,57%206,54%207,53%209,54%2010,52%2012,52%2014,50%2012,52%2011,51%206,54%204,52%203,53%202,52ZM38,43%2036,46%2036,48%2040,50%2037,51%2037,52%2041,58%2041,60%2043,59%2041,55%2039,54%2039,51%2040,50%2041,51%2038,49%2036,46ZM28,36%2027,39%2028,39%2029,41%2027,43%2028,45%2026,47%2026,51%2023,58%2024,59%2023,61%2024,64%2025,63%2024,61%2026,60%2025,59%2025,55%2026,54%2027,55%2028,53%2028,48%2029,47Z'/%3e%3c/svg%3e", Be = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20125%20125'%3e%3cpath%20fill='%235d5b50'%20fill-rule='evenodd'%20d='M61,21%2060,22%2057,22%2056,23%2051,24%2045,27%2043,29%2039,31%2032,38%2032,39%2030,41%2025,51%2025,53%2024,54%2024,58%2023,59%2023,75%2024,76%2024,80%2025,81%2025,83%2030,93%2034,97%2034,98%2042,105%2045,106%2047,108%2049,109%2051,109%2054,111%2057,111%2058,112%2074,112%2075,111%2080,111%2083,109%2088,108%2090,106%2094,104%20103,95%20103,94%20106,91%20110,83%20110,81%20111,80%20111,77%20112,76%20112,70%20113,69%20113,63%20112,62%20112,57%20111,56%20111,53%20110,52%20109,47%20106,43%20106,42%20104,40%20104,39%2095,30%2094,30%2091,27%2087,25%2085,25%2082,23%2079,23%2078,22%2074,22%2073,21ZM36,89%2037,88%2038,89%2037,90ZM46,86%2047,84%2049,85%2047,87ZM32,85%2033,84%2034,85%2033,86ZM85,82%2086,84%2084,86%2082,84ZM48,81%2049,80%2051,81%2050,82ZM33,79%2034,78%2035,79%2034,80ZM97,72%2098,71%20100,72%2099,73ZM65,70%2066,69%2068,71%2066,72ZM90,66%2091,65%2092,66%2091,67ZM41,65%2042,64%2043,66%2042,67ZM65,57%2068,55%2075,55%2076,56%2076,58%2077,60%2074,62%2071,62%2069,61ZM33,48%2034,49%2034,52%2036,54%2038,54%2041,57%2043,56%2044,58%2047,57%2050,60%2047,62%2041,62%2037,66%2037,67%2039,67%2040,68%2040,70%2031,78%2034,80%2034,82%2032,84%2031,84%2029,81%2029,78%2028,77%2028,74%2027,73%2027,62%2028,61%2028,56%2029,55%2029,53%2031,51%2031,49ZM38,39%2040,40%2040,43%2041,45%2050,53%2049,54%2045,54%2044,53%2041,53%2038,50%2037,50%2033,47%2035,42ZM65,25%2071,25%2072,26%2077,26%2083,29%2085,29%2087,31%2089,31%2092,34%2093,34%20102,44%20106,52%20106,54%20108,58%20108,73%20107,74%20107,78%20101,90%2094,98%2093,98%2087,103%2083,105%2078,106%2077,107%2074,107%2073,108%2062,108%2061,107%2056,107%2055,106%2053,106%2051,105%2049,103%2048,101%2048,97%2049,96%2049,90%2050,89%2050,85%2051,84%2051,82%2053,81%2053,79%2059,73%2061,74%2063,73%2064,71%2065,72%2070,73%2071,75%2074,75%2075,76%2074,77%2075,77%2076,79%2080,82%2081,84%2081,86%2087,86%2089,84%2088,81%2086,79%2084,79%2081,76%2080,76%2078,74%2078,73%2076,73%2075,72%2075,69%2077,67%2078,67%2077,66%2078,64%2081,67%2082,67%2082,66%2084,65%2085,67%2087,68%2087,69%2089,69%2091,70%2094,73%2098,73%2099,74%20101,74%20103,72%20103,71%20101,68%20101,65%2099,63%2092,63%2091,62%2089,62%2087,60%2083,58%2082,56%2081,56%2078,53%2077,53%2073,50%2068,50%2067,51%2059,51%2053,48%2050,48%2043,42%2043,40%2041,40%2040,39%2040,38%2047,31%2053,28%2055,28%2058,26%2064,26Z'/%3e%3c/svg%3e", Ve = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20125%20125'%3e%3cpath%20fill='%235d5b50'%20fill-rule='evenodd'%20d='M61,19%2060,20%2056,20%2055,21%2053,21%2047,24%2045,26%2041,28%2032,37%2026,49%2026,53%2025,54%2025,57%2024,58%2024,72%2025,73%2026,80%2028,83%2028,85%2030,89%2032,91%2032,92%2033,92%2034,94%2039,99%2041,100%2042,102%2054,108%2057,108%2058,109%2062,109%2063,110%2073,110%2074,109%2079,109%2080,108%2083,108%2093,103%2096,100%2097,100%20105,92%20106,89%20108,87%20111,81%20111,79%20113,75%20113,71%20114,70%20114,59%20113,58%20113,54%20112,53%20112,50%20110,47%20110,45%20108,41%20106,39%20104,35%2097,28%2091,25%2089,23%2087,22%2085,22%2084,21%2082,21%2081,20%2078,20%2077,19ZM53,99%2054,98%2055,99%2057,99%2059,103%2058,104%2055,104%2053,102ZM47,97%2049,96%2050,97%2050,99%2048,100%2047,99ZM74,89%2075,88%2077,89%2076,90ZM62,65%2064,65%2067,68%2067,73%2066,74%2064,74%2061,71%2061,66ZM57,24%2061,24%2062,23%2069,22%2070,23%2076,23%2077,24%2082,25%2085,27%2087,26%2090,29%2091,29%2094,32%2095,32%2097,34%2097,35%20100,37%20100,38%20104,42%20106,46%20106,48%20108,50%20108,53%20109,54%20109,57%20110,58%20109,60%20110,62%20110,66%20109,67%20109,71%20108,72%20108,75%20107,76%20107,80%20105,82%20101,90%2099,91%2099,92%2097,94%2096,94%2091,99%2088,100%2084,103%2082,103%2081,101%2077,99%2075,100%2073,100%2070,102%2066,102%2063,99%2061,99%2059,97%2058,95%2058,93%2061,90%2062,88%2063,88%2065,90%2067,90%2067,89%2070,87%2072,88%2072,90%2079,91%2078,90%2079,89%2083,89%2085,87%2090,85%2096,80%2098,79%20101,80%20102,78%20105,75%20105,68%20103,66%2095,66%2094,68%2091,71%2089,72%2087,72%2086,73%2076,73%2066,65%2065,63%2065,61%2064,60%2064,56%2060,48%2058,46%2058,45%2057,45%2057,47%2059,51%2059,55%2057,56%2051,44%2049,43%2046,40%2046,42%2048,43%2048,45%2051,49%2051,51%2052,52%2052,57%2050,59%2049,59%2048,57%2043,52%2042,52%2042,54%2046,58%2046,59%2044,61%2043,61%2042,59%2035,52%2034,53%2036,55%2036,58%2035,59%2032,58%2033,60%2033,62%2031,63%2030,61%2028,60%2028,58%2029,57%2029,54%2030,53%2030,50%2033,44%2037,39%2037,38%2047,29Z'/%3e%3c/svg%3e", He = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20125%20125'%3e%3cpath%20fill='%235d5b50'%20fill-rule='evenodd'%20d='M46,124%2059,124%2060,123%2063,123%2064,122%2077,122%2081,124%2093,124%2090,122%2088,122%2085,120%2083,120%2082,119%2079,119%2078,118%2061,118%2060,119%2057,119%2056,120%2051,121%2047,124ZM62,16%2061,17%2058,17%2057,18%2052,19%2046,22%2043,25%2042,25%2034,33%2034,34%2032,36%2032,37%2029,41%2029,43%2027,46%2027,49%2025,53%2025,70%2026,71%2027,78%2031,86%2034,89%2034,90%2037,93%2037,94%2043,99%2046,100%2048,102%2052,104%2054,104%2055,105%2057,105%2061,107%2063,106%2064,107%2076,107%2077,106%2081,106%2082,105%2087,104%2093,101%2095,99%2096,99%20106,89%20106,88%20108,86%20112,78%20112,76%20114,72%20114,68%20115,67%20115,55%20114,54%20114,51%20113,50%20113,47%20112,46%20112,44%20109,38%20107,36%20107,35%20102,30%20102,29%20100,28%2095,23%2094,23%2092,21%2090,21%2088,19%2086,19%2082,17%2078,17%2077,16ZM38,83%2039,82%2040,83%2039,84ZM48,69%2049,68%2050,69%2049,70ZM91,53%2092,52%2094,53%2093,54ZM76,42%2079,40%2080,41%2083,41%2087,44%2083,47%2081,47%2078,44%2078,43ZM66,20%2077,20%2080,22%2083,22%2084,23%2086,23%2090,25%2093,28%2094,28%20102,36%20102,37%20105,40%20108,46%20108,48%20109,49%20109,52%20110,53%20110,61%20111,62%20110,64%20110,69%20109,70%20109,73%20108,74%20108,76%20105,82%2099,89%2099,90%2089,98%2087,98%2082,101%2079,101%2078,102%2074,102%2073,103%2071,103%2069,101%2070,100%2070,80%2069,79%2070,78%2070,75%2069,73%2073,67%2075,68%2077,67%2078,65%2080,68%2080,70%2082,70%2083,71%2082,74%2084,74%2085,73%2086,74%2089,71%2090,71%2093,68%2093,66%2092,66%2090,68%2088,68%2084,65%2084,62%2086,60%2086,59%2089,57%2090,55%2092,55%2093,54%2096,56%2096,58%2094,60%2094,61%2095,60%2097,60%2099,58%2099,55%20101,52%20101,49%2098,47%2095,47%2093,45%2092,45%2086,37%2083,37%2082,36%2069,36%2068,37%2065,37%2060,41%2054,44%2051,44%2050,45%2046,45%2045,46%2041,44%2042,46%2042,48%2043,49%2045,48%2047,51%2049,50%2050,51%2049,53%2050,54%2049,55%2048,60%2046,63%2046,65%2043,70%2043,73%2041,75%2041,77%2038,80%2037,82%2035,82%2033,80%2032,78%2032,76%2031,75%2031,73%2030,72%2030,69%2029,68%2029,56%2030,55%2031,48%2036,38%2047,27%2048,27%2050,25%2054,23%2059,22%2060,21%2065,21Z'/%3e%3c/svg%3e", Ue = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20125%20125'%3e%3cpath%20fill='%235d5b50'%20fill-rule='evenodd'%20d='M53,23%2052,24%2049,24%2048,25%2046,25%2042,28%2040,28%2038,30%2037,30%2034,33%2033,33%2024,43%2021,49%2021,51%2019,54%2019,57%2018,58%2018,62%2017,63%2017,74%2018,75%2018,80%2019,81%2020,86%2023,92%2025,94%2025,95%2028,98%2028,99%2037,107%2038,107%2040,109%2044,111%2046,111%2047,112%2050,112%2051,113%2055,113%2056,114%2069,114%2070,113%2073,113%2074,112%2079,111%2083,108%2085,108%2088,105%2089,105%2092,102%2093,102%2093,101%2099,95%2099,94%20101,92%20104,86%20104,84%20106,80%20106,76%20107,75%20107,60%20106,59%20106,56%20105,55%20104,50%20101,44%2096,38%2096,37%2089,31%2088,31%2086,29%2085,29%2081,26%2079,26%2075,24%2072,24%2071,23%2064,23%2063,22%2061,22%2060,23ZM41,103%2042,102%2043,103%2042,104ZM39,97%2040,96%2041,97%2040,98ZM45,95%2046,94%2047,95%2046,96ZM30,92%2031,91%2032,92%2031,93ZM26,86%2027,85%2028,86%2027,87ZM67,83%2068,82%2069,84%2068,85ZM64,82%2065,84%2063,85%2062,84ZM68,82%2069,81%2070,82%2069,83ZM58,82%2059,81%2060,82%2059,83ZM85,81%2086,80%2087,82%2086,83ZM25,80%2027,83%2026,85%2024,83%2024,81ZM56,80%2057,79%2058,80%2057,81ZM23,79%2023,77%2024,76%2026,78%2024,80ZM77,76%2078,75%2079,76%2078,77ZM30,66%2031,65%2032,66%2031,67ZM64,64%2065,63%2068,65%2071,65%2072,66%2072,69%2073,71%2072,72%2069,72%2065,68%2064,66ZM63,62%2064,61%2065,62%2064,63ZM45,58%2046,57%2047,58%2046,59ZM51,28%2055,28%2056,27%2068,27%2069,28%2074,28%2079,31%2081,31%2088,37%2089,37%2092,40%2092,41%2094,42%2094,43%2097,46%2099,50%2099,52%20101,55%20101,57%20102,58%20102,63%20103,64%20103,72%20102,73%20102,77%20101,78%20101,81%2096,91%2091,96%2091,97%2084,103%2083,103%2081,105%2077,107%2075,107%2071,109%2064,109%2063,110%2058,110%2057,109%2054,109%2052,106%2052,102%2051,101%2051,98%2050,97%2050,90%2052,87%2052,85%2054,83%2060,83%2061,84%2059,85%2060,86%2063,86%2064,87%2066,86%2070,86%2072,84%2073,84%2074,85%2073,87%2075,88%2075,89%2078,93%2081,92%2081,90%2079,86%2080,85%2082,85%2083,86%2083,84%2085,82%2086,83%2086,87%2089,86%2089,81%2088,80%2088,78%2085,75%2079,72%2078,70%2076,69%2075,67%2072,65%2075,59%2075,57%2081,50%2081,47%2085,43%2086,40%2084,40%2084,41%2079,46%2079,47%2074,51%2072,55%2067,60%2065,57%2069,53%2070,51%2070,49%2069,49%2069,51%2066,54%2062,56%2060,56%2059,55%2058,56%2053,56%2052,55%2048,55%2044,53%2042,51%2041,51%2035,44%2033,44%2032,45%2032,47%2034,49%2035,49%2040,55%2042,56%2042,58%2040,60%2039,59%2032,59%2030,57%2029,58%2026,57%2026,60%2028,62%2029,65%2028,66%2026,65%2024,65%2024,70%2025,71%2025,73%2024,74%2022,73%2022,61%2023,60%2023,57%2026,51%2026,49%2028,47%2030,43%2038,35%2044,32%2046,30%2048,29%2050,29ZM72,0%2076,0%2077,1%2086,1%2087,0%2088,1%2099,1%20100,0%20105,0Z'/%3e%3c/svg%3e", We = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20125%20125'%3e%3cpath%20fill='%235d5b50'%20fill-rule='evenodd'%20d='M62,21%2061,22%2056,22%2055,23%2052,23%2051,24%2049,24%2045,26%2043,28%2039,30%2031,38%2031,39%2027,44%2024,50%2024,52%2023,53%2023,56%2022,57%2022,62%2021,63%2021,72%2022,73%2022,77%2023,78%2023,81%2024,82%2024,84%2028,92%2038,103%2039,103%2041,105%2044,106%2046,108%2050,110%2053,110%2057,112%2073,112%2074,111%2078,111%2084,108%2086,108%2088,106%2094,103%2098,99%2098,98%20101,96%20101,95%20105,90%20108,84%20108,82%20110,79%20110,75%20111,74%20111,59%20110,58%20110,54%20109,53%20109,51%20108,50%20108,48%20106,44%20104,42%20103,39%2095,31%2094,31%2091,28%2088,27%2086,25%2084,25%2081,23%2078,23%2077,22%2073,22%2072,21ZM67,72%2068,71%2069,72%2068,73ZM52,63%2053,65%2050,68%2050,69%2047,72%2047,73%2035,85%2033,86%2034,87%2033,89%2029,84%2028,82%2028,80%2027,79%2027,76%2026,75%2026,68%2030,64%2031,64%2030,62%2032,61%2033,62%2036,62%2040,64%2041,63%2042,64%2044,63%2048,63%2049,64%2050,63ZM36,61%2037,60%2038,61%2037,62ZM86,59%2087,58%2088,60%2087,61ZM28,58%2029,59%2029,62%2030,63%2029,64%2028,64%2026,62%2026,60ZM94,58%2095,57%2097,58%2096,59ZM91,57%2092,59%2090,60%2089,59ZM41,62%2041,59%2042,58%2048,58%2049,57%2051,58%2053,58%2055,57%2056,58%2056,59%2054,61%2050,61%2049,62%2044,62%2043,63ZM79,54%2079,56%2077,58%2075,58%2073,60%2071,59%2070,60%2066,60%2065,61%2063,61%2062,60%2063,58%2065,57%2069,53%2071,53%2072,52%2075,52ZM65,25%2071,25%2072,26%2076,26%2077,27%2079,27%2089,32%2094,37%2095,37%20100,43%20101,46%20103,48%20103,50%20105,53%20105,55%20106,56%20106,59%20107,60%20107,72%20106,73%20106,77%20102,85%20102,87%20100,89%20100,90%2090,100%2089,100%2084,104%2082,105%2080,105%2079,106%2077,106%2076,107%2072,107%2071,108%2059,108%2058,107%2055,107%2054,106%2052,106%2046,103%2045,101%2049,96%2049,94%2050,92%2053,90%2054,88%2054,86%2056,85%2058,81%2061,78%2061,76%2064,73%2065,73%2067,76%2066,77%2066,81%2068,84%2067,85%2069,87%2069,88%2072,90%2071,88%2069,87%2070,85%2068,82%2069,81%2069,76%2070,74%2073,71%2073,70%2078,66%2079,67%2081,66%2084,66%2092,60%2093,61%2094,60%2096,60%20100,62%20101,61%20100,58%2097,55%2095,55%2094,54%2091,54%2090,53%2082,53%2078,51%2077,52%2076,51%2071,51%2070,52%2067,52%2062,55%2058,55%2057,54%2055,54%2054,55%2050,55%2049,56%2043,56%2042,57%2039,57%2035,60%2031,58%2030,56%2028,55%2029,50%2032,44%2040,35%2041,35%2045,31%2053,27%2056,27%2057,26%2064,26Z'/%3e%3c/svg%3e", Ge = [
	"#508b45",
	"#e0a918",
	"#655680",
	"#3d91ba",
	"#d84b42"
], Ke = [
	Fe,
	Ie,
	Le,
	Re,
	ze
], qe = [
	Be,
	Ve,
	He,
	Ue,
	We
];
function Je({ card: e }) {
	let t = _(e), n = g(e);
	return /* @__PURE__ */ l("span", {
		className: "mu-face",
		style: { "--mu-suit": Ge[n] },
		children: [
			/* @__PURE__ */ c("span", {
				className: "mu-band",
				children: /* @__PURE__ */ c("img", {
					src: Ke[n],
					alt: "",
					draggable: !1
				})
			}),
			/* @__PURE__ */ c("span", {
				className: "mu-number mu-number-top",
				children: t
			}),
			/* @__PURE__ */ c("span", {
				className: "mu-number mu-number-bottom",
				children: t
			}),
			/* @__PURE__ */ c("img", {
				className: "mu-seal mu-seal-top",
				src: qe[n],
				alt: ""
			}),
			/* @__PURE__ */ c("img", {
				className: "mu-seal mu-seal-bottom",
				src: qe[n],
				alt: ""
			}),
			/* @__PURE__ */ c("svg", {
				className: "mu-points",
				viewBox: "0 0 30 18",
				"aria-hidden": !0,
				children: /* @__PURE__ */ c("path", {
					d: v(e) === 2 ? "M1 2H13L7 15ZM16 2H28L22 15Z" : v(e) === 1 ? "M8 2H22L15 16Z" : "",
					fill: "#fff9df",
					stroke: "#373a32",
					strokeWidth: "1.2"
				})
			})
		]
	});
}
function K({ card: e, selected: t = !1, legal: n = !1, disabled: a = !1, onClick: o, anchor: s, small: l = !1 }) {
	let u = r(), { ref: d, hidden: f } = i(s ?? null);
	return /* @__PURE__ */ c("button", {
		ref: d,
		className: `mu-card${l ? " mu-card-small" : ""}${t ? " mu-selected" : ""}${n ? " mu-legal" : ""}`,
		type: "button",
		disabled: a || !o,
		onClick: o,
		"aria-pressed": o ? t : void 0,
		"aria-label": u("games.mumore.card", {
			suit: u(Pe[g(e)]),
			n: _(e),
			points: v(e)
		}),
		style: { visibility: f ? "hidden" : void 0 },
		children: /* @__PURE__ */ c(Je, { card: e })
	});
}
function q() {
	return /* @__PURE__ */ c("span", {
		className: "mu-back",
		children: /* @__PURE__ */ l("svg", {
			viewBox: "0 0 60 100",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ c("path", {
				d: "M30 10C4 25 54 42 30 60S8 84 30 92M30 10C56 25 6 42 30 60S52 84 30 92",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2"
			}), /* @__PURE__ */ c("path", {
				d: "M30 5V95",
				stroke: "currentColor"
			})]
		})
	});
}
function Ye({ shield: e = !1 }) {
	return /* @__PURE__ */ c("svg", {
		className: "mu-role-icon",
		viewBox: "0 0 120 100",
		"aria-hidden": !0,
		children: e ? /* @__PURE__ */ c("path", {
			d: "M60 10C75 20 87 21 105 21V58C102 77 82 91 60 96C38 91 18 77 15 58V21C33 21 45 20 60 10Z",
			fill: "#08090a",
			stroke: "#f9f6e9",
			strokeWidth: "4"
		}) : /* @__PURE__ */ c("path", {
			d: "M15 24L42 48L60 7L80 48L108 24L100 91H23Z",
			fill: "#fffdf0",
			stroke: "#171b21",
			strokeWidth: "4"
		})
	});
}
//#endregion
//#region src/games/mumore/view-player.tsx
function J({ name: e, className: t, children: n }) {
	let { ref: r, hidden: a } = i(e);
	return /* @__PURE__ */ c("div", {
		ref: r,
		className: t,
		style: { visibility: a ? "hidden" : void 0 },
		children: n
	});
}
function Xe(e) {
	let t = e.public, n = e.private, r = `${t.round}:${t.phase}:${t.actor}:${n?.hand.join(",")}:${t.wild.join(",")}:${t.melds.map((e) => e.cards.join(",")).join("/")}`;
	return /* @__PURE__ */ c(Ze, {
		...e,
		pub: t,
		priv: n
	}, r);
}
function Ze({ pub: e, priv: t, members: i, myRid: u, send: d }) {
	let f = r(), [p, m] = n([]), [h, v] = n([]), [y, b] = n([]), x = (e) => i.find((t) => t.rid === e)?.name ?? e ?? "", S = e.players.find((e) => e.rid === u), C = e.phase === "pass" || e.phase === "predict", w = !!t && (C ? !S?.ready : e.actor === u), T = y.flat(), E = t?.hand.filter((t) => !S?.display.includes(t) || e.mode === "roland") ?? [], ee = w && [
		"bid",
		"kitty",
		"predict",
		"pass",
		"play",
		"lead",
		"fish",
		"meld"
	].includes(e.phase), O = (n) => ee && !T.includes(n) && (e.phase !== "play" || !!t?.playable.includes(n)) && (e.phase !== "lead" || e.leadChoices.includes(n)) && (e.phase !== "kitty" || !S?.display.includes(n)) && (e.phase !== "bid" || !S?.display.includes(n)), te = (t) => {
		e.phase === "fish" && (b([]), v([])), m((n) => n.includes(t) ? n.filter((e) => e !== t) : [
			"play",
			"lead",
			"fish"
		].includes(e.phase) ? [t] : [...n, t]);
	}, A = (e) => {
		d(e), m([]), b([]), v([]);
	}, j = (e) => e.kind === "none" ? f("games.mumore.none") : e.kind === "suit" ? f(Pe[e.value]) : f("games.mumore.numberTrump", { n: e.value }), M = (e, t, n = !1, r = !1) => /* @__PURE__ */ c("button", {
		type: "button",
		className: r ? "mu-button mu-primary" : "mu-button",
		disabled: n,
		onClick: t,
		children: e
	}), N = (e, t = !1, n = O(e)) => /* @__PURE__ */ c(K, {
		card: e,
		anchor: `card:${e}`,
		small: t,
		selected: p.includes(e) || T.includes(e),
		legal: n,
		onClick: n ? () => te(e) : void 0
	}, e), P = null;
	if (w && t && (e.phase === "bid" && (P = M(p.length ? f("games.mumore.submit") : f("games.mumore.skip"), () => A({
		type: "bid",
		cards: p
	}), p.length > t.bidLimit, !0)), e.phase === "kitty" && (P = M(f("games.mumore.confirm"), () => A({
		type: "discardKitty",
		cards: p
	}), p.length !== (e.mode === "roland" ? 4 : 3), !0)), e.phase === "pass" && (P = M(f("games.mumore.submit"), () => A({
		type: "passCards",
		cards: p
	}), p.length !== (e.players.length === 6 ? 2 : 3), !0)), e.phase === "predict" && (P = M(f("games.mumore.submit"), () => A({
		type: "predict",
		cards: [p[0], p[1]]
	}), p.length !== 2, !0)), (e.phase === "play" || e.phase === "lead") && (P = M(f("games.mumore.play"), () => A({
		type: e.phase === "lead" ? "lead" : "play",
		card: p[0]
	}), p.length !== 1, !0)), e.phase === "takeDiscard" && (P = M(f("games.mumore.stopDrawing"), () => A({
		type: "draw",
		count: 0
	}), !1, !0)), e.phase === "meld" && (P = /* @__PURE__ */ l(s, { children: [M(f("games.mumore.addGroup"), () => {
		b([...y, p]), m([]);
	}, !D(p)), y.length > 0 ? M(f("games.mumore.submit"), () => A({
		type: "meld",
		groups: y
	}), T.length >= t.hand.length || !S?.opened && T.length < t.opening, !0) : M(f("games.mumore.discard"), () => A({
		type: "discard",
		card: p[0]
	}), p.length !== 1, !0)] })), e.phase === "fish" && p.length === 1)) {
		let t = k(p[0], e.wild), n = t.some((e) => e.cards.length === h.length && e.cards.every((e) => h.includes(e)));
		P = /* @__PURE__ */ l(s, { children: [t.length > 0 && M(f("games.mumore.addGroup"), () => {
			b([...y, h]), v([]);
		}, !n || y.length >= 3), M(f(t.length ? "games.mumore.capture" : "games.mumore.release"), () => A({
			type: "catch",
			card: p[0],
			groups: y
		}), !ne(p[0], e.wild, y), !0)] });
	}
	return /* @__PURE__ */ c(a, {
		adaptive: !0,
		className: "mu-game",
		banner: /* @__PURE__ */ l("div", {
			className: "mu-header",
			children: [/* @__PURE__ */ c("span", {
				className: "mu-title",
				children: f("games.mumore.name")
			}), /* @__PURE__ */ c(o, {
				tone: w ? "accent" : "info",
				accent: "#65704c",
				chip: f("games.mumore.round", { n: e.round }),
				text: f(Ne[e.phase]),
				sub: w || C || !e.actor ? f(G[e.mode]) : f("games.mumore.wait", { name: x(e.actor) })
			})]
		}),
		actionsHeight: "mu-actions-height",
		actions: /* @__PURE__ */ l("div", {
			className: "mu-actions",
			children: [/* @__PURE__ */ l("div", {
				className: "mu-selection",
				children: [
					p.length > 0 && /* @__PURE__ */ c("span", { children: f("games.mumore.selected", { n: p.length }) }),
					y.length > 0 && /* @__PURE__ */ c("span", { children: f("games.mumore.groupCount", { n: y.length }) }),
					(p.length > 0 || y.length > 0) && M(f("games.mumore.cancel"), () => {
						m([]), b([]), v([]);
					})
				]
			}), /* @__PURE__ */ c("div", {
				className: "mu-action-buttons",
				children: P
			})]
		}),
		children: /* @__PURE__ */ l("div", {
			className: "mu-table",
			children: [
				/* @__PURE__ */ c("div", {
					className: "mu-players",
					children: e.players.map((n) => {
						let r = w && e.phase === "partner" && n.rid !== e.crown && n.rid !== e.shield, i = e.mode === "roland" ? n.columns.flatMap((e) => e.up) : n.display;
						return /* @__PURE__ */ l(J, {
							name: `seat:${n.rid}`,
							className: `mu-seat${e.actor === n.rid ? " mu-seat-active" : ""}`,
							children: [
								/* @__PURE__ */ l("div", {
									className: "mu-seat-heading",
									children: [
										/* @__PURE__ */ c("strong", { children: x(n.rid) }),
										/* @__PURE__ */ c("span", { children: f("games.mumore.score", { n: n.score }) }),
										e.crown === n.rid && /* @__PURE__ */ l("span", {
											className: "mu-role",
											title: f("games.mumore.crown"),
											children: [/* @__PURE__ */ c(Ye, {}), f("games.mumore.crown")]
										}),
										e.shield === n.rid && /* @__PURE__ */ l("span", {
											className: "mu-role",
											title: f("games.mumore.shield"),
											children: [/* @__PURE__ */ c(Ye, { shield: !0 }), f("games.mumore.shield")]
										}),
										e.partner === n.rid && /* @__PURE__ */ c("span", {
											className: "mu-role",
											children: f("games.mumore.partner")
										})
									]
								}),
								/* @__PURE__ */ l("div", {
									className: "mu-seat-stats",
									children: [
										/* @__PURE__ */ c("span", { children: f("games.mumore.handCount", { n: n.handCount }) }),
										[
											"revised",
											"classic",
											"don",
											"roland"
										].includes(e.mode) ? /* @__PURE__ */ c("span", { children: f("games.mumore.bid", { n: n.bid }) }) : /* @__PURE__ */ c("span", { children: f("games.mumore.tricks", { n: n.tricks }) }),
										C && n.ready && /* @__PURE__ */ c("span", { children: f("games.mumore.ready") })
									]
								}),
								r && M(f("games.mumore.partner"), () => A({
									type: "partner",
									rid: n.rid
								}), !1, !0),
								i.length > 0 && e.mode !== "roland" && /* @__PURE__ */ l("details", {
									className: "mu-display",
									open: !0,
									children: [/* @__PURE__ */ c("summary", { children: f("games.mumore.publicCards", { name: x(n.rid) }) }), /* @__PURE__ */ c("div", {
										className: "mu-card-row",
										children: i.map((r) => N(r, !0, n.rid === u && w && e.phase === "play" && !!t?.playable.includes(r)))
									})]
								}),
								e.mode === "roland" && /* @__PURE__ */ c("div", {
									className: "mu-columns",
									children: n.columns.map((r, i) => (r.up.length > 0 || r.down > 0) && /* @__PURE__ */ l("div", {
										className: "mu-column",
										children: [
											/* @__PURE__ */ c("span", { children: i < 4 ? f(Pe[i]) : i === 4 ? f("games.mumore.minor") : i === 5 ? f("games.mumore.major") : f("games.mumore.major") + " ∩ " + f("games.mumore.minor") }),
											/* @__PURE__ */ c("div", {
												className: "mu-card-row",
												children: r.up.map((r) => N(r, !0, n.rid === u && w && e.phase === "play" && !!t?.playable.includes(r)))
											}),
											!!r.down && /* @__PURE__ */ l("button", {
												type: "button",
												className: `mu-column-back${n.rid === u && t?.revealColumns.includes(i) ? " mu-legal" : ""}`,
												disabled: n.rid !== u || !t?.revealColumns.includes(i),
												onClick: () => A({
													type: "reveal",
													column: i
												}),
												children: [/* @__PURE__ */ c(q, {}), /* @__PURE__ */ c("span", { children: f("games.mumore.down", { n: r.down }) })]
											})
										]
									}, i))
								}),
								n.prediction !== null && /* @__PURE__ */ l("div", {
									className: "mu-prediction",
									children: [/* @__PURE__ */ l("div", {
										className: "mu-prediction-choice",
										children: [/* @__PURE__ */ c("span", { children: f("games.mumore.prediction") }), N(n.prediction, !0, !1)]
									}), (n.hiddenPrediction !== null || n.rid === u && t?.selected[1] !== void 0) && /* @__PURE__ */ l("div", {
										className: "mu-prediction-choice",
										children: [/* @__PURE__ */ c("span", { children: f("games.mumore.hidden") }), N(n.hiddenPrediction ?? t.selected[1], !0, !1)]
									})]
								})
							]
						}, n.rid);
					})
				}),
				[
					"revised",
					"classic",
					"don",
					"roland",
					"wimmuln"
				].includes(e.mode) && /* @__PURE__ */ l("div", {
					className: "mu-trumps",
					children: [
						/* @__PURE__ */ l("span", { children: [
							/* @__PURE__ */ c("b", { children: f("games.mumore.major") }),
							" ",
							j(e.major)
						] }),
						/* @__PURE__ */ l("span", { children: [
							/* @__PURE__ */ c("b", { children: f("games.mumore.minor") }),
							" ",
							j(e.minor)
						] }),
						e.goal > 0 && /* @__PURE__ */ c("strong", { children: f("games.mumore.goal", { n: e.goal }) }),
						w && t && (e.phase === "minor" || e.phase === "major") && /* @__PURE__ */ c("div", {
							className: "mu-trump-choices",
							children: t.trumps.map((e) => /* @__PURE__ */ l("button", {
								className: "mu-button mu-token mu-legal",
								onClick: () => A({
									type: "trump",
									trump: e
								}),
								children: [e.kind === "suit" && /* @__PURE__ */ c("span", { style: { background: [
									"#508b45",
									"#e0a918",
									"#655680",
									"#3d91ba",
									"#d84b42"
								][e.value] } }), j(e)]
							}, e.kind + e.value))
						})
					]
				}),
				/* @__PURE__ */ l(J, {
					name: "deck",
					className: "mu-deck",
					children: [/* @__PURE__ */ c(q, {}), /* @__PURE__ */ c("span", { children: e.supply > 0 ? f("games.mumore.supply") + " · " + e.supply : f(G[e.mode]) })]
				}),
				e.mode === "rummu" ? /* @__PURE__ */ l("section", {
					className: "mu-meld-table",
					children: [/* @__PURE__ */ l("div", {
						className: "mu-draw",
						children: [
							/* @__PURE__ */ c(J, {
								name: "discard",
								children: e.discard !== null && /* @__PURE__ */ c(K, {
									card: e.discard,
									small: !0,
									anchor: "discardCard",
									legal: w && ["draw", "takeDiscard"].includes(e.phase),
									onClick: w && ["draw", "takeDiscard"].includes(e.phase) ? () => A({
										type: "draw",
										count: 1
									}) : void 0
								})
							}),
							/* @__PURE__ */ l("span", { children: [
								f("games.mumore.discardPile"),
								" · ",
								e.discardCount
							] }),
							w && e.phase === "draw" && M(f("games.mumore.draw"), () => A({
								type: "draw",
								count: 0
							}), !1, !0)
						]
					}), /* @__PURE__ */ c("div", {
						className: "mu-melds",
						children: e.melds.map((n, r) => /* @__PURE__ */ l(J, {
							name: `meld:${r}`,
							className: "mu-meld",
							children: [
								/* @__PURE__ */ c("b", { children: x(n.owner) }),
								/* @__PURE__ */ c("div", {
									className: "mu-card-row",
									children: n.cards.map((t) => /* @__PURE__ */ c(K, {
										card: t,
										small: !0,
										anchor: `card:${t}`,
										legal: w && e.phase === "meld" && p.length === 1 && g(t) === 1,
										selected: h.includes(t),
										onClick: w && e.phase === "meld" && p.length === 1 && g(t) === 1 ? () => v([t]) : void 0
									}, t))
								}),
								w && e.phase === "meld" && S?.opened && p.length > 0 && M(f("games.mumore.extend"), () => A({
									type: "extend",
									group: r,
									cards: p
								}), !D([...n.cards, ...p]) || p.length >= (t?.hand.length ?? 0)),
								w && e.phase === "meld" && S?.opened && p.length === 1 && h.length === 1 && n.cards.includes(h[0]) && M(f("games.mumore.trade"), () => A({
									type: "trade",
									group: r,
									joker: h[0],
									card: p[0]
								}), g(p[0]) === 1 || _(p[0]) !== _(h[0]) || !D(n.cards.map((e) => e === h[0] ? p[0] : e)))
							]
						}, r))
					})]
				}) : e.mode === "safaru" ? /* @__PURE__ */ l("section", {
					className: "mu-wild",
					children: [/* @__PURE__ */ c("h2", { children: f("games.mumore.wild") }), /* @__PURE__ */ c(J, {
						name: "wild",
						className: "mu-hand-cards",
						children: e.wild.map((e) => /* @__PURE__ */ c(K, {
							card: e,
							anchor: `card:${e}`,
							legal: w && p.length === 1 && !T.includes(e),
							selected: h.includes(e) || T.includes(e),
							onClick: w && p.length === 1 && !T.includes(e) ? () => v(h.includes(e) ? h.filter((t) => t !== e) : [...h, e]) : void 0
						}, e))
					})]
				}) : /* @__PURE__ */ c(J, {
					name: "trick",
					className: "mu-trick",
					children: e.players.map((t) => {
						let n = e.trick.find((e) => e.rid === t.rid);
						return /* @__PURE__ */ c(J, {
							name: `trick:${t.rid}`,
							className: "mu-trick-play",
							children: n ? /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c(K, {
								card: n.card,
								anchor: `card:${n.card}`
							}), /* @__PURE__ */ c("span", { children: x(n.rid) })] }) : /* @__PURE__ */ c("span", { className: "mu-empty-card" })
						}, t.rid);
					})
				}),
				e.side.length > 0 && /* @__PURE__ */ l("details", {
					className: "mu-side",
					children: [/* @__PURE__ */ c("summary", { children: f("games.mumore.side") }), /* @__PURE__ */ c("div", {
						className: "mu-card-row",
						children: e.side.map((e) => /* @__PURE__ */ c(K, {
							card: e,
							small: !0
						}, e))
					})]
				}),
				e.phase === "roundEnd" && /* @__PURE__ */ l("div", {
					className: "mu-round-result",
					children: [
						/* @__PURE__ */ c("h2", { children: f("games.mumore.results") }),
						e.history.at(-1)?.success !== null && /* @__PURE__ */ c("p", { children: f("games.mumore.achieved", {
							n: e.history.at(-1)?.achieved ?? 0,
							goal: e.goal
						}) }),
						/* @__PURE__ */ c("div", {
							className: "mu-result-row",
							children: e.players.map((t) => /* @__PURE__ */ l("span", { children: [
								x(t.rid),
								" ",
								/* @__PURE__ */ c("b", { children: e.history.at(-1)?.delta[t.rid] })
							] }, t.rid))
						})
					]
				}),
				t && /* @__PURE__ */ l("section", {
					className: "mu-hand",
					children: [/* @__PURE__ */ l("h2", { children: [f("games.mumore.hand"), w && e.phase === "meld" && !S?.opened && /* @__PURE__ */ c("small", { children: f("games.mumore.opening", { n: t.opening }) })] }), /* @__PURE__ */ c(J, {
						name: `hand:${u}`,
						className: "mu-hand-cards",
						children: E.map((e) => N(e))
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/games/mumore/bot.ts
function Qe(e) {
	let t = [], n = Array.from({ length: 10 }, (t, n) => e.filter((e) => _(e) === n)), r = (e) => {
		D(e) && t.push(e);
	};
	for (let e of n) {
		let t = (n, i) => {
			if (i.length >= 3 && r(i), i.length !== 5) for (let r = n; r < e.length; r++) i.some((t) => g(t) === g(e[r])) || t(r + 1, [...i, e[r]]);
		};
		t(0, []);
	}
	for (let e = 0; e <= 7; e++) {
		let t = (e, i) => {
			if (i.length >= 3 && r(i), !(e > 9)) for (let r of n[e]) {
				let n = [...i, r], a = n.filter((e) => g(e) !== 1), o = new Set(a.map(g)), s = n.length - a.length;
				o.size > 1 && (o.size !== a.length || n.length > 5 || s > 1) || t(e + 1, n);
			}
		};
		t(e, []);
	}
	return t;
}
function $e(e, t, n = 1) {
	let r = Qe(e).sort((e, t) => t.length - e.length || O(t) - O(e)), i = [], a = 0;
	for (let o of r) {
		let s = [o], c = new Set(o);
		for (let t of r) t.every((e) => !c.has(e)) && c.size + t.length <= e.length - n && (s.push(t), t.forEach((e) => c.add(e)));
		c.size >= t && c.size <= e.length - n && c.size > a && (i = s, a = c.size);
	}
	return i;
}
function et(e, t, n = !1) {
	let r = e.public, i = e.private;
	if (!i || r.phase === "done" || r.phase === "roundEnd" || r.phase === "trickEnd") return null;
	let a = r.players.find((e) => e.rid === t), o = i.hand;
	if (r.phase === "predict") {
		if (a.ready) return null;
		let e = Math.max(0, Math.round(o.reduce((e, t) => e + (x(t, r.major) ? .7 : _(t) >= 7 ? .5 : .1), 0))), t = [...o].sort((t, n) => Math.abs(_(t) - e) - Math.abs(_(n) - e) || t - n);
		return {
			type: "predict",
			cards: [t[0], t[1]]
		};
	}
	if (r.phase === "pass") {
		if (a.ready) return null;
		let e = (e) => g(e) === 2 && _(e) === 7 ? 100 : g(e) === 4 ? 30 + _(e) : g(e) === 1 ? -15 - _(e) : _(e);
		return {
			type: "passCards",
			cards: [...o].sort((t, n) => e(n) - e(t)).slice(0, r.players.length === 6 ? 2 : 3)
		};
	}
	if (r.actor !== t) return null;
	if (r.phase === "takeDiscard") return {
		type: "draw",
		count: 0
	};
	if (r.phase === "lead") return {
		type: "lead",
		card: r.leadChoices[0]
	};
	if (r.phase === "reveal") return {
		type: "reveal",
		column: i.revealColumns[0]
	};
	if (r.phase === "kitty") return {
		type: "discardKitty",
		cards: o.filter((e) => !a.display.includes(e)).sort((e, t) => S(e, r.major, r.minor) - S(t, r.major, r.minor) || _(e) - _(t)).slice(0, r.mode === "roland" ? 4 : 3)
	};
	if (r.phase === "bid") {
		let e = o.filter((e) => !a.display.includes(e)), t = [...o, ...a.columns.flatMap((e) => e.up)], s = Array.from({ length: 5 }, (e, n) => t.filter((e) => g(e) === n).length), c = s.indexOf(Math.max(...s)), l = t.filter((e) => g(e) === c || _(e) >= 7).length, u = n ? 1 : Math.max(1, Math.min(t.length - 2, Math.floor(l * .58))), d = Math.max(...r.players.map((e) => e.bid)), f = Math.min(u, r.mode === "classic" ? d + 1 : u), p = Math.min(i.bidLimit, Math.max(0, f - a.bid));
		return {
			type: "bid",
			cards: [...e].sort((e, t) => Number(g(t) === c) - Number(g(e) === c) || _(t) - _(e)).slice(0, p)
		};
	}
	if (r.phase === "minor" || r.phase === "major") {
		let e = [...o, ...a.columns.flatMap((e) => e.up)], t = (t) => e.reduce((e, n) => e + (x(n, t) ? 4 + _(n) * .3 : 0), 0) - E(t) * (n ? 0 : .08);
		return {
			type: "trump",
			trump: [...i.trumps].sort((e, n) => t(n) - t(e))[0]
		};
	}
	if (r.phase === "partner") {
		let e = r.players.filter((e) => e.rid !== t && e.rid !== r.shield);
		return e.sort((e, t) => t.display.reduce((e, t) => e + S(t, r.major, r.minor) * 4 + _(t), 0) - e.display.reduce((e, t) => e + S(t, r.major, r.minor) * 4 + _(t), 0)), {
			type: "partner",
			rid: e[0].rid
		};
	}
	if (r.phase === "play") {
		let e = [...i.playable];
		if (n) return {
			type: "play",
			card: e[0]
		};
		let o = (e) => S(e, r.major, r.minor) * 20 + _(e), s = e.filter((e) => w([...r.trick, {
			rid: t,
			card: e
		}], r.major, r.minor) === t), c = [r.crown, r.partner], l = c.includes(t), u = r.trick.length ? c.includes(w(r.trick, r.major, r.minor)) === l && [
			"revised",
			"classic",
			"don",
			"roland"
		].includes(r.mode) : !1, d = r.mode === "panther" || r.mode === "wimmuln" && a.prediction !== null && a.tricks >= _(a.prediction), f = !d && !u && s.length ? s : e;
		if (f.sort((e, t) => d ? o(t) - o(e) : o(e) - o(t)), d && r.trick.length) {
			let e = f.filter((e) => !s.includes(e));
			if (e.length) return {
				type: "play",
				card: e[0]
			};
		}
		return {
			type: "play",
			card: f[0]
		};
	}
	if (r.phase === "fish") return o.flatMap((e) => {
		let t = k(e, r.wild);
		if (!t.length) return [{
			action: {
				type: "catch",
				card: e,
				groups: []
			},
			score: -_(e)
		}];
		let i = [], a = -Infinity, o = (n, s, c, l) => {
			let u = !(c.has(0) || c.has(1)) || !r.wild.some((e) => _(e) === 0) || [...l].some((e) => _(e) === 0);
			if (s.length && u) {
				let t = [...l, ...c.has(2) ? [e] : []].reduce((e, t) => e + (g(t) === 3 ? 3 : g(t) === 4 ? 2 : 0) + (_(t) === 0 ? -5 : 1), 0);
				t > a && (a = t, i = s);
			}
			if (s.length !== 3) for (let e = n; e < t.length; e++) {
				let n = t[e];
				!c.has(n.kind) && n.cards.every((e) => !l.has(e)) && o(e + 1, [...s, n.cards], /* @__PURE__ */ new Set([...c, n.kind]), /* @__PURE__ */ new Set([...l, ...n.cards]));
			}
		};
		o(0, [], /* @__PURE__ */ new Set(), /* @__PURE__ */ new Set());
		let s = t.find((t) => ne(e, r.wild, [t.cards]));
		return [{
			action: {
				type: "catch",
				card: e,
				groups: n ? [s.cards] : i
			},
			score: a
		}];
	}).sort((e, t) => t.score - e.score)[0].action;
	if (r.phase === "draw") {
		let e = r.discard;
		if (e !== null && !n) {
			let t = $e([...o, e], a.opened ? 3 : i.opening).some((t) => t.includes(e)), n = a.opened && r.melds.some((t) => D([...t.cards, e]));
			if (t || n) return {
				type: "draw",
				count: 1
			};
			if (o.length < 3 && r.discardCount >= 4 - o.length) return {
				type: "draw",
				count: 4 - o.length
			};
		}
		return {
			type: "draw",
			count: 0
		};
	}
	if (r.phase === "meld") {
		let e = $e(o, a.opened ? 3 : i.opening);
		if (e.length) return {
			type: "meld",
			groups: e
		};
		if (a.opened && o.length > 1) {
			for (let e = 0; e < r.melds.length; e++) for (let t of o) if (D([...r.melds[e].cards, t])) return {
				type: "extend",
				group: e,
				cards: [t]
			};
		}
		let t = (e) => o.filter((t) => t !== e && (_(t) === _(e) && g(t) !== g(e) || g(t) === g(e) && Math.abs(_(t) - _(e)) <= 2)).length * 4 + (g(e) === 1 ? 2 : 0);
		return {
			type: "discard",
			card: [...o].sort((e, n) => t(e) - t(n) || _(n) - _(e))[0]
		};
	}
	return null;
}
var tt = (e, t) => {
	let n = e.public, r = e.private?.hand;
	if (n.mode !== "rummu" || !r || t.difficulty === "weak") {
		let n = et(e, t.rid, t.difficulty === "weak");
		return n ? { action: n } : null;
	}
	if (n.actor !== t.rid) return null;
	let i = n.players.find((e) => e.rid === t.rid), a = n.players.filter((e) => e.team !== i.team), o = (e) => n.players.find((t) => t.rid === e).team === i.team, s = `${n.round}:${n.melds.reduce((e, t) => e + t.cards.length, 0)}`, c = t.memory, l = c?.key === s ? (c.stalled ?? 0) + Number(n.phase === "draw") : 0, u = {
		key: s,
		stalled: l
	}, d = l < 6 && i.score + 50 < Math.max(...a.map((e) => e.score)) && a.some((e) => e.handCount > 3), f = null;
	if (n.phase === "draw") l >= 6 && n.supply === 0 && n.discardCount > 1 ? f = {
		type: "draw",
		count: n.discardCount
	} : n.discardCount >= 3 && r.length < 9 && a.every((e) => e.handCount > 2) ? f = {
		type: "draw",
		count: Math.min(n.discardCount, 10 - r.length)
	} : l >= 6 && r.length < 8 && n.discardCount >= 2 && (f = {
		type: "draw",
		count: Math.min(n.discardCount, 8 - r.length)
	});
	else if (n.phase === "meld") {
		let t = $e(r, i.opened ? 3 : e.private.opening, d ? 2 : 1);
		if (t.length && (f = {
			type: "meld",
			groups: t
		}), !f && i.opened && r.length > (d ? 2 : 1)) {
			let e = n.melds.flatMap((e, t) => r.filter((t) => D([...e.cards, t])).map((n) => ({
				group: t,
				card: n,
				score: (o(e.owner) ? 1 : -1 / Math.max(1, a.length)) * (O([...e.cards, n]) - O(e.cards)) + (g(n) === 1 ? 10 : 5)
			}))).sort((e, t) => t.score - e.score);
			e.length && e[0].score >= 0 && (f = {
				type: "extend",
				group: e[0].group,
				cards: [e[0].card]
			});
		}
		if (!f && i.opened) for (let e = 0; e < n.melds.length; e++) {
			let t = n.melds[e];
			if (o(t.owner)) {
				for (let n of t.cards.filter((e) => g(e) === 1)) for (let i of r.filter((e) => g(e) !== 1 && _(e) === _(n))) {
					let r = t.cards.map((e) => e === n ? i : e);
					if (D(r) && O(r) > O(t.cards)) {
						f = {
							type: "trade",
							group: e,
							joker: n,
							card: i
						};
						break;
					}
				}
				if (f) break;
			}
		}
		if (!f) {
			let e = Qe(r), t = (t) => r.filter((e) => e !== t && (_(e) === _(t) && g(e) !== g(t) || (g(e) === g(t) || g(e) === 1 || g(t) === 1) && Math.abs(_(e) - _(t)) <= 2 && _(e) !== _(t))).length * 6 + (g(t) === 1 ? 6 : 0) + Math.max(0, ...e.filter((e) => e.includes(t)).map(O)) * .5;
			f = {
				type: "discard",
				card: [...r].sort((e, n) => t(e) - t(n) || _(n) - _(e))[0]
			};
		}
	}
	return f ??= et(e, t.rid), f ? {
		action: f,
		memory: u
	} : null;
}, Y = (e, t) => e.anchor(t), X = (e, t) => Y(e, `hand:${t}`) ?? Y(e, `seat:${t}`) ?? Y(e, "deck");
function nt(e, t = 60) {
	return {
		x: e.x + e.w / 2 - t / 2,
		y: e.y + e.h / 2 - t * .768,
		w: t,
		h: t * 1.536
	};
}
function Z(e, t, n, r = [], i = 400) {
	if (!e || !t) return null;
	let a = e.w > 150 ? nt(e, Math.min(t.w, 85)) : e, o = t.w > 150 ? nt(t) : t;
	return {
		ms: i,
		hide: r,
		node: /* @__PURE__ */ c(d, {
			from: a,
			to: o,
			ms: i,
			children: /* @__PURE__ */ c("span", {
				className: "mu-fx-card",
				style: {
					width: a.w,
					height: a.w * 1.536
				},
				children: n === void 0 ? /* @__PURE__ */ c(q, {}) : /* @__PURE__ */ c(Je, { card: n })
			})
		})
	};
}
var Q = (e) => e.data;
function $(e) {
	let t = e.filter((e) => e !== null);
	return t.length ? {
		ms: Math.max(...t.map((e) => e.ms)),
		hide: t.flatMap((e) => e.hide),
		node: t.map((e, t) => /* @__PURE__ */ c("span", { children: e.node }, t))
	} : null;
}
function rt(e, t) {
	let n = Q(e)?.card, r = n === void 0 ? null : Y(t, `card:${n}`);
	return Z(Q(e)?.displayed ? Y(t, `seat:${e.rid}`) : X(t, e.rid), r ?? Y(t, "trick"), n, n === void 0 ? [] : [`card:${n}`]);
}
var it = {
	deal(e, t) {
		return Z(Y(t, "deck"), X(t, t.myRid));
	},
	play: rt,
	bid(e, t) {
		return $((Q(e)?.cards ?? []).map((n) => Z(X(t, e.rid), Y(t, `card:${n}`) ?? Y(t, `seat:${e.rid}`), n, [`card:${n}`])));
	},
	reveal(e, t) {
		let n = Q(e)?.card;
		return Z(Y(t, `seat:${e.rid}`), n === void 0 ? null : Y(t, `card:${n}`), n, n === void 0 ? [] : [`card:${n}`], 460);
	},
	gather(e, t) {
		let n = (Q(e)?.plays ?? []).map((n) => Z(Y(t, `trick:${n.rid}`), Y(t, `seat:${e.rid}`), n.card)).filter((e) => e !== null);
		return n.length ? {
			ms: 400,
			node: n.map((e, t) => /* @__PURE__ */ c("span", { children: e.node }, t))
		} : null;
	},
	draw(e, t) {
		return Z(Y(t, Q(e)?.source === "discard" ? "discard" : "deck"), X(t, e.rid));
	},
	discard(e, t) {
		return Z(X(t, e.rid), Y(t, "discardCard"), Q(e)?.card, ["discardCard"]);
	},
	discardPrivate(e, t) {
		let n = e.secret;
		return $(Array.from({ length: Q(e)?.count ?? 0 }, (r, i) => Z(X(t, e.rid), Y(t, `seat:${e.rid}`), n?.cards?.[i])));
	},
	meld(e, t) {
		let n = Q(e)?.cards?.[0];
		return Z(X(t, e.rid), n === void 0 ? null : Y(t, `card:${n}`), n, n === void 0 ? [] : [`card:${n}`]);
	},
	trade(e, t) {
		let n = Q(e), r = Z(X(t, e.rid), n?.card === void 0 ? null : Y(t, `card:${n.card}`), n?.card, n?.card === void 0 ? [] : [`card:${n.card}`]), i = Z(n?.card === void 0 ? null : Y(t, `card:${n.card}`), X(t, e.rid), n?.joker);
		return r ? {
			ms: r.ms,
			hide: [...r.hide, ...n?.joker === void 0 ? [] : [`card:${n.joker}`]],
			node: /* @__PURE__ */ l(s, { children: [r.node, i?.node] })
		} : i;
	},
	catch(e, t) {
		let n = Q(e), r = [], i = [];
		if (n?.card !== void 0) {
			let a = n.paired ? Y(t, `seat:${e.rid}`) : Y(t, `card:${n.card}`), o = Z(X(t, e.rid), a, n.card);
			o && r.push(/* @__PURE__ */ c("span", { children: o.node }, "play")), n.paired || i.push(`card:${n.card}`);
		}
		for (let [i, a] of (n?.taken ?? []).entries()) {
			let n = Z(Y(t, "wild"), Y(t, `seat:${e.rid}`), a);
			n && r.push(/* @__PURE__ */ c("span", { children: n.node }, i));
		}
		return {
			ms: 400,
			node: r,
			hide: i
		};
	},
	exchange(e, t) {
		let n = Q(e), r = e.secret?.cards;
		return $(Array.from({ length: n?.count ?? 0 }, (i, a) => {
			let o = r?.[a], s = n?.to === t.myRid && o !== void 0;
			return Z(X(t, e.rid), s ? Y(t, `card:${o}`) : X(t, n?.to), o, s ? [`card:${o}`] : []);
		}));
	},
	prediction(e, t) {
		return $([Q(e)?.card, ...e.rid === t.myRid ? [e.secret?.card] : []].filter((e) => e !== void 0).map((n) => Z(X(t, e.rid), Y(t, `card:${n}`) ?? Y(t, `seat:${e.rid}`), n, [`card:${n}`])));
	},
	trump(e, t) {
		let n = Y(t, `seat:${e.rid}`);
		return n ? {
			ms: 400,
			node: /* @__PURE__ */ c(u, {
				at: n,
				ms: 400,
				children: /* @__PURE__ */ c("span", { className: "mu-fx-ring" })
			})
		} : null;
	},
	partner(e, t) {
		let n = Y(t, `seat:${e.rid}`);
		return n ? {
			ms: 400,
			node: /* @__PURE__ */ c(u, {
				at: n,
				ms: 400,
				children: /* @__PURE__ */ c("span", { className: "mu-fx-ring" })
			})
		} : null;
	}
};
//#endregion
//#region src/games/mumore/game-over.tsx
function at({ public: e, result: t, members: n, myRid: i, hintCount: a, onPlayAgain: o, onBackToLobby: s }) {
	let u = r(), d = e, f = (e) => n.find((t) => t.rid === e)?.name ?? e, p = t.winner.map(f).join(" · "), m = t.ranking;
	return /* @__PURE__ */ l("div", {
		className: "mu-ending",
		children: [
			/* @__PURE__ */ l("h1", { children: [
				/* @__PURE__ */ c(Ye, {}),
				" ",
				u(t.winner.length > 1 ? "games.mumore.tied" : "games.mumore.winner", { name: p })
			] }),
			/* @__PURE__ */ l("p", { children: [
				u(G[d.mode]),
				" · ",
				u("games.mumore.hands", { n: d.history.length })
			] }),
			/* @__PURE__ */ l("div", {
				className: "mu-ending-scroll",
				children: [
					/* @__PURE__ */ c("div", {
						className: "mu-score-paper",
						children: /* @__PURE__ */ l("table", { children: [/* @__PURE__ */ c("thead", { children: /* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", { children: u("games.mumore.results") }), m.map((e) => /* @__PURE__ */ l("th", { children: [f(e), e === i ? " ◇" : ""] }, e))] }) }), /* @__PURE__ */ l("tbody", { children: [/* @__PURE__ */ l("tr", {
							className: "mu-score-total",
							children: [/* @__PURE__ */ c("th", { children: u("games.mumore.total") }), m.map((e) => /* @__PURE__ */ c("td", { children: t.scores?.[e] ?? d.players.find((t) => t.rid === e)?.score }, e))]
						}), d.history.map((e) => /* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", { children: u("games.mumore.history", { n: e.round }) }), m.map((t) => /* @__PURE__ */ c("td", { children: e.delta[t] }, t))] }, e.round))] })] })
					}),
					d.history.map((e) => /* @__PURE__ */ l("details", {
						className: "mu-ending-note",
						children: [/* @__PURE__ */ l("summary", { children: [u("games.mumore.history", { n: e.round }), e.success !== null && " · " + u("games.mumore.achieved", {
							n: e.achieved,
							goal: e.goal
						})] }), /* @__PURE__ */ c("div", {
							className: "mu-score-paper",
							children: /* @__PURE__ */ l("table", { children: [/* @__PURE__ */ c("thead", { children: /* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", {}), m.map((e) => /* @__PURE__ */ c("th", { children: f(e) }, e))] }) }), /* @__PURE__ */ l("tbody", { children: [/* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", { children: u("games.mumore.cardPoints") }), m.map((t) => /* @__PURE__ */ c("td", { children: e.points[t] }, t))] }), /* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", { children: u("games.mumore.bonus") }), m.map((t) => /* @__PURE__ */ c("td", { children: e.bonus[t] }, t))] })] })] })
						})]
					}, e.round)),
					a !== void 0 && a > 0 && /* @__PURE__ */ c("p", {
						className: "mu-ending-note",
						children: u("games.mumore.hints", { n: a })
					}),
					m.filter((e) => (t.autopilot?.[e] ?? 0) > 0).map((e) => /* @__PURE__ */ l("p", {
						className: "mu-ending-note",
						children: [
							f(e),
							" · ",
							u("games.mumore.autoplay", { n: Math.round(t.autopilot[e] * 100) })
						]
					}, e))
				]
			}),
			/* @__PURE__ */ l("div", {
				className: "mu-ending-controls",
				children: [
					o && /* @__PURE__ */ c("button", {
						className: "mu-button mu-primary",
						onClick: o,
						children: u("games.mumore.again")
					}),
					s && /* @__PURE__ */ c("button", {
						className: "mu-button",
						onClick: s,
						children: u("games.mumore.lobby")
					}),
					!o && !s && /* @__PURE__ */ c("p", { children: u("games.mumore.waitingHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/mumore/options.tsx
function ot({ value: e, onChange: t }) {
	let n = r(), i = M.parse(e);
	return /* @__PURE__ */ l("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ c(p, {
			title: n("games.mumore.modeLabel"),
			columns: 2,
			children: Object.keys(G).map((e) => /* @__PURE__ */ c(f, {
				name: "mumore-mode",
				value: e,
				checked: i.mode === e,
				label: n(G[e]),
				accent: A.accent,
				onChange: () => t({
					...i,
					mode: e
				})
			}, e))
		}), [
			"revised",
			"classic",
			"don"
		].includes(i.mode) && /* @__PURE__ */ c(p, {
			title: n("games.mumore.handsLabel"),
			children: [3, 4].map((e) => /* @__PURE__ */ c(f, {
				name: "mumore-hands",
				value: String(e),
				checked: i.hands === e,
				label: n("games.mumore.hands", { n: e }),
				accent: A.accent,
				onChange: () => t({
					...i,
					hands: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/mumore/entry.tsx
var st = {
	definition: Me,
	View: Xe,
	bot: tt,
	fx: it,
	OverView: at,
	Options: ot,
	locales: {
		zh: {
			name: "多多益善：修订版",
			desc: "一副动物牌，八种玩法：公开竞标、双重将牌，以及捕获和组合挑战。",
			rules: "目标与牌组：\n游戏包含八种独立模式，在开始游戏时选择一种。牌组共有 60 张牌，分为绿龙、黄凤凰、紫黑豹、蓝独角兽和红刺猬五种颜色。每种颜色的数字为 0 至 9，其中数字 1 和 7 各有两张。数字为 0、8、9 的牌，其牌点为 0；数字为 1 至 5 的牌，其牌点为 1；数字为 6 和 7 的牌，其牌点为 2。数字决定出牌大小，三角表示牌点，动物圆章表示花色。最高总分获胜，允许并列。\n\n修订 Mü（3至6人）：\n4至6人发完全部牌；3人移除红色，每人15张，留3张暗底牌。从庄家开始顺时针竞标：展示任意数量尚未展示的手牌，或跳过。跳过后仍能再次展示；连续全员跳过时结束。最早达到最高展示数者持皇冠，第二位持盾牌；有人超过皇冠时，原皇冠立即成为盾牌。其余人只有超过当前盾牌展示数才接替盾牌，平数不接替。无人展示则重发；仅一人展示则没有盾牌、次将及防守奖金。\n· 3人皇冠获得底牌，再从未展示的手牌暗弃3张，计入自己的牌点。\n· 盾牌先选次将，皇冠后选主将：只能选自己展示牌中出现的颜色或数字，也可以无将。\n· 四至六人游戏中，皇冠玩家选择盾牌玩家以外的一名玩家作为伙伴；三人游戏中，皇冠玩家独自组成一方。\n· 皇冠首先领牌，后续由上一墩胜者领牌；手牌和公开展示牌都可打。必须跟领出的花色，将牌已经脱离原色并合并为一种花色。缺门时可打任意牌。主次将交集最高，其次主将、次将、普通领色牌；同级比较数字，相同牌先出者胜。\n每人获得自己赢得的牌点。皇冠队的目标牌点按人数确定：\n· 三人游戏为 16 加皇冠展示牌数的 2 倍。\n· 四人游戏为 28 加皇冠展示牌数的 2 倍。\n· 五人游戏为 21 加皇冠展示牌数的 3 倍。\n· 六人游戏为 16 加皇冠展示牌数的 4 倍。\n达标时每位皇冠队员获得皇冠展示数的10倍加主将奖金；否则每位防守队员获得盾牌展示数的5倍加次将奖金。\n将牌奖金如下：\n· 选择颜色作为将牌时，获得 10 分。\n· 选择数字 1 或 7 作为将牌时，获得 20 分。\n· 选择其他数字作为将牌时，获得 30 分。\n· 选择无将时，获得 40 分。\n按开局约定的3或4手结束。\n\n经典 Mü（4至6人）：\n· 其余流程沿用Mü，但每次展示后的总数不能超过当前最高数加1，因此首次最多1张。\n· 竞标结束若最高展示数平局，本手不打牌：最后达到该平数者扣展示数的10倍，其他并列最高的玩家，各获得自己展示牌数五倍的分数；其余玩家获得 0 分。\n· 最高数唯一者成为首领；副手为第二高者，并列时按展示数字从大到小逐个比较，完全相同则无副手。副手不能选无将，首领可以。\n· 达标时首领与伙伴的奖金为展示数的10倍加主将奖金减10，最高100。\n· 失败时，查实际牌点能达到的最高展示数，与原展示数相减得到差值；首领扣差值的10倍，伙伴不加不扣，其余玩家各获得该差值五倍的分数。\n· 所有人仍获得赢牌的牌点。本包按事先约定的3或4手结束。\n\nDon Eskridge 双人版：\n· 移除全部红色牌。每名玩家获得 15 张手牌，另留 3 张暗底牌和 6 张公开的侧牌，将其余 9 张牌移出游戏。\n· 竞标沿用修订 Mü 的规则。皇冠玩家获得底牌后，将 3 张手牌暗弃至自己的得分堆，并且没有伙伴。\n· 皇冠方使用三人游戏的目标牌点。公开的侧牌只帮助皇冠方完成目标，不计入任何玩家的个人牌点。\n· 其余计分沿用修订 Mü 的规则，按事先约定进行 3 手或 4 手。\n\nRoland Goslar 双人版：\n· 去红色。每人四个颜色列及主、次将列各放1张暗牌，再发4张明牌归颜色列和12张暗手，留4张底牌。\n· 竞标包括初始4张明牌，新展示牌直接归颜色列；双方未额外展示则重发。\n· 皇冠玩家获得底牌后，从自己的暗手中弃置 4 张牌，将其计入自己的牌点。\n· 盾牌选次将，若为颜色则整列明暗牌移动至次将列；若为数字只移动相符明牌。皇冠选主将，只移动相符明牌，再把主次交集放入超级将列。\n· 所有未被明牌覆盖的暗牌，由拥有者逐张选择翻牌次序，并立即归入相应列。\n· 每墩后再次检查并翻开未被覆盖的暗牌。任何明牌均可打，不限列顶；暗牌不参与跟牌义务。\n· 使用三人游戏的目标牌点。皇冠方达到目标时，皇冠玩家获得 10 分；否则盾牌玩家获得 5 分。不另外计算个人牌点或奖金。任意玩家率先达到 30 分时，游戏结束。\n\nWimmüln（3至6人）：\n· 3人去蓝、红两色。全部发完，庄家翻开最后两张牌：不同色且不同数字时，小数字的颜色是将色，小牌收回，大牌已作为第一墩领牌；同色或同数则无将，由庄家选择其中一张领牌。\n· 随后每人秘密选两张预测牌，第一张公开、第二张保密，两张都不参与出牌。\n· 全员提交后继续首墩。跟牌和吃墩同Mü，只有颜色将。\n· 每人获得赢牌牌点；实际赢得的墩数恰好等于较小的预测数字时，获得 5 分；恰好等于较大的预测数字时，获得 10 分；命中公开预测牌时奖金翻倍，两预测相同且命中时共25分。任一玩家达到200分时结束。\n\nThe Last Panther（3至8人）：\n· 三人游戏中，移除全部数字为 1 和 2 的牌；七人或八人游戏中，移除绿色、紫色、蓝色和红色的数字 2。\n· 发完牌后，每名玩家秘密向右侧玩家传递 3 张牌；六人游戏中改为传递 2 张。所有玩家提交后，才能接收传来的牌。\n· 持有绿色数字 5 的玩家必须以该牌领出第一墩。本模式没有将牌，必须跟随领出的颜色；牌相同时，先出牌的玩家获胜。\n· 赢得最后一墩的玩家获得 50 分。每张黄色牌增加 5 分，每张红色牌扣除 10 分，每张紫色数字 7 扣除 50 分，不另外计算牌点。\n· 任意玩家的累计得分达到 −250 分或更低时，游戏结束，累计得分最高的玩家获胜。\n\nSafarü（2至4人）：\n· 每名玩家获得 4 张手牌，在野外放置 4 张公开牌，其余牌组成供应牌堆。四人游戏中，位置相对的两名玩家组成一队。\n· 从庄家左边开始，每次打一张：可以捕获至少两张数字之和等于所打数字的野外牌；可以捕获至少一张、与所打数字合计17的野外牌；可以捕获一张同数字牌，并把所打牌也收入。每种方法最多一组，最多三组且不能重复取牌。\n· 使用加法捕获时野外若有0，至少取一个0。有可捕获的组合时必须至少捕获一组；若没有配对捕获，所打牌留在野外。\n· 每名玩家打完 4 张手牌后，由原庄家左侧的玩家成为新庄家。重新为每名玩家发 4 张牌；供应足够时，再向野外补充 4 张牌。\n· 供应耗尽且手牌打完后结算，野外剩牌不计分。捕获蓝色牌最多的玩家或队伍获得 24 分，捕获红色牌最多的玩家或队伍获得 12 分；并列时，平分对应奖励。每捕获一张数字为 0 的牌，扣除 5 分；再加上所有捕获牌的牌点。个人或队伍先达100分后结束。此模式采用正常捕获规则。\n\nRümmü（3至6人）：\n· 三人游戏中，每名玩家获得 9 张手牌；四人或五人游戏中，每名玩家获得 8 张；六人游戏中，每名玩家获得 7 张。四人或六人游戏中，位置相对的两名玩家组成一队，六人共分为三队。\n· 每回合先从牌库顶抽取 1 张牌，或从弃牌堆顶逐张领取卡牌。每领取 1 张后，可以查看该牌，再决定是否继续领取。\n· 随后可以打出组合、向已有组合追加卡牌，或换回组合中的黄色牌。最后必须弃置 1 张手牌，不能将最后一张手牌加入组合。\n每个组合至少包含 3 张牌，可以采用以下形式：\n· 数字相同，且颜色各不相同。\n· 数字连续，且全部同色或全部异色。\n黄色牌可以替代与其数字相同的任意颜色牌。同色顺子中，普通牌必须超过一半；异色顺子或相同数字的组合中，最多只能使用 1 张黄色牌。已经打出的组合不能拆分或重新排列，但可以使用合适的普通牌，换回其中的黄色牌。\n首次开牌可以同时打出多个组合，合计张数按累计分决定：个人累计分为负数时至少3张，0至99分至少4张，100至149分至少5张，150分及以上至少6张；团队累计分为负数、0至199分、200至399分、400分及以上时，分别至少3、4、5、6张。已开牌者可以向任何组合追加。\n最先出完手牌的玩家获得 10 分，其伙伴免于结算剩余手牌的罚分。其他玩家每剩余一张黄色手牌扣除 10 分，每剩余一张其他手牌扣除 5 分。\n桌面组合按以下方式计分：\n· 三张相同数字的组合获得 0 分。\n· 四张相同数字的组合，含黄色牌时获得 10 分，不含黄色牌时获得 30 分。\n· 五张相同数字的组合获得 50 分。\n· 数字为 1 或 7 的相同数字组合，其分数减半。\n· 长度为三张的顺子，混色获得 0 分，纯色获得 10 分。\n· 长度为四张的顺子，混色获得 10 分，纯色获得 20 分。\n· 长度为五张的顺子，混色获得 20 分，纯色获得 40 分；之后每增加一张牌，再获得 10 分。\n异色顺子或含黄色牌的顺子均视为混色。个人率先达到 200 分，或团队率先达到 500 分时，游戏结束。\n牌库耗尽时，保留弃牌堆顶的一张牌，将其余弃牌洗混成新牌库。如果没有可洗混的牌，本手按现有组合和剩余手牌结算，不给予出完手牌的奖金及伙伴免罚。这是此模式的补充裁定。",
			mode: {
				revised: "修订 Mü",
				classic: "经典 Mü",
				don: "双人 · Don Eskridge",
				roland: "双人 · Roland Goslar",
				wimmuln: "Wimmüln",
				rummu: "Rümmü",
				safaru: "Safarü",
				panther: "The Last Panther"
			},
			phase: {
				bid: "展示手牌参与竞标，或跳过",
				kitty: "选择暗弃的手牌",
				minor: "选择次将",
				major: "选择主将",
				partner: "选择伙伴",
				reveal: "选择一列翻开暗牌",
				play: "选择一张牌出牌",
				trickEnd: "本墩结算",
				predict: "选择两张预测牌，第一张将公开",
				lead: "选择首墩领牌",
				pass: "选择向右传出的牌",
				fish: "选择手牌与捕获组合",
				draw: "从牌库或弃牌堆摸牌",
				takeDiscard: "继续拿取弃牌，或停止取牌",
				meld: "打出组合，或弃一张牌结束回合",
				roundEnd: "本手得分",
				done: "对局结束"
			},
			suit: {
				green: "绿龙",
				yellow: "黄凤凰",
				purple: "紫黑豹",
				blue: "蓝独角兽",
				red: "红刺猬"
			},
			modeLabel: "玩法",
			handsLabel: "Mü 手数",
			hands: "{{n}}手",
			round: "第{{n}}手",
			wait: "等待{{name}}",
			ready: "已提交",
			hand: "你的手牌",
			display: "展示牌",
			crown: "皇冠",
			shield: "盾牌",
			partner: "伙伴",
			major: "主将",
			minor: "次将",
			none: "无将",
			numberTrump: "数字{{n}}",
			goal: "目标{{n}}牌点",
			score: "{{n}}分",
			bid: "展示{{n}}张",
			tricks: "{{n}}墩",
			handCount: "手牌{{n}}张",
			card: "{{suit}} {{n}} · {{points}}牌点",
			confirm: "确认",
			cancel: "取消选择",
			skip: "跳过",
			play: "出牌",
			reveal: "翻牌",
			submit: "提交所选牌",
			addGroup: "加入组合",
			clearGroups: "清空组合",
			groupCount: "已选{{n}}组",
			capture: "捕获",
			release: "放入野外",
			wild: "野外",
			supply: "牌库",
			discardPile: "弃牌堆",
			draw: "摸一张牌",
			takeDiscard: "拿取弃牌堆顶{{n}}张",
			stopDrawing: "停止取牌",
			discard: "弃牌并结束回合",
			extend: "追加所选牌",
			trade: "换回所选黄色牌",
			opening: "首次开牌至少{{n}}张",
			side: "公开侧牌",
			prediction: "公开预测",
			hidden: "秘密预测",
			column: "第{{n}}列",
			down: "{{n}}张暗牌",
			results: "得分记录",
			total: "总分",
			cardPoints: "牌点／组合",
			bonus: "奖金／罚分",
			delta: "本手合计",
			achieved: "皇冠队{{n}}／{{goal}}牌点",
			winner: "{{name}}获胜",
			tied: "并列获胜：{{name}}",
			again: "再来一局",
			lobby: "返回大厅",
			waitingHost: "等待主机开始新一局",
			invalid: "这个动作目前不合法，请检查选牌与当前阶段。",
			history: "第{{n}}手",
			publicCards: "查看{{name}}的展示牌",
			selected: "已选{{n}}张",
			returnConfirm: "返回大厅将离开当前结算，确定继续吗？",
			autoplay: "托管{{n}}%",
			hints: "使用建议{{n}}次"
		},
		en: {
			name: "Mü & more: Revised Edition",
			desc: "Eight games with one animal deck: open bidding, two trumps, fishing and melding.",
			rules: "Deck and objective:\nChoose one of eight separate games at setup. The deck has five suits: green dragons, yellow phoenixes, purple panthers, blue unicorns and red hedgehogs. Each has 0–9, with two 1s and two 7s. Card points: 0/8/9 score zero; 1–5 score one; 6/7 score two. Numbers determine trick strength; triangles show points, animal seals show suits. Highest total wins; ties are allowed.\n\nRevised Mü (3–6):\nDeal all 60 equally with 4–6 players. With 3, remove red, deal 15 each and leave a 3-card kitty. Starting with the dealer, reveal any number of previously hidden hand cards or pass. You may bid after passing. The auction ends after everyone passes consecutively. The first player to reach the highest display holds the Crown. A player exceeding it takes Crown and the previous Crown becomes Shield. Otherwise, a player takes Shield only by exceeding its current display; ties retain the earlier holder. With no bids, redeal. A sole bidder has no Shield, minor trump or defending bonus.\nWith 3 players, Crown takes the kitty and discards 3 hidden hand cards to their points pile. Shield chooses minor trump, then Crown chooses major: a suit or number present in their own display, or no trump. With 4–6, Crown chooses a partner other than Shield; with 3 Crown plays alone. Crown leads first, then each trick winner leads. Displayed cards remain visible and playable. Follow the led suit if possible. All trumps leave their original suits and form one suit. If void, play anything. The intersection of both trumps beats major, then minor, then the led ordinary suit; within each rank the higher number wins, identical cards favor the earlier play.\nEveryone scores their own captured card points. The Crown team’s target depends on player count:\n· With 3 players, the target is 16 card points plus twice the Crown’s displayed-card count.\n· With 4 players, it is 28 card points plus twice that count.\n· With 5 players, it is 21 card points plus three times that count.\n· With 6 players, it is 16 card points plus four times that count.\nIf reached, each Crown teammate gains 10×Crown bid plus major-trump bonus. Otherwise each defender gains 5×Shield bid plus minor-trump bonus.\nTrump bonuses are as follows:\n· A suit trump earns 10 points.\n· A number trump of 1 or 7 earns 20 points.\n· Any other number trump earns 30 points.\n· No trump earns 40 points.\nPlay the agreed 3 or 4 hands.\n\nClassic Mü (4–6):\nUse Mü play with these changes. A display may never exceed the current highest count plus one, so the first bid is at most one card. If the final highest bid is tied, no tricks are played: the last player to reach that tied count loses 10×bid, other tied leaders gain 5×bid, others zero. The sole highest bidder is Chief. Vice is second highest; ties compare displayed numbers in descending order, and an exact tie leaves no Vice. Vice cannot choose no trump. On success, Chief and partner each gain min(100,10×bid+major bonus−10). On failure, find the highest bid whose goal the team's actual points reached; subtract it from the original bid. Chief loses ten times that difference, partner receives no bonus or penalty, others gain five times it. Everyone also scores their captured card points. This implementation uses the agreed 3 or 4 hands.\n\nDon Eskridge (2):\nRemove red. Deal 15 each, 3 kitty, 6 face-up side cards; remove the other 9 unseen. Use the revised auction. Crown takes kitty and discards 3 hidden hand cards to their points pile. No partner. Use the 3-player goal. Side-card points help Crown reach the goal but never add to personal points. Other scoring is revised Mü. Play 3 or 4 hands.\n\nRoland Goslar (2):\nRemove red. Each player has one face-down card in each of four suit columns and two trump columns, four face-up cards sorted by suit, and 12 hidden hand cards. Leave a 4-card kitty. Bids include the initial four face-up cards; new bids go into suit columns. Redeal if neither adds cards. Crown takes kitty and discards four hidden hand cards. Shield chooses minor: choosing a suit moves that whole column, including face-down cards, to minor; choosing a number moves matching face-up cards only. Crown chooses major and moves matching face-up cards, then move intersections into super trump. Uncovered face-down cards are revealed one at a time in their owner's chosen order, immediately sorted into their proper columns. Repeat after every trick. Any face-up card is playable, not just the top card; face-down cards impose no following obligation. Use the 3-player goal. Crown scores 10 on success, otherwise Shield scores 5. These replace all card points and bonuses. First to 30 ends the game.\n\nWimmüln (3–6):\nWith 3, remove blue and red. Deal all cards. Dealer reveals the last two dealt to them. If they differ in both number and suit, the lower card's suit is trump; return it to hand and lead the higher card. If either number or suit matches, there is no trump and dealer chooses which to lead. Each player then secretly selects two prediction cards: first face up, second hidden. Neither is played. Reveal the first predictions after all submit, then continue the already-led trick. Follow and resolve as Mü, with only a suit trump. Score captured card points plus an exact-prediction bonus: lower number 5, higher number 10; double the bonus when the matching prediction is face up. Equal predictions hit for 25 total. End when anyone reaches 200.\n\nThe Last Panther (3–8):\nWith 3 remove every 1 and 2; with 7–8 remove the green, purple, blue and red 2s. Deal all. Secretly pass three cards right, or two with 6 players. Receive cards only after everyone submits. Green 5 must lead first. No trumps; follow suit, earlier identical cards win. The last trick scores 50 points. Each captured yellow card scores 5 points, each red card loses 10 points, and each purple 7 loses 50 points. No card-point additions. End when anyone reaches −250 or below; highest score wins.\n\nSafarü (2–4):\nDeal four each and four face up into the wild; the rest is supply. With 4, opposite seats are partners. Begin left of dealer. Play one card and catch wild cards using up to one group of each method: at least two wild numbers summing to the played number; at least one wild card whose sum with the played number is 17; or one equal-number wild card, also capturing the played card. Groups cannot overlap. An adding catch must include at least one zero whenever any are in the wild. If a catch exists, take at least one group. Unless pairing, the played card stays in the wild. When all hands empty, rotate dealer left, deal four each and add four to the wild while supply lasts. Once supply and hands are empty, remaining wild cards are unscored. The player or team with the most blue cards scores 24 points; the most red cards scores 12 points. Ties divide the corresponding award equally. Deduct 5 points for each zero and add all captured card points. End at 100 for a player or team. This package uses the normal catching game.\n\nRümmü (3–6):\nDeal nine cards each with three players, eight with four or five, or seven with six. With 4 or 6, opposite seats form two-person teams; 6 therefore has three teams. Each turn draw one from supply or take cards one at a time from the top of discard, inspecting each before deciding whether to continue, optionally meld/extend/trade, then discard one. Never meld your final card. A meld has at least three cards: equal numbers in different suits, or consecutive numbers all one suit or all different suits. Yellow cards substitute any suit of the same number. Single-suit runs require a majority of non-yellow cards. Mixed runs and equal-number sets allow at most one yellow. Do not rearrange existing melds. A suitable normal card may replace a yellow and return it to hand.\nOpening can contain several melds. The total number of cards depends on score: individual <0:3, 0–99:4, 100–149:5, 150+:6; team <0:3, 0–199:4, 200–399:5, 400+:6. Opened players may extend any meld.\nThe first player to empty their hand scores 10 points, and their partner receives no penalty for remaining hand cards. Other players lose 10 points per remaining yellow card and 5 points per other remaining card.\nScore table melds as follows:\n· A set of three equal numbers scores 0 points.\n· A set of four equal numbers scores 10 points with a yellow card, or 30 points without one.\n· A set of five equal numbers scores 50 points.\n· Sets of 1s or 7s score half their normal value.\n· A three-card run scores 0 points if mixed, or 10 if pure.\n· A four-card run scores 10 points if mixed, or 20 if pure.\n· A five-card run scores 20 points if mixed, or 40 if pure. Each additional card adds 10 points.\nAll-different runs and runs containing yellow are mixed. End the game when an individual reaches 200 points or a team reaches 500.\nIf supply empties, preserve the top discard and shuffle the rest into supply. If none can be shuffled, score the hand without a going-out bonus or partner exemption. This is a supplemental ruling for this version.",
			mode: {
				revised: "Revised Mü",
				classic: "Classic Mü",
				don: "2P · Don Eskridge",
				roland: "2P · Roland Goslar",
				wimmuln: "Wimmüln",
				rummu: "Rümmü",
				safaru: "Safarü",
				panther: "The Last Panther"
			},
			phase: {
				bid: "Reveal cards to bid, or pass",
				kitty: "Choose hidden cards to discard",
				minor: "Choose minor trump",
				major: "Choose major trump",
				partner: "Choose your partner",
				reveal: "Choose a column to reveal",
				play: "Choose a card to play",
				trickEnd: "Resolving trick",
				predict: "Choose two predictions; first will be public",
				lead: "Choose the opening lead",
				pass: "Choose cards to pass right",
				fish: "Choose a card and catch groups",
				draw: "Draw from supply or discard",
				takeDiscard: "Take another discard, or stop drawing",
				meld: "Meld cards, or discard to end your turn",
				roundEnd: "Hand scored",
				done: "Game over"
			},
			suit: {
				green: "Green dragon",
				yellow: "Yellow phoenix",
				purple: "Purple panther",
				blue: "Blue unicorn",
				red: "Red hedgehog"
			},
			modeLabel: "Game",
			handsLabel: "Mü hands",
			hands: "{{n}} hands",
			round: "Hand {{n}}",
			wait: "Waiting for {{name}}",
			ready: "Submitted",
			hand: "Your hand",
			display: "Display",
			crown: "Crown",
			shield: "Shield",
			partner: "Partner",
			major: "Major",
			minor: "Minor",
			none: "No trump",
			numberTrump: "Number {{n}}",
			goal: "Goal: {{n}} points",
			score: "{{n}} pts",
			bid: "{{n}} displayed",
			tricks: "{{n}} tricks",
			handCount: "{{n}} in hand",
			card: "{{suit}} {{n}} · {{points}} points",
			confirm: "Confirm",
			cancel: "Clear selection",
			skip: "Pass",
			play: "Play card",
			reveal: "Reveal",
			submit: "Submit cards",
			addGroup: "Add group",
			clearGroups: "Clear groups",
			groupCount: "{{n}} groups",
			capture: "Catch",
			release: "Release",
			wild: "Wild",
			supply: "Supply",
			discardPile: "Discard",
			draw: "Draw one",
			takeDiscard: "Take top {{n}} discards",
			stopDrawing: "Stop drawing",
			discard: "Discard and end turn",
			extend: "Extend with selected cards",
			trade: "Exchange selected yellow",
			opening: "Opening needs {{n}} cards",
			side: "Side cards",
			prediction: "Public prediction",
			hidden: "Hidden prediction",
			column: "Column {{n}}",
			down: "{{n}} face down",
			results: "Score sheet",
			total: "Total",
			cardPoints: "Cards / melds",
			bonus: "Bonus / penalty",
			delta: "Hand total",
			achieved: "Crown team {{n}} / {{goal}} points",
			winner: "{{name}} wins",
			tied: "Tied winners: {{name}}",
			again: "Play again",
			lobby: "Back to lobby",
			waitingHost: "Waiting for host to start again",
			invalid: "That move is not legal now. Check the selected cards and current phase.",
			history: "Hand {{n}}",
			publicCards: "View {{name}}’s display",
			selected: "{{n}} selected",
			returnConfirm: "Leave these results and return to the lobby?",
			autoplay: "{{n}}% autopilot",
			hints: "{{n}} hints used"
		}
	}
};
//#endregion
export { st as default };
