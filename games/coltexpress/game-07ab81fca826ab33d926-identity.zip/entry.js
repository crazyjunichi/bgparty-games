import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o, useFxAnchorsMaybe as s } from "@bgparty/sdk/fx/anchors";
import { useT as c } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { useFrame as m, useThree as h } from "@react-three/fiber";
import { ResilientCanvas as g } from "@bgparty/sdk/three/resilient-canvas";
import { AdditiveBlending as _, BackSide as v, DoubleSide as y, Vector3 as b } from "three";
import { usePrefersReducedMotion as x } from "@bgparty/sdk/fx/use-reduced-motion";
import { Floater as S, FlySprite as C, PulseBox as w } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as T } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/coltexpress/meta.ts
var E = {
	id: "coltexpress",
	tier: "beta",
	mechanics: ["hand-management", "action-programming"],
	interactionTags: [],
	nameKey: "games.coltexpress.name",
	descKey: "games.coltexpress.desc",
	rulesKey: "games.coltexpress.rules",
	icon: "🚂",
	iconImg: "games/coltexpress.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/coltexpress/en.pdf" },
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [5, 6],
	accent: "#b45309",
	releasedAt: "2026-09-17",
	search: {
		py: "ke er te kuai che",
		init: "ketkc"
	},
	hotseat: "cover"
}, ee = [
	"move",
	"floorChange",
	"marshal",
	"fire",
	"robbery",
	"punch"
], te = [
	"ghost",
	"belle",
	"cheyenne",
	"tuco",
	"django",
	"doc"
], ne = [
	"normal",
	"tunnel",
	"speeding",
	"switching"
], re = [
	"angryMarshal",
	"swivelArm",
	"braking",
	"takeItAll",
	"rebellion",
	"pickpocketing",
	"marshalsRevenge",
	"hostage"
], ie = t.enum(ee), D = t.union([t.literal(-1), t.literal(1)]), ae = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: ie,
		faceDown: t.boolean().optional()
	}),
	t.object({ type: t.literal("draw") }),
	t.object({
		type: t.literal("chooseMove"),
		dir: D,
		dist: t.int().min(1).max(3)
	}),
	t.object({
		type: t.literal("chooseMarshal"),
		dir: D
	}),
	t.object({
		type: t.literal("chooseFire"),
		target: t.string()
	}),
	t.object({
		type: t.literal("chooseRobbery"),
		lootIdx: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("choosePunch"),
		target: t.string(),
		lootIdx: t.int().nonnegative().nullable(),
		dir: D
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), O = t.string(), oe = t.enum([
	"purse",
	"gem",
	"strongbox"
]), se = t.object({
	kind: oe,
	value: t.int().nullable()
}), ce = t.union([
	t.object({
		kind: t.literal("move"),
		moves: t.array(t.object({
			dir: D,
			dist: t.int().min(1).max(3)
		}))
	}),
	t.object({
		kind: t.literal("marshal"),
		dirs: t.array(D)
	}),
	t.object({
		kind: t.literal("fire"),
		targets: t.array(O)
	}),
	t.object({
		kind: t.literal("robbery"),
		lootIdxs: t.array(t.int().nonnegative())
	}),
	t.object({
		kind: t.literal("punch"),
		targets: t.array(O),
		lootCounts: t.record(t.string(), t.int().nonnegative()),
		dirs: t.array(D)
	})
]), le = t.object({
	players: t.array(t.object({
		rid: O,
		character: t.enum(te),
		car: t.int().nonnegative(),
		roof: t.boolean(),
		loot: t.array(se),
		handCount: t.int().nonnegative(),
		fired: t.int().nonnegative(),
		taken: t.int().nonnegative()
	})),
	cars: t.array(t.object({
		inside: t.array(se),
		roof: t.array(se)
	})),
	marshal: t.int().nonnegative(),
	strongbox2: t.boolean(),
	neutralLeft: t.int().nonnegative(),
	round: t.int().min(1),
	roundsTotal: t.int(),
	roundCard: t.object({
		turns: t.array(t.enum(ne)),
		event: t.enum(re).nullable()
	}),
	phase: t.enum([
		"scheme",
		"steal",
		"done"
	]),
	scheme: t.object({
		turnIdx: t.int().nonnegative(),
		actor: O,
		actionsLeft: t.int().positive(),
		order: t.array(O)
	}).nullable(),
	pile: t.array(t.object({
		by: O,
		card: ie.nullable(),
		faceDown: t.boolean()
	})),
	execIdx: t.int().nonnegative(),
	pending: t.object({
		by: O,
		card: ie
	}).nullable(),
	options: ce.nullable()
}), ue = t.object({
	hand: t.array(t.union([ie, t.literal("bullet")])),
	deckCount: t.int().nonnegative(),
	myLoot: t.array(t.object({
		kind: oe,
		value: t.int()
	})),
	bulletsLeft: t.int().nonnegative(),
	canFaceDown: t.boolean()
}), de = 1e3, fe = 1e3, pe = [
	"move",
	"move",
	"floorChange",
	"floorChange",
	"robbery",
	"robbery",
	"fire",
	"fire",
	"punch",
	"marshal"
], me = [
	{
		gems: 0,
		purses: 1
	},
	{
		gems: 3,
		purses: 0
	},
	{
		gems: 1,
		purses: 1
	},
	{
		gems: 1,
		purses: 3
	},
	{
		gems: 0,
		purses: 3
	},
	{
		gems: 1,
		purses: 4
	}
], he = [
	250,
	250,
	250,
	250,
	250,
	250,
	250,
	250,
	300,
	300,
	350,
	350,
	400,
	400,
	450,
	450,
	500,
	500
], ge = [
	{
		turns: [
			"normal",
			"tunnel",
			"normal",
			"tunnel",
			"normal"
		],
		event: null
	},
	{
		turns: [
			"normal",
			"tunnel",
			"normal",
			"normal"
		],
		event: "swivelArm"
	},
	{
		turns: [
			"normal",
			"speeding",
			"normal"
		],
		event: null
	},
	{
		turns: [
			"normal",
			"normal",
			"normal",
			"normal"
		],
		event: "braking"
	},
	{
		turns: [
			"normal",
			"normal",
			"tunnel",
			"normal",
			"normal"
		],
		event: "rebellion"
	},
	{
		turns: [
			"normal",
			"normal",
			"tunnel",
			"switching"
		],
		event: "angryMarshal"
	},
	{
		turns: [
			"normal",
			"tunnel",
			"speeding",
			"normal"
		],
		event: "takeItAll"
	}
], _e = [
	{
		turns: [
			"normal",
			"normal",
			"switching"
		],
		event: "angryMarshal"
	},
	{
		turns: [
			"normal",
			"speeding",
			"switching"
		],
		event: "takeItAll"
	},
	{
		turns: [
			"normal",
			"tunnel",
			"normal",
			"tunnel"
		],
		event: null
	},
	{
		turns: [
			"normal",
			"tunnel",
			"normal"
		],
		event: "swivelArm"
	},
	{
		turns: ["normal", "speeding"],
		event: null
	},
	{
		turns: [
			"normal",
			"tunnel",
			"normal",
			"normal"
		],
		event: "braking"
	},
	{
		turns: [
			"normal",
			"tunnel",
			"normal",
			"switching"
		],
		event: "rebellion"
	}
], ve = [
	{
		turns: [
			"normal",
			"normal",
			"tunnel",
			"normal"
		],
		event: "marshalsRevenge"
	},
	{
		turns: [
			"normal",
			"normal",
			"tunnel",
			"normal"
		],
		event: "hostage"
	},
	{
		turns: [
			"normal",
			"normal",
			"tunnel",
			"normal"
		],
		event: "pickpocketing"
	}
], k = {
	stealBegin: 900,
	exec: 1e3,
	hit: 1300,
	event: 1600,
	wait: 800,
	deal: 900
}, A = (e) => e.cars.length - 1;
function j(t, n, r) {
	let i = [...t];
	for (let t = i.length - 1; t > 0; --t) {
		let a = e(n, r.c, t + 1);
		r.c += 1, [i[t], i[a]] = [i[a], i[t]];
	}
	return i;
}
var ye = (e) => e.roundCards[e.round - 1].turns[e.turnIdx];
function be(e) {
	let t = e.players.length, n = ye(e) === "switching" ? -1 : 1;
	return Array.from({ length: t }, (r, i) => e.players[(e.firstPlayer + n * i + t * t) % t]);
}
var xe = (e) => ye(e) === "speeding" ? 2 : 1;
function M(e, t) {
	return e.neutralLeft <= 0 ? !1 : (--e.neutralLeft, e.decks[t].push("bullet"), e.taken[t] += 1, !0);
}
function Se(e, t) {
	let n = e.positions[t];
	return n.roof || n.car !== e.marshal ? !1 : (n.roof = !0, M(e, t));
}
function Ce(e, t) {
	let n = e.positions[t], r = [];
	if (n.roof) for (let t = 1; t <= 3; t += 1) n.car - t >= 0 && r.push({
		dir: -1,
		dist: t
	}), n.car + t <= A(e) && r.push({
		dir: 1,
		dist: t
	});
	else n.car > 0 && r.push({
		dir: -1,
		dist: 1
	}), n.car < A(e) && r.push({
		dir: 1,
		dist: 1
	});
	return {
		kind: "move",
		moves: r
	};
}
function we(e) {
	let t = [];
	return e.marshal > 0 && t.push(-1), e.marshal < A(e) && t.push(1), {
		kind: "marshal",
		dirs: t
	};
}
function Te(e, t) {
	if (e.bulletsLeft[t] <= 0) return {
		kind: "fire",
		targets: []
	};
	let n = e.positions[t], r = [];
	if (n.roof) for (let i of [-1, 1]) for (let a = 1; n.car + i * a >= 0 && n.car + i * a <= A(e); a += 1) {
		let o = n.car + i * a, s = e.players.filter((n) => n !== t && e.positions[n].roof && e.positions[n].car === o);
		if (s.length) {
			r.push(...s);
			break;
		}
	}
	else for (let i of [-1, 1]) {
		let a = n.car + i;
		if (!(a < 0 || a > A(e))) for (let n of e.players) n !== t && !e.positions[n].roof && e.positions[n].car === a && r.push(n);
	}
	if (e.characters[t] === "tuco") for (let i of e.players) i !== t && e.positions[i].car === n.car && e.positions[i].roof !== n.roof && r.push(i);
	let i = r.filter((t) => e.characters[t] !== "belle");
	return i.length && (r = i), {
		kind: "fire",
		targets: r
	};
}
function Ee(e, t) {
	let n = e.positions[t];
	return {
		kind: "robbery",
		lootIdxs: (n.roof ? e.cars[n.car].roof : e.cars[n.car].inside).map((e, t) => t)
	};
}
function De(e, t) {
	let n = e.positions[t], r = e.players.filter((r) => r !== t && e.positions[r].car === n.car && e.positions[r].roof === n.roof), i = r.filter((t) => e.characters[t] !== "belle");
	i.length && (r = i);
	let a = [];
	n.car > 0 && a.push(-1), n.car < A(e) && a.push(1);
	let o = {};
	for (let t of r) o[t] = e.loots[t].length;
	return {
		kind: "punch",
		targets: r,
		lootCounts: o,
		dirs: a
	};
}
function N(e, t, n) {
	switch (n) {
		case "move": return Ce(e, t);
		case "marshal": return we(e);
		case "fire": return Te(e, t);
		case "robbery": return Ee(e, t);
		case "punch": return De(e, t);
		case "floorChange": return null;
	}
}
function Oe(e) {
	if (!e) return !1;
	switch (e.kind) {
		case "move": return e.moves.length > 1;
		case "marshal": return e.dirs.length > 1;
		case "fire": return e.targets.length > 1;
		case "robbery": return e.lootIdxs.length > 1;
		case "punch": return e.targets.length > 1 || e.targets.length === 1 && (e.dirs.length > 1 || e.lootCounts[e.targets[0]] > 1);
	}
}
function ke(e, t, n, r) {
	let i = { ...e.positions[t] };
	e.positions[t].car += n * r;
	let a = Se(e, t);
	return {
		kind: "execMove",
		rid: t,
		data: {
			from: i,
			to: { ...e.positions[t] },
			ejected: a
		}
	};
}
function Ae(e, t) {
	let n = e.positions[t], r = { ...n };
	n.roof = !n.roof;
	let i = Se(e, t);
	return {
		kind: "execFloor",
		rid: t,
		data: {
			from: r,
			to: { ...n },
			ejected: i
		}
	};
}
function je(e, t) {
	let n = e.marshal;
	e.marshal += t;
	let r = [];
	for (let t of e.players) {
		let n = e.positions[t];
		!n.roof && n.car === e.marshal && (n.roof = !0, M(e, t), r.push(t));
	}
	return {
		kind: "execMarshal",
		data: {
			from: n,
			to: e.marshal,
			ejected: r
		}
	};
}
function Me(e, t, n) {
	if (n === null || e.bulletsLeft[t] <= 0) return {
		kind: "execFire",
		rid: t,
		data: { miss: !0 }
	};
	--e.bulletsLeft[t], e.fired[t] += 1, e.decks[n].push("bullet"), e.taken[n] += 1;
	let r = null, i = !1;
	if (e.characters[t] === "django") {
		let a = Math.sign(e.positions[n].car - e.positions[t].car);
		if (a !== 0) {
			let t = e.positions[n], o = Math.min(Math.max(t.car + a, 0), A(e));
			o !== t.car && (t.car = o, r = { ...t }, i = Se(e, n));
		}
	}
	return {
		kind: "execFire",
		rid: t,
		data: {
			target: n,
			pushedTo: r,
			ejected: i
		}
	};
}
function Ne(e, t, n) {
	let r = e.positions[t], [i] = (r.roof ? e.cars[r.car].roof : e.cars[r.car].inside).splice(n, 1);
	return e.loots[t].push(i), {
		kind: "execRobbery",
		rid: t,
		data: {
			car: r.car,
			roof: r.roof,
			lootKind: i.kind
		}
	};
}
function Pe(e, t, n, r, i) {
	let a = e.positions[t], o = null, s = !1;
	if (r !== null) {
		let [i] = e.loots[n].splice(r, 1);
		o = i.kind, i.kind === "purse" && e.characters[t] === "cheyenne" ? (e.loots[t].push(i), s = !0) : (a.roof ? e.cars[a.car].roof : e.cars[a.car].inside).push(i);
	}
	e.positions[n].car += i;
	let c = Se(e, n);
	return {
		kind: "execPunch",
		rid: t,
		data: {
			target: n,
			dir: i,
			dropped: o,
			stolen: s,
			to: { ...e.positions[n] },
			ejected: c
		}
	};
}
function Fe(e, t, n, r) {
	if (!r) return Ie(e, t, n, N(e, t, n));
	switch (r.kind) {
		case "move": return ke(e, t, r.dir, r.dist);
		case "marshal": return je(e, r.dir);
		case "fire": return Me(e, t, r.target);
		case "robbery": return Ne(e, t, r.lootIdx);
		case "punch": return Pe(e, t, r.target, r.lootIdx, r.dir);
	}
}
function Ie(e, t, n, r) {
	switch (n) {
		case "floorChange": return Ae(e, t);
		case "move": {
			let i = r.moves;
			return i.length ? ke(e, t, i[0].dir, i[0].dist) : {
				kind: "execFizzle",
				rid: t,
				data: { card: n }
			};
		}
		case "marshal": {
			let i = r.dirs;
			return i.length ? je(e, i[0]) : {
				kind: "execFizzle",
				rid: t,
				data: { card: n }
			};
		}
		case "fire": {
			let n = r.targets;
			return Me(e, t, n.length ? n[0] : null);
		}
		case "robbery": {
			let i = r.lootIdxs;
			return i.length ? Ne(e, t, i[0]) : {
				kind: "execFizzle",
				rid: t,
				data: { card: n }
			};
		}
		case "punch": {
			let i = r;
			if (!i.targets.length) return {
				kind: "execFizzle",
				rid: t,
				data: { card: n }
			};
			let a = i.targets[0];
			return Pe(e, t, a, i.lootCounts[a] > 0 ? 0 : null, i.dirs[0]);
		}
	}
}
function Le(t) {
	let n = t.roundCards[t.round - 1].event;
	if (!n) return null;
	let r = A(t);
	switch (n) {
		case "angryMarshal": {
			let e = t.players.filter((e) => t.positions[e].roof && t.positions[e].car === t.marshal);
			for (let n of e) M(t, n);
			let i = t.marshal;
			return t.marshal < r && (t.marshal += 1), {
				kind: "event",
				data: {
					event: n,
					victims: e,
					from: i,
					to: t.marshal
				}
			};
		}
		case "swivelArm": {
			let e = t.players.filter((e) => t.positions[e].roof && t.positions[e].car !== r);
			for (let n of e) t.positions[n].car = r;
			return {
				kind: "event",
				data: {
					event: n,
					movers: e
				}
			};
		}
		case "braking": {
			let e = t.players.filter((e) => t.positions[e].roof && t.positions[e].car > 0);
			for (let n of e) --t.positions[n].car;
			return {
				kind: "event",
				data: {
					event: n,
					movers: e
				}
			};
		}
		case "takeItAll": return t.strongbox2 ? (t.strongbox2 = !1, t.cars[t.marshal].inside.push({
			kind: "strongbox",
			value: de
		}), {
			kind: "event",
			data: {
				event: n,
				car: t.marshal
			}
		}) : {
			kind: "event",
			data: {
				event: n,
				nothing: !0
			}
		};
		case "rebellion": {
			let e = t.players.filter((e) => !t.positions[e].roof);
			for (let n of e) M(t, n);
			return {
				kind: "event",
				data: {
					event: n,
					victims: e
				}
			};
		}
		case "pickpocketing": {
			let r = [];
			for (let n of t.players) {
				let i = t.positions[n];
				if (!t.players.every((e) => e === n || t.positions[e].car !== i.car || t.positions[e].roof !== i.roof)) continue;
				let a = i.roof ? t.cars[i.car].roof : t.cars[i.car].inside, o = a.map((e, t) => e.kind === "purse" ? t : -1).filter((e) => e >= 0);
				if (!o.length) continue;
				let s = o[e(t.seed, t.rngCursor, o.length)];
				t.rngCursor += 1;
				let [c] = a.splice(s, 1);
				t.loots[n].push(c), r.push({
					rid: n,
					car: i.car,
					roof: i.roof
				});
			}
			return {
				kind: "event",
				data: {
					event: n,
					picks: r
				}
			};
		}
		case "marshalsRevenge": {
			let e = [];
			for (let n of t.players) {
				if (!t.positions[n].roof || t.positions[n].car !== t.marshal) continue;
				let r = t.loots[n].map((e, t) => ({
					l: e,
					i: t
				})).filter(({ l: e }) => e.kind === "purse");
				if (!r.length) continue;
				let i = r.reduce((e, t) => t.l.value < e.l.value ? t : e);
				t.loots[n].splice(i.i, 1), e.push(n);
			}
			return {
				kind: "event",
				data: {
					event: n,
					victims: e
				}
			};
		}
		case "hostage": {
			let e = t.players.filter((e) => t.positions[e].car === 0);
			for (let n of e) t.loots[n].push({
				kind: "purse",
				value: 250
			});
			return {
				kind: "event",
				data: {
					event: n,
					winners: e
				}
			};
		}
	}
}
function Re(e) {
	let t = { c: e.rngCursor }, n = [];
	for (let [r, i] of e.players.entries()) {
		let a = e.pile.filter((e) => e.by === i).map((e) => e.card), o = j([
			...e.hands[i],
			...e.decks[i],
			...a
		], e.seed, t), s = e.characters[i] === "doc" ? 7 : 6;
		e.hands[i] = o.splice(o.length - s), e.decks[i] = o, n.push({
			kind: "deal",
			rid: i,
			data: { count: e.hands[i].length },
			for: [i],
			secret: { cards: e.hands[i] },
			...r > 0 ? { with: !0 } : {}
		});
	}
	return e.rngCursor = t.c, e.pile = [], n;
}
function ze(t, n, r) {
	let i = n.length, a = { c: 0 }, o = j([...te], r, a), s = {};
	for (let [e, t] of n.entries()) s[t] = o[e];
	let c = [...j(i <= 4 ? ge : _e, r, a).slice(0, 4), j(ve, r, a)[0]], l = j(he.slice(i), r, a), u = 0, d = [{
		inside: [{
			kind: "strongbox",
			value: de
		}],
		roof: []
	}];
	for (let e = 0; e < i; e += 1) {
		let t = me[e], n = [];
		for (let e = 0; e < t.gems; e += 1) n.push({
			kind: "gem",
			value: 500
		});
		for (let e = 0; e < t.purses; e += 1) n.push({
			kind: "purse",
			value: l[u++]
		});
		d.push({
			inside: n,
			roof: []
		});
	}
	let f = {};
	for (let [e, t] of n.entries()) f[t] = {
		car: i - e % 2,
		roof: !1
	};
	let p = e(r, a.c, i);
	a.c += 1;
	let m = {
		players: n,
		characters: s,
		cars: d,
		positions: f,
		marshal: 0,
		strongbox2: !0,
		neutralLeft: 13,
		decks: {},
		hands: {},
		loots: {},
		bulletsLeft: {},
		fired: {},
		taken: {},
		roundCards: c,
		round: 1,
		firstPlayer: p,
		phase: "scheme",
		turnIdx: 0,
		orderPos: 0,
		actionsLeft: 1,
		ghostSpent: {},
		pile: [],
		execIdx: 0,
		pending: null,
		eventDone: !1,
		beatMs: k.deal,
		seed: r,
		rngCursor: 0
	};
	for (let e of n) m.decks[e] = j(pe, r, a), m.hands[e] = [], m.loots[e] = [{
		kind: "purse",
		value: 250
	}], m.bulletsLeft[e] = 6, m.fired[e] = 0, m.taken[e] = 0;
	return m.rngCursor = a.c, m.actionsLeft = xe(m), {
		state: m,
		fx: Re(m)
	};
}
function Be(e) {
	return e.actionsLeft > 1 ? (--e.actionsLeft, !1) : (e.orderPos += 1, e.orderPos >= e.players.length && (e.orderPos = 0, e.turnIdx += 1, e.turnIdx >= e.roundCards[e.round - 1].turns.length) ? (e.phase = "steal", e.execIdx = 0, e.pending = null, e.beatMs = k.stealBegin, !0) : (e.actionsLeft = xe(e), !1));
}
function Ve(e) {
	return e === "fire" || e === "punch" ? k.hit : k.exec;
}
function He(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "steal" || e.pending) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		if (t.execIdx < t.pile.length) {
			let e = t.pile[t.execIdx], n = N(t, e.by, e.card);
			if (Oe(n)) return t.pending = {
				by: e.by,
				card: e.card
			}, t.beatMs = k.wait, {
				state: t,
				fx: [{
					kind: "execReveal",
					rid: e.by,
					data: { card: e.card }
				}]
			};
			let r = Ie(t, e.by, e.card, n);
			return t.execIdx += 1, t.beatMs = Ve(e.card), {
				state: t,
				fx: [r]
			};
		}
		if (!t.eventDone) {
			t.eventDone = !0;
			let e = Le(t);
			if (e) return t.beatMs = k.event, {
				state: t,
				fx: [e]
			};
		}
		if (t.round >= 5) return t.phase = "done", {
			state: t,
			fx: []
		};
		t.round += 1, t.firstPlayer = (t.firstPlayer + 1) % t.players.length, t.phase = "scheme", t.turnIdx = 0, t.orderPos = 0, t.ghostSpent = {}, t.eventDone = !1, t.execIdx = 0, t.actionsLeft = xe(t), t.beatMs = k.deal;
		let n = Re(t);
		return {
			state: t,
			fx: [{
				kind: "roundStart",
				data: { round: t.round }
			}, ...n.map((e, t) => t === 0 ? {
				...e,
				with: !0
			} : e)]
		};
	}
	if (t.type === "play" || t.type === "draw") {
		if (e.phase !== "scheme" || be(e)[e.orderPos] !== n.by) return { code: "games.coltexpress.errNotYourTurn" };
		let r = structuredClone(e), i = ye(r), a = [];
		if (t.type === "play") {
			let e = r.hands[n.by].indexOf(t.card);
			if (e < 0) return { code: "games.coltexpress.errBadCard" };
			r.hands[n.by].splice(e, 1);
			let o = r.characters[n.by] === "ghost" && r.turnIdx === 0 && !r.ghostSpent[n.by], s = i === "tunnel" || o && t.faceDown === !0;
			r.pile.push({
				by: n.by,
				card: t.card,
				faceDown: s
			}), a.push(s ? {
				kind: "play",
				rid: n.by,
				data: { faceDown: !0 },
				for: [n.by],
				secret: { card: t.card }
			} : {
				kind: "play",
				rid: n.by,
				data: {
					faceDown: !1,
					card: t.card
				}
			});
		} else {
			let e = [];
			for (let t = 0; t < 3 && r.decks[n.by].length; t += 1) e.push(r.decks[n.by].pop());
			r.hands[n.by].push(...e), a.push({
				kind: "draw",
				rid: n.by,
				data: { count: e.length },
				for: [n.by],
				secret: { cards: e }
			});
		}
		return r.characters[n.by] === "ghost" && r.turnIdx === 0 && (r.ghostSpent[n.by] = !0), Be(r) && a.push({ kind: "stealBegin" }), {
			state: r,
			fx: a
		};
	}
	let r = e.pending;
	if (!r || r.by !== n.by) return { code: "games.coltexpress.errNotYourTurn" };
	let i = structuredClone(e), a = N(i, n.by, r.card), o = { code: "games.coltexpress.errBadChoice" }, s;
	switch (t.type) {
		case "chooseMove":
			if (a?.kind !== "move" || !a.moves.some((e) => e.dir === t.dir && e.dist === t.dist)) return o;
			s = ke(i, n.by, t.dir, t.dist);
			break;
		case "chooseMarshal":
			if (a?.kind !== "marshal" || !a.dirs.includes(t.dir)) return o;
			s = je(i, t.dir);
			break;
		case "chooseFire":
			if (a?.kind !== "fire" || !a.targets.includes(t.target)) return o;
			s = Me(i, n.by, t.target);
			break;
		case "chooseRobbery":
			if (a?.kind !== "robbery" || !a.lootIdxs.includes(t.lootIdx)) return o;
			s = Ne(i, n.by, t.lootIdx);
			break;
		case "choosePunch": {
			if (a?.kind !== "punch" || !a.targets.includes(t.target) || !a.dirs.includes(t.dir)) return o;
			let e = a.lootCounts[t.target];
			if (e === 0 ? t.lootIdx !== null : t.lootIdx === null || t.lootIdx >= e) return o;
			s = Pe(i, n.by, t.target, t.lootIdx, t.dir);
			break;
		}
	}
	return i.pending = null, i.execIdx += 1, i.beatMs = Ve(r.card), {
		state: i,
		fx: [s]
	};
}
function Ue(e) {
	return e.map((e) => ({
		kind: e.kind,
		value: e.kind === "purse" ? null : e.value
	}));
}
function We(e, t) {
	let n = e.phase === "scheme" ? be(e) : [];
	return {
		public: {
			players: e.players.map((t) => ({
				rid: t,
				character: e.characters[t],
				car: e.positions[t].car,
				roof: e.positions[t].roof,
				loot: Ue(e.loots[t]),
				handCount: e.hands[t].length,
				fired: e.fired[t],
				taken: e.taken[t]
			})),
			cars: e.cars.map((e) => ({
				inside: Ue(e.inside),
				roof: Ue(e.roof)
			})),
			marshal: e.marshal,
			strongbox2: e.strongbox2,
			neutralLeft: e.neutralLeft,
			round: e.round,
			roundsTotal: 5,
			roundCard: e.roundCards[e.round - 1],
			phase: e.phase,
			scheme: e.phase === "scheme" ? {
				turnIdx: e.turnIdx,
				actor: n[e.orderPos],
				actionsLeft: e.actionsLeft,
				order: n
			} : null,
			pile: e.pile.map((n, r) => ({
				by: n.by,
				faceDown: n.faceDown,
				card: !n.faceDown || r < e.execIdx || e.pending !== null && r === e.execIdx || n.by === t ? n.card : null
			})),
			execIdx: e.execIdx,
			pending: e.pending,
			options: e.pending ? N(e, e.pending.by, e.pending.card) : null
		},
		private: {
			hand: e.hands[t] ?? [],
			deckCount: e.decks[t]?.length ?? 0,
			myLoot: e.loots[t] ?? [],
			bulletsLeft: e.bulletsLeft[t] ?? 0,
			canFaceDown: e.phase === "scheme" && (ye(e) === "tunnel" || e.characters[t] === "ghost" && e.turnIdx === 0 && !e.ghostSpent[t])
		}
	};
}
var Ge = (e) => e.reduce((e, t) => e + t.value, 0);
function Ke(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = Ge(e.loots[n]);
	let n = Math.max(...e.players.map((t) => e.fired[t]));
	if (n > 0) for (let r of e.players) e.fired[r] === n && (t[r] += fe);
	let r = [...e.players].sort((n, r) => t[r] - t[n] || e.taken[n] - e.taken[r]), i = r[0];
	return {
		phase: "done",
		winner: r.filter((n) => t[n] === t[i] && e.taken[n] === e.taken[i]),
		ranking: r,
		scores: t
	};
}
function qe(e) {
	return e.phase === "steal" && !e.pending ? e.beatMs : null;
}
var Je = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: E,
	schemas: {
		action: ae,
		publicView: le,
		privateView: ue
	},
	setup: ze,
	reduce: He,
	viewFor: We,
	status: Ke,
	nextTickIn: qe
}, Ye = {
	ghost: "games/coltexpress/fig-ghost.png",
	belle: "games/coltexpress/fig-belle.png",
	cheyenne: "games/coltexpress/fig-cheyenne.png",
	tuco: "games/coltexpress/fig-tuco.png",
	django: "games/coltexpress/fig-django.png",
	doc: "games/coltexpress/fig-doc.png"
}, Xe = {
	ghost: .406,
	belle: .453,
	cheyenne: .273,
	tuco: .516,
	django: .367,
	doc: .289
}, Ze = "games/coltexpress/fig-marshal.png", Qe = .367;
function $e(e) {
	return {
		WebkitMaskImage: `url(${e})`,
		maskImage: `url(${e})`,
		WebkitMaskSize: "contain",
		maskSize: "contain",
		WebkitMaskRepeat: "no-repeat",
		maskRepeat: "no-repeat",
		WebkitMaskPosition: "center bottom",
		maskPosition: "center bottom",
		maskMode: "luminance"
	};
}
function et({ src: e, ratio: t, edge: n, className: r }) {
	return /* @__PURE__ */ f("span", {
		className: `block ${r ?? ""}`,
		style: {
			aspectRatio: `${t}`,
			filter: n ? `drop-shadow(0 0 1px ${n}) drop-shadow(0 0 2.5px ${n})` : void 0
		},
		children: /* @__PURE__ */ f("span", {
			className: "block h-full w-full",
			style: {
				...$e(e),
				backgroundColor: "var(--color-ink)"
			}
		})
	});
}
function tt({ character: e, edge: t, className: n }) {
	return /* @__PURE__ */ f(et, {
		src: Ye[e],
		ratio: Xe[e],
		edge: t,
		className: n
	});
}
function nt({ className: e }) {
	return /* @__PURE__ */ f(et, {
		src: Ze,
		ratio: Qe,
		edge: "var(--color-surface)",
		className: e
	});
}
//#endregion
//#region src/games/coltexpress/i18n-keys.ts
var P = {
	move: "games.coltexpress.actionMove",
	floorChange: "games.coltexpress.actionFloorChange",
	marshal: "games.coltexpress.actionMarshal",
	fire: "games.coltexpress.actionFire",
	robbery: "games.coltexpress.actionRobbery",
	punch: "games.coltexpress.actionPunch"
}, rt = {
	normal: "games.coltexpress.turnNormal",
	tunnel: "games.coltexpress.turnTunnel",
	speeding: "games.coltexpress.turnSpeeding",
	switching: "games.coltexpress.turnSwitching"
}, it = {
	angryMarshal: "games.coltexpress.eventAngryMarshal",
	swivelArm: "games.coltexpress.eventSwivelArm",
	braking: "games.coltexpress.eventBraking",
	takeItAll: "games.coltexpress.eventTakeItAll",
	rebellion: "games.coltexpress.eventRebellion",
	pickpocketing: "games.coltexpress.eventPickpocketing",
	marshalsRevenge: "games.coltexpress.eventMarshalsRevenge",
	hostage: "games.coltexpress.eventHostage"
}, at = {
	ghost: "games.coltexpress.charGhost",
	belle: "games.coltexpress.charBelle",
	cheyenne: "games.coltexpress.charCheyenne",
	tuco: "games.coltexpress.charTuco",
	django: "games.coltexpress.charDjango",
	doc: "games.coltexpress.charDoc"
}, ot = {
	purse: "games.coltexpress.purse",
	gem: "games.coltexpress.gem",
	strongbox: "games.coltexpress.strongbox"
}, F = {
	ink: "#2b2118",
	iron: "#282526",
	roof: "#3b302b",
	rail: "#5b514a",
	timber: "#5c3528",
	wood: "#91402a",
	woodLight: "#c06b36",
	trim: "#e5ac55",
	paper: "#fdf6ec",
	sky: "#d97748",
	sand: "#c28655",
	distant: "#8d584b",
	emerald: "#0e8e93",
	gem: "#43c4da"
};
function st({ x: e, z: t }) {
	return /* @__PURE__ */ p("group", {
		position: [
			e,
			.35,
			t
		],
		rotation: [
			Math.PI / 2,
			0,
			0
		],
		children: [/* @__PURE__ */ p("mesh", { children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
			.32,
			.32,
			.13,
			14
		] }), /* @__PURE__ */ f("meshStandardMaterial", {
			color: F.iron,
			flatShading: !0
		})] }), /* @__PURE__ */ p("mesh", {
			position: [
				0,
				.08,
				0
			],
			children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
				.13,
				.13,
				.02,
				10
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.trim,
				flatShading: !0
			})]
		})]
	});
}
function ct() {
	return /* @__PURE__ */ p(d, { children: [[-.78, .78].flatMap((e) => [-.72, .72].map((t) => /* @__PURE__ */ f(st, {
		x: e,
		z: t
	}, `${e}:${t}`))), /* @__PURE__ */ p("mesh", {
		position: [
			0,
			.42,
			0
		],
		children: [/* @__PURE__ */ f("boxGeometry", { args: [
			2.42,
			.16,
			1.42
		] }), /* @__PURE__ */ f("meshStandardMaterial", {
			color: F.ink,
			flatShading: !0
		})]
	})] });
}
function lt({ active: e = !1 }) {
	return /* @__PURE__ */ p("group", {
		position: [
			0,
			0,
			0
		],
		children: [
			/* @__PURE__ */ f(ct, {}),
			/* @__PURE__ */ p("mesh", {
				position: [
					-.46,
					1.04,
					0
				],
				rotation: [
					0,
					0,
					Math.PI / 2
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.58,
					.58,
					1.55,
					18
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.iron,
					flatShading: !0
				})]
			}),
			[-.94, -.25].map((e) => /* @__PURE__ */ p("mesh", {
				position: [
					e,
					1.04,
					0
				],
				rotation: [
					0,
					0,
					Math.PI / 2
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.61,
					.61,
					.055,
					18
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.trim,
					flatShading: !0
				})]
			}, e)),
			/* @__PURE__ */ p("mesh", {
				position: [
					-1.22,
					1.04,
					0
				],
				rotation: [
					0,
					0,
					Math.PI / 2
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.65,
					.65,
					.16,
					20
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.trim,
					metalness: .1,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					-1.32,
					1.04,
					0
				],
				rotation: [
					0,
					0,
					Math.PI / 2
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.55,
					.55,
					.055,
					20
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.iron,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					-1.37,
					1.04,
					0
				],
				rotation: [
					0,
					0,
					Math.PI / 2
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.19,
					.19,
					.06,
					16
				] }), /* @__PURE__ */ f("meshBasicMaterial", { color: "#f7d580" })]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					-1.5,
					.39,
					0
				],
				rotation: [
					0,
					0,
					-.38
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.75,
					.14,
					1.54
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.iron,
					flatShading: !0
				})]
			}),
			[
				-.55,
				-.28,
				0,
				.28,
				.55
			].map((e) => /* @__PURE__ */ p("mesh", {
				position: [
					-1.82,
					.37,
					e
				],
				rotation: [
					0,
					0,
					-.39
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.48,
					.055,
					.065
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.trim,
					flatShading: !0
				})]
			}, e)),
			/* @__PURE__ */ p("mesh", {
				position: [
					-.76,
					1.64,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.14,
					.19,
					.58,
					12
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.ink,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					-.76,
					1.95,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.24,
					.14,
					.12,
					12
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.ink,
					flatShading: !0
				})]
			}),
			[
				[
					0,
					2.25,
					0,
					.26
				],
				[
					-.24,
					2.55,
					-.06,
					.35
				],
				[
					-.47,
					2.94,
					-.1,
					.45
				]
			].map(([e, t, n, r], i) => /* @__PURE__ */ p("mesh", {
				position: [
					-.76 + e,
					t,
					n
				],
				scale: [
					1.2,
					.75,
					.7
				],
				children: [/* @__PURE__ */ f("dodecahedronGeometry", { args: [r, 0] }), /* @__PURE__ */ f("meshBasicMaterial", {
					color: "#f4d7b4",
					transparent: !0,
					opacity: .68 - i * .11,
					depthWrite: !1
				})]
			}, i)),
			/* @__PURE__ */ p("mesh", {
				position: [
					-1.02,
					1.69,
					0
				],
				rotation: [
					0,
					0,
					Math.PI / 2
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.15,
					.15,
					.22,
					12
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.trim,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					-1.15,
					1.69,
					0
				],
				rotation: [
					0,
					0,
					Math.PI / 2
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.12,
					.12,
					.04,
					12
				] }), /* @__PURE__ */ f("meshBasicMaterial", { color: "#ffe6a0" })]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					.7,
					1.28,
					-.64
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					1.02,
					1.55,
					.13
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.wood,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					.7,
					1.48,
					-.565
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.91,
					1.05,
					.025
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: "#d8a96c",
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					.7,
					.81,
					0
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					1.18,
					.09,
					1.22
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: e ? "#eecb82" : "#bc8150",
					flatShading: !0
				})]
			}),
			[-.58, .58].map((e) => [.16, 1.24].map((t) => /* @__PURE__ */ p("mesh", {
				position: [
					t,
					1.7,
					e
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.09,
					1.73,
					.09
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.timber,
					flatShading: !0
				})]
			}, `${t}:${e}`))),
			/* @__PURE__ */ p("mesh", {
				position: [
					.7,
					2.57,
					-.36
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					1.34,
					.13,
					.94
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.ink,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					.7,
					2.61,
					.05
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					1.34,
					.1,
					.32
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.trim,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					.7,
					1.02,
					.72
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					1.02,
					.12,
					.06
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.trim,
					flatShading: !0
				})]
			})
		]
	});
}
function ut({ index: e, active: t, cutaway: n }) {
	return /* @__PURE__ */ p("group", { children: [
		/* @__PURE__ */ f(ct, {}),
		/* @__PURE__ */ p("mesh", {
			position: [
				0,
				.71,
				0
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				2.46,
				.22,
				1.55
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.timber,
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ p("mesh", {
			position: [
				0,
				1.45,
				-.72
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				2.46,
				1.43,
				.13
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.wood,
				flatShading: !0
			})]
		}),
		[[-.57, -.57], [.57, .57]].map(([e, t]) => /* @__PURE__ */ p("group", { children: [
			/* @__PURE__ */ p("mesh", {
				position: [
					e,
					1.55,
					-.62
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.7,
					.58,
					.045
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.trim,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					e,
					1.55,
					-.58
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.57,
					.44,
					.045
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.emerald,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					e,
					1.55,
					-.55
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.035,
					.44,
					.025
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.trim,
					flatShading: !0
				})]
			})
		] }, t)),
		/* @__PURE__ */ p("mesh", {
			position: [
				0,
				.97,
				.75
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				2.46,
				.48,
				.14
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.wood,
				flatShading: !0
			})]
		}),
		[
			.83,
			1.02,
			1.2
		].map((e) => /* @__PURE__ */ p("mesh", {
			position: [
				0,
				e,
				.835
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				2.45,
				.025,
				.025
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: e === 1.2 ? F.trim : F.timber,
				flatShading: !0
			})]
		}, e)),
		/* @__PURE__ */ p("mesh", {
			position: [
				0,
				1.22,
				.84
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				2.48,
				.055,
				.06
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.trim,
				flatShading: !0
			})]
		}),
		!n && /* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					1.23,
					.75
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					2.46,
					.28,
					.14
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.wood,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					1.98,
					.75
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					2.46,
					.18,
					.14
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.wood,
					flatShading: !0
				})]
			}),
			[
				-1.05,
				0,
				1.05
			].map((e) => /* @__PURE__ */ p("mesh", {
				position: [
					e,
					1.63,
					.75
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					e === 0 ? .54 : .36,
					.63,
					.14
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.wood,
					flatShading: !0
				})]
			}, e)),
			[-.57, .57].map((e) => /* @__PURE__ */ p("group", { children: [
				/* @__PURE__ */ p("mesh", {
					position: [
						e,
						1.62,
						.85
					],
					children: [/* @__PURE__ */ f("boxGeometry", { args: [
						.59,
						.54,
						.02
					] }), /* @__PURE__ */ f("meshStandardMaterial", {
						color: F.emerald,
						transparent: !0,
						opacity: .45,
						depthWrite: !1,
						flatShading: !0
					})]
				}),
				[-.31, .31].map((t) => /* @__PURE__ */ p("mesh", {
					position: [
						e + t,
						1.62,
						.89
					],
					children: [/* @__PURE__ */ f("boxGeometry", { args: [
						.04,
						.62,
						.045
					] }), /* @__PURE__ */ f("meshStandardMaterial", {
						color: F.trim,
						flatShading: !0
					})]
				}, t)),
				[-.29, .29].map((t) => /* @__PURE__ */ p("mesh", {
					position: [
						e,
						1.62 + t,
						.89
					],
					children: [/* @__PURE__ */ f("boxGeometry", { args: [
						.63,
						.04,
						.045
					] }), /* @__PURE__ */ f("meshStandardMaterial", {
						color: F.trim,
						flatShading: !0
					})]
				}, t)),
				/* @__PURE__ */ p("mesh", {
					position: [
						e,
						1.62,
						.91
					],
					children: [/* @__PURE__ */ f("boxGeometry", { args: [
						.035,
						.53,
						.025
					] }), /* @__PURE__ */ f("meshStandardMaterial", {
						color: F.trim,
						flatShading: !0
					})]
				})
			] }, e)),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					2.19,
					.75
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					2.46,
					.33,
					.14
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.wood,
					flatShading: !0
				})]
			}),
			[
				-.66,
				0,
				.66
			].map((e) => /* @__PURE__ */ p("mesh", {
				position: [
					e,
					1.66,
					.78
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.12,
					.75,
					.12
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.timber,
					flatShading: !0
				})]
			}, e)),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					2.01,
					.84
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					2.46,
					.045,
					.04
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.trim,
					flatShading: !0
				})]
			})
		] }),
		[-1.14, 1.14].flatMap((e) => [-.69, .69].map((t) => /* @__PURE__ */ p("mesh", {
			position: [
				e,
				1.62,
				t
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				.13,
				1.8,
				.13
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.timber,
				flatShading: !0
			})]
		}, `${e}:${t}`))),
		/* @__PURE__ */ p("mesh", {
			position: [
				0,
				2.52,
				-.42
			],
			rotation: [
				.13,
				0,
				0
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				2.72,
				.14,
				.93
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.roof,
				flatShading: !0
			})]
		}),
		!n && /* @__PURE__ */ p("mesh", {
			position: [
				0,
				2.52,
				.42
			],
			rotation: [
				-.13,
				0,
				0
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				2.72,
				.14,
				.93
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.roof,
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ p("mesh", {
			position: [
				0,
				2.64,
				0
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				2.58,
				.085,
				.13
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.trim,
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ p("mesh", {
			position: [
				0,
				2.44,
				n ? -.84 : .84
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				2.64,
				.055,
				.055
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.trim,
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ p("mesh", {
			position: [
				0,
				.82,
				0
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				2.28,
				.02,
				1.24
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: t ? "#eecb82" : "#b77643",
				flatShading: !0
			})]
		}),
		e === 2 && /* @__PURE__ */ p("mesh", {
			position: [
				.7,
				1.1,
				.1
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				1.1,
				.34,
				.85
			] }), /* @__PURE__ */ f("meshStandardMaterial", {
				color: F.timber,
				flatShading: !0
			})]
		}),
		t && /* @__PURE__ */ p("mesh", {
			position: [
				0,
				.81,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ f("ringGeometry", { args: [
				.86,
				.94,
				32
			] }), /* @__PURE__ */ f("meshBasicMaterial", {
				color: F.trim,
				side: 2
			})]
		})
	] });
}
function dt() {
	return /* @__PURE__ */ p("mesh", { children: [/* @__PURE__ */ f("sphereGeometry", { args: [
		72,
		24,
		16
	] }), /* @__PURE__ */ f("shaderMaterial", {
		side: v,
		depthWrite: !1,
		vertexShader: "varying vec3 vDirection; void main() { vDirection = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
		fragmentShader: "varying vec3 vDirection; void main() { float h = normalize(vDirection).y; vec3 horizon = vec3(0.98, 0.68, 0.40); vec3 sunset = vec3(0.88, 0.36, 0.24); vec3 dusk = vec3(0.42, 0.18, 0.22); vec3 lower = mix(horizon, sunset, smoothstep(-0.18, 0.38, h)); vec3 color = mix(lower, dusk, smoothstep(0.28, 0.84, h)); gl_FragColor = vec4(color, 1.0); }"
	})] });
}
function ft({ x: e, z: t }) {
	return /* @__PURE__ */ p("group", {
		position: [
			e,
			0,
			t
		],
		children: [
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					1.75,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.08,
					.13,
					3.5,
					8
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.timber,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					2.9,
					0
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					1.45,
					.1,
					.1
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.timber,
					flatShading: !0
				})]
			}),
			[-.57, .57].map((e) => /* @__PURE__ */ p("mesh", {
				position: [
					e,
					2.99,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.07,
					.07,
					.18,
					8
				] }), /* @__PURE__ */ f("meshStandardMaterial", {
					color: F.iron,
					flatShading: !0
				})]
			}, e))
		]
	});
}
//#endregion
//#region src/games/coltexpress/board3d.tsx
var I = "#2b2118", pt = "#493229", mt = "#282526", L = "#e5ac55", ht = "#fdf6ec", R = {
	purse: "#f59e0b",
	gem: "#0ea5e9",
	strongbox: "#57534e"
}, gt = {
	purse: "#fbbf24",
	gem: "#7dd3fc",
	strongbox: "#d6d3d1"
}, _t = 2.7, vt = .82, yt = 2.68;
function bt() {
	try {
		let e = document.createElement("canvas");
		return !!(e.getContext("webgl2") ?? e.getContext("webgl"));
	} catch {
		return !1;
	}
}
function xt({ pub: e, members: t, inspectCar: r = null }) {
	let o = x(), c = e.phase !== "done" && !o, l = s(), [u] = a(() => /* @__PURE__ */ new Map()), d = i(null), m = i({
		az: 0,
		pol: 0,
		zoom: 1
	}), h = i(/* @__PURE__ */ new Map()), _ = i(null), v = e.cars.length, y = e.players.map((e) => e.rid).join("|"), b = e.phase === "steal" ? e.pile[e.pending ? e.execIdx : Math.max(0, e.execIdx - 1)] : void 0, S = e.players.find((t) => t.rid === (e.pending?.by ?? b?.by)), C = e.phase === "steal" ? b?.card === "marshal" ? e.marshal : S?.car ?? null : null, w = r === "overview" ? null : typeof r == "number" ? r : C, T = e.options?.kind === "fire" || e.options?.kind === "move" || e.options?.kind === "marshal";
	return n(() => {
		if (!l) return;
		let e = ["train", "marshal"];
		for (let t = 0; t < v; t++) e.push(`car:${t}:in`, `car:${t}:roof`);
		for (let t of y.split("|")) t && e.push(`bandit:${t}`);
		let t = (e) => {
			let t = d.current, n = u.get(e);
			if (!t || !n) return null;
			n.getWorldPosition(z), St.copy(z).x += .9, z.project(t.camera), St.project(t.camera);
			let r = t.canvas.getBoundingClientRect(), i = r.left + (z.x + 1) / 2 * r.width, a = r.top + (1 - z.y) / 2 * r.height, o = Math.abs((St.x - z.x) / 2 * r.width);
			return {
				x: i - o,
				y: a - o,
				w: o * 2,
				h: o * 2
			};
		};
		for (let n of e) l.registerProbe(n, () => t(n));
		return () => {
			for (let t of e) l.registerProbe(t, null);
		};
	}, [
		l,
		v,
		u,
		y
	]), /* @__PURE__ */ f("div", {
		className: "relative min-h-0 flex-1 cursor-grab touch-none active:cursor-grabbing",
		onPointerDown: (e) => {
			if (h.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			}), e.currentTarget.setPointerCapture(e.pointerId), h.current.size === 2) {
				let [e, t] = [...h.current.values()];
				_.current = Math.hypot(e.x - t.x, e.y - t.y);
			}
		},
		onPointerMove: (e) => {
			let t = h.current, n = t.get(e.pointerId);
			if (!n) return;
			let r = {
				x: n.x,
				y: n.y
			};
			if (n.x = e.clientX, n.y = e.clientY, t.size >= 2) {
				let [e, n] = [...t.values()], r = Math.hypot(e.x - n.x, e.y - n.y), i = _.current;
				i && r > 0 && (m.current.zoom = Tt(m.current.zoom * (i / r), .55, 1.7), d.current?.invalidate()), _.current = r;
				return;
			}
			m.current.az -= (n.x - r.x) * .009, m.current.pol = Tt(m.current.pol + (n.y - r.y) * .006, -.3, .55), d.current?.invalidate();
		},
		onPointerUp: (e) => {
			h.current.delete(e.pointerId), h.current.size < 2 && (_.current = null);
		},
		onPointerCancel: (e) => {
			h.current.delete(e.pointerId), h.current.size < 2 && (_.current = null);
		},
		onWheel: (e) => {
			m.current.zoom = Tt(m.current.zoom * (1 + e.deltaY * .001), .55, 1.7), d.current?.invalidate();
		},
		children: /* @__PURE__ */ p(g, {
			style: {
				position: "absolute",
				inset: 0
			},
			gl: {
				antialias: !0,
				powerPreference: "low-power"
			},
			dpr: [1, 2],
			frameloop: c ? "always" : "demand",
			camera: {
				fov: 38,
				near: .1,
				far: 100
			},
			children: [
				/* @__PURE__ */ f("ambientLight", { intensity: 1.2 }),
				/* @__PURE__ */ f("directionalLight", {
					position: [
						4,
						8,
						6
					],
					intensity: 1.1
				}),
				/* @__PURE__ */ f("color", {
					attach: "background",
					args: ["#d97748"]
				}),
				/* @__PURE__ */ f("fog", {
					attach: "fog",
					args: [
						"#d88b5c",
						25,
						65
					]
				}),
				/* @__PURE__ */ f(wt, { rigRef: d }),
				/* @__PURE__ */ f(Et, {
					carCount: v,
					focusX: w === null ? null : Ct(w, v) + .6,
					wideFocus: T,
					orbitRef: m
				}),
				/* @__PURE__ */ f(Dt, { dep: e }),
				/* @__PURE__ */ f(dt, {}),
				/* @__PURE__ */ f(kt, {}),
				/* @__PURE__ */ f(It, { running: c }),
				/* @__PURE__ */ f(Nt, { running: c }),
				/* @__PURE__ */ f(Ft, { running: c }),
				/* @__PURE__ */ f(Ot, {
					running: c,
					children: /* @__PURE__ */ p("group", {
						position: [
							.6,
							0,
							0
						],
						children: [
							/* @__PURE__ */ f(Lt, {}),
							e.cars.map((n, r) => /* @__PURE__ */ f(zt, {
								pub: e,
								members: t,
								idx: r,
								car: n,
								active: w === r && !!e.pending,
								markers: u
							}, r)),
							/* @__PURE__ */ f(B, {
								name: "marshal",
								position: [
									Ct(e.marshal, v),
									1.4,
									0
								],
								markers: u
							}),
							/* @__PURE__ */ f(B, {
								name: "train",
								position: [
									0,
									1.5,
									0
								],
								markers: u
							})
						]
					})
				})
			]
		})
	});
}
var z = new b(), St = new b(), Ct = (e, t) => (e - (t - 1) / 2) * _t;
function wt({ rigRef: e }) {
	let t = h((e) => e.camera), r = h((e) => e.gl), i = h((e) => e.invalidate);
	return n(() => (e.current = {
		camera: t,
		canvas: r.domElement,
		invalidate: i
	}, () => {
		e.current = null;
	}), [
		e,
		t,
		r,
		i
	]), null;
}
var Tt = (e, t, n) => Math.min(n, Math.max(t, e));
function Et({ carCount: e, focusX: t, wideFocus: n, orbitRef: r }) {
	let a = h((e) => e.camera), o = h((e) => e.size), s = h((e) => e.invalidate), c = i(null), l = i(null), u = a.fov * Math.PI / 180 / 2, d = Math.max(.45, o.width / Math.max(1, o.height)), f = e * _t + 1.3, p = t === null ? Math.max(7.5, f / (2 * Math.tan(u) * d)) : Math.max(6.1, (n ? 9.5 : 6.8) / d);
	return m(() => {
		c.current ||= { ...r.current };
		let e = c.current, n = r.current.az - e.az, i = r.current.pol - e.pol, o = r.current.zoom - e.zoom;
		(Math.abs(n) > 4e-4 || Math.abs(i) > 4e-4 || Math.abs(o) > 4e-4) && (e.az += n * .18, e.pol += i * .18, e.zoom += o * .18, s());
		let u = t ?? .3, d = t === null ? -.5 : -.18, f = t === null ? .32 : .43;
		l.current ||= {
			x: u,
			dist: p,
			az: d,
			pol: f
		};
		let m = l.current;
		(Math.abs(m.x - u) > .002 || Math.abs(m.dist - p) > .002 || Math.abs(m.az - d) > 4e-4 || Math.abs(m.pol - f) > 4e-4) && (m.x += (u - m.x) * .14, m.dist += (p - m.dist) * .14, m.az += (d - m.az) * .14, m.pol += (f - m.pol) * .14, s());
		let h = m.pol + e.pol, g = m.az + e.az, _ = m.dist * e.zoom;
		a.position.set(m.x + Math.sin(g) * Math.cos(h) * _, 1.25 + Math.sin(h) * _, Math.cos(g) * Math.cos(h) * _), a.lookAt(m.x, 1.18, 0);
	}), null;
}
function Dt({ dep: e }) {
	let t = h((e) => e.invalidate);
	return n(() => {
		t();
	}, [t, e]), null;
}
function Ot({ running: e, children: t }) {
	let n = i(null);
	return m(({ clock: t }) => {
		if (!e || !n.current) return;
		let r = t.elapsedTime;
		n.current.position.y = Math.sin(r * 6) * .02, n.current.rotation.z = Math.sin(r * 3) * .004;
	}), /* @__PURE__ */ f("group", {
		ref: n,
		children: t
	});
}
function B({ name: e, position: t, markers: r }) {
	let a = i(null);
	return n(() => {
		let t = a.current;
		if (t) return r.set(e, t), () => {
			r.delete(e);
		};
	}, [e, r]), /* @__PURE__ */ f("object3D", {
		ref: a,
		position: t
	});
}
function kt() {
	return /* @__PURE__ */ p("group", { children: [
		/* @__PURE__ */ p("mesh", {
			position: [
				24,
				4.5,
				-28
			],
			children: [/* @__PURE__ */ f("sphereGeometry", { args: [
				2.3,
				20,
				12
			] }), /* @__PURE__ */ f("meshBasicMaterial", {
				color: "#f6cd84",
				fog: !1
			})]
		}),
		/* @__PURE__ */ p("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				-.05,
				0
			],
			children: [/* @__PURE__ */ f("planeGeometry", { args: [100, 100] }), /* @__PURE__ */ f("meshLambertMaterial", { color: "#c28655" })]
		}),
		[
			-1,
			0,
			1
		].map((e) => /* @__PURE__ */ p("group", {
			position: [
				e * 9 + 2,
				0,
				-18 - e % 2 * 3
			],
			children: [/* @__PURE__ */ p("mesh", {
				position: [
					0,
					.95,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					1.7,
					2.5,
					1.9,
					6
				] }), /* @__PURE__ */ f("meshLambertMaterial", {
					color: "#8d584b",
					flatShading: !0
				})]
			}), /* @__PURE__ */ p("mesh", {
				position: [
					0,
					1.95,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					1.28,
					1.7,
					.45,
					6
				] }), /* @__PURE__ */ f("meshLambertMaterial", {
					color: "#8d584b",
					flatShading: !0
				})]
			})]
		}, e)),
		/* @__PURE__ */ f(ft, {
			x: -9,
			z: -6.7
		}),
		/* @__PURE__ */ f(ft, {
			x: 9,
			z: -6.7
		})
	] });
}
var V = 64, At = 3.2, jt = (e) => (e % V + V) % V - V / 2, Mt = [
	{
		kind: "cactus",
		phase: 3,
		z: -6,
		s: 1
	},
	{
		kind: "cactus",
		phase: 17,
		z: -9,
		s: .8
	},
	{
		kind: "cactus",
		phase: 29,
		z: -5.5,
		s: .7
	},
	{
		kind: "cactus",
		phase: 43,
		z: -12,
		s: 1.2
	},
	{
		kind: "cactus",
		phase: 9,
		z: 6,
		s: .9
	},
	{
		kind: "cactus",
		phase: 23,
		z: 8.5,
		s: .75
	},
	{
		kind: "cactus",
		phase: 51,
		z: 5.5,
		s: .6
	},
	{
		kind: "cactus",
		phase: 59,
		z: -4.5,
		s: .55
	},
	{
		kind: "cactus",
		phase: 36,
		z: 10,
		s: 1.05
	},
	{
		kind: "rock",
		phase: 11,
		z: -7,
		s: 1
	},
	{
		kind: "rock",
		phase: 33,
		z: -10,
		s: .8
	},
	{
		kind: "rock",
		phase: 39,
		z: 7,
		s: .7
	},
	{
		kind: "rock",
		phase: 57,
		z: 11,
		s: 1.1
	},
	{
		kind: "rock",
		phase: 21,
		z: 4.5,
		s: .5
	},
	{
		kind: "bush",
		phase: 25,
		z: -5,
		s: 1
	},
	{
		kind: "bush",
		phase: 5,
		z: 5,
		s: .9
	},
	{
		kind: "bush",
		phase: 47,
		z: -8,
		s: 1.1
	},
	{
		kind: "bush",
		phase: 61,
		z: 7.5,
		s: .8
	},
	{
		kind: "bush",
		phase: 14,
		z: -11,
		s: .9
	},
	{
		kind: "dune",
		phase: 7,
		z: -18,
		s: 1,
		f: .7
	},
	{
		kind: "dune",
		phase: 27,
		z: 18,
		s: 1.2,
		f: .7
	},
	{
		kind: "dune",
		phase: 47,
		z: -20,
		s: .9,
		f: .7
	},
	{
		kind: "mesa",
		phase: 16,
		z: -26,
		s: 1,
		f: .35
	},
	{
		kind: "mesa",
		phase: 44,
		z: -30,
		s: 1.4,
		f: .35
	},
	{
		kind: "mesa",
		phase: 58,
		z: 26,
		s: 1.1,
		f: .35
	},
	{
		kind: "cloud",
		phase: 10,
		z: -16,
		s: 1,
		f: .12
	},
	{
		kind: "cloud",
		phase: 40,
		z: 14,
		s: 1.3,
		f: .1
	}
];
function Nt({ running: e }) {
	let t = i(null);
	return m(({ clock: n }) => {
		let r = t.current;
		if (!r || !e) return;
		let i = n.elapsedTime * At;
		for (let e = 0; e < r.children.length; e++) {
			let t = Mt[e];
			r.children[e].position.x = jt(t.phase + i * (t.f ?? 1));
		}
	}), /* @__PURE__ */ f("group", {
		ref: t,
		children: Mt.map((e, t) => /* @__PURE__ */ p("group", {
			position: [
				jt(e.phase),
				e.kind === "cloud" ? 6.5 + e.s : 0,
				e.z
			],
			scale: e.s,
			children: [
				e.kind === "cactus" && /* @__PURE__ */ f(Rt, { position: [
					0,
					0,
					0
				] }),
				e.kind === "rock" && /* @__PURE__ */ p("mesh", {
					position: [
						0,
						.2,
						0
					],
					scale: [
						1,
						.6,
						1
					],
					children: [/* @__PURE__ */ f("sphereGeometry", { args: [
						.5,
						10,
						8
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: "#a8a29e" })]
				}),
				e.kind === "bush" && /* @__PURE__ */ p("mesh", {
					position: [
						0,
						.18,
						0
					],
					scale: [
						1,
						.7,
						1
					],
					children: [/* @__PURE__ */ f("sphereGeometry", { args: [
						.35,
						8,
						6
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: "#b8a05a" })]
				}),
				e.kind === "dune" && /* @__PURE__ */ p("mesh", {
					scale: [
						1,
						.28,
						.6
					],
					children: [/* @__PURE__ */ f("sphereGeometry", { args: [
						5,
						14,
						10
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: "#e3bd85" })]
				}),
				e.kind === "mesa" && /* @__PURE__ */ p("group", { children: [/* @__PURE__ */ p("mesh", {
					position: [
						0,
						.9,
						0
					],
					children: [/* @__PURE__ */ f("boxGeometry", { args: [
						7,
						1.8,
						2.6
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: "#d9a86c" })]
				}), /* @__PURE__ */ p("mesh", {
					position: [
						0,
						2.05,
						0
					],
					children: [/* @__PURE__ */ f("boxGeometry", { args: [
						4.6,
						.6,
						2
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: "#c99356" })]
				})] }),
				e.kind === "cloud" && /* @__PURE__ */ p("mesh", {
					scale: [
						1,
						.45,
						.7
					],
					children: [/* @__PURE__ */ f("sphereGeometry", { args: [
						1.6,
						12,
						10
					] }), /* @__PURE__ */ f("meshBasicMaterial", { color: "#fffdf6" })]
				})
			]
		}, t))
	});
}
var Pt = Array.from({ length: 26 }, (e, t) => ({
	px: t * 2.618 % V,
	py: .3 + t * 7 % 13 * .15,
	pz: t * 11 % 15 / 15 * 8 - 4
}));
function Ft({ running: e }) {
	let t = i(null);
	return m(({ clock: n }) => {
		let r = t.current;
		if (!r || !e) return;
		let i = n.elapsedTime;
		for (let e = 0; e < r.children.length; e++) {
			let t = Pt[e];
			r.children[e].position.x = jt(t.px + i * At * 2.2), r.children[e].position.y = t.py + Math.sin(i * 3 + t.px) * .12;
		}
	}), /* @__PURE__ */ f("group", {
		ref: t,
		children: Pt.map((e, t) => /* @__PURE__ */ p("mesh", {
			position: [
				jt(e.px),
				e.py,
				e.pz
			],
			rotation: [
				0,
				0,
				.04
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				.55,
				.02,
				.02
			] }), /* @__PURE__ */ f("meshBasicMaterial", {
				color: "#e8c98f",
				transparent: !0,
				opacity: .5
			})]
		}, t))
	});
}
function It({ running: e }) {
	let t = i(null);
	return m(({ clock: n }) => {
		let r = t.current;
		if (!r || !e) return;
		let i = n.elapsedTime * At;
		for (let e = 0; e < r.children.length; e++) r.children[e].position.x = (e * .6 + i) % 66 - 33;
	}), /* @__PURE__ */ f("group", {
		ref: t,
		children: Array.from({ length: 110 }, (e, t) => /* @__PURE__ */ p("mesh", {
			position: [
				0,
				.12,
				0
			],
			children: [/* @__PURE__ */ f("boxGeometry", { args: [
				.16,
				.06,
				1
			] }), /* @__PURE__ */ f("meshLambertMaterial", { color: pt })]
		}, t))
	});
}
function Lt() {
	return /* @__PURE__ */ p("group", { children: [/* @__PURE__ */ p("mesh", {
		position: [
			0,
			.05,
			0
		],
		children: [/* @__PURE__ */ f("boxGeometry", { args: [
			80,
			.1,
			1.1
		] }), /* @__PURE__ */ f("meshLambertMaterial", { color: "#c9a06a" })]
	}), [-.4, .4].map((e) => /* @__PURE__ */ p("mesh", {
		position: [
			0,
			.13,
			e
		],
		children: [/* @__PURE__ */ f("boxGeometry", { args: [
			80,
			.06,
			.07
		] }), /* @__PURE__ */ f("meshLambertMaterial", { color: pt })]
	}, e))] });
}
function Rt({ position: e, scale: t = 1 }) {
	let n = "#4d7c0f";
	return /* @__PURE__ */ p("group", {
		position: e,
		scale: t,
		children: [
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					.8,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.14,
					.17,
					1.6,
					8
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: n })]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					.24,
					.85,
					0
				],
				rotation: [
					0,
					0,
					Math.PI / 2
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.09,
					.09,
					.34,
					8
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: n })]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					.4,
					1.1,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.09,
					.09,
					.5,
					8
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: n })]
			})
		]
	});
}
function zt({ pub: e, members: t, idx: n, car: r, markers: i, active: a }) {
	let o = e.phase !== "done", s = e.cars.length, c = Ct(n, s), l = n === 0, u = e.players.filter((e) => e.car === n && !e.roof), m = e.players.filter((e) => e.car === n && e.roof), h = e.marshal === n, g = u.length + +!!h, _ = e.players.find((t) => t.rid === e.pending?.by), v = e.options?.kind === "robbery" && _?.car === n ? e.options.lootIdxs : [], b = e.options?.kind === "fire" || e.options?.kind === "punch" ? e.options.targets : [], x = e.options?.kind === "move" && _ && e.options.moves.some((e) => _.car + e.dir * e.dist === n) || e.options?.kind === "marshal" && e.options.dirs.some((t) => e.marshal + t === n);
	return /* @__PURE__ */ p("group", {
		position: [
			c,
			0,
			0
		],
		children: [
			l ? /* @__PURE__ */ f(lt, { active: a }) : /* @__PURE__ */ f(ut, {
				index: n,
				active: a,
				cutaway: !0
			}),
			x && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("mesh", {
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				position: [
					0,
					.18,
					1.1
				],
				children: [/* @__PURE__ */ f("ringGeometry", { args: [
					.78,
					.88,
					32
				] }), /* @__PURE__ */ f("meshBasicMaterial", {
					color: L,
					side: y
				})]
			}), /* @__PURE__ */ p("mesh", {
				position: [
					0,
					l ? 2.48 : 2.97,
					0
				],
				rotation: [
					0,
					0,
					Math.PI / 4
				],
				children: [/* @__PURE__ */ f("octahedronGeometry", { args: [.17] }), /* @__PURE__ */ f("meshBasicMaterial", { color: L })]
			})] }),
			h && /* @__PURE__ */ f("group", {
				position: Vt(0, g, l),
				scale: l ? g <= 2 ? .9 : .72 : 1,
				children: /* @__PURE__ */ f(Kt, { position: [
					0,
					0,
					0
				] })
			}),
			u.map((e, n) => /* @__PURE__ */ p("group", {
				position: Vt(n + +!!h, g, l),
				scale: l ? g <= 2 ? .9 : .72 : 1,
				children: [/* @__PURE__ */ f(Gt, {
					character: e.character,
					color: Ut(e.rid, t),
					highlighted: b.includes(e.rid),
					position: [
						0,
						0,
						0
					]
				}), /* @__PURE__ */ f(B, {
					name: `bandit:${e.rid}`,
					position: [
						0,
						.4,
						0
					],
					markers: i
				})]
			}, e.rid)),
			m.map((e, n) => /* @__PURE__ */ p("group", {
				position: Ht(n, m.length, l),
				scale: l ? .8 : 1,
				children: [/* @__PURE__ */ f(Gt, {
					character: e.character,
					color: Ut(e.rid, t),
					highlighted: b.includes(e.rid),
					position: [
						0,
						0,
						0
					]
				}), /* @__PURE__ */ f(B, {
					name: `bandit:${e.rid}`,
					position: [
						0,
						.4,
						0
					],
					markers: i
				})]
			}, e.rid)),
			/* @__PURE__ */ f(Jt, {
				loot: r.inside,
				y: vt,
				running: o,
				locomotive: l,
				highlighted: _?.roof === !1 ? v : []
			}),
			/* @__PURE__ */ f(Jt, {
				loot: r.roof,
				y: yt,
				running: o,
				locomotive: l,
				highlighted: _?.roof === !0 ? v : []
			}),
			/* @__PURE__ */ f(B, {
				name: `car:${n}:in`,
				position: [
					l ? .7 : 0,
					1.35,
					0
				],
				markers: i
			}),
			/* @__PURE__ */ f(B, {
				name: `car:${n}:roof`,
				position: [
					l ? .7 : 0,
					3.0300000000000002,
					0
				],
				markers: i
			})
		]
	});
}
function Bt(e, t) {
	if (t <= 1) return 0;
	let n = Math.min(.62, 1.7 / t);
	return (e - (t - 1) / 2) * n;
}
function Vt(e, t, n) {
	if (!n) return [
		Bt(e, t),
		vt,
		.05
	];
	let r = Math.floor(e / 3), i = Math.min(3, t - r * 3);
	return [
		.7 + (e % 3 - (i - 1) / 2) * .3,
		vt,
		-.2 + r * .3
	];
}
function Ht(e, t, n) {
	if (!n) return [
		Bt(e, t),
		yt,
		0
	];
	let r = Math.floor(e / 3), i = Math.min(3, t - r * 3);
	return [
		.7 + (e % 3 - (i - 1) / 2) * .3,
		yt,
		-.16 + r * .28
	];
}
function Ut(e, t) {
	let n = t.find((t) => t.rid === e);
	return l[(n?.colorIndex ?? 0) % l.length].hex;
}
var Wt = {
	ghost: {
		rTop: .13,
		rBot: .19,
		h: .52
	},
	belle: {
		rTop: .12,
		rBot: .27,
		h: .5
	},
	cheyenne: {
		rTop: .14,
		rBot: .2,
		h: .52
	},
	tuco: {
		rTop: .19,
		rBot: .25,
		h: .4
	},
	django: {
		rTop: .14,
		rBot: .2,
		h: .52
	},
	doc: {
		rTop: .12,
		rBot: .16,
		h: .58
	}
};
function Gt({ character: e, color: t, position: n, highlighted: r = !1 }) {
	let i = Wt[e], a = i.h + .12;
	return /* @__PURE__ */ p("group", {
		position: n,
		children: [
			r && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("mesh", {
				position: [
					0,
					.38,
					.37
				],
				children: [/* @__PURE__ */ f("ringGeometry", { args: [
					.28,
					.35,
					24
				] }), /* @__PURE__ */ f("meshBasicMaterial", {
					color: L,
					side: y
				})]
			}), /* @__PURE__ */ p("mesh", {
				position: [
					0,
					a + .3,
					0
				],
				rotation: [
					0,
					0,
					Math.PI / 4
				],
				children: [/* @__PURE__ */ f("octahedronGeometry", { args: [.12] }), /* @__PURE__ */ f("meshBasicMaterial", { color: L })]
			})] }),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					i.h / 2,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					i.rTop,
					i.rBot,
					i.h,
					10
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: t })]
			}),
			[-.19, .19].map((e) => /* @__PURE__ */ p("mesh", {
				position: [
					e,
					i.h * .65,
					0
				],
				rotation: [
					0,
					0,
					e * .8
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.05,
					.06,
					.32,
					8
				] }), /* @__PURE__ */ f("meshLambertMaterial", {
					color: t,
					flatShading: !0
				})]
			}, e)),
			[-.1, .1].map((e) => /* @__PURE__ */ p("mesh", {
				position: [
					e,
					.035,
					.07
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.12,
					.16,
					.18
				] }), /* @__PURE__ */ f("meshLambertMaterial", {
					color: mt,
					flatShading: !0
				})]
			}, e)),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					i.h * .45,
					.17
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.32,
					.055,
					.055
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: pt })]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					a,
					0
				],
				children: [/* @__PURE__ */ f("sphereGeometry", { args: [
					.14,
					12,
					10
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: t })]
			}),
			e === "ghost" && /* @__PURE__ */ p("mesh", {
				position: [
					0,
					a + .06,
					0
				],
				children: [/* @__PURE__ */ f("coneGeometry", { args: [
					.2,
					.32,
					10
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: t })]
			}),
			e === "belle" && /* @__PURE__ */ p("mesh", {
				position: [
					0,
					a + .13,
					-.08
				],
				children: [/* @__PURE__ */ f("sphereGeometry", { args: [
					.07,
					10,
					8
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: I })]
			}),
			e === "cheyenne" && /* @__PURE__ */ p("mesh", {
				position: [
					0,
					a + .18,
					-.09
				],
				rotation: [
					-.35,
					0,
					0
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.06,
					.34,
					.02
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: "#dc2626" })]
			}),
			e === "tuco" && /* @__PURE__ */ p("group", {
				position: [
					0,
					a + .1,
					0
				],
				children: [/* @__PURE__ */ p("mesh", { children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.3,
					.3,
					.035,
					14
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: I })] }), /* @__PURE__ */ p("mesh", {
					position: [
						0,
						.07,
						0
					],
					children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
						.12,
						.13,
						.12,
						12
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: I })]
				})]
			}),
			e === "django" && /* @__PURE__ */ p("group", { children: [/* @__PURE__ */ p("mesh", {
				position: [
					.16,
					i.h * .55,
					-.2
				],
				rotation: [
					0,
					0,
					.5
				],
				children: [/* @__PURE__ */ f("boxGeometry", { args: [
					.24,
					.4,
					.07
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: "#8b5a2b" })]
			}), /* @__PURE__ */ p("mesh", {
				position: [
					0,
					a + .1,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.17,
					.17,
					.06,
					12
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: I })]
			})] }),
			e === "doc" && /* @__PURE__ */ p("group", {
				position: [
					0,
					a + .1,
					0
				],
				children: [/* @__PURE__ */ p("mesh", { children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.2,
					.2,
					.03,
					14
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: I })] }), /* @__PURE__ */ p("mesh", {
					position: [
						0,
						.13,
						0
					],
					children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
						.12,
						.12,
						.24,
						12
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: I })]
				})]
			})
		]
	});
}
function Kt({ position: e }) {
	return /* @__PURE__ */ p("group", {
		position: e,
		children: [
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					.27,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.14,
					.2,
					.54,
					10
				] }), /* @__PURE__ */ f("meshBasicMaterial", { color: I })]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					.64,
					0
				],
				children: [/* @__PURE__ */ f("sphereGeometry", { args: [
					.15,
					12,
					10
				] }), /* @__PURE__ */ f("meshBasicMaterial", { color: I })]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					.27,
					0
				],
				scale: 1.16,
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.14,
					.2,
					.54,
					10
				] }), /* @__PURE__ */ f("meshBasicMaterial", {
					color: ht,
					side: v
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					.64,
					0
				],
				scale: 1.16,
				children: [/* @__PURE__ */ f("sphereGeometry", { args: [
					.15,
					12,
					10
				] }), /* @__PURE__ */ f("meshBasicMaterial", {
					color: ht,
					side: v
				})]
			}),
			/* @__PURE__ */ p("mesh", {
				position: [
					0,
					.4,
					.16
				],
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ f("octahedronGeometry", { args: [.11] }), /* @__PURE__ */ f("meshBasicMaterial", { color: L })]
			})
		]
	});
}
function qt({ color: e, phase: t, running: n }) {
	let r = i(null), a = i(null);
	return m(({ clock: e }) => {
		if (!n) return;
		let i = e.elapsedTime, o = .8 + Math.sin(i * 2.4 + t) * .2;
		r.current && (r.current.scale.setScalar(o), r.current.material.opacity = .3 + o * .3), a.current && (a.current.rotation.y = i * 1.6 + t, a.current.scale.setScalar(.75 + o * .3));
	}), /* @__PURE__ */ p("group", { children: [/* @__PURE__ */ p("mesh", {
		ref: r,
		rotation: [
			-Math.PI / 2,
			0,
			0
		],
		position: [
			0,
			.02,
			0
		],
		children: [/* @__PURE__ */ f("ringGeometry", { args: [
			.17,
			.3,
			24
		] }), /* @__PURE__ */ f("meshBasicMaterial", {
			color: e,
			transparent: !0,
			opacity: .5,
			blending: _,
			depthWrite: !1
		})]
	}), /* @__PURE__ */ f("group", {
		ref: a,
		position: [
			0,
			.56,
			0
		],
		children: /* @__PURE__ */ p("mesh", {
			scale: [
				.4,
				1,
				.4
			],
			children: [/* @__PURE__ */ f("octahedronGeometry", { args: [.11] }), /* @__PURE__ */ f("meshBasicMaterial", {
				color: "#fffbe8",
				transparent: !0,
				opacity: .9,
				blending: _,
				depthWrite: !1
			})]
		})
	})] });
}
function Jt({ loot: e, y: t, running: n, locomotive: i = !1, highlighted: a }) {
	let o = r(() => {
		let n = Math.ceil(e.length / 2);
		return e.map((r, a) => {
			let o = a < n ? -1 : 1, s = a < n ? a : a - n, c = Math.floor(a / 3), l = Math.min(3, e.length - c * 3), u = i ? .7 + (a % 3 - (l - 1) / 2) * .3 : o * (.82 - s % 2 * .3), d = i ? (t > 2 ? -.12 : .42) - Math.floor(a / 3) * .22 : (s % 3 - 1) * .22;
			return {
				key: a,
				kind: r.kind,
				x: u,
				z: d,
				rot: a * 137 % 360 * (Math.PI / 180)
			};
		});
	}, [
		e,
		i,
		t
	]);
	return /* @__PURE__ */ f("group", { children: o.map((e) => /* @__PURE__ */ p("group", {
		position: [
			e.x,
			t,
			e.z
		],
		rotation: [
			0,
			e.rot,
			0
		],
		children: [
			e.kind === "purse" && /* @__PURE__ */ p("group", { children: [
				/* @__PURE__ */ p("mesh", {
					position: [
						0,
						.15,
						0
					],
					scale: [
						1,
						.85,
						1
					],
					children: [/* @__PURE__ */ f("sphereGeometry", { args: [
						.19,
						12,
						10
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: R.purse })]
				}),
				/* @__PURE__ */ p("mesh", {
					position: [
						0,
						.29,
						0
					],
					rotation: [
						Math.PI / 2,
						0,
						0
					],
					children: [/* @__PURE__ */ f("torusGeometry", { args: [
						.07,
						.022,
						8,
						14
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: I })]
				}),
				/* @__PURE__ */ p("mesh", {
					position: [
						0,
						.36,
						0
					],
					scale: [
						1,
						.75,
						1
					],
					children: [/* @__PURE__ */ f("sphereGeometry", { args: [
						.085,
						10,
						8
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: R.purse })]
				})
			] }),
			e.kind === "gem" && /* @__PURE__ */ p("group", { children: [/* @__PURE__ */ p("mesh", {
				position: [
					0,
					.26,
					0
				],
				children: [/* @__PURE__ */ f("cylinderGeometry", { args: [
					.1,
					.19,
					.12,
					8
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: "#bae6fd" })]
			}), /* @__PURE__ */ p("mesh", {
				position: [
					0,
					.12,
					0
				],
				rotation: [
					Math.PI,
					0,
					0
				],
				children: [/* @__PURE__ */ f("coneGeometry", { args: [
					.19,
					.24,
					8
				] }), /* @__PURE__ */ f("meshLambertMaterial", { color: R.gem })]
			})] }),
			e.kind === "strongbox" && /* @__PURE__ */ p("group", {
				position: [
					0,
					.17,
					0
				],
				children: [
					/* @__PURE__ */ p("mesh", { children: [/* @__PURE__ */ f("boxGeometry", { args: [
						.5,
						.34,
						.34
					] }), /* @__PURE__ */ f("meshLambertMaterial", { color: R.strongbox })] }),
					/* @__PURE__ */ p("mesh", {
						position: [
							0,
							.03,
							.174
						],
						children: [/* @__PURE__ */ f("boxGeometry", { args: [
							.4,
							.23,
							.015
						] }), /* @__PURE__ */ f("meshBasicMaterial", {
							color: L,
							wireframe: !0
						})]
					}),
					/* @__PURE__ */ p("mesh", {
						position: [
							0,
							.03,
							.19
						],
						children: [/* @__PURE__ */ f("boxGeometry", { args: [
							.09,
							.09,
							.014
						] }), /* @__PURE__ */ f("meshBasicMaterial", { color: ht })]
					})
				]
			}),
			a?.includes(e.key) && /* @__PURE__ */ f(qt, {
				color: gt[e.kind],
				phase: e.key * 1.7,
				running: n
			})
		]
	}, e.key)) });
}
//#endregion
//#region src/games/coltexpress/scenery.tsx
function Yt({ running: e }) {
	return /* @__PURE__ */ p("div", {
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("div", {
				className: "absolute inset-0",
				style: { background: "linear-gradient(180deg, #a95035 0%, #d47a49 42%, #e4a363 67%, #b98b5a 100%)" }
			}),
			/* @__PURE__ */ f("div", { className: "absolute top-2 right-7 size-9 rounded-full bg-[#f7ca7b] opacity-85 shadow-[0_0_28px_9px_#f0aa6a]" }),
			/* @__PURE__ */ f(H, {
				items: ["☁️", "☁️"],
				offset: "top-2",
				text: "text-xl opacity-35",
				duration: 48,
				running: e
			}),
			/* @__PURE__ */ f(H, {
				items: ["🦅", "☁️"],
				offset: "top-9",
				text: "text-sm opacity-45",
				duration: 64,
				running: e
			}),
			/* @__PURE__ */ f(H, {
				items: [
					"⛰️",
					"⛰️",
					"⛰️"
				],
				offset: "bottom-9",
				text: "text-lg opacity-50",
				duration: 24,
				running: e
			}),
			/* @__PURE__ */ f(H, {
				items: [
					"🌵",
					"🌾",
					"🌵",
					"🪨"
				],
				offset: "bottom-4",
				text: "text-xl opacity-75",
				duration: 9,
				running: e
			}),
			/* @__PURE__ */ f(H, {
				items: [
					"🌵",
					"🪨",
					"🌵",
					"🌵",
					"🪨",
					"🌾"
				],
				offset: "bottom-0",
				text: "text-2xl",
				duration: 3.5,
				running: e
			})
		]
	});
}
function H({ items: e, offset: t, text: n, duration: r, running: i }) {
	return /* @__PURE__ */ f("div", {
		className: `absolute inset-x-0 ${t} overflow-hidden`,
		children: /* @__PURE__ */ f("div", {
			className: "scenery-drift flex w-max",
			style: {
				animationDuration: `${r}s`,
				animationPlayState: i ? "running" : "paused"
			},
			children: [0, 1].map((t) => /* @__PURE__ */ f("span", {
				className: "flex gap-9 pr-9",
				children: e.map((e, t) => /* @__PURE__ */ f("span", {
					className: n,
					children: e
				}, t))
			}, t))
		})
	});
}
//#endregion
//#region src/games/coltexpress/view-player.tsx
function Xt(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ f(en, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var U = {
	purse: "💰",
	gem: "💎",
	strongbox: "🧳"
}, Zt = "repeating-linear-gradient(45deg, rgba(255,253,246,.28) 0 2px, transparent 2px 7px), repeating-linear-gradient(-45deg, rgba(255,253,246,.28) 0 2px, transparent 2px 7px)", Qt = {
	angryMarshal: "😠",
	swivelArm: "🌀",
	braking: "🛑",
	takeItAll: "🧳",
	rebellion: "😡",
	pickpocketing: "🫰",
	marshalsRevenge: "💢",
	hostage: "🤠"
}, $t = {
	ghost: "👻",
	belle: "💃",
	cheyenne: "🪶",
	tuco: "🤠",
	django: "🎸",
	doc: "🎓"
};
function en({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let o = c(), s = (e) => n.find((t) => t.rid === e)?.name ?? e, m = l[(n.find((e) => e.rid === r)?.colorIndex ?? 0) % l.length].hex, h = e.scheme?.actor === r, g = e.pending?.by === r, [_, v] = a(null), y, b, x;
	if (e.phase === "scheme" && e.scheme) {
		let t = e.roundCard.turns[e.scheme.turnIdx];
		x = nn(o, t), h ? (y = "accent", b = t === "speeding" && e.scheme.actionsLeft === 1 ? o("games.coltexpress.schemePromptAgain") : o("games.coltexpress.schemePrompt")) : (y = "info", b = o("games.coltexpress.schemeWaiting", { name: s(e.scheme.actor) }));
	} else e.phase === "steal" ? (x = e.roundCard.event ? o(it[e.roundCard.event]) : void 0, e.pending && g ? (y = "warn", b = o("games.coltexpress.chooseTitle", { card: o(P[e.pending.card]) })) : e.pending ? (y = "info", b = o("games.coltexpress.stealWaiting", { name: s(e.pending.by) })) : (y = "info", b = o("games.coltexpress.stealRunning"))) : (y = "done", b = o("games.coltexpress.roundEnd"));
	let S = e.phase === "scheme" ? e.scheme?.actor : e.pending?.by, C = e.players.find((e) => e.rid === S) ?? e.players.find((e) => e.rid === r), w = typeof _ == "number" ? _ : C?.car ?? 0, T = _ === "overview" || _ === null && e.phase !== "steal", E = e.players.filter((e) => e.car === w), ee = e.cars[w], te = `${o("games.coltexpress.inside")}: ${E.filter((e) => !e.roof).map((e) => s(e.rid)).join(", ") || "—"} · ${ee?.inside.map((e) => o(ot[e.kind])).join(", ") || "—"} / ${o("games.coltexpress.roof")}: ${E.filter((e) => e.roof).map((e) => s(e.rid)).join(", ") || "—"} · ${ee?.roof.map((e) => o(ot[e.kind])).join(", ") || "—"}`;
	return /* @__PURE__ */ f("div", {
		className: "ce-sample ce-live",
		children: /* @__PURE__ */ f(u, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("header", {
				className: `ce-top ce-top--${y}`,
				children: [/* @__PURE__ */ f("span", {
					className: "ce-round",
					children: o("games.coltexpress.roundShort", {
						n: e.round,
						total: 5
					})
				}), /* @__PURE__ */ p("div", {
					className: "ce-top__message",
					children: [/* @__PURE__ */ f("span", {
						className: "ce-top__eyebrow",
						children: e.phase === "scheme" ? o("games.coltexpress.phaseScheme") : e.phase === "steal" ? o("games.coltexpress.phaseSteal") : o("games.coltexpress.phaseDone")
					}), /* @__PURE__ */ f("strong", { children: b })]
				})]
			}), /* @__PURE__ */ p("section", {
				className: "ce-players",
				"aria-label": o("games.coltexpress.currentAction"),
				children: [/* @__PURE__ */ f("div", {
					className: "ce-live__player-list",
					children: e.players.map((e) => /* @__PURE__ */ f(tn, {
						player: e,
						member: n.find((t) => t.rid === e.rid),
						active: S === e.rid,
						mine: r === e.rid
					}, e.rid))
				}), /* @__PURE__ */ p("span", {
					className: "ce-event",
					title: x,
					children: [/* @__PURE__ */ f("b", { children: e.phase === "scheme" ? "Ⅰ" : "Ⅱ" }), /* @__PURE__ */ f("span", { children: x ?? o("games.coltexpress.roundEnd") })]
				})]
			})] }),
			actionsHeight: "ce-live__actions-slot",
			actions: /* @__PURE__ */ p("footer", {
				className: "ce-tray",
				children: [e.phase === "done" ? /* @__PURE__ */ p("div", {
					className: "ce-result",
					children: [
						/* @__PURE__ */ f("span", {
							className: "ce-result__seal",
							children: "✓"
						}),
						/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("small", { children: o("games.coltexpress.phaseDone") }), /* @__PURE__ */ f("strong", { children: o("games.coltexpress.roundEnd") })] }),
						/* @__PURE__ */ f("span", {
							className: "ce-result__purse",
							children: "＄"
						})
					]
				}) : t && g && e.options && e.pending ? /* @__PURE__ */ f(Sn, {
					pub: e,
					options: e.options,
					members: n,
					send: i
				}, `${e.execIdx}:${e.pending.card}`) : t ? /* @__PURE__ */ f(xn, {
					priv: t,
					color: m,
					send: i,
					enabled: e.phase === "scheme" && h
				}) : /* @__PURE__ */ f("div", {
					className: "ce-live__waiting",
					children: e.phase === "steal" ? o("games.coltexpress.stealRunning") : b
				}), t ? /* @__PURE__ */ f(wn, { priv: t }) : /* @__PURE__ */ f("div", {
					className: "ce-stash",
					"aria-hidden": !0
				})]
			}),
			children: /* @__PURE__ */ p("div", {
				className: "ce-live__playfield",
				children: [/* @__PURE__ */ p("section", {
					className: "ce-stage",
					children: [
						/* @__PURE__ */ f("div", {
							className: "ce-stage__canvas",
							children: /* @__PURE__ */ f(on, {
								pub: e,
								members: n,
								inspectCar: _
							})
						}),
						/* @__PURE__ */ p("div", {
							className: "ce-stage__topline",
							children: [
								/* @__PURE__ */ p("span", {
									className: "ce-stage__compass",
									children: ["← ", o("games.coltexpress.engineDirection")]
								}),
								/* @__PURE__ */ f("span", {
									className: "ce-stage__brand",
									children: "COLT EXPRESS"
								}),
								/* @__PURE__ */ f("span", {
									className: "ce-stage__hint",
									children: o("games.coltexpress.orbitHint")
								})
							]
						}),
						/* @__PURE__ */ p("div", {
							className: "ce-stage__location",
							children: [
								/* @__PURE__ */ f("button", {
									type: "button",
									"aria-label": o("games.coltexpress.previousCar"),
									onClick: () => v((w - 1 + e.cars.length) % e.cars.length),
									children: "‹"
								}),
								/* @__PURE__ */ f("button", {
									type: "button",
									className: "ce-stage__location-number",
									"aria-label": o("games.coltexpress.inspectCurrentCar", { n: w }),
									onClick: () => v(w),
									children: T ? "◎" : String(w).padStart(2, "0")
								}),
								/* @__PURE__ */ p("span", {
									className: "ce-stage__location-copy",
									title: T ? o("games.coltexpress.trainOverview") : te,
									children: [T ? o("games.coltexpress.trainOverview") : w === 0 ? o("games.coltexpress.locomotive") : o("games.coltexpress.carN", { n: w }), /* @__PURE__ */ f("small", { children: T ? o("games.coltexpress.inspectHint") : te })]
								}),
								/* @__PURE__ */ f("button", {
									type: "button",
									"aria-label": o("games.coltexpress.nextCar"),
									onClick: () => v((w + 1) % e.cars.length),
									children: "›"
								}),
								/* @__PURE__ */ f("button", {
									type: "button",
									"aria-label": o(_ === "overview" ? "games.coltexpress.followAction" : "games.coltexpress.trainOverview"),
									onClick: () => v(_ === "overview" ? null : "overview"),
									children: _ === "overview" ? "⌖" : "▦"
								})
							]
						})
					]
				}), /* @__PURE__ */ f(yn, {
					pub: e,
					members: n
				})]
			})
		})
	});
}
function tn({ player: e, member: t, active: n, mine: r }) {
	let i = c(), { ref: a, hidden: s } = o(`seat:${e.rid}`), u = l[(t?.colorIndex ?? 0) % l.length];
	return /* @__PURE__ */ p("div", {
		ref: a,
		className: `ce-player ${n ? "ce-player--active" : ""}`,
		style: { visibility: s ? "hidden" : "visible" },
		title: `${t?.name ?? e.rid} · ${i(at[e.character])}`,
		children: [
			/* @__PURE__ */ f("span", {
				className: "ce-player__pawn",
				style: { backgroundColor: u.hex },
				children: $t[e.character]
			}),
			/* @__PURE__ */ p("span", {
				className: "ce-live__player-copy",
				children: [/* @__PURE__ */ f("span", {
					className: "ce-player__name",
					children: t?.name ?? e.rid
				}), /* @__PURE__ */ p("small", { children: [
					i(at[e.character]),
					" · ",
					e.loot.length
				] })]
			}),
			r && /* @__PURE__ */ f("span", {
				className: "ce-player__turn",
				children: "◆"
			})
		]
	});
}
function nn(e, t) {
	return e(rt[t]);
}
var rn = [
	"Ⅰ",
	"Ⅱ",
	"Ⅲ",
	"Ⅳ",
	"Ⅴ",
	"Ⅵ"
];
function an({ pub: e }) {
	let t = c();
	return /* @__PURE__ */ p("div", {
		className: "ce-ticket__turns",
		children: [e.roundCard.turns.map((n, r) => /* @__PURE__ */ f("b", {
			title: nn(t, n),
			className: e.phase === "scheme" && e.scheme?.turnIdx === r ? "is-current" : "",
			children: rn[r] ?? r + 1
		}, r)), e.roundCard.event && /* @__PURE__ */ f("span", {
			title: t(it[e.roundCard.event]),
			children: Qt[e.roundCard.event]
		})]
	});
}
function on({ pub: e, members: t, inspectCar: n }) {
	let [r] = a(bt);
	return f(r ? xt : sn, {
		pub: e,
		members: t,
		inspectCar: n
	});
}
function sn({ pub: e, members: t, inspectCar: r }) {
	let { ref: a } = o("train"), s = i(null);
	return n(() => {
		let e = s.current;
		if (!e) return;
		if (typeof r != "number") {
			r === "overview" && (e.scrollLeft = 0);
			return;
		}
		let t = e.querySelector(`[data-car="${r}"]`);
		t && (e.scrollLeft = t.offsetLeft - (e.clientWidth - t.clientWidth) / 2);
	}, [r]), /* @__PURE__ */ p("div", {
		className: "relative min-h-0 flex-1",
		children: [/* @__PURE__ */ f(Yt, { running: e.phase !== "done" }), /* @__PURE__ */ f("div", {
			ref: (e) => {
				s.current = e, a(e);
			},
			className: "relative h-full overflow-x-auto",
			children: /* @__PURE__ */ p("div", {
				className: "mx-auto flex h-full w-max flex-col justify-end px-2 pb-1",
				children: [/* @__PURE__ */ f("div", {
					className: "flex items-end gap-1.5 pt-1",
					children: e.cars.map((n, r) => /* @__PURE__ */ f(dn, {
						pub: e,
						members: t,
						idx: r,
						car: n,
						loco: r === 0,
						last: r === e.cars.length - 1
					}, r))
				}), /* @__PURE__ */ f(pn, { running: e.phase !== "done" })]
			})
		})]
	});
}
var cn = {
	backgroundColor: E.accent,
	backgroundImage: "repeating-linear-gradient(90deg, rgba(43,33,24,.10) 0 1px, transparent 1px 18px), linear-gradient(rgba(255,253,246,.14), rgba(43,33,24,.14))"
}, ln = {
	backgroundColor: `color-mix(in srgb, var(--color-ink) 76%, ${E.accent})`,
	backgroundImage: "repeating-linear-gradient(90deg, rgba(0,0,0,.14) 0 1px, transparent 1px 18px), linear-gradient(rgba(255,253,246,.10), rgba(0,0,0,.20))"
}, un = { background: "linear-gradient(rgba(255,253,246,.28), transparent), color-mix(in srgb, var(--color-ink) 88%, var(--color-paper))" };
function dn({ pub: e, members: t, idx: n, car: r, loco: i, last: a }) {
	let o = c();
	return /* @__PURE__ */ p("div", {
		"data-car": n,
		className: "relative flex w-28 flex-none flex-col",
		children: [
			/* @__PURE__ */ f(mn, {
				pub: e,
				members: t,
				car: n,
				roof: !0,
				loot: r.roof,
				shift: i
			}),
			/* @__PURE__ */ f("div", {
				className: "relative h-2.5 flex-none rounded-t-full border-2 border-b-0 border-ink",
				style: un,
				children: i && /* @__PURE__ */ p("span", {
					className: "absolute -top-5 left-1 flex flex-col items-center",
					"aria-hidden": !0,
					children: [/* @__PURE__ */ f("span", { className: "h-1 w-3 rounded-t-sm bg-ink" }), /* @__PURE__ */ f("span", { className: "h-3.5 w-1.5 bg-ink/90" })]
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "relative flex flex-col border-2 border-t-0 border-ink",
				style: i ? ln : cn,
				children: [/* @__PURE__ */ f(mn, {
					pub: e,
					members: t,
					car: n,
					roof: !1,
					loot: r.inside,
					screen: !0
				}), /* @__PURE__ */ f("span", {
					className: "absolute top-0.5 right-0.5 z-20 rounded border border-ink/60 bg-ink/70 px-1 text-[8px] leading-3.5 font-bold text-surface",
					children: i ? `🚂 ${o("games.coltexpress.locomotive")}` : o("games.coltexpress.carN", { n })
				})]
			}),
			i && /* @__PURE__ */ f("span", {
				className: "absolute -left-1.5 bottom-3.5 h-3 w-2 bg-ink/85",
				style: { clipPath: "polygon(100% 0, 100% 100%, 0 100%)" },
				"aria-hidden": !0
			}),
			!a && /* @__PURE__ */ f("span", {
				className: "absolute -right-2 bottom-3.5 z-10 h-1 w-2.5 rounded-full bg-ink/80",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ p("div", {
				className: "relative mx-0.5 h-4 flex-none",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ f("span", { className: "absolute inset-x-0 top-0 h-1 rounded-sm bg-ink/75" }), /* @__PURE__ */ p("span", {
					className: "absolute inset-x-1.5 top-0.5 flex justify-between",
					children: [
						/* @__PURE__ */ f(fn, {}),
						/* @__PURE__ */ f(fn, {}),
						/* @__PURE__ */ f(fn, {})
					]
				})]
			})
		]
	});
}
function fn() {
	return /* @__PURE__ */ f("span", {
		className: "size-3.5 rounded-full border-2 border-ink",
		style: { background: "radial-gradient(circle, var(--color-paper) 0 26%, var(--color-ink) 30%)" }
	});
}
function pn({ running: e }) {
	return /* @__PURE__ */ p("div", {
		className: "flex-none pt-0.5",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("div", { className: "h-1 rounded-full bg-ink/80" }), /* @__PURE__ */ f("div", {
			className: "rail-scroll h-1.5 opacity-45",
			style: {
				backgroundImage: "repeating-linear-gradient(90deg, var(--color-ink) 0 5px, transparent 5px 12px)",
				animationPlayState: e ? "running" : "paused"
			}
		})]
	});
}
function mn({ pub: e, members: t, car: n, roof: r, loot: i, shift: a, screen: s }) {
	let { ref: c } = o(`car:${n}:${r ? "roof" : "in"}`), l = e.players.filter((e) => e.car === n && e.roof === r), u = !r && e.marshal === n, m = Math.ceil(i.length / 2);
	return /* @__PURE__ */ p("div", {
		ref: c,
		className: `relative flex flex-col justify-end px-0.5 ${r ? "min-h-10 flex-none" : "min-h-14 flex-none"}`,
		children: [
			s && /* @__PURE__ */ f("span", {
				className: "absolute inset-x-1 top-1 bottom-2 rounded-[4px] border border-ink/45",
				style: { background: "radial-gradient(ellipse at 50% 38%, var(--color-paper) 0%, var(--color-warn-soft) 78%)" },
				"aria-hidden": !0
			}),
			!r && /* @__PURE__ */ f("span", {
				className: "absolute inset-x-0 bottom-0 h-2 bg-ink/30",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ p("div", {
				className: `relative flex flex-wrap items-end justify-center gap-0.5 ${r ? "" : "pb-0.5"} ${a ? "pl-4" : ""}`,
				children: [u && /* @__PURE__ */ f(hn, {}), l.map((e) => /* @__PURE__ */ f(gn, {
					rid: e.rid,
					character: e.character,
					members: t
				}, e.rid))]
			}),
			i.length > 0 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("div", {
				className: "pointer-events-none absolute bottom-0 left-0.5 z-20 flex max-w-[45%] flex-wrap items-end gap-[3px]",
				children: i.slice(0, m).map((e, t) => /* @__PURE__ */ f("span", {
					className: "text-xs leading-none",
					style: { rotate: `${[
						-9,
						7,
						-12,
						5,
						-6,
						11
					][t % 6]}deg` },
					children: U[e.kind]
				}, t))
			}), /* @__PURE__ */ f("div", {
				className: "pointer-events-none absolute right-0.5 bottom-0 z-20 flex max-w-[45%] flex-wrap items-end justify-end gap-[3px]",
				children: i.slice(m).map((e, t) => /* @__PURE__ */ f("span", {
					className: "text-xs leading-none",
					style: { rotate: `${[
						8,
						-7,
						12,
						-5,
						6,
						-11
					][t % 6]}deg` },
					children: U[e.kind]
				}, t))
			})] })
		]
	});
}
function hn() {
	let { ref: e } = o("marshal");
	return /* @__PURE__ */ f("span", {
		ref: e,
		className: "flex h-9 w-7 items-end justify-center",
		children: /* @__PURE__ */ f(nt, { className: "h-9" })
	});
}
function gn({ rid: e, character: t, members: n }) {
	let r = n.find((t) => t.rid === e), i = l[(r?.colorIndex ?? 0) % l.length];
	return /* @__PURE__ */ f("span", {
		className: "flex h-9 w-7 items-end justify-center",
		title: r?.name ?? e,
		children: /* @__PURE__ */ f(tt, {
			character: t,
			edge: i.hex,
			className: "h-9"
		})
	});
}
function _n({ card: e }) {
	let t = c();
	return /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ p("span", {
			className: "ce-card__corner",
			children: [
				"✦ ",
				t("games.coltexpress.wanted"),
				" ✦"
			]
		}),
		/* @__PURE__ */ f("span", {
			className: "ce-card__image",
			children: /* @__PURE__ */ f(vn, { card: e })
		}),
		/* @__PURE__ */ f("span", {
			className: "ce-card__label",
			children: t(P[e])
		})
	] });
}
function vn({ card: e }) {
	return e === "robbery" ? /* @__PURE__ */ p("svg", {
		viewBox: "0 0 48 48",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("path", {
				d: "M20 9c3 3 5 3 8 0l-2 7h-4zM17 18h14l5 15c1 5-3 8-12 8s-13-3-12-8z",
				fill: "currentColor",
				stroke: "#2d1c16",
				strokeWidth: "2.2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M20 27h8m-4-4v11",
				stroke: "#f3d9a6",
				strokeWidth: "2.5",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M17 18h14",
				stroke: "#2d1c16",
				strokeWidth: "3"
			})
		]
	}) : e === "fire" ? /* @__PURE__ */ p("svg", {
		viewBox: "0 0 48 48",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("path", {
			d: "M7 20h23l4 5-5 4H18l-2 11h-7l3-12H7z",
			fill: "currentColor",
			stroke: "#2d1c16",
			strokeWidth: "2.2",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ f("path", {
			d: "M30 18h9m-4-4v8",
			stroke: "#2d1c16",
			strokeWidth: "2.3",
			strokeLinecap: "round"
		})]
	}) : e === "move" ? /* @__PURE__ */ p("svg", {
		viewBox: "0 0 48 48",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("path", {
			d: "M12 34V17h6l4 9h6l4 8-8 5H9z",
			fill: "currentColor",
			stroke: "#2d1c16",
			strokeWidth: "2.2",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ f("path", {
			d: "M15 13h8m-4-4v8M31 12h10m-4-4 4 4-4 4",
			stroke: "#2d1c16",
			strokeWidth: "2.3",
			strokeLinecap: "round"
		})]
	}) : e === "floorChange" ? /* @__PURE__ */ p("svg", {
		viewBox: "0 0 48 48",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("path", {
			d: "M12 40V8m18 32V8M12 14h18M12 22h18M12 30h18M12 38h18",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "3",
			strokeLinecap: "round"
		}), /* @__PURE__ */ f("path", {
			d: "m35 27 5-6 5 6m-5-6v15",
			fill: "none",
			stroke: "#2d1c16",
			strokeWidth: "2.5",
			strokeLinecap: "round"
		})]
	}) : e === "marshal" ? /* @__PURE__ */ p("svg", {
		viewBox: "0 0 48 48",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("path", {
			d: "m24 5 4.5 9.3 10.2-1.5-3.6 9.7 7 7.6-10.4 1.3L24 41l-7.7-9.6L6 30.1l7-7.6-3.6-9.7 10.2 1.5z",
			fill: "currentColor",
			stroke: "#2d1c16",
			strokeWidth: "2.1",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ f("circle", {
			cx: "24",
			cy: "23",
			r: "4",
			fill: "#f3d9a6"
		})]
	}) : /* @__PURE__ */ p("svg", {
		viewBox: "0 0 48 48",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("path", {
			d: "M11 37V21c0-3 4-4 6-1v-7c0-4 5-4 5 0v6c0-4 5-4 5 0v2c1-4 6-3 6 1v3c2-3 6-2 6 2v5c0 7-5 11-13 11h-7c-5 0-8-3-8-6z",
			fill: "currentColor",
			stroke: "#2d1c16",
			strokeWidth: "2.3",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ f("path", {
			d: "M11 28h8",
			stroke: "#2d1c16",
			strokeWidth: "2.3"
		})]
	});
}
function yn({ pub: e, members: t }) {
	let r = c(), { ref: a } = o("pile"), s = i(null), l = e.pile.length === 0 || e.phase === "done" ? -1 : e.phase === "scheme" ? e.pile.length - 1 : e.pending ? e.execIdx : Math.max(0, e.execIdx - 1), u = e.pile[l], d = t.find((e) => e.rid === u?.by);
	return n(() => {
		let e = s.current, t = e?.children.item(l);
		e && t && (e.scrollLeft = t.offsetLeft - (e.clientWidth - t.clientWidth) / 2);
	}, [l, e.pile.length]), /* @__PURE__ */ p("aside", {
		className: `ce-timeline ${e.phase === "steal" ? "ce-timeline--resolving" : ""}`,
		"aria-label": r("games.coltexpress.actionPile"),
		children: [
			/* @__PURE__ */ p("div", {
				className: "ce-timeline__round",
				children: [/* @__PURE__ */ p("span", { children: [
					r("games.coltexpress.roundCard"),
					" ",
					e.round
				] }), /* @__PURE__ */ f(an, { pub: e })]
			}),
			/* @__PURE__ */ p("div", {
				className: "ce-timeline__head",
				children: [/* @__PURE__ */ p("strong", { children: ["✦ ", r("games.coltexpress.actionPile")] }), /* @__PURE__ */ f("span", {
					"aria-live": "polite",
					children: e.phase === "steal" && u ? `${String(l + 1).padStart(2, "0")}/${String(e.pile.length).padStart(2, "0")} · ${d?.name ?? u.by} · ${u.card ? r(P[u.card]) : r("games.coltexpress.faceDown")}` : r("games.coltexpress.pileCount", { n: e.pile.length })
				})]
			}),
			/* @__PURE__ */ p("ol", {
				ref: (e) => {
					s.current = e, a(e);
				},
				className: "ce-timeline__cards",
				children: [e.pile.map((n, r) => /* @__PURE__ */ f(bn, {
					entry: n,
					index: r,
					member: t.find((e) => e.rid === n.by),
					current: r === l,
					resolved: e.phase !== "scheme" && r < e.execIdx && r !== l
				}, r)), e.pile.length === 0 && /* @__PURE__ */ f("li", {
					className: "ce-timeline__empty",
					"aria-label": r("games.coltexpress.waiting"),
					children: "✦"
				})]
			}),
			/* @__PURE__ */ p("div", {
				className: "ce-timeline__focus",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ f("span", { children: u?.card ? /* @__PURE__ */ f(vn, { card: u.card }) : "✦" }), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("small", { children: e.phase === "done" ? r("games.coltexpress.phaseDone") : e.phase === "steal" ? r("games.coltexpress.phaseSteal") : r("games.coltexpress.phaseScheme") }), /* @__PURE__ */ f("strong", { children: u ? `${d?.name ?? u.by} · ${u.card ? r(P[u.card]) : r("games.coltexpress.faceDown")}` : e.phase === "done" ? r("games.coltexpress.roundEnd") : r("games.coltexpress.waiting") })] })]
			})
		]
	});
}
function bn({ entry: e, index: t, member: n, current: r, resolved: i }) {
	let a = c(), { ref: s } = o(r ? "pile:current" : null), u = l[(n?.colorIndex ?? 0) % l.length], d = e.card ? a(P[e.card]) : a("games.coltexpress.faceDown");
	return /* @__PURE__ */ p("li", {
		ref: s,
		title: `${t + 1}. ${n?.name ?? e.by} · ${d}`,
		"aria-label": `${t + 1}. ${n?.name ?? e.by} · ${d}`,
		className: `ce-timeline__card ${r ? "is-current" : ""} ${i ? "is-resolved" : ""} ${e.card === null ? "is-hidden" : ""}`,
		style: { "--ce-owner": u.hex },
		children: [
			/* @__PURE__ */ f("span", {
				className: "ce-timeline__number",
				children: String(t + 1).padStart(2, "0")
			}),
			/* @__PURE__ */ f("span", {
				className: "ce-timeline__art",
				children: e.card ? /* @__PURE__ */ f(vn, { card: e.card }) : "✦"
			}),
			/* @__PURE__ */ f("span", {
				className: "ce-timeline__label",
				children: d
			}),
			/* @__PURE__ */ f("span", {
				className: "ce-timeline__owner",
				children: n?.name ?? e.by
			}),
			e.faceDown && /* @__PURE__ */ f("span", {
				className: "ce-timeline__secret",
				title: a("games.coltexpress.faceDown"),
				children: "?"
			})
		]
	});
}
function xn({ priv: e, color: t, send: n, enabled: r }) {
	let i = c(), [o, s] = a(!1);
	return /* @__PURE__ */ p("div", {
		className: `ce-hand ${r ? "" : "ce-hand--waiting"}`,
		children: [/* @__PURE__ */ p("div", {
			className: "ce-hand__caption",
			children: [
				/* @__PURE__ */ f("span", { children: i("games.coltexpress.currentAction") }),
				/* @__PURE__ */ f("strong", { children: i(r ? "games.coltexpress.schemePrompt" : "games.coltexpress.waiting") }),
				e.canFaceDown && /* @__PURE__ */ p("button", {
					type: "button",
					disabled: !r,
					"aria-pressed": o,
					"aria-label": i("games.coltexpress.faceDownAria"),
					onClick: () => s((e) => !e),
					className: `ce-live__face-down ${o ? "is-selected" : ""}`,
					children: ["🂠 ", i("games.coltexpress.faceDown")]
				})
			]
		}), /* @__PURE__ */ p("div", {
			className: "ce-hand__cards",
			children: [e.hand.map((e, a) => e === "bullet" ? /* @__PURE__ */ p("span", {
				title: i("games.coltexpress.actionBullet"),
				className: "ce-card ce-card--disabled",
				children: [
					/* @__PURE__ */ p("span", {
						className: "ce-card__corner",
						children: [
							"✦ ",
							i("games.coltexpress.wanted"),
							" ✦"
						]
					}),
					/* @__PURE__ */ f("span", {
						className: "ce-card__image ce-live__bullet",
						children: "🔸"
					}),
					/* @__PURE__ */ f("span", {
						className: "ce-card__label",
						children: i("games.coltexpress.actionBullet")
					})
				]
			}, a) : /* @__PURE__ */ f("button", {
				type: "button",
				"aria-label": i(P[e]),
				disabled: !r,
				onClick: () => n({
					type: "play",
					card: e,
					...o ? { faceDown: !0 } : {}
				}),
				className: "ce-card",
				style: { "--ce-player": t },
				children: /* @__PURE__ */ f(_n, { card: e })
			}, a)), /* @__PURE__ */ p("button", {
				type: "button",
				disabled: !r,
				onClick: () => n({ type: "draw" }),
				className: "ce-live__draw",
				children: [
					/* @__PURE__ */ f("b", { children: "＋3" }),
					/* @__PURE__ */ f("span", { children: i("games.coltexpress.draw") }),
					/* @__PURE__ */ f("small", { children: e.deckCount })
				]
			})]
		})]
	});
}
function Sn({ pub: e, options: t, members: n, send: r }) {
	let i = c(), [o, s] = a(null), [l, u] = a(null);
	switch (t.kind) {
		case "move": return /* @__PURE__ */ f(W, {
			label: i("games.coltexpress.chooseMove"),
			children: t.moves.map((t) => /* @__PURE__ */ p("button", {
				type: "button",
				className: "ce-command",
				onClick: () => r({
					type: "chooseMove",
					dir: t.dir,
					dist: t.dist
				}),
				children: [
					t.dir < 0 ? "←" : "→",
					" ",
					i("games.coltexpress.carN", { n: (e.players.find((t) => t.rid === e.pending?.by)?.car ?? 0) + t.dir * t.dist })
				]
			}, `${t.dir}:${t.dist}`))
		});
		case "marshal": return /* @__PURE__ */ f(W, {
			label: i("games.coltexpress.chooseMarshal"),
			children: t.dirs.map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				className: "ce-command",
				onClick: () => r({
					type: "chooseMarshal",
					dir: e
				}),
				children: [
					e < 0 ? "⬅️" : "➡️",
					" ",
					i(e < 0 ? "games.coltexpress.dirForward" : "games.coltexpress.dirBackward")
				]
			}, e))
		});
		case "fire": return /* @__PURE__ */ f(W, {
			label: i("games.coltexpress.chooseFire"),
			children: t.targets.map((t) => /* @__PURE__ */ f(Cn, {
				rid: t,
				members: n,
				pub: e,
				onClick: () => r({
					type: "chooseFire",
					target: t
				})
			}, t))
		});
		case "robbery": {
			let n = e.players.find((t) => t.rid === e.pending?.by), a = n ? n.roof ? e.cars[n.car].roof : e.cars[n.car].inside : [];
			return /* @__PURE__ */ f(W, {
				label: i("games.coltexpress.chooseRobbery"),
				children: t.lootIdxs.map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "ce-loot-option",
					onClick: () => r({
						type: "chooseRobbery",
						lootIdx: e
					}),
					children: [/* @__PURE__ */ f("span", {
						className: `ce-loot-option__icon ce-loot-option__icon--${a[e]?.kind ?? "purse"}`,
						children: a[e]?.kind === "gem" ? "◆" : a[e]?.kind === "strongbox" ? "▣" : "＄"
					}), /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("strong", { children: i(ot[a[e]?.kind ?? "purse"]) }), /* @__PURE__ */ p("small", { children: [
						a[e]?.value === null ? i("games.coltexpress.purseAria") : `$${a[e]?.value ?? 0}`,
						" · ",
						String.fromCharCode(65 + e)
					] })] })]
				}, e))
			});
		}
		case "punch": {
			if (!o) return /* @__PURE__ */ f(W, {
				label: i("games.coltexpress.choosePunchTarget"),
				children: t.targets.map((t) => /* @__PURE__ */ f(Cn, {
					rid: t,
					members: n,
					pub: e,
					onClick: () => s(t)
				}, t))
			});
			let a = t.lootCounts[o] ?? 0;
			if (a > 0 && l === null) {
				let t = e.players.find((e) => e.rid === o);
				return /* @__PURE__ */ f(W, {
					label: i("games.coltexpress.choosePunchLoot"),
					children: (t?.loot ?? []).map((e, t) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "ce-command",
						onClick: () => u(t),
						children: [U[e.kind], e.value !== null && /* @__PURE__ */ f("span", {
							className: "font-mono text-xs tabular-nums",
							children: e.value
						})]
					}, t))
				});
			}
			let c = a > 0 ? l : null;
			return /* @__PURE__ */ f(W, {
				label: i("games.coltexpress.choosePunchDir"),
				children: t.dirs.map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "ce-command",
					onClick: () => r({
						type: "choosePunch",
						target: o,
						lootIdx: c,
						dir: e
					}),
					children: [
						e < 0 ? "⬅️" : "➡️",
						" ",
						i(e < 0 ? "games.coltexpress.dirForward" : "games.coltexpress.dirBackward")
					]
				}, e))
			});
		}
	}
}
function W({ label: e, children: t }) {
	let n = c();
	return /* @__PURE__ */ p("div", {
		className: "ce-choice",
		children: [/* @__PURE__ */ p("div", {
			className: "ce-choice__title",
			children: [/* @__PURE__ */ p("span", {
				className: "ce-choice__action",
				children: ["◈ ", n("games.coltexpress.currentAction")]
			}), /* @__PURE__ */ f("strong", { children: e })]
		}), /* @__PURE__ */ f("div", {
			className: "ce-choice__options",
			children: t
		})]
	});
}
function Cn({ rid: e, members: t, pub: n, onClick: r }) {
	let i = t.find((t) => t.rid === e), a = n.players.find((t) => t.rid === e), o = l[(i?.colorIndex ?? 0) % l.length];
	return /* @__PURE__ */ p("button", {
		type: "button",
		onClick: r,
		className: "ce-command",
		style: { boxShadow: `2px 2px 0 ${o.hex}` },
		children: [a && /* @__PURE__ */ f("span", {
			"aria-hidden": !0,
			children: $t[a.character]
		}), i?.name ?? e]
	});
}
function wn({ priv: e }) {
	let t = c(), { ref: n } = o("stash"), r = e.myLoot.reduce((e, t) => e + t.value, 0);
	return /* @__PURE__ */ p("div", {
		ref: n,
		className: "ce-stash",
		children: [
			/* @__PURE__ */ f("span", { children: t("games.coltexpress.myLoot", { n: r }) }),
			/* @__PURE__ */ f("span", {
				className: "ce-stash__loot",
				children: e.myLoot.map((n, r) => /* @__PURE__ */ p("span", {
					title: t(ot[n.kind]),
					children: [
						U[n.kind],
						" ",
						n.value,
						r < e.myLoot.length - 1 ? " + " : ""
					]
				}, r))
			}),
			/* @__PURE__ */ p("span", {
				"aria-label": t("games.coltexpress.bulletsAria", { n: e.bulletsLeft }),
				children: [
					t("games.coltexpress.bulletsLabel"),
					" ",
					/* @__PURE__ */ f("b", { children: e.bulletsLeft })
				]
			})
		]
	});
}
//#endregion
//#region src/games/coltexpress/bot.ts
var G = {
	fire: 150,
	gunLead: 350,
	taken: 80,
	otherTaken: 120,
	spot: .25,
	near: .1,
	marshal: 150,
	draw: 40
};
function K(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Tn(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967296 < e;
}
var q = (e) => e.reduce((e, t) => e + t.value, 0);
function En(e, t) {
	let n = he.slice(e.cars.length - 1);
	for (let e of t?.myLoot ?? []) {
		if (e.kind !== "purse") continue;
		let t = n.indexOf(e.value);
		t >= 0 && n.splice(t, 1);
	}
	return n.length ? n.reduce((e, t) => e + t, 0) / n.length : 350;
}
function Dn(e, t, n, r) {
	let i = (e) => ({
		kind: e.kind,
		value: e.value ?? r
	}), a = e.players.map((e) => e.rid), o = (t) => Object.fromEntries(e.players.map((e) => [e.rid, t(e)]));
	return {
		players: a,
		characters: o((e) => e.character),
		cars: e.cars.map((e) => ({
			inside: e.inside.map(i),
			roof: e.roof.map(i)
		})),
		positions: o((e) => ({
			car: e.car,
			roof: e.roof
		})),
		marshal: e.marshal,
		strongbox2: e.strongbox2,
		neutralLeft: e.neutralLeft,
		decks: Object.fromEntries(a.map((e) => [e, []])),
		hands: Object.fromEntries(a.map((e) => [e, []])),
		loots: o((e) => e.rid === n && t ? t.myLoot.map((e) => ({ ...e })) : e.loot.map(i)),
		bulletsLeft: o((e) => e.rid === n && t ? t.bulletsLeft : 6 - e.fired),
		fired: o((e) => e.fired),
		taken: o((e) => e.taken),
		roundCards: [e.roundCard],
		round: 1,
		firstPlayer: 0,
		phase: "steal",
		turnIdx: 0,
		orderPos: 0,
		actionsLeft: 1,
		ghostSpent: {},
		pile: e.pile.map((e) => ({
			by: e.by,
			card: e.card ?? "move",
			faceDown: e.faceDown
		})),
		execIdx: 0,
		pending: null,
		eventDone: !1,
		beatMs: 0,
		seed: 1,
		rngCursor: 0
	};
}
function On(e, t, n) {
	if (n) switch (n.kind) {
		case "move": {
			let r = e.positions[t], i, a = -Infinity;
			for (let t of n.moves) {
				let n = r.car + t.dir * t.dist, o = q(r.roof ? e.cars[n].roof : e.cars[n].inside) - (!r.roof && n === e.marshal ? 500 : 0);
				o > a && (a = o, i = {
					kind: "move",
					dir: t.dir,
					dist: t.dist
				});
			}
			return i;
		}
		case "marshal": {
			let r, i = -Infinity;
			for (let a of n.dirs) {
				let n = e.marshal + a, o = e.players.filter((t) => !e.positions[t].roof && e.positions[t].car === n), s = o.filter((e) => e !== t).length * 200 - (o.includes(t) ? 600 : 0);
				s > i && (i = s, r = {
					kind: "marshal",
					dir: a
				});
			}
			return r;
		}
		case "fire": {
			if (!n.targets.length) return;
			let t = n.targets[0], r = -1;
			for (let i of n.targets) {
				let n = q(e.loots[i]);
				n > r && (r = n, t = i);
			}
			return {
				kind: "fire",
				target: t
			};
		}
		case "robbery": {
			if (!n.lootIdxs.length) return;
			let r = e.positions[t], i = r.roof ? e.cars[r.car].roof : e.cars[r.car].inside, a = n.lootIdxs[0], o = -1;
			for (let e of n.lootIdxs) i[e].value > o && (o = i[e].value, a = e);
			return {
				kind: "robbery",
				lootIdx: a
			};
		}
		case "punch": {
			if (!n.targets.length) return;
			let t = n.targets[0], r = -1;
			for (let i of n.targets) {
				let n = q(e.loots[i]);
				n > r && (r = n, t = i);
			}
			let i = e.loots[t], a = null;
			if (i.length) {
				a = 0;
				for (let e = 1; e < i.length; e += 1) i[e].value > i[a].value && (a = e);
			}
			let o = e.positions[t], s = n.dirs[0], c = -Infinity;
			for (let t of n.dirs) {
				let n = o.car + t, r = -q(o.roof ? e.cars[n].roof : e.cars[n].inside) * .2;
				!o.roof && n === e.marshal && (r += 300), r > c && (c = r, s = t);
			}
			return {
				kind: "punch",
				target: t,
				lootIdx: a,
				dir: s
			};
		}
	}
}
function kn(e, t) {
	let n = e.positions[t], r = q(e.loots[t]), i = e.fired[t];
	r += i * G.fire;
	let a = Math.max(0, ...e.players.filter((e) => e !== t).map((t) => e.fired[t]));
	i > 0 && i >= a && (r += G.gunLead), r -= e.taken[t] * G.taken;
	let o = n.roof ? e.cars[n.car].roof : e.cars[n.car].inside;
	r += q(o) * G.spot;
	let s = q(n.roof ? e.cars[n.car].inside : e.cars[n.car].roof);
	for (let t = 1; t <= (n.roof ? 3 : 1); t += 1) for (let r of [-1, 1]) {
		let i = n.car + r * t;
		i >= 0 && i < e.cars.length && (s = Math.max(s, q(n.roof ? e.cars[i].roof : e.cars[i].inside)));
	}
	return r += s * G.near, !n.roof && n.car === e.marshal && (r -= G.marshal), r;
}
var An = (e, t) => e.players.reduce((n, r) => n + (r === t ? 0 : e.taken[r]), 0);
function jn(e, t) {
	let n = e.public, r = e.private;
	if (!r) return { type: "draw" };
	let i = r.hand.filter((e) => e !== "bullet"), a = Dn(n, r, t, En(n, r)), o = n.pile.map((e, t) => e.card === null ? t : -1).filter((e) => e >= 0), s = o.length ? 6 : 1, c = [];
	for (let e = 0; e < s; e += 1) {
		let e = structuredClone(a);
		for (let t of o) e.pile[t].card = K(pe);
		for (let t of e.pile) Fe(e, t.by, t.card, On(e, t.by, N(e, t.by, t.card)));
		c.push(e);
	}
	let l = (e) => {
		let n = 0;
		for (let r of c) {
			let i = structuredClone(r);
			e && Fe(i, t, e, On(i, t, N(i, t, e))), Le(i), n += kn(i, t);
		}
		return n / c.length + (e === null ? G.draw : 0);
	}, u = [...new Set(i)], d = null, f = -Infinity;
	(r.deckCount > 0 || !u.length) && (f = l(null));
	for (let e of u) {
		let t = l(e);
		t > f && (f = t, d = e);
	}
	return d ? {
		type: "play",
		card: d,
		...r.canFaceDown ? { faceDown: !0 } : {}
	} : { type: "draw" };
}
function Mn(e, t) {
	let n = e.public, r = n.options, i = n.pending;
	if (!r || !i) return null;
	let a = En(n, e.private), o = Dn(n, e.private, t, a), s = An(o, t), c = (e) => {
		let n = structuredClone(o);
		return Fe(n, t, i.card, e), kn(n, t) + (An(n, t) - s) * G.otherTaken;
	}, l = (e, t, n) => {
		let r = e[0], i = -Infinity;
		for (let n of e) {
			let e = c(t(n));
			e > i && (i = e, r = n);
		}
		return n(r);
	};
	switch (r.kind) {
		case "move": return l(r.moves, (e) => ({
			kind: "move",
			dir: e.dir,
			dist: e.dist
		}), (e) => ({
			type: "chooseMove",
			dir: e.dir,
			dist: e.dist
		}));
		case "marshal": return l(r.dirs, (e) => ({
			kind: "marshal",
			dir: e
		}), (e) => ({
			type: "chooseMarshal",
			dir: e
		}));
		case "fire": return l(r.targets, (e) => ({
			kind: "fire",
			target: e
		}), (e) => ({
			type: "chooseFire",
			target: e
		}));
		case "robbery": return l(r.lootIdxs, (e) => ({
			kind: "robbery",
			lootIdx: e
		}), (e) => ({
			type: "chooseRobbery",
			lootIdx: e
		}));
		case "punch": {
			let e = [];
			for (let t of r.targets) {
				let n = r.lootCounts[t] > 0 ? Array.from({ length: r.lootCounts[t] }, (e, t) => t) : [null];
				for (let i of r.dirs) for (let r of n) e.push({
					target: t,
					lootIdx: r,
					dir: i
				});
			}
			return l(e, (e) => ({
				kind: "punch",
				target: e.target,
				lootIdx: e.lootIdx,
				dir: e.dir
			}), (e) => ({
				type: "choosePunch",
				target: e.target,
				lootIdx: e.lootIdx,
				dir: e.dir
			}));
		}
	}
}
function Nn(e) {
	let t = e.private, n = (t?.hand ?? []).filter((e) => e !== "bullet");
	return t && t.deckCount > 0 && (n.length === 0 || Tn(.3)) || !n.length ? { type: "draw" } : {
		type: "play",
		card: K(n),
		...t?.canFaceDown && Tn(.5) ? { faceDown: !0 } : {}
	};
}
function Pn(e) {
	let t = e.options;
	if (!t || !e.pending) return null;
	switch (t.kind) {
		case "move": {
			let e = K(t.moves);
			return {
				type: "chooseMove",
				dir: e.dir,
				dist: e.dist
			};
		}
		case "marshal": return {
			type: "chooseMarshal",
			dir: K(t.dirs)
		};
		case "fire": return {
			type: "chooseFire",
			target: K(t.targets)
		};
		case "robbery": return {
			type: "chooseRobbery",
			lootIdx: K(t.lootIdxs)
		};
		case "punch": {
			let e = K(t.targets), n = t.lootCounts[e];
			return {
				type: "choosePunch",
				target: e,
				lootIdx: n > 0 ? K(Array.from({ length: n }, (e, t) => t)) : null,
				dir: K(t.dirs)
			};
		}
	}
}
var Fn = (e, t) => {
	let n = e.public, r = t.difficulty === "weak";
	if (n.phase === "steal" && n.pending?.by === t.rid) {
		let i = r ? Pn(n) : Mn(e, t.rid);
		return i ? { action: i } : null;
	}
	return n.phase === "scheme" && n.scheme?.actor === t.rid ? { action: r ? Nn(e) : jn(e, t.rid) } : null;
}, In = (e, t, n) => {
	let r = (e) => {
		let r = t.public.players.find((t) => t.rid === e);
		return r ? n(at[r.character]) : e;
	}, i = (e) => n(e < 0 ? "games.coltexpress.dirForward" : "games.coltexpress.dirBackward");
	switch (e.type) {
		case "play": return e.faceDown ? n("games.coltexpress.hintPlayFaceDown", { card: n(P[e.card]) }) : n("games.coltexpress.hintPlay", { card: n(P[e.card]) });
		case "draw": return n("games.coltexpress.hintDraw");
		case "chooseMove": return n("games.coltexpress.hintMove", {
			dir: i(e.dir),
			n: e.dist
		});
		case "chooseMarshal": return n("games.coltexpress.hintMarshal", { dir: i(e.dir) });
		case "chooseFire": return n("games.coltexpress.hintFire", { name: r(e.target) });
		case "chooseRobbery": {
			let r = t.public.players.find((e) => e.rid === t.public.pending?.by), i = r ? (r.roof ? t.public.cars[r.car].roof : t.public.cars[r.car].inside)[e.lootIdx] : void 0;
			return n("games.coltexpress.hintRobbery", { loot: i ? n(i.kind === "purse" ? "games.coltexpress.purse" : i.kind === "gem" ? "games.coltexpress.gem" : "games.coltexpress.strongbox") : "" });
		}
		case "choosePunch": return n("games.coltexpress.hintPunch", { name: r(e.target) });
		default: return "";
	}
}, J = (e, t) => typeof t?.car == "number" ? e.anchor(`car:${t.car}:${t.roof ? "roof" : "in"}`) : null;
function Y(e, t) {
	return typeof t == "string" ? e.anchor(`seat:${t}`) : null;
}
var X = "grid size-8 place-items-center rounded-lg border-2 border-ink bg-surface text-xl shadow-[2px_2px_0_var(--color-ink)]";
function Z(e, t) {
	if (typeof t != "string") return "#8b3b28";
	let n = e.member(t);
	return l[(n?.colorIndex ?? 0) % l.length].hex;
}
var Ln = "ce-card ce-card--fx";
function Rn(e) {
	return {
		x: e.x + e.w / 2 - 20,
		y: e.y + e.h / 2 - 28,
		w: 40,
		h: 56
	};
}
function zn(e) {
	return {
		x: e.x + e.w / 2 - 16,
		y: e.y + e.h / 2 - 16,
		w: 32,
		h: 32
	};
}
function Q(e, t) {
	return typeof t == "string" ? e.anchor(`bandit:${t}`) ?? Y(e, t) : null;
}
function $(e, t, n, r) {
	let i = e.anchor("pile:current");
	return i ? /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f(w, {
			at: i,
			ms: 580
		}),
		r && /* @__PURE__ */ f(C, {
			from: i,
			to: Rn(r),
			ms: 410,
			delay: 70,
			children: /* @__PURE__ */ f(Bn, {
				card: t,
				color: Z(e, n)
			})
		}),
		r && /* @__PURE__ */ f(w, {
			at: r,
			ms: 540,
			delay: 330
		})
	] }) : null;
}
function Bn({ card: e, color: t }) {
	return /* @__PURE__ */ f("span", {
		className: Ln,
		style: { borderTopColor: t },
		children: /* @__PURE__ */ f(_n, { card: e })
	});
}
function Vn({ color: e }) {
	return /* @__PURE__ */ f("span", {
		className: "ce-card--fx-back",
		style: { backgroundColor: e },
		children: /* @__PURE__ */ f("span", {
			className: "ce-card--fx-back__pattern",
			style: { backgroundImage: Zt },
			children: /* @__PURE__ */ f("span", { children: "🂠" })
		})
	});
}
var Hn = {
	deal(e, t) {
		let n = t.anchor("train"), r = Y(t, e.rid);
		if (!n || !r) return null;
		let i = e.data?.count, a = typeof i == "number" ? i : 6, o = {
			x: n.x + n.w / 2 - 20,
			y: n.y + n.h / 2 - 28,
			w: 40,
			h: 56
		}, s = Z(t, e.rid);
		return {
			ms: 320 + a * 50,
			node: Array.from({ length: a }, (e, t) => /* @__PURE__ */ f(C, {
				from: o,
				to: r,
				ms: 320,
				delay: t * 50,
				children: /* @__PURE__ */ f(Vn, { color: s })
			}, t))
		};
	},
	play(e, t) {
		let n = Y(t, e.rid), r = t.anchor("pile:current") ?? t.anchor("pile");
		if (!n || !r) return null;
		let i = e.data, a = e.secret, o = i?.card ?? a?.card, s = o !== void 0 && !(i?.faceDown === !0 && !a), c = Z(t, e.rid);
		return {
			ms: 480,
			node: /* @__PURE__ */ f(C, {
				from: n,
				to: Rn(r),
				ms: 420,
				children: s && o ? /* @__PURE__ */ f(Bn, {
					card: o,
					color: c
				}) : /* @__PURE__ */ f(Vn, { color: c })
			})
		};
	},
	draw(e, t) {
		let n = t.anchor("pile"), r = Y(t, e.rid);
		if (!n || !r) return null;
		let i = e.data?.count, a = typeof i == "number" ? i : 3, o = Z(t, e.rid);
		return {
			ms: 320 + a * 60,
			node: Array.from({ length: a }, (e, t) => /* @__PURE__ */ f(C, {
				from: Rn(n),
				to: r,
				ms: 320,
				delay: t * 60,
				children: /* @__PURE__ */ f(Vn, { color: o })
			}, t))
		};
	},
	stealBegin(e, t) {
		let n = t.anchor("pile:current") ?? t.anchor("pile");
		return n ? {
			ms: k.stealBegin,
			node: /* @__PURE__ */ f(w, {
				at: n,
				ms: 800
			})
		} : null;
	},
	roundStart(e, t) {
		let n = t.anchor("train");
		if (!n) return null;
		let r = e.data?.round;
		return {
			ms: k.deal,
			node: /* @__PURE__ */ f(S, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ p("span", {
					className: "text-2xl",
					children: ["🚂 ", typeof r == "number" ? r : ""]
				})
			})
		};
	},
	execReveal(e, t) {
		let n = t.anchor("pile:current"), r = Q(t, e.rid), i = e.data?.card;
		return n ? {
			ms: k.wait,
			node: /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f(w, {
					at: n,
					ms: 700
				}),
				i && /* @__PURE__ */ f(S, {
					at: n,
					ms: 680,
					children: /* @__PURE__ */ f("span", {
						className: "ce-fx-reveal",
						children: /* @__PURE__ */ f(Bn, {
							card: i,
							color: Z(t, e.rid)
						})
					})
				}),
				r && /* @__PURE__ */ f(w, {
					at: r,
					ms: 650,
					delay: 180
				})
			] })
		} : null;
	},
	execMove: Un("🤠", "move"),
	execFloor: Un("🪜", "floorChange"),
	execMarshal(e, t) {
		let n = e.data, r = typeof n?.from == "number" ? t.anchor(`car:${n.from}:in`) : null, i = typeof n?.to == "number" ? t.anchor(`car:${n.to}:in`) : null;
		if (!r || !i) return null;
		let a = Array.isArray(n?.ejected) ? n.ejected : [];
		return {
			ms: k.exec,
			node: /* @__PURE__ */ p(d, { children: [
				$(t, "marshal", e.rid, r),
				/* @__PURE__ */ f(C, {
					from: r,
					to: i,
					ms: 420,
					delay: 330,
					children: /* @__PURE__ */ f("span", {
						className: X,
						children: "⭐"
					})
				}),
				a.length > 0 && /* @__PURE__ */ f(S, {
					at: i,
					ms: 650,
					delay: 490,
					children: /* @__PURE__ */ p("span", {
						className: "text-lg",
						children: ["🔸×", a.length]
					})
				})
			] })
		};
	},
	execFire(e, t) {
		let n = e.data, r = Q(t, e.rid);
		if (!r) return null;
		if (n?.miss === !0 || typeof n?.target != "string") return {
			ms: k.hit,
			node: /* @__PURE__ */ p(d, { children: [$(t, "fire", e.rid, r), /* @__PURE__ */ f(S, {
				at: r,
				ms: 690,
				delay: 410,
				children: /* @__PURE__ */ f("span", {
					className: "text-xl",
					children: "🔫💨"
				})
			})] })
		};
		let i = Q(t, n.target);
		return {
			ms: k.hit,
			node: /* @__PURE__ */ p(d, { children: [
				$(t, "fire", e.rid, r),
				/* @__PURE__ */ f(S, {
					at: r,
					ms: 600,
					delay: 360,
					children: /* @__PURE__ */ f("span", {
						className: "text-xl",
						children: "🔫"
					})
				}),
				i && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(C, {
					from: r,
					to: i,
					ms: 360,
					delay: 480,
					children: /* @__PURE__ */ f("span", {
						className: X,
						children: "✦"
					})
				}), /* @__PURE__ */ f(S, {
					at: i,
					ms: 570,
					delay: 740,
					children: /* @__PURE__ */ f("span", {
						className: "text-xl",
						children: "💥🔸"
					})
				})] })
			] })
		};
	},
	execRobbery(e, t) {
		let n = e.data, r = J(t, n), i = Y(t, e.rid);
		if (!r || !i) return null;
		let a = e.rid === t.myRid ? t.anchor("stash") : null, o = a ? zn(a) : i, s = n?.lootKind;
		return {
			ms: k.exec,
			node: /* @__PURE__ */ p(d, { children: [
				$(t, "robbery", e.rid, r),
				/* @__PURE__ */ f(C, {
					from: r,
					to: o,
					ms: 460,
					delay: 410,
					children: /* @__PURE__ */ f("span", {
						className: X,
						children: s ? U[s] : "💰"
					})
				}),
				a && /* @__PURE__ */ f(w, {
					at: o,
					ms: 350,
					delay: 630
				})
			] })
		};
	},
	execPunch(e, t) {
		let n = e.data, r = J(t, n?.to), i = typeof n?.to?.car == "number" && typeof n.dir == "number" ? n.to.car - n.dir : null, a = i === null ? Q(t, e.rid) : t.anchor(`car:${i}:${n?.to?.roof ? "roof" : "in"}`);
		if (!a) return null;
		let o = n?.dropped;
		return {
			ms: k.hit,
			node: /* @__PURE__ */ p(d, { children: [
				$(t, "punch", e.rid, a),
				/* @__PURE__ */ f(S, {
					at: a,
					ms: 620,
					delay: 410,
					children: /* @__PURE__ */ f("span", {
						className: "text-xl",
						children: "👊"
					})
				}),
				r && /* @__PURE__ */ f(C, {
					from: a,
					to: r,
					ms: 410,
					delay: 540,
					children: /* @__PURE__ */ f("span", {
						className: X,
						children: "🤠"
					})
				}),
				o && /* @__PURE__ */ f(S, {
					at: a,
					ms: 550,
					delay: 680,
					children: /* @__PURE__ */ f("span", {
						className: "text-lg",
						children: U[o]
					})
				})
			] })
		};
	},
	execFizzle(e, t) {
		let n = Q(t, e.rid);
		if (!n) return null;
		let r = e.data?.card;
		return {
			ms: k.exec,
			node: /* @__PURE__ */ p(d, { children: [r && $(t, r, e.rid, n), /* @__PURE__ */ f(S, {
				at: n,
				ms: 550,
				delay: 390,
				children: /* @__PURE__ */ f("span", {
					className: "text-lg",
					children: "💨"
				})
			})] })
		};
	},
	event(e, t) {
		let n = t.anchor("train");
		if (!n) return null;
		let r = {
			angryMarshal: "😠⭐",
			swivelArm: "🌀",
			braking: "🛑",
			takeItAll: "🧳",
			rebellion: "😡",
			pickpocketing: "🫰",
			marshalsRevenge: "💢",
			hostage: "🤠💰"
		}, i = e.data?.event, a = typeof i == "string" ? r[i] ?? "🚩" : "🚩";
		return {
			ms: k.event,
			node: /* @__PURE__ */ f(S, {
				at: n,
				ms: 1300,
				children: /* @__PURE__ */ f("span", {
					className: "text-3xl",
					children: a
				})
			})
		};
	}
};
function Un(e, t) {
	return (n, r) => {
		let i = n.data, a = J(r, i?.from), o = J(r, i?.to);
		return !a || !o ? null : {
			ms: k.exec,
			node: /* @__PURE__ */ p(d, { children: [$(r, t, n.rid, a), /* @__PURE__ */ f(C, {
				from: a,
				to: o,
				ms: 430,
				delay: 400,
				children: /* @__PURE__ */ f("span", {
					className: X,
					children: e
				})
			})] })
		};
	};
}
//#endregion
//#region src/games/coltexpress/game-over.tsx
function Wn({ result: e, members: t, myRid: n, hintCount: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ f("div", {
		className: "ce-over",
		children: /* @__PURE__ */ f(T, {
			result: e,
			members: t,
			myRid: n,
			accent: E.accent,
			hintCount: r,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/coltexpress/entry.tsx
var Gn = {
	definition: Je,
	View: Xt,
	bot: Fn,
	describe: In,
	fx: Hn,
	OverView: Wn,
	locales: {
		zh: {
			name: "柯尔特快车",
			desc: "编程行动洗劫列车,枪林弹雨里抢最多的钱",
			rules: "目标:五轮抢劫后,战利品总价值最高的匪徒获胜。\n准备:\n· 列车由车头与人数相同的车厢组成;警长和保险箱($1000)在车头。\n· 车厢地板上放有宝石($500)与钱袋($250-$500);钱袋面值只有持有者能看。\n· 每人获得 10 张行动卡、6 颗子弹和 1 个 $250 钱袋。\n流程:每轮分谋划与动手两阶段;回合卡规定本轮回合数与轮末事件。\n· 每轮开始洗混自己的牌库并抽 6 张;未打出的手牌轮末放回牌库。\n· 谋划:从起始玩家开始轮流打出一张行动卡,或从牌库抽 3 张。\n· 隧道回合的牌暗置;加速回合连续行动两次;反转回合逆时针进行。\n· 动手:公共牌堆按打出顺序逐张强制执行,目标在执行时才选定。\n· 移动:位于车内时，移至相邻车厢；位于车顶时，移动1至3节车厢;打出就必须移动。\n· 换层:在同一车厢的车内与车顶之间切换。\n· 警长：将警长移至相邻的1节车厢;其车厢内的匪徒逃上车顶并各获得1张子弹牌。\n· 开枪:位于车内时，只能向相邻车厢内的匪徒开枪；位于车顶时，可以沿视线向任意距离的匪徒开枪。不能向与自己处于同一位置的匪徒开枪。\n· 中弹的匪徒将你的1张子弹牌洗入自己的牌库；抽到手中的子弹牌没有可用效果。\n· 抢劫:拿走所在车厢同层的一件战利品。\n· 殴打:令同位置的匪徒掉一件战利品到地板,并将其推到相邻车厢。\n· 公共子弹共 13 颗,发完即止。\n事件:每轮结束后结算回合卡上的事件。\n· 愤怒警长:车顶的匪徒各获得1张子弹牌,警长向车尾移一节。\n· 旋转臂：将所有位于车顶的匪徒移至车尾车厢的顶部。\n· 刹车:所有车顶的匪徒向车头移一节。\n· 全拿走:第二个保险箱放入警长所在车厢。\n· 乘客反抗:车厢内的匪徒各获得1张子弹牌。\n· 顺手牵羊:独占一处(同车厢同层)的匪徒拿走该处一个钱袋。\n· 警长的报复:警长正上方的匪徒失去自己最便宜的钱袋。\n· 劫持列车长:车头的匪徒各获得$250。\n角色:每人随机扮演一名角色,各有一项能力。\n· 幽灵:每轮自己的第一个回合可暗置打牌。\n· 美女:只要还有其他可选目标,就不能成为开枪或殴打的目标。\n· 神偷:殴打令对方掉出钱袋时,直接据为己有。\n· 穿顶:开枪可以打同一车厢另一层的匪徒。\n· 击退:被其击中的匪徒沿射击方向退一节。\n· 多谋:每轮开始抽 7 张牌而非 6 张。\n结束:\n· 开枪最多者获得 $1000 神枪手奖;并列则各得一份。\n· 战利品总价值最高者获胜;总价值相同时，获得子弹牌数量最少的玩家获胜。",
			phaseScheme: "谋划阶段",
			phaseSteal: "动手阶段",
			phaseDone: "劫案结束",
			roundEnd: "列车劫案结束",
			currentAction: "当前行动",
			roundCard: "回合卡",
			actionPile: "行动牌堆",
			pileCount: "已打出 {{n}} 张",
			engineDirection: "车头方向",
			orbitHint: "拖动环视",
			previousCar: "查看上一节车厢",
			nextCar: "查看下一节车厢",
			trainOverview: "全列车",
			followAction: "跟随行动",
			inspectCurrentCar: "查看 {{n}} 号车厢",
			inspectHint: "点编号或箭头查看车厢",
			inside: "车内",
			wanted: "悬赏",
			waiting: "等待其他匪徒",
			bulletsLabel: "子弹",
			roundShort: "第 {{n}}/{{total}} 轮",
			schemePrompt: "轮到你:打出一张行动卡,或抽 3 张牌",
			schemePromptAgain: "加速回合:再行动一次",
			schemeWaiting: "谋划中,等 {{name}} 行动…",
			stealRunning: "动手!行动卡依次执行…",
			stealWaiting: "等 {{name}} 选择…",
			chooseTitle: "执行「{{card}}」",
			draw: "抽 3 张",
			faceDown: "暗置",
			faceDownAria: "暗置打出",
			actionMove: "移动",
			actionFloorChange: "换层",
			actionMarshal: "警长",
			actionFire: "开枪",
			actionRobbery: "抢劫",
			actionPunch: "殴打",
			actionBullet: "子弹",
			charGhost: "幽灵",
			charBelle: "美女",
			charCheyenne: "神偷",
			charTuco: "穿顶",
			charDjango: "击退",
			charDoc: "多谋",
			turnNormal: "明置",
			turnTunnel: "隧道·暗置",
			turnSpeeding: "加速·两次",
			turnSwitching: "反转·逆时针",
			eventAngryMarshal: "愤怒警长:车顶的匪徒各吃一颗子弹,警长向车尾移一节",
			eventSwivelArm: "旋转臂:车顶的匪徒全部移到车尾顶",
			eventBraking: "刹车:车顶的匪徒向车头移一节",
			eventTakeItAll: "全拿走!第二个保险箱放进警长所在车厢",
			eventRebellion: "乘客反抗:车厢内的匪徒各吃一颗子弹",
			eventPickpocketing: "顺手牵羊:独占一处(同车厢同层)的匪徒拿走该处一个钱袋",
			eventMarshalsRevenge: "警长的报复:警长正上方的匪徒失去自己最便宜的钱袋",
			eventHostage: "劫持列车长:车头的匪徒各获得 $250",
			chooseMove: "往哪移动?",
			chooseMarshal: "警长往哪走?",
			chooseFire: "开枪打谁?",
			chooseRobbery: "抢哪一件?",
			choosePunchTarget: "打谁?",
			choosePunchLoot: "让 TA 掉哪一件?",
			choosePunchDir: "把 TA 推向哪边?",
			dirForward: "向车头",
			dirBackward: "向车尾",
			roofDist: "车顶 {{n}} 节",
			locomotive: "车头",
			carN: "{{n}} 号车厢",
			roof: "车顶",
			purse: "钱袋",
			gem: "宝石",
			strongbox: "保险箱",
			purseAria: "钱袋(面值保密)",
			myLoot: "我的战利品 ${{n}}",
			bulletsAria: "剩 {{n}} 颗子弹",
			firedAria: "已开枪 {{n}} 次",
			takenAria: "吃了 {{n}} 颗子弹",
			neutralLeft: "公共子弹 {{n}}",
			empty: "空无一人",
			hintPlay: "打出「{{card}}」",
			hintPlayFaceDown: "暗置打出「{{card}}」",
			hintDraw: "抽 3 张牌",
			hintMove: "{{dir}}移动 {{n}} 节",
			hintMarshal: "警长{{dir}}移一节",
			hintFire: "开枪打{{name}}",
			hintRobbery: "抢走{{loot}}",
			hintPunch: "殴打{{name}}",
			errNotYourTurn: "现在轮不到你",
			errBadCard: "这张牌不在你手里",
			errBadChoice: "这个选择不合法"
		},
		en: {
			name: "Colt Express",
			desc: "Program your moves, rob the train, dodge the bullets",
			rules: "Goal: after five rounds, the bandit with the most valuable loot wins.\nSetup:\n· The train has a locomotive plus one car per player; the Marshal and a strongbox ($1000) start in the locomotive.\n· Gems ($500) and purses ($250-$500) lie on the car floors; purse values are secret to their owner.\n· Each player takes 10 action cards, 6 bullets and one $250 purse.\nPlay: each round has a Schemin' and a Stealin' phase; the round card sets the turns and an end-of-round event.\n· At the start of each round, shuffle your deck and draw 6 cards; unplayed cards return to the deck.\n· Schemin': starting from the first player, play one action card to the common pile or draw 3 cards.\n· Cards are played face down in tunnel turns; speeding turns give two actions; switching turns run counter-clockwise.\n· Stealin': the pile is executed in the order played; targets are chosen as each card resolves.\n· Move: if inside, move to an adjacent car; if on the roof, move one to three cars. You must move when this action resolves.\n· Floor Change: switch between inside and roof of the same car.\n· Marshal: move the Marshal one car; bandits inside his car flee to the roof and each take a bullet.\n· Fire: from inside, shoot an adjacent car; from the roof, shoot along line of sight; never your own spot.\n· The target takes one of your bullets into their deck; bullets are dead cards when drawn.\n· Robbery: take one loot from your car and floor.\n· Punch: a bandit on your spot drops one loot and is pushed to an adjacent car.\n· The 13 neutral bullets run out for good.\nEvents: resolve the round card's event after each round.\n· Angry Marshal: bandits on roofs take a bullet, then the Marshal moves one car back.\n· Swivel Arm: all bandits on roofs move to the rearmost roof.\n· Braking: all bandits on roofs move one car forward.\n· Take It All: a second strongbox is placed in the Marshal's car.\n· Passengers' Rebellion: bandits inside cars each take a bullet.\n· Pickpocketing: a bandit alone on a spot takes one purse there.\n· Marshal's Revenge: the bandit right above the Marshal loses their cheapest purse.\n· Hostage-Taking: bandits in or on the locomotive each gain $250.\nCharacters: each player randomly plays a character with a special ability.\n· Ghost: may play face down on the first turn of each round.\n· Belle: cannot be targeted by Fire or Punch while another target is available.\n· Cheyenne: when her punch makes a purse drop, she keeps it.\n· Tuco: his Fire can hit a bandit on the other floor of his car.\n· Django: bandits he hits are knocked one car along the shot's direction.\n· Doc: draws 7 cards at the start of each round instead of 6.\nEnd:\n· The bandit who shot the most earns the $1000 Gunslinger award; tied shooters each earn it.\n· The highest loot total wins; ties are broken by the fewest bullets taken.",
			phaseScheme: "Schemin’",
			phaseSteal: "Stealin’",
			phaseDone: "Heist over",
			roundEnd: "The heist is over",
			currentAction: "Current action",
			roundCard: "Round card",
			actionPile: "Action pile",
			pileCount: "{{n}} cards played",
			engineDirection: "Engine ahead",
			orbitHint: "Drag to look around",
			previousCar: "Inspect previous car",
			nextCar: "Inspect next car",
			trainOverview: "Full train",
			followAction: "Follow action",
			inspectCurrentCar: "Inspect car {{n}}",
			inspectHint: "Tap the number or arrows to inspect",
			inside: "Inside",
			wanted: "WANTED",
			waiting: "Waiting for the next move",
			bulletsLabel: "Bullets",
			roundShort: "Round {{n}}/{{total}}",
			schemePrompt: "Your move: play an action card or draw 3",
			schemePromptAgain: "Speeding: take your second action",
			schemeWaiting: "Schemin’ — waiting for {{name}}…",
			stealRunning: "Stealin’! Cards resolve in order…",
			stealWaiting: "Waiting for {{name}} to choose…",
			chooseTitle: "Resolving \"{{card}}\"",
			draw: "Draw 3",
			faceDown: "Face down",
			faceDownAria: "Play face down",
			actionMove: "Move",
			actionFloorChange: "Floor",
			actionMarshal: "Marshal",
			actionFire: "Fire",
			actionRobbery: "Robbery",
			actionPunch: "Punch",
			actionBullet: "Bullet",
			charGhost: "Ghost",
			charBelle: "Belle",
			charCheyenne: "Cheyenne",
			charTuco: "Tuco",
			charDjango: "Django",
			charDoc: "Doc",
			turnNormal: "Face up",
			turnTunnel: "Tunnel · face down",
			turnSpeeding: "Speeding · twice",
			turnSwitching: "Switching · counter-clockwise",
			eventAngryMarshal: "Angry Marshal: all roof bandits take a bullet, Marshal moves one car toward the caboose",
			eventSwivelArm: "Swivel Arm: all roof bandits move to the caboose roof",
			eventBraking: "Braking: roof bandits move one car toward the locomotive",
			eventTakeItAll: "Take It All! A second strongbox enters the Marshal’s car",
			eventRebellion: "Passengers’ Rebellion: bandits inside cars take a neutral bullet",
			eventPickpocketing: "Pickpocketing: anyone alone on a spot (same car, same level) takes a purse there",
			eventMarshalsRevenge: "Marshal’s Revenge: bandits above the Marshal lose their cheapest purse",
			eventHostage: "Hostage-Taking: bandits at the locomotive each gain $250",
			chooseMove: "Move where?",
			chooseMarshal: "Move the Marshal which way?",
			chooseFire: "Shoot whom?",
			chooseRobbery: "Take which loot?",
			choosePunchTarget: "Punch whom?",
			choosePunchLoot: "Make them drop which loot?",
			choosePunchDir: "Push them which way?",
			dirForward: "Toward locomotive",
			dirBackward: "Toward caboose",
			roofDist: "{{n}} car(s) on roof",
			locomotive: "Locomotive",
			carN: "Car {{n}}",
			roof: "Roof",
			purse: "Purse",
			gem: "Gem",
			strongbox: "Strongbox",
			purseAria: "Purse (value hidden)",
			myLoot: "My loot ${{n}}",
			bulletsAria: "{{n}} bullets left",
			firedAria: "Fired {{n}} times",
			takenAria: "Took {{n}} bullets",
			neutralLeft: "Neutral bullets {{n}}",
			empty: "Nobody here",
			hintPlay: "Play \"{{card}}\"",
			hintPlayFaceDown: "Play \"{{card}}\" face down",
			hintDraw: "Draw 3 cards",
			hintMove: "Move {{n}} car(s) {{dir}}",
			hintMarshal: "Move the Marshal {{dir}}",
			hintFire: "Shoot {{name}}",
			hintRobbery: "Rob the {{loot}}",
			hintPunch: "Punch {{name}}",
			errNotYourTurn: "Not your move right now",
			errBadCard: "That card is not in your hand",
			errBadChoice: "That choice is not legal"
		}
	}
};
//#endregion
export { Gn as default };
