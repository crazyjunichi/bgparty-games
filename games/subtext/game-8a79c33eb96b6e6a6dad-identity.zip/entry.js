import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { CANVAS_SIZE as n, PALETTE as r, STROKE_WIDTHS as i, strokeSchema as a } from "@bgparty/sdk/drawing/strokes";
import o from "@bgparty/sdk/word-list";
import { useEffect as s, useState as c } from "react";
import { DrawingPad as l } from "@bgparty/sdk/drawing/canvas";
import { DrawingView as u } from "@bgparty/sdk/drawing/view";
import { useI18nSettings as d, useT as f } from "@bgparty/sdk/i18n";
import { IconCheck as p } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as m } from "@bgparty/sdk/player-colors";
import { PhaseBanner as h } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as g } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as ee, seatName as _ } from "@bgparty/sdk/ui/player-strip";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { GameOverScreen as x } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as S, OptionSection as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/subtext/meta.ts
var w = {
	id: "subtext",
	tier: "released",
	mechanics: ["drawing", "word-association"],
	interactionTags: [],
	nameKey: "games.subtext.name",
	descKey: "games.subtext.desc",
	rulesKey: "games.subtext.rules",
	icon: "💡",
	iconImg: "games/subtext.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/subtext/en.pdf" },
	minPlayers: 4,
	maxPlayers: 8,
	bestPlayers: [6],
	accent: "#f97316",
	releasedAt: "2026-09-17",
	search: {
		py: "hua wai zhi yi",
		init: "hwzy"
	},
	hotseat: "cover"
}, T = t.string(), E = t.int().min(0).max(6), D = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draw"),
		strokes: t.array(a).min(1).max(200)
	}),
	t.object({
		type: t.literal("guess"),
		at: E
	}),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), O = [
	0,
	60,
	90,
	120
], k = t.object({ timeLimitSec: t.union([
	t.literal(0),
	t.literal(60),
	t.literal(90),
	t.literal(120)
]).default(0) }).default({ timeLimitSec: 0 }), A = t.object({ strokes: t.array(a) }), te = A.extend({
	owner: T,
	word: t.string()
}), j = t.object({
	phase: t.enum([
		"draw",
		"guess",
		"reveal",
		"done"
	]),
	round: t.int().min(0),
	totalRounds: t.int().min(1),
	dealer: T,
	players: t.array(T),
	scores: t.record(T, t.int()),
	timeLimitSec: t.int(),
	submitted: t.array(T),
	dealerStrokes: t.array(a).nullable(),
	offers: t.array(A),
	guessed: t.array(T),
	reveal: t.object({
		partner: T,
		dealerWord: t.string(),
		offers: t.array(te),
		guesses: t.record(T, E),
		deltas: t.record(T, t.int())
	}).nullable()
}), M = t.object({
	word: t.string(),
	mySubmitted: t.boolean(),
	myGuess: E.nullable()
}), N = o, P = (e) => e <= 5 ? 2 * e : e;
function F(t, n, r) {
	let i = [...r];
	for (let r = i.length - 1; r > 0; --r) {
		let a = e(t, n, r + 1);
		n += 1;
		let o = i[r];
		i[r] = i[a], i[a] = o;
	}
	return {
		out: i,
		cursor: n
	};
}
function I(t, n, r) {
	let i = n.length, a = P(i), o = F(r, 0, N), s = o.cursor, c = 0, l = [];
	for (let t = 0; t < a; t += 1) {
		let a = n[t % i], u = n.filter((e) => e !== a), d = u[e(r, s, u.length)];
		s += 1;
		let f = o.out[c];
		c += 1;
		let p = {
			[a]: f,
			[d]: f
		};
		for (let e of u) e !== d && (p[e] = o.out[c], c += 1);
		let m = F(r, s, u);
		s = m.cursor, l.push({
			dealer: a,
			partner: d,
			words: p,
			offerOrder: m.out
		});
	}
	return { state: {
		players: [...n],
		totalRounds: a,
		round: 0,
		phase: "draw",
		rounds: l,
		drawings: {},
		guesses: {},
		scores: Object.fromEntries(n.map((e) => [e, 0])),
		deltas: {},
		phaseStartedAt: null,
		config: t
	} };
}
var L = (e) => e.rounds[e.round];
function R(e) {
	let t = L(e), n = t.offerOrder.indexOf(t.partner), r = (t) => e.guesses[t] === n, i = e.players.filter((e) => !r(e)).length, a = {};
	for (let n of e.players) {
		let o = 0;
		r(n) && (n === t.dealer || n === t.partner ? r(t.dealer) && r(t.partner) && (o = i) : o = i + 1), a[n] = o, e.scores[n] += o;
	}
	e.deltas = a, e.phase = "reveal", e.phaseStartedAt = null;
}
function z(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "draw" && e.phase !== "guess" || e.config.timeLimitSec === 0) return { state: e };
		if (e.phaseStartedAt === null) {
			let n = structuredClone(e);
			return n.phaseStartedAt = t.now, { state: n };
		}
		if (t.now - e.phaseStartedAt < e.config.timeLimitSec * 1e3) return { state: e };
		let n = structuredClone(e);
		if (n.phase === "draw") {
			for (let e of n.players) e in n.drawings || (n.drawings[e] = []);
			return n.phase = "guess", n.phaseStartedAt = null, { state: n };
		}
		return R(n), { state: n };
	}
	if (t.type === "draw") {
		if (e.phase !== "draw") return { code: "games.subtext.errNotDrawing" };
		if (n.by in e.drawings) return { code: "games.subtext.errAlreadySubmitted" };
		let r = structuredClone(e);
		return r.drawings[n.by] = t.strokes, r.players.every((e) => e in r.drawings) && (r.phase = "guess", r.phaseStartedAt = null), { state: r };
	}
	if (t.type === "guess") {
		if (e.phase !== "guess") return { code: "games.subtext.errNotGuessing" };
		if (n.by in e.guesses) return { code: "games.subtext.errAlreadySubmitted" };
		if (t.at >= L(e).offerOrder.length) return { code: "games.subtext.errBadOffer" };
		let r = structuredClone(e);
		return r.guesses[n.by] = t.at, r.players.every((e) => e in r.guesses) && R(r), { state: r };
	}
	if (e.phase !== "reveal") return { code: "games.subtext.errNotReveal" };
	let r = L(e);
	if (n.by !== r.dealer && n.by !== e.players[0]) return { code: "games.subtext.errNotDealer" };
	let i = structuredClone(e);
	return i.round + 1 >= i.totalRounds ? (i.phase = "done", { state: i }) : (i.round += 1, i.phase = "draw", i.drawings = {}, i.guesses = {}, i.deltas = {}, i.phaseStartedAt = null, { state: i });
}
function B(e, t) {
	let n = L(e), r = e.phase === "reveal" || e.phase === "done", i = e.phase !== "draw", a = {
		phase: e.phase,
		round: e.round,
		totalRounds: e.totalRounds,
		dealer: n.dealer,
		players: [...e.players],
		scores: { ...e.scores },
		timeLimitSec: e.config.timeLimitSec,
		submitted: Object.keys(e.drawings),
		dealerStrokes: i ? e.drawings[n.dealer] ?? [] : null,
		offers: i ? n.offerOrder.map((t) => ({ strokes: e.drawings[t] ?? [] })) : [],
		guessed: Object.keys(e.guesses),
		reveal: r ? {
			partner: n.partner,
			dealerWord: n.words[n.dealer],
			offers: n.offerOrder.map((t) => ({
				strokes: e.drawings[t] ?? [],
				owner: t,
				word: n.words[t]
			})),
			guesses: { ...e.guesses },
			deltas: { ...e.deltas }
		} : null
	};
	return r ? { public: a } : {
		public: a,
		private: {
			word: n.words[t],
			mySubmitted: t in e.drawings,
			myGuess: e.guesses[t] ?? null
		}
	};
}
function V(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.scores[t] === n),
		ranking: t,
		scores: { ...e.scores }
	};
}
function H(e, t) {
	return e.phase !== "draw" && e.phase !== "guess" || e.config.timeLimitSec === 0 ? null : e.phaseStartedAt === null ? 0 : e.phaseStartedAt + e.config.timeLimitSec * 1e3 - t;
}
var U = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: w,
	schemas: {
		action: D,
		publicView: j,
		privateView: M,
		config: k
	},
	setup: I,
	reduce: z,
	viewFor: B,
	status: V,
	nextTickIn: H
};
//#endregion
//#region src/games/subtext/view-player.tsx
function W(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ y(K, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var G = (e) => String.fromCharCode(65 + e);
function K({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let a = f(), o = d((e) => e.locale), s = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? _(t, o) : e;
	}, c = e.players.map((e) => n.find((t) => t.rid === e)).filter((e) => e !== void 0), l = e.phase === "draw" ? e.submitted : e.phase === "guess" ? e.guessed : e.players, u = e.dealer === r, p, m;
	if (e.phase === "draw") {
		let n = t?.mySubmitted ?? !1;
		p = n ? "info" : "accent", m = n ? a("games.subtext.waitingDraw", {
			n: e.submitted.length,
			total: e.players.length
		}) : a(u ? "games.subtext.drawPromptDealer" : "games.subtext.drawPrompt");
	} else if (e.phase === "guess") {
		let n = t?.myGuess != null;
		p = n ? "info" : "accent", m = n ? a("games.subtext.waitingGuess", {
			n: e.guessed.length,
			total: e.players.length
		}) : a("games.subtext.guessPrompt");
	} else p = "done", m = a("games.subtext.revealTitle");
	let g = /* @__PURE__ */ b("div", {
		className: "subtext-banner",
		children: [/* @__PURE__ */ y(h, {
			tone: p,
			text: m,
			chip: a("games.subtext.roundShort", {
				n: e.round + 1,
				total: e.totalRounds
			}),
			accent: w.accent
		}), /* @__PURE__ */ b("div", {
			className: "subtext-player-row",
			children: [/* @__PURE__ */ y("div", {
				className: "min-w-0 flex-1",
				children: /* @__PURE__ */ y(ee, {
					variant: "mini",
					scroll: !0,
					adaptive: !0,
					members: c,
					myRid: r,
					status: (t) => /* @__PURE__ */ b("span", {
						className: "subtext-score font-mono font-extrabold tabular-nums",
						children: [e.scores[t] ?? 0, (e.phase === "reveal" || e.phase === "done") && e.reveal && (e.reveal.deltas[t] ?? 0) > 0 && /* @__PURE__ */ y("span", {
							className: "text-done-ink",
							children: a("games.subtext.deltaPlus", { n: e.reveal.deltas[t] })
						})]
					}),
					action: (e) => l.includes(e) ? "done" : "pending"
				})
			}), e.timeLimitSec > 0 && (e.phase === "draw" || e.phase === "guess") && /* @__PURE__ */ y(J, { limitSec: e.timeLimitSec }, `${e.round}-${e.phase}`)]
		})]
	});
	return e.phase === "draw" && t ? /* @__PURE__ */ y(Y, {
		banner: g,
		word: t.word,
		mySubmitted: t.mySubmitted,
		send: i
	}, e.round) : e.phase === "guess" && t ? /* @__PURE__ */ y(X, {
		banner: g,
		pub: e,
		priv: t,
		send: i
	}, `g${e.round}`) : (e.phase === "reveal" || e.phase === "done") && e.reveal ? /* @__PURE__ */ y(Z, {
		banner: g,
		pub: e,
		members: n,
		nameOf: s,
		iAmDealer: u,
		isHost: e.players[0] === r,
		send: i
	}) : /* @__PURE__ */ y(q, {
		banner: g,
		children: null
	});
}
function q({ banner: e, actions: t, children: n }) {
	return /* @__PURE__ */ y("div", {
		className: "subtext-root",
		style: { "--subtext-accent": w.accent },
		children: /* @__PURE__ */ y(g, {
			adaptive: !0,
			scroll: !1,
			className: "subtext-screen",
			banner: e,
			actionsHeight: "subtext-action-height",
			actions: /* @__PURE__ */ y("div", {
				className: "subtext-actions",
				children: t
			}),
			children: n
		})
	});
}
function J({ limitSec: e }) {
	let [t, n] = c(e);
	return s(() => {
		let e = window.setInterval(() => n((e) => Math.max(0, e - 1)), 1e3);
		return () => window.clearInterval(e);
	}, []), /* @__PURE__ */ b("span", {
		className: `subtext-countdown flex flex-none items-center rounded-xl border-2 border-ink font-mono font-extrabold tabular-nums ${t <= 10 ? "bg-warn-soft text-warn-ink" : "bg-surface"}`,
		children: ["⏱", t]
	});
}
function Y({ banner: e, word: t, mySubmitted: n, send: r }) {
	let i = f(), [a, o] = c([]);
	return /* @__PURE__ */ y(q, {
		banner: e,
		actions: !n && /* @__PURE__ */ y("button", {
			className: "btn-base subtext-primary disabled:opacity-40",
			disabled: a.length === 0,
			onClick: () => r({
				type: "draw",
				strokes: a
			}),
			children: i("games.subtext.submit")
		}),
		children: /* @__PURE__ */ b("div", {
			className: "subtext-draw-layout",
			children: [/* @__PURE__ */ b("div", {
				className: "frame subtext-word",
				children: [/* @__PURE__ */ y("span", { children: i("games.subtext.yourWord") }), /* @__PURE__ */ y("strong", {
					className: "font-display",
					children: t
				})]
			}), /* @__PURE__ */ y("div", {
				className: "subtext-draw-stage",
				children: /* @__PURE__ */ y("div", {
					className: "subtext-drawing-pad",
					children: n ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("div", {
						className: "frame subtext-submitted-paper",
						children: /* @__PURE__ */ y(u, {
							strokes: a,
							className: "h-full w-full rounded-lg bg-white"
						})
					}), /* @__PURE__ */ y("div", {
						className: "subtext-tool-placeholder",
						"aria-hidden": !0
					})] }) : /* @__PURE__ */ y(l, {
						value: a,
						onChange: o
					})
				})
			})]
		})
	});
}
function X({ banner: e, pub: t, priv: n, send: r }) {
	let i = f(), [a, o] = c(null), s = n.myGuess, l = s != null;
	return /* @__PURE__ */ y(q, {
		banner: e,
		actions: !l && /* @__PURE__ */ y("button", {
			className: "btn-base subtext-primary disabled:opacity-40",
			disabled: a === null,
			onClick: () => a !== null && r({
				type: "guess",
				at: a
			}),
			children: a === null ? i("games.subtext.submit") : i("games.subtext.submitGuess", { letter: G(a) })
		}),
		children: /* @__PURE__ */ y("div", {
			className: "subtext-gallery-scroll",
			children: /* @__PURE__ */ b("div", {
				className: "subtext-guess-layout",
				children: [/* @__PURE__ */ b("section", {
					className: "frame subtext-reference",
					children: [/* @__PURE__ */ y("h2", {
						className: "subtext-reference-title",
						children: i("games.subtext.dealerDrawing")
					}), /* @__PURE__ */ y(Q, { strokes: t.dealerStrokes ?? [] })]
				}), /* @__PURE__ */ y("div", {
					className: "subtext-offers",
					children: t.offers.map((e, t) => {
						let n = l ? s === t : a === t;
						return /* @__PURE__ */ b("button", {
							type: "button",
							disabled: l,
							"aria-label": i("games.subtext.submitGuess", { letter: G(t) }),
							"aria-pressed": n,
							onClick: () => o(t),
							className: "subtext-offer",
							"data-selected": n,
							children: [
								/* @__PURE__ */ y("span", {
									className: "subtext-letter font-mono",
									children: G(t)
								}),
								n && /* @__PURE__ */ y("span", {
									className: "subtext-selection",
									children: /* @__PURE__ */ y(p, { "aria-hidden": !0 })
								}),
								/* @__PURE__ */ y(Q, { strokes: e.strokes })
							]
						}, t);
					})
				})]
			})
		})
	});
}
function Z({ banner: e, pub: t, members: n, nameOf: r, iAmDealer: i, isHost: a, send: o }) {
	let s = f(), c = t.reveal;
	if (!c) return null;
	let l = /* @__PURE__ */ new Map();
	for (let [e, t] of Object.entries(c.guesses)) {
		let n = l.get(t) ?? [];
		n.push(e), l.set(t, n);
	}
	let u = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? m[t.colorIndex % m.length].hex : "#57534e";
	}, d = c.offers.findIndex((e) => e.owner === c.partner), h = i || a;
	return /* @__PURE__ */ y(q, {
		banner: e,
		actions: t.phase === "reveal" && (h ? /* @__PURE__ */ y("button", {
			className: "btn-base subtext-primary",
			onClick: () => o({ type: "next" }),
			children: s("games.subtext.nextRound")
		}) : /* @__PURE__ */ y("p", {
			className: "subtext-wait",
			children: s("games.subtext.waitingNext")
		})),
		children: /* @__PURE__ */ b("div", {
			className: "subtext-gallery-scroll",
			children: [/* @__PURE__ */ y("p", {
				className: "plate subtext-partner",
				children: s("games.subtext.partnerWas", { name: r(c.partner) })
			}), /* @__PURE__ */ b("div", {
				className: "subtext-reveal-gallery",
				children: [/* @__PURE__ */ b("div", {
					className: "subtext-revealed-paper",
					"data-dealer": "true",
					children: [
						/* @__PURE__ */ y("span", {
							className: "subtext-dealer-label",
							children: s("games.subtext.dealerDrawing")
						}),
						/* @__PURE__ */ y(Q, { strokes: t.dealerStrokes ?? [] }),
						/* @__PURE__ */ b("div", {
							className: "subtext-paper-info",
							children: [/* @__PURE__ */ y("strong", { children: r(t.dealer) }), /* @__PURE__ */ y("span", { children: c.dealerWord })]
						})
					]
				}), c.offers.map((e, t) => {
					let n = t === d;
					return /* @__PURE__ */ b("div", {
						className: "subtext-revealed-paper",
						"data-partner": n,
						children: [
							/* @__PURE__ */ y("span", {
								className: "subtext-letter font-mono",
								children: G(t)
							}),
							n && /* @__PURE__ */ y("span", {
								className: "subtext-partner-mark",
								children: /* @__PURE__ */ y(p, { "aria-hidden": !0 })
							}),
							/* @__PURE__ */ y(Q, { strokes: e.strokes }),
							/* @__PURE__ */ b("div", {
								className: "subtext-paper-info",
								children: [
									/* @__PURE__ */ y("strong", { children: r(e.owner) }),
									/* @__PURE__ */ y("span", { children: e.word }),
									/* @__PURE__ */ y("span", {
										className: "subtext-guessers",
										children: (l.get(t) ?? []).map((e) => /* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y("i", {
											"aria-hidden": !0,
											style: { backgroundColor: u(e) }
										}), r(e)] }, e))
									})
								]
							})
						]
					}, t);
				})]
			})]
		})
	});
}
function Q({ strokes: e }) {
	let t = f();
	return /* @__PURE__ */ y("div", {
		className: "subtext-paper",
		children: e.length > 0 ? /* @__PURE__ */ y(u, {
			strokes: e,
			className: "h-full w-full"
		}) : /* @__PURE__ */ y("span", { children: t("games.subtext.blankDrawing") })
	});
}
//#endregion
//#region src/games/subtext/bot.ts
var $ = (e) => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
function ne() {
	let e = [], t = 1 + $(3);
	for (let a = 0; a < t; a += 1) {
		let t = [], a = 200 + $(600), o = 200 + $(600);
		t.push(a, o);
		let s = 4 + $(8);
		for (let e = 0; e < s; e += 1) a = Math.max(0, Math.min(n, a + $(301) - 150)), o = Math.max(0, Math.min(n, o + $(301) - 150)), t.push(a, o);
		e.push({
			c: $(r.length),
			w: $(i.length),
			pts: t
		});
	}
	return e;
}
var re = (e) => {
	let t = e.private;
	return t ? e.public.phase === "draw" && !t.mySubmitted ? { action: {
		type: "draw",
		strokes: ne()
	} } : e.public.phase === "guess" && t.myGuess === null ? { action: {
		type: "guess",
		at: $(e.public.offers.length)
	} } : null : null;
};
//#endregion
//#region src/games/subtext/game-over.tsx
function ie({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ y("div", {
		className: "subtext-over",
		children: /* @__PURE__ */ y(x, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: w.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region src/games/subtext/options.tsx
function ae({ value: e, onChange: t }) {
	let n = f(), r = k.safeParse(e), i = r.success ? r.data : k.parse(void 0);
	return /* @__PURE__ */ y("div", {
		className: "flex flex-col gap-2",
		children: /* @__PURE__ */ y(C, {
			title: n("games.subtext.optTimeLimit"),
			children: O.map((e) => /* @__PURE__ */ y(S, {
				name: "subtext-time-limit",
				value: String(e),
				checked: i.timeLimitSec === e,
				label: e === 0 ? n("games.subtext.optOff") : n("games.subtext.optSec", { n: e }),
				accent: w.accent,
				onChange: () => t({ timeLimitSec: e })
			}, e))
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/subtext/entry.tsx
var oe = {
	definition: U,
	View: W,
	bot: re,
	OverView: ie,
	Options: ae,
	locales: {
		zh: {
			name: "画外之意",
			desc: "画得刚好让搭档看懂:太直白人人得分,太隐晦搭档也猜不到",
			rules: "目标:通过画画暗示词语得分,总分最高者获胜。\n流程:\n· 每轮一人当庄家。庄家与一名随机搭档拿到同一个词,其余人各拿不同的词。\n· 搭档是谁,连庄家也不知道。\n· 所有人同时画出自己的词(不能写字母或数字)。\n· 画作公示:庄家的画单独展示,其余人的画打乱后标上字母;所有人(含庄家)猜哪幅画与庄家同词。\n计分:\n· 只有庄家与搭档均猜对时，两人才获得分数；两人各自获得的分数，等于猜错的玩家人数。\n· 其他玩家猜对时，获得的分数等于猜错的玩家人数加1；猜错时不得分。\n· 所有人均猜对时，庄家与搭档不得分；搭档未能猜对时，两人也不得分。\n结束:\n· 4–5 人局每人当 2 次庄家,6–8 人局每人当 1 次。\n· 全部规定轮次结束后，总分最高的玩家获胜；总分相同时，共同获胜。",
			roundShort: "{{n}}/{{total}}",
			drawPrompt: "画出你的词",
			drawPromptDealer: "你是庄家,画出你的词",
			guessPrompt: "哪幅画与庄家同词?",
			waitingDraw: "已提交,等其他人画完 {{n}}/{{total}}…",
			waitingGuess: "已提交,等其他人猜完 {{n}}/{{total}}…",
			submit: "提交",
			submitGuess: "确定选 {{letter}}",
			dealerDrawing: "庄家的画",
			yourWord: "你的词",
			blankDrawing: "(超时没画)",
			revealTitle: "揭晓",
			partnerWas: "搭档是 {{name}}",
			deltaPlus: "+{{n}}",
			nextRound: "下一轮",
			waitingNext: "等庄家或主机开始下一轮…",
			optTimeLimit: "每阶段限时",
			optOff: "不限时",
			optSec: "{{n}} 秒",
			errNotDrawing: "现在不是作画阶段",
			errNotGuessing: "现在不是猜测阶段",
			errAlreadySubmitted: "本轮已提交",
			errBadOffer: "没有这幅画",
			errNotReveal: "现在不能开下一轮",
			errNotDealer: "只有庄家或主机能开下一轮"
		},
		en: {
			name: "Subtext",
			desc: "Draw so only your secret partner gets it — too obvious and everyone scores",
			rules: "Goal: score by hinting at words with drawings; the highest total wins.\nPlay:\n· Each round one player is the dealer. The dealer and one random partner get the same word; everyone else gets a different word.\n· Nobody — not even the dealer — knows who the partner is.\n· Everyone draws their word at the same time (no letters or numbers allowed).\n· Then the drawings are revealed: the dealer's drawing stands alone, the rest are shuffled and lettered; everyone (including the dealer) guesses which drawing shares the dealer's word.\nScoring:\n· The dealer and the partner score only if BOTH guessed right: each gets 1 point per wrong guess.\n· Any other player who guessed right gets 1 point per wrong guess plus 1 bonus point; a wrong guess scores nothing.\n· If everyone guesses correctly, the dealer and partner score nothing. They also score nothing if the partner guesses incorrectly.\nEnd:\n· With 4–5 players everyone deals twice, with 6–8 everyone deals once.\n· After all rounds the highest total wins, and tied players share the win.",
			roundShort: "{{n}}/{{total}}",
			drawPrompt: "Draw your word",
			drawPromptDealer: "You are the dealer — draw your word",
			guessPrompt: "Which drawing shares the dealer's word?",
			waitingDraw: "Submitted — waiting for drawings {{n}}/{{total}}…",
			waitingGuess: "Submitted — waiting for guesses {{n}}/{{total}}…",
			submit: "Submit",
			submitGuess: "Pick {{letter}}",
			dealerDrawing: "Dealer's drawing",
			yourWord: "Your word",
			blankDrawing: "(timed out, blank)",
			revealTitle: "Reveal",
			partnerWas: "The partner was {{name}}",
			deltaPlus: "+{{n}}",
			nextRound: "Next round",
			waitingNext: "Waiting for the dealer or host to start the next round…",
			optTimeLimit: "Phase timer",
			optOff: "Off",
			optSec: "{{n}}s",
			errNotDrawing: "Not the drawing phase",
			errNotGuessing: "Not the guessing phase",
			errAlreadySubmitted: "Already submitted this round",
			errBadOffer: "No such drawing",
			errNotReveal: "Cannot start the next round yet",
			errNotDealer: "Only the dealer or host can start the next round"
		}
	}
};
//#endregion
export { oe as default };
