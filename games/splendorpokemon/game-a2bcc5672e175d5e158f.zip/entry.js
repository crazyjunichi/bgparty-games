import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { useWakeLock as l } from "@bgparty/sdk/use-wake-lock";
import { AVATARS as u } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { isBotRid as f } from "@bgparty/sdk/lobby";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { Floater as v, FlySprite as y } from "@bgparty/sdk/fx/primitives";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
import { seatName as x } from "@bgparty/sdk/ui/player-strip";
import { OptionRadio as S, OptionSection as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/splendorpokemon/cards.ts
var w = [
	"poke",
	"great",
	"ultra",
	"heal",
	"quick"
], T = [
	[
		"nidoran",
		"nidorina",
		"nidoqueen"
	],
	[
		"gastly",
		"haunter",
		"gengar"
	],
	[
		"bulbasaur",
		"ivysaur",
		"venusaur"
	],
	[
		"pidgey",
		"pidgeotto",
		"pidgeot"
	],
	[
		"geodude",
		"graveler",
		"golem"
	],
	[
		"charmander",
		"charmeleon",
		"charizard"
	],
	[
		"oddish",
		"gloom",
		"vileplume"
	],
	[
		"weedle",
		"kakuna",
		"beedrill"
	],
	[
		"dratini",
		"dragonair",
		"dragonite"
	],
	[
		"bellsprout",
		"weepinbell",
		"victreebel"
	],
	[
		"machop",
		"machoke",
		"machamp"
	],
	[
		"squirtle",
		"wartortle",
		"blastoise"
	],
	[
		"poliwag",
		"poliwhirl",
		"poliwrath"
	],
	[
		"caterpie",
		"metapod",
		"butterfree"
	],
	[
		"abra",
		"kadabra",
		"alakazam"
	]
], E = (e) => `games.splendorpokemon.card.${e}`;
function D(e, t, n, r, i, a, o) {
	return {
		id: e,
		nameKey: E(T[t][n - 1]),
		chain: t,
		stage: n,
		tier: n,
		points: r,
		bonus: i,
		bonusCount: 1,
		evolve: a ? {
			color: a[0],
			count: a[1]
		} : null,
		cost: o,
		masterCost: 0
	};
}
function O(e, t, n, r, i, a, o) {
	return {
		id: e,
		nameKey: E(t),
		chain: -1,
		stage: 0,
		tier: n,
		points: r,
		bonus: i,
		bonusCount: 2,
		evolve: null,
		cost: a,
		masterCost: 1,
		altOf: o
	};
}
var k = [
	D("dratini-a", 8, 1, 1, "ultra", ["great", 3], {
		quick: 3,
		poke: 2
	}),
	D("dratini-b", 8, 1, 1, "ultra", ["great", 3], { ultra: 4 }),
	D("oddish-a", 6, 1, 1, "ultra", ["quick", 2], {
		heal: 2,
		poke: 1
	}),
	D("oddish-b", 6, 1, 0, "ultra", ["quick", 2], {
		quick: 2,
		ultra: 2
	}),
	D("oddish-c", 6, 1, 0, "ultra", ["quick", 2], { great: 3 }),
	D("weedle-a", 7, 1, 0, "ultra", ["poke", 3], {
		poke: 1,
		quick: 1,
		heal: 1,
		great: 1
	}),
	D("weedle-b", 7, 1, 0, "ultra", ["poke", 3], {
		great: 2,
		poke: 1,
		heal: 1
	}),
	D("charmander-a", 5, 1, 1, "great", ["quick", 3], {
		ultra: 3,
		heal: 2
	}),
	D("charmander-b", 5, 1, 0, "great", ["quick", 3], { great: 4 }),
	D("pidgey-a", 3, 1, 0, "great", ["poke", 2], {
		quick: 2,
		ultra: 1
	}),
	D("pidgey-b", 3, 1, 0, "great", ["poke", 2], {
		great: 2,
		poke: 2
	}),
	D("pidgey-c", 3, 1, 0, "great", ["poke", 2], { heal: 3 }),
	D("abra-a", 14, 1, 1, "heal", ["poke", 3], {
		great: 3,
		quick: 2
	}),
	D("abra-b", 14, 1, 0, "heal", ["poke", 3], { heal: 4 }),
	D("caterpie-a", 13, 1, 0, "heal", ["great", 3], {
		great: 1,
		quick: 1,
		poke: 1,
		ultra: 1
	}),
	D("caterpie-b", 13, 1, 0, "heal", ["great", 3], {
		ultra: 2,
		great: 1,
		quick: 1
	}),
	D("poliwag-a", 12, 1, 0, "heal", ["ultra", 2], {
		great: 2,
		quick: 1
	}),
	D("poliwag-b", 12, 1, 0, "heal", ["ultra", 2], {
		heal: 2,
		ultra: 2
	}),
	D("poliwag-c", 12, 1, 0, "heal", ["ultra", 2], { poke: 3 }),
	D("bellsprout-a", 9, 1, 0, "poke", ["heal", 2], {
		ultra: 2,
		great: 1
	}),
	D("bellsprout-b", 9, 1, 0, "poke", ["heal", 2], {
		heal: 2,
		poke: 2
	}),
	D("bellsprout-c", 9, 1, 0, "poke", ["heal", 2], { quick: 3 }),
	D("machop-a", 10, 1, 0, "poke", ["quick", 3], {
		great: 1,
		quick: 1,
		heal: 1,
		ultra: 1
	}),
	D("machop-b", 10, 1, 0, "poke", ["quick", 3], {
		quick: 2,
		heal: 1,
		ultra: 1
	}),
	D("squirtle-a", 11, 1, 1, "poke", ["ultra", 3], {
		heal: 3,
		great: 2
	}),
	D("squirtle-b", 11, 1, 1, "poke", ["ultra", 3], { poke: 4 }),
	D("bulbasaur-a", 2, 1, 1, "quick", ["heal", 3], {
		poke: 3,
		ultra: 2
	}),
	D("bulbasaur-b", 2, 1, 0, "quick", ["heal", 3], { quick: 4 }),
	D("gastly-a", 1, 1, 0, "quick", ["ultra", 3], {
		great: 1,
		poke: 1,
		heal: 1,
		ultra: 1
	}),
	D("gastly-b", 1, 1, 0, "quick", ["ultra", 3], {
		heal: 2,
		ultra: 1,
		poke: 1
	}),
	D("nidoran-a", 0, 1, 0, "quick", ["great", 2], {
		poke: 2,
		heal: 1
	}),
	D("nidoran-b", 0, 1, 0, "quick", ["great", 2], {
		great: 2,
		quick: 2
	}),
	D("nidoran-c", 0, 1, 0, "quick", ["great", 2], { ultra: 3 }),
	D("geodude-a", 4, 1, 0, "great", ["heal", 3], {
		ultra: 1,
		quick: 1,
		heal: 1,
		poke: 1
	}),
	D("geodude-b", 4, 1, 0, "great", ["heal", 3], {
		poke: 2,
		quick: 1,
		great: 1
	}),
	D("dragonair-a", 8, 2, 3, "ultra", ["quick", 4], {
		great: 4,
		heal: 4,
		quick: 1
	}),
	D("dragonair-b", 8, 2, 3, "ultra", ["quick", 4], { ultra: 6 }),
	D("gloom-a", 6, 2, 1, "ultra", ["quick", 4], {
		quick: 3,
		great: 2,
		poke: 2
	}),
	D("gloom-b", 6, 2, 1, "ultra", ["quick", 4], {
		ultra: 3,
		great: 2,
		poke: 2
	}),
	D("kakuna-a", 7, 2, 2, "ultra", ["heal", 3], {
		poke: 4,
		great: 2,
		heal: 1
	}),
	D("kakuna-b", 7, 2, 2, "ultra", ["heal", 3], {
		ultra: 5,
		quick: 2
	}),
	D("charmeleon-a", 5, 2, 3, "great", ["poke", 4], {
		quick: 4,
		ultra: 4,
		poke: 1
	}),
	D("charmeleon-b", 5, 2, 3, "great", ["poke", 4], { great: 6 }),
	D("pidgeotto-a", 3, 2, 1, "great", ["poke", 4], {
		poke: 3,
		quick: 2,
		heal: 2
	}),
	D("pidgeotto-b", 3, 2, 1, "great", ["poke", 4], {
		great: 3,
		heal: 2,
		ultra: 2
	}),
	D("kadabra-a", 14, 2, 3, "heal", ["ultra", 4], {
		poke: 4,
		quick: 4,
		ultra: 1
	}),
	D("kadabra-b", 14, 2, 3, "heal", ["ultra", 4], { heal: 6 }),
	D("metapod-a", 13, 2, 2, "heal", ["quick", 3], {
		great: 4,
		poke: 2,
		quick: 1
	}),
	D("metapod-b", 13, 2, 2, "heal", ["quick", 3], {
		heal: 5,
		ultra: 2
	}),
	D("poliwhirl-a", 12, 2, 1, "heal", ["ultra", 4], {
		ultra: 3,
		great: 2,
		poke: 2
	}),
	D("poliwhirl-b", 12, 2, 1, "heal", ["ultra", 4], {
		heal: 3,
		great: 2,
		quick: 2
	}),
	D("machoke-a", 10, 2, 2, "poke", ["great", 3], {
		quick: 4,
		ultra: 2,
		great: 1
	}),
	D("machoke-b", 10, 2, 2, "poke", ["great", 3], {
		poke: 5,
		heal: 2
	}),
	D("wartortle-a", 11, 2, 3, "poke", ["heal", 4], {
		great: 4,
		ultra: 4,
		heal: 1
	}),
	D("wartortle-b", 11, 2, 3, "poke", ["heal", 4], { poke: 6 }),
	D("weepinbell-a", 9, 2, 1, "poke", ["heal", 4], {
		heal: 3,
		quick: 2,
		ultra: 2
	}),
	D("weepinbell-b", 9, 2, 1, "poke", ["heal", 4], {
		poke: 3,
		ultra: 2,
		quick: 2
	}),
	D("haunter-a", 1, 2, 2, "quick", ["poke", 3], {
		ultra: 4,
		heal: 2,
		poke: 1
	}),
	D("haunter-b", 1, 2, 2, "quick", ["poke", 3], {
		quick: 5,
		great: 2
	}),
	D("ivysaur-a", 2, 2, 3, "quick", ["great", 4], {
		poke: 4,
		heal: 4,
		great: 1
	}),
	D("ivysaur-b", 2, 2, 3, "quick", ["great", 4], { quick: 6 }),
	D("nidorina-a", 0, 2, 1, "quick", ["great", 4], {
		great: 3,
		heal: 2,
		ultra: 2
	}),
	D("nidorina-b", 0, 2, 1, "quick", ["great", 4], {
		quick: 3,
		heal: 2,
		poke: 2
	}),
	D("graveler-a", 4, 2, 2, "great", ["ultra", 3], {
		heal: 4,
		quick: 2,
		ultra: 1
	}),
	D("graveler-b", 4, 2, 2, "great", ["ultra", 3], {
		great: 5,
		poke: 2
	}),
	D("dragonite", 8, 3, 5, "ultra", null, {
		heal: 7,
		great: 3
	}),
	D("beedrill", 7, 3, 4, "ultra", null, {
		poke: 6,
		quick: 4
	}),
	D("vileplume", 6, 3, 3, "ultra", null, {
		ultra: 5,
		great: 2,
		heal: 2
	}),
	D("charizard", 5, 3, 5, "great", null, {
		ultra: 7,
		quick: 3
	}),
	D("golem", 4, 3, 4, "great", null, {
		heal: 6,
		poke: 4
	}),
	D("pidgeot", 3, 3, 3, "great", null, {
		great: 5,
		ultra: 2,
		quick: 2
	}),
	D("alakazam", 14, 3, 5, "heal", null, {
		quick: 7,
		poke: 3
	}),
	D("butterfree", 13, 3, 4, "heal", null, {
		great: 6,
		ultra: 4
	}),
	D("poliwrath", 12, 3, 3, "heal", null, {
		heal: 5,
		quick: 2,
		poke: 2
	}),
	D("blastoise", 11, 3, 5, "poke", null, {
		great: 7,
		ultra: 3
	}),
	D("machamp", 10, 3, 4, "poke", null, {
		quick: 6,
		heal: 4
	}),
	D("victreebel", 9, 3, 3, "poke", null, {
		poke: 5,
		ultra: 2,
		great: 2
	}),
	D("gengar", 1, 3, 4, "quick", null, {
		ultra: 6,
		great: 4
	}),
	D("nidoqueen", 0, 3, 3, "quick", null, {
		quick: 5,
		poke: 2,
		heal: 2
	}),
	D("venusaur", 2, 3, 5, "quick", null, {
		poke: 7,
		heal: 3
	}),
	O("eevee", "eevee", "rare", 0, "ultra", {
		quick: 3,
		poke: 2
	}),
	O("ditto", "ditto", "rare", 0, "great", {
		heal: 3,
		quick: 2
	}),
	O("snorlax", "snorlax", "rare", 0, "heal", {
		poke: 3,
		ultra: 2
	}),
	O("lapras", "lapras", "rare", 0, "poke", {
		ultra: 3,
		great: 2
	}),
	O("aerodactyl", "aerodactyl", "rare", 0, "quick", {
		great: 3,
		heal: 2
	}),
	O("mewtwo", "mewtwo", "legendary", 2, "ultra", {
		heal: 3,
		poke: 3,
		great: 3
	}),
	O("mew", "mew", "legendary", 2, "great", {
		ultra: 3,
		quick: 3,
		poke: 3
	}),
	O("moltres", "moltres", "legendary", 2, "heal", {
		great: 3,
		quick: 3,
		ultra: 3
	}),
	O("zapdos", "zapdos", "legendary", 2, "poke", {
		heal: 3,
		great: 3,
		quick: 3
	}),
	O("articuno", "articuno", "legendary", 2, "quick", {
		poke: 3,
		heal: 3,
		ultra: 3
	}),
	O("onix", "onix", "rare", 0, "ultra", {
		quick: 3,
		poke: 2
	}, "eevee"),
	O("wobbuffet", "wobbuffet", "rare", 0, "great", {
		heal: 3,
		quick: 2
	}, "ditto"),
	O("psyduck", "psyduck", "rare", 0, "heal", {
		poke: 3,
		ultra: 2
	}, "snorlax"),
	O("meowth", "meowth", "rare", 0, "poke", {
		ultra: 3,
		great: 2
	}, "lapras"),
	O("pikachu", "pikachu", "rare", 0, "quick", {
		great: 3,
		heal: 2
	}, "aerodactyl"),
	O("meloetta", "meloetta", "legendary", 2, "ultra", {
		heal: 3,
		poke: 3,
		great: 3
	}, "mewtwo"),
	O("keldeo", "keldeo", "legendary", 2, "great", {
		ultra: 3,
		quick: 3,
		poke: 3
	}, "mew"),
	O("diancie", "diancie", "legendary", 2, "heal", {
		great: 3,
		quick: 3,
		ultra: 3
	}, "moltres"),
	O("victini", "victini", "legendary", 2, "poke", {
		heal: 3,
		great: 3,
		quick: 3
	}, "zapdos"),
	O("zeraora", "zeraora", "legendary", 2, "quick", {
		poke: 3,
		heal: 3,
		ultra: 3
	}, "articuno")
], ee = new Map(k.map((e) => [e.id, e])), A = (e) => ee.get(e), j = {
	id: "splendorpokemon",
	tier: "released",
	mechanics: ["engine-building", "set-collection"],
	interactionTags: [],
	nameKey: "games.splendorpokemon.name",
	descKey: "games.splendorpokemon.desc",
	rulesKey: "games.splendorpokemon.rules",
	icon: "⚡",
	iconImg: "games/splendorpokemon.webp",
	rulesUrl: { zh: "https://rules.bgparty.uuppi.com/splendorpokemon/zh.pdf" },
	precacheAssets: /* @__PURE__ */ "art/nidoran.svg,art/nidorina.svg,art/nidoqueen.svg,art/gastly.svg,art/haunter.svg,art/gengar.svg,art/bulbasaur.svg,art/ivysaur.svg,art/venusaur.svg,art/pidgey.svg,art/pidgeotto.svg,art/pidgeot.svg,art/geodude.svg,art/graveler.svg,art/golem.svg,art/charmander.svg,art/charmeleon.svg,art/charizard.svg,art/oddish.svg,art/gloom.svg,art/vileplume.svg,art/weedle.svg,art/kakuna.svg,art/beedrill.svg,art/dratini.svg,art/dragonair.svg,art/dragonite.svg,art/bellsprout.svg,art/weepinbell.svg,art/victreebel.svg,art/machop.svg,art/machoke.svg,art/machamp.svg,art/squirtle.svg,art/wartortle.svg,art/blastoise.svg,art/poliwag.svg,art/poliwhirl.svg,art/poliwrath.svg,art/caterpie.svg,art/metapod.svg,art/butterfree.svg,art/abra.svg,art/kadabra.svg,art/alakazam.svg,art/eevee.svg,art/ditto.svg,art/snorlax.svg,art/lapras.svg,art/aerodactyl.svg,art/mewtwo.svg,art/mew.svg,art/moltres.svg,art/zapdos.svg,art/articuno.svg,art/onix.svg,art/wobbuffet.svg,art/psyduck.svg,art/meowth.svg,art/pikachu.svg,art/meloetta.svg,art/keldeo.svg,art/diancie.svg,art/victini.svg,art/zeraora.svg".split(","),
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3],
	accent: "#f3cf4c",
	releasedAt: "2026-10-13",
	search: {
		py: "cui can bao shi bao ke meng",
		init: "ccbsbkm"
	},
	hotseat: "cover"
}, M = t.enum([
	"poke",
	"great",
	"ultra",
	"heal",
	"quick"
]), te = t.enum([
	"poke",
	"great",
	"ultra",
	"heal",
	"quick",
	"master"
]), N = t.union([
	t.literal(1),
	t.literal(2),
	t.literal(3),
	t.literal("rare"),
	t.literal("legendary")
]), P = t.object({ altArt: t.boolean().catch(!1) }).default({ altArt: !1 }), F = t.union([
	t.object({
		type: t.literal("take"),
		gems: t.array(M).min(1).max(3)
	}),
	t.object({
		type: t.literal("catch"),
		cardId: t.string(),
		from: t.enum(["market", "reserved"])
	}),
	t.object({
		type: t.literal("reserve"),
		cardId: t.string()
	}),
	t.object({
		type: t.literal("reserve"),
		tier: t.union([
			t.literal(1),
			t.literal(2),
			t.literal(3)
		])
	}),
	t.object({
		type: t.literal("return"),
		gems: t.array(te).min(1)
	}),
	t.object({
		type: t.literal("evolve"),
		baseId: t.string(),
		targetId: t.string()
	}),
	t.object({ type: t.literal("skipEvolve") }),
	t.object({ type: t.literal("pass") })
]), I = t.string(), L = t.object({
	poke: t.int().nonnegative(),
	great: t.int().nonnegative(),
	ultra: t.int().nonnegative(),
	heal: t.int().nonnegative(),
	quick: t.int().nonnegative(),
	master: t.int().nonnegative()
}), R = t.object({
	poke: t.int().nonnegative(),
	great: t.int().nonnegative(),
	ultra: t.int().nonnegative(),
	heal: t.int().nonnegative(),
	quick: t.int().nonnegative()
}), ne = t.object({
	phase: t.enum([
		"play",
		"return",
		"evolve",
		"done"
	]),
	turn: I,
	market: t.array(t.object({
		tier: N,
		cards: t.array(t.string()),
		deckCount: t.int().nonnegative()
	})),
	bank: L,
	lastRound: t.boolean(),
	players: t.array(t.object({
		rid: I,
		tokens: L,
		captured: t.array(t.string()),
		bonuses: R,
		points: t.int().nonnegative(),
		reservedCount: t.int().nonnegative(),
		evolvedCount: t.int().nonnegative()
	}))
}), re = t.object({ reserved: t.array(t.string()) }), z = [...w, "master"], B = 4, V = 3, H = [
	1,
	2,
	3,
	"rare",
	"legendary"
], ie = () => ({
	poke: 0,
	great: 0,
	ultra: 0,
	heal: 0,
	quick: 0,
	master: 0
}), ae = () => ({
	poke: 0,
	great: 0,
	ultra: 0,
	heal: 0,
	quick: 0
}), oe = (e) => z.reduce((t, n) => t + e[n], 0);
function U(e) {
	let t = ae();
	for (let n of e) {
		let e = A(n);
		t[e.bonus] += e.bonusCount;
	}
	return t;
}
function W(e, t) {
	return e.captured[t].reduce((e, t) => e + A(t).points, 0);
}
function G(e, t, n) {
	let r = {}, i = e.masterCost;
	for (let a of w) {
		let o = Math.max(0, (e.cost[a] ?? 0) - t[a]), s = Math.min(n[a], o);
		s > 0 && (r[a] = s), i += o - s;
	}
	return i > n.master ? null : {
		pay: r,
		master: i
	};
}
function se(e, t, n, r) {
	let i = [];
	for (let a of e) {
		let e = A(a);
		if (!e.evolve || e.stage === 0 || e.stage === 3 || r[e.evolve.color] < e.evolve.count) continue;
		let o = e.stage + 1, s = [...n[o], ...t].filter((t) => {
			let n = A(t);
			return n.chain === e.chain && n.stage === o;
		});
		for (let e of s) i.push({
			baseId: a,
			targetId: e
		});
	}
	return i;
}
function K(e, t) {
	return se(e.captured[t], e.reserved[t], e.market, U(e.captured[t]));
}
function ce(t, n, r) {
	let i = 0, a = (t) => {
		for (let n = t.length - 1; n > 0; --n) {
			let a = e(r, i, n + 1);
			i += 1, [t[n], t[a]] = [t[a], t[n]];
		}
		return t;
	}, o = (n) => k.filter((e) => e.tier === n && !e.altOf).map((n) => {
		if (!t.altArt) return n.id;
		let a = k.find((e) => e.altOf === n.id);
		if (!a) return n.id;
		let o = e(r, i, 2) === 1;
		return i += 1, o ? a.id : n.id;
	}), s = {}, c = {};
	for (let e of [
		1,
		2,
		3
	]) {
		s[e] = a(k.filter((t) => t.tier === e).map((e) => e.id)), c[e] = [];
		for (let t = 0; t < B; t += 1) c[e].push(s[e].pop());
	}
	for (let e of ["rare", "legendary"]) s[e] = a(o(e)), c[e] = [s[e].pop()];
	let l = {
		2: 4,
		3: 5,
		4: 7
	}[n.length], u = {
		players: n,
		turnIdx: 0,
		phase: "play",
		decks: s,
		market: c,
		bank: {
			poke: l,
			great: l,
			ultra: l,
			heal: l,
			quick: l,
			master: 5
		},
		tokens: {},
		captured: {},
		reserved: {},
		evolvedUnder: {},
		mustReturn: 0,
		lastRound: !1,
		progressMark: "",
		stallCount: 0
	};
	for (let e of n) u.tokens[e] = ie(), u.captured[e] = [], u.reserved[e] = [], u.evolvedUnder[e] = 0;
	return {
		state: u,
		fx: []
	};
}
function le(e, t) {
	let n = t === "rare" || t === "legendary" ? 1 : B;
	for (; e.market[t].length < n && e.decks[t].length > 0;) e.market[t].push(e.decks[t].pop());
}
function q(e) {
	let t = oe(e.tokens[e.players[e.turnIdx]]) - 10;
	return t > 0 ? (e.phase = "return", e.mustReturn = t, []) : ue(e);
}
function ue(e) {
	let t = e.players[e.turnIdx];
	return K(e, t).length > 0 ? (e.phase = "evolve", []) : (de(e), []);
}
function de(e) {
	let t = e.players.reduce((t, n) => t + e.captured[n].length + e.reserved[n].length + e.evolvedUnder[n], 0) + "|" + z.map((t) => e.bank[t]).join(",");
	if (t === e.progressMark ? e.stallCount += 1 : (e.progressMark = t, e.stallCount = 0), e.stallCount >= e.players.length) {
		e.phase = "done";
		return;
	}
	!e.lastRound && W(e, e.players[e.turnIdx]) >= 18 && (e.lastRound = !0);
	let n = (e.turnIdx + 1) % e.players.length;
	if (e.lastRound && n === 0) {
		e.phase = "done";
		return;
	}
	e.turnIdx = n, e.phase = "play";
}
function fe(e, t, n) {
	if (e.phase === "done") return { code: "games.splendorpokemon.errNotYourTurn" };
	let r = n.by;
	if (e.players[e.turnIdx] !== r) return { code: "games.splendorpokemon.errNotYourTurn" };
	if (t.type === "return") {
		if (e.phase !== "return" || t.gems.length !== e.mustReturn) return { code: "games.splendorpokemon.errBadReturn" };
		let n = {};
		for (let e of t.gems) n[e] = (n[e] ?? 0) + 1;
		if (z.some((t) => (n[t] ?? 0) > e.tokens[r][t])) return { code: "games.splendorpokemon.errBadReturn" };
		let i = structuredClone(e);
		for (let e of z) {
			let t = n[e] ?? 0;
			i.tokens[r][e] -= t, i.bank[e] += t;
		}
		return i.mustReturn = 0, {
			state: i,
			fx: [{
				kind: "return",
				rid: r,
				data: { gems: t.gems }
			}, ...ue(i)]
		};
	}
	if (t.type === "evolve") {
		if (e.phase !== "evolve" || !K(e, r).some((e) => e.baseId === t.baseId && e.targetId === t.targetId)) return { code: "games.splendorpokemon.errBadEvolve" };
		let n = structuredClone(e), i = A(t.targetId);
		n.captured[r] = n.captured[r].filter((e) => e !== t.baseId), n.evolvedUnder[r] += 1;
		let a, o = i.tier;
		if (n.market[o].includes(t.targetId)) {
			let e = n.market[o].indexOf(t.targetId), r = n.market[o].length;
			n.market[o] = n.market[o].filter((e) => e !== t.targetId), le(n, o), a = {
				baseId: t.baseId,
				targetId: t.targetId,
				from: "market",
				tier: String(o),
				slot: e,
				rowLen: r
			};
		} else a = {
			baseId: t.baseId,
			targetId: t.targetId,
			from: "reserved",
			slot: n.reserved[r].indexOf(t.targetId)
		}, n.reserved[r] = n.reserved[r].filter((e) => e !== t.targetId);
		n.captured[r].push(t.targetId);
		let s = [{
			kind: "evolve",
			rid: r,
			data: a
		}];
		return de(n), {
			state: n,
			fx: s
		};
	}
	if (t.type === "skipEvolve") {
		if (e.phase !== "evolve") return { code: "games.splendorpokemon.errBadEvolve" };
		let t = structuredClone(e);
		return de(t), {
			state: t,
			fx: []
		};
	}
	if (e.phase !== "play") return { code: "games.splendorpokemon.errNotYourTurn" };
	if (t.type === "pass") {
		if (w.some((t) => e.bank[t] > 0)) return { code: "games.splendorpokemon.errBadPass" };
		let t = [
			1,
			2,
			3
		].some((t) => e.market[t].length > 0 || e.decks[t].length > 0);
		if (e.reserved[r].length < V && t) return { code: "games.splendorpokemon.errBadPass" };
		let n = U(e.captured[r]);
		if ([...H.flatMap((t) => e.market[t]), ...e.reserved[r]].some((t) => G(A(t), n, e.tokens[r]) !== null)) return { code: "games.splendorpokemon.errBadPass" };
		let i = structuredClone(e);
		return de(i), {
			state: i,
			fx: []
		};
	}
	if (t.type === "take") {
		let n = {};
		for (let e of t.gems) n[e] = (n[e] ?? 0) + 1;
		let i = w.filter((e) => (n[e] ?? 0) > 0);
		if (i.length === 1 && n[i[0]] === 2) {
			if (e.bank[i[0]] < 4) return { code: "games.splendorpokemon.errBadTake" };
		} else {
			if (i.some((t) => n[t] !== 1 || e.bank[t] < 1)) return { code: "games.splendorpokemon.errBadTake" };
			let t = w.filter((t) => e.bank[t] > 0).length;
			if (i.length !== Math.min(3, t)) return { code: "games.splendorpokemon.errBadTake" };
		}
		let a = structuredClone(e);
		for (let e of t.gems) a.tokens[r][e] += 1, --a.bank[e];
		return {
			state: a,
			fx: [{
				kind: "take",
				rid: r,
				data: { gems: t.gems }
			}, ...q(a)]
		};
	}
	if (t.type === "reserve") {
		if (e.reserved[r].length >= V) return { code: "games.splendorpokemon.errReserveFull" };
		let n;
		if ("cardId" in t) {
			let i = [
				1,
				2,
				3
			].find((n) => e.market[n].includes(t.cardId));
			if (!i) return { code: "games.splendorpokemon.errBadCard" };
			n = t.cardId;
			let a = structuredClone(e), o = a.market[i].indexOf(n), s = a.market[i].length;
			return a.market[i] = a.market[i].filter((e) => e !== n), le(a, i), a.reserved[r].push(n), a.bank.master > 0 && (--a.bank.master, a.tokens[r].master += 1), {
				state: a,
				fx: [{
					kind: "reserve",
					rid: r,
					data: {
						cardId: n,
						tier: String(i),
						slot: o,
						rowLen: s
					}
				}, ...q(a)]
			};
		}
		if (e.decks[t.tier].length === 0) return { code: "games.splendorpokemon.errBadCard" };
		let i = structuredClone(e);
		return n = i.decks[t.tier].pop(), i.reserved[r].push(n), i.bank.master > 0 && (--i.bank.master, i.tokens[r].master += 1), {
			state: i,
			fx: [{
				kind: "reserve",
				rid: r,
				data: {
					tier: t.tier,
					blind: !0
				},
				for: [r],
				secret: { cardId: n }
			}, ...q(i)]
		};
	}
	if (t.type === "catch") {
		let n = k.find((e) => e.id === t.cardId);
		if (!n) return { code: "games.splendorpokemon.errBadCard" };
		let i = null;
		if (t.from === "market") {
			if (i = H.find((n) => e.market[n].includes(t.cardId)) ?? null, i === null) return { code: "games.splendorpokemon.errBadCard" };
		} else if (!e.reserved[r].includes(t.cardId)) return { code: "games.splendorpokemon.errBadCard" };
		let a = G(n, U(e.captured[r]), e.tokens[r]);
		if (!a) return { code: "games.splendorpokemon.errCantAfford" };
		let o = structuredClone(e);
		for (let e of w) {
			let t = a.pay[e] ?? 0;
			o.tokens[r][e] -= t, o.bank[e] += t;
		}
		o.tokens[r].master -= a.master, o.bank.master += a.master;
		let s;
		if (i !== null) {
			let e = o.market[i].indexOf(n.id), r = o.market[i].length;
			o.market[i] = o.market[i].filter((e) => e !== n.id), le(o, i), s = {
				cardId: n.id,
				from: t.from,
				tier: String(i),
				slot: e,
				rowLen: r
			};
		} else s = {
			cardId: n.id,
			from: t.from,
			slot: o.reserved[r].indexOf(n.id)
		}, o.reserved[r] = o.reserved[r].filter((e) => e !== n.id);
		return o.captured[r].push(n.id), {
			state: o,
			fx: [{
				kind: "catch",
				rid: r,
				data: s
			}, ...ue(o)]
		};
	}
	return { code: "games.splendorpokemon.errNotYourTurn" };
}
function pe(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			market: H.map((t) => ({
				tier: t,
				cards: e.market[t],
				deckCount: e.decks[t].length
			})),
			bank: { ...e.bank },
			lastRound: e.lastRound,
			players: e.players.map((t) => ({
				rid: t,
				tokens: { ...e.tokens[t] },
				captured: [...e.captured[t]],
				bonuses: U(e.captured[t]),
				points: W(e, t),
				reservedCount: e.reserved[t].length,
				evolvedCount: e.evolvedUnder[t]
			}))
		},
		private: { reserved: [...e.reserved[t] ?? []] }
	};
}
function me(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => [
		W(e, t),
		e.evolvedUnder[t],
		e.captured[t].length
	], n = [...e.players].sort((e, n) => {
		let r = t(e), i = t(n);
		for (let e = 0; e < 3; e += 1) if (r[e] !== i[e]) return i[e] - r[e];
		return 0;
	}), r = t(n[0]), i = n.filter((e) => t(e).every((e, t) => e === r[t])), a = {};
	for (let t of e.players) a[t] = W(e, t);
	return {
		phase: "done",
		winner: i,
		ranking: n,
		scores: a
	};
}
var he = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: j,
	schemas: {
		action: F,
		publicView: ne,
		privateView: re,
		config: P
	},
	setup: (e, t, n) => ce(P.parse(e), t, n),
	reduce: fe,
	viewFor: pe,
	status: me
}, ge = {
	"games.splendorpokemon.card.nidoran": "art/nidoran.svg",
	"games.splendorpokemon.card.nidorina": "art/nidorina.svg",
	"games.splendorpokemon.card.nidoqueen": "art/nidoqueen.svg",
	"games.splendorpokemon.card.gastly": "art/gastly.svg",
	"games.splendorpokemon.card.haunter": "art/haunter.svg",
	"games.splendorpokemon.card.gengar": "art/gengar.svg",
	"games.splendorpokemon.card.bulbasaur": "art/bulbasaur.svg",
	"games.splendorpokemon.card.ivysaur": "art/ivysaur.svg",
	"games.splendorpokemon.card.venusaur": "art/venusaur.svg",
	"games.splendorpokemon.card.pidgey": "art/pidgey.svg",
	"games.splendorpokemon.card.pidgeotto": "art/pidgeotto.svg",
	"games.splendorpokemon.card.pidgeot": "art/pidgeot.svg",
	"games.splendorpokemon.card.geodude": "art/geodude.svg",
	"games.splendorpokemon.card.graveler": "art/graveler.svg",
	"games.splendorpokemon.card.golem": "art/golem.svg",
	"games.splendorpokemon.card.charmander": "art/charmander.svg",
	"games.splendorpokemon.card.charmeleon": "art/charmeleon.svg",
	"games.splendorpokemon.card.charizard": "art/charizard.svg",
	"games.splendorpokemon.card.oddish": "art/oddish.svg",
	"games.splendorpokemon.card.gloom": "art/gloom.svg",
	"games.splendorpokemon.card.vileplume": "art/vileplume.svg",
	"games.splendorpokemon.card.weedle": "art/weedle.svg",
	"games.splendorpokemon.card.kakuna": "art/kakuna.svg",
	"games.splendorpokemon.card.beedrill": "art/beedrill.svg",
	"games.splendorpokemon.card.dratini": "art/dratini.svg",
	"games.splendorpokemon.card.dragonair": "art/dragonair.svg",
	"games.splendorpokemon.card.dragonite": "art/dragonite.svg",
	"games.splendorpokemon.card.bellsprout": "art/bellsprout.svg",
	"games.splendorpokemon.card.weepinbell": "art/weepinbell.svg",
	"games.splendorpokemon.card.victreebel": "art/victreebel.svg",
	"games.splendorpokemon.card.machop": "art/machop.svg",
	"games.splendorpokemon.card.machoke": "art/machoke.svg",
	"games.splendorpokemon.card.machamp": "art/machamp.svg",
	"games.splendorpokemon.card.squirtle": "art/squirtle.svg",
	"games.splendorpokemon.card.wartortle": "art/wartortle.svg",
	"games.splendorpokemon.card.blastoise": "art/blastoise.svg",
	"games.splendorpokemon.card.poliwag": "art/poliwag.svg",
	"games.splendorpokemon.card.poliwhirl": "art/poliwhirl.svg",
	"games.splendorpokemon.card.poliwrath": "art/poliwrath.svg",
	"games.splendorpokemon.card.caterpie": "art/caterpie.svg",
	"games.splendorpokemon.card.metapod": "art/metapod.svg",
	"games.splendorpokemon.card.butterfree": "art/butterfree.svg",
	"games.splendorpokemon.card.abra": "art/abra.svg",
	"games.splendorpokemon.card.kadabra": "art/kadabra.svg",
	"games.splendorpokemon.card.alakazam": "art/alakazam.svg",
	"games.splendorpokemon.card.eevee": "art/eevee.svg",
	"games.splendorpokemon.card.ditto": "art/ditto.svg",
	"games.splendorpokemon.card.snorlax": "art/snorlax.svg",
	"games.splendorpokemon.card.lapras": "art/lapras.svg",
	"games.splendorpokemon.card.aerodactyl": "art/aerodactyl.svg",
	"games.splendorpokemon.card.mewtwo": "art/mewtwo.svg",
	"games.splendorpokemon.card.mew": "art/mew.svg",
	"games.splendorpokemon.card.moltres": "art/moltres.svg",
	"games.splendorpokemon.card.zapdos": "art/zapdos.svg",
	"games.splendorpokemon.card.articuno": "art/articuno.svg",
	"games.splendorpokemon.card.onix": "art/onix.svg",
	"games.splendorpokemon.card.wobbuffet": "art/wobbuffet.svg",
	"games.splendorpokemon.card.psyduck": "art/psyduck.svg",
	"games.splendorpokemon.card.meowth": "art/meowth.svg",
	"games.splendorpokemon.card.pikachu": "art/pikachu.svg",
	"games.splendorpokemon.card.meloetta": "art/meloetta.svg",
	"games.splendorpokemon.card.keldeo": "art/keldeo.svg",
	"games.splendorpokemon.card.diancie": "art/diancie.svg",
	"games.splendorpokemon.card.victini": "art/victini.svg",
	"games.splendorpokemon.card.zeraora": "art/zeraora.svg"
}, J = "#253647", Y = "#fffdf3", X = {
	poke: {
		bg: "#ed5552",
		fg: Y,
		deep: "#b74040"
	},
	great: {
		bg: "#288fce",
		fg: Y,
		deep: "#226fa1"
	},
	ultra: {
		bg: "#333746",
		fg: Y,
		deep: "#202632"
	},
	heal: {
		bg: "#ec95bb",
		fg: J,
		deep: "#be6f96"
	},
	quick: {
		bg: "#f1cf48",
		fg: J,
		deep: "#ad922b"
	},
	master: {
		bg: "#8c5cbb",
		fg: Y,
		deep: "#64408c"
	}
}, _e = {
	1: "#73a44f",
	2: "#e5924c",
	3: "#2d92c5",
	rare: "#bb6da3",
	legendary: "#8157ab"
}, ve = {
	"games.splendorpokemon.card.onix": "games.splendorpokemon.ui.shortNames.onix",
	"games.splendorpokemon.card.wobbuffet": "games.splendorpokemon.ui.shortNames.wobbuffet",
	"games.splendorpokemon.card.psyduck": "games.splendorpokemon.ui.shortNames.psyduck",
	"games.splendorpokemon.card.meowth": "games.splendorpokemon.ui.shortNames.meowth",
	"games.splendorpokemon.card.pikachu": "games.splendorpokemon.ui.shortNames.pikachu"
};
function ye({ color: e, x: t = 0, y: n = 0, size: r = 40, count: i }) {
	let a = r / 2, o = X[e];
	return /* @__PURE__ */ _("g", {
		transform: `translate(${t + a} ${n + a})`,
		children: [
			/* @__PURE__ */ g("circle", {
				r: a - .7,
				fill: Y,
				stroke: J,
				strokeWidth: 1.3
			}),
			/* @__PURE__ */ g("path", {
				d: `M${-a + .7} 0a${a - .7} ${a - .7} 0 0 1 ${r - 1.4} 0Z`,
				fill: o.bg
			}),
			e === "great" && /* @__PURE__ */ g("path", {
				d: `M${-a * .68} ${-a * .67}l${a * .45} ${a * .24}M${a * .68} ${-a * .67}l${-a * .45} ${a * .24}`,
				stroke: X.poke.bg,
				strokeWidth: a * .18
			}),
			e === "ultra" && /* @__PURE__ */ g("path", {
				d: `M${-a * .5} ${-a * .66}v${a * .5}M${a * .5} ${-a * .66}v${a * .5}`,
				stroke: X.quick.bg,
				strokeWidth: a * .22
			}),
			e === "quick" && /* @__PURE__ */ g("path", {
				d: `M${-a * .52} ${-a * .7}l${a * .52} ${a * .65}l${a * .52} ${-a * .65}`,
				fill: "none",
				stroke: X.great.bg,
				strokeWidth: a * .2
			}),
			e === "heal" && /* @__PURE__ */ g("path", {
				d: `M0 ${-a * .77}v${a * .42}M${-a * .21} ${-a * .56}h${a * .42}`,
				stroke: "#fffdf3",
				strokeWidth: a * .15
			}),
			e === "master" && /* @__PURE__ */ g("text", {
				x: 0,
				y: -a * .3,
				fill: "#fffdf3",
				textAnchor: "middle",
				fontSize: a * .72,
				fontWeight: 900,
				children: "M"
			}),
			/* @__PURE__ */ g("path", {
				d: `M${-a + .7} 0h${r - 1.4}`,
				stroke: J,
				strokeWidth: Math.max(1, a * .15)
			}),
			/* @__PURE__ */ g("circle", {
				r: a * .24,
				fill: Y,
				stroke: J,
				strokeWidth: 1
			}),
			i !== void 0 && /* @__PURE__ */ g("text", {
				x: 0,
				y: a * .68,
				fill: "#253647",
				textAnchor: "middle",
				fontSize: a * .65,
				fontWeight: 900,
				children: i
			})
		]
	});
}
function Z({ color: e, count: t, size: n = 40 }) {
	return /* @__PURE__ */ g("svg", {
		width: n,
		height: n,
		viewBox: `0 0 ${n} ${n}`,
		"aria-hidden": !0,
		className: "spp-glyph",
		children: /* @__PURE__ */ g(ye, {
			color: e,
			count: t,
			size: n
		})
	});
}
function Q({ color: e, x: t = 0, y: n = 0, size: r = 16 }) {
	let i = r / 2, a = Array.from({ length: 6 }, (e, t) => {
		let n = (t * 60 - 90) * Math.PI / 180;
		return `${i * Math.cos(n)},${i * Math.sin(n)}`;
	}).join(" ");
	return /* @__PURE__ */ _("g", {
		transform: `translate(${t + i} ${n + i})`,
		children: [/* @__PURE__ */ g("polygon", {
			points: a,
			fill: X[e].bg,
			stroke: J,
			strokeWidth: r >= 18 ? 1.3 : 1
		}), /* @__PURE__ */ g("path", {
			d: `M${-i * .43} 0h${i * .86}`,
			stroke: X[e].fg,
			strokeWidth: Math.max(1.4, r * .1),
			strokeLinecap: "round"
		})]
	});
}
function be({ color: e, size: t = 16 }) {
	return /* @__PURE__ */ g("svg", {
		width: t,
		height: t,
		viewBox: `0 0 ${t} ${t}`,
		"aria-hidden": !0,
		className: "spp-glyph",
		children: /* @__PURE__ */ g(Q, {
			color: e,
			size: t
		})
	});
}
function xe({ x: e = 0, y: t = 0, size: n = 12 }) {
	let r = n / 2, i = Array.from({ length: 10 }, (e, t) => {
		let n = (t * 36 - 90) * Math.PI / 180, i = t % 2 ? r * .44 : r;
		return `${i * Math.cos(n)},${i * Math.sin(n)}`;
	}).join(" ");
	return /* @__PURE__ */ g("polygon", {
		transform: `translate(${e + r} ${t + r})`,
		points: i,
		fill: "#e8c650",
		stroke: J,
		strokeWidth: .7
	});
}
function Se({ size: e = 12 }) {
	return /* @__PURE__ */ g("svg", {
		width: e,
		height: e,
		viewBox: `0 0 ${e} ${e}`,
		"aria-hidden": !0,
		className: "spp-glyph",
		children: /* @__PURE__ */ g(xe, { size: e })
	});
}
function Ce({ x: e = 0, y: t = 0, size: n = 12, direction: r = "up", color: i = "currentColor" }) {
	return /* @__PURE__ */ g("g", {
		transform: `translate(${e} ${t}) scale(${n / 24})`,
		children: /* @__PURE__ */ g("path", {
			d: "M2 8 12 1 22 8v4L12 5 2 12Z M2 18 12 11 22 18v4L12 15 2 22Z",
			fill: i,
			transform: r === "right" ? "rotate(90 12 12)" : void 0
		})
	});
}
function we({ size: e = 12, direction: t = "up" }) {
	return /* @__PURE__ */ g("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		className: "spp-glyph",
		children: /* @__PURE__ */ g(Ce, {
			size: 24,
			direction: t
		})
	});
}
function Te({ card: e, x: t, y: n, w: r, h: i }) {
	let a = ge[e.nameKey];
	return /* @__PURE__ */ g("image", {
		x: t,
		y: n,
		width: r,
		height: i,
		href: `./games/splendorpokemon/${a}`
	});
}
function Ee({ card: e, width: t = 68, compact: n = !1 }) {
	return /* @__PURE__ */ _(h, { children: [
		/* @__PURE__ */ g("rect", {
			x: 2,
			y: 2,
			width: t - 4,
			height: n ? 14 : 17,
			rx: 4,
			fill: X[e.bonus].bg
		}),
		/* @__PURE__ */ g(xe, {
			x: 4,
			y: n ? 5 : 6,
			size: 8
		}),
		/* @__PURE__ */ g("text", {
			x: 15,
			y: n ? 13 : 15,
			fontSize: n ? 11 : 12,
			fill: X[e.bonus].fg,
			fontWeight: 900,
			children: e.points
		}),
		/* @__PURE__ */ g(Q, {
			color: e.bonus,
			x: t - 16.5,
			y: n ? 3 : 3.5,
			size: n ? 12 : 13
		}),
		e.bonusCount === 2 && /* @__PURE__ */ g(Q, {
			color: e.bonus,
			x: t - 30,
			y: n ? 3 : 3.5,
			size: n ? 12 : 13
		})
	] });
}
function De({ card: e, y: t, width: n = 68, short: r = !1 }) {
	let i = c()(r ? ve[e.nameKey] ?? e.nameKey : e.nameKey), a = Math.min(11, (n - 8) / i.length * (/^[\x20-\x7E]*$/.test(i) ? 1.7 : 1));
	return /* @__PURE__ */ g("text", {
		x: n / 2,
		y: t,
		textAnchor: "middle",
		fontSize: a,
		fontWeight: 800,
		fill: J,
		children: i
	});
}
function $({ id: e, w: t = 68, h: n = 92, owned: r = !1, count: i = 1, bonuses: a }) {
	let o = c(), s = A(e), l = X[s.bonus].bg, u = [...w.filter((e) => (s.cost[e] ?? 0) > 0).map((e) => ({
		k: e,
		n: s.cost[e]
	})), ...s.masterCost ? [{
		k: "master",
		n: s.masterCost
	}] : []];
	return /* @__PURE__ */ _("svg", {
		width: t,
		height: n,
		viewBox: "0 0 68 92",
		"aria-hidden": !0,
		className: "spp-card-svg",
		children: [
			/* @__PURE__ */ g("rect", {
				x: .75,
				y: .75,
				width: 66.5,
				height: 90.5,
				rx: 6,
				fill: Y,
				stroke: J,
				strokeWidth: 1.5
			}),
			/* @__PURE__ */ g(Ee, { card: s }),
			/* @__PURE__ */ g("rect", {
				x: 3,
				y: 22,
				width: 62,
				height: r ? 39 : 41,
				rx: 3,
				fill: s.bonus === "ultra" ? "#edf0f2" : `${l}2a`
			}),
			/* @__PURE__ */ g(Te, {
				card: s,
				x: r ? 5 : 16,
				y: 21,
				w: r ? 58 : 49,
				h: r ? 41 : 42
			}),
			!r && u.map(({ k: e, n: t }, n) => /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("circle", {
				cx: 9,
				cy: 29 + n * 14,
				r: 6.5,
				fill: X[e].bg,
				stroke: "#fffdf3",
				strokeWidth: 1.2
			}), /* @__PURE__ */ g("text", {
				x: 9,
				y: 32.4 + n * 14,
				textAnchor: "middle",
				fill: X[e].fg,
				fontSize: 10,
				fontWeight: 900,
				children: t
			})] }, e)),
			/* @__PURE__ */ g(De, {
				card: s,
				y: r ? 72 : 85,
				short: r
			}),
			s.evolve ? r ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Q, {
				color: s.evolve.color,
				x: 17,
				y: 75,
				size: 12
			}), /* @__PURE__ */ _("text", {
				x: 32,
				y: 85,
				fontSize: 11,
				fill: "#46768b",
				children: [
					a?.[s.evolve.color] ?? 0,
					"/",
					s.evolve.count
				]
			})] }) : /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g(Ce, {
					x: 24,
					y: 63,
					size: 9,
					color: "#46768b"
				}),
				/* @__PURE__ */ g(Q, {
					color: s.evolve.color,
					x: 34.5,
					y: 62.5,
					size: 11
				}),
				/* @__PURE__ */ g("text", {
					x: 52,
					y: 72,
					fontSize: 9,
					fill: J,
					children: s.evolve.count
				})
			] }) : r && /* @__PURE__ */ g("text", {
				x: 34,
				y: 85,
				textAnchor: "middle",
				fontSize: 8,
				fill: "#637e8b",
				children: o(s.stage === 3 ? "games.splendorpokemon.ui.finalStage" : "games.splendorpokemon.ui.noEvolution")
			}),
			r && i > 1 && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("rect", {
				x: 49,
				y: 24,
				width: 16,
				height: 12,
				rx: 3,
				fill: "#fffdf3",
				stroke: "#253647",
				strokeWidth: .7
			}), /* @__PURE__ */ _("text", {
				x: 57,
				y: 33,
				fontSize: 9,
				fontWeight: 800,
				textAnchor: "middle",
				fill: "#253647",
				children: ["×", i]
			})] })
		]
	});
}
function Oe({ id: e, count: t = 1, bonuses: n, width: r = 52, height: i = 65 }) {
	let a = c(), o = A(e), s = X[o.bonus].bg, l = i * 52 / r, u = l - 15;
	return /* @__PURE__ */ _("svg", {
		width: r,
		height: i,
		viewBox: `0 0 52 ${l}`,
		"aria-hidden": !0,
		className: "spp-card-svg",
		children: [
			t > 1 && /* @__PURE__ */ g("rect", {
				x: 2,
				y: 1,
				width: 52,
				height: l - 2,
				rx: 5,
				fill: "#c9d6da",
				stroke: "#253647"
			}),
			/* @__PURE__ */ g("rect", {
				x: .75,
				y: .75,
				width: 50.5,
				height: l - 1.5,
				rx: 5,
				fill: Y,
				stroke: J,
				strokeWidth: 1.5
			}),
			/* @__PURE__ */ g(Ee, {
				card: o,
				width: 52,
				compact: !0
			}),
			/* @__PURE__ */ g("rect", {
				x: 3,
				y: 18,
				width: 46,
				height: u - 29,
				rx: 3,
				fill: o.bonus === "ultra" ? "#edf0f2" : `${s}2a`
			}),
			/* @__PURE__ */ g(Te, {
				card: o,
				x: t > 1 ? 4 : 8,
				y: 17,
				w: t > 1 ? 31 : 36,
				h: u - 27
			}),
			/* @__PURE__ */ g(De, {
				card: o,
				width: 52,
				y: u - 1,
				short: !0
			}),
			/* @__PURE__ */ g("rect", {
				x: 1,
				y: u,
				width: 50,
				height: 14,
				rx: 3,
				fill: "#e5eef0"
			}),
			o.evolve ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Q, {
				color: o.evolve.color,
				x: 5.5,
				y: u + 1.5,
				size: 11
			}), /* @__PURE__ */ _("text", {
				x: 21,
				y: l - 4,
				fontSize: 11,
				fill: "#46768b",
				children: [
					n[o.evolve.color] ?? 0,
					"/",
					o.evolve.count
				]
			})] }) : /* @__PURE__ */ g("text", {
				x: 26,
				y: l - 6,
				textAnchor: "middle",
				fontSize: a("games.splendorpokemon.ui.finalStage").length > 6 ? 6.5 : 9,
				fill: "#6a818b",
				children: a(o.stage === 3 ? "games.splendorpokemon.ui.finalStage" : "games.splendorpokemon.ui.noEvolution")
			}),
			t > 1 && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("rect", {
				x: 35,
				y: 18,
				width: 15,
				height: 11,
				rx: 3,
				fill: "#fffdf3",
				stroke: "#253647",
				strokeWidth: .6
			}), /* @__PURE__ */ _("text", {
				x: 42.5,
				y: 26,
				fontSize: 9,
				fontWeight: 800,
				textAnchor: "middle",
				fill: "#253647",
				children: ["×", t]
			})] })
		]
	});
}
function ke({ tier: e, w: t = 44, h: n = 92 }) {
	let r = c(), i = _e[e];
	return /* @__PURE__ */ _("svg", {
		width: t,
		height: n,
		viewBox: "0 0 44 92",
		"aria-hidden": !0,
		className: "spp-card-svg",
		children: [
			/* @__PURE__ */ g("rect", {
				x: 3,
				y: 4,
				width: 38,
				height: 88,
				rx: 5,
				fill: J
			}),
			/* @__PURE__ */ g("rect", {
				x: .75,
				y: .75,
				width: 36.5,
				height: 90.5,
				rx: 5,
				fill: i,
				stroke: J,
				strokeWidth: 1.5
			}),
			/* @__PURE__ */ g("rect", {
				x: 3,
				y: 3,
				width: 32,
				height: 86,
				rx: 3,
				fill: "none",
				stroke: "#ffffff80"
			}),
			/* @__PURE__ */ g(ye, {
				color: "poke",
				x: 7,
				y: 31,
				size: 24
			}),
			/* @__PURE__ */ g("text", {
				x: 19,
				y: 76,
				fill: Y,
				textAnchor: "middle",
				fontSize: typeof e == "number" ? 14 : e === "legendary" ? 7 : 10,
				fontWeight: 800,
				children: typeof e == "number" ? e : r(e === "rare" ? "games.splendorpokemon.rareLabel" : "games.splendorpokemon.legendaryLabel")
			}),
			Array.from({ length: typeof e == "number" ? e : 1 }, (t, n) => /* @__PURE__ */ g("circle", {
				cx: 19 - ((typeof e == "number" ? e : 1) - 1) * 4 + n * 8,
				cy: 16,
				r: 2,
				fill: Y
			}, n))
		]
	});
}
//#endregion
//#region src/games/splendorpokemon/visual-helpers.ts
var Ae = {
	poke: "games.splendorpokemon.ball.poke",
	great: "games.splendorpokemon.ball.great",
	ultra: "games.splendorpokemon.ball.ultra",
	heal: "games.splendorpokemon.ball.heal",
	quick: "games.splendorpokemon.ball.quick",
	master: "games.splendorpokemon.ball.master"
}, je = {
	1: "games.splendorpokemon.tier1",
	2: "games.splendorpokemon.tier2",
	3: "games.splendorpokemon.tier3",
	rare: "games.splendorpokemon.rareLabel",
	legendary: "games.splendorpokemon.legendaryLabel"
};
function Me(e) {
	let t = A(e);
	return JSON.stringify([
		t.nameKey,
		t.stage,
		t.points,
		t.bonus,
		t.bonusCount,
		t.evolve
	]);
}
function Ne(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = Me(n), r = t.get(e);
		r ? r.ids.push(n) : t.set(e, {
			id: n,
			ids: [n]
		});
	}
	return [...t.values()];
}
function Pe(e) {
	return Object.fromEntries(e.market.map((e) => [e.tier, e.cards]));
}
//#endregion
//#region src/games/splendorpokemon/card-dialog.tsx
function Fe({ id: e, player: t }) {
	let n = c(), r = A(e);
	if (r.chain < 0) return /* @__PURE__ */ g("div", {
		className: "spp-no-evolution",
		children: n("games.splendorpokemon.ui.noEvolution")
	});
	let i = [
		1,
		2,
		3
	].map((e) => e === r.stage ? r : k.find((t) => t.chain === r.chain && t.stage === e));
	return /* @__PURE__ */ g("div", {
		className: "spp-route",
		children: i.map((e, i) => {
			let a = e.stage === r.stage ? [e.points] : k.filter((t) => t.chain === r.chain && t.stage === e.stage).map((e) => e.points), o = Math.min(...a), s = Math.max(...a);
			return /* @__PURE__ */ _("div", {
				className: `spp-route-node${e.stage === r.stage ? " spp-current" : ""}${e.stage < r.stage ? " spp-past" : ""}`,
				children: [
					/* @__PURE__ */ g("div", {
						className: "spp-route-stage",
						children: n(e.stage === r.stage ? "games.splendorpokemon.ui.currentStage" : "games.splendorpokemon.ui.stage", { n: e.stage })
					}),
					/* @__PURE__ */ g("svg", {
						className: "spp-route-art",
						width: 58,
						height: 38,
						viewBox: "0 0 58 38",
						"aria-hidden": !0,
						children: /* @__PURE__ */ g(Te, {
							card: e,
							x: 2,
							y: 1,
							w: 54,
							h: 36
						})
					}),
					/* @__PURE__ */ g("strong", {
						className: "spp-route-name",
						children: n(e.nameKey)
					}),
					/* @__PURE__ */ _("span", {
						className: "spp-route-gain",
						children: [
							/* @__PURE__ */ g(Se, { size: 9 }),
							o === s ? o : `${o}–${s}`,
							/* @__PURE__ */ g(be, {
								color: e.bonus,
								size: 10
							}),
							e.bonusCount
						]
					}),
					i < 2 && e.evolve && /* @__PURE__ */ _("div", {
						className: `spp-route-link${e.stage < r.stage ? " spp-past" : ""}`,
						children: [
							/* @__PURE__ */ g("span", {
								className: "spp-route-arrow",
								"aria-hidden": !0,
								children: /* @__PURE__ */ g(we, {
									size: 20,
									direction: "right"
								})
							}),
							/* @__PURE__ */ g(be, {
								color: e.evolve.color,
								size: 15
							}),
							/* @__PURE__ */ g("small", { children: n(e.stage < r.stage ? "games.splendorpokemon.ui.discountNeed" : "games.splendorpokemon.ui.discountProgress", {
								n: e.stage < r.stage ? e.evolve.count : t.bonuses[e.evolve.color],
								need: e.evolve.count
							}) }),
							e.stage >= r.stage && /* @__PURE__ */ g("div", {
								className: "spp-progress",
								children: /* @__PURE__ */ g("span", { style: {
									width: `${Math.min(1, t.bonuses[e.evolve.color] / e.evolve.count) * 100}%`,
									background: X[e.evolve.color].bg
								} })
							})
						]
					})
				]
			}, e.stage);
		})
	});
}
function Ie({ selection: e, root: t, player: n, myTurn: o, canReserve: s, canEvolve: l, targetIds: u, onClose: d, onCatch: f, onReserve: p, onEvolve: m }) {
	let v = c(), y = A(e.id), b = e.from === "team", x = G(y, n.bonuses, n.tokens), S = i(null), C = i(null), [T, E] = a(null), D = i(d);
	r(() => {
		D.current = d;
	}), r(() => {
		let n = e.source, r = t.current, i = S.current;
		if (!r || !i) return;
		let a = () => {
			let e = r.getBoundingClientRect(), t = n.getBoundingClientRect(), a = i.getBoundingClientRect(), o = matchMedia("(orientation: landscape)").matches && e.width >= 1e3 && e.height >= 600, s = o ? 16 : 8, c = o ? 18 : 12, l = o ? Math.min(190, Math.max(100, t.width * 1.08)) : 73.44, d = l * 92 / 68, f = {
				x: Math.max(s, Math.min(e.width - s - l, t.left - e.left + (t.width - l) / 2)),
				y: t.top - e.top - (o ? 20 : 13),
				w: l,
				h: d
			}, p = e.height - s - a.height - c - d, m = s + a.height + c;
			f.y + d + c + a.height > e.height - s && f.y - c - a.height < s && (f.y = Math.abs(f.y - p) <= Math.abs(f.y - m) ? p : m), f.y = Math.max(s, Math.min(e.height - s - d, f.y));
			let h = f.y + d + c + a.height <= e.height - s, g = {
				x: Math.max(s, Math.min(e.width - s - a.width, f.x + l / 2 - a.width / 2)),
				y: h ? f.y + d + c : f.y - c - a.height,
				w: a.width,
				h: a.height
			}, _ = [];
			r.querySelectorAll("[data-spp-card]").forEach((t) => {
				let n = t.dataset.sppCard, r = t.dataset.sppFrom;
				if (!u.has(n) || r !== "market" && r !== "reserved") return;
				let i = t.getBoundingClientRect(), a = t.closest(".spp-market-scroll")?.getBoundingClientRect();
				a && (i.top < a.top || i.bottom > a.bottom) || i.top < e.top || i.bottom > e.bottom || _.push({
					id: n,
					from: r,
					rect: {
						x: i.left - e.left,
						y: i.top - e.top,
						w: i.width,
						h: i.height
					}
				});
			}), E({
				card: f,
				panel: g,
				below: h,
				targets: _
			});
		};
		a();
		let o = new ResizeObserver(a);
		return o.observe(r), o.observe(i), r.addEventListener("scroll", a, !0), () => {
			o.disconnect(), r.removeEventListener("scroll", a, !0);
		};
	}, [
		e,
		t,
		u
	]);
	let O = T !== null;
	r(() => {
		if (!O) return;
		let t = e.source;
		(S.current?.querySelector("button:not(:disabled)"))?.focus({ preventScroll: !0 });
		let n = (e) => {
			if (e.key === "Escape" && (e.preventDefault(), D.current()), e.key !== "Tab") return;
			let t = [...C.current?.querySelectorAll("button:not(:disabled)") ?? []];
			if (!t.length) return;
			let n = t[0], r = t[t.length - 1];
			e.shiftKey && (document.activeElement === n || !C.current?.contains(document.activeElement)) ? (e.preventDefault(), r.focus()) : !e.shiftKey && (document.activeElement === r || !C.current?.contains(document.activeElement)) && (e.preventDefault(), n.focus());
		};
		return document.addEventListener("keydown", n), () => {
			document.removeEventListener("keydown", n), queueMicrotask(() => {
				t.isConnected && t.focus({ preventScroll: !0 });
			});
		};
	}, [e, O]);
	let k = x ? [...w.filter((e) => (x.pay[e] ?? 0) > 0).map((e) => ({
		color: e,
		n: x.pay[e]
	})), ...x.master ? [{
		color: "master",
		n: x.master
	}] : []] : [...w.filter((e) => Math.max(0, (y.cost[e] ?? 0) - n.bonuses[e]) > 0).map((e) => ({
		color: e,
		n: Math.max(0, (y.cost[e] ?? 0) - n.bonuses[e])
	})), ...y.masterCost ? [{
		color: "master",
		n: y.masterCost
	}] : []];
	return /* @__PURE__ */ _("div", {
		ref: C,
		className: "spp-dialog-overlay",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": v(y.nameKey),
		children: [
			/* @__PURE__ */ g("div", {
				className: "spp-shade",
				onClick: d
			}),
			T?.targets.map((e) => /* @__PURE__ */ _("button", {
				className: "spp-target-clone",
				style: {
					left: e.rect.x,
					top: e.rect.y,
					width: e.rect.w,
					height: e.rect.h
				},
				tabIndex: l ? 0 : -1,
				disabled: !l,
				"aria-label": v("games.splendorpokemon.evolveTargetAria", { name: v(A(e.id).nameKey) }),
				onClick: () => m(e.id),
				children: [/* @__PURE__ */ g($, {
					id: e.id,
					w: e.rect.w,
					h: e.rect.h
				}), /* @__PURE__ */ g("span", {
					className: "spp-available-mark",
					"aria-hidden": !0,
					children: /* @__PURE__ */ g(we, { size: 10 })
				})]
			}, e.id)),
			T && /* @__PURE__ */ g("div", {
				className: "spp-floating-card",
				style: {
					left: T.card.x,
					top: T.card.y
				},
				children: /* @__PURE__ */ g($, {
					id: e.id,
					w: T.card.w,
					h: T.card.h,
					owned: b,
					count: e.count,
					bonuses: n.bonuses
				})
			}),
			/* @__PURE__ */ _("div", {
				ref: S,
				className: "spp-card-dialog",
				style: {
					left: T?.panel.x ?? 8,
					top: T?.panel.y ?? 8,
					visibility: T ? "visible" : "hidden"
				},
				children: [
					T && /* @__PURE__ */ g("span", {
						className: `spp-dialog-tip${T.below ? " spp-tip-up" : " spp-tip-down"}`,
						style: { left: Math.max(18, Math.min(T.panel.w - 32, T.card.x + T.card.w / 2 - T.panel.x - 7)) },
						"aria-hidden": !0
					}),
					/* @__PURE__ */ _("div", {
						className: "spp-dialog-title",
						children: [/* @__PURE__ */ g("strong", { children: v(y.nameKey) }), /* @__PURE__ */ g("span", { children: b && y.stage ? v("games.splendorpokemon.ui.caughtStage", { n: y.stage }) : v(je[y.tier]) })]
					}),
					/* @__PURE__ */ _("div", {
						className: `spp-finances${b ? " spp-owned-finances" : ""}`,
						children: [
							!b && /* @__PURE__ */ _("div", {
								className: "spp-payment",
								children: [/* @__PURE__ */ g("small", { children: v("games.splendorpokemon.ui.pay") }), /* @__PURE__ */ g("div", { children: k.length ? k.map((e) => /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Z, {
									color: e.color,
									size: 22
								}), /* @__PURE__ */ g("b", { children: e.n })] }, e.color)) : /* @__PURE__ */ g("b", { children: v("games.splendorpokemon.free") }) })]
							}),
							/* @__PURE__ */ _("div", {
								className: "spp-gain",
								children: [/* @__PURE__ */ g("small", { children: v("games.splendorpokemon.ui.score") }), /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Se, {}), /* @__PURE__ */ g("b", { children: y.points })] })]
							}),
							/* @__PURE__ */ _("div", {
								className: "spp-gain",
								children: [/* @__PURE__ */ g("small", { children: v("games.splendorpokemon.ui.discount") }), /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(be, {
									color: y.bonus,
									size: 22
								}), /* @__PURE__ */ g("b", { children: y.bonusCount })] })]
							}),
							b && /* @__PURE__ */ g("small", {
								className: "spp-evolution-timing",
								children: v(y.stage === 3 ? "games.splendorpokemon.ui.finalStage" : y.evolve ? "games.splendorpokemon.ui.endTurnEvolution" : "games.splendorpokemon.ui.noEvolution")
							})
						]
					}),
					/* @__PURE__ */ g(Fe, {
						id: e.id,
						player: n
					}),
					/* @__PURE__ */ g("div", {
						className: "spp-dialog-actions",
						children: b ? /* @__PURE__ */ _(h, { children: [y.evolve && /* @__PURE__ */ g("button", {
							className: "spp-button spp-primary",
							disabled: !l,
							onClick: () => m(),
							children: v(l ? "games.splendorpokemon.ui.evolve" : n.bonuses[y.evolve.color] < y.evolve.count ? "games.splendorpokemon.ui.insufficient" : "games.splendorpokemon.ui.endTurnEvolution")
						}), /* @__PURE__ */ g("button", {
							className: "spp-button",
							onClick: d,
							children: v("games.splendorpokemon.cancel")
						})] }) : /* @__PURE__ */ _(h, { children: [
							/* @__PURE__ */ g("button", {
								className: "spp-button",
								onClick: d,
								children: v("games.splendorpokemon.cancel")
							}),
							e.from === "market" && typeof y.tier == "number" && /* @__PURE__ */ g("button", {
								className: "spp-button",
								disabled: !o || !s,
								onClick: p,
								children: v(s ? "games.splendorpokemon.reserve" : "games.splendorpokemon.ui.reserveFull")
							}),
							/* @__PURE__ */ g("button", {
								className: "spp-button spp-primary",
								disabled: !o || !x,
								onClick: f,
								children: v(x ? "games.splendorpokemon.catch" : "games.splendorpokemon.cantAfford")
							})
						] })
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/splendorpokemon/view-player.tsx
function Le(e) {
	return z.reduce((t, n) => t + e.tokens[n], 0);
}
function Re(e, t) {
	if (!e.length) return !1;
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t, (n.get(t) ?? 0) + 1);
	if (n.size === 1) {
		let [e, r] = [...n.entries()][0];
		return r === 2 ? t[e] >= 4 : r === 1 && t[e] > 0 && w.filter((e) => t[e] > 0).length === 1;
	}
	return ![...n.values()].some((e) => e !== 1) && !e.some((e) => t[e] < 1) && e.length === Math.min(3, w.filter((e) => t[e] > 0).length);
}
function ze({ anchor: e, arrivalAnchor: t, children: n, className: r = "", style: i, label: a, disabled: s, onClick: c, cardId: l, from: u }) {
	let { ref: d, hidden: f } = o(e), { ref: p, hidden: m } = o(t ?? null);
	return /* @__PURE__ */ g("button", {
		ref: (e) => {
			d(e), p(e);
		},
		className: r,
		style: {
			...i,
			visibility: f || m ? "hidden" : void 0
		},
		"aria-label": a,
		disabled: s,
		onClick: c,
		"data-spp-card": l,
		"data-spp-from": u,
		children: n
	});
}
function Be({ rid: e, color: t }) {
	let { ref: n } = o(`held:${e}:${t}`);
	return /* @__PURE__ */ g("span", {
		ref: n,
		className: "inline-flex",
		children: /* @__PURE__ */ g(Z, {
			color: t,
			size: 18
		})
	});
}
function Ve({ color: e, count: t }) {
	let { ref: n } = o(`bank-token:${e}`);
	return /* @__PURE__ */ g("span", {
		ref: n,
		className: "spp-bank-token",
		children: /* @__PURE__ */ g(Z, {
			color: e,
			size: 37,
			count: t
		})
	});
}
function He({ anchor: e, children: t, className: n }) {
	let { ref: r } = o(e);
	return /* @__PURE__ */ g("div", {
		ref: r,
		className: n,
		children: t
	});
}
function Ue({ member: e, player: t, mine: n, current: r, picked: i, onClick: a }) {
	let o = c(), s = o("games.splendorpokemon.ui.playerSummary", {
		name: e.name,
		points: t.points,
		tokens: Le(t),
		caught: t.captured.length,
		reserved: t.reservedCount,
		evolved: t.evolvedCount
	});
	return /* @__PURE__ */ _(ze, {
		anchor: `seat:${e.rid}`,
		className: `spp-seat${r ? " spp-turn-seat" : ""}${i ? " spp-picked-seat" : ""}${e.online ? "" : " spp-offline-seat"}`,
		label: `${s}${e.online ? "" : `, ${o("games.splendorpokemon.ui.offline")}`}`,
		onClick: a,
		style: { "--spp-player-color": d[e.colorIndex % d.length].hex },
		children: [
			/* @__PURE__ */ g("img", {
				className: "spp-avatar",
				src: `./${u[e.avatar % u.length]}`,
				alt: ""
			}),
			/* @__PURE__ */ _("span", {
				className: "spp-seat-name",
				children: [
					e.name,
					n ? ` · ${o("games.splendorpokemon.ui.you")}` : f(e.rid) || e.autopilot ? " · ♟" : "",
					!e.online && " ◌"
				]
			}),
			/* @__PURE__ */ _("span", {
				className: "spp-seat-score",
				children: [/* @__PURE__ */ g(Se, { size: 10 }), /* @__PURE__ */ g("b", { children: t.points })]
			}),
			/* @__PURE__ */ _("span", {
				className: "spp-seat-balls",
				children: [/* @__PURE__ */ g(Z, {
					color: "poke",
					size: 13
				}), /* @__PURE__ */ g("b", { children: Le(t) })]
			})
		]
	});
}
function We(e) {
	return /* @__PURE__ */ g(Ge, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ge({ pub: e, priv: t, members: n, myRid: u, send: d }) {
	l();
	let f = c(), v = i(null), y = s((e) => e.locale), b = i(null), x = i(null), { ref: S } = o(`team-strip:${u}`), { ref: C } = o("market-card-size"), [T, E] = a({
		w: 52,
		h: 65,
		rows: 1
	});
	r(() => {
		let e = b.current;
		if (!e) return;
		let t = () => {
			let t = v.current?.getBoundingClientRect(), n = t && matchMedia("(orientation: landscape)").matches && t.width >= 1e3 && t.height >= 600, r = n ? Math.max(76, Math.min(110, t.width * .07)) : 52, i = n ? r * 65 / 52 : Math.max(65, e.getBoundingClientRect().height - 8), a = n ? Math.max(1, Math.min(3, Math.floor((e.clientHeight - 6) / (i + 10)))) : 1;
			E((e) => e.w === r && e.h === i && e.rows === a ? e : {
				w: r,
				h: i,
				rows: a
			});
		}, n = new ResizeObserver(t);
		n.observe(e), v.current && n.observe(v.current), t();
		let r = matchMedia("(orientation: landscape)"), i = () => {
			x.current && (x.current.scrollTop = r.matches ? x.current.scrollHeight : 0);
		};
		return i(), r.addEventListener("change", i), () => {
			n.disconnect(), r.removeEventListener("change", i);
		};
	}, []);
	let D = e.players.find((e) => e.rid === u), O = (e) => n.find((t) => t.rid === e)?.name ?? e, k = e.phase === "play" && e.turn === u, ee = e.phase === "return" && e.turn === u, j = e.phase === "evolve" && e.turn === u, M = t?.reserved ?? [], [te, N] = a(u), [P, F] = a(null), [I, L] = a([]), [R, ne] = a([]), [re, B] = a(null), [V, H] = a(null), ie = JSON.stringify([
		e.phase,
		e.turn,
		e.bank,
		e.market,
		e.players,
		M
	]), [ae, oe] = a(ie);
	ae !== ie && (oe(ie), F(null), L([]), ne([]), B(null), H(null), e.turn === u && N(u));
	let U = e.players.find((e) => e.rid === te) ?? D, W = U.rid === u, K = j ? se(D.captured, M, Pe(e), D.bonuses) : [], ce = new Set(K.map((e) => e.baseId)), le = M.length < 3, q = Math.max(0, Le(D) - 10), ue = !w.some((t) => e.bank[t] > 0), de = [...e.market.flatMap((e) => e.cards), ...M].some((e) => G(A(e), D.bonuses, D.tokens)), fe = le && e.market.some((e) => typeof e.tier == "number" && (e.deckCount > 0 || e.cards.length > 0)), pe = k && ue && !de && !fe, me = P ? A(P.id) : null, he = new Set(V ? K.filter((e) => e.baseId === V).map((e) => e.targetId) : me && me.chain >= 0 ? [...e.market.flatMap((e) => e.cards), ...M].filter((e) => {
		let t = A(e);
		return t.chain === me.chain && t.stage === me.stage + 1;
	}) : []), ge = () => {
		F(null), L([]), B(null), H(null);
	}, J = (e) => {
		ge(), ne([]), d(e);
	}, Y = (e, t, n, r = 1, i = u) => {
		if (V && K.some((t) => t.baseId === V && t.targetId === e)) {
			J({
				type: "evolve",
				baseId: V,
				targetId: e
			});
			return;
		}
		L([]), B(null), H(null), F({
			id: e,
			from: t,
			source: n,
			count: r,
			owner: i
		});
	}, X = (t) => {
		k && (N(u), F(null), B(null), L((n) => {
			let r = n.filter((e) => e === t).length;
			return r ? r === 1 && new Set(n).size === 1 && e.bank[t] >= 4 ? [...n, t] : n.filter((e) => e !== t) : n.length >= 3 || n.length === 2 && n[0] === n[1] ? n : [...n, t];
		}));
	}, _e = (e) => ne((t) => t.length < q && t.filter((t) => t === e).length < D.tokens[e] ? [...t, e] : t), ve = (e) => {
		if (!P || P.owner !== u || !j) return;
		let t = K.filter((e) => e.baseId === P.id);
		e && t.some((t) => t.targetId === e) ? J({
			type: "evolve",
			baseId: P.id,
			targetId: e
		}) : t.length === 1 ? J({
			type: "evolve",
			...t[0]
		}) : t.length > 1 && (H(P.id), F(null));
	}, ye = ee ? f("games.splendorpokemon.returnPrompt", { n: q }) : j ? f("games.splendorpokemon.evolvePrompt") : e.phase === "return" ? f("games.splendorpokemon.returnWait", { name: O(e.turn) }) : e.phase === "evolve" ? f("games.splendorpokemon.evolveWait", { name: O(e.turn) }) : k ? f("games.splendorpokemon.ui.turnShort") : f("games.splendorpokemon.turnWait", { name: O(e.turn) }), Q = (e, t, n = 0) => {
		let r = A(e), i = k && G(r, D.bonuses, D.tokens) !== null, a = he.has(e);
		return /* @__PURE__ */ _(ze, {
			anchor: t === "market" ? `mcard:${e}` : `rsv:${n}`,
			arrivalAnchor: t === "reserved" ? `reserved:${u}:${e}` : void 0,
			cardId: e,
			from: t,
			className: `spp-card-button${a ? " spp-target" : ""}${i ? " spp-affordable" : ""}`,
			label: f("games.splendorpokemon.cardStatusAria", {
				card: f(r.nameKey),
				status: f(a ? "games.splendorpokemon.evolveTargetAria" : i ? "games.splendorpokemon.cardAffordable" : "games.splendorpokemon.cardInspect", { name: f(r.nameKey) })
			}),
			onClick: (n) => Y(e, t, n.currentTarget),
			children: [/* @__PURE__ */ g($, {
				id: e,
				w: t === "reserved" ? 42 : 68,
				h: t === "reserved" ? 57 : 92
			}), (a || i) && /* @__PURE__ */ g("span", {
				className: "spp-available-mark",
				"aria-hidden": !0,
				children: a ? /* @__PURE__ */ g(we, { size: 10 }) : "✓"
			})]
		}, e);
	}, xe = (t) => {
		let n = e.market.find((e) => e.tier === t);
		return /* @__PURE__ */ _("div", {
			className: typeof t == "number" ? "spp-market-row" : "spp-special-row",
			children: [
				typeof t != "number" && /* @__PURE__ */ g("span", {
					className: "spp-special-label",
					children: f(je[t])
				}),
				/* @__PURE__ */ _(ze, {
					anchor: `deck:${t}`,
					className: "spp-deck",
					label: f(typeof t == "number" ? "games.splendorpokemon.deckAria" : "games.splendorpokemon.specialDeckAria", {
						tier: typeof t == "number" ? t : f(je[t]),
						n: n.deckCount
					}),
					disabled: typeof t != "number" || !k || !le || !n.deckCount,
					onClick: () => {
						typeof t == "number" && (ge(), N(u), B(t));
					},
					children: [/* @__PURE__ */ g(ke, { tier: t }), /* @__PURE__ */ g("span", {
						className: "spp-deck-count",
						children: n.deckCount
					})]
				}),
				/* @__PURE__ */ g(He, {
					anchor: `mrow:${t}`,
					className: "spp-market-cards",
					children: n.cards.map((e) => Q(e, "market"))
				})
			]
		}, t);
	}, Se = Ne(U.captured), Ce = P ? e.players.find((e) => e.rid === P.owner) ?? D : D;
	return /* @__PURE__ */ _("div", {
		ref: v,
		className: "spp-view",
		children: [/* @__PURE__ */ g("div", {
			className: "spp-base",
			inert: !!P,
			children: /* @__PURE__ */ g(m, {
				adaptive: !0,
				scroll: !1,
				banner: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("div", {
					className: "spp-banner",
					"data-locale": y,
					children: [/* @__PURE__ */ g(p, {
						tone: k || j ? "accent" : ee ? "warn" : "info",
						accent: "#d94e49",
						text: ye,
						chip: e.lastRound ? f("games.splendorpokemon.lastRound") : void 0
					}), k && !e.lastRound && /* @__PURE__ */ g("span", {
						className: "spp-turn-actions",
						children: f("games.splendorpokemon.ui.turnActions")
					})]
				}), /* @__PURE__ */ g("div", {
					className: "spp-seats",
					children: e.players.map((t) => {
						let r = n.find((e) => e.rid === t.rid);
						return r && /* @__PURE__ */ g(Ue, {
							member: r,
							player: t,
							mine: t.rid === u,
							current: t.rid === e.turn,
							picked: t.rid === te && !W,
							onClick: () => {
								ge(), N(t.rid === te ? u : t.rid);
							}
						}, t.rid);
					})
				})] }),
				children: /* @__PURE__ */ _("div", {
					className: "spp-stage",
					children: [
						/* @__PURE__ */ g("div", {
							ref: x,
							className: "spp-market-scroll",
							children: /* @__PURE__ */ _("div", {
								className: "spp-board",
								children: [
									/* @__PURE__ */ g("span", {
										ref: C,
										className: "spp-market-size",
										"aria-hidden": !0
									}),
									/* @__PURE__ */ _("div", {
										className: "spp-specials",
										children: [xe("rare"), xe("legendary")]
									}),
									[
										3,
										2,
										1
									].map((e) => xe(e))
								]
							})
						}),
						/* @__PURE__ */ g("div", {
							className: "spp-bank",
							children: z.map((t) => /* @__PURE__ */ _(ze, {
								anchor: `bank:${t}`,
								className: `spp-bank-ball${I.includes(t) ? " spp-selected-ball" : ""}`,
								label: f(t === "master" ? "games.splendorpokemon.masterReserveOnly" : "games.splendorpokemon.bankTokenAria", {
									ball: f(Ae[t]),
									n: e.bank[t]
								}),
								disabled: t === "master" || !k || !e.bank[t] || !I.includes(t) && (I.length >= 3 || I.length === 2 && I[0] === I[1]),
								onClick: () => {
									t !== "master" && X(t);
								},
								children: [
									/* @__PURE__ */ g(Ve, {
										color: t,
										count: e.bank[t]
									}),
									t === "master" && /* @__PURE__ */ g("span", {
										className: "spp-bank-lock",
										children: f("games.splendorpokemon.ui.lock")
									}),
									I.includes(t) && /* @__PURE__ */ g("span", {
										className: "spp-selection-count",
										children: I.filter((e) => e === t).length
									})
								]
							}, t))
						}),
						/* @__PURE__ */ _("div", {
							className: "spp-personal",
							children: [/* @__PURE__ */ _("div", {
								className: "spp-resource-panel",
								children: [/* @__PURE__ */ _("div", {
									className: "spp-resources",
									children: [/* @__PURE__ */ g("strong", {
										className: "spp-resource-title",
										children: f("games.splendorpokemon.ui.totalBalls", { n: Le(U) })
									}), /* @__PURE__ */ _("div", {
										className: "spp-resource-grid",
										children: [
											/* @__PURE__ */ g("span", {}),
											/* @__PURE__ */ g(h, { children: z.map((e) => /* @__PURE__ */ g(Be, {
												rid: U.rid,
												color: e
											}, e)) }),
											/* @__PURE__ */ g("small", { children: f("games.splendorpokemon.ui.owned") }),
											z.map((e) => /* @__PURE__ */ g("b", { children: U.tokens[e] }, e)),
											/* @__PURE__ */ g("small", { children: f("games.splendorpokemon.ui.discountShort") }),
											z.map((e) => e === "master" ? /* @__PURE__ */ g("span", { children: "—" }, e) : /* @__PURE__ */ _("span", {
												className: "spp-resource-discount",
												children: [/* @__PURE__ */ g(be, {
													color: e,
													size: 13
												}), U.bonuses[e]]
											}, e))
										]
									})]
								}), /* @__PURE__ */ _("div", {
									className: "spp-reserved",
									children: [/* @__PURE__ */ g("strong", {
										className: "spp-resource-title",
										children: f("games.splendorpokemon.ui.totalReserved", { n: U.reservedCount })
									}), /* @__PURE__ */ g("div", {
										className: "spp-reserved-slots",
										children: [
											0,
											1,
											2
										].map((e) => /* @__PURE__ */ g(He, {
											anchor: `reserved-slot:${U.rid}:${e}`,
											className: "spp-reserved-slot",
											children: W && M[e] ? Q(M[e], "reserved", e) : !W && e < U.reservedCount ? /* @__PURE__ */ g(ke, {
												tier: 1,
												w: 40,
												h: 57
											}) : /* @__PURE__ */ g("span", {
												className: "spp-empty-slot",
												"aria-hidden": !0
											})
										}, e))
									})]
								})]
							}), /* @__PURE__ */ g("div", {
								ref: (e) => {
									b.current = e, S(W ? e : null);
								},
								className: "spp-team-strip",
								"aria-label": f("games.splendorpokemon.caughtLabel"),
								children: /* @__PURE__ */ g("div", {
									className: "spp-team-grid",
									style: {
										"--spp-team-rows": T.rows,
										"--spp-team-w": `${T.w}px`,
										"--spp-team-h": `${T.h}px`
									},
									children: Se.length ? Se.map((e) => {
										let t = W && e.ids.some((e) => ce.has(e));
										return /* @__PURE__ */ _(ze, {
											anchor: `team:${U.rid}:${Me(e.id)}`,
											arrivalAnchor: e.ids.length === 1 ? `team-new:${U.rid}:${e.id}` : void 0,
											cardId: e.id,
											from: "team",
											className: `spp-team-button${t ? " spp-target" : ""}`,
											style: {
												width: T.w,
												height: T.h
											},
											label: f("games.splendorpokemon.ui.groupAria", {
												name: f(A(e.id).nameKey),
												n: e.ids.length,
												points: A(e.id).points
											}),
											onClick: (t) => Y(e.ids.find((e) => ce.has(e)) ?? e.id, "team", t.currentTarget, e.ids.length, U.rid),
											children: [/* @__PURE__ */ g(Oe, {
												id: e.id,
												count: e.ids.length,
												bonuses: U.bonuses,
												width: T.w,
												height: T.h
											}), t && /* @__PURE__ */ g("span", {
												className: "spp-available-mark",
												"aria-hidden": !0,
												children: /* @__PURE__ */ g(we, { size: 10 })
											})]
										}, e.id);
									}) : /* @__PURE__ */ g("span", {
										className: "spp-team-empty",
										children: f("games.splendorpokemon.ui.emptyTeam")
									})
								})
							})]
						}),
						I.length > 0 && /* @__PURE__ */ _("div", {
							className: "spp-action-popover",
							children: [
								/* @__PURE__ */ g("span", {
									className: "spp-taken-balls",
									children: I.map((e, t) => /* @__PURE__ */ g(Z, {
										color: e,
										size: 25
									}, `${e}${t}`))
								}),
								/* @__PURE__ */ g("button", {
									className: "spp-button",
									onClick: () => L([]),
									children: f("games.splendorpokemon.cancel")
								}),
								/* @__PURE__ */ g("button", {
									className: "spp-button spp-primary",
									disabled: !Re(I, e.bank),
									onClick: () => J({
										type: "take",
										gems: I
									}),
									children: f("games.splendorpokemon.takeConfirm", { n: I.length })
								})
							]
						}),
						re && /* @__PURE__ */ _("div", {
							className: "spp-action-popover spp-deck-popover",
							children: [
								/* @__PURE__ */ g("strong", { children: f("games.splendorpokemon.blindReserveDesc", { tier: re }) }),
								/* @__PURE__ */ g("button", {
									className: "spp-button",
									onClick: () => B(null),
									children: f("games.splendorpokemon.cancel")
								}),
								/* @__PURE__ */ g("button", {
									className: "spp-button spp-primary",
									onClick: () => J({
										type: "reserve",
										tier: re
									}),
									children: f("games.splendorpokemon.reserve")
								})
							]
						}),
						ee && /* @__PURE__ */ _("div", {
							className: "spp-return-popover",
							children: [
								/* @__PURE__ */ g("strong", { children: f("games.splendorpokemon.returnPrompt", { n: q }) }),
								/* @__PURE__ */ g("div", {
									className: "spp-return-balls",
									children: z.map((e) => /* @__PURE__ */ _("button", {
										className: "spp-return-ball",
										"aria-label": f("games.splendorpokemon.returnBallAria", {
											ball: f(Ae[e]),
											n: D.tokens[e] - R.filter((t) => t === e).length
										}),
										disabled: R.length >= q || R.filter((t) => t === e).length >= D.tokens[e],
										onClick: () => _e(e),
										children: [/* @__PURE__ */ g(Z, {
											color: e,
											size: 34,
											count: D.tokens[e] - R.filter((t) => t === e).length
										}), /* @__PURE__ */ g("span", { children: R.filter((t) => t === e).length > 0 ? `−${R.filter((t) => t === e).length}` : "" })]
									}, e))
								}),
								/* @__PURE__ */ _("div", {
									className: "spp-return-actions",
									children: [
										/* @__PURE__ */ g("span", { children: f("games.splendorpokemon.ui.returnSelected", {
											n: R.length,
											need: q
										}) }),
										/* @__PURE__ */ g("button", {
											className: "spp-button",
											disabled: !R.length,
											onClick: () => ne([]),
											children: f("games.splendorpokemon.cancel")
										}),
										/* @__PURE__ */ g("button", {
											className: "spp-button spp-primary",
											disabled: R.length !== q,
											onClick: () => J({
												type: "return",
												gems: R
											}),
											children: f("games.splendorpokemon.returnConfirm")
										})
									]
								})
							]
						}),
						j && !P && /* @__PURE__ */ _("div", {
							className: "spp-evolve-popover",
							children: [V && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", { children: f("games.splendorpokemon.ui.chooseTarget") }), /* @__PURE__ */ g("button", {
								className: "spp-button",
								onClick: () => H(null),
								children: f("games.splendorpokemon.cancel")
							})] }), /* @__PURE__ */ g("button", {
								className: "spp-button",
								onClick: () => J({ type: "skipEvolve" }),
								children: f("games.splendorpokemon.ui.skipEvolution")
							})]
						}),
						pe && /* @__PURE__ */ g("div", {
							className: "spp-action-popover",
							children: /* @__PURE__ */ g("button", {
								className: "spp-button spp-primary",
								onClick: () => J({ type: "pass" }),
								children: f("games.splendorpokemon.pass")
							})
						})
					]
				})
			})
		}), P && /* @__PURE__ */ g(Ie, {
			selection: P,
			root: v,
			player: Ce,
			myTurn: k && P.owner === u,
			canReserve: le,
			canEvolve: P.owner === u && K.some((e) => e.baseId === P.id),
			targetIds: he,
			onClose: () => F(null),
			onCatch: () => {
				N(u), J({
					type: "catch",
					cardId: P.id,
					from: P.from
				});
			},
			onReserve: () => {
				N(u), J({
					type: "reserve",
					cardId: P.id
				});
			},
			onEvolve: ve
		})]
	});
}
//#endregion
//#region src/games/splendorpokemon/bot.ts
function Ke() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function qe(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Je = (e) => z.reduce((t, n) => t + e[n], 0), Ye = (e) => Object.fromEntries(e.market.map((e) => [e.tier, e.cards]));
function Xe(e) {
	let t = w.filter((t) => e[t] > 0), n = [], r = Math.min(3, t.length);
	if (r > 0) {
		let e = (i, a) => {
			if (a.length === r) {
				n.push(a);
				return;
			}
			for (let n = i; n < t.length; n += 1) e(n + 1, [...a, t[n]]);
		};
		e(0, []);
	}
	for (let t of w) e[t] >= 4 && n.push([t, t]);
	return n;
}
function Ze(e, t, n) {
	let r = 0;
	for (let i of e) r += Math.max(0, (A(i).cost[n] ?? 0) - t[n]);
	return r;
}
var Qe = {
	pointsW: 5,
	raceW: .5,
	masterW: .4,
	hoardW: 1.5,
	returnW: 2,
	denyW: 0,
	denyEndW: 0,
	oppRespW: 0,
	oppDistW: 1,
	reserveBaseW: .2,
	blindW: .15,
	engineW: .3,
	evolveW: .5,
	evolveBonusW: .6,
	evolveTbW: .2,
	gatherRate: 3,
	colorRate: 1,
	searchK: 6,
	noiseW: 0
};
function $e(e = Qe) {
	let t = (t, n, r, i) => {
		let a = {}, o = 0;
		for (let e of w) a[e] = Math.max(0, (t[e] ?? 0) - r[e] - i[e]), o += a[e];
		let s = i.master - n;
		for (let e of [...w].sort((e, t) => a[t] - a[e])) {
			let t = Math.min(s, a[e]);
			a[e] -= t, s -= t, o -= t;
		}
		o += Math.max(0, -s);
		let c = 0;
		for (let t of w) c = Math.max(c, a[t] / e.colorRate);
		return Math.max(c, o / e.gatherRate);
	}, n = (t, n) => {
		let r = A(t), i = A(n);
		return i.points - r.points + (i.bonusCount - r.bonusCount) * e.evolveBonusW + e.evolveTbW;
	}, r = (e) => [
		...e[1],
		...e[2],
		...e[3],
		...e.rare,
		...e.legendary
	], i = (e, t, i) => {
		let a = e.players[t], o = () => {
			for (; Je(a.tokens) > 10;) {
				let t = null, n = Infinity;
				for (let i of z) {
					if (a.tokens[i] <= 0) continue;
					let o = i === "master" ? 999 : Ze(r(e.market), a.bonuses, i);
					o < n && (n = o, t = i);
				}
				if (!t) break;
				--a.tokens[t], e.bank[t] += 1;
			}
		};
		if (i.type === "take") {
			for (let t of i.gems) a.tokens[t] += 1, --e.bank[t];
			o();
			return;
		}
		if (i.type === "reserve") {
			if ("cardId" in i) {
				let n = [
					1,
					2,
					3
				].find((t) => e.market[t].includes(i.cardId));
				n && (e.market[n] = e.market[n].filter((e) => e !== i.cardId)), t === e.myRid && e.myReserved.push(i.cardId);
			}
			e.bank.master > 0 && (--e.bank.master, a.tokens.master += 1, o());
			return;
		}
		if (i.type === "catch") {
			let r = A(i.cardId), o = G(r, a.bonuses, a.tokens);
			if (!o) return;
			for (let t of w) {
				let n = o.pay[t] ?? 0;
				a.tokens[t] -= n, e.bank[t] += n;
			}
			if (a.tokens.master -= o.master, e.bank.master += o.master, i.from === "market") {
				let t = r.tier;
				e.market[t] = e.market[t].filter((e) => e !== i.cardId);
			} else e.myReserved = e.myReserved.filter((e) => e !== i.cardId);
			a.bonuses[r.bonus] += r.bonusCount, a.points += r.points, a.captured.push(i.cardId);
			let s = t === e.myRid ? e.myReserved : [], c = se(a.captured, s, e.market, a.bonuses), l = null;
			for (let e of c) {
				let t = n(e.baseId, e.targetId);
				(!l || t > l.gain) && (l = {
					...e,
					gain: t
				});
			}
			if (l && l.gain > 0) {
				let t = A(l.baseId), n = A(l.targetId);
				a.captured = a.captured.filter((e) => e !== l.baseId), a.captured.push(l.targetId), a.bonuses[t.bonus] -= t.bonusCount, a.bonuses[n.bonus] += n.bonusCount, a.points += n.points - t.points, e.market[n.tier].includes(l.targetId) ? e.market[n.tier] = e.market[n.tier].filter((e) => e !== l.targetId) : e.myReserved = e.myReserved.filter((e) => e !== l.targetId);
			}
		}
	};
	return (a, o) => {
		let s = a.public, c = s.players.find((e) => e.rid === o.rid);
		if (!c) return null;
		let l = Ye(s), u = r(l), d = a.private?.reserved ?? [];
		if (s.phase === "return") {
			if (s.turn !== o.rid) return null;
			let e = Je(c.tokens) - 10;
			if (e <= 0) return null;
			let t = z.flatMap((e) => Array.from({ length: c.tokens[e] }, () => e));
			if (o.difficulty === "weak") {
				let n = [];
				for (let r = 0; r < e && t.length > 0; r += 1) n.push(t.splice(crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % t.length, 1)[0]);
				return { action: {
					type: "return",
					gems: n
				} };
			}
			let n = (e) => e === "master" ? 999 : Ze(u, c.bonuses, e) + c.tokens[e] * .1, r = z.filter((e) => c.tokens[e] > 0).sort((e, t) => n(e) - n(t)), i = [];
			for (; i.length < e;) {
				let e = r.find((e) => c.tokens[e] > i.filter((t) => t === e).length);
				if (!e) break;
				i.push(e);
			}
			return { action: {
				type: "return",
				gems: i
			} };
		}
		if (s.phase === "evolve") {
			if (s.turn !== o.rid) return null;
			let e = se(c.captured, d, l, c.bonuses);
			if (e.length === 0) return { action: { type: "skipEvolve" } };
			if (o.difficulty === "weak") {
				if (crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 2 == 0) return { action: { type: "skipEvolve" } };
				let t = qe(e);
				return { action: {
					type: "evolve",
					baseId: t.baseId,
					targetId: t.targetId
				} };
			}
			let t = null;
			for (let r of e) {
				let e = n(r.baseId, r.targetId);
				(!t || e > t.gain) && (t = {
					...r,
					gain: e
				});
			}
			return t && t.gain > 0 ? { action: {
				type: "evolve",
				baseId: t.baseId,
				targetId: t.targetId
			} } : { action: { type: "skipEvolve" } };
		}
		if (s.phase !== "play" || s.turn !== o.rid) return null;
		let f = d.length < 3, p = (e, t, n, i, a, o) => {
			let s = [];
			for (let t of r(e)) G(A(t), i, n) && s.push({
				type: "catch",
				cardId: t,
				from: "market"
			});
			for (let e of a) G(A(e), i, n) && s.push({
				type: "catch",
				cardId: e,
				from: "reserved"
			});
			for (let e of Xe(t)) s.push({
				type: "take",
				gems: e
			});
			if (!o) for (let t of [
				1,
				2,
				3
			]) for (let n of e[t]) s.push({
				type: "reserve",
				cardId: n
			});
			return s;
		};
		if (o.difficulty === "weak") {
			let e = p(l, s.bank, c.tokens, c.bonuses, d, !f);
			if (f) for (let t of s.market) (t.tier === 1 || t.tier === 2 || t.tier === 3) && t.deckCount > 0 && e.push({
				type: "reserve",
				tier: t.tier
			});
			return e.length > 0 ? { action: qe(e) } : { action: { type: "pass" } };
		}
		let m = s.lastRound ? 1 : Infinity, h = s.players.filter((e) => e.rid !== o.rid), g = [...u, ...d], _ = (t, r) => {
			let i = A(t), a = i.points + e.engineW;
			if (i.evolve) {
				let o = i.stage + 1, s = r.filter((e) => {
					let t = A(e);
					return t.chain === i.chain && t.stage === o;
				});
				s.length > 0 && (a += Math.max(...s.map((e) => n(t, e))) * e.evolveW);
			}
			return a;
		}, v = (e, n, r) => e.map((i) => {
			let a = A(i);
			return {
				id: i,
				eff: _(i, e) / (t(a.cost, a.masterCost, r, n) + 1)
			};
		}).sort((e, t) => t.eff - e.eff).slice(0, 3).map((e) => e.id), y = (t, r, i) => {
			let a = e.pointsW * t.points + e.masterW * t.tokens.master - e.hoardW * Math.max(0, Je(t.tokens) - 10);
			for (let n of w) {
				if (t.bonuses[n] <= 0) continue;
				let r = 0;
				for (let e of i) (A(e).cost[n] ?? 0) > t.bonuses[n] && (r += 1);
				a += e.engineW * t.bonuses[n] * Math.min(r, 4);
			}
			let o = r.map((e) => {
				let n = A(e), r = n.masterCost, i = 0;
				for (let e of w) {
					let a = n.cost[e] ?? 0;
					r += a, i += Math.min(t.bonuses[e], a) + Math.min(t.tokens[e], Math.max(0, a - t.bonuses[e]));
				}
				return {
					id: e,
					total: r,
					cov: i
				};
			}), s = o.reduce((e, t) => e + Math.max(0, t.total - t.cov), 0), c = s > t.tokens.master && s > 0 ? t.tokens.master / s : 1;
			for (let e of o) e.total > 0 && (a += _(e.id, i) * ((e.cov + Math.min(t.tokens.master, Math.max(0, e.total - e.cov)) * c) / e.total));
			for (let r of t.captured) {
				let o = A(r);
				if (!o.evolve) continue;
				let s = o.stage + 1, c = i.filter((e) => {
					let t = A(e);
					return t.chain === o.chain && t.stage === s;
				});
				if (c.length === 0) continue;
				let l = Math.min(1, t.bonuses[o.evolve.color] / o.evolve.count);
				a += l * Math.max(...c.map((e) => n(r, e))) * e.evolveW;
			}
			return a;
		}, b = (t, n, a, o) => {
			let s = t.players[n], c = s.points;
			if (m <= 1) return i(t, n, o), e.pointsW * (s.points - c);
			let l = () => [...r(t.market), ...n === t.myRid ? t.myReserved : []], u = y(s, a, l()), d = Je(s.tokens), f = o.type === "take" && d + o.gems.length > 10 || o.type === "reserve" && t.bank.master > 0 && d + 1 > 10;
			i(t, n, o);
			let p = o.type === "catch" ? a.filter((e) => e !== o.cardId) : a, h = y(s, p, l()) - u;
			if (f && (h -= e.returnW), o.type === "reserve" && (h += e.reserveBaseW, "tier" in o && (h += e.blindW * o.tier)), o.type === "catch" && o.from === "market" || o.type === "reserve" && "cardId" in o) {
				let r = o.cardId;
				for (let i of Object.keys(t.players)) {
					if (i === n) continue;
					let a = t.players[i];
					if (G(A(r), a.bonuses, a.tokens)) {
						h += e.denyW * (.5 + A(r).points), a.points + A(r).points >= 18 && (h += e.denyEndW * (.5 + A(r).points));
						break;
					}
				}
			}
			return h;
		}, x = () => ({
			market: Object.fromEntries(s.market.map((e) => [e.tier, [...e.cards]])),
			bank: { ...s.bank },
			players: Object.fromEntries(s.players.map((e) => [e.rid, {
				tokens: { ...e.tokens },
				bonuses: { ...e.bonuses },
				points: e.points,
				captured: [...e.captured]
			}])),
			myReserved: [...d],
			myRid: o.rid
		}), S = (n, r, i, a) => {
			let o = { ...r }, s = { ...i }, c = a, l = [...n], u = 0;
			for (let n = 0; n < 24 && c < 18; n += 1) {
				let n = null, r = 0, i = 0;
				for (let a of l) {
					let c = A(a), l = t(c.cost, c.masterCost, s, o), u = (c.points + e.engineW) / (l + 1);
					u > i && (i = u, n = a, r = l);
				}
				if (!n) break;
				u += r + 1;
				let a = A(n);
				for (let e of w) {
					let t = Math.max(0, (a.cost[e] ?? 0) - s[e]), n = Math.min(o[e], t);
					o[e] -= n;
					let r = Math.min(o.master, t - n);
					o.master -= r;
				}
				o.master -= Math.min(o.master, a.masterCost), s[a.bonus] += a.bonusCount, c += a.points, l.splice(l.indexOf(n), 1);
			}
			return c >= 18 ? u : 99 + (18 - c);
		}, C = p(l, s.bank, c.tokens, c.bonuses, d, !f);
		if (f) for (let e of s.market) (e.tier === 1 || e.tier === 2 || e.tier === 3) && e.deckCount > 0 && C.push({
			type: "reserve",
			tier: e.tier
		});
		if (C.length === 0) return { action: { type: "pass" } };
		let T = m <= 1 ? [] : v(g, c.tokens, c.bonuses), E = 0;
		if (m > 1 && e.raceW > 0) {
			let e = S(g, c.tokens, c.bonuses, c.points), t = Infinity;
			for (let e of h) t = Math.min(t, S(u, e.tokens, e.bonuses, e.points));
			E = Math.max(-1, Math.min(1, (e - t) / 10));
		}
		let D = [];
		for (let t of C) {
			let n = b(x(), o.rid, T, t);
			E !== 0 && t.type === "catch" && (n += e.raceW * E * e.pointsW * A(t.cardId).points), n += e.noiseW > 0 ? (Ke() - .5) * e.noiseW : 0, D.push({
				action: t,
				score: n
			});
		}
		if (D.sort((e, t) => t.score - e.score), e.searchK > 0 && e.oppRespW > 0) {
			let t = s.players.findIndex((e) => e.rid === o.rid), n = s.players.length;
			for (let a of D.slice(0, e.searchK)) {
				let c = x();
				i(c, o.rid, a.action);
				let l = 0, u = 0;
				for (let i of h) {
					let a = c.players[i.rid], o = m <= 1 ? [] : v(r(c.market), a.tokens, a.bonuses), d = p(c.market, c.bank, a.tokens, a.bonuses, [], i.reservedCount >= 3), f = 0;
					for (let e of d) {
						let t = b({
							market: Object.fromEntries(Object.entries(c.market).map(([e, t]) => [e, [...t]])),
							bank: { ...c.bank },
							players: structuredClone(c.players),
							myReserved: [],
							myRid: i.rid
						}, i.rid, o, e);
						t > f && (f = t);
					}
					let h = (s.players.findIndex((e) => e.rid === i.rid) - t + n) % n, g = e.oppDistW ** (h - 1);
					l += g * f, u += g;
				}
				a.score -= e.oppRespW * (u > 0 ? l / u : 0);
			}
			D.sort((e, t) => t.score - e.score);
		}
		return { action: D[0].action };
	};
}
var et = $e(), tt = {
	poke: "games.splendorpokemon.ball.poke",
	great: "games.splendorpokemon.ball.great",
	ultra: "games.splendorpokemon.ball.ultra",
	heal: "games.splendorpokemon.ball.heal",
	quick: "games.splendorpokemon.ball.quick",
	master: "games.splendorpokemon.ball.master"
};
function nt(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t, (n.get(t) ?? 0) + 1);
	return [...n].map(([e, n]) => n > 1 ? t("games.splendorpokemon.hintBallCount", {
		ball: t(tt[e]),
		n
	}) : t(tt[e])).join(" ");
}
var rt = (e, t, n) => {
	switch (e.type) {
		case "take": return n("games.splendorpokemon.hintTake", { gems: nt(e.gems, n) });
		case "catch": {
			let t = A(e.cardId);
			return n("games.splendorpokemon.hintCatch", {
				name: n(t.nameKey),
				points: t.points
			});
		}
		case "reserve": return "tier" in e ? n("games.splendorpokemon.hintBlindReserve", { tier: e.tier }) : n("games.splendorpokemon.hintReserve", { name: n(A(e.cardId).nameKey) });
		case "return": return n("games.splendorpokemon.hintReturn", { gems: nt(e.gems, n) });
		case "evolve": return n("games.splendorpokemon.hintEvolve", {
			base: n(A(e.baseId).nameKey),
			target: n(A(e.targetId).nameKey)
		});
		case "skipEvolve": return n("games.splendorpokemon.hintSkipEvolve");
		case "pass": return n("games.splendorpokemon.pass");
	}
}, it = 5;
function at(e, t) {
	let n = t ? e.anchor(`seat:${t}`) : null;
	return n ? {
		x: n.x + n.w / 2 - 14,
		y: n.y + n.h / 2 - 14,
		w: 28,
		h: 28
	} : null;
}
function ot(e, t) {
	let n = e.anchor(`bank-token:${t}`);
	if (n) return n;
	let r = e.anchor(`bank:${t}`);
	return r ? {
		x: r.x + r.w / 2 - 18.5,
		y: r.y + r.h / 2 - 18.5,
		w: 37,
		h: 37
	} : null;
}
function st(e) {
	let t = Math.min(e.w / 68, e.h / 92), n = 68 * t, r = 92 * t;
	return {
		x: e.x + (e.w - n) / 2,
		y: e.y + (e.h - r) / 2,
		w: n,
		h: r
	};
}
function ct(e, t) {
	let n = e.anchor(`team-strip:${e.myRid}`), r = e.anchor(`team:${e.myRid}:${Me(t)}`);
	if (!n || !r) return null;
	let i = st(r);
	return {
		...i,
		x: Math.max(n.x + 6, Math.min(i.x, n.x + n.w - i.w - 6))
	};
}
function lt(e, t, n) {
	let r = e.anchor(`mrow:${t}`);
	if (!r) return null;
	let i = e.anchor("market-card-size"), a = i?.w ?? 68, o = i?.h ?? 92;
	return {
		x: r.x + n * a * (1 + it / 68),
		y: r.y + (r.h - o) / 2,
		w: a,
		h: o
	};
}
function ut(e) {
	return Array.isArray(e) ? e.filter((e) => typeof e == "string") : [];
}
function dt(e, t, n) {
	return t.from === "market" && typeof t.tier == "string" && typeof t.slot == "number" ? lt(e, t.tier, t.slot) ?? n : t.from === "reserved" && typeof t.slot == "number" ? e.anchor(`rsv:${t.slot}`) ?? n : n;
}
var ft = {
	take(e, t) {
		let n = ut(e.data?.gems), r = at(t, e.rid);
		if (!n.length) return null;
		let i = n.map((n, i) => {
			let a = ot(t, n), o = e.rid === t.myRid ? t.anchor(`held:${t.myRid}:${n}`) : r;
			return !a || !o ? null : /* @__PURE__ */ g(y, {
				from: a,
				to: o,
				ms: 340,
				delay: i * 70,
				children: /* @__PURE__ */ g("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ g(Z, {
						color: n,
						size: a.w
					})
				})
			}, `${n}${i}`);
		}).filter(Boolean);
		return i.length ? {
			ms: 340 + n.length * 70,
			node: i
		} : null;
	},
	return(e, t) {
		let n = ut(e.data?.gems), r = at(t, e.rid);
		if (!n.length || !r) return null;
		let i = n.map((e, n) => {
			let i = ot(t, e);
			return i ? /* @__PURE__ */ g(y, {
				from: r,
				to: i,
				ms: 320,
				delay: n * 60,
				children: /* @__PURE__ */ g("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ g(Z, {
						color: e,
						size: i.w
					})
				})
			}, `${e}${n}`) : null;
		}).filter(Boolean);
		return i.length ? {
			ms: 320 + n.length * 60,
			node: i
		} : null;
	},
	catch(e, t) {
		let n = e.data;
		if (typeof n?.cardId != "string") return null;
		let r = at(t, e.rid);
		if (!r) return null;
		let i = e.rid === t.myRid, a = i ? ct(t, n.cardId) : r;
		if (!a) return null;
		let o = i && n.from === "reserved" && typeof n.slot == "number" ? t.anchor(`reserved-slot:${t.myRid}:${n.slot}`) : null, s = o ? st(o) : dt(t, n, r), c = `team-new:${t.myRid}:${n.cardId}`;
		return {
			ms: 600,
			hide: i && !t.queued && t.anchor(c) ? [c] : void 0,
			node: /* @__PURE__ */ g(y, {
				from: s,
				to: a,
				ms: 420,
				children: /* @__PURE__ */ g("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ g($, {
						id: n.cardId,
						w: s.w,
						h: s.h
					})
				})
			})
		};
	},
	reserve(e, t) {
		let n = e.data, r = at(t, e.rid);
		if (!n || !r) return null;
		let i = e.secret, a = n.blind === !0 ? i?.cardId : n.cardId, o = e.rid === t.myRid, s = typeof a == "string" ? `reserved:${t.myRid}:${a}` : null, c = o ? s && t.anchor(s) : r;
		if (!c) return null;
		let l = o ? st(c) : c, u = null, d = null;
		return n.blind === !0 && typeof n.tier == "number" ? (u = t.anchor(`deck:${n.tier}`), d = typeof i?.cardId == "string" ? /* @__PURE__ */ g("span", {
			className: "inline-flex",
			children: /* @__PURE__ */ g($, {
				id: i.cardId,
				w: u ? u.h * 68 / 92 : void 0,
				h: u?.h
			})
		}) : /* @__PURE__ */ g("span", {
			className: "inline-flex",
			children: /* @__PURE__ */ g(ke, {
				tier: n.tier ?? 1,
				w: u?.w,
				h: u?.h
			})
		})) : typeof n.cardId == "string" && typeof n.tier == "string" && typeof n.slot == "number" && (u = lt(t, n.tier, n.slot), d = /* @__PURE__ */ g("span", {
			className: "inline-flex",
			children: /* @__PURE__ */ g($, {
				id: n.cardId,
				w: u?.w,
				h: u?.h
			})
		})), !u || !d ? null : {
			ms: 500,
			hide: o && !t.queued && s ? [s] : void 0,
			node: /* @__PURE__ */ g(y, {
				from: u,
				to: l,
				ms: 380,
				children: d
			})
		};
	},
	evolve(e, t) {
		let n = e.data;
		if (typeof n?.baseId != "string" || typeof n.targetId != "string") return null;
		let r = at(t, e.rid);
		if (!r) return null;
		let i = dt(t, n, r);
		return {
			ms: 1100,
			node: [/* @__PURE__ */ g(y, {
				from: i,
				to: r,
				ms: 480,
				delay: 150,
				children: /* @__PURE__ */ g("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ g($, {
						id: n.targetId,
						w: i.w,
						h: i.h
					})
				})
			}, "target"), /* @__PURE__ */ g(v, {
				at: r,
				ms: 900,
				delay: 480,
				children: "⬆️"
			}, "evo")]
		};
	}
};
//#endregion
//#region src/games/splendorpokemon/game-over.tsx
function pt({ result: e, public: t, members: r, myRid: o, onPlayAgain: l, onBackToLobby: f }) {
	let p = t, m = c(), h = s((e) => e.locale), v = new Set(p.players.map((e) => e.points)).size < p.players.length, y = l ?? f, S = i(null), [C, w] = a(0);
	return n(() => {
		let e = S.current, t = e?.closest(".spp-over");
		if (!e || !t) return;
		let n = () => {
			let n = matchMedia("(orientation: landscape)").matches && t.clientWidth >= 960 && t.clientHeight >= 600, r = 0;
			if (n) for (let t of e.querySelectorAll(".spp-over-player")) {
				let e = t.querySelector(".spp-over-person"), n = t.querySelector(".spp-over-metrics"), i = t.querySelector(".spp-over-team");
				if (!e || !n || !i) continue;
				let a = getComputedStyle(t), o = getComputedStyle(i);
				r = Math.max(r, e.offsetHeight + n.offsetHeight + parseFloat(a.borderTopWidth) + parseFloat(a.borderBottomWidth) + parseFloat(o.paddingTop) + parseFloat(o.paddingBottom) + 7410 / 52);
			}
			let i = Math.ceil(r);
			w((e) => e === i ? e : i);
		}, r = new ResizeObserver(n);
		r.observe(t), r.observe(e);
		for (let t of e.querySelectorAll(".spp-over-person, .spp-over-metrics")) r.observe(t);
		return n(), () => r.disconnect();
	}, [h, e.ranking.length]), /* @__PURE__ */ g("div", {
		className: "spp-over",
		children: /* @__PURE__ */ _("div", {
			className: "spp-over-layout",
			children: [
				/* @__PURE__ */ g(b, {}),
				/* @__PURE__ */ _("header", {
					className: "spp-over-heading",
					children: [/* @__PURE__ */ g("h1", { children: m("session.result.title") }), v && /* @__PURE__ */ g("p", { children: m("games.splendorpokemon.resultTieBreak") })]
				}),
				/* @__PURE__ */ g("div", {
					ref: S,
					className: "spp-over-main",
					style: { "--spp-over-row-min": `${C}px` },
					children: e.ranking.map((t) => {
						let n = p.players.find((e) => e.rid === t);
						if (!n) return null;
						let i = r.find((e) => e.rid === t), a = i ? x(i, h) : t, s = e.winner.includes(t), c = Ne(n.captured);
						return /* @__PURE__ */ _("section", {
							className: `spp-over-player${s ? " spp-over-player--winner" : ""}`,
							style: { "--spp-over-player": d[(i?.colorIndex ?? 0) % d.length].hex },
							children: [
								/* @__PURE__ */ _("header", {
									className: "spp-over-person",
									children: [
										/* @__PURE__ */ _("span", {
											className: "spp-over-avatar",
											children: [i && /* @__PURE__ */ g("img", {
												src: u[i.avatar % u.length],
												alt: ""
											}), s && /* @__PURE__ */ g("span", {
												"aria-label": m("games.splendorpokemon.resultWinner"),
												children: "👑"
											})]
										}),
										/* @__PURE__ */ _("div", {
											className: "spp-over-name",
											children: [/* @__PURE__ */ g("h2", {
												title: a,
												children: a
											}), t === o && /* @__PURE__ */ g("small", { children: m("lobby.you") })]
										}),
										/* @__PURE__ */ _("div", {
											className: "spp-over-points",
											children: [/* @__PURE__ */ g(Se, { size: 24 }), /* @__PURE__ */ g("strong", {
												className: "font-mono tabular-nums",
												children: e.scores?.[t] ?? n.points
											})]
										})
									]
								}),
								/* @__PURE__ */ _("div", {
									className: "spp-over-metrics",
									children: [/* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(we, { size: 18 }), m("games.splendorpokemon.resultEvolutions", { n: n.evolvedCount })] }), /* @__PURE__ */ g("span", { children: m("games.splendorpokemon.resultCaptured", { n: n.captured.length }) })]
								}),
								/* @__PURE__ */ g(mt, {
									groups: c,
									bonuses: n.bonuses
								})
							]
						}, t);
					})
				}),
				y ? /* @__PURE__ */ _("div", {
					className: "spp-over-actions safe-b",
					children: [l && /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-base text-white",
						style: { background: j.accent },
						onClick: l,
						children: m("session.result.playAgain")
					}), f && /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-quiet bg-surface",
						onClick: f,
						children: m("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ g("p", {
					className: "spp-over-wait safe-b",
					children: m("session.result.waitHost")
				})
			]
		})
	});
}
function mt({ groups: e, bonuses: t }) {
	let r = c(), o = i(null), [s, l] = a({
		columns: 2,
		width: 114
	});
	return n(() => {
		let t = o.current, n = t?.closest(".spp-over");
		if (!t || !n) return;
		let r = n.querySelector(".spp-over-main"), i = () => {
			let i = getComputedStyle(t), a = parseFloat(i.columnGap) || 0, o = t.clientWidth - parseFloat(i.paddingLeft) - parseFloat(i.paddingRight), s = t.clientHeight - parseFloat(i.paddingTop) - parseFloat(i.paddingBottom);
			if (o <= 0 || e.length === 0) return;
			let c = matchMedia("(orientation: landscape)").matches, u = c && n.clientWidth >= 960 && n.clientHeight >= 600, d = Math.min(e.length, c ? 4 : 3, Math.max(1, Math.floor((o + a) / (114 + a)))), f = (o - a * (d - 1)) / d;
			if (c && matchMedia("(max-height: 480px)").matches && r) {
				let t = getComputedStyle(r), n = r.clientHeight - parseFloat(t.paddingTop) - parseFloat(t.paddingBottom), i = Math.max(1, n - 8) * 52 / 65, s = Math.min(114, i), c = Math.ceil((o + a) / (i + a)), l = Math.max(1, Math.floor((o + a) / (s + a)));
				d = Math.min(e.length, c, l), f = Math.min(i, (o - a * (d - 1)) / d);
			} else if (u && s > 0) {
				let t = {
					columns: 1,
					width: 0,
					empty: e.length
				};
				for (let n = 1; n <= e.length; n += 1) {
					let r = Math.ceil(e.length / n), i = Math.min((o - a * (n - 1)) / n, (s - a * (r - 1)) / r * 52 / 65), c = n * r - e.length;
					(i > t.width + .1 || Math.abs(i - t.width) <= .1 && c < t.empty) && (t = {
						columns: n,
						width: i,
						empty: c
					});
				}
				t.width >= 114 ? (d = t.columns, f = t.width) : (d = Math.min(e.length, Math.max(1, Math.floor((o + a) / (114 + a)))), f = Math.min((o - a * (d - 1)) / d, Math.max(114, s * 52 / 65)));
			}
			let p = {
				columns: d,
				width: Math.floor(f * 10) / 10
			};
			l((e) => e.columns === p.columns && e.width === p.width ? e : p);
		}, a = new ResizeObserver(i);
		return a.observe(t), a.observe(n), r && a.observe(r), i(), () => a.disconnect();
	}, [e.length]), /* @__PURE__ */ g("div", {
		ref: o,
		className: "spp-over-team",
		style: {
			"--spp-over-columns": s.columns,
			"--spp-over-card-w": `${s.width}px`
		},
		children: e.map((e) => /* @__PURE__ */ g("span", {
			className: "spp-over-team-card",
			"aria-label": r("games.splendorpokemon.ui.groupAria", {
				name: r(A(e.id).nameKey),
				n: e.ids.length,
				points: A(e.id).points
			}),
			children: /* @__PURE__ */ g(Oe, {
				id: e.id,
				count: e.ids.length,
				bonuses: t,
				width: s.width,
				height: s.width * 65 / 52
			})
		}, e.id))
	});
}
//#endregion
//#region src/games/splendorpokemon/options.tsx
function ht({ value: e, onChange: t }) {
	let n = c(), r = P.safeParse(e), i = r.success ? r.data : P.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-2",
		children: /* @__PURE__ */ g(C, {
			title: n("games.splendorpokemon.optAltArt"),
			children: [!1, !0].map((e) => /* @__PURE__ */ g(S, {
				name: "splendorpokemon-altart",
				value: String(e),
				checked: i.altArt === e,
				label: n(e ? "games.splendorpokemon.optAltArtOn" : "games.splendorpokemon.optAltArtOff"),
				hint: e ? n("games.splendorpokemon.optAltArtDesc") : void 0,
				accent: j.accent,
				onChange: () => t({
					...i,
					altArt: e
				})
			}, String(e)))
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/splendorpokemon/entry.tsx
var gt = {
	definition: he,
	View: We,
	bot: et,
	describe: rt,
	fx: ft,
	OverView: pt,
	Options: ht,
	locales: {
		zh: {
			name: "璀璨宝石:宝可梦",
			desc: "拿球、捕捉宝可梦、触发进化,先达 18 分获胜",
			rules: "目标:有人达到 18 分触发最后一轮,所有人补平回合数后,分数最高者获胜。\n准备:\n· 1/2/3 阶牌堆各翻 4 张,稀有与传说牌堆各翻 1 张。\n· 球供应:2 人局每种 4 个、3 人局 5 个、4 人局 7 个;大师球恒为 5 个。\n流程(每回合四选一):\n· 拿取 3 个不同种类的球;供应不足 3 种时,有多少种拿多少种。\n· 拿取 2 个同种球;该种供应剩 4 个以上时才可选择。\n· 保留 1 张卡并拿取 1 个大师球:明留场上卡或盲留牌堆顶,最多保留 3 张。\n· 稀有卡与传说卡不可保留。\n· 捕捉 1 张场上或自己保留的卡,支付卡面费用;大师球可抵任意种类。\n进化(不占行动,在回合结束时进行):\n· 已捕捉的卡提供减免标记,捕捉时抵扣费用;稀有与传说卡各提供 2 个。\n· 减免标记达到卡面进化条件时,可将该卡进化为同链下一阶段的卡;每回合最多 1 次,可以不进化。\n· 进化目标须为场上或自己保留中的卡,不支付费用;被进化的卡垫到训练家面板下,不再提供分数与减免。\n结算:\n· 手里球的总数(含大师球)不能超过 10 个,超出部分须在回合结束时退还。\n· 平分则垫到面板下的卡多者胜;再平则面前卡多者胜;再平则共享胜利。",
			turnYou: "轮到你:拿球 / 捕捉 / 保留",
			turnWait: "等 {{name}} 行动…",
			returnPrompt: "球超过 10 个,点选退还 {{n}} 个",
			returnWait: "等 {{name}} 退还超出的球…",
			evolvePrompt: "可以进化:点选面前发光的宝可梦,或跳过",
			evolveWait: "等 {{name}} 决定是否进化…",
			evolveSkip: "跳过",
			bankLabel: "球供应",
			bankGuide: "异色 3 个 / 同色 2 个(供应剩 4 个以上);大师球靠保留取得",
			myBalls: "我的球",
			playerBalls: "{{name}}的球",
			caughtLabel: "面前宝可梦",
			rareLabel: "稀有",
			legendaryLabel: "传说",
			cardAffordable: "可捕捉",
			cardInspect: "查看费用或保留",
			cardStatusAria: "{{card}},{{status}}",
			masterReserveOnly: "大师球,余 {{n}};只能通过保留卡取得",
			bankTokenAria: "{{ball}},余 {{n}}",
			returnBallAria: "退还 {{ball}},持有 {{n}} 个",
			soldOut: "售罄",
			lastRound: "最后一轮",
			resultWinner: "获胜",
			resultEvolutions: "进化次数 {{n}}",
			resultCaptured: "面前卡数 {{n}}",
			resultTieBreak: "平分时依次比较进化次数、面前卡数",
			takeIllegal: "拿满 3 个异色(供应不足有几种拿几种),或 2 个同色(供应剩 4 个以上)",
			takeConfirm: "拿 {{n}} 个",
			cancel: "取消",
			free: "免费",
			cantAfford: "球不够",
			reserve: "保留",
			catch: "捕捉",
			blindReserveDesc: "盲留 {{tier}} 阶牌堆顶一张",
			returnConfirm: "退还",
			pass: "跳过",
			passPrompt: "无处可拿也买不起,跳过本回合",
			reservedLabel: "保留",
			evolveBaseAria: "进化 {{name}}",
			evolveTargetAria: "进化为 {{name}}",
			evolveNeed: "进化条件:{{ball}} 减免 {{n}} 个",
			optAltArt: "异画卡",
			optAltArtDesc: "稀有与传说卡随机替换为异画版本,数据相同",
			optAltArtOn: "启用",
			optAltArtOff: "关闭",
			cardAria: "{{tier}} 阶卡 {{name}}",
			specialAria: "{{tier}}卡 {{name}}",
			reservedCardAria: "保留的 {{name}}",
			deckAria: "{{tier}} 阶牌堆,剩 {{n}} 张",
			specialDeckAria: "{{tier}}牌堆,剩 {{n}} 张",
			tier1: "1 阶",
			tier2: "2 阶",
			tier3: "3 阶",
			ball: {
				poke: "精灵球",
				great: "超级球",
				ultra: "高级球",
				heal: "治愈球",
				quick: "先机球",
				master: "大师球"
			},
			errNotYourTurn: "还没轮到你",
			errBadTake: "拿法不对:异色拿满供应可给的种数,或 2 个同色且供应剩 4 个以上",
			errCantAfford: "球不够,捕捉不了",
			errReserveFull: "最多保留 3 张",
			errBadCard: "这张卡不在那里了",
			errBadReturn: "退还的数量或种类不对",
			errBadEvolve: "不能这样进化",
			errBadPass: "还有能做的动作,不能跳过",
			hintTake: "拿 {{gems}}",
			hintBallCount: "{{ball}}×{{n}}",
			hintCatch: "捕捉 {{name}}({{points}} 分)",
			hintReserve: "保留 {{name}}",
			hintBlindReserve: "盲留 {{tier}} 阶牌堆顶",
			hintReturn: "退还 {{gems}}",
			hintEvolve: "将 {{base}} 进化为 {{target}}",
			hintSkipEvolve: "跳过进化",
			ui: {
				turnShort: "轮到你",
				turnActions: "拿球 · 捕捉 · 保留",
				held: "持球",
				owned: "持有",
				discount: "减免",
				discountShort: "减免",
				pay: "支付",
				score: "分数",
				stage: "{{n}} 阶",
				currentStage: "{{n}} 阶 · 当前",
				caughtStage: "已捕捉 · {{n}} 阶",
				finalStage: "最终阶段",
				noEvolution: "无进化",
				endTurnEvolution: "回合末进化",
				evolve: "进化",
				insufficient: "条件未满足",
				chooseTarget: "点选发光的进化目标",
				discountNeed: "减免 ≥{{n}}",
				discountProgress: "减免 {{n}}/{{need}}",
				you: "你",
				offline: "离线",
				bot: "机器人",
				emptyTeam: "还没有捕捉宝可梦",
				playerSummary: "{{name}}，{{points}} 分，持球 {{tokens}}，已捕捉 {{caught}} 张，保留 {{reserved}} 张，进化 {{evolved}} 次",
				groupAria: "{{name}}，{{n}} 张，单张 {{points}} 分",
				lock: "锁",
				totalBalls: "持球 {{n}} / 10",
				totalReserved: "保留 {{n}} / 3",
				skipEvolution: "跳过进化",
				reserveFull: "保留已满",
				viewCard: "查看 {{name}}",
				returnSelected: "已选 {{n}} / {{need}}",
				shortNames: {
					onix: "大岩蛇",
					wobbuffet: "果然翁",
					psyduck: "可达鸭",
					meowth: "喵喵",
					pikachu: "皮卡丘"
				}
			},
			card: {
				nidoran: "尼多兰",
				nidorina: "尼多娜",
				nidoqueen: "尼多后",
				gastly: "鬼斯",
				haunter: "鬼斯通",
				gengar: "耿鬼",
				bulbasaur: "妙蛙种子",
				ivysaur: "妙蛙草",
				venusaur: "妙蛙花",
				pidgey: "波波",
				pidgeotto: "比比鸟",
				pidgeot: "大比鸟",
				geodude: "小拳石",
				graveler: "隆隆石",
				golem: "隆隆岩",
				charmander: "小火龙",
				charmeleon: "火恐龙",
				charizard: "喷火龙",
				oddish: "走路草",
				gloom: "臭臭花",
				vileplume: "霸王花",
				weedle: "独角虫",
				kakuna: "铁壳蛹",
				beedrill: "大针蜂",
				dratini: "迷你龙",
				dragonair: "哈克龙",
				dragonite: "快龙",
				bellsprout: "喇叭芽",
				weepinbell: "口呆花",
				victreebel: "大食花",
				machop: "腕力",
				machoke: "豪力",
				machamp: "怪力",
				squirtle: "杰尼龟",
				wartortle: "卡咪龟",
				blastoise: "水箭龟",
				poliwag: "蚊香蝌蚪",
				poliwhirl: "蚊香君",
				poliwrath: "蚊香泳士",
				caterpie: "绿毛虫",
				metapod: "铁甲蛹",
				butterfree: "巴大蝶",
				abra: "凯西",
				kadabra: "勇基拉",
				alakazam: "胡地",
				eevee: "伊布",
				ditto: "百变怪",
				snorlax: "卡比兽",
				lapras: "拉普拉斯",
				aerodactyl: "化石翼龙",
				mewtwo: "超梦",
				mew: "梦幻",
				moltres: "火焰鸟",
				zapdos: "闪电鸟",
				articuno: "急冻鸟",
				onix: "小刚的大岩蛇",
				wobbuffet: "火箭队的果然翁",
				psyduck: "小霞的可达鸭",
				meowth: "火箭队的喵喵",
				pikachu: "小智的皮卡丘",
				meloetta: "美洛耶塔",
				keldeo: "凯路迪欧",
				diancie: "蒂安希",
				victini: "比克提尼",
				zeraora: "捷拉奥拉"
			}
		},
		en: {
			name: "Splendor Pokémon",
			desc: "Take Poké Balls, catch Pokémon, evolve them — first to 18 points wins",
			rules: "Goal: when a player reaches 18 points, the final round is triggered; after all players take equal turns, the highest score wins.\nSetup:\n· Reveal 4 cards from each of the Stage 1/2/3 decks, and 1 each from the Rare and Legendary decks.\n· Ball supply: 4 of each kind with 2 players, 5 with 3, 7 with 4; always 5 Master Balls.\nPlay (choose one per turn):\n· Take 3 balls of different kinds; if fewer kinds are available, take as many as possible.\n· Take 2 balls of the same kind; only if that supply has 4 or more.\n· Reserve 1 card and take 1 Master Ball: reserve a face-up card or the top of a Stage 1/2/3 deck; at most 3 reserved cards.\n· Rare and Legendary cards cannot be reserved.\n· Catch 1 card from the display or your reserved cards by paying its cost; Master Balls count as any kind.\nEvolution (not an action; resolved at end of turn):\n· Caught cards provide discount marks toward future costs; Rare and Legendary cards each provide 2.\n· When your discount marks meet a card’s evolution requirement, you may evolve it into the next stage of its chain; at most once per turn, and you may decline.\n· The evolution target must be in the display or your reserved cards and costs nothing; the evolved-from card is tucked under your trainer board and no longer scores or discounts.\nScoring:\n· You may hold at most 10 balls (including Master Balls) at end of turn; return the excess.\n· Ties are broken by the number of cards tucked under the trainer board, then by cards in front of you; further ties share the win.",
			turnYou: "Your turn: take balls / catch / reserve",
			turnWait: "Waiting for {{name}}…",
			returnPrompt: "Over 10 balls: pick {{n}} to return",
			returnWait: "Waiting for {{name}} to return balls…",
			evolvePrompt: "Evolution available: tap a glowing Pokémon, or skip",
			evolveWait: "Waiting for {{name}} to decide on evolution…",
			evolveSkip: "Skip",
			bankLabel: "Ball Supply",
			bankGuide: "3 different / 2 of one kind (needs 4+ left); Master Balls come from reserving",
			myBalls: "My balls",
			playerBalls: "{{name}}’s balls",
			caughtLabel: "Caught Pokémon",
			rareLabel: "Rare",
			legendaryLabel: "Legendary",
			cardAffordable: "Catchable",
			cardInspect: "View cost or reserve",
			cardStatusAria: "{{card}}, {{status}}",
			masterReserveOnly: "Master Ball, {{n}} left; only gained by reserving",
			bankTokenAria: "{{ball}}, {{n}} left",
			returnBallAria: "Return {{ball}}, holding {{n}}",
			soldOut: "Sold out",
			lastRound: "Final round",
			resultWinner: "Winner",
			resultEvolutions: "Evolutions {{n}}",
			resultCaptured: "Cards in play {{n}}",
			resultTieBreak: "Ties compare evolutions, then cards in play",
			takeIllegal: "Take 3 different kinds (as many as available), or 2 of one kind (needs 4+ left)",
			takeConfirm: "Take {{n}}",
			cancel: "Cancel",
			free: "Free",
			cantAfford: "Need balls",
			reserve: "Reserve",
			catch: "Catch",
			blindReserveDesc: "Reserve the top card of the Stage {{tier}} deck",
			returnConfirm: "Return",
			pass: "Pass",
			passPrompt: "Nothing to take or catch — pass this turn",
			reservedLabel: "Reserved",
			evolveBaseAria: "Evolve {{name}}",
			evolveTargetAria: "Evolve into {{name}}",
			evolveNeed: "Evolution requirement: {{ball}} discount ×{{n}}",
			optAltArt: "Alternate art cards",
			optAltArtDesc: "Rare and Legendary cards may be replaced by alternate-art versions with identical stats",
			optAltArtOn: "On",
			optAltArtOff: "Off",
			cardAria: "Stage {{tier}} card {{name}}",
			specialAria: "{{tier}} card {{name}}",
			reservedCardAria: "Reserved {{name}}",
			deckAria: "Stage {{tier}} deck, {{n}} left",
			specialDeckAria: "{{tier}} deck, {{n}} left",
			tier1: "Stage 1",
			tier2: "Stage 2",
			tier3: "Stage 3",
			ball: {
				poke: "Poké Ball",
				great: "Great Ball",
				ultra: "Ultra Ball",
				heal: "Heal Ball",
				quick: "Quick Ball",
				master: "Master Ball"
			},
			errNotYourTurn: "Not your turn yet",
			errBadTake: "Invalid take: different kinds up to what the supply offers, or 2 of one kind with 4+ left",
			errCantAfford: "Not enough balls to catch",
			errReserveFull: "At most 3 reserved cards",
			errBadCard: "That card is no longer there",
			errBadReturn: "Wrong number or kinds to return",
			errBadEvolve: "Cannot evolve that way",
			errBadPass: "You still have legal moves — cannot pass",
			hintTake: "Take {{gems}}",
			hintBallCount: "{{ball}}×{{n}}",
			hintCatch: "Catch {{name}} ({{points}} pts)",
			hintReserve: "Reserve {{name}}",
			hintBlindReserve: "Blind-reserve the top of the Stage {{tier}} deck",
			hintReturn: "Return {{gems}}",
			hintEvolve: "Evolve {{base}} into {{target}}",
			hintSkipEvolve: "Skip evolution",
			ui: {
				turnShort: "Your turn",
				turnActions: "Take · Catch · Reserve",
				held: "Balls",
				owned: "Held",
				discount: "Discount",
				discountShort: "Disc.",
				pay: "Pay",
				score: "Points",
				stage: "Stage {{n}}",
				currentStage: "{{n}} · Current",
				caughtStage: "Caught · {{n}}",
				finalStage: "Final stage",
				noEvolution: "No evolution",
				endTurnEvolution: "End of turn",
				evolve: "Evolve",
				insufficient: "Not ready",
				chooseTarget: "Tap a glowing evolution target",
				discountNeed: "Discount ≥{{n}}",
				discountProgress: "Discount {{n}}/{{need}}",
				you: "You",
				offline: "Offline",
				bot: "Bot",
				emptyTeam: "No Pokémon caught yet",
				playerSummary: "{{name}}, {{points}} points, {{tokens}} balls, {{caught}} caught, {{reserved}} reserved, {{evolved}} evolutions",
				groupAria: "{{name}}, {{n}} cards, {{points}} points each",
				lock: "Lock",
				totalBalls: "Balls {{n}} / 10",
				totalReserved: "Reserved {{n}} / 3",
				skipEvolution: "Skip evolution",
				reserveFull: "Reserve full",
				viewCard: "View {{name}}",
				returnSelected: "Picked {{n}} / {{need}}",
				shortNames: {
					onix: "Onix",
					wobbuffet: "Wobbuffet",
					psyduck: "Psyduck",
					meowth: "Meowth",
					pikachu: "Pikachu"
				}
			},
			card: {
				nidoran: "Nidoran♀",
				nidorina: "Nidorina",
				nidoqueen: "Nidoqueen",
				gastly: "Gastly",
				haunter: "Haunter",
				gengar: "Gengar",
				bulbasaur: "Bulbasaur",
				ivysaur: "Ivysaur",
				venusaur: "Venusaur",
				pidgey: "Pidgey",
				pidgeotto: "Pidgeotto",
				pidgeot: "Pidgeot",
				geodude: "Geodude",
				graveler: "Graveler",
				golem: "Golem",
				charmander: "Charmander",
				charmeleon: "Charmeleon",
				charizard: "Charizard",
				oddish: "Oddish",
				gloom: "Gloom",
				vileplume: "Vileplume",
				weedle: "Weedle",
				kakuna: "Kakuna",
				beedrill: "Beedrill",
				dratini: "Dratini",
				dragonair: "Dragonair",
				dragonite: "Dragonite",
				bellsprout: "Bellsprout",
				weepinbell: "Weepinbell",
				victreebel: "Victreebel",
				machop: "Machop",
				machoke: "Machoke",
				machamp: "Machamp",
				squirtle: "Squirtle",
				wartortle: "Wartortle",
				blastoise: "Blastoise",
				poliwag: "Poliwag",
				poliwhirl: "Poliwhirl",
				poliwrath: "Poliwrath",
				caterpie: "Caterpie",
				metapod: "Metapod",
				butterfree: "Butterfree",
				abra: "Abra",
				kadabra: "Kadabra",
				alakazam: "Alakazam",
				eevee: "Eevee",
				ditto: "Ditto",
				snorlax: "Snorlax",
				lapras: "Lapras",
				aerodactyl: "Aerodactyl",
				mewtwo: "Mewtwo",
				mew: "Mew",
				moltres: "Moltres",
				zapdos: "Zapdos",
				articuno: "Articuno",
				onix: "Brock's Onix",
				wobbuffet: "Rocket's Wobbuffet",
				psyduck: "Misty's Psyduck",
				meowth: "Rocket's Meowth",
				pikachu: "Ash's Pikachu",
				meloetta: "Meloetta",
				keldeo: "Keldeo",
				diancie: "Diancie",
				victini: "Victini",
				zeraora: "Zeraora"
			}
		}
	}
};
//#endregion
export { gt as default };
