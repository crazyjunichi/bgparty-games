import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { AVATARS as n } from "@bgparty/sdk/avatars";
import { useId as r, useState as i } from "react";
import { createPortal as a } from "react-dom";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useT as s } from "@bgparty/sdk/i18n";
import { IconAdd as c, IconCheck as l, IconZoomIn as u, IconZoomOut as d } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { useWakeLock as p } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { GameOverScreen as _ } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as v, OptionSection as te, OptionSwitch as y } from "@bgparty/sdk/ui/game-options";
//#region src/games/timelessjourneys/data.ts
var b = [
	"science",
	"history",
	"art",
	"philosophy"
], ne = [
	"montesquieu",
	"montagu",
	"addison",
	"craven",
	"goethe",
	"lebrun",
	"keats",
	"byron",
	"shelley",
	"dickens",
	"twain",
	"blessington"
], re = [
	"duel",
	"night",
	"admiration",
	"affinity1",
	"affinity2"
], x = (e) => ({
	kind: "coins",
	n: e
}), S = (e) => ({
	kind: "vp",
	n: e
}), C = (e = 1, t) => ({
	kind: "idea",
	n: e,
	...t ? { idea: t } : {}
}), w = (e = 1, t = 0) => ({
	kind: "move",
	n: e,
	discount: t
}), T = (e = 1) => ({
	kind: "explore",
	n: e
}), E = (e = 1) => ({
	kind: "talk",
	n: e
}), D = (e = 1, t = !1) => ({
	kind: "letter",
	n: e,
	different: t
}), O = (e = 1, t = !1) => ({
	kind: "write",
	n: e,
	different: t
}), k = { kind: "discuss" }, A = (e = 0, t = !1) => ({
	kind: "buy",
	discount: e,
	immediate: t
}), j = (e, ...t) => ({
	kind: "pay",
	coins: e,
	then: t
}), M = (...e) => ({
	kind: "choice",
	options: e
}), ie = M([j(1, C())], [j(3, C(2))]), N = (e, t, n, r, i, ...a) => ({
	id: `a${e}`,
	number: e,
	level: t,
	category: n,
	effects: a,
	score: typeof r == "number" ? {
		kind: "fixed",
		n: r
	} : r,
	copies: i
}), ae = [
	N(1, 1, "travel", 1, 2, w(), j(1, w())),
	N(2, 1, "travel", 0, 2, x(1), T()),
	N(3, 1, "travel", 1, 2, M([T()], [w()])),
	N(4, 1, "inspiration", 1, 1, ie),
	N(5, 1, "inspiration", 1, 1, M([x(2)], [{
		kind: "exchange",
		n: 2
	}])),
	N(6, 1, "inspiration", 1, 2, x(1), O()),
	N(7, 1, "inspiration", 2, 2, x(1), k),
	N(8, 1, "friendship", 1, 2, M([D()], [E()])),
	N(9, 1, "friendship", 0, 2, x(1), E()),
	N(10, 1, "friendship", 0, 2, x(1), D()),
	N(11, 1, "festivities", 2, 2, x(1), w()),
	N(12, 1, "festivities", 2, 2, C()),
	N(13, 1, "festivities", 2, 2, x(2), S(1)),
	N(14, 1, "festivities", 2, 1, S(1), D()),
	N(15, 2, "travel", 0, 2, T(), w()),
	N(16, 2, "travel", 2, 1, w(1, 2)),
	N(17, 2, "festivities", 3, 2, S(1), E()),
	N(18, 2, "travel", 0, 1, T(2)),
	N(19, 2, "inspiration", 1, 2, O(), k),
	N(20, 2, "inspiration", 2, 2, M([C()], [O()])),
	N(21, 2, "inspiration", 2, 2, M([C()], [k])),
	N(22, 2, "friendship", 0, 2, D(), E()),
	N(23, 2, "friendship", 3, 2, D(), j(1, D())),
	N(24, 2, "friendship", 0, 2, E(2)),
	N(25, 2, "festivities", 3, 1, x(1), w(2)),
	N(26, 2, "festivities", 3, 2, x(2), O()),
	N(27, 2, "festivities", 3, 2, A(2)),
	N(28, 2, "travel", 2, 2, w(2)),
	N(29, 3, "travel", 2, 1, M([T(2)], [w(2)])),
	N(30, 3, "travel", 2, 1, w(1, 2), w()),
	N(31, 3, "travel", 0, 1, T(), w(1, 2)),
	N(32, 3, "inspiration", 4, 1, j(1, C()), O()),
	N(33, 3, "inspiration", 3, 1, C(), k),
	N(34, 3, "inspiration", 0, 1, C(), j(1, O(2, !0))),
	N(35, 3, "friendship", 2, 1, M([D(2, !0)], [E(2)])),
	N(36, 3, "friendship", 2, 1, j(1, D(3, !0))),
	N(37, 3, "friendship", 3, 1, D(2, !0), j(1, E())),
	N(38, 3, "festivities", 3, 1, A(0, !0)),
	N(39, 3, "festivities", 3, 1, T(2), w()),
	N(40, 3, "festivities", 3, 1, x(1), {
		kind: "letter",
		n: 1,
		any: !0
	}),
	N(41, 3, "festivities", 2, 1, x(1), O(2, !0)),
	N(42, 3, "travel", 2, 1, M([T(2)], [{ kind: "reactivate" }])),
	N(43, 3, "travel", {
		kind: "travel",
		n: 4,
		per: 2
	}, 1, w(2)),
	N(44, 3, "travel", {
		kind: "tiles",
		n: 1
	}, 1, T(2)),
	N(45, 3, "travel", {
		kind: "contacts",
		n: 2
	}, 1, T(), w()),
	N(46, 3, "inspiration", {
		kind: "inspiration",
		n: 4,
		per: 2
	}, 1, O(), k),
	N(47, 3, "inspiration", {
		kind: "writtenIdeas",
		n: 2,
		per: 3
	}, 1, j(1, C()), O()),
	N(48, 3, "inspiration", {
		kind: "cafes",
		n: 2,
		max: 8
	}, 1, M([C()], [k])),
	N(49, 3, "friendship", {
		kind: "reserveIdeas",
		n: 2,
		max: 8
	}, 1, D(), E()),
	N(50, 3, "friendship", {
		kind: "friendship",
		n: 4,
		per: 2
	}, 1, D(2, !0)),
	N(51, 3, "friendship", {
		kind: "coins",
		n: 1,
		max: 8
	}, 1, E(2)),
	N(52, 3, "festivities", {
		kind: "level2",
		n: 3,
		per: 2
	}, 1, x(1), w(2)),
	N(53, 3, "festivities", {
		kind: "festivities",
		n: 3,
		per: 2
	}, 1, x(2), O()),
	N(54, 3, "festivities", {
		kind: "level3",
		n: 3,
		per: 2
	}, 1, A(2))
], P = (e, t, ...n) => ({
	id: e,
	number: 0,
	level: 0,
	category: t,
	score: {
		kind: "fixed",
		n: 0
	},
	copies: 1,
	effects: n
}), oe = [
	P("move1", "travel", w()),
	P("move2", "travel", w()),
	P("explore", "travel", T()),
	P("talk", "friendship", E()),
	P("letter", "friendship", D()),
	P("journal", "inspiration", M([O()], [k])),
	...b.map((e) => P(e, "inspiration", C(1, e))),
	P("money", "inspiration", x(2))
], se = Object.fromEntries([...ae, ...oe].map((e) => [e.id, e]));
function F(e) {
	return se[e.split(":")[0]];
}
var ce = M([x(2)], [w()], [A()]), I = [
	[297, 227],
	[754, 313],
	[593, 513],
	[464, 622],
	[622, 781],
	[502, 967],
	[640, 1214],
	[353, 1570],
	[512, 330],
	[405, 416],
	[690, 628],
	[520, 755],
	[410, 775],
	[494, 857],
	[747, 884],
	[618, 959],
	[791, 1065],
	[629, 1036],
	[582, 1124],
	[772, 1330],
	[800, 1478],
	[622, 1650],
	[565, 1332]
], L = [
	[
		0,
		1,
		0
	],
	[
		0,
		8,
		1
	],
	[
		8,
		1,
		1
	],
	[
		8,
		9,
		0
	],
	[
		8,
		2,
		0
	],
	[
		9,
		3,
		1
	],
	[
		2,
		10,
		2
	],
	[
		3,
		10,
		0
	],
	[
		3,
		11,
		2
	],
	[
		10,
		11,
		3
	],
	[
		11,
		12,
		0
	],
	[
		11,
		4,
		0
	],
	[
		12,
		13,
		0
	],
	[
		13,
		5,
		0
	],
	[
		4,
		14,
		0
	],
	[
		14,
		15,
		2
	],
	[
		15,
		5,
		0
	],
	[
		14,
		16,
		0
	],
	[
		5,
		17,
		0
	],
	[
		17,
		18,
		0
	],
	[
		18,
		6,
		0
	],
	[
		16,
		6,
		2
	],
	[
		6,
		19,
		0
	],
	[
		19,
		20,
		0
	],
	[
		20,
		21,
		3
	],
	[
		21,
		7,
		0
	],
	[
		18,
		22,
		0
	],
	[
		22,
		7,
		6
	],
	[
		5,
		7,
		6
	],
	[
		1,
		7,
		6
	]
];
function R(e) {
	let t = I.map(() => Infinity);
	t[e] = 0;
	let n = [e];
	for (; n.length;) {
		let e = n.shift();
		for (let [r, i] of L) {
			let a = r === e ? i : i === e ? r : -1;
			a >= 0 && t[a] > t[e] + 1 && (t[a] = t[e] + 1, n.push(a));
		}
	}
	return t;
}
var z = (e, t, n, r) => [
	e,
	t,
	n,
	r
], B = [
	{
		bonus: [x(1)],
		discussions: [[z(0, 1, 0, 0), z(0, 0, 0, 1)], [z(0, 0, 1, 0), z(1, 0, 0, 0)]],
		points: [3, 1]
	},
	{
		bonus: [C(1, "art")],
		discussions: [[z(0, 1, 1, 0)], [z(1, 0, 0, 1)]],
		points: [5, 3]
	},
	{
		bonus: [C(1, "science")],
		discussions: [[z(2, 1, 0, 0)], [z(0, 0, 2, 1)]],
		points: [6, 4]
	},
	{
		bonus: [C(1, "history")],
		discussions: [[z(1, 0, 0, 2)], [z(0, 2, 1, 0)]],
		points: [8, 6]
	},
	{
		bonus: [C(1, "philosophy")],
		discussions: [[z(2, 0, 2, 0)], [z(0, 2, 0, 2)]],
		points: [11, 9]
	},
	{
		bonus: [D()],
		discussions: [[z(0, 0, 5, 0)], [z(5, 0, 0, 0)]],
		points: [13, 10]
	},
	{
		bonus: [S(1)],
		discussions: [[z(0, 0, 0, 5)], [z(0, 5, 0, 0)]],
		points: [15, 12]
	},
	{
		bonus: [O()],
		discussions: [[z(2, 2, 1, 0)], [z(1, 0, 2, 2)]],
		points: [17, 13]
	}
], le = [
	[
		[E()],
		[C(1, "history")],
		[C(1, "science")],
		[D()],
		[w()],
		[x(2)]
	],
	[
		[O()],
		[C(1, "art")],
		[C(1, "philosophy")],
		[k],
		[ie],
		[x(1), A()]
	],
	[
		[x(1), D()],
		[C(1, "history")],
		[C(1, "science")],
		[x(1), E()],
		[x(1), w()],
		[ie]
	],
	[
		[C(1, "philosophy")],
		[x(3)],
		[x(1), k],
		[x(2), A()],
		[C(1, "art")],
		[x(1), O()]
	],
	[
		[x(1), S(1)],
		[x(1), w()],
		[C()],
		[E(), S(1)],
		[w(2)],
		[x(3)]
	],
	[
		[x(2), A()],
		[M([k], [O()])],
		[{
			kind: "teleport",
			cities: [2, 3]
		}],
		[C()],
		[C(1, "philosophy"), C(1, "history")],
		[ie]
	],
	[
		[w(1, 2)],
		[{
			kind: "teleport",
			cities: [5, 4]
		}],
		[C(1, "art"), C(1, "science")],
		[M([x(2)], [S(2)])],
		[D(2, !0)],
		[x(4)]
	],
	[
		[x(2), A()],
		[M([E()], [D()])],
		[{
			kind: "teleport",
			cities: [3, 5]
		}],
		[x(1), S(2)],
		[O(2)],
		[C(), j(1, C())]
	]
], ue = [
	[[x(2)], [C(1, "art")]],
	[[C(1, "science")], [w()]],
	[[j(1, C())], [C(1, "history")]],
	[[C(1, "philosophy")], [O()]],
	[[{
		kind: "exchange",
		n: 1,
		coinsInstead: 3
	}], [{ kind: "flipMove" }]],
	[[x(1), S(1)], [{
		kind: "pay",
		vp: 1,
		then: [C()]
	}]],
	[[M([C(1, "art")], [C(1, "history")])], [x(2), S(1)]],
	[[M([C(1, "science")], [C(1, "philosophy")])], [A()]],
	[[M([C(1, "art")], [C(1, "philosophy")])], [w(), S(1)]],
	[[M([C(1, "science")], [C(1, "history")])], [j(2, O(2, !0))]],
	[[j(2, {
		kind: "idea",
		n: 2,
		different: !0
	})], [j(2, S(3))]],
	[[{ kind: "removeI" }], [{
		kind: "discuss",
		any: !0
	}]]
], de = [
	{
		city: 2,
		types: ["history", "philosophy"]
	},
	{
		city: 3,
		types: ["art", "history"]
	},
	{
		city: 6,
		types: ["philosophy", "art"]
	},
	{
		city: 7,
		types: ["art", "philosophy"]
	},
	{
		city: 4,
		types: ["art", "science"]
	},
	{
		city: 5,
		types: ["history", "art"]
	},
	{
		city: 0,
		types: ["history", "philosophy"]
	},
	{
		city: 1,
		types: ["art", "history"]
	},
	{
		city: 4,
		types: ["philosophy", "history"]
	},
	{
		city: 5,
		types: ["science", "philosophy"]
	},
	{
		city: 0,
		types: ["science", "art"]
	},
	{
		city: 1,
		types: ["philosophy", "science"]
	},
	{
		city: 2,
		types: ["science", "art"]
	},
	{
		city: 3,
		types: ["philosophy", "science"]
	},
	{
		city: 6,
		types: ["science", "history"]
	},
	{
		city: 7,
		types: ["history", "science"]
	}
], fe = [
	0,
	1,
	2,
	3,
	6,
	10,
	15,
	21,
	28
], pe = [
	0,
	1,
	2,
	3,
	4,
	6,
	9,
	13,
	18
], me = [
	0,
	1,
	3,
	7,
	13,
	20
], he = {
	A: [
		[
			2,
			1,
			3
		],
		[
			3,
			2,
			1
		],
		[
			4,
			3,
			5
		],
		[
			6,
			7,
			3
		],
		[
			7,
			5,
			7
		]
	],
	B: [
		[
			2,
			1,
			3
		],
		[
			3,
			4,
			1
		],
		[
			4,
			6,
			3
		],
		[
			5,
			5,
			5
		],
		[
			6,
			7,
			4
		]
	],
	C: [
		[
			2,
			1,
			3
		],
		[
			3,
			2,
			4
		],
		[
			4,
			3,
			2
		],
		[
			6,
			7,
			5
		],
		[
			7,
			5,
			6
		]
	],
	D: [
		[
			2,
			1,
			3
		],
		[
			4,
			2,
			4
		],
		[
			4,
			3,
			2
		],
		[
			3,
			7,
			5
		],
		[
			5,
			6,
			6
		]
	]
}, V = {
	A: [
		[x(2)],
		[C(1, "art")],
		[O()]
	],
	B: [
		[k],
		[C(1, "history")],
		[w()]
	],
	C: [
		[S(2)],
		[C(1, "science")],
		[A()]
	],
	D: [
		[T()],
		[C(1, "philosophy")],
		[D()]
	]
}, ge = [
	[
		3,
		2,
		4,
		2,
		2
	],
	[
		2,
		3,
		2,
		4,
		2
	],
	[
		2,
		2,
		3,
		2,
		4
	]
], _e = {
	A: [
		"montesquieu",
		"montagu",
		"addison"
	],
	B: [
		"craven",
		"goethe",
		"lebrun"
	],
	C: [
		"keats",
		"byron",
		"shelley"
	],
	D: [
		"dickens",
		"twain",
		"blessington"
	]
}, ve = {
	id: "timelessjourneys",
	tier: "beta",
	nameKey: "games.timelessjourneys.name",
	descKey: "games.timelessjourneys.desc",
	rulesKey: "games.timelessjourneys.rules",
	icon: "🧳",
	iconImg: "games/timelessjourneys.webp",
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	accent: "#317f83",
	releasedAt: "2026-10-19T18:23:03+08:00",
	mechanics: [
		"hand-management",
		"engine-building",
		"set-collection",
		"grid-movement"
	],
	interactionTags: [],
	search: {
		py: "yong heng lv tu yi da li da you xue yong heng zhi lv yi da li zhuang you",
		init: "yhltydldyx yhzlydlzy"
	},
	hotseat: "cover"
}, ye = t.enum(b), be = t.tuple([
	t.int().nonnegative(),
	t.int().nonnegative(),
	t.int().nonnegative(),
	t.int().nonnegative()
]), xe = t.int().min(0).max(7), Se = t.int().min(0).max(22), H = t.int().min(0).max(1), Ce = t.object({
	mode: t.enum([
		"intro",
		"A",
		"B",
		"C",
		"D",
		"random",
		"custom"
	]).default("intro"),
	gazette: t.enum([
		"random",
		"A",
		"B",
		"C",
		"D"
	]).default("random"),
	custom: t.tuple([
		t.enum(ne),
		t.enum(ne),
		t.enum(ne)
	]).refine((e) => new Set(e).size === 3).default([
		"montesquieu",
		"montagu",
		"shelley"
	]),
	extraMovement: t.boolean().default(!0)
}).prefault({}), we = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().min(1).max(240)
}), t.object({
	type: t.literal("tick"),
	now: t.number().finite()
})]), Te = t.object({
	kind: t.string(),
	n: t.number().optional(),
	idea: ye.optional(),
	coins: t.number().optional(),
	vp: t.number().optional(),
	discount: t.number().optional(),
	different: t.boolean().optional(),
	any: t.boolean().optional(),
	immediate: t.boolean().optional(),
	cities: t.array(xe).optional()
}), Ee = t.object({
	id: t.string(),
	kind: t.enum(/* @__PURE__ */ "play.faceDown.activate.effect.endEffects.endTurn.endChain.skip.branch.pay.move.explore.cityBonus.takeTile.idea.writeIdea.writeTile.writeFriend.talk.traveler.letter.reward.friend.correspond.buy.discuss.exchange.teleport.reactivate.flip.remove.painting.admiration.byron.dickensExplore.dickensDiscuss.useTile.discard".split(".")),
	card: t.string().optional(),
	city: xe.optional(),
	node: Se.optional(),
	local: H.optional(),
	traveler: t.int().min(0).max(2).optional(),
	row: t.int().min(0).max(4).optional(),
	experience: t.enum(re).optional(),
	idea: ye.optional(),
	n: t.number().optional(),
	journal: H.optional(),
	tile: t.int().nonnegative().optional(),
	cost: t.number().optional(),
	points: t.number().optional(),
	ideas: be.optional(),
	effects: t.array(Te).optional()
}), De = t.object({
	id: t.int().min(0).max(15),
	ideas: be,
	tile: t.boolean(),
	friend: t.boolean()
}), Oe = t.object({
	city: xe,
	index: t.int().min(0).max(5),
	used: t.boolean(),
	journal: H.nullable()
}), ke = t.object({
	city: xe,
	local: H,
	journal: H.nullable()
}), Ae = t.object({
	rid: t.string(),
	coins: t.int().nonnegative(),
	vp: t.int(),
	node: Se,
	ideas: be,
	journals: t.array(De).length(2),
	tiles: t.array(Oe),
	friends: t.array(ke),
	paintings: t.array(t.int().min(0).max(4)),
	letters: t.array(t.object({
		city: xe,
		local: H
	})).max(3),
	played: t.array(t.object({
		card: t.string().nullable(),
		faceDown: t.boolean()
	})).max(5),
	handSize: t.int().nonnegative(),
	advancedPlayed: t.int().nonnegative(),
	finalHand: t.array(t.string()).optional()
}), je = t.object({
	journey: t.number(),
	exploration: t.number(),
	journals: t.number(),
	cards: t.number(),
	experiences: t.number(),
	paintings: t.number(),
	total: t.number()
}), Me = t.object({
	round: t.int().min(1).max(5),
	phase: t.enum([
		"action",
		"travelers",
		"market",
		"discard",
		"roundEnd",
		"done"
	]),
	stage: t.enum([
		"play",
		"chain",
		"finish"
	]),
	active: t.string().nullable(),
	first: t.string(),
	players: t.array(Ae),
	gazette: t.enum([
		"A",
		"B",
		"C",
		"D"
	]),
	travelers: t.array(t.enum(ne)).length(3),
	experiences: t.array(t.array(t.object({
		rid: t.string(),
		kind: t.enum(re)
	}).nullable()).length(5)).length(3),
	favors: t.array(t.int().min(0).max(11)).length(8),
	friends: t.array(H.nullable()).length(8),
	remainingTiles: t.array(t.int().nonnegative()).length(8),
	cafes: t.array(t.array(t.array(t.string()).max(2)).length(2)).length(8),
	market: t.array(t.array(t.string())).length(3),
	deckTop: t.array(t.string().nullable()).length(3),
	deckSize: t.array(t.int().nonnegative()).length(3),
	paintings: t.array(t.int().min(0).max(4)),
	task: t.array(Te),
	activeCard: t.string().nullable(),
	scores: t.record(t.string(), je),
	event: t.object({
		kind: t.string(),
		rid: t.string().optional(),
		n: t.number().optional(),
		city: xe.optional(),
		node: Se.optional(),
		card: t.string().optional()
	}).nullable()
}), Ne = t.object({
	hand: t.array(t.string()),
	choices: t.array(Ee)
}), Pe = () => [
	0,
	0,
	0,
	0
], U = (e) => e.reduce((e, t) => e + t, 0), W = (e, t) => e.players.find((e) => e.rid === t), G = (e, t) => {
	let n = e.travelers.indexOf(t);
	return n < 0 ? -1 : he[e.gazette][e.round - 1][n];
}, Fe = (e) => e.tasks[0]?.who ?? (e.phase === "action" || e.phase === "market" || e.phase === "discard" ? e.players[e.turn].rid : null), K = (e, t, n) => {
	e.tasks.unshift(...n.map((e) => ({
		who: t,
		effect: structuredClone(e),
		used: []
	})));
};
function Ie(e, t, n) {
	e.tasks.unshift({
		who: t,
		effect: {
			kind: "cardEffects",
			card: n,
			remaining: structuredClone(F(n).effects),
			previousCard: e.activeCard
		},
		used: []
	}), e.activeCard = n;
}
function q(e, t) {
	let n = e.tasks[0], r = n.effect;
	t !== void 0 && n.used.push(t), "n" in r && r.n > 1 ? --r.n : e.tasks.shift();
}
function J(e, t, n, r = {}) {
	e.event = {
		kind: t,
		...n ? { rid: n } : {},
		...r
	};
}
function Y(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.rngCursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Le(e) {
	e.paintings = e.travelers.includes("lebrun") ? e.paintingDeck.splice(0, e.players.length === 2 ? 2 : 3) : [];
}
function Re(e) {
	let t = e.players.length < 4 ? 2 : 3;
	for (let n = 0; n < 3; n++) e.decks[n].push(...e.market[n]), e.market[n] = e.decks[n].splice(0, t);
}
function ze(t, n, r) {
	let i = {
		seed: r,
		rngCursor: 0,
		revision: 0,
		players: [],
		round: 1,
		first: 0,
		turn: 0,
		phase: "action",
		stage: "play",
		gazette: "A",
		travelers: [],
		experiences: Array.from({ length: 3 }, () => [
			,
			,
			,
			,
			,
		].fill(null)),
		favors: [],
		friends: Array(8).fill(null),
		remainingTiles: [],
		cafes: Array.from({ length: 8 }, () => [[], []]),
		decks: [
			[],
			[],
			[]
		],
		market: [
			[],
			[],
			[]
		],
		paintingDeck: [],
		paintings: [],
		tasks: [],
		chain: [],
		activeCard: null,
		byronUsed: !1,
		dickensUsed: !1,
		travelerStep: 0,
		marketStep: 0,
		scores: {},
		event: null
	}, a = Ce.parse(t);
	i.gazette = a.gazette === "random" ? Y(i, [
		"A",
		"B",
		"C",
		"D"
	])[0] : a.gazette, i.travelers = Y(i, a.mode === "intro" ? [
		"montesquieu",
		"montagu",
		"shelley"
	] : a.mode === "custom" ? a.custom : a.mode === "random" ? Y(i, [...ne]).slice(0, 3) : _e[a.mode]);
	let o = Y(i, a.mode === "intro" ? [
		0,
		1,
		2,
		3
	] : [
		0,
		1,
		2,
		3,
		4,
		5
	]), s = Y(i, a.mode === "intro" ? [
		6,
		7,
		8,
		9
	] : [
		6,
		7,
		8,
		9,
		10,
		11
	]);
	i.favors = [...o.slice(0, 4), ...s.slice(0, 4)];
	for (let t of Y(i, [
		1,
		2,
		3,
		4,
		5,
		6,
		7
	]).slice(0, [
		0,
		0,
		3,
		4,
		6,
		7
	][n.length])) i.friends[t] = e(r, i.rngCursor++, 2);
	i.remainingTiles = Array.from({ length: 8 }, () => Y(i, [
		0,
		1,
		2,
		3,
		4,
		5
	]).slice(0, n.length + 1));
	let c = Y(i, [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7
	]), l = Y(i, [
		8,
		9,
		10,
		11,
		12,
		13,
		14,
		15
	]);
	i.players = n.map((e, t) => ({
		rid: e,
		coins: n.length === 2 ? t + 1 : t < 2 ? 1 : 2,
		vp: 5,
		node: 0,
		ideas: Pe(),
		journals: [c[t], l[t]].map((e) => ({
			id: e,
			ideas: Pe(),
			tile: !1,
			friend: !1
		})),
		tiles: [],
		friends: [],
		paintings: [],
		letters: [],
		played: [],
		advancedPlayed: 0,
		hand: [
			"move1",
			...a.extraMovement ? ["move2"] : [],
			"explore",
			"talk",
			"letter",
			"journal",
			b[t] ?? "money"
		]
	}));
	for (let e = 1; e <= 3; e++) i.decks[e - 1] = Y(i, ae.filter((t) => t.level === e).flatMap((e) => Array.from({ length: e.copies }, (t, n) => `${e.id}:${n}`)));
	return i.paintingDeck = Y(i, Array.from({ length: 5 }, (e, t) => Array(n.length === 2 ? 2 : 3).fill(t)).flat()), Re(i), Le(i), {
		state: i,
		fx: []
	};
}
function X(e) {
	return e.flatMap((e) => e.kind === "cardEffects" ? [{ kind: e.kind }] : e.kind === "choice" ? e.options.flatMap((e, t) => [...t ? [{ kind: "or" }] : [], ...X(e)]) : e.kind === "pay" ? [{
		kind: "pay",
		coins: e.coins,
		vp: e.vp
	}, ...X(e.then)] : e.kind === "teleport" ? [{
		kind: e.kind,
		cities: e.cities
	}] : e.kind === "admiration" || "city" in e && [
		"localBonus",
		"localLink",
		"takeTile",
		"painting"
	].includes(e.kind) ? [{ kind: e.kind }] : [{ ...e }]);
}
function Be(e, t, n) {
	let r = b.indexOf(n), i = W(e, t);
	U(e.players.map((e) => e.ideas[r] + U(e.journals.map((e) => e.ideas[r])))) >= 20 || (i.ideas[r] += 1, i.node === G(e, "twain") && (i.vp += 2), J(e, "idea", t, { n: 1 }));
}
function Ve(e, t) {
	return U(e.players.map((e) => e.ideas[t] + U(e.journals.map((e) => e.ideas[t])))) < 20;
}
function He(e, t, n) {
	n === G(e, "addison") && (W(e, t).vp += 1);
}
function Ue(e, t, n, r) {
	let i = W(e, t);
	i.hand.splice(i.hand.indexOf(n), 1), i.played.push({
		card: n,
		faceDown: r
	}), F(n).level > 0 && (i.advancedPlayed += 1, i.node === G(e, "keats") && (i.vp += 2));
}
function We(e) {
	return e.market.flatMap((t, n) => [...t, ...e.decks[n][0] ? [e.decks[n][0]] : []]);
}
function Ge(e, t) {
	let n = F(t).level - 1, r = e.market[n].indexOf(t);
	r >= 0 ? e.market[n].splice(r, 1) : e.decks[n].shift();
}
function Ke(e, t) {
	return e.cafes.flat(2).filter((e) => e === t).length;
}
function qe(e, t) {
	let n = [];
	for (let r = 0; r <= Math.min(t, e[0]); r++) for (let i = 0; i <= Math.min(t - r, e[1]); i++) for (let a = 0; a <= Math.min(t - r - i, e[2]); a++) {
		let o = t - r - i - a;
		o <= e[3] && n.push([
			r,
			i,
			a,
			o
		]);
	}
	return n;
}
function Je(e) {
	for (; e.tasks[0]?.effect.kind === "cardEffects";) {
		let t = e.tasks[0], n = t.effect;
		if (n.remaining.length > 1) break;
		if (n.remaining.length === 1) {
			K(e, t.who, n.remaining.splice(0, 1));
			break;
		}
		e.tasks.shift(), e.activeCard = n.previousCard;
	}
	e.tasks.length || (e.activeCard = null, e.phase === "action" && e.stage === "chain" && !e.chain.length && (e.stage = "finish"));
}
function Ye(e, t, n = !0) {
	if (Fe(e) !== t || e.phase === "done" || e.phase === "roundEnd") return [];
	let r = [], i = W(e, t), a = e.tasks[0], o = a?.effect, s = (t, n, i) => r.push({
		view: {
			id: `${e.revision}:${t}:${r.length}`,
			kind: t,
			...n
		},
		apply: i
	}), c = () => s("skip", {}, (e) => {
		e.tasks.shift();
	});
	if (o) switch (o.kind) {
		case "cardEffects":
			o.remaining.forEach((n, r) => {
				let i = {
					...e,
					tasks: [{
						who: t,
						effect: n,
						used: []
					}]
				};
				(tt(n) || Ye(i, t, !1).some((e) => e.view.kind !== "skip")) && s("effect", {
					n: r,
					effects: X([n])
				}, (e) => {
					let n = e.tasks[0].effect;
					K(e, t, n.remaining.splice(r, 1));
				});
			}), s("endEffects", {}, (e) => {
				e.tasks.shift(), e.activeCard = o.previousCard;
			});
			break;
		case "coins":
		case "vp":
		case "localBonus": break;
		case "idea":
			if (!o.idea) {
				for (let n = 0; n < 4; n++) Ve(e, n) && (!o.different || !a.used.includes(n)) && s("idea", { idea: b[n] }, (e) => {
					Be(e, t, b[n]), q(e, n);
				});
				c();
			}
			break;
		case "choice":
			o.options.forEach((e, n) => s("branch", {
				n,
				effects: X(e)
			}, (n) => {
				n.tasks.shift(), K(n, t, e);
			})), c();
			break;
		case "pay":
			i.coins >= (o.coins ?? 0) && i.vp >= (o.vp ?? 0) && s("pay", {
				cost: o.coins ?? 0,
				points: o.vp ?? 0,
				effects: X(o.then)
			}, (e) => {
				let n = W(e, t);
				n.coins -= o.coins ?? 0, n.vp -= o.vp ?? 0, e.tasks.shift(), K(e, t, o.then);
			}), c();
			break;
		case "move":
			for (let [e, n, r] of L) {
				let a = e === i.node ? n : n === i.node ? e : -1, c = Math.max(0, r - (o.discount ?? 0));
				a >= 0 && i.coins >= c && s("move", {
					node: a,
					cost: c
				}, (e) => {
					let n = W(e, t);
					n.node = a, n.coins -= c, q(e), J(e, "move", t, { node: a });
				});
			}
			c();
			break;
		case "explore": {
			let n = o.city ?? i.node;
			n < 8 && (!i.tiles.some((e) => e.city === n) && e.remainingTiles[n].length && s("explore", { city: n }, (e) => {
				q(e), He(e, t, n), K(e, t, [{
					kind: "takeTile",
					city: n
				}, ...n === G(e, "lebrun") ? [{
					kind: "painting",
					city: n
				}] : []]);
			}), s("cityBonus", {
				city: n,
				effects: X(B[n].bonus)
			}, (e) => {
				q(e), He(e, t, n), K(e, t, [...B[n].bonus, ...n === G(e, "lebrun") ? [{
					kind: "painting",
					city: n
				}] : []]), J(e, "explore", t, { city: n });
			})), c();
			break;
		}
		case "takeTile":
			for (let n of e.remainingTiles[o.city]) s("takeTile", {
				city: o.city,
				tile: n,
				effects: X(le[o.city][n])
			}, (e) => {
				e.remainingTiles[o.city] = e.remainingTiles[o.city].filter((e) => e !== n), W(e, t).tiles.push({
					city: o.city,
					index: n,
					used: !1,
					journal: null
				}), e.tasks.shift(), J(e, "explore", t, { city: o.city });
			});
			c();
			break;
		case "talk": {
			let n = o.city ?? i.node;
			if (n < 8) {
				for (let r = 0; r < 2; r++) s("talk", {
					city: n,
					local: r,
					effects: X(ue[e.favors[n]][r])
				}, (e) => {
					q(e), He(e, t, n), K(e, t, [{
						kind: "localBonus",
						city: n,
						local: r
					}, {
						kind: "localLink",
						city: n,
						local: r
					}]), J(e, "talk", t, { city: n });
				});
				e.travelers.forEach((r, i) => {
					if (G(e, r) !== n) return;
					let a = e.experiences[i].filter((e) => e?.rid === t);
					if (a.some((e) => e?.kind === "duel")) return;
					let o = e.experiences.flat().filter((e) => e?.rid === t).map((e) => e.kind);
					for (let c of re) if (!(o.includes(c) || c === "duel" && (r === "blessington" || a.length))) for (let r = 0; r < 5; r++) !e.experiences[i][r] && e.players.length >= ge[i][r] && s("traveler", {
						city: n,
						traveler: i,
						row: r,
						experience: c,
						effects: X(V[e.gazette][i])
					}, (e) => {
						q(e), He(e, t, n), e.experiences[i][r] = {
							rid: t,
							kind: c
						}, K(e, t, Array.from({ length: c === "duel" ? 2 : 1 }, () => V[e.gazette][i]).flat()), J(e, "traveler", t, { city: n });
					});
				});
			}
			c();
			break;
		}
		case "letter": {
			let n = o.any ? Array.from({ length: 8 }, (e, t) => [0, 1].map((e) => ({
				city: t,
				local: e
			}))).flat().filter(({ city: e, local: t }) => !i.letters.some((n) => n.city === e && n.local === t)) : i.letters.filter((e) => e.city !== i.node);
			for (let { city: r, local: i } of n) (!o.different || !a.used.includes(r * 2 + i)) && s("letter", {
				city: r,
				local: i,
				effects: X(ue[e.favors[r]][i])
			}, (e) => {
				q(e, r * 2 + i), He(e, t, r), K(e, t, [{
					kind: "localBonus",
					city: r,
					local: i
				}]), J(e, "letter", t, { city: r });
			});
			c();
			break;
		}
		case "localLink": {
			e.friends[o.city] === o.local && s("friend", {
				city: o.city,
				local: o.local
			}, (e) => {
				e.friends[o.city] = null, W(e, t).friends.push({
					city: o.city,
					local: o.local,
					journal: null
				}), e.tasks.shift();
			});
			let n = e.players.flatMap((e) => e.letters.map((t) => ({
				...t,
				rid: e.rid
			}))).filter((e) => e.city === o.city && e.rid !== t), r = i.letters.findIndex((e) => e.city === o.city);
			if (n.length < (e.players.length === 5 ? 3 : 2) && n.filter((e) => e.local === o.local).length < (e.players.length === 5 ? 2 : 1) && (r < 0 || i.letters[r].local !== o.local)) {
				let e = r >= 0 ? [r] : i.letters.length < 3 ? [-1] : i.letters.map((e, t) => t);
				for (let n of e) s("correspond", {
					city: o.city,
					local: o.local,
					...n >= 0 && r < 0 ? { n: i.letters[n].city } : {}
				}, (e) => {
					let r = W(e, t);
					n < 0 ? r.letters.push({
						city: o.city,
						local: o.local
					}) : r.letters[n] = {
						city: o.city,
						local: o.local
					}, e.tasks.shift();
				});
			}
			c();
			break;
		}
		case "write":
			i.journals.forEach((e, n) => {
				if (!(o.different && a.used.includes(n))) {
					for (let r of de[e.id].types) {
						let a = b.indexOf(r);
						i.ideas[a] && e.ideas[a] < 3 && s("writeIdea", {
							journal: n,
							idea: r
						}, (e) => {
							let r = W(e, t);
							--r.ideas[a], r.journals[n].ideas[a] += 1, q(e, n), J(e, "write", t);
						});
					}
					e.tile || i.tiles.forEach((r, i) => {
						r.journal === null && r.city === de[e.id].city && s("writeTile", {
							journal: n,
							tile: i,
							city: r.city
						}, (e) => {
							let r = W(e, t);
							r.tiles[i].journal = n, r.journals[n].tile = !0, q(e, n), J(e, "write", t);
						});
					}), e.friend || i.friends.forEach((e, r) => {
						e.journal === null && s("writeFriend", {
							journal: n,
							n: r,
							city: e.city
						}, (e) => {
							let i = W(e, t);
							i.friends[r].journal = n, i.journals[n].friend = !0, q(e, n), J(e, "write", t);
						});
					});
				}
			}), c();
			break;
		case "discuss":
			if (Ke(e, t) < 6) {
				let n = o.city === void 0 ? o.any ? [
					0,
					1,
					2,
					3,
					4,
					5,
					6,
					7
				] : [.../* @__PURE__ */ new Set([...i.node < 8 ? [i.node] : [], ...i.letters.map((e) => e.city)])] : [o.city];
				for (let r of n) for (let n = 0; n < 2; n++) if (e.cafes[r][n].length < 2) {
					let a = B[r].points[e.cafes[r][n].length] + (r === G(e, "montesquieu") ? 4 : 0), o = B[r].discussions[n].flatMap((t) => r === G(e, "craven") ? t.flatMap((e, n) => {
						if (!e) return [];
						let r = [...t];
						return --r[n], [r];
					}) : [t]);
					for (let e of o.filter((e, t, n) => n.findIndex((t) => t.every((t, n) => t === e[n])) === t)) e.every((e, t) => e <= i.ideas[t]) && s("discuss", {
						city: r,
						local: n,
						ideas: e,
						points: a
					}, (i) => {
						let o = W(i, t);
						o.ideas = o.ideas.map((t, n) => t - e[n]), o.vp += a, i.cafes[r][n].push(t), i.tasks.shift(), J(i, "discuss", t, {
							city: r,
							n: a
						});
					});
				}
			}
			c();
			break;
		case "buy":
			for (let n of We(e)) {
				let e = Math.max(0, [
					0,
					0,
					2,
					5
				][F(n).level] - (o.discount ?? 0));
				i.coins >= e && s("buy", {
					card: n,
					cost: e
				}, (r) => {
					W(r, t).coins -= e, W(r, t).hand.push(n), Ge(r, n), r.tasks.shift(), o.immediate && Ie(r, t, n), J(r, "buy", t, { card: n });
				});
			}
			c();
			break;
		case "exchange":
			for (let e of qe(i.ideas, o.n)) s("exchange", {
				ideas: e,
				n: o.n
			}, (n) => {
				let r = W(n, t);
				r.ideas = r.ideas.map((t, n) => t - e[n]), n.tasks.shift(), K(n, t, [{
					kind: "idea",
					n: o.n
				}]);
			}), o.coinsInstead && s("exchange", {
				ideas: e,
				n: o.coinsInstead,
				cost: 0
			}, (n) => {
				let r = W(n, t);
				r.ideas = r.ideas.map((t, n) => t - e[n]), r.coins += o.coinsInstead, n.tasks.shift();
			});
			c();
			break;
		case "teleport":
			for (let e of o.cities) s("teleport", { city: e }, (n) => {
				W(n, t).node = e, n.tasks.shift(), J(n, "move", t, { node: e });
			});
			c();
			break;
		case "reactivate":
			i.tiles.forEach((e, n) => {
				e.used && s("reactivate", {
					tile: n,
					city: e.city,
					effects: X(le[e.city][e.index])
				}, (n) => {
					n.tasks.shift(), K(n, t, le[e.city][e.index]);
				});
			}), c();
			break;
		case "flipMove":
			i.played.forEach((e, n) => {
				e.faceDown || s("flip", { card: e.card }, (r) => {
					W(r, t).played[n].faceDown = !0, r.chain = r.chain.filter((t) => t !== e.card), r.tasks.shift(), K(r, t, [{
						kind: "move",
						n: 2
					}]);
				});
			}), c();
			break;
		case "removeI":
			if (i.hand.length > 5) for (let e of i.hand) F(e).level === 1 && s("remove", { card: e }, (n) => {
				let r = W(n, t);
				r.hand = r.hand.filter((t) => t !== e), r.coins += 2, r.vp += 3, n.tasks.shift();
			});
			c();
			break;
		case "painting":
			for (let n of [...new Set(e.paintings)]) i.paintings.includes(n) || s("painting", { n }, (e) => {
				W(e, t).paintings.push(n), e.paintings.splice(e.paintings.indexOf(n), 1), e.tasks.shift();
			});
			c();
			break;
		case "admiration": i.vp >= 1 && s("admiration", {
			traveler: o.column,
			row: o.row,
			cost: 1,
			effects: X(V[e.gazette][o.column])
		}, (e) => {
			--W(e, t).vp, e.tasks.shift(), K(e, t, V[e.gazette][o.column]);
		}), c();
	}
	else if (e.phase === "action") {
		if (e.stage === "play") for (let e of i.hand) s("play", { card: e }, (n) => {
			Ue(n, t, e, !1);
			let r = W(n, t);
			n.stage = "chain", n.chain = r.played.filter((t) => !t.faceDown && F(t.card).category === F(e).category).map((e) => e.card), J(n, "play", t, { card: e });
		}), s("faceDown", { card: e }, (n) => {
			Ue(n, t, e, !0), n.stage = "finish", n.chain = [], K(n, t, [ce]), J(n, "faceDown", t);
		});
		if (e.stage === "chain") {
			for (let n of e.chain) s("activate", { card: n }, (e) => {
				e.chain = e.chain.filter((e) => e !== n), Ie(e, t, n), J(e, "activate", t, { card: n });
			});
			s("endChain", {}, (e) => {
				e.chain = [], e.stage = "finish";
			});
		}
		e.stage === "finish" && s("endTurn", {}, (e) => {
			if (e.chain = [], e.activeCard = null, e.byronUsed = !1, e.dickensUsed = !1, e.players.every((e) => e.played.length === 5)) e.phase = "travelers", e.travelerStep = 0, J(e, "travelers");
			else {
				do
					e.turn = (e.turn + 1) % e.players.length;
				while (e.players[e.turn].played.length >= 5);
				e.stage = "play", J(e, "turn", e.players[e.turn].rid);
			}
		});
	} else if (e.phase === "market") {
		let n = new Set(i.played.map((e) => e.faceDown ? "faceDown" : F(e.card).category)).size;
		for (let r of We(e)) F(r).level <= n - 1 && s("buy", {
			card: r,
			cost: 0
		}, (e) => {
			W(e, t).hand.push(r), Ge(e, r), Xe(e), J(e, "buy", t, { card: r });
		});
		s("skip", {}, (e) => Xe(e));
	} else if (e.phase === "discard") for (let e of i.hand) s("discard", { card: e }, (n) => {
		W(n, t).hand.splice(W(n, t).hand.indexOf(e), 1), Ze(n), J(n, "discard", t);
	});
	if (n && e.phase === "action" && !(o && tt(o)) && (i.tiles.forEach((e, n) => {
		e.used || s("useTile", {
			tile: n,
			city: e.city,
			effects: X(le[e.city][e.index])
		}, (r) => {
			W(r, t).tiles[n].used = !0, K(r, t, le[e.city][e.index]), J(r, "useTile", t, { city: e.city });
		});
	}), e.stage === "play" && !e.tasks.length && !e.byronUsed && i.coins >= 3 && G(e, "byron") >= 0 && s("byron", {
		city: G(e, "byron"),
		cost: 3
	}, (e) => {
		let n = W(e, t);
		n.coins -= 3, n.node = G(e, "byron"), e.byronUsed = !0, J(e, "move", t, { node: n.node });
	}), !e.dickensUsed && i.coins >= 2 && G(e, "dickens") >= 0)) for (let n of ["dickensExplore", "dickensDiscuss"]) s(n, {
		city: G(e, "dickens"),
		cost: 2
	}, (e) => {
		W(e, t).coins -= 2, e.dickensUsed = !0, K(e, t, [n === "dickensExplore" ? {
			kind: "explore",
			n: 1,
			city: G(e, "dickens")
		} : {
			kind: "discuss",
			city: G(e, "dickens")
		}]);
	});
	return r;
}
function Xe(e) {
	if (e.marketStep += 1, e.marketStep < e.players.length) e.turn = (e.turn + e.players.length - 1) % e.players.length;
	else {
		for (let t of e.players) t.hand.push(...t.played.map((e) => e.card)), t.played = [];
		e.phase = "discard", Ze(e);
	}
}
function Ze(e) {
	let t = e.players.findIndex((e) => e.hand.length > 8);
	t >= 0 ? e.turn = t : e.phase = "roundEnd";
}
function Qe(e) {
	if (e.travelerStep < 3) {
		let t = e.travelerStep++, n = e.travelers[t], r = G(e, n), i = [], a = (e, t) => i.push(...t.map((t) => ({
			who: e,
			effect: t,
			used: []
		}))), o = e.players.map((e) => R(r)[e.node]);
		for (let t = 0; t < e.players.length; t++) {
			let i = e.players[(e.first + t) % e.players.length], s = [];
			if (n === "goethe" && s.push({
				kind: "vp",
				n: Math.min(7, i.coins)
			}), n === "keats" && s.push({
				kind: "vp",
				n: i.advancedPlayed
			}), n === "montagu" && i.node === r && s.push({
				kind: "choice",
				options: [[{
					kind: "idea",
					n: 2
				}], [{
					kind: "vp",
					n: 3
				}]]
			}), n === "shelley" && i.node === r && s.push({
				kind: "vp",
				n: U(i.journals.map((e) => U(e.ideas)))
			}), n === "blessington") {
				let e = R(r)[i.node];
				e === Math.min(...o) && s.push({
					kind: "vp",
					n: 3
				}), e === Math.max(...o) && s.push({
					kind: "vp",
					n: -2
				});
			}
			a(i.rid, s);
		}
		e.tasks.push(...i), J(e, "travelerBonus");
	} else if (e.travelerStep === 3) {
		e.travelerStep++;
		for (let t = 0; t < e.players.length; t++) {
			let n = e.players[(e.first + t) % e.players.length].rid;
			e.experiences.forEach((t, r) => t.forEach((t, i) => {
				t?.rid === n && t.kind === "admiration" && e.tasks.push({
					who: n,
					effect: {
						kind: "admiration",
						column: r,
						row: i
					},
					used: []
				});
			}));
		}
	} else e.phase = "market", e.marketStep = 0, e.turn = (e.first + e.players.length - 1) % e.players.length, J(e, "market");
}
function $e(e, t, n) {
	let r = F(n).score, i = 0;
	switch (r.kind) {
		case "fixed": return r.n;
		case "travel":
		case "inspiration":
		case "friendship":
		case "festivities":
			i = t.hand.filter((e) => F(e).category === r.kind).length;
			break;
		case "tiles":
			i = t.tiles.length;
			break;
		case "contacts":
			i = (/* @__PURE__ */ new Set([...t.letters.map((e) => e.city), ...e.cafes.flatMap((e, n) => e.some((e) => e.includes(t.rid)) ? [n] : [])])).size;
			break;
		case "writtenIdeas":
			i = U(t.journals.map((e) => U(e.ideas)));
			break;
		case "cafes":
			i = Ke(e, t.rid);
			break;
		case "reserveIdeas":
			i = U(t.ideas);
			break;
		case "coins":
			i = t.coins;
			break;
		case "level2":
			i = t.hand.filter((e) => F(e).level === 2).length;
			break;
		case "level3": i = t.hand.filter((e) => F(e).level === 3).length;
	}
	return Math.min(r.max ?? Infinity, Math.floor(i / (r.per ?? 1)) * r.n);
}
function et(e) {
	let t = Object.fromEntries(e.players.map((e) => [e.rid, 0]));
	for (let n of e.players) {
		let r = e.experiences.flatMap((e, t) => e.some((e) => e?.rid === n.rid && e.kind === "affinity1") ? [t] : []).concat(e.experiences.flatMap((e, t) => e.some((e) => e?.rid === n.rid && e.kind === "affinity2") ? [t] : []));
		t[n.rid] += r.length === 2 && r[0] === r[1] ? 6 : r.length * 2;
	}
	for (let n of e.experiences) e.players.map((e) => ({
		rid: e.rid,
		n: U(n.map((t) => t?.rid === e.rid ? t.kind === "night" ? 2 : 1 : 0)),
		highest: n.findIndex((t) => t?.rid === e.rid)
	})).filter((e) => e.n > 0).sort((e, t) => t.n - e.n || e.highest - t.highest).slice(0, e.players.length === 2 ? 1 : 3).forEach((e, n) => {
		t[e.rid] += [
			5,
			3,
			1
		][n];
	});
	return Object.fromEntries(e.players.map((n) => {
		let r = {
			journey: n.vp,
			exploration: pe[n.tiles.length],
			journals: U(n.journals.map((e) => fe[U(e.ideas) + Number(e.tile) + Number(e.friend)])),
			cards: U(n.hand.map((t) => $e(e, n, t))),
			experiences: t[n.rid],
			paintings: me[n.paintings.length],
			total: 0
		};
		return r.total = U(Object.values(r)), [n.rid, r];
	}));
}
function tt(e) {
	return e.kind === "coins" || e.kind === "vp" || e.kind === "localBonus" || e.kind === "idea" && !!e.idea;
}
function nt(e) {
	let t = e.tasks[0];
	if (t) {
		let n = t.effect, r = W(e, t.who);
		n.kind === "coins" ? (r.coins += n.n, e.tasks.shift(), J(e, "coins", r.rid, { n: n.n })) : n.kind === "vp" ? (r.vp += n.n, e.tasks.shift(), J(e, "vp", r.rid, { n: n.n })) : n.kind === "idea" && n.idea ? (Be(e, r.rid, n.idea), q(e)) : n.kind === "localBonus" && (e.tasks.shift(), K(e, r.rid, ue[e.favors[n.city]][n.local])), Je(e);
		return;
	}
	e.phase === "travelers" ? Qe(e) : e.phase === "roundEnd" && (e.round === 5 ? (e.scores = et(e), e.phase = "done", J(e, "done")) : (e.round += 1, e.first = (e.first + 1) % e.players.length, e.turn = e.first, e.phase = "action", e.stage = "play", e.players.forEach((e) => {
		e.advancedPlayed = 0;
	}), Re(e), Le(e), J(e, "round")));
}
function rt(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine" || it(e) === null) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return nt(t), t.revision++, {
			state: t,
			fx: []
		};
	}
	let r = Ye(e, n.by).find((e) => e.view.id === t.id);
	if (!r) return { code: "games.timelessjourneys.invalidAction" };
	let i = structuredClone(e);
	return r.apply(i), e.phase === "action" && e.stage === "play" && (i.byronUsed = !0), Je(i), i.revision++, {
		state: i,
		fx: []
	};
}
function it(e) {
	return e.tasks.length ? tt(e.tasks[0].effect) ? 450 : null : e.phase === "travelers" || e.phase === "roundEnd" ? 450 : null;
}
function at(e, t) {
	let n = {
		round: e.round,
		phase: e.phase,
		stage: e.stage,
		active: Fe(e),
		first: e.players[e.first].rid,
		players: e.players.map(({ hand: t, played: n, ...r }) => ({
			...r,
			handSize: t.length,
			played: n.map((e) => ({
				faceDown: e.faceDown,
				card: e.faceDown ? null : e.card
			})),
			...e.phase === "done" ? { finalHand: t } : {}
		})),
		gazette: e.gazette,
		travelers: e.travelers,
		experiences: e.experiences,
		favors: e.favors,
		friends: e.friends,
		remainingTiles: e.remainingTiles.map((e) => e.length),
		cafes: e.cafes,
		market: e.market,
		deckTop: e.decks.map((e) => e[0] ?? null),
		deckSize: e.decks.map((e) => e.length),
		paintings: e.paintings,
		task: e.tasks[0] ? X([e.tasks[0].effect]) : [],
		activeCard: e.activeCard,
		scores: e.scores,
		event: e.event
	};
	return {
		public: structuredClone(n),
		private: {
			hand: [...e.players.find((e) => e.rid === t)?.hand ?? []],
			choices: Ye(e, t).map((e) => e.view)
		}
	};
}
function ot(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n.rid].total - e.scores[t.rid].total || I[n.node][1] - I[t.node][1]).map((e) => e.rid), n = W(e, t[0]);
	return {
		phase: "done",
		ranking: t,
		winner: t.filter((t) => e.scores[t].total === e.scores[n.rid].total && I[W(e, t).node][1] === I[n.node][1]),
		scores: Object.fromEntries(e.players.map((t) => [t.rid, e.scores[t.rid].total]))
	};
}
var st = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ve,
	schemas: {
		action: we,
		publicView: Me,
		privateView: Ne,
		config: Ce
	},
	setup: ze,
	reduce: rt,
	viewFor: at,
	status: ot,
	nextTickIn: it
}, ct = [
	"games.timelessjourneys.cities.torino",
	"games.timelessjourneys.cities.venezia",
	"games.timelessjourneys.cities.bologna",
	"games.timelessjourneys.cities.firenze",
	"games.timelessjourneys.cities.perugia",
	"games.timelessjourneys.cities.roma",
	"games.timelessjourneys.cities.napoli",
	"games.timelessjourneys.cities.palermo"
], lt = {
	science: "games.timelessjourneys.ideas.science",
	history: "games.timelessjourneys.ideas.history",
	art: "games.timelessjourneys.ideas.art",
	philosophy: "games.timelessjourneys.ideas.philosophy"
}, ut = {
	travel: "games.timelessjourneys.categories.travel",
	inspiration: "games.timelessjourneys.categories.inspiration",
	friendship: "games.timelessjourneys.categories.friendship",
	festivities: "games.timelessjourneys.categories.festivities"
}, dt = {
	montesquieu: "games.timelessjourneys.travelerNames.montesquieu",
	montagu: "games.timelessjourneys.travelerNames.montagu",
	addison: "games.timelessjourneys.travelerNames.addison",
	craven: "games.timelessjourneys.travelerNames.craven",
	goethe: "games.timelessjourneys.travelerNames.goethe",
	lebrun: "games.timelessjourneys.travelerNames.lebrun",
	keats: "games.timelessjourneys.travelerNames.keats",
	byron: "games.timelessjourneys.travelerNames.byron",
	shelley: "games.timelessjourneys.travelerNames.shelley",
	dickens: "games.timelessjourneys.travelerNames.dickens",
	twain: "games.timelessjourneys.travelerNames.twain",
	blessington: "games.timelessjourneys.travelerNames.blessington"
}, ft = {
	montesquieu: "games.timelessjourneys.travelerRules.montesquieu",
	montagu: "games.timelessjourneys.travelerRules.montagu",
	addison: "games.timelessjourneys.travelerRules.addison",
	craven: "games.timelessjourneys.travelerRules.craven",
	goethe: "games.timelessjourneys.travelerRules.goethe",
	lebrun: "games.timelessjourneys.travelerRules.lebrun",
	keats: "games.timelessjourneys.travelerRules.keats",
	byron: "games.timelessjourneys.travelerRules.byron",
	shelley: "games.timelessjourneys.travelerRules.shelley",
	dickens: "games.timelessjourneys.travelerRules.dickens",
	twain: "games.timelessjourneys.travelerRules.twain",
	blessington: "games.timelessjourneys.travelerRules.blessington"
}, pt = {
	duel: "games.timelessjourneys.experiences.duel",
	night: "games.timelessjourneys.experiences.night",
	admiration: "games.timelessjourneys.experiences.admiration",
	affinity1: "games.timelessjourneys.experiences.affinity1",
	affinity2: "games.timelessjourneys.experiences.affinity2"
}, mt = {
	duel: "games.timelessjourneys.experienceRules.duel",
	night: "games.timelessjourneys.experienceRules.night",
	admiration: "games.timelessjourneys.experienceRules.admiration",
	affinity1: "games.timelessjourneys.experienceRules.affinity1",
	affinity2: "games.timelessjourneys.experienceRules.affinity2"
}, ht = {
	play: "games.timelessjourneys.phase.play",
	chain: "games.timelessjourneys.phase.chain",
	finish: "games.timelessjourneys.phase.finish",
	travelers: "games.timelessjourneys.phase.travelers",
	market: "games.timelessjourneys.phase.market",
	discard: "games.timelessjourneys.phase.discard",
	roundEnd: "games.timelessjourneys.phase.roundEnd",
	done: "games.timelessjourneys.phase.done"
}, gt = {
	journey: "games.timelessjourneys.scoreRows.journey",
	exploration: "games.timelessjourneys.scoreRows.exploration",
	journals: "games.timelessjourneys.scoreRows.journals",
	cards: "games.timelessjourneys.scoreRows.cards",
	experiences: "games.timelessjourneys.scoreRows.experiences",
	paintings: "games.timelessjourneys.scoreRows.paintings",
	total: "games.timelessjourneys.scoreRows.total"
}, _t = {
	move1: "games.timelessjourneys.basic.move1",
	move2: "games.timelessjourneys.basic.move2",
	explore: "games.timelessjourneys.basic.explore",
	talk: "games.timelessjourneys.basic.talk",
	letter: "games.timelessjourneys.basic.letter",
	journal: "games.timelessjourneys.basic.journal",
	science: "games.timelessjourneys.basic.science",
	history: "games.timelessjourneys.basic.history",
	art: "games.timelessjourneys.basic.art",
	philosophy: "games.timelessjourneys.basic.philosophy",
	money: "games.timelessjourneys.basic.money"
}, vt = {
	effect: "games.timelessjourneys.choice.effect",
	endEffects: "games.timelessjourneys.choice.endEffects",
	play: "games.timelessjourneys.choice.play",
	faceDown: "games.timelessjourneys.choice.faceDown",
	activate: "games.timelessjourneys.choice.activate",
	endTurn: "games.timelessjourneys.choice.endTurn",
	endChain: "games.timelessjourneys.choice.endChain",
	skip: "games.timelessjourneys.choice.skip",
	branch: "games.timelessjourneys.choice.branch",
	pay: "games.timelessjourneys.choice.pay",
	move: "games.timelessjourneys.choice.move",
	explore: "games.timelessjourneys.choice.explore",
	cityBonus: "games.timelessjourneys.choice.cityBonus",
	takeTile: "games.timelessjourneys.choice.takeTile",
	idea: "games.timelessjourneys.choice.idea",
	writeIdea: "games.timelessjourneys.choice.writeIdea",
	writeTile: "games.timelessjourneys.choice.writeTile",
	writeFriend: "games.timelessjourneys.choice.writeFriend",
	talk: "games.timelessjourneys.choice.talk",
	traveler: "games.timelessjourneys.choice.traveler",
	letter: "games.timelessjourneys.choice.letter",
	reward: "games.timelessjourneys.ui.reward",
	friend: "games.timelessjourneys.choice.friend",
	correspond: "games.timelessjourneys.choice.correspond",
	buy: "games.timelessjourneys.choice.buy",
	discuss: "games.timelessjourneys.choice.discuss",
	exchange: "games.timelessjourneys.choice.exchange",
	teleport: "games.timelessjourneys.choice.teleport",
	reactivate: "games.timelessjourneys.choice.reactivate",
	flip: "games.timelessjourneys.choice.flip",
	remove: "games.timelessjourneys.choice.remove",
	painting: "games.timelessjourneys.choice.painting",
	admiration: "games.timelessjourneys.choice.admiration",
	byron: "games.timelessjourneys.choice.byron",
	dickensExplore: "games.timelessjourneys.choice.dickensExplore",
	dickensDiscuss: "games.timelessjourneys.choice.dickensDiscuss",
	useTile: "games.timelessjourneys.choice.useTile",
	discard: "games.timelessjourneys.choice.discard"
};
function Z(e, t) {
	return e < 8 ? t(ct[e]) : t("games.timelessjourneys.ui.node", { n: e - 7 });
}
function yt(e, t) {
	let n = F(e);
	return n.level ? t("games.timelessjourneys.ui.cardName", {
		level: [
			"",
			"I",
			"II",
			"III"
		][n.level],
		category: t(ut[n.category]),
		n: String(n.number).padStart(2, "0")
	}) : t(_t[n.id]);
}
function bt(e, t) {
	return e.flatMap((e, n) => e ? [`${t(lt[b[n]])} ${e}`] : []).join(" · ");
}
function xt(e, t) {
	switch (e.kind) {
		case "cardEffects": return t("games.timelessjourneys.effect.cardEffects");
		case "coins": return t("games.timelessjourneys.effect.coins", { n: e.n ?? 0 });
		case "vp": return t("games.timelessjourneys.effect.vp", { n: e.n ?? 0 });
		case "idea": return e.different ? t("games.timelessjourneys.effect.differentIdeas", { n: e.n ?? 1 }) : t("games.timelessjourneys.effect.idea", {
			n: e.n ?? 1,
			idea: e.idea ? t(lt[e.idea]) : t("games.timelessjourneys.ideas.any")
		});
		case "move": return t(e.discount ? "games.timelessjourneys.effect.discountMove" : "games.timelessjourneys.effect.move", {
			n: e.n ?? 1,
			discount: e.discount ?? 0
		});
		case "explore": return t("games.timelessjourneys.effect.explore", { n: e.n ?? 1 });
		case "talk": return t("games.timelessjourneys.effect.talk", { n: e.n ?? 1 });
		case "letter": return t(e.any ? "games.timelessjourneys.effect.anyLetter" : e.different ? "games.timelessjourneys.effect.differentLetters" : "games.timelessjourneys.effect.letter", { n: e.n ?? 1 });
		case "write": return t(e.different ? "games.timelessjourneys.effect.differentJournals" : "games.timelessjourneys.effect.write", { n: e.n ?? 1 });
		case "discuss": return t(e.any ? "games.timelessjourneys.effect.anyDiscuss" : "games.timelessjourneys.effect.discuss");
		case "buy": return t(e.immediate ? "games.timelessjourneys.effect.immediateBuy" : e.discount ? "games.timelessjourneys.effect.discountBuy" : "games.timelessjourneys.effect.buy", { n: e.discount ?? 0 });
		case "pay": return t(e.vp ? "games.timelessjourneys.effect.payVp" : "games.timelessjourneys.effect.payCoins", { n: e.vp ?? e.coins ?? 0 });
		case "exchange": return "coinsInstead" in e && typeof e.coinsInstead == "number" ? t("games.timelessjourneys.effect.exchangeOrCoins", {
			n: e.n ?? 1,
			coins: e.coinsInstead
		}) : t("games.timelessjourneys.effect.exchange", { n: e.n ?? 1 });
		case "teleport": return t("games.timelessjourneys.effect.teleport", { cities: (e.cities ?? []).map((e) => Z(e, t)).join(" / ") });
		case "reactivate": return t("games.timelessjourneys.effect.reactivate");
		case "flipMove": return t("games.timelessjourneys.effect.flipMove");
		case "removeI": return t("games.timelessjourneys.effect.removeI");
		case "localBonus": return t("games.timelessjourneys.effect.localBonus");
		case "localLink": return t("games.timelessjourneys.effect.localLink");
		case "takeTile": return t("games.timelessjourneys.effect.takeTile");
		case "painting": return t("games.timelessjourneys.effect.painting");
		case "admiration": return t("games.timelessjourneys.effect.admiration");
		case "or": return t("games.timelessjourneys.effect.or");
		default: return "";
	}
}
function St(e, t) {
	return e.map((e) => xt(e, t)).filter(Boolean).join(" · ");
}
function Ct(e, t, n) {
	return n(e.kind === "exchange" && e.cost === 0 ? "games.timelessjourneys.choice.exchangeCoins" : vt[e.kind], {
		card: e.card ? yt(e.card, n) : "",
		effects: St(e.effects ?? [], n),
		cost: e.points ? n("games.timelessjourneys.effect.payVp", { n: e.points }) : n("games.timelessjourneys.effect.payCoins", { n: e.cost ?? 0 }),
		place: e.node === void 0 ? "" : Z(e.node, n),
		city: e.city === void 0 ? "" : Z(e.city, n),
		n: e.journal === void 0 ? e.local === void 0 ? (e.n ?? 0) + +(e.kind === "painting") : e.local + 1 : e.journal + 1,
		idea: e.idea ? n(lt[e.idea]) : "",
		traveler: e.traveler === void 0 ? "" : n(dt[t.travelers[e.traveler]]),
		experience: e.experience ? n(pt[e.experience]) : "",
		ideas: bt(e.ideas ?? [], n)
	});
}
var wt = {
	fixed: "games.timelessjourneys.scoring.fixed",
	travel: "games.timelessjourneys.scoring.travel",
	inspiration: "games.timelessjourneys.scoring.inspiration",
	friendship: "games.timelessjourneys.scoring.friendship",
	festivities: "games.timelessjourneys.scoring.festivities",
	tiles: "games.timelessjourneys.scoring.tiles",
	contacts: "games.timelessjourneys.scoring.contacts",
	writtenIdeas: "games.timelessjourneys.scoring.writtenIdeas",
	cafes: "games.timelessjourneys.scoring.cafes",
	reserveIdeas: "games.timelessjourneys.scoring.reserveIdeas",
	coins: "games.timelessjourneys.scoring.coins",
	level2: "games.timelessjourneys.scoring.level2",
	level3: "games.timelessjourneys.scoring.level3"
};
function Tt(e, t) {
	return t(wt[e.kind], { n: e.n });
}
//#endregion
//#region src/games/timelessjourneys/artwork.tsx
var Et = [
	"#456b8b",
	"#59823b",
	"#a97828",
	"#26785e",
	"#805389",
	"#ad6242",
	"#397d84",
	"#ad667c"
];
function Q({ kind: e, ...t }) {
	let n = {
		coin: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "16",
				r: "12",
				fill: "#d6ab51",
				stroke: "#8e6b2d",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "16",
				r: "8.5",
				fill: "none",
				stroke: "#f4d98f"
			}),
			/* @__PURE__ */ h("path", {
				d: "M17 8l-5 9h5l-2 7 7-12h-6z",
				fill: "#916b2b"
			})
		] }),
		science: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M7 9l15-5 3 7-15 5z",
				fill: "#80b8ba",
				stroke: "#42666a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ h("path", {
				d: "M18 15l-2 5m0 0L8 28m8-8 8 8M6 9l3 8M24 3l3 10",
				fill: "none",
				stroke: "#42666a",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "20",
				r: "2.7",
				fill: "#c29c50"
			})
		] }),
		history: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M4 9l12-6 12 6v3H4zM5 26h22v3H5z",
			fill: "#c8a75e",
			stroke: "#8c713f",
			strokeWidth: "1.2"
		}), /* @__PURE__ */ h("path", {
			d: "M8 13h4v12H8zm12 0h4v12h-4zM14 13h4v12h-4z",
			fill: "#e1c989",
			stroke: "#8c713f",
			strokeWidth: "1.2"
		})] }),
		art: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M17 4C8 4 2 11 4 19c2 9 13 11 18 6 4-4-4-4-2-8 1-2 8 0 8-5 0-4-5-8-11-8z",
				fill: "#c18d78",
				stroke: "#8d5d4e",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "10",
				cy: "12",
				r: "2.1",
				fill: "#ebcd86"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "15",
				cy: "8",
				r: "2",
				fill: "#739e95"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "22",
				cy: "11",
				r: "2",
				fill: "#8a7899"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "8",
				cy: "19",
				r: "2",
				fill: "#8d5e75"
			}),
			/* @__PURE__ */ h("path", {
				d: "M16 27l10-11 2 2-10 11z",
				fill: "#d6b56d",
				stroke: "#765b40"
			})
		] }),
		philosophy: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M11 24v-5c-6-3-6-13 1-15 10-4 17 6 11 12l4 4h-5v5H11z",
			fill: "#9ba2b0",
			stroke: "#626878",
			strokeWidth: "1.4"
		}), /* @__PURE__ */ h("path", {
			d: "M9 28h15M15 9c4-3 7 1 3 3-3 2-4 5-1 7",
			fill: "none",
			stroke: "#626878",
			strokeWidth: "1.7"
		})] }),
		move: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M3 15h20l-7-7 3-3 12 12-12 11-3-3 7-7H3z",
			fill: "currentColor"
		}), /* @__PURE__ */ h("path", {
			d: "M4 8l6 7-6 7",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.5"
		})] }),
		explore: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("circle", {
				cx: "13",
				cy: "13",
				r: "8.2",
				fill: "#fbf6df",
				stroke: "currentColor",
				strokeWidth: "2.4"
			}),
			/* @__PURE__ */ h("path", {
				d: "M19 19l10 10",
				stroke: "currentColor",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ h("path", {
				d: "M8 11q4-6 8-2",
				fill: "none",
				stroke: "#b8d8d5",
				strokeWidth: "2"
			})
		] }),
		letter: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M3 7h26v18H3z",
				fill: "#fff7df",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ h("path", {
				d: "M3 7l13 11L29 7M3 25l10-10m16 10L19 15",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.3"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "17",
				r: "3",
				fill: "#a96b50"
			})
		] }),
		write: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M2 7q7-4 14 0 7-4 14 0v21q-7-4-14 0-7-4-14 0z",
				fill: "#fff7df",
				stroke: "currentColor",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ h("path", {
				d: "M16 7v21M5 12h7m-7 4h7m8-4h7m-7 4h7",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ h("path", {
				d: "M20 3l-8 17 5-4 7-15z",
				fill: "#79a29d",
				stroke: "#426b64"
			})
		] }),
		talk: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M3 6q0-3 4-3h18q4 0 4 4v12q0 4-4 4H14l-9 7 2-7q-4 0-4-4z",
			fill: "#fff7df",
			stroke: "currentColor",
			strokeWidth: "1.7"
		}), /* @__PURE__ */ h("path", {
			d: "M9 11h14M9 16h10",
			stroke: "currentColor",
			strokeWidth: "1.3"
		})] }),
		friend: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("circle", {
				cx: "11",
				cy: "9",
				r: "4",
				fill: "#7b9591"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "23",
				cy: "10",
				r: "3.5",
				fill: "#ba936c"
			}),
			/* @__PURE__ */ h("path", {
				d: "M3 28v-9q1-6 8-6 6 0 8 6v9z",
				fill: "#7b9591",
				stroke: "#4c6663",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ h("path", {
				d: "M20 17q8-3 10 6v5H20z",
				fill: "#ba936c",
				stroke: "#806344",
				strokeWidth: "1.2"
			})
		] }),
		cup: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M6 9h18l-2 13q-7 5-14 0z",
			fill: "#fff6df",
			stroke: "currentColor",
			strokeWidth: "1.6"
		}), /* @__PURE__ */ h("path", {
			d: "M24 11h4q4 8-5 8M3 27h25M10 4q4 2 0 4m7-5q4 2 0 4",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.6"
		})] }),
		duel: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M5 3l20 23m-1-23L6 26",
			stroke: "currentColor",
			strokeWidth: "3"
		}), /* @__PURE__ */ h("path", {
			d: "M2 23l7 6m15-7 6 6M5 3l3 8m16-8-2 8",
			stroke: "currentColor",
			strokeWidth: "2"
		})] }),
		night: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M22 3C5 2-3 23 14 28c8 2 13-4 15-9C17 23 10 10 22 3z",
			fill: "currentColor"
		}), /* @__PURE__ */ h("path", {
			d: "M25 6v7m-3-4h7",
			stroke: "currentColor",
			strokeWidth: "1.7"
		})] }),
		admiration: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M16 2l4 9 10 1-8 7 3 11-9-6-10 6 3-11-8-7 11-1z",
			fill: "currentColor"
		}), /* @__PURE__ */ h("circle", {
			cx: "16",
			cy: "16",
			r: "5",
			fill: "#fff5dd"
		})] }),
		affinity1: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M5 15q-5-9 3-11 5-1 8 5 3-6 8-5 8 2 3 11L16 29z",
			fill: "currentColor"
		}), /* @__PURE__ */ h("path", {
			d: "M5 17l6-4 5 5 5-5 6 4M11 13l5-4 5 4",
			fill: "none",
			stroke: "#fff5df",
			strokeWidth: "1.6"
		})] }),
		affinity2: null,
		laurel: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M11 29C-1 21 0 11 10 3M21 29c12-8 11-18 1-26",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.4"
		}), /* @__PURE__ */ h("path", {
			d: "M6 23Q0 25 0 18q7-1 6 5m-2-9Q-2 10 3 7q5 3 1 7m3-6Q2 2 10 1q3 5-3 7m19 15q6 2 6-5-7-1-6 5m2-9q6-4 1-7-5 3-1 7m-3-6q5-6-3-7-3 5 3 7",
			fill: "currentColor"
		})] }),
		painting: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("rect", {
				x: "2",
				y: "3",
				width: "28",
				height: "26",
				rx: "2",
				fill: "#d7bc78",
				stroke: "#8a734c"
			}),
			/* @__PURE__ */ h("path", {
				d: "M6 7h20v18H6z",
				fill: "#a8ccc0"
			}),
			/* @__PURE__ */ h("path", {
				d: "M6 22l7-10 5 5 4-4 4 9z",
				fill: "#718a6c"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "22",
				cy: "10",
				r: "2",
				fill: "#f6e0a1"
			})
		] }),
		card: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("rect", {
				x: "8",
				y: "2",
				width: "19",
				height: "25",
				rx: "2",
				fill: "#e3d5b3",
				stroke: "currentColor"
			}),
			/* @__PURE__ */ h("rect", {
				x: "4",
				y: "5",
				width: "19",
				height: "25",
				rx: "2",
				fill: "#fff4d9",
				stroke: "currentColor",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ h("rect", {
				x: "7",
				y: "8",
				width: "13",
				height: "19",
				rx: "1",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ h("path", {
				d: "M13.5 11l4 6-4 6-4-6z",
				fill: "currentColor"
			})
		] }),
		any: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			d: "M16 2l13 14-13 14L3 16z",
			fill: "#e5d9b6",
			stroke: "#9b8a62"
		}), /* @__PURE__ */ h("path", {
			d: "M16 8v16M8 16h16",
			stroke: "#8a7956",
			strokeWidth: "2"
		})] }),
		lock: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M9 15V9a7 7 0 0114 0v6",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.4"
			}),
			/* @__PURE__ */ h("rect", {
				x: "5",
				y: "14",
				width: "22",
				height: "15",
				rx: "3",
				fill: "currentColor"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "20",
				r: "2",
				fill: "#eee6d4"
			})
		] })
	};
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		...t,
		children: n[e === "affinity2" ? "affinity1" : e]
	});
}
function Dt({ city: e, ...t }) {
	let n = "#ede2bd", r = "#ae7450", i = [
		/* @__PURE__ */ g("g", { children: [
			/* @__PURE__ */ h("path", {
				d: "M-22 9V-13h44V9M-26-14h52L16-22h-32z",
				fill: n
			}),
			/* @__PURE__ */ h("path", {
				d: "M-14-10v15m9-15v15m10-15v15m9-15v15M-24 9h48",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-7-22v-8h14v8",
				fill: n
			})
		] }),
		/* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
			d: "M-25 11V-7h41v18M-29-7h49M-12-7v-10q7-20 15 0v10M-15-17h21M22 11v-41h6v41",
			fill: n
		}), /* @__PURE__ */ h("path", {
			d: "M-20 11V2q3-7 6 0v9m5 0V2q3-7 6 0v9m5 0V2q3-7 6 0v9M20-30h10l-5-6z",
			fill: r
		})] }),
		/* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
			d: "M-17 12l3-47h11l1 47M6 12L5-21h12l4 33M-17-35h15M4-21h15",
			fill: r
		}), /* @__PURE__ */ h("path", {
			d: "M-10-29v6m-1 6v6M11-17v6M-22 12h48",
			strokeWidth: "2"
		})] }),
		/* @__PURE__ */ g("g", { children: [
			/* @__PURE__ */ h("path", {
				d: "M-19 11v-19h38v19M-16-8q1-20 16-24Q15-28 16-8M-20-8h40M0-32v-8M-7-36H7M-25 11h50",
				fill: n
			}),
			/* @__PURE__ */ h("path", {
				d: "M-16-8q2-17 16-24 5 6 6 24M0-32q-6 7-6 24M22 11v-31h7v31",
				fill: r
			}),
			/* @__PURE__ */ h("path", {
				d: "M-12 11V3q0-9 8-9v17m7 0V3q0-9 8-9v17",
				fill: "none"
			})
		] }),
		/* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
			d: "M-24 12v-29h48v29M-26-17h52M-17-17v-12h7v12M10-17v-12h7v12M-8 12V-1q8-17 16 0v13",
			fill: n
		}), /* @__PURE__ */ h("path", {
			d: "M-18-8h5m26 0h5M-21 12h42",
			strokeWidth: "2"
		})] }),
		/* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
			d: "M-27 9v-23q10-15 27-9 15-6 27 9V9q-27 9-54 0z",
			fill: n
		}), /* @__PURE__ */ h("path", {
			d: "M-27-4q27 8 54 0M-27 7q27 8 54 0M-21-5v-7q3-8 6 0v8m7 1v-10q3-8 6 0V-2m7 0v-11q3-8 6 0V-3m7-2v-7q3-8 6 0v6M-22 8V1m9 10V3m10 9V4m10 8V4m10 7V2m8 6V0",
			fill: "none",
			strokeWidth: "1.3"
		})] }),
		/* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
			d: "M-40-3l15-20 9 4 9-10L15-3",
			fill: "#abb599",
			opacity: ".7"
		}), /* @__PURE__ */ h("path", {
			d: "M-24 12V-9h48v21M-29 12v-29h10v29M-8 12v-26H2v26M19 12v-29h10v29M-29-17v-5m5 5v-5m5 5v-5M-8-14v-5m5 5v-5m5 5v-5M19-17v-5m5 5v-5m5 5v-5M7 12V1q4-8 8 0v11",
			fill: n
		})] }),
		/* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
			d: "M-27 12v-23h54v23M-29-11h58M-22-11v-12q5-13 10 0v12m24 0v-12q5-13 10 0v12M-9-11v-9q9-20 18 0v9M-10-21h20M-4 12V2q4-8 8 0v10",
			fill: n
		}), /* @__PURE__ */ h("path", {
			d: "M-22-21q5-15 10 0m24 0q5-15 10 0m-31 1q9-21 18 0",
			fill: r
		})] })
	];
	return /* @__PURE__ */ h("svg", {
		viewBox: "-42 -48 84 68",
		"aria-hidden": "true",
		...t,
		children: /* @__PURE__ */ h("g", {
			stroke: "#6c735c",
			strokeWidth: "1",
			strokeLinejoin: "round",
			fill: "none",
			children: i[e]
		})
	});
}
var Ot = {
	montesquieu: {
		female: !1,
		hair: "#b9b5a5",
		dress: "#344952",
		style: "wig"
	},
	montagu: {
		female: !0,
		hair: "#594234",
		dress: "#5d8e8b",
		style: "bun"
	},
	shelley: {
		female: !0,
		hair: "#574039",
		dress: "#8e6663",
		style: "curls"
	},
	addison: {
		female: !1,
		hair: "#736552",
		dress: "#796254",
		style: "wig"
	},
	craven: {
		female: !0,
		hair: "#9f8b66",
		dress: "#789188",
		style: "bun"
	},
	goethe: {
		female: !1,
		hair: "#b7b5a7",
		dress: "#4c666c",
		style: "short"
	},
	lebrun: {
		female: !0,
		hair: "#715842",
		dress: "#a3786c",
		style: "curls"
	},
	keats: {
		female: !1,
		hair: "#694c35",
		dress: "#8b745a",
		style: "short"
	},
	byron: {
		female: !1,
		hair: "#463b32",
		dress: "#5e6378",
		style: "curls"
	},
	dickens: {
		female: !1,
		hair: "#6b4d39",
		dress: "#5e7565",
		style: "beard"
	},
	twain: {
		female: !1,
		hair: "#d5d2be",
		dress: "#a49c86",
		style: "mustache"
	},
	blessington: {
		female: !0,
		hair: "#42372f",
		dress: "#7d7292",
		style: "bun"
	}
};
function kt({ traveler: e, ...t }) {
	let n = r(), { female: i, hair: a, dress: o, style: s } = Ot[e];
	return /* @__PURE__ */ g("svg", {
		viewBox: "-55 -69 110 138",
		"aria-hidden": "true",
		...t,
		children: [
			/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ h("clipPath", {
				id: n,
				children: /* @__PURE__ */ h("ellipse", {
					rx: "47",
					ry: "59"
				})
			}) }),
			/* @__PURE__ */ h("ellipse", {
				rx: "51",
				ry: "63",
				fill: "#efe0bd",
				stroke: "#977b58",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ h("ellipse", {
				rx: "47",
				ry: "59",
				fill: "#d7d4b7"
			}),
			/* @__PURE__ */ g("g", {
				clipPath: `url(#${n})`,
				children: [
					/* @__PURE__ */ h("path", {
						d: "M-55 65q6-38 36-43h35q35 4 41 43z",
						fill: o,
						stroke: "#514b3e",
						strokeWidth: "1.5"
					}),
					i ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
						d: "M-30 30q28 22 60 0l4 7q-34 28-68 0z",
						fill: "#ecdec3"
					}), /* @__PURE__ */ h("path", {
						d: "M-24 32q24 13 48 0",
						fill: "none",
						stroke: "#b9955d",
						strokeWidth: "3"
					})] }) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
						d: "M-30 31l8-7 21 13 17-14 11 6-12 39H-15z",
						fill: "#263b45"
					}), /* @__PURE__ */ h("path", {
						d: "M-18 24l16 7 16-8-4 19-12 15-8-15z",
						fill: "#f7efd8"
					})] }),
					/* @__PURE__ */ h("path", {
						d: "M-10 5v19q9 13 21 0V5",
						fill: "#ddb990",
						stroke: "#9f7d5e"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-27-18q-10-24 7-32 29-20 48 8 8 16-2 34l-3 27-13 7h-22l-14-8z",
						fill: a,
						stroke: "#675845",
						strokeWidth: "1.4"
					}),
					s === "wig" && /* @__PURE__ */ h("path", {
						d: "M-24-36q-15 12-9 21-11 9-3 18-6 13 5 20m9-63q-14 12-7 21-10 11-2 21-5 10 4 16M24-39q14 12 8 23 11 6 3 17 8 10 0 20m-11-55q10 12 5 19 8 11 1 20 8 12-1 19",
						fill: "none",
						stroke: "#ded8c3",
						strokeWidth: "6",
						strokeLinecap: "round"
					}),
					s === "bun" && /* @__PURE__ */ h("path", {
						d: "M-19-36q-10-30 5-29 18-8 21 8 13-15 18-3 8 16-8 24",
						fill: a,
						stroke: "#3d302a",
						strokeWidth: "2"
					}),
					s === "curls" && /* @__PURE__ */ h("path", {
						d: "M-21-33q-14 14-8 29-14 12-2 22-12 17 3 20M23-32q15 15 6 31 14 10 3 22 10 12-4 18",
						fill: "none",
						stroke: a,
						strokeWidth: "8"
					}),
					/* @__PURE__ */ h("path", {
						d: i ? "M-17-30q21-14 36 5l-1 22Q13 17 0 17-15 14-21-2z" : "M-19-29q23-15 39 5l-2 23Q14 17 2 20-13 17-23-3z",
						fill: i ? "#f0cda4" : "#ddbc94",
						stroke: "#9f7d5e",
						strokeWidth: "1.1"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-18-27q7-13 20-11 12 0 18 13L5-33l-13 8z",
						fill: a
					}),
					/* @__PURE__ */ h("path", {
						d: "M-14-15q4-3 8 0m13-1q5-3 9 0",
						fill: "none",
						stroke: "#776047",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-13-10h6m14-1h6",
						stroke: "#4d514a",
						strokeWidth: "1.9"
					}),
					/* @__PURE__ */ h("path", {
						d: "M3-11L-1 2l8 1",
						fill: "none",
						stroke: "#b28a65",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-5 10q8 2 14-1",
						fill: "none",
						stroke: "#a66b60",
						strokeWidth: "1.4"
					}),
					i && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("circle", {
						cx: "-20",
						cy: "3",
						r: "2.5",
						fill: "#d5ab5a"
					}), /* @__PURE__ */ h("path", {
						d: "M-19 21q17 13 32 0",
						fill: "none",
						stroke: "#d8bc78",
						strokeWidth: "1.8"
					})] }),
					s === "beard" && /* @__PURE__ */ h("path", {
						d: "M-17 0l7 23 10 8 14-13 4-19-8 10H-9z",
						fill: a
					}),
					s === "mustache" && /* @__PURE__ */ h("path", {
						d: "M1 2q-12-5-20 6 12 3 20-2 11 6 20 0-10-8-20-4z",
						fill: a
					})
				]
			}),
			/* @__PURE__ */ h("ellipse", {
				rx: "47",
				ry: "59",
				fill: "none",
				stroke: "#fff3d4",
				strokeWidth: "2"
			})
		]
	});
}
function At() {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 79 94",
		preserveAspectRatio: "none",
		className: "tj-card-frame",
		"aria-hidden": "true",
		children: /* @__PURE__ */ g("g", {
			fill: "none",
			stroke: "currentColor",
			strokeWidth: ".7",
			children: [
				/* @__PURE__ */ h("rect", {
					x: "4",
					y: "4",
					width: "71",
					height: "86",
					rx: "4"
				}),
				/* @__PURE__ */ h("rect", {
					x: "7",
					y: "7",
					width: "65",
					height: "80",
					rx: "2"
				}),
				/* @__PURE__ */ h("path", { d: "M8 12q4 0 4-4m59 4q-4 0-4-4M8 82q4 0 4 4m59-4q-4 0-4 4" })
			]
		})
	});
}
function jt({ city: e, label: t }) {
	return /* @__PURE__ */ h("span", {
		className: "tj-ribbon",
		style: { "--tj-city": Et[e] },
		children: t
	});
}
//#endregion
//#region src/games/timelessjourneys/table.tsx
var Mt = "M30 40H1050L1040 218Q980 293 923 335L887 432Q857 479 836 535Q810 576 756 624Q783 729 840 815L881 931Q897 1008 972 1110Q1006 1154 990 1202L928 1222 875 1180Q880 1265 955 1347Q1007 1400 986 1461L946 1540Q915 1592 871 1635Q829 1675 786 1648L730 1599Q704 1562 735 1510L773 1440Q799 1406 769 1371L707 1302Q655 1285 618 1237Q589 1172 536 1149L513 1079Q486 1052 456 1033L431 946Q402 883 363 854L349 780Q351 733 399 669Q412 633 381 568L354 496Q328 450 279 425L219 350Q157 301 80 289L30 250Z", Nt = "M201 1555Q279 1509 361 1534L451 1572 559 1605 680 1650Q632 1718 561 1721L478 1710Q422 1741 372 1683L301 1649 247 1607Z", Pt = [
	[
		23,
		187,
		72
	],
	[
		265,
		218,
		83
	],
	[
		238,
		272,
		100
	],
	[
		37,
		303,
		103
	],
	[
		248,
		334,
		88
	],
	[
		64,
		390,
		73
	],
	[
		246,
		444,
		103
	],
	[
		19,
		542,
		91
	]
], Ft = [
	[
		91,
		176,
		57
	],
	[
		249,
		201,
		49
	],
	[
		214,
		257,
		51
	],
	[
		123,
		287,
		52
	],
	[
		235,
		319,
		49
	],
	[
		147,
		372,
		55
	],
	[
		229,
		426,
		54
	],
	[
		168,
		525,
		52
	]
], It = (e) => ({
	x: 51 + I[e][0] * .24,
	y: 155 + I[e][1] * .24
}), Lt = (e, t, n) => {
	let [r, i] = I[e], [a, o] = I[t];
	return n === 28 ? `M${r} ${i}Q120 1270 ${a} ${o}` : n === 29 ? `M${r} ${i}Q60 700 150 1320T${a} ${o}` : `M${r} ${i}L${a} ${o}`;
};
function Rt({ effects: e }) {
	return /* @__PURE__ */ h("span", {
		className: "tj-effect-symbols",
		"aria-hidden": "true",
		children: e.map((e, t) => {
			if (e.kind === "choice" && "options" in e) return /* @__PURE__ */ h("span", {
				className: "tj-effect-alternatives",
				children: e.options.map((e, t) => /* @__PURE__ */ g("span", { children: [t > 0 && /* @__PURE__ */ h("i", { children: "/" }), /* @__PURE__ */ h(Rt, { effects: e })] }, t))
			}, t);
			if (e.kind === "or") return /* @__PURE__ */ h("i", { children: "/" }, t);
			if (e.kind === "pay") return /* @__PURE__ */ g("span", {
				className: "tj-paid-effect",
				children: [/* @__PURE__ */ g("small", {
					className: "tj-payment-cost",
					children: [
						"−",
						/* @__PURE__ */ h(Q, { kind: e.vp ? "laurel" : "coin" }),
						e.vp ?? e.coins ?? 0
					]
				}), "then" in e && /* @__PURE__ */ h(Rt, { effects: e.then })]
			}, t);
			let n = e.kind === "coins" ? "coin" : e.kind === "vp" ? "laurel" : e.kind === "idea" ? e.idea ?? "any" : e.kind === "discuss" ? "cup" : e.kind === "buy" ? "card" : e.kind === "teleport" ? "move" : e.kind === "takeTile" || e.kind === "explore" ? "explore" : [
				"move",
				"talk",
				"letter",
				"write",
				"painting"
			].includes(e.kind) ? e.kind : "any";
			return /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(Q, { kind: n }), "n" in e && e.n !== void 0 && /* @__PURE__ */ h("b", { children: e.n })] }, t);
		})
	});
}
function zt({ id: e, compact: t = !1 }) {
	let n = s(), r = F(e), i = yt(e, n);
	return /* @__PURE__ */ g("div", {
		className: `tj-card tj-card-${r.category}${t ? " tj-card-compact" : ""}`,
		children: [
			/* @__PURE__ */ h(At, {}),
			/* @__PURE__ */ h("strong", {
				className: t && i.split(/\s+/).some((e) => e.length > 11) ? "tj-card-title-long" : void 0,
				children: i
			}),
			/* @__PURE__ */ h("div", {
				className: "tj-card-pictures",
				children: /* @__PURE__ */ h(Rt, { effects: r.effects })
			}),
			!t && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("span", {
				className: "tj-card-category",
				children: [n(ut[r.category]), r.level > 0 ? ` · ${[
					"",
					"I",
					"II",
					"III"
				][r.level]}` : ""]
			}), /* @__PURE__ */ h("div", {
				className: "tj-card-effects",
				children: r.effects.map((e, t) => /* @__PURE__ */ h("p", { children: St(X([e]), n) }, t))
			})] }),
			r.level > 0 && /* @__PURE__ */ h("small", {
				className: "tj-card-score",
				title: Tt(r.score, n),
				children: t ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Q, { kind: "laurel" }), r.score.kind === "fixed" ? r.score.n : "×" + r.score.n] }) : Tt(r.score, n)
			})
		]
	});
}
function Bt({ pub: e, name: t, color: n, avatarOf: i, showCity: a, zoom: o, setZoom: c, ...l }) {
	let f = s(), p = r(), ee = l.choices.filter((e) => e.kind === "move" || e.kind === "teleport"), _ = l.selected, v = e.players.find((t) => t.rid === e.active), te = _?.kind === "move" ? _.node : _?.kind === "teleport" ? _.city : void 0, y = L.findIndex(([e, t]) => e === v?.node && t === te || t === v?.node && e === te);
	return /* @__PURE__ */ g("div", {
		className: "tj-map-shell",
		children: [/* @__PURE__ */ g("div", {
			className: "tj-map-tools",
			children: [o > 1 && /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => c(1),
				"aria-label": f("games.timelessjourneys.zoomOut"),
				children: /* @__PURE__ */ h(d, { size: 21 })
			}), /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => c(Math.min(2.5, o + .5)),
				disabled: o >= 2.5,
				"aria-label": f("games.timelessjourneys.zoomIn"),
				children: /* @__PURE__ */ h(u, { size: 21 })
			})]
		}), /* @__PURE__ */ h("div", {
			className: "tj-map-scroll",
			children: /* @__PURE__ */ h("div", {
				className: "tj-map-inner",
				style: {
					width: `${o * 100}%`,
					height: `${o * 100}%`
				},
				children: /* @__PURE__ */ g("svg", {
					className: "tj-italy",
					viewBox: "0 146 375 459",
					"aria-label": f("games.timelessjourneys.ui.map"),
					children: [
						/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ g("linearGradient", {
							id: `${p}-sea`,
							x2: ".8",
							y2: "1",
							children: [/* @__PURE__ */ h("stop", { stopColor: "#65adb0" }), /* @__PURE__ */ h("stop", {
								offset: "1",
								stopColor: "#2d7d86"
							})]
						}) }),
						/* @__PURE__ */ h("rect", {
							x: "0",
							y: "146",
							width: "375",
							height: "459",
							fill: `url(#${p}-sea)`
						}),
						/* @__PURE__ */ g("g", {
							opacity: ".12",
							stroke: "#e5f3d8",
							fill: "none",
							children: [
								[
									175,
									250,
									325,
									400,
									475,
									550
								].map((e) => /* @__PURE__ */ h("path", { d: `M0 ${e}H375` }, e)),
								[
									50,
									125,
									200,
									275,
									350
								].map((e) => /* @__PURE__ */ h("path", { d: `M${e} 146V605` }, e)),
								/* @__PURE__ */ h("path", { d: "M-15 463Q60 409 137 465T334 493M-20 471Q63 416 135 474T335 501M-25 479Q63 424 132 483T335 509" })
							]
						}),
						/* @__PURE__ */ g("g", {
							transform: "translate(51 155) scale(.24)",
							children: [
								[Mt, Nt].map((e, t) => /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
									d: e,
									fill: "#8db4a0",
									stroke: "#c2d7b4",
									strokeWidth: "29"
								}), /* @__PURE__ */ h("path", {
									d: e,
									fill: t ? "#d9cf9a" : "#d1d0a3",
									stroke: "#6c8d71",
									strokeWidth: "5"
								})] }, t)),
								/* @__PURE__ */ h("path", {
									d: "M125 72l90 80 102-66 118 90 145-85 95 78 136-72 160 90v54L823 194l-123 59-160-72-130 78-115-79-92 62-121-54z",
									fill: "#b0b590"
								}),
								/* @__PURE__ */ h("path", {
									d: "M125 72l90 80 102-66 118 90 145-85 95 78 136-72 160 90",
									fill: "none",
									stroke: "#e5dfba",
									strokeWidth: "12"
								}),
								/* @__PURE__ */ h("path", {
									d: "M585 399Q689 538 616 700T621 1022Q626 1131 739 1210L731 1253Q574 1157 555 1037T555 788Q636 624 553 437z",
									fill: "#bcc296"
								}),
								/* @__PURE__ */ h("path", {
									d: "M620 452l28 38-21-9m24 107 26 34-21-6m-48 101 18 33-21-7m-22 101 18 29-18-6m31 101 27 40-27-12m17 111 23 32-23-8m58 94 21 35-26-13",
									fill: "none",
									stroke: "#849a76",
									strokeWidth: "4"
								}),
								/* @__PURE__ */ h("path", {
									d: "M708 261q-44 45-139 29t-175 29",
									fill: "none",
									stroke: "#80ada0",
									strokeWidth: "7"
								}),
								/* @__PURE__ */ h("path", {
									d: "M50 655q-50 50-19 132l40 38 15-52-18-70z",
									fill: "#b7bf92",
									stroke: "#84a38c",
									strokeWidth: "4"
								}),
								L.map(([e, t, n], r) => /* @__PURE__ */ g("g", { children: [
									/* @__PURE__ */ h("path", {
										d: Lt(e, t, r),
										fill: "none",
										stroke: r >= 26 ? "#eddfac" : "#8e9473",
										strokeWidth: r >= 26 ? 6 : 13,
										strokeDasharray: r >= 26 ? "15 13" : void 0
									}),
									r < 26 && /* @__PURE__ */ h("path", {
										d: Lt(e, t, r),
										fill: "none",
										stroke: "#fff3cb",
										strokeWidth: "6"
									}),
									n > 0 && /* @__PURE__ */ g("g", {
										transform: `translate(${r === 28 ? 225 : r === 29 ? 125 : (I[e][0] + I[t][0]) / 2} ${r === 28 ? 1250 : r === 29 ? 1e3 : (I[e][1] + I[t][1]) / 2})`,
										children: [/* @__PURE__ */ h("circle", {
											r: "16",
											fill: "#dbb261",
											stroke: "#8d793f",
											strokeWidth: "3"
										}), /* @__PURE__ */ h("text", {
											y: "7",
											fontSize: "23",
											textAnchor: "middle",
											fill: "#655431",
											children: n
										})]
									})
								] }, r)),
								y >= 0 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
									d: Lt(L[y][0], L[y][1], y),
									className: "tj-route-glow"
								}), /* @__PURE__ */ h("path", {
									d: Lt(L[y][0], L[y][1], y),
									className: "tj-route-selected"
								})] }),
								I.map(([e, t], n) => /* @__PURE__ */ h("circle", {
									cx: e,
									cy: t,
									r: n < 8 ? 24 : 14,
									fill: "#fff5d7",
									stroke: n < 8 ? Et[n] : "#9d9770",
									strokeWidth: n < 8 ? 7 : 3
								}, n))
							]
						}),
						/* @__PURE__ */ h("text", {
							x: "44",
							y: "415",
							transform: "rotate(-74 44 415)",
							className: "tj-map-water",
							children: f("games.timelessjourneys.westSea")
						}),
						/* @__PURE__ */ h("text", {
							x: "330",
							y: "340",
							transform: "rotate(71 330 340)",
							className: "tj-map-water",
							children: f("games.timelessjourneys.eastSea")
						}),
						Ft.map(([e, t, n], r) => /* @__PURE__ */ h(Dt, {
							city: r,
							x: e - n / 2,
							y: t - n * .6,
							width: n,
							height: n * .81
						}, r)),
						Pt.map(([t, n, r], i) => {
							let o = e.travelers.filter((t, n) => he[e.gazette][e.round - 1][n] === i);
							return /* @__PURE__ */ g("g", {
								role: "button",
								tabIndex: 0,
								"aria-label": Z(i, f),
								onClick: () => a(i),
								onKeyDown: (e) => {
									(e.key === "Enter" || e.key === " ") && (e.preventDefault(), a(i));
								},
								className: "tj-city-map-label",
								children: [
									/* @__PURE__ */ h("rect", {
										x: t - 4,
										y: n - 10,
										width: r + 8,
										height: "44",
										fill: "transparent"
									}),
									/* @__PURE__ */ h("path", {
										d: `M${t - 7} ${n + 4}h12v20H${t - 7}l6-10zM${t + r + 7} ${n + 1}h-13v20h13l-6-10z`,
										fill: Et[i],
										opacity: ".75"
									}),
									/* @__PURE__ */ h("rect", {
										x: t,
										y: n,
										width: r,
										height: "24",
										rx: "2",
										fill: Et[i],
										stroke: "#fff3d5",
										strokeWidth: ".7"
									}),
									/* @__PURE__ */ h("path", {
										d: `M${t + 5} ${n + 3}H${t + r - 5}`,
										stroke: "#fff5d5",
										strokeWidth: ".6",
										opacity: ".5"
									}),
									/* @__PURE__ */ h("text", {
										x: t + r / 2 - (o.length ? 9 : 0),
										y: n + 16.5,
										textAnchor: "middle",
										fontSize: "12",
										fontWeight: "700",
										fill: "#fff7e0",
										children: Z(i, f)
									}),
									o.map((e, i) => /* @__PURE__ */ h(kt, {
										traveler: e,
										x: t + r - 20 - i * 15,
										y: n + 2,
										width: "17",
										height: "21"
									}, e))
								]
							}, i);
						}),
						ee.map((t) => {
							let { x: n, y: r } = It(t.node ?? t.city), i = _?.id === t.id;
							return /* @__PURE__ */ g("g", {
								role: "button",
								tabIndex: 0,
								"aria-label": `${Ct(t, e, f)}${t.cost === void 0 ? "" : ` · ${f("games.timelessjourneys.ui.moveCost", { n: t.cost })}`}`,
								"aria-pressed": i,
								onClick: () => l.onSelect(t),
								onKeyDown: (e) => {
									(e.key === "Enter" || e.key === " ") && (e.preventDefault(), l.onSelect(t));
								},
								className: "tj-destination",
								children: [
									/* @__PURE__ */ h("rect", {
										x: n - 22,
										y: r - 22,
										width: "44",
										height: "44",
										fill: "transparent"
									}),
									/* @__PURE__ */ h("circle", {
										cx: n,
										cy: r,
										r: i ? 15 : 11,
										fill: i ? "#e7f4eb" : "#eef6dd",
										stroke: "#e1f1f4",
										strokeWidth: "5"
									}),
									/* @__PURE__ */ h("circle", {
										cx: n,
										cy: r,
										r: i ? 13 : 10,
										fill: "none",
										stroke: "#236f9a",
										strokeWidth: "2"
									}),
									i && /* @__PURE__ */ h("path", {
										d: `M${n - 6} ${r}l4 4 8-9`,
										fill: "none",
										stroke: "#236f9a",
										strokeWidth: "2.5"
									}),
									/* @__PURE__ */ g("g", {
										transform: `translate(${Math.max(5, Math.min(326, n - 20))} ${r + 19})`,
										children: [
											/* @__PURE__ */ h("rect", {
												width: "45",
												height: "20",
												rx: "3",
												fill: i ? "#236f9a" : "#fff6da",
												stroke: "#e7f4eb"
											}),
											/* @__PURE__ */ h(Q, {
												kind: "coin",
												x: "3",
												y: "3",
												width: "14",
												height: "14"
											}),
											/* @__PURE__ */ h("text", {
												x: "30",
												y: "14",
												textAnchor: "middle",
												fontSize: "12",
												fill: i ? "white" : "#3e443b",
												children: t.cost ?? 0
											})
										]
									})
								]
							}, t.id);
						}),
						e.players.map((r) => {
							let { x: a, y: o } = It(r.node), s = e.players.filter((e) => e.node === r.node), c = s.findIndex((e) => e.rid === r.rid), l = a + (c - (s.length - 1) / 2) * 17;
							return /* @__PURE__ */ g("g", {
								className: "tj-pawn",
								style: { transform: `translate(${l}px,${o - 14}px)` },
								children: [
									/* @__PURE__ */ h("title", { children: t(r.rid) }),
									/* @__PURE__ */ h("path", {
										d: "M-9 10l3-13H6l3 13q-9 4-18 0z",
										fill: n(r.rid),
										stroke: "#fff3db",
										strokeWidth: "1.5"
									}),
									/* @__PURE__ */ h("circle", {
										cy: "-8",
										r: "6",
										fill: n(r.rid),
										stroke: "#fff3db",
										strokeWidth: "1.5"
									}),
									/* @__PURE__ */ h("image", {
										href: i(r.rid),
										x: -7,
										y: -6,
										width: 14,
										height: 14,
										preserveAspectRatio: "xMidYMid meet",
										pointerEvents: "none"
									}),
									c === s.length - 1 && /* @__PURE__ */ h("text", {
										x: a > 220 ? -12 - (s.length - 1) * 17 : 12,
										y: "-4",
										textAnchor: a > 220 ? "end" : "start",
										className: "tj-pawn-name",
										children: s.length > 2 ? f("games.timelessjourneys.ui.travelGroup", { n: s.length }) : s.map((e) => t(e.rid)).join(" · ")
									})
								]
							}, r.rid);
						}),
						/* @__PURE__ */ g("g", {
							transform: "translate(304 555)",
							stroke: "#b5d7bf",
							fill: "none",
							opacity: ".75",
							children: [
								/* @__PURE__ */ h("circle", {
									r: "23",
									strokeWidth: ".8"
								}),
								/* @__PURE__ */ h("path", {
									d: "M0-30L5-5 30 0 5 5 0 30-5 5-30 0-5-5z",
									strokeWidth: ".8"
								}),
								/* @__PURE__ */ h("path", {
									d: "M0-24L4-4 0 0-4-4z",
									fill: "#c9dcc2"
								}),
								/* @__PURE__ */ h("text", {
									y: "-34",
									textAnchor: "middle",
									fontSize: "12",
									fill: "#c2dfc7",
									children: "N"
								})
							]
						})
					]
				})
			})
		})]
	});
}
function Vt({ pub: e, name: t, color: n, owner: r, experience: i, onExperience: a, onTraveler: o, ...c }) {
	let u = s();
	return /* @__PURE__ */ g("div", {
		className: "tj-scroll tj-gazette",
		children: [
			/* @__PURE__ */ g("h2", {
				className: "tj-gazette-title" + (u("games.timelessjourneys.gazetteTitle").length > 20 ? " tj-gazette-title-long" : ""),
				children: [u("games.timelessjourneys.gazetteTitle"), /* @__PURE__ */ h("small", { children: e.gazette })]
			}),
			/* @__PURE__ */ h("div", { className: "tj-flourish" }),
			/* @__PURE__ */ h("div", {
				className: "tj-gazette-columns",
				children: e.travelers.map((r, a) => /* @__PURE__ */ g("section", { children: [
					/* @__PURE__ */ g("button", {
						className: "tj-traveler",
						type: "button",
						onClick: () => o(a),
						"aria-label": `${u(dt[r])} · ${u(ft[r])}`,
						children: [
							/* @__PURE__ */ h(kt, { traveler: r }),
							/* @__PURE__ */ h("strong", { children: u(dt[r]) }),
							/* @__PURE__ */ h(Rt, { effects: V[e.gazette][a] })
						]
					}),
					Array.from({ length: 5 }, (r, o) => {
						let s = e.experiences[a][o], d = e.players.length < ge[a][o], f = he[e.gazette][o][a], p = c.choices.find((e) => e.kind === "traveler" && e.traveler === a && e.row === o && e.experience === i), ee = p?.id === c.selected?.id && !!p;
						return /* @__PURE__ */ g("button", {
							type: "button",
							className: "tj-gazette-slot",
							"data-current": o === e.round - 1,
							"data-blocked": d,
							"data-ready": !!p,
							"data-selected": ee,
							disabled: !p,
							onClick: () => p && c.onSelect(p),
							"aria-label": p ? `${Ct(p, e, u)} · ${[
								"I",
								"II",
								"III",
								"IV",
								"V"
							][o]} · ${Z(f, u)}` : `${[
								"I",
								"II",
								"III",
								"IV",
								"V"
							][o]} · ${Z(f, u)} · ${s ? `${t(s.rid)} · ${u(pt[s.kind])}` : d ? `${ge[a][o]}+` : u("games.timelessjourneys.ui.empty")}`,
							"aria-pressed": ee,
							children: [/* @__PURE__ */ g("span", {
								className: "tj-gazette-city",
								style: { color: Et[f] },
								children: [a === 0 && /* @__PURE__ */ h("i", { children: [
									"I",
									"II",
									"III",
									"IV",
									"V"
								][o] }), Z(f, u)]
							}), s ? /* @__PURE__ */ g("span", {
								className: "tj-gazette-token",
								style: { color: n(s.rid) },
								children: [
									/* @__PURE__ */ h(Q, { kind: s.kind }),
									/* @__PURE__ */ h("b", { children: t(s.rid) }),
									s.kind === "affinity1" ? "Ⅰ" : s.kind === "affinity2" ? "Ⅱ" : ""
								]
							}) : ee ? /* @__PURE__ */ g("span", {
								className: "tj-gazette-token",
								children: [/* @__PURE__ */ h(Q, { kind: i }), /* @__PURE__ */ h(l, { size: 14 })]
							}) : d ? /* @__PURE__ */ g("span", {
								className: "tj-locked",
								children: [
									/* @__PURE__ */ h(Q, { kind: "lock" }),
									ge[a][o],
									"+"
								]
							}) : /* @__PURE__ */ h("span", { className: "tj-empty-oval" })]
						}, o);
					}),
					/* @__PURE__ */ g("div", {
						className: "tj-majority",
						children: [/* @__PURE__ */ h(Q, { kind: "laurel" }), /* @__PURE__ */ g("span", { children: ["5 · ", e.players.length === 2 ? "— · —" : "3 · 1"] })]
					})
				] }, r))
			}),
			/* @__PURE__ */ h("div", {
				className: "tj-experiences",
				"aria-label": u("games.timelessjourneys.ui.experiences"),
				children: re.map((t) => {
					let n = e.experiences.flat().some((e) => e?.rid === r && e.kind === t), o = c.choices.some((e) => e.experience === t);
					return /* @__PURE__ */ g("button", {
						type: "button",
						disabled: !o,
						"data-used": n,
						"aria-pressed": o && t === i,
						onClick: () => a(t),
						children: [
							/* @__PURE__ */ h(Q, { kind: t }),
							/* @__PURE__ */ h("span", { children: u(pt[t]) }),
							n && /* @__PURE__ */ h(l, { size: 12 })
						]
					}, t);
				})
			})
		]
	});
}
function Ht({ p: e, showCard: t, showCity: n, ...r }) {
	let i = s(), a = (e) => e.length === 1 ? r.onSelect(e[0]) : r.onOptions(e);
	return /* @__PURE__ */ g(m, { children: [
		e.journals.map((e, t) => {
			let o = de[e.id], s = e.ideas.reduce((e, t) => e + t, 0) + Number(e.tile) + Number(e.friend), l = r.choices.filter((e) => e.kind === "writeTile" && e.journal === t), u = r.choices.filter((e) => e.kind === "writeFriend" && e.journal === t);
			return /* @__PURE__ */ h("section", {
				className: "tj-journal",
				"aria-label": i("games.timelessjourneys.ui.journal", { n: t + 1 }),
				children: /* @__PURE__ */ g("div", {
					className: "tj-journal-pages",
					children: [/* @__PURE__ */ g("div", {
						className: "tj-journal-left",
						children: [
							/* @__PURE__ */ g("div", {
								className: "tj-journal-title",
								children: [/* @__PURE__ */ h("span", { children: i("games.timelessjourneys.ui.journal", { n: t + 1 }) }), /* @__PURE__ */ g("span", {
									"aria-label": i("games.timelessjourneys.ui.journalProgress", { n: s }),
									children: [s, " / 8"]
								})]
							}),
							/* @__PURE__ */ h(jt, {
								city: o.city,
								label: Z(o.city, i)
							}),
							/* @__PURE__ */ g("div", {
								className: "tj-journal-objects",
								children: [/* @__PURE__ */ g("button", {
									className: "tj-city-stamp",
									type: "button",
									onClick: () => l.length ? a(l) : n(o.city),
									"data-filled": e.tile,
									"data-ready": !!l.length,
									"data-selected": !!r.selected && l.some((e) => e.id === r.selected.id),
									"aria-label": l.length ? i("games.timelessjourneys.choice.writeTile", {
										city: Z(o.city, i),
										n: t + 1
									}) : i("games.timelessjourneys.ui.journalTile"),
									children: [/* @__PURE__ */ h(Dt, { city: o.city }), /* @__PURE__ */ h("span", { children: e.tile ? Z(o.city, i) : i("games.timelessjourneys.ui.journalTile") })]
								}), /* @__PURE__ */ g("button", {
									className: "tj-friend-slot",
									type: "button",
									disabled: !u.length,
									onClick: () => a(u),
									"data-filled": e.friend,
									"data-ready": !!u.length,
									"data-selected": !!r.selected && u.some((e) => e.id === r.selected.id),
									"aria-label": i("games.timelessjourneys.ui.journalFriend"),
									children: [/* @__PURE__ */ h(Q, { kind: "friend" }), /* @__PURE__ */ h("span", { children: i("games.timelessjourneys.ui.friends") })]
								})]
							}),
							/* @__PURE__ */ h("div", { className: "tj-flourish" })
						]
					}), /* @__PURE__ */ h("div", {
						className: "tj-journal-right",
						children: o.types.map((n) => {
							let a = e.ideas[b.indexOf(n)], o = r.choices.find((e) => e.kind === "writeIdea" && e.journal === t && e.idea === n);
							return /* @__PURE__ */ g("div", {
								className: "tj-journal-idea-row",
								children: [/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(Q, { kind: n }), i(lt[n])] }), /* @__PURE__ */ h("div", { children: Array.from({ length: 3 }, (e, s) => {
									let l = s === a && !!o, u = l && o.id === r.selected?.id;
									return /* @__PURE__ */ g("button", {
										type: "button",
										disabled: !l,
										"data-filled": s < a,
										"data-ready": l,
										"data-selected": u,
										onClick: () => o && r.onSelect(o),
										"aria-label": l ? i("games.timelessjourneys.choice.writeIdea", {
											idea: i(lt[n]),
											n: t + 1
										}) : `${i(lt[n])} ${s + 1}/3`,
										"aria-pressed": u,
										children: [/* @__PURE__ */ h(Q, { kind: n }), u && /* @__PURE__ */ h(c, { size: 12 })]
									}, s);
								}) })]
							}, n);
						})
					})]
				})
			}, t);
		}),
		/* @__PURE__ */ h("h3", {
			className: "tj-section-caption",
			children: i("games.timelessjourneys.ui.reserve")
		}),
		/* @__PURE__ */ g("div", {
			className: "tj-collection",
			children: [
				e.tiles.map((e, t) => {
					let n = r.choices.filter((e) => (e.kind === "useTile" || e.kind === "reactivate") && e.tile === t);
					return /* @__PURE__ */ g("button", {
						type: "button",
						className: "tj-tile",
						"data-used": e.used || e.journal !== null,
						"data-ready": !!n.length,
						onClick: () => a(n),
						disabled: !n.length,
						children: [
							/* @__PURE__ */ h(Dt, { city: e.city }),
							/* @__PURE__ */ h("b", { children: Z(e.city, i) }),
							/* @__PURE__ */ h("span", { children: St(X(le[e.city][e.index]), i) }),
							/* @__PURE__ */ g("small", { children: [i(e.used ? "games.timelessjourneys.ui.used" : "games.timelessjourneys.ui.unused"), e.journal === null ? "" : ` · ${i("games.timelessjourneys.ui.journal", { n: e.journal + 1 })}`] })
						]
					}, t);
				}),
				e.letters.map((e) => /* @__PURE__ */ g("span", {
					className: "tj-collection-tag",
					children: [
						/* @__PURE__ */ h(Q, { kind: "letter" }),
						Z(e.city, i),
						" · ",
						e.local + 1
					]
				}, `l${e.city}`)),
				e.friends.map((e, t) => /* @__PURE__ */ g("span", {
					className: "tj-collection-tag",
					"data-used": e.journal !== null,
					children: [
						/* @__PURE__ */ h(Q, { kind: "friend" }),
						Z(e.city, i),
						e.journal === null ? "" : ` · ${i("games.timelessjourneys.ui.journal", { n: e.journal + 1 })}`
					]
				}, `f${t}`)),
				e.paintings.map((e) => /* @__PURE__ */ g("span", {
					className: "tj-collection-tag",
					children: [/* @__PURE__ */ h(Q, { kind: "painting" }), i("games.timelessjourneys.ui.paintType", { n: e + 1 })]
				}, `p${e}`)),
				!e.tiles.length && !e.friends.length && !e.letters.length && !e.paintings.length && /* @__PURE__ */ h("span", {
					className: "tj-empty-collection",
					children: i("games.timelessjourneys.ui.empty")
				})
			]
		}),
		e.finalHand && /* @__PURE__ */ h("div", {
			className: "tj-mini-cards",
			children: e.finalHand.map((e) => /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => t(e),
				children: /* @__PURE__ */ h(zt, {
					id: e,
					compact: !0
				})
			}, e))
		})
	] });
}
function Ut({ pub: e, showCard: t, ...n }) {
	let r = s();
	return /* @__PURE__ */ h("div", {
		className: "tj-scroll tj-market",
		children: e.market.map((i, a) => /* @__PURE__ */ g("section", {
			className: "tj-market-shelf",
			children: [/* @__PURE__ */ g("div", {
				className: "tj-section-title",
				children: [/* @__PURE__ */ h("h3", { children: r("games.timelessjourneys.ui.level", { n: [
					"I",
					"II",
					"III"
				][a] }) }), /* @__PURE__ */ g("span", { children: [r("games.timelessjourneys.ui.threshold", { n: a + 2 }), /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(Q, { kind: "coin" }), [
					0,
					2,
					5
				][a]] })] })]
			}), /* @__PURE__ */ h("div", {
				className: "tj-market-row",
				children: [...i, ...e.deckTop[a] ? [e.deckTop[a]] : []].map((o, s) => {
					let c = n.choices.find((e) => e.kind === "buy" && e.card === o);
					return /* @__PURE__ */ g("button", {
						type: "button",
						className: "tj-market-card",
						"data-deck": s === i.length,
						"data-ready": !!c,
						"data-selected": c?.id === n.selected?.id && !!c,
						onClick: () => c ? n.onSelect(c) : t(o),
						"aria-label": c ? Ct(c, e, r) : yt(o, r),
						"aria-pressed": !!c && c.id === n.selected?.id,
						children: [
							s === i.length && /* @__PURE__ */ g("span", {
								className: "tj-deck-label",
								children: [
									r("games.timelessjourneys.ui.deck"),
									" · ",
									e.deckSize[a]
								]
							}),
							/* @__PURE__ */ h(zt, { id: o }),
							c && /* @__PURE__ */ g("span", {
								className: "tj-market-cost",
								children: [/* @__PURE__ */ h(Q, { kind: "coin" }), c.cost ?? 0]
							})
						]
					}, o);
				})
			})]
		}, a))
	});
}
function Wt({ city: e, pub: t, owner: n, onCity: r, name: i, color: a, choices: o, choiceButton: c }) {
	let l = s(), u = B[e], d = t.players.find((e) => e.rid === n), f = t.travelers.filter((n, r) => he[t.gazette][t.round - 1][r] === e), p = f.filter((e) => e === "montesquieu" || e === "craven"), ee = f.includes("montesquieu") ? 4 : 0, m = f.includes("craven"), _ = t.players.length === 5 ? 3 : 2, v = t.players.length === 5 ? 2 : 1, te = t.players.filter((t) => t.letters.some((t) => t.city === e)).length, y = (e) => /* @__PURE__ */ g("section", {
		className: "tj-city-visitor",
		children: [/* @__PURE__ */ h(kt, { traveler: e }), /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("h3", { children: l(dt[e]) }), /* @__PURE__ */ h("p", { children: l(ft[e]) })] })]
	}, e);
	return /* @__PURE__ */ g("div", {
		className: "tj-city-details",
		style: { "--tj-city": Et[e] },
		children: [
			/* @__PURE__ */ g("div", {
				className: "tj-city-vignette",
				children: [/* @__PURE__ */ h(Dt, { city: e }), /* @__PURE__ */ h("select", {
					value: e,
					onChange: (e) => r(Number(e.target.value)),
					"aria-label": l("games.timelessjourneys.ui.selectCity"),
					children: B.map((e, t) => /* @__PURE__ */ h("option", {
						value: t,
						children: Z(t, l)
					}, t))
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: "tj-city-summary",
				children: [
					/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(Q, { kind: "explore" }), l("games.timelessjourneys.ui.explorationLeft", { n: t.remainingTiles[e] })] }),
					d && /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(Q, { kind: "explore" }), l(d.tiles.some((t) => t.city === e) ? "games.timelessjourneys.ui.explorationCollected" : "games.timelessjourneys.ui.explorationUncollected")] }),
					/* @__PURE__ */ h("p", { children: l("games.timelessjourneys.ui.cityReward", { reward: St(X(u.bonus), l) }) })
				]
			}),
			o.some((t) => t.city === e && [
				"explore",
				"cityBonus",
				"teleport"
			].includes(t.kind)) && /* @__PURE__ */ h("div", {
				className: "tj-choice-list",
				children: o.filter((t) => t.city === e && [
					"explore",
					"cityBonus",
					"teleport"
				].includes(t.kind)).map(c)
			}),
			f.filter((e) => e !== "montesquieu" && e !== "craven").map(y),
			/* @__PURE__ */ g("div", {
				className: "tj-city-letter-count",
				children: [/* @__PURE__ */ h(Q, { kind: "letter" }), l("games.timelessjourneys.ui.cityLetters", {
					used: te,
					max: _
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: "tj-locals",
				children: [0, 1].map((n) => {
					let r = t.players.filter((t) => t.letters.some((t) => t.city === e && t.local === n)), s = d?.letters.some((t) => t.city === e && t.local !== n) ?? !1, u = t.players.find((t) => t.friends.some((t) => t.city === e && t.local === n));
					return /* @__PURE__ */ g("section", { children: [
						/* @__PURE__ */ g("h3", { children: [/* @__PURE__ */ h(Q, { kind: "talk" }), l("games.timelessjourneys.ui.local", { n: n + 1 })] }),
						/* @__PURE__ */ h("p", { children: St(X(ue[t.favors[e]][n]), l) }),
						(t.friends[e] === n || u) && /* @__PURE__ */ g("span", {
							className: "tj-local-friend",
							children: [/* @__PURE__ */ h(Q, { kind: "friend" }), u ? l("games.timelessjourneys.ui.friendCollectedBy", { name: i(u.rid) }) : l("games.timelessjourneys.ui.friendAvailable")]
						}),
						/* @__PURE__ */ h("div", {
							className: "tj-local-letters",
							"aria-label": l("games.timelessjourneys.ui.localLetters", {
								used: r.length,
								max: v
							}),
							children: Array.from({ length: v }, (e, t) => {
								let n = r[t], o = !n && t - r.length >= _ - te + +!!s;
								return /* @__PURE__ */ g("span", {
									"data-filled": !!n,
									"data-blocked": o,
									style: n ? { color: a(n.rid) } : void 0,
									children: [/* @__PURE__ */ h(Q, { kind: o ? "lock" : "letter" }), n ? i(n.rid) : l(o ? "games.timelessjourneys.ui.cityLettersFull" : s && te === _ ? "games.timelessjourneys.ui.letterRelocate" : "games.timelessjourneys.ui.letterVacancy")]
								}, t);
							})
						}),
						o.filter((t) => t.city === e && t.local === n && [
							"talk",
							"letter",
							"correspond",
							"friend"
						].includes(t.kind)).map(c)
					] }, n);
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "tj-city-cafe-effects",
				children: p.map(y)
			}),
			/* @__PURE__ */ h("div", {
				className: "tj-city-cafes",
				children: u.discussions.map((n, r) => /* @__PURE__ */ g("section", {
					className: "tj-coffee",
					children: [
						/* @__PURE__ */ g("h3", { children: [/* @__PURE__ */ h(Q, { kind: "cup" }), l("games.timelessjourneys.ui.discussion", { n: r + 1 })] }),
						/* @__PURE__ */ g("p", { children: [m && /* @__PURE__ */ g("span", { children: [l("games.timelessjourneys.ui.baseIdeas"), " "] }), n.map((e) => bt(e, l)).join(` ${l("games.timelessjourneys.effect.or")} `)] }),
						/* @__PURE__ */ h("div", {
							className: "tj-cafe-seats",
							children: u.points.map((n, o) => {
								let s = t.cafes[e][r][o], c = n + ee;
								return /* @__PURE__ */ g("span", {
									"data-filled": !!s,
									style: s ? { color: a(s) } : void 0,
									"aria-label": s ? l("games.timelessjourneys.ui.occupiedCafe", {
										name: i(s),
										n
									}) : l("games.timelessjourneys.ui.score", { n: c }),
									children: [
										/* @__PURE__ */ h(Q, { kind: "cup" }),
										/* @__PURE__ */ h("b", { children: s ? n : c }),
										/* @__PURE__ */ h("small", { children: l(s ? "games.timelessjourneys.ui.baseVp" : "games.timelessjourneys.ui.scoreUnit") }),
										s && /* @__PURE__ */ h("span", { children: i(s) })
									]
								}, o);
							})
						}),
						o.some((t) => t.kind === "discuss" && t.city === e && t.local === r) && /* @__PURE__ */ h("div", {
							className: "tj-choice-list",
							children: o.filter((t) => t.kind === "discuss" && t.city === e && t.local === r).map(c)
						})
					]
				}, r))
			})
		]
	});
}
//#endregion
//#region src/games/timelessjourneys/view-player.tsx
var Gt = {
	map: "games.timelessjourneys.ui.map",
	gazette: "games.timelessjourneys.ui.gazette",
	market: "games.timelessjourneys.ui.market",
	journals: "games.timelessjourneys.ui.journals",
	players: "games.timelessjourneys.ui.players"
}, Kt = (e) => [
	"useTile",
	"byron",
	"dickensExplore",
	"dickensDiscuss"
].includes(e.kind), qt = (e) => [
	"skip",
	"endChain",
	"endEffects"
].includes(e.kind), Jt = [
	"move",
	"teleport",
	"writeIdea",
	"writeTile",
	"writeFriend",
	"buy",
	"talk",
	"traveler",
	"letter",
	"explore",
	"cityBonus",
	"discuss"
];
function Yt({ open: e, onClose: t, title: n, children: r }) {
	let [a, s] = i({
		title: n,
		children: r
	});
	e && (a.title !== n || a.children !== r) && s({
		title: n,
		children: r
	});
	let c = e ? {
		title: n,
		children: r
	} : a;
	return /* @__PURE__ */ h(o, {
		open: e,
		onClose: t,
		label: c.title,
		title: c.title,
		children: c.children
	});
}
function Xt(e) {
	p();
	let t = s(), r = e.public, o = e.private, c = o?.choices ?? [], u = r.active === e.myRid, d = r.players.find((t) => t.rid === e.myRid), _ = c[0]?.id.split(":")[0] ?? "", v = r.task[0]?.kind, [te, y] = i(null), [ne, x] = i(null), [S, C] = i(""), [w, T] = i(""), [E, D] = i(null), [O, k] = i(0), [A, j] = i(0), [M, ie] = i(null), [N, ae] = i(1), [P, oe] = i("affinity1"), [se, F] = i(e.myRid), ce = u && v === "write" ? "journals" : u && (v === "buy" || r.phase === "market") ? "market" : "map", I = te ?? ce, L = (e) => y(e), R = (t) => e.members.find((e) => e.rid === t)?.name ?? t, z = (t) => f[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % f.length].hex, B = r.phase === "action" ? r.stage : r.phase, le = c.some((e) => Jt.includes(e.kind)), ue = le && (v === "move" || v === "teleport") ? t("games.timelessjourneys.ui.selectDestination") : le && v === "write" ? t("games.timelessjourneys.ui.selectJournal") : r.task.length ? St(r.task, t) : t(ht[B]), de = c.filter((e) => !Kt(e) && !qt(e)), fe = c.find((e) => e.id === w), pe = fe ?? c.find((e) => e.kind === "endTurn") ?? (de.length === 1 ? de[0] : void 0), me = c.find(qt), he = u && r.task.length > 0 && c.length > 0 && !le && S !== _, V = ne ?? (he ? "choices" : null), ge = () => {
		x(null), C(_), ie(null);
	}, _e = (t) => {
		ge(), e.send({
			type: "choose",
			id: t.id
		}), T("");
	}, ve = (e) => {
		T(e.id), ge();
	}, ye = (e) => {
		D(e), x("card");
	}, be = (e) => {
		k(e), x("city");
	}, xe = (e) => {
		j(e), x("traveler");
	}, Se = (e) => {
		ie(e?.map((e) => e.id) ?? null), x("choices");
	}, H = {
		choices: u ? c : [],
		selected: fe,
		onSelect: ve,
		onOptions: Se
	}, Ce = r.stage === "chain" && u ? d?.played.flatMap((e) => e.card ? [e.card] : []) ?? [] : o?.hand ?? [], we = c.some((e) => e.experience === P) ? P : re.find((e) => c.some((t) => t.experience === e)) ?? P, Te = r.travelers[A], Ee = (e) => /* @__PURE__ */ g("button", {
		type: "button",
		className: "tj-choice" + (qt(e) ? " tj-choice-quiet" : ""),
		onClick: () => _e(e),
		children: [
			/* @__PURE__ */ h("span", { children: Ct(e, r, t) }),
			e.effects && ![
				"branch",
				"effect",
				"pay",
				"takeTile"
			].includes(e.kind) && /* @__PURE__ */ h("small", { children: St(e.effects, t) }),
			e.kind === "discuss" && /* @__PURE__ */ g("small", { children: [
				t("games.timelessjourneys.ui.payIdeas", { ideas: bt(e.ideas ?? [], t) }),
				" · ",
				t("games.timelessjourneys.ui.score", { n: e.points ?? 0 })
			] }),
			["buy", "move"].includes(e.kind) && e.cost !== void 0 && /* @__PURE__ */ h("small", { children: t("games.timelessjourneys.ui.cost", { n: e.cost }) }),
			e.kind === "correspond" && e.n !== void 0 && /* @__PURE__ */ h("small", { children: t("games.timelessjourneys.ui.letterFrom", { city: Z(e.n, t) }) }),
			e.experience && /* @__PURE__ */ g("small", { children: [
				t(mt[e.experience]),
				" · ",
				[
					"I",
					"II",
					"III",
					"IV",
					"V"
				][e.row ?? 0]
			] })
		]
	}, e.id), De = (e) => {
		let n = r.players.find((t) => t.rid === e);
		return /* @__PURE__ */ g("div", {
			className: "tj-resources",
			"aria-label": t("games.timelessjourneys.ui.reserve"),
			children: [
				/* @__PURE__ */ g("span", {
					title: t("games.timelessjourneys.ui.coins"),
					children: [/* @__PURE__ */ h(Q, { kind: "coin" }), n?.coins ?? 0]
				}),
				b.map((e, r) => /* @__PURE__ */ g("span", {
					title: t(lt[e]),
					children: [/* @__PURE__ */ h(Q, { kind: e }), n?.ideas[r] ?? 0]
				}, e)),
				/* @__PURE__ */ g("span", {
					title: t("games.timelessjourneys.ui.letters"),
					children: [
						/* @__PURE__ */ h(Q, { kind: "letter" }),
						n?.letters.length ?? 0,
						"/3"
					]
				})
			]
		});
	}, Oe = V === "card" && E ? yt(E, t) : V === "city" ? Z(O, t) : t(V === "traveler" ? dt[Te] : V === "players" ? Gt.players : v === "takeTile" ? "games.timelessjourneys.ui.chooseTile" : "games.timelessjourneys.ui.decisions"), ke = /* @__PURE__ */ h("div", {
		className: "tj-player-list",
		children: r.players.map((r) => /* @__PURE__ */ g("details", {
			className: "tj-player-panel",
			open: r.rid === se,
			onToggle: (e) => {
				e.currentTarget.open && F(r.rid);
			},
			children: [
				/* @__PURE__ */ g("summary", {
					style: { "--tj-player": z(r.rid) },
					children: [
						/* @__PURE__ */ h("span", {
							className: "tj-player-medallion",
							children: /* @__PURE__ */ h("img", {
								src: n[(e.members.find((e) => e.rid === r.rid)?.avatar ?? 0) % n.length],
								alt: "",
								draggable: !1,
								style: {
									width: "1.75em",
									height: "1.75em",
									maxWidth: "100%",
									maxHeight: "100%",
									display: "block",
									objectFit: "contain",
									pointerEvents: "none",
									borderRadius: "inherit"
								}
							})
						}),
						/* @__PURE__ */ h("strong", { children: R(r.rid) }),
						/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(Q, { kind: "laurel" }), r.vp] })
					]
				}),
				/* @__PURE__ */ g("p", { children: [
					t("games.timelessjourneys.ui.at", { city: Z(r.node, t) }),
					" · ",
					t("games.timelessjourneys.ui.handSize", { n: r.handSize })
				] }),
				De(r.rid),
				/* @__PURE__ */ h("div", {
					className: "tj-mini-cards",
					"aria-label": t("games.timelessjourneys.ui.played"),
					children: r.played.map((e, n) => e.card ? /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => ye(e.card),
						children: /* @__PURE__ */ h(zt, {
							id: e.card,
							compact: !0
						})
					}, n) : /* @__PURE__ */ h("span", {
						className: "tj-card-back",
						"aria-label": t("games.timelessjourneys.ui.faceDownCard"),
						children: /* @__PURE__ */ h(Q, { kind: "move" })
					}, n))
				}),
				/* @__PURE__ */ h(Ht, {
					p: r,
					showCard: ye,
					showCity: be,
					...H,
					choices: r.rid === e.myRid ? H.choices : []
				})
			]
		}, r.rid))
	}), Ae = /* @__PURE__ */ g("div", {
		className: "tj-sheet",
		children: [
			V === "card" && E && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(zt, { id: E }), /* @__PURE__ */ h("div", {
				className: "tj-choice-list",
				children: c.filter((e) => e.card === E).map(Ee)
			})] }),
			V === "city" && /* @__PURE__ */ h(Wt, {
				city: O,
				pub: r,
				owner: e.myRid,
				onCity: k,
				name: R,
				color: z,
				choices: c,
				choiceButton: Ee
			}),
			V === "traveler" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("div", {
				className: "tj-traveler-detail",
				children: [/* @__PURE__ */ h(kt, { traveler: Te }), /* @__PURE__ */ h("p", { children: t(ft[Te]) })]
			}), /* @__PURE__ */ h("div", {
				className: "tj-choice-list",
				children: c.filter((e) => e.traveler === A).map(Ee)
			})] }),
			V === "players" && ke,
			V === "choices" && /* @__PURE__ */ g(m, { children: [
				r.activeCard && /* @__PURE__ */ h("strong", { children: t("games.timelessjourneys.ui.currentCard", { card: yt(r.activeCard, t) }) }),
				r.task.length > 0 && /* @__PURE__ */ h("p", {
					className: "tj-task",
					children: St(r.task, t)
				}),
				/* @__PURE__ */ h("div", {
					className: "tj-choice-list",
					children: c.filter((e) => M ? M.includes(e.id) : !Kt(e) && e.kind !== "traveler").map(Ee)
				}),
				!M && r.travelers.map((e, n) => {
					let r = c.filter((e) => e.kind === "traveler" && e.traveler === n);
					return r.length > 0 && /* @__PURE__ */ g("details", {
						className: "tj-choice-group",
						children: [
							/* @__PURE__ */ g("summary", { children: [/* @__PURE__ */ h(kt, { traveler: e }), t(dt[e])] }),
							/* @__PURE__ */ h("p", { children: t(ft[e]) }),
							/* @__PURE__ */ h("div", {
								className: "tj-choice-list",
								children: r.map(Ee)
							})
						]
					}, e);
				}),
				!M && c.some(Kt) && /* @__PURE__ */ g("details", {
					className: "tj-choice-group",
					children: [/* @__PURE__ */ h("summary", { children: t("games.timelessjourneys.ui.freeActions") }), /* @__PURE__ */ h("div", {
						className: "tj-choice-list",
						children: c.filter(Kt).map(Ee)
					})]
				})
			] }),
			fe && V === "choices" && /* @__PURE__ */ h("span", {
				className: "tj-sr-only",
				children: fe.experience ? t(pt[fe.experience]) : Ct(fe, r, t)
			})
		]
	}), je = /* @__PURE__ */ g("div", {
		className: "tj-actions",
		children: [
			De(e.myRid),
			/* @__PURE__ */ g("div", {
				className: "tj-hand-caption",
				children: [t("games.timelessjourneys.ui.handProgress", { n: d?.played.length ?? 0 }), r.activeCard && /* @__PURE__ */ h("span", {
					title: yt(r.activeCard, t),
					children: yt(r.activeCard, t)
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: "tj-hand",
				"aria-label": t("games.timelessjourneys.ui.hand"),
				children: [Ce.map((e) => {
					let n = c.some((t) => t.card === e && [
						"activate",
						"play",
						"discard",
						"remove",
						"flip"
					].includes(t.kind));
					return /* @__PURE__ */ g("button", {
						type: "button",
						className: "tj-hand-card",
						onClick: () => ye(e),
						"aria-label": yt(e, t),
						"data-ready": n,
						"data-active": r.activeCard === e,
						children: [/* @__PURE__ */ h(zt, {
							id: e,
							compact: !0
						}), r.activeCard === e && /* @__PURE__ */ h("span", {
							className: "tj-active-card",
							children: /* @__PURE__ */ h(l, { size: 12 })
						})]
					}, e);
				}), !Ce.length && /* @__PURE__ */ h("span", {
					className: "tj-no-cards",
					children: t("games.timelessjourneys.ui.noCards")
				})]
			})
		]
	}), Me = /* @__PURE__ */ g("div", {
		className: "tj-control",
		children: [/* @__PURE__ */ h("button", {
			type: "button",
			className: "tj-secondary",
			onClick: () => me ? _e(me) : Se(),
			disabled: !c.length,
			children: me ? Ct(me, r, t) : t("games.timelessjourneys.ui.viewChoices")
		}), /* @__PURE__ */ h("button", {
			type: "button",
			className: "tj-primary",
			disabled: !c.length,
			onClick: () => pe ? _e(pe) : Se(),
			children: !u && r.active ? t("games.timelessjourneys.ui.waiting", { name: R(r.active) }) : pe ? Ct(pe, r, t) : t("games.timelessjourneys.ui.choose")
		})]
	});
	return /* @__PURE__ */ g("div", {
		className: "tj-screen",
		children: [/* @__PURE__ */ h(ee, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ g("div", {
					className: "tj-banner",
					"data-active": u,
					children: [/* @__PURE__ */ h("span", {
						className: "tj-round",
						children: t("games.timelessjourneys.ui.round", { n: r.round })
					}), /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("strong", { children: r.active ? t(u ? "games.timelessjourneys.ui.yourTurn" : "games.timelessjourneys.ui.turn", { name: R(r.active) }) : t("games.timelessjourneys.ui.resolving") }), /* @__PURE__ */ h("span", {
						title: ue,
						children: ue
					})] })]
				}),
				/* @__PURE__ */ h("div", {
					className: "tj-score-strip",
					children: r.players.map((i) => /* @__PURE__ */ g("button", {
						type: "button",
						className: "tj-seat",
						"data-active": r.active === i.rid,
						style: { "--tj-player": z(i.rid) },
						onClick: () => {
							F(i.rid), x("players");
						},
						children: [
							/* @__PURE__ */ h("span", {
								className: "tj-seat-number",
								children: /* @__PURE__ */ h("img", {
									src: n[(e.members.find((e) => e.rid === i.rid)?.avatar ?? 0) % n.length],
									alt: "",
									draggable: !1,
									style: {
										width: "1.75em",
										height: "1.75em",
										maxWidth: "100%",
										maxHeight: "100%",
										display: "block",
										objectFit: "contain",
										pointerEvents: "none",
										borderRadius: "inherit"
									}
								})
							}),
							/* @__PURE__ */ h("span", {
								className: "tj-seat-name",
								children: R(i.rid)
							}),
							i.rid === r.first && /* @__PURE__ */ h("span", {
								className: "tj-first",
								title: t("games.timelessjourneys.ui.first"),
								children: "⚑"
							}),
							/* @__PURE__ */ g("span", {
								className: "tj-seat-stats",
								children: [/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(Q, { kind: "laurel" }), i.vp] }), /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(Q, { kind: "coin" }), i.coins] })]
							})
						]
					}, i.rid))
				}),
				/* @__PURE__ */ h("nav", {
					className: "tj-tabs",
					"aria-label": t("games.timelessjourneys.ui.map"),
					children: [
						"map",
						"gazette",
						"market",
						"journals",
						"players"
					].map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						"aria-pressed": e === "players" ? V === "players" : I === e,
						onClick: () => e === "players" ? x("players") : L(e),
						children: t(Gt[e])
					}, e))
				})
			] }),
			children: /* @__PURE__ */ g("div", {
				className: "tj-tabletop",
				"data-tab": I,
				children: [
					/* @__PURE__ */ h("div", {
						className: "tj-map-pane tj-pane",
						children: /* @__PURE__ */ h(Bt, {
							avatarOf: (t) => n[(e.members.find((e) => e.rid === t)?.avatar ?? 0) % n.length],
							pub: r,
							name: R,
							color: z,
							showCity: be,
							zoom: N,
							setZoom: ae,
							...H
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "tj-public-column",
						children: [/* @__PURE__ */ h("div", {
							className: "tj-gazette-pane tj-pane",
							"data-related": c.some((e) => e.kind === "traveler"),
							children: /* @__PURE__ */ h(Vt, {
								pub: r,
								name: R,
								color: z,
								owner: e.myRid,
								experience: we,
								onExperience: (e) => {
									oe(e), T("");
								},
								onTraveler: xe,
								...H
							})
						}), /* @__PURE__ */ h("div", {
							className: "tj-market-pane tj-pane",
							"data-related": r.phase === "market" || v === "buy",
							children: /* @__PURE__ */ h(Ut, {
								pub: r,
								showCard: ye,
								...H
							})
						})]
					}),
					/* @__PURE__ */ g("div", {
						className: "tj-personal-column",
						children: [/* @__PURE__ */ g("div", {
							className: "tj-personal-scroll",
							children: [/* @__PURE__ */ h("div", {
								className: "tj-private-pane tj-pane",
								"data-related": v === "write",
								children: /* @__PURE__ */ h("div", {
									className: "tj-scroll tj-ledger",
									children: d && /* @__PURE__ */ h(Ht, {
										p: d,
										showCard: ye,
										showCity: be,
										...H
									})
								})
							}), je]
						}), Me]
					})
				]
			})
		}), a(/* @__PURE__ */ h("div", {
			className: "tj-dialog-scope",
			children: /* @__PURE__ */ h(Yt, {
				open: V !== null,
				onClose: ge,
				title: Oe,
				children: Ae
			})
		}), document.body)]
	});
}
//#endregion
//#region src/games/timelessjourneys/bot.ts
var $ = (e) => e.reduce((e, t) => e + t, 0), Zt = (e) => fe[Math.min(8, $(e.ideas) + Number(e.tile) + Number(e.friend))], Qt = (e, t) => Zt(t) - Zt(e) + (Zt(e) < 4 ? 2 : 0), $t = (e) => pe[Math.min(8, e)];
function en(e, t) {
	return [...t.hand, ...e.played.flatMap((e) => e.card ? [e.card] : [])];
}
function tn(e, t, n) {
	let r = e.map(F), i = (e) => r.filter((t) => t.category === e).length, a = /* @__PURE__ */ new Set();
	n.cafes.forEach((e, n) => {
		e.some((e) => e.includes(t.rid)) && a.add(n);
	});
	let o = (/* @__PURE__ */ new Set([...t.letters.map((e) => e.city), ...a])).size, s = n.cafes.flat(2).filter((e) => e === t.rid).length, c = $(t.journals.map((e) => $(e.ideas)));
	return $(r.map((e) => {
		let n = e.score, a = 0;
		switch (n.kind) {
			case "fixed": return n.n;
			case "travel":
			case "inspiration":
			case "friendship":
			case "festivities":
				a = i(n.kind);
				break;
			case "tiles":
				a = t.tiles.length;
				break;
			case "contacts":
				a = o;
				break;
			case "writtenIdeas":
				a = c;
				break;
			case "cafes":
				a = s;
				break;
			case "reserveIdeas":
				a = $(t.ideas);
				break;
			case "coins":
				a = t.coins;
				break;
			case "level2":
				a = r.filter((e) => e.level === 2).length;
				break;
			case "level3": a = r.filter((e) => e.level === 3).length;
		}
		return Math.min(n.max ?? Infinity, Math.floor(a / (n.per ?? 1)) * n.n);
	}));
}
var nn = [
	0,
	0,
	1.5,
	3.5,
	6
];
function rn(e, t, n) {
	let r = new Set(e.played.filter((e) => !e.faceDown && e.card).map((e) => F(e.card).category));
	r.add(F(n).category);
	let i = new Set(t.hand.filter((e) => e !== n).map((e) => F(e).category));
	return Math.min(4, (/* @__PURE__ */ new Set([...r, ...i])).size);
}
function an(e, t) {
	let n = $(e.journals.map((e) => de[e.id].types.includes(b[t]) ? Math.max(0, 3 - e.ideas[t]) : 0));
	return 1.2 + Math.min(3, Math.max(0, n - e.ideas[t])) * .65 - (e.ideas[t] > 5);
}
function on(e, t, n) {
	switch (e.kind) {
		case "coins": return (e.n ?? 1) * (t.coins < 3 ? 1.2 : .5);
		case "vp": return (e.n ?? 0) * .75;
		case "idea": return (e.n ?? 1) * (e.idea ? an(t, b.indexOf(e.idea)) : Math.max(...b.map((e, n) => an(t, n))));
		case "write": {
			let n = 1;
			for (let e of t.journals) {
				for (let r of de[e.id].types) {
					let i = b.indexOf(r);
					t.ideas[i] && e.ideas[i] < 3 && (n = Math.max(n, Qt(e, {
						...e,
						ideas: e.ideas.map((e, t) => e + +(t === i))
					}) - .9));
				}
				!e.tile && t.tiles.some((t) => t.journal === null && t.city === de[e.id].city) && (n = Math.max(n, Qt(e, {
					...e,
					tile: !0
				}))), !e.friend && t.friends.some((e) => e.journal === null) && (n = Math.max(n, Qt(e, {
					...e,
					friend: !0
				})));
			}
			return (e.n ?? 1) * n;
		}
		case "explore": return t.node < 8 ? t.tiles.some((e) => e.city === t.node) ? 1.5 : 4 : 0;
		case "talk": return t.node < 8 ? 3 * (e.n ?? 1) : 0;
		case "letter": return t.letters.filter((e) => e.city !== t.node).length ? 3 * (e.n ?? 1) : 0;
		case "discuss": {
			let e = 0;
			if (n.cafes.flat(2).filter((e) => e === t.rid).length < 6) for (let r of /* @__PURE__ */ new Set([...t.node < 8 ? [t.node] : [], ...t.letters.map((e) => e.city)])) for (let i = 0; i < 2; i++) {
				let a = n.cafes[r][i].length;
				if (a >= 2) continue;
				let o = B[r].points[a];
				for (let n of B[r].discussions[i]) n.every((e, n) => e <= t.ideas[n]) && (e = Math.max(e, o - $(n) * .8));
			}
			return Math.max(e, .1);
		}
		case "move": return 1.6 * (e.n ?? 1);
		case "buy": return 2;
		case "pay": return -(e.coins ?? 0) * .9 - (e.vp ?? 0) * .75;
		case "or": return -1;
		default: return .5;
	}
}
function sn(e) {
	let t = Math.floor(4294967296 / e) * e, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return n[0] % e;
}
var cn = (e, t) => {
	let n = e.public, r = e.private?.choices ?? [];
	if (n.active !== t.rid || !r.length) return null;
	if (t.difficulty === "weak") return { action: {
		type: "choose",
		id: r[sn(r.length)].id
	} };
	let i = n.players.find((e) => e.rid === t.rid), a = e.private, o = en(i, a), s = (e) => i.played.filter((t) => t.card && F(t.card).category === e).length, c = (e) => he[n.gazette][n.round - 1][e], l = (e) => n.travelers.findIndex((t, n) => c(n) === e), u = (e) => n.experiences[e].some((t, r) => !t && ge[e][r] <= n.players.length), d = (e) => {
		let t = 0;
		if (n.cafes.flat(2).filter((e) => e === i.rid).length >= 6) return 0;
		for (let r = 0; r < 2; r++) {
			let a = n.cafes[e][r].length;
			if (a >= 2) continue;
			let o = B[e].points[a];
			for (let n of B[e].discussions[r]) t = Math.max(t, o - $(n.map((e, t) => Math.max(0, e - i.ideas[t]))) * 1.2);
		}
		return t;
	}, f = Array.from({ length: 8 }, (e, t) => ({
		city: t,
		value: (i.tiles.some((e) => e.city === t) ? 0 : 5) + (i.journals.some((e) => de[e.id].city === t && !e.tile) ? 3 : 0) + (n.friends[t] !== null && i.journals.some((e) => !e.friend) ? 2 : 0) + (he[n.gazette][n.round - 1].includes(t) ? 1.5 : 0) + (l(t) >= 0 && u(l(t)) ? 2.5 : 0) + d(t) * 1.4 - R(i.node)[t] * .7
	})).sort((e, t) => t.value - e.value), p = f.find((e) => e.city !== i.node && !i.tiles.some((t) => t.city === e.city))?.city ?? f[0].city, ee = (e) => $(F(e).effects.flatMap((e) => e.kind === "choice" ? [Math.max(...e.options.map((e) => $(e.map((e) => on(e, i, n)))))] : [on(e, i, n)])), m = (e) => {
		let r = $((e.effects ?? []).map((e) => on(e, i, n)));
		switch (e.kind) {
			case "play": {
				let t = F(e.card);
				return ee(e.card) + (t.level ? .7 : 0) + nn[rn(i, a, e.card)];
			}
			case "faceDown": return (i.coins < 2 ? 1.7 : .2) + nn[Math.min(4, (/* @__PURE__ */ new Set([
				...i.played.filter((e) => e.card).map((e) => e.faceDown ? "faceDown" : F(e.card).category),
				"faceDown",
				...a.hand.map((e) => F(e).category)
			])).size)];
			case "activate": return ee(e.card) + 2;
			case "branch":
			case "effect": return r + 1;
			case "pay": return r - (e.cost ?? 0) * .8 - (e.points ?? 0) * .8;
			case "endTurn": return 0;
			case "endChain":
			case "endEffects":
			case "skip": return -3;
			case "idea": return an(i, b.indexOf(e.idea)) + 2;
			case "writeIdea": {
				let t = i.journals[e.journal], n = b.indexOf(e.idea);
				return Qt(t, {
					...t,
					ideas: t.ideas.map((e, t) => e + +(t === n))
				}) - .9;
			}
			case "writeTile":
			case "writeFriend": {
				let t = i.journals[e.journal];
				return Qt(t, {
					...t,
					[e.kind === "writeTile" ? "tile" : "friend"]: !0
				}) + .5;
			}
			case "explore": return 5 + $t(i.tiles.length + 1) - $t(i.tiles.length);
			case "cityBonus": return r + 1;
			case "takeTile": {
				let e = $t(i.tiles.length + 1) - $t(i.tiles.length);
				return r + 2 + e;
			}
			case "talk": {
				let t = e.city ?? i.node;
				return r + (i.letters.some((e) => e.city === t) ? 0 : 1.5) + (n.friends[t] === e.local && i.journals.some((e) => !e.friend) ? 2.5 : 0);
			}
			case "traveler": {
				let i = n.experiences[e.traveler].some((e) => e?.rid === t.rid && e.kind === "affinity1");
				return 6 + r + (e.experience === "night" ? 1.5 : 0) + (e.experience === "affinity2" && i ? 6 : 0);
			}
			case "letter": return r + 2;
			case "friend": return i.journals.some((e) => !e.friend) ? 5 : 0;
			case "correspond": return i.letters.length < 3 ? 4 : .5;
			case "buy": return (tn([...o, e.card], i, n) - tn(o, i, n)) * .9 + ee(e.card) * .3 - (e.cost ?? 0) * .7;
			case "discuss": return (e.points ?? 0) - $(e.ideas ?? []) * .8;
			case "move": return (R(i.node)[p] - R(e.node)[p]) * 2.5 - (e.cost ?? 0) * .8 + +(e.node < 8 && !i.tiles.some((t) => t.city === e.node));
			case "exchange": return r + (e.cost === 0 ? (e.n ?? 0) - $(e.ideas ?? []) : 1);
			case "teleport": return 3 + (i.tiles.some((t) => t.city === e.city) ? 0 : 2);
			case "useTile": return r + .5;
			case "reactivate": return r + 1;
			case "flip": return +(s(F(e.card).category) > 1);
			case "remove": return 2;
			case "painting": {
				let e = i.paintings.length;
				return me[Math.min(5, e + 1)] - me[Math.min(5, e)] + 1;
			}
			case "admiration": return r - .7;
			case "byron": return i.coins > 4 && !i.tiles.some((t) => t.city === e.city) ? 1.5 : -4;
			case "dickensExplore": return !i.tiles.some((t) => t.city === e.city) && i.coins > 3 ? 2 : -4;
			case "dickensDiscuss": return i.coins > 3 && B[e.city].discussions.some((e) => e.some((e) => e.every((e, t) => e <= i.ideas[t]))) ? 2 : -4;
			case "discard": return -(tn(en(i, a), i, n) - tn(a.hand.filter((t) => t !== e.card), i, n));
			default: return 0;
		}
	};
	return { action: {
		type: "choose",
		id: r.map((e, t) => ({
			choice: e,
			value: m(e),
			i: t
		})).sort((e, t) => t.value - e.value || e.i - t.i)[0].choice.id
	} };
}, ln = (e, t, n) => e.type === "choose" ? Ct(t.private?.choices.find((t) => t.id === e.id) ?? {
	id: "",
	kind: "skip"
}, t.public, n) : "";
//#endregion
//#region src/games/timelessjourneys/game-over-row.tsx
function un({ public: e, rid: t }) {
	let n = s(), r = e.scores[t];
	return r ? /* @__PURE__ */ h("div", {
		className: "mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs",
		children: [
			"journey",
			"exploration",
			"journals",
			"cards",
			"experiences",
			"paintings"
		].map((e) => /* @__PURE__ */ g("span", { children: [
			n(gt[e]),
			": ",
			/* @__PURE__ */ h("b", {
				className: "font-mono tabular-nums",
				children: r[e]
			})
		] }, e))
	}) : null;
}
//#endregion
//#region src/games/timelessjourneys/game-over.tsx
function dn(e) {
	return /* @__PURE__ */ h("div", {
		className: "tj-over",
		children: /* @__PURE__ */ h(_, {
			...e,
			accent: ve.accent,
			renderRowExtra: (t) => /* @__PURE__ */ h(un, {
				public: e.public,
				rid: t,
				myRid: e.myRid
			})
		})
	});
}
//#endregion
//#region src/games/timelessjourneys/options.tsx
var fn = {
	intro: "games.timelessjourneys.options.intro",
	A: "games.timelessjourneys.options.A",
	B: "games.timelessjourneys.options.B",
	C: "games.timelessjourneys.options.C",
	D: "games.timelessjourneys.options.D",
	random: "games.timelessjourneys.options.random",
	custom: "games.timelessjourneys.options.custom"
};
function pn({ value: e, onChange: t }) {
	let n = s(), r = Ce.safeParse(e), i = r.success ? r.data : Ce.parse(void 0), a = (e, n) => {
		let r = [...i.custom], a = r[e], o = r.indexOf(n);
		r[e] = n, o >= 0 && (r[o] = a), t({
			...i,
			custom: r
		});
	};
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ h(te, {
				title: n("games.timelessjourneys.options.mode"),
				children: [
					"intro",
					"A",
					"B",
					"C",
					"D",
					"random",
					"custom"
				].map((e) => /* @__PURE__ */ h(v, {
					name: "tj-mode",
					value: e,
					label: n(fn[e]),
					checked: i.mode === e,
					onChange: () => t({
						...i,
						mode: e
					})
				}, e))
			}),
			i.mode === "custom" && /* @__PURE__ */ g("fieldset", { children: [/* @__PURE__ */ h("legend", { children: n("games.timelessjourneys.options.selectTravelers") }), i.custom.map((e, t) => /* @__PURE__ */ g("label", {
				className: "flex min-h-12 items-center gap-3",
				children: [/* @__PURE__ */ h("span", { children: t + 1 }), /* @__PURE__ */ h("select", {
					className: "min-h-11 flex-1 rounded-lg border px-2",
					value: e,
					onChange: (e) => a(t, e.target.value),
					"aria-label": n("games.timelessjourneys.options.selectTravelers"),
					children: ne.map((e) => /* @__PURE__ */ h("option", {
						value: e,
						children: n(dt[e])
					}, e))
				})]
			}, t))] }),
			/* @__PURE__ */ h(te, {
				title: n("games.timelessjourneys.options.gazette"),
				children: [
					"random",
					"A",
					"B",
					"C",
					"D"
				].map((e) => /* @__PURE__ */ h(v, {
					name: "tj-gazette",
					value: e,
					label: e === "random" ? n("games.timelessjourneys.options.randomGazette") : e,
					checked: i.gazette === e,
					onChange: () => t({
						...i,
						gazette: e
					})
				}, e))
			}),
			/* @__PURE__ */ h(y, {
				label: n("games.timelessjourneys.options.extraMovement"),
				checked: i.extraMovement,
				onChange: () => t({
					...i,
					extraMovement: !i.extraMovement
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/timelessjourneys/entry.tsx
var mn = {
	definition: st,
	View: Xt,
	bot: cn,
	describe: ln,
	OverView: dn,
	RowView: un,
	Options: pn,
	locales: {
		zh: {
			name: "永恒旅途：意大利大游学",
			desc: "串联行动牌，游历意大利，与名人相逢，将见闻写入旅行日志。",
			rules: "目标：\n· 五轮后总分最高者获胜。\n· 同分时，地图位置更靠南者优先。\n准备：\n· 每人从都灵出发，拥有 5 分和两本旅行日志。\n· 每人获得 7 张基础牌，可在选项中移除重复移动牌。\n· 前两位玩家获得 1 枚钱币，其余获得 2 枚。\n· 两人游戏中，第二位玩家获得 2 枚钱币。\n行动阶段：\n· 从首位玩家开始，顺时针轮流打出一张手牌。\n· 每人每轮打出 5 张牌。\n· 正面出牌后，可激活本轮所有同类别的正面牌。\n· 自选牌的激活顺序，完成一张后才能激活下一张。\n· 同一张牌的独立效果可自选执行顺序。\n· 每项效果和每张牌均可放弃，斜线效果选择一项。\n· 背面出牌可获得 2 枚钱币、移动一次或购买一张牌。\n· 背面牌不触发连锁，市场阶段额外算一种类别。\n游历与记录：\n· 每次移动到相邻地点，支付道路上标明的钱币。\n· 探索时，秘密查看当地板块并选取一块。\n· 每人在每座城市最多收集一块，也可改取城市奖励。\n· 自己回合随时可使用探索板块一次。\n· 交谈可选择当地人，或与当地著名旅行者互动。\n· 与当地人交谈，先获得好感奖励，再选择通信或朋友。\n· 每人最多有 3 处通信，每城只能有自己的一个信件标记。\n· 寄信须寄给自己建立通信且不在当前位置城市的当地人。\n· 写日志时，将一个思想、对应城市板块或朋友填入空槽。\n· 探索板块使用前后均可写入日志。\n· 在本人或信件标记所在城市，可支付思想参与咖啡讨论。\n· 每场讨论有两个名额，先到者获得较高分数。\n· 与旅行者互动时，放置一个体验标记并获得所在格奖励。\n· 决斗令格子奖励执行两次，同列不能再有自己的其他体验。\n· 铭记之夜在多数比较中算两个标记。\n· 心驰神往每轮末可支付 1 分，再次获得原格奖励。\n· 两个志趣相投标记各获得 2 分，同列合计获得 6 分。\n轮末：\n· 依次结算旅行者能力与心驰神往奖励。\n· 从首位玩家右侧开始，逆时针各可免费领取一张牌。\n· 本轮 2、3、4 类牌分别允许领取 I、II、III 级牌。\n· 购买费用为 I 级 0 枚、II 级 2 枚、III 级 5 枚钱币。\n· 展示区领取后不补充，牌堆顶牌始终公开且可领取。\n· 收回本轮出牌，将手牌永久弃至最多 8 张。\n· 最后一轮同样先收回手牌并检查上限，再进行计分。\n· 其余轮次更新市场、移动旅行者，并传递首位玩家。\n终局计分：\n· 加上探索城市数、两本日志、手牌进阶牌和绘画的分数。\n· 每列体验多数前三名获得 5、3、1 分。\n· 两人游戏中只奖励第一名 5 分。\n· 多数相同时，标记在该列更高者优先。\n· 歌德、济慈的轮末奖励适用于所有玩家。\n· 官方单人模式 The Automatons 不包含在本版本中。",
			invalidAction: "当前不能执行这项操作，请重新选择。",
			zoomIn: "放大地图",
			zoomOut: "缩小地图",
			gazetteTitle: "旅行者报",
			westSea: "第勒尼安海",
			eastSea: "亚得里亚海",
			phase: {
				play: "请选择一张手牌",
				chain: "选择下一张要激活的牌",
				finish: "本回合行动完成",
				travelers: "旅行者奖励",
				market: "免费领取一张进阶牌",
				discard: "将手牌弃至 8 张",
				roundEnd: "准备下一轮",
				done: "旅程结束"
			},
			ui: {
				scoreUnit: "分",
				letterRelocate: "可迁移通信",
				selectCity: "查看城市",
				explorationLeft: "剩余 {{n}} 块",
				explorationCollected: "已收集该城探索",
				explorationUncollected: "尚未收集该城探索",
				cityReward: "城市奖励：{{reward}}",
				cityLetters: "全城通信：{{used}}／{{max}}",
				localLetters: "通信位置：{{used}}／{{max}}",
				friendAvailable: "可收集朋友板块",
				friendCollectedBy: "{{name}}已收集朋友板块",
				cityLettersFull: "全城已满",
				letterVacancy: "通信空位",
				baseIdeas: "基础需求：",
				baseVp: "基础分",
				occupiedCafe: "{{name}}已占用，基础 {{n}} 分",
				travelGroup: "{{n}} 人同行",
				experiences: "旅行体验",
				local: "当地人 {{n}}",
				selectDestination: "选择移动目的地",
				selectJournal: "选择要填写的日志槽位",
				handProgress: "本轮出牌 · {{n}}／5",
				faceDownCard: "背面出牌",
				round: "第 {{n}}／5 轮",
				turn: "{{name}}的回合",
				waiting: "等待{{name}}选择",
				resolving: "正在结算",
				hand: "手牌",
				map: "意大利",
				gazette: "旅行者报",
				market: "市场",
				journals: "日志",
				players: "旅伴",
				city: "城市详情",
				decisions: "当前选择",
				choose: "继续选择",
				close: "关闭",
				freeActions: "额外行动",
				played: "本轮出牌",
				reserve: "个人物品",
				coins: "钱币",
				vp: "分数",
				ideas: "思想",
				letters: "通信",
				friends: "朋友",
				tiles: "探索",
				paintings: "绘画",
				first: "首位玩家",
				deck: "牌堆顶",
				level: "{{n}} 级",
				price: "购买：{{n}} 枚钱币",
				threshold: "免费领取：至少 {{n}} 类",
				empty: "暂无",
				used: "已使用",
				unused: "可使用",
				journal: "日志 {{n}}",
				handSize: "{{n}} 张牌",
				yourTurn: "轮到你了",
				selectCard: "查看牌面并选择出牌方式",
				cardDetail: "牌面",
				reward: "奖励",
				collected: "已收集",
				discussion: "讨论 {{n}}",
				spots: "剩余 {{n}} 个名额",
				node: "乡间 {{n}}",
				moveCost: "路费 {{n}}",
				at: "位于{{city}}",
				letterFrom: "迁移{{city}}的信件标记",
				chooseTile: "秘密选择一块探索板块",
				journalProgress: "已完成 {{n}}／8 项",
				endPoints: "终局分数",
				own: "自己",
				cardName: "{{level}} · {{category}} {{n}}",
				allPlayers: "所有玩家",
				journalTile: "对应城市探索",
				journalFriend: "任意城市朋友",
				scrollMap: "地图可滚动查看",
				score: "{{n}} 分",
				cost: "支付 {{n}} 枚钱币",
				payIdeas: "支付：{{ideas}}",
				paintType: "绘画 {{n}}",
				noCards: "没有可用的牌",
				viewChoices: "查看选择",
				scores: "得分明细",
				currentCard: "正在激活：{{card}}"
			},
			cities: {
				torino: "都灵",
				venezia: "威尼斯",
				bologna: "博洛尼亚",
				firenze: "佛罗伦萨",
				perugia: "佩鲁贾",
				roma: "罗马",
				napoli: "那不勒斯",
				palermo: "巴勒莫"
			},
			ideas: {
				science: "科学",
				history: "历史",
				art: "艺术",
				philosophy: "哲学",
				any: "任选"
			},
			categories: {
				travel: "旅行",
				inspiration: "灵感",
				friendship: "友谊",
				festivities: "庆典"
			},
			basic: {
				move1: "移动",
				move2: "移动",
				explore: "探索",
				talk: "交谈",
				letter: "寄信",
				journal: "写作与讨论",
				science: "科学灵感",
				history: "历史灵感",
				art: "艺术灵感",
				philosophy: "哲学灵感",
				money: "旅费"
			},
			travelerNames: {
				montesquieu: "孟德斯鸠",
				montagu: "玛丽·蒙塔古",
				addison: "约瑟夫·艾迪生",
				craven: "克雷文夫人",
				goethe: "歌德",
				lebrun: "维热·勒布伦",
				keats: "约翰·济慈",
				byron: "拜伦勋爵",
				shelley: "玛丽·雪莱",
				dickens: "查尔斯·狄更斯",
				twain: "马克·吐温",
				blessington: "布莱辛顿夫人"
			},
			travelerRules: {
				montesquieu: "在其城市参与咖啡讨论，额外获得 4 分。",
				montagu: "轮末与其同城，获得两个任选思想或 3 分。",
				addison: "探索其城市、在其城市交谈或向该城寄信，每次额外获得 1 分。",
				craven: "其城市的咖啡讨论少支付一个思想。",
				goethe: "每轮末，所有玩家每枚持有的钱币获得 1 分，最多 7 分。",
				lebrun: "探索其城市时，可额外收集一幅未拥有的绘画。1 至 5 幅不同绘画分别得 1、3、7、13、20 分。",
				keats: "在其城市打出进阶牌时获得 2 分；轮末所有玩家每张本轮打出的进阶牌获得 1 分。正面和背面出牌均计入。",
				byron: "自己回合开始时，可支付 3 枚钱币直接前往其城市。",
				shelley: "轮末与其同城，日志中每个思想获得 1 分。",
				dickens: "每回合可额外支付 2 枚钱币，在其城市探索或讨论一次。",
				twain: "本人位于其城市时，每获得一个思想，额外获得 2 分。",
				blessington: "轮末，按道路步数计算，最近的玩家获得 3 分，最远的玩家失去 2 分；不可与其决斗。"
			},
			experiences: {
				duel: "荣誉决斗",
				night: "铭记之夜",
				admiration: "心驰神往",
				affinity1: "志趣相投 I",
				affinity2: "志趣相投 II"
			},
			experienceRules: {
				duel: "立即获得两次格子奖励，同列不能放置自己的其他体验。",
				night: "终局比较多数时，此标记算两个。",
				admiration: "每轮末可支付 1 分，再次获得所在格奖励。",
				affinity1: "终局获得 2 分；两个志趣相投同列时，合计获得 6 分。",
				affinity2: "终局获得 2 分；两个志趣相投同列时，合计获得 6 分。"
			},
			effect: {
				cardEffects: "选择下一项效果",
				coins: "获得 {{n}} 枚钱币",
				vp: "获得 {{n}} 分",
				idea: "获得 {{n}} 个{{idea}}思想",
				move: "移动 {{n}} 次",
				discountMove: "移动 {{n}} 次，首笔路费减免 {{discount}} 枚",
				explore: "探索 {{n}} 次",
				talk: "交谈 {{n}} 次",
				letter: "寄信 {{n}} 次",
				differentLetters: "向不同当地人寄信 {{n}} 次",
				anyLetter: "向尚未建立通信的任意当地人寄信",
				write: "填写 {{n}} 个日志槽位",
				differentJournals: "填写 {{n}} 本不同日志",
				discuss: "参与咖啡讨论",
				anyDiscuss: "在任意城市参与咖啡讨论",
				buy: "购买一张进阶牌",
				discountBuy: "购买一张进阶牌，减免 {{n}} 枚钱币",
				immediateBuy: "购买一张进阶牌，并立即执行其效果",
				exchange: "交还 {{n}} 个思想，获得 {{n}} 个任选思想",
				exchangeOrCoins: "交还 {{n}} 个思想，获得 {{n}} 个任选思想或 {{coins}} 枚钱币",
				payCoins: "支付 {{n}} 枚钱币",
				payVp: "支付 {{n}} 分",
				teleport: "直接前往{{cities}}",
				reactivate: "再次使用一块已使用的探索板块",
				flipMove: "将本轮一张正面牌翻为背面，然后移动两次",
				removeI: "永久弃置手牌中的一张 I 级牌，获得 2 枚钱币和 3 分；弃后手牌至少 5 张",
				localBonus: "获得当地人的好感奖励",
				localLink: "选择朋友或建立通信",
				takeTile: "选择探索板块",
				painting: "选择一幅绘画",
				admiration: "选择是否再次获得体验奖励",
				differentIdeas: "获得 {{n}} 个不同种类的思想",
				or: "或"
			},
			choice: {
				effect: "执行：{{effects}}",
				endEffects: "放弃本牌剩余效果",
				play: "正面打出{{card}}",
				faceDown: "背面打出{{card}}",
				activate: "激活{{card}}",
				endTurn: "结束回合",
				endChain: "放弃剩余牌的激活",
				skip: "放弃本项效果",
				branch: "选择：{{effects}}",
				pay: "{{cost}}：{{effects}}",
				move: "前往{{place}}",
				explore: "查看{{city}}的探索板块",
				cityBonus: "获得{{city}}的城市奖励",
				takeTile: "收集：{{effects}}",
				idea: "获得{{idea}}思想",
				writeIdea: "将{{idea}}思想写入日志 {{n}}",
				writeTile: "将{{city}}探索写入日志 {{n}}",
				writeFriend: "将{{city}}的朋友写入日志 {{n}}",
				talk: "与{{city}}的当地人 {{n}} 交谈",
				traveler: "与{{traveler}}建立{{experience}}",
				letter: "向{{city}}的当地人 {{n}} 寄信",
				friend: "收集当地人的朋友板块",
				correspond: "与当地人建立通信",
				buy: "领取{{card}}",
				discuss: "在{{city}}参与讨论 {{n}}",
				exchange: "交还{{ideas}}，获得 {{n}} 个任选思想",
				exchangeCoins: "交还{{ideas}}，获得 {{n}} 枚钱币",
				teleport: "直接前往{{city}}",
				reactivate: "再次使用{{city}}的探索板块",
				flip: "将{{card}}翻为背面",
				remove: "永久弃置{{card}}",
				painting: "收集绘画 {{n}}",
				admiration: "支付 1 分，再次获得体验奖励",
				byron: "支付 3 枚钱币，前往拜伦所在城市",
				dickensExplore: "支付 2 枚钱币，在狄更斯所在城市探索",
				dickensDiscuss: "支付 2 枚钱币，在狄更斯所在城市讨论",
				useTile: "使用{{city}}的探索板块",
				discard: "永久弃置{{card}}"
			},
			scoring: {
				fixed: "终局获得 {{n}} 分",
				travel: "每两张旅行牌获得 {{n}} 分",
				inspiration: "每两张灵感牌获得 {{n}} 分",
				friendship: "每两张友谊牌获得 {{n}} 分",
				festivities: "每两张庆典牌获得 {{n}} 分",
				tiles: "每块探索板块获得 {{n}} 分",
				contacts: "每座有咖啡标记或信件标记的城市获得 {{n}} 分",
				writtenIdeas: "日志中每三个思想获得 {{n}} 分",
				cafes: "每个咖啡标记获得 {{n}} 分，最多 8 分",
				reserveIdeas: "每个尚未写入日志的思想获得 {{n}} 分，最多 8 分",
				coins: "每枚持有的钱币获得 {{n}} 分，最多 8 分",
				level2: "每两张 II 级牌获得 {{n}} 分",
				level3: "每两张 III 级牌获得 {{n}} 分"
			},
			scoreRows: {
				journey: "旅程得分",
				exploration: "探索城市",
				journals: "旅行日志",
				cards: "进阶手牌",
				experiences: "体验与多数",
				paintings: "绘画收藏",
				total: "总分"
			},
			options: {
				mode: "旅行者组合",
				intro: "初次旅程",
				A: "18 世纪早期",
				B: "18 世纪晚期",
				C: "19 世纪早期",
				D: "19 世纪晚期",
				random: "跨时空相逢",
				custom: "自选旅行者",
				gazette: "旅行者报",
				randomGazette: "随机报面",
				extraMovement: "加入第二张基础移动牌",
				selectTravelers: "选择三位不同旅行者"
			}
		},
		en: {
			name: "Timeless Journeys: The Italian Grand Tour",
			desc: "Chain action cards, travel across Italy, meet famous travelers, and fill your journals.",
			rules: "Objective:\n· The highest score after five rounds wins.\n· Ties favor the southernmost map position.\nSetup:\n· Start in Torino with 5 VP and two journals.\n· Take 7 basic cards. The option to remove the duplicate Movement card may be enabled during setup.\n· The first two players each receive 1 coin. Each later player receives 2 coins.\n· In a two-player game, the second player receives 2 coins.\nAction phase:\n· Take clockwise turns playing one hand card.\n· Each player plays 5 cards per round.\n· After playing a card face up, you may activate every face-up card of that category that you have played this round.\n· Choose the order in which to activate your cards. Fully resolve one card before activating the next.\n· Choose the order of independent effects on a card.\n· You may skip any effect or card. When a slash separates effects, choose one of them.\n· Playing a card face down lets you gain 2 coins, move once, or buy a card.\n· A card played face down does not activate a chain, but counts as an additional category during the market phase.\nTravel and records:\n· Move to an adjacent location and pay its toll.\n· When exploring, secretly inspect the tiles at your location and choose one.\n· You may collect at most one tile from each city, or take its city bonus instead.\n· You may use an exploration tile once, at any time during your turn.\n· Converse with a local or famous traveler.\n· When conversing with a local, first gain their favor reward, then choose to establish correspondence or gain a Friend.\n· You may maintain correspondence with up to 3 locals, with at most one of your Letter markers in each city.\n· Send Letters only to locals with whom you have established correspondence, in cities other than your current location.\n· When writing in a journal, fill an empty slot with an Idea, a matching city tile, or a Friend.\n· You may place an exploration tile in a journal either before or after using it.\n· Pay Ideas to join a discussion in a city containing your pawn or one of your Letter markers.\n· Each discussion has two spaces. The first player to join scores more points.\n· When interacting with a traveler, place an Experience token and gain the reward shown on that space.\n· A Duel resolves the space’s reward twice. You cannot have another of your Experience tokens in the same column.\n· A Night to Remember counts as two tokens when comparing majorities in its column.\n· At the end of each round, Admiration lets you pay 1 VP to gain its space’s reward again.\n· Each of your two Affinity tokens scores 2 VP. If both are in the same column, they score 6 VP in total.\nRound end:\n· Resolve traveler abilities, then Admiration.\n· Beginning with the player to the first player’s right and proceeding counterclockwise, each player may take one card for free.\n· Having played 2, 3 or 4 card categories this round allows you to take a level I, II or III card respectively.\n· Level I, II and III cards cost 0, 2 and 5 coins respectively.\n· Do not refill display spaces when cards are taken. The top card of each deck remains face up and available to take.\n· Return the cards you played this round to your hand, then permanently discard cards until you have at most 8.\n· In the final round, also recover your cards and check your hand limit before scoring.\n· In other rounds, refresh the market, move the travelers, and pass the first-player marker.\nFinal scoring:\n· Add the points for the cities you explored, your two journals, advanced cards in your hand, and paintings.\n· The players with the most, second-most and third-most Experience tokens in each column score 5, 3 and 1 VP respectively.\n· With two players only first place scores 5 VP.\n· When players tie for a majority, the player whose token is higher in that column wins the tie.\n· Goethe and Keats grant their end-of-round rewards to all players.\n· The Automatons solo rules are not included.",
			invalidAction: "That action is no longer available. Please choose again.",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			gazetteTitle: "La Gazzetta del Viaggiatore",
			westSea: "TYRRHENIAN SEA",
			eastSea: "ADRIATIC SEA",
			phase: {
				play: "Choose a card to play",
				chain: "Choose the next card to activate",
				finish: "Your actions are complete",
				travelers: "Traveler rewards",
				market: "Take one free advanced card",
				discard: "Discard down to 8 cards",
				roundEnd: "Preparing the next round",
				done: "Journey complete"
			},
			ui: {
				scoreUnit: "VP",
				letterRelocate: "Move your letter here",
				selectCity: "View city",
				explorationLeft: "{{n}} tiles left",
				explorationCollected: "City tile collected",
				explorationUncollected: "City tile not collected",
				cityReward: "City bonus: {{reward}}",
				cityLetters: "City letters: {{used}} / {{max}}",
				localLetters: "Letter slots: {{used}} / {{max}}",
				friendAvailable: "Friend tile available",
				friendCollectedBy: "{{name}} took this Friend tile",
				cityLettersFull: "City is full",
				letterVacancy: "Letter slot",
				baseIdeas: "Base cost:",
				baseVp: "Base VP",
				occupiedCafe: "Occupied by {{name}}; {{n}} base VP",
				travelGroup: "{{n}} travelers together",
				experiences: "Travel experiences",
				local: "Local {{n}}",
				selectDestination: "Choose your destination",
				selectJournal: "Choose a journal slot to fill",
				handProgress: "Played this round · {{n}} / 5",
				faceDownCard: "Face-down card",
				round: "Round {{n}} / 5",
				turn: "{{name}}’s turn",
				waiting: "Waiting for {{name}}",
				resolving: "Resolving",
				hand: "Hand",
				map: "Italy",
				gazette: "Gazette",
				market: "Market",
				journals: "Journals",
				players: "Travelers",
				city: "City details",
				decisions: "Your choice",
				choose: "Continue",
				close: "Close",
				freeActions: "Extra actions",
				played: "Played this round",
				reserve: "Your collection",
				coins: "Coins",
				vp: "VP",
				ideas: "Ideas",
				letters: "Links",
				friends: "Friends",
				tiles: "Exploration",
				paintings: "Paintings",
				first: "First player",
				deck: "Deck top",
				level: "Level {{n}}",
				price: "Buy: {{n}} coins",
				threshold: "Free: at least {{n}} categories",
				empty: "None",
				used: "Used",
				unused: "Ready",
				journal: "Journal {{n}}",
				handSize: "{{n}} cards",
				yourTurn: "Your turn",
				selectCard: "View a card and choose how to play it",
				cardDetail: "Card",
				reward: "Reward",
				collected: "Collected",
				discussion: "Discussion {{n}}",
				spots: "{{n}} seats left",
				node: "Countryside {{n}}",
				moveCost: "Toll {{n}}",
				at: "In {{city}}",
				letterFrom: "Move your Letter marker from {{city}}",
				chooseTile: "Privately choose an Exploration tile",
				journalProgress: "{{n}} / 8 slots filled",
				endPoints: "Final VP",
				own: "You",
				cardName: "{{level}} · {{category}} {{n}}",
				allPlayers: "All players",
				journalTile: "Matching city exploration",
				journalFriend: "Friend from any city",
				scrollMap: "Scroll to explore the map",
				score: "{{n}} VP",
				cost: "Pay {{n}} coins",
				payIdeas: "Pay: {{ideas}}",
				paintType: "Painting {{n}}",
				noCards: "No cards available",
				viewChoices: "View choices",
				scores: "Score breakdown",
				currentCard: "Activating: {{card}}"
			},
			cities: {
				torino: "Torino",
				venezia: "Venezia",
				bologna: "Bologna",
				firenze: "Firenze",
				perugia: "Perugia",
				roma: "Roma",
				napoli: "Napoli",
				palermo: "Palermo"
			},
			ideas: {
				science: "Science",
				history: "History",
				art: "Art",
				philosophy: "Philosophy",
				any: "any"
			},
			categories: {
				travel: "Travel",
				inspiration: "Inspiration",
				friendship: "Friendship",
				festivities: "Festivities"
			},
			basic: {
				move1: "Movement",
				move2: "Movement",
				explore: "Exploration",
				talk: "Conversation",
				letter: "Letter",
				journal: "Write or discuss",
				science: "Scientific inspiration",
				history: "Historical inspiration",
				art: "Artistic inspiration",
				philosophy: "Philosophical inspiration",
				money: "Travel funds"
			},
			travelerNames: {
				montesquieu: "Montesquieu",
				montagu: "Lady Montagu",
				addison: "Joseph Addison",
				craven: "Lady Craven",
				goethe: "Goethe",
				lebrun: "Vigée Le Brun",
				keats: "John Keats",
				byron: "Lord Byron",
				shelley: "Mary Shelley",
				dickens: "Charles Dickens",
				twain: "Mark Twain",
				blessington: "Lady Blessington"
			},
			travelerRules: {
				montesquieu: "Discuss in his city to gain 4 extra VP.",
				montagu: "End of round, in her city: gain any two Ideas or 3 VP.",
				addison: "Gain 1 extra VP whenever you Explore, Converse in, or send a Letter to his city.",
				craven: "Café discussions in her city cost one fewer Idea.",
				goethe: "End of round: every player scores 1 VP per coin, up to 7 VP.",
				lebrun: "When exploring her city, collect one new Painting. 1–5 different Paintings score 1, 3, 7, 13, or 20 VP.",
				keats: "Gain 2 VP for playing an advanced card in his city. At round end every player scores 1 VP per advanced card played. Face-up and face-down plays both count.",
				byron: "At the start of your turn, pay 3 coins to travel directly to his city.",
				shelley: "End of round, in her city: score 1 VP per journaled Idea.",
				dickens: "Once per turn, pay 2 coins for an extra Explore or Discuss action in his city.",
				twain: "While in his city, gain 2 extra VP for each Idea you receive.",
				blessington: "At round end, the closest players gain 3 VP and the farthest lose 2 VP, by road distance. She cannot be dueled."
			},
			experiences: {
				duel: "Duel of Honor",
				night: "A Night to Remember",
				admiration: "Lost in Admiration",
				affinity1: "Elective Affinities I",
				affinity2: "Elective Affinities II"
			},
			experienceRules: {
				duel: "Take the slot reward twice. No other own token may share this column.",
				night: "Counts as two tokens for final majorities.",
				admiration: "At each round end, you may pay 1 VP to repeat this slot reward.",
				affinity1: "Score 2 VP; both Affinities in one column score 6 VP total.",
				affinity2: "Score 2 VP; both Affinities in one column score 6 VP total."
			},
			effect: {
				cardEffects: "Choose the next effect",
				coins: "Gain {{n}} coins",
				vp: "Gain {{n}} VP",
				idea: "Gain {{n}} {{idea}} Ideas",
				move: "Move {{n}} times",
				discountMove: "Move {{n}} times; discount the toll by {{discount}}",
				explore: "Explore {{n}} times",
				talk: "Converse {{n}} times",
				letter: "Send {{n}} letters",
				differentLetters: "Send {{n}} letters to different locals",
				anyLetter: "Send a letter to any unlinked local",
				write: "Fill {{n}} journal slots",
				differentJournals: "Write in {{n}} different journals",
				discuss: "Discuss in a café",
				anyDiscuss: "Discuss in any city",
				buy: "Buy an advanced card",
				discountBuy: "Buy an advanced card with {{n}} coins off",
				immediateBuy: "Buy an advanced card and immediately use its effects",
				exchange: "Return {{n}} Ideas for {{n}} Ideas of your choice",
				exchangeOrCoins: "Return {{n}} Ideas for {{n}} Ideas of your choice or {{coins}} coins",
				payCoins: "Pay {{n}} coins",
				payVp: "Pay {{n}} VP",
				teleport: "Travel directly to {{cities}}",
				reactivate: "Reuse a spent Exploration tile",
				flipMove: "Turn a played face-up card face-down, then move twice",
				removeI: "Remove a level I hand card for 2 coins and 3 VP; keep at least 5 hand cards",
				localBonus: "Take the local’s Favor reward",
				localLink: "Choose a Friend or establish correspondence",
				takeTile: "Choose an Exploration tile",
				painting: "Choose a Painting",
				admiration: "Choose whether to repeat the Experience reward",
				differentIdeas: "Gain {{n}} different Ideas",
				or: "or"
			},
			choice: {
				effect: "Resolve: {{effects}}",
				endEffects: "Skip the rest of this card",
				play: "Play {{card}} face up",
				faceDown: "Play {{card}} face down",
				activate: "Activate {{card}}",
				endTurn: "End turn",
				endChain: "Skip remaining cards",
				skip: "Skip this effect",
				branch: "Choose: {{effects}}",
				pay: "{{cost}}: {{effects}}",
				move: "Travel to {{place}}",
				explore: "Inspect {{city}} Exploration tiles",
				cityBonus: "Take the {{city}} bonus",
				takeTile: "Collect: {{effects}}",
				idea: "Gain a {{idea}} Idea",
				writeIdea: "Write {{idea}} in journal {{n}}",
				writeTile: "Journal {{city}} exploration in journal {{n}}",
				writeFriend: "Journal your {{city}} Friend in journal {{n}}",
				talk: "Talk to local {{n}} in {{city}}",
				traveler: "{{experience}} with {{traveler}}",
				letter: "Write to local {{n}} in {{city}}",
				friend: "Take this local’s Friend tile",
				correspond: "Establish correspondence",
				buy: "Take {{card}}",
				discuss: "Discussion {{n}} in {{city}}",
				exchange: "Return {{ideas}} for {{n}} Ideas of your choice",
				exchangeCoins: "Return {{ideas}} for {{n}} coins",
				teleport: "Travel directly to {{city}}",
				reactivate: "Reuse your {{city}} Exploration tile",
				flip: "Turn {{card}} face-down",
				remove: "Permanently remove {{card}}",
				painting: "Collect Painting {{n}}",
				admiration: "Pay 1 VP to repeat the Experience reward",
				byron: "Pay 3 coins to travel to Byron",
				dickensExplore: "Pay 2 coins to Explore in Dickens’s city",
				dickensDiscuss: "Pay 2 coins to Discuss in Dickens’s city",
				useTile: "Use your {{city}} Exploration tile",
				discard: "Permanently discard {{card}}"
			},
			scoring: {
				fixed: "Score {{n}} final VP",
				travel: "Score {{n}} VP per 2 Travel cards",
				inspiration: "Score {{n}} VP per 2 Inspiration cards",
				friendship: "Score {{n}} VP per 2 Friendship cards",
				festivities: "Score {{n}} VP per 2 Festivity cards",
				tiles: "Score {{n}} VP per Exploration tile",
				contacts: "Score {{n}} VP per city with your Café or Letter marker",
				writtenIdeas: "Score {{n}} VP per 3 journaled Ideas",
				cafes: "Score {{n}} VP per Café marker, up to 8 VP",
				reserveIdeas: "Score {{n}} VP per unjournaled Idea, up to 8 VP",
				coins: "Score {{n}} VP per coin, up to 8 VP",
				level2: "Score {{n}} VP per 2 level II cards",
				level3: "Score {{n}} VP per 2 level III cards"
			},
			scoreRows: {
				journey: "Journey VP",
				exploration: "Exploration",
				journals: "Journals",
				cards: "Advanced cards",
				experiences: "Experiences",
				paintings: "Paintings",
				total: "Total"
			},
			options: {
				mode: "Traveler selection",
				intro: "First journey",
				A: "Early 18th century",
				B: "Late 18th century",
				C: "Early 19th century",
				D: "Late 19th century",
				random: "Timeless Jam",
				custom: "Expert Journey",
				gazette: "Traveler’s Gazette",
				randomGazette: "Random side",
				extraMovement: "Include the extra basic Movement card",
				selectTravelers: "Choose three different travelers"
			}
		}
	}
};
//#endregion
export { mn as default };
