import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { createPortal as a } from "react-dom";
import { useT as o } from "@bgparty/sdk/i18n";
import { AVATARS as s } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { BottomSheet as l } from "@bgparty/sdk/bottom-sheet";
import { DeltaNumber as u } from "@bgparty/sdk/fx/delta-number";
import { useFxAnchor as d } from "@bgparty/sdk/fx/anchors";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as te } from "@bgparty/sdk/fx/primitives";
import { OptionSection as ne, OptionSwitch as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/tokyobay/data.ts
var v = [
	"smash",
	"heal",
	"energy",
	"special",
	"fame",
	"destruction"
], y = [
	"H.A.D.E.S.",
	"Gigarex",
	"Pagura",
	"Iron Back",
	"Kraken",
	"Cyber Bunny"
], b = [
	13,
	13,
	14,
	13,
	15,
	13
], x = [
	{
		id: 0,
		cost: 4,
		type: "discard",
		fish: [
			0,
			1,
			0,
			1,
			0
		]
	},
	{
		id: 1,
		cost: 4,
		type: "discard",
		fish: [
			1,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 2,
		cost: 5,
		type: "discard",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 3,
		cost: 2,
		type: "discard",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 4,
		cost: 4,
		type: "discard",
		fish: [
			0,
			0,
			0,
			0,
			1
		]
	},
	{
		id: 5,
		cost: 3,
		type: "discard",
		fish: [
			0,
			0,
			0,
			0,
			1
		]
	},
	{
		id: 6,
		cost: 4,
		type: "keep",
		fish: [
			1,
			1,
			0,
			0,
			0
		]
	},
	{
		id: 7,
		cost: 4,
		type: "reactive",
		fish: [
			2,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 8,
		cost: 5,
		type: "keep",
		fish: [
			0,
			0,
			1,
			0,
			0
		]
	},
	{
		id: 9,
		cost: 3,
		type: "reactive",
		fish: [
			0,
			0,
			1,
			0,
			0
		]
	},
	{
		id: 10,
		cost: 2,
		type: "keep",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 11,
		cost: 9,
		type: "keep",
		fish: [
			0,
			1,
			1,
			0,
			0
		]
	},
	{
		id: 12,
		cost: 4,
		type: "keep",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 13,
		cost: 6,
		type: "keep",
		fish: [
			1,
			0,
			1,
			0,
			0
		]
	},
	{
		id: 14,
		cost: 3,
		type: "keep",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 15,
		cost: 4,
		type: "reactive",
		fish: [
			0,
			0,
			1,
			0,
			1
		]
	},
	{
		id: 16,
		cost: 4,
		type: "keep",
		fish: [
			1,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 17,
		cost: 7,
		type: "discard",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 18,
		cost: 5,
		type: "keep",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 19,
		cost: 4,
		type: "keep",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 20,
		cost: 7,
		type: "keep",
		fish: [
			1,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 21,
		cost: 7,
		type: "reactive",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 22,
		cost: 5,
		type: "keep",
		fish: [
			0,
			1,
			0,
			0,
			0
		]
	},
	{
		id: 23,
		cost: 5,
		type: "keep",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 24,
		cost: 2,
		type: "keep",
		fish: [
			0,
			5,
			0,
			0,
			0
		]
	},
	{
		id: 25,
		cost: 4,
		type: "keep",
		fish: [
			0,
			0,
			2,
			0,
			0
		]
	},
	{
		id: 26,
		cost: 5,
		type: "keep",
		fish: [
			1,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 27,
		cost: 4,
		type: "keep",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 28,
		cost: 5,
		type: "keep",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 29,
		cost: 7,
		type: "keep",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 30,
		cost: 3,
		type: "reactive",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 31,
		cost: 3,
		type: "reactive",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 32,
		cost: 5,
		type: "reactive",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 33,
		cost: 6,
		type: "keep",
		fish: [
			1,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 34,
		cost: 5,
		type: "reactive",
		fish: [
			0,
			1,
			0,
			0,
			0
		]
	},
	{
		id: 35,
		cost: 3,
		type: "reactive",
		fish: [
			0,
			0,
			1,
			0,
			0
		]
	},
	{
		id: 36,
		cost: 3,
		type: "keep",
		fish: [
			0,
			0,
			3,
			0,
			0
		]
	},
	{
		id: 37,
		cost: 3,
		type: "keep",
		fish: [
			3,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 38,
		cost: 4,
		type: "reactive",
		fish: [
			1,
			0,
			0,
			0,
			1
		]
	},
	{
		id: 39,
		cost: 3,
		type: "keep",
		fish: [
			0,
			0,
			0,
			1,
			1
		]
	},
	{
		id: 40,
		cost: 3,
		type: "discard",
		fish: [
			0,
			0,
			0,
			0,
			1
		]
	},
	{
		id: 41,
		cost: 3,
		type: "discard",
		fish: [
			1,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 42,
		cost: 5,
		type: "discard",
		fish: [
			0,
			0,
			0,
			1,
			0
		]
	},
	{
		id: 43,
		cost: -1,
		type: "discard",
		fish: [
			1,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 44,
		cost: 3,
		type: "discard",
		fish: [
			1,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 45,
		cost: 3,
		type: "discard",
		fish: [
			0,
			0,
			1,
			0,
			0
		]
	},
	{
		id: 46,
		cost: -2,
		type: "discard",
		fish: [
			0,
			0,
			2,
			0,
			0
		]
	},
	{
		id: 47,
		cost: 3,
		type: "discard",
		fish: [
			0,
			2,
			0,
			1,
			0
		]
	},
	{
		id: 48,
		cost: 8,
		type: "discard",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: 49,
		cost: 4,
		type: "discard",
		fish: [
			0,
			0,
			0,
			0,
			0
		]
	}
], S = [
	{
		name: "games.tokyobay.cards.c0.name",
		text: "games.tokyobay.cards.c0.text"
	},
	{
		name: "games.tokyobay.cards.c1.name",
		text: "games.tokyobay.cards.c1.text"
	},
	{
		name: "games.tokyobay.cards.c2.name",
		text: "games.tokyobay.cards.c2.text"
	},
	{
		name: "games.tokyobay.cards.c3.name",
		text: "games.tokyobay.cards.c3.text"
	},
	{
		name: "games.tokyobay.cards.c4.name",
		text: "games.tokyobay.cards.c4.text"
	},
	{
		name: "games.tokyobay.cards.c5.name",
		text: "games.tokyobay.cards.c5.text"
	},
	{
		name: "games.tokyobay.cards.c6.name",
		text: "games.tokyobay.cards.c6.text"
	},
	{
		name: "games.tokyobay.cards.c7.name",
		text: "games.tokyobay.cards.c7.text"
	},
	{
		name: "games.tokyobay.cards.c8.name",
		text: "games.tokyobay.cards.c8.text"
	},
	{
		name: "games.tokyobay.cards.c9.name",
		text: "games.tokyobay.cards.c9.text"
	},
	{
		name: "games.tokyobay.cards.c10.name",
		text: "games.tokyobay.cards.c10.text"
	},
	{
		name: "games.tokyobay.cards.c11.name",
		text: "games.tokyobay.cards.c11.text"
	},
	{
		name: "games.tokyobay.cards.c12.name",
		text: "games.tokyobay.cards.c12.text"
	},
	{
		name: "games.tokyobay.cards.c13.name",
		text: "games.tokyobay.cards.c13.text"
	},
	{
		name: "games.tokyobay.cards.c14.name",
		text: "games.tokyobay.cards.c14.text"
	},
	{
		name: "games.tokyobay.cards.c15.name",
		text: "games.tokyobay.cards.c15.text"
	},
	{
		name: "games.tokyobay.cards.c16.name",
		text: "games.tokyobay.cards.c16.text"
	},
	{
		name: "games.tokyobay.cards.c17.name",
		text: "games.tokyobay.cards.c17.text"
	},
	{
		name: "games.tokyobay.cards.c18.name",
		text: "games.tokyobay.cards.c18.text"
	},
	{
		name: "games.tokyobay.cards.c19.name",
		text: "games.tokyobay.cards.c19.text"
	},
	{
		name: "games.tokyobay.cards.c20.name",
		text: "games.tokyobay.cards.c20.text"
	},
	{
		name: "games.tokyobay.cards.c21.name",
		text: "games.tokyobay.cards.c21.text"
	},
	{
		name: "games.tokyobay.cards.c22.name",
		text: "games.tokyobay.cards.c22.text"
	},
	{
		name: "games.tokyobay.cards.c23.name",
		text: "games.tokyobay.cards.c23.text"
	},
	{
		name: "games.tokyobay.cards.c24.name",
		text: "games.tokyobay.cards.c24.text"
	},
	{
		name: "games.tokyobay.cards.c25.name",
		text: "games.tokyobay.cards.c25.text"
	},
	{
		name: "games.tokyobay.cards.c26.name",
		text: "games.tokyobay.cards.c26.text"
	},
	{
		name: "games.tokyobay.cards.c27.name",
		text: "games.tokyobay.cards.c27.text"
	},
	{
		name: "games.tokyobay.cards.c28.name",
		text: "games.tokyobay.cards.c28.text"
	},
	{
		name: "games.tokyobay.cards.c29.name",
		text: "games.tokyobay.cards.c29.text"
	},
	{
		name: "games.tokyobay.cards.c30.name",
		text: "games.tokyobay.cards.c30.text"
	},
	{
		name: "games.tokyobay.cards.c31.name",
		text: "games.tokyobay.cards.c31.text"
	},
	{
		name: "games.tokyobay.cards.c32.name",
		text: "games.tokyobay.cards.c32.text"
	},
	{
		name: "games.tokyobay.cards.c33.name",
		text: "games.tokyobay.cards.c33.text"
	},
	{
		name: "games.tokyobay.cards.c34.name",
		text: "games.tokyobay.cards.c34.text"
	},
	{
		name: "games.tokyobay.cards.c35.name",
		text: "games.tokyobay.cards.c35.text"
	},
	{
		name: "games.tokyobay.cards.c36.name",
		text: "games.tokyobay.cards.c36.text"
	},
	{
		name: "games.tokyobay.cards.c37.name",
		text: "games.tokyobay.cards.c37.text"
	},
	{
		name: "games.tokyobay.cards.c38.name",
		text: "games.tokyobay.cards.c38.text"
	},
	{
		name: "games.tokyobay.cards.c39.name",
		text: "games.tokyobay.cards.c39.text"
	},
	{
		name: "games.tokyobay.cards.c40.name",
		text: "games.tokyobay.cards.c40.text"
	},
	{
		name: "games.tokyobay.cards.c41.name",
		text: "games.tokyobay.cards.c41.text"
	},
	{
		name: "games.tokyobay.cards.c42.name",
		text: "games.tokyobay.cards.c42.text"
	},
	{
		name: "games.tokyobay.cards.c43.name",
		text: "games.tokyobay.cards.c43.text"
	},
	{
		name: "games.tokyobay.cards.c44.name",
		text: "games.tokyobay.cards.c44.text"
	},
	{
		name: "games.tokyobay.cards.c45.name",
		text: "games.tokyobay.cards.c45.text"
	},
	{
		name: "games.tokyobay.cards.c46.name",
		text: "games.tokyobay.cards.c46.text"
	},
	{
		name: "games.tokyobay.cards.c47.name",
		text: "games.tokyobay.cards.c47.text"
	},
	{
		name: "games.tokyobay.cards.c48.name",
		text: "games.tokyobay.cards.c48.text"
	},
	{
		name: "games.tokyobay.cards.c49.name",
		text: "games.tokyobay.cards.c49.text"
	}
], re = [
	"games.tokyobay.monster0",
	"games.tokyobay.monster1",
	"games.tokyobay.monster2",
	"games.tokyobay.monster3",
	"games.tokyobay.monster4",
	"games.tokyobay.monster5"
], C = [
	"token",
	"token",
	"token",
	"heal",
	"heal",
	"heal",
	"energy",
	"energy",
	"energy",
	"energy",
	"smash",
	"smash",
	"smash",
	"smash"
], w = {
	id: "tokyobay",
	tier: "alpha",
	nameKey: "games.tokyobay.name",
	descKey: "games.tokyobay.desc",
	rulesKey: "games.tokyobay.rules",
	icon: "🦖",
	iconImg: "games/tokyobay.webp",
	accent: "#168f88",
	mechanics: [
		"dice-rolling",
		"push-your-luck",
		"tile-placement",
		"race",
		"engine-building"
	],
	interactionTags: [],
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	hotseat: "open",
	search: {
		py: "",
		init: ""
	},
	releasedAt: "2026-11-07T01:47:46+08:00",
	rulesUrl: { en: "https://iellogames.com/wp-content/uploads/2026/07/KOT-Duel-Tokyo-Bay_Rulebook_EN_Light.pdf" }
}, T = t.enum([
	"smash",
	"heal",
	"energy",
	"special",
	"fame",
	"destruction"
]), E = t.object({ support: t.boolean().default(!0) }).prefault({}), D = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		index: t.number().int().min(0).max(100)
	}),
	t.object({
		type: t.literal("roll"),
		dice: t.array(t.number().int().min(0).max(7)).max(8),
		extra: t.number().int().min(0).max(2).default(0)
	}),
	t.object({ type: t.literal("stop") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), O = t.object({
	kind: t.string(),
	n: t.number().default(0),
	card: t.number().default(-1),
	face: T.optional(),
	track: t.number().default(-1),
	tile: t.number().default(-1),
	monster: t.number().default(-1)
}), k = t.object({
	monster: t.number(),
	hp: t.number(),
	maxHp: t.number(),
	energy: t.number(),
	tokens: t.number(),
	shields: t.number(),
	cards: t.array(t.number()),
	captured: t.array(t.number()),
	support: t.array(t.number()),
	tentacles: t.array(t.number()),
	fans: t.array(t.number()),
	protocol: t.number()
}), A = t.object({
	players: t.array(t.string()),
	seats: t.array(k),
	turn: t.number(),
	round: t.number(),
	phase: t.enum([
		"draft",
		"roll",
		"react",
		"resolve",
		"support",
		"market",
		"end",
		"done"
	]),
	actor: t.number(),
	dice: t.array(T),
	rolls: t.number(),
	rollLimit: t.number(),
	extraLimit: t.number(),
	diceSources: t.array(t.enum([
		"normal",
		"extra",
		"support",
		"card"
	])),
	revealCard: t.number(),
	fishingCards: t.array(t.number()),
	resolved: t.array(T),
	tracks: t.array(t.object({
		tiles: t.array(t.number()),
		marker: t.number()
	})),
	canReroll: t.array(t.boolean()),
	prices: t.array(t.number()),
	market: t.array(t.number()),
	deckCount: t.number(),
	debrisCount: t.number(),
	choices: t.array(O),
	prompt: t.string(),
	busy: t.boolean(),
	supportMode: t.boolean(),
	winner: t.number().nullable(),
	reason: t.string(),
	event: t.object({
		seq: t.number(),
		kind: t.string(),
		seat: t.number(),
		n: t.number(),
		card: t.number()
	}),
	log: t.array(t.object({
		kind: t.string(),
		seat: t.number(),
		n: t.number(),
		card: t.number()
	}))
}), ie = t.object({ canAct: t.boolean() }), j = () => ({
	monster: -1,
	hp: 0,
	maxHp: 0,
	energy: 0,
	tokens: 0,
	shields: 0,
	cards: [],
	captured: [],
	support: [
		0,
		0,
		0,
		0,
		0,
		0
	],
	tentacles: [],
	fans: [],
	protocol: 0
}), M = (e, t = 0, n = 0, r = -1, i = -1, a = "") => ({
	k: e,
	p: t,
	n,
	a: r,
	b: i,
	source: a
}), N = (e, t = {}, n = []) => ({
	view: {
		kind: e,
		n: 0,
		card: -1,
		track: -1,
		tile: -1,
		monster: -1,
		...t
	},
	ops: n
}), P = (e, t, n) => e.seats[t].cards.includes(n), F = (e, t) => e.filter((e) => e === t).length;
function I(t, n) {
	return e(t.seed, t.cursor++, n);
}
function L(e, t) {
	for (let n = t.length - 1; n > 0; n--) {
		let r = I(e, n + 1);
		[t[n], t[r]] = [t[r], t[n]];
	}
	return t;
}
function R(e, t, n, r = 0, i = -1) {
	e.event = {
		seq: e.event.seq + 1,
		kind: t,
		seat: n,
		n: r,
		card: i
	}, e.log.push({
		kind: t,
		seat: n,
		n: r,
		card: i
	}), e.log = e.log.slice(-70);
}
function z(e, ...t) {
	e.queue.unshift(...t);
}
function B(e, t, n, r) {
	e.actor = t, e.prompt = n, e.options = r, e.phase = t === e.turn ? e.flow : "react";
}
function V(e, t, n) {
	e.winner = t, e.reason = n, e.phase = "done", e.queue = [], e.options = [];
}
function H(e) {
	if (!(e.phase === "done" || e.damageBatch)) {
		if (e.seats.every((e) => e.hp <= 0) && e.seats.every((e) => e.monster >= 0)) {
			V(e, -1, "draw");
			return;
		}
		for (let t of [e.turn, 1 - e.turn]) {
			let n = e.seats[t], r = e.seats[1 - t];
			if (!(n.monster < 0 || r.monster < 0)) {
				if (r.hp <= 0) {
					V(e, t, "ko");
					return;
				}
				if (e.tracks.every((e) => e.tiles.length === 5 && e.marker === (t === 0 ? 0 : 4))) {
					V(e, t, "tracksWin");
					return;
				}
				if (n.captured.length >= 3) {
					V(e, t, "captureWin");
					return;
				}
				if (P(e, t, 10) && n.cards.length >= 7 || P(e, t, 22) && n.captured.length >= 2 && n.hp < r.hp || P(e, t, 24) && n.hp >= 20 || P(e, t, 25) && n.energy >= 18) {
					V(e, t, "cardWin");
					return;
				}
			}
		}
	}
}
function ae(e) {
	return !e.deck.length && e.discard.length && (e.deck = L(e, e.discard), e.discard = []), e.deck.shift();
}
function U(e) {
	for (; e.market.length < 3;) {
		let t = ae(e);
		if (t === void 0) break;
		e.market.unshift(t);
	}
}
function oe(e, t, n) {
	e.seats[t].cards = e.seats[t].cards.filter((e) => e !== n), e.discard.push(n), R(e, "Discard", t, 1, n), n === 24 && (e.seats[t].maxHp = b[e.seats[t].monster], e.seats[t].hp = Math.min(e.seats[t].hp, e.seats[t].maxHp)), n === 28 && (e.lastChance = e.seats.some((e) => e.cards.includes(28)));
}
function se(e, t, n, r) {
	let i = e.seats[t];
	if (n === "heal") {
		let n = i.hp;
		i.hp = Math.min(i.maxHp, i.hp + r), R(e, "Heal", t, i.hp - n);
	}
	n === "energy" && (i.energy = Math.max(0, i.energy + r), R(e, "Energy", t, r)), n === "token" && (i.tokens = Math.min(2, i.tokens + r), R(e, "Other", t, r));
}
function ce(e, t, n = 3) {
	let r = e.market[t], i = r === 43 ? e.tracks.reduce((e, t) => e + t.tiles.length - 1, 0) : r === 46 ? n : x[r].cost;
	return Math.max(0, i - +(t === e.market.length - 1) - e.discounts - e.nextDiscount);
}
function le(e) {
	e.flow = "roll", e.phase = "roll", e.actor = e.turn, e.dice = [], e.finalDice = [], e.remaining = [], e.rolls = 0, e.rerolls = 0, e.diceSources = [], e.baseDice = Math.min(8, (e.round === 1 ? 5 : 6) + Number(P(e, e.turn, 16)) + Number(P(e, e.turn, 29))), e.rollLimit = 3 + Number(P(e, e.turn, 19)), P(e, 1 - e.turn, 32) && (e.rollLimit = Math.min(e.rollLimit, 1 + e.lastRerolls[1 - e.turn])), e.lost = 0, e.bought = !1, e.discounts = 0, e.nextDiscount = 0, e.activations = 0, e.pulls = [0, 0], e.usedCards = [], e.ironMode = -1, e.vampire = !1;
}
function ue(e) {
	let t;
	do
		t = [0, 1].map(() => Array.from({ length: 6 }, () => I(e, 6)).filter((e) => e === 0).length);
	while (t[0] === t[1]);
	e.turn = t[0] > t[1] ? 0 : 1, e.seats[1 - e.turn].energy = 1, e.round = 1, R(e, "Initiative", e.turn, t[e.turn], t[1 - e.turn]), le(e);
}
function de(e) {
	let t = e.turn, n = e.seats[t], r = [];
	for (let n of v) e.remaining.includes(n) && r.push(N("resolve", {
		face: n,
		n: F(e.remaining, n)
	}, [M("face", t, 0, v.indexOf(n))]));
	let i = (t) => F(e.finalDice, t), a = new Set(e.finalDice).size, o = {
		12: a >= 4,
		13: i("smash") >= 2 && n.energy > 0,
		18: a === 6,
		24: i("special") >= 2,
		25: i("special") >= 2,
		26: !i("fame") && !i("destruction")
	};
	for (let i of n.cards) o[i] && !e.usedCards.includes(i) && r.push(N("cardEffect", { card: i }, [M("rollCard", t, 0, i)]));
	r.length ? B(e, t, "resolve", r) : (e.flow = "support", e.supportLeft = e.supportMode ? Math.floor(e.lost / 2) : 0, W(e));
}
function W(e) {
	if (e.phase === "done" || e.queue.length || e.options.length) return;
	let t = e.turn, n = e.seats[t];
	if (e.actor = t, e.phase = e.flow, e.prompt = e.flow, e.flow === "draft") {
		let t = e.seats[0].monster < 0 ? 0 : 1;
		B(e, t, "chooseMonster", Array.from({ length: 6 }, (e, t) => t).filter((t) => !e.seats.some((e) => e.monster === t)).map((e) => N("monster", { monster: e }, [M("draft", t, 0, e)])));
	} else if (e.flow === "resolve") de(e);
	else if (e.flow === "support") e.supportLeft && n.support.includes(0) ? B(e, t, "support", [...n.support.flatMap((e, n) => e === 0 ? [N("takeSupport", { face: v[n] }, [M("support", t, 0, n)])] : []), N("decline", {}, [M("supportEnd", t)])]) : (e.flow = "market", W(e));
	else if (e.flow === "market") {
		let r = [];
		e.market.forEach((i, a) => {
			let o = i === 46 ? [3, 8] : [3];
			for (let s of o) {
				let o = ce(e, a, s);
				n.energy >= o && r.push(N("buy", {
					card: i,
					n: o,
					track: a,
					tile: i === 46 ? s : -1
				}, [M("buy", t, o, a, s)]));
			}
		}), n.energy >= 2 && e.market.length && r.push(N("refresh", { n: 2 }, [M("refresh", t, 2)]));
		for (let e of n.fans) r.push(N("fan", { n: e }, [M("fan", t, 0, e)]));
		r.push(N(n.cards.includes(8) && !e.bought ? "finishForecast" : e.bought ? "finish" : "gainEnergy", {}, [M("finish", t)])), B(e, t, "market", r);
	}
}
function fe(e, t, n = -1) {
	if (!e.debris.length) return;
	let r = e.debris.splice(0, P(e, t, 14) ? 2 : 1);
	r.length === 1 ? z(e, M("placeDebris", t, 0, r[0], n)) : B(e, t, "nightVision", r.map((e) => N("nightVision", {
		tile: e,
		track: n
	}, [M("chosenDebris", t, 0, e, n), ...r.filter((t) => t !== e).map((e) => M("returnTile", t, 0, e))])));
}
function pe(e, t, n) {
	let r = e.queue.length, i = e.tracks[n], a = i.marker + (t === 0 ? -1 : 1);
	e.pulls[n]++, R(e, "Pull", t, 1, n), a < 0 || a >= i.tiles.length ? fe(e, t, i.tiles.length === 5 ? -1 : n) : (i.marker = a, i.tiles[a] >= 0 ? z(e, M("bonus", t, 0, i.tiles[a])) : me(e)), P(e, 1 - t, 38) && e.queue.splice(e.queue.length - r, 0, M("reaction", 1 - t)), e.flow === "resolve" && e.pulls[n] >= 3 && P(e, 1 - t, 15) && (e.seats[t].energy = 0, R(e, "Energy", t, 0, 15));
}
function me(e) {
	for (let t of [0, 1]) P(e, t, 39) && z(e, M("token", t, 1));
}
function he(e, t, n, r = !1) {
	let i = e.seats[t], a = [], o = (e) => n > e ? [M("special", t, n - e, +!!r)] : [];
	if (i.monster === 0 && n >= 2) {
		i.protocol = i.protocol % 3 + 1, e.activations++, R(e, "Special", t, 1), z(e, ...i.protocol === 1 ? [M("damage", 1 - t, 3, -1, -1, "special")] : i.protocol === 2 ? [M("token", t, 1)] : [M("pull", t, 1, 0)], ...o(2));
		return;
	}
	if (i.monster === 1 && n >= 1 && (a.push(N("gigarex1", {}, [M("rage", t, 1), ...o(1)])), n >= 3 && a.push(N("gigarex3", {}, [M("rage", t, 4), ...o(3)]))), i.monster === 2 && n >= 1) {
		e.activations += n, e.fishingCards = Array.from({ length: n }, () => ae(e)).filter((e) => e !== void 0), z(e, ...e.fishingCards.map((e) => M("fish", t, 0, e)), ...e.fishingCards.map((e) => M("fishReturn", t, 0, e)));
		return;
	}
	if (i.monster === 3 && n >= 1 && (e.ironMode !== 1 && a.push(N("shieldMode", {}, [M("shields", t, n)])), e.ironMode !== 0 && i.shields > 0)) for (let e = 0; e <= i.shields; e++) a.push(N("exchange", {
		n: e,
		tile: i.shields - e
	}, [M("exchange", t, e, i.shields - e), ...o(1)]));
	if (i.monster === 4 && n >= 1) {
		let n = e.seats.flatMap((e) => e.tentacles).map((e) => e % 3);
		for (let e = 0; e < 3; e++) if (!n.includes(e)) for (let n of [t, 1 - t]) a.push(N(n === t ? "tentacleSelf" : "tentacleRival", { face: [
			"heal",
			"smash",
			"fame"
		][e] }, [M("tentacle", t, 1, e, n), ...o(1)]));
	}
	if (i.monster === 5 && n >= 2 && (e.fanDeck.length || (e.fanDeck = L(e, e.fanDiscard), e.fanDiscard = []), e.fanDeck.length)) {
		let n = e.fanDeck.shift();
		i.fans.push(n), e.activations++, R(e, "Fan", t, 1, n), z(e, ...o(2));
		return;
	}
	a.length ? B(e, t, "activate", a) : r || (e.lost += n);
}
function ge(e, t, n, r) {
	let i = 1 - t, a = e.seats[t], o = [], s = (e, n) => Array.from({ length: n }, () => M("pull", t, 1, e));
	if (n === 0) {
		let e = [
			M("heal", t, 3),
			M("token", t, 1),
			M("pull", t, 1, 1)
		], n = [
			"heal",
			"special",
			"destruction"
		];
		o.push({
			k: "menu",
			p: t,
			prompt: "pillage",
			options: e.map((r, a) => N("pillage", { face: n[a] }, [{
				k: "menu",
				p: t,
				prompt: "choose",
				options: e.flatMap((t, r) => r === a ? [] : [N("effectOrder", { face: n[r] }, [
					t,
					...e.filter((e, t) => t !== a && t !== r),
					{
						...e[a],
						p: i
					}
				])])
			}]))
		});
	}
	if (n === 1 && a.captured.length && o.push({
		k: "menu",
		p: t,
		prompt: "returnDebris",
		options: a.captured.map((e) => N("returnDebris", { tile: e }, [M("returnCapture", t, 0, e), M("damage", i, 6, -1, -1, "card")]))
	}), n === 2 && o.push(...s(0, 2)), n === 3) for (let e of [t, i]) o.push(M("discardChoice", e));
	if (n === 4) for (let n = 0; n < Math.min(2, e.activations); n++) o.push(M("chooseTrack", t, 1));
	n === 5 && o.push({
		k: "menu",
		p: t,
		prompt: "choose",
		options: [0, 1].map((n) => N("track", {
			track: n,
			face: n === 0 ? "fame" : "destruction"
		}, e.tracks[n].tiles.filter((e) => e >= 0).map((e) => M("bonus", t, 0, e))))
	}), n === 17 && o.push(M("drawDebris", t)), n === 40 && o.push({
		k: "menu",
		p: t,
		prompt: "choose",
		options: e.tracks.flatMap((e, n) => e.tiles.flatMap((r, i) => r >= 0 && e.marker !== i ? [N("tile", {
			tile: r,
			track: n
		}, [
			M("bonus", t, 0, r),
			M("bonus", t, 0, r),
			M("removeTile", t, 0, r, n)
		])] : []))
	}), n === 41 && o.push(...s(1, 1), {
		k: "menu",
		p: t,
		prompt: "artificer",
		options: [N("artificer", {}, [M("damage", t, 3, -1, -1, "card"), ...s(1, 1)]), N("pass")]
	}), n === 42 && o.push(M("resetTrack", t, 0, 1), M("token", t, 1)), n === 43 && o.push(M("beginDamage"), M("damage", t, r, 1, -1, "card"), M("damage", i, r, 1, -1, "card"), M("check")), n === 44 && o.push(M("damage", i, F(e.finalDice, "special"), -1, -1, "card")), n === 45 && o.push(M("energy", t, 2 * F(e.finalDice, "special"))), n === 46 && o.push(M("special", t, r === 8 ? 6 : 2, 1)), n === 47 && o.push(M("heal", t, e.tracks.flatMap((e) => e.tiles).filter((e) => e >= 0 && ["heal", "token"].includes(C[e])).length)), n === 48 && o.push(...e.debris.map((e) => M("bonus", t, 0, e)), M("shuffleDebris")), n === 49 && o.push(M("jealousy", i)), z(e, ...o);
}
function _e(e, t, n) {
	e.usedCards.push(n), R(e, "Card", t, 1, n), n === 12 && z(e, M("pull", t, 1, 0)), n === 13 && z(e, M("missiles", t, Math.floor(F(e.finalDice, "smash") / 2))), n === 18 && z(e, M("drawDebris", t)), n === 24 && z(e, M("heal", t, Math.floor(F(e.finalDice, "special") / 2))), n === 25 && z(e, M("energy", t, Math.floor(F(e.finalDice, "special") / 2))), n === 26 && z(e, M("damage", 1 - t, 2, -1, -1, "card"));
}
function ve(e, t) {
	let n = t.p ?? e.turn, r = t.n ?? 0, i = t.a ?? -1, a = t.b ?? -1, o = e.seats[n], s = 1 - n;
	if (t.k === "menu") {
		t.options?.length && B(e, n, t.prompt ?? "choose", t.options);
		return;
	}
	if ([
		"heal",
		"energy",
		"token"
	].includes(t.k)) se(e, n, t.k, r);
	else if (t.k === "draft") o.monster = i, o.hp = b[i], o.maxHp = b[i], e.seats.every((e) => e.monster >= 0) && ue(e);
	else if (t.k === "damage") {
		if (r <= 0 || P(e, n, 33) && ["card", "special"].includes(t.source ?? "") || P(e, n, 7) && e.flow === "resolve" && n !== e.turn && r >= 5) return;
		if (o.shields > 0) {
			B(e, n, "damageChoice", Array.from({ length: Math.min(r, o.shields) + 1 }, (e, t) => N("shield", {
				n: t,
				tile: r - t
			}, [M("hurt", n, r - t, t, i)])));
			return;
		}
		z(e, M("hurt", n, r, 0, i));
	} else if (t.k === "hurt") {
		o.shields -= i, o.hp = Math.max(0, o.hp - r), R(e, "Damage", n, r), r > 0 && n !== e.turn && !e.vampire && P(e, e.turn, 6) && (e.vampire = !0, z(e, M("heal", e.turn, 1))), a !== 1 && H(e);
		return;
	} else if (t.k === "beginDamage") e.damageBatch = !0;
	else if (t.k === "check") e.damageBatch = !1, H(e);
	else if (t.k === "rage") e.activations++, R(e, "Special", n, 1), z(e, M("beginDamage"), M("damage", n, 1, 1, -1, "special"), M("damage", s, r, 1, -1, "special"), M("check"));
	else if (t.k === "pull") pe(e, n, i);
	else if (t.k === "reaction") {
		let t = I(e, 6);
		R(e, "ReactionDie", n, t, 38), (t === 0 || t === 3) && z(e, M("damage", s, 1, -1, -1, "card"));
	} else if (t.k === "drawDebris") fe(e, n);
	else if (t.k === "chosenDebris") z(e, M("placeDebris", n, 0, i, a));
	else if (t.k === "returnTile") e.debris.push(i);
	else if (t.k === "placeDebris") {
		if (a >= 0) {
			let t = e.tracks[a];
			n === 0 ? (t.tiles.unshift(i), t.marker = 0) : (t.tiles.push(i), t.marker = t.tiles.length - 1), R(e, "Tile", n, 1, a);
		} else {
			z(e, M("bonus", n, 0, i), M("captureRecord", n, 0, i));
			return;
		}
		z(e, M("bonus", n, 0, i));
	} else if (t.k === "captureRecord") o.captured.push(i), R(e, "Capture", n, o.captured.length, i), (P(e, n, 16) && o.captured.length > e.captureGoal[n] || e.lastChance) && V(e, n, "lastChanceWin");
	else if (t.k === "captureWin") V(e, n, "lastChanceWin");
	else if (t.k === "bonus") {
		let t = C[i];
		P(e, s, 11) && t === "energy" ? (o.energy = Math.max(0, o.energy - 1), R(e, "Energy", n, -1)) : P(e, s, 11) && t === "heal" ? (o.hp = Math.max(0, o.hp - 1), R(e, "Damage", n, 1)) : t === "smash" ? z(e, M("damage", s, P(e, n, 37) ? 2 : 1, -1, -1, "debris")) : z(e, M(t, n, t === "energy" && P(e, n, 36) ? 2 : 1));
	} else if (t.k === "face") {
		let t = v[i], r = F(e.remaining, t);
		if (e.remaining = e.remaining.filter((e) => e !== t), t === "smash" && z(e, M("damage", s, r, -1, -1, "dice")), t === "energy" && z(e, M("energy", n, r)), t === "heal" && (e.lost += Math.max(0, r - (o.maxHp - o.hp)), z(e, M("heal", n, r))), t === "fame" || t === "destruction") {
			let i = r - 2 - Number(P(e, s, 21));
			i > 0 ? z(e, ...Array.from({ length: i }, () => M("pull", n, 1, t === "fame" ? 0 : 1))) : e.lost += r;
		}
		t === "special" && z(e, M("special", n, r));
	} else if (t.k === "special") he(e, n, r, i === 1);
	else if (t.k === "shields") e.ironMode = 0, o.shields = Math.min(4, o.shields + r), e.activations += r, R(e, "Special", n, r);
	else if (t.k === "exchange") e.ironMode = 1, o.shields = 0, e.activations++, R(e, "Special", n, 1), z(e, M("energy", n, r), M("damage", s, i, -1, -1, "special"));
	else if (t.k === "tentacle") e.seats[a].tentacles.push(i + (a === n ? 0 : 3)), e.activations++, R(e, "Special", n, 1);
	else if (t.k === "fish") {
		e.revealCard = i, R(e, "Fish", n, 1, i);
		let t = x[i].fish;
		z(e, M("damage", s, t[0], -1, -1, "special"), M("heal", n, t[1]), M("energy", n, t[2]), M("token", n, t[3]), ...t[4] ? [M("pull", n, 1, 0), M("pull", n, 1, 1)] : []);
	} else if (t.k === "fishReturn") e.deck.push(i), e.fishingCards = e.fishingCards.filter((e) => e !== i), e.revealCard = e.fishingCards[0] ?? -1, R(e, "ReturnCard", n, 1, i);
	else if (t.k === "support") o.support[i] = 1, e.supportLeft--, R(e, "Support", n, 1, i);
	else if (t.k === "supportEnd") e.supportLeft = 0, e.flow = "market";
	else if (t.k === "refresh") o.energy -= r, e.discard.push(...e.market), e.market = [], U(e), R(e, "Market", n);
	else if (t.k === "buy") {
		let t = e.market[i], c = t === 43 ? e.tracks.reduce((e, t) => e + t.tiles.length - 1, 0) : a;
		o.energy -= r, e.nextDiscount = 0, e.bought = !0, e.market.splice(i, 1), U(e), R(e, "Buy", n, r, t), x[t].type === "discard" ? (e.discard.push(t), ge(e, n, t, c)) : (o.cards.push(t), t === 11 && z(e, M("drawDebris", n)), t === 24 && (o.maxHp = 20, o.hp = Math.max(0, o.hp - 3)), t === 16 && (e.captureGoal[n] = o.captured.length), t === 28 && (e.lastChance = !0)), P(e, s, 35) && z(e, M("energy", s, 1));
	} else if (t.k === "rollCard") _e(e, n, i);
	else if (t.k === "missiles" && r > 0 && o.energy > 0) B(e, n, "missile", [N("missile", {}, [
		M("spend", n, 1),
		M("damage", s, 2, -1, -1, "card"),
		M("missiles", n, r - 1)
	]), N("pass")]);
	else if (t.k === "spend") o.energy -= r;
	else if (t.k === "chooseTrack") B(e, n, "choose", [0, 1].map((e) => N("track", {
		face: e === 0 ? "fame" : "destruction",
		track: e
	}, [M("pull", n, 1, e)])));
	else if (t.k === "discardChoice" && o.cards.length) B(e, n, "discard", o.cards.map((e) => N("discard", { card: e }, [M("discard", n, 0, e)])));
	else if (t.k === "discard") oe(e, n, i);
	else if (t.k === "returnCapture") o.captured = o.captured.filter((e) => e !== i), e.debris.push(i);
	else if (t.k === "removeTile") {
		let t = e.tracks[a], n = t.tiles.indexOf(i);
		t.tiles.splice(n, 1), t.marker > n && t.marker--, e.debris.unshift(i);
	} else if (t.k === "resetTrack") e.tracks[i].marker = e.tracks[i].tiles.indexOf(-1), me(e), R(e, "Pull", n, 0, i);
	else if (t.k === "shuffleDebris") L(e, e.debris);
	else if (t.k === "jealousy") B(e, n, "discard", [...o.cards.map((e) => N("discard", { card: e }, [M("discard", n, 0, e), M("jealousy", n)])), N("keepCard", {}, Array.from({ length: o.cards.length }, () => M("pull", s, 1, 1)))]);
	else if (t.k === "fan") {
		if (o.fans.splice(o.fans.indexOf(i), 1), e.fanDiscard.push(i), i === 0 && z(e, M("refresh", n, 0), M("energy", n, 1)), i === 1 && (e.nextDiscount += 3), i === 2 && e.discounts++, i === 3) {
			let t = Array.from({ length: 5 }, () => ae(e)).filter((e) => e !== void 0);
			B(e, n, "offer", t.map((r) => N("offer", { card: r }, [{
				k: "menu",
				p: n,
				prompt: "replace",
				options: e.market.map((e, i) => N("replace", {
					card: e,
					track: i
				}, [
					M("replaceMarket", n, 0, r, i),
					...t.filter((e) => e !== r).map((e) => M("deckReturn", n, 0, e)),
					M("shuffleDeck")
				]))
			}])));
		}
	} else if (t.k === "replaceMarket") e.deck.push(e.market[a]), e.market[a] = i;
	else if (t.k === "deckReturn") e.deck.push(i);
	else if (t.k === "shuffleDeck") L(e, e.deck);
	else if (t.k === "finish") e.bought || z(e, M("energy", n, P(e, n, 8) ? 2 : 1)), e.queue.push(M("nextTurn"));
	else if (t.k === "nextTurn") e.turn = 1 - e.turn, e.round++, le(e);
	else if (t.k === "change") e.dice[i] = v[a];
	else if (t.k === "preReact") {
		let t = [30, 31].filter((t) => P(e, s, t) && e.dice.includes(t === 30 ? "smash" : "heal")).map((e) => N("cancelCard", { card: e }, [M("cancel", s, 0, e), M("preReact", n)]));
		t.length ? B(e, s, "react", [...t, N("pass", {}, [M("finalize", n)])]) : z(e, M("finalize", n));
	} else t.k === "cancel" ? (oe(e, n, i), e.diceSources = e.diceSources.filter((t, n) => e.dice[n] !== (i === 30 ? "smash" : "heal")), e.dice = e.dice.filter((e) => e !== (i === 30 ? "smash" : "heal"))) : t.k === "finalize" && (e.finalDice = [...e.dice], e.remaining = [...e.dice], e.flow = "resolve", e.phase = "resolve", P(e, s, 9) && v.some((t) => F(e.finalDice, t) >= 5) && z(e, M("energy", s, 3)), P(e, s, 34) && e.finalDice.includes("heal") && z(e, M("heal", s, 1)), P(e, n, 16) && v.some((t) => F(e.finalDice, t) >= 4) && z(e, M("damage", n, 10, -1, -1, "card")));
	H(e);
}
function ye(e) {
	let t = e.turn, n = e.seats[t];
	e.lastRerolls[t] = e.rerolls, n.tentacles = [], e.fixedDice = e.dice.length;
	let r = n.support.flatMap((e, t) => e === 1 ? [v[t]] : []);
	e.dice.push(...r), e.diceSources.push(...r.map(() => "support")), n.support = n.support.map((e) => e === 1 ? 2 : e), P(e, t, 27) && (e.dice.push(...n.captured.map(() => "smash")), e.diceSources.push(...n.captured.map(() => "card"))), e.flow = "resolve", e.phase = "resolve";
	let i = P(e, t, 23) ? e.dice.slice(0, e.fixedDice).flatMap((e, n) => e === "fame" || e === "destruction" ? [N("change", {
		face: e === "fame" ? "destruction" : "fame",
		tile: n
	}, [M("change", t, 0, n, v.indexOf(e === "fame" ? "destruction" : "fame")), M("preReact", t)])] : []) : [];
	i.length ? B(e, t, "change", [...i, N("pass", {}, [M("preReact", t)])]) : z(e, M("preReact", t));
}
function be(e, t) {
	if (e.seats[1 - e.turn].cards.includes(32) && e.rerolls >= e.lastRerolls[1 - e.turn]) return !1;
	let n = e.seats[e.turn].tentacles, r = e.dice[t], i = [
		"heal",
		"smash",
		"fame"
	];
	return n.some((e) => e >= 3 && i[e % 3] === r) ? !1 : e.rolls < e.rollLimit || n.some((e) => e < 3 && i[e] === r);
}
function xe(e, t, n) {
	let r = {
		players: [...t],
		seats: [j(), j()],
		seed: n,
		cursor: 0,
		supportMode: E.parse(e).support,
		turn: 0,
		round: 0,
		flow: "draft",
		actor: 0,
		dice: [],
		diceSources: [],
		finalDice: [],
		remaining: [],
		rolls: 0,
		rerolls: 0,
		rollLimit: 3,
		baseDice: 6,
		lastRerolls: [2, 2],
		fixedDice: 0,
		tracks: [{
			tiles: [-1],
			marker: 0
		}, {
			tiles: [-1],
			marker: 0
		}],
		deck: [],
		discard: [],
		debris: [],
		market: [],
		queue: [],
		options: [],
		prompt: "chooseMonster",
		phase: "draft",
		winner: null,
		reason: "",
		lost: 0,
		supportLeft: 0,
		bought: !1,
		discounts: 0,
		nextDiscount: 0,
		activations: 0,
		pulls: [0, 0],
		usedCards: [],
		ironMode: -1,
		vampire: !1,
		fanDeck: [],
		fanDiscard: [],
		captureGoal: [0, 0],
		lastChance: !1,
		damageBatch: !1,
		revealCard: -1,
		fishingCards: [],
		event: {
			seq: 0,
			kind: "",
			seat: 0,
			n: 0,
			card: -1
		},
		log: []
	};
	return r.deck = L(r, Array.from({ length: 50 }, (e, t) => t)), r.debris = L(r, Array.from({ length: 14 }, (e, t) => t)), r.fanDeck = L(r, [
		0,
		1,
		2,
		3
	]), U(r), W(r), {
		state: r,
		fx: []
	};
}
function Se(e, t, n) {
	return t.event.seq === e.event.seq ? [] : [{
		kind: "tokyoEvent",
		rid: t.players[t.event.seat],
		data: {
			kind: t.event.kind,
			n: t.event.n,
			card: t.event.card,
			dice: t.dice,
			sources: t.diceSources,
			indices: n.type === "roll" ? e.rolls ? n.dice : t.dice.map((e, t) => t) : [],
			slot: t.event.kind === "Buy" ? e.market.indexOf(t.event.card) : -1,
			newCards: t.market.filter((t) => !e.market.includes(t)),
			tracks: t.tracks,
			oldMarket: e.market,
			tile: t.event.kind === "Tile" ? t.tracks[t.event.card].tiles.find((n) => !e.tracks[t.event.card].tiles.includes(n)) ?? -1 : -1
		}
	}];
}
function Ce(e, t, n) {
	let r = { code: "games.tokyobay.error" };
	if (e.phase === "done") return r;
	if (t.type === "tick") {
		if (n.by !== "$engine" || !e.queue.length || e.options.length) return {
			state: e,
			fx: []
		};
		let r = structuredClone(e);
		return ve(r, r.queue.shift()), W(r), {
			state: r,
			fx: Se(e, r, t)
		};
	}
	if (n.by !== e.players[e.actor] || e.queue.length && e.options.length === 0) return r;
	let i = structuredClone(e);
	if (t.type === "choose") {
		let e = i.options[t.index];
		if (!e) return r;
		i.options = [], i.prompt = "", i.actor = i.turn, i.phase = i.flow, z(i, ...e.ops);
	} else if (t.type === "roll") {
		if (i.flow !== "roll") return r;
		if (i.rolls === 0) {
			if (t.extra > i.seats[i.turn].tokens || i.baseDice + t.extra > 8) return r;
			i.seats[i.turn].tokens -= t.extra, i.dice = Array.from({ length: i.baseDice + t.extra }, () => v[I(i, 6)]), i.rolls = 1, i.diceSources = i.dice.map((e, t) => t >= (i.round === 1 ? 5 : 6) ? "extra" : "normal");
		} else {
			let e = [...new Set(t.dice)];
			if (!e.length || e.some((e) => e >= i.dice.length || !be(i, e))) return r;
			P(i, i.turn, 20) && e.some((e) => i.dice[e] === "smash") && z(i, M("damage", 1 - i.turn, 1, -1, -1, "card")), i.rerolls++;
			let n = i.rolls < i.rollLimit;
			e.forEach((e) => {
				i.dice[e] = v[I(i, 6)];
			}), n && i.rolls++;
		}
		R(i, "Roll", i.turn, i.rolls);
	} else if (t.type === "stop") {
		if (i.flow !== "roll" || i.rolls === 0) return r;
		ye(i);
	}
	return W(i), H(i), {
		state: i,
		fx: Se(e, i, t)
	};
}
function we(e, t) {
	return {
		public: {
			players: e.players,
			seats: e.seats,
			turn: e.turn,
			round: e.round,
			phase: e.phase,
			actor: e.actor,
			dice: e.dice,
			diceSources: e.diceSources,
			revealCard: e.revealCard,
			fishingCards: e.fishingCards,
			rolls: e.rolls,
			rollLimit: e.rollLimit,
			extraLimit: Math.min(2, e.seats[e.turn].tokens, 8 - e.baseDice),
			resolved: v.filter((t) => !e.remaining.includes(t)),
			tracks: e.tracks,
			market: e.market,
			deckCount: e.deck.length,
			debrisCount: e.debris.length,
			choices: e.options.map((e) => e.view),
			prompt: e.prompt,
			busy: e.queue.length > 0 && !e.options.length,
			supportMode: e.supportMode,
			winner: e.winner,
			reason: e.reason,
			event: e.event,
			log: e.log,
			canReroll: e.dice.map((t, n) => e.flow === "roll" && be(e, n)),
			prices: e.market.map((t, n) => ce(e, n))
		},
		private: { canAct: e.players[e.actor] === t && e.phase !== "done" && (!e.queue.length || e.options.length > 0) }
	};
}
var Te = {
	meta: w,
	saveCompatibility: { version: "1" },
	schemas: {
		action: D,
		publicView: A,
		privateView: ie,
		config: E
	},
	setup: xe,
	reduce: Ce,
	viewFor: we,
	status: (e) => e.phase === "done" ? {
		phase: "done",
		winner: e.winner === -1 ? [] : [e.players[e.winner]],
		ranking: e.winner === -1 ? e.players : [e.players[e.winner], e.players[1 - e.winner]]
	} : { phase: e.phase },
	nextTickIn: (e) => e.phase !== "done" && e.queue.length && !e.options.length ? 540 : null
}, Ee = {
	smash: "#fffdf2",
	heal: "#f577a1",
	energy: "#d6e85a",
	special: "#fffdf2",
	fame: "#72c4e0",
	destruction: "#eb6d58",
	damage: "#f4bd4c",
	token: "#fff6d7",
	shield: "#a9b2db",
	capture: "#ded6bd",
	crown: "#f8d44e"
};
function G({ kind: e, className: t = "" }) {
	let n;
	return n = e === "smash" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M11 30Q18 17 25 20Q35 23 39 30Q40 32 37 35L31 45Q28 49 21 45Q11 41 11 30Z" }), /* @__PURE__ */ p("path", { d: "M2 19Q0 14 4 16L11 20Q14 23 10 27Q6 29 2 19ZM18 4Q20-2 22 5L24 15Q23 21 18 18L16 16ZM31 4Q34-1 35 6L36 19Q35 23 31 22Q25 21 26 16ZM39 21Q40 19 47 16Q49 17 45 25Q42 29 39 26Z" })] }) : e === "heal" ? /* @__PURE__ */ p("path", { d: "M24 42C16 35 3 26 3 15 3 3 19 0 24 11 30 0 45 3 45 15 45 26 32 35 24 42Z" }) : e === "energy" ? /* @__PURE__ */ p("path", { d: "M30 1 9 24Q8 26 11 27L22 32 19 47 38 26Q40 24 37 23L27 19Z" }) : e === "special" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M15 2Q22-1 31 3Q33 7 31 14L26 17 31 20Q32 26 29 32Q24 35 19 32Q15 21 15 2Z" }), /* @__PURE__ */ p("circle", {
		cx: "24",
		cy: "42",
		r: "6"
	})] }) : e === "fame" ? /* @__PURE__ */ p("path", { d: "M24 1Q25-1 26 2L31 18 47 17Q50 17 47 20L34 29 36 34 34 36 37 36 40 46Q40 49 37 47L24 37 10 47Q7 49 9 45L14 29 1 20Q-1 17 3 17L19 18Z" }) : e === "destruction" ? /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("path", { d: "M10 2H36V6H10ZM13 9H34V23H20L22 26 8 21 10 17 13 19Z" }),
		/* @__PURE__ */ p("path", { d: "M22 30 31 25 41 27V32L33 29 38 38Q33 49 22 46L15 33Z" }),
		/* @__PURE__ */ p("path", {
			d: "M17 13h3m7 0h3m-13 5h3m7 0h3m-5 16 3-2m4 6 3-2m-12 5 3-2",
			fill: "none",
			stroke: "#247f75",
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ p("path", { d: "m6 27 7 1-7 2Zm-1 10 12-7-10 12ZM38 20l6-3 1 4-8 3" })
	] }) : e === "damage" ? /* @__PURE__ */ p("path", { d: "m24 0 4 14 13-8-5 15 12 3-12 7 6 14-16-7-11 10 1-16-15-4 13-7-7-13 14 7Z" }) : e === "token" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "m5 11 18-9 20 8-2 26-18 10L6 36Z" }), /* @__PURE__ */ p("path", {
		d: "m5 11 18 10 20-11M23 21v25",
		fill: "none"
	})] }) : e === "shield" ? /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("ellipse", {
			cx: "24",
			cy: "24",
			rx: "21",
			ry: "16",
			transform: "rotate(-23 24 24)",
			fill: "#5b4669",
			stroke: "#d29ab9"
		}),
		/* @__PURE__ */ p("path", {
			d: "M27 8Q46 7 44 22Q42 36 24 41Q16 33 23 26Q30 19 27 8Z",
			fill: "#cc609c",
			stroke: "none"
		}),
		/* @__PURE__ */ p("path", {
			d: "m14 17 2-6-1 21-4 1Zm9-7 2-3-1 23-5 6Zm11-1 3 2-3 17-5 7Z",
			fill: "#e9e1e0",
			stroke: "none"
		})
	] }) : e === "capture" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "m4 13 12-7 9 4 10-4 10 11-5 24H7Z" }), /* @__PURE__ */ p("path", {
		d: "m6 24 13 2 6-13m0 13 11 7",
		fill: "none"
	})] }) : /* @__PURE__ */ p("path", { d: "m4 12 11 9 9-18 9 18 11-9-5 29H9Z" }), /* @__PURE__ */ p("svg", {
		className: `tb-symbol ${t}`,
		viewBox: "0 0 48 48",
		"aria-hidden": "true",
		children: /* @__PURE__ */ p("g", {
			fill: Ee[e],
			stroke: e === "smash" || e === "special" ? "none" : "#293734",
			strokeWidth: "2.5",
			strokeLinejoin: "round",
			strokeLinecap: "round",
			children: n
		})
	});
}
function De({ text: e }) {
	let t = o();
	return /* @__PURE__ */ p(f, { children: e.split(/(\[[a-z]+\])/g).map((e, n) => e === "[keep]" ? /* @__PURE__ */ p("strong", { children: t("games.tokyobay.keep") }, n) : e.startsWith("[") ? /* @__PURE__ */ p(G, { kind: e.slice(1, -1) }, n) : e) });
}
var K = (e) => `games/tokyobay/${e}.webp`;
function Oe() {
	return /* @__PURE__ */ p("svg", {
		className: "tb-legal-edge",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ p("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "9",
			pathLength: "100"
		})
	});
}
//#endregion
//#region src/games/tokyobay/labels.ts
var q = {
	smash: "games.tokyobay.smash",
	heal: "games.tokyobay.heal",
	energy: "games.tokyobay.energy",
	special: "games.tokyobay.special",
	fame: "games.tokyobay.fame",
	destruction: "games.tokyobay.destruction"
}, ke = {
	effectOrder: "games.tokyobay.effectOrder",
	pass: "games.tokyobay.pass",
	finish: "games.tokyobay.finish",
	finishForecast: "games.tokyobay.gainEnergy",
	gainEnergy: "games.tokyobay.gainEnergy",
	refresh: "games.tokyobay.refresh",
	decline: "games.tokyobay.decline",
	gigarex1: "games.tokyobay.gigarex1",
	gigarex3: "games.tokyobay.gigarex3",
	shieldMode: "games.tokyobay.shieldMode",
	exchange: "games.tokyobay.exchange",
	shield: "games.tokyobay.shield",
	takeSupport: "games.tokyobay.takeSupport",
	tentacleSelf: "games.tokyobay.tentacleSelf",
	tentacleRival: "games.tokyobay.tentacleRival",
	missile: "games.tokyobay.missile",
	artificer: "games.tokyobay.artificer",
	pillage: "games.tokyobay.pillage",
	discard: "games.tokyobay.discard",
	keepCard: "games.tokyobay.keepCard",
	returnDebris: "games.tokyobay.returnDebris",
	replace: "games.tokyobay.replace",
	offer: "games.tokyobay.offer",
	nightVision: "games.tokyobay.nightVision",
	change: "games.tokyobay.change",
	cancelCard: "games.tokyobay.discard",
	cardEffect: "games.tokyobay.activate",
	track: "games.tokyobay.pull"
}, Ae = {
	chooseMonster: "games.tokyobay.chooseMonster",
	roll: "games.tokyobay.rollHint",
	resolve: "games.tokyobay.resolve",
	support: "games.tokyobay.support",
	market: "games.tokyobay.market",
	activate: "games.tokyobay.activate",
	damageChoice: "games.tokyobay.damageChoice",
	nightVision: "games.tokyobay.nightVision",
	pillage: "games.tokyobay.pillagePrompt",
	returnDebris: "games.tokyobay.returnDebris",
	choose: "games.tokyobay.choose",
	artificer: "games.tokyobay.artificer",
	discard: "games.tokyobay.discard",
	offer: "games.tokyobay.offer",
	replace: "games.tokyobay.chooseMarket",
	change: "games.tokyobay.change",
	react: "games.tokyobay.react",
	draft: "games.tokyobay.chooseMonster",
	done: "games.tokyobay.done"
}, je = {
	ko: "games.tokyobay.ko",
	tracksWin: "games.tokyobay.tracksWin",
	captureWin: "games.tokyobay.captureWin",
	cardWin: "games.tokyobay.cardWin",
	lastChanceWin: "games.tokyobay.lastChanceWin",
	draw: "games.tokyobay.draw"
};
//#endregion
//#region src/games/tokyobay/view-player.tsx
function J({ card: e, compact: t = !1, onClick: n, selected: r = !1, price: i }) {
	let a = o(), s = x[e], { ref: c, hidden: l } = d(`tokyo-card:${e}:${t ? "market" : "detail"}`);
	return /* @__PURE__ */ m("button", {
		type: "button",
		ref: c,
		style: { visibility: l ? "hidden" : void 0 },
		className: `tb-card${t ? " tb-card-compact" : ""}${r ? " tb-selected" : ""}`,
		onClick: n,
		"aria-label": a(S[e].name),
		children: [
			/* @__PURE__ */ p("img", {
				className: "tb-card-art",
				src: K(`power-${e}`),
				alt: ""
			}),
			/* @__PURE__ */ m("span", {
				className: "tb-card-cost",
				children: [/* @__PURE__ */ p("b", { children: i ?? (s.cost === -1 ? "X" : s.cost === -2 ? "3/8" : s.cost) }), /* @__PURE__ */ p(G, { kind: "energy" })]
			}),
			/* @__PURE__ */ p("span", {
				className: "tb-card-name",
				children: a(S[e].name)
			}),
			/* @__PURE__ */ p("span", {
				className: `tb-card-type tb-${s.type}`,
				children: a(s.type === "discard" ? "games.tokyobay.discardType" : s.type === "reactive" ? "games.tokyobay.reactive" : "games.tokyobay.keepType")
			}),
			!t && /* @__PURE__ */ p("span", {
				className: "tb-card-text",
				children: /* @__PURE__ */ p(De, { text: a(S[e].text) })
			})
		]
	});
}
function Y(e, t, n, r) {
	let i = e.find((e) => e.rid === t), a = c[(i?.colorIndex ?? n) % c.length];
	return {
		name: i?.name || r(a.nameKey),
		color: a.hex,
		avatar: s[(i?.avatar ?? n) % s.length]
	};
}
function Me({ anchor: e, ...t }) {
	let { ref: n, hidden: r } = d(e);
	return /* @__PURE__ */ p("span", {
		ref: n,
		...t,
		style: {
			...t.style,
			visibility: r ? "hidden" : t.style?.visibility
		}
	});
}
function Ne({ anchor: e, ...t }) {
	let { ref: n, hidden: r } = d(e);
	return /* @__PURE__ */ p("button", {
		type: "button",
		ref: n,
		...t,
		style: {
			...t.style,
			visibility: r ? "hidden" : t.style?.visibility
		}
	});
}
function Pe({ v: e, p: t, members: n, openCards: r, openMonster: i }) {
	let a = o(), s = e.seats[t], c = Y(n, e.players[t], t, a), { ref: l } = d(`tokyo-seat:${e.players[t]}`), { ref: ee } = d(`tokyo-keeps:${e.players[t]}`), { ref: h } = d(`tokyo-capture:${e.players[t]}`);
	return /* @__PURE__ */ m("section", {
		ref: l,
		className: `tb-player tb-player-${t}${e.turn === t ? " tb-current" : ""}`,
		style: { "--player": c.color },
		children: [/* @__PURE__ */ m("div", {
			className: "tb-identity",
			children: [/* @__PURE__ */ p("img", {
				src: c.avatar,
				alt: ""
			}), /* @__PURE__ */ p("b", { children: c.name })]
		}), s.monster >= 0 && /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p("img", {
				className: "tb-monster-art",
				src: K(`monster-${s.monster}`),
				alt: ""
			}),
			/* @__PURE__ */ p("h2", { children: /* @__PURE__ */ p("button", {
				type: "button",
				className: "tb-monster-details",
				onClick: i,
				children: y[s.monster]
			}) }),
			/* @__PURE__ */ m("div", {
				className: "tb-resources",
				children: [
					/* @__PURE__ */ m("span", {
						title: a("games.tokyobay.health"),
						children: [
							/* @__PURE__ */ p(G, { kind: "heal" }),
							/* @__PURE__ */ p("b", { children: /* @__PURE__ */ p(u, { value: s.hp }) }),
							/* @__PURE__ */ m("small", { children: ["/", s.maxHp] })
						]
					}),
					/* @__PURE__ */ m("span", {
						title: a("games.tokyobay.energy"),
						children: [/* @__PURE__ */ p(G, { kind: "energy" }), /* @__PURE__ */ p("b", { children: /* @__PURE__ */ p(u, { value: s.energy }) })]
					}),
					/* @__PURE__ */ m("span", {
						title: a("games.tokyobay.token"),
						children: [/* @__PURE__ */ p(G, { kind: "token" }), /* @__PURE__ */ p("b", { children: s.tokens })]
					})
				]
			}),
			/* @__PURE__ */ p("div", {
				ref: h,
				className: "tb-captured",
				title: a("games.tokyobay.captured"),
				children: [
					0,
					1,
					2
				].map((n) => /* @__PURE__ */ m(Me, {
					anchor: `tokyo-capture:${e.players[t]}:${n}`,
					className: s.captured.length > n ? "tb-filled" : "",
					children: [/* @__PURE__ */ p(G, { kind: "capture" }), s.captured[n] !== void 0 && /* @__PURE__ */ p(G, { kind: C[s.captured[n]] === "token" ? "token" : C[s.captured[n]] })]
				}, n))
			}),
			/* @__PURE__ */ p("p", {
				className: "tb-monster-power",
				children: a(re[s.monster])
			}),
			/* @__PURE__ */ m("div", {
				className: "tb-monster-tokens",
				children: [
					s.monster === 0 && /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p(G, { kind: s.protocol === 0 ? "special" : s.protocol === 1 ? "damage" : s.protocol === 2 ? "token" : "fame" }), a("games.tokyobay.protocol")] }),
					s.monster === 3 && /* @__PURE__ */ m("span", { children: [
						/* @__PURE__ */ p(G, { kind: "shield" }),
						s.shields,
						" / 4"
					] }),
					s.monster === 5 && /* @__PURE__ */ m("span", { children: [
						/* @__PURE__ */ p(G, { kind: "special" }),
						a("games.tokyobay.fanTokens"),
						" ",
						s.fans.length
					] }),
					s.tentacles.map((e) => /* @__PURE__ */ m("span", {
						className: e >= 3 ? "tb-locked" : "",
						children: [/* @__PURE__ */ p(G, { kind: [
							"heal",
							"smash",
							"fame"
						][e % 3] }), e >= 3 ? "×" : "↻"]
					}, e))
				]
			}),
			/* @__PURE__ */ m("button", {
				ref: ee,
				className: "tb-keeps",
				type: "button",
				onClick: r,
				children: [
					a("games.tokyobay.viewCards"),
					" ",
					/* @__PURE__ */ p("b", { children: s.cards.length })
				]
			}),
			e.supportMode && /* @__PURE__ */ p("div", {
				className: "tb-support-set",
				children: s.support.map((n, r) => /* @__PURE__ */ m(Me, {
					anchor: `tokyo-support:${e.players[t]}:${r}`,
					className: `tb-support-status-${n}`,
					title: a(n === 2 ? "games.tokyobay.supportSpent" : n === 1 ? "games.tokyobay.pendingSupport" : "games.tokyobay.supportReady"),
					children: [/* @__PURE__ */ p(G, { kind: v[r] }), n === 2 && /* @__PURE__ */ p("small", { children: "×" })]
				}, r))
			})
		] })]
	});
}
function Fe({ v: e, index: t, choose: n, canAct: r }) {
	let i = o(), a = e.tracks[t], s = t === 0 ? "fame" : "destruction", { ref: c } = d(`tokyo-track:${t}`), l = (n) => e.choices.findIndex((e) => e.kind === "tile" && e.track === t && e.tile === n), u = e.choices.findIndex((e) => e.kind === "track" && e.track === t);
	return /* @__PURE__ */ m("div", {
		ref: c,
		className: `tb-track tb-track-${s}`,
		children: [/* @__PURE__ */ m("div", {
			className: "tb-track-heading",
			children: [
				/* @__PURE__ */ p(G, { kind: s }),
				/* @__PURE__ */ p("b", { children: i(q[s]) }),
				u >= 0 && r && /* @__PURE__ */ p("button", {
					type: "button",
					className: "tb-action",
					onClick: () => n(u),
					children: i("games.tokyobay.pull", { face: i(q[s]) })
				})
			]
		}), /* @__PURE__ */ m("div", {
			className: "tb-track-line",
			children: [
				/* @__PURE__ */ p("span", {
					className: "tb-victory-zone",
					children: /* @__PURE__ */ p(G, { kind: "crown" })
				}),
				/* @__PURE__ */ p("div", {
					className: "tb-water",
					children: /* @__PURE__ */ p("svg", {
						viewBox: "0 0 120 40",
						preserveAspectRatio: "none",
						"aria-hidden": "true",
						children: /* @__PURE__ */ p("path", { d: "M0 18q15-9 30 0t30 0t30 0t30 0M0 29q15-9 30 0t30 0t30 0t30 0" })
					})
				}),
				/* @__PURE__ */ m("div", {
					className: "tb-track-tiles",
					children: [a.tiles.map((e, t) => {
						let o = l(e), c = o >= 0 && r;
						return /* @__PURE__ */ m(Ne, {
							anchor: `tokyo-tile:${e}`,
							className: `tb-debris${e === -1 ? " tb-starting" : ""}${c ? " tb-legal" : ""}`,
							style: { left: `${(5 - a.tiles.length) * 10 + t * 20}%` },
							disabled: !c,
							"aria-label": e === -1 ? i(q[s]) : `${i(q[s])} · ${i(C[e] === "token" ? "games.tokyobay.token" : q[C[e]])}`,
							onClick: () => n(o),
							children: [c && /* @__PURE__ */ p(Oe, {}), e === -1 ? /* @__PURE__ */ p(G, { kind: s }) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { className: "tb-slab-line" }), /* @__PURE__ */ p(G, { kind: C[e] })] })]
						}, e);
					}), /* @__PURE__ */ p("span", {
						className: "tb-marker",
						style: { left: `${(5 - a.tiles.length) * 10 + a.marker * 20 + 10}%` },
						"aria-label": i(q[s]),
						children: /* @__PURE__ */ p(G, { kind: s })
					})]
				}),
				/* @__PURE__ */ p("span", {
					className: "tb-victory-zone tb-zone-right",
					children: /* @__PURE__ */ p(G, { kind: "crown" })
				})
			]
		})]
	});
}
function Ie({ index: e, ...t }) {
	let { ref: n, hidden: r } = d(`tokyo-die:${e}`);
	return /* @__PURE__ */ p("button", {
		type: "button",
		ref: n,
		...t,
		style: {
			...t.style,
			visibility: r ? "hidden" : t.style?.visibility
		}
	});
}
function Le({ v: e, canAct: t, indices: n, setIndices: r, choose: i }) {
	let a = o(), { ref: s } = d("tokyo-dice");
	return /* @__PURE__ */ p("div", {
		ref: s,
		className: "tb-dice-tray",
		children: (e.dice.length ? e.dice : Array.from({ length: e.round === 1 ? 5 : 6 }, () => null)).map((o, s) => {
			let c = e.choices.findIndex((e) => e.kind === "resolve" && e.face === o), l = e.phase === "roll" && e.rolls > 0 && e.canReroll[s], u = t && (l || c >= 0);
			return /* @__PURE__ */ m(Ie, {
				index: s,
				className: `tb-die${n.includes(s) && l ? " tb-die-selected" : ""}${o && e.phase !== "roll" && e.resolved.includes(o) ? " tb-die-resolved" : ""}${u ? " tb-legal" : ""}${e.diceSources[s] === "extra" ? " tb-extra-die" : e.diceSources[s] === "support" ? " tb-support-die" : e.diceSources[s] === "card" ? " tb-card-die" : ""}`,
				disabled: !u,
				onClick: () => c >= 0 ? i(c) : r(n.includes(s) ? n.filter((e) => e !== s) : [...n, s]),
				"aria-label": o ? l ? `${a(q[o])} · ${a("games.tokyobay.reroll")}` : a("games.tokyobay.resolveFace", { face: a(q[o]) }) : a("games.tokyobay.firstRoll"),
				"aria-pressed": l ? n.includes(s) : void 0,
				children: [
					u && /* @__PURE__ */ p(Oe, {}),
					o ? /* @__PURE__ */ p(G, { kind: o }) : /* @__PURE__ */ p("span", { children: "?" }),
					e.phase === "roll" && e.rolls > 0 && !e.canReroll[s] && /* @__PURE__ */ p("small", { children: "×" })
				]
			}, s);
		})
	});
}
var Re = {
	Roll: "games.tokyobay.eventRoll",
	Heal: "games.tokyobay.eventHeal",
	Energy: "games.tokyobay.eventEnergy",
	Damage: "games.tokyobay.eventDamage",
	Pull: "games.tokyobay.eventPull",
	Capture: "games.tokyobay.eventCapture",
	Buy: "games.tokyobay.eventBuy",
	Special: "games.tokyobay.eventSpecial",
	Other: "games.tokyobay.eventOther",
	Initiative: "games.tokyobay.logInitiative",
	Card: "games.tokyobay.logCard",
	Fish: "games.tokyobay.logFish",
	ReactionDie: "games.tokyobay.logReactionDie",
	Market: "games.tokyobay.logMarket",
	Tile: "games.tokyobay.logTile",
	Discard: "games.tokyobay.logDiscard",
	Fan: "games.tokyobay.logFan",
	Support: "games.tokyobay.logSupport",
	ReturnCard: "games.tokyobay.logReturnCard"
};
function ze(e) {
	return /* @__PURE__ */ p(Be, { ...e });
}
function Be(e) {
	let t = o(), n = e.public, r = e.private?.canAct === !0 && !n.busy && n.phase !== "done", [s, c] = i({
		scope: "",
		indices: []
	}), u = `${e.myRid}:${n.round}:${n.phase}:${n.rolls}`, h = s.scope === u ? s.indices.filter((e) => n.canReroll[e]) : [], g = (e) => c({
		scope: u,
		indices: e
	}), [te, ne] = i(0), [_, w] = i(null), [T, E] = i(null), [D, O] = i(0), k = (t) => {
		r && t >= 0 && e.send({
			type: "choose",
			index: t
		});
	}, A = (r) => Y(e.members, n.players[r], r, t), ie = (e) => e.kind === "fan" ? t([
		"games.tokyobay.fan0",
		"games.tokyobay.fan1",
		"games.tokyobay.fan2",
		"games.tokyobay.fan3"
	][e.n]) : t(ke[e.kind] ?? "games.tokyobay.choose", {
		n: e.n,
		damage: e.tile,
		face: e.face ? t(q[e.face]) : "",
		name: A(n.actor).name
	}), j = _ === null ? [] : n.choices.map((e, t) => ({
		c: e,
		i: t
	})).filter(({ c: e }) => e.card === _ && [
		"buy",
		"cardEffect",
		"discard",
		"cancelCard",
		"offer",
		"replace"
	].includes(e.kind)), { ref: M } = d("tokyo-market"), { ref: N } = d("tokyo-deck"), { ref: P } = d("tokyo-debris"), { ref: F } = d("tokyo-arena"), { ref: I, hidden: L } = d("tokyo-reveal"), R = (e) => {
		O(e), E("cards");
	}, z = t(Ae[n.prompt] ?? "games.tokyobay.choose"), B = n.choices.map((e, t) => ({
		c: e,
		i: t
	})).filter(({ c: e }) => ![
		"monster",
		"buy",
		"resolve",
		"track",
		"tile"
	].includes(e.kind)), V = (e) => {
		k(e), E(null);
	}, H = /* @__PURE__ */ m("div", {
		className: "tb-actions",
		children: [/* @__PURE__ */ m("div", {
			className: "tb-action-prompt",
			children: [/* @__PURE__ */ p("b", { children: n.phase === "done" ? t("games.tokyobay.done") : r ? z : t("games.tokyobay.turnWaiting", { name: A(n.actor).name }) }), n.phase === "roll" && n.rolls > 0 && /* @__PURE__ */ p("small", { children: t("games.tokyobay.rolls", {
				n: n.rolls,
				total: n.rollLimit
			}) })]
		}), /* @__PURE__ */ p("div", {
			className: "tb-choice-scroll",
			children: n.phase === "roll" ? /* @__PURE__ */ p("div", {
				className: "tb-roll-actions",
				children: n.rolls === 0 ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("div", {
					className: "tb-extra-tokens",
					children: Array.from({ length: n.extraLimit + 1 }, (e, i) => /* @__PURE__ */ m("button", {
						type: "button",
						className: Math.min(te, n.extraLimit) === i ? "tb-selected" : "",
						disabled: !r,
						"aria-label": t("games.tokyobay.extra", { n: i }),
						onClick: () => ne(i),
						children: [/* @__PURE__ */ p(G, { kind: "token" }), i]
					}, i))
				}), /* @__PURE__ */ p("button", {
					className: "tb-action tb-primary",
					type: "button",
					disabled: !r,
					onClick: () => e.send({
						type: "roll",
						dice: [],
						extra: Math.min(te, n.extraLimit)
					}),
					children: t("games.tokyobay.roll")
				})] }) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("button", {
					className: "tb-action",
					disabled: !r || !h.length,
					type: "button",
					onClick: () => {
						e.send({
							type: "roll",
							dice: h,
							extra: 0
						}), g([]);
					},
					children: t("games.tokyobay.reroll")
				}), /* @__PURE__ */ p("button", {
					className: "tb-action tb-primary",
					type: "button",
					disabled: !r,
					onClick: () => e.send({ type: "stop" }),
					children: t("games.tokyobay.stop")
				})] })
			}) : B.map(({ c: e, i: n }) => /* @__PURE__ */ m("button", {
				type: "button",
				className: `tb-choice${[
					"finish",
					"gainEnergy",
					"finishForecast"
				].includes(e.kind) ? " tb-primary" : ""}`,
				disabled: !r,
				onClick: () => k(n),
				children: [
					e.card >= 0 && /* @__PURE__ */ p("img", {
						src: K(`power-${e.card}`),
						alt: ""
					}),
					e.tile >= 0 && ["nightVision", "returnDebris"].includes(e.kind) && /* @__PURE__ */ p(G, { kind: C[e.tile] }),
					/* @__PURE__ */ m("span", { children: [e.card >= 0 && /* @__PURE__ */ p("b", { children: t(S[e.card].name) }), ie(e)] }),
					e.face && /* @__PURE__ */ p(G, { kind: e.face })
				]
			}, `${e.kind}:${e.card}:${e.n}:${e.tile}:${e.face}`))
		})]
	});
	return /* @__PURE__ */ m("div", {
		className: "tb-game",
		children: [/* @__PURE__ */ m(ee, {
			adaptive: !0,
			scroll: !1,
			className: "tb-screen",
			actionsHeight: "tb-footer-size",
			actions: H,
			banner: /* @__PURE__ */ m("header", {
				className: "tb-header",
				children: [/* @__PURE__ */ m("div", {
					className: "tb-title",
					children: [/* @__PURE__ */ p("span", { children: "KING OF TOKYO · DUEL" }), /* @__PURE__ */ p("strong", { children: "TOKYO BAY" })]
				}), /* @__PURE__ */ p("div", {
					className: "tb-turn",
					children: /* @__PURE__ */ p("span", { children: t("games.tokyobay.round", { n: Math.max(1, n.round) }) })
				})]
			}),
			children: [/* @__PURE__ */ m("div", {
				className: "tb-table",
				children: [
					/* @__PURE__ */ p(Pe, {
						v: n,
						p: 0,
						members: e.members,
						openCards: () => R(0),
						openMonster: () => {
							O(0), E("monster");
						}
					}),
					/* @__PURE__ */ m("main", {
						ref: F,
						className: "tb-arena",
						children: [
							/* @__PURE__ */ m("div", {
								className: "tb-direction",
								children: [/* @__PURE__ */ m("span", {
									style: { color: A(0).color },
									children: ["← ", A(0).name]
								}), /* @__PURE__ */ m("span", {
									style: { color: A(1).color },
									children: [A(1).name, " →"]
								})]
							}),
							/* @__PURE__ */ m("div", {
								className: "tb-bay",
								children: [/* @__PURE__ */ p(Fe, {
									v: n,
									index: 0,
									choose: k,
									canAct: r
								}), /* @__PURE__ */ p(Fe, {
									v: n,
									index: 1,
									choose: k,
									canAct: r
								})]
							}),
							/* @__PURE__ */ p("div", {
								className: "tb-market",
								ref: M,
								children: n.market.map((e, t) => /* @__PURE__ */ m("div", {
									className: "tb-market-slot",
									style: { left: `${t * 100 / 3}%` },
									children: [/* @__PURE__ */ p(J, {
										card: e,
										compact: !0,
										selected: _ === e && T === "card",
										price: n.prices[t],
										onClick: () => {
											w(e), E("card");
										}
									}), r && n.phase === "market" && n.choices.some((t) => t.kind === "buy" && t.card === e) && /* @__PURE__ */ m("span", {
										className: "tb-buy-mark",
										children: [/* @__PURE__ */ p(G, { kind: "energy" }), n.prices[t]]
									})]
								}, e))
							}),
							/* @__PURE__ */ p(Le, {
								v: n,
								canAct: r,
								indices: h,
								setIndices: g,
								choose: k
							}),
							/* @__PURE__ */ m("div", {
								className: "tb-table-tools",
								children: [
									/* @__PURE__ */ m("span", {
										ref: P,
										children: [/* @__PURE__ */ p(G, { kind: "capture" }), n.debrisCount]
									}),
									/* @__PURE__ */ m("span", {
										ref: N,
										children: [
											/* @__PURE__ */ p("span", { className: "tb-deck-back" }),
											t("games.tokyobay.deck"),
											" ",
											n.deckCount
										]
									}),
									/* @__PURE__ */ p("button", {
										type: "button",
										onClick: () => E("log"),
										children: t("games.tokyobay.log")
									})
								]
							}),
							/* @__PURE__ */ p("div", {
								ref: I,
								style: { visibility: L ? "hidden" : void 0 },
								className: `tb-reveal${n.revealCard < 0 ? " tb-reveal-empty" : ""}`,
								"aria-hidden": n.revealCard < 0,
								children: n.revealCard >= 0 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("div", {
									className: "tb-fishing-fan",
									children: n.fishingCards.map((e) => /* @__PURE__ */ p("img", {
										src: K(`power-${e}`),
										alt: t(S[e].name)
									}, e))
								}), /* @__PURE__ */ p(J, {
									card: n.revealCard,
									onClick: () => {
										w(n.revealCard), E("card");
									}
								})] })
							})
						]
					}),
					/* @__PURE__ */ p(Pe, {
						v: n,
						p: 1,
						members: e.members,
						openCards: () => R(1),
						openMonster: () => {
							O(1), E("monster");
						}
					})
				]
			}), n.phase === "draft" && /* @__PURE__ */ m("div", {
				className: "tb-draft",
				children: [
					/* @__PURE__ */ p("h1", { children: t("games.tokyobay.chooseMonster") }),
					/* @__PURE__ */ p("p", { children: A(n.actor).name }),
					/* @__PURE__ */ p("div", {
						className: "tb-monster-grid",
						children: n.choices.map((e, n) => /* @__PURE__ */ m("button", {
							type: "button",
							disabled: !r,
							onClick: () => k(n),
							children: [
								/* @__PURE__ */ p("img", {
									src: K(`monster-${e.monster}`),
									alt: ""
								}),
								/* @__PURE__ */ p("strong", { children: y[e.monster] }),
								/* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p(G, { kind: "heal" }), b[e.monster]] }),
								/* @__PURE__ */ p("p", { children: t(re[e.monster]) })
							]
						}, e.monster))
					})
				]
			})]
		}), a(/* @__PURE__ */ p(l, {
			open: T !== null,
			onClose: () => E(null),
			label: t(T === "log" ? "games.tokyobay.log" : T === "cards" ? "games.tokyobay.viewCards" : T === "monster" ? "games.tokyobay.monsterDetail" : "games.tokyobay.cardDetail"),
			title: T === "cards" ? t("games.tokyobay.yourCards", { name: A(D).name }) : t(T === "log" ? "games.tokyobay.log" : T === "monster" ? "games.tokyobay.monsterDetail" : "games.tokyobay.cardDetail"),
			footer: T === "card" && j.length > 0 ? /* @__PURE__ */ p("div", {
				className: "tb-sheet-actions",
				children: j.map(({ c: e, i: n }) => /* @__PURE__ */ p("button", {
					className: "tb-action tb-primary",
					type: "button",
					disabled: !r,
					onClick: () => V(n),
					children: e.kind === "buy" ? e.card === 46 ? t("games.tokyobay.buySecret", {
						n: e.n,
						power: e.tile === 8 ? 6 : 2
					}) : t("games.tokyobay.buy", { n: e.n }) : ie(e)
				}, n))
			}) : void 0,
			children: /* @__PURE__ */ m("div", {
				className: "tb-sheet",
				children: [
					T === "card" && _ !== null && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(J, { card: _ }), /* @__PURE__ */ m("div", {
						className: "tb-fishing",
						children: [/* @__PURE__ */ p("b", { children: t("games.tokyobay.fished") }), x[_].fish.every((e) => !e) ? /* @__PURE__ */ p("span", { children: t("games.tokyobay.noEffect") }) : x[_].fish.map((e, t) => e > 0 ? /* @__PURE__ */ p("span", { children: t === 4 ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(G, { kind: "fame" }), /* @__PURE__ */ p(G, { kind: "destruction" })] }) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(G, { kind: [
							"damage",
							"heal",
							"energy",
							"token"
						][t] }), e] }) }, t) : null)]
					})] }),
					T === "cards" && (n.seats[D].cards.length ? /* @__PURE__ */ p("div", {
						className: "tb-card-list",
						children: n.seats[D].cards.map((e) => /* @__PURE__ */ p(J, {
							card: e,
							onClick: () => {
								w(e), E("card");
							}
						}, e))
					}) : /* @__PURE__ */ p("p", { children: t("games.tokyobay.noCards") })),
					T === "monster" && n.seats[D].monster >= 0 && /* @__PURE__ */ m("div", {
						className: "tb-monster-sheet",
						children: [
							/* @__PURE__ */ p("img", {
								src: K(`monster-${n.seats[D].monster}`),
								alt: ""
							}),
							/* @__PURE__ */ p("h2", { children: y[n.seats[D].monster] }),
							/* @__PURE__ */ p("p", { children: t(re[n.seats[D].monster]) }),
							/* @__PURE__ */ m("div", { children: [
								n.seats[D].monster === 0 && /* @__PURE__ */ m("p", { children: [
									t("games.tokyobay.protocol"),
									" ",
									/* @__PURE__ */ p(G, { kind: n.seats[D].protocol === 0 ? "special" : n.seats[D].protocol === 1 ? "damage" : n.seats[D].protocol === 2 ? "token" : "fame" })
								] }),
								n.seats[D].monster === 3 && /* @__PURE__ */ m("p", { children: [
									/* @__PURE__ */ p(G, { kind: "shield" }),
									n.seats[D].shields,
									" / 4"
								] }),
								n.seats[D].tentacles.map((e) => /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p(G, { kind: [
									"heal",
									"smash",
									"fame"
								][e % 3] }), e >= 3 ? "×" : "↻"] }, e))
							] }),
							n.supportMode && /* @__PURE__ */ p("div", {
								className: "tb-monster-support",
								children: n.seats[D].support.map((e, n) => /* @__PURE__ */ m("p", { children: [/* @__PURE__ */ p(G, { kind: v[n] }), t(e === 2 ? "games.tokyobay.supportSpent" : e === 1 ? "games.tokyobay.pendingSupport" : "games.tokyobay.supportReady")] }, n))
							})
						]
					}),
					T === "log" && /* @__PURE__ */ p("ol", {
						className: "tb-log",
						children: n.log.map((e, n) => /* @__PURE__ */ m("li", { children: [
							t(Re[e.kind] ?? "games.tokyobay.eventOther", {
								name: A(e.seat).name,
								n: e.n
							}),
							e.card >= 0 && [
								"Buy",
								"Card",
								"Fish"
							].includes(e.kind) && /* @__PURE__ */ m(f, { children: [" · ", t(S[e.card].name)] }),
							e.kind === "ReactionDie" && /* @__PURE__ */ p(G, { kind: v[e.n] })
						] }, n))
					})
				]
			})
		}), document.body)]
	});
}
//#endregion
//#region src/games/tokyobay/bot.ts
var Ve = {
	attack: 1.25,
	heal: 1.05,
	special: 1.6,
	track: 2.5,
	energy: .7
}, X = (e, t) => e.filter((e) => e === t).length;
function Z(e, t, n) {
	let r = e.tracks[n], i = t === 0 ? r.marker : r.tiles.length - 1 - r.marker;
	return (r.tiles.length === 5 && i === 0 ? 4 : 1.5) / (1 + i * .35);
}
function He(e, t, n) {
	let r = e.actor, i = e.seats[r], a = e.seats[1 - r], o = i.maxHp - i.hp;
	if (t.kind === "monster") return [
		2,
		3,
		2.5,
		3,
		2,
		1
	][t.monster];
	if (t.kind === "shield") return t.n * 2;
	if (t.kind === "buy") {
		let n = [
			4,
			i.captured.length ? 8 : -10,
			6,
			1,
			4,
			4,
			5,
			7,
			3,
			3,
			i.cards.length >= 6 ? 50 : 4,
			11,
			5,
			5,
			5,
			6,
			i.hp > 10 ? 6 : -5,
			10,
			5,
			5,
			6,
			7,
			i.captured.length >= 2 && i.hp < a.hp ? 50 : 5,
			5,
			i.hp > 5 ? 5 : -8,
			i.energy >= 18 ? 50 : 6,
			5,
			6,
			i.captured.length > 0 ? 2 : 1,
			8,
			4,
			4,
			6,
			8,
			4,
			5,
			4,
			4,
			4,
			3,
			4,
			4,
			3,
			8,
			4,
			5,
			5,
			o > 3 ? 6 : 1,
			8,
			5
		];
		if (t.card === 1 && !i.captured.length) return -20;
		let r = t.card === 44 ? X(e.dice, "special") : t.card === 43 ? e.tracks.reduce((e, t) => e + t.tiles.length - 1, 0) : 0;
		return r >= a.hp && (t.card !== 43 || i.hp > r) ? 100 : n[t.card] - t.n * .85 - .5;
	}
	if (t.kind === "refresh") return i.energy >= 8 ? -.5 : -8;
	if ([
		"finish",
		"gainEnergy",
		"finishForecast",
		"pass",
		"decline"
	].includes(t.kind)) return 0;
	if (t.kind === "resolve") return t.face === "smash" ? t.n >= a.hp ? 100 : 4 : t.face === "heal" ? o ? 5 : 1 : t.face === "special" ? 3 : t.face === "energy" ? 2 : Z(e, r, t.face === "fame" ? 0 : 1) * t.n;
	if (t.kind === "change") {
		let n = X(e.dice, t.face);
		return n === 2 ? 9 : n >= 3 ? 6 : 0;
	}
	if (t.kind === "cardEffect") return t.card === 24 ? o ? 8 : 0 : t.card === 25 ? 5 : 7;
	if (t.kind === "takeSupport") return t.face === "smash" ? n.attack * 1.5 : t.face === "heal" ? i.hp < 6 ? 3 : .5 : t.face === "special" ? n.special : t.face === "energy" ? n.energy : t.face === "fame" ? Z(e, r, 0) : Z(e, r, 1);
	if (t.kind === "gigarex3") return i.hp > 1 ? 5 : -10;
	if (t.kind === "gigarex1") return i.hp > a.hp || a.hp === 1 ? 2 : -5;
	if (t.kind === "exchange") return t.tile >= a.hp ? 100 : t.n * n.energy + t.tile * n.attack - i.shields * .9;
	if (t.kind === "shieldMode") return i.shields < 3 ? 6 : 1;
	if (t.kind === "tentacleRival") return t.face === "heal" ? 4 : 2;
	if (t.kind === "tentacleSelf") return t.face === "fame" ? 3 : 1;
	if (t.kind === "fan") return 3;
	if (t.kind === "missile") return 4;
	if (t.kind === "artificer") return i.hp > 6 || i.cards.includes(33) ? 3 : -5;
	if (t.kind === "cancelCard") return X(e.dice, t.card === 30 ? "smash" : "heal") * (t.card === 30 ? n.attack : n.heal) - 1.2;
	if (t.kind === "discard") return t.card === 16 ? 10 : 50 - (t.card === 33 ? 20 : t.card === 29 ? 15 : t.card === 14 ? 10 : t.card === 24 ? 8 : 5);
	if (t.kind === "keepCard") return i.cards.length < 2 || i.hp < 4 ? 2 : 6;
	if (t.kind === "track") return Z(e, r, t.track);
	if (t.kind === "nightVision" || t.kind === "returnDebris") {
		let e = t.tile < 3 ? "special" : t.tile < 6 ? "heal" : t.tile < 10 ? "energy" : "smash";
		return (t.kind === "returnDebris" ? -1 : 1) * (e === "heal" ? Math.min(1, o) * 2 : e === "smash" ? n.attack : 1);
	}
	return t.kind === "pillage" ? t.face === "heal" ? -(Math.min(3, a.maxHp - a.hp) * 1.5) : t.face === "destruction" ? -3 : -1 : 1;
}
function Ue(e = Ve) {
	return (t, n) => {
		let r = t.public;
		if (!t.private?.canAct || r.players[r.actor] !== n.rid || r.busy || r.phase === "done") return null;
		if (r.choices.length) return { action: {
			type: "choose",
			index: r.choices.map((t, n) => ({
				index: n,
				value: He(r, t, e)
			})).sort((e, t) => t.value - e.value || e.index - t.index)[0].index
		} };
		if (r.phase !== "roll") return null;
		if (!r.rolls) return { action: {
			type: "roll",
			dice: [],
			extra: r.extraLimit
		} };
		let i = r.seats[r.turn], a = r.seats[1 - r.turn], o = i.maxHp - i.hp, s = r.dice.map((e, t) => t).filter((e) => r.canReroll[e]);
		if (!s.length) return { action: { type: "stop" } };
		let c = v.map((t) => {
			let n = X(r.dice, t) + s.filter((e) => r.dice[e] !== t).length * (1 - (5 / 6) ** Math.max(1, r.rollLimit - r.rolls)), c = 0;
			return t === "smash" && (c = n * e.attack + (n >= a.hp ? 8 : 0)), t === "heal" && (c = Math.min(o, n) * e.heal * (i.hp < 6 ? 1.8 : 1)), t === "energy" && (c = n * e.energy), t === "special" && (c = n * e.special * (i.monster === 1 && i.hp <= 3 ? .3 : 1)), (t === "fame" || t === "destruction") && (c = Math.max(0, n - 2 - Number(a.cards.includes(21))) * e.track * Z(r, r.turn, t === "fame" ? 0 : 1)), {
				face: t,
				value: c
			};
		}).sort((e, t) => t.value - e.value), l = n.difficulty === "weak" ? "smash" : c[0].face, u = s.filter((e) => r.dice[e] !== l && !(r.dice[e] === "heal" && o >= 3 && i.hp < 5) && !(r.dice[e] === "energy" && i.energy < 2 && l !== "fame" && l !== "destruction"));
		return { action: u.length ? {
			type: "roll",
			dice: u,
			extra: 0
		} : { type: "stop" } };
	};
}
var We = Ue();
//#endregion
//#region src/games/tokyobay/fx.tsx
function Ge({ card: e }) {
	let t = o();
	return /* @__PURE__ */ m("div", {
		className: "tb-fx-card",
		children: [/* @__PURE__ */ p("img", {
			src: K(`power-${e}`),
			alt: ""
		}), /* @__PURE__ */ p("b", { children: t(S[e].name) })]
	});
}
function Q({ from: e, to: t, ms: i, card: a }) {
	let o = r(null);
	return n(() => {
		let n = t.x - e.x, r = t.y - e.y, a = o.current?.animate([
			{
				width: `${e.w}px`,
				height: `${e.h}px`,
				fontSize: `${e.w * .085}px`,
				transform: "translate(0,0)"
			},
			{
				width: `${e.w + (t.w - e.w) * .55}px`,
				height: `${e.h + (t.h - e.h) * .55}px`,
				fontSize: `${(e.w + (t.w - e.w) * .55) * .085}px`,
				transform: `translate(${n * .55}px,${r * .55 - 12}px)`,
				offset: .55
			},
			{
				width: `${t.w}px`,
				height: `${t.h}px`,
				fontSize: `${t.w * .085}px`,
				transform: `translate(${n}px,${r}px)`
			}
		], {
			duration: i,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => a?.cancel();
	}, [
		e,
		t,
		i
	]), /* @__PURE__ */ p("div", {
		ref: o,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			fontSize: e.w * .085
		},
		children: /* @__PURE__ */ p(Ge, { card: a })
	});
}
function Ke({ at: e, face: t, source: i, ms: a }) {
	let o = r(null);
	return n(() => {
		let e = o.current?.animate([
			{ transform: "perspective(400px) rotateX(0deg) rotateY(0deg) rotate(-18deg) scale(.8)" },
			{
				transform: "perspective(400px) rotateX(245deg) rotateY(200deg) translateY(-12px) scale(1.1)",
				offset: .5
			},
			{ transform: "perspective(400px) rotateX(360deg) rotateY(360deg) rotate(0deg) scale(1)" }
		], {
			duration: a,
			easing: "cubic-bezier(.2,.7,.35,1)",
			fill: "both"
		});
		return () => e?.cancel();
	}, [a]), /* @__PURE__ */ p("div", {
		ref: o,
		className: `tb-die tb-fx-die${i === "extra" ? " tb-extra-die" : i === "card" ? " tb-card-die" : i === "support" ? " tb-support-die" : ""}`,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ p(G, { kind: t })
	});
}
var $ = (e, t, n = t) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), qe = { tokyoEvent(e, t) {
	let n = e.data, r = e.rid ? t.anchor(`tokyo-seat:${e.rid}`) : null, i = t.anchor("tokyo-market"), a = t.anchor("tokyo-deck"), o = t.anchor("tokyo-arena"), s = t.anchor(`tokyo-keeps:${e.rid}`), c = t.queued ? 240 : 540, l = [];
	if (n.kind === "Roll") {
		let e = n.indices.flatMap((e) => {
			let r = t.anchor(`tokyo-die:${e}`);
			return r ? (l.push(`tokyo-die:${e}`), /* @__PURE__ */ p(Ke, {
				at: r,
				face: n.dice[e],
				source: n.sources[e],
				ms: c
			}, e)) : [];
		});
		return e.length ? {
			ms: c,
			node: /* @__PURE__ */ p(f, { children: e }),
			hide: t.queued ? [] : l
		} : null;
	}
	if (["Buy", "Market"].includes(n.kind) && i && a) {
		let e = (e) => ({
			x: i.x + i.w * e / 3,
			y: i.y,
			w: i.w / 3,
			h: i.h
		}), o = n.newCards.flatMap((e) => {
			let n = t.anchor(`tokyo-card:${e}:market`);
			return n ? (l.push(`tokyo-card:${e}:market`), /* @__PURE__ */ p(Q, {
				from: $(a, 35, 48),
				to: n,
				ms: c,
				card: e
			}, e)) : [];
		});
		return {
			ms: c,
			hide: t.queued ? [] : l,
			node: /* @__PURE__ */ m(f, { children: [
				n.kind === "Buy" && n.slot >= 0 && /* @__PURE__ */ p(Q, {
					from: e(n.slot),
					to: $(x[n.card].type === "discard" ? a : s ?? r ?? a, 45, 62),
					ms: c,
					card: n.card
				}),
				n.kind === "Market" && n.oldMarket.map((t, n) => /* @__PURE__ */ p(Q, {
					from: e(n),
					to: $(a, 35, 48),
					ms: c,
					card: t
				}, `old-${t}`)),
				o
			] })
		};
	}
	if (n.kind === "Fish" && a) {
		let e = t.anchor("tokyo-reveal");
		return e ? {
			ms: c,
			hide: t.queued ? [] : ["tokyo-reveal"],
			node: /* @__PURE__ */ p(Q, {
				from: $(a, 35, 48),
				to: e,
				ms: c,
				card: n.card
			})
		} : null;
	}
	if (n.kind === "ReturnCard" && a && o) return {
		ms: c,
		node: /* @__PURE__ */ p(Q, {
			from: t.anchor("tokyo-reveal") ?? $(o, 110, 145),
			to: $(a, 35, 48),
			ms: c,
			card: n.card
		})
	};
	if (n.kind === "Discard" && a && (s || r)) return {
		ms: c,
		node: /* @__PURE__ */ p(Q, {
			from: $(s ?? r, 60, 80),
			to: $(a, 35, 48),
			ms: c,
			card: n.card
		})
	};
	if (n.kind === "Fan" && r && o) return {
		ms: c,
		node: /* @__PURE__ */ p(g, {
			from: $(o, 42),
			to: $(r, 42),
			ms: c,
			children: /* @__PURE__ */ m("span", {
				className: `tb-fx-token tb-fx-fan tb-fx-fan-${n.card}`,
				children: [/* @__PURE__ */ p(G, { kind: "special" }), [
					"↻",
					"−3",
					"−1",
					"5"
				][n.card]]
			})
		})
	};
	if (n.kind === "ReactionDie" && o) return {
		ms: c,
		node: /* @__PURE__ */ p(Ke, {
			at: $(o, 55),
			face: v[n.n],
			source: "normal",
			ms: c
		})
	};
	if ([
		"Tile",
		"Capture",
		"Support"
	].includes(n.kind) && r && o) {
		let i = n.kind === "Support" ? o : t.anchor("tokyo-debris") ?? o, a = n.kind === "Tile" ? `tokyo-tile:${n.tile}` : n.kind === "Capture" ? `tokyo-capture:${e.rid}:${n.n - 1}` : `tokyo-support:${e.rid}:${n.card}`, s = t.anchor(a), l = s && s.w > 0 ? s : r;
		if (!l) return null;
		let u = n.kind === "Tile" ? C[n.tile] ?? "capture" : n.kind === "Capture" ? C[n.card] : v[n.card];
		return {
			ms: c,
			hide: t.queued || !s?.w ? [] : [a],
			node: /* @__PURE__ */ p(g, {
				from: $(i, 34),
				to: $(l, Math.min(34, l.w, l.h)),
				ms: c,
				children: /* @__PURE__ */ p("span", {
					className: `tb-fx-token${n.kind === "Support" ? " tb-fx-support" : " tb-fx-debris"}`,
					children: /* @__PURE__ */ p(G, { kind: u })
				})
			})
		};
	}
	let u = (n.kind === "Pull" ? t.anchor(`tokyo-track:${n.card}`) : null) ?? r;
	if (!u) return null;
	let d = n.kind === "Heal" ? "heal" : n.kind === "Damage" ? "damage" : n.kind === "Energy" ? "energy" : n.kind === "Special" ? "special" : n.kind === "Pull" ? n.card === 0 ? "fame" : "destruction" : "token";
	return [
		"Heal",
		"Damage",
		"Energy",
		"Special",
		"Pull",
		"Other",
		"Card"
	].includes(n.kind) ? {
		ms: c,
		node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(te, {
			at: u,
			ms: c
		}), /* @__PURE__ */ p(h, {
			at: u,
			ms: c,
			children: /* @__PURE__ */ m("span", {
				className: "tb-fx-value",
				children: [/* @__PURE__ */ p(G, { kind: d }), [
					"Heal",
					"Damage",
					"Energy"
				].includes(n.kind) ? n.n : ""]
			})
		})] })
	} : null;
} };
//#endregion
//#region src/games/tokyobay/game-over.tsx
function Je(e) {
	let t = o(), n = e.public, [r, a] = i(!0), [s, c] = i(!1), l = n.winner === null || n.winner < 0 ? null : Y(e.members, n.players[n.winner], n.winner, t);
	return /* @__PURE__ */ m("div", {
		className: "tb-game",
		children: [
			/* @__PURE__ */ p(Be, {
				public: n,
				members: e.members,
				myRid: e.myRid,
				send: () => void 0
			}),
			!r && /* @__PURE__ */ p("button", {
				type: "button",
				className: "tb-action tb-primary tb-over-restore",
				onClick: () => a(!0),
				children: t("games.tokyobay.returnResult")
			}),
			r && /* @__PURE__ */ p("div", {
				className: "tb-over-overlay",
				children: /* @__PURE__ */ m("section", {
					className: "tb-over-paper",
					"aria-label": t("games.tokyobay.done"),
					children: [
						/* @__PURE__ */ p(G, { kind: "crown" }),
						/* @__PURE__ */ p("h1", { children: l ? t("games.tokyobay.victory", { name: l.name }) : t("games.tokyobay.draw") }),
						/* @__PURE__ */ p("h2", { children: t(je[n.reason] ?? "games.tokyobay.cardWin") }),
						/* @__PURE__ */ p("div", {
							className: "tb-over-portraits",
							children: n.seats.map((r, i) => {
								let a = Y(e.members, n.players[i], i, t);
								return /* @__PURE__ */ m("div", {
									className: "tb-over-portrait",
									style: { "--player": a.color },
									children: [
										/* @__PURE__ */ p("img", {
											src: K(`monster-${r.monster}`),
											alt: y[r.monster]
										}),
										/* @__PURE__ */ p("strong", { children: a.name }),
										/* @__PURE__ */ m("span", { children: [
											/* @__PURE__ */ p(G, { kind: "heal" }),
											r.hp,
											" · ",
											/* @__PURE__ */ p(G, { kind: "energy" }),
											r.energy,
											" · ",
											/* @__PURE__ */ p(G, { kind: "capture" }),
											r.captured.length
										] }),
										e.result.autopilot?.[n.players[i]] !== void 0 && /* @__PURE__ */ p("small", { children: t("session.autopilot.share", { n: Math.round(e.result.autopilot[n.players[i]] * 100) }) })
									]
								}, n.players[i]);
							})
						}),
						e.hintCount !== void 0 && /* @__PURE__ */ p("p", { children: t("session.hint.usedCount", { n: e.hintCount }) }),
						/* @__PURE__ */ m("div", {
							className: "tb-over-actions",
							children: [
								/* @__PURE__ */ p("button", {
									className: "tb-action",
									type: "button",
									onClick: () => a(!1),
									children: t("games.tokyobay.review")
								}),
								e.onPlayAgain && /* @__PURE__ */ p("button", {
									className: "tb-action tb-primary",
									type: "button",
									onClick: e.onPlayAgain,
									children: t("session.result.playAgain")
								}),
								e.onBackToLobby && /* @__PURE__ */ p("button", {
									className: `tb-action${s ? " tb-confirm-armed" : ""}`,
									type: "button",
									onBlur: () => c(!1),
									onClick: () => s ? e.onBackToLobby?.() : c(!0),
									children: t(s ? "games.tokyobay.backConfirm" : "session.result.backToLobby")
								})
							]
						}),
						!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ p("p", { children: t("games.tokyobay.hostWait") })
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/tokyobay/options.tsx
function Ye({ value: e, onChange: t }) {
	let n = o(), r = E.safeParse(e), i = r.success ? r.data : E.parse(void 0);
	return /* @__PURE__ */ p(ne, {
		title: n("games.tokyobay.supportOption"),
		children: /* @__PURE__ */ p(_, {
			checked: i.support,
			label: n("games.tokyobay.supportOption"),
			hint: n("games.tokyobay.supportDescription"),
			accent: w.accent,
			onChange: () => t({ support: !i.support })
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tokyobay/entry.tsx
var Xe = {
	definition: Te,
	View: ze,
	bot: We,
	fx: qe,
	OverView: Je,
	Options: Ye,
	locales: {
		zh: {
			name: "King of Tokyo: Duel – Tokyo Bay",
			desc: "六只怪兽争夺东京湾，掷骰、铺设碎片轨道，成为最受瞩目或最令人畏惧的王者。",
			rules: "目标：\n满足以下任意一项条件时，你立即获胜：\n· 使对手的生命值降至 0。\n· 两条轨道均已铺满五块板块，并且两个标记都位于你这一侧的末端碎片上。\n· 捕获三块碎片。\n· 满足你所拥有的能力牌规定的胜利条件。\n准备：\n双方各选一只不同怪兽，按怪兽板设置生命。两条轨道各放对应起始板块与标记，洗混14块碎片和50张能力牌，市场展示三张。双方掷六颗骰子，攻击结果较多者先手，同数重掷；先手首回合少掷一颗骰子，后手获得1点能量。\n回合流程：\n每回合通常最多掷骰三次。首次投掷前，可消耗骰子令牌增加对应数量的额外骰子，最多同时使用两颗，骰子总数不超过八颗。以后可自由选择重掷的骰子，也可取回此前保留的骰子。停止投掷后加入上回合取得的支援令牌，然后结算全部结果，顺序由你选择。\n· 攻击：每个结果使对手受到1点伤害。\n· 回复：每个结果回复1点生命，通常不得超过怪兽初始生命。\n· 能量：每个结果获得1点能量。\n· 声望／破坏：至少三个相同结果拉动对应标记1格，每多一个相同结果多拉动1格。\n· 特殊：按怪兽板发动能力，可在数量允许时多次发动；每次能力及其拉动效果须完整结算后才能再次发动。\n碎片轨道：\n标记只能移动到已有板块上。向你的一侧移动时，如前方是水域，抽取碎片并添加到轨道这一侧，再移上去并应用奖励。添加或移除碎片后，所有板块紧邻并居中，两端保留水域。完整轨道包含起始板块和四块碎片。标记已在完整轨道己方末端时，再次拉动不移动标记，改为抽取一块碎片、应用奖励并将其捕获。\n碎片奖励为回复1点生命、获得1点能量、使对手受到1点伤害，或获得1枚骰子令牌。令牌最多保留两枚。\n失效骰与支援：\n默认启用。声望、破坏或特殊结果因数量不足而无法生效，以及在满血时结算的回复结果，均为失效骰。其他结果、被取消或弃掉的骰子不计。每对失效骰可让你选取一枚尚未使用的支援令牌，下回合必须加入最终骰组。支援视为对应骰面，不能修改，也可能失效；结算后翻面，本局不能再次取得同一枚。\n购买：\n结算后可逐张购买市场能力牌，支付牌面能量，最右侧卡牌的费用始终减少1点能量。取走的空位由其余牌向右滑动，再从左侧补牌，新牌可立即购买。也可支付2点能量弃掉三张市场牌并补满。不购买牌时获得1点能量；刷新不算购买。保留牌留在面前，响应保留牌通常在对手回合触发，一次性牌购买后立即应用效果并弃掉。\n怪兽：\n· H.A.D.E.S.每两个特殊结果使环路前进一格，依次造成3点伤害、获得骰子令牌、拉动声望。\n· Gigarex可用一个特殊结果让双方各受1点伤害，再用两个特殊结果让对手额外受到3点伤害。\n· Pagura每个特殊结果展示一张牌，按效果区奖励图标获益，随后放到牌堆底。\n· Iron Back每个特殊结果获得护盾，或选择本回合转换模式，弃掉全部护盾并按每枚获得 1 点能量或造成 1 点伤害；受伤时每枚护盾可抵消1点伤害。\n· Kraken每个特殊结果选择一枚触手：下回合自己可不限次重掷对应骰面，或让对手不得重掷对应骰面，使用后归还。\n· Cyber Bunny：每两个特殊结果可以翻开一枚粉丝令牌。在购买阶段，弃置一枚粉丝令牌可以选择下列一种效果。\n粉丝令牌的可选效果：\n· 刷新市场，并获得1点能量。\n· 使下一张能力牌的费用减少3点能量。\n· 使本回合所有能力牌的费用减少1点能量。\n· 查看五张牌，使用其中一张替换市场中的一张牌。\n结束：\n能力牌可能改变通常规则或提供额外胜利条件。胜利在条件满足时立即发生，无须等回合结束。盒内成就贴纸属于实体收藏，不影响对局。",
			smash: "攻击",
			heal: "回复",
			energy: "能量",
			special: "特殊",
			fame: "声望",
			destruction: "破坏",
			damage: "伤害",
			token: "骰子令牌",
			keep: "保留",
			monster0: "每两个特殊结果沿环路前进：造成3伤害 → 获得骰子令牌 → 拉动声望。",
			monster1: "一个特殊结果：双方各受1伤害；再支付两个特殊结果，对手额外受到3伤害。",
			monster2: "每个特殊结果展示一张牌，获得其效果区奖励，再将牌放到牌堆底。",
			monster3: "每个特殊结果获得一面护盾；或将全部护盾转为能量／伤害。每面护盾可抵消1伤害。",
			monster4: "每个特殊结果取得一枚触手，帮助自己不限次重掷对应骰面，或限制对手保留该骰面。",
			monster5: "每两个特殊结果翻开一枚粉丝令牌，在购买阶段弃掉并使用其效果。",
			chooseMonster: "选择你的怪兽",
			waiting: "等待{{name}}",
			turn: "{{name}}的回合",
			round: "第{{n}}回合",
			roll: "掷骰",
			reroll: "重掷所选骰子",
			stop: "开始结算",
			rolls: "投掷 {{n}}／{{total}}",
			resolve: "选择结算顺序",
			market: "购买能力牌",
			support: "选择下回合的支援",
			react: "选择响应",
			choose: "选择效果",
			end: "回合结束效果",
			draft: "选择怪兽",
			done: "对局结束",
			rollHint: "点击骰子选择重掷",
			extra: "使用{{n}}枚骰子令牌",
			pass: "继续",
			finish: "结束回合",
			refresh: "刷新市场 · 2能量",
			buy: "购买 · {{n}}能量",
			gainEnergy: "不购买，获得能量",
			activate: "发动能力",
			lost: "结算失效骰",
			shield: "消耗{{n}}面护盾",
			damageChoice: "承受伤害／使用护盾",
			energyMode: "将护盾转为能量",
			attackMode: "将护盾转为伤害",
			shieldMode: "获得护盾",
			gigarex1: "双方各受1伤害",
			gigarex3: "双方各受1伤害，对手再受3伤害",
			pull: "拉动{{face}}标记",
			takeSupport: "获得{{face}}支援",
			decline: "放弃剩余支援",
			discard: "弃掉此牌",
			keepCard: "保留剩余牌",
			returnDebris: "归还捕获的碎片",
			tile: "碎片",
			capture: "捕获碎片",
			debris: "碎片堆",
			deck: "能力牌堆",
			viewCards: "已购买的能力牌",
			close: "关闭",
			details: "查看详情",
			noCards: "暂无保留牌",
			fan: "使用粉丝令牌",
			fan0: "刷新市场并获得1能量",
			fan1: "下一张牌减费3",
			fan2: "本回合所有牌减费1",
			fan3: "查看五张牌并替换市场一张",
			replace: "替换市场第{{n}}张牌",
			offer: "选取展示的牌",
			nightVision: "选择抽取的碎片",
			tentacleSelf: "帮助自己重掷{{face}}",
			tentacleRival: "限制对手重掷{{face}}",
			missile: "支付1能量，造成2伤害",
			artificer: "受到3伤害，再拉动破坏",
			pillage: "由对手获得{{face}}奖励",
			change: "改变骰面",
			pay3: "支付3能量",
			pay8: "支付8能量",
			continue: "继续",
			effectOrder: "选择下一项效果",
			bonus: "应用碎片奖励",
			victory: "{{name}}获胜",
			ko: "击败对手",
			tracksWin: "同时控制两条完整轨道",
			captureWin: "捕获三块碎片",
			cardWin: "满足能力牌胜利条件",
			lastChanceWin: "最后机会：捕获碎片",
			review: "回看战场",
			returnResult: "返回结果",
			health: "生命",
			shields: "护盾",
			captured: "已捕获",
			activeSupport: "可用支援",
			spentSupport: "已使用",
			pendingSupport: "下回合支援",
			log: "战况记录",
			error: "当前无法执行此操作，请重新选择。",
			supportOption: "失效骰与支援模式",
			supportDescription: "每对失效骰可取得一枚下回合使用的支援。",
			on: "开启（推荐）",
			off: "关闭",
			wonBy: "获胜方式",
			history: "战场回顾",
			draw: "双方同时倒下",
			hostWait: "等待主机开始下一局",
			eventRoll: "{{name}}投掷了骰子",
			eventHeal: "{{name}}回复{{n}}点生命",
			eventEnergy: "{{name}}获得{{n}}点能量",
			eventDamage: "{{name}}受到{{n}}点伤害",
			eventPull: "{{name}}拉动了标记",
			eventCapture: "{{name}}捕获了碎片",
			eventBuy: "{{name}}购买了能力牌",
			eventSpecial: "{{name}}发动了特殊能力",
			eventOther: "{{name}}应用了效果",
			cards: {
				c0: {
					name: "掠夺港口",
					text: "选择并应用两项效果，对手应用剩余一项：回复3点生命、获得1枚骰子令牌、拉动破坏标记1格。"
				},
				c1: {
					name: "接招！",
					text: "将你捕获的一块碎片放回碎片堆底，对手受到6点伤害。"
				},
				c2: {
					name: "超稀有怪兽",
					text: "拉动声望标记2格。"
				},
				c3: {
					name: "巨浪",
					text: "每只怪兽必须弃掉一张保留牌。"
				},
				c4: {
					name: "特殊招式",
					text: "本回合每发动一次特殊能力，拉动声望或破坏标记1格，最多应用两次。"
				},
				c5: {
					name: "混乱建筑",
					text: "选择声望或破坏轨道，应用该轨道上的全部碎片奖励。"
				},
				c6: {
					name: "吸血目光",
					text: "在你的回合，对手首次受到伤害时，你回复1点生命。"
				},
				c7: {
					name: "巨型护盾",
					text: "对手结算骰子时，你单次应受到至少5点伤害时，免除该次全部伤害。"
				},
				c8: {
					name: "未雨绸缪",
					text: "回合结束时，若你本回合未购买能力牌，额外获得1点能量。"
				},
				c9: {
					name: "赌徒",
					text: "若对手最终骰组中至少有五个相同结果，你获得3点能量。"
				},
				c10: {
					name: "满载",
					text: "胜利条件：拥有7张保留牌。"
				},
				c11: {
					name: "危险水域",
					text: "购买时捕获1块碎片。对手每次应用能量或回复碎片奖励时，改为失去对应能量或生命。"
				},
				c12: {
					name: "多线作战",
					text: "若最终骰组中至少有四种不同结果，拉动声望标记1格。"
				},
				c13: {
					name: "多重飞弹",
					text: "最终骰组中每有一对攻击结果，你可支付1点能量，使对手受到2点伤害。"
				},
				c14: {
					name: "夜视",
					text: "每次需要抽取碎片时，改为抽取两块，选择一块，另一块放回碎片堆底。"
				},
				c15: {
					name: "网络过载",
					text: "对手结算最终骰组时，拉动声望或破坏标记累计至少三次后，失去全部能量。"
				},
				c16: {
					name: "危险举升",
					text: "每回合额外掷一颗骰子。最终骰组中至少有四个相同结果时，在结算前受到10点伤害。胜利条件：再捕获1块碎片。"
				},
				c17: {
					name: "遗忘圣物",
					text: "捕获1块碎片。"
				},
				c18: {
					name: "混沌魔法",
					text: "最终骰组中集齐六种不同结果时，捕获1块碎片。"
				},
				c19: {
					name: "巨型大脑",
					text: "每回合可额外重掷一次。"
				},
				c20: {
					name: "欧米伽武器",
					text: "每次重掷时，若至少一颗骰子在重掷前为攻击结果，对手受到1点伤害。"
				},
				c21: {
					name: "万全计划",
					text: "对手必须比通常要求多一个声望或破坏结果，才能拉动对应标记。"
				},
				c22: {
					name: "为了家人",
					text: "胜利条件：你的生命少于对手，且已捕获至少2块碎片。"
				},
				c23: {
					name: "不定命运",
					text: "结算前，你可将一颗破坏结果改为声望，或将一颗声望结果改为破坏；不能改变支援令牌。"
				},
				c24: {
					name: "庞然巨物",
					text: "购买时失去3点生命，生命上限改为20。最终骰组中每有一对特殊结果，回复1点生命。胜利条件：拥有20点生命。"
				},
				c25: {
					name: "闪电之力",
					text: "最终骰组中每有一对特殊结果，获得1点能量。胜利条件：拥有18点能量。"
				},
				c26: {
					name: "任务委派",
					text: "最终骰组中没有声望和破坏结果时，对手受到2点伤害。"
				},
				c27: {
					name: "稳固地面",
					text: "每有一块你捕获的碎片，向最终骰组添加一个攻击结果。"
				},
				c28: {
					name: "最后机会",
					text: "双方均获得以下胜利条件：再捕获1块碎片即获胜。"
				},
				c29: {
					name: "额外头颅",
					text: "每回合额外掷一颗骰子。"
				},
				c30: {
					name: "潜航",
					text: "对手即将结算最终骰组前，你可弃掉此牌，取消其全部攻击结果。"
				},
				c31: {
					name: "迷失海上",
					text: "对手即将结算最终骰组前，你可弃掉此牌，取消其全部回复结果。"
				},
				c32: {
					name: "潮汐主宰",
					text: "对手本回合的重掷次数不得超过你上一回合的重掷次数。"
				},
				c33: {
					name: "超游怪兽",
					text: "免除能力牌及特殊能力对你造成的全部伤害。"
				},
				c34: {
					name: "安全港",
					text: "对手结算最终骰组时，若至少有一个回复结果，你回复1点生命。"
				},
				c35: {
					name: "海盗！",
					text: "对手每购买一张能力牌，你获得1点能量。"
				},
				c36: {
					name: "快速充能",
					text: "应用能量碎片奖励时，获得2点能量，替代通常的1点。"
				},
				c37: {
					name: "格斗专家",
					text: "应用攻击碎片奖励时，对手受到2点伤害，替代通常的1点。"
				},
				c38: {
					name: "不稳航路",
					text: "对手每次拉动声望或破坏标记时，你掷一颗骰子；若结果为攻击或特殊，对手受到1点伤害。"
				},
				c39: {
					name: "贡品",
					text: "任一标记到达对应起始板块时，你获得1枚骰子令牌。"
				},
				c40: {
					name: "海湾巨颚",
					text: "选择版图上一块没有标记的碎片，应用其奖励两次，然后将它面朝下放回碎片堆顶。"
				},
				c41: {
					name: "工匠",
					text: "拉动破坏标记1格。你可受到3点伤害，再拉动破坏标记1格。"
				},
				c42: {
					name: "废墟之主",
					text: "将破坏标记放在对应起始板块上，并获得1枚骰子令牌。"
				},
				c43: {
					name: "超级反击",
					text: "费用X等于版图上的碎片数量。所有怪兽各受到X点伤害。"
				},
				c44: {
					name: "突袭",
					text: "本回合最终骰组中每有一个特殊结果，对手受到1点伤害。"
				},
				c45: {
					name: "过载",
					text: "本回合最终骰组中每有一个特殊结果，你获得2点能量。"
				},
				c46: {
					name: "秘密武器",
					text: "支付3点能量时，如同掷出两个特殊结果发动特殊能力；支付8点能量时，如同掷出六个特殊结果发动特殊能力。"
				},
				c47: {
					name: "援手",
					text: "版图上每有一个回复或骰子令牌碎片奖励，你回复1点生命。"
				},
				c48: {
					name: "排空海湾",
					text: "展示碎片堆中的全部碎片，应用全部奖励，然后重新洗混碎片堆。"
				},
				c49: {
					name: "嫉妒",
					text: "对手可先弃掉任意数量的保留牌。其每有一张剩余保留牌，你拉动破坏标记1格。"
				}
			},
			exchange: "转换护盾：获得{{n}}能量，造成{{damage}}伤害",
			pillagePrompt: "选择由对手获得的奖励",
			chooseMarket: "选择替换的市场牌",
			reactive: "响应保留",
			discardType: "一次性",
			keepType: "保留",
			cardDetail: "能力牌详情",
			monsterDetail: "怪兽能力",
			yourCards: "{{name}}的能力牌",
			boardHint: "← {{left}} · {{right}} →",
			firstRoll: "首次投掷",
			locked: "锁定",
			chosen: "已选",
			resolveFace: "结算{{face}}",
			fanTokens: "粉丝",
			tentacles: "触手",
			protocol: "协议环路",
			lostDice: "失效骰：{{n}}",
			logInitiative: "{{name}}先手（攻击结果{{n}}）",
			logCard: "{{name}}发动了能力牌",
			logFish: "{{name}}展示并捞取能力牌奖励",
			logReactionDie: "{{name}}掷出响应骰",
			logMarket: "{{name}}刷新了市场",
			logTile: "{{name}}铺设了碎片",
			backConfirm: "再次点击返回大厅",
			fished: "捕鱼奖励",
			noEffect: "无可捞取奖励",
			turnWaiting: "{{name}}正在行动",
			marketDiscount: "最右侧牌减费1",
			bonusReroll: "触手可继续重掷",
			supportSpent: "此支援已使用",
			supportReady: "此支援尚可取得",
			replayHint: "回看最终战场",
			buySecret: "购买 · {{n}}能量（发动{{power}}个特殊结果）",
			logDiscard: "{{name}}弃置了能力牌",
			logFan: "{{name}}揭示并获得粉丝圆片",
			logSupport: "{{name}}获得了支援圆片",
			logReturnCard: "{{name}}将捕鱼揭示的牌放回牌堆底"
		},
		en: {
			name: "King of Tokyo: Duel – Tokyo Bay",
			desc: "Six monsters contest Tokyo Bay. Roll dice, build Debris tracks, and seize victory through fame, destruction, or cunning powers.",
			rules: "Goal:\nYou win immediately when you meet any one of the following conditions:\n· Your Rival has no Life remaining.\n· Both tracks are complete and both markers are on the last tile on your side.\n· You have captured three Debris tiles.\n· You meet a victory condition on one of your Power cards.\nSetup:\nChoose different Monsters and set your starting Life. Place each starting tile and marker on its track, shuffle 14 Debris tiles and 50 Power cards, and reveal three market cards. Both players roll six dice; most Smash results goes first, rerolling ties. The first player rolls one fewer die on their first turn; the other player gains 1 Energy.\nTurn:\nNormally roll up to three times. Before the first roll, spend Dice tokens to add extra dice, up to two extra dice and eight dice total. Choose any dice to reroll, including dice previously kept. Stop whenever you wish, add Support gained last turn, and resolve every result in any order.\n· Smash: deal 1 damage per result.\n· Heal: regain 1 Life per result, up to your maximum Life.\n· Energy: gain 1 Energy per result.\n· Fame / Destruction: three matching results pull that marker one space; each additional matching result pulls one more space.\n· Special: activate your Monster's power, multiple times if possible. Fully resolve each activation, including marker pulls, before the next activation.\nDebris tracks:\nMarkers can only move onto tiles. If the next space towards you is water, draw a Debris tile and add it on your side, then move onto it and apply its bonus. Whenever tiles are added or removed, slide all tiles together and center them, leaving water at both ends. A complete track has its starting tile and four Debris tiles. Pulling beyond your end of a complete track instead draws a tile, applies its bonus, and captures it.\nDebris bonuses heal 1 Life, gain 1 Energy, deal 1 damage, or gain one Dice token. You may keep at most two Dice tokens.\nLost Dice and Support:\nEnabled by default. Fame, Destruction, or Special results too few to have an effect, and Heal results resolved while at maximum Life, are Lost Dice. Other results, canceled dice, and discarded dice never count. For each pair, you may take an unused Support token. Add it to your next Roll as an unchangeable extra result. It can itself be lost. After resolving, it becomes inactive for the rest of the game.\nBuying:\nBuy available Power cards one at a time, paying their Energy cost. The rightmost card always costs 1 less. Slide remaining cards right and refill from the left after every purchase or discard; new cards are immediately available. You may spend 2 Energy to discard and replace all three. If you buy no cards, gain 1 Energy; refreshing does not count as a purchase. Keep cards remain in play; Reactive Keep cards work mainly during your Rival's turn and otherwise count as Keep cards. Discard cards resolve immediately.\nMonsters:\n· H.A.D.E.S. spends pairs of Special results to advance around its loop: deal 3 damage, gain a Dice token, pull Fame.\n· Gigarex spends one Special to deal 1 damage to both Monsters, with two additional Special results dealing 3 more damage to its Rival.\n· Pagura reveals one card per Special, fishes its effect-zone bonus symbols, then puts it below the deck.\n· Iron Back gains shields or converts all its shields to Energy or damage; each shield may prevent one damage.\n· Kraken assigns one of three tentacles per Special: reroll that face without limit on your next turn, or prevent your Rival rerolling that face. Return tentacles after their Roll.\n· Cyber Bunny: Spend two Special results to reveal one Fan token. During buying, spend one Fan token to choose one of the effects below.\nFan token effects:\n· Refresh the market and gain 1 Energy.\n· Reduce the cost of your next Power card by 3 Energy.\n· Reduce the cost of all Power cards you buy this turn by 1 Energy.\n· Inspect five cards and exchange one of them for a market card.\nEnd:\nPower cards may override general rules and add immediate victory conditions. Achievements on the physical box are collectible stickers and have no match effect.",
			smash: "Smash",
			heal: "Heal",
			energy: "Energy",
			special: "Special",
			fame: "Fame",
			destruction: "Destruction",
			damage: "Damage",
			token: "Dice token",
			keep: "Keep",
			monster0: "Spend two Special: advance the loop. Deal 3 damage → gain a Dice token → pull Fame.",
			monster1: "Spend one Special: both take 1 damage. Spend two additional Special: your Rival takes 3 more.",
			monster2: "Reveal one card per Special. Fish its effect-zone bonuses, then put it below the deck.",
			monster3: "Gain a shield per Special, or convert all shields to Energy / damage. A shield may prevent 1 damage.",
			monster4: "Take a tentacle to reroll its face without limit next turn, or stop your Rival rerolling that face.",
			monster5: "Spend two Special to reveal a Fan. Spend Fans during buying for discounts or market effects.",
			chooseMonster: "Choose your Monster",
			waiting: "Waiting for {{name}}",
			turn: "{{name}}'s turn",
			round: "Turn {{n}}",
			roll: "Roll dice",
			reroll: "Reroll selected dice",
			stop: "Resolve Roll",
			rolls: "Roll {{n}} / {{total}}",
			resolve: "Choose resolution order",
			market: "Buy Power cards",
			support: "Choose Support for next turn",
			react: "Choose a response",
			choose: "Choose an effect",
			end: "End-of-turn effects",
			draft: "Choose Monsters",
			done: "Game over",
			rollHint: "Select dice to reroll",
			extra: "Spend {{n}} Dice tokens",
			pass: "Continue",
			finish: "End turn",
			refresh: "Refresh market · 2 Energy",
			buy: "Buy · {{n}} Energy",
			gainEnergy: "Buy nothing; gain Energy",
			activate: "Activate power",
			lost: "Resolve Lost Dice",
			shield: "Spend {{n}} shields",
			damageChoice: "Take damage or use shields",
			energyMode: "Convert shields to Energy",
			attackMode: "Convert shields to damage",
			shieldMode: "Gain shields",
			gigarex1: "Both take 1 damage",
			gigarex3: "Both take 1 damage; Rival takes 3 more",
			pull: "Pull {{face}}",
			takeSupport: "Take {{face}} Support",
			decline: "Decline remaining Support",
			discard: "Discard this card",
			keepCard: "Keep remaining cards",
			returnDebris: "Return a captured tile",
			tile: "Debris",
			capture: "Capture Debris",
			debris: "Debris stack",
			deck: "Power deck",
			viewCards: "Power cards",
			close: "Close",
			details: "View details",
			noCards: "No Keep cards yet",
			fan: "Spend a Fan",
			fan0: "Refresh and gain 1 Energy",
			fan1: "Discount one card by 3",
			fan2: "Discount all cards by 1 this turn",
			fan3: "Inspect five and exchange a market card",
			replace: "Replace market card {{n}}",
			offer: "Choose a revealed card",
			nightVision: "Choose a Debris tile",
			tentacleSelf: "Reroll {{face}} without limit",
			tentacleRival: "Lock Rival’s {{face}}",
			missile: "Pay 1 Energy; deal 2 damage",
			artificer: "Take 3 damage; pull Destruction again",
			pillage: "Rival gains the {{face}} bonus",
			change: "Change a die",
			pay3: "Pay 3 Energy",
			pay8: "Pay 8 Energy",
			continue: "Continue",
			effectOrder: "Choose the next effect",
			bonus: "Apply Debris bonus",
			victory: "{{name}} wins",
			ko: "Defeated the Rival",
			tracksWin: "Controls both complete tracks",
			captureWin: "Captured three Debris tiles",
			cardWin: "Power card victory",
			lastChanceWin: "Last Chance: captured Debris",
			review: "Review the battlefield",
			returnResult: "Return to results",
			health: "Life",
			shields: "Shields",
			captured: "Captured",
			activeSupport: "Available Support",
			spentSupport: "Used",
			pendingSupport: "Next-turn Support",
			log: "Battle log",
			error: "That action is no longer available. Choose again.",
			supportOption: "Lost Dice and Support",
			supportDescription: "Each pair of Lost Dice may gain Support for your next turn.",
			on: "On (recommended)",
			off: "Off",
			wonBy: "Victory condition",
			history: "Battlefield review",
			draw: "Both Monsters fell",
			hostWait: "Waiting for the host",
			eventRoll: "{{name}} rolled the dice",
			eventHeal: "{{name}} regained {{n}} Life",
			eventEnergy: "{{name}} gained {{n}} Energy",
			eventDamage: "{{name}} took {{n}} damage",
			eventPull: "{{name}} pulled a marker",
			eventCapture: "{{name}} captured Debris",
			eventBuy: "{{name}} bought a Power card",
			eventSpecial: "{{name}} activated a special power",
			eventOther: "{{name}} applied an effect",
			cards: {
				c0: {
					name: "Pillage the Port",
					text: "Choose and apply 2 effects; your Rival applies the remaining effect: gain 3 [heal], gain 1 [token], pull 1 [destruction]."
				},
				c1: {
					name: "Catch This!",
					text: "Return one of your captured Debris tiles to the bottom of the stack. Your Rival takes 6 [damage]."
				},
				c2: {
					name: "Super Rare Monster",
					text: "Pull 2 [fame]."
				},
				c3: {
					name: "Tidal Wave",
					text: "Each Monster must discard a [keep] card."
				},
				c4: {
					name: "Special Move",
					text: "Pull 1 [fame] or 1 [destruction] for each time you activated your special power this turn (maximum 2 times)."
				},
				c5: {
					name: "Chaotic Architecture",
					text: "Choose the [fame] or [destruction] track. Apply all Debris bonuses on that track."
				},
				c6: {
					name: "Vampiric Look",
					text: "On your turn, when your Rival takes their first [damage], gain 1 [heal]."
				},
				c7: {
					name: "Giant Shield",
					text: "When your Rival resolves their Roll, if you must take 5 or more [damage], do not take any [damage]."
				},
				c8: {
					name: "Forecasting",
					text: "At the end of your turn, gain 1 additional [energy] if you did not buy any Power cards this turn."
				},
				c9: {
					name: "Gambler",
					text: "If your Rival has at least 5 of a kind in their Roll, gain 3 [energy]."
				},
				c10: {
					name: "Overloaded",
					text: "Victory: have 7 [keep] cards."
				},
				c11: {
					name: "Dangerous Waters",
					text: "Capture 1 Debris tile when you buy this card. Each time your Rival applies an [energy] or [heal] Debris bonus, they lose that bonus instead of gaining it."
				},
				c12: {
					name: "Multitask",
					text: "If you have at least 4 different results in your Roll, pull 1 [fame]."
				},
				c13: {
					name: "Multi-Missiles",
					text: "For each pair of [smash] in your Roll, you may pay 1 [energy] to make your Rival take 2 [damage]."
				},
				c14: {
					name: "Night Vision",
					text: "When you must draw a Debris tile, draw 2, choose 1, and put the other on the bottom of the stack."
				},
				c15: {
					name: "Network Overload",
					text: "If your Rival pulls [fame] or [destruction] 3 or more times while resolving their Roll, they lose all their [energy]."
				},
				c16: {
					name: "Risky Lift",
					text: "Roll 1 additional die each turn. If you have at least 4 of a kind in your Roll, take 10 [damage] before resolving your Roll. Victory: capture 1 Debris tile."
				},
				c17: {
					name: "Forgotten Relic",
					text: "Capture 1 Debris tile."
				},
				c18: {
					name: "Chaos Magic",
					text: "If your Roll contains all six different results, capture 1 Debris tile."
				},
				c19: {
					name: "Giant Brain",
					text: "You may roll the dice 1 additional time each turn."
				},
				c20: {
					name: "Omega Weapons",
					text: "When you reroll dice, if at least one had a [smash] result before rerolling, your Rival takes 1 [damage]."
				},
				c21: {
					name: "Foolproof Plan",
					text: "Your Rival must have 1 additional [fame] or [destruction] in their Roll to pull the corresponding marker."
				},
				c22: {
					name: "For Family",
					text: "Victory: have fewer [heal] than your Rival and have captured 2 Debris tiles."
				},
				c23: {
					name: "Uncertain Destiny",
					text: "Before resolving your Roll, you may change 1 [destruction] result to [fame], or vice versa."
				},
				c24: {
					name: "Colossal",
					text: "Lose 3 [heal] when you buy this card. Your maximum Life is now 20. For each pair of [special] in your Roll, gain 1 [heal]. Victory: have 20 [heal]."
				},
				c25: {
					name: "Lightning Power",
					text: "For each pair of [special] in your Roll, gain 1 [energy]. Victory: have 18 [energy]."
				},
				c26: {
					name: "Mission Assignment",
					text: "If you have neither [fame] nor [destruction] in your Roll, your Rival takes 2 [damage]."
				},
				c27: {
					name: "Solid Ground",
					text: "For each of your captured Debris tiles, add 1 [smash] to your Roll."
				},
				c28: {
					name: "Last Chance",
					text: "You and your Rival can gain the following effect. Victory: capture 1 Debris tile."
				},
				c29: {
					name: "Extra Head",
					text: "Roll 1 additional die each turn."
				},
				c30: {
					name: "Submersible",
					text: "Just before your Rival resolves their Roll, discard this card to cancel all their [smash] results."
				},
				c31: {
					name: "Lost At Sea",
					text: "Just before your Rival resolves their Roll, discard this card to cancel all their [heal] results."
				},
				c32: {
					name: "Tide Master",
					text: "On their turn, your Rival cannot reroll more times than you did on your last turn."
				},
				c33: {
					name: "Metagame Monster",
					text: "Ignore any [damage] dealt to you by Power cards or special powers."
				},
				c34: {
					name: "Safe Haven",
					text: "When resolving their Roll, if your Rival has at least 1 [heal] result, gain 1 [heal]."
				},
				c35: {
					name: "Pirates!",
					text: "Each time your Rival buys a Power card, gain 1 [energy]."
				},
				c36: {
					name: "Quick Recharge",
					text: "Gain 2 [energy] instead of 1 when you apply an [energy] Debris bonus."
				},
				c37: {
					name: "Martial Expert",
					text: "Your Rival takes 2 [damage] instead of 1 when you apply a [smash] Debris bonus."
				},
				c38: {
					name: "Unstable Path",
					text: "Roll 1 die each time your Rival pulls [fame] or [destruction]. If you roll [smash] or [special], they take 1 [damage]."
				},
				c39: {
					name: "Tribute",
					text: "When [fame] or [destruction] reaches its starting tile, gain 1 [token]."
				},
				c40: {
					name: "Jaws in the Bay",
					text: "Choose an unoccupied Debris tile on the board. Apply its bonus twice, then place it face down on top of the stack."
				},
				c41: {
					name: "Artificer",
					text: "Pull 1 [destruction]. You may take 3 [damage] to pull 1 more [destruction]."
				},
				c42: {
					name: "Master of Ruin",
					text: "Place [destruction] on its starting tile. Gain 1 [token]."
				},
				c43: {
					name: "Super Counterattack",
					text: "Cost X is the number of Debris tiles on the board. All Monsters take X [damage]."
				},
				c44: {
					name: "Surprise Attack",
					text: "Your Rival takes 1 [damage] for each [special] in your Roll this turn."
				},
				c45: {
					name: "Overload",
					text: "Gain 2 [energy] for each [special] in your Roll this turn."
				},
				c46: {
					name: "Secret Weapon",
					text: "Activate your special power as if you rolled 2 [special] if you paid 3 [energy], or 6 [special] if you paid 8 [energy]."
				},
				c47: {
					name: "Helping Hand",
					text: "Gain 1 [heal] for each [heal] and [token] Debris bonus on the board."
				},
				c48: {
					name: "Drain the Bay",
					text: "Reveal all Debris tiles in the stack. Apply all their bonuses, then reshuffle the stack."
				},
				c49: {
					name: "Jealousy",
					text: "Pull 1 [destruction] for each of your Rival's [keep] cards. They may discard [keep] cards before this effect resolves."
				}
			},
			exchange: "Exchange shields: gain {{n}} Energy; deal {{damage}} damage",
			pillagePrompt: "Choose the bonus your Rival receives",
			chooseMarket: "Choose a market card to replace",
			reactive: "Reactive Keep",
			discardType: "Discard",
			keepType: "Keep",
			cardDetail: "Power card details",
			monsterDetail: "Monster power",
			yourCards: "{{name}}’s Power cards",
			boardHint: "← {{left}} · {{right}} →",
			firstRoll: "First roll",
			locked: "Locked",
			chosen: "Selected",
			resolveFace: "Resolve {{face}}",
			fanTokens: "Fans",
			tentacles: "Tentacles",
			protocol: "Protocol loop",
			lostDice: "Lost Dice: {{n}}",
			logInitiative: "{{name}} goes first ({{n}} Smash results)",
			logCard: "{{name}} activated a Power card",
			logFish: "{{name}} revealed a card and fished bonuses",
			logReactionDie: "{{name}} rolled a reactive die",
			logMarket: "{{name}} refreshed the market",
			logTile: "{{name}} placed Debris",
			backConfirm: "Click again to return to lobby",
			fished: "Fishing bonuses",
			noEffect: "No eligible fishing bonus",
			turnWaiting: "{{name}} is taking their turn",
			marketDiscount: "Rightmost card costs 1 less",
			bonusReroll: "Tentacles allow more rerolls",
			supportSpent: "This Support has been used",
			supportReady: "This Support is available",
			replayHint: "Review the final battlefield",
			buySecret: "Buy · {{n}} Energy (activate {{power}} Special results)",
			logDiscard: "{{name}} discarded a Power card",
			logFan: "{{name}} revealed and gained a Fan token",
			logSupport: "{{name}} gained a Support token",
			logReturnCard: "{{name}} returned a fished card to the bottom of the deck"
		}
	}
};
//#endregion
export { Xe as default };
