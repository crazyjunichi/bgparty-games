import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as s } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as c, seatName as l } from "@bgparty/sdk/ui/player-strip";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { Flash as p, Floater as m, FlySprite as h, PulseBox as g } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as _, OptionSection as v } from "@bgparty/sdk/ui/game-options";
//#region src/games/spots/data.ts
var y = (e, t, n, r, i) => ({
	id: e,
	color: t,
	ops: n,
	nameKey: r,
	descKey: i
}), b = {
	howl: y("howl", "red", [{ op: "drawDog" }, {
		op: "roll",
		count: 1
	}], "games.spots.trickHowl", "games.spots.trickHowlDesc"),
	rollOver: y("rollOver", "red", [{
		op: "roll",
		count: "buried"
	}, {
		op: "roll",
		count: 1,
		optional: !0
	}], "games.spots.trickRollOver", "games.spots.trickRollOverDesc"),
	beg: y("beg", "green", [{
		op: "treat",
		mode: "beg"
	}], "games.spots.trickBeg", "games.spots.trickBegDesc"),
	chew: y("chew", "green", [{
		op: "treat",
		mode: "chew"
	}], "games.spots.trickChew", "games.spots.trickChewDesc"),
	gobble: y("gobble", "green", [{
		op: "treat",
		mode: "gobble"
	}], "games.spots.trickGobble", "games.spots.trickGobbleDesc"),
	playDead: y("playDead", "green", [{
		op: "roll",
		count: 1,
		tag: "playDead"
	}], "games.spots.trickPlayDead", "games.spots.trickPlayDeadDesc"),
	stay: y("stay", "green", [{
		op: "treat",
		mode: "stay"
	}], "games.spots.trickStay", "games.spots.trickStayDesc"),
	fetch: y("fetch", "blue", [{
		op: "roll",
		count: 8,
		policy: "fetch"
	}], "games.spots.trickFetch", "games.spots.trickFetchDesc"),
	guard: y("guard", "blue", [{
		op: "roll",
		count: 4,
		policy: "guard",
		chooseFirst: !0
	}], "games.spots.trickGuard", "games.spots.trickGuardDesc"),
	hunt: y("hunt", "blue", [{
		op: "roll",
		count: "pawsPlus",
		policy: "hunt"
	}], "games.spots.trickHunt", "games.spots.trickHuntDesc"),
	scavenge: y("scavenge", "blue", [{
		op: "roll",
		count: 4,
		policy: "scavenge"
	}], "games.spots.trickScavenge", "games.spots.trickScavengeDesc"),
	search: y("search", "blue", [{
		op: "roll",
		count: 7,
		policy: "search"
	}], "games.spots.trickSearch", "games.spots.trickSearchDesc"),
	dig: y("dig", "yellow", [{ op: "dig" }, {
		op: "roll",
		count: 2
	}], "games.spots.trickDig", "games.spots.trickDigDesc"),
	retrieve: y("retrieve", "yellow", [{ op: "retrieve" }, {
		op: "roll",
		count: 2
	}], "games.spots.trickRetrieve", "games.spots.trickRetrieveDesc"),
	track: y("track", "yellow", [{
		op: "roll",
		count: 3,
		partialReroll: !0
	}], "games.spots.trickTrack", "games.spots.trickTrackDesc"),
	trot: y("trot", "yellow", [{ op: "trot" }, {
		op: "roll",
		count: 2
	}], "games.spots.trickTrot", "games.spots.trickTrotDesc"),
	walk: y("walk", "yellow", [{
		op: "roll",
		count: 2
	}, {
		op: "roll",
		count: 1,
		optional: !0
	}], "games.spots.trickWalk", "games.spots.trickWalkDesc"),
	bolt: y("bolt", "purple", [{ op: "bolt" }], "games.spots.trickBolt", "games.spots.trickBoltDesc"),
	chase: y("chase", "purple", [{ op: "chase" }], "games.spots.trickChase", "games.spots.trickChaseDesc"),
	dogpile: y("dogpile", "purple", [{ op: "dogpile" }], "games.spots.trickDogpile", "games.spots.trickDogpileDesc"),
	run: y("run", "purple", [{
		op: "roll",
		count: 3
	}, {
		op: "roll",
		count: 1,
		optional: !0,
		repeat: !0
	}], "games.spots.trickRun", "games.spots.trickRunDesc"),
	sprint: y("sprint", "purple", [{ op: "sprint" }], "games.spots.trickSprint", "games.spots.trickSprintDesc")
}, ee = [
	"base",
	"dogpark",
	"agility",
	"hunting",
	"kennel",
	"puppy"
], x = {
	base: {
		nameKey: "games.spots.setBase",
		descKey: "games.spots.setBaseDesc",
		tricks: [
			"howl",
			"rollOver",
			"walk",
			"run",
			"fetch",
			"beg"
		]
	},
	dogpark: {
		nameKey: "games.spots.setDogPark",
		descKey: "games.spots.setDogParkDesc",
		tricks: [
			"howl",
			"rollOver",
			"dig",
			"chase",
			"guard",
			"chew"
		]
	},
	agility: {
		nameKey: "games.spots.setAgility",
		descKey: "games.spots.setAgilityDesc",
		tricks: [
			"howl",
			"rollOver",
			"trot",
			"bolt",
			"fetch",
			"gobble"
		]
	},
	hunting: {
		nameKey: "games.spots.setHunting",
		descKey: "games.spots.setHuntingDesc",
		tricks: [
			"howl",
			"rollOver",
			"retrieve",
			"sprint",
			"hunt",
			"stay"
		]
	},
	kennel: {
		nameKey: "games.spots.setKennel",
		descKey: "games.spots.setKennelDesc",
		tricks: [
			"howl",
			"rollOver",
			"track",
			"dogpile",
			"search",
			"beg"
		]
	},
	puppy: {
		nameKey: "games.spots.setPuppy",
		descKey: "games.spots.setPuppyDesc",
		tricks: [
			"howl",
			"rollOver",
			"retrieve",
			"bolt",
			"scavenge",
			"playDead"
		]
	}
}, S = (e, t, n, r, i) => ({
	id: e,
	name: t,
	nameZh: n,
	paws: i,
	spaces: [...r].map((e) => Number(e))
}), C = [
	S(0, "Bart", "巴特", "5", 0),
	S(1, "Gumbo", "甘博", "125", 1),
	S(2, "Sorry", "小歉", "345", 0),
	S(3, "Rogue", "罗格", "456", 1),
	S(4, "Mamma", "玛玛", "135", 0),
	S(5, "Pava", "帕瓦", "246", 1),
	S(6, "Xerox", "齐罗克斯", "1234", 0),
	S(7, "Perky", "珀琪", "2345", 1),
	S(8, "Gyro", "吉罗", "3456", 0),
	S(9, "Wolfgang", "沃尔夫冈", "1245", 1),
	S(10, "Mayor", "市长", "2356", 0),
	S(11, "Nutmeg", "肉豆蔻", "1123", 1),
	S(12, "Gretchen", "格蕾琴", "4456", 0),
	S(13, "Handsome", "帅帅", "1233", 1),
	S(14, "Jolene", "乔琳", "2344", 0),
	S(15, "Ebby", "艾比", "3455", 1),
	S(16, "Ham", "火腿", "4566", 0),
	S(17, "Rupert", "鲁珀特", "1356", 1),
	S(18, "Rondo", "朗多", "2461", 2),
	S(19, "Winifred", "温妮", "1223", 0),
	S(20, "Spot", "点点", "3345", 1),
	S(21, "Biscuit", "饼干", "5566", 0),
	S(22, "Pepper", "胡椒", "1212", 2),
	S(23, "Luna", "露娜", "3434", 0),
	S(24, "Max", "麦克斯", "5656", 2),
	S(25, "Daisy", "黛西", "1111", 0),
	S(26, "Rocky", "洛基", "12345", 1),
	S(27, "Bella", "贝拉", "23456", 0),
	S(28, "Charlie", "查理", "12356", 1),
	S(29, "Molly", "莫莉", "12456", 0),
	S(30, "Toby", "托比", "11234", 2),
	S(31, "Rusty", "拉斯特", "22345", 0),
	S(32, "Sadie", "赛迪", "33456", 1),
	S(33, "Duke", "杜克", "12346", 0),
	S(34, "Penny", "佩妮", "13456", 1),
	S(35, "Ziggy", "齐吉", "12234", 0),
	S(36, "Bruno", "布鲁诺", "123456", 2),
	S(37, "Cleo", "克莱奥", "112233", 0),
	S(38, "Lil Beth", "小贝丝", "5", 1),
	S(39, "Rex", "雷克斯", "234566", 2)
], te = Object.keys(b), w = {
	red: "#b9382f",
	green: "#237c6c",
	blue: "#274c9b",
	yellow: "#d09200",
	purple: "#8c2f86"
}, ne = {
	id: "spots",
	tier: "alpha",
	mechanics: ["dice-rolling", "push-your-luck"],
	interactionTags: [],
	nameKey: "games.spots.name",
	descKey: "games.spots.desc",
	rulesKey: "games.spots.rules",
	icon: "🎲",
	iconImg: "games/spots.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#274c9b",
	releasedAt: "2026-11-11T13:12:53+08:00",
	search: {
		py: "gou yun dang tou",
		init: "gydt"
	},
	hotseat: "open"
}, T = t.int().min(1).max(6), E = t.string(), D = t.enum(te), re = t.enum([
	"base",
	"dogpark",
	"agility",
	"hunting",
	"kennel",
	"puppy"
]), O = t.object({ trickSet: re.default("base") }).default({ trickSet: "base" }), ie = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("trick"),
		id: D
	}),
	t.object({ type: t.literal("score") }),
	t.object({
		type: t.literal("reroll"),
		dice: t.array(t.int().nonnegative()).optional()
	}),
	t.object({ type: t.literal("beginPlace") }),
	t.object({
		type: t.literal("placeDie"),
		die: t.int().nonnegative(),
		card: t.string(),
		space: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("buryDie"),
		die: t.int().nonnegative()
	}),
	t.object({ type: t.literal("autoPlace") }),
	t.object({ type: t.literal("finishPlacement") }),
	t.object({
		type: t.literal("chooseNumber"),
		value: t.int().min(1).max(6)
	}),
	t.object({
		type: t.literal("chooseDice"),
		dice: t.array(t.int().nonnegative())
	}),
	t.object({
		type: t.literal("dig"),
		rid: E,
		index: t.int().nonnegative(),
		delta: t.union([t.literal(1), t.literal(-1)])
	}),
	t.object({ type: t.literal("skipDig") }),
	t.object({
		type: t.literal("trot"),
		card: t.string(),
		space: t.int().nonnegative(),
		toCard: t.string(),
		toSpace: t.int().nonnegative()
	}),
	t.object({ type: t.literal("skipTrot") }),
	t.object({
		type: t.literal("retrieve"),
		value: T
	}),
	t.object({ type: t.literal("skipRetrieve") }),
	t.object({
		type: t.literal("dogpileSource"),
		from: t.enum(["yard", "dog"]),
		index: t.int().nonnegative().optional(),
		card: t.string().optional(),
		space: t.int().nonnegative().optional()
	}),
	t.object({
		type: t.literal("boltChoose"),
		count: t.int().min(1).max(12)
	}),
	t.object({ type: t.literal("repeat") }),
	t.object({ type: t.literal("stop") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ae = t.object({
	uid: t.string(),
	def: t.int().nonnegative(),
	placed: t.array(T.nullable()),
	scored: t.boolean()
}), oe = t.union([
	t.object({
		kind: t.literal("dog"),
		card: t.string(),
		space: t.int().nonnegative()
	}),
	t.object({ kind: t.literal("yard") }),
	t.object({ kind: t.literal("discard") })
]), k = t.object({
	phase: t.enum(["play", "done"]),
	turn: E.nullable(),
	awaiting: t.enum([
		"action",
		"roll",
		"chooseNumber",
		"chooseDice",
		"place",
		"repeat",
		"dig",
		"trot",
		"retrieve",
		"dogpile",
		"bolt"
	]),
	config: O,
	tiles: t.array(t.object({
		id: D,
		faceup: t.boolean(),
		treats: t.int().nonnegative()
	})),
	activeTrick: D.nullable(),
	stepIdx: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	deckTop: t.int().nullable(),
	supplyDice: t.int().nonnegative(),
	supplyTreats: t.int().nonnegative(),
	players: t.array(t.object({
		rid: E,
		treats: t.int().nonnegative(),
		yard: t.array(T),
		cards: t.array(ae),
		paws: t.int().nonnegative(),
		scoredCount: t.int().nonnegative()
	})),
	pending: t.object({
		dice: t.array(T),
		assigned: t.array(oe.nullable()),
		stage: t.enum([
			"roll",
			"chooseNumber",
			"chooseDice",
			"place"
		]),
		policy: t.enum([
			"normal",
			"fetch",
			"guard",
			"hunt",
			"search",
			"scavenge"
		]),
		choices: t.array(t.int()).optional(),
		chosenNumber: t.int().optional(),
		selectCount: t.int().optional(),
		targetSum: t.int().optional(),
		yardTotal: t.int().optional(),
		canReroll: t.boolean(),
		partialReroll: t.boolean(),
		tag: t.literal("playDead").optional()
	}).nullable(),
	prompt: t.union([
		t.object({
			kind: t.literal("dig"),
			remaining: t.int().nonnegative()
		}),
		t.object({ kind: t.literal("trot") }),
		t.object({
			kind: t.literal("retrieve"),
			values: t.array(T)
		}),
		t.object({ kind: t.literal("dogpile") }),
		t.object({
			kind: t.literal("boltChoose"),
			max: t.int().nonnegative()
		})
	]).nullable(),
	repeatKind: t.enum([
		"optional",
		"repeat",
		"bolt"
	]).nullable(),
	boltRemaining: t.int().nonnegative(),
	chaseCount: t.int().nonnegative(),
	winner: t.array(E).optional()
}), se = t.object({}), A = (e, t) => ({
	code: e,
	params: t
}), ce = (e) => structuredClone(e), j = (e) => e.phase === "play";
function M(t, n) {
	let r = e(t.seed, t.cursor, n);
	return t.cursor += 1, r;
}
function le(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; --t) {
		let r = M(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
var ue = (e) => e.players[e.turnIdx], N = (e) => e.cards.filter((e) => !e.scored), P = (e) => e.placed.every((e) => e !== null), F = (e) => e.cards.filter((e) => e.scored).length, I = (e) => N(e).reduce((e, t) => e + C[t.def].paws, 0), de = (e) => e.yard.reduce((e, t) => e + t, 0), L = (e) => N(e).filter((e) => !P(e)).length;
function fe(e) {
	return e.uidSeq += 1, `dog${e.uidSeq}`;
}
function pe(e, t, n) {
	let r = 0;
	for (let i = 0; i < n && !(e.deck.length === 0 || t.cards.length >= 6); i += 1) {
		let n = e.deck.pop();
		t.cards.push({
			uid: fe(e),
			def: n,
			placed: Array(C[n].spaces.length).fill(null),
			scored: !1
		}), r += 1;
	}
	return r;
}
function R(e, t, n) {
	let r = Math.max(0, Math.min(n, e.supplyTreats));
	return r > 0 && (t.treats += r, e.supplyTreats -= r), r;
}
function me(e, t) {
	return t.treats <= 0 ? !1 : (--t.treats, e.supplyTreats += 1, !0);
}
function he(e) {
	let t = 0;
	for (let n of e.cards) for (let e = 0; e < n.placed.length; e += 1) n.placed[e] !== null && (n.placed[e] = null, t += 1);
	return t;
}
function z(e, t) {
	let n = he(t);
	n += t.yard.length, t.yard = [], e.pending && t === ue(e) && (n += e.pending.assigned.filter((e) => e === null).length, e.pending = null), e.supplyDice += n;
}
function ge(e) {
	let t = e.players.map((e, t) => t);
	for (; t.length > 1;) {
		let n = 0;
		for (let r of t) {
			let t = M(e, 6) + 1;
			e.players[r].yard = [t], n = Math.max(n, t);
		}
		t = t.filter((t) => e.players[t].yard[0] === n);
	}
	return t[0] ?? 0;
}
function _e(e, t, n) {
	let r = O.parse(e), i = {
		players: t.map((e) => ({
			rid: e,
			treats: 1,
			yard: [],
			cards: []
		})),
		turnIdx: 0,
		phase: "play",
		winner: [],
		config: r,
		seed: n,
		cursor: 0,
		tiles: x[r.trickSet].tricks.map((e) => ({
			id: e,
			faceup: !0,
			treats: 0
		})),
		deck: [],
		supplyDice: 40 - t.length,
		supplyTreats: 40 - t.length,
		activeTrick: null,
		stepIdx: 0,
		pending: null,
		prompt: null,
		awaiting: "action",
		repeatKind: null,
		boltRemaining: 0,
		chaseCount: 0,
		uidSeq: 0
	};
	i.deck = le(i, C.map((e) => e.id));
	for (let e of i.players) pe(i, e, 2);
	i.turnIdx = ge(i);
	let a = [{
		kind: "setup",
		data: { first: i.players[i.turnIdx].rid }
	}];
	return ye(i, a, !0), {
		state: i,
		fx: a
	};
}
function ve(e, t) {
	let n = e.tiles.filter((e) => e.faceup);
	if (n.length === 1) {
		e.supplyTreats > 0 && (--e.supplyTreats, n[0].treats += 1);
		for (let t of e.tiles) t.faceup = !0;
		t.push({
			kind: "reset",
			data: {
				id: n[0].id,
				treats: n[0].treats
			}
		});
	}
}
function ye(e, t, n = !1) {
	if (j(e)) {
		if (ve(e, t), e.supplyDice === 0) {
			for (let t of e.players) z(e, t);
			t.push({ kind: "diceOut" });
		}
		e.activeTrick = null, e.stepIdx = 0, e.pending = null, e.prompt = null, e.repeatKind = null, e.boltRemaining = 0, e.chaseCount = 0, e.awaiting = "action", n || t.push({
			kind: "turnStart",
			rid: ue(e).rid
		});
	}
}
function be(e, t) {
	j(e) && (e.turnIdx = (e.turnIdx + 1) % e.players.length, ye(e, t));
}
function xe(e, t, n) {
	return F(t) < 6 ? !1 : (e.phase = "done", e.winner = [t.rid], e.activeTrick = null, e.stepIdx = 0, e.pending = null, e.prompt = null, e.repeatKind = null, e.awaiting = "action", n.push({
		kind: "win",
		rid: t.rid
	}), !0);
}
function Se(e, t, n, r) {
	let i = N(t).filter(P);
	if (i.length === 0) return 0;
	for (let t of i) {
		for (let n = 0; n < t.placed.length; n += 1) t.placed[n] !== null && (t.placed[n] = null, e.supplyDice += 1);
		t.scored = !0;
	}
	let a = pe(e, t, Math.min(i.length, 6 - t.cards.length));
	return n.push({
		kind: r ? "fastScore" : "score",
		rid: t.rid,
		data: {
			n: i.length,
			drawn: a
		}
	}), a > 0 && n.push({
		kind: "draw",
		rid: t.rid,
		data: { n: a }
	}), i.length;
}
function Ce(e, t, n) {
	z(e, t), e.activeTrick = null, e.stepIdx = 0, e.prompt = null, e.repeatKind = null, e.boltRemaining = 0, e.chaseCount = 0, e.awaiting = "action", n.push({
		kind: "bust",
		rid: t.rid
	}), be(e, n);
}
function B(e, t, n) {
	j(e) && (e.stepIdx += 1, je(e, t, n));
}
function we(e) {
	return e.activeTrick ? b[e.activeTrick].ops[e.stepIdx] ?? null : null;
}
function Te(e, t) {
	return t === "pawsPlus" ? 2 + I(e) : t === "buried" ? e.yard.length : t === "incompleteDogs" ? L(e) : t;
}
function V(e, t, n, r, i) {
	let a;
	if (i.fromYard) {
		if (t.yard.length === 0) return !1;
		a = t.yard.map(() => M(e, 6) + 1), t.yard = [];
	} else {
		let t = i.extra ?? 0, r = Math.min(n, e.supplyDice);
		if (r <= 0) return !1;
		e.supplyDice -= r, a = Array.from({ length: r }, () => M(e, 6) + 1), t > 0 && a.push(M(e, 6) + 1);
	}
	return a.length !== 0 && (e.pending = {
		dice: a,
		assigned: Array(a.length).fill(null),
		stage: "roll",
		policy: i.policy ?? "normal",
		canReroll: !0,
		partialReroll: i.partialReroll ?? !1,
		...i.tag ? { tag: i.tag } : {},
		resume: i.resume
	}, e.prompt = null, e.awaiting = "roll", e.repeatKind = null, r.push({
		kind: "roll",
		rid: t.rid,
		data: { dice: a }
	}), !0);
}
function Ee(e, t) {
	for (let n = 1; n < 1 << e.length; n += 1) {
		let r = 0;
		for (let t = 0; t < e.length; t += 1) n & 1 << t && (r += e[t]);
		if (r === t) return !0;
	}
	return !1;
}
function De(e, t, n) {
	let r = e.pending;
	if (r.policy === "guard") {
		let i = r.chosenNumber ?? 6, a = [], o = 0;
		for (let e of r.dice) e > i ? o += 1 : a.push(e);
		e.supplyDice += o, r.dice = a, r.assigned = Array(a.length).fill(null), r.stage = "place", e.awaiting = "place", o > 0 && n.push({
			kind: "discard",
			rid: t.rid,
			data: { n: o }
		}), a.length === 0 && U(e, t, n);
		return;
	}
	if (r.policy === "fetch") {
		r.choices = [...new Set(r.dice)].sort((e, t) => e - t), r.stage = "chooseNumber", e.awaiting = "chooseNumber";
		return;
	}
	if (r.policy === "hunt") {
		r.selectCount = Math.min(2, r.dice.length), r.stage = "chooseDice", e.awaiting = "chooseDice", r.dice.length <= 2 && H(e, t, n, r.dice.map((e, t) => t));
		return;
	}
	if (r.policy === "search") {
		r.targetSum = 8, r.stage = "chooseDice", e.awaiting = "chooseDice", Ee(r.dice, 8) || H(e, t, n, []);
		return;
	}
	if (r.policy === "scavenge") {
		r.yardTotal = de(t), r.stage = "chooseDice", e.awaiting = "chooseDice", r.dice.some((e) => e < r.yardTotal) || H(e, t, n, []);
		return;
	}
	r.stage = "place", e.awaiting = "place";
}
function H(e, t, n, r) {
	let i = e.pending, a = [...new Set(r)], o = i.policy === "hunt" || i.policy === "search", s = new Set(o ? a : i.dice.map((e, t) => t).filter((e) => !a.includes(e))), c = [], l = 0;
	i.dice.forEach((e, t) => {
		s.has(t) ? c.push(e) : l += 1;
	}), e.supplyDice += l, i.dice = c, i.assigned = Array(c.length).fill(null), i.stage = "place", i.selectCount = void 0, i.targetSum = void 0, i.yardTotal = void 0, e.awaiting = "place", l > 0 && n.push({
		kind: "discard",
		rid: t.rid,
		data: { n: l }
	}), c.length === 0 && U(e, t, n);
}
function Oe(e, t, n, r, i) {
	let a = e.pending;
	if (a.assigned[n] = { kind: "yard" }, t.yard.push(r), i.push({
		kind: "bury",
		rid: t.rid,
		data: { die: r }
	}), de(t) > 7) {
		Ce(e, t, i);
		return;
	}
	a.assigned.every((e) => e !== null) && U(e, t, i);
}
function ke(e, t, n, r, i, a, o) {
	let s = e.pending;
	s.assigned[n] = {
		kind: "dog",
		card: r.uid,
		space: i
	}, r.placed[i] = a, o.push({
		kind: "place",
		rid: t.rid,
		data: {
			die: a,
			card: r.uid,
			space: i,
			def: r.def
		}
	}), s.assigned.every((e) => e !== null) && U(e, t, o);
}
function Ae(e) {
	return e.yard.length > 0 || e.cards.some((e) => !e.scored && e.placed.some((e) => e !== null));
}
function U(e, t, n) {
	if (!e.pending) return;
	let r = e.pending, i = r.tag === "playDead" && r.assigned.some((e) => e?.kind === "yard"), a = r.tag === "playDead" ? r.dice[0] : 0, o = r.resume;
	if (e.pending = null, e.repeatKind = null, e.awaiting = "action", i && a > 0) {
		let r = R(e, t, a);
		n.push({
			kind: "treat",
			rid: t.rid,
			data: { n: r }
		});
	}
	if (N(t).length > 0 && N(t).every(P) && (Se(e, t, n, !0), xe(e, t, n))) return;
	if (o === "stepDone") {
		B(e, t, n);
		return;
	}
	let s = we(e);
	if (o === "bolt") {
		e.boltRemaining = Math.max(0, e.boltRemaining - 1), e.boltRemaining > 0 && e.supplyDice > 0 ? (e.awaiting = "repeat", e.repeatKind = "bolt") : B(e, t, n);
		return;
	}
	if (!s) {
		B(e, t, n);
		return;
	}
	if (s.op === "chase") {
		e.supplyDice > 0 ? (e.awaiting = "repeat", e.repeatKind = "repeat") : B(e, t, n);
		return;
	}
	if (s.op === "sprint") {
		e.supplyDice > 0 && L(t) > 0 ? (e.awaiting = "repeat", e.repeatKind = "repeat") : B(e, t, n);
		return;
	}
	if (s.op === "dogpile") {
		e.supplyDice > 0 && Ae(t) ? (e.awaiting = "repeat", e.repeatKind = "repeat") : B(e, t, n);
		return;
	}
	e.supplyDice > 0 ? (e.awaiting = "repeat", e.repeatKind = "repeat") : B(e, t, n);
}
function je(e, t, n) {
	if (!j(e)) return;
	let r = we(e);
	if (!r) {
		e.activeTrick = null, e.stepIdx = 0, be(e, n);
		return;
	}
	switch (r.op) {
		case "drawDog":
			t.cards.length < 6 && pe(e, t, 1) > 0 && n.push({
				kind: "draw",
				rid: t.rid,
				data: { n: 1 }
			}), B(e, t, n);
			return;
		case "treat":
			Me(e, t, r.mode, n), B(e, t, n);
			return;
		case "roll": {
			if (r.chooseFirst) {
				e.pending = {
					dice: [],
					assigned: [],
					stage: "chooseNumber",
					policy: "guard",
					canReroll: !1,
					partialReroll: !1,
					resume: "stepDone"
				}, e.awaiting = "chooseNumber";
				return;
			}
			if (r.optional) {
				e.awaiting = "repeat", e.repeatKind = "optional";
				return;
			}
			let i = Te(t, r.count);
			if (i <= 0) {
				B(e, t, n);
				return;
			}
			V(e, t, i, n, {
				policy: r.policy,
				partialReroll: r.partialReroll,
				tag: r.tag,
				resume: r.repeat ? "repeat" : "stepDone",
				fromYard: r.count === "buried"
			}) || B(e, t, n);
			return;
		}
		case "chase":
			e.chaseCount = 1, V(e, t, 1, n, { resume: "repeat" }) || B(e, t, n);
			return;
		case "sprint": {
			let r = L(t);
			(r <= 0 || !V(e, t, r, n, { resume: "repeat" })) && B(e, t, n);
			return;
		}
		case "bolt": {
			let r = Math.min(12, e.supplyDice);
			if (r <= 0) {
				B(e, t, n);
				return;
			}
			e.prompt = {
				kind: "boltChoose",
				max: r
			}, e.awaiting = "bolt";
			return;
		}
		case "dogpile":
			if (!Ae(t)) {
				V(e, t, 2, n, { resume: "repeat" }) || B(e, t, n);
				return;
			}
			e.prompt = { kind: "dogpile" }, e.awaiting = "dogpile";
			return;
		case "dig": {
			let r = I(t);
			if (r <= 0) {
				B(e, t, n);
				return;
			}
			e.prompt = {
				kind: "dig",
				remaining: r
			}, e.awaiting = "dig";
			return;
		}
		case "trot":
			if (!Ne(t)) {
				B(e, t, n);
				return;
			}
			e.prompt = { kind: "trot" }, e.awaiting = "trot";
			return;
		case "retrieve": {
			let r = e.deck[e.deck.length - 1];
			if (r === void 0 || e.supplyDice <= 0) {
				B(e, t, n);
				return;
			}
			e.prompt = {
				kind: "retrieve",
				values: [...new Set(C[r].spaces)].sort((e, t) => e - t)
			}, e.awaiting = "retrieve";
			return;
		}
	}
}
function Me(e, t, n, r) {
	if (n === "beg") {
		let n = R(e, t, 1 + I(t));
		r.push({
			kind: "treat",
			rid: t.rid,
			data: { n }
		});
		return;
	}
	if (n === "chew") {
		let n = Math.min(t.treats, e.supplyTreats);
		t.treats += n, e.supplyTreats -= n;
		let i = R(e, t, 1);
		r.push({
			kind: "treat",
			rid: t.rid,
			data: { n: n + i }
		});
		return;
	}
	if (n === "gobble") {
		let n = R(e, t, 7), i = 0;
		for (let e of N(t)) {
			let t = C[e.def];
			e.placed.forEach((e, n) => {
				e === null && (i = Math.max(i, t.spaces[n]));
			});
		}
		let a = Math.min(t.treats, i);
		t.treats -= a, e.supplyTreats += a, r.push({
			kind: "treat",
			rid: t.rid,
			data: { n: n - a }
		});
		return;
	}
	if (n === "stay") {
		let n = e.tiles.filter((e) => !e.faceup && e.id !== "stay").length, i = R(e, t, n);
		r.push({
			kind: "treat",
			rid: t.rid,
			data: { n: i }
		});
		return;
	}
}
function Ne(e) {
	let t = N(e).some((e) => e.placed.some((e) => e === null)), n = N(e).some((e) => e.placed.some((e) => e !== null));
	return t && n;
}
function Pe(e, t) {
	let n = e.placed[t];
	return n === null ? null : (e.placed[t] = null, n);
}
var Fe = {
	meta: ne,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ie,
		publicView: k,
		privateView: se,
		config: O
	},
	setup: _e,
	reduce(e, t, n) {
		if (t.type === "tick") return { state: e };
		if (!j(e)) return A("games.spots.errBadAction");
		let r = ce(e), i = ue(r);
		if (i.rid !== n.by) return A("games.spots.errNotYourTurn");
		let a = [];
		if (t.type === "trick") {
			if (r.awaiting !== "action") return A("games.spots.errBadAction");
			let e = r.tiles.find((e) => e.id === t.id);
			return !e || !e.faceup ? A("games.spots.errNoTrick") : (i.treats += e.treats, e.treats = 0, e.faceup = !1, r.activeTrick = t.id, r.stepIdx = 0, r.repeatKind = null, r.pending = null, r.prompt = null, a.push({
				kind: "trick",
				rid: i.rid,
				data: { id: t.id }
			}), je(r, i, a), {
				state: r,
				fx: a
			});
		}
		if (t.type === "score") return r.awaiting === "action" ? N(i).some(P) ? (Se(r, i, a, !1) > 0 && xe(r, i, a) || be(r, a), {
			state: r,
			fx: a
		}) : A("games.spots.errNoCompleted") : A("games.spots.errBadAction");
		if (t.type === "reroll") {
			let e = r.pending;
			if (!e || e.stage !== "roll" || r.awaiting !== "roll" || !e.canReroll) return A("games.spots.errBadAction");
			if (i.treats <= 0) return A("games.spots.errNoTreat");
			let n;
			if (e.partialReroll) {
				let r = t.dice ?? e.dice.map((e, t) => t);
				if (n = [...new Set(r)], n.length === 0 || n.some((t) => !Number.isInteger(t) || t < 0 || t >= e.dice.length)) return A("games.spots.errBadDice");
			} else n = e.dice.map((e, t) => t);
			me(r, i);
			for (let t of n) e.dice[t] = M(r, 6) + 1;
			return a.push({
				kind: "reroll",
				rid: i.rid,
				data: {
					dice: e.dice,
					indices: n
				}
			}), {
				state: r,
				fx: a
			};
		}
		if (t.type === "beginPlace") {
			let e = r.pending;
			return !e || e.stage !== "roll" || r.awaiting !== "roll" ? A("games.spots.errBadAction") : (De(r, i, a), {
				state: r,
				fx: a
			});
		}
		if (t.type === "chooseNumber") {
			let e = r.pending;
			if (!e || e.stage !== "chooseNumber" || r.awaiting !== "chooseNumber") return A("games.spots.errBadAction");
			if (e.policy === "guard" && e.dice.length === 0) return e.chosenNumber = t.value, V(r, i, 4, a, {
				policy: "guard",
				resume: "stepDone"
			}) || B(r, i, a), {
				state: r,
				fx: a
			};
			if (e.policy === "fetch") {
				if (!e.choices?.includes(t.value)) return A("games.spots.errBadNumber");
				let n = e.dice.filter((e) => e === t.value);
				return r.supplyDice += e.dice.length - n.length, e.dice = n, e.assigned = Array(n.length).fill(null), e.choices = void 0, e.chosenNumber = t.value, e.stage = "place", r.awaiting = "place", e.dice.length === 0 && U(r, i, a), {
					state: r,
					fx: a
				};
			}
			return A("games.spots.errBadAction");
		}
		if (t.type === "chooseDice") {
			let e = r.pending;
			if (!e || e.stage !== "chooseDice" || r.awaiting !== "chooseDice") return A("games.spots.errBadAction");
			let n = [...new Set(t.dice)];
			if (n.some((t) => !Number.isInteger(t) || t < 0 || t >= e.dice.length)) return A("games.spots.errBadDice");
			if (e.policy === "hunt") {
				if (n.length !== e.selectCount) return A("games.spots.errBadDice");
			} else if (e.policy === "search") {
				let t = n.reduce((t, n) => t + e.dice[n], 0);
				if (n.length === 0 || t !== e.targetSum) return A("games.spots.errBadDice");
			} else if (e.policy === "scavenge") {
				if (n.some((t) => e.dice[t] >= e.yardTotal)) return A("games.spots.errBadDice");
			} else return A("games.spots.errBadAction");
			return H(r, i, a, n), {
				state: r,
				fx: a
			};
		}
		if (t.type === "placeDie") {
			let e = r.pending;
			if (!e || e.stage !== "place" || r.awaiting !== "place") return A("games.spots.errBadAction");
			let n = t.die;
			if (!Number.isInteger(n) || n < 0 || n >= e.dice.length || e.assigned[n]) return A("games.spots.errBadDice");
			let o = i.cards.find((e) => e.uid === t.card);
			if (!o || o.scored || t.space < 0 || t.space >= o.placed.length || o.placed[t.space] !== null) return A("games.spots.errBadSpace");
			let s = e.dice[n];
			return C[o.def].spaces[t.space] === s ? (ke(r, i, n, o, t.space, s, a), {
				state: r,
				fx: a
			}) : A("games.spots.errBadSpace");
		}
		if (t.type === "buryDie") {
			let e = r.pending;
			if (!e || e.stage !== "place" || r.awaiting !== "place") return A("games.spots.errBadAction");
			let n = t.die;
			return !Number.isInteger(n) || n < 0 || n >= e.dice.length || e.assigned[n] ? A("games.spots.errBadDice") : (Oe(r, i, n, e.dice[n], a), {
				state: r,
				fx: a
			});
		}
		if (t.type === "autoPlace") {
			let e = r.pending;
			if (!e || e.stage !== "place" || r.awaiting !== "place") return A("games.spots.errBadAction");
			for (let t = 0; t < e.dice.length; t += 1) {
				if (!r.pending || e.assigned[t]) continue;
				let n = e.dice[t], o = N(i).find((e) => C[e.def].spaces.some((t, r) => t === n && e.placed[r] === null));
				if (o) {
					let e = C[o.def].spaces.findIndex((e, t) => e === n && o.placed[t] === null);
					ke(r, i, t, o, e, n, a);
				}
			}
			if (!r.pending) return {
				state: r,
				fx: a
			};
			for (let t = 0; t < e.dice.length; t += 1) r.pending && !e.assigned[t] && Oe(r, i, t, e.dice[t], a);
			return {
				state: r,
				fx: a
			};
		}
		if (t.type === "finishPlacement") {
			let e = r.pending;
			if (!e || e.stage !== "place" || r.awaiting !== "place") return A("games.spots.errBadAction");
			for (let t = 0; t < e.dice.length; t += 1) r.pending && !e.assigned[t] && Oe(r, i, t, e.dice[t], a);
			return {
				state: r,
				fx: a
			};
		}
		if (t.type === "dig") {
			if (!r.prompt || r.prompt.kind !== "dig" || r.awaiting !== "dig") return A("games.spots.errBadAction");
			let e = r.players.find((e) => e.rid === t.rid);
			if (!e || t.index >= e.yard.length) return A("games.spots.errNoTarget");
			let n = e.yard[t.index];
			if (t.delta === 1) {
				if (n >= 6) return A("games.spots.errBadDice");
				e.yard[t.index] = n + 1;
			} else n <= 1 ? (e.yard.splice(t.index, 1), r.supplyDice += 1) : e.yard[t.index] = n - 1;
			if (a.push({
				kind: "dig",
				rid: i.rid,
				data: {
					target: e.rid,
					delta: t.delta
				}
			}), de(e) > 7) {
				if (e === i) return Ce(r, i, a), {
					state: r,
					fx: a
				};
				z(r, e), a.push({
					kind: "bust",
					rid: e.rid
				});
			}
			return --r.prompt.remaining, r.prompt.remaining <= 0 && (r.prompt = null, B(r, i, a)), {
				state: r,
				fx: a
			};
		}
		if (t.type === "skipDig") return !r.prompt || r.prompt.kind !== "dig" || r.awaiting !== "dig" ? A("games.spots.errBadAction") : (r.prompt = null, B(r, i, a), {
			state: r,
			fx: a
		});
		if (t.type === "trot") {
			if (!r.prompt || r.prompt.kind !== "trot" || r.awaiting !== "trot") return A("games.spots.errBadAction");
			let e = i.cards.find((e) => e.uid === t.card), n = i.cards.find((e) => e.uid === t.toCard);
			return !e || !n || e.scored || n.scored || t.space < 0 || t.space >= e.placed.length || e.placed[t.space] === null || t.toSpace < 0 || t.toSpace >= n.placed.length || n.placed[t.toSpace] !== null || e.uid === n.uid && t.space === t.toSpace ? A("games.spots.errBadSpace") : (Pe(e, t.space), n.placed[t.toSpace] = C[n.def].spaces[t.toSpace], a.push({
				kind: "trot",
				rid: i.rid,
				data: {
					die: C[n.def].spaces[t.toSpace],
					card: n.uid,
					space: t.toSpace
				}
			}), r.prompt = null, N(i).length > 0 && N(i).every(P) && (Se(r, i, a, !0), xe(r, i, a)) || B(r, i, a), {
				state: r,
				fx: a
			});
		}
		if (t.type === "skipTrot") return !r.prompt || r.prompt.kind !== "trot" || r.awaiting !== "trot" ? A("games.spots.errBadAction") : (r.prompt = null, B(r, i, a), {
			state: r,
			fx: a
		});
		if (t.type === "retrieve") return !r.prompt || r.prompt.kind !== "retrieve" || r.awaiting !== "retrieve" ? A("games.spots.errBadAction") : r.prompt.values.includes(t.value) ? r.supplyDice <= 0 ? A("games.spots.errNoDie") : (--r.supplyDice, r.prompt = null, r.pending = {
			dice: [t.value],
			assigned: [null],
			stage: "place",
			policy: "normal",
			canReroll: !1,
			partialReroll: !1,
			resume: "stepDone"
		}, r.awaiting = "place", a.push({
			kind: "retrieve",
			rid: i.rid,
			data: { die: t.value }
		}), {
			state: r,
			fx: a
		}) : A("games.spots.errBadNumber");
		if (t.type === "skipRetrieve") return !r.prompt || r.prompt.kind !== "retrieve" || r.awaiting !== "retrieve" || r.supplyDice > 0 ? A("games.spots.errBadAction") : (r.prompt = null, B(r, i, a), {
			state: r,
			fx: a
		});
		if (t.type === "dogpileSource") {
			if (!r.prompt || r.prompt.kind !== "dogpile" || r.awaiting !== "dogpile") return A("games.spots.errBadAction");
			let e = 0;
			if (t.from === "yard") {
				if (t.index === void 0 || t.index >= i.yard.length) return A("games.spots.errNoTarget");
				i.yard.splice(t.index, 1), e = 1;
			} else if (t.from === "dog") {
				let n = i.cards.find((e) => e.uid === t.card);
				if (!n || n.scored || t.space === void 0 || n.placed[t.space] === null) return A("games.spots.errNoTarget");
				Pe(n, t.space), e = 1;
			}
			return r.prompt = null, V(r, i, 2, a, {
				resume: "repeat",
				extra: e
			}) || B(r, i, a), {
				state: r,
				fx: a
			};
		}
		if (t.type === "boltChoose") {
			if (!r.prompt || r.prompt.kind !== "boltChoose" || r.awaiting !== "bolt") return A("games.spots.errBadAction");
			let e = Math.min(t.count, r.prompt.max);
			return e < 1 ? A("games.spots.errBadAction") : (r.boltRemaining = e, r.prompt = null, V(r, i, 1, a, { resume: "bolt" }) || B(r, i, a), {
				state: r,
				fx: a
			});
		}
		if (t.type === "repeat") {
			if (!r.repeatKind) return A("games.spots.errBadAction");
			let e = r.repeatKind, t = we(r);
			if (!t) return A("games.spots.errBadAction");
			if (e === "bolt") return r.repeatKind = null, V(r, i, 1, a, { resume: "bolt" }) || B(r, i, a), {
				state: r,
				fx: a
			};
			if (e === "optional") return r.repeatKind = null, t.op === "roll" ? (V(r, i, Te(i, t.count), a, {
				policy: t.policy,
				partialReroll: t.partialReroll,
				tag: t.tag,
				resume: t.repeat ? "repeat" : "stepDone",
				fromYard: t.count === "buried"
			}) || B(r, i, a), {
				state: r,
				fx: a
			}) : A("games.spots.errBadAction");
			if (r.repeatKind = null, t.op === "chase") return r.chaseCount += 1, V(r, i, r.chaseCount, a, { resume: "repeat" }) || B(r, i, a), {
				state: r,
				fx: a
			};
			if (t.op === "sprint") {
				let e = L(i);
				return (e <= 0 || !V(r, i, e, a, { resume: "repeat" })) && B(r, i, a), {
					state: r,
					fx: a
				};
			}
			return t.op === "dogpile" ? Ae(i) ? (r.prompt = { kind: "dogpile" }, r.awaiting = "dogpile", {
				state: r,
				fx: a
			}) : (B(r, i, a), {
				state: r,
				fx: a
			}) : (V(r, i, 1, a, { resume: "repeat" }) || B(r, i, a), {
				state: r,
				fx: a
			});
		}
		return t.type === "stop" && r.repeatKind ? r.repeatKind === "bolt" && I(i) < r.boltRemaining ? A("games.spots.errCannotStop") : (r.repeatKind = null, r.boltRemaining = 0, B(r, i, a), {
			state: r,
			fx: a
		}) : A("games.spots.errBadAction");
	},
	viewFor(e) {
		return {
			public: {
				phase: e.phase,
				turn: e.players[e.turnIdx]?.rid ?? null,
				awaiting: e.awaiting,
				config: e.config,
				tiles: e.tiles.map((e) => ({
					id: e.id,
					faceup: e.faceup,
					treats: e.treats
				})),
				activeTrick: e.activeTrick,
				stepIdx: e.stepIdx,
				deckCount: e.deck.length,
				deckTop: e.deck.length ? e.deck[e.deck.length - 1] : null,
				supplyDice: e.supplyDice,
				supplyTreats: e.supplyTreats,
				players: e.players.map((e) => ({
					rid: e.rid,
					treats: e.treats,
					yard: [...e.yard],
					cards: e.cards.map((e) => ({
						uid: e.uid,
						def: e.def,
						placed: [...e.placed],
						scored: e.scored
					})),
					paws: I(e),
					scoredCount: F(e)
				})),
				pending: e.pending ? {
					dice: [...e.pending.dice],
					assigned: e.pending.assigned.map((e) => e ? { ...e } : null),
					stage: e.pending.stage,
					policy: e.pending.policy,
					...e.pending.choices ? { choices: [...e.pending.choices] } : {},
					...e.pending.chosenNumber ? { chosenNumber: e.pending.chosenNumber } : {},
					...e.pending.selectCount ? { selectCount: e.pending.selectCount } : {},
					...e.pending.targetSum ? { targetSum: e.pending.targetSum } : {},
					...e.pending.yardTotal === void 0 ? {} : { yardTotal: e.pending.yardTotal },
					canReroll: e.pending.canReroll,
					partialReroll: e.pending.partialReroll,
					...e.pending.tag ? { tag: e.pending.tag } : {}
				} : null,
				prompt: e.prompt ? { ...e.prompt } : null,
				repeatKind: e.repeatKind,
				boltRemaining: e.boltRemaining,
				chaseCount: e.chaseCount,
				...e.winner.length ? { winner: [...e.winner] } : {}
			},
			private: {}
		};
	},
	status(e) {
		let t = Object.fromEntries(e.players.map((e) => [e.rid, F(e)])), n = (t) => e.players.indexOf(t), r = [...e.players].sort((e, t) => F(t) - F(e) || t.treats - e.treats || n(e) - n(t)).map((e) => e.rid);
		return {
			phase: e.phase,
			...e.winner.length ? {
				winner: e.winner,
				ranking: r,
				scores: t
			} : {}
		};
	}
}, Ie = {
	die: null,
	reroll: [],
	dice: [],
	trot: null
};
function Le(e) {
	e.target.closest("button") && e.preventDefault();
}
var Re = {
	1: [4],
	2: [0, 8],
	3: [
		0,
		4,
		8
	],
	4: [
		0,
		2,
		6,
		8
	],
	5: [
		0,
		2,
		4,
		6,
		8
	],
	6: [
		0,
		2,
		3,
		5,
		6,
		8
	]
}, ze = {
	1: [[50, 50]],
	2: [[50, 32], [50, 70]],
	3: [
		[50, 30],
		[29, 68],
		[71, 68]
	],
	4: [
		[31, 32],
		[69, 32],
		[31, 70],
		[69, 70]
	],
	5: [
		[25, 30],
		[50, 30],
		[75, 30],
		[37, 70],
		[63, 70]
	],
	6: [
		[25, 31],
		[50, 31],
		[75, 31],
		[25, 69],
		[50, 69],
		[75, 69]
	]
};
function Be(e) {
	return /* @__PURE__ */ d(Ve, {
		pub: e.public,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ve(e) {
	return /* @__PURE__ */ d(He, { ...e });
}
function He({ pub: e, members: t, myRid: r, send: u }) {
	let p = a(), m = i((e) => e.locale), h = e.players.find((e) => e.rid === r), g = (e) => e ? t.find((t) => t.rid === e)?.name ?? p("lobby.you") : "", _ = e.phase === "play" && e.turn === r, v = `${e.pending?.stage ?? ""}|${e.pending?.dice.join(",") ?? ""}|${e.awaiting}|${e.stepIdx}`, [y, b] = n({
		key: v,
		...Ie
	}), ee = y.key === v ? y : {
		key: v,
		...Ie
	}, x = (e) => b((t) => ({
		key: v,
		...t.key === v ? t : Ie,
		...e
	})), { die: S, reroll: C, dice: te, trot: w } = ee, T = (e) => x({ die: e }), E = (e) => x({ reroll: e }), D = (e) => x({ dice: e }), re = (e) => x({ trot: e }), O = Ue(e, _, g, p), ie = h ? h.cards.filter((e) => !e.scored && e.placed.every((e) => e !== null)).length : 0, ae = e.players.filter((e) => e.rid !== r), oe = /* @__PURE__ */ d(it, {
		pub: e,
		me: h,
		myTurn: _,
		completed: ie,
		selectedDie: S,
		setSelectedDie: T,
		rerollPicks: C,
		setRerollPicks: E,
		dicePicks: te,
		setDicePicks: D,
		send: u,
		t: p
	}), k = t.find((e) => e.rid === r), se = k ? l(k, m) : g(r);
	return /* @__PURE__ */ d("div", {
		className: "sp-screen",
		children: /* @__PURE__ */ d(o, {
			adaptive: !0,
			scroll: !1,
			actionsHeight: "sp-action-slot",
			banner: /* @__PURE__ */ d("div", {
				className: "sp-banner",
				children: /* @__PURE__ */ d(s, {
					tone: O.tone,
					text: O.text,
					sub: O.sub,
					accent: ne.accent
				})
			}),
			actions: oe,
			children: /* @__PURE__ */ d("div", {
				className: "sp-table",
				children: /* @__PURE__ */ f("div", {
					className: "sp-layout",
					children: [/* @__PURE__ */ d("section", {
						className: "sp-tricks",
						"aria-label": p("games.spots.chooseTrick"),
						onMouseDown: Le,
						children: e.tiles.map((t) => /* @__PURE__ */ d(Je, {
							tile: t,
							active: e.activeTrick === t.id,
							disabled: !_ || e.awaiting !== "action" || !t.faceup,
							onClick: () => u({
								type: "trick",
								id: t.id
							})
						}, t.id))
					}), /* @__PURE__ */ f("div", {
						className: "sp-body",
						onMouseDown: Le,
						children: [
							h && /* @__PURE__ */ f("section", {
								className: "sp-my-pack",
								children: [
									/* @__PURE__ */ f("header", {
										className: "sp-me-head",
										children: [
											k && /* @__PURE__ */ d(c, {
												m: k,
												myRid: r,
												action: _ && e.awaiting === "action" && !e.pending ? "pending" : null,
												anchorName: `row:${r}`,
												box: "size-6",
												img: "size-5"
											}),
											/* @__PURE__ */ d("span", {
												className: "sp-me-name",
												children: se
											}),
											/* @__PURE__ */ f("span", {
												className: "sp-me-stat",
												children: [/* @__PURE__ */ d("span", {
													className: "sp-me-label",
													children: p("games.spots.scoredLabel")
												}), /* @__PURE__ */ f("b", { children: [
													h.scoredCount,
													"/",
													6
												] })]
											}),
											/* @__PURE__ */ f("span", {
												className: "sp-me-stat",
												children: [/* @__PURE__ */ d(W, {}), h.treats]
											}),
											/* @__PURE__ */ f("span", {
												className: "sp-me-stat",
												children: [/* @__PURE__ */ d(G, {}), h.paws]
											})
										]
									}),
									/* @__PURE__ */ d(Ye, {
										pub: e,
										me: h,
										locale: m,
										selectedDie: S,
										setSelectedDie: T,
										rerollPicks: C,
										setRerollPicks: E,
										dicePicks: te,
										setDicePicks: D
									}),
									/* @__PURE__ */ d("div", {
										className: "sp-cards",
										"data-count": Math.min(h.cards.length, 6),
										children: h.cards.map((t) => /* @__PURE__ */ d(Qe, {
											card: t,
											locale: m,
											mine: !0,
											selectedDie: S !== null && e.pending?.stage === "place" ? e.pending.dice[S] : null,
											onPlace: (e) => {
												S !== null && (u({
													type: "placeDie",
													die: S,
													card: t.uid,
													space: e
												}), T(null));
											},
											trotSource: w,
											onTrotSource: (e) => re({
												card: t.uid,
												space: e
											}),
											onTrotTarget: (e) => {
												w && u({
													type: "trot",
													card: w.card,
													space: w.space,
													toCard: t.uid,
													toSpace: e
												});
											},
											trotActive: e.awaiting === "trot" && _,
											dogpileActive: e.awaiting === "dogpile" && _,
											onDogpile: (e) => u({
												type: "dogpileSource",
												from: "dog",
												card: t.uid,
												space: e
											})
										}, t.uid))
									}),
									/* @__PURE__ */ d($e, {
										rid: h.rid,
										dice: h.yard,
										digActive: e.awaiting === "dig" && _,
										dogpileActive: e.awaiting === "dogpile" && _,
										onDig: (e, t) => u({
											type: "dig",
											rid: h.rid,
											index: e,
											delta: t
										}),
										onDogpile: (e) => u({
											type: "dogpileSource",
											from: "yard",
											index: e
										}),
										t: p
									})
								]
							}),
							/* @__PURE__ */ f("aside", {
								className: "sp-public",
								"aria-label": p("games.spots.publicArea"),
								children: [
									/* @__PURE__ */ d("span", {
										className: "sp-public-title",
										children: p("games.spots.publicArea")
									}),
									/* @__PURE__ */ d(nt, {
										pub: e,
										locale: m,
										t: p
									}),
									/* @__PURE__ */ d(rt, {
										pub: e,
										t: p
									})
								]
							}),
							/* @__PURE__ */ f("section", {
								className: "sp-opponents",
								"aria-label": p("games.spots.otherPlayers"),
								children: [/* @__PURE__ */ d("h2", {
									className: "sp-opp-title",
									children: p("games.spots.otherPlayers")
								}), ae.map((n) => {
									let i = t.find((e) => e.rid === n.rid);
									return /* @__PURE__ */ d(tt, {
										p: n,
										member: i,
										myRid: r,
										name: i ? l(i, m) : g(n.rid),
										locale: m,
										digActive: e.awaiting === "dig" && _,
										onDig: (e, t) => u({
											type: "dig",
											rid: n.rid,
											index: e,
											delta: t
										}),
										t: p
									}, n.rid);
								})]
							})
						]
					})]
				})
			})
		})
	});
}
function Ue(e, t, n, r) {
	if (e.phase === "done") return {
		tone: "done",
		text: r("games.spots.gameOver", { name: n(e.winner?.[0] ?? null) })
	};
	if (t) {
		if (e.awaiting === "action") return {
			tone: "accent",
			text: r("games.spots.yourTurn"),
			sub: r("games.spots.chooseTrickSub")
		};
		if (e.awaiting === "roll") return {
			tone: "accent",
			text: r("games.spots.yourTurnRoll")
		};
		if (e.awaiting === "place") return {
			tone: "accent",
			text: r("games.spots.yourTurnPlace")
		};
		if (e.awaiting === "chooseNumber") return {
			tone: "accent",
			text: e.pending?.policy === "guard" ? r("games.spots.selectNumberGuard") : r("games.spots.selectNumberFetch")
		};
		if (e.awaiting === "chooseDice") return {
			tone: "accent",
			text: r("games.spots.selectDiceHint")
		};
		if (e.awaiting === "dig") return {
			tone: "accent",
			text: r("games.spots.digPrompt", { n: e.prompt?.kind === "dig" ? e.prompt.remaining : 0 })
		};
		if (e.awaiting === "trot") return {
			tone: "accent",
			text: r("games.spots.trotPrompt")
		};
		if (e.awaiting === "retrieve") return {
			tone: "accent",
			text: r("games.spots.retrievePrompt")
		};
		if (e.awaiting === "dogpile") return {
			tone: "accent",
			text: r("games.spots.dogpilePrompt")
		};
		if (e.awaiting === "bolt") return {
			tone: "accent",
			text: r("games.spots.boltPrompt")
		};
		if (e.awaiting === "repeat") return e.repeatKind === "bolt" ? {
			tone: "accent",
			text: r("games.spots.boltRemaining", { n: e.boltRemaining })
		} : {
			tone: "accent",
			text: e.repeatKind === "optional" ? r("games.spots.optionalPrompt") : r("games.spots.repeatPrompt")
		};
	}
	return e.turn && e.activeTrick ? {
		tone: "info",
		text: r("games.spots.waitingTrick", {
			name: n(e.turn),
			trick: r(`games.spots.trick${We(e.activeTrick)}`)
		})
	} : {
		tone: "info",
		text: r("games.spots.waitingTurn", { name: n(e.turn) })
	};
}
function We(e) {
	return e.charAt(0).toUpperCase() + e.slice(1);
}
function W({ className: e = "" }) {
	return /* @__PURE__ */ f("svg", {
		className: `sp-bone ${e}`,
		viewBox: "0 0 24 12",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ d("circle", {
				cx: "5",
				cy: "4",
				r: "3"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "5",
				cy: "8",
				r: "3"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "19",
				cy: "4",
				r: "3"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "19",
				cy: "8",
				r: "3"
			}),
			/* @__PURE__ */ d("rect", {
				x: "5",
				y: "4",
				width: "14",
				height: "4",
				rx: "2"
			})
		]
	});
}
function G({ className: e = "" }) {
	return /* @__PURE__ */ f("svg", {
		className: `sp-paw ${e}`,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ d("ellipse", {
				cx: "7",
				cy: "8",
				rx: "2.6",
				ry: "3.2"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "12",
				cy: "6",
				rx: "2.6",
				ry: "3.2"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "17",
				cy: "8",
				rx: "2.6",
				ry: "3.2"
			}),
			/* @__PURE__ */ d("path", { d: "M12 11c-3.4 0-6 2.5-6 5.1 0 1.8 1.5 2.9 3.2 2.3 1.8-.7 3.8-.7 5.6 0 1.7.6 3.2-.5 3.2-2.3 0-2.6-2.6-5.1-6-5.1Z" })
		]
	});
}
function K({ value: e, size: t = "md", muted: n = !1, aria: r }) {
	let i = Re[e] ?? [];
	return /* @__PURE__ */ d("span", {
		className: `sp-die sp-die--${t}${n ? " sp-die--muted" : ""}`,
		"aria-label": r,
		role: r ? "img" : void 0,
		children: Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ d("i", { className: i.includes(t) ? "on" : "" }, t))
	});
}
var Ge = 26, Ke = (() => {
	let e = [];
	for (let t = 0; t < 52; t += 1) {
		let n = Math.PI * t / Ge - Math.PI / 2, r = t % 2 == 0 ? 49 : 42;
		e.push(`${(50 + Math.cos(n) * r).toFixed(2)},${(50 + Math.sin(n) * r).toFixed(2)}`);
	}
	return `M${e.join("L")}Z`;
})();
function qe({ color: e, children: t }) {
	return /* @__PURE__ */ f("span", {
		className: "sp-rosette",
		style: { "--sp-rosette": e },
		children: [/* @__PURE__ */ f("svg", {
			viewBox: "0 0 100 112",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ d("path", {
					d: "M30 68 22 108 40 98 48 110 54 70Z",
					fill: "var(--sp-rosette-deep)",
					stroke: "var(--sp-ink)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ d("path", {
					d: "M70 68 78 108 60 98 52 110 46 70Z",
					fill: "var(--sp-rosette-deep)",
					stroke: "var(--sp-ink)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ d("path", {
					d: Ke,
					fill: "var(--sp-rosette)",
					stroke: "var(--sp-ink)",
					strokeWidth: "2.5"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "50",
					cy: "50",
					r: "30",
					fill: "none",
					stroke: "rgb(255 255 255 / .55)",
					strokeWidth: "1.5"
				})
			]
		}), /* @__PURE__ */ d("span", {
			className: "sp-rosette-label",
			children: t
		})]
	});
}
function Je({ tile: e, active: t, disabled: n, onClick: i }) {
	let o = a(), s = b[e.id], c = w[s.color], { ref: l, hidden: p } = r(`trick:${e.id}`);
	return /* @__PURE__ */ f("button", {
		ref: l,
		type: "button",
		className: `sp-trick${e.faceup ? "" : " sp-trick--down"}${t ? " sp-trick--active" : ""}${p ? " sp-hidden" : ""}`,
		style: { "--sp-trick": c },
		disabled: n,
		"aria-label": e.faceup ? o("games.spots.chooseTrickAria", { name: o(s.nameKey) }) : o("games.spots.trickFacedown"),
		onClick: i,
		children: [e.faceup ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(qe, {
			color: c,
			children: /* @__PURE__ */ d("span", { children: o(s.nameKey) })
		}), /* @__PURE__ */ d("span", {
			className: "sp-trick-desc",
			children: o(s.descKey)
		})] }) : /* @__PURE__ */ f("span", {
			className: "sp-trick-back",
			children: [/* @__PURE__ */ d(G, {}), /* @__PURE__ */ d("span", { children: o("games.spots.trickFacedown") })]
		}), e.treats > 0 && /* @__PURE__ */ f("span", {
			className: "sp-tile-treats",
			"aria-label": o("games.spots.trickTreats", { n: e.treats }),
			children: [/* @__PURE__ */ d(W, {}), e.treats]
		})]
	});
}
function Ye({ pub: e, me: t, locale: n, selectedDie: i, setSelectedDie: o, rerollPicks: s, setRerollPicks: c, dicePicks: l, setDicePicks: u }) {
	let p = a(), { ref: m, hidden: h } = r("tray"), g = e.pending;
	if (!g) return null;
	let _ = (e) => {
		let r = t.cards.find((t) => t.uid === e);
		if (!r) return "";
		let i = C[r.def];
		return n === "zh" ? i.nameZh : i.name;
	}, v = (e, t, n) => {
		t(e.includes(n) ? e.filter((e) => e !== n) : [...e, n]);
	}, y = l.reduce((e, t) => e + (g.dice[t] ?? 0), 0), b = "";
	return g.stage === "roll" ? b = g.partialReroll ? p("games.spots.rerollPartialHint") : p("games.spots.placeHint") : g.stage === "place" ? b = p("games.spots.placeHint") : g.stage === "chooseDice" ? b = g.policy === "hunt" ? p("games.spots.selectedDice", { n: l.length }) : g.policy === "search" ? p("games.spots.selectedSum", {
		n: l.length,
		sum: y
	}) : p("games.spots.scavengeHint", { n: g.yardTotal ?? 0 }) : g.stage === "chooseNumber" && (b = g.policy === "guard" ? p("games.spots.selectNumberGuard") : p("games.spots.selectNumberFetch")), /* @__PURE__ */ f("section", {
		ref: m,
		className: `sp-pending${h ? " sp-hidden" : ""}`,
		children: [/* @__PURE__ */ f("div", {
			className: "sp-pending-head",
			children: [
				/* @__PURE__ */ d("span", {
					className: "sp-pending-label",
					children: p("games.spots.rollTray")
				}),
				/* @__PURE__ */ d("span", {
					className: "sp-pending-hint",
					children: b
				}),
				/* @__PURE__ */ d("span", {
					className: "sp-pending-yard",
					children: p("games.spots.yardTotal", { n: t.yard.reduce((e, t) => e + t, 0) })
				})
			]
		}), /* @__PURE__ */ f("div", {
			className: "sp-pending-dice",
			children: [g.dice.map((e, t) => {
				let n = g.assigned[t], r = !n && (g.stage === "place" || g.stage === "chooseDice" || g.stage === "roll" && g.partialReroll), a = g.stage === "chooseDice" ? l.includes(t) : g.stage === "roll" ? s.includes(t) : i === t;
				return /* @__PURE__ */ f("button", {
					type: "button",
					className: `sp-pending-die${a ? " sp-pending-die--picked" : ""}${n ? " sp-pending-die--done" : ""}`,
					disabled: !r,
					"aria-label": p("games.spots.dieAria", { n: e }),
					"aria-pressed": a,
					onClick: () => {
						g.stage === "chooseDice" ? v(l, u, t) : g.stage === "roll" ? v(s, c, t) : o(i === t ? null : t);
					},
					children: [
						/* @__PURE__ */ d(K, {
							value: e,
							size: "lg"
						}),
						n && g.stage === "place" && /* @__PURE__ */ d("span", {
							className: "sp-pending-where",
							children: n.kind === "dog" ? _(n.card) : n.kind === "yard" ? p("games.spots.yard") : p("games.spots.discard")
						}),
						i === t && g.stage === "place" && !n && /* @__PURE__ */ d("span", {
							className: "sp-pending-where",
							children: p("games.spots.selected")
						})
					]
				}, t);
			}), g.dice.length === 0 && /* @__PURE__ */ d("span", {
				className: "sp-empty",
				children: p("games.spots.noDice")
			})]
		})]
	});
}
function Xe({ paws: e }) {
	return /* @__PURE__ */ f("svg", {
		className: "sp-dog-art",
		viewBox: "0 0 200 132",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ d("path", {
				d: "M22 98c-7-15-4-35 12-45l4-18c2-9 14-9 16 0l3 13c16-8 42-10 62-3l17-12c8-6 19 1 16 11l-6 17c14 10 20 27 16 43l-13 1-4 14h-13l-3-14H56l-4 14H39l-3-14Z",
				fill: "#f6f0df",
				stroke: "#292721",
				strokeWidth: "3",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ d("path", {
				d: "M148 46c7-4 14-2 17 5",
				fill: "none",
				stroke: "#292721",
				strokeWidth: "3",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "148",
				cy: "53",
				r: "4.2",
				fill: "#292721"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "166",
				cy: "63",
				r: "3.4",
				fill: "#292721"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "40",
				cy: "45",
				rx: "10",
				ry: "14",
				fill: "#292721",
				transform: "rotate(-20 40 45)"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "68",
				cy: "88",
				rx: "12",
				ry: "8",
				fill: "#292721",
				transform: "rotate(-12 68 88)"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "112",
				cy: "76",
				rx: "14",
				ry: "9",
				fill: "#292721",
				transform: "rotate(8 112 76)"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "142",
				cy: "86",
				rx: "8",
				ry: "6",
				fill: "#292721",
				transform: "rotate(-16 142 86)"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "92",
				cy: "110",
				rx: "7",
				ry: "4.5",
				fill: "#292721"
			}),
			/* @__PURE__ */ d("path", {
				d: "M48 108c4 8 12 8 16 0M104 108c4 8 12 8 16 0",
				fill: "none",
				stroke: "#292721",
				strokeWidth: "3",
				strokeLinecap: "round"
			}),
			e > 0 && /* @__PURE__ */ d("text", {
				x: "16",
				y: "24",
				fontSize: "13",
				fontWeight: "800",
				fill: "#292721",
				children: e
			})
		]
	});
}
function Ze({ cardUid: e, space: t, value: n, placed: i, kind: o, picked: s, left: c, top: l, onClick: u }) {
	let f = a(), { ref: p, hidden: m } = r(`slot:${e}:${t}`);
	return /* @__PURE__ */ d("button", {
		ref: p,
		type: "button",
		className: `sp-slot sp-slot--${o}${s ? " sp-slot--picked" : ""}${m ? " sp-hidden" : ""}`,
		style: {
			left: `${c}%`,
			top: `${l}%`
		},
		disabled: o === "static",
		"aria-label": i === null ? f("games.spots.spaceAria", { n }) : f("games.spots.dieAria", { n: i }),
		onClick: u,
		children: i === null ? /* @__PURE__ */ d(K, {
			value: n,
			size: "md",
			muted: !0
		}) : /* @__PURE__ */ d(K, {
			value: i,
			size: "md"
		})
	});
}
function Qe({ card: e, locale: t, mine: n, selectedDie: i, onPlace: o, trotSource: s, onTrotSource: c, onTrotTarget: l, trotActive: u, dogpileActive: p, onDogpile: m }) {
	let h = C[e.def], g = t === "zh" ? h.nameZh : h.name, _ = e.placed.filter((e) => e !== null).length, { ref: v, hidden: y } = r(`card:${e.uid}`), b = a();
	if (e.scored) return /* @__PURE__ */ d("div", {
		ref: v,
		className: `sp-dog sp-dog--scored${y ? " sp-hidden" : ""}`,
		"aria-label": `${g}, ${b("games.spots.dogScored")}`,
		children: /* @__PURE__ */ f("div", {
			className: "sp-scored-face",
			children: [
				/* @__PURE__ */ d(G, {}),
				/* @__PURE__ */ d("span", { children: b("games.spots.dogScored") }),
				/* @__PURE__ */ d("b", { children: g })
			]
		})
	});
	let ee = (t) => s?.card === e.uid && s.space === t, x = ze[h.spaces.length] ?? ze[6];
	return /* @__PURE__ */ f("div", {
		ref: v,
		className: `sp-dog${y ? " sp-hidden" : ""}${_ === e.placed.length ? " sp-dog--done" : ""}`,
		"aria-label": b("games.spots.cardAria", {
			name: g,
			filled: _,
			total: e.placed.length
		}),
		children: [/* @__PURE__ */ f("div", {
			className: "sp-dog-face",
			children: [/* @__PURE__ */ d(Xe, { paws: h.paws }), h.spaces.map((t, r) => {
				let a = e.placed[r], [f, h] = x[r] ?? [50, 50], g = "static";
				return n && a !== null ? p ? g = "dogpile" : u && (g = "source") : n && a === null && (u && s ? g = "target" : i === t && i !== null && (g = "place")), /* @__PURE__ */ d(Ze, {
					cardUid: e.uid,
					space: r,
					value: t,
					placed: a,
					kind: g,
					picked: ee(r),
					left: f,
					top: h,
					onClick: () => {
						g === "place" ? o?.(r) : g === "source" ? c?.(r) : g === "target" ? l?.(r) : g === "dogpile" && m?.(r);
					}
				}, r);
			})]
		}), /* @__PURE__ */ f("div", {
			className: "sp-dog-foot",
			children: [
				/* @__PURE__ */ d("span", {
					className: "sp-dog-name",
					children: g
				}),
				/* @__PURE__ */ f("span", {
					className: "sp-dog-count",
					children: [
						_,
						"/",
						e.placed.length
					]
				}),
				h.paws > 0 && /* @__PURE__ */ f("span", {
					className: "sp-dog-paw",
					children: [/* @__PURE__ */ d(G, {}), h.paws]
				})
			]
		})]
	});
}
function $e({ rid: e, dice: t, chip: n = !1, digActive: i, dogpileActive: a, onDig: o, onDogpile: s, t: c }) {
	let { ref: l, hidden: u } = r(`yard:${e}`), p = t.reduce((e, t) => e + t, 0);
	return /* @__PURE__ */ f("div", {
		ref: l,
		className: `sp-yard${n ? " sp-yard--chip" : ""}${p > 5 ? " sp-yard--danger" : ""}${i || a ? " sp-yard--open" : ""}${u ? " sp-hidden" : ""}`,
		children: [
			/* @__PURE__ */ d("span", {
				className: "sp-yard-label",
				children: c("games.spots.yard")
			}),
			/* @__PURE__ */ f("span", {
				className: "sp-yard-dice",
				children: [t.map((e, t) => /* @__PURE__ */ f("span", {
					className: "sp-yard-die",
					children: [/* @__PURE__ */ d("button", {
						type: "button",
						className: `sp-yard-die-main${a ? " sp-yard-die--pick" : ""}`,
						disabled: !a,
						"aria-label": c("games.spots.dieAria", { n: e }),
						onClick: () => s?.(t),
						children: /* @__PURE__ */ d(K, {
							value: e,
							size: n ? "sm" : "md"
						})
					}), i && /* @__PURE__ */ f("span", {
						className: "sp-yard-adj",
						children: [/* @__PURE__ */ d("button", {
							type: "button",
							disabled: e >= 6,
							onClick: () => o?.(t, 1),
							"aria-label": c("games.spots.digUp"),
							children: "+"
						}), /* @__PURE__ */ d("button", {
							type: "button",
							disabled: e <= 1,
							onClick: () => o?.(t, -1),
							"aria-label": c("games.spots.digDown"),
							children: "−"
						})]
					})]
				}, t)), t.length === 0 && /* @__PURE__ */ d("span", {
					className: "sp-empty",
					children: c(n ? "games.spots.yardEmpty" : "games.spots.emptyYard")
				})]
			}),
			/* @__PURE__ */ f("b", {
				className: "sp-yard-total",
				children: [p, " / 7"]
			})
		]
	});
}
function et({ card: e, locale: t }) {
	let n = a(), r = C[e.def], i = t === "zh" ? r.nameZh : r.name, o = e.placed.filter((e) => e !== null).length;
	return /* @__PURE__ */ f("span", {
		className: "sp-mini-dog",
		title: n("games.spots.cardAria", {
			name: i,
			filled: o,
			total: e.placed.length
		}),
		children: [
			/* @__PURE__ */ d("b", { children: i }),
			/* @__PURE__ */ d("span", {
				className: "sp-mini-spaces",
				children: r.spaces.map((t, n) => /* @__PURE__ */ d("i", {
					className: e.placed[n] === null ? "" : "on",
					children: e.placed[n] ?? t
				}, n))
			}),
			/* @__PURE__ */ f("em", { children: [
				o,
				"/",
				r.spaces.length
			] }),
			r.paws > 0 && /* @__PURE__ */ f("span", {
				className: "sp-mini-paw",
				children: [/* @__PURE__ */ d(G, {}), r.paws]
			})
		]
	});
}
function tt({ p: e, member: t, myRid: n, name: r, locale: i, digActive: a, onDig: o, t: s }) {
	return /* @__PURE__ */ f("article", {
		className: "sp-opp",
		children: [/* @__PURE__ */ f("header", {
			className: "sp-opp-head",
			children: [
				t ? /* @__PURE__ */ d(c, {
					m: t,
					myRid: n,
					action: null,
					anchorName: `row:${e.rid}`,
					box: "size-5",
					img: "size-4"
				}) : /* @__PURE__ */ d("span", { className: "sp-opp-dot" }),
				/* @__PURE__ */ d("b", {
					className: "sp-opp-name",
					children: r
				}),
				/* @__PURE__ */ f("span", {
					className: "sp-opp-stat",
					children: [/* @__PURE__ */ d("span", { children: s("games.spots.scoredLabel") }), /* @__PURE__ */ f("b", { children: [
						e.scoredCount,
						"/",
						6
					] })]
				}),
				/* @__PURE__ */ f("span", {
					className: "sp-opp-stat",
					children: [/* @__PURE__ */ d(W, {}), e.treats]
				}),
				/* @__PURE__ */ f("span", {
					className: "sp-opp-stat",
					children: [/* @__PURE__ */ d(G, {}), e.paws]
				}),
				/* @__PURE__ */ d($e, {
					rid: e.rid,
					dice: e.yard,
					chip: !0,
					digActive: a,
					onDig: o,
					t: s
				})
			]
		}), /* @__PURE__ */ d("div", {
			className: "sp-opp-dogs",
			children: e.cards.filter((e) => !e.scored).map((e) => /* @__PURE__ */ d(et, {
				card: e,
				locale: i
			}, e.uid))
		})]
	});
}
function nt({ pub: e, locale: t, t: n }) {
	let { ref: i, hidden: a } = r("deck"), o = e.deckTop === null ? null : C[e.deckTop];
	return /* @__PURE__ */ f("div", {
		ref: i,
		className: `sp-deck${a ? " sp-hidden" : ""}`,
		children: [/* @__PURE__ */ d("span", {
			className: "sp-deck-count",
			children: n("games.spots.deckCount", { n: e.deckCount })
		}), o ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ f("span", {
				className: "sp-deck-name",
				children: [/* @__PURE__ */ d(G, {}), t === "zh" ? o.nameZh : o.name]
			}),
			/* @__PURE__ */ d("span", {
				className: "sp-deck-spaces",
				children: o.spaces.map((e, t) => /* @__PURE__ */ d("i", { children: e }, t))
			}),
			/* @__PURE__ */ d("small", {
				className: "sp-deck-tag",
				children: n("games.spots.deckTopTag")
			})
		] }) : /* @__PURE__ */ d("span", {
			className: "sp-empty",
			children: n("games.spots.deckEmpty")
		})]
	});
}
function rt({ pub: e, t }) {
	let { ref: n, hidden: i } = r("supply");
	return /* @__PURE__ */ f("div", {
		ref: n,
		className: `sp-supply${i ? " sp-hidden" : ""}`,
		children: [/* @__PURE__ */ f("div", {
			className: "sp-supply-row",
			children: [/* @__PURE__ */ d("span", { children: t("games.spots.supplyDice", { n: e.supplyDice }) }), /* @__PURE__ */ f("span", {
				className: "sp-supply-dice",
				children: [
					/* @__PURE__ */ d(K, {
						value: 1,
						size: "sm"
					}),
					/* @__PURE__ */ d(K, {
						value: 3,
						size: "sm"
					}),
					/* @__PURE__ */ d(K, {
						value: 6,
						size: "sm"
					})
				]
			})]
		}), /* @__PURE__ */ f("div", {
			className: "sp-supply-row",
			children: [/* @__PURE__ */ d("span", { children: t("games.spots.supplyTreats", { n: e.supplyTreats }) }), /* @__PURE__ */ d(W, {})]
		})]
	});
}
function it({ pub: e, me: t, myTurn: n, completed: r, selectedDie: i, setSelectedDie: a, rerollPicks: o, dicePicks: s, setDicePicks: c, send: l, t: u }) {
	let p = (e) => l(e);
	if (!n || !t) return /* @__PURE__ */ d("div", {
		className: "sp-actions sp-actions--wait",
		children: u("games.spots.waitingTurnShort")
	});
	if (e.phase === "done") return /* @__PURE__ */ d("div", {
		className: "sp-actions sp-actions--wait",
		children: u("games.spots.gameOver", { name: "" })
	});
	if (e.awaiting === "action") return /* @__PURE__ */ f("div", {
		className: "sp-actions",
		children: [/* @__PURE__ */ d("span", {
			className: "sp-actions-hint",
			children: u("games.spots.hintPick")
		}), /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base sp-btn",
			disabled: r === 0,
			onClick: () => p({ type: "score" }),
			children: [u("games.spots.scoreDogs"), r > 0 ? ` +${r}` : ""]
		})]
	});
	let m = e.pending;
	if (e.awaiting === "roll" && m) {
		let e = m.partialReroll, n = t.treats <= 0 || e && o.length === 0;
		return /* @__PURE__ */ f("div", {
			className: "sp-actions",
			children: [/* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-base sp-btn sp-btn--quiet",
				disabled: n,
				onClick: () => p({
					type: "reroll",
					...e ? { dice: o } : {}
				}),
				children: [
					u(e ? "games.spots.rerollSome" : "games.spots.rerollAll"),
					" · ",
					/* @__PURE__ */ d(W, {}),
					"1"
				]
			}), /* @__PURE__ */ d("button", {
				type: "button",
				className: "btn-base sp-btn sp-btn--primary",
				onClick: () => p({ type: "beginPlace" }),
				children: u("games.spots.confirmRoll")
			})]
		});
	}
	if (e.awaiting === "place" && m) return /* @__PURE__ */ f("div", {
		className: "sp-actions",
		children: [
			/* @__PURE__ */ d("span", {
				className: "sp-actions-hint",
				children: u("games.spots.placeHint")
			}),
			i !== null && /* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-base sp-btn sp-btn--danger",
				onClick: () => {
					p({
						type: "buryDie",
						die: i
					}), a(null);
				},
				children: [
					u("games.spots.buryDie"),
					" ",
					m.dice[i]
				]
			}),
			/* @__PURE__ */ d("button", {
				type: "button",
				className: "btn-base sp-btn",
				onClick: () => {
					p({ type: "autoPlace" }), a(null);
				},
				children: u("games.spots.autoPlace")
			}),
			/* @__PURE__ */ d("button", {
				type: "button",
				className: "btn-base sp-btn sp-btn--quiet",
				onClick: () => {
					p({ type: "finishPlacement" }), a(null);
				},
				children: u("games.spots.buryRest")
			})
		]
	});
	if (e.awaiting === "chooseNumber" && m) {
		let e = m.policy === "guard" ? [
			1,
			2,
			3,
			4,
			5,
			6
		] : m.choices ?? [];
		return /* @__PURE__ */ f("div", {
			className: "sp-actions sp-actions--numbers",
			children: [/* @__PURE__ */ d("span", {
				className: "sp-actions-hint",
				children: m.policy === "guard" ? u("games.spots.selectNumberGuard") : u("games.spots.selectNumberFetch")
			}), e.map((e) => /* @__PURE__ */ d("button", {
				type: "button",
				className: "btn-base sp-num-btn",
				"aria-label": m.policy === "guard" ? u("games.spots.guardRollAria", { n: e }) : u("games.spots.selectNumberAria", { n: e }),
				onClick: () => p({
					type: "chooseNumber",
					value: e
				}),
				children: /* @__PURE__ */ d(K, {
					value: e,
					size: "md"
				})
			}, e))]
		});
	}
	if (e.awaiting === "chooseDice" && m) {
		let e = m.policy === "hunt" ? s.length === m.selectCount : m.policy !== "search" || s.reduce((e, t) => e + (m.dice[t] ?? 0), 0) === m.targetSum && s.length > 0, t = m.policy === "hunt" || m.policy === "search" ? u("games.spots.keepSelected") : u("games.spots.discardSelected");
		return /* @__PURE__ */ f("div", {
			className: "sp-actions",
			children: [
				/* @__PURE__ */ d("span", {
					className: "sp-actions-hint",
					children: m.policy === "scavenge" ? u("games.spots.scavengeHint", { n: m.yardTotal ?? 0 }) : u("games.spots.selectDiceHint")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "btn-base sp-btn",
					disabled: !e,
					onClick: () => p({
						type: "chooseDice",
						dice: s
					}),
					children: [
						t,
						" (",
						s.length,
						")"
					]
				}),
				/* @__PURE__ */ d("button", {
					type: "button",
					className: "btn-base sp-btn sp-btn--quiet",
					onClick: () => c([]),
					children: u("games.spots.clearSelection")
				})
			]
		});
	}
	if (e.awaiting === "dig") return /* @__PURE__ */ f("div", {
		className: "sp-actions",
		children: [/* @__PURE__ */ d("span", {
			className: "sp-actions-hint",
			children: u("games.spots.digPrompt", { n: e.prompt?.kind === "dig" ? e.prompt.remaining : 0 })
		}), /* @__PURE__ */ d("button", {
			type: "button",
			className: "btn-base sp-btn sp-btn--quiet",
			onClick: () => p({ type: "skipDig" }),
			children: u("games.spots.skipDig")
		})]
	});
	if (e.awaiting === "trot") return /* @__PURE__ */ f("div", {
		className: "sp-actions",
		children: [/* @__PURE__ */ d("span", {
			className: "sp-actions-hint",
			children: u("games.spots.trotPrompt")
		}), /* @__PURE__ */ d("button", {
			type: "button",
			className: "btn-base sp-btn sp-btn--quiet",
			onClick: () => p({ type: "skipTrot" }),
			children: u("games.spots.skipTrot")
		})]
	});
	if (e.awaiting === "retrieve") {
		let t = e.prompt?.kind === "retrieve" ? e.prompt.values : [];
		return /* @__PURE__ */ f("div", {
			className: "sp-actions sp-actions--numbers",
			children: [
				/* @__PURE__ */ d("span", {
					className: "sp-actions-hint",
					children: u("games.spots.retrievePrompt")
				}),
				t.map((t) => /* @__PURE__ */ d("button", {
					type: "button",
					className: "btn-base sp-num-btn",
					"aria-label": u("games.spots.retrieveAria", { n: t }),
					disabled: e.supplyDice <= 0,
					onClick: () => p({
						type: "retrieve",
						value: t
					}),
					children: /* @__PURE__ */ d(K, {
						value: t,
						size: "md"
					})
				}, t)),
				e.supplyDice <= 0 && /* @__PURE__ */ d("button", {
					type: "button",
					className: "btn-base sp-btn sp-btn--quiet",
					onClick: () => p({ type: "skipRetrieve" }),
					children: u("games.spots.skipRetrieve")
				})
			]
		});
	}
	if (e.awaiting === "dogpile") return /* @__PURE__ */ d("div", {
		className: "sp-actions",
		children: /* @__PURE__ */ d("span", {
			className: "sp-actions-hint sp-actions-hint--keep",
			children: u("games.spots.dogpilePrompt")
		})
	});
	if (e.awaiting === "bolt") {
		let t = e.prompt?.kind === "boltChoose" ? e.prompt.max : 3, n = t >= 3 ? Array.from({ length: t - 2 }, (e, t) => t + 3) : Array.from({ length: t }, (e, t) => t + 1);
		return /* @__PURE__ */ f("div", {
			className: "sp-actions sp-actions--numbers",
			children: [/* @__PURE__ */ d("span", {
				className: "sp-actions-hint",
				children: u("games.spots.boltPrompt")
			}), n.map((e) => /* @__PURE__ */ d("button", {
				type: "button",
				className: "btn-base sp-btn",
				onClick: () => p({
					type: "boltChoose",
					count: e
				}),
				children: u("games.spots.boltChoose", { n: e })
			}, e))]
		});
	}
	if (e.awaiting === "repeat") {
		let n = e.repeatKind !== "bolt" || t.paws >= e.boltRemaining;
		return /* @__PURE__ */ f("div", {
			className: "sp-actions",
			children: [
				/* @__PURE__ */ d("span", {
					className: "sp-actions-hint",
					children: e.repeatKind === "bolt" ? u("games.spots.boltRemaining", { n: e.boltRemaining }) : u("games.spots.repeatPrompt")
				}),
				/* @__PURE__ */ d("button", {
					type: "button",
					className: "btn-base sp-btn sp-btn--primary",
					onClick: () => p({ type: "repeat" }),
					children: u("games.spots.repeat")
				}),
				/* @__PURE__ */ d("button", {
					type: "button",
					className: "btn-base sp-btn sp-btn--quiet",
					disabled: !n,
					onClick: () => p({ type: "stop" }),
					children: u("games.spots.stop")
				})
			]
		});
	}
	return /* @__PURE__ */ d("div", {
		className: "sp-actions sp-actions--wait",
		children: u("games.spots.waitingTurnShort")
	});
}
//#endregion
//#region src/games/spots/bot.ts
var q = (e) => e.placed.every((e) => e !== null);
function J(e) {
	let t = [
		0,
		0,
		0,
		0,
		0,
		0,
		0
	];
	for (let n of e.cards) n.scored || C[n.def].spaces.forEach((e, r) => {
		n.placed[r] === null && (t[e] += 1);
	});
	return t;
}
function at(e, t) {
	let n = J(e), r = 0;
	for (let e of t) n[e] > 0 && (--n[e], r += 1);
	return r;
}
function Y(e) {
	return e.yard.reduce((e, t) => e + t, 0);
}
function ot(e, t) {
	return e.placed[t] === null;
}
function st(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function ct(e) {
	return e.cards.filter((e) => !e.scored && q(e)).length;
}
function lt(e, t, n) {
	if (e.phase !== "play" || e.turn !== t.rid) return null;
	if (e.awaiting === "action") {
		let r = ct(t);
		if (r > 0 && (n ? Math.random() < .5 : r >= 2 || t.scoredCount >= 4)) return { type: "score" };
		let i = e.tiles.filter((e) => e.faceup);
		return i.length ? n ? {
			type: "trick",
			id: st(i).id
		} : {
			type: "trick",
			id: ut(e, t, i.map((e) => e.id))
		} : null;
	}
	if (e.repeatKind) {
		if (n) return Math.random() < .5 ? { type: "repeat" } : { type: "stop" };
		let r = Y(t);
		return e.repeatKind === "bolt" ? t.paws >= e.boltRemaining && r >= 5 ? { type: "stop" } : { type: "repeat" } : r >= 5 || e.supplyDice === 0 ? { type: "stop" } : { type: "repeat" };
	}
	if (e.awaiting === "dig") {
		if (n) return { type: "skipDig" };
		if (Y(t) >= 5) {
			let e = t.yard.findIndex((e) => e >= 2);
			if (e >= 0) return {
				type: "dig",
				rid: t.rid,
				index: e,
				delta: -1
			};
		}
		for (let n of e.players) if (n.rid !== t.rid && Y(n) === 7) {
			let e = n.yard.findIndex((e) => e <= 5);
			if (e >= 0) return {
				type: "dig",
				rid: n.rid,
				index: e,
				delta: 1
			};
		}
		return { type: "skipDig" };
	}
	if (e.awaiting === "trot") return n ? { type: "skipTrot" } : pt(t) ?? { type: "skipTrot" };
	if (e.awaiting === "retrieve") {
		let n = e.prompt?.kind === "retrieve" ? e.prompt.values : [];
		if (!n.length) return { type: "skipRetrieve" };
		let r = J(t);
		return {
			type: "retrieve",
			value: [...n].sort((e, t) => r[t] - r[e])[0]
		};
	}
	if (e.awaiting === "dogpile") {
		let e = () => {
			let e = [...t.cards].filter((e) => !e.scored && e.placed.some((e) => e !== null)).sort((e, t) => t.placed.filter((e) => e === null).length - e.placed.filter((e) => e === null).length)[0];
			if (!e) return null;
			let n = e.placed.findIndex((e) => e !== null);
			return n >= 0 ? {
				type: "dogpileSource",
				from: "dog",
				card: e.uid,
				space: n
			} : null;
		};
		if (t.yard.length === 0) return e() ?? {
			type: "dogpileSource",
			from: "yard",
			index: 0
		};
		if (n) return {
			type: "dogpileSource",
			from: "yard",
			index: 0
		};
		let r = t.yard.findIndex((e) => e >= 2);
		return r >= 0 && Y(t) >= 5 ? {
			type: "dogpileSource",
			from: "yard",
			index: r
		} : e() ?? {
			type: "dogpileSource",
			from: "yard",
			index: 0
		};
	}
	if (e.awaiting === "bolt") {
		let r = e.prompt?.kind === "boltChoose" ? e.prompt.max : 3;
		if (n) return {
			type: "boltChoose",
			count: Math.min(3, r)
		};
		let i = Y(t) >= 5 ? 3 : Math.min(4, r);
		return {
			type: "boltChoose",
			count: Math.max(1, i)
		};
	}
	let r = e.pending;
	if (!r) return null;
	if (r.stage === "roll") {
		if (n) return Math.random() < .25 && t.treats > 0 ? { type: "reroll" } : { type: "beginPlace" };
		let e = at(t, r.dice), i = _t(t, r.dice), a = Y(t) + Math.max(0, i);
		return t.treats > 0 && (a > 7 || e === 0 && r.dice.length > 1) ? { type: "reroll" } : { type: "beginPlace" };
	}
	if (r.stage === "chooseNumber") {
		if (r.policy === "guard") {
			let e = [
				1,
				2,
				3,
				4,
				5,
				6
			];
			if (n) return {
				type: "chooseNumber",
				value: st(e)
			};
			let i = 6, a = -Infinity;
			for (let n of e) {
				let e = r.dice.filter((e) => e <= n), o = at(t, e), s = _t(t, e), c = o * 3 - (Y(t) + s > 7 ? 8 : 0) - (e.length - o);
				c > a && (a = c, i = n);
			}
			return {
				type: "chooseNumber",
				value: i
			};
		}
		let e = r.choices ?? [];
		if (!e.length) return { type: "beginPlace" };
		if (n) return {
			type: "chooseNumber",
			value: st(e)
		};
		let i = J(t), a = e.filter((e) => i[e] > 0);
		return {
			type: "chooseNumber",
			value: [...a.length ? a : e].sort((e, t) => r.dice.filter((e) => e === t).length - r.dice.filter((t) => t === e).length)[0]
		};
	}
	if (r.stage === "chooseDice") {
		let e = r.dice;
		if (r.policy === "hunt") {
			let n = J(t);
			return {
				type: "chooseDice",
				dice: e.map((e, t) => ({
					index: t,
					value: e,
					score: (n[e] > 0 ? 10 : 0) - e
				})).sort((e, t) => t.score - e.score).slice(0, r.selectCount ?? 2).map((e) => e.index)
			};
		}
		if (r.policy === "search") {
			let n = [], i = -Infinity;
			for (let a = 1; a < 1 << e.length; a += 1) {
				let o = [], s = 0;
				for (let t = 0; t < e.length; t += 1) a & 1 << t && (o.push(t), s += e[t]);
				if (s !== r.targetSum) continue;
				let c = J(t), l = 0;
				for (let t of o) c[e[t]] > 0 ? (--c[e[t]], l += 10) : l -= e[t];
				l > i && (i = l, n = o);
			}
			return n.length ? {
				type: "chooseDice",
				dice: n
			} : {
				type: "chooseDice",
				dice: []
			};
		}
		let n = r.yardTotal ?? 0, i = J(t), a = [];
		return e.forEach((e, t) => {
			e < n && i[e] === 0 && a.push(t);
		}), {
			type: "chooseDice",
			dice: a
		};
	}
	if (r.stage === "place") {
		let e = r.assigned.findIndex((e) => e === null);
		if (e < 0) return { type: "autoPlace" };
		if (r.tag === "playDead") {
			let n = r.dice[e], i = t.cards.find((e) => !e.scored && C[e.def].spaces.some((t, r) => t === n && ot(e, r)));
			if (n >= 4 && Y(t) + n <= 7) return {
				type: "buryDie",
				die: e
			};
			if (i) {
				let t = C[i.def].spaces.findIndex((e, t) => e === n && ot(i, t));
				return {
					type: "placeDie",
					die: e,
					card: i.uid,
					space: t
				};
			}
			return {
				type: "buryDie",
				die: e
			};
		}
		return { type: "autoPlace" };
	}
	return null;
}
function ut(e, t, n) {
	let r = J(t), i = r.filter((e) => e > 0).length, a = r.reduce((e, t) => e + t, 0), o = n[0], s = -Infinity;
	for (let r of n) {
		let n = 0;
		r === "howl" ? n = 2.4 + (t.cards.length < 6 && e.deckCount > 0 ? 1.2 : 0) : r === "rollOver" ? n = t.yard.length * (.7 + i / 6) : r === "walk" ? n = i / 6 * 3 + 1.2 : r === "run" ? n = i / 6 * 4 + 1.4 : r === "fetch" ? n = 1 / 6 * 8 * (a > 0 ? 2.2 : .4) : r === "beg" ? n = 1 + t.paws + +(t.treats < 3) : r === "chew" ? n = 1 + t.treats : r === "gobble" ? n = 2 + Math.min(7, 7 - ft(t)) : r === "playDead" ? n = 2 + t.yard.length * 0 : r === "stay" ? n = e.tiles.filter((e) => !e.faceup && e.id !== "stay").length + .5 : r === "dig" ? n = 2 + t.paws * (Y(t) >= 5 ? 1.3 : .4) : r === "chase" ? n = 3.4 + (t.yard.length ? 0 : .4) : r === "guard" ? n = i / 6 * 3.4 + 1 : r === "scavenge" ? n = i / 6 * 4 + 1.2 : r === "search" ? n = 2.4 : r === "retrieve" ? n = i / 6 * 2.4 + 1.2 : r === "track" ? n = i / 6 * 3 + 1.5 : r === "trot" ? n = (pt(t) ? 5 : 1.5) + 1.2 : r === "bolt" ? n = 3.6 : r === "dogpile" ? n = 3.8 + (t.yard.length ? .5 : 0) : r === "sprint" && (n = Math.max(1, dt(t)) * (i / 6) + 1.5), n > s && (s = n, o = r);
	}
	return o;
}
function dt(e) {
	return e.cards.filter((e) => !e.scored && !q(e)).length;
}
function ft(e) {
	let t = 0;
	for (let n of e.cards) n.scored || C[n.def].spaces.forEach((e, r) => {
		n.placed[r] === null && (t = Math.max(t, e));
	});
	return t;
}
function pt(e) {
	let t = null, n = 0;
	for (let r of e.cards) if (!r.scored) {
		for (let i = 0; i < r.placed.length; i += 1) if (r.placed[i] !== null) {
			for (let a of e.cards) if (!a.scored) for (let e = 0; e < a.placed.length; e += 1) {
				if (r.uid === a.uid && i === e || a.placed[e] !== null) continue;
				let o = r.placed.map((e, t) => t === i ? null : e), s = a.placed.map((t, n) => n === e ? C[a.def].spaces[n] : t), c = o.every((e) => e !== null), l = s.every((e) => e !== null), u = (+!!c + +!!l - !!q(r) - (r.uid !== a.uid && q(a) ? 1 : 0)) * 10 + s.filter((e) => e !== null).length + (c ? 2 : 0);
				u > n && (n = u, t = {
					type: "trot",
					card: r.uid,
					space: i,
					toCard: a.uid,
					toSpace: e
				});
			}
		}
	}
	return t;
}
var mt = (e, t) => {
	let n = e.public.players.find((e) => e.rid === t.rid);
	if (!n) return null;
	let r = lt(e.public, n, t.difficulty === "weak");
	return r ? { action: r } : null;
}, ht = (e, t, n) => {
	let r = t.public.players.find((e) => e.rid === t.public.turn);
	return e.type === "trick" ? n("games.spots.hintTrick", { trick: n(`games.spots.trick${gt(e.id)}`) }) : e.type === "score" ? n("games.spots.hintScore") : e.type === "reroll" ? n("games.spots.hintReroll") : e.type === "beginPlace" ? n("games.spots.hintBegin") : e.type === "placeDie" ? n("games.spots.hintPlace", {
		die: String(t.public.pending?.dice[e.die] ?? ""),
		dog: ((e) => {
			let t = r?.cards.find((t) => t.uid === e);
			if (!t) return "";
			let i = C[t.def];
			return n("games.spots.cardAria", {
				name: i.name,
				filled: t.placed.filter((e) => e !== null).length,
				total: t.placed.length
			});
		})(e.card)
	}) : e.type === "buryDie" ? n("games.spots.hintBury", { die: String(t.public.pending?.dice[e.die] ?? "") }) : e.type === "autoPlace" ? n("games.spots.hintAuto") : e.type === "finishPlacement" ? n("games.spots.hintBuryRest") : e.type === "chooseNumber" ? n("games.spots.hintNumber", { n: String(e.value) }) : e.type === "chooseDice" ? n("games.spots.hintDice", { n: String(e.dice.length) }) : e.type === "dig" ? n("games.spots.hintDig", { name: t.public.players.find((t) => t.rid === e.rid)?.rid ?? "" }) : e.type === "skipDig" ? n("games.spots.hintSkip") : e.type === "trot" ? n("games.spots.hintTrot") : e.type === "skipTrot" ? n("games.spots.hintSkip") : e.type === "retrieve" ? n("games.spots.hintRetrieve", { n: String(e.value) }) : e.type === "skipRetrieve" ? n("games.spots.hintSkip") : e.type === "dogpileSource" ? n("games.spots.hintDogpile", { from: e.from === "yard" ? n("games.spots.yard") : n("games.spots.dogs") }) : e.type === "boltChoose" ? n("games.spots.hintBoltStop") : e.type === "repeat" ? n("games.spots.hintRepeat") : e.type === "stop" ? n("games.spots.hintStop") : n("games.spots.hintPick");
};
function gt(e) {
	return e.charAt(0).toUpperCase() + e.slice(1);
}
function _t(e, t) {
	let n = J(e), r = 0;
	for (let e of t) n[e] > 0 ? --n[e] : r += e;
	return r;
}
//#endregion
//#region src/games/spots/fx.tsx
function X(e, t) {
	return t ? e.anchor(`row:${t}`) : null;
}
function Z(e, t = 28) {
	return {
		x: e.x + e.w / 2 - t / 2,
		y: e.y + e.h / 2 - t / 2,
		w: t,
		h: t
	};
}
function Q({ value: e, size: t = 28 }) {
	return /* @__PURE__ */ d("span", {
		className: "sp-fx-die",
		style: {
			width: t,
			height: t
		},
		children: /* @__PURE__ */ d(K, {
			value: e,
			size: "md"
		})
	});
}
function $({ children: e, tone: t = "" }) {
	return /* @__PURE__ */ d("span", {
		className: `sp-fx-pill${t ? ` ${t}` : ""}`,
		children: e
	});
}
function vt({ dice: e, at: t, ms: n }) {
	return /* @__PURE__ */ d("div", {
		className: "sp-fx-roll",
		style: {
			left: t.x + t.w / 2,
			top: t.y + t.h / 2
		},
		children: e.map((e, t) => /* @__PURE__ */ d("span", {
			className: "sp-fx-tumble",
			style: {
				animationDelay: `${t * 45}ms`,
				animationDuration: `${n}ms`
			},
			children: /* @__PURE__ */ d(Q, {
				value: e,
				size: 30
			})
		}, t))
	});
}
var yt = {
	roll(e, t) {
		let n = e.data, r = Array.isArray(n?.dice) ? n.dice : [], i = t.anchor("tray");
		if (!i || r.length === 0) return null;
		let a = t.queued > 0;
		return {
			ms: a ? 260 : 560,
			hide: a ? void 0 : ["tray"],
			node: /* @__PURE__ */ d(vt, {
				dice: r,
				at: i,
				ms: a ? 220 : 460
			})
		};
	},
	reroll(e, t) {
		let n = e.data, r = Array.isArray(n?.dice) ? n.dice : [], i = Array.isArray(n?.indices) ? n.indices : [], a = t.anchor("tray");
		if (!a || i.length === 0) return null;
		let o = i.map((e) => r[e]).filter((e) => typeof e == "number");
		return {
			ms: 520,
			hide: ["tray"],
			node: /* @__PURE__ */ d(vt, {
				dice: o,
				at: a,
				ms: 440
			})
		};
	},
	place(e, t) {
		let n = e.data;
		if (typeof n?.die != "number" || typeof n.card != "string" || typeof n.space != "number") return null;
		let r = t.anchor(`slot:${n.card}:${n.space}`), i = t.anchor("tray") ?? t.anchor("supply");
		if (!r) {
			let e = t.anchor(`card:${n.card}`);
			return e ? {
				ms: 500,
				node: /* @__PURE__ */ d(g, {
					at: e,
					ms: 420
				})
			} : null;
		}
		return {
			ms: 420,
			hide: t.queued > 0 ? void 0 : [`slot:${n.card}:${n.space}`],
			node: i ? /* @__PURE__ */ d(h, {
				from: Z(i),
				to: r,
				ms: 360,
				children: /* @__PURE__ */ d(Q, {
					value: n.die,
					size: 30
				})
			}) : /* @__PURE__ */ d(g, {
				at: r,
				ms: 380
			})
		};
	},
	bury(e, t) {
		let n = e.data, r = X(t, e.rid) && t.anchor(`yard:${e.rid}`);
		if (!r) return null;
		let i = t.anchor("tray") ?? t.anchor("supply");
		return {
			ms: 460,
			node: /* @__PURE__ */ d(u, { children: i && typeof n?.die == "number" ? /* @__PURE__ */ d(h, {
				from: Z(i),
				to: Z(r, 34),
				ms: 380,
				children: /* @__PURE__ */ d(Q, {
					value: n.die,
					size: 28
				})
			}) : /* @__PURE__ */ d(g, {
				at: r,
				ms: 420
			}) })
		};
	},
	discard(e, t) {
		let n = e.data, r = typeof n?.n == "number" ? n.n : 0, i = t.anchor(`yard:${e.rid}`) ?? X(t, e.rid);
		return !i || r <= 0 ? null : {
			ms: 620,
			node: /* @__PURE__ */ d(m, {
				at: i,
				ms: 560,
				children: /* @__PURE__ */ f($, {
					tone: "sp-fx-pill--quiet",
					children: ["−", r]
				})
			})
		};
	},
	treat(e, t) {
		let n = e.data, r = typeof n?.n == "number" ? n.n : 0, i = X(t, e.rid);
		return !i || r <= 0 ? null : {
			ms: 700,
			node: /* @__PURE__ */ d(m, {
				at: i,
				ms: 640,
				children: /* @__PURE__ */ f($, {
					tone: "sp-fx-pill--bone",
					children: [
						/* @__PURE__ */ d(W, {}),
						"+",
						r
					]
				})
			})
		};
	},
	score(e, t) {
		return bt(e, t);
	},
	fastScore(e, t) {
		return bt(e, t);
	},
	draw(e, t) {
		let n = e.data, r = typeof n?.n == "number" ? n.n : 0, i = t.anchor("deck"), a = X(t, e.rid);
		return !i || !a || r <= 0 ? null : {
			ms: 520 + Math.min(r, 3) * 80,
			node: /* @__PURE__ */ d(u, { children: Array.from({ length: Math.min(r, 3) }, (e, t) => /* @__PURE__ */ d(h, {
				from: Z(i, 26),
				to: Z(a, 34),
				ms: 420,
				delay: t * 70,
				children: /* @__PURE__ */ d("span", { className: "sp-fx-cardback" })
			}, t)) })
		};
	},
	bust(e, t) {
		let n = t.anchor(`yard:${e.rid}`) ?? X(t, e.rid);
		return n ? {
			ms: 760,
			node: /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d(p, {
					ms: 520,
					className: "sp-fx-flash--bust"
				}),
				/* @__PURE__ */ d(g, {
					at: n,
					ms: 560
				}),
				/* @__PURE__ */ d(m, {
					at: n,
					ms: 700,
					children: /* @__PURE__ */ d($, {
						tone: "sp-fx-pill--danger",
						children: "7+"
					})
				})
			] })
		} : null;
	},
	dig(e, t) {
		let n = e.data;
		if (typeof n?.target != "string" || typeof n.delta != "number") return null;
		let r = t.anchor(`yard:${n.target}`);
		return r ? {
			ms: 620,
			node: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(g, {
				at: r,
				ms: 480
			}), /* @__PURE__ */ d(m, {
				at: r,
				ms: 600,
				children: /* @__PURE__ */ d($, { children: n.delta > 0 ? "+1" : "−1" })
			})] })
		} : null;
	},
	trot(e, t) {
		let n = e.data, r = typeof n?.card == "string" ? t.anchor(`card:${n.card}`) : null;
		return !r || typeof n?.die != "number" ? null : {
			ms: 700,
			node: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(g, {
				at: r,
				ms: 520
			}), /* @__PURE__ */ d(m, {
				at: r,
				ms: 620,
				children: /* @__PURE__ */ d($, { children: /* @__PURE__ */ d(Q, {
					value: n.die,
					size: 20
				}) })
			})] })
		};
	},
	retrieve(e, t) {
		let n = e.data, r = t.anchor("deck"), i = t.anchor("tray") ?? t.anchor("supply");
		return !r || !i || typeof n?.die != "number" ? null : {
			ms: 480,
			node: /* @__PURE__ */ d(h, {
				from: Z(r, 28),
				to: Z(i, 34),
				ms: 400,
				children: /* @__PURE__ */ d(Q, {
					value: n.die,
					size: 28
				})
			})
		};
	},
	trick(e, t) {
		let n = e.data, r = typeof n?.id == "string" ? t.anchor(`trick:${n.id}`) : null;
		return r ? {
			ms: 640,
			node: /* @__PURE__ */ d(g, {
				at: r,
				ms: 520
			})
		} : null;
	},
	reset(e, t) {
		let n = e.data, r = typeof n?.id == "string" ? t.anchor(`trick:${n.id}`) : null;
		if (!r) return null;
		let i = typeof n?.treats == "number" ? n.treats : 0;
		return {
			ms: 820,
			node: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(g, {
				at: r,
				ms: 620
			}), /* @__PURE__ */ d(m, {
				at: r,
				ms: 700,
				children: /* @__PURE__ */ f($, {
					tone: "sp-fx-pill--bone",
					children: [/* @__PURE__ */ d(W, {}), i]
				})
			})] })
		};
	},
	diceOut(e, t) {
		let n = t.anchor("supply");
		return n ? {
			ms: 760,
			node: /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d(p, {
					ms: 520,
					className: "sp-fx-flash--dice"
				}),
				/* @__PURE__ */ d(g, {
					at: n,
					ms: 560
				}),
				/* @__PURE__ */ d(m, {
					at: n,
					ms: 680,
					children: /* @__PURE__ */ f($, {
						tone: "sp-fx-pill--quiet",
						children: [/* @__PURE__ */ d(K, {
							value: 1,
							size: "sm"
						}), "0"]
					})
				})
			] })
		} : null;
	},
	turnStart(e, t) {
		let n = X(t, e.rid);
		return n ? {
			ms: 620,
			node: /* @__PURE__ */ d(g, {
				at: n,
				ms: 500
			})
		} : null;
	},
	win(e, t) {
		let n = X(t, e.rid);
		return n ? {
			ms: 1e3,
			node: /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d(p, {
					ms: 700,
					className: "sp-fx-flash--win"
				}),
				/* @__PURE__ */ d(g, {
					at: n,
					ms: 700
				}),
				/* @__PURE__ */ d(m, {
					at: n,
					ms: 900,
					children: /* @__PURE__ */ f($, {
						tone: "sp-fx-pill--win",
						children: [/* @__PURE__ */ d(G, {}), "6"]
					})
				})
			] })
		} : null;
	}
};
function bt(e, t) {
	let n = e.data, r = typeof n?.n == "number" ? n.n : 0, i = typeof n?.drawn == "number" ? n.drawn : 0, a = X(t, e.rid);
	return !a || r <= 0 ? null : {
		ms: 900,
		node: /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d(g, {
				at: a,
				ms: 620
			}),
			/* @__PURE__ */ d(m, {
				at: a,
				ms: 820,
				children: /* @__PURE__ */ f($, {
					tone: "sp-fx-pill--score",
					children: [
						/* @__PURE__ */ d(G, {}),
						"+",
						r
					]
				})
			}),
			i > 0 && /* @__PURE__ */ d(m, {
				at: a,
				ms: 820,
				delay: 220,
				children: /* @__PURE__ */ f($, {
					tone: "sp-fx-pill--quiet",
					children: ["+", i]
				})
			})
		] })
	};
}
//#endregion
//#region src/games/spots/options.tsx
function xt({ value: e, onChange: t }) {
	let n = a(), r = O.safeParse(e), i = r.success ? r.data : O.parse(void 0);
	return /* @__PURE__ */ d("div", {
		className: "flex flex-col gap-4",
		children: /* @__PURE__ */ d(v, {
			title: n("games.spots.trickSetLabel"),
			columns: 2,
			children: ee.map((e) => /* @__PURE__ */ d(_, {
				name: "spots-trick-set",
				value: e,
				checked: i.trickSet === e,
				label: n(x[e].nameKey),
				hint: n(x[e].descKey),
				accent: ne.accent,
				onChange: () => t({
					...i,
					trickSet: e
				})
			}, e))
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/spots/entry.tsx
var St = {
	definition: Fe,
	View: Be,
	bot: mt,
	describe: ht,
	fx: yt,
	Options: xt,
	locales: {
		zh: {
			name: "狗运当骰",
			desc: "掷骰填满斑点狗,骨头奖励助你重掷,率先计分 6 张狗牌获胜",
			rules: "目标:\n· 率先计分满 6 张狗牌的玩家立即获胜。\n准备:\n· 从 22 张技巧牌中按所选套组取出 6 张,正面朝上放在桌面中央。每个套组都包含「嚎叫」和「打滚」。\n· 洗混 40 张狗牌,发给每名玩家 2 张,灰色面朝上,作为该玩家的狗群。其余狗牌在桌面中央堆成一叠,灰色面朝上作为狗牌堆。\n· 将 40 颗骰子和骨头奖励放在所有人伸手可及的位置。\n· 每名玩家拿取 1 块院子、1 个骨头奖励和 1 颗骰子。每名玩家掷这颗骰子,并将它埋进自己的院子。\n· 埋藏点数最高的玩家先手。如果有多名玩家并列最高,则由这些玩家重新掷骰决定先手。\n流程:\n· 玩家按顺时针方向轮流行动。轮到你时,你可以选择执行一张正面朝上的技巧牌,或者计分自己的狗牌。\n· 执行技巧时,先取得技巧牌上放置的骨头奖励,然后将该技巧牌翻到背面,并按照牌面列出的顺序逐步执行。所有步骤默认必须执行,只有写出「可以」的步骤才是可选的。\n· 如果你因为无法满足条件而不能执行某一步,就跳过该步。无法执行第一步不会影响你继续执行后面的步骤。\n· 掷骰时,除非技巧牌另有说明,从公共骰堆取骰。掷骰之后,你可以把每颗骰子放到自己任意一张狗牌上点数相同的空格,每个空格只能放一颗骰子。\n· 你不能或不愿放置的骰子必须埋进自己的院子。任何时候,只要院中骰子的点数总和超过 7 点,你立即爆掉:本回合立刻结束,你狗牌上和院子里的所有骰子全部弃回公共骰堆。\n· 每完成一次掷骰,必须先把这次掷出的所有骰子放置或埋藏完毕,才能进行下一次掷骰。\n· 掷骰之后、放置或埋藏之前,你可以花费 1 个骨头奖励重掷本次掷出的全部骰子。你可以连续花费骨头奖励重掷,直到满意为止。每次只能重掷最近一次掷骰,并且不能只重掷其中一部分,「追踪」除外。\n· 当你执行技巧时,如果所有正面朝上的狗牌同时完成,立即计分这些狗牌。此时你必须先完成最近一次掷骰的全部放置或埋藏;如果这次掷骰导致你爆掉,则不能计分。计分后继续执行当前技巧。\n· 如果回合开始时只剩 1 张正面朝上的技巧牌,先从供应区拿取 1 个骨头奖励放在这张技巧牌上,然后将所有技巧牌翻到正面朝上。\n· 如果需要的骰子或骨头奖励不足,能拿多少就拿多少。极少数情况下,如果回合开始时公共骰堆没有骰子,所有玩家立即爆掉并弃掉自己的全部骰子,然后当前玩家照常继续回合。\n· 爪印只计算未计分狗牌;已计分的狗牌翻到背面后不再提供爪印。\n计分:\n· 轮到你时,如果不执行技巧,你可以计分自己的狗牌。你必须至少有 1 张已完成的狗牌(所有空格都已放满骰子)才能计分,并且必须计分全部已完成的狗牌,不能只计分其中一部分。\n· 计分时,弃掉所有已完成狗牌上的骰子,将这些狗牌翻到背面表示已计分。然后每计分 1 张狗牌,就从狗牌堆顶摸 1 张新狗牌加入自己的狗群,灰色面朝上。狗牌总数(已计分与未计分合计)最多为 6 张,达到 6 张后停止摸牌。\n· 已计分的狗牌不会因为爆掉而失去。\n结束:\n· 第一名拥有 6 张已计分狗牌的玩家立即获胜。\n技巧:\n· 嚎叫:如果你的狗牌少于 6 张,从狗牌堆顶摸 1 张狗牌加入狗群。然后掷 1 颗骰子。\n· 打滚:掷出你院子里的全部骰子。你可以花费骨头奖励重掷这些骰子,然后放置或埋藏。然后你可以掷 1 颗骰子。\n· 行走:掷 2 颗骰子。然后你可以掷 1 颗骰子。\n· 奔跑:掷 3 颗骰子。然后你可以反复掷 1 颗骰子,次数不限。\n· 捡球:掷 8 颗骰子。选择你掷出的一个点数,将该点数的所有骰子放置或埋藏,其余骰子弃掉。\n· 乞讨:拿取 1 个骨头奖励。然后,你每有 1 个未计分狗牌上的爪印,再拿取 1 个骨头奖励。\n· 挖掘:你每有 1 个未计分狗牌上的爪印,可以将任意玩家院子里的一颗骰子点数加 1 或减 1;将 1 点减为 0 时弃掉该骰子。然后掷 2 颗骰子。\n· 追逐:掷 1 颗骰子。然后你可以重复这个技巧,次数不限;每次重复时,比上一次多掷 1 颗骰子(2 颗、3 颗、4 颗,依此类推)。\n· 看守:说出一个点数,然后掷 4 颗骰子。弃掉所有点数大于你说出点数的骰子,其余骰子放置或埋藏。\n· 咀嚼:将你的骨头奖励数量翻倍。然后拿取 1 个骨头奖励。\n· 装死:掷 1 颗骰子。然后,如果你没有爆掉并将这颗骰子埋进院子,按照骰面点数拿取等量的骨头奖励。\n· 待命:除「待命」以外,每有 1 张背面朝上的技巧牌,拿取 1 个骨头奖励。\n· 觅食:掷 4 颗骰子。你可以弃掉任意点数小于你院子中所有骰子点数总和的骰子,然后将其余骰子放置或埋藏。\n· 搜寻:掷 7 颗骰子。如果可能,选择一组点数总和恰好为 8 点的骰子,将它们放置或埋藏;其余骰子弃掉。\n· 狩猎:掷 2 颗骰子,并额外为你狗牌上的每个爪印掷 1 颗骰子。将掷出的骰子中的 2 颗放置或埋藏,其余骰子弃掉。\n· 拾回:拿取 1 颗骰子,将它的点数设成狗牌堆顶那张狗牌上显示的一个点数。将这颗骰子放置或埋藏。然后掷 2 颗骰子。\n· 追踪:掷 3 颗骰子。当你花费骨头奖励重掷时,你可以只选择其中一部分骰子重掷。\n· 小跑:你可以将自己狗牌上的 1 颗骰子移到任意其他空格;如果新空格的点数不同,将这颗骰子的点数改为新空格的数字。然后掷 2 颗骰子。\n· 疾冲:先取出 3 至 12 颗骰子放在一旁。然后每次掷其中 1 颗。如果你拥有的爪印数量不少于剩余待掷骰子的数量,你可以提前停止。\n· 狗堆:拿取 2 颗骰子,再从你院子里的骰子或狗牌上的骰子中拿取 1 颗(如果有)。掷出这些骰子。你可以重复这个技巧,次数不限。\n· 冲刺:为你每张还有未填格子的狗牌各掷 1 颗骰子。你可以重复这个技巧,次数不限。",
			trickHowl: "嚎叫",
			trickRollOver: "打滚",
			trickWalk: "行走",
			trickRun: "奔跑",
			trickFetch: "捡球",
			trickBeg: "乞讨",
			trickDig: "挖掘",
			trickChase: "追逐",
			trickGuard: "看守",
			trickChew: "咀嚼",
			trickTrot: "小跑",
			trickBolt: "疾冲",
			trickGobble: "狼吞",
			trickRetrieve: "拾回",
			trickSprint: "冲刺",
			trickHunt: "狩猎",
			trickStay: "待命",
			trickTrack: "追踪",
			trickDogpile: "狗堆",
			trickSearch: "搜寻",
			trickScavenge: "觅食",
			trickPlayDead: "装死",
			trickHowlDesc: "狗牌少于 6 张时摸 1 张狗牌,然后掷 1 颗骰子。",
			trickRollOverDesc: "掷出院子里的全部骰子并放置或埋藏,然后可以掷 1 颗骰子。",
			trickWalkDesc: "掷 2 颗骰子,然后可以再掷 1 颗骰子。",
			trickRunDesc: "掷 3 颗骰子,然后可以反复掷 1 颗骰子。",
			trickFetchDesc: "掷 8 颗骰子,选择 1 个点数,将该点数的骰子全部放置或埋藏,其余弃掉。",
			trickBegDesc: "拿 1 个骨头奖励,再按未计分狗牌上的爪印数拿取等量骨头奖励。",
			trickDigDesc: "每个未计分狗牌上的爪印可调整任意玩家院子里 1 颗骰子的点数 1 点,然后掷 2 颗骰子。",
			trickChaseDesc: "掷 1 颗骰子,然后可以反复重掷,每次比上次多掷 1 颗。",
			trickGuardDesc: "说出 1 个点数,掷 4 颗骰子,弃掉大于该点数的骰子,其余放置或埋藏。",
			trickChewDesc: "骨头奖励翻倍,然后拿 1 个骨头奖励。",
			trickTrotDesc: "可以将狗牌上 1 颗骰子移到任意其他空格,然后掷 2 颗骰子。",
			trickBoltDesc: "取出 3 至 12 颗骰子逐颗掷出,爪印数不少于剩余待掷骰数时可以提前停止。",
			trickGobbleDesc: "拿 7 个骨头奖励,再按最高未填格子的点数退回骨头奖励。",
			trickRetrieveDesc: "拿 1 颗骰子设为狗牌堆顶的点数,放置或埋藏,然后掷 2 颗骰子。",
			trickSprintDesc: "每张有未填格子的狗牌各掷 1 颗骰子,可以反复执行。",
			trickHuntDesc: "掷 2 颗骰子,再按未计分狗牌上的爪印数追加骰子,选择 2 颗放置或埋藏,其余弃掉。",
			trickStayDesc: "除「待命」外,每有 1 张背面技巧牌,拿 1 个骨头奖励。",
			trickTrackDesc: "掷 3 颗骰子;花费骨头奖励重掷时,可以只重掷部分骰子。",
			trickDogpileDesc: "拿 2 颗骰子加 1 颗来自院子或狗牌的骰子一起掷,可以反复执行。",
			trickSearchDesc: "掷 7 颗骰子,选择总和恰好 8 点的骰子放置或埋藏,其余弃掉。",
			trickScavengeDesc: "掷 4 颗骰子,可以弃掉小于院子总点数的骰子,其余放置或埋藏。",
			trickPlayDeadDesc: "掷 1 颗骰子;若将它埋进院子且没有爆掉,按骰面点数拿骨头奖励。",
			setBase: "领养日",
			setBaseDesc: "嚎叫、打滚、行走、奔跑、捡球、乞讨",
			setDogPark: "狗狗公园",
			setDogParkDesc: "嚎叫、打滚、挖掘、追逐、看守、咀嚼",
			setAgility: "敏捷赛道",
			setAgilityDesc: "嚎叫、打滚、小跑、疾冲、捡球、狼吞",
			setHunting: "狩猎场",
			setHuntingDesc: "嚎叫、打滚、拾回、冲刺、狩猎、待命",
			setKennel: "犬舍俱乐部",
			setKennelDesc: "嚎叫、打滚、追踪、狗堆、搜寻、乞讨",
			setPuppy: "幼犬围栏",
			setPuppyDesc: "嚎叫、打滚、拾回、疾冲、觅食、装死",
			trickSetLabel: "技巧套组",
			yourTurn: "轮到你:执行技巧或计分狗牌",
			yourTurnRoll: "掷骰结果已出:重掷或开始放置",
			yourTurnPlace: "放置或埋藏本次掷出的骰子",
			chooseTrick: "选择一张正面技巧牌",
			chooseTrickSub: "执行技巧会将该牌翻到背面",
			chooseTrickAria: "执行技巧 {{name}}",
			scoreDogs: "计分狗牌",
			scoreDogsAria: "计分全部已完成的狗牌",
			mustComplete: "没有已完成的狗牌,先掷骰填满一张狗牌。",
			waitingTurn: "等 {{name}} 行动…",
			waitingTrick: "{{name}} 正在执行「{{trick}}」…",
			currentTrick: "当前技巧:{{name}}",
			deckCount: "狗牌堆 {{n}}",
			deckTop: "牌堆顶 {{name}}",
			deckTopTag: "牌堆顶",
			supplyDice: "骰子 {{n}}",
			supplyTreats: "骨头 {{n}}",
			treats: "骨头 {{n}}",
			yard: "院子",
			yardTotal: "院子 {{n}} / 7",
			otherPlayers: "其他玩家",
			publicArea: "公共区",
			scoredLabel: "已计分",
			yardEmpty: "院子空着",
			dogs: "狗群",
			scoredCount: "已计分 {{n}} / 6",
			paw: "爪印 {{n}}",
			pawShort: "{{n}} 爪印",
			dogComplete: "已完成",
			dogIncomplete: "还差 {{n}} 格",
			dogScored: "已计分",
			bust: "爆掉",
			busted: "爆掉,本回合结束",
			noDice: "没有可用的骰子",
			emptyYard: "院子里没有骰子",
			noCards: "没有狗牌",
			reroll: "重掷",
			rerollAll: "花费 1 骨头重掷全部",
			rerollSome: "花费 1 骨头重掷所选",
			rerollAria: "花费 1 个骨头奖励重掷本次掷骰",
			rerollPartialHint: "追踪:点选要重掷的骰子",
			confirmRoll: "开始放置",
			confirmRollAria: "保留本次点数,开始放置骰子",
			placeHint: "点选骰子,再点自己狗牌上的同点数空格",
			placeOn: "放到 {{dog}} 的第 {{n}} 格",
			placeAria: "把 {{die}} 点放到 {{dog}}",
			buryDie: "埋进院子",
			buryAria: "把 {{die}} 点埋进院子",
			autoPlace: "自动放置",
			autoPlaceAria: "自动把能放的骰子放上狗牌,其余埋进院子",
			buryRest: "其余全部埋藏",
			buryRestAria: "把尚未处理的骰子全部埋进院子",
			discardRest: "其余全部弃掉",
			discardRestAria: "把未选中的骰子全部弃掉",
			selectedDice: "已选 {{n}} 颗",
			selectedSum: "已选 {{n}} 颗,合计 {{sum}} 点",
			selectDiceHint: "点选要放置或埋藏的骰子",
			selectNumberFetch: "选择要保留的点数",
			selectNumberGuard: "先说出一个点数",
			selectNumberAria: "选择点数 {{n}}",
			guardRollAria: "按点数 {{n}} 掷 4 颗骰子",
			digPrompt: "还有 {{n}} 个爪印:调整任意玩家院子里 1 颗骰子,或跳过",
			digAria: "把 {{name}} 院子里的 {{die}} 点{{delta}}",
			digUp: "加 1",
			digDown: "减 1",
			skipDig: "跳过剩余爪印",
			trotPrompt: "可以移动自己狗牌上的 1 颗骰子到其他空格",
			trotFrom: "选择要移动的骰子",
			trotTo: "选择目标空格",
			trotAria: "把 {{dog}} 上的 {{die}} 点移到 {{toDog}} 的第 {{n}} 格",
			skipTrot: "不移动",
			retrievePrompt: "选择狗牌堆顶显示的点数",
			retrieveAria: "把拾回的骰子设为 {{n}} 点",
			skipRetrieve: "跳过拾回",
			dogpilePrompt: "点选院子或狗牌上的一颗骰子，它会与该技巧追加的 2 颗骰子一起掷出",
			dogpileYard: "从院子拿 {{n}} 点",
			dogpileDog: "从 {{dog}} 拿 {{n}} 点",
			dogpileNone: "没有可加的骰子,直接掷 2 颗",
			dogpileGo: "直接掷 2 颗",
			boltPrompt: "取出 3 至 12 颗骰子逐颗掷出",
			boltChoose: "取出 {{n}} 颗",
			boltStop: "提前停止",
			boltStopAria: "保留已掷结果并结束疾冲",
			boltRemaining: "剩余 {{n}} 颗待掷",
			boltPawsEnough: "爪印足够,可以提前停止",
			repeatPrompt: "可以继续这个技巧",
			repeatAria: "再执行一次当前步骤",
			stopPrompt: "结束这个技巧",
			stopAria: "不再重复,结束当前技巧",
			optionalPrompt: "可以再掷 1 颗骰子",
			skip: "跳过",
			skipAria: "跳过这个可选步骤",
			cancel: "取消",
			back: "返回",
			turnEnd: "回合结束",
			gameOver: "{{name}} 计分满 6 张狗牌,获胜!",
			finalScored: "已计分狗牌",
			finalCards: "狗群",
			finalRankAria: "最终排名",
			treatIconAria: "骨头奖励",
			dieAria: "{{n}} 点骰子",
			cardAria: "{{name}},{{filled}} / {{total}} 格",
			trickFaceup: "正面",
			trickFacedown: "背面",
			trickTreats: "牌上骨头 {{n}}",
			logTrick: "执行「{{trick}}」",
			logScore: "计分 {{n}} 张狗牌",
			logBust: "{{name}} 爆掉",
			logFastScore: "{{name}} 完成全部狗牌并计分",
			errNotYourTurn: "现在轮不到你",
			errBadAction: "当前不能执行这个操作",
			errNoTrick: "这张技巧牌不能选择",
			errNoCompleted: "没有已完成的狗牌可以计分",
			errBadNumber: "这个点数不可用",
			errBadDice: "骰子选择不合法",
			errBadSpace: "这个空格不能放这颗骰子",
			errNoTreat: "没有骨头奖励可以花费",
			errCannotStop: "还没有满足提前停止的条件",
			errNoTarget: "没有符合条件的目标",
			errNoDie: "没有可用的骰子",
			errDeckEmpty: "狗牌堆已经空了",
			hintTrick: "执行「{{trick}}」",
			hintScore: "计分全部已完成的狗牌",
			hintReroll: "花费 1 个骨头奖励重掷",
			hintBegin: "保留点数并开始放置",
			hintPlace: "把 {{die}} 点放到 {{dog}}",
			hintBury: "把 {{die}} 点埋进院子",
			hintAuto: "自动放置能放的骰子",
			hintBuryRest: "把剩余骰子全部埋进院子",
			hintDiscardRest: "弃掉未选中的骰子",
			hintNumber: "选择点数 {{n}}",
			hintDice: "选择 {{n}} 颗骰子",
			hintDig: "调整 {{name}} 院子里的一颗骰子",
			hintTrot: "移动狗牌上的一颗骰子",
			hintRetrieve: "把拾回的骰子设为 {{n}} 点",
			hintDogpile: "从{{from}}拿 1 颗骰子",
			hintRepeat: "再执行一次",
			hintStop: "结束当前技巧",
			hintSkip: "跳过这个步骤",
			hintBoltStop: "提前停止疾冲",
			scavengeHint: "可以弃掉点数小于院子总点数 {{n}} 的骰子",
			rollTray: "本次掷骰",
			discard: "弃掉",
			selected: "已选",
			spaceAria: "{{n}} 点空格",
			deckEmpty: "狗牌堆已经空了",
			waitingTurnShort: "等待其他玩家行动…",
			keepSelected: "保留所选",
			discardSelected: "弃掉所选",
			clearSelection: "清空选择",
			repeat: "继续",
			stop: "停止",
			hintPick: "选择一张正面技巧牌或计分狗牌"
		},
		en: {
			name: "Spots",
			desc: "Roll dice onto spotted dogs, spend bone treats to reroll, and score 6 dogs first",
			rules: "Goal:\n· The first player to score 6 dog cards wins immediately.\nSetup:\n· Take the 6 trick cards for the chosen set from the 22 trick cards and place them faceup in the middle of the table. Every set includes Howl and Roll Over.\n· Shuffle the 40 dog cards and deal 2 dog cards to each player, gray side up; this is that player's dog pack. Put the remaining dog cards in a gray-side-up stack in the middle as the dog deck.\n· Put the 40 dice and the bone treats within everyone's reach.\n· Each player takes 1 yard, 1 bone treat, and 1 die. Each player rolls that die and buries it in their yard.\n· The player with the highest buried die goes first. If several players tie for highest, those players reroll to decide.\nFlow:\n· Players take turns clockwise. On your turn, either perform a faceup trick or score your dogs.\n· To perform a trick, first take any treats placed on that trick card, flip the card facedown, and follow its steps in the order listed. Every step is mandatory unless it says \"may\".\n· If you cannot perform a step for any reason, skip it. Being unable to perform the first step does not prevent you from performing later steps.\n· When a step tells you to roll dice, take them from the common pile unless the trick says otherwise. After rolling, you may place each die on an empty space showing the same number on any of your dog cards. Each space holds only one die.\n· Dice you cannot or do not want to place must be buried in your yard. At any time, if the total number of spots on the dice in your yard is greater than 7, you bust: your turn ends immediately, and all dice on your dog cards and in your yard are discarded to the common pile.\n· After a roll, you must place or bury all dice from that roll before making another roll.\n· After rolling but before placing or burying, you may spend 1 bone treat to reroll all dice from that roll. You may spend treats to reroll repeatedly until you are satisfied. You may only reroll the most recent roll, and you may not reroll only some of its dice, except with Track.\n· While performing a trick, if all your faceup dog cards become complete at the same time, score them immediately. You must first place or bury all dice from the most recent roll; if that roll makes you bust, you do not score. After scoring, continue the current trick.\n· If only 1 faceup trick remains at the start of your turn, first place 1 bone treat from the supply on that trick, then flip all trick cards faceup.\n· If there are not enough dice or treats, take as many as you can. In the rare case that no dice are available at the start of your turn, all players immediately bust and discard all their dice, then the current player continues the turn as normal.\n· Paw prints count only on unscored dog cards. Scored dog cards are face down and no longer provide paw prints.\nScoring:\n· On your turn, instead of performing a trick, you may score your dogs. You must have at least 1 complete dog card (every space filled with a die), and you must score all complete dog cards, not only some of them.\n· To score, discard all dice on your complete dog cards and flip those cards face down to show they are scored. Then, for each dog card you scored, draw the top card of the dog deck and add it to your pack, gray side up. You may never have more than 6 dog cards in total, counting scored and unscored cards; stop drawing at 6.\n· Scored dog cards are never lost when you bust.\nEnd:\n· The first player to have 6 scored dog cards wins immediately.\nTricks:\n· Howl: If you have fewer than 6 dog cards, draw the top card of the dog deck and add it to your pack. Then roll 1 die.\n· Roll Over: Roll all dice in your yard. You may spend treats to reroll them, then place or bury them. Then you may roll 1 die.\n· Walk: Roll 2 dice. Then you may roll 1 die.\n· Run: Roll 3 dice. Then you may roll 1 die any number of times.\n· Fetch: Roll 8 dice. Choose a number you rolled; place or bury all dice showing that number, and discard the rest.\n· Beg: Take 1 bone treat. Then take 1 more bone treat for each paw print on your unscored dog cards.\n· Dig: For each paw print on your unscored dog cards, you may raise or lower any player's buried die by 1; lowering a 1 discards that die. Then roll 2 dice.\n· Chase: Roll 1 die. Then you may repeat this trick any number of times, rolling 1 more die each time than you did last time (2 dice, then 3, then 4, and so on).\n· Guard: Name a number, then roll 4 dice. Discard any dice greater than the number you named, and place or bury the rest.\n· Chew: Double your bone treats. Then take 1 bone treat.\n· Play Dead: Roll 1 die. Then, if you buried that die without busting, take 1 bone treat for each spot showing on it.\n· Stay: Take 1 bone treat for each facedown trick card other than Stay.\n· Scavenge: Roll 4 dice. You may discard any dice lower than the total number of spots on all dice in your yard, then place or bury the rest.\n· Search: Roll 7 dice. If possible, choose a set of dice showing a total of exactly 8 spots; place or bury them, and discard the rest.\n· Hunt: Roll 2 dice, plus 1 more die for each paw print on your unscored dog cards. Place or bury 2 of the rolled dice, and discard the rest.\n· Retrieve: Take 1 die and set it to any number shown on the top card of the dog deck. Place or bury it. Then roll 2 dice.\n· Track: Roll 3 dice. When you spend a treat to reroll, you may reroll only some of the dice.\n· Trot: You may move 1 die on your dog cards to any other empty space, changing its number to the number of that space if needed. Then roll 2 dice.\n· Bolt: Set aside 3 to 12 dice. Then roll them 1 at a time. If you have at least as many paw prints on your unscored dog cards as dice left to roll, you may stop early.\n· Dogpile: Take 2 dice, plus 1 more die from your yard or dog cards (if you have any). Roll them all. You may repeat this trick any number of times.\n· Sprint: Roll 1 die for each of your dog cards that has an unfilled space. You may repeat this trick any number of times.",
			trickHowl: "Howl",
			trickRollOver: "Roll Over",
			trickWalk: "Walk",
			trickRun: "Run",
			trickFetch: "Fetch",
			trickBeg: "Beg",
			trickDig: "Dig",
			trickChase: "Chase",
			trickGuard: "Guard",
			trickChew: "Chew",
			trickTrot: "Trot",
			trickBolt: "Bolt",
			trickGobble: "Gobble",
			trickRetrieve: "Retrieve",
			trickSprint: "Sprint",
			trickHunt: "Hunt",
			trickStay: "Stay",
			trickTrack: "Track",
			trickDogpile: "Dogpile",
			trickSearch: "Search",
			trickScavenge: "Scavenge",
			trickPlayDead: "Play Dead",
			trickHowlDesc: "If you have fewer than 6 dog cards, draw 1, then roll 1 die.",
			trickRollOverDesc: "Roll all dice in your yard, place or bury them, then you may roll 1 die.",
			trickWalkDesc: "Roll 2 dice, then you may roll 1 more die.",
			trickRunDesc: "Roll 3 dice, then you may roll 1 die any number of times.",
			trickFetchDesc: "Roll 8 dice, choose a number, and place or bury every die of that number; discard the rest.",
			trickBegDesc: "Take 1 bone treat, then 1 more for each paw print.",
			trickDigDesc: "For each paw print, adjust any player's buried die by 1, then roll 2 dice.",
			trickChaseDesc: "Roll 1 die, then repeat any number of times, rolling 1 more die each time.",
			trickGuardDesc: "Name a number, roll 4 dice, discard dice above it, and place or bury the rest.",
			trickChewDesc: "Double your bone treats, then take 1 bone treat.",
			trickTrotDesc: "You may move 1 die on your dogs to another space, then roll 2 dice.",
			trickBoltDesc: "Set aside 3 to 12 dice and roll them one at a time; you may stop early once your paw prints suffice.",
			trickGobbleDesc: "Take 7 bone treats, then return 1 for each spot in your highest unfilled space.",
			trickRetrieveDesc: "Set 1 die to a number on the top dog card, place or bury it, then roll 2 dice.",
			trickSprintDesc: "Roll 1 die for each dog with an unfilled space; you may repeat this any number of times.",
			trickHuntDesc: "Roll 2 dice plus 1 per paw print, place or bury 2, and discard the rest.",
			trickStayDesc: "Take 1 bone treat for each facedown trick other than Stay.",
			trickTrackDesc: "Roll 3 dice; when spending a treat to reroll, you may reroll only some dice.",
			trickDogpileDesc: "Take 2 dice plus 1 from your yard or dogs, roll them all, and repeat any number of times.",
			trickSearchDesc: "Roll 7 dice, place or bury a set totaling exactly 8 spots, and discard the rest.",
			trickScavengeDesc: "Roll 4 dice, you may discard dice below your yard total, then place or bury the rest.",
			trickPlayDeadDesc: "Roll 1 die; if you bury it without busting, take treats equal to its spots.",
			setBase: "Adoption Event",
			setBaseDesc: "Howl, Roll Over, Walk, Run, Fetch, Beg",
			setDogPark: "Dog Park",
			setDogParkDesc: "Howl, Roll Over, Dig, Chase, Guard, Chew",
			setAgility: "Agility Course",
			setAgilityDesc: "Howl, Roll Over, Trot, Bolt, Fetch, Gobble",
			setHunting: "Hunting Grounds",
			setHuntingDesc: "Howl, Roll Over, Retrieve, Sprint, Hunt, Stay",
			setKennel: "Kennel Club",
			setKennelDesc: "Howl, Roll Over, Track, Dogpile, Search, Beg",
			setPuppy: "Puppy Pen",
			setPuppyDesc: "Howl, Roll Over, Retrieve, Bolt, Scavenge, Play Dead",
			trickSetLabel: "Trick set",
			yourTurn: "Your turn: perform a trick or score your dogs",
			yourTurnRoll: "Dice rolled: reroll or begin placing",
			yourTurnPlace: "Place or bury the dice from this roll",
			chooseTrick: "Choose a faceup trick",
			chooseTrickSub: "Performing it flips the trick facedown",
			chooseTrickAria: "Perform the {{name}} trick",
			scoreDogs: "Score dogs",
			scoreDogsAria: "Score all complete dog cards",
			mustComplete: "No complete dog card yet. Roll dice to fill one first.",
			waitingTurn: "Waiting for {{name}}…",
			waitingTrick: "{{name}} is performing {{trick}}…",
			currentTrick: "Current trick: {{name}}",
			deckCount: "Dog deck {{n}}",
			deckTop: "Top card {{name}}",
			deckTopTag: "Top card",
			supplyDice: "Dice {{n}}",
			supplyTreats: "Treats {{n}}",
			treats: "Treats {{n}}",
			yard: "Yard",
			yardTotal: "Yard {{n}} / 7",
			otherPlayers: "Other players",
			publicArea: "Public area",
			scoredLabel: "Scored",
			yardEmpty: "Yard empty",
			dogs: "Dogs",
			scoredCount: "Scored {{n}} / 6",
			paw: "Paws {{n}}",
			pawShort: "{{n}} paws",
			dogComplete: "Complete",
			dogIncomplete: "{{n}} left",
			dogScored: "Scored",
			bust: "Bust",
			busted: "Bust! Turn over",
			noDice: "No dice available",
			emptyYard: "No dice in the yard",
			noCards: "No dog cards",
			reroll: "Reroll",
			rerollAll: "Spend 1 treat to reroll all",
			rerollSome: "Spend 1 treat to reroll selected",
			rerollAria: "Spend 1 bone treat to reroll this roll",
			rerollPartialHint: "Track: tap the dice you want to reroll",
			confirmRoll: "Begin placing",
			confirmRollAria: "Keep this roll and begin placing dice",
			placeHint: "Tap a die, then tap a matching empty space on your dogs",
			placeOn: "Place on {{dog}}, space {{n}}",
			placeAria: "Place the {{die}} die on {{dog}}",
			buryDie: "Bury in yard",
			buryAria: "Bury the {{die}} die in your yard",
			autoPlace: "Auto-place",
			autoPlaceAria: "Automatically place legal dice and bury the rest",
			buryRest: "Bury all remaining",
			buryRestAria: "Bury every unassigned die in your yard",
			discardRest: "Discard the rest",
			discardRestAria: "Discard all unselected dice",
			selectedDice: "{{n}} selected",
			selectedSum: "{{n}} selected, {{sum}} spots",
			selectDiceHint: "Tap the dice to place or bury",
			selectNumberFetch: "Choose a number to keep",
			selectNumberGuard: "Name a number first",
			selectNumberAria: "Choose number {{n}}",
			guardRollAria: "Roll 4 dice after naming {{n}}",
			digPrompt: "{{n}} paw prints left: adjust 1 buried die of any player, or skip",
			digAria: "Change the {{die}} die in {{name}}'s yard by {{delta}}",
			digUp: "Raise by 1",
			digDown: "Lower by 1",
			skipDig: "Skip remaining paws",
			trotPrompt: "You may move 1 die on your dogs to another space",
			trotFrom: "Choose a die to move",
			trotTo: "Choose the destination space",
			trotAria: "Move the {{die}} die on {{dog}} to {{toDog}}, space {{n}}",
			skipTrot: "Do not move",
			retrievePrompt: "Choose a number shown on the top dog card",
			retrieveAria: "Set the retrieved die to {{n}}",
			skipRetrieve: "Skip Retrieve",
			dogpilePrompt: "Tap a die in your yard or on your dogs to roll it with 2 extra dice",
			dogpileYard: "Take {{n}} from yard",
			dogpileDog: "Take {{n}} from {{dog}}",
			dogpileNone: "No extra die available; roll 2 dice",
			dogpileGo: "Roll 2 dice instead",
			boltPrompt: "Set aside 3 to 12 dice to roll one at a time",
			boltChoose: "Set aside {{n}} dice",
			boltStop: "Stop early",
			boltStopAria: "Keep the current results and end Bolt",
			boltRemaining: "{{n}} dice left to roll",
			boltPawsEnough: "Enough paw prints: you may stop early",
			repeatPrompt: "You may continue this trick",
			repeatAria: "Perform the current step again",
			stopPrompt: "Finish this trick",
			stopAria: "Do not repeat; finish the current trick",
			optionalPrompt: "You may roll 1 more die",
			skip: "Skip",
			skipAria: "Skip this optional step",
			cancel: "Cancel",
			back: "Back",
			turnEnd: "Turn over",
			gameOver: "{{name}} scored 6 dogs and wins!",
			finalScored: "Scored dogs",
			finalCards: "Dog pack",
			finalRankAria: "Final ranking",
			treatIconAria: "Bone treat",
			dieAria: "Die showing {{n}}",
			cardAria: "{{name}}, {{filled}} of {{total}} spaces filled",
			trickFaceup: "Faceup",
			trickFacedown: "Facedown",
			trickTreats: "Treats on card: {{n}}",
			logTrick: "Performs {{trick}}",
			logScore: "Scores {{n}} dog cards",
			logBust: "{{name}} busts",
			logFastScore: "{{name}} completes all dogs and scores",
			errNotYourTurn: "It is not your turn",
			errBadAction: "You cannot do that now",
			errNoTrick: "That trick cannot be chosen",
			errNoCompleted: "No complete dog card to score",
			errBadNumber: "That number is not available",
			errBadDice: "That dice selection is not legal",
			errBadSpace: "That die cannot go in that space",
			errNoTreat: "No bone treat to spend",
			errCannotStop: "You do not meet the condition to stop yet",
			errNoTarget: "No legal target",
			errNoDie: "No die available",
			errDeckEmpty: "The dog deck is empty",
			hintTrick: "Perform {{trick}}",
			hintScore: "Score all complete dogs",
			hintReroll: "Spend 1 bone treat to reroll",
			hintBegin: "Keep the roll and begin placing",
			hintPlace: "Place the {{die}} die on {{dog}}",
			hintBury: "Bury the {{die}} die in the yard",
			hintAuto: "Auto-place every legal die",
			hintBuryRest: "Bury all remaining dice",
			hintDiscardRest: "Discard the unselected dice",
			hintNumber: "Choose number {{n}}",
			hintDice: "Select {{n}} dice",
			hintDig: "Adjust a buried die in {{name}}'s yard",
			hintTrot: "Move a die on your dogs",
			hintRetrieve: "Set the retrieved die to {{n}}",
			hintDogpile: "Take 1 die from {{from}}",
			hintRepeat: "Do it again",
			hintStop: "Finish the current trick",
			hintSkip: "Skip this step",
			hintBoltStop: "Stop Bolt early",
			scavengeHint: "You may discard dice lower than your yard total ({{n}})",
			rollTray: "This roll",
			discard: "Discard",
			selected: "Selected",
			spaceAria: "{{n}}-spot space",
			deckEmpty: "The dog deck is empty",
			waitingTurnShort: "Waiting for the other players…",
			keepSelected: "Keep selected",
			discardSelected: "Discard selected",
			clearSelection: "Clear selection",
			repeat: "Continue",
			stop: "Stop",
			hintPick: "Choose a faceup trick or score your dogs"
		}
	}
};
//#endregion
export { St as default };
