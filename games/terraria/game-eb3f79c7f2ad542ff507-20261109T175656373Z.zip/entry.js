import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { IconClose as c, IconHistory as l, IconInfo as u } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as ee, seatName as te } from "@bgparty/sdk/ui/player-strip";
import { AVATARS as ne } from "@bgparty/sdk/avatars";
import { SheetFxProbe as p, SheetView as re } from "@bgparty/sdk/sheet-view";
import { Fragment as ie, jsx as m, jsxs as h } from "react/jsx-runtime";
import { Floater as g, FlySprite as ae, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as oe } from "@bgparty/sdk/confirm-button";
//#region src/games/terraria/catalog.ts
var v = [
	{
		id: "d5e851",
		biome: "forest",
		layer: 2,
		cells: [
			"fe",
			"#",
			"#",
			"fe",
			"fe",
			"#",
			"s",
			"#",
			"s",
			"g",
			"s",
			"s",
			"#",
			"au",
			"#"
		]
	},
	{
		id: "190aa7",
		biome: "forest",
		layer: 2,
		cells: [
			"#",
			"s",
			"s",
			".",
			".",
			".",
			".",
			".",
			".",
			"C1",
			"S",
			".",
			"s",
			"fe",
			"."
		]
	},
	{
		id: "7f2eb2",
		biome: "forest",
		layer: 3,
		cells: [
			"s",
			".",
			"#",
			"W",
			".",
			".",
			".",
			".",
			".",
			"C1",
			".",
			"S",
			"s",
			"s",
			"s"
		]
	},
	{
		id: "d7adfd",
		biome: "forest",
		layer: 2,
		cells: [
			"#",
			"#",
			"fe",
			"s",
			"#",
			".",
			".",
			".",
			"S",
			"W",
			".",
			"s",
			"#",
			"s",
			"ag"
		]
	},
	{
		id: "f7be32",
		biome: "forest",
		layer: 3,
		cells: [
			"#",
			"ag",
			"#",
			"s",
			"s",
			"s",
			"s",
			"au",
			"s",
			"#",
			"s",
			"#",
			"#",
			"s",
			"#"
		]
	},
	{
		id: "558959",
		biome: "forest",
		layer: 3,
		cells: [
			"s",
			"s",
			"s",
			".",
			".",
			".",
			".",
			".",
			"W",
			".",
			".",
			"s",
			".",
			"g",
			"ag"
		]
	},
	{
		id: "088eaa",
		biome: "desert",
		layer: 3,
		cells: [
			"hs",
			"hs",
			"hs",
			".",
			"au",
			"#",
			"S",
			".",
			"#",
			"#",
			".",
			"C1",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "e89f47",
		biome: "desert",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"T2",
			".",
			".",
			".",
			".",
			"#",
			"#",
			"fe"
		]
	},
	{
		id: "ac837b",
		biome: "desert",
		layer: 3,
		cells: [
			"#",
			"#",
			"#",
			"#",
			".",
			".",
			".",
			"S",
			"hs",
			".",
			"hs",
			"ag",
			"#",
			"g",
			"#"
		]
	},
	{
		id: "5d2795",
		biome: "desert",
		layer: 2,
		cells: [
			"fe",
			"#",
			"#",
			"hs",
			"hs",
			".",
			"#",
			".",
			"C1",
			".",
			"S",
			"#",
			"#",
			"ag",
			"#"
		]
	},
	{
		id: "876fec",
		biome: "desert",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"S",
			".",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "f2c2d8",
		biome: "desert",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			"T2",
			".",
			".",
			".",
			"C1",
			"S",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "2d021c",
		biome: "desert",
		layer: 3,
		cells: [
			"#",
			"#",
			"#",
			"#",
			"#",
			"#",
			"#",
			"au",
			"hs",
			"#",
			"hs",
			"hs",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "b574ca",
		biome: "desert",
		layer: 2,
		cells: [
			"#",
			"#",
			"#",
			"#",
			"fe",
			"#",
			"#",
			"hs",
			"#",
			"hs",
			"au",
			"hs",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "05ce12",
		biome: "desert",
		layer: 2,
		cells: [
			"#",
			"#",
			"#",
			".",
			".",
			"#",
			"fe",
			".",
			".",
			"hs",
			"hs",
			"S",
			"ag",
			"#",
			"g"
		]
	},
	{
		id: "7fc926",
		biome: "snow",
		layer: 3,
		cells: [
			"#",
			"#",
			"#",
			"ice",
			"#",
			"#",
			"ice",
			"au",
			"#",
			"ice",
			"ice",
			"ice",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "e13c66",
		biome: "snow",
		layer: 3,
		cells: [
			"ice",
			"#",
			"#",
			"ag",
			".",
			".",
			".",
			".",
			"S",
			"C1",
			".",
			"#",
			"#",
			"g",
			"ice"
		]
	},
	{
		id: "530128",
		biome: "snow",
		layer: 2,
		cells: [
			"#",
			"#",
			"#",
			"fe",
			"fe",
			"#",
			"#",
			"ice",
			"ice",
			"#",
			"ag",
			"ice",
			"#",
			"au",
			"#"
		]
	},
	{
		id: "317109",
		biome: "snow",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"T3",
			".",
			".",
			".",
			".",
			".",
			"#",
			"cu"
		]
	},
	{
		id: "eafb3d",
		biome: "snow",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"T2",
			"T2",
			"S",
			".",
			".",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "28c081",
		biome: "snow",
		layer: 2,
		cells: [
			"fe",
			"ice",
			"#",
			"ice",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"C1",
			"#",
			".",
			"#"
		]
	},
	{
		id: "ddfc7e",
		biome: "snow",
		layer: 3,
		cells: [
			"#",
			"#",
			"#",
			".",
			"au",
			"ice",
			".",
			".",
			".",
			".",
			"S",
			".",
			"#",
			"ice",
			"#"
		]
	},
	{
		id: "4834a3",
		biome: "snow",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			"T3",
			".",
			".",
			".",
			"C1",
			"S",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "7fbd1f",
		biome: "snow",
		layer: 2,
		cells: [
			"#",
			"fe",
			"ice",
			".",
			".",
			"ice",
			".",
			".",
			".",
			".",
			"S",
			".",
			"ag",
			"ag",
			"g"
		]
	},
	{
		id: "f3f80c",
		biome: "jungle",
		layer: 2,
		cells: [
			"#",
			"#",
			"#",
			"#",
			"#",
			"fe",
			"#",
			"#",
			"#",
			"#",
			"ag",
			"#",
			"g",
			"#",
			"#"
		]
	},
	{
		id: "8b4ee9",
		biome: "jungle",
		layer: 3,
		cells: [
			"#",
			"#",
			".",
			"T2",
			".",
			".",
			"C2",
			"S",
			"T2",
			"#",
			"au",
			".",
			"g",
			"#",
			"#"
		]
	},
	{
		id: "6eb97a",
		biome: "jungle",
		layer: 3,
		cells: [
			"#",
			"#",
			"#",
			"#",
			".",
			"#",
			"#",
			".",
			"#",
			".",
			"Larva",
			".",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "b88e53",
		biome: "jungle",
		layer: 2,
		cells: [
			"fe",
			"#",
			"#",
			".",
			".",
			".",
			".",
			".",
			"T2",
			"T2",
			".",
			"C2",
			"#",
			".",
			"ag"
		]
	},
	{
		id: "7d163c",
		biome: "jungle",
		layer: 3,
		cells: [
			"#",
			"#",
			"#",
			"#",
			"ag",
			"#",
			"#",
			"#",
			"#",
			"#",
			"au",
			"#",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "fab69d",
		biome: "jungle",
		layer: 0,
		cells: [
			"C1",
			"S",
			".",
			"#",
			"#",
			".",
			"#",
			".",
			".",
			"#",
			".",
			"T3",
			"#",
			".",
			"."
		]
	},
	{
		id: "266dfb",
		biome: "jungle",
		layer: 2,
		cells: [
			"#",
			"fe",
			".",
			".",
			".",
			"T2",
			"T2",
			"S",
			".",
			".",
			"#",
			"#",
			"#",
			"au",
			"#"
		]
	},
	{
		id: "597d39",
		biome: "jungle",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			"T3",
			"S",
			".",
			".",
			"#",
			".",
			"#",
			"#",
			"#",
			"cu",
			"#"
		]
	},
	{
		id: "562288",
		biome: "jungle",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			"T2",
			"#",
			"T3",
			".",
			"#",
			".",
			"fe",
			"#",
			"#"
		]
	},
	{
		id: "1e502a",
		biome: "crimson",
		layer: 3,
		cells: [
			"cs",
			"cs",
			"#",
			"cr",
			".",
			".",
			".",
			".",
			".",
			"C2",
			".",
			"S",
			"#",
			".",
			"cr"
		]
	},
	{
		id: "ab3075",
		biome: "crimson",
		layer: 2,
		cells: [
			"cs",
			"cs",
			"cs",
			".",
			".",
			".",
			"S",
			".",
			".",
			"cs",
			"Altar",
			".",
			"cr",
			"cs",
			"."
		]
	},
	{
		id: "b03c2b",
		biome: "crimson",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			"T2",
			"#",
			"T3",
			".",
			"#",
			".",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "4af6f8",
		biome: "crimson",
		layer: 3,
		cells: [
			"#",
			"cr",
			"#",
			"cs",
			"cs",
			"cs",
			"cs",
			"Heart4",
			"cs",
			"cs",
			"cs",
			"cs",
			"#",
			"cr",
			"#"
		]
	},
	{
		id: "5de5e8",
		biome: "crimson",
		layer: 2,
		cells: [
			"cs",
			"cs",
			"cs",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"C2",
			".",
			".",
			"cr",
			"cs"
		]
	},
	{
		id: "341e33",
		biome: "crimson",
		layer: 2,
		cells: [
			"cs",
			"cs",
			"cs",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"S",
			"cs",
			"g",
			"cs"
		]
	},
	{
		id: "8883d9",
		biome: "crimson",
		layer: 3,
		cells: [
			".",
			"cs",
			"cs",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"S",
			".",
			"#",
			"cr",
			"."
		]
	},
	{
		id: "31f3be",
		biome: "crimson",
		layer: 0,
		cells: [
			"T2",
			".",
			".",
			".",
			"S",
			"T2",
			"#",
			"#",
			".",
			"C1",
			".",
			"#",
			"#",
			".",
			"#"
		]
	},
	{
		id: "779010",
		biome: "crimson",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			"#",
			"T3",
			"#",
			"#",
			".",
			"#",
			"#",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "c70e6b",
		biome: "corruption",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			"T3",
			"T2",
			".",
			".",
			".",
			"#",
			"#",
			"#",
			"fe"
		]
	},
	{
		id: "0cc497",
		biome: "corruption",
		layer: 3,
		cells: [
			"#",
			"de",
			"#",
			"de",
			"#",
			"#",
			"es",
			"es",
			"es",
			"es",
			"Orb4",
			"es",
			"es",
			"es",
			"es"
		]
	},
	{
		id: "2b6f9b",
		biome: "corruption",
		layer: 0,
		cells: [
			".",
			"T2",
			".",
			".",
			".",
			"S",
			".",
			"#",
			"#",
			"#",
			".",
			"C1",
			"#",
			".",
			"."
		]
	},
	{
		id: "6e07b6",
		biome: "corruption",
		layer: 3,
		cells: [
			"es",
			"es",
			"#",
			"#",
			"W",
			".",
			".",
			".",
			".",
			".",
			"C2",
			"S",
			"de",
			"de",
			"es"
		]
	},
	{
		id: "bc2440",
		biome: "corruption",
		layer: 2,
		cells: [
			"es",
			"es",
			"es",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"C2",
			".",
			".",
			"de",
			"es"
		]
	},
	{
		id: "254122",
		biome: "corruption",
		layer: 3,
		cells: [
			".",
			"#",
			"#",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"S",
			".",
			"g",
			"de",
			"."
		]
	},
	{
		id: "775483",
		biome: "corruption",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			"T3",
			".",
			"T2",
			".",
			"#",
			".",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "e2cd7b",
		biome: "corruption",
		layer: 2,
		cells: [
			"es",
			"es",
			"es",
			".",
			".",
			".",
			"S",
			".",
			".",
			"es",
			"Altar",
			".",
			"de",
			"es",
			"."
		]
	},
	{
		id: "1a292d",
		biome: "corruption",
		layer: 2,
		cells: [
			"es",
			"es",
			"es",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"S",
			".",
			"es",
			"g",
			"es"
		]
	},
	{
		id: "f52fc8",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"#",
			"#",
			"cu",
			"s",
			".",
			"#",
			".",
			"W",
			".",
			"S",
			"#",
			"s",
			"g",
			"#"
		]
	},
	{
		id: "a46c54",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"#",
			"#",
			"#",
			"fe",
			"s",
			"#",
			"s",
			"#",
			"s",
			"#",
			"#",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "4b8e37",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"#",
			"#",
			"#",
			"fe",
			"#",
			"#",
			"#",
			"#",
			"#",
			"s",
			"#",
			"s",
			"#",
			"s"
		]
	},
	{
		id: "ab4ae2",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"#",
			"#",
			"s",
			"s",
			"s",
			"#",
			"fe",
			"#",
			"#",
			"#",
			"#",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "7ea13a",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"s",
			"s",
			".",
			".",
			"#",
			".",
			".",
			".",
			"cu",
			".",
			"W",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "08fc10",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"#",
			"#",
			"#",
			"#",
			"s",
			"#",
			"s",
			"s",
			"#",
			"fe",
			"#",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "cd2fc5",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"#",
			"#",
			"#",
			"#",
			"#",
			"#",
			"fe",
			"#",
			"s",
			"s",
			"s",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "973949",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"#",
			"#",
			"#",
			"cu",
			"#",
			".",
			"S",
			".",
			"C2",
			"s",
			"s",
			"#",
			"#",
			"ag"
		]
	},
	{
		id: "152e5a",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"cu",
			"#",
			"#",
			".",
			".",
			"#",
			".",
			"S",
			"s",
			"s",
			"#",
			"ag",
			"#",
			"#"
		]
	},
	{
		id: "5cdaa7",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"#",
			"#",
			".",
			"#",
			"cu",
			".",
			".",
			".",
			"C1",
			"S",
			".",
			"#",
			"s",
			"s"
		]
	},
	{
		id: "ef1725",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"#",
			"#",
			"cu",
			"s",
			"s",
			".",
			".",
			"#",
			"C1",
			".",
			"#",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "8add4f",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"s",
			"#",
			".",
			"s",
			"#",
			".",
			".",
			"cu",
			"#",
			"W",
			".",
			"#",
			"ag",
			"#"
		]
	},
	{
		id: "8d2914",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"s",
			"#",
			"C2",
			".",
			"#",
			"#",
			".",
			".",
			"#",
			"cu",
			"S",
			"#",
			"s",
			"#"
		]
	},
	{
		id: "8a2cd3",
		biome: "underground",
		layer: 1,
		cells: [
			"#",
			"#",
			"#",
			"#",
			"cu",
			"#",
			".",
			".",
			"S",
			".",
			".",
			"s",
			"s",
			".",
			"g"
		]
	},
	{
		id: "b14a76",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"C2",
			".",
			"#",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "602f13",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"S",
			".",
			"#",
			"#",
			"he"
		]
	},
	{
		id: "58c0db",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"#",
			".",
			"C2",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "0ae90f",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"L",
			"#",
			"L"
		]
	},
	{
		id: "88a4ff",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"S",
			".",
			"he",
			"#",
			".",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "d693ee",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			"S",
			".",
			"he",
			"#",
			"#",
			"he",
			".",
			".",
			"#",
			".",
			".",
			"#",
			"L",
			"#"
		]
	},
	{
		id: "335ae3",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"he",
			".",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "375593",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"#",
			".",
			"C2",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "0df2a1",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			"#",
			".",
			".",
			"#",
			".",
			".",
			"he",
			".",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "4f28db",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"S",
			".",
			"#",
			"he",
			"#",
			"#"
		]
	},
	{
		id: "d63de6",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"L",
			"L",
			"L"
		]
	},
	{
		id: "da44b3",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"S",
			"#",
			".",
			"#",
			"he",
			"#",
			"he",
			"#"
		]
	},
	{
		id: "9f7cf5",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"L",
			"L",
			"#"
		]
	},
	{
		id: "dfca20",
		biome: "underworld",
		layer: 4,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"S",
			".",
			".",
			"he",
			".",
			"#",
			"#",
			"#"
		]
	},
	{
		id: "099503",
		biome: "underworld",
		layer: 4,
		cells: [
			"S",
			".",
			".",
			"#",
			"#",
			"#",
			".",
			".",
			"#",
			".",
			".",
			"he",
			"L",
			"L",
			"he"
		]
	},
	{
		id: "966c2f",
		biome: "beach",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"T3",
			".",
			".",
			".",
			"Ocean",
			"Ocean",
			"#"
		]
	},
	{
		id: "90c913",
		biome: "beach",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			"T3",
			".",
			".",
			".",
			".",
			".",
			"#",
			"Ocean",
			"Ocean"
		]
	},
	{
		id: "f6d5dc",
		biome: "forest",
		layer: 1,
		cells: [
			"s",
			"#",
			"#",
			"#",
			"s",
			"#",
			".",
			".",
			"W",
			"#",
			"C1",
			"#",
			"cu",
			"#",
			"#"
		]
	},
	{
		id: "c2cd53",
		biome: "forest",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"T2",
			".",
			"S",
			"C1",
			".",
			"#",
			"#",
			"."
		]
	},
	{
		id: "d912eb",
		biome: "forest",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"T2",
			"T1",
			".",
			".",
			"."
		]
	},
	{
		id: "e29094",
		biome: "forest",
		layer: 0,
		cells: [
			".",
			".",
			".",
			".",
			".",
			".",
			".",
			"T1",
			".",
			".",
			".",
			"S",
			".",
			"cu",
			"#"
		]
	}
], y = [
	{
		id: "a0",
		slot: 0,
		name: "Second Wind",
		source: "guide",
		cost: 5,
		effect: "Attack2 OR ready Attack1",
		copies: 8
	},
	{
		id: "a1",
		slot: 1,
		name: "Explore More",
		source: "guide",
		cost: 5,
		effect: "AP2",
		copies: 8
	},
	{
		id: "a2",
		slot: 2,
		name: "Somersault",
		source: "guide",
		cost: 5,
		effect: "Draw2 keep1 discard other OR ready Defense1",
		copies: 8
	},
	{
		id: "a3",
		slot: 3,
		name: "Recuperate",
		source: "loot",
		cost: 1,
		effect: "AP1 + Health1",
		copies: 1
	},
	{
		id: "a4",
		slot: 4,
		name: "Doubletap",
		source: "loot",
		cost: 1,
		effect: "AP1 OR copy icons/effects from a starting action card in your hand",
		copies: 1
	},
	{
		id: "a5",
		slot: 5,
		name: "Escape Route",
		source: "loot",
		cost: 1,
		effect: "AP1 + place up to2 platforms without crafting",
		copies: 1
	},
	{
		id: "a6",
		slot: 6,
		name: "Aglet",
		source: "loot",
		cost: 1,
		effect: "ready AP2",
		copies: 1
	},
	{
		id: "a7",
		slot: 7,
		name: "Juiced Up",
		source: "loot",
		cost: 1,
		effect: "AP1 + Mana1",
		copies: 1
	},
	{
		id: "a8",
		slot: 8,
		name: "Cha-Ching!",
		source: "loot",
		cost: 1,
		effect: "AP1 + Coin2",
		copies: 1
	},
	{
		id: "a9",
		slot: 9,
		name: "Industrious",
		source: "loot",
		cost: 1,
		effect: "This turn all characters located in the same biome as your character gain Chop1 Dig1",
		copies: 1
	},
	{
		id: "a10",
		slot: 10,
		name: "Fingers Crossed",
		source: "loot",
		cost: 1,
		effect: "AP1 + discard1 from hand then draw1",
		copies: 1
	},
	{
		id: "a11",
		slot: 11,
		name: "Helping Hand",
		source: "loot",
		cost: 2,
		effect: "AP2 + another player draws2 OR two other players each draw1; solo yourself",
		copies: 1
	},
	{
		id: "a12",
		slot: 12,
		name: "Double Measure",
		source: "loot",
		cost: 2,
		effect: "AP1 + use a single consumable twice",
		copies: 1
	},
	{
		id: "a13",
		slot: 13,
		name: "Rallying Cry",
		source: "loot",
		cost: 2,
		effect: "This turn all characters located in the same biome as your character gain Attack2 Defense2",
		copies: 1
	},
	{
		id: "a14",
		slot: 14,
		name: "Magic Mirror",
		source: "loot",
		cost: 2,
		effect: "AP2 OR teleport to empty Forest Surface block or bedhouse block",
		copies: 1
	},
	{
		id: "a15",
		slot: 15,
		name: "Sidestep",
		source: "loot",
		cost: 2,
		effect: "AP1 + once this turn reroll one highest-value attack die of one enemy",
		copies: 1
	},
	{
		id: "a16",
		slot: 16,
		name: "Seize the Opportunity",
		source: "loot",
		cost: 2,
		effect: "AP1 OR once this turn reroll one highest-value defense die of one enemy",
		copies: 1
	},
	{
		id: "a17",
		slot: 17,
		name: "Accessorize",
		source: "loot",
		cost: 2,
		effect: "Clear all debuffs from any number of other characters OR ready immune frozen/on-fire/poisoned",
		copies: 1
	},
	{
		id: "a18",
		slot: 18,
		name: "Shakedown",
		source: "loot",
		cost: 2,
		effect: "AP1 + double loot when defeating a non-boss enemy this turn",
		copies: 1
	},
	{
		id: "a19",
		slot: 19,
		name: "Thick-Skinned",
		source: "loot",
		cost: 3,
		effect: "AP2 + duplicate one of your smallest defense dice this turn",
		copies: 1
	},
	{
		id: "a20",
		slot: 20,
		name: "Band of Starpower",
		source: "loot",
		cost: 3,
		effect: "AP2 OR Mana2",
		copies: 1
	},
	{
		id: "a21",
		slot: 21,
		name: "Favourite Move",
		source: "loot",
		cost: 3,
		effect: "AP2 + fetch1 from draw deck to hand without shuffling",
		copies: 1
	},
	{
		id: "a22",
		slot: 22,
		name: "De-escalate",
		source: "loot",
		cost: 3,
		effect: "May reduce threat1; if so lose Health4",
		copies: 1
	},
	{
		id: "a23",
		slot: 23,
		name: "Band of Regeneration",
		source: "loot",
		cost: 3,
		effect: "AP2 + Health1 for each non-boss enemy you defeat this turn",
		copies: 1
	},
	{
		id: "a24",
		slot: 24,
		name: "Enraged",
		source: "loot",
		cost: 3,
		effect: "AP2 + Attack2",
		copies: 1
	},
	{
		id: "a25",
		slot: 25,
		name: "Shackle",
		source: "loot",
		cost: 3,
		effect: "AP2 OR ready Defense2",
		copies: 1
	},
	{
		id: "a26",
		slot: 26,
		name: "Radar",
		source: "loot",
		cost: 3,
		effect: "AP2 + this turn when spawning non-boss draw2 choose1 return other to tray",
		copies: 1
	},
	{
		id: "a27",
		slot: 27,
		name: "Nope!",
		source: "loot",
		cost: 4,
		effect: "AP2 + demote one smallest attack die of one enemy this turn; minimum D4",
		copies: 1
	},
	{
		id: "a28",
		slot: 28,
		name: "Take That",
		source: "loot",
		cost: 4,
		effect: "AP2 + demote one smallest defense die of one enemy this turn; minimum D4",
		copies: 1
	},
	{
		id: "a29",
		slot: 29,
		name: "Double Trouble",
		source: "loot",
		cost: 4,
		effect: "AP2 + copy icons/effects from one action card in your hand",
		copies: 1
	},
	{
		id: "a30",
		slot: 30,
		name: "Lifeform Analyzer",
		source: "loot",
		cost: 4,
		effect: "AP2 + this turn when spawning non-boss draw3 choose1 return others to tray",
		copies: 1
	},
	{
		id: "a31",
		slot: 31,
		name: "Shoe Spikes",
		source: "loot",
		cost: 4,
		effect: "AP2 OR ready move along vertical surfaces; end Character phase on horizontal surface",
		copies: 1
	},
	{
		id: "a32",
		slot: 32,
		name: "Reclaim",
		source: "loot",
		cost: 4,
		effect: "AP2 + fetch1 from draw or discard",
		copies: 1
	},
	{
		id: "a33",
		slot: 33,
		name: "Stockpile",
		source: "loot",
		cost: 4,
		effect: "ready extra resource slot capacity20; discard resource when card leaves ready",
		copies: 1
	},
	{
		id: "a34",
		slot: 34,
		name: "Hermes Boots",
		source: "loot",
		cost: 4,
		effect: "AP2 OR ready normal movement2 steps per AP; rope unchanged",
		copies: 1
	},
	{
		id: "a35",
		slot: 35,
		name: "Bring It On",
		source: "loot",
		cost: 5,
		effect: "AP2 + demote one largest attack die of one enemy this turn; minimum D4",
		copies: 1
	},
	{
		id: "a36",
		slot: 36,
		name: "Intimidate",
		source: "loot",
		cost: 5,
		effect: "AP2 + demote one largest defense die of one enemy this turn; minimum D4",
		copies: 1
	},
	{
		id: "a37",
		slot: 37,
		name: "Geared Up",
		source: "loot",
		cost: 5,
		effect: "AP1 + draw3",
		copies: 1
	},
	{
		id: "a38",
		slot: 38,
		name: "Retrieve",
		source: "loot",
		cost: 5,
		effect: "AP2 + fetch1 from draw/discard/scrapped cards this game",
		copies: 1
	},
	{
		id: "a39",
		slot: 39,
		name: "Finisher",
		source: "loot",
		cost: 5,
		effect: "If all characters on same tile perform 3D20 short/medium/long attack then scrap this card",
		copies: 1
	},
	{
		id: "a40",
		slot: 40,
		name: "Take Out the Trash",
		source: "loot",
		cost: 5,
		effect: "AP2 + scrap2 from hand and/or discard; scrapping optional by rulebook",
		copies: 1
	},
	{
		id: "a41",
		slot: 41,
		name: "Weak Spot",
		source: "loot",
		cost: 5,
		effect: "AP2 + remove one smallest attack die of one enemy this turn; minimum1 die",
		copies: 1
	},
	{
		id: "a42",
		slot: 42,
		name: "Get Wrecked!",
		source: "loot",
		cost: 5,
		effect: "AP2 OR remove one smallest defense die of one enemy this turn; minimum1 die",
		copies: 1
	},
	{
		id: "a43",
		slot: 43,
		name: "Punchbag",
		source: "merchant",
		cost: 8,
		effect: "AP1 + for each Health lost this turn gain Coin3",
		copies: 1
	},
	{
		id: "a44",
		slot: 44,
		name: "Foresight",
		source: "merchant",
		cost: 8,
		effect: "This turn when discovering biome tiles discover1 additional adjacent tile in a direction of your choice",
		copies: 1
	},
	{
		id: "a45",
		slot: 45,
		name: "Get 'Em!",
		source: "merchant",
		cost: 8,
		effect: "AP1 OR duplicate1 of your smallest attack dice this turn",
		copies: 1
	},
	{
		id: "a46",
		slot: 46,
		name: "Bandage Up",
		source: "merchant",
		cost: 8,
		effect: "AP1 OR Health2 if current Health2 or less",
		copies: 1
	},
	{
		id: "a47",
		slot: 47,
		name: "Spring Clean",
		source: "merchant",
		cost: 8,
		effect: "Discard1 from hand then draw1 OR scrap1 from hand then scrap this card",
		copies: 1
	},
	{
		id: "a48",
		slot: 48,
		name: "Explore Even More",
		source: "merchant",
		cost: 8,
		effect: "AP3",
		copies: 1
	},
	{
		id: "a49",
		slot: 49,
		name: "Duck and Weave",
		source: "merchant",
		cost: 8,
		effect: "AP1 + once this turn reroll1 of your lowest-value defense dice",
		copies: 1
	},
	{
		id: "a50",
		slot: 50,
		name: "Quick Thinking",
		source: "merchant",
		cost: 8,
		effect: "AP1 + draw2 then discard1 from hand",
		copies: 1
	},
	{
		id: "a51",
		slot: 51,
		name: "Clobber",
		source: "merchant",
		cost: 15,
		effect: "AP1 + promote1 of your smallest attack dice for rest of turn; maximum D20",
		copies: 1
	},
	{
		id: "a52",
		slot: 52,
		name: "Hunker Down",
		source: "merchant",
		cost: 15,
		effect: "AP1 + promote1 of your smallest defense dice for rest of turn; maximum D20",
		copies: 1
	},
	{
		id: "a53",
		slot: 53,
		name: "Swap Shop",
		source: "merchant",
		cost: 15,
		effect: "This turn all players may donate without AP cost",
		copies: 1
	},
	{
		id: "a54",
		slot: 54,
		name: "Copycat",
		source: "merchant",
		cost: 15,
		effect: "Use any icons/effects from a single action card in another player's play area",
		copies: 1
	},
	{
		id: "a55",
		slot: 55,
		name: "Get Rid",
		source: "merchant",
		cost: 15,
		effect: "Draw1 then discard1 from hand OR scrap1 from hand or discard",
		copies: 1
	},
	{
		id: "a56",
		slot: 56,
		name: "Backup Plan",
		source: "merchant",
		cost: 15,
		effect: "AP1 + draw2",
		copies: 1
	},
	{
		id: "a57",
		slot: 57,
		name: "Productive",
		source: "merchant",
		cost: 15,
		effect: "This turn all characters gain yield1 when chopping trees or digging blocks located in same biome as your character",
		copies: 1
	},
	{
		id: "a58",
		slot: 58,
		name: "Explore Way More",
		source: "merchant",
		cost: 15,
		effect: "AP4",
		copies: 1
	},
	{
		id: "s0",
		slot: 0,
		name: "Charge",
		source: "start",
		cost: 0,
		effect: "AP1 OR Attack1",
		copies: 1
	},
	{
		id: "s1",
		slot: 1,
		name: "Assist",
		source: "start",
		cost: 0,
		effect: "Another player draws1 (solo yourself) + AP1",
		copies: 1
	},
	{
		id: "s2",
		slot: 2,
		name: "Dodge",
		source: "start",
		cost: 0,
		effect: "AP1 OR Defense2",
		copies: 1
	},
	{
		id: "s3",
		slot: 3,
		name: "Rest",
		source: "start",
		cost: 0,
		effect: "Coin1 OR Health1 if current health2 or less",
		copies: 1
	},
	{
		id: "s4",
		slot: 4,
		name: "Explore",
		source: "start",
		cost: 0,
		effect: "AP1",
		copies: 3
	},
	{
		id: "s5",
		slot: 5,
		name: "Explore More",
		source: "start",
		cost: 0,
		effect: "AP2",
		copies: 1
	}
], se = [
	{
		id: "e0",
		name: "Copper Axe",
		slot: "axe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 1,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Axe\nShort Range\n\n1 Action point = 1 Chop\n----------\nStarting Axe"
	},
	{
		id: "e1",
		name: "Iron Axe",
		slot: "axe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 2,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {
			wood: 1,
			iron: 2
		},
		house: "anvil",
		description: "Equipment: Axe\nShort Range\n\n1 Action point = 2 Chop\n----------\n1 Wood + 2 Iron + Anvil"
	},
	{
		id: "e2",
		name: "Silver Axe",
		slot: "axe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 3,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {
			wood: 1,
			silver: 2
		},
		house: "anvil",
		description: "Equipment: Axe\nShort Range\n\n1 Action point = 3 Chop\n----------\n1 Wood + 2 Silver + Anvil"
	},
	{
		id: "e3",
		name: "Gold Axe",
		slot: "axe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 3,
		dig: 0,
		hardy: !1,
		yield_: 2,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {
			wood: 2,
			gold: 2
		},
		house: "anvil",
		description: "Equipment: Axe\nShort Range\n\n1 Action point = 3 Chop\n+\ndouble yield\n----------\n2 Wood + 2 Gold + Anvil"
	},
	{
		id: "e4",
		name: "Blood Lust Cluster",
		slot: "axe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 3,
		dig: 0,
		hardy: !1,
		yield_: 3,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { crimtane: 2 },
		house: "anvil",
		description: "Equipment: Axe\nShort Range\n\n1 Action point = 3 Chop\n+\ntriple yield\n----------\n2 Crimtane + Anvil"
	},
	{
		id: "e5",
		name: "War Axe of the Night",
		slot: "axe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 3,
		dig: 0,
		hardy: !1,
		yield_: 3,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { demonite: 2 },
		house: "anvil",
		description: "Equipment: Axe\nShort Range\n\n1 Action point = 3 Chop\n+\ntriple yield\n----------\n2 Demonite + Anvil"
	},
	{
		id: "e6",
		name: "Molten Hamaxe",
		slot: "axe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 3,
		dig: 0,
		hardy: !1,
		yield_: 4,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { hellstone: 2 },
		house: "hellforge",
		description: "Equipment: Axe\nShort Range\n\n1 Action point = 3 Chop\n+\nquadruple yield\n----------\n2 Hellstone + Hellforge"
	},
	{
		id: "e7",
		name: "Copper Pickaxe",
		slot: "pickaxe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 1,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Pickaxe\nShort Range\n1 Action point = 1 Dig\nStarting Pickaxe"
	},
	{
		id: "e8",
		name: "Iron Pickaxe",
		slot: "pickaxe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 2,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {
			wood: 1,
			iron: 2
		},
		house: "anvil",
		description: "Equipment: Pickaxe\nShort Range\n\n1 Action point = 2 Dig\n----------\n1 Wood + 2 Iron + Anvil"
	},
	{
		id: "e9",
		name: "Silver Pickaxe",
		slot: "pickaxe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 3,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {
			wood: 1,
			silver: 2
		},
		house: "anvil",
		description: "Equipment: Pickaxe\nShort Range\n\n1 Action point = 3 Dig\n----------\n1 Wood + 2 Silver + Anvil"
	},
	{
		id: "e10",
		name: "Gold Pickaxe",
		slot: "pickaxe",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 4,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {
			wood: 2,
			gold: 2
		},
		house: "anvil",
		description: "Equipment: Pickaxe\nShort Range\n\n1 Action point = 4 Dig\n----------\n2 Wood + 2 Gold + Anvil"
	},
	{
		id: "e11",
		name: "Nightmare Pickaxe",
		slot: "pickaxe",
		copies: 4,
		cost: 2,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 4,
		hardy: !0,
		yield_: 2,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { demonite: 2 },
		house: "anvil",
		description: "Equipment: Pickaxe\nShort Range\n\n2 Action points = 4 Hardy Dig\ndouble yield\n----------\n2 Demonite + Anvil"
	},
	{
		id: "e12",
		name: "Deathbringer Pickaxe",
		slot: "pickaxe",
		copies: 4,
		cost: 2,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 4,
		hardy: !0,
		yield_: 2,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { crimtane: 2 },
		house: "anvil",
		description: "Equipment: Pickaxe\nShort Range\n\n2 Action points = 4 Hardy Dig\ndouble yield\n----------\n2 Crimtane + Anvil"
	},
	{
		id: "e13",
		name: "Molten Pickaxe",
		slot: "pickaxe",
		copies: 4,
		cost: 3,
		mana: !1,
		dice: [],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 4,
		hardy: !0,
		yield_: 3,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { hellstone: 2 },
		house: "hellforge",
		description: "Equipment: Pickaxe\nShort Range\n\n3 Action points = 4 Hardy Dig\ntriple yield\n----------\n2 Hellstone + Hellforge"
	},
	{
		id: "e14",
		name: "Copper Shortsword",
		slot: "sword",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [4],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Sword\nShort Range\n\n1 Action point = 1D4\n----------\nStarting Sword"
	},
	{
		id: "e15",
		name: "Iron Shortsword",
		slot: "sword",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [4, 4],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { iron: 2 },
		house: "anvil",
		description: "Equipment: Sword\nShort Range\n\n1 Action point = 2D4\n----------\n2 Iron + Anvil"
	},
	{
		id: "e16",
		name: "Silver Broadsword",
		slot: "sword",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [
			4,
			4,
			6
		],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { silver: 2 },
		house: "anvil",
		description: "Equipment: Sword\nShort Range\n\n1 Action point = 2D4 1D6\n----------\n2 Silver + Anvil"
	},
	{
		id: "e17",
		name: "Gold Broadsword",
		slot: "sword",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [
			6,
			6,
			6
		],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { gold: 2 },
		house: "anvil",
		description: "Equipment: Sword\nShort Range\n\n1 Action point = 3D6\n----------\n2 Gold + Anvil"
	},
	{
		id: "e18",
		name: "Light's Bane",
		slot: "sword",
		copies: 4,
		cost: 2,
		mana: !1,
		dice: [
			6,
			8,
			8
		],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 1,
		recipe: { demonite: 2 },
		house: "anvil",
		description: "Equipment: Sword\nShort Range\n\n2 Action points = 1D6 2D8\n+\nDraw 1 card\n----------\n2 Demonite + Anvil"
	},
	{
		id: "e19",
		name: "Blood Butcherer",
		slot: "sword",
		copies: 4,
		cost: 2,
		mana: !1,
		dice: [
			6,
			8,
			8
		],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 1,
		recipe: { crimtane: 2 },
		house: "anvil",
		description: "Equipment: Sword\nShort Range\n2 Action points = 1D6 2D8 + draw 1 card\n2 Crimtane + Anvil"
	},
	{
		id: "e20",
		name: "Volcano",
		slot: "sword",
		copies: 4,
		cost: 3,
		mana: !1,
		dice: [
			8,
			8,
			12
		],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !0,
		draw: 1,
		recipe: { hellstone: 2 },
		house: "hellforge",
		description: "Equipment: Sword\nShort Range\n\n3 Action points = 2D8 1D12\n+\nDraw 1 card + Prevent Retaliation\n----------\n2 Hellstone + Hellforge"
	},
	{
		id: "e21",
		name: "Wooden Bow",
		slot: "other",
		copies: 4,
		cost: 2,
		mana: !1,
		dice: [4],
		ranges: ["long"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { wood: 1 },
		house: "",
		description: "Equipment: Other\nLong Range\n\n2 Action points = 1D4\n----------\n1 Wood"
	},
	{
		id: "e22",
		name: "Iron Bow",
		slot: "other",
		copies: 4,
		cost: 2,
		mana: !1,
		dice: [4, 6],
		ranges: ["long"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { iron: 2 },
		house: "anvil",
		description: "Equipment: Other\nLong Range\n\n2 Action points = 1D4 1D6\n----------\n2 Iron + Anvil"
	},
	{
		id: "e23",
		name: "Silver Bow",
		slot: "other",
		copies: 4,
		cost: 2,
		mana: !1,
		dice: [
			4,
			4,
			6
		],
		ranges: ["long"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { silver: 2 },
		house: "anvil",
		description: "Equipment: Other\nLong Range\n\n2 Action points = 2D4 1D6\n----------\n2 Silver + Anvil"
	},
	{
		id: "e24",
		name: "Gold Bow",
		slot: "other",
		copies: 4,
		cost: 2,
		mana: !1,
		dice: [
			6,
			6,
			6
		],
		ranges: ["long"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { gold: 2 },
		house: "anvil",
		description: "Equipment: Other\nLong Range\n\n2 Action points = 3D6\n----------\n2 Gold + Anvil"
	},
	{
		id: "e25",
		name: "Demon Bow",
		slot: "other",
		copies: 4,
		cost: 3,
		mana: !1,
		dice: [
			6,
			8,
			8
		],
		ranges: ["long"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { demonite: 2 },
		house: "anvil",
		description: "Equipment: Other\nLong Range\n\n3 Action points = 1D6 2D8\n+\nremove 1 of the targeted enemy's smallest defense dice (min = 1 die)\n----------\n2 Demonite + Anvil"
	},
	{
		id: "e26",
		name: "Tendon Bow",
		slot: "other",
		copies: 4,
		cost: 3,
		mana: !1,
		dice: [
			6,
			8,
			8
		],
		ranges: ["long"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { crimtane: 2 },
		house: "anvil",
		description: "Equipment: Other\nLong Range\n\n3 Action points = 1D6 2D8\n+\nremove 1 of the targeted enemy's smallest defense dice (min = 1 die)\n----------\n2 Crimtane + Anvil"
	},
	{
		id: "e27",
		name: "Molten Fury",
		slot: "other",
		copies: 4,
		cost: 3,
		mana: !1,
		dice: [
			8,
			8,
			12
		],
		ranges: ["long"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { hellstone: 2 },
		house: "hellforge",
		description: "Equipment: Other\nLong Range\n3 Action points = 2D8 1D12 + demote 1 of targeted enemy largest defense dice (min D4)\n2 Hellstone + Hellforge"
	},
	{
		id: "e28",
		name: "Wooden Yoyo",
		slot: "other",
		copies: 4,
		cost: 1,
		mana: !1,
		dice: [4],
		ranges: ["short", "medium"],
		sightless: !0,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {
			wood: 2,
			cobweb: 2
		},
		house: "workbench",
		description: "Equipment: Other\nShort Medium Sightless Range\n\n1 Action point = 1D4\n----------\n2 Wood + 2 Cobweb + Workbench"
	},
	{
		id: "e29",
		name: "Malaise",
		slot: "other",
		copies: 4,
		cost: 3,
		mana: !1,
		dice: [
			6,
			6,
			8
		],
		ranges: ["short", "medium"],
		sightless: !0,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { demonite: 1 },
		house: "anvil",
		description: "Equipment: Other\nShort Medium Sightless Range\n\n3 Action points = 2D6 1D8\n----------\n1 Demonite + Anvil"
	},
	{
		id: "e30",
		name: "Artery",
		slot: "other",
		copies: 4,
		cost: 3,
		mana: !1,
		dice: [
			6,
			6,
			8
		],
		ranges: ["short", "medium"],
		sightless: !0,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { crimtane: 1 },
		house: "anvil",
		description: "Equipment: Other\nShort Medium Sightless Range\n\n3 Action points = 2D6 1D8\n----------\n1 Crimtane + Anvil"
	},
	{
		id: "e31",
		name: "Amethyst Staff",
		slot: "other",
		copies: 4,
		cost: 2,
		mana: !0,
		dice: [
			4,
			4,
			4
		],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {
			copper: 2,
			gem: 1
		},
		house: "anvil",
		description: "Equipment: Other\nShort Medium Range\n\n2 Mana = 3D4\n----------\n2 Copper + 1 Gem + Anvil"
	},
	{
		id: "e32",
		name: "Ruby Staff",
		slot: "other",
		copies: 4,
		cost: 2,
		mana: !0,
		dice: [
			6,
			6,
			6
		],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 1,
		prevent: !1,
		draw: 0,
		recipe: {
			gold: 2,
			gem: 2
		},
		house: "anvil",
		description: "Equipment: Other\nShort Medium Range\n\n2 Mana = 3D6\n+\n1 Piercing\n----------\n2 Gold + 2 Gem + Anvil"
	},
	{
		id: "e33",
		name: "Flinx Staff",
		slot: "other",
		copies: 4,
		cost: 2,
		mana: !0,
		dice: [],
		ranges: [],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {
			gold: 2,
			flinxfur: 2
		},
		house: "anvil",
		description: "Equipment: Other\n\n2 Mana = summon Snow Flinx minion\n----------\n2 Gold + 2 Flinx Fur + Furnace"
	},
	{
		id: "e34",
		name: "Imp Staff",
		slot: "other",
		copies: 4,
		cost: 3,
		mana: !0,
		dice: [],
		ranges: [],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { hellstone: 2 },
		house: "hellforge",
		description: "Equipment: Other\n\n3 Mana = summon Fire Imp minion\n----------\n2 Hellstone + Hellforge"
	},
	{
		id: "e35",
		name: "Grappling Hook",
		slot: "other",
		copies: 4,
		cost: 2,
		mana: !1,
		dice: [],
		ranges: [],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: { iron: 2 },
		house: "anvil",
		description: "Equipment: Other\n\n2 Action points = move 2 up and 1 right or left\n----------\n2 Iron + Anvil"
	},
	{
		id: "e36",
		name: "Night's Edge",
		slot: "sword",
		copies: 1,
		cost: 3,
		mana: !1,
		dice: [
			8,
			8,
			12
		],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !0,
		draw: 2,
		recipe: {},
		house: "",
		description: "Equipment: Sword\nShort Medium Range\n\n3 Action points = 2D8 1D12\n+\nDraw 2 cards + Prevent Retaliation\n----------\nScrap 2 of Light's Bane/Blood Butcherer/Volcano/Muramasa at Crimson Altar or Demon Altar"
	},
	{
		id: "e37",
		name: "Bee Keeper",
		slot: "sword",
		copies: 1,
		cost: 2,
		mana: !1,
		dice: [
			8,
			8,
			8
		],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Sword\nShort Range\n2 Action points = 3D8\nObtained from Queen Bee"
	},
	{
		id: "e38",
		name: "Bee's Knees",
		slot: "other",
		copies: 1,
		cost: 3,
		mana: !1,
		dice: [
			6,
			8,
			8
		],
		ranges: ["long"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nLong Range\n\n3 Action points = 1D6 2D8\n----------\nObtained from Queen Bee"
	},
	{
		id: "e39",
		name: "Bee Gun",
		slot: "other",
		copies: 1,
		cost: 2,
		mana: !0,
		dice: [
			4,
			6,
			6
		],
		ranges: ["short", "medium"],
		sightless: !0,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 1,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Sightless Range\n\n2 Mana = 1D4 2D6\n+\n1 Piercing\n----------\nObtained from Queen Bee"
	},
	{
		id: "e41",
		name: "Dark Lance",
		slot: "other",
		copies: 2,
		cost: 2,
		mana: !1,
		dice: [
			6,
			6,
			8
		],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 2,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Range\n\n2 Action points = 2D6 1D8\n+\n2 Piercing\n----------\nFound in Chests"
	},
	{
		id: "e42",
		name: "Spear",
		slot: "other",
		copies: 1,
		cost: 1,
		mana: !1,
		dice: [4],
		ranges: ["short"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 1,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Range\n\n1 Action point = 1D4\n+\n1 Piercing\n----------\nFound in Chests"
	},
	{
		id: "e43",
		name: "Wooden Boomerang",
		slot: "other",
		copies: 1,
		cost: 3,
		mana: !1,
		dice: [6],
		ranges: ["medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 1,
		recipe: {},
		house: "",
		description: "Equipment: Other\nMedium Range\n\n3 Action points = 1D6\n+\ndraw 1 card\n----------\nFound in Chests"
	},
	{
		id: "e44",
		name: "Enchanted Boomerang",
		slot: "other",
		copies: 1,
		cost: 2,
		mana: !1,
		dice: [
			6,
			6,
			8
		],
		ranges: ["medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 1,
		recipe: {},
		house: "",
		description: "Equipment: Other\nMedium Range\n\n2 Action points = 2D6 + 1D8\n+\ndraw 1 card\n----------\nFound in Chests"
	},
	{
		id: "e45",
		name: "Blowpipe",
		slot: "other",
		copies: 1,
		cost: 1,
		mana: !1,
		dice: [4],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !0,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Range\n\n1 Action point = 1D4\n+\nRetaliation Prevention\n----------\nFound in Chests"
	},
	{
		id: "e46",
		name: "Ice Blade",
		slot: "sword",
		copies: 1,
		cost: 1,
		mana: !1,
		dice: [
			6,
			6,
			8
		],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Sword\nShort Medium Range\n\n1 Action point = 2D6 1D8\n----------\nFound in Chests"
	},
	{
		id: "e48",
		name: "Amazon",
		slot: "other",
		copies: 1,
		cost: 3,
		mana: !1,
		dice: [
			6,
			8,
			8
		],
		ranges: ["short", "medium"],
		sightless: !0,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Sightless Range\n\n3 Action points = 1D6 2D8\n----------\nFound in Chests"
	},
	{
		id: "e49",
		name: "Cascade",
		slot: "other",
		copies: 2,
		cost: 3,
		mana: !1,
		dice: [
			8,
			8,
			8
		],
		ranges: ["short", "medium"],
		sightless: !0,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Sightless Range\n\n3 Action points = 3D8\n----------\nFound in Chests"
	},
	{
		id: "e50",
		name: "Hellwing Bow",
		slot: "other",
		copies: 1,
		cost: 3,
		mana: !1,
		dice: [
			8,
			8,
			8
		],
		ranges: ["long"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 99,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nLong Range\n\n3 Action points = 3D8\n+\nInfinite Piercing\n----------\nFound in Chests"
	},
	{
		id: "e51",
		name: "Phoenix Blaster",
		slot: "other",
		copies: 1,
		cost: 2,
		mana: !1,
		dice: [
			8,
			8,
			8
		],
		ranges: ["short", "long"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Long Range\n\n2 Action points = 3D8\n----------\nFound in Chests"
	},
	{
		id: "e52",
		name: "Ruby Hook",
		slot: "other",
		copies: 1,
		cost: 2,
		mana: !1,
		dice: [],
		ranges: [],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\n\n2 Action points = move 3 up and 1 right or left\n----------\nFound in Chests"
	},
	{
		id: "e53",
		name: "Wand of Sparking",
		slot: "other",
		copies: 1,
		cost: 1,
		mana: !0,
		dice: [4],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Range\n\n1 Mana = 1D4\n----------\nFound in Chests"
	},
	{
		id: "e54",
		name: "Thunder Zapper",
		slot: "other",
		copies: 1,
		cost: 2,
		mana: !0,
		dice: [
			6,
			6,
			8
		],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Range\n\n2 Mana = 2D6 1D8\n----------\nFound in Chests"
	},
	{
		id: "e55",
		name: "Crimson Rod",
		slot: "other",
		copies: 1,
		cost: 2,
		mana: !0,
		dice: [
			6,
			8,
			8
		],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 2,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Range\n\n2 Mana = 1D6 2D8\n+\n2 Piercing\n----------\nFound in Chests"
	},
	{
		id: "e56",
		name: "Vilethorn",
		slot: "other",
		copies: 1,
		cost: 2,
		mana: !0,
		dice: [
			6,
			8,
			8
		],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 2,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Range\n\n2 Mana = 1D6 2D8\n+\n2 Piercing\n----------\nFound in Chests"
	},
	{
		id: "e57",
		name: "Flamelash",
		slot: "other",
		copies: 2,
		cost: 2,
		mana: !0,
		dice: [
			8,
			8,
			8
		],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 2,
		prevent: !0,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Range\n\n2 Mana = 3D8\n+\n2 Piercing + Retaliation Prevention\n----------\nFound in Chests"
	},
	{
		id: "e58",
		name: "Demon Scythe",
		slot: "other",
		copies: 2,
		cost: 2,
		mana: !0,
		dice: [
			8,
			8,
			12
		],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 3,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Range\n\n2 Mana = 2D8 1D12\n+\n3 Piercing\n----------\nFound in Chests"
	},
	{
		id: "e59",
		name: "Flower of Fire",
		slot: "other",
		copies: 1,
		cost: 3,
		mana: !0,
		dice: [
			8,
			12,
			12
		],
		ranges: ["short", "medium"],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !0,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\nShort Medium Range\n\n3 Mana = 1D8 2D12\n+\nRetaliation Prevention\n----------\nFound in Chests"
	},
	{
		id: "e60",
		name: "Slime Staff",
		slot: "other",
		copies: 1,
		cost: 1,
		mana: !0,
		dice: [],
		ranges: [],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\n1 Mana = summon Baby Slime minion\nFound in Chests"
	},
	{
		id: "e61",
		name: "Hornet Staff",
		slot: "other",
		copies: 1,
		cost: 3,
		mana: !0,
		dice: [],
		ranges: [],
		sightless: !1,
		chop: 0,
		dig: 0,
		hardy: !1,
		yield_: 1,
		pierce: 0,
		prevent: !1,
		draw: 0,
		recipe: {},
		house: "",
		description: "Equipment: Other\n\n3 Mana = summon Hornet minion\n----------\nFound in Chests"
	}
], ce = [
	{
		id: "r8",
		name: "Wood Armor",
		dice: [4, 4],
		draw: 4,
		ap: 0,
		mana: 0,
		special: "",
		recipe: { wood: 1 },
		house: "workbench",
		copies: 4
	},
	{
		id: "r9",
		name: "Copper Armor",
		dice: [4, 6],
		draw: 4,
		ap: 0,
		mana: 0,
		special: "",
		recipe: { copper: 3 },
		house: "anvil",
		copies: 4
	},
	{
		id: "r10",
		name: "Iron Armor",
		dice: [
			6,
			6,
			6
		],
		draw: 4,
		ap: 0,
		mana: 0,
		special: "",
		recipe: { iron: 3 },
		house: "anvil",
		copies: 4
	},
	{
		id: "r11",
		name: "Silver Armor",
		dice: [
			6,
			6,
			8
		],
		draw: 4,
		ap: 1,
		mana: 0,
		special: "",
		recipe: { silver: 3 },
		house: "anvil",
		copies: 4
	},
	{
		id: "r12",
		name: "Gold Armor",
		dice: [
			6,
			8,
			8
		],
		draw: 4,
		ap: 1,
		mana: 0,
		special: "",
		recipe: { gold: 3 },
		house: "anvil",
		copies: 4
	},
	{
		id: "r13",
		name: "Shadow Armor",
		dice: [
			8,
			8,
			8
		],
		draw: 5,
		ap: 2,
		mana: 0,
		special: "",
		recipe: { demonite: 3 },
		house: "anvil",
		copies: 4
	},
	{
		id: "r14",
		name: "Crimson Armor",
		dice: [
			8,
			8,
			8
		],
		draw: 5,
		ap: 2,
		mana: 0,
		special: "",
		recipe: { crimtane: 3 },
		house: "anvil",
		copies: 4
	},
	{
		id: "r15",
		name: "Molten Armor",
		dice: [
			8,
			12,
			12
		],
		draw: 5,
		ap: 1,
		mana: 0,
		special: "onFire immunity",
		recipe: { hellstone: 3 },
		house: "hellforge",
		copies: 4
	},
	{
		id: "r16",
		name: "Necro Armor",
		dice: [
			8,
			8,
			12
		],
		draw: 4,
		ap: 2,
		mana: 0,
		special: "Promote1 smallest attack die(maxD20) for all long-range equipment",
		recipe: {
			cobweb: 5,
			bone: 2
		},
		house: "workbench",
		copies: 4
	},
	{
		id: "r17",
		name: "Wizard Set",
		dice: [
			4,
			6,
			6
		],
		draw: 4,
		ap: 2,
		mana: 2,
		special: "",
		recipe: {
			cobweb: 3,
			gem: 2
		},
		house: "loom",
		copies: 4
	},
	{
		id: "r19",
		name: "Ninja Armor",
		dice: [
			4,
			6,
			6
		],
		draw: 4,
		ap: 1,
		mana: 0,
		special: "Once per turn reroll1 own attack die",
		recipe: {},
		house: "",
		copies: 1
	},
	{
		id: "r20",
		name: "Bee Armor",
		dice: [
			6,
			6,
			8
		],
		draw: 4,
		ap: 1,
		mana: 1,
		special: "Summoned minions gain Attack1",
		recipe: {},
		house: "",
		copies: 1
	},
	{
		id: "r21",
		name: "Shadewood Armor",
		dice: [
			4,
			4,
			4
		],
		draw: 4,
		ap: 0,
		mana: 0,
		special: "",
		recipe: {},
		house: "",
		copies: 1
	},
	{
		id: "r22",
		name: "Ebonwood Armor",
		dice: [
			4,
			4,
			4
		],
		draw: 4,
		ap: 0,
		mana: 0,
		special: "",
		recipe: {},
		house: "",
		copies: 1
	},
	{
		id: "r23",
		name: "Jungle Armor",
		dice: [
			8,
			8,
			8
		],
		draw: 4,
		ap: 1,
		mana: 1,
		special: "",
		recipe: {},
		house: "",
		copies: 1
	},
	{
		id: "r24",
		name: "Mining Armor",
		dice: [4, 4],
		draw: 4,
		ap: 0,
		mana: 0,
		special: "Dig2 at Character phase start",
		recipe: {},
		house: "",
		copies: 1
	},
	{
		id: "r25",
		name: "Snow Armor",
		dice: [
			4,
			6,
			6
		],
		draw: 4,
		ap: 0,
		mana: 0,
		special: "frozen immunity",
		recipe: {},
		house: "",
		copies: 1
	}
], b = [
	{
		id: "c0",
		name: "Lesser Healing Potion",
		type: 1,
		copies: 4,
		description: "Consumable\nType 1\n\nUSE = 1 Health\n----------\nFound in Chests or obtained from Objective/ Merchant NPC"
	},
	{
		id: "c1",
		name: "Lesser Mana Potion",
		type: 1,
		copies: 2,
		description: "Consumable\nType 1\n\nUSE = 1 Mana\n----------\nFound in Chests or obtained from Objective/ Merchant NPC"
	},
	{
		id: "c2",
		name: "Throwing Knife",
		type: 1,
		copies: 3,
		description: "Consumable\nType 1\n\nUSE = perform a single 1D6 Short Medium Range + 1 Piercing attack\n----------\nFound in Chests or obtained from Objective/ Merchant NPC"
	},
	{
		id: "c3",
		name: "Shuriken",
		type: 1,
		copies: 3,
		description: "Consumable\nType 1\n\nUSE = perform a single 1D4 Short Medium Range + 2 Piercing attack\n----------\nFound in Chests or obtained from Objective/ Merchant NPC"
	},
	{
		id: "c4",
		name: "Swiftness Potion",
		type: 2,
		copies: 3,
		description: "Consumable\nType 2\n\nUSE = 2 Action Points\n----------\nFound in Chests or obtained from Objective/ Placed Bottle house"
	},
	{
		id: "c5",
		name: "Inferno Potion",
		type: 2,
		copies: 3,
		description: "Consumable\r\nType 2\r\n\r\nUSE = demote 1 of the largest enemy defense dice (min = 1D4) for all enemies on the same biome tile this turn\r\n----------\r\nFound in Chests or obtained from Objective/ Placed Bottle house"
	},
	{
		id: "c6",
		name: "Recall Potion",
		type: 2,
		copies: 3,
		description: "Consumable\nType 2\n\nUSE = teleport to any unoccupied Forest Surface square or any house with a bed OR gain 5 Coins\n----------\nFound in Chests or obtained from Objective/ Placed Bottle house"
	},
	{
		id: "c7",
		name: "Invisibility Potion",
		type: 2,
		copies: 3,
		description: "Consumable\r\nType 2\r\n\r\nUSE when Enermy Spawn is revealed on a biome tile to skip the spawn, OR USE to be ignored by all non-Boss enemies this turn  \r\n----------\r\nFound in Chests or obtained from Objective/ Placed Bottle house"
	},
	{
		id: "c8",
		name: "Ironskin Potion",
		type: 2,
		copies: 3,
		description: "Consumable\nType 2\n\nUSE = 2 Defense\n----------\nFound in Chests or obtained from Objective/ Placed Bottle house"
	},
	{
		id: "c9",
		name: "Mining Potion",
		type: 2,
		copies: 3,
		description: "Consumable\nType 2\n\nUSE = 2 Dig\n----------\nFound in Chests or obtained from Objective/ Placed Bottle house"
	},
	{
		id: "c10",
		name: "Archery Potion",
		type: 2,
		copies: 3,
		description: "Consumable\nType 2\n\nUSE = promote 1 of your largest attack dice (max = 1D20) for all your bows this turn OR gain 5 Coins\n----------\nFound in Chests or obtained from Objective/ Placed Bottle house"
	},
	{
		id: "c11",
		name: "Healing Potion",
		type: 2,
		copies: 3,
		description: "Consumable\nType 2\n\nUSE = 2 Health\n----------\nFound in Chests or obtained from Objective/ Placed Bottle house"
	},
	{
		id: "c12",
		name: "Magic Power Potion",
		type: 2,
		copies: 3,
		description: "Consumable\nType 2\n\nUSE = promote 1 of your largest for all your attack dice (max = 1D20) for all your magic (Mana-consuming) equipment this turn OR gain 5 Coins\n----------\nFound in Chests or obtained from Objective/ Placed Bottle house"
	},
	{
		id: "c13",
		name: "Greater Luck Potion",
		type: 2,
		copies: 3,
		description: "Consumable\nType 2\n\nUSE = draw 2 cards\n----------\nFound in Chests or obtained from Objective/ Placed Bottle house"
	},
	{
		id: "c14",
		name: "Bomb",
		type: 3,
		copies: 4,
		description: "Consumable\r\nType 3\r\n\r\nUSE = perform 2D6 attack + 3 Hardy Dig + 3 Chop in a 9-block AOE at Short Medium range\r\n----------\r\nFound in Chests or obtained from Demolitionist NPC"
	},
	{
		id: "c15",
		name: "Dynamite",
		type: 3,
		copies: 4,
		description: "Consumable\r\nType 3\r\n\r\nUSE = perform 2D8 attack + 4 Hardy Dig + 4 Chop in a 9-block AOE at Short Medium range\r\n----------\r\nFound in Chests or obtained from Demolitionist NPC"
	},
	{
		id: "c16",
		name: "Mana Potion",
		type: 4,
		copies: 4,
		description: "Consumable\r\nType 4\r\n\r\nUse = 3 Mana\r\n----------\r\nFound in Chests"
	},
	{
		id: "c17",
		name: "Water Bucket",
		type: 4,
		copies: 2,
		description: "Consumable\r\nType 4\r\n\r\nUSE = remove On Fire debuff\nOR\ngain 8 Coins\r\n----------\r\nFound in Chests or obtained from Objective"
	},
	{
		id: "c20",
		name: "Guide Voodoo Doll",
		type: 4,
		copies: 4,
		description: "Consumable\r\nType 4\r\n\r\nUSE = while adjacent to lava in the Underworld to spawn the Wall of Flesh boss\r\n----------\r\nObtained from Voodoo Demon enemy"
	},
	{
		id: "c21",
		name: "Beenade",
		type: 4,
		copies: 4,
		description: "Consumable\r\nType 4\r\n\r\nUSE = perform 1D4 1D6 attack + 2 Dig + 2 Chop in a 9-block AOE at Short Medium Range\r\n----------\r\nObtained from Queen Bee"
	}
], x = [
	{
		name: "Green Slime",
		move: 1,
		mode: "walk",
		ranges: "short",
		attack: [4],
		defense: [4],
		health: 1,
		coins: 1,
		resources: { gel: 1 },
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Blue Slime",
		move: 2,
		mode: "walk",
		ranges: "short",
		attack: [4],
		defense: [4, 4],
		health: 1,
		coins: 1,
		resources: { gel: 2 },
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Red Slime",
		move: 2,
		mode: "walk",
		ranges: "short",
		attack: [4, 4],
		defense: [4],
		health: 1,
		coins: 2,
		resources: { gel: 2 },
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Yellow Slime",
		move: 2,
		mode: "walk",
		ranges: "short",
		attack: [4, 4],
		defense: [4, 4],
		health: 2,
		coins: 2,
		resources: { gel: 3 },
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Black Slime",
		move: 2,
		mode: "walk",
		ranges: "short",
		attack: [
			4,
			4,
			4
		],
		defense: [4],
		health: 2,
		coins: 3,
		resources: { gel: 3 },
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Lava Slime",
		move: 3,
		mode: "walk",
		ranges: "short",
		attack: [
			4,
			6,
			6
		],
		defense: [
			4,
			4,
			6
		],
		health: 2,
		coins: 8,
		resources: {},
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Demon Eye",
		move: 3,
		mode: "fly",
		ranges: "short",
		attack: [4, 4],
		defense: [4],
		health: 1,
		coins: 2,
		resources: { lens: 1 },
		lootLevel: 1,
		debuff: ""
	},
	{
		name: "Zombie",
		move: 2,
		mode: "walk",
		ranges: "short",
		attack: [
			4,
			4,
			4
		],
		defense: [
			4,
			4,
			4
		],
		health: 1,
		coins: 3,
		resources: {},
		lootLevel: 2,
		debuff: ""
	},
	{
		name: "Giant Worm",
		move: 2,
		mode: "worm",
		ranges: "short",
		attack: [
			4,
			4,
			6
		],
		defense: [4, 4],
		health: 2,
		coins: 8,
		resources: {},
		lootLevel: 2,
		debuff: ""
	},
	{
		name: "Cave Bat",
		move: 2,
		mode: "fly",
		ranges: "short",
		attack: [4, 4],
		defense: [4],
		health: 1,
		coins: 2,
		resources: {},
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Hellbat",
		move: 2,
		mode: "fly",
		ranges: "short",
		attack: [
			4,
			6,
			6
		],
		defense: [
			4,
			4,
			4
		],
		health: 2,
		coins: 8,
		resources: {},
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Skeleton",
		move: 2,
		mode: "walk",
		ranges: "short",
		attack: [
			6,
			6,
			6
		],
		defense: [
			4,
			4,
			6
		],
		health: 3,
		coins: 10,
		resources: { bone: 1 },
		lootLevel: 4,
		debuff: ""
	},
	{
		name: "Salamander",
		move: 2,
		mode: "walk",
		ranges: "short medium",
		attack: [
			4,
			4,
			6
		],
		defense: [
			4,
			6,
			6
		],
		health: 3,
		coins: 14,
		resources: {},
		lootLevel: 5,
		debuff: "poison"
	},
	{
		name: "Vulture",
		move: 2,
		mode: "fly",
		ranges: "short",
		attack: [4, 4],
		defense: [4],
		health: 2,
		coins: 5,
		resources: {},
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Antlion",
		move: 0,
		mode: "walk",
		ranges: "short medium",
		attack: [4, 4],
		defense: [4],
		health: 2,
		coins: 6,
		resources: {},
		lootLevel: 1,
		debuff: ""
	},
	{
		name: "Sand Slime",
		move: 2,
		mode: "walk",
		ranges: "short",
		attack: [
			4,
			4,
			6
		],
		defense: [
			4,
			4,
			4
		],
		health: 2,
		coins: 4,
		resources: { gel: 3 },
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Antlion Swarmer",
		move: 2,
		mode: "fly",
		ranges: "short",
		attack: [
			6,
			6,
			6
		],
		defense: [
			4,
			4,
			6
		],
		health: 3,
		coins: 12,
		resources: {},
		lootLevel: 3,
		debuff: ""
	},
	{
		name: "Tomb Crawler",
		move: 3,
		mode: "worm",
		ranges: "short",
		attack: [
			6,
			6,
			8
		],
		defense: [
			4,
			6,
			6
		],
		health: 3,
		coins: 10,
		resources: {},
		lootLevel: 3,
		debuff: ""
	},
	{
		name: "Fire Imp",
		move: 2,
		mode: "walk",
		ranges: "short long",
		attack: [
			6,
			8,
			8
		],
		defense: [
			6,
			8,
			8
		],
		health: 3,
		coins: 18,
		resources: {},
		lootLevel: 5,
		debuff: "fire"
	},
	{
		name: "Snatcher",
		move: 0,
		mode: "walk",
		ranges: "short medium",
		attack: [
			6,
			6,
			6
		],
		defense: [
			4,
			6,
			6
		],
		health: 3,
		coins: 10,
		resources: {},
		lootLevel: 2,
		debuff: ""
	},
	{
		name: "Jungle Slime",
		move: 2,
		mode: "walk",
		ranges: "short",
		attack: [
			4,
			6,
			6
		],
		defense: [
			4,
			4,
			4
		],
		health: 2,
		coins: 4,
		resources: { gel: 3 },
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Spiked Jungle Slime",
		move: 2,
		mode: "walk",
		ranges: "short medium",
		attack: [
			4,
			6,
			6
		],
		defense: [
			4,
			4,
			4
		],
		health: 2,
		coins: 5,
		resources: { gel: 3 },
		lootLevel: 0,
		debuff: "poison"
	},
	{
		name: "Jungle Bat",
		move: 2,
		mode: "fly",
		ranges: "short",
		attack: [
			4,
			4,
			4
		],
		defense: [4],
		health: 1,
		coins: 6,
		resources: {},
		lootLevel: 0,
		debuff: ""
	},
	{
		name: "Hornet",
		move: 3,
		mode: "fly",
		ranges: "short medium",
		attack: [
			4,
			4,
			4
		],
		defense: [4],
		health: 1,
		coins: 3,
		resources: {},
		lootLevel: 0,
		debuff: "poison"
	},
	{
		name: "Ice Slime",
		move: 2,
		mode: "walk",
		ranges: "short",
		attack: [4, 4],
		defense: [4],
		health: 1,
		coins: 3,
		resources: { gel: 2 },
		lootLevel: 0,
		debuff: "frozen"
	},
	{
		name: "Frozen Zombie",
		move: 2,
		mode: "walk",
		ranges: "short",
		attack: [
			4,
			4,
			4
		],
		defense: [
			4,
			4,
			4
		],
		health: 1,
		coins: 4,
		resources: {},
		lootLevel: 2,
		debuff: "frozen"
	},
	{
		name: "Ice Bat",
		move: 2,
		mode: "fly",
		ranges: "short",
		attack: [
			4,
			4,
			6
		],
		defense: [4],
		health: 1,
		coins: 4,
		resources: {},
		lootLevel: 0,
		debuff: "frozen"
	},
	{
		name: "Snow Flinx",
		move: 3,
		mode: "walk",
		ranges: "short",
		attack: [
			6,
			8,
			8
		],
		defense: [
			6,
			6,
			6
		],
		health: 3,
		coins: 16,
		resources: { flinxFur: 1 },
		lootLevel: 4,
		debuff: ""
	},
	{
		name: "Crimera",
		move: 3,
		mode: "fly",
		ranges: "short",
		attack: [4, 6],
		defense: [
			4,
			4,
			4
		],
		health: 1,
		coins: 7,
		resources: {},
		lootLevel: 2,
		debuff: ""
	},
	{
		name: "Blood Crawler",
		move: 3,
		mode: "walk",
		ranges: "short",
		attack: [
			4,
			6,
			6
		],
		defense: [
			4,
			4,
			6
		],
		health: 3,
		coins: 10,
		resources: {},
		lootLevel: 3,
		debuff: ""
	},
	{
		name: "Eater of Souls",
		move: 3,
		mode: "fly",
		ranges: "short",
		attack: [4, 6],
		defense: [
			4,
			4,
			4
		],
		health: 1,
		coins: 7,
		resources: {},
		lootLevel: 2,
		debuff: ""
	},
	{
		name: "Devourer",
		move: 3,
		mode: "worm",
		ranges: "short",
		attack: [
			6,
			8,
			8
		],
		defense: [
			4,
			6,
			6
		],
		health: 3,
		coins: 10,
		resources: {},
		lootLevel: 4,
		debuff: ""
	},
	{
		name: "Voodoo Demon",
		move: 3,
		mode: "fly",
		ranges: "short medium",
		attack: [
			8,
			8,
			8
		],
		defense: [
			8,
			8,
			8
		],
		health: 3,
		coins: 20,
		resources: {},
		lootLevel: 0,
		debuff: ""
	}
], le = {
	"Desert Lower Cavern": [
		"Tomb Crawler",
		"Sand Slime",
		"Antlion Swarmer",
		"Antlion Swarmer",
		"Life Crystal"
	],
	"Snow Lower Cavern": [
		"Snow Flinx",
		"Ice Bat",
		"Ice Bat",
		"Ice Bat",
		"Snow Flinx"
	],
	"Desert Underworld": [
		"Lava Slime",
		"Fire Imp",
		"Lava Slime"
	],
	"Forest Underworld": [
		"Hellbat",
		"Lava Slime",
		"Lava Slime"
	],
	"Snow Underworld": [
		"Hellbat",
		"Hellbat",
		"Voodoo Demon"
	],
	"Forest Lower Cavern": [
		"Skeleton",
		"Salamander",
		"Black Slime",
		"Salamander",
		"Skeleton"
	],
	"Jungle Lower Cavern": [
		"Hornet",
		"Life Crystal",
		"Spiked Jungle Slime",
		"Spiked Jungle Slime",
		"Hornet"
	],
	"Jungle Underworld": [
		"Voodoo Demon",
		"Lava Slime",
		"Lava Slime"
	],
	"Crimson Underworld": [
		"Fire Imp",
		"Fire Imp",
		"Voodoo Demon"
	],
	"Crimson Lower Cavern": [
		"Blood Crawler",
		"Blood Crawler",
		"Blood Crawler",
		"Crimera",
		"Crimera"
	],
	"Crimson Upper Cavern": [
		"Blood Crawler",
		"Crimera",
		"Crimera",
		"Blood Crawler",
		"Crimera"
	],
	"Jungle Underground": [
		"Red Slime",
		"Giant Worm",
		"Life Crystal",
		"Yellow Slime",
		"Red Slime"
	],
	"Snow Upper Cavern": [
		"Life Crystal",
		"Snow Flinx",
		"Ice Bat",
		"Ice Bat",
		"Snow Flinx"
	],
	"Desert Upper Cavern": [
		"Sand Slime",
		"Tomb Crawler",
		"Sand Slime",
		"Tomb Crawler",
		"Antlion Swarmer"
	],
	"Forest Upper Cavern": [
		"Skeleton",
		"Cave Bat",
		"Black Slime",
		"Cave Bat",
		"Life Crystal"
	],
	"Corruption Upper Cavern": [
		"Devourer",
		"Eater of Souls",
		"Devourer",
		"Eater of Souls",
		"Eater of Souls"
	],
	"Corruption Lower Cavern": [
		"Devourer",
		"Eater of Souls",
		"Devourer",
		"Devourer",
		"Devourer"
	],
	"Corruption Underworld": [
		"Voodoo Demon",
		"Fire Imp",
		"Fire Imp"
	],
	"Corruption Underground": [
		"Yellow Slime",
		"Red Slime",
		"Life Crystal",
		"Giant Worm",
		"Red Slime"
	],
	"Crimson Underground": [
		"Red Slime",
		"Giant Worm",
		"Red Slime",
		"Life Crystal",
		"Yellow Slime"
	],
	"Jungle Upper Cavern": [
		"Hornet",
		"Jungle Bat",
		"Hornet",
		"Jungle Bat",
		"Hornet"
	],
	"Snow Underground": [
		"Giant Worm",
		"Red Slime",
		"Life Crystal",
		"Red Slime",
		"Yellow Slime"
	],
	"Desert Underground": [
		"Life Crystal",
		"Red Slime",
		"Giant Worm",
		"Yellow Slime",
		"Red Slime"
	],
	"Forest Underground": [
		"Red Slime",
		"Giant Worm",
		"Red Slime",
		"Yellow Slime",
		"Life Crystal"
	],
	"Corruption Surface Night": [
		"Fallen Star",
		"Eater of Souls",
		"Eater of Souls",
		"Eater of Souls",
		"Eater of Souls"
	],
	"Crimson Surface Night": [
		"Fallen Star",
		"Crimera",
		"Crimera",
		"Crimera",
		"Crimera"
	],
	"Jungle Surface Night": [
		"Demon Eye",
		"Jungle Bat",
		"Jungle Bat",
		"Fallen Star",
		"Zombie"
	],
	"Snow Surface Night": [
		"Fallen Star",
		"Frozen Zombie",
		"Frozen Zombie",
		"Frozen Zombie",
		"Frozen Zombie"
	],
	"Desert Surface Night": [
		"Fallen Star",
		"Antlion",
		"Antlion",
		"Antlion",
		"Antlion"
	],
	"Forest Surface Night": [
		"Demon Eye",
		"Fallen Star",
		"Zombie",
		"Demon Eye",
		"Zombie"
	],
	"Corruption Surface Day": [
		"Eater of Souls",
		"Eater of Souls",
		"Eater of Souls",
		"Eater of Souls",
		"Eater of Souls"
	],
	"Crimson Surface Day": [
		"Crimera",
		"Crimera",
		"Crimera",
		"Crimera",
		"Crimera"
	],
	"Jungle Surface Day": [
		"Snatcher",
		"Jungle Slime",
		"Jungle Slime",
		"Snatcher",
		"Jungle Slime"
	],
	"Snow Surface Day": [
		"Ice Slime",
		"Ice Slime",
		"Ice Slime",
		"Ice Slime",
		"Ice Slime"
	],
	"Desert Surface Day": [
		"Antlion",
		"Vulture",
		"Vulture",
		"Antlion",
		"Vulture"
	],
	"Forest Surface Day": [
		"Blue Slime",
		"Green Slime",
		"Green Slime",
		"Green Slime",
		"Blue Slime"
	]
}, ue = [
	[
		0,
		"c2",
		"fe2",
		"L3",
		"L4",
		"Magic Power Potion"
	],
	[
		1,
		"Wooden Boomerang",
		"Lesser Healing Potion",
		"w2",
		"au2",
		"L5"
	],
	[
		2,
		"L1",
		"Wand of Sparking",
		"Greater Luck Potion",
		"c8",
		"he2"
	],
	[
		3,
		"w2",
		"L2",
		"Mining Armor",
		"Invisibility Potion",
		"Demon Scythe"
	],
	[
		4,
		"Shuriken",
		"c4",
		"ag2",
		"L4",
		"Hellwing Bow"
	],
	[
		5,
		"Ugly Sweater",
		"Gingerbread Cookie",
		"L3",
		"Candy Cane Sword",
		"L5"
	],
	[
		6,
		"Rotten Egg",
		"Pumpkin Armor",
		"Bladed Glove",
		"L4",
		"L5"
	],
	[
		7,
		"c2",
		"fe2",
		"L3",
		"Thunder Zapper",
		"Inferno Potion"
	],
	[
		8,
		"Mining Potion",
		"w2",
		"ag2",
		"L4",
		"Dark Lance"
	],
	[
		9,
		"L1",
		"w2",
		"Bomb",
		"c8",
		"he2"
	],
	[
		10,
		"cu2",
		"L2",
		"Enchanted Boomerang",
		"Dynamite",
		"L5"
	],
	[
		11,
		"Ironskin Potion",
		"Throwing Knife",
		"c6",
		"au2",
		"L5"
	],
	[
		12,
		"c2",
		"fe2",
		"L3",
		"Snow Armor",
		"Inferno Potion"
	],
	[
		13,
		"Swiftness Potion",
		"Lesser Mana Potion",
		"c6",
		"au2",
		"L5"
	],
	[
		14,
		"Shuriken",
		"w2",
		"ag2",
		"L4",
		"Cascade"
	],
	[
		15,
		"cu2",
		"L2",
		"Ruby Hook",
		"Invisibility Potion",
		"Flamelash"
	],
	[
		16,
		"L1",
		"Ice Blade",
		"Bomb",
		"c8",
		"he2"
	],
	[
		17,
		"w2",
		"L2",
		"Amazon",
		"Hornet Staff",
		"Phoenix Blaster"
	],
	[
		18,
		"c2",
		"fe2",
		"L3",
		"Jungle Armor",
		"Water Bucket"
	],
	[
		19,
		"Swiftness Potion",
		"c4",
		"ag2",
		"L4",
		"Demon Scythe"
	],
	[
		20,
		"Blowpipe",
		"Archery Potion",
		"w2",
		"au2",
		"L5"
	],
	[
		21,
		"L1",
		"Slime Staff",
		"Recall Potion",
		"c8",
		"Healing Potion"
	],
	[
		22,
		"c2",
		"fe2",
		"L3",
		"Crimson Rod",
		"Water Bucket"
	],
	[
		23,
		"Ironskin Potion",
		"c4",
		"ag2",
		"L4",
		"Flower of Fire"
	],
	[
		24,
		"L1",
		"Swiftness Potion",
		"Greater Luck Potion",
		"c8",
		"he2"
	],
	[
		25,
		"Spear",
		"Lesser Healing Potion",
		"w2",
		"au2",
		"L5"
	],
	[
		26,
		"w2",
		"L2",
		"Shadewood Armor",
		"Dynamite",
		"Dark Lance"
	],
	[
		27,
		"c2",
		"fe2",
		"L3",
		"Vilethorn",
		"Magic Power Potion"
	],
	[
		28,
		"w2",
		"L2",
		"Ebonwood Armor",
		"Lesser Mana Potion",
		"Cascade"
	],
	[
		29,
		"Spear",
		"Throwing Knife",
		"w2",
		"au2",
		"L5"
	],
	[
		30,
		"Mining Potion",
		"c4",
		"ag2",
		"L4",
		"Flamelash"
	],
	[
		31,
		"L1",
		"Swiftness Potion",
		"Recall Potion",
		"c8",
		"Healing Potion"
	]
], de = {
	forest: [
		0,
		1,
		2,
		3,
		4
	],
	desert: [
		7,
		8,
		9,
		10,
		11
	],
	snow: [
		12,
		13,
		14,
		15,
		16
	],
	jungle: [
		17,
		18,
		19,
		20,
		21
	],
	crimson: [
		22,
		23,
		24,
		25,
		26
	],
	corruption: [
		27,
		28,
		29,
		30,
		31
	]
}, fe = [
	{
		id: "o0",
		name: "Scraping the Surface",
		chain: "dig",
		level: 1,
		condition: "dig block",
		reward: "each coin1",
		threat: 0,
		small: { reward: "each coin2" }
	},
	{
		id: "o1",
		name: "Ooo, Shiny!",
		chain: "dig",
		level: 2,
		condition: "dig copper/iron/silver/gold ore",
		reward: "share2 dug ore",
		threat: 0,
		small: {}
	},
	{
		id: "o2",
		name: "World Wide Web",
		chain: "dig",
		level: 3,
		condition: "collect cobweb from Underground tunnel",
		reward: "each iron1",
		threat: 0,
		small: { reward: "each iron2" }
	},
	{
		id: "o3",
		name: "Getting Picky",
		chain: "dig",
		level: 4,
		condition: "have crafted pickaxe from crafting menu",
		reward: "share2 pickaxe ore",
		threat: 0,
		small: {}
	},
	{
		id: "o4",
		name: "Under Pressure",
		chain: "dig",
		level: 5,
		condition: "dig gem",
		reward: "each random type2 consumable1",
		threat: 0,
		small: { reward: "each random type2 consumable2" }
	},
	{
		id: "o5",
		name: "Having a Blast",
		chain: "dig",
		level: 6,
		condition: "dig at least1 block with explosive consumable",
		reward: "share coin6 OR threat-1",
		threat: 0,
		small: {}
	},
	{
		id: "o6",
		name: "Evil, Or...?",
		chain: "dig",
		level: 7,
		condition: "dig evil ore",
		reward: "share2 dug ore",
		threat: 1,
		small: {}
	},
	{
		id: "o7",
		name: "A Blank Slate",
		chain: "dig",
		level: 8,
		condition: "have dug all blocks on one tile",
		reward: "each random type3 consumable1",
		threat: 1,
		small: {}
	},
	{
		id: "o8",
		name: "Bulldozer",
		chain: "dig",
		level: 9,
		condition: "have dug2-wide column Surface to bottom Underworld",
		reward: "each scrap1 from hand/draw/discard",
		threat: 1,
		small: {}
	},
	{
		id: "o9",
		name: "Hot Stuff",
		chain: "dig",
		level: 10,
		condition: "dig at least8 hellstone blocks",
		reward: "chain complete",
		threat: 2,
		small: { condition: "dig at least6 hellstone blocks" }
	},
	{
		id: "o10",
		name: "Timber!",
		chain: "build",
		level: 1,
		condition: "chop tree",
		reward: "each coin1",
		threat: 0,
		small: { reward: "each coin2" }
	},
	{
		id: "o11",
		name: "Benched",
		chain: "build",
		level: 2,
		condition: "have workbench house",
		reward: "each platform1",
		threat: 0,
		small: { reward: "each platform2" }
	},
	{
		id: "o12",
		name: "Heavy Metal",
		chain: "build",
		level: 3,
		condition: "have anvil house",
		reward: "each free Second Wind from Guide",
		threat: 0,
		small: {}
	},
	{
		id: "o13",
		name: "Chop It Like It's Hot",
		chain: "build",
		level: 4,
		condition: "have crafted axe from crafting menu",
		reward: "share coin4",
		threat: 0,
		small: {}
	},
	{
		id: "o14",
		name: "Subterranean Homestead Blues",
		chain: "build",
		level: 5,
		condition: "have house completely below Surface",
		reward: "each random type2 consumable1",
		threat: 0,
		small: { reward: "each random type2 consumable2" }
	},
	{
		id: "o15",
		name: "Getting Crafty",
		chain: "build",
		level: 6,
		condition: "have loom OR placed bottle house",
		reward: "share coin6 OR threat-1",
		threat: 0,
		small: {}
	},
	{
		id: "o16",
		name: "Home Comforts",
		chain: "build",
		level: 7,
		condition: "have bed OR cooking pot house",
		reward: "share health4",
		threat: 1,
		small: {}
	},
	{
		id: "o17",
		name: "Property Developer",
		chain: "build",
		level: 8,
		condition: "houses in3 biomes OR4 in one biome",
		reward: "each random type3 consumable1",
		threat: 1,
		small: {}
	},
	{
		id: "o18",
		name: "Forging Ahead",
		chain: "build",
		level: 9,
		condition: "have hellforge house",
		reward: "share hellstone2",
		threat: 1,
		small: {}
	},
	{
		id: "o19",
		name: "Quite the Portfolio",
		chain: "build",
		level: 10,
		condition: "have crafted all7 house types",
		reward: "chain complete",
		threat: 2,
		small: {}
	},
	{
		id: "o20",
		name: "That Was Close",
		chain: "fight",
		level: 1,
		condition: "defeat enemy",
		reward: "each coin1",
		threat: 0,
		small: { reward: "each coin2" }
	},
	{
		id: "o21",
		name: "Matching Attire",
		chain: "fight",
		level: 2,
		condition: "have crafted Wood Armor",
		reward: "each wood1 OR coin3",
		threat: 0,
		small: { reward: "each wood2 OR coin4" }
	},
	{
		id: "o22",
		name: "Looking Sharp",
		chain: "fight",
		level: 3,
		condition: "have crafted sword from crafting menu",
		reward: "share coin4",
		threat: 0,
		small: {}
	},
	{
		id: "o23",
		name: "You Can Do It!",
		chain: "fight",
		level: 4,
		condition: "have survived night",
		reward: "each scrap1 from hand/draw/discard; share lens1",
		threat: 0,
		small: {}
	},
	{
		id: "o24",
		name: "Slippery Shinobi",
		chain: "fight",
		level: 5,
		condition: "have defeated King Slime",
		reward: "each level2 loot action",
		threat: 0,
		small: {}
	},
	{
		id: "o25",
		name: "Never Mana Give You Up",
		chain: "fight",
		level: 6,
		condition: "have magic mana-consuming other equipment",
		reward: "each random type2 consumable2",
		threat: 1,
		small: {}
	},
	{
		id: "o26",
		name: "Sting Operation/Eye on You",
		chain: "fight",
		level: 7,
		condition: "have defeated Queen Bee OR Eye of Cthulhu",
		reward: "each level3 loot action",
		threat: 1,
		small: {}
	},
	{
		id: "o27",
		name: "Diverse Dispatch",
		chain: "fight",
		level: 8,
		condition: "defeat4 different non-boss types in one Character phase",
		reward: "each random type3 consumable1",
		threat: 1,
		small: { condition: "defeat3 different non-boss types in one Character phase" }
	},
	{
		id: "o28",
		name: "Mastermind/Worm Fodder",
		chain: "fight",
		level: 9,
		condition: "have defeated Brain of Cthulhu OR Eater of Worlds",
		reward: "each level4 loot action",
		threat: 1,
		small: {}
	},
	{
		id: "o29",
		name: "All Dolled Up",
		chain: "fight",
		level: 10,
		condition: "have obtained Guide Voodoo Doll from defeated Voodoo Demon in Underworld",
		reward: "chain complete",
		threat: 2,
		small: {}
	},
	{
		id: "o30",
		name: "Off We Go!",
		chain: "explore",
		level: 1,
		condition: "discover2 biome tiles",
		reward: "each coin1",
		threat: 0,
		small: { reward: "each coin2" }
	},
	{
		id: "o31",
		name: "Feeling Chesty",
		chain: "explore",
		level: 2,
		condition: "open chest in non-Forest biome",
		reward: "each free Explore More from Guide",
		threat: 0,
		small: {}
	},
	{
		id: "o32",
		name: "I Am Loot!",
		chain: "explore",
		level: 3,
		condition: "open chest at Underground or deeper",
		reward: "each rope1 OR platform2; share Recall Potion1",
		threat: 0,
		small: { reward: "each rope2 OR platform3; share Recall Potion1" }
	},
	{
		id: "o33",
		name: "Real Estate Agent",
		chain: "explore",
		level: 4,
		condition: "have2 non-Guide NPCs spawned",
		reward: "each random type2 consumable1",
		threat: 0,
		small: { reward: "each random type2 consumable2" }
	},
	{
		id: "o34",
		name: "A Lovely Neighborhood",
		chain: "explore",
		level: 5,
		condition: "have discovered3 evil biome tiles",
		reward: "each scrap1 from hand/draw/discard",
		threat: 0,
		small: {}
	},
	{
		id: "o35",
		name: "Land's End",
		chain: "explore",
		level: 6,
		condition: "have discovered Ocean tile",
		reward: "each free Explore More from Guide",
		threat: 1,
		small: {}
	},
	{
		id: "o36",
		name: "Where's My Honey?",
		chain: "explore",
		level: 7,
		condition: "have discovered Jungle Lower Cavern bee hive",
		reward: "share coin6",
		threat: 1,
		small: {}
	},
	{
		id: "o37",
		name: "It's Getting Hot In Here",
		chain: "explore",
		level: 8,
		condition: "have discovered Underworld tile",
		reward: "each random type3 consumable1",
		threat: 1,
		small: {}
	},
	{
		id: "o38",
		name: "Marathon Medalist",
		chain: "explore",
		level: 9,
		condition: "have discovered tile in all5 Surface biomes",
		reward: "each scrap1 from hand/draw/discard",
		threat: 1,
		small: {}
	},
	{
		id: "o39",
		name: "Rapid Transit Network",
		chain: "explore",
		level: 10,
		condition: "have5 pylons",
		reward: "chain complete",
		threat: 2,
		small: { condition: "have4 pylons" }
	},
	{
		id: "o40",
		name: "Heart Breaker",
		chain: "dig",
		level: 5,
		condition: "have collected life crystal",
		reward: "each random type2 consumable2",
		threat: 0,
		small: {}
	},
	{
		id: "o41",
		name: "Lucky Break",
		chain: "dig",
		level: 6,
		condition: "fall8+ squares without dying",
		reward: "share coin6 OR threat-1",
		threat: 0,
		small: {}
	},
	{
		id: "o42",
		name: "Heated Heist",
		chain: "dig",
		level: 8,
		condition: "have opened3 Underworld chests",
		reward: "each random type3 consumable1",
		threat: 1,
		small: { condition: "have opened2 Underworld chests" }
	},
	{
		id: "o43",
		name: "Going Up!",
		chain: "dig",
		level: 10,
		condition: "Underworld to Surface in one Character phase without pylon",
		reward: "chain complete",
		threat: 2,
		small: {}
	},
	{
		id: "o44",
		name: "Fashion Statement",
		chain: "build",
		level: 5,
		condition: "have2 characters wearing Gold Armor",
		reward: "each random type2 consumable2",
		threat: 0,
		small: { condition: "have1 character wearing Gold Armor" }
	},
	{
		id: "o45",
		name: "High Rise",
		chain: "build",
		level: 6,
		condition: "have3 houses stacked",
		reward: "share coin6 OR threat-1",
		threat: 0,
		small: {}
	},
	{
		id: "o46",
		name: "Pack Horse",
		chain: "build",
		level: 8,
		condition: "have2 characters with6 full unlocked inventory slots",
		reward: "each random type3 consumable1",
		threat: 1,
		small: { condition: "have1 character with6 full unlocked inventory slots" }
	},
	{
		id: "o47",
		name: "Slumber Party",
		chain: "build",
		level: 10,
		condition: "all characters inside bed house at night; may share houses",
		reward: "chain complete",
		threat: 2,
		small: {}
	},
	{
		id: "o48",
		name: "Throwing Lines",
		chain: "fight",
		level: 5,
		condition: "have yoyo in any other equipment slot",
		reward: "each merchant discount5 on1 action card this phase; share cobweb2",
		threat: 0,
		small: {}
	},
	{
		id: "o49",
		name: "You're a Wizard Lady!",
		chain: "fight",
		level: 6,
		condition: "defeat4 non-boss enemies in one Character phase using only staves",
		reward: "each Magic Power Potion OR Mana Potion",
		threat: 1,
		small: { condition: "defeat2 non-boss enemies in one Character phase using only staves" }
	},
	{
		id: "o50",
		name: "You and What Army?",
		chain: "fight",
		level: 8,
		condition: "all characters have summoned minion",
		reward: "each random type3 consumable1",
		threat: 1,
		small: {}
	},
	{
		id: "o51",
		name: "Cu Later!",
		chain: "fight",
		level: 10,
		condition: "defeat boss with everyone in Copper/Wood/no armor for entire fight",
		reward: "chain complete",
		threat: 2,
		small: {}
	},
	{
		id: "o52",
		name: "Star Power",
		chain: "explore",
		level: 5,
		condition: "have collected fallen star",
		reward: "each scrap1 from hand/draw/discard",
		threat: 0,
		small: {}
	},
	{
		id: "o53",
		name: "Out Past Curfew",
		chain: "explore",
		level: 6,
		condition: "spawn6 non-boss Surface enemies during one night",
		reward: "each free Explore More from Guide",
		threat: 1,
		small: { condition: "spawn4 non-boss Surface enemies during one night" }
	},
	{
		id: "o54",
		name: "In This Economy?",
		chain: "explore",
		level: 8,
		condition: "spend50 coins in one Character phase",
		reward: "each random type3 consumable1",
		threat: 1,
		small: { condition: "spend40 coins in one Character phase" }
	},
	{
		id: "o55",
		name: "Hellavator",
		chain: "explore",
		level: 10,
		condition: "Surface to Underworld in one Character phase without pylon",
		reward: "chain complete",
		threat: 2,
		small: {}
	}
], S = {
	source: "Original ruler and house image geometries visually checked 2026-11-07",
	time: {
		spaces: [
			"sunrise",
			"day",
			"day threat spawn",
			"day",
			"day",
			"night threat spawn",
			"night threat spawn"
		],
		advanceBeforeResolve: !0
	},
	houses: {
		workbench: ["##"],
		anvil: ["##", "##"],
		loom: ["####"],
		bottle: [".#.", "###"],
		cookingPot: ["###", "###"],
		bed: ["###", "###"],
		hellforge: ["###", "###"]
	},
	range: {
		entryDistance: "Center-to-center ray intersects target cell boundary; Euclidean distance at entry",
		short: "8-adjacent squares; no ruler",
		medium: {
			maxEntryCells: 3,
			excludeAdjacentForCharacter: !0
		},
		long: {
			maxEntryCells: 7,
			discard1AfterCells: 3,
			discard2AfterCells: 5,
			excludeAdjacentForCharacter: !0
		},
		rulerMeasurement: "Long left-end boundaries x≈240,725,1210,1715 on1976px image; common segment unit≈244px. Medium measured from right end x≈1715,1215. Headings correspond1/3/5/7 cell lengths. Near out-of-range heading is only reminder; adjacency checked separately by rulebook21."
	},
	bossShapes: {
		kingSlime1: {
			rows: ["###", "###"],
			anchor: [1, 1]
		},
		kingSlime2: {
			rows: ["##"],
			anchor: [0, 0]
		},
		eater1: {
			rows: [
				"#",
				"#",
				"#",
				"#",
				"#"
			],
			anchor: [0, 4]
		},
		eater2: {
			rows: [
				"#",
				"#",
				"#"
			],
			anchor: [0, 2]
		},
		brain: {
			rows: ["###", "###"],
			anchor: [1, 1]
		},
		eye: {
			rows: [
				"##",
				"##",
				"##"
			],
			anchor: [1, 2]
		},
		queenBee: {
			rows: [
				"##",
				"##",
				"##"
			],
			anchor: [1, 2]
		},
		wall1: {
			rows: [
				"#.",
				"##",
				"#.",
				"##",
				"#."
			],
			anchor: [0, 4],
			targets: [[1, 1], [1, 3]]
		},
		wall2: {
			rows: [
				"#.",
				"#.",
				"##",
				"#.",
				"#."
			],
			anchor: [0, 4],
			targets: [[1, 2]]
		}
	},
	notes: [
		"Larva/Shadow Orb/Crimson Heart use D4 defense, not D8",
		"Decorative sword/pickaxe illustrations on Underground maps have no rule icon and are not collectible",
		"Evil upper cavern images show altars, not spawned Creeper/Devourer tokens",
		"Molten Fury crafting reference says4AP but actual equipment card says3AP; implement actual card"
	]
}, pe = se, me = ce, C = y, w = (e) => pe.find((t) => t.id === e), T = (e) => me.find((t) => t.id === e), he = (e) => b.find((t) => t.id === e), E = (e) => x.find((t) => t.name === e), ge = (e) => v.find((t) => t.id === e), D = (e) => fe.find((t) => t.id === e), O = (e) => [
	...pe,
	...me,
	...b,
	...C
].find((t) => t.name === e)?.id ?? "", k = {
	"#": {
		cost: 1,
		resource: ""
	},
	s: {
		cost: 2,
		resource: "stone"
	},
	cu: {
		cost: 2,
		resource: "copper"
	},
	fe: {
		cost: 2,
		resource: "iron"
	},
	ag: {
		cost: 3,
		resource: "silver"
	},
	au: {
		cost: 3,
		resource: "gold"
	},
	g: {
		cost: 3,
		resource: "gem"
	},
	de: {
		cost: 3,
		resource: "demonite"
	},
	cr: {
		cost: 3,
		resource: "crimtane"
	},
	es: {
		cost: 4,
		resource: "",
		hardy: !0
	},
	cs: {
		cost: 4,
		resource: "",
		hardy: !0
	},
	hs: {
		cost: 2,
		resource: ""
	},
	ice: {
		cost: 2,
		resource: ""
	},
	he: {
		cost: 4,
		resource: "hellstone",
		hardy: !0
	}
}, _e = {
	workbench: {
		rows: ["##"],
		cost: {
			wood: 4,
			gel: 2
		},
		requires: "",
		copies: 1
	},
	anvil: {
		rows: ["##", "##"],
		cost: {
			stone: 1,
			wood: 1,
			gel: 2,
			iron: 1
		},
		requires: "workbench",
		copies: 1
	},
	loom: {
		rows: ["####"],
		cost: {
			stone: 1,
			gel: 3,
			wood: 2,
			iron: 1
		},
		requires: "anvil",
		copies: 1
	},
	bottle: {
		rows: [".#.", "###"],
		cost: {
			stone: 3,
			wood: 3,
			gel: 3
		},
		requires: "anvil",
		copies: 1
	},
	cookingPot: {
		rows: ["###", "###"],
		cost: {
			stone: 2,
			wood: 2,
			gel: 2,
			iron: 2
		},
		requires: "anvil",
		copies: 1
	},
	bed: {
		rows: ["###", "###"],
		cost: {
			stone: 2,
			wood: 2,
			gel: 2,
			cobweb: 2
		},
		requires: "loom",
		copies: 4
	},
	hellforge: {
		rows: ["###", "###"],
		cost: {
			stone: 4,
			wood: 4,
			gel: 4,
			hellstone: 1
		},
		requires: "anvil",
		copies: 1
	}
}, ve = [
	"merchant",
	"nurse",
	"goblin",
	"demolitionist",
	"dryad"
], ye = [
	4,
	6,
	8,
	12,
	20
], A = (e) => ye[Math.min(4, ye.indexOf(e) + 1)], be = (e) => ye[Math.max(0, ye.indexOf(e) - 1)], xe = {
	e33: {
		name: "Snow Flinx",
		attack: 2,
		cost: 2
	},
	e34: {
		name: "Fire Imp",
		attack: 3,
		cost: 3,
		prevent: !0
	},
	e60: {
		name: "Baby Slime",
		attack: 1,
		cost: 1
	},
	e61: {
		name: "Hornet",
		attack: 3,
		cost: 3
	}
}, j = (e, t = 1, n = "") => ({
	kind: e,
	n: t,
	a: n
}), M = (e = 1) => j("ap", e), N = (...e) => ({ branches: [e] }), P = (e, t) => ({ branches: [[e], [t]] }), F = (e, t = 1) => j("flag", t, e), Se = {
	s0: P(M(), j("attack")),
	s1: N(M(), j("assist")),
	s2: P(M(), j("defense", 2)),
	s3: P(j("coins"), j("lowHeal")),
	s4: N(M()),
	s5: N(M(2)),
	a0: {
		branches: [[j("attack", 2)]],
		ready: { attack: 1 }
	},
	a1: N(M(2)),
	a2: {
		branches: [[j("drawKeep", 2)]],
		ready: { defense: 1 }
	},
	a3: N(M(), j("health")),
	a4: P(M(), j("copy", 1, "start")),
	a5: N(M(), j("freePlatforms", 2)),
	a6: {
		branches: [],
		ready: { ap: 2 }
	},
	a7: N(M(), j("mana")),
	a8: N(M(), j("coins", 2)),
	a9: N(j("teamBiome", 1, "industry")),
	a10: N(M(), j("discardDraw")),
	a11: N(M(2), j("assist", 2)),
	a12: N(M(), F("doubleConsumable")),
	a13: N(j("teamBiome", 2, "rally")),
	a14: P(M(2), j("teleport")),
	a15: N(M(), F("enemyAttackReroll")),
	a16: P(M(), F("enemyDefenseReroll")),
	a17: {
		branches: [[j("clearOthers")]],
		ready: { immune: 1 }
	},
	a18: N(M(), F("shakedown")),
	a19: N(M(2), F("duplicateDefense")),
	a20: P(M(2), j("mana", 2)),
	a21: N(M(2), j("fetch", 1, "draw")),
	a22: N(j("deescalate")),
	a23: N(M(2), F("regenKill")),
	a24: N(M(2), j("attack", 2)),
	a25: {
		branches: [[M(2)]],
		ready: { defense: 2 }
	},
	a26: N(M(2), F("radar", 2)),
	a27: N(M(2), F("enemySmallAttackDemote")),
	a28: N(M(2), F("enemySmallDefenseDemote")),
	a29: N(M(2), j("copy")),
	a30: N(M(2), F("radar", 3)),
	a31: {
		branches: [[M(2)]],
		ready: { climb: 1 }
	},
	a32: N(M(2), j("fetch", 1, "discard")),
	a33: {
		branches: [],
		ready: { stockpile: 1 }
	},
	a34: {
		branches: [[M(2)]],
		ready: { speed: 2 }
	},
	a35: N(M(2), F("enemyLargeAttackDemote")),
	a36: N(M(2), F("enemyLargeDefenseDemote")),
	a37: N(M(), j("draw", 3)),
	a38: N(M(2), j("fetch", 1, "scrapped")),
	a39: N(j("finisher")),
	a40: N(M(2), j("scrap", 2, "handDiscard")),
	a41: N(M(2), F("enemyRemoveAttack")),
	a42: P(M(2), F("enemyRemoveDefense")),
	a43: N(M(), F("punchbag")),
	a44: N(F("foresight")),
	a45: P(M(), F("duplicateAttack")),
	a46: P(M(), j("lowHeal", 2)),
	a47: P(j("discardDraw"), j("springScrap")),
	a48: N(M(3)),
	a49: N(M(), F("defenseReroll")),
	a50: N(M(), j("drawDiscard", 2)),
	a51: N(M(), F("promoteAttack")),
	a52: N(M(), F("promoteDefense")),
	a53: N(j("teamFlag", 1, "freeDonate")),
	a54: N(j("copy", 1, "other")),
	a55: P(j("drawDiscard"), j("scrap", 1, "handDiscard")),
	a56: N(M(), j("draw", 2)),
	a57: N(j("teamBiome", 1, "yield")),
	a58: N(M(4))
}, Ce = (e, t) => e ? Se[e]?.ready?.[t] ?? 0 : 0, we = (e, t, n) => ({
	kind: "card",
	a: e,
	n,
	flag: String(t)
}), I = (e, t) => e.x === t.x && e.y === t.y, L = (e, t) => Math.max(Math.abs(e.x - t.x), Math.abs(e.y - t.y)) <= 1, R = (e, t) => Math.hypot(e.x - t.x, e.y - t.y);
function Te(e) {
	let t = e[0];
	return e.length < 3 || e.slice(1).flatMap((e) => [-.5, .5].flatMap((n) => [-.5, .5].map((r) => Math.atan2(e.y - t.y + r, e.x - t.x + n)))).some((n) => {
		let r = Math.cos(n), i = Math.sin(n);
		return e.every((e) => Math.abs(r * (e.y - t.y) - i * (e.x - t.x)) <= .5 * (Math.abs(r) + Math.abs(i)) + 1e-8);
	});
}
var z = (e, t = !0) => [
	-1,
	0,
	1
].flatMap((n) => [
	-1,
	0,
	1
].flatMap((r) => r === 0 && n === 0 || !t && r !== 0 && n !== 0 ? [] : [{
	x: e.x + r,
	y: e.y + n
}])), Ee = (e, t) => e >= 0 && e < 17 && t >= 0 && t < 5 && (t === 0 || e > 0 && e < 16), De = (e, t) => e.world.find((e) => e.x === Math.floor(t.x / 3) && e.y === Math.floor(t.y / 5)), B = (e, t) => De(e, t)?.cells[t.y % 5 * 3 + t.x % 3] ?? "unknown", Oe = (e, t, n) => {
	let r = De(e, t);
	r && (r.cells[t.y % 5 * 3 + t.x % 3] = n);
}, ke = (e) => e < 3 ? -1 : e >= 48 ? 5 : Math.floor((Math.floor(e / 3) - 1) / 3), V = (e, t) => e.biomeOrder[ke(t.x)] ?? "beach", H = (e, t) => !!k[B(e, t)], Ae = (e, t) => e.houses.find((e) => e.cells.some((e) => I(e, t))), je = (e) => {
	let t = e.id === "kingSlime" || e.id === "eater" || e.id === "wall" ? e.id + (e.form + 1) : e.id;
	return S.bossShapes[t];
}, U = (e) => {
	if (!e.boss) return [];
	let t = e.boss, n = je(t);
	return n.rows.flatMap((e, r) => [...e].flatMap((e, i) => e === "#" ? [{
		x: t.x + i - n.anchor[0],
		y: t.y + r - n.anchor[1]
	}] : []));
}, W = (e, t, n = "") => Object.values(e.people).some((e) => e.rid !== n && !e.dead && I(e, t)) || e.enemies.some((e) => e.uid !== n && I(e, t)) || n !== "boss" && U(e).some((e) => I(e, t)), Me = (e, t) => B(e, t) !== "unknown" && !H(e, t), Ne = (e, t) => !W(e, t) && !Ae(e, t) && !e.ropes.some((e) => I(e, t)) && !e.pylons.some((e) => I(e, t)), Pe = (e, t) => e.ropes.some((n) => n.x === t.x && n.y <= t.y && Array.from({ length: t.y - n.y }, (e, r) => ({
	x: t.x,
	y: n.y + r + 1
})).every((t) => !H(e, t) && !Ae(e, t))), Fe = (e, t, n = "") => t.y >= 24 || e.platforms.some((e) => I(e, t)) || H(e, {
	x: t.x,
	y: t.y + 1
}) || B(e, {
	x: t.x,
	y: t.y + 1
}) === "unknown" || W(e, {
	x: t.x,
	y: t.y + 1
}, n) || !(!Ae(e, {
	x: t.x,
	y: t.y + 1
}) || Ae(e, t)), Ie = (e, t, n) => t.x !== n.x && t.y !== n.y && H(e, {
	x: t.x,
	y: n.y
}) && H(e, {
	x: n.x,
	y: t.y
});
function Le(e, t, n, r = !1) {
	if (r) return !0;
	if (Ae(e, n) && Ae(e, n) !== Ae(e, t)) return !1;
	let i = n.x - t.x, a = n.y - t.y, o = Math.max(Math.abs(i), Math.abs(a)) * 12, s = { ...t };
	for (let r = 1; r < o; r++) {
		let c = {
			x: Math.floor(t.x + .5 + i * r / o),
			y: Math.floor(t.y + .5 + a * r / o)
		};
		if (!I(c, t) && !I(c, n) && H(e, c) && !e.enemies.some((e) => I(e, c) && [
			"Giant Worm",
			"Tomb Crawler",
			"Devourer"
		].includes(e.name)) || Ie(e, s, c)) return !1;
		s = c;
	}
	return !0;
}
function Re(e, t, n, r = !1) {
	if (L(e, t)) return n.includes("short") || r ? 0 : -1;
	let i = Math.abs(e.x - t.x), a = Math.abs(e.y - t.y), o = Math.hypot(i, a) * (1 - .5 / Math.max(i, a));
	return n.includes("medium") && o <= 3 + 1e-8 ? 0 : n.includes("long") && o <= 7 + 1e-8 ? o > 5 ? 2 : +(o > 3) : -1;
}
var ze = (e, t) => _e[e].rows.flatMap((e, n) => [...e].flatMap((e, r) => e === "#" ? [{
	x: t.x + r,
	y: t.y + n
}] : [])), Be = (e, t, n, r) => {
	let i = ze(t, n);
	return i.some((e) => L(e, r)) && i.every((t) => Me(e, t) && !Ae(e, t) && !e.enemies.some((e) => I(e, t)) && !U(e).some((e) => I(e, t)));
}, Ve = (e) => [
	{
		x: e.x - 1,
		y: e.y
	},
	{
		x: e.x + 1,
		y: e.y
	},
	{
		x: e.x,
		y: e.y - 1
	},
	{
		x: e.x,
		y: e.y + 1
	}
].filter((e) => Ee(e.x, e.y)), He = (e, t) => {
	let n = De(e, t);
	return n ? Ve(n).filter((t) => !e.world.some((e) => I(e, t))) : [];
}, Ue = (e, t) => Object.values(e.people).some((e) => !e.dead && Math.abs(Math.floor(e.x / 3) - Math.floor(t.x / 3)) + Math.abs(Math.floor(e.y / 5) - Math.floor(t.y / 5)) <= 1), We = {
	id: "terraria",
	tier: "alpha",
	mechanics: [
		"deck-bag-building",
		"grid-movement",
		"action-points",
		"dice-rolling",
		"tile-placement"
	],
	interactionTags: ["cooperative"],
	nameKey: "games.terraria.name",
	descKey: "games.terraria.desc",
	rulesKey: "games.terraria.rules",
	icon: "🌳",
	iconImg: "games/terraria.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [
		2,
		3,
		4
	],
	accent: "#62984a",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/12262868527317008969/2DAAF27BA4554A32AADB3D048345EE87186A0988/" },
	releasedAt: "2026-11-07T18:00:00+08:00",
	search: {
		py: "tailaruiyazhuoyouban",
		init: "tlryzyb"
	},
	hotseat: "open",
	botDelayMs: 550
}, Ge = t.object({
	difficulty: t.enum([
		"journey",
		"standard",
		"tough",
		"heroic"
	]).default("standard"),
	evil: t.enum(["corruption", "crimson"]).default("corruption"),
	threat: t.int().min(0).max(3).default(0),
	alternatives: t.boolean().default(!1),
	focus: t.boolean().default(!1)
}).default({
	difficulty: "standard",
	evil: "corruption",
	threat: 0,
	alternatives: !1,
	focus: !1
}), Ke = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(80)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), qe = {
	x: t.int(),
	y: t.int()
}, Je = t.object({
	uid: t.string(),
	type: t.string(),
	used: t.array(t.int()),
	branch: t.int().nullable()
}), Ye = {
	kind: t.string(),
	a: t.string().optional(),
	b: t.string().optional(),
	n: t.number().optional(),
	x: t.int().optional(),
	y: t.int().optional(),
	flag: t.string().optional(),
	who: t.string().optional()
}, Xe = t.object({
	...qe,
	rid: t.string(),
	hp: t.number(),
	maxHp: t.number(),
	mana: t.number(),
	maxMana: t.number(),
	coins: t.number(),
	inventory: t.array(t.object({
		resource: t.string(),
		n: t.int()
	})),
	stockpile: t.object({
		resource: t.string(),
		n: t.int()
	}),
	toolPoints: t.array(t.object({
		kind: t.string(),
		n: t.int(),
		yield: t.number()
	})),
	equipment: t.array(t.string()),
	equipped: t.record(t.string(), t.string()),
	armors: t.array(t.string()),
	armor: t.string(),
	consumables: t.array(t.string()),
	minion: t.string(),
	platforms: t.int(),
	ropes: t.int(),
	hand: t.array(Je),
	played: t.array(Je),
	ready: Je.nullable(),
	deckCount: t.int(),
	discard: t.array(Je),
	scrapped: t.array(Je),
	ap: t.number(),
	attack: t.number(),
	defense: t.number(),
	dig: t.number(),
	hardyDig: t.number(),
	chop: t.number(),
	debuffs: t.record(t.string(), t.number()),
	flags: t.record(t.string(), t.number()),
	ended: t.boolean(),
	prepared: t.boolean(),
	dead: t.boolean()
}), Ze = t.object({
	serial: t.int(),
	config: Ge,
	phase: t.enum([
		"prepare",
		"character",
		"enemy",
		"environment",
		"done"
	]),
	round: t.int(),
	day: t.int(),
	time: t.int(),
	threat: t.number(),
	graves: t.int(),
	permanentThreat: t.boolean(),
	people: t.array(Xe),
	world: t.array(t.object({
		...qe,
		biome: t.string(),
		id: t.string(),
		cells: t.array(t.string())
	})),
	biomes: t.array(t.string()),
	enemies: t.array(t.object({
		...qe,
		uid: t.string(),
		name: t.string(),
		hp: t.number(),
		night: t.boolean()
	})),
	houses: t.array(t.object({
		...qe,
		type: t.string(),
		cells: t.array(t.object(qe))
	})),
	platforms: t.array(t.object(qe)),
	ropes: t.array(t.object(qe)),
	pylons: t.array(t.object(qe)),
	acorns: t.array(t.object(qe)),
	npcs: t.array(t.string()),
	bottle: t.int(),
	food: t.array(t.int()),
	dryad: t.boolean(),
	boss: t.object({
		...qe,
		id: t.string(),
		form: t.int(),
		hp: t.number(),
		eyes: t.array(t.number()),
		buffs: t.array(t.int()),
		behavior: t.int(),
		transformed: t.boolean(),
		born: t.int(),
		cheap: t.boolean()
	}).nullable(),
	bossQueue: t.array(t.string()),
	defeated: t.array(t.string()),
	objectives: t.array(t.object({
		chain: t.string(),
		level: t.int(),
		id: t.string(),
		focus: t.int()
	})),
	completed: t.array(t.string()),
	pending: t.object({
		who: t.string(),
		prompt: t.string()
	}).nullable(),
	battle: t.object({
		piercePoints: t.array(t.object(qe)).optional(),
		rid: t.string(),
		targets: t.array(t.string()),
		dice: t.array(t.number()),
		rolled: t.array(t.number()),
		defense: t.array(t.number()),
		defended: t.array(t.number()),
		prevent: t.boolean(),
		stage: t.string(),
		enemyAttack: t.boolean(),
		debuff: t.string(),
		kind: t.string(),
		source: t.string(),
		mods: t.array(t.string()),
		boosted: t.int(),
		shielded: t.int(),
		drop: t.int(),
		friends: t.array(t.string()),
		retaliations: t.array(t.object({
			id: t.string(),
			n: t.number(),
			debuff: t.string()
		}))
	}).nullable(),
	log: t.array(t.object({
		id: t.int(),
		key: t.string(),
		who: t.string(),
		item: t.string(),
		n: t.number(),
		x: t.int(),
		y: t.int()
	})),
	result: t.enum([
		"",
		"win",
		"loss"
	]),
	stats: t.record(t.string(), t.number()),
	supply: t.record(t.string(), t.int())
}), Qe = t.object({ choices: t.array(t.object({
	...Ye,
	id: t.string(),
	group: t.string()
})) }), $e = (e, t = "c") => t + e.nextUid++, et = (t, n) => e(t.seed, t.rngCursor++, n), tt = (e, t) => {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = et(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}, nt = (e, t) => t.map((t) => et(e, t) + 1), rt = (e, t) => ({
	uid: $e(e),
	type: t,
	used: [],
	branch: null
}), G = (e, ...t) => e.queue.unshift(...t), K = (e, t, n, r) => {
	e.pending = r.length ? {
		who: t,
		prompt: n,
		options: r
	} : null;
}, q = (e, t, n = "", r = "", i = 0, a = {
	x: 0,
	y: 0
}) => {
	e.log.push({
		id: ++e.logSequence,
		key: t,
		who: n,
		item: r,
		n: i,
		...a
	}), e.log.length > 100 && e.log.shift();
}, J = (e, t, n = 1) => {
	e.stats[t] = (e.stats[t] ?? 0) + n, e.turnStats[t] = (e.turnStats[t] ?? 0) + n;
	for (let r of e.objectives) e.stats[r.id + ":" + t] = (e.stats[r.id + ":" + t] ?? 0) + n;
}, it = (e, t) => [...e.inventory, e.stockpile].reduce((e, n) => e + (n.resource === t ? n.n : 0), 0), at = (e, t) => Object.entries(t).every(([t, n]) => it(e, t) >= n), ot = (e, t) => {
	for (let [n, r] of Object.entries(t)) {
		let t = r;
		for (let r of [...e.inventory, e.stockpile]) if (r.resource === n) {
			let e = Math.min(t, r.n);
			r.n -= e, t -= e;
		}
	}
}, st = (e, t, n) => {
	t.coins -= n, J(e, "spent", n);
}, ct = (e, t) => {
	e.coins = Math.min(25, e.coins + t);
}, lt = (e, t) => !t || e.houses.some((e) => e.type === t), Y = (e, t, n) => ({
	kind: "resource",
	who: e,
	a: t,
	n
}), ut = (e, t, n = 1) => ({
	kind: "gain",
	who: e,
	a: t,
	n
}), dt = (e) => T(e.armor), ft = (e, t) => Ce(e.ready?.type, t), pt = (e) => [...dt(e)?.dice ?? [4]], mt = (e, t) => ft(e, "immune") > 0 || e.armor === "r15" && t === "fire" || e.armor === "r25" && t === "frozen", X = (e) => e.players.map((t) => e.people[t]).filter((e) => !e.dead), ht = (e, t) => e.supply[t] > 0, gt = (e, t) => e[t].length + Object.values(e.people).reduce((e, n) => e + n[t], 0), Z = (e, t) => e.enemies.find((e) => e.uid === t), _t = (e) => e.permanentThreat || e.boss ? 2 : 1;
function vt(e, t) {
	e.threat = Math.max(0, Math.min(10, e.threat + t)), e.threat >= 10 && (e.phase = "done", e.result = "loss", e.queue = [], e.pending = null, e.battle = null), q(e, "threat", "", "", t);
}
function yt(e, t, n) {
	let r = 0;
	for (let i = 0; i < n; i++) {
		!t.deck.length && t.discard.length && (t.deck = tt(e, t.discard), t.discard = []);
		let n = t.deck.shift();
		n && (t.hand.push(n), r++);
	}
	r && q(e, "draw", t.rid, "", r);
}
function bt(e, t, n) {
	!n || t.dead || mt(t, n) || (t.debuffs[n] = 2, q(e, "debuff", t.rid, n));
}
function xt(e, t) {
	if (!t.dead) {
		t.stockpile = {
			resource: "",
			n: 0
		}, t.dead = !0, t.hp = 0, t.debuffs = {}, t.deck = tt(e, [
			...t.deck,
			...t.discard,
			...t.hand,
			...t.played,
			...t.ready ? [t.ready] : []
		].filter((e) => !e.uid.startsWith("copy"))).map((e) => ({
			...e,
			used: [],
			branch: null
		})), t.discard = [], t.hand = [], t.played = [], t.ready = null, t.coins = Math.floor(t.coins / 2), t.minion = "";
		for (let n of t.consumables) Ct(e, n);
		t.consumables = [], e.config.difficulty !== "journey" && (e.graves > 0 ? (e.graves--, vt(e, _t(e)), e.graves || (e.permanentThreat = !0)) : vt(e, 2)), q(e, "death", t.rid);
	}
}
function St(e, t, n) {
	t.dead || n <= 0 || (t.hp -= n, t.flags.punchbag && ct(t, 3 * n), q(e, "damage", t.rid, "", n, t), t.hp <= 0 && xt(e, t));
}
function Ct(e, t) {
	e.supply[t]++, e.loot["consumable:" + he(t).type].push(t);
}
function wt(e, t) {
	B(e, t) === "W" && (G(e, Y(t.rid, "cobweb", 1)), t.y >= 5 && t.y < 10 && J(e, "web")), B(e, t) === "L" && bt(e, t, "fire");
}
function Tt(e, t, n = !1, r = !0) {
	if (t.dead || n && Pe(e, t) || r && ft(t, "climb") && z(t, !1).some((n) => n.x !== t.x && H(e, n))) return;
	let i = t.y;
	for (; t.y < 24 && !Fe(e, t, t.rid);) t.y++, B(e, t) === "W" && (G(e, Y(t.rid, "cobweb", 1)), t.y >= 5 && t.y < 10 && J(e, "web"));
	let a = t.y - i;
	if (a > 0) {
		if (B(e, t) === "L" && bt(e, t, "fire"), a > 1 && !["W", "L"].includes(B(e, t)) && e.config.difficulty !== "journey") {
			let n = nt(e, pt(t));
			St(e, t, Math.max(0, a - n.reduce((e, t) => e + t, 0)));
		}
		a >= 8 && !t.dead && J(e, "fall8"), q(e, "fall", t.rid, "", a, t);
	}
}
function Et(e) {
	let t = [...X(e), ...e.enemies].sort((e, t) => t.y - e.y);
	for (let n of t) {
		if ("rid" in n) {
			W(e, n, n.rid) || Tt(e, n, !0);
			continue;
		}
		let t = E(n.name);
		if (!(t?.mode === "fly" || t?.mode === "worm" && H(e, n))) for (; n.y < 24 && !Fe(e, n, n.uid);) n.y++;
	}
}
function Dt(e, t, n, r) {
	let i = E(n);
	e.enemies.push({
		...t,
		uid: $e(e, "e"),
		name: n,
		hp: i?.health ?? 1,
		bag: r,
		night: e.time >= 5 && t.y < 5
	}), n === "Life Crystal" && J(e, "crystalSeen"), t.y < 5 && e.time >= 5 && (J(e, "nightSpawn"), e.stats.thisNightSpawns = (e.stats.thisNightSpawns ?? 0) + 1), q(e, "spawn", "", n, 0, t);
}
function Ot(e, t) {
	let n = [
		"Surface",
		"Underground",
		"Upper Cavern",
		"Lower Cavern",
		"Underworld"
	], r = V(e, t);
	return r[0].toUpperCase() + r.slice(1) + " " + n[Math.floor(t.y / 5)] + (t.y < 5 ? e.time < 5 ? " Day" : " Night" : "");
}
function kt(e, t) {
	return B(e, t) === "S" && Ne(e, t) ? {
		kind: "spawnAt",
		...t
	} : void 0;
}
function At(e, t, n) {
	let r = e.world.find((e) => e.x === t && e.y === n);
	return r ? r.cells.flatMap((e, r) => e === "S" ? [{
		x: t * 3 + r % 3,
		y: n * 5 + Math.floor(r / 3)
	}] : []) : [];
}
function jt(e, t, n) {
	if (e.world.some((e) => e.x === t && e.y === n) || !Ee(t, n)) return;
	let r = V(e, {
		x: t * 3,
		y: n * 5
	}), i = n === 1 ? "underground" : n === 4 ? "underworld" : r + ":" + n, a = e.mapPools[i]?.shift();
	if (!a) return;
	let o = ge(a);
	e.world.push({
		x: t,
		y: n,
		id: a,
		biome: r,
		cells: [...o.cells]
	});
	let s = ke(t * 3);
	e.revealedBiomes.includes(s) || e.revealedBiomes.push(s), J(e, "discovered"), J(e, "discovered:" + r), n === 4 && J(e, "underworldSeen"), r === "beach" && J(e, "ocean"), o.cells.includes("Larva") && J(e, "hive"), G(e, ...At(e, t, n).flatMap((t) => {
		let n = kt(e, t);
		return n ? [n] : [];
	})), q(e, "discover", "", r, 0, {
		x: t * 3,
		y: n * 5
	});
}
function Mt(e, t, n) {
	let r = {
		seed: n,
		logSequence: 0,
		rngCursor: 0,
		serial: 0,
		nextUid: 1,
		config: Ge.parse(e),
		players: t,
		people: {},
		world: [],
		enemies: [],
		mapPools: {},
		biomeOrder: [],
		revealedBiomes: [2],
		bags: {},
		supply: {},
		loot: {},
		chests: {},
		houses: [],
		platforms: [{
			x: 25,
			y: 3
		}],
		ropes: [],
		pylons: [],
		acorns: [],
		digged: [],
		npcs: ["guide"],
		bottle: 0,
		food: [],
		dryad: !1,
		graves: t.length * 2,
		permanentThreat: !1,
		threat: e?.threat ?? 0,
		day: 1,
		time: 0,
		round: 1,
		phase: "prepare",
		boss: null,
		bossQueue: [],
		triggered: [],
		defeated: [],
		queue: [],
		pending: null,
		battle: null,
		enemyTodo: [],
		objectives: [],
		completed: [],
		stats: {},
		turnStats: {},
		globalFlags: {},
		log: [],
		result: ""
	}, i = tt(r, [
		"desert",
		"snow",
		"jungle",
		r.config.evil
	]);
	r.biomeOrder = [
		i[0],
		i[1],
		"forest",
		i[2],
		i[3]
	];
	for (let e of v) {
		if ([
			"c2cd53",
			"d912eb",
			"e29094",
			"f6d5dc"
		].includes(e.id)) continue;
		let t = e.layer === 1 ? "underground" : e.layer === 4 ? "underworld" : e.biome + ":" + e.layer;
		(r.mapPools[t] ??= []).push(e.id);
	}
	for (let e of Object.keys(r.mapPools)) r.mapPools[e] = tt(r, r.mapPools[e]);
	for (let [e, t] of [
		"c2cd53",
		"d912eb",
		"e29094"
	].entries()) r.world.push({
		x: 7 + e,
		y: 0,
		biome: "forest",
		id: t,
		cells: [...ge(t).cells]
	});
	r.world.push({
		x: 8,
		y: 1,
		biome: "forest",
		id: "f6d5dc",
		cells: [...ge("f6d5dc").cells]
	});
	for (let [e, t] of Object.entries(le)) r.bags[e] = tt(r, t);
	for (let e of [
		...pe,
		...me,
		...b,
		...C.filter((e) => e.source !== "start")
	]) r.supply[e.id] = e.copies;
	for (let e = 1; e <= 4; e++) r.loot["consumable:" + e] = tt(r, b.filter((t) => t.type === e).flatMap((e) => Array.from({ length: e.copies }, () => e.id)));
	for (let e = 1; e <= 5; e++) r.loot[e] = tt(r, C.filter((t) => t.source === "loot" && t.cost === e).flatMap((e) => Array.from({ length: e.copies }, () => e.id)));
	for (let [e, t] of Object.entries(de)) r.chests[e] = tt(r, t);
	let a = [
		{
			x: 25,
			y: 3
		},
		{
			x: 24,
			y: 4
		},
		{
			x: 25,
			y: 4
		},
		{
			x: 26,
			y: 4
		}
	];
	for (let [e, n] of t.entries()) {
		let i = {
			rid: n,
			...a[e],
			hp: 5,
			maxHp: 5,
			mana: 3,
			maxMana: 3,
			coins: 0,
			inventory: Array.from({ length: t.length <= 2 ? 6 : t.length === 3 ? 5 : 4 }, () => ({
				resource: "",
				n: 0
			})),
			stockpile: {
				resource: "",
				n: 0
			},
			toolPoints: [],
			equipment: [
				"e0",
				"e7",
				"e14"
			],
			equipped: {
				axe: "e0",
				pickaxe: "e7",
				sword: "e14",
				other: ""
			},
			armors: [],
			armor: "",
			consumables: [],
			minion: "",
			platforms: 0,
			ropes: r.config.difficulty === "journey" ? 2 : 0,
			hand: [],
			played: [],
			ready: null,
			deck: [],
			discard: [],
			scrapped: [],
			ap: 0,
			attack: 0,
			defense: 0,
			dig: 0,
			hardyDig: 0,
			chop: 0,
			debuffs: {},
			flags: {},
			ended: !1,
			prepared: !1,
			dead: !1
		};
		r.config.difficulty === "journey" && (i.equipment = [
			"e1",
			"e8",
			"e15"
		], i.equipped = {
			axe: "e1",
			pickaxe: "e8",
			sword: "e15",
			other: ""
		});
		for (let e of i.equipment) r.supply[e]--;
		i.deck = tt(r, [
			"s0",
			"s1",
			"s2",
			"s3",
			"s4",
			"s4",
			"s4",
			"s5"
		].map((e) => rt(r, e))), r.people[n] = i;
	}
	for (let e of [{
		x: 21,
		y: 3
	}, {
		x: 29,
		y: 3
	}]) {
		let t = Ot(r, e), n = r.bags[t].shift();
		n && Dt(r, e, n, t);
	}
	return r.stats = {}, r.turnStats = {}, r.objectives = [
		"dig",
		"build",
		"fight",
		"explore"
	].map((e) => ({
		chain: e,
		level: 1,
		id: fe.find((t) => t.chain === e && t.level === 1).id,
		focus: 0
	})), q(r, "start"), {
		state: r,
		fx: []
	};
}
function Nt(e, t, n, r, i = !1) {
	if (r <= 0) return;
	let a = t.inventory.flatMap((e, i) => Array.from({ length: Math.min(r, e.resource === n ? 5 - e.n : 5) }, (e, a) => ({
		kind: "store",
		a: n,
		b: String(i),
		n: a + 1,
		flag: String(r),
		who: t.rid
	})));
	ft(t, "stockpile") && t.stockpile.n < 20 && (!t.stockpile.n || t.stockpile.resource === n) && a.push({
		kind: "storeStockpile",
		a: n,
		n: Math.min(r, 20 - t.stockpile.n),
		flag: String(r),
		who: t.rid
	}), a.push({
		kind: "discardResource",
		a: n,
		n: r,
		who: t.rid
	});
	for (let i of X(e)) i.rid !== t.rid && (t.ap > 0 || e.globalFlags.freeDonate) && a.push({
		kind: "overflowDonate",
		a: n,
		n: r,
		b: i.rid,
		who: t.rid
	});
	if (i) {
		let i = {
			...t,
			inventory: [...t.inventory, {
				resource: n,
				n: r
			}]
		};
		for (let o of Lt(e, i)) [
			"craft",
			"craftToken",
			"house"
		].includes(o.kind) && a.push({
			kind: "giftCraft",
			a: JSON.stringify(o),
			b: n,
			n: r,
			who: t.rid
		});
	}
	K(e, t.rid, "inventory", a);
}
function Pt(e, t, n) {
	if (ht(e, n)) {
		if (n.startsWith("e")) e.supply[n]--, t.equipment.push(n), t.equipped[w(n).slot] = n, J(e, "obtain:" + n);
		else if (n.startsWith("r")) {
			e.supply[n]--, t.armors.push(n), t.armor = n;
			for (let e of Object.keys(t.debuffs)) mt(t, e) && delete t.debuffs[e];
			J(e, "obtain:" + n);
		} else if (n.startsWith("c")) {
			let r = e.loot["consumable:" + he(n).type], i = r.indexOf(n);
			i >= 0 && r.splice(i, 1), e.supply[n]--, t.consumables.push(n), J(e, "obtain:" + n);
		} else e.supply[n] > 0 && e.supply[n]--, t.discard.push(rt(e, n)), J(e, "obtain:" + n);
		q(e, "gain", t.rid, n);
	}
}
function Ft(e, t, n) {
	let r = /^(c|w|cu|fe|ag|au|he)(\d+)$/.exec(n);
	if (r) {
		r[1] === "c" ? ct(t, +r[2]) : G(e, Y(t.rid, {
			w: "wood",
			cu: "copper",
			fe: "iron",
			ag: "silver",
			au: "gold",
			he: "hellstone"
		}[r[1]], +r[2]));
		return;
	}
	if (/^L[1-5]$/.test(n)) {
		G(e, {
			kind: "loot",
			who: t.rid,
			n: +n[1]
		});
		return;
	}
	let i = O(n);
	i && G(e, ut(t.rid, i));
}
function It(e, t, n) {
	if (!ht(e, n)) return !1;
	let r = n.startsWith("e") ? w(n) : T(n);
	return r && Object.keys(r.recipe).length > 0 && at(t, r.recipe) && lt(e, r.house);
}
function Lt(e, t) {
	let n = [...pe, ...me].flatMap((n) => It(e, t, n.id) ? [{
		kind: "craft",
		a: n.id
	}] : []);
	at(t, { wood: 1 }) && (gt(e, "platforms") < 30 || e.platforms.length) && n.push({
		kind: "craftToken",
		a: "platform"
	}), at(t, { cobweb: 1 }) && (gt(e, "ropes") < 12 || e.ropes.length) && n.push({
		kind: "craftToken",
		a: "rope"
	}), ht(e, "e36") && t.equipment.filter((e) => [
		"e18",
		"e19",
		"e20"
	].includes(e)).length >= 2 && e.world.some((e) => e.cells.includes("Altar")) && n.push({ kind: "nightsEdge" });
	for (let [r, i] of Object.entries(_e)) if (!(e.houses.filter((e) => e.type === r).length >= i.copies || !at(t, i.cost) || !lt(e, i.requires) || r === "hellforge" && !Object.values(e.people).some((e) => e.equipment.some((e) => e === "e11" || e === "e12")))) for (let i = t.y - 3; i <= t.y + 1; i++) for (let a = t.x - 4; a <= t.x + 1; a++) Be(e, r, {
		x: a,
		y: i
	}, t) && n.push({
		kind: "house",
		a: r,
		x: a,
		y: i
	});
	return n;
}
function Rt(e, t) {
	return e.npcs.includes(t) || e.npcs.length - 1 >= e.houses.length ? !1 : t === "merchant" ? X(e).some((e) => e.coins >= 10) : t === "nurse" ? (e.stats.crystalSeen ?? 0) > 0 : t === "goblin" ? e.world.filter((e) => e.biome === "forest" && (e.y === 2 || e.y === 3)).length === 6 : t === "demolitionist" ? e.npcs.includes("merchant") && X(e).some((e) => e.consumables.some((e) => he(e).type === 3)) : e.defeated.some((e) => [
		"eye",
		"brain",
		"eater"
	].includes(e));
}
function zt(e, t) {
	let n = ve.filter((t) => Rt(e, t)).map((e) => ({
		kind: "spawnNpc",
		a: e
	}));
	for (let r of C) (r.source === "guide" || r.source === "merchant" && e.npcs.includes("merchant")) && t.coins >= r.cost - (t.flags.discount ?? 0) && ht(e, r.id) && n.push({
		kind: "buyAction",
		a: r.id,
		n: Math.max(0, r.cost - (t.flags.discount ?? 0))
	});
	if (e.npcs.includes("merchant") && t.coins >= 3 && b.some((t) => t.type === 1 && ht(e, t.id)) && n.push({
		kind: "buyConsumable",
		n: 1
	}), e.npcs.includes("demolitionist") && t.coins >= 15 && b.some((t) => t.type === 3 && ht(e, t.id)) && n.push({
		kind: "buyConsumable",
		n: 3
	}), e.npcs.includes("nurse") && !e.boss && t.coins >= 10 && (t.hp < t.maxHp || Object.keys(t.debuffs).length) && n.push({ kind: "nurse" }), e.npcs.includes("goblin") && t.coins >= 15 && !t.flags.goblin && n.push({ kind: "goblin" }), e.bottle && !t.flags.bottle) for (let t of b) t.type === 2 && ht(e, t.id) && n.push({
		kind: "bottle",
		a: t.id
	});
	if (!t.flags.food) for (let t of e.food) n.push({
		kind: "food",
		n: t
	});
	return n;
}
function Bt(e, t) {
	if (t.ap <= 0) return [];
	let n = [], r = ft(t, "speed") || 1;
	function i(r, a, o, s) {
		if (!(a.length > 5)) for (let c of z(r)) {
			if (!Me(e, c) || Ie(e, r, c) || e.boss?.id === "wall" && U(e).some((e) => I(e, c))) continue;
			let l = [...a, c], u = W(e, c, t.rid), d = { ...c };
			if (!u) {
				let r = ft(t, "climb") && z(c, !1).some((t) => t.x !== c.x && H(e, t));
				if (!Pe(e, c) && !r) for (; d.y < 24 && !Fe(e, d, t.rid);) d.y++;
				n.push({
					kind: "move",
					...d,
					n: o,
					flag: JSON.stringify(l)
				});
			}
			u && o < t.ap ? i(c, l, o + 1, 1) : !u && s > 1 && i(d, l, o, s - 1);
		}
	}
	if (i(t, [], 1, r), Pe(e, t) && !Fe(e, t, t.rid) && n.push({
		kind: "drop",
		x: t.x,
		y: t.y
	}), Pe(e, t)) for (let r of [-1, 1]) for (let i = 1; i <= (lt(e, "loom") ? 3 : 2); i++) {
		let a = {
			x: t.x,
			y: t.y + i * r
		};
		if (!Me(e, a) || !Pe(e, a)) break;
		W(e, a, t.rid) || n.push({
			kind: "ropeMove",
			...a,
			n: 1
		});
	}
	let a = t.equipped.other;
	if (["e35", "e52"].includes(a) && t.ap >= 2) for (let o of [-1, 1]) {
		let s = a === "e52" ? 3 : 2, c = {
			x: t.x + o,
			y: t.y - s
		}, l = Array.from({ length: s }, (e, n) => ({
			x: t.x,
			y: t.y - n - 1
		})).concat(c);
		if (!(!l.every((t) => Me(e, t)) || e.boss?.id === "wall" && U(e).some((e) => I(e, c)))) {
			if (!W(e, c, t.rid)) n.push({
				kind: "hook",
				...c,
				n: 2,
				flag: JSON.stringify(l)
			});
			else if (t.ap > 2) {
				let e = n.length;
				i(c, [], 3, r);
				let t = n.splice(e);
				for (let e of t) n.push({
					...e,
					kind: "hook",
					flag: JSON.stringify([...l, ...JSON.parse(e.flag)])
				});
			}
		}
	}
	return [...new Map(n.map((e) => [e.kind + ":" + e.x + ":" + e.y + ":" + e.n, e])).values()];
}
function Vt(e, t, n, r = !1) {
	let i = e.toolPoints.map((e, t) => ({
		pool: e,
		i: t
	})).filter(({ pool: e }) => t === "chop" ? e.kind === "chop" : e.kind === "hardyDig" || !r && e.kind === "dig"), a = [];
	function o(e, t, n) {
		if (!t) {
			a.push(JSON.stringify(n));
			return;
		}
		if (e >= i.length) return;
		let { pool: r, i: s } = i[e];
		for (let i = Math.min(t, r.n); i >= 0; i--) o(e + 1, t - i, i ? [...n, {
			i: s,
			n: i
		}] : n);
	}
	return o(0, n, []), [...new Map(a.map((t) => {
		let n = JSON.parse(t);
		return [Math.min(...n.map((t) => e.toolPoints[t.i].yield)), t];
	})).values()];
}
function Ht(e, t) {
	let n = JSON.parse(t), r = Math.min(...n.map((t) => e.toolPoints[t.i].yield));
	for (let t of n) {
		let n = e.toolPoints[t.i];
		n.n -= t.n, n.kind === "chop" ? e.chop -= t.n : n.kind === "hardyDig" ? e.hardyDig -= t.n : e.dig -= t.n;
	}
	return e.toolPoints = e.toolPoints.filter((e) => e.n > 0), r;
}
function Ut(e, t, n = !1) {
	let r = [];
	for (let i of t.hand) Se[i.type].branches.forEach((a, o) => {
		(i.branch === null || i.branch === o) && a.forEach((a, s) => {
			i.used.includes(s) || n && a.kind !== "defense" || a.kind === "lowHeal" && t.hp > 2 || (a.kind !== "finisher" || X(e).every((e) => Math.floor(e.x / 3) === Math.floor(t.x / 3) && Math.floor(e.y / 5) === Math.floor(t.y / 5))) && (a.kind !== "copy" || a.a !== "other" || e.players.length !== 1) && (a.kind === "copy" && i.uid.startsWith("copy") || r.push(we(i.uid, o, s)));
		});
	}), !n && !i.uid.startsWith("copy") && !i.used.length && !t.flags.poison && r.push({
		kind: "ready",
		a: i.uid
	});
	return t.ready && !n && ft(t, "ap") && !t.ready.used.includes(-1) && r.push({
		kind: "readyAP",
		a: t.ready.uid,
		n: ft(t, "ap")
	}), r;
}
function Wt(e, t) {
	let n = e.enemies.filter((e) => L(t, e) && ["Life Crystal", "Fallen Star"].includes(e.name));
	if (n.length) return n.flatMap((e) => [{
		kind: "collect",
		a: e.uid,
		n: 0
	}, {
		kind: "collect",
		a: e.uid,
		n: 1
	}]);
	let r = [
		...Ut(e, t),
		...Bt(e, t),
		...Lt(e, t),
		...zt(e, t)
	];
	t.ready && r.push({ kind: "unready" }), He(e, t).length && r.push({ kind: "discover" });
	for (let n of e.world) for (let [i, a] of n.cells.entries()) {
		let o = {
			x: n.x * 3 + i % 3,
			y: n.y * 5 + Math.floor(i / 3)
		};
		if (L(t, o)) {
			if (a.startsWith("C") && t.ap > 0 && Ne(e, o) && r.push({
				kind: "chest",
				...o,
				n: +a[1]
			}), a.startsWith("T") && !e.acorns.some((e) => I(e, o)) && Ne(e, o)) for (let e of Vt(t, "chop", +a[1])) r.push({
				kind: "chop",
				...o,
				n: +a[1],
				b: e
			});
			let n = k[a];
			if (n && !e.enemies.some((e) => I(e, o))) for (let e of Vt(t, "dig", n.cost, n.hardy)) r.push({
				kind: "dig",
				...o,
				n: n.cost,
				b: e
			});
			a === "Altar" && it(t, "lens") && !e.triggered.includes("eye") && r.push({
				kind: "summonEye",
				...o
			}), !H(e, o) && t.platforms && !e.platforms.some((e) => I(e, o)) && r.push({
				kind: "platform",
				...o
			}), !I(t, o) && Me(e, o) && !W(e, o) && !Ae(e, o) && (t.ropes && !e.ropes.some((e) => I(e, o)) && r.push({
				kind: "rope",
				...o
			}), e.npcs.length >= 2 && t.coins >= 10 && e.pylons.length < e.npcs.length && !e.pylons.some((t) => V(e, t) === V(e, o)) && r.push({
				kind: "pylon",
				...o
			}));
		}
	}
	for (let e of ["axe", "pickaxe"]) {
		let n = t.equipped[e], i = w(n);
		i && t.ap >= i.cost && r.push({
			kind: "tool",
			a: n
		});
	}
	for (let n of Object.values(t.equipped)) {
		if (!n) continue;
		let i = w(n);
		i.dice.length && (i.mana ? t.mana >= i.cost : t.ap >= i.cost) && Yt(e, t, i.ranges, i.sightless).length && r.push({
			kind: "weapon",
			a: n
		}), xe[n] && t.mana >= i.cost && t.minion !== n && r.push({
			kind: "minion",
			a: n
		});
	}
	for (let n of [...new Set(t.consumables)]) n === "c20" && (t.y < 20 || !z(t).concat([t]).some((t) => B(e, t) === "L") || e.triggered.includes("wall")) || (!["c2", "c3"].includes(n) || Yt(e, t, ["short", "medium"]).length) && r.push({
		kind: "consumable",
		a: n
	});
	for (let n of e.enemies) L(t, n) && ["Life Crystal", "Fallen Star"].includes(n.name) && r.push({
		kind: "collect",
		a: n.uid,
		n: 0
	}, {
		kind: "collect",
		a: n.uid,
		n: 1
	});
	if (t.inventory.length < 6 && t.coins >= (t.inventory.length === 4 ? 15 : 25) && r.push({ kind: "unlock" }), e.pylons.some((e) => L(t, e)) && t.ap >= 4 && !e.boss) for (let n of e.pylons) !W(e, n) && !I(t, n) && r.push({
		kind: "travel",
		...n
	});
	e.players.length > 1 && (t.ap > 0 || e.globalFlags.freeDonate) && r.push({ kind: "donate" });
	for (let t of e.objectives) sn(e, t.id) && r.push({
		kind: "objective",
		a: t.id
	});
	if (e.config.focus && !e.globalFlags.focusTarget) for (let t of e.objectives) r.push({
		kind: "focus",
		a: t.id
	});
	return r.push({ kind: t.ended ? "resume" : "end" }), r;
}
function Gt(e, t) {
	let n = e.people[t];
	return !n || e.result ? [] : e.pending ? e.pending.who === "*" || e.pending.who === t ? e.pending.options : [] : e.battle ? tn(e, t) : e.queue.length ? [] : e.phase === "prepare" ? e.config.focus && !e.globalFlags.focusTarget ? e.objectives.map((e) => ({
		kind: "focus",
		a: e.id
	})) : n.prepared ? [] : n.dead ? un(e, n) : [
		{ kind: "prepared" },
		...n.equipment.filter((e) => n.equipped[w(e).slot] !== e).map((e) => ({
			kind: "equip",
			a: e
		})),
		...n.armors.filter((e) => n.armor !== e).map((e) => ({
			kind: "armor",
			a: e
		}))
	] : e.phase === "character" ? n.ended ? [{ kind: "resume" }] : n.dead ? [{ kind: "end" }] : Wt(e, n) : e.phase === "enemy" ? e.enemyTodo.map((e) => ({
		kind: "activate",
		a: e
	})) : [];
}
var Kt = (e, t) => Gt(e, t).map((t, n) => ({
	...t,
	id: e.serial + ":" + n,
	group: qt(t.kind)
}));
function qt(e) {
	return [
		"card",
		"ready",
		"unready",
		"cardEffect"
	].includes(e) ? "cards" : [
		"move",
		"ropeMove",
		"hook",
		"travel",
		"discover"
	].includes(e) ? "move" : [
		"dig",
		"tool",
		"chop",
		"chest",
		"collect"
	].includes(e) ? "gather" : [
		"weapon",
		"consumable",
		"minion",
		"summonEye"
	].includes(e) ? "fight" : [
		"craft",
		"craftToken",
		"house",
		"platform",
		"rope",
		"pylon",
		"nightsEdge"
	].includes(e) ? "build" : [
		"end",
		"resume",
		"objective",
		"focus",
		"prepared",
		"equip",
		"armor"
	].includes(e) ? "progress" : "other";
}
function Jt(e, t) {
	if (t === "boss" || t.startsWith("ally:")) return U(e);
	if (t.startsWith("eye:") && e.boss) {
		let n = e.boss;
		return [{
			x: n.x + 1,
			y: n.y - (t === "eye:0" ? 3 : 1)
		}];
	}
	if (t === "mouth" && e.boss) return [{
		x: e.boss.x + 1,
		y: e.boss.y - 2
	}];
	if (t.startsWith("icon:")) {
		let [, e, n] = t.split(":");
		return [{
			x: +e,
			y: +n
		}];
	}
	let n = Z(e, t);
	return n ? [n] : [];
}
function Yt(e, t, n, r = !1) {
	let i = e.enemies.filter((e) => E(e.name)).map((e) => e.uid);
	e.boss && !e.boss.transformed && (e.boss.id === "wall" ? e.boss.form === 0 ? e.boss.eyes.forEach((e, t) => {
		e > 0 && i.push("eye:" + t);
	}) : i.push("mouth") : e.boss.id === "brain" && e.boss.form === 0 ? i.push(...e.boss.buffs.map((e) => "ally:" + e)) : i.push("boss"));
	for (let t of e.world) for (let [e, n] of t.cells.entries()) [
		"Orb4",
		"Heart4",
		"Larva"
	].includes(n) && i.push(`icon:${t.x * 3 + e % 3}:${t.y * 5 + Math.floor(e / 3)}`);
	return i.filter((i) => Jt(e, i).some((i) => Re(t, i, n) >= 0 && Le(e, t, i, r)));
}
function Xt(e, t) {
	if (t.startsWith("icon:")) return [4];
	let n = Z(e, t);
	if (n) return [...E(n.name)?.defense ?? [4]];
	if (!e.boss) return [4];
	let r = e.boss;
	if (t.startsWith("ally:")) return Number(t.slice(5)) % 2 == 0 ? [6, 6] : [6, 8];
	let i = r.id === "kingSlime" ? [6, 6] : r.id === "eye" ? r.form === 0 ? [6, 8] : [8] : r.id === "eater" ? [8, 8] : r.id === "brain" ? r.form === 0 ? r.buffs[0] % 2 == 0 ? [6, 6] : [6, 8] : [8, 8] : r.id === "queenBee" ? [6, 4] : r.form === 0 ? [8, 12] : [12, 12];
	return r.id === "kingSlime" && r.buffs.includes(1) && (i = [...i, 4]), i;
}
function Zt(e, t, n, r, i = "") {
	let a = [...r], o = (n) => e.globalFlags[t + ":" + n];
	for (let e of ["Small", "Large"]) for (let t = 0; t < (o("enemy" + e + n + "Demote") ?? 0); t++) {
		let t = e === "Small" ? Math.min(...a) : Math.max(...a), n = a.indexOf(t);
		a[n] = be(t);
	}
	for (let e = 0; e < (o("enemyRemove" + n) ?? 0) && a.length > 1; e++) a.splice(a.indexOf(Math.min(...a)), 1);
	if (n === "Defense" && ["e25", "e26"].includes(i) && a.length > 1 && a.splice(a.indexOf(Math.min(...a)), 1), n === "Defense" && i === "e27") {
		let e = a.indexOf(Math.max(...a));
		a[e] = be(a[e]);
	}
	let s = Z(e, t);
	if (n === "Defense" && s && e.globalFlags["inferno:" + Math.floor(s.x / 3) + ":" + Math.floor(s.y / 5)]) {
		let e = a.indexOf(Math.max(...a));
		a[e] = be(a[e]);
	}
	return a;
}
function Qt(e, t, n, r, i, a, o = !1, s = 0, c = !1) {
	let l = Jt(e, r).filter((n) => Le(e, t, n, c)).map((e) => Re(t, e, a)).filter((e) => e >= 0), u = Zt(e, r, "Defense", Xt(e, r), n);
	e.battle = {
		rid: t.rid,
		targets: [r],
		dice: [...i],
		rolled: [],
		defense: u,
		defended: [],
		prevent: o || !!xe[t.minion]?.prevent,
		stage: s > 0 ? "pierce" : "attackDice",
		enemyAttack: !1,
		debuff: "",
		kind: "attack",
		source: n,
		mods: [],
		boosted: -1,
		shielded: -1,
		drop: Math.min(...l),
		retaliations: [],
		friends: []
	}, s > 0 && (e.globalFlags.pierce = s + 1, e.battle.stage = "pierceOrigin", K(e, t.rid, "attackTarget", Jt(e, r).filter((n) => Le(e, t, n, c) && Re(t, n, a) >= 0).map((e) => ({
		kind: "pierceOrigin",
		...e
	}))));
}
function $t(e, t, n) {
	if (n.dead) return null;
	let r = Z(e, t);
	if (r) {
		if (n.flags.invisible) return null;
		let t = E(r.name);
		if (!t) return null;
		let i = Re(r, n, t.ranges.split(" "), !0);
		if (i < 0 || !Le(e, r, n, r.name === "Fire Imp")) return null;
		let a = Zt(e, r.uid, "Attack", [...t.attack]);
		return a = a.sort((e, t) => e - t).slice(i), a.length ? {
			dice: a,
			debuff: t.debuff
		} : null;
	}
	if (!e.boss || ![
		"boss",
		"mouth",
		"eye:0",
		"eye:1"
	].includes(t) && !t.startsWith("ally:")) return null;
	let i = e.boss, a = i.id === "eater" && i.behavior === 0 ? ["short", "medium"] : i.id === "queenBee" && i.behavior === 1 ? ["long"] : ["short"], o = U(e), s = Math.min(...o.filter((t) => Le(e, t, n, i.id === "eater")).map((e) => Re(e, n, a, !0)).filter((e) => e >= 0));
	if (!Number.isFinite(s)) return null;
	let c = i.id === "kingSlime" ? i.behavior === 0 ? [
		6,
		6,
		4
	] : [6, 6] : i.id === "eye" || i.id === "brain" || i.id === "eater" ? i.behavior === 0 ? [
		6,
		6,
		6
	] : [
		6,
		6,
		8
	] : i.id === "queenBee" ? i.behavior === 0 ? [6, 8] : [6] : [20, 20];
	if (i.id === "kingSlime" && i.buffs.includes(3) && (c = [...c, 6]), i.id === "eye" && i.buffs.includes(3)) {
		c = [...c];
		let e = c.indexOf(Math.max(...c));
		c[e] = A(c[e]);
	}
	return i.id === "queenBee" && (c = [...c, ...i.buffs.filter((e) => e >= 2).map(() => 6)]), {
		dice: c.sort((e, t) => e - t).slice(s),
		debuff: i.id === "queenBee" && i.behavior === 1 ? "poison" : ""
	};
}
function en(e, t, n, r, i = "", a) {
	e.battle = {
		rid: t.rid,
		targets: [n],
		dice: [...r],
		rolled: a === void 0 ? [] : [a],
		defense: pt(t),
		defended: [],
		prevent: !1,
		stage: "defenseDice",
		enemyAttack: !0,
		debuff: i,
		kind: "defense",
		source: n,
		mods: [],
		boosted: -1,
		shielded: -1,
		drop: 0,
		retaliations: [],
		friends: []
	};
}
function tn(e, t) {
	let n = e.battle;
	if (n.rid !== t) return [];
	let r = e.people[t], i = [];
	if (n.stage === "pierce") {
		i.push({ kind: "finishTargets" });
		let t = n.piercePoints ?? n.targets.flatMap((t) => Jt(e, t)), a = t[0], o = (e) => ["boss", "mouth"].includes(e) || e.startsWith("eye:") || e.startsWith("ally:"), s = e.enemies.filter((e) => E(e.name)).map((e) => e.uid);
		if (e.boss && !e.boss.transformed && !n.targets.some(o) && (e.boss.id === "wall" ? s.push(...e.boss.form === 0 ? e.boss.eyes.flatMap((e, t) => e > 0 ? ["eye:" + t] : []) : ["mouth"]) : e.boss.id === "brain" && e.boss.form === 0 ? s.push(...e.boss.buffs.map((e) => "ally:" + e)) : s.push("boss")), n.targets.length < (e.globalFlags.pierce ?? 0)) {
			for (let o of s) if (!n.targets.includes(o)) for (let n of Jt(e, o)) !t.some((e) => I(n, e)) && t.some((e) => L(n, e)) && R(r, n) + 1e-8 >= R(r, a) && Te([...t, n]) && i.push({
				kind: "pierceTarget",
				a: o,
				...n
			});
		}
		return i;
	}
	if (n.drop > 0) return n.dice.map((e, t) => ({
		kind: "dropDie",
		n: t,
		a: String(e)
	}));
	let a = n.enemyAttack;
	if (n.stage === "attackDice" || n.stage === "defenseDice") {
		let t = a ? n.defense : n.dice, o = a ? ["duplicateDefense", "promoteDefense"] : ["duplicateAttack", "promoteAttack"];
		for (let e of o) r.flags[e] > n.mods.filter((t) => t === e).length && i.push({
			kind: "modifyDie",
			a: e
		});
		if (!a) {
			let e = n.source.startsWith("e") ? w(n.source) : void 0;
			e?.ranges.includes("long") && r.armor === "r16" && !n.mods.includes("necro") && i.push({
				kind: "modifyDie",
				a: "necro"
			}), e?.ranges.includes("long") && r.flags.archery && !n.mods.includes("archery") && i.push({
				kind: "modifyDie",
				a: "archery"
			}), e?.mana && r.flags.magic && !n.mods.includes("magic") && i.push({
				kind: "modifyDie",
				a: "magic"
			});
		}
		return e.dryad && !n.mods.includes("dryad") && i.push({
			kind: "modifyDie",
			a: "dryad"
		}), t.length && i.push({ kind: "roll" }), i;
	}
	if (n.stage === "modify") {
		let t = a ? n.defended : n.rolled, o = a ? r.defense + Math.max(0, ft(r, "defense") - (r.ready?.used.filter((e) => e === -2).length ?? 0)) : r.attack + Math.max(0, ft(r, "attack") - (r.ready?.used.filter((e) => e === -3).length ?? 0)), s = a ? n.shielded : n.boosted;
		if (o > 0) {
			for (let e = 0; e < t.length; e++) if (s < 0 || s === e) for (let t = 1; t <= o; t++) i.push({
				kind: "boost",
				a: String(e),
				n: t
			});
		}
		if (!a && r.armor === "r19" && !r.flags.ninja && t.forEach((e, t) => i.push({
			kind: "reroll",
			a: "ninja",
			n: t
		})), a && r.flags.defenseReroll && !r.flags.defenseRerolled) {
			let e = Math.min(...t);
			t.forEach((t, n) => {
				t === e && i.push({
					kind: "reroll",
					a: "defense",
					n
				});
			});
		}
		if (a && r.flags.enemyAttackReroll && !r.flags.enemyAttackRerolled) {
			let e = Math.max(...n.rolled);
			n.rolled.forEach((t, n) => {
				t === e && i.push({
					kind: "reroll",
					a: "enemyAttack",
					n
				});
			});
		}
		if (!a && r.flags.enemyDefenseReroll && !r.flags.enemyDefenseRerolled) {
			let e = Math.max(...n.defended);
			n.defended.forEach((t, n) => {
				t === e && i.push({
					kind: "reroll",
					a: "enemyDefense",
					n
				});
			});
		}
		a && i.push(...Ut(e, r, !0)), i.push({ kind: "resolveBattle" });
	}
	return i;
}
function nn(e, t) {
	let n = e.people[t.rid], r = t.targets[0], i = Math.max(...t.defended), a = n.flags.battleAttackSpent ?? 0, o = t.rolled.filter((e) => e >= i).length;
	if (q(e, "fight", n.rid, r, o), r.startsWith("icon:")) {
		if (o > 0) {
			let t = Jt(e, r)[0], n = B(e, t), i = n === "Larva" ? "queenBee" : n === "Orb4" ? "eater" : "brain";
			e.triggered.includes(i) || (e.bossQueue.push({
				id: i,
				...t
			}), e.triggered.push(i));
		}
	} else if (Z(e, r)) {
		let i = Z(e, r);
		i.hp -= o, i.hp <= 0 && (rn(e, n, i, t.source), e.battle = null);
	} else if (e.boss && o > 0) {
		let t = e.boss;
		if (t.id === "brain" && t.form === 0) t.buffs = t.buffs.filter((e) => "ally:" + e !== r), t.buffs.length || an(e);
		else if (r.startsWith("eye:")) {
			let n = +r.split(":")[1];
			t.eyes[n] = Math.max(0, t.eyes[n] - o), t.eyes.every((e) => e <= 0) && an(e);
		} else t.hp -= o, t.hp <= 0 && (t.form === 0 ? an(e) : on(e, n));
	}
	n.flags.battleAttackSpent = a;
	let s = t.targets.slice(1), c = !t.prevent && o >= 0 && (Z(e, r) || e.boss && !e.boss.transformed && !r.startsWith("icon:")) && $t(e, r, n);
	e.battle = null, c && t.retaliations.push({
		id: r,
		n: i,
		debuff: c.debuff
	}), s.length ? G(e, {
		kind: "pierceNext",
		who: n.rid,
		a: JSON.stringify({
			...t,
			targets: s,
			stage: "modify",
			defense: [],
			defended: []
		})
	}) : (t.retaliations.length && G(e, {
		kind: "retaliationOrder",
		who: n.rid,
		a: JSON.stringify(t.retaliations)
	}), G(e, ...t.friends.map((e) => ({
		kind: "blastFriend",
		who: e,
		a: JSON.stringify(t.rolled),
		b: JSON.stringify(t.dice)
	}))));
}
function rn(e, t, n, r) {
	let i = E(n.name);
	e.enemies = e.enemies.filter((e) => e.uid !== n.uid), e.bags[n.bag].push(n.name);
	let a = t.flags.shakedown ? 2 : 1;
	ct(t, i.coins * a);
	for (let [n, r] of Object.entries(i.resources)) G(e, Y(t.rid, n, r * a));
	if (i.lootLevel) for (let n = 0; n < a; n++) G(e, {
		kind: "loot",
		who: t.rid,
		n: i.lootLevel
	});
	n.name === "Voodoo Demon" && G(e, ut(t.rid, "c20")), t.flags.regenKill && (t.hp = Math.min(t.maxHp, t.hp + 1)), J(e, "kill"), J(e, "kill:" + n.name), n.name.includes("Slime") && J(e, "slimes"), n.name === "Voodoo Demon" && J(e, "voodoo"), e.turnStats["type:" + n.name] = 1, r.startsWith("e") && w(r).name.includes("Staff") ? J(e, "staffKills") : J(e, "nonStaffKills"), q(e, "defeat", t.rid, n.name), Et(e);
}
function an(e) {
	let t = e.boss;
	t.form = 1, t.transformed = !0, t.hp = t.id === "kingSlime" ? 2 : t.id === "eater" || t.id === "brain" ? 6 : 4, q(e, "transform", "", t.id), G(e, { kind: "displace" });
}
function on(e, t) {
	let n = e.boss;
	if (e.defeated.push(n.id), J(e, "boss:" + n.id), n.cheap && J(e, "cheapBoss"), q(e, "defeat", t.rid, n.id), e.boss = null, n.id === "wall") {
		e.phase = "done", e.result = "win", e.queue = [];
		return;
	}
	vt(e, n.id === "eater" || n.id === "brain" ? -2 : n.id === "eye" || n.id === "queenBee" ? -1 : 0);
	for (let t of e.players) G(e, {
		kind: "scrapOffer",
		who: t,
		n: 1,
		a: "all"
	}), ["eater", "brain"].includes(n.id) && G(e, {
		kind: "evilLoot",
		who: t
	});
	n.id === "kingSlime" && G(e, {
		kind: "shareItem",
		a: "r19",
		n: 1
	}, {
		kind: "shareItem",
		a: "c14",
		n: 2
	}, {
		kind: "shareItem",
		a: "c0",
		n: 2
	}, {
		kind: "coinOrThreat",
		n: e.players.length <= 2 ? 15 : 30,
		a: "2"
	}), n.id === "eye" && G(e, {
		kind: "shareResource",
		a: e.config.evil === "crimson" ? "crimtane" : "demonite",
		n: e.players.length <= 2 ? 2 : 3
	}, {
		kind: "shareItem",
		a: "c0",
		n: 4
	}, {
		kind: "coinOrThreat",
		n: e.players.length <= 2 ? 20 : 40,
		a: "1"
	}), (n.id === "brain" || n.id === "eater") && G(e, {
		kind: "shareResource",
		a: n.id === "brain" ? "crimtane" : "demonite",
		n: e.players.length <= 2 ? 4 : 6
	}, {
		kind: "shareItem",
		a: "c0",
		n: 4
	}, {
		kind: "coinOrThreat",
		n: e.players.length <= 2 ? 20 : 40,
		a: "1"
	}), n.id === "queenBee" && G(e, {
		kind: "shareItem",
		a: "e38",
		n: 1
	}, {
		kind: "shareItem",
		a: "e37",
		n: 1
	}, {
		kind: "shareItem",
		a: "e39",
		n: 1
	}, {
		kind: "beeLoot",
		n: e.players.length <= 2 ? 2 : 4
	});
}
function sn(e, t) {
	let n = +t.slice(1);
	D(t);
	let r = (n) => e.stats[t + ":" + n] ?? 0, i = (t) => e.stats[t] ?? 0, a = (t) => lt(e, t), o = e.players.length <= 2, s = Object.values(e.people);
	switch (n) {
		case 0: return r("dig") > 0;
		case 1: return [
			"copper",
			"iron",
			"silver",
			"gold"
		].some((e) => r("dig:" + e) > 0);
		case 2: return r("web") > 0;
		case 3: return i("craft:pickaxe") > 0;
		case 4: return r("dig:gem") > 0;
		case 5: return r("explosiveDig") > 0;
		case 6: return r("dig:demonite") + r("dig:crimtane") > 0;
		case 7: return e.world.some((e) => ge(e.id).cells.some((e) => k[e]) && !e.cells.some((e) => k[e]));
		case 8: return Array.from({ length: 50 }, (e, t) => t).some((t) => Array.from({ length: 25 }, (e, t) => t).every((n) => Me(e, {
			x: t,
			y: n
		}) && Me(e, {
			x: t + 1,
			y: n
		})));
		case 9: return i("dig:hellstone") >= (o ? 6 : 8);
		case 10: return r("chop") > 0;
		case 11: return a("workbench");
		case 12: return a("anvil");
		case 13: return i("craft:axe") > 0;
		case 14: return e.houses.some((e) => e.cells.every((e) => e.y >= 5));
		case 15: return a("loom") || a("bottle");
		case 16: return a("bed") || a("cookingPot");
		case 17: return new Set(e.houses.map((t) => V(e, t))).size >= 3 || e.biomeOrder.some((t) => e.houses.filter((n) => V(e, n) === t).length >= 4);
		case 18: return a("hellforge");
		case 19: return Object.keys(_e).every(a);
		case 20: return r("kill") > 0;
		case 21: return i("craft:r8") > 0;
		case 22: return i("craft:sword") > 0;
		case 23: return e.day >= 2;
		case 24: return e.defeated.includes("kingSlime");
		case 25: return s.some((e) => e.equipped.other && w(e.equipped.other).mana);
		case 26: return e.defeated.some((e) => e === "queenBee" || e === "eye");
		case 27: return Object.keys(e.turnStats).filter((e) => e.startsWith("type:")).length >= (o ? 3 : 4);
		case 28: return e.defeated.some((e) => e === "brain" || e === "eater");
		case 29: return i("voodoo") > 0;
		case 30: return r("discovered") >= 2;
		case 31: return r("nonForestChest") > 0;
		case 32: return r("deepChest") > 0;
		case 33: return e.npcs.length >= 3;
		case 34: return e.world.filter((t) => t.biome === e.config.evil).length >= 3;
		case 35: return i("ocean") > 0;
		case 36: return i("hive") > 0;
		case 37: return i("underworldSeen") > 0;
		case 38: return new Set(e.world.filter((e) => e.y === 0 && e.biome !== "beach").map((e) => e.biome)).size >= 5;
		case 39: return e.pylons.length >= (o ? 4 : 5);
		case 40: return i("lifeCrystal") > 0;
		case 41: return r("fall8") > 0;
		case 42: return i("underworldChest") >= (o ? 2 : 3);
		case 43: return s.some((e) => e.flags.startLayer === 4 && e.y < 5 && !e.flags.pylon);
		case 44: return s.filter((e) => e.armor === "r12").length >= (o ? 1 : 2);
		case 45: {
			let t = (e, t) => e.cells.some((e) => t.cells.some((t) => e.x === t.x && e.y + 1 === t.y));
			return e.houses.some((n) => e.houses.some((r) => n !== r && t(n, r) && e.houses.some((e) => e !== n && e !== r && t(r, e))));
		}
		case 46: return s.filter((e) => e.inventory.length === 6 && e.inventory.every((e) => e.n === 5)).length >= (o ? 1 : 2);
		case 47: return e.time >= 5 && X(e).length === s.length && s.every((t) => Ae(e, t)?.type === "bed");
		case 48: return s.some((e) => [
			"e28",
			"e29",
			"e30",
			"e48",
			"e49"
		].includes(e.equipped.other));
		case 49: return (e.turnStats.staffKills ?? 0) >= (o ? 2 : 4) && !e.turnStats.nonStaffKills;
		case 50: return s.every((e) => e.minion);
		case 51: return i("cheapBoss") > 0;
		case 52: return i("fallenStar") > 0;
		case 53: return (e.stats.thisNightSpawns ?? 0) >= (o ? 4 : 6);
		case 54: return (e.turnStats.spent ?? 0) >= (o ? 40 : 50);
		case 55: return s.some((e) => e.flags.startLayer === 0 && e.y >= 20 && !e.flags.pylon);
		default: return !1;
	}
}
function cn(e, t, n = !1) {
	let r = D(t), i = e.objectives.find((e) => e.id === t);
	if (!i) return;
	e.globalFlags.focusTarget === +t.slice(1) + 1 && (e.globalFlags.focusTarget = 0), n || (e.completed.push(t), vt(e, -r.threat), ln(e, +t.slice(1)), q(e, "objective", "", t));
	let a = e.config.difficulty === "journey" ? 6 : 10;
	if (i.level >= a) e.stats["chain:" + r.chain] = 1, e.objectives = e.objectives.filter((e) => e !== i);
	else {
		i.level++, i.focus = 0;
		let t = fe.find((e) => e.chain === r.chain && e.level === i.level && +e.id.slice(1) < 40);
		e.config.alternatives && [
			5,
			6,
			8,
			10
		].includes(i.level) && et(e, 2) === 1 && (t = fe.find((e) => e.chain === r.chain && e.level === i.level && +e.id.slice(1) >= 40)), i.id = t.id;
	}
	let o = e.config.difficulty === "heroic" ? 3 : e.config.difficulty === "tough" ? 2 : 1;
	Object.keys(e.stats).filter((t) => t.startsWith("chain:") && e.stats[t]).length >= o && (e.phase = "done", e.result = "win", e.queue = [], e.pending = null, e.battle = null);
}
function ln(e, t) {
	let n = e.players.length <= 2, r = (t) => e.players.map((e) => ({
		...t,
		who: e
	})), i = (e, t) => ({
		kind: "shareResource",
		a: e,
		n: t
	}), a = () => r({
		kind: "scrapOffer",
		n: 1,
		a: "all"
	}), o = (e, t = 1) => r({
		kind: "randomConsumable",
		n: e,
		b: String(t)
	}), s = [];
	if ([
		0,
		10,
		20,
		30
	].includes(t)) s = r({
		kind: "coins",
		n: n ? 2 : 1
	});
	else if (t === 1) s = [{
		kind: "oreReward",
		n: 2
	}];
	else if (t === 2) s = r(Y("", "iron", n ? 2 : 1));
	else if (t === 3) s = [{
		kind: "pickaxeOre",
		n: 2
	}];
	else if ([
		4,
		14,
		33
	].includes(t)) s = o(2, n ? 2 : 1);
	else if ([
		5,
		15,
		41,
		45
	].includes(t)) s = [{
		kind: "coinOrThreat",
		n: 6,
		a: "1"
	}];
	else if (t === 6) s = [i(e.config.evil === "crimson" ? "crimtane" : "demonite", 2)];
	else if ([
		7,
		17,
		27,
		37,
		42,
		46,
		50,
		54
	].includes(t)) s = o(3);
	else if ([
		8,
		34,
		38,
		52
	].includes(t)) s = a();
	else if (t === 11) s = r({
		kind: "platformAward",
		n: n ? 2 : 1
	});
	else if (t === 12) s = r(ut("", "a0"));
	else if ([13, 22].includes(t)) s = [{
		kind: "shareCoins",
		n: 4
	}];
	else if (t === 16) s = [{
		kind: "shareHealth",
		n: 4
	}];
	else if (t === 18) s = [i("hellstone", 2)];
	else if (t === 21) s = r({
		kind: "woodOrCoins",
		n: n ? 2 : 1,
		b: n ? "4" : "3"
	});
	else if (t === 23) s = [...a(), i("lens", 1)];
	else if (t === 24) s = r({
		kind: "loot",
		n: 2
	});
	else if (t === 25) s = o(2, 2);
	else if (t === 26) s = r({
		kind: "loot",
		n: 3
	});
	else if (t === 28) s = r({
		kind: "loot",
		n: 4
	});
	else if ([
		31,
		35,
		53
	].includes(t)) s = r(ut("", "a1"));
	else if (t === 32) s = [...r({
		kind: "ropeOrPlatform",
		n: n ? 2 : 1,
		b: n ? "3" : "2"
	}), {
		kind: "shareItem",
		a: "c6",
		n: 1
	}];
	else if (t === 36) s = [{
		kind: "shareCoins",
		n: 6
	}];
	else if (t === 40 || t === 44) s = o(2, 2);
	else if (t === 48) {
		for (let t of Object.values(e.people)) t.flags.discount = 5;
		s = [i("cobweb", 2)];
	} else t === 49 && (s = r({ kind: "magicOrMana" }));
	G(e, ...s);
}
function un(e, t) {
	return e.world.filter((e) => e.biome === "forest" && e.y === 0).flatMap((e) => e.cells.flatMap((t, n) => k[t] ? [] : [{
		x: e.x * 3 + n % 3,
		y: Math.floor(n / 3)
	}])).concat(e.houses.filter((e) => e.type === "bed").flatMap((e) => e.cells)).filter((t) => !W(e, t)).map((e) => ({
		kind: "respawn",
		...e,
		who: t.rid
	}));
}
function dn(e, t) {
	for (let e of Object.keys(t.debuffs)) mt(t, e) && delete t.debuffs[e];
	let n = !!t.debuffs.frozen, r = !!t.debuffs.poison;
	if (t.debuffs.fire && St(e, t, 2), t.dead) {
		t.prepared = !0;
		return;
	}
	t.flags = {
		startLayer: Math.floor(t.y / 5),
		poison: +!!r
	}, r && t.ready && (t.discard.push(t.ready), t.ready = null, t.stockpile = {
		resource: "",
		n: 0
	});
	for (let e of Object.keys(t.debuffs)) t.debuffs[e]--, t.debuffs[e] <= 0 && delete t.debuffs[e];
	t.ap = dt(t)?.ap ?? 0, t.toolPoints = [], t.attack = (xe[t.minion]?.attack ?? 0) + (t.minion && t.armor === "r20" ? 1 : 0), t.minion && (t.flags["minion:" + t.minion] = 1), t.defense = 0, t.dig = t.armor === "r24" ? 2 : 0, t.dig && t.toolPoints.push({
		kind: "dig",
		n: t.dig,
		yield: 1
	}), t.hardyDig = 0, t.chop = 0, t.mana = Math.min(t.maxMana, t.mana + (dt(t)?.mana ?? 0)), yt(e, t, Math.max(0, (dt(t)?.draw ?? 4) - +!!n)), t.prepared = !0;
}
function fn(e) {
	for (let t of X(e)) B(e, t) === "L" && bt(e, t, "fire"), Tt(e, t, !0, !1), t.ap = 0, t.dig = 0, t.hardyDig = 0, t.chop = 0, t.toolPoints = [];
	e.phase = "enemy", e.enemyTodo = e.enemies.filter((t) => E(t.name) && Ue(e, t)).map((e) => e.uid), !e.boss && e.bossQueue.length ? G(e, { kind: "spawnBoss" }) : e.boss ? G(e, { kind: "bossStart" }) : e.enemyTodo.length || G(e, { kind: "environment" });
}
function pn(e) {
	let t = X(e).filter((t) => He(e, t).length);
	if (t.length) {
		K(e, "*", "discover", t.map((e) => ({
			kind: "discover",
			who: e.rid
		}))), G(e, { kind: "endCheck" });
		return;
	}
	let n = e.objectives.filter((t) => sn(e, t.id));
	if (n.length) {
		K(e, "*", "objectives", n.map((t) => ({
			kind: "objective",
			a: t.id,
			who: e.players[0]
		}))), G(e, { kind: "endCheck" });
		return;
	}
	(e.stats.slimes ?? 0) >= 5 && !e.triggered.includes("kingSlime") && (e.triggered.push("kingSlime"), e.bossQueue.push({
		id: "kingSlime",
		x: 25,
		y: 4
	}));
	let r = e.globalFlags.focusTarget;
	if (r) {
		let t = e.objectives.find((e) => e.id === "o" + (r - 1));
		t && (t.focus++, t.focus >= 2 && (vt(e, _t(e)), e.globalFlags.focusTarget = 0, t.focus = 0));
	}
	e.result || fn(e);
}
function mn(e) {
	e.phase = "environment", e.boss && (e.boss.behavior = 1 - e.boss.behavior, e.boss.id === "eye" && e.boss.behavior === 0 && e.time < 5 && (q(e, "escape", "", "eye"), e.boss = null, e.triggered = e.triggered.filter((e) => e !== "eye")));
	for (let t of Object.values(e.people)) {
		t.discard.push(...t.hand.filter((e) => !e.uid.startsWith("copy")), ...t.played.filter((e) => !e.uid.startsWith("copy"))), t.hand = [], t.played = [];
		for (let e of t.discard) e.used = [], e.branch = null;
	}
	G(e, { kind: "advanceTime" });
}
function hn(e) {
	e.round++, e.phase = "prepare", e.turnStats = {}, e.globalFlags = { focusTarget: e.globalFlags.focusTarget ?? 0 }, e.boss && (e.boss.transformed = !1);
	for (let t of Object.values(e.people)) t.ended = !1, t.prepared = !1, t.flags = {}, t.ap = 0, t.attack = 0, t.defense = 0, t.ready && (t.ready.used = [], t.ready.branch = null);
	if (X(e).length === 0) for (let t of Object.values(e.people)) t.hp = t.maxHp, t.mana = t.maxMana;
	q(e, "round", "", "", e.round);
}
function gn(e, t, n, r, i, a = !1, o = !1) {
	let s = /* @__PURE__ */ new Map(), c = [{
		x: t.x,
		y: t.y
	}];
	s.set(t.x + ":" + t.y, {
		x: t.x,
		y: t.y
	});
	let l = (t) => {
		if (B(e, t) === "unknown") return !1;
		if (a && e.boss) {
			let n = je({
				...e.boss,
				...t
			});
			return n.rows.every((r, a) => [...r].every((r, o) => r !== "#" || (() => {
				let r = {
					x: t.x + o - n.anchor[0],
					y: t.y + a - n.anchor[1]
				};
				return B(e, r) !== "unknown" && (i === "ghost" || !H(e, r));
			})()));
		}
		return (i === "worm" || i === "ghost" || !H(e, t)) && !Ae(e, t);
	};
	for (let n = 0; n < r && c.length; n++) {
		let n = [];
		for (let r of c) for (let o of z(r)) {
			let c = { ...o };
			if (!l(c) || i !== "worm" && i !== "ghost" && Ie(e, r, c)) continue;
			if (i === "walk") {
				let n = (n) => a && e.boss ? U({
					...e,
					boss: {
						...e.boss,
						...n
					}
				}).some((t) => {
					let r = {
						x: t.x,
						y: t.y + 1
					};
					return !U({
						...e,
						boss: {
							...e.boss,
							...n
						}
					}).some((e) => I(e, r)) && Fe(e, t, "boss");
				}) : Fe(e, n, "uid" in t ? String(t.uid) : "");
				for (; c.y < 24 && !n(c) && l({
					x: c.x,
					y: c.y + 1
				});) c.y++;
			}
			let u = c.x + ":" + c.y;
			s.has(u) || (s.set(u, c), n.push(c));
		}
		c = n;
	}
	let u = [...s.values()].filter((n) => a || !W(e, n, "uid" in t ? String(t.uid) : ""));
	if (o) return u;
	let d = (t) => a && e.boss ? Math.min(...U({
		...e,
		boss: {
			...e.boss,
			...t
		}
	}).map((e) => R(e, n))) : R(t, n), f = Math.min(...u.map(d));
	return u.filter((e) => Math.abs(d(e) - f) < 1e-8);
}
function _n(e, t) {
	let n = Z(e, t);
	if (!n) {
		yn(e);
		return;
	}
	let r = X(e).filter((e) => !e.flags.invisible), i = Math.min(...r.map((e) => R(n, e))), a = r.filter((e) => Math.abs(R(n, e) - i) < 1e-8);
	if (!a.length) {
		yn(e);
		return;
	}
	K(e, "*", "enemyTarget", a.map((e) => ({
		kind: "enemyTarget",
		a: t,
		b: e.rid
	})));
}
function vn(e, t) {
	let n = X(e).filter((n) => (e.globalFlags[t + ":hit:" + n.rid] ?? 0) < (t === "boss" && e.boss?.id === "eye" && e.boss.behavior === 0 ? 1 + e.boss.buffs.filter((e) => e < 2).length : 1) && $t(e, t, n)).map((e) => ({
		kind: "enemyHit",
		a: t,
		b: e.rid
	}));
	if (n.length) {
		K(e, "*", "enemyAttackOrder", n);
		return;
	}
	yn(e);
}
function yn(e) {
	e.enemyTodo.length || G(e, { kind: "environment" });
}
function bn(e) {
	let t = e.bossQueue.shift();
	if (!t) return;
	let n = t.id, r = e.players.length <= 2, i = n === "kingSlime" ? r ? 3 : 5 : n === "eater" ? r ? 4 : 6 : n === "brain" ? 0 : r ? 4 : 6;
	if (e.boss = {
		...t,
		form: 0,
		hp: i,
		eyes: n === "wall" ? [r ? 3 : 5, r ? 3 : 5] : [],
		buffs: n === "brain" ? r ? [0, 1] : [
			0,
			1,
			2,
			3
		] : [],
		behavior: 0,
		transformed: !1,
		born: e.round,
		cheap: Object.values(e.people).every((e) => !e.armor || ["r8", "r9"].includes(e.armor))
	}, n === "wall") {
		let t = e.world.filter((e) => e.y === 4).sort((e, t) => e.x - t.x);
		t.length && (e.boss.x = t[0].x * 3, e.boss.y = 24);
	}
	n === "eye" && (e.boss.x = 25, e.boss.y = 2), e.enemyTodo.push("boss"), q(e, "boss", "", n), G(e, { kind: "displace" });
}
function xn(e) {
	let t = e.boss;
	if (t) {
		if (e.enemyTodo.push("boss"), t.id !== "eater" && t.id !== "brain" && t.buffs.length < 4) {
			K(e, "*", "bossBuff", [
				0,
				1,
				2,
				3
			].filter((e) => !t.buffs.includes(e)).map((e) => ({
				kind: "bossBuff",
				n: e
			})));
			return;
		}
		G(e, { kind: "bossSpecial" });
	}
}
function Sn(e) {
	let t = U(e);
	e.platforms = e.platforms.filter((e) => !t.some((t) => I(t, e)));
	let n = t, r = [...X(e).map((e) => ({
		id: e.rid,
		p: e
	})), ...e.enemies.map((e) => ({
		id: e.uid,
		p: e
	}))].filter(({ p: e }) => n.some((t) => I(e, t)));
	r.length && K(e, "*", "displace", r.map((e) => ({
		kind: "displaceWho",
		a: e.id
	})));
}
function Cn(e) {
	let t = e.boss;
	if (!t) {
		yn(e);
		return;
	}
	if (!X(e).length) {
		yn(e);
		return;
	}
	if (t.id === "eater") {
		let t = X(e).filter((t) => V(e, t) === "corruption");
		if (!t.length) {
			e.boss = null, e.triggered = e.triggered.filter((e) => e !== "eater"), q(e, "escape", "", "eater"), yn(e);
			return;
		}
		K(e, "*", "enemyTarget", t.map((e) => ({
			kind: "wormTeleport",
			b: e.rid
		})));
		return;
	}
	if (t.id === "wall") {
		let n = (t.behavior === 0 ? 1 : 2) + t.buffs.filter((e) => e >= 2).length;
		G(e, ...Array.from({ length: n }, () => ({ kind: "wallStep" })), { kind: "bossAttacks" });
		return;
	}
	if (t.id === "kingSlime" && t.behavior === 0 && !e.globalFlags.kingTeleported && !X(e).some((n) => n.y < 5 && V(e, n) === V(e, t))) {
		e.globalFlags.kingTeleported = 1;
		let t = e.world.filter((e) => e.y === 0).flatMap((t) => At(e, t.x, t.y)).filter((t) => Ne(e, t)), n = Math.min(...t.map((t) => Math.min(...X(e).map((e) => R(e, t))))), r = t.filter((t) => Math.abs(Math.min(...X(e).map((e) => R(e, t))) - n) < 1e-8);
		if (r.length) {
			K(e, "*", "bossTeleport", r.map((e) => ({
				kind: "bossTeleport",
				...e
			})));
			return;
		}
	}
	let n = X(e), r = U(e), i = Math.min(...n.map((e) => R(e, t)));
	if (n.some((n) => Math.abs(R(n, t) - i) < 1e-8 && r.some((t) => Le(e, t, n)))) {
		let r = gn(e, t, t, 1275, t.id === "kingSlime" ? "walk" : "ghost", !0, !0), i = n.filter((n) => r.some((r) => U({
			...e,
			boss: {
				...t,
				...r
			}
		}).some((e) => L(e, n))));
		i.length && (n = i);
	}
	let a = Math.min(...n.map((e) => R(e, t)));
	K(e, "*", "enemyTarget", n.filter((e) => Math.abs(R(e, t) - a) < 1e-8).map((e) => ({
		kind: "bossTarget",
		b: e.rid
	})));
}
function wn(e, t, n, r) {
	let i = n.n ?? 1;
	switch (n.kind) {
		case "ap":
			t.ap += i;
			break;
		case "attack":
			t.attack += i;
			break;
		case "defense":
			t.defense += i;
			break;
		case "health":
		case "lowHeal":
			t.hp = Math.min(t.maxHp, t.hp + i);
			break;
		case "mana":
			t.mana = Math.min(t.maxMana, t.mana + i);
			break;
		case "coins":
			ct(t, i);
			break;
		case "draw":
			yt(e, t, i);
			break;
		case "flag":
			if (n.a.startsWith("enemy") && !n.a.includes("Reroll")) {
				let r = [...e.enemies.filter((e) => E(e.name)).map((e) => e.uid), ...e.boss ? ["boss"] : []];
				K(e, t.rid, "enemyTarget", r.map((e) => ({
					kind: "markEnemy",
					a: e,
					b: n.a
				})));
			} else [
				"duplicateAttack",
				"duplicateDefense",
				"promoteAttack",
				"promoteDefense"
			].includes(n.a) ? t.flags[n.a] = (t.flags[n.a] ?? 0) + i : t.flags[n.a] = Math.max(t.flags[n.a] ?? 0, i);
			break;
		case "teamFlag":
			e.globalFlags[n.a] = i;
			break;
		case "teamBiome": {
			let r = V(e, t);
			if (n.a === "yield") e.globalFlags["yield:" + r] = (e.globalFlags["yield:" + r] ?? 0) + i;
			else for (let t of X(e)) V(e, t) === r && (n.a === "rally" ? (t.attack += i, t.defense += i) : (t.dig += i, t.chop += i, t.toolPoints.push({
				kind: "dig",
				n: i,
				yield: 1
			}, {
				kind: "chop",
				n: i,
				yield: 1
			})));
			break;
		}
		case "clearOthers":
			for (let n of Object.values(e.people)) n.rid !== t.rid && (n.debuffs = {});
			break;
		case "assist": {
			let n = X(e).filter((e) => e.rid !== t.rid);
			if (!n.length) yt(e, t, i);
			else {
				let r = n.map((e) => ({
					kind: "assistDraw",
					a: e.rid,
					n: i
				}));
				if (i === 2) for (let e = 0; e < n.length; e++) for (let t = e + 1; t < n.length; t++) r.push({
					kind: "assistSplit",
					a: n[e].rid,
					b: n[t].rid
				});
				K(e, t.rid, "assist", r);
			}
			break;
		}
		case "freePlatforms":
			t.flags.freePlatforms = (t.flags.freePlatforms ?? 0) + i, G(e, {
				kind: "freePlatformOffer",
				who: t.rid
			});
			break;
		case "discardDraw":
			K(e, t.rid, "discard", t.hand.map((e) => ({
				kind: "discardDraw",
				a: e.uid,
				n: i
			})));
			break;
		case "drawDiscard":
			yt(e, t, i), K(e, t.rid, "discard", t.hand.map((e) => ({
				kind: "discardCard",
				a: e.uid
			})));
			break;
		case "drawKeep": {
			let n = new Set(t.hand.map((e) => e.uid));
			yt(e, t, i), K(e, t.rid, "keep", t.hand.filter((e) => !n.has(e.uid)).map((e) => ({
				kind: "keepDraw",
				a: e.uid,
				b: JSON.stringify(t.hand.filter((e) => !n.has(e.uid)).map((e) => e.uid))
			})));
			break;
		}
		case "fetch": {
			let r = [
				...t.deck,
				...n.a === "draw" ? [] : t.discard,
				...n.a === "scrapped" ? t.scrapped : []
			];
			K(e, t.rid, "fetch", r.map((e) => ({
				kind: "fetchCard",
				a: e.uid,
				b: e.type
			})).concat([{ kind: "skip" }]));
			break;
		}
		case "scrap":
			G(e, {
				kind: "scrapOffer",
				who: t.rid,
				n: i,
				a: n.a
			});
			break;
		case "springScrap":
			K(e, t.rid, "scrap", t.hand.map((e) => ({
				kind: "springScrap",
				a: e.uid,
				b: r
			})));
			break;
		case "deescalate":
			vt(e, -1), St(e, t, 4);
			break;
		case "teleport":
			K(e, t.rid, "teleport", un(e, t).map((e) => ({
				...e,
				kind: "teleport"
			})));
			break;
		case "copy": {
			let i = (n.a === "other" ? Object.values(e.people).filter((e) => e.rid !== t.rid).flatMap((e) => e.played) : t.hand.filter((e) => e.uid !== r && (n.a !== "start" || e.type.startsWith("s")))).map((e) => ({
				kind: "copyCard",
				a: e.type
			}));
			K(e, t.rid, "copy", i.concat([{ kind: "skip" }]));
			break;
		}
		case "finisher": K(e, t.rid, "attackTarget", Yt(e, t, [
			"short",
			"medium",
			"long"
		]).map((e) => ({
			kind: "finisherTarget",
			a: r,
			b: e
		})));
	}
}
function Tn(e, t, n, r) {
	let i = (e) => {
		t.hp = Math.min(t.maxHp, t.hp + e);
	}, a = (e) => {
		t.mana = Math.min(t.maxMana, t.mana + e);
	};
	switch (n) {
		case "c0":
			i(1);
			break;
		case "c1":
			a(1);
			break;
		case "c4":
			t.ap += 2;
			break;
		case "c8":
			t.defense += 2;
			break;
		case "c9":
			t.dig += 2, t.toolPoints.push({
				kind: "dig",
				n: 2,
				yield: 1
			});
			break;
		case "c11":
			i(2);
			break;
		case "c13":
			yt(e, t, 2);
			break;
		case "c16":
			a(3);
			break;
		case "c5":
			e.globalFlags["inferno:" + Math.floor(t.x / 3) + ":" + Math.floor(t.y / 5)] = 1;
			break;
		case "c6":
			r === "coins" ? ct(t, 5) : K(e, t.rid, "teleport", un(e, t).map((e) => ({
				...e,
				kind: "teleport"
			})));
			break;
		case "c7":
			t.flags.invisible = 1;
			break;
		case "c10":
		case "c12":
			r === "coins" ? ct(t, 5) : t.flags[n === "c10" ? "archery" : "magic"] = 1;
			break;
		case "c17":
			r === "coins" ? ct(t, 8) : delete t.debuffs.fire;
			break;
		case "c20":
			e.triggered.includes("wall") || (e.triggered.push("wall"), e.bossQueue.push({
				id: "wall",
				x: 0,
				y: 24
			}));
			break;
		case "c2":
		case "c3":
			K(e, t.rid, "attackTarget", Yt(e, t, ["short", "medium"]).map((e) => ({
				kind: "throwTarget",
				a: n,
				b: e
			})));
			break;
		case "c14":
		case "c15":
		case "c21": {
			let r = [];
			for (let i of e.world) for (let a = 0; a < 15; a++) {
				let o = {
					x: i.x * 3 + a % 3,
					y: i.y * 5 + Math.floor(a / 3)
				};
				Re(t, o, ["short", "medium"]) >= 0 && Le(e, t, o) && r.push({
					kind: "explode",
					a: n,
					...o
				});
			}
			K(e, t.rid, "explosive", r);
			break;
		}
	}
}
function En(e, t, n) {
	let r = t.who ?? n, i = e.people[r], a = t.a ?? "", o = t.b ?? "", s = t.n ?? 1, c = {
		x: t.x ?? 0,
		y: t.y ?? 0
	};
	switch (t.kind) {
		case "skip": break;
		case "prepared":
			dn(e, i), Object.values(e.people).every((e) => e.prepared) && (e.phase = "character");
			break;
		case "equip":
			i.equipped[w(a).slot] = a;
			break;
		case "armor":
			i.armor = a;
			for (let e of Object.keys(i.debuffs)) mt(i, e) && delete i.debuffs[e];
			break;
		case "respawn":
			i.x = c.x, i.y = c.y, i.hp = i.maxHp, i.mana = i.maxMana, i.dead = !1, Tt(e, i, !0);
			break;
		case "end":
			i.ended = !0, Object.values(e.people).every((e) => e.ended) && G(e, { kind: "endCheck" });
			break;
		case "resume":
			i.ended = !1;
			break;
		case "endCheck":
			pn(e);
			break;
		case "resource":
			i.dead || Nt(e, i, a, s, o === "donated");
			break;
		case "giftCraft": {
			let t = JSON.parse(a), n = t.kind === "craft" ? t.a.startsWith("e") ? w(t.a).recipe : T(t.a).recipe : t.kind === "house" ? _e[t.a].cost : { [t.a === "platform" ? "wood" : "cobweb"]: 1 }, c = Math.min(s, n[o] ?? 0), l = {
				resource: o,
				n: c
			};
			i.inventory.unshift(l), En(e, t, r), i.inventory.splice(i.inventory.indexOf(l), 1), s > c && G(e, {
				...Y(r, o, s - c),
				b: "donated"
			});
			break;
		}
		case "store": {
			let n = i.inventory[+o];
			n.resource !== a && (n.n = 0, n.resource = a), n.n += s;
			let c = +(t.flag ?? 0) - s;
			c > 0 && G(e, Y(r, a, c)), q(e, "resource", r, a, s);
			break;
		}
		case "storeStockpile":
			i.stockpile.resource = a, i.stockpile.n += s, +(t.flag ?? 0) > s && G(e, Y(r, a, +(t.flag ?? 0) - s));
			break;
		case "discardResource": break;
		case "overflowDonate":
			e.globalFlags.freeDonate || i.ap--, G(e, {
				...Y(o, a, s),
				b: "donated"
			});
			break;
		case "gain":
			ht(e, a) && K(e, r, "loot", [{
				kind: "takeItem",
				a,
				who: r
			}, { kind: "skip" }]);
			break;
		case "takeItem":
			Pt(e, i, a);
			break;
		case "loot": {
			let t = e.loot[s].splice(0, 2);
			t.length && K(e, r, "loot", t.map((e) => ({
				kind: "lootPick",
				a: e,
				b: JSON.stringify(t),
				n: s,
				who: r
			})).concat([{
				kind: "lootDecline",
				b: JSON.stringify(t),
				n: s,
				who: r
			}]));
			break;
		}
		case "lootPick":
		case "lootDecline": {
			let n = JSON.parse(o);
			t.kind === "lootPick" ? (i.discard.push(rt(e, a)), e.supply[a]--, e.loot[s].push(...n.filter((e, t) => e !== a || n.indexOf(a) !== t)), q(e, "gain", r, a)) : e.loot[s].push(...n);
			break;
		}
		case "randomConsumable": {
			let t = e.loot["consumable:" + s][0], n = [];
			t && n.push(ut(r, t)), +o > 1 && n.push({
				kind: "randomConsumable",
				who: r,
				n: s,
				b: String(o - 1)
			}), G(e, ...n);
			break;
		}
		case "coins":
			ct(i, s);
			break;
		case "shareResource":
		case "shareItem":
		case "shareCoins":
		case "shareHealth": {
			if (s <= 0) break;
			let n = [];
			for (let r of e.players) {
				let i = e.people[r], o = t.kind === "shareCoins" ? 25 - i.coins : t.kind === "shareHealth" ? i.maxHp - i.hp : s;
				for (let e = 1; e <= Math.min(s, o); e++) n.push({
					kind: "shareTake",
					who: r,
					a,
					b: t.kind,
					n: e,
					flag: String(s)
				});
			}
			K(e, "*", "share", n.concat([{ kind: "skip" }]));
			break;
		}
		case "shareTake": {
			let n = +(t.flag ?? 0) - s;
			n > 0 && G(e, {
				kind: o,
				a,
				n
			}), o === "shareResource" && G(e, Y(r, a, s)), o === "shareCoins" && ct(i, s), o === "shareHealth" && (i.hp = Math.min(i.maxHp, i.hp + s)), o === "shareItem" && G(e, ...Array.from({ length: s }, () => ut(r, a)));
			break;
		}
		case "coinOrThreat":
			K(e, "*", "reward", [{
				kind: "shareCoins",
				n: s
			}, {
				kind: "reduceThreat",
				n: +a
			}]);
			break;
		case "reduceThreat":
			vt(e, -s);
			break;
		case "beeLoot":
			K(e, "*", "reward", [{
				kind: "shareItem",
				a: "c21",
				n: s
			}, {
				kind: "reduceThreat",
				n: 1
			}]);
			break;
		case "evilLoot":
			K(e, r, "reward", [{
				kind: "loot",
				who: r,
				n: 4
			}, ut(r, "c14")]);
			break;
		case "oreReward":
			K(e, "*", "reward", [
				"copper",
				"iron",
				"silver",
				"gold"
			].filter((t) => (e.stats["o1:dig:" + t] ?? 0) > 0).map((e) => ({
				kind: "shareResource",
				a: e,
				n: s
			})));
			break;
		case "pickaxeOre":
			K(e, "*", "reward", [...new Set(Object.values(e.people).flatMap((e) => e.equipment.filter((e) => w(e).slot === "pickaxe" && e !== "e7").flatMap((e) => Object.keys(w(e).recipe).filter((e) => e !== "wood"))))].map((e) => ({
				kind: "shareResource",
				a: e,
				n: s
			})));
			break;
		case "woodOrCoins":
			K(e, r, "reward", [Y(r, "wood", s), {
				kind: "coins",
				n: +o,
				who: r
			}]);
			break;
		case "ropeOrPlatform":
			K(e, r, "reward", [{
				kind: "ropeAward",
				who: r,
				n: s
			}, {
				kind: "platformAward",
				who: r,
				n: +o
			}]);
			break;
		case "platformAward":
		case "ropeAward": {
			let n = t.kind === "platformAward" ? "platforms" : "ropes", a = n === "platforms" ? 30 : 12;
			gt(e, n) < a ? (i[n]++, s > 1 && G(e, {
				...t,
				n: s - 1
			})) : e[n].length && K(e, r, "reclaim", e[n].map((e) => ({
				kind: "reclaimToken",
				a: n === "platforms" ? "platform" : "rope",
				n: s,
				flag: "award",
				...e,
				who: r
			})));
			break;
		}
		case "magicOrMana":
			K(e, r, "reward", [ut(r, "c12"), ut(r, "c16")]);
			break;
		case "scrapOffer":
			K(e, r, "scrap", [
				...i.hand,
				...i.discard,
				...a === "all" ? i.deck : []
			].map((e) => ({
				kind: "scrapCard",
				a: e.uid,
				n: s,
				b: a,
				who: r
			})).concat([{ kind: "skip" }]));
			break;
		case "scrapCard":
			for (let e of [
				"hand",
				"discard",
				"deck"
			]) {
				let t = i[e].findIndex((e) => e.uid === a);
				if (t >= 0) {
					let n = i[e].splice(t, 1);
					i.scrapped.push(...n.filter((e) => !e.uid.startsWith("copy")));
					break;
				}
			}
			s > 1 && G(e, {
				kind: "scrapOffer",
				who: r,
				n: s - 1,
				a: o
			});
			break;
		case "card": {
			let n = i.hand.find((e) => e.uid === a), o = +(t.flag ?? 0), c = Se[n.type], l = c.branches[o][s];
			n.branch = o, n.used.push(s);
			let u = n.uid;
			n.used.length === c.branches[o].length && (i.hand = i.hand.filter((e) => e !== n), i.played.push(n)), wn(e, i, l, u), q(e, "play", r, n.type);
			break;
		}
		case "ready": {
			let e = i.hand.find((e) => e.uid === a);
			i.hand = i.hand.filter((t) => t !== e), i.ready && i.hand.push(i.ready), i.stockpile = {
				resource: "",
				n: 0
			}, i.ready = e, ft(i, "immune") && (i.debuffs = {});
			break;
		}
		case "readyAP":
			i.ap += s, i.ready.used.push(-1);
			break;
		case "unready":
			i.ready && (i.hand.push(i.ready), i.ready = null, i.stockpile = {
				resource: "",
				n: 0
			});
			break;
		case "assistDraw":
			yt(e, e.people[a], s);
			break;
		case "assistSplit":
			yt(e, e.people[a], 1), yt(e, e.people[o], 1);
			break;
		case "discardDraw":
		case "discardCard": {
			let n = i.hand.find((e) => e.uid === a);
			n && (i.hand = i.hand.filter((e) => e !== n), i.discard.push(n)), t.kind === "discardDraw" && yt(e, i, s);
			break;
		}
		case "keepDraw": {
			let e = JSON.parse(o), t = i.hand.filter((t) => e.includes(t.uid) && t.uid !== a);
			i.hand = i.hand.filter((e) => !t.includes(e)), i.discard.push(...t);
			break;
		}
		case "fetchCard":
			for (let e of [
				"deck",
				"discard",
				"scrapped"
			]) {
				let t = i[e].findIndex((e) => e.uid === a);
				if (t >= 0) {
					let n = i[e].splice(t, 1)[0];
					n.used = [], n.branch = null, i.hand.push(n);
					break;
				}
			}
			break;
		case "springScrap": {
			let e = i.hand.find((e) => e.uid === a);
			e && (i.hand = i.hand.filter((t) => t !== e), e.uid.startsWith("copy") || i.scrapped.push(e));
			let t = i.played.find((e) => e.uid === o);
			t && (i.played = i.played.filter((e) => e !== t), i.scrapped.push(t));
			break;
		}
		case "copyCard":
			i.hand.push({
				uid: $e(e, "copy"),
				type: a,
				used: [],
				branch: null
			});
			break;
		case "markEnemy":
			e.globalFlags[a + ":" + o] = (e.globalFlags[a + ":" + o] ?? 0) + 1;
			break;
		case "discover":
			G(e, ...He(e, i).map((e) => ({
				kind: "reveal",
				...e
			}))), i.flags.foresight && G(e, {
				kind: "foresight",
				who: r
			});
			break;
		case "reveal":
			jt(e, c.x, c.y);
			break;
		case "foresight": {
			let t = De(e, i);
			if (t) {
				let n = e.world.filter((e) => Math.abs(e.x - t.x) + Math.abs(e.y - t.y) <= 1).flatMap((e) => [
					{
						x: e.x - 1,
						y: e.y
					},
					{
						x: e.x + 1,
						y: e.y
					},
					{
						x: e.x,
						y: e.y - 1
					},
					{
						x: e.x,
						y: e.y + 1
					}
				]).filter((t) => Ee(t.x, t.y) && !e.world.some((e) => I(e, t)));
				n.length && K(e, r, "discover", n.map((e) => ({
					kind: "reveal",
					...e
				})));
			}
			break;
		}
		case "move":
			i.ap -= s, G(e, ...JSON.parse(t.flag).map((e) => ({
				kind: "moveStep",
				...e,
				who: r
			})));
			break;
		case "drop":
			Tt(e, i, !1, !1), Et(e);
			break;
		case "hook": {
			i.ap -= s;
			let n = JSON.parse(t.flag), a = i.equipped.other === "e52" ? 3 : 2;
			G(e, ...n.map((e, t) => ({
				kind: t < a ? "hookStep" : "moveStep",
				...e,
				who: r
			})));
			break;
		}
		case "hookStep":
			if (i.dead) break;
			if (e.boss?.id === "wall" && i.y >= 20 && c.y < 20) {
				xt(e, i);
				break;
			}
			i.x = c.x, i.y = c.y, wt(e, i), q(e, "move", r, "", 0, i);
			break;
		case "moveStep":
		case "ropeMove":
		case "teleport":
		case "travel":
			if (i.dead) break;
			if (t.kind === "ropeMove" && (i.ap -= s), t.kind === "travel" && (i.ap -= 4, i.flags.pylon = 1), e.boss?.id === "wall" && i.y >= 20 && c.y < 20) {
				xt(e, i);
				break;
			}
			i.x = c.x, i.y = c.y, wt(e, i), W(e, i, i.rid) || Tt(e, i, !0), Et(e), q(e, "move", r, "", 0, i);
			break;
		case "tool": {
			let e = w(a);
			i.ap -= e.cost;
			let t = e.chop ? "chop" : e.hardy ? "hardyDig" : "dig", n = e.chop || e.dig;
			i[t] += n, i.toolPoints.push({
				kind: t,
				n,
				yield: e.yield_
			});
			break;
		}
		case "chop": {
			let t = Ht(i, o);
			e.acorns.push(c), J(e, "chop"), G(e, Y(r, "wood", s * (t + (e.globalFlags["yield:" + V(e, c)] ?? 0)))), q(e, "chop", r, "wood", s, c);
			break;
		}
		case "dig": {
			let t = k[B(e, c)], n = Ht(i, o);
			Oe(e, c, "."), e.digged.push(c), J(e, "dig"), t.resource && (J(e, "dig:" + t.resource), G(e, Y(r, t.resource, n + (e.globalFlags["yield:" + V(e, c)] ?? 0)))), t.resource === "hellstone" && bt(e, i, "fire"), !W(e, c) && !I(i, c) && G(e, {
				kind: "digEnterOffer",
				who: r,
				...c
			}), Et(e), q(e, "dig", r, t.resource, s, c);
			break;
		}
		case "digEnterOffer":
			L(i, c) && Me(e, c) && !W(e, c) && K(e, r, "enter", [{
				kind: "teleport",
				...c,
				who: r
			}, { kind: "skip" }]);
			break;
		case "chest": {
			i.ap--;
			let t = V(e, c), n = e.chests[t] ?? e.chests.forest, a = n.splice(0, s);
			n.push(...a), Oe(e, c, "."), J(e, "chest"), t !== "forest" && J(e, "nonForestChest"), c.y >= 5 && J(e, "deepChest"), c.y >= 20 && J(e, "underworldChest"), K(e, r, "chest", a.map((e) => ({
				kind: "chestPick",
				a: String(e),
				n: Math.floor(c.y / 5),
				who: r
			})).concat([{ kind: "skip" }]));
			break;
		}
		case "chestPick":
			Ft(e, i, ue[+a][s + 1]);
			break;
		case "craft":
			ot(i, (a.startsWith("e") ? w(a) : T(a)).recipe), Pt(e, i, a), J(e, "craft:" + a), a.startsWith("e") && J(e, "craft:" + w(a).slot);
			break;
		case "nightsEdge": {
			let t = i.equipment.filter((e) => [
				"e18",
				"e19",
				"e20"
			].includes(e));
			K(e, r, "scrapEquipment", t.flatMap((e, n) => t.slice(n + 1).map((t) => ({
				kind: "forgeEdge",
				a: e,
				b: t,
				who: r
			}))));
			break;
		}
		case "forgeEdge":
			i.equipment = i.equipment.filter((e) => e !== a && e !== o), e.supply[a]++, e.supply[o]++;
			for (let [e, t] of Object.entries(i.equipped)) (t === a || t === o) && (i.equipped[e] = "");
			Pt(e, i, "e36");
			break;
		case "craftToken": {
			ot(i, { [a === "platform" ? "wood" : "cobweb"]: 1 });
			let t = a === "platform" ? "platforms" : "ropes", n = a === "platform" ? 30 : 12;
			e[t].length + Object.values(e.people).reduce((e, n) => e + n[t], 0) < n ? i[t]++ : K(e, r, "reclaim", e[t].map((e) => ({
				kind: "reclaimToken",
				a,
				...e,
				who: r
			})));
			break;
		}
		case "reclaimToken": {
			let n = a === "platform" ? "platforms" : "ropes";
			e[n] = e[n].filter((e) => !I(e, c)), o ? G(e, JSON.parse(o)) : i[n]++, t.flag === "award" && s > 1 && G(e, {
				kind: n === "platforms" ? "platformAward" : "ropeAward",
				n: s - 1,
				who: r
			}), Et(e);
			break;
		}
		case "house": {
			ot(i, _e[a].cost);
			let t = ze(a, c);
			t.some((t) => B(e, t) === "S") && vt(e, _t(e)), e.houses.push({
				...c,
				type: a,
				cells: t
			}), a === "bottle" && (e.bottle = 4), a === "cookingPot" && (e.food = [
				0,
				1,
				2,
				3
			]), q(e, "craft", r, a);
			break;
		}
		case "platform":
			i.platforms--, e.platforms.push(c);
			break;
		case "freePlatformOffer":
			i.flags.freePlatforms > 0 && (gt(e, "platforms") < 30 || e.platforms.length) && K(e, r, "platform", z(i).concat([{
				x: i.x,
				y: i.y
			}]).filter((t) => Me(e, t) && !e.platforms.some((e) => I(e, t))).map((e) => ({
				kind: "freePlatform",
				...e,
				who: r
			})).concat([{ kind: "skip" }]));
			break;
		case "freePlatform":
			gt(e, "platforms") >= 30 ? K(e, r, "reclaim", e.platforms.map((e) => ({
				kind: "reclaimToken",
				a: "platform",
				...e,
				b: JSON.stringify(t),
				who: r
			}))) : (e.platforms.push(c), i.flags.freePlatforms--, G(e, {
				kind: "freePlatformOffer",
				who: r
			}));
			break;
		case "rope":
			i.ropes--, e.ropes.push(c), B(e, c) === "S" && vt(e, _t(e));
			break;
		case "pylon":
			st(e, i, 10), e.pylons.push(c), B(e, c) === "S" && vt(e, _t(e));
			break;
		case "collect": {
			let t = Z(e, a);
			e.enemies = e.enemies.filter((e) => e !== t), t.name === "Life Crystal" ? (J(e, "lifeCrystal"), s === 0 ? (i.maxHp = Math.min(7, i.maxHp + 1), i.hp = i.maxHp) : ct(i, 10)) : (J(e, "fallenStar"), s === 0 ? (i.maxMana = Math.min(7, i.maxMana + 1), i.mana = i.maxMana) : ct(i, 10)), Et(e);
			break;
		}
		case "unlock":
			st(e, i, i.inventory.length === 4 ? 15 : 25), i.inventory.push({
				resource: "",
				n: 0
			});
			break;
		case "spawnNpc":
			e.npcs.push(a), q(e, "npc", "", a);
			break;
		case "buyAction":
			st(e, i, s), i.flags.discount = 0, Pt(e, i, a);
			break;
		case "buyConsumable":
			st(e, i, s === 1 ? 3 : 15), G(e, {
				kind: "randomConsumable",
				who: r,
				n: s,
				b: "1"
			});
			break;
		case "nurse":
			st(e, i, 10), i.hp = i.maxHp, i.debuffs = {};
			break;
		case "goblin":
			st(e, i, 15), i.flags.goblin = 1, G(e, {
				kind: "scrapOffer",
				who: r,
				n: 1,
				a: "all"
			});
			break;
		case "bottle":
			e.bottle--, i.flags.bottle = 1, Pt(e, i, a);
			break;
		case "food":
			e.food = e.food.filter((e) => e !== s), i.flags.food = 1, s === 0 && (i.mana = Math.min(i.maxMana, i.mana + 2)), s === 1 && (i.hp = Math.min(i.maxHp, i.hp + 2)), s === 2 && (i.ap += 2), s === 3 && (i.defense += 2);
			break;
		case "objective":
			cn(e, a);
			break;
		case "focus":
			e.globalFlags.focusTarget = +a.slice(1) + 1;
			break;
		case "donate":
			K(e, r, "donate", e.players.filter((e) => e !== r).map((e) => ({
				kind: "donateTo",
				b: e,
				who: r
			})));
			break;
		case "donateTo": {
			let t = [];
			for (let e of [...i.inventory, i.stockpile]) if (e.n) for (let n = 1; n <= it(i, e.resource); n++) t.push({
				kind: "donateResource",
				a: e.resource,
				b: o,
				n,
				who: r
			});
			for (let e = 1; e <= i.coins; e++) t.push({
				kind: "donateCoins",
				b: o,
				n: e,
				who: r
			});
			for (let e of [
				...i.equipment,
				...i.armors,
				...i.consumables
			]) t.push({
				kind: "donateItem",
				a: e,
				b: o,
				who: r
			});
			for (let e of ["platforms", "ropes"]) for (let n = 1; n <= i[e]; n++) t.push({
				kind: "donateTokens",
				a: e,
				b: o,
				n,
				who: r
			});
			K(e, r, "donate", t.concat([{ kind: "skip" }]));
			break;
		}
		case "donateResource":
			e.globalFlags.freeDonate || i.ap--, ot(i, { [a]: s }), G(e, {
				...Y(o, a, s),
				b: "donated"
			});
			break;
		case "donateCoins":
			e.globalFlags.freeDonate || i.ap--, i.coins -= s, ct(e.people[o], s);
			break;
		case "donateTokens":
			e.globalFlags.freeDonate || i.ap--, a === "platforms" ? (i.platforms -= s, e.people[o].platforms += s) : (i.ropes -= s, e.people[o].ropes += s);
			break;
		case "donateItem": {
			e.globalFlags.freeDonate || i.ap--;
			let t = e.people[o];
			if (a.startsWith("e")) {
				let e = i.equipment.indexOf(a);
				i.equipment.splice(e, 1), t.equipment.push(a), t.equipped[w(a).slot] = a, i.equipped[w(a).slot] === a && (i.equipped[w(a).slot] = i.equipment.filter((e) => w(e).slot === w(a).slot).at(-1) ?? "");
			} else a.startsWith("r") ? (i.armors.splice(i.armors.indexOf(a), 1), t.armors.push(a), t.armor = a, i.armor === a && (i.armor = i.armors.at(-1) ?? "")) : (i.consumables.splice(i.consumables.indexOf(a), 1), t.consumables.push(a));
			break;
		}
		case "weapon": {
			let t = w(a);
			K(e, r, "attackTarget", Yt(e, i, t.ranges, t.sightless).map((e) => ({
				kind: "weaponTarget",
				a,
				b: e,
				who: r
			})));
			break;
		}
		case "weaponTarget": {
			let t = w(a);
			t.mana ? i.mana -= t.cost : i.ap -= t.cost, t.draw && yt(e, i, t.draw), Qt(e, i, a, o, t.dice, t.ranges, t.prevent, t.pierce, t.sightless);
			break;
		}
		case "finisherTarget": {
			let t = i.played.find((e) => e.uid === a);
			t && (i.played = i.played.filter((e) => e !== t), t.uid.startsWith("copy") || i.scrapped.push(t)), Qt(e, i, "a39", o, [
				20,
				20,
				20
			], [
				"short",
				"medium",
				"long"
			]);
			break;
		}
		case "minion":
			i.mana -= xe[a].cost, i.minion = a, i.flags["minion:" + a] || (i.attack += xe[a].attack + +(i.armor === "r20"), i.flags["minion:" + a] = 1);
			break;
		case "summonEye":
			ot(i, { lens: 1 }), e.time = 4, e.triggered.push("eye"), e.bossQueue.push({
				id: "eye",
				x: 25,
				y: 2
			});
			break;
		case "consumable":
			if (a === "c20" && (i.y < 20 || !z(i).concat([{
				x: i.x,
				y: i.y
			}]).some((t) => B(e, t) === "L") || e.triggered.includes("wall"))) break;
			K(e, r, "consumable", ([
				"c6",
				"c10",
				"c12",
				"c17"
			].includes(a) ? ["effect", "coins"] : ["effect"]).map((e) => ({
				kind: "useConsumable",
				a,
				b: e,
				who: r
			})).concat([{ kind: "skip" }]));
			break;
		case "useConsumable":
			i.consumables.splice(i.consumables.indexOf(a), 1), Ct(e, a), i.flags.doubleConsumable && (i.flags.doubleConsumable = 0, G(e, {
				kind: "repeatConsumable",
				a,
				b: o,
				who: r
			})), Tn(e, i, a, o), q(e, "use", r, a);
			break;
		case "repeatConsumable":
			Tn(e, i, a, o);
			break;
		case "throwTarget":
			Qt(e, i, a, o, [a === "c2" ? 6 : 4], ["short", "medium"], !1, a === "c2" ? 1 : 2);
			break;
		case "explode": {
			if (e.boss?.id === "brain" && e.boss.form === 0 && !o && U(e).some((e) => L(e, c))) {
				K(e, r, "attackTarget", e.boss.buffs.map((e) => ({
					...t,
					b: "ally:" + e,
					who: r
				})));
				break;
			}
			let n = z(c).concat([c]), s = a === "c15" ? 4 : a === "c14" ? 3 : 2, l = a === "c15" ? [8, 8] : a === "c14" ? [6, 6] : [4, 6], u = e.enemies.filter((e) => n.some((t) => I(t, e)) && E(e.name)).map((e) => e.uid);
			if (e.boss && !e.boss.transformed) {
				let t = e.boss.id === "wall" ? e.boss.form === 0 ? e.boss.eyes.flatMap((e, t) => e > 0 ? ["eye:" + t] : []) : ["mouth"] : e.boss.id === "brain" && e.boss.form === 0 ? [o] : ["boss"];
				u.push(...t.filter((t) => Jt(e, t).some((e) => n.some((t) => I(e, t)))));
			}
			let d = X(e).filter((e) => n.some((t) => I(e, t))).map((e) => e.rid), f = [];
			for (let t of n) {
				let n = k[B(e, t)];
				n && n.cost <= s && (!n.hardy || a !== "c21") && !e.enemies.some((e) => I(e, t)) && (Oe(e, t, "."), e.digged.push(t), J(e, "dig"), J(e, "explosiveDig"), n.resource && (J(e, "dig:" + n.resource), f.push(Y(r, n.resource, 1))));
				let i = B(e, t);
				i.startsWith("T") && +i[1] <= s && !e.acorns.some((e) => I(e, t)) && (e.acorns.push(t), J(e, "chop"), f.push(Y(r, "wood", +i[1])));
			}
			if (Et(e), G(e, ...f), u.length) Qt(e, i, a, u[0], l, ["short", "medium"], !1), e.battle.targets = u, e.battle.drop = 0, e.battle.friends = d;
			else if (d.length) {
				let t = nt(e, l);
				G(e, ...d.map((e) => ({
					kind: "blastFriend",
					who: e,
					a: JSON.stringify(t),
					b: JSON.stringify(l)
				})));
			}
			break;
		}
		case "blastFriend":
			i.dead || (en(e, i, "explosive", JSON.parse(o)), e.battle.rolled = JSON.parse(a));
			break;
		case "finishTargets":
			e.battle.stage = "attackDice";
			break;
		case "pierceOrigin":
			e.battle.piercePoints = [c], e.battle.stage = "pierce";
			break;
		case "pierceTarget":
			e.battle.targets.push(a), e.battle.piercePoints.push(c);
			break;
		case "dropDie":
			e.battle.dice.splice(s, 1), e.battle.drop--, e.battle.dice.length || (e.battle = null);
			break;
		case "modifyDie": {
			let t = e.battle, n = t.enemyAttack ? t.defense : t.dice, r = Math.min(...n), i = Math.max(...n);
			if (a === "dryad") n.push(8), e.dryad = !1;
			else if (a.startsWith("duplicate")) n.push(r);
			else {
				let e = n.indexOf(["archery", "magic"].includes(a) ? i : r);
				n[e] = A(n[e]);
			}
			t.mods.push(a);
			break;
		}
		case "roll": {
			let t = e.battle;
			t.enemyAttack ? (t.rolled.length || (t.rolled = nt(e, t.dice)), t.defended = nt(e, t.defense)) : (t.rolled = nt(e, t.dice), t.defended = nt(e, t.defense)), t.stage = "modify", q(e, "roll", r, t.source);
			break;
		}
		case "boost": {
			let t = e.battle, n = +a;
			if (t.enemyAttack) {
				t.defended[n] += s, t.shielded = n;
				let e = Math.min(i.defense, s);
				i.defense -= e, i.ready && i.ready.used.push(...Array.from({ length: s - e }, () => -2));
			} else {
				t.rolled[n] += s, t.boosted = n;
				let e = Math.min(i.attack, s);
				i.attack -= e, i.ready && i.ready.used.push(...Array.from({ length: s - e }, () => -3));
			}
			break;
		}
		case "reroll": {
			let t = e.battle;
			a === "ninja" && (t.rolled[s] = et(e, t.dice[s]) + 1, i.flags.ninja = 1), a === "defense" && (t.defended[s] = et(e, t.defense[s]) + 1, i.flags.defenseRerolled = 1), a === "enemyAttack" && (t.rolled[s] = et(e, t.dice[s]) + 1, i.flags.enemyAttackRerolled = 1), a === "enemyDefense" && (t.defended[s] = et(e, t.defense[s]) + 1, i.flags.enemyDefenseRerolled = 1);
			break;
		}
		case "resolveBattle": {
			let t = e.battle;
			if (t.enemyAttack) {
				let n = Math.max(...t.defended), r = t.rolled.filter((e) => e >= n).length;
				St(e, i, r), r && !i.dead && bt(e, i, t.debuff), e.battle = null;
			} else nn(e, t);
			break;
		}
		case "pierceNext": {
			let t = JSON.parse(a);
			if (i.dead) break;
			let n = t.targets[0];
			if (!Jt(e, n).length) break;
			t.defense = Zt(e, n, "Defense", Xt(e, n), t.source), t.defended = nt(e, t.defense), e.battle = t;
			break;
		}
		case "retaliationOrder": {
			let t = JSON.parse(a).filter((t) => $t(e, t.id, i));
			i.dead || K(e, r, "retaliation", t.map((e, n) => ({
				kind: "retaliate",
				who: r,
				a: e.id,
				n: e.n,
				flag: e.debuff,
				b: JSON.stringify(t.filter((e, t) => n !== t))
			})));
			break;
		}
		case "retaliate":
			!i.dead && $t(e, a, i) && (en(e, i, a, [20], t.flag ?? "", s), o !== "[]" && G(e, {
				kind: "retaliationOrder",
				who: r,
				a: o
			}));
			break;
		case "spawnAt": {
			if (!Ne(e, c)) break;
			let t = X(e).filter((e) => e.consumables.includes("c7"));
			if (t.length) {
				K(e, "*", "preventSpawn", [...t.map((e) => ({
					kind: "preventSpawn",
					who: e.rid,
					...c
				})), {
					kind: "spawnAllowed",
					...c
				}]);
				break;
			}
			G(e, {
				kind: "spawnAllowed",
				...c
			});
			break;
		}
		case "preventSpawn":
			i.consumables.splice(i.consumables.indexOf("c7"), 1), Ct(e, "c7"), q(e, "use", r, "c7");
			break;
		case "spawnAllowed": {
			if (!Ne(e, c)) break;
			let t = Ot(e, c), n = e.bags[t];
			if (!n?.length) break;
			let r = X(e).filter((e) => e.flags.radar), i = Math.max(1, ...r.map((e) => e.flags.radar)), a = n.splice(0, i);
			a.length === 1 ? Dt(e, c, a[0], t) : K(e, "*", "spawn", a.map((e, n) => ({
				kind: "spawnPick",
				a: e,
				b: t,
				n,
				flag: JSON.stringify(a),
				...c
			})));
			break;
		}
		case "spawnPick": {
			let n = JSON.parse(t.flag);
			e.bags[o].push(...n.filter((e, t) => t !== s)), Dt(e, c, a, o);
			break;
		}
		case "activate":
			e.enemyTodo = e.enemyTodo.filter((e) => e !== a), a === "boss" ? Cn(e) : _n(e, a);
			break;
		case "enemyTarget": {
			let t = Z(e, a);
			if (!t) {
				yn(e);
				break;
			}
			let n = E(t.name), r = e.people[o], i = t.name.includes("Slime") && e.boss?.id === "kingSlime" && e.boss.behavior === 1 ? 1 : 0;
			K(e, "*", "enemyMove", (L(t, r) ? [{
				x: t.x,
				y: t.y
			}] : gn(e, t, r, Le(e, t, r) ? n.move + i : Math.min(1, n.move), n.mode)).map((e) => ({
				kind: "enemyMove",
				a,
				...e
			})));
			break;
		}
		case "enemyMove": {
			let t = Z(e, a);
			t ? (t.x = c.x, t.y = c.y, Et(e), vn(e, a)) : yn(e);
			break;
		}
		case "enemyHit": {
			let t = e.people[o], n = $t(e, a, t);
			e.globalFlags[a + ":hit:" + o] = (e.globalFlags[a + ":hit:" + o] ?? 0) + 1, n ? (en(e, t, a, n.dice, n.debuff), G(e, {
				kind: "enemyAttacks",
				a
			})) : vn(e, a);
			break;
		}
		case "enemyAttacks":
			vn(e, a);
			break;
		case "spawnBoss":
			bn(e);
			break;
		case "bossStart":
			xn(e);
			break;
		case "bossBuff": {
			let t = e.boss;
			if (t.buffs.push(s), t.id === "kingSlime" && s === 0 && G(e, ...e.world.filter((t) => Ue(e, {
				x: t.x * 3,
				y: t.y * 5
			})).flatMap((t) => At(e, t.x, t.y).map((e) => ({
				kind: "spawnAt",
				...e
			})))), t.id === "queenBee" && s < 2) for (let t of X(e)) V(e, t) === "jungle" && t.y >= 10 && t.y < 20 && bt(e, t, "poison");
			if (t.id === "wall" && s === 0 && K(e, "*", "wallBuff", [{ kind: "wallThreat" }, { kind: "wallFire" }]), t.id === "wall" && s === 1) for (let t of X(e)) t.y >= 20 && (t.hp = Math.min(t.maxHp, t.hp + 1));
			G(e, { kind: "bossSpecial" });
			break;
		}
		case "wallThreat":
			vt(e, _t(e));
			break;
		case "wallFire":
			for (let t of X(e)) t.y >= 20 && bt(e, t, "fire");
			break;
		case "bossSpecial": {
			let t = e.boss;
			if (!t) break;
			t.id === "queenBee" && t.buffs.length < 4 && U(e).some((t) => V(e, t) !== "jungle") && !e.globalFlags.queenExtra && (e.globalFlags.queenExtra = 1, K(e, "*", "bossBuff", [
				0,
				1,
				2,
				3
			].filter((e) => !t.buffs.includes(e)).map((e) => ({
				kind: "bossBuff",
				n: e
			}))));
			break;
		}
		case "bossTeleport":
			e.boss.x = c.x, e.boss.y = c.y, G(e, { kind: "displace" }, { kind: "bossMoveContinue" });
			break;
		case "bossMoveContinue":
			Cn(e);
			break;
		case "bossTarget": {
			let t = e.boss, n = e.people[o], r = t.id !== "kingSlime", i = t.id === "kingSlime" ? (t.behavior === 0 ? 1 : 2) + +!!t.buffs.includes(2) : t.id === "eye" ? (t.behavior === 0 ? 2 : 3) + +!!t.buffs.includes(2) : t.id === "brain" && t.behavior === 0 ? 3 : 2, a = U(e);
			K(e, "*", "bossMove", (a.some((e) => L(e, n)) ? [t] : gn(e, t, n, a.some((t) => Le(e, t, n)) ? i : 1, r ? "ghost" : "walk", !0)).map((e) => ({
				kind: "bossMove",
				x: e.x,
				y: e.y
			})));
			break;
		}
		case "bossMove":
			e.boss.x = c.x, e.boss.y = c.y, G(e, { kind: "displace" }, { kind: "bossAttacks" });
			break;
		case "wormTeleport": {
			let n = e.people[o], r = De(e, n), i = et(e, 6), a = {
				x: r.x * 3 + i % 3,
				y: r.y * 5 + (i < 3 ? 2 : 4)
			};
			if (I(e.boss, a)) {
				G(e, t);
				break;
			}
			e.boss.x = a.x, e.boss.y = a.y, G(e, { kind: "displace" }, { kind: "bossAttacks" });
			break;
		}
		case "wallStep": {
			let t = e.boss;
			if (!t) break;
			let n = {
				x: t.x + 1,
				y: t.y
			};
			if (!De(e, n) || n.x >= 48) {
				e.boss = null, e.triggered = e.triggered.filter((e) => e !== "wall");
				for (let t of X(e)) xt(e, t);
				q(e, "escape", "", "wall");
				break;
			}
			t.x++, G(e, { kind: "displace" });
			break;
		}
		case "bossAttacks": {
			let t = e.boss;
			if (!t) {
				yn(e);
				break;
			}
			if (t.id === "wall" && t.form === 0) {
				for (let [n, r] of t.eyes.entries()) if (r > 0) for (let r of X(e)) {
					let i = {
						x: t.x + 1,
						y: t.y - (n === 0 ? 3 : 1)
					}, a = Re(i, r, ["long"], !0);
					a >= 0 && Le(e, i, r) && G(e, {
						kind: "wallEyeAttack",
						who: r.rid,
						n: a
					});
				}
			}
			vn(e, "boss");
			break;
		}
		case "wallEyeAttack":
			i.dead || en(e, i, "boss", [12, 12].slice(s));
			break;
		case "displace":
			Sn(e);
			break;
		case "displaceWho": {
			let t = e.people[a] ?? Z(e, a), n = U(e), r = z(t).filter((t) => Me(e, t) && !W(e, t, a) && !n.some((e) => I(e, t)));
			if (r.length) K(e, "*", "displace", r.map((e) => ({
				kind: "displaceTo",
				a,
				...e
			})));
			else {
				if (e.people[a]) xt(e, e.people[a]);
				else {
					let t = Z(e, a);
					t && (e.bags[t.bag].push(t.name), e.enemies = e.enemies.filter((e) => e !== t));
				}
				G(e, { kind: "displace" });
			}
			break;
		}
		case "displaceTo": {
			let t = e.people[a] ?? Z(e, a);
			t.x = c.x, t.y = c.y, Et(e), G(e, { kind: "displace" });
			break;
		}
		case "environment":
			mn(e);
			break;
		case "advanceTime":
			e.time = (e.time + 1) % 7, e.time === 0 ? G(e, { kind: "sunrise" }) : [
				2,
				5,
				6
			].includes(e.time) ? G(e, { kind: "environmentThreat" }, { kind: "environmentSpawn" }, { kind: "round" }) : G(e, { kind: "round" });
			break;
		case "environmentThreat":
			vt(e, _t(e));
			break;
		case "environmentSpawn":
			G(e, ...e.world.filter((t) => Ue(e, {
				x: t.x * 3,
				y: t.y * 5
			})).flatMap((t) => At(e, t.x, t.y)).map((e) => ({
				kind: "spawnAt",
				...e
			})));
			break;
		case "sunrise": {
			e.day++, e.acorns = [], e.stats.thisNightSpawns = 0;
			for (let t of e.enemies.filter((e) => e.y < 5 && (e.night || e.name === "Fallen Star"))) e.bags[t.bag].push(t.name);
			e.enemies = e.enemies.filter((e) => e.y >= 5 || !e.night && e.name !== "Fallen Star");
			for (let t of Object.values(e.people)) t.mana = t.maxMana;
			lt(e, "bottle") && (e.bottle = 4), lt(e, "cookingPot") && (e.food = [
				0,
				1,
				2,
				3
			]), e.npcs.includes("dryad") && (e.dryad = !0), e.day === 2 && !e.triggered.includes("kingSlime") && (e.triggered.push("kingSlime"), e.bossQueue.push({
				id: "kingSlime",
				x: 25,
				y: 4
			}));
			let t = [];
			if (e.npcs.includes("goblin")) for (let n of e.players) t.push({
				kind: "scrapOffer",
				who: n,
				n: 1,
				a: "all"
			});
			G(e, ...t, { kind: "round" });
			break;
		}
		case "round": hn(e);
	}
}
function Dn(e, t, n) {
	if (t.type === "tick") {
		if (e.result || e.pending || e.battle || !e.queue.length) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = t.queue.shift();
		return En(t, n, n.who ?? t.players[0]), t.serial++, {
			state: t,
			fx: On(e, t, n, n.who ?? t.players[0])
		};
	}
	let r = Kt(e, n.by).find((e) => e.id === t.id);
	if (!r) return { code: "games.terraria.invalidAction" };
	let i = structuredClone(e);
	return i.pending &&= null, i.people[n.by] && i.phase === "character" && !["end", "resume"].includes(r.kind) && (i.people[n.by].ended = !1), En(i, r, n.by), i.boss && Object.values(i.people).some((e) => e.armor && !["r8", "r9"].includes(e.armor)) && (i.boss.cheap = !1), i.serial++, {
		state: i,
		fx: On(e, i, r, n.by)
	};
}
function On(e, t, n, r) {
	let i = [], a = n.who ?? r, o = e.people[a], s = t.people[a], c = t.log.filter((t) => t.id > e.logSequence);
	for (let e of c) e.key === "draw" ? i.push({
		kind: "terrariaDraw",
		rid: e.who,
		data: { n: e.n }
	}) : e.key === "resource" ? i.push({
		kind: "terrariaResource",
		rid: e.who,
		data: {
			item: e.item,
			n: e.n,
			x: o?.x ?? 0,
			y: o?.y ?? 0
		}
	}) : [
		"damage",
		"objective",
		"transform",
		"defeat",
		"boss",
		"discover",
		"spawn"
	].includes(e.key) && i.push({
		kind: "terrariaEvent",
		rid: e.who || void 0,
		data: {
			event: e.key,
			item: e.item,
			n: e.n,
			x: e.x,
			y: e.y
		}
	});
	if (o && s && !I(o, s) && [
		"moveStep",
		"hookStep",
		"ropeMove",
		"hook",
		"teleport",
		"travel",
		"drop",
		"respawn",
		"displaceTo",
		"dig",
		"digEnter"
	].includes(n.kind) && i.push({
		kind: "terrariaMove",
		rid: a,
		data: {
			from: {
				x: o.x,
				y: o.y
			},
			to: {
				x: s.x,
				y: s.y
			},
			teleport: [
				"teleport",
				"travel",
				"respawn"
			].includes(n.kind)
		}
	}), n.kind === "card" && o) {
		let e = o.hand.find((e) => e.uid === n.a);
		e && i.push({
			kind: "terrariaPlay",
			rid: a,
			data: {
				item: e.type,
				complete: s.played.some((t) => t.uid === e.uid)
			}
		});
	}
	return n.kind === "roll" && t.battle && i.push({
		kind: "terrariaRoll",
		rid: t.battle.rid,
		data: {
			attack: t.battle.rolled,
			defense: t.battle.defended
		}
	}), [
		"dig",
		"chop",
		"explode"
	].includes(n.kind) && i.push({
		kind: "terrariaBreak",
		rid: a,
		data: {
			x: n.x ?? 0,
			y: n.y ?? 0,
			kind: n.kind
		}
	}), i.map((e, t) => ({
		...e,
		...t ? { with: !0 } : {}
	}));
}
function kn(e, t) {
	return {
		public: {
			serial: e.serial,
			config: e.config,
			phase: e.phase,
			round: e.round,
			day: e.day,
			time: e.time,
			threat: e.threat,
			graves: e.graves,
			permanentThreat: e.permanentThreat,
			people: e.players.map((t) => {
				let { deck: n, ...r } = e.people[t];
				return {
					...r,
					deckCount: n.length
				};
			}),
			world: e.world,
			biomes: e.biomeOrder.map((t, n) => e.revealedBiomes.includes(n) ? t : "unknown"),
			enemies: e.enemies.map((e) => ({
				uid: e.uid,
				name: e.name,
				x: e.x,
				y: e.y,
				hp: e.hp,
				night: e.night
			})),
			houses: e.houses,
			platforms: e.platforms,
			ropes: e.ropes,
			pylons: e.pylons,
			acorns: e.acorns,
			npcs: e.npcs,
			bottle: e.bottle,
			food: e.food,
			dryad: e.dryad,
			boss: e.boss,
			bossQueue: e.bossQueue.map((e) => e.id),
			defeated: e.defeated,
			objectives: e.objectives,
			completed: e.completed,
			pending: e.pending ? {
				who: e.pending.who,
				prompt: e.pending.prompt
			} : null,
			battle: e.battle,
			log: e.log,
			result: e.result,
			stats: e.stats,
			supply: e.supply
		},
		private: { choices: Kt(e, t) }
	};
}
var An = {
	meta: We,
	saveCompatibility: { version: "1" },
	schemas: {
		action: Ke,
		publicView: Ze,
		privateView: Qe,
		config: Ge
	},
	setup: Mt,
	reduce: Dn,
	viewFor: kn,
	status: (e) => e.result ? {
		phase: "done",
		winner: e.result === "win" ? [...e.players] : [],
		ranking: [...e.players],
		scores: Object.fromEntries(e.players.map((t) => [t, e.completed.length]))
	} : { phase: e.phase },
	nextTickIn: (e) => !e.result && !e.pending && !e.battle && e.queue.length ? 480 : null
}, jn = {
	"Tomb Crawler": "games/terraria/tomb-crawler.webp",
	"Sand Slime": "games/terraria/sand-slime.webp",
	"Antlion Swarmer": "games/terraria/antlion-swarmer.webp",
	"Snow Flinx": "games/terraria/snow-flinx.webp",
	"Ice Bat": "games/terraria/ice-bat.webp",
	"Lava Slime": "games/terraria/lava-slime.webp",
	"Fire Imp": "games/terraria/fire-imp.webp",
	Hellbat: "games/terraria/hellbat.webp",
	"Voodoo Demon": "games/terraria/voodoo-demon.webp",
	Skeleton: "games/terraria/skeleton.webp",
	Salamander: "games/terraria/salamander.webp",
	"Black Slime": "games/terraria/black-slime.webp",
	Hornet: "games/terraria/hornet.webp",
	"Spiked Jungle Slime": "games/terraria/spiked-jungle-slime.webp",
	"Blood Crawler": "games/terraria/blood-crawler.webp",
	Crimera: "games/terraria/crimera.webp",
	"Red Slime": "games/terraria/red-slime.webp",
	"Giant Worm": "games/terraria/giant-worm.webp",
	"Yellow Slime": "games/terraria/yellow-slime.webp",
	"Cave Bat": "games/terraria/cave-bat.webp",
	Devourer: "games/terraria/devourer.webp",
	"Eater of Souls": "games/terraria/eater-of-souls.webp",
	"Jungle Bat": "games/terraria/jungle-bat.webp",
	"Fallen Star": "games/terraria/fallen-star.webp",
	"Demon Eye": "games/terraria/demon-eye.webp",
	Zombie: "games/terraria/zombie.webp",
	"Frozen Zombie": "games/terraria/frozen-zombie.webp",
	Antlion: "games/terraria/antlion.webp",
	Snatcher: "games/terraria/snatcher.webp",
	"Jungle Slime": "games/terraria/jungle-slime.webp",
	"Ice Slime": "games/terraria/ice-slime.webp",
	Vulture: "games/terraria/vulture.webp",
	"Blue Slime": "games/terraria/blue-slime.webp",
	"Green Slime": "games/terraria/green-slime.webp",
	Stone: "games/terraria/stone.webp",
	Demonite: "games/terraria/demonite.webp",
	Copper: "games/terraria/copper.webp",
	Gold: "games/terraria/gold.webp",
	Cobweb: "games/terraria/cobweb.webp",
	Silver: "games/terraria/silver.webp",
	Iron: "games/terraria/iron.webp",
	Gem: "games/terraria/gem.webp",
	Crimtane: "games/terraria/crimtane.webp",
	Hellstone: "games/terraria/hellstone.webp",
	Bone: "games/terraria/bone.webp",
	Lens: "games/terraria/lens.webp",
	"Flinx Fur": "games/terraria/flinx-fur.webp",
	Gel: "games/terraria/gel.webp"
}, Mn = {
	kingSlime: "games/terraria/boss-kingSlime.webp",
	kingSlime2: "games/terraria/boss-kingSlime2.webp",
	eye: "games/terraria/boss-eye.webp",
	eye2: "games/terraria/boss-eye2.webp",
	queenBee: "games/terraria/boss-queenBee.webp",
	brain: "games/terraria/boss-brain.webp",
	brain2: "games/terraria/boss-brain2.webp",
	eater: "games/terraria/boss-eater.webp",
	eater2: "games/terraria/boss-eater2.webp",
	wall: "games/terraria/boss-wall.webp",
	wall2: "games/terraria/boss-wall2.webp"
}, Nn = {
	e0: "games/terraria/art-e0.webp",
	e1: "games/terraria/art-e1.webp",
	e2: "games/terraria/art-e2.webp",
	e3: "games/terraria/art-e3.webp",
	e4: "games/terraria/art-e4.webp",
	e5: "games/terraria/art-e5.webp",
	e6: "games/terraria/art-e6.webp",
	e7: "games/terraria/art-e7.webp",
	e8: "games/terraria/art-e8.webp",
	e9: "games/terraria/art-e9.webp",
	e10: "games/terraria/art-e10.webp",
	e11: "games/terraria/art-e11.webp",
	e12: "games/terraria/art-e12.webp",
	e13: "games/terraria/art-e13.webp",
	e14: "games/terraria/art-e14.webp",
	e15: "games/terraria/art-e15.webp",
	e16: "games/terraria/art-e16.webp",
	e17: "games/terraria/art-e17.webp",
	e18: "games/terraria/art-e18.webp",
	e19: "games/terraria/art-e19.webp",
	e20: "games/terraria/art-e20.webp",
	e21: "games/terraria/art-e21.webp",
	e22: "games/terraria/art-e22.webp",
	e23: "games/terraria/art-e23.webp",
	e24: "games/terraria/art-e24.webp",
	e25: "games/terraria/art-e25.webp",
	e26: "games/terraria/art-e26.webp",
	e27: "games/terraria/art-e27.webp",
	e28: "games/terraria/art-e28.webp",
	e29: "games/terraria/art-e29.webp",
	e30: "games/terraria/art-e30.webp",
	e31: "games/terraria/art-e31.webp",
	e32: "games/terraria/art-e32.webp",
	e33: "games/terraria/art-e33.webp",
	e34: "games/terraria/art-e34.webp",
	e35: "games/terraria/art-e35.webp",
	e36: "games/terraria/art-e36.webp",
	e37: "games/terraria/art-e37.webp",
	e38: "games/terraria/art-e38.webp",
	e39: "games/terraria/art-e39.webp",
	e41: "games/terraria/art-e41.webp",
	e42: "games/terraria/art-e42.webp",
	e43: "games/terraria/art-e43.webp",
	e44: "games/terraria/art-e44.webp",
	e45: "games/terraria/art-e45.webp",
	e46: "games/terraria/art-e46.webp",
	e48: "games/terraria/art-e48.webp",
	e49: "games/terraria/art-e49.webp",
	e50: "games/terraria/art-e50.webp",
	e51: "games/terraria/art-e51.webp",
	e52: "games/terraria/art-e52.webp",
	e53: "games/terraria/art-e53.webp",
	e54: "games/terraria/art-e54.webp",
	e55: "games/terraria/art-e55.webp",
	e56: "games/terraria/art-e56.webp",
	e57: "games/terraria/art-e57.webp",
	e58: "games/terraria/art-e58.webp",
	e59: "games/terraria/art-e59.webp",
	e60: "games/terraria/art-e60.webp",
	e61: "games/terraria/art-e61.webp"
}, Pn = (e) => e === "wood" ? "games/terraria/art-wood-resource.webp" : ["flinxFur", "flinxfur"].includes(e) ? jn["Flinx Fur"] : jn[e[0]?.toUpperCase() + e.slice(1)];
function Fn({ id: e, className: t = "" }) {
	let n = Nn[e] ?? Pn(e);
	return n ? /* @__PURE__ */ m("img", {
		className: "terraria-item-art " + t,
		src: n,
		alt: "",
		draggable: !1
	}) : null;
}
function In({ kind: e }) {
	let t = {
		ap: "ap",
		attack: "attack",
		defense: "defense",
		health: "heart",
		lowHeal: "heart",
		coins: "coins"
	}[e];
	return t ? /* @__PURE__ */ m("img", {
		className: "terraria-rule-icon",
		src: "games/terraria/rule-" + t + ".webp",
		alt: "",
		draggable: !1
	}) : null;
}
//#endregion
//#region src/games/terraria/keys.ts
var Ln = {
	pierceOrigin: "games.terraria.operations.pierceOrigin",
	skip: "games.terraria.operations.skip",
	prepared: "games.terraria.operations.prepared",
	equip: "games.terraria.operations.equip",
	armor: "games.terraria.operations.armor",
	respawn: "games.terraria.operations.respawn",
	end: "games.terraria.operations.end",
	resume: "games.terraria.operations.resume",
	store: "games.terraria.operations.store",
	storeStockpile: "games.terraria.operations.storeStockpile",
	discardResource: "games.terraria.operations.discardResource",
	overflowDonate: "games.terraria.operations.overflowDonate",
	takeItem: "games.terraria.operations.takeItem",
	lootPick: "games.terraria.operations.lootPick",
	lootDecline: "games.terraria.operations.lootDecline",
	shareTake: "games.terraria.operations.shareTake",
	shareCoins: "games.terraria.operations.shareCoins",
	reduceThreat: "games.terraria.operations.reduceThreat",
	loot: "games.terraria.operations.loot",
	gain: "games.terraria.operations.gain",
	shareResource: "games.terraria.operations.shareResource",
	coins: "games.terraria.operations.coins",
	resource: "games.terraria.operations.resource",
	ropeAward: "games.terraria.operations.ropeAward",
	platformAward: "games.terraria.operations.platformAward",
	scrapCard: "games.terraria.operations.scrapCard",
	card: "games.terraria.operations.card",
	ready: "games.terraria.operations.ready",
	unready: "games.terraria.operations.unready",
	assistDraw: "games.terraria.operations.assistDraw",
	assistSplit: "games.terraria.operations.assistSplit",
	discardDraw: "games.terraria.operations.discardDraw",
	discardCard: "games.terraria.operations.discardCard",
	keepDraw: "games.terraria.operations.keepDraw",
	fetchCard: "games.terraria.operations.fetchCard",
	springScrap: "games.terraria.operations.springScrap",
	copyEffect: "games.terraria.operations.copyEffect",
	markEnemy: "games.terraria.operations.markEnemy",
	discover: "games.terraria.operations.discover",
	reveal: "games.terraria.operations.reveal",
	move: "games.terraria.operations.move",
	ropeMove: "games.terraria.operations.ropeMove",
	hook: "games.terraria.operations.hook",
	teleport: "games.terraria.operations.teleport",
	travel: "games.terraria.operations.travel",
	tool: "games.terraria.operations.tool",
	chop: "games.terraria.operations.chop",
	dig: "games.terraria.operations.dig",
	chest: "games.terraria.operations.chest",
	chestPick: "games.terraria.operations.chestPick",
	craft: "games.terraria.operations.craft",
	nightsEdge: "games.terraria.operations.nightsEdge",
	forgeEdge: "games.terraria.operations.forgeEdge",
	craftToken: "games.terraria.operations.craftToken",
	reclaimToken: "games.terraria.operations.reclaimToken",
	house: "games.terraria.operations.house",
	platform: "games.terraria.operations.platform",
	freePlatform: "games.terraria.operations.freePlatform",
	rope: "games.terraria.operations.rope",
	pylon: "games.terraria.operations.pylon",
	collect: "games.terraria.operations.collect",
	unlock: "games.terraria.operations.unlock",
	spawnNpc: "games.terraria.operations.spawnNpc",
	buyAction: "games.terraria.operations.buyAction",
	buyConsumable: "games.terraria.operations.buyConsumable",
	nurse: "games.terraria.operations.nurse",
	goblin: "games.terraria.operations.goblin",
	bottle: "games.terraria.operations.bottle",
	food: "games.terraria.operations.food",
	objective: "games.terraria.operations.objective",
	focus: "games.terraria.operations.focus",
	donate: "games.terraria.operations.donate",
	donateTo: "games.terraria.operations.donateTo",
	donateResource: "games.terraria.operations.donateResource",
	donateCoins: "games.terraria.operations.donateCoins",
	donateTokens: "games.terraria.operations.donateTokens",
	donateItem: "games.terraria.operations.donateItem",
	weapon: "games.terraria.operations.weapon",
	weaponTarget: "games.terraria.operations.weaponTarget",
	finisherTarget: "games.terraria.operations.finisherTarget",
	minion: "games.terraria.operations.minion",
	summonEye: "games.terraria.operations.summonEye",
	consumable: "games.terraria.operations.consumable",
	useConsumable: "games.terraria.operations.useConsumable",
	throwTarget: "games.terraria.operations.throwTarget",
	explode: "games.terraria.operations.explode",
	finishTargets: "games.terraria.operations.finishTargets",
	pierceTarget: "games.terraria.operations.pierceTarget",
	dropDie: "games.terraria.operations.dropDie",
	modifyDie: "games.terraria.operations.modifyDie",
	roll: "games.terraria.operations.roll",
	boost: "games.terraria.operations.boost",
	reroll: "games.terraria.operations.reroll",
	resolveBattle: "games.terraria.operations.resolveBattle",
	spawnPick: "games.terraria.operations.spawnPick",
	activate: "games.terraria.operations.activate",
	enemyTarget: "games.terraria.operations.enemyTarget",
	enemyMove: "games.terraria.operations.enemyMove",
	enemyHit: "games.terraria.operations.enemyHit",
	bossBuff: "games.terraria.operations.bossBuff",
	wallThreat: "games.terraria.operations.wallThreat",
	wallFire: "games.terraria.operations.wallFire",
	bossTeleport: "games.terraria.operations.bossTeleport",
	bossTarget: "games.terraria.operations.bossTarget",
	bossMove: "games.terraria.operations.bossMove",
	wormTeleport: "games.terraria.operations.wormTeleport",
	displaceWho: "games.terraria.operations.displaceWho",
	displaceTo: "games.terraria.operations.displaceTo",
	copyCard: "games.terraria.operations.copyCard",
	readyAP: "games.terraria.operations.readyAP",
	drop: "games.terraria.operations.drop",
	giftCraft: "games.terraria.operations.giftCraft",
	preventSpawn: "games.terraria.operations.preventSpawn",
	spawnAllowed: "games.terraria.operations.spawnAllowed",
	retaliate: "games.terraria.operations.retaliate"
}, Rn = {
	inventory: "games.terraria.prompts.inventory",
	loot: "games.terraria.prompts.loot",
	share: "games.terraria.prompts.share",
	reward: "games.terraria.prompts.reward",
	scrap: "games.terraria.prompts.scrap",
	assist: "games.terraria.prompts.assist",
	discard: "games.terraria.prompts.discard",
	keep: "games.terraria.prompts.keep",
	fetch: "games.terraria.prompts.fetch",
	teleport: "games.terraria.prompts.teleport",
	copy: "games.terraria.prompts.copy",
	attackTarget: "games.terraria.prompts.attackTarget",
	explosive: "games.terraria.prompts.explosive",
	discover: "games.terraria.prompts.discover",
	objectives: "games.terraria.prompts.objectives",
	enemyTarget: "games.terraria.prompts.enemyTarget",
	enemyMove: "games.terraria.prompts.enemyMove",
	enemyAttackOrder: "games.terraria.prompts.enemyAttackOrder",
	bossBuff: "games.terraria.prompts.bossBuff",
	displace: "games.terraria.prompts.displace",
	bossTeleport: "games.terraria.prompts.bossTeleport",
	bossMove: "games.terraria.prompts.bossMove",
	consumable: "games.terraria.prompts.consumable",
	enter: "games.terraria.prompts.enter",
	chest: "games.terraria.prompts.chest",
	scrapEquipment: "games.terraria.prompts.scrapEquipment",
	reclaim: "games.terraria.prompts.reclaim",
	platform: "games.terraria.prompts.platform",
	donate: "games.terraria.prompts.donate",
	spawn: "games.terraria.prompts.spawn",
	wallBuff: "games.terraria.prompts.wallBuff",
	preventSpawn: "games.terraria.prompts.preventSpawn",
	retaliation: "games.terraria.prompts.retaliation"
}, zn = {
	e0: "games.terraria.items.e0",
	e1: "games.terraria.items.e1",
	e2: "games.terraria.items.e2",
	e3: "games.terraria.items.e3",
	e4: "games.terraria.items.e4",
	e5: "games.terraria.items.e5",
	e6: "games.terraria.items.e6",
	e7: "games.terraria.items.e7",
	e8: "games.terraria.items.e8",
	e9: "games.terraria.items.e9",
	e10: "games.terraria.items.e10",
	e11: "games.terraria.items.e11",
	e12: "games.terraria.items.e12",
	e13: "games.terraria.items.e13",
	e14: "games.terraria.items.e14",
	e15: "games.terraria.items.e15",
	e16: "games.terraria.items.e16",
	e17: "games.terraria.items.e17",
	e18: "games.terraria.items.e18",
	e19: "games.terraria.items.e19",
	e20: "games.terraria.items.e20",
	e21: "games.terraria.items.e21",
	e22: "games.terraria.items.e22",
	e23: "games.terraria.items.e23",
	e24: "games.terraria.items.e24",
	e25: "games.terraria.items.e25",
	e26: "games.terraria.items.e26",
	e27: "games.terraria.items.e27",
	e28: "games.terraria.items.e28",
	e29: "games.terraria.items.e29",
	e30: "games.terraria.items.e30",
	e31: "games.terraria.items.e31",
	e32: "games.terraria.items.e32",
	e33: "games.terraria.items.e33",
	e34: "games.terraria.items.e34",
	e35: "games.terraria.items.e35",
	e36: "games.terraria.items.e36",
	e37: "games.terraria.items.e37",
	e38: "games.terraria.items.e38",
	e39: "games.terraria.items.e39",
	e41: "games.terraria.items.e41",
	e42: "games.terraria.items.e42",
	e43: "games.terraria.items.e43",
	e44: "games.terraria.items.e44",
	e45: "games.terraria.items.e45",
	e46: "games.terraria.items.e46",
	e48: "games.terraria.items.e48",
	e49: "games.terraria.items.e49",
	e50: "games.terraria.items.e50",
	e51: "games.terraria.items.e51",
	e52: "games.terraria.items.e52",
	e53: "games.terraria.items.e53",
	e54: "games.terraria.items.e54",
	e55: "games.terraria.items.e55",
	e56: "games.terraria.items.e56",
	e57: "games.terraria.items.e57",
	e58: "games.terraria.items.e58",
	e59: "games.terraria.items.e59",
	e60: "games.terraria.items.e60",
	e61: "games.terraria.items.e61",
	c0: "games.terraria.items.c0",
	c1: "games.terraria.items.c1",
	c2: "games.terraria.items.c2",
	c3: "games.terraria.items.c3",
	c4: "games.terraria.items.c4",
	c5: "games.terraria.items.c5",
	c6: "games.terraria.items.c6",
	c7: "games.terraria.items.c7",
	c8: "games.terraria.items.c8",
	c9: "games.terraria.items.c9",
	c10: "games.terraria.items.c10",
	c11: "games.terraria.items.c11",
	c12: "games.terraria.items.c12",
	c13: "games.terraria.items.c13",
	c14: "games.terraria.items.c14",
	c15: "games.terraria.items.c15",
	c16: "games.terraria.items.c16",
	c17: "games.terraria.items.c17",
	c20: "games.terraria.items.c20",
	c21: "games.terraria.items.c21",
	r8: "games.terraria.items.r8",
	r9: "games.terraria.items.r9",
	r10: "games.terraria.items.r10",
	r11: "games.terraria.items.r11",
	r12: "games.terraria.items.r12",
	r13: "games.terraria.items.r13",
	r14: "games.terraria.items.r14",
	r15: "games.terraria.items.r15",
	r16: "games.terraria.items.r16",
	r17: "games.terraria.items.r17",
	r19: "games.terraria.items.r19",
	r20: "games.terraria.items.r20",
	r21: "games.terraria.items.r21",
	r22: "games.terraria.items.r22",
	r23: "games.terraria.items.r23",
	r24: "games.terraria.items.r24",
	r25: "games.terraria.items.r25",
	a0: "games.terraria.items.a0",
	a1: "games.terraria.items.a1",
	a2: "games.terraria.items.a2",
	a3: "games.terraria.items.a3",
	a4: "games.terraria.items.a4",
	a5: "games.terraria.items.a5",
	a6: "games.terraria.items.a6",
	a7: "games.terraria.items.a7",
	a8: "games.terraria.items.a8",
	a9: "games.terraria.items.a9",
	a10: "games.terraria.items.a10",
	a11: "games.terraria.items.a11",
	a12: "games.terraria.items.a12",
	a13: "games.terraria.items.a13",
	a14: "games.terraria.items.a14",
	a15: "games.terraria.items.a15",
	a16: "games.terraria.items.a16",
	a17: "games.terraria.items.a17",
	a18: "games.terraria.items.a18",
	a19: "games.terraria.items.a19",
	a20: "games.terraria.items.a20",
	a21: "games.terraria.items.a21",
	a22: "games.terraria.items.a22",
	a23: "games.terraria.items.a23",
	a24: "games.terraria.items.a24",
	a25: "games.terraria.items.a25",
	a26: "games.terraria.items.a26",
	a27: "games.terraria.items.a27",
	a28: "games.terraria.items.a28",
	a29: "games.terraria.items.a29",
	a30: "games.terraria.items.a30",
	a31: "games.terraria.items.a31",
	a32: "games.terraria.items.a32",
	a33: "games.terraria.items.a33",
	a34: "games.terraria.items.a34",
	a35: "games.terraria.items.a35",
	a36: "games.terraria.items.a36",
	a37: "games.terraria.items.a37",
	a38: "games.terraria.items.a38",
	a39: "games.terraria.items.a39",
	a40: "games.terraria.items.a40",
	a41: "games.terraria.items.a41",
	a42: "games.terraria.items.a42",
	a43: "games.terraria.items.a43",
	a44: "games.terraria.items.a44",
	a45: "games.terraria.items.a45",
	a46: "games.terraria.items.a46",
	a47: "games.terraria.items.a47",
	a48: "games.terraria.items.a48",
	a49: "games.terraria.items.a49",
	a50: "games.terraria.items.a50",
	a51: "games.terraria.items.a51",
	a52: "games.terraria.items.a52",
	a53: "games.terraria.items.a53",
	a54: "games.terraria.items.a54",
	a55: "games.terraria.items.a55",
	a56: "games.terraria.items.a56",
	a57: "games.terraria.items.a57",
	a58: "games.terraria.items.a58",
	s0: "games.terraria.items.s0",
	s1: "games.terraria.items.s1",
	s2: "games.terraria.items.s2",
	s3: "games.terraria.items.s3",
	s4: "games.terraria.items.s4",
	s5: "games.terraria.items.s5",
	o0: "games.terraria.items.o0",
	o1: "games.terraria.items.o1",
	o2: "games.terraria.items.o2",
	o3: "games.terraria.items.o3",
	o4: "games.terraria.items.o4",
	o5: "games.terraria.items.o5",
	o6: "games.terraria.items.o6",
	o7: "games.terraria.items.o7",
	o8: "games.terraria.items.o8",
	o9: "games.terraria.items.o9",
	o10: "games.terraria.items.o10",
	o11: "games.terraria.items.o11",
	o12: "games.terraria.items.o12",
	o13: "games.terraria.items.o13",
	o14: "games.terraria.items.o14",
	o15: "games.terraria.items.o15",
	o16: "games.terraria.items.o16",
	o17: "games.terraria.items.o17",
	o18: "games.terraria.items.o18",
	o19: "games.terraria.items.o19",
	o20: "games.terraria.items.o20",
	o21: "games.terraria.items.o21",
	o22: "games.terraria.items.o22",
	o23: "games.terraria.items.o23",
	o24: "games.terraria.items.o24",
	o25: "games.terraria.items.o25",
	o26: "games.terraria.items.o26",
	o27: "games.terraria.items.o27",
	o28: "games.terraria.items.o28",
	o29: "games.terraria.items.o29",
	o30: "games.terraria.items.o30",
	o31: "games.terraria.items.o31",
	o32: "games.terraria.items.o32",
	o33: "games.terraria.items.o33",
	o34: "games.terraria.items.o34",
	o35: "games.terraria.items.o35",
	o36: "games.terraria.items.o36",
	o37: "games.terraria.items.o37",
	o38: "games.terraria.items.o38",
	o39: "games.terraria.items.o39",
	o40: "games.terraria.items.o40",
	o41: "games.terraria.items.o41",
	o42: "games.terraria.items.o42",
	o43: "games.terraria.items.o43",
	o44: "games.terraria.items.o44",
	o45: "games.terraria.items.o45",
	o46: "games.terraria.items.o46",
	o47: "games.terraria.items.o47",
	o48: "games.terraria.items.o48",
	o49: "games.terraria.items.o49",
	o50: "games.terraria.items.o50",
	o51: "games.terraria.items.o51",
	o52: "games.terraria.items.o52",
	o53: "games.terraria.items.o53",
	o54: "games.terraria.items.o54",
	o55: "games.terraria.items.o55",
	wood: "games.terraria.items.wood",
	gel: "games.terraria.items.gel",
	stone: "games.terraria.items.stone",
	cobweb: "games.terraria.items.cobweb",
	copper: "games.terraria.items.copper",
	iron: "games.terraria.items.iron",
	silver: "games.terraria.items.silver",
	gold: "games.terraria.items.gold",
	demonite: "games.terraria.items.demonite",
	crimtane: "games.terraria.items.crimtane",
	hellstone: "games.terraria.items.hellstone",
	gem: "games.terraria.items.gem",
	lens: "games.terraria.items.lens",
	bone: "games.terraria.items.bone",
	flinxFur: "games.terraria.items.flinxFur",
	workbench: "games.terraria.items.workbench",
	anvil: "games.terraria.items.anvil",
	loom: "games.terraria.items.loom",
	bottle: "games.terraria.items.bottle",
	cookingPot: "games.terraria.items.cookingPot",
	bed: "games.terraria.items.bed",
	hellforge: "games.terraria.items.hellforge",
	platform: "games.terraria.items.platform",
	rope: "games.terraria.items.rope",
	platforms: "games.terraria.items.platforms",
	ropes: "games.terraria.items.ropes",
	guide: "games.terraria.items.guide",
	merchant: "games.terraria.items.merchant",
	nurse: "games.terraria.items.nurse",
	goblin: "games.terraria.items.goblin",
	demolitionist: "games.terraria.items.demolitionist",
	dryad: "games.terraria.items.dryad",
	kingSlime: "games.terraria.items.kingSlime",
	eye: "games.terraria.items.eye",
	eater: "games.terraria.items.eater",
	brain: "games.terraria.items.brain",
	queenBee: "games.terraria.items.queenBee",
	wall: "games.terraria.items.wall",
	boss: "games.terraria.items.boss",
	fire: "games.terraria.items.fire",
	frozen: "games.terraria.items.frozen",
	poison: "games.terraria.items.poison",
	Orb4: "games.terraria.items.Orb4",
	Heart4: "games.terraria.items.Heart4",
	Larva: "games.terraria.items.Larva",
	Altar: "games.terraria.items.Altar",
	"Green Slime": "games.terraria.items.Green Slime",
	"Blue Slime": "games.terraria.items.Blue Slime",
	"Red Slime": "games.terraria.items.Red Slime",
	"Yellow Slime": "games.terraria.items.Yellow Slime",
	"Black Slime": "games.terraria.items.Black Slime",
	"Lava Slime": "games.terraria.items.Lava Slime",
	"Demon Eye": "games.terraria.items.Demon Eye",
	Zombie: "games.terraria.items.Zombie",
	"Giant Worm": "games.terraria.items.Giant Worm",
	"Cave Bat": "games.terraria.items.Cave Bat",
	Hellbat: "games.terraria.items.Hellbat",
	Skeleton: "games.terraria.items.Skeleton",
	Salamander: "games.terraria.items.Salamander",
	Vulture: "games.terraria.items.Vulture",
	Antlion: "games.terraria.items.Antlion",
	"Sand Slime": "games.terraria.items.Sand Slime",
	"Antlion Swarmer": "games.terraria.items.Antlion Swarmer",
	"Tomb Crawler": "games.terraria.items.Tomb Crawler",
	"Fire Imp": "games.terraria.items.Fire Imp",
	Snatcher: "games.terraria.items.Snatcher",
	"Jungle Slime": "games.terraria.items.Jungle Slime",
	"Spiked Jungle Slime": "games.terraria.items.Spiked Jungle Slime",
	"Jungle Bat": "games.terraria.items.Jungle Bat",
	Hornet: "games.terraria.items.Hornet",
	"Ice Slime": "games.terraria.items.Ice Slime",
	"Frozen Zombie": "games.terraria.items.Frozen Zombie",
	"Ice Bat": "games.terraria.items.Ice Bat",
	"Snow Flinx": "games.terraria.items.Snow Flinx",
	Crimera: "games.terraria.items.Crimera",
	"Blood Crawler": "games.terraria.items.Blood Crawler",
	"Eater of Souls": "games.terraria.items.Eater of Souls",
	Devourer: "games.terraria.items.Devourer",
	"Voodoo Demon": "games.terraria.items.Voodoo Demon",
	"Life Crystal": "games.terraria.items.Life Crystal",
	"Fallen Star": "games.terraria.items.Fallen Star",
	"Angry Bones": "games.terraria.items.Angry Bones",
	"Baby Slime": "games.terraria.items.Baby Slime"
}, Bn = {
	ap: "games.terraria.effects.ap",
	attack: "games.terraria.effects.attack",
	defense: "games.terraria.effects.defense",
	health: "games.terraria.effects.health",
	lowHeal: "games.terraria.effects.lowHeal",
	mana: "games.terraria.effects.mana",
	coins: "games.terraria.effects.coins",
	assist: "games.terraria.effects.assist",
	draw: "games.terraria.effects.draw",
	drawKeep: "games.terraria.effects.drawKeep",
	drawDiscard: "games.terraria.effects.drawDiscard",
	discardDraw: "games.terraria.effects.discardDraw",
	freePlatforms: "games.terraria.effects.freePlatforms",
	clearOthers: "games.terraria.effects.clearOthers",
	fetch: "games.terraria.effects.fetch",
	scrap: "games.terraria.effects.scrap",
	springScrap: "games.terraria.effects.springScrap",
	copy: "games.terraria.effects.copy",
	deescalate: "games.terraria.effects.deescalate",
	teleport: "games.terraria.effects.teleport",
	finisher: "games.terraria.effects.finisher",
	industry: "games.terraria.effects.industry",
	rally: "games.terraria.effects.rally",
	yield: "games.terraria.effects.yield",
	freeDonate: "games.terraria.effects.freeDonate",
	doubleConsumable: "games.terraria.effects.doubleConsumable",
	enemyAttackReroll: "games.terraria.effects.enemyAttackReroll",
	enemyDefenseReroll: "games.terraria.effects.enemyDefenseReroll",
	shakedown: "games.terraria.effects.shakedown",
	duplicateDefense: "games.terraria.effects.duplicateDefense",
	regenKill: "games.terraria.effects.regenKill",
	radar: "games.terraria.effects.radar",
	enemySmallAttackDemote: "games.terraria.effects.enemySmallAttackDemote",
	enemySmallDefenseDemote: "games.terraria.effects.enemySmallDefenseDemote",
	enemyLargeAttackDemote: "games.terraria.effects.enemyLargeAttackDemote",
	enemyLargeDefenseDemote: "games.terraria.effects.enemyLargeDefenseDemote",
	enemyRemoveAttack: "games.terraria.effects.enemyRemoveAttack",
	enemyRemoveDefense: "games.terraria.effects.enemyRemoveDefense",
	punchbag: "games.terraria.effects.punchbag",
	foresight: "games.terraria.effects.foresight",
	duplicateAttack: "games.terraria.effects.duplicateAttack",
	defenseReroll: "games.terraria.effects.defenseReroll",
	promoteAttack: "games.terraria.effects.promoteAttack",
	promoteDefense: "games.terraria.effects.promoteDefense",
	immune: "games.terraria.effects.immune",
	stockpile: "games.terraria.effects.stockpile",
	speed: "games.terraria.effects.speed",
	climb: "games.terraria.effects.climb",
	archery: "games.terraria.effects.archery",
	magic: "games.terraria.effects.magic",
	dryad: "games.terraria.effects.dryad",
	necro: "games.terraria.effects.necro"
}, Vn = {
	o0: "games.terraria.objectiveConditions.o0",
	o1: "games.terraria.objectiveConditions.o1",
	o2: "games.terraria.objectiveConditions.o2",
	o3: "games.terraria.objectiveConditions.o3",
	o4: "games.terraria.objectiveConditions.o4",
	o5: "games.terraria.objectiveConditions.o5",
	o6: "games.terraria.objectiveConditions.o6",
	o7: "games.terraria.objectiveConditions.o7",
	o8: "games.terraria.objectiveConditions.o8",
	o9: "games.terraria.objectiveConditions.o9",
	o10: "games.terraria.objectiveConditions.o10",
	o11: "games.terraria.objectiveConditions.o11",
	o12: "games.terraria.objectiveConditions.o12",
	o13: "games.terraria.objectiveConditions.o13",
	o14: "games.terraria.objectiveConditions.o14",
	o15: "games.terraria.objectiveConditions.o15",
	o16: "games.terraria.objectiveConditions.o16",
	o17: "games.terraria.objectiveConditions.o17",
	o18: "games.terraria.objectiveConditions.o18",
	o19: "games.terraria.objectiveConditions.o19",
	o20: "games.terraria.objectiveConditions.o20",
	o21: "games.terraria.objectiveConditions.o21",
	o22: "games.terraria.objectiveConditions.o22",
	o23: "games.terraria.objectiveConditions.o23",
	o24: "games.terraria.objectiveConditions.o24",
	o25: "games.terraria.objectiveConditions.o25",
	o26: "games.terraria.objectiveConditions.o26",
	o27: "games.terraria.objectiveConditions.o27",
	o28: "games.terraria.objectiveConditions.o28",
	o29: "games.terraria.objectiveConditions.o29",
	o30: "games.terraria.objectiveConditions.o30",
	o31: "games.terraria.objectiveConditions.o31",
	o32: "games.terraria.objectiveConditions.o32",
	o33: "games.terraria.objectiveConditions.o33",
	o34: "games.terraria.objectiveConditions.o34",
	o35: "games.terraria.objectiveConditions.o35",
	o36: "games.terraria.objectiveConditions.o36",
	o37: "games.terraria.objectiveConditions.o37",
	o38: "games.terraria.objectiveConditions.o38",
	o39: "games.terraria.objectiveConditions.o39",
	o40: "games.terraria.objectiveConditions.o40",
	o41: "games.terraria.objectiveConditions.o41",
	o42: "games.terraria.objectiveConditions.o42",
	o43: "games.terraria.objectiveConditions.o43",
	o44: "games.terraria.objectiveConditions.o44",
	o45: "games.terraria.objectiveConditions.o45",
	o46: "games.terraria.objectiveConditions.o46",
	o47: "games.terraria.objectiveConditions.o47",
	o48: "games.terraria.objectiveConditions.o48",
	o49: "games.terraria.objectiveConditions.o49",
	o50: "games.terraria.objectiveConditions.o50",
	o51: "games.terraria.objectiveConditions.o51",
	o52: "games.terraria.objectiveConditions.o52",
	o53: "games.terraria.objectiveConditions.o53",
	o54: "games.terraria.objectiveConditions.o54",
	o55: "games.terraria.objectiveConditions.o55",
	o9Small: "games.terraria.objectiveConditions.o9Small",
	o27Small: "games.terraria.objectiveConditions.o27Small",
	o39Small: "games.terraria.objectiveConditions.o39Small",
	o42Small: "games.terraria.objectiveConditions.o42Small",
	o44Small: "games.terraria.objectiveConditions.o44Small",
	o46Small: "games.terraria.objectiveConditions.o46Small",
	o49Small: "games.terraria.objectiveConditions.o49Small",
	o53Small: "games.terraria.objectiveConditions.o53Small",
	o54Small: "games.terraria.objectiveConditions.o54Small"
}, Hn = {
	o0: "games.terraria.objectiveRewards.o0",
	o1: "games.terraria.objectiveRewards.o1",
	o2: "games.terraria.objectiveRewards.o2",
	o3: "games.terraria.objectiveRewards.o3",
	o4: "games.terraria.objectiveRewards.o4",
	o5: "games.terraria.objectiveRewards.o5",
	o6: "games.terraria.objectiveRewards.o6",
	o7: "games.terraria.objectiveRewards.o7",
	o8: "games.terraria.objectiveRewards.o8",
	o9: "games.terraria.objectiveRewards.o9",
	o10: "games.terraria.objectiveRewards.o10",
	o11: "games.terraria.objectiveRewards.o11",
	o12: "games.terraria.objectiveRewards.o12",
	o13: "games.terraria.objectiveRewards.o13",
	o14: "games.terraria.objectiveRewards.o14",
	o15: "games.terraria.objectiveRewards.o15",
	o16: "games.terraria.objectiveRewards.o16",
	o17: "games.terraria.objectiveRewards.o17",
	o18: "games.terraria.objectiveRewards.o18",
	o19: "games.terraria.objectiveRewards.o19",
	o20: "games.terraria.objectiveRewards.o20",
	o21: "games.terraria.objectiveRewards.o21",
	o22: "games.terraria.objectiveRewards.o22",
	o23: "games.terraria.objectiveRewards.o23",
	o24: "games.terraria.objectiveRewards.o24",
	o25: "games.terraria.objectiveRewards.o25",
	o26: "games.terraria.objectiveRewards.o26",
	o27: "games.terraria.objectiveRewards.o27",
	o28: "games.terraria.objectiveRewards.o28",
	o29: "games.terraria.objectiveRewards.o29",
	o30: "games.terraria.objectiveRewards.o30",
	o31: "games.terraria.objectiveRewards.o31",
	o32: "games.terraria.objectiveRewards.o32",
	o33: "games.terraria.objectiveRewards.o33",
	o34: "games.terraria.objectiveRewards.o34",
	o35: "games.terraria.objectiveRewards.o35",
	o36: "games.terraria.objectiveRewards.o36",
	o37: "games.terraria.objectiveRewards.o37",
	o38: "games.terraria.objectiveRewards.o38",
	o39: "games.terraria.objectiveRewards.o39",
	o40: "games.terraria.objectiveRewards.o40",
	o41: "games.terraria.objectiveRewards.o41",
	o42: "games.terraria.objectiveRewards.o42",
	o43: "games.terraria.objectiveRewards.o43",
	o44: "games.terraria.objectiveRewards.o44",
	o45: "games.terraria.objectiveRewards.o45",
	o46: "games.terraria.objectiveRewards.o46",
	o47: "games.terraria.objectiveRewards.o47",
	o48: "games.terraria.objectiveRewards.o48",
	o49: "games.terraria.objectiveRewards.o49",
	o50: "games.terraria.objectiveRewards.o50",
	o51: "games.terraria.objectiveRewards.o51",
	o52: "games.terraria.objectiveRewards.o52",
	o53: "games.terraria.objectiveRewards.o53",
	o54: "games.terraria.objectiveRewards.o54",
	o55: "games.terraria.objectiveRewards.o55",
	o0Small: "games.terraria.objectiveRewards.o0Small",
	o2Small: "games.terraria.objectiveRewards.o2Small",
	o4Small: "games.terraria.objectiveRewards.o4Small",
	o10Small: "games.terraria.objectiveRewards.o10Small",
	o11Small: "games.terraria.objectiveRewards.o11Small",
	o14Small: "games.terraria.objectiveRewards.o14Small",
	o20Small: "games.terraria.objectiveRewards.o20Small",
	o21Small: "games.terraria.objectiveRewards.o21Small",
	o30Small: "games.terraria.objectiveRewards.o30Small",
	o32Small: "games.terraria.objectiveRewards.o32Small",
	o33Small: "games.terraria.objectiveRewards.o33Small"
}, Un = {
	start: "games.terraria.events.start",
	threat: "games.terraria.events.threat",
	debuff: "games.terraria.events.debuff",
	death: "games.terraria.events.death",
	damage: "games.terraria.events.damage",
	fall: "games.terraria.events.fall",
	spawn: "games.terraria.events.spawn",
	discover: "games.terraria.events.discover",
	gain: "games.terraria.events.gain",
	fight: "games.terraria.events.fight",
	defeat: "games.terraria.events.defeat",
	transform: "games.terraria.events.transform",
	objective: "games.terraria.events.objective",
	draw: "games.terraria.events.draw",
	round: "games.terraria.events.round",
	escape: "games.terraria.events.escape",
	boss: "games.terraria.events.boss",
	resource: "games.terraria.events.resource",
	play: "games.terraria.events.play",
	move: "games.terraria.events.move",
	chop: "games.terraria.events.chop",
	dig: "games.terraria.events.dig",
	craft: "games.terraria.events.craft",
	npc: "games.terraria.events.npc",
	use: "games.terraria.events.use",
	roll: "games.terraria.events.roll"
}, Wn = {
	"#": "games.terraria.tokenNames.#",
	s: "games.terraria.tokenNames.s",
	cu: "games.terraria.tokenNames.cu",
	fe: "games.terraria.tokenNames.fe",
	ag: "games.terraria.tokenNames.ag",
	au: "games.terraria.tokenNames.au",
	g: "games.terraria.tokenNames.g",
	de: "games.terraria.tokenNames.de",
	cr: "games.terraria.tokenNames.cr",
	es: "games.terraria.tokenNames.es",
	cs: "games.terraria.tokenNames.cs",
	hs: "games.terraria.tokenNames.hs",
	ice: "games.terraria.tokenNames.ice",
	he: "games.terraria.tokenNames.he",
	".": "games.terraria.tokenNames.empty",
	S: "games.terraria.tokenNames.S",
	C1: "games.terraria.tokenNames.C1",
	C2: "games.terraria.tokenNames.C2",
	T1: "games.terraria.tokenNames.T1",
	T2: "games.terraria.tokenNames.T2",
	T3: "games.terraria.tokenNames.T3",
	W: "games.terraria.tokenNames.W",
	L: "games.terraria.tokenNames.L",
	Altar: "games.terraria.tokenNames.Altar",
	Orb4: "games.terraria.tokenNames.Orb4",
	Heart4: "games.terraria.tokenNames.Heart4",
	Larva: "games.terraria.tokenNames.Larva"
}, Gn = {
	prepare: "games.terraria.phase.prepare",
	character: "games.terraria.phase.character",
	enemy: "games.terraria.phase.enemy",
	environment: "games.terraria.phase.environment",
	done: "games.terraria.phase.done"
}, Kn = {
	dig: "games.terraria.objectChain.dig",
	build: "games.terraria.objectChain.build",
	fight: "games.terraria.objectChain.fight",
	explore: "games.terraria.objectChain.explore"
}, qn = {
	c0: "games.terraria.consumableEffects.c0",
	c1: "games.terraria.consumableEffects.c1",
	c2: "games.terraria.consumableEffects.c2",
	c3: "games.terraria.consumableEffects.c3",
	c4: "games.terraria.consumableEffects.c4",
	c5: "games.terraria.consumableEffects.c5",
	c6: "games.terraria.consumableEffects.c6",
	c7: "games.terraria.consumableEffects.c7",
	c8: "games.terraria.consumableEffects.c8",
	c9: "games.terraria.consumableEffects.c9",
	c10: "games.terraria.consumableEffects.c10",
	c11: "games.terraria.consumableEffects.c11",
	c12: "games.terraria.consumableEffects.c12",
	c13: "games.terraria.consumableEffects.c13",
	c14: "games.terraria.consumableEffects.c14",
	c15: "games.terraria.consumableEffects.c15",
	c16: "games.terraria.consumableEffects.c16",
	c17: "games.terraria.consumableEffects.c17",
	c20: "games.terraria.consumableEffects.c20",
	c21: "games.terraria.consumableEffects.c21"
}, Jn = {
	kingSlime0: "games.terraria.bossEffects.kingSlime0",
	kingSlime1: "games.terraria.bossEffects.kingSlime1",
	kingSlime2: "games.terraria.bossEffects.kingSlime2",
	kingSlime3: "games.terraria.bossEffects.kingSlime3",
	eye0: "games.terraria.bossEffects.eye0",
	eye1: "games.terraria.bossEffects.eye1",
	eye2: "games.terraria.bossEffects.eye2",
	eye3: "games.terraria.bossEffects.eye3",
	queenBee0: "games.terraria.bossEffects.queenBee0",
	queenBee1: "games.terraria.bossEffects.queenBee1",
	queenBee2: "games.terraria.bossEffects.queenBee2",
	queenBee3: "games.terraria.bossEffects.queenBee3",
	wall0: "games.terraria.bossEffects.wall0",
	wall1: "games.terraria.bossEffects.wall1",
	wall2: "games.terraria.bossEffects.wall2",
	wall3: "games.terraria.bossEffects.wall3"
}, Yn = {
	r15: "games.terraria.armorEffects.r15",
	r16: "games.terraria.armorEffects.r16",
	r19: "games.terraria.armorEffects.r19",
	r20: "games.terraria.armorEffects.r20",
	r24: "games.terraria.armorEffects.r24",
	r25: "games.terraria.armorEffects.r25"
}, Q = (e, t) => {
	let n = e in zn ? e : O(e);
	return n in zn ? t(zn[n]) : e;
};
function Xn(e, t) {
	let n = e.kind === "flag" || e.kind === "teamBiome" || e.kind === "teamFlag" ? e.a : e.kind;
	return n in Bn ? t(Bn[n], { n: e.n ?? 1 }) : "";
}
function Zn(e, t, n, r) {
	let i = e.a ?? "", a = e.b ?? "", o = [
		"card",
		"ready",
		"readyAP",
		"scrapCard",
		"discardDraw",
		"discardCard",
		"keepDraw",
		"fetchCard",
		"springScrap"
	].includes(e.kind) ? t.people.find((e) => [
		...e.hand,
		...e.played,
		...e.discard,
		...e.scrapped
	].some((e) => e.uid === i)) : void 0, s = o && [
		...o.hand,
		...o.played,
		...o.discard,
		...o.scrapped
	].find((e) => e.uid === i), c = Q(s?.type ?? (e.kind === "fetchCard" ? a : i), n), l = Q(a, n), u = "", d = t.enemies.find((e) => e.uid === i), f = t.enemies.find((e) => e.uid === a);
	if (d && [
		"activate",
		"markEnemy",
		"pierceTarget",
		"retaliate",
		"enemyTarget",
		"enemyHit"
	].includes(e.kind) && (c = Q(d.name, n)), f && [
		"weaponTarget",
		"finisherTarget",
		"throwTarget",
		"explode"
	].includes(e.kind) && (l = Q(f.name, n)), t.people.some((e) => e.rid === i) && (c = r(i)), t.people.some((e) => e.rid === a) && (l = r(a)), e.kind === "store" && (l = n("games.terraria.slot", { n: Number(a) + 1 })), e.kind === "shareTake" && (l = r(e.who ?? ""), a === "shareCoins" && (c = n("games.terraria.coins")), a === "shareHealth" && (c = n("games.terraria.health"))), e.kind === "card" && s && (u = Xn(Se[s.type].branches[Number(e.flag)][e.n], n)), e.kind === "collect" && (c = Q(d?.name ?? "", n), u = e.n === 1 ? n("games.terraria.collectCoins") : n(d?.name === "Life Crystal" ? "games.terraria.collectHealth" : "games.terraria.collectMana")), e.kind === "chestPick") {
		let t = ue[Number(i)][(e.n ?? 0) + 1], r = /^(c|w|cu|fe|ag|au|he)(\d+)$/.exec(t);
		c = r ? r[1] === "c" ? n("games.terraria.effects.coins", { n: +r[2] }) : n("games.terraria.resourceReward", {
			n: +r[2],
			item: Q({
				w: "wood",
				cu: "copper",
				fe: "iron",
				ag: "silver",
				au: "gold",
				he: "hellstone"
			}[r[1]], n)
		}) : /^L[1-5]$/.test(t) ? n("games.terraria.lootLevel", { n: +t[1] }) : Q(t, n);
	}
	if (e.kind === "explode" && a.startsWith("ally:")) return n("games.terraria.operations.throwTarget", {
		item: c,
		target: n("games.terraria.brainAlly", { dice: Number(a.slice(5)) % 2 == 0 ? "2D6" : "D6 + D8" })
	});
	if (e.kind === "food" && (u = e.n === 0 ? n("games.terraria.effects.mana", { n: 2 }) : e.n === 1 ? n("games.terraria.effects.health", { n: 2 }) : e.n === 2 ? n("games.terraria.effects.ap", { n: 2 }) : n("games.terraria.effects.defense", { n: 2 })), e.kind === "useConsumable" && (u = a === "coins" ? n("games.terraria.effects.coins", { n: i === "c17" ? 8 : 5 }) : n("games.terraria.effect")), e.kind === "bossBuff") {
		let r = (t.boss?.id ?? "") + (e.n ?? 0);
		r in Jn && (u = n(Jn[r]));
	}
	a.startsWith("ally:") && (l = n("games.terraria.brainAlly", { dice: Number(a.slice(5)) % 2 == 0 ? "2D6" : "D6 + D8" })), e.kind === "modifyDie" && i in Bn && (u = n(Bn[i])), e.kind === "dropDie" && (c = n("games.terraria.die", { n: Number(i) })), e.kind === "giftCraft" && (c = Q(JSON.parse(i).a ?? "", n)), e.kind === "activate" && i === "boss" && (c = Q(t.boss?.id ?? "boss", n)), i.startsWith("icon:") && (c = n("games.terraria.selectTarget")), (a.startsWith("eye:") || a === "mouth" || a === "boss") && (l = Q(t.boss?.id ?? "boss", n));
	let ee = Ln[e.kind];
	return ee ? n(ee, {
		item: c,
		target: l,
		effect: u,
		n: e.n ?? 1
	}) : n("games.terraria.choose");
}
var Qn = (e) => e.map((e) => "D" + e).join(" · ");
function $n(e) {
	let t = w(e);
	return t ? t.dice.length ? Qn(t.dice) : t.chop ? String(t.chop) : String(t.dig) : "";
}
//#endregion
//#region src/games/terraria/board.tsx
var $ = 80;
function er({ mode: e, x: t, y: n }) {
	let r = s();
	return e !== "fly" && e !== "worm" ? null : /* @__PURE__ */ h("g", {
		transform: `translate(${t},${n})`,
		children: [
			/* @__PURE__ */ m("title", { children: r(e === "fly" ? "games.terraria.flying" : "games.terraria.burrowing") }),
			/* @__PURE__ */ m("circle", {
				r: "15",
				fill: "#332c32",
				stroke: "#ede3c4",
				strokeWidth: "1.5"
			}),
			e === "fly" ? /* @__PURE__ */ m("path", {
				d: "M-7 10Q-4 1-4-4Q1-4 8-11Q9-2 4 1L-2 2L3 3L-3 6Z",
				fill: "#f6f2e9"
			}) : /* @__PURE__ */ m("path", {
				d: "M5-8C-8-14-10 1 0 1S10 14-5 8M-1-12L-2-9M2 9L1 12",
				fill: "none",
				stroke: "#f6f2e9",
				strokeWidth: "4",
				strokeLinecap: "round"
			})
		]
	});
}
var tr = {
	underground: [
		"#9bd8e5",
		"#88705c",
		"#645965",
		"#4d414e",
		"#ac4737"
	],
	underworld: [
		"#f89765",
		"#925e58",
		"#65444b",
		"#493044",
		"#ac4737"
	],
	forest: [
		"#9bd8e5",
		"#88705c",
		"#645965",
		"#4d414e",
		"#ac4737"
	],
	desert: [
		"#e9d49f",
		"#b39a6b",
		"#887559",
		"#6b5552",
		"#ac4737"
	],
	snow: [
		"#bedde7",
		"#8fabb9",
		"#667c97",
		"#505969",
		"#ac4737"
	],
	jungle: [
		"#8fcdb5",
		"#698c60",
		"#4a6f58",
		"#3e594b",
		"#ac4737"
	],
	corruption: [
		"#b4a3d2",
		"#7a6b8d",
		"#665679",
		"#4f3b69",
		"#ac4737"
	],
	crimson: [
		"#d5a4a5",
		"#a06666",
		"#834e5b",
		"#603947",
		"#ac4737"
	],
	beach: [
		"#8ad5dc",
		"#c1ac7d",
		"#726769",
		"#62535b",
		"#ac4737"
	]
}, nr = {
	s: "#aeb5b1",
	cu: "#df8d5a",
	fe: "#c3b7ae",
	ag: "#d5e8ee",
	au: "#f3ce58",
	g: "#75d9e6",
	de: "#9677c9",
	cr: "#e76a6a",
	he: "#f28b48",
	ice: "#c5efff",
	es: "#7954a5",
	cs: "#b95769",
	hs: "#e0c38a"
};
function rr(e, t) {
	if (e.x !== void 0 && e.y !== void 0) return e.kind === "reveal" ? {
		x: e.x * 3 + 1,
		y: e.y * 5 + 2
	} : {
		x: e.x,
		y: e.y
	};
	let n = [
		"weaponTarget",
		"throwTarget",
		"enemyHit",
		"bossTarget",
		"wormTeleport"
	].includes(e.kind) ? e.b : e.a;
	if (!n) return null;
	let r = t.enemies.find((e) => e.uid === n), i = t.people.find((e) => e.rid === n);
	if (r || i) return r ?? i ?? null;
	if (n.startsWith("icon:")) {
		let [, e, t] = n.split(":");
		return {
			x: +e,
			y: +t
		};
	}
	if (t.boss) {
		if (n.startsWith("eye:")) return {
			x: t.boss.x + 1,
			y: t.boss.y - (n === "eye:0" ? 3 : 1)
		};
		if (n === "mouth") return {
			x: t.boss.x + 1,
			y: t.boss.y - 2
		};
		if (n === "boss" || n.startsWith("ally:")) return t.boss;
	}
	return null;
}
function ir({ pub: e, members: t, me: a, candidates: o, onChoose: l, nameOf: u, overview: f = !1, fit: ee = 0, focus: te = {
	x: 25,
	y: 4
} }) {
	let g = s(), ae = r(null), [_, oe] = i({
		w: 0,
		h: 0
	});
	n(() => {
		let e = ae.current, t = new ResizeObserver(() => oe({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let [v, y] = i(() => window.matchMedia("(max-width: 700px)").matches);
	n(() => {
		let e = window.matchMedia("(max-width: 700px)"), t = () => y(e.matches);
		return e.addEventListener("change", t), () => e.removeEventListener("change", t);
	}, []);
	let se = f ? 4080 : v ? 400 : 800, ce = f ? 2e3 : _.w ? se * _.h / _.w : 560, b = f ? 0 : Math.max(0, Math.min(40, te.x - (v ? 2 : 4))), x = f ? 0 : Math.max(0, Math.min(18, te.y - ce / $ * .58)), [le, ue] = i(null), [de, fe] = i(a);
	de !== a && (fe(a), ue(null));
	let S = (e) => ({
		x: (e.x - b) * $,
		y: e.y * $,
		w: $,
		h: $
	}), pe = /* @__PURE__ */ new Map();
	for (let t of o) {
		let n = rr(t, e);
		if (!n) continue;
		let r = n.x + ":" + n.y;
		pe.set(r, [...pe.get(r) ?? [], t]);
	}
	let me = e.world.flatMap((e) => e.cells.map((t, n) => ({
		x: e.x * 3 + n % 3,
		y: e.y * 5 + Math.floor(n / 3)
	})));
	for (let e of pe.keys()) {
		let [t, n] = e.split(":").map(Number);
		me.some((e) => e.x === t && e.y === n) || me.push({
			x: t,
			y: n
		});
	}
	let C = me.map((e) => ({
		key: e.x + ":" + e.y,
		rect: {
			...S(e),
			y: S(e).y - x * $
		}
	})), w = le ? pe.get(le) ?? [] : [], [T, he] = (le ?? "0:0").split(":").map(Number), ge = e.world.find((e) => e.x === Math.floor(T / 3) && e.y === Math.floor(he / 5))?.cells[he % 5 * 3 + T % 3], D = e.enemies.find((e) => e.x === T && e.y === he);
	return /* @__PURE__ */ h("div", {
		className: "terraria-map",
		ref: ae,
		children: [/* @__PURE__ */ m(re, {
			sheetW: se,
			sheetH: ce,
			fitKey: (f ? "world" : "camp") + ":" + ee + ":" + v + ":" + _.w + "x" + _.h,
			eligible: C,
			onTapEligible: (e) => {
				let t = pe.get(e) ?? [];
				t.length === 1 && t[0].kind !== "house" ? (l(t[0]), ue(null)) : ue(e);
			},
			highlight: "off",
			children: /* @__PURE__ */ h("g", {
				transform: `translate(0,${-x * $})`,
				children: [
					/* @__PURE__ */ h("defs", { children: [
						Object.keys(tr).map((e) => /* @__PURE__ */ m("pattern", {
							id: "terraria-ground-" + e,
							width: "160",
							height: "160",
							patternUnits: "userSpaceOnUse",
							children: /* @__PURE__ */ m("image", {
								href: e === "underground" ? "games/terraria/art-stone.webp" : "games/terraria/art-soil-" + (e === "beach" ? "desert" : e) + ".webp",
								width: "160",
								height: "160",
								preserveAspectRatio: "none"
							})
						}, e)),
						/* @__PURE__ */ m("pattern", {
							id: "terraria-rock-art",
							width: "160",
							height: "160",
							patternUnits: "userSpaceOnUse",
							children: /* @__PURE__ */ m("image", {
								href: "games/terraria/art-stone.webp",
								width: "160",
								height: "160",
								preserveAspectRatio: "none"
							})
						}),
						/* @__PURE__ */ m("pattern", {
							id: "terraria-soil",
							width: "36",
							height: "32",
							patternUnits: "userSpaceOnUse",
							children: /* @__PURE__ */ m("path", {
								d: "M2 10h6m13 14h9",
								stroke: "#211d29",
								opacity: ".12",
								strokeWidth: "3"
							})
						}),
						/* @__PURE__ */ m("pattern", {
							id: "terraria-stone",
							width: "80",
							height: "80",
							patternUnits: "userSpaceOnUse",
							children: /* @__PURE__ */ m("path", {
								d: "M0 28h31l12 17h37M22 0l9 28m12 17L29 80",
								fill: "none",
								stroke: "#302c3d",
								opacity: ".16",
								strokeWidth: "3"
							})
						})
					] }),
					Array.from({ length: 5 }, (e, t) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("rect", {
						x: -b * $,
						y: t * 400,
						width: 4080,
						height: 400,
						fill: [
							"#bae7ec",
							"#6d635b",
							"#4f4955",
							"#342c40",
							"#853f35"
						][t],
						opacity: ".32"
					}), /* @__PURE__ */ m("text", {
						x: (18 - b) * $ + 10,
						y: t * 400 + 36,
						fill: "#f8edc9",
						fontSize: "24",
						opacity: ".75",
						children: g(t === 0 ? "games.terraria.layer.surface" : t === 1 ? "games.terraria.layer.underground" : t === 2 ? "games.terraria.layer.upperCavern" : t === 3 ? "games.terraria.layer.lowerCavern" : "games.terraria.layer.underworld")
					})] }, t)),
					e.world.map((t) => /* @__PURE__ */ h("g", { children: [t.cells.map((n, r) => {
						let i = {
							x: t.x * 3 + r % 3,
							y: t.y * 5 + Math.floor(r / 3)
						}, a = S(i), o = k[n], s = (tr[t.biome] ?? tr.forest)[t.y];
						return /* @__PURE__ */ h("g", { children: [
							/* @__PURE__ */ m("rect", {
								x: a.x,
								y: a.y,
								width: $,
								height: $,
								fill: o ? s : t.y === 0 ? "#a9d8df" : t.y === 4 ? "#302330" : "#282b3b",
								fillOpacity: !o && t.y === 0 ? .28 : 1,
								stroke: o ? "#4b3d3e" : "#8c8494",
								strokeOpacity: o ? .6 : .18,
								strokeWidth: "1.5"
							}),
							o && /* @__PURE__ */ h(ie, { children: [
								/* @__PURE__ */ m("rect", {
									x: a.x,
									y: a.y,
									width: $,
									height: $,
									fill: n === "#" || t.y === 0 ? "url(#terraria-ground-" + t.biome + ")" : "url(#terraria-rock-art)",
									opacity: t.y === 0 ? .93 : .64
								}),
								/* @__PURE__ */ m("rect", {
									x: a.x,
									y: a.y,
									width: $,
									height: $,
									fill: n === "#" ? "url(#terraria-soil)" : "url(#terraria-stone)"
								}),
								i.y === 4 && /* @__PURE__ */ m("path", {
									d: `M${a.x} ${a.y}h80v9l-10 -3 -9 8 -7 -9 -13 4 -8 -7 -13 4 -10 -4Z`,
									fill: t.biome === "snow" ? "#e2eff2" : t.biome === "corruption" ? "#8873b4" : t.biome === "crimson" ? "#b65e6b" : "#70a052"
								})
							] }),
							nr[n] && (o?.resource ? /* @__PURE__ */ m("image", {
								href: Pn(o.resource),
								x: a.x + 16,
								y: a.y + 21,
								width: "50",
								height: "50"
							}) : /* @__PURE__ */ h("g", {
								fill: nr[n],
								stroke: "#fff5df",
								strokeOpacity: ".4",
								strokeWidth: "1",
								children: [/* @__PURE__ */ m("path", { d: `M${a.x + 12} ${a.y + 45}l12-18 18 3 8 18-19 15Z` }), /* @__PURE__ */ m("path", { d: `M${a.x + 48} ${a.y + 20}l14-5 8 13-8 12-16-5Z` })]
							})),
							o && /* @__PURE__ */ h("text", {
								x: a.x + 9,
								y: a.y + 21,
								className: "terraria-map-cost",
								children: [o.hardy ? "◆ " : "", o.cost]
							}),
							n.startsWith("T") && /* @__PURE__ */ h("g", {
								opacity: e.acorns.some((e) => e.x === i.x && e.y === i.y) ? .2 : 1,
								children: [
									/* @__PURE__ */ m("image", {
										href: "games/terraria/art-tree-" + (t.biome === "beach" ? "desert" : t.biome) + ".webp",
										x: a.x - 25,
										y: a.y - 140,
										width: "130",
										height: "215",
										preserveAspectRatio: "xMidYMax meet"
									}),
									/* @__PURE__ */ m("path", {
										d: `M${a.x + 20} ${a.y + 34}h40l-20 35Z`,
										fill: "#9878aa",
										stroke: "#f7ecd0",
										strokeWidth: "3"
									}),
									/* @__PURE__ */ m("text", {
										x: a.x + 40,
										y: a.y + 56,
										textAnchor: "middle",
										className: "terraria-map-cost",
										children: n.slice(1)
									})
								]
							}),
							n.startsWith("C") && /* @__PURE__ */ h("g", { children: [
								/* @__PURE__ */ m("rect", {
									x: a.x + 15,
									y: a.y + 35,
									width: "51",
									height: "31",
									rx: "4",
									fill: "#ac733e",
									stroke: "#efc875",
									strokeWidth: "4"
								}),
								/* @__PURE__ */ m("path", {
									d: `M${a.x + 15} ${a.y + 48}h51m-34 -12v28m16 -28v28`,
									stroke: "#efd68e",
									strokeWidth: "4"
								}),
								/* @__PURE__ */ m("text", {
									x: a.x + 41,
									y: a.y + 28,
									textAnchor: "middle",
									className: "terraria-map-cost",
									children: n.slice(1)
								})
							] }),
							n === "W" && /* @__PURE__ */ m("path", {
								d: `M${a.x + 7} ${a.y + 5}L${a.x + 70} ${a.y + 70}m0 -65L${a.x + 7} ${a.y + 70}M${a.x + 39} ${a.y + 5}v65M${a.x + 5} ${a.y + 39}h65M${a.x + 22} ${a.y + 22}h33v33h-33Z`,
								stroke: "#e8e3e0",
								fill: "none",
								strokeWidth: "2.5",
								opacity: ".7"
							}),
							n === "L" && /* @__PURE__ */ h(ie, { children: [/* @__PURE__ */ m("path", {
								d: `M${a.x} ${a.y + 43}q20 -12 40 0t40 0v37h-80Z`,
								fill: "#f47943"
							}), /* @__PURE__ */ m("path", {
								d: `M${a.x} ${a.y + 44}q20 -12 40 0t40 0`,
								fill: "none",
								stroke: "#ffd367",
								strokeWidth: "6"
							})] }),
							[
								"S",
								"Altar",
								"Orb4",
								"Heart4",
								"Larva"
							].includes(n) && /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
								d: n === "S" ? `M${a.x + 27} ${a.y + 48}v-13q13 -14 26 0v13l-8 4v9h-10v-9Z` : `M${a.x + 20} ${a.y + 62}h40l-6 -14v-20l-14 -11 -14 11v20Z`,
								fill: n === "S" ? "#f0ecdf" : n === "Heart4" ? "#d96786" : n === "Larva" ? "#d5b75c" : "#a387cc",
								stroke: "#6b5972",
								strokeWidth: "2"
							}), n === "S" && /* @__PURE__ */ m("path", {
								d: `M${a.x + 33} ${a.y + 38}h3m8 0h3`,
								stroke: "#4a3a53",
								strokeWidth: "5"
							})] }),
							/* @__PURE__ */ m(p, {
								name: "cell:" + i.x + ":" + i.y,
								r: a
							})
						] }, r);
					}), /* @__PURE__ */ m("rect", {
						x: (t.x * 3 - b) * $,
						y: t.y * 400,
						width: "240",
						height: "400",
						fill: "none",
						stroke: "#ead9ae",
						strokeOpacity: ".55",
						strokeWidth: "3"
					})] }, t.x + ":" + t.y)),
					e.houses.map((e, t) => /* @__PURE__ */ h("g", { children: [e.cells.map((e, t) => {
						let n = S(e);
						return /* @__PURE__ */ h("g", { children: [
							/* @__PURE__ */ m("rect", {
								x: n.x + 3,
								y: n.y + 3,
								width: "74",
								height: "74",
								fill: "#a57a4e",
								stroke: "#5b4236",
								strokeWidth: "5"
							}),
							/* @__PURE__ */ m("path", {
								d: `M${n.x + 4} ${n.y + 28}h72m-72 24h72`,
								stroke: "#795536",
								strokeWidth: "2"
							}),
							/* @__PURE__ */ m("rect", {
								x: n.x + 26,
								y: n.y + 21,
								width: "29",
								height: "36",
								fill: "#e9cd7c",
								stroke: "#543b31",
								strokeWidth: "4"
							})
						] }, t);
					}), /* @__PURE__ */ m("text", {
						x: (e.x - b) * $ + 12,
						y: e.y * $ - 10,
						fontSize: "20",
						fill: "#fff3c9",
						stroke: "#483646",
						strokeWidth: "4",
						paintOrder: "stroke",
						children: Q(e.type, g)
					})] }, t)),
					e.ropes.map((t, n) => {
						let r = e.world.flatMap((e) => e.cells.flatMap((n, r) => {
							let i = e.x * 3 + r % 3, a = e.y * 5 + Math.floor(r / 3);
							return i === t.x && a > t.y && k[n] ? [a] : [];
						})), i = Math.min(25, ...r), a = S(t);
						return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
							d: `M${a.x + 40} ${a.y + 12}v${(i - t.y) * $ - 12}`,
							stroke: "#d7b87c",
							strokeWidth: "5",
							strokeDasharray: "8 3"
						}), /* @__PURE__ */ m("circle", {
							cx: a.x + 40,
							cy: a.y + 14,
							r: "10",
							fill: "#cbaa67",
							stroke: "#765333",
							strokeWidth: "3"
						})] }, n);
					}),
					e.platforms.map((e, t) => {
						let n = S(e);
						return /* @__PURE__ */ m("path", {
							d: `M${n.x + 2} ${n.y + 75}h76m-62 -7v13m16 -13v13m16 -13v13m16 -13v13`,
							stroke: "#c49c65",
							strokeWidth: "7"
						}, t);
					}),
					e.pylons.map((e, t) => {
						let n = S(e);
						return /* @__PURE__ */ m("path", {
							d: `M${n.x + 40} ${n.y + 7}l17 20 -17 27 -17 -27Z M${n.x + 23} ${n.y + 67}h34`,
							fill: "#79d5da",
							stroke: "#ede1a2",
							strokeWidth: "5"
						}, t);
					}),
					e.boss && /* @__PURE__ */ h("g", { children: [
						je(e.boss).rows.flatMap((t, n) => [...t].flatMap((t, r) => {
							if (t !== "#") return [];
							let i = e.boss, a = je(i).anchor, o = S({
								x: i.x + r - a[0],
								y: i.y + n - a[1]
							});
							return /* @__PURE__ */ m("rect", {
								x: o.x + 1,
								y: o.y + 1,
								width: "78",
								height: "78",
								fill: i.id === "kingSlime" ? "#4585cf" : i.id === "queenBee" ? "#b99e43" : "#ad5971",
								fillOpacity: ".82",
								stroke: "#f6d78e",
								strokeWidth: "3"
							}, r + ":" + n);
						})),
						(() => {
							let t = e.boss, n = je(t), r = S({
								x: t.x - n.anchor[0],
								y: t.y - n.anchor[1]
							}), i = t.id + (t.form && t.id !== "queenBee" ? "2" : "");
							return /* @__PURE__ */ m("image", {
								href: Mn[i],
								x: r.x,
								y: r.y,
								width: n.rows[0].length * $,
								height: n.rows.length * $,
								preserveAspectRatio: "xMidYMid meet"
							});
						})(),
						/* @__PURE__ */ h("text", {
							x: S(e.boss).x + 40,
							y: S(e.boss).y - 16,
							textAnchor: "middle",
							className: "terraria-map-label",
							children: [
								Q(e.boss.id, g),
								" · ",
								e.boss.id === "wall" && e.boss.form === 0 ? e.boss.eyes.join(" / ") : e.boss.hp
							]
						}),
						/* @__PURE__ */ m(p, {
							name: "boss",
							r: S(e.boss)
						})
					] }),
					e.enemies.map((e) => {
						let t = S(e), n = jn[e.name];
						return /* @__PURE__ */ h("g", { children: [
							/* @__PURE__ */ m("ellipse", {
								cx: t.x + 40,
								cy: t.y + 57,
								rx: "32",
								ry: "17",
								fill: "#151c30",
								opacity: ".35"
							}),
							/* @__PURE__ */ m("rect", {
								x: t.x + 6,
								y: t.y + 17,
								width: "68",
								height: "55",
								rx: "18",
								fill: "#d3e4c5",
								stroke: "#ede3c4",
								strokeWidth: "2"
							}),
							n ? /* @__PURE__ */ m("image", {
								href: n,
								x: t.x + 3,
								y: t.y + 3,
								width: "74",
								height: "74"
							}) : /* @__PURE__ */ m("text", {
								x: t.x + 40,
								y: t.y + 48,
								textAnchor: "middle",
								fontSize: "15",
								children: Q(e.name, g)
							}),
							/* @__PURE__ */ m("circle", {
								cx: t.x + 65,
								cy: t.y + 19,
								r: "13",
								fill: "#a4435f",
								stroke: "#f5ddd0",
								strokeWidth: "2"
							}),
							/* @__PURE__ */ m("text", {
								x: t.x + 65,
								y: t.y + 25,
								textAnchor: "middle",
								fill: "#fff7df",
								fontSize: "18",
								fontWeight: "800",
								children: e.hp
							}),
							/* @__PURE__ */ m(er, {
								mode: E(e.name)?.mode ?? "walk",
								x: t.x + 15,
								y: t.y + 16
							}),
							/* @__PURE__ */ m(p, {
								name: "enemy:" + e.uid,
								r: t
							})
						] }, e.uid);
					}),
					e.people.filter((e) => !e.dead).map((e) => {
						let n = S(e), r = t.find((t) => t.rid === e.rid), i = d[(r?.colorIndex ?? 0) % d.length].hex;
						return /* @__PURE__ */ h("g", { children: [
							/* @__PURE__ */ m("circle", {
								cx: n.x + 40,
								cy: n.y + 42,
								r: "30",
								fill: i,
								stroke: e.rid === a ? "#fff1ba" : "#d7d4cc",
								strokeWidth: "5"
							}),
							r && /* @__PURE__ */ m("image", {
								href: ne[r.avatar % ne.length],
								x: n.x + 16,
								y: n.y + 16,
								width: "48",
								height: "48"
							}),
							/* @__PURE__ */ m("text", {
								x: n.x + 40,
								y: n.y + 84,
								textAnchor: "middle",
								className: "terraria-map-label",
								children: u(e.rid)
							}),
							/* @__PURE__ */ m(p, {
								name: "person:" + e.rid,
								r: n
							})
						] }, e.rid);
					}),
					[...pe.keys()].map((e) => {
						let [t, n] = e.split(":").map(Number), r = S({
							x: t,
							y: n
						});
						return /* @__PURE__ */ m("rect", {
							x: r.x + 5,
							y: r.y + 5,
							width: "70",
							height: "70",
							rx: "6",
							fill: "#ffedb4",
							fillOpacity: ".12",
							stroke: "#fff3bb",
							strokeWidth: "3",
							strokeDasharray: "9 6",
							pointerEvents: "none",
							children: /* @__PURE__ */ m("animate", {
								attributeName: "stroke-dashoffset",
								from: "0",
								to: "-30",
								dur: ".8s",
								repeatCount: "indefinite"
							})
						}, e);
					}),
					w[0]?.kind === "house" && _e[w[0].a] && _e[w[0].a].rows.flatMap((e, t) => [...e].flatMap((e, n) => e === "#" ? /* @__PURE__ */ m("rect", {
						x: S({
							x: T + n,
							y: he + t
						}).x + 3,
						y: (he + t) * $ + 3,
						width: "74",
						height: "74",
						fill: "#edcf88",
						fillOpacity: ".5",
						stroke: "#fff2b1",
						strokeWidth: "4"
					}, n + ":" + t) : []))
				]
			})
		}), le && /* @__PURE__ */ h("div", {
			className: "terraria-cell-menu",
			children: [
				/* @__PURE__ */ m("button", {
					className: "terraria-close",
					"aria-label": g("games.terraria.close"),
					onClick: () => ue(null),
					children: /* @__PURE__ */ m(c, { size: 18 })
				}),
				/* @__PURE__ */ m("strong", { children: D ? Q(D.name, g) : ge && ge in Wn ? g(Wn[ge]) : g("games.terraria.selectLocation") }),
				D && (() => {
					let e = E(D.name);
					return e ? /* @__PURE__ */ h("div", {
						className: "terraria-enemy-detail",
						children: [/* @__PURE__ */ h("p", { children: [
							g("games.terraria.health"),
							" ",
							D.hp,
							" · ",
							g("games.terraria.attack"),
							" ",
							Qn(e.attack),
							" · ",
							g("games.terraria.defense"),
							" ",
							Qn(e.defense)
						] }), /* @__PURE__ */ h("p", { children: [
							e.ranges.split(" ").map((e) => g(e === "short" ? "games.terraria.short" : e === "medium" ? "games.terraria.medium" : "games.terraria.long")).join(" · "),
							" · ",
							g("games.terraria.movement"),
							" ",
							e.move
						] })]
					}) : null;
				})(),
				w.map((t) => /* @__PURE__ */ m("button", {
					onClick: () => {
						l(t), ue(null);
					},
					children: Zn(t, e, g, u)
				}, t.id))
			]
		})]
	});
}
//#endregion
//#region src/games/terraria/view-player.tsx
var ar = {
	kingSlime: "games.terraria.bossRules.kingSlime",
	eye: "games.terraria.bossRules.eye",
	brain: "games.terraria.bossRules.brain",
	eater: "games.terraria.bossRules.eater",
	queenBee: "games.terraria.bossRules.queenBee",
	wall: "games.terraria.bossRules.wall"
};
function or(e) {
	return /* @__PURE__ */ m(sr, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function sr({ pub: e, priv: t, members: n, myRid: r, send: ne }) {
	let p = s(), re = o((e) => e.locale), [g, ae] = i(r), [_, oe] = i(null), [v, y] = i(null), [se, ce] = i(null), [b, x] = i(null), [le, ue] = i(!1), [de, fe] = i(0);
	g !== r && (ae(r), oe(null), y(null), x(null), ce(null));
	let S = e.people.find((e) => e.rid === r) ?? e.people[0], C = e.people.find((e) => e.rid === se) ?? S, [E, ge] = i({
		x: S.x,
		y: S.y
	}), D = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? te(t, re) : p("games.terraria.everyone");
	}, O = t?.choices ?? [], k = !!(e.pending || e.battle), ve = _ && O.some((e) => e.kind === _.kind && (!_.a || e.a === _.a)) ? _ : null, ye = O.filter((t) => rr(t, e) && (k || ve ? k || t.kind === ve?.kind && (!ve.a || t.a === ve.a) : [
		"move",
		"ropeMove",
		"hook",
		"drop",
		"activate",
		"dig",
		"chop",
		"chest",
		"collect",
		"summonEye"
	].includes(t.kind))), A = (e) => {
		ne({
			type: "choose",
			id: e.id
		}), [
			"house",
			"craft",
			"buyAction",
			"bottle"
		].includes(e.kind) && y(null);
	}, be = (e, t) => {
		let n = O.filter((n) => n.kind === e && (!t || n.a === t));
		n.length === 1 ? A(n[0]) : n.length && oe({
			kind: e,
			a: t
		});
	}, j = (t) => Zn(t, e, p, D), M = O.filter((t) => !rr(t, e) && !(/* @__PURE__ */ "card.ready.readyAP.unready.tool.weapon.consumable.craft.craftToken.nightsEdge.house.buyAction.buyConsumable.spawnNpc.bottle.food.nurse.goblin.donate.unlock.focus.objective.discover.end.resume.prepared.armor.equip".split(".")).includes(t.kind)), N = O.filter((e) => [
		"end",
		"resume",
		"prepared"
	].includes(e.kind)), { ref: P } = a("hand:" + r), { ref: F } = a("inventory:" + r), { ref: Ce } = a("deck:" + r), { ref: we } = a("played:" + r), { ref: I } = a("battle"), { ref: L } = a("objectives"), [R, Te] = i("tools"), z = (e, t) => /* @__PURE__ */ m("div", {
		className: "terraria-scrim",
		onClick: () => {
			y(null), x(null);
		},
		children: /* @__PURE__ */ h("section", {
			className: "terraria-drawer" + (v === "craft" ? " terraria-drawer--craft" : ""),
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("h2", { children: e }), /* @__PURE__ */ m("button", {
				className: "terraria-close",
				"aria-label": p("games.terraria.close"),
				onClick: () => {
					y(null), x(null);
				},
				children: /* @__PURE__ */ m(c, { size: 20 })
			})] }), t]
		})
	}), Ee = /* @__PURE__ */ m("div", {
		className: "terraria-objectives",
		ref: L,
		children: e.objectives.map((t) => {
			let n = e.people.length <= 2 && t.id + "Small" in Vn ? t.id + "Small" : t.id, r = e.people.length <= 2 && t.id + "Small" in Hn ? t.id + "Small" : t.id, i = O.find((e) => e.kind === "objective" && e.a === t.id), a = O.find((e) => e.kind === "focus" && e.a === t.id);
			return /* @__PURE__ */ h("article", {
				className: "terraria-objective",
				"data-chain": t.chain,
				children: [
					/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("b", { children: p(Kn[t.chain]) }), /* @__PURE__ */ m("span", { children: p("games.terraria.objectLevel", { n: t.level }) })] }),
					/* @__PURE__ */ m("h3", { children: Q(t.id, p) }),
					/* @__PURE__ */ m("p", { children: p(Vn[n]) }),
					/* @__PURE__ */ h("details", { children: [/* @__PURE__ */ m("summary", { children: p("games.terraria.reward") }), /* @__PURE__ */ m("p", { children: p(Hn[r]) })] }),
					t.focus > 0 && /* @__PURE__ */ h("span", {
						className: "terraria-focus",
						children: [
							p("games.terraria.focusRule"),
							" · ",
							2 - t.focus
						]
					}),
					i && /* @__PURE__ */ m("button", {
						className: "terraria-main-button",
						onClick: () => A(i),
						children: j(i)
					}),
					a && /* @__PURE__ */ m("button", {
						onClick: () => A(a),
						children: j(a)
					})
				]
			}, t.chain);
		})
	}), De = (e) => {
		let t = w(e), n = T(e), r = Se[e], i = he(e), a = xe[e];
		return /* @__PURE__ */ h(ie, { children: [
			/* @__PURE__ */ m(Fn, {
				id: e,
				className: "terraria-detail-art"
			}),
			/* @__PURE__ */ m("h3", { children: Q(e, p) }),
			r ? /* @__PURE__ */ h("div", {
				className: "terraria-detail-effects",
				children: [r.branches.map((e, t) => /* @__PURE__ */ h("div", { children: [t > 0 && /* @__PURE__ */ m("b", { children: p("games.terraria.or") }), e.map((e, t) => /* @__PURE__ */ m("p", { children: Xn(e, p) }, t))] }, t)), r.ready && Object.entries(r.ready).map(([e, t]) => /* @__PURE__ */ h("p", { children: [
					p("games.terraria.readySlot"),
					"：",
					e in Bn ? p(Bn[e], { n: t }) : e
				] }, e))]
			}) : t ? /* @__PURE__ */ h(ie, { children: [
				/* @__PURE__ */ m("p", { children: t.chop ? p("games.terraria.gainChop", {
					cost: t.cost,
					n: t.chop
				}) : t.dig ? p(t.hardy ? "games.terraria.gainHardyDig" : "games.terraria.gainDig", {
					cost: t.cost,
					n: t.dig
				}) : a ? p("games.terraria.summonEffect", {
					cost: a.cost,
					n: a.attack
				}) : ["e35", "e52"].includes(e) ? p("games.terraria.hookEffect", { n: e === "e52" ? 3 : 2 }) : $n(e) + " · " + t.cost + " " + p(t.mana ? "games.terraria.mana" : "games.terraria.ap") }),
				/* @__PURE__ */ m("p", { children: t.ranges.map((e) => p(e === "short" ? "games.terraria.short" : e === "medium" ? "games.terraria.medium" : "games.terraria.long")).join(" · ") }),
				t.yield_ > 1 && /* @__PURE__ */ m("p", { children: p("games.terraria.toolYield", { n: t.yield_ }) }),
				t.hardy && /* @__PURE__ */ m("p", { children: p("games.terraria.hardyDig") }),
				t.prevent && /* @__PURE__ */ m("p", { children: p("games.terraria.prevent") }),
				t.pierce > 0 && /* @__PURE__ */ m("p", { children: p("games.terraria.pierce", { n: t.pierce }) }),
				t.sightless && /* @__PURE__ */ m("p", { children: p("games.terraria.sightless") }),
				t.draw > 0 && /* @__PURE__ */ m("p", { children: p("games.terraria.draw", { n: t.draw }) })
			] }) : n ? /* @__PURE__ */ h(ie, { children: [
				/* @__PURE__ */ h("p", { children: [
					p("games.terraria.defense"),
					"：",
					Qn(n.dice)
				] }),
				/* @__PURE__ */ h("p", { children: [
					p("games.terraria.draw", { n: n.draw }),
					" · ",
					n.ap,
					" ",
					p("games.terraria.ap"),
					" · ",
					n.mana,
					" ",
					p("games.terraria.mana")
				] }),
				e in Yn && /* @__PURE__ */ m("p", { children: p(Yn[e]) })
			] }) : i && e in qn ? /* @__PURE__ */ m("p", { children: p(qn[e]) }) : null,
			(t || n) && Object.keys((t ?? n).recipe).length > 0 && /* @__PURE__ */ h("div", {
				className: "terraria-recipe",
				children: [
					/* @__PURE__ */ m("b", { children: p("games.terraria.recipe") }),
					Object.entries((t ?? n).recipe).map(([e, t]) => /* @__PURE__ */ h("span", { children: [
						/* @__PURE__ */ m(Fn, { id: e }),
						Q(e === "flinxfur" ? "flinxFur" : e, p),
						" ",
						/* @__PURE__ */ m("b", { children: t })
					] }, e)),
					(t ?? n).house && /* @__PURE__ */ h("span", { children: [
						p("games.terraria.requires"),
						"：",
						Q((t ?? n).house, p)
					] })
				]
			})
		] });
	}, B = e.boss && /* @__PURE__ */ h("div", {
		className: "terraria-boss-summary",
		children: [
			/* @__PURE__ */ m("img", {
				className: "terraria-boss-art",
				src: Mn[e.boss.id + (e.boss.form && e.boss.id !== "queenBee" ? "2" : "")],
				alt: ""
			}),
			/* @__PURE__ */ m("h3", { children: Q(e.boss.id, p) }),
			/* @__PURE__ */ h("p", { children: [
				p("games.terraria.bossForm", { n: e.boss.form + 1 }),
				" · ",
				p("games.terraria.bossBehavior", { n: e.boss.behavior === 0 ? "A" : "B" })
			] }),
			/* @__PURE__ */ m("p", { children: p(ar[e.boss.id]) }),
			e.boss.buffs.map((t) => {
				let n = e.boss.id + t;
				return n in Jn ? /* @__PURE__ */ m("p", { children: p(Jn[n]) }, t) : null;
			})
		]
	}), Oe = /* @__PURE__ */ h("div", {
		className: "terraria-pack",
		children: [
			/* @__PURE__ */ h("div", {
				className: "terraria-resource-slots",
				children: [C.inventory.map((e, t) => /* @__PURE__ */ h("div", {
					className: "terraria-resource",
					children: [
						/* @__PURE__ */ m(Fn, { id: e.resource }),
						/* @__PURE__ */ m("span", { children: e.resource ? Q(e.resource, p) : p("games.terraria.slot", { n: t + 1 }) }),
						/* @__PURE__ */ h("b", { children: [e.n, /* @__PURE__ */ m("small", { children: "/5" })] }),
						O.filter((e) => e.kind === "store" && e.b === String(t)).map((e) => /* @__PURE__ */ m("button", {
							onClick: () => A(e),
							children: p("games.terraria.count", { n: e.n })
						}, e.id))
					]
				}, t)), C.ready?.type === "a33" && /* @__PURE__ */ h("div", {
					className: "terraria-resource",
					children: [/* @__PURE__ */ h("span", { children: [
						p("games.terraria.stockpileSlot"),
						" · ",
						Q(C.stockpile.resource, p)
					] }), /* @__PURE__ */ h("b", { children: [C.stockpile.n, /* @__PURE__ */ m("small", { children: "/20" })] })]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "terraria-equipment",
				children: Object.entries(C.equipped).map(([e, t]) => /* @__PURE__ */ h("article", {
					className: "terraria-equipment-slot",
					children: [/* @__PURE__ */ h("button", {
						disabled: !t,
						onClick: () => x(t),
						children: [
							/* @__PURE__ */ m(Fn, { id: t }),
							/* @__PURE__ */ m("span", { children: t ? Q(t, p) : p("games.terraria.emptyEquipment") }),
							/* @__PURE__ */ m("b", { children: $n(t) })
						]
					}), O.filter((e) => [
						"tool",
						"weapon",
						"minion"
					].includes(e.kind) && e.a === t).map((e) => /* @__PURE__ */ m("button", {
						className: "terraria-equip-action",
						onClick: () => A(e),
						children: j(e)
					}, e.id))]
				}, e))
			}),
			/* @__PURE__ */ h("button", {
				className: "terraria-armor",
				onClick: () => C.armor && x(C.armor),
				children: [
					C.armor ? Q(C.armor, p) : p("games.terraria.noArmor"),
					" · ",
					Qn(T(C.armor)?.dice ?? [4])
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "terraria-supplies",
				children: C.consumables.map((e, t) => /* @__PURE__ */ h("div", {
					className: "terraria-supply",
					children: [/* @__PURE__ */ m("button", {
						onClick: () => x(e),
						children: Q(e, p)
					}), O.some((t) => t.kind === "consumable" && t.a === e) && /* @__PURE__ */ m("button", {
						onClick: () => be("consumable", e),
						children: p("games.terraria.use")
					})]
				}, e + ":" + t))
			}),
			/* @__PURE__ */ h("div", {
				className: "terraria-token-counts",
				children: [
					/* @__PURE__ */ h("span", { children: [
						p("games.terraria.items.platform"),
						" ",
						C.platforms
					] }),
					/* @__PURE__ */ h("span", { children: [
						p("games.terraria.items.rope"),
						" ",
						C.ropes
					] }),
					/* @__PURE__ */ h("span", { children: [
						p("games.terraria.coins"),
						" ",
						C.coins
					] })
				]
			}),
			[
				"unlock",
				"donate",
				"unready"
			].flatMap((e) => O.filter((t) => t.kind === e).map((e) => /* @__PURE__ */ m("button", {
				onClick: () => A(e),
				children: j(e)
			}, e.id))),
			/* @__PURE__ */ h("div", {
				className: "terraria-card-piles",
				children: [/* @__PURE__ */ h("span", { children: [
					p("games.terraria.deck"),
					" ",
					C.deckCount
				] }), /* @__PURE__ */ h("span", { children: [
					p("games.terraria.discard"),
					" ",
					C.discard.length
				] })]
			}),
			/* @__PURE__ */ h("div", {
				className: "terraria-ready",
				children: [/* @__PURE__ */ m("b", { children: p("games.terraria.readySlot") }), C.ready ? /* @__PURE__ */ h(ie, { children: [/* @__PURE__ */ m("button", {
					onClick: () => x(C.ready.type),
					children: Q(C.ready.type, p)
				}), O.filter((e) => e.kind === "readyAP").map((e) => /* @__PURE__ */ m("button", {
					onClick: () => A(e),
					children: j(e)
				}, e.id))] }) : /* @__PURE__ */ m("span", { children: "—" })]
			})
		]
	}), ke = (e) => {
		let t = Se[e.type], n = O.filter((t) => t.kind === "card" && t.a === e.uid), r = O.find((t) => t.kind === "ready" && t.a === e.uid);
		return /* @__PURE__ */ h("article", {
			className: "terraria-card" + (n.length ? " terraria-card--active" : ""),
			children: [
				/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("b", { children: Q(e.type, p) }), /* @__PURE__ */ m("button", {
					"aria-label": p("games.terraria.detail"),
					onClick: () => x(e.type),
					children: /* @__PURE__ */ m(u, { size: 15 })
				})] }),
				/* @__PURE__ */ m("div", {
					className: "terraria-card-effects",
					children: t.branches.map((t, r) => /* @__PURE__ */ h("div", {
						className: "terraria-branch",
						children: [r > 0 && /* @__PURE__ */ m("span", {
							className: "terraria-or",
							children: p("games.terraria.or")
						}), t.map((t, i) => {
							let a = n.find((e) => Number(e.flag) === r && e.n === i);
							return /* @__PURE__ */ h("button", {
								disabled: !a,
								className: e.used.includes(i) && e.branch === r ? "terraria-used" : "",
								onClick: () => a && A(a),
								children: [/* @__PURE__ */ m(In, { kind: t.kind }), /* @__PURE__ */ m("span", { children: Xn(t, p) })]
							}, i);
						})]
					}, r))
				}),
				r && /* @__PURE__ */ m("button", {
					className: "terraria-ready-action",
					onClick: () => A(r),
					children: p("games.terraria.ready")
				}),
				!t.branches.length && t.ready && Object.entries(t.ready).map(([e, t]) => /* @__PURE__ */ m("p", { children: e in Bn ? p(Bn[e], { n: t }) : e }, e))
			]
		}, e.uid);
	}, V = /* @__PURE__ */ h("section", {
		className: "terraria-rack",
		children: [/* @__PURE__ */ m("div", {
			className: "terraria-rack-tools",
			children: Object.values(S.equipped).filter(Boolean).map((e) => /* @__PURE__ */ h("div", {
				className: "terraria-tool",
				children: [/* @__PURE__ */ h("button", {
					onClick: () => x(e),
					children: [
						/* @__PURE__ */ m(Fn, { id: e }),
						/* @__PURE__ */ m("span", { children: Q(e, p) }),
						/* @__PURE__ */ m("b", { children: $n(e) })
					]
				}), O.filter((t) => [
					"tool",
					"weapon",
					"minion"
				].includes(t.kind) && t.a === e).map((e) => /* @__PURE__ */ m("button", {
					className: "terraria-tool-use",
					onClick: () => A(e),
					children: j(e)
				}, e.id))]
			}, e))
		}), /* @__PURE__ */ m("div", {
			className: "terraria-rack-resources",
			ref: F,
			children: S.inventory.map((e, t) => /* @__PURE__ */ h("button", {
				onClick: () => {
					ce(r), y("pack");
				},
				"aria-label": (e.resource ? Q(e.resource, p) : p("games.terraria.emptyEquipment")) + " " + e.n + "/5",
				children: [
					/* @__PURE__ */ m(Fn, { id: e.resource }),
					/* @__PURE__ */ m("span", { children: e.resource ? Q(e.resource, p) : "—" }),
					/* @__PURE__ */ h("b", { children: [e.n, /* @__PURE__ */ m("small", { children: "/5" })] })
				]
			}, t))
		})]
	});
	return /* @__PURE__ */ h("div", {
		className: "terraria-screen",
		children: [
			/* @__PURE__ */ m(f, {
				adaptive: !0,
				scroll: !1,
				actionsHeight: "terraria-actions-height",
				banner: /* @__PURE__ */ h("div", {
					className: "terraria-head",
					children: [
						/* @__PURE__ */ h("div", {
							className: "terraria-time",
							children: [
								/* @__PURE__ */ m("strong", { children: re === "en" ? "Terraria" : p("games.terraria.name") }),
								/* @__PURE__ */ h("span", { children: [
									p("games.terraria.day", { n: e.day }),
									" · ",
									p(e.time >= 5 ? "games.terraria.time.night" : "games.terraria.time.day")
								] }),
								/* @__PURE__ */ m("div", {
									className: "terraria-time-track",
									children: Array.from({ length: 7 }, (t, n) => /* @__PURE__ */ m("i", { className: n === e.time ? "terraria-time-current" : "" }, n))
								})
							]
						}),
						/* @__PURE__ */ h("div", {
							className: "terraria-danger",
							children: [
								/* @__PURE__ */ m("span", { children: p("games.terraria.threat", { n: e.threat }) }),
								/* @__PURE__ */ m("meter", {
									min: "0",
									max: "10",
									value: e.threat
								}),
								/* @__PURE__ */ m("small", { children: p("games.terraria.graves", { n: e.graves }) })
							]
						}),
						/* @__PURE__ */ m("div", {
							className: "terraria-members",
							children: e.people.map((e) => {
								let t = n.find((t) => t.rid === e.rid);
								return /* @__PURE__ */ h("button", {
									className: "terraria-member" + (e.rid === C.rid ? " terraria-member--selected" : ""),
									onClick: () => {
										ce(e.rid), y("pack");
									},
									style: { "--terraria-player": d[(t?.colorIndex ?? 0) % d.length].hex },
									children: [
										t && /* @__PURE__ */ m(ee, {
											m: t,
											myRid: r,
											action: e.ended ? "done" : null,
											anchorName: "seat:" + t.rid,
											box: "size-8",
											img: "size-8"
										}),
										/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("b", { children: D(e.rid) }), /* @__PURE__ */ h("small", {
											className: "terraria-vitals",
											children: [/* @__PURE__ */ h("i", {
												"aria-label": p("games.terraria.health"),
												children: [
													"♥ ",
													e.hp,
													"/",
													e.maxHp
												]
											}), /* @__PURE__ */ h("em", {
												"aria-label": p("games.terraria.mana"),
												children: [
													"◆ ",
													e.mana,
													"/",
													e.maxMana
												]
											})]
										})] }),
										e.ended && /* @__PURE__ */ m("span", {
											"aria-label": p("games.terraria.endReady"),
											children: "✓"
										})
									]
								}, e.rid);
							})
						})
					]
				}),
				actions: /* @__PURE__ */ h("div", {
					className: "terraria-hand-area",
					children: [
						V,
						/* @__PURE__ */ h("div", {
							className: "terraria-hand",
							ref: P,
							children: [S.hand.map(ke), !S.hand.length && /* @__PURE__ */ m("div", {
								className: "terraria-empty-hand",
								children: S.dead ? p("games.terraria.dead") : p("games.terraria.noCards")
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "terraria-turn-actions",
							children: [N.map((e) => /* @__PURE__ */ m("button", {
								className: "terraria-main-button",
								onClick: () => A(e),
								children: j(e)
							}, e.id)), /* @__PURE__ */ h("span", {
								ref: Ce,
								children: [
									p("games.terraria.deck"),
									" ",
									S.deckCount,
									" · ",
									p("games.terraria.round", { n: e.round })
								]
							})]
						})
					]
				}),
				children: /* @__PURE__ */ h("div", {
					className: "terraria-layout",
					children: [/* @__PURE__ */ h("div", {
						className: "terraria-world-wrap",
						children: [
							/* @__PURE__ */ m(ir, {
								pub: e,
								members: n,
								me: r,
								candidates: ye,
								onChoose: A,
								nameOf: D,
								overview: le,
								fit: de,
								focus: E
							}),
							/* @__PURE__ */ h("div", {
								className: "terraria-map-tools",
								children: [
									/* @__PURE__ */ m("button", {
										onClick: () => {
											ue(!le), ge({
												x: S.x,
												y: S.y
											}), fe(de + 1);
										},
										children: p(le ? "games.terraria.focusMe" : "games.terraria.fit")
									}),
									e.boss && /* @__PURE__ */ m("button", {
										onClick: () => y("boss"),
										children: Q(e.boss.id, p)
									}),
									/* @__PURE__ */ m("button", {
										onClick: () => y("objectives"),
										children: p("games.terraria.objectives")
									}),
									/* @__PURE__ */ m("button", {
										onClick: () => {
											ce(r), y("pack");
										},
										children: p("games.terraria.pack")
									}),
									/* @__PURE__ */ m("button", {
										onClick: () => y("craft"),
										children: p("games.terraria.buildMenu")
									}),
									/* @__PURE__ */ m("button", {
										onClick: () => y("market"),
										children: p("games.terraria.npcs")
									}),
									/* @__PURE__ */ m("button", {
										"aria-label": p("games.terraria.journal"),
										onClick: () => y("log"),
										children: /* @__PURE__ */ m(l, { size: 18 })
									})
								]
							}),
							/* @__PURE__ */ h("div", {
								className: "terraria-status",
								children: [/* @__PURE__ */ m("strong", { children: e.pending ? e.pending.prompt in Rn ? p(Rn[e.pending.prompt]) : p("games.terraria.choose") : p(Gn[e.phase]) }), /* @__PURE__ */ h("div", {
									className: "terraria-points",
									children: [
										/* @__PURE__ */ h("span", { children: [
											p("games.terraria.ap"),
											" ",
											/* @__PURE__ */ m("b", { children: S.ap })
										] }),
										/* @__PURE__ */ h("span", { children: [
											p("games.terraria.attack"),
											" ",
											/* @__PURE__ */ m("b", { children: S.attack })
										] }),
										/* @__PURE__ */ h("span", { children: [
											p("games.terraria.defense"),
											" ",
											/* @__PURE__ */ m("b", { children: S.defense })
										] }),
										/* @__PURE__ */ h("span", { children: [
											p("games.terraria.dig"),
											" ",
											/* @__PURE__ */ m("b", { children: S.dig + S.hardyDig })
										] }),
										/* @__PURE__ */ h("span", { children: [
											p("games.terraria.chop"),
											" ",
											/* @__PURE__ */ m("b", { children: S.chop })
										] })
									]
								})]
							}),
							/* @__PURE__ */ h("div", {
								className: "terraria-tools",
								children: [O.filter((e) => e.kind === "discover").map((e) => /* @__PURE__ */ m("button", {
									onClick: () => A(e),
									children: j(e)
								}, e.id)), ve && /* @__PURE__ */ m("button", {
									onClick: () => oe(null),
									children: p("games.terraria.cancel")
								})]
							}),
							k && (M.length > 0 || e.battle) && /* @__PURE__ */ h("div", {
								className: "terraria-decision",
								children: [
									/* @__PURE__ */ m("strong", { children: e.battle ? p(e.battle.enemyAttack ? "games.terraria.combatDefense" : "games.terraria.combatAttack") : e.pending && e.pending.prompt in Rn ? p(Rn[e.pending.prompt]) : p("games.terraria.choose") }),
									e.battle && /* @__PURE__ */ h("div", {
										className: "terraria-battle-dice",
										ref: I,
										children: [/* @__PURE__ */ m("div", { children: e.battle.dice.map((t, n) => /* @__PURE__ */ h("span", {
											className: "terraria-die",
											children: [e.battle.rolled[n] ?? "?", /* @__PURE__ */ h("small", { children: ["D", t] })]
										}, n)) }), /* @__PURE__ */ m("div", { children: e.battle.defense.map((t, n) => /* @__PURE__ */ h("span", {
											className: "terraria-die terraria-die-defense",
											children: [e.battle.defended[n] ?? "?", /* @__PURE__ */ h("small", { children: ["D", t] })]
										}, n)) })]
									}),
									/* @__PURE__ */ m("div", {
										className: "terraria-decision-choices",
										children: M.map((e) => /* @__PURE__ */ m("button", {
											onClick: () => A(e),
											children: j(e)
										}, e.id))
									}),
									!M.length && ye.length > 0 && /* @__PURE__ */ m("span", { children: p("games.terraria.selectTarget") })
								]
							}),
							!k && M.length > 0 && /* @__PURE__ */ m("div", {
								className: "terraria-small-choices",
								children: M.map((e) => /* @__PURE__ */ m("button", {
									onClick: () => A(e),
									children: j(e)
								}, e.id))
							}),
							e.phase === "prepare" && (O.some((e) => [
								"equip",
								"armor",
								"focus"
							].includes(e.kind)) || !O.length) && /* @__PURE__ */ h("div", {
								className: "terraria-prepare",
								children: [
									/* @__PURE__ */ m("strong", { children: p("games.terraria.phase.prepare") }),
									O.filter((e) => [
										"equip",
										"armor",
										"focus"
									].includes(e.kind)).map((e) => /* @__PURE__ */ m("button", {
										onClick: () => A(e),
										children: j(e)
									}, e.id)),
									!O.length && /* @__PURE__ */ m("span", { children: p("games.terraria.waitOther", { name: D(e.pending?.who ?? "") }) })
								]
							})
						]
					}), /* @__PURE__ */ h("aside", {
						className: "terraria-side",
						children: [
							B,
							Ee,
							/* @__PURE__ */ h("div", {
								ref: we,
								className: "terraria-played",
								children: [/* @__PURE__ */ m("h3", { children: p("games.terraria.played") }), S.played.map((e) => /* @__PURE__ */ m("button", {
									onClick: () => x(e.type),
									children: Q(e.type, p)
								}, e.uid))]
							})
						]
					})]
				})
			}),
			v === "boss" && z(Q(e.boss?.id ?? "", p), B),
			v === "objectives" && z(p("games.terraria.objectives"), Ee),
			v === "pack" && z(D(C.rid) + " · " + p("games.terraria.pack"), Oe),
			v === "craft" && z(p("games.terraria.buildMenu"), /* @__PURE__ */ h(ie, { children: [/* @__PURE__ */ m("nav", {
				className: "terraria-book-tabs",
				"aria-label": p("games.terraria.buildMenu"),
				children: [
					"tools",
					"weapons",
					"armor",
					"houses"
				].map((e) => /* @__PURE__ */ m("button", {
					"aria-pressed": R === e,
					onClick: () => Te(e),
					children: p("games.terraria.craftTabs." + e)
				}, e))
			}), /* @__PURE__ */ h("div", {
				className: "terraria-shop",
				children: [R !== "houses" && [...pe, ...me].filter((e) => Object.keys(e.recipe).length > 0 || e.id === "e36").filter((e) => R === "armor" ? !!T(e.id) : R === "tools" ? ["axe", "pickaxe"].includes(w(e.id)?.slot) : !!w(e.id) && !["axe", "pickaxe"].includes(w(e.id).slot)).map((e) => {
					let t = O.find((t) => t.kind === "craft" && t.a === e.id || t.kind === "nightsEdge" && e.id === "e36");
					return /* @__PURE__ */ h("article", { children: [
						De(e.id),
						e.id === "e36" && /* @__PURE__ */ m("p", { children: p("games.terraria.nightsEdgeRecipe") }),
						/* @__PURE__ */ m("button", {
							className: t ? "terraria-main-button" : "",
							disabled: !t,
							onClick: () => t && A(t),
							children: t ? j(t) : p("games.terraria.craftUnavailable")
						})
					] }, e.id);
				}), R === "houses" && /* @__PURE__ */ h(ie, { children: [Object.entries(_e).map(([e, t]) => {
					let n = O.filter((t) => t.kind === "house" && t.a === e);
					return /* @__PURE__ */ h("article", { children: [
						/* @__PURE__ */ m("svg", {
							className: "terraria-house-plan",
							viewBox: "0 0 240 120",
							"aria-hidden": "true",
							children: t.rows.flatMap((e, t) => [...e].flatMap((e, n) => e === "#" ? /* @__PURE__ */ h("g", { children: [
								/* @__PURE__ */ m("rect", {
									x: 25 + n * 44,
									y: 28 + t * 39,
									width: "43",
									height: "38",
									fill: "#a67b52",
									stroke: "#66503e",
									strokeWidth: "2"
								}),
								/* @__PURE__ */ m("path", {
									d: `M${25 + n * 44} ${49 + t * 39}h43`,
									stroke: "#78583c"
								}),
								/* @__PURE__ */ m("rect", {
									x: 40 + n * 44,
									y: 37 + t * 39,
									width: "15",
									height: "15",
									fill: "#efd99d",
									stroke: "#66503e"
								})
							] }, n + ":" + t) : []))
						}),
						/* @__PURE__ */ m("h3", { children: Q(e, p) }),
						/* @__PURE__ */ h("div", {
							className: "terraria-recipe",
							children: [Object.entries(t.cost).map(([e, t]) => /* @__PURE__ */ h("span", { children: [
								/* @__PURE__ */ m(Fn, { id: e }),
								Q(e, p),
								" ",
								/* @__PURE__ */ m("b", { children: t })
							] }, e)), t.requires && /* @__PURE__ */ h("span", { children: [
								p("games.terraria.requires"),
								"：",
								Q(t.requires, p)
							] })]
						}),
						/* @__PURE__ */ m("button", {
							disabled: !n.length,
							className: n.length ? "terraria-main-button" : "",
							onClick: () => {
								oe({
									kind: "house",
									a: e
								}), y(null);
							},
							children: n.length ? p("games.terraria.selectLocation") : p("games.terraria.craftUnavailable")
						})
					] }, e);
				}), O.filter((e) => [
					"craftToken",
					"platform",
					"rope",
					"pylon"
				].includes(e.kind)).filter((e, t, n) => n.findIndex((t) => t.kind === e.kind && t.a === e.a) === t).map((e) => /* @__PURE__ */ m("button", {
					onClick: () => {
						e.kind === "craftToken" ? A(e) : (oe({ kind: e.kind }), y(null));
					},
					children: j(e)
				}, e.id))] })]
			})] })),
			v === "market" && z(p("games.terraria.market"), /* @__PURE__ */ h("div", {
				className: "terraria-shop",
				children: [/* @__PURE__ */ m("div", {
					className: "terraria-residents",
					children: e.npcs.map((e) => /* @__PURE__ */ m("b", { children: Q(e, p) }, e))
				}), O.filter((e) => [
					"buyAction",
					"buyConsumable",
					"spawnNpc",
					"bottle",
					"food",
					"nurse",
					"goblin"
				].includes(e.kind)).map((e) => /* @__PURE__ */ h("article", { children: [e.a && De(e.a), /* @__PURE__ */ m("button", {
					onClick: () => A(e),
					children: j(e)
				})] }, e.id))]
			})),
			v === "log" && z(p("games.terraria.journal"), /* @__PURE__ */ m("ol", {
				className: "terraria-journal",
				children: e.log.slice().reverse().map((e, t) => /* @__PURE__ */ m("li", { children: e.key in Un ? p(Un[e.key], {
					name: D(e.who),
					item: Q(e.item, p),
					n: e.n
				}) : "" }, t))
			})),
			b && z(Q(b, p), De(b))
		]
	});
}
//#endregion
//#region src/games/terraria/bot.ts
var cr = (e) => e.startsWith("e") ? w(e).dice.reduce((e, t) => e + t, 0) + w(e).chop * 3 + w(e).dig * 3 + w(e).yield_ * 2 : e.startsWith("r") ? T(e)?.dice.reduce((e, t) => e + t, 0) ?? 0 : 5, lr = {
	explore: 1,
	danger: 0,
	gear: 1
};
function ur(e, t, n, r, i = lr) {
	let a = t.people.find((e) => e.rid === n), o = e.a ?? "", s = e.n ?? 1, c = e.b ?? "", l = e.kind;
	if (l === "end") return -10;
	if (l === "skip" || l === "lootDecline") return -30;
	if (l === "resume" || l === "unready" || l === "ready" || l === "consumable" && a.hp > 2) return -1e3;
	if (l === "prepared") return 20;
	if (l === "equip") return cr(o) - cr(a.equipped[w(o).slot] || o);
	if (l === "armor") return cr(o) - cr(a.armor || "");
	if (l === "objective" || l === "discover") return 100;
	if (l === "focus") return -200;
	if (l === "card") {
		let n = Se[a.hand.find((e) => e.uid === o).type].branches[+(e.flag ?? 0)][s];
		return n.kind === "lowHeal" && a.hp >= a.maxHp || n.kind === "health" && a.hp >= a.maxHp || n.kind === "mana" && a.mana >= a.maxMana ? -50 : n.kind === "deescalate" ? a.hp > 4 && t.threat >= 4 ? 60 : -50 : n.kind === "teleport" ? -70 : n.kind === "copy" && r.actions > 100 ? -20 : n.kind === "ap" ? 40 + (n.n ?? 1) * 2 : n.kind === "draw" ? 50 : n.kind === "coins" ? 30 : n.kind === "health" || n.kind === "lowHeal" ? 60 : 15;
	}
	if (l === "craft") return a.equipment.includes(o) || a.armors.includes(o) ? -100 : (cr(o) - (o.startsWith("e") ? cr(a.equipped[w(o).slot] || o) : cr(a.armor))) * i.gear + 25;
	if (l === "tool") {
		let e = w(o), n = t.world.flatMap((e) => e.cells.map((t, n) => ({
			token: t,
			x: e.x * 3 + n % 3,
			y: e.y * 5 + Math.floor(n / 3)
		}))).filter((e) => Math.max(Math.abs(e.x - a.x), Math.abs(e.y - a.y)) <= 1);
		return e.chop ? a.chop < 3 && n.some((e) => e.token.startsWith("T") && !t.acorns.some((t) => t.x === e.x && t.y === e.y)) ? 10 : -50 : a.dig + a.hardyDig < 4 && n.some((e) => k[e.token]) ? 8 : -50;
	}
	if (l === "dig") {
		let n = k[t.world.find((t) => t.x === Math.floor(e.x / 3) && t.y === Math.floor(e.y / 5)).cells[e.y % 5 * 3 + e.x % 3]]?.resource ?? "", r = a.inventory.filter((e) => e.resource === n).reduce((e, t) => e + t.n, 0);
		return (n && r < 5 ? 35 : 8) + (e.y > a.y ? 3 : 0);
	}
	if (l === "chop") return a.inventory.filter((e) => e.resource === "wood").reduce((e, t) => e + t.n, 0) < 8 ? 38 : 1;
	if (l === "chest" || l === "collect") return 70;
	if (l === "house") return t.houses.some((e) => e.type === o) ? -100 : 60 - (Math.abs(e.x - a.x) + Math.abs(e.y - a.y));
	if (l === "spawnNpc") return 60;
	if (l === "buyAction") return a.coins >= s + 5 || s <= 5 ? 25 - s / 4 : -20;
	if (l === "nurse") return a.hp <= 2 ? 90 : -20;
	if (l === "bottle" || l === "takeItem" || l === "lootPick") return 40 + cr(o);
	if (l === "food") return s === 1 && a.hp < a.maxHp ? 60 : s === 2 ? 35 : -20;
	if (l === "store") {
		let e = a.inventory[+c], t = o, n = a.inventory.filter((e) => e.resource === t).reduce((e, t) => e + t.n, 0), r = e.resource === t ? 5 - e.n : 5;
		return 50 + s * 2 + (e.n === 0 || e.resource === t ? 5 : -e.n * 5) + (n < 5 ? 5 : -10) + +(s === r);
	}
	if (l === "shareTake") return 40 + s + +(e.who === n);
	if (l === "scrapCard" || l === "springScrap") {
		let e = [...a.hand, ...a.discard].find((e) => e.uid === o);
		return e?.type === "s4" ? 30 : e?.type.startsWith("s") ? 20 : -20;
	}
	if (l === "roll" || l === "finishTargets" || l === "resolveBattle") return 20;
	if (l === "modifyDie") return 30;
	if (l === "dropDie") return 30 - Number(o);
	if (l === "boost") {
		let e = t.battle, n = +o;
		if (e.enemyAttack) {
			let t = Math.max(...e.defended), r = Math.max(...e.defended.map((e, t) => t === n ? e + s : e)), i = e.rolled.filter((e) => e >= t).length - e.rolled.filter((e) => e >= r).length;
			return i > 0 ? 50 + i * 20 - s : -30;
		}
		let r = e.rolled[n], i = Math.max(...e.defended);
		return r < i && r + s >= i ? 60 - s : -30;
	}
	if (l === "reroll") return -5;
	if (l === "activate") return 10;
	if (l === "enemyTarget" || l === "bossTarget" || l === "wormTeleport" || l === "enemyHit") return 10 + (t.people.find((e) => e.rid === c)?.hp ?? 0);
	if (l === "enemyMove" || l === "bossMove") return 10 - t.people.reduce((t, n) => t + +(Math.max(Math.abs(e.x - n.x), Math.abs(e.y - n.y)) <= 1), 0);
	if (l === "bossBuff") return e.n === 0 ? 20 : e.n === 2 ? 15 : 10;
	if (l === "weapon") return a.hp >= 3 ? 12 : -10;
	if (l === "weaponTarget") {
		let e = t.enemies.find((e) => e.uid === c);
		return e ? 40 + w(o).dice.reduce((e, t) => e + t, 0) - e.hp * 2 : c === "boss" ? 30 : 25;
	}
	if (l === "respawn" || l === "teleport") return 20 - Math.abs(e.x - 25) - Math.abs(e.y - 4);
	if ([
		"move",
		"ropeMove",
		"hook"
	].includes(l)) {
		let n = r.visits[e.x + ":" + e.y] ?? 0, o = -100;
		for (let n of t.world) for (let t = 0; t < 15; t++) {
			let r = n.cells[t], i = n.x * 3 + t % 3, s = n.y * 5 + Math.floor(t / 3), c = Math.hypot(e.x - i, e.y - s), l = Math.hypot(a.x - i, a.y - s), u = r.startsWith("C") ? 18 : r.startsWith("T") ? 8 : k[r]?.resource ? 6 : 0;
			(r === "Larva" || r === "Orb4" || r === "Heart4") && (u = 16), u && (o = Math.max(o, u / (1 + c) + (l - c) * 2));
		}
		let c = t.enemies.filter((t) => Math.max(Math.abs(t.x - e.x), Math.abs(t.y - e.y)) <= 1).length, l = (e.y - a.y) * i.explore;
		return o + l - n * 6 - c * i.danger * 3 - (s - 1) * 2;
	}
	return [
		"assistDraw",
		"assistSplit",
		"discardDraw",
		"discardCard",
		"keepDraw",
		"fetchCard",
		"spawnPick",
		"displaceWho",
		"displaceTo",
		"freePlatform",
		"reveal",
		"throwTarget",
		"finisherTarget",
		"copyEffect",
		"markEnemy"
	].includes(l) ? 20 : l === "focus" || l === "donate" || l === "pylon" || l === "travel" || l === "craftToken" || l === "platform" || l === "rope" ? -30 : l === "useConsumable" ? c === "coins" ? 10 : 30 : l === "reduceThreat" ? 30 + t.threat * 5 : l === "shareCoins" || l === "coinOrThreat" ? 30 : l === "consumable" ? a.hp <= 2 ? 20 : -25 : l === "lootPick" && O(o) ? 20 : 0;
}
function dr(e = lr) {
	return (t, n) => {
		let r = t.private?.choices ?? [];
		if (!r.length || r.every((e) => e.kind === "resume")) return null;
		let i = t.public.people.find((e) => e.rid === n.rid), a = n.memory, o = i.x + ":" + i.y, s = a ? {
			...a,
			visits: { ...a.visits }
		} : {
			visits: {},
			lastSerial: -1,
			position: "",
			actions: 0
		};
		if (s.position !== o && (s.visits[o] = (s.visits[o] ?? 0) + 1, s.position = o), s.lastSerial = t.public.serial, s.actions++, n.difficulty === "weak") return {
			action: {
				type: "choose",
				id: r[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % r.length].id
			},
			memory: s
		};
		let c = r[0], l = -Infinity;
		for (let i of r) {
			let r = ur(i, t.public, n.rid, s, e);
			r > l && (l = r, c = i);
		}
		return {
			action: {
				type: "choose",
				id: c.id
			},
			memory: s
		};
	};
}
var fr = dr(), pr = (e, t, n) => {
	let r = t.private?.choices.find((t) => e.type === "choose" && t.id === e.id);
	return r ? Zn(r, t.public, n, () => n("games.terraria.everyone")) : n("games.terraria.wait");
};
//#endregion
//#region src/games/terraria/fx.tsx
function mr({ at: e, values: t }) {
	let i = r(null);
	return n(() => {
		let e = i.current?.animate([
			{
				transform: "translateY(-16px) rotate(-12deg)",
				opacity: 0
			},
			{
				transform: "translateY(3px) rotate(4deg)",
				opacity: 1,
				offset: .55
			},
			{
				transform: "translateY(0) rotate(0)",
				opacity: 1
			}
		], {
			duration: 480,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ m("div", {
		className: "terraria-fx-sprite",
		ref: i,
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			display: "flex",
			gap: 5
		},
		children: t.map((e, t) => /* @__PURE__ */ m("span", {
			className: "terraria-die",
			children: e
		}, t))
	});
}
function hr({ at: e }) {
	let t = r(null);
	return n(() => {
		let n = [...t.current?.children ?? []].map((t, n) => t.animate([{
			transform: "translate(0,0)",
			opacity: 1
		}, {
			transform: `translate(${(n % 3 - 1) * e.w * .6}px,${(n < 3 ? -1 : 1) * e.h * .6}px) rotate(${n * 45}deg)`,
			opacity: 0
		}], {
			duration: 480,
			easing: "ease-out",
			fill: "both"
		}));
		return () => n.forEach((e) => e.cancel());
	}, [e]), /* @__PURE__ */ m("div", {
		ref: t,
		style: {
			position: "absolute",
			left: e.x + e.w / 2,
			top: e.y + e.h / 2
		},
		children: Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ m("i", { className: "terraria-fx-spark" }, t))
	});
}
function gr({ item: e }) {
	let t = s();
	return /* @__PURE__ */ m("div", {
		className: "terraria-fx-card",
		children: /* @__PURE__ */ m("span", { children: e ? Q(e, t) : "Terraria" })
	});
}
function _r({ item: e, n: t }) {
	let n = s(), r = Pn(e);
	return /* @__PURE__ */ h("div", {
		className: "terraria-fx-resource",
		children: [
			r && /* @__PURE__ */ m("img", {
				src: r,
				alt: ""
			}),
			/* @__PURE__ */ h("b", { children: ["+", t] }),
			/* @__PURE__ */ m("span", { children: Q(e, n) })
		]
	});
}
var vr = (e) => e && e.w > 0 && e.h > 0 ? e : null, yr = {
	terrariaMove: (e, t) => {
		let n = e.data, r = t.anchor("cell:" + n.from.x + ":" + n.from.y), i = t.anchor("person:" + e.rid), a = t.member(e.rid ?? "");
		return !r || !i || !a ? null : n.teleport ? {
			ms: 480,
			node: /* @__PURE__ */ m(_, {
				at: i,
				ms: 480
			})
		} : {
			ms: 480,
			hide: t.queued ? [] : ["person:" + e.rid],
			node: /* @__PURE__ */ m(ae, {
				from: r,
				to: i,
				ms: 480,
				children: /* @__PURE__ */ m("img", {
					className: "terraria-fx-avatar",
					src: ne[a.avatar % ne.length],
					alt: "",
					style: {
						width: i.w,
						height: i.h
					}
				})
			})
		};
	},
	terrariaDraw: (e, t) => {
		let n = t.anchor("deck:" + e.rid) ?? t.anchor("seat:" + e.rid), r = t.anchor("hand:" + e.rid) ?? t.anchor("seat:" + e.rid);
		return n && r ? {
			ms: 480,
			node: /* @__PURE__ */ m(ae, {
				from: n,
				to: {
					...r,
					w: 75,
					h: 98
				},
				ms: 480,
				children: /* @__PURE__ */ m(gr, {})
			})
		} : null;
	},
	terrariaPlay: (e, t) => {
		let n = e.data, r = t.anchor("hand:" + e.rid), i = vr(t.anchor("played:" + e.rid)) ?? t.anchor("seat:" + e.rid);
		return r && i ? {
			ms: 480,
			node: n.complete ? /* @__PURE__ */ m(ae, {
				from: {
					...r,
					w: 75,
					h: 98
				},
				to: {
					...i,
					w: 75,
					h: 98
				},
				ms: 480,
				children: /* @__PURE__ */ m(gr, { item: n.item })
			}) : /* @__PURE__ */ m(_, {
				at: r,
				ms: 480
			})
		} : null;
	},
	terrariaResource: (e, t) => {
		let n = e.data, r = t.anchor("person:" + e.rid), i = vr(t.anchor("inventory:" + e.rid)) ?? t.anchor("seat:" + e.rid);
		return r && i ? {
			ms: 480,
			node: /* @__PURE__ */ m(ae, {
				from: {
					...r,
					w: 72,
					h: 58
				},
				to: {
					...i,
					w: 72,
					h: 58
				},
				ms: 480,
				children: /* @__PURE__ */ m(_r, {
					item: n.item,
					n: n.n
				})
			})
		} : null;
	},
	terrariaRoll: (e, t) => {
		let n = e.data, r = t.anchor("battle");
		return r ? {
			ms: 480,
			node: /* @__PURE__ */ m(mr, {
				at: r,
				values: [...n.attack, ...n.defense]
			})
		} : null;
	},
	terrariaBreak: (e, t) => {
		let n = e.data, r = t.anchor("cell:" + n.x + ":" + n.y);
		return r ? {
			ms: 480,
			node: /* @__PURE__ */ m(hr, { at: r })
		} : null;
	},
	terrariaEvent: (e, t) => {
		let n = e.data, r = t.anchor(e.rid ? "person:" + e.rid : "cell:" + n.x + ":" + n.y) ?? t.anchor("objectives");
		return r ? {
			ms: 480,
			node: n.event === "damage" ? /* @__PURE__ */ m(g, {
				at: r,
				ms: 480,
				children: /* @__PURE__ */ h("span", {
					style: {
						color: "#f9a69d",
						fontSize: 24
					},
					children: ["−", n.n]
				})
			}) : /* @__PURE__ */ m(_, {
				at: r,
				ms: 480
			})
		} : null;
	}
};
//#endregion
//#region src/games/terraria/game-over.tsx
function br({ public: e, result: t, members: n, myRid: r, hintCount: a, onPlayAgain: c, onBackToLobby: l }) {
	let u = e, f = s(), ee = o((e) => e.locale), [ne, p] = i(!1), re = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? te(t, ee) : f("games.terraria.everyone");
	};
	return /* @__PURE__ */ h("div", {
		className: "terraria-screen terraria-over",
		children: [/* @__PURE__ */ m("div", {
			className: "terraria-final-map",
			inert: !ne,
			children: /* @__PURE__ */ m(ir, {
				pub: u,
				members: n,
				me: r,
				candidates: [],
				onChoose: () => void 0,
				nameOf: re,
				overview: !0
			})
		}), ne ? /* @__PURE__ */ m("button", {
			className: "terraria-result-return",
			onClick: () => p(!1),
			children: f("games.terraria.showResult")
		}) : /* @__PURE__ */ m("div", {
			className: "terraria-ending",
			children: /* @__PURE__ */ h("section", {
				className: "terraria-ending-card",
				children: [
					/* @__PURE__ */ m("div", {
						className: "terraria-ending-forest",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ m("small", { children: f("games.terraria.name") }),
					/* @__PURE__ */ m("h1", { children: f(u.result === "win" ? "games.terraria.resultWin" : "games.terraria.resultLoss") }),
					/* @__PURE__ */ m("p", { children: f("games.terraria.resultDetail", {
						day: u.day,
						n: u.completed.length,
						bosses: u.defeated.length
					}) }),
					/* @__PURE__ */ h("div", {
						className: "terraria-ending-stats",
						children: [
							/* @__PURE__ */ h("span", { children: [f("games.terraria.objectives"), /* @__PURE__ */ m("b", { children: u.completed.length })] }),
							/* @__PURE__ */ h("span", { children: [f("games.terraria.bossDetails"), /* @__PURE__ */ m("b", { children: u.defeated.length })] }),
							/* @__PURE__ */ h("span", { children: [f("games.terraria.threat", { n: u.threat }), /* @__PURE__ */ h("b", { children: [u.threat, "/10"] })] })
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "terraria-ending-list",
						children: u.defeated.map((e) => /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("img", {
							src: Mn[e],
							alt: ""
						}), Q(e, f)] }, e))
					}),
					/* @__PURE__ */ m("div", {
						className: "terraria-ending-objectives",
						children: u.completed.map((e, t) => /* @__PURE__ */ m("span", { children: Q(e, f) }, e + ":" + t))
					}),
					/* @__PURE__ */ m("div", {
						className: "terraria-ending-members",
						children: n.map((e) => /* @__PURE__ */ h("article", {
							style: { borderColor: d[e.colorIndex % d.length].hex },
							children: [/* @__PURE__ */ m("b", { children: re(e.rid) }), t.autopilot?.[e.rid] !== void 0 && t.autopilot[e.rid] > 0 && /* @__PURE__ */ m("small", { children: f("games.terraria.autopilot", { n: Math.round(t.autopilot[e.rid] * 100) }) })]
						}, e.rid))
					}),
					a !== void 0 && a > 0 && /* @__PURE__ */ m("p", { children: f("session.hint.usedCount", { n: a }) }),
					/* @__PURE__ */ h("div", {
						className: "terraria-ending-controls",
						children: [
							/* @__PURE__ */ m("button", {
								onClick: () => p(!0),
								children: f("games.terraria.review")
							}),
							c && /* @__PURE__ */ m(oe, {
								compact: !0,
								label: f("games.terraria.again"),
								confirmLabel: f("games.terraria.againConfirm"),
								onConfirm: c
							}),
							l && /* @__PURE__ */ m(oe, {
								compact: !0,
								label: f("games.terraria.lobby"),
								confirmLabel: f("games.terraria.leaveConfirm"),
								onConfirm: l
							}),
							!c && !l && /* @__PURE__ */ m("span", { children: f("games.terraria.waitingHost") })
						]
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/games/terraria/options.tsx
function xr({ value: e, onChange: t }) {
	let n = s(), r = Ge.parse(e ?? {});
	return /* @__PURE__ */ h("div", {
		className: "terraria-options",
		children: [
			/* @__PURE__ */ h("label", { children: [n("games.terraria.difficulty"), /* @__PURE__ */ h("select", {
				value: r.difficulty,
				onChange: (e) => t({
					...r,
					difficulty: e.target.value
				}),
				children: [
					/* @__PURE__ */ m("option", {
						value: "journey",
						children: n("games.terraria.journey")
					}),
					/* @__PURE__ */ m("option", {
						value: "standard",
						children: n("games.terraria.standard")
					}),
					/* @__PURE__ */ m("option", {
						value: "tough",
						children: n("games.terraria.tough")
					}),
					/* @__PURE__ */ m("option", {
						value: "heroic",
						children: n("games.terraria.heroic")
					})
				]
			})] }),
			/* @__PURE__ */ h("label", { children: [n("games.terraria.evil"), /* @__PURE__ */ h("select", {
				value: r.evil,
				onChange: (e) => t({
					...r,
					evil: e.target.value
				}),
				children: [/* @__PURE__ */ m("option", {
					value: "corruption",
					children: n("games.terraria.corruption")
				}), /* @__PURE__ */ m("option", {
					value: "crimson",
					children: n("games.terraria.crimson")
				})]
			})] }),
			/* @__PURE__ */ h("label", { children: [n("games.terraria.initialThreat"), /* @__PURE__ */ m("select", {
				value: r.threat,
				onChange: (e) => t({
					...r,
					threat: Number(e.target.value)
				}),
				children: [
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ m("option", {
					value: e,
					children: e
				}, e))
			})] }),
			/* @__PURE__ */ h("label", { children: [/* @__PURE__ */ m("input", {
				type: "checkbox",
				checked: r.alternatives,
				onChange: (e) => t({
					...r,
					alternatives: e.target.checked
				})
			}), n("games.terraria.alternatives")] }),
			/* @__PURE__ */ h("label", { children: [/* @__PURE__ */ m("input", {
				type: "checkbox",
				checked: r.focus,
				onChange: (e) => t({
					...r,
					focus: e.target.checked
				})
			}), n("games.terraria.focusRule")] })
		]
	});
}
//#endregion
//#region src/games/terraria/guide.tsx
function Sr() {
	let e = s();
	return /* @__PURE__ */ m("div", {
		tabIndex: 0,
		style: {
			height: "100dvh",
			overflowY: "auto",
			padding: 16,
			boxSizing: "border-box",
			whiteSpace: "pre-line",
			lineHeight: 1.7
		},
		children: e("games.terraria.rules")
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/terraria/entry.tsx
var Cr = {
	definition: An,
	View: or,
	bot: fr,
	describe: pr,
	fx: yr,
	OverView: br,
	Options: xr,
	Guide: Sr,
	locales: {
		zh: {
			name: "泰拉瑞亚：桌游版",
			movement: "移动力",
			flying: "飞行",
			burrowing: "钻地",
			bossRules: {
				kingSlime: "防御：2D6。行为A：若同一地表生态区没有角色，先传送至离角色最近的已揭示生成点；移动1格，短程攻击2D6+D4。行为B：移动2格，短程攻击2D6，其他史莱姆移动力增加1。可穿过房屋。",
				eye: "防御：第一形态D6+D8，第二形态D8。行为A：飞行2格，短程攻击3D6；蓝色盟友各增加一次攻击。行为B：飞行3格，短程攻击2D6+D8；白昼时在该敌人阶段结束后逃离。移动可穿过方块与房屋。",
				brain: "第一形态需选择一个盟友作为攻击目标，其防御为2D6或D6+D8；一次成功只移除一个盟友。移除全部盟友后转为第二形态，防御2D8。行为A：飞行3格，短程攻击3D6。行为B：飞行2格，短程攻击2D6+D8。可穿过方块与房屋。",
				eater: "防御：2D8。激活时选择腐化区域内任意角色，掷D6决定在该角色板块的第三行或第五行、对应列出现；必须改变位置。行为A：短／中程攻击3D6。行为B：短程攻击2D6+D8。移动与视线无视方块、房屋和棋件；腐化区域内没有角色时逃离。",
				queenBee: "防御：D6+D4。两个行为均飞行2格，可穿过方块与房屋。行为A：短程攻击D6+D8。行为B：远程攻击D6，命中使角色中毒。开始敌人阶段时，若任何占格位于丛林以外，额外加入一个盟友。",
				wall: "第一形态分别攻击上下眼睛，防御D8+D12；第二形态只能攻击嘴部，防御2D12。行为A向右移动1格，行为B向右移动2格；均短程攻击2D20，每只尚存眼睛另以2D12远程攻击。可穿过方块和房屋，角色不能穿过它。离开地狱的角色立即死亡；它移出已揭示地狱时全队死亡。击败它立即获胜。"
			},
			desc: "合作探索地表与洞穴，采集资源、建造房屋并挑战首领。",
			rules: "目标：\n1–4 人合作探索 Terraria 世界。标准难度完成任意一条十级目标链；困难完成两条，英雄完成三条。旅程难度完成一条六级目标链。击败血肉墙也会立即获胜。威胁达到10时立即失败。\n准备：\n每人有5生命、3魔力和八张起始行动牌，装备铜斧、铜镐和铜短剑。根据人数开放四至六个资源槽，每槽最多存放5个同类资源，金币上限25。旅程难度改用铁制起始装备与两根绳索，免除跌落伤害和死亡威胁。\n流程：\n每轮依次进行角色、敌人和环境阶段。角色阶段开始时先选择本轮装备和护甲，再处理异常状态，按护甲抽牌值抽牌。玩家可以自由交错行动。行动牌中以“或”相连的效果只能选一支，以“并且”相连的效果可以在本阶段不同时间使用。防御点可以留到敌人阶段，未用行动、砍伐和挖掘点在角色阶段结束时失效；本回合战斗效果继续有效。所有人结束后，必须完成仍可进行的探索与目标，再检查首领出现条件。\n移动与探索：\n支付1行动点可向八邻格移动，不能穿过两块接角的实心方块。可以经过角色或敌人，但必须有足够行动点走到无人占据的格子。没有支撑时立即下落；超过1格的跌落以防御骰总和抵消跌距，蛛网、熔岩及旅程模式免除跌伤。绳索允许留在空中，已经下落时不能抓住绳索。沿绳索1行动点移动最多2格，建有织布机房后最多3格。\n所在板块的正交相邻位置没有板块时，可以免费探索所有这些位置。新板块上未被遮住的骷髅格立即从对应生态和深度的有限敌袋中生成敌人。地表根据白昼或夜晚使用对应敌袋。\n采集与建造：\n使用斧或镐将行动点转换为砍伐或挖掘点，可留存并分次支付。资源方块按图示费用挖掘，坚硬方块必须使用坚硬挖掘点；砍树支付树上的费用，获得相同数量木材，再计产量加成。进入或经过蛛网格可以收集蛛网。挖空后可以免费进入新格，挖脚下方块可能立即跌落。树木到日出恢复。\n支付1行动点打开身旁未被遮住的宝箱，按图示数量抽宝箱牌，选择对应深度的一项奖励；所有宝箱牌按抽取顺序放回牌堆底。行动牌奖励抽两张选一张，另一张回底。物品与敌人供应有限。获得的行动牌放入弃牌堆。资源装不下时由接收者选择保存、换槽、转赠或丢弃；不会自动丢掉原有物资。\n制作不消耗行动点。支付配方资源，并满足已建房屋要求；无需靠近该房屋。每个装备槽只使用最上方一件，新制作装备立即装备；旧装备保留到下轮选择。房屋必须覆盖自身或邻格，不能覆盖实心方块和敌人，可以浮空。绳索、房屋与传送晶塔覆盖骷髅格会增加一次当前威胁增量。木材制作平台，蛛网制作绳索；平台放在自身或邻格的底边，绳索放在相邻空格并向下延伸至阻挡。\n支付1行动点可向任意距离的另一名角色捐赠任意数量的一种资源、金币、平台或绳索，或一件装备、护甲或消耗品。第五资源槽价格15金币，第六槽25金币。\n战斗：\n选择已装备武器并支付行动点或魔力。短射程包括八邻格；仅中、长射程的角色武器不能攻击邻格。中射程和长射程按尺进入目标方格边缘的位置测量；长射程超过3格丢1枚攻击骰，超过5格丢2枚，超过7格不可攻击。实心方块与接角方块阻挡视线，屋外看不进屋内，屋内可以看见屋外。无视视线的武器例外。\n投掷攻击和防御骰。每枚攻击骰达到或超过最高防御结果，造成1点伤害。攻击点只能加在一枚攻击骰上，防御点只能加在一枚防御骰上，点数可超过骰子面数。穿刺可以攻击符合相邻连通及同一直线要求的多个敌人，只有最近目标必须在射程内，共用攻击结果，各自防御与反击。未被击败的敌人在射程和视线允许时反击，使用刚才最高防御结果作为一枚攻击骰。防止反击效果例外。\n敌人阶段：\n所在板块或正交相邻板块有角色时，普通敌人激活。全队选择激活顺序、等距目标、等距终点和受击顺序。敌人朝最近角色移动；只有已经邻接目标才不动，有视线按移动力移动，否则仅移动1格。它随后攻击所有在射程和视线内的角色。飞行敌人不下落，蠕虫可以穿方块，普通敌人不能进入房屋。\n环境与异常状态：\n环境阶段弃掉所有未留在准备槽中的在场行动牌，时间前进一格，再结算威胁和生成图标。日出清除树上橡实、地表夜间敌人和坠星，恢复魔力及房屋奖励。第二天日出会触发史莱姆王。\n异常状态持续两次角色阶段。冰冻本轮少抽1张牌；着火在角色阶段开始时失去2生命；中毒弃掉准备牌并禁止本轮准备牌。护甲与准备牌提供的免疫可在处理前清除相应异常。新的相同异常将剩余持续时间重置为两次。\n死亡与首领：\n角色死亡后清除异常、失去一半金币（向下取整），弃掉消耗品与随从，保留资源与装备，把所有行动牌洗成牌库。取走一枚墓碑并增加当前威胁增量；取走最后墓碑后，增量永久变为2。没有墓碑时死亡直接增加2威胁。下轮开始在森林地表空格或床房空格满生命、魔力复活。\n首领条件在角色阶段结束时检查，下一敌人阶段开始且没有其他首领时出现，威胁增量变为2。出现当轮不添加盟友，之后按首领卡添加盟友和执行特殊效果，行为A与B在敌人阶段结束交替。形态转换丢弃过量伤害，本角色阶段不能再次攻击该首领。击败后按奖励卡分配物资；墓碑耗尽造成的威胁增量不会恢复。\n准备牌与城镇居民：\n只能把完全未用的手牌放入准备槽；原准备牌回手。准备牌除写明的准备效果外不能使用，可随时取回。新行动牌进入弃牌堆；抓取牌库中的牌不会洗牌。城镇居民按其条件与可用房屋生成，向导始终存在且不占房屋。向导与商人出售行动牌，商人及爆破专家提供消耗品，护士在没有首领时提供治疗，哥布林工匠提供移除行动牌，树妖提供全队共享的D8。\n可选规则：\n开局可选择腐化或猩红生态、初始威胁0–3、替代目标及目标专注。专注目标第一次未完成时翻面，第二次仍未完成时清除专注标记并增加一次当前威胁增量。替代目标在对应等级随机使用。本次采用2026规则与配件参考版本，不纳入节日促销牌。",
			invalidAction: "该选择已经失效，请重新选择。",
			day: "第 {{n}} 天",
			round: "第 {{n}} 轮",
			threat: "威胁 {{n}} / 10",
			graves: "剩余墓碑 {{n}}",
			phase: {
				prepare: "选择本轮装备",
				character: "角色阶段",
				enemy: "敌人阶段",
				environment: "环境阶段",
				done: "冒险结束"
			},
			time: {
				day: "白昼",
				night: "夜晚",
				sunrise: "日出"
			},
			group: {
				cards: "行动牌",
				move: "移动与探索",
				gather: "采集",
				fight: "战斗",
				build: "建造",
				progress: "目标与阶段",
				other: "其他"
			},
			health: "生命",
			mana: "魔力",
			coins: "金币",
			ap: "行动点",
			attack: "攻击点",
			defense: "防御点",
			dig: "挖掘点",
			hardyDig: "坚硬挖掘点",
			chop: "砍伐点",
			hand: "手牌",
			ready: "准备牌",
			inventory: "物品栏",
			equipment: "装备",
			armor: "护甲",
			consumables: "消耗品",
			objectives: "目标",
			npcs: "居民",
			journal: "事件",
			close: "关闭",
			back: "返回",
			detail: "查看详情",
			world: "世界",
			fit: "全景",
			focusMe: "查看角色",
			choose: "选择",
			wait: "等待结算",
			waitOther: "等待 {{name}} 选择",
			everyone: "全队",
			unknown: "未知区域",
			discard: "弃牌堆",
			deck: "牌库",
			spent: "已使用",
			none: "无",
			end: "结束角色阶段",
			resume: "继续行动",
			confirmed: "已准备",
			cost: "费用",
			recipe: "制作配方",
			requires: "所需设施",
			range: "射程",
			short: "短射程",
			medium: "中射程",
			long: "长射程",
			sightless: "无视视线",
			prevent: "防止反击",
			pierce: "穿刺 {{n}}",
			draw: "抽 {{n}} 张牌",
			die: "D{{n}}",
			use: "使用",
			or: "或",
			plus: "并且",
			full: "已满",
			slot: "资源槽 {{n}}",
			count: "{{n}} 个",
			at: "位置 {{x}}, {{y}}",
			selectCard: "选择牌面效果",
			played: "已打出",
			dead: "等待复活",
			endReady: "已结束行动",
			resultWin: "世界因你们而不同",
			resultLoss: "黑暗笼罩了世界",
			victory: "冒险成功",
			defeat: "冒险失败",
			resultDetail: "第 {{day}} 天 · 完成 {{n}} 个目标 · 击败 {{bosses}} 个首领",
			review: "回看世界",
			showResult: "查看结果",
			again: "再来一局",
			lobby: "返回大厅",
			waitingHost: "等待主机选择下一步",
			leaveConfirm: "再次点击返回大厅",
			hintCount: "求助 {{n}} 次",
			autopilot: "托管 {{n}}%",
			objectLevel: "第 {{n}} 级",
			bossForm: "形态 {{n}}",
			bossBehavior: "行为 {{n}}",
			bossBuff: "盟友效果 {{n}}",
			combatAttack: "攻击骰",
			combatDefense: "防御骰",
			reward: "奖励",
			effect: "效果",
			noCards: "没有手牌",
			capacity: "每槽最多5个同类资源",
			face: "外观",
			search: "查找物品",
			difficulty: "难度",
			evil: "邪恶生态",
			initialThreat: "初始威胁",
			alternatives: "使用替代目标",
			focusRule: "目标专注",
			journey: "旅程",
			standard: "标准",
			tough: "困难",
			heroic: "英雄",
			corruption: "腐化",
			crimson: "猩红",
			forest: "森林",
			desert: "沙漠",
			snow: "雪地",
			jungle: "丛林",
			beach: "海洋",
			layer: {
				surface: "地表",
				underground: "地下",
				upperCavern: "上层洞穴",
				lowerCavern: "下层洞穴",
				underworld: "地狱"
			},
			prompts: {
				inventory: "分配获得的资源",
				loot: "选择奖励",
				share: "分配全队奖励",
				reward: "选择奖励",
				scrap: "选择要移除的牌",
				assist: "选择获得支援的角色",
				discard: "选择要弃掉的牌",
				keep: "选择保留的牌",
				fetch: "选择取回的牌",
				teleport: "选择落点",
				copy: "选择复制的效果",
				attackTarget: "选择攻击目标",
				explosive: "选择爆炸中心",
				discover: "探索相邻板块",
				objectives: "完成已满足的目标",
				enemyTarget: "选择敌人的目标",
				enemyMove: "选择敌人的落点",
				enemyAttackOrder: "选择先受攻击的角色",
				bossBuff: "放置一枚首领盟友",
				displace: "移开被首领覆盖的棋子",
				bossTeleport: "选择首领传送点",
				bossMove: "选择首领落点",
				consumable: "选择消耗品用途",
				enter: "进入刚挖空的格子？",
				chest: "选择宝箱奖励",
				scrapEquipment: "选择两件牺牲的武器",
				reclaim: "选择回收位置",
				platform: "放置免费平台",
				donate: "选择捐赠",
				spawn: "选择生成的敌人",
				wallBuff: "选择血肉墙效果",
				preventSpawn: "是否用隐身药水取消此次生成？",
				retaliation: "选择先结算的反击"
			},
			operations: {
				pierceOrigin: "选择穿刺射线起点",
				skip: "放弃本次选择",
				prepared: "确认本轮装备",
				equip: "装备 {{item}}",
				armor: "穿上 {{item}}",
				respawn: "在此复活",
				end: "结束行动",
				resume: "继续行动",
				store: "保存 {{n}} {{item}} 至 {{target}}",
				storeStockpile: "将 {{n}} {{item}} 放入储备槽",
				discardResource: "丢弃 {{n}} {{item}}",
				overflowDonate: "将 {{n}} {{item}} 赠予 {{target}}",
				takeItem: "获得 {{item}}",
				lootPick: "获得 {{item}}",
				lootDecline: "放弃行动牌奖励",
				shareTake: "将 {{n}} {{item}} 分给 {{target}}",
				shareCoins: "全队分配 {{n}} 金币",
				reduceThreat: "降低 {{n}} 威胁",
				loot: "获得 {{n}} 级行动牌",
				gain: "获得 {{item}}",
				shareResource: "全队分配 {{n}} {{item}}",
				coins: "获得 {{n}} 金币",
				resource: "获得 {{n}} {{item}}",
				ropeAward: "获得 {{n}} 根绳索",
				platformAward: "获得 {{n}} 个平台",
				scrapCard: "移除 {{item}}",
				card: "使用 {{item}}：{{effect}}",
				ready: "准备 {{item}}",
				unready: "取回准备牌",
				assistDraw: "让 {{item}} 抽 {{n}} 张牌",
				assistSplit: "让 {{item}} 与 {{target}} 各抽1张牌",
				discardDraw: "弃掉 {{item}} 并抽1张牌",
				discardCard: "弃掉 {{item}}",
				keepDraw: "保留 {{item}}",
				fetchCard: "取回 {{item}}",
				springScrap: "移除 {{item}} 与此牌",
				copyEffect: "复制 {{item}}：{{effect}}",
				markEnemy: "对 {{item}} 使用此效果",
				discover: "探索相邻区域",
				reveal: "探索此板块",
				move: "移动至此处（{{n}}行动点）",
				ropeMove: "沿绳索移动至此处",
				hook: "使用钩爪到此处",
				teleport: "移动至此处",
				travel: "传送至此晶塔",
				tool: "使用 {{item}}",
				chop: "砍树（{{n}}砍伐点）",
				dig: "挖掘（{{n}}挖掘点）",
				chest: "打开宝箱",
				chestPick: "选择 {{item}}",
				craft: "制作 {{item}}",
				nightsEdge: "制作永夜刃",
				forgeEdge: "牺牲 {{item}} 与 {{target}}",
				craftToken: "制作 {{item}}",
				reclaimToken: "回收此 {{item}}",
				house: "建造 {{item}}",
				platform: "在此放置平台",
				freePlatform: "在此放置免费平台",
				rope: "在此铺设绳索",
				pylon: "购买传送晶塔（10金币）",
				collect: "收集 {{item}}：{{effect}}",
				unlock: "解锁下一个资源槽",
				spawnNpc: "邀请 {{item}} 入住",
				buyAction: "购买 {{item}}（{{n}}金币）",
				buyConsumable: "购买随机 {{n}} 类消耗品",
				nurse: "支付10金币，完全治疗",
				goblin: "支付15金币，移除一张行动牌",
				bottle: "获得 {{item}}",
				food: "获得 {{effect}}",
				objective: "完成 {{item}}",
				focus: "专注 {{item}}",
				donate: "捐赠物品",
				donateTo: "赠予 {{target}}",
				donateResource: "赠予 {{target}} {{n}} {{item}}",
				donateCoins: "赠予 {{target}} {{n}} 金币",
				donateTokens: "赠予 {{target}} {{n}} {{item}}",
				donateItem: "将 {{item}} 赠予 {{target}}",
				weapon: "使用 {{item}} 攻击",
				weaponTarget: "攻击 {{target}}",
				finisherTarget: "以终结技攻击 {{target}}",
				minion: "召唤 {{item}}",
				summonEye: "献上1晶状体，召唤克苏鲁之眼",
				consumable: "使用 {{item}}",
				useConsumable: "使用 {{item}}：{{effect}}",
				throwTarget: "用 {{item}} 攻击 {{target}}",
				explode: "将 {{item}} 投至此处",
				finishTargets: "确认攻击目标",
				pierceTarget: "穿刺 {{item}}",
				dropDie: "丢弃 {{item}}",
				modifyDie: "使用 {{effect}}",
				roll: "投掷骰子",
				boost: "向选定骰子投入 {{n}} 点",
				reroll: "重掷选定骰子",
				resolveBattle: "确认战斗结果",
				spawnPick: "生成 {{item}}",
				activate: "激活 {{item}}",
				enemyTarget: "{{item}} 朝 {{target}} 移动",
				enemyMove: "让 {{item}} 移动至此处",
				enemyHit: "攻击 {{target}}",
				bossBuff: "添加盟友：{{effect}}",
				wallThreat: "增加一次当前威胁增量",
				wallFire: "使地狱中的所有角色着火",
				bossTeleport: "让首领传送至此处",
				bossTarget: "朝 {{target}} 移动",
				bossMove: "让首领移动至此处",
				wormTeleport: "选择 {{target}} 所在板块",
				displaceWho: "先移开 {{item}}",
				displaceTo: "将 {{item}} 移至此处",
				copyCard: "复制 {{item}} 的效果",
				readyAP: "使用准备牌：获得 {{n}} 行动点",
				drop: "松开绳索并下落",
				giftCraft: "使用赠予的资源立即制作 {{item}}",
				preventSpawn: "使用隐身药水，取消此次生成",
				spawnAllowed: "允许敌人出现",
				retaliate: "先结算 {{item}} 的反击"
			},
			items: {
				e0: "铜斧",
				e1: "铁斧",
				e2: "银斧",
				e3: "金斧",
				e4: "嗜血狂斧",
				e5: "暗夜战斧",
				e6: "熔岩锤斧",
				e7: "铜镐",
				e8: "铁镐",
				e9: "银镐",
				e10: "金镐",
				e11: "梦魇镐",
				e12: "死亡使者镐",
				e13: "熔岩镐",
				e14: "铜短剑",
				e15: "铁短剑",
				e16: "银阔剑",
				e17: "金阔剑",
				e18: "魔光剑",
				e19: "血腥屠刀",
				e20: "火山",
				e21: "木弓",
				e22: "铁弓",
				e23: "银弓",
				e24: "金弓",
				e25: "恶魔弓",
				e26: "肌腱弓",
				e27: "熔火之怒",
				e28: "木悠悠球",
				e29: "抑郁球",
				e30: "血脉球",
				e31: "紫晶法杖",
				e32: "红玉法杖",
				e33: "小雪怪法杖",
				e34: "小鬼法杖",
				e35: "抓钩",
				e36: "永夜刃",
				e37: "养蜂人",
				e38: "蜂膝弓",
				e39: "蜜蜂枪",
				e41: "暗黑长戟",
				e42: "长矛",
				e43: "木回旋镖",
				e44: "附魔回旋镖",
				e45: "吹管",
				e46: "冰雪刃",
				e48: "亚马逊球",
				e49: "喷流球",
				e50: "地狱之翼弓",
				e51: "凤凰爆破枪",
				e52: "红玉钩",
				e53: "火花魔棒",
				e54: "雷霆电击枪",
				e55: "猩红魔杖",
				e56: "魔刺",
				e57: "火鞭",
				e58: "恶魔锄刀",
				e59: "火之花",
				e60: "史莱姆法杖",
				e61: "黄蜂法杖",
				c0: "弱效治疗药水",
				c1: "弱效魔力药水",
				c2: "飞刀",
				c3: "手里剑",
				c4: "敏捷药水",
				c5: "狱火药水",
				c6: "回忆药水",
				c7: "隐身药水",
				c8: "铁皮药水",
				c9: "挖矿药水",
				c10: "箭术药水",
				c11: "治疗药水",
				c12: "魔能药水",
				c13: "强效幸运药水",
				c14: "炸弹",
				c15: "炸药",
				c16: "魔力药水",
				c17: "水桶",
				c20: "向导巫毒娃娃",
				c21: "蜜蜂手榴弹",
				r8: "木盔甲",
				r9: "铜盔甲",
				r10: "铁盔甲",
				r11: "银盔甲",
				r12: "金盔甲",
				r13: "暗影盔甲",
				r14: "猩红盔甲",
				r15: "熔岩盔甲",
				r16: "死灵盔甲",
				r17: "巫师套装",
				r19: "忍者盔甲",
				r20: "蜜蜂盔甲",
				r21: "暗影木盔甲",
				r22: "乌木盔甲",
				r23: "丛林盔甲",
				r24: "挖矿盔甲",
				r25: "雪地盔甲",
				a0: "重振精神",
				a1: "深入探索",
				a2: "翻滚",
				a3: "恢复体力",
				a4: "连击",
				a5: "脱身之路",
				a6: "金属带扣",
				a7: "活力充沛",
				a8: "财源滚滚",
				a9: "勤勉",
				a10: "祈求好运",
				a11: "伸出援手",
				a12: "双倍收获",
				a13: "振奋呐喊",
				a14: "魔镜",
				a15: "侧身闪避",
				a16: "把握时机",
				a17: "饰品加身",
				a18: "搜刮",
				a19: "皮糙肉厚",
				a20: "星力手环",
				a21: "拿手好戏",
				a22: "平息冲突",
				a23: "再生手环",
				a24: "怒火中烧",
				a25: "脚镣",
				a26: "雷达",
				a27: "休想！",
				a28: "接招",
				a29: "双重麻烦",
				a30: "生命体分析机",
				a31: "鞋钉",
				a32: "回收",
				a33: "储备物资",
				a34: "赫尔墨斯靴",
				a35: "放马过来",
				a36: "威慑",
				a37: "整装待发",
				a38: "取回",
				a39: "终结一击",
				a40: "清理废物",
				a41: "弱点",
				a42: "打个落花流水！",
				a43: "出气筒",
				a44: "先见之明",
				a45: "上吧！",
				a46: "包扎伤口",
				a47: "大扫除",
				a48: "更深入地探索",
				a49: "灵巧闪躲",
				a50: "急中生智",
				a51: "痛击",
				a52: "固守",
				a53: "以物易物",
				a54: "模仿者",
				a55: "清除",
				a56: "备用计划",
				a57: "高效采集",
				a58: "探索无止境",
				s0: "冲锋",
				s1: "援助",
				s2: "闪避",
				s3: "休息",
				s4: "探索",
				s5: "深入探索",
				o0: "初探地表",
				o1: "闪闪发光",
				o2: "蛛网遍地",
				o3: "精挑细镐",
				o4: "压力之下",
				o5: "爆破时刻",
				o6: "邪恶之地？",
				o7: "清理一空",
				o8: "推土先锋",
				o9: "炽热之物",
				o10: "树倒啦！",
				o11: "工作台就绪",
				o12: "重金属",
				o13: "热火朝天地砍伐",
				o14: "地下家园",
				o15: "巧手制作",
				o16: "舒适的家",
				o17: "地产开发",
				o18: "锻造前行",
				o19: "地产大亨",
				o20: "有惊无险",
				o21: "整齐着装",
				o22: "锋芒初现",
				o23: "你能行！",
				o24: "灵活忍者",
				o25: "魔力永不弃",
				o26: "蜂刺行动／盯上你了",
				o27: "各个击破",
				o28: "智取巨脑／蠕虫诱饵",
				o29: "精心装扮",
				o30: "出发！",
				o31: "宝箱满满",
				o32: "战利品归我",
				o33: "地产经纪",
				o34: "美好邻里",
				o35: "陆地尽头",
				o36: "蜂蜜在哪里？",
				o37: "热浪袭来",
				o38: "马拉松奖章",
				o39: "快速交通网",
				o40: "碎心者",
				o41: "幸运突破",
				o42: "灼热劫掠",
				o43: "向上攀登！",
				o44: "时尚宣言",
				o45: "高楼林立",
				o46: "负重前行",
				o47: "睡衣派对",
				o48: "抛出钩索",
				o49: "你是巫师！",
				o50: "你的大军在哪里？",
				o51: "铜你道别",
				o52: "星之力量",
				o53: "夜不归宿",
				o54: "物价飞涨",
				o55: "地狱直通梯",
				wood: "木材",
				gel: "凝胶",
				stone: "石头",
				cobweb: "蛛网",
				copper: "铜",
				iron: "铁",
				silver: "银",
				gold: "金",
				demonite: "魔矿",
				crimtane: "猩红矿",
				hellstone: "狱石",
				gem: "宝石",
				lens: "晶状体",
				bone: "骨头",
				flinxFur: "小雪怪皮毛",
				workbench: "工作台房",
				anvil: "铁砧／熔炉房",
				loom: "织布机房",
				bottle: "炼药瓶房",
				cookingPot: "烹饪锅房",
				bed: "床房",
				hellforge: "地狱熔炉房",
				platform: "平台",
				rope: "绳索",
				platforms: "平台",
				ropes: "绳索",
				guide: "向导",
				merchant: "商人",
				nurse: "护士",
				goblin: "哥布林工匠",
				demolitionist: "爆破专家",
				dryad: "树妖",
				kingSlime: "史莱姆王",
				eye: "克苏鲁之眼",
				eater: "世界吞噬怪",
				brain: "克苏鲁之脑",
				queenBee: "蜂王",
				wall: "血肉墙",
				boss: "首领",
				fire: "着火",
				frozen: "冰冻",
				poison: "中毒",
				Orb4: "暗影珠",
				Heart4: "猩红之心",
				Larva: "幼虫",
				Altar: "祭坛",
				"Green Slime": "绿史莱姆",
				"Blue Slime": "蓝史莱姆",
				"Red Slime": "红史莱姆",
				"Yellow Slime": "黄史莱姆",
				"Black Slime": "黑史莱姆",
				"Lava Slime": "熔岩史莱姆",
				"Demon Eye": "恶魔眼",
				Zombie: "僵尸",
				"Giant Worm": "巨型蠕虫",
				"Cave Bat": "洞穴蝙蝠",
				Hellbat: "地狱蝙蝠",
				Skeleton: "骷髅",
				Salamander: "蝾螈",
				Vulture: "秃鹰",
				Antlion: "蚁狮",
				"Sand Slime": "沙史莱姆",
				"Antlion Swarmer": "蚁狮群",
				"Tomb Crawler": "墓穴爬虫",
				"Fire Imp": "火焰小鬼",
				Snatcher: "抓人草",
				"Jungle Slime": "丛林史莱姆",
				"Spiked Jungle Slime": "尖刺丛林史莱姆",
				"Jungle Bat": "丛林蝙蝠",
				Hornet: "黄蜂",
				"Ice Slime": "冰史莱姆",
				"Frozen Zombie": "冰冻僵尸",
				"Ice Bat": "冰蝙蝠",
				"Snow Flinx": "小雪怪",
				Crimera: "猩红喀迈拉",
				"Blood Crawler": "血爬虫",
				"Eater of Souls": "噬魂怪",
				Devourer: "吞噬怪",
				"Voodoo Demon": "巫毒恶魔",
				"Life Crystal": "生命水晶",
				"Fallen Star": "坠星",
				"Angry Bones": "愤怒骷髅",
				"Baby Slime": "小史莱姆"
			},
			effects: {
				ap: "获得 {{n}} 行动点",
				attack: "获得 {{n}} 攻击点",
				defense: "获得 {{n}} 防御点",
				health: "恢复 {{n}} 生命",
				lowHeal: "生命不超过2时恢复 {{n}} 生命",
				mana: "恢复 {{n}} 魔力",
				coins: "获得 {{n}} 金币",
				assist: "让其他角色抽共 {{n}} 张牌（单人由自己抽）",
				draw: "抽 {{n}} 张牌",
				drawKeep: "抽2张牌并保留1张",
				drawDiscard: "抽 {{n}} 张牌，再弃1张手牌",
				discardDraw: "弃1张手牌，再抽1张牌",
				freePlatforms: "免费放置最多2个平台",
				clearOthers: "清除其他角色的异常状态",
				fetch: "从允许的牌堆取回1张牌",
				scrap: "移除最多 {{n}} 张手牌或弃牌",
				springScrap: "移除1张手牌与此牌",
				copy: "复制1张符合条件行动牌的效果",
				deescalate: "降低1威胁并失去4生命",
				teleport: "传送到森林地表或床房",
				finisher: "全队在同一板块时进行3D20攻击，随后移除此牌",
				industry: "同生态的角色各获得1砍伐点和1挖掘点",
				rally: "同生态角色获得2攻击与2防御",
				yield: "同生态采集增加1产量",
				freeDonate: "本回合捐赠不消耗行动点",
				doubleConsumable: "将一个消耗品使用两次",
				enemyAttackReroll: "本回合可重掷一个敌人的最高攻击结果",
				enemyDefenseReroll: "本回合可重掷一个敌人的最高防御结果",
				shakedown: "本回合击败非首领敌人时获得双倍掉落",
				duplicateDefense: "本回合复制一枚最小防御骰",
				regenKill: "本回合每击败一个非首领敌人恢复1生命",
				radar: "生成敌人时抽 {{n}} 选1",
				enemySmallAttackDemote: "本回合降低一个敌人的最小攻击骰",
				enemySmallDefenseDemote: "本回合降低一个敌人的最小防御骰",
				enemyLargeAttackDemote: "本回合降低一个敌人的最大攻击骰",
				enemyLargeDefenseDemote: "本回合降低一个敌人的最大防御骰",
				enemyRemoveAttack: "本回合移除一个敌人的最小攻击骰（至少留1枚）",
				enemyRemoveDefense: "本回合移除一个敌人的最小防御骰（至少留1枚）",
				punchbag: "本回合每失去1生命获得3金币",
				foresight: "探索时额外揭示1张相邻板块",
				duplicateAttack: "本回合复制一枚最小攻击骰",
				defenseReroll: "本回合可重掷一枚自己的最低防御结果",
				promoteAttack: "本回合提升一枚最小攻击骰",
				promoteDefense: "本回合提升一枚最小防御骰",
				immune: "准备时免疫所有异常状态",
				stockpile: "准备时增加一个容量20的资源槽",
				speed: "准备时1行动点可以移动2格",
				climb: "准备时可以沿垂直墙面移动，阶段结束须落稳",
				archery: "本回合提升弓的最大攻击骰",
				magic: "本回合提升魔法武器的最大攻击骰",
				dryad: "使用树妖的D8",
				necro: "死灵盔甲：提升长射程装备的最小攻击骰"
			},
			objectiveConditions: {
				o0: "挖掘一个方块。",
				o1: "挖掘一个铜、铁、银或金矿方块。",
				o2: "从地下层的隧道收集蛛网。",
				o3: "已按制作菜单制作一把镐。",
				o4: "挖掘一个宝石方块。",
				o5: "用爆炸消耗品挖掘至少一个方块。",
				o6: "挖掘一个魔矿或猩红矿方块。",
				o7: "已挖空一个板块上的全部实心方块。",
				o8: "已挖通一条宽两格、从地表直达地狱底部的竖井。",
				o9: "已挖掘至少8个狱石方块。",
				o10: "砍伐一棵树。",
				o11: "已建造工作台房。",
				o12: "已建造铁砧／熔炉房。",
				o13: "已按制作菜单制作一把斧。",
				o14: "有一座房屋完全位于地表以下。",
				o15: "已建造织布机房或炼药瓶房。",
				o16: "已建造床房或烹饪锅房。",
				o17: "在三个生态区建有房屋，或在同一生态区建有四座房屋。",
				o18: "已建造地狱熔炉房。",
				o19: "已建造全部七种房屋。",
				o20: "击败一个敌人。",
				o21: "已制作木盔甲。",
				o22: "已按制作菜单制作一把剑。",
				o23: "已度过一个夜晚。",
				o24: "已击败史莱姆王。",
				o25: "有角色在其他装备槽中装备消耗魔力的装备。",
				o26: "已击败蜂王或克苏鲁之眼。",
				o27: "在同一个角色阶段击败四种不同的普通敌人。",
				o28: "已击败克苏鲁之脑或世界吞噬怪。",
				o29: "已击败地狱中的巫毒恶魔并获得向导巫毒娃娃。",
				o30: "探索两个生态板块。",
				o31: "在森林以外的生态区打开一个宝箱。",
				o32: "在地下层或更深处打开一个宝箱。",
				o33: "已有两位向导以外的居民入住。",
				o34: "已探索三个邪恶生态区的板块。",
				o35: "已探索海洋板块。",
				o36: "已发现丛林下层洞穴中的蜂巢。",
				o37: "已探索地狱板块。",
				o38: "已在全部五种地表生态区探索板块。",
				o39: "已放置五座传送晶塔。",
				o40: "已收集生命水晶。",
				o41: "下落至少8格且未死亡。",
				o42: "已在地狱打开三个宝箱。",
				o43: "在同一个角色阶段从地狱到达地表，且未使用晶塔。",
				o44: "有两名角色穿着金盔甲。",
				o45: "有三座房屋上下堆叠。",
				o46: "有两名角色的六个已解锁资源槽全部装满。",
				o47: "夜晚时全部角色都在床房内，可以共用一座房屋。",
				o48: "有角色在其他装备槽中装备悠悠球。",
				o49: "在同一个角色阶段仅使用法杖击败四个普通敌人。",
				o50: "全部角色都有已召唤的随从。",
				o51: "击败一个首领，且整个战斗过程中全队仅穿铜盔甲、木盔甲或不穿盔甲。",
				o52: "已收集坠星。",
				o53: "在同一个夜晚，地表生成至少六个普通敌人。",
				o54: "在同一个角色阶段花费至少50金币。",
				o55: "在同一个角色阶段从地表到达地狱，且未使用晶塔。",
				o9Small: "已挖掘至少6个狱石方块。",
				o27Small: "在同一个角色阶段击败三种不同的普通敌人。",
				o39Small: "已放置四座传送晶塔。",
				o42Small: "已在地狱打开两个宝箱。",
				o44Small: "有一名角色穿着金盔甲。",
				o46Small: "有一名角色的六个已解锁资源槽全部装满。",
				o49Small: "在同一个角色阶段仅使用法杖击败两个普通敌人。",
				o53Small: "在同一个夜晚，地表生成至少四个普通敌人。",
				o54Small: "在同一个角色阶段花费至少40金币。"
			},
			objectiveRewards: {
				o0: "每人获得1金币。",
				o1: "全队分配2个刚挖出的同类矿石。",
				o2: "每人获得1铁。",
				o3: "全队分配2个已制作镐所用的同类矿石。",
				o4: "每人随机获得1张二类消耗品。",
				o5: "全队分配6金币，或降低1威胁。",
				o6: "全队分配2个刚挖出的邪恶矿石。",
				o7: "每人随机获得1张三类消耗品。",
				o8: "每人从手牌、牌库或弃牌堆移除1张行动牌。",
				o9: "完成此目标链。",
				o10: "每人获得1金币。",
				o11: "每人获得1个平台。",
				o12: "每人从向导处免费获得1张《重振精神》行动牌。",
				o13: "全队分配4金币。",
				o14: "每人随机获得1张二类消耗品。",
				o15: "全队分配6金币，或降低1威胁。",
				o16: "全队分配4生命。",
				o17: "每人随机获得1张三类消耗品。",
				o18: "全队分配2狱石。",
				o19: "完成此目标链。",
				o20: "每人获得1金币。",
				o21: "每人选择获得1木材或3金币。",
				o22: "全队分配4金币。",
				o23: "每人从手牌、牌库或弃牌堆移除1张行动牌；全队分配1晶状体。",
				o24: "每人获得1张二级战利品行动牌。",
				o25: "每人随机获得2张二类消耗品。",
				o26: "每人获得1张三级战利品行动牌。",
				o27: "每人随机获得1张三类消耗品。",
				o28: "每人获得1张四级战利品行动牌。",
				o29: "完成此目标链。",
				o30: "每人获得1金币。",
				o31: "每人从向导处免费获得1张《深入探索》行动牌。",
				o32: "每人选择获得1绳索或2平台；全队分配1瓶回忆药水。",
				o33: "每人随机获得1张二类消耗品。",
				o34: "每人从手牌、牌库或弃牌堆移除1张行动牌。",
				o35: "每人从向导处免费获得1张《深入探索》行动牌。",
				o36: "全队分配6金币。",
				o37: "每人随机获得1张三类消耗品。",
				o38: "每人从手牌、牌库或弃牌堆移除1张行动牌。",
				o39: "完成此目标链。",
				o40: "每人随机获得2张二类消耗品。",
				o41: "全队分配6金币，或降低1威胁。",
				o42: "每人随机获得1张三类消耗品。",
				o43: "完成此目标链。",
				o44: "每人随机获得2张二类消耗品。",
				o45: "全队分配6金币，或降低1威胁。",
				o46: "每人随机获得1张三类消耗品。",
				o47: "完成此目标链。",
				o48: "本阶段每人购买一张行动牌时减免5金币；全队分配2蛛网。",
				o49: "每人选择获得1瓶魔能药水或魔力药水。",
				o50: "每人随机获得1张三类消耗品。",
				o51: "完成此目标链。",
				o52: "每人从手牌、牌库或弃牌堆移除1张行动牌。",
				o53: "每人从向导处免费获得1张《深入探索》行动牌。",
				o54: "每人随机获得1张三类消耗品。",
				o55: "完成此目标链。",
				o0Small: "每人获得2金币。",
				o2Small: "每人获得2铁。",
				o4Small: "每人随机获得2张二类消耗品。",
				o10Small: "每人获得2金币。",
				o11Small: "每人获得2个平台。",
				o14Small: "每人随机获得2张二类消耗品。",
				o20Small: "每人获得2金币。",
				o21Small: "每人选择获得2木材或4金币。",
				o30Small: "每人获得2金币。",
				o32Small: "每人选择获得2绳索或3平台；全队分配1瓶回忆药水。",
				o33Small: "每人随机获得2张二类消耗品。"
			},
			events: {
				start: "冒险开始",
				threat: "威胁变化 {{n}}",
				debuff: "{{name}} 获得 {{item}}",
				death: "{{name}} 倒下了",
				damage: "{{name}} 失去 {{n}} 生命",
				fall: "{{name}} 下落 {{n}} 格",
				spawn: "{{item}} 出现",
				discover: "发现 {{item}}",
				gain: "{{name}} 获得 {{item}}",
				fight: "{{name}} 对 {{item}} 造成 {{n}} 伤害",
				defeat: "{{name}} 击败 {{item}}",
				transform: "{{item}} 改变形态",
				objective: "完成目标：{{item}}",
				draw: "{{name}} 抽取 {{n}} 张行动牌",
				round: "第 {{n}} 轮开始",
				escape: "{{item}} 离开了世界",
				boss: "{{item}} 出现",
				resource: "{{name}} 获得 {{n}} {{item}}",
				play: "{{name}} 使用 {{item}}",
				move: "{{name}} 移动",
				chop: "{{name}} 砍伐树木",
				dig: "{{name}} 挖掘方块",
				craft: "{{name}} 建造 {{item}}",
				npc: "{{item}} 入住了",
				use: "{{name}} 使用 {{item}}",
				roll: "{{name}} 投掷骰子"
			},
			toolYield: "产量 {{n}} 倍",
			cancel: "取消",
			buildMenu: "制作",
			market: "居民与交易",
			pack: "背包",
			yourTurn: "可自由行动",
			viewing: "正在查看 {{name}}",
			readySlot: "准备槽",
			emptyEquipment: "空装备槽",
			noChoices: "此时没有可用行动。",
			collectHealth: "提高生命上限并完全恢复",
			collectMana: "提高魔力上限并完全恢复",
			collectCoins: "获得10金币",
			selectLocation: "选择地图上的落点",
			selectTarget: "选择地图上的目标",
			inspect: "查看",
			usePoints: "支付 {{n}} 点",
			stockpileSlot: "储备槽",
			status: "状态",
			rewardAvailable: "奖励待选择",
			zoom: "缩放",
			chooseEffect: "选择效果",
			threatStep: "威胁增量 {{n}}",
			noArmor: "未穿护甲",
			defenseBase: "防御 D4",
			objectChain: {
				dig: "挖掘",
				build: "建造",
				fight: "战斗",
				explore: "探索"
			},
			tokenNames: {
				"#": "土块",
				s: "石头",
				cu: "铜矿",
				fe: "铁矿",
				ag: "银矿",
				au: "金矿",
				g: "宝石矿",
				de: "魔矿",
				cr: "猩红矿",
				es: "黑檀石",
				cs: "猩红石",
				hs: "硬化沙",
				ice: "冰块",
				he: "狱石",
				empty: "空格",
				S: "敌人生成点",
				C1: "宝箱",
				C2: "宝箱",
				T1: "树木",
				T2: "树木",
				T3: "树木",
				W: "蛛网",
				L: "熔岩",
				Altar: "祭坛",
				Orb4: "暗影珠",
				Heart4: "猩红之心",
				Larva: "幼虫"
			},
			consumableEffects: {
				c0: "恢复1生命。",
				c1: "恢复1魔力。",
				c2: "以D6进行一次短／中射程攻击，穿刺1。",
				c3: "以D4进行一次短／中射程攻击，穿刺2。",
				c4: "获得2行动点。",
				c5: "本回合，同一板块上的敌人各降级一枚最大的防御骰。",
				c6: "传送至森林地表或床房的空格，或获得5金币。",
				c7: "揭示生成点时可取消此次生成；或本回合普通敌人忽略你。",
				c8: "获得2防御点。",
				c9: "获得2挖掘点。",
				c10: "本回合使用弓时升级一枚最大的攻击骰，或获得5金币。",
				c11: "恢复2生命。",
				c12: "本回合使用消耗魔力的装备时升级一枚最大的攻击骰，或获得5金币。",
				c13: "抽2张行动牌。",
				c14: "选择短／中射程内的中心格，对周围九格进行2D6攻击，并分别以3坚硬挖掘点与3砍伐点处理每格。爆炸也会伤及角色。",
				c15: "选择短／中射程内的中心格，对周围九格进行2D8攻击，并分别以4坚硬挖掘点与4砍伐点处理每格。爆炸也会伤及角色。",
				c16: "恢复3魔力。",
				c17: "清除着火，或获得8金币。",
				c20: "在地狱中位于或邻接熔岩时使用，召唤血肉墙。",
				c21: "选择短／中射程内的中心格，对周围九格进行D4加D6攻击，并分别以2挖掘点与2砍伐点处理每格。爆炸也会伤及角色。"
			},
			bossEffects: {
				kingSlime0: "在所有活跃板块的空置生成点生成敌人。",
				kingSlime1: "首领防御增加D4。",
				kingSlime2: "首领移动力增加1。",
				kingSlime3: "首领攻击增加D6。",
				eye0: "行为A时，对每名目标额外攻击一次。",
				eye1: "行为A时，对每名目标额外攻击一次。",
				eye2: "首领移动力增加1。",
				eye3: "首领升级一枚最大的攻击骰。",
				queenBee0: "丛林上层及下层洞穴中的角色中毒。",
				queenBee1: "丛林上层及下层洞穴中的角色中毒。",
				queenBee2: "首领攻击增加D6。",
				queenBee3: "首领攻击增加D6。",
				wall0: "增加一次威胁增量，或令地狱中的所有角色着火。",
				wall1: "地狱中的所有角色恢复1生命。",
				wall2: "首领移动力增加1。",
				wall3: "首领移动力增加1。"
			},
			armorEffects: {
				r15: "免疫着火。",
				r16: "使用长射程装备时，升级一枚最小的攻击骰。",
				r19: "每回合可重掷一枚自己的攻击骰。",
				r20: "已召唤的随从增加1攻击点。",
				r24: "角色阶段开始获得2挖掘点。",
				r25: "免疫冰冻。"
			},
			gainChop: "支付 {{cost}} 行动点，获得 {{n}} 砍伐点",
			gainDig: "支付 {{cost}} 行动点，获得 {{n}} 挖掘点",
			gainHardyDig: "支付 {{cost}} 行动点，获得 {{n}} 坚硬挖掘点",
			summonEffect: "支付 {{cost}} 魔力召唤随从，每回合获得 {{n}} 攻击点",
			hookEffect: "支付2行动点，向上移动 {{n}} 格并向左或右移动1格",
			lootLevel: "{{n}}级行动牌奖励",
			resourceReward: "{{n}} {{item}}",
			brainAlly: "克苏鲁之脑盟友 · 防御 {{dice}}",
			againConfirm: "再次点击开始新冒险",
			diceResult: "骰子结果",
			mapInfo: "地图信息",
			bossDetails: "首领状态",
			debuffs: "异常状态",
			emptyDebuffs: "无异常状态",
			healthMana: "生命 {{hp}} / {{maxHp}} · 魔力 {{mana}} / {{maxMana}}",
			craftTabs: {
				tools: "工具",
				weapons: "武器与饰品",
				armor: "盔甲",
				houses: "建筑"
			},
			craftUnavailable: "尚未满足制作条件",
			nightsEdgeRecipe: "世界中有祭坛时，可消耗已有的魔光剑、血腥屠刀和火山中的任意两把剑，制作永夜刃。"
		},
		en: {
			name: "Terraria: The Board Game",
			movement: "Movement",
			flying: "Flying",
			burrowing: "Burrowing",
			bossRules: {
				kingSlime: "Defense: 2D6. A: if no character is in the same Surface biome, teleport to the revealed spawn nearest a character; move 1 and attack at short range with 2D6+D4. B: move 2 and attack at short range with 2D6; other Slimes gain 1 movement. May pass through houses.",
				eye: "Defense: D6+D8 in Form 1, D8 in Form 2. A: fly 2, attack at short range with 3D6; each blue ally adds another attack. B: fly 3, attack at short range with 2D6+D8; flee at the end of that Enemy Phase if it is daytime. Movement passes through blocks and houses.",
				brain: "In Form 1, choose an ally to attack using its 2D6 or D6+D8 defense; one successful attack removes exactly one ally. Removing all allies reveals Form 2, with 2D8 defense. A: fly 3 and attack at short range with 3D6. B: fly 2 and attack at short range with 2D6+D8. May pass through blocks and houses.",
				eater: "Defense: 2D8. On activation, choose any character in Corruption and roll D6 to appear in the corresponding column of row 3 or 5 of their tile; the position must change. A: short/medium attack with 3D6. B: short attack with 2D6+D8. Movement and LOS ignore blocks, houses and tokens. Flees if no character remains in Corruption.",
				queenBee: "Defense: D6+D4. Both behaviors fly 2, through blocks and houses. A: short attack with D6+D8. B: long attack with D6; a hit inflicts poison. At the start of the Enemy Phase, add an extra ally if any occupied square is outside Jungle.",
				wall: "Form 1 targets the two eyes separately, each with D8+D12 defense. Form 2 targets only the mouth, with 2D12 defense. A moves 1 right; B moves 2 right. Both attack at short range with 2D20, and each intact eye makes a separate long attack with 2D12. Passes through blocks and houses; characters cannot cross it. Leaving the Underworld kills a character; it leaving the revealed Underworld kills everyone. Defeating it wins immediately."
			},
			desc: "Explore, mine, craft and face the bosses of Terraria together.",
			rules: "Goal:\nCooperate with 1–4 characters. Complete one ten-level objective chain in Standard, two in Tough or three in Heroic. Journey ends after one six-level chain. Defeating the Wall of Flesh also wins immediately. Threat reaching 10 loses immediately.\nSetup:\nStart with 5 health, 3 mana and eight action cards, a Copper Axe, Copper Pickaxe and Copper Shortsword. There are 4–6 unlocked resource slots depending on player count; each holds up to 5 of one resource. Coins are capped at 25. Journey grants iron equipment and two ropes, prevents fall damage and removes death threat.\nRound:\nEach round has Character, Enemy and Environment phases. First select equipment and armor, then resolve debuffs and draw to your armor's draw value. Characters act in any interleaved order. OR effects select one branch; effects joined by + can be used at different times. Defense points may be saved for the Enemy phase. Unused AP, Chop and Dig points expire at Character end. Attack and defense points and round-long combat effects remain available until the next round. Before advancing, resolve all available discoveries and objectives, then check boss spawning conditions.\nMovement and discovery:\nSpend 1AP to move to an adjacent empty square, including diagonally. You cannot pass between touching block corners. You may pass through characters or enemies only when you have enough AP to end in an unoccupied square. Unsupported characters fall immediately. Falls longer than 1 square lose health equal to distance minus the sum of defense dice. Cobwebs, lava and Journey prevent fall damage. Rope can hold you in place, but cannot stop an existing fall. Moving along rope costs 1AP for up to 2 squares, or 3 with a Loom House.\nDiscover all vacant tile spaces orthogonally adjacent to the tile you occupy for free. Uncovered skulls on new tiles spawn from their biome and layer's finite enemy supply. Surface spawns use the day or night tray.\nGathering and building:\nConvert AP into Chop or Dig points using equipped tools, saving and spending these points separately. Pay each block's printed cost; hardy blocks require Hardy Dig. Chopping a tree costs its value and yields that much wood before yield bonuses. Moving through cobweb squares collects cobweb. You may enter a freshly dug square for free, and digging beneath yourself can cause a fall. Trees regrow at sunrise.\nSpend 1AP at an uncovered adjacent chest. Draw the indicated number of chest cards and select one reward for that layer; return all drawn cards to the bottom in their original order. Loot action rewards draw two cards, keep one and put the other at the bottom. Supplies are finite. New action cards enter discard. Choose how to store, replace, donate or discard overflowing resources.\nCrafting is free after paying its recipe and meeting existing house requirements, with no distance restriction. Only the top equipment in each of four slots is active. New crafted equipment equips immediately; keep old items for future rounds. Houses overlap your square or an adjacent square and cannot cover blocks or enemies; they may float. Covering a skull with a house, rope or pylon advances threat once. Craft platforms for 1 wood and ropes for 1 cobweb. Platforms occupy a square's bottom edge; rope extends downward until a block or house.\nDonate any quantity of one resource, coins, platforms or ropes, or one equipment, armor or consumable to any other character for 1AP. Unlock the fifth inventory slot for 15 coins and the sixth for 25.\nCombat:\nPay an equipped weapon's AP or mana cost. Short range is eight-adjacent squares; character weapons lacking short range cannot hit adjacent targets. Measure medium and long range along a ray to the target square's near edge. Long range discards one attack die past 3 squares and two past 5; past 7 is out of range. Blocks and touching corners block sight. Houses allow sight out but prevent sight in. Sightless weapons ignore LOS.\nRoll attack and defense dice. Each attack result reaching the highest defense result deals 1 damage. Attack and defense points each boost only one die and may exceed its face value. Piercing targets must form an adjacent connected line; only the nearest must be in range. They share the attack roll but defend and retaliate separately. Surviving enemies retaliate if range and sight permit, using their highest defense result as one attack result. Prevention effects cancel retaliation.\nEnemies:\nActivate non-boss enemies in character tiles and orthogonally adjacent tiles. The team chooses activation order, tied targets and destinations, and attack order. Move toward the closest character, unless already adjacent. Use movement value with LOS or only one step without LOS. Then attack all characters in range and sight. Flyers do not fall, worms move through blocks and ordinary enemies cannot enter houses.\nEnvironment and debuffs:\nDiscard all in-play action cards except the readied card. Advance time, then resolve threat and spawn icons. Sunrise regrows trees, removes surface night enemies and fallen stars, replenishes mana and resets house tokens. The second sunrise triggers King Slime.\nDebuffs last for two Character starts. Frozen reduces draw by 1; On Fire loses 2 health; Poisoned discards the readied card and prevents readying this round. Equip immunity before resolving debuffs. Receiving the same debuff refreshes its duration to two starts.\nDeath and bosses:\nDeath clears debuffs, halves coins rounded down, returns consumables and minion, and shuffles all action cards into the deck. Keep resources and equipment. Remove one tombstone and advance threat by its current increment; removing the last tombstone permanently makes that increment 2. With no tombstones, death adds 2 threat. At the next Character start, respawn at full health and mana in an empty Forest Surface square or an unoccupied Bed House square.\nBoss triggers are checked at Character end. A triggered boss spawns at the next Enemy start if no boss is present, making the threat increment 2. Add no ally on its spawn phase; later Enemy starts place allies and resolve specials. Alternate A/B behavior at Enemy end. A form change discards excess damage and prevents further attacks on that boss this Character phase. Distribute printed rewards after defeating it. Permanent threat from exhausted tombstones never resets.\nReadying and residents:\nOnly completely unused hand cards can be readied. Return the old readied card to hand. Only explicit ready effects work while in that slot; retrieve it any time. New action cards enter discard, and fetching from the draw pile does not shuffle. Spawn residents when conditions and available houses permit; the Guide is always present and needs no house. Residents sell actions and consumables, heal, scrap actions or supply a shared D8.\nOptions:\nChoose Corruption or Crimson, starting threat 0–3, alternate objectives and Objective Focus. A focused objective flips after the first incomplete phase; after the second, remove it and advance threat by the current increment. Alternate objectives are randomly selected at their corresponding levels. This implementation uses the 2026 reference version and excludes holiday promos.",
			invalidAction: "That choice is no longer available. Choose again.",
			day: "Day {{n}}",
			round: "Round {{n}}",
			threat: "Threat {{n}} / 10",
			graves: "{{n}} tombstones",
			phase: {
				prepare: "Choose equipment",
				character: "Character phase",
				enemy: "Enemy phase",
				environment: "Environment phase",
				done: "Adventure ended"
			},
			time: {
				day: "Day",
				night: "Night",
				sunrise: "Sunrise"
			},
			group: {
				cards: "Actions",
				move: "Move & discover",
				gather: "Gather",
				fight: "Fight",
				build: "Build",
				progress: "Progress",
				other: "More"
			},
			health: "Health",
			mana: "Mana",
			coins: "Coins",
			ap: "AP",
			attack: "Attack",
			defense: "Defense",
			dig: "Dig",
			hardyDig: "Hardy Dig",
			chop: "Chop",
			hand: "Hand",
			ready: "Readied",
			inventory: "Inventory",
			equipment: "Equipment",
			armor: "Armor",
			consumables: "Consumables",
			objectives: "Objectives",
			npcs: "Residents",
			journal: "Journal",
			close: "Close",
			back: "Back",
			detail: "Details",
			world: "World",
			fit: "Overview",
			focusMe: "Find character",
			choose: "Choose",
			wait: "Resolving",
			waitOther: "Waiting for {{name}}",
			everyone: "The team",
			unknown: "Unexplored",
			discard: "Discard",
			deck: "Draw pile",
			spent: "Used",
			none: "None",
			end: "End Character phase",
			resume: "Resume actions",
			confirmed: "Ready",
			cost: "Cost",
			recipe: "Recipe",
			requires: "Requires",
			range: "Range",
			short: "Short",
			medium: "Medium",
			long: "Long",
			sightless: "Sightless",
			prevent: "Prevent retaliation",
			pierce: "Piercing {{n}}",
			draw: "Draw {{n}}",
			die: "D{{n}}",
			use: "Use",
			or: "OR",
			plus: "+",
			full: "Full",
			slot: "Slot {{n}}",
			count: "{{n}}",
			at: "At {{x}}, {{y}}",
			selectCard: "Choose an effect",
			played: "Played",
			dead: "Awaiting respawn",
			endReady: "Finished",
			resultWin: "A world worth saving",
			resultLoss: "Darkness claimed the world",
			victory: "Adventure won",
			defeat: "Adventure lost",
			resultDetail: "Day {{day}} · {{n}} objectives · {{bosses}} bosses",
			review: "Explore the final world",
			showResult: "Show result",
			again: "Play again",
			lobby: "Back to lobby",
			waitingHost: "Waiting for the host",
			leaveConfirm: "Click again to leave",
			hintCount: "{{n}} hints",
			autopilot: "{{n}}% autopilot",
			objectLevel: "Level {{n}}",
			bossForm: "Form {{n}}",
			bossBehavior: "Behavior {{n}}",
			bossBuff: "Ally effect {{n}}",
			combatAttack: "Attack dice",
			combatDefense: "Defense dice",
			reward: "Reward",
			effect: "Effect",
			noCards: "No cards in hand",
			capacity: "Up to 5 of one resource per slot",
			face: "Character",
			search: "Find an item",
			difficulty: "Difficulty",
			evil: "Evil biome",
			initialThreat: "Starting threat",
			alternatives: "Alternate objectives",
			focusRule: "Objective Focus",
			journey: "Journey",
			standard: "Standard",
			tough: "Tough",
			heroic: "Heroic",
			corruption: "Corruption",
			crimson: "Crimson",
			forest: "Forest",
			desert: "Desert",
			snow: "Snow",
			jungle: "Jungle",
			beach: "Ocean",
			layer: {
				surface: "Surface",
				underground: "Underground",
				upperCavern: "Upper Cavern",
				lowerCavern: "Lower Cavern",
				underworld: "Underworld"
			},
			prompts: {
				inventory: "Store the resources",
				loot: "Choose loot",
				share: "Distribute rewards",
				reward: "Choose a reward",
				scrap: "Choose a card to scrap",
				assist: "Choose who draws",
				discard: "Choose a card to discard",
				keep: "Choose a card to keep",
				fetch: "Choose a card to fetch",
				teleport: "Choose a destination",
				copy: "Choose an effect to copy",
				attackTarget: "Choose attack targets",
				explosive: "Choose the blast center",
				discover: "Discover adjacent tiles",
				objectives: "Complete available objectives",
				enemyTarget: "Choose the enemy target",
				enemyMove: "Choose the enemy destination",
				enemyAttackOrder: "Choose attack order",
				bossBuff: "Place a boss ally",
				displace: "Displace covered pieces",
				bossTeleport: "Choose boss teleport",
				bossMove: "Choose boss destination",
				consumable: "Choose consumable effect",
				enter: "Enter the newly dug square?",
				chest: "Choose a chest reward",
				scrapEquipment: "Choose two weapons to scrap",
				reclaim: "Choose a token to reclaim",
				platform: "Place a free platform",
				donate: "Choose a donation",
				spawn: "Choose a spawn",
				wallBuff: "Choose Wall of Flesh effect",
				preventSpawn: "Prevent this spawn with an Invisibility Potion?",
				retaliation: "Choose the retaliation order"
			},
			operations: {
				pierceOrigin: "Choose piercing origin",
				skip: "Decline",
				prepared: "Confirm equipment",
				equip: "Equip {{item}}",
				armor: "Wear {{item}}",
				respawn: "Respawn here",
				end: "Finish actions",
				resume: "Resume actions",
				store: "Store {{n}} {{item}} in {{target}}",
				storeStockpile: "Stockpile {{n}} {{item}}",
				discardResource: "Discard {{n}} {{item}}",
				overflowDonate: "Give {{n}} {{item}} to {{target}}",
				takeItem: "Take {{item}}",
				lootPick: "Take {{item}}",
				lootDecline: "Decline loot",
				shareTake: "Give {{n}} {{item}} to {{target}}",
				shareCoins: "Share {{n}} coins",
				reduceThreat: "Reduce threat by {{n}}",
				loot: "Level {{n}} loot",
				gain: "Take {{item}}",
				shareResource: "Share {{n}} {{item}}",
				coins: "Gain {{n}} coins",
				resource: "Gain {{n}} {{item}}",
				ropeAward: "Gain {{n}} ropes",
				platformAward: "Gain {{n}} platforms",
				scrapCard: "Scrap {{item}}",
				card: "Use {{item}}: {{effect}}",
				ready: "Ready {{item}}",
				unready: "Retrieve readied card",
				assistDraw: "{{item}} draws {{n}} cards",
				assistSplit: "{{item}} and {{target}} draw 1 each",
				discardDraw: "Discard {{item}}, draw 1",
				discardCard: "Discard {{item}}",
				keepDraw: "Keep {{item}}",
				fetchCard: "Fetch {{item}}",
				springScrap: "Scrap {{item}} and this card",
				copyEffect: "Copy {{item}}: {{effect}}",
				markEnemy: "Apply the effect to {{item}}",
				discover: "Discover adjacent tiles",
				reveal: "Discover this tile",
				move: "Move here ({{n}}AP)",
				ropeMove: "Climb here",
				hook: "Grapple here",
				teleport: "Move here",
				travel: "Travel to this pylon",
				tool: "Use {{item}}",
				chop: "Chop ({{n}}Chop)",
				dig: "Dig ({{n}}Dig)",
				chest: "Open chest",
				chestPick: "Take {{item}}",
				craft: "Craft {{item}}",
				nightsEdge: "Craft Night’s Edge",
				forgeEdge: "Scrap {{item}} and {{target}}",
				craftToken: "Craft {{item}}",
				reclaimToken: "Reclaim this {{item}}",
				house: "Build {{item}}",
				platform: "Place platform here",
				freePlatform: "Place a free platform",
				rope: "Lay rope here",
				pylon: "Place pylon (10 coins)",
				collect: "Collect {{item}}: {{effect}}",
				unlock: "Unlock the next slot",
				spawnNpc: "Spawn {{item}}",
				buyAction: "Buy {{item}} ({{n}}coins)",
				buyConsumable: "Buy a random type{{n}} consumable",
				nurse: "Full heal (10 coins)",
				goblin: "Scrap an action (15 coins)",
				bottle: "Take {{item}}",
				food: "Gain {{effect}}",
				objective: "Complete {{item}}",
				focus: "Focus on {{item}}",
				donate: "Donate",
				donateTo: "Give to {{target}}",
				donateResource: "Give {{target}} {{n}} {{item}}",
				donateCoins: "Give {{target}} {{n}} coins",
				donateTokens: "Give {{target}} {{n}} {{item}}",
				donateItem: "Give {{item}} to {{target}}",
				weapon: "Attack with {{item}}",
				weaponTarget: "Attack {{target}}",
				finisherTarget: "Finish {{target}}",
				minion: "Summon {{item}}",
				summonEye: "Spend 1 lens to summon the Eye",
				consumable: "Use {{item}}",
				useConsumable: "Use {{item}}: {{effect}}",
				throwTarget: "Throw {{item}} at {{target}}",
				explode: "Throw {{item}} here",
				finishTargets: "Confirm targets",
				pierceTarget: "Pierce {{item}}",
				dropDie: "Discard {{item}}",
				modifyDie: "Apply {{effect}}",
				roll: "Roll dice",
				boost: "Boost the chosen die by {{n}}",
				reroll: "Reroll the chosen die",
				resolveBattle: "Resolve combat",
				spawnPick: "Spawn {{item}}",
				activate: "Activate {{item}}",
				enemyTarget: "Move {{item}} toward {{target}}",
				enemyMove: "Move {{item}} here",
				enemyHit: "Attack {{target}}",
				bossBuff: "Add ally: {{effect}}",
				wallThreat: "Advance threat once",
				wallFire: "Set all Underworld characters on fire",
				bossTeleport: "Teleport the boss here",
				bossTarget: "Move toward {{target}}",
				bossMove: "Move the boss here",
				wormTeleport: "Choose {{target}}’s tile",
				displaceWho: "Displace {{item}} first",
				displaceTo: "Displace {{item}} here",
				copyCard: "Copy the effects of {{item}}",
				readyAP: "Readied card: gain {{n}} AP",
				drop: "Release the rope and fall",
				giftCraft: "Immediately craft {{item}} with donated resources",
				preventSpawn: "Use an Invisibility Potion to prevent this spawn",
				spawnAllowed: "Allow the spawn",
				retaliate: "Resolve {{item}}’s retaliation first"
			},
			items: {
				e0: "Copper Axe",
				e1: "Iron Axe",
				e2: "Silver Axe",
				e3: "Gold Axe",
				e4: "Blood Lust Cluster",
				e5: "War Axe of the Night",
				e6: "Molten Hamaxe",
				e7: "Copper Pickaxe",
				e8: "Iron Pickaxe",
				e9: "Silver Pickaxe",
				e10: "Gold Pickaxe",
				e11: "Nightmare Pickaxe",
				e12: "Deathbringer Pickaxe",
				e13: "Molten Pickaxe",
				e14: "Copper Shortsword",
				e15: "Iron Shortsword",
				e16: "Silver Broadsword",
				e17: "Gold Broadsword",
				e18: "Light's Bane",
				e19: "Blood Butcherer",
				e20: "Volcano",
				e21: "Wooden Bow",
				e22: "Iron Bow",
				e23: "Silver Bow",
				e24: "Gold Bow",
				e25: "Demon Bow",
				e26: "Tendon Bow",
				e27: "Molten Fury",
				e28: "Wooden Yoyo",
				e29: "Malaise",
				e30: "Artery",
				e31: "Amethyst Staff",
				e32: "Ruby Staff",
				e33: "Flinx Staff",
				e34: "Imp Staff",
				e35: "Grappling Hook",
				e36: "Night's Edge",
				e37: "Bee Keeper",
				e38: "Bee's Knees",
				e39: "Bee Gun",
				e41: "Dark Lance",
				e42: "Spear",
				e43: "Wooden Boomerang",
				e44: "Enchanted Boomerang",
				e45: "Blowpipe",
				e46: "Ice Blade",
				e48: "Amazon",
				e49: "Cascade",
				e50: "Hellwing Bow",
				e51: "Phoenix Blaster",
				e52: "Ruby Hook",
				e53: "Wand of Sparking",
				e54: "Thunder Zapper",
				e55: "Crimson Rod",
				e56: "Vilethorn",
				e57: "Flamelash",
				e58: "Demon Scythe",
				e59: "Flower of Fire",
				e60: "Slime Staff",
				e61: "Hornet Staff",
				c0: "Lesser Healing Potion",
				c1: "Lesser Mana Potion",
				c2: "Throwing Knife",
				c3: "Shuriken",
				c4: "Swiftness Potion",
				c5: "Inferno Potion",
				c6: "Recall Potion",
				c7: "Invisibility Potion",
				c8: "Ironskin Potion",
				c9: "Mining Potion",
				c10: "Archery Potion",
				c11: "Healing Potion",
				c12: "Magic Power Potion",
				c13: "Greater Luck Potion",
				c14: "Bomb",
				c15: "Dynamite",
				c16: "Mana Potion",
				c17: "Water Bucket",
				c20: "Guide Voodoo Doll",
				c21: "Beenade",
				r8: "Wood Armor",
				r9: "Copper Armor",
				r10: "Iron Armor",
				r11: "Silver Armor",
				r12: "Gold Armor",
				r13: "Shadow Armor",
				r14: "Crimson Armor",
				r15: "Molten Armor",
				r16: "Necro Armor",
				r17: "Wizard Set",
				r19: "Ninja Armor",
				r20: "Bee Armor",
				r21: "Shadewood Armor",
				r22: "Ebonwood Armor",
				r23: "Jungle Armor",
				r24: "Mining Armor",
				r25: "Snow Armor",
				a0: "Second Wind",
				a1: "Explore More",
				a2: "Somersault",
				a3: "Recuperate",
				a4: "Doubletap",
				a5: "Escape Route",
				a6: "Aglet",
				a7: "Juiced Up",
				a8: "Cha-Ching!",
				a9: "Industrious",
				a10: "Fingers Crossed",
				a11: "Helping Hand",
				a12: "Double Measure",
				a13: "Rallying Cry",
				a14: "Magic Mirror",
				a15: "Sidestep",
				a16: "Seize the Opportunity",
				a17: "Accessorize",
				a18: "Shakedown",
				a19: "Thick-Skinned",
				a20: "Band of Starpower",
				a21: "Favourite Move",
				a22: "De-escalate",
				a23: "Band of Regeneration",
				a24: "Enraged",
				a25: "Shackle",
				a26: "Radar",
				a27: "Nope!",
				a28: "Take That",
				a29: "Double Trouble",
				a30: "Lifeform Analyzer",
				a31: "Shoe Spikes",
				a32: "Reclaim",
				a33: "Stockpile",
				a34: "Hermes Boots",
				a35: "Bring It On",
				a36: "Intimidate",
				a37: "Geared Up",
				a38: "Retrieve",
				a39: "Finisher",
				a40: "Take Out the Trash",
				a41: "Weak Spot",
				a42: "Get Wrecked!",
				a43: "Punchbag",
				a44: "Foresight",
				a45: "Get 'Em!",
				a46: "Bandage Up",
				a47: "Spring Clean",
				a48: "Explore Even More",
				a49: "Duck and Weave",
				a50: "Quick Thinking",
				a51: "Clobber",
				a52: "Hunker Down",
				a53: "Swap Shop",
				a54: "Copycat",
				a55: "Get Rid",
				a56: "Backup Plan",
				a57: "Productive",
				a58: "Explore Way More",
				s0: "Charge",
				s1: "Assist",
				s2: "Dodge",
				s3: "Rest",
				s4: "Explore",
				s5: "Explore More",
				o0: "Scraping the Surface",
				o1: "Ooo, Shiny!",
				o2: "World Wide Web",
				o3: "Getting Picky",
				o4: "Under Pressure",
				o5: "Having a Blast",
				o6: "Evil, Or...?",
				o7: "A Blank Slate",
				o8: "Bulldozer",
				o9: "Hot Stuff",
				o10: "Timber!",
				o11: "Benched",
				o12: "Heavy Metal",
				o13: "Chop It Like It's Hot",
				o14: "Subterranean Homestead Blues",
				o15: "Getting Crafty",
				o16: "Home Comforts",
				o17: "Property Developer",
				o18: "Forging Ahead",
				o19: "Quite the Portfolio",
				o20: "That Was Close",
				o21: "Matching Attire",
				o22: "Looking Sharp",
				o23: "You Can Do It!",
				o24: "Slippery Shinobi",
				o25: "Never Mana Give You Up",
				o26: "Sting Operation/Eye on You",
				o27: "Diverse Dispatch",
				o28: "Mastermind/Worm Fodder",
				o29: "All Dolled Up",
				o30: "Off We Go!",
				o31: "Feeling Chesty",
				o32: "I Am Loot!",
				o33: "Real Estate Agent",
				o34: "A Lovely Neighborhood",
				o35: "Land's End",
				o36: "Where's My Honey?",
				o37: "It's Getting Hot In Here",
				o38: "Marathon Medalist",
				o39: "Rapid Transit Network",
				o40: "Heart Breaker",
				o41: "Lucky Break",
				o42: "Heated Heist",
				o43: "Going Up!",
				o44: "Fashion Statement",
				o45: "High Rise",
				o46: "Pack Horse",
				o47: "Slumber Party",
				o48: "Throwing Lines",
				o49: "You're a Wizard Lady!",
				o50: "You and What Army?",
				o51: "Cu Later!",
				o52: "Star Power",
				o53: "Out Past Curfew",
				o54: "In This Economy?",
				o55: "Hellavator",
				wood: "Wood",
				gel: "Gel",
				stone: "Stone",
				cobweb: "Cobweb",
				copper: "Copper",
				iron: "Iron",
				silver: "Silver",
				gold: "Gold",
				demonite: "Demonite",
				crimtane: "Crimtane",
				hellstone: "Hellstone",
				gem: "Gem",
				lens: "Lens",
				bone: "Bone",
				flinxFur: "Flinx Fur",
				workbench: "Workbench House",
				anvil: "Anvil / Furnace House",
				loom: "Loom House",
				bottle: "Placed Bottle House",
				cookingPot: "Cooking Pot House",
				bed: "Bed House",
				hellforge: "Hellforge House",
				platform: "Platform",
				rope: "Rope",
				platforms: "Platforms",
				ropes: "Ropes",
				guide: "Guide",
				merchant: "Merchant",
				nurse: "Nurse",
				goblin: "Goblin Tinkerer",
				demolitionist: "Demolitionist",
				dryad: "Dryad",
				kingSlime: "King Slime",
				eye: "Eye of Cthulhu",
				eater: "Eater of Worlds",
				brain: "Brain of Cthulhu",
				queenBee: "Queen Bee",
				wall: "Wall of Flesh",
				boss: "Boss",
				fire: "On Fire",
				frozen: "Frozen",
				poison: "Poisoned",
				Orb4: "Shadow Orb",
				Heart4: "Crimson Heart",
				Larva: "Larva",
				Altar: "Altar",
				"Green Slime": "Green Slime",
				"Blue Slime": "Blue Slime",
				"Red Slime": "Red Slime",
				"Yellow Slime": "Yellow Slime",
				"Black Slime": "Black Slime",
				"Lava Slime": "Lava Slime",
				"Demon Eye": "Demon Eye",
				Zombie: "Zombie",
				"Giant Worm": "Giant Worm",
				"Cave Bat": "Cave Bat",
				Hellbat: "Hellbat",
				Skeleton: "Skeleton",
				Salamander: "Salamander",
				Vulture: "Vulture",
				Antlion: "Antlion",
				"Sand Slime": "Sand Slime",
				"Antlion Swarmer": "Antlion Swarmer",
				"Tomb Crawler": "Tomb Crawler",
				"Fire Imp": "Fire Imp",
				Snatcher: "Snatcher",
				"Jungle Slime": "Jungle Slime",
				"Spiked Jungle Slime": "Spiked Jungle Slime",
				"Jungle Bat": "Jungle Bat",
				Hornet: "Hornet",
				"Ice Slime": "Ice Slime",
				"Frozen Zombie": "Frozen Zombie",
				"Ice Bat": "Ice Bat",
				"Snow Flinx": "Snow Flinx",
				Crimera: "Crimera",
				"Blood Crawler": "Blood Crawler",
				"Eater of Souls": "Eater of Souls",
				Devourer: "Devourer",
				"Voodoo Demon": "Voodoo Demon",
				"Life Crystal": "Life Crystal",
				"Fallen Star": "Fallen Star",
				"Angry Bones": "Angry Bones",
				"Baby Slime": "Baby Slime"
			},
			effects: {
				ap: "Gain {{n}}AP",
				attack: "Gain {{n}}Attack",
				defense: "Gain {{n}}Defense",
				health: "Heal {{n}}",
				lowHeal: "Heal {{n}} if health is 2 or less",
				mana: "Restore {{n}}mana",
				coins: "Gain {{n}}coins",
				assist: "Other characters draw {{n}} total (yourself in solo)",
				draw: "Draw {{n}}",
				drawKeep: "Draw 2, keep 1",
				drawDiscard: "Draw {{n}}, discard 1",
				discardDraw: "Discard 1, draw 1",
				freePlatforms: "Place up to 2 free platforms",
				clearOthers: "Clear other characters’ debuffs",
				fetch: "Fetch 1 from the permitted piles",
				scrap: "Scrap up to {{n}} from hand/discard",
				springScrap: "Scrap 1 hand card and this card",
				copy: "Copy an eligible action card",
				deescalate: "Reduce threat 1, lose 4 health",
				teleport: "Teleport to Forest Surface or a Bed House",
				finisher: "When all characters share a tile, attack with 3D20 then scrap this card",
				industry: "Each same-biome character gains 1 Chop and 1 Dig",
				rally: "Same-biome characters gain 2Attack and 2Defense",
				yield: "Same-biome gathering gains 1 yield",
				freeDonate: "Donations cost no AP this turn",
				doubleConsumable: "Use a single consumable twice",
				enemyAttackReroll: "Reroll one enemy’s highest attack result once this turn",
				enemyDefenseReroll: "Reroll one enemy’s highest defense result once this turn",
				shakedown: "Double non-boss loot this turn",
				duplicateDefense: "Duplicate a smallest defense die this turn",
				regenKill: "Heal 1 per non-boss defeated this turn",
				radar: "Draw {{n}}spawns, choose 1",
				enemySmallAttackDemote: "Demote one enemy’s smallest attack die this turn",
				enemySmallDefenseDemote: "Demote one enemy’s smallest defense die this turn",
				enemyLargeAttackDemote: "Demote one enemy’s largest attack die this turn",
				enemyLargeDefenseDemote: "Demote one enemy’s largest defense die this turn",
				enemyRemoveAttack: "Remove one enemy’s smallest attack die (min 1 die)",
				enemyRemoveDefense: "Remove one enemy’s smallest defense die (min 1 die)",
				punchbag: "Gain 3 coins per health lost this turn",
				foresight: "Discover an extra adjacent tile",
				duplicateAttack: "Duplicate a smallest attack die this turn",
				defenseReroll: "Reroll a lowest defense result once this turn",
				promoteAttack: "Promote a smallest attack die this turn",
				promoteDefense: "Promote a smallest defense die this turn",
				immune: "While readied: immune to all debuffs",
				stockpile: "While readied: extra 20-capacity resource slot",
				speed: "While readied: move 2 squares per AP",
				climb: "While readied: move along vertical walls; finish on a horizontal surface",
				archery: "Promote a largest bow attack die this turn",
				magic: "Promote a largest magic attack die this turn",
				dryad: "Use the shared DryadD8",
				necro: "Necro Armor: promote a smallest long-range equipment attack die"
			},
			objectiveConditions: {
				o0: "Dig one block.",
				o1: "Dig one Copper, Iron, Silver or Gold Ore block.",
				o2: "Collect Cobweb from an Underground tunnel.",
				o3: "Craft a pickaxe using the crafting menu.",
				o4: "Dig one Gem block.",
				o5: "Dig at least one block with an explosive consumable.",
				o6: "Dig one Demonite or Crimtane Ore block.",
				o7: "Remove every solid block from one biome tile.",
				o8: "Dig a two-square-wide vertical shaft from the Surface to the bottom of the Underworld.",
				o9: "Dig at least eight Hellstone blocks.",
				o10: "Chop one tree.",
				o11: "Build a Work Bench house.",
				o12: "Build an Anvil/Furnace house.",
				o13: "Craft an axe using the crafting menu.",
				o14: "Have a house entirely below the Surface.",
				o15: "Build a Loom or Bottles house.",
				o16: "Build a Bed or Cooking Pot house.",
				o17: "Have houses in three biomes, or four houses in one biome.",
				o18: "Build a Hellforge house.",
				o19: "Build all seven types of house.",
				o20: "Defeat one enemy.",
				o21: "Craft Wood Armor.",
				o22: "Craft a sword using the crafting menu.",
				o23: "Survive one night.",
				o24: "Defeat King Slime.",
				o25: "Have a character equip mana-consuming equipment in their Other slot.",
				o26: "Defeat Queen Bee or the Eye of Cthulhu.",
				o27: "Defeat four different non-boss enemy types in one Character Phase.",
				o28: "Defeat the Brain of Cthulhu or Eater of Worlds.",
				o29: "Defeat a Voodoo Demon in the Underworld and obtain the Guide Voodoo Doll.",
				o30: "Explore two biome tiles.",
				o31: "Open a chest outside the Forest biome.",
				o32: "Open a chest in the Underground or deeper.",
				o33: "Have two residents other than the Guide.",
				o34: "Explore three evil-biome tiles.",
				o35: "Explore an Ocean tile.",
				o36: "Discover the Bee Hive in the Jungle Lower Cavern.",
				o37: "Explore an Underworld tile.",
				o38: "Explore tiles in all five Surface biomes.",
				o39: "Place five pylons.",
				o40: "Collect a Life Crystal.",
				o41: "Fall at least eight squares without dying.",
				o42: "Open three Underworld chests.",
				o43: "Travel from the Underworld to the Surface in one Character Phase without using a pylon.",
				o44: "Have two characters wearing Gold Armor.",
				o45: "Have three houses stacked above one another.",
				o46: "Have two characters with all six unlocked inventory slots full.",
				o47: "Have every character inside a Bed house at night; they may share a house.",
				o48: "Have a character equip a yoyo in their Other slot.",
				o49: "Defeat four non-boss enemies in one Character Phase using only staves.",
				o50: "Have every character with a summoned minion.",
				o51: "Defeat a boss while the entire team wears only Copper Armor, Wood Armor or no armor throughout the battle.",
				o52: "Collect a Fallen Star.",
				o53: "Spawn at least six non-boss Surface enemies during one night.",
				o54: "Spend at least 50 coins in one Character Phase.",
				o55: "Travel from the Surface to the Underworld in one Character Phase without using a pylon.",
				o9Small: "Dig at least six Hellstone blocks.",
				o27Small: "Defeat three different non-boss enemy types in one Character Phase.",
				o39Small: "Place four pylons.",
				o42Small: "Open two Underworld chests.",
				o44Small: "Have one character wearing Gold Armor.",
				o46Small: "Have one character with all six unlocked inventory slots full.",
				o49Small: "Defeat two non-boss enemies in one Character Phase using only staves.",
				o53Small: "Spawn at least four non-boss Surface enemies during one night.",
				o54Small: "Spend at least 40 coins in one Character Phase."
			},
			objectiveRewards: {
				o0: "Each character gains one coin.",
				o1: "Share two ore of the type just mined.",
				o2: "Each character gains one Iron.",
				o3: "Share two ore of a type used to craft the pickaxe.",
				o4: "Each character gains one random type-two consumable.",
				o5: "Share six coins, or reduce threat by one.",
				o6: "Share two evil ore of the type just mined.",
				o7: "Each character gains one random type-three consumable.",
				o8: "Each character scraps one action card from their hand, deck or discard pile.",
				o9: "Complete this objective chain.",
				o10: "Each character gains one coin.",
				o11: "Each character gains one platform.",
				o12: "Each character gains one free Second Wind card from the Guide.",
				o13: "Share four coins.",
				o14: "Each character gains one random type-two consumable.",
				o15: "Share six coins, or reduce threat by one.",
				o16: "Share four health.",
				o17: "Each character gains one random type-three consumable.",
				o18: "Share two Hellstone.",
				o19: "Complete this objective chain.",
				o20: "Each character gains one coin.",
				o21: "Each character chooses one Wood or three coins.",
				o22: "Share four coins.",
				o23: "Each character scraps one action card from their hand, deck or discard pile; share one Lens.",
				o24: "Each character gains one level-two loot action card.",
				o25: "Each character gains two random type-two consumables.",
				o26: "Each character gains one level-three loot action card.",
				o27: "Each character gains one random type-three consumable.",
				o28: "Each character gains one level-four loot action card.",
				o29: "Complete this objective chain.",
				o30: "Each character gains one coin.",
				o31: "Each character gains one free Explore More card from the Guide.",
				o32: "Each character chooses one rope or two platforms; share one Recall Potion.",
				o33: "Each character gains one random type-two consumable.",
				o34: "Each character scraps one action card from their hand, deck or discard pile.",
				o35: "Each character gains one free Explore More card from the Guide.",
				o36: "Share six coins.",
				o37: "Each character gains one random type-three consumable.",
				o38: "Each character scraps one action card from their hand, deck or discard pile.",
				o39: "Complete this objective chain.",
				o40: "Each character gains two random type-two consumables.",
				o41: "Share six coins, or reduce threat by one.",
				o42: "Each character gains one random type-three consumable.",
				o43: "Complete this objective chain.",
				o44: "Each character gains two random type-two consumables.",
				o45: "Share six coins, or reduce threat by one.",
				o46: "Each character gains one random type-three consumable.",
				o47: "Complete this objective chain.",
				o48: "Each character discounts one action-card purchase by five coins this phase; share two Cobweb.",
				o49: "Each character chooses one Mana Power Potion or Mana Potion.",
				o50: "Each character gains one random type-three consumable.",
				o51: "Complete this objective chain.",
				o52: "Each character scraps one action card from their hand, deck or discard pile.",
				o53: "Each character gains one free Explore More card from the Guide.",
				o54: "Each character gains one random type-three consumable.",
				o55: "Complete this objective chain.",
				o0Small: "Each character gains two coins.",
				o2Small: "Each character gains two Iron.",
				o4Small: "Each character gains two random type-two consumables.",
				o10Small: "Each character gains two coins.",
				o11Small: "Each character gains two platforms.",
				o14Small: "Each character gains two random type-two consumables.",
				o20Small: "Each character gains two coins.",
				o21Small: "Each character chooses two Wood or four coins.",
				o30Small: "Each character gains two coins.",
				o32Small: "Each character chooses two ropes or three platforms; share one Recall Potion.",
				o33Small: "Each character gains two random type-two consumables."
			},
			events: {
				start: "Adventure begins",
				threat: "Threat changes by {{n}}",
				debuff: "{{name}} receives {{item}}",
				death: "{{name}} has fallen",
				damage: "{{name}} loses {{n}}health",
				fall: "{{name}} falls {{n}}squares",
				spawn: "{{item}} spawns",
				discover: "Discovered {{item}}",
				gain: "{{name}} gains {{item}}",
				fight: "{{name}} deals {{n}}damage to {{item}}",
				defeat: "{{name}} defeats {{item}}",
				transform: "{{item}} transforms",
				objective: "Objective completed: {{item}}",
				draw: "{{name}} draws {{n}} action cards",
				round: "Round {{n}} begins",
				escape: "{{item}} leaves the world",
				boss: "{{item}} appears",
				resource: "{{name}} stores {{n}} {{item}}",
				play: "{{name}} uses {{item}}",
				move: "{{name}} moves",
				chop: "{{name}} chops a tree",
				dig: "{{name}} digs a block",
				craft: "{{name}} builds {{item}}",
				npc: "{{item}} arrives",
				use: "{{name}} uses {{item}}",
				roll: "{{name}} rolls dice"
			},
			toolYield: "Yield ×{{n}}",
			cancel: "Cancel",
			buildMenu: "Craft",
			market: "Residents & trade",
			pack: "Backpack",
			yourTurn: "Act freely",
			viewing: "Viewing {{name}}",
			readySlot: "Ready slot",
			emptyEquipment: "Empty slot",
			noChoices: "No actions available now.",
			collectHealth: "Raise max health and fully heal",
			collectMana: "Raise max mana and fully restore",
			collectCoins: "Gain 10 coins",
			selectLocation: "Choose a destination on the map",
			selectTarget: "Choose a target on the map",
			inspect: "Inspect",
			usePoints: "Spend {{n}} points",
			stockpileSlot: "Stockpile",
			status: "Status",
			rewardAvailable: "Choose a reward",
			zoom: "Zoom",
			chooseEffect: "Choose effect",
			threatStep: "Threat step {{n}}",
			noArmor: "No armor",
			defenseBase: "Defense D4",
			objectChain: {
				dig: "Dig",
				build: "Build",
				fight: "Fight",
				explore: "Explore"
			},
			tokenNames: {
				"#": "Dirt",
				s: "Stone",
				cu: "Copper",
				fe: "Iron",
				ag: "Silver",
				au: "Gold",
				g: "Gem",
				de: "Demonite",
				cr: "Crimtane",
				es: "Ebonstone",
				cs: "Crimstone",
				hs: "Hardened Sand",
				ice: "Ice",
				he: "Hellstone",
				empty: "Empty square",
				S: "Enemy spawn",
				C1: "Chest",
				C2: "Chest",
				T1: "Tree",
				T2: "Tree",
				T3: "Tree",
				W: "Cobweb",
				L: "Lava",
				Altar: "Altar",
				Orb4: "Shadow Orb",
				Heart4: "Crimson Heart",
				Larva: "Larva"
			},
			consumableEffects: {
				c0: "Restore 1 health.",
				c1: "Restore 1 mana.",
				c2: "Make one D6 short/medium attack; pierce 1.",
				c3: "Make one D4 short/medium attack; pierce 2.",
				c4: "Gain 2 AP.",
				c5: "This turn, demote one largest defense die of each enemy on your tile.",
				c6: "Teleport to an empty Forest Surface or Bed House square, or gain 5 coins.",
				c7: "Cancel a newly revealed spawn, or be ignored by non-boss enemies this turn.",
				c8: "Gain 2 Defense.",
				c9: "Gain 2 Dig.",
				c10: "This turn, promote one largest attack die when using bows, or gain 5 coins.",
				c11: "Restore 2 health.",
				c12: "This turn, promote one largest attack die for mana equipment, or gain 5 coins.",
				c13: "Draw 2 action cards.",
				c14: "Choose a short/medium target square: 2D6 attack plus 3 Hardy Dig and 3 Chop in each square of its 3×3 area. Characters are also hit.",
				c15: "Choose a short/medium target square: 2D8 attack plus 4 Hardy Dig and 4 Chop in each square of its 3×3 area. Characters are also hit.",
				c16: "Restore 3 mana.",
				c17: "Remove On Fire, or gain 8 coins.",
				c20: "Use on or adjacent to lava in the Underworld to summon the Wall of Flesh.",
				c21: "Choose a short/medium target square: D4 + D6 attack plus 2 Dig and 2 Chop in each square of its 3×3 area. Characters are also hit."
			},
			bossEffects: {
				kingSlime0: "Spawn at uncovered skulls on all active tiles.",
				kingSlime1: "Add D4 to boss defense.",
				kingSlime2: "Boss movement +1.",
				kingSlime3: "Add D6 to boss attack.",
				eye0: "Behavior A: one extra attack against each target.",
				eye1: "Behavior A: one extra attack against each target.",
				eye2: "Boss movement +1.",
				eye3: "Promote one largest boss attack die.",
				queenBee0: "Poison all characters in Jungle Upper/Lower Cavern.",
				queenBee1: "Poison all characters in Jungle Upper/Lower Cavern.",
				queenBee2: "Add D6 to boss attack.",
				queenBee3: "Add D6 to boss attack.",
				wall0: "Increase threat once, or set all Underworld characters On Fire.",
				wall1: "All Underworld characters heal 1.",
				wall2: "Boss movement +1.",
				wall3: "Boss movement +1."
			},
			armorEffects: {
				r15: "Immune to On Fire.",
				r16: "Promote one smallest attack die for long-range equipment.",
				r19: "Reroll one own attack die per turn.",
				r20: "Summoned minions grant +1 Attack.",
				r24: "Gain 2 Dig at Character Phase start.",
				r25: "Immune to Frozen."
			},
			gainChop: "Spend {{cost}} AP for {{n}} Chop",
			gainDig: "Spend {{cost}} AP for {{n}} Dig",
			gainHardyDig: "Spend {{cost}} AP for {{n}} Hardy Dig",
			summonEffect: "Spend {{cost}} mana to summon: gain {{n}} Attack each turn",
			hookEffect: "Spend 2 AP: move {{n}} up and 1 left or right",
			lootLevel: "Level {{n}} action loot",
			resourceReward: "{{n}} {{item}}",
			brainAlly: "Brain ally · defense {{dice}}",
			againConfirm: "Click again to start an adventure",
			diceResult: "Dice result",
			mapInfo: "Map information",
			bossDetails: "Boss status",
			debuffs: "Debuffs",
			emptyDebuffs: "No debuffs",
			healthMana: "Health {{hp}} / {{maxHp}} · Mana {{mana}} / {{maxMana}}",
			craftTabs: {
				tools: "Tools",
				weapons: "Weapons & accessories",
				armor: "Armor",
				houses: "Buildings"
			},
			craftUnavailable: "Crafting requirements not met",
			nightsEdgeRecipe: "When an Altar is revealed, consume any two owned swords among Light’s Bane, Blood Butcherer and Volcano to craft Night’s Edge."
		}
	}
};
//#endregion
export { Cr as default };
