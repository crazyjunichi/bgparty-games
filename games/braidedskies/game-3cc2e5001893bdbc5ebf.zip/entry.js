import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { DeltaNumber as a } from "@bgparty/sdk/fx/delta-number";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as c } from "@bgparty/sdk/assets";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { useI18nSettings as p, useT as ee } from "@bgparty/sdk/i18n";
import { FlySprite as m, PulseBox as te } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as h, OptionSection as g } from "@bgparty/sdk/ui/game-options";
//#region src/games/braidedskies/data.ts
var _ = [
	"y",
	"b",
	"r",
	"t"
], v = [
	"c",
	"s",
	"a"
], y = {
	y: ["黄色汲石", "Yellow tapstone"],
	b: ["蓝色汲石", "Blue tapstone"],
	r: ["红色汲石", "Red tapstone"],
	t: ["游客", "Tourist"]
}, b = {
	c: ["文化", "Culture"],
	s: ["风景", "Scenic"],
	a: ["冒险", "Adventure"]
}, x = {
	...b,
	h: ["遗产", "Heritage"],
	food: ["美食", "Culinary"]
}, S = [
	["单帆飞船", "Single-sail drop ship"],
	["双帆飞船", "Double-sail drop ship"],
	["三帆飞船", "Triple-sail drop ship"]
], C = (e, t, n, r, i, a, o, s = 0) => ({
	id: e,
	name: t,
	track: n,
	cost: r.split(""),
	symbols: i,
	advance: a,
	ability: o,
	grit: s
}), w = [
	["叶之祭", "Lay of the Leaves Festival"],
	["克里德精灵盛宴", "Pixie Feast of Creed"],
	["玛伦夫人的汤汤节", "Madame Maren’s Tomtom Festival"],
	["白兰地鹿战役重演", "Battle of Brandybuck Reenactment"],
	["费舍尔灵药", "Fisher’s Elixirs"],
	["寻宝者密库", "The Finders’ Vault"],
	["斯特格山与迈尔蝴蝶矿", "Steg Mtn. and the Maier Butterfly Mines"],
	["凤凰之心咖啡馆", "Phonix Heart Cafe"],
	["惠瑟姆城门卫队", "The Guards of Whitham Gate"]
], ne = [
	["落石节", "The Festival of Falling Stone"],
	["芬利金雁群", "Golden Flocks of Finlie"],
	["与凋零鲨同游", "Swimming With Wither Sharks"],
	["巴里戈尔德湾巨浪", "The Waves of Barigold Bay"],
	["云端冰淇淋坊", "The Cloud Creamery"],
	["闪电蟹垂钓", "Lightning Crab Fishing"],
	["马格努斯旋流", "Magnus’ Carousel"],
	["西风之尾", "Zephyr’s Tails"],
	["洋流杯", "The Currents Cup"]
], re = [
	["盛放树瘤", "The Blooming Burl"],
	["汤汤果采收", "Tomtom Fruit Harvest"],
	["阿拉多之鼓", "Arador’s Drum"],
	["沙漏喷口", "Hourglass Vent"],
	["史诗水果公司之旅", "Epic Fruit Company Tour"],
	["邱之神谕", "The Chiu Oracle"],
	["彩绘荒原", "The Painted Barrens"],
	["邓哈罗甜味", "Dunharrow Licks"],
	["性情之瓦", "Tiles of Temperament"]
], ie = [
	"XXt*",
	"XXZt",
	"XXXt",
	"XXt**",
	"XXXt*",
	"XXXZt*",
	"XXXXt",
	"XXXZt",
	"XXXt"
], T = [
	["s", "c"],
	[
		"food",
		"food",
		"c"
	],
	[
		"food",
		"s",
		"c"
	],
	[
		"h",
		"a",
		"c"
	],
	[
		"food",
		"food",
		"c"
	],
	[
		"h",
		"s",
		"a",
		"c"
	],
	["c", "c"],
	[
		"food",
		"food",
		"s",
		"c"
	],
	[
		"h",
		"c",
		"c"
	]
], E = [];
for (let [e, t, n, r, i] of [
	[
		"c",
		"y",
		"b",
		w,
		[
			"reroll",
			"guildEncounter",
			"flagonEncounter",
			"any2",
			"reroll",
			"guildEncounter",
			"flagonEncounter",
			"marketFame",
			"reroll"
		]
	],
	[
		"a",
		"r",
		"y",
		ne,
		[
			"grit2",
			"marketFame",
			"trade",
			"any2",
			"trade",
			"marketFame",
			"grit3",
			"marketFame",
			"grit3"
		]
	],
	[
		"s",
		"b",
		"r",
		re,
		[
			"build",
			"marketFame",
			"reroll",
			"outpostFame",
			"outpostActivate",
			"workshopEncounter",
			"workshopEncounter",
			"outpostFame",
			"outpostActivate"
		]
	]
]) for (let a = 0; a < 9; a++) {
	let o = T[a].map((t) => e === "c" ? t : t === "c" ? e : t === "s" ? e === "a" ? "c" : "a" : t === "a" ? "c" : t), s = {
		a: [
			["c", "a"],
			[
				"food",
				"food",
				"a"
			],
			[
				"food",
				"c",
				"a"
			],
			[
				"h",
				"s",
				"a"
			],
			[
				"food",
				"food",
				"a"
			],
			[
				"h",
				"c",
				"s",
				"a"
			],
			["a", "a"],
			[
				"h",
				"food",
				"c",
				"a"
			],
			[
				"h",
				"a",
				"a"
			]
		],
		s: [
			["a", "s"],
			[
				"food",
				"food",
				"s"
			],
			[
				"food",
				"a",
				"s"
			],
			[
				"h",
				"c",
				"s"
			],
			[
				"food",
				"s",
				"s"
			],
			[
				"h",
				"a",
				"c",
				"s"
			],
			["s", "s"],
			[
				"food",
				"food",
				"a",
				"s"
			],
			[
				"h",
				"s",
				"s"
			]
		]
	}, c = a < 2 ? [e, "*"] : a === 2 ? [e, e] : [
		e,
		e,
		a === 3 || a === 5 || a === 7 || a === 8 ? e === "c" ? "a" : e === "a" ? "s" : "c" : e
	];
	e === "s" && a === 8 && (c[2] = "s"), E.push(C(`${e}${a + 1}`, r[a], e, ie[a].replaceAll("X", t).replaceAll("Z", n), s[e]?.[a] ?? o, c, i[a], i[a] === "any2" ? 2 : +(i[a] === "build" || i[a] === "outpostActivate")));
}
var D = [
	["红路商队", "The Red Way Caravan"],
	["萤火虫大狩猎", "The Great Firefly Hunt"],
	["大星塔", "Great Star Tower"],
	["水母海", "The Jellyfish Sea"],
	["哈拉巴拉斯特俱乐部", "The Halabalaster Club"],
	["提普顿火泉", "The Fire Springs of Tipton"],
	["海德峰风力采集", "Hyde Peak Wind Harvesting"]
];
for (let e = 0; e < 7; e++) E.push(C(`start${e + 1}`, D[e], "start", "", [e < 2 ? "c" : e < 4 ? "s" : e < 6 ? "a" : "h"], [], `start${e + 1}`));
var O = Object.fromEntries(E.map((e) => [e.id, e])), k = [
	["货物分拣架", "Cargo Sorting Rack"],
	["补给站", "Refill Station"],
	["备件柜", "Spare Parts Locker"],
	["码头旅游手册", "Dockside Tour Brochure"],
	["游客接待平台", "Tourist Welcome Platform"],
	["夜床服务", "Turndown Service"],
	["汲石漏斗", "Tapstone Funnel"],
	["货箱补给臂", "Crate Resupply Arm"],
	["转化舱", "Conversion Chamber"],
	["安全带升级", "Safety Harness Upgrade"],
	["风暴准备训练", "Storm Prep Training"],
	["重物升降机", "Heavy Gear Lift"],
	["图书馆扩建", "Library Expansion"],
	["备用御风手套", "Spare Wind Gloves"],
	["观景甲板", "Observation Deck"],
	["导览旅程", "Guided Tour"],
	["全景眺望台", "Panorama Overlook"],
	["船员故事会", "Crew Story Hour"],
	["空中新闻报道", "Aerial Press Coverage"],
	["灯下传奇", "Legend by Lamplight"],
	["壮举节", "Festival of Feats"],
	["日落巡航", "Sunset Cruise"],
	["民俗舞之夜", "Folk Dance Night"],
	["空中雪橇赛道", "Sky Sled Course"],
	["黄金旅行套餐", "Gold-Tier Travel Package"],
	["纪念币", "Commemorative Coin"],
	["告别烟火秀", "Farewell Fireworks Show"],
	["珍奇食橱", "Pantry of Curiosities"],
	["客座主厨展示", "Guest Chef Showcase"],
	["采集者地图", "Tapper’s Map"],
	["采矿钻机", "Mining Drill"],
	["补给空投", "Supplies Airdrop"],
	["测绘员", "Surveyor"],
	["攀越风墙", "Wind Wall Climb"],
	["英雄试炼", "Hero’s Gauntlet"],
	["耐力鸣钟", "Endurance Bell Ring"]
], ae = /* @__PURE__ */ "r.b.y.yr.rb.by.rr.bb.yy.*r.*b.*y.r.b.y.*t.*t.*t.*r.*b.*y.tr.tb.ty.tt.tt.tt.*C.*C.*C.*C.*C.*C.rC.bC.yC".split("."), oe = /* @__PURE__ */ "stone.stone.stone.tourist.tourist.tourist.resource.resource.resource.grit3.grit3.grit3.c.a.s.any.any.any.as.cs.ca.ss.cc.aa.fame3.fame3.fame3.foodFame.foodFame.outpostTypes.outpostTypes.outpostActivate.outpostActivate.trade.trade.trade".split("."), se = k.map((e, t) => ({
	id: `o${t + 1}`,
	name: e,
	slots: ae[t].split("").map((e) => e === "C" ? "crew" : e),
	effect: oe[t],
	grit: t >= 6 && t <= 8 ? 1 : t >= 18 && t <= 26 || t >= 31 && t <= 32 ? 2 : 0
})), A = Object.fromEntries(se.map((e) => [e.id, e])), ce = {
	resource: ["飞船舱", "Drop Ship Bay"],
	outpost: ["前哨扩建", "Outpost Expansion"],
	grit: ["风力引擎", "Wind Engines"]
}, le = [
	[
		"resource",
		"outpost",
		"grit"
	],
	[
		"outpost",
		"grit",
		"resource"
	],
	[
		"grit",
		"resource",
		"outpost"
	],
	[
		"outpost",
		"resource",
		"grit"
	],
	[
		"resource",
		"grit",
		"outpost"
	]
], ue = [
	["全体登船！", "All Aboard!"],
	["连胜！", "Hot Streak!"],
	["季节奇观", "Seasonal Wonder"],
	["善行", "Good Deeds"],
	["善意邀约", "A Kind Offer"],
	["酒与交易", "Drinks & Deals"],
	["毅力考验", "Test of Grit"],
	["盛大活动", "The Big Event"],
	["巅峰效率", "Peak Efficiency"],
	["一线曙光", "Silver Lining"],
	["重要的信标", "An Important Beacon"],
	["公平交易", "A Fair Trade"],
	["专家到访", "An Expert Arrives"],
	["恰逢其时！", "Just in Time!"],
	["猝不及防！", "Blindsided!"],
	["满堂！", "Full House!"],
	["故事时间", "Story Time"],
	["拳脚相向", "Fisticuffs"],
	["红色警报！", "Red Alert!"],
	["迷你市场", "Mini Market"],
	["早鸟", "Early Bird"],
	["初雪", "First Snowfall"],
	["战利品空降", "Loot Drop"],
	["短暂停靠", "A Quick Stop"],
	["风向转变", "A Change in the Wind"]
], j = Array.from({ length: 25 }, (e, t) => ({
	a: t >= 6 && t <= 8 ? "grit2" : t < 3 || t >= 9 && t < 12 ? "resource" : t === 3 || t === 15 || t === 19 ? "b" : t === 4 || t === 8 || t === 16 || t === 18 ? "y" : t === 5 || t === 7 || t === 17 || t === 20 ? "r" : t === 6 || t === 24 ? "grit2" : "t",
	b: t < 3 ? `count${[
		"r",
		"y",
		"b"
	][t]}` : t < 6 ? "outfit" : t < 9 ? [
		"b",
		"r",
		"y"
	][t - 6] : t < 12 ? [
		"s",
		"c",
		"a"
	][t - 9] : t < 15 ? "fame3" : t < 18 ? [
		"s",
		"c",
		"a"
	][t - 15] : t < 21 ? "fame3" : t < 24 ? `count${[
		"r",
		"y",
		"b"
	][t - 21]}` : "t",
	grit: +(t < 6 || t >= 9 && t <= 20),
	port: t >= 9 && t <= 11 ? "market" : t === 12 ? "wc" : t === 13 ? "ws" : t === 14 ? "wa" : t === 15 ? "workshop" : t === 16 ? "guild" : t === 17 ? "flagon" : t >= 18 && t <= 20 ? "festival" : void 0
})), de = {
	p0: ["西风余烬", "Zephyr’s Cinders"],
	p1: ["虹彩喷泉", "Rainbow Geyser"],
	p2: ["马格努斯旋流", "Magnus Carousel"],
	p3: ["交织瀑布", "Braided Falls"],
	p4: ["朱红荒地", "Vermillion Wastes"],
	p5: ["巨柱", "The Pillars"],
	p6: ["长者平原", "Elder Plains"],
	p7: ["内森谷", "Nathan’s Vale"],
	p8: ["斯塔克海峡", "Stark Sound"],
	wc: ["文化奇观港", "Culture Wonder Port"],
	ws: ["风景奇观港", "Scenic Wonder Port"],
	wa: ["冒险奇观港", "Adventure Wonder Port"],
	festival: ["汤汤节", "Tomtom Festival"],
	market: ["地下市场", "Underground Market"],
	guild: ["自由飞行者公会", "Free Flyer’s Guild"],
	workshop: ["雷霆工坊", "Thunder’s Workshop"],
	flagon: ["破旗酒馆", "Cracked Flagon"]
}, fe = [
	"c",
	"s",
	"h",
	"food",
	"food",
	"encounter",
	"t",
	"t",
	"crew",
	"a",
	"encounter",
	"h"
], pe = [
	["安瑟姆机械极光", "Automauroric Skies of Anthem"],
	["耳语自动乐厅", "Auricular Automatorium"],
	["法拉斯自动工艺学院", "Falas Institute of Automastry"],
	["机械汤汤盛宴", "Automtoma Gala"]
], me = [
	["h"],
	[
		"c",
		"s",
		"a"
	],
	["a", "s"],
	["s", "food"]
], he = [
	{
		ships: [
			0,
			1,
			2
		],
		tracks: [
			"c",
			"s",
			"a"
		],
		collection: !0,
		deep: !0,
		recall: !1,
		bonus: "festival"
	},
	{
		ships: [
			0,
			1,
			2
		],
		tracks: [
			"s",
			"a",
			"c"
		],
		collection: !1,
		deep: !1,
		recall: !1,
		bonus: "market"
	},
	{
		ships: [
			1,
			2,
			0
		],
		tracks: [
			"s",
			"a",
			"c"
		],
		collection: !0,
		deep: !1,
		recall: !0,
		bonus: "guild"
	},
	{
		ships: [
			2,
			0,
			1
		],
		tracks: [
			"a",
			"c",
			"s"
		],
		collection: !0,
		deep: !0,
		recall: !1,
		bonus: "workshop"
	},
	{
		ships: [
			1,
			2,
			0
		],
		tracks: [
			"a",
			"s",
			"c"
		],
		collection: !1,
		deep: !1,
		recall: !1,
		bonus: "flagon"
	},
	{
		ships: [
			2,
			0,
			1
		],
		tracks: [
			"c",
			"s",
			"a"
		],
		collection: !1,
		deep: !1,
		recall: !1,
		bonus: "festival"
	},
	{
		ships: [
			0,
			1,
			2
		],
		tracks: [
			"c",
			"s",
			"a"
		],
		collection: !0,
		deep: !0,
		recall: !0,
		bonus: "market"
	},
	{
		ships: [
			0,
			1,
			2
		],
		tracks: [
			"a",
			"c",
			"s"
		],
		collection: !1,
		deep: !1,
		recall: !1,
		bonus: "guild"
	},
	{
		ships: [
			1,
			2,
			0
		],
		tracks: [
			"s",
			"c",
			"a"
		],
		collection: !1,
		deep: !1,
		recall: !1,
		bonus: "workshop"
	},
	{
		ships: [
			1,
			2,
			0
		],
		tracks: [
			"s",
			"a",
			"c"
		],
		collection: !0,
		deep: !0,
		recall: !1,
		bonus: "flagon"
	},
	{
		ships: [
			2,
			0,
			1
		],
		tracks: [
			"c",
			"a",
			"s"
		],
		collection: !1,
		deep: !1,
		recall: !0,
		bonus: "workshop"
	},
	{
		ships: [
			2,
			0,
			1
		],
		tracks: [
			"a",
			"c",
			"s"
		],
		collection: !0,
		deep: !1,
		recall: !1,
		bonus: "flagon"
	}
];
//#endregion
//#region src/games/braidedskies/fx-events.ts
function ge(e, t, n, r) {
	let i = [], a = e.players.find((e) => e.rid === n.rid), o = t.players.find((e) => e.rid === n.rid);
	if (!a || !o) return i;
	let s = (e, t, r) => i.push({
		kind: "bsFly",
		rid: n.rid,
		data: {
			from: `bs/${e}`,
			to: `bs/${t}`,
			sprite: r
		},
		with: i.length > 0
	}), c = (e, t = "pulse") => i.push({
		kind: "bsReveal",
		rid: n.rid,
		data: {
			anchor: `bs/${e}`,
			style: t
		},
		with: i.length > 0
	});
	if (r) {
		let e = r.row ?? 0, t = `slot/${n.rid}/${e}/${r.value}/${r.slot}`;
		r.kind === "deploy" && s(`ship/${n.rid}/${e}`, `visitor/${n.rid}/${e}`, `ship${e}`), r.kind === "recallRow" && s(`port/${a.ships[e].port}`, `ship/${n.rid}/${e}`, `ship${e}`), r.kind === "pay" && s(t, `supply/${r.resource}`, r.resource), r.kind === "payPocket" && s(`cargo/${n.rid}`, `supply/${r.resource}`, r.resource), (r.kind === "place" || r.kind === "store") && s(`cargo/${n.rid}`, t, r.resource), (r.kind === "captainSlot" || r.kind === "crewSlot") && s(r.kind === "captainSlot" ? `captain/${n.rid}` : `crew/${n.rid}/${e}`, t, r.kind === "captainSlot" ? "captain" : "crew"), r.kind === "captainWonder" && s(`captain/${n.rid}`, `wonder/${n.rid}/${r.value}`, "captain"), r.kind === "outfitSelect" && s(`market/${r.value}`, "pending", r.card), r.kind === "outfitPlace" && c(`outfit/${n.rid}/${e}/${a.rows[e].length}`, "flip"), r.kind === "encounter" && s(`hand/${n.rid}`, "discard", `e${Number(r.value) + 1}`), r.kind === "keepEncounter" && s("deck", `hand/${n.rid}`, `e${Number(r.value) + 1}`), r.kind === "activate" && c(`outfit/${n.rid}/${e}/${r.value}`), r.kind === "upgrade" && c(`${r.value}/${n.rid}/${e}`, "flip"), r.kind === "outpost" && c(`port/p${r.value}`, "build");
	}
	if (!r && n.kind === "wonderAcquire" && o.wonders.length > a.wonders.length && s(`wonderPort/${n.port}`, `wonder/${n.rid}/${o.wonders.at(-1)}`, o.wonders.at(-1)), !r && n.kind === "advance") {
		let e = v.indexOf(n.value);
		o.tracks[e] > a.tracks[e] && i.push({
			kind: "bsTrack",
			rid: n.rid,
			data: {
				track: n.value,
				from: a.tracks[e],
				to: o.tracks[e]
			},
			with: i.length > 0
		});
	}
	if (!r && n.kind === "explore" && t.cloud !== e.cloud) {
		for (let [n, r] of t.ports.entries()) r.open && !e.ports[n].open && c(`port/${r.id}`, "cloud");
		c("cloudEvent", "cloud");
	}
	if ((!r && n.kind === "roll" || r?.kind === "reroll") && c("dice", "roll"), o.encounters.length > a.encounters.length && r?.kind !== "keepEncounter" && s("deck", `hand/${n.rid}`, `e${o.encounters.at(-1) + 1}`), [
		"collectionCore",
		"resource",
		"harvest",
		"effect",
		"keepDie",
		"automaGain"
	].includes(r?.kind ?? n.kind)) {
		let r = o.cargo.length > a.cargo.length, i = o.pocket.length > a.pocket.length;
		if (r || i) for (let r = 0; r < 4; r++) for (let i = 0; i < e.supply[r] - t.supply[r]; i++) s(`supply/${_[r]}`, `cargo/${n.rid}`, _[r]);
	}
	if (!r && n.kind === "collectionCore" && n.port) {
		let r = e.ports.find((e) => e.id === n.port), i = t.ports.find((e) => e.id === n.port);
		if (r && i) for (let e of r.resources.slice(i.resources.length)) s(`port/${n.port}`, `cargo/${n.rid}`, e);
	}
	if (!r && n.kind === "automa") for (let e = 0; e < 3; e++) a.ships[e].port !== o.ships[e].port && s(a.ships[e].port ? `port/${a.ships[e].port}` : `ship/${n.rid}/${e}`, o.ships[e].port ? `visitor/${n.rid}/${e}` : `ship/${n.rid}/${e}`, `ship${e}`);
	if (r?.kind === "endRecall") for (let [e, t] of a.rows.entries()) for (let [r, i] of t.entries()) for (let [t, a] of i.tokens.entries()) (a === "captain" || a === "crew") && s(`slot/${n.rid}/${e}/${r}/${t}`, a === "captain" ? `captain/${n.rid}` : `crew/${n.rid}/${e}`, a);
	return i;
}
//#endregion
//#region src/games/braidedskies/meta.ts
var _e = {
	id: "braidedskies",
	tier: "alpha",
	nameKey: "games.braidedskies.name",
	descKey: "games.braidedskies.desc",
	rulesKey: "games.braidedskies.rules",
	rulesUrl: { en: "https://stonemaiergames.com/games/braided-skies/rules-faq/" },
	icon: "☁️",
	iconImg: "games/braidedskies.webp",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [2, 3],
	accent: "#597e92",
	mechanics: [
		"worker-placement",
		"engine-building",
		"set-collection",
		"dice-rolling"
	],
	interactionTags: [],
	releasedAt: "2026-11-05T12:40:00+08:00",
	search: {
		py: "jiao zhi cang qiong",
		init: "jzcq"
	},
	hotseat: "open",
	botDelayMs: 450
}, ve = t.object({
	soloLevel: t.int().min(0).max(5).default(2),
	automaStart: t.int().min(-1).max(3).default(-1)
}).prefault({}), ye = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(250)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), be = t.object({
	id: t.string(),
	kind: t.string(),
	value: t.string(),
	n: t.number().optional(),
	row: t.int().optional(),
	slot: t.int().optional(),
	card: t.string().optional(),
	resource: t.string().optional(),
	score: t.number().optional()
}), xe = t.object({
	id: t.string(),
	tokens: t.array(t.string().nullable()),
	used: t.boolean()
}), Se = t.object({
	port: t.string().nullable(),
	crew: t.boolean(),
	harvester: t.boolean(),
	crewUsed: t.boolean()
}), Ce = t.object({
	fame: t.int(),
	heritage: t.int(),
	tracks: t.array(t.int()),
	automa: t.int(),
	total: t.int()
}), we = t.object({
	rid: t.string(),
	mat: t.int(),
	ships: t.array(Se),
	rows: t.array(t.array(xe)),
	grit: t.int(),
	fame: t.int(),
	tracks: t.array(t.int()),
	wonders: t.array(t.string()),
	encounters: t.array(t.int()),
	outposts: t.array(t.int()),
	captainUsed: t.boolean(),
	pocket: t.array(t.string()),
	cargo: t.array(t.string()),
	score: Ce,
	automa: t.boolean()
}), Te = t.object({
	id: t.string(),
	open: t.boolean(),
	tile: t.string().nullable(),
	resources: t.array(t.string()),
	fame: t.int()
}), Ee = t.object({
	rid: t.string(),
	kind: t.string(),
	value: t.string(),
	n: t.number().optional()
}), De = t.object({
	phase: t.enum([
		"play",
		"settle",
		"done"
	]),
	turn: t.string(),
	actor: t.string(),
	round: t.int(),
	prompt: t.string(),
	source: t.string(),
	promptValue: t.string(),
	promptRow: t.int(),
	promptPort: t.string(),
	payment: t.array(t.string()),
	players: t.array(we),
	ports: t.array(Te),
	market: t.array(t.string()),
	wonderTops: t.array(t.string().nullable()),
	supply: t.array(t.int()),
	fameSupply: t.int(),
	outfitCount: t.int(),
	encounterCount: t.int(),
	recall: t.array(t.int()),
	activeRow: t.int(),
	lastPort: t.string().nullable(),
	encountersPlayed: t.int(),
	endRound: t.int().nullable(),
	dice: t.array(t.string()),
	revealed: t.array(t.int()),
	cloud: t.string().nullable(),
	automaCard: t.int().nullable(),
	automaStart: t.int(),
	config: ve,
	log: t.array(Ee)
}), Oe = t.object({ choices: t.array(be) }), M = (e, t) => e.players.find((e) => e.rid === t), N = (e, t, n = {}) => ({
	kind: e,
	rid: t,
	...n
}), P = (e, ...t) => {
	e.queue.unshift(...t);
}, F = (t, n) => {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}, I = (e, t, n, r = "", i) => {
	e.log.push({
		rid: t,
		kind: n,
		value: r,
		...i === void 0 ? {} : { n: i }
	});
}, L = (e, t) => {
	e.grit = Math.max(0, Math.min(8, e.grit + t));
};
function R(e, t, n) {
	let r = M(e, t);
	r.fame += n, I(e, t, "fame", "", n), Re(e);
}
function z(e, t) {
	let n = {
		c: 0,
		s: 0,
		a: 0,
		h: 0,
		food: 0
	};
	for (let e of t.wonders) for (let t of O[e]?.symbols ?? []) n[t]++;
	if (t.automa) {
		for (let t of me[e.automaStart]) n[t]++;
		for (let t of e.config.soloLevel <= 1 ? ["h"] : [
			"c",
			"s",
			"a",
			"h",
			"food"
		]) n[t]++;
	}
	return n;
}
var ke = (e, t, n) => t.id.startsWith("base:") ? ["*", _[n]] : A[t.id].slots, Ae = (e) => [...e.rows.flatMap((e) => e.flatMap((e) => e.tokens.filter((e) => _.includes(e)))), ...e.pocket.filter((e) => _.includes(e))], B = (e, t) => Ae(e).filter((e) => e === t).length, je = (e, t) => e.ships.filter((e) => e[t]).length, Me = (e) => e.wonders.at(-1);
function V(e, t) {
	return _.includes(t) && e.supply[_.indexOf(t)] > 0;
}
function H(e, t, n, r) {
	let i = _.indexOf(n);
	if (e.supply[i] <= 0) return;
	e.supply[i]--;
	let a = M(e, t);
	a.automa ? a.pocket.push(n) : r === "cargo" ? a.cargo.push(n) : (a.pocket.push(n), P(e, N("place", t, {
		value: n,
		port: r,
		flag: !0
	})));
}
function Ne(e, t) {
	_.includes(t) && e.supply[_.indexOf(t)]++;
}
function U(e, t, n = 1) {
	let r = M(e, t), i = 0;
	for (let t = 0; t < n; t++) {
		e.encounterDeck.length || (e.encounterDeck = F(e, e.encounterDiscard), e.encounterDiscard = []);
		let t = e.encounterDeck.pop();
		t !== void 0 && (r.encounters.push(t), i++);
	}
	i && I(e, t, "encounter", "", i);
}
function Pe(e) {
	return e.outfitDeck.length || (e.outfitDeck = F(e, e.outfitDiscard), e.outfitDiscard = []), e.outfitDeck.pop();
}
function Fe(e) {
	for (; e.market.length < 4;) {
		let t = Pe(e);
		if (!t) break;
		e.market.unshift(t);
	}
}
function Ie(e, t) {
	let n = Ae(e);
	for (let e of t.filter((e) => e !== "*")) {
		let t = n.indexOf(e);
		if (t < 0) return !1;
		n.splice(t, 1);
	}
	return n.length >= t.filter((e) => e === "*").length;
}
function Le(e, t) {
	return t < 3 || !e.players.some((e) => e.ships.some((e) => e.port === `p${t}`));
}
function Re(e) {
	e.endRound === null && (e.players.some((e) => e.fame >= 60 || e.wonders.length + (e.automa ? 2 : 0) >= 7) || v.every((t, n) => e.players.some((e) => e.tracks[n] >= 11))) && (e.endRound = e.round + 1);
}
function ze(e, t, n, r = 1) {
	P(e, ...Array.from({ length: r }, () => N("advance", t, { value: n })));
}
function Be(e, t) {
	let n = M(e, t.rid), r = v.indexOf(t.value);
	if (n.tracks[r] >= 13 || (n.tracks[r]++, I(e, n.rid, "advance", t.value, n.tracks[r]), Re(e), n.automa)) return;
	let i = n.tracks[r], a = z(e, n);
	i === 13 && R(e, n.rid, 4), t.value === "c" && (i === 3 && P(e, N("outfitDraw", n.rid)), (i === 4 || i === 9) && U(e, n.rid), i === 6 && R(e, n.rid, 4 + ([
		"food",
		"c",
		"s",
		"a"
	].every((e) => a[e] > 0) ? 5 : 0)), i === 11 && R(e, n.rid, 6 + a.food)), t.value === "s" && (i === 3 && P(e, N("upgrade", n.rid, { value: "harvester" })), (i === 4 || i === 9) && P(e, N("outpost", n.rid)), i === 6 && R(e, n.rid, 4 + je(n, "harvester") + je(n, "crew")), i === 11 && R(e, n.rid, 6 + n.outposts.length)), t.value === "a" && ((i === 1 || i === 4) && L(n, 1), i === 3 && P(e, N("upgrade", n.rid, { value: "crew" })), i === 6 && R(e, n.rid, 6 + (n.grit >= 6 ? 5 : 0)), i === 9 && L(n, 2), i === 11 && R(e, n.rid, 6 + (v.every((e) => n.wonders.some((t) => O[t]?.track === e)) ? 5 : 0)));
}
function Ve(e, t, n, r = "free") {
	let i = M(e, t), a = e.ports[n].tile;
	a && ([
		"c",
		"s",
		"a",
		"h",
		"food"
	].includes(a) ? R(e, t, z(e, i)[a]) : a === "crew" ? R(e, t, je(i, "crew")) : a === "encounter" ? U(e, t) : a === "t" && H(e, t, "t", r));
}
function W(e, t, n, r = "free", i) {
	let a = M(e, t);
	if (n === "stone" || n === "resource") {
		P(e, N("resource", t, {
			value: n === "stone" ? "ybr" : "ybrt",
			port: r
		}));
		return;
	}
	if (n === "tourist" || _.includes(n)) {
		H(e, t, n === "tourist" ? "t" : n, r);
		return;
	}
	if (n === "grit2" || n === "grit3") {
		L(a, Number(n.slice(-1)));
		return;
	}
	if (n === "fame3") {
		R(e, t, 3);
		return;
	}
	if (n === "any" || n === "any2") {
		P(e, N("track", t, { n: n === "any2" ? 2 : 1 }));
		return;
	}
	if (/^[csa]{1,2}$/.test(n)) {
		P(e, ...n.split("").map((e) => N("advance", t, { value: e })));
		return;
	}
	if (n === "outpostChoice") {
		P(e, N("outpostChoice", t));
		return;
	}
	if (n === "foodFame") {
		R(e, t, z(e, a).food);
		return;
	}
	if (n === "outpostTypes") {
		R(e, t, a.outposts.length);
		return;
	}
	if (n === "outpostActivate") {
		P(e, N("activateOutpost", t, { port: r }));
		return;
	}
	if (n === "outpostFame") {
		R(e, t, a.outposts.length);
		return;
	}
	if (n === "build") {
		P(e, N("outpost", t));
		return;
	}
	if (n === "trade") {
		P(e, N("trade", t));
		return;
	}
	if (n.startsWith("start")) {
		let r = Number(n.slice(5));
		P(e, N("track", t, {
			n: 1,
			value: r < 3 ? "a" : r < 5 ? "c" : r < 7 ? "s" : void 0
		}), N("startingFame", t, { n: r }));
		return;
	}
	if (n === "base") {
		W(e, t, a.rows[i][0].id.slice(5) === "outpost" ? "outpostChoice" : a.rows[i][0].id.slice(5) === "grit" ? "grit2" : "resource", r);
		return;
	}
}
var G = (e, t = "", n = {}) => ({
	id: [
		e,
		t,
		n.row ?? "",
		n.slot ?? "",
		n.card ?? "",
		n.resource ?? "",
		n.n ?? ""
	].join("~"),
	kind: e,
	value: t,
	...n
});
function He(e) {
	let t = e.cost ?? [];
	return t.find((e) => e !== "*") ?? t[0];
}
function Ue(e) {
	return e.card && O[e.card] ? [...O[e.card].cost] : e.value === "festival" ? [
		"t",
		"t",
		"t",
		"t"
	] : e.value === "market" ? e.n === 0 ? ["*", "*"] : e.n === 1 ? [e.resource, e.resource] : [
		"*",
		"*",
		"*"
	] : e.value === "guild" ? ["y"] : e.value === "workshop" ? ["b"] : e.value === "flagon" ? ["r"] : [];
}
function We(e, t) {
	if (t.kind !== "deploy") return !1;
	let n = Ue(t);
	for (let t of e.pocket) {
		let e = n.indexOf(t), r = e < 0 ? n.indexOf("*") : e;
		if (r < 0) return !1;
		n.splice(r, 1);
	}
	return !0;
}
var Ge = (e, t) => e === "*" || e === t;
function Ke(e) {
	return e.rows.flatMap((t, n) => t.flatMap((t, r) => t.tokens.flatMap((i, a) => i === null ? [{
		row: n,
		oi: r,
		slot: a,
		need: ke(e, t, n)[a]
	}] : [])));
}
function qe(e, t) {
	let n = M(e, t.rid), r = [];
	switch (t.kind) {
		case "turn":
			for (let t = 0; t < 3; t++) if (n.ships[t].port === null) {
				for (let i = t; i < 9; i += 3) e.ports[i].open && Le(e, i) && r.push(G("deploy", `p${i}`, {
					row: t,
					score: 2 + (n.ships[t].crew || n.ships[t].harvester ? 1 : 0)
				}));
				for (let i = 0; i < 3; i++) {
					let a = e.wonderDecks[i].at(-1);
					a && Ie(n, O[a].cost) && r.push(G("deploy", `w${v[i]}`, {
						row: t,
						card: a,
						score: 8
					}));
				}
				Ie(n, [
					"t",
					"t",
					"t",
					"t"
				]) && r.push(G("deploy", "festival", {
					row: t,
					score: 10
				})), Ie(n, ["*", "*"]) && r.push(G("deploy", "market", {
					row: t,
					n: 0,
					score: 2
				}));
				for (let e of _) B(n, e) >= 2 && r.push(G("deploy", "market", {
					row: t,
					n: 1,
					resource: e,
					score: 3
				}));
				Ie(n, [
					"*",
					"*",
					"*"
				]) && r.push(G("deploy", "market", {
					row: t,
					n: 2,
					score: 4
				})), n.grit >= 1 && (B(n, "y") > 0 && n.rows.some((e) => e.length < 3) && e.market.length && r.push(G("deploy", "guild", {
					row: t,
					score: 4
				})), B(n, "b") > 0 && n.ships.some((e) => !e.harvester) && r.push(G("deploy", "workshop", {
					row: t,
					score: 5
				})), B(n, "r") > 0 && n.ships.some((e) => !e.crew) && r.push(G("deploy", "flagon", {
					row: t,
					score: 5
				})));
			}
			if (n.ships.some((e) => e.port !== null) && r.push(G("recall", "", { score: 3 })), n.pocket.length) return r.filter((e) => We(n, e));
			break;
		case "pay": {
			let e = He(t);
			if (n.pocket.forEach((t, n) => {
				(e === "*" || t === e) && r.push(G("payPocket", String(n), { resource: t }));
			}), !r.length) for (let t = 0; t < 3; t++) for (let i = 0; i < n.rows[t].length; i++) n.rows[t][i].tokens.forEach((n, a) => {
				n && _.includes(n) && (e === "*" || n === e) && r.push(G("pay", String(i), {
					row: t,
					slot: a,
					resource: n
				}));
			});
			break;
		}
		case "resource":
			for (let n of t.value ?? "ybrt") V(e, n) && r.push(G("resource", n, { score: n === "t" ? 1.3 : 1 }));
			r.length || r.push(G("skip"));
			break;
		case "harvest":
			V(e, t.value) && r.push(G("harvest", t.value)), (!t.n || V(e, "t")) && r.push(G("harvest", t.n ? "t" : "die")), r.length || r.push(G("skip"));
			break;
		case "place": {
			let i = t.port === "cargo", a = i ? n.cargo : n.pocket, o = [...new Set(t.value ? [t.value] : a)];
			for (let e of o) if (a.includes(e)) for (let a of Ke(n)) Ge(a.need, e) && (!i || a.row === t.row || n.grit > 0) && r.push(G("place", String(a.oi), {
				row: a.row,
				slot: a.slot,
				resource: e,
				score: a.row === t.row ? 2 : 1
			}));
			if (i) r.push(G("discard"));
			else {
				let i = e.queue[1];
				t.port === "pocket" && i && (i.kind === "pay" && (He(i) === "*" || He(i) === t.value) || i.kind === "turn" && qe(e, i).some((e) => We(n, e))) && r.push(G("directPayment", t.value)), r.length || r.push(G("skip"));
			}
			break;
		}
		case "track":
			if (t.value) r.push(G("track", t.value));
			else for (let e of v) r.push(G("track", e, { score: n.tracks[v.indexOf(e)] >= 13 ? 0 : 2 }));
			break;
		case "outpostChoice":
			r.push(G("outpostChoice", "track")), n.outposts.length < 6 && e.ports.some((e, t) => t < 9 && e.open && !n.outposts.includes(t)) && r.push(G("outpostChoice", "build"));
			break;
		case "outpost":
			if (n.outposts.length < 6) for (let t = 0; t < 9; t++) e.ports[t].open && !n.outposts.includes(t) && r.push(G("outpost", String(t)));
			r.push(G("skip"));
			break;
		case "activateOutpost":
			for (let e of n.outposts) r.push(G("activateOutpost", String(e)));
			r.push(G("skip"));
			break;
		case "upgrade":
			n.ships.forEach((e, n) => {
				e[t.value] || r.push(G("upgrade", t.value, { row: n }));
			}), r.length || r.push(G("skip"));
			break;
		case "outfitSelect":
			e.market.forEach((e, t) => r.push(G("outfitSelect", String(t), { card: e }))), !t.flag && e.market.length === 4 && r.push(G("cycle"));
			break;
		case "outfitPlace":
			n.rows.forEach((e, n) => {
				e.length < 3 && r.push(G("outfitPlace", t.card, {
					row: n,
					card: t.card
				}));
			}), r.length || r.push(G("skip"));
			break;
		case "recall":
			for (let t of e.recall) r.push(G("recallRow", "", { row: t }));
			e.recall.length || r.push(G("endRecall"));
			break;
		case "row":
			n.rows[t.row].forEach((e, i) => {
				let a = e.id.startsWith("base:") ? null : A[e.id];
				!e.used && e.tokens.every((e) => e !== null) && n.grit >= (a?.grit ?? 0) && r.push(G("activate", String(i), {
					row: t.row,
					card: e.id,
					score: 2
				}));
			}), r.push(G("endRow"));
			break;
		case "trade":
			for (let e = 1; e <= n.grit; e++) r.push(G("trade", "", {
				n: e,
				score: e
			}));
			r.push(G("skip"));
			break;
		case "cloudChoice":
			t.value === "encounterGrit" ? r.push(G("cloudChoice", "encounter"), G("cloudChoice", "grit2")) : r.push(G("cloudChoice", "encounter"), G("cloudChoice", "any"));
			break;
		case "keepEncounter":
			for (let t of e.revealed) r.push(G("keepEncounter", String(t), { card: `e${t + 1}` }));
			break;
		case "dice":
			r.push(G("keepDie", t.value)), O[Me(n) ?? ""]?.ability === "reroll" && !t.flag && r.push(G("reroll"));
			break;
		case "cloudPort":
			for (let e of v) r.push(G("cloudPort", `w${e}`));
			break;
		case "end": r.push(G("finish"));
	}
	return r;
}
function Je(e, t) {
	let n = M(e, t.rid), r = [];
	if (t.rid === e.players[e.turn].rid && !n.automa && e.encountersPlayed < 2 && t.kind !== "keepEncounter") for (let t of n.encounters) {
		let i = j[t];
		r.push(G("encounter", String(t), {
			n: 0,
			card: `e${t + 1}`,
			score: 1
		})), n.grit >= i.grit && (!i.port || e.lastPort === i.port) && r.push(G("encounter", String(t), {
			n: 1,
			card: `e${t + 1}`,
			score: 2
		}));
	}
	if (e.recalling && t.rid === e.players[e.turn].rid && !n.automa) {
		for (let e of Ke(n)) n.captainUsed || r.push(G("captainSlot", String(e.oi), {
			row: e.row,
			slot: e.slot
		})), n.ships[e.row].crew && !n.ships[e.row].crewUsed && r.push(G("crewSlot", String(e.oi), {
			row: e.row,
			slot: e.slot
		}));
		if (!n.captainUsed) for (let e of [.../* @__PURE__ */ new Set([n.wonders[0], Me(n)])]) {
			let t = O[e];
			t && (t.ability.startsWith("start") || ![
				"reroll",
				"guildEncounter",
				"flagonEncounter",
				"workshopEncounter",
				"marketFame"
			].includes(t.ability)) && n.grit >= t.grit && r.push(G("captainWonder", e, {
				card: e,
				score: 3
			}));
		}
	}
	if ([
		"turn",
		"end",
		"row",
		"recall"
	].includes(t.kind)) for (let e of [...new Set(n.pocket)]) for (let t of Ke(n)) Ge(t.need, e) && r.push(G("store", String(t.oi), {
		row: t.row,
		slot: t.slot,
		resource: e,
		score: 1
	}));
	return r;
}
function Ye(e) {
	let t = e.queue[0];
	return !t || e.phase !== "play" || M(e, t.rid).automa ? [] : [...qe(e, t), ...Je(e, t)];
}
var Xe = /* @__PURE__ */ new Set([
	"turn",
	"pay",
	"resource",
	"harvest",
	"place",
	"track",
	"outpostChoice",
	"outpost",
	"activateOutpost",
	"upgrade",
	"outfitSelect",
	"outfitPlace",
	"recall",
	"row",
	"trade",
	"cloudChoice",
	"keepEncounter",
	"dice",
	"cloudPort",
	"end"
]);
function Ze(e) {
	if (e.phase === "done") return;
	let t = e.queue[0];
	e.phase = t && Xe.has(t.kind) && !M(e, t.rid).automa ? "play" : "settle";
}
function Qe(e, t) {
	let n = M(e, t.rid), r = t.row, i = Number(t.port.slice(1)), a = e.ports[i], o = "cargo", s = _[i % 3];
	H(e, n.rid, s, o), i < 3 && L(n, 1), n.cargo.push(...a.resources), a.resources = [], P(e, ...Array.from({ length: Math.floor(i / 3) }, () => N("roll", n.rid, { port: o })), N("collectionHarvester", n.rid, {
		row: r,
		port: t.port
	}));
}
function $e(e, t) {
	let n = M(e, t.rid), r = Number(t.port.slice(1));
	P(e, ...n.ships[t.row].harvester ? [N("harvest", n.rid, {
		value: _[r < 3 ? (r % 3 + 1) % 3 : r % 3],
		port: "cargo",
		n: +(r >= 6)
	})] : [], N("collectionOutpost", n.rid, {
		row: t.row,
		port: t.port
	}));
}
function et(e, t, n) {
	let r = n.value, i = n.row, a = t.ships[i];
	a.port = r, e.lastPort = r, I(e, t.rid, "deploy", r, i);
	let o = [], s;
	if (r.startsWith("p")) s = [
		N("explore", t.rid, {
			row: i,
			port: r
		}),
		N("collectionCore", t.rid, {
			row: i,
			port: r
		}),
		N("place", t.rid, {
			row: i,
			port: "cargo"
		})
	];
	else if (/^w[csa]$/.test(r)) {
		let n = e.wonderDecks[v.indexOf(r.slice(1))].at(-1);
		o = O[n].cost, s = [N("wonder", t.rid, {
			row: i,
			port: r,
			card: n
		})];
	} else r === "festival" ? (o = [
		"t",
		"t",
		"t",
		"t"
	], s = [N("festival", t.rid, { row: i })]) : r === "market" ? (o = n.n === 0 ? ["*", "*"] : n.n === 1 ? [n.resource, n.resource] : [
		"*",
		"*",
		"*"
	], s = [N("market", t.rid, {
		row: i,
		n: n.n
	})]) : (L(t, -1), o = [r === "guild" ? "y" : r === "workshop" ? "b" : "r"], s = [N("special", t.rid, {
		row: i,
		port: r
	})]);
	P(e, ...o.length ? [N("pay", t.rid, { cost: [...o] })] : [], ...s, N("portExtras", t.rid, {
		row: i,
		port: r
	}), N("end", t.rid));
}
function tt(e, t) {
	let n = M(e, t.rid), r = e.ports.find((e) => e.id === t.port);
	if (r?.fame && (e.fameSupply += r.fame, R(e, n.rid, r.fame), r.fame = 0), r?.resources.length) {
		for (let t of r.resources) n.pocket.push(t), P(e, N("place", n.rid, {
			value: t,
			flag: !0
		}));
		r.resources = [];
	}
	let i = O[Me(n) ?? ""]?.ability;
	i === "marketFame" && t.port === "market" && R(e, n.rid, 2), (i === "guildEncounter" && t.port === "guild" || i === "flagonEncounter" && t.port === "flagon" || i === "workshopEncounter" && t.port === "workshop") && U(e, n.rid);
}
function nt(e, t, n) {
	let r = (t, n) => {
		for (let r of t) {
			let t = e.ports.find((e) => e.id === r), i = Math.min(n, e.fameSupply);
			t.fame += i, e.fameSupply -= i;
		}
	}, i = (t, n, r = 1) => {
		for (let i of t) if (e.ports[i].open) for (let t = 0; t < r && V(e, n); t++) e.supply[_.indexOf(n)]--, e.ports[i].resources.push(n);
	}, a = () => {
		let n = e.players.findIndex((e) => e.rid === t);
		P(e, ...Array.from({ length: e.players.length }, (t, r) => e.players[(n + r) % e.players.length]).filter((e) => !e.automa).map((e) => N("trade", e.rid)));
	};
	n === "L1" && (r(["market"], 2), r([
		"guild",
		"workshop",
		"flagon"
	], 1)), n === "L2" && (r(["wc"], 3), i([
		0,
		3,
		6
	], "b")), n === "L3" && (r([
		"wc",
		"ws",
		"wa"
	], 1), a()), n === "L4" && (r(["wa"], 3), i([
		2,
		5,
		8
	], "y")), n === "L5" && P(e, N("cloudPort", t)), n === "L6" && (r(["ws"], 3), i([
		1,
		4,
		7
	], "r")), n === "L7" && r([
		"wc",
		"ws",
		"wa"
	], 2), n === "L8" && (r(["festival"], 2), a()), n === "L9" && r(["festival", "flagon"], 2), n === "L10" && r([
		"wc",
		"ws",
		"wa"
	], 1), n === "S1" && r(["wc"], 4), n === "S2" && r(["market"], 4), n === "S3" && i([
		0,
		1,
		2
	], "t", 2), n === "S4" && r(["wa"], 4), n === "S5" && r([
		"guild",
		"workshop",
		"flagon"
	], 2), n === "S6" && a(), n === "S7" && r(["ws"], 4);
}
function rt(e, t) {
	let n = M(e, t.rid), r = t.value;
	if (n.automa) {
		R(e, n.rid, 3);
		return;
	}
	[
		"L1",
		"L6",
		"L8"
	].includes(r) && W(e, n.rid, "any"), [
		"L2",
		"L5",
		"S1"
	].includes(r) && P(e, N("drawKeep", n.rid)), [
		"L3",
		"L10",
		"S4",
		"S6"
	].includes(r) && L(n, 3), ["L4", "L7"].includes(r) && R(e, n.rid, 2), r === "S2" && P(e, N("cloudChoice", n.rid, { value: "encounterGrit" })), r === "L9" && P(e, N("cloudChoice", n.rid, { value: "encounterTrack" })), (r === "S3" || r === "S5") && P(e, N("track", n.rid, { n: 2 })), r === "S7" && R(e, n.rid, 3);
}
function it(e, t) {
	let n = M(e, t.rid), r = Number(t.port.slice(1)), i = n.ships[t.row];
	if (!i.crew && !i.harvester) return;
	let a = r % 3, o = Math.floor(r / 3), s = -1;
	if (o === 0 && e.clouds[a][0] ? s = 0 : o === 1 && e.clouds[a][1] ? s = 1 : o === 1 && e.clouds[a][2] && (s = 2), s < 0) return;
	let c = e.clouds[a][s];
	e.clouds[a][s] = null, e.cloud = c, I(e, n.rid, "cloud", c), s === 0 && (e.ports[a + 3].open = !0, e.ports[a + 3].tile = e.outpostDeck.pop() ?? null), s === 2 && (e.ports[a + 6].open = !0, e.ports[a + 6].tile = e.outpostDeck.pop() ?? null), P(e, N("cloudLeft", n.rid, { value: c }), N("cloudRight", n.rid, { value: c }));
}
function at(e, t, n) {
	let r = M(e, t.rid), i = Number(n.value), a = j[i], o = r.encounters.indexOf(i);
	r.encounters.splice(o, 1), e.encounterDiscard.push(i), e.encountersPlayed++, I(e, r.rid, "playEncounter", String(i), n.n);
	let s = n.n === 0 ? a.a : a.b;
	n.n === 1 && L(r, -a.grit), s.startsWith("count") ? R(e, r.rid, B(r, s.slice(5))) : s === "outfit" ? P(e, N("outfitDraw", r.rid)) : W(e, r.rid, s, "pocket");
}
function ot(e) {
	let t = e.players[e.turn];
	if (!t.automa) {
		for (let n of t.pocket) Ne(e, n);
		t.pocket = [];
	}
	if (t.cargo = [], e.lastPort = null, e.encountersPlayed = 0, e.cloud = null, e.dice = [], e.revealed = [], e.automaCard = null, e.turn = (e.turn + 1) % e.players.length, e.turn === 0 && (e.round++, e.endRound !== null && e.round > e.endRound)) {
		e.phase = "done", e.queue = [];
		return;
	}
	let n = e.players[e.turn];
	P(e, N(n.automa ? "automa" : "turn", n.rid));
}
function st(e, t) {
	for (let e of t.ships) e.port = null;
	let n = z(e, t), r = e.automaStart;
	if (R(e, t.rid, r === 0 ? 3 : r === 1 ? 2 : r === 2 ? 3 + 2 * n.h : 3 + n.food), r === 0) {
		H(e, t.rid, _.find((t) => V(e, t)) ?? "y", "pocket");
		for (let n of v) ze(e, t.rid, n);
	}
	if (r === 1) for (let n = 0; n < 3; n++) H(e, t.rid, _.find((t) => V(e, t)) ?? "y", "pocket");
}
function ct(e, t) {
	let n = M(e, t.rid), r = n.ships.filter((e) => e.port !== null).length;
	if (r === 3) {
		P(e, N("finish", n.rid)), st(e, n);
		return;
	}
	e.automaDeck.length || (e.automaDeck = F(e, e.automaDiscard), e.automaDiscard = []);
	let i = e.automaDeck.pop();
	e.automaDiscard.push(i), e.automaCard = i;
	let a = he[i];
	if (r === 2 && a.recall) {
		P(e, N("finish", n.rid)), st(e, n);
		return;
	}
	let o = -1, s = "", c = "c";
	for (let t = 0; t < 3; t++) {
		let r = a.ships[t];
		if (n.ships[r].port !== null) continue;
		if (!a.collection) {
			o = r, c = a.tracks[t], s = `w${c}`;
			break;
		}
		let i = [
			r,
			r + 3,
			r + 6
		].filter((t) => e.ports[t].open && Le(e, t));
		if (i.length) {
			o = r, c = a.tracks[t], s = `p${a.deep ? i.at(-1) : i[0]}`;
			break;
		}
	}
	if (o < 0) {
		P(e, N("finish", n.rid)), st(e, n);
		return;
	}
	n.ships[o].port = s, e.lastPort = s, I(e, n.rid, "deploy", s, o), P(e, ...s.startsWith("p") ? [N("explore", n.rid, {
		row: o,
		port: s
	})] : [], N("automaGain", n.rid, {
		row: o,
		port: s,
		value: c
	}), N("automaBonus", n.rid, {
		row: o,
		port: a.bonus
	}), N("finish", n.rid));
}
function lt(e, t, n) {
	let r = e.ports.find((e) => e.id === n);
	t.pocket.push(...r.resources), r.resources = [], r.fame &&= (e.config.soloLevel !== 0 && R(e, t.rid, r.fame), e.fameSupply += r.fame, 0);
}
function ut(e, t) {
	let n = M(e, t.rid), r = n.ships[t.row], i = t.port, a = t.value;
	if (lt(e, n, i), i.startsWith("p")) {
		let t = r.crew || r.harvester;
		for (let r = 0; r < (t ? 2 : 1); r++) H(e, n.rid, _.find((t) => V(e, t)) ?? "y", "pocket");
		ze(e, n.rid, a, t ? 2 : 1);
	} else if (n.pocket.length < 4) R(e, n.rid, 3), ze(e, n.rid, a, 1 + Number(r.crew) + Number(r.harvester));
	else {
		let t = e.wonderDecks[v.indexOf(a)].pop();
		if (t) {
			for (let t of n.pocket.splice(0, 4)) Ne(e, t);
			n.wonders.push(t), P(e, ...O[t].advance.map((e) => N("advance", n.rid, { value: e === "*" ? a : e }))), Re(e);
		}
	}
}
function dt(t, n) {
	let r = M(t, n.rid);
	switch (n.kind) {
		case "advance":
			Be(t, n);
			break;
		case "finish":
			ot(t);
			break;
		case "effect":
			W(t, n.rid, n.value, n.port ?? "free", n.row);
			break;
		case "startingFame": {
			let e = n.n, i = e === 1 ? r.encounters.length : e === 2 ? r.outposts.length : e === 3 ? r.rows.flat().filter((e) => !e.id.startsWith("base:") && ke(r, e, 0).length === 2).length : e === 4 ? 2 * je(r, "crew") : e === 5 ? B(r, "t") : e === 6 ? 2 * je(r, "harvester") : 2 * z(t, r).h;
			R(t, r.rid, i);
			break;
		}
		case "explore":
			it(t, n);
			break;
		case "cloudLeft":
			rt(t, n);
			break;
		case "cloudRight":
			nt(t, n.rid, n.value);
			break;
		case "drawKeep":
			t.revealed = [];
			for (let e = 0; e < 2; e++) {
				t.encounterDeck.length || (t.encounterDeck = F(t, t.encounterDiscard), t.encounterDiscard = []);
				let e = t.encounterDeck.pop();
				e !== void 0 && t.revealed.push(e);
			}
			t.revealed.length && P(t, N("keepEncounter", r.rid));
			break;
		case "collectionCore":
			Qe(t, n);
			break;
		case "collectionHarvester":
			$e(t, n);
			break;
		case "collectionOutpost":
			r.outposts.includes(Number(n.port.slice(1))) && Ve(t, r.rid, Number(n.port.slice(1)), "cargo");
			break;
		case "cloudPort": {
			let e = he[t.automaCard ?? 0], i = e.ships.findIndex((e) => r.ships[e].port === t.lastPort), a = e.tracks[Math.max(0, i)];
			ft(t, n, G("cloudPort", `w${a}`));
			break;
		}
		case "roll": {
			let i = [
				"y",
				"y",
				"b",
				"b",
				"r",
				"r",
				"t",
				"e"
			][e(t.seed, t.cursor++, 8)];
			t.dice = [i], P(t, N("dice", r.rid, {
				value: i,
				port: n.port
			}));
			break;
		}
		case "wonder":
			P(t, ...r.ships[n.row].crew ? [N("advance", r.rid, { value: v[(v.indexOf(n.port.slice(1)) + 2) % 3] })] : [], N("wonderFame", r.rid, { port: n.port }), N("wonderAcquire", r.rid, {
				port: n.port,
				card: n.card
			}), N("wonderInstant", r.rid, { card: n.card }));
			break;
		case "wonderFame": {
			let e = t.ports.find((e) => e.id === n.port);
			e.fame &&= (t.fameSupply += e.fame, R(t, r.rid, e.fame), 0);
			break;
		}
		case "wonderAcquire": {
			let e = t.wonderDecks[v.indexOf(n.port.slice(1))].pop();
			e && (r.wonders.push(e), I(t, r.rid, "wonder", e), Re(t));
			break;
		}
		case "wonderInstant":
			P(t, ...O[n.card].advance.map((e) => e === "*" ? N("track", r.rid, { n: 1 }) : N("advance", r.rid, { value: e })));
			break;
		case "festival": {
			R(t, r.rid, 9);
			let e = r.ships[n.row];
			P(t, ...v.map((e) => N("advance", r.rid, { value: e })), ...e.harvester ? [N("track", r.rid, { n: 1 })] : []), e.crew && R(t, r.rid, z(t, r).food);
			break;
		}
		case "market": {
			R(t, r.rid, (n.n ?? 0) === 0 ? 2 : n.n === 1 ? 3 : 4);
			let e = r.ships[n.row];
			e.harvester && L(r, 2), e.crew && P(t, N("track", r.rid, { n: 1 }));
			break;
		}
		case "special": {
			let e = r.ships[n.row], i = e.crew, a = e.harvester;
			n.port === "guild" && P(t, N("outfitSelect", r.rid), ...i ? [N("drawEncounter", r.rid)] : []), n.port === "workshop" && P(t, N("upgrade", r.rid, { value: "harvester" }), ...i ? [N("track", r.rid, { n: 1 })] : []), n.port === "flagon" && (P(t, N("upgrade", r.rid, { value: "crew" })), a && L(r, 2));
			break;
		}
		case "drawEncounter":
			U(t, r.rid);
			break;
		case "outfitDraw": {
			let e = Pe(t);
			e && P(t, N("outfitPlace", r.rid, { card: e }));
			break;
		}
		case "portExtras":
			tt(t, n);
			break;
		case "automa":
			ct(t, n);
			break;
		case "automaGain":
			ut(t, n);
			break;
		case "automaBonus": lt(t, r, n.port), n.port === "workshop" && (r.ships[n.row].harvester = !0), n.port === "flagon" && (r.ships[n.row].crew = !0), n.port === "guild" && (t.outfitDiscard.push(...t.market.splice(2)), Fe(t));
	}
}
function ft(t, n, r) {
	let i = M(t, n.rid);
	if (r.kind === "encounter") {
		P(t, n), at(t, n, r);
		return;
	}
	if ([
		"captainSlot",
		"crewSlot",
		"captainWonder",
		"store"
	].includes(r.kind)) {
		if (P(t, n), r.kind === "captainWonder") {
			let e = O[r.value];
			i.captainUsed = !0, L(i, -e.grit), W(t, i.rid, e.ability);
		} else r.kind === "store" ? (i.pocket.splice(i.pocket.indexOf(r.resource), 1), i.rows[r.row][Number(r.value)].tokens[r.slot] = r.resource) : (i.rows[r.row][Number(r.value)].tokens[r.slot] = r.kind === "captainSlot" ? "captain" : "crew", r.kind === "captainSlot" ? i.captainUsed = !0 : i.ships[r.row].crewUsed = !0);
		return;
	}
	switch (r.kind) {
		case "deploy":
			et(t, i, r);
			break;
		case "recall":
			t.recalling = !0, t.recall = i.ships.flatMap((e, t) => e.port === null ? [] : [t]), t.activeRow = -1, P(t, N("recall", i.rid));
			break;
		case "pay":
		case "payPocket": {
			let e = r.kind === "payPocket" ? i.pocket.splice(Number(r.value), 1)[0] : i.rows[r.row][Number(r.value)].tokens[r.slot];
			r.kind === "pay" && (i.rows[r.row][Number(r.value)].tokens[r.slot] = null), Ne(t, e);
			let a = He(n), o = [...n.cost];
			o.splice(o.indexOf(a), 1), o.length && P(t, {
				...n,
				cost: o
			});
			break;
		}
		case "resource":
			H(t, i.rid, r.value, n.port ?? "free");
			break;
		case "harvest":
			r.value === "die" ? P(t, N("roll", i.rid, { port: "cargo" })) : H(t, i.rid, r.value, "cargo");
			break;
		case "directPayment": break;
		case "place": {
			let e = n.port === "cargo", a = e ? i.cargo : i.pocket;
			a.splice(a.indexOf(r.resource), 1), i.rows[r.row][Number(r.value)].tokens[r.slot] = r.resource, e && r.row !== n.row && L(i, -1), e && a.length && P(t, n);
			break;
		}
		case "discard":
			for (let e of i.cargo) t.ports[Number(t.lastPort.slice(1))].resources.push(e);
			i.cargo = [];
			break;
		case "track":
			P(t, N("advance", i.rid, { value: r.value }), ...(n.n ?? 1) > 1 ? [{
				...n,
				n: n.n - 1
			}] : []);
			break;
		case "outpostChoice":
			r.value === "build" ? P(t, N("outpost", i.rid)) : P(t, N("track", i.rid, { n: 1 }));
			break;
		case "outpost":
			i.outposts.push(Number(r.value)), I(t, i.rid, "outpost", `p${r.value}`);
			break;
		case "activateOutpost":
			Ve(t, i.rid, Number(r.value), n.port ?? "free");
			break;
		case "upgrade":
			i.ships[r.row][r.value] = !0, I(t, i.rid, "upgrade", r.value, r.row);
			break;
		case "cycle":
			t.outfitDiscard.push(t.market.pop()), Fe(t), P(t, {
				...n,
				flag: !0
			});
			break;
		case "outfitSelect": {
			let e = t.market.splice(Number(r.value), 1)[0];
			Fe(t), P(t, N("outfitPlace", i.rid, { card: e }));
			break;
		}
		case "outfitPlace": {
			let e = i.rows[r.row], a = e.length;
			e.push({
				id: n.card,
				tokens: A[n.card].slots.map(() => null),
				used: !1
			}), I(t, i.rid, "outfit", n.card, r.row), P(t, N("advance", i.rid, { value: v[r.row] })), a === 2 && L(i, 1);
			break;
		}
		case "recallRow":
			i.ships[r.row].port = null, t.recall = t.recall.filter((e) => e !== r.row), t.activeRow = r.row, I(t, i.rid, "recall", "", r.row), P(t, N("row", i.rid, { row: r.row }), N("recall", i.rid));
			break;
		case "activate": {
			let e = i.rows[r.row][Number(r.value)];
			e.used = !0, P(t, n);
			let a = A[e.id];
			a && L(i, -a.grit), I(t, i.rid, "activate", e.id, r.row), W(t, i.rid, a?.effect ?? "base", "free", r.row);
			break;
		}
		case "endRow":
			t.activeRow = -1;
			break;
		case "endRecall":
			t.recalling = !1, t.activeRow = -1;
			for (let e of i.rows) for (let t of e) t.tokens = t.tokens.map((e) => e === "captain" || e === "crew" ? null : e), t.used = !1;
			i.captainUsed = !1;
			for (let e of i.ships) e.crewUsed = !1;
			P(t, N("end", i.rid));
			break;
		case "captainWonder": break;
		case "trade":
			L(i, -r.n), R(t, i.rid, r.n);
			break;
		case "cloudChoice":
			r.value === "encounter" ? U(t, i.rid) : W(t, i.rid, r.value);
			break;
		case "keepEncounter": {
			let e = Number(r.value);
			i.encounters.push(e), t.encounterDiscard.push(...t.revealed.filter((t) => t !== e)), t.revealed = [];
			break;
		}
		case "reroll": {
			let r = [
				"y",
				"y",
				"b",
				"b",
				"r",
				"r",
				"t",
				"e"
			][e(t.seed, t.cursor++, 8)];
			t.dice = [r], P(t, {
				...n,
				value: r,
				flag: !0
			});
			break;
		}
		case "keepDie":
			n.value === "e" ? U(t, i.rid) : H(t, i.rid, n.value, n.port ?? "free");
			break;
		case "cloudPort": {
			let e = t.ports.find((e) => e.id === r.value), n = Math.min(2, t.fameSupply);
			t.fameSupply -= n, e.fame += n;
			for (let e of [
				0,
				1,
				2
			]) t.ports[e].open && V(t, "t") && (t.supply[3]--, t.ports[e].resources.push("t"));
			break;
		}
		case "finish":
			P(t, N("finish", i.rid));
			break;
		case "skip": if (n.kind === "outfitPlace" && n.card && t.outfitDiscard.push(n.card), n.kind === "place" && n.value) {
			let e = i.pocket.indexOf(n.value);
			e >= 0 && Ne(t, i.pocket.splice(e, 1)[0]);
		}
	}
}
function pt(t, n, r) {
	let i = ve.parse(t), a = {
		seed: r,
		cursor: 0,
		players: [],
		turn: 0,
		round: 1,
		phase: "play",
		queue: [],
		ports: [
			...Array.from({ length: 9 }, (e, t) => `p${t}`),
			"wc",
			"ws",
			"wa",
			"festival",
			"market",
			"guild",
			"workshop",
			"flagon"
		].map((e, t) => ({
			id: e,
			open: t < 3 || t >= 9,
			tile: null,
			resources: [],
			fame: 0
		})),
		supply: [
			20,
			20,
			20,
			20
		],
		fameSupply: 15,
		wonderDecks: [],
		outfitDeck: [],
		outfitDiscard: [],
		market: [],
		encounterDeck: [],
		encounterDiscard: [],
		outpostDeck: [],
		clouds: [],
		recall: [],
		activeRow: -1,
		recalling: !1,
		lastPort: null,
		encountersPlayed: 0,
		endRound: null,
		dice: [],
		revealed: [],
		cloud: null,
		automaDeck: [],
		automaDiscard: [],
		automaCard: null,
		automaStart: 0,
		config: i,
		log: []
	}, o = F(a, Array.from({ length: 7 }, (e, t) => `start${t + 1}`)), s = F(a, [
		0,
		1,
		2,
		3,
		4
	]);
	a.wonderDecks = v.map((e) => F(a, Array.from({ length: 9 }, (t, n) => `${e}${n + 1}`))), a.outfitDeck = F(a, Array.from({ length: 36 }, (e, t) => `o${t + 1}`)), a.encounterDeck = F(a, Array.from({ length: 25 }, (e, t) => t)), a.outpostDeck = F(a, [...fe]);
	let c = F(a, Array.from({ length: 10 }, (e, t) => `L${t + 1}`)), l = F(a, Array.from({ length: 7 }, (e, t) => `S${t + 1}`));
	a.clouds = Array.from({ length: 3 }, () => [
		c.pop(),
		c.pop(),
		l.pop()
	]);
	for (let e = 0; e < 3; e++) a.ports[e].tile = a.outpostDeck.pop();
	Fe(a), a.players = n.map((e, t) => ({
		rid: e,
		mat: s[t],
		ships: Array.from({ length: 3 }, () => ({
			port: null,
			crew: !1,
			harvester: !1,
			crewUsed: !1
		})),
		rows: le[s[t]].map((e, t) => [{
			id: `base:${e}`,
			tokens: [null, _[t]],
			used: !1
		}]),
		grit: 2,
		fame: 0,
		tracks: [
			0,
			0,
			0
		],
		wonders: [o[t]],
		encounters: [],
		outposts: [],
		captainUsed: !1,
		pocket: [],
		cargo: [],
		score: {
			fame: 0,
			heritage: 0,
			tracks: [
				0,
				0,
				0
			],
			automa: 0,
			total: 0
		},
		automa: !1
	}));
	for (let e of a.players) {
		for (let e = 0; e < 3; e++) a.supply[e]--;
		U(a, e.rid);
	}
	if (n.length === 1 && (a.automaStart = i.automaStart < 0 ? e(a.seed, a.cursor++, 4) : i.automaStart, a.players.push({
		rid: "$automa",
		mat: 0,
		ships: Array.from({ length: 3 }, () => ({
			port: null,
			crew: !1,
			harvester: !1,
			crewUsed: !1
		})),
		rows: [],
		grit: 0,
		fame: i.soloLevel >= 3 ? 3 : 0,
		tracks: [
			0,
			0,
			0
		],
		wonders: [],
		encounters: [],
		outposts: [],
		captainUsed: !1,
		pocket: [],
		cargo: [],
		score: {
			fame: 0,
			heritage: 0,
			tracks: [
				0,
				0,
				0
			],
			automa: 0,
			total: 0
		},
		automa: !0
	}), a.automaDeck = F(a, Array.from({ length: 12 }, (e, t) => t)), i.soloLevel >= 4)) {
		let e = F(a, [
			0,
			1,
			2
		]);
		for (let t of e.slice(0, i.soloLevel >= 5 ? 2 : 1)) a.players[1].ships[t].crew = !0;
	}
	return a.queue = [N("turn", a.players[0].rid)], { state: a };
}
function mt(e, t) {
	let n = z(e, t), r = 0;
	if (n.h) {
		let t = e.players.filter((t) => z(e, t).h > n.h).length, i = e.players.filter((t) => z(e, t).h === n.h).length;
		r = Math.floor(Array.from({ length: i }, (e, n) => [
			16,
			10,
			6
		][t + n] ?? 0).reduce((e, t) => e + t, 0) / i);
	}
	let i = v.map((e, r) => (t.tracks[r] >= 12 ? 4 : t.tracks[r] >= 8 ? 3 : t.tracks[r] >= 4 ? 2 : 1) * n[[
		"s",
		"a",
		"c"
	][r]]), a = t.automa ? 2 * n.food + t.pocket.length : 0;
	return {
		fame: t.fame,
		heritage: r,
		tracks: i,
		automa: a,
		total: t.fame + r + i.reduce((e, t) => e + t, 0) + a
	};
}
function ht(e, t, n) {
	if (e.phase === "done") return { code: "games.braidedskies.errorFinished" };
	if (t.type === "tick") {
		if (e.phase !== "settle") return { code: "games.braidedskies.errorTurn" };
		let t = structuredClone(e), n = t.queue.shift();
		return n && dt(t, n), Ze(t), {
			state: t,
			fx: n ? ge(e, t, n) : []
		};
	}
	let r = e.queue[0];
	if (e.phase !== "play" || !r || r.rid !== n.by) return { code: "games.braidedskies.errorTurn" };
	let i = Ye(e).find((e) => e.id === t.id);
	if (!i) return { code: "games.braidedskies.errorChoice" };
	let a = structuredClone(e);
	return a.queue.shift(), ft(a, r, i), Ze(a), {
		state: a,
		fx: ge(e, a, r, i)
	};
}
function gt(e, t) {
	let n = e.queue[0];
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turn].rid,
			actor: n?.rid ?? e.players[e.turn].rid,
			round: e.round,
			prompt: n?.kind ?? "done",
			source: n?.card ?? n?.source ?? "",
			promptValue: n?.value ?? "",
			promptRow: n?.row ?? -1,
			promptPort: n?.port ?? "",
			payment: n?.cost ?? [],
			players: e.players.map((t) => ({
				...t,
				score: mt(e, t)
			})),
			ports: e.ports,
			market: e.market,
			wonderTops: e.wonderDecks.map((e) => e.at(-1) ?? null),
			supply: e.supply,
			fameSupply: e.fameSupply,
			outfitCount: e.outfitDeck.length,
			encounterCount: e.encounterDeck.length,
			recall: e.recall,
			activeRow: e.activeRow,
			lastPort: e.lastPort,
			encountersPlayed: e.encountersPlayed,
			endRound: e.endRound,
			dice: e.dice,
			revealed: e.revealed,
			cloud: e.cloud,
			automaCard: e.automaCard,
			automaStart: e.automaStart,
			config: e.config,
			log: e.log.slice(-100)
		},
		private: { choices: n?.rid === t ? Ye(e) : [] }
	};
}
function _t(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t.rid, mt(e, t).total])), n = (e) => e.automa ? e.pocket.length : Ae(e).filter((e) => e !== "t").length, r = (e, r) => t[r.rid] - t[e.rid] || n(r) - n(e) || r.wonders.length + (r.automa ? 2 : 0) - (e.wonders.length + (e.automa ? 2 : 0)) || r.grit - e.grit, i = [...e.players].sort(r), a = i.filter((e) => r(i[0], e) === 0).map((e) => e.rid), o = e.players.filter((e) => !e.automa).sort(r).map((e) => e.rid);
	return {
		phase: "done",
		winner: a.filter((e) => e !== "$automa"),
		ranking: o,
		scores: Object.fromEntries(o.map((e) => [e, t[e]]))
	};
}
var vt = {
	meta: _e,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ye,
		publicView: De,
		privateView: Oe,
		config: ve
	},
	setup: pt,
	reduce: ht,
	viewFor: gt,
	status: _t,
	nextTickIn: (e) => e.phase === "settle" ? 440 : null
}, K = (e) => c(`games/braidedskies/art/${e}.svg`);
function q({ id: e, label: t = "", className: n = "" }) {
	return /* @__PURE__ */ d("img", {
		className: `bs-icon ${n}`,
		src: c(`games/braidedskies/icons/${e === "*" ? "any" : e}.svg`),
		alt: t,
		title: t,
		draggable: !1
	});
}
function J({ name: e, className: t = "", children: n, style: r }) {
	let { ref: i, hidden: a } = l(e);
	return /* @__PURE__ */ d("div", {
		ref: i,
		className: t,
		style: {
			...r,
			visibility: a ? "hidden" : void 0
		},
		children: n
	});
}
function yt() {
	return /* @__PURE__ */ d("svg", {
		className: "bs-ants",
		"aria-hidden": "true",
		children: /* @__PURE__ */ d("rect", {
			x: "2",
			y: "2",
			rx: "8"
		})
	});
}
function Y({ row: e }) {
	return /* @__PURE__ */ d(q, {
		id: `ship${e}`,
		className: "bs-ship-art"
	});
}
//#endregion
//#region src/games/braidedskies/locales/zh.ts
var bt = {
	trackPosition: "第{{n}}格",
	dice: "采集骰",
	details: "详情",
	discardPile: "弃牌堆",
	ready: "可用",
	installShort: "安装设备",
	takeShort: "选取设备",
	sail: "派遣飞船",
	close: "关闭",
	costShort: "费用",
	instantShort: "立即",
	inactive: "能力已休眠",
	activateShort: "激活设备",
	wonderPorts: "奇观港口",
	ledger: "航行账簿",
	viewBoard: "回看最终局面",
	viewLedger: "查看航行账簿",
	winner: "胜者：{{name}}",
	tieInfo: "同分时依次比较汲石、奇观数量、毅力。",
	confirmAgain: "确认再来一局？",
	confirmLeave: "确认返回大厅？",
	confirm: "确认",
	cancel: "取消",
	waitingHost: "等待主机开始下一局。",
	total: "总声望",
	name: "交织苍穹",
	desc: "驾驶飞船深入云海，采集汲石，建设旅游公司并发现北方奇观。",
	rules: "目标与准备：\n经营飞船旅游公司，获得最多声望。每人拥有三艘飞船、一张随机玩家板、一张起始奇观、2点毅力、三色汲石各1枚及1张公开遭遇牌。三种颜色的奇观牌各有9张，另有36张设备牌和25张遭遇牌。云层与前哨位置随机设置。中文名称采用社区译名《交织苍穹》，卡牌名称为本地译名；规则依据官方2026年基础版r12与单人规则r5。\n回合：\n轮到你时，派遣一艘仍在玩家板上的飞船，或回收所有已派遣飞船。三艘均在外时必须回收。上层采集港与所有奇观、专门港口不限飞船数量；中层及深层每个采集港只容一艘。采集港只接收旗帜匹配的飞船，其他港口接收任意飞船。\n采集与探索：\n派遣到采集港时，若飞船已有船员或采集器，移除该港口正下方相邻的一块云板并执行事件；新出现的前哨位置随机补板。上层港只能揭开相邻中层，中层港可依次移除盖住深层的大小云板。然后依次获得港口本身与遗留资源、采集器奖励、自有前哨奖励。资源全部放入该飞船货舱；从货舱转移到同行设备免费，跨行每枚支付1点毅力。不能覆盖已有物资或船员。未装入设备的货物全部留在出发港口，供后续来访者收取。资源供应有限，每种20枚。\n奇观港：\n支付牌面费用，资源可从玩家板任意位置取用。有船员的飞船先获得港口的跨轨奖励，再领取遗留声望，取得顶牌并执行即时推进。将新奇观放在行程末端，起始奇观与最新奇观的能力有效，其余只保留顶部符号。只有标有船长动作的能力需要在回收时使用船长；持续能力始终生效。每次采集骰可按有效重掷能力重掷一次。\n专门港口：\n· 汤汤节支付4名游客，获得9点声望，三条轨道各推进1格；采集器额外任选轨道推进1格，船员按美食符号数获得声望。\n· 地下市场支付任意2份资源、同类2份资源或任意3份资源，分别获得2、3、4点声望；采集器获得2点毅力，船员任选轨道推进1格。\n· 自由飞行者公会支付1点毅力及1枚黄色汲石，取得一张市场设备；选牌前，可以弃置市场第4张设备牌，并补充1张新牌；每次到访最多执行1次，船员额外抽取1张遭遇牌。\n· 雷霆工坊支付1点毅力及1枚蓝色汲石，为任意一艘飞船安装采集器；来访飞船原有船员时任选轨道推进1格。\n· 破旗酒馆支付1点毅力及1枚红色汲石，安装船员；来访飞船原有采集器时获得2点毅力。\n新装升级不追溯本次来访奖励。\n设备与回收：\n新增设备放在任意一行最左空位，获得被覆盖位置的轨道推进，放入该行第3张设备时再获得1点毅力。每行最多3张，含印刷设备。回收时自行决定飞船次序；每回收一艘，任意次序激活该行已填满槽位的设备，每张至多一次，并支付相应毅力。激活时资源不消耗。回收期间新获得的资源必须立即放入任意空槽，跨行免费，无法放置则不获得。每名船员在本行空槽代替一个资源或船员要求，船长可放在任意行空槽或一个有效奇观动作上；每枚每次回收只能用一次。全部回收结束后取回船长与船员。毅力上限为8点。\n遭遇与前哨：\n遭遇牌全部公开，本人回合任意决策时可打出，包括刚获得的牌，每回合最多2张。选择A或B，满足B的港口条件并支付毅力后获得其奖励；资源立即用于当前付款或放入空槽。建造前哨时选择一个已揭开的采集港，每人每港最多一个，共6个；多人可共建。前哨奖励按牌面获得资源、遭遇，或按行程符号、船员数获得声望。\n奇观轨道：\n到达奖励格立即获得奖励。\n· 文化：到达第3格时，抽取一张设备牌；到达第4及第9格时，各抽取一张遭遇牌；到达第6格时，获得4点声望，若文化、风景、冒险和美食符号各至少有一个，再获得5点声望；到达第11格时，获得6点声望，再按美食符号数量获得等量声望。\n· 风景：到达第3格时，安装一个采集器；到达第4及第9格时，各建造一个前哨；到达第6格时，获得4点声望，再按船员与采集器的总数量获得等量声望；到达第11格时，获得6点声望，再按已建前哨数量获得等量声望。\n· 冒险：到达第1及第4格时，各获得1点毅力；到达第3格时，安装一名船员；到达第6格时，获得6点声望，若此时至少有6点毅力，再获得5点声望；到达第9格时，获得2点毅力；到达第11格时，获得6点声望，若已收集三种普通奇观，再获得5点声望。\n三条轨道的第13格各提供4点声望；到达顶端后不能继续推进。\n结束与计分：\n任一玩家达到60点声望、行程达到7张奇观，或三条轨道均有人到达第11格，触发游戏结束。完成当前轮后再完整进行一轮。遗产符号数量前三名获得16、10、6点声望；并列时相关名次奖励相加平分，向下取整，没有遗产不得分。文化轨按风景符号、风景轨按冒险符号、冒险轨按文化符号计分：轨道第0至3格每枚1分，第4至7格2分，第8至11格3分，第12至13格4分。合计游戏中声望及终局奖励。平分依次比较剩余汲石数量（不含游客）、奇观数量、毅力，仍同则并列。\n单人Automa：\n一人游戏中，加入官方自动对手Automa，由玩家先行动，随后双方交替行动。Automa拥有独立的起始奇观和1张固定奇观，并使用12张行动牌决定飞船、港口、轨道与额外奖励。\n· Automa通常不须支付费用。采集时，没有升级则获得1份资源并推进1格轨道；已有任一升级则获得2份资源并推进2格轨道。\n· 到访奇观港时，若资源不足4枚，则获得3点声望并推进1格轨道；每名船员和每个采集器各使其额外推进1格。若资源至少有4枚，则支付4枚资源，取得奇观并执行即时推进。\n· Automa不领取轨道上的即时奖励。她会收取到访港口和行动牌指定额外港口上的遗留资源与声望，并可以免费安装对应升级。到访自由飞行者公会时，弃置市场第3张和第4张设备牌。\n· Automa探索时，忽略云板左侧的内容，改为获得3点声望；她不参与“所有玩家可以”执行的交换。\n· 三艘飞船均已部署时，Automa必须回收；行动牌也可能要求她回收两艘飞船。回收时，执行起始奇观的回收能力。\n· 终局按通常规则计分，此外，每个美食符号获得2分，每枚剩余资源获得1分。\n· 最容易难度中，Automa不获得遗留声望。较易难度中，她的固定奇观只有遗产符号。普通及以上难度使用五种符号各1个的工厂游览。随着难度提高，依次增加3点起始声望、1名起始船员或2名起始船员。\n· 平分时，Automa在第一项比较中计入全部资源，毅力视为0点。",
	errorFinished: "本局已经结束。",
	errorTurn: "请等待轮到你行动。",
	errorChoice: "此选择已不可用，请重新选择。",
	round: "第{{n}}轮",
	lastRound: "最后一轮：第{{n}}轮",
	waiting: "等待{{name}}行动",
	resolving: "正在结算",
	choose: "请选择行动",
	done: "本局结束",
	automa: "Automa",
	board: "云海与港口",
	company: "旅游公司",
	itinerary: "奇观行程",
	encounters: "遭遇牌",
	market: "设备市场",
	supply: "公共供应",
	fame: "声望",
	grit: "毅力",
	score: "当前总分",
	heritage: "遗产奖励",
	trackScore: "轨道奖励",
	automaScore: "Automa额外奖励",
	ship: "飞船",
	crew: "船员",
	harvester: "采集器",
	captain: "船长",
	any: "任意资源",
	empty: "空槽",
	filled: "已有{{name}}",
	slot: "第{{n}}槽",
	outfit: "设备",
	used: "已激活",
	home: "在公司",
	deployed: "停靠{{name}}",
	unexplored: "尚未探索",
	blocked: "已被占用",
	unlimited: "不限数量",
	single: "只容一艘",
	outpost: "前哨",
	none: "无",
	deploy: "派遣{{ship}}前往{{port}}",
	recall: "回收所有已派遣飞船",
	recallRow: "回收{{ship}}",
	pay: "支付{{resource}}（{{ship}} · {{card}} · 第{{n}}槽）",
	payPocket: "支付刚获得的{{resource}}",
	place: "放入{{ship}} · {{card}} · 第{{n}}槽：{{resource}}",
	resource: "获得{{resource}}",
	track: "在{{track}}轨道推进1格",
	build: "在{{port}}建造前哨",
	activateOutpost: "发动{{port}}的前哨",
	upgrade: "为{{ship}}安装{{name}}",
	selectOutfit: "取得{{card}}",
	install: "将{{card}}放入{{ship}}行",
	activate: "激活{{ship}}行的{{card}}",
	captainSlot: "将船长放入{{ship}} · {{card}} · 第{{n}}槽",
	crewSlot: "将船员放入{{ship}} · {{card}} · 第{{n}}槽",
	captainWonder: "派船长访问{{card}}",
	encounter: "打出{{card}} · {{option}}：{{effect}}",
	costGrit: "支付{{n}}毅力",
	requiresPort: "本回合已到访{{port}}",
	skip: "放弃此项",
	cycle: "循环市场第4张",
	endRow: "结束本行激活",
	endRecall: "完成回收",
	discard: "将剩余货物留在港口",
	finish: "结束回合",
	trade: "支付{{n}}毅力，获得{{n}}声望",
	keepDie: "接受骰子结果：{{name}}",
	reroll: "重掷这枚骰子",
	roll: "掷一枚采集骰",
	directPayment: "将这份资源用于紧接着的付款",
	keepEncounter: "保留{{card}}",
	cloudPort: "向{{port}}添加2枚声望",
	promptTurn: "选择飞船与目的港，或回收飞船",
	promptPay: "逐枚选择要支付的资源",
	promptPlace: "选择资源的设备槽位",
	promptResource: "选择要获得的资源",
	promptHarvest: "选择采集器奖励",
	promptTrack: "选择要推进的轨道",
	promptOutpost: "选择前哨位置",
	promptOutpostChoice: "建造前哨或推进轨道",
	promptUpgrade: "选择要升级的飞船",
	promptOutfitSelect: "选择一张市场设备",
	promptOutfitPlace: "选择设备所在行",
	promptRecall: "选择下一艘要回收的飞船",
	promptRow: "激活本行设备；船长与船员可帮助填槽",
	promptTrade: "选择要兑换的毅力数量",
	promptCloudChoice: "选择云事件奖励",
	promptKeepEncounter: "查看两张遭遇并保留一张",
	promptDice: "确认采集骰结果",
	promptCloudPort: "选择添加声望的奇观港",
	promptEnd: "可打出遭遇牌，或结束回合",
	effectStone: "获得1枚任意汲石，并立即放入玩家板。",
	effectResource: "获得1份任意资源，并立即放入玩家板。",
	effectTourist: "获得1名游客。",
	effectGrit2: "获得2点毅力。",
	effectGrit3: "获得3点毅力。",
	effectFame3: "获得3声望。",
	effectAny: "任选奇观轨道推进1格。",
	effectAny2: "任选奇观轨道合计推进2格。",
	effectBuild: "建造1个前哨。",
	effectOutpostChoice: "建造1个前哨，或任选奇观轨道推进1格。",
	effectOutpostFame: "每个已建前哨获得1声望。",
	effectOutpostActivate: "发动任意一个自有前哨。",
	effectFoodFame: "每个美食符号获得1声望。",
	effectTrade: "可支付任意数量毅力，每点获得1声望。",
	effectReroll: "每枚采集骰可重掷一次。",
	effectGuildEncounter: "派遣至自由飞行者公会后抽1张遭遇。",
	effectFlagonEncounter: "派遣至破旗酒馆后抽1张遭遇。",
	effectWorkshopEncounter: "派遣至雷霆工坊后抽1张遭遇。",
	effectMarketFame: "派遣至地下市场后获得2声望。",
	effectOutfit: "从牌堆抽取并安装1张设备。",
	effectCount: "每枚剩余{{resource}}获得1声望。",
	effectAdvance: "在{{track}}轨道推进1格。",
	start1: "冒险轨道推进1格，每张未打出的遭遇牌获得1声望。",
	start2: "冒险轨道推进1格，每个已建前哨获得1声望。",
	start3: "文化轨道推进1格，每张双槽设备牌获得1声望。",
	start4: "文化轨道推进1格，每名船员获得2声望。",
	start5: "风景轨道推进1格，每名游客获得1声望。",
	start6: "风景轨道推进1格，每个采集器获得2声望。",
	start7: "任选轨道推进1格，每个遗产符号获得2声望。",
	instant: "获得后立即：{{value}}",
	cost: "费用：{{value}}",
	captainAction: "船长动作",
	passive: "持续能力",
	symbols: "行程符号",
	remaining: "尚需支付：{{value}}",
	cargo: "货舱：{{value}}",
	finalBreakdown: "声望{{fame}}，遗产{{heritage}}，轨道{{tracks}}，额外{{automa}}",
	portTop: "获得1枚{{resource}}与1点毅力；采集器：{{bonus}}或掷1枚采集骰。",
	portMiddle: "获得1枚{{resource}}并掷1枚采集骰；采集器：{{resource}}或掷1枚采集骰。",
	portDeep: "获得1枚{{resource}}并掷2枚采集骰；采集器：{{resource}}或1名游客。",
	wonderPort: "支付顶牌费用并取得奇观；船员：{{track}}推进1格。",
	festivalPort: "支付4名游客，获得9声望，三轨各推进1格；采集器：任意轨道推进1格；船员：每个美食符号1声望。",
	marketPort: "支付任意2份、同类2份或任意3份资源，获得2、3或4声望；采集器：2毅力；船员：任意轨道推进1格。",
	guildPort: "支付1毅力及1黄色汲石，取得市场设备；船员：抽1遭遇。",
	workshopPort: "支付1毅力及1蓝色汲石，安装采集器；船员：任意轨道推进1格。",
	flagonPort: "支付1毅力及1红色汲石，安装船员；采集器：2毅力。",
	outpostSymbols: "每个{{name}}符号获得1声望。",
	outpostCrew: "每名船员获得1声望。",
	outpostEncounter: "抽1张遭遇。",
	cloud: "云事件{{id}}",
	cloudReward: "探索奖励",
	cloudRight: "公共变化",
	cloudDrawKeep: "抽2张遭遇，保留1张。",
	cloudEncounterGrit: "获得1张遭遇或2点毅力。",
	cloudEncounterTrack: "获得1张遭遇或任选轨道推进1格。",
	cloudTwoFame: "获得2声望。",
	cloudThreeFame: "获得3声望。",
	cloudPublicFame: "在{{ports}}各添加{{n}}枚声望。",
	cloudPublicResource: "在已揭开的{{ports}}各添加{{n}}份{{resource}}。",
	cloudPublicTrade: "所有玩家均可按1点毅力兑换1声望。",
	log: "行动记录",
	logDeploy: "{{name}}派遣{{ship}}前往{{port}}",
	logRecall: "{{name}}回收{{ship}}",
	logFame: "{{name}}获得{{n}}声望",
	logAdvance: "{{name}}的{{track}}轨道到达第{{n}}格",
	logWonder: "{{name}}取得{{card}}",
	logOutfit: "{{name}}在{{ship}}行安装{{card}}",
	logActivate: "{{name}}激活{{card}}",
	logOutpost: "{{name}}在{{port}}建造前哨",
	logUpgrade: "{{name}}为{{ship}}安装{{value}}",
	logEncounter: "{{name}}抽取{{n}}张遭遇",
	logPlayEncounter: "{{name}}打出{{card}}的{{option}}项",
	logCloud: "{{name}}揭开{{id}}",
	optionsSolo: "单人Automa难度",
	level0: "最容易",
	level1: "较易",
	level2: "普通",
	level3: "困难",
	level4: "更困难",
	level5: "最困难",
	optionsStart: "Automa起始奇观",
	random: "随机",
	soloOnly: "这些选项仅用于一名玩家的官方Automa模式。",
	automaFactory: "自动机工厂游览",
	automaWorkshop: "自动机工坊参观",
	automaTurn: "行动卡{{n}}",
	automaRecall1: "回收：获得3声望、1份资源，三轨各推进1格。",
	automaRecall2: "回收：获得2声望与3份资源。",
	automaRecall3: "回收：获得3声望，每个遗产符号额外2声望。",
	automaRecall4: "回收：获得3声望，每个美食符号额外1声望。",
	help: "卡牌与轨道说明",
	trackInfo: "文化按风景、风景按冒险、冒险按文化符号计分。第4、8、12格提高乘数，第11格触发结束条件。",
	availableActions: "当前可选行动",
	otherActions: "船长、船员与遭遇",
	inspect: "查看公司",
	yourCompany: "你的公司"
}, xt = Object.fromEntries(Object.keys(bt).map((e) => [e, `games.braidedskies.${e}`])), St = {
	stone: "effectStone",
	resource: "effectResource",
	tourist: "effectTourist",
	grit2: "effectGrit2",
	grit3: "effectGrit3",
	fame3: "effectFame3",
	any: "effectAny",
	any2: "effectAny2",
	build: "effectBuild",
	outpostChoice: "effectOutpostChoice",
	outpostFame: "effectOutpostFame",
	outpostTypes: "effectOutpostFame",
	outpostActivate: "effectOutpostActivate",
	foodFame: "effectFoodFame",
	trade: "effectTrade",
	reroll: "effectReroll",
	guildEncounter: "effectGuildEncounter",
	flagonEncounter: "effectFlagonEncounter",
	workshopEncounter: "effectWorkshopEncounter",
	marketFame: "effectMarketFame",
	outfit: "effectOutfit",
	start1: "start1",
	start2: "start2",
	start3: "start3",
	start4: "start4",
	start5: "start5",
	start6: "start6",
	start7: "start7"
}, Ct = {
	turn: "promptTurn",
	pay: "promptPay",
	place: "promptPlace",
	resource: "promptResource",
	harvest: "promptHarvest",
	track: "promptTrack",
	outpost: "promptOutpost",
	activateOutpost: "promptOutpost",
	outpostChoice: "promptOutpostChoice",
	upgrade: "promptUpgrade",
	outfitSelect: "promptOutfitSelect",
	outfitPlace: "promptOutfitPlace",
	recall: "promptRecall",
	row: "promptRow",
	trade: "promptTrade",
	cloudChoice: "promptCloudChoice",
	keepEncounter: "promptKeepEncounter",
	dice: "promptDice",
	cloudPort: "promptCloudPort",
	end: "promptEnd"
};
function wt() {
	let e = ee(), t = p((e) => e.locale) === "zh" ? 0 : 1, n = (t, n) => e(xt[t], n), r = (e) => y[e]?.[t] ?? n(e === "*" || e === "any" ? "any" : e === "captain" ? "captain" : e === "crew" ? "crew" : "empty"), i = (e) => b[e]?.[t] ?? n("choose"), a = (e) => x[e]?.[t] ?? r(e), o = (e) => S[e]?.[t] ?? n("ship"), s = (e) => de[e]?.[t] ?? n("none"), c = (e) => O[e]?.name[t] ?? A[e]?.name[t] ?? ce[e.slice(5)]?.[t] ?? (e.startsWith("e") ? ue[Number(e.slice(1)) - 1]?.[t] : void 0) ?? n("outfit"), l = (e) => {
		let t = St[e];
		return t ? n(t) : e.startsWith("count") ? n("effectCount", { resource: r(e.slice(5)) }) : _.includes(e) ? n("resource", { resource: r(e) }) : /^[csa]+$/.test(e) ? e.split("").map((e) => n("effectAdvance", { track: i(e) })).join(" ") : n("none");
	};
	return {
		text: n,
		lang: t,
		resource: r,
		track: i,
		symbol: a,
		ship: o,
		port: s,
		card: c,
		effect: l,
		outpost: (e) => e === "t" ? n("effectTourist") : e === "crew" ? n("outpostCrew") : e === "encounter" ? n("outpostEncounter") : n("outpostSymbols", { name: a(e) }),
		portEffect: (e) => {
			if (e.startsWith("p")) {
				let t = Number(e.slice(1)), i = r(_[t % 3]);
				return n(t < 3 ? "portTop" : t < 6 ? "portMiddle" : "portDeep", {
					resource: i,
					bonus: r(_[(t % 3 + 1) % 3])
				});
			}
			return /^w[csa]$/.test(e) ? n("wonderPort", { track: i({
				wc: "a",
				ws: "c",
				wa: "s"
			}[e]) }) : n({
				festival: "festivalPort",
				market: "marketPort",
				guild: "guildPort",
				workshop: "workshopPort",
				flagon: "flagonPort"
			}[e]);
		},
		label: (e, t) => {
			let a = e.row ?? 0, u = {
				ship: o(a),
				card: c(e.card ?? t.rows[a]?.[Number(e.value)]?.id ?? ""),
				port: s(e.value),
				resource: r(e.resource ?? e.value),
				n: (e.slot ?? 0) + 1,
				name: n(e.value === "crew" ? "crew" : "harvester"),
				track: i(e.value)
			};
			if (e.kind === "deploy") return n("deploy", {
				...u,
				port: s(e.value)
			}) + (e.value === "market" ? ` · ${e.n === 0 ? "2 → 2" : e.n === 1 ? `${r(e.resource)} × 2 → 3` : "3 → 4"}` : "");
			if (e.kind === "encounter") {
				let t = j[Number(e.value)], r = e.n ? t.b : t.a;
				return [
					n("encounter", {
						card: c(e.card),
						option: e.n ? "B" : "A",
						effect: l(r)
					}),
					e.n && t.grit ? n("costGrit", { n: t.grit }) : "",
					e.n && t.port ? n("requiresPort", { port: s(t.port) }) : ""
				].filter(Boolean).join(" · ");
			}
			return e.kind === "payPocket" ? n("payPocket", u) : e.kind === "store" ? n("place", u) : [
				"pay",
				"place",
				"captainSlot",
				"crewSlot"
			].includes(e.kind) ? n(e.kind, u) : e.kind === "recallRow" ? n("recallRow", u) : e.kind === "resource" ? n("resource", u) : e.kind === "harvest" ? e.value === "die" ? n("roll") : n("resource", u) : e.kind === "track" ? n("track", u) : e.kind === "outpostChoice" ? l(e.value === "build" ? "build" : "any") : e.kind === "outpost" || e.kind === "activateOutpost" ? n(e.kind === "outpost" ? "build" : "activateOutpost", { port: s(`p${e.value}`) }) : e.kind === "upgrade" ? n("upgrade", u) : e.kind === "outfitSelect" ? n("selectOutfit", u) : e.kind === "outfitPlace" ? n("install", u) : e.kind === "activate" ? n("activate", u) : e.kind === "captainWonder" ? n("captainWonder", u) : e.kind === "trade" ? n("trade", { n: e.n }) : e.kind === "cloudChoice" ? e.value === "encounter" ? n("outpostEncounter") : l(e.value) : e.kind === "keepEncounter" ? n("keepEncounter", u) : e.kind === "keepDie" ? n("keepDie", { name: e.value === "e" ? n("outpostEncounter") : r(e.value) }) : e.kind === "cloudPort" ? n("cloudPort", u) : n(e.kind);
		},
		prompt: (e) => e.phase === "settle" ? n("resolving") : e.phase === "done" ? n("done") : n(Ct[e.prompt] ?? "choose"),
		cloud: (e) => {
			let t = [
				"L1",
				"L6",
				"L8"
			].includes(e) ? l("any") : [
				"L2",
				"L5",
				"S1"
			].includes(e) ? n("cloudDrawKeep") : [
				"L3",
				"L10",
				"S4",
				"S6"
			].includes(e) ? l("grit3") : ["L4", "L7"].includes(e) ? n("cloudTwoFame") : e === "S2" ? n("cloudEncounterGrit") : ["S3", "S5"].includes(e) ? l("any2") : ["S7"].includes(e) ? n("cloudThreeFame") : n("cloudEncounterTrack"), i = (e, t) => n("cloudPublicFame", {
				ports: e.map(s).join(" / "),
				n: t
			}), a = (e, t, i = 1) => n("cloudPublicResource", {
				ports: e.map(s).join(" / "),
				resource: r(t),
				n: i
			}), o = n("cloudPublicTrade");
			return {
				left: t,
				right: {
					L1: i(["market"], 2) + " " + i([
						"guild",
						"workshop",
						"flagon"
					], 1),
					L2: i(["wc"], 3) + " " + a([
						"p0",
						"p3",
						"p6"
					], "b"),
					L3: i([
						"wc",
						"ws",
						"wa"
					], 1) + " " + o,
					L4: i(["wa"], 3) + " " + a([
						"p2",
						"p5",
						"p8"
					], "y"),
					L5: n("promptCloudPort") + " " + a([
						"p0",
						"p1",
						"p2"
					], "t"),
					L6: i(["ws"], 3) + " " + a([
						"p1",
						"p4",
						"p7"
					], "r"),
					L7: i([
						"wc",
						"ws",
						"wa"
					], 2),
					L8: i(["festival"], 2) + " " + o,
					L9: i(["festival", "flagon"], 2),
					L10: i([
						"wc",
						"ws",
						"wa"
					], 1),
					S1: i(["wc"], 4),
					S2: i(["market"], 4),
					S3: a([
						"p0",
						"p1",
						"p2"
					], "t", 2),
					S4: i(["wa"], 4),
					S5: i([
						"guild",
						"workshop",
						"flagon"
					], 2),
					S6: o,
					S7: i(["ws"], 4)
				}[e]
			};
		},
		entry: (e, t) => {
			let r = {
				name: t(e.rid),
				n: e.n ?? 0,
				ship: o(e.n ?? 0),
				port: s(e.value),
				card: c(e.value),
				track: i(e.value),
				value: e.value === "crew" ? n("crew") : n("harvester"),
				option: e.n ? "B" : "A",
				id: e.value
			};
			return n({
				deploy: "logDeploy",
				recall: "logRecall",
				fame: "logFame",
				advance: "logAdvance",
				wonder: "logWonder",
				outfit: "logOutfit",
				activate: "logActivate",
				outpost: "logOutpost",
				upgrade: "logUpgrade",
				encounter: "logEncounter",
				playEncounter: "logPlayEncounter",
				cloud: "logCloud"
			}[e.kind], {
				...r,
				card: c(e.kind === "playEncounter" ? `e${Number(e.value) + 1}` : e.value)
			});
		},
		automaName: (e) => pe[e][t]
	};
}
//#endregion
//#region src/games/braidedskies/guide.tsx
function Tt() {
	let e = wt();
	return /* @__PURE__ */ d("article", {
		className: "bs-guide",
		children: /* @__PURE__ */ f("div", {
			className: "bs-guide-legend",
			children: [[
				"y",
				"b",
				"r",
				"t",
				"c",
				"s",
				"a",
				"h",
				"food"
			].map((t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(q, { id: t }), e.symbol(t)] }, t)), [
				"captain",
				"crew",
				"harvester",
				"grit",
				"outpost"
			].map((t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(q, { id: t }), e.text(t)] }, t))]
		})
	});
}
//#endregion
//#region src/games/braidedskies/view-player.tsx
var Et = /* @__PURE__ */ new Set([
	"finish",
	"recall",
	"endRow",
	"endRecall",
	"discard",
	"skip"
]), Dt = /* @__PURE__ */ new Set([
	...Et,
	"deploy",
	"recallRow",
	"pay",
	"place",
	"store",
	"captainSlot",
	"crewSlot",
	"captainWonder",
	"outfitSelect",
	"outfitPlace",
	"upgrade",
	"activate",
	"encounter",
	"keepEncounter",
	"outpost",
	"activateOutpost",
	"cloudPort",
	"track",
	"cycle"
]), Ot = /* @__PURE__ */ new Set([
	"pay",
	"place",
	"recall",
	"row",
	"upgrade",
	"outfitPlace"
]);
function kt(e) {
	let t = e.public, n = e.private, r = wt(), [c, l] = i(e.myRid), [p, ee] = i(0), [m, te] = i(null), [h, g] = i(null), y = t.players.find((t) => t.rid === e.myRid) ?? t.players[0], b = t.players.find((e) => e.rid === c) ?? y, x = t.players.find((e) => e.rid === t.actor) ?? y, S = n?.choices ?? [], C = t.actor === e.myRid && t.phase === "play", w = y.ships[p]?.port === null ? p : y.ships.findIndex((e) => e.port === null), ne = `${t.actor}/${t.prompt}/${t.source}/${t.promptRow}`, re = Ot.has(t.prompt) ? "company" : t.prompt === "outfitSelect" ? "market" : t.prompt === "keepEncounter" || t.prompt === "cloudPort" ? "itinerary" : "board", ie = m?.key === ne ? m.pane : re, T = (t) => t === "$automa" ? r.text("automa") : e.members.find((e) => e.rid === t)?.name ?? t, E = (t) => t === "$automa" ? "#756883" : o[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % o.length].hex, D = (t) => e.send({
		type: "choose",
		id: t.id
	}), k = (e, t) => /* @__PURE__ */ d("button", {
		type: "button",
		className: "bs-action",
		onClick: () => D(e),
		"aria-label": r.label(e, y),
		children: t ?? r.label(e, y)
	}, e.id), ae = t.cloud ? r.cloud(t.cloud) : null, oe = (e, t = !1, n = !1) => /* @__PURE__ */ d(At, {
		id: e,
		tx: r,
		inactive: n,
		anchor: t ? `bs/wonderPort/w${O[e].track}` : `bs/wonder/${b.rid}/${e}`,
		choices: S.filter((n) => t ? n.kind === "deploy" && n.card === e && n.row === w : b.rid === y.rid && n.kind === "captainWonder" && n.card === e),
		onChoice: D,
		player: y
	}, e);
	return /* @__PURE__ */ f("div", {
		className: "bs-app",
		children: [/* @__PURE__ */ d(s, {
			adaptive: !0,
			className: "bs-screen",
			banner: /* @__PURE__ */ f("header", {
				className: "bs-banner",
				children: [
					/* @__PURE__ */ f("div", {
						className: "bs-masthead",
						children: [
							/* @__PURE__ */ d("h1", { children: r.text("name") }),
							/* @__PURE__ */ f("span", { children: [r.text("round", { n: t.round }), t.endRound !== null && ` · ${r.text("lastRound", { n: t.endRound })}`] }),
							/* @__PURE__ */ d("button", {
								className: "bs-text-button",
								onClick: () => g("rules"),
								children: r.text("help")
							}),
							/* @__PURE__ */ d("button", {
								className: "bs-text-button",
								onClick: () => g("log"),
								children: r.text("log")
							})
						]
					}),
					/* @__PURE__ */ d("nav", {
						className: "bs-players",
						"aria-label": r.text("inspect"),
						children: t.players.map((e) => /* @__PURE__ */ f("button", {
							type: "button",
							className: b.rid === e.rid ? "bs-selected" : "",
							style: { borderColor: E(e.rid) },
							onClick: () => l(e.rid),
							"aria-pressed": b.rid === e.rid,
							children: [
								/* @__PURE__ */ d("span", {
									className: "bs-player-dot",
									style: { background: E(e.rid) }
								}),
								T(e.rid),
								/* @__PURE__ */ d("b", {
									title: r.text("fame"),
									children: /* @__PURE__ */ d(a, { value: e.fame })
								}),
								/* @__PURE__ */ d(q, {
									id: "grit",
									label: r.text("grit")
								}),
								/* @__PURE__ */ d("span", { children: e.grit }),
								t.actor === e.rid && /* @__PURE__ */ d("span", { className: "bs-active-dot" })
							]
						}, e.rid))
					}),
					/* @__PURE__ */ d("div", {
						className: `bs-status ${C ? "bs-your-turn" : ""}`,
						"aria-live": "polite",
						children: C ? r.prompt(t) : t.phase === "done" ? r.text("done") : t.phase === "settle" ? r.text("resolving") : r.text("waiting", { name: T(t.actor) })
					}),
					/* @__PURE__ */ f("nav", {
						className: "bs-tabs",
						children: [[
							"board",
							"company",
							"itinerary",
							"market"
						].map((e) => /* @__PURE__ */ d("button", {
							"aria-pressed": ie === e,
							onClick: () => te({
								key: ne,
								pane: e
							}),
							children: r.text(e)
						}, e)), /* @__PURE__ */ f("button", {
							onClick: () => g("hand"),
							children: [
								r.text("encounters"),
								" (",
								y.encounters.length,
								")"
							]
						})]
					})
				]
			}),
			actionsHeight: "bs-footer-height",
			actions: /* @__PURE__ */ f("footer", {
				className: "bs-footer",
				children: [/* @__PURE__ */ d("div", {
					className: "bs-ship-picker",
					children: y.ships.map((e, n) => /* @__PURE__ */ d(J, {
						name: `bs/fleet/${y.rid}/${n}`,
						children: /* @__PURE__ */ f("button", {
							type: "button",
							disabled: !C || t.prompt !== "turn" || e.port !== null,
							"aria-pressed": w === n,
							"aria-label": r.ship(n),
							onClick: () => ee(n),
							children: [
								/* @__PURE__ */ d(Y, { row: n }),
								/* @__PURE__ */ d("span", { children: n + 1 }),
								e.crew && /* @__PURE__ */ d(q, { id: "crew" }),
								e.harvester && /* @__PURE__ */ d(q, { id: "harvester" })
							]
						}, n)
					}, n))
				}), /* @__PURE__ */ d("div", {
					className: "bs-footer-actions",
					children: S.filter((e) => Et.has(e.kind)).map((e) => k(e))
				})]
			}),
			children: /* @__PURE__ */ f("div", {
				className: "bs-table",
				"data-pane": ie,
				children: [
					/* @__PURE__ */ f("div", {
						className: "bs-flight-info",
						children: [
							t.payment.length > 0 && /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("b", { children: r.text("remaining", { value: "" }) }), /* @__PURE__ */ d(X, {
								values: t.payment,
								tx: r
							})] }),
							/* @__PURE__ */ f(J, {
								name: `bs/cargo/${x.rid}`,
								className: "bs-cargo",
								children: [x.cargo.length > 0 && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("b", { children: r.text("cargo", { value: "" }) }), /* @__PURE__ */ d(X, {
									values: x.cargo,
									tx: r
								})] }), x.pocket.length > 0 && /* @__PURE__ */ d(X, {
									values: x.pocket,
									tx: r
								})]
							}),
							t.dice.length > 0 && /* @__PURE__ */ d(J, {
								name: "bs/dice",
								className: "bs-dice",
								children: t.dice.map((e, t) => /* @__PURE__ */ d("span", { children: e === "e" ? r.text("outpostEncounter") : /* @__PURE__ */ d(q, {
									id: e,
									label: r.resource(e)
								}) }, t))
							}, t.dice.join() + t.log.length),
							S.some((e) => !Dt.has(e.kind)) && /* @__PURE__ */ d("div", {
								className: "bs-context-choices",
								children: S.filter((e) => !Dt.has(e.kind)).map((e) => k(e))
							}),
							t.source.startsWith("o") && t.prompt === "outfitPlace" && /* @__PURE__ */ f(J, {
								name: "bs/pending",
								className: "bs-pending",
								children: [/* @__PURE__ */ d("img", {
									src: K(t.source),
									alt: ""
								}), /* @__PURE__ */ d("b", { children: r.card(t.source) })]
							})
						]
					}),
					/* @__PURE__ */ f("section", {
						className: "bs-chart bs-pane-board",
						children: [
							/* @__PURE__ */ d("div", {
								className: "bs-tracks",
								children: v.map((e, n) => /* @__PURE__ */ f(J, {
									name: `bs/track/${e}`,
									className: `bs-track bs-${e}`,
									children: [
										/* @__PURE__ */ f("div", {
											className: "bs-track-title",
											children: [
												/* @__PURE__ */ d(q, {
													id: e,
													label: r.track(e)
												}),
												/* @__PURE__ */ d("b", { children: r.track(e) }),
												S.filter((t) => t.kind === "track" && t.value === e).map((e) => k(e, "+1"))
											]
										}),
										/* @__PURE__ */ d("div", {
											className: "bs-track-cells",
											children: Array.from({ length: 14 }, (r, i) => /* @__PURE__ */ f(J, {
												name: `bs/trackCell/${e}/${i}`,
												className: i === 11 ? "bs-end-threshold" : "",
												children: [/* @__PURE__ */ d("small", { children: i }), t.players.filter((e) => e.tracks[n] === i).map((t) => /* @__PURE__ */ d(J, {
													name: `bs/trackToken/${t.rid}/${e}`,
													className: "bs-track-token",
													style: { background: E(t.rid) },
													children: /* @__PURE__ */ d("span", {
														title: T(t.rid),
														children: T(t.rid).slice(0, 1)
													})
												}, t.rid))]
											}, i))
										}),
										S.some((t) => t.kind === "track" && t.value === e) && /* @__PURE__ */ d(yt, {})
									]
								}, e))
							}),
							/* @__PURE__ */ f("div", {
								className: "bs-cloudsea",
								children: [/* @__PURE__ */ d("div", {
									className: "bs-terrain",
									children: [
										0,
										1,
										2
									].map((e) => /* @__PURE__ */ d("img", {
										src: K(`land${e}`),
										alt: ""
									}, e))
								}), t.ports.slice(0, 9).map((e, n) => {
									let i = S.filter((t) => t.kind === "deploy" && t.value === e.id && t.row === w || ["outpost", "activateOutpost"].includes(t.kind) && Number(t.value) === n), a = t.players.flatMap((t) => t.ships.flatMap((n, r) => n.port === e.id ? [{
										q: t,
										r
									}] : []));
									return /* @__PURE__ */ d(J, {
										name: `bs/port/${e.id}`,
										className: `bs-port ${e.open ? "bs-revealed" : "bs-cloud-port"} bs-layer-${Math.floor(n / 3)}`,
										children: e.open ? /* @__PURE__ */ f(u, { children: [
											/* @__PURE__ */ f("div", {
												className: "bs-port-title",
												children: [/* @__PURE__ */ d(Y, { row: n % 3 }), /* @__PURE__ */ d("b", { children: r.port(e.id) })]
											}),
											/* @__PURE__ */ f("div", {
												className: "bs-port-benefit",
												children: [/* @__PURE__ */ d(q, {
													id: _[n % 3],
													label: r.resource(_[n % 3])
												}), /* @__PURE__ */ f("span", { children: ["+ ", n < 3 ? /* @__PURE__ */ d(q, {
													id: "grit",
													label: r.text("grit")
												}) : /* @__PURE__ */ f("span", { children: [
													Math.floor(n / 3),
													" ",
													r.text("dice")
												] })] })]
											}),
											/* @__PURE__ */ f("details", {
												className: "bs-port-info",
												children: [
													/* @__PURE__ */ d("summary", { children: r.text("details") }),
													/* @__PURE__ */ d("p", { children: r.portEffect(e.id) }),
													e.tile && /* @__PURE__ */ f("p", { children: [/* @__PURE__ */ d(q, { id: "outpost" }), r.outpost(e.tile)] })
												]
											}),
											e.resources.length > 0 && /* @__PURE__ */ d(X, {
												values: e.resources,
												tx: r
											}),
											/* @__PURE__ */ f("div", {
												className: "bs-port-rewards",
												children: [e.fame > 0 && /* @__PURE__ */ f("span", { children: [
													r.text("fame"),
													" ",
													e.fame
												] }), e.tile && /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(q, { id: "outpost" }), [
													"c",
													"s",
													"a",
													"h",
													"food",
													"t",
													"crew"
												].includes(e.tile) ? /* @__PURE__ */ d(q, {
													id: e.tile,
													label: r.outpost(e.tile)
												}) : r.text("outpostEncounter")] })]
											}),
											/* @__PURE__ */ d("div", {
												className: "bs-outpost-owners",
												children: t.players.filter((e) => e.outposts.includes(n)).map((e) => /* @__PURE__ */ d("span", {
													style: { borderColor: E(e.rid) },
													children: T(e.rid)
												}, e.rid))
											}),
											/* @__PURE__ */ d("div", {
												className: "bs-visitors",
												children: a.map(({ q: e, r: t }) => /* @__PURE__ */ f(J, {
													name: `bs/visitor/${e.rid}/${t}`,
													children: [/* @__PURE__ */ d(Y, { row: t }), /* @__PURE__ */ d("small", {
														style: { color: E(e.rid) },
														children: T(e.rid)
													})]
												}, e.rid + t))
											}),
											/* @__PURE__ */ d(Z, {
												choices: i,
												tx: r,
												player: y,
												onChoice: D,
												short: t.prompt === "turn" ? r.text("sail") : void 0
											})
										] }) : /* @__PURE__ */ f("div", {
											className: "bs-cloud-cover",
											children: [
												/* @__PURE__ */ d("svg", {
													viewBox: "0 0 160 130",
													"aria-hidden": "true",
													children: /* @__PURE__ */ d("path", { d: "M-20 102Q13 50 52 82T145 72T180 32M-20 80Q13 28 52 60T145 50T180 10M-20 58Q13 6 52 38T145 28T180-12" })
												}),
												/* @__PURE__ */ d(Y, { row: n % 3 }),
												/* @__PURE__ */ d("b", { children: r.text("unexplored") })
											]
										})
									}, e.id);
								})]
							}),
							ae && /* @__PURE__ */ f(J, {
								name: "bs/cloudEvent",
								className: "bs-event",
								children: [
									/* @__PURE__ */ d("b", { children: r.text("cloud", { id: t.cloud }) }),
									/* @__PURE__ */ f("p", { children: [
										r.text("cloudReward"),
										" · ",
										t.turn === "$automa" ? r.text("cloudThreeFame") : ae.left
									] }),
									/* @__PURE__ */ f("p", { children: [
										r.text("cloudRight"),
										" · ",
										ae.right
									] })
								]
							}, t.cloud),
							/* @__PURE__ */ d("div", {
								className: "bs-special-ports",
								children: t.ports.slice(12).map((e) => /* @__PURE__ */ f(J, {
									name: `bs/port/${e.id}`,
									className: "bs-special",
									children: [
										/* @__PURE__ */ d("b", { children: r.port(e.id) }),
										/* @__PURE__ */ f("details", { children: [/* @__PURE__ */ d("summary", { children: r.text("details") }), /* @__PURE__ */ d("p", { children: r.portEffect(e.id) })] }),
										e.fame > 0 && /* @__PURE__ */ f("span", { children: [
											r.text("fame"),
											" ",
											e.fame
										] }),
										/* @__PURE__ */ d("div", {
											className: "bs-visitors",
											children: t.players.flatMap((t) => t.ships.flatMap((n, r) => n.port === e.id ? /* @__PURE__ */ f(J, {
												name: `bs/visitor/${t.rid}/${r}`,
												children: [/* @__PURE__ */ d(Y, { row: r }), /* @__PURE__ */ d("small", { children: T(t.rid) })]
											}, t.rid + r) : []))
										}),
										/* @__PURE__ */ d(Z, {
											choices: S.filter((t) => t.kind === "deploy" && t.value === e.id && t.row === w),
											tx: r,
											player: y,
											onChoice: D,
											short: e.id === "market" ? void 0 : r.text("sail")
										})
									]
								}, e.id))
							}),
							/* @__PURE__ */ f("div", {
								className: "bs-supply",
								children: [
									/* @__PURE__ */ d("b", { children: r.text("supply") }),
									_.map((e, n) => /* @__PURE__ */ f(J, {
										name: `bs/supply/${e}`,
										children: [/* @__PURE__ */ d(q, {
											id: e,
											label: r.resource(e)
										}), /* @__PURE__ */ d(a, { value: t.supply[n] })]
									}, e)),
									/* @__PURE__ */ f("span", { children: [
										r.text("fame"),
										" ",
										t.fameSupply
									] }),
									/* @__PURE__ */ f(J, {
										name: "bs/deck",
										children: [
											r.text("encounters"),
											" ",
											t.encounterCount
										]
									}),
									/* @__PURE__ */ d(J, {
										name: "bs/discard",
										children: r.text("discardPile")
									})
								]
							})
						]
					}),
					/* @__PURE__ */ f("section", {
						className: "bs-company bs-pane-company",
						children: [/* @__PURE__ */ f("div", {
							className: "bs-section-heading",
							children: [/* @__PURE__ */ f("h2", { children: [
								T(b.rid),
								" · ",
								r.text("company")
							] }), /* @__PURE__ */ f("b", { children: [
								r.text("score"),
								" ",
								/* @__PURE__ */ d(a, { value: b.score.total })
							] })]
						}), b.automa ? /* @__PURE__ */ f(u, { children: [
							/* @__PURE__ */ d("h3", { children: r.automaName(t.automaStart) }),
							/* @__PURE__ */ d("p", { children: r.text([
								"automaRecall1",
								"automaRecall2",
								"automaRecall3",
								"automaRecall4"
							][t.automaStart]) }),
							/* @__PURE__ */ d("p", { children: r.text(t.config.soloLevel <= 1 ? "automaWorkshop" : "automaFactory") }),
							/* @__PURE__ */ d(X, {
								values: [...me[t.automaStart], ...t.config.soloLevel <= 1 ? ["h"] : [
									"c",
									"s",
									"a",
									"h",
									"food"
								]],
								tx: r
							}),
							/* @__PURE__ */ d(X, {
								values: b.pocket,
								tx: r
							}),
							t.automaCard !== null && /* @__PURE__ */ d("p", { children: r.text("automaTurn", { n: t.automaCard + 1 }) })
						] }) : /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("div", {
							className: "bs-personnel",
							children: /* @__PURE__ */ f(J, {
								name: `bs/captain/${b.rid}`,
								children: [/* @__PURE__ */ d(q, {
									id: "captain",
									label: r.text("captain")
								}), /* @__PURE__ */ f("span", { children: [
									r.text("captain"),
									" · ",
									r.text(b.captainUsed ? "used" : "ready")
								] })]
							})
						}), /* @__PURE__ */ d("div", {
							className: "bs-rows",
							children: b.rows.map((e, n) => /* @__PURE__ */ f("div", {
								className: `bs-row bs-${v[n]} ${t.activeRow === n && t.turn === b.rid ? "bs-current-row" : ""}`,
								children: [/* @__PURE__ */ f("div", {
									className: "bs-row-head",
									children: [
										/* @__PURE__ */ f(J, {
											name: `bs/ship/${b.rid}/${n}`,
											className: `bs-ship ${b.ships[n].port ? "bs-away-ship" : ""}`,
											children: [/* @__PURE__ */ f("button", {
												disabled: !C || b.rid !== y.rid || t.prompt !== "turn" || b.ships[n].port !== null,
												"aria-pressed": w === n,
												onClick: () => ee(n),
												children: [/* @__PURE__ */ d(Y, { row: n }), /* @__PURE__ */ d("b", { children: r.ship(n) })]
											}), /* @__PURE__ */ d("span", { children: b.ships[n].port ? r.text("deployed", { name: r.port(b.ships[n].port) }) : r.text("home") })]
										}),
										/* @__PURE__ */ f(J, {
											name: `bs/crew/${b.rid}/${n}`,
											children: [/* @__PURE__ */ d(q, {
												id: "crew",
												label: r.text("crew")
											}), /* @__PURE__ */ d("span", { children: b.ships[n].crew ? r.text(b.ships[n].crewUsed ? "used" : "ready") : "—" })]
										}),
										/* @__PURE__ */ f(J, {
											name: `bs/harvester/${b.rid}/${n}`,
											children: [/* @__PURE__ */ d(q, {
												id: "harvester",
												label: r.text("harvester")
											}), /* @__PURE__ */ d("span", { children: b.ships[n].harvester ? "✓" : "—" })]
										}),
										/* @__PURE__ */ d("div", { children: b.rid === y.rid && S.filter((e) => (e.kind === "recallRow" || e.kind === "upgrade") && e.row === n).map((e) => k(e)) })
									]
								}), /* @__PURE__ */ f("div", {
									className: "bs-row-cards",
									children: [e.map((e, t) => /* @__PURE__ */ d(jt, {
										outfit: e,
										row: n,
										index: t,
										tx: r,
										choices: b.rid === y.rid ? S : [],
										player: b,
										onChoice: D
									}, t)), Array.from({ length: 3 - e.length }, (t, i) => /* @__PURE__ */ f("div", {
										className: "bs-empty-outfit",
										children: [
											/* @__PURE__ */ d(q, {
												id: v[n],
												label: r.track(v[n])
											}),
											/* @__PURE__ */ f("span", { children: [
												r.text("outfit"),
												" ",
												e.length + i + 1
											] }),
											b.rid === y.rid && i === 0 && /* @__PURE__ */ d(Z, {
												choices: S.filter((e) => e.kind === "outfitPlace" && e.row === n),
												tx: r,
												player: b,
												onChoice: D,
												short: r.text("installShort")
											})
										]
									}, i))]
								})]
							}, n))
						})] })]
					}),
					/* @__PURE__ */ f("section", {
						className: "bs-itinerary-section bs-pane-itinerary",
						children: [
							/* @__PURE__ */ f("div", {
								className: "bs-section-heading",
								children: [/* @__PURE__ */ f("h2", { children: [
									T(b.rid),
									" · ",
									r.text("itinerary")
								] }), /* @__PURE__ */ d(J, {
									name: `bs/hand/${b.rid}`,
									children: /* @__PURE__ */ f("button", {
										className: "bs-action",
										onClick: () => g("hand"),
										children: [
											r.text("encounters"),
											" (",
											b.encounters.length,
											")"
										]
									})
								})]
							}),
							/* @__PURE__ */ d("div", {
								className: "bs-itinerary",
								children: b.wonders.map((e, t) => oe(e, !1, t !== 0 && t !== b.wonders.length - 1))
							}),
							t.prompt === "keepEncounter" && /* @__PURE__ */ d("div", {
								className: "bs-encounters",
								children: t.revealed.map((e) => /* @__PURE__ */ d(Mt, {
									id: e,
									tx: r,
									choices: S,
									player: y,
									onChoice: D
								}, e))
							}),
							/* @__PURE__ */ d("h2", { children: r.text("wonderPorts") }),
							/* @__PURE__ */ d("div", {
								className: "bs-wonder-market",
								children: t.wonderTops.map((e, n) => /* @__PURE__ */ f(J, {
									name: `bs/port/w${v[n]}`,
									children: [
										/* @__PURE__ */ d("b", { children: r.port(`w${v[n]}`) }),
										e ? oe(e, !0) : /* @__PURE__ */ d("p", { children: r.text("none") }),
										t.ports[9 + n].fame > 0 && /* @__PURE__ */ f("span", { children: [
											r.text("fame"),
											" ",
											t.ports[9 + n].fame
										] }),
										S.filter((e) => e.kind === "cloudPort" && e.value === `w${v[n]}`).map((e) => k(e)),
										t.players.flatMap((e) => e.ships.flatMap((t, r) => t.port === `w${v[n]}` ? /* @__PURE__ */ f(J, {
											name: `bs/visitor/${e.rid}/${r}`,
											className: "bs-wonder-visitor",
											children: [/* @__PURE__ */ d(Y, { row: r }), /* @__PURE__ */ d("small", { children: T(e.rid) })]
										}, e.rid + r) : []))
									]
								}, n))
							})
						]
					}),
					/* @__PURE__ */ f("section", {
						className: "bs-market bs-pane-market",
						children: [
							/* @__PURE__ */ d("h2", { children: r.text("market") }),
							/* @__PURE__ */ d("div", {
								className: "bs-market-cards",
								children: t.market.map((e, t) => /* @__PURE__ */ f(J, {
									name: `bs/market/${t}`,
									className: "bs-card bs-market-card",
									children: [
										/* @__PURE__ */ d("small", { children: t + 1 }),
										/* @__PURE__ */ d("img", {
											className: "bs-machine-art",
											src: K(e),
											alt: ""
										}),
										/* @__PURE__ */ d("h3", { children: r.card(e) }),
										/* @__PURE__ */ d(X, {
											values: A[e].slots,
											tx: r
										}),
										/* @__PURE__ */ d("p", { children: r.effect(A[e].effect) }),
										A[e].grit > 0 && /* @__PURE__ */ f("p", { children: [/* @__PURE__ */ d(q, { id: "grit" }), r.text("costGrit", { n: A[e].grit })] }),
										/* @__PURE__ */ d(Z, {
											choices: S.filter((t) => t.kind === "outfitSelect" && t.card === e),
											tx: r,
											player: y,
											onChoice: D,
											short: r.text("takeShort")
										})
									]
								}, e))
							}),
							S.filter((e) => e.kind === "cycle").map((e) => k(e))
						]
					})
				]
			})
		}), h && /* @__PURE__ */ d("div", {
			className: "bs-modal-shade",
			onClick: () => g(null),
			children: /* @__PURE__ */ f("section", {
				role: "dialog",
				"aria-modal": "true",
				"aria-label": r.text(h === "rules" ? "help" : h === "log" ? "log" : "encounters"),
				className: "bs-modal",
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ f("div", {
					className: "bs-modal-heading",
					children: [/* @__PURE__ */ d("h2", { children: r.text(h === "rules" ? "help" : h === "log" ? "log" : "encounters") }), /* @__PURE__ */ d("button", {
						className: "bs-action",
						autoFocus: !0,
						onClick: () => g(null),
						children: r.text("close")
					})]
				}), h === "rules" ? /* @__PURE__ */ d(Tt, {}) : h === "log" ? /* @__PURE__ */ d("ol", { children: t.log.slice().reverse().map((e, t) => /* @__PURE__ */ d("li", { children: r.entry(e, T) }, t)) }) : /* @__PURE__ */ d("div", {
					className: "bs-encounters",
					children: [.../* @__PURE__ */ new Set([...b.encounters, ...t.revealed])].map((e) => /* @__PURE__ */ d(Mt, {
						id: e,
						tx: r,
						choices: b.rid === y.rid ? S : [],
						player: y,
						onChoice: (e) => {
							D(e), g(null);
						}
					}, e))
				})]
			})
		})]
	});
}
function X({ values: e, tx: t }) {
	return /* @__PURE__ */ d("div", {
		className: "bs-token-row",
		children: e.map((e, n) => /* @__PURE__ */ d(q, {
			id: e,
			label: t.symbol(e)
		}, n))
	});
}
function Z({ choices: e, tx: t, player: n, onChoice: r, short: i }) {
	return e.length ? /* @__PURE__ */ f("div", {
		className: "bs-object-choices",
		children: [/* @__PURE__ */ d(yt, {}), e.length === 1 ? /* @__PURE__ */ d("button", {
			className: "bs-action",
			"aria-label": t.label(e[0], n),
			onClick: () => r(e[0]),
			children: i ?? t.label(e[0], n)
		}) : /* @__PURE__ */ f("details", { children: [/* @__PURE__ */ d("summary", { children: t.text("choose") }), e.map((e) => /* @__PURE__ */ d("button", {
			className: "bs-action",
			onClick: () => r(e),
			children: t.label(e, n)
		}, e.id))] })]
	}) : null;
}
function At({ id: e, tx: t, inactive: n, anchor: r, choices: i, onChoice: a, player: o }) {
	let s = O[e], c = ![
		"reroll",
		"guildEncounter",
		"flagonEncounter",
		"workshopEncounter",
		"marketFame"
	].includes(s.ability);
	return /* @__PURE__ */ f(J, {
		name: r,
		className: `bs-card bs-wonder bs-${s.track} ${n ? "bs-inactive" : ""}`,
		children: [
			/* @__PURE__ */ f("header", { children: [/* @__PURE__ */ d("h3", { children: t.card(e) }), /* @__PURE__ */ d(X, {
				values: s.symbols,
				tx: t
			})] }),
			/* @__PURE__ */ d("img", {
				className: "bs-wonder-art",
				src: K(e),
				alt: ""
			}),
			s.cost.length > 0 && /* @__PURE__ */ f("div", {
				className: "bs-card-cost",
				children: [/* @__PURE__ */ d("span", { children: t.text("costShort") }), /* @__PURE__ */ d(X, {
					values: s.cost,
					tx: t
				})]
			}),
			s.advance.length > 0 && /* @__PURE__ */ f("div", {
				className: "bs-card-instant",
				children: [/* @__PURE__ */ d("span", { children: t.text("instantShort") }), /* @__PURE__ */ d(X, {
					values: s.advance.map((e) => e === "*" ? "any" : e),
					tx: t
				})]
			}),
			/* @__PURE__ */ f("p", {
				className: "bs-card-ability",
				children: [
					c && /* @__PURE__ */ d(q, {
						id: "captain",
						label: t.text("captainAction")
					}),
					/* @__PURE__ */ d("b", { children: t.text(n ? "inactive" : c ? "captainAction" : "passive") }),
					" · ",
					t.effect(s.ability),
					s.grit > 0 && /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(q, { id: "grit" }), s.grit] })
				]
			}),
			/* @__PURE__ */ d(Z, {
				choices: i,
				tx: t,
				player: o,
				onChoice: a,
				short: i[0]?.kind === "captainWonder" ? t.text("captainAction") : t.text("sail")
			})
		]
	});
}
function jt({ outfit: e, row: t, index: n, tx: r, choices: i, player: a, onChoice: o }) {
	let s = A[e.id], c = s?.slots ?? ["*", _[t]], l = s?.effect ?? (e.id === "base:grit" ? "grit2" : e.id === "base:outpost" ? "outpostChoice" : "resource");
	return /* @__PURE__ */ f(J, {
		name: `bs/outfit/${a.rid}/${t}/${n}`,
		className: `bs-card bs-outfit ${e.used ? "bs-used" : ""}`,
		children: [
			/* @__PURE__ */ d("img", {
				className: "bs-machine-art",
				src: K(s ? e.id : e.id.replace(":", "-")),
				alt: ""
			}),
			/* @__PURE__ */ d("h3", { children: r.card(e.id) }),
			/* @__PURE__ */ d("div", {
				className: "bs-slots",
				children: c.map((s, c) => {
					let l = e.tokens[c], u = i.filter((e) => [
						"pay",
						"place",
						"store",
						"captainSlot",
						"crewSlot"
					].includes(e.kind) && e.row === t && e.slot === c && Number(e.value) === n);
					return /* @__PURE__ */ f(J, {
						name: `bs/slot/${a.rid}/${t}/${n}/${c}`,
						className: `bs-slot ${l ? "bs-filled" : ""}`,
						children: [
							/* @__PURE__ */ d(q, {
								id: s,
								label: r.resource(s),
								className: "bs-slot-need"
							}),
							l && /* @__PURE__ */ d(q, {
								id: l,
								label: r.text("filled", { name: r.resource(l) })
							}),
							/* @__PURE__ */ d(Z, {
								choices: u,
								tx: r,
								player: a,
								onChoice: o,
								short: /* @__PURE__ */ d(q, {
									id: u[0]?.kind === "pay" ? l : u[0]?.kind === "captainSlot" ? "captain" : u[0]?.kind === "crewSlot" ? "crew" : u[0]?.resource ?? s,
									label: r.text("choose")
								})
							})
						]
					}, c);
				})
			}),
			/* @__PURE__ */ d("p", { children: r.effect(l) }),
			(s?.grit ?? 0) > 0 && /* @__PURE__ */ f("small", { children: [/* @__PURE__ */ d(q, { id: "grit" }), s.grit] }),
			e.used && /* @__PURE__ */ d("b", { children: r.text("used") }),
			/* @__PURE__ */ d(Z, {
				choices: i.filter((e) => e.kind === "activate" && e.row === t && Number(e.value) === n),
				tx: r,
				player: a,
				onChoice: o,
				short: r.text("activateShort")
			})
		]
	});
}
function Mt({ id: e, tx: t, choices: n, player: r, onChoice: i }) {
	let a = j[e];
	return /* @__PURE__ */ f("article", {
		className: "bs-card bs-encounter",
		children: [
			/* @__PURE__ */ d("h3", { children: t.card(`e${e + 1}`) }),
			/* @__PURE__ */ d("img", {
				src: K(`e${e + 1}`),
				className: "bs-encounter-art",
				alt: ""
			}),
			/* @__PURE__ */ f("p", { children: [
				/* @__PURE__ */ d("b", { children: "A" }),
				" ",
				t.effect(a.a)
			] }),
			/* @__PURE__ */ f("p", { children: [
				/* @__PURE__ */ d("b", { children: "B" }),
				" ",
				t.effect(a.b),
				a.grit > 0 && /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(q, { id: "grit" }), a.grit] }),
				" ",
				a.port && t.text("requiresPort", { port: t.port(a.port) })
			] }),
			/* @__PURE__ */ d(Z, {
				choices: n.filter((t) => (t.kind === "encounter" || t.kind === "keepEncounter") && Number(t.value) === e),
				tx: t,
				player: r,
				onChoice: i
			})
		]
	});
}
//#endregion
//#region src/games/braidedskies/bot.ts
var Nt = (e) => [...e.rows.flatMap((e) => e.flatMap((e) => e.tokens)), ...e.pocket].filter((e) => _.includes(e));
function Pt(e) {
	let t = {
		c: 0,
		s: 0,
		a: 0,
		h: 0,
		food: 0
	};
	for (let n of e.wonders) for (let e of O[n].symbols) t[e]++;
	return t;
}
function Q(e, t, n) {
	let r = Nt(t).filter((e) => e === n).length, i = e.wonderTops.filter((e) => !!e).map((e) => O[e].cost.filter((e) => e === n).length - r);
	return (n === "t" ? 2.1 : 1.5) + Math.max(0, ...i) * .22 - r * .2;
}
function Ft(e, t) {
	let n = v.indexOf(t), r = e.tracks[n];
	return r >= 13 ? 0 : [
		2.6,
		2.6,
		2.8
	][n] + ([
		2,
		3,
		5,
		8,
		10,
		12
	].includes(r) ? 1.9 : 0) + +(r === 10);
}
function $(e, t, n) {
	if (/^[csa]+$/.test(n)) return n.split("").reduce((e, n) => e + Ft(t, n), 0);
	if (_.includes(n)) return Q(e, t, n);
	if (n === "tourist") return Q(e, t, "t");
	if (n === "resource" || n === "stone") return 1.6;
	if (n === "grit2" || n === "grit3") return Math.min(8 - t.grit, Number(n.slice(-1))) * .7;
	if (n === "any" || n === "any2") return Math.max(...v.map((e) => Ft(t, e))) * (n === "any2" ? 2 : 1);
	if (n === "fame3") return 3;
	if (n === "outfit") return t.rows.some((e) => e.length < 3) ? 4 : 0;
	if (n === "trade") return t.grit * .45;
	if (n === "foodFame") return Pt(t).food;
	if (n === "outpostTypes" || n === "outpostFame") return t.outposts.length;
	if (n === "outpostActivate") return 2.4;
	if (n === "outpostChoice" || n === "build") return t.outposts.length < 6 ? 3.5 : 2;
	if (n.startsWith("count")) return Nt(t).filter((e) => e === n.slice(5)).length;
	if (n.startsWith("start")) {
		let e = Number(n.slice(5));
		return 2.5 + (e === 1 ? t.encounters.length : e === 2 ? t.outposts.length : e === 3 ? t.rows.flat().filter((e) => A[e.id]?.slots.length === 2).length : e === 4 ? t.ships.filter((e) => e.crew).length * 2 : e === 5 ? Nt(t).filter((e) => e === "t").length : e === 6 ? t.ships.filter((e) => e.harvester).length * 2 : Pt(t).h * 2);
	}
	return 2;
}
var It = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid), i = e.private?.choices;
	if (!r || !i?.length || n.phase !== "play" || n.actor !== t.rid) return null;
	let a = n.endRound !== null, o = Nt(r), s = r.rows.flatMap((e, t) => e.flatMap((e) => e.tokens.flatMap((n, r) => n === null ? [{
		row: t,
		need: e.id.startsWith("base:") ? r === 0 ? "*" : _[t] : A[e.id].slots[r]
	}] : []))), c = (e) => {
		let t = e.row ?? 0, i = r.rows[t]?.[Number(e.value)], c = i?.tokens.filter((e) => e === null).length ?? 0;
		if (e.kind === "deploy") {
			let i = r.ships[t], c = Number(i.crew) + Number(i.harvester);
			if (e.value.startsWith("p")) {
				let a = Number(e.value.slice(1)), c = n.ports[a], l = _[a % 3], u = s.filter((e) => e.row === t || r.grit > 1).length, d = (i.crew || i.harvester) && (a < 3 && !n.ports[a + 3].open || a >= 3 && a < 6 && !n.ports[a + 3].open);
				return Math.min(u, 1 + Math.floor(a / 3) + Number(i.harvester) + c.resources.length) * Q(n, r, l) + (a < 3 ? Math.min(8 - r.grit, 1) * .7 : 0) + (d ? 3.2 : 0) + (r.outposts.includes(a) ? 2 : 0) - o.length * .08;
			}
			if (/^w[csa]$/.test(e.value)) {
				let t = O[e.card], n = Pt(r);
				return 6 + t.advance.reduce((e, t) => e + (t === "*" ? 3 : Ft(r, t)), 0) + t.symbols.reduce((e, t) => e + (t === "h" ? n.h ? 2 : 4 : 1.4), 0) + c - t.cost.length * .8;
			}
			if (e.value === "festival") return 14 + c * 2;
			if (e.value === "market") return 1 + (e.n ?? 0) + c * 1.5 + (a ? 2 : -o.length * .1);
			if (e.value === "guild") return (a ? 2 : 6.2) + Number(i.crew) * 1.4;
			if (e.value === "workshop") return (a ? 1 : 7.5 - r.ships.filter((e) => e.harvester).length) + Number(i.crew) * 2;
			if (e.value === "flagon") return (a ? 1 : 8 - r.ships.filter((e) => e.crew).length) + Number(i.harvester);
		}
		if (e.kind === "recall") return r.ships.reduce((e, t, i) => e + (t.port === null ? 0 : r.rows[i].reduce((e, t) => e + (t.tokens.every((e) => e !== null) ? $(n, r, A[t.id]?.effect ?? "any") : 0), 0)), 2) + $(n, r, O[r.wonders[0]].ability) * .7;
		if (e.kind === "recallRow") return r.rows[t].reduce((e, t) => e + (t.tokens.every((e) => e !== null) ? 2 : 0) + +(A[t.id]?.effect === "resource"), 0);
		if (e.kind === "activate") return $(n, r, A[e.card]?.effect ?? (e.card?.endsWith("grit") ? "grit2" : e.card?.endsWith("resource") ? "resource" : "outpostChoice")) + .2;
		if (e.kind === "captainWonder") return $(n, r, O[e.value].ability) - O[e.value].grit * .5;
		if (e.kind === "captainSlot" || e.kind === "crewSlot") return c === 1 ? ($(n, r, A[i.id]?.effect ?? "any") - (e.kind === "captainSlot" ? 1 : .2)) * (n.activeRow === t ? 1.2 : .9) : -6;
		if (e.kind === "encounter") {
			let t = j[Number(e.value)];
			return $(n, r, e.n ? t.b : t.a) - (e.n ? t.grit * .7 : 0) - (n.prompt === "end" ? 0 : 1.4) - (n.prompt === "pay" ? 2 : 0);
		}
		if (e.kind === "place") return 3 + Q(n, r, e.resource) * .2 + (c === 1 ? 2 : 0) + +(e.row === n.promptRow) + (n.activeRow === t ? 1.4 : 0);
		if (e.kind === "pay") return 2 - Q(n, r, e.resource) * .1 - !!i.tokens.every((e) => e !== null);
		if (e.kind === "payPocket" || e.kind === "directPayment") return 3;
		if (e.kind === "resource") return Q(n, r, e.value);
		if (e.kind === "harvest") return e.value === "die" ? 1.8 : Q(n, r, e.value);
		if (e.kind === "track") return Ft(r, e.value);
		if (e.kind === "outpostChoice") return e.value === "build" && !a ? 3.8 : 3;
		if (e.kind === "outpost" || e.kind === "activateOutpost") {
			let t = n.ports[Number(e.value)], i = Pt(r);
			return (t.tile === "t" ? 2.8 : t.tile === "encounter" ? 2 : t.tile === "crew" ? r.ships.filter((e) => e.crew).length : i[t.tile] ?? 1) + (Number(e.value) < 3 ? .7 : 0);
		}
		if (e.kind === "upgrade") return 2 + Number(r.ships[t][e.value === "crew" ? "harvester" : "crew"]) + Number(r.ships[t].port === null) * .4;
		if (e.kind === "outfitSelect") return $(n, r, A[e.card].effect) + A[e.card].slots.reduce((e, t) => e + (o.includes(t) ? 1 : t === "*" ? 1.3 : t === "crew" && r.ships.some((e) => e.crew) ? 1 : 0), 0) - A[e.card].grit * .8;
		if (e.kind === "outfitPlace") return 2 + +(r.rows[t].length === 2) + +!!r.ships[t].crew + (r.ships[t].port === null ? 0 : .5);
		if (e.kind === "keepDie") return e.value === "e" ? 2 : Q(n, r, e.value);
		if (e.kind === "reroll") return n.promptValue === "t" || n.promptValue === "e" ? -1 : 1.9 - Q(n, r, n.promptValue);
		if (e.kind === "keepEncounter") {
			let t = j[Number(e.value)];
			return Math.max($(n, r, t.a), $(n, r, t.b) - t.grit * .7);
		}
		return e.kind === "trade" ? e.n * (a ? .95 : r.grit > 5 ? .8 : .3) : e.kind === "cloudChoice" ? e.value === "encounter" ? 2 : $(n, r, e.value) : e.kind === "cloudPort" ? e.value === "wa" ? 2 : 1 : e.kind === "endRow" || e.kind === "endRecall" || e.kind === "finish" || e.kind === "discard" || e.kind === "skip" ? -5 : e.kind === "cycle" ? -.5 : 0;
	}, l = (e) => {
		let t = c(e);
		if (e.kind === "track") {
			let n = v.indexOf(e.value), i = r.tracks[n], a = Pt(r), o = i === 5 ? n === 0 ? 4 + Number([
				"food",
				"c",
				"s",
				"a"
			].every((e) => a[e] > 0)) * 5 : n === 1 ? 4 + r.ships.filter((e) => e.crew).length + r.ships.filter((e) => e.harvester).length : 6 + (r.grit >= 6 ? 5 : 0) : i === 10 ? n === 0 ? 6 + a.food : n === 1 ? 6 + r.outposts.length : 6 + Number(v.every((e) => r.wonders.some((t) => O[t].track === e))) * 5 : i === 12 || i === 2 ? 4 : i === 3 || i === 8 ? 2 : 0;
			t = i >= 13 ? -10 : 1.2 + o + ([
				3,
				7,
				11
			].includes(i) ? a[[
				"s",
				"a",
				"c"
			][n]] : 0);
		}
		return e.kind === "captainWonder" && (t += 2), e.kind === "deploy" && e.value === "guild" && r.rows.every((e) => e.length === 3) && (t -= 8), e.kind === "recall" && (t *= .68), e.kind === "deploy" && ["flagon", "workshop"].includes(e.value) && (t += n.round < 8 ? 2 : -2), e.kind === "outfitSelect" && (t += A[e.card].slots.length === 1 ? 2.5 : A[e.card].slots.includes("crew") ? -2 : 0), e.kind === "place" && (t += r.rows[u(e)]?.[Number(e.value)]?.tokens.filter((e) => e === null).length === 1 ? 2 : 0), t;
	}, u = (e) => e.row ?? 0, d = i.map((e, n) => ({
		c: e,
		v: l(e) + (t.difficulty === "weak" ? n % 5 * .12 : 0)
	})).sort((e, t) => t.v - e.v), f = /* @__PURE__ */ new Set([
		"deploy",
		"recall",
		"track",
		"outfitSelect",
		"upgrade"
	]), p = d.filter((e) => f.has(e.c.kind)).slice(0, 3);
	return { action: {
		type: "choose",
		id: (t.difficulty === "weak" && f.has(d[0].c.kind) && p.length > 1 ? p[(n.round + r.fame + r.grit) % p.length] : d[0]).c.id
	} };
};
//#endregion
//#region src/games/braidedskies/fx.tsx
function Lt({ at: e, style: t, ms: i }) {
	let a = r(null);
	return n(() => {
		let e = a.current;
		if (!e) return;
		let n = e.animate(t === "roll" ? [{
			transform: "rotate(-45deg) scale(.7)",
			opacity: .8
		}, {
			transform: "rotate(0deg) scale(1)",
			opacity: 0
		}] : [{
			transform: "perspective(500px) rotateX(0deg)",
			opacity: .85
		}, {
			transform: "perspective(500px) rotateX(85deg)",
			opacity: 0
		}], {
			duration: i,
			easing: "ease-out",
			fill: "both"
		});
		return () => n.cancel();
	}, [t, i]), /* @__PURE__ */ d("div", {
		ref: a,
		className: "bs-fx-reveal",
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			border: "2px solid #f4e6bd",
			borderRadius: 8,
			background: t === "cloud" ? "#c6dcdf" : "#f3d29a66",
			transformOrigin: "top"
		}
	});
}
var Rt = {
	bsTrack: (e, t) => {
		let n = e.data, r = t.anchor(`bs/trackCell/${n.track}/${n.from}`), i = t.anchor(`bs/trackToken/${e.rid}/${n.track}`);
		if (!r?.w || !r.h || !i?.w || !i.h) return null;
		let a = t.queued ? 140 : 340, s = e.rid === "$automa" ? "#756883" : o[(t.member(e.rid ?? "")?.colorIndex ?? 0) % o.length].hex;
		return {
			ms: a,
			hide: t.queued ? void 0 : [`bs/trackToken/${e.rid}/${n.track}`],
			node: /* @__PURE__ */ d(m, {
				from: {
					x: r.x + r.w / 2 - i.w / 2,
					y: r.y + r.h - i.h,
					w: i.w,
					h: i.h
				},
				to: i,
				ms: a,
				children: /* @__PURE__ */ d("div", { style: {
					width: i.w,
					height: i.h,
					borderRadius: "50%",
					background: s,
					boxShadow: "0 0 0 1px #fff"
				} })
			})
		};
	},
	bsFly: (e, t) => {
		let n = e.data, r = t.anchor(n.from), i = r?.w && r?.h ? r : t.anchor(n.from.replace("/ship/", "/fleet/")), a = t.anchor(n.to);
		if (!i || !a || !i.w || !i.h || !a.w || !a.h) return null;
		let o = /^(?:[csaoe]\d+|start\d+)$/.test(n.sprite), s = t.queued ? 140 : 340, c = o ? 70 : 32, l = (e) => ({
			x: e.x + (e.w - c) / 2,
			y: e.y + (e.h - c) / 2,
			w: c,
			h: o ? c * .7 : c
		});
		return {
			ms: s,
			hide: t.queued ? void 0 : [n.to],
			node: /* @__PURE__ */ d(m, {
				from: l(i),
				to: l(a),
				ms: s,
				children: /* @__PURE__ */ d("div", {
					className: "bs-fx-sprite",
					style: {
						width: c,
						height: o ? c * .7 : c
					},
					children: o ? /* @__PURE__ */ d("img", {
						src: K(n.sprite),
						alt: ""
					}) : /* @__PURE__ */ d(q, { id: n.sprite })
				})
			})
		};
	},
	bsReveal: (e, t) => {
		let n = e.data, r = t.anchor(n.anchor);
		if (!r || !r.w || !r.h) return null;
		let i = t.queued ? 140 : 400;
		return {
			ms: i,
			node: n.style === "pulse" ? /* @__PURE__ */ d(te, {
				at: r,
				ms: i
			}) : /* @__PURE__ */ d(Lt, {
				at: r,
				style: n.style,
				ms: i
			})
		};
	}
};
//#endregion
//#region src/games/braidedskies/game-over.tsx
function zt(e) {
	let t = e.public, n = wt(), r = ee(), [a, o] = i(!0), [s, c] = i(null), l = (t) => t === "$automa" ? n.text("automa") : e.members.find((e) => e.rid === t)?.name ?? t, u = (e.result.ranking ?? t.players.filter((e) => !e.automa).map((e) => e.rid)).map((e) => t.players.find((t) => t.rid === e)).filter(Boolean), p = t.players.find((e) => e.automa);
	p && u.push(p);
	let m = e.result.winner?.length ? e.result.winner : p ? ["$automa"] : [];
	return /* @__PURE__ */ f("div", {
		className: "bs-app bs-ending",
		children: [
			/* @__PURE__ */ d(kt, {
				public: t,
				private: { choices: [] },
				members: e.members,
				myRid: e.myRid,
				send: () => {}
			}),
			!a && /* @__PURE__ */ d("button", {
				className: "bs-ledger-reopen bs-action",
				onClick: () => o(!0),
				children: n.text("viewLedger")
			}),
			a && /* @__PURE__ */ d("div", {
				className: "bs-ledger-shade",
				children: /* @__PURE__ */ f("section", {
					className: "bs-ledger",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": n.text("ledger"),
					children: [/* @__PURE__ */ d("img", {
						className: "bs-ledger-art",
						src: K("a8"),
						alt: ""
					}), /* @__PURE__ */ f("div", {
						className: "bs-ledger-content",
						children: [
							/* @__PURE__ */ f("div", {
								className: "bs-ledger-title",
								children: [/* @__PURE__ */ f("div", { children: [
									/* @__PURE__ */ d("small", { children: n.text("name") }),
									/* @__PURE__ */ d("h1", { children: n.text("ledger") }),
									/* @__PURE__ */ d("h2", { children: n.text("winner", { name: m.map(l).join(" / ") }) })
								] }), /* @__PURE__ */ d("button", {
									className: "bs-action",
									onClick: () => o(!1),
									children: n.text("viewBoard")
								})]
							}),
							/* @__PURE__ */ d("div", {
								className: "bs-score-scroll",
								children: /* @__PURE__ */ f("table", {
									className: "bs-score-table",
									children: [/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: n.text("score") }), u.map((e) => /* @__PURE__ */ f("th", { children: [l(e.rid), m.includes(e.rid) && /* @__PURE__ */ d(q, { id: "captain" })] }, e.rid))] }) }), /* @__PURE__ */ f("tbody", { children: [
										/* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: n.text("fame") }), u.map((e) => /* @__PURE__ */ d("td", { children: e.score.fame }, e.rid))] }),
										/* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ f("th", { children: [/* @__PURE__ */ d(q, { id: "h" }), n.text("heritage")] }), u.map((e) => /* @__PURE__ */ d("td", { children: e.score.heritage }, e.rid))] }),
										v.map((e, t) => /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ f("th", { children: [/* @__PURE__ */ d(q, { id: e }), n.track(e)] }), u.map((e) => /* @__PURE__ */ f("td", { children: [e.score.tracks[t], /* @__PURE__ */ d("small", { children: n.text("trackPosition", { n: e.tracks[t] }) })] }, e.rid))] }, e)),
										p && /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: n.text("automaScore") }), u.map((e) => /* @__PURE__ */ d("td", { children: e.score.automa }, e.rid))] }),
										/* @__PURE__ */ f("tr", {
											className: "bs-score-total",
											children: [/* @__PURE__ */ d("th", { children: n.text("total") }), u.map((e) => /* @__PURE__ */ d("td", { children: e.score.total }, e.rid))]
										})
									] })]
								})
							}),
							/* @__PURE__ */ d("p", { children: n.text("tieInfo") }),
							/* @__PURE__ */ f("div", {
								className: "bs-ledger-buttons",
								children: [
									e.onPlayAgain && /* @__PURE__ */ d("button", {
										className: "bs-action",
										onClick: () => c("again"),
										children: r("session.result.playAgain")
									}),
									e.onBackToLobby && /* @__PURE__ */ d("button", {
										className: "bs-action",
										onClick: () => c("leave"),
										children: r("session.result.backToLobby")
									}),
									!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ d("p", { children: n.text("waitingHost") })
								]
							}),
							s && /* @__PURE__ */ f("div", {
								className: "bs-ending-confirm",
								children: [
									/* @__PURE__ */ d("p", { children: n.text(s === "again" ? "confirmAgain" : "confirmLeave") }),
									/* @__PURE__ */ d("button", {
										className: "bs-action",
										onClick: () => c(null),
										children: n.text("cancel")
									}),
									/* @__PURE__ */ d("button", {
										className: "bs-action",
										onClick: () => s === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.(),
										children: n.text("confirm")
									})
								]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
//#region src/games/braidedskies/options.tsx
function Bt({ value: e, onChange: t }) {
	let n = wt(), r = ve.safeParse(e), i = r.success ? r.data : ve.parse(void 0);
	return /* @__PURE__ */ f("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ d("p", { children: n.text("soloOnly") }),
			/* @__PURE__ */ d(g, {
				title: n.text("optionsSolo"),
				columns: 3,
				children: [
					0,
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ d(h, {
					name: "braided-level",
					value: String(e),
					checked: i.soloLevel === e,
					label: n.text(`level${e}`),
					accent: _e.accent,
					onChange: () => t({
						...i,
						soloLevel: e
					})
				}, e))
			}),
			/* @__PURE__ */ d(g, {
				title: n.text("optionsStart"),
				columns: 2,
				children: [
					-1,
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ d(h, {
					name: "braided-start",
					value: String(e),
					checked: i.automaStart === e,
					label: e < 0 ? n.text("random") : pe[e][n.lang],
					accent: _e.accent,
					onChange: () => t({
						...i,
						automaStart: e
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/braidedskies/entry.tsx
var Vt = {
	definition: vt,
	View: kt,
	bot: It,
	fx: Rt,
	OverView: zt,
	Options: Bt,
	Guide: Tt,
	locales: {
		zh: bt,
		en: {
			trackPosition: "Space {{n}}",
			dice: "harvest dice",
			details: "Details",
			discardPile: "Discard pile",
			ready: "Ready",
			installShort: "Install outfitting",
			takeShort: "Take outfitting",
			sail: "Deploy ship",
			close: "Close",
			costShort: "Cost",
			instantShort: "Instant",
			inactive: "Dormant ability",
			activateShort: "Activate",
			wonderPorts: "Wonder ports",
			ledger: "Voyage ledger",
			viewBoard: "View the final board",
			viewLedger: "View voyage ledger",
			winner: "Winner: {{name}}",
			tieInfo: "Ties: tapstones, then wonders, then grit.",
			confirmAgain: "Start another game?",
			confirmLeave: "Return to the lobby?",
			confirm: "Confirm",
			cancel: "Cancel",
			waitingHost: "Waiting for the host to start another game.",
			total: "Total fame",
			name: "Braided Skies",
			desc: "Pilot drop ships into the clouds, harvest tapstones and build a tourism company in the Northlands.",
			rules: "Goal and setup:\nEarn the most fame. Each player has 3 drop ships, a random player mat, a starting wonder, 2 grit, one tapstone of each color and 1 face-up encounter. There are 9 wonders of each type, 36 outfittings and 25 encounters. Cloud tiles and outposts are randomized. This implementation follows the official 2026 base game rulebook r12 and Automa r5.\nTurns:\nDeploy one ship from your mat or recall all deployed ships. With all three deployed you must recall. Top-level collection ports and all wonder and specialized ports have unlimited capacity. Middle and deep collection ports hold only one ship. Collection ports require their matching ship; other ports accept any ship.\nCollection and exploration:\nIf your deployed ship already has a crewmate or harvester, remove one vertically adjacent cloud tile below that port and resolve the event. Add a random outpost tile to a newly revealed location. A top port reveals the adjacent middle port; a middle port successively removes the large and small tiles over the deep port. Resolve core benefits and leftovers, harvester benefits, then your outpost. Put all gained resources in the deployed ship’s cargo hold. Transfer them into empty outfitting slots: the same row is free, each resource transferred to another row costs 1 grit. Existing tokens cannot be replaced. Leave all unplaced cargo at the visited port. Supplies are limited to 20 of each resource.\nWonder ports:\nPay the top card’s cost from anywhere on your mat. First gain the ship’s crewmate cross-track benefit, then leftover fame, acquire the card and resolve its instant advances. Only your starting and latest wonder abilities are active; symbols on all wonders remain. Abilities marked with a captain action require your captain during recall. Unmarked abilities are ongoing. A reroll ability allows each harvest die to be rerolled once.\nSpecialized ports:\n· Tomtom Festival costs 4 tourists and awards 9 fame plus one advance on each track; a harvester adds one advance on any track and a crewmate scores your culinary symbols.\n· The Underground Market exchanges any 2 resources, 2 matching resources or any 3 resources for 2, 3 or 4 fame; a harvester adds 2 grit, a crewmate one advance on any track.\n· Free Flyer’s Guild costs 1 grit and 1 yellow tapstone to take a market outfitting; optionally cycle card 4 once before selecting; a crewmate draws an encounter.\n· Thunder’s Workshop costs 1 grit and 1 blue tapstone to install a harvester on any ship; an existing crewmate on the visiting ship advances any track.\n· Cracked Flagon costs 1 grit and 1 red tapstone to install a crewmate; an existing harvester on the visiting ship gains 2 grit.\nNewly installed upgrades do not grant retroactive arrival bonuses.\nOutfittings and recall:\nInstall an outfitting in the leftmost empty space of any row and gain the covered track advancement; the third outfitting in a row also gives 1 grit. Each row holds at most 3, including the printed outfitting. Recall ships in any order. On recalling each ship, activate that row’s fully filled outfittings in any order, at most once each, paying any grit cost. Resources are not consumed. Resources gained during recall must immediately fill an empty slot in any row for free, or are not gained. Each crewmate may fill one empty resource or crewmate slot in its own row; your captain may fill any row’s empty slot or visit one active wonder action. Each pawn is used once per recall. Return all pawns after completing the recall. Grit is capped at 8.\nEncounters and outposts:\nEncounters are public. Play up to 2 on your turn at any decision, including cards just gained. Choose A or B, meeting B’s port condition and grit cost. Gained resources immediately cover a payment or fill empty slots. Build up to 6 outposts at revealed collection ports, at most one of your own at each; different players may share locations. Resolve their printed resource, encounter, itinerary-symbol or crewmate fame reward.\nWonder tracks:\nGain bonuses immediately.\n· Culture: at space 3, draw an outfitting. At spaces 4 and 9, draw an encounter. At space 6, score 4 fame, plus 5 fame if you have at least one culture, scenic, adventure and culinary symbol. At space 11, score 6 fame plus fame equal to your culinary-symbol count.\n· Scenic: at space 3, install a harvester. At spaces 4 and 9, build an outpost. At space 6, score 4 fame plus fame equal to your total crewmates and harvesters. At space 11, score 6 fame plus fame equal to your built outposts.\n· Adventure: at spaces 1 and 4, gain 1 grit. At space 3, install a crewmate. At space 6, score 6 fame, plus 5 fame if you have at least 6 grit. At space 9, gain 2 grit. At space 11, score 6 fame, plus 5 fame if you have acquired all three ordinary wonder types.\nSpace 13 on each track scores 4 fame. Further advancement at the top has no effect.\nGame end and scoring:\nTrigger the end when anyone reaches 60 fame or 7 itinerary wonders, or when each track has at least one token at space 11. Finish the current round and play one more full round. Heritage leaders score 16, 10 and 6; tied players share the sum of occupied awards, rounded down. No heritage means no award. Culture scores scenic symbols, scenic scores adventure symbols and adventure scores culture symbols. Multiply by 1 at spaces 0–3, 2 at 4–7, 3 at 8–11 or 4 at 12–13. Add these awards to earned fame. Ties favor more tapstones (excluding tourists), then more wonders, then more grit; otherwise share victory.\nSolo Automa:\nWith one human, add the official Automa and alternate turns, human first. Automa has a starting wonder and a fixed wonder. Her 12 action cards select the ship, port, track and bonus port. She pays no usual deployment costs. Collection gains 1 resource and 1 advance without upgrades, or 2 of each with either upgrade. At a wonder port, with fewer than 4 resources gain 3 fame and advance once plus once per installed upgrade; otherwise pay 4 resources to acquire the wonder and resolve its instant advances. She never gains immediate track bonuses. Collect leftovers at the deployed and bonus ports; gain the indicated free upgrade or discard market cards 3 and 4 at the Guild. Exploration replaces the cloud’s left reward with 3 fame; she ignores “all players may” trades. Recall all three deployed ships, or two when the card says so, and resolve her starting wonder’s recall benefit. Score normally, plus 2 per culinary symbol and 1 per remaining resource. Easiest ignores leftover fame. Easier uses the Workshop Visit with only a heritage symbol. Normal and harder use Factory Tour with one of each symbol. Harder levels successively add 3 starting fame and one or two starting crewmates. Her first tiebreaker counts all resources; she has no grit.",
			errorFinished: "This game has finished.",
			errorTurn: "Please wait for your turn.",
			errorChoice: "That choice is no longer available.",
			round: "Round {{n}}",
			lastRound: "Final round: {{n}}",
			waiting: "Waiting for {{name}}",
			resolving: "Resolving",
			choose: "Choose an action",
			done: "Game over",
			automa: "Automa",
			board: "Clouds and ports",
			company: "Tourism company",
			itinerary: "Itinerary",
			encounters: "Encounters",
			market: "Outfitting market",
			supply: "Supply",
			fame: "Fame",
			grit: "Grit",
			score: "Current total",
			heritage: "Heritage award",
			trackScore: "Track awards",
			automaScore: "Automa bonuses",
			ship: "Drop ship",
			crew: "Crewmate",
			harvester: "Harvester",
			captain: "Captain",
			any: "Any resource",
			empty: "Empty slot",
			filled: "Contains {{name}}",
			slot: "Slot {{n}}",
			outfit: "Outfitting",
			used: "Activated",
			home: "At company",
			deployed: "At {{name}}",
			unexplored: "Unexplored",
			blocked: "Occupied",
			unlimited: "Unlimited",
			single: "One ship only",
			outpost: "Outpost",
			none: "None",
			deploy: "Deploy {{ship}} to {{port}}",
			recall: "Recall all deployed ships",
			recallRow: "Recall {{ship}}",
			pay: "Pay {{resource}} ({{ship}} · {{card}} · slot {{n}})",
			payPocket: "Pay newly gained {{resource}}",
			place: "Place {{resource}} in {{ship}} · {{card}} · slot {{n}}",
			resource: "Gain {{resource}}",
			track: "Advance once on {{track}}",
			build: "Build an outpost at {{port}}",
			activateOutpost: "Activate the outpost at {{port}}",
			upgrade: "Install {{name}} on {{ship}}",
			selectOutfit: "Take {{card}}",
			install: "Install {{card}} in {{ship}} row",
			activate: "Activate {{card}} in {{ship}} row",
			captainSlot: "Place captain in {{ship}} · {{card}} · slot {{n}}",
			crewSlot: "Place crewmate in {{ship}} · {{card}} · slot {{n}}",
			captainWonder: "Send captain to {{card}}",
			encounter: "Play {{card}} · {{option}}: {{effect}}",
			costGrit: "Pay {{n}} grit",
			requiresPort: "Visited {{port}} this turn",
			skip: "Decline",
			cycle: "Cycle market card 4",
			endRow: "Finish this row",
			endRecall: "Complete recall",
			discard: "Leave remaining cargo at the port",
			finish: "End turn",
			trade: "Pay {{n}} grit for {{n}} fame",
			keepDie: "Keep die: {{name}}",
			reroll: "Reroll this die",
			roll: "Roll one harvest die",
			directPayment: "Use this resource for the next payment",
			keepEncounter: "Keep {{card}}",
			cloudPort: "Add 2 fame to {{port}}",
			promptTurn: "Choose a ship and port, or recall ships",
			promptPay: "Select resources to pay, one at a time",
			promptPlace: "Choose a resource slot",
			promptResource: "Choose a resource to gain",
			promptHarvest: "Choose the harvester benefit",
			promptTrack: "Choose a wonder track",
			promptOutpost: "Choose an outpost location",
			promptOutpostChoice: "Build an outpost or advance a track",
			promptUpgrade: "Choose a ship to upgrade",
			promptOutfitSelect: "Choose a market outfitting",
			promptOutfitPlace: "Choose an outfitting row",
			promptRecall: "Choose the next ship to recall",
			promptRow: "Activate this row; use your captain and crewmates to fill slots",
			promptTrade: "Choose how much grit to trade",
			promptCloudChoice: "Choose the cloud reward",
			promptKeepEncounter: "Inspect two encounters and keep one",
			promptDice: "Confirm the harvest die",
			promptCloudPort: "Choose a wonder port to receive fame",
			promptEnd: "Play encounters or end your turn",
			effectStone: "Gain any 1 tapstone and place it on your mat.",
			effectResource: "Gain any 1 resource and place it on your mat.",
			effectTourist: "Gain 1 tourist.",
			effectGrit2: "Gain 2 grit.",
			effectGrit3: "Gain 3 grit.",
			effectFame3: "Gain 3 fame.",
			effectAny: "Advance once on any wonder track.",
			effectAny2: "Advance twice on any wonder tracks.",
			effectBuild: "Build 1 outpost.",
			effectOutpostChoice: "Build 1 outpost or advance once on any track.",
			effectOutpostFame: "Score 1 fame per built outpost.",
			effectOutpostActivate: "Activate any one of your outposts.",
			effectFoodFame: "Score 1 fame per culinary symbol.",
			effectTrade: "Pay any amount of grit to score that much fame.",
			effectReroll: "You may reroll each harvest die once.",
			effectGuildEncounter: "Draw an encounter after deploying to Free Flyer’s Guild.",
			effectFlagonEncounter: "Draw an encounter after deploying to Cracked Flagon.",
			effectWorkshopEncounter: "Draw an encounter after deploying to Thunder’s Workshop.",
			effectMarketFame: "Score 2 fame after deploying to the Underground Market.",
			effectOutfit: "Draw and install 1 outfitting from the deck.",
			effectCount: "Score 1 fame per remaining {{resource}}.",
			effectAdvance: "Advance once on {{track}}.",
			start1: "Advance adventure once; score 1 fame per unplayed encounter.",
			start2: "Advance adventure once; score 1 fame per built outpost.",
			start3: "Advance culture once; score 1 fame per two-slot outfitting card.",
			start4: "Advance culture once; score 2 fame per crewmate.",
			start5: "Advance scenic once; score 1 fame per tourist.",
			start6: "Advance scenic once; score 2 fame per harvester.",
			start7: "Advance any track once; score 2 fame per heritage symbol.",
			instant: "Instant: {{value}}",
			cost: "Cost: {{value}}",
			captainAction: "Captain action",
			passive: "Ongoing ability",
			symbols: "Itinerary symbols",
			remaining: "Remaining payment: {{value}}",
			cargo: "Cargo: {{value}}",
			finalBreakdown: "Fame {{fame}}, heritage {{heritage}}, tracks {{tracks}}, bonus {{automa}}",
			portTop: "Gain 1 {{resource}} and 1 grit; harvester: {{bonus}} or one harvest die.",
			portMiddle: "Gain 1 {{resource}} and roll one harvest die; harvester: {{resource}} or one harvest die.",
			portDeep: "Gain 1 {{resource}} and roll two harvest dice; harvester: {{resource}} or 1 tourist.",
			wonderPort: "Pay for the top wonder and acquire it; crewmate: advance {{track}} once.",
			festivalPort: "Pay 4 tourists for 9 fame and advance every track once; harvester: advance any track; crewmate: score culinary symbols.",
			marketPort: "Pay any 2, matching 2 or any 3 resources for 2, 3 or 4 fame; harvester: 2 grit; crewmate: advance any track.",
			guildPort: "Pay 1 grit and 1 yellow tapstone for a market outfitting; crewmate: draw an encounter.",
			workshopPort: "Pay 1 grit and 1 blue tapstone to install a harvester; crewmate: advance any track.",
			flagonPort: "Pay 1 grit and 1 red tapstone to install a crewmate; harvester: gain 2 grit.",
			outpostSymbols: "Score 1 fame per {{name}} symbol.",
			outpostCrew: "Score 1 fame per crewmate.",
			outpostEncounter: "Draw 1 encounter.",
			cloud: "Cloud event {{id}}",
			cloudReward: "Explorer reward",
			cloudRight: "Shared changes",
			cloudDrawKeep: "Draw 2 encounters and keep 1.",
			cloudEncounterGrit: "Gain 1 encounter or 2 grit.",
			cloudEncounterTrack: "Gain 1 encounter or advance any track once.",
			cloudTwoFame: "Score 2 fame.",
			cloudThreeFame: "Score 3 fame.",
			cloudPublicFame: "Add {{n}} fame to each of {{ports}}.",
			cloudPublicResource: "Add {{n}} {{resource}} to each revealed port in {{ports}}.",
			cloudPublicTrade: "All players may pay grit for fame, one for one.",
			log: "Action log",
			logDeploy: "{{name}} deployed {{ship}} to {{port}}",
			logRecall: "{{name}} recalled {{ship}}",
			logFame: "{{name}} gained {{n}} fame",
			logAdvance: "{{name}} reached {{track}} space {{n}}",
			logWonder: "{{name}} acquired {{card}}",
			logOutfit: "{{name}} installed {{card}} in {{ship}} row",
			logActivate: "{{name}} activated {{card}}",
			logOutpost: "{{name}} built an outpost at {{port}}",
			logUpgrade: "{{name}} installed {{value}} on {{ship}}",
			logEncounter: "{{name}} drew {{n}} encounters",
			logPlayEncounter: "{{name}} played {{card}} option {{option}}",
			logCloud: "{{name}} revealed {{id}}",
			optionsSolo: "Solo Automa difficulty",
			level0: "Easiest",
			level1: "Easier",
			level2: "Normal",
			level3: "Hard",
			level4: "Harder",
			level5: "Hardest",
			optionsStart: "Automa starting wonder",
			random: "Random",
			soloOnly: "These settings apply only to the official single-player Automa.",
			automaFactory: "Automa Factory Tour",
			automaWorkshop: "Automa Workshop Visit",
			automaTurn: "Action card {{n}}",
			automaRecall1: "Recall: gain 3 fame, 1 resource and one advance on each track.",
			automaRecall2: "Recall: gain 2 fame and 3 resources.",
			automaRecall3: "Recall: gain 3 fame plus 2 per heritage symbol.",
			automaRecall4: "Recall: gain 3 fame plus 1 per culinary symbol.",
			help: "Card and track reference",
			trackInfo: "Culture scores scenic, scenic scores adventure, adventure scores culture. Spaces 4, 8 and 12 raise the multiplier; space 11 contributes to the end trigger.",
			availableActions: "Available actions",
			otherActions: "Captain, crewmates and encounters",
			inspect: "View company",
			yourCompany: "Your company"
		}
	}
};
//#endregion
export { Vt as default };
