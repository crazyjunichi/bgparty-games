import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as i } from "@bgparty/sdk/fx/delta-number";
import { useT as a } from "@bgparty/sdk/i18n";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { IconClose as s, IconInfo as c } from "@bgparty/sdk/icons";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Floater as m, FlySprite as h, PulseBox as g } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as _ } from "@bgparty/sdk/confirm-button";
//#region src/games/bearnecessities/data.ts
var v = [
	{
		id: 0,
		english: "Baby Beaver",
		color: "water",
		types: ["animal"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c0.name",
		textKey: "games.bearnecessities.c0.effect"
	},
	{
		id: 1,
		english: "Beaver Dad",
		color: "water",
		types: ["animal"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c1.name",
		textKey: "games.bearnecessities.c1.effect"
	},
	{
		id: 2,
		english: "Beaver Mom",
		color: "water",
		types: ["animal"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c2.name",
		textKey: "games.bearnecessities.c2.effect"
	},
	{
		id: 3,
		english: "Fish",
		color: "water",
		types: ["animal"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c3.name",
		textKey: "games.bearnecessities.c3.effect"
	},
	{
		id: 4,
		english: "Fish",
		color: "water",
		types: ["animal"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c4.name",
		textKey: "games.bearnecessities.c4.effect"
	},
	{
		id: 5,
		english: "Fish",
		color: "water",
		types: ["animal"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c5.name",
		textKey: "games.bearnecessities.c5.effect"
	},
	{
		id: 6,
		english: "Fish",
		color: "water",
		types: ["animal"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c6.name",
		textKey: "games.bearnecessities.c6.effect"
	},
	{
		id: 7,
		english: "Fish",
		color: "water",
		types: ["animal"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c7.name",
		textKey: "games.bearnecessities.c7.effect"
	},
	{
		id: 8,
		english: "Fish",
		color: "water",
		types: ["animal"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c8.name",
		textKey: "games.bearnecessities.c8.effect"
	},
	{
		id: 9,
		english: "Fish",
		color: "water",
		types: ["animal"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c9.name",
		textKey: "games.bearnecessities.c9.effect"
	},
	{
		id: 10,
		english: "Fish",
		color: "water",
		types: ["animal"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c10.name",
		textKey: "games.bearnecessities.c10.effect"
	},
	{
		id: 11,
		english: "Fishing Cabin",
		color: "water",
		types: ["building"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c11.name",
		textKey: "games.bearnecessities.c11.effect"
	},
	{
		id: 12,
		english: "Harbor",
		color: "water",
		types: ["building"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c12.name",
		textKey: "games.bearnecessities.c12.effect"
	},
	{
		id: 13,
		english: "Lighthouse",
		color: "water",
		types: ["building"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c13.name",
		textKey: "games.bearnecessities.c13.effect"
	},
	{
		id: 14,
		english: "Binoculars",
		color: "water",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c14.name",
		textKey: "games.bearnecessities.c14.effect"
	},
	{
		id: 15,
		english: "Chest",
		color: "water",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c15.name",
		textKey: "games.bearnecessities.c15.effect"
	},
	{
		id: 16,
		english: "Collector",
		color: "water",
		types: ["bear"],
		hives: 0,
		goal: !0,
		glasses: !0,
		nameKey: "games.bearnecessities.c16.name",
		textKey: "games.bearnecessities.c16.effect"
	},
	{
		id: 17,
		english: "Diver",
		color: "water",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !0,
		nameKey: "games.bearnecessities.c17.name",
		textKey: "games.bearnecessities.c17.effect"
	},
	{
		id: 18,
		english: "Fisherbear",
		color: "water",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c18.name",
		textKey: "games.bearnecessities.c18.effect"
	},
	{
		id: 19,
		english: "Spy",
		color: "water",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !0,
		nameKey: "games.bearnecessities.c19.name",
		textKey: "games.bearnecessities.c19.effect"
	},
	{
		id: 20,
		english: "Reed",
		color: "water",
		types: ["plant"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c20.name",
		textKey: "games.bearnecessities.c20.effect"
	},
	{
		id: 21,
		english: "Reed",
		color: "water",
		types: ["plant"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c21.name",
		textKey: "games.bearnecessities.c21.effect"
	},
	{
		id: 22,
		english: "Water Lily",
		color: "water",
		types: ["plant"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c22.name",
		textKey: "games.bearnecessities.c22.effect"
	},
	{
		id: 24,
		english: "Coyote",
		color: "desert",
		types: ["animal"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c24.name",
		textKey: "games.bearnecessities.c24.effect"
	},
	{
		id: 25,
		english: "Queen Bee",
		color: "desert",
		types: ["animal"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c25.name",
		textKey: "games.bearnecessities.c25.effect"
	},
	{
		id: 26,
		english: "Big Trading Post",
		color: "desert",
		types: ["building"],
		hives: 1,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c26.name",
		textKey: "games.bearnecessities.c26.effect"
	},
	{
		id: 27,
		english: "CIA Headquarters",
		color: "desert",
		types: ["building"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c27.name",
		textKey: "games.bearnecessities.c27.effect"
	},
	{
		id: 28,
		english: "Rock Shelter",
		color: "desert",
		types: ["building"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c28.name",
		textKey: "games.bearnecessities.c28.effect"
	},
	{
		id: 29,
		english: "Small Trading Post",
		color: "desert",
		types: ["building"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c29.name",
		textKey: "games.bearnecessities.c29.effect"
	},
	{
		id: 30,
		english: "Trading Post",
		color: "desert",
		types: ["building"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c30.name",
		textKey: "games.bearnecessities.c30.effect"
	},
	{
		id: 31,
		english: "Bearbecue",
		color: "desert",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c31.name",
		textKey: "games.bearnecessities.c31.effect"
	},
	{
		id: 32,
		english: "Binoculars",
		color: "desert",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c32.name",
		textKey: "games.bearnecessities.c32.effect"
	},
	{
		id: 33,
		english: "Compass",
		color: "desert",
		types: ["item"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c33.name",
		textKey: "games.bearnecessities.c33.effect"
	},
	{
		id: 34,
		english: "Secret Honey Stash",
		color: "desert",
		types: ["item"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c34.name",
		textKey: "games.bearnecessities.c34.effect"
	},
	{
		id: 35,
		english: "Signpost",
		color: "desert",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c35.name",
		textKey: "games.bearnecessities.c35.effect"
	},
	{
		id: 36,
		english: "Water Canteen",
		color: "desert",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c36.name",
		textKey: "games.bearnecessities.c36.effect"
	},
	{
		id: 37,
		english: "Explorer",
		color: "desert",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c37.name",
		textKey: "games.bearnecessities.c37.effect"
	},
	{
		id: 38,
		english: "Photographer",
		color: "desert",
		types: ["bear"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c38.name",
		textKey: "games.bearnecessities.c38.effect"
	},
	{
		id: 39,
		english: "Spy",
		color: "desert",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !0,
		nameKey: "games.bearnecessities.c39.name",
		textKey: "games.bearnecessities.c39.effect"
	},
	{
		id: 40,
		english: "Spy",
		color: "desert",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !0,
		nameKey: "games.bearnecessities.c40.name",
		textKey: "games.bearnecessities.c40.effect"
	},
	{
		id: 41,
		english: "Treasure Hunter",
		color: "desert",
		types: ["bear"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c41.name",
		textKey: "games.bearnecessities.c41.effect"
	},
	{
		id: 42,
		english: "Cactus",
		color: "desert",
		types: ["plant"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c42.name",
		textKey: "games.bearnecessities.c42.effect"
	},
	{
		id: 43,
		english: "Sunflower",
		color: "desert",
		types: ["plant"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c43.name",
		textKey: "games.bearnecessities.c43.effect"
	},
	{
		id: 44,
		english: "Yucca",
		color: "desert",
		types: ["plant"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c44.name",
		textKey: "games.bearnecessities.c44.effect"
	},
	{
		id: 46,
		english: "Cat",
		color: "city",
		types: ["animal"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c46.name",
		textKey: "games.bearnecessities.c46.effect"
	},
	{
		id: 47,
		english: "Dog",
		color: "city",
		types: ["animal"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c47.name",
		textKey: "games.bearnecessities.c47.effect"
	},
	{
		id: 48,
		english: "Pigeon",
		color: "city",
		types: ["animal"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c48.name",
		textKey: "games.bearnecessities.c48.effect"
	},
	{
		id: 49,
		english: "Cellar",
		color: "city",
		types: ["building"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c49.name",
		textKey: "games.bearnecessities.c49.effect"
	},
	{
		id: 50,
		english: "Factory",
		color: "city",
		types: ["building"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c50.name",
		textKey: "games.bearnecessities.c50.effect"
	},
	{
		id: 51,
		english: "Suburban Apartments",
		color: "city",
		types: ["building"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c51.name",
		textKey: "games.bearnecessities.c51.effect"
	},
	{
		id: 52,
		english: "Station",
		color: "city",
		types: ["building"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c52.name",
		textKey: "games.bearnecessities.c52.effect"
	},
	{
		id: 53,
		english: "Tourist Office",
		color: "city",
		types: ["building"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c53.name",
		textKey: "games.bearnecessities.c53.effect"
	},
	{
		id: 54,
		english: "Town Hall",
		color: "city",
		types: ["building"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c54.name",
		textKey: "games.bearnecessities.c54.effect"
	},
	{
		id: 55,
		english: "Rubber Duck",
		color: "city",
		types: ["item", "animal"],
		hives: 2,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c55.name",
		textKey: "games.bearnecessities.c55.effect"
	},
	{
		id: 56,
		english: "Binoculars",
		color: "city",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c56.name",
		textKey: "games.bearnecessities.c56.effect"
	},
	{
		id: 57,
		english: "Streetlight",
		color: "city",
		types: ["item"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c57.name",
		textKey: "games.bearnecessities.c57.effect"
	},
	{
		id: 58,
		english: "Statue",
		color: "city",
		types: ["item", "bear"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c58.name",
		textKey: "games.bearnecessities.c58.effect"
	},
	{
		id: 59,
		english: "Actor",
		color: "city",
		types: ["bear"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c59.name",
		textKey: "games.bearnecessities.c59.effect"
	},
	{
		id: 60,
		english: "Architect",
		color: "city",
		types: ["bear"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c60.name",
		textKey: "games.bearnecessities.c60.effect"
	},
	{
		id: 61,
		english: "Banker",
		color: "city",
		types: ["bear"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c61.name",
		textKey: "games.bearnecessities.c61.effect"
	},
	{
		id: 62,
		english: "Football Player",
		color: "city",
		types: ["bear"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c62.name",
		textKey: "games.bearnecessities.c62.effect"
	},
	{
		id: 63,
		english: "Bearlet",
		color: "city",
		types: ["bear"],
		hives: 1,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c63.name",
		textKey: "games.bearnecessities.c63.effect"
	},
	{
		id: 64,
		english: "Optician",
		color: "city",
		types: ["bear"],
		hives: 1,
		goal: !1,
		glasses: !0,
		nameKey: "games.bearnecessities.c64.name",
		textKey: "games.bearnecessities.c64.effect"
	},
	{
		id: 65,
		english: "Sergeant",
		color: "city",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c65.name",
		textKey: "games.bearnecessities.c65.effect"
	},
	{
		id: 66,
		english: "Spy",
		color: "city",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !0,
		nameKey: "games.bearnecessities.c66.name",
		textKey: "games.bearnecessities.c66.effect"
	},
	{
		id: 67,
		english: "Window Cleaner",
		color: "city",
		types: ["bear"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c67.name",
		textKey: "games.bearnecessities.c67.effect"
	},
	{
		id: 68,
		english: "Planter Box",
		color: "city",
		types: ["plant"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c68.name",
		textKey: "games.bearnecessities.c68.effect"
	},
	{
		id: 69,
		english: "Rose",
		color: "city",
		types: ["plant"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c69.name",
		textKey: "games.bearnecessities.c69.effect"
	},
	{
		id: 71,
		english: "Eagle",
		color: "mountain",
		types: ["animal"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c71.name",
		textKey: "games.bearnecessities.c71.effect"
	},
	{
		id: 72,
		english: "Mountain Goat",
		color: "mountain",
		types: ["animal"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c72.name",
		textKey: "games.bearnecessities.c72.effect"
	},
	{
		id: 73,
		english: "Snake",
		color: "mountain",
		types: ["animal"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c73.name",
		textKey: "games.bearnecessities.c73.effect"
	},
	{
		id: 74,
		english: "Lookout Tower",
		color: "mountain",
		types: ["building"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c74.name",
		textKey: "games.bearnecessities.c74.effect"
	},
	{
		id: 75,
		english: "Research Lab",
		color: "mountain",
		types: ["building"],
		hives: 1,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c75.name",
		textKey: "games.bearnecessities.c75.effect"
	},
	{
		id: 76,
		english: "Visitor Center",
		color: "mountain",
		types: ["building"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c76.name",
		textKey: "games.bearnecessities.c76.effect"
	},
	{
		id: 77,
		english: "Backpack",
		color: "mountain",
		types: ["item"],
		hives: 0,
		goal: !0,
		glasses: !1,
		nameKey: "games.bearnecessities.c77.name",
		textKey: "games.bearnecessities.c77.effect"
	},
	{
		id: 78,
		english: "Binoculars",
		color: "mountain",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c78.name",
		textKey: "games.bearnecessities.c78.effect"
	},
	{
		id: 79,
		english: "Water Trough",
		color: "mountain",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c79.name",
		textKey: "games.bearnecessities.c79.effect"
	},
	{
		id: 80,
		english: "Snack Bag",
		color: "mountain",
		types: ["item"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c80.name",
		textKey: "games.bearnecessities.c80.effect"
	},
	{
		id: 81,
		english: "Weather Forecast",
		color: "mountain",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c81.name",
		textKey: "games.bearnecessities.c81.effect"
	},
	{
		id: 82,
		english: "Weather Forecast",
		color: "mountain",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c82.name",
		textKey: "games.bearnecessities.c82.effect"
	},
	{
		id: 83,
		english: "Weather Forecast",
		color: "mountain",
		types: ["item"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c83.name",
		textKey: "games.bearnecessities.c83.effect"
	},
	{
		id: 84,
		english: "Weather Forecast",
		color: "mountain",
		types: ["item"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c84.name",
		textKey: "games.bearnecessities.c84.effect"
	},
	{
		id: 85,
		english: "Botanist",
		color: "mountain",
		types: ["bear"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c85.name",
		textKey: "games.bearnecessities.c85.effect"
	},
	{
		id: 86,
		english: "Guide",
		color: "mountain",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c86.name",
		textKey: "games.bearnecessities.c86.effect"
	},
	{
		id: 87,
		english: "Hiker",
		color: "mountain",
		types: ["bear"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c87.name",
		textKey: "games.bearnecessities.c87.effect"
	},
	{
		id: 88,
		english: "Spy",
		color: "mountain",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !0,
		nameKey: "games.bearnecessities.c88.name",
		textKey: "games.bearnecessities.c88.effect"
	},
	{
		id: 89,
		english: "Spy",
		color: "mountain",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !0,
		nameKey: "games.bearnecessities.c89.name",
		textKey: "games.bearnecessities.c89.effect"
	},
	{
		id: 90,
		english: "Spy",
		color: "mountain",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !0,
		nameKey: "games.bearnecessities.c90.name",
		textKey: "games.bearnecessities.c90.effect"
	},
	{
		id: 91,
		english: "Wildlife Ranger",
		color: "mountain",
		types: ["bear"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c91.name",
		textKey: "games.bearnecessities.c91.effect"
	},
	{
		id: 92,
		english: "Berries",
		color: "mountain",
		types: ["plant"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c92.name",
		textKey: "games.bearnecessities.c92.effect"
	},
	{
		id: 93,
		english: "Dandelion",
		color: "mountain",
		types: ["plant"],
		hives: 0,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c93.name",
		textKey: "games.bearnecessities.c93.effect"
	},
	{
		id: 94,
		english: "Ivy",
		color: "mountain",
		types: ["plant"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c94.name",
		textKey: "games.bearnecessities.c94.effect"
	},
	{
		id: 95,
		english: "Sequoia",
		color: "mountain",
		types: ["plant"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c95.name",
		textKey: "games.bearnecessities.c95.effect"
	},
	{
		id: 96,
		english: "Wild Carrot",
		color: "mountain",
		types: ["plant"],
		hives: 1,
		goal: !1,
		glasses: !1,
		nameKey: "games.bearnecessities.c96.name",
		textKey: "games.bearnecessities.c96.effect"
	}
], y = Object.fromEntries(v.map((e) => [e.id, e])), b = [
	19,
	39,
	40,
	66,
	88,
	89,
	90
], x = {
	water: "games.bearnecessities.water",
	desert: "games.bearnecessities.desert",
	city: "games.bearnecessities.city",
	mountain: "games.bearnecessities.mountain"
}, S = {
	animal: "games.bearnecessities.animal",
	bear: "games.bearnecessities.bear",
	building: "games.bearnecessities.building",
	item: "games.bearnecessities.item",
	plant: "games.bearnecessities.plant"
}, C = {
	id: "bearnecessities",
	tier: "alpha",
	mechanics: [
		"drafting",
		"tile-placement",
		"engine-building"
	],
	interactionTags: [],
	nameKey: "games.bearnecessities.name",
	descKey: "games.bearnecessities.desc",
	rulesKey: "games.bearnecessities.rules",
	icon: "🐻",
	iconImg: "games/bearnecessities.webp",
	rulesUrl: { en: "https://www.mojitostudios.com/assets/files/bear-necessities/Bear%20Necessities%20Rules%20LQ.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	accent: "#217f8d",
	releasedAt: "2026-11-01T14:00:00+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, w = t.int().refine((e) => e in y), T = {
	x: t.int().min(-3).max(3),
	y: t.int().min(-2).max(2)
}, E = t.object({
	card: w,
	...T
}), D = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("select"),
		play: w,
		reserve: w
	}),
	t.object({
		type: t.literal("place"),
		...T
	}),
	t.object({
		type: t.literal("activate"),
		card: w
	}),
	t.object({
		type: t.literal("opponent"),
		rid: t.string()
	}),
	t.object({
		type: t.literal("refill"),
		keep: t.boolean()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), O = t.object({
	kind: t.enum([
		"neighbor",
		"card",
		"opponent"
	]),
	source: w,
	targets: t.array(w),
	opponents: t.array(t.string())
}), k = t.object({
	rid: t.string(),
	board: t.array(E).max(12),
	points: t.int().nonnegative(),
	bees: t.int().nonnegative(),
	spyBees: t.int().nonnegative(),
	roundPoints: t.int().nonnegative(),
	picked: t.boolean(),
	placed: t.boolean(),
	refillReady: t.boolean(),
	play: w.nullable(),
	reserveColor: t.enum([
		"water",
		"desert",
		"city",
		"mountain"
	]).nullable(),
	pending: O.nullable(),
	finished: t.boolean()
}), A = t.object({
	round: t.int().min(1).max(12),
	phase: t.enum([
		"select",
		"place",
		"resolve",
		"bee",
		"pass",
		"refill",
		"final",
		"done"
	]),
	players: t.array(k).min(2).max(4),
	last: t.object({
		rid: t.string(),
		card: w.nullable(),
		points: t.int(),
		bees: t.int(),
		serial: t.int()
	}).nullable()
}), j = t.object({
	hand: t.array(w),
	play: w.nullable(),
	reserve: w.nullable()
}), M = (e, t) => Math.abs(e.x - t.x) + Math.abs(e.y - t.y) === 1, N = (e) => e.reduce((e, t) => e + y[t.card].hives, 0);
function P(e) {
	if (!e.length) return [{
		x: 0,
		y: 0
	}];
	let t = /* @__PURE__ */ new Map();
	for (let n of e) for (let [r, i] of [
		[1, 0],
		[-1, 0],
		[0, 1],
		[0, -1]
	]) {
		let a = n.x + r, o = n.y + i;
		if (e.some((e) => e.x === a && e.y === o)) continue;
		let s = [...e.map((e) => e.x), a], c = [...e.map((e) => e.y), o];
		Math.max(...s) - Math.min(...s) < 4 && Math.max(...c) - Math.min(...c) < 3 && t.set(`${a},${o}`, {
			x: a,
			y: o
		});
	}
	return [...t.values()];
}
function F(e) {
	switch (e) {
		case 14: return { color: "water" };
		case 32: return { color: "desert" };
		case 56: return { color: "city" };
		case 78: return { color: "mountain" };
		case 17: return { type: "item" };
		case 86: return { type: "bear" };
		default: return null;
	}
}
function I(e, t, n) {
	let r = F(t);
	return r ? e.filter((e) => !n.includes(e.card) && (!r.color || y[e.card].color === r.color) && (!r.type || y[e.card].types.includes(r.type))).map((e) => e.card) : [];
}
function ee(e) {
	let t = new Set(e.filter((e) => y[e.card].color === "water").map((e) => e.card)), n = 0;
	for (; t.size;) {
		let r = t.values().next().value, i = [r];
		t.delete(r);
		for (let n = 0; n < i.length; n++) {
			let r = e.find((e) => e.card === i[n]);
			for (let n of e) t.has(n.card) && M(r, n) && (t.delete(n.card), i.push(n.card));
		}
		n = Math.max(n, i.length);
	}
	return n;
}
function L(e, t) {
	let n = (e) => t.board.filter((t) => y[t.card].color === e).length;
	switch (e) {
		case 19: return 2 * n("water");
		case 39: return n("city") + n("mountain");
		case 40: return 3 * t.board.filter((e) => y[e.card].goal).length;
		case 66: return 2 * n("desert");
		case 88: return n("desert") + n("mountain");
		case 89: return n("city") + n("water");
		case 90: return 2 * t.bees;
		default: return 0;
	}
}
function te(e, t, n, r = !1) {
	let i = t.board, a = i.find((t) => t.card === e);
	if (!a) return 0;
	let o = i.filter((e) => M(a, e)), s = (e, t) => e.filter((e) => y[e.card].color === t).length, c = (e, t) => e.filter((e) => y[e.card].types.includes(t)).length, l = i.filter((e) => e.y === a.y), u = i.filter((e) => e.x === a.x), d = new Set(o.map((e) => y[e.card].color)).size, f = (e, t) => e ? t : 2;
	if (e >= 3 && e <= 10) return 2 * ee(i);
	switch (e) {
		case 0: return f(o.some((e) => e.card === 1 || e.card === 2), 8);
		case 1:
		case 2:
		case 28:
		case 95: return 3;
		case 11: return c(o, "bear") === 1 ? 4 : 0;
		case 12: return f(s(o, "water") >= 2, 7);
		case 13: return 2 * i.filter((e) => (e.x === a.x || e.y === a.y) && y[e.card].color === "water").length;
		case 15: return 3 * c(i, "item");
		case 16: return f(Math.max(...[
			"water",
			"desert",
			"city",
			"mountain"
		].map((e) => s(i, e))) >= 5, 12);
		case 18: return s(o, "water") >= 1 ? 4 : 0;
		case 20:
		case 21: return s(o, "water") === 1 ? 3 : 0;
		case 22: return 3 * s(o, "water");
		case 24: return 4 * s(o, "mountain");
		case 25: return 4 * N(o);
		case 26: return f(d === 4, 16);
		case 27: return 5 * i.filter((e) => b.includes(e.card)).length;
		case 29: return f(d === 2, 8);
		case 30: return f(d === 3, 12);
		case 31: return 6 * o.filter((e) => e.card >= 3 && e.card <= 10).length;
		case 33: return 2 * o.length;
		case 34: return +!r;
		case 35: return 4 * s(o, "city");
		case 36: return 4 * s(o, "desert");
		case 37: return 3 * d;
		case 38: return f(o.some((e) => e.x === a.x + 1 && y[e.card].types.includes("animal")), 8);
		case 41: return f(o.some((e) => y[e.card].goal), 8);
		case 42: return c(o, "bear") === 0 ? 4 : 0;
		case 43: return s(o, "desert") === 1 ? 5 : 0;
		case 44: return 3 * s(i, "desert");
		case 46: return 4 * c(o, "item");
		case 47: return 3 * c(o, "bear");
		case 48: return 4 * c(i.filter((e) => e.y > a.y), "bear");
		case 49: return 4 * c(i.filter((e) => e.y < a.y), "building");
		case 50: return s(o, "city") === 0 ? 4 : 0;
		case 51: return 2 * [...new Set(i.map((e) => e.x))].filter((e) => i.filter((t) => t.x === e).length === 3).length;
		case 52: return 3 * [...new Set(i.map((e) => e.y))].filter((e) => i.filter((t) => t.y === e).length === 4).length;
		case 53: return s(i, "city");
		case 54: return 2 * i.filter((e) => (e.x === a.x || e.y === a.y) && y[e.card].color === "city").length;
		case 55: return 2;
		case 57: return f(c(o, "building") >= 2, 12);
		case 58: return 2 * new Set(i.filter((e) => y[e.card].color === "city").map((e) => e.x)).size;
		case 59: return 2 * (c(i, "bear") - 1);
		case 60: return 4 * c(i, "building");
		case 61: return 5 * i.filter((e) => y[e.card].goal).length;
		case 62: return f(l.length === 4, 8);
		case 63: return f(t.bees >= 6, 10);
		case 64: return 4 * i.filter((e) => y[e.card].types.includes("bear") && !y[e.card].glasses).length;
		case 65: return 3 * c(l, "bear");
		case 67: return f(u.length === 3, 7);
		case 68: return 2 * new Set(i.filter((e) => y[e.card].color === "city").map((e) => e.y)).size;
		case 69: return f(c(o, "bear") === 2, 10);
		case 71: return 2 * c(i, "animal");
		case 72: return 4 * c(o, "plant");
		case 73: return 2 * i.filter((e) => y[e.card].english.startsWith("S")).length;
		case 74: return i.length - o.length;
		case 75: return f(c(o, "plant") >= 1 && c(o, "animal") >= 1, 10);
		case 76: return f(new Set(i.map((e) => y[e.card].color)).size === 4, 7);
		case 77: return f(c(i, "item") >= 3, 8);
		case 79: return 4 * c(o, "animal");
		case 80: return 2 * t.bees;
		case 81:
		case 82:
		case 83:
		case 84: return n !== null && y[n].color === [
			"city",
			"water",
			"mountain",
			"desert"
		][e - 81] ? 7 : 0;
		case 85: return 4 * c(i, "plant");
		case 87: return 2 * s(i, "mountain");
		case 91: return 3 * c(i, "animal");
		case 92: return 4 * c(l, "animal");
		case 93: return r ? 7 : 1;
		case 94: return 4 * c(o, "building");
		case 96: return c(o, "animal") >= 1 ? 5 : 0;
		default: return 0;
	}
}
function R(e) {
	return e.seats.map((e, t) => ({
		kind: "deal",
		rid: e.rid,
		data: { count: e.hand.length },
		for: [e.rid],
		secret: { cards: e.hand },
		...t ? { with: !0 } : {}
	}));
}
function ne(t, n, r) {
	let i = v.map((e) => e.id), a = 0;
	for (let t = i.length - 1; t > 0; t--) {
		let n = e(r, a++, t + 1);
		[i[t], i[n]] = [i[n], i[t]];
	}
	let o = {
		seats: n.map((e) => ({
			rid: e,
			hand: i.splice(0, 5),
			board: [],
			points: 0,
			bees: 0,
			roundPoints: 0,
			play: null,
			reserve: null,
			placed: !1,
			keep: null,
			queue: [],
			neighbors: [],
			pending: null,
			chain: [],
			finished: !1
		})),
		deck: i,
		discard: [],
		round: 1,
		phase: "select",
		rngCursor: a,
		spyBees: {},
		last: null,
		serial: 0
	};
	return {
		state: o,
		fx: R(o)
	};
}
function z(e = "games.bearnecessities.errPhase") {
	return { code: e };
}
function B(e) {
	e.pending || e.queue.length || (e.neighbors.length ? e.pending = {
		kind: "neighbor",
		source: e.play,
		targets: [...e.neighbors],
		opponents: []
	} : e.finished = !0);
}
function V(e) {
	e.seats.every((e) => e.finished) && (e.phase = "bee");
}
function H(e, t, n, r, i) {
	e.last = {
		rid: t,
		card: n,
		points: r,
		bees: i,
		serial: ++e.serial
	};
}
function U(e, t, n, r, i = 0) {
	return t.points += r, t.roundPoints += r, t.bees += i, H(e, t.rid, n, r, i), {
		kind: "activate",
		rid: t.rid,
		data: {
			card: n,
			points: r,
			bees: i
		}
	};
}
function re(e, t) {
	let n = t.queue.shift(), r = [...n.chain, n.card];
	if (F(n.card)) {
		let i = I(t.board, n.card, r);
		return i.length && (t.pending = {
			kind: "card",
			source: n.card,
			targets: i,
			opponents: []
		}, t.chain = r), H(e, t.rid, n.card, 0, 0), B(t), V(e), {
			kind: "activate",
			rid: t.rid,
			data: {
				card: n.card,
				points: 0,
				bees: 0
			}
		};
	}
	if (b.includes(n.card)) return t.pending = {
		kind: "opponent",
		source: n.card,
		targets: [],
		opponents: e.seats.filter((e) => e.rid !== t.rid).map((e) => e.rid)
	}, t.chain = r, H(e, t.rid, n.card, 0, 0), {
		kind: "activate",
		rid: t.rid,
		data: {
			card: n.card,
			points: 0,
			bees: 0
		}
	};
	let i = U(e, t, n.card, te(n.card, t, t.reserve, n.placed), n.card === 34 && n.placed ? 2 : 0);
	return B(t), V(e), i;
}
function ie(e) {
	if (e.phase === "resolve") {
		let t = e.seats.find((e) => e.queue.length);
		return t ? [re(e, t)] : [];
	}
	if (e.phase === "bee") {
		let t = Math.min(...e.seats.map((e) => e.roundPoints)), n = e.seats.filter((e) => e.roundPoints === t);
		for (let e of n) e.bees++;
		return e.phase = "pass", [{
			kind: "bees",
			data: { rids: n.map((e) => e.rid) }
		}];
	}
	if (e.phase === "pass") {
		if (e.round === 12) return e.phase = "final", [{
			kind: "roundEnd",
			data: {}
		}];
		if (e.round % 4 == 0) {
			e.phase = "refill";
			for (let t of e.seats) t.keep = null;
			return [{
				kind: "roundEnd",
				data: {}
			}];
		}
		let t = e.seats.map((e) => [...e.hand]);
		for (let n = 0; n < e.seats.length; n++) e.seats[n].hand = [...t[(n + e.seats.length - 1) % e.seats.length], e.seats[n].reserve];
		return W(e), R(e);
	}
	if (e.phase === "final") {
		let t = [];
		for (let n of e.seats) {
			let e = n.bees * N(n.board);
			n.points += e, t.push({
				kind: "bonus",
				rid: n.rid,
				data: { points: e },
				...t.length ? { with: !0 } : {}
			});
		}
		return e.phase = "done", t;
	}
	return [];
}
function W(e) {
	e.round++, e.phase = "select", e.last = null;
	for (let t of e.seats) t.play = null, t.reserve = null, t.placed = !1, t.roundPoints = 0, t.finished = !1, t.queue = [], t.neighbors = [], t.pending = null, t.chain = [], t.keep = null;
}
function ae(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine") return z();
		if (G(e) === null) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return {
			state: t,
			fx: ie(t)
		};
	}
	if (!e.seats.find((e) => e.rid === n.by) || e.phase === "done") return z();
	let r = structuredClone(e), i = r.seats.find((e) => e.rid === n.by);
	if (t.type === "select") return r.phase !== "select" || i.play !== null ? z() : t.play === t.reserve || !i.hand.includes(t.play) || !i.hand.includes(t.reserve) ? z("games.bearnecessities.errCard") : (i.play = t.play, i.reserve = t.reserve, i.hand = i.hand.filter((e) => e !== t.play && e !== t.reserve), r.seats.every((e) => e.play !== null) ? (r.phase = "place", {
		state: r,
		fx: [{
			kind: "reveal",
			data: { cards: r.seats.map((e) => ({
				rid: e.rid,
				card: e.play
			})) }
		}]
	}) : {
		state: r,
		fx: []
	});
	if (t.type === "place") {
		if (r.phase !== "place" || i.placed || i.play === null) return z();
		if (!P(i.board).some((e) => e.x === t.x && e.y === t.y)) return z("games.bearnecessities.errPlace");
		if (i.board.push({
			card: i.play,
			x: t.x,
			y: t.y
		}), i.placed = !0, r.seats.every((e) => e.placed)) {
			r.phase = "resolve", r.spyBees = Object.fromEntries(r.seats.map((e) => [e.rid, e.bees + (e.play === 34 ? 2 : 0)]));
			for (let e of r.seats) {
				let t = e.board.find((t) => t.card === e.play);
				e.neighbors = e.board.filter((e) => M(t, e)).map((e) => e.card), e.queue = [{
					card: e.play,
					chain: [],
					placed: !0
				}];
			}
		}
		return {
			state: r,
			fx: [{
				kind: "place",
				rid: i.rid,
				data: { card: i.play }
			}]
		};
	}
	if (t.type === "activate") {
		if (r.phase !== "resolve" || !i.pending || !i.pending.targets.includes(t.card)) return z("games.bearnecessities.errTarget");
		let e = i.pending.kind === "neighbor" ? [] : [...i.chain];
		return i.pending.kind === "neighbor" && (i.neighbors = i.neighbors.filter((e) => e !== t.card)), i.pending = null, i.queue.push({
			card: t.card,
			chain: e,
			placed: !1
		}), {
			state: r,
			fx: []
		};
	}
	if (t.type === "opponent") {
		if (r.phase !== "resolve" || i.pending?.kind !== "opponent" || !i.pending.opponents.includes(t.rid)) return z("games.bearnecessities.errTarget");
		let e = r.seats.find((e) => e.rid === t.rid), n = i.pending.source, a = L(n, {
			board: e.board,
			bees: r.spyBees[e.rid]
		});
		i.pending = null;
		let o = U(r, i, n, a);
		return B(i), V(r), {
			state: r,
			fx: [o]
		};
	}
	if (t.type === "refill") {
		if (r.phase !== "refill" || i.keep !== null) return z();
		if (i.keep = t.keep, r.seats.every((e) => e.keep !== null)) {
			for (let e of r.seats) e.keep ? e.hand = [e.reserve] : (e.hand = [], r.discard.push(e.reserve)), e.hand.push(...r.deck.splice(0, 5 - e.hand.length));
			return W(r), {
				state: r,
				fx: R(r)
			};
		}
		return {
			state: r,
			fx: []
		};
	}
	return z();
}
function oe(e, t) {
	let n = e.seats.find((e) => e.rid === t);
	return {
		public: {
			round: e.round,
			phase: e.phase,
			last: e.last,
			players: e.seats.map((t) => ({
				rid: t.rid,
				board: t.board,
				points: t.points,
				bees: t.bees,
				spyBees: e.phase === "resolve" ? e.spyBees[t.rid] : t.bees,
				roundPoints: t.roundPoints,
				picked: t.play !== null,
				placed: t.placed,
				refillReady: t.keep !== null,
				play: e.phase === "select" ? null : t.play,
				reserveColor: e.phase === "select" || t.reserve === null ? null : y[t.reserve].color,
				pending: t.pending,
				finished: t.finished
			}))
		},
		...n ? { private: {
			hand: n.hand,
			play: n.play,
			reserve: n.reserve
		} } : {}
	};
}
function se(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.seats].sort((e, t) => t.points - e.points);
	return {
		phase: "done",
		ranking: t.map((e) => e.rid),
		winner: t.filter((e) => e.points === t[0].points).map((e) => e.rid),
		scores: Object.fromEntries(t.map((e) => [e.rid, e.points]))
	};
}
function G(e) {
	return [
		"bee",
		"pass",
		"final"
	].includes(e.phase) || e.phase === "resolve" && e.seats.some((e) => e.queue.length) ? 580 : null;
}
var ce = {
	meta: C,
	saveCompatibility: { version: "1" },
	schemas: {
		action: D,
		publicView: A,
		privateView: j
	},
	setup: ne,
	reduce: ae,
	viewFor: oe,
	status: se,
	nextTickIn: G
};
//#endregion
//#region src/games/bearnecessities/card.tsx
function K({ name: e, className: t = "" }) {
	return /* @__PURE__ */ f("img", {
		className: `bnx-symbol ${t}`,
		src: `games/bearnecessities/icon-${e}.svg`,
		alt: "",
		draggable: !1
	});
}
function q({ id: e, full: t = !1, style: n }) {
	let r = a(), i = y[e];
	return /* @__PURE__ */ p("article", {
		className: `bnx-photo${t ? " bnx-photo-full" : ""}`,
		"data-color": i.color,
		style: n,
		children: [
			/* @__PURE__ */ f("img", {
				className: "bnx-photo-art",
				src: `games/bearnecessities/art-${e}.svg`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ f("strong", {
				className: "bnx-photo-name",
				children: r(i.nameKey)
			}),
			/* @__PURE__ */ p("div", {
				className: "bnx-photo-symbols",
				children: [
					/* @__PURE__ */ f(K, { name: i.color }),
					i.types.map((e) => /* @__PURE__ */ f(K, { name: e }, e)),
					i.goal && /* @__PURE__ */ f(K, { name: "goal" }),
					i.hives > 0 && /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(K, { name: "hive" }), i.hives] }),
					i.english.startsWith("S") && /* @__PURE__ */ f("span", {
						className: "bnx-s-mark",
						children: "S"
					})
				]
			}),
			t && /* @__PURE__ */ f("p", {
				className: "bnx-photo-effect",
				children: r(i.textKey)
			})
		]
	});
}
function le({ id: e }) {
	let t = a(), n = y[e];
	return /* @__PURE__ */ p("div", {
		className: "bnx-details",
		children: [
			/* @__PURE__ */ f(q, {
				id: e,
				full: !0
			}),
			/* @__PURE__ */ f("p", {
				className: "bnx-original-name",
				children: n.english
			}),
			/* @__PURE__ */ p("div", {
				className: "bnx-details-traits",
				children: [
					/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(K, { name: n.color }), t(x[n.color])] }),
					n.types.map((e) => /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(K, { name: e }), t(S[e])] }, e)),
					n.goal && /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(K, { name: "goal" }), t("games.bearnecessities.goal")] }),
					/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(K, { name: "hive" }), t("games.bearnecessities.hiveCount", { n: n.hives })] }),
					n.types.includes("bear") && /* @__PURE__ */ f("span", { children: t(n.glasses ? "games.bearnecessities.glasses" : "games.bearnecessities.noGlasses") })
				]
			})
		]
	});
}
function J() {
	return /* @__PURE__ */ p("svg", {
		className: "bnx-target-outline",
		viewBox: "0 0 100 140",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "136",
			rx: "5",
			fill: "none",
			stroke: "white",
			strokeWidth: "4"
		}), /* @__PURE__ */ f("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "136",
			rx: "5",
			fill: "none",
			stroke: "#136b78",
			strokeWidth: "2",
			strokeDasharray: "7 5",
			children: /* @__PURE__ */ f("animate", {
				attributeName: "stroke-dashoffset",
				from: "24",
				to: "0",
				dur: "1.2s",
				repeatCount: "indefinite"
			})
		})]
	});
}
//#endregion
//#region src/games/bearnecessities/view-player.tsx
function ue(e) {
	return /* @__PURE__ */ f(Y, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function Y({ pub: e, priv: t, members: i, myRid: s, send: m, review: h = !1 }) {
	let g = a(), [_, v] = n(s), [b, x] = n({
		round: e.round,
		play: null,
		reserve: null
	}), [S, C] = n(null), w = e.players.find((e) => e.rid === s), T = !h && w && (e.phase === "place" && !w.placed || e.phase === "resolve" && w.pending && w.pending.kind !== "opponent"), E = e.players.find((e) => e.rid === (T ? s : _)) ?? e.players[0], D = (e) => i.find((t) => t.rid === e)?.name ?? e, O = b.round === e.round ? b : {
		round: e.round,
		play: null,
		reserve: null
	}, k = !h && e.phase === "select" && t?.play === null, A = h ? null : w?.pending, j = g("games.bearnecessities.waiting"), M = !1;
	h ? j = g("games.bearnecessities.done") : k ? (j = g(O.play === null ? "games.bearnecessities.choose" : "games.bearnecessities.chooseReserve"), M = !0) : e.phase === "place" && w && !w.placed ? (j = g("games.bearnecessities.place"), M = !0) : A ? (j = g(A.kind === "neighbor" ? "games.bearnecessities.activate" : A.kind === "card" ? "games.bearnecessities.target" : "games.bearnecessities.opponent"), M = !0) : e.phase === "resolve" ? j = g("games.bearnecessities.resolving") : e.phase === "bee" || e.phase === "pass" ? j = g("games.bearnecessities.beeTime") : e.phase === "refill" && w && !w.refillReady && (j = g("games.bearnecessities.refill"), M = !0);
	let N = (e) => {
		k && (O.play === e ? x({
			...O,
			play: null
		}) : O.reserve === e ? x({
			...O,
			reserve: null
		}) : O.play === null ? x({
			...O,
			play: e
		}) : x({
			...O,
			reserve: e
		}));
	}, { ref: P } = r("hand");
	return /* @__PURE__ */ p("div", {
		className: "bnx-screen",
		children: [/* @__PURE__ */ f(l, {
			adaptive: !0,
			scroll: !1,
			className: h ? "bnx-layout bnx-review-layout" : "bnx-layout",
			banner: /* @__PURE__ */ p("div", {
				className: "bnx-top",
				children: [/* @__PURE__ */ f(u, {
					text: j,
					chip: g("games.bearnecessities.round", { n: e.round }),
					tone: M ? "accent" : h ? "done" : "info",
					accent: "#217f8d"
				}), /* @__PURE__ */ f("div", {
					className: "bnx-player-tabs",
					children: e.players.map((e) => /* @__PURE__ */ f(de, {
						p: e,
						name: D(e.rid),
						selected: E.rid === e.rid,
						targetScore: A?.kind === "opponent" && A.opponents.includes(e.rid) ? L(A.source, {
							board: e.board,
							bees: e.spyBees
						}) : null,
						onClick: () => {
							A?.kind === "opponent" && A.opponents.includes(e.rid) ? m({
								type: "opponent",
								rid: e.rid
							}) : v(e.rid);
						}
					}, e.rid))
				})]
			}),
			actionsHeight: "bnx-actions-slot",
			actions: /* @__PURE__ */ p("div", {
				className: "bnx-actions",
				children: [
					k && /* @__PURE__ */ p("div", {
						className: "bnx-choice-strip",
						children: [
							/* @__PURE__ */ p("span", { children: [
								g("games.bearnecessities.playLabel"),
								": ",
								/* @__PURE__ */ f("b", { children: O.play === null ? "—" : g(y[O.play].nameKey) })
							] }),
							/* @__PURE__ */ p("span", { children: [
								g("games.bearnecessities.keepLabel"),
								": ",
								/* @__PURE__ */ f("b", { children: O.reserve === null ? "—" : g(y[O.reserve].nameKey) })
							] }),
							/* @__PURE__ */ f("button", {
								className: "bnx-primary",
								disabled: O.play === null || O.reserve === null,
								onClick: () => {
									O.play !== null && O.reserve !== null && m({
										type: "select",
										play: O.play,
										reserve: O.reserve
									});
								},
								children: g("games.bearnecessities.confirm")
							})
						]
					}),
					!k && /* @__PURE__ */ p("div", {
						className: "bnx-choice-strip",
						children: [
							/* @__PURE__ */ f("span", { children: t?.play !== null && t?.play !== void 0 && /* @__PURE__ */ p(d, { children: [
								g("games.bearnecessities.playLabel"),
								": ",
								/* @__PURE__ */ f("b", { children: g(y[t.play].nameKey) })
							] }) }),
							/* @__PURE__ */ f("span", { children: t?.reserve !== null && t?.reserve !== void 0 && /* @__PURE__ */ p(d, { children: [
								g("games.bearnecessities.keepLabel"),
								": ",
								/* @__PURE__ */ f("b", { children: g(y[t.reserve].nameKey) })
							] }) }),
							!h && e.phase === "refill" && w && !w.refillReady && /* @__PURE__ */ p("div", {
								className: "bnx-refill",
								children: [/* @__PURE__ */ f("button", {
									onClick: () => m({
										type: "refill",
										keep: !0
									}),
									children: g("games.bearnecessities.keep")
								}), /* @__PURE__ */ f("button", {
									onClick: () => m({
										type: "refill",
										keep: !1
									}),
									children: g("games.bearnecessities.discard")
								})]
							})
						]
					}),
					/* @__PURE__ */ f("div", {
						ref: P,
						className: "bnx-hand-scroll",
						children: /* @__PURE__ */ f("div", {
							className: "bnx-hand",
							children: (h ? [] : t?.hand ?? []).map((e) => /* @__PURE__ */ p("div", {
								className: "bnx-hand-item",
								children: [/* @__PURE__ */ p("button", {
									className: "bnx-hand-pick",
									"aria-pressed": O.play === e || O.reserve === e,
									disabled: !k,
									onClick: () => N(e),
									children: [/* @__PURE__ */ f(q, {
										id: e,
										full: !0
									}), k && (O.play === e || O.reserve === e) && /* @__PURE__ */ f("span", {
										className: "bnx-pick-label",
										children: g(O.play === e ? "games.bearnecessities.playLabel" : "games.bearnecessities.keepLabel")
									})]
								}), /* @__PURE__ */ f("button", {
									className: "bnx-inspect",
									"aria-label": g("games.bearnecessities.inspect") + " " + g(y[e].nameKey),
									onClick: () => C(e),
									children: /* @__PURE__ */ f(c, { size: 16 })
								})]
							}, e))
						})
					})
				]
			}),
			children: /* @__PURE__ */ p("div", {
				className: "bnx-album",
				children: [/* @__PURE__ */ p("div", {
					className: "bnx-album-heading",
					children: [/* @__PURE__ */ f("strong", { children: E.rid === s ? g("games.bearnecessities.own") : D(E.rid) }), /* @__PURE__ */ p("span", { children: [
						/* @__PURE__ */ f(K, { name: "points" }),
						E.roundPoints,
						" ",
						/* @__PURE__ */ f("small", { children: g("games.bearnecessities.roundScore") })
					] })]
				}), /* @__PURE__ */ f(fe, {
					p: E,
					canPlace: !h && E.rid === s && e.phase === "place" && !E.placed,
					targets: E.rid === s ? A?.targets ?? [] : [],
					lastCard: e.last?.rid === E.rid ? e.last.card : null,
					onPlace: (e) => m({
						type: "place",
						...e
					}),
					onCard: (e) => {
						E.rid === s && A?.targets.includes(e) ? m({
							type: "activate",
							card: e
						}) : C(e);
					},
					onInspect: C
				})]
			})
		}), /* @__PURE__ */ f(o, {
			open: S !== null,
			onClose: () => C(null),
			label: g("games.bearnecessities.inspect"),
			title: S === null ? "" : g(y[S].nameKey),
			children: S !== null && /* @__PURE__ */ f(le, { id: S })
		})]
	});
}
function de({ p: e, name: t, selected: n, targetScore: o, onClick: s }) {
	let c = a(), { ref: l } = r(`seat:${e.rid}`);
	return /* @__PURE__ */ p("button", {
		ref: l,
		className: "bnx-player-tab",
		"data-selected": n || void 0,
		"data-target": o !== null || void 0,
		onClick: s,
		"aria-label": o === null ? c("games.bearnecessities.inspectBoard", { name: t }) : c("games.bearnecessities.spyChoice", {
			name: t,
			n: o
		}),
		children: [
			/* @__PURE__ */ f("strong", { children: t }),
			/* @__PURE__ */ f("div", { children: o === null ? /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ p("span", {
					title: c("games.bearnecessities.score"),
					children: [/* @__PURE__ */ f(K, { name: "points" }), /* @__PURE__ */ f(i, { value: e.points })]
				}),
				/* @__PURE__ */ p("span", {
					title: c("games.bearnecessities.bees"),
					children: [/* @__PURE__ */ f(K, { name: "bee" }), e.bees]
				}),
				/* @__PURE__ */ p("span", {
					title: c("games.bearnecessities.hives"),
					children: [/* @__PURE__ */ f(K, { name: "hive" }), N(e.board)]
				})
			] }) : /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(K, { name: "points" }), o] }) }),
			o !== null && /* @__PURE__ */ f(J, {})
		]
	});
}
function fe({ p: e, canPlace: t, targets: n, lastCard: r, onPlace: i, onCard: o, onInspect: s }) {
	let c = a(), l = t ? P(e.board) : [], u = [...e.board, ...l], m = Math.min(0, ...u.map((e) => e.x)), h = Math.min(0, ...u.map((e) => e.y)), g = Math.max(m + 3, ...u.map((e) => e.x)), _ = Math.max(h + 2, ...u.map((e) => e.y)), v = {
		"--bnx-cols": g - m + 1,
		"--bnx-rows": _ - h + 1
	};
	return /* @__PURE__ */ f("div", {
		className: "bnx-album-scroll",
		children: /* @__PURE__ */ f("div", {
			className: "bnx-tableau",
			style: v,
			children: Array.from({ length: (g - m + 1) * (_ - h + 1) }, (t, a) => {
				let u = m + a % (g - m + 1), _ = h + Math.floor(a / (g - m + 1)), v = e.board.find((e) => e.x === u && e.y === _), y = l.some((e) => e.x === u && e.y === _);
				return v ? /* @__PURE__ */ f(pe, {
					rid: e.rid,
					id: v.card,
					target: n.includes(v.card),
					activated: r === v.card,
					onClick: () => o(v.card),
					onInspect: () => s(v.card)
				}, v.card) : /* @__PURE__ */ f("button", {
					className: "bnx-empty-photo",
					disabled: !y,
					"aria-label": c("games.bearnecessities.placeAt", {
						x: u,
						y: _
					}),
					onClick: () => i({
						x: u,
						y: _
					}),
					children: y && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", { children: "+" }), /* @__PURE__ */ f(J, {})] })
				}, `${u},${_}`);
			})
		})
	});
}
function pe({ rid: e, id: t, target: n, activated: i, onClick: o, onInspect: s }) {
	let l = a(), { ref: u, hidden: d } = r(`table:${e}:${t}`);
	return /* @__PURE__ */ p("div", {
		ref: u,
		className: "bnx-table-card",
		style: d ? { visibility: "hidden" } : void 0,
		"data-target": n || void 0,
		"data-activated": i || void 0,
		children: [/* @__PURE__ */ p("button", {
			className: "bnx-table-card-main",
			onClick: o,
			"aria-label": n ? l("games.bearnecessities.hintActivate", { card: l(y[t].nameKey) }) : l(y[t].nameKey),
			children: [/* @__PURE__ */ f(q, { id: t }), n && /* @__PURE__ */ f(J, {})]
		}), /* @__PURE__ */ f("button", {
			className: "bnx-inspect",
			onClick: s,
			"aria-label": l("games.bearnecessities.inspect") + " " + l(y[t].nameKey),
			children: /* @__PURE__ */ f(c, { size: 14 })
		})]
	});
}
//#endregion
//#region src/games/bearnecessities/bot.ts
var X = {
	future: 0,
	reserve: 0,
	hive: 0
}, me = {
	future: 1,
	reserve: .5,
	hive: 1.2
};
function Z(e, t, n, r, i = !1, a = []) {
	return a.includes(e) ? 0 : F(e) ? Math.max(0, ...I(t.board, e, [...a, e]).map((i) => Z(i, t, n, r, !1, [...a, e]))) : b.includes(e) ? Math.max(0, ...r.map((t) => L(e, t))) : te(e, t, n, i);
}
function Q(e, t, n, r, i, a, o) {
	let s = {
		card: t,
		...r
	}, c = [...e.board, s], l = {
		board: c,
		bees: e.bees + (t === 34 ? 2 : 0)
	}, u = Z(t, l, n, i, !0);
	for (let e of c) M(s, e) && (u += Z(e.card, l, n, i));
	let d = P(c), f = c.reduce((e, t) => e + d.filter((e) => Math.abs(e.x - t.x) + Math.abs(e.y - t.y) === 1).length * Z(t.card, l, n, i), 0);
	if (u += o.future * f * (12 - a) / 24, u += o.hive * (N(c) * (e.bees + (12 - a) / 4) + (t === 34 ? 2 * N(c) : 0)), n !== null) {
		let e = P(c), t = Math.max(0, ...e.map((e) => Z(n, {
			board: [...c, {
				card: n,
				...e
			}],
			bees: l.bees
		}, null, i, !0)));
		u += o.reserve * t;
	}
	return u;
}
function $(e = me) {
	return (t, n) => {
		let r = t.public, i = t.private, a = r.players.find((e) => e.rid === n.rid);
		if (!a || !i) return null;
		let o = r.players.filter((e) => e.rid !== n.rid).map((e) => ({
			...e,
			bees: r.phase === "resolve" ? e.spyBees : e.bees
		}));
		if (r.phase === "select" && i.play === null && i.hand.length >= 2) {
			let t = -Infinity, n = null;
			for (let s of i.hand) for (let c of i.hand) if (s !== c) for (let i of P(a.board)) {
				let l = Q(a, s, c, i, o, r.round, e);
				l > t && (t = l, n = {
					type: "select",
					play: s,
					reserve: c
				});
			}
			return n ? { action: n } : null;
		}
		if (r.phase === "place" && !a.placed && a.play !== null) return { action: {
			type: "place",
			...[...P(a.board)].sort((t, n) => Q(a, a.play, i.reserve, n, o, r.round, e) - Q(a, a.play, i.reserve, t, o, r.round, e))[0]
		} };
		if (r.phase === "resolve" && a.pending) {
			if (a.pending.kind === "opponent") {
				let e = o.filter((e) => a.pending.opponents.includes(e.rid)).sort((e, t) => L(a.pending.source, t) - L(a.pending.source, e))[0];
				return e ? { action: {
					type: "opponent",
					rid: e.rid
				} } : null;
			}
			let e = [...a.pending.targets].sort((e, t) => Z(t, a, i.reserve, o) - Z(e, a, i.reserve, o));
			return e.length ? { action: {
				type: "activate",
				card: e[0]
			} } : null;
		}
		return r.phase === "refill" && !a.refillReady && i.reserve !== null ? { action: {
			type: "refill",
			keep: Math.max(...P(a.board).map((e) => Q(a, i.reserve, null, e, o, r.round + 1, X))) >= 8
		} } : null;
	};
}
var he = $(), ge = $(X), _e = (e, t) => t.difficulty === "weak" ? ge(e, t) : he(e, t), ve = (e, t, n) => e.type === "select" ? n("games.bearnecessities.hint", {
	card: n(y[e.play].nameKey),
	reserve: n(y[e.reserve].nameKey)
}) : e.type === "place" ? n("games.bearnecessities.hintPlace", {
	x: e.x,
	y: e.y
}) : e.type === "activate" ? n("games.bearnecessities.hintActivate", { card: n(y[e.card].nameKey) }) : e.type === "refill" ? n(e.keep ? "games.bearnecessities.keep" : "games.bearnecessities.discard") : e.type === "opponent" ? n("games.bearnecessities.opponent") : "", ye = {
	deal(e, t) {
		let n = e.rid === t.myRid ? t.anchor("hand") : t.anchor(`seat:${e.rid}`), r = t.anchor(`seat:${e.rid}`);
		if (!n || !r) return null;
		let i = {
			x: n.x + n.w / 2 - 23,
			y: n.y + n.h / 2 - 32,
			w: 46,
			h: 64
		}, a = {
			x: r.x + r.w / 2 - 23,
			y: r.y - 20,
			w: 46,
			h: 64
		};
		return {
			ms: 580,
			node: /* @__PURE__ */ f(h, {
				from: a,
				to: i,
				ms: 580,
				children: /* @__PURE__ */ p("div", {
					className: "bnx-card-back",
					children: [
						"Bear",
						/* @__PURE__ */ f("br", {}),
						"Necessities"
					]
				})
			})
		};
	},
	reveal(e, t) {
		return {
			ms: 580,
			node: e.data.cards.map((e) => {
				let n = t.anchor(`seat:${e.rid}`);
				return n ? /* @__PURE__ */ f(g, {
					at: n,
					ms: 580
				}, e.rid) : null;
			})
		};
	},
	place(e, t) {
		let { card: n } = e.data, r = t.anchor(`table:${e.rid}:${n}`), i = e.rid === t.myRid ? t.anchor("hand") : t.anchor(`seat:${e.rid}`);
		if (!r || !i) return null;
		let a = {
			x: i.x + i.w / 2 - r.w / 2,
			y: i.y + i.h / 2 - r.h / 2,
			w: r.w,
			h: r.h
		}, o = t.queued ? 180 : 580;
		return {
			ms: o,
			hide: t.queued ? [] : [`table:${e.rid}:${n}`],
			node: /* @__PURE__ */ f(h, {
				from: a,
				to: r,
				ms: o,
				children: /* @__PURE__ */ f(q, {
					id: n,
					style: {
						width: r.w,
						height: r.h
					}
				})
			})
		};
	},
	activate(e, t) {
		let n = e.data, r = t.anchor(`table:${e.rid}:${n.card}`) ?? t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 580,
			node: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(g, {
				at: r,
				ms: 580
			}), (n.points > 0 || n.bees > 0) && /* @__PURE__ */ f(m, {
				at: r,
				ms: 580,
				children: /* @__PURE__ */ p("span", {
					className: "bnx-score-float",
					children: [
						/* @__PURE__ */ f(K, { name: n.bees ? "bee" : "points" }),
						"+",
						n.bees || n.points
					]
				})
			})] })
		} : null;
	},
	bees(e, t) {
		let { rids: n } = e.data;
		return {
			ms: 580,
			node: n.map((e) => {
				let n = t.anchor(`seat:${e}`);
				if (!n) return null;
				let r = {
					x: n.x + n.w / 2 - 20,
					y: n.y + 100,
					w: 40,
					h: 40
				};
				return /* @__PURE__ */ f(h, {
					from: r,
					to: {
						x: n.x + n.w / 2 - 20,
						y: n.y,
						w: 40,
						h: 40
					},
					ms: 580,
					children: /* @__PURE__ */ f(K, {
						name: "bee",
						className: "bnx-bee-flight"
					})
				}, e);
			})
		};
	},
	roundEnd() {
		return {
			ms: 580,
			node: null
		};
	},
	bonus(e, t) {
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: 580,
			node: /* @__PURE__ */ f(m, {
				at: n,
				ms: 580,
				children: /* @__PURE__ */ p("span", {
					className: "bnx-score-float",
					children: [
						/* @__PURE__ */ f(K, { name: "hive" }),
						"+",
						e.data.points
					]
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/bearnecessities/game-over.tsx
function be({ result: e, public: t, members: r, myRid: i, onPlayAgain: o, onBackToLobby: c, hintCount: l }) {
	let u = t, d = a(), [m, h] = n(!0), g = (e) => r.find((t) => t.rid === e)?.name ?? e, v = e.ranking.map((e) => u.players.find((t) => t.rid === e));
	return /* @__PURE__ */ p("div", {
		className: "bnx-result",
		children: [/* @__PURE__ */ p("div", {
			className: "bnx-result-table",
			inert: m,
			children: [/* @__PURE__ */ f(Y, {
				pub: u,
				members: r,
				myRid: i,
				send: () => {},
				review: !0
			}), /* @__PURE__ */ f("button", {
				className: "bnx-reopen",
				onClick: () => h(!0),
				children: d("games.bearnecessities.showResult")
			})]
		}), /* @__PURE__ */ f("div", {
			className: "bnx-result-shade",
			hidden: !m,
			children: /* @__PURE__ */ p("section", {
				className: "bnx-result-paper",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": d("games.bearnecessities.result"),
				children: [
					/* @__PURE__ */ p("header", {
						className: "bnx-result-header",
						children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("p", { children: d("games.bearnecessities.result") }), /* @__PURE__ */ f("h1", { children: d("games.bearnecessities.winner", { name: e.winner.map(g).join(" · ") }) })] }), /* @__PURE__ */ f("button", {
							className: "bnx-result-close",
							"aria-label": d("games.bearnecessities.close"),
							onClick: () => h(!1),
							children: /* @__PURE__ */ f(s, { size: 24 })
						})]
					}),
					/* @__PURE__ */ p("div", {
						className: "bnx-result-content",
						children: [
							/* @__PURE__ */ p("div", {
								className: "bnx-result-emblems",
								children: [
									/* @__PURE__ */ f(K, { name: "points" }),
									/* @__PURE__ */ f(K, { name: "bee" }),
									/* @__PURE__ */ f(K, { name: "hive" })
								]
							}),
							/* @__PURE__ */ p("table", {
								className: "bnx-score-table",
								children: [/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {}), v.map((t) => /* @__PURE__ */ p("th", {
									"data-winner": e.winner.includes(t.rid) || void 0,
									children: [g(t.rid), e.autopilot?.[t.rid] ? /* @__PURE__ */ f("small", { children: d("session.autopilot.share", { n: Math.round(e.autopilot[t.rid] * 100) }) }) : null]
								}, t.rid))] }) }), /* @__PURE__ */ p("tbody", { children: [
									/* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: d("games.bearnecessities.points") }), v.map((e) => /* @__PURE__ */ f("td", { children: e.points - e.bees * N(e.board) }, e.rid))] }),
									/* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: d("games.bearnecessities.bonus") }), v.map((e) => /* @__PURE__ */ p("td", { children: [
										e.bees,
										" × ",
										N(e.board),
										/* @__PURE__ */ f("small", { children: e.bees * N(e.board) })
									] }, e.rid))] }),
									/* @__PURE__ */ p("tr", {
										className: "bnx-total",
										children: [/* @__PURE__ */ f("th", { children: d("games.bearnecessities.total") }), v.map((e) => /* @__PURE__ */ f("td", { children: e.points }, e.rid))]
									})
								] })]
							}),
							l !== void 0 && /* @__PURE__ */ f("p", {
								className: "bnx-result-note",
								children: d("session.hint.usedCount", { n: l })
							})
						]
					}),
					/* @__PURE__ */ p("footer", {
						className: "bnx-result-footer",
						children: [/* @__PURE__ */ f("button", {
							onClick: () => h(!1),
							children: d("games.bearnecessities.review")
						}), o || c ? /* @__PURE__ */ p("div", { children: [o && /* @__PURE__ */ f(_, {
							label: d("games.bearnecessities.again"),
							confirmLabel: d("games.bearnecessities.confirmAgain"),
							onConfirm: o
						}), c && /* @__PURE__ */ f(_, {
							label: d("games.bearnecessities.lobby"),
							confirmLabel: d("games.bearnecessities.confirmLobby"),
							onConfirm: c
						})] }) : /* @__PURE__ */ f("p", { children: d("session.result.waitHost") })]
					})
				]
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/bearnecessities/entry.tsx
var xe = {
	definition: ce,
	View: ue,
	bot: _e,
	describe: ve,
	fx: ye,
	OverView: be,
	locales: {
		zh: {
			name: "Bear Necessities",
			desc: "轮抽照片，构建熊族的日常生活；通过相邻激活与蜜蜂连成得分引擎。",
			rules: "目标：\n经过12轮，组成4列3行的牌阵。通过激活卡牌获得分数，并在终局用蜜蜂与蜂巢获得额外分数；总分最高者获胜，并列共享胜利。\n准备：\n2至4人游玩。将94张牌洗混，每人发5张。四种颜色分别代表城市、水域、山地与沙漠；卡牌可具有动物、熊族、建筑、物品、植物中的一种或两种类别。\n每轮流程：\n每人秘密选择不同的两张手牌，一张用于本轮放置，另一张作为保留牌。全部选好后同时公开本轮放置牌，各自选择位置。第一张牌的位置自由；后续牌须与已有牌正交相邻。阵列可向上下左右扩展，但不能超过4列或3行，已经放置的牌不能移动。\n先激活刚放置的牌，再按自己选择的顺序激活其每张正交邻牌。激活旧牌不会自动激活它的邻牌。望远镜、潜水员、向导等效果允许选择额外激活的牌；同一条连锁中不允许重复激活已经经过的牌，其他独立激活仍可再次激活同一张牌。没有可选目标时结束该条效果。\n目标牌每次被激活时检查条件：满足时只获得横线下的分数，不满足时只获得横线上分数。仅仅满足条件不会自动激活目标牌。统计自己阵列时通常包含本牌；演员明确排除自身。蛇按照卡牌英文原名的首字母S计数；符合条件的牌面标有S，英文原名可在卡牌详情查看。眼镜属性包含单片眼镜、潜水镜和太阳镜，可在牌面详情查看。\n间谍由玩家指定一名对手。各人的本轮放置全部完成后才开始激活；间谍读取所有人的本轮牌阵与放置秘密蜂蜜储藏室后持有的蜜蜂数量，不受点击先后影响。天气预报读取自己本轮的保留牌。\n每轮全部激活结束后，本轮获得分数最少的玩家获得1只蜜蜂，并列最低者各获得1只。其余手牌传给左侧玩家，再将自己的保留牌加入收到的手牌，进入下一轮。\n第4、8轮结束后，先决定保留或弃置当前保留牌，再从牌堆补至5张；其他轮次不补牌。\n终局：\n第12轮仍结算本轮最低分的蜜蜂。将自己持有的蜜蜂数乘以阵列上蜂巢符号总数，所得分数加到累计分数。橡皮鸭具有2个蜂巢。分数最高者获胜。",
			water: "水域",
			desert: "沙漠",
			city: "城市",
			mountain: "山地",
			animal: "动物",
			bear: "熊族",
			building: "建筑",
			item: "物品",
			plant: "植物",
			round: "第{{n}} / 12轮",
			score: "分数",
			bees: "蜜蜂",
			hives: "蜂巢",
			roundScore: "本轮分数",
			choose: "选择本轮放置牌与保留牌",
			chooseReserve: "选择一张保留牌",
			confirm: "确认选择",
			waiting: "等待其他玩家",
			place: "选择相邻位置放置卡牌",
			activate: "选择下一张要激活的邻牌",
			target: "选择要额外激活的卡牌",
			opponent: "选择一名对手",
			resolving: "正在激活卡牌",
			beeTime: "结算本轮蜜蜂",
			refill: "保留或弃置保留牌，然后补至5张手牌",
			keep: "保留并补4张",
			discard: "弃置并补5张",
			keepLabel: "保留牌",
			playLabel: "放置牌",
			inspect: "查看卡牌",
			close: "关闭",
			cancel: "取消选择",
			placeAt: "放置于坐标（{{x}}，{{y}}）",
			own: "我的阵列",
			inspectBoard: "查看{{name}}的阵列",
			glasses: "戴有眼镜",
			noGlasses: "未戴眼镜",
			goal: "目标牌",
			hiveCount: "{{n}}个蜂巢",
			empty: "空位",
			done: "相册完成",
			winner: "{{name}}获胜",
			result: "旅程收获",
			points: "激活得分",
			bonus: "蜜蜂与蜂巢",
			total: "总分",
			review: "查看相册",
			showResult: "查看结算",
			again: "重新开始",
			lobby: "返回大厅",
			confirmAgain: "确认重新开始",
			confirmLobby: "确认返回大厅",
			hint: "放置{{card}}，保留{{reserve}}",
			hintActivate: "激活{{card}}",
			hintPlace: "在坐标（{{x}}，{{y}}）放置",
			hintOpponent: "选择{{name}}的阵列",
			spyChoice: "选择{{name}}，获得{{n}}分",
			errPhase: "当前无法执行此操作。",
			errCard: "请选择自己手中不同的两张牌。",
			errPlace: "请选择正交相邻且不超过4列3行的位置。",
			errTarget: "请选择当前可以激活的目标。",
			lastActivation: "{{card}}：获得{{n}}分",
			roundBees: "本轮蜜蜂已发放",
			selectPlay: "选择放置牌",
			selectReserve: "选择保留牌",
			c0: {
				name: "小河狸",
				effect: "获得2分；若与河狸爸爸或河狸妈妈相邻，改为获得8分。"
			},
			c1: {
				name: "河狸爸爸",
				effect: "获得3分。"
			},
			c2: {
				name: "河狸妈妈",
				effect: "获得3分。"
			},
			c3: {
				name: "鱼",
				effect: "自己最大的水域连通组中，每张水域牌使你获得2分。"
			},
			c4: {
				name: "鱼",
				effect: "自己最大的水域连通组中，每张水域牌使你获得2分。"
			},
			c5: {
				name: "鱼",
				effect: "自己最大的水域连通组中，每张水域牌使你获得2分。"
			},
			c6: {
				name: "鱼",
				effect: "自己最大的水域连通组中，每张水域牌使你获得2分。"
			},
			c7: {
				name: "鱼",
				effect: "自己最大的水域连通组中，每张水域牌使你获得2分。"
			},
			c8: {
				name: "鱼",
				effect: "自己最大的水域连通组中，每张水域牌使你获得2分。"
			},
			c9: {
				name: "鱼",
				effect: "自己最大的水域连通组中，每张水域牌使你获得2分。"
			},
			c10: {
				name: "鱼",
				effect: "自己最大的水域连通组中，每张水域牌使你获得2分。"
			},
			c11: {
				name: "钓鱼小屋",
				effect: "若恰好与1张熊族牌相邻，获得4分。"
			},
			c12: {
				name: "港口",
				effect: "获得2分；若与至少2张水域牌相邻，改为获得7分。"
			},
			c13: {
				name: "灯塔",
				effect: "本行与本列每张水域牌使你获得2分，本牌只计一次。"
			},
			c14: {
				name: "望远镜",
				effect: "激活自己阵列中的1张水域牌。"
			},
			c15: {
				name: "宝箱",
				effect: "自己阵列中，每张物品牌使你获得3分。"
			},
			c16: {
				name: "收藏家",
				effect: "获得2分；若自己阵列中有至少5张同色牌，改为获得12分。"
			},
			c17: {
				name: "潜水员",
				effect: "激活自己阵列中的1张物品牌。"
			},
			c18: {
				name: "钓鱼熊",
				effect: "若与至少1张水域牌相邻，获得4分。"
			},
			c19: {
				name: "间谍",
				effect: "选择一名对手，其阵列中每张水域牌使你获得2分。"
			},
			c20: {
				name: "芦苇",
				effect: "若恰好与1张水域牌相邻，获得3分。"
			},
			c21: {
				name: "芦苇",
				effect: "若恰好与1张水域牌相邻，获得3分。"
			},
			c22: {
				name: "睡莲",
				effect: "每张相邻水域牌使你获得3分。"
			},
			c24: {
				name: "郊狼",
				effect: "每张相邻山地牌使你获得4分。"
			},
			c25: {
				name: "蜂后",
				effect: "相邻牌上每个蜂巢符号使你获得4分。"
			},
			c26: {
				name: "大型贸易站",
				effect: "获得2分；若相邻牌包含全部4种颜色，改为获得16分。"
			},
			c27: {
				name: "中央情报局总部",
				effect: "自己阵列中，每张间谍牌使你获得5分。"
			},
			c28: {
				name: "岩石庇护所",
				effect: "获得3分。"
			},
			c29: {
				name: "小型贸易站",
				effect: "获得2分；若相邻牌恰好包含2种颜色，改为获得8分。"
			},
			c30: {
				name: "贸易站",
				effect: "获得2分；若相邻牌恰好包含3种颜色，改为获得12分。"
			},
			c31: {
				name: "熊式烧烤炉",
				effect: "每张相邻鱼牌使你获得6分。"
			},
			c32: {
				name: "望远镜",
				effect: "激活自己阵列中的1张沙漠牌。"
			},
			c33: {
				name: "指南针",
				effect: "每张相邻牌使你获得2分。"
			},
			c34: {
				name: "秘密蜂蜜储藏室",
				effect: "放置时获得2只蜜蜂；被其他牌激活时获得1分。"
			},
			c35: {
				name: "路标",
				effect: "每张相邻城市牌使你获得4分。"
			},
			c36: {
				name: "水壶",
				effect: "每张相邻沙漠牌使你获得4分。"
			},
			c37: {
				name: "探险家",
				effect: "相邻牌中，每种颜色使你获得3分。"
			},
			c38: {
				name: "摄影师",
				effect: "获得2分；若其右侧相邻位置是动物牌，改为获得8分。"
			},
			c39: {
				name: "间谍",
				effect: "选择一名对手，其阵列中每张城市牌与每张山地牌分别使你获得1分。"
			},
			c40: {
				name: "间谍",
				effect: "选择一名对手，其阵列中每张目标牌使你获得3分。"
			},
			c41: {
				name: "寻宝者",
				effect: "获得2分；若与至少1张目标牌相邻，改为获得8分。"
			},
			c42: {
				name: "仙人掌",
				effect: "若没有相邻熊族牌，获得4分。"
			},
			c43: {
				name: "向日葵",
				effect: "若恰好与1张沙漠牌相邻，获得5分。"
			},
			c44: {
				name: "丝兰",
				effect: "自己阵列中，每张沙漠牌使你获得3分。"
			},
			c46: {
				name: "猫",
				effect: "每张相邻物品牌使你获得4分。"
			},
			c47: {
				name: "狗",
				effect: "每张相邻熊族牌使你获得3分。"
			},
			c48: {
				name: "鸽子",
				effect: "本牌下方所有行中，每张熊族牌使你获得4分。"
			},
			c49: {
				name: "地窖",
				effect: "本牌上方所有行中，每张建筑牌使你获得4分。"
			},
			c50: {
				name: "工厂",
				effect: "若没有相邻城市牌，获得4分。"
			},
			c51: {
				name: "郊区公寓",
				effect: "自己阵列中，每个完整的3张牌列使你获得2分。"
			},
			c52: {
				name: "车站",
				effect: "自己阵列中，每个完整的4张牌行使你获得3分。"
			},
			c53: {
				name: "旅游咨询处",
				effect: "自己阵列中，每张城市牌使你获得1分。"
			},
			c54: {
				name: "市政厅",
				effect: "本行与本列每张城市牌使你获得2分，本牌只计一次。"
			},
			c55: {
				name: "橡皮鸭",
				effect: "获得2分。"
			},
			c56: {
				name: "望远镜",
				effect: "激活自己阵列中的1张城市牌。"
			},
			c57: {
				name: "路灯",
				effect: "获得2分；若与至少2张建筑牌相邻，改为获得12分。"
			},
			c58: {
				name: "雕像",
				effect: "自己阵列中，每个含有城市牌的列使你获得2分。"
			},
			c59: {
				name: "演员",
				effect: "自己阵列中，除本牌以外每张熊族牌使你获得2分。"
			},
			c60: {
				name: "建筑师",
				effect: "自己阵列中，每张建筑牌使你获得4分。"
			},
			c61: {
				name: "银行家",
				effect: "自己阵列中，每张目标牌使你获得5分。"
			},
			c62: {
				name: "橄榄球运动员",
				effect: "获得2分；若本行已有4张牌，改为获得8分。"
			},
			c63: {
				name: "小熊",
				effect: "获得2分；若自己有至少6只蜜蜂，改为获得10分。"
			},
			c64: {
				name: "验光师",
				effect: "自己阵列中，每张未戴眼镜的熊族牌使你获得4分。"
			},
			c65: {
				name: "军士",
				effect: "本行中，每张熊族牌使你获得3分。"
			},
			c66: {
				name: "间谍",
				effect: "选择一名对手，其阵列中每张沙漠牌使你获得2分。"
			},
			c67: {
				name: "擦窗工",
				effect: "获得2分；若本列已有3张牌，改为获得7分。"
			},
			c68: {
				name: "花箱",
				effect: "自己阵列中，每个含有城市牌的行使你获得2分。"
			},
			c69: {
				name: "玫瑰",
				effect: "获得2分；若恰好与2张熊族牌相邻，改为获得10分。"
			},
			c71: {
				name: "鹰",
				effect: "自己阵列中，每张动物牌使你获得2分。"
			},
			c72: {
				name: "山羊",
				effect: "每张相邻植物牌使你获得4分。"
			},
			c73: {
				name: "蛇",
				effect: "自己阵列中，每张英文原名以S开头的牌使你获得2分。"
			},
			c74: {
				name: "瞭望塔",
				effect: "自己阵列中，每张不与本牌相邻的牌使你获得1分，包含本牌。"
			},
			c75: {
				name: "研究实验室",
				effect: "获得2分；若相邻牌中至少有1张植物牌和1张动物牌，改为获得10分。"
			},
			c76: {
				name: "游客中心",
				effect: "获得2分；若自己阵列包含全部4种颜色，改为获得7分。"
			},
			c77: {
				name: "背包",
				effect: "获得2分；若自己阵列中有至少3张物品牌，改为获得8分。"
			},
			c78: {
				name: "望远镜",
				effect: "激活自己阵列中的1张山地牌。"
			},
			c79: {
				name: "饮水槽",
				effect: "每张相邻动物牌使你获得4分。"
			},
			c80: {
				name: "零食袋",
				effect: "自己每只蜜蜂使你获得2分。"
			},
			c81: {
				name: "天气预报",
				effect: "若自己的保留牌是城市牌，获得7分。"
			},
			c82: {
				name: "天气预报",
				effect: "若自己的保留牌是水域牌，获得7分。"
			},
			c83: {
				name: "天气预报",
				effect: "若自己的保留牌是山地牌，获得7分。"
			},
			c84: {
				name: "天气预报",
				effect: "若自己的保留牌是沙漠牌，获得7分。"
			},
			c85: {
				name: "植物学家",
				effect: "自己阵列中，每张植物牌使你获得4分。"
			},
			c86: {
				name: "向导",
				effect: "激活自己阵列中的1张熊族牌。"
			},
			c87: {
				name: "远足者",
				effect: "自己阵列中，每张山地牌使你获得2分。"
			},
			c88: {
				name: "间谍",
				effect: "选择一名对手，其阵列中每张沙漠牌与每张山地牌分别使你获得1分。"
			},
			c89: {
				name: "间谍",
				effect: "选择一名对手，其阵列中每张城市牌与每张水域牌分别使你获得1分。"
			},
			c90: {
				name: "间谍",
				effect: "选择一名对手，其每只蜜蜂使你获得2分。"
			},
			c91: {
				name: "野生动物护林员",
				effect: "自己阵列中，每张动物牌使你获得3分。"
			},
			c92: {
				name: "浆果",
				effect: "本行中，每张动物牌使你获得4分。"
			},
			c93: {
				name: "蒲公英",
				effect: "放置时获得7分；被其他牌激活时获得1分。"
			},
			c94: {
				name: "常春藤",
				effect: "每张相邻建筑牌使你获得4分。"
			},
			c95: {
				name: "红杉",
				effect: "获得3分。"
			},
			c96: {
				name: "野胡萝卜",
				effect: "若与至少1张动物牌相邻，获得5分。"
			}
		},
		en: {
			name: "Bear Necessities",
			desc: "Draft photographs and build a Bearfolk tableau, chaining adjacent cards into a scoring engine.",
			rules: "Objective:\nOver 12 rounds, build a tableau of four columns and three rows. Score by activating cards, then multiply bees by hive symbols at the end. Highest total wins; tied players share victory.\nSetup:\nFor 2–4 players. Shuffle all 94 cards and deal five to each player. The four colors represent city, water, mountain and desert. A card has one or two types: animal, Bearfolk, building, item or plant.\nEach round:\nSecretly choose two different cards: one to place and one to keep in reserve. When everyone is ready, reveal the chosen placement cards and choose their positions. The first card is free; subsequent cards must be orthogonally adjacent to an existing card. Expand in any direction without exceeding four columns or three rows. Placed cards cannot move.\nActivate the newly placed card first, then each of its orthogonal neighbors in the order you choose. Activating an old card does not automatically activate its neighbors. Binoculars, Diver and Guide let you select an additional card. A card cannot repeat within the same activation chain; separate activations may activate it again. If there is no eligible target, that effect ends.\nCheck a goal card whenever it activates. If complete, use only the score below the line; otherwise use only the score above it. Completing a goal does not activate its card. Counts in your tableau normally include the card itself; Actor explicitly excludes itself. Snake counts cards whose original English names start with S. These cards carry an S mark; their English names are in card details. Glasses include a monocle, diving goggles and sunglasses; card details show this attribute.\nFor a Spy, choose one opponent. All placements finish before activations begin. Spies use this round’s complete tableaux and bee counts after placing Secret Honey Stash, independent of click order. Weather Forecast checks your current reserve card.\nAfter all activations, the player scoring the fewest points this round gains one bee. Tied last players each gain one. Pass your remaining hand to the player on your left, and add your reserve card to the hand you receive.\nAfter rounds four and eight, choose whether to keep or discard your reserve card, then draw up to five cards. Do not draw in other rounds.\nEnd:\nAward the round-12 bee as usual. Multiply your bee count by the total hive symbols in your tableau and add this bonus to your activation score. Rubber Duck has two hives. Highest total wins.",
			water: "Water",
			desert: "Desert",
			city: "City",
			mountain: "Mountain",
			animal: "Animal",
			bear: "Bearfolk",
			building: "Building",
			item: "Item",
			plant: "Plant",
			round: "Round {{n}} / 12",
			score: "Points",
			bees: "Bees",
			hives: "Hives",
			roundScore: "This round",
			choose: "Choose a card to place and a reserve card",
			chooseReserve: "Choose a reserve card",
			confirm: "Confirm selection",
			waiting: "Waiting for other players",
			place: "Choose an adjacent position for your card",
			activate: "Choose the next adjacent card to activate",
			target: "Choose a card for the extra activation",
			opponent: "Choose an opponent",
			resolving: "Activating cards",
			beeTime: "Awarding this round’s bees",
			refill: "Keep or discard your reserve, then draw up to five cards",
			keep: "Keep and draw 4",
			discard: "Discard and draw 5",
			keepLabel: "Reserve",
			playLabel: "Place",
			inspect: "Inspect card",
			close: "Close",
			cancel: "Clear selection",
			placeAt: "Place at ({{x}}, {{y}})",
			own: "My tableau",
			inspectBoard: "View {{name}}’s tableau",
			glasses: "Wearing glasses",
			noGlasses: "Without glasses",
			goal: "Goal card",
			hiveCount: "{{n}} hives",
			empty: "Empty position",
			done: "Album complete",
			winner: "{{name}} wins",
			result: "Journey rewards",
			points: "Activation points",
			bonus: "Bees and hives",
			total: "Total",
			review: "View albums",
			showResult: "Show results",
			again: "Play again",
			lobby: "Back to lobby",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm lobby",
			hint: "Place {{card}} and reserve {{reserve}}",
			hintActivate: "Activate {{card}}",
			hintPlace: "Place at ({{x}}, {{y}})",
			hintOpponent: "Choose {{name}}’s tableau",
			spyChoice: "Choose {{name}} for {{n}} points",
			errPhase: "You cannot do that right now.",
			errCard: "Choose two different cards from your hand.",
			errPlace: "Choose an orthogonally adjacent position within four columns and three rows.",
			errTarget: "Choose an eligible activation target.",
			lastActivation: "{{card}}: gained {{n}} points",
			roundBees: "This round’s bees have been awarded",
			selectPlay: "Choose placement card",
			selectReserve: "Choose reserve card",
			c0: {
				name: "Baby Beaver",
				effect: "2 points; 8 instead if adjacent to Beaver Dad or Beaver Mom."
			},
			c1: {
				name: "Beaver Dad",
				effect: "3 points."
			},
			c2: {
				name: "Beaver Mom",
				effect: "3 points."
			},
			c3: {
				name: "Fish",
				effect: "2 points per water card in your largest connected water group."
			},
			c4: {
				name: "Fish",
				effect: "2 points per water card in your largest connected water group."
			},
			c5: {
				name: "Fish",
				effect: "2 points per water card in your largest connected water group."
			},
			c6: {
				name: "Fish",
				effect: "2 points per water card in your largest connected water group."
			},
			c7: {
				name: "Fish",
				effect: "2 points per water card in your largest connected water group."
			},
			c8: {
				name: "Fish",
				effect: "2 points per water card in your largest connected water group."
			},
			c9: {
				name: "Fish",
				effect: "2 points per water card in your largest connected water group."
			},
			c10: {
				name: "Fish",
				effect: "2 points per water card in your largest connected water group."
			},
			c11: {
				name: "Fishing Cabin",
				effect: "4 points if adjacent to exactly one Bearfolk card."
			},
			c12: {
				name: "Harbor",
				effect: "2 points; 7 instead if adjacent to at least two water cards."
			},
			c13: {
				name: "Lighthouse",
				effect: "2 points per water card in this row and column, counting this card only once."
			},
			c14: {
				name: "Binoculars",
				effect: "Activate one water card in your tableau."
			},
			c15: {
				name: "Chest",
				effect: "3 points per item card in your tableau."
			},
			c16: {
				name: "Collector",
				effect: "2 points; 12 instead if your tableau has at least five cards of one color."
			},
			c17: {
				name: "Diver",
				effect: "Activate one item card in your tableau."
			},
			c18: {
				name: "Fisherbear",
				effect: "4 points if adjacent to at least one water card."
			},
			c19: {
				name: "Spy",
				effect: "Choose an opponent. Gain 2 points per water card in their tableau."
			},
			c20: {
				name: "Reed",
				effect: "3 points if adjacent to exactly one water card."
			},
			c21: {
				name: "Reed",
				effect: "3 points if adjacent to exactly one water card."
			},
			c22: {
				name: "Water Lily",
				effect: "3 points per adjacent water card."
			},
			c24: {
				name: "Coyote",
				effect: "4 points per adjacent mountain card."
			},
			c25: {
				name: "Queen Bee",
				effect: "4 points per hive symbol on adjacent cards."
			},
			c26: {
				name: "Big Trading Post",
				effect: "2 points; 16 instead if adjacent to all four colors."
			},
			c27: {
				name: "CIA Headquarters",
				effect: "5 points per Spy in your tableau."
			},
			c28: {
				name: "Rock Shelter",
				effect: "3 points."
			},
			c29: {
				name: "Small Trading Post",
				effect: "2 points; 8 instead if adjacent to exactly two different colors."
			},
			c30: {
				name: "Trading Post",
				effect: "2 points; 12 instead if adjacent to exactly three different colors."
			},
			c31: {
				name: "Bearbecue",
				effect: "6 points per adjacent Fish."
			},
			c32: {
				name: "Binoculars",
				effect: "Activate one desert card in your tableau."
			},
			c33: {
				name: "Compass",
				effect: "2 points per adjacent card."
			},
			c34: {
				name: "Secret Honey Stash",
				effect: "Gain 2 bees when placed. Gain 1 point when activated by another card."
			},
			c35: {
				name: "Signpost",
				effect: "4 points per adjacent city card."
			},
			c36: {
				name: "Water Canteen",
				effect: "4 points per adjacent desert card."
			},
			c37: {
				name: "Explorer",
				effect: "3 points per different color among adjacent cards."
			},
			c38: {
				name: "Photographer",
				effect: "2 points; 8 instead if an animal card is immediately to its right."
			},
			c39: {
				name: "Spy",
				effect: "Choose an opponent. Gain 1 point per city card and 1 per mountain card in their tableau."
			},
			c40: {
				name: "Spy",
				effect: "Choose an opponent. Gain 3 points per goal card in their tableau."
			},
			c41: {
				name: "Treasure Hunter",
				effect: "2 points; 8 instead if adjacent to at least one goal card."
			},
			c42: {
				name: "Cactus",
				effect: "4 points if not adjacent to a Bearfolk card."
			},
			c43: {
				name: "Sunflower",
				effect: "5 points if adjacent to exactly one desert card."
			},
			c44: {
				name: "Yucca",
				effect: "3 points per desert card in your tableau."
			},
			c46: {
				name: "Cat",
				effect: "4 points per adjacent item card."
			},
			c47: {
				name: "Dog",
				effect: "3 points per adjacent Bearfolk card."
			},
			c48: {
				name: "Pigeon",
				effect: "4 points per Bearfolk card in all rows below this card."
			},
			c49: {
				name: "Cellar",
				effect: "4 points per building card in all rows above this card."
			},
			c50: {
				name: "Factory",
				effect: "4 points if not adjacent to a city card."
			},
			c51: {
				name: "Suburban Apartments",
				effect: "2 points per complete column in your tableau."
			},
			c52: {
				name: "Station",
				effect: "3 points per complete row in your tableau."
			},
			c53: {
				name: "Tourist Office",
				effect: "1 point per city card in your tableau."
			},
			c54: {
				name: "Town Hall",
				effect: "2 points per city card in this row and column, counting this card only once."
			},
			c55: {
				name: "Rubber Duck",
				effect: "2 points."
			},
			c56: {
				name: "Binoculars",
				effect: "Activate one city card in your tableau."
			},
			c57: {
				name: "Streetlight",
				effect: "2 points; 12 instead if adjacent to at least two building cards."
			},
			c58: {
				name: "Statue",
				effect: "2 points per column containing at least one city card."
			},
			c59: {
				name: "Actor",
				effect: "2 points for each other Bearfolk card in your tableau."
			},
			c60: {
				name: "Architect",
				effect: "4 points per building card in your tableau."
			},
			c61: {
				name: "Banker",
				effect: "5 points per goal card in your tableau."
			},
			c62: {
				name: "Football Player",
				effect: "2 points; 8 instead if this row is complete."
			},
			c63: {
				name: "Bearlet",
				effect: "2 points; 10 instead if you have at least six bees."
			},
			c64: {
				name: "Optician",
				effect: "4 points per Bearfolk card without glasses in your tableau."
			},
			c65: {
				name: "Sergeant",
				effect: "3 points per Bearfolk card in this row."
			},
			c66: {
				name: "Spy",
				effect: "Choose an opponent. Gain 2 points per desert card in their tableau."
			},
			c67: {
				name: "Window Cleaner",
				effect: "2 points; 7 instead if this column is complete."
			},
			c68: {
				name: "Planter Box",
				effect: "2 points per row containing at least one city card."
			},
			c69: {
				name: "Rose",
				effect: "2 points; 10 instead if adjacent to exactly two Bearfolk cards."
			},
			c71: {
				name: "Eagle",
				effect: "2 points per animal card in your tableau."
			},
			c72: {
				name: "Mountain Goat",
				effect: "4 points per adjacent plant card."
			},
			c73: {
				name: "Snake",
				effect: "2 points per card whose English name starts with S in your tableau."
			},
			c74: {
				name: "Lookout Tower",
				effect: "1 point per card in your tableau that is not adjacent to this card, including this card."
			},
			c75: {
				name: "Research Lab",
				effect: "2 points; 10 instead if adjacent to at least one plant and at least one animal."
			},
			c76: {
				name: "Visitor Center",
				effect: "2 points; 7 instead if all four colors are in your tableau."
			},
			c77: {
				name: "Backpack",
				effect: "2 points; 8 instead if your tableau has at least three item cards."
			},
			c78: {
				name: "Binoculars",
				effect: "Activate one mountain card in your tableau."
			},
			c79: {
				name: "Water Trough",
				effect: "4 points per adjacent animal card."
			},
			c80: {
				name: "Snack Bag",
				effect: "2 points per bee you have."
			},
			c81: {
				name: "Weather Forecast",
				effect: "7 points if your reserve card is a city card."
			},
			c82: {
				name: "Weather Forecast",
				effect: "7 points if your reserve card is a water card."
			},
			c83: {
				name: "Weather Forecast",
				effect: "7 points if your reserve card is a mountain card."
			},
			c84: {
				name: "Weather Forecast",
				effect: "7 points if your reserve card is a desert card."
			},
			c85: {
				name: "Botanist",
				effect: "4 points per plant card in your tableau."
			},
			c86: {
				name: "Guide",
				effect: "Activate one Bearfolk card in your tableau."
			},
			c87: {
				name: "Hiker",
				effect: "2 points per mountain card in your tableau."
			},
			c88: {
				name: "Spy",
				effect: "Choose an opponent. Gain 1 point per desert card and 1 per mountain card in their tableau."
			},
			c89: {
				name: "Spy",
				effect: "Choose an opponent. Gain 1 point per city card and 1 per water card in their tableau."
			},
			c90: {
				name: "Spy",
				effect: "Choose an opponent. Gain 2 points per bee they have."
			},
			c91: {
				name: "Wildlife Ranger",
				effect: "3 points per animal card in your tableau."
			},
			c92: {
				name: "Berries",
				effect: "4 points per animal card in this row."
			},
			c93: {
				name: "Dandelion",
				effect: "7 points when placed. 1 point when activated by another card."
			},
			c94: {
				name: "Ivy",
				effect: "4 points per adjacent building card."
			},
			c95: {
				name: "Sequoia",
				effect: "3 points."
			},
			c96: {
				name: "Wild Carrot",
				effect: "5 points if adjacent to at least one animal card."
			}
		}
	}
};
//#endregion
export { xe as default };
