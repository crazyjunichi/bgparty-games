import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useT as r } from "@bgparty/sdk/i18n";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { Fragment as o, jsx as s, jsxs as c } from "react/jsx-runtime";
import { Floater as l, FlySprite as u, PulseBox as d } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as f } from "@bgparty/sdk/confirm-button";
import { OptionRadio as p, OptionSection as m, OptionSwitch as h } from "@bgparty/sdk/ui/game-options";
//#region src/games/rebelprincess/data.ts
var g = [
	"alice",
	"cinderella",
	"ice",
	"mermaid",
	"mulan",
	"pea",
	"pocahontas",
	"scheherazade",
	"sleeping",
	"snow",
	"rapunzel",
	"thumbelina"
], _ = [
	...g,
	"red",
	"swan",
	"beauty",
	"carmesina"
], v = [
	..."abcdefghijklmnopqrstuvwxyz",
	"alpha",
	"beta",
	"gamma",
	"delta",
	"epsilon",
	"zeta"
], y = {
	a: [0, 3],
	b: [0, 1],
	c: [3, 0],
	d: [0, 3],
	e: [1, 1],
	f: [0, 3],
	g: [0, 1],
	h: [0, 2],
	i: [1, 0],
	j: [1, 1],
	k: [0, 1],
	l: [0, 2],
	m: [1, 0],
	n: [0, 2],
	o: [1, 1],
	p: [1, 0],
	q: [0, 1],
	r: [2, 0],
	s: [0, 2],
	t: [1, 0],
	u: [1, 1],
	v: [3, 0],
	w: [3, 0],
	x: [2, 0],
	y: [2, 0],
	z: [0, 2],
	alpha: [0, 0],
	beta: [2, 0],
	gamma: [3, 0],
	delta: [1, 0],
	epsilon: [0, 2],
	zeta: [0, 1]
}, b = [
	"e",
	"j",
	"o",
	"t",
	"y",
	"z",
	"gamma"
], x = (e) => Math.floor(e / 12), S = (e) => e % 12 + 1, C = (e) => e === 43, w = (e) => Array.from({ length: 48 }, (e, t) => t).filter((t) => e === 6 || S(t) <= 10 && (e !== 3 || S(t) !== 1)), ee = [
	"games.rebelprincess.suits.queens",
	"games.rebelprincess.suits.princes",
	"games.rebelprincess.suits.fairies",
	"games.rebelprincess.suits.pets"
], T = {
	alice: "games.rebelprincess.princess.alice",
	cinderella: "games.rebelprincess.princess.cinderella",
	ice: "games.rebelprincess.princess.ice",
	mermaid: "games.rebelprincess.princess.mermaid",
	mulan: "games.rebelprincess.princess.mulan",
	pea: "games.rebelprincess.princess.pea",
	pocahontas: "games.rebelprincess.princess.pocahontas",
	scheherazade: "games.rebelprincess.princess.scheherazade",
	sleeping: "games.rebelprincess.princess.sleeping",
	snow: "games.rebelprincess.princess.snow",
	rapunzel: "games.rebelprincess.princess.rapunzel",
	thumbelina: "games.rebelprincess.princess.thumbelina",
	red: "games.rebelprincess.princess.red",
	swan: "games.rebelprincess.princess.swan",
	beauty: "games.rebelprincess.princess.beauty",
	carmesina: "games.rebelprincess.princess.carmesina"
}, E = {
	id: "rebelprincess",
	tier: "alpha",
	mechanics: ["trick-taking", "hand-management"],
	interactionTags: [],
	nameKey: "games.rebelprincess.name",
	descKey: "games.rebelprincess.desc",
	rulesKey: "games.rebelprincess.rules",
	icon: "👑",
	iconImg: "games/rebelprincess.webp",
	rulesUrl: { en: "https://cdn.shopify.com/s/files/1/0740/4855/files/RPDX_Online_Rules_Preview.pdf" },
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [4, 5],
	accent: "#315b64",
	releasedAt: "2026-11-03T01:33:00+08:00",
	search: {
		py: "pan ni gong zhu hao hua ban",
		init: "pngzhhb"
	},
	hotseat: "cover"
}, D = t.int().min(0).max(47), O = t.object({
	rounds: t.union([t.literal(3), t.literal(5)]).default(5),
	random: t.boolean().default(!1),
	expansion: t.boolean().default(!1),
	promos: t.boolean().default(!1),
	roundIds: t.array(t.enum(v)).max(5).default([])
}).prefault({}), k = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(150),
	cards: t.array(D).max(12).default([])
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), A = [
	"confirm",
	"skip",
	"power",
	"play",
	"zero",
	"ignore",
	"return",
	"princess",
	"target",
	"suit",
	"swap",
	"keep"
], te = /* @__PURE__ */ "choosePrincess.pass.lock.revealSuit.hide.draft.bid.discard.before.play.iceTarget.freeze.mermaid.mermaidRetry.leader.barterTarget.barter.contribute.distribute.mulan.mulanCard.alice.haggle.haggleCard.redAsk.redGive.beautyFirst.beautySecond.afterPlay.wait.reveal.collect.score.roundEnd.done".split("."), ne = t.object({
	id: t.string(),
	label: t.enum(A),
	card: D.nullable().default(null),
	princess: t.enum(_).nullable().default(null),
	target: t.string().nullable().default(null),
	suit: t.int().min(0).max(3).nullable().default(null)
}), j = t.object({
	title: t.enum(te),
	count: t.int().min(0).max(12),
	cards: t.array(D),
	options: t.array(ne)
}), re = t.object({
	rid: t.string(),
	card: D.nullable(),
	suit: t.int().min(0).max(3).nullable(),
	zero: t.boolean()
}), ie = t.object({
	round: t.string(),
	scores: t.record(t.string(), t.number()),
	rebels: t.array(t.string()),
	tricks: t.record(t.string(), t.int())
}), M = t.object({
	phase: t.enum(te),
	round: t.int(),
	totalRounds: t.int(),
	roundId: t.string(),
	revealedRounds: t.array(t.string()),
	leader: t.string(),
	turn: t.string().nullable(),
	broken: t.boolean(),
	limit: t.number(),
	trick: t.array(re),
	players: t.array(t.object({
		rid: t.string(),
		princess: t.enum(_).nullable(),
		used: t.boolean(),
		count: t.int(),
		ready: t.boolean(),
		score: t.number(),
		tricks: t.int(),
		open: t.array(D)
	})),
	rows: t.array(ie),
	winner: t.string().nullable(),
	effects: t.array(t.enum(_))
}), N = t.object({
	hand: t.array(D),
	selected: t.array(D),
	princesses: t.array(t.enum(_)),
	request: j.nullable(),
	received: t.array(D),
	sources: t.array(t.object({
		card: D,
		rid: t.string()
	}))
}), P = {
	reveal: 900,
	collect: 850,
	score: 1500,
	deal: 650
}, F = (e) => Object.fromEntries(e.map((e) => [e, []])), I = (e) => Object.fromEntries(e.map((e) => [e, 0])), L = (e, t, n = 1) => e.players[(e.players.indexOf(t) + e.players.length + n) % e.players.length], R = (e) => e.rounds[e.round - 1];
function z(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function B(e, t, n) {
	e.hands[t] = e.hands[t].filter((e) => !n.includes(e)), e.open = e.open.filter((e) => !n.includes(e));
}
function V(e, t, n) {
	e.hands[t].push(...n), e.hands[t].sort((e, t) => e - t);
}
function H(e, t, n, r = "", i = [], a = null) {
	e.phase = t, e.pending = {
		kind: t,
		actor: n,
		target: r,
		cards: i,
		power: a,
		index: 0
	};
}
function ae(e) {
	let t = z(e, w(e.players.length)), n = t.length / e.players.length;
	e.players.forEach((r, i) => {
		e.hands[r] = t.slice(i * n, (i + 1) * n).sort((e, t) => e - t);
	}), e.stash = F(e.players), e.locked = F(e.players), e.won = F(e.players), e.submissions = {}, e.open = [], e.visibleWon = [], e.gifts = [], e.used = Object.fromEntries(e.players.map((e) => [e, !1])), e.tricks = I(e.players), e.bids = {}, e.broken = !1, e.limit = 0, e.received = F(e.players), e.trick = [], e.pending = null, e.winner = null, e.effects = [], e.blocked = [], e.step = 0, e.phase = R(e) === "alpha" ? "draft" : "pass", e.phase === "pass" && y[R(e)].every((e) => e === 0) && oe(e);
}
function oe(e) {
	e.submissions = {};
	let t = R(e);
	if (t === "epsilon" && e.players.some((t) => !e.hands[t].some((e) => S(e) < 8))) {
		ae(e);
		return;
	}
	let n = {
		b: "lock",
		h: "revealSuit",
		m: "hide",
		q: "hide",
		beta: "bid",
		epsilon: "discard"
	};
	n[t] ? e.phase = n[t] : U(e);
}
function U(e) {
	let t = R(e);
	if (e.players.every((t) => e.hands[t].length === 0)) {
		if (e.players.some((t) => e.stash[t].length)) {
			let n = e.stash;
			e.stash = F(e.players), e.players.forEach((r) => V(e, t === "q" ? L(e, r, -1) : r, n[r]));
		} else if (e.players.some((t) => e.locked[t].length)) e.players.forEach((t) => {
			V(e, t, e.locked[t]), e.locked[t] = [];
		});
		else {
			Ce(e);
			return;
		}
	}
	if (t === "n" && e.players.every((t) => e.hands[t].length === 3)) {
		e.players.forEach((t) => {
			e.won[t].push(...e.hands[t]), e.visibleWon.push(...e.hands[t]), e.hands[t] = [];
		}), Ce(e);
		return;
	}
	e.trick = [], e.winner = null, e.pending = null, e.reverse = !1, e.pea = null, e.forcedSuit = null, e.mermaid = !1, e.frozen = {}, e.effects = [], e.blocked = [], e.swan = null, e.forcedLeader = null, e.sum = 0, e.thresholdWinner = null, e.led = null, e.mulanPassed = [], e.mulanSwapped = [], e.trickPowers = {}, e.zeroCards = [], e.revealed = !1, e.order = Array.from({ length: e.players.length }, (t, n) => L(e, e.leader, n)), e.at = 0, e.preAt = e.players.indexOf(L(e, e.leader)), e.passes = 0, e.phase = "before", e.step++;
}
function se(e) {
	e.pending = null, e.phase = R(e) === "o" && e.gifts.length === 0 ? "contribute" : "play", e.submissions = {};
}
function W(e, t) {
	e.pending = null, e.phase = "before", e.preAt = e.players.indexOf(L(e, t)), e.passes = 0;
}
function G(e, t, n) {
	return e.used[t] || e.blocked.includes(t) ? [] : e.roles[t] === n ? [""] : e.roles[t] === "carmesina" ? e.players.filter((r) => r !== t && e.roles[r] === n && !e.used[r] && !e.blocked.includes(r)) : [];
}
function ce(e, t, n, r) {
	r !== "repeat" && (e.used[t] = !0, r && e.blocked.push(r), e.effects.push(n), (e.trickPowers[t] ??= []).push(n));
}
function K(e, t, n) {
	return R(e) === "u" && e.trickPowers[t]?.includes(n);
}
function q(e, t) {
	return e.hands[t].filter((n) => !e.open.includes(n) && n !== e.frozen[t]);
}
function le(e, t, n) {
	switch (n) {
		case "cinderella": return !e.reverse;
		case "pea": return e.pea === null;
		case "pocahontas": return !e.mermaid && e.forcedSuit === null;
		case "mermaid": return !(e.leader in e.frozen) && e.forcedSuit === null;
		case "rapunzel": return !(e.leader in e.frozen) && e.forcedSuit === null;
		case "ice": return e.players.some((t) => q(e, t).length >= 2 && !(t in e.frozen) && (t !== e.leader || e.forcedSuit === null));
		case "scheherazade": return e.players.some((n) => n !== t && q(e, n).length > 0 && (R(e) !== "b" || e.hands[n].length !== 1) && !(n === e.leader && (e.forcedSuit !== null || n in e.frozen))) && e.hands[t].length > 0;
		case "sleeping": return !e.mermaid && e.forcedSuit === null && Object.keys(e.frozen).length === 0 && (R(e) !== "b" || e.hands[t].length !== 1);
		default: return !1;
	}
}
var ue = [
	"cinderella",
	"ice",
	"mermaid",
	"pea",
	"pocahontas",
	"scheherazade",
	"sleeping",
	"rapunzel"
];
function J(e) {
	return e.zero ? 0 : S(e.card);
}
function de(e, t) {
	let n = R(e);
	return [...e.visibleWon, ...e.trick.filter((e, r) => e.rid === t || !(n === "i" && r > 0 || n === "zeta" && r === 0)).map((e) => e.card)].filter((e) => !C(e));
}
function fe(e) {
	return e.led ?? x(e.trick[0].original);
}
function pe(e, t, n = !1) {
	let r = e.hands[t], i = R(e);
	if (t in e.frozen) return [e.frozen[t]];
	let a = [...r];
	if (!e.trick.length) e.forcedSuit !== null && r.some((t) => x(t) === e.forcedSuit) ? a = a.filter((t) => x(t) === e.forcedSuit) : !e.broken && a.some((e) => x(e) !== 1) && (a = a.filter((e) => x(e) !== 1));
	else {
		let t = fe(e), r = a.filter((e) => x(e) === t || i === "v" && x(e) === 2);
		if (n ? a = a.filter((e) => x(e) !== 1 && !C(e)) : r.length && (a = r), i === "s") {
			let t = S(e.trick[0].card) % 2, n = a.filter((e) => S(e) % 2 === t);
			n.length && (a = n);
		}
	}
	if (i === "c" && (a = a.filter((e) => {
		let t = r.filter((t) => x(t) === x(e)).map(S);
		return S(e) === Math.min(...t) || S(e) === Math.max(...t);
	})), e.pea !== null && e.pea !== t) {
		let e = a.filter((e) => S(e) > 5);
		e.length && (a = e);
	}
	return a;
}
function me(e) {
	let t = R(e), n = e.trick[0], r = fe(e), i = e.reverse !== (t === "x" && e.trick.filter((e) => S(e.card) === 6).length % 2 == 1);
	if (t === "epsilon" && e.thresholdWinner) return e.thresholdWinner;
	if (t === "u") {
		let t = e.players.map((t) => ({
			p: t,
			cs: e.trick.filter((e) => e.rid === t && x(e.card) === r)
		})).filter((e) => e.cs.length);
		return t.sort((e, t) => {
			let n = (e) => e.cs.reduce((e, t) => e + J(t), 0), r = (e) => (i ? Math.min : Math.max)(...e.cs.map(J));
			return (i ? 1 : -1) * (n(e) - n(t) || r(e) - r(t));
		}), t.length ? t[0].p : n.rid;
	}
	let a = e.trick.filter((e) => x(e.card) === r || t === "v" && x(e.card) === 2);
	if (t === "f" && e.trick.some((e) => x(e.card) === 0) && (a = e.trick.filter((e) => x(e.card) === 0)), t === "r" && e.trick.some((e) => x(e.card) !== r) && (a = e.trick.filter((e) => x(e.card) !== r)), t === "l") {
		a = a.filter((e) => e !== n), a.length || (a = e.trick.slice(1));
		let t = n.zero ? 0 : S(n.original);
		a.sort((e, n) => Math.abs(J(n) - t) - Math.abs(J(e) - t) || (i ? 1 : -1) * (J(e) - J(n)));
	} else a.sort((e, t) => (i ? 1 : -1) * (J(e) - J(t)));
	return a.length ? (t === "g" && a.length > 1 ? a[1] : a[0]).rid : n.rid;
}
function he(e, t, n, r, i) {
	r && ce(e, t, r, i);
	let a = e.trick.length === 0, o = R(e);
	x(n) === 1 && (t in e.frozen || !a && x(n) !== fe(e)) && (e.broken = !0), (a || o === "w") && (e.led = x(n)), e.sum += r === "snow" ? 0 : S(n), o === "epsilon" && !e.thresholdWinner && e.sum > e.limit && (e.thresholdWinner = t), r === "snow" && e.zeroCards.push(n), e.trick.push({
		rid: t,
		card: n,
		zero: r === "snow",
		original: n
	}), B(e, t, [n]), delete e.frozen[t], e.phase = "afterPlay", e.pending = null, G(e, t, "beauty").length && de(e, t).length >= 2 ? H(e, "afterPlay", t) : ge(e);
}
function ge(e) {
	if (e.pending = null, e.at++, e.at >= e.order.length) {
		if (R(e) === "u" && e.trick.length < e.players.length * 2) {
			e.order = e.order.filter((t) => t !== e.swan).concat(e.swan ? [e.swan] : []), e.at = 0, e.phase = "play";
			return;
		}
		e.phase = "reveal", e.beat = P.reveal;
		return;
	}
	e.phase = "play";
}
function _e(e) {
	let t = e.players.find((t) => !e.mulanPassed.includes(t) && (G(e, t, "mulan").length || K(e, t, "mulan")) && ve(e, t).length);
	t ? H(e, "mulan", t) : ye(e);
}
function ve(e, t) {
	return e.trick.filter((n) => n.rid === t && !e.mulanSwapped.includes(n.original) && !C(n.card) && e.hands[t].some((r) => x(r) === x(n.card) && !C(r) && (e.pea === null || e.pea === t || S(r) > 5 || !e.hands[t].some((e) => x(e) === x(r) && S(e) > 5))));
}
function ye(e) {
	e.winner = me(e), !e.trick.some((e) => C(e.card)) && G(e, e.winner, "alice").length ? H(e, "alice", e.winner) : be(e);
}
function be(e) {
	let t = e.winner;
	R(e) === "p" && e.hands[t].length && e.trick.some((e) => e.rid !== t) ? H(e, "haggle", t) : (e.phase = "collect", e.pending = null, e.beat = P.collect);
}
function xe(e) {
	let t = e.winner;
	if (e.won[t].push(...e.trick.map((e) => e.card), ...e.gifts), e.visibleWon.push(...e.trick.map((e) => e.card)), e.tricks[t]++, e.gifts = [], e.leader = t, e.trick = [], R(e) === "gamma" && e.players.every((t) => e.hands[t].length === 0)) {
		let n = L(e, t);
		e.won[n].push(...e.won[t]), e.won[t] = [];
	}
	R(e) === "k" && e.players.some((t) => e.hands[t].length) ? (e.phase = "pass", e.submissions = {}, e.step = -1) : U(e);
}
function Se(e, t) {
	let n = e.won[t], r = R(e), i = n.filter((e) => x(e) === 1), a = n.some(C);
	if (r !== "o" && a && i.length === w(e.players.length).filter((e) => x(e) === 1).length) return -10;
	if (r === "beta" && e.bids[t] === e.tricks[t]) return -e.tricks[t];
	let o = (a ? 5 : 0) + i.length;
	if (r === "j" && (o += n.filter((e) => x(e) === 3).length), r === "d" && (o -= n.filter((e) => S(e) === 3).length * 3), r === "e" && e.tricks[t] === 0 && (o += 5), r === "t" && (o -= n.filter((e) => x(e) === 2).length), r === "delta" && (o -= i.length * 2), r === "y" && e.scores[t] < Math.max(...Object.values(e.scores)) && (o += i.length), r === "z") {
		let e = n.filter((e) => x(e) === 0), t = i.filter((t) => e.some((e) => S(e) === S(t))).length;
		o += t * 2 + Math.min(i.length - t, e.length - t);
	}
	return o;
}
function Ce(e) {
	let t = Object.fromEntries(e.players.map((t) => [t, Se(e, t)])), n = e.players.filter((t) => R(e) !== "o" && e.won[t].some(C) && e.won[t].filter((e) => x(e) === 1).length === w(e.players.length).filter((e) => x(e) === 1).length);
	e.players.forEach((n) => {
		e.scores[n] += t[n];
	}), e.rows.push({
		round: R(e),
		scores: t,
		rebels: n,
		tricks: { ...e.tricks }
	}), e.phase = "score", e.pending = null, e.beat = P.score;
}
function we(e) {
	return [...e.players].sort((t, n) => e.scores[t] - e.scores[n] || e.rows.filter((e) => e.scores[n] <= 0).length - e.rows.filter((e) => e.scores[t] <= 0).length);
}
function Te(e) {
	if (e.round >= e.rounds.length) {
		let t = we(e), n = t[0], r = e.rows.filter((e) => e.scores[n] <= 0).length;
		if (t.filter((t) => e.scores[t] === e.scores[n] && e.rows.filter((e) => e.scores[t] <= 0).length === r).length === 1) {
			e.phase = "done";
			return;
		}
		e.rounds.push(z(e, b.filter((t) => t !== "gamma" || e.config.expansion))[0]);
	}
	let t = Math.min(...Object.values(e.scores));
	e.leader = Array.from({ length: e.players.length }, (t, n) => L(e, e.roundLeader, n + 1)).find((n) => e.scores[n] === t), e.roundLeader = e.leader, e.round++, ae(e);
}
function Y(e, t, n = {}) {
	return {
		id: e,
		label: t,
		card: null,
		princess: null,
		target: null,
		suit: null,
		...n
	};
}
function X(e, t, n = [], r = 0) {
	return {
		title: e,
		options: t,
		cards: n,
		count: r
	};
}
function Z(e, t, n) {
	return n.flatMap((n) => G(e, t, n).map((e) => Y(`power:${n}:${e}`, "power", {
		princess: n,
		target: e || null
	})));
}
function Ee(e) {
	return e.pending ? e.pending.actor : e.phase === "before" ? e.players[e.preAt] : e.phase === "play" ? e.order[e.at] : null;
}
function De(e, t) {
	return t in e.chosen ? null : e.players.length === 6 && t === e.players[5] ? Object.keys(e.chosen).length < 5 ? null : X("choosePrincess", e.discarded.map((e) => Y(e, "princess", { princess: e }))) : X("choosePrincess", e.offers[t].map((e) => Y(e, "princess", { princess: e })));
}
function Oe(e, t) {
	if (!e.players.includes(t)) return null;
	if (e.phase === "choosePrincess") return De(e, t);
	let n = R(e), r = e.hands[t];
	if ((!e.pending || e.phase === "contribute") && [
		"pass",
		"lock",
		"revealSuit",
		"hide",
		"draft",
		"bid",
		"discard",
		"contribute"
	].includes(e.phase)) {
		if (t in e.submissions) return null;
		if (e.phase === "revealSuit") return X(e.phase, [...new Set(r.map(x))].map((e) => Y(String(e), "suit", { suit: e })));
		let i = e.phase === "pass" ? e.step === -1 ? 1 : y[n][0] + y[n][1] : e.phase === "hide" ? r.length / 2 : e.phase === "draft" ? Math.min(2, r.length) : 1, a = e.phase === "bid" ? r.filter((e) => x(e) !== 1 && !C(e)) : e.phase === "discard" ? r.filter((e) => S(e) < 8) : e.phase === "contribute" ? r.filter((n) => n !== e.frozen[t]) : r;
		return X(e.phase, [Y("submit", "confirm")], a, i);
	}
	if (Ee(e) !== t) return null;
	let i = e.pending;
	if (i) switch (i.kind) {
		case "iceTarget": return X(i.kind, e.players.filter((t) => q(e, t).length >= 2 && !(t in e.frozen) && (t !== e.leader || e.forcedSuit === null)).map((e) => Y(e, "target", { target: e })));
		case "freeze": return X(i.kind, [Y("submit", "confirm")], i.cards, 1);
		case "mermaid": return X(i.index ? "mermaidRetry" : i.kind, [
			0,
			1,
			2,
			3
		].filter((t) => !(i.index & 1 << t) && (t !== 1 || e.broken || (i.index & 13) == 13)).map((e) => Y(String(e), "suit", { suit: e })));
		case "leader": return X(i.kind, e.players.map((e) => Y(e, "target", { target: e })));
		case "barterTarget": return X(i.kind, e.players.filter((r) => r !== t && q(e, r).length && (n !== "b" || e.hands[r].length !== 1) && !(r === e.leader && (e.forcedSuit !== null || r in e.frozen))).map((e) => Y(e, "target", { target: e })));
		case "barter": return X(i.kind, [Y("return", "return"), ...r.map((e) => Y(String(e), "swap", { card: e }))]);
		case "distribute": return X(i.kind, [Y("submit", "confirm", { target: e.players[i.index] })], i.cards, 1);
		case "mulan": return X(i.kind, [Y("skip", "skip"), ...K(e, t, "mulan") ? [Y("power:mulan:repeat", "power", { princess: "mulan" })] : Z(e, t, ["mulan"])]);
		case "mulanCard": {
			if (!i.cards.length) return X(i.kind, ve(e, t).map((e) => Y(String(e.card), "swap", { card: e.card })));
			let n = i.cards[0], a = r.filter((e) => x(e) === x(n) && !C(e)), o = a.filter((e) => S(e) > 5);
			return X(i.kind, [Y("submit", "confirm")], e.pea && e.pea !== t && o.length ? o : a, 1);
		}
		case "alice": return X(i.kind, [Y("skip", "skip"), ...Z(e, t, ["alice"])]);
		case "haggle": return X(i.kind, [Y("skip", "skip"), ...r.map((e) => Y(String(e), "swap", { card: e }))]);
		case "haggleCard": return X(i.kind, e.trick.filter((e) => e.rid !== t).map((e) => Y(String(e.card), "swap", { card: e.card })));
		case "redAsk": return X(i.kind, Array.from({ length: 48 }, (e, t) => t).filter((e) => !C(e) && !r.includes(e) && r.some((t) => x(t) === x(e))).map((e) => Y(String(e), "swap", { card: e })));
		case "redGive": return X(i.kind, [Y("submit", "confirm")], r.filter((e) => x(e) === x(i.cards[0])), 1);
		case "afterPlay": return X(i.kind, [Y("skip", "skip"), ...Z(e, t, ["beauty"])]);
		case "beautyFirst": return X(i.kind, [Y("submit", "confirm")], de(e, t), 1);
		case "beautySecond": return X(i.kind, [Y("submit", "confirm")], de(e, t).filter((e) => e !== i.cards[0]), 1);
	}
	if (e.phase === "before") return X("before", [Y("skip", "skip"), ...Z(e, t, ue.filter((n) => le(e, t, n)))]);
	if (e.phase === "play") {
		let n = pe(e, t), i = n.map((e) => Y(`play:${e}`, "play", { card: e })), a = K(e, t, "snow") ? ["repeat"] : G(e, t, "snow"), o = K(e, t, "thumbelina") ? ["repeat"] : G(e, t, "thumbelina");
		return a.forEach((e) => n.filter((e) => S(e) <= 7).forEach((t) => i.push(Y(`play:${t}:snow:${e}`, "zero", {
			card: t,
			princess: "snow",
			target: e && e !== "repeat" ? e : null
		})))), e.trick.length && !(t in e.frozen) && o.forEach((n) => pe(e, t, !0).forEach((e) => i.push(Y(`play:${e}:thumbelina:${n}`, "ignore", {
			card: e,
			princess: "thumbelina",
			target: n && n !== "repeat" ? n : null
		})))), t in e.frozen || (r.some((e) => !C(e)) && Array.from({ length: 48 }, (e, t) => t).some((e) => !C(e) && !r.includes(e) && r.some((t) => x(t) === x(e))) && i.push(...Z(e, t, ["red"])), e.swan === null && e.forcedLeader !== t && (e.leader !== t || e.forcedSuit === null) && e.order.indexOf(t) !== e.order.length - 1 && i.push(...Z(e, t, ["swan"]))), X("play", i);
	}
	return null;
}
function ke(e, t, n, r) {
	let i = e.phase, a = R(e), o = e.players.length;
	if (e.submissions[t] = i === "revealSuit" ? e.hands[t].filter((e) => x(e) === Number(n)) : r, Object.keys(e.submissions).length < o) return;
	let s = e.submissions;
	if (e.submissions = {}, i === "pass") {
		let [t, n] = e.step === -1 ? [0, 1] : y[a];
		e.players.forEach((t) => B(e, t, s[t])), e.players.forEach((r) => {
			let i = s[r];
			V(e, L(e, r), i.slice(0, t)), V(e, L(e, r, -1), i.slice(t, t + n)), e.received[L(e, r)].push(...i.slice(0, t)), e.received[L(e, r, -1)].push(...i.slice(t, t + n));
		}), e.step === -1 ? U(e) : oe(e);
	} else if (i === "draft") {
		if (e.players.forEach((t) => {
			e.stash[t].push(...s[t]), B(e, t, s[t]);
		}), e.players.every((t) => e.hands[t].length === 0)) e.players.forEach((t) => {
			V(e, t, e.stash[t]), e.stash[t] = [];
		}), U(e);
		else {
			let t = e.hands;
			e.hands = F(e.players), e.players.forEach((n) => V(e, L(e, n), t[n]));
		}
	} else i === "revealSuit" ? (e.open = Object.values(s).flat(), U(e)) : i === "contribute" ? (e.players.forEach((t) => B(e, t, s[t])), e.pending?.power === "sleeping" ? (H(e, "distribute", e.pending.actor, "", e.players.flatMap((e) => s[e]), "sleeping"), e.pending.sources = e.players.map((e) => ({
		rid: e,
		card: s[e][0]
	}))) : (e.gifts = Object.values(s).flat(), e.phase = "play")) : (e.players.forEach((t) => {
		let n = s[t];
		B(e, t, n), i === "lock" && (e.locked[t] = n), i === "hide" && (e.stash[t] = n), i === "bid" && (e.bids[t] = S(n[0])), i === "discard" && (e.limit += S(n[0]));
	}), U(e));
}
function Ae(e, t, n, r) {
	switch (ce(e, t, n, r), n) {
		case "cinderella":
			e.reverse = !e.reverse, W(e, t);
			break;
		case "pea":
			e.pea = t, W(e, t);
			break;
		case "rapunzel":
			e.forcedSuit = 1, W(e, t);
			break;
		case "ice":
			H(e, "iceTarget", t, "", [], n);
			break;
		case "mermaid":
			H(e, "mermaid", t, "", [], n);
			break;
		case "pocahontas":
			H(e, "leader", t, "", [], n);
			break;
		case "scheherazade":
			H(e, "barterTarget", t, "", [], n);
			break;
		case "sleeping":
			H(e, "contribute", t, "", [], n), e.submissions = {};
			break;
		case "mulan":
			H(e, "mulanCard", t, "", [], n);
			break;
		case "alice": {
			let n = z(e, e.trick.map((e) => e.card)), r = R(e) === "u" ? 2 : 1;
			e.players.forEach((t, i) => V(e, t, n.slice(i * r, (i + 1) * r))), e.leader = t, e.trick = [], e.winner = null, U(e);
			break;
		}
		case "red":
			H(e, "redAsk", t, "", [], n);
			break;
		case "swan":
			e.swan = t, e.order = e.order.filter((e) => e !== t).concat(t), e.leader === t && (e.leader = L(e, t), e.forcedSuit = null), e.phase = "play";
			break;
		case "beauty": H(e, "beautyFirst", t, "", [], n);
	}
}
function je(e, t, n, r) {
	if (e.phase === "choosePrincess") {
		let r = n;
		e.chosen[t] = r, e.offers[t] && e.discarded.push(...e.offers[t].filter((e) => e !== r)), Object.keys(e.chosen).length === e.players.length && (e.roles = { ...e.chosen }, ae(e));
		return;
	}
	if (e.phase === "contribute" && e.pending?.power === "sleeping") {
		ke(e, t, n, r);
		return;
	}
	if (!e.pending && [
		"pass",
		"lock",
		"revealSuit",
		"hide",
		"draft",
		"bid",
		"discard",
		"contribute"
	].includes(e.phase)) {
		ke(e, t, n, r);
		return;
	}
	if (n.startsWith("power:")) {
		let [, r, i] = n.split(":");
		Ae(e, t, r, i ?? "");
		return;
	}
	if (e.phase === "before") {
		e.passes++, e.preAt = (e.preAt + 1) % e.players.length, e.passes >= e.players.length && se(e);
		return;
	}
	if (e.phase === "play") {
		let [, r, i, a] = n.split(":");
		he(e, t, Number(r), i ?? null, a ?? "");
		return;
	}
	let i = e.pending;
	switch (i.kind) {
		case "iceTarget":
			H(e, "freeze", t, n, z(e, q(e, n)).slice(0, 2), "ice");
			break;
		case "freeze":
			e.frozen[i.target] = r[0], x(r[0]) === 1 && (e.broken = !0), W(e, t);
			break;
		case "mermaid": {
			let r = Number(n);
			if (!e.hands[e.leader].some((e) => x(e) === r)) {
				i.index |= 1 << r;
				break;
			}
			e.forcedSuit = r, e.mermaid = !0, W(e, t);
			break;
		}
		case "leader":
			e.leader = n, e.forcedLeader = n, e.order = Array.from({ length: e.players.length }, (t, r) => L(e, n, r)), W(e, t);
			break;
		case "barterTarget": {
			let r = z(e, q(e, n))[0];
			H(e, "barter", t, n, [r], "scheherazade");
			break;
		}
		case "barter":
			if (n !== "return") {
				let r = Number(n);
				B(e, t, [r]), B(e, i.target, i.cards), V(e, t, i.cards), V(e, i.target, [r]);
			}
			W(e, t);
			break;
		case "distribute": {
			let n = e.players[i.index];
			V(e, n, r), i.cards = i.cards.filter((e) => e !== r[0]), i.index++, i.index === e.players.length && W(e, t);
			break;
		}
		case "mulan":
			e.mulanPassed.push(t), _e(e);
			break;
		case "mulanCard": {
			if (!i.cards.length) {
				i.cards = [Number(n)];
				break;
			}
			let a = i.cards[0], o = r[0], s = e.trick.find((e) => e.card === a);
			B(e, t, [o]), V(e, t, [a]), e.mulanSwapped.push(s.original), s.card = o, s.zero = !1, _e(e);
			break;
		}
		case "alice":
			be(e);
			break;
		case "haggle":
			n === "skip" ? (e.phase = "collect", e.pending = null, e.beat = P.collect) : H(e, "haggleCard", t, "", [Number(n)]);
			break;
		case "haggleCard": {
			let r = Number(n), a = i.cards[0], o = e.trick.find((e) => e.card === r);
			B(e, t, [a]), V(e, t, [r]), o.card = a, o.zero = !1, e.phase = "collect", e.pending = null, e.beat = P.collect;
			break;
		}
		case "redAsk": {
			let r = Number(n), i = e.players.find((n) => n !== t && e.hands[n].includes(r) && e.frozen[n] !== r);
			i ? H(e, "redGive", t, i, [r], "red") : (e.phase = "play", e.pending = null);
			break;
		}
		case "redGive":
			B(e, t, r), B(e, i.target, i.cards), V(e, t, i.cards), V(e, i.target, r), e.phase = "play", e.pending = null;
			break;
		case "afterPlay":
			ge(e);
			break;
		case "beautyFirst":
			H(e, "beautySecond", t, "", r, "beauty");
			break;
		case "beautySecond": {
			let t = i.cards[0], n = r[0];
			e.trick.forEach((e) => {
				e.card === t ? e.card = n : e.card === n && (e.card = t);
			}), e.trick.forEach((t) => {
				t.zero = e.zeroCards.includes(t.card);
			}), e.players.forEach((r) => {
				e.won[r] = e.won[r].map((e) => e === t ? n : e === n ? t : e);
			}), e.visibleWon = e.visibleWon.map((e) => e === t ? n : e === n ? t : e), ge(e);
			break;
		}
	}
}
function Me(t, n, r) {
	let i = [...n], a = {
		players: i,
		seed: r,
		cursor: 0,
		config: O.parse(t),
		phase: "choosePrincess",
		round: 1,
		rounds: [],
		leader: "",
		roundLeader: "",
		hands: F(i),
		stash: F(i),
		locked: F(i),
		offers: {},
		roles: {},
		chosen: {},
		discarded: [],
		used: {},
		blocked: [],
		submissions: {},
		open: [],
		won: F(i),
		visibleWon: [],
		tricks: I(i),
		scores: I(i),
		rows: [],
		bids: {},
		trick: [],
		gifts: [],
		broken: !1,
		order: [],
		at: 0,
		preAt: 0,
		passes: 0,
		reverse: !1,
		pea: null,
		forcedSuit: null,
		mermaid: !1,
		frozen: {},
		effects: [],
		pending: null,
		winner: null,
		beat: 0,
		limit: 0,
		thresholdWinner: null,
		sum: 0,
		swan: null,
		forcedLeader: null,
		received: F(i),
		step: 0,
		led: null,
		mulanPassed: [],
		mulanSwapped: [],
		trickPowers: {},
		zeroCards: [],
		revealed: !1
	}, o = z(a, [
		...g,
		...a.config.expansion ? ["red", "swan"] : [],
		...a.config.promos ? ["beauty", "carmesina"] : []
	]);
	i.slice(0, i.length === 6 ? 5 : i.length).forEach((e, t) => {
		a.offers[e] = o.slice(t * 2, t * 2 + 2);
	});
	let s = v.filter((e) => a.config.expansion || e.length === 1), c = z(a, s.filter((e) => !b.includes(e))), l = z(a, s.filter((e) => b.includes(e))), u = a.config.roundIds.filter((e) => s.includes(e));
	return a.rounds = u.length === a.config.rounds && new Set(u).size === u.length ? u : a.config.random ? [...c.slice(0, a.config.rounds - 1), l[0]] : a.config.rounds === 3 ? [
		"a",
		"b",
		"e"
	] : [
		"a",
		"b",
		"c",
		"d",
		"e"
	], a.leader = i[(e(r, a.cursor++, i.length) + 1) % i.length], a.roundLeader = a.leader, {
		state: a,
		fx: []
	};
}
function Ne(e, t, n) {
	let r = [];
	if (t.trick.length > e.trick.length) {
		let e = t.trick.length - 1, i = t.trick[e], a = R(t), o = a === "i" && e > 0 || a === "zeta" && e === 0;
		r.push({
			kind: "rpPlay",
			rid: n,
			data: {
				slot: e,
				card: o ? null : i.card
			},
			for: [n],
			secret: { card: i.card }
		});
	}
	if (!e.revealed && t.revealed && r.push({
		kind: "rpReveal",
		data: { cards: t.trick.map((e, n) => ({
			card: e.card,
			zero: e.zero,
			concealed: R(t) === "i" && n > 0 || R(t) === "zeta" && n === 0
		})) }
	}), t.phase === "collect" && e.phase !== "collect" && r.push({
		kind: "rpCollect",
		rid: t.winner,
		data: { cards: t.trick.map((e) => e.card) }
	}), t.phase === "score" && e.phase !== "score" && r.push({
		kind: "rpScore",
		data: { scores: t.rows.at(-1).scores }
	}), t.trick.length === e.trick.length) for (let n of t.players) {
		let i = t.hands[n].filter((t) => !e.hands[n].includes(t)), a = /* @__PURE__ */ new Map();
		for (let t of i) {
			let n = e.players.find((n) => e.hands[n].includes(t)) ?? "table";
			a.set(n, [...a.get(n) ?? [], t]);
		}
		for (let [e, t] of a) e !== n && r.push({
			kind: "rpTransfer",
			rid: n,
			data: {
				from: e,
				count: t.length
			},
			for: [n],
			secret: { cards: t },
			with: r.length > 0
		});
	}
	return r;
}
function Pe(e, t, n) {
	if (t.type === "tick") {
		if (![
			"reveal",
			"collect",
			"score",
			"roundEnd"
		].includes(e.phase)) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return t.phase === "reveal" ? t.revealed ? _e(t) : t.revealed = !0 : t.phase === "collect" ? xe(t) : t.phase === "score" ? (t.phase = "roundEnd", t.beat = P.deal) : Te(t), {
			state: t,
			fx: Ne(e, t, n.by)
		};
	}
	let r = Oe(e, n.by);
	if (!r || !r.options.some((e) => e.id === t.id) || t.cards.length !== r.count || new Set(t.cards).size !== t.cards.length || t.cards.some((e) => !r.cards.includes(e))) return { code: "games.rebelprincess.invalid" };
	let i = structuredClone(e);
	return je(i, n.by, t.id, t.cards), {
		state: i,
		fx: Ne(e, i, n.by)
	};
}
function Fe(e, t) {
	let n = R(e), r = (t) => !e.revealed && (n === "i" && t > 0 || n === "zeta" && t === 0), i = {
		phase: e.phase,
		round: e.round,
		totalRounds: e.rounds.length,
		roundId: e.phase === "choosePrincess" ? "" : n,
		revealedRounds: e.phase === "choosePrincess" ? [] : e.rounds.slice(0, e.round),
		leader: e.leader,
		turn: Ee(e),
		broken: e.broken,
		limit: e.limit,
		trick: e.trick.map((e, t) => ({
			rid: e.rid,
			card: r(t) ? null : e.card,
			suit: r(t) && n === "i" ? null : x(e.card),
			zero: e.zero
		})),
		players: e.players.map((t) => ({
			rid: t,
			princess: e.phase === "choosePrincess" ? null : e.roles[t],
			used: e.used[t] ?? !1,
			count: e.hands[t].length + e.locked[t].length + e.stash[t].length,
			ready: t in e.submissions || t in e.chosen && e.phase === "choosePrincess",
			score: e.scores[t],
			tricks: e.tricks[t],
			open: e.hands[t].filter((t) => e.open.includes(t))
		})),
		rows: e.rows,
		winner: e.winner,
		effects: e.effects
	}, a = Oe(e, t);
	return {
		public: i,
		private: {
			hand: e.hands[t] ?? [],
			selected: e.submissions[t] ?? [],
			princesses: e.phase === "choosePrincess" ? a?.options.flatMap((e) => e.princess ? [e.princess] : []) ?? [] : [],
			request: a,
			received: e.pending?.actor === t && e.pending.kind === "barter" ? e.pending.cards : e.received[t] ?? [],
			sources: e.pending?.actor === t ? e.pending.sources ?? [] : []
		}
	};
}
var Ie = {
	meta: E,
	saveCompatibility: { version: "1" },
	schemas: {
		action: k,
		publicView: M,
		privateView: N,
		config: O
	},
	setup: Me,
	reduce: Pe,
	viewFor: Fe,
	nextTickIn: (e) => [
		"reveal",
		"collect",
		"score",
		"roundEnd"
	].includes(e.phase) ? e.beat : null,
	status: (e) => e.phase === "done" ? {
		phase: "done",
		winner: [we(e)[0]],
		ranking: we(e),
		scores: { ...e.scores }
	} : { phase: e.phase }
}, Le = [
	"queens",
	"princes",
	"fairies",
	"pets"
], Re = [
	"#ae7630",
	"#42585c",
	"#a48c28",
	"#657d3b"
];
function ze({ suit: e }) {
	return /* @__PURE__ */ s("img", {
		className: "rp-suit-icon",
		src: `games/rebelprincess/icon-${Le[e]}.svg`,
		alt: ""
	});
}
function Q({ card: e, zero: t = !1, style: n }) {
	let i = r();
	if (e === null) return /* @__PURE__ */ s("div", {
		className: "rp-card rp-back",
		style: n,
		"aria-label": i("games.rebelprincess.hidden"),
		children: /* @__PURE__ */ c("svg", {
			viewBox: "0 0 100 150",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ s("path", {
				d: "M18 120C84 121 20 29 82 30M82 120C16 121 80 29 18 30",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2"
			}), /* @__PURE__ */ s("path", {
				d: "m50 35 5 14 15 1-12 9 4 15-12-9-12 9 4-15-12-9 15-1zM50 108l-9 9 9 9 9-9z",
				fill: "currentColor"
			})]
		})
	});
	let a = x(e), o = C(e) ? "frog" : Le[a];
	return /* @__PURE__ */ c("div", {
		className: "rp-card",
		style: {
			"--rp-suit": Re[a],
			...n
		},
		"aria-label": `${i(ee[a])} ${S(e)}`,
		children: [
			/* @__PURE__ */ c("div", {
				className: "rp-corner",
				children: [/* @__PURE__ */ s("b", { children: t ? 0 : S(e) }), /* @__PURE__ */ s(ze, { suit: a })]
			}),
			/* @__PURE__ */ s("img", {
				className: "rp-card-art",
				src: `games/rebelprincess/suit-${o}.svg`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ c("div", {
				className: "rp-corner rp-corner-end",
				children: [/* @__PURE__ */ s("b", { children: t ? 0 : S(e) }), /* @__PURE__ */ s(ze, { suit: a })]
			}),
			(a === 1 || C(e)) && /* @__PURE__ */ s("span", {
				className: "rp-proposal",
				children: C(e) ? "5" : "1"
			})
		]
	});
}
//#endregion
//#region src/games/rebelprincess/text-keys.ts
var Be = {
	choosePrincess: "games.rebelprincess.titles.choosePrincess",
	pass: "games.rebelprincess.titles.pass",
	lock: "games.rebelprincess.titles.lock",
	revealSuit: "games.rebelprincess.titles.revealSuit",
	hide: "games.rebelprincess.titles.hide",
	draft: "games.rebelprincess.titles.draft",
	bid: "games.rebelprincess.titles.bid",
	discard: "games.rebelprincess.titles.discard",
	before: "games.rebelprincess.titles.before",
	play: "games.rebelprincess.titles.play",
	iceTarget: "games.rebelprincess.titles.iceTarget",
	freeze: "games.rebelprincess.titles.freeze",
	mermaid: "games.rebelprincess.titles.mermaid",
	mermaidRetry: "games.rebelprincess.titles.mermaidRetry",
	leader: "games.rebelprincess.titles.leader",
	barterTarget: "games.rebelprincess.titles.barterTarget",
	barter: "games.rebelprincess.titles.barter",
	contribute: "games.rebelprincess.titles.contribute",
	distribute: "games.rebelprincess.titles.distribute",
	mulan: "games.rebelprincess.titles.mulan",
	mulanCard: "games.rebelprincess.titles.mulanCard",
	alice: "games.rebelprincess.titles.alice",
	haggle: "games.rebelprincess.titles.haggle",
	haggleCard: "games.rebelprincess.titles.haggleCard",
	redAsk: "games.rebelprincess.titles.redAsk",
	redGive: "games.rebelprincess.titles.redGive",
	beautyFirst: "games.rebelprincess.titles.beautyFirst",
	beautySecond: "games.rebelprincess.titles.beautySecond",
	afterPlay: "games.rebelprincess.titles.afterPlay",
	wait: "games.rebelprincess.titles.wait",
	reveal: "games.rebelprincess.titles.reveal",
	collect: "games.rebelprincess.titles.collect",
	score: "games.rebelprincess.titles.score",
	roundEnd: "games.rebelprincess.titles.roundEnd",
	done: "games.rebelprincess.titles.done"
}, Ve = {
	confirm: "games.rebelprincess.labels.confirm",
	skip: "games.rebelprincess.labels.skip",
	power: "games.rebelprincess.labels.power",
	play: "games.rebelprincess.labels.play",
	zero: "games.rebelprincess.labels.zero",
	ignore: "games.rebelprincess.labels.ignore",
	return: "games.rebelprincess.labels.return",
	princess: "games.rebelprincess.labels.princess",
	target: "games.rebelprincess.labels.target",
	suit: "games.rebelprincess.labels.suit",
	swap: "games.rebelprincess.labels.swap",
	keep: "games.rebelprincess.labels.keep"
}, He = {
	a: "games.rebelprincess.roundNames.a",
	b: "games.rebelprincess.roundNames.b",
	c: "games.rebelprincess.roundNames.c",
	d: "games.rebelprincess.roundNames.d",
	e: "games.rebelprincess.roundNames.e",
	f: "games.rebelprincess.roundNames.f",
	g: "games.rebelprincess.roundNames.g",
	h: "games.rebelprincess.roundNames.h",
	i: "games.rebelprincess.roundNames.i",
	j: "games.rebelprincess.roundNames.j",
	k: "games.rebelprincess.roundNames.k",
	l: "games.rebelprincess.roundNames.l",
	m: "games.rebelprincess.roundNames.m",
	n: "games.rebelprincess.roundNames.n",
	o: "games.rebelprincess.roundNames.o",
	p: "games.rebelprincess.roundNames.p",
	q: "games.rebelprincess.roundNames.q",
	r: "games.rebelprincess.roundNames.r",
	s: "games.rebelprincess.roundNames.s",
	t: "games.rebelprincess.roundNames.t",
	u: "games.rebelprincess.roundNames.u",
	v: "games.rebelprincess.roundNames.v",
	w: "games.rebelprincess.roundNames.w",
	x: "games.rebelprincess.roundNames.x",
	y: "games.rebelprincess.roundNames.y",
	z: "games.rebelprincess.roundNames.z",
	alpha: "games.rebelprincess.roundNames.alpha",
	beta: "games.rebelprincess.roundNames.beta",
	gamma: "games.rebelprincess.roundNames.gamma",
	delta: "games.rebelprincess.roundNames.delta",
	epsilon: "games.rebelprincess.roundNames.epsilon",
	zeta: "games.rebelprincess.roundNames.zeta"
}, Ue = {
	a: "games.rebelprincess.roundRules.a",
	b: "games.rebelprincess.roundRules.b",
	c: "games.rebelprincess.roundRules.c",
	d: "games.rebelprincess.roundRules.d",
	e: "games.rebelprincess.roundRules.e",
	f: "games.rebelprincess.roundRules.f",
	g: "games.rebelprincess.roundRules.g",
	h: "games.rebelprincess.roundRules.h",
	i: "games.rebelprincess.roundRules.i",
	j: "games.rebelprincess.roundRules.j",
	k: "games.rebelprincess.roundRules.k",
	l: "games.rebelprincess.roundRules.l",
	m: "games.rebelprincess.roundRules.m",
	n: "games.rebelprincess.roundRules.n",
	o: "games.rebelprincess.roundRules.o",
	p: "games.rebelprincess.roundRules.p",
	q: "games.rebelprincess.roundRules.q",
	r: "games.rebelprincess.roundRules.r",
	s: "games.rebelprincess.roundRules.s",
	t: "games.rebelprincess.roundRules.t",
	u: "games.rebelprincess.roundRules.u",
	v: "games.rebelprincess.roundRules.v",
	w: "games.rebelprincess.roundRules.w",
	x: "games.rebelprincess.roundRules.x",
	y: "games.rebelprincess.roundRules.y",
	z: "games.rebelprincess.roundRules.z",
	alpha: "games.rebelprincess.roundRules.alpha",
	beta: "games.rebelprincess.roundRules.beta",
	gamma: "games.rebelprincess.roundRules.gamma",
	delta: "games.rebelprincess.roundRules.delta",
	epsilon: "games.rebelprincess.roundRules.epsilon",
	zeta: "games.rebelprincess.roundRules.zeta"
}, We = {
	alice: "games.rebelprincess.power.alice",
	cinderella: "games.rebelprincess.power.cinderella",
	ice: "games.rebelprincess.power.ice",
	mermaid: "games.rebelprincess.power.mermaid",
	mulan: "games.rebelprincess.power.mulan",
	pea: "games.rebelprincess.power.pea",
	pocahontas: "games.rebelprincess.power.pocahontas",
	scheherazade: "games.rebelprincess.power.scheherazade",
	sleeping: "games.rebelprincess.power.sleeping",
	snow: "games.rebelprincess.power.snow",
	rapunzel: "games.rebelprincess.power.rapunzel",
	thumbelina: "games.rebelprincess.power.thumbelina",
	red: "games.rebelprincess.power.red",
	swan: "games.rebelprincess.power.swan",
	beauty: "games.rebelprincess.power.beauty",
	carmesina: "games.rebelprincess.power.carmesina"
};
//#endregion
//#region src/games/rebelprincess/view-player.tsx
function Ge({ player: e, name: t, active: n, onClick: a }) {
	let o = r(), { ref: l } = i(`rp-seat:${e.rid}`);
	return /* @__PURE__ */ c("button", {
		ref: l,
		type: "button",
		className: `rp-seat${n ? " rp-seat-active" : ""}`,
		onClick: a,
		children: [
			e.princess && /* @__PURE__ */ s("img", {
				className: "rp-seat-art",
				src: `games/rebelprincess/princess-${e.princess}.svg`,
				alt: ""
			}),
			/* @__PURE__ */ c("span", {
				className: "rp-seat-info",
				children: [
					/* @__PURE__ */ s("strong", { children: t }),
					/* @__PURE__ */ c("span", { children: [
						e.score,
						" ",
						o("games.rebelprincess.proposals"),
						" · ",
						e.tricks,
						" ",
						o("games.rebelprincess.tricks")
					] }),
					/* @__PURE__ */ c("small", { children: [e.ready ? o("games.rebelprincess.ready") : e.princess ? o(T[e.princess]) : "—", e.used ? ` · ${o("games.rebelprincess.used")}` : ""] })
				]
			}),
			/* @__PURE__ */ s("span", {
				className: "rp-seat-count",
				children: e.count
			})
		]
	});
}
function Ke({ play: e, i: t, name: n }) {
	let { ref: r, hidden: a } = i(`rp-slot:${t}`);
	return /* @__PURE__ */ c("div", {
		className: "rp-trick-slot",
		children: [
			/* @__PURE__ */ s("div", {
				ref: r,
				style: { visibility: a ? "hidden" : void 0 },
				children: /* @__PURE__ */ s(Q, {
					card: e.card,
					zero: e.zero
				})
			}),
			/* @__PURE__ */ s("span", { children: n }),
			e.card === null && e.suit !== null && /* @__PURE__ */ s(ze, { suit: e.suit })
		]
	});
}
function qe({ card: e, selected: t, order: n, available: r, onClick: a, inHand: o = !1 }) {
	let { ref: l, hidden: u } = i(`${o ? "rp-held" : "rp-candidate"}:${e}`);
	return /* @__PURE__ */ c("button", {
		ref: l,
		style: { visibility: u ? "hidden" : void 0 },
		type: "button",
		disabled: !r,
		"aria-pressed": t,
		className: `rp-pick${r ? " rp-legal" : ""}${t ? " rp-selected" : ""}`,
		onClick: a,
		children: [
			/* @__PURE__ */ s(Q, { card: e }),
			n > 0 && /* @__PURE__ */ s("span", {
				className: "rp-selection-number",
				children: n
			}),
			/* @__PURE__ */ s("svg", {
				className: "rp-target-ring",
				viewBox: "0 0 100 150",
				preserveAspectRatio: "none",
				"aria-hidden": "true",
				children: /* @__PURE__ */ s("rect", {
					x: "2",
					y: "2",
					width: "96",
					height: "146",
					rx: "7"
				})
			})
		]
	});
}
function Je({ public: e, private: t, members: l, myRid: u, send: d }) {
	let f = e, p = t, m = r(), h = p?.request ?? null, g = JSON.stringify(h), [_, v] = n({
		key: "",
		cards: [],
		id: ""
	}), [x, S] = n(null), [C, w] = n(null), E = _.key === g ? _.cards : [], D = _.key === g ? _.id : "", O = (e) => l.find((t) => t.rid === e)?.name ?? e, k = f.players.find((e) => e.rid === u), A = f.roundId, { ref: te } = i("rp-hand"), { ref: ne } = i("rp-table"), j = (e) => v({
		key: g,
		id: e,
		cards: E
	}), re = (e) => v({
		key: g,
		id: D,
		cards: E.includes(e) ? E.filter((t) => t !== e) : h && E.length < h.count ? [...E, e] : h?.count === 1 ? [e] : E
	}), ie = () => {
		h && (d({
			type: "choose",
			id: D || h.options[0]?.id,
			cards: E
		}), v({
			key: "",
			id: "",
			cards: []
		}));
	}, M = !!h && h.count > 0 && h.cards.every((e) => p?.hand.includes(e)), N = !!h && h.count === 0 && [
		"play",
		"barter",
		"haggle"
	].includes(h.title), P = h?.options.find((e) => e.id === D), F = (e) => {
		if (M) re(e);
		else if (N) {
			let t = h.options.filter((t) => t.card === e);
			t.length && j(t[0].id);
		}
	}, I = (e) => e.princess ? m(T[e.princess]) : e.target ? O(e.target) : e.suit === null ? m(Ve[e.label]) : m(ee[e.suit]), L = !!h && h.count === 0 && h.options.length > 0 && h.options.every((e) => e.label === "power" || e.label === "skip"), R = h && h.count === 0 && h.title !== "play" && !L ? h.options.filter((e) => !(N && e.card !== null)) : [], z = L ? h.options : h?.title === "play" ? h.options.filter((e) => e.label === "power") : [], B = y[f.roundId] ?? [0, 0];
	return /* @__PURE__ */ c(a, {
		adaptive: !0,
		className: "rp-root",
		scroll: !1,
		banner: /* @__PURE__ */ c("header", {
			className: "rp-header",
			children: [/* @__PURE__ */ c("div", {
				className: "rp-heading",
				children: [/* @__PURE__ */ s("span", { children: "Rebel Princess" }), /* @__PURE__ */ s("strong", { children: f.phase === "choosePrincess" ? m("games.rebelprincess.neutralRound") : m("games.rebelprincess.round", { n: f.round }) })]
			}), /* @__PURE__ */ s("div", {
				className: "rp-seats",
				children: f.players.map((e) => /* @__PURE__ */ s(Ge, {
					player: e,
					name: O(e.rid),
					active: f.turn === e.rid,
					onClick: () => e.princess && S(e.princess)
				}, e.rid))
			})]
		}),
		actionsHeight: "rp-actions-height",
		actions: /* @__PURE__ */ c("div", {
			className: "rp-actions",
			children: [/* @__PURE__ */ s("span", { children: m(Be[h?.title ?? ([
				"reveal",
				"collect",
				"score",
				"roundEnd",
				"done"
			].includes(f.phase) ? f.phase : "wait")]) }), /* @__PURE__ */ c("div", {
				className: "rp-actions-controls",
				children: [
					h?.count ? /* @__PURE__ */ s("span", { children: m("games.rebelprincess.selected", {
						n: E.length,
						total: h.count
					}) }) : null,
					z.length > 0 && /* @__PURE__ */ s("div", {
						className: "rp-quick-powers",
						children: z.map((e) => /* @__PURE__ */ s("button", {
							type: "button",
							className: `rp-small${D === e.id ? " rp-on" : ""}`,
							onClick: () => j(e.id),
							"aria-pressed": D === e.id,
							children: I(e)
						}, e.id))
					}),
					N && P?.card !== null && D && h?.options.filter((e) => e.card === P?.card).map((e) => /* @__PURE__ */ s("button", {
						className: `rp-small${D === e.id ? " rp-on" : ""}`,
						onClick: () => j(e.id),
						children: m(Ve[e.label])
					}, e.id)),
					/* @__PURE__ */ s("button", {
						className: "rp-confirm",
						disabled: !h || (h.count > 0 ? E.length !== h.count : !D),
						onClick: ie,
						children: m("games.rebelprincess.labels.confirm")
					})
				]
			})]
		}),
		children: [
			/* @__PURE__ */ c("div", {
				className: `rp-play-layout${f.phase === "choosePrincess" ? " rp-choosing" : ""}`,
				children: [
					/* @__PURE__ */ c("button", {
						className: "rp-round-card",
						onClick: () => S("round"),
						disabled: !A,
						children: [
							/* @__PURE__ */ c("div", {
								className: "rp-round-heading",
								children: [
									/* @__PURE__ */ s("b", { children: A }),
									b.includes(A) && /* @__PURE__ */ s("span", {
										"aria-hidden": "true",
										children: "⌛"
									}),
									/* @__PURE__ */ s("span", { children: A ? m(He[A]) : "—" })
								]
							}),
							A && /* @__PURE__ */ s("img", {
								src: `games/rebelprincess/round-${A}.svg`,
								alt: ""
							}),
							/* @__PURE__ */ c("div", {
								className: "rp-pass-arrows",
								children: [B[0] > 0 && /* @__PURE__ */ c("span", { children: ["← ", B[0]] }), B[1] > 0 && /* @__PURE__ */ c("span", { children: [B[1], " →"] })]
							}),
							/* @__PURE__ */ s("p", { children: A ? m(Ue[A]) : "" })
						]
					}),
					/* @__PURE__ */ c("div", {
						className: "rp-table",
						ref: ne,
						children: [
							/* @__PURE__ */ c("div", {
								className: "rp-table-status",
								children: [/* @__PURE__ */ s("span", { children: m(f.broken ? "games.rebelprincess.broken" : "games.rebelprincess.unbroken") }), f.limit > 0 && /* @__PURE__ */ s("span", { children: m("games.rebelprincess.limit", { n: f.limit }) })]
							}),
							f.players.some((e) => e.open.length > 0) && /* @__PURE__ */ s("div", {
								className: "rp-open-hands",
								"aria-label": m("games.rebelprincess.openHand"),
								children: f.players.filter((e) => e.open.length > 0).map((e) => /* @__PURE__ */ c("button", {
									type: "button",
									className: "rp-small",
									onClick: () => w(e.rid),
									"aria-label": `${O(e.rid)} · ${m("games.rebelprincess.openHand")}`,
									children: [/* @__PURE__ */ s("strong", { children: O(e.rid) }), /* @__PURE__ */ s("span", { children: e.open.length })]
								}, e.rid))
							}),
							/* @__PURE__ */ c("div", {
								className: "rp-trick",
								children: [f.trick.map((e, t) => /* @__PURE__ */ s(Ke, {
									play: e,
									i: t,
									name: O(e.rid)
								}, `${t}:${e.rid}`)), f.trick.length === 0 && !h && /* @__PURE__ */ s("span", {
									className: "rp-wait",
									children: f.turn ? m("games.rebelprincess.waitName", { name: O(f.turn) }) : m("games.rebelprincess.titles.wait")
								})]
							}),
							f.effects.length > 0 && /* @__PURE__ */ s("div", {
								className: "rp-effects",
								children: f.effects.map((e, t) => /* @__PURE__ */ s("span", { children: m(T[e]) }, t))
							}),
							f.phase === "score" && f.rows.at(-1) && /* @__PURE__ */ s("div", {
								className: "rp-score-overlay",
								children: f.players.map((e) => /* @__PURE__ */ c("p", { children: [O(e.rid), /* @__PURE__ */ s("b", { children: f.rows.at(-1).scores[e.rid] })] }, e.rid))
							}),
							h && (!M && h.count > 0 || R.length > 0) && /* @__PURE__ */ c("div", {
								className: "rp-decision",
								"aria-label": m(Be[h.title]),
								children: [
									h.title === "barter" && p?.received[0] !== void 0 && /* @__PURE__ */ s("div", {
										className: "rp-inspected",
										children: /* @__PURE__ */ s(Q, { card: p.received[0] })
									}),
									!M && h.count > 0 && /* @__PURE__ */ s("div", {
										className: "rp-candidates",
										children: h.cards.map((e) => /* @__PURE__ */ c("div", { children: [/* @__PURE__ */ s(qe, {
											card: e,
											selected: E.includes(e),
											order: E.indexOf(e) + 1,
											available: !0,
											onClick: () => re(e)
										}), p?.sources.find((t) => t.card === e) && /* @__PURE__ */ s("small", { children: O(p.sources.find((t) => t.card === e).rid) })] }, e))
									}),
									R.length > 0 && /* @__PURE__ */ s("div", {
										className: "rp-options",
										children: R.map((e) => /* @__PURE__ */ c("button", {
											type: "button",
											className: `rp-option${e.princess ? " rp-princess-option" : ""}${D === e.id ? " rp-on" : ""}`,
											onClick: () => j(e.id),
											"aria-pressed": D === e.id,
											children: [
												e.princess && /* @__PURE__ */ s("img", {
													src: `games/rebelprincess/princess-${e.princess}.svg`,
													alt: ""
												}),
												e.suit !== null && /* @__PURE__ */ s(ze, { suit: e.suit }),
												" ",
												e.card === null ? /* @__PURE__ */ s("span", { children: I(e) }) : /* @__PURE__ */ s(Q, { card: e.card }),
												e.princess && e.label === "power" && /* @__PURE__ */ s("small", { children: m("games.rebelprincess.labels.power") }),
												e.princess && h.title === "choosePrincess" && /* @__PURE__ */ s("small", {
													className: "rp-choose-power",
													children: m(We[e.princess])
												}),
												e.target && e.princess && /* @__PURE__ */ s("small", { children: O(e.target) })
											]
										}, e.id))
									}),
									h.title === "distribute" && h.options[0].target && /* @__PURE__ */ s("p", { children: m("games.rebelprincess.target", { name: O(h.options[0].target) }) })
								]
							})
						]
					}),
					/* @__PURE__ */ s("button", {
						className: `rp-personal${k?.used ? " rp-spent" : ""}`,
						onClick: () => k?.princess && S(k.princess),
						disabled: !k?.princess,
						children: k?.princess && /* @__PURE__ */ c(o, { children: [
							/* @__PURE__ */ s("img", {
								src: `games/rebelprincess/princess-${k.princess}.svg`,
								alt: ""
							}),
							/* @__PURE__ */ s("strong", { children: m(T[k.princess]) }),
							/* @__PURE__ */ s("p", { children: m(We[k.princess]) })
						] })
					}),
					/* @__PURE__ */ c("div", {
						className: "rp-hand-area",
						ref: te,
						children: [/* @__PURE__ */ c("div", {
							className: "rp-hand-label",
							children: [/* @__PURE__ */ s("span", { children: h?.title === "pass" && B.every((e) => e > 0) ? m("games.rebelprincess.leftFirst", {
								left: B[0],
								right: B[1]
							}) : m("games.rebelprincess.hand") }), p?.selected.length ? /* @__PURE__ */ s("span", { children: m("games.rebelprincess.ready") }) : null]
						}), /* @__PURE__ */ s("div", {
							className: "rp-hand",
							children: p?.hand.map((e) => /* @__PURE__ */ s(qe, {
								inHand: !0,
								card: e,
								selected: M ? E.includes(e) : P?.card === e,
								order: M ? E.indexOf(e) + 1 : 0,
								available: M ? h.cards.includes(e) : N && h.options.some((t) => t.card === e),
								onClick: () => F(e)
							}, e))
						})]
					})
				]
			}),
			x && /* @__PURE__ */ s("div", {
				className: "rp-detail-backdrop",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": m(x === "round" ? "games.rebelprincess.roundRule" : "games.rebelprincess.powerRule"),
				children: /* @__PURE__ */ c("div", {
					className: "rp-detail",
					children: [/* @__PURE__ */ s("button", {
						className: "rp-close",
						onClick: () => S(null),
						children: m("games.rebelprincess.close")
					}), x === "round" ? /* @__PURE__ */ c(o, { children: [/* @__PURE__ */ s("h2", { children: A ? m(He[A]) : "" }), /* @__PURE__ */ s("p", { children: A ? m(Ue[A]) : "" })] }) : /* @__PURE__ */ c(o, { children: [
						/* @__PURE__ */ s("img", {
							src: `games/rebelprincess/princess-${x}.svg`,
							alt: ""
						}),
						/* @__PURE__ */ s("h2", { children: m(T[x]) }),
						/* @__PURE__ */ s("p", { children: m(We[x]) })
					] })]
				})
			}),
			C && /* @__PURE__ */ s("div", {
				className: "rp-detail-backdrop",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": m("games.rebelprincess.openHand"),
				children: /* @__PURE__ */ c("div", {
					className: "rp-detail",
					children: [
						/* @__PURE__ */ s("button", {
							className: "rp-close",
							onClick: () => w(null),
							children: m("games.rebelprincess.close")
						}),
						/* @__PURE__ */ c("h2", { children: [
							O(C),
							" · ",
							m("games.rebelprincess.openHand")
						] }),
						/* @__PURE__ */ s("div", {
							className: "rp-public-cards",
							children: f.players.find((e) => e.rid === C)?.open.map((e) => /* @__PURE__ */ s(Q, { card: e }, e))
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/rebelprincess/bot.ts
var Ye = {
	risk: .5,
	shed: .5,
	power: 2
};
function $(e, t) {
	let n = +(x(e) === 1) + (C(e) ? 5 : 0);
	return t === "j" && x(e) === 3 && n++, t === "d" && S(e) === 3 && (n -= 3), t === "t" && x(e) === 2 && n--, t === "delta" && x(e) === 1 && (n -= 2), t === "y" && x(e) === 1 && n++, n;
}
function Xe(e = Ye) {
	return ({ public: t, private: n }, r) => {
		let i = n?.request;
		if (!i) return null;
		let a = r.difficulty === "weak", o = t.roundId, s = n.hand, c = (t) => $(t, o) * e.shed + S(t) / 12, l = i.options[0], u = [];
		if (i.count) {
			let e = [
				"pass",
				"discard",
				"contribute",
				"hide"
			].includes(i.title), t = i.options[0].target;
			u = [...i.cards].sort((n, o) => a ? n - o : (c(n) - c(o)) * (e || i.title === "distribute" && t !== r.rid ? -1 : 1)).slice(0, i.count);
		} else if (!a) {
			let n = (n) => {
				if (n.label === "princess") return {
					thumbelina: 5,
					snow: 4,
					mulan: 3,
					cinderella: 2
				}[n.princess] ?? 1;
				if (n.id.startsWith("play:") && n.card !== null) {
					let r = n.card, i = n.princess === "snow" ? 0 : S(r), a = x(r), s = t.trick[0]?.suit, l = t.trick.filter((e) => e.card !== null && (e.suit === s || o === "v" && e.suit === 2)).map((e) => e.zero ? 0 : S(e.card)), u = t.effects.includes("cinderella") !== (o === "x" && t.trick.filter((e) => e.card !== null && S(e.card) === 6).length % 2 == 1), d = l.length ? u ? Math.min(...l) : Math.max(...l) : null, f = s === void 0 ? i / 13 : a === s || o === "v" && a === 2 ? +(d === null || (u ? i < d : i > d)) : 0;
					o === "f" && a === 0 && (f = 1), o === "w" && (f = i / 13);
					let p = t.trick.reduce((e, t) => e + (t.card === null ? 0 : $(t.card, o)), 0) + $(r, o);
					return c(r) * e.shed - f * (Math.max(0, p) + i / 12 + 1) * e.risk - (n.princess ? .15 : 0);
				}
				if (n.label === "power") {
					let r = s.length <= 4;
					return n.princess === "mulan" ? 2 * e.power : n.princess === "alice" ? t.trick.reduce((e, t) => e + (t.card === null ? 0 : $(t.card, o)), 0) * e.power : n.princess === "cinderella" && s.some((e) => S(e) >= 9) ? 1.2 * e.power : n.princess === "red" || n.princess === "beauty" || n.princess === "swan" ? r ? .7 * e.power : -.2 : r ? .4 * e.power : -.3;
				}
				return n.card === null ? n.target ? n.target === r.rid ? .1 : 0 : n.id === "skip" ? 0 : -.1 : i.title === "redAsk" ? -c(n.card) : i.title === "haggle" ? c(n.card) : i.title === "haggleCard" || i.title === "mulanCard" ? -c(n.card) : 0;
			};
			l = [...i.options].sort((e, t) => n(t) - n(e))[0];
		}
		return { action: {
			type: "choose",
			id: l.id,
			cards: u
		} };
	};
}
var Ze = Xe(), Qe = {
	rpPlay(e, t) {
		let n = e.data, r = e.secret, i = t.anchor(e.rid === t.myRid ? "rp-hand" : `rp-seat:${e.rid}`), a = t.anchor(`rp-slot:${n.slot}`);
		return !i || !a ? null : {
			ms: 350,
			node: /* @__PURE__ */ s(u, {
				from: i,
				to: a,
				ms: 350,
				children: /* @__PURE__ */ s("div", {
					style: { width: a.w },
					children: /* @__PURE__ */ s(Q, { card: r?.card ?? n.card })
				})
			}),
			hide: t.queued ? [] : [`rp-slot:${n.slot}`]
		};
	},
	rpReveal(e, t) {
		let n = e.data.cards, r = n.flatMap((e, t) => e.concealed ? [t] : []);
		if (!r.length) {
			let e = t.anchor("rp-table");
			return e ? {
				ms: P.reveal,
				node: /* @__PURE__ */ s(d, {
					at: e,
					ms: P.reveal
				})
			} : null;
		}
		return {
			ms: P.reveal,
			node: r.map((e) => {
				let r = t.anchor(`rp-slot:${e}`);
				return r ? /* @__PURE__ */ s("div", {
					className: "rp-flip-card",
					style: {
						left: r.x,
						top: r.y,
						width: r.w,
						height: r.h
					},
					children: /* @__PURE__ */ c("div", {
						className: "rp-flip-inner",
						children: [/* @__PURE__ */ s("div", {
							className: "rp-flip-front",
							children: /* @__PURE__ */ s(Q, {
								card: n[e].card,
								zero: n[e].zero
							})
						}), /* @__PURE__ */ s("div", {
							className: "rp-flip-back",
							children: /* @__PURE__ */ s(Q, { card: null })
						})]
					})
				}, e) : null;
			}),
			hide: t.queued ? [] : r.map((e) => `rp-slot:${e}`)
		};
	},
	rpCollect(e, t) {
		let n = e.data.cards, r = t.anchor(`rp-seat:${e.rid}`);
		return r ? {
			ms: P.collect,
			node: n.map((e, n) => {
				let i = t.anchor(`rp-slot:${n}`);
				return i ? /* @__PURE__ */ s(u, {
					from: i,
					to: {
						...r,
						w: Math.min(r.w, 60),
						h: 90
					},
					ms: P.collect - 150,
					delay: n * 10,
					children: /* @__PURE__ */ s("div", {
						style: { width: i.w },
						children: /* @__PURE__ */ s(Q, { card: e })
					})
				}, n) : null;
			}),
			hide: t.queued ? [] : n.map((e, t) => `rp-slot:${t}`)
		} : null;
	},
	rpTransfer(e, t) {
		let { from: n, count: r } = e.data, i = t.anchor(n === "table" ? "rp-table" : n === t.myRid ? "rp-hand" : `rp-seat:${n}`), a = t.anchor(e.rid === t.myRid ? "rp-hand" : `rp-seat:${e.rid}`);
		if (!i || !a) return null;
		let o = e.secret?.cards;
		if (e.rid === t.myRid && o) {
			let e = o.map((e) => ({
				card: e,
				at: t.anchor(`rp-held:${e}`)
			})).filter((e) => e.at !== null);
			return {
				ms: 450,
				node: e.map(({ card: e, at: t }, n) => /* @__PURE__ */ s(u, {
					from: i,
					to: t,
					ms: 360,
					delay: Math.min(n * 12, 75),
					children: /* @__PURE__ */ s("div", {
						style: { width: t.w },
						children: /* @__PURE__ */ s(Q, { card: e })
					})
				}, e)),
				hide: t.queued ? [] : e.map(({ card: e }) => `rp-held:${e}`)
			};
		}
		return {
			ms: 450,
			node: Array.from({ length: Math.min(r, 4) }, (e, t) => /* @__PURE__ */ s(u, {
				from: i,
				to: {
					...a,
					w: 48,
					h: 72
				},
				ms: 360,
				delay: t * 25,
				children: /* @__PURE__ */ s("div", {
					style: { width: 48 },
					children: /* @__PURE__ */ s(Q, { card: null })
				})
			}, t))
		};
	},
	rpScore(e, t) {
		let { scores: n } = e.data;
		return {
			ms: P.score,
			node: Object.entries(n).map(([e, n]) => {
				let r = t.anchor(`rp-seat:${e}`);
				return r ? /* @__PURE__ */ s(l, {
					at: r,
					ms: P.score,
					children: /* @__PURE__ */ c("strong", {
						className: "rp-score-float",
						children: [n > 0 ? "+" : "", n]
					})
				}, e) : null;
			})
		};
	}
};
//#endregion
//#region src/games/rebelprincess/game-over.tsx
function $e({ public: e, result: t, members: n, hintCount: i, onPlayAgain: a, onBackToLobby: o }) {
	let l = e, u = r(), d = (e) => n.find((t) => t.rid === e)?.name ?? e;
	return /* @__PURE__ */ c("div", {
		className: "rp-root rp-end",
		children: [
			/* @__PURE__ */ c("header", {
				className: "rp-end-heading",
				children: [
					/* @__PURE__ */ s("span", { children: "Rebel Princess" }),
					/* @__PURE__ */ s("h1", { children: u("games.rebelprincess.champion") }),
					/* @__PURE__ */ s("p", { children: t.winner.map(d).join(" · ") }),
					/* @__PURE__ */ s("small", { children: u("games.rebelprincess.final") })
				]
			}),
			/* @__PURE__ */ c("div", {
				className: "rp-end-scroll",
				children: [
					/* @__PURE__ */ s("div", {
						className: "rp-final-portraits",
						children: t.ranking.map((e) => {
							let n = l.players.find((t) => t.rid === e)?.princess;
							return /* @__PURE__ */ c("div", {
								className: t.winner.includes(e) ? "rp-winner" : "",
								children: [
									n && /* @__PURE__ */ s("img", {
										src: `games/rebelprincess/princess-${n}.svg`,
										alt: ""
									}),
									/* @__PURE__ */ s("strong", { children: d(e) }),
									/* @__PURE__ */ s("span", { children: n ? u(T[n]) : "" }),
									/* @__PURE__ */ s("b", { children: t.scores?.[e] }),
									t.autopilot?.[e] !== void 0 && /* @__PURE__ */ s("small", { children: u("games.rebelprincess.autopilot", { n: Math.round(t.autopilot[e] * 100) }) })
								]
							}, e);
						})
					}),
					/* @__PURE__ */ s("div", {
						className: "rp-score-table-scroll",
						children: /* @__PURE__ */ c("table", {
							className: "rp-score-table",
							children: [
								/* @__PURE__ */ s("caption", { children: u("games.rebelprincess.scoreDetail") }),
								/* @__PURE__ */ s("thead", { children: /* @__PURE__ */ c("tr", { children: [/* @__PURE__ */ s("th", {}), t.ranking.map((e) => /* @__PURE__ */ s("th", { children: d(e) }, e))] }) }),
								/* @__PURE__ */ c("tbody", { children: [l.rows.map((e, n) => /* @__PURE__ */ c("tr", { children: [/* @__PURE__ */ c("th", { children: [
									n + 1,
									" · ",
									u(He[e.round])
								] }), t.ranking.map((t) => /* @__PURE__ */ c("td", { children: [e.scores[t], e.rebels.includes(t) && /* @__PURE__ */ s("span", {
									title: u("games.rebelprincess.rebel"),
									children: " ♕"
								})] }, t))] }, n)), /* @__PURE__ */ c("tr", {
									className: "rp-total",
									children: [/* @__PURE__ */ s("th", { children: u("games.rebelprincess.total") }), t.ranking.map((e) => /* @__PURE__ */ s("td", { children: t.scores?.[e] }, e))]
								})] })
							]
						})
					}),
					i !== void 0 && /* @__PURE__ */ s("p", {
						className: "rp-hint-count",
						children: u("games.rebelprincess.hintUsed", { n: i })
					})
				]
			}),
			/* @__PURE__ */ c("footer", {
				className: "rp-end-controls",
				children: [
					a && /* @__PURE__ */ s("button", {
						className: "rp-confirm",
						onClick: a,
						children: u("session.result.playAgain")
					}),
					o && /* @__PURE__ */ s(f, {
						label: u("session.result.backToLobby"),
						confirmLabel: u("session.result.backToLobby"),
						onConfirm: o,
						className: "rp-small"
					}),
					!a && !o && /* @__PURE__ */ s("p", { children: u("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/rebelprincess/options.tsx
function et({ value: e, onChange: t }) {
	let n = r(), i = O.safeParse(e), a = i.success ? i.data : O.parse(void 0);
	return /* @__PURE__ */ c("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ s(m, {
				title: n("games.rebelprincess.rounds"),
				columns: 2,
				children: [3, 5].map((e) => /* @__PURE__ */ s(p, {
					name: "rp-rounds",
					value: String(e),
					checked: a.rounds === e,
					label: n(e === 3 ? "games.rebelprincess.three" : "games.rebelprincess.five"),
					accent: E.accent,
					onChange: () => t({
						...a,
						rounds: e,
						roundIds: []
					})
				}, e))
			}),
			/* @__PURE__ */ s(m, {
				title: n("games.rebelprincess.roundMode"),
				columns: 2,
				children: [!1, !0].map((e) => /* @__PURE__ */ s(p, {
					name: "rp-mode",
					value: String(e),
					checked: a.random === e,
					label: n(e ? "games.rebelprincess.random" : "games.rebelprincess.recommended"),
					accent: E.accent,
					onChange: () => t({
						...a,
						random: e,
						roundIds: []
					})
				}, String(e)))
			}),
			/* @__PURE__ */ s(h, {
				label: n("games.rebelprincess.expansion"),
				checked: a.expansion,
				accent: E.accent,
				onChange: () => t({
					...a,
					expansion: !a.expansion
				})
			}),
			/* @__PURE__ */ s(h, {
				label: n("games.rebelprincess.promos"),
				checked: a.promos,
				accent: E.accent,
				onChange: () => t({
					...a,
					promos: !a.promos
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/rebelprincess/entry.tsx
var tt = {
	definition: Ie,
	View: Je,
	bot: Ze,
	fx: Qe,
	OverView: $e,
	Options: et,
	locales: {
		zh: {
			name: "叛逆公主：豪华版",
			desc: "公主们不想结婚：躲开王子与青蛙，在不断变化的舞会规则中争取最少求婚。",
			invalid: "此动作当前不可用，请重新选择。",
			round: "第{{n}}轮",
			proposals: "求婚",
			tricks: "赢墩",
			hand: "手牌",
			openHand: "公开手牌",
			selected: "已选{{n}}张／{{total}}张",
			used: "能力已用",
			ready: "已提交",
			leader: "领出",
			broken: "王子已混入",
			unbroken: "王子尚未混入",
			limit: "越界阈值：{{n}}",
			received: "收到的牌",
			target: "交给：{{name}}",
			roundRule: "本轮规则",
			powerRule: "公主能力",
			close: "关闭",
			total: "总计",
			rebel: "舞会叛逆者",
			champion: "自由的公主",
			final: "求婚最少者获胜",
			rounds: "游戏轮数",
			three: "3轮",
			five: "5轮",
			roundMode: "轮次牌",
			recommended: "推荐顺序",
			random: "随机轮次",
			expansion: "Happily Never After 扩展",
			promos: "贝儿与卡尔梅西娜宣传牌",
			on: "启用",
			off: "关闭",
			hidden: "暗牌",
			scoreDetail: "各轮求婚",
			neutralRound: "选择公主后开始舞会",
			waitName: "等待{{name}}",
			leftFirst: "先选传左的{{left}}张，再选传右的{{right}}张。",
			hintUsed: "本局求助{{n}}次",
			autopilot: "托管{{n}}%",
			rules: "目标:\n游戏进行 3 轮或 5 轮舞会，获得求婚次数最少的玩家获胜。每张王子牌计为 1 次求婚；宠物花色的 8 号牌代表青蛙，计为 5 次求婚。\n· 舞会叛逆者：赢得全部王子和青蛙时，本轮计为 −10 次求婚；结婚礼物轮不适用此规则。\n准备:\n3人移除每色的1、11、12；4至5人移除11、12；6人使用全部48张牌。洗牌均分。每人从两位公主中选一位，能力每轮一次；6人时第六位从前五人的弃选公主中选择。可选扩展与宣传牌须在开局启用，默认为关闭。\n流程:\n每轮揭示一张轮次牌，其规则优先于通常规则。按牌面箭头同时传牌，所有人提交前不能查看收到的牌。双向传牌先选传左的牌，再选传右的牌。默认推荐顺序为a、b、c、d、e；短局为a、b、e。随机选择时，黑沙漏牌仅放在最后一轮。\n每墩领出者出一张牌，其他人顺时针跟出领出牌的花色；没有该花色时可出任意牌。领出花色中点数最高的玩家赢得本墩，收取卡牌后领出下一墩。赢牌在轮末前不得随意翻看。王子尚未混入时，不能领出王子牌，除非手中只有王子；无法跟出领出花色的玩家打出王子牌后，王子才混入。青蛙不算王子，长发公主的强制领出与女巫换入王子都不使王子混入。\n公主能力:\n在各能力要求的时机使用。墩前从领出者左边开始依次询问，能力声明后重新给其他人使用机会，所有人连续放弃后开始出牌。不能用能力撤销已生效的能力。点击自己的公主可查看完整说明；轮次牌说明列明特殊规则。\n· 睡美人：查看贡献牌来源并逐一分配。\n· 冰雪公主与山鲁佐德：只随机抽取隐藏的当前手牌。\n暂存牌与留出的末墩牌受相应轮次保护。\n· 贝儿：只能选择已经公开或本人知道的已出牌，不揭示其他人的暗牌。\n交换不改变原领色与原领牌；若交换后没有合格的领色牌，由原领出者赢墩，特殊轮次的明确判定优先。\n结算:\n按本轮规则计算求婚，每轮恢复能力并重新洗牌发牌。下一轮由累计求婚最少者领出；求婚次数相同时，从上轮起始玩家的左侧开始，按顺时针顺序确定最先遇到的并列玩家。最终同分时，获得非正分轮次更多者优先；仍同分则所有人追加一张随机黑沙漏轮，直到分出胜者。追加轮可能使原本未并列的玩家获胜。",
			titles: {
				choosePrincess: "选择公主",
				pass: "选择要传出的手牌",
				lock: "留出最后一墩的牌",
				revealSuit: "公开一种花色",
				hide: "暂存一半手牌",
				draft: "留下两张牌",
				bid: "暗押本轮赢墩数",
				discard: "弃一张小于8的牌",
				before: "是否使用公主能力？",
				play: "出一张牌",
				iceTarget: "选择要冰封的玩家",
				freeze: "选择对方必须出的牌",
				mermaid: "点名领出的花色",
				mermaidRetry: "领出者没有该花色，请继续点名",
				leader: "选择领出者",
				barterTarget: "选择交换对象",
				barter: "交换或归还抽到的牌",
				contribute: "暗交一张牌",
				distribute: "选择交给此玩家的牌",
				mulan: "是否替换自己出的牌？",
				mulanCard: "选择要交换的牌",
				alice: "是否重新进行这一墩？",
				haggle: "是否用手牌交换墩中的牌？",
				haggleCard: "选择别人刚出的牌",
				redAsk: "点名要寻找的牌",
				redGive: "交出一张同花色手牌",
				beautyFirst: "选择第一张已出过的牌",
				beautySecond: "选择与它交换位置的牌",
				afterPlay: "是否交换两张已出过的牌？",
				wait: "等待其他玩家",
				reveal: "亮牌",
				collect: "收墩",
				score: "本轮计分",
				roundEnd: "下一轮即将开始",
				done: "舞会结束"
			},
			labels: {
				confirm: "确认",
				skip: "不使用",
				power: "使用能力",
				play: "出牌",
				zero: "以0打出",
				ignore: "不跟花色",
				return: "归还原牌",
				princess: "选择公主",
				target: "选择玩家",
				suit: "选择花色",
				swap: "交换",
				keep: "留下"
			},
			suits: {
				queens: "皇后",
				princes: "王子",
				fairies: "仙女",
				pets: "宠物"
			},
			princess: {
				alice: "爱丽丝",
				cinderella: "灰姑娘",
				ice: "冰雪公主",
				mermaid: "小美人鱼",
				mulan: "花木兰",
				pea: "豌豆公主",
				pocahontas: "宝嘉康蒂",
				scheherazade: "山鲁佐德",
				sleeping: "睡美人",
				snow: "白雪公主",
				rapunzel: "长发公主",
				thumbelina: "拇指姑娘",
				red: "小红帽",
				swan: "天鹅少女",
				beauty: "贝儿",
				carmesina: "卡尔梅西娜"
			},
			power: {
				alice: "赢下不含青蛙的一墩后，将明出的牌洗匀发回所有人手中，重新进行这一墩。王子已混入的状态保留。",
				cinderella: "一墩开始前，反转本墩的大小顺序。",
				ice: "一墩开始前，随机查看一名玩家的两张暗手牌，选一张成为其本墩必须出的牌，另一张归还。冰封牌可以违背跟色等限制；冰封王子使王子混入。",
				mermaid: "一墩开始前，点名一种花色；若领出者没有该花色，继续点名，直到命中。王子未混入时，先询问其他花色，确认领出者只有王子后才能指定王子；不能覆盖冰封牌。",
				mulan: "所有牌亮出后，用一张同花色手牌替换自己出的牌，不能换入或换出青蛙。替换不受奇偶限制，但仍受豌豆公主影响。",
				pea: "一墩开始前，要求其他人在满足跟色等限制后，持有大于5的合法牌时必须出大于5的牌。",
				pocahontas: "一墩开始前，指定任意玩家领出。小美人鱼已经指定花色时不能使用。",
				scheherazade: "一墩开始前，随机查看另一人的一张暗手牌，可用自己的手牌交换，或将原牌归还。不能交换最后留出的牌，也不能撤销对领出者的冰封或指定花色。",
				sleeping: "一墩开始前，所有人暗交一张手牌。你查看每张牌的来源，再决定每名玩家收到哪张牌。不能撤销已经生效的冰封或指定花色；不能交换最后留出的牌。",
				snow: "出牌时，将一张本来合法且数值不大于7的牌作为0参与本墩比较；轮末仍按原数值计分。",
				rapunzel: "一墩开始前，要求领出者出王子，即使王子尚未混入；没有王子时任意领出。能力仍会耗用，本次领出不使王子混入。",
				thumbelina: "跟牌时可不跟花色，但不能用此能力出王子或青蛙。不能违背对领出者指定的花色。",
				red: "轮到你出牌时，点名一张非青蛙牌。持有者必须用它与你的一张同花色手牌交换；无人持有也会耗用能力。暂存牌和最后留出的牌不算手牌。",
				swan: "轮到你出牌时，可改为本墩最后出牌。若原本由你领出，则由左边玩家领出；不能撤销宝嘉康蒂指定你领出的能力。",
				beauty: "自己出牌后，交换本轮已出过的两张非青蛙牌的位置。不改变已经确定的领色或越界赢家。暗牌的身份不会因此向你公开。",
				carmesina: "在相应时机，复制本局其他玩家本轮尚未使用的一种公主能力。被复制的玩家本墩不能再用该能力，但仍可在之后的墩使用。"
			},
			roundNames: {
				a: "很久以前",
				b: "迟到舞会",
				c: "魔豆",
				d: "三度淑女",
				e: "包办婚姻",
				f: "皇室敕令",
				g: "永远的伴娘",
				h: "水晶般透明",
				i: "假面舞会",
				j: "宠物复仇",
				k: "抢椅子",
				l: "姐妹情谊",
				m: "余兴派对",
				n: "重要约会要迟到",
				o: "结婚礼物",
				p: "与女巫议价",
				q: "盲人摸象",
				r: "毒苹果",
				s: "奇与偶",
				t: "单身仙女",
				u: "王子总按两次门铃",
				v: "午夜变装",
				w: "传递花束",
				x: "颠倒世界",
				y: "洗手间休息",
				z: "舞后",
				alpha: "穿堂风",
				beta: "秘密竞标",
				gamma: "遗赠",
				delta: "老故事",
				epsilon: "魔法之夜",
				zeta: "惊喜婚礼"
			},
			roundRules: {
				a: "没有额外规则。",
				b: "交换后，每人留出一张牌，最后一墩才出。最后留出的牌不能被睡美人或山鲁佐德交换。",
				c: "每次只能出自己相应花色的最大或最小牌，仍须跟色。缺色时可选其他花色的最大或最小牌。",
				d: "每张3减3分；王子3合计减2分。",
				e: "本轮没有赢墩的玩家额外获得5次求婚。",
				f: "皇后为王牌。有皇后时，由其中最大者赢墩；灰姑娘仍反转大小。",
				g: "领色第二大的牌赢墩。其他人都缺色时，领出者赢。",
				h: "交换后，每人选择自己持有的一种花色，将其全部手牌同时公开。之后收到的同花色牌保持隐藏。随机抽牌不包括已公开牌。",
				i: "除领出者外，所有人暗出牌，收齐后同时亮出。白雪公主仍须宣告能力，花木兰在亮牌后替换。",
				j: "每张宠物额外计1次求婚，青蛙合计6次。",
				k: "每墩结束后，每人同时传一张手牌给右边玩家，再进入公主能力时机。",
				l: "领出者不能赢墩。其他跟领色者中，与领牌数值距离最远者赢；所有人都缺色时，在其他人中比较距离。同距离优先较大数，灰姑娘生效时优先较小数；仍同数则先出者赢。",
				m: "每人暂存一半手牌，先打完当前手牌，再取回暂存牌。公主能力只能作用于当前手牌。",
				n: "最后三张手牌直接加入自己赢下的牌并计分。",
				o: "每墩前，每人暗交一张礼物，礼物归本墩赢家。睡美人先于交礼物。爱丽丝只重分明出的牌，礼物留待重打后的赢家收取。本轮不能获得舞会叛逆者奖励。",
				p: "赢家可公开一张手牌，将其换入刚赢的墩，并拿回一张别人出的牌。换入王子不使王子混入。",
				q: "每人暂存一半手牌，先打完当前手牌，再将暂存牌传给右边玩家继续打。能力不能作用于暂存牌。",
				r: "有缺领色者时，由缺色者中数值最高的牌赢；同数先出者赢。没有缺色者时照常。",
				s: "跟花色并跟领牌的奇偶。不能同时满足时先跟色；缺色时再要求跟奇偶。花木兰的替换不受奇偶限制。",
				t: "每张仙女减1次求婚。",
				u: "每人按顺序出一张，再按同顺序出第二张。比较领色牌数值之和；同和比较最大的单张。反转时比较最小和、最小单张。能力影响两张牌。",
				v: "仙女可随时跟任何花色。没有领色但有仙女时须出仙女，不算缺色。领色或仙女中最大者赢，同数先出者赢。指定领出花色仍须遵守。",
				w: "每张新花色的牌都改变领色；最后领色中的最大牌赢墩。",
				x: "本墩每出现一张6就反转一次大小，与灰姑娘的反转叠加。花木兰换入或换出6时重新计算。",
				y: "王子计两次求婚，但本轮开始前累计求婚最多的玩家仍每张计一次。",
				z: "王子与皇后优先按同数配对，每对计3次求婚；不同数配对计2次；未配对王子计1次，未配对皇后计0次。",
				alpha: "每次暗留两张牌，将剩余手牌传给左边玩家，重复直到全部牌分完。留出的牌可以查看，但不能再传。",
				beta: "交换后，暗押一张非王子、非青蛙牌并移出手牌。若本轮赢墩数等于其数值，忽略其他牌分，每墩减1次求婚。",
				gamma: "最后一墩赢家把本轮全部赢牌交给左边玩家，再计分。",
				delta: "每张王子减1次求婚，青蛙仍计5次。",
				epsilon: "交换后，每人暗弃一张小于8的牌，亮出后数值之和成为本轮固定阈值。每墩按出牌顺序累计所有花色的数值，第一个使总和大于阈值者赢；未超过时照常。有人无法弃牌则重新洗发并交换。",
				zeta: "领出者宣告花色但暗出牌，收齐所有人的牌后才亮出。"
			}
		},
		en: {
			name: "Rebel Princess: Deluxe Edition",
			desc: "Dodge Princes and the Frog, bend the rules with princess powers, and finish the ball with the fewest proposals.",
			invalid: "That action is not available. Please choose again.",
			round: "Round {{n}}",
			proposals: "Proposals",
			tricks: "Tricks",
			hand: "Hand",
			openHand: "Public hand",
			selected: "{{n}} / {{total}} selected",
			used: "Power spent",
			ready: "Submitted",
			leader: "Lead",
			broken: "Princes have snuck in",
			unbroken: "Princes are not invited",
			limit: "Threshold: {{n}}",
			received: "Received cards",
			target: "Give to: {{name}}",
			roundRule: "Round rule",
			powerRule: "Princess power",
			close: "Close",
			total: "Total",
			rebel: "Rebel of the Ball",
			champion: "Free to be a princess",
			final: "Fewest proposals wins",
			rounds: "Game length",
			three: "3 rounds",
			five: "5 rounds",
			roundMode: "Round cards",
			recommended: "Recommended order",
			random: "Random rounds",
			expansion: "Happily Never After",
			promos: "Beauty and Carmesina promos",
			on: "On",
			off: "Off",
			hidden: "Face down",
			scoreDetail: "Proposals by round",
			neutralRound: "Choose princesses to begin",
			waitName: "Waiting for {{name}}",
			leftFirst: "Select {{left}} card(s) for the left first, then {{right}} for the right.",
			hintUsed: "{{n}} hints used",
			autopilot: "{{n}}% autopilot",
			rules: "Goal:\nFinish a 3- or 5-round ball with the fewest proposals. Each Prince scores 1 and the Pet 8 (the Frog) scores 5. Capturing every Prince and the Frog scores only −10 for the round: Rebel of the Ball. This bonus is unavailable in Wedding Gift.\nSetup:\nWith 3 players remove 1, 11 and 12 from every suit; with 4–5 remove 11 and 12; with 6 use all 48 cards. Shuffle and deal equally. Choose one of two princesses; each power is available once per round. With 6 players, the sixth chooses from the first five players’ rejected princesses. Optional expansion and promos are off by default.\nPlay:\nReveal one round card at a time; its rule overrides normal play. Simultaneously pass as its arrows indicate. Received cards stay hidden until everyone commits. When passing both ways, select the leftward cards first, then the rightward cards. Recommended rounds are a, b, c, d, e, or a, b, e for a short game. Random selection places black-hourglass cards only in the final round.\nThe leader plays a card and others follow clockwise. Follow the led suit if possible; otherwise play any suit. The highest card in the led suit wins and leads next. Captured cards cannot be freely inspected before scoring. Princes cannot be led until a void player plays a Prince, unless the leader holds only Princes. The Frog is not a Prince. Rapunzel’s forced lead and Haggle trades do not break Princes.\nPrincess powers:\nUse each power at its stated time. Pre-trick offers begin left of the leader and proceed clockwise. A declaration reopens offers; a full cycle of passes begins play. Powers cannot cancel existing constraints. Select your princess for details; the round card explains its special rule.\n· Sleeping Beauty sees each contribution’s source and assigns cards one by one.\n· The Ice Princess and Scheherazade draw only hidden active hand cards.\nSet-aside and reserved cards have their round-specific protection.\n· Beauty can select previously public cards or your own known plays, without revealing another player’s hidden cards.\nExchanges preserve the original led suit and card. If no eligible led-suit cards remain, the original leader wins; explicit special-round rules take precedence.\nScoring:\nApply the round’s scoring, refresh powers, shuffle and deal again. The lowest cumulative score leads next; ties are resolved clockwise starting left of the previous round’s leader. Final ties favor the most rounds with a non-positive score. If still tied, everyone plays another random black-hourglass round until one winner remains. Someone outside the original tie can win.",
			titles: {
				choosePrincess: "Choose a princess",
				pass: "Choose cards to pass",
				lock: "Reserve your last card",
				revealSuit: "Reveal one suit",
				hide: "Set aside half your hand",
				draft: "Keep two cards",
				bid: "Bid your trick count",
				discard: "Discard a card below 8",
				before: "Use a princess power?",
				play: "Play a card",
				iceTarget: "Choose whom to freeze",
				freeze: "Choose their forced card",
				mermaid: "Name the led suit",
				mermaidRetry: "The leader has none of that suit. Name another.",
				leader: "Choose the leader",
				barterTarget: "Choose a player to barter with",
				barter: "Swap or return the drawn card",
				contribute: "Contribute a card face down",
				distribute: "Assign a card to this player",
				mulan: "Replace your played card?",
				mulanCard: "Choose a card to swap",
				alice: "Replay this trick?",
				haggle: "Trade a hand card into the trick?",
				haggleCard: "Choose another player’s card",
				redAsk: "Name the card you seek",
				redGive: "Give a hand card of the same suit",
				beautyFirst: "Choose the first played card",
				beautySecond: "Choose the other card to switch",
				afterPlay: "Switch two played cards?",
				wait: "Waiting for other players",
				reveal: "Reveal",
				collect: "Collect the trick",
				score: "Round scoring",
				roundEnd: "Next round",
				done: "The ball is over"
			},
			labels: {
				confirm: "Confirm",
				skip: "Pass",
				power: "Use power",
				play: "Play",
				zero: "Play as zero",
				ignore: "Ignore suit",
				return: "Return card",
				princess: "Choose princess",
				target: "Choose player",
				suit: "Choose suit",
				swap: "Swap",
				keep: "Keep"
			},
			suits: {
				queens: "Queens",
				princes: "Princes",
				fairies: "Fairies",
				pets: "Pets"
			},
			princess: {
				alice: "Alice",
				cinderella: "Cinderella",
				ice: "The Ice Princess",
				mermaid: "The Little Mermaid",
				mulan: "Mulan",
				pea: "The Pea Princess",
				pocahontas: "Pocahontas",
				scheherazade: "Scheherazade",
				sleeping: "Sleeping Beauty",
				snow: "Snow White",
				rapunzel: "Rapunzel",
				thumbelina: "Thumbelina",
				red: "Red Riding Hood",
				swan: "The Swan Maiden",
				beauty: "Beauty",
				carmesina: "Carmesina"
			},
			power: {
				alice: "After winning a trick without the Frog, shuffle its face-up cards and deal them back to everyone, then replay it. Princes remain broken if they snuck in.",
				cinderella: "Before a trick, reverse its card hierarchy.",
				ice: "Before a trick, inspect two random hidden cards from a player. Choose one as their forced play and return the other. The frozen card overrides play restrictions; a frozen Prince breaks Princes.",
				mermaid: "Before a trick, name a suit. If the leader has none, keep naming suits until one is held. Before Princes have broken in, ask about the other suits first; Princes may be named once the answers confirm that only Princes remain. A frozen lead cannot be overridden.",
				mulan: "After all cards are revealed, replace your played card with a hand card of the same suit. Neither may be the Frog. The replacement ignores parity but remains subject to the Pea Princess.",
				pea: "Before a trick, other players must play above 5 whenever they can do so while following suit and other restrictions.",
				pocahontas: "Before a trick, choose any player to lead. This cannot override the Little Mermaid.",
				scheherazade: "Before a trick, inspect one random hidden card from another player. Swap a hand card for it or return it. The final reserved card and a constrained leader are protected.",
				sleeping: "Before a trick, everyone contributes a hand card. View each source and assign one card to every player. Existing frozen cards, named suits and the final reserved card are protected.",
				snow: "Play an otherwise legal card of value 7 or lower as zero for this trick. Its printed value still applies to round scoring.",
				rapunzel: "Before a trick, require the leader to lead a Prince, even before Princes break. If none is held, any lead is allowed. The power is still spent and this lead does not break Princes.",
				thumbelina: "When following, you may ignore suit, but cannot use this power to play a Prince or the Frog. A required lead suit still applies.",
				red: "On your turn, name a card other than the Frog. Its holder must trade it for a hand card of yours in the same suit. The power is spent even if nobody has it. Set-aside and reserved cards are not in hand.",
				swan: "On your turn, move to the end of this trick. If you were leading, the player to your left leads. Pocahontas’s forced lead cannot be overridden.",
				beauty: "After playing, switch two previously played non-Frog cards. The established led suit and threshold winner do not change. Hidden card identities are not disclosed.",
				carmesina: "At the matching time, copy another chosen princess’s unused power. Its owner cannot activate it this trick, but may do so in a later trick."
			},
			roundNames: {
				a: "Once Upon a Time",
				b: "Late to the Ball",
				c: "Magic Beans",
				d: "Three Times a Lady",
				e: "Arranged Marriage",
				f: "Royal Decree",
				g: "Always the Bridesmaid",
				h: "Crystal Clear",
				i: "Masquerade Ball",
				j: "Pet’s Revenge",
				k: "Musical Chairs",
				l: "Sisterhood",
				m: "After Party",
				n: "Late for a Very Important Date",
				o: "Wedding Gift",
				p: "Haggle with the Hag",
				q: "Blind Man’s Bluff",
				r: "Poisoned Apple",
				s: "Odds and Evens",
				t: "Single Fairy",
				u: "The Prince Always Rings Twice",
				v: "Midnight Makeover",
				w: "Pass the Bouquet",
				x: "Upside Down",
				y: "Bathroom Break",
				z: "Dancing Queens",
				alpha: "It’s 2 Drafty in Here",
				beta: "Secret Bid",
				gamma: "Bequeathed",
				delta: "The Same Old Story",
				epsilon: "Sum Enchanted Evening",
				zeta: "Surprise Wedding"
			},
			roundRules: {
				a: "No special rules.",
				b: "After passing, reserve one card for the final trick. Sleeping Beauty and Scheherazade cannot exchange that final card.",
				c: "Play only the highest or lowest card you hold in the chosen suit. Follow suit if possible.",
				d: "Every 3 scores −3; the Prince 3 totals −2.",
				e: "Players who win no tricks receive 5 extra proposals.",
				f: "Queens are trumps. The highest Queen wins unless the hierarchy is reversed.",
				g: "The second-highest card of the led suit wins. If everyone else is void, the leader wins.",
				h: "After passing, simultaneously reveal all cards of one suit you hold. Later arrivals stay hidden. Random draws exclude face-up cards.",
				i: "Followers play face down and reveal together. Snow White announces her power; Mulan swaps after the reveal.",
				j: "Every Pet adds 1 proposal; the Frog totals 6.",
				k: "After each trick, simultaneously pass one hand card right, then offer pre-trick powers.",
				l: "The leader cannot win. Among other followers, the furthest value from the lead wins. If all are void, compare all others. Equal distance favors the higher value, or lower when reversed; remaining ties favor earlier play.",
				m: "Set aside half your hand. Play the active half first, then take back the rest. Powers affect only active hands.",
				n: "Keep and score your final three hand cards as captured cards.",
				o: "Before each trick, everyone contributes a face-down gift for the winner. Sleeping Beauty acts first. Alice redistributes only face-up trick cards; gifts stay for the replay winner. Rebel of the Ball is unavailable.",
				p: "The winner may trade a revealed hand card for another player’s card in the trick. Trading in a Prince does not break Princes.",
				q: "Set aside half your hand. After playing the active half, pass the rest right and continue. Powers cannot affect set-aside cards.",
				r: "If anyone is void, the highest off-suit card wins; equal values favor earlier play. Otherwise resolve normally.",
				s: "Match suit and parity. Suit takes priority; if void, match parity when possible. Mulan’s replacement ignores parity.",
				t: "Every Fairy scores −1 proposal.",
				u: "Play one card each, then a second in the same order. Compare sums in the led suit, then the highest single card. Reversed play compares lowest sums and lowest singles. Powers affect both cards.",
				v: "Fairies can follow any suit. If void but holding Fairies, play a Fairy. The highest led-suit card or Fairy wins; ties favor earlier play. Named lead suits still apply.",
				w: "Each newly played suit becomes the led suit. The highest card of the final suit wins.",
				x: "Each 6 reverses the hierarchy again, stacking with Cinderella. Recompute if Mulan adds or removes a 6.",
				y: "Princes score double, except for players tied for the highest cumulative score before the round.",
				z: "Pair Princes with Queens, matching equal values first for 3 proposals each. Other pairs score 2, lone Princes 1 and lone Queens 0.",
				alpha: "Keep two cards face down, pass the rest left, and repeat until all are kept. Kept cards may be viewed but not passed.",
				beta: "After passing, set aside a non-Prince, non-Frog card. If its value matches your trick count, ignore normal card scoring and score −1 per trick.",
				gamma: "The final trick winner gives all captured cards to the player on their left before scoring.",
				delta: "Each Prince scores −1 proposal; the Frog still scores 5.",
				epsilon: "After passing, everyone discards a card below 8. Their revealed sum is the fixed round threshold. Within each trick, total all suits in play order; the first player to exceed the threshold wins. Otherwise resolve normally. If anyone cannot discard, redeal and pass again.",
				zeta: "The leader announces a suit but plays face down, revealing after everyone has played."
			}
		}
	}
};
//#endregion
export { tt as default };
