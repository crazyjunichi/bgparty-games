import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as i } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { Texture as s } from "@bgparty/sdk/texture";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as u, seatName as d } from "@bgparty/sdk/ui/player-strip";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { Confetti as v } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as y, OptionSection as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/faraway/cards.ts
var x = [
	{
		id: 1,
		biome: "forest",
		night: !1,
		clues: 0,
		symbols: ["okiko", "uddu"],
		quest: null
	},
	{
		id: 2,
		biome: "desert",
		night: !1,
		clues: 0,
		symbols: ["uddu", "uddu"],
		quest: null
	},
	{
		id: 3,
		biome: "river",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "flat",
			points: 4
		}
	},
	{
		id: 4,
		biome: "forest",
		night: !1,
		clues: 0,
		symbols: ["goldlog", "uddu"],
		quest: null
	},
	{
		id: 5,
		biome: "river",
		night: !1,
		clues: 0,
		symbols: ["okiko"],
		quest: {
			kind: "flat",
			points: 2
		}
	},
	{
		id: 6,
		biome: "desert",
		night: !1,
		clues: 1,
		symbols: ["uddu"],
		quest: null
	},
	{
		id: 7,
		biome: "forest",
		night: !1,
		clues: 0,
		symbols: ["okiko", "goldlog"],
		quest: null
	},
	{
		id: 8,
		biome: "river",
		night: !1,
		clues: 1,
		symbols: ["okiko"],
		quest: null
	},
	{
		id: 9,
		biome: "desert",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "flat",
			points: 5
		}
	},
	{
		id: 10,
		biome: "forest",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perNight",
			per: 3
		}
	},
	{
		id: 11,
		biome: "river",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perClue",
			per: 2
		}
	},
	{
		id: 12,
		biome: "city",
		night: !1,
		clues: 1,
		symbols: ["goldlog"],
		quest: null
	},
	{
		id: 13,
		biome: "desert",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perSymbol",
			symbol: "uddu",
			per: 2
		}
	},
	{
		id: 14,
		biome: "forest",
		night: !1,
		clues: 0,
		symbols: ["goldlog"],
		quest: {
			kind: "perNight",
			per: 2
		}
	},
	{
		id: 15,
		biome: "river",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "perSymbol",
			symbol: "okiko",
			per: 2
		}
	},
	{
		id: 16,
		biome: "forest",
		night: !1,
		clues: 0,
		symbols: ["okiko"],
		quest: {
			kind: "perSymbol",
			symbol: "okiko",
			per: 2
		}
	},
	{
		id: 17,
		biome: "desert",
		night: !1,
		clues: 0,
		symbols: ["uddu"],
		quest: {
			kind: "perSymbol",
			symbol: "uddu",
			per: 3,
			prereq: { okiko: 2 }
		}
	},
	{
		id: 18,
		biome: "river",
		night: !1,
		clues: 0,
		symbols: ["okiko"],
		quest: {
			kind: "perFourSet",
			per: 10
		}
	},
	{
		id: 19,
		biome: "forest",
		night: !1,
		clues: 0,
		symbols: ["goldlog"],
		quest: {
			kind: "perSymbol",
			symbol: "goldlog",
			per: 2
		}
	},
	{
		id: 20,
		biome: "river",
		night: !0,
		clues: 1,
		symbols: [],
		quest: {
			kind: "perNight",
			per: 2,
			prereq: { uddu: 1 }
		}
	},
	{
		id: 21,
		biome: "desert",
		night: !0,
		clues: 0,
		symbols: [],
		quest: {
			kind: "flat",
			points: 8,
			prereq: { uddu: 2 }
		}
	},
	{
		id: 22,
		biome: "river",
		night: !0,
		clues: 1,
		symbols: [],
		quest: {
			kind: "perClue",
			per: 1
		}
	},
	{
		id: 23,
		biome: "forest",
		night: !0,
		clues: 0,
		symbols: ["okiko", "uddu"],
		quest: {
			kind: "perFourSet",
			per: 10
		}
	},
	{
		id: 24,
		biome: "desert",
		night: !0,
		clues: 0,
		symbols: ["uddu"],
		quest: {
			kind: "perNight",
			per: 2,
			prereq: { okiko: 1 }
		}
	},
	{
		id: 25,
		biome: "city",
		night: !0,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perBiome",
			biomes: ["city", "river"],
			per: 1
		}
	},
	{
		id: 26,
		biome: "forest",
		night: !0,
		clues: 0,
		symbols: ["okiko"],
		quest: {
			kind: "perSymbol",
			symbol: "goldlog",
			per: 3
		}
	},
	{
		id: 27,
		biome: "city",
		night: !0,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perBiome",
			biomes: ["city", "desert"],
			per: 1
		}
	},
	{
		id: 28,
		biome: "forest",
		night: !0,
		clues: 0,
		symbols: ["uddu"],
		quest: {
			kind: "perSymbol",
			symbol: "okiko",
			per: 3
		}
	},
	{
		id: 29,
		biome: "city",
		night: !0,
		clues: 0,
		symbols: ["goldlog"],
		quest: {
			kind: "perSymbol",
			symbol: "goldlog",
			per: 2
		}
	},
	{
		id: 30,
		biome: "forest",
		night: !0,
		clues: 0,
		symbols: ["uddu"],
		quest: {
			kind: "perSymbol",
			symbol: "uddu",
			per: 2
		}
	},
	{
		id: 31,
		biome: "city",
		night: !0,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perBiome",
			biomes: ["city", "forest"],
			per: 1
		}
	},
	{
		id: 32,
		biome: "forest",
		night: !0,
		clues: 0,
		symbols: ["okiko", "uddu"],
		quest: {
			kind: "flat",
			points: 7,
			prereq: { uddu: 3 }
		}
	},
	{
		id: 33,
		biome: "city",
		night: !0,
		clues: 1,
		symbols: [],
		quest: {
			kind: "perSymbol",
			symbol: "goldlog",
			per: 3
		}
	},
	{
		id: 34,
		biome: "river",
		night: !0,
		clues: 0,
		symbols: ["okiko"],
		quest: {
			kind: "perSymbol",
			symbol: "okiko",
			per: 3,
			prereq: { uddu: 2 }
		}
	},
	{
		id: 35,
		biome: "city",
		night: !0,
		clues: 0,
		symbols: ["okiko"],
		quest: {
			kind: "perFourSet",
			per: 10
		}
	},
	{
		id: 36,
		biome: "forest",
		night: !0,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perSymbol",
			symbol: "goldlog",
			per: 4,
			prereq: { okiko: 2 }
		}
	},
	{
		id: 37,
		biome: "city",
		night: !0,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perNight",
			per: 3,
			prereq: { goldlog: 1 }
		}
	},
	{
		id: 38,
		biome: "river",
		night: !0,
		clues: 0,
		symbols: ["uddu"],
		quest: {
			kind: "perClue",
			per: 3,
			prereq: {
				okiko: 1,
				goldlog: 1
			}
		}
	},
	{
		id: 39,
		biome: "forest",
		night: !0,
		clues: 0,
		symbols: ["goldlog", "uddu"],
		quest: {
			kind: "flat",
			points: 9,
			prereq: { okiko: 2 }
		}
	},
	{
		id: 40,
		biome: "desert",
		night: !0,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perNight",
			per: 3,
			prereq: {
				goldlog: 1,
				okiko: 1,
				uddu: 1
			}
		}
	},
	{
		id: 41,
		biome: "river",
		night: !1,
		clues: 0,
		symbols: ["goldlog"],
		quest: {
			kind: "perNight",
			per: 4,
			prereq: {
				okiko: 1,
				uddu: 2
			}
		}
	},
	{
		id: 42,
		biome: "city",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perBiome",
			biomes: ["city", "river"],
			per: 2,
			prereq: {
				uddu: 1,
				okiko: 1
			}
		}
	},
	{
		id: 43,
		biome: "desert",
		night: !1,
		clues: 0,
		symbols: ["uddu"],
		quest: {
			kind: "perFourSet",
			per: 10
		}
	},
	{
		id: 44,
		biome: "city",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perBiome",
			biomes: ["city", "desert"],
			per: 2,
			prereq: {
				uddu: 1,
				goldlog: 1
			}
		}
	},
	{
		id: 45,
		biome: "river",
		night: !1,
		clues: 0,
		symbols: ["uddu"],
		quest: {
			kind: "flat",
			points: 13,
			prereq: { okiko: 3 }
		}
	},
	{
		id: 46,
		biome: "desert",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "flat",
			points: 10,
			prereq: {
				uddu: 2,
				okiko: 1
			}
		}
	},
	{
		id: 47,
		biome: "city",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perBiome",
			biomes: ["city", "forest"],
			per: 2,
			prereq: {
				goldlog: 1,
				okiko: 1
			}
		}
	},
	{
		id: 48,
		biome: "forest",
		night: !1,
		clues: 0,
		symbols: ["okiko"],
		quest: {
			kind: "perSymbol",
			symbol: "uddu",
			per: 3
		}
	},
	{
		id: 49,
		biome: "desert",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "flat",
			points: 12,
			prereq: {
				uddu: 2,
				goldlog: 1
			}
		}
	},
	{
		id: 50,
		biome: "city",
		night: !1,
		clues: 0,
		symbols: ["uddu"],
		quest: {
			kind: "perBiome",
			biomes: ["river"],
			per: 4,
			prereq: { goldlog: 2 }
		}
	},
	{
		id: 51,
		biome: "desert",
		night: !1,
		clues: 0,
		symbols: ["uddu"],
		quest: {
			kind: "flat",
			points: 14,
			prereq: { uddu: 4 }
		}
	},
	{
		id: 52,
		biome: "forest",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perSymbol",
			symbol: "okiko",
			per: 4,
			prereq: { uddu: 3 }
		}
	},
	{
		id: 53,
		biome: "city",
		night: !1,
		clues: 0,
		symbols: ["okiko"],
		quest: {
			kind: "perBiome",
			biomes: ["forest"],
			per: 4,
			prereq: { goldlog: 2 }
		}
	},
	{
		id: 54,
		biome: "river",
		night: !1,
		clues: 0,
		symbols: ["okiko"],
		quest: {
			kind: "perClue",
			per: 4,
			prereq: { goldlog: 2 }
		}
	},
	{
		id: 55,
		biome: "desert",
		night: !1,
		clues: 1,
		symbols: ["uddu"],
		quest: {
			kind: "perSymbol",
			symbol: "uddu",
			per: 3,
			prereq: {
				okiko: 1,
				goldlog: 2
			}
		}
	},
	{
		id: 56,
		biome: "city",
		night: !1,
		clues: 0,
		symbols: ["goldlog"],
		quest: {
			kind: "perBiome",
			biomes: ["desert"],
			per: 4,
			prereq: {
				okiko: 2,
				uddu: 1
			}
		}
	},
	{
		id: 57,
		biome: "forest",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "perSymbol",
			symbol: "uddu",
			per: 4,
			prereq: { goldlog: 3 }
		}
	},
	{
		id: 58,
		biome: "river",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "perClue",
			per: 3,
			prereq: { okiko: 3 }
		}
	},
	{
		id: 59,
		biome: "city",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "perBiome",
			biomes: ["city", "forest"],
			per: 3,
			prereq: {
				okiko: 3,
				uddu: 1
			}
		}
	},
	{
		id: 60,
		biome: "desert",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "flat",
			points: 16,
			prereq: {
				uddu: 2,
				okiko: 2
			}
		}
	},
	{
		id: 61,
		biome: "river",
		night: !1,
		clues: 0,
		symbols: ["goldlog"],
		quest: {
			kind: "flat",
			points: 17,
			prereq: { okiko: 4 }
		}
	},
	{
		id: 62,
		biome: "city",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "perBiome",
			biomes: ["city", "desert"],
			per: 3,
			prereq: { goldlog: 3 }
		}
	},
	{
		id: 63,
		biome: "river",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "perClue",
			per: 3,
			prereq: {
				okiko: 2,
				goldlog: 1
			}
		}
	},
	{
		id: 64,
		biome: "desert",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "flat",
			points: 18,
			prereq: {
				uddu: 2,
				goldlog: 2
			}
		}
	},
	{
		id: 65,
		biome: "city",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "perBiome",
			biomes: ["city", "river"],
			per: 3,
			prereq: { goldlog: 3 }
		}
	},
	{
		id: 66,
		biome: "desert",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "flat",
			points: 20,
			prereq: { uddu: 4 }
		}
	},
	{
		id: 67,
		biome: "river",
		night: !1,
		clues: 1,
		symbols: [],
		quest: {
			kind: "flat",
			points: 19,
			prereq: {
				okiko: 2,
				goldlog: 2
			}
		}
	},
	{
		id: 68,
		biome: "desert",
		night: !1,
		clues: 0,
		symbols: [],
		quest: {
			kind: "flat",
			points: 24,
			prereq: { uddu: 5 }
		}
	}
], S = [
	{
		id: 0,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perBiome",
			biomes: ["city", "river"],
			per: 1
		}
	},
	{
		id: 1,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perBiome",
			biomes: ["river", "desert"],
			per: 1
		}
	},
	{
		id: 2,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perBiome",
			biomes: ["forest", "city"],
			per: 1
		}
	},
	{
		id: 3,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perBiome",
			biomes: ["river", "forest"],
			per: 1
		}
	},
	{
		id: 4,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perBiome",
			biomes: ["desert", "city"],
			per: 1
		}
	},
	{
		id: 5,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perBiome",
			biomes: ["city"],
			per: 1
		}
	},
	{
		id: 6,
		clues: 0,
		symbols: ["uddu"],
		night: !1,
		biome: null,
		quest: {
			kind: "perSymbol",
			symbol: "uddu",
			per: 1
		}
	},
	{
		id: 7,
		clues: 1,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perClue",
			per: 1
		}
	},
	{
		id: 8,
		clues: 0,
		symbols: ["uddu"],
		night: !1,
		biome: null,
		quest: {
			kind: "perClue",
			per: 1
		}
	},
	{
		id: 9,
		clues: 0,
		symbols: [],
		night: !0,
		biome: "forest",
		quest: null
	},
	{
		id: 10,
		clues: 0,
		symbols: ["okiko"],
		night: !0,
		biome: null,
		quest: null
	},
	{
		id: 11,
		clues: 0,
		symbols: ["okiko"],
		night: !1,
		biome: null,
		quest: {
			kind: "perSymbol",
			symbol: "okiko",
			per: 1
		}
	},
	{
		id: 12,
		clues: 0,
		symbols: ["goldlog"],
		night: !1,
		biome: null,
		quest: {
			kind: "perSymbol",
			symbol: "goldlog",
			per: 1
		}
	},
	{
		id: 13,
		clues: 0,
		symbols: ["goldlog"],
		night: !0,
		biome: null,
		quest: null
	},
	{
		id: 14,
		clues: 1,
		symbols: ["goldlog"],
		night: !1,
		biome: null,
		quest: null
	},
	{
		id: 15,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perSymbol",
			symbol: "goldlog",
			per: 2
		}
	},
	{
		id: 16,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perSymbol",
			symbol: "uddu",
			per: 2
		}
	},
	{
		id: 17,
		clues: 0,
		symbols: ["uddu"],
		night: !0,
		biome: null,
		quest: null
	},
	{
		id: 18,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perSymbol",
			symbol: "okiko",
			per: 2
		}
	},
	{
		id: 19,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perClue",
			per: 2
		}
	},
	{
		id: 20,
		clues: 1,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perFourSet",
			per: 4
		}
	},
	{
		id: 21,
		clues: 0,
		symbols: [],
		night: !1,
		biome: "river",
		quest: {
			kind: "perNight",
			per: 1
		}
	},
	{
		id: 22,
		clues: 0,
		symbols: ["uddu"],
		night: !1,
		biome: null,
		quest: {
			kind: "perNight",
			per: 1
		}
	},
	{
		id: 23,
		clues: 0,
		symbols: ["okiko"],
		night: !1,
		biome: null,
		quest: {
			kind: "perClue",
			per: 1
		}
	},
	{
		id: 24,
		clues: 0,
		symbols: ["goldlog"],
		night: !1,
		biome: "forest",
		quest: null
	},
	{
		id: 25,
		clues: 0,
		symbols: ["uddu"],
		night: !1,
		biome: "city",
		quest: null
	},
	{
		id: 26,
		clues: 1,
		symbols: [],
		night: !1,
		biome: "city",
		quest: null
	},
	{
		id: 27,
		clues: 0,
		symbols: [],
		night: !1,
		biome: "city",
		quest: {
			kind: "perFourSet",
			per: 4
		}
	},
	{
		id: 28,
		clues: 0,
		symbols: [],
		night: !1,
		biome: "river",
		quest: {
			kind: "perBiome",
			biomes: ["river"],
			per: 1
		}
	},
	{
		id: 29,
		clues: 0,
		symbols: [],
		night: !1,
		biome: "forest",
		quest: {
			kind: "perBiome",
			biomes: ["forest"],
			per: 1
		}
	},
	{
		id: 30,
		clues: 0,
		symbols: [],
		night: !1,
		biome: "desert",
		quest: {
			kind: "perBiome",
			biomes: ["desert"],
			per: 1
		}
	},
	{
		id: 31,
		clues: 0,
		symbols: [],
		night: !1,
		biome: "city",
		quest: {
			kind: "perClue",
			per: 1
		}
	},
	{
		id: 32,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "flat",
			points: 5
		}
	},
	{
		id: 33,
		clues: 1,
		symbols: ["uddu"],
		night: !1,
		biome: null,
		quest: null
	},
	{
		id: 34,
		clues: 1,
		symbols: [],
		night: !1,
		biome: "desert",
		quest: null
	},
	{
		id: 35,
		clues: 1,
		symbols: ["okiko"],
		night: !1,
		biome: null,
		quest: null
	},
	{
		id: 36,
		clues: 0,
		symbols: [],
		night: !1,
		biome: null,
		quest: {
			kind: "perBiome",
			biomes: ["forest", "desert"],
			per: 1
		}
	},
	{
		id: 37,
		clues: 0,
		symbols: ["okiko"],
		night: !1,
		biome: "desert",
		quest: null
	},
	{
		id: 38,
		clues: 0,
		symbols: ["uddu"],
		night: !1,
		biome: "desert",
		quest: null
	},
	{
		id: 39,
		clues: 0,
		symbols: ["goldlog"],
		night: !1,
		biome: "desert",
		quest: null
	},
	{
		id: 40,
		clues: 0,
		symbols: ["okiko"],
		night: !1,
		biome: "river",
		quest: null
	},
	{
		id: 41,
		clues: 0,
		symbols: ["uddu"],
		night: !1,
		biome: "river",
		quest: null
	},
	{
		id: 42,
		clues: 1,
		symbols: [],
		night: !1,
		biome: "river",
		quest: null
	},
	{
		id: 43,
		clues: 0,
		symbols: ["okiko"],
		night: !1,
		biome: "forest",
		quest: null
	},
	{
		id: 44,
		clues: 0,
		symbols: ["uddu"],
		night: !1,
		biome: "forest",
		quest: null
	}
], C = new Map(x.map((e) => [e.id, e])), w = new Map(S.map((e) => [e.id, e]));
function T(e, t) {
	let n = {
		symbols: {
			uddu: 0,
			okiko: 0,
			goldlog: 0
		},
		biomes: {
			desert: 0,
			forest: 0,
			river: 0,
			city: 0
		},
		nights: 0,
		clues: 0
	};
	for (let t of e) {
		n.biomes[t.biome]++, t.night && n.nights++, n.clues += t.clues;
		for (let e of t.symbols) n.symbols[e]++;
	}
	for (let e of t) {
		e.biome && n.biomes[e.biome]++, e.night && n.nights++, n.clues += e.clues;
		for (let t of e.symbols) n.symbols[t]++;
	}
	return n;
}
function ee(e, t) {
	if (!e) return 0;
	if (e.prereq) {
		for (let [n, r] of Object.entries(e.prereq)) if (t.symbols[n] < (r ?? 0)) return 0;
	}
	switch (e.kind) {
		case "flat": return e.points ?? 0;
		case "perClue": return (e.per ?? 0) * t.clues;
		case "perNight": return (e.per ?? 0) * t.nights;
		case "perSymbol": return (e.per ?? 0) * t.symbols[e.symbol ?? "uddu"];
		case "perFourSet": return (e.per ?? 0) * Math.min(t.biomes.desert, t.biomes.forest, t.biomes.river, t.biomes.city);
		case "perBiome": {
			let n = e.biomes ?? [];
			return n.length === 1 ? (e.per ?? 0) * t.biomes[n[0]] : n.length === 2 ? (e.per ?? 0) * Math.min(t.biomes[n[0]], t.biomes[n[1]]) : 0;
		}
	}
}
//#endregion
//#region src/games/faraway/meta.ts
var E = {
	id: "faraway",
	tier: "beta",
	mechanics: ["drafting", "set-collection"],
	interactionTags: [],
	nameKey: "games.faraway.name",
	descKey: "games.faraway.desc",
	rulesKey: "games.faraway.rules",
	icon: "🧭",
	iconImg: "games/faraway.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/faraway/en.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [3],
	accent: "#6d28d9",
	releasedAt: "2026-09-15",
	search: {
		py: "yao yuan zhi di",
		init: "yyzd"
	},
	hotseat: "cover"
}, D = t.int().min(1).max(68), O = t.int().min(0).max(44), te = t.string(), k = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draft"),
		keep: t.tuple([
			D,
			D,
			D
		])
	}),
	t.object({
		type: t.literal("explore"),
		card: D
	}),
	t.object({
		type: t.literal("refill"),
		bankCard: D.nullable(),
		sanct: O.nullable()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), A = t.object({ advanced: t.boolean().catch(!1) }).default({ advanced: !1 }), ne = t.object({
	rid: te,
	tableau: t.array(D),
	sanctuaries: t.array(O),
	picked: t.boolean(),
	lastPlayed: D.nullable(),
	pendingCount: t.int().nonnegative(),
	fame: t.array(t.int().nullable()),
	sanctFame: t.int().nullable()
}), j = t.object({
	phase: t.enum([
		"draft",
		"explore",
		"refill",
		"scoring",
		"done"
	]),
	round: t.int().min(1).max(8),
	advanced: t.boolean(),
	bank: t.array(D),
	deckLeft: t.int().nonnegative(),
	players: t.array(ne),
	refillOrder: t.array(te),
	refillTurn: te.nullable(),
	scoringPos: t.int().nonnegative().nullable()
}), M = t.object({
	hand: t.array(D),
	mySelected: D.nullable(),
	pendingSanct: t.array(O)
}), N = {
	flip: 1e3,
	sanct: 1600,
	done: 900
}, re = (e) => 450 + 70 * e;
function P(t, n, r) {
	let i = [...t];
	for (let t = i.length - 1; t > 0; --t) {
		let a = e(n, r, t + 1);
		r += 1, [i[t], i[a]] = [i[a], i[t]];
	}
	return [i, r];
}
function ie(e, t) {
	return e.fame[t].reduce((e, t) => e + (t ?? 0), 0) + (e.sanctFame[t] ?? 0);
}
function ae(e, t, n) {
	let r = e.advanced, i = 0, [a, o] = P(x.map((e) => e.id), n, i);
	i = o;
	let [s, c] = P(S.map((e) => e.id), n, i);
	i = c;
	let l = {}, u = {}, d = {}, f = {}, p = {}, m = {}, h = {}, g = r ? 5 : 3;
	for (let e of t) l[e] = a.splice(0, g).sort((e, t) => e - t), u[e] = [], d[e] = [], f[e] = [], p[e] = null, m[e] = Array.from({ length: 8 }, () => null), h[e] = null;
	let _ = r ? [] : a.splice(0, t.length + 1), v = {
		players: t,
		advanced: r,
		phase: r ? "draft" : "explore",
		round: 1,
		hands: l,
		tableaux: u,
		sanctuaries: d,
		pendingSanct: f,
		selected: {},
		lastPlayed: p,
		drafted: {},
		bank: _,
		regionDeck: a,
		sanctDeck: s,
		refillOrder: [],
		refillTurn: null,
		scoringPos: null,
		fame: m,
		sanctFame: h,
		beatMs: 0,
		seed: n,
		rngCursor: i
	}, y = t.map((e, t) => ({
		kind: "deal",
		rid: e,
		data: { count: g },
		for: [e],
		secret: { cards: l[e] },
		...t > 0 ? { with: !0 } : {}
	}));
	return r || y.push({
		kind: "bankReveal",
		data: { cards: _ }
	}), {
		state: v,
		fx: y
	};
}
function oe(e, t) {
	let n = 0;
	for (let r of e.tableaux[t]) n += C.get(r)?.clues ?? 0;
	for (let r of e.sanctuaries[t]) n += w.get(r)?.clues ?? 0;
	return n;
}
function F(e) {
	let t = [], n = Object.entries(e.selected).map(([e, t]) => ({
		rid: e,
		card: t
	}));
	for (let { rid: t, card: r } of n) e.tableaux[t] = [...e.tableaux[t], r], e.lastPlayed[t] = r;
	e.selected = {}, t.push({
		kind: "reveal",
		data: { cards: n }
	});
	let r = [];
	for (let { rid: t, card: i } of n) {
		let n = e.tableaux[t], a = n.length >= 2 ? n[n.length - 2] : null;
		if (a === null || i <= a) continue;
		let o = 1 + oe(e, t), s = e.sanctDeck.splice(-o).reverse();
		e.pendingSanct[t] = [...e.pendingSanct[t], ...s], r.push({
			rid: t,
			cards: s
		});
	}
	for (let e of r) t.push({
		kind: "drawSanct",
		rid: e.rid,
		data: { count: e.cards.length },
		for: [e.rid],
		secret: { cards: e.cards }
	});
	return e.refillOrder = n.sort((e, t) => e.card - t.card).map((e) => e.rid), e.round >= 8 && (e.refillOrder = e.refillOrder.filter((t) => e.pendingSanct[t].length > 0)), e.refillTurn = e.refillOrder[0] ?? null, e.phase = "refill", e.beatMs = re(n.length), e.refillTurn === null && t.push(...se(e)), t;
}
function se(e) {
	e.refillOrder = [], e.refillTurn = null;
	for (let t of e.players) e.lastPlayed[t] = null;
	return e.round >= 8 ? (e.phase = "scoring", e.scoringPos = 0, e.beatMs = N.flip, [{ kind: "scoringStart" }]) : (e.bank = e.regionDeck.splice(0, e.players.length + 1), e.round += 1, e.phase = "explore", [{
		kind: "bankReveal",
		data: { cards: e.bank }
	}]);
}
function I(e) {
	let t = e.scoringPos ?? 0;
	if (t < 8) {
		let n = [];
		for (let r of e.players) {
			let i = e.tableaux[r], a = i[7 - t], o = C.get(a), s = i.slice(7 - t).map((e) => C.get(e)).filter((e) => !!e), c = e.sanctuaries[r].map((e) => w.get(e)).filter((e) => !!e), l = ee(o?.quest ?? null, T(s, c));
			e.fame[r][7 - t] = l, n.push({
				rid: r,
				card: a,
				gain: l
			});
		}
		return e.scoringPos = t + 1, e.beatMs = N.flip, {
			kind: "flip",
			data: {
				index: 7 - t,
				plays: n
			}
		};
	}
	if (t === 8) {
		let n = [];
		for (let t of e.players) {
			let r = e.tableaux[t].map((e) => C.get(e)).filter((e) => !!e), i = e.sanctuaries[t].map((e) => w.get(e)).filter((e) => !!e), a = T(r, i), o = i.reduce((e, t) => e + ee(t.quest, a), 0);
			e.sanctFame[t] = o, n.push({
				rid: t,
				gain: o
			});
		}
		return e.scoringPos = t + 1, e.beatMs = N.sanct, {
			kind: "flipSanct",
			data: { plays: n }
		};
	}
	return e.phase = "done", { kind: "scoringDone" };
}
function L(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "scoring" || e.scoringPos === null || e.scoringPos > 9) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return {
			state: t,
			fx: [I(t)]
		};
	}
	if (t.type === "draft") {
		if (e.phase !== "draft" || n.by in e.drafted) return { code: "games.faraway.errNotYourTurn" };
		let r = e.hands[n.by] ?? [], i = [...t.keep];
		if (r.length !== 5 || i.length !== 3 || new Set(i).size !== 3 || !i.every((e) => r.includes(e))) return { code: "games.faraway.errBadDraft" };
		let a = structuredClone(e);
		a.hands[n.by] = i.sort((e, t) => e - t), a.drafted[n.by] = !0;
		let o = r.filter((e) => !i.includes(e));
		if (a.regionDeck = [...a.regionDeck, ...o], Object.keys(a.drafted).length === a.players.length) {
			let [e, t] = P(a.regionDeck, a.seed, a.rngCursor);
			return a.regionDeck = e, a.rngCursor = t, a.bank = a.regionDeck.splice(0, a.players.length + 1), a.phase = "explore", {
				state: a,
				fx: [{
					kind: "bankReveal",
					data: { cards: a.bank }
				}]
			};
		}
		return {
			state: a,
			fx: []
		};
	}
	if (t.type === "explore") {
		if (e.phase !== "explore" || n.by in e.selected) return { code: "games.faraway.errNotYourTurn" };
		if (!e.hands[n.by]?.includes(t.card)) return { code: "games.faraway.errBadCard" };
		let r = structuredClone(e);
		return r.hands[n.by] = r.hands[n.by].filter((e) => e !== t.card), r.selected[n.by] = t.card, Object.keys(r.selected).length === r.players.length ? {
			state: r,
			fx: F(r)
		} : {
			state: r,
			fx: []
		};
	}
	if (e.phase !== "refill" || e.refillTurn !== n.by) return { code: "games.faraway.errNotYourTurn" };
	let r = e.pendingSanct[n.by] ?? [];
	if (e.round < 8) {
		if (t.bankCard === null || !e.bank.includes(t.bankCard)) return { code: "games.faraway.errBadRefill" };
	} else if (t.bankCard !== null) return { code: "games.faraway.errBadRefill" };
	if (r.length > 0) {
		if (t.sanct === null || !r.includes(t.sanct)) return { code: "games.faraway.errBadRefill" };
	} else if (t.sanct !== null) return { code: "games.faraway.errBadRefill" };
	let i = structuredClone(e), a = [];
	return t.bankCard !== null && (i.bank = i.bank.filter((e) => e !== t.bankCard), i.hands[n.by] = [...i.hands[n.by], t.bankCard].sort((e, t) => e - t), a.push({
		kind: "takeBank",
		rid: n.by,
		data: { card: t.bankCard }
	})), t.sanct !== null && (i.pendingSanct[n.by] = i.pendingSanct[n.by].filter((e) => e !== t.sanct), i.sanctuaries[n.by] = [...i.sanctuaries[n.by], t.sanct], i.sanctDeck = [...i.pendingSanct[n.by], ...i.sanctDeck], i.pendingSanct[n.by] = [], a.push({
		kind: "keepSanct",
		rid: n.by,
		data: { count: r.length },
		for: [n.by],
		secret: { sanct: t.sanct }
	})), i.refillOrder = i.refillOrder.slice(1), i.refillTurn = i.refillOrder[0] ?? null, i.refillTurn === null && a.push(...se(i)), {
		state: i,
		fx: a
	};
}
function ce(e, t) {
	return {
		public: {
			phase: e.phase,
			round: e.round,
			advanced: e.advanced,
			bank: e.bank,
			deckLeft: e.regionDeck.length,
			players: e.players.map((t) => ({
				rid: t,
				tableau: e.tableaux[t],
				sanctuaries: e.sanctuaries[t],
				picked: t in e.selected,
				lastPlayed: e.lastPlayed[t],
				pendingCount: e.pendingSanct[t].length,
				fame: e.fame[t],
				sanctFame: e.sanctFame[t]
			})),
			refillOrder: e.refillOrder,
			refillTurn: e.refillTurn,
			scoringPos: e.scoringPos
		},
		private: {
			hand: e.hands[t] ?? [],
			mySelected: e.selected[t] ?? null,
			pendingSanct: e.pendingSanct[t] ?? []
		}
	};
}
function le(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => Math.min(...e.tableaux[t]), n = [...e.players].sort((n, r) => ie(e, r) - ie(e, n) || t(n) - t(r)), r = {};
	for (let t of e.players) r[t] = ie(e, t);
	return {
		phase: "done",
		winner: [n[0]],
		ranking: n,
		scores: r
	};
}
function ue(e) {
	return e.phase === "scoring" && e.scoringPos !== null && e.scoringPos <= 9 ? e.beatMs : null;
}
var de = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: E,
	schemas: {
		action: k,
		publicView: j,
		privateView: M,
		config: A
	},
	setup: ae,
	reduce: L,
	viewFor: ce,
	status: le,
	nextTickIn: ue
};
//#endregion
//#region src/games/faraway/icons.tsx
function R({ color: e, children: t, size: n }) {
	return /* @__PURE__ */ m("svg", {
		width: n,
		height: n,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		className: "flex-none",
		children: [/* @__PURE__ */ p("g", {
			stroke: "#fff",
			strokeWidth: 3.2,
			strokeLinejoin: "round",
			strokeLinecap: "round",
			fill: e,
			opacity: .95,
			children: t
		}), /* @__PURE__ */ p("g", {
			stroke: "#1c1917",
			strokeWidth: 1.4,
			strokeLinejoin: "round",
			strokeLinecap: "round",
			fill: e,
			children: t
		})]
	});
}
function fe({ size: e = 14 }) {
	return /* @__PURE__ */ p(R, {
		color: "#38bdf8",
		size: e,
		children: /* @__PURE__ */ p("path", { d: "M12 3 C15 8 18 10.5 18 14.5 a6 6 0 0 1 -12 0 C6 10.5 9 8 12 3 Z" })
	});
}
function pe({ size: e = 14 }) {
	return /* @__PURE__ */ p(R, {
		color: "#92400e",
		size: e,
		children: /* @__PURE__ */ p("path", { d: "M12 21 L9.5 13 C7 12 5.5 9.5 5.5 6 C5.5 4.5 6 3.5 6.8 3 C6.4 5.5 7.5 8 9.5 9.5 L10.5 6.5 C11 5.8 13 5.8 13.5 6.5 L14.5 9.5 C16.5 8 17.6 5.5 17.2 3 C18 3.5 18.5 4.5 18.5 6 C18.5 9.5 17 12 14.5 13 Z" })
	});
}
function me({ size: e = 14 }) {
	return /* @__PURE__ */ m(R, {
		color: "#4d7c0f",
		size: e,
		children: [/* @__PURE__ */ p("path", {
			d: "M12 21 L12 12 M12 12 L6.5 4.5 C8 4.2 9.5 4.8 10.5 6 L11 2.5 C11.8 2 12.2 2 13 2.5 L13.5 6 C14.5 4.8 16 4.2 17.5 4.5 L12 12 M12 12 L4 10 C4.8 11.8 6.5 12.8 8.5 12.8 M12 12 L20 10 C19.2 11.8 17.5 12.8 15.5 12.8",
			fill: "none"
		}), /* @__PURE__ */ p("circle", {
			cx: 12,
			cy: 12,
			r: 2.6
		})]
	});
}
function he({ size: e = 14 }) {
	return /* @__PURE__ */ m(R, {
		color: "#fbbf24",
		size: e,
		children: [
			/* @__PURE__ */ p("rect", {
				x: 3.5,
				y: 5.5,
				width: 17,
				height: 13,
				rx: 2
			}),
			/* @__PURE__ */ p("path", {
				d: "M8 9.5 L12 13.5 M12 9.5 L8 13.5",
				fill: "none"
			}),
			/* @__PURE__ */ p("path", {
				d: "M15 15.5 L18 15.5",
				fill: "none"
			})
		]
	});
}
var z = {
	uddu: fe,
	okiko: pe,
	goldlog: me
};
function ge({ size: e = 12 }) {
	return /* @__PURE__ */ m("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		className: "flex-none",
		children: [/* @__PURE__ */ p("g", {
			stroke: "#fff",
			strokeWidth: 3,
			strokeLinejoin: "round",
			children: /* @__PURE__ */ p("path", {
				d: "M12 2 L14 8 L20 6 L16.5 11 L22 13 L16 15 L17.5 21.5 L12 17.5 L6.5 21.5 L8 15 L2 13 L7.5 11 L4 6 L10 8 Z",
				fill: "#facc15"
			})
		}), /* @__PURE__ */ p("path", {
			d: "M12 2 L14 8 L20 6 L16.5 11 L22 13 L16 15 L17.5 21.5 L12 17.5 L6.5 21.5 L8 15 L2 13 L7.5 11 L4 6 L10 8 Z",
			fill: "#facc15",
			stroke: "#1c1917",
			strokeWidth: 1.4,
			strokeLinejoin: "round"
		})]
	});
}
function B({ size: e = 12 }) {
	return /* @__PURE__ */ m("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		className: "flex-none",
		children: [/* @__PURE__ */ p("path", {
			d: "M20 14.5 A9 9 0 1 1 9.5 4 A7.2 7.2 0 0 0 20 14.5 Z",
			fill: "#7dd3fc",
			stroke: "#fff",
			strokeWidth: 3,
			strokeLinejoin: "round"
		}), /* @__PURE__ */ p("path", {
			d: "M20 14.5 A9 9 0 1 1 9.5 4 A7.2 7.2 0 0 0 20 14.5 Z",
			fill: "#7dd3fc",
			stroke: "#1c1917",
			strokeWidth: 1.4,
			strokeLinejoin: "round"
		})]
	});
}
//#endregion
//#region src/games/faraway/card.tsx
var V = {
	forest: "#b91c1c",
	river: "#15803d",
	desert: "#0369a1",
	city: "#ca8a04"
};
function _e(e, t, n) {
	return `games/faraway/art/${e}-${t ? "night" : "day"}-${n % 2 + 1}.webp`;
}
function ve(e) {
	return e.biome ? _e(e.biome, !1, e.id) : `games/faraway/art/sanctuary-${e.id % 2 + 1}.webp`;
}
var H = {
	mini: "h-10 w-15 rounded-sm",
	journey: "h-16 w-24 rounded",
	bank: "h-18 w-27 rounded",
	hand: "h-24 w-36 rounded-md"
}, ye = {
	mini: "size-4 text-[9px]",
	journey: "size-5 text-[10px]",
	bank: "size-5.5 text-xs",
	hand: "size-7 text-sm"
}, U = {
	mini: 0,
	journey: 12,
	bank: 14,
	hand: 18
};
function be({ n: e, night: t, size: n }) {
	return /* @__PURE__ */ m("span", {
		className: "fw-number-area absolute top-[4%] left-[3%] flex items-center",
		children: [
			n !== "mini" && !t && /* @__PURE__ */ p(ge, { size: U[n] }),
			n === "mini" && !t && /* @__PURE__ */ p("span", {
				className: "fw-mini-detail hidden",
				children: /* @__PURE__ */ p(ge, { size: 12 })
			}),
			/* @__PURE__ */ p("span", {
				className: `fw-number grid place-items-center rounded-full border-2 border-ink font-display font-black text-ink tabular-nums ${ye[n]} ${t ? "bg-sky-200" : "bg-amber-100"}`,
				children: e
			}),
			n !== "mini" && t && /* @__PURE__ */ p(B, { size: U[n] }),
			n === "mini" && t && /* @__PURE__ */ p("span", {
				className: "fw-mini-detail hidden",
				children: /* @__PURE__ */ p(B, { size: 12 })
			})
		]
	});
}
function xe({ clues: e, symbols: t, size: n }) {
	let r = U[n] || 12;
	return /* @__PURE__ */ m("span", {
		className: `fw-corner-icons absolute top-[4%] right-[3%] items-center gap-px ${n === "mini" ? "fw-mini-detail hidden" : "flex"}`,
		children: [Array.from({ length: e }, (e, t) => /* @__PURE__ */ p(he, { size: r }, `c${t}`)), t.map((e, t) => {
			let n = z[e];
			return /* @__PURE__ */ p(n, { size: r }, `${e}${t}`);
		})]
	});
}
function Se({ quest: e, iconSize: t = 14 }) {
	let n, r;
	switch (e.kind) {
		case "flat":
			n = /* @__PURE__ */ p("span", {
				style: { fontSize: `var(--fw-icon, ${t}px)` },
				children: "★"
			}), r = String(e.points ?? 0);
			break;
		case "perClue":
			n = /* @__PURE__ */ p(he, { size: t }), r = `×${e.per}`;
			break;
		case "perNight":
			n = /* @__PURE__ */ p(B, { size: t }), r = `×${e.per}`;
			break;
		case "perSymbol":
			n = (() => {
				let n = z[e.symbol ?? "uddu"];
				return /* @__PURE__ */ p(n, { size: t });
			})(), r = `×${e.per}`;
			break;
		case "perFourSet":
			n = /* @__PURE__ */ p("span", {
				className: "flex flex-none items-center gap-px",
				children: Object.keys(V).map((e) => /* @__PURE__ */ p("span", {
					className: "inline-block flex-none rounded-[2px] border border-ink/60",
					style: {
						width: `var(--fw-biome-size, ${t - 4}px)`,
						height: `var(--fw-biome-size, ${t - 4}px)`,
						backgroundColor: V[e]
					}
				}, e))
			}), r = `×${e.per}`;
			break;
		case "perBiome": n = /* @__PURE__ */ p("span", {
			className: "flex flex-none items-center gap-px",
			children: (e.biomes ?? []).map((e, n) => /* @__PURE__ */ m("span", {
				className: "flex flex-none items-center gap-px",
				children: [n > 0 && /* @__PURE__ */ p("span", {
					className: "font-black text-ink/60",
					style: { fontSize: `var(--fw-quest-separator, ${t - 3}px)` },
					children: "/"
				}), /* @__PURE__ */ p("span", {
					className: "inline-block flex-none rounded-[2px] border border-ink/60",
					style: {
						width: `var(--fw-biome-size, ${t - 4}px)`,
						height: `var(--fw-biome-size, ${t - 4}px)`,
						backgroundColor: V[e]
					}
				})]
			}, e))
		}), r = `×${e.per}`;
	}
	let i = e.prereq ? Object.entries(e.prereq).flatMap(([e, n]) => Array.from({ length: n ?? 0 }, (n, r) => {
		let i = z[e];
		return /* @__PURE__ */ p(i, { size: t - 3 }, `${e}${r}`);
	})) : null;
	return /* @__PURE__ */ m("span", {
		className: "fw-quest flex items-center gap-0.5 leading-none whitespace-nowrap",
		children: [
			i && i.length > 0 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", {
				className: "fw-quest-prereq flex flex-none items-center gap-px rounded-sm border border-dashed border-ink/50 px-0.5",
				children: i
			}), /* @__PURE__ */ p("span", {
				"aria-hidden": !0,
				className: "flex-none font-black text-ink/50",
				style: { fontSize: `var(--fw-quest-arrow, ${t - 2}px)` },
				children: "▸"
			})] }),
			n,
			/* @__PURE__ */ p("b", {
				className: "flex-none font-mono tabular-nums",
				style: { fontSize: `var(--fw-quest-value, ${t + 1}px)` },
				children: r
			})
		]
	});
}
function Ce({ color: e, quest: t, size: n }) {
	let r = U[n] || 12;
	return /* @__PURE__ */ p("span", {
		className: "fw-biome-band absolute inset-x-0 bottom-0 flex items-center justify-center border-t-2 border-ink/40",
		style: {
			height: "27%",
			backgroundColor: e,
			backgroundImage: "repeating-linear-gradient(45deg, rgb(0 0 0 / 0.08) 0 4px, transparent 4px 9px)"
		},
		children: t && /* @__PURE__ */ p("span", {
			className: `fw-task-plate rounded-sm bg-amber-50/95 px-1 py-0.5 shadow-[1px_1px_0_var(--color-ink)] ${n === "mini" ? "fw-mini-detail hidden" : ""}`,
			children: /* @__PURE__ */ p(Se, {
				quest: t,
				iconSize: r
			})
		})
	});
}
function W({ id: e, size: t, faceDown: n }) {
	let r = C.get(e);
	return n ? /* @__PURE__ */ p(G, { size: t }) : /* @__PURE__ */ m("span", {
		"data-fw-size": t,
		className: `fw-card relative inline-block flex-none overflow-hidden border-2 border-ink bg-ink/10 select-none ${H[t]}`,
		children: [
			/* @__PURE__ */ p("img", {
				src: _e(r.biome, r.night, e),
				alt: "",
				draggable: !1,
				className: "absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ p(be, {
				n: r.id,
				night: r.night,
				size: t
			}),
			/* @__PURE__ */ p(xe, {
				clues: r.clues,
				symbols: r.symbols,
				size: t
			}),
			/* @__PURE__ */ p(Ce, {
				color: V[r.biome],
				quest: r.quest,
				size: t
			})
		]
	});
}
function G({ size: e }) {
	return /* @__PURE__ */ p("span", {
		"data-fw-size": e,
		className: `fw-card relative inline-block flex-none overflow-hidden border-2 border-ink select-none ${H[e]}`,
		style: {
			backgroundColor: E.accent,
			backgroundImage: "repeating-linear-gradient(45deg, rgb(0 0 0 / 0.1) 0 6px, transparent 6px 14px)"
		},
		children: /* @__PURE__ */ m("svg", {
			viewBox: "0 0 24 24",
			className: "absolute inset-0 m-auto size-3/5 text-white/90",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 1.6,
			strokeLinejoin: "round",
			children: [/* @__PURE__ */ p("circle", {
				cx: 12,
				cy: 12,
				r: 9
			}), /* @__PURE__ */ p("path", {
				d: "M12 5 L14 10 L19 12 L14 14 L12 19 L10 14 L5 12 L10 10 Z",
				fill: "currentColor",
				stroke: "none"
			})]
		})
	});
}
function K({ id: e, size: t }) {
	let n = w.get(e), r = {
		mini: "mini",
		mid: "bank",
		hand: "hand"
	}[t], i = U[r] || 12;
	return /* @__PURE__ */ m("span", {
		"data-fw-size": r,
		className: `fw-card relative inline-block flex-none overflow-hidden border-2 border-ink select-none ${H[r]}`,
		children: [
			/* @__PURE__ */ p("img", {
				src: ve(n),
				alt: "",
				draggable: !1,
				className: "absolute inset-0 size-full object-cover"
			}),
			i > 0 && /* @__PURE__ */ m("span", {
				className: `fw-corner-icons absolute top-[4%] right-[3%] items-center gap-px ${r === "mini" ? "fw-mini-detail hidden" : "flex"}`,
				children: [
					n.night && /* @__PURE__ */ p(B, { size: i }),
					Array.from({ length: n.clues }, (e, t) => /* @__PURE__ */ p(he, { size: i }, `c${t}`)),
					n.symbols.map((e, t) => {
						let n = z[e];
						return /* @__PURE__ */ p(n, { size: i }, `${e}${t}`);
					})
				]
			}),
			/* @__PURE__ */ p(Ce, {
				color: n.biome ? V[n.biome] : "#78716c",
				quest: n.quest,
				size: r
			})
		]
	});
}
//#endregion
//#region src/games/faraway/view-player.tsx
var we = {
	2: "fw-count-2",
	3: "fw-count-3",
	4: "fw-count-4",
	5: "fw-count-5",
	6: "fw-count-6"
};
function Te(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(De, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ee(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return !n || e.phase !== "scoring" && e.phase !== "done" ? null : n.fame.reduce((e, t) => e + (t ?? 0), 0) + (n.sanctFame ?? 0);
}
function De({ pub: e, priv: t, members: a, myRid: u, send: d }) {
	let h = o(), g = (e) => a.find((t) => t.rid === e)?.name ?? e, { ref: _ } = r("table"), v = e.players.find((e) => e.rid === u), y = e.phase === "refill" && e.refillTurn === u, b = t?.pendingSanct ?? [], [x, S] = n(null), [C, w] = n(null), [T, ee] = n([]), D = `${e.phase}:${e.round}:${e.refillTurn ?? ""}`, [O, te] = n(D);
	O !== D && (te(D), S(null), w(null), ee([]));
	let k, A;
	if (e.phase === "draft") {
		let e = t ? t.hand.length <= 3 : !1;
		k = e ? "info" : "accent", A = h(e ? "games.faraway.draftWaiting" : "games.faraway.draftPrompt");
	} else if (e.phase === "explore") {
		let e = v?.picked ?? !1;
		k = e ? "info" : "accent", A = h(e ? "games.faraway.waitingPick" : "games.faraway.explorePrompt");
	} else e.phase === "refill" ? (k = y ? "accent" : "info", A = y ? e.round >= 8 ? h("games.faraway.refillSanctOnly") : b.length > 0 ? h("games.faraway.refillPromptSanct") : h("games.faraway.refillPrompt") : h("games.faraway.refillWaiting", { name: g(e.refillTurn ?? "") })) : (k = "warn", A = h("games.faraway.scoring"));
	let ne = y && e.round < 8, j = y && b.length > 0, M = e.phase === "scoring" || e.phase === "done", N = a.find((e) => e.rid === u), re = (t) => {
		if (e.phase === "explore") {
			let n = e.players.find((e) => e.rid === t);
			return n ? n.picked ? "done" : "pending" : null;
		}
		return e.phase === "refill" && t === e.refillTurn ? "pending" : null;
	}, P = (t) => {
		let n = Ee(e, t.rid);
		return /* @__PURE__ */ m(f, { children: [t.pendingCount > 0 && /* @__PURE__ */ m("span", {
			title: h("games.faraway.pendingSanct"),
			children: ["🛖×", t.pendingCount]
		}), n !== null && /* @__PURE__ */ m("span", {
			className: "flex items-center gap-0.5",
			children: ["⭐", /* @__PURE__ */ p(i, {
				value: n,
				className: "font-mono tabular-nums"
			})]
		})] });
	}, ie = (e) => {
		if (x === e) return S(null);
		S(e), (!j || C !== null) && d({
			type: "refill",
			bankCard: e,
			sanct: j ? C : null
		});
	}, ae = (e) => {
		if (C === e) return w(null);
		w(e), (!ne || x !== null) && d({
			type: "refill",
			bankCard: ne ? x : null,
			sanct: e
		});
	}, oe = (e, t, n) => /* @__PURE__ */ p("button", {
		type: "button",
		disabled: t,
		onClick: e,
		className: "fw-confirm btn-base sticky right-0 flex-none self-center min-h-12 px-5",
		children: n
	}), F = null, se = null, I = "waiting", L = 1;
	return t && e.phase === "draft" && t.hand.length > 3 ? (I = "draft", L = t.hand.length, se = oe(() => d({
		type: "draft",
		keep: T
	}), T.length !== 3, h("games.faraway.draftConfirm", { n: T.length })), F = /* @__PURE__ */ p(f, { children: t.hand.map((e) => /* @__PURE__ */ p("button", {
		type: "button",
		"aria-pressed": T.includes(e),
		onClick: () => ee((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length < 3 ? [...t, e] : t),
		className: `flex-none transition-transform ${T.includes(e) ? "-translate-y-1.5" : "opacity-60"}`,
		children: /* @__PURE__ */ p(W, {
			id: e,
			size: "hand"
		})
	}, e)) })) : t && e.phase === "explore" ? (I = "explore", L = 3, F = /* @__PURE__ */ m(f, { children: [v?.picked && t.mySelected !== null && /* @__PURE__ */ p(W, {
		id: t.mySelected,
		size: "hand"
	}), t.hand.map((e) => /* @__PURE__ */ p("button", {
		type: "button",
		disabled: v?.picked,
		"aria-label": h("games.faraway.playCardAria", { n: e }),
		onClick: () => d({
			type: "explore",
			card: e
		}),
		className: "flex-none transition-transform active:translate-y-0.5 disabled:opacity-40",
		children: /* @__PURE__ */ p(je, {
			id: e,
			size: "hand"
		})
	}, e))] })) : t && y ? (I = j ? "sanct" : "waiting", L = Math.max(1, b.length), F = /* @__PURE__ */ p(f, { children: j ? b.map((e) => /* @__PURE__ */ p("button", {
		type: "button",
		"aria-label": h("games.faraway.keepSanctAria"),
		onClick: () => ae(e),
		className: `flex-none self-center rounded-md transition-transform ${C === e ? "-translate-y-1 ring-3 ring-ink" : ""}`,
		children: /* @__PURE__ */ p(Me, {
			id: e,
			size: "mid"
		})
	}, e)) : /* @__PURE__ */ p("span", {
		className: "self-center px-2 text-xs whitespace-nowrap text-ink/50",
		children: h("games.faraway.refillPrompt")
	}) })) : t && (e.phase === "draft" || e.phase === "refill") && (L = 3, F = t.hand.map((e) => /* @__PURE__ */ p(je, {
		id: e,
		size: "hand"
	}, e))), /* @__PURE__ */ p(c, {
		adaptive: !0,
		className: `fw-view ${we[e.players.length]}${e.phase === "draft" ? " fw-draft" : ""}${M ? " fw-scoring" : ""}`,
		banner: /* @__PURE__ */ p(l, {
			tone: k,
			text: A,
			chip: M ? void 0 : h("games.faraway.roundShort", {
				n: e.round,
				total: 8
			}),
			accent: E.accent
		}),
		actionsHeight: "h-28",
		actions: F && /* @__PURE__ */ m("div", {
			className: "fw-actions scrollbar-none flex h-full items-start gap-2 overflow-x-auto overflow-y-hidden px-2 pt-2 pb-1.5",
			"data-fw-kind": I,
			style: { "--fw-choice-count": L },
			children: [/* @__PURE__ */ p("div", {
				className: "fw-action-cards",
				children: F
			}), se]
		}),
		scroll: !1,
		children: /* @__PURE__ */ m("div", {
			ref: _,
			className: "fw-table frame relative flex h-full flex-col overflow-hidden p-2",
			style: {
				"--fw-player-count": e.players.length,
				"--fw-bank-count": e.players.length + 1
			},
			children: [/* @__PURE__ */ p(s, {
				kind: "sheen",
				base: "var(--color-surface)",
				className: "absolute inset-0"
			}), /* @__PURE__ */ m("div", {
				className: "fw-table-content relative flex h-full flex-col gap-2",
				children: [
					/* @__PURE__ */ m("div", {
						className: "fw-players",
						children: [/* @__PURE__ */ p("div", {
							className: "fw-opponents scrollbar-none flex max-h-[42%] flex-none flex-col gap-1.5 overflow-y-auto pt-2 pl-2",
							children: e.players.filter((e) => e.rid !== u).map((e) => {
								let t = a.find((t) => t.rid === e.rid);
								return /* @__PURE__ */ m("div", {
									className: "fw-player-row flex items-center gap-1.5",
									children: [/* @__PURE__ */ m("div", {
										className: "fw-player-core fw-opponent-core",
										children: [t && /* @__PURE__ */ p(Oe, {
											m: t,
											myRid: u,
											action: re(e.rid),
											status: P(e)
										}), /* @__PURE__ */ p(ke, {
											rid: e.rid,
											tableau: e.tableau,
											fame: e.fame,
											scoring: M
										})]
									}), e.sanctuaries.length > 0 && /* @__PURE__ */ p("span", {
										className: "fw-sanct-row flex flex-none items-center gap-0.5",
										children: e.sanctuaries.map((e) => /* @__PURE__ */ p(K, {
											id: e,
											size: "mini"
										}, e))
									})]
								}, e.rid);
							})
						}), v && /* @__PURE__ */ m("div", {
							className: "fw-self fw-player-row flex flex-col items-center gap-1",
							children: [
								/* @__PURE__ */ p("div", {
									className: "fw-journey-label section-label",
									children: h("games.faraway.myJourney")
								}),
								/* @__PURE__ */ m("div", {
									className: "fw-player-core flex w-full items-center gap-1.5 pl-2",
									children: [N && /* @__PURE__ */ p(Oe, {
										m: N,
										myRid: u,
										action: re(u),
										status: P(v)
									}), /* @__PURE__ */ p(ke, {
										rid: u,
										tableau: v.tableau,
										fame: v.fame,
										scoring: M
									})]
								}),
								v.sanctuaries.length > 0 && /* @__PURE__ */ p("div", {
									className: "fw-sanct-row mt-1 flex items-center gap-1.5 self-end",
									children: v.sanctuaries.map((e) => /* @__PURE__ */ p(Me, {
										id: e,
										size: "mini"
									}, e))
								})
							]
						})]
					}),
					/* @__PURE__ */ p("div", { className: "fw-space-top flex-1" }),
					/* @__PURE__ */ m("div", {
						className: "fw-bank flex flex-none flex-col items-center gap-1",
						children: [/* @__PURE__ */ p("div", {
							className: "fw-bank-label section-label",
							children: h("games.faraway.bankLabel")
						}), /* @__PURE__ */ m("div", {
							className: "fw-bank-cards scrollbar-none flex max-w-full items-center gap-2 overflow-x-auto overflow-y-hidden px-1 pt-2 pb-1",
							children: [e.bank.map((e) => /* @__PURE__ */ p(Ae, {
								id: e,
								tappable: y && ne,
								selected: x === e,
								onPick: () => ie(e)
							}, e)), e.bank.length === 0 && /* @__PURE__ */ p("span", {
								className: "fw-empty text-xs whitespace-nowrap text-ink/50",
								children: h("games.faraway.bankEmpty")
							})]
						})]
					}),
					M && /* @__PURE__ */ p(Ne, {
						pub: e,
						nameOf: g
					}),
					/* @__PURE__ */ p("div", { className: "fw-space-bottom flex-1" })
				]
			})]
		})
	});
}
function Oe({ m: e, myRid: t, action: n, status: r }) {
	let i = a((e) => e.locale);
	return /* @__PURE__ */ m("div", {
		className: "fw-seat flex w-12 flex-none flex-col items-center",
		children: [
			/* @__PURE__ */ p(u, {
				m: e,
				myRid: t,
				action: n,
				anchorName: `seat:${e.rid}`,
				box: "fw-seat-avatar size-8",
				img: "fw-seat-image size-6"
			}),
			/* @__PURE__ */ p("span", {
				className: "fw-seat-name z-10 -mt-2 max-w-full truncate rounded-full border-2 border-ink bg-surface px-1 text-[10px] leading-4 font-bold shadow-[1px_1px_0_var(--color-ink)]",
				children: d(e, i)
			}),
			/* @__PURE__ */ p("span", {
				className: "fw-seat-status mt-0.5 flex min-h-4 items-center gap-0.5 text-[10px] leading-4 font-bold",
				children: r
			})
		]
	});
}
function ke({ rid: e, tableau: t, fame: n, scoring: i }) {
	let { ref: a } = r(`journey:${e}`);
	return /* @__PURE__ */ p("div", {
		ref: a,
		className: "fw-journey scrollbar-none flex max-w-full items-center overflow-x-auto overflow-y-hidden rounded-md border-2 border-ink bg-ink/10 pb-1",
		children: Array.from({ length: 8 }, (e, r) => {
			let a = t[r], o = i && a !== void 0 && n[r] === null;
			return /* @__PURE__ */ m("span", {
				className: "relative flex-none",
				children: [a === void 0 ? /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					"data-fw-size": "journey",
					className: `fw-card block border-r border-dashed border-ink/30 last:border-r-0 ${H.journey}`
				}) : /* @__PURE__ */ p(je, {
					id: a,
					size: "journey",
					faceDown: o,
					bare: !0
				}), i && a !== void 0 && n[r] !== null && /* @__PURE__ */ m("span", {
					className: "fw-fame absolute -right-1 -bottom-1 z-10 rounded-md border-2 border-ink bg-surface px-0.5 font-mono text-[10px] font-black tabular-nums",
					children: ["+", n[r]]
				})]
			}, r);
		})
	});
}
function Ae({ id: e, tappable: t, selected: n, onPick: r }) {
	let i = o();
	return /* @__PURE__ */ p("button", {
		type: "button",
		disabled: !t,
		"aria-label": t ? i("games.faraway.takeBankAria", { n: e }) : void 0,
		onClick: r,
		className: `flex-none rounded shadow-[2px_2px_0_var(--color-ink)] transition-transform ${t ? "active:translate-y-0.5" : ""} ${n ? "-translate-y-1.5 ring-3 ring-ink" : ""}`,
		children: /* @__PURE__ */ p(je, {
			id: e,
			size: "bank"
		})
	});
}
function je({ id: e, size: t, faceDown: n, bare: i }) {
	let { ref: a, hidden: o } = r(`card:${e}`);
	return /* @__PURE__ */ p("span", {
		ref: a,
		className: `inline-flex ${i ? "[&>span]:rounded-none [&>span]:border-0" : "shadow-[2px_2px_0_var(--color-ink)]"}`,
		style: { visibility: o ? "hidden" : void 0 },
		children: /* @__PURE__ */ p(W, {
			id: e,
			size: t,
			faceDown: n
		})
	});
}
function Me({ id: e, size: t }) {
	let { ref: n, hidden: i } = r(`sanct:${e}`);
	return /* @__PURE__ */ p("span", {
		ref: n,
		className: "inline-flex shadow-[2px_2px_0_var(--color-ink)]",
		style: { visibility: i ? "hidden" : void 0 },
		children: /* @__PURE__ */ p(K, {
			id: e,
			size: t
		})
	});
}
function Ne({ pub: e, nameOf: t }) {
	let n = o(), r = e.scoringPos ?? 0, a = 8 - r, s = r > 8;
	return /* @__PURE__ */ p("div", {
		className: "fw-score-recap scrollbar-none",
		children: e.players.map((r) => {
			let o = a >= 0 && a < 8 ? r.tableau[a] : void 0, c = s ? r.sanctFame : r.fame[a], l = o !== void 0 && c != null;
			return /* @__PURE__ */ p("section", {
				className: "fw-score-player frame",
				"data-fw-score-empty": s && r.sanctuaries.length === 0 ? "true" : void 0,
				children: /* @__PURE__ */ m("div", {
					className: "fw-score-content",
					children: [
						/* @__PURE__ */ m("header", {
							className: "fw-score-header",
							children: [/* @__PURE__ */ p("span", {
								className: "fw-score-name",
								children: t(r.rid)
							}), /* @__PURE__ */ m("span", {
								className: "fw-score-total",
								children: ["⭐", /* @__PURE__ */ p(i, { value: Ee(e, r.rid) ?? 0 })]
							})]
						}),
						/* @__PURE__ */ p("div", {
							className: "fw-score-face",
							children: s ? /* @__PURE__ */ p("div", {
								className: "fw-score-sancts",
								"aria-label": n("games.faraway.mySancts"),
								style: { "--fw-score-sanct-count": r.sanctuaries.length },
								children: r.sanctuaries.map((e) => /* @__PURE__ */ p("span", {
									className: "fw-score-sanct-card",
									children: /* @__PURE__ */ p(K, {
										id: e,
										size: "mid"
									})
								}, e))
							}) : l ? /* @__PURE__ */ p(W, {
								id: o,
								size: "journey"
							}) : /* @__PURE__ */ p(W, {
								id: o ?? r.tableau[0],
								size: "journey",
								faceDown: !0
							})
						}),
						/* @__PURE__ */ p("span", {
							className: "fw-score-gain",
							children: c == null ? "—" : "+" + c
						})
					]
				})
			}, r.rid);
		})
	});
}
//#endregion
//#region src/games/faraway/bot.ts
function Pe(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var q = (() => {
	let e = T(x, []), t = x.length;
	return {
		symbols: {
			uddu: e.symbols.uddu / t,
			okiko: e.symbols.okiko / t,
			goldlog: e.symbols.goldlog / t
		},
		biomes: {
			desert: e.biomes.desert / t,
			forest: e.biomes.forest / t,
			river: e.biomes.river / t,
			city: e.biomes.city / t
		},
		nights: e.nights / t,
		clues: e.clues / t
	};
})();
function Fe(e, t, n = 1) {
	let r = {
		symbols: { ...e.symbols },
		biomes: { ...e.biomes },
		nights: e.nights,
		clues: e.clues
	};
	t.biome && (r.biomes[t.biome] += n), t.night && (r.nights += n), r.clues += t.clues * n;
	for (let e of t.symbols) r.symbols[e] += n;
	return r;
}
function J(e, t) {
	return t <= 0 ? e : {
		symbols: {
			uddu: e.symbols.uddu + q.symbols.uddu * t,
			okiko: e.symbols.okiko + q.symbols.okiko * t,
			goldlog: e.symbols.goldlog + q.symbols.goldlog * t
		},
		biomes: {
			desert: e.biomes.desert + q.biomes.desert * t,
			forest: e.biomes.forest + q.biomes.forest * t,
			river: e.biomes.river + q.biomes.river * t,
			city: e.biomes.city + q.biomes.city * t
		},
		nights: e.nights + q.nights * t,
		clues: e.clues + q.clues * t
	};
}
function Y(e, t) {
	if (!e) return 0;
	let n = 1;
	if (e.prereq) for (let [r, i] of Object.entries(e.prereq)) i && (n = Math.min(n, Math.min(1, t.symbols[r] / i)));
	let r = 0;
	switch (e.kind) {
		case "flat":
			r = e.points ?? 0;
			break;
		case "perClue":
			r = (e.per ?? 0) * t.clues;
			break;
		case "perNight":
			r = (e.per ?? 0) * t.nights;
			break;
		case "perSymbol":
			r = (e.per ?? 0) * t.symbols[e.symbol ?? "uddu"];
			break;
		case "perFourSet":
			r = (e.per ?? 0) * Math.min(t.biomes.desert, t.biomes.forest, t.biomes.river, t.biomes.city);
			break;
		case "perBiome": {
			let n = e.biomes ?? [];
			n.length === 1 ? r = (e.per ?? 0) * t.biomes[n[0]] : n.length === 2 && (r = (e.per ?? 0) * Math.min(t.biomes[n[0]], t.biomes[n[1]]));
			break;
		}
	}
	return n * r;
}
function Ie(e) {
	return e.quest ? e.quest.points ?? (e.quest.per ?? 0) * 4 : 0;
}
var Le = (e, t) => {
	let n = e.public, r = e.private, i = r?.hand ?? [], a = n.players.find((e) => e.rid === t.rid), o = t.difficulty === "weak";
	if (n.phase === "draft") {
		if (i.length !== 5) return null;
		if (o) {
			let e = [...i], t = [];
			for (; t.length < 3;) {
				let n = Pe(e);
				t.push(n), e.splice(e.indexOf(n), 1);
			}
			return { action: {
				type: "draft",
				keep: t
			} };
		}
		let e = null, t = -Infinity;
		for (let n = 0; n < 5; n++) for (let r = n + 1; r < 5; r++) for (let a = r + 1; a < 5; a++) {
			let o = [...[
				i[n],
				i[r],
				i[a]
			].map((e) => C.get(e))].sort((e, t) => Ie(t) - Ie(e)), s = 0;
			for (let e = 0; e < 3; e++) s += Y(o[e].quest, J(T(o.slice(e), []), 5));
			for (let e = 0; e < 2; e++) o[e + 1].id > o[e].id && (s += .5);
			s > t && (t = s, e = [
				i[n],
				i[r],
				i[a]
			]);
		}
		return { action: {
			type: "draft",
			keep: e
		} };
	}
	if (!a) return null;
	let s = a.tableau.map((e) => C.get(e)), c = a.sanctuaries.map((e) => w.get(e)), l = r?.pendingSanct ?? [], u = 7 - s.length, d = (e) => {
		let t = [];
		for (let n = 0; n < s.length; n++) {
			let r = s[n].quest;
			r && t.push({
				q: r,
				pool: J(T(s.slice(n), e), u)
			});
		}
		let n = J(T(s, e), u);
		for (let r of e) r.quest && t.push({
			q: r.quest,
			pool: n
		});
		return t;
	}, f = (e, t) => {
		let n = 0;
		for (let r of d(t)) n += Y(r.q, Fe(r.pool, e)) - Y(r.q, r.pool);
		return n;
	}, p = (e, t) => {
		let n = Fe(J(T(s, t), u), e);
		return Y(e.quest, n) + f(e, t);
	}, m = l.length > 0 ? l.map((e) => w.get(e)).sort((e, t) => p(t, c) - p(e, c))[0] : null, h = m ? [...c, m] : c, g = (e) => {
		let t = C.get(e);
		return Y(t.quest, J(T([t], h), u)) + f(t, h) + (68 - e) / 68 * 1.5;
	};
	if (n.phase === "explore") {
		if (a.picked || i.length === 0) return null;
		if (o) return { action: {
			type: "explore",
			card: Pe(i)
		} };
		let e = n.bank.map(g).sort((e, t) => t - e), t = s.length > 0 ? s[s.length - 1].id : null, r = s.reduce((e, t) => e + t.clues, 0) + c.reduce((e, t) => e + t.clues, 0), d = /* @__PURE__ */ new Set([...a.sanctuaries, ...l]), m = S.filter((e) => !d.has(e.id)).map((e) => p(e, c)).sort((e, t) => t - e), _ = i[0], v = -Infinity;
		for (let a of i) {
			let i = C.get(a), o = f(i, h);
			if (o += Y(i.quest, J(T([i], h), u)), t !== null && a > t && m.length > 0) {
				let e = 1 + r + i.clues, t = Math.min(m.length - 1, Math.floor(m.length / (e + 1)));
				o += m[t];
			}
			if (n.round < 8 && e.length > 0) {
				let t = Math.min(e.length - 1, Math.round((n.players.length - 1) * (a / 69)));
				o += .8 * e[t];
			}
			o > v && (v = o, _ = a);
		}
		return { action: {
			type: "explore",
			card: _
		} };
	}
	return n.phase === "refill" && n.refillTurn === t.rid ? { action: {
		type: "refill",
		bankCard: n.round < 8 ? o ? Pe(n.bank) : [...n.bank].sort((e, t) => g(t) - g(e))[0] : null,
		sanct: l.length > 0 ? o ? Pe(l) : [...l].sort((e, t) => p(w.get(t), c) - p(w.get(e), c))[0] : null
	} } : null;
}, Re = (e, t, n) => {
	if (e.type === "draft") {
		let [t, r, i] = [...e.keep].sort((e, t) => e - t);
		return n("games.faraway.hintDraft", {
			a: t,
			b: r,
			c: i
		});
	}
	return e.type === "explore" ? n("games.faraway.playCardAria", { n: e.card }) : e.type === "refill" ? e.bankCard !== null && e.sanct !== null ? n("games.faraway.hintRefillBoth", { n: e.bankCard }) : e.bankCard === null ? e.sanct === null ? "" : n("games.faraway.keepSanctAria") : n("games.faraway.takeBankAria", { n: e.bankCard }) : "";
}, ze = {
	desert: "沙漠",
	forest: "森林",
	river: "河流",
	city: "城市"
}, Be = {
	uddu: "乌杜石",
	okiko: "奇美拉",
	goldlog: "金蓟"
}, Ve = (e) => {
	if (!e) return "无任务";
	let t = e.prereq ? `(前置:场上凑齐 ${Object.entries(e.prereq).map(([e, t]) => `${Be[e]}×${t}`).join("+")} 才得分)` : "";
	switch (e.kind) {
		case "perClue": return `每条线索 ${e.per} 分${t}`;
		case "perSymbol": return `每个${Be[e.symbol]} ${e.per} 分${t}`;
		case "perBiome": {
			let n = e.biomes ?? [];
			return n.length === 2 ? `每对(${n.map((e) => ze[e]).join("+")}) ${e.per} 分${t}` : `每个${ze[n[0]]} ${e.per} 分${t}`;
		}
		case "perFourSet": return `每凑齐四群系各一 ${e.per} 分${t}`;
		case "perNight": return `每张夜晚卡 ${e.per} 分${t}`;
		case "flat": return `固定 ${e.points} 分${t}`;
	}
}, He = (e) => {
	let t = C.get(e);
	return t ? `#${e}(${ze[t.biome]}${t.night ? "·夜" : ""}${t.clues ? `·线索${t.clues}` : ""}${t.symbols.length ? `·${t.symbols.map((e) => Be[e]).join("+")}` : ""}${t.quest ? `;任务:${Ve(t.quest)}` : ""})` : `#${e}`;
}, Ue = (e) => {
	let t = w.get(e);
	return t ? `S${e}(${t.biome ? `${ze[t.biome]}·` : ""}${t.night ? "夜·" : ""}${t.clues ? `线索${t.clues}·` : ""}${t.symbols.map((e) => Be[e]).join("+")}${t.quest ? `;任务:${Ve(t.quest)}` : ""})` : `S${e}`;
}, We = {
	needsAction(e, t) {
		let n = e.public;
		if (n.phase === "draft") return (e.private?.hand.length ?? 0) > 3;
		if (n.phase === "explore") {
			let r = n.players.find((e) => e.rid === t.rid);
			return !!r && !r.picked && (e.private?.hand.length ?? 0) > 0;
		}
		return n.phase === "refill" && n.refillTurn === t.rid;
	},
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.round}/8 轮。核心规则:每轮全员暗选 1 张打到旅程行右端;打出的探索时长(卡号)比你上一轮大就能找到圣所(抽 1 张,旅程行上每条线索多抽 1 张)。终局回程从右往左逐张翻开计分:每张卡只对「它右边已翻开的卡 + 全部圣所」结算——所以越靠左(越早打出)的卡统计范围越大。同分比旅程中最小时长,小者胜。`];
		for (let e of n.players) {
			let n = e.rid === t.rid ? "你" : e.rid;
			r.push(`${n} 旅程(左→右): ${e.tableau.map(He).join(" → ") || "(空)"}${e.sanctuaries.length ? `;圣所: ${e.sanctuaries.map(Ue).join(" ")}` : ""}`);
		}
		return n.phase === "draft" ? r.push(`开局 5 留 3:你的手牌 ${e.private?.hand.map(He).join(" ")}。输出 draft(keep=留下的 3 张 id)。`) : n.phase === "explore" ? r.push(`你的手牌: ${e.private?.hand.map(He).join(" ")}。暗选一张打出,输出 explore(card=id)。`) : n.phase === "refill" && n.refillTurn === t.rid && (r.push(`银行: ${n.bank.map(He).join(" ") || "(空)"}`), r.push(`待选圣所: ${(e.private?.pendingSanct ?? []).map(Ue).join(" ") || "(无)"}`), r.push("输出 refill:bankCard=从银行拿一张回手(第 8 轮拿不了填 null),sanct=从待选圣所留一张进场(无待选填 null)。")), r.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: {
				type: { const: "draft" },
				keep: {
					type: "array",
					items: {
						type: "integer",
						minimum: 1,
						maximum: 68
					},
					minItems: 3,
					maxItems: 3
				}
			},
			required: ["type", "keep"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "explore" },
				card: {
					type: "integer",
					minimum: 1,
					maximum: 68
				}
			},
			required: ["type", "card"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "refill" },
				bankCard: {
					type: ["integer", "null"],
					description: "银行卡 id 或 null"
				},
				sanct: {
					type: ["integer", "null"],
					description: "待选圣所 id 或 null"
				}
			},
			required: [
				"type",
				"bankCard",
				"sanct"
			],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = k.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public, o = t.private?.hand ?? [];
		return i.type === "draft" ? a.phase !== "draft" || o.length <= 3 ? null : new Set(i.keep).size === 3 && i.keep.every((e) => o.includes(e)) ? i : null : i.type === "explore" ? a.phase === "explore" && o.includes(i.card) ? i : null : a.phase !== "refill" || a.refillTurn !== n.rid || i.bankCard != null && !a.bank.includes(i.bankCard) || i.sanct != null && !(t.private?.pendingSanct ?? []).includes(i.sanct) ? null : i;
	}
}, Ge = 68, Ke = 96;
function X(e, t = Ge, n = Ke) {
	let r = e.anchor("table");
	return r ? {
		x: r.x + r.w / 2 - t / 2,
		y: r.y + r.h / 2 - n / 2,
		w: t,
		h: n
	} : null;
}
function Z(e, t) {
	return (t ? e.anchor(`seat:${t}`) : null) ?? X(e);
}
function Q({ width: e, baseWidth: t, children: n }) {
	return /* @__PURE__ */ p("span", {
		style: {
			display: "block",
			width: e,
			height: e / 1.5,
			lineHeight: 0
		},
		children: /* @__PURE__ */ p("span", {
			style: {
				display: "block",
				width: t,
				height: t / 1.5,
				transform: "scale(" + e / t + ")",
				transformOrigin: "top left"
			},
			children: n
		})
	});
}
function $(e, t, n = 96) {
	let r = t ? e.anchor("journey:" + t) : null;
	return r ? Math.max(n, (r.h - 8) * 1.5) : n;
}
function qe(e, t) {
	let n = Math.min(e.w, t), r = n / 1.5;
	return {
		x: e.x + (e.w - n) / 2,
		y: e.y + (e.h - r) / 2,
		w: n,
		h: r
	};
}
function Je(e) {
	return { fontSize: Math.max(14, Math.min(32, Math.round(e.w * .4))) };
}
var Ye = {
	deal(e, t) {
		let n = e.secret;
		if (n && Array.isArray(n.cards)) {
			let e = X(t);
			if (!e) return null;
			let r = [], i = [];
			for (let [a, o] of n.cards.entries()) {
				let n = t.anchor(`card:${o}`);
				n && (i.push(`card:${o}`), r.push(/* @__PURE__ */ p(g, {
					from: e,
					to: n,
					ms: 320,
					delay: a * 45,
					children: /* @__PURE__ */ p(Q, {
						width: n.w,
						baseWidth: 144,
						children: /* @__PURE__ */ p(W, {
							id: o,
							size: "hand"
						})
					})
				}, o)));
			}
			return r.length ? {
				ms: 320 + r.length * 45,
				node: r,
				hide: i
			} : null;
		}
		let r = X(t), i = Z(t, e.rid);
		if (!r || !i) return null;
		let a = e.data?.count, o = typeof a == "number" ? a : 3;
		return {
			ms: 320 + o * 45,
			node: Array.from({ length: o }, (n, a) => /* @__PURE__ */ p(g, {
				from: r,
				to: i,
				ms: 320,
				delay: a * 45,
				children: /* @__PURE__ */ p(Q, {
					width: $(t, e.rid),
					baseWidth: 96,
					children: /* @__PURE__ */ p(G, { size: "journey" })
				})
			}, a))
		};
	},
	bankReveal(e, t) {
		let n = e.data?.cards;
		if (!Array.isArray(n) || !n.length) return null;
		let r = X(t, 56, 80);
		if (!r) return null;
		let i = [], a = [];
		for (let [e, o] of n.entries()) {
			let n = t.anchor(`card:${o}`);
			n && (a.push(`card:${o}`), i.push(/* @__PURE__ */ p(g, {
				from: r,
				to: n,
				ms: 300,
				delay: e * 60,
				children: /* @__PURE__ */ p(Q, {
					width: n.w,
					baseWidth: 108,
					children: /* @__PURE__ */ p(W, {
						id: o,
						size: "bank"
					})
				})
			}, o)));
		}
		return i.length ? {
			ms: 300 + i.length * 60,
			node: i,
			hide: a
		} : null;
	},
	reveal(e, t) {
		let n = e.data?.cards;
		if (!Array.isArray(n) || !n.length) return null;
		let r = re(n.length), i = [];
		for (let [e, r] of n.entries()) {
			let n = t.anchor(`card:${r.card}`);
			n && i.push(/* @__PURE__ */ p(_, {
				at: n,
				ms: 500,
				delay: e * 120
			}, r.card));
		}
		return {
			ms: r,
			node: i.length ? i : null
		};
	},
	drawSanct(e, t) {
		let n = Z(t, e.rid), r = X(t, 40, 60);
		if (!r || !n) return null;
		let i = e.data?.count, a = typeof i == "number" ? i : 1;
		return {
			ms: 300 + a * 70,
			node: Array.from({ length: a }, (i, a) => /* @__PURE__ */ p(g, {
				from: r,
				to: n,
				ms: 300,
				delay: a * 70,
				children: /* @__PURE__ */ p(Q, {
					width: $(t, e.rid),
					baseWidth: 96,
					children: /* @__PURE__ */ p(G, { size: "journey" })
				})
			}, a))
		};
	},
	takeBank(e, t) {
		let n = e.data;
		if (typeof n?.card != "number") return null;
		let r = n.card, i = X(t, 56, 80);
		if (!i) return null;
		if (e.rid === t.myRid) {
			let n = t.anchor(`card:${r}`) ?? Z(t, e.rid);
			return n ? {
				ms: 380,
				node: /* @__PURE__ */ p(g, {
					from: i,
					to: n,
					ms: 380,
					children: /* @__PURE__ */ p(Q, {
						width: Math.max(108, n.w),
						baseWidth: 108,
						children: /* @__PURE__ */ p(W, {
							id: r,
							size: "bank"
						})
					})
				}),
				hide: [`card:${r}`]
			} : null;
		}
		let a = Z(t, e.rid);
		return a ? {
			ms: 380,
			node: /* @__PURE__ */ p(g, {
				from: i,
				to: a,
				ms: 380,
				children: /* @__PURE__ */ p(Q, {
					width: $(t, e.rid),
					baseWidth: 96,
					children: /* @__PURE__ */ p(G, { size: "journey" })
				})
			})
		} : null;
	},
	keepSanct(e, t) {
		let n = e.secret;
		if (n && typeof n.sanct == "number") {
			let r = t.anchor(`sanct:${n.sanct}`), i = Z(t, e.rid);
			return !i || !r ? null : {
				ms: 380,
				node: /* @__PURE__ */ p(g, {
					from: i,
					to: r,
					ms: 380,
					children: /* @__PURE__ */ p(Q, {
						width: r.w,
						baseWidth: 60,
						children: /* @__PURE__ */ p(K, {
							id: n.sanct,
							size: "mini"
						})
					})
				}),
				hide: [`sanct:${n.sanct}`]
			};
		}
		let r = Z(t, e.rid), i = (e.rid ? t.anchor(`journey:${e.rid}`) : null) ?? r;
		return !r || !i ? null : {
			ms: 380,
			node: /* @__PURE__ */ p(g, {
				from: r,
				to: qe(i, $(t, e.rid, 60)),
				ms: 380,
				children: /* @__PURE__ */ p(Q, {
					width: $(t, e.rid, 60),
					baseWidth: 60,
					children: /* @__PURE__ */ p(G, { size: "mini" })
				})
			})
		};
	},
	scoringStart() {
		return {
			ms: N.flip,
			node: null
		};
	},
	flip(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.plays)) return null;
		let r = [];
		for (let e of n.plays) {
			let n = t.anchor(`card:${e.card}`);
			n && r.push(/* @__PURE__ */ p(_, {
				at: n,
				ms: 600
			}, `p${e.card}`));
			let i = t.anchor(`seat:${e.rid}`);
			i && e.gain > 0 && r.push(/* @__PURE__ */ p(h, {
				at: i,
				ms: 900,
				children: /* @__PURE__ */ m("span", {
					style: Je(i),
					children: [
						"+",
						e.gain,
						" ⭐"
					]
				})
			}, `f${e.rid}`));
		}
		return {
			ms: N.flip,
			node: r.length ? r : null
		};
	},
	flipSanct(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.plays)) return null;
		let r = [];
		for (let e of n.plays) {
			let n = t.anchor(`seat:${e.rid}`);
			!n || e.gain <= 0 || r.push(/* @__PURE__ */ p(h, {
				at: n,
				ms: 1200,
				children: /* @__PURE__ */ m("span", {
					style: Je(n),
					children: [
						"+",
						e.gain,
						" 🛖"
					]
				})
			}, e.rid));
		}
		return {
			ms: N.sanct,
			node: r.length ? r : null
		};
	},
	scoringDone() {
		return {
			ms: N.done,
			node: null
		};
	}
};
//#endregion
//#region src/games/faraway/game-over.tsx
function Xe({ pub: e, rid: t, won: n, place: r, name: i, tieBreak: a }) {
	let s = o(), c = e.players.find((e) => e.rid === t);
	if (!c) return null;
	let l = c.fame.reduce((e, t) => e + (t ?? 0), 0) + (c.sanctFame ?? 0), u = Math.min(...c.tableau);
	return /* @__PURE__ */ m("section", {
		className: "fw-over-player frame flex flex-col gap-1.5 p-2.5",
		style: { "--fw-over-detail-count": c.tableau.length + +((c.sanctFame ?? 0) > 0) },
		children: [
			/* @__PURE__ */ m("header", {
				className: "fw-over-player-header flex items-center gap-2",
				children: [
					/* @__PURE__ */ p("span", {
						"aria-hidden": !0,
						className: `w-5 flex-none text-center ${n ? "" : "invisible"}`,
						children: "🏆"
					}),
					/* @__PURE__ */ m("span", {
						className: "fw-over-name min-w-0 flex-1 truncate text-sm font-extrabold",
						children: [
							r,
							". ",
							i
						]
					}),
					/* @__PURE__ */ p("span", {
						className: "fw-over-total flex-none font-mono text-lg font-extrabold tabular-nums",
						children: l
					})
				]
			}),
			/* @__PURE__ */ m("ul", {
				className: "fw-over-details scrollbar-none flex flex-wrap items-end gap-1.5",
				children: [c.tableau.map((e, t) => /* @__PURE__ */ m("li", {
					className: `fw-over-detail flex flex-col items-center gap-0.5 ${(c.fame[t] ?? 0) === 0 ? "opacity-45" : ""}`,
					children: [/* @__PURE__ */ p(W, {
						id: e,
						size: "mini"
					}), /* @__PURE__ */ m("span", {
						className: "fw-over-gain font-mono text-[10px] font-bold tabular-nums",
						children: ["+", c.fame[t] ?? 0]
					})]
				}, e)), (c.sanctFame ?? 0) > 0 && /* @__PURE__ */ m("li", {
					className: "fw-over-detail flex flex-col items-center gap-0.5",
					children: [/* @__PURE__ */ p("span", {
						className: "fw-over-sanct grid h-10 w-7 place-items-center rounded-md border-2 border-ink bg-surface text-sm shadow-[2px_2px_0_var(--color-ink)]",
						children: "🛖"
					}), /* @__PURE__ */ m("span", {
						className: "fw-over-gain font-mono text-[10px] font-bold tabular-nums",
						children: ["+", c.sanctFame]
					})]
				})]
			}),
			a && /* @__PURE__ */ p("p", {
				className: "fw-over-tie text-[11px] text-ink/60",
				children: s("games.faraway.tieBreak", { n: u })
			})
		]
	});
}
function Ze({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let a = o(), s = t, c = (e) => n.find((t) => t.rid === e)?.name ?? e, l = r ?? i, u = (e) => {
		let t = s.players.find((t) => t.rid === e);
		return t ? t.fame.reduce((e, t) => e + (t ?? 0), 0) + (t.sanctFame ?? 0) : 0;
	}, d = u(e.ranking[0] ?? ""), f = e.ranking.filter((e) => u(e) === d).length > 1;
	return /* @__PURE__ */ p("div", {
		className: "fw-over-screen relative flex h-full min-h-0 flex-col items-center gap-2 overflow-y-auto",
		children: /* @__PURE__ */ m("div", {
			className: "fw-over-layout",
			style: { "--fw-over-count": e.ranking.length },
			children: [
				e.winner.length > 0 && /* @__PURE__ */ p(v, {}),
				/* @__PURE__ */ m("h1", {
					className: "fw-over-title flex flex-none items-center gap-2 text-center font-display text-xl font-extrabold",
					children: [/* @__PURE__ */ p("span", {
						"aria-hidden": !0,
						children: E.icon
					}), a("session.result.title")]
				}),
				/* @__PURE__ */ p("div", {
					className: "fw-over-players scrollbar-none flex w-full max-w-md flex-none flex-col gap-2",
					children: e.ranking.map((t, n) => /* @__PURE__ */ p(Xe, {
						pub: s,
						rid: t,
						won: e.winner.includes(t),
						place: n + 1,
						name: c(t),
						tieBreak: f
					}, t))
				}),
				l ? /* @__PURE__ */ m("div", {
					className: "fw-over-actions safe-b flex w-full max-w-sm flex-none flex-col gap-2 pb-1",
					children: [r && /* @__PURE__ */ p("button", {
						className: "btn-base w-full cursor-pointer text-white",
						style: { background: E.accent },
						onClick: r,
						children: a("session.result.playAgain")
					}), i && /* @__PURE__ */ p("button", {
						className: "btn-quiet w-full cursor-pointer",
						onClick: i,
						children: a("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ p("p", {
					className: "fw-over-actions safe-b flex-none pb-1 text-sm font-bold opacity-70",
					children: a("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/games/faraway/options.tsx
function Qe({ value: e, onChange: t }) {
	let n = o(), r = A.safeParse(e), i = r.success ? r.data : A.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ p(b, {
			title: n("games.faraway.optAdvanced"),
			children: [!1, !0].map((e) => /* @__PURE__ */ p(y, {
				name: "faraway-advanced",
				value: String(e),
				checked: i.advanced === e,
				label: n(e ? "games.faraway.optAdvancedOn" : "games.faraway.optAdvancedOff"),
				accent: E.accent,
				onChange: () => t({ advanced: e })
			}, String(e)))
		}), /* @__PURE__ */ p("p", {
			className: "text-xs text-ink/70",
			children: n("games.faraway.optAdvancedHint")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/faraway/entry.tsx
var $e = {
	definition: de,
	View: Te,
	bot: Le,
	describe: Re,
	llm: We,
	fx: Ye,
	OverView: Ze,
	Options: Qe,
	locales: {
		zh: {
			name: "遥远之地",
			desc: "8 轮探索阿鲁拉,回程逐张翻牌赢声望",
			rules: "目标:8 轮探索后回程计分,声望最高者获胜。\n流程(每轮):\n· 每人 3 张手牌,所有人同时暗选 1 张打出,排到旅程行右端。\n· 打出的探索时长比自己上一张更大,就能找到圣所。\n· 圣所先抽 1 张,自己旅程行与已有圣所上每个线索图标再多抽 1 张。\n· 然后按本轮时长从小到大轮流行动:从银行补 1 张手牌。\n· 抽到的圣所留 1 张,其余放回圣所牌堆。\n计分:\n· 8 轮后回程:区域卡从右到左逐张翻开,每张只对「已翻开的卡」和「全部圣所」结算。\n· 最后结算圣所。\n· 同分比旅程中最小的探索时长,小者胜。",
			roundShort: "{{n}}/{{total}}",
			draftPrompt: "保留 3 张,弃掉其余",
			draftWaiting: "已留牌,等其他人…",
			draftConfirm: "保留所选({{n}}/3)",
			explorePrompt: "选一张打出",
			waitingPick: "已打出,等其他人…",
			refillPrompt: "从银行拿 1 张",
			refillPromptSanct: "拿 1 张银行牌,再留 1 张圣所",
			refillSanctOnly: "留 1 张圣所",
			refillWaiting: "等 {{name}} 补牌…",
			bankLabel: "银行",
			bankEmpty: "银行已空",
			myJourney: "我的旅程",
			mySancts: "圣所",
			pendingSanct: "选 1 张圣所留下",
			scoring: "回程计分中…",
			playCardAria: "打出 {{n}} 号区域",
			takeBankAria: "拿取 {{n}} 号区域",
			keepSanctAria: "留下这张圣所",
			tieBreak: "同分决胜:旅程最小时长 {{n}}",
			optAdvanced: "进阶变体",
			optAdvancedOn: "进阶",
			optAdvancedOff: "标准",
			optAdvancedHint: "进阶:开局发 5 张留 3 张,弃牌洗回牌库",
			errNotYourTurn: "现在轮不到你",
			errBadCard: "这张牌不在你手里",
			errBadDraft: "要保留正好 3 张",
			errBadRefill: "这步补牌不合法",
			hintDraft: "保留 {{a}}、{{b}}、{{c}} 号区域",
			hintRefillBoth: "拿取 {{n}} 号区域,留下 1 张圣所"
		},
		en: {
			name: "Faraway",
			desc: "Explore Alula for 8 rounds, then score your way back",
			rules: "Goal: after 8 rounds of exploration, score the way back; the most fame wins.\nEach round:\n· Everyone holds 3 cards; all players secretly play one card to the right end of their journey.\n· If its duration beats your previous card, you find sanctuaries.\n· Draw 1 sanctuary, plus 1 more per clue icon on your journey cards and existing sanctuaries.\n· Then, in ascending duration order: take 1 bank card.\n· Keep 1 of the drawn sanctuaries, putting the rest back on the sanctuary deck.\nScoring:\n· On the way back, region cards flip from right to left; each scores only against already-flipped regions and all of your sanctuaries.\n· Sanctuaries score last.\n· Ties go to the lowest duration in the journey.",
			roundShort: "{{n}}/{{total}}",
			draftPrompt: "Keep 3 cards, discard the rest",
			draftWaiting: "Kept. Waiting for others…",
			draftConfirm: "Keep selected ({{n}}/3)",
			explorePrompt: "Play a card",
			waitingPick: "Played. Waiting for others…",
			refillPrompt: "Take 1 card from the bank",
			refillPromptSanct: "Take 1 bank card and keep 1 sanctuary",
			refillSanctOnly: "Keep 1 sanctuary",
			refillWaiting: "Waiting for {{name}}…",
			bankLabel: "Bank",
			bankEmpty: "Bank is empty",
			myJourney: "My journey",
			mySancts: "Sanctuaries",
			pendingSanct: "Keep 1 sanctuary",
			scoring: "Scoring the way back…",
			playCardAria: "Play region {{n}}",
			takeBankAria: "Take region {{n}}",
			keepSanctAria: "Keep this sanctuary",
			tieBreak: "Tie-break: lowest duration {{n}}",
			optAdvanced: "Advanced variant",
			optAdvancedOn: "Advanced",
			optAdvancedOff: "Standard",
			optAdvancedHint: "Advanced: deal 5, keep 3, shuffle the discards back",
			errNotYourTurn: "Not your turn",
			errBadCard: "That card is not in your hand",
			errBadDraft: "Keep exactly 3 cards",
			errBadRefill: "Invalid refill",
			hintDraft: "Keep regions {{a}}, {{b}} and {{c}}",
			hintRefillBoth: "Take region {{n}} and keep 1 sanctuary"
		}
	}
};
//#endregion
export { $e as default };
