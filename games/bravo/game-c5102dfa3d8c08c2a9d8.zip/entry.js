import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useMemo as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as p, seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { SheetView as m } from "@bgparty/sdk/sheet-view";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { Floater as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { AVATARS as b } from "@bgparty/sdk/avatars";
import { IconBot as te } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as x } from "@bgparty/sdk/player-colors";
import { Confetti as S } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as C } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/bravo/meta.ts
var w = {
	id: "bravo",
	tier: "released",
	mechanics: ["roll-and-write", "dice-rolling"],
	interactionTags: [],
	nameKey: "games.bravo.name",
	descKey: "games.bravo.desc",
	rulesKey: "games.bravo.rules",
	icon: "🌈",
	iconImg: "games/bravo.webp",
	rulesUrl: { de: "https://rules.bgparty.uuppi.com/bravo/de.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [2],
	accent: "#7c3aed",
	releasedAt: "2026-09-17",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, T = t.enum([
	"pink",
	"yellow",
	"green",
	"orange",
	"blue"
]), E = t.enum([
	"pink",
	"yellow",
	"green",
	"orange",
	"blue",
	"X"
]), ne = t.union([t.int().min(1).max(5), t.literal("?")]), re = t.enum([
	"bomb",
	"heart",
	"stars",
	"row3",
	"block"
]), D = t.int().min(0).max(104), ie = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("pick"),
		colorDie: t.int().min(0).max(2),
		numberDie: t.int().min(0).max(2),
		color: T.optional(),
		number: t.int().min(1).max(5).optional(),
		cells: t.array(D).min(1).max(5)
	}),
	t.object({
		type: t.literal("special"),
		cells: t.array(D).max(4)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("bomb"),
		cells: t.array(D).max(4)
	})
]), ae = t.object({
	crossed: t.array(t.boolean()).length(105),
	jokers: t.int().min(0).max(6),
	diceCircled: t.int().min(0).max(10),
	diceUsed: t.int().min(0).max(10),
	hearts: t.int().min(0).max(5),
	rowsDone: t.array(t.boolean()).length(7),
	colsDone: t.array(t.boolean()).length(15),
	colPts: t.array(t.int().min(0)).length(15),
	colHeart: t.array(t.int().min(0)).length(15),
	colorsDone: t.record(T, t.boolean()),
	colorPts: t.record(T, t.int().min(0))
}), oe = t.object({
	colors: t.array(E).length(3),
	numbers: t.array(ne).length(3),
	special: re
}), se = t.object({
	color: t.int().min(0).max(2).nullable(),
	number: t.int().min(0).max(2).nullable(),
	special: t.boolean(),
	passed: t.boolean()
}), ce = t.object({
	players: t.array(t.string()).min(2).max(6),
	throwNum: t.int().min(1),
	phase: t.enum([
		"roll",
		"activePick",
		"othersPick",
		"bombs",
		"done"
	]),
	active: t.string(),
	dice: oe.nullable(),
	taken: se.nullable(),
	done: t.record(t.string(), t.boolean()),
	bombs: t.record(t.string(), t.int().min(0)),
	sheets: t.record(t.string(), ae),
	firsts: t.object({
		rows: t.array(t.int().min(1).nullable()).length(7),
		cols: t.array(t.int().min(1).nullable()).length(15),
		colors: t.record(T, t.int().min(1).nullable())
	}),
	scores: t.record(t.string(), t.number())
}), le = t.object({}), O = [
	"pink",
	"yellow",
	"green",
	"orange",
	"blue"
], k = {
	p: "pink",
	y: "yellow",
	g: "green",
	o: "orange",
	b: "blue"
}, A = [
	"ppoyyppggyyooob",
	"byyyooppbbyypoo",
	"bybbbooobggyppo",
	"obbgbyyboogggpp",
	"ooppgbbbyoopyyy",
	"ggpogggyypppbbg",
	"yggopggyppbbbgg"
].flatMap((e) => [...e].map((e) => k[e])), j = /* @__PURE__ */ new Set([
	2,
	5,
	10,
	11,
	24,
	37,
	46,
	48,
	57,
	74,
	81,
	88,
	90,
	94,
	98
]), M = /* @__PURE__ */ new Set([
	31,
	49,
	95,
	71,
	44
]), N = [
	5,
	3,
	3,
	3,
	2,
	2,
	2,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	5
], P = [
	3,
	2,
	2,
	2,
	1,
	1,
	1,
	0,
	1,
	1,
	1,
	2,
	2,
	2,
	3
], F = [
	"die",
	"bomb",
	"heart",
	"bomb",
	"die",
	"heart",
	"bomb"
], I = (e) => Math.floor(e / 15), L = (e) => e % 15;
function R(e) {
	let t = I(e), n = L(e), r = [];
	return t > 0 && r.push(e - 15), t < 6 && r.push(e + 15), n > 0 && r.push(e - 1), n < 14 && r.push(e + 1), r;
}
var z = (() => {
	let e = Array(105).fill(-1), t = 0;
	for (let n = 0; n < 105; n++) {
		if (e[n] >= 0) continue;
		let r = A[n], i = [n];
		for (e[n] = t; i.length > 0;) {
			let n = i.pop();
			for (let a of R(n)) e[a] < 0 && A[a] === r && (e[a] = t, i.push(a));
		}
		t += 1;
	}
	return e;
})(), B = (() => {
	let e = {
		pink: [],
		yellow: [],
		green: [],
		orange: [],
		blue: []
	};
	for (let t = 0; t < 105; t++) e[A[t]].push(t);
	return e;
})();
function ue(e) {
	if (e.length <= 1) return !0;
	let t = new Set(e), n = /* @__PURE__ */ new Set([e[0]]), r = [e[0]];
	for (; r.length > 0;) {
		let e = r.pop();
		for (let i of R(e)) t.has(i) && !n.has(i) && (n.add(i), r.push(i));
	}
	return n.size === t.size;
}
function de(e, t) {
	return t.some((t) => L(t) === 7 || R(t).some((t) => e[t]));
}
function fe(e, t, n, r) {
	if (r.length !== n || n < 1 || n > 5 || new Set(r).size !== r.length) return !1;
	let i = z[r[0]];
	for (let n of r) if (e[n] || A[n] !== t || z[n] !== i) return !1;
	return ue(r) && de(e, r);
}
function pe(e, t) {
	if (t.length < 1 || t.length > 4 || new Set(t).size !== t.length) return !1;
	for (let n of t) if (e[n]) return !1;
	let n = t.map(I), r = t.map(L);
	return Math.max(...n) - Math.min(...n) <= 1 && Math.max(...r) - Math.min(...r) <= 1;
}
function me(e, t) {
	if (t.length < 1 || t.length > 2 || new Set(t).size !== t.length) return !1;
	for (let n of t) if (e[n] || !j.has(n) || !(L(n) === 7 || R(n).some((t) => e[t]))) return !1;
	return !0;
}
function he(e, t) {
	if (t.length < 1 || t.length > 3 || new Set(t).size !== t.length) return !1;
	let n = I(t[0]);
	for (let r of t) if (e[r] || I(r) !== n || !R(r).some((t) => e[t])) return !1;
	return !0;
}
function V(e, t) {
	if (e[t]) return null;
	let n = z[t], r = [];
	for (let t = 0; t < 105; t++) z[t] === n && !e[t] && r.push(t);
	return r.length === 0 ? null : r.some((t) => R(t).some((t) => e[t])) ? r : null;
}
function ge(e, t, n, r = 300) {
	let i = [], a = /* @__PURE__ */ new Set(), o = new Set(B[t].map((e) => z[e]));
	for (let s of o) {
		let o = B[t].filter((t) => z[t] === s && !e[t]);
		if (o.length < n) continue;
		let c = o.filter((t) => L(t) === 7 || R(t).some((t) => e[t])), l = (t, o) => {
			if (!(i.length >= r)) {
				if (t.length === n) {
					let e = [...t].sort((e, t) => e - t).join(",");
					a.has(e) || (a.add(e), i.push([...t]));
					return;
				}
				for (let n = 0; n < o.length; n++) {
					let r = o[n], i = [...o.slice(n + 1)];
					for (let n of R(r)) !e[n] && z[n] === s && !t.includes(n) && !i.includes(n) && i.push(n);
					l([...t, r], i);
				}
			}
		};
		for (let t of c) {
			let n = R(t).filter((t) => !e[t] && z[t] === s);
			l([t], n);
		}
	}
	return i;
}
function _e(e) {
	let t = [];
	for (let n = 0; n < 7; n++) {
		let r = !0;
		for (let t = 0; t < 15; t++) e[n * 15 + t] || (r = !1);
		t.push(r);
	}
	return t;
}
function ve(e) {
	let t = [];
	for (let n = 0; n < 15; n++) {
		let r = !0;
		for (let t = 0; t < 7; t++) e[t * 15 + n] || (r = !1);
		t.push(r);
	}
	return t;
}
function ye(e) {
	let t = {};
	for (let n of O) t[n] = B[n].every((t) => e[t]);
	return t;
}
function be() {
	return {
		crossed: Array(105).fill(!1),
		jokers: 6,
		diceCircled: 1,
		diceUsed: 0,
		hearts: 0,
		rowsDone: Array(7).fill(!1),
		colsDone: Array(15).fill(!1),
		colPts: Array(15).fill(0),
		colHeart: Array(15).fill(0),
		colorsDone: {
			pink: !1,
			yellow: !1,
			green: !1,
			orange: !1,
			blue: !1
		},
		colorPts: {
			pink: 0,
			yellow: 0,
			green: 0,
			orange: 0,
			blue: 0
		}
	};
}
function xe(e) {
	let t = 0;
	for (let n of j) e.crossed[n] || (t += 1);
	return t;
}
function H(e) {
	let t = O.reduce((t, n) => t + e.colorPts[n], 0), n = e.colPts.reduce((e, t) => e + t, 0), r = e.rowsDone.filter(Boolean).length * 5, i = e.colHeart.reduce((e, t) => e + t, 0), a = e.jokers, o = (e.diceCircled - e.diceUsed) * 2, s = -2 * xe(e);
	return {
		colors: t,
		cols: n,
		rows: r,
		hearts: i,
		jokers: a,
		dice: o,
		stars: s,
		total: t + n + r + i + a + o + s
	};
}
//#endregion
//#region src/games/bravo/rules.ts
var U = {
	notYourTurn: "games.bravo.errNotYourTurn",
	noDice: "games.bravo.errNoDice",
	badCells: "games.bravo.errBadCells",
	noJoker: "games.bravo.errNoJoker",
	noSpecial: "games.bravo.errNoSpecial",
	over: "games.bravo.errOver"
}, Se = [
	"bomb",
	"heart",
	"stars",
	"row3",
	"block",
	"heart"
];
function Ce(t, n, r) {
	let i = {};
	for (let e of n) i[e] = be();
	return {
		state: {
			players: n,
			seed: r,
			rngCursor: 1,
			throwNum: 1,
			activeIdx: e(r, 0, n.length),
			phase: "roll",
			dice: null,
			taken: null,
			done: {},
			bombs: {},
			sheets: i,
			firsts: {
				rows: Array(7).fill(null),
				cols: Array(15).fill(null),
				colors: {
					pink: null,
					yellow: null,
					green: null,
					orange: null,
					blue: null
				}
			}
		},
		fx: []
	};
}
var W = (e) => e.players[e.activeIdx];
function we(e, t) {
	if (!e.dice) return null;
	let n = {
		colors: [
			0,
			1,
			2
		],
		numbers: [
			0,
			1,
			2
		],
		special: !0
	};
	if (e.phase === "activePick" && t === W(e)) return n;
	if (e.phase === "othersPick" && t !== W(e) && !e.done[t]) {
		if (e.throwNum <= 3 || e.taken?.passed) return n;
		let t = e.taken;
		return t ? {
			colors: [
				0,
				1,
				2
			].filter((e) => e !== t.color),
			numbers: [
				0,
				1,
				2
			].filter((e) => e !== t.number),
			special: !t.special
		} : null;
	}
	return null;
}
function G(e, t, n, r) {
	for (let n of t) e.crossed[n] = !0;
	n.push({
		kind: "cross",
		rid: r,
		data: { cells: [...t] }
	});
	for (let i of t) M.has(i) && e.diceCircled < 10 && (e.diceCircled += 1, n.push({
		kind: "gain",
		rid: r,
		data: { what: "die" }
	}));
}
function Te(e, t, n) {
	let r = e.sheets[t], i = _e(r.crossed);
	for (let a = 0; a < i.length; a++) {
		if (!i[a] || r.rowsDone[a] || (r.rowsDone[a] = !0, e.firsts.rows[a] !== null && e.firsts.rows[a] !== e.throwNum)) continue;
		e.firsts.rows[a] ??= e.throwNum;
		let o = F[a];
		o === "die" && r.diceCircled < 10 ? r.diceCircled += 1 : o === "heart" && r.hearts < 5 ? r.hearts += 1 : o === "bomb" && (e.bombs[t] = (e.bombs[t] ?? 0) + 1), n.push({
			kind: "gain",
			rid: t,
			data: { what: o }
		});
	}
}
function Ee(e, t) {
	for (let n of e.players) {
		let r = e.sheets[n], i = ve(r.crossed);
		for (let a = 0; a < i.length; a++) {
			if (!i[a] || r.colsDone[a]) continue;
			r.colsDone[a] = !0;
			let o = e.firsts.cols[a] === null || e.firsts.cols[a] === e.throwNum;
			e.firsts.cols[a] ??= e.throwNum, r.colPts[a] = o ? N[a] : P[a], r.colHeart[a] = r.hearts, t.push({
				kind: "score",
				rid: n,
				data: {
					label: `col:${a}`,
					pts: r.colPts[a] + r.colHeart[a]
				}
			});
		}
		let a = ye(r.crossed);
		for (let i of O) {
			if (!a[i] || r.colorsDone[i]) continue;
			r.colorsDone[i] = !0;
			let o = e.firsts.colors[i] === null || e.firsts.colors[i] === e.throwNum;
			e.firsts.colors[i] ??= e.throwNum, r.colorPts[i] = o ? 5 : 3, t.push({
				kind: "score",
				rid: n,
				data: {
					label: `color:${i}`,
					pts: r.colorPts[i]
				}
			});
		}
	}
	if (e.players.some((t) => O.filter((n) => e.sheets[t].colorsDone[n]).length >= 2)) {
		e.phase = "done";
		return;
	}
	e.throwNum += 1, e.activeIdx = (e.activeIdx + 1) % e.players.length, e.phase = "roll", e.dice = null, e.taken = null, e.done = {}, e.bombs = {};
}
function K(e, t) {
	for (let n of e.players) Te(e, n, t);
	if (Object.values(e.bombs).some((e) => e > 0)) {
		e.phase = "bombs";
		return;
	}
	Ee(e, t);
}
function De(t, n, r) {
	if (t.phase === "done") return { code: U.over };
	if (n.type === "roll") {
		if (t.phase !== "roll" || r.by !== W(t)) return { code: U.notYourTurn };
		let n = structuredClone(t), i = [], a = [];
		for (let t = 0; t < 3; t++) {
			let t = e(n.seed, n.rngCursor, 6);
			n.rngCursor += 1, i.push(t === 5 ? "X" : O[t]);
		}
		for (let t = 0; t < 3; t++) {
			let t = e(n.seed, n.rngCursor, 6);
			n.rngCursor += 1, a.push(t === 5 ? "?" : t + 1);
		}
		return n.dice = {
			colors: i,
			numbers: a,
			special: Se[e(n.seed, n.rngCursor, 6)]
		}, n.rngCursor += 1, n.phase = "activePick", {
			state: n,
			fx: [{
				kind: "roll",
				rid: r.by,
				data: { dice: n.dice }
			}]
		};
	}
	if (n.type === "pick" || n.type === "special" || n.type === "pass") {
		let e = we(t, r.by);
		if (!e) return { code: U.notYourTurn };
		let i = t.phase === "activePick", a = structuredClone(t), o = a.sheets[r.by], s = [];
		if (n.type === "pass") return i ? (a.taken = {
			color: null,
			number: null,
			special: !1,
			passed: !0
		}, a.phase = "othersPick", a.done = {}) : (a.done[r.by] = !0, Object.keys(a.done).length >= a.players.length - 1 && K(a, s)), {
			state: a,
			fx: s
		};
		if (n.type === "pick") {
			if (!a.dice || !e.colors.includes(n.colorDie) || !e.numbers.includes(n.numberDie)) return { code: U.noDice };
			let t = a.dice.colors[n.colorDie], c = a.dice.numbers[n.numberDie];
			if ((t === "X" ? n.color === void 0 : n.color !== void 0 && n.color !== t) || (c === "?" ? n.number === void 0 : n.number !== void 0 && n.number !== c)) return { code: U.badCells };
			let l = t === "X" ? n.color : t, u = c === "?" ? n.number : c, d = +(t === "X") + +(c === "?");
			return o.jokers < d ? { code: U.noJoker } : fe(o.crossed, l, u, n.cells) ? (o.jokers -= d, G(o, n.cells, s, r.by), i ? (a.taken = {
				color: n.colorDie,
				number: n.numberDie,
				special: !1,
				passed: !1
			}, a.phase = "othersPick", a.done = {}) : (a.done[r.by] = !0, Object.keys(a.done).length >= a.players.length - 1 && K(a, s)), {
				state: a,
				fx: s
			}) : { code: U.badCells };
		}
		if (!a.dice || !e.special) return { code: U.noDice };
		if (o.diceCircled - o.diceUsed <= 0) return { code: U.noSpecial };
		let c = a.dice.special, l = [];
		if (c === "heart") {
			if (n.cells.length !== 0) return { code: U.badCells };
		} else if (c === "bomb") {
			if (!pe(o.crossed, n.cells)) return { code: U.badCells };
			l = [...n.cells];
		} else if (c === "stars") {
			if (!me(o.crossed, n.cells)) return { code: U.badCells };
			l = [...n.cells];
		} else if (c === "row3") {
			if (!he(o.crossed, n.cells)) return { code: U.badCells };
			l = [...n.cells];
		} else {
			let e = n.cells.length === 1 ? V(o.crossed, n.cells[0]) : null;
			if (!e) return { code: U.badCells };
			l = e;
		}
		return o.diceUsed += 1, c === "heart" ? (o.hearts < 5 && (o.hearts += 1), s.push({
			kind: "gain",
			rid: r.by,
			data: { what: "heart" }
		})) : G(o, l, s, r.by), i ? (a.taken = {
			color: null,
			number: null,
			special: !0,
			passed: !1
		}, a.phase = "othersPick", a.done = {}) : (a.done[r.by] = !0, Object.keys(a.done).length >= a.players.length - 1 && K(a, s)), {
			state: a,
			fx: s
		};
	}
	return { code: U.notYourTurn };
}
function Oe(e, t, n) {
	if (e.phase !== "bombs" || (e.bombs[n.by] ?? 0) <= 0) return { code: U.notYourTurn };
	let r = e.sheets[n.by];
	if (t.cells.length > 0 && !pe(r.crossed, t.cells)) return { code: U.badCells };
	let i = structuredClone(e), a = [];
	return G(i.sheets[n.by], t.cells, a, n.by), --i.bombs[n.by], Te(i, n.by, a), Object.values(i.bombs).every((e) => e <= 0) && Ee(i, a), {
		state: i,
		fx: a
	};
}
function ke(e, t, n) {
	return t.type === "bomb" ? Oe(e, t, n) : De(e, t, n);
}
function Ae(e) {
	let t = {};
	for (let n of e.players) t[n] = H(e.sheets[n]).total;
	return {
		public: {
			players: e.players,
			throwNum: e.throwNum,
			phase: e.phase,
			active: W(e),
			dice: e.dice,
			taken: e.taken,
			done: e.done,
			bombs: e.bombs,
			sheets: e.sheets,
			firsts: e.firsts,
			scores: t
		},
		private: {}
	};
}
function je(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = H(e.sheets[n]).total;
	let n = [...e.players].sort((n, r) => {
		if (t[r] !== t[n]) return t[r] - t[n];
		let i = e.sheets[n].jokers, a = e.sheets[r].jokers;
		return a === i ? e.players.indexOf(n) - e.players.indexOf(r) : a - i;
	}), r = n[0];
	return {
		phase: "done",
		winner: n.filter((n) => t[n] === t[r] && e.sheets[n].jokers === e.sheets[r].jokers),
		ranking: n,
		scores: t
	};
}
var Me = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: w,
	schemas: {
		action: ie,
		publicView: ce,
		privateView: le
	},
	setup: Ce,
	reduce: ke,
	viewFor: Ae,
	status: je
}, q = 1872, J = 1052;
function Y(e) {
	let t = Math.floor(e / 15);
	return {
		x: 120 + e % 15 * 108,
		y: 72 + t * 108,
		w: 100,
		h: 100
	};
}
var Ne = 1752;
function Pe(e) {
	return {
		x: 8,
		y: 72 + e * 108,
		w: 96,
		h: 100
	};
}
function Fe(e) {
	return 120 + e * 108 + 50;
}
//#endregion
//#region src/games/bravo/sheet-view.tsx
var X = {
	pink: "#f9a8d4",
	yellow: "#fde047",
	green: "#86efac",
	orange: "#fdba74",
	blue: "#93c5fd"
}, Ie = "ABCDEFGHIJKLMNO", Le = "PQRSTUV";
function Re(e, t, n) {
	let r = [];
	for (let i = 0; i < 10; i++) {
		let a = i % 2 == 0 ? n : n * .45, o = Math.PI / 5 * i - Math.PI / 2;
		r.push(`${(e + a * Math.cos(o)).toFixed(1)},${(t + a * Math.sin(o)).toFixed(1)}`);
	}
	return r.join(" ");
}
function Z(e, t, n) {
	return `M ${e} ${t + n * .75} C ${e - n * 1.3} ${t - n * .15} ${e - n * .62} ${t - n * 1.05} ${e} ${t - n * .28} C ${e + n * .62} ${t - n * 1.05} ${e + n * 1.3} ${t - n * .15} ${e} ${t + n * .75} Z`;
}
function ze({ kind: e, cx: t, cy: n }) {
	return e === "heart" ? /* @__PURE__ */ g("path", {
		d: Z(t, n, 20),
		fill: "#e11d48",
		stroke: "var(--color-ink)",
		strokeWidth: 4
	}) : e === "bomb" ? /* @__PURE__ */ _("g", {
		stroke: "var(--color-ink)",
		strokeWidth: 4,
		children: [
			/* @__PURE__ */ g("circle", {
				cx: t,
				cy: n + 4,
				r: 17,
				fill: "var(--color-ink)"
			}),
			/* @__PURE__ */ g("line", {
				x1: t + 10,
				y1: n - 9,
				x2: t + 18,
				y2: n - 19,
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ g("circle", {
				cx: t + 20,
				cy: n - 22,
				r: 4,
				fill: "#fbbf24",
				stroke: "none"
			})
		]
	}) : /* @__PURE__ */ _("g", {
		stroke: "var(--color-ink)",
		strokeWidth: 4,
		children: [/* @__PURE__ */ g("rect", {
			x: t - 17,
			y: n - 17,
			width: 34,
			height: 34,
			rx: 8,
			fill: "#fbbf24"
		}), /* @__PURE__ */ g("circle", {
			cx: t,
			cy: n,
			r: 5,
			fill: "var(--color-ink)",
			stroke: "none"
		})]
	});
}
function Be({ x: e, y: t }) {
	return /* @__PURE__ */ _("g", {
		stroke: "var(--color-ink)",
		strokeWidth: 3.5,
		pointerEvents: "none",
		children: [/* @__PURE__ */ g("rect", {
			x: e + 30,
			y: t + 30,
			width: 40,
			height: 40,
			rx: 10,
			fill: "#fbbf24"
		}), /* @__PURE__ */ g("circle", {
			cx: e + 50,
			cy: t + 50,
			r: 6,
			fill: "var(--color-ink)",
			stroke: "none"
		})]
	});
}
function Ve({ x: e, y: t }) {
	return /* @__PURE__ */ _("g", {
		stroke: "var(--color-ink)",
		strokeWidth: 11,
		strokeLinecap: "round",
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ g("animate", {
				attributeName: "opacity",
				from: "0.2",
				to: "1",
				dur: "0.25s",
				fill: "freeze"
			}),
			/* @__PURE__ */ g("line", {
				x1: e + 20,
				y1: t + 20,
				x2: e + 80,
				y2: t + 80
			}),
			/* @__PURE__ */ g("line", {
				x1: e + 80,
				y1: t + 20,
				x2: e + 20,
				y2: t + 80
			})
		]
	});
}
function Q({ sheet: e, selection: t, eligible: n, onTapCell: r, readOnly: a, fitKey: o }) {
	let s = i(() => n?.map((e) => ({
		key: String(e),
		rect: Y(e)
	})), [n]), c = i(() => new Set(t ?? []), [t]);
	return /* @__PURE__ */ _(m, {
		sheetW: q,
		sheetH: J,
		eligible: s,
		onTapEligible: r ? (e) => r(Number(e)) : void 0,
		readOnly: a,
		fitKey: o,
		children: [
			/* @__PURE__ */ g("rect", {
				x: 0,
				y: 0,
				width: q,
				height: J,
				rx: 24,
				fill: "var(--color-surface)",
				stroke: "var(--color-ink)",
				strokeWidth: 5
			}),
			Ie.split("").map((e, t) => /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ g("text", {
					x: Fe(t),
					y: 36,
					textAnchor: "middle",
					dominantBaseline: "central",
					fontSize: 40,
					fontWeight: 900,
					fill: "var(--color-ink)",
					children: e
				}), t === 7 && /* @__PURE__ */ g("rect", {
					x: Fe(t) - 24,
					y: 56,
					width: 48,
					height: 8,
					rx: 4,
					fill: "var(--color-ink)"
				})]
			}, e)),
			Array.from({ length: 105 }, (e, t) => {
				let n = Y(t);
				return /* @__PURE__ */ g("rect", {
					x: n.x,
					y: n.y,
					width: n.w,
					height: n.h,
					rx: 14,
					fill: X[A[t]],
					stroke: "var(--color-ink)",
					strokeWidth: t % 15 == 7 ? 6 : 3
				}, t);
			}),
			[...j].map((e) => {
				let t = Y(e);
				return /* @__PURE__ */ g("polygon", {
					points: Re(t.x + 50, t.y + 50, 26),
					fill: "#ffffff",
					stroke: "var(--color-ink)",
					strokeWidth: 4,
					pointerEvents: "none"
				}, `s${e}`);
			}),
			[...M].map((e) => {
				let t = Y(e);
				return /* @__PURE__ */ g(Be, {
					x: t.x,
					y: t.y
				}, `u${e}`);
			}),
			Le.split("").map((t, n) => {
				let r = Pe(n), i = e.rowsDone[n];
				return /* @__PURE__ */ _("g", { children: [
					/* @__PURE__ */ g("rect", {
						x: r.x,
						y: r.y,
						width: r.w,
						height: r.h,
						rx: 14,
						fill: "var(--color-paper)",
						stroke: "var(--color-ink)",
						strokeWidth: 3,
						opacity: i ? .45 : 1
					}),
					/* @__PURE__ */ g("text", {
						x: r.x + 24,
						y: r.y + 50,
						textAnchor: "middle",
						dominantBaseline: "central",
						fontSize: 34,
						fontWeight: 900,
						fill: "var(--color-ink)",
						pointerEvents: "none",
						children: t
					}),
					/* @__PURE__ */ g(ze, {
						kind: F[n],
						cx: r.x + 96 - 32,
						cy: r.y + 50
					}),
					i && /* @__PURE__ */ g("line", {
						x1: r.x + 6,
						y1: r.y + 100 - 14,
						x2: r.x + 96 - 6,
						y2: r.y + 14,
						stroke: "var(--color-ink)",
						strokeWidth: 7,
						strokeLinecap: "round",
						pointerEvents: "none"
					})
				] }, t);
			}),
			O.map((t, n) => {
				let r = 72 + n * 142, i = e.colorsDone[t];
				return /* @__PURE__ */ _("g", { children: [
					/* @__PURE__ */ g("rect", {
						x: Ne,
						y: r,
						width: 96,
						height: 100,
						rx: 14,
						fill: X[t],
						stroke: "var(--color-ink)",
						strokeWidth: 3,
						opacity: i ? .55 : 1
					}),
					/* @__PURE__ */ g("text", {
						x: Ne + 48,
						y: r + 50,
						textAnchor: "middle",
						dominantBaseline: "central",
						fontSize: 34,
						fontWeight: 900,
						fill: "var(--color-ink)",
						pointerEvents: "none",
						children: i ? e.colorPts[t] : "5|3"
					}),
					i && /* @__PURE__ */ g("line", {
						x1: 1760,
						y1: r + 100 - 14,
						x2: 1840,
						y2: r + 14,
						stroke: "var(--color-ink)",
						strokeWidth: 7,
						strokeLinecap: "round",
						pointerEvents: "none"
					})
				] }, t);
			}),
			Array.from({ length: 15 }, (t, n) => {
				let r = 120 + n * 108, i = e.colsDone[n];
				return /* @__PURE__ */ _("g", { children: [
					/* @__PURE__ */ g("rect", {
						x: r,
						y: 836,
						width: 100,
						height: 56,
						rx: 10,
						fill: "var(--color-paper)",
						stroke: "var(--color-ink)",
						strokeWidth: i ? 4 : 2.5,
						opacity: i ? 1 : .75
					}),
					i ? /* @__PURE__ */ g("text", {
						x: r + 50,
						y: 864,
						textAnchor: "middle",
						dominantBaseline: "central",
						fontSize: 30,
						fontWeight: 900,
						fill: "var(--color-ink)",
						pointerEvents: "none",
						children: e.colPts[n] + e.colHeart[n]
					}) : /* @__PURE__ */ _("text", {
						x: r + 50,
						y: 864,
						textAnchor: "middle",
						dominantBaseline: "central",
						fontSize: 24,
						fontWeight: 800,
						fill: "var(--color-ink)",
						opacity: .55,
						pointerEvents: "none",
						children: [
							N[n],
							"|",
							P[n]
						]
					}),
					i && e.colHeart[n] > 0 && /* @__PURE__ */ g("path", {
						d: Z(r + 100 - 14, 848, 7),
						fill: "#e11d48",
						pointerEvents: "none"
					})
				] }, n);
			}),
			Array.from({ length: 5 }, (t, n) => /* @__PURE__ */ g("path", {
				d: Z(160 + n * 88, 938, 24),
				fill: n < e.hearts ? "#e11d48" : "transparent",
				stroke: "var(--color-ink)",
				strokeWidth: 4,
				opacity: n < e.hearts ? 1 : .35,
				pointerEvents: "none"
			}, n)),
			Array.from({ length: 6 }, (t, n) => {
				let r = n >= e.jokers, i = 120 + n * 64;
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					children: [/* @__PURE__ */ g("text", {
						x: i + 24,
						y: 1008,
						textAnchor: "middle",
						dominantBaseline: "central",
						fontSize: 40,
						fontWeight: 900,
						fill: "var(--color-ink)",
						opacity: r ? .3 : 1,
						children: "!"
					}), r && /* @__PURE__ */ g("line", {
						x1: i + 4,
						y1: 1024,
						x2: i + 44,
						y2: 992,
						stroke: "var(--color-ink)",
						strokeWidth: 6,
						strokeLinecap: "round"
					})]
				}, n);
			}),
			Array.from({ length: 10 }, (t, n) => {
				let r = 560 + n * 56, i = n < e.diceUsed, a = n < e.diceCircled;
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					children: [
						/* @__PURE__ */ g("rect", {
							x: r,
							y: 986,
							width: 44,
							height: 44,
							rx: 10,
							fill: a ? "var(--color-paper)" : "transparent",
							stroke: "var(--color-ink)",
							strokeWidth: a ? 4 : 2.5,
							opacity: a ? 1 : .3
						}),
						/* @__PURE__ */ g("circle", {
							cx: r + 22,
							cy: 1008,
							r: 7,
							fill: "var(--color-ink)",
							opacity: a ? 1 : .3
						}),
						i && /* @__PURE__ */ _("g", {
							stroke: "var(--color-ink)",
							strokeWidth: 6,
							strokeLinecap: "round",
							children: [/* @__PURE__ */ g("line", {
								x1: r + 8,
								y1: 994,
								x2: r + 36,
								y2: 1022
							}), /* @__PURE__ */ g("line", {
								x1: r + 36,
								y1: 994,
								x2: r + 8,
								y2: 1022
							})]
						})
					]
				}, n);
			}),
			e.crossed.map((e, t) => {
				if (!e) return null;
				let n = Y(t);
				return /* @__PURE__ */ g(Ve, {
					x: n.x,
					y: n.y
				}, `x${t}`);
			}),
			[...c].map((e) => {
				let t = Y(e);
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					opacity: .7,
					children: [/* @__PURE__ */ g("rect", {
						x: t.x,
						y: t.y,
						width: t.w,
						height: t.h,
						rx: 14,
						fill: "#ffffff",
						fillOpacity: .55
					}), /* @__PURE__ */ g(Ve, {
						x: t.x,
						y: t.y
					})]
				}, `p${e}`);
			})
		]
	});
}
//#endregion
//#region src/games/bravo/view-player.tsx
var He = {
	bomb: "💣",
	heart: "❤️",
	stars: "⭐",
	row3: "☰",
	block: "⬛"
}, Ue = {
	bomb: "games.bravo.face.bomb",
	heart: "games.bravo.face.heart",
	stars: "games.bravo.face.stars",
	row3: "games.bravo.face.row3",
	block: "games.bravo.face.block"
}, We = {
	bomb: "games.bravo.faceHint.bomb",
	heart: "games.bravo.faceHint.heart",
	stars: "games.bravo.faceHint.stars",
	row3: "games.bravo.faceHint.row3",
	block: "games.bravo.faceHint.block"
}, Ge = {
	pink: "games.bravo.colors.pink",
	yellow: "games.bravo.colors.yellow",
	green: "games.bravo.colors.green",
	orange: "games.bravo.colors.orange",
	blue: "games.bravo.colors.blue"
}, Ke = [
	"pink",
	"yellow",
	"green",
	"orange",
	"blue"
];
function qe(e, t) {
	if (!e.dice) return null;
	let n = {
		colors: [
			0,
			1,
			2
		],
		numbers: [
			0,
			1,
			2
		],
		special: !0
	};
	if (e.phase === "activePick" && e.active === t) return n;
	if (e.phase === "othersPick" && e.active !== t && !e.done[t]) {
		if (e.throwNum <= 3 || e.taken?.passed) return n;
		let t = e.taken;
		return t ? {
			colors: [
				0,
				1,
				2
			].filter((e) => e !== t.color),
			numbers: [
				0,
				1,
				2
			].filter((e) => e !== t.number),
			special: !t.special
		} : null;
	}
	return null;
}
function Je() {
	let e = a(null), [t, r] = o("");
	return n(() => {
		let t = e.current;
		if (!t) return;
		let n = !0, i = new ResizeObserver(([e]) => {
			let t = Math.round(e.contentRect.width), i = Math.round(e.contentRect.height);
			if (!t || !i) return;
			let a = t + "x" + i;
			queueMicrotask(() => {
				n && r((e) => e === a ? e : a);
			});
		});
		return i.observe(t), () => {
			n = !1, i.disconnect();
		};
	}, []), [e, t];
}
function Ye(e) {
	let t = e.public;
	return /* @__PURE__ */ g(Xe, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Xe({ pub: e, members: t, myRid: n, send: r }) {
	let a = u(), s = (e) => t.find((t) => t.rid === e)?.name ?? e, [l, ee] = Je(), [m, h] = o(n), [v, y] = o({ kind: "idle" }), b = e.sheets[n], te = e.sheets[m] ?? b, x = e.active === n, S = qe(e, n), C = e.bombs[n] ?? 0, T = e.dice, E = `${e.phase}:${e.throwNum}:${+!!S}:${C}`, [ne, re] = o(E);
	ne !== E && (re(E), y(e.phase === "bombs" && C > 0 ? {
		kind: "bomb",
		cells: []
	} : { kind: "idle" }));
	let D = i(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t = 0; t < 105; t++) b.crossed[t] || e.set(z[t], (e.get(z[t]) ?? 0) + 1);
		return e;
	}, [b.crossed]), ie = i(() => {
		if (m !== n) return;
		let t = b.crossed, r = [], i = (e) => {
			r.includes(e) || r.push(e);
		};
		if (v.kind === "combo" && S) {
			if (v.color === null || v.number === null) return;
			for (let e of v.cells) i(e);
			if (v.cells.length >= v.number) return r;
			if (v.cells.length === 0) for (let e = 0; e < 105; e++) t[e] || A[e] !== v.color || (D.get(z[e]) ?? 0) < v.number || (L(e) === 7 || R(e).some((e) => t[e])) && i(e);
			else {
				let e = new Set(v.cells), n = z[v.cells[0]];
				for (let r = 0; r < 105; r++) t[r] || e.has(r) || z[r] !== n || R(r).some((t) => e.has(t)) && i(r);
			}
			return r;
		}
		if (v.kind === "special" && S?.special && T) {
			let e = T.special;
			if (e === "heart") return;
			if (e === "block") {
				for (let e = 0; e < 105; e++) !t[e] && V(t, e) !== null && i(e);
				return r;
			}
			for (let e of v.cells) i(e);
			let n = e === "bomb" ? 4 : e === "stars" ? 2 : 3;
			if (v.cells.length >= n) return r;
			for (let n = 0; n < 105; n++) if (!(t[n] || v.cells.includes(n))) {
				if (e === "bomb") {
					let e = [...v.cells, n].map(I), t = [...v.cells, n].map(L);
					Math.max(...e) - Math.min(...e) <= 1 && Math.max(...t) - Math.min(...t) <= 1 && i(n);
				} else e === "stars" ? j.has(n) && (L(n) === 7 || R(n).some((e) => t[e])) && i(n) : R(n).some((e) => t[e]) && (v.cells.length === 0 || I(n) === I(v.cells[0])) && i(n);
			}
			return r;
		}
		if (v.kind === "bomb" && e.phase === "bombs" && C > 0) {
			for (let e of v.cells) i(e);
			if (v.cells.length >= 4) return r;
			for (let e = 0; e < 105; e++) {
				if (t[e] || v.cells.includes(e)) continue;
				let n = [...v.cells, e].map(I), r = [...v.cells, e].map(L);
				Math.max(...n) - Math.min(...n) <= 1 && Math.max(...r) - Math.min(...r) <= 1 && i(e);
			}
			return r;
		}
	}, [
		v,
		b.crossed,
		n,
		m,
		S,
		T,
		e.phase,
		C,
		D
	]), ae = (e) => {
		if (v.kind === "combo") {
			let t = v.cells.indexOf(e);
			y({
				...v,
				cells: t >= 0 ? v.cells.slice(0, t) : [...v.cells, e]
			});
		} else if (v.kind === "special") {
			if (T?.special === "block") y({
				kind: "special",
				cells: [e]
			});
			else {
				let t = v.cells.indexOf(e);
				y({
					kind: "special",
					cells: t >= 0 ? v.cells.filter((t) => t !== e) : [...v.cells, e]
				});
			}
		} else if (v.kind === "bomb") {
			let t = v.cells.indexOf(e);
			y({
				kind: "bomb",
				cells: t >= 0 ? v.cells.filter((t) => t !== e) : [...v.cells, e]
			});
		}
	}, oe = i(() => v.kind === "special" && T?.special === "block" && v.cells.length === 1 ? V(b.crossed, v.cells[0]) ?? v.cells : "cells" in v ? v.cells : [], [
		v,
		T,
		b.crossed
	]), se = (e) => {
		if (!S?.colors.includes(e) || !T) return;
		let t = T.colors[e], n = v.kind === "combo" ? v : {
			kind: "combo",
			colorDie: null,
			numberDie: null,
			color: null,
			number: null,
			cells: []
		};
		n.kind === "combo" && (n.colorDie === e ? y({
			...n,
			colorDie: null,
			color: null,
			cells: []
		}) : y({
			...n,
			colorDie: e,
			color: t === "X" ? null : t,
			cells: []
		}));
	}, ce = (e) => {
		if (!S?.numbers.includes(e) || !T) return;
		let t = T.numbers[e], n = v.kind === "combo" ? v : {
			kind: "combo",
			colorDie: null,
			numberDie: null,
			color: null,
			number: null,
			cells: []
		};
		n.kind === "combo" && (n.numberDie === e ? y({
			...n,
			numberDie: null,
			number: null,
			cells: []
		}) : y({
			...n,
			numberDie: e,
			number: t === "?" ? null : t,
			cells: []
		}));
	}, le = () => {
		!S?.special || b.diceCircled - b.diceUsed <= 0 || y({
			kind: "special",
			cells: []
		});
	}, O = "info", k = "";
	return e.phase === "roll" ? x ? (O = "accent", k = a("games.bravo.rollPrompt")) : k = a("games.bravo.waitingActive", { name: s(e.active) }) : e.phase === "activePick" ? x ? (O = "accent", k = a("games.bravo.pickPrompt")) : k = a("games.bravo.waitingActive", { name: s(e.active) }) : e.phase === "othersPick" ? S ? (O = "accent", k = a("games.bravo.othersPrompt")) : k = a("games.bravo.waitingOthers") : e.phase === "bombs" && (C > 0 ? (O = "accent", k = a("games.bravo.bombPrompt")) : k = a("games.bravo.waitingBombs")), /* @__PURE__ */ g("div", {
		className: "br-view",
		children: /* @__PURE__ */ g(f, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ g(d, {
				tone: O,
				text: k,
				chip: a("games.bravo.throwChip", { n: e.throwNum }),
				accent: w.accent
			}),
			children: /* @__PURE__ */ _("div", {
				className: "br-table",
				children: [
					/* @__PURE__ */ g("div", {
						className: "br-players",
						children: /* @__PURE__ */ g(p, {
							variant: "plate",
							members: t,
							myRid: n,
							anchorOf: (e) => `seat:${e}`,
							onPick: (e) => h(e),
							picked: (e) => e === m,
							action: (t) => e.phase === "roll" || e.phase === "activePick" ? t === e.active ? "pending" : null : e.phase === "othersPick" ? t === e.active || e.done[t] ? "done" : "pending" : e.phase === "bombs" ? (e.bombs[t] ?? 0) > 0 ? "pending" : "done" : null,
							status: (t) => /* @__PURE__ */ _("span", {
								className: "br-total flex items-center gap-0.5 font-bold",
								children: [/* @__PURE__ */ g("span", {
									"aria-hidden": !0,
									children: "⭐"
								}), /* @__PURE__ */ g(c, {
									value: e.scores[t] ?? 0,
									className: "font-mono tabular-nums"
								})]
							})
						})
					}),
					/* @__PURE__ */ g("div", {
						ref: l,
						className: "br-paper",
						"aria-label": a("games.bravo.sheetAria"),
						children: /* @__PURE__ */ g("div", { children: /* @__PURE__ */ g(Q, {
							sheet: te,
							selection: m === n ? oe : [],
							eligible: ie,
							onTapCell: ae,
							readOnly: m !== n,
							fitKey: `bravo:${m}:${ee}`
						}) })
					}),
					/* @__PURE__ */ _("div", {
						className: "br-dock",
						children: [/* @__PURE__ */ g(Ze, {
							pub: e,
							pool: S,
							mode: v,
							specialLeft: b.diceCircled - b.diceUsed,
							onTapColor: se,
							onTapNumber: ce,
							onTapSpecial: le
						}), /* @__PURE__ */ _("div", {
							className: "br-actions",
							children: [
								e.phase === "roll" && x && /* @__PURE__ */ _("button", {
									type: "button",
									onClick: () => r({ type: "roll" }),
									className: "btn-base min-h-12 w-full text-base font-black text-white",
									style: { background: w.accent },
									children: ["🎲 ", a("games.bravo.roll")]
								}),
								S && v.kind === "idle" && /* @__PURE__ */ g("button", {
									type: "button",
									onClick: () => r({ type: "pass" }),
									className: "card min-h-12 w-full px-3 text-sm font-black",
									children: a("games.bravo.pass")
								}),
								v.kind === "combo" && T && S && /* @__PURE__ */ g($e, {
									mode: v,
									jokerCost: +(v.colorDie !== null && T.colors[v.colorDie] === "X") + +(v.numberDie !== null && T.numbers[v.numberDie] === "?"),
									jokers: b.jokers,
									onDeclare: (e) => y({
										...v,
										...e
									}),
									onConfirm: () => {
										if (v.colorDie === null || v.numberDie === null || v.color === null || v.number === null) return;
										let e = T.colors[v.colorDie], t = T.numbers[v.numberDie];
										r({
											type: "pick",
											colorDie: v.colorDie,
											numberDie: v.numberDie,
											...e === "X" ? { color: v.color } : {},
											...t === "?" ? { number: v.number } : {},
											cells: v.cells
										}), y({ kind: "idle" });
									},
									onCancel: () => y({ kind: "idle" })
								}),
								v.kind === "special" && T && /* @__PURE__ */ g(et, {
									face: T.special,
									cells: v.cells,
									onConfirm: () => {
										r({
											type: "special",
											cells: v.cells
										}), y({ kind: "idle" });
									},
									onCancel: () => y({ kind: "idle" })
								}),
								v.kind === "bomb" && e.phase === "bombs" && C > 0 && /* @__PURE__ */ g(tt, {
									cells: v.cells,
									onConfirm: () => {
										r({
											type: "bomb",
											cells: v.cells
										}), y({ kind: "idle" });
									},
									onGiveUp: () => {
										r({
											type: "bomb",
											cells: []
										}), y({ kind: "idle" });
									}
								})
							]
						})]
					})
				]
			})
		})
	});
}
function Ze({ pub: e, pool: t, mode: n, specialLeft: r, onTapColor: i, onTapNumber: a, onTapSpecial: o }) {
	let s = u(), c = e.dice, l = e.phase === "othersPick" && e.throwNum > 3 && !e.taken?.passed ? e.taken?.color : null, d = e.phase === "othersPick" && e.throwNum > 3 && !e.taken?.passed ? e.taken?.number : null, f = e.phase === "othersPick" && e.throwNum > 3 && !e.taken?.passed ? e.taken?.special ?? !1 : !1, p = n.kind === "combo" ? n.colorDie : null, ee = n.kind === "combo" ? n.numberDie : null, m = n.kind === "special", h = /* @__PURE__ */ g("span", { className: "br-die br-empty grid flex-none place-items-center rounded-lg border-2 border-dashed border-ink/30" });
	return /* @__PURE__ */ _("div", {
		className: "br-dice frame",
		children: [
			[
				0,
				1,
				2
			].map((e) => {
				let n = c?.colors[e];
				return n ? /* @__PURE__ */ g(Qe, {
					anchor: `die:c${e}`,
					aria: n === "X" ? "X" : s(Ge[n]),
					taken: l === e,
					tappable: !!t?.colors.includes(e),
					selected: p === e,
					onTap: () => i(e),
					children: n === "X" ? /* @__PURE__ */ g("span", {
						className: "grid size-full place-items-center rounded-md bg-ink text-lg font-black text-surface",
						children: "✕"
					}) : /* @__PURE__ */ g("span", {
						className: "size-full rounded-md border border-ink/40",
						style: { backgroundColor: X[n] }
					})
				}, `c${e}`) : /* @__PURE__ */ g("span", { children: h }, `c${e}`);
			}),
			/* @__PURE__ */ g("span", { className: "br-separator" }),
			[
				0,
				1,
				2
			].map((e) => {
				let n = c?.numbers[e];
				return n ? /* @__PURE__ */ g(Qe, {
					anchor: `die:n${e}`,
					aria: String(n),
					taken: d === e,
					tappable: !!t?.numbers.includes(e),
					selected: ee === e,
					onTap: () => a(e),
					children: /* @__PURE__ */ g("span", {
						className: "grid size-full place-items-center rounded-md bg-surface font-mono text-lg font-black text-ink",
						children: n
					})
				}, `n${e}`) : /* @__PURE__ */ g("span", { children: h }, `n${e}`);
			}),
			/* @__PURE__ */ g("span", { className: "br-separator" }),
			c ? /* @__PURE__ */ g(Qe, {
				anchor: "die:s",
				aria: s(Ue[c.special]),
				taken: f,
				tappable: !!t?.special && r > 0,
				selected: m,
				badge: r > 0 ? r : void 0,
				onTap: o,
				children: /* @__PURE__ */ g("span", {
					className: "grid size-full place-items-center rounded-md text-lg",
					style: { backgroundColor: "#ede9fe" },
					children: He[c.special]
				})
			}) : h
		]
	});
}
function Qe({ anchor: e, aria: t, taken: n, tappable: r, selected: i, badge: a, onTap: o, children: c }) {
	let { ref: l } = s(e), u = /* @__PURE__ */ _("span", {
		className: `br-die relative grid place-items-center rounded-lg border-3 border-ink p-0.5 ${n ? "opacity-30" : ""} ${i ? "ring-3 ring-ink ring-offset-1 ring-offset-paper" : ""}`,
		children: [
			c,
			n && /* @__PURE__ */ g("span", {
				className: "absolute inset-0 grid place-items-center text-xl font-black text-ink",
				children: "✕"
			}),
			a !== void 0 && /* @__PURE__ */ g("span", {
				className: "br-die-badge absolute -top-1.5 -right-1.5 grid size-4.5 place-items-center rounded-full border-2 border-ink bg-surface font-mono text-[9px] font-black",
				children: a
			})
		]
	});
	return /* @__PURE__ */ g("span", {
		ref: l,
		className: "inline-flex",
		children: r && !n ? /* @__PURE__ */ g("button", {
			type: "button",
			"aria-label": t,
			onClick: o,
			className: "transition-transform active:translate-y-0.5",
			children: u
		}) : u
	});
}
function $e({ mode: e, jokerCost: t, jokers: n, onDeclare: r, onConfirm: i, onCancel: a }) {
	let o = u(), s = e.colorDie !== null && e.color === null, c = e.numberDie !== null && e.number === null, l = e.colorDie !== null && e.numberDie !== null && !s && !c && e.number !== null && e.cells.length === e.number && t <= n;
	return /* @__PURE__ */ _("div", {
		className: "br-panel br-combo frame",
		children: [
			/* @__PURE__ */ _("div", {
				className: "br-panel-top",
				children: [
					/* @__PURE__ */ _("span", {
						className: "flex-1 text-xs font-bold",
						children: [e.number === null ? o("games.bravo.pickPrompt") : o("games.bravo.selectedCells", {
							n: e.cells.length,
							total: e.number
						}), t > 0 && ` · ${o("games.bravo.usesJoker", { n: t })}`]
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						disabled: !l,
						onClick: i,
						className: "btn-base min-h-11 px-4 text-sm font-black text-white disabled:opacity-40",
						style: { background: w.accent },
						children: o("games.bravo.confirm")
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						onClick: a,
						className: "btn-quiet min-h-11 px-3 text-xs font-bold",
						children: o("games.bravo.cancel")
					})
				]
			}),
			s && /* @__PURE__ */ _("div", {
				className: "br-declare",
				children: [/* @__PURE__ */ g("span", {
					className: "text-xs font-bold",
					children: o("games.bravo.chooseColor")
				}), /* @__PURE__ */ g("span", {
					className: "br-options",
					children: Ke.map((e) => /* @__PURE__ */ g("button", {
						type: "button",
						"aria-label": o(Ge[e]),
						onClick: () => r({ color: e }),
						className: "card grid min-h-11 flex-1 place-items-center px-1",
						children: /* @__PURE__ */ g("span", {
							className: "inline-block size-5 rounded border border-ink/60",
							style: { backgroundColor: X[e] }
						})
					}, e))
				})]
			}),
			c && /* @__PURE__ */ _("div", {
				className: "br-declare",
				children: [/* @__PURE__ */ g("span", {
					className: "text-xs font-bold",
					children: o("games.bravo.chooseNumber")
				}), /* @__PURE__ */ g("span", {
					className: "br-options",
					children: [
						1,
						2,
						3,
						4,
						5
					].map((e) => /* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => r({ number: e }),
						className: "card min-h-11 flex-1 px-1 font-mono text-sm font-black",
						children: e
					}, e))
				})]
			})
		]
	});
}
function et({ face: e, cells: t, onConfirm: n, onCancel: r }) {
	let i = u(), a = e === "heart" ? 0 : 1, o = e === "bomb" ? 4 : e === "stars" ? 2 : e === "row3" ? 3 : 1, s = e === "heart" || t.length >= a;
	return /* @__PURE__ */ _("div", {
		className: "br-panel br-panel-top frame",
		children: [
			/* @__PURE__ */ _("span", {
				className: "flex-1 text-xs font-bold",
				children: [i(We[e]), e !== "heart" && ` · ${i("games.bravo.selectedCells", {
					n: t.length,
					total: o
				})}`]
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				disabled: !s,
				onClick: n,
				className: "btn-base min-h-11 px-4 text-sm font-black text-white disabled:opacity-40",
				style: { background: w.accent },
				children: i("games.bravo.confirm")
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				onClick: r,
				className: "btn-quiet min-h-11 px-3 text-xs font-bold",
				children: i("games.bravo.cancel")
			})
		]
	});
}
function tt({ cells: e, onConfirm: t, onGiveUp: n }) {
	let r = u();
	return /* @__PURE__ */ _("div", {
		className: "br-panel br-panel-top frame",
		children: [
			/* @__PURE__ */ _("span", {
				className: "flex-1 text-xs font-bold",
				children: [
					r("games.bravo.faceHint.bomb"),
					" · ",
					r("games.bravo.selectedCells", {
						n: e.length,
						total: 4
					})
				]
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				disabled: e.length === 0,
				onClick: t,
				className: "btn-base min-h-11 px-4 text-sm font-black text-white disabled:opacity-40",
				style: { background: w.accent },
				children: ["💣 ", r("games.bravo.confirmBomb")]
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				onClick: n,
				className: "btn-quiet min-h-11 px-3 text-xs font-bold",
				children: r("games.bravo.pass")
			})
		]
	});
}
//#endregion
//#region src/games/bravo/bot.ts
function nt(e, t) {
	if (!e.dice) return null;
	let n = {
		colors: [
			0,
			1,
			2
		],
		numbers: [
			0,
			1,
			2
		],
		special: !0
	};
	if (e.phase === "activePick" && e.active === t) return n;
	if (e.phase === "othersPick" && e.active !== t && !e.done[t]) {
		if (e.throwNum <= 3 || e.taken?.passed) return n;
		let t = e.taken;
		return t ? {
			colors: [
				0,
				1,
				2
			].filter((e) => e !== t.color),
			numbers: [
				0,
				1,
				2
			].filter((e) => e !== t.number),
			special: !t.special
		} : null;
	}
	return null;
}
var rt = {
	die: 2.5,
	heart: 2.5,
	bomb: 3.5
};
function $(e, t, n) {
	if (n.length === 0) return 0;
	let r = [...e.crossed];
	for (let e of n) r[e] = !0;
	let i = n.length * .5;
	for (let e of n) M.has(e) && (i += 2.5), j.has(e) && (i += 2);
	let a = _e(r), o = e.hearts;
	for (let n = 0; n < a.length; n++) a[n] && !e.rowsDone[n] && (i += 5, t.rows[n] === null && (i += rt[F[n]], F[n] === "heart" && (o = Math.min(5, o + 1))));
	let s = ve(r);
	for (let n = 0; n < s.length; n++) s[n] && !e.colsDone[n] && (i += (t.cols[n] === null ? N[n] : P[n]) + o);
	let c = ye(r), l = 0;
	for (let n of Object.keys(c)) c[n] && !e.colorsDone[n] && (l += 1, i += t.colors[n] === null ? 5 : 3);
	let u = Object.values(e.colorsDone).filter(Boolean).length;
	return u + l >= 2 && u < 2 && (i += 4), i;
}
function it(e, t, n) {
	let r = t.dice;
	if (!r) return null;
	let i = /* @__PURE__ */ new Map();
	for (let t of n.colors) {
		let a = r.colors[t], o = a === "X" ? [
			"pink",
			"yellow",
			"green",
			"orange",
			"blue"
		] : [a];
		for (let s of n.numbers) {
			let n = r.numbers[s], c = n === "?" ? [
				1,
				2,
				3,
				4,
				5
			] : [n];
			for (let r of o) for (let o of c) {
				let c = +(a === "X") + +(n === "?");
				if (c > e.jokers) continue;
				let l = `${r}:${o}`, u = {
					colorDie: t,
					numberDie: s,
					cost: c,
					...a === "X" ? { color: r } : {},
					...n === "?" ? { number: o } : {}
				}, d = i.get(l);
				(!d || u.cost < d.cost) && i.set(l, u);
			}
		}
	}
	let a = null;
	for (let [n, r] of i) {
		let [i, o] = n.split(":"), s = Number(o), c = ge(e.crossed, i, s, 120);
		for (let n of c) {
			let i = $(e, t.firsts, n) - 1.5 * r.cost;
			(!a || i > a.value) && (a = {
				action: {
					type: "pick",
					colorDie: r.colorDie,
					numberDie: r.numberDie,
					...r.color ? { color: r.color } : {},
					...r.number === void 0 ? {} : { number: r.number },
					cells: n
				},
				value: i
			});
		}
	}
	return a;
}
function at(e, t) {
	let n = t.dice?.special;
	if (!n) return null;
	let r = e.crossed;
	if (n === "heart") return {
		action: {
			type: "special",
			cells: []
		},
		value: e.hearts >= 5 ? .5 : 3
	};
	if (n === "bomb") {
		let n = ot(r, t, e);
		return n.length === 0 ? null : {
			action: {
				type: "special",
				cells: n
			},
			value: $(e, t.firsts, n)
		};
	}
	if (n === "stars") {
		let n = [], i = 0;
		for (let a of j) if (!r[a]) for (let o of [void 0, ...j]) {
			if (o !== void 0 && (o <= a || r[o])) continue;
			let s = o === void 0 ? [a] : [a, o];
			if (!s.every((e) => e % 15 == 7 || R(e).some((e) => r[e]))) continue;
			let c = $(e, t.firsts, s);
			c > i && (i = c, n = s);
		}
		return n.length === 0 ? null : {
			action: {
				type: "special",
				cells: n
			},
			value: i
		};
	}
	if (n === "row3") {
		let n = [], i = 0;
		for (let a = 0; a < 7; a++) {
			let o = [];
			for (let e = 0; e < 15; e++) {
				let t = a * 15 + e;
				!r[t] && R(t).some((e) => r[e]) && o.push(t);
			}
			for (let r = 0; r < o.length; r++) for (let a = r; a < o.length; a++) for (let s = a; s < o.length; s++) {
				let c = [.../* @__PURE__ */ new Set([
					o[r],
					o[a],
					o[s]
				])], l = $(e, t.firsts, c);
				l > i && (i = l, n = c);
			}
		}
		return n.length === 0 ? null : {
			action: {
				type: "special",
				cells: n
			},
			value: i
		};
	}
	let i = null, a = 0, o = /* @__PURE__ */ new Set();
	for (let n = 0; n < 105; n++) {
		if (r[n]) continue;
		let s = V(r, n);
		if (!s) continue;
		let c = s[0];
		if (o.has(c)) continue;
		o.add(c);
		let l = $(e, t.firsts, s);
		l > a && (a = l, i = s);
	}
	return i ? {
		action: {
			type: "special",
			cells: [i[0]]
		},
		value: a
	} : null;
}
function ot(e, t, n) {
	let r = [], i = 0;
	for (let a = 0; a < 6; a++) for (let o = 0; o < 14; o++) {
		let s = [
			a * 15 + o,
			a * 15 + o + 1,
			(a + 1) * 15 + o,
			(a + 1) * 15 + o + 1
		].filter((t) => !e[t]);
		if (s.length === 0) continue;
		let c = $(n, t.firsts, s);
		c > i && (i = c, r = s);
	}
	return r;
}
var st = (e, t) => {
	let n = e.public, r = n.sheets[t.rid];
	if (!r || n.phase === "done") return null;
	let i = t.difficulty === "weak", a = (e) => e[Math.floor(Math.random() * e.length)];
	if (n.phase === "roll") return n.active === t.rid ? { action: { type: "roll" } } : null;
	if (n.phase === "bombs") return (n.bombs[t.rid] ?? 0) <= 0 ? null : { action: {
		type: "bomb",
		cells: ot(r.crossed, n, r)
	} };
	let o = nt(n, t.rid);
	if (!o) return null;
	let s = it(r, n, o), c = o.special && r.diceCircled - r.diceUsed > 0 ? at(r, n) : null;
	if (c && (c.value -= 2), i) {
		let e = [{ type: "pass" }];
		return s && e.push(s.action), c && c.value > 0 && e.push(c.action), { action: a(e) };
	}
	let l = s ? c ? s.value >= c.value ? s : c : s : c;
	return !l || l.value < .3 ? { action: { type: "pass" } } : { action: l.action };
}, ct = {
	bomb: "games.bravo.face.bomb",
	heart: "games.bravo.face.heart",
	stars: "games.bravo.face.stars",
	row3: "games.bravo.face.row3",
	block: "games.bravo.face.block"
}, lt = {
	pink: "games.bravo.colors.pink",
	yellow: "games.bravo.colors.yellow",
	green: "games.bravo.colors.green",
	orange: "games.bravo.colors.orange",
	blue: "games.bravo.colors.blue"
}, ut = (e, t, n) => {
	switch (e.type) {
		case "roll": return n("games.bravo.roll");
		case "pass": return n("games.bravo.hintPass");
		case "bomb": return n("games.bravo.hintBomb");
		case "special": {
			let e = t.public.dice?.special;
			return n("games.bravo.hintSpecial", { face: e ? n(ct[e]) : "?" });
		}
		case "pick": {
			let r = t.public.dice?.colors[e.colorDie], i = e.color ?? (r && r !== "X" ? r : null);
			return n("games.bravo.hintPick", {
				color: i ? n(lt[i]) : "?",
				n: e.cells.length
			});
		}
		default: return "";
	}
}, dt = {
	die: "+🎲",
	heart: "+❤️",
	bomb: "+💣"
}, ft = {
	roll(e, t) {
		if (!e.data?.dice) return null;
		let n = [
			"die:c0",
			"die:c1",
			"die:c2",
			"die:n0",
			"die:n1",
			"die:n2",
			"die:s"
		].map((e) => t.anchor(e)).filter((e) => e !== null);
		return n.length === 0 ? null : {
			ms: 700,
			node: /* @__PURE__ */ g(h, { children: n.map((e, t) => /* @__PURE__ */ g(y, {
				at: e,
				ms: 600,
				delay: t * 50
			}, t)) })
		};
	},
	cross(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || !Array.isArray(n?.cells) ? null : {
			ms: 700,
			node: /* @__PURE__ */ g(v, {
				at: r,
				ms: 700,
				children: /* @__PURE__ */ _("span", {
					style: { fontSize: Math.max(14, Math.min(r.w, r.h) * .32) },
					className: "font-mono font-black",
					children: ["✕×", n.cells.length]
				})
			})
		};
	},
	gain(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.what != "string" ? null : {
			ms: 800,
			node: /* @__PURE__ */ g(v, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ g("span", {
					style: { fontSize: Math.max(14, Math.min(r.w, r.h) * .32) },
					className: "text-done-ink",
					children: dt[n.what] ?? "+1"
				})
			})
		};
	},
	score(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.pts != "number" ? null : {
			ms: 800,
			node: /* @__PURE__ */ g(v, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ _("span", {
					style: { fontSize: Math.max(14, Math.min(r.w, r.h) * .32) },
					className: "font-mono font-black text-done-ink",
					children: ["+", n.pts]
				})
			})
		};
	}
};
//#endregion
//#region src/games/bravo/game-over-row.tsx
function pt({ public: e, rid: t }) {
	let n = u(), r = e.sheets[t];
	if (!r) return null;
	let i = H(r), a = [
		[n("games.bravo.brkColors"), i.colors],
		[n("games.bravo.brkCols"), i.cols],
		[n("games.bravo.brkRows"), i.rows],
		[n("games.bravo.brkHearts"), i.hearts],
		[n("games.bravo.brkJokers"), i.jokers],
		[n("games.bravo.brkDice"), i.dice],
		[n("games.bravo.brkStars"), i.stars]
	];
	return /* @__PURE__ */ _("div", {
		className: "mt-1.5 flex flex-col gap-1.5",
		children: [/* @__PURE__ */ _("div", {
			className: "flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px] font-bold",
			children: [a.map(([e, t]) => /* @__PURE__ */ _("span", {
				className: "flex items-center gap-0.5",
				children: [/* @__PURE__ */ g("span", {
					className: "text-ink/50",
					children: e
				}), /* @__PURE__ */ g("span", {
					className: `font-mono tabular-nums ${t < 0 ? "text-rose-600" : ""}`,
					children: t > 0 ? `+${t}` : t
				})]
			}, e)), /* @__PURE__ */ g("span", {
				className: "ml-auto font-mono text-xs font-black tabular-nums",
				children: i.total
			})]
		}), /* @__PURE__ */ g("div", {
			className: "frame pointer-events-none overflow-hidden",
			"aria-hidden": !0,
			children: /* @__PURE__ */ g("div", {
				style: { aspectRatio: `${q} / ${J}` },
				children: /* @__PURE__ */ g(Q, {
					sheet: r,
					readOnly: !0,
					fitKey: `over-${t}`
				})
			})
		})]
	});
}
//#endregion
//#region src/games/bravo/game-over.tsx
function mt() {
	let e = a(null), [t, r] = o("");
	return n(() => {
		let t = e.current;
		if (!t) return;
		let n = !0, i = new ResizeObserver(([e]) => {
			let t = Math.round(e.contentRect.width), i = Math.round(e.contentRect.height);
			if (!t || !i) return;
			let a = t + "x" + i;
			queueMicrotask(() => {
				n && r((e) => e === a ? e : a);
			});
		});
		return i.observe(t), () => {
			n = !1, i.disconnect();
		};
	}, []), [e, t];
}
function ht(e) {
	let t = ce.safeParse(e.public);
	return !t.success || t.data.phase !== "done" || !e.result.ranking.length || e.result.ranking.some((e) => !t.data.sheets[e]) ? /* @__PURE__ */ g(C, {
		result: e.result,
		members: e.members,
		myRid: e.myRid,
		accent: w.accent,
		onPlayAgain: e.onPlayAgain,
		onBackToLobby: e.onBackToLobby,
		renderRowExtra: t.success ? (n) => /* @__PURE__ */ g(pt, {
			public: t.data,
			rid: n,
			myRid: e.myRid
		}) : void 0
	}) : /* @__PURE__ */ g(_t, {
		...e,
		pub: t.data
	});
}
function gt({ sheet: e }) {
	let t = u(), n = H(e), r = [
		[t("games.bravo.brkColors"), n.colors],
		[t("games.bravo.brkCols"), n.cols],
		[t("games.bravo.brkRows"), n.rows],
		[t("games.bravo.brkHearts"), n.hearts],
		[t("games.bravo.brkJokers"), n.jokers],
		[t("games.bravo.brkDice"), n.dice],
		[t("games.bravo.brkStars"), n.stars]
	];
	return /* @__PURE__ */ g("dl", {
		className: "br-final-breakdown",
		children: r.map(([e, t]) => /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: e }), /* @__PURE__ */ g("dd", {
			"data-negative": t < 0,
			children: t > 0 ? "+" + t : t
		})] }, e))
	});
}
function _t({ pub: e, result: t, members: n, myRid: i, onPlayAgain: a, onBackToLobby: s }) {
	let c = u(), d = l((e) => e.locale), [p, m] = o(i), h = t.ranking.includes(p) ? p : t.ranking.includes(i) ? i : t.ranking[0], v = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? ee(t, d) : e;
	}, [y, C] = mt(), T = r();
	return /* @__PURE__ */ _("div", {
		className: "br-final",
		children: [t.winner.length > 0 && /* @__PURE__ */ g(S, {}), /* @__PURE__ */ g(f, {
			adaptive: !0,
			scroll: !1,
			className: "br-final-screen",
			actionsHeight: "br-final-action-height",
			banner: /* @__PURE__ */ g("header", {
				className: "br-final-heading",
				children: /* @__PURE__ */ g("h1", { children: c("session.result.title") })
			}),
			actions: a || s ? /* @__PURE__ */ _("div", {
				className: "br-final-actions",
				children: [a && /* @__PURE__ */ g("button", {
					type: "button",
					className: "btn-base text-white",
					style: { background: w.accent },
					onClick: a,
					children: c("session.result.playAgain")
				}), s && /* @__PURE__ */ g("button", {
					type: "button",
					className: "btn-quiet",
					onClick: s,
					children: c("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ g("p", {
				className: "br-final-wait",
				children: c("session.result.waitHost")
			}),
			children: /* @__PURE__ */ _("div", {
				className: "br-final-main",
				children: [/* @__PURE__ */ g("ol", {
					className: "br-final-ranking",
					"aria-label": c("games.bravo.overRanking"),
					children: t.ranking.map((r, a) => {
						let o = n.find((e) => e.rid === r), s = t.winner.includes(r), l = t.autopilot?.[r];
						return /* @__PURE__ */ _("li", {
							"data-winner": s,
							"data-selected": r === h,
							children: [/* @__PURE__ */ _("div", {
								className: "br-final-person",
								children: [
									/* @__PURE__ */ g("span", {
										className: "br-final-rank",
										children: a + 1
									}),
									/* @__PURE__ */ _("span", {
										className: "br-final-avatar",
										style: { backgroundColor: x[(o?.colorIndex ?? 0) % x.length].hex },
										children: [o && /* @__PURE__ */ g("img", {
											src: b[o.avatar % b.length],
											alt: "",
											draggable: !1
										}), s && /* @__PURE__ */ g("b", {
											"aria-hidden": !0,
											children: "👑"
										})]
									}),
									/* @__PURE__ */ _("span", {
										className: "br-final-name",
										children: [/* @__PURE__ */ g("strong", {
											title: v(r),
											children: v(r)
										}), /* @__PURE__ */ _("span", { children: [r === i && /* @__PURE__ */ g("small", { children: c("lobby.you") }), l !== void 0 && l > 0 && /* @__PURE__ */ _("small", {
											className: "br-final-autopilot",
											children: [/* @__PURE__ */ g(te, { size: 14 }), c("session.autopilot.share", { n: Math.round(l * 100) })]
										})] })]
									}),
									t.scores?.[r] !== void 0 && /* @__PURE__ */ g("b", {
										className: "br-final-score",
										"aria-label": c("games.bravo.overScore", { n: t.scores[r] }),
										children: t.scores[r]
									}),
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "br-final-select",
										"aria-label": c("games.bravo.overSelect", { name: v(r) }),
										"aria-pressed": r === h,
										"aria-controls": T,
										onClick: () => m(r)
									})
								]
							}), /* @__PURE__ */ _("div", {
								className: "br-final-thumbnail",
								children: [/* @__PURE__ */ g(gt, { sheet: e.sheets[r] }), /* @__PURE__ */ g("div", {
									className: "br-final-small-paper",
									"aria-hidden": !0,
									children: /* @__PURE__ */ g(Q, {
										sheet: e.sheets[r],
										readOnly: !0,
										fitKey: "over-small:" + r
									})
								})]
							})]
						}, r);
					})
				}), h && /* @__PURE__ */ _("section", {
					id: T,
					className: "br-final-detail",
					"aria-label": c("games.bravo.overSheet", { name: v(h) }),
					children: [
						/* @__PURE__ */ g("h2", {
							title: c("games.bravo.overSheet", { name: v(h) }),
							children: c("games.bravo.overSheet", { name: v(h) })
						}),
						/* @__PURE__ */ g(gt, { sheet: e.sheets[h] }),
						/* @__PURE__ */ g("div", {
							ref: y,
							className: "br-final-paper",
							children: /* @__PURE__ */ g("div", { children: /* @__PURE__ */ g(Q, {
								sheet: e.sheets[h],
								readOnly: !0,
								fitKey: h + ":over:" + C
							}) })
						})
					]
				})]
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/bravo/entry.tsx
var vt = {
	definition: Me,
	View: Ye,
	bot: st,
	describe: ut,
	fx: ft,
	OverView: ht,
	RowView: pt,
	locales: {
		zh: {
			name: "Bravo!",
			desc: "《再来一次》续作骰写:连通涂格,抢行列与颜色奖励",
			rules: "目标:在计分纸上涂格,填满行、列与同色区域得分,总分最高者获胜。\n准备:每人一张计分纸,15 列(A-O)、7 行(P-V),起始列为 H 列。\n流程:\n· 主动玩家掷全部 7 颗骰子(3 颜色、3 数字、1 特殊),先选 1 颗颜色骰和 1 颗数字骰,或选特殊骰。\n· 其他玩家从剩余的骰子中选择。前三次掷骰中，所有玩家均可从全部骰子中选择；主动玩家放弃选择时，其他玩家也可从全部骰子中选择。\n· 普通组合:按数字骰点数涂该颜色恰好数量的格子;这些格必须同色同块、横竖连通,且至少一格在 H 列或与已有涂格相邻。\n· 颜色骰的黑 X 与数字骰的 ? 是百搭:每用 1 个百搭划掉 1 个「!」(共 6 个)。\n· 选特殊骰则执行其骰面效果,并消耗 1 个已圈的特殊骰(开局已圈 1 个,涂到金色骰子格可再圈 1 个)。\n特殊骰:\n· 炸弹:在任意 2 行 2 列的方块区域内涂至多 4 格,无需与已有涂格相邻。\n· 爱心:圈 1 颗爱心;之后每完成一列,额外获得当时已圈爱心数的加分。\n· 双星:涂至多 2 个星标格,须与已有涂格相邻或在 H 列。\n· 同行三格:涂同一行至多 3 格,每格须与已有涂格相邻。\n· 整块:涂满一个与已有涂格相邻的同色块。\n计分:\n· 列:首先完成该列的玩家获得该列上方标示的分值，其他完成该列的玩家获得下方标示的分值;完成列时额外获得等于当时已圈爱心数量的分数。\n· 行:每行 5 分;首个完成该行的玩家获得行奖励(特殊骰/炸弹/爱心)。\n· 颜色:首个涂满某色的玩家获得 5 分,其余涂满的玩家获得 3 分。\n· 同一掷内多人同时先完成同一行、列或颜色,共享先手待遇。\n结束:有玩家涂满第 2 种颜色时,该掷结束后游戏结束。\n结算:颜色分、列分、行分、爱心分相加;每个剩余「!」加 1 分。\n· 每个已圈未用的特殊骰加 2 分,每个未涂星标格扣 2 分;总分相同时，剩余“!”标记较多的玩家获胜。",
			throwChip: "第 {{n}} 掷",
			roll: "掷骰",
			rollPrompt: "轮到你:掷骰",
			pickPrompt: "选 1 颜色骰 + 1 数字骰,或用特殊骰",
			waitingActive: "等 {{name}} 先选…",
			othersPrompt: "选一组骰子涂格,或弃权",
			waitingOthers: "等其他人选择…",
			bombPrompt: "行奖励:放炸弹(同一 2 行 2 列区域内至多 4 格)",
			waitingBombs: "等炸弹落格…",
			pass: "弃权",
			confirm: "确认涂格",
			confirmBomb: "引爆炸弹",
			cancel: "取消",
			chooseColor: "X 百搭:选颜色",
			chooseNumber: "? 百搭:选数字",
			selectedCells: "已选 {{n}}/{{total}} 格",
			specialLeft: "特殊骰(可用 {{n}})",
			usesJoker: "耗 {{n}} 个「!」",
			colors: {
				pink: "粉",
				yellow: "黄",
				green: "绿",
				orange: "橙",
				blue: "蓝"
			},
			face: {
				bomb: "炸弹",
				heart: "爱心",
				stars: "双星",
				row3: "同行三格",
				block: "整块"
			},
			faceHint: {
				bomb: "点选同一 2 行 2 列区域内的格子(1-4 格)",
				heart: "圈 1 颗爱心(每完成一列按爱心数加分)",
				stars: "点选 1-2 个星标格(须相邻或在 H 列)",
				row3: "点选同一行 1-3 格(每格须与已涂格相邻)",
				block: "点选一个同色块,整块涂满(须与已涂格相邻)"
			},
			heartsBar: "爱心",
			jokersBar: "百搭",
			diceBar: "特殊骰",
			sheetAria: "计分纸",
			hintPick: "用{{color}}骰涂 {{n}} 格",
			hintSpecial: "用特殊骰:{{face}}",
			hintPass: "弃权",
			hintBomb: "炸弹落格",
			brkColors: "颜色",
			brkCols: "列",
			brkRows: "行",
			brkHearts: "爱心",
			brkJokers: "百搭",
			brkDice: "特殊骰",
			brkStars: "星标",
			overRanking: "最终排名",
			overScore: "总分 {{n}}",
			overSelect: "查看{{name}}的计分纸",
			overSheet: "{{name}}的计分纸",
			errNotYourTurn: "现在轮不到你",
			errNoDice: "这些骰子现在不能选",
			errBadCells: "这些格子不符合涂格规则",
			errNoJoker: "「!」不够,用不了百搭",
			errNoSpecial: "没有可用的特殊骰",
			errOver: "本局已结束"
		},
		en: {
			name: "Bravo!",
			desc: "Roll-and-write sequel to Encore!: cross connected blocks, race for row, column and color bonuses",
			rules: "Goal: Cross off boxes on your sheet to complete rows, columns and same-color regions. Highest total score wins.\nSetup: Each player gets a sheet: 15 columns (A-O) by 7 rows (P-V). Column H is the starting column.\nPlay:\n· The active player rolls all 7 dice (3 color, 3 number, 1 special), then takes 1 color die and 1 number die, or the special die.\n· Everyone else picks from the remaining dice; in the first 3 throws everyone picks from all dice, and if the active player passes, the others also pick from all dice.\n· Color + number combo: cross exactly that many boxes of that color. They must form one connected group inside a single color block, with at least one box in column H or orthogonally adjacent to an existing cross.\n· The black X on color dice and the ? on number dice are jokers: each joker used crosses out one \"!\" (you have 6).\n· Choosing the special die applies its face effect and spends one circled special die (you start with one circled; crossing a golden die box circles another).\nSpecial die:\n· Bomb: cross up to 4 boxes inside any single 2-by-2 area, no adjacency required.\n· Heart: circle a heart; whenever you complete a column later, gain bonus points equal to your circled hearts at that moment.\n· Two stars: cross up to 2 star boxes, adjacent to an existing cross or in column H.\n· Three in a row: cross up to 3 boxes in one row, each adjacent to an existing cross.\n· Color block: cross an entire color block adjacent to an existing cross.\nScoring:\n· Columns: the first player(s) to complete a column get the upper value, later players the lower value; completing a column also adds your current circled-heart count.\n· Rows: each completed row is worth 5 points; the first player(s) to complete a row also gain its bonus (special die / bomb / heart).\n· Colors: the first player(s) to finish a color get 5 points, everyone else who finishes it gets 3.\n· Players completing the same row, column or color on the same throw all share the first finisher bonus.\nEnd: the game ends after the throw in which a player completes their second color.\nFinal score: add color, column, row and heart points; gain 1 point per unused \"!\".\n· Gain 2 per circled unused special die and lose 2 per uncrossed star box; ties are broken by remaining \"!\".",
			throwChip: "Throw {{n}}",
			roll: "Roll",
			rollPrompt: "Your turn: roll the dice",
			pickPrompt: "Pick 1 color die + 1 number die, or use the special die",
			waitingActive: "Waiting for {{name}} to pick first…",
			othersPrompt: "Pick a dice combo to cross boxes, or pass",
			waitingOthers: "Waiting for the others…",
			bombPrompt: "Row bonus: place the bomb (up to 4 boxes in one 2-by-2 area)",
			waitingBombs: "Waiting for bombs to land…",
			pass: "Pass",
			confirm: "Cross boxes",
			confirmBomb: "Detonate",
			cancel: "Cancel",
			chooseColor: "X joker: pick a color",
			chooseNumber: "? joker: pick a number",
			selectedCells: "Selected {{n}}/{{total}}",
			specialLeft: "Special die ({{n}} left)",
			usesJoker: "costs {{n}} \"!\"",
			colors: {
				pink: "Pink",
				yellow: "Yellow",
				green: "Green",
				orange: "Orange",
				blue: "Blue"
			},
			face: {
				bomb: "Bomb",
				heart: "Heart",
				stars: "Two stars",
				row3: "Three in a row",
				block: "Color block"
			},
			faceHint: {
				bomb: "Tap boxes inside one 2-by-2 area (1-4)",
				heart: "Circle 1 heart (column bonus grows per heart)",
				stars: "Tap 1-2 star boxes (adjacent or in column H)",
				row3: "Tap 1-3 boxes in one row (each next to a cross)",
				block: "Tap a color block to fill it (must touch a cross)"
			},
			heartsBar: "Hearts",
			jokersBar: "Jokers",
			diceBar: "Special dice",
			sheetAria: "Score sheet",
			hintPick: "Cross {{n}} boxes with the {{color}} die",
			hintSpecial: "Use special die: {{face}}",
			hintPass: "Pass",
			hintBomb: "Place the bomb",
			brkColors: "Colors",
			brkCols: "Columns",
			brkRows: "Rows",
			brkHearts: "Hearts",
			brkJokers: "Jokers",
			brkDice: "Dice",
			brkStars: "Stars",
			overRanking: "Final ranking",
			overScore: "Total score {{n}}",
			overSelect: "View {{name}}’s score sheet",
			overSheet: "{{name}}’s score sheet",
			errNotYourTurn: "Not your turn right now",
			errNoDice: "Those dice are not available",
			errBadCells: "Those boxes cannot be crossed",
			errNoJoker: "Not enough \"!\" left for a joker",
			errNoSpecial: "No special die available",
			errOver: "This game is over"
		}
	}
};
//#endregion
export { vt as default };
