import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useMemo as n, useState as r } from "react";
import { AVATARS as i } from "@bgparty/sdk/avatars";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { playTurn as l, useSoundEdge as u } from "@bgparty/sdk/sfx";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { seatName as f } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { botAvatarOf as g } from "@bgparty/sdk/lobby";
import { botPersonality as _ } from "@bgparty/sdk/bot-personality";
import { Floater as ee, FlySprite as v } from "@bgparty/sdk/fx/primitives";
import { Confetti as y } from "@bgparty/sdk/ui/confetti";
//#region src/games/salad/cards.ts
var b = [
	"P",
	"L",
	"C",
	"N",
	"T",
	"B"
], x = {
	P: "🫑",
	L: "🥬",
	C: "🥕",
	N: "🧅",
	T: "🍅",
	B: "🍆"
}, S = (...e) => ({
	k: "per",
	items: e
}), C = (e, ...t) => ({
	k: "set",
	vegs: t,
	pts: e
}), w = (e, t) => ({
	k: "most",
	veg: e,
	pts: t
}), T = (e, t) => ({
	k: "fewest",
	veg: e,
	pts: t
}), E = (e, t, n) => ({
	k: "evenOdd",
	veg: e,
	even: t,
	odd: n
}), D = {
	P: [
		w("L", 10),
		T("L", 7),
		E("L", 7, 3),
		S(["L", 2]),
		C(5, "L", "L"),
		C(5, "C", "N"),
		C(5, "B", "T"),
		S(["L", 1], ["N", 1]),
		S(["L", 1], ["T", 1]),
		S(["L", 3], ["C", -2]),
		C(8, "L", "L", "L"),
		C(8, "P", "L", "B"),
		C(8, "T", "L", "C"),
		S(["L", 2], ["N", 1], ["P", -2]),
		S(["L", 2], ["C", 2], ["N", -4]),
		S(["L", 3], ["N", -1], ["P", -1]),
		S(["L", 4], ["T", -2], ["B", -2]),
		{
			k: "totalMost",
			pts: 10
		}
	],
	L: [
		w("P", 10),
		T("P", 7),
		E("P", 7, 3),
		S(["P", 2]),
		C(5, "P", "P"),
		C(5, "B", "N"),
		C(5, "C", "T"),
		S(["P", 1], ["T", 1]),
		S(["P", 1], ["N", 1]),
		S(["P", 3], ["B", -2]),
		C(8, "P", "P", "P"),
		C(8, "L", "P", "C"),
		C(8, "N", "P", "B"),
		S(["P", 2], ["T", 1], ["L", -2]),
		S(["P", 2], ["B", 2], ["T", -4]),
		S(["P", 3], ["T", -1], ["L", -1]),
		S(["P", 4], ["N", -2], ["C", -2]),
		{
			k: "totalFewest",
			pts: 7
		}
	],
	C: [
		w("B", 10),
		T("B", 7),
		E("B", 7, 3),
		S(["B", 2]),
		C(5, "B", "B"),
		C(5, "T", "L"),
		C(5, "N", "P"),
		S(["B", 1], ["L", 1]),
		S(["B", 1], ["P", 1]),
		S(["B", 3], ["T", -2]),
		C(8, "B", "B", "B"),
		C(8, "C", "B", "N"),
		C(8, "P", "B", "T"),
		S(["B", 2], ["L", 1], ["C", -2]),
		S(["B", 2], ["T", 2], ["L", -4]),
		S(["B", 3], ["L", -1], ["C", -1]),
		S(["B", 4], ["P", -2], ["N", -2]),
		{
			k: "typeGe",
			min: 3,
			pts: 5
		}
	],
	B: [
		w("C", 10),
		T("C", 7),
		E("C", 7, 3),
		S(["C", 2]),
		C(5, "C", "C"),
		C(5, "L", "N"),
		C(5, "T", "P"),
		S(["C", 1], ["P", 1]),
		S(["C", 1], ["L", 1]),
		S(["C", 3], ["N", -2]),
		C(8, "C", "C", "C"),
		C(8, "B", "C", "T"),
		C(8, "L", "C", "N"),
		S(["C", 2], ["P", 1], ["B", -2]),
		S(["C", 2], ["N", 2], ["P", -4]),
		S(["C", 3], ["P", -1], ["B", -1]),
		S(["C", 4], ["L", -2], ["T", -2]),
		{
			k: "missing",
			pts: 5
		}
	],
	N: [
		w("T", 10),
		T("T", 7),
		E("T", 7, 3),
		S(["T", 2]),
		C(5, "T", "T"),
		C(5, "B", "L"),
		C(5, "C", "P"),
		S(["T", 1], ["C", 1]),
		S(["T", 1], ["B", 1]),
		S(["T", 3], ["L", -2]),
		C(8, "T", "T", "T"),
		C(8, "N", "T", "P"),
		C(8, "B", "T", "L"),
		S(["T", 2], ["C", 1], ["N", -2]),
		S(["T", 2], ["L", 2], ["C", -4]),
		S(["T", 3], ["C", -1], ["N", -1]),
		S(["T", 4], ["B", -1], ["P", -2]),
		{
			k: "typeGe",
			min: 2,
			pts: 3
		}
	],
	T: [
		w("N", 10),
		T("N", 7),
		E("N", 7, 3),
		S(["N", 2]),
		C(5, "N", "N"),
		C(5, "C", "L"),
		C(5, "B", "P"),
		S(["N", 1], ["B", 1]),
		S(["N", 1], ["C", 1]),
		S(["N", 3], ["P", -2]),
		C(8, "N", "N", "N"),
		C(8, "T", "N", "L"),
		C(8, "C", "N", "P"),
		S(["N", 2], ["B", 1], ["T", -2]),
		S(["N", 2], ["P", 2], ["B", -4]),
		S(["N", 3], ["B", -1], ["T", -1]),
		S(["N", 4], ["C", -2], ["L", -2]),
		C(12, "P", "L", "C", "N", "T", "B")
	]
};
b.length * 18;
function O(e) {
	return b[Math.floor(e / 18)];
}
function k(e) {
	return D[O(e)][e % 18];
}
var A = {
	2: 6,
	3: 9,
	4: 12,
	5: 15,
	6: 18
};
function j() {
	return {
		P: 0,
		L: 0,
		C: 0,
		N: 0,
		T: 0,
		B: 0
	};
}
function M(e) {
	let t = j();
	for (let n of e) n.up === "veg" && (t[O(n.card)] += 1);
	return t;
}
function N(e) {
	return b.reduce((t, n) => t + e[n], 0);
}
function P(e) {
	return e.map((t, n) => {
		let r = {
			most: {},
			fewest: {},
			totalMost: !0,
			totalFewest: !0
		}, i = N(t);
		for (let n of b) r.most[n] = e.every((e) => t[n] >= e[n]), r.fewest[n] = e.every((e) => t[n] <= e[n]);
		return e.forEach((e, t) => {
			t !== n && (N(e) > i && (r.totalMost = !1), N(e) < i && (r.totalFewest = !1));
		}), r;
	});
}
function F(e, t, n) {
	switch (e.k) {
		case "per": return e.items.reduce((e, [n, r]) => e + t[n] * r, 0);
		case "set": {
			let n = j();
			for (let t of e.vegs) n[t] += 1;
			let r = Infinity;
			for (let e of b) n[e] > 0 && (r = Math.min(r, Math.floor(t[e] / n[e])));
			return (r === Infinity ? 0 : r) * e.pts;
		}
		case "most": return n.most[e.veg] ? e.pts : 0;
		case "fewest": return n.fewest[e.veg] ? e.pts : 0;
		case "evenOdd": return t[e.veg] % 2 == 0 ? e.even : e.odd;
		case "totalMost": return n.totalMost ? e.pts : 0;
		case "totalFewest": return n.totalFewest ? e.pts : 0;
		case "typeGe": return b.filter((n) => t[n] >= e.min).length * e.pts;
		case "missing": return b.filter((e) => t[e] === 0).length * e.pts;
	}
}
function I(e, t) {
	let n = M(e), r = e.map((e) => e.up === "point" ? F(k(e.card), n, t) : 0);
	return {
		perCard: r,
		total: r.reduce((e, t) => e + t, 0)
	};
}
//#endregion
//#region src/games/salad/meta.ts
var L = {
	id: "salad",
	tier: "released",
	mechanics: ["drafting", "set-collection"],
	interactionTags: [],
	nameKey: "games.salad.name",
	descKey: "games.salad.desc",
	rulesKey: "games.salad.rules",
	icon: "🥗",
	iconImg: "games/salad.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/salad/en.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [3],
	accent: "#65a30d",
	releasedAt: "2026-09-15",
	search: {
		py: "de fen sha la",
		init: "dfsl"
	},
	hotseat: "cover"
}, R = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("takePoint"),
		pile: t.int().min(0).max(2)
	}),
	t.object({
		type: t.literal("takeVeggies"),
		slots: t.array(t.int().min(0).max(5)).min(1).max(2)
	}),
	t.object({
		type: t.literal("flip"),
		card: t.int().min(0)
	}),
	t.object({ type: t.literal("pass") })
]), z = t.string(), B = t.object({
	card: t.int().min(0).max(107),
	up: t.enum(["point", "veg"])
}), te = t.object({
	rid: z,
	perCard: t.array(t.number()),
	vegTotal: t.int().min(0),
	total: t.number()
}), ne = t.object({
	phase: t.enum(["play", "done"]),
	piles: t.array(t.object({
		count: t.int().min(0),
		top: t.int().min(0).max(107).nullable()
	})).length(3),
	market: t.array(t.int().min(0).max(107).nullable()).length(6),
	players: t.array(t.object({
		rid: z,
		tableau: t.array(B)
	})),
	turn: t.object({
		playerIdx: t.int().min(0),
		stage: t.enum(["draft", "flip"])
	}),
	final: t.array(te).optional()
}), V = t.object({});
//#endregion
//#region src/games/salad/rules.ts
function H(t, n) {
	for (let r = t.length - 1; r > 0; --r) {
		let i = e(n.seed, n.rngCursor, r + 1);
		n.rngCursor += 1, [t[r], t[i]] = [t[i], t[r]];
	}
}
function U(e, t) {
	let n = 0;
	for (let t = 1; t < e.piles.length; t += 1) e.piles[t].length > e.piles[n].length && (n = t);
	let r = Math.floor(e.piles[n].length / 2);
	return r !== 0 && (e.piles[t] = e.piles[n].splice(0, r), !0);
}
function re(e) {
	let t = !1;
	for (let n = 0; n < e.market.length; n += 1) {
		if (e.market[n] !== null) continue;
		let r = Math.floor(n / 2);
		e.piles[r].length === 0 && (t = U(e, r) || t), e.piles[r].length > 0 && (e.market[n] = e.piles[r].pop());
	}
	for (let n = 0; n < e.piles.length; n += 1) e.piles[n].length === 0 && e.piles.some((e) => e.length > 0) && (t = U(e, n) || t);
	return t;
}
function W(e) {
	return e.piles.every((e) => e.length === 0) && e.market.every((e) => e === null);
}
function G(e, t) {
	if (re(e) && t.push({
		kind: "refill",
		data: { split: !0 }
	}), W(e)) {
		e.phase = "done", t.push({ kind: "gameEnd" });
		return;
	}
	e.turn.stage = "flip";
}
function ie(e) {
	e.turn = {
		playerIdx: (e.turn.playerIdx + 1) % e.players.length,
		stage: "draft"
	};
}
function ae(t, n, r) {
	let i = {
		seed: r,
		rngCursor: 0,
		players: n,
		startIdx: 0,
		piles: [
			[],
			[],
			[]
		],
		market: [
			null,
			null,
			null,
			null,
			null,
			null
		],
		tableaus: {},
		turn: {
			playerIdx: 0,
			stage: "draft"
		},
		phase: "play"
	}, a = A[n.length] ?? A[6], o = [];
	b.forEach((e, t) => {
		let n = Array.from({ length: 18 }, (e, n) => t * 18 + n);
		H(n, i), o.push(...n.slice(0, a));
	}), H(o, i);
	for (let e = 0; e < 3; e += 1) i.piles[e] = o.slice(e * 2 * a, (e + 1) * 2 * a);
	for (let e = 0; e < 3; e += 1) i.market[e * 2] = i.piles[e].pop(), i.market[e * 2 + 1] = i.piles[e].pop();
	for (let e of n) i.tableaus[e] = [];
	return i.startIdx = e(r, i.rngCursor, n.length), i.rngCursor += 1, i.turn.playerIdx = i.startIdx, { state: i };
}
function oe(e, t, n) {
	if (e.phase !== "play" || n.by !== e.players[e.turn.playerIdx]) return { code: "games.salad.errNotYourTurn" };
	if (t.type === "takePoint" || t.type === "takeVeggies") {
		if (e.turn.stage !== "draft") return { code: "games.salad.errNotYourTurn" };
		let r = structuredClone(e), i = r.tableaus[n.by];
		if (t.type === "takePoint") {
			if (r.piles[t.pile].length === 0) return { code: "games.salad.errPileEmpty" };
			let e = r.piles[t.pile].pop();
			i.push({
				card: e,
				up: "point"
			});
			let a = [{
				kind: "takePoint",
				rid: n.by,
				data: {
					pile: t.pile,
					card: e
				}
			}];
			return G(r, a), {
				state: r,
				fx: a
			};
		}
		let a = [...new Set(t.slots)], o = r.market.filter((e) => e !== null).length;
		if (a.length !== t.slots.length || a.length !== Math.min(2, o) || a.some((e) => r.market[e] === null)) return { code: "games.salad.errBadPick" };
		let s = a.map((e) => r.market[e]);
		for (let e of a) r.market[e] = null;
		for (let e of s) i.push({
			card: e,
			up: "veg"
		});
		let c = [{
			kind: "takeVeggies",
			rid: n.by,
			data: {
				slots: a,
				cards: s
			}
		}];
		return G(r, c), {
			state: r,
			fx: c
		};
	}
	if (e.turn.stage !== "flip") return { code: "games.salad.errNotYourTurn" };
	let r = structuredClone(e);
	if (t.type === "flip") {
		let e = r.tableaus[n.by][t.card];
		return !e || e.up !== "point" ? { code: "games.salad.errBadFlip" } : (e.up = "veg", ie(r), {
			state: r,
			fx: [{
				kind: "flip",
				rid: n.by,
				data: {
					idx: t.card,
					card: e.card
				}
			}]
		});
	}
	return ie(r), { state: r };
}
function se(e) {
	let t = e.players.map((t) => M(e.tableaus[t])), n = P(t);
	return e.players.map((r, i) => {
		let { perCard: a, total: o } = I(e.tableaus[r], n[i]);
		return {
			rid: r,
			perCard: a,
			vegTotal: N(t[i]),
			total: o
		};
	});
}
function ce(e) {
	return {
		public: {
			phase: e.phase,
			piles: e.piles.map((e) => ({
				count: e.length,
				top: e.length > 0 ? e[e.length - 1] : null
			})),
			market: e.market,
			players: e.players.map((t) => ({
				rid: t,
				tableau: e.tableaus[t]
			})),
			turn: e.turn,
			...e.phase === "done" ? { final: se(e) } : {}
		},
		private: {}
	};
}
function le(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = se(e), n = e.players.length, r = (t) => (e.players.indexOf(t) - e.startIdx + n) % n, i = [...e.players].sort((e, n) => {
		let i = t.find((t) => t.rid === e).total;
		return t.find((e) => e.rid === n).total - i || r(n) - r(e);
	});
	return {
		phase: "done",
		winner: [i[0]],
		ranking: i,
		scores: Object.fromEntries(t.map((e) => [e.rid, e.total]))
	};
}
var ue = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: L,
	schemas: {
		action: R,
		publicView: ne,
		privateView: V
	},
	setup: ae,
	reduce: oe,
	viewFor: ce,
	status: le
}, K = {
	P: "#e9af35",
	L: "#47a360",
	C: "#e7883e",
	N: "#ce6a9d",
	T: "#df5e4b",
	B: "#9563aa"
};
function q({ veg: e, ...t }) {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 48 48",
		fill: "none",
		"aria-hidden": "true",
		...t,
		children: [
			e === "P" && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "M22 13c-5-5-12-3-14 4-3 9 1 23 7 26 3 1 6-1 9-2 3 1 6 3 9 2 6-3 10-17 7-26-2-7-9-9-14-4",
					fill: "#79b53e",
					stroke: "#315d26",
					strokeWidth: "2.5",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ m("path", {
					d: "M24 15c0-7 2-10 8-11",
					stroke: "#315d26",
					strokeWidth: "3",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ m("path", {
					d: "M18 18c-5 7-4 17-2 20m16-20c4 7 4 17 2 20",
					stroke: "#c8df75",
					strokeWidth: "2",
					strokeLinecap: "round"
				})
			] }),
			e === "L" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "M10 33C3 28 5 19 12 17c-2-7 4-11 10-9 5-6 12-3 13 4 8 0 10 7 6 13 3 6-1 12-8 12-4 5-14 5-18 0-5 1-7-1-5-4Z",
				fill: "#7fc758",
				stroke: "#3e8a3a",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}), /* @__PURE__ */ m("path", {
				d: "M12 28c7-3 13-3 23-11M17 37c4-7 8-14 7-25m2 22c4-3 7-5 11-5",
				stroke: "#d6eea1",
				strokeWidth: "2.5",
				strokeLinecap: "round"
			})] }),
			e === "C" && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "M21 13 15 3m7 9 3-10m-2 10 9-8",
					stroke: "#48933b",
					strokeWidth: "4",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ m("path", {
					d: "M18 12c5-3 15 1 17 7 3 8-8 19-24 26 1-14 1-27 7-33Z",
					fill: "#f39a37",
					stroke: "#a95d26",
					strokeWidth: "2.5",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ m("path", {
					d: "m20 20 6 3m-10 5 7 3m-8 5 4 2",
					stroke: "#f8c27a",
					strokeWidth: "2",
					strokeLinecap: "round"
				})
			] }),
			e === "N" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "M24 5c2 8 13 11 15 23 2 10-6 16-15 16S7 38 9 28C11 16 22 13 24 5Z",
				fill: "#dcb58a",
				stroke: "#8d654b",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}), /* @__PURE__ */ m("path", {
				d: "M24 11c-4 13-7 24-2 30m4-27c6 13 7 23 2 28",
				stroke: "#f6dec1",
				strokeWidth: "2.5",
				strokeLinecap: "round"
			})] }),
			e === "T" && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "M7 25C7 15 15 11 24 11s17 4 17 14c0 11-8 18-17 18S7 36 7 25Z",
					fill: "#ee6254",
					stroke: "#a7332d",
					strokeWidth: "2.5"
				}),
				/* @__PURE__ */ m("path", {
					d: "m24 15-4-8 6 3 5-4-1 8 7 3-8 2-5 6-2-7-9-2Z",
					fill: "#4c9b45",
					stroke: "#32733b",
					strokeWidth: "1.5",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ m("path", {
					d: "M15 28c0 4 2 7 5 9",
					stroke: "#ffaea0",
					strokeWidth: "2.5",
					strokeLinecap: "round"
				})
			] }),
			e === "B" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "M9 31C3 25 7 17 13 16c0-7 7-11 13-8 7-4 14 2 13 9 6 5 5 15-2 18-4 9-21 11-26 3-5 0-7-4-2-7Z",
				fill: "#a782c9",
				stroke: "#624682",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}), /* @__PURE__ */ m("path", {
				d: "M13 30c9 0 11-6 17-15m-12 23c-1-11 4-19 7-27m1 25c4-6 8-9 12-11",
				stroke: "#d9c4ec",
				strokeWidth: "2.5",
				strokeLinecap: "round"
			})] })
		]
	});
}
//#endregion
//#region src/games/salad/card.tsx
var J = {
	P: "games.salad.vegP",
	L: "games.salad.vegL",
	C: "games.salad.vegC",
	N: "games.salad.vegN",
	T: "games.salad.vegT",
	B: "games.salad.vegB"
};
function de(e) {
	switch (e.k) {
		case "per": return e.items.length === 1 ? "games.salad.cardPer" : "games.salad.cardPerMulti";
		case "set": return "games.salad.cardSet";
		case "most":
		case "fewest": return "games.salad.cardCompare";
		case "evenOdd": return "games.salad.cardParity";
		case "totalMost":
		case "totalFewest": return "games.salad.cardTotal";
		case "typeGe": return "games.salad.cardType";
		case "missing": return "games.salad.cardMissing";
	}
}
function Y({ veg: e }) {
	return /* @__PURE__ */ m("span", {
		className: "salad-recipe__food",
		"aria-hidden": !0,
		children: /* @__PURE__ */ m(q, { veg: e })
	});
}
function X({ value: e }) {
	let t = s();
	return /* @__PURE__ */ h("strong", {
		className: `salad-recipe__points ${e < 0 ? "salad-recipe__points--negative" : ""}`,
		children: [e, /* @__PURE__ */ m("small", { children: t("games.salad.pointsUnit") })]
	});
}
function fe({ cond: e }) {
	let t = s();
	if (e.k === "per") {
		if (e.items.length === 1) {
			let [n, r] = e.items[0];
			return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("div", {
				className: "salad-recipe__formula",
				children: [
					/* @__PURE__ */ m(Y, { veg: n }),
					/* @__PURE__ */ m("span", {
						className: "salad-recipe__op",
						children: "×"
					}),
					/* @__PURE__ */ m(X, { value: r })
				]
			}), /* @__PURE__ */ m("div", {
				className: "salad-recipe__note",
				children: t("games.salad.ruleEachVeg", { veg: t(J[n]) })
			})] });
		}
		return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("div", {
			className: `salad-recipe__formula salad-recipe__formula--multi ${e.items.length > 2 ? "salad-recipe__formula--triple" : ""}`,
			children: e.items.map(([e, t]) => /* @__PURE__ */ h("span", {
				className: "salad-recipe__term",
				children: [/* @__PURE__ */ m(Y, { veg: e }), /* @__PURE__ */ m("strong", {
					className: t < 0 ? "salad-recipe__small-points salad-recipe__points--negative" : "salad-recipe__small-points",
					children: t > 0 ? `+${t}` : t
				})]
			}, e))
		}), /* @__PURE__ */ m("div", {
			className: "salad-recipe__note",
			children: t("games.salad.ruleEachSeparate")
		})] });
	}
	return e.k === "set" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("div", {
		className: `salad-recipe__formula salad-recipe__formula--set ${e.vegs.length > 3 ? "salad-recipe__formula--long-set" : ""}`,
		children: e.vegs.map((e, t) => /* @__PURE__ */ m(Y, { veg: e }, `${e}-${t}`))
	}), /* @__PURE__ */ h("div", {
		className: "salad-recipe__note",
		children: [
			t("games.salad.rulePerSet"),
			" ",
			/* @__PURE__ */ m("strong", { children: e.pts }),
			" ",
			t("games.salad.pointsUnit")
		]
	})] }) : e.k === "most" || e.k === "fewest" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("div", {
		className: "salad-recipe__formula",
		children: [
			/* @__PURE__ */ m(Y, { veg: e.veg }),
			/* @__PURE__ */ m("span", {
				className: "salad-recipe__op",
				children: "→"
			}),
			/* @__PURE__ */ m(X, { value: e.pts })
		]
	}), /* @__PURE__ */ h("div", {
		className: "salad-recipe__note",
		children: [
			t(e.k === "most" ? "games.salad.ruleMostVeg" : "games.salad.ruleFewestVeg", { veg: t(J[e.veg]) }),
			/* @__PURE__ */ m("br", {}),
			/* @__PURE__ */ m("small", { children: t("games.salad.ruleTiesScore") })
		]
	})] }) : e.k === "evenOdd" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("div", {
		className: "salad-recipe__formula salad-recipe__formula--parity",
		children: [/* @__PURE__ */ m(Y, { veg: e.veg }), /* @__PURE__ */ h("strong", {
			className: "salad-recipe__pair",
			children: [
				t("games.salad.shortEven"),
				" ",
				e.even,
				/* @__PURE__ */ m("br", {}),
				t("games.salad.shortOdd"),
				" ",
				e.odd
			]
		})]
	}), /* @__PURE__ */ m("div", {
		className: "salad-recipe__note",
		children: t("games.salad.ruleVegCount", { veg: t(J[e.veg]) })
	})] }) : e.k === "totalMost" || e.k === "totalFewest" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("div", {
		className: "salad-recipe__formula",
		children: [
			/* @__PURE__ */ h("span", {
				className: "salad-recipe__food-pair",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ m(q, { veg: "L" }), /* @__PURE__ */ m(q, { veg: "T" })]
			}),
			/* @__PURE__ */ m("span", {
				className: "salad-recipe__op",
				children: "→"
			}),
			/* @__PURE__ */ m(X, { value: e.pts })
		]
	}), /* @__PURE__ */ h("div", {
		className: "salad-recipe__note",
		children: [
			t(e.k === "totalMost" ? "games.salad.ruleTotalMost" : "games.salad.ruleTotalFewest"),
			/* @__PURE__ */ m("br", {}),
			/* @__PURE__ */ m("small", { children: t("games.salad.ruleTiesScore") })
		]
	})] }) : e.k === "typeGe" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("div", {
		className: "salad-recipe__formula",
		children: [
			/* @__PURE__ */ h("span", {
				className: "salad-recipe__type-mark",
				children: ["≥", e.min]
			}),
			/* @__PURE__ */ m("span", {
				className: "salad-recipe__op",
				children: "×"
			}),
			/* @__PURE__ */ m(X, { value: e.pts })
		]
	}), /* @__PURE__ */ m("div", {
		className: "salad-recipe__note",
		children: t("games.salad.ruleTypeMin", { min: e.min })
	})] }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("div", {
		className: "salad-recipe__formula",
		children: [
			/* @__PURE__ */ m("span", {
				className: "salad-recipe__type-mark",
				children: t("games.salad.missingMark")
			}),
			/* @__PURE__ */ m("span", {
				className: "salad-recipe__op",
				children: "×"
			}),
			/* @__PURE__ */ m(X, { value: e.pts })
		]
	}), /* @__PURE__ */ m("div", {
		className: "salad-recipe__note",
		children: t("games.salad.ruleMissingType")
	})] });
}
function Z({ card: e }) {
	let t = s(), n = k(e), r = O(e);
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("span", {
			className: "salad-recipe__stripe",
			style: { background: K[r] },
			"aria-hidden": !0
		}),
		/* @__PURE__ */ h("span", {
			className: "salad-recipe__head",
			children: [/* @__PURE__ */ m("span", {
				className: "salad-recipe__kind",
				children: t(de(n))
			}), /* @__PURE__ */ h("span", {
				className: "salad-recipe__flip",
				title: t("games.salad.flipToVeg", { veg: t(J[r]) }),
				"aria-label": t("games.salad.flipToVeg", { veg: t(J[r]) }),
				children: [/* @__PURE__ */ m("span", { children: t("games.salad.flipShort") }), /* @__PURE__ */ m(q, { veg: r })]
			})]
		}),
		/* @__PURE__ */ m("span", {
			className: "salad-recipe__body",
			children: /* @__PURE__ */ m(fe, { cond: n })
		})
	] });
}
function pe({ card: e }) {
	let t = s(), n = O(e);
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("span", {
		className: "salad-veg-card__art",
		children: /* @__PURE__ */ m(q, { veg: n })
	}), /* @__PURE__ */ m("span", {
		className: "salad-veg-card__name",
		children: t(J[n])
	})] });
}
function me({ card: e, face: t, w: n, h: r }) {
	let i = o((e) => e.locale);
	return /* @__PURE__ */ m("div", {
		className: `salad-card-sprite ${t === "point" ? "salad-recipe" : "salad-veg-card"}`,
		"data-locale": i,
		style: {
			width: n,
			height: r,
			background: t === "veg" ? K[O(e)] : void 0
		},
		children: m(t === "point" ? Z : pe, { card: e })
	});
}
//#endregion
//#region src/games/salad/cond-text.ts
function he(e, t) {
	switch (e.k) {
		case "per": return e.items.map(([e, t]) => `${t}/${x[e]}`).join(" ");
		case "set": return `${e.vegs.map((e) => x[e]).join("+")}=${e.pts}`;
		case "most": return t("games.salad.condMost", {
			veg: x[e.veg],
			n: e.pts
		});
		case "fewest": return t("games.salad.condFewest", {
			veg: x[e.veg],
			n: e.pts
		});
		case "evenOdd": return t("games.salad.condEvenOdd", {
			veg: x[e.veg],
			even: e.even,
			odd: e.odd
		});
		case "totalMost": return t("games.salad.condTotalMost", { n: e.pts });
		case "totalFewest": return t("games.salad.condTotalFewest", { n: e.pts });
		case "typeGe": return t("games.salad.condTypeGe", {
			min: e.min,
			n: e.pts
		});
		case "missing": return t("games.salad.condMissing", { n: e.pts });
	}
}
//#endregion
//#region src/games/salad/view-player.tsx
function ge(e) {
	let t = e.public;
	return /* @__PURE__ */ m(_e, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function _e({ pub: e, members: t, myRid: i, send: a }) {
	let c = s(), g = o((e) => e.locale), [_, ee] = r(i), [v, y] = r(null), b = e.players[e.turn.playerIdx]?.rid, x = e.phase === "play" && b === i, S = e.turn.stage, C = x && _ === i;
	u(x, l);
	let [w, T] = r(""), E = `${e.turn.playerIdx}:${S}:${_}:${e.phase}`;
	w !== E && (T(E), y(null));
	let D = n(() => {
		let t = e.players.map((e) => M(e.tableau)), n = P(t), r = {};
		return e.players.forEach((e, i) => {
			let { perCard: a, total: o } = I(e.tableau, n[i]);
			r[e.rid] = {
				perCard: a,
				total: o,
				vegTotal: N(t[i])
			};
		}), r;
	}, [e.players]), k = e.piles.reduce((e, t) => e + t.count, 0) + e.market.filter((e) => e !== null).length, A = e.market.filter((e) => e !== null).length, j = Math.min(2, A), F = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? f(n, g) : e;
	}, R = e.players.find((e) => e.rid === _), z = D[_], B = C && S === "draft", te = (t) => {
		B && e.piles[t].count !== 0 && y((e) => e?.kind === "point" && e.pile === t ? null : {
			kind: "point",
			pile: t
		});
	}, ne = (t) => {
		B && e.market[t] !== null && y((e) => e?.kind === "veg" ? e.slots.includes(t) ? {
			kind: "veg",
			slots: e.slots.filter((e) => e !== t)
		} : {
			kind: "veg",
			slots: e.slots.length >= 2 ? [...e.slots.slice(1), t] : [...e.slots, t]
		} : {
			kind: "veg",
			slots: [t]
		});
	}, V = v !== null && (v.kind === "point" && e.piles[v.pile].count > 0 || v.kind === "veg" && j > 0 && v.slots.length === j), H = () => {
		V && (v.kind === "point" ? a({
			type: "takePoint",
			pile: v.pile
		}) : v.kind === "veg" && a({
			type: "takeVeggies",
			slots: v.slots
		}), y(null));
	}, U = C && S === "flip", re = (e) => {
		if (!U) return;
		let t = R?.tableau[e];
		t && t.up === "point" && y((t) => t?.kind === "flip" && t.idx === e ? null : {
			kind: "flip",
			idx: e
		});
	}, W = c("games.salad.pickHint");
	if (!x) W = c("games.salad.waitingHint");
	else if (_ !== i) W = c("games.salad.otherSalad", {
		name: F(_),
		n: z?.vegTotal ?? 0
	});
	else if (v?.kind === "veg") {
		let t = v.slots.map((t) => c(J[O(e.market[t])]));
		W = c("games.salad.selectedVegHint", {
			n: v.slots.length,
			need: j,
			vegs: t.join(" + ")
		});
	} else v?.kind === "point" ? W = c("games.salad.selectedPointHint", { n: v.pile + 1 }) : v?.kind === "flip" && R?.tableau[v.idx] ? W = c("games.salad.selectedFlipHint", { veg: c(J[O(R.tableau[v.idx].card)]) }) : S === "flip" && (W = c("games.salad.flipCardHint"));
	let G = /* @__PURE__ */ m("div", {
		className: "salad-actions",
		children: !x || _ !== i ? /* @__PURE__ */ m("div", {
			className: "salad-actions__hint",
			children: W
		}) : S === "flip" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("button", {
			type: "button",
			className: "salad-actions__button salad-actions__button--quiet",
			disabled: v?.kind !== "flip",
			onClick: () => {
				v?.kind === "flip" && (a({
					type: "flip",
					card: v.idx
				}), y(null));
			},
			children: c("games.salad.flipConfirm")
		}), /* @__PURE__ */ m("button", {
			type: "button",
			className: "salad-actions__button",
			style: { background: L.accent },
			onClick: () => a({ type: "pass" }),
			children: c("games.salad.endTurn")
		})] }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("div", {
			className: "salad-actions__hint",
			children: W
		}), /* @__PURE__ */ m("button", {
			type: "button",
			className: "salad-actions__button",
			disabled: !V,
			onClick: H,
			style: V ? { background: L.accent } : void 0,
			children: v?.kind === "point" ? c("games.salad.takePoint") : v?.kind === "veg" ? c("games.salad.takeVeggies", { n: v.slots.length }) : c("games.salad.pickNone")
		})] })
	});
	return /* @__PURE__ */ m("div", {
		className: "salad-screen",
		"data-locale": g,
		children: /* @__PURE__ */ m(d, {
			adaptive: !0,
			scroll: !1,
			className: "salad-adaptive",
			actionsHeight: "salad-actions-height",
			actions: G,
			banner: /* @__PURE__ */ h("div", {
				className: "salad-banner",
				children: [/* @__PURE__ */ m("div", {
					className: "salad-turnbar",
					role: "status",
					children: /* @__PURE__ */ h("div", {
						className: "salad-turnbar__plate",
						children: [
							/* @__PURE__ */ h("strong", { children: ["🥗 ", c(x ? "games.salad.turnYou" : "games.salad.waitTitle")] }),
							/* @__PURE__ */ m("span", {
								className: "salad-turnbar__text",
								children: x ? c(S === "draft" ? "games.salad.stageDraft" : "games.salad.stageFlip") : c("games.salad.waitTurn", { name: F(b ?? "") })
							}),
							/* @__PURE__ */ m("span", {
								className: "salad-turnbar__left",
								children: c("games.salad.cardsLeft", { n: k })
							})
						]
					})
				}), /* @__PURE__ */ m("div", {
					className: "salad-players",
					"aria-label": c("games.salad.playersLabel"),
					children: t.filter((t) => e.players.some((e) => e.rid === t.rid)).map((t) => /* @__PURE__ */ m(ve, {
						member: t,
						name: f(t, g),
						myRid: i,
						current: e.phase === "play" && t.rid === b,
						viewed: t.rid === _,
						estimate: D[t.rid],
						onClick: () => ee(t.rid)
					}, t.rid))
				})]
			}),
			children: /* @__PURE__ */ h("main", {
				className: "salad-main",
				children: [/* @__PURE__ */ h("section", {
					className: "salad-market",
					"aria-label": c("games.salad.marketTitle"),
					children: [/* @__PURE__ */ h("div", {
						className: "salad-section-head",
						children: [/* @__PURE__ */ h("span", { children: ["▣ ", c("games.salad.marketTitle")] }), /* @__PURE__ */ m("em", {
							className: "salad-section-head__aside",
							children: c("games.salad.marketRefill")
						})]
					}), /* @__PURE__ */ m("div", {
						className: "salad-market__columns",
						children: e.piles.map((t, n) => /* @__PURE__ */ h("div", {
							className: "salad-market__column",
							children: [/* @__PURE__ */ m(ye, {
								idx: n,
								count: t.count,
								top: t.top,
								selected: v?.kind === "point" && v.pile === n,
								disabled: !B || t.count === 0,
								onTap: () => te(n)
							}), [n * 2, n * 2 + 1].map((t) => /* @__PURE__ */ m(be, {
								idx: t,
								card: e.market[t],
								pickOrder: v?.kind === "veg" ? v.slots.indexOf(t) + 1 : 0,
								disabled: !B || e.market[t] === null,
								onTap: () => ne(t)
							}, t))]
						}, n))
					})]
				}), /* @__PURE__ */ m("section", {
					className: "salad-personal",
					"aria-label": _ === i ? c("games.salad.mySalad", { n: z?.vegTotal ?? 0 }) : c("games.salad.otherSalad", {
						name: F(_),
						n: z?.vegTotal ?? 0
					}),
					children: R && /* @__PURE__ */ m(Se, {
						tableau: R.tableau,
						perCard: z?.perCard ?? [],
						total: z?.total ?? 0,
						vegTotal: z?.vegTotal ?? 0,
						name: F(_),
						mine: _ === i,
						flipSel: U && v?.kind === "flip" ? v.idx : null,
						onTapCard: U ? re : void 0
					}, _)
				})]
			})
		})
	});
}
function ve({ member: e, name: t, myRid: n, current: r, viewed: o, estimate: l, onClick: u }) {
	let d = s(), { ref: f } = a(`seat:${e.rid}`);
	return /* @__PURE__ */ h("button", {
		type: "button",
		className: `salad-player ${o ? "is-viewed" : ""} ${e.online ? "" : "is-offline"}`,
		"aria-pressed": o,
		onClick: u,
		children: [
			r && /* @__PURE__ */ m("span", {
				className: "salad-player__turn",
				children: d("games.salad.acting")
			}),
			/* @__PURE__ */ m("span", {
				ref: f,
				className: "salad-player__avatar",
				style: { background: c[e.colorIndex % c.length].hex },
				children: /* @__PURE__ */ m("img", {
					src: i[e.avatar % i.length],
					alt: "",
					draggable: !1
				})
			}),
			/* @__PURE__ */ h("span", {
				className: "salad-player__text",
				children: [/* @__PURE__ */ m("b", { children: e.rid === n ? `${d("lobby.you")} · ${t}` : t }), /* @__PURE__ */ h("small", { children: [
					"🥗 ",
					l?.vegTotal ?? 0,
					" · ★ ",
					l?.total ?? 0
				] })]
			})
		]
	});
}
function ye({ idx: e, count: t, top: n, selected: r, disabled: i, onTap: o }) {
	let c = s(), { ref: l, hidden: u } = a(`pile:${e}`);
	return /* @__PURE__ */ h("div", {
		className: "salad-pile-wrap",
		children: [/* @__PURE__ */ m("button", {
			ref: l,
			type: "button",
			disabled: i,
			onClick: o,
			"aria-label": `${c("games.salad.pileAria", {
				n: e + 1,
				count: t
			})}${n === null ? "" : ` · ${he(k(n), c)}`}`,
			className: `salad-recipe salad-pile ${r ? "is-selected" : ""} ${u ? "invisible" : ""} ${n === null ? "opacity-40" : ""}`,
			children: n !== null && /* @__PURE__ */ m(Z, { card: n })
		}), /* @__PURE__ */ h("span", {
			className: "salad-pile-wrap__remaining",
			"aria-hidden": !0,
			children: ["×", t]
		})]
	});
}
function be({ idx: e, card: t, pickOrder: n, disabled: r, onTap: i }) {
	let o = s(), { ref: c, hidden: l } = a(`mkt:${e}`);
	if (t === null) return /* @__PURE__ */ m("div", {
		ref: c,
		className: "salad-market-slot",
		children: /* @__PURE__ */ m("div", {
			className: "salad-veg-card--empty",
			"aria-hidden": !0
		})
	});
	let u = O(t);
	return /* @__PURE__ */ m("div", {
		ref: c,
		className: "salad-market-slot",
		children: /* @__PURE__ */ h("button", {
			type: "button",
			disabled: r,
			onClick: i,
			"aria-label": o("games.salad.marketAria", { name: o(J[u]) }),
			style: { background: K[u] },
			className: `salad-veg-card ${n ? "is-selected" : ""} ${l ? "invisible" : ""}`,
			children: [/* @__PURE__ */ m(pe, { card: t }), n > 0 && /* @__PURE__ */ h("span", {
				className: "salad-veg-card__pick",
				"aria-hidden": !0,
				children: [n, "/2 ✓"]
			})]
		})
	});
}
function xe({ veg: e, count: t }) {
	let n = s();
	return /* @__PURE__ */ h("li", {
		className: `salad-ingredient ${t === 0 ? "is-empty" : "is-owned"} ${t > 1 ? "is-stacked" : ""}`,
		style: { "--salad-veg": K[e] },
		"aria-label": `${n(J[e])} ×${t}`,
		children: [/* @__PURE__ */ m("span", {
			className: "salad-ingredient__tile",
			children: /* @__PURE__ */ m(q, { veg: e })
		}), /* @__PURE__ */ h("span", {
			className: "salad-ingredient__amount",
			children: [/* @__PURE__ */ m("span", { children: n(J[e]) }), /* @__PURE__ */ h("b", { children: ["×", t] })]
		})]
	});
}
function Se({ tableau: e, perCard: t, total: n, vegTotal: r, name: i, mine: a, flipSel: o, onTapCard: c }) {
	let l = s(), u = M(e), d = e.map((e, t) => ({
		c: e,
		idx: t
	})).filter(({ c: e }) => e.up === "point");
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ h("div", {
			className: "salad-section-head",
			children: [/* @__PURE__ */ m("span", { children: a ? l("games.salad.mySalad", { n: r }) : l("games.salad.otherSalad", {
				name: i,
				n: r
			}) }), /* @__PURE__ */ m("strong", {
				className: "salad-personal__score",
				children: l("games.salad.currentScore", { n })
			})]
		}),
		/* @__PURE__ */ m("ul", {
			className: "salad-ingredients",
			"aria-label": l("games.salad.finalVeggies", { n: r }),
			children: b.map((e) => /* @__PURE__ */ m(xe, {
				veg: e,
				count: u[e]
			}, e))
		}),
		/* @__PURE__ */ h("div", {
			className: "salad-rack-head",
			children: [/* @__PURE__ */ m("span", { children: l(a ? "games.salad.myPointCards" : "games.salad.otherPointCards", { n: d.length }) }), /* @__PURE__ */ m("span", { children: d.length > 6 ? l("games.salad.scrollForMore") : a ? l("games.salad.flipCardHint") : "" })]
		}),
		/* @__PURE__ */ h("ul", {
			className: "salad-rack",
			"aria-label": l(a ? "games.salad.myPointCards" : "games.salad.otherPointCards", { n: d.length }),
			children: [d.length === 0 && /* @__PURE__ */ m("li", {
				className: "salad-rack__empty",
				children: l("games.salad.emptyPoints")
			}), d.map(({ c: e, idx: n }) => {
				let r = t[n] ?? 0, i = `salad-recipe salad-owned-card ${o === n ? "is-selected" : ""}`, a = `${he(k(e.card), l)} · ${l("games.salad.pointCardScore", { n: r > 0 ? `+${r}` : r })} · ${l("games.salad.flipToVeg", { veg: l(J[O(e.card)]) })}`;
				return /* @__PURE__ */ h("li", {
					className: "salad-owned-card-wrap",
					children: [c ? /* @__PURE__ */ m("button", {
						type: "button",
						className: i,
						onClick: () => c(n),
						"aria-label": a,
						children: /* @__PURE__ */ m(Z, { card: e.card })
					}) : /* @__PURE__ */ m("div", {
						className: i,
						"aria-label": a,
						children: /* @__PURE__ */ m(Z, { card: e.card })
					}), /* @__PURE__ */ m("span", {
						className: `salad-owned-card__earned ${r < 0 ? "is-negative" : ""}`,
						"aria-hidden": !0,
						children: l("games.salad.pointCardScore", { n: r > 0 ? `+${r}` : r })
					})]
				}, n);
			})]
		})
	] });
}
//#endregion
//#region src/games/salad/bot.ts
function Ce(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function we() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function Q(e, t, n) {
	return I(n, P(e.players.map((e) => e.rid === t ? n : e.tableau).map(M))[e.players.findIndex((e) => e.rid === t)]).total;
}
function Te(e, t) {
	let n = [];
	e.piles.forEach((e, r) => {
		e.top !== null && n.push({
			action: {
				type: "takePoint",
				pile: r
			},
			tableau: [...t, {
				card: e.top,
				up: "point"
			}]
		});
	});
	let r = e.market.flatMap((e, t) => e === null ? [] : [t]);
	r.length === 1 && n.push({
		action: {
			type: "takeVeggies",
			slots: r
		},
		tableau: [...t, {
			card: e.market[r[0]],
			up: "veg"
		}]
	});
	for (let i = 0; i < r.length; i += 1) for (let a = i + 1; a < r.length; a += 1) {
		let o = [r[i], r[a]];
		n.push({
			action: {
				type: "takeVeggies",
				slots: o
			},
			tableau: [
				...t,
				{
					card: e.market[o[0]],
					up: "veg"
				},
				{
					card: e.market[o[1]],
					up: "veg"
				}
			]
		});
	}
	return n;
}
var Ee = (e, t) => {
	let n = e.public;
	if (n.phase !== "play") return null;
	let r = n.players[n.turn.playerIdx];
	if (!r || r.rid !== t.rid) return null;
	let i = _(g(t.rid)), a = t.difficulty === "weak", o = () => (we() - .5) * i.noise * 6;
	if (n.turn.stage === "draft") {
		let e = Te(n, r.tableau);
		if (e.length === 0) return null;
		if (a) return { action: Ce(e).action };
		let i = Q(n, t.rid, r.tableau), s = e[0], c = -Infinity;
		for (let r of e) {
			let e = Q(n, t.rid, r.tableau) - i + o();
			e > c && (c = e, s = r);
		}
		return { action: s.action };
	}
	let s = r.tableau.flatMap((e, t) => e.up === "point" ? [t] : []);
	if (s.length === 0) return { action: { type: "pass" } };
	if (a) return { action: we() < .3 ? {
		type: "flip",
		card: Ce(s)
	} : { type: "pass" } };
	let c = Q(n, t.rid, r.tableau), l = -1, u = 0;
	for (let e of s) {
		let i = r.tableau.map((t, n) => n === e ? {
			...t,
			up: "veg"
		} : t), a = Q(n, t.rid, i) - c + o();
		a > u && (u = a, l = e);
	}
	return { action: l >= 0 ? {
		type: "flip",
		card: l
	} : { type: "pass" } };
}, De = {
	P: "games.salad.vegP",
	L: "games.salad.vegL",
	C: "games.salad.vegC",
	N: "games.salad.vegN",
	T: "games.salad.vegT",
	B: "games.salad.vegB"
}, Oe = (e, t, n) => {
	if (e.type === "takePoint") return n("games.salad.hintTakePoint", { n: e.pile + 1 });
	if (e.type === "takeVeggies") {
		let r = e.slots.map((e) => t.public.market[e]);
		if (r.some((e) => e === null)) return n("games.salad.takeVeggies", { n: e.slots.length });
		let i = r.map((e) => n(De[O(e)]));
		return i.length === 1 ? n("games.salad.hintTakeVeg1", { veg: i[0] }) : n("games.salad.hintTakeVeg2", {
			veg1: i[0],
			veg2: i[1]
		});
	}
	return e.type === "flip" ? n("games.salad.flipConfirm") : e.type === "pass" ? n("games.salad.endTurn") : "";
}, ke = {
	P: "彩椒",
	L: "生菜",
	C: "胡萝卜",
	N: "洋葱",
	T: "番茄",
	B: "紫甘蓝"
}, $ = (e) => `${x[e]}${ke[e]}`, Ae = (e) => {
	switch (e.k) {
		case "per": return e.items.map(([e, t]) => `每个${$(e)}${t > 0 ? "+" : ""}${t}分`).join(",");
		case "set": return `每凑齐 ${e.vegs.map($).join("+")} 得 ${e.pts} 分`;
		case "most": return `${$(e.veg)}全场最多(可并列)得 ${e.pts} 分`;
		case "fewest": return `${$(e.veg)}全场最少(可并列)得 ${e.pts} 分`;
		case "evenOdd": return `${$(e.veg)}偶数个得 ${e.even} 分,奇数个得 ${e.odd} 分(0 是偶数)`;
		case "totalMost": return `蔬菜总数全场最多得 ${e.pts} 分`;
		case "totalFewest": return `蔬菜总数全场最少得 ${e.pts} 分`;
		case "typeGe": return `每有一种蔬菜数量≥${e.min},得 ${e.pts} 分`;
		case "missing": return `每缺一种蔬菜,得 ${e.pts} 分`;
	}
}, je = (e) => `#${e} ${$(O(e))} | 计分面: ${Ae(k(e))}`, Me = {
	needsAction: (e, t) => e.public.phase === "play" && e.public.players[e.public.turn.playerIdx]?.rid === t.rid,
	describeView(e, t) {
		let n = e.public, r = ["规则:每回合两段——draft 拿牌(3 堆里拿 1 张计分卡,或从 6 格蔬菜市场拿 2 张蔬菜;市场不足 2 张时全拿),然后 flip(可把自己一张计分卡翻成蔬菜面,或 pass)。卡是双面的:计分面朝上才计分,翻成蔬菜面后只算蔬菜。终局按各人计分卡+蔬菜统计,分高者胜。", `蔬菜图例: ${b.map($).join(" ")}`];
		r.push(`牌堆顶(计分面): ${n.piles.map((e, t) => `堆${t}: ${e.top == null ? "(空)" : je(e.top)}`).join(" | ")}`), r.push(`蔬菜市场: ${n.market.map((e, t) => `格${t}: ${e == null ? "(空)" : $(O(e))}`).join(" | ")}`);
		for (let e of n.players) {
			let n = e.rid === t.rid ? "你" : e.rid;
			r.push(`${n} 面前: ${e.tableau.map((e, t) => e.up === "point" ? `${t}:${je(e.card)}` : `${t}:${$(O(e.card))}(蔬菜面)`).join(" | ") || "(空)"}`);
		}
		return n.turn.stage === "draft" ? r.push("轮到你 draft:takePoint(pile=0-2)或 takeVeggies(slots=市场格号数组)。") : r.push("轮到你 flip:flip(card=你面前的条目序号,翻成蔬菜面)或 pass 结束回合。"), r.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: {
				type: { const: "takePoint" },
				pile: {
					type: "integer",
					minimum: 0,
					maximum: 2
				}
			},
			required: ["type", "pile"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "takeVeggies" },
				slots: {
					type: "array",
					items: {
						type: "integer",
						minimum: 0,
						maximum: 5
					},
					minItems: 1,
					maxItems: 2,
					description: "市场 ≥2 张时必须恰拿 2 张"
				}
			},
			required: ["type", "slots"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "flip" },
				card: {
					type: "integer",
					minimum: 0,
					description: "自己面前计分面朝上的条目序号"
				}
			},
			required: ["type", "card"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "pass" } },
			required: ["type"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = R.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public;
		if (a.phase !== "play" || a.players[a.turn.playerIdx]?.rid !== n.rid) return null;
		let o = a.turn.stage;
		if (i.type === "takePoint") return o === "draft" && a.piles[i.pile]?.top != null ? i : null;
		if (i.type === "takeVeggies") {
			if (o !== "draft") return null;
			let e = [...new Set(i.slots)], t = a.market.filter((e) => e !== null).length;
			return e.length !== i.slots.length || e.length !== Math.min(2, t) ? null : e.every((e) => a.market[e] != null) ? i : null;
		}
		return o === "flip" ? i.type === "flip" ? a.players[a.turn.playerIdx].tableau[i.card]?.up === "point" ? i : null : i : null;
	}
}, Ne = {
	takePoint(e, t) {
		let n = e.data, r = typeof n?.pile == "number" ? t.anchor(`pile:${n.pile}`) : null, i = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || !i || typeof n?.card != "number" ? null : {
			ms: 550,
			node: /* @__PURE__ */ m(v, {
				from: r,
				to: i,
				ms: 550,
				children: /* @__PURE__ */ m(me, {
					card: n.card,
					face: "point",
					w: r.w,
					h: r.h
				})
			})
		};
	},
	takeVeggies(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || !Array.isArray(n?.slots) || !Array.isArray(n?.cards) ? null : {
			ms: 700,
			node: /* @__PURE__ */ m(p, { children: n.slots.map((e, i) => {
				let a = t.anchor(`mkt:${e}`), o = n.cards[i];
				return !a || typeof o != "number" ? null : /* @__PURE__ */ m(v, {
					from: a,
					to: r,
					ms: 550,
					delay: i * 100,
					children: /* @__PURE__ */ m(me, {
						card: o,
						face: "veg",
						w: a.w,
						h: a.h
					})
				}, e);
			}) })
		};
	},
	flip(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!r || typeof n?.card != "number") return null;
		let i = Math.max(30, r.w * 1.2);
		return {
			ms: 1e3,
			node: /* @__PURE__ */ m(ee, {
				at: r,
				ms: 1e3,
				children: /* @__PURE__ */ m(q, {
					veg: O(n.card),
					width: i,
					height: i
				})
			})
		};
	}
};
//#endregion
//#region src/games/salad/game-over.tsx
function Pe({ final: e, pub: t, won: n, place: r, name: i }) {
	let a = s(), o = t.players.find((t) => t.rid === e.rid)?.tableau ?? [], c = M(o), l = o.flatMap((t, n) => t.up === "point" ? [{
		card: t.card,
		score: e.perCard[n] ?? 0,
		idx: n
	}] : []);
	return /* @__PURE__ */ h("section", {
		"data-rid": e.rid,
		className: `salad-result__receipt ${n ? "is-winner" : ""}`,
		children: [
			/* @__PURE__ */ h("header", {
				className: "salad-result__player",
				children: [
					/* @__PURE__ */ m("span", {
						className: "salad-result__place",
						"aria-label": `${r}`,
						children: n ? "★" : r
					}),
					/* @__PURE__ */ m("strong", {
						className: "salad-result__name",
						children: i
					}),
					/* @__PURE__ */ h("span", {
						className: "salad-result__total",
						children: [e.total, /* @__PURE__ */ m("small", { children: a("games.salad.pointsUnit") })]
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "salad-result__label",
				children: a("games.salad.finalVeggies", { n: e.vegTotal })
			}),
			/* @__PURE__ */ m("ul", {
				className: "salad-result__veggies",
				children: b.map((e) => /* @__PURE__ */ h("li", {
					className: c[e] === 0 ? "is-empty" : "",
					"aria-label": `${a(J[e])} ×${c[e]}`,
					children: [
						/* @__PURE__ */ m("span", {
							className: "salad-result__veg-icon",
							style: { background: K[e] },
							children: /* @__PURE__ */ m(q, { veg: e })
						}),
						/* @__PURE__ */ m("span", { children: a(J[e]) }),
						/* @__PURE__ */ h("b", { children: ["×", c[e]] })
					]
				}, e))
			}),
			/* @__PURE__ */ h("div", {
				className: "salad-result__label salad-result__label--points",
				children: [/* @__PURE__ */ m("span", { children: a("games.salad.otherPointCards", { n: l.length }) }), /* @__PURE__ */ m("strong", { children: a("games.salad.currentScore", { n: e.total }) })]
			}),
			/* @__PURE__ */ h("ul", {
				className: "salad-result__cards",
				children: [l.map(({ card: e, score: t, idx: n }) => /* @__PURE__ */ h("li", {
					"data-card-index": n,
					className: "salad-result__card-wrap",
					"aria-label": `${he(k(e), a)} · ${a("games.salad.pointCardScore", { n: t })}`,
					children: [/* @__PURE__ */ m("div", {
						className: "salad-recipe salad-result__card",
						children: /* @__PURE__ */ m(Z, { card: e })
					}), /* @__PURE__ */ m("span", {
						className: `salad-result__earned ${t < 0 ? "is-negative" : ""}`,
						"aria-hidden": !0,
						children: t > 0 ? `+${t}` : t
					})]
				}, n)), l.length === 0 && /* @__PURE__ */ m("li", {
					className: "salad-result__empty",
					children: a("games.salad.emptyPoints")
				})]
			})
		]
	});
}
function Fe({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let a = s(), c = o((e) => e.locale), l = t, u = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? f(t, c) : e;
	}, p = r ?? i ? /* @__PURE__ */ h("div", {
		className: "salad-result__actions",
		children: [r && /* @__PURE__ */ m("button", {
			type: "button",
			className: "btn-base w-full cursor-pointer text-white",
			style: { background: L.accent },
			onClick: r,
			children: a("session.result.playAgain")
		}), i && /* @__PURE__ */ m("button", {
			type: "button",
			className: "btn-quiet w-full cursor-pointer",
			onClick: i,
			children: a("session.result.backToLobby")
		})]
	}) : /* @__PURE__ */ m("p", {
		className: "salad-result__waiting",
		children: a("session.result.waitHost")
	});
	return /* @__PURE__ */ m("div", {
		className: "salad-result",
		children: /* @__PURE__ */ h(d, {
			adaptive: !0,
			scroll: !1,
			className: "salad-result-adaptive",
			banner: /* @__PURE__ */ h("header", {
				className: "salad-result__heading",
				children: [/* @__PURE__ */ m("span", {
					className: "salad-result__heading-icon",
					children: /* @__PURE__ */ m(q, { veg: "L" })
				}), /* @__PURE__ */ m("h1", { children: a("session.result.title") })]
			}),
			actionsHeight: `salad-result-actions-height${r && i ? "" : " salad-result-actions-height--single"}`,
			actions: p,
			children: [e.winner.length > 0 && /* @__PURE__ */ m(y, {}), /* @__PURE__ */ m("div", {
				className: "salad-result__list",
				"data-players": e.ranking.length,
				children: e.ranking.map((t, n) => {
					let r = l.final?.find((e) => e.rid === t);
					return r && /* @__PURE__ */ m(Pe, {
						final: r,
						pub: l,
						won: e.winner.includes(t),
						place: n + 1,
						name: u(t)
					}, t);
				})
			})]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/salad/entry.tsx
var Ie = {
	definition: ue,
	View: ge,
	bot: Ee,
	describe: Oe,
	llm: Me,
	fx: Ne,
	OverView: Fe,
	locales: {
		zh: {
			name: "得分沙拉",
			desc: "拿计分卡、囤蔬菜,108 种计分方式叠出最高分",
			rules: "目标:牌堆和市场全部拿完后,计分卡总分最高者获胜。\n流程(每回合):\n先选择以下一种方式拿牌：\n· 拿取一张计分卡，可以选择三个牌堆中任意一个的顶牌；这些顶牌的计分条件向所有玩家公开。\n· 从市场拿取两张蔬菜牌。\n· 拿牌后，市场自动补充。一个牌堆耗尽时，将当前最大牌堆的一半移入该位置。\n· 拿牌后还可把 1 张自己的计分卡翻成蔬菜面,每回合至多 1 次,单向不可逆。\n终局计分:\n· 只计算蔬菜面朝上的卡牌。同一张蔬菜牌可以同时计入多张计分卡的条件。\n· 「最多 / 最少某蔬菜」并列同得分;0 个也算数(0 是偶数)。\n· 总分相同时，行动顺序较后的玩家获胜。",
			vegP: "彩椒",
			vegL: "生菜",
			vegC: "胡萝卜",
			vegN: "洋葱",
			vegT: "番茄",
			vegB: "紫甘蓝",
			cardsLeft: "剩 {{n}} 张",
			stageDraft: "拿取 1 张计分卡或 2 张蔬菜",
			stageFlip: "可翻 1 张计分卡变蔬菜,或结束回合",
			waitTurn: "等 {{name}} 操作…",
			watchHint: "轮到你时,这里会出现操作按钮",
			takePoint: "拿计分卡",
			takeVeggies: "拿 {{n}} 张蔬菜",
			pickNone: "点上方卡牌选择",
			flipConfirm: "翻面变蔬菜",
			endTurn: "结束回合",
			pileAria: "计分卡堆 {{n}},{{count}} 张",
			marketAria: "市场里的{{name}}",
			estAria: "当前估分 {{n}}",
			vegTotalAria: "蔬菜共 {{n}} 张",
			emptyTableau: "面前还空着,去拿第一张牌吧",
			emptyPoints: "还没有计分牌 · 可以从上方牌堆拿取",
			turnYou: "轮到你",
			waitTitle: "等待中",
			playersLabel: "玩家",
			acting: "行动中",
			marketTitle: "菜摊 · 选牌区",
			marketRefill: "每堆下方补两张蔬菜",
			mySalad: "我的沙拉 · {{n}} 张食材",
			otherSalad: "{{name}}的沙拉 · {{n}} 张食材",
			currentScore: "当前 {{n}} 分",
			myPointCards: "我的计分牌 · {{n}} 张",
			otherPointCards: "计分牌 · {{n}} 张",
			scrollForMore: "上滑查看更多",
			flipCardHint: "拿牌后可点选翻面",
			pickHint: "点选计分牌，或从市场选两张蔬菜",
			selectedVegHint: "已选 {{n}}/{{need}} · {{vegs}}",
			selectedPointHint: "已选第 {{n}} 堆计分牌",
			selectedFlipHint: "已选计分牌 · 翻成{{veg}}",
			waitingHint: "等待当前玩家操作",
			flipToVeg: "翻面成为{{veg}}",
			flipShort: "翻",
			pointCardScore: "本卡 {{n}}",
			pointsUnit: "分",
			cardPer: "按张计分",
			cardPerMulti: "多料计分",
			cardSet: "凑组合",
			cardCompare: "比多少",
			cardParity: "单双奖励",
			cardTotal: "总数比较",
			cardType: "种类奖励",
			cardMissing: "缺少奖励",
			ruleEachVeg: "每张{{veg}}",
			ruleEachSeparate: "每张分别计分",
			rulePerSet: "每组",
			ruleMostVeg: "{{veg}}最多",
			ruleFewestVeg: "{{veg}}最少",
			ruleTiesScore: "并列同得",
			ruleVegCount: "{{veg}}张数",
			ruleTotalMost: "蔬菜总数最多",
			ruleTotalFewest: "蔬菜总数最少",
			ruleTypeMin: "每种至少 {{min}} 张",
			ruleMissingType: "每缺一种蔬菜",
			missingMark: "缺1",
			condMost: "最多{{veg}}={{n}}",
			condFewest: "最少{{veg}}={{n}}",
			condEvenOdd: "{{veg}} 偶={{even}} 奇={{odd}}",
			condTotalMost: "蔬菜总数最多={{n}}",
			condTotalFewest: "蔬菜总数最少={{n}}",
			condTypeGe: "每种≥{{min}}个的蔬菜={{n}}分",
			condMissing: "每缺一种蔬菜={{n}}分",
			shortMost: "最多",
			shortFewest: "最少",
			shortEven: "偶",
			shortOdd: "奇",
			shortTotalMost: "总数最多",
			shortTotalFewest: "总数最少",
			shortTypeGe: "每种≥{{min}}",
			shortMissing: "缺一种",
			finalVeggies: "蔬菜 {{n}} 张",
			errNotYourTurn: "还没轮到你",
			errPileEmpty: "这堆已经拿完了",
			errBadPick: "不能这样拿",
			errBadFlip: "这张卡不能翻",
			hintTakePoint: "拿第 {{n}} 堆的计分卡",
			hintTakeVeg1: "拿 {{veg}}",
			hintTakeVeg2: "拿 {{veg1}} 和 {{veg2}}"
		},
		en: {
			name: "Point Salad",
			desc: "Draft point cards and veggies, mix 108 ways to score",
			rules: "Goal: when every pile and the market is gone, the highest point-card total wins.\nEach turn:\nFirst choose one way to draft cards:\n· Take 1 point card from the top of any of the 3 piles. The scoring conditions on those top cards are public.\n· Take 2 vegetable cards from the market.\n· The market refills automatically; an emptied pile is replaced by half of the largest pile.\n· After drafting, you may flip 1 of your point cards to its veggie side — at most once per turn, and it cannot be flipped back.\nFinal scoring:\n· Count only cards with their vegetable side face up. Each vegetable card can count toward every applicable point card you own.\n· “Most / fewest of a veggie” ties all score; 0 counts (0 is even).\n· Ties go to the player later in turn order.",
			vegP: "Pepper",
			vegL: "Lettuce",
			vegC: "Carrot",
			vegN: "Onion",
			vegT: "Tomato",
			vegB: "Cabbage",
			cardsLeft: "{{n}} left",
			stageDraft: "1 point card / 2 veggies",
			stageFlip: "Flip 1 card or end turn",
			waitTurn: "Waiting for {{name}}…",
			watchHint: "Buttons appear here on your turn",
			takePoint: "Take point card",
			takeVeggies: "Take {{n}} veggies",
			pickNone: "Choose cards",
			flipConfirm: "Flip to veggie",
			endTurn: "End turn",
			pileAria: "Point pile {{n}}, {{count}} cards",
			marketAria: "{{name}} in the market",
			estAria: "Current estimate {{n}}",
			vegTotalAria: "{{n}} veggies",
			emptyTableau: "Nothing yet — go draft your first card",
			emptyPoints: "No point cards yet · take one from a pile above",
			turnYou: "Your turn",
			waitTitle: "Waiting",
			playersLabel: "Players",
			acting: "Playing",
			marketTitle: "Market · pick cards",
			marketRefill: "Two veggies under each pile",
			mySalad: "My salad · {{n}} veggies",
			otherSalad: "{{name}}'s salad · {{n}} veggies",
			currentScore: "Current {{n}} pts",
			myPointCards: "My point cards · {{n}}",
			otherPointCards: "Point cards · {{n}}",
			scrollForMore: "Scroll for more",
			flipCardHint: "Tap a card to flip after drafting",
			pickHint: "Pick a point card or two veggies",
			selectedVegHint: "{{n}}/{{need}} picked · {{vegs}}",
			selectedPointHint: "Point pile {{n}} selected",
			selectedFlipHint: "Card selected · flip to {{veg}}",
			waitingHint: "Waiting for the current player",
			flipToVeg: "Flip to {{veg}}",
			flipShort: "↻",
			pointCardScore: "Card {{n}}",
			pointsUnit: "pts",
			cardPer: "Per card",
			cardPerMulti: "Mixed",
			cardSet: "Make sets",
			cardCompare: "Compare",
			cardParity: "Even / odd",
			cardTotal: "Total",
			cardType: "Types",
			cardMissing: "Missing",
			ruleEachVeg: "Per {{veg}}",
			ruleEachSeparate: "Each card scores",
			rulePerSet: "Per set",
			ruleMostVeg: "Most {{veg}}",
			ruleFewestVeg: "Fewest {{veg}}",
			ruleTiesScore: "Ties score",
			ruleVegCount: "{{veg}} count",
			ruleTotalMost: "Most veggies",
			ruleTotalFewest: "Fewest veggies",
			ruleTypeMin: "Each type ≥ {{min}}",
			ruleMissingType: "Per missing type",
			missingMark: "−1 type",
			condMost: "Most {{veg}}={{n}}",
			condFewest: "Fewest {{veg}}={{n}}",
			condEvenOdd: "{{veg}} even={{even}} odd={{odd}}",
			condTotalMost: "Most veggies={{n}}",
			condTotalFewest: "Fewest veggies={{n}}",
			condTypeGe: "Per type with ≥{{min}}={{n}}",
			condMissing: "Per missing type={{n}}",
			shortMost: "most",
			shortFewest: "fewest",
			shortEven: "even",
			shortOdd: "odd",
			shortTotalMost: "most total",
			shortTotalFewest: "fewest total",
			shortTypeGe: "each ≥{{min}}",
			shortMissing: "missing",
			finalVeggies: "{{n}} veggies",
			errNotYourTurn: "Not your turn",
			errPileEmpty: "This pile is empty",
			errBadPick: "Invalid pick",
			errBadFlip: "Cannot flip this card",
			hintTakePoint: "Take the point card from pile {{n}}",
			hintTakeVeg1: "Take {{veg}}",
			hintTakeVeg2: "Take {{veg1}} and {{veg2}}"
		}
	}
};
//#endregion
export { Ie as default };
