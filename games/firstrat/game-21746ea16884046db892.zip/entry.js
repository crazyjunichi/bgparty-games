import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { avatarNameAt as o, useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { botAvatarOf as l } from "@bgparty/sdk/lobby";
import { BottomSheet as u } from "@bgparty/sdk/bottom-sheet";
import { ConfirmButton as d } from "@bgparty/sdk/confirm-button";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as ee } from "@bgparty/sdk/ui/player-strip";
import { useFxAnchorsMaybe as h } from "@bgparty/sdk/fx/anchors";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { Floater as y, FlySprite as b, PulseBox as x } from "@bgparty/sdk/fx/primitives";
import { playSettle as S } from "@bgparty/sdk/sfx";
import { GameOverScreen as C } from "@bgparty/sdk/ui/game-over-screen";
import { OptionSwitch as w } from "@bgparty/sdk/ui/game-options";
//#region src/games/firstrat/board-data.ts
var T = [
	{
		id: "A1",
		color: "blue",
		res: "bulb",
		n: 1
	},
	{
		id: "A2",
		color: "yellow",
		res: "cheese",
		n: 1
	},
	{
		id: "A3",
		color: "orange",
		res: "soda",
		n: 1
	},
	{
		id: "A4",
		color: "green",
		res: "vinegar",
		n: 1
	},
	{
		id: "A5",
		color: "yellow",
		res: "cheese",
		n: 1
	},
	{
		id: "A6",
		color: "white",
		res: "core",
		n: 1
	},
	{
		id: "B1",
		color: "orange",
		res: "vinegar",
		n: 1
	},
	{
		id: "B2",
		color: "blue",
		res: "bulb",
		n: 2
	},
	{
		id: "B3",
		color: "white",
		res: "core",
		n: 2
	},
	{
		id: "B4",
		color: "green",
		res: "soda",
		n: 1
	},
	{
		id: "B5",
		color: "yellow",
		res: "cheese",
		n: 2
	},
	{
		id: "C1",
		color: "white",
		res: "core",
		n: 3
	},
	{
		id: "C2",
		color: "orange",
		res: "vinegar",
		n: 1
	},
	{
		id: "C3",
		color: "blue",
		res: "bulb",
		n: 2
	},
	{
		id: "C4",
		color: "yellow",
		res: "cheese",
		n: 2
	},
	{
		id: "C5",
		color: "green",
		res: "can",
		n: 1
	},
	{
		id: "D1",
		color: "blue",
		res: "bulb",
		n: 2
	},
	{
		id: "D2",
		color: "orange",
		res: "calculator",
		n: 1
	},
	{
		id: "D3",
		color: "green",
		res: "soda",
		n: 1
	},
	{
		id: "D4",
		color: "white",
		res: "core",
		n: 3
	},
	{
		id: "D5",
		color: "yellow",
		res: "cheese",
		n: 3
	},
	{
		id: "E1",
		color: "blue",
		res: "bulb",
		n: 4
	},
	{
		id: "E2",
		color: "orange",
		res: "can",
		n: 1
	},
	{
		id: "E3",
		color: "yellow",
		res: "cheese",
		n: 4
	},
	{
		id: "E4",
		color: "green",
		res: "calculator",
		n: 1
	},
	{
		id: "E5",
		color: "white",
		res: "core",
		n: 4
	}
], E = [
	[
		"A1",
		"A2",
		"A3",
		"A4",
		"A5",
		"A6"
	],
	[
		"B1",
		"B2",
		"B3",
		"B4",
		"B5"
	],
	[
		"C1",
		"C2",
		"C3",
		"C4",
		"C5"
	],
	[
		"D1",
		"D2",
		"D3",
		"D4",
		"D5"
	],
	[
		"E1",
		"E2",
		"E3",
		"E4",
		"E5"
	]
], te = Object.fromEntries(T.map((e) => [e.id, e])), D = [
	{
		from: 12,
		to: 16,
		cost: "vinegar",
		color: "red"
	},
	{
		from: 11,
		to: 19,
		cost: "can",
		color: "yellow"
	},
	{
		from: 2,
		to: 11,
		cost: "calculator",
		color: "red"
	},
	{
		from: 4,
		to: 9,
		cost: "soda",
		color: "yellow"
	},
	{
		from: 19,
		to: 24,
		cost: "vinegar",
		color: "silver"
	}
], O = [
	0,
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	9,
	10,
	11,
	12,
	13,
	14,
	14,
	15,
	16,
	16,
	17,
	17,
	18,
	18,
	19,
	19,
	19,
	20,
	21,
	21,
	21,
	22,
	22,
	22,
	23,
	23,
	23,
	24,
	24,
	25
], k = [
	13,
	20,
	25
], A = O.length, ne = [
	{
		slot: 8,
		kind: "hamster",
		price: 6
	},
	{
		slot: 14,
		kind: "frog",
		price: 7
	},
	{
		slot: 20,
		kind: "crow",
		price: 12
	}
], j = Object.fromEntries(ne.map((e) => [e.slot, e.kind])), re = {
	T0: ["T1"],
	T1: ["T2"],
	T2: ["T3"],
	T3: ["R0"],
	R0: ["B2"],
	B2: ["M2", "B1"],
	M2: ["T2"],
	B1: ["M1", "B0"],
	M1: ["T1"],
	B0: ["L1"],
	L1: ["T0"]
}, ie = {
	B2: !0,
	B1: !0
}, ae = {
	M2: "comic",
	M1: "rat",
	L1: "food"
}, M = {
	cockpit: [
		8,
		7,
		5,
		5,
		4
	],
	cargoBay: [
		8,
		7,
		6,
		6,
		5
	],
	thruster: [
		9,
		8,
		7,
		7,
		5
	],
	rocket: [
		5,
		4,
		4,
		3,
		2
	],
	provisions: [
		7,
		6,
		6,
		6,
		5
	],
	lights: [
		9,
		7,
		5,
		5,
		4
	],
	food: [
		7,
		7,
		5,
		5,
		4
	],
	rattronaut: [
		10,
		8,
		7,
		7,
		6
	]
}, N = Object.keys(M), oe = (e) => e <= 2 ? [1, 3] : e <= 4 ? [3] : [], P = {
	cockpit: {
		calculator: 2,
		soda: 0,
		vinegar: 0,
		can: 1
	},
	cargoBay: {
		soda: 3,
		can: 2,
		vinegar: 0,
		calculator: 0
	},
	thruster: {
		vinegar: 5,
		soda: 2,
		can: 0,
		calculator: 0
	}
}, F = [
	0,
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9
], I = [
	"pipesYellow",
	"pipesRed",
	"noToll",
	"march14",
	"colorblind",
	"discount",
	"neil",
	"lola",
	"arnold",
	"ratwoman"
], se = [
	"neil",
	"lola",
	"arnold",
	"ratwoman"
], ce = [
	"orange",
	"green",
	"cheese",
	"core",
	"bulb"
], le = [
	0,
	0,
	5,
	6,
	7,
	9
], ue = [
	0,
	0,
	3,
	4,
	5,
	6
], L = {
	id: "firstrat",
	tier: "alpha",
	mechanics: ["engine-building", "set-collection"],
	interactionTags: [],
	nameKey: "games.firstrat.name",
	descKey: "games.firstrat.desc",
	rulesKey: "games.firstrat.rules",
	icon: "🐭",
	iconImg: "games/firstrat.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/firstrat/en.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	accent: "#d97706",
	releasedAt: "2026-09-28",
	search: {
		py: "meng shu zhai yue",
		init: "mszy"
	},
	hotseat: "open"
}, R = t.enum([
	"vinegar",
	"soda",
	"can",
	"calculator"
]), de = t.enum(ce), fe = t.enum(I), pe = t.enum(se), me = t.enum([
	"cockpit",
	"cargoBay",
	"thruster"
]), he = t.enum(N), ge = t.enum(Object.keys(re)), _e = t.string(), ve = t.int().min(0).max(25), z = t.object({
	variantPath: t.boolean().default(!1),
	variantTracks: t.boolean().default(!1)
}).default({
	variantPath: !1,
	variantTracks: !1
}), ye = t.object({
	rat: t.int().min(0).max(3),
	dest: t.int().min(0).max(26),
	pipes: t.array(ve).max(3)
}), be = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("move"),
		moves: t.array(ye).min(1).max(4),
		drink: t.boolean(),
		bonus: t.object({
			orange: R.optional(),
			green: R.optional()
		}),
		launchColor: t.enum([
			"blue",
			"yellow",
			"orange",
			"green",
			"white"
		]).optional(),
		launchReward: t.enum(["award", "rat"]).optional(),
		burrowDirs: t.array(t.enum(["up", "left"])).max(8),
		comics: t.array(t.object({
			comic: fe,
			rat: t.int().min(0).max(3).optional()
		})).max(4)
	}),
	t.object({
		type: t.literal("shop"),
		rat: t.int().min(0).max(3),
		steal: t.boolean(),
		item: t.discriminatedUnion("kind", [
			t.object({
				kind: t.literal("backpack"),
				bp: de
			}),
			t.object({ kind: t.literal("drink") }),
			t.object({
				kind: t.literal("cap"),
				cap: t.int().min(0).max(9)
			})
		])
	}),
	t.object({
		type: t.literal("build"),
		part: me,
		pay: t.partialRecord(R, t.int().min(0).max(8))
	}),
	t.object({ type: t.literal("donate") }),
	t.object({ type: t.literal("endTurn") })
]), xe = t.object({
	pos: t.int().min(-2).max(26),
	super: pe.nullable(),
	slot: t.int().min(0).max(4).nullable()
}), Se = t.object({
	rid: _e,
	cheese: t.int().nonnegative(),
	moldy: t.int().nonnegative(),
	mats: t.record(R, t.int().nonnegative()),
	awards: t.int().nonnegative(),
	drinks: t.int().nonnegative(),
	drinksSpent: t.int().nonnegative(),
	backpacks: t.array(de),
	comics: t.array(fe),
	caps: t.array(t.int().min(0).max(9)),
	rats: t.array(xe).length(4),
	light: t.int().min(0).max(40),
	burrow: ge,
	clScored: t.int().min(0).max(3),
	parts: t.record(me, t.int().nonnegative()),
	tracks: t.partialRecord(he, t.array(t.int().min(0).max(4))),
	freshBackpacks: t.array(de),
	freshComics: t.array(fe)
}), Ce = t.object({
	players: t.array(Se),
	path: t.array(t.string()).length(26),
	activeTracks: t.array(he).min(7).max(8),
	supply: t.object({
		caps: t.array(t.int().min(0).max(9)),
		comics: t.array(fe),
		backpacks: t.array(de),
		drinks: t.int().nonnegative(),
		awards: t.int().nonnegative()
	}),
	turn: t.int().nonnegative(),
	seat: t.int().nonnegative(),
	step: t.enum(["move", "post"]),
	boothRats: t.array(t.int().min(0).max(3)),
	endRound: t.int().nonnegative().nullable(),
	phase: t.enum(["play", "done"])
}), B = t.object({}), we = /* @__PURE__ */ new Set([
	"neil",
	"lola",
	"arnold",
	"ratwoman"
]), Te = 4, V = [
	"vinegar",
	"soda",
	"can",
	"calculator"
], Ee = {
	cockpit: "cockpit",
	cargoBay: "cargoBay",
	thruster: "thruster"
}, H = (e, t) => e.comics.includes(t), U = (e, t, n) => e.rats[t]?.super === n && H(e, n);
function De(e, t, n) {
	if (t <= e || t > 26 || e < -1) return null;
	let r = /* @__PURE__ */ new Map();
	for (let e of n) {
		let t = D.find((t) => t.from === e);
		if (!t || r.has(e)) return null;
		r.set(e, t);
	}
	let i = e, a = 0, o = [];
	for (; i < t;) {
		let e = r.get(i);
		if (e ? (i = e.to, o.push(e), r.delete(e.from)) : i += 1, a += 1, a > 27) return null;
	}
	return i !== t || r.size > 0 ? null : {
		steps: a,
		used: o
	};
}
function Oe(e, t, n) {
	if (n <= 1) return U(e, t, "neil") ? Infinity : U(e, t, "lola") ? 7 : 5;
	let r = H(e, "march14") ? 4 : 3;
	return U(e, t, "lola") ? r + 2 : r;
}
function ke(e) {
	let t = Array(26).fill(0);
	for (let n = 0; n < e && n < A; n += 1) t[O[n]] += 1;
	return t;
}
function W(e, t, n, r, i) {
	let a = ke(e.light), o = {}, s = (e, t) => {
		o[e] = (o[e] ?? 0) + t;
	}, c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set();
	for (let r of t) {
		let t = te[n[r.slot]];
		s(t.res, t.n + a[r.slot]), t.color === "orange" && c.add(t.res), t.color === "green" && l.add(t.res), U(e, r.rat, "arnold") && s(t.res, 1);
	}
	let u = new Set(Object.keys(o));
	if (i.orange !== void 0) {
		if (!e.backpacks.includes("orange") || c.size === 0 || !u.has(i.orange)) return null;
		s(i.orange, 1);
	}
	if (i.green !== void 0) {
		if (!e.backpacks.includes("green") || l.size === 0 || !u.has(i.green)) return null;
		s(i.green, 1);
	}
	if (i.orange !== void 0 && i.green !== void 0 && H(e, "colorblind") && e.backpacks.includes("orange") && e.backpacks.includes("green")) return null;
	if (e.backpacks.includes("cheese") && (o.cheese ?? 0) > 0 && s("cheese", 2), e.backpacks.includes("core") && (o.core ?? 0) > 0 && s("core", 2), e.backpacks.includes("bulb") && (o.bulb ?? 0) > 0 && s("bulb", 2), r) {
		if (e.drinks <= 0) return null;
		for (let e of Object.keys(o)) o[e] = (o[e] ?? 0) * 2;
	}
	return {
		gains: o,
		orangeMats: [...c],
		greenMats: [...l]
	};
}
var Ae = (e) => oe(e.players.length);
function je(e, t, n) {
	return t === "rattronaut" ? e.players.some((t) => e.ps[t].rats.some((e) => e.pos === 26 && e.slot === n)) : e.players.some((r) => (e.ps[r].tracks[t] ?? []).includes(n));
}
function Me(e, t) {
	let n = Ae(e);
	for (let r = 0; r < 4; r += 1) if (!n.includes(r) && !je(e, t, r)) return r;
	return 4;
}
var Ne = (e) => Object.values(e.tracks).reduce((e, t) => e + (t?.length ?? 0), 0);
function Pe(e, t, n) {
	if (!e.activeTracks.includes(n) || Ne(t) >= 10) return null;
	let r = Me(e, n);
	if ((t.tracks[n] ??= []).push(r), Ne(t) === 8) {
		let t = Math.floor(e.turn / e.players.length);
		e.endRound = Math.max(e.endRound ?? -1, t + 1);
	}
	return {
		slot: r,
		value: M[n][r]
	};
}
function Fe(e) {
	let t = {};
	for (let n of e.players) {
		let r = e.ps[n], i = 0;
		for (let t of e.activeTracks) if (t !== "rattronaut") for (let e of r.tracks[t] ?? []) i += M[t][e];
		for (let e of r.rats) {
			if (e.pos !== 26 || e.slot === null) continue;
			let t = M.rattronaut[e.slot];
			e.super === "neil" && (t *= 2), i += t;
		}
		i += Ie(e.activeTracks, r), i += r.awards * 3 + r.moldy * -2, i += Math.floor((r.cheese + V.reduce((e, t) => e + r.mats[t], 0)) / 4), t[n] = i;
	}
	return t;
}
function Ie(e, t) {
	let n = (n) => e.includes(n) ? t.tracks[n]?.length ?? 0 : 0, r = t.rats.filter((e) => e.pos === 26).length, i = t.backpacks.length + t.freshBackpacks.length + t.drinks + t.drinksSpent + t.comics.length + t.freshComics.length + t.caps.length, a = 0;
	for (let e of t.caps) switch (e) {
		case 0:
			a += Math.max(0, 12 - 2 * (n("cockpit") + n("cargoBay") + n("thruster")));
			break;
		case 1:
			a += 4 * n("food");
			break;
		case 2:
			a += 4 * n("lights");
			break;
		case 3:
			a += 4 * n("cockpit");
			break;
		case 4:
			a += 6 * n("rocket");
			break;
		case 5:
			a += 2 * i;
			break;
		case 6:
			a += 5 * n("provisions");
			break;
		case 7:
			a += 5 * n("cargoBay");
			break;
		case 8:
			a += 5 * n("thruster");
			break;
		case 9: a += 4 * r;
	}
	return a;
}
function Le(t, n, r) {
	let i = { c: 0 }, a = (t) => {
		let n = [...t];
		for (let t = n.length - 1; t > 0; --t) {
			let a = e(r, i.c, t + 1);
			i.c += 1, [n[t], n[a]] = [n[a], n[t]];
		}
		return n;
	}, o = E.flatMap((e) => t.variantPath ? a(e) : [...e]), s = [...N];
	if (t.variantTracks) {
		let t = s.filter((e) => e !== "rocket"), n = t[e(r, i.c, t.length)];
		i.c += 1, s = s.filter((e) => e !== n);
	}
	let c = ce.flatMap((e) => [e, e]), l = {
		caps: a(F).slice(0, 6),
		comics: a(I).slice(0, 6),
		backpacks: a(c).slice(0, le[n.length] ?? 9),
		drinks: ue[n.length] ?? 6,
		awards: 16
	}, u = {};
	return n.forEach((e, t) => {
		u[e] = {
			rid: e,
			cheese: t === 0 ? 1 : t <= 2 ? 2 : 3,
			moldy: 0,
			mats: {
				vinegar: 0,
				soda: 0,
				can: 0,
				calculator: 0
			},
			awards: 0,
			drinks: 0,
			drinksSpent: 0,
			backpacks: [],
			comics: [],
			caps: [],
			rats: [
				{
					pos: -1,
					super: null,
					slot: null
				},
				{
					pos: -1,
					super: null,
					slot: null
				},
				{
					pos: -2,
					super: null,
					slot: null
				},
				{
					pos: -2,
					super: null,
					slot: null
				}
			],
			light: 0,
			burrow: "T1",
			clScored: 0,
			parts: {
				cockpit: 0,
				cargoBay: 0,
				thruster: 0
			},
			tracks: {},
			freshBackpacks: [],
			freshComics: []
		};
	}), {
		state: {
			players: n,
			path: o,
			activeTracks: s,
			supply: l,
			ps: u,
			turn: 0,
			step: "move",
			boothRats: [],
			shopped: [],
			endRound: null,
			phase: "play"
		},
		fx: []
	};
}
function Re(e, t, n) {
	if (e.players.indexOf(n) !== e.turn % e.players.length || e.step !== "move") return { code: "games.firstrat.errTurn" };
	let r = structuredClone(e), i = r.ps[n], a = [], o = t.moves, s = o.map((e) => e.rat);
	if (new Set(s).size !== o.length) return { code: "games.firstrat.errMove" };
	for (let e of o) {
		let t = i.rats[e.rat];
		if (!t || t.pos < -1 || t.pos > 25) return { code: "games.firstrat.errMove" };
		let n = De(t.pos, e.dest, e.pipes);
		if (!n || n.steps > Oe(i, e.rat, o.length)) return { code: "games.firstrat.errMove" };
	}
	if (o.length > 1) {
		let e = [];
		for (let n of o) if (n.dest === 26) {
			if (!t.launchColor) return { code: "games.firstrat.errMove" };
			e.push(t.launchColor);
		} else e.push(te[r.path[n.dest]].color);
		let n = new Set(e).size === 1, a = H(i, "colorblind") && e.every((e) => e === "green" || e === "orange");
		if (!n && !a) return { code: "games.firstrat.errMove" };
	}
	let c = i.rats.map((e, t) => {
		let n = o.find((e) => e.rat === t);
		return n ? n.dest : e.pos;
	}).filter((e) => e >= 0 && e < 26);
	if (new Set(c).size !== c.length) return { code: "games.firstrat.errMove" };
	for (let e of o) {
		let t = De(i.rats[e.rat].pos, e.dest, e.pipes);
		if (!t) return { code: "games.firstrat.errMove" };
		for (let e of t.used) if (!(e.color === "yellow" && H(i, "pipesYellow") || e.color === "red" && H(i, "pipesRed"))) {
			if (i.mats[e.cost] <= 0) return { code: "games.firstrat.errPay" };
			--i.mats[e.cost];
		}
	}
	let l = [];
	if (!H(i, "noToll")) {
		let e = /* @__PURE__ */ new Map();
		for (let t of o) if (!(t.dest >= 26)) for (let i of r.players) i !== n && r.ps[i].rats.some((e) => e.pos === t.dest) && e.set(i, (e.get(i) ?? 0) + 1);
		let t = 0;
		for (let n of e.values()) t += n;
		if (t > i.cheese) {
			let e = t - i.cheese, n = Math.ceil(e / 3);
			i.moldy += n, i.cheese += n * 3;
		}
		for (let [t, n] of e) i.cheese -= n, r.ps[t].cheese += n, l.push({
			to: t,
			n
		});
	}
	let u = [];
	for (let e of o) {
		let t = i.rats[e.rat].pos;
		i.rats[e.rat].pos = e.dest, u.push({
			rat: e.rat,
			from: t,
			to: e.dest,
			pipes: e.pipes
		});
	}
	a.push({
		kind: "move",
		rid: n,
		data: {
			legs: u,
			toll: l
		}
	});
	let d = o.filter((e) => e.dest < 26).map((e) => ({
		rat: e.rat,
		slot: e.dest
	})), f = W(i, d, r.path, t.drink, t.bonus);
	if (!f) return { code: "games.firstrat.errBonus" };
	let p = f.gains;
	t.drink && (--i.drinks, i.drinksSpent += 1), i.cheese += p.cheese ?? 0;
	for (let e of V) i.mats[e] += p[e] ?? 0;
	let m = [], ee = i.light, h = p.bulb ?? 0;
	if (h > 0) {
		i.light = Math.min(i.light + h, A);
		for (let e of k) if (e >= ee && e < i.light && i.clScored < 3) {
			i.clScored += 1;
			let e = Pe(r, i, "lights");
			e && m.push({
				kind: "marker",
				rid: n,
				data: {
					track: "lights",
					...e
				}
			});
		}
	}
	let g = i.burrow, _ = p.core ?? 0, v = 0, y = 0, b = [];
	for (let e = 0; e < _; e += 1) {
		let e = re[i.burrow], a;
		if (ie[i.burrow]) {
			let n = t.burrowDirs[v];
			if (n === void 0) return { code: "games.firstrat.errMove" };
			v += 1, a = n === "up" ? e[0] : e[1];
		} else a = e[0];
		i.burrow = a, b.push(a);
		let o = ae[a];
		if (o === "comic" && (y += 1), o === "rat") {
			let e = i.rats.find((e) => e.pos === -2);
			e && (e.pos = -1);
		}
		if (o === "food") {
			let e = Pe(r, i, "food");
			e && m.push({
				kind: "marker",
				rid: n,
				data: {
					track: "food",
					...e
				}
			});
		}
	}
	if (v !== t.burrowDirs.length) return { code: "games.firstrat.errMove" };
	let x = [];
	if (t.comics.length > y) return { code: "games.firstrat.errComic" };
	for (let e of t.comics) {
		if (!r.supply.comics.includes(e.comic)) return { code: "games.firstrat.errComic" };
		if (r.supply.comics = r.supply.comics.filter((t) => t !== e.comic), i.freshComics.push(e.comic), we.has(e.comic)) {
			let t = e.rat === void 0 ? null : i.rats[e.rat];
			if (!t || t.pos < -1 || t.pos >= 26 || t.super !== null) return { code: "games.firstrat.errComic" };
			t.super = e.comic;
		}
		x.push({
			kind: "comic",
			rid: n,
			data: {
				comic: e.comic,
				rat: e.rat ?? null
			}
		});
	}
	(h > 0 || _ > 0 || (p.cheese ?? 0) > 0 || V.some((e) => (p[e] ?? 0) > 0)) && a.push({
		kind: "collect",
		rid: n,
		data: {
			gains: p,
			lightFrom: ee,
			lightTo: i.light,
			burrowFrom: g,
			burrowPath: b,
			drink: t.drink,
			slots: d.map((e) => e.slot)
		}
	}), a.push(...m, ...x);
	for (let e of o) {
		if (e.dest !== 26) continue;
		let o = i.rats[e.rat], s = Me(r, "rattronaut");
		o.slot = s;
		let c = i.rats.filter((e) => e.pos === 26).length, l = i.rats.filter((e) => e.pos >= -1 && e.pos < 26).length, u = t.launchReward;
		if (u === "award") {
			if (r.supply.awards <= 0 || l === 0 && c < Te) return { code: "games.firstrat.errReward" };
			--r.supply.awards, i.awards += 1;
		} else if (u === "rat") {
			let e = i.rats.find((e) => e.pos === -2);
			if (!e) return { code: "games.firstrat.errReward" };
			e.pos = -1;
		} else return { code: "games.firstrat.errReward" };
		if (a.push({
			kind: "launch",
			rid: n,
			data: {
				rat: e.rat,
				slot: s,
				value: M.rattronaut[s],
				reward: u
			}
		}), i.rats.every((e) => e.pos === 26)) {
			let e = Math.floor(r.turn / r.players.length);
			r.endRound = Math.max(r.endRound ?? -1, e);
		}
	}
	return r.boothRats = o.filter((e) => e.dest < 26 && j[e.dest] !== void 0).map((e) => e.rat), r.shopped = [], r.step = "post", {
		state: r,
		fx: a
	};
}
function ze(e, t, n) {
	if (e.players[e.turn % e.players.length] !== n || e.step !== "post") return { code: "games.firstrat.errTurn" };
	let r = e.ps[n].rats[t.rat];
	if (!r || !e.boothRats.includes(t.rat) || e.shopped.includes(t.rat)) return { code: "games.firstrat.errShop" };
	let i = ne.find((e) => e.slot === r.pos);
	if (!i) return { code: "games.firstrat.errShop" };
	let a = structuredClone(e), o = a.ps[n], s = o.rats[t.rat], c = t.item;
	if (c.kind === "backpack") {
		if (i.kind !== "hamster" || !a.supply.backpacks.includes(c.bp) || o.backpacks.includes(c.bp) || o.freshBackpacks.includes(c.bp)) return { code: "games.firstrat.errShop" };
	} else if (c.kind === "drink") {
		if (i.kind !== "frog" || a.supply.drinks <= 0) return { code: "games.firstrat.errShop" };
	} else if (i.kind !== "crow" || !a.supply.caps.includes(c.cap)) return { code: "games.firstrat.errShop" };
	let l = t.steal;
	if (l && (s.super === "neil" && H(o, "neil") || s.super === "ratwoman" && H(o, "ratwoman"))) return { code: "games.firstrat.errShop" };
	if (!l && !(s.super === "ratwoman" && H(o, "ratwoman"))) {
		if (o.cheese < i.price) return { code: "games.firstrat.errPay" };
		o.cheese -= i.price;
	}
	return c.kind === "backpack" ? (a.supply.backpacks = a.supply.backpacks.filter((e) => e !== c.bp), o.freshBackpacks.push(c.bp)) : c.kind === "drink" ? (--a.supply.drinks, o.drinks += 1) : (a.supply.caps = a.supply.caps.filter((e) => e !== c.cap), o.caps.push(c.cap)), l && (s.pos = -1), a.shopped.push(t.rat), {
		state: a,
		fx: [{
			kind: "shop",
			rid: n,
			data: {
				booth: i.kind,
				steal: l,
				item: c,
				rat: t.rat
			}
		}]
	};
}
function Be(e, t, n) {
	if (e.players[e.turn % e.players.length] !== n || e.step !== "post") return { code: "games.firstrat.errTurn" };
	if (!e.activeTracks.includes(Ee[t.part])) return { code: "games.firstrat.errBuild" };
	let r = e.ps[n], i = P[t.part], a = t.pay, o = V.map((e) => a[e] ?? 0), s = V.every((e, t) => o[t] === i[e]), c = H(r, "discount") && V.filter((e, t) => o[t] === i[e] - 1).length === 1 && V.every((e, t) => o[t] === i[e] || o[t] === i[e] - 1);
	if (!s && !c) return { code: "games.firstrat.errBuild" };
	for (let e of V) if ((a[e] ?? 0) > r.mats[e]) return { code: "games.firstrat.errBuild" };
	let l = structuredClone(e), u = l.ps[n];
	for (let e of V) u.mats[e] -= a[e] ?? 0;
	u.parts[t.part] += 1;
	let d = [{
		kind: "build",
		rid: n,
		data: { part: t.part }
	}], f = Pe(l, u, Ee[t.part]);
	f && d.push({
		kind: "marker",
		rid: n,
		data: {
			track: Ee[t.part],
			...f
		}
	});
	let p = Math.min(u.parts.cockpit, u.parts.cargoBay, u.parts.thruster);
	for (; (u.tracks.rocket?.length ?? 0) < p;) {
		let e = Pe(l, u, "rocket");
		if (!e) break;
		d.push({
			kind: "marker",
			rid: n,
			data: {
				track: "rocket",
				...e
			}
		});
	}
	return {
		state: l,
		fx: d
	};
}
function Ve(e, t) {
	if (e.players[e.turn % e.players.length] !== t || e.step !== "post") return { code: "games.firstrat.errTurn" };
	if (e.ps[t].cheese < 10) return { code: "games.firstrat.errPay" };
	let n = structuredClone(e), r = n.ps[t];
	r.cheese -= 10;
	let i = [{
		kind: "donate",
		rid: t,
		data: {}
	}], a = Pe(n, r, "provisions");
	return a && i.push({
		kind: "marker",
		rid: t,
		data: {
			track: "provisions",
			...a
		}
	}), {
		state: n,
		fx: i
	};
}
function He(e, t) {
	if (e.players[e.turn % e.players.length] !== t || e.step !== "post") return { code: "games.firstrat.errTurn" };
	let n = structuredClone(e), r = n.ps[t];
	r.backpacks.push(...r.freshBackpacks), r.comics.push(...r.freshComics), r.freshBackpacks = [], r.freshComics = [], n.turn += 1, n.step = "move", n.boothRats = [], n.shopped = [];
	let i = Math.floor(n.turn / n.players.length);
	return n.endRound !== null && i > n.endRound && (n.phase = "done"), {
		state: n,
		fx: []
	};
}
function Ue(e, t, n) {
	if (e.phase !== "play") return { code: "games.firstrat.errTurn" };
	switch (t.type) {
		case "move": return Re(e, t, n.by);
		case "shop": return ze(e, t, n.by);
		case "build": return Be(e, t, n.by);
		case "donate": return Ve(e, n.by);
		case "endTurn": return He(e, n.by);
	}
}
function We(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n) return [];
	let r = n, i = 0;
	for (let t of e.activeTracks) if (t !== "rattronaut") for (let e of r.tracks[t] ?? []) i += M[t][e];
	let a = 0;
	for (let e of r.rats) e.pos === 26 && e.slot !== null && (a += M.rattronaut[e.slot] * (e.super === "neil" ? 2 : 1));
	let o = Ie(e.activeTracks, r), s = r.awards * 3, c = r.moldy * -2, l = Math.floor((r.cheese + V.reduce((e, t) => e + r.mats[t], 0)) / 4);
	return [
		{
			key: "scoreTracks",
			pts: i
		},
		{
			key: "trackRattronaut",
			pts: a
		},
		{
			key: "scoreCaps",
			pts: o
		},
		{
			key: "scoreAwards",
			pts: s
		},
		{
			key: "scoreMoldy",
			pts: c
		},
		{
			key: "scoreLeftover",
			pts: l
		},
		{
			key: "scoreTotal",
			pts: i + a + o + s + c + l
		}
	];
}
function Ge(e) {
	return {
		public: {
			players: e.players.map((t) => {
				let n = e.ps[t];
				return {
					rid: t,
					cheese: n.cheese,
					moldy: n.moldy,
					mats: n.mats,
					awards: n.awards,
					drinks: n.drinks,
					drinksSpent: n.drinksSpent,
					backpacks: n.backpacks,
					comics: n.comics,
					caps: n.caps,
					rats: n.rats,
					light: n.light,
					burrow: n.burrow,
					clScored: n.clScored,
					parts: n.parts,
					tracks: n.tracks,
					freshBackpacks: n.freshBackpacks,
					freshComics: n.freshComics
				};
			}),
			path: e.path,
			activeTracks: e.activeTracks,
			supply: e.supply,
			turn: e.turn,
			seat: e.turn % e.players.length,
			step: e.step,
			boothRats: e.boothRats.filter((t) => !e.shopped.includes(t)),
			endRound: e.endRound,
			phase: e.phase
		},
		private: {}
	};
}
function Ke(e) {
	if (e.phase !== "done") return { phase: e.step };
	let t = Fe(e), n = (t) => e.ps[t].rats.filter((e) => e.pos === 26).length, r = [...e.players].sort((e, r) => t[r] - t[e] || n(r) - n(e)), i = t[r[0]], a = n(r[0]);
	return {
		phase: "done",
		winner: r.filter((e) => t[e] === i && n(e) === a),
		ranking: r,
		scores: t
	};
}
var qe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: L,
	schemas: {
		action: be,
		publicView: Ce,
		privateView: B,
		config: z
	},
	setup: Le,
	reduce: Ue,
	viewFor: Ge,
	status: Ke
}, G = "var(--color-ink)", Je = {
	cheese: /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M 3 15 L 21 7.5 L 21 18 Q 21 19.5 19.5 19.5 L 4.5 19.5 Q 3 19.5 3 18 Z",
			fill: "#fcd34d",
			stroke: G,
			strokeWidth: 1.8,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ _("circle", {
			cx: 14,
			cy: 15,
			r: 1.6,
			fill: "#f59e0b"
		}),
		/* @__PURE__ */ _("circle", {
			cx: 18,
			cy: 13,
			r: 1.2,
			fill: "#f59e0b"
		}),
		/* @__PURE__ */ _("circle", {
			cx: 9,
			cy: 16.8,
			r: 1.3,
			fill: "#f59e0b"
		})
	] }),
	core: /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M 7.5 4.5 L 16.5 4.5 Q 13 8 13 12 Q 13 16 16.5 19.5 L 7.5 19.5 Q 11 16 11 12 Q 11 8 7.5 4.5 Z",
			fill: "#f8fafc",
			stroke: G,
			strokeWidth: 1.8,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ _("path", {
			d: "M 7.5 4.5 L 16.5 4.5 Q 14.5 7.2 12 7.2 Q 9.5 7.2 7.5 4.5 Z",
			fill: "#ef4444",
			stroke: G,
			strokeWidth: 1.2,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ _("path", {
			d: "M 7.5 19.5 L 16.5 19.5 Q 14.5 16.8 12 16.8 Q 9.5 16.8 7.5 19.5 Z",
			fill: "#ef4444",
			stroke: G,
			strokeWidth: 1.2,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ _("path", {
			d: "M 12 4.2 Q 12 1.8 14 1.2",
			fill: "none",
			stroke: G,
			strokeWidth: 1.4,
			strokeLinecap: "round"
		})
	] }),
	bulb: /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("circle", {
			cx: 12,
			cy: 10,
			r: 6.8,
			fill: "#fde047",
			stroke: G,
			strokeWidth: 1.8
		}),
		/* @__PURE__ */ _("path", {
			d: "M 9.6 11.5 L 12 7.5 L 14.4 11.5",
			fill: "none",
			stroke: "#f59e0b",
			strokeWidth: 1.4,
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ _("rect", {
			x: 9,
			y: 15.8,
			width: 6,
			height: 4.4,
			rx: 1.4,
			fill: "#94a3b8",
			stroke: G,
			strokeWidth: 1.6
		}),
		/* @__PURE__ */ _("path", {
			d: "M 10.8 20.2 L 13.2 20.2 L 12.5 22.4 L 11.5 22.4 Z",
			fill: "#94a3b8",
			stroke: G,
			strokeWidth: 1.2,
			strokeLinejoin: "round"
		})
	] }),
	vinegar: /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M 10 3.5 L 14 3.5 L 14 6.5 Q 17.5 8.5 17.5 13 L 17.5 19 Q 17.5 21 15.5 21 L 8.5 21 Q 6.5 21 6.5 19 L 6.5 13 Q 6.5 8.5 10 6.5 Z",
			fill: "#c4b5fd",
			stroke: G,
			strokeWidth: 1.8,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ _("rect", {
			x: 9.3,
			y: 1.2,
			width: 5.4,
			height: 3,
			rx: 1,
			fill: "#7c3aed",
			stroke: G,
			strokeWidth: 1.4
		}),
		/* @__PURE__ */ _("rect", {
			x: 8.2,
			y: 12,
			width: 7.6,
			height: 5,
			rx: 1,
			fill: "#f8fafc",
			stroke: G,
			strokeWidth: 1.2
		})
	] }),
	soda: /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M 13 7 L 16.8 1.6",
			fill: "none",
			stroke: G,
			strokeWidth: 2.6,
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ _("path", {
			d: "M 13 7 L 16.8 1.6",
			fill: "none",
			stroke: "#f8fafc",
			strokeWidth: 1.3,
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ _("path", {
			d: "M 6.5 8.8 L 17.5 8.8 L 15.8 20 Q 15.6 21.2 14.3 21.2 L 9.7 21.2 Q 8.4 21.2 8.2 20 Z",
			fill: "#f87171",
			stroke: G,
			strokeWidth: 1.8,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ _("rect", {
			x: 5.8,
			y: 6.6,
			width: 12.4,
			height: 2.8,
			rx: 1.4,
			fill: "#fca5a5",
			stroke: G,
			strokeWidth: 1.6
		})
	] }),
	can: /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("rect", {
			x: 6.5,
			y: 5,
			width: 11,
			height: 14.5,
			rx: 2,
			fill: "#9ca3af",
			stroke: G,
			strokeWidth: 1.8
		}),
		/* @__PURE__ */ _("rect", {
			x: 8,
			y: 10.5,
			width: 8,
			height: 4.5,
			fill: "#22c55e"
		}),
		/* @__PURE__ */ _("ellipse", {
			cx: 12,
			cy: 5.2,
			rx: 5.5,
			ry: 1.9,
			fill: "#d1d5db",
			stroke: G,
			strokeWidth: 1.6
		}),
		/* @__PURE__ */ _("circle", {
			cx: 12,
			cy: 5.2,
			r: 1,
			fill: "#6b7280"
		})
	] }),
	calculator: /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("rect", {
			x: 6,
			y: 3.5,
			width: 12,
			height: 17,
			rx: 2,
			fill: "#64748b",
			stroke: G,
			strokeWidth: 1.8
		}),
		/* @__PURE__ */ _("rect", {
			x: 8,
			y: 5.5,
			width: 8,
			height: 4,
			rx: 1,
			fill: "#bae6fd",
			stroke: G,
			strokeWidth: 1.2
		}),
		[
			9,
			12,
			15
		].map((e) => [13.5, 17].map((t) => /* @__PURE__ */ _("circle", {
			cx: e,
			cy: t,
			r: 1.1,
			fill: "#f8fafc"
		}, `${e}:${t}`)))
	] })
};
function Ye({ kind: e }) {
	return Je[e];
}
function Xe({ kind: e, size: t = 16 }) {
	return /* @__PURE__ */ _("svg", {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		className: "inline-block flex-none",
		children: Je[e]
	});
}
function Ze() {
	return /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M 12 5 Q 8 3 4 4 L 4 19 Q 8 18 12 20 Q 16 18 20 19 L 20 4 Q 16 3 12 5 Z",
			fill: "#f8fafc",
			stroke: G,
			strokeWidth: 1.6,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ _("path", {
			d: "M 12 5 L 12 20",
			fill: "none",
			stroke: G,
			strokeWidth: 1.2
		}),
		/* @__PURE__ */ _("path", {
			d: "M 6.8 8 L 10 8.6 M 6.8 11.5 L 10 12.1 M 14 8.6 L 17.2 8 M 14 12.1 L 17.2 11.5",
			fill: "none",
			stroke: "#94a3b8",
			strokeWidth: 1.2,
			strokeLinecap: "round"
		})
	] });
}
function Qe({ x: e, y: t, color: n, isSuper: r = !1, size: i = 32 }) {
	return /* @__PURE__ */ v("g", {
		transform: `translate(${e} ${t}) scale(${i / 37})`,
		children: [
			/* @__PURE__ */ _("path", {
				d: "M 12 8 Q 18.5 8 18.5 1 Q 18.5 -4.5 13.5 -5.5",
				fill: "none",
				stroke: G,
				strokeWidth: 4.6,
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ _("path", {
				d: "M 12 8 Q 18.5 8 18.5 1 Q 18.5 -4.5 13.5 -5.5",
				fill: "none",
				stroke: n,
				strokeWidth: 2.6,
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ _("path", {
				d: "M -17 3 Q -15.5 -3.5 -8 -6.5 Q 1 -10 9.5 -5.5 Q 15.5 -2 14.5 5.5 Q 13.5 11 6 11.5 L -6.5 11.5 Q -14.5 11 -17 3 Z",
				fill: n,
				stroke: G,
				strokeWidth: 2.2,
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ _("circle", {
				cx: -8,
				cy: -7,
				r: 3.4,
				fill: n,
				stroke: G,
				strokeWidth: 2
			}),
			/* @__PURE__ */ _("circle", {
				cx: -11.5,
				cy: -1.5,
				r: 1.5,
				fill: "#ffffff",
				stroke: G,
				strokeWidth: .8
			}),
			/* @__PURE__ */ _("circle", {
				cx: -16.2,
				cy: 2.2,
				r: 1.2,
				fill: G
			}),
			r && /* @__PURE__ */ _("path", {
				d: "M 0 -4.5 L 1.3 -1.4 L 4.5 -1.4 L 2 0.9 L 3 4 L 0 2.2 L -3 4 L -2 0.9 L -4.5 -1.4 L -1.3 -1.4 Z",
				transform: "translate(4 -11)",
				fill: "#fbbf24",
				stroke: G,
				strokeWidth: 1.2,
				strokeLinejoin: "round"
			})
		]
	});
}
var $e = 58, K = 64, et = 64, tt = [
	632,
	534,
	436,
	338,
	240
], q = {
	x: 30,
	y: 694,
	w: 170,
	h: 44
}, J = {
	x: 212,
	y: 698,
	w: 96,
	h: 36
}, Y = {
	x: 338,
	y: 152
}, nt = {
	x: 360,
	y: 68
}, X = {
	x: 95,
	y: 98,
	r: 72
}, rt = 460;
function Z(e) {
	let t = e < 6 ? 0 : 1 + Math.floor((e - 6) / 5), n = e < 6 ? e : (e - 6) % 5, r = tt[t];
	return t === 0 ? {
		x: 50 + et * n,
		y: r
	} : {
		x: 82 + et * (t === 2 || t === 4 ? n : 4 - n),
		y: r
	};
}
var it = (e) => 688 - 16.2 * e, at = [
	"T1",
	"T2",
	"T3",
	"R0",
	"B2",
	"B1",
	"B0",
	"L1",
	"T0"
], ot = (() => {
	let e = {};
	at.forEach((t, n) => {
		let r = (-90 + n * 40) * (Math.PI / 180);
		e[t] = {
			x: X.x + X.r * Math.cos(r),
			y: X.y + X.r * Math.sin(r)
		};
	});
	for (let [t, n] of [["M2", "B2"], ["M1", "B1"]]) {
		let r = e[n], i = r.x - X.x, a = r.y - X.y, o = Math.hypot(i, a) || 1;
		e[t] = {
			x: r.x - i / o * 26,
			y: r.y - a / o * 26
		};
	}
	return e;
})(), st = {
	blue: "#93c5fd",
	yellow: "#fde047",
	orange: "#fdba74",
	green: "#86efac",
	white: "#f8fafc"
}, ct = "#f3e9d2", lt = {
	cheese: "🧀",
	core: "🍎",
	bulb: "💡",
	vinegar: "🍾",
	soda: "🥤",
	can: "🥫",
	calculator: "🧮"
}, ut = {
	red: "#ef4444",
	yellow: "#eab308",
	silver: "#9ca3af"
}, dt = {
	hamster: "🐹",
	frog: "🐸",
	crow: "🐦‍⬛"
}, ft = [
	[[0, 0]],
	[[-12, 0], [12, 0]],
	[
		[-13, -8],
		[13, -8],
		[0, 9]
	],
	[
		[-13, -9],
		[13, -9],
		[-13, 9],
		[13, 9]
	],
	[
		[-14, -10],
		[14, -10],
		[-14, 10],
		[14, 10],
		[0, 0]
	]
];
function pt({ pub: e, members: t, myRid: o, interactive: s, selRat: l, eligible: u, draft: d, onTapSlot: p, onTapRat: m }) {
	let ee = c(), g = i(null), [y, b] = a({
		w: 0,
		h: 0
	}), [x, S] = a({
		cx: 250,
		cy: 385,
		s: 1
	}), C = i({
		cx: 250,
		cy: 385,
		s: 1
	});
	n(() => {
		let e = g.current, t = new ResizeObserver(() => b({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let w = y.w > 0 && y.h > 0 ? Math.min(y.w / 500, y.h / 770) : 1, T = {
		...x,
		s: x.s * w
	};
	n(() => {
		C.current = T;
	});
	let E = h();
	n(() => {
		if (!E) return;
		let e = (e, t, n, r) => () => {
			let i = g.current;
			if (!i) return null;
			let a = i.getBoundingClientRect(), o = C.current;
			return {
				x: a.left + a.width / 2 + (e - o.cx) * o.s - n * o.s / 2,
				y: a.top + a.height / 2 + (t - o.cy) * o.s - r * o.s / 2,
				w: n * o.s,
				h: r * o.s
			};
		}, t = [];
		for (let n = 0; n < 26; n += 1) {
			let r = Z(n);
			t.push([`slot:${n}`, e(r.x, r.y, $e, K)]);
		}
		t.push(["launchpad", e(Y.x, Y.y, 64, 52)]), t.push(["start", e(q.x + q.w / 2, q.y + q.h / 2, q.w, q.h)]), t.push(["burrow", e(X.x, X.y, X.r * 2 + 16, X.r * 2 + 16)]), t.push(["lightstrip", e(rt, 372, 40, 660)]), t.push(["rocket", e(nt.x, nt.y, 110, 130)]);
		for (let [e, n] of t) E.registerProbe(e, n);
		return () => {
			for (let [e] of t) E.registerProbe(e, null);
		};
	}, [E]);
	let O = r(() => {
		let e = /* @__PURE__ */ new Map();
		for (let n of t) e.set(n.rid, f[n.colorIndex % f.length].hex);
		return (t) => e.get(t) ?? "#57534e";
	}, [t]), j = e.players.find((e) => e.rid === o), re = r(() => ke(j?.light ?? 0), [j?.light]), M = r(() => {
		let t = [], n = /* @__PURE__ */ new Map(), r = [], i = [];
		for (let t of e.players) t.rats.forEach((e, a) => {
			let o = {
				rid: t.rid,
				rat: a,
				superId: e.super
			};
			if (e.pos >= 0 && e.pos < 26) {
				let t = n.get(e.pos) ?? [];
				t.push(o), n.set(e.pos, t);
			} else e.pos === -1 ? r.push(o) : e.pos === 26 && i.push(o);
		});
		for (let [e, r] of n) {
			let n = Z(e), i = ft[Math.min(r.length, 5) - 1];
			r.forEach((e, r) => {
				let a = i[Math.min(r, i.length - 1)];
				t.push({
					...e,
					x: n.x + a[0],
					y: n.y + a[1],
					mine: e.rid === o
				});
			});
		}
		return r.forEach((e, n) => {
			t.push({
				...e,
				x: q.x + 24 + n % 6 * 24,
				y: q.y + 14 + Math.floor(n / 6) * 18,
				mine: e.rid === o
			});
		}), i.forEach((e, n) => {
			let r = (-90 + n * 36) * (Math.PI / 180), i = n < 10 ? 38 : 52;
			t.push({
				...e,
				x: Y.x + i * Math.cos(r),
				y: Y.y + i * Math.sin(r),
				mine: e.rid === o
			});
		}), t;
	}, [e.players, o]), N = r(() => {
		let e = [];
		for (let t of M) if (t.mine && s && t.rat !== void 0) {
			let n = j?.rats[t.rat];
			n && n.pos >= -1 && n.pos < 26 && e.push({
				kind: "rat",
				rat: t.rat,
				x: t.x,
				y: t.y,
				r: 26
			});
		}
		if (u) for (let t of u.keys()) if (t === 26) e.push({
			kind: "slot",
			slot: t,
			x: Y.x,
			y: Y.y,
			r: 34
		});
		else {
			let n = Z(t);
			e.push({
				kind: "slot",
				slot: t,
				x: n.x,
				y: n.y,
				r: 38
			});
		}
		return e;
	}, [
		M,
		s,
		j,
		u
	]), oe = (e) => Math.min(Math.max(e, w), w * 5);
	n(() => {
		let e = g.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = C.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = oe(r.s * i), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			C.current = u, S({
				...u,
				s: u.s / w
			});
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [w]);
	let P = i(/* @__PURE__ */ new Map()), F = i(0), I = i(0), se = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), P.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), P.current.size === 1 && (F.current = 0), P.current.size === 2) {
			let [e, t] = [...P.current.values()];
			I.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, ce = (e) => {
		let t = P.current.get(e.pointerId);
		if (!t) return;
		let n = g.current.getBoundingClientRect();
		if (P.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			F.current += Math.abs(n) + Math.abs(r);
			let i = C.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			C.current = a, S({
				...a,
				s: a.s / w
			});
		} else if (P.current.size === 2) {
			P.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...P.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (I.current > 0 && i > 0) {
				let e = C.current, a = oe(e.s * i / I.current), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				C.current = u, S({
					...u,
					s: u.s / w
				});
			}
			I.current = i, F.current = 99;
			return;
		}
		P.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, le = (e) => {
		let t = P.current.size === 1 && F.current < 10;
		if (P.current.delete(e.pointerId), I.current = 0, !t) return;
		let n = g.current.getBoundingClientRect(), r = C.current, i = r.cx + (e.clientX - n.left - n.width / 2) / r.s, a = r.cy + (e.clientY - n.top - n.height / 2) / r.s, o = null, s = Infinity;
		for (let e of N) {
			let t = Math.hypot(i - e.x, a - e.y);
			t < e.r && t < s && (s = t, o = e);
		}
		o && (o.kind === "rat" && o.rat !== void 0 ? m(o.rat) : o.kind === "slot" && o.slot !== void 0 && p(o.slot));
	}, ue = /* @__PURE__ */ new Map();
	return d.forEach((e, t) => ue.set(e.dest, t)), /* @__PURE__ */ _("div", {
		ref: g,
		className: "relative h-full w-full overflow-hidden",
		role: "img",
		"aria-label": ee("games.firstrat.boardAria"),
		children: /* @__PURE__ */ _("svg", {
			className: "h-full w-full touch-none select-none",
			onPointerDown: se,
			onPointerMove: ce,
			onPointerUp: le,
			onPointerCancel: le,
			children: /* @__PURE__ */ v("g", {
				transform: `translate(${y.w / 2 - T.cx * T.s}, ${y.h / 2 - T.cy * T.s}) scale(${T.s})`,
				children: [
					/* @__PURE__ */ _("defs", { children: /* @__PURE__ */ v("linearGradient", {
						id: "fr-bg",
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [
							/* @__PURE__ */ _("stop", {
								offset: "0",
								stopColor: "#1e4258"
							}),
							/* @__PURE__ */ _("stop", {
								offset: "0.55",
								stopColor: "#132a44"
							}),
							/* @__PURE__ */ _("stop", {
								offset: "1",
								stopColor: "#0b1828"
							})
						]
					}) }),
					/* @__PURE__ */ _("rect", {
						x: -40,
						y: -40,
						width: 580,
						height: 850,
						rx: 28,
						fill: "url(#fr-bg)"
					}),
					/* @__PURE__ */ _("rect", {
						x: -40,
						y: -40,
						width: 580,
						height: 850,
						rx: 28,
						fill: "none",
						stroke: "var(--color-ink)",
						strokeWidth: 3
					}),
					[
						[52, 60],
						[180, 34],
						[300, 52],
						[420, 90],
						[470, 180],
						[30, 180],
						[440, 260],
						[26, 470],
						[430, 420],
						[60, 560],
						[420, 580],
						[200, 660],
						[300, 700],
						[455, 660],
						[140, 120],
						[350, 200],
						[240, 300],
						[120, 380],
						[330, 470],
						[210, 470]
					].map(([e, t], n) => /* @__PURE__ */ _("circle", {
						cx: e,
						cy: t,
						r: n % 3 == 0 ? 1.6 : 1,
						fill: "#ffffff",
						opacity: n % 4 == 0 ? .5 : .28
					}, `st${n}`)),
					/* @__PURE__ */ v("g", {
						fill: "none",
						stroke: "#ffffff",
						opacity: .09,
						strokeWidth: 2.5,
						strokeLinecap: "round",
						children: [
							/* @__PURE__ */ _("circle", {
								cx: 30,
								cy: 410,
								r: 11
							}),
							/* @__PURE__ */ _("circle", {
								cx: 30,
								cy: 410,
								r: 4.5
							}),
							/* @__PURE__ */ _("rect", {
								x: 404,
								y: 510,
								width: 18,
								height: 18,
								rx: 2
							}),
							/* @__PURE__ */ _("path", { d: "M 404 510 L 422 528" }),
							/* @__PURE__ */ _("path", { d: "M 27 288 h6 v4 q5 2 5 7 v11 q0 3 -3 3 h-10 q-3 0 -3 -3 v-11 q0 -5 5 -7 Z" }),
							/* @__PURE__ */ _("rect", {
								x: 404,
								y: 290,
								width: 14,
								height: 20,
								rx: 3
							}),
							/* @__PURE__ */ _("ellipse", {
								cx: 411,
								cy: 290,
								rx: 7,
								ry: 2.5
							})
						]
					}),
					D.map((e, t) => {
						let n = Z(e.from), r = Z(e.to), i = (n.x + r.x) / 2, a = (n.y + r.y) / 2, o = r.x - n.x, s = r.y - n.y, c = Math.hypot(o, s) || 1, l = i + -s / c * 46, u = a + o / c * 46, d = `M ${n.x} ${n.y} Q ${l} ${u} ${r.x} ${r.y}`;
						return /* @__PURE__ */ v("g", { children: [
							/* @__PURE__ */ _("path", {
								d,
								fill: "none",
								stroke: ct,
								strokeWidth: 13,
								strokeLinecap: "round"
							}),
							/* @__PURE__ */ _("path", {
								d,
								fill: "none",
								stroke: ut[e.color],
								strokeWidth: 9,
								strokeLinecap: "round"
							}),
							/* @__PURE__ */ v("g", {
								transform: `translate(${l} ${u})`,
								children: [/* @__PURE__ */ _("circle", {
									r: 12,
									fill: "#ffffff",
									stroke: "var(--color-ink)",
									strokeWidth: 2
								}), /* @__PURE__ */ _("svg", {
									x: -8,
									y: -8,
									width: 16,
									height: 16,
									viewBox: "0 0 24 24",
									children: /* @__PURE__ */ _(Ye, { kind: e.cost })
								})]
							})
						] }, `pipe${t}`);
					}),
					e.path.map((e, t) => {
						let n = te[e], r = Z(t), i = re[t], a = ne.find((e) => e.slot === t);
						return /* @__PURE__ */ v("g", { children: [
							/* @__PURE__ */ _("rect", {
								x: r.x - $e / 2 - 5,
								y: r.y - K / 2 - 5,
								width: 68,
								height: 74,
								rx: 14,
								fill: st[n.color],
								opacity: .28
							}),
							/* @__PURE__ */ _("rect", {
								x: r.x - $e / 2,
								y: r.y - K / 2,
								width: $e,
								height: K,
								rx: 10,
								fill: st[n.color],
								stroke: "var(--color-ink)",
								strokeWidth: 2.5
							}),
							/* @__PURE__ */ _("svg", {
								x: r.x - 15,
								y: r.y - 21,
								width: 30,
								height: 30,
								viewBox: "0 0 24 24",
								children: /* @__PURE__ */ _(Ye, { kind: n.res })
							}),
							/* @__PURE__ */ _("text", {
								x: r.x + $e / 2 - 5,
								y: r.y + K / 2 - 4,
								textAnchor: "end",
								fontSize: 14,
								fontWeight: 800,
								fill: "var(--color-ink)",
								fontFamily: "monospace",
								children: n.n
							}),
							i > 0 && /* @__PURE__ */ v("g", {
								transform: `translate(${r.x - $e / 2 + 3} ${r.y - K / 2 - 5})`,
								children: [/* @__PURE__ */ _("rect", {
									x: -2,
									y: -7,
									width: 26,
									height: 14,
									rx: 7,
									fill: "#fbbf24",
									stroke: "var(--color-ink)",
									strokeWidth: 1.5
								}), /* @__PURE__ */ v("text", {
									x: 11,
									y: 1,
									textAnchor: "middle",
									dominantBaseline: "central",
									fontSize: 10,
									fontWeight: 800,
									fill: "var(--color-ink)",
									children: ["+", i]
								})]
							}),
							a && /* @__PURE__ */ v("g", {
								transform: `translate(${r.x} ${r.y - K / 2 - 13})`,
								children: [
									/* @__PURE__ */ _("rect", {
										x: -22,
										y: -11,
										width: 44,
										height: 22,
										rx: 8,
										fill: "#ffffff",
										stroke: "var(--color-ink)",
										strokeWidth: 2
									}),
									/* @__PURE__ */ _("text", {
										x: -7,
										y: 1,
										textAnchor: "middle",
										dominantBaseline: "central",
										fontSize: 13,
										children: dt[a.kind]
									}),
									/* @__PURE__ */ v("text", {
										x: 9,
										y: 1,
										textAnchor: "middle",
										dominantBaseline: "central",
										fontSize: 11,
										fontWeight: 800,
										fill: "var(--color-ink)",
										fontFamily: "monospace",
										children: [a.price, "🧀"]
									})
								]
							})
						] }, e);
					}),
					u && [...u.entries()].map(([e]) => {
						let t = e === 26 ? Y : Z(e), n = e === 26 ? 64 : 66, r = e === 26 ? 52 : 72;
						return /* @__PURE__ */ v("g", {
							pointerEvents: "none",
							className: "hint-flash",
							children: [
								/* @__PURE__ */ _("rect", {
									x: t.x - n / 2,
									y: t.y - r / 2,
									width: n,
									height: r,
									rx: 12,
									fill: "#ffffff",
									opacity: .3
								}),
								/* @__PURE__ */ _("rect", {
									x: t.x - n / 2,
									y: t.y - r / 2,
									width: n,
									height: r,
									rx: 12,
									fill: "none",
									stroke: "#ffffff",
									strokeWidth: 6
								}),
								/* @__PURE__ */ _("rect", {
									x: t.x - n / 2,
									y: t.y - r / 2,
									width: n,
									height: r,
									rx: 12,
									fill: "none",
									stroke: "var(--color-ink)",
									strokeWidth: 3,
									strokeDasharray: "9 6",
									strokeLinecap: "round",
									children: /* @__PURE__ */ _("animate", {
										attributeName: "stroke-dashoffset",
										from: "0",
										to: "-30",
										dur: "0.7s",
										repeatCount: "indefinite"
									})
								})
							]
						}, `e${e}`);
					}),
					[...ue.entries()].map(([e, t]) => {
						let n = e === 26 ? Y : Z(e);
						return /* @__PURE__ */ v("g", {
							pointerEvents: "none",
							transform: `translate(${n.x + 20} ${n.y - 26})`,
							children: [/* @__PURE__ */ _("circle", {
								r: 10,
								fill: "var(--color-ink)"
							}), /* @__PURE__ */ _("text", {
								y: 1,
								textAnchor: "middle",
								dominantBaseline: "central",
								fontSize: 12,
								fontWeight: 900,
								fill: "#ffffff",
								fontFamily: "monospace",
								children: t + 1
							})]
						}, `d${e}`);
					}),
					/* @__PURE__ */ v("g", { children: [
						/* @__PURE__ */ _("rect", {
							x: q.x,
							y: q.y,
							width: q.w,
							height: q.h,
							rx: 14,
							fill: "#ffffff",
							stroke: "var(--color-ink)",
							strokeWidth: 2.5,
							strokeDasharray: "7 5"
						}),
						/* @__PURE__ */ v("text", {
							x: q.x + q.w / 2,
							y: q.y - 6,
							textAnchor: "middle",
							fontSize: 11,
							fontWeight: 900,
							fill: ct,
							children: ["🏁 ", ee("games.firstrat.startLabel")]
						}),
						/* @__PURE__ */ _("rect", {
							x: J.x,
							y: J.y,
							width: J.w,
							height: J.h,
							rx: 14,
							fill: "#d6d3d1",
							stroke: "var(--color-ink)",
							strokeWidth: 2.5
						}),
						/* @__PURE__ */ v("text", {
							x: J.x + J.w / 2,
							y: J.y - 6,
							textAnchor: "middle",
							fontSize: 11,
							fontWeight: 900,
							fill: ct,
							children: ["🕳️ ", ee("games.firstrat.nurseryLabel")]
						}),
						e.players.flatMap((e) => e.rats.map((t, n) => ({
							rid: e.rid,
							r: t,
							i: n
						})).filter(({ r: e }) => e.pos === -2).map(({ rid: e }, t) => /* @__PURE__ */ _("circle", {
							cx: J.x + 16 + t * 16,
							cy: J.y + J.h / 2,
							r: 6.5,
							fill: O(e),
							stroke: "var(--color-ink)",
							strokeWidth: 1.5
						}, `${e}n${t}`)))
					] }),
					/* @__PURE__ */ v("g", { children: [
						/* @__PURE__ */ _("path", {
							d: `M ${Z(25).x} ${Z(25).y - K / 2 - 4} L ${Y.x} ${Y.y + 30}`,
							stroke: ct,
							strokeWidth: 2.5,
							strokeDasharray: "6 5",
							fill: "none"
						}),
						/* @__PURE__ */ v("g", {
							transform: `translate(${nt.x} ${nt.y})`,
							children: [
								/* @__PURE__ */ _("path", {
									d: "M -20 38 L -34 62 L -16 52 Z",
									fill: "#f87171",
									stroke: "var(--color-ink)",
									strokeWidth: 2.5,
									strokeLinejoin: "round"
								}),
								/* @__PURE__ */ _("path", {
									d: "M 20 38 L 34 62 L 16 52 Z",
									fill: "#f87171",
									stroke: "var(--color-ink)",
									strokeWidth: 2.5,
									strokeLinejoin: "round"
								}),
								/* @__PURE__ */ _("ellipse", {
									cx: 0,
									cy: 0,
									rx: 24,
									ry: 46,
									fill: "#f8fafc",
									stroke: "var(--color-ink)",
									strokeWidth: 2.5
								}),
								/* @__PURE__ */ _("path", {
									d: "M -24 -18 A 24 46 0 0 1 24 -18 L 24 -8 A 24 46 0 0 0 -24 -8 Z",
									fill: "#f87171",
									stroke: "var(--color-ink)",
									strokeWidth: 2
								}),
								/* @__PURE__ */ _("circle", {
									cx: 0,
									cy: 10,
									r: 10,
									fill: "#bae6fd",
									stroke: "var(--color-ink)",
									strokeWidth: 2.5
								}),
								/* @__PURE__ */ _("path", {
									d: "M -10 46 Q 0 66 10 46 Q 0 54 -10 46 Z",
									fill: "#fbbf24",
									stroke: "var(--color-ink)",
									strokeWidth: 2
								}),
								/* @__PURE__ */ _("svg", {
									x: -8,
									y: 21,
									width: 16,
									height: 16,
									viewBox: "0 0 24 24",
									children: /* @__PURE__ */ _(Ye, { kind: "cheese" })
								})
							]
						}),
						/* @__PURE__ */ _("ellipse", {
							cx: Y.x,
							cy: Y.y,
							rx: 34,
							ry: 20,
							fill: "#d6d3d1",
							stroke: "var(--color-ink)",
							strokeWidth: 2.5
						}),
						/* @__PURE__ */ _("ellipse", {
							cx: Y.x,
							cy: Y.y - 3,
							rx: 24,
							ry: 12,
							fill: "#a8a29e",
							stroke: "var(--color-ink)",
							strokeWidth: 1.5
						})
					] }),
					/* @__PURE__ */ v("g", { children: [
						/* @__PURE__ */ _("polyline", {
							points: [
								`${rt},726`,
								...Array.from({ length: A }, (e, t) => `${rt},${it(t)}`),
								`${nt.x + 30},${nt.y + 40}`
							].join(" "),
							fill: "none",
							stroke: ct,
							strokeWidth: 2
						}),
						/* @__PURE__ */ v("g", {
							transform: `translate(${rt} 726)`,
							children: [/* @__PURE__ */ _("rect", {
								x: -10,
								y: -8,
								width: 20,
								height: 16,
								rx: 4,
								fill: "#78716c",
								stroke: ct,
								strokeWidth: 2
							}), /* @__PURE__ */ _("path", {
								d: "M 2.5 -5 L -3 1.5 L -0.3 1.5 L -2.5 5 L 3 -1.5 L 0.3 -1.5 Z",
								fill: "#fde047",
								stroke: "var(--color-ink)",
								strokeWidth: .8,
								strokeLinejoin: "round"
							})]
						}),
						Array.from({ length: A }, (e, t) => {
							let n = k.includes(t), r = it(t);
							return /* @__PURE__ */ v("g", { children: [
								/* @__PURE__ */ _("circle", {
									cx: rt,
									cy: r,
									r: 10,
									fill: "#fde047",
									opacity: .16
								}),
								n ? /* @__PURE__ */ _("rect", {
									x: 453,
									y: r - 7,
									width: 14,
									height: 14,
									rx: 4,
									fill: "#fbbf24",
									stroke: "var(--color-ink)",
									strokeWidth: 2
								}) : /* @__PURE__ */ _("circle", {
									cx: rt,
									cy: r,
									r: 5.5,
									fill: "#fef08a",
									stroke: "var(--color-ink)",
									strokeWidth: 1.5
								}),
								n && /* @__PURE__ */ _("path", {
									d: "M 2.5 -5 L -3 1.5 L -0.3 1.5 L -2.5 5 L 3 -1.5 L 0.3 -1.5 Z",
									transform: `translate(${rt} ${r}) scale(0.9)`,
									fill: "var(--color-ink)"
								})
							] }, `b${t}`);
						}),
						e.players.map((t, n) => {
							if (t.light <= 0) return null;
							let r = Math.min(t.light - 1, A - 1);
							return /* @__PURE__ */ _("circle", {
								cx: 449,
								cy: it(r) + (n - (e.players.length - 1) / 2) * 4,
								r: 5,
								fill: O(t.rid),
								stroke: "var(--color-ink)",
								strokeWidth: 1.5
							}, `lm${t.rid}`);
						})
					] }),
					/* @__PURE__ */ v("g", { children: [
						/* @__PURE__ */ _("circle", {
							cx: X.x,
							cy: X.y,
							r: X.r,
							fill: "#9c7a4d",
							stroke: "var(--color-ink)",
							strokeWidth: 2.5
						}),
						/* @__PURE__ */ _("circle", {
							cx: X.x,
							cy: X.y,
							r: X.r - 18,
							fill: "#7d5f3a",
							stroke: "var(--color-ink)",
							strokeWidth: 1.5
						}),
						["M2", "M1"].map((e) => {
							let t = ot[e === "M2" ? "B2" : "B1"], n = ot[e];
							return /* @__PURE__ */ _("line", {
								x1: t.x,
								y1: t.y,
								x2: n.x,
								y2: n.y,
								stroke: "var(--color-ink)",
								strokeWidth: 2.5,
								strokeDasharray: "4 3"
							}, e);
						}),
						Object.keys(ot).map((e) => {
							let t = ot[e], n = ae[e], r = ie[e];
							return /* @__PURE__ */ v("g", {
								transform: `translate(${t.x} ${t.y})`,
								children: [
									/* @__PURE__ */ _("circle", {
										r: n ? 15 : r ? 12 : 10.5,
										fill: n ? "#fef3c7" : r ? "#fde68a" : "#f5f5f4",
										stroke: "var(--color-ink)",
										strokeWidth: 2
									}),
									n === "comic" && /* @__PURE__ */ _("svg", {
										x: -9,
										y: -9,
										width: 18,
										height: 18,
										viewBox: "0 0 24 24",
										children: /* @__PURE__ */ _(Ze, {})
									}),
									n === "rat" && /* @__PURE__ */ _(Qe, {
										x: 0,
										y: 0,
										color: "#a8a29e",
										size: 19
									}),
									n === "food" && /* @__PURE__ */ _("svg", {
										x: -8.5,
										y: -8.5,
										width: 17,
										height: 17,
										viewBox: "0 0 24 24",
										children: /* @__PURE__ */ _(Ye, { kind: "can" })
									}),
									e === "T1" && /* @__PURE__ */ _("text", {
										y: 1,
										textAnchor: "middle",
										dominantBaseline: "central",
										fontSize: 11,
										fontWeight: 900,
										fill: "var(--color-ink)",
										children: "▶"
									})
								]
							}, e);
						}),
						e.players.map((e, t) => /* @__PURE__ */ _("circle", {
							cx: ot[e.burrow].x + (t % 3 - 1) * 7,
							cy: ot[e.burrow].y + (Math.floor(t / 3) - .5) * 8.5,
							r: 5.5,
							fill: O(e.rid),
							stroke: "var(--color-ink)",
							strokeWidth: 1.5
						}, `bm${e.rid}`))
					] }),
					M.map((e) => {
						let t = e.mine && l === e.rat, n = e.superId !== null, r = e.mine ? j?.rats[e.rat] : void 0, i = s && r !== void 0 && r.pos >= -1 && r.pos < 26;
						return /* @__PURE__ */ v("g", {
							pointerEvents: "none",
							children: [
								/* @__PURE__ */ _("circle", {
									cx: e.x,
									cy: e.y + 2,
									r: 13.5,
									fill: "#000000",
									opacity: .22
								}),
								n && /* @__PURE__ */ _("circle", {
									cx: e.x,
									cy: e.y,
									r: 14.5,
									fill: "none",
									stroke: "#fbbf24",
									strokeWidth: 2.5
								}),
								i && !t && /* @__PURE__ */ v("g", {
									className: "hint-flash",
									children: [/* @__PURE__ */ _("circle", {
										cx: e.x,
										cy: e.y,
										r: 17,
										fill: "none",
										stroke: "#ffffff",
										strokeWidth: 3.5
									}), /* @__PURE__ */ _("circle", {
										cx: e.x,
										cy: e.y,
										r: 17,
										fill: "none",
										stroke: "var(--color-ink)",
										strokeWidth: 1.8,
										strokeDasharray: "6 5",
										strokeLinecap: "round",
										children: /* @__PURE__ */ _("animate", {
											attributeName: "stroke-dashoffset",
											from: "0",
											to: "-22",
											dur: "0.7s",
											repeatCount: "indefinite"
										})
									})]
								}),
								t && /* @__PURE__ */ _("circle", {
									cx: e.x,
									cy: e.y,
									r: 17,
									fill: "none",
									stroke: "#ffffff",
									strokeWidth: 4,
									className: "hint-flash"
								}),
								/* @__PURE__ */ _(Qe, {
									x: e.x,
									y: e.y,
									color: O(e.rid),
									isSuper: n,
									size: 32
								})
							]
						}, `${e.rid}:${e.rat}`);
					})
				]
			})
		})
	});
}
var Q = lt, mt = [
	"vinegar",
	"soda",
	"can",
	"calculator"
], ht = {
	cockpit: "games.firstrat.trackCockpit",
	cargoBay: "games.firstrat.trackCargoBay",
	thruster: "games.firstrat.trackThruster",
	rocket: "games.firstrat.trackRocket",
	provisions: "games.firstrat.trackProvisions",
	lights: "games.firstrat.trackLights",
	food: "games.firstrat.trackFood",
	rattronaut: "games.firstrat.trackRattronaut"
}, gt = {
	pipesYellow: "games.firstrat.comicPipesYellow",
	pipesRed: "games.firstrat.comicPipesRed",
	noToll: "games.firstrat.comicNoToll",
	march14: "games.firstrat.comicMarch14",
	colorblind: "games.firstrat.comicColorblind",
	discount: "games.firstrat.comicDiscount",
	neil: "games.firstrat.comicNeil",
	lola: "games.firstrat.comicLola",
	arnold: "games.firstrat.comicArnold",
	ratwoman: "games.firstrat.comicRatwoman"
}, _t = {
	pipesYellow: "games.firstrat.comicDescPipesYellow",
	pipesRed: "games.firstrat.comicDescPipesRed",
	noToll: "games.firstrat.comicDescNoToll",
	march14: "games.firstrat.comicDescMarch14",
	colorblind: "games.firstrat.comicDescColorblind",
	discount: "games.firstrat.comicDescDiscount",
	neil: "games.firstrat.comicDescNeil",
	lola: "games.firstrat.comicDescLola",
	arnold: "games.firstrat.comicDescArnold",
	ratwoman: "games.firstrat.comicDescRatwoman"
}, vt = {
	orange: "games.firstrat.bpOrange",
	green: "games.firstrat.bpGreen",
	cheese: "games.firstrat.bpCheese",
	core: "games.firstrat.bpCore",
	bulb: "games.firstrat.bpBulb"
}, yt = {
	orange: "games.firstrat.bpDescOrange",
	green: "games.firstrat.bpDescGreen",
	cheese: "games.firstrat.bpDescCheese",
	core: "games.firstrat.bpDescCore",
	bulb: "games.firstrat.bpDescBulb"
}, bt = {
	0: "games.firstrat.cap0",
	1: "games.firstrat.cap1",
	2: "games.firstrat.cap2",
	3: "games.firstrat.cap3",
	4: "games.firstrat.cap4",
	5: "games.firstrat.cap5",
	6: "games.firstrat.cap6",
	7: "games.firstrat.cap7",
	8: "games.firstrat.cap8",
	9: "games.firstrat.cap9"
}, xt = {
	0: "games.firstrat.capDesc0",
	1: "games.firstrat.capDesc1",
	2: "games.firstrat.capDesc2",
	3: "games.firstrat.capDesc3",
	4: "games.firstrat.capDesc4",
	5: "games.firstrat.capDesc5",
	6: "games.firstrat.capDesc6",
	7: "games.firstrat.capDesc7",
	8: "games.firstrat.capDesc8",
	9: "games.firstrat.capDesc9"
}, St = {
	blue: "games.firstrat.colorBlue",
	yellow: "games.firstrat.colorYellow",
	orange: "games.firstrat.colorOrange",
	green: "games.firstrat.colorGreen",
	white: "games.firstrat.colorWhite"
}, Ct = {
	cockpit: "games.firstrat.trackCockpit",
	cargoBay: "games.firstrat.trackCargoBay",
	thruster: "games.firstrat.trackThruster"
}, wt = {
	hamster: "games.firstrat.boothHamster",
	frog: "games.firstrat.boothFrog",
	crow: "games.firstrat.boothCrow"
}, Tt = new Set(se);
function Et(e, t) {
	return l(e.rid) === null ? e.name : o(t, e.avatar);
}
function Dt(e, t, n, r, i) {
	let a = /* @__PURE__ */ new Map(), o = t.rats[n]?.pos ?? -99;
	if (o < -1 || o > 25) return a;
	let s = Oe(t, n, r.length + 1), c = /* @__PURE__ */ new Set();
	t.rats.forEach((e, t) => {
		if (t === n) return;
		let i = r.find((e) => e.rat === t), a = i ? i.dest : e.pos;
		a >= 0 && a < 26 && c.add(a);
	});
	let l = null;
	if (r.length > 0) {
		let n = r[0].dest === 26 ? i : te[e.path[r[0].dest]].color;
		if (!n) return a;
		l = /* @__PURE__ */ new Set([n]), t.comics.includes("colorblind") && (n === "green" || n === "orange") && (l.add("green"), l.add("orange"));
	}
	for (let n = o + 1; n <= 26; n += 1) {
		let r = D.filter((e) => e.from >= o && e.from < n);
		if (n - o > s && r.length === 0) break;
		if (n !== 26 && (c.has(n) || l && !l.has(te[e.path[n]].color))) continue;
		let i = null;
		for (let e = 0; e < 1 << r.length; e += 1) {
			let a = [];
			for (let t = 0; t < r.length; t += 1) e & 1 << t && a.push(r[t].from);
			let c = De(o, n, a);
			if (!c || c.steps > s) continue;
			let l = {};
			for (let e of c.used) e.color === "yellow" && t.comics.includes("pipesYellow") || e.color === "red" && t.comics.includes("pipesRed") || (l[e.cost] = (l[e.cost] ?? 0) + 1);
			if (!mt.every((e) => (l[e] ?? 0) <= t.mats[e])) continue;
			let u = Object.values(l).reduce((e, t) => e + t, 0);
			(!i || c.steps < i.steps || c.steps === i.steps && u < i.cost) && (i = {
				steps: c.steps,
				cost: u,
				froms: a
			});
		}
		i && a.set(n, i.froms);
	}
	return a;
}
function Ot(e, t, n) {
	let r = e, i = [], a = 0;
	for (let e = 0; e < t; e += 1) {
		let e = re[r];
		if (ie[r]) {
			let t = n[a];
			if (t === void 0) return {
				path: i,
				needMore: !0,
				junctionsShown: a + 1
			};
			r = t === "up" ? e[0] : e[1], a += 1;
		} else r = e[0];
		i.push(r);
	}
	return {
		path: i,
		needMore: !1,
		junctionsShown: a
	};
}
var kt = {
	drink: !1,
	dirs: [],
	comicPicks: []
};
function At({ pub: e, members: t, nameOf: n }) {
	let r = c();
	return /* @__PURE__ */ v("div", {
		className: "firstrat-overview flex flex-col gap-3",
		children: [
			/* @__PURE__ */ _("p", {
				className: "section-label",
				children: r("games.firstrat.tracksTitle")
			}),
			/* @__PURE__ */ _("div", {
				className: "firstrat-tracks",
				children: N.map((i) => {
					let a = e.activeTracks.includes(i), o = oe(e.players.length);
					return /* @__PURE__ */ v("div", {
						className: `firstrat-track flex items-center gap-1.5 ${a ? "" : "opacity-40"}`,
						children: [/* @__PURE__ */ v("span", {
							className: "firstrat-track-label w-16 flex-none text-xs font-bold",
							children: [r(ht[i]), !a && /* @__PURE__ */ _("span", {
								className: "block text-[9px]",
								children: r("games.firstrat.trackRemoved")
							})]
						}), M[i].map((r, a) => {
							let s = i === "rattronaut" ? e.players.filter((e) => e.rats.some((e) => e.pos === 26 && e.slot === a)) : e.players.filter((e) => (e.tracks[i] ?? []).includes(a)), c = a < 4 && o.includes(a);
							return /* @__PURE__ */ v("span", {
								className: `firstrat-track-slot relative grid min-h-8 flex-1 place-items-center rounded-lg border-2 border-ink font-mono text-xs font-extrabold tabular-nums ${c ? "bg-stone-300" : "bg-surface"}`,
								children: [c ? "✕" : r, /* @__PURE__ */ _("span", {
									className: "absolute inset-x-0 bottom-0 flex justify-center gap-0.5",
									children: s.map((e) => {
										let r = t.find((t) => t.rid === e.rid), i = f[(r?.colorIndex ?? 0) % f.length].hex;
										return /* @__PURE__ */ _("span", {
											className: "firstrat-track-marker mb-0.5 inline-block h-2 w-2 rounded-full border border-ink",
											style: { background: i },
											title: n(e.rid)
										}, e.rid);
									})
								})]
							}, a);
						})]
					}, i);
				})
			}),
			/* @__PURE__ */ v("p", {
				className: "firstrat-supply text-xs font-bold opacity-70",
				children: [
					r("games.firstrat.awardsLeft", { n: e.supply.awards }),
					" · 🥤",
					e.supply.drinks,
					" · ",
					r("games.firstrat.supplyComics"),
					" ",
					e.supply.comics.length
				]
			}),
			/* @__PURE__ */ _("p", {
				className: "section-label",
				children: r("games.firstrat.itemsTitle")
			}),
			/* @__PURE__ */ _("div", {
				className: "firstrat-items",
				children: e.players.map((e) => /* @__PURE__ */ v("div", {
					className: "firstrat-item plate px-2 py-1.5 text-xs font-bold",
					children: [
						/* @__PURE__ */ _("p", {
							className: "text-sm font-extrabold",
							children: n(e.rid)
						}),
						/* @__PURE__ */ v("p", {
							className: "mt-0.5 opacity-80",
							children: [e.backpacks.map((e) => r(vt[e])).join(" / ") || "—", e.freshBackpacks.length > 0 && ` (+${e.freshBackpacks.map((e) => r(vt[e])).join("/")})`]
						}),
						/* @__PURE__ */ v("p", {
							className: "opacity-80",
							children: [e.comics.map((e) => r(gt[e])).join(" / ") || "—", e.freshComics.length > 0 && ` (+${e.freshComics.map((e) => r(gt[e])).join("/")})`]
						}),
						/* @__PURE__ */ v("p", {
							className: "opacity-80",
							children: [
								e.caps.map((e) => r(bt[e])).join(" / ") || "—",
								" · ",
								r("games.firstrat.drinkN", { n: e.drinks + e.drinksSpent }),
								" ·",
								" ",
								r("games.firstrat.awardN", { n: e.awards }),
								" · ",
								r("games.firstrat.moldyN", { n: e.moldy })
							]
						})
					]
				}, e.rid))
			})
		]
	});
}
function jt(e) {
	let t = e.public, { members: n, myRid: i, send: o } = e, l = c(), f = s((e) => e.locale), h = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? Et(t, f) : e;
	}, y = t.players.find((e) => e.rid === i), b = y, x = t.phase === "play" && t.players[t.seat]?.rid === i, S = x && t.step === "move", C = x && t.step === "post", [w, T] = a(null), [E, D] = a([]), [O, k] = a(kt), [A, j] = a(!1), [re, ie] = a(!1), [M, N] = a(!1), [oe, F] = a(!1), [I, se] = a({}), ce = `${t.turn}|${t.step}|${t.phase}`, [le, ue] = a(ce);
	le !== ce && (ue(ce), T(null), D([]), k(kt), j(!1), ie(!1), N(!1));
	let R = JSON.stringify(E), [de, fe] = a(R);
	R !== de && (fe(R), k(kt));
	let pe = r(() => !S || w === null || !b || A ? null : Dt(t, b, w, E, O.launchColor), [
		S,
		w,
		R,
		O.launchColor,
		A,
		t,
		b
	]), me = E.filter((e) => e.dest < 26).map((e) => ({
		rat: e.rat,
		slot: e.dest
	})), he = b && me.length ? W(b, me, t.path, !1, {}) : null, ge = !!b?.backpacks.includes("orange") && (he?.orangeMats.length ?? 0) > 0, _e = !!b?.backpacks.includes("green") && (he?.greenMats.length ?? 0) > 0, ve = ge && _e && !!b?.comics.includes("colorblind"), z = b ? W(b, me, t.path, O.drink, {
		orange: O.orange,
		green: O.green
	}) : null, ye = z?.gains.core ?? 0, be = Ot(b?.burrow ?? "T1", ye, O.dirs), xe = be.path.filter((e) => ae[e] === "comic").length, Se = O.comicPicks.slice(0, xe), Ce = E.filter((e) => e.dest === 26), B = Ce.length, we = y ? y.rats.filter((e, t) => !Ce.some((e) => e.rat === t) && e.pos >= -1 && e.pos < 26).length : 0, Te = (y?.rats.filter((e) => e.pos === 26).length ?? 0) + B, V = t.supply.awards >= B && (we > 0 || Te >= 4), Ee = (y?.rats.filter((e) => e.pos === -2).length ?? 0) >= B, H = r(() => {
		if (!b || b.comics.includes("noToll")) return 0;
		let e = 0;
		for (let n of E) if (!(n.dest >= 26)) for (let r of t.players) r.rid !== i && r.rats.some((e) => e.pos === n.dest) && (e += 1);
		return e;
	}, [
		E,
		t.players,
		b,
		i
	]), U = [];
	E.length === 0 && U.push("games.firstrat.pickDestHint"), z || U.push("games.firstrat.errBonus"), be.needMore && U.push("games.firstrat.needDir"), B > 0 && (O.launchReward ? (O.launchReward === "award" && !V || O.launchReward === "rat" && !Ee) && U.push("games.firstrat.needReward") : U.push("games.firstrat.needReward")), E.length > 1 && B > 0 && !O.launchColor && U.push("games.firstrat.needLaunchColor");
	let De = () => {
		if (U.length > 0 || !S) return;
		let e = {
			type: "move",
			moves: E.map((e) => ({
				rat: e.rat,
				dest: e.dest,
				pipes: e.pipes
			})),
			drink: O.drink,
			bonus: {
				orange: O.orange,
				green: O.green
			},
			launchColor: O.launchColor,
			launchReward: O.launchReward,
			burrowDirs: O.dirs,
			comics: Se
		};
		o(e), D([]), k(kt), T(null), j(!1);
	}, Oe = () => {
		D([]), T(null), j(!1);
	}, ke = Math.floor(t.turn / t.players.length), Ae = "info", je;
	S ? (Ae = "accent", je = E.length > 0 ? l("games.firstrat.draftChip", { n: E.length }) : l(w === null ? "games.firstrat.yourMove" : "games.firstrat.pickDestHint")) : C ? (Ae = "accent", je = l("games.firstrat.postHint")) : je = l("games.firstrat.waitTurn", { name: h(t.players[t.seat]?.rid ?? "") });
	let Me = t.endRound === null ? void 0 : ke >= t.endRound ? l("games.firstrat.lastRoundChip") : l("games.firstrat.extraRoundChip"), Ne = n.filter((e) => t.players.some((t) => t.rid === e.rid)), Pe;
	Pe = S ? /* @__PURE__ */ _("div", {
		className: "flex items-center gap-2",
		children: E.length > 0 ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
			type: "button",
			className: "btn-base min-h-12 flex-1 px-3 text-sm",
			onClick: () => j(!0),
			children: l("games.firstrat.draftChip", { n: E.length })
		}), /* @__PURE__ */ _("button", {
			type: "button",
			className: "btn-quiet min-h-12 px-3 text-sm",
			onClick: Oe,
			children: l("games.firstrat.clearDraft")
		})] }) : /* @__PURE__ */ _("p", {
			className: "grid flex-1 place-items-center text-xs font-bold opacity-60",
			children: l(w === null ? "games.firstrat.pickRatHint" : "games.firstrat.pickDestHint")
		})
	}) : C ? /* @__PURE__ */ v("div", {
		className: "flex items-center gap-2",
		children: [
			t.boothRats.length > 0 && /* @__PURE__ */ v("button", {
				type: "button",
				className: "btn-base min-h-12 flex-1 px-2 text-sm",
				onClick: () => ie(!0),
				children: ["🛒 ×", t.boothRats.length]
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				className: "btn-base min-h-12 flex-1 px-2 text-sm",
				onClick: () => N(!0),
				children: l("games.firstrat.buildTitle")
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				className: "btn-base min-h-12 flex-1 px-2 text-sm",
				disabled: !y || y.cheese < 10 || !t.activeTracks.includes("provisions"),
				onClick: () => o({ type: "donate" }),
				children: l("games.firstrat.donate")
			}),
			/* @__PURE__ */ _(d, {
				label: l("games.firstrat.endTurn"),
				confirmLabel: l("games.firstrat.endConfirm"),
				onConfirm: () => o({ type: "endTurn" }),
				className: "min-h-12 flex-1 px-2 text-sm"
			})
		]
	}) : /* @__PURE__ */ _("p", {
		className: "grid h-12 place-items-center text-xs font-bold opacity-60",
		children: l("games.firstrat.waitTurn", { name: h(t.players[t.seat]?.rid ?? "") })
	});
	let Fe = (y?.rats ?? []).map((e, t) => ({
		r: e,
		i: t
	})).filter(({ r: e, i: t }) => {
		let n = E.find((e) => e.rat === t), r = n ? n.dest : e.pos;
		return r >= -1 && r < 26 && e.super === null;
	}).map(({ i: e }) => e);
	return /* @__PURE__ */ v(p, {
		adaptive: !0,
		className: "firstrat-layout",
		banner: /* @__PURE__ */ v("div", {
			className: "firstrat-banner flex flex-col gap-2",
			children: [/* @__PURE__ */ _(m, {
				tone: Ae,
				text: je,
				chip: Me,
				accent: L.accent
			}), /* @__PURE__ */ _(ee, {
				members: Ne,
				myRid: i,
				variant: "plate",
				anchorOf: (e) => `seat:${e}`,
				action: (e) => t.phase === "play" && t.players[t.seat]?.rid === e ? "pending" : null,
				status: (e) => {
					let n = t.players.find((t) => t.rid === e);
					if (!n) return null;
					let r = n.rats.filter((e) => e.pos === 26).length;
					return /* @__PURE__ */ v("span", {
						className: "firstrat-player-status flex items-center gap-1.5 text-[10px] leading-3.5 font-bold",
						children: [
							/* @__PURE__ */ v("span", {
								className: "font-mono tabular-nums",
								children: ["🧀", n.cheese]
							}),
							r > 0 && /* @__PURE__ */ v("span", {
								className: "font-mono tabular-nums",
								children: ["🚀×", r]
							}),
							n.moldy > 0 && /* @__PURE__ */ v("span", {
								className: "font-mono tabular-nums",
								children: ["🤢", n.moldy]
							})
						]
					});
				}
			})]
		}),
		actionsHeight: "firstrat-actions h-28",
		actions: /* @__PURE__ */ v("div", {
			className: "firstrat-action-content flex h-full flex-col justify-center gap-1.5",
			children: [/* @__PURE__ */ v("div", {
				className: "flex items-center gap-1.5",
				children: [/* @__PURE__ */ _("div", {
					className: "firstrat-resources flex min-h-11 min-w-0 flex-1 items-center gap-2 overflow-x-auto rounded-xl border-2 border-ink bg-surface px-2 text-xs font-bold nowrap",
					children: y && /* @__PURE__ */ v(g, { children: [
						/* @__PURE__ */ v("span", {
							className: "flex flex-none items-center gap-0.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ _(Xe, {
								kind: "cheese",
								size: 14
							}), y.cheese]
						}),
						mt.map((e) => /* @__PURE__ */ v("span", {
							className: "flex flex-none items-center gap-0.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ _(Xe, {
								kind: e,
								size: 14
							}), y.mats[e]]
						}, e)),
						/* @__PURE__ */ v("span", {
							className: "flex flex-none items-center gap-0.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ _(Xe, {
								kind: "bulb",
								size: 14
							}), y.light]
						}),
						y.drinks > 0 && /* @__PURE__ */ v("span", {
							className: "flex flex-none items-center gap-0.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ _(Xe, {
								kind: "soda",
								size: 14
							}), y.drinks]
						}),
						y.awards > 0 && /* @__PURE__ */ v("span", {
							className: "flex-none font-mono tabular-nums",
							children: ["🏅", y.awards]
						})
					] })
				}), /* @__PURE__ */ _("button", {
					type: "button",
					"aria-label": l("games.firstrat.sheetTracks"),
					className: "btn-quiet min-h-11 min-w-11 px-2 text-base",
					onClick: () => F(!0),
					children: "📊"
				})]
			}), Pe]
		}),
		scroll: !1,
		children: [
			/* @__PURE__ */ v("div", {
				className: "firstrat-table",
				children: [/* @__PURE__ */ _("div", {
					className: "firstrat-board-space",
					children: /* @__PURE__ */ _(pt, {
						pub: t,
						members: n,
						myRid: i,
						interactive: S && !A,
						selRat: w,
						eligible: pe,
						draft: E,
						onTapRat: (e) => T((t) => t === e ? null : e),
						onTapSlot: (e) => {
							if (w === null || !pe) return;
							let t = pe.get(e);
							t && (D((n) => [...n, {
								rat: w,
								dest: e,
								pipes: [...t]
							}]), T(null), j(!0));
						}
					})
				}), /* @__PURE__ */ _("aside", {
					className: "firstrat-sidebar",
					"aria-label": l("games.firstrat.sheetTracks"),
					children: /* @__PURE__ */ _(At, {
						pub: t,
						members: n,
						nameOf: h
					})
				})]
			}),
			/* @__PURE__ */ _(u, {
				open: A,
				onClose: () => j(!1),
				label: l("games.firstrat.moveConfirm"),
				children: /* @__PURE__ */ v("div", {
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ _("div", {
							className: "flex flex-wrap gap-1.5",
							children: E.map((e, n) => /* @__PURE__ */ v("span", {
								className: "plate px-2 py-1 text-xs font-bold",
								children: [
									"🐭",
									e.rat + 1,
									" → ",
									e.dest === 26 ? "🚀" : `${Q[te[t.path[e.dest]].res]}${e.dest + 1}`,
									e.pipes.length > 0 && ` · 🛠️×${e.pipes.length}`
								]
							}, n))
						}),
						z && Object.keys(z.gains).length > 0 && /* @__PURE__ */ v("div", {
							className: "plate px-2 py-1.5",
							children: [
								/* @__PURE__ */ _("p", {
									className: "section-label",
									children: l("games.firstrat.collectTitle")
								}),
								/* @__PURE__ */ _("p", {
									className: "font-mono text-sm font-extrabold tabular-nums",
									children: Object.entries(z.gains).map(([e, t]) => `${Q[e]}×${t}`).join("  ")
								}),
								H > 0 && /* @__PURE__ */ _("p", {
									className: "text-xs font-bold text-warn-ink",
									children: l("games.firstrat.tollCost", { n: H })
								}),
								y && H > y.cheese && /* @__PURE__ */ _("p", {
									className: "text-xs font-bold text-warn-ink",
									children: l("games.firstrat.moldyWarn")
								})
							]
						}),
						y && y.drinks > 0 && me.length > 0 && /* @__PURE__ */ v("button", {
							type: "button",
							"aria-pressed": O.drink,
							className: "card min-h-11 cursor-pointer px-3 text-left text-sm font-bold",
							style: O.drink ? {
								borderColor: L.accent,
								boxShadow: `4px 4px 0 ${L.accent}`
							} : void 0,
							onClick: () => k((e) => ({
								...e,
								drink: !e.drink
							})),
							children: ["🥤 ", l("games.firstrat.drinkUse")]
						}),
						(ge || _e) && he && /* @__PURE__ */ v("div", {
							className: "flex flex-col gap-1.5",
							children: [ge && /* @__PURE__ */ v("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ _("span", {
									className: "flex-none text-xs font-bold",
									children: l("games.firstrat.bonusOrange")
								}), he.orangeMats.map((e) => /* @__PURE__ */ _("button", {
									type: "button",
									className: "card min-h-11 min-w-11 cursor-pointer px-2 text-base",
									style: O.orange === e ? {
										borderColor: L.accent,
										boxShadow: `3px 3px 0 ${L.accent}`
									} : void 0,
									onClick: () => k((t) => ({
										...t,
										orange: t.orange === e ? void 0 : e,
										...ve ? { green: void 0 } : {}
									})),
									children: Q[e]
								}, e))]
							}), _e && /* @__PURE__ */ v("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ _("span", {
									className: "flex-none text-xs font-bold",
									children: l("games.firstrat.bonusGreen")
								}), he.greenMats.map((e) => /* @__PURE__ */ _("button", {
									type: "button",
									className: "card min-h-11 min-w-11 cursor-pointer px-2 text-base",
									style: O.green === e ? {
										borderColor: L.accent,
										boxShadow: `3px 3px 0 ${L.accent}`
									} : void 0,
									onClick: () => k((t) => ({
										...t,
										green: t.green === e ? void 0 : e,
										...ve ? { orange: void 0 } : {}
									})),
									children: Q[e]
								}, e))]
							})]
						}),
						be.junctionsShown > 0 && /* @__PURE__ */ v("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _("p", {
								className: "section-label",
								children: l("games.firstrat.burrowPickTitle")
							}), Array.from({ length: be.junctionsShown }, (e, t) => /* @__PURE__ */ v("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ v("span", {
									className: "flex-none font-mono text-xs font-bold tabular-nums",
									children: ["#", t + 1]
								}), ["up", "left"].map((e) => /* @__PURE__ */ _("button", {
									type: "button",
									className: "card min-h-11 flex-1 cursor-pointer px-2 text-sm font-bold",
									style: O.dirs[t] === e ? {
										borderColor: L.accent,
										boxShadow: `3px 3px 0 ${L.accent}`
									} : void 0,
									onClick: () => k((n) => ({
										...n,
										dirs: [...n.dirs.slice(0, t), e]
									})),
									children: l(e === "up" ? "games.firstrat.burrowUp" : "games.firstrat.burrowLeft")
								}, e))]
							}, t))]
						}),
						xe > 0 && !be.needMore && /* @__PURE__ */ v("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _("p", {
								className: "section-label",
								children: l("games.firstrat.comicPickTitle")
							}), Array.from({ length: xe }, (e, n) => {
								let r = Se[n], i = new Set(Se.map((e) => e.comic));
								return /* @__PURE__ */ v("div", {
									className: "flex flex-col gap-1",
									children: [/* @__PURE__ */ v("div", {
										className: "flex flex-wrap items-center gap-1.5",
										children: [/* @__PURE__ */ _("button", {
											type: "button",
											className: "card min-h-11 cursor-pointer px-2 text-xs font-bold",
											style: r ? void 0 : {
												borderColor: L.accent,
												boxShadow: `3px 3px 0 ${L.accent}`
											},
											onClick: () => k((e) => ({
												...e,
												comicPicks: e.comicPicks.filter((e, t) => t !== n)
											})),
											children: l("games.firstrat.comicSkip")
										}), t.supply.comics.filter((e) => !i.has(e) || r?.comic === e).map((e) => /* @__PURE__ */ _("button", {
											type: "button",
											title: l(_t[e]),
											className: "card min-h-11 cursor-pointer px-2 text-xs font-bold",
											style: r?.comic === e ? {
												borderColor: L.accent,
												boxShadow: `3px 3px 0 ${L.accent}`
											} : void 0,
											onClick: () => k((t) => {
												let r = t.comicPicks.filter((e, t) => t !== n);
												return r.splice(n, 0, {
													comic: e,
													rat: Tt.has(e) ? Fe[0] : void 0
												}), {
													...t,
													comicPicks: r
												};
											}),
											children: l(gt[e])
										}, e))]
									}), r && Tt.has(r.comic) && /* @__PURE__ */ v("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _("span", {
											className: "flex-none text-xs font-bold",
											children: l("games.firstrat.superPickTitle")
										}), Fe.map((e) => /* @__PURE__ */ v("button", {
											type: "button",
											className: "card min-h-11 min-w-11 cursor-pointer px-2 text-xs font-bold",
											style: r.rat === e ? {
												borderColor: L.accent,
												boxShadow: `3px 3px 0 ${L.accent}`
											} : void 0,
											onClick: () => k((t) => ({
												...t,
												comicPicks: t.comicPicks.map((t, r) => r === n ? {
													...t,
													rat: e
												} : t)
											})),
											children: ["🐭", e + 1]
										}, e))]
									})]
								}, n);
							})]
						}),
						B > 0 && /* @__PURE__ */ v("div", {
							className: "flex flex-col gap-1.5",
							children: [
								E.length > 1 && /* @__PURE__ */ v("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ _("span", {
										className: "flex-none text-xs font-bold",
										children: l("games.firstrat.launchColorPick")
									}), [
										"blue",
										"yellow",
										"orange",
										"green",
										"white"
									].map((e) => /* @__PURE__ */ _("button", {
										type: "button",
										className: "card min-h-11 flex-1 cursor-pointer px-1 text-xs font-bold",
										style: O.launchColor === e ? {
											borderColor: L.accent,
											boxShadow: `3px 3px 0 ${L.accent}`
										} : void 0,
										onClick: () => k((t) => ({
											...t,
											launchColor: e
										})),
										children: l(St[e])
									}, e))]
								}),
								/* @__PURE__ */ _("p", {
									className: "section-label",
									children: l("games.firstrat.launchRewardTitle")
								}),
								/* @__PURE__ */ v("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ v("button", {
										type: "button",
										disabled: !V,
										className: "card min-h-11 flex-1 cursor-pointer px-2 text-sm font-bold disabled:opacity-40",
										style: O.launchReward === "award" ? {
											borderColor: L.accent,
											boxShadow: `3px 3px 0 ${L.accent}`
										} : void 0,
										onClick: () => k((e) => ({
											...e,
											launchReward: "award"
										})),
										children: ["🏅 ", l("games.firstrat.rewardAward")]
									}), /* @__PURE__ */ v("button", {
										type: "button",
										disabled: !Ee,
										className: "card min-h-11 flex-1 cursor-pointer px-2 text-sm font-bold disabled:opacity-40",
										style: O.launchReward === "rat" ? {
											borderColor: L.accent,
											boxShadow: `3px 3px 0 ${L.accent}`
										} : void 0,
										onClick: () => k((e) => ({
											...e,
											launchReward: "rat"
										})),
										children: ["🐭 ", l("games.firstrat.rewardRat")]
									})]
								})
							]
						}),
						U.length > 0 && E.length > 0 && /* @__PURE__ */ _("p", {
							className: "text-xs font-bold text-warn-ink",
							children: l(U[0])
						}),
						/* @__PURE__ */ v("div", {
							className: "flex items-center gap-2",
							children: [
								E.length < 4 && b && b.rats.some((e, t) => !E.some((e) => e.rat === t) && e.pos >= -1 && e.pos < 26) && /* @__PURE__ */ _("button", {
									type: "button",
									className: "btn-quiet min-h-12 flex-1 px-2 text-sm",
									disabled: E.some((e) => e.dest === 26) && !O.launchColor,
									onClick: () => {
										j(!1), T(null);
									},
									children: l("games.firstrat.addRat")
								}),
								/* @__PURE__ */ _("button", {
									type: "button",
									className: "btn-quiet min-h-12 px-3 text-sm",
									onClick: Oe,
									children: l("games.firstrat.cancel")
								}),
								/* @__PURE__ */ _("button", {
									type: "button",
									disabled: U.length > 0,
									className: "btn-base min-h-12 flex-1 px-3 text-sm text-white disabled:opacity-40",
									style: { background: L.accent },
									onClick: De,
									children: l("games.firstrat.moveConfirm")
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ _(u, {
				open: re,
				onClose: () => ie(!1),
				label: l("games.firstrat.shopTitle"),
				children: /* @__PURE__ */ _("div", {
					className: "flex flex-col gap-3",
					children: t.boothRats.map((e) => {
						let n = y?.rats[e], r = ne.find((e) => e.slot === n?.pos);
						if (!y || !n || !r) return null;
						let i = n.super === "ratwoman" && y.comics.includes("ratwoman"), a = n.super === "neil" && y.comics.includes("neil") || n.super === "ratwoman" && y.comics.includes("ratwoman"), s = i ? 0 : r.price, c = y.cheese >= s, u = (t, n, r) => /* @__PURE__ */ v("div", {
							className: "flex items-center gap-1.5",
							children: [
								/* @__PURE__ */ v("span", {
									className: "min-w-0 flex-1 text-xs font-bold",
									children: [n, r && /* @__PURE__ */ _("span", {
										className: "block text-[10px] font-bold opacity-70",
										children: r
									})]
								}),
								/* @__PURE__ */ _("button", {
									type: "button",
									disabled: !c,
									className: "btn-base min-h-11 px-2 text-xs disabled:opacity-40",
									onClick: () => o({
										type: "shop",
										rat: e,
										steal: !1,
										item: t
									}),
									children: s === 0 ? l("games.firstrat.pipeFree") : l("games.firstrat.shopBuy", { price: s })
								}),
								!a && /* @__PURE__ */ _("button", {
									type: "button",
									className: "btn-quiet min-h-11 px-2 text-xs",
									onClick: () => o({
										type: "shop",
										rat: e,
										steal: !0,
										item: t
									}),
									children: l("games.firstrat.stealBtn")
								})
							]
						}, n);
						return /* @__PURE__ */ v("div", {
							className: "flex flex-col gap-1.5",
							children: [
								/* @__PURE__ */ v("p", {
									className: "section-label",
									children: [
										"🐭",
										e + 1,
										" · ",
										l(wt[r.kind])
									]
								}),
								r.kind === "hamster" && t.supply.backpacks.filter((e) => !y.backpacks.includes(e) && !y.freshBackpacks.includes(e)).map((e) => u({
									kind: "backpack",
									bp: e
								}, l(vt[e]), l(yt[e]))),
								r.kind === "frog" && t.supply.drinks > 0 && u({ kind: "drink" }, `🥤 ×1 (${t.supply.drinks})`),
								r.kind === "crow" && t.supply.caps.map((e) => u({
									kind: "cap",
									cap: e
								}, l(bt[e]), l(xt[e])))
							]
						}, e);
					})
				})
			}),
			/* @__PURE__ */ _(u, {
				open: M,
				onClose: () => N(!1),
				label: l("games.firstrat.buildTitle"),
				children: /* @__PURE__ */ _("div", {
					className: "flex flex-col gap-3",
					children: Object.keys(P).map((e) => {
						if (!t.activeTracks.includes(e)) return null;
						let n = P[e], r = y?.comics.includes("discount") ?? !1, i = I[e] ?? null, a = {};
						for (let e of mt) {
							let t = n[e] - (r && i === e ? 1 : 0);
							t > 0 && (a[e] = t);
						}
						let s = y ? mt.every((e) => y.mats[e] >= (a[e] ?? 0)) : !1, c = mt.filter((e) => (a[e] ?? 0) > 0).map((e) => `${Q[e]}×${a[e]}`).join(" ");
						return /* @__PURE__ */ v("div", {
							className: "plate flex flex-col gap-1.5 px-2 py-1.5",
							children: [
								/* @__PURE__ */ v("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ v("span", {
										className: "min-w-0 flex-1 text-sm font-extrabold",
										children: [l(Ct[e]), /* @__PURE__ */ _("span", {
											className: "ml-1 text-[10px] font-bold opacity-70",
											children: l("games.firstrat.buildOwned", { n: y?.parts[e] ?? 0 })
										})]
									}), /* @__PURE__ */ _("span", {
										className: "font-mono text-xs font-bold tabular-nums",
										children: c
									})]
								}),
								r && /* @__PURE__ */ v("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ _("span", {
										className: "flex-none text-[10px] font-bold opacity-70",
										children: l(gt.discount)
									}), mt.filter((e) => n[e] > 0).map((t) => /* @__PURE__ */ _("button", {
										type: "button",
										className: "card min-h-11 min-w-11 cursor-pointer px-2 text-base",
										style: i === t ? {
											borderColor: L.accent,
											boxShadow: `3px 3px 0 ${L.accent}`
										} : void 0,
										onClick: () => se((n) => ({
											...n,
											[e]: n[e] === t ? null : t
										})),
										children: Q[t]
									}, t))]
								}),
								/* @__PURE__ */ _("button", {
									type: "button",
									disabled: !s,
									className: "btn-base min-h-12 px-3 text-sm disabled:opacity-40",
									onClick: () => o({
										type: "build",
										part: e,
										pay: a
									}),
									children: l("games.firstrat.buildWith", { pay: c })
								})
							]
						}, e);
					})
				})
			}),
			/* @__PURE__ */ _(u, {
				open: oe,
				onClose: () => F(!1),
				label: l("games.firstrat.sheetTracks"),
				children: /* @__PURE__ */ _(At, {
					pub: t,
					members: n,
					nameOf: h
				})
			})
		]
	});
}
//#endregion
//#region src/games/firstrat/bot.ts
var Mt = [
	"vinegar",
	"soda",
	"can",
	"calculator"
], Nt = [
	"cockpit",
	"cargoBay",
	"thruster"
], Pt = {
	cockpit: "cockpit",
	cargoBay: "cargoBay",
	thruster: "thruster"
}, Ft = [
	"noToll",
	"march14",
	"discount",
	"pipesYellow",
	"pipesRed",
	"colorblind"
], It = {
	cheese: 1,
	core: 2.2,
	bulb: 2.6,
	vinegar: 2,
	soda: 2.2,
	can: 2.4,
	calculator: 3
};
function Lt(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Rt(e, t) {
	let n = oe(e.players.length);
	for (let r = 0; r < 4; r += 1) if (!n.includes(r) && !(t === "rattronaut" ? e.players.some((e) => e.rats.some((e) => e.pos === 26 && e.slot === r)) : e.players.some((e) => (e.tracks[t] ?? []).includes(r)))) return r;
	return 4;
}
function zt(e, t, n) {
	let r = e, i = [], a = [];
	for (let e = 0; e < t; e += 1) {
		let e = re[r], t;
		if (ie[r]) {
			let a = n(r);
			i.push(a), t = a === "up" ? e[0] : e[1];
		} else t = e[0];
		r = t, a.push(t);
	}
	return {
		dirs: i,
		path: a
	};
}
function Bt(e) {
	let t = [], n = new Set(e.rats.filter((e) => e.pos >= 0 && e.pos < 26).map((e) => e.pos));
	for (let r = 0; r < e.rats.length; r += 1) {
		let i = e.rats[r];
		if (i.pos < -1 || i.pos > 25) continue;
		let a = Oe(e, r, 1);
		for (let o = i.pos + 1; o <= 26; o += 1) {
			let s = D.filter((e) => e.from >= i.pos && e.from < o);
			if (o - i.pos > a && s.length === 0) break;
			if (o !== 26 && n.has(o)) continue;
			let c = [[]];
			for (let e = 1; e < 1 << s.length; e += 1) {
				let t = [];
				for (let n = 0; n < s.length; n += 1) e & 1 << n && t.push(s[n].from);
				c.push(t);
			}
			for (let n of c) {
				let s = De(i.pos, o, n);
				if (!s || s.steps > a) continue;
				let c = {};
				for (let t of s.used) t.color === "yellow" && e.comics.includes("pipesYellow") || t.color === "red" && e.comics.includes("pipesRed") || (c[t.cost] = (c[t.cost] ?? 0) + 1);
				Mt.every((t) => (c[t] ?? 0) <= e.mats[t]) && t.push({
					rat: r,
					dest: o,
					pipeFroms: n,
					steps: s.steps,
					used: s.used
				});
			}
		}
	}
	return t;
}
function Vt(e, t) {
	return (n) => n === "B2" ? e.supply.comics.length > 0 ? "up" : "left" : t.rats.some((e) => e.pos === -2) ? "up" : "left";
}
function Ht(e, t, n) {
	let r = t.rats.filter((e, t) => t !== n && e.pos >= -1 && e.pos < 26).length, i = t.rats.filter((e) => e.pos === 26).length + 1, a = e.supply.awards > 0 && (r > 0 || i >= 4), o = t.rats.some((e) => e.pos === -2);
	return a && (r >= 2 || !o) ? "award" : o ? "rat" : "award";
}
function Ut(e, t, n, r) {
	let i = [], a = [...e.supply.comics];
	for (let e = 0; e < n && a.length > 0; e += 1) {
		let e = se.find((e) => a.includes(e));
		if (e) {
			let n = t.rats.map((e, t) => ({
				r: e,
				idx: t
			})).filter(({ r: e, idx: t }) => t !== r && e.pos >= -1 && e.pos < 26 && e.super === null).sort((e, t) => t.r.pos - e.r.pos);
			if (n.length > 0) {
				a.splice(a.indexOf(e), 1), i.push({
					comic: e,
					rat: n[0].idx
				});
				continue;
			}
		}
		let n = Ft.find((e) => a.includes(e)) ?? a[0];
		a.splice(a.indexOf(n), 1), i.push({ comic: n });
	}
	return i;
}
function Wt(e, t, n) {
	let r = .12 * (n.dest - t.rats[n.rat].pos);
	if (n.dest === 26) return r += M.rattronaut[Rt(e, "rattronaut")], r += 3, r;
	let i = W(t, [{
		rat: n.rat,
		slot: n.dest
	}], e.path, !1, {});
	if (!i) return -Infinity;
	for (let [e, t] of Object.entries(i.gains)) r += (It[e] ?? 1) * t;
	let a = i.gains.bulb ?? 0;
	if (a > 0) {
		let n = Math.min(t.light + a, 40);
		for (let i of k) i >= t.light && i < n && e.activeTracks.includes("lights") && (r += .8 * M.lights[Rt(e, "lights")]);
	}
	let o = i.gains.core ?? 0;
	if (o > 0) {
		let n = zt(t.burrow, o, Vt(e, t));
		for (let i of n.path) {
			let n = ae[i];
			n === "comic" && (r += e.supply.comics.length > 0 ? 3.5 : 0), n === "rat" && (r += t.rats.some((e) => e.pos === -2) ? 4 : 0), n === "food" && e.activeTracks.includes("food") && (r += .8 * M.food[Rt(e, "food")]);
		}
	}
	let s = ne.find((e) => e.slot === n.dest);
	if (s && (r += t.cheese >= s.price ? 2.5 : .8), !t.comics.includes("noToll")) {
		let i = 0;
		for (let r of e.players) r.rid !== t.rid && r.rats.some((e) => e.pos === n.dest) && (i += 1);
		r -= i, i > t.cheese && (r -= 1.2 * Math.ceil((i - t.cheese) / 3));
	}
	for (let e of n.used) e.color === "yellow" && t.comics.includes("pipesYellow") || e.color === "red" && t.comics.includes("pipesRed") || (r -= It[e.cost]);
	return r;
}
function Gt(e, t) {
	let n = e.public, r = n.players[n.seat];
	if (!r || r.rid !== t.rid) return null;
	let i = r, a = Bt(i);
	if (a.length === 0) return null;
	let o = t.difficulty === "weak" ? Lt(a) : a.reduce((e, t) => Wt(n, i, t) > Wt(n, i, e) ? t : e), s = !1, c = o.dest < 26 ? W(i, [{
		rat: o.rat,
		slot: o.dest
	}], n.path, !1, {}) : null;
	t.difficulty !== "weak" && c && i.drinks > 0 && Object.entries(c.gains).reduce((e, [t, n]) => e + (It[t] ?? 1) * (n ?? 0), 0) >= 4.5 && (s = !0), s && (c = W(i, [{
		rat: o.rat,
		slot: o.dest
	}], n.path, !0, {}));
	let l = {};
	if (t.difficulty !== "weak" && c && o.dest < 26) {
		let e = i.backpacks.includes("orange") && c.orangeMats.length > 0, t = i.backpacks.includes("green") && c.greenMats.length > 0, r = e && t && i.comics.includes("colorblind");
		e && (l.orange = c.orangeMats[0]), t && !r && (l.green = c.greenMats[0]);
		let a = W(i, [{
			rat: o.rat,
			slot: o.dest
		}], n.path, s, l);
		a ? c = a : (l.orange = void 0, l.green = void 0);
	}
	let u = c?.gains ?? {}, d = o.dest < 26 ? u.core ?? 0 : 0, f = zt(i.burrow, d, Vt(n, i)), p = t.difficulty === "weak" ? 0 : f.path.filter((e) => ae[e] === "comic").length, m = o.dest === 26;
	return {
		type: "move",
		moves: [{
			rat: o.rat,
			dest: o.dest,
			pipes: o.pipeFroms
		}],
		drink: s,
		bonus: l,
		launchReward: m ? Ht(n, i, o.rat) : void 0,
		burrowDirs: f.dirs,
		comics: Ut(n, i, p, m ? o.rat : null)
	};
}
function Kt(e, t, n) {
	let r = (n) => e.activeTracks.includes(n) ? t.tracks[n]?.length ?? 0 : 0, i = t.rats.filter((e) => e.pos === 26).length, a = t.backpacks.length + t.freshBackpacks.length + t.drinks + t.drinksSpent + t.comics.length + t.freshComics.length + t.caps.length;
	switch (n) {
		case 0: return Math.max(0, 12 - 2 * (r("cockpit") + r("cargoBay") + r("thruster")));
		case 1: return 4 * (r("food") + 1);
		case 2: return 4 * (r("lights") + 1);
		case 3: return 4 * (r("cockpit") + 1);
		case 4: return 6 * (r("rocket") + 1);
		case 5: return 2 * (a + 4);
		case 6: return 5 * (r("provisions") + 1);
		case 7: return 5 * (r("cargoBay") + 1);
		case 8: return 5 * (r("thruster") + 1);
		default: return 4 * (i + 1);
	}
}
function qt(e, t) {
	let n = e.public, r = n.players[n.seat];
	if (!r) return { type: "endTurn" };
	let i = r;
	if (t.difficulty === "weak") return { type: "endTurn" };
	for (let e of n.boothRats) {
		let t = r.rats[e], a = ne.find((e) => e.slot === t.pos);
		if (!a) continue;
		let o = t.super === "ratwoman" && i.comics.includes("ratwoman");
		if (a.kind === "hamster") {
			let t = [
				"cheese",
				"bulb",
				"core",
				"orange",
				"green"
			].find((e) => n.supply.backpacks.includes(e) && !i.backpacks.includes(e) && !i.freshBackpacks.includes(e));
			if (t && (o || i.cheese >= a.price + 2)) return {
				type: "shop",
				rat: e,
				steal: !1,
				item: {
					kind: "backpack",
					bp: t
				}
			};
		} else if (a.kind === "frog") {
			if (n.supply.drinks > 0 && i.drinks < 2 && (o || i.cheese >= a.price + 2)) return {
				type: "shop",
				rat: e,
				steal: !1,
				item: { kind: "drink" }
			};
		} else {
			let t = [...n.supply.caps].sort((e, t) => Kt(n, i, t) - Kt(n, i, e))[0];
			if (t !== void 0 && (o || i.cheese >= a.price + 4)) return {
				type: "shop",
				rat: e,
				steal: !1,
				item: {
					kind: "cap",
					cap: t
				}
			};
		}
	}
	let a = Nt.filter((e) => n.activeTracks.includes(Pt[e])).sort((e, t) => M[Pt[t]][Rt(n, Pt[t])] - M[Pt[e]][Rt(n, Pt[e])]);
	for (let e of a) {
		let t = P[e], n = {}, r = !0;
		for (let e of Mt) t[e] > 0 && (n[e] = t[e]), i.mats[e] < t[e] && (r = !1);
		if (r) return {
			type: "build",
			part: e,
			pay: n
		};
		if (i.comics.includes("discount")) for (let n of Mt) {
			if (t[n] <= 0) continue;
			let r = {}, a = !0;
			for (let e of Mt) {
				let o = e === n ? t[e] - 1 : t[e];
				o > 0 && (r[e] = o), i.mats[e] < o && (a = !1);
			}
			if (a) return {
				type: "build",
				part: e,
				pay: r
			};
		}
	}
	return n.activeTracks.includes("provisions") && i.cheese >= 16 ? { type: "donate" } : { type: "endTurn" };
}
var Jt = (e, t) => {
	let n = e.public;
	if (n.phase !== "play") return null;
	let r = n.players[n.seat];
	if (!r || r.rid !== t.rid) return null;
	if (n.step === "move") {
		let n = Gt(e, t);
		return n ? { action: n } : null;
	}
	return { action: qt(e, t) };
};
//#endregion
//#region src/games/firstrat/fx.tsx
function Yt(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Xt(e, t) {
	return e.anchor(t === 26 ? "launchpad" : t === -1 ? "start" : `slot:${t}`);
}
function Zt(e, t) {
	let n = t ? e.member(t) : null;
	return f[(n?.colorIndex ?? 0) % f.length].hex;
}
function Qt(e, t = 26) {
	return /* @__PURE__ */ _("span", {
		className: "grid place-items-center rounded-full border-2 border-ink text-sm",
		style: {
			width: t,
			height: t,
			background: e,
			boxShadow: "2px 2px 0 var(--color-ink)"
		},
		children: "🐭"
	});
}
function $(e) {
	return /* @__PURE__ */ _("span", {
		className: "rounded-lg border-2 border-ink bg-surface px-1.5 py-0.5 font-mono text-sm font-black whitespace-nowrap tabular-nums shadow-[2px_2px_0_var(--color-ink)]",
		children: e
	});
}
var $t = {
	backpack: "🎒",
	drink: "🥤",
	cap: "🔘"
}, en = {
	move(e, t) {
		let n = e.data, r = Array.isArray(n?.legs) ? n.legs : [];
		if (r.length === 0) return null;
		let i = Zt(t, e.rid), a = t.queued > 0, o = a ? 220 : 430, s = [...r].reverse().find((e) => e.to < 26), c = typeof n?.toll == "number" ? n.toll : 0, l = s ? Xt(t, s.to) : null;
		return {
			ms: a ? 320 : 560 + r.length * 90,
			node: /* @__PURE__ */ v(g, { children: [r.map((e, n) => {
				let r = Xt(t, e.from), s = Xt(t, e.to);
				return s ? r ? /* @__PURE__ */ _(b, {
					from: r,
					to: {
						x: s.x + s.w / 2 - 13,
						y: s.y + s.h / 2 - 13,
						w: 26,
						h: 26
					},
					ms: o,
					delay: a ? 0 : n * 90,
					children: Qt(i)
				}, n) : /* @__PURE__ */ _(x, {
					at: s,
					ms: o
				}, n) : null;
			}), c > 0 && l && /* @__PURE__ */ _(y, {
				at: l,
				ms: 800,
				delay: a ? 0 : 300,
				children: $(`−${c}${Q.cheese}`)
			})] })
		};
	},
	collect(e, t) {
		let n = e.data, r = n?.gains ?? {}, i = Object.entries(r).filter(([, e]) => (e ?? 0) > 0), a = Array.isArray(n?.slots) ? n.slots : [], o = typeof n?.lightTo == "number" ? n.lightTo : 0, s = typeof n?.lightFrom == "number" ? n.lightFrom : 0, c = Array.isArray(n?.burrowPath) && n.burrowPath.length > 0;
		if (i.length === 0 && o === s && !c) return null;
		let l = a.length > 0 ? Xt(t, a[0]) : Yt(t, e.rid), u = t.anchor("lightstrip"), d = t.anchor("burrow"), f = t.queued > 0, p = i.map(([e, t]) => `${Q[e]}×${t}`).join(" ");
		return {
			ms: f ? 380 : 760,
			node: /* @__PURE__ */ v(g, { children: [
				l && p && /* @__PURE__ */ _(y, {
					at: l,
					ms: f ? 500 : 800,
					children: $(n?.drink ? `${p} 🥤×2` : p)
				}),
				o > s && u && /* @__PURE__ */ _(x, {
					at: u,
					ms: 600
				}),
				c && d && /* @__PURE__ */ _(x, {
					at: d,
					ms: 600
				})
			] })
		};
	},
	marker(e, t) {
		let n = e.data;
		if (typeof n?.value != "number") return null;
		let r = Yt(t, e.rid);
		return r ? (S(), {
			ms: 700,
			node: /* @__PURE__ */ _(y, {
				at: r,
				ms: 700,
				children: $(`+${n.value} 🎯`)
			})
		}) : null;
	},
	comic(e, t) {
		let n = t.anchor("burrow") ?? Yt(t, e.rid);
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ _(y, {
				at: n,
				ms: 600,
				children: $("📖")
			})
		} : null;
	},
	launch(e, t) {
		let n = e.data, r = t.anchor("launchpad");
		if (!r) return null;
		S();
		let i = n?.reward === "award" ? "🏅" : n?.reward === "rat" ? "🐭" : null, a = t.anchor("start");
		return {
			ms: 900,
			node: /* @__PURE__ */ v(g, { children: [
				/* @__PURE__ */ _(x, {
					at: r,
					ms: 700
				}),
				typeof n?.value == "number" && /* @__PURE__ */ _(y, {
					at: r,
					ms: 800,
					children: $(`+${n.value} 🚀`)
				}),
				i === "🏅" && /* @__PURE__ */ _(y, {
					at: r,
					ms: 800,
					delay: 250,
					children: $("🏅 +3")
				}),
				i === "🐭" && a && /* @__PURE__ */ _(y, {
					at: a,
					ms: 800,
					delay: 250,
					children: $("🐭")
				})
			] })
		};
	},
	shop(e, t) {
		let n = e.data, r = Yt(t, e.rid);
		if (!r) return null;
		let i = $t[n?.item?.kind ?? ""] ?? "🎁", a = n?.steal === !0, o = t.anchor("start");
		return {
			ms: 700,
			node: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(y, {
				at: r,
				ms: 700,
				children: $(i)
			}), a && o && /* @__PURE__ */ _(y, {
				at: o,
				ms: 700,
				delay: 200,
				children: $("🐭↩️")
			})] })
		};
	},
	build(e, t) {
		let n = t.anchor("rocket");
		return n ? (S(), {
			ms: 800,
			node: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(x, {
				at: n,
				ms: 700
			}), /* @__PURE__ */ _(y, {
				at: n,
				ms: 800,
				children: $("🔧")
			})] })
		}) : null;
	},
	donate(e, t) {
		let n = Yt(t, e.rid);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ _(y, {
				at: n,
				ms: 700,
				children: $(`−10 ${Q.cheese}`)
			})
		} : null;
	}
}, tn = {
	scoreTracks: "games.firstrat.scoreTracks",
	trackRattronaut: "games.firstrat.trackRattronaut",
	scoreCaps: "games.firstrat.scoreCaps",
	scoreAwards: "games.firstrat.scoreAwards",
	scoreMoldy: "games.firstrat.scoreMoldy",
	scoreLeftover: "games.firstrat.scoreLeftover",
	scoreTotal: "games.firstrat.scoreTotal"
};
function nn({ public: e, rid: t }) {
	let n = c(), r = We(e, t);
	if (r.length === 0) return null;
	let i = r.find((e) => e.key === "scoreTotal")?.pts ?? 0;
	return /* @__PURE__ */ v("div", {
		className: "firstrat-score-detail mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px] font-bold",
		children: [r.filter((e) => e.key !== "scoreTotal" && e.pts !== 0).map((e) => /* @__PURE__ */ v("span", {
			className: "flex items-center gap-0.5",
			children: [/* @__PURE__ */ _("span", {
				className: "text-ink/50",
				children: n(tn[e.key])
			}), /* @__PURE__ */ _("span", {
				className: `font-mono tabular-nums ${e.pts < 0 ? "text-rose-600" : ""}`,
				children: e.pts > 0 ? `+${e.pts}` : e.pts
			})]
		}, e.key)), /* @__PURE__ */ _("span", {
			className: "ml-auto font-mono text-xs font-black tabular-nums",
			children: i
		})]
	});
}
//#endregion
//#region src/games/firstrat/game-over.tsx
function rn(e) {
	return /* @__PURE__ */ _("div", {
		className: "firstrat-game-over",
		children: /* @__PURE__ */ _(C, {
			...e,
			accent: L.accent,
			renderRowExtra: (t) => /* @__PURE__ */ _(nn, {
				public: e.public,
				rid: t,
				myRid: e.myRid
			})
		})
	});
}
//#endregion
//#region src/games/firstrat/options.tsx
function an({ value: e, onChange: t }) {
	let n = c(), r = z.safeParse(e), i = r.success ? r.data : z.parse(void 0), a = [{
		key: "variantPath",
		label: n("games.firstrat.optVariantPath"),
		hint: n("games.firstrat.optVariantPathHint")
	}, {
		key: "variantTracks",
		label: n("games.firstrat.optVariantTracks"),
		hint: n("games.firstrat.optVariantTracksHint")
	}];
	return /* @__PURE__ */ _("div", {
		className: "flex flex-col gap-2",
		children: a.map((e) => {
			let n = i[e.key];
			return /* @__PURE__ */ _(w, {
				checked: n,
				label: e.label,
				hint: e.hint,
				accent: L.accent,
				onChange: () => t({
					...i,
					[e.key]: !n
				})
			}, e.key);
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/firstrat/entry.tsx
var on = {
	definition: qe,
	View: jt,
	bot: Jt,
	fx: en,
	OverView: rn,
	RowView: nn,
	Options: an,
	locales: {
		zh: {
			name: "萌鼠摘月",
			desc: "垃圾场小鼠造火箭:跑图采集攒建材,灯串鼠洞滚雪球,把四只鼠送上奶酪月亮",
			rules: "目标:火箭完工前攒最多分。终局触发:有玩家第四只鼠进入火箭,本轮结束后完局。\n或有玩家放下第八个计分标记,则本轮结束后再加一轮。\n回合流程:\n· 移动二选一:一只鼠前进一至五格;或二至四只鼠各前进一至三格,全部停在同色的不同格。\n· 只能朝火箭方向走;自己的鼠不能同格,起点除外。\n· 停入有其他玩家鼠的格,须付给该格每位玩家一奶酪。\n· 无力支付则按差额拿取霉奶酪:每拿一个立即获得三奶酪,终局扣两分。\n· 管道捷径:从入口格出发交出管身所示建材,一步直达出口格。\n· 采集:本回合移动过的鼠按落格产出。\n· 黄格获得奶酪,白格获得苹果核,蓝格获得灯泡,绿橙格获得所示建材。\n· 采集数量为格面数字再加灯串加成。\n· 灯泡驱动灯串标记前进;标记每到达或越过一盏灯泡,该灯泡对应的路径格以后采集加一,可叠加。\n· 每越过一盏建筑灯,各计一次建筑灯轨。\n· 苹果核驱动鼠洞标记顺时针走;到岔口选向上或向左。\n· 经过图书馆旁免费获得一本漫画;经过育儿室旁养一只新鼠,全场最多两次;经过储食旁计一次储食轨。\n· 购物:本回合停在摊位格的鼠可购一件。\n· 仓鼠处六奶酪买背包,青蛙处七奶酪买能量饮料,疯鸦处十二奶酪买瓶盖。\n· 也可免费偷一件,但该鼠回到起点。\n· 建造:交两个计算器与一个铁罐建座舱;交三个苏打与两个铁罐建货舱。\n· 交五个醋瓶与两个苏打建推进器。以上建造各计对应计分轨。\n· 每集齐三件一套再计整箭轨。捐十奶酪计补给轨。次数不限。\n· 发射台:鼠到达即成宇航员,占宇航员轨最左空格。\n· 并二选一:获得一枚奖章(终局值三分),或从育儿室养一只鼠到起点。\n· 若它并非第四只进入火箭的鼠,且此后场上已无可移动之鼠,则只能选养鼠。\n物品:背包与漫画均从下个回合起生效。能量饮料在采集时使用,当次采集总量翻倍,每回合限一瓶。\n瓶盖为终局加分。\n计分:八条计分轨得分,加瓶盖得分,加奖章每个三分,减霉奶酪每个两分,加剩余建材与奶酪每四个一分。\n平分则比宇航员数,再平则共享胜利。",
			resCheese: "奶酪",
			resCore: "苹果核",
			resBulb: "灯泡",
			resVinegar: "醋瓶",
			resSoda: "苏打",
			resCan: "铁罐",
			resCalculator: "计算器",
			trackCockpit: "座舱",
			trackCargoBay: "货舱",
			trackThruster: "推进器",
			trackRocket: "整箭",
			trackProvisions: "补给",
			trackLights: "建筑灯",
			trackFood: "储食",
			trackRattronaut: "宇航员",
			boothHamster: "仓鼠的背包摊",
			boothFrog: "青蛙的饮料摊",
			boothCrow: "疯鸦的瓶盖摊",
			bpOrange: "橙背包",
			bpGreen: "绿背包",
			bpCheese: "奶酪背包",
			bpCore: "果核背包",
			bpBulb: "灯泡背包",
			bpDescOrange: "橙格采集建材总量 +1(类型自选)",
			bpDescGreen: "绿格采集建材总量 +1(类型自选)",
			bpDescCheese: "采集奶酪总量 +2",
			bpDescCore: "采集苹果核总量 +2",
			bpDescBulb: "采集灯泡总量 +2",
			comicPipesYellow: "黄管通行证",
			comicPipesRed: "红管通行证",
			comicNoToll: "霸王条款",
			comicMarch14: "齐步前进",
			comicColorblind: "绿橙色盲",
			comicDiscount: "讨价还价",
			comicNeil: "尼尔·鼠斯壮",
			comicLola: "萝拉鼠",
			comicArnold: "阿诺·鼠瓦辛格",
			comicRatwoman: "鼠女侠",
			comicDescPipesYellow: "两条黄色捷径免费通行",
			comicDescPipesRed: "两条红色捷径免费通行",
			comicDescNoToll: "停在有其他玩家的格子不必给奶酪",
			comicDescMarch14: "一次动多只鼠时,每只可走 1 至 4 格",
			comicDescColorblind: "动多只鼠时可停在绿橙混合格;橙绿背包同持时每回合只能用 1 个",
			comicDescDiscount: "建造火箭部件时,指定一种建材少交 1 个",
			comicDescNeil: "超级鼠:单独移动它时步数不限;不能偷东西;终局时若已在火箭中,其宇航员分双倍",
			comicDescLola: "超级鼠:步数 +2(单动 1-7;多鼠同动时它 1-5、其余 1-3)",
			comicDescArnold: "超级鼠:它移动并采集时额外 +1 资源(饮料翻倍之前)",
			comicDescRatwoman: "超级鼠:购物不付奶酪;永远不能偷",
			superNeil: "尼尔",
			superLola: "萝拉",
			superArnold: "阿诺",
			superRatwoman: "鼠女侠",
			cap0: "基石瓶盖",
			cap1: "储食瓶盖",
			cap2: "灯光瓶盖",
			cap3: "座舱瓶盖",
			cap4: "整箭瓶盖",
			cap5: "收藏家瓶盖",
			cap6: "补给瓶盖",
			cap7: "货舱瓶盖",
			cap8: "推进器瓶盖",
			cap9: "宇航瓶盖",
			capDesc0: "终局 12 分;你在三条部件轨上的每个计分标记 −2(不会变负)",
			capDesc1: "储食轨上你的每个计分标记 4 分",
			capDesc2: "建筑灯轨上你的每个计分标记 4 分",
			capDesc3: "座舱轨上你的每个计分标记 4 分",
			capDesc4: "整箭轨上你的每个计分标记 6 分",
			capDesc5: "你的每件物品(背包/饮料/漫画/瓶盖,含本瓶盖)2 分",
			capDesc6: "补给轨上你的每个计分标记 5 分",
			capDesc7: "货舱轨上你的每个计分标记 5 分",
			capDesc8: "推进器轨上你的每个计分标记 5 分",
			capDesc9: "你的每只宇航员鼠 4 分",
			yourMove: "你的回合:移动小鼠(1 只走 1-5 格,或多只同色落格各走 1-3 格)",
			waitTurn: "等待 {{name}} 行动…",
			postHint: "可购物 / 建造 / 捐献,然后结束回合",
			endTurn: "结束回合",
			endConfirm: "结束本回合?",
			moveConfirm: "出发",
			cancel: "取消",
			drinkUse: "用能量饮料 ×2",
			bonusOrange: "橙背包 +1:选建材",
			bonusGreen: "绿背包 +1:选建材",
			launchRewardTitle: "抵达发射台!选择奖励",
			rewardAward: "拿 1 奖章(3 分)",
			rewardRat: "从育儿室养 1 鼠",
			launchColorPick: "发射台本回合视为:",
			burrowUp: "向上",
			burrowLeft: "向左",
			burrowPickTitle: "鼠洞岔口方向(按经过顺序)",
			comicPickTitle: "经过图书馆:选漫画(下回合生效)",
			comicSkip: "不拿",
			superPickTitle: "超级鼠附体:选 1 只鼠",
			shopTitle: "购物",
			shopBuy: "买 {{price}}",
			shopSteal: "偷(回起点)",
			shopDone: "这只鼠已买过",
			buildTitle: "建造火箭",
			buildWith: "交 {{pay}}",
			donate: "捐 10 奶酪(补给轨)",
			tracksTitle: "计分轨",
			itemsTitle: "物品",
			supplyCaps: "瓶盖摊",
			supplyComics: "图书馆漫画",
			supplyBackpacks: "背包摊",
			supplyDrinks: "能量饮料",
			awardsLeft: "奖章余 {{n}}",
			markersLeft: "标记余 {{n}}",
			moldyN: "霉奶酪 {{n}}",
			drinkN: "饮料 {{n}}",
			awardN: "奖章 {{n}}",
			ratN: "鼠 {{n}}",
			nurseryN: "育儿室 {{n}}",
			lastRoundChip: "最后一轮",
			extraRoundChip: "加赛一轮",
			scoreTracks: "计分轨",
			scoreCaps: "瓶盖",
			scoreAwards: "奖章",
			scoreMoldy: "霉奶酪",
			scoreLeftover: "剩余物资",
			scoreTotal: "总分",
			optVariantPath: "变体路径",
			optVariantPathHint: "各组板块洗混后铺设",
			optVariantTracks: "变体计分轨",
			optVariantTracksHint: "随机移除 1 条计分轨(整箭轨除外)",
			errTurn: "还没轮到你",
			errMove: "这步移动不合法",
			errPay: "奶酪或建材不够",
			errBonus: "采集加成选择无效",
			errShop: "现在不能买这个",
			errBuild: "配方或建材不对",
			errComic: "漫画选择无效",
			errReward: "这个奖励现在选不了",
			fxToll: "过路费",
			fxMoldy: "霉奶酪 +{{n}}",
			fxLaunch: "宇航员!",
			fxStolen: "偷到手,回起点",
			addRat: "再动一只",
			stepsN: "{{n}} 步",
			tollCost: "过路费 −{{n}} 🧀",
			collectTitle: "采集预览",
			pickRatHint: "点选一只小鼠出发",
			pickDestHint: "点选高亮落点",
			multiSameColor: "多鼠同动须停同色的不同格",
			boardAria: "萌鼠摘月版图",
			startLabel: "起点",
			nurseryLabel: "育儿室",
			launchpadLabel: "发射台",
			colorBlue: "蓝",
			colorYellow: "黄",
			colorOrange: "橙",
			colorGreen: "绿",
			colorWhite: "白",
			trackRemoved: "本局已移除",
			buildOwned: "已建 ×{{n}}",
			pipeFree: "漫画免费",
			stealBtn: "偷(回起点)",
			sheetTracks: "计分轨与物品",
			draftChip: "已选 {{n}} 鼠 · 点我确认",
			clearDraft: "清空",
			needDir: "还有岔口未选方向",
			needReward: "请选择发射台奖励",
			needLaunchColor: "多鼠含发射台:选本回视同色",
			moldyWarn: "奶酪不足,差额将转霉奶酪"
		},
		en: {
			name: "First Rat",
			desc: "Junkyard rats build a rocket: race, collect, light up the string, and fly four rats to the Cheese Moon",
			rules: "Goal: score the most before the rocket is done. The end is triggered when a player moves their fourth rat into the rocket; finish the current round.\nAlternatively, when a player places their eighth score marker, finish the round and then play one more.\nEach turn:\n· Move, one of: advance one rat one to five spaces; or advance two to four rats one to three spaces each, all ending on different spaces of one color.\n· Always move towards the rocket; your own rats may not share a space, except at Start.\n· Ending on a space with other players' rats costs you one Cheese per player there.\n· If you cannot pay, take Moldy Cheese for the shortfall: each gives three Cheese now, minus two points at the end.\n· Pipes: from a pipe's entry space, hand in the depicted material to jump to its exit as a single step.\n· Collect: rats moved this turn yield their landing space.\n· Yellow gives Cheese, white Apple Cores, blue Lightbulbs, green and orange the depicted building material.\n· The amount is the printed number plus the light string bonus.\n· Lightbulbs advance your light string marker; every bulb it reaches or passes gives its path space a plus-one yield from now on, stacking.\n· Passing each of the three construction lights scores the Construction Lights track once.\n· Apple Cores advance your burrow marker clockwise; at each fork choose up or left.\n· Passing the Library grants a free comic; passing the Nursery raises one new rat, at most twice per game; passing the Stored Food scores its track.\n· Shopping: a rat that ended this turn on a booth space may buy one item.\n· Six Cheese for a Backpack from the Hamster, seven for an Energy Drink from the Frog, twelve for a Bottle Cap from the Crow.\n· Or steal one item for free, but that rat returns to Start.\n· Build: pay two Calculators and one Tin Can for the Cockpit; three Soda and two Tin Cans for the Cargo Bay.\n· Pay five Vinegar and two Soda for the Thruster. Each build scores the matching track.\n· Each full set of all three parts also scores the Rocket track. Donate ten Cheese to score Provisions. No limits.\n· Launchpad: a rat arriving becomes a Rattronaut on the leftmost free space of its track.\n· Then choose: one Award worth three points, or raise one rat from the Nursery to Start.\n· If it is not your fourth rat into the rocket, and no movable rats of yours would remain in play, you must raise.\nItems: Backpacks and Comics take effect from your next turn. An Energy Drink doubles one collection, at most one per turn.\nBottle Caps score at the end.\nScoring: the eight tracks, plus Bottle Caps, plus three points per Award, minus two per Moldy Cheese, plus one point per four leftover building materials and Cheese.\nTies go to the most Rattronauts, then shared.",
			resCheese: "Cheese",
			resCore: "Apple Core",
			resBulb: "Lightbulb",
			resVinegar: "Vinegar",
			resSoda: "Baking Soda",
			resCan: "Tin Can",
			resCalculator: "Calculator",
			trackCockpit: "Cockpit",
			trackCargoBay: "Cargo Bay",
			trackThruster: "Thruster",
			trackRocket: "Rocket",
			trackProvisions: "Provisions",
			trackLights: "Lights",
			trackFood: "Stored Food",
			trackRattronaut: "Rattronaut",
			boothHamster: "Hamster Backpacks",
			boothFrog: "Frog Energy Drinks",
			boothCrow: "Crow Bottle Caps",
			bpOrange: "Orange Pack",
			bpGreen: "Green Pack",
			bpCheese: "Cheese Pack",
			bpCore: "Core Pack",
			bpBulb: "Bulb Pack",
			bpDescOrange: "+1 building material of your choice from orange spaces",
			bpDescGreen: "+1 building material of your choice from green spaces",
			bpDescCheese: "+2 Cheese when collecting Cheese",
			bpDescCore: "+2 Apple Cores when collecting Cores",
			bpDescBulb: "+2 Lightbulbs when collecting Bulbs",
			comicPipesYellow: "Yellow Pipe Pass",
			comicPipesRed: "Red Pipe Pass",
			comicNoToll: "Freeloader",
			comicMarch14: "Route March",
			comicColorblind: "Color-Blind",
			comicDiscount: "Haggler",
			comicNeil: "Neil Ratstrong",
			comicLola: "Lola Rat",
			comicArnold: "Arnold Rattenegger",
			comicRatwoman: "Ratwoman",
			comicDescPipesYellow: "Use both yellow shortcuts for free",
			comicDescPipesRed: "Use both red shortcuts for free",
			comicDescNoToll: "No Cheese owed when stopping on occupied spaces",
			comicDescMarch14: "When moving 2+ rats, each may move 1-4 spaces",
			comicDescColorblind: "Multi-rat moves may mix green and orange; with both matching Backpacks, use only 1 per turn",
			comicDescDiscount: "When building, hand in 1 less of one depicted material",
			comicDescNeil: "Super Rat: moving it alone, go as far as you want; may never steal; double Rattronaut points at the end",
			comicDescLola: "Super Rat: +2 steps (1-7 alone; 1-5 in a group, others 1-3)",
			comicDescArnold: "Super Rat: when it moves and collects, +1 extra resource (before doubling)",
			comicDescRatwoman: "Super Rat: shopping costs no Cheese; may never steal",
			superNeil: "Neil",
			superLola: "Lola",
			superArnold: "Arnold",
			superRatwoman: "Ratwoman",
			cap0: "Cornerstone Cap",
			cap1: "Granary Cap",
			cap2: "Lamplighter Cap",
			cap3: "Cockpit Cap",
			cap4: "Rocket Cap",
			cap5: "Collector Cap",
			cap6: "Provisions Cap",
			cap7: "Cargo Cap",
			cap8: "Thruster Cap",
			cap9: "Astronaut Cap",
			capDesc0: "12 points at the end; −2 per marker of yours on the three part tracks (never below 0)",
			capDesc1: "4 points per marker of yours on Stored Food",
			capDesc2: "4 points per marker of yours on Construction Lights",
			capDesc3: "4 points per marker of yours on Cockpit",
			capDesc4: "6 points per marker of yours on Rocket",
			capDesc5: "2 points per item you own (Backpacks, Drinks, Comics, Caps — including this one)",
			capDesc6: "5 points per marker of yours on Provisions",
			capDesc7: "5 points per marker of yours on Cargo Bay",
			capDesc8: "5 points per marker of yours on Thruster",
			capDesc9: "4 points per Rattronaut of yours",
			yourMove: "Your turn: move rats (1 rat 1-5 spaces, or several 1-3 each onto same-colored spaces)",
			waitTurn: "Waiting for {{name}}…",
			postHint: "Shop, build, or donate — then end your turn",
			endTurn: "End turn",
			endConfirm: "End this turn?",
			moveConfirm: "Go",
			cancel: "Cancel",
			drinkUse: "Use Energy Drink ×2",
			bonusOrange: "Orange Pack +1: pick a material",
			bonusGreen: "Green Pack +1: pick a material",
			launchRewardTitle: "Launchpad reached! Pick a reward",
			rewardAward: "Take 1 Award (3 pts)",
			rewardRat: "Raise 1 rat from the Nursery",
			launchColorPick: "Launchpad counts as:",
			burrowUp: "Up",
			burrowLeft: "Left",
			burrowPickTitle: "Burrow fork directions (in order)",
			comicPickTitle: "Library passed: pick comics (active next turn)",
			comicSkip: "Skip",
			superPickTitle: "Super Rat: choose a rat",
			shopTitle: "Shopping",
			shopBuy: "Buy {{price}}",
			shopSteal: "Steal (back to Start)",
			shopDone: "This rat already shopped",
			buildTitle: "Build the rocket",
			buildWith: "Pay {{pay}}",
			donate: "Donate 10 Cheese (Provisions)",
			tracksTitle: "Score tracks",
			itemsTitle: "Items",
			supplyCaps: "Bottle Caps",
			supplyComics: "Library Comics",
			supplyBackpacks: "Backpacks",
			supplyDrinks: "Energy Drinks",
			awardsLeft: "Awards left {{n}}",
			markersLeft: "Markers left {{n}}",
			moldyN: "Moldy Cheese {{n}}",
			drinkN: "Drinks {{n}}",
			awardN: "Awards {{n}}",
			ratN: "Rats {{n}}",
			nurseryN: "Nursery {{n}}",
			lastRoundChip: "Final round",
			extraRoundChip: "Extra round",
			scoreTracks: "Tracks",
			scoreCaps: "Bottle Caps",
			scoreAwards: "Awards",
			scoreMoldy: "Moldy Cheese",
			scoreLeftover: "Leftovers",
			scoreTotal: "Total",
			optVariantPath: "Variable path",
			optVariantPathHint: "Tiles shuffled within each group",
			optVariantTracks: "Variable tracks",
			optVariantTracksHint: "One random track removed (Rocket stays)",
			errTurn: "Not your turn",
			errMove: "Illegal move",
			errPay: "Not enough Cheese or materials",
			errBonus: "Invalid collection bonus choice",
			errShop: "Cannot buy that now",
			errBuild: "Wrong recipe or materials",
			errComic: "Invalid comic choice",
			errReward: "That reward is unavailable",
			fxToll: "Toll",
			fxMoldy: "Moldy Cheese +{{n}}",
			fxLaunch: "Rattronaut!",
			fxStolen: "Stolen! Back to Start",
			addRat: "Move another rat",
			stepsN: "{{n}} steps",
			tollCost: "Toll −{{n}} 🧀",
			collectTitle: "Collection preview",
			pickRatHint: "Tap one of your rats to move",
			pickDestHint: "Tap a highlighted space",
			multiSameColor: "Rats moved together must land on different spaces of one color",
			boardAria: "First Rat board",
			startLabel: "START",
			nurseryLabel: "Nursery",
			launchpadLabel: "Launchpad",
			colorBlue: "Blue",
			colorYellow: "Yellow",
			colorOrange: "Orange",
			colorGreen: "Green",
			colorWhite: "White",
			trackRemoved: "Removed this game",
			buildOwned: "Built ×{{n}}",
			pipeFree: "Free (comic)",
			stealBtn: "Steal (back to Start)",
			sheetTracks: "Tracks & items",
			draftChip: "{{n}} rat(s) picked · tap to confirm",
			clearDraft: "Clear",
			needDir: "Fork direction missing",
			needReward: "Pick a launchpad reward",
			needLaunchColor: "Multi-rat with launchpad: pick its color",
			moldyWarn: "Not enough Cheese — shortfall becomes Moldy"
		}
	}
};
//#endregion
export { on as default };
