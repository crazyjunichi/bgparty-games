import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { ConfirmButton as a } from "@bgparty/sdk/confirm-button";
import { useT as o } from "@bgparty/sdk/i18n";
import { PhaseBanner as s } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as c } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { IconCheck as u } from "@bgparty/sdk/icons";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Texture as m } from "@bgparty/sdk/texture";
import { LogTicker as ee } from "@bgparty/sdk/ui/log-sheet";
import { Confetti as h } from "@bgparty/sdk/ui/confetti";
import { create as g } from "zustand";
import { persist as _ } from "zustand/middleware";
import { OptionRadio as v, OptionSection as y } from "@bgparty/sdk/ui/game-options";
//#region src/games/regicidelegacy/cards.ts
var b = [
	"w",
	"c",
	"b",
	"p"
], x = /* @__PURE__ */ new Map(), S = (e) => x.set(e.id, e);
for (let e of b) for (let t = 1; t <= 10; t += 1) S({
	id: `${e}${t}`,
	suit: e,
	value: t,
	tags: t === 1 ? ["animal"] : []
});
S({
	id: "j0",
	suit: null,
	value: 0,
	tags: ["jester"]
}), S({
	id: "j1",
	suit: null,
	value: 0,
	tags: ["jester"]
});
for (let e = 1; e <= 10; e += 1) S({
	id: `f${e}`,
	suit: "f",
	value: e,
	tags: []
});
for (let e of b) S({
	id: `beast-${e}`,
	suit: e,
	value: 0,
	tags: ["beast"]
});
S({
	id: "beast-f",
	suit: "f",
	value: 0,
	tags: ["beast"]
});
for (let e of [
	3,
	5,
	7,
	9
]) S({
	id: `mu${e}`,
	suit: "mu",
	value: e,
	tags: []
}), S({
	id: `ro${e}`,
	suit: "ro",
	value: e,
	tags: []
}), S({
	id: `fe${e}`,
	suit: "fe",
	value: e,
	tags: []
}), S({
	id: `dr${e}`,
	suit: "dr",
	value: e,
	tags: []
});
for (let e = 2; e <= 7; e += 1) for (let t of [
	"a",
	"b",
	"c",
	"d"
]) S({
	id: `pg${e}${t}`,
	suit: null,
	value: e,
	tags: ["pilgrim"]
});
S({
	id: "pg1",
	suit: null,
	value: 1,
	tags: ["pilgrim", "animal"]
}), S({
	id: "arc25",
	suit: "f",
	value: 25,
	tags: []
}), S({
	id: "goran0",
	suit: null,
	value: 8,
	tags: []
}), S({
	id: "goran",
	suit: "ev",
	value: 8,
	tags: []
}), S({
	id: "esme",
	suit: "ev",
	value: 6,
	tags: []
}), S({
	id: "myla",
	suit: "b",
	value: 7,
	tags: []
});
for (let e of b) S({
	id: `m12${e}`,
	suit: e,
	value: 12,
	tags: ["merc"],
	cost: 1
}), S({
	id: `m25${e}`,
	suit: e,
	value: 5,
	tags: ["merc", "pair"],
	cost: 1
});
S({
	id: "m19a",
	suit: "ro",
	value: 19,
	tags: ["merc"],
	cost: 3
}), S({
	id: "m19b",
	suit: "ro",
	value: 19,
	tags: ["merc"],
	cost: 3
}), S({
	id: "mwa",
	suit: null,
	value: 1,
	tags: [
		"merc",
		"wild",
		"animal"
	],
	cost: 3
}), S({
	id: "mwb",
	suit: null,
	value: 1,
	tags: [
		"merc",
		"wild",
		"animal"
	],
	cost: 3
}), S({
	id: "mj0",
	suit: null,
	value: 0,
	tags: ["merc", "jester"],
	cost: 5
}), S({
	id: "mj1",
	suit: null,
	value: 0,
	tags: ["merc", "jester"],
	cost: 5
});
var te = [...x.values()].filter((e) => e.tags.includes("merc")).map((e) => e.id);
function C(e) {
	let t = x.get(e);
	if (!t) throw Error(`unknown card ${e}`);
	return t;
}
var w = (e, t) => x.get(e)?.tags.includes(t) ?? !1, T = (e) => w(e, "jester"), E = (e) => w(e, "beast"), D = b.flatMap((e) => Array.from({ length: 10 }, (t, n) => `${e}${n + 1}`));
function O(e, t) {
	let n = C(e).suit, r = n ? [n] : [], i = t.dual[e];
	return i && !r.includes(i) && r.push(i), t.apprentice === e && !r.includes("f") && r.push("f"), r;
}
var k = (e, t) => t.corrupted.includes(e) && !t.reborn.includes(e), ne = (e, t) => O(e, t).includes("f"), A = {
	id: "regicidelegacy",
	tier: "beta",
	mechanics: ["hand-management"],
	interactionTags: ["cooperative"],
	nameKey: "games.regicidelegacy.name",
	descKey: "games.regicidelegacy.desc",
	rulesKey: "games.regicidelegacy.rules",
	icon: "👑",
	iconImg: "games/regicidelegacy.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/regicidelegacy/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#7c3aed",
	releasedAt: "2026-10-24T13:43:24+08:00",
	search: {
		py: "jun wang ling yi chan",
		init: "jwlyc"
	},
	hotseat: "cover"
}, j = (e, t, n) => ({ enemies: b.map((r) => ({
	name: e,
	atk: t,
	hp: n,
	suits: [r]
})) }), M = {
	1: { groups: [
		j("justicar", 10, 20),
		j("justicar", 15, 30),
		j("justicar", 20, 40)
	] },
	2: {
		groups: [{ enemies: Array.from({ length: 6 }, () => ({
			name: "hydra",
			atk: 10,
			hp: 20,
			suits: []
		})) }],
		randomSuits: 2
	},
	3: { groups: [
		{ enemies: Array.from({ length: 4 }, () => ({
			name: "instructor",
			atk: 10,
			hp: 30,
			suits: ["f"]
		})) },
		{ enemies: Array.from({ length: 2 }, () => ({
			name: "professor",
			atk: 15,
			hp: 45,
			suits: ["f"]
		})) },
		{ enemies: [{
			name: "dean",
			atk: 20,
			hp: 60,
			suits: ["f"]
		}] }
	] },
	4: { groups: [
		j("experiment", 10, 20),
		j("experiment", 15, 30),
		j("experiment", 20, 40)
	] },
	5: { groups: [j("sporite", 10, 40), j("umbrispore", 15, 60)] },
	6: { groups: [j("statue", 15, 30), j("gardenstatue", 20, 40)] },
	7: { groups: [
		j("shallowkin", 10, 20),
		j("deepkin", 15, 30),
		j("abysskin", 20, 40)
	] },
	8: {
		groups: [{ enemies: Array.from({ length: 6 }, () => ({
			name: "troll",
			atk: 10,
			hp: 20,
			suits: []
		})) }, { enemies: Array.from({ length: 6 }, () => ({
			name: "wyvern",
			atk: 25,
			hp: 50,
			suits: []
		})) }],
		randomSuits: 2
	},
	9: { groups: [
		j("loreguard", 15, 30),
		j("lorekeeper", 20, 40),
		{ enemies: [{
			name: "myla",
			atk: 30,
			hp: 60,
			suits: ["b", "p"],
			hardImmune: ["b", "p"]
		}] }
	] },
	10: { groups: [{
		ordered: !0,
		enemies: Array.from({ length: 8 }, (e, t) => {
			let n = t + 2, r = n === 2 || n === 6 ? "w" : n === 3 || n === 7 ? "c" : n === 4 || n === 8 ? "b" : "p";
			return {
				name: `corrupted${n}`,
				atk: n,
				hp: n * 5,
				suits: [r]
			};
		})
	}] },
	11: { groups: [{ enemies: Array.from({ length: 4 }, () => ({
		name: "mutant",
		atk: 10,
		hp: 30,
		suits: []
	})) }, { enemies: [{
		name: "vid",
		atk: 20,
		hp: 60,
		suits: []
	}] }] },
	12: { groups: [
		j("mutantqueen", 15, 30),
		j("mutantking", 20, 40),
		{ enemies: [{
			name: "arcana",
			atk: 30,
			hp: 60,
			suits: [...b]
		}] }
	] },
	13: { groups: [j("experiment", 15, 30), j("experiment", 20, 40)] }
};
Object.fromEntries(Object.entries(M).map(([e, t]) => [e, t.groups.reduce((e, t) => e + t.enemies.length, 0)]));
//#endregion
//#region src/games/regicidelegacy/schema.ts
var N = t.enum([
	"w",
	"c",
	"b",
	"p",
	"f",
	"mu",
	"ro",
	"fe",
	"dr",
	"ev"
]), P = t.string().min(1).max(16), re = t.object({
	mission: t.number().int().min(1).max(13).default(1),
	evg: t.object({
		location: t.enum([
			"A",
			"B",
			"C",
			"D",
			"E"
		]),
		curses: t.array(t.number().int().min(1).max(23)).max(5),
		boons: t.array(t.number().int().min(24).max(35)).max(2)
	}).nullable().default(null),
	party: t.array(P).default([]),
	corrupted: t.array(P).default([]),
	dual: t.record(P, N).default({}),
	apprentice: P.nullable().default(null),
	reborn: t.array(P).default([]),
	relics: t.array(t.enum([
		"flute",
		"whistle",
		"emblem",
		"motherC",
		"motherR"
	])).default([]),
	beast: P.nullable().default(null),
	mercs: t.array(P).default([])
}).prefault({}), ie = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		cards: t.array(P).max(8),
		flute: t.array(P).max(4).optional(),
		asValue: t.record(P, t.union([t.literal(2), t.literal(5)])).optional(),
		asSuit: t.record(P, N).optional(),
		soloJesterSuit: N.optional()
	}),
	t.object({ type: t.literal("yield") }),
	t.object({
		type: t.literal("defend"),
		cards: t.array(P).max(12)
	}),
	t.object({ type: t.literal("jester") }),
	t.object({ type: t.literal("jesterClaim") }),
	t.object({
		type: t.literal("magePick"),
		card: P
	}),
	t.object({
		type: t.literal("druidAssign"),
		hand: P.optional(),
		banish: P.optional(),
		top: P.optional(),
		bottom: P.optional()
	}),
	t.object({
		type: t.literal("chanterDraw"),
		count: t.number().int().min(0).max(60)
	}),
	t.object({
		type: t.literal("discardDown"),
		cards: t.array(P).min(1).max(12)
	}),
	t.object({
		type: t.literal("whistleGive"),
		card: P.optional(),
		asValue: t.union([t.literal(2), t.literal(5)]).optional(),
		asSuit: N.optional()
	}),
	t.object({
		type: t.literal("fluteGive"),
		cards: t.array(P).max(4),
		asValue: t.record(P, t.union([t.literal(2), t.literal(5)])).optional(),
		asSuit: t.record(P, N).optional()
	}),
	t.object({
		type: t.literal("emblemGive"),
		card: P.optional()
	}),
	t.object({
		type: t.literal("emblemReturn"),
		card: P.optional()
	}),
	t.object({
		type: t.literal("motherGive"),
		card: P
	}),
	t.object({
		type: t.literal("motherSolo"),
		useDiscard: t.boolean()
	}),
	t.object({
		type: t.literal("reaverCount"),
		count: t.number().int().min(1).max(60)
	}),
	t.object({
		type: t.literal("mylaPick"),
		card: P
	}),
	t.object({
		type: t.literal("rescue"),
		banishCard: P.optional(),
		zoneCard: P.optional()
	}),
	t.object({
		type: t.literal("chainMove"),
		cards: t.array(P).max(8)
	}),
	t.object({
		type: t.literal("cull"),
		cards: t.array(P).max(60)
	}),
	t.object({
		type: t.literal("zonePick"),
		card: P.optional()
	}),
	t.object({
		type: t.literal("reaverPick"),
		card: P
	}),
	t.object({
		type: t.literal("fluteAdd"),
		card: P
	}),
	t.object({
		type: t.literal("bardTake"),
		card: P
	}),
	t.object({
		type: t.literal("pilgrimBanish"),
		card: P
	}),
	t.object({
		type: t.literal("discardPick"),
		card: P
	}),
	t.object({
		type: t.literal("evgPick"),
		card: P.optional()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), F = t.object({
	eid: t.string(),
	name: t.string(),
	atk: t.number(),
	hp: t.number(),
	maxHp: t.number(),
	suits: t.array(N),
	shield: t.number(),
	effectiveAtk: t.number(),
	effectiveImmune: t.array(N)
}), ae = t.object({
	kind: t.enum([
		"magePick",
		"druidAssign",
		"chanterDraw",
		"discardDown",
		"whistleGive",
		"fluteGive",
		"emblemGive",
		"emblemReturn",
		"motherGive",
		"motherSolo",
		"reaverCount",
		"reaverPick",
		"mylaPick",
		"rescue",
		"chainMove",
		"cull",
		"zonePick",
		"bardTake",
		"discardPick",
		"squadMove",
		"rescueMove",
		"strikePick",
		"arrowsPick",
		"closeCall",
		"poisonPick"
	]),
	by: t.string().nullable(),
	revealed: t.array(P).optional()
}), I = t.object({
	k: t.string(),
	rid: t.string().optional(),
	cards: t.array(P).optional(),
	n: t.number().optional(),
	dmg: t.number().optional(),
	exact: t.boolean().optional(),
	extra: t.string().optional()
}), oe = t.object({
	mission: t.number(),
	phase: t.enum([
		"play",
		"defend",
		"choice",
		"done"
	]),
	turn: t.string(),
	handLimit: t.number(),
	enemy: F.nullable(),
	enemyLeft: t.number(),
	enemyTotal: t.number(),
	reserveCount: t.number(),
	discard: t.array(P),
	banish: t.array(P),
	zoneFaceup: t.array(P),
	zoneFacedownCount: t.number(),
	zonePiles: t.array(t.object({
		top: P.nullable(),
		count: t.number()
	})).optional(),
	players: t.array(t.object({
		rid: t.string(),
		handCount: t.number(),
		mat: t.array(t.object({
			id: P,
			v: t.number().optional(),
			suit: N.optional(),
			tucked: t.boolean().optional()
		}))
	})),
	flute: t.array(P),
	fluteUsedBy: t.string().nullable(),
	relics: t.array(t.string()),
	emblemUsed: t.boolean(),
	defendNeed: t.number().nullable(),
	defendKind: t.enum([
		"enemy",
		"myla",
		"teamEnd"
	]).nullable(),
	feignOk: t.boolean(),
	yieldBlocked: t.boolean(),
	pending: ae.nullable(),
	jesterOut: t.string().nullable(),
	result: t.enum(["win", "lose"]).nullable(),
	kills: t.number(),
	corrupted: t.array(P),
	dual: t.record(P, N),
	apprentice: P.nullable(),
	reborn: t.array(P),
	enemyBook: t.record(t.string(), t.object({
		name: t.string(),
		atk: t.number(),
		suits: t.array(N)
	})),
	soloJesters: t.number().optional(),
	evg: t.object({
		location: t.enum([
			"A",
			"B",
			"C",
			"D",
			"E"
		]),
		curses: t.array(t.number()),
		boons: t.array(t.number())
	}).nullable(),
	log: t.array(I)
}), se = t.object({ hand: t.array(P) }), L = (e) => ({ code: `games.regicidelegacy.${e}` }), ce = (e) => e <= 1 ? 8 : e === 2 ? 7 : e === 3 ? 6 : 5, R = (e) => e <= 2 ? 0 : e - 2, z = [];
for (let e = 2; e <= 7; e += 1) for (let t of [
	"a",
	"b",
	"c",
	"d"
]) z.push(`pg${e}${t}`);
var le = 80;
function B(e, t) {
	e.log.push(t), e.log.length > le && e.log.splice(0, e.log.length - le);
}
function V(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var ue = (e) => e.mods, H = (e, t) => e.mission === 13 && (e.evg?.curses.includes(t) ?? !1), de = (e, t) => e.mission === 13 && (e.evg?.boons.includes(t) ?? !1), fe = (e) => e.mission === 13 ? e.evg?.location ?? null : null, U = (e, t) => e.enemyDefs[t]?.atk ?? C(t).value, W = (e, t) => e.enemyDefs[t]?.suits ?? O(t, ue(e)), pe = (e, t) => !e.enemyDefs[t] && ne(t, ue(e)), me = (e, t) => !!e.enemyDefs[t] || k(t, ue(e)), he = (e, t) => !e.enemyDefs[t] && e.mods.reborn.includes(t), G = (e, t, n) => !e.enemyDefs[t] && w(t, n), ge = (e) => e.enemyDeck[0], K = (e) => e.enemyDefs[ge(e).eid], _e = (e, t) => t.length > 0 ? U(e, t[t.length - 1]) : 0;
function q(e, t = !0) {
	return e.zoneUp.reduce((n, r) => n + (t || !G(e, r, "pilgrim") ? U(e, r) : 0), 0);
}
function ve(e) {
	let t = [], n = (n) => {
		if (n.length > 0) for (let r of W(e, n[n.length - 1])) t.includes(r) || t.push(r);
	};
	if (e.mission === 3 || e.mission === 12) for (let n of e.zoneUp) for (let r of W(e, n)) t.includes(r) || t.push(r);
	if (e.mission === 11 && (n(e.discard), n(e.banished)), e.mission === 13) {
		if (fe(e) === "A") for (let n of e.zoneUp) for (let r of W(e, n)) t.includes(r) || t.push(r);
		H(e, 19) && n(e.discard), H(e, 20) && n(e.banished);
	}
	return t;
}
function ye(e) {
	let t = [...K(e).suits];
	for (let n of ve(e)) t.includes(n) || t.push(n);
	return t;
}
function be(e) {
	switch (e.mission) {
		case 4: return _e(e, e.discard);
		case 5: return q(e);
		case 8: return q(e, !1);
		case 10: return q(e);
		case 11: return _e(e, e.discard) + _e(e, e.banished);
		case 12: return q(e);
		case 13: {
			let t = 0;
			return fe(e) === "C" && (t += q(e)), H(e, 17) && (t += _e(e, e.discard)), H(e, 18) && (t += _e(e, e.banished)), t;
		}
		default: return 0;
	}
}
function xe(e) {
	let t = K(e), n = t.atk + be(e);
	return e.mission === 10 && t.suits.includes("w") && (n *= 2), e.mission === 13 && H(e, 9) && t.suits.includes("w") && (n *= 2), n - e.shield;
}
function J(e, t) {
	e.relics.includes("motherR") && he(e, t) ? e.reserve.push(t) : e.banished.push(t);
}
function Y(e, t) {
	e.zoneUp.push(t);
}
var Se = (e, t) => me(e, t) || he(e, t) || W(e, t).includes("ev");
function Ce(e, t, n, r) {
	let i = e.combat;
	if (!i) return;
	let a = r || Se(e, t), o = [];
	for (let e of n) e === "ev" ? o.push("w", "c", "b", "p") : o.push(e);
	if (t === "pg1" && de(e, 28)) for (let e of b) o.includes(e) || o.push(e);
	for (let e of o) i.suits[e] = (i.suits[e] ?? !1) || a;
}
function we(e, t) {
	let n = e.combat?.suits[t];
	return n === void 0 || e.enemyDeck.length === 0 || K(e).hardImmune?.includes(t) ? !1 : n || !ye(e).includes(t);
}
function Te(e, t, n, r) {
	if (me(e, t)) {
		if (e.relics.includes("motherC")) {
			if (e.solo) r.push({
				kind: "motherSolo",
				by: n
			});
			else {
				let t = e.players.find((t) => t !== n && e.hands[t].length > 0);
				t && r.push({
					kind: "motherGive",
					by: t
				});
			}
		} else e.reserve.length > 0 && J(e, e.reserve.shift());
	}
	if (he(e, t) && e.banished.length > 0) {
		let t = e.banished.pop();
		me(e, t) ? e.banished.unshift(t) : e.reserve.push(t), B(e, {
			k: "rebornPick",
			cards: [t]
		});
	}
}
function Ee(e, t) {
	if (t.kind === "magePick") {
		let n = t.aux === void 0 ? e.combat?.base ?? 1 : Number(t.aux), r = e.reserve.slice(0, Math.min(Math.max(n, 1), e.reserve.length)), i = [];
		for (let t of r) if (T(t) || me(e, t)) {
			let n = e.reserve.indexOf(t);
			n >= 0 && e.reserve.splice(n, 1), e.discard.push(t);
		} else i.push(t);
		return t.revealed = i, i.length > 0;
	}
	if (t.kind === "reaverPick") return (t.revealed?.length ?? 0) > 0;
	if (t.kind === "whistleGive") return e.flags.whistleFilled ? !1 : e.solo ? e.discard.length > 0 : e.hands[t.by].some((e) => !T(e));
	if (t.kind === "fluteGive" || t.kind === "emblemGive") return e.hands[t.by].length > 0;
	if (t.kind === "emblemReturn") return (t.revealed?.length ?? 0) > 0;
	if (t.kind === "motherGive") return e.hands[t.by].length > 0;
	if (t.kind === "motherSolo") return e.discard.length > 0;
	if (t.kind === "druidAssign") {
		if (!e.druidDeal) {
			e.druidAside = { ...e.hands };
			for (let t of e.players) e.hands[t] = [];
			let t = Object.fromEntries(e.players.map((e) => [e, []])), n = e.turnIdx;
			for (let r of V(e, e.discard)) t[e.players[n]].push(r), n = (n + 1) % e.players.length;
			e.druidDeal = t, e.discard = [];
		}
		return t.revealed = e.druidDeal[t.by] ?? [], (e.druidDeal[t.by]?.length ?? 0) > 0;
	}
	return t.kind === "chanterDraw" ? e.reserve.length > 0 : t.kind === "discardPick" ? e.discard.length > 0 : t.kind === "squadMove" ? e.zoneUp.some((n) => String(t.aux).split(",").map(Number).includes(U(e, n))) : t.kind === "rescueMove" ? e.zoneUp.some((n) => U(e, n) === Number(t.aux)) : t.kind === "strikePick" ? e.zoneUp.length > 0 || e.discard.length > 0 : t.kind === "arrowsPick" ? e.banished.length > 0 : t.kind === "closeCall" ? e.discard.length > 0 : t.kind !== "poisonPick" || e.hands[t.by].length > 0 || (e.reserve.length > 0 && (Y(e, e.reserve.shift()), B(e, {
		k: "zoneFlip",
		n: 1
	})), !1);
}
function De(e, t) {
	for (; !e.pending;) {
		let t = e.queue.shift();
		if (!t) break;
		if (Ee(e, t)) {
			e.pending = t, e.phase = "choice";
			return;
		}
	}
	if (e.pending) {
		e.phase = "choice";
		return;
	}
	let n = e.afterChoice;
	e.afterChoice = null, n === "attack" ? Ie(e, t) : n === "damage" ? Le(e, t) : n === "postAttack" ? Re(e, t) : n === "defeat" ? He(e, t) : n === "postDefend" ? ze(e, t) : n === "endturn" ? je(e, t) : n === "start" && (e.phase = "play", Ze(e));
}
function Oe(e, t) {
	e.guardianUp = !1, e.fluteUsedBy = null, e.emblemUsed = !1, e.flags.whistleFilled = !1, e.flags.pilgrimUsed = !1, Me(e, t), !e.pending && e.phase !== "done" && (e.phase = "play", Ze(e));
}
function ke(e, t) {
	e.turnIdx = (e.turnIdx + 1) % e.players.length, Oe(e, t);
}
function Ae(e, t) {
	if (Ne(e, t), e.pending) {
		e.afterChoice = "endturn", e.phase = "choice";
		return;
	}
	je(e, t);
}
function je(e, t) {
	let n = typeof e.flags.teamEndNeed == "number" ? e.flags.teamEndNeed : 0;
	if (e.flags.teamEndNeed = 0, e.phase !== "done") {
		if (n > 0) {
			Be(e, t, "teamEnd", n);
			return;
		}
		ke(e, t);
	}
}
function Me(e, t) {
	let n = e.players[e.turnIdx];
	if (e.mission === 7 && e.zoneDown.length > 0 && (Y(e, e.zoneDown.shift()), B(e, {
		k: "zoneFlip",
		n: 1
	})), e.mission === 10 && e.reserve.length > 0 && (Y(e, e.reserve.shift()), B(e, {
		k: "zoneFlip",
		n: 1
	})), e.mission === 11) {
		if (e.flags.skipFlip) e.flags.skipFlip = !1;
		else if (e.zoneDown.length > 0) {
			let t = e.zoneDown.shift();
			e.zoneUp.push(t);
			let r = C(t).suit;
			if (B(e, {
				k: "beastFlip",
				cards: [t]
			}), r === "w" ? e.discard.length > 0 && J(e, e.discard.pop()) : r === "c" || r === "b" ? e.hands[n].length > 0 && (e.pending = {
				kind: "bardTake",
				by: n,
				aux: r === "b" ? "banish" : "discard"
			}, e.afterChoice = "start", e.phase = "choice") : r === "p" && e.reserve.length > 0 && e.discard.push(e.reserve.shift()), e.zoneDown.length === 0) {
				let t = e.zoneUp.filter((e) => E(e));
				e.zoneUp = e.zoneUp.filter((e) => !E(e)), e.zoneDown = V(e, t);
			}
		}
	}
	if (e.mission === 12 && (e.flags.skipStart ? e.flags.skipStart = !1 : e.banished.length > 0 && (Y(e, e.banished.pop()), B(e, {
		k: "zoneFlip",
		n: 1
	}))), e.mission === 13 && (H(e, 16) && e.discard.length > 0 && (J(e, e.discard.pop()), B(e, {
		k: "evgDread",
		n: 1
	})), H(e, 22) && e.reserve.length > 0 && e.discard.push(e.reserve.shift()), fe(e) === "E")) {
		let t = e.zoneDown.length > 0 ? e.zoneDown.shift() : e.reserve.length > 0 ? e.reserve.shift() ?? null : null;
		t && (Y(e, t), B(e, {
			k: "zoneFlip",
			n: 1
		}));
	}
}
function Ne(e, t) {
	let n = e.players[e.turnIdx];
	if (e.flags.skipEndHook) {
		e.flags.skipEndHook = !1;
		return;
	}
	if (e.mission === 3 && e.reserve.length > 0 && (Y(e, e.reserve.shift()), B(e, {
		k: "zoneFlip",
		n: 1
	})), e.mission === 5 && e.banished.length > 0 && (Y(e, e.banished.pop()), B(e, {
		k: "zoneFlip",
		n: 1
	})), e.mission === 9 && e.zonePiles && e.zonePiles.some((e) => e.up !== null) && (e.hands[n].length > 0 ? e.pending = {
		kind: "rescue",
		by: n
	} : Pe(e), B(e, { k: "rescue" })), e.mission === 10) {
		let t = K(e);
		t.suits.includes("c") && e.discard.length > 0 && (Y(e, e.discard.pop()), B(e, {
			k: "zoneFlip",
			n: 1
		})), t.suits.includes("b") && e.hands[n].length > 0 && !e.pending && (e.pending = {
			kind: "bardTake",
			by: n,
			aux: "zone"
		});
	}
	if (e.mission === 13 && e.enemyDeck.length > 0) {
		let t = fe(e);
		if ((t === "A" || t === "B") && e.reserve.length > 0 && (Y(e, e.reserve.shift()), B(e, {
			k: "zoneFlip",
			n: 1
		})), t === "B" && e.zoneUp.length > 0 && q(e) >= K(e).atk) {
			for (let t of e.zoneUp) J(e, t);
			e.zoneUp = [];
			for (let t of e.discard) J(e, t);
			e.discard = [], B(e, { k: "evgPurge" });
		}
		(t === "C" || t === "D") && e.banished.length > 0 && (Y(e, e.banished.pop()), B(e, {
			k: "zoneFlip",
			n: 1
		})), t === "D" && q(e) > 0 && (e.flags.teamEndNeed = q(e));
		let r = K(e);
		H(e, 10) && r.suits.includes("c") && e.discard.length > 0 && (Y(e, e.discard.pop()), B(e, {
			k: "zoneFlip",
			n: 1
		}));
		let i = [];
		H(e, 12) && r.suits.includes("b") && e.hands[n].length > 0 && i.push({
			kind: "bardTake",
			by: n,
			aux: "zone"
		}), H(e, 23) && i.push({
			kind: "poisonPick",
			by: n
		}), i.length > 0 && (e.pending ? e.queue.push(...i) : (e.pending = i[0], e.queue.push(...i.slice(1))));
	}
}
function Pe(e) {
	if (e.zonePiles) for (let t of e.zonePiles) t.up !== null && (t.down.push(t.up), t.up = t.down.shift() ?? null);
}
function Fe(e, t) {
	e.pending || (e.afterChoice = "attack", De(e, t));
}
function Ie(e, t) {
	let n = e.combat;
	if (!n) return;
	let r = e.players[e.turnIdx], i = n.base;
	if (we(e, "c") && i > 0 && e.discard.length > 0) {
		e.discard = V(e, e.discard);
		let t = e.discard.splice(0, Math.min(i, e.discard.length));
		e.reserve.push(...t), B(e, {
			k: "heal",
			n: t.length
		});
	}
	if (we(e, "b") && i > 0) {
		let n = ct(e, i);
		for (let [e, r] of Object.entries(n)) t.push({
			kind: "draw",
			rid: e,
			data: { count: r.length },
			for: [e],
			secret: { cards: r },
			with: !0
		});
	}
	we(e, "p") && i > 0 && (e.shield += i, n.suits.p && (e.shieldCorrupt += i), B(e, {
		k: "shieldUp",
		n: i
	})), we(e, "ro") && (e.guardianUp = !0);
	let a = [];
	if (we(e, "fe") && e.discard.length > 0) for (let t = 0; t < e.players.length; t += 1) a.push({
		kind: "druidAssign",
		by: e.players[(e.turnIdx + t) % e.players.length]
	});
	we(e, "dr") && a.push({
		kind: "chanterDraw",
		by: r
	}), we(e, "mu") && e.reserve.length > 0 && a.push({
		kind: "reaverCount",
		by: r
	}), e.queue.push(...a), e.afterChoice = "damage", De(e, t);
}
function Le(e, t) {
	let n = e.combat;
	if (!n) return;
	let r = n.base + n.reaverBonus;
	we(e, "mu") && (r *= 2), we(e, "w") && (r *= 2), e.mission === 10 && K(e).suits.includes("p") && (r = Math.max(0, r - K(e).atk)), e.mission === 13 && H(e, 11) && K(e).suits.includes("p") && (r = Math.max(0, r - 10));
	let i = ge(e);
	if (i.hp -= r, B(e, {
		k: "damage",
		dmg: r,
		n: i.hp
	}), t.push({
		kind: "damage",
		data: {
			dmg: r,
			hp: i.hp
		}
	}), e.mission === 13) {
		let t = e.players[e.turnIdx];
		if (H(e, 21) && e.hands[t].length > 0 && n.cards.some((t) => (t.asV ?? U(e, t.id)) >= 8) && e.queue.push({
			kind: "bardTake",
			by: t,
			aux: "zone"
		}), de(e, 30) && e.zoneUp.length > 0) {
			let r = [...new Set(n.cards.map((t) => t.asV ?? U(e, t.id)))];
			e.zoneUp.some((t) => r.includes(U(e, t))) && e.queue.push({
				kind: "squadMove",
				by: t,
				aux: r.join(",")
			});
		}
	}
	e.afterChoice = "postAttack", De(e, t);
}
function Re(e, t) {
	if (e.combat = null, e.phase === "done") return;
	let n = ge(e);
	n.hp <= 0 ? Ve(e, t, n.hp === 0) : Be(e, t, "enemy");
}
function ze(e, t) {
	e.phase !== "done" && (e.defendKind === "enemy" ? Ae(e, t) : e.defendKind === "myla" ? Oe(e, t) : ke(e, t));
}
function Be(e, t, n, r) {
	let i = e.guardianUp ? 0 : r ?? xe(e);
	if (i <= 0) {
		n === "enemy" ? Ae(e, t) : n === "myla" ? Oe(e, t) : ke(e, t);
		return;
	}
	e.phase = "defend", e.defendKind = n, e.defendNeed = i, e.defendAccum = 0;
}
function Ve(e, t, n) {
	let r = K(e), i = e.enemyDeck.shift();
	if (e.kills += 1, e.flags.fallenEid = i.eid, e.flags.fallenExact = n, (e.mission === 3 || e.mission === 9) && (e.flags.skipEndHook = !0), B(e, {
		k: "slain",
		dmg: r.atk,
		exact: n
	}), t.push({
		kind: "slain",
		data: {
			eid: i.eid,
			exact: n,
			last: e.enemyDeck.length === 0
		}
	}), e.enemyDeck.length === 0) {
		Ue(e), e.phase = "done", e.result = "win";
		return;
	}
	We(e, n, t), e.afterChoice = "defeat", De(e, t);
}
function He(e, t) {
	let n = e.flags.fallenExact === !0, r = typeof e.flags.fallenEid == "string" ? e.enemyDefs[e.flags.fallenEid] : void 0;
	if (Ue(e), e.shield = 0, e.shieldCorrupt = 0, e.jesterBoost = !1, e.flags.fallenEid = !1, e.flags.fallenExact = !1, e.mission === 5 && n && r && e.enemyDeck.length > 0) {
		let n = ge(e);
		if (n.hp -= r.atk, B(e, {
			k: "damage",
			dmg: r.atk,
			n: n.hp
		}), t.push({
			kind: "damage",
			data: {
				dmg: r.atk,
				hp: n.hp
			}
		}), n.hp <= 0) {
			Ve(e, t, n.hp === 0);
			return;
		}
	}
	if (e.mission === 6 && e.mylaZone) {
		Be(e, t, "myla", q(e));
		return;
	}
	if (e.mission === 13 && H(e, 13) && r && e.enemyDeck.length > 0) {
		Be(e, t, "myla", r.atk);
		return;
	}
	e.phase !== "done" && Oe(e, t);
}
function Ue(e) {
	for (let t of e.players) {
		let n = e.mats[t], r = n.some((e) => e.tucked);
		for (let t of n) t.tucked || r && pe(e, t.id) ? J(e, t.id) : e.discard.push(t.id);
		e.mats[t] = [];
	}
}
function We(e, t, n) {
	let r = String(e.flags.fallenEid), i = e.players[e.turnIdx], a = () => {
		t ? e.reserve.unshift(X(e, r)) : e.discard.push(X(e, r));
	};
	switch (e.mission) {
		case 2:
			t ? J(e, X(e, r)) : e.enemyDeck.push({
				eid: r,
				hp: e.enemyDefs[r].hp
			});
			break;
		case 3:
			if (t && e.zoneUp.length > 0) e.pending = {
				kind: "zonePick",
				by: i
			};
			else {
				J(e, X(e, r));
				for (let t of e.zoneUp) J(e, t);
				e.zoneUp = [];
			}
			break;
		case 4:
			a();
			break;
		case 5:
			e.banished = V(e, [
				...e.banished,
				X(e, r),
				...e.zoneUp
			]), e.zoneUp = [];
			break;
		case 6:
			J(e, X(e, r)), e.players.some((t) => e.mats[t].length > 0) && (e.pending = {
				kind: "mylaPick",
				by: i
			}), t && e.zoneUp.some((e) => e !== "myla") && (e.pending ? e.queue.unshift({
				kind: "zonePick",
				by: i
			}) : e.pending = {
				kind: "zonePick",
				by: i
			});
			break;
		case 7:
			J(e, X(e, r)), t && e.zoneUp.length > 0 ? e.pending = {
				kind: "zonePick",
				by: i
			} : Ge(e);
			break;
		case 8:
			J(e, X(e, r)), e.mats[i].length > 0 && !e.flags.zoneSealed && (e.pending = {
				kind: "chainMove",
				by: i
			}), t && e.discard.length > 0 && e.queue.unshift({
				kind: "discardPick",
				by: i
			});
			break;
		case 9:
			J(e, X(e, r)), t && e.zonePiles?.some((e) => e.up !== null) && (e.pending = {
				kind: "zonePick",
				by: i
			});
			break;
		case 10:
			if (e.discard.push(X(e, r)), t) e.discard.push(...e.zoneUp);
			else for (let t of e.zoneUp) J(e, t);
			e.zoneUp = [];
			break;
		case 11:
			J(e, X(e, r)), t && (e.flags.skipFlip = !0);
			break;
		case 12:
			for (let t of e.zoneUp) J(e, t);
			e.zoneUp = [], J(e, X(e, r));
			for (let t of e.discard) J(e, t);
			e.discard = [], t && (e.flags.skipStart = !0);
			break;
		case 13: {
			let n = e.enemyDefs[r];
			if (H(e, 1) && n?.name === "hydra" && !t) {
				e.enemyDeck.push({
					eid: r,
					hp: n.hp
				});
				break;
			}
			if (H(e, 15) && !t) {
				for (let t of e.discard) J(e, t);
				e.discard = [];
			}
			let a = fe(e);
			if (a === "A" || a === "B" || a === null) {
				if (t ? e.discard.push(X(e, r)) : J(e, X(e, r)), a === "A" || a === null) for (let t of e.zoneUp) J(e, t);
				else e.discard.push(...e.zoneUp);
				e.zoneUp = [], Je(e, i, t);
			} else if (a === "C" || a === "D") t && e.zoneUp.length > 0 ? e.pending = {
				kind: "zonePick",
				by: i
			} : (Ke(e, r), Je(e, i, t));
			else {
				for (let t = 0; t < e.zoneUp.length; t += 1) e.reserve.length > 0 && J(e, e.reserve.shift());
				e.discard.push(...e.zoneUp), e.zoneUp = [], t ? e.discard.push(X(e, r)) : J(e, X(e, r)), Je(e, i, t);
			}
			break;
		}
		default: a();
	}
}
function Ge(e) {
	let t = q(e);
	for (let n = 0; n < t && e.reserve.length > 0; n += 1) e.discard.push(e.reserve.shift());
	e.discard.push(...e.zoneUp), e.zoneUp = [], B(e, {
		k: "m7drain",
		n: t
	});
}
function Ke(e, t) {
	e.banished = V(e, [
		...e.banished,
		X(e, t),
		...e.zoneUp
	]), e.zoneUp = [];
}
function qe(e, t, n) {
	if (e.mission !== 13 || !de(e, 31)) return [];
	let r = [];
	for (let i of n) {
		let n = U(e, i);
		e.zoneUp.some((t) => U(e, t) === n) && r.push({
			kind: "rescueMove",
			by: t,
			aux: n
		});
	}
	return r;
}
function Je(e, t, n) {
	if (H(e, 14)) {
		for (let n of e.mats[t]) Y(e, n.id);
		e.mats[t] = [];
	}
	n && de(e, 32) && (e.zoneUp.length > 0 || e.discard.length > 0) && e.queue.push({
		kind: "strikePick",
		by: t
	}), n && de(e, 33) && e.banished.length > 0 && e.queue.push({
		kind: "arrowsPick",
		by: t
	});
}
function X(e, t) {
	return t;
}
function Ye(e, t) {
	return e.hands[t].length === 0 && e.flute.length < 2 && e.soloJesters === 0;
}
function Xe(e) {
	let t = e.players[e.turnIdx];
	return e.players.every((n) => n === t || e.yieldFrom.includes(n));
}
function Ze(e) {
	if (e.phase !== "play" || e.pending || e.jesterBy) return !1;
	let t = e.players[e.turnIdx];
	return !Ye(e, t) || !Xe(e) ? !1 : (e.phase = "done", e.result = "lose", B(e, {
		k: "fallen",
		rid: t
	}), !0);
}
var Qe = [];
for (let e of b) for (let t = 1; t <= 10; t += 1) Qe.push(`${e}${t}`);
function $e(e, t, n) {
	let r = M[e.mission], i = e.mission === 13 ? e.evg : null, a = {
		seed: n,
		rngCursor: 0,
		mission: e.mission,
		evg: i,
		players: t,
		handLimit: ce(t.length) + +!!i?.boons.includes(27),
		solo: t.length === 1,
		soloJesters: t.length === 1 ? 2 : 0,
		mods: {
			corrupted: e.corrupted,
			dual: e.dual,
			apprentice: e.apprentice,
			reborn: e.reborn
		},
		relics: i?.curses.includes(4) ? e.relics.map((e) => e === "motherR" ? "motherC" : e) : e.relics,
		reserve: [],
		discard: [],
		banished: [],
		enemyDeck: [],
		enemyDefs: {},
		shield: 0,
		shieldCorrupt: 0,
		hands: {},
		mats: {},
		turnIdx: 0,
		phase: "play",
		defendNeed: 0,
		defendKind: "enemy",
		defendAccum: 0,
		afterChoice: null,
		jesterBy: null,
		jesterCard: null,
		jesterBoost: !1,
		guardianUp: !1,
		pending: null,
		queue: [],
		combat: null,
		zoneUp: [],
		zoneDown: [],
		zonePiles: null,
		mylaZone: !1,
		flute: [],
		fluteUsedBy: null,
		emblemUsed: !1,
		druidAside: null,
		druidDeal: null,
		yieldFrom: [],
		locked: [],
		flags: {},
		kills: 0,
		result: null,
		log: []
	}, o = 0;
	for (let e of r.groups) {
		let t = e.ordered ? e.enemies : V(a, [...e.enemies]);
		for (let e of t) {
			let t = `e${o}`;
			o += 1;
			let n = [...e.suits];
			r.randomSuits && (n = V(a, [...b]).slice(0, r.randomSuits)), a.enemyDefs[t] = {
				...e,
				suits: n
			}, a.enemyDeck.push({
				eid: t,
				hp: e.hp
			});
		}
	}
	if (e.mission === 10 && e.corrupted.length > 0) {
		a.enemyDefs = {}, a.enemyDeck = [];
		let t = {
			corrupted: [],
			dual: e.dual,
			apprentice: e.apprentice,
			reborn: []
		}, n = [...e.corrupted].sort((e, t) => C(e).value - C(t).value);
		for (let e of n) {
			let n = C(e);
			a.enemyDefs[e] = {
				name: `corrupted${n.value}`,
				atk: n.value,
				hp: n.value * 5,
				suits: O(e, t)
			}, a.enemyDeck.push({
				eid: e,
				hp: n.value * 5
			});
		}
	}
	if (e.mission === 13 && i) {
		a.enemyDefs = {}, a.enemyDeck = [], o = 0;
		let e = (e) => {
			let t = `e${o}`;
			o += 1, a.enemyDefs[t] = e, a.enemyDeck.push({
				eid: t,
				hp: e.hp
			});
		}, t = () => V(a, [...b]).slice(0, 2), n = i.curses.includes(1) ? Array.from({ length: 6 }, () => ({
			name: "hydra",
			atk: 10,
			hp: 20,
			suits: t()
		})) : b.map((e) => ({
			name: "experiment",
			atk: 15,
			hp: 30,
			suits: [e]
		}));
		for (let t of V(a, n)) e(t);
		let r = i.curses.includes(3) ? Array.from({ length: 6 }, () => ({
			name: "wyvern",
			atk: 25,
			hp: 50,
			suits: t()
		})) : b.map((e) => ({
			name: "experiment",
			atk: 20,
			hp: 40,
			suits: [e]
		}));
		for (let t of V(a, r)) e(t);
		if (i.curses.includes(5) && e({
			name: "myla",
			atk: 30,
			hp: 60,
			suits: ["b", "p"],
			hardImmune: ["b", "p"]
		}), i.curses.includes(8) && e({
			name: "arcana",
			atk: 30,
			hp: 60,
			suits: [...b]
		}), i.location === "C") {
			let e = b.map((e) => ({
				name: "experiment",
				atk: 10,
				hp: 20,
				suits: [e]
			}));
			for (let t of V(a, e)) {
				let e = `e${o}`;
				o += 1, a.enemyDefs[e] = t, a.banished.push(e);
			}
		}
		a.flags.enemyTotal = a.enemyDeck.length;
	}
	let s = [...e.party.length > 0 ? e.party : [...Qe], ...e.mercs];
	for (let e = 0; e < R(t.length); e += 1) s.push(`j${e}`);
	if (e.mission >= 8 && e.mission <= 12 && s.push(...z), e.mission === 11 && (s = s.filter((e) => !E(e) || e === "beast-f")), e.mission === 13 && i && (i.boons.includes(25) && s.push("goran"), i.boons.includes(26) && s.push(...b.map((e) => `beast-${e}`)), i.boons.includes(28) && s.push("pg1"), i.boons.includes(29) && s.push("mu3", "fe3", "dr3"), i.curses.includes(6) && (s = s.filter((e) => e !== "beast-f" && e !== "f1")), i.curses.includes(7) && (s = s.filter((e) => ![
		"w10",
		"c10",
		"b10",
		"p10",
		"f10"
	].includes(e)))), s = V(a, s), e.mission === 5 && a.banished.push("myla"), e.mission === 6 && (a.mylaZone = !0), e.mission === 7 && (a.zoneDown = V(a, [...z])), e.mission === 8 && a.zoneUp.push("pg1"), e.mission === 9) {
		let e = [], t = (t, n) => {
			for (let r = s.length - 1; r >= 0 && !(t(s[r]) && (e.push(...s.splice(r, 1)), !n)); --r);
		};
		t((e) => e === "goran" || e === "goran0", !1), t((e) => E(e), !1), t((e) => T(e) || w(e, "merc"), !0);
		let n = [];
		for (let e = 0; e < 3; e += 1) {
			let e = s.splice(0, 10);
			n.push({
				up: e.shift() ?? null,
				down: e
			});
		}
		a.zonePiles = n, s = V(a, [...s, ...e]);
	}
	e.mission === 11 && (a.zoneDown = V(a, b.map((e) => `beast-${e}`))), e.mission === 13 && i?.location === "E" && (a.zoneDown = V(a, [...z])), a.reserve = s;
	for (let e of t) a.hands[e] = a.reserve.splice(0, a.handLimit), a.mats[e] = [];
	return e.mission === 13 && i?.curses.includes(2) && a.discard.push(...a.reserve.splice(0, 30)), B(a, {
		k: "start",
		n: e.mission
	}), Oe(a, []), {
		state: a,
		fx: t.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: a.hands[e].length },
			for: [e],
			secret: { cards: a.hands[e] },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
var et = (e, t, n) => {
	let r = [...e.hands[t]];
	return n.every((e) => {
		let t = r.indexOf(e);
		return t < 0 ? !1 : (r.splice(t, 1), !0);
	});
}, Z = (e, t) => {
	let n = [...e];
	for (let e of t) n.splice(n.indexOf(e), 1);
	return n;
};
function tt(e, t, n) {
	if (e.enemyDefs[t]) return e.enemyDefs[t].atk;
	let r = C(t);
	return r.tags.includes("pair") ? n?.[t] ?? 5 : r.value;
}
function nt(e, t, n) {
	if (e.enemyDefs[t]) return e.enemyDefs[t].suits;
	let r = O(t, ue(e));
	if (r.length > 0) return r;
	let i = n?.[t];
	return i ? [i] : [];
}
function rt(e, t, n) {
	if (t.length === 0 || new Set(t).size !== t.length || t.some((t) => T(t) || e.locked.includes(t))) return !1;
	if (t.length === 1) return !0;
	let r = t.some((t) => pe(e, t)), i = t.some((t) => me(e, t));
	if (r && i) return !1;
	if (t.length === 2) {
		let [n, r] = t;
		if (E(n) !== E(r) && !e.enemyDefs[n] && !e.enemyDefs[r] || G(e, n, "animal") || G(e, r, "animal")) return !0;
	}
	let a = t.map((t) => tt(e, t, n));
	return a.every((e) => e === a[0]) && a.reduce((e, t) => e + t, 0) <= (de(e, 34) ? 12 : 10);
}
function it(e, t, n) {
	if (e.phase === "done") return L("errDone");
	let r = e.players[e.turnIdx];
	if (t.type === "jesterClaim") {
		if (!e.jesterBy || !e.jesterCard) return L("errNoJester");
		let t = e.jesterCard, r = structuredClone(e);
		return r.turnIdx = r.players.indexOf(n.by), r.mats[n.by].push({ id: t }), r.jesterCard = null, r.jesterBy = null, r.jesterBoost = !0, r.yieldFrom = [], B(r, {
			k: "jesterClaim",
			rid: n.by
		}), {
			state: r,
			fx: [{
				kind: "jester",
				rid: n.by
			}]
		};
	}
	if (e.pending) return ft(e, t, n);
	if (n.by !== r && (t.type !== "defend" || e.phase !== "defend" || e.defendKind === "enemy")) return L("errNotYourTurn");
	if (e.jesterBy) return L("errPending");
	if (t.type === "defend") return e.phase === "defend" ? lt(e, t.cards, n) : L("errNotYourTurn");
	if (e.phase !== "play") return L("errNotYourTurn");
	if (t.type === "yield") {
		if (Xe(e)) return L("errYieldBlocked");
		let t = structuredClone(e), r = [{
			kind: "yield",
			rid: n.by
		}];
		return t.yieldFrom.includes(n.by) || t.yieldFrom.push(n.by), B(t, {
			k: "yield",
			rid: n.by
		}), Be(t, r, "enemy"), t.phase === "done" && r.push({
			kind: "fallen",
			rid: n.by
		}), {
			state: t,
			fx: r
		};
	}
	if (t.type === "jester") {
		let t = e.hands[n.by].find((e) => T(e));
		if (t === void 0) return L("errNoJester");
		let r = structuredClone(e);
		return r.hands[n.by] = r.hands[n.by].filter((e) => e !== t), r.jesterCard = t, r.jesterBy = n.by, B(r, {
			k: "jester",
			rid: n.by
		}), {
			state: r,
			fx: [{
				kind: "jester",
				rid: n.by
			}]
		};
	}
	if (t.type === "fluteAdd") {
		if (!e.solo || !e.relics.includes("flute")) return L("errNoRelic");
		if (e.fluteUsedBy === n.by) return L("errFluteUsed");
		if (!e.hands[n.by].includes(t.card)) return L("errBadCards");
		let r = U(e, t.card);
		if (r < 2 || r > 5 || e.flute.length > 0 && U(e, e.flute[0]) !== r) return L("errBadCombo");
		let i = structuredClone(e);
		return i.hands[n.by] = Z(i.hands[n.by], [t.card]), i.flute.push(t.card), i.fluteUsedBy = n.by, B(i, {
			k: "fluteAdd",
			rid: n.by,
			cards: [t.card]
		}), {
			state: i,
			fx: []
		};
	}
	if (t.type === "pilgrimBanish") {
		if (e.mission !== 7 || e.flags.pilgrimUsed) return L("errBadChoice");
		if (!e.zoneUp.includes(t.card) || !G(e, t.card, "pilgrim")) return L("errBadCards");
		let r = U(e, t.card);
		if (!e.mats[n.by].some((t) => (t.asV ?? U(e, t.id)) === r)) return L("errBadCombo");
		let i = structuredClone(e);
		return i.zoneUp = i.zoneUp.filter((e) => e !== t.card), J(i, t.card), i.flags.pilgrimUsed = !0, B(i, {
			k: "pilgrimBanish",
			rid: n.by,
			cards: [t.card]
		}), {
			state: i,
			fx: []
		};
	}
	return t.type === "play" ? st(e, t, n) : L("errBadChoice");
}
function at(e, t, n) {
	if (E(t.id) && !e.enemyDefs[t.id]) {
		let r = n.find((e) => e !== t);
		return r ? r.asV ?? U(e, r.id) : 0;
	}
	return t.asV ?? U(e, t.id);
}
function ot(e) {
	let t = e.combat;
	t && (t.base = t.cards.reduce((n, r) => n + at(e, r, t.cards), 0));
}
function st(e, t, n) {
	let r = structuredClone(e), i = [], a = n.by;
	if (t.cards.length === 0) return !r.solo || r.soloJesters <= 0 || !t.soloJesterSuit ? L("errBadCombo") : (--r.soloJesters, r.combat = {
		base: 8,
		suits: { [t.soloJesterSuit]: !0 },
		reaverBonus: 0,
		cards: []
	}, B(r, {
		k: "soloJester",
		rid: a
	}), r.afterChoice = "attack", De(r, i), r.phase === "done" && r.result === "lose" && i.push({
		kind: "fallen",
		rid: a
	}), {
		state: r,
		fx: i
	});
	if (!et(r, a, t.cards)) return L("errBadCards");
	let o = t.flute ?? [];
	if (o.length > 0) {
		if (!r.solo || !r.relics.includes("flute")) return L("errBadCombo");
		if (!o.every((e) => r.flute.includes(e))) return L("errBadCards");
		if (!rt(r, [...t.cards, ...o], t.asValue)) return L("errBadCombo");
	} else if (!rt(r, t.cards, t.asValue)) return L("errBadCombo");
	r.hands[a] = Z(r.hands[a], t.cards), r.flute = r.flute.filter((e) => !o.includes(e));
	let s = [...t.cards, ...o].map((e) => ({
		id: e,
		asV: t.asValue?.[e],
		asSuit: t.asSuit?.[e]
	}));
	r.mats[a].push(...s), r.yieldFrom = [], r.emblemUsed = !1, r.combat = {
		base: 0,
		suits: {},
		reaverBonus: 0,
		cards: s
	}, ot(r);
	for (let e of s) Ce(r, e.id, nt(r, e.id, t.asSuit), r.jesterBoost);
	r.jesterBoost = !1;
	let c = [];
	for (let e of s) Te(r, e.id, a, c);
	let l = s.length === 1;
	if (r.relics.includes("whistle") && l && (G(r, s[0].id, "animal") || E(s[0].id) && !r.enemyDefs[s[0].id])) {
		if (r.solo) c.push({
			kind: "whistleGive",
			by: a
		});
		else for (let e of r.players) e !== a && c.push({
			kind: "whistleGive",
			by: e
		});
	}
	if (!r.solo && r.relics.includes("flute") && s.every((e) => !G(r, e.id, "animal") && !E(e.id))) for (let e of r.players) e !== a && c.push({
		kind: "fluteGive",
		by: e
	});
	if (!r.solo && r.relics.includes("emblem") && s.some((e) => pe(r, e.id))) {
		r.emblemUsed = !0;
		for (let e of r.players) e !== a && c.push({
			kind: "emblemGive",
			by: e
		});
	}
	return s.some((e) => pe(r, e.id)) && we(r, "f") && c.push({
		kind: "magePick",
		by: a
	}), B(r, {
		k: "play",
		rid: a,
		cards: t.cards
	}), i.push({
		kind: "attack",
		rid: a,
		data: { cards: t.cards }
	}), r.queue = c, r.afterChoice = "attack", Fe(r, i), r.phase === "done" && r.result === "lose" && i.push({
		kind: "fallen",
		rid: a
	}), {
		state: r,
		fx: i
	};
}
function ct(e, t) {
	let n = {}, r = t, i = e.turnIdx;
	for (; r > 0 && e.reserve.length > 0;) {
		let t = e.players[i];
		if (e.hands[t].length < e.handLimit) {
			let i = e.reserve.shift();
			e.hands[t].push(i), (n[t] ??= []).push(i), --r;
		}
		if (i = (i + 1) % e.players.length, i === e.turnIdx && e.players.every((t) => e.hands[t].length >= e.handLimit)) break;
	}
	return n;
}
function lt(e, t, n) {
	let r = e.defendKind === "myla" || e.defendKind === "teamEnd";
	if (!r && n.by !== e.players[e.turnIdx]) return L("errNotYourTurn");
	if (!et(e, n.by, t) || t.some((t) => e.locked.includes(t))) return L("errBadCards");
	let i = t.reduce((t, n) => t + U(e, n), 0);
	if (r) {
		let r = structuredClone(e), a = [{
			kind: "suffer",
			rid: n.by,
			data: { cards: t }
		}];
		if (t.length === 0) return r.players.reduce((e, t) => e + r.hands[t].reduce((e, t) => e + U(r, t), 0), 0) + r.defendAccum >= r.defendNeed ? L("errDefendMore") : (r.phase = "done", r.result = "lose", B(r, {
			k: "fallen",
			rid: n.by
		}), a.push({
			kind: "fallen",
			rid: n.by
		}), {
			state: r,
			fx: a
		});
		if (r.hands[n.by] = Z(r.hands[n.by], t), r.discard.push(...t), r.defendAccum += i, B(r, {
			k: "defend",
			rid: n.by,
			n: t.length
		}), r.defendAccum >= r.defendNeed) {
			r.defendAccum = 0;
			let e = qe(r, n.by, t);
			e.length > 0 ? (r.queue.push(...e), r.afterChoice = "postDefend", De(r, a)) : r.defendKind === "myla" ? Oe(r, a) : ke(r, a);
		}
		return {
			state: r,
			fx: a
		};
	}
	let a = e.hands[n.by], o = t.length === a.length && a.length === e.handLimit;
	if (!o && t.length > 1 && i - Math.max(...t.map((t) => U(e, t))) >= e.defendNeed) return L("errDefendExtra");
	if (!o && i < e.defendNeed) {
		let r = a.reduce((t, n) => t + U(e, n), 0);
		if (a.length === e.handLimit || r >= e.defendNeed) return L("errDefendMore");
		let i = structuredClone(e);
		return i.hands[n.by] = Z(i.hands[n.by], t), i.discard.push(...t), i.phase = "done", i.result = "lose", B(i, {
			k: "defend",
			rid: n.by,
			n: t.length
		}), B(i, {
			k: "fallen",
			rid: n.by
		}), {
			state: i,
			fx: [{
				kind: "suffer",
				rid: n.by,
				data: { cards: t }
			}, {
				kind: "fallen",
				rid: n.by
			}]
		};
	}
	let s = structuredClone(e), c = [{
		kind: "suffer",
		rid: n.by,
		data: { cards: t }
	}];
	s.hands[n.by] = Z(s.hands[n.by], t);
	let l = s.mission === 13 && de(s, 35) && !o && t.length > 0 && i === s.defendNeed && s.defendNeed > 0;
	if (l ? s.reserve.push(...t) : s.discard.push(...t), B(s, {
		k: "defend",
		rid: n.by,
		n: t.length,
		extra: o ? "feign" : void 0
	}), l && s.discard.length > 0) return s.pending = {
		kind: "closeCall",
		by: n.by
	}, s.afterChoice = "postDefend", s.phase = "choice", {
		state: s,
		fx: c
	};
	let u = l ? [] : qe(s, n.by, t);
	return u.length > 0 ? (s.queue.push(...u), s.afterChoice = "postDefend", De(s, c), {
		state: s,
		fx: c
	}) : (s.defendKind === "enemy" ? Ae(s, c) : Oe(s, c), {
		state: s,
		fx: c
	});
}
function ut(e) {
	if ("code" in e) return e;
	let t = e.state;
	return t.enemyDeck.length > 0 && ye(t).includes("p") && t.shield > t.shieldCorrupt && (t.shield = t.shieldCorrupt), e;
}
function dt(e, t, n) {
	return ut(it(e, t, n));
}
function ft(e, t, n) {
	if (e.pending.by !== n.by) return L("errNotYourTurn");
	let r = structuredClone(e), i = [], a = r.pending;
	r.pending = null;
	let o = n.by, s = () => {
		De(r, i), r.phase === "done" && r.result === "lose" && i.push({
			kind: "fallen",
			rid: o
		});
	};
	switch (a.kind) {
		case "magePick": {
			if (t.type !== "magePick" || !a.revealed?.includes(t.card)) return L("errBadChoice");
			let e = r.reserve.indexOf(t.card);
			e >= 0 && r.reserve.splice(e, 1);
			let n = (a.revealed ?? []).filter((e) => e !== t.card);
			if (r.mats[o].push({
				id: t.card,
				tucked: !0
			}), r.combat?.cards.push({
				id: t.card,
				tucked: !0
			}), ot(r), Ce(r, t.card, W(r, t.card), r.jesterBoost), Te(r, t.card, o, r.queue), r.solo && r.relics.includes("emblem") && n.length > 0) r.queue.unshift({
				kind: "emblemReturn",
				by: o,
				revealed: n
			});
			else for (let e of n) {
				let t = r.reserve.indexOf(e);
				t >= 0 && r.reserve.splice(t, 1), r.discard.push(e);
			}
			return pe(r, t.card) && r.reserve.length > 0 && r.queue.unshift({
				kind: "magePick",
				by: o,
				aux: U(r, t.card)
			}), B(r, {
				k: "magePick",
				rid: o,
				cards: [t.card]
			}), s(), {
				state: r,
				fx: i
			};
		}
		case "emblemReturn": {
			if (t.type !== "emblemReturn") return L("errBadChoice");
			let e = a.revealed ?? [];
			if (t.card !== void 0) {
				if (!e.includes(t.card)) return L("errBadChoice");
				let n = r.reserve.indexOf(t.card);
				n >= 0 && r.reserve.splice(n, 1), r.reserve.unshift(t.card);
			}
			for (let n of e) {
				if (n === t.card) continue;
				let e = r.reserve.indexOf(n);
				e >= 0 && r.reserve.splice(e, 1), r.discard.push(n);
			}
			return s(), {
				state: r,
				fx: i
			};
		}
		case "reaverCount": {
			if (t.type !== "reaverCount") return L("errBadChoice");
			let e = Math.min(Math.max(1, t.count), r.reserve.length);
			return r.queue.unshift({
				kind: "reaverPick",
				by: o,
				revealed: r.reserve.slice(0, e)
			}), s(), {
				state: r,
				fx: i
			};
		}
		case "reaverPick":
			if (t.type !== "reaverPick" || !a.revealed?.includes(t.card)) return L("errBadChoice");
			r.combat && (r.combat.reaverBonus += U(r, t.card));
			for (let e of a.revealed) {
				let t = r.reserve.indexOf(e);
				t >= 0 && r.reserve.splice(t, 1), J(r, e);
			}
			return B(r, {
				k: "reaverPick",
				rid: o,
				cards: [t.card]
			}), s(), {
				state: r,
				fx: i
			};
		case "whistleGive":
			if (t.type !== "whistleGive") return L("errBadChoice");
			if (t.card === void 0) return s(), {
				state: r,
				fx: i
			};
			if (r.solo) {
				let e = r.discard[r.discard.length - 1];
				if (t.card !== e) return L("errBadChoice");
				r.discard.pop(), r.mats[o].push({ id: t.card }), r.combat?.cards.push({ id: t.card }), ot(r), Ce(r, t.card, W(r, t.card), r.jesterBoost), Te(r, t.card, o, r.queue);
			} else {
				if (a.by !== o && r.players[r.turnIdx] === a.by) return L("errBadChoice");
				if (!et(r, a.by, [t.card]) || T(t.card)) return L("errBadCards");
				r.hands[a.by] = Z(r.hands[a.by], [t.card]), r.mats[r.players[r.turnIdx]].push({
					id: t.card,
					asV: t.asValue,
					asSuit: t.asSuit
				}), r.combat?.cards.push({
					id: t.card,
					asV: t.asValue,
					asSuit: t.asSuit
				}), ot(r), Ce(r, t.card, t.asSuit ? [t.asSuit] : W(r, t.card), r.jesterBoost), Te(r, t.card, r.players[r.turnIdx], r.queue);
			}
			return r.flags.whistleFilled = !0, B(r, {
				k: "whistlePick",
				rid: a.by,
				cards: [t.card]
			}), s(), {
				state: r,
				fx: i
			};
		case "fluteGive": {
			if (t.type !== "fluteGive") return L("errBadChoice");
			if (t.cards.length === 0) return s(), {
				state: r,
				fx: i
			};
			let e = r.combat;
			if (!e) return L("errBadChoice");
			let n = at(r, e.cards[0], e.cards);
			if (!et(r, a.by, t.cards) || t.cards.some((e) => T(e) || w(e, "animal") || E(e)) || t.cards.some((e) => (t.asValue?.[e] ?? U(r, e)) !== n) || e.cards.reduce((t, n) => t + at(r, n, e.cards), 0) + t.cards.reduce((e, n) => e + (t.asValue?.[n] ?? U(r, n)), 0) > 10) return L("errBadCombo");
			r.hands[a.by] = Z(r.hands[a.by], t.cards);
			for (let n of t.cards) {
				let i = {
					id: n,
					asV: t.asValue?.[n],
					asSuit: t.asSuit?.[n]
				};
				r.mats[r.players[r.turnIdx]].push(i), e.cards.push(i), Ce(r, n, t.asSuit?.[n] ? [t.asSuit[n]] : W(r, n), r.jesterBoost), Te(r, n, r.players[r.turnIdx], r.queue);
			}
			return ot(r), B(r, {
				k: "fluteGive",
				rid: a.by,
				cards: t.cards
			}), s(), {
				state: r,
				fx: i
			};
		}
		case "emblemGive":
			if (t.type !== "emblemGive") return L("errBadChoice");
			if (t.card !== void 0) {
				if (!et(r, a.by, [t.card])) return L("errBadCards");
				r.hands[a.by] = Z(r.hands[a.by], [t.card]), r.reserve.unshift(t.card), B(r, {
					k: "emblemGive",
					rid: a.by,
					cards: [t.card]
				});
			}
			return s(), {
				state: r,
				fx: i
			};
		case "motherGive": return t.type !== "motherGive" || !et(r, a.by, [t.card]) ? L("errBadCards") : (r.hands[a.by] = Z(r.hands[a.by], [t.card]), J(r, t.card), B(r, {
			k: "motherPeek",
			rid: a.by,
			cards: [t.card]
		}), s(), {
			state: r,
			fx: i
		});
		case "motherSolo": return t.type === "motherSolo" ? (t.useDiscard && r.discard.length > 0 ? J(r, r.discard.pop()) : r.reserve.length > 0 && J(r, r.reserve.shift()), B(r, {
			k: "motherPeek",
			rid: o
		}), s(), {
			state: r,
			fx: i
		}) : L("errBadChoice");
		case "druidAssign": {
			if (t.type !== "druidAssign") return L("errBadChoice");
			let e = r.druidDeal?.[a.by] ?? [], n = [
				t.hand,
				t.banish,
				t.top,
				t.bottom
			].filter((e) => e !== void 0);
			if (new Set(n).size !== n.length || !n.every((t) => e.includes(t))) return L("errBadChoice");
			if (t.hand && (r.hands[a.by].push(t.hand), r.mission === 7 && w(t.hand, "pilgrim") && r.locked.push(t.hand)), t.banish && J(r, t.banish), t.top && r.reserve.unshift(t.top), t.bottom && r.reserve.push(t.bottom), r.druidDeal[a.by] = e.filter((e) => !n.includes(e)), B(r, {
				k: "druidAssign",
				rid: a.by,
				n: n.length
			}), !r.queue.some((e) => e.kind === "druidAssign")) {
				r.discard = V(r, Object.values(r.druidDeal ?? {}).flat());
				for (let e of r.players) r.hands[e] = [...r.druidAside?.[e] ?? [], ...r.hands[e]];
				r.druidDeal = null, r.druidAside = null;
			}
			return s(), {
				state: r,
				fx: i
			};
		}
		case "chanterDraw":
			if (t.type !== "chanterDraw") return L("errBadChoice");
			for (let e = 0; e < r.players.length; e += 1) {
				let n = r.players[(r.turnIdx + e) % r.players.length], a = r.reserve.splice(0, Math.min(t.count, r.reserve.length));
				r.hands[n].push(...a), a.length > 0 && i.push({
					kind: "draw",
					rid: n,
					data: { count: a.length },
					for: [n],
					secret: { cards: a },
					with: !0
				}), r.hands[n].length > r.handLimit && r.queue.push({
					kind: "discardDown",
					by: n,
					aux: r.handLimit
				});
			}
			return B(r, {
				k: "chanterDraw",
				rid: o,
				n: t.count
			}), s(), {
				state: r,
				fx: i
			};
		case "discardDown": {
			if (t.type !== "discardDown") return L("errBadChoice");
			let e = Number(a.aux) || r.handLimit;
			return et(r, o, t.cards) ? r.hands[o].length - t.cards.length === e ? (r.hands[o] = Z(r.hands[o], t.cards), r.discard.push(...t.cards), B(r, {
				k: "discardDown",
				rid: o,
				n: t.cards.length
			}), s(), {
				state: r,
				fx: i
			}) : L("errBadCombo") : L("errBadCards");
		}
		case "bardTake": return t.type !== "bardTake" || !et(r, o, [t.card]) ? L("errBadCards") : (r.hands[o] = Z(r.hands[o], [t.card]), a.aux === "discard" ? r.discard.push(t.card) : Y(r, t.card), B(r, {
			k: "bardTake",
			rid: o,
			cards: [t.card]
		}), s(), {
			state: r,
			fx: i
		});
		case "mylaPick": {
			if (t.type !== "mylaPick") return L("errBadChoice");
			let e = r.players.find((e) => r.mats[e].some((e) => e.id === t.card));
			if (!e) return L("errBadCards");
			let n = r.mats[e], [a] = n.splice(n.findIndex((e) => e.id === t.card), 1);
			if (pe(r, a.id) || a.tucked) {
				let t = n.filter((e) => e.tucked || pe(r, e.id));
				r.mats[e] = n.filter((e) => !t.includes(e));
				for (let e of t) J(r, e.id);
			}
			return Y(r, a.id), B(r, {
				k: "myla",
				rid: o,
				cards: [a.id]
			}), s(), {
				state: r,
				fx: i
			};
		}
		case "rescue":
			if (t.type !== "rescue") return L("errBadChoice");
			if (t.banishCard && t.zoneCard) {
				if (!et(r, o, [t.banishCard])) return L("errBadCards");
				let e = r.zonePiles?.find((e) => e.up === t.zoneCard);
				if (!e) return L("errBadCards");
				r.hands[o] = Z(r.hands[o], [t.banishCard]), J(r, t.banishCard), e.up = e.down.shift() ?? null, r.discard.push(t.zoneCard), B(r, {
					k: "rescue",
					rid: o,
					cards: [t.banishCard, t.zoneCard]
				});
			} else Pe(r), B(r, {
				k: "rotate",
				rid: o
			});
			return s(), {
				state: r,
				fx: i
			};
		case "zonePick":
			if (t.type !== "zonePick") return L("errBadChoice");
			if (r.mission === 3) {
				if (t.card !== void 0) {
					if (!r.zoneUp.includes(t.card)) return L("errBadCards");
					r.zoneUp = r.zoneUp.filter((e) => e !== t.card), r.discard.push(t.card);
				}
				let e = r.flags.fallenEid;
				typeof e == "string" && J(r, e);
				for (let e of r.zoneUp) J(r, e);
				r.zoneUp = [];
			} else if (r.mission === 6) {
				if (t.card !== void 0) {
					if (!r.zoneUp.includes(t.card) || t.card === "myla") return L("errBadCards");
					r.zoneUp = r.zoneUp.filter((e) => e !== t.card), r.discard.push(t.card);
				}
			} else if (r.mission === 7) {
				if (t.card !== void 0) {
					if (!r.zoneUp.includes(t.card)) return L("errBadCards");
					r.zoneUp = r.zoneUp.filter((e) => e !== t.card), J(r, t.card);
				}
				Ge(r);
			} else if (r.mission === 9) {
				if (t.card !== void 0) {
					let e = r.zonePiles?.find((e) => e.up === t.card);
					if (!e) return L("errBadCards");
					e.up = e.down.shift() ?? null, r.reserve.unshift(t.card), B(r, {
						k: "rescueTop",
						rid: o,
						cards: [t.card]
					});
				}
			} else if (r.mission === 13) {
				if (t.card !== void 0) {
					if (!r.zoneUp.includes(t.card)) return L("errBadCards");
					r.zoneUp = r.zoneUp.filter((e) => e !== t.card), r.discard.push(t.card);
				}
				let e = r.flags.fallenEid;
				typeof e == "string" && Ke(r, e), Je(r, o, r.flags.fallenExact === !0);
			} else return L("errBadChoice");
			return s(), {
				state: r,
				fx: i
			};
		case "chainMove":
			if (t.type !== "chainMove") return L("errBadChoice");
			if (t.cards.length > 0) {
				let e = r.mats[o];
				if (!t.cards.every((t) => e.some((e) => e.id === t))) return L("errBadCards");
				let n = t.cards.map((e) => U(r, e)).sort((e, t) => e - t), i = Math.max(0, ...r.zoneUp.map((e) => U(r, e))) + 1;
				for (let e of n) {
					if (e !== i) return L("errBadCombo");
					i += 1;
				}
				for (let e of t.cards) r.mats[o] = r.mats[o].filter((t) => t.id !== e), Y(r, e);
				B(r, {
					k: "chainMove",
					rid: o,
					cards: t.cards
				}), n.includes(10) && (r.discard.push(...r.zoneUp), r.zoneUp = [], r.discard.length > 0 && r.queue.unshift({
					kind: "cull",
					by: o
				}));
			}
			return s(), {
				state: r,
				fx: i
			};
		case "cull":
			if (t.type !== "cull") return L("errBadChoice");
			if (!t.cards.every((e) => r.discard.includes(e))) return L("errBadCards");
			for (let e of t.cards) r.discard = r.discard.filter((t) => t !== e), J(r, e);
			return r.reserve.push(...V(r, r.discard)), r.discard = [], r.flags.zoneSealed = !0, B(r, {
				k: "cull",
				rid: o,
				n: t.cards.length
			}), s(), {
				state: r,
				fx: i
			};
		case "discardPick": return t.type !== "discardPick" || !r.discard.includes(t.card) ? L("errBadCards") : (r.discard = r.discard.filter((e) => e !== t.card), r.reserve.unshift(t.card), B(r, {
			k: "discardPick",
			rid: o,
			cards: [t.card]
		}), s(), {
			state: r,
			fx: i
		});
		case "squadMove":
			if (t.type !== "evgPick") return L("errBadChoice");
			if (t.card !== void 0) {
				let e = String(a.aux).split(",").map(Number);
				if (!r.zoneUp.includes(t.card) || !e.includes(U(r, t.card))) return L("errBadCards");
				r.zoneUp = r.zoneUp.filter((e) => e !== t.card), r.discard.push(t.card);
			}
			return B(r, {
				k: "squadMove",
				rid: o,
				cards: t.card ? [t.card] : []
			}), s(), {
				state: r,
				fx: i
			};
		case "rescueMove":
			if (t.type !== "evgPick") return L("errBadChoice");
			if (t.card !== void 0) {
				if (!r.zoneUp.includes(t.card) || U(r, t.card) !== Number(a.aux)) return L("errBadCards");
				r.zoneUp = r.zoneUp.filter((e) => e !== t.card), r.discard.push(t.card);
			}
			return B(r, {
				k: "rescueMove",
				rid: o,
				cards: t.card ? [t.card] : []
			}), s(), {
				state: r,
				fx: i
			};
		case "strikePick":
			if (t.type !== "evgPick") return L("errBadChoice");
			if (t.card !== void 0) {
				if (r.zoneUp.includes(t.card)) r.zoneUp = r.zoneUp.filter((e) => e !== t.card), r.hands[o].push(t.card);
				else if (r.discard[r.discard.length - 1] === t.card) r.discard.pop(), r.hands[o].push(t.card);
				else return L("errBadCards");
				B(r, {
					k: "strikePick",
					rid: o,
					cards: [t.card]
				});
			}
			return s(), {
				state: r,
				fx: i
			};
		case "arrowsPick":
			if (t.type !== "evgPick") return L("errBadChoice");
			if (t.card !== void 0) {
				if (!r.banished.includes(t.card)) return L("errBadCards");
				r.banished = r.banished.filter((e) => e !== t.card), r.reserve.push(t.card), B(r, {
					k: "arrowsPick",
					rid: o,
					cards: [t.card]
				});
			}
			return s(), {
				state: r,
				fx: i
			};
		case "closeCall": return t.type !== "evgPick" || t.card === void 0 || !r.discard.includes(t.card) ? L("errBadCards") : (r.discard = r.discard.filter((e) => e !== t.card), r.reserve.unshift(t.card), B(r, {
			k: "closeCall",
			rid: o,
			cards: [t.card]
		}), s(), {
			state: r,
			fx: i
		});
		case "poisonPick":
			if (t.type !== "evgPick") return L("errBadChoice");
			if (t.card !== void 0) {
				if (!et(r, o, [t.card])) return L("errBadCards");
				r.hands[o] = Z(r.hands[o], [t.card]), r.discard.push(t.card);
			} else r.reserve.length > 0 && (Y(r, r.reserve.shift()), B(r, {
				k: "zoneFlip",
				n: 1
			}));
			return B(r, {
				k: "poisonPick",
				rid: o,
				cards: t.card ? [t.card] : []
			}), s(), {
				state: r,
				fx: i
			};
		default: return L("errBadChoice");
	}
}
function pt(e, t) {
	let n = e, r = n.players[n.turnIdx], i = n.phase === "done" || n.enemyDeck.length === 0 ? null : ge(n), a = i ? n.enemyDefs[i.eid] : null;
	return {
		public: {
			mission: n.mission,
			phase: n.phase,
			turn: r,
			handLimit: n.handLimit,
			enemy: i && a ? {
				eid: i.eid,
				name: `games.regicidelegacy.enemy.${a.name}`,
				atk: a.atk,
				hp: i.hp,
				maxHp: a.hp,
				suits: a.suits,
				shield: n.shield,
				effectiveAtk: xe(n),
				effectiveImmune: ye(n)
			} : null,
			enemyLeft: n.enemyDeck.length,
			enemyTotal: typeof n.flags.enemyTotal == "number" ? n.flags.enemyTotal : Object.keys(n.enemyDefs).length,
			reserveCount: n.reserve.length,
			discard: [...n.discard],
			banish: [...n.banished],
			zoneFaceup: [...n.zoneUp],
			zoneFacedownCount: n.zoneDown.length,
			zonePiles: n.zonePiles ? n.zonePiles.map((e) => ({
				top: e.up,
				count: e.down.length
			})) : void 0,
			players: n.players.map((e) => ({
				rid: e,
				handCount: n.hands[e]?.length ?? 0,
				mat: n.mats[e].map((e) => ({
					id: e.id,
					v: e.asV,
					suit: e.asSuit,
					tucked: e.tucked
				}))
			})),
			flute: [...n.flute],
			fluteUsedBy: n.fluteUsedBy,
			relics: [...n.relics],
			emblemUsed: n.emblemUsed,
			defendNeed: n.phase === "defend" ? n.defendNeed - n.defendAccum : null,
			defendKind: n.phase === "defend" ? n.defendKind : null,
			feignOk: n.phase === "defend" && n.defendKind === "enemy" && (n.hands[t]?.length ?? 0) === n.handLimit,
			yieldBlocked: n.phase === "play" && Xe(n),
			pending: n.pending ? {
				kind: n.pending.kind,
				by: n.pending.by,
				revealed: n.pending.revealed ? [...n.pending.revealed] : void 0
			} : null,
			jesterOut: n.jesterBy,
			result: n.result,
			kills: n.kills,
			corrupted: [...n.mods.corrupted],
			dual: { ...n.mods.dual },
			apprentice: n.mods.apprentice,
			enemyBook: Object.fromEntries(Object.entries(n.enemyDefs).filter(([e]) => n.mission === 10 || !n.enemyDeck.some((t) => t.eid === e)).map(([e, t]) => [e, {
				name: `games.regicidelegacy.enemy.${t.name}`,
				atk: t.atk,
				suits: [...t.suits]
			}])),
			soloJesters: n.solo ? n.soloJesters : void 0,
			reborn: [...n.mods.reborn],
			evg: n.evg ? {
				location: n.evg.location,
				curses: [...n.evg.curses],
				boons: [...n.evg.boons]
			} : null,
			log: n.log.map((e) => ({ ...e }))
		},
		private: { hand: [...n.hands[t] ?? []] }
	};
}
function mt(e) {
	return e.phase === "done" ? {
		phase: "done",
		winner: e.result === "win" ? [...e.players] : [],
		ranking: [...e.players],
		scores: Object.fromEntries(e.players.map((t) => [t, e.kills]))
	} : { phase: e.phase };
}
var ht = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: A,
	schemas: {
		action: ie,
		publicView: oe,
		privateView: se,
		config: re
	},
	setup: $e,
	reduce: dt,
	viewFor: pt,
	status: mt
}, gt = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%3e%3cdefs%3e%3cpattern%20id='paper-grain'%20width='40'%20height='40'%20patternUnits='userSpaceOnUse'%3e%3ccircle%20cx='3'%20cy='9'%20r='.65'%20fill='%23765b41'%20opacity='.13'/%3e%3ccircle%20cx='26'%20cy='31'%20r='.5'%20fill='%23765b41'%20opacity='.12'/%3e%3cpath%20d='M17%2017h3M33%204h2'%20stroke='%23fff'%20stroke-opacity='.4'/%3e%3c/pattern%3e%3cpattern%20id='back-lines'%20width='24'%20height='24'%20patternUnits='userSpaceOnUse'%20patternTransform='rotate(30)'%3e%3cpath%20d='M0%200v24'%20stroke='%23f4e1b7'%20stroke-opacity='.13'%20stroke-width='2'/%3e%3c/pattern%3e%3csymbol%20id='crown'%20viewBox='0%200%2070%2050'%3e%3cpath%20d='M8%2035%203%2010l17%2010L33%203l11%2017%2022-10-6%2025ZM8%2035h52v11H8Z'%20fill='currentColor'%20stroke='%23302739'%20stroke-width='3'%20stroke-linejoin='round'/%3e%3cpath%20d='m35%205-6%2014%209%206-6%2010'%20fill='none'%20stroke='%23302739'%20stroke-width='2'/%3e%3cpath%20d='m35%2025%205%205-5%205-5-5Z'%20fill='%23b95652'/%3e%3c/symbol%3e%3csymbol%20id='suit-w'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='m9%2028%2012-24M8%209l12%206M16%204q11-4%2014%207l-8%206-2-8-8%204Z'%20fill='currentColor'%20stroke='currentColor'%20stroke-width='2'%20stroke-linejoin='round'/%3e%3cpath%20d='m8%2028%204%202'%20stroke='currentColor'%20stroke-width='3'/%3e%3c/symbol%3e%3csymbol%20id='suit-p'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='m16%202%2012%205-1%2013q-3%207-11%2011Q5%2026%204%2020L3%207Z'%20fill='currentColor'/%3e%3cpath%20d='m16%207%207%203-1%209q-1%204-6%207Z'%20fill='%23fffaf0'%20opacity='.65'/%3e%3cpath%20d='M16%207v19'%20stroke='%23fffaf0'%20stroke-width='1.5'/%3e%3c/symbol%3e%3csymbol%20id='suit-c'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='M11%203h10v4h-2v6l8%2010q4%207-4%207H9q-8%200-4-7l8-10V7h-2Z'%20fill='currentColor'/%3e%3cpath%20d='M9%2022h15M16%2016v10m-4-5h8'%20fill='none'%20stroke='%23fffaf0'%20stroke-width='2'/%3e%3ccircle%20cx='21'%20cy='24'%20r='1.5'%20fill='%23fffaf0'/%3e%3c/symbol%3e%3csymbol%20id='suit-b'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='m23%202%205%203-9%2015q5%209-3%2011Q2%2034%203%2023q0-8%2010-8Z'%20fill='currentColor'/%3e%3cellipse%20cx='12'%20cy='23'%20rx='4'%20ry='5'%20fill='%23fffaf0'%20opacity='.6'/%3e%3cpath%20d='m12%2023%2014-19'%20stroke='%23fffaf0'%20stroke-width='1.5'/%3e%3c/symbol%3e%3csymbol%20id='suit-f'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='M16%201q3%2010%209%2013Q37%2030%2017%2032-3%2031%206%2015q0%208%205%206Q19%2015%2016%201Z'%20fill='currentColor'/%3e%3cpath%20d='M17%2016q12%2012%200%2013-9-2%200-13Z'%20fill='%23fffaf0'%20opacity='.75'/%3e%3c/symbol%3e%3csymbol%20id='suit-j'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='M6%2024Q3%207%202%205q9%200%2014%2012Q18%202%2030%205L25%2024Z'%20fill='currentColor'/%3e%3cpath%20d='M6%2025h19v5H6Z'%20fill='currentColor'/%3e%3ccircle%20cx='2'%20cy='4'%20r='2'%20fill='currentColor'/%3e%3ccircle%20cx='30'%20cy='4'%20r='2'%20fill='currentColor'/%3e%3c/symbol%3e%3csymbol%20id='suit-fe'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='M29%202Q7%200%203%2023l5%205Q31%2020%2029%202Z'%20fill='currentColor'/%3e%3cpath%20d='M3%2031%2025%207M9%2022l10%201M15%2015l1-7'%20fill='none'%20stroke='%23fffaf0'%20stroke-width='2'/%3e%3c/symbol%3e%3csymbol%20id='suit-ev'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='M15%2031V13M15%2023Q0%2022%201%207q16-1%2014%2016ZM16%2017Q14%201%2031%201q1%2016-15%2016Z'%20fill='currentColor'/%3e%3cpath%20d='m5%2011%2010%2012M27%205%2016%2016'%20stroke='%23fffaf0'%20stroke-width='1.5'/%3e%3c/symbol%3e%3csymbol%20id='suit-ro'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='M3%2024%206%2010l9-7%2012%208%204%2015-10%205Z'%20fill='currentColor'/%3e%3cpath%20d='m7%2011%2010%205%209-4M17%2016l-4%2013'%20stroke='%23fffaf0'%20fill='none'%20stroke-width='1.5'/%3e%3c/symbol%3e%3csymbol%20id='suit-mu'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='M12%2016h8l4%2014H8ZM1%2016Q1%200%2016%201q15%200%2015%2015Z'%20fill='currentColor'/%3e%3ccircle%20cx='10'%20cy='10'%20r='2'%20fill='%23fffaf0'/%3e%3ccircle%20cx='21'%20cy='7'%20r='2'%20fill='%23fffaf0'/%3e%3ccircle%20cx='25'%20cy='13'%20r='1.5'%20fill='%23fffaf0'/%3e%3c/symbol%3e%3csymbol%20id='suit-dr'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='M4%2010h24v16Q16%2034%204%2026Z'%20fill='currentColor'/%3e%3cellipse%20cx='16'%20cy='10'%20rx='12'%20ry='5'%20fill='%23fffaf0'%20stroke='currentColor'%20stroke-width='2'/%3e%3cpath%20d='m3%200%2014%2010M27%200%2015%2010M8%2014l5%2013%207-13%204%2013'%20fill='none'%20stroke='currentColor'%20stroke-width='2'/%3e%3c/symbol%3e%3csymbol%20id='tree'%20viewBox='0%200%2040%2065'%3e%3cpath%20d='M19%2044h4v21h-4Z'%20fill='%23638b78'/%3e%3cpath%20d='M21%200%205%2026h8L0%2046h40L27%2026h9Z'%20fill='%23548776'/%3e%3cpath%20d='M21%200v46h19L27%2026h9Z'%20fill='%2335695f'%20opacity='.5'/%3e%3c/symbol%3e%3csymbol%20id='warrior'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='m24%20186%2012-76%2075-4%2026%2080-20%2017-17-51-15%2013-16%2036-31%203Z'%20fill='%2339434b'/%3e%3cpath%20d='m40%20177-5%2025-19%205%202%203h48l3-24m31-11%2010%2028%2027%204%202%203H99l-9-24'%20fill='%23423731'%20stroke='%23302739'%20stroke-width='2'/%3e%3cpath%20d='m44%2080-18%2018-8%2045%2016%2012%2017-41%2050-1%2015%2039%2017-7-14-47-20-18Z'%20fill='%23ac533a'%20stroke='%23563b37'%20stroke-width='1.5'/%3e%3cpath%20d='m42%2079%2022-10h30l18%2011-7%2066-65%201Z'%20fill='%23d38543'/%3e%3cpath%20d='m43%2081%2019%2023%2038-25%2010%207-10%2055-50%204Z'%20fill='%23bb6640'/%3e%3cpath%20d='m29%20104-7%2028%2011%206%2016-34m67-1%2012%2027-11%206-14-31'%20fill='%23d39e79'/%3e%3cpath%20d='M43%20130h64l-2%2015H41Z'%20fill='%23574139'/%3e%3cpath%20d='M71%20128h15v18H71Z'%20fill='%23e9c875'/%3e%3cpath%20d='M75%20133h7v8h-7Z'%20fill='%2367493d'/%3e%3cpath%20d='m50%20143%2018%2030%2012-16%2016%2017%209-31'%20fill='%23a55a3a'/%3e%3cpath%20d='M49%2045%2037%2040l8%2022%2012-1m49-17%2014-6-8%2024-10-2'%20fill='%23c99577'/%3e%3cpath%20d='M49%2039q30-25%2056%200l-4%2037-17%2012-29-12Z'%20fill='%23dfb18b'/%3e%3cpath%20d='M46%2052q-14-26%2016-30%2035-8%2044%2017l-4%2018-10-23-12%2010-19-3-8%2017Z'%20fill='%23e2dbbd'/%3e%3cpath%20d='m52%2060%2010%207%2018-5%2021%200-7%2029-15%2014-18-13Z'%20fill='%23d8d4be'/%3e%3cpath%20d='m55%2065%2010%207%2015-6%2017%200-9%2013-14-2-14%203'%20fill='%23f5ebcf'/%3e%3cpath%20d='m58%2053%209-3m20%201%208%203'%20fill='none'%20stroke='%235a4038'%20stroke-width='3'/%3e%3ccircle%20cx='64'%20cy='57'%20r='2'%20fill='%23302739'/%3e%3ccircle%20cx='90'%20cy='57'%20r='2'%20fill='%23302739'/%3e%3cpath%20d='m74%2055-5%2010%2012%201'%20fill='%23bd886b'/%3e%3cpath%20d='M130%2022%20111%20165'%20stroke='%23665145'%20stroke-width='8'/%3e%3cpath%20d='m118%2034-16-14%204-12q18%203%2025%2012l13-4%208%2034-18-4-7-14Z'%20fill='%23a0b5b0'%20stroke='%234c5757'%20stroke-width='2'/%3e%3cpath%20d='m144%2016%208%2034-11-3-6-27'%20fill='%23e0e9d9'/%3e%3cpath%20d='m115%20126%2015%201-1%2014-14%201Z'%20fill='%23d6a581'%20stroke='%2384644d'%20stroke-width='1'/%3e%3c/symbol%3e%3csymbol%20id='paladin'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='m45%2079-22%20116%2047-11%2019%209%2046-3-26-111Z'%20fill='%23326a68'/%3e%3cpath%20d='m99%2083%2020%20103-30%207-13-39Z'%20fill='%23235255'/%3e%3cpath%20d='m53%20150-8%2048-15%208%201%204h41l8-57m11%202%206%2042%2017%208v5H82l-5-56'%20fill='%234c4e51'%20stroke='%23302739'%20stroke-width='2'/%3e%3cpath%20d='m53%2078-16%2020%208%2056%2056%205%2018-56-17-23Z'%20fill='%23b8c6b9'%20stroke='%23536767'%20stroke-width='2'/%3e%3cpath%20d='m65%2083%2014%2014%2014-14%207%2042-19%2022-27-24Z'%20fill='%23e0dfc7'/%3e%3cpath%20d='M76%2088v56m-20-25%2043%201'%20stroke='%23a58a4f'%20stroke-width='3'/%3e%3cpath%20d='m57%2042%2043-2-2%2029-19%2016-24-16Z'%20fill='%23d7ad8c'/%3e%3cpath%20d='M52%2045q1-27%2027-27%2025%200%2027%2029l-9%2018-4-24-32%203-4%2020Z'%20fill='%23a7b7b1'%20stroke='%23536767'%20stroke-width='2'/%3e%3cpath%20d='m79%2017%201%2037%2017-7-4-20Z'%20fill='%23e4e4cf'/%3e%3cpath%20d='m57%2050%2016-4%205%206%206-6%2015%204-7%2015-12%207-15-8Z'%20fill='%2336525a'/%3e%3cpath%20d='M60%2063q17%209%2036%200l-4%2017-12%2011-16-11Z'%20fill='%23efebd5'/%3e%3cpath%20d='m66%2058%208%201m10%200h7'%20stroke='%23fbf6db'%20stroke-width='2'/%3e%3cpath%20d='M121%2028v155'%20stroke='%237d6749'%20stroke-width='6'/%3e%3cpath%20d='m121%207%2010%2022-10%2012-10-12Z'%20fill='%23d3b370'%20stroke='%23826d4e'%20stroke-width='2'/%3e%3cpath%20d='M114%2041h14'%20stroke='%23dcc47b'%20stroke-width='4'/%3e%3cpath%20d='m110%20111%2017-2-1%2014-16%203Z'%20fill='%23d7ad8c'/%3e%3cpath%20d='m24%20101%2039-8%2023%2012-5%2048q-8%2020-27%2032-30-19-32-44Z'%20fill='%23c7a45e'%20stroke='%234d5550'%20stroke-width='3'/%3e%3cpath%20d='m30%20107%2032-6%2016%2010-4%2039q-6%2016-20%2027-23-16-25-38Z'%20fill='%23477d77'/%3e%3cpath%20d='m55%20103%201%2072m-26-46%2046-1'%20stroke='%23e2c784'%20stroke-width='3'/%3e%3cpath%20d='m56%20116%209%2013-9%2014-9-14Z'%20fill='%23f0dfae'/%3e%3c/symbol%3e%3csymbol%20id='cleric'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='M52%2072%2031%20191l48%2016%2046-15-23-121Z'%20fill='%239b4f49'/%3e%3cpath%20d='m70%2083-13%20119%2024%205%2019-10-13-111'%20fill='%23e9ddc1'/%3e%3cpath%20d='m48%2083-20%2035%207%2020%2027-32m37-23%2024%2033-9%2022-28-36'%20fill='%23c57d68'/%3e%3cpath%20d='m35%20122%2014-3%2015%2018-7%2011-15-7Zm65%2012%2012-14%2012%206-10%2021Z'%20fill='%23dfb28e'/%3e%3cpath%20d='m58%20188-6%2016-17%203v3h37l5-17m10-2%207%2013%2018%203v3H79l1-15'%20fill='%234a3b3b'/%3e%3cpath%20d='M53%2047q-5-30%2026-30%2028-1%2029%2028l-5%2047-22-12-28%2012Z'%20fill='%23633e38'/%3e%3cpath%20d='m60%2039%2036-2%202%2029-17%2017-18-12Z'%20fill='%23e7ba98'/%3e%3cpath%20d='m58%2042%209-18%2021%203%2012%2011-22-2-11%2013Z'%20fill='%23774b3b'/%3e%3cpath%20d='m65%2054%208-1m11%200%209%201'%20stroke='%2368443e'%20stroke-width='2'/%3e%3ccircle%20cx='70'%20cy='57'%20r='1.5'%20fill='%23302739'/%3e%3ccircle%20cx='88'%20cy='57'%20r='1.5'%20fill='%23302739'/%3e%3cpath%20d='m75%2070%209%201'%20stroke='%23ad6b60'%20stroke-width='2'/%3e%3cpath%20d='m58%2077%2021%2018%2022-18-11%2042-12-15-12%2015Z'%20fill='%23cad1b4'/%3e%3cpath%20d='m52%20103%2049%2024-3%2012-49-22Z'%20fill='%23684d40'/%3e%3cpath%20d='m74%20112%209%204-2%209-9-5Z'%20fill='%23dec282'/%3e%3cpath%20d='M49%20128h11v19H49Z'%20fill='%23b7c1a3'%20stroke='%23705747'%20stroke-width='2'/%3e%3cpath%20d='M120%2016v190'%20stroke='%23796348'%20stroke-width='5'/%3e%3ccircle%20cx='120'%20cy='24'%20r='12'%20fill='none'%20stroke='%23ba9f64'%20stroke-width='4'/%3e%3cpath%20d='m120%209%208%2015-8%209-8-9Z'%20fill='%23c9d9bd'/%3e%3cpath%20d='M50%20126h12v9l8%2010q4%2011-12%2011-17%200-12-11l7-10v-9'%20fill='%238dbbb0'%20stroke='%233e7773'%20stroke-width='2'/%3e%3cpath%20d='M49%20145h17'%20stroke='%23d7f0d8'%20stroke-width='2'/%3e%3cpath%20d='M51%20123h12'%20stroke='%23d2b778'%20stroke-width='5'/%3e%3cpath%20d='m78%20155%204%206-4%207-4-7Z'%20fill='%23c2a468'/%3e%3c/symbol%3e%3csymbol%20id='bard'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='m49%2076-22%20109%2040%2013%2043-7%2019-6-21-106Z'%20fill='%23426d82'/%3e%3cpath%20d='m86%2087%2028%20101-21%205-22-70'%20fill='%2331556f'/%3e%3cpath%20d='m52%20146-6%2047-15%2011%201%206h38l9-58m9%202%2011%2043%2022%209v4H88l-12-56'%20fill='%236d5d45'/%3e%3cpath%20d='m49%2086-19%2019-4%2031%2015%208%2017-34%2031%201%2023%2030%2019-11-22-36Z'%20fill='%23b8b39b'/%3e%3cpath%20d='m42%20120-8%2012%2019%2018%2010-12m42-18%2011%207-23%2021-11-11'%20fill='%23c2ab6d'/%3e%3cpath%20d='m58%2029%2038-9%2013%2022-7%2022-18%2019-25-12-10-22Z'%20fill='%23d1bd7a'/%3e%3cpath%20d='m96%2043%2026%209-24%209-8-8Z'%20fill='%23d89a53'%20stroke='%2384653f'%20stroke-width='1.5'/%3e%3cpath%20d='m51%2036%204-22%2011%2012%2013-20%206%2020%2014-9-4%2022Z'%20fill='%23758c75'/%3e%3cpath%20d='m55%2042%2026-4%2018%209-10%207%203%2014-12%2012-19-10Z'%20fill='%23e1d199'/%3e%3cpath%20d='m70%2046%2011%201'%20stroke='%23665a46'%20stroke-width='2.5'/%3e%3ccircle%20cx='77'%20cy='51'%20r='2'%20fill='%23302739'/%3e%3cpath%20d='m49%2081%2028%2013%2023-15-11%2026-25%205Z'%20fill='%23e3cf8f'/%3e%3cpath%20d='M47%20119h61v12H47Z'%20fill='%235e4e3e'/%3e%3cpath%20d='m111%2085%209%205-31%2068-12-7Z'%20fill='%23bb9755'%20stroke='%2368513c'%20stroke-width='2'/%3e%3cpath%20d='M75%20130q-33%200-33%2027-1%2023%2025%2025%2027%200%2030-25%201-17-22-27Z'%20fill='%23c39451'%20stroke='%2370513b'%20stroke-width='2'/%3e%3cpath%20d='M69%20137q-20%202-20%2022%200%2016%2017%2018%2020-3%2023-20-1-12-20-20Z'%20fill='%23e1bd75'/%3e%3ccircle%20cx='72'%20cy='157'%20r='8'%20fill='%23624a3e'/%3e%3cpath%20d='m68%20172%2048-85m-42%2086%2044-85'%20stroke='%23f2dfb0'%20stroke-width='1.2'/%3e%3cpath%20d='m49%20147%2019%203-3%208-17-1Zm51-30-16%2021%2010%205%2014-18'%20fill='%23d1b16f'/%3e%3c/symbol%3e%3csymbol%20id='jester'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='m55%20129-20%2062%2022%2014%2025-48%2017%2043%2027-7-24-66Z'%20fill='%23706078'/%3e%3cpath%20d='m77%20157%2020%2043%2026-7-23-61'%20fill='%23ab965b'/%3e%3cpath%20d='m33%20190-16%2011%2013%209h30l-1-13m41%202%2017%2011h28l-4-12-16-8'%20fill='%2346394f'/%3e%3cpath%20d='m55%2081-24%2028-18-12-8%2013%2027%2029%2026-23%2033%202%2027%2012%2029-40-12-6-23%2025-16-27Z'%20fill='%23568378'/%3e%3cpath%20d='m61%2079%2039%201%2010%2058-57-1Z'%20fill='%23d4bf7e'/%3e%3cpath%20d='m61%2079%2018%2028-24%2024%2011%206%2019-29%2017%2029%208-2-12-55Z'%20fill='%2374617a'/%3e%3cpath%20d='m17%2099-5-17-9%204%201%2021m131-18%207-19%2011%203-7%2023'%20fill='%23ddc4a3'/%3e%3cpath%20d='M58%2037h42l-2%2034-18%2015-22-17Z'%20fill='%23e8d8b8'/%3e%3cpath%20d='m60%2053%2015-4%207%206%2012-5%203%2013-13%208-17-5Z'%20fill='%23f9efcf'/%3e%3cpath%20d='m65%2054%206%202m16-1%205-2m-20%2014%2013%201'%20stroke='%235d4c58'%20stroke-width='2'/%3e%3cpath%20d='m77%2053-3%2010%209-1'%20fill='%23b78568'/%3e%3cpath%20d='M57%2044q-26-19-26-35%2025%202%2044%2024Q83-5%20111%207q-4%2022-17%2034Z'%20fill='%2376617b'%20stroke='%2349364c'%20stroke-width='2'/%3e%3cpath%20d='M75%2033Q83%201%20108%208L91%2038Z'%20fill='%235a8c7c'/%3e%3cpath%20d='m57%2038%2040-2%204%2010-44%202Z'%20fill='%23d3b96e'/%3e%3ccircle%20cx='32'%20cy='10'%20r='5'%20fill='%23d9b767'/%3e%3ccircle%20cx='110'%20cy='8'%20r='5'%20fill='%23d9b767'/%3e%3cpath%20d='m55%2082%2012%209%2012-9%2012%2010%2011-10'%20stroke='%23ebda9a'%20stroke-width='5'%20fill='none'/%3e%3cpath%20d='m79%20110%208%208-8%209-8-9Z'%20fill='%23e4d194'/%3e%3c/symbol%3e%3csymbol%20id='mage'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='m57%2072-34%20128%2055%209%2058-11-35-127Z'%20fill='%23665773'/%3e%3cpath%20d='m77%2083%203%20119%2035-7-27-110Z'%20fill='%239a7787'/%3e%3cpath%20d='m56%2084-35%2035%2013%2021%2039-34m20-20%2031%2025%2013-12%2011%2020-22%2020-38-28'%20fill='%2389728e'/%3e%3cpath%20d='m26%20123%2010%2010-9%2016-11-6m116-34%2011-19%2010%203-7%2022'%20fill='%23d5aa8b'/%3e%3cpath%20d='m56%2036%2040-2%203%2029-19%2018-24-16Z'%20fill='%23d5aa8b'/%3e%3cpath%20d='m30%2042%2091-4-18-11L85%200%2057%2027Z'%20fill='%234d4b66'%20stroke='%23302739'%20stroke-width='2'/%3e%3cpath%20d='m61%2027%2040%201-8-10-20%201Z'%20fill='%23cca65d'/%3e%3cpath%20d='m57%2058%2015%208%2025-10-5%2031-13%2013-18-20Z'%20fill='%23d3caba'/%3e%3ccircle%20cx='66'%20cy='52'%20r='2'%20fill='%23302739'/%3e%3ccircle%20cx='88'%20cy='50'%20r='2'%20fill='%23302739'/%3e%3cpath%20d='M33%2048v160'%20stroke='%23715847'%20stroke-width='6'/%3e%3cpath%20d='m32%209%2013%2022-12%2017-12-17Z'%20fill='%23e9bb65'%20stroke='%238b6b49'%20stroke-width='2'/%3e%3cpath%20d='m33%2014%203%2016-5%208-4-8Z'%20fill='%23fff1bd'/%3e%3cpath%20d='M55%20128h53'%20stroke='%23bb9c60'%20stroke-width='7'/%3e%3cpath%20d='m79%20122%209%208-9%208-9-8Z'%20fill='%23e3c476'/%3e%3cpath%20d='m136%2057%207-18%206%2013%2010%209-13%2010-12-6Z'%20fill='%23e1b35e'/%3e%3cpath%20d='m144%2049%205%2012-4%205-6-6Z'%20fill='%23fff1c6'/%3e%3c/symbol%3e%3csymbol%20id='justicar'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='m48%2069-24%20124%2053%2017%2058-14-27-127Z'%20fill='%23445e68'/%3e%3cpath%20d='m75%2080-7%20124%2017%205%2023-9-18-121Z'%20fill='%23bb9b5a'/%3e%3cpath%20d='m90%2080%2020%20118%2022-4-26-117Z'%20fill='%232c4657'/%3e%3cpath%20d='m48%2072-21%2028-12%2045%2017%209%2028-48%2035%201%2024%2042%2018-10-20-45-13-21Z'%20fill='%23617b7d'%20stroke='%23b5bca5'%20stroke-width='1.5'/%3e%3cpath%20d='m47%2072%2012%2035%2020-15%2017%2015%2015-34-24-7Z'%20fill='%23b9bba0'/%3e%3cpath%20d='m50%2076%2011%2026%2018-12-2-13-13-10Z'%20fill='%23e0d6ae'/%3e%3cpath%20d='m59%2042%2039%201%202%2027-22%2017-20-16Z'%20fill='%23c9a78b'/%3e%3cpath%20d='M55%2043%2060%2023%2079%206l21%2018%203%2022-10%2014-4-22-21-1-6%2025Z'%20fill='%23516374'%20stroke='%23b5bbab'%20stroke-width='2'/%3e%3cpath%20d='M79%208v32l17%205-4-20Z'%20fill='%23819195'/%3e%3cpath%20d='m65%2046%2013%206%2015-5-4%2012-10%205-11-5Z'%20fill='%23253746'/%3e%3cpath%20d='m68%2050%208%203m7-1%206-2'%20stroke='%23efe3b6'%20stroke-width='2'/%3e%3cpath%20d='m68%2065%2011%205%2011-7-3%2012-9%209-9-9Z'%20fill='%23e2dac1'/%3e%3cpath%20d='m58%20103%2045-6%203%2033-27%2013-24-13Z'%20fill='%23536873'%20stroke='%23b7ad85'%20stroke-width='2'/%3e%3cpath%20d='m79%20105%2012%2013-11%2015-12-15Z'%20fill='%23cbb271'/%3e%3cpath%20d='m79%20111%205%207-5%207-5-7Z'%20fill='%23455d65'/%3e%3cpath%20d='m49%20134%2059-4%202%2012-64%207Z'%20fill='%239c4b4d'/%3e%3cpath%20d='m77%20140%2012%202-4%2044-10-9Z'%20fill='%23bb6760'/%3e%3cpath%20d='M128%2024v180'%20stroke='%23a58a51'%20stroke-width='5'/%3e%3cpath%20d='m129%204%209%2015-9%2016-10-16Z'%20fill='%23dfc88d'%20stroke='%23a58a51'%20stroke-width='2'/%3e%3cpath%20d='m115%2034%2027%200m-14-1%201%2019'%20stroke='%23d9bf7b'%20stroke-width='3'/%3e%3cpath%20d='m117%20122%2015-5%204%209-15%207Z'%20fill='%23cbaa8b'/%3e%3cpath%20d='m24%20130%2017-8%2027%2011-4%2032-21%2015-18-17Z'%20fill='%23b4bba4'%20stroke='%23c9bd8f'%20stroke-width='2'/%3e%3cpath%20d='m29%20135%2012-6%2020%208-3%2024-15%2012-13-12Z'%20fill='%23344f5d'/%3e%3cpath%20d='m44%20132%201%2036m-15-20h28'%20stroke='%23d6c58b'%20stroke-width='2'/%3e%3c/symbol%3e%3csymbol%20id='wolf'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='m31%20130%2014-45%2034-22%2039%2037%209%2066-29%2020-57-7Z'%20fill='%23678b82'/%3e%3cpath%20d='m45%2085-7-54%2031%2030%2028-3%2023-30%201%2064-25%2033-31-1Z'%20fill='%23789d8f'/%3e%3cpath%20d='m42%2044%205%2033%2017-11m38-1%2014-23-1%2036'%20fill='%23d7cfb0'/%3e%3cpath%20d='m60%2091%2019-13%2023%2013-3%2027-20%2020-19-22Z'%20fill='%23e1e0c9'/%3e%3cpath%20d='m72%20106%2015-1-8%2010Z'%20fill='%23354e4d'/%3e%3cpath%20d='m78%20113%201%2010m-9-1%209%203%2010-4'%20stroke='%23354e4d'%20fill='none'%20stroke-width='2'/%3e%3cpath%20d='m48%2088%2016%205m30%200%2016-7'%20stroke='%23304c4d'%20stroke-width='3'/%3e%3ccircle%20cx='60'%20cy='96'%20r='3'%20fill='%23dec78b'/%3e%3ccircle%20cx='98'%20cy='95'%20r='3'%20fill='%23dec78b'/%3e%3cpath%20d='m47%20143-17%2048%2021%205%2016-40m24-7%2014%2045%2020-1-17-55'%20fill='%23416a65'/%3e%3cpath%20d='m27%20186-10%2013h38l-4-8m50-1%201%209h37l-16-12'%20fill='%23d4d5bc'/%3e%3cpath%20d='m114%20133%2024%203%208-25%2010%2020-10%2028-27%204'%20fill='%23769c8e'/%3e%3cpath%20d='m55%20126%2022%2011%2025-12-4%2015-20%2010-22-11Z'%20fill='%23b8955c'/%3e%3cpath%20d='m77%20141%207%208-8%208-7-9Z'%20fill='%23e4c98d'/%3e%3c/symbol%3e%3csymbol%20id='land'%20viewBox='0%200%201200%20450'%20preserveAspectRatio='none'%3e%3cpath%20d='M0%200h1200v450H0Z'%20fill='%23c3d6bb'/%3e%3cpath%20d='M0%2054%20196%206l156%2057%20161-24%20138%2047%20114-73%20170%2045%20103-41%20162%208v425H0Z'%20fill='%23d3dfba'/%3e%3cpath%20d='M0%20142%20153%20126%20279%20179%20376%20138%20545%20161%20655%20125%20782%20186%20916%20142%201055%20198%201200%20164v286H0Z'%20fill='%23b8cfad'/%3e%3cpath%20d='M0%20306%20127%20277%20272%20319%20412%20269%20603%20315%20754%20264%20913%20304%201082%20276%201200%20304v146H0Z'%20fill='%23a6c2a2'/%3e%3cpath%20d='M42%200Q267%20140%20339%2092T570%20126T818%2095%201117%20188'%20fill='none'%20stroke='%23edf0cb'%20stroke-width='2'%20opacity='.65'/%3e%3cpath%20d='M0%20228Q174%20169%20324%20248T607%20223%20850%20250%201200%20222M0%20398Q197%20327%20369%20372T688%20356%20918%20381%201200%20350'%20fill='none'%20stroke='%23dae6bd'%20stroke-width='2'%20opacity='.8'/%3e%3cpath%20d='M1084-30Q1003%2034%201051%2093T933%20177%201011%20259%20850%20323%20919%20484'%20fill='none'%20stroke='%2380aeac'%20stroke-width='25'/%3e%3cpath%20d='M1084-30Q1003%2034%201051%2093T933%20177%201011%20259%20850%20323%20919%20484'%20fill='none'%20stroke='%23c5dcd0'%20stroke-width='13'%20opacity='.65'/%3e%3cpath%20d='M75%20380Q177%20268%20329%20301T541%20246%20763%20282%20961%20190%201160%20231'%20fill='none'%20stroke='%23e5d89d'%20stroke-width='8'/%3e%3cpath%20d='M75%20380Q177%20268%20329%20301T541%20246%20763%20282%20961%20190%201160%20231'%20fill='none'%20stroke='%239d9f6d'%20stroke-width='1.2'%20stroke-dasharray='3%206'/%3e%3cpath%20d='m34%20120%2038-61%2038%2066%2021-32%2050%2073%2039-30%2041%2052H0Z'%20fill='%238fac9c'/%3e%3cpath%20d='m72%2059%2038%2066-22-11-12%209-17-6-25%203Zm59%2034%2025%2036-15-5-9%209-13-8-9%200Z'%20fill='%23d8e1c7'/%3e%3cpath%20d='m290%2050%2037-44%2041%2048%2032-29%2055%2061-49%2017-54-17Z'%20fill='%23a0b8a1'/%3e%3cpath%20d='m327%206%2023%2027-18-4-13%2010-13-8Z'%20fill='%23e4e6ca'/%3e%3cg%20fill='%23829e80'%20stroke='%23b2c39b'%20stroke-width='2'%3e%3cpath%20d='M82%20270h36v-43h-7v9h-8v-9h-8v9h-8v-9h-5Z'/%3e%3cpath%20d='M70%20270h62v12H70Z'/%3e%3cpath%20d='M91%20270v-15q10-13%2019%200v15'%20fill='%23b8c6a1'/%3e%3c/g%3e%3cg%20fill='%237b9b80'%3e%3cpath%20d='m1135%20333%2020-14%2018%2014v25h-38Z'/%3e%3cpath%20d='m1132%20334%2023-20%2023%2020Z'%20fill='%23617f75'/%3e%3cpath%20d='M1147%20358v-14h12v14'%20fill='%23b3c7a0'/%3e%3c/g%3e%3cpath%20d='m802%2070%2012-4%2014%206-2%2013-17%203-10-9m-441%20326%2016-9%2019%207-1%2011-25%202Z'%20fill='%238da888'%20stroke='%23adc4a0'%20stroke-width='2'/%3e%3c/symbol%3e%3c/defs%3e%3csymbol%20id='reaver'%20viewBox='0%200%20160%20210'%3e%3cuse%20href='%23warrior'%20width='160'%20height='210'/%3e%3cpath%20d='M32%2040Q32-6%2079%203q48%202%2049%2039Z'%20fill='%239e6559'%20stroke='%235e4244'%20stroke-width='2'/%3e%3cpath%20d='M37%2039h88v7H37Z'%20fill='%23dfc39b'/%3e%3ccircle%20cx='61'%20cy='21'%20r='7'%20fill='%23dfbc94'/%3e%3ccircle%20cx='96'%20cy='16'%20r='6'%20fill='%23dfbc94'/%3e%3cpath%20d='m43%2091%2025%2011%2031-7-4%2027-32%2013-26-19Z'%20fill='%2368857a'/%3e%3cpath%20d='m55%20112%2014%204%2010-5'%20stroke='%23d9c8a0'%20stroke-width='3'%20fill='none'/%3e%3c/symbol%3e%3csymbol%20id='guardian'%20viewBox='0%200%20160%20210'%3e%3cuse%20href='%23paladin'%20width='160'%20height='210'/%3e%3cpath%20d='m21%20103%2027-17%2038%2022-4%2057-28%2027-34-23Z'%20fill='%23888b86'%20stroke='%23424b4c'%20stroke-width='3'/%3e%3cpath%20d='m28%20109%2022-13%2026%2016-6%2025-29%202Z'%20fill='%23adb2a3'/%3e%3cpath%20d='m41%20141%2031%200-2%2021-17%2018-26-16Z'%20fill='%23626e6c'/%3e%3cpath%20d='m51%20106%205%2023-12%2019%2010%2017'%20stroke='%23d1c6a5'%20stroke-width='3'%20fill='none'/%3e%3cpath%20d='M51%2042%2059%2018l19-8%2026%2021-1%2015-22-13Z'%20fill='%23a0aa9f'%20stroke='%23536767'%20stroke-width='2'/%3e%3c/symbol%3e%3csymbol%20id='druid'%20viewBox='0%200%20160%20210'%3e%3cuse%20href='%23mage'%20width='160'%20height='210'/%3e%3cpath%20d='M28%2044%2042%2023%2056%2039%2080%2019l26%2022%2020-11-8%2023Z'%20fill='%233f776a'/%3e%3cpath%20d='m40%2041%202-25%2010%2014%205-29%2012%2023%2011-21%207%2031%2016-18%202%2028Z'%20fill='%23b8c29a'/%3e%3cpath%20d='m73%2093-24%2079%2027%2017%2032-20-16-77'%20fill='%23547b6e'/%3e%3cpath%20d='m76%2099%204%2077m-3-45-12-7m14%2025%2013-13'%20stroke='%23c9bc83'%20stroke-width='3'/%3e%3cpath%20d='m24%2027-9-17-4%2019%2016%2010%2016-9-1-17-11%2014Z'%20fill='%239aab77'/%3e%3cpath%20d='m129%2064%2013-20%209%2013-6%2018-13%201'%20fill='%23aebc8e'/%3e%3c/symbol%3e%3csymbol%20id='chanter'%20viewBox='0%200%20160%20210'%3e%3cuse%20href='%23bard'%20width='160'%20height='210'/%3e%3cpath%20d='m51%2028%2014-16%2032%206%2010%2021-32%204Z'%20fill='%23aa6957'/%3e%3cpath%20d='m46%20127%2060-1%204%2040q-30%2021-62%200Z'%20fill='%23a2654b'%20stroke='%235e493e'%20stroke-width='2'/%3e%3cellipse%20cx='77'%20cy='127'%20rx='30'%20ry='10'%20fill='%23dec89a'%20stroke='%23665143'%20stroke-width='2'/%3e%3cpath%20d='m50%20138%2010%2027%2013-26%2013%2026%2017-25'%20fill='none'%20stroke='%23e2ca8c'%20stroke-width='3'/%3e%3cpath%20d='m48%20111%2037%2023m27-27-30%2031'%20stroke='%23665143'%20stroke-width='4'/%3e%3cpath%20d='m49%20106%2020%209-4%209-21-8m59-6%2014-8%205%2011-16%2012'%20fill='%23cfb77d'/%3e%3c/symbol%3e%3csymbol%20id='evergreen'%20viewBox='0%200%20160%20210'%3e%3cuse%20href='%23paladin'%20width='160'%20height='210'/%3e%3cpath%20d='m36%2083%2016%20108%2026%2012%2042-14-18-108-21%2020-23-22Z'%20fill='%235e8b69'/%3e%3cpath%20d='m76%20103%202%2093m-1-64-16-12m18%2034%2018-19'%20fill='none'%20stroke='%23c6d0a0'%20stroke-width='3'/%3e%3cpath%20d='m45%2037%2016-19%2018%2010%2024-15%207%2024-19-8-14%209-16-10Z'%20fill='%23c4b674'/%3e%3cpath%20d='m49%2031-13-8%201%2014%2015%204m54-10%2016-5-6%2016-10%201'%20fill='%2372996f'/%3e%3c/symbol%3e%3csymbol%20id='hydra'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='M30%20194Q61%20160%2041%20128%2015%20104%2025%2067L8%2044%2020%2018l28%205%2011%2022-16%2022q-5%2026%2023%2045L63%2054%2049%2028%2063%208l31%202%2014%2022-22%2022%207%2059q25-27%2015-47l-8-22%2018-23%2028%202%208%2026-25%2018q12%2038-9%2062-22%2026%2013%2065Z'%20fill='%2378957c'%20stroke='%23456759'%20stroke-width='3'/%3e%3cpath%20d='m8%2044%2022%205%2020-4M58%2031l24%208%2021-7m9%2017%2020%206%2021-6'%20stroke='%23c6c99a'%20stroke-width='5'%20fill='none'/%3e%3cpath%20d='m67%20125%2015%2055%2024-58'%20fill='%23aebb94'/%3e%3cpath%20d='m28%2030%208%204m33-14%208%203m48%209%208%203'%20stroke='%23ead7a0'%20stroke-width='4'/%3e%3cpath%20d='M22%2043v8m14-4v7m37-20v10m14-8v9m34%206v8m14-4v8'%20stroke='%23e6e1c7'%20stroke-width='2'/%3e%3c/symbol%3e%3csymbol%20id='fungus'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='m61%2087-19%2099-13%2015%2020%207%2030-17%2032%2016%2024-10-20-18-18-91Z'%20fill='%23b4b096'%20stroke='%23626860'%20stroke-width='2'/%3e%3cpath%20d='M14%2088Q10%2014%2079%208q68%204%2068%2080-58%2021-133%200Z'%20fill='%238e5e6b'%20stroke='%235c455b'%20stroke-width='3'/%3e%3cpath%20d='M19%2087q63-16%20124%200-60%2026-124%200Z'%20fill='%23d2b89c'/%3e%3cpath%20d='M29%2091l50%2014%2053-14'%20stroke='%239d8275'%20stroke-width='3'%20fill='none'/%3e%3cpath%20d='m59%20115%2014%201m14-1%2013-2'%20stroke='%2344585b'%20stroke-width='4'/%3e%3cpath%20d='m68%20142%2021%201-7%209-14-2'%20fill='%2379806b'/%3e%3ccircle%20cx='52'%20cy='48'%20r='10'%20fill='%23bca78a'/%3e%3ccircle%20cx='103'%20cy='34'%20r='8'%20fill='%23bca78a'/%3e%3ccircle%20cx='124'%20cy='64'%20r='7'%20fill='%23bca78a'/%3e%3cpath%20d='m51%20123-30%2028%207%2012%2025-12m51-25%2029%2026-7%2013-26-16'%20fill='%23b4b096'/%3e%3c/symbol%3e%3csymbol%20id='statue'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='M39%20187h83v18H39Z'%20fill='%2378827c'/%3e%3cpath%20d='m51%20112-6%2071%2027%207%2010-47%2015%2045%2026-9-18-66Z'%20fill='%23819087'/%3e%3cpath%20d='m46%2067%2066-2%2017%2043-18%2019-62-7-20-23Z'%20fill='%23a6b1a1'%20stroke='%235d716b'%20stroke-width='3'/%3e%3cpath%20d='m55%2020%2022-13%2025%2015-1%2039-19%2017-25-18Z'%20fill='%23a8b3a5'%20stroke='%2363756f'%20stroke-width='2'/%3e%3cpath%20d='m58%2040%2018%206%2020-7m-20%208%204%2015'%20stroke='%235e716b'%20stroke-width='3'%20fill='none'/%3e%3cpath%20d='m30%2091-14%2042%2022%2011%2023-42m52-12%2027%2030-8%2014-24-12'%20fill='%23879c90'/%3e%3cpath%20d='M127%2042v149'%20stroke='%239eaf9e'%20stroke-width='7'/%3e%3cpath%20d='m126%2021-11%2024%2012%207%2014-8Z'%20fill='%23b3b99f'/%3e%3cpath%20d='m74%2079%208%2019-13%2016%2011%2024-9%2032'%20fill='none'%20stroke='%23587d72'%20stroke-width='3'/%3e%3cpath%20d='m78%2088%202%2012-5%208'%20stroke='%23dad1a1'%20stroke-width='2'%20fill='none'/%3e%3c/symbol%3e%3csymbol%20id='pondkin'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='M23%20193q36-23%2026-75L37%2083l14-42%2027-21%2037%2023%206%2048-18%2040q-4%2038%2029%2061l-27%2012-22-9-23%2012Z'%20fill='%2366998d'%20stroke='%23386a6b'%20stroke-width='2'/%3e%3cpath%20d='m49%2051%2016-5%2012%208%2022-7%2013%2013-11%2023-23%207-23-12Z'%20fill='%23a2c2a2'/%3e%3cpath%20d='m60%2064%2013%203m16-2%2012-3'%20stroke='%23305c62'%20stroke-width='3'/%3e%3cpath%20d='m67%2096%2013%2017%2020-19-9%2073-14%2021-17-21Z'%20fill='%2390b49a'/%3e%3cpath%20d='m42%20101-29%2034%206%2014%2033-25m58-23%2035%2027-6%2019-34-25'%20fill='%2366998d'/%3e%3cpath%20d='m56%2035-15-19%201%2031%2017-1m44-9%2014-23%203%2033-16%205'%20fill='%238eb294'/%3e%3cpath%20d='M22%20199q25-14%2050%200t67-2'%20fill='none'%20stroke='%23c6d6b4'%20stroke-width='5'/%3e%3c/symbol%3e%3csymbol%20id='troll'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='m37%20119-17%2071%2030%2016%2028-50%2018%2049%2038-16-23-78Z'%20fill='%235e7765'/%3e%3cpath%20d='m38%2069%2071-1%2024%2064-25%2025-64-5-29-27Z'%20fill='%238d9c76'%20stroke='%234a665b'%20stroke-width='3'/%3e%3cpath%20d='m42%2080-26%2017-11%2050%2017%2013%2034-55m52-24%2028%2015%2018%2045-18%2015-34-50'%20fill='%238d9c76'/%3e%3cpath%20d='m51%2031%2028-23%2030%2022-5%2035-24%2019-29-17Z'%20fill='%239daa81'/%3e%3cpath%20d='m49%2042-18-13%209%2027%2015%207m47-17%2021-20-9%2032-14%206'%20fill='%238d9c76'/%3e%3cpath%20d='m55%2048%2016%204m19-1%2013-5'%20stroke='%233f5c54'%20stroke-width='4'/%3e%3cpath%20d='m59%2063%2041-2-12%2014-18-2Z'%20fill='%234b6054'/%3e%3cpath%20d='m65%2060%202%2013%208-1m14-1%208%200-1-15'%20fill='%23e4d8b0'/%3e%3cpath%20d='M120%2089%20105%20191'%20stroke='%236a5142'%20stroke-width='12'/%3e%3cpath%20d='m102%2060%2025-2%2015%2028-9%2022-23-8Z'%20fill='%235e5146'/%3e%3cpath%20d='m38%20140%2069%201-12%2023-47%200Z'%20fill='%237e6150'/%3e%3c/symbol%3e%3csymbol%20id='wyvern'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='M66%2077%2028%2033%205%2020l5%2097%2039-3%2018%2031m25-68%2037-43%2026-12-7%2097-36-3-18%2029'%20fill='%238d7087'%20stroke='%234c4966'%20stroke-width='3'/%3e%3cpath%20d='m15%2044%2038%2064-36-3m128-60-38%2066%2033-5'%20fill='%23b4969d'/%3e%3cpath%20d='m65%2067%203-30%2014-18%2022%205%2012%2020-20%2019%202%2068-13%2048%2014%2025-21-7-10-26-7-48Z'%20fill='%23687b76'%20stroke='%23425f5e'%20stroke-width='2'/%3e%3cpath%20d='m82%2032%2021%202%2011%2011-21%201-10%2013-11-8Z'%20fill='%2392a28c'/%3e%3cpath%20d='m69%2035-7-28%2018%2014m17%203%2012-18-3%2029'%20fill='%23b7b48f'/%3e%3cpath%20d='m80%2041%2011-3'%20stroke='%23e5dba5'%20stroke-width='3'/%3e%3cpath%20d='m72%2086%2012%2017%208-21-3%2065-10%2022-10-23Z'%20fill='%23b1ba98'/%3e%3cpath%20d='m66%20130-23%2038%208%2021%2015-4%205-37m24-11%2017%2033-6%2020-14-4-4-37'%20fill='%235e7771'/%3e%3c/symbol%3e%3csymbol%20id='vines'%20viewBox='0%200%20160%20210'%3e%3cpath%20d='M33%20200q42-62%202-114Q8%2043%2060%2017%2037%2067%2080%2096q42-20%2020-77%2053%2029%2026%2076-27%2046%2011%20104Z'%20fill='%23577e69'%20stroke='%233d5c58'%20stroke-width='3'/%3e%3cpath%20d='M62%20200q45-65%2013-119M82%20140q-45-44-55-24m57%2015q39-52%2054-34M71%20166q-41-2-44-23'%20fill='none'%20stroke='%2399b083'%20stroke-width='9'/%3e%3cpath%20d='m39%2057-23-29%2032%208m55%2018%2028-31-32%209m-58%2091-21%208%205-21m88%2018%2020%209-2-23'%20fill='%23a8bb8a'/%3e%3cpath%20d='m61%2092%2010%205m16-2%2013-6'%20stroke='%23e2d49e'%20stroke-width='4'/%3e%3cpath%20d='m70%20109%2020-1-8%2012Z'%20fill='%232f4948'/%3e%3c/symbol%3e%3csymbol%20id='mutant'%20viewBox='0%200%20160%20210'%3e%3cuse%20href='%23justicar'%20width='160'%20height='210'/%3e%3cpath%20d='M26%20202q33-63-2-106-21-25%2010-50-13%2034%2017%2058m57%2096q-19-62%2022-97%2030-30%209-50%2042%2024%2017%2065-18%2030-12%2080Z'%20fill='%23687b6a'%20stroke='%233e5857'%20stroke-width='2'/%3e%3cpath%20d='m32%20124-22-11%2013%2028m107%202%2023-8-12%2022'%20fill='%23a8b48b'/%3e%3cpath%20d='m62%2058%2012%203m12%200%2011-4'%20stroke='%23d1b889'%20stroke-width='3'/%3e%3c/symbol%3e%3csymbol%20id='queen'%20viewBox='0%200%20160%20210'%3e%3cuse%20href='%23mutant'%20width='160'%20height='210'/%3e%3cpath%20d='m45%2031%203-22%2020%2013L81%200l16%2022%2018-12-2%2024Z'%20fill='%23c0ab72'%20stroke='%23725e55'%20stroke-width='2'/%3e%3cpath%20d='m50%2082-26%20113%2056%2015%2055-16-30-113-25%2018Z'%20fill='%23766077'/%3e%3cpath%20d='m80%20100%201%2096m-28-58%2027%2012%2025-16'%20stroke='%23b6a083'%20stroke-width='3'%20fill='none'/%3e%3c/symbol%3e%3csymbol%20id='king'%20viewBox='0%200%20160%20210'%3e%3cuse%20href='%23mutant'%20width='160'%20height='210'/%3e%3cpath%20d='m43%2029-2-24%2024%2013L80%200l17%2018%2022-14-1%2027Z'%20fill='%23c0ab72'%20stroke='%23725e55'%20stroke-width='2'/%3e%3cpath%20d='m23%2080%2036-14%2020%2031%2025-31%2034%2013-14%2039-27-12-17%2017-28-20-20%2016Z'%20fill='%23908c83'%20stroke='%23b5ac8f'%20stroke-width='2'/%3e%3cpath%20d='m78%20101%2017%2017-17%2018-16-18Z'%20fill='%23d0b87b'/%3e%3c/symbol%3e%3c/svg%3e";
//#endregion
//#region src/games/regicidelegacy/card-art.tsx
function Q({ suit: e, className: t = "" }) {
	return /* @__PURE__ */ f("svg", {
		"aria-hidden": !0,
		"data-suit": e,
		className: `rll-suit ${t}`,
		viewBox: "0 0 32 32",
		children: /* @__PURE__ */ f("use", {
			href: `${gt}#suit-${e}`,
			width: "32",
			height: "32"
		})
	});
}
function _t({ className: e = "" }) {
	return /* @__PURE__ */ f("svg", {
		"aria-hidden": !0,
		className: `rll-crown ${e}`,
		viewBox: "0 0 70 50",
		children: /* @__PURE__ */ f("use", {
			href: `${gt}#crown`,
			width: "70",
			height: "50"
		})
	});
}
var vt = {
	w: "warrior",
	c: "cleric",
	b: "bard",
	p: "paladin",
	f: "mage",
	mu: "reaver",
	ro: "guardian",
	fe: "druid",
	dr: "chanter",
	ev: "evergreen"
}, yt = {
	justicar: "justicar",
	hydra: "hydra",
	instructor: "mage",
	professor: "mage",
	dean: "mage",
	experiment: "mutant",
	sporite: "fungus",
	umbrispore: "fungus",
	statue: "statue",
	gardenstatue: "statue",
	shallowkin: "pondkin",
	deepkin: "pondkin",
	abysskin: "pondkin",
	troll: "troll",
	wyvern: "wyvern",
	loreguard: "guardian",
	lorekeeper: "mage",
	myla: "bard",
	mutant: "mutant",
	vid: "vines",
	mutantqueen: "queen",
	mutantking: "king",
	arcana: "evergreen"
};
function bt({ suit: e, value: t, jester: n = !1, animal: r = !1, beast: i = !1, pilgrim: a = !1, enemyName: o }) {
	let s = o?.split(".").at(-1), c = s?.startsWith("corrupted") ? Number(s.slice(9)) : null, l = n ? "jester" : r || i ? "wolf" : s && !c ? yt[s] ?? "justicar" : vt[e ?? "fe"], u = s && !c || n || r || i ? 0 : c ?? t;
	return /* @__PURE__ */ p("svg", {
		"aria-hidden": !0,
		className: `rll-character ${a ? "rll-character--pilgrim" : ""}`,
		viewBox: "0 0 160 210",
		children: [
			/* @__PURE__ */ f("g", {
				transform: u === 2 || u === 3 || u === 4 ? "translate(0 8) scale(1 .96)" : void 0,
				children: /* @__PURE__ */ f("use", {
					href: `${gt}#${l}`,
					width: "160",
					height: "210"
				})
			}),
			u > 0 && u !== 5 && l === "bard" && /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("path", {
					d: "m48 23 53-8 23 41-23 25H50L39 49Z",
					fill: "#ececdb"
				}),
				/* @__PURE__ */ f("path", {
					d: "M54 43q-2-27 25-28 24-1 25 27l-6 24-19 17-22-15Z",
					fill: "#dcb38d"
				}),
				/* @__PURE__ */ f("path", {
					d: "m51 42 6-22 24-7 20 12 4 22-13-18-14 9-18-4-6 20Z",
					fill: "#6d5142"
				}),
				/* @__PURE__ */ f("path", {
					d: "m63 52 10 1m13-1 9-1m-20 17 9 1",
					stroke: "#60493d",
					strokeWidth: "2"
				})
			] }),
			u > 0 && u !== 4 && l === "warrior" && /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("path", {
					d: "m52 60 10 7 18-5 21 0-7 29-15 14-18-13Z",
					fill: "#dfb18b"
				}),
				/* @__PURE__ */ f("path", {
					d: "m60 74 12 8 17-5-10 16-13-5Z",
					fill: "#c18d6d"
				}),
				/* @__PURE__ */ f("path", {
					d: "m69 72 16 1",
					stroke: "#76513e",
					strokeWidth: "2"
				})
			] }),
			u === 5 && l !== "bard" && /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("path", {
					d: "m58 38 23-9 21 12-7 26-19 9-19-15Z",
					fill: "#d3bf7f"
				}),
				/* @__PURE__ */ f("path", {
					d: "m94 44 26 10-22 9-8-9Z",
					fill: "#c78f4c"
				}),
				/* @__PURE__ */ f("path", {
					d: "m60 36 3-21 11 12 10-20 8 22 12-10-6 20Z",
					fill: "#7c9178"
				}),
				/* @__PURE__ */ f("path", {
					d: "m67 49 10 1",
					stroke: "#625d47",
					strokeWidth: "2"
				})
			] }),
			u === 7 && /* @__PURE__ */ f("g", {
				fill: "#dfb48f",
				children: /* @__PURE__ */ f("path", { d: "m56 46-19-14 9 27 12 1m44-14 20-14-10 27-12 1" })
			}),
			u === 8 && /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("path", {
					d: "m48 46-8-30 22 18m34 0 23-18-9 33",
					fill: "#a5b4a1",
					stroke: "#546b67",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ f("path", {
					d: "m67 62 12-3 12 3-12 10Z",
					fill: "#b7c2ad"
				}),
				/* @__PURE__ */ f("path", {
					d: "m76 62 6 0-3 4",
					fill: "#435956"
				}),
				/* @__PURE__ */ f("path", {
					d: "m68 65-19-3m19 6-19 5m41-8 19-5m-19 8 19 4",
					stroke: "#5b7167",
					strokeWidth: "1.5"
				})
			] }),
			u === 9 && /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("path", {
					d: "m51 43-9-30 18 16m36-1 18-16-8 33",
					fill: "#a7a58a"
				}),
				/* @__PURE__ */ f("path", {
					d: "m61 46 20-10 19 9-2 21-17 13-22-13Z",
					fill: "#7d9a86"
				}),
				/* @__PURE__ */ f("path", {
					d: "m73 57 20-1 13 9-17 6-17-3Z",
					fill: "#b6bd94"
				}),
				/* @__PURE__ */ f("path", {
					d: "m65 49 10 2m12-1 8-2",
					stroke: "#344e4d",
					strokeWidth: "2"
				})
			] }),
			u === 10 && /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("path", {
				d: "m49 45 10-21 20 12 22-14 10 24-13 22-19 10-19-11Z",
				fill: "#c3bea3"
			}), /* @__PURE__ */ f("path", {
				d: "m58 46 15 4m14-1 14-4m-21 8-6 14 12-1",
				fill: "none",
				stroke: "#53665f",
				strokeWidth: "3"
			})] }),
			a && /* @__PURE__ */ f("path", {
				d: "m50 75 28 19 25-20-14 39-13-10-13 10Z",
				fill: "#c8b68b"
			})
		]
	});
}
//#endregion
//#region src/games/regicidelegacy/card.tsx
var xt = {
	w: "games.regicidelegacy.suitW",
	c: "games.regicidelegacy.suitC",
	b: "games.regicidelegacy.suitB",
	p: "games.regicidelegacy.suitP",
	f: "games.regicidelegacy.suitF",
	mu: "games.regicidelegacy.suitMu",
	ro: "games.regicidelegacy.suitRo",
	fe: "games.regicidelegacy.suitFe",
	dr: "games.regicidelegacy.suitDr",
	ev: "games.regicidelegacy.suitEv"
}, St = {
	2: "games.regicidelegacy.cardRaceGnome",
	3: "games.regicidelegacy.cardRaceHalfling",
	4: "games.regicidelegacy.cardRaceDwarf",
	5: "games.regicidelegacy.cardRaceAvian",
	6: "games.regicidelegacy.cardRaceHuman",
	7: "games.regicidelegacy.cardRaceElf",
	8: "games.regicidelegacy.cardRaceFeltrix",
	9: "games.regicidelegacy.cardRaceDragonian",
	10: "games.regicidelegacy.cardRaceMazcari"
};
function $({ id: e, v: t, enemy: n, corrupted: r, reborn: i, dualSuit: a, apprentice: s, selected: c, elevated: l, mini: d, target: m, hp: ee, maxHp: h }) {
	let g = o(), _ = n ? null : C(e), v = !n && T(e), y = !n && E(e), b = _?.tags.includes("animal") ?? !1, x = n ? n.suits[0] ?? null : _.suit, S = t ?? n?.atk ?? _.value, te = n && ee !== void 0 && h !== void 0, w = r && !i, D = v ? g("games.regicidelegacy.cardJester") : n ? g(n.name) : _?.tags.includes("pilgrim") ? g("games.regicidelegacy.cardPilgrim") : g(x ? xt[x] : "games.regicidelegacy.cardUnaligned"), O = _ && /^(?:[wcbpf]|mu|ro|fe|dr)(?:[2-9]|10)$/.test(e) ? St[_.value] : void 0, k = O ? `${g(O)} · ${D}` : y ? g("games.regicidelegacy.cardBeast", { suit: D }) : b ? g("games.regicidelegacy.cardAnimal", { suit: D }) : D, ne = [
		w ? g("games.regicidelegacy.cardCorrupted") : "",
		i ? g("games.regicidelegacy.cardReborn") : "",
		a ? g("games.regicidelegacy.cardDual", { suit: g(xt[a]) }) : "",
		s ? g("games.regicidelegacy.cardApprentice") : ""
	].filter(Boolean), A = [
		y ? "B" : S,
		k,
		...ne,
		te ? g("games.regicidelegacy.enemyHp", {
			hp: Math.max(0, ee),
			max: h
		}) : ""
	].filter((e) => e !== "").join(" · "), j = Math.max(0, Math.min(h ?? 0, ee ?? 0));
	return /* @__PURE__ */ p("span", {
		role: "img",
		"aria-label": A,
		"data-suit": x ?? "none",
		className: [
			"rll-card",
			d ? "rll-card--mini" : "",
			te ? "rll-card--enemy" : "",
			n ? "rll-card--hostile" : "",
			c ? "rll-card--selected" : "",
			m ? "rll-card--target" : "",
			l ? "rll-card--elevated" : "",
			w ? "rll-card--corrupted" : "",
			i ? "rll-card--reborn" : ""
		].filter(Boolean).join(" "),
		children: [/* @__PURE__ */ p("span", {
			className: "rll-card-inner",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ f("span", {
					className: "rll-card-corner font-mono tabular-nums",
					children: y ? "B" : S
				}),
				te ? /* @__PURE__ */ f("span", {
					className: "rll-enemy-name",
					children: D
				}) : /* @__PURE__ */ f("span", {
					className: "rll-card-profession",
					children: v ? /* @__PURE__ */ f(Q, { suit: "j" }) : x ? /* @__PURE__ */ f(Q, { suit: x }) : /* @__PURE__ */ f(Q, { suit: "fe" })
				}),
				/* @__PURE__ */ f("span", {
					className: "rll-card-picture",
					children: /* @__PURE__ */ f(bt, {
						suit: x,
						value: _?.value ?? S,
						jester: v,
						animal: b,
						beast: y,
						pilgrim: _?.tags.includes("pilgrim"),
						enemyName: n?.name
					})
				}),
				te ? /* @__PURE__ */ p("span", {
					className: "rll-card-life",
					children: [/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("span", { children: g("games.regicidelegacy.healthLabel") }), /* @__PURE__ */ p("strong", {
						className: "font-mono tabular-nums",
						children: [
							j,
							" / ",
							h
						]
					})] }), /* @__PURE__ */ f("span", {
						className: "rll-life-track",
						children: /* @__PURE__ */ f("span", { style: { width: `${h && h > 0 ? j / h * 100 : 0}%` } })
					})]
				}) : /* @__PURE__ */ f("span", {
					className: "rll-card-name",
					children: k
				}),
				w && /* @__PURE__ */ f("span", {
					className: "rll-corrupt-branches",
					children: /* @__PURE__ */ f("svg", {
						viewBox: "0 0 140 200",
						children: /* @__PURE__ */ f("path", { d: "M9 150q15-32 2-57l16 6m-13 20 13-6M130 166q-17-37-2-68l-16 9m12 33-14-8" })
					})
				}),
				(w || i || a || s) && /* @__PURE__ */ p("span", {
					className: "rll-card-seals",
					children: [
						w && /* @__PURE__ */ f("span", {
							className: "rll-seal rll-seal--corrupt",
							children: g("games.regicidelegacy.corruptStamp")
						}),
						a && /* @__PURE__ */ f("span", {
							className: "rll-seal",
							children: /* @__PURE__ */ f(Q, { suit: a })
						}),
						s && /* @__PURE__ */ f("span", {
							className: "rll-seal",
							children: /* @__PURE__ */ f(Q, { suit: "f" })
						}),
						i && /* @__PURE__ */ f("span", {
							className: "rll-seal rll-seal--reborn",
							children: /* @__PURE__ */ f(Q, { suit: "ev" })
						})
					]
				})
			]
		}), c && /* @__PURE__ */ f("span", {
			className: "rll-card-check",
			"aria-hidden": !0,
			children: /* @__PURE__ */ f(u, { size: 16 })
		})]
	});
}
//#endregion
//#region src/games/regicidelegacy/board-art.tsx
function Ct() {
	return /* @__PURE__ */ p("div", {
		className: "rll-map",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f(m, {
				kind: "sheen",
				base: "var(--rll-map-base)",
				className: "rll-map-light"
			}),
			/* @__PURE__ */ f("svg", {
				viewBox: "0 0 1200 450",
				preserveAspectRatio: "none",
				className: "rll-map-land",
				children: /* @__PURE__ */ f("use", {
					href: `${gt}#land`,
					width: "1200",
					height: "450"
				})
			}),
			/* @__PURE__ */ f("svg", {
				viewBox: "0 0 1200 450",
				preserveAspectRatio: "xMidYMid slice",
				className: "rll-map-forest",
				children: [
					[30, 260],
					[90, 295],
					[230, 345],
					[335, 60],
					[745, 30],
					[820, 285],
					[1080, 295],
					[1e3, 365]
				].map(([e, t]) => /* @__PURE__ */ p("g", {
					opacity: ".26",
					children: [/* @__PURE__ */ f("use", {
						href: `${gt}#tree`,
						x: e,
						y: t,
						width: "40",
						height: "65"
					}), /* @__PURE__ */ f("use", {
						href: `${gt}#tree`,
						x: e + 20,
						y: t + 20,
						width: "30",
						height: "49"
					})]
				}, e))
			})
		]
	});
}
function wt({ enemy: e = !1 }) {
	return /* @__PURE__ */ p("span", {
		className: `rll-card-back ${e ? "rll-card-back--enemy" : ""}`,
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("span", { className: "rll-card-back-lines" }), /* @__PURE__ */ f(_t, {})]
	});
}
function Tt({ kind: e }) {
	return /* @__PURE__ */ f("svg", {
		className: "rll-relic-art",
		viewBox: "0 0 80 70",
		"aria-hidden": !0,
		children: e === "flute" ? /* @__PURE__ */ p("g", {
			transform: "rotate(-25 40 35)",
			children: [
				/* @__PURE__ */ f("path", {
					d: "M10 28h60v14H10Z",
					fill: "#c0a46b",
					stroke: "#66553d",
					strokeWidth: "2"
				}),
				[
					22,
					34,
					46,
					58
				].map((e) => /* @__PURE__ */ f("circle", {
					cx: e,
					cy: "35",
					r: "3",
					fill: "#5e5140"
				}, e)),
				/* @__PURE__ */ f("path", {
					d: "M14 28v14m49-14v14",
					stroke: "#e8d6a3",
					strokeWidth: "3"
				})
			]
		}) : e === "whistle" ? /* @__PURE__ */ p("g", { children: [
			/* @__PURE__ */ f("path", {
				d: "M15 28h35l12-10 8 13-16 11-18 14-20-9Z",
				fill: "#b96a62",
				stroke: "#66454b",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "29",
				cy: "39",
				r: "8",
				fill: "#dec18c"
			}),
			/* @__PURE__ */ f("path", {
				d: "m52 28 10 7",
				stroke: "#ead5ab",
				strokeWidth: "3"
			})
		] }) : e === "emblem" ? /* @__PURE__ */ p("g", { children: [
			/* @__PURE__ */ f("path", {
				d: "m40 4 27 15-3 31-24 16L16 50l-3-31Z",
				fill: "#5f8e95",
				stroke: "#4d5a67",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("path", {
				d: "m40 15 16 10-3 20-13 10-13-10-3-20Z",
				fill: "#d4c28c"
			}),
			/* @__PURE__ */ f("path", {
				d: "m40 24 10 10-10 13-10-13Z",
				fill: "#537b87"
			})
		] }) : /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("path", {
			d: "M41 63V27m-1 18Q9 44 15 13q27 0 26 26M41 29Q43 6 69 9q0 22-28 24",
			fill: "none",
			stroke: e === "motherC" ? "#775c80" : "#59846b",
			strokeWidth: "8"
		}), /* @__PURE__ */ f("path", {
			d: "m30 52 10-13 11 13-10 13Z",
			fill: "#d1b978"
		})] })
	});
}
//#endregion
//#region src/games/regicidelegacy/evg.ts
var Et = {
	A: "games.regicidelegacy.evgLocA",
	B: "games.regicidelegacy.evgLocB",
	C: "games.regicidelegacy.evgLocC",
	D: "games.regicidelegacy.evgLocD",
	E: "games.regicidelegacy.evgLocE"
}, Dt = {
	1: "games.regicidelegacy.evgCurse1",
	2: "games.regicidelegacy.evgCurse2",
	3: "games.regicidelegacy.evgCurse3",
	4: "games.regicidelegacy.evgCurse4",
	5: "games.regicidelegacy.evgCurse5",
	6: "games.regicidelegacy.evgCurse6",
	7: "games.regicidelegacy.evgCurse7",
	8: "games.regicidelegacy.evgCurse8",
	9: "games.regicidelegacy.evgCurse9",
	10: "games.regicidelegacy.evgCurse10",
	11: "games.regicidelegacy.evgCurse11",
	12: "games.regicidelegacy.evgCurse12",
	13: "games.regicidelegacy.evgCurse13",
	14: "games.regicidelegacy.evgCurse14",
	15: "games.regicidelegacy.evgCurse15",
	16: "games.regicidelegacy.evgCurse16",
	17: "games.regicidelegacy.evgCurse17",
	18: "games.regicidelegacy.evgCurse18",
	19: "games.regicidelegacy.evgCurse19",
	20: "games.regicidelegacy.evgCurse20",
	21: "games.regicidelegacy.evgCurse21",
	22: "games.regicidelegacy.evgCurse22",
	23: "games.regicidelegacy.evgCurse23"
}, Ot = {
	24: "games.regicidelegacy.evgBoon24",
	25: "games.regicidelegacy.evgBoon25",
	26: "games.regicidelegacy.evgBoon26",
	27: "games.regicidelegacy.evgBoon27",
	28: "games.regicidelegacy.evgBoon28",
	29: "games.regicidelegacy.evgBoon29",
	30: "games.regicidelegacy.evgBoon30",
	31: "games.regicidelegacy.evgBoon31",
	32: "games.regicidelegacy.evgBoon32",
	33: "games.regicidelegacy.evgBoon33",
	34: "games.regicidelegacy.evgBoon34",
	35: "games.regicidelegacy.evgBoon35"
}, kt = [
	{
		location: "A",
		curses: [
			1,
			2,
			14,
			21
		],
		boons: [26, 30]
	},
	{
		location: "B",
		curses: [
			5,
			7,
			12,
			18
		],
		boons: [28, 35]
	},
	{
		location: "C",
		curses: [
			4,
			8,
			15,
			19
		],
		boons: [25, 32]
	},
	{
		location: "D",
		curses: [
			1,
			7,
			12,
			16
		],
		boons: [27, 31]
	},
	{
		location: "E",
		curses: [
			2,
			3,
			10,
			22
		],
		boons: [29, 33]
	}
], At = (e) => {
	let t = /* @__PURE__ */ new Uint32Array(1);
	return crypto.getRandomValues(t), e[t[0] % e.length];
};
function jt(e) {
	let t = [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	], n = [], r = e ? 1 : 2;
	for (let e = 0; e < r; e += 1) n.push(...t.splice(t.indexOf(At(t)), 1));
	n.push(At([
		9,
		10,
		11,
		12,
		13,
		14,
		15
	]));
	let i = [
		16,
		17,
		18,
		19,
		20,
		21,
		22,
		23
	];
	for (let t = 0; t < (e ? 2 : 1); t += 1) n.push(...i.splice(i.indexOf(At(i)), 1));
	return {
		location: At([
			"A",
			"B",
			"C",
			"D",
			"E"
		]),
		curses: n,
		boons: [At([
			24,
			25,
			26,
			27,
			28,
			29
		]), At([
			30,
			31,
			32,
			33,
			34,
			35
		])]
	};
}
//#endregion
//#region src/games/regicidelegacy/view-player.tsx
function Mt(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ f(Pt, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var Nt = [
	"w",
	"c",
	"b",
	"p"
];
function Pt({ pub: e, priv: t, members: u, myRid: m, send: ee }) {
	let h = o(), g = ee, _ = (e) => u.find((t) => t.rid === e)?.name ?? e, [v, y] = i([]), [b, x] = i({}), [S, te] = i({}), [w, E] = i(null), [D, O] = i({}), [k, ne] = i("hand"), [j, M] = i(0), [N, P] = i(1), [re, ie] = i([]), [F, ae] = i({}), I = t?.hand ?? [], oe = e.turn === m, se = e.phase === "play" && oe && !e.pending && !e.jesterOut, L = e.defendKind === "myla" || e.defendKind === "teamEnd", ce = e.phase === "defend" && e.defendNeed !== null && (L || oe), R = e.pending, z = e.phase === "choice" && R !== null && R.by === m, le = R?.kind, B = r(null), V = r(null);
	n(() => {
		if (!z || !le) return;
		let e = le === "mylaPick" || le === "chainMove", t = [
			"magePick",
			"reaverPick",
			"emblemReturn",
			"druidAssign",
			"chanterDraw",
			"reaverCount",
			"discardPick",
			"cull",
			"closeCall",
			"arrowsPick",
			"zonePick",
			"squadMove",
			"rescueMove",
			"strikePick",
			"rescue"
		].includes(le);
		(e ? B.current : t ? V.current : null)?.scrollIntoView({ block: "start" });
	}, [z, le]);
	let ue = `${e.phase}|${e.turn}|${R?.kind ?? ""}|${I.join(".")}`, [H, de] = i(ue);
	H !== ue && (de(ue), y([]), x({}), te({}), E(null), O({}), M(0), P(1), ie([]), ae({}));
	let fe = (t) => e.enemyBook[t], U = (t) => e.enemyBook[t]?.atk ?? C(t).value, W = v.reduce((e, t) => e + (b[t] ?? U(t)), 0), pe = I.reduce((e, t) => e + U(t), 0), me = ce && e.defendNeed !== null && pe >= e.defendNeed, he = ce && e.feignOk && v.length === I.length, G = (t) => ({
		enemy: fe(t),
		corrupted: e.corrupted.includes(t),
		dualSuit: e.dual[t] ?? null,
		apprentice: e.apprentice === t,
		reborn: e.reborn.includes(t)
	}), ge = (e) => y(v.includes(e) ? v.filter((t) => t !== e) : [...v, e]), K = (e) => {
		if (z && R?.kind === "bardTake") {
			g({
				type: "bardTake",
				card: e
			});
			return;
		}
		if (z && R?.kind === "emblemGive") {
			g({
				type: "emblemGive",
				card: e
			});
			return;
		}
		if (z && R?.kind === "motherGive") {
			g({
				type: "motherGive",
				card: e
			});
			return;
		}
		if (z && R?.kind === "poisonPick") {
			g({
				type: "evgPick",
				card: e
			});
			return;
		}
		if (z && R?.kind === "rescue") {
			ae({
				...F,
				banishCard: F.banishCard === e ? void 0 : e
			});
			return;
		}
		(se || ce || z && (R?.kind === "discardDown" || R?.kind === "whistleGive" || R?.kind === "fluteGive")) && ge(e);
	}, _e = (e) => {
		z && (R?.kind === "mylaPick" ? g({
			type: "mylaPick",
			card: e
		}) : R?.kind === "chainMove" && ie(re.includes(e) ? re.filter((t) => t !== e) : [...re, e]));
	}, q = (t) => {
		if (z && (R?.kind === "zonePick" || R?.kind === "cull")) {
			R.kind === "zonePick" && g({
				type: "zonePick",
				card: t
			});
			return;
		}
		if (z && (R?.kind === "squadMove" || R?.kind === "rescueMove" || R?.kind === "strikePick")) {
			g({
				type: "evgPick",
				card: t
			});
			return;
		}
		se && e.mission === 7 && !e.yieldBlocked && g({
			type: "pilgrimBanish",
			card: t
		});
	}, ve = (e) => {
		z && (R?.kind === "discardPick" ? g({
			type: "discardPick",
			card: e
		}) : R?.kind === "closeCall" ? g({
			type: "evgPick",
			card: e
		}) : R?.kind === "cull" && y(v.includes(e) ? v.filter((t) => t !== e) : [...v, e]));
	}, ye = (e) => {
		if (z && R) {
			if (R.kind === "magePick") g({
				type: "magePick",
				card: e
			});
			else if (R.kind === "reaverPick") g({
				type: "reaverPick",
				card: e
			});
			else if (R.kind === "emblemReturn") g({
				type: "emblemReturn",
				card: e
			});
			else if (R.kind === "druidAssign") {
				let t = D[k], n = { ...D };
				if (t === e) delete n[k];
				else {
					for (let t of [
						"hand",
						"banish",
						"top",
						"bottom"
					]) n[t] === e && delete n[t];
					n[k] = e;
				}
				O(n);
			}
		}
	}, be = (e) => {
		z && R && (R.kind === "rescue" ? ae({
			...F,
			zoneCard: F.zoneCard === e ? void 0 : e
		}) : R.kind === "zonePick" && g({
			type: "zonePick",
			card: e
		}));
	}, xe, J;
	e.phase === "defend" ? (xe = ce ? "warn" : "info", J = L ? h("games.regicidelegacy.defendTeam", { n: e.defendNeed ?? 0 }) : ce ? h("games.regicidelegacy.defendYou", { n: e.defendNeed ?? 0 }) : h("games.regicidelegacy.defendWait", { name: _(e.turn) })) : e.phase === "choice" ? (xe = "info", J = h(z ? Ft(R.kind) : "games.regicidelegacy.phaseChoice")) : se ? (xe = "accent", J = h("games.regicidelegacy.turnYou")) : (xe = "info", J = h("games.regicidelegacy.turnWait", { name: _(e.turn) }));
	let Y = se && v.length === 1 && e.relics.includes("flute") && e.fluteUsedBy === null && U(v[0]) >= 2 && U(v[0]) <= 5, Se = I.some((e) => T(e)), Ce = v.filter((t) => !e.enemyBook[t] && C(t).tags.includes("pair")), we = v.filter((t) => !e.enemyBook[t] && C(t).tags.includes("wild")), Te = se || ce || z && [
		"bardTake",
		"emblemGive",
		"motherGive",
		"poisonPick",
		"rescue",
		"discardDown",
		"whistleGive",
		"fluteGive"
	].includes(R.kind), Ee = z && [
		"zonePick",
		"squadMove",
		"rescueMove",
		"strikePick"
	].includes(R.kind) || se && e.mission === 7 && !e.yieldBlocked, De = {
		flute: "games.regicidelegacy.relicFlute",
		whistle: "games.regicidelegacy.relicWhistle",
		emblem: "games.regicidelegacy.relicEmblem",
		motherC: "games.regicidelegacy.relicMotherC",
		motherR: "games.regicidelegacy.relicMotherR"
	}, Oe = () => {
		g({
			type: "play",
			cards: v,
			asValue: Object.keys(b).length > 0 ? b : void 0,
			asSuit: Object.keys(S).length > 0 ? S : void 0
		}), y([]);
	};
	return /* @__PURE__ */ f(l, {
		adaptive: !0,
		scroll: !1,
		className: "rll-screen",
		banner: /* @__PURE__ */ p("div", {
			className: "rll-banner",
			children: [/* @__PURE__ */ f(s, {
				tone: xe,
				text: J,
				chip: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(_t, {}), h("games.regicidelegacy.missionLabel", { n: e.mission })] }),
				accent: A.accent
			}), /* @__PURE__ */ f(c, {
				variant: "plate",
				members: u,
				myRid: m,
				anchorOf: (e) => `seat:${e}`,
				action: (t) => e.phase !== "done" && t === e.turn ? "pending" : null,
				status: (t) => {
					let n = e.players.find((e) => e.rid === t);
					return n ? /* @__PURE__ */ f("span", {
						className: "rll-seat-count tabular-nums",
						children: h("games.regicidelegacy.handCount", { n: n.handCount })
					}) : null;
				}
			})]
		}),
		children: /* @__PURE__ */ p("div", {
			className: "rll-table",
			children: [/* @__PURE__ */ p("div", {
				className: "rll-public",
				children: [
					/* @__PURE__ */ f(Ct, {}),
					/* @__PURE__ */ f("span", {
						className: "rll-progress",
						children: h("games.regicidelegacy.kills", { n: e.kills })
					}),
					/* @__PURE__ */ p("div", {
						className: "rll-public-scroll",
						children: [
							/* @__PURE__ */ p("div", {
								className: "rll-stage",
								children: [
									/* @__PURE__ */ p("div", {
										className: "rll-pile rll-pile--enemy",
										children: [
											/* @__PURE__ */ f("span", { children: h("games.regicidelegacy.pileEnemyLabel") }),
											/* @__PURE__ */ f(wt, { enemy: !0 }),
											/* @__PURE__ */ f("strong", {
												className: "font-mono tabular-nums",
												children: e.enemyLeft
											})
										]
									}),
									/* @__PURE__ */ p("div", {
										className: "rll-pile rll-pile--reserve",
										children: [
											/* @__PURE__ */ f("span", { children: h("games.regicidelegacy.pileReserveLabel") }),
											/* @__PURE__ */ f(wt, {}),
											/* @__PURE__ */ f("strong", {
												className: "font-mono tabular-nums",
												children: e.reserveCount
											})
										]
									}),
									/* @__PURE__ */ p("div", {
										className: "rll-pile rll-pile--banish rll-pile--slot",
										children: [
											/* @__PURE__ */ f("span", { children: h("games.regicidelegacy.pileBanishLabel") }),
											/* @__PURE__ */ f("span", {
												className: "rll-pile-slot",
												children: e.banish.length ? /* @__PURE__ */ f($, {
													id: e.banish[e.banish.length - 1],
													mini: !0,
													...G(e.banish[e.banish.length - 1])
												}) : /* @__PURE__ */ f("span", {
													"aria-hidden": !0,
													children: "↓"
												})
											}),
											/* @__PURE__ */ f("strong", {
												className: "font-mono tabular-nums",
												children: e.banish.length
											})
										]
									}),
									/* @__PURE__ */ p("div", {
										className: "rll-pile rll-pile--discard rll-pile--slot",
										children: [
											/* @__PURE__ */ f("span", { children: h("games.regicidelegacy.pileDiscardLabel") }),
											/* @__PURE__ */ f("span", {
												className: "rll-pile-slot",
												children: e.discard.length ? /* @__PURE__ */ f($, {
													id: e.discard[e.discard.length - 1],
													mini: !0,
													...G(e.discard[e.discard.length - 1])
												}) : /* @__PURE__ */ f("span", {
													"aria-hidden": !0,
													children: "↓"
												})
											}),
											/* @__PURE__ */ f("strong", {
												className: "font-mono tabular-nums",
												children: e.discard.length
											})
										]
									}),
									e.enemy && /* @__PURE__ */ p("div", {
										className: "rll-enemy",
										children: [/* @__PURE__ */ f($, {
											id: e.enemy.eid,
											enemy: {
												name: e.enemy.name,
												atk: e.enemy.atk,
												suits: e.enemy.suits
											},
											hp: e.enemy.hp,
											maxHp: e.enemy.maxHp,
											target: se && v.length > 0,
											elevated: !0
										}), /* @__PURE__ */ p("div", {
											className: "rll-threat",
											children: [
												/* @__PURE__ */ p("span", {
													className: "font-mono tabular-nums",
													children: [/* @__PURE__ */ f(Q, { suit: "w" }), h("games.regicidelegacy.enemyAtk", { n: e.enemy.effectiveAtk })]
												}),
												e.enemy.shield > 0 && /* @__PURE__ */ f("span", { children: h("games.regicidelegacy.shieldChip", { n: e.enemy.shield }) }),
												e.enemy.effectiveImmune.length > 0 && /* @__PURE__ */ p("span", {
													"aria-label": h("games.regicidelegacy.immuneChip", { suit: e.enemy.effectiveImmune.map((e) => h(xt[e])).join(", ") }),
													children: [e.enemy.effectiveImmune.map((e) => /* @__PURE__ */ f(Q, { suit: e }, e)), /* @__PURE__ */ f("span", { children: h("games.regicidelegacy.immuneChip", { suit: "" }) })]
												})
											]
										})]
									})
								]
							}),
							/* @__PURE__ */ f("div", {
								ref: B,
								className: "rll-mat-zone",
								children: e.players.some((e) => e.mat.length > 0) && /* @__PURE__ */ f("div", {
									className: "rll-mat-content",
									children: /* @__PURE__ */ f("div", {
										className: "overflow-x-auto",
										children: /* @__PURE__ */ f("div", {
											className: "rll-mats",
											children: e.players.filter((e) => e.mat.length > 0).map((e) => /* @__PURE__ */ p("div", {
												className: "rll-mat",
												children: [/* @__PURE__ */ f("span", { children: _(e.rid) }), /* @__PURE__ */ f("div", { children: e.mat.map((t, n) => /* @__PURE__ */ p("button", {
													type: "button",
													onClick: () => _e(t.id),
													disabled: !(z && (R?.kind === "mylaPick" || R?.kind === "chainMove" && e.rid === m)),
													children: [/* @__PURE__ */ f($, {
														id: t.id,
														v: t.v,
														mini: !0,
														selected: re.includes(t.id),
														...G(t.id)
													}), t.tucked && /* @__PURE__ */ f("span", {
														className: "rll-tucked",
														children: h("games.regicidelegacy.tuckedChip")
													})]
												}, t.id + ":" + n)) })]
											}, e.rid))
										})
									})
								})
							}),
							/* @__PURE__ */ p("div", {
								ref: V,
								className: "rll-details",
								children: [
									e.evg && /* @__PURE__ */ p("div", {
										className: "rll-evg",
										children: [
											h(Et[e.evg.location]),
											" · ",
											e.evg.curses.map((e) => h(Dt[e])).join(" · "),
											" · ",
											e.evg.boons.map((e) => h(Ot[e])).join(" · ")
										]
									}),
									e.relics.length > 0 && /* @__PURE__ */ p("div", {
										className: "rll-relics",
										children: [e.relics.map((e) => /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Tt, { kind: e }), /* @__PURE__ */ f("span", { children: h(De[e]) })] }, e)), e.flute.map((e) => /* @__PURE__ */ f($, {
											id: e,
											mini: !0,
											...G(e)
										}, e))]
									}),
									(e.zoneFaceup.length > 0 || e.zoneFacedownCount > 0 || e.zonePiles) && /* @__PURE__ */ p("div", {
										className: "flex-none",
										children: [/* @__PURE__ */ f("p", {
											className: "section-label",
											children: h("games.regicidelegacy.zoneLabel")
										}), /* @__PURE__ */ f("div", {
											className: "overflow-x-auto",
											children: /* @__PURE__ */ p("div", {
												className: "flex w-max items-center gap-1 px-1 py-0.5",
												children: [
													e.zoneFacedownCount > 0 && /* @__PURE__ */ p("span", {
														className: "rll-zone-down",
														children: [/* @__PURE__ */ f(wt, {}), /* @__PURE__ */ f("span", { children: h("games.regicidelegacy.zoneDownLabel", { n: e.zoneFacedownCount }) })]
													}),
													e.zoneFaceup.map((e) => /* @__PURE__ */ f("button", {
														type: "button",
														onClick: () => q(e),
														disabled: !Ee,
														className: "flex-none cursor-pointer",
														children: /* @__PURE__ */ f($, {
															id: e,
															mini: !0,
															...G(e)
														})
													}, e)),
													e.zonePiles?.map((e, t) => /* @__PURE__ */ p("span", {
														className: "flex flex-none flex-col items-center gap-0.5",
														children: [e.top === null ? /* @__PURE__ */ f("span", { className: "h-14 w-10 rounded border border-dashed border-ink/30" }) : /* @__PURE__ */ f("button", {
															type: "button",
															onClick: () => be(e.top),
															disabled: !z || R?.kind !== "rescue" && R?.kind !== "zonePick",
															className: "cursor-pointer",
															children: /* @__PURE__ */ f($, {
																id: e.top,
																mini: !0,
																selected: F.zoneCard === e.top,
																...G(e.top)
															})
														}), /* @__PURE__ */ f("span", {
															className: "font-mono text-[10px] tabular-nums opacity-60",
															children: e.count
														})]
													}, t))
												]
											})
										})]
									}),
									z && R?.revealed && R.kind !== "druidAssign" && /* @__PURE__ */ f("div", {
										className: "flex-none overflow-x-auto",
										children: /* @__PURE__ */ f("div", {
											className: "flex w-max items-center gap-1 px-1 py-0.5",
											children: R.revealed.map((e) => /* @__PURE__ */ f("button", {
												type: "button",
												onClick: () => ye(e),
												className: "flex-none cursor-pointer",
												children: /* @__PURE__ */ f($, {
													id: e,
													mini: !0,
													elevated: !0,
													...G(e)
												})
											}, e))
										})
									}),
									z && R?.kind === "druidAssign" && /* @__PURE__ */ p("div", {
										className: "flex-none",
										children: [/* @__PURE__ */ f("div", {
											className: "flex gap-1 px-1 py-0.5",
											children: [
												"hand",
												"banish",
												"top",
												"bottom"
											].map((e) => /* @__PURE__ */ p("button", {
												type: "button",
												onClick: () => ne(e),
												className: `btn-quiet min-h-11 flex-1 px-1 text-xs ${k === e ? "border-ink text-white" : ""}`,
												style: k === e ? { background: A.accent } : void 0,
												children: [h(`games.regicidelegacy.druid${e[0].toUpperCase()}${e.slice(1)}`), D[e] ? `: ${U(D[e])}` : ""]
											}, e))
										}), /* @__PURE__ */ f("div", {
											className: "overflow-x-auto",
											children: /* @__PURE__ */ f("div", {
												className: "flex w-max items-center gap-1 px-1 py-0.5",
												children: (R.revealed ?? []).map((e) => /* @__PURE__ */ f("button", {
													type: "button",
													onClick: () => ye(e),
													className: "flex-none cursor-pointer",
													children: /* @__PURE__ */ f($, {
														id: e,
														mini: !0,
														selected: Object.values(D).includes(e),
														...G(e)
													})
												}, e))
											})
										})]
									}),
									z && (R?.kind === "chanterDraw" || R?.kind === "reaverCount") && /* @__PURE__ */ p("div", {
										className: "flex flex-none items-center gap-2 px-1 py-0.5",
										children: [
											/* @__PURE__ */ f("button", {
												type: "button",
												"aria-label": h("games.regicidelegacy.decreaseCount"),
												className: "btn-quiet min-h-11 px-4",
												onClick: () => R.kind === "chanterDraw" ? M(Math.max(0, j - 1)) : P(Math.max(1, N - 1)),
												children: "−"
											}),
											/* @__PURE__ */ f("span", {
												className: "font-mono text-lg font-extrabold tabular-nums",
												children: R.kind === "chanterDraw" ? j : N
											}),
											/* @__PURE__ */ f("button", {
												type: "button",
												"aria-label": h("games.regicidelegacy.increaseCount"),
												className: "btn-quiet min-h-11 px-4",
												onClick: () => R.kind === "chanterDraw" ? M(Math.min(e.reserveCount, j + 1)) : P(Math.min(e.reserveCount, N + 1)),
												children: "+"
											})
										]
									}),
									z && (R?.kind === "discardPick" || R?.kind === "cull" || R?.kind === "closeCall") && /* @__PURE__ */ f("div", {
										className: "flex-none overflow-x-auto",
										children: /* @__PURE__ */ f("div", {
											className: "flex w-max items-center gap-1 px-1 py-0.5",
											children: e.discard.map((e, t) => /* @__PURE__ */ f("button", {
												type: "button",
												onClick: () => ve(e),
												className: "flex-none cursor-pointer",
												children: /* @__PURE__ */ f($, {
													id: e,
													mini: !0,
													selected: R.kind === "cull" && v.includes(e),
													...G(e)
												})
											}, `${e}:${t}`))
										})
									}),
									z && R?.kind === "arrowsPick" && /* @__PURE__ */ f("div", {
										className: "flex-none overflow-x-auto",
										children: /* @__PURE__ */ f("div", {
											className: "flex w-max items-center gap-1 px-1 py-0.5",
											children: e.banish.map((e, t) => /* @__PURE__ */ f("button", {
												type: "button",
												onClick: () => g({
													type: "evgPick",
													card: e
												}),
												className: "flex-none cursor-pointer",
												children: /* @__PURE__ */ f($, {
													id: e,
													mini: !0,
													...G(e)
												})
											}, `${e}:${t}`))
										})
									})
								]
							})
						]
					}),
					/* @__PURE__ */ f(It, {
						log: e.log,
						nameOf: _
					})
				]
			}), /* @__PURE__ */ p("div", {
				className: "rll-decision",
				children: [/* @__PURE__ */ p("div", {
					className: "rll-actions",
					children: [
						se && /* @__PURE__ */ f(d, { children: v.length > 0 ? /* @__PURE__ */ p(d, { children: [
							/* @__PURE__ */ p("span", {
								className: "rll-selection",
								children: [/* @__PURE__ */ f("span", { children: h("games.regicidelegacy.selectedCount", { n: v.length }) }), /* @__PURE__ */ f("strong", { children: h("games.regicidelegacy.selectedPower", { n: W }) })]
							}),
							Ce.map((e) => /* @__PURE__ */ p("button", {
								type: "button",
								"aria-label": h("games.regicidelegacy.valueChoice", { n: b[e] ?? 5 }),
								className: "btn-quiet min-h-11 px-2 text-xs",
								onClick: () => x({
									...b,
									[e]: b[e] === 2 ? 5 : 2
								}),
								children: [
									b[e] ?? 5,
									" ↔ ",
									b[e] === 2 ? 5 : 2
								]
							}, e)),
							we.map((e) => /* @__PURE__ */ f("span", {
								className: "flex gap-0.5",
								children: Nt.map((t) => /* @__PURE__ */ f("button", {
									type: "button",
									"aria-label": h(xt[t]),
									"aria-pressed": S[e] === t,
									className: `btn-quiet min-h-11 px-2 text-xs ${S[e] === t ? "border-ink" : ""}`,
									onClick: () => te({
										...S,
										[e]: t
									}),
									children: /* @__PURE__ */ f(Q, { suit: t })
								}, t))
							}, e)),
							Y && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-2 text-xs",
								onClick: () => {
									g({
										type: "fluteAdd",
										card: v[0]
									}), y([]);
								},
								children: h("games.regicidelegacy.fluteAdd")
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => y([]),
								children: h("games.regicidelegacy.cancel")
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-base min-h-11 px-4 text-sm text-white",
								style: { background: A.accent },
								onClick: Oe,
								children: h("games.regicidelegacy.play")
							})
						] }) : /* @__PURE__ */ p(d, { children: [
							Se && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({ type: "jester" }),
								children: h("games.regicidelegacy.jesterPlay")
							}),
							(e.soloJesters ?? 0) > 0 && /* @__PURE__ */ p(d, { children: [Nt.map((e) => /* @__PURE__ */ f("button", {
								type: "button",
								"aria-label": h(xt[e]),
								"aria-pressed": w === e,
								className: `btn-quiet min-h-11 px-2 text-xs ${w === e ? "border-ink" : ""}`,
								onClick: () => E(w === e ? null : e),
								children: /* @__PURE__ */ f(Q, { suit: e })
							}, e)), /* @__PURE__ */ f("button", {
								type: "button",
								disabled: !w,
								className: "btn-quiet min-h-11 px-3 text-sm disabled:opacity-40",
								onClick: () => {
									w && g({
										type: "play",
										cards: [],
										soloJesterSuit: w
									});
								},
								children: h("games.regicidelegacy.soloJester", { n: e.soloJesters ?? 0 })
							})] }),
							/* @__PURE__ */ f("span", { className: "min-w-0 flex-1" }),
							/* @__PURE__ */ f("button", {
								type: "button",
								disabled: e.yieldBlocked,
								className: "btn-quiet min-h-11 px-3 text-sm disabled:opacity-40",
								onClick: () => g({ type: "yield" }),
								children: h("games.regicidelegacy.yieldBtn")
							})
						] }) }),
						ce && e.defendNeed !== null && L && /* @__PURE__ */ p(d, { children: [
							/* @__PURE__ */ p("span", {
								className: "min-w-0 flex-1 font-mono text-sm font-extrabold tabular-nums",
								children: [
									W,
									" / ",
									e.defendNeed
								]
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								disabled: v.length === 0,
								className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
								style: { background: A.accent },
								onClick: () => {
									g({
										type: "defend",
										cards: v
									}), y([]);
								},
								children: h("games.regicidelegacy.defendBtn")
							}),
							/* @__PURE__ */ f(a, {
								label: h("games.regicidelegacy.surrenderBtn"),
								confirmLabel: h("games.regicidelegacy.surrenderConfirm"),
								onConfirm: () => g({
									type: "defend",
									cards: []
								})
							})
						] }),
						ce && e.defendNeed !== null && !L && /* @__PURE__ */ p(d, { children: [
							/* @__PURE__ */ p("span", {
								className: `min-w-0 flex-1 font-mono text-sm font-extrabold tabular-nums ${W >= e.defendNeed || he ? "text-done-ink" : "text-danger-ink"}`,
								children: [
									W,
									" / ",
									e.defendNeed
								]
							}),
							e.feignOk && /* @__PURE__ */ f("button", {
								type: "button",
								disabled: !he,
								className: "btn-quiet min-h-11 px-3 text-sm disabled:opacity-40",
								onClick: () => g({
									type: "defend",
									cards: I
								}),
								children: h("games.regicidelegacy.feignBtn")
							}),
							me || he ? /* @__PURE__ */ f("button", {
								type: "button",
								disabled: W < e.defendNeed && !he,
								className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
								style: { background: A.accent },
								onClick: () => {
									g({
										type: "defend",
										cards: v
									}), y([]);
								},
								children: h("games.regicidelegacy.defendBtn")
							}) : /* @__PURE__ */ f(a, {
								label: `${W} / ${e.defendNeed}`,
								confirmLabel: h("games.regicidelegacy.defendBtn"),
								onConfirm: () => g({
									type: "defend",
									cards: I
								})
							})
						] }),
						z && R && /* @__PURE__ */ p(d, { children: [
							R.kind === "druidAssign" && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-base min-h-11 px-4 text-sm text-white",
								style: { background: A.accent },
								onClick: () => g({
									type: "druidAssign",
									...D
								}),
								children: h("games.regicidelegacy.confirm")
							}),
							R.kind === "chanterDraw" && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-base min-h-11 px-4 text-sm text-white",
								style: { background: A.accent },
								onClick: () => g({
									type: "chanterDraw",
									count: j
								}),
								children: h("games.regicidelegacy.confirm")
							}),
							R.kind === "reaverCount" && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-base min-h-11 px-4 text-sm text-white",
								style: { background: A.accent },
								onClick: () => g({
									type: "reaverCount",
									count: N
								}),
								children: h("games.regicidelegacy.confirm")
							}),
							R.kind === "whistleGive" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({ type: "whistleGive" }),
								children: h("games.regicidelegacy.skip")
							}), e.soloJesters !== void 0 && e.discard.length > 0 ? /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-base min-h-11 px-4 text-sm text-white",
								style: { background: A.accent },
								onClick: () => g({
									type: "whistleGive",
									card: e.discard[e.discard.length - 1]
								}),
								children: h("games.regicidelegacy.whistleTakeTop")
							}) : /* @__PURE__ */ f("button", {
								type: "button",
								disabled: v.length !== 1 || T(v[0]),
								className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
								style: { background: A.accent },
								onClick: () => {
									g({
										type: "whistleGive",
										card: v[0],
										asValue: b[v[0]],
										asSuit: S[v[0]]
									}), y([]);
								},
								children: h("games.regicidelegacy.confirm")
							})] }),
							R.kind === "fluteGive" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({
									type: "fluteGive",
									cards: []
								}),
								children: h("games.regicidelegacy.skip")
							}), /* @__PURE__ */ p("button", {
								type: "button",
								disabled: v.length === 0,
								className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
								style: { background: A.accent },
								onClick: () => {
									g({
										type: "fluteGive",
										cards: v,
										asValue: Object.keys(b).length > 0 ? b : void 0,
										asSuit: Object.keys(S).length > 0 ? S : void 0
									}), y([]);
								},
								children: [
									h("games.regicidelegacy.confirm"),
									" (",
									v.length,
									")"
								]
							})] }),
							R.kind === "emblemGive" && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({ type: "emblemGive" }),
								children: h("games.regicidelegacy.skip")
							}),
							R.kind === "emblemReturn" && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({ type: "emblemReturn" }),
								children: h("games.regicidelegacy.skip")
							}),
							R.kind === "motherSolo" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-base min-h-11 px-4 text-sm text-white",
								style: { background: A.accent },
								onClick: () => g({
									type: "motherSolo",
									useDiscard: !1
								}),
								children: h("games.regicidelegacy.motherBanishDeck")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								disabled: e.discard.length === 0,
								className: "btn-quiet min-h-11 px-3 text-sm disabled:opacity-40",
								onClick: () => g({
									type: "motherSolo",
									useDiscard: !0
								}),
								children: h("games.regicidelegacy.motherBanishDiscard")
							})] }),
							R.kind === "discardDown" && /* @__PURE__ */ f("button", {
								type: "button",
								disabled: I.length - v.length !== e.handLimit,
								className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
								style: { background: A.accent },
								onClick: () => {
									g({
										type: "discardDown",
										cards: v
									}), y([]);
								},
								children: h("games.regicidelegacy.promptDiscardDown", { n: e.handLimit })
							}),
							R.kind === "chainMove" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({
									type: "chainMove",
									cards: []
								}),
								children: h("games.regicidelegacy.skip")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								disabled: re.length === 0,
								className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
								style: { background: A.accent },
								onClick: () => g({
									type: "chainMove",
									cards: re
								}),
								children: h("games.regicidelegacy.confirm")
							})] }),
							R.kind === "cull" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({
									type: "cull",
									cards: []
								}),
								children: h("games.regicidelegacy.skip")
							}), /* @__PURE__ */ p("button", {
								type: "button",
								className: "btn-base min-h-11 px-4 text-sm text-white",
								style: { background: A.accent },
								onClick: () => {
									g({
										type: "cull",
										cards: v
									}), y([]);
								},
								children: [
									h("games.regicidelegacy.confirm"),
									" (",
									v.length,
									")"
								]
							})] }),
							R.kind === "rescue" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({ type: "rescue" }),
								children: h("games.regicidelegacy.skip")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								disabled: !F.banishCard || !F.zoneCard,
								className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
								style: { background: A.accent },
								onClick: () => g({
									type: "rescue",
									banishCard: F.banishCard,
									zoneCard: F.zoneCard
								}),
								children: h("games.regicidelegacy.confirm")
							})] }),
							R.kind === "zonePick" && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({ type: "zonePick" }),
								children: h("games.regicidelegacy.skip")
							}),
							(R.kind === "squadMove" || R.kind === "rescueMove" || R.kind === "arrowsPick" || R.kind === "poisonPick") && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({ type: "evgPick" }),
								children: h("games.regicidelegacy.skip")
							}),
							R.kind === "strikePick" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-sm",
								onClick: () => g({ type: "evgPick" }),
								children: h("games.regicidelegacy.skip")
							}), e.discard.length > 0 && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-base min-h-11 px-4 text-sm text-white",
								style: { background: A.accent },
								onClick: () => g({
									type: "evgPick",
									card: e.discard[e.discard.length - 1]
								}),
								children: h("games.regicidelegacy.whistleTakeTop")
							})] })
						] }),
						e.jesterOut && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("span", {
							className: "min-w-0 flex-1 text-sm font-extrabold",
							children: ["🃏 ", _(e.jesterOut)]
						}), /* @__PURE__ */ f("button", {
							type: "button",
							className: "btn-base min-h-11 px-4 text-sm text-white",
							style: { background: A.accent },
							onClick: () => g({ type: "jesterClaim" }),
							children: h("games.regicidelegacy.jesterClaim")
						})] }),
						!se && !ce && !z && !e.jesterOut && /* @__PURE__ */ f("span", {
							className: "rll-waiting",
							children: h("games.regicidelegacy.waitingAction")
						})
					]
				}), t && /* @__PURE__ */ p("div", {
					className: "rll-hand",
					children: [/* @__PURE__ */ p("div", {
						className: "rll-hand-label",
						children: [/* @__PURE__ */ f("strong", { children: h("games.regicidelegacy.handLabel") }), /* @__PURE__ */ p("span", {
							className: "font-mono tabular-nums",
							children: [
								I.length,
								" / ",
								e.handLimit
							]
						})]
					}), /* @__PURE__ */ f("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ p("div", {
							className: "rll-hand-rail",
							children: [I.map((e) => /* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => K(e),
								disabled: !Te,
								"aria-pressed": v.includes(e) || F.banishCard === e,
								className: "rll-hand-card",
								children: /* @__PURE__ */ f($, {
									id: e,
									elevated: !0,
									selected: v.includes(e) || F.banishCard === e,
									...G(e)
								})
							}, e)), I.length === 0 && /* @__PURE__ */ f("span", {
								className: "px-4 py-6 text-sm font-bold opacity-50",
								children: h("games.regicidelegacy.handEmpty")
							})]
						})
					})]
				})]
			})]
		})
	});
}
function Ft(e) {
	return {
		magePick: "games.regicidelegacy.promptMagePick",
		reaverCount: "games.regicidelegacy.promptReaverCount",
		reaverPick: "games.regicidelegacy.promptReaverPick",
		whistleGive: "games.regicidelegacy.promptWhistleGive",
		fluteGive: "games.regicidelegacy.promptFluteGive",
		emblemGive: "games.regicidelegacy.promptEmblemGive",
		emblemReturn: "games.regicidelegacy.promptEmblemReturn",
		motherGive: "games.regicidelegacy.promptMotherGive",
		motherSolo: "games.regicidelegacy.promptMotherSolo",
		druidAssign: "games.regicidelegacy.promptDruidAssign",
		chanterDraw: "games.regicidelegacy.promptChanterDraw",
		discardDown: "games.regicidelegacy.promptDiscardDown",
		bardTake: "games.regicidelegacy.promptBardTake",
		mylaPick: "games.regicidelegacy.promptMylaPick",
		rescue: "games.regicidelegacy.promptRescue",
		chainMove: "games.regicidelegacy.promptChainMove",
		cull: "games.regicidelegacy.promptCull",
		zonePick: "games.regicidelegacy.promptZonePick",
		discardPick: "games.regicidelegacy.promptDiscardPick",
		squadMove: "games.regicidelegacy.promptSquadMove",
		rescueMove: "games.regicidelegacy.promptRescueMove",
		strikePick: "games.regicidelegacy.promptStrikePick",
		arrowsPick: "games.regicidelegacy.promptArrowsPick",
		closeCall: "games.regicidelegacy.promptCloseCall",
		poisonPick: "games.regicidelegacy.promptPoisonPick"
	}[e];
}
function It({ log: e, nameOf: t }) {
	let n = o();
	return /* @__PURE__ */ f("div", {
		className: "rll-log",
		children: /* @__PURE__ */ f(ee, {
			log: e,
			line: (e) => {
				let r = e.rid ? t(e.rid) : "";
				switch (e.k) {
					case "start": return n("games.regicidelegacy.logStart", { n: e.n ?? 0 });
					case "play": return n("games.regicidelegacy.logPlay", {
						name: r,
						n: e.cards?.length ?? 0
					});
					case "damage": return n("games.regicidelegacy.logDamage", { dmg: e.dmg ?? 0 });
					case "slain": return e.exact ? n("games.regicidelegacy.logSlainExact") : n("games.regicidelegacy.logSlain");
					case "yield": return n("games.regicidelegacy.logYield", { name: r });
					case "defend": return n("games.regicidelegacy.logDefend", {
						name: r,
						n: e.n ?? 0
					});
					case "fallen": return n("games.regicidelegacy.logFallen", { name: r });
					case "jester": return n("games.regicidelegacy.logJester", { name: r });
					case "jesterClaim": return n("games.regicidelegacy.logJesterClaim", { name: r });
					case "heal": return n("games.regicidelegacy.logHeal", { n: e.n ?? 0 });
					case "shieldUp": return n("games.regicidelegacy.logShieldUp", { n: e.n ?? 0 });
					case "magePick": return n("games.regicidelegacy.logMagePick", { name: r });
					case "reaverPick": return n("games.regicidelegacy.logReaverPick", { name: r });
					case "whistlePick": return n("games.regicidelegacy.logWhistlePick", { name: r });
					case "fluteGive": return n("games.regicidelegacy.logFluteGive", { name: r });
					case "emblemGive": return n("games.regicidelegacy.logEmblemGive", { name: r });
					case "motherPeek": return n("games.regicidelegacy.logMotherPeek", { name: r });
					case "druidAssign": return n("games.regicidelegacy.logDruidAssign", { name: r });
					case "chanterDraw": return n("games.regicidelegacy.logChanterDraw", {
						name: r,
						n: e.n ?? 0
					});
					case "discardDown": return n("games.regicidelegacy.logDiscardDown", { name: r });
					case "bardTake": return n("games.regicidelegacy.logBardTake", { name: r });
					case "myla": return n("games.regicidelegacy.logMyla", { dmg: e.dmg ?? 0 });
					case "rescue": return n("games.regicidelegacy.logRescue", { name: r });
					case "rotate": return n("games.regicidelegacy.logRotate");
					case "chainMove": return n("games.regicidelegacy.logChainMove", {
						name: r,
						n: e.cards?.length ?? 0
					});
					case "cull": return n("games.regicidelegacy.logCull", {
						name: r,
						n: e.n ?? 0
					});
					case "discardPick": return n("games.regicidelegacy.logDiscardPick", { name: r });
					case "zoneFlip": return n("games.regicidelegacy.logZoneFlip");
					case "beastFlip": return n("games.regicidelegacy.logBeastFlip");
					case "m7drain": return n("games.regicidelegacy.logM7Drain", { n: e.n ?? 0 });
					case "fluteAdd": return n("games.regicidelegacy.logFluteAdd", { name: r });
					case "pilgrimBanish": return n("games.regicidelegacy.logPilgrimBanish", { name: r });
					case "soloJester": return n("games.regicidelegacy.logSoloJester", { name: r });
					case "squadMove": return n("games.regicidelegacy.logSquadMove", { name: r });
					case "rescueMove": return n("games.regicidelegacy.logRescueMove", { name: r });
					case "strikePick": return n("games.regicidelegacy.logStrikePick", { name: r });
					case "arrowsPick": return n("games.regicidelegacy.logArrowsPick", { name: r });
					case "closeCall": return n("games.regicidelegacy.logCloseCall", { name: r });
					case "poisonPick": return n("games.regicidelegacy.logPoisonPick", { name: r });
					case "evgPurge": return n("games.regicidelegacy.logEvgPurge");
					case "evgDread": return n("games.regicidelegacy.logEvgDread");
					default: return e.k;
				}
			}
		})
	});
}
//#endregion
//#region src/games/regicidelegacy/bot.ts
var Lt = (e, t) => e.enemyBook[t]?.atk ?? C(t).value;
function Rt(e, t, n, r) {
	let i = t.hand, a = [], o = e.pending, s = (t) => [...t].sort((t, n) => Lt(e, t) - Lt(e, n))[0];
	if (e.phase === "choice" && o && o.by === n) {
		let t = o.revealed ?? [];
		switch (o.kind) {
			case "magePick": return t.map((e) => ({
				type: "magePick",
				card: e
			}));
			case "reaverPick": return t.map((e) => ({
				type: "reaverPick",
				card: e
			}));
			case "reaverCount": return [{
				type: "reaverCount",
				count: 1
			}];
			case "whistleGive": {
				let t = { type: "whistleGive" };
				if (e.soloJesters !== void 0) {
					let n = e.discard[e.discard.length - 1];
					return n ? [{
						type: "whistleGive",
						card: n
					}, t] : [t];
				}
				let n = s(i.filter((e) => !C(e).tags.includes("jester")));
				return n && !r ? [{
					type: "whistleGive",
					card: n
				}, t] : [t];
			}
			case "fluteGive": return [{
				type: "fluteGive",
				cards: []
			}];
			case "emblemGive": {
				let e = s(i);
				return e && !r ? [{
					type: "emblemGive",
					card: e
				}, { type: "emblemGive" }] : [{ type: "emblemGive" }];
			}
			case "emblemReturn": return [...t.map((e) => ({
				type: "emblemReturn",
				card: e
			})), { type: "emblemReturn" }];
			case "motherGive": {
				let e = s(i);
				return e ? [{
					type: "motherGive",
					card: e
				}] : [];
			}
			case "motherSolo": return [{
				type: "motherSolo",
				useDiscard: !1
			}];
			case "druidAssign": return t.length > 0 ? [{
				type: "druidAssign",
				top: t[0]
			}, { type: "druidAssign" }] : [{ type: "druidAssign" }];
			case "chanterDraw": return [{
				type: "chanterDraw",
				count: 0
			}];
			case "discardDown": return [{
				type: "discardDown",
				cards: [...i].sort((t, n) => Lt(e, t) - Lt(e, n)).slice(0, Math.max(0, i.length - e.handLimit))
			}];
			case "bardTake": {
				let e = s(i);
				return e ? [{
					type: "bardTake",
					card: e
				}] : [];
			}
			case "mylaPick": {
				let t = e.players.flatMap((e) => e.mat)[0];
				return t ? [{
					type: "mylaPick",
					card: t.id
				}] : [];
			}
			case "rescue": return [{ type: "rescue" }];
			case "chainMove": return [{
				type: "chainMove",
				cards: []
			}];
			case "cull": return [{
				type: "cull",
				cards: []
			}];
			case "zonePick": {
				let t = [], n = e.zonePiles?.find((e) => e.top !== null)?.top;
				n && t.push({
					type: "zonePick",
					card: n
				});
				let r = e.zoneFaceup.find((e) => e !== "myla");
				return r && t.push({
					type: "zonePick",
					card: r
				}), t.push({ type: "zonePick" }), t;
			}
			case "discardPick": {
				let t = e.discard[e.discard.length - 1];
				return t ? [{
					type: "discardPick",
					card: t
				}] : [];
			}
			case "squadMove":
			case "rescueMove": return [...e.zoneFaceup.map((e) => ({
				type: "evgPick",
				card: e
			})), { type: "evgPick" }];
			case "strikePick": {
				let t = e.zoneFaceup.map((e) => ({
					type: "evgPick",
					card: e
				})), n = e.discard[e.discard.length - 1];
				return n && t.push({
					type: "evgPick",
					card: n
				}), t.push({ type: "evgPick" }), t;
			}
			case "arrowsPick": {
				let t = e.banish.slice(0, 3).map((e) => ({
					type: "evgPick",
					card: e
				}));
				return t.push({ type: "evgPick" }), t;
			}
			case "closeCall": {
				let t = e.discard[e.discard.length - 1];
				return t ? [{
					type: "evgPick",
					card: t
				}] : [];
			}
			case "poisonPick": {
				let e = s(i);
				return e ? [{
					type: "evgPick",
					card: e
				}, { type: "evgPick" }] : [{ type: "evgPick" }];
			}
		}
	}
	if (e.phase === "defend" && e.defendNeed !== null && (e.defendKind !== "enemy" || e.turn === n)) {
		let t = e.defendNeed, n = [...i].sort((t, n) => Lt(e, t) - Lt(e, n)), r = [], a = 0;
		for (let i of n) {
			if (a >= t) break;
			r.push(i), a += Lt(e, i);
		}
		return a >= t ? [{
			type: "defend",
			cards: r
		}] : [{
			type: "defend",
			cards: [...i]
		}];
	}
	if (e.jesterOut && e.jesterOut !== n && !r) return [{ type: "jesterClaim" }];
	if (e.phase === "play" && e.turn === n && !o && !e.jesterOut) {
		let t = i.find((t) => !e.enemyBook[t] && C(t).tags.includes("jester"));
		!r && t && (e.enemy?.effectiveAtk ?? 0) >= 15 && a.push({ type: "jester" });
		let n = e.enemy?.effectiveAtk ?? 0, o = (t) => {
			let r = t.reduce((t, n) => t + Lt(e, n), 0);
			for (let a of t) {
				if (e.enemyBook[a]) continue;
				let t = C(a).suit;
				t === "p" && (r += Math.min(n, 12)), t === "b" && i.length <= 4 && (r += 8), t === "c" && e.discard.length >= 8 && (r += 8);
			}
			return r;
		}, s = [];
		if (!r) {
			let t = /* @__PURE__ */ new Map();
			for (let n of i) {
				let r = Lt(e, n);
				t.set(r, [...t.get(r) ?? [], n]);
			}
			for (let [e, n] of t) n.length >= 2 && e * 2 <= 10 && s.push(n.slice(0, 2));
			let n = i.filter((t) => !e.enemyBook[t] && (C(t).tags.includes("animal") || C(t).tags.includes("beast")));
			for (let e of n) for (let t of i) t !== e && s.push([e, t]);
		}
		for (let e of i) s.push([e]);
		s.sort((e, t) => r ? o(e) - o(t) : o(t) - o(e));
		for (let t of s.slice(0, 30)) {
			let n = {
				type: "play",
				cards: t
			}, r = {}, i = {};
			for (let n of t) e.enemyBook[n] || (C(n).tags.includes("pair") && (r[n] = 5), C(n).tags.includes("wild") && (i[n] = "w"));
			Object.keys(r).length > 0 && (n.asValue = r), Object.keys(i).length > 0 && (n.asSuit = i), a.push(n);
		}
		if (e.mission === 7) for (let t of e.zoneFaceup) a.push({
			type: "pilgrimBanish",
			card: t
		});
		return (e.soloJesters ?? 0) > 0 && a.push({
			type: "play",
			cards: [],
			soloJesterSuit: "w"
		}), a.push({ type: "yield" }), a;
	}
	return [];
}
var zt = (e, t) => {
	let n = e.public;
	if (n.phase === "done") return null;
	let r = t.difficulty === "weak", i = Rt(n, e.private ?? { hand: [] }, t.rid, r);
	if (i.length === 0) return null;
	let a = `${n.log.length}`, o = t.memory, s = o?.key === a ? o.tried : [], c = i.find((e) => !s.includes(JSON.stringify(e))) ?? i[0];
	return {
		action: c,
		memory: {
			key: a,
			tried: [...s, JSON.stringify(c)]
		}
	};
}, Bt = () => ({
	completed: [],
	attempts: {},
	gold: 0,
	mercs: [],
	corrupted: [],
	dual: {},
	apprentice: null,
	torn: [],
	relics: [],
	beast: null,
	outcome: null,
	lastCorruptHit: null
}), Vt = g()(_((e, t) => ({
	...Bt(),
	setOutcome: (n) => {
		t().outcome || e({
			outcome: n,
			lastCorruptHit: null
		});
	},
	settleOutcome: () => {
		let n = t();
		if (!n.outcome) return null;
		let r = n.outcome.mission;
		if (n.outcome.result === "win") {
			let t = new Set(n.relics);
			r >= 1 && t.add("flute"), r >= 4 && t.add("whistle"), r >= 6 && t.add("emblem"), r >= 9 && t.add("motherC");
			let i, a = [...n.corrupted];
			if (r >= 1 && r <= 8) {
				let e = new Set(a.map((e) => C(e).value)), t = [
					2,
					3,
					4,
					5,
					6,
					7,
					8,
					9
				].filter((t) => !e.has(t));
				if (t.length > 0) {
					let e = /* @__PURE__ */ new Uint32Array(2);
					crypto.getRandomValues(e), i = `${b[e[1] % b.length]}${t[e[0] % t.length]}`, a.push(i);
				}
			}
			return e({
				completed: n.completed.includes(r) ? n.completed : [...n.completed, r],
				attempts: {
					...n.attempts,
					[r]: 0
				},
				relics: [...t],
				corrupted: a,
				outcome: null,
				gold: 0,
				mercs: [],
				lastCorruptHit: i ?? null
			}), i ? { corrupted: i } : null;
		}
		let i = { ...n.attempts };
		i[r] = (i[r] ?? 0) + 1;
		let a = i[r];
		return e({
			attempts: i,
			gold: a,
			outcome: null
		}), { earned: a };
	},
	applyDual: (n) => e({ dual: {
		...t().dual,
		...n
	} }),
	applyApprentice: (n) => {
		let r = t();
		if (r.apprentice) return r.apprentice;
		let i = b.map((e) => `${e}${n}`).filter((e) => !r.dual[e]);
		if (i.length === 0) return null;
		let a = /* @__PURE__ */ new Uint32Array(1);
		crypto.getRandomValues(a);
		let o = i[a[0] % i.length];
		return e({ apprentice: o }), o;
	},
	applyTear: (n) => {
		let r = t();
		r.corrupted.includes(n) && !r.torn.includes(n) && e({ torn: [...r.torn, n] });
	},
	setBeast: (t) => e({ beast: t }),
	buyMerc: (n) => {
		let r = t(), i = C(n).cost ?? 0;
		return !te.includes(n) || r.mercs.includes(n) || r.gold < i ? !1 : (e({
			gold: r.gold - i,
			mercs: [...r.mercs, n]
		}), !0);
	},
	sellMerc: (n) => {
		let r = t();
		r.mercs.includes(n) && e({
			gold: r.gold + (C(n).cost ?? 0),
			mercs: r.mercs.filter((e) => e !== n)
		});
	},
	resetCampaign: () => e(Bt())
}), { name: "bgparty:regicidelegacy:campaign" }));
function Ht(e, t) {
	let n = (e) => t.completed.includes(e), r = [...D];
	if (n(1) && r.push("arc25"), n(3)) for (let e = 1; e <= 10; e += 1) r.push(`f${e}`);
	if (n(4) && t.beast && r.push(t.beast), e === 5 && !n(5)) for (let e of [
		3,
		5,
		7,
		9
	]) r.push(`mu${e}`);
	else n(5) && r.push("mu5");
	if (e === 6 && !n(6)) for (let e of [
		3,
		5,
		7,
		9
	]) r.push(`ro${e}`);
	else n(6) && r.push("ro3");
	if (e === 7 && !n(7)) for (let e of [
		3,
		5,
		7,
		9
	]) r.push(`fe${e}`);
	else n(7) && r.push("fe7");
	if (e === 8 && !n(8)) for (let e of [
		3,
		5,
		7,
		9
	]) r.push(`dr${e}`);
	else n(8) && r.push("dr9");
	return n(4) && !n(9) ? r.push("goran0") : n(9) && !n(10) && r.push("goran"), n(9) && r.push("beast-f"), n(11) && r.push("esme"), r.filter((n) => !t.torn.includes(n) && !(e === 10 && t.corrupted.includes(n)));
}
function Ut(e, t) {
	let n = e >= 12 ? t.relics.map((e) => e === "motherC" ? "motherR" : e) : t.relics, r = t.corrupted.filter((e) => !t.torn.includes(e));
	return {
		mission: e,
		evg: null,
		party: Ht(e, t),
		corrupted: r,
		dual: t.dual,
		apprentice: t.apprentice,
		reborn: e >= 12 ? [...r, ...t.completed.includes(11) ? ["esme"] : []] : [],
		relics: n,
		beast: t.beast,
		mercs: t.mercs
	};
}
var Wt = (e) => Math.min(12, e.completed.length === 0 ? 1 : Math.max(...e.completed) + 1);
function Gt(e, t) {
	let n = [...D, "arc25"];
	for (let e = 1; e <= 10; e += 1) n.push(`f${e}`);
	n.push("mu5", "ro3", "fe7", "dr9", "beast-f", "esme");
	let r = [
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9
	].map((e) => `${b[(e - 2) % b.length]}${e}`);
	return r.push("esme"), {
		mission: 13,
		evg: e,
		party: n,
		corrupted: [],
		dual: {},
		apprentice: null,
		reborn: r,
		relics: [
			"flute",
			"whistle",
			"emblem",
			"motherR"
		],
		beast: null,
		mercs: t
	};
}
//#endregion
//#region src/games/regicidelegacy/game-over.tsx
var Kt = [
	"w",
	"c",
	"b",
	"p"
], qt = {
	5: {
		value: 6,
		suit: "mu",
		esme: !0
	},
	6: {
		value: 8,
		suit: "ro"
	},
	7: {
		value: 4,
		suit: "fe"
	},
	8: {
		value: 2,
		suit: "dr"
	}
}, Jt = {
	w: "games.regicidelegacy.suitW",
	c: "games.regicidelegacy.suitC",
	b: "games.regicidelegacy.suitB",
	p: "games.regicidelegacy.suitP",
	f: "games.regicidelegacy.suitF",
	mu: "games.regicidelegacy.suitMu",
	ro: "games.regicidelegacy.suitRo",
	fe: "games.regicidelegacy.suitFe",
	dr: "games.regicidelegacy.suitDr",
	ev: "games.regicidelegacy.suitEv"
};
function Yt({ result: e, public: t, members: r, myRid: a, hintCount: s, onPlayAgain: c, onBackToLobby: l }) {
	let u = o(), d = t, m = e.winner.length > 0, ee = (e) => r.find((t) => t.rid === e)?.name ?? e, g = Vt(), _ = (c ?? l) !== void 0;
	n(() => {
		_ && (g.setOutcome({
			mission: d.mission,
			result: m ? "win" : "lose"
		}), g.settleOutcome());
	}, []);
	let v = _ && m ? g.lastCorruptHit : null, [y] = i(() => {
		if (!_ || !m || d.mission !== 2) return [];
		let e = /* @__PURE__ */ new Uint32Array(4);
		return crypto.getRandomValues(e), [
			3,
			5,
			7,
			9
		].map((t, n) => `${Kt[e[n] % Kt.length]}${t}`);
	}), [b, x] = i({}), S = y.length > 0 && !y.every((e) => g.dual[e]), te = y.every((e) => b[e] && b[e] !== C(e).suit), w = m ? qt[d.mission] : void 0, T = w ? Kt.map((e) => `${e}${w.value}`).filter((e) => (!w.esme || e !== "b6") && !g.corrupted.includes(e)) : [], E = !!(_ && w && T.length > 0 && !T.some((e) => g.dual[e] === w.suit)), [D, O] = i(null), k = _ && m && d.mission === 9 && !g.apprentice && !D, ne = g.corrupted.filter((e) => !g.torn.includes(e)), j = _ && m && d.mission === 11 && ne.length > 0, M = (e) => ({
		corrupted: g.corrupted.includes(e),
		reborn: d.reborn.includes(e),
		dualSuit: g.dual[e],
		apprentice: g.apprentice === e
	}), N = v || S || E || k || D || j;
	return /* @__PURE__ */ f("div", {
		className: "rll-over",
		children: /* @__PURE__ */ p("div", {
			className: "rll-over-content",
			children: [
				/* @__PURE__ */ p("div", {
					className: "rll-over-summary",
					children: [
						m && /* @__PURE__ */ f(h, {}),
						/* @__PURE__ */ f("span", {
							"aria-hidden": !0,
							className: "mt-6 text-5xl",
							children: /* @__PURE__ */ f(_t, {})
						}),
						/* @__PURE__ */ f("h1", {
							className: "flex-none text-center font-display text-2xl font-extrabold",
							children: u(m ? "games.regicidelegacy.overWin" : "games.regicidelegacy.overLose")
						}),
						/* @__PURE__ */ p("p", {
							className: "flex-none text-sm font-bold opacity-70",
							children: [
								u(`games.regicidelegacy.m${d.mission}`),
								" · ",
								u("games.regicidelegacy.overProgress", { n: d.kills })
							]
						}),
						_ && !m && g.gold > 0 && /* @__PURE__ */ f("p", {
							className: "flex-none text-sm font-bold text-done-ink",
							children: u("games.regicidelegacy.overGold", { n: g.gold })
						}),
						s !== void 0 && /* @__PURE__ */ f("p", {
							className: "text-sm font-bold opacity-70",
							children: u("session.hint.usedCount", { n: s })
						})
					]
				}),
				N && /* @__PURE__ */ p("div", {
					className: "rll-over-rewards frame w-full flex-none p-2",
					children: [
						/* @__PURE__ */ f("p", {
							className: "section-label",
							children: u("games.regicidelegacy.overReward")
						}),
						v && /* @__PURE__ */ p("div", {
							className: "mb-2 flex items-center gap-2",
							children: [/* @__PURE__ */ f("p", {
								className: "text-xs font-bold",
								children: u("games.regicidelegacy.overCorruptHit")
							}), /* @__PURE__ */ f($, {
								id: v,
								mini: !0,
								...M(v)
							})]
						}),
						S && /* @__PURE__ */ p("div", {
							className: "mb-2",
							children: [
								/* @__PURE__ */ f("p", {
									className: "mb-1 text-xs font-bold",
									children: u("games.regicidelegacy.overDualPick")
								}),
								/* @__PURE__ */ f("div", {
									className: "flex flex-wrap gap-1",
									children: y.map((e) => /* @__PURE__ */ p("span", {
										className: "flex flex-col items-center gap-0.5",
										children: [/* @__PURE__ */ f($, {
											id: e,
											mini: !0,
											...M(e),
											dualSuit: b[e] ?? g.dual[e],
											selected: !!b[e]
										}), /* @__PURE__ */ f("span", {
											className: "flex gap-0.5",
											children: Kt.filter((t) => t !== C(e).suit).map((t) => /* @__PURE__ */ f("button", {
												type: "button",
												"aria-label": u(Jt[t]),
												"aria-pressed": b[e] === t,
												className: `btn-quiet min-h-11 px-1.5 text-xs ${b[e] === t ? "border-ink" : ""}`,
												onClick: () => x({
													...b,
													[e]: t
												}),
												children: /* @__PURE__ */ f(Q, { suit: t })
											}, t))
										})]
									}, e))
								}),
								/* @__PURE__ */ f("button", {
									type: "button",
									disabled: !te,
									className: "btn-base mt-2 w-full min-h-11 text-sm text-white disabled:opacity-40",
									style: { background: A.accent },
									onClick: () => g.applyDual(Object.fromEntries(y.map((e) => [e, b[e]]))),
									children: u("games.regicidelegacy.overApply")
								})
							]
						}),
						E && w && /* @__PURE__ */ p("div", {
							className: "mb-2",
							children: [/* @__PURE__ */ f("p", {
								className: "mb-1 text-xs font-bold",
								children: u("games.regicidelegacy.overSealPick", { cls: u(Jt[w.suit]) })
							}), /* @__PURE__ */ f("div", {
								className: "flex flex-wrap gap-1",
								children: T.map((e) => /* @__PURE__ */ f("button", {
									type: "button",
									className: "cursor-pointer",
									onClick: () => g.applyDual({ [e]: w.suit }),
									children: /* @__PURE__ */ f($, {
										id: e,
										mini: !0,
										...M(e)
									})
								}, e))
							})]
						}),
						k && /* @__PURE__ */ p("div", {
							className: "mb-2",
							children: [/* @__PURE__ */ f("p", {
								className: "mb-1 text-xs font-bold",
								children: u("games.regicidelegacy.overApprenticePick")
							}), /* @__PURE__ */ f("div", {
								className: "flex gap-2",
								children: [4, 8].map((e) => /* @__PURE__ */ f("button", {
									type: "button",
									className: "btn-base min-h-11 flex-1 text-sm text-white",
									style: { background: A.accent },
									onClick: () => O(g.applyApprentice(e)),
									children: u(e === 4 ? "games.regicidelegacy.raceDwarf" : "games.regicidelegacy.raceFeltrix")
								}, e))
							})]
						}),
						D && /* @__PURE__ */ p("div", {
							className: "mb-2 flex items-center gap-2",
							children: [/* @__PURE__ */ f("p", {
								className: "text-xs font-bold",
								children: u("games.regicidelegacy.overApprenticeHit")
							}), /* @__PURE__ */ f($, {
								id: D,
								mini: !0,
								...M(D),
								apprentice: !0
							})]
						}),
						j && /* @__PURE__ */ p("div", {
							className: "mb-2",
							children: [/* @__PURE__ */ f("p", {
								className: "mb-1 text-xs font-bold",
								children: u("games.regicidelegacy.overTearPick")
							}), /* @__PURE__ */ f("div", {
								className: "flex flex-wrap gap-1",
								children: ne.map((e) => /* @__PURE__ */ f("button", {
									type: "button",
									className: "cursor-pointer",
									onClick: () => g.applyTear(e),
									children: /* @__PURE__ */ f($, {
										id: e,
										mini: !0,
										...M(e)
									})
								}, e))
							})]
						}),
						!S && !E && !k && !j && /* @__PURE__ */ f("p", {
							className: "text-xs font-bold text-done-ink",
							children: u("games.regicidelegacy.overApplied")
						})
					]
				}),
				/* @__PURE__ */ f("ul", {
					className: "rll-over-players flex w-full flex-none flex-col gap-1",
					children: e.ranking.map((e) => /* @__PURE__ */ p("li", {
						className: `frame flex items-center gap-2 px-3 py-1.5 text-sm font-bold ${e === a ? "border-ink" : ""}`,
						children: [/* @__PURE__ */ f("span", {
							"aria-hidden": !0,
							children: m ? "🏆" : "⚔️"
						}), /* @__PURE__ */ f("span", {
							className: "min-w-0 flex-1 truncate",
							children: ee(e)
						})]
					}, e))
				}),
				_ ? /* @__PURE__ */ p("div", {
					className: "rll-over-actions safe-b flex w-full flex-none flex-col gap-2 pb-1",
					children: [c && /* @__PURE__ */ f("button", {
						className: "btn-base w-full cursor-pointer text-white",
						style: { background: A.accent },
						onClick: c,
						children: u("session.result.playAgain")
					}), l && /* @__PURE__ */ f("button", {
						className: "btn-quiet w-full cursor-pointer",
						onClick: l,
						children: u("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ f("p", {
					className: "safe-b flex-none pb-1 text-sm font-bold opacity-70",
					children: u("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/games/regicidelegacy/options.tsx
function Xt(e) {
	return e.startsWith("m12") ? "games.regicidelegacy.mercM12" : e.startsWith("m25") ? "games.regicidelegacy.mercM25" : e.startsWith("m19") ? "games.regicidelegacy.mercM19" : e.startsWith("mw") ? "games.regicidelegacy.mercWild" : "games.regicidelegacy.mercJester";
}
function Zt({ value: e, onChange: t }) {
	let r = o(), a = Vt(), s = re.safeParse(e), c = Wt(a), [l, u] = i(() => {
		let e = s.success ? s.data.mission : 1;
		return Math.max(1, Math.min(c, e));
	}), [m, ee] = i(() => s.success && s.data.mission === 13 && s.data.evg !== null), [h, g] = i(!1), [_, b] = i(() => s.success && s.data.evg ? s.data.evg : jt(!1)), [x, S] = i([]), { settleOutcome: w, mercs: T, beast: E, gold: D, completed: O, corrupted: k, dual: ne, apprentice: j, relics: M } = a;
	n(() => {
		w();
	}, []), n(() => {
		t(m ? Gt(_, x) : Ut(l, a));
	}, [
		l,
		T,
		E,
		m,
		_,
		x
	]);
	let N = Ut(l, a).party;
	return /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p(y, {
				title: r("games.regicidelegacy.campTitle"),
				columns: 3,
				children: [Array.from({ length: c }, (e, t) => t + 1).map((e) => {
					let t = !m && e === l, n = O.includes(e);
					return /* @__PURE__ */ f(v, {
						name: "regicidelegacy-mission",
						value: String(e),
						checked: t,
						label: /* @__PURE__ */ p(d, { children: [r("games.regicidelegacy.campMission", { n: e }), n && /* @__PURE__ */ f("span", {
							className: "block text-[10px] text-done-ink",
							children: r("games.regicidelegacy.campCompleted")
						})] }),
						accent: A.accent,
						onChange: () => {
							u(e), ee(!1);
						}
					}, e);
				}), /* @__PURE__ */ f(v, {
					name: "regicidelegacy-mission",
					value: "evergreen",
					checked: m,
					label: r("games.regicidelegacy.m13"),
					accent: A.accent,
					onChange: () => ee(!0)
				})]
			}), !m && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("p", {
				className: "mt-1 text-sm font-bold",
				children: r(`games.regicidelegacy.m${l}`)
			}), (a.attempts[String(l)] ?? 0) > 0 && /* @__PURE__ */ f("p", {
				className: "text-xs opacity-70",
				children: r("games.regicidelegacy.campLosses", { n: a.attempts[String(l)] ?? 0 })
			})] })] }),
			m && /* @__PURE__ */ p("div", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ p("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ f("p", {
								className: "section-label",
								children: r("games.regicidelegacy.evgTitle")
							}),
							/* @__PURE__ */ f("div", {
								className: "flex gap-1",
								children: [!1, !0].map((e) => /* @__PURE__ */ f("button", {
									type: "button",
									onClick: () => {
										g(e), b(jt(e));
									},
									className: `btn-quiet min-h-11 px-2 text-xs ${h === e ? "font-bold" : "opacity-60"}`,
									children: r(e ? "games.regicidelegacy.evgHard" : "games.regicidelegacy.evgNormal")
								}, String(e)))
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								onClick: () => b(jt(h)),
								className: "btn-quiet min-h-11 px-2 text-xs",
								children: r("games.regicidelegacy.evgReroll")
							})
						]
					}),
					/* @__PURE__ */ p("div", {
						className: "flex flex-wrap items-center gap-1",
						children: [/* @__PURE__ */ f("span", {
							className: "text-xs opacity-70",
							children: r("games.regicidelegacy.evgPreset")
						}), kt.map((e, t) => /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => b(e),
							className: "btn-quiet min-h-11 px-2 text-xs",
							children: [
								r(Et[e.location]),
								"·",
								t + 1
							]
						}, e.location))]
					}),
					/* @__PURE__ */ p("div", {
						className: "plate px-3 py-2 text-xs font-bold",
						children: [
							/* @__PURE__ */ f("p", { children: r(Et[_.location]) }),
							/* @__PURE__ */ f("p", {
								className: "opacity-70",
								children: _.curses.map((e) => r(Dt[e])).join(" · ")
							}),
							/* @__PURE__ */ f("p", {
								className: "text-done-ink",
								children: _.boons.map((e) => r(Ot[e])).join(" · ")
							})
						]
					}),
					_.boons.includes(24) && /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("p", {
						className: "section-label",
						children: r("games.regicidelegacy.evgMercBudget")
					}), /* @__PURE__ */ f("div", {
						className: "grid grid-cols-2 gap-2",
						children: te.map((e) => {
							let t = C(e), n = x.includes(e), i = x.reduce((e, t) => e + (C(t).cost ?? 0), 0) + (t.cost ?? 0) <= 5;
							return /* @__PURE__ */ p("button", {
								type: "button",
								disabled: !n && !i,
								"aria-pressed": n,
								onClick: () => S(n ? x.filter((t) => t !== e) : [...x, e]),
								className: "plate flex min-h-11 cursor-pointer items-center gap-2 px-2 py-1.5 disabled:opacity-40",
								style: n ? { borderColor: A.accent } : void 0,
								children: [
									/* @__PURE__ */ f($, {
										id: e,
										mini: !0,
										selected: n
									}),
									/* @__PURE__ */ f("span", {
										className: "min-w-0 flex-1 truncate text-left text-xs font-bold",
										children: r(Xt(e))
									}),
									/* @__PURE__ */ f("span", {
										className: "font-mono text-[10px] tabular-nums opacity-70",
										children: t.cost ?? 0
									})
								]
							}, e);
						})
					})] })
				]
			}),
			!m && /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p("p", {
				className: "section-label",
				children: [
					r("games.regicidelegacy.campGold", { n: D }),
					" · ",
					r("games.regicidelegacy.campMercShop")
				]
			}), /* @__PURE__ */ f("div", {
				className: "grid grid-cols-2 gap-2",
				children: te.map((e) => {
					let t = C(e), n = T.includes(e), i = D >= (t.cost ?? 0);
					return /* @__PURE__ */ p("div", {
						className: "plate flex items-center gap-2 px-2 py-1.5",
						children: [
							/* @__PURE__ */ f($, {
								id: e,
								mini: !0
							}),
							/* @__PURE__ */ p("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ f("p", {
									className: "truncate text-xs font-bold",
									children: r(Xt(e))
								}), /* @__PURE__ */ f("p", {
									className: "font-mono text-[10px] tabular-nums opacity-70",
									children: r("games.regicidelegacy.campMercCost", { n: t.cost ?? 0 })
								})]
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								disabled: !n && !i,
								onClick: () => n ? a.sellMerc(e) : a.buyMerc(e),
								className: `btn-quiet min-h-11 px-2 text-xs disabled:opacity-40 ${n ? "text-danger-ink" : ""}`,
								children: r(n ? "games.regicidelegacy.mercSell" : "games.regicidelegacy.mercBuy")
							})
						]
					}, e);
				})
			})] }),
			!m && O.includes(4) && /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("p", {
				className: "section-label",
				children: r("games.regicidelegacy.campBeastPick")
			}), /* @__PURE__ */ f("div", {
				className: "flex gap-2",
				children: [
					"beast-w",
					"beast-c",
					"beast-b",
					"beast-p"
				].map((e) => {
					let t = E === e;
					return /* @__PURE__ */ f("button", {
						type: "button",
						"aria-label": e,
						onClick: () => a.setBeast(t ? null : e),
						className: "cursor-pointer rounded",
						style: t ? { outline: `3px solid ${A.accent}` } : void 0,
						children: /* @__PURE__ */ f($, {
							id: e,
							mini: !0,
							selected: t
						})
					}, e);
				})
			})] }),
			!m && (k.length > 0 || Object.keys(ne).length > 0 || j || M.length > 0) && /* @__PURE__ */ p("div", {
				className: "plate px-3 py-2 text-xs font-bold",
				children: [/* @__PURE__ */ f("p", { children: M.map((e) => r(`games.regicidelegacy.relic${e[0].toUpperCase()}${e.slice(1)}`)).join(" · ") }), /* @__PURE__ */ f("p", {
					className: "opacity-70",
					children: r("games.regicidelegacy.campSummary", {
						c: k.length,
						d: Object.keys(ne).length,
						a: +!!j,
						p: N.length
					})
				})]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/regicidelegacy/entry.tsx
var Qt = {
	definition: ht,
	View: Mt,
	bot: zt,
	OverView: Yt,
	Options: Zt,
	locales: {
		zh: {
			name: "弑君者:传承",
			desc: "12 任务合作传承战役:队伍随战役成长,腐蚀、佣兵与神器改变每一局",
			rules: "目标:全队合作击败本任务的全部敌人;任一玩家承受不住伤害则全员落败。\n回合流程(轮到你):\n· 打出一张牌攻击;或打出同点数的组合(合计不超过 10 点)、动物/野兽带 1 张搭档;也可以放弃攻击直接承受反击。\n· 花色能力:牧师=弃牌堆洗切后取等量牌垫入库底;吟游诗人=全队轮流补牌;战士=本次伤害翻倍;圣骑士=永久削减敌攻。\n· 敌人未被击败则反击:弃掉合计不低于其攻击力的手牌来承受伤害;一次性弃光整副手牌可「假死」,抵挡任意数值的伤害。\n· 敌人免疫自身花色:该花色只算伤害不发动能力;小丑打出后由任意玩家认领,认领者的攻击无视免疫。\n战役演化:\n· 腐蚀卡:打出时先放逐牌库顶 1 张,无视同色免疫。\n· 法师:翻牌垫牌连锁;守护者:打出当回合格挡全部伤害;德鲁伊:重分配弃牌堆;吟唱者:从牌库任意补牌。\n· 失败得金币,可在下次尝试前招募佣兵;通关任务解锁新职业、神器与卡牌。",
			m1: "征召号角",
			m2: "影与迷雾",
			m3: "烈焰课业",
			m4: "黑暗熔合",
			m5: "高高在上",
			m6: "记忆碎片",
			m7: "重生传说",
			m8: "混沌之风",
			m9: "灰烬中的希望",
			m10: "骄傲与陨落",
			m11: "堕入黑暗",
			m12: "腐朽与新生",
			enemy: {
				justicar: "法官",
				hydra: "九头蛇之首",
				instructor: "火焰导师",
				professor: "火焰教授",
				dean: "火焰院长",
				experiment: "实验体",
				sporite: "孢子族",
				umbrispore: "影孢族",
				statue: "雕像",
				gardenstatue: "庭园雕像",
				shallowkin: "浅水湖精",
				deepkin: "深水湖精",
				abysskin: "深渊湖精",
				troll: "巨魔",
				wyvern: "双足飞龙",
				loreguard: "知识卫士",
				lorekeeper: "知识保管",
				myla: "米拉",
				corrupted2: "腐蚀侏儒",
				corrupted3: "腐蚀半身人",
				corrupted4: "腐蚀矮人",
				corrupted5: "腐蚀禽族",
				corrupted6: "腐蚀人类",
				corrupted7: "腐蚀精灵",
				corrupted8: "腐蚀猫灵",
				corrupted9: "腐蚀龙裔",
				mutant: "变异法官",
				vid: "永恒藤蔓",
				mutantqueen: "变异之后",
				mutantking: "变异之王",
				arcana: "至高奥秘"
			},
			cardRaceGnome: "侏儒",
			cardRaceHalfling: "半身人",
			cardRaceDwarf: "矮人",
			cardRaceAvian: "禽族",
			cardRaceHuman: "人类",
			cardRaceElf: "精灵",
			cardRaceFeltrix: "猫灵",
			cardRaceDragonian: "龙裔",
			cardRaceMazcari: "玛斯卡里",
			cardJester: "小丑",
			cardUnaligned: "无职业",
			cardPilgrim: "朝圣者",
			cardBeast: "{{suit}}野兽",
			cardAnimal: "{{suit}}动物伙伴",
			cardCorrupted: "腐蚀",
			cardReborn: "重生",
			cardDual: "第二职业：{{suit}}",
			cardApprentice: "法师学徒",
			healthLabel: "生命",
			corruptStamp: "蚀",
			handLabel: "你的手牌",
			handCount: "手牌 {{n}} 张",
			selectedPower: "强度 {{n}}",
			selectedCount: "已选 {{n}} 张",
			missionLabel: "任务 {{n}}",
			pileEnemyLabel: "敌堆",
			pileReserveLabel: "牌库",
			pileDiscardLabel: "弃牌堆",
			pileBanishLabel: "放逐区",
			valueChoice: "选择此牌强度：{{n}}",
			decreaseCount: "减少张数",
			increaseCount: "增加张数",
			waitingAction: "等待其他玩家行动",
			suitW: "战士",
			suitC: "牧师",
			suitB: "吟游诗人",
			suitP: "圣骑士",
			suitF: "法师",
			suitMu: "掠夺者",
			suitRo: "守护者",
			suitFe: "德鲁伊",
			suitDr: "吟唱者",
			suitEv: "常青",
			relicFlute: "部落笛",
			relicWhistle: "猩红哨",
			relicEmblem: "蔚蓝徽记",
			relicMotherC: "常青母体·腐蚀",
			relicMotherR: "常青母体·复原",
			turnYou: "轮到你 · 选择手牌攻击",
			turnWait: "等 {{name}} 出牌…",
			defendYou: "承受 {{n}} 点伤害:弃牌合计 ≥ {{n}}",
			defendWait: "等 {{name}} 承受伤害…",
			defendKindMyla: "米拉的反击!",
			defendKindBacklash: "完美击杀的反噬!",
			phaseChoice: "处理效果…",
			enemyHp: "生命 {{hp}}/{{max}}",
			enemyAtk: "攻击 {{n}}",
			immuneChip: "免疫 {{suit}}",
			shieldChip: "护盾 -{{n}}",
			pileReserve: "牌库 {{n}}",
			pileDiscard: "弃牌 {{n}}",
			pileBanish: "放逐 {{n}}",
			pileEnemy: "敌堆 {{n}}",
			zoneLabel: "任务区",
			zoneDownLabel: "扣置 {{n}}",
			fluteLabel: "部落笛",
			matLabel: "垫上",
			kills: "已击败 {{n}}",
			handEmpty: "手牌已空",
			lockedChip: "锁定",
			tuckedChip: "垫牌",
			play: "攻击",
			yieldBtn: "跳过攻击(承受反击)",
			defendBtn: "弃牌承受",
			feignBtn: "假死(弃全手牌)",
			defendTeam: "团队承伤:全队弃牌合计 ≥ {{n}}(任意玩家可分批弃)",
			surrenderBtn: "宣告团灭",
			surrenderConfirm: "确认团灭?",
			jesterPlay: "打出小丑",
			jesterClaim: "认领小丑",
			cancel: "取消",
			confirm: "确定",
			skip: "跳过",
			soloJester: "打出小丑({{n}} 剩余)",
			fluteAdd: "堆入部落笛",
			whistleTakeTop: "取弃牌堆顶",
			motherBanishDeck: "放逐库顶",
			motherBanishDiscard: "放逐弃牌堆顶",
			pilgrimBanish: "放逐朝圣者",
			promptMagePick: "法师:选 1 张垫入(垫到法师会继续翻)",
			promptReaverCount: "掠夺者:宣言翻牌张数,选 1 张加伤害,翻出的全放逐",
			promptReaverPick: "掠夺者:选 1 张,其强度加进本次伤害,其余放逐",
			promptWhistleGive: "猩红哨:选 1 张非小丑手牌加入本次攻击(可跳过)",
			promptFluteGive: "部落笛:选与攻击卡同值的手牌加入攻击(合计 ≤10,可跳过)",
			promptEmblemGive: "徽记:选 1 张手牌放上牌库顶(可跳过)",
			promptEmblemReturn: "徽记:选 1 张放回牌库顶,其余弃掉(可跳过)",
			promptMotherGive: "常青母体:放逐你 1 张手牌",
			promptMotherSolo: "常青母体:放逐库顶,或改放逐弃牌堆顶",
			promptDruidAssign: "德鲁伊:把发到的牌分送四槽(手牌/放逐/库顶/库底各至多 1 张)",
			promptChanterDraw: "吟唱者:宣言张数,全队每人各摸该数量的牌",
			promptDiscardDown: "手牌超上限:弃至 {{n}} 张",
			promptBardTake: "选 1 张手牌交出",
			promptMylaPick: "选 1 张垫上卡送入任务区",
			promptRescue: "救援:放逐 1 张手牌救回 1 张明卡,或跳过轮转牌堆",
			promptChainMove: "接龙:把垫上强度递增接续任务区的卡移入(可跳过)",
			promptCull: "玛斯卡里入区:从弃牌堆放逐任意张,其余垫入库底",
			promptZonePick: "选择任务区 1 张卡(可跳过)",
			promptDiscardPick: "完美击杀:选弃牌堆 1 张放上牌库顶",
			druidHand: "入手",
			druidBanish: "放逐",
			druidTop: "库顶",
			druidBottom: "库底",
			overWin: "任务完成!",
			overLose: "队伍倒下…",
			overProgress: "击败 {{n}} 个敌人",
			overReward: "战役奖励",
			overApply: "应用奖励",
			overApplied: "已应用",
			overGold: "获得金币 {{n}}",
			overCorruptHit: "腐蚀降临(随机)",
			overDualPick: "双色章:为这 4 张牌各选第二花色",
			overSealPick: "职业章:选 1 张牌贴上{{cls}}章",
			overApprenticePick: "法师学徒:选择受训种族(随机定位 1 张未贴章卡)",
			raceDwarf: "矮人(4)",
			raceFeltrix: "猫灵(8)",
			overApprenticeHit: "学徒诞生",
			overTearPick: "剧情杀:永恒誓言者披上绿斗篷——选 1 名腐蚀者撕卡",
			campTitle: "战役进度",
			campMission: "任务 {{n}}",
			campCompleted: "已通关",
			campGold: "金币 {{n}}",
			campMercShop: "佣兵商店(未花完的金币开局作废;败北不离队,同价可互换)",
			campMercCost: "{{n}} 金币",
			campBeastPick: "选择出战野兽",
			campLosses: "本任务已败 {{n}} 次",
			mercM12: "精英佣兵",
			mercM25: "双面佣兵",
			mercM19: "重装佣兵",
			mercWild: "驯兽佣兵",
			mercJester: "弄臣佣兵",
			mercBuy: "雇佣",
			mercSell: "解雇",
			campSummary: "腐蚀 {{c}} · 双花色 {{d}} · 学徒 {{a}} · 队伍 {{p}} 张",
			logStart: "任务 {{n}} 开始",
			logPlay: "{{name}} 打出 {{n}} 张",
			logDamage: "造成 {{dmg}} 伤害",
			logSlain: "敌人被击败",
			logSlainExact: "完美击杀!",
			logYield: "{{name}} 跳过",
			logDefend: "{{name}} 弃 {{n}} 张承受",
			logFallen: "{{name}} 承受不住——全员落败",
			logJester: "{{name}} 打出小丑",
			logJesterClaim: "{{name}} 认领小丑",
			logHeal: "洗回 {{n}} 张入库底",
			logShieldUp: "敌攻 -{{n}}",
			logMagePick: "{{name}} 垫入 1 张",
			logReaverPick: "{{name}} 掠夺翻倍",
			logWhistlePick: "{{name}} 唤来搭档",
			logFluteGive: "{{name}} 以部落笛加入攻击",
			logEmblemGive: "{{name}} 放 1 张上库顶",
			logMotherPeek: "{{name}} 放逐 1 张",
			logDruidAssign: "{{name}} 重分配弃牌堆",
			logChanterDraw: "{{name}} 摸 {{n}} 张",
			logDiscardDown: "{{name}} 弃至上限",
			logBardTake: "{{name}} 交出 1 张",
			logMyla: "米拉反击 {{dmg}}",
			logRescue: "{{name}} 救援 1 张",
			logRotate: "牌堆轮转",
			logChainMove: "{{name}} 接龙 {{n}} 张",
			logCull: "{{name}} 放逐 {{n}} 张",
			logDiscardPick: "{{name}} 取回 1 张上库顶",
			logZoneFlip: "任务区翻开 1 张",
			logBeastFlip: "野兽翻面",
			logM7Drain: "从牌库弃 {{n}} 张",
			logFluteAdd: "{{name}} 堆入部落笛",
			logPilgrimBanish: "{{name}} 放逐朝圣者",
			logSoloJester: "{{name}} 打出小丑",
			m13: "常青模式",
			evgTitle: "常青模式(随机任务)",
			evgReroll: "重新随机",
			evgNormal: "普通",
			evgHard: "困难(双红咒)",
			evgPreset: "官方预设",
			evgMercBudget: "佣兵(预算 5 金币)",
			evgLocA: "神殿",
			evgLocB: "洞窟",
			evgLocC: "森林",
			evgLocD: "丘陵",
			evgLocE: "湖泊",
			evgCurse1: "六首之替",
			evgCurse2: "疗养日",
			evgCurse3: "十二种死法",
			evgCurse4: "腐蚀之种",
			evgCurse5: "米拉归来",
			evgCurse6: "满月",
			evgCurse7: "至日",
			evgCurse8: "往昔亡魂",
			evgCurse9: "致命战士",
			evgCurse10: "剧毒牧师",
			evgCurse11: "不动圣骑",
			evgCurse12: "双面吟游",
			evgCurse13: "爆裂孢子",
			evgCurse14: "吸收",
			evgCurse15: "小心脚下",
			evgCurse16: "萦绕恐惧",
			evgCurse17: "野兽活力",
			evgCurse18: "变异兽群",
			evgCurse19: "变形",
			evgCurse20: "融合之骨",
			evgCurse21: "齐眉棍影",
			evgCurse22: "烈焰熔炉",
			evgCurse23: "自择其毒",
			evgBoon24: "这位是贵族,先生",
			evgBoon25: "他们有两个!",
			evgBoon26: "求援",
			evgBoon27: "太简单了!",
			evgBoon28: "挚友",
			evgBoon29: "第二顿早餐",
			evgBoon30: "手足小队",
			evgBoon31: "无私救援",
			evgBoon32: "精准打击",
			evgBoon33: "回收箭矢",
			evgBoon34: "同盟",
			evgBoon35: "千钧一发",
			promptSquadMove: "手足小队:可把任务区 1 张同值卡移入弃牌堆",
			promptRescueMove: "无私救援:可把任务区 1 张同值卡移入弃牌堆",
			promptStrikePick: "精准打击:从任务区选 1 卡入手,或取弃牌堆顶",
			promptArrowsPick: "回收箭矢:可从放逐区选 1 卡放库底",
			promptCloseCall: "千钧一发:从弃牌堆选 1 卡放上库顶(必选)",
			promptPoisonPick: "自择其毒:可弃 1 张手牌,否则库顶 1 张入任务区",
			logSquadMove: "{{name}} 手足小队移回 1 张",
			logRescueMove: "{{name}} 无私救援移回 1 张",
			logStrikePick: "{{name}} 精准打击取回 1 张",
			logArrowsPick: "{{name}} 回收 1 支箭矢",
			logCloseCall: "{{name}} 千钧一发救回 1 张",
			logPoisonPick: "{{name}} 自择其毒",
			logEvgPurge: "洞窟坍塌:任务区与弃牌堆全放逐",
			logEvgDread: "萦绕恐惧:弃牌堆顶被放逐",
			errDone: "对局已结束",
			errNotYourTurn: "现在轮不到你",
			errBadCards: "这些牌不在可选范围",
			errBadCombo: "这组牌出不了",
			errDefendMore: "弃牌合计还不够",
			errDefendExtra: "承伤要逐张弃,凑够即停",
			errNoJester: "没有可用的小丑",
			errPending: "先处理当前效果",
			errBadChoice: "无效的选择",
			errYieldBlocked: "上一轮全员跳过,不能连续跳过",
			errNoRelic: "还没有这件神器",
			errFluteUsed: "本回合已堆过笛"
		},
		en: {
			name: "Regicide Legacy",
			desc: "A 12-mission co-op legacy campaign: your party evolves with corruption, mercenaries and relics",
			rules: "Goal: cooperate to defeat every enemy of the mission; if any player cannot suffer the damage, the whole party falls.\nOn your turn:\n· Play a card to attack; or a same-value combo (totalling no more than 10), or an Animal/Beast with 1 partner; or yield and take the hit.\n· Suits: Cleric shuffles the discard and tucks cards under the deck; Bard refills hands around the table; Warrior doubles damage; Paladin permanently reduces enemy attack.\n· If the enemy survives it strikes back: discard cards totaling at least its attack; discarding a full hand (Feign Death) covers any amount.\n· Enemies are immune to their own suit: that suit only deals damage; a claimed Jester attack ignores immunity.\nCampaign twists:\n· Corrupted cards banish the top of the deck when played and ignore immunity.\n· Mages tuck chained flips; Guardians block all damage that turn; Druids redistribute the discard; Chanters draw freely from the deck.\n· Losing earns gold to hire mercenaries for the next attempt; winning missions unlocks new suits, relics and cards.",
			m1: "Call to Arms",
			m2: "Shadow and Mist",
			m3: "Lessons in Flames",
			m4: "Fusion of Darkness",
			m5: "High and Mighty",
			m6: "Shards of Memory",
			m7: "Tales of Rebirth",
			m8: "Winds of Chaos",
			m9: "Hope From Ashes",
			m10: "Pride to Fall",
			m11: "Descent Into Darkness",
			m12: "Decay to Growth",
			enemy: {
				justicar: "Justicar",
				hydra: "Hydra Head",
				instructor: "Flame Instructor",
				professor: "Flame Professor",
				dean: "Flame Dean",
				experiment: "Experiment",
				sporite: "Sporite",
				umbrispore: "Umbrispore",
				statue: "Statue",
				gardenstatue: "Garden Statue",
				shallowkin: "Shallow Pondkin",
				deepkin: "Deep Pondkin",
				abysskin: "Abyssal Pondkin",
				troll: "Troll",
				wyvern: "Wyvern",
				loreguard: "Loreguard",
				lorekeeper: "Lorekeeper",
				myla: "Myla",
				corrupted2: "Corrupted Gnome",
				corrupted3: "Corrupted Halfling",
				corrupted4: "Corrupted Dwarf",
				corrupted5: "Corrupted Avian",
				corrupted6: "Corrupted Human",
				corrupted7: "Corrupted Elf",
				corrupted8: "Corrupted Feltrix",
				corrupted9: "Corrupted Dragonian",
				mutant: "Mutant Justicar",
				vid: "Eternal Vid",
				mutantqueen: "Mutant Queen",
				mutantking: "Mutant King",
				arcana: "Supreme Arcana"
			},
			cardRaceGnome: "Gnome",
			cardRaceHalfling: "Halfling",
			cardRaceDwarf: "Dwarf",
			cardRaceAvian: "Avian",
			cardRaceHuman: "Human",
			cardRaceElf: "Elf",
			cardRaceFeltrix: "Feltrix",
			cardRaceDragonian: "Dragonian",
			cardRaceMazcari: "Mazcari",
			cardJester: "Jester",
			cardUnaligned: "Unaligned",
			cardPilgrim: "Pilgrim",
			cardBeast: "{{suit}} Beast",
			cardAnimal: "{{suit}} Animal",
			cardCorrupted: "Corrupted",
			cardReborn: "Reborn",
			cardDual: "Second suit: {{suit}}",
			cardApprentice: "Mage Apprentice",
			healthLabel: "HP",
			corruptStamp: "C",
			handLabel: "Your hand",
			handCount: "{{n}} cards",
			selectedPower: "Power {{n}}",
			selectedCount: "{{n}} selected",
			missionLabel: "Mission {{n}}",
			pileEnemyLabel: "Enemies",
			pileReserveLabel: "Deck",
			pileDiscardLabel: "Discard",
			pileBanishLabel: "Banished",
			valueChoice: "Choose card value: {{n}}",
			decreaseCount: "Decrease count",
			increaseCount: "Increase count",
			waitingAction: "Waiting for other players",
			suitW: "Warrior",
			suitC: "Cleric",
			suitB: "Bard",
			suitP: "Paladin",
			suitF: "Mage",
			suitMu: "Reaver",
			suitRo: "Guardian",
			suitFe: "Druid",
			suitDr: "Chanter",
			suitEv: "Evergreen",
			relicFlute: "Tribal Flute",
			relicWhistle: "Crimson Whistle",
			relicEmblem: "Azure Emblem",
			relicMotherC: "Evergreen Mother (Corrupted)",
			relicMotherR: "Evergreen Mother (Restored)",
			turnYou: "Your turn: attack or yield",
			turnWait: "Waiting for {{name}}…",
			defendYou: "Suffer {{n}}: discard cards totaling ≥ {{n}}",
			defendWait: "Waiting for {{name}} to suffer…",
			defendKindMyla: "Myla strikes back!",
			defendKindBacklash: "Exact-kill backlash!",
			phaseChoice: "Resolving effects…",
			enemyHp: "HP {{hp}}/{{max}}",
			enemyAtk: "ATK {{n}}",
			immuneChip: "Immune {{suit}}",
			shieldChip: "Shield -{{n}}",
			pileReserve: "Deck {{n}}",
			pileDiscard: "Discard {{n}}",
			pileBanish: "Banish {{n}}",
			pileEnemy: "Enemies {{n}}",
			zoneLabel: "Mission zone",
			zoneDownLabel: "Face-down {{n}}",
			fluteLabel: "Tribal Flute",
			matLabel: "Mat",
			kills: "Defeated {{n}}",
			handEmpty: "Hand empty",
			lockedChip: "Locked",
			tuckedChip: "Tucked",
			play: "Attack",
			yieldBtn: "Yield (take the hit)",
			defendBtn: "Discard to suffer",
			feignBtn: "Feign Death (discard all)",
			defendTeam: "Team suffer: the party discards cards totaling ≥ {{n}} (anyone may pitch in)",
			surrenderBtn: "Concede defeat",
			surrenderConfirm: "Confirm defeat?",
			jesterPlay: "Play Jester",
			jesterClaim: "Claim Jester",
			cancel: "Cancel",
			confirm: "Confirm",
			skip: "Skip",
			soloJester: "Play Jester ({{n}} left)",
			fluteAdd: "Stack onto Flute",
			whistleTakeTop: "Take discard top",
			motherBanishDeck: "Banish deck top",
			motherBanishDiscard: "Banish discard top",
			pilgrimBanish: "Banish Pilgrim",
			promptMagePick: "Mage: tuck 1 card (tucking a Mage flips again)",
			promptReaverCount: "Reaver: declare a flip count; pick 1 to add damage, all flips are banished",
			promptReaverPick: "Reaver: pick 1 to add its value to this damage; the rest are banished",
			promptWhistleGive: "Whistle: add 1 non-Jester hand card to this attack (optional)",
			promptFluteGive: "Flute: add hand cards matching the attack value (total ≤ 10, optional)",
			promptEmblemGive: "Emblem: put 1 hand card on the deck top (optional)",
			promptEmblemReturn: "Emblem: return 1 card to the deck top; the rest are discarded (optional)",
			promptMotherGive: "Evergreen Mother: banish 1 of your hand cards",
			promptMotherSolo: "Evergreen Mother: banish the deck top, or the discard top instead",
			promptDruidAssign: "Druid: assign your dealt cards (hand / banish / top / bottom, up to 1 each)",
			promptChanterDraw: "Chanter: declare a count; every player draws that many",
			promptDiscardDown: "Over hand limit: discard down to {{n}}",
			promptBardTake: "Give up 1 hand card",
			promptMylaPick: "Move 1 mat card into the zone",
			promptRescue: "Rescue: banish 1 hand card to save 1 face-up card, or skip to rotate",
			promptChainMove: "Chain: move ascending mat cards into the zone (optional)",
			promptCull: "Mazcari enters: banish any discard cards, rest go under the deck",
			promptZonePick: "Pick 1 zone card (optional)",
			promptDiscardPick: "Exact kill: put 1 discard card on the deck top",
			druidHand: "Hand",
			druidBanish: "Banish",
			druidTop: "Top",
			druidBottom: "Bottom",
			overWin: "Mission complete!",
			overLose: "The party has fallen…",
			overProgress: "Defeated {{n}} enemies",
			overReward: "Campaign rewards",
			overApply: "Apply rewards",
			overApplied: "Applied",
			overGold: "Gained {{n}} gold",
			overCorruptHit: "Corruption strikes (random)",
			overDualPick: "Dual seals: pick a second suit for each of these 4 cards",
			overSealPick: "Class seal: choose 1 card to receive the {{cls}} seal",
			overApprenticePick: "Mage apprentice: choose the race to train (a random unsealed card)",
			raceDwarf: "Dwarf (4)",
			raceFeltrix: "Feltrix (8)",
			overApprenticeHit: "Apprentice chosen",
			overTearPick: "Story event: the Eternal Vow dons the green cloak — tear 1 corrupted card",
			campTitle: "Campaign",
			campMission: "Mission {{n}}",
			campCompleted: "Completed",
			campGold: "Gold {{n}}",
			campMercShop: "Mercenary shop (unspent gold is lost at start; mercs survive defeat, swap freely at equal cost)",
			campMercCost: "{{n}} gold",
			campBeastPick: "Choose your Beast",
			campLosses: "{{n}} losses on this mission",
			mercM12: "Elite Mercenary",
			mercM25: "Dual Mercenary",
			mercM19: "Heavy Mercenary",
			mercWild: "Beast Mercenary",
			mercJester: "Jester Mercenary",
			mercBuy: "Hire",
			mercSell: "Dismiss",
			campSummary: "Corrupted {{c}} · Dual {{d}} · Apprentice {{a}} · Party {{p}} cards",
			logStart: "Mission {{n}} begins",
			logPlay: "{{name}} played {{n}} card(s)",
			logDamage: "{{dmg}} damage",
			logSlain: "Enemy defeated",
			logSlainExact: "Exact kill!",
			logYield: "{{name}} yielded",
			logDefend: "{{name}} discarded {{n}} to suffer",
			logFallen: "{{name}} could not suffer — the party falls",
			logJester: "{{name}} played a Jester",
			logJesterClaim: "{{name}} claimed the Jester",
			logHeal: "{{n}} tucked under the deck",
			logShieldUp: "Enemy ATK -{{n}}",
			logMagePick: "{{name}} tucked a card",
			logReaverPick: "{{name}} reaves double",
			logWhistlePick: "{{name}} called a partner",
			logFluteGive: "{{name}} joined via Flute",
			logEmblemGive: "{{name}} put 1 on the deck top",
			logMotherPeek: "{{name}} banished 1",
			logDruidAssign: "{{name}} redistributed the discard",
			logChanterDraw: "{{name}} drew {{n}}",
			logDiscardDown: "{{name}} discarded to limit",
			logBardTake: "{{name}} gave up 1",
			logMyla: "Myla strikes {{dmg}}",
			logRescue: "{{name}} rescued 1",
			logRotate: "Piles rotate",
			logChainMove: "{{name}} chained {{n}}",
			logCull: "{{name}} banished {{n}}",
			logDiscardPick: "{{name}} put 1 on deck top",
			logZoneFlip: "A card flips into the zone",
			logBeastFlip: "A beast flips",
			logM7Drain: "{{n}} discarded from the deck",
			logFluteAdd: "{{name}} stacked the Flute",
			logPilgrimBanish: "{{name}} banished a pilgrim",
			logSoloJester: "{{name}} played a Jester",
			m13: "Evergreen",
			evgTitle: "Evergreen Mode (random scenario)",
			evgReroll: "Reroll",
			evgNormal: "Normal",
			evgHard: "Hard (double red)",
			evgPreset: "Official presets",
			evgMercBudget: "Mercenaries (5 gold budget)",
			evgLocA: "Temple",
			evgLocB: "Cave",
			evgLocC: "Forest",
			evgLocD: "Hills",
			evgLocE: "Lake",
			evgCurse1: "Six Is the New Four",
			evgCurse2: "Mental Health Day",
			evgCurse3: "A Dozen Ways to Die",
			evgCurse4: "Seeds of Corruption",
			evgCurse5: "Somehow, Myla Returned",
			evgCurse6: "Full Moon",
			evgCurse7: "Solstice",
			evgCurse8: "Ghosts from the Past",
			evgCurse9: "Lethal Warriors",
			evgCurse10: "Poisonous Clerics",
			evgCurse11: "Immovable Paladins",
			evgCurse12: "Duplicitous Bards",
			evgCurse13: "Explosive Spores",
			evgCurse14: "Absorbtion",
			evgCurse15: "Tread Carefully",
			evgCurse16: "Lingering Dread",
			evgCurse17: "Beastly Vigor",
			evgCurse18: "Mutated Beasts",
			evgCurse19: "Shapeshift",
			evgCurse20: "Fused Bones",
			evgCurse21: "Eye-Level Sticks",
			evgCurse22: "The Fiery Crucible",
			evgCurse23: "Choose Your Poison",
			evgBoon24: "This Is Noble, Sir",
			evgBoon25: "There Are Two of Them!",
			evgBoon26: "Call for Help",
			evgBoon27: "Too Easy!",
			evgBoon28: "Best Friend",
			evgBoon29: "Second Breakfast",
			evgBoon30: "Squad of Siblings",
			evgBoon31: "Selfless Rescue",
			evgBoon32: "Precision Strike",
			evgBoon33: "Restored Arrows",
			evgBoon34: "An Alliance",
			evgBoon35: "A Close Call",
			promptSquadMove: "Squad of Siblings: you may move 1 matching-value zone card to the discard",
			promptRescueMove: "Selfless Rescue: you may move 1 matching-value zone card to the discard",
			promptStrikePick: "Precision Strike: take 1 zone card into hand, or take the discard top",
			promptArrowsPick: "Restored Arrows: you may move 1 banished card to the deck bottom",
			promptCloseCall: "A Close Call: choose 1 discard card for the deck top (required)",
			promptPoisonPick: "Choose Your Poison: discard 1 hand card, or the deck top enters the zone",
			logSquadMove: "{{name}} moved 1 card back (Squad of Siblings)",
			logRescueMove: "{{name}} moved 1 card back (Selfless Rescue)",
			logStrikePick: "{{name}} took 1 card (Precision Strike)",
			logArrowsPick: "{{name}} restored 1 arrow",
			logCloseCall: "{{name}} saved 1 card (A Close Call)",
			logPoisonPick: "{{name}} chose their poison",
			logEvgPurge: "The cave collapses: zone and discard all banished",
			logEvgDread: "Lingering Dread: discard top banished",
			errDone: "Game over",
			errNotYourTurn: "Not your turn",
			errBadCards: "Those cards are not selectable",
			errBadCombo: "Illegal combo",
			errDefendMore: "Not enough to suffer",
			errDefendExtra: "Discard one at a time; stop once covered",
			errNoJester: "No Jester available",
			errPending: "Resolve the current effect first",
			errBadChoice: "Invalid choice",
			errYieldBlocked: "Everyone yielded last round",
			errNoRelic: "Relic not owned",
			errFluteUsed: "Flute already used this turn"
		}
	}
};
//#endregion
export { Qt as default };
