import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconClose as u, IconLog as d } from "@bgparty/sdk/icons";
import { playTurn as f, useSoundEdge as p } from "@bgparty/sdk/sfx";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { Floater as v, FlySprite as y } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as b } from "@bgparty/sdk/confirm-button";
import { OptionSwitch as x } from "@bgparty/sdk/ui/game-options";
//#region src/games/modernart/data.ts
var S = [
	{
		name: "Manuel Carvalho",
		short: "Carvalho",
		color: "#f1d52d",
		count: 12
	},
	{
		name: "Sigrid Thaler",
		short: "Thaler",
		color: "#53aed0",
		count: 13
	},
	{
		name: "Daniel Melim",
		short: "Melim",
		color: "#e95446",
		count: 14
	},
	{
		name: "Ramon Martins",
		short: "Martins",
		color: "#83ad49",
		count: 15
	},
	{
		name: "Rafael Silveira",
		short: "Silveira",
		color: "#e8a131",
		count: 16
	}
], C = [
	[1, "open"],
	[1, "open"],
	[1, "once"],
	[1, "once"],
	[1, "hidden"],
	[1, "open"],
	[1, "hidden"],
	[1, "double"],
	[1, "fixed"],
	[1, "fixed"],
	[1, "fixed"],
	[1, "hidden"],
	[2, "open"],
	[2, "open"],
	[2, "open"],
	[2, "once"],
	[1, "double"],
	[2, "once"],
	[4, "hidden"],
	[4, "hidden"],
	[4, "once"],
	[4, "hidden"],
	[0, "open"],
	[0, "open"],
	[0, "once"],
	[0, "once"],
	[0, "once"],
	[0, "open"],
	[0, "hidden"],
	[0, "double"],
	[0, "double"],
	[0, "fixed"],
	[0, "fixed"],
	[0, "hidden"],
	[2, "hidden"],
	[2, "hidden"],
	[2, "hidden"],
	[2, "fixed"],
	[2, "fixed"],
	[2, "once"],
	[2, "fixed"],
	[3, "open"],
	[3, "open"],
	[3, "open"],
	[2, "double"],
	[2, "double"],
	[3, "once"],
	[3, "once"],
	[3, "hidden"],
	[3, "hidden"],
	[3, "hidden"],
	[4, "open"],
	[4, "open"],
	[4, "open"],
	[4, "once"],
	[4, "once"],
	[4, "open"],
	[3, "fixed"],
	[3, "double"],
	[3, "double"],
	[3, "fixed"],
	[3, "fixed"],
	[3, "double"],
	[4, "fixed"],
	[4, "double"],
	[4, "double"],
	[4, "double"],
	[4, "fixed"],
	[4, "fixed"],
	[3, "once"]
].map(([e, t], n) => ({
	id: n,
	artist: e,
	kind: t
})), w = {
	open: "games.modernart.open",
	once: "games.modernart.once",
	hidden: "games.modernart.hidden",
	fixed: "games.modernart.fixed",
	double: "games.modernart.double"
}, T = (e) => C[e], E = {
	id: "modernart",
	tier: "alpha",
	mechanics: ["auction", "hand-management"],
	interactionTags: [],
	nameKey: "games.modernart.name",
	descKey: "games.modernart.desc",
	rulesKey: "games.modernart.rules",
	icon: "🖼️",
	iconImg: "games/modernart.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/45707916999772903/08834AD992DF77791A4C4634242D599CDFEE408F/" },
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [4, 5],
	accent: "#e9bd20",
	releasedAt: "2026-11-04T00:31:37+08:00",
	search: {
		py: "xian dai yi shu",
		init: "xdys"
	},
	hotseat: "cover",
	botDelayMs: 500
}, D = t.int().min(0).max(69), O = t.int().min(0).max(1e5), k = t.object({ mystery: t.boolean().default(!1) }).default({ mystery: !1 }), A = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("offer"),
		card: D
	}),
	t.object({
		type: t.literal("pair"),
		card: D
	}),
	t.object({
		type: t.literal("bid"),
		amount: O
	}),
	t.object({
		type: t.literal("price"),
		amount: O
	}),
	t.object({ type: t.literal("buy") }),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("mystery"),
		reveal: t.boolean()
	}),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), j = t.enum([
	"offer",
	"show",
	"double",
	"open",
	"once",
	"hidden",
	"reveal",
	"price",
	"fixed",
	"award",
	"mystery",
	"mysteryReveal",
	"settle",
	"roundOver",
	"done"
]), M = t.object({
	round: t.int(),
	counts: t.array(t.int()),
	values: t.array(t.int()),
	ranks: t.array(t.int()),
	revenue: t.record(t.string(), t.int())
}), N = t.object({
	phase: j,
	round: t.int(),
	turn: t.string(),
	seller: t.string(),
	lot: t.array(D),
	kind: t.enum([
		"open",
		"once",
		"hidden",
		"fixed",
		"double"
	]).nullable(),
	high: O,
	bidder: t.string().nullable(),
	fixedPrice: O,
	counts: t.array(t.int()),
	history: t.array(M),
	players: t.array(t.object({
		rid: t.string(),
		handCount: t.int(),
		paintings: t.array(D),
		cash: O.nullable(),
		ready: t.boolean()
	})),
	revealedBids: t.record(t.string(), O).nullable(),
	lastSale: t.object({
		seller: t.string(),
		buyer: t.string(),
		amount: O,
		cards: t.array(D)
	}).nullable(),
	mysteryCount: t.int(),
	mysteryEnabled: t.boolean(),
	mysteryCard: D.nullable(),
	log: t.array(t.object({
		kind: t.enum([
			"offer",
			"sale",
			"round",
			"mystery"
		]),
		rid: t.string(),
		cards: t.array(D),
		amount: O,
		round: t.int()
	}))
}), P = t.object({
	hand: t.array(D),
	outgoing: t.object({
		card: D,
		index: t.int()
	}).nullable(),
	cash: O,
	bid: O.nullable(),
	canAct: t.boolean()
}), F = () => ({ code: "games.modernart.invalid" }), I = (e, t) => e.players[t % e.players.length], L = (e) => e.players.reduce((t, n) => t + e.hands[n].length, 0), R = (e, t) => (t + 1) % e.players.length;
function z(e, t, n, r = [], i = 0) {
	e.log.push({
		kind: t,
		rid: n,
		cards: [...r],
		amount: i,
		round: e.round
	});
}
function B(e, t, n) {
	return [{
		kind: e,
		rid: t,
		data: n
	}];
}
function V(e) {
	let t = ({
		3: [
			10,
			6,
			6,
			0
		],
		4: [
			9,
			4,
			4,
			0
		],
		5: [
			8,
			3,
			3,
			0
		]
	}[e.config.mystery ? 4 : e.players.length] ?? [])[e.round - 1] ?? 0, n = [];
	for (let r of e.players) {
		let i = e.deck.splice(0, t);
		e.hands[r].push(...i), i.length && n.push({
			kind: "ma-deal",
			rid: r,
			data: { count: i.length },
			for: [r],
			secret: { cards: i },
			...n.length ? { with: !0 } : {}
		});
	}
	return e.config.mystery && e.mystery.push(...e.deck.splice(0, t)), n;
}
function H(e) {
	e.lot = [], e.kind = null, e.high = 0, e.bidder = null, e.bids = {}, e.ready = [], e.fixedPrice = 0, e.mysteryCard = null, e.outgoing = null, e.turn = e.nextSeller;
	for (let t = 0; t < e.players.length && e.hands[I(e, e.turn)].length === 0; t++) e.turn = R(e, e.turn);
	e.seller = e.turn, e.phase = "offer";
}
function U(e) {
	e.afterShow = e.phase, e.phase = "show";
}
function W(e) {
	let t = [
		0,
		1,
		2,
		3,
		4
	].filter((t) => e.counts[t] > 0).sort((t, n) => e.counts[n] - e.counts[t] || t - n).slice(0, 3), n = [
		0,
		0,
		0,
		0,
		0
	];
	t.forEach((e, t) => {
		n[e] = 30 - t * 10;
	});
	let r = n.map((t, n) => t === 0 ? 0 : t + e.history.reduce((e, t) => e + (t.ranks.indexOf(n) === -1 ? 0 : 30 - t.ranks.indexOf(n) * 10), 0)), i = Object.fromEntries(e.players.map((t) => [t, e.owned[t].reduce((e, t) => e + r[T(t).artist], 0)]));
	e.history.push({
		round: e.round,
		counts: [...e.counts],
		values: r,
		ranks: t,
		revenue: i
	}), e.phase = "settle", e.settleIndex = 0, e.ready = [], z(e, "round", "");
}
function G(e, t, n) {
	return e.outgoing = {
		by: t,
		card: n,
		index: e.hands[t].indexOf(n)
	}, e.hands[t].splice(e.hands[t].indexOf(n), 1), e.lot.push(n), e.played.push(n), e.counts[T(n).artist]++, z(e, "offer", t, [n]), e.earlyEnd = L(e) === 0, e.counts[T(n).artist] >= 5 || e.earlyEnd ? (e.nextSeller = R(e, e.seller), W(e), !0) : !1;
}
function K(e, t) {
	e.kind = t, e.high = 0, e.bidder = null, e.ready = [], e.bids = {}, e.fixedPrice = 0, e.phase = t === "fixed" ? "price" : t, e.turn = t === "once" ? R(e, e.seller) : e.seller;
}
function q(e, t, n) {
	let r = I(e, e.seller);
	return e.cash[t] -= n, t !== r && (e.cash[r] += n), e.owned[t].push(...e.lot), e.lastSale = {
		seller: r,
		buyer: t,
		amount: n,
		cards: [...e.lot]
	}, e.phase = "award", e.nextSeller = R(e, e.seller), z(e, "sale", t, e.lot, n), B("ma-sale", t, {
		cards: [...e.lot],
		amount: n,
		seller: r
	});
}
function J(e) {
	e.config.mystery && e.mystery.length > 0 ? (e.phase = "mystery", e.turn = e.seller, e.lot = [], e.kind = null) : H(e);
}
function Y(e) {
	if (e.turn = R(e, e.turn), e.turn === e.seller) return q(e, I(e, e.seller), 0);
}
function X(e, t) {
	return e.phase === "open" ? !e.ready.includes(t) && e.bidder !== t : e.phase === "hidden" || e.phase === "roundOver" ? !e.ready.includes(t) : [
		"offer",
		"double",
		"once",
		"price",
		"fixed",
		"mystery"
	].includes(e.phase) && I(e, e.turn) === t;
}
var te = {
	meta: E,
	saveCompatibility: { version: "1" },
	schemas: {
		action: A,
		publicView: N,
		privateView: P,
		config: k
	},
	setup(t, n, r) {
		let i = k.parse(t);
		n.length !== 3 && (i.mystery = !1);
		let a = Array.from({ length: 70 }, (e, t) => t), o = 0;
		for (let t = a.length - 1; t > 0; t--) {
			let n = e(r, o++, t + 1);
			[a[t], a[n]] = [a[n], a[t]];
		}
		let s = {
			players: [...n],
			seed: r,
			cursor: o,
			config: i,
			round: 1,
			phase: "offer",
			turn: 0,
			seller: 0,
			hands: Object.fromEntries(n.map((e) => [e, []])),
			cash: Object.fromEntries(n.map((e) => [e, 100])),
			owned: Object.fromEntries(n.map((e) => [e, []])),
			deck: a,
			mystery: [],
			lot: [],
			kind: null,
			counts: [
				0,
				0,
				0,
				0,
				0
			],
			played: [],
			discarded: [],
			high: 0,
			bidder: null,
			fixedPrice: 0,
			bids: {},
			ready: [],
			history: [],
			lastSale: null,
			mysteryCard: null,
			log: [],
			nextSeller: 0,
			settleIndex: 0,
			earlyEnd: !1,
			afterShow: null,
			outgoing: null
		}, c = V(s);
		return U(s), {
			state: s,
			fx: c
		};
	},
	reduce(e, t, { by: n }) {
		if (t.type === "tick") {
			if (![
				"show",
				"reveal",
				"award",
				"mysteryReveal",
				"settle"
			].includes(e.phase)) return { state: e };
			let t = structuredClone(e);
			if (t.phase === "show") return t.phase = t.afterShow, t.afterShow = null, { state: t };
			if (t.phase === "mysteryReveal") return H(t), { state: t };
			if (t.phase === "reveal") {
				let e = [t.seller, ...Array.from({ length: t.players.length - 1 }, (e, n) => (t.seller + n + 1) % t.players.length)], n = e.reduce((e, n) => t.bids[I(t, n)] > t.bids[I(t, e)] ? n : e, e[0]);
				return {
					state: t,
					fx: q(t, I(t, n), t.bids[I(t, n)])
				};
			}
			if (t.phase === "award") return J(t), { state: t };
			if (t.settleIndex === t.players.length) return t.discarded.push(...t.played), t.played = [], t.lot = [], t.kind = null, t.phase = t.round === 4 || t.earlyEnd ? "done" : "roundOver", t.ready = [], { state: t };
			let n = t.players[t.settleIndex++], r = t.history.at(-1).revenue[n], i = [...t.owned[n]];
			return t.cash[n] += r, t.owned[n] = [], {
				state: t,
				fx: B("ma-income", n, {
					amount: r,
					cards: i
				})
			};
		}
		if (!e.players.includes(n) || e.phase === "done") return F();
		let r = structuredClone(e), i = r.players.indexOf(n);
		if (t.type === "next" && r.phase === "roundOver" && !r.ready.includes(n)) {
			if (r.ready.push(n), r.ready.length === r.players.length) {
				r.round++, r.counts = [
					0,
					0,
					0,
					0,
					0
				], r.lastSale = null;
				let e = V(r);
				return H(r), e.length && U(r), {
					state: r,
					fx: e
				};
			}
			return { state: r };
		}
		if (t.type === "offer" && r.phase === "offer" && i === r.turn && r.hands[n].includes(t.card)) return r.lastSale = null, r.seller = i, G(r, n, t.card) ? (U(r), {
			state: r,
			fx: B("ma-offer", n, { cards: [t.card] })
		}) : (T(t.card).kind === "double" ? (r.phase = "double", r.kind = "double", r.turn = i) : K(r, T(t.card).kind), U(r), {
			state: r,
			fx: B("ma-offer", n, { cards: [t.card] })
		});
		if (r.phase === "double" && i === r.turn) return t.type === "pass" ? {
			state: r,
			fx: Y(r)
		} : t.type === "pair" && r.hands[n].includes(t.card) && T(t.card).artist === T(r.lot[0]).artist && T(t.card).kind !== "double" ? (r.seller = i, G(r, n, t.card) || K(r, T(t.card).kind), U(r), {
			state: r,
			fx: B("ma-offer", n, { cards: [t.card] })
		}) : F();
		if (t.type === "bid" && t.amount <= r.cash[n]) {
			if (r.phase === "hidden" && !r.ready.includes(n)) return r.bids[n] = t.amount, r.ready.push(n), r.ready.length === r.players.length && (r.phase = "reveal"), { state: r };
			if ((r.phase === "open" || r.phase === "once" && r.turn === i) && t.amount > r.high) {
				if (r.high = t.amount, r.bidder = n, r.phase === "once") {
					if (i === r.seller) return {
						state: r,
						fx: q(r, n, t.amount)
					};
					r.turn = R(r, r.turn);
				} else r.ready = [n];
				return { state: r };
			}
		}
		if (t.type === "pass" && r.phase === "open" && !r.ready.includes(n)) return r.ready.push(n), r.ready.length === r.players.length ? {
			state: r,
			fx: q(r, r.bidder ?? I(r, r.seller), r.high)
		} : { state: r };
		if (t.type === "pass" && r.phase === "once" && r.turn === i) return i === r.seller ? {
			state: r,
			fx: q(r, r.bidder ?? n, r.high)
		} : (r.turn = R(r, r.turn), { state: r });
		if (t.type === "price" && r.phase === "price" && i === r.seller && t.amount <= r.cash[n]) return r.fixedPrice = t.amount, r.phase = "fixed", r.turn = R(r, r.seller), { state: r };
		if (r.phase === "fixed" && i === r.turn) {
			if (t.type === "buy" && r.cash[n] >= r.fixedPrice) return {
				state: r,
				fx: q(r, n, r.fixedPrice)
			};
			if (t.type === "pass") return r.turn = R(r, r.turn), r.turn === r.seller ? {
				state: r,
				fx: q(r, I(r, r.seller), r.fixedPrice)
			} : { state: r };
		}
		if (t.type === "mystery" && r.phase === "mystery" && i === r.turn) {
			if (t.reveal && r.mystery.length) {
				let e = r.mystery.shift();
				return r.mysteryCard = e, r.played.push(e), r.counts[T(e).artist]++, z(r, "mystery", n, [e]), r.counts[T(e).artist] >= 5 ? W(r) : r.phase = "mysteryReveal", U(r), {
					state: r,
					fx: B("ma-offer", n, {
						cards: [e],
						mystery: 1
					})
				};
			}
			return H(r), { state: r };
		}
		return F();
	},
	viewFor(e, t) {
		return {
			public: {
				phase: e.phase,
				round: e.round,
				turn: I(e, e.turn),
				seller: I(e, e.seller),
				lot: [...e.lot],
				kind: e.kind,
				high: e.high,
				bidder: e.bidder,
				fixedPrice: e.fixedPrice,
				counts: [...e.counts],
				history: e.history,
				players: e.players.map((t) => ({
					rid: t,
					handCount: e.hands[t].length,
					paintings: [...e.owned[t]],
					cash: e.phase === "done" ? e.cash[t] : null,
					ready: e.ready.includes(t)
				})),
				revealedBids: e.phase === "reveal" ? { ...e.bids } : null,
				lastSale: e.lastSale,
				mysteryCount: e.mystery.length,
				mysteryEnabled: e.config.mystery,
				mysteryCard: e.mysteryCard,
				log: e.log
			},
			private: e.players.includes(t) ? {
				hand: [...e.hands[t]],
				outgoing: e.phase === "show" && e.mysteryCard === null && e.outgoing?.by === t ? {
					card: e.outgoing.card,
					index: e.outgoing.index
				} : null,
				cash: e.cash[t],
				bid: e.bids[t] ?? null,
				canAct: X(e, t)
			} : void 0
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => e.cash[n] - e.cash[t]);
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((n) => e.cash[n] === e.cash[t[0]]),
			scores: { ...e.cash }
		};
	},
	nextTickIn(e) {
		return [
			"show",
			"reveal",
			"award",
			"mysteryReveal",
			"settle"
		].includes(e.phase) ? 650 : null;
	}
};
//#endregion
//#region src/games/modernart/auction-icon.tsx
function Z({ kind: e, size: t = 24 }) {
	return /* @__PURE__ */ _(h, { children: [
		e === "open" && /* @__PURE__ */ g("svg", {
			viewBox: "0 0 63 38",
			width: t,
			height: t,
			"aria-hidden": "true",
			fill: "currentColor",
			children: /* @__PURE__ */ g("path", {
				fillRule: "evenodd",
				d: "M35.0,35.5L25.0,35.5L24.0,34.5L21.0,34.5L20.0,33.5L19.0,33.5L18.0,32.5L16.0,32.5L15.0,31.5L14.0,31.5L13.0,30.5L12.0,30.5L10.0,28.5L9.0,28.5L6.0,25.5L5.0,25.5L-0.5,20.0L-0.5,16.0L4.0,11.5L5.0,11.5L8.0,8.5L9.0,8.5L11.0,6.5L12.0,6.5L14.0,4.5L15.0,4.5L16.0,3.5L18.0,3.5L19.0,2.5L20.0,2.5L21.0,1.5L25.0,1.5L26.0,0.5L35.0,0.5L36.0,1.5L39.0,1.5L40.0,2.5L42.0,2.5L43.0,3.5L44.0,3.5L45.0,4.5L46.0,4.5L47.0,5.5L48.0,5.5L49.0,6.5L50.0,6.5L53.0,9.5L54.0,9.5L61.5,17.0L61.5,19.0L53.0,27.5L52.0,27.5L50.0,29.5L49.0,29.5L48.0,30.5L47.0,30.5L46.0,31.5L45.0,31.5L44.0,32.5L43.0,32.5L42.0,33.5L40.0,33.5L39.0,34.5L36.0,34.5L35.0,35.5ZM34.5,30.0L35.0,29.5L38.0,29.5L39.0,28.5L41.0,28.5L42.0,27.5L43.0,27.5L44.0,26.5L45.0,26.5L47.0,24.5L48.0,24.5L50.0,22.5L51.0,22.5L55.5,18.0L52.0,14.5L51.0,14.5L48.0,11.5L47.0,11.5L45.0,9.5L44.0,9.5L43.0,8.5L42.0,8.5L41.0,7.5L39.0,7.5L38.0,6.5L34.0,6.5L33.0,5.5L27.0,5.5L26.0,6.5L23.0,6.5L22.0,7.5L20.0,7.5L19.0,8.5L18.0,8.5L17.0,9.5L16.0,9.5L15.0,10.5L14.0,10.5L11.0,13.5L10.0,13.5L5.5,18.0L11.0,23.5L12.0,23.5L14.0,25.5L15.0,25.5L16.0,26.5L17.0,26.5L18.0,27.5L19.0,27.5L20.0,28.5L22.0,28.5L23.0,29.5L26.0,29.5L27.0,30.5L34.0,30.5L34.5,30.0ZM32.0,28.5L28.0,28.5L27.0,27.5L26.0,27.5L25.0,26.5L24.0,26.5L21.5,24.0L21.5,23.0L20.5,22.0L20.5,20.0L19.5,19.0L20.0,18.5L25.0,18.5L28.5,15.0L28.5,12.0L27.5,11.0L27.5,10.0L26.5,9.0L27.0,8.5L28.0,8.5L29.0,7.5L32.0,7.5L33.0,8.5L35.0,8.5L39.5,13.0L39.5,14.0L40.5,15.0L40.5,22.0L38.5,24.0L38.5,25.0L37.0,26.5L36.0,26.5L35.0,27.5L33.0,27.5L32.0,28.5Z"
			})
		}),
		e === "once" && /* @__PURE__ */ g("svg", {
			viewBox: "0 0 63 67",
			width: t,
			height: t,
			"aria-hidden": "true",
			fill: "currentColor",
			children: /* @__PURE__ */ g("path", {
				fillRule: "evenodd",
				d: "M49.0,62.5L48.0,61.5L47.0,61.5L46.0,60.5L45.0,60.5L43.0,58.5L42.0,58.5L41.0,57.5L40.0,57.5L39.0,56.5L38.0,56.5L37.0,55.5L36.0,55.5L35.0,54.5L34.0,54.5L33.0,53.5L32.0,53.5L31.0,52.5L30.0,53.5L29.0,53.5L28.0,54.5L27.0,54.5L25.0,56.5L24.0,56.5L23.0,57.5L22.0,57.5L21.0,58.5L20.0,58.5L19.0,59.5L18.0,59.5L16.0,61.5L15.0,61.5L14.0,62.5L13.5,62.0L13.5,57.0L14.5,56.0L14.5,50.0L15.5,49.0L15.5,43.0L16.5,42.0L15.5,41.0L15.5,40.0L2.5,27.0L2.5,26.0L3.0,25.5L7.0,25.5L8.0,24.5L13.0,24.5L14.0,23.5L19.0,23.5L20.0,22.5L22.0,22.5L22.5,22.0L22.5,21.0L23.5,20.0L23.5,19.0L24.5,18.0L24.5,17.0L25.5,16.0L25.5,14.0L26.5,13.0L26.5,12.0L27.5,11.0L27.5,10.0L28.5,9.0L28.5,8.0L29.5,7.0L29.5,6.0L30.5,5.0L30.5,4.0L31.0,3.5L31.5,4.0L31.5,5.0L32.5,6.0L32.5,7.0L33.5,8.0L33.5,9.0L34.5,10.0L34.5,11.0L35.5,12.0L35.5,13.0L36.5,14.0L36.5,15.0L37.5,16.0L37.5,17.0L38.5,18.0L38.5,19.0L39.5,20.0L39.5,21.0L41.0,22.5L43.0,22.5L44.0,23.5L49.0,23.5L50.0,24.5L55.0,24.5L56.0,25.5L60.0,25.5L60.5,26.0L52.5,34.0L52.5,35.0L46.5,41.0L46.5,46.0L47.5,47.0L47.5,52.0L48.5,53.0L48.5,58.0L49.5,59.0L49.5,62.0L49.0,62.5ZM35.5,48.0L35.5,23.0L35.0,22.5L31.0,22.5L30.0,23.5L29.0,23.5L27.0,25.5L26.0,25.5L23.5,28.0L23.5,29.0L27.0,32.5L29.0,30.5L29.5,31.0L29.5,48.0L30.0,48.5L35.0,48.5L35.5,48.0Z"
			})
		}),
		e === "hidden" && /* @__PURE__ */ g("svg", {
			viewBox: "0 0 42 55",
			width: t,
			height: t,
			"aria-hidden": "true",
			fill: "currentColor",
			children: /* @__PURE__ */ g("path", {
				fillRule: "evenodd",
				d: "M33.0,54.5L7.0,54.5L6.0,53.5L4.0,53.5L1.5,51.0L1.5,26.0L2.0,25.5L3.0,25.5L4.0,24.5L5.0,24.5L5.5,24.0L5.5,13.0L6.5,12.0L6.5,10.0L12.0,4.5L13.0,4.5L14.0,3.5L15.0,3.5L16.0,2.5L24.0,2.5L25.0,3.5L27.0,3.5L29.0,5.5L30.0,5.5L32.5,8.0L32.5,9.0L33.5,10.0L33.5,11.0L34.5,12.0L34.5,15.0L35.5,16.0L35.5,24.0L36.0,24.5L37.0,24.5L38.5,26.0L38.5,52.0L38.0,52.5L37.0,52.5L36.0,53.5L34.0,53.5L33.0,54.5ZM30.5,22.0L30.5,16.0L29.5,15.0L29.5,13.0L24.0,7.5L17.0,7.5L16.0,8.5L15.0,8.5L11.5,12.0L11.5,13.0L10.5,14.0L10.5,22.0L11.0,22.5L17.0,22.5L18.0,21.5L22.0,21.5L23.0,22.5L30.0,22.5L30.5,22.0ZM20.5,48.0L21.0,47.5L22.0,47.5L22.5,47.0L22.5,38.0L24.5,36.0L24.5,32.0L23.0,30.5L22.0,30.5L21.0,29.5L19.0,29.5L15.5,33.0L15.5,36.0L17.5,38.0L17.5,46.0L20.0,48.5L20.5,48.0Z"
			})
		}),
		e === "fixed" && /* @__PURE__ */ g("svg", {
			viewBox: "0 0 44 67",
			width: t,
			height: t,
			"aria-hidden": "true",
			fill: "currentColor",
			children: /* @__PURE__ */ g("path", {
				fillRule: "evenodd",
				d: "M39.0,64.5L4.0,64.5L3.5,64.0L3.5,23.0L6.5,20.0L6.5,19.0L11.5,14.0L11.5,13.0L12.0,12.5L22.0,12.5L23.5,11.0L23.5,10.0L25.5,8.0L25.5,7.0L27.5,5.0L27.5,4.0L29.0,2.5L30.0,2.5L31.0,1.5L32.0,1.5L33.0,0.5L35.0,0.5L36.0,1.5L37.0,1.5L38.5,3.0L38.5,9.0L37.5,10.0L37.5,11.0L34.0,14.5L32.5,13.0L34.5,11.0L34.5,10.0L36.5,8.0L36.5,4.0L36.0,3.5L35.0,3.5L34.0,2.5L33.0,2.5L32.0,3.5L31.0,3.5L28.5,6.0L28.5,7.0L26.5,9.0L26.5,10.0L25.5,11.0L25.5,12.0L26.0,12.5L31.0,12.5L33.5,15.0L33.5,16.0L38.5,21.0L38.5,22.0L40.5,24.0L40.5,63.0L39.0,64.5ZM23.5,21.0L24.5,20.0L24.5,17.0L24.0,16.5L22.5,18.0L22.5,19.0L22.0,19.5L21.0,19.5L20.5,19.0L20.5,17.0L21.5,16.0L21.0,15.5L20.0,16.5L19.0,16.5L18.5,17.0L18.5,20.0L19.0,20.5L20.0,20.5L21.0,21.5L23.0,21.5L23.5,21.0ZM23.5,59.0L24.5,58.0L24.5,57.0L25.0,56.5L27.0,56.5L28.0,55.5L29.0,55.5L31.5,53.0L31.5,51.0L32.5,50.0L32.5,47.0L31.5,46.0L31.5,45.0L28.0,41.5L27.0,41.5L26.0,40.5L25.0,40.5L24.5,40.0L24.5,34.0L25.0,33.5L26.0,34.5L27.0,34.5L28.0,33.5L29.0,33.5L30.5,32.0L28.0,29.5L27.0,29.5L26.0,28.5L25.0,28.5L24.5,28.0L24.5,27.0L23.0,25.5L20.0,25.5L19.5,26.0L19.5,27.0L18.0,28.5L16.0,28.5L12.5,32.0L12.5,34.0L11.5,35.0L11.5,37.0L12.5,38.0L12.5,39.0L16.0,42.5L17.0,42.5L18.0,43.5L19.0,43.5L19.5,44.0L19.5,52.0L19.0,52.5L15.0,48.5L14.0,48.5L12.0,50.5L11.0,50.5L10.5,51.0L15.0,55.5L16.0,55.5L17.0,56.5L18.0,56.5L19.5,58.0L19.5,59.0L20.0,59.5L23.0,59.5L23.5,59.0ZM19.0,38.5L17.5,37.0L17.5,35.0L18.5,34.0L18.5,33.0L19.0,32.5L19.5,33.0L19.5,38.0L19.0,38.5ZM25.0,52.5L24.5,52.0L24.5,46.0L25.0,45.5L26.5,47.0L26.5,50.0L25.5,51.0L25.5,52.0L25.0,52.5Z"
			})
		}),
		e === "double" && /* @__PURE__ */ g("svg", {
			viewBox: "0 0 67 61",
			width: t,
			height: t,
			"aria-hidden": "true",
			fill: "currentColor",
			children: /* @__PURE__ */ g("path", {
				fillRule: "evenodd",
				d: "M6.0,41.5L4.0,41.5L1.5,39.0L8.0,32.5L9.0,32.5L13.0,28.5L14.0,28.5L15.0,27.5L16.0,27.5L18.0,25.5L19.0,25.5L23.0,21.5L24.0,21.5L26.0,19.5L27.0,19.5L30.5,16.0L30.5,15.0L29.0,13.5L26.0,13.5L24.5,12.0L24.5,9.0L30.0,3.5L31.0,3.5L32.0,2.5L34.0,2.5L36.5,5.0L36.5,8.0L37.5,9.0L37.5,10.0L44.0,16.5L47.0,16.5L47.5,17.0L47.5,18.0L48.5,19.0L48.5,20.0L43.0,25.5L42.0,25.5L40.0,27.5L39.0,27.5L38.0,26.5L37.0,26.5L35.5,25.0L35.5,23.0L36.5,22.0L33.0,18.5L30.0,21.5L29.0,21.5L23.0,27.5L22.0,27.5L19.5,30.0L19.5,31.0L18.0,32.5L17.0,32.5L13.0,36.5L12.0,36.5L8.0,40.5L7.0,40.5L6.0,41.5ZM61.0,54.5L42.0,54.5L41.5,54.0L42.5,53.0L42.5,52.0L44.5,50.0L44.5,49.0L46.5,47.0L46.5,46.0L48.5,44.0L48.5,43.0L50.5,41.0L50.5,40.0L52.5,38.0L52.5,37.0L53.5,36.0L53.5,35.0L54.5,34.0L54.5,32.0L53.0,30.5L47.0,30.5L46.0,31.5L44.0,31.5L43.5,31.0L43.5,29.0L42.5,28.0L42.5,27.0L44.0,25.5L46.0,25.5L47.0,24.5L55.0,24.5L56.0,25.5L57.0,25.5L60.5,29.0L60.5,36.0L59.5,37.0L59.5,38.0L57.5,40.0L57.5,41.0L55.5,43.0L55.5,44.0L53.5,46.0L53.5,47.0L52.5,48.0L53.0,48.5L61.0,48.5L61.5,49.0L61.5,54.0L61.0,54.5ZM40.0,54.5L37.0,54.5L36.5,54.0L36.5,53.0L34.5,51.0L34.5,50.0L34.0,49.5L33.0,49.5L31.5,51.0L31.5,52.0L30.5,53.0L30.5,54.0L30.0,54.5L27.0,54.5L26.5,54.0L26.5,53.0L28.5,51.0L28.5,50.0L29.5,49.0L29.5,48.0L31.5,46.0L31.5,45.0L30.5,44.0L30.5,43.0L28.5,41.0L28.5,40.0L27.5,39.0L27.5,38.0L28.0,37.5L30.0,37.5L32.5,40.0L32.5,41.0L33.0,41.5L34.0,41.5L34.5,41.0L34.5,40.0L37.0,37.5L39.0,37.5L39.5,38.0L39.5,39.0L38.5,40.0L38.5,41.0L36.5,43.0L36.5,44.0L35.5,45.0L35.5,46.0L36.5,47.0L36.5,48.0L38.5,50.0L38.5,51.0L39.5,52.0L39.5,53.0L40.5,54.0L40.0,54.5Z"
			})
		})
	] });
}
//#endregion
//#region src/games/modernart/card.tsx
function Q({ id: e, className: t = "", legal: n = !1, selected: r = !1 }) {
	let i = T(e), a = S[i.artist], o = l();
	return /* @__PURE__ */ _("span", {
		className: `ma-painting ${t}`,
		"data-selected": r,
		style: { "--ma-artist": a.color },
		children: [
			/* @__PURE__ */ g("img", {
				src: `games/modernart/${String(e).padStart(2, "0")}.svg`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ _("span", {
				className: "ma-card-label",
				children: [/* @__PURE__ */ g(Z, { kind: i.kind }), /* @__PURE__ */ _("span", { children: [a.short, /* @__PURE__ */ _("small", { children: ["№ ", e + 1] })] })]
			}),
			/* @__PURE__ */ g("span", {
				className: "ma-card-kind",
				children: o(w[i.kind])
			}),
			n && /* @__PURE__ */ g("svg", {
				className: "ma-legal",
				viewBox: "0 0 180 260",
				preserveAspectRatio: "none",
				"aria-hidden": "true",
				children: /* @__PURE__ */ g("rect", {
					x: "3",
					y: "3",
					width: "174",
					height: "254",
					rx: "3",
					fill: "none",
					stroke: "white",
					strokeWidth: "2",
					strokeDasharray: "8 5",
					children: /* @__PURE__ */ g("animate", {
						attributeName: "stroke-dashoffset",
						from: "0",
						to: "-26",
						dur: "1.2s",
						repeatCount: "indefinite"
					})
				})
			})
		]
	});
}
function ne({ id: e, anchor: t, className: n }) {
	let { ref: r, hidden: i } = o(t);
	return /* @__PURE__ */ g("span", {
		className: `ma-painting-anchor ${n ?? ""}`,
		ref: r,
		style: { visibility: i ? "hidden" : void 0 },
		children: /* @__PURE__ */ g(Q, { id: e })
	});
}
//#endregion
//#region src/games/modernart/market.tsx
function re({ pub: e }) {
	let t = l(), { ref: n } = o("ma-bank");
	return /* @__PURE__ */ _("section", {
		ref: n,
		className: "ma-market",
		"aria-label": t("games.modernart.market"),
		children: [/* @__PURE__ */ _("div", {
			className: "ma-market-heading",
			children: [/* @__PURE__ */ g("span", { children: "MODERN ART" }), /* @__PURE__ */ g("small", { children: t("games.modernart.market") })]
		}), /* @__PURE__ */ g("div", {
			className: "ma-market-columns",
			children: S.map((t, n) => /* @__PURE__ */ _("div", {
				className: "ma-artist",
				style: { "--ma-artist": t.color },
				children: [
					/* @__PURE__ */ _("div", {
						className: "ma-artist-name",
						children: [/* @__PURE__ */ g("span", { children: n + 1 }), /* @__PURE__ */ g("strong", { children: t.short })]
					}),
					/* @__PURE__ */ _("div", {
						className: "ma-popularity",
						children: [
							/* @__PURE__ */ g("b", { children: e.counts[n] }),
							/* @__PURE__ */ g("span", { children: "/ 5" }),
							/* @__PURE__ */ g("div", {
								className: "ma-pips",
								children: Array.from({ length: 5 }, (t, r) => /* @__PURE__ */ g("i", { "data-filled": r < e.counts[n] }, r))
							})
						]
					}),
					/* @__PURE__ */ g("div", {
						className: "ma-values",
						children: Array.from({ length: 4 }, (t, r) => {
							let i = e.history.find((e) => e.round === r + 1), a = i?.ranks.indexOf(n) ?? -1;
							return /* @__PURE__ */ _("span", {
								"data-current": r + 1 === e.round,
								children: [/* @__PURE__ */ g("small", { children: r + 1 }), i ? /* @__PURE__ */ g("b", { children: a < 0 ? "—" : 30 - a * 10 }) : /* @__PURE__ */ g("i", {})]
							}, r);
						})
					})
				]
			}, t.name))
		})]
	});
}
//#endregion
//#region src/games/modernart/view-player.tsx
function ie({ rid: e, name: t, count: n, handCount: r, active: i, ready: a, onClick: s }) {
	let { ref: c } = o(`ma-seat:${e}`), u = l();
	return /* @__PURE__ */ _("button", {
		type: "button",
		className: "ma-museum",
		"data-active": i,
		onClick: s,
		ref: c,
		"aria-label": `${t} · ${u("games.modernart.details")}`,
		children: [
			/* @__PURE__ */ g("span", {
				className: "ma-museum-roof",
				"aria-hidden": "true",
				children: "▰ ▰ ▰"
			}),
			/* @__PURE__ */ g("strong", { children: t }),
			/* @__PURE__ */ _("span", { children: [
				u("games.modernart.count", { n }),
				" · ",
				r,
				/* @__PURE__ */ g("span", {
					"aria-hidden": "true",
					children: " ▤"
				}),
				a ? " ✓" : ""
			] })
		]
	});
}
function ae({ id: e, legal: t, selected: n, label: r, onClick: i }) {
	let { ref: a, hidden: s } = o(`ma-hand:${e}`);
	return /* @__PURE__ */ g("button", {
		ref: a,
		type: "button",
		className: "ma-hand-card",
		style: { visibility: s ? "hidden" : void 0 },
		disabled: !t,
		"aria-pressed": n,
		"aria-label": r,
		onClick: i,
		children: /* @__PURE__ */ g(Q, {
			id: e,
			legal: t,
			selected: n
		})
	});
}
function oe({ public: e, private: t, myRid: n, members: r, send: v }) {
	let y = e, b = t, x = l(), C = c((e) => e.locale), E = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? ee(t, C) : e;
	}, [D, O] = i(null), [k, A] = i(""), [j, M] = i(null), N = `${y.phase}:${y.turn}:${y.lot.join(",")}:${y.round}`, P = D?.key === N ? D.id : null, F = [...b?.hand ?? []], I = (y.phase === "offer" || y.phase === "double") && y.turn === n;
	b?.outgoing && F.splice(b.outgoing.index, 0, b.outgoing.card);
	let L = (e) => I && (y.phase === "offer" || T(e).artist === T(y.lot[0]).artist && T(e).kind !== "double"), R = y.players.find((e) => e.rid === n)?.ready ?? !1, z = !!b && (y.phase === "open" && y.bidder !== n || y.phase === "once" && y.turn === n || y.phase === "hidden" && !R), B = y.phase === "price" && y.seller === n, V = y.phase === "hidden" || B ? 0 : y.high + 1, H = k === "" ? V : Number(k), U = Number.isSafeInteger(H) && H >= V && H <= (b?.cash ?? 0), W = () => {
		U && (v({
			type: B ? "price" : "bid",
			amount: H
		}), A(""));
	}, G = b?.canAct ?? !1;
	p(G, f);
	let { ref: K } = o("ma-lot"), { ref: q } = o("ma-hand"), { ref: J } = o(`ma-cash:${n}`), { ref: Y } = o("ma-mystery"), X = y.phase === "done" ? x("games.modernart.final") : y.mysteryCard === null ? y.phase === "offer" ? y.turn === n ? x("games.modernart.offerPrompt") : x("games.modernart.waiting", { name: E(y.turn) }) : y.phase === "double" ? y.turn === n ? x("games.modernart.pairPrompt") : x("games.modernart.waiting", { name: E(y.turn) }) : y.phase === "settle" ? x("games.modernart.settling") : y.phase === "roundOver" ? x("games.modernart.roundOver") : y.phase === "reveal" ? x("games.modernart.reveal") : x("games.modernart.seller", { name: E(y.seller) }) : x("games.modernart.mysteryLog");
	return /* @__PURE__ */ _(m, {
		adaptive: !0,
		scroll: !1,
		className: "ma-screen",
		banner: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("header", {
			className: "ma-top",
			children: [
				/* @__PURE__ */ _("span", {
					className: "ma-brand",
					children: ["MODERN ART", /* @__PURE__ */ g("small", { children: x("games.modernart.roundOf", { n: y.round }) })]
				}),
				/* @__PURE__ */ _("span", {
					className: "ma-wallet",
					ref: J,
					children: [/* @__PURE__ */ g("small", { children: x("games.modernart.cash") }), /* @__PURE__ */ _("strong", { children: [
						/* @__PURE__ */ g(s, { value: b?.cash ?? 0 }),
						" ",
						/* @__PURE__ */ g("span", { children: "k€" })
					] })]
				}),
				/* @__PURE__ */ g("button", {
					type: "button",
					className: "ma-log-button",
					"aria-label": x("games.modernart.auctionHistory"),
					onClick: () => M("log"),
					children: /* @__PURE__ */ g(d, { size: 20 })
				})
			]
		}), /* @__PURE__ */ g("div", {
			className: "ma-museums",
			children: y.players.map((e) => /* @__PURE__ */ g(ie, {
				rid: e.rid,
				name: E(e.rid),
				count: e.paintings.length,
				handCount: e.handCount,
				active: e.rid === y.seller,
				ready: e.ready,
				onClick: () => M(e.rid)
			}, e.rid))
		})] }),
		children: [/* @__PURE__ */ _("div", {
			className: "ma-body",
			children: [/* @__PURE__ */ _("div", {
				className: "ma-stage",
				children: [/* @__PURE__ */ g(re, { pub: y }), /* @__PURE__ */ _("section", {
					className: "ma-auction",
					children: [
						/* @__PURE__ */ _("div", {
							className: "ma-auction-caption",
							children: [/* @__PURE__ */ g("h1", { children: X }), y.kind && /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Z, {
								kind: y.kind,
								size: 20
							}), x(w[y.kind])] })]
						}),
						/* @__PURE__ */ g("div", {
							className: "ma-lot",
							ref: K,
							children: y.mysteryCard === null ? y.lot.length ? y.lot.map((e) => /* @__PURE__ */ g(ne, {
								id: e,
								anchor: `ma-table:${e}`
							}, e)) : /* @__PURE__ */ g("div", {
								className: "ma-easel",
								"aria-hidden": "true",
								children: /* @__PURE__ */ _("svg", {
									viewBox: "0 0 120 150",
									children: [
										/* @__PURE__ */ g("path", {
											d: "M42 136 58 12h6l20 124M26 120h71M32 85h58",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "6"
										}),
										/* @__PURE__ */ g("rect", {
											x: "22",
											y: "26",
											width: "78",
											height: "92",
											fill: "#f2f0e9",
											stroke: "currentColor",
											strokeWidth: "5"
										}),
										/* @__PURE__ */ g("path", {
											d: "m30 102 20-37 20 17 23-40v60Z",
											fill: "#e4bd29"
										})
									]
								})
							}) : /* @__PURE__ */ g(ne, {
								id: y.mysteryCard,
								anchor: `ma-table:${y.mysteryCard}`
							})
						}),
						/* @__PURE__ */ _("div", {
							className: "ma-auction-controls",
							children: [
								y.phase === "award" && y.lastSale ? /* @__PURE__ */ g("strong", {
									className: "ma-sale-note",
									children: x("games.modernart.sale", {
										name: E(y.lastSale.buyer),
										n: y.lastSale.amount
									})
								}) : null,
								[
									"open",
									"once",
									"hidden",
									"price",
									"fixed"
								].includes(y.phase) && /* @__PURE__ */ g("div", {
									className: "ma-bid-status",
									children: y.phase === "fixed" ? x("games.modernart.fixedAt", { n: y.fixedPrice }) : y.phase === "price" ? x("games.modernart.pricePrompt") : y.phase === "hidden" ? b?.bid !== null && b?.bid !== void 0 ? x("games.modernart.yourBid", { n: b.bid }) : x("games.modernart.hidden") : y.bidder ? x("games.modernart.highest", {
										name: E(y.bidder),
										n: y.high
									}) : x("games.modernart.noBid")
								}),
								(z || B) && /* @__PURE__ */ _("div", {
									className: "ma-bid-form",
									children: [/* @__PURE__ */ _("label", { children: [/* @__PURE__ */ g("span", { children: x("games.modernart.amount") }), /* @__PURE__ */ g("input", {
										"aria-label": x("games.modernart.amount"),
										type: "number",
										inputMode: "numeric",
										min: V,
										max: b?.cash ?? 0,
										step: "1",
										placeholder: String(V),
										value: k,
										onChange: (e) => A(e.target.value),
										onKeyDown: (e) => {
											e.key === "Enter" && W();
										}
									})] }), /* @__PURE__ */ g("button", {
										type: "button",
										onClick: W,
										className: "ma-primary",
										disabled: !U,
										children: x(B ? "games.modernart.setPrice" : "games.modernart.submit")
									})]
								}),
								y.phase === "double" && G && /* @__PURE__ */ g("button", {
									type: "button",
									onClick: () => v({ type: "pass" }),
									children: x("games.modernart.noPair")
								}),
								(y.phase === "open" && !R || y.phase === "once" && G) && /* @__PURE__ */ g("button", {
									type: "button",
									className: "ma-pass",
									onClick: () => v({ type: "pass" }),
									children: x(y.phase === "open" ? "games.modernart.pass" : "games.modernart.passOnce")
								}),
								y.phase === "fixed" && G && /* @__PURE__ */ _("div", {
									className: "ma-control-row",
									children: [/* @__PURE__ */ _("button", {
										type: "button",
										className: "ma-primary",
										disabled: (b?.cash ?? 0) < y.fixedPrice,
										onClick: () => v({ type: "buy" }),
										children: [
											x("games.modernart.buy"),
											" · ",
											y.fixedPrice,
											" k€"
										]
									}), /* @__PURE__ */ g("button", {
										type: "button",
										onClick: () => v({ type: "pass" }),
										children: x("games.modernart.passOnce")
									})]
								}),
								y.phase === "mystery" && G && /* @__PURE__ */ _("div", {
									className: "ma-control-row",
									ref: Y,
									children: [/* @__PURE__ */ g("button", {
										type: "button",
										className: "ma-primary",
										onClick: () => v({
											type: "mystery",
											reveal: !0
										}),
										children: x("games.modernart.revealMystery")
									}), /* @__PURE__ */ g("button", {
										type: "button",
										onClick: () => v({
											type: "mystery",
											reveal: !1
										}),
										children: x("games.modernart.skipMystery")
									})]
								}),
								y.revealedBids && /* @__PURE__ */ g("div", {
									className: "ma-sealed-results",
									children: Object.entries(y.revealedBids).map(([e, t]) => /* @__PURE__ */ _("span", { children: [
										E(e),
										" ",
										/* @__PURE__ */ _("b", { children: [t, " k€"] })
									] }, e))
								}),
								y.phase === "roundOver" && /* @__PURE__ */ _("div", {
									className: "ma-round-note",
									children: [/* @__PURE__ */ _("span", { children: [
										x("games.modernart.income"),
										" ",
										/* @__PURE__ */ _("strong", { children: [y.history.at(-1)?.revenue[n] ?? 0, " k€"] })
									] }), /* @__PURE__ */ g("button", {
										type: "button",
										className: "ma-primary",
										disabled: R,
										onClick: () => v({ type: "next" }),
										children: x(R ? "games.modernart.ready" : "games.modernart.next")
									})]
								})
							]
						})
					]
				})]
			}), /* @__PURE__ */ _("section", {
				className: "ma-hand",
				ref: q,
				children: [/* @__PURE__ */ _("div", {
					className: "ma-hand-heading",
					children: [/* @__PURE__ */ _("span", { children: [
						x("games.modernart.hand"),
						" ",
						/* @__PURE__ */ g("b", { children: b?.hand.length ?? 0 })
					] }), P === null ? y.mysteryEnabled ? /* @__PURE__ */ g("small", { children: x("games.modernart.mysteryLeft", { n: y.mysteryCount }) }) : null : /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("button", {
						type: "button",
						"aria-label": x("games.modernart.cancel"),
						onClick: () => O(null),
						children: /* @__PURE__ */ g(u, { size: 18 })
					}), /* @__PURE__ */ g("button", {
						type: "button",
						className: "ma-primary",
						onClick: () => {
							v({
								type: y.phase === "double" ? "pair" : "offer",
								card: P
							}), O(null);
						},
						children: x(y.phase === "double" ? "games.modernart.pair" : "games.modernart.offer")
					})] })]
				}), /* @__PURE__ */ g("div", {
					className: "ma-hand-rail",
					children: F.length ? F.map((e) => /* @__PURE__ */ g(ae, {
						id: e,
						legal: L(e),
						selected: P === e,
						label: x("games.modernart.cardLabel", {
							artist: S[T(e).artist].name,
							kind: x(w[T(e).kind]),
							n: e + 1
						}),
						onClick: () => O(P === e ? null : {
							id: e,
							key: N
						})
					}, e)) : /* @__PURE__ */ g("p", { children: x("games.modernart.noCards") })
				})]
			})]
		}), /* @__PURE__ */ g(a, {
			open: j !== null,
			onClose: () => M(null),
			label: j === "log" ? x("games.modernart.auctionHistory") : j ? E(j) : "",
			tall: !0,
			children: j === "log" ? /* @__PURE__ */ g("ol", {
				className: "ma-log",
				children: y.log.map((e, t) => /* @__PURE__ */ _("li", { children: [/* @__PURE__ */ g("span", { children: e.kind === "offer" ? x("games.modernart.offerLog", { name: E(e.rid) }) : e.kind === "sale" ? x("games.modernart.saleLog", {
					name: E(e.rid),
					n: e.amount
				}) : e.kind === "round" ? x("games.modernart.roundLog", { n: e.round }) : x("games.modernart.mysteryLog") }), /* @__PURE__ */ g("div", { children: e.cards.map((e) => /* @__PURE__ */ g(Q, { id: e }, e)) })] }, t))
			}) : /* @__PURE__ */ _("div", {
				className: "ma-gallery",
				children: [y.players.find((e) => e.rid === j)?.paintings.map((e) => /* @__PURE__ */ g(Q, { id: e }, e)), !y.players.find((e) => e.rid === j)?.paintings.length && /* @__PURE__ */ g("p", { children: x("games.modernart.noPaintings") })]
			})
		})]
	});
}
//#endregion
//#region src/games/modernart/bot.ts
var se = {
	bidFraction: .5,
	futureWeight: .35,
	endWeight: 1
};
function $(e, t = e.counts) {
	let n = [
		0,
		1,
		2,
		3,
		4
	].filter((e) => t[e] > 0).sort((e, n) => t[n] - t[e] || e - n).slice(0, 3);
	return t.map((t, r) => n.includes(r) ? 30 - n.indexOf(r) * 10 + e.history.reduce((e, t) => e + (t.ranks.includes(r) ? 30 - t.ranks.indexOf(r) * 10 : 0), 0) : 0);
}
function ce(e = {}) {
	let t = {
		...se,
		...e
	};
	return ({ public: e, private: n }, r) => {
		if (!n) return null;
		let i = e.players.find((e) => e.rid === r.rid)?.ready ?? !1, a = (e) => ({ action: e });
		if (e.phase === "roundOver") return i ? null : a({ type: "next" });
		if (!n.canAct) return null;
		let o = r.difficulty === "weak", s = $(e), c = (n) => {
			let r = T(n).artist, i = [...e.counts];
			return i[r]++, $(e, i)[r] + t.futureWeight * (4 - e.round) * 10;
		};
		if (e.phase === "offer" || e.phase === "double") {
			let i = n.hand.filter((t) => e.phase === "offer" || T(t).artist === T(e.lot[0]).artist && T(t).kind !== "double");
			if (!i.length) return a({ type: "pass" });
			if (o) return a({
				type: e.phase === "double" ? "pair" : "offer",
				card: i[0]
			});
			let l = (t, n) => e.players.find((e) => e.rid === t).paintings.reduce((e, t) => e + n[T(t).artist], 0), u = l(r.rid, s), d = e.players.filter((e) => e.rid !== r.rid), f = (i) => {
				let a = T(i), o = [...e.counts];
				if (o[a.artist]++, o[a.artist] >= 5) {
					let n = $(e, o);
					return t.endWeight * (l(r.rid, n) - u - d.reduce((e, t) => e + l(t.rid, n) - l(t.rid, s), 0) / d.length);
				}
				let f = n.hand.filter((e) => T(e).artist === a.artist).length;
				return c(i) * .35 + f * 2 + (a.kind === "double" ? 4 : 0);
			}, p = [...i].sort((e, t) => f(t) - f(e) || e - t)[0];
			return a({
				type: e.phase === "double" ? "pair" : "offer",
				card: p
			});
		}
		let l = e.lot.reduce((n, r) => n + s[T(r).artist] + t.futureWeight * (4 - e.round) * 10, 0), u = Math.min(n.cash, Math.max(0, Math.floor(l * (o ? .25 : t.bidFraction))));
		if (e.phase === "price") return a({
			type: "price",
			amount: u
		});
		if (e.phase === "fixed") return a({ type: e.fixedPrice <= u ? "buy" : "pass" });
		if (e.phase === "hidden") return a({
			type: "bid",
			amount: u
		});
		if (e.phase === "open" || e.phase === "once") return a(u > e.high ? {
			type: "bid",
			amount: e.phase === "open" ? e.high + 1 : u
		} : { type: "pass" });
		if (e.phase === "mystery") {
			let t = e.players.find((e) => e.rid === r.rid).paintings.length;
			return a({
				type: "mystery",
				reveal: t > 0 || n.hand.length < 3
			});
		}
		return null;
	};
}
var le = ce(), ue = (e, t, n) => e.type === "offer" || e.type === "pair" ? n("games.modernart.helpOffer", { artist: S[T(e.card).artist].name }) : e.type === "bid" ? n("games.modernart.helpBid", { n: e.amount }) : e.type === "price" ? `${n("games.modernart.setPrice")} · ${e.amount} k€` : e.type === "buy" ? n("games.modernart.buy") : e.type === "next" ? n("games.modernart.next") : e.type === "mystery" ? n(e.reveal ? "games.modernart.revealMystery" : "games.modernart.skipMystery") : n("games.modernart.helpPass"), de = {
	"ma-deal"(e, t) {
		let n = t.anchor("ma-bank"), r = t.anchor(`ma-seat:${e.rid}`);
		if (!n || !r) return null;
		let i = e.secret?.cards;
		return i ? {
			ms: 650,
			hide: t.queued ? [] : i.map((e) => `ma-hand:${e}`),
			node: i.map((e, r) => {
				let i = t.anchor(`ma-hand:${e}`);
				return i ? /* @__PURE__ */ g(y, {
					from: {
						...n,
						w: i.w,
						h: i.h
					},
					to: i,
					ms: 400,
					delay: r * 18,
					children: /* @__PURE__ */ g("span", {
						className: "ma-flying",
						style: {
							width: i.w,
							height: i.h
						},
						children: /* @__PURE__ */ g(Q, { id: e })
					})
				}, e) : null;
			})
		} : {
			ms: 650,
			node: /* @__PURE__ */ g(y, {
				from: {
					...n,
					w: 40,
					h: 60
				},
				to: {
					...r,
					w: 30,
					h: 45
				},
				ms: 570,
				children: /* @__PURE__ */ g("span", { className: "ma-card-back" })
			})
		};
	},
	"ma-offer"(e, t) {
		let n = e.data, r = t.anchor(n.mystery ? "ma-bank" : e.rid === t.myRid ? `ma-hand:${n.cards[0]}` : `ma-seat:${e.rid}`);
		return r ? {
			ms: 650,
			node: n.cards.map((i) => {
				let a = t.anchor(`ma-table:${i}`), o = e.rid === t.myRid && !n.mystery ? r : {
					...r,
					w: a?.w ?? 0,
					h: a?.h ?? 0
				};
				return a ? /* @__PURE__ */ g(y, {
					from: o,
					to: a,
					ms: 550,
					children: /* @__PURE__ */ g("span", {
						className: "ma-flying",
						style: {
							width: o.w,
							height: o.h
						},
						children: /* @__PURE__ */ g(Q, { id: i })
					})
				}, i) : null;
			}),
			hide: t.queued ? [] : n.cards.flatMap((e) => [`ma-table:${e}`, `ma-hand:${e}`]).filter((e) => t.anchor(e) !== null)
		} : null;
	},
	"ma-sale"(e, t) {
		let n = e.data, r = t.anchor(`ma-seat:${e.rid}`);
		return r ? {
			ms: 650,
			hide: t.queued ? [] : n.cards.map((e) => `ma-table:${e}`),
			node: /* @__PURE__ */ _(h, { children: [
				n.cards.map((e) => {
					let n = t.anchor(`ma-table:${e}`);
					return n ? /* @__PURE__ */ g(y, {
						from: n,
						to: {
							...r,
							w: Math.min(r.w, 70),
							h: Math.min(r.w, 70) * 1.5
						},
						ms: 550,
						children: /* @__PURE__ */ g("span", {
							className: "ma-flying",
							style: {
								width: n.w,
								height: n.h
							},
							children: /* @__PURE__ */ g(Q, { id: e })
						})
					}, e) : null;
				}),
				/* @__PURE__ */ _(v, {
					at: r,
					ms: 650,
					children: [
						"−",
						n.amount,
						" k€"
					]
				}),
				n.seller !== e.rid && t.anchor(`ma-seat:${n.seller}`) && /* @__PURE__ */ _(v, {
					at: t.anchor(`ma-seat:${n.seller}`),
					ms: 650,
					children: [
						"+",
						n.amount,
						" k€"
					]
				})
			] })
		} : null;
	},
	"ma-income"(e, t) {
		let n = t.anchor(e.rid === t.myRid ? `ma-cash:${e.rid}` : `ma-seat:${e.rid}`), r = t.anchor(`ma-seat:${e.rid}`), i = t.anchor("ma-bank"), { amount: a, cards: o } = e.data;
		return n ? {
			ms: 650,
			node: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _(v, {
				at: n,
				ms: 650,
				children: [
					"+",
					a,
					" k€"
				]
			}), r && i && o.map((e, t) => /* @__PURE__ */ g(y, {
				from: {
					...r,
					x: r.x + t * 2,
					w: 45,
					h: 67.5
				},
				to: {
					...i,
					x: i.x + i.w / 2,
					w: 25,
					h: 37.5
				},
				ms: 550,
				children: /* @__PURE__ */ g("span", {
					className: "ma-flying",
					style: {
						width: 45,
						height: 67.5
					},
					children: /* @__PURE__ */ g(Q, { id: e })
				})
			}, e))] })
		} : null;
	}
}, fe = () => {};
function pe(e) {
	let { public: t, result: a, members: o, hintCount: s, onPlayAgain: d, onBackToLobby: f } = e, p = t, m = l(), h = c((e) => e.locale), [v, y] = i(!0), x = r(null), S = r(null), C = r(null);
	n(() => {
		x.current?.focus({ preventScroll: !0 });
	}, []);
	let w = (e) => {
		y(e), requestAnimationFrame(() => (e ? x : S).current?.focus({ preventScroll: !0 }));
	}, T = (e) => {
		let t = o.find((t) => t.rid === e);
		return t ? ee(t, h) : e;
	};
	return /* @__PURE__ */ _("div", {
		className: "ma-endgame",
		children: [
			/* @__PURE__ */ g("div", {
				className: "ma-final-board",
				inert: v,
				children: /* @__PURE__ */ g(oe, {
					public: p,
					private: e.private,
					myRid: e.myRid,
					members: o,
					send: fe
				})
			}),
			/* @__PURE__ */ g("div", {
				className: "ma-end-overlay",
				hidden: !v,
				children: /* @__PURE__ */ _("section", {
					className: "ma-result",
					ref: C,
					role: "dialog",
					"aria-modal": "true",
					"aria-label": m("games.modernart.final"),
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), w(!1)), e.key === "Tab") {
							let t = C.current?.querySelectorAll("button:not(:disabled),[tabindex=\"0\"]"), n = t?.[0], r = t?.[t.length - 1];
							e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
						}
					},
					children: [
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ma-collapse",
							ref: x,
							"aria-label": m("games.modernart.review"),
							onClick: () => w(!1),
							children: /* @__PURE__ */ g(u, { size: 22 })
						}),
						/* @__PURE__ */ _("div", {
							className: "ma-result-scroll",
							children: [
								/* @__PURE__ */ g("p", {
									className: "ma-result-brand",
									children: "MODERN ART"
								}),
								/* @__PURE__ */ g("h1", { children: m("games.modernart.final") }),
								/* @__PURE__ */ g("p", {
									className: "ma-result-winners",
									children: a.winner.length === 1 ? m("games.modernart.winner", { name: T(a.winner[0]) }) : m("games.modernart.tied", { names: a.winner.map(T).join(" · ") })
								}),
								/* @__PURE__ */ _("table", {
									className: "ma-results-table",
									children: [/* @__PURE__ */ g("thead", { children: /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", {
										scope: "col",
										children: "k€"
									}), a.ranking.map((e) => /* @__PURE__ */ g("th", {
										scope: "col",
										"data-winner": a.winner.includes(e),
										children: T(e)
									}, e))] }) }), /* @__PURE__ */ _("tbody", { children: [p.history.map((e) => /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ _("th", {
										scope: "row",
										children: [m("games.modernart.round", { n: e.round }), /* @__PURE__ */ _("small", { children: [" · ", m("games.modernart.income")] })]
									}), a.ranking.map((t) => /* @__PURE__ */ g("td", { children: e.revenue[t] }, t))] }, e.round)), /* @__PURE__ */ _("tr", {
										className: "ma-result-total",
										children: [/* @__PURE__ */ g("th", {
											scope: "row",
											children: m("games.modernart.finalCash")
										}), a.ranking.map((e) => /* @__PURE__ */ g("td", {
											"data-winner": a.winner.includes(e),
											children: a.scores?.[e] ?? p.players.find((t) => t.rid === e)?.cash
										}, e))]
									})] })]
								}),
								/* @__PURE__ */ _("div", {
									className: "ma-result-notes",
									children: [s !== void 0 && /* @__PURE__ */ g("p", { children: m("session.hint.usedCount", { n: s }) }), a.ranking.filter((e) => (a.autopilot?.[e] ?? 0) > 0).map((e) => /* @__PURE__ */ _("p", { children: [
										T(e),
										" · ",
										m("session.autopilot.share", { n: Math.round(a.autopilot[e] * 100) })
									] }, e))]
								})
							]
						}),
						/* @__PURE__ */ _("footer", {
							className: "ma-result-footer",
							children: [
								d && /* @__PURE__ */ g(b, {
									className: "ma-primary",
									label: m("session.result.playAgain"),
									confirmLabel: m("games.modernart.confirmAgain"),
									onConfirm: d
								}, `again-${v}`),
								f && /* @__PURE__ */ g(b, {
									label: m("session.result.backToLobby"),
									confirmLabel: m("games.modernart.confirmLeave"),
									onConfirm: f
								}, `lobby-${v}`),
								!d && !f && /* @__PURE__ */ g("p", { children: m("session.result.waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "ma-restore",
				hidden: v,
				ref: S,
				onClick: () => w(!0),
				children: m("games.modernart.showResult")
			})
		]
	});
}
//#endregion
//#region src/games/modernart/options.tsx
function me({ value: e, onChange: t }) {
	let n = l(), r = k.parse(e);
	return /* @__PURE__ */ g(x, {
		checked: r.mystery,
		label: n("games.modernart.mystery"),
		hint: n("games.modernart.mysteryHint"),
		onChange: () => t({
			...r,
			mystery: !r.mystery
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/modernart/entry.tsx
var he = {
	definition: te,
	View: oe,
	bot: le,
	describe: ue,
	fx: de,
	OverView: pe,
	Options: me,
	ruleIcons: {
		open: ({ size: e = 24 }) => /* @__PURE__ */ g(Z, {
			kind: "open",
			size: e
		}),
		once: ({ size: e = 24 }) => /* @__PURE__ */ g(Z, {
			kind: "once",
			size: e
		}),
		hidden: ({ size: e = 24 }) => /* @__PURE__ */ g(Z, {
			kind: "hidden",
			size: e
		}),
		fixed: ({ size: e = 24 }) => /* @__PURE__ */ g(Z, {
			kind: "fixed",
			size: e
		}),
		double: ({ size: e = 24 }) => /* @__PURE__ */ g(Z, {
			kind: "double",
			size: e
		})
	},
	locales: {
		zh: {
			name: "现代艺术",
			desc: "经营美术馆，以五种拍卖方式买卖画作，掌握四轮艺术市场。",
			rules: "目标：\n经营美术馆，拍卖手牌中的画作并购买其他画作。四轮后现金最多的玩家获胜；现金相同时并列获胜。所有金额以千欧元（k€）计，现金在终局前保密。\n准备：\n每人获得100 k€。70张画作属于五位画家，按市场板从左至右分别为Carvalho（12张）、Thaler（13张）、Melim（14张）、Martins（15张）、Silveira（16张）。三人局各发10张，四人局9张，五人局8张。起始座位首先主持拍卖，此后顺时针进行。\n拍卖流程：\n拍卖师从手牌选出一幅画作，按牌面图标拍卖。买家向拍卖师支付成交价；拍卖师自己买下时向银行付款。成交画作放入买家的美术馆，在本轮结束时出售。所有出价必须为非负整数且不超过自己的现金；加价须高于当前最高价。无人出价时拍卖师免费获得画作，定价拍卖除外。\n· 公开拍卖[icon:open|眼睛]：所有人可随时加价。暂不加价后，只要拍卖尚未结束仍可重新出价；每次加价会重新征询其他人。全员不再加价时成交。\n· 一轮拍卖[icon:once|星形1]：从拍卖师左手玩家开始，每人仅一次加价或放弃机会，拍卖师最后行动。\n· 暗标拍卖[icon:hidden|锁]：全员秘密提交一次出价，0代表不出价，同时揭晓。最高价相同时，拍卖师优先，否则从拍卖师左手起顺时针最近者获得。\n· 定价拍卖[icon:fixed|价签]：拍卖师定出自己付得起的价格，其他人从其左手起依次决定购买或放弃。首位购买者获得；全部放弃时拍卖师必须按该价格向银行购买。\n· 双重拍卖[icon:double|双槌]：先打出双重拍卖牌，再由拍卖师决定是否补出同一画家的非双重牌；若不补，其他人顺时针依次获得补牌机会。两幅画作按第二张牌的方式一起拍卖。补牌者成为新拍卖师，获得全部成交款，之后由其左手玩家主持下一场。无人补牌时原拍卖师免费取得第一幅画作。\n回合结算：\n任一画家的第5幅画作被打出时立即结束本轮，该画不拍卖，也不归任何玩家。若它是双重拍卖的第二幅，两幅都不成交；第一幅已是第5幅时不再补牌。所有已打出的画作，包括未成交及神秘玩家的画作，均计入数量。\n按数量排列画家，平手时市场板位置更靠左者优先。前三名本轮分别记30、20、10 k€。仅本轮前三名的画作有价值：每幅售价为该画家所有轮次估值的累计值；其他画家本轮均为0，即使以前有估值。每人将本轮买到的全部画作卖给银行并弃掉，未拍卖的手牌保留。\n新回合：\n第2与第3轮，三人局每人各补6张，四人局4张，五人局3张；第4轮不补牌。上一轮打出结束牌的拍卖师左手玩家开始。没有手牌的玩家跳过主持机会，仍可参与竞拍。若所有人提前用尽手牌，最后打出的画作不拍卖，结算该轮后结束游戏。\n三人神秘玩家变体：\n仅三人局可启用，默认关闭。按四人局发牌，额外一手面朝下作为神秘手牌并保留至后续轮次。拍卖师完成拍卖后，可选择翻开一张随机神秘画作；该画不拍卖也无归属，但计入市场数量并可能触发第5幅结束本轮。神秘双重牌不追加第二张。",
			open: "公开拍卖",
			once: "一轮拍卖",
			hidden: "暗标拍卖",
			fixed: "定价拍卖",
			double: "双重拍卖",
			round: "第{{n}}轮",
			roundOf: "第{{n}}轮 / 共4轮",
			cash: "你的现金",
			money: "{{n}} k€",
			hand: "待拍卖画作",
			collection: "馆藏",
			market: "艺术市场",
			offerPrompt: "选择一幅画作进行拍卖",
			pairPrompt: "补出同一画家的非双重画作，或放弃补牌",
			waiting: "等待{{name}}",
			seller: "{{name}}主持拍卖",
			bidPrompt: "出价",
			pricePrompt: "设定价格",
			pass: "不再加价",
			passOnce: "放弃",
			noPair: "不补牌",
			submit: "提交出价",
			setPrice: "确定价格",
			buy: "购买",
			offer: "拍卖所选画作",
			pair: "补出所选画作",
			cancel: "取消选择",
			current: "当前出价",
			noBid: "尚无人出价",
			highest: "{{name}} · {{n}} k€",
			fixedAt: "售价 {{n}} k€",
			yourBid: "你的暗标：{{n}} k€",
			submitted: "已提交",
			sale: "{{name}}以{{n}} k€购入",
			reveal: "暗标揭晓",
			settling: "出售本轮馆藏",
			roundOver: "本轮结算",
			next: "进入下一轮",
			ready: "已确认",
			count: "{{n}}幅",
			value: "{{n}} k€ / 幅",
			noValue: "未入前三名",
			estimate: "本轮排名",
			history: "历轮估值",
			income: "出售收入",
			mystery: "神秘玩家",
			mysteryHint: "仅三人局生效，按四人局发牌；每次拍卖后可翻开一张神秘画作。",
			revealMystery: "翻开神秘画作",
			skipMystery: "不翻开",
			mysteryLeft: "神秘手牌 {{n}}张",
			auctionHistory: "拍卖记录",
			close: "关闭",
			details: "查看馆藏",
			noPaintings: "暂无馆藏",
			noCards: "手牌已用尽",
			offerLog: "{{name}}展出画作",
			saleLog: "{{name}}以{{n}} k€购入画作",
			roundLog: "第{{n}}轮结束",
			mysteryLog: "翻开神秘画作",
			final: "闭馆结算",
			winner: "{{name}}的美术馆获胜",
			tied: "并列获胜：{{names}}",
			finalCash: "最终资产",
			totalIncome: "累计出售收入",
			review: "查看市场记录",
			showResult: "查看结算",
			confirmAgain: "确认再来一局？",
			confirmLeave: "确认返回大厅？",
			invalid: "当前不能进行此操作，请检查阶段、画作或可用现金。",
			amount: "金额（k€）",
			cardLabel: "{{artist}} · {{kind}} · 画作{{n}}",
			choose: "选择画作",
			guideTitle: "五种拍卖方式",
			helpBid: "出价 {{n}} k€",
			helpOffer: "拍卖{{artist}}的画作",
			helpPass: "放弃本次机会"
		},
		en: {
			name: "Modern Art",
			desc: "Run a museum, trade paintings through five auction types, and read the market over four rounds.",
			rules: "Goal:\nAuction paintings from your hand and acquire paintings for your museum. After four rounds, the player with the most cash wins; equal cash produces a shared victory. Amounts are in thousands of euros (k€). Cash stays private until the end.\nSetup:\nEach player starts with 100 k€. The 70 paintings belong to five artists, in market order: Carvalho (12), Thaler (13), Melim (14), Martins (15), and Silveira (16). Deal 10 cards each with three players, 9 with four, or 8 with five. The starting seat holds the first auction, then play proceeds clockwise.\nAuctions:\nThe auctioneer selects a painting from their hand. Its symbol determines the auction. The buyer pays the auctioneer; an auctioneer buying their own lot pays the bank. Purchased paintings go into the buyer's museum until the round ends. Bids must be whole, nonnegative amounts within your cash; a raise must exceed the current bid. With no bids, the auctioneer takes the lot free, except in fixed-price auctions.\n· Open[icon:open|eye]: Anyone may raise at any time. Passing is temporary: you may bid again before the auction ends. Every raise asks everyone else again; the auction ends when no one wishes to raise.\n· One offer[icon:once|star 1]: Beginning to the auctioneer's left, each player gets one chance to raise or pass. The auctioneer acts last.\n· Hidden[icon:hidden|lock]: Everyone submits one secret bid, including 0 for no bid. Reveal together. The highest bid wins. Ties favor the auctioneer, then the closest tied player clockwise from their left.\n· Fixed price[icon:fixed|price tag]: The auctioneer sets an affordable price. Others, beginning to their left, may buy or pass. The first buyer takes the lot; if all pass, the auctioneer must buy it from the bank at that price.\n· Double[icon:double|double gavel]: Play a double-auction card, then optionally add a non-double painting by the same artist. If the auctioneer declines, others get the same opportunity clockwise. Auction both together using the second card's type. The second contributor becomes auctioneer, receives all proceeds, and play resumes to their left. If nobody contributes, the original auctioneer takes the first painting free.\nRound end:\nThe fifth painting offered by any artist immediately ends the round. It is not auctioned and nobody owns it. If it is the second card of a double auction, neither card is sold; if the first card is already the fifth, no second card is added. Count all offered paintings, including unsold and mystery paintings.\nRank artists by paintings offered, breaking ties toward the left of the market. The top three receive values of 30, 20, and 10 k€ this round. Only the current top three have value: each painting sells for that artist's accumulated value across all rounds. Everyone else is worth 0 this round, regardless of earlier values. Sell and discard every museum painting. Keep unplayed cards in hand.\nNew rounds:\nBefore rounds 2 and 3, deal each player 6 cards with three players, 4 with four, or 3 with five. Deal none before round 4. Start to the left of the auctioneer who ended the last round. Empty-handed players skip hosting but may still bid. If all players run out early, the last offered painting is not auctioned; settle that round and end the game.\nThree-player mystery variant:\nOptional and off by default. Deal as for four players, with an extra face-down mystery hand retained between rounds. After each auction, the auctioneer may reveal a random mystery painting. It is never auctioned or owned, but counts toward popularity and can end the round as the fifth painting. A mystery double card never adds a second painting.",
			open: "Open auction",
			once: "One offer",
			hidden: "Hidden auction",
			fixed: "Fixed price",
			double: "Double auction",
			round: "Round {{n}}",
			roundOf: "Round {{n}} of 4",
			cash: "Your cash",
			money: "{{n}} k€",
			hand: "Paintings to auction",
			collection: "Collection",
			market: "Art market",
			offerPrompt: "Choose a painting to auction",
			pairPrompt: "Add a non-double painting by the same artist, or pass",
			waiting: "Waiting for {{name}}",
			seller: "{{name}} is auctioneer",
			bidPrompt: "Your bid",
			pricePrompt: "Set a price",
			pass: "No further raise",
			passOnce: "Pass",
			noPair: "Do not add",
			submit: "Submit bid",
			setPrice: "Set price",
			buy: "Buy",
			offer: "Auction painting",
			pair: "Add painting",
			cancel: "Cancel selection",
			current: "Current bid",
			noBid: "No bids yet",
			highest: "{{name}} · {{n}} k€",
			fixedAt: "Price {{n}} k€",
			yourBid: "Your sealed bid: {{n}} k€",
			submitted: "Submitted",
			sale: "{{name}} bought for {{n}} k€",
			reveal: "Bids revealed",
			settling: "Selling museum paintings",
			roundOver: "Round accounts",
			next: "Next round",
			ready: "Confirmed",
			count: "{{n}} paintings",
			value: "{{n}} k€ each",
			noValue: "Outside top three",
			estimate: "Round ranking",
			history: "Past values",
			income: "Sale revenue",
			mystery: "Mystery player",
			mysteryHint: "Three players only. Deal as for four; optionally reveal a mystery painting after each auction.",
			revealMystery: "Reveal a painting",
			skipMystery: "Do not reveal",
			mysteryLeft: "Mystery hand: {{n}}",
			auctionHistory: "Auction record",
			close: "Close",
			details: "View collection",
			noPaintings: "No paintings yet",
			noCards: "No cards left",
			offerLog: "{{name}} offered a painting",
			saleLog: "{{name}} bought paintings for {{n}} k€",
			roundLog: "Round {{n}} ended",
			mysteryLog: "A mystery painting was revealed",
			final: "Closing accounts",
			winner: "{{name}} wins",
			tied: "Joint winners: {{names}}",
			finalCash: "Final assets",
			totalIncome: "Total sale revenue",
			review: "Review market",
			showResult: "Show results",
			confirmAgain: "Play again?",
			confirmLeave: "Return to lobby?",
			invalid: "That action is unavailable. Check the stage, painting, and available cash.",
			amount: "Amount (k€)",
			cardLabel: "{{artist}} · {{kind}} · Painting {{n}}",
			choose: "Choose a painting",
			guideTitle: "Five auction types",
			helpBid: "Bid {{n}} k€",
			helpOffer: "Auction a painting by {{artist}}",
			helpPass: "Pass this opportunity"
		}
	}
};
//#endregion
export { he as default };
