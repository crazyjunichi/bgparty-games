import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n, useSyncExternalStore as r } from "react";
import { botAvatarOf as i } from "@bgparty/sdk/lobby";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconBot as u, IconCheck as d, IconClose as f, IconDisconnected as p } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as m } from "@bgparty/sdk/player-colors";
import { Texture as h } from "@bgparty/sdk/texture";
import { GameScreen as g } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as ee } from "@bgparty/sdk/ui/phase-banner";
import { seatName as _ } from "@bgparty/sdk/ui/player-strip";
import { jsx as v, jsxs as y } from "react/jsx-runtime";
import { Floater as b, FlySprite as x } from "@bgparty/sdk/fx/primitives";
import { Confetti as te } from "@bgparty/sdk/ui/confetti";
//#region src/games/gang/cards.ts
var S = (e) => e % 13 + 2, C = (e) => Math.floor(e / 13), w = Array.from({ length: 52 }, (e, t) => t), ne = 15, re = 5, ie = ne ** re;
function T(e, t) {
	let n = e;
	for (let e = 0; e < re; e += 1) n = n * ne + (t[e] ?? 0);
	return n;
}
var E = (e) => Math.floor(e / ie);
function D(e) {
	for (let t = 14; t >= 6; --t) if (e[t] && e[t - 1] && e[t - 2] && e[t - 3] && e[t - 4]) return t;
	return e[14] && e[2] && e[3] && e[4] && e[5] ? 5 : 0;
}
function O(e) {
	if (e.length < 5) return -1;
	let t = Array(15).fill(0), n = [
		[],
		[],
		[],
		[]
	];
	for (let r of e) t[S(r)] += 1, n[C(r)].push(S(r));
	let r = t.map((e) => e > 0), i = [];
	for (let e = 14; e >= 2; --e) t[e] > 0 && i.push(e);
	for (let e = 0; e < 4; e += 1) {
		if (n[e].length < 5) continue;
		let t = n[e].sort((e, t) => t - e), r = Array(15).fill(!1);
		for (let e of t) r[e] = !0;
		let i = D(r);
		return i > 0 ? T(8, [i]) : T(5, t.slice(0, 5));
	}
	let a = i.find((e) => t[e] === 4);
	if (a !== void 0) return T(7, [a, i.find((e) => e !== a)]);
	let o = i.filter((e) => t[e] === 3), s = i.filter((e) => t[e] === 2);
	if (o.length > 0 && (s.length > 0 || o.length > 1)) return T(6, [o[0], o.length > 1 ? o[1] : s[0]]);
	let c = D(r);
	return c > 0 ? T(4, [c]) : o.length > 0 ? T(3, [o[0], ...i.filter((e) => e !== o[0]).slice(0, 2)]) : s.length >= 2 ? T(2, [
		s[0],
		s[1],
		i.find((e) => e !== s[0] && e !== s[1])
	]) : s.length === 1 ? T(1, [s[0], ...i.filter((e) => e !== s[0]).slice(0, 3)]) : T(0, i.slice(0, 5));
}
function ae(e) {
	let t = [], n = -2, r = e.length;
	for (let i = 0; i < r - 4; i += 1) for (let a = i + 1; a < r - 3; a += 1) for (let o = a + 1; o < r - 2; o += 1) for (let s = o + 1; s < r - 1; s += 1) for (let c = s + 1; c < r; c += 1) {
		let r = [
			e[i],
			e[a],
			e[o],
			e[s],
			e[c]
		], l = O(r);
		l > n && (n = l, t = r);
	}
	return t.sort((e, t) => S(e) - S(t) || C(e) - C(t));
}
function k(e) {
	let t = Object.keys(e).sort((t, n) => e[n] - e[t]), n = /* @__PURE__ */ new Map(), r = 0;
	for (; r < t.length;) {
		let i = r;
		for (; i + 1 < t.length && e[t[i + 1]] === e[t[r]];) i += 1;
		for (let e = r; e <= i; e += 1) n.set(t[e], [r + 1, i + 1]);
		r = i + 1;
	}
	return n;
}
//#endregion
//#region src/games/gang/meta.ts
var A = {
	id: "gang",
	tier: "released",
	mechanics: ["deduction"],
	interactionTags: ["cooperative"],
	nameKey: "games.gang.name",
	descKey: "games.gang.desc",
	rulesKey: "games.gang.rules",
	icon: "🃏",
	iconImg: "games/gang.webp",
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [5],
	accent: "#15803d",
	releasedAt: "2026-09-09",
	search: {
		py: "zhi pai bang",
		init: "zpb"
	},
	hotseat: "cover"
}, j = t.int().min(0).max(51), M = t.string(), N = t.int().min(1).max(6), oe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("claim"),
		rank: N
	}),
	t.object({ type: t.literal("release") }),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), se = t.object({
	phase: t.enum([
		"preflop",
		"flop",
		"turn",
		"river",
		"showdown",
		"done"
	]),
	round: t.int().min(1),
	wins: t.int().nonnegative(),
	losses: t.int().nonnegative(),
	community: t.array(j),
	pool: t.array(N),
	claims: t.record(M, N),
	history: t.record(M, t.array(N)),
	players: t.array(t.object({
		rid: M,
		claimed: t.boolean()
	})),
	showdown: t.object({
		hands: t.record(M, t.array(j)),
		verdict: t.enum(["win", "lose"])
	}).nullable()
}), ce = t.object({
	hand: t.array(j),
	myClaim: N.nullable()
}), le = {
	claim: 1500,
	showdown: 3200
}, P = [
	"preflop",
	"flop",
	"turn",
	"river"
];
function F(t) {
	let n = [...w];
	for (let r = n.length - 1; r > 0; --r) {
		let i = e(t.rngSeed, t.rngCursor, r + 1);
		t.rngCursor += 1, [n[r], n[i]] = [n[i], n[r]];
	}
	let r = {}, i = 0;
	for (let e of t.players) r[e] = n.slice(i, i + 2), i += 2;
	return t.hands = r, t.deck = n.slice(i), t.community = [], t.claims = {}, t.history = {}, t.verdict = null, t.players.map((e, t) => ({
		kind: "deal",
		rid: e,
		data: { count: 2 },
		for: [e],
		secret: { cards: r[e] },
		...t > 0 ? { with: !0 } : {}
	}));
}
function ue(e) {
	let t = {};
	for (let n of e.players) t[n] = O([...e.hands[n], ...e.community]);
	let n = k(t);
	for (let t of e.players) {
		let r = n.get(t), i = e.claims[t];
		if (i === void 0 || i < r[0] || i > r[1]) return "lose";
	}
	return "win";
}
var de = (e) => e.players.every((t) => t in e.claims);
function fe(e, t, n) {
	let r = {
		players: t,
		hands: {},
		deck: [],
		community: [],
		claims: {},
		history: {},
		phase: "preflop",
		round: 1,
		wins: 0,
		losses: 0,
		verdict: null,
		rngSeed: n,
		rngCursor: 0
	};
	return {
		state: r,
		fx: F(r)
	};
}
function pe(e) {
	if (e.phase === "river") {
		e.phase = "showdown", e.verdict = ue(e);
		let t = {};
		for (let n of e.players) t[n] = O([...e.hands[n], ...e.community]);
		let n = [...e.players].sort((e, n) => t[n] - t[e]);
		return [{
			kind: "showdown",
			data: {
				hands: e.hands,
				verdict: e.verdict,
				order: n
			}
		}];
	}
	for (let [t, n] of Object.entries(e.claims)) (e.history[t] ??= []).push(n);
	e.claims = {};
	let t = e.phase === "preflop" ? 3 : 1, n = e.community.length, r = e.deck.slice(0, t);
	return e.community = [...e.community, ...r], e.deck = e.deck.slice(t), e.phase = e.phase === "preflop" ? "flop" : e.phase === "flop" ? "turn" : "river", [{
		kind: "community",
		data: {
			cards: r,
			from: n
		}
	}];
}
function me(e, t, n) {
	if (t.type === "tick") {
		if (P.includes(e.phase)) {
			if (!de(e)) return {
				state: e,
				fx: []
			};
			let t = structuredClone(e);
			return {
				state: t,
				fx: pe(t)
			};
		}
		return {
			state: e,
			fx: []
		};
	}
	if (t.type === "next") {
		if (e.phase !== "showdown") return { code: "games.gang.errNotShowdown" };
		let t = structuredClone(e);
		return t.verdict === "win" ? t.wins += 1 : t.losses += 1, t.wins >= 3 ? (t.phase = "done", {
			state: t,
			fx: []
		}) : (t.round += 1, t.phase = "preflop", {
			state: t,
			fx: F(t)
		});
	}
	if (!P.includes(e.phase)) return { code: "games.gang.errNotBetting" };
	if (t.type === "claim") {
		if (t.rank > e.players.length) return { code: "games.gang.errBadRank" };
		let r = e.claims[n.by] ?? null;
		if (r === t.rank) return {
			state: e,
			fx: []
		};
		let i = Object.entries(e.claims).find(([e, r]) => r === t.rank && e !== n.by)?.[0] ?? null, a = structuredClone(e);
		i && delete a.claims[i], a.claims[n.by] = t.rank;
		let o = a.players.length, s = o + 1 - t.rank;
		return {
			state: a,
			fx: [{
				kind: "claim",
				rid: n.by,
				data: {
					rank: t.rank,
					prev: r,
					from: i,
					phase: e.phase,
					stars: s,
					prevStars: r === null ? null : o + 1 - r
				}
			}]
		};
	}
	let r = e.claims[n.by];
	if (r === void 0) return { code: "games.gang.errNoChip" };
	let i = structuredClone(e);
	return delete i.claims[n.by], {
		state: i,
		fx: [{
			kind: "release",
			rid: n.by,
			data: {
				rank: r,
				phase: e.phase,
				stars: i.players.length + 1 - r
			}
		}]
	};
}
function he(e, t) {
	let n = new Set(Object.values(e.claims)), r = [];
	for (let t = 1; t <= e.players.length; t += 1) n.has(t) || r.push(t);
	let i = e.phase === "showdown" ? {
		hands: e.hands,
		verdict: e.verdict ?? "lose"
	} : null;
	return {
		public: {
			phase: e.phase,
			round: e.round,
			wins: e.wins,
			losses: e.losses,
			community: e.community,
			pool: r,
			claims: { ...e.claims },
			history: structuredClone(e.history),
			players: e.players.map((t) => ({
				rid: t,
				claimed: t in e.claims
			})),
			showdown: i
		},
		private: {
			hand: e.hands[t] ?? [],
			myClaim: e.claims[t] ?? null
		}
	};
}
function ge(e) {
	return e.phase === "done" ? {
		phase: "done",
		winner: [...e.players],
		ranking: [...e.players]
	} : { phase: e.phase };
}
function _e(e) {
	return P.includes(e.phase) && de(e) ? le.claim : null;
}
var ve = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: A,
	schemas: {
		action: oe,
		publicView: se,
		privateView: ce
	},
	setup: fe,
	reduce: me,
	viewFor: he,
	status: ge,
	nextTickIn: _e
}, I = [
	"preflop",
	"flop",
	"turn",
	"river"
], L = (e) => I.includes(e), R = (e) => B[L(e) ? e : "river"], z = (e, t) => t + 1 - e, B = {
	preflop: {
		bg: "#ffffff",
		fg: "var(--color-ink)"
	},
	flop: {
		bg: "#facc15",
		fg: "var(--color-ink)"
	},
	turn: {
		bg: "#f97316",
		fg: "#ffffff"
	},
	river: {
		bg: "#ef4444",
		fg: "#ffffff"
	}
}, V = [
	"",
	"",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"10",
	"J",
	"Q",
	"K",
	"A"
], H = [
	"♠",
	"♥",
	"♦",
	"♣"
], U = [
	"text-ink",
	"text-danger",
	"text-info",
	"text-done"
], ye = (e) => V[e], be = (e) => H[e];
function W({ card: e, size: t, elevated: n }) {
	let r = S(e), i = C(e), a = {
		hand: "h-22 w-16 rounded border-2 px-1 py-1",
		comm: "h-20 w-14 short:h-16 short:w-11 rounded border-2 px-1 py-1",
		table: "h-16 w-11 rounded border-2 px-0.5 py-0.5",
		mini: "h-11 w-8 rounded-sm border-2 px-0.5 py-0.5"
	}[t], o = {
		hand: "text-xl",
		comm: "text-lg",
		table: "text-sm",
		mini: "text-xs"
	}[t], s = {
		hand: "text-4xl",
		comm: "text-3xl",
		table: "text-2xl",
		mini: "text-lg"
	}[t];
	return /* @__PURE__ */ y("span", {
		"aria-label": `${V[r]}${H[i]}`,
		className: `gang-card-face relative inline-flex flex-none flex-col border-ink bg-surface ${a} ${n ? "shadow-[2px_2px_0_var(--color-ink)]" : ""}`,
		"data-size": t,
		"data-elevated": n,
		children: [
			t !== "mini" && /* @__PURE__ */ v("span", {
				"aria-hidden": !0,
				className: "gang-card-inner pointer-events-none absolute inset-0.75 rounded-[2px] border border-warn/35"
			}),
			/* @__PURE__ */ v("span", {
				className: `gang-card-rank font-display leading-none font-extrabold tabular-nums ${o} ${U[i]}`,
				children: V[r]
			}),
			/* @__PURE__ */ v("span", {
				"aria-hidden": !0,
				className: `gang-card-suit grid flex-1 place-items-center leading-none ${s} ${U[i]}`,
				children: H[i]
			}),
			t !== "mini" && /* @__PURE__ */ v("span", {
				"aria-hidden": !0,
				className: "gang-card-ornament absolute right-1 bottom-0.5 text-[8px] leading-none text-warn-ink/45",
				children: "✦"
			})
		]
	});
}
function G({ size: e = "table", fill: t }) {
	return /* @__PURE__ */ v("span", {
		className: `gang-card-back relative inline-flex ${t ? "h-full w-full" : e === "comm" ? "h-20 w-14 short:h-16 short:w-11" : "h-16 w-11"} flex-none overflow-hidden rounded border-2 border-ink bg-ink`,
		children: /* @__PURE__ */ y("svg", {
			className: "absolute inset-0 size-full",
			viewBox: "0 0 64 90",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ v("rect", {
					x: "3",
					y: "3",
					width: "58",
					height: "84",
					rx: "2",
					fill: "none",
					stroke: "var(--color-warn)",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ v("rect", {
					x: "7",
					y: "7",
					width: "50",
					height: "76",
					rx: "1",
					fill: "none",
					stroke: "var(--color-surface)",
					strokeWidth: "0.8"
				}),
				/* @__PURE__ */ v("rect", {
					x: "10",
					y: "10",
					width: "44",
					height: "70",
					rx: "1",
					fill: "none",
					stroke: "var(--color-warn)",
					strokeWidth: "0.7"
				}),
				/* @__PURE__ */ v("path", {
					d: "M15 13h34M15 77h34",
					stroke: B.river.bg,
					strokeWidth: "1.2"
				}),
				/* @__PURE__ */ v("path", {
					d: "M12 12v11l4-10 4 7M52 12v11l-4-10-4 7M12 78V67l4 10 4-7M52 78V67l-4 10-4-7",
					fill: "none",
					stroke: B.river.bg,
					strokeWidth: "1.3",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ v("path", {
					d: "M13 30q5 15 0 30M51 30q-5 15 0 30",
					fill: "none",
					stroke: "var(--color-warn)",
					strokeWidth: "0.8"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "32",
					cy: "45",
					r: "23",
					fill: "var(--color-ink)",
					stroke: "var(--color-warn)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "32",
					cy: "45",
					r: "20",
					fill: "none",
					stroke: "var(--color-surface)",
					strokeWidth: "0.7"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "32",
					cy: "45",
					r: "17",
					fill: "none",
					stroke: "var(--color-warn)",
					strokeWidth: "1"
				}),
				Array.from({ length: 12 }, (e, t) => /* @__PURE__ */ v("path", {
					d: "M32 22v3",
					transform: `rotate(${t * 30} 32 45)`,
					stroke: "var(--color-warn)",
					strokeWidth: "1.3",
					strokeLinecap: "round"
				}, t)),
				/* @__PURE__ */ v("circle", {
					cx: "32",
					cy: "45",
					r: "12",
					fill: B.river.bg,
					stroke: "var(--color-warn)",
					strokeWidth: "1.2"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "32",
					cy: "45",
					r: "9",
					fill: "var(--color-ink)",
					stroke: "var(--color-surface)",
					strokeWidth: "0.7"
				}),
				/* @__PURE__ */ v("path", {
					d: "m32 37 2.4 5.6L40 45l-5.6 2.4L32 53l-2.4-5.6L24 45l5.6-2.4Z",
					fill: "var(--color-warn)"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "32",
					cy: "45",
					r: "2.6",
					fill: "var(--color-surface)"
				})
			]
		})
	});
}
//#endregion
//#region src/games/gang/chip.tsx
function xe({ className: e, style: t }) {
	return /* @__PURE__ */ v("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		"aria-hidden": !0,
		className: e,
		style: t,
		children: /* @__PURE__ */ v("path", { d: "M12 2.6l2.83 5.9 6.47.87-4.73 4.5 1.18 6.4L12 17.2l-5.75 3.07 1.18-6.4-4.73-4.5 6.47-.87L12 2.6z" })
	});
}
function K({ stars: e, color: t, className: n }) {
	let r = e > 4 ? 20 : 24;
	return /* @__PURE__ */ y("span", {
		className: `gang-chip relative block h-full w-full rounded-full border-3 border-ink shadow-[2px_2px_0_var(--color-ink)] ${n ?? ""}`,
		style: {
			background: t.bg,
			color: t.fg
		},
		children: [/* @__PURE__ */ v("span", {
			className: "gang-chip-number absolute top-[44%] left-1/2 -translate-x-1/2 -translate-y-1/2 font-display text-2xl leading-none font-extrabold tabular-nums",
			children: e
		}), Array.from({ length: e }, (t, n) => {
			let i = (n - (e - 1) / 2) * r;
			return /* @__PURE__ */ v(xe, {
				className: "gang-chip-star absolute size-1.5",
				style: {
					left: "50%",
					top: "50%",
					transform: `translate(-50%, -50%) rotate(${i}deg) translateY(var(--gang-chip-radius, 14px)) rotate(${-i * .55}deg)`
				}
			}, n);
		})]
	});
}
function Se({ stars: e, color: t }) {
	return /* @__PURE__ */ v("span", {
		className: "gang-chip-mini grid size-4.5 flex-none place-items-center rounded-full border-2 border-ink font-display text-[11px] leading-none font-extrabold tabular-nums",
		style: {
			background: t.bg,
			color: t.fg
		},
		children: e
	});
}
//#endregion
//#region src/games/gang/view-player.tsx
var Ce = "(orientation: landscape)", we = (e) => {
	let t = window.matchMedia(Ce);
	return t.addEventListener("change", e), () => t.removeEventListener("change", e);
}, Te = () => window.matchMedia(Ce).matches, q = {
	preflop: "games.gang.stagePreflop",
	flop: "games.gang.stageFlop",
	turn: "games.gang.stageTurn",
	river: "games.gang.stageRiver",
	showdown: "games.gang.stageShowdown",
	done: "games.gang.stageShowdown"
}, Ee = [
	"games.gang.hand0",
	"games.gang.hand1",
	"games.gang.hand2",
	"games.gang.hand3",
	"games.gang.hand4",
	"games.gang.hand5",
	"games.gang.hand6",
	"games.gang.hand7",
	"games.gang.hand8"
];
function De(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ v(Oe, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Oe({ pub: e, priv: t, members: n, myRid: i, send: a }) {
	let o = l(), s = r(we, Te, () => !1), c = L(e.phase), u = t?.myClaim ?? null, d = {
		"--gang-felt": A.accent,
		"--gang-river": B.river.bg,
		"--gang-player-count": e.players.length,
		"--gang-seat-cols": e.players.length === 3 ? 1 : 2,
		"--gang-seat-rows": e.players.length === 4 ? 2 : 3
	}, f, p;
	if (e.phase === "showdown") {
		let t = e.showdown?.verdict === "win";
		f = t ? "done" : "warn", p = o(t ? "games.gang.verdictWin" : "games.gang.verdictLose");
	} else c && u === null ? (f = "accent", p = o("games.gang.claimPrompt")) : (f = "info", p = o("games.gang.waitingAll"));
	let m = /* @__PURE__ */ v(Me, {
		priv: t,
		community: e.community
	});
	return /* @__PURE__ */ y("div", {
		className: "gang-game h-full min-h-0",
		style: d,
		children: [/* @__PURE__ */ v(g, {
			adaptive: !0,
			className: "gang-adaptive",
			banner: /* @__PURE__ */ y("div", {
				className: "gang-top flex flex-col gap-1",
				children: [/* @__PURE__ */ y("div", {
					className: "gang-mast",
					children: [/* @__PURE__ */ y("span", {
						className: "gang-brand",
						children: [/* @__PURE__ */ v("span", {
							className: "gang-brand-mark",
							"aria-hidden": !0,
							children: "✦"
						}), /* @__PURE__ */ y("span", {
							className: "gang-brand-copy",
							children: [/* @__PURE__ */ v("strong", { children: o("games.gang.name") }), /* @__PURE__ */ v("small", { children: o("games.gang.brandSub") })]
						})]
					}), /* @__PURE__ */ y("span", {
						className: "gang-score font-mono tabular-nums",
						children: [/* @__PURE__ */ v("strong", { children: o("games.gang.round", { n: e.round }) }), /* @__PURE__ */ y("small", { children: [o("games.gang.progressShort", {
							n: e.wins,
							total: 3
						}), e.losses > 0 && ` · ${o("games.gang.lossesShort", { n: e.losses })}`] })]
					})]
				}), /* @__PURE__ */ v("div", {
					className: "gang-banner",
					"data-tone": f,
					children: /* @__PURE__ */ v(ee, {
						tone: f,
						text: p,
						chip: o(q[e.phase]),
						accent: A.accent
					})
				})]
			}),
			actionsHeight: s ? void 0 : "h-28",
			actions: s ? void 0 : m,
			scroll: !1,
			children: /* @__PURE__ */ y("div", {
				className: "gang-layout flex h-full min-h-0 flex-col gap-1.5 wide:grid wide:grid-cols-[minmax(11rem,24%)_minmax(0,1fr)_minmax(10rem,22%)]",
				"data-seat-layout": e.players.length === 3 ? "single" : "double",
				children: [
					/* @__PURE__ */ v(ke, {
						pub: e,
						members: n,
						myRid: i,
						betting: c,
						send: a
					}),
					/* @__PURE__ */ v(je, {
						pub: e,
						betting: c,
						send: a
					}),
					s && /* @__PURE__ */ v("div", {
						className: "gang-hand-panel min-h-0",
						children: m
					})
				]
			})
		}), /* @__PURE__ */ v(Ne, {
			pub: e,
			members: n,
			send: a
		})]
	});
}
function ke({ pub: e, members: t, myRid: n, betting: r, send: a }) {
	let o = l(), s = c((e) => e.locale), f = t.filter((t) => e.players.some((e) => e.rid === t.rid)), m = f.length === 4 ? "grid-cols-4" : "grid-cols-3";
	return /* @__PURE__ */ v("ul", {
		className: `gang-seats grid max-h-full min-h-0 flex-none gap-1 short:overflow-y-auto wide:grid-cols-2 wide:content-start ${m}`,
		children: f.map((t) => {
			let c = e.claims[t.rid] !== void 0, l = t.rid === n, f = o(r ? c ? l ? "games.gang.seatReturn" : "games.gang.seatSteal" : "games.gang.seatAwait" : "games.gang.seatLocked"), m = e.history[t.rid] ?? [];
			return /* @__PURE__ */ y("li", {
				className: "gang-seat",
				"data-mine": l,
				"data-offline": !t.online,
				children: [
					/* @__PURE__ */ y("div", {
						className: "gang-seat-head",
						children: [
							/* @__PURE__ */ v(Ae, { member: t }),
							/* @__PURE__ */ v("span", {
								className: "gang-seat-name",
								title: _(t, s),
								children: _(t, s)
							}),
							l && /* @__PURE__ */ v("span", {
								className: "gang-seat-self",
								role: "img",
								"aria-label": o("lobby.you"),
								children: "✦"
							})
						]
					}),
					/* @__PURE__ */ y("div", {
						className: "gang-seat-main",
						children: [/* @__PURE__ */ v(Fe, {
							pub: e,
							rid: t.rid,
							myRid: n,
							betting: r,
							send: a
						}), /* @__PURE__ */ v("span", {
							className: "gang-seat-action",
							"data-action": c && !l && r ? "steal" : void 0,
							children: f
						})]
					}),
					/* @__PURE__ */ y("div", {
						className: "gang-seat-history",
						children: [t.online ? i(t.rid) === null ? r && (c ? /* @__PURE__ */ v(d, {
							size: 12,
							strokeWidth: 3,
							"aria-label": o("lobby.done")
						}) : /* @__PURE__ */ v("span", {
							role: "status",
							"aria-label": o("lobby.thinking"),
							children: "…"
						})) : /* @__PURE__ */ v(u, {
							size: 12,
							"aria-label": o("lobby.bot")
						}) : /* @__PURE__ */ v(p, {
							size: 12,
							"aria-label": o("lobby.offline")
						}), m.map((t, n) => /* @__PURE__ */ v(Pe, {
							phase: I[n],
							stars: z(t, e.players.length)
						}, n))]
					})
				]
			}, t.rid);
		})
	});
}
function Ae({ member: e }) {
	let { ref: t } = s(`seat:${e.rid}`), n = m[e.colorIndex % m.length];
	return /* @__PURE__ */ v("span", {
		ref: t,
		className: "gang-seat-avatar",
		style: { backgroundColor: n.hex },
		children: /* @__PURE__ */ v("img", {
			src: a[e.avatar % a.length],
			alt: "",
			draggable: !1
		})
	});
}
function je({ pub: e, betting: t, send: n }) {
	let r = l(), { ref: i } = s("deck");
	return /* @__PURE__ */ y("section", {
		className: "gang-table w-full",
		"aria-label": r("games.gang.name"),
		children: [
			/* @__PURE__ */ v(h, {
				kind: "sheen",
				base: A.accent,
				className: "gang-table-texture"
			}),
			/* @__PURE__ */ y("div", {
				className: "gang-table-top relative z-1 flex h-20 w-full flex-none justify-center short:h-13",
				children: [
					/* @__PURE__ */ v("span", {
						className: "gang-table-plaque",
						children: r("games.gang.brandSub")
					}),
					/* @__PURE__ */ v("span", {
						ref: i,
						className: "gang-deck-stack h-17 w-12 short:h-11 short:w-8",
						role: "img",
						"aria-label": r("games.gang.deck"),
						children: /* @__PURE__ */ v(G, { fill: !0 })
					}),
					/* @__PURE__ */ v("span", {
						className: "gang-table-fan",
						"aria-hidden": !0,
						children: "✺"
					})
				]
			}),
			/* @__PURE__ */ v("div", {
				className: "gang-community-row relative z-1 flex h-22 w-full flex-none items-center justify-center gap-1 short:h-17",
				children: Array.from({ length: 5 }, (t, n) => /* @__PURE__ */ v(Ie, {
					index: n,
					card: e.community[n]
				}, n))
			}),
			/* @__PURE__ */ v("div", {
				className: "gang-table-dial relative z-1 grid min-h-0 w-full flex-1 place-items-center",
				children: /* @__PURE__ */ y("div", {
					className: "gang-dial size-25 short:size-15",
					"aria-label": r("games.gang.progress", {
						n: e.wins,
						total: 3
					}),
					children: [
						/* @__PURE__ */ v("span", {
							className: "gang-dial-stars",
							"aria-hidden": !0,
							children: "✦ ✦ ✦"
						}),
						/* @__PURE__ */ y("b", {
							className: "font-mono tabular-nums",
							children: [
								e.wins,
								"/",
								3
							]
						}),
						/* @__PURE__ */ v("small", { children: r("games.gang.winsLabel") })
					]
				})
			}),
			/* @__PURE__ */ v(Le, {
				pub: e,
				betting: t,
				send: n
			})
		]
	});
}
function Me({ priv: e, community: t }) {
	let n = l(), r = e?.hand.length === 2 && t.length >= 3 ? E(O([...e.hand, ...t])) : null;
	return /* @__PURE__ */ y("div", {
		className: "gang-hand wide:flex-col wide:justify-center",
		children: [
			/* @__PURE__ */ v("span", {
				className: "gang-hand-label",
				children: n("games.gang.handLabel")
			}),
			/* @__PURE__ */ v("div", {
				className: "gang-hand-cards flex flex-none gap-2",
				children: e?.hand.length ? e.hand.map((e) => /* @__PURE__ */ v(Be, {
					card: e,
					size: "hand",
					elevated: !0
				}, e)) : [0, 1].map((e) => /* @__PURE__ */ v(G, { size: "comm" }, e))
			}),
			/* @__PURE__ */ y("div", {
				className: "gang-hand-read wide:items-center wide:text-center",
				children: [
					/* @__PURE__ */ v("small", { children: n("games.gang.handCategoryLabel") }),
					/* @__PURE__ */ v("strong", { children: n(r === null ? "games.gang.handPending" : Ee[r]) }),
					/* @__PURE__ */ v("em", {
						className: "wide:self-center",
						children: n("games.gang.handHint")
					})
				]
			})
		]
	});
}
function Ne({ pub: e, members: t, send: r }) {
	let i = l(), a = e.showdown !== null, [s, c] = n(() => e.showdown ? e : null), [u, d] = n(a);
	a !== u && (d(a), a && c(e));
	let f = s?.showdown?.verdict === "win";
	return /* @__PURE__ */ v("div", {
		className: "gang-showdown-scope",
		children: /* @__PURE__ */ v(o, {
			open: a,
			label: i("games.gang.stageShowdown"),
			title: /* @__PURE__ */ y("span", {
				className: "gang-showdown-title",
				children: [/* @__PURE__ */ v("span", {
					"aria-hidden": !0,
					children: f ? "✓" : "✗"
				}), i(f ? "games.gang.verdictWin" : "games.gang.verdictLose")]
			}),
			footer: /* @__PURE__ */ v("div", {
				className: "gang-showdown-footer",
				children: /* @__PURE__ */ v("button", {
					type: "button",
					disabled: !a,
					onClick: () => r({ type: "next" }),
					className: "btn-base w-full",
					style: {
						background: A.accent,
						color: "#fff"
					},
					children: i("games.gang.nextRound")
				})
			}),
			children: s?.showdown && /* @__PURE__ */ y("div", {
				className: "gang-showdown-content",
				children: [/* @__PURE__ */ y("section", {
					className: "gang-showdown-public",
					"aria-label": i("games.gang.showdownPublic"),
					children: [
						/* @__PURE__ */ v("h3", { children: i("games.gang.showdownPublic") }),
						/* @__PURE__ */ v("div", {
							className: "gang-showdown-public-cards",
							children: s.community.map((e) => /* @__PURE__ */ v(W, {
								card: e,
								size: "comm"
							}, e))
						}),
						/* @__PURE__ */ v("p", { children: i("games.gang.showdownBestHint") })
					]
				}), /* @__PURE__ */ v(ze, {
					pub: s,
					members: t
				})]
			})
		})
	});
}
function Pe({ phase: e, stars: t }) {
	let n = l();
	return /* @__PURE__ */ v("span", {
		role: "img",
		"aria-label": n("games.gang.historyChipAria", {
			stage: n(q[e]),
			n: t
		}),
		className: "inline-flex",
		children: /* @__PURE__ */ v(Se, {
			stars: t,
			color: B[e]
		})
	});
}
function Fe({ pub: e, rid: t, myRid: n, betting: r, send: i }) {
	let a = l(), { ref: o, hidden: c } = s(`schip:${t}`), u = e.claims[t], d = e.players.length, f = R(e.phase), p = t === n, m = u === void 0 ? 0 : z(u, d), h = u === void 0 ? void 0 : a(p ? "games.gang.releaseAria" : "games.gang.stealAria", { n: m });
	return /* @__PURE__ */ y("span", {
		ref: o,
		className: "gang-seat-slot",
		"aria-label": u === void 0 ? a("games.gang.seatAwait") : void 0,
		children: [/* @__PURE__ */ v("span", {
			"aria-hidden": !0,
			children: "✦"
		}), u !== void 0 && /* @__PURE__ */ v("span", {
			className: "absolute -inset-0.5",
			style: { visibility: c ? "hidden" : void 0 },
			children: /* @__PURE__ */ v("button", {
				type: "button",
				disabled: !r,
				"aria-label": h,
				onClick: () => i(p ? { type: "release" } : {
					type: "claim",
					rank: u
				}),
				className: `h-full w-full rounded-full ${r ? "active:translate-y-0.5" : "cursor-default"}`,
				children: /* @__PURE__ */ v(K, {
					stars: m,
					color: f,
					className: p ? "ring-2 ring-white ring-inset" : void 0
				})
			})
		})]
	});
}
function Ie({ index: e, card: t }) {
	let n = l(), { ref: r } = s(`comm:${e}`);
	return /* @__PURE__ */ y("span", {
		ref: r,
		className: "gang-card-slot h-20 w-14 short:h-16 short:w-11",
		children: [/* @__PURE__ */ y("span", {
			className: "gang-card-slot-empty",
			"aria-hidden": t !== void 0,
			children: [/* @__PURE__ */ v("span", {
				"aria-hidden": !0,
				children: "✦"
			}), /* @__PURE__ */ v("small", { children: n(q[e < 3 ? "flop" : e === 3 ? "turn" : "river"]) })]
		}), t !== void 0 && /* @__PURE__ */ v("span", {
			className: "card-flip-in absolute -inset-0.5",
			children: /* @__PURE__ */ v(Be, {
				card: t,
				size: "comm"
			})
		})]
	});
}
function Le({ pub: e, betting: t, send: n }) {
	let r = l(), i = new Set(e.pool), a = Array.from({ length: e.players.length }, (e, t) => t + 1);
	return /* @__PURE__ */ y("div", {
		className: "gang-pool-wrap h-22 short:h-19",
		children: [
			/* @__PURE__ */ v("span", {
				className: "gang-pool-title",
				children: r("games.gang.chipsTitle")
			}),
			/* @__PURE__ */ v("div", {
				className: "gang-pool-row flex w-full items-center justify-around gap-1",
				children: a.map((r) => /* @__PURE__ */ v(Re, {
					rank: r,
					free: t && i.has(r),
					pub: e,
					send: n
				}, r))
			}),
			/* @__PURE__ */ v("span", {
				className: "gang-pool-help",
				children: r("games.gang.chipsHelp")
			})
		]
	});
}
function Re({ rank: e, free: t, pub: n, send: r }) {
	let i = l(), { ref: a, hidden: o } = s(`chip:${e}`), c = R(n.phase), u = z(e, n.players.length);
	return /* @__PURE__ */ y("span", {
		ref: a,
		className: "gang-pool-slot",
		children: [/* @__PURE__ */ v("span", {
			"aria-hidden": !0,
			className: "gang-pool-imprint font-display tabular-nums",
			children: u
		}), t && /* @__PURE__ */ v("span", {
			className: "absolute inset-0",
			style: { visibility: o ? "hidden" : void 0 },
			children: /* @__PURE__ */ v("button", {
				type: "button",
				"aria-label": i("games.gang.chipAria", { n: u }),
				onClick: () => r({
					type: "claim",
					rank: e
				}),
				className: "h-full w-full rounded-full active:translate-y-0.5",
				children: /* @__PURE__ */ v(K, {
					stars: u,
					color: c
				})
			})
		})]
	});
}
function ze({ pub: e, members: t }) {
	let n = l(), r = c((e) => e.locale), i = e.showdown;
	if (!i) return null;
	let o = {};
	for (let t of e.players) o[t.rid] = O([...i.hands[t.rid] ?? [], ...e.community]);
	let s = k(o), u = [...e.players].map((e) => e.rid).sort((e, t) => o[t] - o[e]);
	return /* @__PURE__ */ v("ul", {
		className: "gang-showdown-list",
		"data-players": u.length,
		children: u.map((c, l) => {
			let u = t.find((e) => e.rid === c), p = e.claims[c], h = s.get(c), g = p !== void 0 && p >= h[0] && p <= h[1], ee = m[(u?.colorIndex ?? 0) % m.length], b = i.hands[c] ?? [], x = new Set(ae([...b, ...e.community]));
			return /* @__PURE__ */ v("li", {
				className: "gang-showdown-player card-flip-in",
				"data-correct": g,
				style: { animationDelay: `${l * 120}ms` },
				children: /* @__PURE__ */ y("div", {
					className: "gang-showdown-player-layout",
					children: [
						/* @__PURE__ */ y("header", {
							className: "gang-showdown-player-head",
							children: [
								u && /* @__PURE__ */ v("img", {
									src: a[u.avatar % a.length],
									alt: "",
									draggable: !1,
									style: { backgroundColor: ee.hex }
								}),
								/* @__PURE__ */ v("strong", {
									title: u ? _(u, r) : c,
									children: u ? _(u, r) : c
								}),
								/* @__PURE__ */ v("span", {
									className: "gang-showdown-best-public",
									"aria-label": n("games.gang.showdownPublic"),
									children: e.community.map((e) => /* @__PURE__ */ y("span", {
										"data-used": x.has(e),
										"aria-label": n(x.has(e) ? "games.gang.showdownUsed" : "games.gang.showdownUnused", { card: `${ye(S(e))}${be(C(e))}` }),
										children: [ye(S(e)), be(C(e))]
									}, e))
								})
							]
						}),
						/* @__PURE__ */ v("div", {
							className: "gang-showdown-holes",
							"aria-label": n("games.gang.showdownHole"),
							children: b.map((e) => /* @__PURE__ */ v("span", {
								className: "gang-showdown-hole",
								"data-used": x.has(e),
								children: /* @__PURE__ */ v(W, {
									card: e,
									size: "table"
								})
							}, e))
						}),
						/* @__PURE__ */ v("span", {
							className: "gang-showdown-current",
							role: "img",
							"aria-label": p === void 0 ? n("games.gang.seatAwait") : n("games.gang.historyChipAria", {
								stage: n("games.gang.stageRiver"),
								n: z(p, e.players.length)
							}),
							children: p === void 0 ? /* @__PURE__ */ v("span", {
								className: "gang-showdown-no-chip",
								children: "–"
							}) : /* @__PURE__ */ v(K, {
								stars: z(p, e.players.length),
								color: B.river
							})
						}),
						/* @__PURE__ */ v("span", {
							className: "gang-showdown-history",
							children: (e.history[c] ?? []).map((t, n) => /* @__PURE__ */ v(Pe, {
								phase: I[n],
								stars: z(t, e.players.length)
							}, n))
						}),
						/* @__PURE__ */ y("div", {
							className: "gang-showdown-meta",
							children: [
								/* @__PURE__ */ v("strong", { children: n(Ee[E(o[c])]) }),
								/* @__PURE__ */ v("span", { children: h[0] === h[1] ? n("games.gang.showdownRank", { n: h[0] }) : n("games.gang.showdownRankTie", {
									from: h[0],
									to: h[1]
								}) }),
								/* @__PURE__ */ y("span", {
									className: "gang-showdown-verdict",
									children: [v(g ? d : f, { strokeWidth: 3.5 }), /* @__PURE__ */ v("span", { children: n(g ? "games.gang.markOk" : "games.gang.markBad") })]
								})
							]
						})
					]
				})
			}, c);
		})
	});
}
function Be({ card: e, size: t, elevated: n }) {
	let { ref: r, hidden: i } = s(`card:${e}`);
	return /* @__PURE__ */ v("span", {
		ref: r,
		className: "gang-anchored-card inline-flex",
		"data-size": t,
		style: { visibility: i ? "hidden" : void 0 },
		children: /* @__PURE__ */ v(W, {
			card: e,
			size: t,
			elevated: n
		})
	});
}
//#endregion
//#region src/games/gang/bot.ts
var Ve = 250, He = 8, Ue = {
	preflop: .45,
	flop: .6,
	turn: .75,
	river: .9
}, We = [
	"preflop",
	"flop",
	"turn"
];
function J(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
}
function Ge() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32;
}
function Ke(e, t) {
	let n = null;
	for (let r of t) (n === null || Math.abs(r - e) < Math.abs(n - e)) && (n = r);
	return n;
}
function qe(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let r of e.players) {
		if (r.rid === t) continue;
		let i = e.claims[r.rid];
		if (i !== void 0) {
			n.set(r.rid, {
				rank: i,
				conf: Ue[e.phase] ?? .5
			});
			continue;
		}
		let a = e.history[r.rid];
		a && a.length > 0 && n.set(r.rid, {
			rank: a[a.length - 1],
			conf: Ue[We[a.length - 1]] ?? .4
		});
	}
	return n;
}
function Je(e, t, n, r, i) {
	let a = /* @__PURE__ */ new Set([...e, ...t]), o = w.filter((e) => !a.has(e)), s = n - 1, c = 0;
	for (let n = 0; n < Ve; n += 1) {
		let n = [...o], a = n.length, l = () => {
			--a;
			let e = J(a + 1);
			return [n[a], n[e]] = [n[e], n[a]], n[a];
		}, u = [...t];
		for (; u.length < 5;) u.push(l());
		let d = O([...e, ...u]), f = 1;
		for (let e = 0; e < s; e += 1) {
			let t = () => O([
				l(),
				l(),
				...u
			]), n = t(), o = r?.[e] ?? null;
			if (o && Ge() < (i?.[e] ?? 0)) {
				let r = o === "beats" ? 1 : -1, i = 2 * (s - e - 1), c = 0;
				for (; Math.sign(n - d) !== r && c < He && a >= i + 2;) n = t(), c += 1;
			}
			n > d && (f += 1);
		}
		c += f;
	}
	let l = c / Ve;
	return Math.min(n, Math.max(1, Math.round(l)));
}
var Ye = (e, t) => {
	let n = e.public;
	if (n.phase === "showdown" || n.phase === "done") return null;
	let r = e.private?.myClaim ?? null, i = n.players.length;
	if (t.difficulty === "weak") return r === null ? { action: {
		type: "claim",
		rank: n.pool.length > 0 ? n.pool[J(n.pool.length)] : J(i) + 1
	} } : null;
	let a = e.private?.hand ?? [];
	if (a.length < 2) return null;
	let o = Je(a, n.community, i), s = n.players.filter((e) => e.rid !== t.rid), c = qe(n, t.rid), l = [], u = [], d = !1;
	for (let e of s) {
		let t = c.get(e.rid), n = t === void 0 || t.rank === o ? null : t.rank < o ? "beats" : "loses";
		l.push(n), u.push(t?.conf ?? 0), n !== null && (d = !0);
	}
	let f = d ? Je(a, n.community, i, l, u) : o, p = Ke(f, n.pool), m = t.memory ?? {};
	if (r === null) {
		if (p === null) return null;
		let e = m.phase === n.phase && m.lastHeld !== void 0 && Object.values(n.claims).includes(m.lastHeld);
		if (!e || m.retaliatedPhase !== n.phase) {
			let t = Object.values(n.claims).filter((t) => e || t !== m.lastHeld), r = t.length ? t.reduce((e, t) => Math.abs(e - f) <= Math.abs(t - f) ? e : t) : null;
			if (r !== null && Math.abs(r - f) + 1 < Math.abs(p - f)) {
				let t = {
					...m,
					lastHeld: r,
					phase: n.phase
				};
				return e && (t.retaliatedPhase = n.phase), {
					action: {
						type: "claim",
						rank: r
					},
					memory: t
				};
			}
		}
		return {
			action: {
				type: "claim",
				rank: p
			},
			memory: {
				...m,
				lastHeld: p,
				phase: n.phase
			}
		};
	}
	return p !== null && Math.abs(p - f) < Math.abs(r - f) ? {
		action: {
			type: "claim",
			rank: p
		},
		memory: {
			...m,
			lastHeld: p,
			phase: n.phase
		}
	} : null;
};
//#endregion
//#region src/games/gang/fx.tsx
function Y({ stars: e, phase: t, from: n }) {
	let r = typeof t == "string" && t in B ? B[t] : B.preflop, i = Math.min(n.w, n.h);
	return /* @__PURE__ */ v("span", {
		className: "gang-fx-chip",
		style: {
			width: i,
			height: i,
			"--gang-chip-size": `${i}px`
		},
		children: /* @__PURE__ */ v(K, {
			stars: e,
			color: r
		})
	});
}
function X({ from: e, to: t }) {
	let n = t && t.w > 0 ? e.w * t.h / t.w : e.h;
	return /* @__PURE__ */ v("span", {
		className: "gang-fx-card",
		style: {
			width: e.w,
			height: n,
			"--gang-card-width": `${e.w}px`
		},
		children: /* @__PURE__ */ v(G, { fill: !0 })
	});
}
function Z(e) {
	return e.anchor("deck") ?? e.anchor("comm:2");
}
function Xe(e, t) {
	return (t ? e.anchor(`seat:${t}`) : null) ?? Z(e);
}
function Q(e, t) {
	return (t ? e.anchor(`schip:${t}`) : null) ?? Xe(e, t);
}
function $(e, t) {
	return (typeof t == "number" ? e.anchor(`chip:${t}`) : null) ?? Z(e);
}
var Ze = {
	deal(e, t) {
		let n = e.secret;
		if (n && Array.isArray(n.cards)) {
			let e = Z(t);
			if (!e) return null;
			let r = [], i = [];
			for (let [a, o] of n.cards.entries()) {
				let n = t.anchor(`card:${o}`);
				n && (i.push(`card:${o}`), r.push(/* @__PURE__ */ v(x, {
					from: e,
					to: n,
					ms: 300,
					delay: a * 60,
					children: /* @__PURE__ */ v(X, {
						from: e,
						to: n
					})
				}, o)));
			}
			return r.length ? {
				ms: 300 + r.length * 60,
				node: r,
				hide: i
			} : null;
		}
		let r = Z(t), i = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || !i ? null : {
			ms: 420,
			node: [0, 1].map((e) => /* @__PURE__ */ v(x, {
				from: r,
				to: i,
				ms: 300,
				delay: e * 60,
				children: /* @__PURE__ */ v(X, { from: r })
			}, e))
		};
	},
	community(e, t) {
		let n = e.data, r = Array.isArray(n?.cards) ? n.cards : [], i = typeof n?.from == "number" ? n.from : 0, a = Z(t);
		if (!a || !r.length) return null;
		let o = [], s = [];
		for (let [e, n] of r.entries()) {
			let r = t.anchor(`comm:${i + e}`);
			r && (o.push(`card:${n}`), s.push(/* @__PURE__ */ v(x, {
				from: a,
				to: r,
				ms: 320,
				delay: e * 140,
				children: /* @__PURE__ */ v(X, {
					from: a,
					to: r
				})
			}, n)));
		}
		return s.length ? {
			ms: 320 + s.length * 140 + 200,
			node: s,
			hide: o
		} : null;
	},
	claim(e, t) {
		let n = e.data;
		if (typeof n?.rank != "number") return null;
		let r = typeof n.stars == "number" ? n.stars : n.rank, i = Q(t, e.rid), a = typeof n.from == "string" ? Q(t, n.from) : $(t, n.rank);
		if (!i || !a) return null;
		let o = [/* @__PURE__ */ v(x, {
			from: a,
			to: i,
			ms: 360,
			children: /* @__PURE__ */ v(Y, {
				stars: r,
				phase: n.phase,
				from: a
			})
		}, "take")], s = e.rid ? [`schip:${e.rid}`] : [];
		if (typeof n.prev == "number") {
			s.push(`chip:${n.prev}`);
			let e = $(t, n.prev);
			e && o.push(/* @__PURE__ */ v(x, {
				from: i,
				to: e,
				ms: 360,
				children: /* @__PURE__ */ v(Y, {
					from: i,
					stars: typeof n.prevStars == "number" ? n.prevStars : n.prev,
					phase: n.phase
				})
			}, "prev"));
		}
		return {
			ms: 360,
			node: o,
			hide: s
		};
	},
	release(e, t) {
		let n = e.data;
		if (typeof n?.rank != "number") return null;
		let r = Q(t, e.rid), i = $(t, n.rank);
		return !r || !i ? null : {
			ms: 360,
			node: /* @__PURE__ */ v(x, {
				from: r,
				to: i,
				ms: 360,
				children: /* @__PURE__ */ v(Y, {
					from: r,
					stars: typeof n.stars == "number" ? n.stars : n.rank,
					phase: n.phase
				})
			}),
			hide: [`chip:${n.rank}`]
		};
	},
	showdown(e, t) {
		let n = e.data, r = Z(t), i = le.showdown;
		return r ? {
			ms: i,
			node: /* @__PURE__ */ v(b, {
				at: r,
				ms: 1400,
				delay: 500,
				children: /* @__PURE__ */ v("span", {
					className: `font-display text-2xl font-extrabold ${n?.verdict === "win" ? "text-done" : "text-danger"}`,
					children: n?.verdict === "win" ? "✓" : "✗"
				})
			})
		} : {
			ms: i,
			node: null
		};
	}
}, Qe = [
	"games.gang.stagePreflop",
	"games.gang.stageFlop",
	"games.gang.stageTurn",
	"games.gang.stageRiver"
];
function $e({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: o }) {
	let s = l(), u = c((e) => e.locale), d = t, f = i ?? o;
	return /* @__PURE__ */ y(g, {
		adaptive: !0,
		scroll: !1,
		className: "gang-over-screen",
		banner: /* @__PURE__ */ y("header", {
			className: "gang-over-heading",
			children: [
				/* @__PURE__ */ v("span", {
					"aria-hidden": !0,
					children: "✦"
				}),
				/* @__PURE__ */ y("h1", { children: [s("session.result.title"), /* @__PURE__ */ v("small", { children: s("games.gang.name") })] }),
				/* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("strong", { children: s("games.gang.progressShort", {
					n: d.wins,
					total: 3
				}) }), /* @__PURE__ */ y("span", { children: [
					s("games.gang.lossesShort", { n: d.losses }),
					" · ",
					s("games.gang.round", { n: d.round })
				] })] })
			]
		}),
		actionsHeight: "gang-over-actions-slot",
		actions: f ? /* @__PURE__ */ y("div", {
			className: "gang-over-actions",
			children: [i && /* @__PURE__ */ v("button", {
				type: "button",
				className: "btn-base",
				style: {
					background: A.accent,
					color: "#fff"
				},
				onClick: i,
				children: s("session.result.playAgain")
			}), o && /* @__PURE__ */ v("button", {
				type: "button",
				className: "btn-quiet",
				onClick: o,
				children: s("session.result.backToLobby")
			})]
		}) : /* @__PURE__ */ v("p", {
			className: "gang-over-wait",
			children: s("session.result.waitHost")
		}),
		children: [e.winner.length > 0 && /* @__PURE__ */ v(te, {}), /* @__PURE__ */ y("div", {
			className: "gang-over-content",
			children: [/* @__PURE__ */ y("section", {
				className: "gang-over-public",
				"aria-label": s("games.gang.showdownPublic"),
				children: [/* @__PURE__ */ v("h2", { children: s("games.gang.showdownPublic") }), /* @__PURE__ */ v("div", { children: d.community.map((e) => /* @__PURE__ */ v(W, {
					card: e,
					size: "comm"
				}, e)) })]
			}), /* @__PURE__ */ v("ol", {
				className: "gang-over-players",
				"data-players": e.ranking.length,
				children: e.ranking.map((t) => {
					let i = n.find((e) => e.rid === t), o = e.winner.includes(t), c = d.claims[t], l = e.autopilot?.[t], f = e.scores?.[t], p = m[(i?.colorIndex ?? 0) % m.length];
					return /* @__PURE__ */ v("li", {
						className: "gang-over-player",
						"data-winner": o,
						"data-extra": f !== void 0 || l !== void 0 && l > 0,
						style: { "--gang-member-color": p.hex },
						children: /* @__PURE__ */ y("div", {
							className: "gang-over-player-layout",
							children: [
								/* @__PURE__ */ y("header", { children: [
									/* @__PURE__ */ v("span", {
										className: "gang-over-avatar",
										children: i && /* @__PURE__ */ v("img", {
											src: a[i.avatar % a.length],
											alt: "",
											draggable: !1
										})
									}),
									/* @__PURE__ */ v("strong", {
										title: i ? _(i, u) : t,
										children: i ? _(i, u) : t
									}),
									t === r && /* @__PURE__ */ v("small", { children: s("lobby.you") }),
									o && /* @__PURE__ */ v("span", {
										role: "img",
										"aria-label": s("games.gang.finalWinner"),
										children: "★"
									})
								] }),
								/* @__PURE__ */ y("div", {
									className: "gang-over-chips",
									children: [c !== void 0 && /* @__PURE__ */ v("span", {
										className: "gang-over-current",
										role: "img",
										"aria-label": s("games.gang.historyChipAria", {
											stage: s("games.gang.stageRiver"),
											n: z(c, d.players.length)
										}),
										children: /* @__PURE__ */ v(K, {
											stars: z(c, d.players.length),
											color: B.river
										})
									}), /* @__PURE__ */ v("span", {
										className: "gang-over-history",
										children: (d.history[t] ?? []).map((e, t) => /* @__PURE__ */ v("span", {
											role: "img",
											"aria-label": s("games.gang.historyChipAria", {
												stage: s(Qe[t]),
												n: z(e, d.players.length)
											}),
											children: /* @__PURE__ */ v(Se, {
												stars: z(e, d.players.length),
												color: B[I[t]]
											})
										}, t))
									})]
								}),
								(f !== void 0 || l !== void 0 && l > 0) && /* @__PURE__ */ y("p", {
									className: "gang-over-extra",
									children: [f !== void 0 && /* @__PURE__ */ v("strong", { children: f }), l !== void 0 && l > 0 && /* @__PURE__ */ v("span", { children: s("session.autopilot.share", { n: Math.round(l * 100) }) })]
								})
							]
						})
					}, t);
				})
			})]
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/gang/entry.tsx
var et = {
	definition: ve,
	View: De,
	bot: Ye,
	fx: Ze,
	OverView: $e,
	locales: {
		zh: {
			name: "纸牌帮",
			desc: "合作估牌力:各拿名次筹码,摊牌全对才算赢",
			rules: "游戏目标：全队合作判断每名玩家的牌力名次。累计赢得 3 局后，全队获胜。\n准备:\n· 每名玩家获得 2 张底牌，只有持有者可以查看。\n· 在中央放置与玩家人数相同的星数筹码。领取 1 星筹码表示认为自己的牌力最弱，星数越多，表示认为自己的牌力越强。\n流程:\n一局依次进行以下四个阶段：\n· 翻牌前阶段，不公开公共牌。\n· 翻牌阶段，公开 3 张公共牌。\n· 转牌阶段，再公开 1 张公共牌。\n· 河牌阶段，再公开最后 1 张公共牌。\n· 每个阶段中，任何玩家都可以随时从中央领取一枚筹码，也可以将自己持有的筹码放回中央，再选择另一枚筹码。\n· 也可以直接取走另一名玩家持有的筹码；该玩家必须重新选择一枚筹码。\n· 全员都持有筹码后,自动进入下一阶段。\n胜负:\n· 河牌亮出后摊牌,按扑克牌型比较真实牌力。\n· 每人持有的星数都与自己的真实名次一致,全队赢下本局;否则记一次失败,失败次数不限。",
			stagePreflop: "翻牌前",
			stageFlop: "翻牌",
			stageTurn: "转牌",
			stageRiver: "河牌",
			stageShowdown: "摊牌",
			brandSub: "合作扑克",
			deck: "牌堆",
			chipsTitle: "星数筹码",
			chipsHelp: "星越多，牌力越强",
			winsLabel: "合作胜局",
			progressShort: "胜 {{n}}/{{total}}",
			lossesShort: "败 {{n}}",
			seatAwait: "待拿",
			seatReturn: "放回",
			seatSteal: "抢取",
			seatLocked: "已定",
			handLabel: "你的底牌",
			handCategoryLabel: "当前牌型",
			handPending: "等待翻牌",
			handHint: "用底牌估计名次",
			progress: "已赢 {{n}}/{{total}} 局",
			round: "第 {{n}} 局",
			claimPrompt: "拿一枚星数筹码，估计你的牌力",
			waitingAll: "你已拿定,等全员拿齐…",
			verdictWin: "名次全对,配合成功!",
			verdictLose: "名次没对上,下一局再来",
			nextRound: "下一局",
			chipAria: "拿 {{n}} 星筹码",
			releaseAria: "放回 {{n}} 星筹码",
			stealAria: "抢走 {{n}} 星筹码",
			historyChipAria: "{{stage}}拿了 {{n}} 星",
			markOk: "名次正确",
			markBad: "名次不对",
			showdownPublic: "公共牌",
			showdownHole: "底牌",
			showdownBestHint: "描边底牌和高亮公共牌组成最佳五张。",
			showdownRank: "真实第{{n}}名",
			showdownRankTie: "并列{{from}}–{{to}}名",
			showdownUsed: "{{card}}：组成最佳五张",
			showdownUnused: "{{card}}：未组成最佳五张",
			finalWinner: "通关成员",
			hand0: "高牌",
			hand1: "一对",
			hand2: "两对",
			hand3: "三条",
			hand4: "顺子",
			hand5: "同花",
			hand6: "葫芦",
			hand7: "四条",
			hand8: "同花顺",
			errBadRank: "这枚筹码不在本局",
			errNotBetting: "现在不能换筹码",
			errNoChip: "你还没拿筹码",
			errNotShowdown: "还没摊牌"
		},
		en: {
			name: "The Gang",
			desc: "Co-op hand reading: claim rank chips, showdown must match",
			rules: "Goal: cooperate as one gang and correctly call every member’s hand rank in 3 rounds.\nSetup:\n· Each player holds 2 hole cards, visible only to themselves.\n· Star chips sit in the middle, one per player: 1★ claims the weakest hand; more stars claim a stronger one.\nPlay:\nA round proceeds through these four stages:\n· During pre-flop, no community cards are revealed.\n· During the flop, reveal 3 community cards.\n· During the turn, reveal 1 more community card.\n· During the river, reveal the final community card.\n· During each stage, any player may take a chip from the middle at any time. A player may also return their chip to the middle and choose another one.\n· You may even take a chip out of another player’s hand; they must then take a new one.\n· Once everyone holds a chip, the next stage begins automatically.\nResult:\n· After the river, hands are revealed and ranked by poker hand strength.\n· If every chip matches its holder’s true rank, the gang wins the round; otherwise it counts as a loss, with no limit on losses.",
			stagePreflop: "Pre-flop",
			stageFlop: "Flop",
			stageTurn: "Turn",
			stageRiver: "River",
			stageShowdown: "Showdown",
			brandSub: "CO-OP POKER",
			deck: "Deck",
			chipsTitle: "STAR CHIPS",
			chipsHelp: "More stars = stronger hand",
			winsLabel: "Gang wins",
			progressShort: "W {{n}}/{{total}}",
			lossesShort: "L {{n}}",
			seatAwait: "Wait",
			seatReturn: "Undo",
			seatSteal: "Take",
			seatLocked: "Set",
			handLabel: "Your cards",
			handCategoryLabel: "Current hand",
			handPending: "Waiting for flop",
			handHint: "Estimate your rank",
			progress: "{{n}}/{{total}} rounds won",
			round: "Round {{n}}",
			claimPrompt: "Take a chip that matches your hand",
			waitingAll: "Chip set — waiting for others…",
			verdictWin: "All ranks correct. Nice job!",
			verdictLose: "Ranks did not match. Next round!",
			nextRound: "Next round",
			chipAria: "Take the {{n}}-star chip",
			releaseAria: "Return the {{n}}-star chip",
			stealAria: "Snatch the {{n}}-star chip",
			historyChipAria: "{{stage}}: {{n}} stars",
			markOk: "Correct rank",
			markBad: "Wrong rank",
			showdownPublic: "Community cards",
			showdownHole: "Hole cards",
			showdownBestHint: "Outlined hole cards and highlighted community cards form the best five.",
			showdownRank: "Rank {{n}}",
			showdownRankTie: "Tied {{from}}–{{to}}",
			showdownUsed: "{{card}}: in the best five",
			showdownUnused: "{{card}}: outside the best five",
			finalWinner: "Gang winner",
			hand0: "High card",
			hand1: "One pair",
			hand2: "Two pair",
			hand3: "Three of a kind",
			hand4: "Straight",
			hand5: "Flush",
			hand6: "Full house",
			hand7: "Four of a kind",
			hand8: "Straight flush",
			errBadRank: "That chip is not in play",
			errNotBetting: "Cannot swap chips right now",
			errNoChip: "You are not holding a chip",
			errNotShowdown: "Not at showdown yet"
		}
	}
};
//#endregion
export { et as default };
