import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { BottomSheet as s } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as l } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as h, seatName as g } from "@bgparty/sdk/ui/player-strip";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { Floater as b, PulseBox as x } from "@bgparty/sdk/fx/primitives";
import { IconBack as S, IconBot as C, IconExpand as w, IconLog as ee } from "@bgparty/sdk/icons";
import { Confetti as te } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as ne, OptionSection as re } from "@bgparty/sdk/ui/game-options";
//#region src/games/ted/data.ts
var T = [
	{
		id: "ethairna",
		name: "伊赛娜",
		title: "精灵术士",
		hp: 6,
		focus: 8,
		speed: 4,
		defense: 3,
		str: 1,
		agi: 2,
		int: 3,
		abilities: [
			{ k: "seekingBolt" },
			{
				k: "weapon",
				name: "匕首",
				weapon: {
					type: "melee",
					skill: "str",
					mod: -1
				}
			},
			{ k: "research" }
		]
	},
	{
		id: "lannon",
		name: "兰农爵士",
		title: "人类圣骑士",
		hp: 8,
		focus: 5,
		speed: 3,
		defense: 5,
		str: 3,
		agi: 1,
		int: 2,
		abilities: [
			{ k: "divineMight" },
			{
				k: "weapon",
				name: "战锤",
				weapon: {
					type: "melee",
					skill: "str",
					mod: 0
				}
			},
			{ k: "healingHands" }
		]
	},
	{
		id: "gerrund",
		name: "蓝袍格伦德",
		title: "远古巫师",
		hp: 5,
		focus: 8,
		speed: 3,
		defense: 4,
		str: 1,
		agi: 2,
		int: 3,
		abilities: [
			{ k: "seekingBolt" },
			{
				k: "weapon",
				name: "匕首",
				weapon: {
					type: "melee",
					skill: "str",
					mod: -1
				}
			},
			{ k: "research" }
		]
	},
	{
		id: "thordin",
		name: "索丁·火辫",
		title: "矮人战士",
		hp: 8,
		focus: 4,
		speed: 3,
		defense: 2,
		str: 3,
		agi: 2,
		int: 1,
		abilities: [
			{ k: "stoneStance" },
			{
				k: "weapon",
				name: "战锤",
				weapon: {
					type: "melee",
					skill: "str",
					mod: 0
				}
			},
			{ k: "shieldBash" }
		]
	},
	{
		id: "grokull",
		name: "格罗库尔",
		title: "半兽人野蛮人",
		hp: 8,
		focus: 4,
		speed: 3,
		defense: 2,
		str: 3,
		agi: 2,
		int: 1,
		abilities: [
			{ k: "battleRage" },
			{
				k: "weapon",
				name: "战斧",
				weapon: {
					type: "melee",
					skill: "str",
					mod: 1
				}
			},
			{ k: "sprint" }
		]
	},
	{
		id: "uliessa",
		name: "乌莉艾萨",
		title: "矮人牧师",
		hp: 6,
		focus: 7,
		speed: 4,
		defense: 5,
		str: 2,
		agi: 1,
		int: 3,
		abilities: [
			{ k: "clericHeal" },
			{
				k: "weapon",
				name: "战锤",
				weapon: {
					type: "melee",
					skill: "str",
					mod: 0
				}
			},
			{ k: "research" }
		]
	},
	{
		id: "moonblade",
		name: "月刃",
		title: "木精灵游荡者",
		hp: 6,
		focus: 5,
		speed: 5,
		defense: 3,
		str: 2,
		agi: 3,
		int: 1,
		abilities: [
			{ k: "shadowWalk" },
			{
				k: "weapon",
				name: "匕首",
				weapon: {
					type: "melee",
					skill: "str",
					mod: -1
				}
			},
			{ k: "lockpick" }
		]
	},
	{
		id: "wyn",
		name: "薇恩·凯利斯",
		title: "精灵游侠",
		hp: 7,
		focus: 5,
		speed: 4,
		defense: 3,
		str: 2,
		agi: 3,
		int: 1,
		abilities: [
			{ k: "stealth" },
			{
				k: "weapon",
				name: "匕首",
				weapon: {
					type: "melee",
					skill: "str",
					mod: -1
				}
			},
			{
				k: "weapon",
				name: "猎弓",
				weapon: {
					type: "missile",
					skill: "agi",
					mod: -1,
					range: 2
				}
			}
		]
	}
], E = [
	{
		id: "boomy",
		name: "爆爆哥布林",
		speed: 1,
		defense: 4,
		reward: { or: [{ k: "loot" }, { k: "spell" }] },
		action: {
			k: "rangedOrMove",
			range: 2,
			dmg: "n1",
			elseMove: 1
		}
	},
	{
		id: "mighty",
		name: "大力哥布林",
		speed: 1,
		defense: 7,
		reward: { and: [{ k: "loot" }, {
			k: "hp",
			n: 3
		}] },
		action: {
			k: "moveThen",
			move: 1,
			range: 0,
			dmg: "n1"
		}
	},
	{
		id: "pokey",
		name: "戳戳哥布林",
		speed: 1,
		defense: 4,
		reward: { or: [{ k: "loot" }, { k: "reveal" }] },
		action: {
			k: "rangedOrMove",
			range: 1,
			dmg: "n1",
			elseMove: 1
		}
	},
	{
		id: "spelly",
		name: "咒咒哥布林",
		speed: 3,
		defense: 5,
		reward: { and: [{ k: "loot" }, {
			k: "focus",
			n: 5
		}] },
		action: {
			k: "rangedOrMove",
			range: 3,
			dmg: "n1",
			elseMove: 3
		}
	},
	{
		id: "shooty",
		name: "射手哥布林",
		speed: 2,
		defense: 5,
		reward: { or: [{ k: "loot" }, {
			k: "focus",
			n: 5
		}] },
		action: {
			k: "moveThen",
			move: 2,
			range: 2,
			dmg: 1
		}
	},
	{
		id: "stabby",
		name: "刺客哥布林",
		speed: 4,
		defense: 4,
		reward: { or: [{ k: "loot" }, {
			k: "hp",
			n: 3
		}] },
		action: {
			k: "rangedOrMove",
			range: 0,
			dmg: "n1",
			elseMove: 4
		}
	}
], D = [
	{
		id: "serpent",
		name: "凶暴巨蟒",
		hp: 6,
		speed: 3,
		defense: 5,
		counterMelee: {
			add: 3,
			defUp: 1
		},
		counterRanged: { add: 2 },
		action: {
			move: 3,
			range: 0,
			hp: 3
		}
	},
	{
		id: "crawler",
		name: "地城爬行者",
		hp: 7,
		speed: 2,
		defense: 5,
		counterMelee: { add: 3 },
		counterRanged: { add: 2 },
		action: {
			move: 2,
			range: 1,
			hp: 2,
			focus: 3
		}
	},
	{
		id: "ogre",
		name: "食人魔",
		hp: 6,
		speed: 4,
		defense: 5,
		counterMelee: {
			add: 2,
			defUp: 2
		},
		counterRanged: { add: 2 },
		action: {
			move: 4,
			range: 0,
			hp: 2
		}
	},
	{
		id: "troglodyte",
		name: "穴居怪",
		hp: 7,
		speed: 1,
		defense: 5,
		counterMelee: { add: 2 },
		counterRanged: { add: 2 },
		action: {
			move: 1,
			range: 1,
			hp: 2,
			focus: 2
		}
	},
	{
		id: "troll",
		name: "巨魔",
		hp: 7,
		speed: 4,
		defense: 4,
		counterMelee: { add: 3 },
		counterRanged: { add: 2 },
		action: {
			move: 4,
			range: 0,
			hp: 1,
			extra: "goblinEntrance"
		}
	},
	{
		id: "minotaur",
		name: "牛头怪",
		hp: 6,
		speed: 5,
		defense: 4,
		counterMelee: {
			add: 3,
			defUp: 2
		},
		counterRanged: { add: 1 },
		action: {
			move: 5,
			range: 0,
			hp: 3
		}
	},
	{
		id: "skeleton",
		name: "骷髅武士",
		hp: 8,
		speed: 3,
		defense: 4,
		counterMelee: { add: 2 },
		counterRanged: { add: 3 },
		action: {
			move: 3,
			range: 1,
			hp: 2,
			focus: 3
		}
	},
	{
		id: "ooze",
		name: "软泥怪",
		hp: 8,
		speed: 2,
		defense: 4,
		counterMelee: { add: 3 },
		counterRanged: {
			add: 1,
			defUp: 2
		},
		action: {
			move: 2,
			range: 1,
			hp: 1,
			extra: "discardLoot"
		}
	}
], O = [
	{
		id: "dragon",
		name: "巨龙",
		altars: [3],
		speed: 3,
		defense: 5,
		counter: {
			melee: 3,
			missile: 2,
			spell: { focusBeforeCast: 2 }
		},
		action: {
			k: "moveHit",
			move: 3,
			range: 4,
			hp: 2
		},
		torch: {
			k: "aoe",
			range: 1,
			hp: 2
		},
		spaces: [
			{ fx: {
				k: "checkAdd",
				skill: "any",
				n: 3
			} },
			{ fx: {
				k: "checkAdd",
				skill: "agi",
				n: 2
			} },
			{ fx: {
				k: "checkAdd",
				skill: "str",
				n: 2
			} },
			{ fx: {
				k: "hp",
				n: -1
			} },
			{
				fx: {
					k: "hp",
					n: -2
				},
				entrance: !0
			},
			{ fx: {
				k: "focus",
				n: 2
			} }
		]
	},
	{
		id: "goblinking",
		name: "哥布林之王",
		altars: [2],
		speed: 1,
		defense: 6,
		counter: {
			melee: 4,
			missile: 2,
			spell: 1
		},
		action: { k: "goblinKing" },
		torch: { k: "goblinAura" },
		spaces: [
			{ fx: {
				k: "checkAdd",
				skill: "any",
				n: 2
			} },
			{ fx: {
				k: "checkAdd",
				skill: "any",
				n: 1
			} },
			{ fx: {
				k: "focus",
				n: 2
			} },
			{ fx: { k: "goblinEntrance" } },
			{
				fx: { k: "goblinEntrance" },
				entrance: !0
			},
			{ fx: {
				k: "focus",
				n: 1
			} }
		]
	},
	{
		id: "gorgon",
		name: "蛇发女妖",
		altars: [4],
		speed: 2,
		defense: 6,
		counter: {
			melee: 4,
			missile: 3,
			spell: 2
		},
		action: {
			k: "moveHit",
			move: 2,
			range: 3,
			hp: 2
		},
		torch: {
			k: "aoe",
			range: 3,
			hp: 2,
			healSelf: 1
		},
		spaces: [
			{ fx: {
				k: "checkAdd",
				skill: "agi",
				n: 3
			} },
			{ fx: {
				k: "checkAdd",
				skill: "int",
				n: 2
			} },
			{ fx: {
				k: "checkAdd",
				skill: "str",
				n: 2
			} },
			{ fx: {
				k: "focus",
				n: 2
			} },
			{ fx: { k: "lessDie" } },
			{
				fx: { k: "lessDie" },
				entrance: !0
			}
		]
	},
	{
		id: "hydra",
		name: "九头蛇",
		altars: [
			2,
			4,
			6
		],
		speed: 2,
		defense: 6,
		counter: {
			melee: 4,
			missile: 2,
			spell: 1
		},
		action: {
			k: "moveHit",
			move: 2,
			range: 1,
			hp: 2
		},
		torch: {
			k: "heal",
			n: 2
		},
		spaces: [
			{ fx: { k: "fullRestore" } },
			{ fx: {
				k: "hp",
				n: -1
			} },
			{ fx: {
				k: "hp",
				n: -1
			} },
			{ fx: { k: "moveAgain" } },
			{ fx: {
				k: "hp",
				n: -1
			} },
			{
				fx: {
					k: "checkAdd",
					skill: "any",
					n: -2
				},
				entrance: !0
			}
		]
	},
	{
		id: "pharaoh",
		name: "法老",
		altars: [3],
		speed: 3,
		defense: 5,
		counter: {
			melee: 3,
			missile: 2,
			spell: { focusBeforeCast: 2 }
		},
		action: {
			k: "moveHit",
			move: 2,
			range: 2,
			hp: 2
		},
		torch: { k: "pharaohChoice" },
		spaces: [
			{
				fx: {
					k: "focus",
					n: -2
				},
				entrance: !0
			},
			{ fx: {
				k: "focus",
				n: -1
			} },
			{ fx: {
				k: "checkAdd",
				skill: "int",
				n: 2
			} },
			{ fx: {
				k: "checkAdd",
				skill: "agi",
				n: 2
			} },
			{ fx: {
				k: "checkAdd",
				skill: "str",
				n: 2
			} },
			{ fx: {
				k: "focus",
				n: 2
			} }
		]
	},
	{
		id: "seer",
		name: "先知",
		altars: [1, 4],
		speed: 3,
		defense: 6,
		counter: {
			melee: 3,
			missile: 4,
			spell: { focusBeforeCast: 3 }
		},
		action: {
			k: "moveHit",
			move: 3,
			range: 1,
			hp: 2,
			focus: 1
		},
		torch: { k: "seerShift" },
		spaces: [
			{
				fx: {
					k: "focus",
					n: -3
				},
				entrance: !0
			},
			{ fx: {
				k: "focus",
				n: -2
			} },
			{ fx: {
				k: "focus",
				n: 1
			} },
			{ fx: {
				k: "checkAdd",
				skill: "any",
				n: 1
			} },
			{ fx: {
				k: "focus",
				n: 1
			} },
			{ fx: {
				k: "checkAdd",
				skill: "any",
				n: 2
			} }
		]
	}
], ie = {
	bear: {
		on: "melee",
		kind: "add"
	},
	lion: {
		on: "melee",
		kind: "heal"
	},
	panther: {
		on: "missile",
		kind: "add"
	},
	phoenix: {
		on: "cast",
		kind: "focus"
	}
}, ae = [
	{
		id: "amethyst",
		name: "紫水晶雕像",
		slot: "trinket",
		effects: [{
			k: "checkDie",
			skill: "int"
		}]
	},
	{
		id: "crossbow",
		name: "弩",
		slot: "hand",
		effects: [{
			k: "weapon",
			name: "弩",
			weapon: {
				type: "missile",
				skill: "agi",
				mod: 1,
				range: 3
			}
		}, { k: "onMissileFocus" }]
	},
	{
		id: "cursedscale",
		name: "诅咒龙鳞",
		slot: "garb",
		effects: [{
			k: "stat",
			def: -1
		}, {
			k: "checkAdd",
			skill: "any",
			n: 1
		}]
	},
	{
		id: "elvenchain",
		name: "精灵锁子甲",
		slot: "garb",
		effects: [{
			k: "stat",
			def: 1,
			spd: 1
		}]
	},
	{
		id: "hookshot",
		name: "钩爪",
		slot: "hand",
		effects: [{
			k: "weapon",
			name: "钩爪",
			weapon: {
				type: "melee",
				skill: "str",
				mod: 1
			}
		}, {
			k: "weapon",
			name: "钩爪(弹射)",
			weapon: {
				type: "missile",
				skill: "agi",
				mod: 1,
				range: 1
			}
		}]
	},
	{
		id: "jade",
		name: "翡翠雕像",
		slot: "trinket",
		effects: [{
			k: "checkDie",
			skill: "agi"
		}]
	},
	{
		id: "ruby",
		name: "红宝石雕像",
		slot: "trinket",
		effects: [{
			k: "checkDie",
			skill: "str"
		}]
	},
	{
		id: "buckler",
		name: "尖刺小盾",
		slot: "hand",
		effects: [{ k: "onMeleeDef" }, {
			k: "checkAdd",
			skill: "str",
			n: 1
		}]
	},
	{
		id: "sunhammer",
		name: "烈阳战锤",
		slot: "hand",
		effects: [{
			k: "weapon",
			name: "烈阳战锤",
			weapon: {
				type: "melee",
				skill: "str",
				mod: 1
			}
		}, { k: "onMeleeFocus" }]
	},
	{
		id: "violetcape",
		name: "紫罗兰披风",
		slot: "garb",
		effects: [{ k: "onMissileOrCastDef" }, {
			k: "checkDie",
			skill: "int"
		}]
	},
	{
		id: "bear-axe",
		name: "熊之巨斧",
		slot: "hand",
		set: "bear",
		effects: [{
			k: "weapon",
			name: "巨斧",
			weapon: {
				type: "melee",
				skill: "str",
				mod: 2
			}
		}, {
			k: "stat",
			spd: -1
		}]
	},
	{
		id: "bear-axes",
		name: "熊之飞斧",
		slot: "hand",
		set: "bear",
		effects: [{
			k: "weapon",
			name: "飞斧",
			weapon: {
				type: "missile",
				skill: "str",
				mod: 2,
				range: 1
			}
		}]
	},
	{
		id: "bear-jerkin",
		name: "熊之铆钉皮甲",
		slot: "garb",
		set: "bear",
		effects: [{ k: "onMeleeDef" }]
	},
	{
		id: "bear-horn",
		name: "熊之战号",
		slot: "trinket",
		set: "bear",
		effects: [{ k: "warHorn" }]
	},
	{
		id: "lion-sword",
		name: "狮之长剑",
		slot: "hand",
		set: "lion",
		effects: [{
			k: "weapon",
			name: "长剑",
			weapon: {
				type: "melee",
				skill: "str",
				mod: 1
			}
		}, { k: "lionSwordPump" }]
	},
	{
		id: "lion-shield",
		name: "狮之盾",
		slot: "hand",
		set: "lion",
		effects: [{ k: "onMeleeDef" }, { k: "meleeReroll" }]
	},
	{
		id: "lion-plate",
		name: "狮之板甲",
		slot: "garb",
		set: "lion",
		effects: [{
			k: "stat",
			def: 1
		}]
	},
	{
		id: "lion-greaves",
		name: "狮之护胫",
		slot: "trinket",
		set: "lion",
		effects: [{
			k: "stat",
			spd: -1
		}]
	},
	{
		id: "panther-claw",
		name: "豹之利爪",
		slot: "hand",
		set: "panther",
		effects: [{
			k: "weapon",
			name: "利爪",
			weapon: {
				type: "melee",
				skill: "agi",
				mod: 1
			}
		}]
	},
	{
		id: "panther-glove",
		name: "豹之手套",
		slot: "trinket",
		set: "panther",
		effects: [{
			k: "checkAdd",
			skill: "str",
			n: 1
		}]
	},
	{
		id: "panther-cloak",
		name: "豹之披风",
		slot: "garb",
		set: "panther",
		effects: [{ k: "stealth" }]
	},
	{
		id: "panther-bow",
		name: "豹之长弓",
		slot: "hand",
		set: "panther",
		effects: [{
			k: "weapon",
			name: "长弓",
			weapon: {
				type: "missile",
				skill: "agi",
				mod: 0,
				range: 4
			}
		}, { k: "pantherVolley" }]
	},
	{
		id: "phoenix-staff",
		name: "凤凰巨杖",
		slot: "hand",
		set: "phoenix",
		effects: [{
			k: "weapon",
			name: "巨杖",
			weapon: {
				type: "missile",
				skill: "int",
				mod: 0,
				range: 3
			}
		}]
	},
	{
		id: "phoenix-robes",
		name: "凤凰长袍",
		slot: "garb",
		set: "phoenix",
		effects: [{ k: "freeTeleport" }]
	},
	{
		id: "phoenix-ring",
		name: "凤凰之戒",
		slot: "trinket",
		set: "phoenix",
		effects: [{ k: "spellDamageUp" }]
	},
	{
		id: "phoenix-tome",
		name: "凤凰法术书",
		slot: "hand",
		set: "phoenix",
		effects: [{
			k: "checkAdd",
			skill: "int",
			n: 1
		}]
	}
], k = [
	{
		id: "chainlightning",
		name: "连锁闪电",
		check: {
			skill: "int",
			n: 6
		},
		cost: 3,
		effect: {
			k: "damage",
			dmg: 1,
			targets: 2,
			range: 2
		}
	},
	{
		id: "eagles",
		name: "雄鹰迅捷",
		check: {
			skill: "int",
			n: 3
		},
		cost: 3,
		effect: { k: "eaglesSwiftness" }
	},
	{
		id: "clawofdarkness",
		name: "黑暗之爪",
		check: {
			skill: "int",
			n: 6
		},
		cost: 4,
		effect: {
			k: "damage",
			dmg: 3,
			targets: 1,
			range: 2
		},
		fail: "torchDown"
	},
	{
		id: "conjurers",
		name: "咒术师的豪赌",
		check: {
			skill: "int",
			n: 7
		},
		cost: 5,
		effect: {
			k: "damage",
			dmg: 4,
			targets: 1,
			range: 3
		},
		fail: "goblinSelf"
	},
	{
		id: "cloudofdeath",
		name: "死亡之云",
		check: {
			skill: "int",
			n: 6
		},
		cost: 4,
		effect: {
			k: "aoeDamage",
			dmg: 2,
			range: 1
		}
	},
	{
		id: "darkbargain",
		name: "黑暗交易",
		check: {
			skill: "int",
			n: 7
		},
		cost: 2,
		effect: {
			k: "healAllMax",
			range: 2,
			goblinSelf: !0
		}
	},
	{
		id: "delversluck",
		name: "探险者之运",
		check: {
			skill: "any",
			n: 7
		},
		cost: 4,
		effect: {
			k: "extraAction",
			checkAdd: 3
		}
	},
	{
		id: "dungeonscry",
		name: "地城探知",
		check: {
			skill: "any",
			n: 5
		},
		cost: 2,
		effect: { k: "dungeonScry" }
	},
	{
		id: "elementalcharge",
		name: "元素充能",
		check: {
			skill: "int",
			n: 5
		},
		cost: 2,
		effect: { k: "restAura" }
	},
	{
		id: "fireball",
		name: "火球术",
		check: {
			skill: "int",
			n: 7
		},
		cost: 6,
		effect: {
			k: "damage",
			dmg: 4,
			targets: 1,
			range: 2
		}
	},
	{
		id: "giantsstrength",
		name: "巨人之力",
		check: {
			skill: "any",
			n: 5
		},
		cost: 2,
		effect: { k: "giantsStrength" }
	},
	{
		id: "holyabundance",
		name: "神圣丰饶",
		check: {
			skill: "int",
			n: 5
		},
		cost: 4,
		effect: { k: "holyAbundance" }
	},
	{
		id: "invisibility",
		name: "隐身术",
		check: {
			skill: "any",
			n: 5
		},
		cost: 2,
		effect: { k: "invisibility" }
	},
	{
		id: "tempest",
		name: "箭雨风暴",
		check: {
			skill: "int",
			n: 6
		},
		cost: 5,
		effect: { k: "tempestArrows" }
	}
], A = [
	{
		id: "lairdoor",
		name: "巢穴之门",
		cell: 0,
		doors: ["D"],
		effect: { k: "lairDoor" }
	},
	{
		id: "web",
		name: "谢尔比的蛛网",
		cell: 1,
		doors: ["L", "R"],
		effect: {
			k: "trap",
			check: {
				skill: "any",
				n: 7
			},
			failDmg: 2,
			disarm: {
				skill: "str",
				n: 6
			}
		}
	},
	{
		id: "bridge",
		name: "厄运之桥",
		cell: 2,
		doors: ["L", "R"],
		effect: {
			k: "trap",
			check: {
				skill: "any",
				n: 7
			},
			failDmg: 2,
			disarm: {
				skill: "agi",
				n: 6
			}
		}
	},
	{
		id: "firevortex",
		name: "火焰漩涡",
		cell: 3,
		doors: [
			"U",
			"R",
			"D"
		],
		effect: {
			k: "trap",
			check: {
				skill: "any",
				n: 6
			},
			failDmg: 3,
			disarm: {
				skill: "int",
				n: 5
			}
		}
	},
	{
		id: "spikedlog",
		name: "穿刺尖木",
		cell: 4,
		doors: [
			"U",
			"R",
			"D"
		],
		effect: {
			k: "trap",
			check: {
				skill: "any",
				n: 7
			},
			failDmg: 2,
			disarm: {
				skill: "agi",
				n: 6
			}
		}
	},
	{
		id: "spikepit",
		name: "尖刺陷坑",
		cell: 5,
		doors: [
			"U",
			"R",
			"D",
			"L"
		],
		effect: {
			k: "trap",
			check: {
				skill: "any",
				n: 6
			},
			failDmg: 3,
			disarm: {
				skill: "agi",
				n: 5
			}
		}
	},
	{
		id: "brambles",
		name: "缠绕荆棘",
		cell: 6,
		doors: [
			"U",
			"R",
			"D"
		],
		effect: {
			k: "trap",
			check: {
				skill: "any",
				n: 7
			},
			failDmg: 2,
			disarm: {
				skill: "int",
				n: 6
			}
		}
	},
	{
		id: "buzzsaw",
		name: "旋转圆锯",
		cell: 7,
		doors: ["R", "D"],
		effect: {
			k: "trap",
			check: {
				skill: "any",
				n: 6
			},
			failDmg: 3,
			disarm: {
				skill: "str",
				n: 5
			}
		}
	},
	{
		id: "lockedchest",
		name: "上锁的宝箱",
		cell: 8,
		doors: [
			"U",
			"R",
			"D",
			"L"
		],
		encounter: "goblin",
		effect: {
			k: "search",
			check: {
				skill: "str",
				n: 5
			}
		}
	},
	{
		id: "jeweledchest",
		name: "珠宝宝箱",
		cell: 9,
		doors: [
			"U",
			"R",
			"D"
		],
		encounter: "goblin",
		effect: {
			k: "search",
			check: {
				skill: "agi",
				n: 5
			}
		}
	},
	{
		id: "pharaohstomb",
		name: "法老之墓",
		cell: 10,
		doors: ["R", "D"],
		effect: {
			k: "search",
			check: {
				skill: "agi",
				n: 5
			}
		}
	},
	{
		id: "vault",
		name: "金库",
		cell: 11,
		doors: ["L", "R"],
		encounter: "goblin",
		effect: {
			k: "search",
			check: {
				skill: "int",
				n: 5
			}
		}
	},
	{
		id: "goblinbunks",
		name: "哥布林营房",
		cell: 12,
		doors: ["L", "R"],
		effect: { k: "goblinBunks" }
	},
	{
		id: "armory",
		name: "军械库",
		cell: 13,
		doors: ["R"],
		effect: { k: "armory" }
	},
	{
		id: "cauldron",
		name: "女巫大锅",
		cell: 14,
		doors: [
			"L",
			"U",
			"R"
		],
		effect: { k: "cauldron" }
	},
	{
		id: "arcanealtar",
		name: "奥术祭坛",
		cell: 15,
		doors: [
			"U",
			"R",
			"D",
			"L"
		],
		encounter: "goblin",
		effect: { k: "arcaneAltar" }
	},
	{
		id: "library",
		name: "图书馆",
		cell: 16,
		doors: ["R", "D"],
		encounter: "goblin",
		effect: { k: "library" }
	},
	{
		id: "graveyard",
		name: "墓地",
		cell: 17,
		doors: ["R", "D"],
		encounter: "goblin",
		effect: { k: "graveyard" }
	},
	{
		id: "pulley",
		name: "滑轮装置",
		cell: 18,
		doors: [
			"U",
			"R",
			"D",
			"L"
		],
		encounter: "goblin",
		effect: { k: "pulley" }
	},
	{
		id: "well",
		name: "水井",
		cell: 19,
		doors: [
			"U",
			"R",
			"D"
		],
		effect: { k: "well" }
	},
	{
		id: "feasthall",
		name: "宴会厅",
		cell: 20,
		doors: [
			"R",
			"D",
			"L"
		],
		effect: { k: "feasthall" }
	},
	{
		id: "stairsnowhere",
		name: "死路阶梯",
		cell: 21,
		doors: ["D"],
		encounter: "goblin",
		effect: { k: "teleport" }
	},
	{
		id: "portal",
		name: "传送门",
		cell: 22,
		doors: ["L"],
		encounter: "goblin",
		effect: { k: "teleport" }
	},
	{
		id: "minion1",
		name: "随从巢穴 I",
		cell: 23,
		doors: [
			"U",
			"R",
			"D",
			"L"
		],
		encounter: "minion",
		effect: { k: "none" }
	},
	{
		id: "minion2",
		name: "随从巢穴 II",
		cell: 24,
		doors: ["L", "R"],
		encounter: "minion",
		effect: { k: "none" }
	},
	{
		id: "minion3",
		name: "随从巢穴 III",
		cell: 25,
		doors: ["R", "D"],
		encounter: "minion",
		effect: { k: "none" }
	},
	{
		id: "minion4",
		name: "随从巢穴 IV",
		cell: 26,
		doors: [
			"U",
			"R",
			"D"
		],
		encounter: "minion",
		effect: { k: "none" }
	},
	{
		id: "entrance",
		name: "入口",
		cell: 27,
		doors: [
			"U",
			"R",
			"D",
			"L"
		],
		effect: { k: "entrance" }
	}
], oe = A.filter((e) => !e.encounter && e.effect.k !== "entrance" && e.effect.k !== "lairDoor").map((e) => e.id), se = A.filter((e) => e.encounter === "minion").map((e) => e.id), ce = {
	2: 9,
	3: 7,
	4: 5
}, le = [
	"plain",
	"plain",
	"plain",
	"plain",
	"goblin",
	"enemy",
	"plain",
	"goblin",
	"enemy",
	"goblin",
	"enemy",
	"plain",
	"goblin",
	"enemy",
	"plain",
	"plain",
	"goblin",
	"enemy",
	"plain",
	"goblin",
	"enemy",
	"skull"
], ue = [
	"plain",
	"plain",
	"enemy",
	"goblin",
	"enemy",
	"plain",
	"enemy",
	"goblin",
	"plain",
	"enemy",
	"goblin",
	"enemy",
	"plain",
	"enemy",
	"goblin",
	"enemy",
	"plain",
	"enemy",
	"enemy",
	"enemy",
	"skull"
], de = {
	2: 7,
	3: 4,
	4: 0
}, fe = [
	{
		add: 1,
		focus: 0,
		hp: 0
	},
	{
		add: 2,
		focus: 3,
		hp: 0
	},
	{
		add: 0,
		focus: 2,
		hp: 0
	},
	{
		add: 0,
		focus: 1,
		hp: 0
	},
	{
		add: 0,
		focus: 1,
		hp: 0
	},
	{
		add: 0,
		focus: 0,
		hp: 1
	}
], pe = [
	{
		k: "num",
		n: 2
	},
	{
		k: "num",
		n: 3
	},
	{
		k: "num",
		n: 4
	},
	{
		k: "num",
		n: 5
	},
	{ k: "shield" },
	{ k: "torch" }
], me = {
	hand: 2,
	garb: 1,
	trinket: 2,
	spell: 2
}, he = {
	id: "ted",
	tier: "alpha",
	mechanics: ["dice-rolling", "grid-movement"],
	interactionTags: ["cooperative"],
	nameKey: "games.ted.name",
	descKey: "games.ted.desc",
	rulesKey: "games.ted.rules",
	icon: "🏰",
	iconImg: "games/ted.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/ted/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [1, 2],
	accent: "#a16207",
	releasedAt: "2026-09-15",
	search: {
		py: "xiao xiao shi shi di cheng",
		init: "xxssdc"
	},
	hotseat: "cover"
}, ge = t.string(), j = t.string(), _e = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pickHero"),
		heroId: t.string()
	}),
	t.object({
		type: t.literal("move"),
		path: t.array(ge).min(1).max(8),
		rot: t.union([
			t.literal(0),
			t.literal(1),
			t.literal(2),
			t.literal(3)
		]).optional()
	}),
	t.object({
		type: t.literal("attack"),
		targetUid: j,
		weaponIdx: t.int().min(0).max(7)
	}),
	t.object({ type: t.literal("search") }),
	t.object({ type: t.literal("disarm") }),
	t.object({ type: t.literal("rest") }),
	t.object({
		type: t.literal("cast"),
		spellId: t.string(),
		targetUids: t.array(j).max(4).optional(),
		coord: ge.optional()
	}),
	t.object({
		type: t.literal("resolveRoll"),
		dieIdx: t.int().min(0).max(2),
		nudges: t.array(t.object({
			die: t.int().min(0).max(2),
			dir: t.union([t.literal(1), t.literal(-1)])
		})).max(6),
		boosts: t.array(t.string()).max(6).optional()
	}),
	t.object({
		type: t.literal("ability"),
		idx: t.int().min(0).max(2),
		targetUid: j.optional()
	}),
	t.object({
		type: t.literal("roomAction"),
		coord: ge.optional()
	}),
	t.object({ type: t.literal("explore") }),
	t.object({
		type: t.literal("equip"),
		lootId: t.string(),
		toUid: j.optional()
	}),
	t.object({
		type: t.literal("useLoot"),
		lootId: t.string(),
		coord: ge.optional(),
		targetUid: j.optional()
	}),
	t.object({ type: t.literal("enterLair") }),
	t.object({ type: t.literal("taunt") }),
	t.object({
		type: t.literal("choose"),
		option: t.string()
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ve = t.object({ boss: t.string().catch("random") }).default({ boss: "random" }), ye = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("pick"),
		uid: j
	}),
	t.object({
		k: t.literal("reveal"),
		roomId: t.string()
	}),
	t.object({
		k: t.literal("spawn"),
		enemy: t.enum(["goblin", "minion"]),
		defId: t.string()
	}),
	t.object({
		k: t.literal("roll"),
		uid: j,
		label: t.string(),
		total: t.number(),
		need: t.number(),
		success: t.boolean()
	}),
	t.object({
		k: t.literal("hitEnemy"),
		uid: j,
		defId: t.string(),
		dmg: t.number(),
		killed: t.boolean()
	}),
	t.object({
		k: t.literal("counter"),
		uid: j,
		defId: t.string(),
		dmg: t.number()
	}),
	t.object({
		k: t.literal("enemyHit"),
		uid: j,
		defId: t.string(),
		dmg: t.number()
	}),
	t.object({
		k: t.literal("knocked"),
		uid: j
	}),
	t.object({
		k: t.literal("rest"),
		uid: j
	}),
	t.object({
		k: t.literal("gain"),
		uid: j,
		item: t.string()
	}),
	t.object({
		k: t.literal("enterLair"),
		uid: j
	}),
	t.object({ k: t.literal("act2") }),
	t.object({
		k: t.literal("bossHit"),
		dmg: t.number()
	}),
	t.object({ k: t.literal("won") }),
	t.object({
		k: t.literal("lost"),
		reason: t.string()
	})
]), be = t.union([
	t.literal(0),
	t.literal(1),
	t.literal(2),
	t.literal(3)
]), xe = t.object({
	uid: j,
	defId: t.string(),
	rid: t.string(),
	hp: t.number(),
	maxHp: t.number(),
	focus: t.number(),
	maxFocus: t.number(),
	pos: ge,
	knocked: t.boolean(),
	loot: t.array(t.string()),
	spellCount: t.number(),
	trapped: t.boolean(),
	speedLeft: t.number(),
	actionsLeft: t.number(),
	onlyMove: t.boolean(),
	roomActionUsed: t.boolean(),
	explored: t.boolean(),
	abilityUsed: t.array(t.number())
}), Se = t.object({
	uid: j,
	defId: t.string(),
	pos: ge
}), Ce = Se.extend({
	hp: t.number(),
	maxHp: t.number()
}), we = t.object({
	forUid: j,
	dice: t.array(t.int().min(1).max(6)),
	enemyDie: t.int().min(1).max(6).nullable(),
	need: t.number(),
	label: t.string()
}), Te = t.object({
	phase: t.enum([
		"pick",
		"play",
		"roll",
		"enemyAct",
		"won",
		"lost"
	]),
	act: t.union([t.literal(1), t.literal(2)]),
	heroCount: t.number(),
	torch: t.number(),
	grid: t.record(t.string(), t.object({
		roomId: t.string().nullable(),
		rot: be,
		faceUp: t.boolean(),
		altar: t.boolean(),
		trap: t.boolean(),
		used: t.boolean()
	})),
	heroes: t.array(xe),
	turn: j.nullable(),
	turnSeq: t.number(),
	goblins: t.array(Se),
	goblinSlots: t.number(),
	minions: t.array(Ce),
	boss: t.object({
		defId: t.string(),
		markers: t.array(t.number()),
		altarsCovered: t.array(t.number()),
		pos: ge.nullable()
	}).nullable(),
	pendingRoll: we.nullable(),
	choice: t.object({
		kind: t.string(),
		forUid: j,
		options: t.array(t.string())
	}).nullable(),
	deckCount: t.number(),
	lostReason: t.string().nullable(),
	lairOpen: t.boolean(),
	picked: t.array(t.string()),
	pickRid: t.string().nullable(),
	log: t.array(ye)
}), Ee = t.object({
	spells: t.array(t.string()),
	myTurnUid: j.nullable()
}), De = {
	enemyAct: 1e3,
	bossIntro: 2600
}, Oe = [
	"U",
	"R",
	"D",
	"L"
], ke = {
	U: [0, -1],
	R: [1, 0],
	D: [0, 1],
	L: [-1, 0]
}, Ae = {
	U: "D",
	R: "L",
	D: "U",
	L: "R"
}, je = (e, t) => `${e},${t}`, Me = (e) => [Number(e.split(",")[0]), Number(e.split(",")[1])], M = (e) => e.startsWith("L"), Ne = 80;
function N(e, t) {
	e.log.push(t), e.log.length > Ne && e.log.splice(0, e.log.length - Ne);
}
var P = (e) => T.find((t) => t.id === e), F = (e) => A.find((t) => t.id === e), Pe = (e) => E.find((t) => t.id === e), Fe = (e) => D.find((t) => t.id === e), Ie = (e) => O.find((t) => t.id === e), Le = (e) => e.act === 1 ? le : ue;
function Re(t, n) {
	let r = [...t];
	for (let t = r.length - 1; t > 0; --t) {
		let i = e(n.seed, n.rngCursor, t + 1);
		n.rngCursor += 1, [r[t], r[i]] = [r[i], r[t]];
	}
	return r;
}
function ze(e, t) {
	return e.uidSeq += 1, `${t}${e.uidSeq}`;
}
function Be(e) {
	return e.roomId ? F(e.roomId).doors.map((t) => Oe[(Oe.indexOf(t) + e.rot) % 4]) : [];
}
function Ve(e, t) {
	let [n, r] = Me(e), [i, a] = ke[t];
	return je(n + i, r + a);
}
function He(e, t, n) {
	let r = e.grid[t], i = e.grid[n];
	if (!r || !i || !r.faceUp) return !1;
	let [a, o] = Me(t), [s, c] = Me(n), l = s - a, u = c - o;
	if (Math.abs(l) + Math.abs(u) !== 1) return !1;
	let d = l === 1 ? "R" : l === -1 ? "L" : u === 1 ? "D" : "U";
	return Be(r).includes(d) ? !i.faceUp || Be(i).includes(Ae[d]) : !1;
}
function Ue(e, t, n) {
	if (M(t) || M(n)) return -1;
	if (t === n) return 0;
	let r = /* @__PURE__ */ new Set([t]), i = [t];
	for (let t = 1; t <= 14; t += 1) {
		let a = [];
		for (let o of i) for (let i of Oe) {
			let s = Ve(o, i);
			if (!r.has(s) && He(e, o, s) && e.grid[s].faceUp) {
				if (s === n) return t;
				r.add(s), a.push(s);
			}
		}
		i = a;
	}
	return -1;
}
function We(e, t, n) {
	let [r, i] = Me(t), [a, o] = Me(n);
	if (r !== a && i !== o) return -1;
	let s = Math.abs(r - a) + Math.abs(i - o);
	if (s === 0) return 0;
	let c = r === a ? o > i ? "D" : "U" : a > r ? "R" : "L", l = t;
	for (let t = 0; t < s; t += 1) {
		let t = Ve(l, c);
		if (!He(e, l, t) || !e.grid[t].faceUp) return -1;
		l = t;
	}
	return s;
}
function I(e, t, n) {
	return M(t) && M(n) ? Math.abs(Number(t.slice(1)) - Number(n.slice(1))) : M(t) || M(n) ? -1 : Ue(e, t, n);
}
function L(e) {
	return e.loot.map((e) => ae.find((t) => t.id === e)).filter((e) => e !== void 0);
}
function Ge(e, t) {
	return L(e).filter((e) => e.set === t).length;
}
function Ke(e, t, n) {
	let r = P(e.defId).defense;
	for (let n of L(e)) for (let e of n.effects) e.k === "stat" && e.def && (r += e.def), e.k === "onMeleeDef" && t === "melee" && (r += 1), e.k === "onMissileOrCastDef" && t !== "melee" && (r += 1);
	return n && (r += 2), r;
}
function qe(e) {
	let t = P(e.defId).speed;
	for (let n of L(e)) for (let e of n.effects) e.k === "stat" && e.spd && (t += e.spd);
	return Math.max(1, t);
}
function Je(e, t, n) {
	let r = P(t.defId), i = n === "any" ? Math.max(r.str, r.agi, r.int) : r[n];
	for (let e of L(t)) for (let t of e.effects) t.k === "checkDie" && t.skill === n && (i += 1);
	return Xe(e, t.pos)?.k === "lessDie" && --i, Math.min(3, Math.max(1, i));
}
function Ye(e, t) {
	let n = 0;
	for (let r of L(e)) for (let e of r.effects) e.k === "checkAdd" && (e.skill === "any" || e.skill === t) && (n += e.n);
	return n;
}
function R(e) {
	let t = [];
	for (let n of P(e.defId).abilities) n.k === "weapon" && t.push({
		name: n.name,
		weapon: n.weapon
	});
	for (let n of L(e)) for (let e of n.effects) e.k === "weapon" && t.push({
		name: e.name,
		weapon: e.weapon
	});
	return t;
}
function Xe(e, t) {
	return !e.boss || !M(t) ? null : Ie(e.boss.defId).spaces[Number(t.slice(1))]?.fx ?? null;
}
function Ze(e) {
	let t = Ie(e).spaces.findIndex((e) => e.entrance);
	return t >= 0 ? t : 0;
}
function z(e) {
	let t = [];
	for (let n of e.goblins) t.push({
		kind: "goblin",
		uid: n.uid,
		defId: n.defId,
		pos: n.pos,
		defense: Pe(n.defId).defense
	});
	for (let n of e.minions) n.dead || t.push({
		kind: "minion",
		uid: n.uid,
		defId: n.defId,
		pos: n.pos,
		defense: Fe(n.defId).defense
	});
	return e.boss && e.act === 2 && t.push({
		kind: "boss",
		uid: "boss",
		defId: e.boss.defId,
		pos: e.boss.pos,
		defense: Ie(e.boss.defId).defense
	}), t;
}
function Qe(e, t) {
	return z(e).filter((e) => e.pos === t);
}
function $e(e, t, n, r) {
	if (n.type === "melee") return r.pos === t.pos;
	let i = n.range ?? 1;
	if (M(t.pos) || M(r.pos)) {
		let n = I(e, t.pos, r.pos);
		return n > 0 && n <= i;
	}
	let a = We(e, t.pos, r.pos);
	return a > 0 && a <= i;
}
function B(e, t, n, r) {
	n <= 0 || (t.hp = Math.max(0, t.hp - n), r.push({
		kind: "damage",
		data: {
			uid: t.uid,
			n
		}
	}), t.hp === 0 && !t.knocked && (t.knocked = !0, r.push({
		kind: "knocked",
		data: { uid: t.uid }
	}), N(e, {
		k: "knocked",
		uid: t.uid
	})));
}
function V(e, t, n, r) {
	n <= 0 || (t.hp = Math.min(P(t.defId).hp, t.hp + n), t.hp > 0 && (t.knocked = !1), r.push({
		kind: "heal",
		data: {
			uid: t.uid,
			n
		}
	}));
}
function H(e, t, n, r) {
	let i = t.focus;
	t.focus = Math.max(0, Math.min(P(t.defId).focus, t.focus + n)), t.focus !== i && r.push({
		kind: "focus",
		data: {
			uid: t.uid,
			n: t.focus - i
		}
	});
}
function et(e, t, n) {
	let r = Le(e), i = de[e.heroCount], a = e.torch + t;
	if (t < 0 && (a = Math.max(a, i)), a >= r.length - 1) {
		e.torch = r.length - 1, e.phase = "lost", e.lostReason = "torch", n.push({
			kind: "torch",
			data: {
				to: e.torch,
				icon: "skull"
			}
		}), N(e, {
			k: "lost",
			reason: "torch"
		});
		return;
	}
	e.torch = a, n.push({
		kind: "torch",
		data: {
			to: a,
			icon: r[a]
		}
	}), t > 0 && tt(e, n);
}
function tt(e, t) {
	let n = Le(e)[e.torch];
	if (n === "goblin") nt(e, t);
	else if (n === "enemy") {
		for (let t of [...e.goblins].sort((e, t) => e.slot - t.slot)) e.enemyQueue.push({
			kind: "goblin",
			uid: t.uid
		});
		for (let t of e.minions) t.dead || e.enemyQueue.push({
			kind: "minion",
			uid: t.uid
		});
		e.act === 2 && e.boss && e.enemyQueue.push({
			kind: "boss",
			uid: "boss"
		}), e.phase = "enemyAct", e.beatMs = De.enemyAct;
	}
}
function nt(e, t, n) {
	if (e.goblins.length >= 4) {
		e.phase = "lost", e.lostReason = "goblins", N(e, {
			k: "lost",
			reason: "goblins"
		});
		return;
	}
	e.goblinDeck.length === 0 && (e.goblinDeck = Re(e.goblinDiscard, e), e.goblinDiscard = []);
	let r = e.goblinDeck.pop(), i = [
		0,
		1,
		2,
		3
	].find((t) => !e.goblins.some((e) => e.slot === t)) ?? 0, a = {
		uid: ze(e, "g"),
		defId: r,
		pos: n ?? je(0, 0),
		slot: i
	};
	e.goblins.push(a), t.push({
		kind: "spawn",
		data: {
			uid: a.uid,
			defId: r,
			pos: a.pos,
			enemy: "goblin"
		}
	}), N(e, {
		k: "spawn",
		enemy: "goblin",
		defId: r
	});
}
function rt(e, t, n) {
	if (e.minionDeck.length === 0) return;
	let r = e.minionDeck.pop(), i = {
		uid: ze(e, "m"),
		defId: r,
		pos: n,
		hp: Fe(r).hp,
		dead: !1
	};
	e.minions.push(i), t.push({
		kind: "spawn",
		data: {
			uid: i.uid,
			defId: r,
			pos: n,
			enemy: "minion"
		}
	}), N(e, {
		k: "spawn",
		enemy: "minion",
		defId: r
	});
}
function it(e, t, n, r = 0) {
	e.choice = {
		kind: "discover",
		forUid: t,
		what: n,
		options: ["deck", ...(n === "loot" ? e.lootDiscard : e.spellDiscard).map((e) => `discard:${e}`)],
		again: r
	};
}
function at(e, t, n, r) {
	let i = n.reward;
	if ("or" in i) {
		e.choice = {
			kind: "goblinReward",
			forUid: t,
			options: i.or.map((e) => e.k === "hp" ? `hp:${e.n}` : e.k === "focus" ? `focus:${e.n}` : e.k)
		};
		return;
	}
	for (let n of i.and) ot(e, t, n, r);
}
function ot(e, t, n, r) {
	let i = e.heroes[t];
	if (n.k === "loot") it(e, t, "loot");
	else if (n.k === "spell") it(e, t, "spell");
	else if (n.k === "hp") V(e, i, n.n ?? 0, r);
	else if (n.k === "focus") H(e, i, n.n ?? 0, r);
	else if (n.k === "reveal") {
		let t = Object.keys(e.grid).filter((t) => !e.grid[t].faceUp);
		t.length > 0 && st(e, t[0], r);
	}
}
function st(e, t, n, r, i) {
	let a = e.grid[t];
	if (!a || a.faceUp || !a.roomId) return;
	let o = F(a.roomId), s = i ?? 0;
	if (r) {
		let [e, n] = Me(r), [a, c] = Me(t), l = a > e ? "L" : a < e ? "R" : c > n ? "U" : "D", u = [
			0,
			1,
			2,
			3
		].filter((e) => o.doors.map((t) => Oe[(Oe.indexOf(t) + e) % 4]).includes(l));
		s = i !== void 0 && u.includes(i) ? i : u[0] ?? 0;
	}
	a.rot = s, a.faceUp = !0, n.push({
		kind: "reveal",
		data: {
			coord: t,
			roomId: a.roomId,
			rot: s
		}
	}), N(e, {
		k: "reveal",
		roomId: o.id
	});
	for (let n of Be(a)) {
		let r = Ve(t, n);
		if (e.grid[r]) continue;
		let [i, a] = Me(r);
		if (Math.abs(i) > 3 || Math.abs(a) > 3) continue;
		let o = e.deck.pop();
		o && (e.grid[r] = {
			roomId: o,
			rot: 0,
			faceUp: !1,
			trapDisarmed: !1,
			used: !1,
			altar: !1,
			spawned: !1
		});
	}
	o.encounter && !a.spawned && (a.spawned = !0, o.encounter === "goblin" ? nt(e, n, t) : rt(e, n, t));
}
function ct(e, t, n, r) {
	let i = e.grid[n];
	if (!i.roomId) return !1;
	let a = F(i.roomId).effect;
	return a.k === "trap" && !i.trapDisarmed ? (lt(e, t, Je(e, t, a.check.skill), a.check.n, "games.ted.rollTrap", {
		k: "trap",
		heroUid: t.uid,
		coord: n
	}, r), !0) : a.k === "goblinBunks" && !i.used && (i.used = !0, lt(e, t, Je(e, t, "agi"), 4, "games.ted.rollBunks", {
		k: "bunks",
		heroUid: t.uid,
		coord: n
	}, r), !0);
}
function lt(t, n, r, i, a, o, s, c = !1) {
	let l = [];
	for (let n = 0; n < r; n += 1) l.push(e(t.seed, t.rngCursor, 6) + 1), t.rngCursor += 1;
	let u = null;
	c && (u = e(t.seed, t.rngCursor, 6) + 1, t.rngCursor += 1), t.pendingRoll = {
		forUid: n.uid,
		dice: l,
		enemyDie: u,
		need: i,
		label: a,
		ctx: o
	}, t.phase = "roll", s.push({
		kind: "roll",
		data: {
			forUid: n.uid,
			dice: l,
			enemyDie: u,
			need: i,
			label: a
		}
	});
}
function ut(e, t) {
	let n = 0;
	for (let [r, i] of Object.entries(ie)) {
		if (i.kind !== "add" || i.on !== t) continue;
		let a = Ge(e, r);
		a >= 2 && (n += Math.min(3, a - 1));
	}
	return n;
}
function U(e, t, n, r, i, a) {
	if (!(r <= 0)) {
		if (n.kind === "goblin") e.goblins = e.goblins.filter((e) => e.uid !== n.uid), e.goblinDiscard.push(n.defId), i.push({
			kind: "kill",
			data: {
				uid: n.uid,
				defId: n.defId
			}
		}), N(e, {
			k: "hitEnemy",
			uid: t.uid,
			defId: n.defId,
			dmg: r,
			killed: !0
		}), at(e, t.uid, Pe(n.defId), i);
		else if (n.kind === "minion") {
			let a = e.minions.find((e) => e.uid === n.uid);
			if (!a) return;
			a.hp -= r, i.push({
				kind: "damage",
				data: {
					uid: n.uid,
					n: r
				}
			}), N(e, {
				k: "hitEnemy",
				uid: t.uid,
				defId: n.defId,
				dmg: r,
				killed: a.hp <= 0
			}), a.hp <= 0 && (a.dead = !0, i.push({
				kind: "kill",
				data: {
					uid: a.uid,
					defId: a.defId
				}
			}), et(e, -6, i), e.phase !== "lost" && (e.choice = {
				kind: "minionReward",
				forUid: t.uid,
				options: ["loot", "spell"],
				count: 2
			}));
		} else {
			let t = e.boss, n = Ie(t.defId), a = r;
			for (t.markers.sort((e, t) => e - t); a > 0 && t.markers.length > 0;) {
				let e = t.markers[0] - 1;
				if (e < 1) {
					t.markers.shift(), --a;
					continue;
				}
				if (n.altars.includes(e) && !t.altarsCovered.includes(e)) break;
				t.markers[0] = e, --a;
			}
			i.push({
				kind: "bossHit",
				data: {
					n: r,
					markers: [...t.markers]
				}
			}), N(e, {
				k: "bossHit",
				dmg: r
			}), t.markers.length === 0 && (e.phase = "won", i.push({
				kind: "phase",
				data: { phase: "won" }
			}), N(e, { k: "won" }));
		}
		for (let [n, r] of Object.entries(ie)) {
			let o = Ge(t, n);
			if (o >= 2 && r.on === a) {
				let n = Math.min(3, o - 1);
				r.kind === "heal" && V(e, t, n, i), r.kind === "focus" && H(e, t, n, i);
			}
		}
	}
}
function dt(e, t, n, r, i, a, o) {
	let s = pe[r - 1], c;
	if (n.kind === "goblin") c = e.goblins.length;
	else if (n.kind === "minion") {
		let e = Fe(n.defId);
		c = (a === "melee" ? e.counterMelee : e.counterRanged).add;
	} else {
		let e = Ie(n.defId), t = a === "melee" ? e.counter.melee : a === "missile" ? e.counter.missile : e.counter.spell;
		c = typeof t == "number" ? t : 0;
	}
	if (s.k === "torch") {
		et(e, 1, i), n.kind === "boss" && e.act === 2 && (H(e, t, -2, i), ft(e, i));
		return;
	}
	let l = s.k === "shield" ? c : Math.max(0, s.n + c - Ke(t, a, o));
	N(e, {
		k: "counter",
		uid: t.uid,
		defId: n.defId,
		dmg: l
	}), B(e, t, l, i);
}
function ft(e, t) {
	let n = e.boss;
	if (!n) return;
	let r = Ie(n.defId).torch, i = (e) => {
		n.markers.length !== 0 && (n.markers.sort((e, t) => e - t), n.markers[n.markers.length - 1] = Math.min(8, n.markers[n.markers.length - 1] + e));
	};
	if (r.k === "aoe") {
		for (let i of Object.values(e.heroes)) {
			let a = I(e, n.pos, i.pos);
			a >= 0 && a <= r.range && B(e, i, r.hp, t);
		}
		r.healSelf && i(r.healSelf);
	} else if (r.k === "goblinAura") for (let n of e.goblins) for (let r of Object.values(e.heroes)) {
		let i = I(e, n.pos, r.pos);
		i >= 0 && i <= 2 && B(e, r, 1, t);
	}
	else if (r.k === "heal") i(r.n);
	else if (r.k === "pharaohChoice") {
		let t = Object.values(e.heroes).filter((t) => {
			let r = I(e, n.pos, t.pos);
			return r >= 0 && r <= 3;
		}), r = t.find((e) => e.spells.length > 0) ?? t[0];
		r && (e.choice = {
			kind: "pharaohTorch",
			forUid: r.uid,
			options: ["focus3", ...r.spells.map((e) => `discard:${e}`)]
		});
	} else r.k === "seerShift" && (n.pos = `L${Ze(n.defId)}`, n.inDungeon = !1, i(2));
}
function pt(e, t, n) {
	if (t.kind === "goblin") {
		let r = e.goblins.find((e) => e.uid === t.uid);
		if (!r) return;
		let i = Pe(r.defId).action, a = i.dmg === "n1" ? e.goblins.length + 1 : i.dmg;
		if (n.push({
			kind: "enemyAct",
			data: { uid: r.uid }
		}), i.k === "rangedOrMove") {
			let t = Object.values(e.heroes).filter((t) => {
				if (t.knocked) return !1;
				let n = I(e, r.pos, t.pos);
				return n >= 0 && n <= i.range;
			});
			if (t.length > 0) for (let i of t) B(e, i, a, n), N(e, {
				k: "enemyHit",
				uid: i.uid,
				defId: r.defId,
				dmg: a
			});
			else mt(e, r, r.uid, i.elseMove, n);
		} else {
			mt(e, r, r.uid, i.move, n);
			let t = Object.values(e.heroes).filter((t) => {
				if (t.knocked) return !1;
				let n = I(e, r.pos, t.pos);
				return n >= 0 && n <= i.range;
			});
			for (let i of t) B(e, i, a, n), N(e, {
				k: "enemyHit",
				uid: i.uid,
				defId: r.defId,
				dmg: a
			});
		}
		return;
	}
	if (t.kind === "minion") {
		let r = e.minions.find((e) => e.uid === t.uid);
		if (!r || r.dead) return;
		let i = Fe(r.defId);
		n.push({
			kind: "enemyAct",
			data: { uid: r.uid }
		}), mt(e, r, r.uid, i.action.move, n);
		let a = Object.values(e.heroes).filter((t) => {
			if (t.knocked) return !1;
			let n = I(e, r.pos, t.pos);
			return n >= 0 && n <= i.action.range;
		});
		for (let t of a) i.action.hp && (B(e, t, i.action.hp, n), N(e, {
			k: "enemyHit",
			uid: t.uid,
			defId: r.defId,
			dmg: i.action.hp
		})), i.action.focus && H(e, t, -i.action.focus, n), i.action.extra === "discardLoot" && t.loot.length > 0 && !e.choice && (e.choice = {
			kind: "oozeDiscard",
			forUid: t.uid,
			options: [...t.loot]
		});
		i.action.extra === "goblinEntrance" && nt(e, n);
		return;
	}
	let r = e.boss;
	if (!r) return;
	let i = Ie(r.defId);
	if (n.push({
		kind: "enemyAct",
		data: { uid: "boss" }
	}), i.action.k === "goblinKing") {
		nt(e, n), r.markers.length > 0 && (r.markers.sort((e, t) => e - t), r.markers[r.markers.length - 1] = Math.min(8, r.markers[r.markers.length - 1] + 2));
		return;
	}
	let a = i.action;
	if (!Object.values(e.heroes).some((e) => M(e.pos)) && !r.inDungeon) {
		let t = Object.entries(e.grid).find(([, e]) => e.faceUp && e.roomId === "lairdoor");
		t && (r.pos = t[0], r.inDungeon = !0, n.push({
			kind: "bossMove",
			data: { to: r.pos }
		}));
	}
	if (r.inDungeon) mt(e, r, "boss", i.speed, n);
	else {
		let t = Number(r.pos.slice(1)), a = Object.values(e.heroes).filter((e) => M(e.pos) && !e.knocked);
		if (a.length > 0) {
			let e = a.reduce((e, n) => Math.abs(Number(n.pos.slice(1)) - t) < Math.abs(Number(e.pos.slice(1)) - t) ? n : e), o = Number(e.pos.slice(1)), s = Math.sign(o - t), c = Math.abs(o - t) <= i.speed ? o : t + s * i.speed;
			c !== t && (r.pos = `L${c}`, n.push({
				kind: "bossMove",
				data: { to: r.pos }
			}));
		}
	}
	for (let t of Object.values(e.heroes)) {
		if (t.knocked) continue;
		let i = I(e, r.pos, t.pos);
		i < 0 || i > a.range || (a.hp && (B(e, t, a.hp, n), N(e, {
			k: "enemyHit",
			uid: t.uid,
			defId: r.defId,
			dmg: a.hp
		})), a.focus && H(e, t, -a.focus, n));
	}
}
function mt(e, t, n, r, i) {
	if (M(t.pos)) return;
	let a = Object.values(e.heroes).filter((e) => !M(e.pos) && !e.knocked).map((e) => e.pos);
	if (a.length === 0 || a.includes(t.pos)) return;
	let o = t.pos, s = [];
	for (let t = 0; t < r; t += 1) {
		let t = null, n = Infinity;
		for (let r of Oe) {
			let i = Ve(o, r);
			if (He(e, o, i) && e.grid[i].faceUp) for (let r of a) {
				let a = Ue(e, i, r);
				a >= 0 && a < n && (n = a, t = i);
			}
		}
		if (!t || (o = t, s.push(o), a.includes(o))) break;
	}
	t.pos = o, s.length > 0 && i.push({
		kind: "move",
		data: {
			uid: n,
			path: s
		}
	});
	let c = e.boss;
	if (c && n === "boss" && c.inDungeon) {
		let t = e.grid[c.pos];
		if (t?.altar) {
			t.altar = !1;
			let e = Ie(c.defId).altars.filter((e) => !c.altarsCovered.includes(e)).sort((e, t) => e - t)[0];
			e !== void 0 && (c.altarsCovered.push(e), i.push({
				kind: "altar",
				data: { altar: e }
			}));
		}
	}
}
function ht(e, t) {
	e.turnSeq += 1;
	let n = e.heroes[e.heroOrder[e.turnIdx]];
	n.speedLeft = qe(n), n.heroActionUsed = !1, n.roomActionUsed = !1, n.abilityUsed = [], n.stealth = !1, n.shadowWalk = !1, n.extraActions = 0, n.extraCheckAdd = 0, n.onlyMove = n.knocked, n.explored = !1, t.push({
		kind: "turn",
		data: { uid: n.uid }
	});
}
function gt(e, t) {
	e.turnIdx = (e.turnIdx + 1) % e.heroOrder.length, e.phase = "play", e.afterQueue = null, ht(e, t), _t(e);
}
function _t(e) {
	e.phase !== "won" && e.phase !== "lost" && e.act !== 2 && (Object.values(e.grid).some((e) => e.faceUp && e.roomId === "lairdoor") || Object.values(e.grid).some((e) => !e.faceUp) || (e.phase = "lost", e.lostReason = "deadend", N(e, {
		k: "lost",
		reason: "deadend"
	})));
}
function vt(t, n, r) {
	let i = ve.parse(t), a = n.length === 1 ? 2 : n.length, o = {
		players: n,
		seed: r,
		rngCursor: 0,
		phase: "pick",
		act: 1,
		heroCount: a,
		pickIdx: 0,
		heroes: {},
		heroOrder: [],
		turnIdx: 0,
		turnSeq: 0,
		grid: {},
		deck: [],
		lootDeck: [],
		lootDiscard: [],
		spellDeck: [],
		spellDiscard: [],
		goblinDeck: [],
		goblinDiscard: [],
		minionDeck: [],
		torch: de[a],
		goblins: [],
		minions: [],
		boss: null,
		pendingRoll: null,
		choice: null,
		enemyQueue: [],
		afterQueue: null,
		uidSeq: 0,
		lostReason: null,
		beatMs: 0,
		log: []
	}, s = Re([...oe], o), c = s.splice(0, ce[a]), l = [];
	for (let e = 0; e < a; e += 1) l.push(...s.splice(0, 3));
	let u = Re([...se], o).slice(0, a), d = Re([...l, ...u], o);
	o.deck = [
		...Re([...s.splice(0, 3), "lairdoor"], o),
		...d,
		...c
	], o.grid[je(0, 0)] = {
		roomId: "entrance",
		rot: 0,
		faceUp: !0,
		trapDisarmed: !1,
		used: !1,
		altar: !1,
		spawned: !0
	};
	for (let e of Oe) {
		let t = o.deck.pop();
		t && (o.grid[Ve(je(0, 0), e)] = {
			roomId: t,
			rot: 0,
			faceUp: !1,
			trapDisarmed: !1,
			used: !1,
			altar: !1,
			spawned: !1
		});
	}
	o.lootDeck = Re(ae.map((e) => e.id), o), o.spellDeck = Re(k.map((e) => e.id), o), o.goblinDeck = Re(E.map((e) => e.id), o), o.minionDeck = Re(D.map((e) => e.id), o);
	let f = i.boss !== "random" && O.some((e) => e.id === i.boss) ? i.boss : O[e(r, o.rngCursor, O.length)].id;
	return o.rngCursor += 1, o.boss = {
		defId: f,
		markers: [],
		altarsCovered: [],
		pos: `L${Ze(f)}`,
		inDungeon: !1
	}, {
		state: o,
		fx: [{
			kind: "phase",
			data: { phase: "pick" }
		}]
	};
}
function W(e) {
	return { code: e };
}
function yt(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "enemyAct") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = [], r = t.enemyQueue.shift();
		return r ? (pt(t, r, n), t.beatMs = t.choice || t.phase === "lost" ? 0 : De.enemyAct) : (t.beatMs = 0, t.afterQueue === "nextTurn" ? gt(t, n) : t.phase = "play"), {
			state: t,
			fx: n
		};
	}
	if (e.phase === "pick") {
		if (t.type !== "pickHero") return W("games.ted.errNotYourTurn");
		let r = e.players[e.pickIdx % e.players.length];
		if (n.by !== r) return W("games.ted.errNotYourTurn");
		if (!T.some((e) => e.id === t.heroId) || e.heroes[t.heroId]) return W("games.ted.errBadPick");
		let i = structuredClone(e), a = P(t.heroId);
		i.heroes[t.heroId] = {
			uid: t.heroId,
			defId: t.heroId,
			rid: n.by,
			hp: a.hp,
			focus: a.focus,
			pos: je(0, 0),
			loot: [],
			spells: [],
			knocked: !1,
			speedLeft: 0,
			heroActionUsed: !1,
			roomActionUsed: !1,
			abilityUsed: [],
			stealth: !1,
			shadowWalk: !1,
			extraActions: 0,
			extraCheckAdd: 0,
			onlyMove: !1,
			explored: !1
		}, i.heroOrder.push(t.heroId), i.pickIdx += 1, N(i, {
			k: "pick",
			uid: t.heroId
		});
		let o = [{
			kind: "pick",
			rid: n.by,
			data: { heroId: t.heroId }
		}];
		return i.heroOrder.length === i.heroCount && (i.phase = "play", ht(i, o)), {
			state: i,
			fx: o
		};
	}
	if (e.phase === "won" || e.phase === "lost") return W("games.ted.errNotYourTurn");
	if (e.choice) return t.type === "choose" ? bt(e, t.option, n) : W("games.ted.errNotYourTurn");
	if (e.phase === "roll") return t.type === "resolveRoll" ? Tt(e, t, n) : W("games.ted.errNotYourTurn");
	if (e.phase !== "play") return W("games.ted.errNotYourTurn");
	let r = e.heroes[e.heroOrder[e.turnIdx]];
	return !r || r.rid !== n.by ? W("games.ted.errNotYourTurn") : At(e, t);
}
function bt(e, t, n) {
	let r = e.choice, i = e.heroes[r.forUid];
	if (!i || i.rid !== n.by) return W("games.ted.errNotYourTurn");
	if (!r.options.includes(t)) return W("games.ted.errBadChoice");
	let a = structuredClone(e), o = a.choice, s = a.heroes[o.forUid], c = [];
	switch (a.choice = null, o.kind) {
		case "goblinReward":
			t === "loot" ? it(a, s.uid, "loot") : t === "spell" ? it(a, s.uid, "spell") : t.startsWith("hp:") ? V(a, s, Number(t.slice(3)), c) : t.startsWith("focus:") ? H(a, s, Number(t.slice(6)), c) : t === "reveal" && ot(a, s.uid, { k: "reveal" }, c);
			break;
		case "minionReward":
			it(a, s.uid, t, o.count - 1);
			break;
		case "discover":
			if (t === "deck") o.what === "loot" && a.lootDeck.length > 0 ? xt(a, s, a.lootDeck.pop(), c) : o.what === "spell" && a.spellDeck.length > 0 && St(a, s, a.spellDeck.pop(), c);
			else {
				let e = t.slice(8);
				o.what === "loot" && a.lootDiscard.includes(e) ? (a.lootDiscard = a.lootDiscard.filter((t) => t !== e), xt(a, s, e, c)) : o.what === "spell" && a.spellDiscard.includes(e) && (a.spellDiscard = a.spellDiscard.filter((t) => t !== e), St(a, s, e, c));
			}
			o.again > 0 && (a.choice = {
				kind: "minionReward",
				forUid: s.uid,
				options: ["loot", "spell"],
				count: o.again
			});
			break;
		case "pharaohTorch":
			if (t === "focus3") H(a, s, -3, c);
			else {
				let e = t.slice(8);
				s.spells = s.spells.filter((t) => t !== e), a.spellDiscard.push(e);
			}
			wt(a, c);
			break;
		case "oozeDiscard":
			s.loot = s.loot.filter((e) => e !== t), a.lootDiscard.push(t), wt(a, c);
			break;
		case "pulleyKill": {
			let e = a.goblins.find((e) => e.uid === t);
			e && (a.goblins = a.goblins.filter((e) => e.uid !== t), a.goblinDiscard.push(e.defId), c.push({
				kind: "kill",
				data: {
					uid: e.uid,
					defId: e.defId
				}
			}));
			break;
		}
		case "warhorn": {
			let e = o.queue, n = e[0], r = z(a).find((e) => e.uid === n);
			if (r && t !== "skip" && a.grid[t]?.faceUp) {
				let e = Ue(a, r.pos, t);
				if (e >= 0 && e <= 2) {
					let e = a.goblins.find((e) => e.uid === n) ?? a.minions.find((e) => e.uid === n);
					e && (e.pos = t), c.push({
						kind: "move",
						data: {
							uid: n,
							path: [t]
						}
					});
				}
			}
			let i = e.slice(1);
			i.length > 0 && (a.choice = {
				kind: "warhorn",
				forUid: s.uid,
				options: o.options,
				queue: i
			});
			break;
		}
	}
	return {
		state: a,
		fx: c
	};
}
function xt(e, t, n, r) {
	t.loot.push(n), Ct(e, t), r.push({
		kind: "gain",
		data: {
			uid: t.uid,
			loot: n
		}
	}), N(e, {
		k: "gain",
		uid: t.uid,
		item: n
	});
}
function St(e, t, n, r) {
	if (t.spells.length >= me.spell) {
		e.spellDiscard.push(n);
		return;
	}
	t.spells.push(n), r.push({
		kind: "gain",
		data: {
			uid: t.uid,
			spell: n
		}
	}), N(e, {
		k: "gain",
		uid: t.uid,
		item: n
	});
}
function Ct(e, t) {
	let n = (e) => t.loot.filter((t) => ae.find((e) => e.id === t)?.slot === e);
	for (let [r, i] of Object.entries({
		hand: me.hand,
		garb: me.garb,
		trinket: me.trinket
	})) {
		let a = n(r);
		for (; a.length > i;) {
			let n = a.shift();
			t.loot = t.loot.filter((e) => e !== n), e.lootDiscard.push(n);
		}
	}
}
function wt(e, t) {
	e.phase === "enemyAct" && (e.enemyQueue.length > 0 ? e.beatMs = De.enemyAct : (e.beatMs = 0, e.afterQueue === "nextTurn" ? gt(e, t) : e.phase = "play"));
}
function Tt(t, n, r) {
	let i = t.pendingRoll;
	if (!i) return W("games.ted.errNotYourTurn");
	let a = t.heroes[i.forUid];
	if (!a || a.rid !== r.by) return W("games.ted.errNotYourTurn");
	if (n.dieIdx >= i.dice.length) return W("games.ted.errBadChoice");
	let o = n.boosts ?? [], s = P(a.defId).abilities, c = i.ctx.k === "attack", l = c ? i.ctx.weapon.type === "melee" ? "melee" : "missile" : "melee", u = o.filter((e) => e === "lionPump").length, d = (e) => s.some((t) => t.k === e), f = (e) => L(a).some((t) => t.effects.some((t) => t.k === e)), p = 0;
	if (o.includes("battleRage")) {
		if (!c || !d("battleRage")) return W("games.ted.errBadChoice");
		p += 3;
	}
	if (o.includes("stoneStance")) {
		if (!c || l !== "melee" || !d("stoneStance")) return W("games.ted.errBadChoice");
		p += 2;
	}
	if (u > 0) {
		if (!c || l !== "melee" || !f("lionSwordPump")) return W("games.ted.errBadChoice");
		p += u * 2;
	}
	let m = o.filter((e) => e.startsWith("reroll"));
	if (m.length > 0 && (!c || l !== "melee" || m.length > 1 || !f("meleeReroll"))) return W("games.ted.errBadChoice");
	if (o.includes("clericHeal")) {
		if (i.ctx.k !== "cast" || !d("clericHeal")) return W("games.ted.errBadChoice");
		p += 2;
	}
	let h = n.nudges.length * 2;
	if (a.focus < p + h) return W("games.ted.errNoFocus");
	let g = structuredClone(t), _ = g.pendingRoll, v = g.heroes[_.forUid], y = [];
	g.pendingRoll = null, g.phase = "play";
	let b = [..._.dice];
	for (let e of n.nudges) {
		let t = b[e.die] + e.dir;
		if (t < 1 || t > 6) return W("games.ted.errBadNudge");
		b[e.die] = t;
	}
	H(g, v, -(p + h), y);
	for (let t of m) {
		let n = Number(t.slice(6));
		n >= 0 && n < b.length && (b[n] = e(g.seed, g.rngCursor, 6) + 1, g.rngCursor += 1);
	}
	let x = b[n.dieIdx];
	for (let e = 0; e < b.length; e += 1) {
		if (e === n.dieIdx) continue;
		let t = fe[b[e] - 1];
		x += t.add, t.focus > 0 && H(g, v, t.focus, y), t.hp > 0 && V(g, v, t.hp, y);
	}
	let S = Et(g, _);
	x += Ye(v, S);
	let C = Xe(g, v.pos);
	if (C?.k === "checkAdd" && (C.skill === "any" || C.skill === S) && (x += C.n), v.extraCheckAdd > 0 && (x += v.extraCheckAdd), c) {
		let e = _.ctx;
		x += e.weapon.mod + ut(v, l), o.includes("battleRage") && (x += 2), x += u;
	}
	let w = x >= _.need;
	return y.push({
		kind: "resolve",
		data: {
			forUid: v.uid,
			faces: b,
			dieIdx: n.dieIdx,
			total: x,
			success: w,
			need: _.need
		}
	}), N(g, {
		k: "roll",
		uid: v.uid,
		label: _.label,
		total: x,
		need: _.need,
		success: w
	}), Dt(g, v, _, x, w, _.enemyDie, y, o.includes("stoneStance")), {
		state: g,
		fx: y
	};
}
function Et(e, t) {
	let n = t.ctx;
	if (n.k === "attack") return n.weapon.skill;
	if (n.k === "cast") return k.find((e) => e.id === n.spellId)?.check.skill ?? "int";
	if (n.k === "trap" || n.k === "disarm" || n.k === "roomCheck") {
		let t = e.grid[n.coord], r = t?.roomId ? F(t.roomId).effect : null;
		return n.k === "disarm" && r?.k === "trap" ? r.disarm.skill : n.k === "roomCheck" && (r?.k === "search" || r?.k === "arcaneAltar" || r?.k === "cauldron") || n.k === "roomCheck" && r?.k === "feasthall" ? "int" : "any";
	}
	if (n.k === "bunks") return "agi";
	if (n.k === "ability") {
		let e = P(n.heroUid).abilities[n.idx];
		return e?.k === "seekingBolt" || e?.k === "divineMight" ? "int" : "agi";
	}
	return "any";
}
function Dt(e, t, n, r, i, a, o, s) {
	let c = n.ctx;
	switch (c.k) {
		case "trap": {
			let n = e.grid[c.coord], r = F(n.roomId).effect;
			r.k === "trap" && !i && B(e, t, r.failDmg, o);
			return;
		}
		case "disarm":
			i && (e.grid[c.coord].trapDisarmed = !0, o.push({
				kind: "disarm",
				data: { coord: c.coord }
			}));
			return;
		case "bunks":
			i ? it(e, t.uid, "loot") : (nt(e, o, c.coord), B(e, t, 1, o));
			return;
		case "roomCheck":
			Ot(e, t, c.coord, i, o);
			return;
		case "attack": {
			let n = z(e).find((e) => e.uid === c.targetUid);
			if (!n) return;
			let i = c.weapon.type === "melee" ? "melee" : "missile";
			if (r > n.defense) {
				o.push({
					kind: "hit",
					data: {
						uid: n.uid,
						n: r - n.defense
					}
				}), U(e, t, n, r - n.defense, o, i);
				for (let n of L(t)) for (let r of n.effects) r.k === "onMeleeFocus" && i === "melee" && H(e, t, 1, o), r.k === "onMissileFocus" && i === "missile" && H(e, t, 1, o);
			}
			z(e).some((e) => e.uid === c.targetUid) && a !== null && e.phase !== "won" && e.phase !== "lost" && dt(e, t, n, a, o, i, s);
			return;
		}
		case "cast":
			kt(e, t, c, i, o);
			return;
		case "ability": {
			if (!i) return;
			let n = P(t.defId).abilities[c.idx];
			if (n?.k === "seekingBolt") {
				H(e, t, -2, o);
				let n = z(e).find((e) => e.uid === c.targetUid);
				if (n) {
					let r = I(e, t.pos, n.pos);
					r >= 0 && r <= 4 && U(e, t, n, 1, o, "spell");
				}
			} else if (n?.k === "divineMight") {
				H(e, t, -2, o);
				let n = c.targetUid ? z(e).find((e) => e.uid === c.targetUid) : Qe(e, t.pos)[0];
				n && n.pos === t.pos && U(e, t, n, 2, o, "melee");
			} else n?.k === "shadowWalk" && (t.stealth = !0, t.shadowWalk = !0, t.speedLeft += qe(t));
			return;
		}
	}
}
function Ot(e, t, n, r, i) {
	let a = e.grid[n], o = F(a.roomId).effect;
	if (!r) {
		o.k === "armory" || o.k === "cauldron" ? et(e, 1, i) : o.k === "feasthall" && B(e, t, 2, i);
		return;
	}
	let s = (n) => {
		let r = n === "loot" ? e.lootDiscard : e.spellDiscard;
		r.length > 0 && (e.choice = {
			kind: "discover",
			forUid: t.uid,
			what: n,
			options: r.map((e) => `discard:${e}`),
			again: 0
		});
	};
	switch (o.k) {
		case "search":
			a.used = !0, (e.lootDiscard.length > 0 || e.spellDiscard.length > 0) && s(e.lootDiscard.length > 0 ? "loot" : "spell");
			return;
		case "graveyard":
			a.used = !0, et(e, -1, i), s("loot");
			return;
		case "arcaneAltar":
			H(e, t, -4, i), et(e, -2, i);
			return;
		case "cauldron":
			H(e, t, 2, i), it(e, t.uid, "spell");
			return;
		case "armory":
			s("loot");
			return;
		case "feasthall":
			H(e, t, -3, i), V(e, t, P(t.defId).hp, i);
			return;
	}
}
function kt(e, t, n, r, i) {
	let a = k.find((e) => e.id === n.spellId);
	if (!a) return;
	if (t.spells = t.spells.filter((e) => e !== n.spellId), e.spellDiscard.push(n.spellId), !r) {
		a.fail === "torchDown" ? et(e, 1, i) : a.fail === "goblinSelf" && nt(e, i, t.pos);
		return;
	}
	H(e, t, -a.cost, i), i.push({
		kind: "cast",
		data: {
			uid: t.uid,
			spell: n.spellId
		}
	});
	let o = a.effect, s = +!!L(t).some((e) => e.effects.some((e) => e.k === "spellDamageUp"));
	switch (o.k) {
		case "damage":
			for (let r of (n.targetUids ?? []).slice(0, o.targets)) {
				let n = z(e).find((e) => e.uid === r);
				if (!n) continue;
				let a = I(e, t.pos, n.pos);
				a >= 0 && a <= o.range && U(e, t, n, o.dmg + s, i, "spell");
			}
			return;
		case "aoeDamage":
			for (let n of z(e)) {
				let r = I(e, t.pos, n.pos);
				r >= 0 && r <= o.range && U(e, t, n, o.dmg + s, i, "spell");
			}
			return;
		case "tempestArrows": {
			for (let n of Qe(e, t.pos)) U(e, t, n, 1 + s, i, "spell");
			let r = z(e).find((e) => e.uid === (n.targetUids ?? [])[0]);
			if (r) {
				let n = I(e, t.pos, r.pos);
				n >= 0 && n <= 2 && U(e, t, r, 2 + s, i, "spell");
			}
			return;
		}
		case "eaglesSwiftness": {
			let r = z(e).find((e) => e.uid === (n.targetUids ?? [])[0]), a = R(t).find((e) => e.weapon.type === "missile");
			r && a && $e(e, t, a.weapon, r) && U(e, t, r, 3 + a.weapon.mod + s, i, "spell");
			return;
		}
		case "healAllMax":
			for (let n of Object.values(e.heroes)) {
				let r = I(e, t.pos, n.pos);
				r >= 0 && r <= o.range && V(e, n, P(n.defId).hp, i);
			}
			o.goblinSelf && nt(e, i, t.pos);
			return;
		case "holyAbundance":
			for (let n of Object.values(e.heroes)) {
				let r = I(e, t.pos, n.pos);
				r >= 0 && r <= 4 && (V(e, n, 3, i), H(e, n, 2, i));
			}
			e.lootDiscard.length > 0 && (e.choice = {
				kind: "discover",
				forUid: t.uid,
				what: "loot",
				options: e.lootDiscard.map((e) => `discard:${e}`),
				again: 0
			});
			return;
		case "extraAction":
			t.extraActions += 1, t.extraCheckAdd = o.checkAdd;
			return;
		case "dungeonScry": {
			let n = Object.keys(e.grid).filter((t) => !e.grid[t].faceUp);
			n.length > 0 && st(e, n[0], i), t.extraActions += 1;
			return;
		}
		case "giantsStrength":
			n.coord && (e.grid[n.coord]?.faceUp || M(n.coord)) && (t.pos = n.coord, i.push({
				kind: "move",
				data: {
					uid: t.uid,
					path: [n.coord]
				}
			}));
			for (let n of Qe(e, t.pos)) U(e, t, n, 2 + s, i, "spell");
			return;
		case "invisibility":
			n.coord && (e.grid[n.coord]?.faceUp || M(n.coord)) && (t.pos = n.coord, i.push({
				kind: "move",
				data: {
					uid: t.uid,
					path: [n.coord]
				}
			})), t.extraActions += 1;
			return;
		case "restAura": return;
	}
}
function At(e, t) {
	let n = structuredClone(e), r = [], i = n.heroes[n.heroOrder[n.turnIdx]];
	if (i.knocked && t.type !== "rest" && t.type !== "endTurn") return W("games.ted.errKnocked");
	switch (t.type) {
		case "move": {
			let e = () => i.stealth || L(i).some((e) => e.effects.some((e) => e.k === "stealth"));
			if (t.path.length > i.speedLeft) return W("games.ted.errNoSpeed");
			let a = i.pos, o = [], s = !1;
			for (let c of t.path) {
				if (i.speedLeft < 1) break;
				if (M(a) || M(c)) {
					let t = n.boss, r = `L${Ze(t.defId)}`, s = Object.entries(n.grid).find(([, e]) => e.faceUp && e.roomId === "lairdoor");
					if (M(c)) {
						if (n.act !== 2 || !s || a !== s[0] || c !== r) return W("games.ted.errBlocked");
					} else if (M(a)) {
						let e = Number(a.slice(1)), t = c === `L${e - 1}` || c === `L${e + 1}`, n = s && c === s[0] && a === r;
						if (!t && !n) return W("games.ted.errBlocked");
						if (t) {
							let e = Number(c.slice(1));
							if (e < 0 || e > 5) return W("games.ted.errBlocked");
						}
					}
					if (--i.speedLeft, a = c, o.push(a), !e() && Qe(n, a).length > 0) break;
					continue;
				}
				let l = n.grid[c];
				if (!l || !He(n, a, c)) return W("games.ted.errBlocked");
				if (!l.faceUp) {
					if (--i.speedLeft, a = c, o.push(a), st(n, a, r, o.length > 1 ? o[o.length - 2] : i.pos, t.rot), n.phase === "lost") break;
					let e = F(l.roomId);
					e.encounter && (B(n, i, e.encounter === "goblin" ? 1 : 2, r), i.speedLeft = 0), ct(n, i, a, r) && (s = !0);
					break;
				}
				if (--i.speedLeft, a = c, o.push(a), ct(n, i, a, r)) {
					s = !0;
					break;
				}
				if (!e() && Qe(n, a).length > 0) break;
			}
			if (i.pos = a, o.length > 0 && r.push({
				kind: "move",
				data: {
					uid: i.uid,
					path: o
				}
			}), !s && (Mt(n, i, r), i.shadowWalk)) {
				for (let e of Qe(n, i.pos)) U(n, i, e, 1, r, "melee");
				i.shadowWalk = !1;
			}
			return {
				state: n,
				fx: r
			};
		}
		case "attack": {
			if (i.onlyMove || i.heroActionUsed && i.extraActions <= 0) return W("games.ted.errNoAction");
			let e = R(i)[t.weaponIdx];
			if (!e) return W("games.ted.errBadChoice");
			let a = z(n).find((e) => e.uid === t.targetUid);
			return !a || !$e(n, i, e.weapon, a) ? W("games.ted.errBadTarget") : (jt(i), lt(n, i, Je(n, i, e.weapon.skill), a.defense + 1, "games.ted.rollAttack", {
				k: "attack",
				heroUid: i.uid,
				targetUid: a.uid,
				weapon: e.weapon
			}, r, !0), {
				state: n,
				fx: r
			});
		}
		case "search": {
			if (i.onlyMove || i.heroActionUsed && i.extraActions <= 0) return W("games.ted.errNoAction");
			let e = n.grid[i.pos], t = e?.roomId ? F(e.roomId).effect : null;
			if (!t || t.k !== "search" && t.k !== "graveyard" && t.k !== "arcaneAltar" && t.k !== "cauldron" || e.used && (t.k === "search" || t.k === "graveyard")) return W("games.ted.errBadChoice");
			jt(i);
			let a = t.k === "search" ? t.check : t.k === "graveyard" ? {
				skill: "any",
				n: 7
			} : {
				skill: "int",
				n: 5
			};
			return lt(n, i, Je(n, i, a.skill), a.n, "games.ted.rollSearch", {
				k: "roomCheck",
				heroUid: i.uid,
				coord: i.pos
			}, r), {
				state: n,
				fx: r
			};
		}
		case "disarm": {
			if (i.onlyMove || i.heroActionUsed && i.extraActions <= 0) return W("games.ted.errNoAction");
			let e = n.grid[i.pos], t = e?.roomId ? F(e.roomId).effect : null;
			return !e || t?.k !== "trap" || e.trapDisarmed ? W("games.ted.errBadChoice") : (jt(i), lt(n, i, Je(n, i, t.disarm.skill), t.disarm.n, "games.ted.rollDisarm", {
				k: "disarm",
				heroUid: i.uid,
				coord: i.pos
			}, r), {
				state: n,
				fx: r
			});
		}
		case "rest": {
			if (i.heroActionUsed && i.extraActions <= 0) return W("games.ted.errNoAction");
			let e = i.knocked;
			jt(i), i.knocked = !1, e && (i.onlyMove = !0), V(n, i, 3, r), H(n, i, 5, r);
			for (let e of Object.values(n.heroes)) if (e.spells.includes("elementalcharge")) for (let t of Object.values(n.heroes)) {
				let i = I(n, e.pos, t.pos);
				i >= 0 && i <= 2 && (V(n, t, 2, r), H(n, t, 3, r));
			}
			return r.push({
				kind: "rest",
				data: { uid: i.uid }
			}), N(n, {
				k: "rest",
				uid: i.uid
			}), {
				state: n,
				fx: r
			};
		}
		case "cast": {
			if (i.onlyMove || i.heroActionUsed && i.extraActions <= 0) return W("games.ted.errNoAction");
			let e = k.find((e) => e.id === t.spellId);
			if (!e || !i.spells.includes(t.spellId)) return W("games.ted.errBadChoice");
			if (i.focus < e.cost) return W("games.ted.errNoFocus");
			if (n.boss && n.act === 2) {
				let e = Ie(n.boss.defId).counter.spell;
				typeof e == "object" && H(n, i, -e.focusBeforeCast, r);
			}
			return jt(i), lt(n, i, Je(n, i, e.check.skill), e.check.n, "games.ted.rollCast", {
				k: "cast",
				heroUid: i.uid,
				spellId: e.id,
				targetUids: t.targetUids,
				coord: t.coord
			}, r, !0), {
				state: n,
				fx: r
			};
		}
		case "ability": {
			if (i.onlyMove) return W("games.ted.errNoAction");
			let e = P(i.defId).abilities[t.idx];
			if (!e || e.k === "weapon" || i.abilityUsed.includes(t.idx) || e.k === "stoneStance" || e.k === "battleRage" || e.k === "clericHeal") return W("games.ted.errBadChoice");
			if (e.k === "seekingBolt" || e.k === "divineMight" || e.k === "shadowWalk") {
				if (i.heroActionUsed && i.extraActions <= 0) return W("games.ted.errNoAction");
				i.abilityUsed.push(t.idx), jt(i);
				let a = e.k === "shadowWalk" ? {
					skill: "agi",
					n: 6
				} : e.k === "divineMight" ? {
					skill: "int",
					n: 4
				} : {
					skill: "int",
					n: 5
				};
				return lt(n, i, Je(n, i, a.skill), a.n, "games.ted.rollAbility", {
					k: "ability",
					heroUid: i.uid,
					idx: t.idx,
					targetUid: t.targetUid
				}, r), {
					state: n,
					fx: r
				};
			}
			let a = {
				research: 4,
				healingHands: 2,
				shieldBash: 5,
				sprint: 1,
				lockpick: 2,
				stealth: 2
			}[e.k];
			if (i.focus < a) return W("games.ted.errNoFocus");
			switch (H(n, i, -a, r), i.abilityUsed.push(t.idx), e.k) {
				case "research":
					it(n, i.uid, "spell");
					break;
				case "healingHands": {
					let e = t.targetUid ? n.heroes[t.targetUid] : i, a = I(n, i.pos, e.pos);
					a >= 0 && a <= 1 ? V(n, e, 2, r) : H(n, i, 2, r);
					break;
				}
				case "shieldBash": {
					let e = Qe(n, i.pos).find((e) => e.kind === "goblin");
					e ? U(n, i, e, 99, r, "melee") : H(n, i, 5, r);
					break;
				}
				case "sprint":
					i.speedLeft += 1;
					break;
				case "lockpick": {
					let e = n.grid[i.pos];
					(e?.roomId ? F(e.roomId).effect : null)?.k === "trap" && !e.trapDisarmed && (e.trapDisarmed = !0, r.push({
						kind: "disarm",
						data: { coord: i.pos }
					}));
					break;
				}
				case "stealth": i.stealth = !0;
			}
			return {
				state: n,
				fx: r
			};
		}
		case "roomAction": {
			if (i.onlyMove) return W("games.ted.errNoAction");
			let e = n.grid[i.pos], a = e?.roomId ? F(e.roomId).effect : null;
			if (!e || !a || i.roomActionUsed) return W("games.ted.errBadChoice");
			switch (a.k) {
				case "well": return i.roomActionUsed = !0, et(n, 1, r), V(n, i, P(i.defId).hp, r), {
					state: n,
					fx: r
				};
				case "library": return i.focus < 4 ? W("games.ted.errNoFocus") : (i.roomActionUsed = !0, H(n, i, -4, r), it(n, i.uid, "spell"), {
					state: n,
					fx: r
				});
				case "pulley": return i.focus < 4 ? W("games.ted.errNoFocus") : n.goblins.length === 0 ? W("games.ted.errBadChoice") : (i.roomActionUsed = !0, H(n, i, -4, r), n.choice = {
					kind: "pulleyKill",
					forUid: i.uid,
					options: n.goblins.map((e) => e.uid)
				}, {
					state: n,
					fx: r
				});
				case "armory": return i.roomActionUsed = !0, lt(n, i, Je(n, i, "any"), 7, "games.ted.rollArmory", {
					k: "roomCheck",
					heroUid: i.uid,
					coord: i.pos
				}, r), {
					state: n,
					fx: r
				};
				case "feasthall": return i.roomActionUsed = !0, lt(n, i, Je(n, i, "int"), 4, "games.ted.rollFeast", {
					k: "roomCheck",
					heroUid: i.uid,
					coord: i.pos
				}, r), {
					state: n,
					fx: r
				};
				case "teleport": return i.focus < 2 || !t.coord ? W("games.ted.errNoFocus") : !n.grid[t.coord]?.faceUp || t.coord === i.pos ? W("games.ted.errBadTarget") : (i.roomActionUsed = !0, H(n, i, -2, r), i.pos = t.coord, r.push({
					kind: "move",
					data: {
						uid: i.uid,
						path: [t.coord]
					}
				}), {
					state: n,
					fx: r
				});
				default: return W("games.ted.errBadChoice");
			}
		}
		case "explore":
			if (i.onlyMove) return W("games.ted.errNoAction");
			if (i.explored) return W("games.ted.errBadChoice");
			if (i.explored = !0, et(n, 1, r), n.phase === "lost") return {
				state: n,
				fx: r
			};
			for (let e of Oe) {
				let t = Ve(i.pos, e), a = n.grid[t];
				a && !a.faceUp && st(n, t, r, i.pos);
			}
			return {
				state: n,
				fx: r
			};
		case "equip": {
			let e = i.loot.indexOf(t.lootId);
			if (e < 0) return W("games.ted.errBadChoice");
			if (t.toUid && t.toUid !== i.uid) {
				let a = n.heroes[t.toUid];
				if (!a || a.pos !== i.pos) return W("games.ted.errBadTarget");
				i.loot.splice(e, 1), a.loot.push(t.lootId), Ct(n, a), r.push({
					kind: "gain",
					data: {
						uid: a.uid,
						loot: t.lootId
					}
				}), N(n, {
					k: "gain",
					uid: a.uid,
					item: t.lootId
				});
			}
			return {
				state: n,
				fx: r
			};
		}
		case "useLoot": {
			let e = L(i).find((e) => e.id === t.lootId);
			if (!e) return W("games.ted.errBadChoice");
			for (let a of e.effects) {
				if (a.k === "warHorn") {
					if (i.focus < 2) return W("games.ted.errNoFocus");
					let e = z(n).filter((e) => {
						if (e.kind === "boss" || M(e.pos)) return !1;
						let t = Ue(n, i.pos, e.pos);
						return t >= 0 && t <= 4;
					});
					return e.length === 0 ? W("games.ted.errBadTarget") : (H(n, i, -2, r), n.choice = {
						kind: "warhorn",
						forUid: i.uid,
						options: [],
						queue: e.map((e) => e.uid)
					}, n.choice.options = ["skip", ...Object.keys(n.grid).filter((e) => n.grid[e].faceUp)], {
						state: n,
						fx: r
					});
				}
				if (a.k === "freeTeleport") return i.focus < 2 || !t.coord ? W("games.ted.errNoFocus") : !n.grid[t.coord]?.faceUp || t.coord === i.pos ? W("games.ted.errBadTarget") : (H(n, i, -2, r), i.pos = t.coord, r.push({
					kind: "move",
					data: {
						uid: i.uid,
						path: [t.coord]
					}
				}), {
					state: n,
					fx: r
				});
				if (a.k === "pantherVolley") {
					if (i.focus < 3) return W("games.ted.errNoFocus");
					let e = z(n).filter((e) => {
						let t = I(n, i.pos, e.pos);
						return t >= 0 && t <= 1;
					});
					if (e.length === 0) return W("games.ted.errBadTarget");
					H(n, i, -3, r);
					for (let t of e) U(n, i, t, 2, r, "missile");
					return {
						state: n,
						fx: r
					};
				}
			}
			return W("games.ted.errBadChoice");
		}
		case "enterLair": {
			if (n.grid[i.pos]?.roomId !== "lairdoor" || n.minions.length < n.heroCount || n.minions.some((e) => !e.dead)) return W("games.ted.errLairLocked");
			if (i.speedLeft < 1) return W("games.ted.errNoSpeed");
			--i.speedLeft;
			let e = n.boss;
			if (N(n, {
				k: "enterLair",
				uid: i.uid
			}), n.act === 1) {
				n.act = 2, n.torch = de[n.heroCount];
				for (let e of Object.values(n.grid)) e.faceUp && e.roomId?.startsWith("minion") && (e.altar = !0);
				e.markers = Array.from({ length: n.heroCount }, () => 8), e.pos = `L${Ze(e.defId)}`, e.inDungeon = !1, r.push({
					kind: "phase",
					data: { phase: "act2" }
				}), N(n, { k: "act2" });
			}
			return i.pos = `L${Ze(e.defId)}`, r.push({
				kind: "move",
				data: {
					uid: i.uid,
					path: [i.pos]
				}
			}), Mt(n, i, r), {
				state: n,
				fx: r
			};
		}
		case "taunt": {
			if (n.act !== 2 || !n.boss) return W("games.ted.errBadChoice");
			if (i.focus < 2) return W("games.ted.errNoFocus");
			let e = n.boss;
			if (H(n, i, -2, r), M(i.pos) && M(e.pos)) {
				let t = Number(i.pos.slice(1)), n = Number(e.pos.slice(1));
				t !== n && (e.pos = `L${n + Math.sign(t - n)}`, r.push({
					kind: "bossMove",
					data: { to: e.pos }
				}));
			} else if (!M(i.pos)) {
				if (e.inDungeon) mt(n, e, "boss", 1, r);
				else {
					let t = Object.entries(n.grid).find(([, e]) => e.faceUp && e.roomId === "lairdoor");
					t && (e.pos = t[0], e.inDungeon = !0, r.push({
						kind: "bossMove",
						data: { to: e.pos }
					}));
				}
			}
			return {
				state: n,
				fx: r
			};
		}
		case "endTurn": return et(n, 1, r), n.phase === "lost" ? {
			state: n,
			fx: r
		} : n.phase === "enemyAct" ? (n.afterQueue = "nextTurn", {
			state: n,
			fx: r
		}) : (gt(n, r), {
			state: n,
			fx: r
		});
		default: return W("games.ted.errBadChoice");
	}
}
function jt(e) {
	e.extraActions > 0 ? --e.extraActions : e.heroActionUsed = !0;
}
function Mt(e, t, n) {
	let r = Xe(e, t.pos);
	r && (r.k === "hp" ? B(e, t, -r.n, n) : r.k === "focus" ? H(e, t, r.n, n) : r.k === "fullRestore" ? (V(e, t, P(t.defId).hp, n), H(e, t, P(t.defId).focus, n)) : r.k === "goblinEntrance" ? nt(e, n) : r.k === "moveAgain" && (t.speedLeft += qe(t)));
}
function Nt(e, t) {
	let n = e.phase === "play" || e.phase === "roll" ? e.heroOrder[e.turnIdx] : null, r = n ? e.heroes[n] : null;
	return {
		public: {
			phase: e.phase,
			act: e.act,
			heroCount: e.heroCount,
			torch: e.torch,
			grid: Object.fromEntries(Object.entries(e.grid).map(([e, t]) => [e, {
				roomId: t.faceUp ? t.roomId : null,
				rot: t.rot,
				faceUp: t.faceUp,
				altar: t.altar,
				trap: t.faceUp && !!t.roomId && F(t.roomId).effect.k === "trap" && !t.trapDisarmed,
				used: t.used
			}])),
			heroes: Object.values(e.heroes).map((t) => {
				let n = P(t.defId), r = e.grid[t.pos], i = r?.roomId && !M(t.pos) ? F(r.roomId).effect : null;
				return {
					uid: t.uid,
					defId: t.defId,
					rid: t.rid,
					hp: t.hp,
					maxHp: n.hp,
					focus: t.focus,
					maxFocus: n.focus,
					pos: t.pos,
					knocked: t.knocked,
					loot: [...t.loot],
					spellCount: t.spells.length,
					trapped: i?.k === "trap" && !r.trapDisarmed,
					speedLeft: t.speedLeft,
					actionsLeft: +!t.heroActionUsed + t.extraActions,
					onlyMove: t.onlyMove,
					roomActionUsed: t.roomActionUsed,
					explored: t.explored,
					abilityUsed: [...t.abilityUsed]
				};
			}),
			turn: n,
			turnSeq: e.turnSeq,
			goblins: e.goblins.map((e) => ({
				uid: e.uid,
				defId: e.defId,
				pos: e.pos
			})),
			goblinSlots: e.goblins.length,
			minions: e.minions.filter((e) => !e.dead).map((e) => ({
				uid: e.uid,
				defId: e.defId,
				pos: e.pos,
				hp: e.hp,
				maxHp: Fe(e.defId).hp
			})),
			boss: e.boss && e.act === 2 ? {
				defId: e.boss.defId,
				markers: [...e.boss.markers],
				altarsCovered: [...e.boss.altarsCovered],
				pos: e.boss.pos
			} : e.boss ? {
				defId: e.boss.defId,
				markers: [],
				altarsCovered: [],
				pos: e.boss.pos
			} : null,
			pendingRoll: e.pendingRoll ? {
				forUid: e.pendingRoll.forUid,
				dice: [...e.pendingRoll.dice],
				enemyDie: e.pendingRoll.enemyDie,
				need: e.pendingRoll.need,
				label: e.pendingRoll.label
			} : null,
			choice: e.choice ? {
				kind: e.choice.kind,
				forUid: e.choice.forUid,
				options: [...e.choice.options]
			} : null,
			deckCount: e.deck.length,
			lostReason: e.lostReason,
			lairOpen: e.minions.length >= e.heroCount && e.minions.every((e) => e.dead),
			picked: Object.values(e.heroes).map((e) => e.defId),
			pickRid: e.phase === "pick" ? e.players[e.pickIdx % e.players.length] ?? null : null,
			log: [...e.log]
		},
		private: {
			spells: Object.values(e.heroes).filter((e) => e.rid === t).flatMap((e) => e.spells),
			myTurnUid: r && r.rid === t ? r.uid : null
		}
	};
}
function Pt(e) {
	return e.phase === "won" ? {
		phase: "done",
		winner: [...e.players],
		ranking: [...e.players]
	} : e.phase === "lost" ? {
		phase: "done",
		winner: [],
		ranking: [...e.players]
	} : { phase: e.phase };
}
function Ft(e) {
	return e.phase === "enemyAct" && e.beatMs > 0 ? e.beatMs : null;
}
var It = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: he,
	schemas: {
		action: _e,
		publicView: Te,
		privateView: Ee,
		config: ve
	},
	setup: vt,
	reduce: yt,
	viewFor: Nt,
	status: Pt,
	nextTickIn: Ft
}, Lt = {
	ethairna: "🧝‍♀️",
	lannon: "🛡️",
	gerrund: "🧙",
	thordin: "⛏️",
	grokull: "🪓",
	uliessa: "📿",
	moonblade: "🗡️",
	wyn: "🏹"
}, Rt = {
	boomy: "💣",
	mighty: "🦾",
	pokey: "🔱",
	spelly: "🪄",
	shooty: "🏹",
	stabby: "🔪",
	serpent: "🐍",
	crawler: "🕷️",
	ogre: "👹",
	troglodyte: "🦎",
	troll: "🧌",
	minotaur: "🐂",
	skeleton: "💀",
	ooze: "🫧",
	dragon: "🐉",
	goblinking: "👑",
	gorgon: "🎭",
	hydra: "🐲",
	pharaoh: "🏺",
	seer: "🔮"
}, zt = {
	lairdoor: "😈",
	web: "🕸️",
	bridge: "🌉",
	firevortex: "🔥",
	spikedlog: "🪵",
	spikepit: "🕳️",
	brambles: "🌿",
	buzzsaw: "🪚",
	lockedchest: "🧰",
	jeweledchest: "💎",
	pharaohstomb: "⚰️",
	vault: "🏦",
	goblinbunks: "🛏️",
	armory: "⚔️",
	cauldron: "🍲",
	arcanealtar: "⛩️",
	library: "📚",
	graveyard: "🪦",
	pulley: "⚙️",
	well: "🪣",
	feasthall: "🍖",
	stairsnowhere: "🪜",
	portal: "🌀",
	minion1: "👿",
	minion2: "👿",
	minion3: "👿",
	minion4: "👿",
	entrance: "🚪"
}, Bt = {
	str: "💪",
	agi: "🎯",
	int: "🧠",
	any: "❔"
}, Vt = [
	"+1",
	"+2⚡3",
	"⚡2",
	"⚡1",
	"⚡1",
	"❤1"
], Ht = {
	plain: "",
	goblin: "👺",
	enemy: "⚔️",
	skull: "💀"
}, Ut = {
	goblinReward: "games.ted.choiceGoblinReward",
	discover: "games.ted.choiceDiscover",
	minionReward: "games.ted.choiceMinionReward",
	pharaohTorch: "games.ted.choicePharaoh",
	oozeDiscard: "games.ted.choiceOoze",
	pulleyKill: "games.ted.choicePulley",
	warhorn: "games.ted.choiceWarhorn"
}, Wt = {
	research: "games.ted.abilityResearch",
	healingHands: "games.ted.abilityHealingHands",
	shieldBash: "games.ted.abilityShieldBash",
	sprint: "games.ted.abilitySprint",
	lockpick: "games.ted.abilityLockpick",
	stealth: "games.ted.abilityStealth",
	seekingBolt: "games.ted.abilitySeekingBolt",
	divineMight: "games.ted.abilityDivineMight",
	shadowWalk: "games.ted.abilityShadowWalk"
}, Gt = (e) => [Number(e.split(",")[0]), Number(e.split(",")[1])], Kt = (e) => e.startsWith("L"), qt = 88, Jt = 96, Yt = [
	"U",
	"R",
	"D",
	"L"
];
function Xt(e, t) {
	let n = A.find((t) => t.id === e);
	return n ? n.doors.map((e) => Yt[(Yt.indexOf(e) + t) % 4]) : [];
}
var Zt = {
	U: "top-0 left-1/2 h-[5px] w-6 -translate-x-1/2 -translate-y-1/2",
	D: "bottom-0 left-1/2 h-[5px] w-6 -translate-x-1/2 translate-y-1/2",
	L: "top-1/2 left-0 h-6 w-[5px] -translate-x-1/2 -translate-y-1/2",
	R: "top-1/2 right-0 h-6 w-[5px] translate-x-1/2 -translate-y-1/2"
};
function Qt(e) {
	return /* @__PURE__ */ v(gn, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function $t({ def: e, taken: t, mine: n, onPick: r }) {
	let i = d();
	return /* @__PURE__ */ y("button", {
		type: "button",
		disabled: t,
		onClick: r,
		className: `ted-hero-card card flex min-h-11 flex-col gap-1.5 p-3 text-left ${t ? n ? "ring-3 ring-sky-400" : "opacity-40 grayscale" : "active:translate-y-0.5"}`,
		children: [
			/* @__PURE__ */ y("span", {
				className: "ted-hero-heading flex items-center gap-2",
				children: [/* @__PURE__ */ v("span", {
					className: "ted-hero-portrait text-4xl",
					children: Lt[e.id]
				}), /* @__PURE__ */ y("span", {
					className: "flex min-w-0 flex-col",
					children: [/* @__PURE__ */ v("span", {
						className: "ted-hero-name truncate text-base font-extrabold",
						children: e.name
					}), /* @__PURE__ */ v("span", {
						className: "ted-hero-title truncate text-xs opacity-60",
						children: e.title
					})]
				})]
			}),
			/* @__PURE__ */ y("span", {
				className: "ted-hero-stats grid grid-cols-4 rounded-md bg-paper/70 px-1 py-1 text-center font-mono text-sm font-bold tabular-nums",
				children: [
					/* @__PURE__ */ y("span", { children: ["❤", e.hp] }),
					/* @__PURE__ */ y("span", { children: ["⚡", e.focus] }),
					/* @__PURE__ */ y("span", { children: ["👟", e.speed] }),
					/* @__PURE__ */ y("span", { children: ["🛡", e.defense] })
				]
			}),
			/* @__PURE__ */ y("span", {
				className: "ted-hero-skills font-mono text-xs tabular-nums opacity-70",
				children: [
					Bt.str,
					e.str,
					" ",
					Bt.agi,
					e.agi,
					" ",
					Bt.int,
					e.int
				]
			}),
			/* @__PURE__ */ v("span", {
				className: "ted-hero-abilities flex flex-col text-xs leading-snug opacity-80",
				children: e.abilities.map((e, t) => /* @__PURE__ */ v("span", { children: e.k === "weapon" ? `⚔️ ${e.name}` : `✦ ${i(Wt[e.k] ?? "games.ted.abilityStealth")}` }, t))
			})
		]
	});
}
function en({ act: e, torch: t }) {
	let n = e === 1 ? le : ue, { ref: r } = c("torch");
	return /* @__PURE__ */ v("div", {
		ref: r,
		className: "ted-torch frame flex items-center gap-0.5 overflow-x-auto px-1.5 py-1",
		children: n.map((e, n) => /* @__PURE__ */ v("span", {
			className: `ted-torch-step grid size-6 flex-none place-items-center rounded-md border text-[11px] ${n === t ? "border-ink bg-amber-300 shadow-[1px_1px_0_var(--color-ink)]" : n < t ? "border-ink/20 opacity-35" : "border-ink/30 bg-surface"}`,
			children: n === t ? "🔥" : Ht[e]
		}, n))
	});
}
function tn({ coord: e, pub: t, myTurnUid: n, selMode: r, colorOf: i }) {
	let a = t.grid[e], { ref: o } = c(`room:${e}`);
	if (!a) return null;
	let [s, l] = Gt(e), u = t.heroes.filter((t) => t.pos === e), d = t.goblins.filter((t) => t.pos === e), f = t.minions.filter((t) => t.pos === e), p = t.boss && t.boss.pos === e, m = r !== null && n !== null, h = a.faceUp && a.roomId ? A.find((e) => e.id === a.roomId) : null, g = a.faceUp && a.roomId ? Xt(a.roomId, a.rot) : [], _ = u.length > 0 || d.length > 0 || f.length > 0 || !!p;
	return /* @__PURE__ */ y("div", {
		ref: o,
		className: "absolute",
		style: {
			left: (s + 3) * Jt,
			top: (l + 3) * Jt,
			width: qt,
			height: qt
		},
		children: [
			/* @__PURE__ */ y("button", {
				type: "button",
				disabled: !m,
				"aria-label": h?.name ?? e,
				className: `flex h-full w-full flex-col items-center justify-center rounded-lg border-2 px-0.5 leading-none ${_ ? "pb-5" : ""} ${a.faceUp ? `border-ink bg-surface shadow-[2px_2px_0_var(--color-ink)] ${m ? "ring-2 ring-sky-300 active:translate-y-0.5" : ""}` : "border-dashed border-ink/50 bg-paper/70"}`,
				children: [
					/* @__PURE__ */ v("span", {
						className: a.faceUp ? "text-3xl" : "text-2xl",
						children: a.faceUp ? zt[a.roomId] : "❔"
					}),
					h && /* @__PURE__ */ v("span", {
						className: "mt-1 w-full truncate text-center text-xs font-bold",
						children: h.name
					}),
					a.altar && /* @__PURE__ */ v("span", {
						className: "absolute top-0 right-0 text-[10px]",
						children: "🕯️"
					}),
					a.trap && /* @__PURE__ */ v("span", {
						className: "absolute top-0 left-0 text-[10px]",
						children: "⚠️"
					})
				]
			}),
			g.map((e) => /* @__PURE__ */ v("span", { className: `pointer-events-none absolute rounded-full bg-ink/35 ${Zt[e]}` }, e)),
			(u.length > 0 || d.length > 0 || f.length > 0 || p) && /* @__PURE__ */ y("span", {
				className: "pointer-events-none absolute inset-x-0.5 bottom-0.5 flex flex-wrap justify-center gap-0.5",
				children: [
					u.map((e) => /* @__PURE__ */ v(rn, {
						uid: e.uid,
						emoji: Lt[e.defId],
						color: i(e.rid),
						knocked: e.knocked,
						active: e.uid === t.turn
					}, e.uid)),
					d.map((e) => /* @__PURE__ */ v(an, {
						uid: e.uid,
						emoji: Rt[e.defId]
					}, e.uid)),
					f.map((e) => /* @__PURE__ */ v(an, {
						uid: e.uid,
						emoji: Rt[e.defId],
						hp: e.hp
					}, e.uid)),
					p && /* @__PURE__ */ v(an, {
						uid: "boss",
						emoji: Rt[t.boss.defId]
					})
				]
			})
		]
	});
}
function nn({ pub: e, myTurnUid: t, selMode: n, onTap: i, colorOf: s }) {
	let c = a(null), [l, u] = o({
		w: 0,
		h: 0,
		fitMax: 1.2
	}), [d, f] = o(null), p = a({
		cx: 0,
		cy: 0,
		s: 1
	});
	r(() => {
		let e = c.current, t = new ResizeObserver(() => u({
			w: e.clientWidth,
			h: e.clientHeight,
			fitMax: Number(getComputedStyle(e).getPropertyValue("--ted-fit-max")) || 1.2
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let m = Object.keys(e.grid).filter((e) => !Kt(e)), [h, g] = o(!1);
	if (!h && l.w > 0 && m.length > 0) {
		let e = m.map((e) => (Gt(e)[0] + 3) * Jt), t = m.map((e) => (Gt(e)[1] + 3) * Jt), n = Math.min(...e) - 12, r = Math.max(...e) + qt + 12, i = Math.min(...t) - 12, a = Math.max(...t) + qt + 12, o = Math.min(l.w / (r - n), l.h / (a - i), l.fitMax);
		g(!0), f({
			cx: (n + r) / 2,
			cy: (i + a) / 2,
			s: o
		});
	}
	let _ = d ?? {
		cx: 3 * Jt + qt / 2,
		cy: 3 * Jt + qt / 2,
		s: 1
	};
	r(() => {
		p.current = _;
	}), r(() => {
		let e = c.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = p.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.min(Math.max(r.s * i, .35), 2.5), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			p.current = u, f(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let y = a(/* @__PURE__ */ new Map()), b = a(0), x = a(0), S = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), y.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), y.current.size === 1 && (b.current = 0), y.current.size === 2) {
			let [e, t] = [...y.current.values()];
			x.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, C = (e) => {
		let t = y.current.get(e.pointerId);
		if (!t) return;
		let n = c.current.getBoundingClientRect();
		if (y.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			b.current += Math.abs(n) + Math.abs(r);
			let i = p.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			p.current = a, f(a);
		} else if (y.current.size === 2) {
			y.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...y.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (x.current > 0 && i > 0) {
				let e = p.current, a = Math.min(Math.max(e.s * i / x.current, .35), 2.5), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				p.current = u, f(u);
			}
			x.current = i, b.current = 99;
			return;
		}
		y.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, w = (e) => {
		let r = y.current.size === 1 && b.current < 10;
		if (y.current.delete(e.pointerId), x.current = 0, !r || t === null || n === null) return;
		let a = c.current.getBoundingClientRect(), o = p.current, s = o.cx + (e.clientX - a.left - a.width / 2) / o.s, l = o.cy + (e.clientY - a.top - a.height / 2) / o.s;
		for (let e of m) {
			let [t, n] = Gt(e), r = (t + 3) * Jt, a = (n + 3) * Jt;
			if (s >= r && s < r + qt && l >= a && l < a + qt) {
				i(e);
				return;
			}
		}
	};
	return /* @__PURE__ */ v("div", {
		ref: c,
		className: "ted-map frame relative min-h-0 flex-1 touch-none overflow-hidden select-none",
		onPointerDown: S,
		onPointerMove: C,
		onPointerUp: w,
		onPointerCancel: w,
		children: /* @__PURE__ */ v("div", {
			className: "absolute top-0 left-0",
			style: {
				transform: `translate(${l.w / 2 - _.cx * _.s}px, ${l.h / 2 - _.cy * _.s}px) scale(${_.s})`,
				transformOrigin: "0 0"
			},
			children: m.map((r) => /* @__PURE__ */ v(tn, {
				coord: r,
				pub: e,
				myTurnUid: t,
				selMode: n,
				colorOf: s
			}, r))
		})
	});
}
function rn({ uid: e, emoji: t, color: n, knocked: r, active: i }) {
	let { ref: a } = c(`hero:${e}`);
	return /* @__PURE__ */ v("span", {
		ref: a,
		style: n ? { backgroundColor: n } : void 0,
		className: `grid size-5 place-items-center rounded-full border border-ink text-[13px] leading-none ${n ? "" : "bg-surface"} ${i ? "ring-2 ring-amber-400" : ""} ${r ? "opacity-40 grayscale" : ""}`,
		children: t
	});
}
function an({ uid: e, emoji: t, hp: n }) {
	let { ref: r } = c(`enemy:${e}`);
	return /* @__PURE__ */ y("span", {
		ref: r,
		className: "relative grid size-5 place-items-center rounded-full border border-ink bg-rose-500 text-[13px] leading-none",
		children: [t, n !== void 0 && /* @__PURE__ */ v("span", {
			className: "absolute -top-1.5 -right-1.5 grid min-w-4 place-items-center rounded-full border border-ink bg-surface px-0.5 font-mono text-[10px] font-bold leading-none",
			children: n
		})]
	});
}
function on({ pub: e, myTurnUid: t, selMode: n, onTap: r, colorOf: i }) {
	let a = d(), { ref: o } = c("bossmat"), s = e.boss;
	if (!s || e.act !== 2) return null;
	let l = O.find((e) => e.id === s.defId);
	return /* @__PURE__ */ y("div", {
		ref: o,
		className: "ted-boss frame flex flex-col gap-1 p-1.5",
		children: [/* @__PURE__ */ y("div", {
			className: "flex items-center justify-between gap-2 px-0.5",
			children: [/* @__PURE__ */ y("span", {
				className: "ted-boss-title text-xs font-extrabold",
				children: [
					Rt[s.defId],
					" ",
					l?.name
				]
			}), /* @__PURE__ */ y("span", {
				className: "ted-boss-life flex items-center gap-0.5 font-mono text-xs tabular-nums",
				children: [s.markers.map((e, t) => /* @__PURE__ */ v("span", {
					className: "grid size-5 place-items-center rounded border border-ink bg-rose-500 text-[10px] font-bold text-white",
					children: e
				}, t)), s.markers.length === 0 && /* @__PURE__ */ v("span", { children: "💀" })]
			})]
		}), /* @__PURE__ */ v("div", {
			className: "ted-boss-spaces grid grid-cols-6 gap-1",
			children: l.spaces.map((o, c) => {
				let l = `L${c}`, u = e.heroes.filter((e) => e.pos === l), d = s.pos === l && !s.markers.includes(-1);
				return /* @__PURE__ */ y("button", {
					type: "button",
					disabled: n !== "move" || t === null,
					onClick: () => r(l),
					className: `ted-boss-space relative grid aspect-square place-items-center rounded-lg border-2 border-ink bg-surface text-sm shadow-[1px_1px_0_var(--color-ink)] ${o.entrance ? "bg-amber-100" : ""} ${n === "move" && t ? "ring-2 ring-sky-300" : ""}`,
					"aria-label": a("games.ted.bossSpace", { n: c + 1 }),
					children: [
						d && /* @__PURE__ */ v(an, {
							uid: "boss",
							emoji: Rt[s.defId]
						}),
						u.map((t) => /* @__PURE__ */ v(rn, {
							uid: t.uid,
							emoji: Lt[t.defId],
							color: i(t.rid),
							knocked: t.knocked,
							active: t.uid === e.turn
						}, t.uid)),
						o.entrance && /* @__PURE__ */ v("span", {
							className: "absolute bottom-0 right-0 text-[9px]",
							children: "🚪"
						})
					]
				}, c);
			})
		})]
	});
}
var sn = (e) => T.find((t) => t.id === e)?.name ?? e, cn = (e) => E.find((t) => t.id === e)?.name ?? D.find((t) => t.id === e)?.name ?? O.find((t) => t.id === e)?.name ?? e, ln = (e) => ae.find((t) => t.id === e)?.name ?? k.find((t) => t.id === e)?.name ?? e, un = {
	torch: "games.ted.lostTorch",
	goblins: "games.ted.lostGoblins",
	deadend: "games.ted.lostDeadend"
};
function dn(e, t) {
	switch (t.k) {
		case "pick": return e("games.ted.logPick", { name: sn(t.uid) });
		case "reveal": return e("games.ted.logReveal", { room: A.find((e) => e.id === t.roomId)?.name ?? t.roomId });
		case "spawn": return e(t.enemy === "goblin" ? "games.ted.logSpawnGoblin" : "games.ted.logSpawnMinion", { name: cn(t.defId) });
		case "roll": return e(t.success ? "games.ted.logRollOk" : "games.ted.logRollFail", {
			name: sn(t.uid),
			label: e(t.label),
			total: t.total,
			need: t.need
		});
		case "hitEnemy": return e(t.killed ? "games.ted.logKill" : "games.ted.logHit", {
			name: sn(t.uid),
			enemy: cn(t.defId),
			dmg: t.dmg
		});
		case "counter": return e(t.dmg > 0 ? "games.ted.logCounter" : "games.ted.logCounterBlocked", {
			enemy: cn(t.defId),
			name: sn(t.uid),
			dmg: t.dmg
		});
		case "enemyHit": return e("games.ted.logEnemyHit", {
			enemy: cn(t.defId),
			name: sn(t.uid),
			dmg: t.dmg
		});
		case "knocked": return e("games.ted.logKnocked", { name: sn(t.uid) });
		case "rest": return e("games.ted.logRest", { name: sn(t.uid) });
		case "gain": return e("games.ted.logGain", {
			name: sn(t.uid),
			item: ln(t.item)
		});
		case "enterLair": return e("games.ted.logEnterLair", { name: sn(t.uid) });
		case "act2": return e("games.ted.logAct2");
		case "bossHit": return e("games.ted.logBossHit", { dmg: t.dmg });
		case "won": return e("games.ted.logWon");
		case "lost": return e(un[t.reason] ?? "games.ted.lost");
		default: return "";
	}
}
function fn({ log: e, children: t }) {
	let n = d(), i = a(null), o = a(!0);
	return r(() => {
		let e = i.current, t = e && getComputedStyle(e).display === "contents" ? e.querySelector(".ted-log") : e;
		t && o.current && (t.scrollTop = t.scrollHeight);
	}, [e.length]), /* @__PURE__ */ y("div", {
		ref: i,
		className: "ted-rail",
		onScrollCapture: (e) => {
			let t = e.target;
			o.current = t.scrollHeight - t.scrollTop - t.clientHeight < 8;
		},
		children: [t, /* @__PURE__ */ v("div", {
			"aria-label": n("games.ted.logAria"),
			className: "ted-log frame h-14 flex-none overflow-y-auto px-2 py-1",
			children: e.map((e, t) => /* @__PURE__ */ v("div", {
				className: "ted-log-line text-[11px] leading-snug",
				children: dn(n, e)
			}, t))
		})]
	});
}
function pn({ pub: e, me: t, send: n }) {
	let r = d(), i = e.pendingRoll, [a, c] = o(0), [l, u] = o([]), [f, p] = o([]), [m, h] = o(i);
	i !== null && i !== m && h(i);
	let g = i ?? m, _ = g ? `${g.label}|${g.dice.join(",")}` : "", [b, x] = o(_);
	if (b !== _ && (x(_), c(0), u([]), p([])), !g) return null;
	let S = e.heroes.find((e) => e.uid === g.forUid), C = S?.rid === t, w = [...g.dice];
	for (let e of l) w[e.die] += e.dir;
	let ee = l.length * 2 + f.reduce((e, t) => e + (t === "battleRage" ? 3 : t === "lionPump" || t === "stoneStance" || t === "clericHeal" ? 2 : 0), 0), te = S?.focus ?? 0, ne = (e, t) => {
		let n = w[e] + t;
		n < 1 || n > 6 || u([...l, {
			die: e,
			dir: t
		}]);
	}, re = (e, t = !1) => {
		if (t) {
			p([...f, e]);
			return;
		}
		p(f.includes(e) ? f.filter((t) => t !== e) : [...f, e]);
	}, E = S ? (T.find((e) => e.id === S.defId)?.abilities ?? []).map((e) => e.k) : [], D = S?.loot ?? [], O = (e) => D.some((t) => ae.find((e) => e.id === t)?.effects.some((t) => t.k === e)), ie = E.includes("battleRage"), k = E.includes("stoneStance"), A = O("lionSwordPump"), oe = O("meleeReroll"), se = E.includes("clericHeal");
	return /* @__PURE__ */ y(s, {
		open: i !== null,
		label: r("games.ted.rollAria"),
		children: [
			/* @__PURE__ */ y("span", {
				className: "text-xs font-extrabold opacity-70",
				children: [
					r(g.label),
					" · ",
					r("games.ted.rollNeed", { n: g.need })
				]
			}),
			/* @__PURE__ */ y("div", {
				className: "flex items-center justify-center gap-2",
				children: [w.map((e, t) => /* @__PURE__ */ y("div", {
					className: "flex flex-col items-center gap-0.5",
					children: [
						/* @__PURE__ */ v("button", {
							type: "button",
							disabled: !C,
							onClick: () => c(t),
							className: `grid size-11 place-items-center rounded-xl border-2 border-ink font-mono text-lg font-extrabold tabular-nums shadow-[2px_2px_0_var(--color-ink)] ${t === a ? "bg-amber-300" : "bg-surface"}`,
							children: e
						}),
						/* @__PURE__ */ v("span", {
							className: "font-mono text-[9px] opacity-60",
							children: t === a ? "=" : Vt[g.dice[t] - 1]
						}),
						C && /* @__PURE__ */ y("span", {
							className: "flex gap-0.5",
							children: [/* @__PURE__ */ v("button", {
								type: "button",
								"aria-label": "-",
								className: "grid size-5 place-items-center rounded border border-ink bg-surface text-[10px] font-bold disabled:opacity-30",
								disabled: w[t] <= 1 || ee + 2 > te,
								onClick: () => ne(t, -1),
								children: "-"
							}), /* @__PURE__ */ v("button", {
								type: "button",
								"aria-label": "+",
								className: "grid size-5 place-items-center rounded border border-ink bg-surface text-[10px] font-bold disabled:opacity-30",
								disabled: w[t] >= 6 || ee + 2 > te,
								onClick: () => ne(t, 1),
								children: "+"
							})]
						})
					]
				}, t)), g.enemyDie !== null && /* @__PURE__ */ v("span", {
					className: "ml-2 grid size-11 place-items-center rounded-xl border-2 border-rose-600 bg-rose-100 font-mono text-lg font-extrabold tabular-nums",
					children: g.enemyDie
				})]
			}),
			C && (ie || k || A || oe || se) && /* @__PURE__ */ y("div", {
				className: "flex flex-wrap justify-center gap-1",
				children: [
					ie && /* @__PURE__ */ v(mn, {
						on: f.includes("battleRage"),
						label: r("games.ted.boostRage"),
						onClick: () => re("battleRage")
					}),
					k && /* @__PURE__ */ v(mn, {
						on: f.includes("stoneStance"),
						label: r("games.ted.boostStance"),
						onClick: () => re("stoneStance")
					}),
					A && /* @__PURE__ */ v(mn, {
						on: f.includes("lionPump"),
						label: r("games.ted.boostPump"),
						onClick: () => re("lionPump", !0)
					}),
					oe && g.dice.map((e, t) => /* @__PURE__ */ v(mn, {
						on: f.includes(`reroll${t}`),
						label: r("games.ted.boostReroll", { n: t + 1 }),
						onClick: () => p([...f.filter((e) => !e.startsWith("reroll")), `reroll${t}`])
					}, t)),
					se && /* @__PURE__ */ v(mn, {
						on: f.includes("clericHeal"),
						label: r("games.ted.boostCleric"),
						onClick: () => re("clericHeal")
					})
				]
			}),
			C && /* @__PURE__ */ y("button", {
				type: "button",
				disabled: ee > te,
				className: "btn-base min-h-12 w-full text-base text-white disabled:opacity-40",
				style: { background: he.accent },
				onClick: () => n({
					type: "resolveRoll",
					dieIdx: a,
					nudges: l,
					boosts: f
				}),
				children: [r("games.ted.rollConfirm"), ee > 0 ? ` (-${ee}⚡)` : ""]
			})
		]
	});
}
function mn({ on: e, label: t, onClick: n }) {
	return /* @__PURE__ */ v("button", {
		type: "button",
		onClick: n,
		className: `min-h-11 rounded-lg border-2 border-ink px-2 text-xs font-bold shadow-[1px_1px_0_var(--color-ink)] ${e ? "bg-amber-300" : "bg-surface"}`,
		children: t
	});
}
function hn({ pub: e, myRid: t, send: n }) {
	let r = d(), i = e.choice, [a, c] = o(i);
	i !== null && i.kind !== "warhorn" && i !== a && c(i);
	let l = i ?? a;
	if (!l || l.kind === "warhorn") return null;
	let u = e.heroes.find((e) => e.uid === l.forUid)?.rid === t, f = (t) => {
		if (t === "deck") return r("games.ted.optDeck");
		if (t === "loot") return r("games.ted.optLoot");
		if (t === "spell") return r("games.ted.optSpell");
		if (t === "reveal") return r("games.ted.optReveal");
		if (t === "focus3") return r("games.ted.optFocus3");
		if (t === "skip") return r("games.ted.optSkip");
		if (t.startsWith("hp:")) return r("games.ted.optHp", { n: t.slice(3) });
		if (t.startsWith("focus:")) return r("games.ted.optFocus", { n: t.slice(6) });
		if (t.startsWith("discard:")) {
			let e = t.slice(8);
			return ae.find((t) => t.id === e)?.name ?? k.find((t) => t.id === e)?.name ?? e;
		}
		let n = e.goblins.find((e) => e.uid === t);
		return n ? `${Rt[n.defId]} ${E.find((e) => e.id === n.defId)?.name}` : t;
	};
	return /* @__PURE__ */ y(s, {
		open: i !== null && i.kind !== "warhorn",
		label: r("games.ted.choiceAria"),
		children: [/* @__PURE__ */ v("span", {
			className: "text-xs font-extrabold opacity-70",
			children: r(u ? Ut[l.kind] ?? "games.ted.choiceDiscover" : "games.ted.choiceWait")
		}), /* @__PURE__ */ v("div", {
			className: "flex flex-wrap gap-1.5",
			children: l.options.map((e) => /* @__PURE__ */ v("button", {
				type: "button",
				disabled: !u,
				onClick: () => n({
					type: "choose",
					option: e
				}),
				className: "btn-quiet min-h-11 px-3 text-sm font-bold disabled:opacity-40",
				children: f(e)
			}, e))
		})]
	});
}
function gn({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let a = d(), [s, c] = o(null), u = e.phase === "won" || e.phase === "lost" ? null : t?.myTurnUid ?? null, g = u ? e.heroes.find((e) => e.uid === u) : null, b = g ? T.find((e) => e.id === g.defId) : null, x = e.choice?.kind === "warhorn" && e.heroes.find((t) => t.uid === e.choice?.forUid)?.rid === r, S = `${e.phase}|${e.turn}|${e.pendingRoll?.label ?? ""}|${e.choice?.kind ?? ""}`, [C, w] = o(S);
	if (C !== S && (w(S), c(null)), e.phase === "pick") {
		let t = e.pickRid === r;
		return /* @__PURE__ */ v(p, {
			adaptive: !0,
			className: "ted-screen ted-pick-screen",
			scroll: !1,
			banner: /* @__PURE__ */ v(m, {
				tone: "accent",
				text: a("games.ted.bannerPick"),
				accent: he.accent
			}),
			children: /* @__PURE__ */ v("div", {
				className: "ted-pick-grid grid h-full min-h-0 grid-cols-2 content-start gap-2 overflow-y-auto p-1",
				children: T.map((n) => /* @__PURE__ */ v($t, {
					def: n,
					taken: e.picked.includes(n.id),
					mine: !1,
					onPick: () => {
						t && i({
							type: "pickHero",
							heroId: n.id
						});
					}
				}, n.id))
			})
		});
	}
	let ee = (e) => {
		if (g) {
			if (x) {
				i({
					type: "choose",
					option: e
				});
				return;
			}
			if (s?.k === "castCoord") {
				i({
					type: "cast",
					spellId: s.spellId,
					coord: e
				});
				return;
			}
			if (s?.k === "roomTeleport") {
				i({
					type: "roomAction",
					coord: e
				});
				return;
			}
			(s?.k === "move" || s === null) && i({
				type: "move",
				path: [e]
			});
		}
	}, te = (e) => {
		g && s && (s.k === "attack" ? i({
			type: "attack",
			targetUid: e,
			weaponIdx: s.weaponIdx
		}) : s.k === "cast" && i({
			type: "cast",
			spellId: s.spellId,
			targetUids: [e]
		}));
	}, ne = s?.k === "attack" || s?.k === "cast" ? [
		...e.goblins,
		...e.minions,
		...e.boss && e.act === 2 ? [{
			uid: "boss",
			defId: e.boss.defId,
			pos: e.boss.pos
		}] : []
	] : [], re = t?.spells ?? [], E = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? f[t.colorIndex % f.length].hex : void 0;
	}, D, O;
	return e.phase === "roll" ? (D = "accent", O = a(e.pendingRoll.label)) : e.phase === "enemyAct" ? (D = "warn", O = a("games.ted.bannerEnemy")) : u ? (D = "accent", O = a("games.ted.bannerYou")) : (D = "info", O = a("games.ted.bannerWait")), /* @__PURE__ */ y(_, { children: [
		/* @__PURE__ */ v(p, {
			adaptive: !0,
			className: "ted-screen",
			scroll: !1,
			banner: /* @__PURE__ */ y("div", {
				className: "ted-banner",
				children: [
					/* @__PURE__ */ v(m, {
						tone: D,
						text: O,
						chip: `Act ${e.act} · 🃏${e.deckCount}`,
						accent: he.accent
					}),
					/* @__PURE__ */ v(en, {
						act: e.act,
						torch: e.torch
					}),
					/* @__PURE__ */ v("div", {
						className: "ted-players",
						children: /* @__PURE__ */ v(h, {
							variant: "plate",
							members: n,
							myRid: r,
							anchorOf: (e) => `seat:${e}`,
							action: (t) => {
								let n = e.heroes.filter((e) => e.rid === t);
								return n.length === 0 ? null : n.some((t) => t.uid === e.turn) ? "pending" : null;
							},
							status: (t) => {
								let n = e.heroes.filter((e) => e.rid === t);
								return n.length === 0 ? null : /* @__PURE__ */ v("span", {
									className: "ted-hero-status flex flex-wrap gap-x-2 font-mono text-xs font-bold tabular-nums",
									children: n.map((e) => /* @__PURE__ */ y("span", { children: [
										Lt[e.defId],
										e.knocked ? "💫" : "",
										"❤️",
										/* @__PURE__ */ v(l, { value: e.hp }),
										/* @__PURE__ */ y("span", {
											className: "opacity-50",
											children: ["/", e.maxHp]
										}),
										" ⚡",
										/* @__PURE__ */ v(l, { value: e.focus })
									] }, e.uid))
								});
							}
						})
					})
				]
			}),
			actionsHeight: "h-28 short:h-24",
			actions: /* @__PURE__ */ v("div", {
				className: "ted-actions safe-b",
				children: /* @__PURE__ */ y("div", {
					className: "ted-action-stack",
					children: [
						ne.length > 0 && /* @__PURE__ */ y("div", {
							className: "ted-targets frame flex flex-none flex-wrap items-center gap-1.5 p-1.5",
							children: [
								/* @__PURE__ */ v("span", {
									className: "text-xs font-bold opacity-60",
									children: a("games.ted.pickTarget")
								}),
								ne.map((e) => /* @__PURE__ */ v("button", {
									type: "button",
									onClick: () => te(e.uid),
									className: "btn-quiet grid min-h-11 min-w-11 place-items-center text-xl",
									"aria-label": cn(e.defId),
									children: Rt[e.defId]
								}, e.uid)),
								/* @__PURE__ */ v("button", {
									type: "button",
									onClick: () => c(null),
									className: "btn-quiet min-h-11 px-3 text-xs font-bold",
									children: a("games.ted.cancel")
								})
							]
						}),
						x && /* @__PURE__ */ y("div", {
							className: "frame flex flex-none items-center justify-between gap-2 p-1.5",
							children: [/* @__PURE__ */ v("span", {
								className: "text-xs font-bold opacity-60",
								children: a("games.ted.choiceWarhorn")
							}), /* @__PURE__ */ v("button", {
								type: "button",
								onClick: () => i({
									type: "choose",
									option: "skip"
								}),
								className: "btn-quiet min-h-11 px-3 text-xs font-bold",
								children: a("games.ted.optSkip")
							})]
						}),
						u && g && b && e.phase === "play" && !e.choice && ne.length === 0 && /* @__PURE__ */ v(_n, {
							pub: e,
							hero: g,
							heroDef: b,
							selAction: s,
							setSelAction: c,
							mySpells: re,
							send: i
						})
					]
				})
			}),
			children: /* @__PURE__ */ y("div", {
				className: "ted-table",
				children: [/* @__PURE__ */ v(nn, {
					pub: e,
					myTurnUid: u,
					selMode: x ? "warhorn" : s?.k === "castCoord" || s?.k === "roomTeleport" ? "castCoord" : "move",
					onTap: ee,
					colorOf: E
				}), /* @__PURE__ */ v(fn, {
					log: e.log,
					children: /* @__PURE__ */ v(on, {
						pub: e,
						myTurnUid: u,
						selMode: s?.k === "move" ? "move" : null,
						onTap: ee,
						colorOf: E
					})
				})]
			})
		}),
		/* @__PURE__ */ v(pn, {
			pub: e,
			me: r,
			send: i
		}),
		/* @__PURE__ */ v(hn, {
			pub: e,
			myRid: r,
			send: i
		})
	] });
}
var G = "ted-action-button flex min-h-11 items-center justify-center gap-1 rounded-xl border-2 border-ink bg-surface px-2 text-xs font-bold shadow-[2px_2px_0_var(--color-ink)] active:translate-y-0.5 active:shadow-none disabled:opacity-40 disabled:shadow-none disabled:active:translate-y-0";
function _n({ pub: e, hero: t, heroDef: n, selAction: r, setSelAction: i, mySpells: a, send: o }) {
	let s = d(), c = e.grid[t.pos], l = c?.roomId ? A.find((e) => e.id === c.roomId)?.effect : null, u = R(t), f = n.abilities.map((e, t) => ({
		a: e,
		idx: t
	})).filter(({ a: e }) => e.k !== "weapon" && e.k !== "stoneStance" && e.k !== "battleRage" && e.k !== "clericHeal"), p = l && [
		"well",
		"library",
		"pulley",
		"armory",
		"feasthall",
		"teleport"
	].includes(l.k), m = l?.k === "lairDoor" && e.act === 1, h = {
		research: "🔬",
		healingHands: "🤲",
		shieldBash: "🛡️",
		sprint: "👟",
		lockpick: "🔓",
		stealth: "🫥",
		seekingBolt: "✨",
		divineMight: "⚡",
		shadowWalk: "🌫️"
	}, g = {
		research: 4,
		healingHands: 2,
		shieldBash: 5,
		sprint: 1,
		lockpick: 2,
		stealth: 2
	}, _ = [
		"seekingBolt",
		"divineMight",
		"shadowWalk"
	], b = t.onlyMove || t.actionsLeft <= 0, x = !!c?.used && (l?.k === "search" || l?.k === "graveyard"), S = l?.k === "library" || l?.k === "pulley" ? 4 : l?.k === "teleport" ? 2 : 0, C = t.onlyMove || t.roomActionUsed || t.focus < S || l?.k === "pulley" && e.goblins.length === 0;
	return /* @__PURE__ */ v("div", {
		className: "flex flex-none flex-col gap-1",
		children: /* @__PURE__ */ y("div", {
			className: "flex flex-wrap gap-1",
			children: [
				u.map((e, t) => /* @__PURE__ */ y("button", {
					type: "button",
					disabled: b,
					onClick: () => i(r?.k === "attack" && r.weaponIdx === t ? null : {
						k: "attack",
						weaponIdx: t
					}),
					className: `${G} ${r?.k === "attack" && r.weaponIdx === t ? "ring-3 ring-sky-400" : ""}`,
					children: ["⚔️ ", e.name]
				}, t)),
				(l?.k === "search" || l?.k === "graveyard" || l?.k === "arcaneAltar" || l?.k === "cauldron") && /* @__PURE__ */ y("button", {
					type: "button",
					disabled: b || x,
					className: G,
					onClick: () => o({ type: "search" }),
					children: ["🔍 ", s("games.ted.actSearch")]
				}),
				l?.k === "trap" && t.trapped && /* @__PURE__ */ y("button", {
					type: "button",
					disabled: b,
					className: G,
					onClick: () => o({ type: "disarm" }),
					children: ["🧰 ", s("games.ted.actDisarm")]
				}),
				f.map(({ a: e, idx: n }) => /* @__PURE__ */ y("button", {
					type: "button",
					disabled: t.onlyMove || t.abilityUsed.includes(n) || (_.includes(e.k) ? t.actionsLeft <= 0 : t.focus < (g[e.k] ?? 0)),
					className: G,
					onClick: () => o({
						type: "ability",
						idx: n
					}),
					children: [
						h[e.k],
						" ",
						s(Wt[e.k] ?? "games.ted.abilityStealth")
					]
				}, n)),
				a.map((e) => {
					let n = k.find((t) => t.id === e), a = n?.effect.k === "giantsStrength" || n?.effect.k === "invisibility";
					return /* @__PURE__ */ y("button", {
						type: "button",
						disabled: b || t.focus < (n?.cost ?? 0),
						className: `${G} ${(r?.k === "cast" || r?.k === "castCoord") && r.spellId === e ? "ring-3 ring-sky-400" : ""}`,
						onClick: () => i((r?.k === "cast" || r?.k === "castCoord") && r.spellId === e ? null : a ? {
							k: "castCoord",
							spellId: e
						} : {
							k: "cast",
							spellId: e
						}),
						children: ["🪄 ", n?.name]
					}, e);
				}),
				p && l?.k === "teleport" ? /* @__PURE__ */ y("button", {
					type: "button",
					disabled: C,
					className: `${G} ${r?.k === "roomTeleport" ? "ring-3 ring-sky-400" : ""}`,
					onClick: () => i(r?.k === "roomTeleport" ? null : { k: "roomTeleport" }),
					children: ["🌀 ", s("games.ted.actRoom")]
				}) : p ? /* @__PURE__ */ y("button", {
					type: "button",
					disabled: C,
					className: G,
					onClick: () => o({ type: "roomAction" }),
					children: ["🏠 ", s("games.ted.actRoom")]
				}) : null,
				m && /* @__PURE__ */ y("button", {
					type: "button",
					disabled: !e.lairOpen || t.speedLeft < 1,
					className: G,
					onClick: () => o({ type: "enterLair" }),
					children: ["😈 ", s("games.ted.actLair")]
				}),
				e.act === 2 && /* @__PURE__ */ y("button", {
					type: "button",
					disabled: t.focus < 2,
					className: G,
					onClick: () => o({ type: "taunt" }),
					children: ["📣 ", s("games.ted.actTaunt")]
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					disabled: t.onlyMove || t.explored,
					className: G,
					onClick: () => o({ type: "explore" }),
					children: ["🔦 ", s("games.ted.actExplore")]
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					disabled: t.actionsLeft <= 0,
					className: G,
					onClick: () => o({ type: "rest" }),
					children: ["💤 ", s("games.ted.actRest")]
				}),
				/* @__PURE__ */ v("button", {
					type: "button",
					className: "ted-end-turn btn-base min-h-12 flex-1 text-sm text-white",
					style: { background: he.accent },
					onClick: () => o({ type: "endTurn" }),
					children: s("games.ted.endTurn")
				})
			]
		})
	});
}
//#endregion
//#region src/games/ted/bot.ts
var vn = [
	"U",
	"R",
	"D",
	"L"
], K = {
	U: [0, -1],
	R: [1, 0],
	D: [0, 1],
	L: [-1, 0]
}, yn = {
	U: "D",
	R: "L",
	D: "U",
	L: "R"
}, q = (e) => [Number(e.split(",")[0]), Number(e.split(",")[1])], J = (e) => e.startsWith("L"), bn = (e) => T.find((t) => t.id === e), xn = (e) => ae.find((t) => t.id === e);
function Sn(e, t) {
	let n = e[t];
	if (!n?.faceUp || !n.roomId) return [];
	let r = A.find((e) => e.id === n.roomId);
	return r ? r.doors.map((e) => vn[(vn.indexOf(e) + n.rot) % 4]) : [];
}
function Cn(e, t, n) {
	let r = e[t], i = e[n];
	if (!r || !i || !r.faceUp) return !1;
	let [a, o] = q(t), [s, c] = q(n), l = vn.find((e) => a + K[e][0] === s && o + K[e][1] === c);
	return !l || !Sn(e, t).includes(l) ? !1 : !i.faceUp || Sn(e, n).includes(yn[l]);
}
function Y(e, t, n, r, i = !1) {
	if (n(t)) return [];
	let a = /* @__PURE__ */ new Map([[t, null]]), o = [t];
	for (; o.length;) {
		let s = o.shift();
		for (let c of vn) {
			let l = `${q(s)[0] + K[c][0]},${q(s)[1] + K[c][1]}`;
			if (!a.has(l) && e[l] && Cn(e, s, l) && (!r?.has(l) || !i && n(l))) {
				if (a.set(l, s), n(l)) {
					let e = [l], n = s;
					for (; n !== t;) e.unshift(n), n = a.get(n);
					return e;
				}
				e[l].faceUp && o.push(l);
			}
		}
	}
	return null;
}
function X(e, t, n) {
	if (J(t) || J(n)) return J(t) && J(n) ? Math.abs(Number(t.slice(1)) - Number(n.slice(1))) : -1;
	if (t === n) return 0;
	let r = Y(e, t, (e) => e === n);
	return r ? r.length : -1;
}
function wn(e, t, n) {
	let [r, i] = q(t), [a, o] = q(n);
	if (r !== a && i !== o) return -1;
	let s = Math.abs(r - a) + Math.abs(i - o);
	if (s === 0) return 0;
	let c = r === a ? o > i ? "D" : "U" : a > r ? "R" : "L", l = t;
	for (let t = 0; t < s; t += 1) {
		let t = `${q(l)[0] + K[c][0]},${q(l)[1] + K[c][1]}`;
		if (!Cn(e, l, t) || !e[t].faceUp) return -1;
		l = t;
	}
	return s;
}
function Tn(e, t, n, r) {
	if (J(t) || J(n)) {
		let i = X(e, t, n);
		return i > 0 && i <= r;
	}
	let i = wn(e, t, n);
	return i > 0 && i <= r;
}
function En(e, t) {
	let n = bn(e.defId), r = t === "any" ? Math.max(n.str, n.agi, n.int) : n[t];
	for (let n of e.loot) for (let e of xn(n)?.effects ?? []) e.k === "checkDie" && e.skill === t && (r += 1);
	return Math.min(3, Math.max(1, r));
}
function Dn(e, t) {
	let n = 0;
	for (let r of e.loot) for (let e of xn(r)?.effects ?? []) e.k === "checkAdd" && (e.skill === "any" || e.skill === t) && (n += e.n);
	return n;
}
function On(e, t) {
	let n = {};
	for (let t of e.loot) {
		let e = xn(t);
		e?.set && (n[e.set] = (n[e.set] ?? 0) + 1);
	}
	let r = 0;
	for (let [e, i] of Object.entries(n)) {
		let n = ie[e];
		n.kind === "add" && n.on === t && i >= 2 && (r += Math.min(3, i - 1));
	}
	return r;
}
var kn = [
	0,
	3.5,
	4.9,
	5.9
];
function Z(e, t, n) {
	return kn[En(e, t)] + Dn(e, t) + Math.min(2, Math.floor(Math.max(0, n) / 2));
}
function Q(e) {
	let t = [];
	for (let n of e.goblins) {
		let e = E.find((e) => e.id === n.defId);
		e && t.push({
			uid: n.uid,
			kind: "goblin",
			pos: n.pos,
			defense: e.defense,
			hp: 1
		});
	}
	for (let n of e.minions) {
		let e = D.find((e) => e.id === n.defId);
		e && t.push({
			uid: n.uid,
			kind: "minion",
			pos: n.pos,
			defense: e.defense,
			hp: n.hp
		});
	}
	if (e.act === 2 && e.boss?.pos) {
		let n = O.find((t) => t.id === e.boss.defId);
		n && t.push({
			uid: "boss",
			kind: "boss",
			pos: e.boss.pos,
			defense: n.defense,
			hp: 99
		});
	}
	return t;
}
function $(e) {
	let t = e.boss;
	if (!t || t.markers.length === 0) return !1;
	let n = O.find((e) => e.id === t.defId);
	if (!n) return !1;
	let r = Math.min(...t.markers) - 1;
	return n.altars.includes(r) && !t.altarsCovered.includes(r);
}
function An(e) {
	return Object.entries(e.grid).find(([, e]) => e.faceUp && e.roomId === "lairdoor")?.[0] ?? null;
}
function jn(e) {
	let t = e.boss;
	if (!t || t.markers.length === 0) return !1;
	let n = O.find((e) => e.id === t.defId);
	if (!n) return !1;
	let r = Math.min(...t.markers);
	return n.altars.some((e) => !t.altarsCovered.includes(e) && r - e >= 2 && r - e <= 4);
}
function Mn(e) {
	return Object.keys(e.grid).filter((t) => e.grid[t].altar);
}
function Nn(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let r of Q(e)) r.pos !== t && !J(r.pos) && n.add(r.pos);
	return n;
}
function Pn(e, t) {
	let n = [], r = $(e);
	return R({
		defId: t.defId,
		loot: t.loot
	}).forEach((i, a) => {
		for (let o of Q(e)) {
			if (!(i.weapon.type === "melee" ? o.pos === t.pos : Tn(e.grid, t.pos, o.pos, i.weapon.range ?? 1))) continue;
			let s = Z(t, i.weapon.skill, t.focus) + i.weapon.mod + On(t, i.weapon.type) - o.defense, c = s >= 1, l;
			if (o.kind === "goblin") {
				let t = E.find((t) => t.id === (e.goblins.find((e) => e.uid === o.uid)?.defId ?? "")), n = (t && "range" in t.action ? t.action.range : 0) + e.goblinSlots * .4, r = Kn(e) === "enemy" && e.goblinSlots >= 1 ? 4 : 0;
				l = c ? 3 + n + r + (e.goblinSlots >= 2 ? 4 : 0) : -1.2;
			} else if (o.kind === "minion") {
				if (l = c ? 1.2 + s * 1.6 + (s >= o.hp ? 8 : 0) : e.act === 1 && s > -2.5 ? 2.6 : -1.5, i.weapon.type === "melee" && s < o.hp) {
					let n = D.find((t) => t.id === (e.minions.find((e) => e.uid === o.uid)?.defId ?? ""));
					n && (14 + 5 * n.counterMelee.add) / 6 - qn(t) >= t.hp && (l = -1.5);
				}
			} else if (l = r ? -2 : c ? s * 1.7 - 1 : -2, !r && c && i.weapon.type === "melee" && e.boss) {
				let n = O.find((t) => t.id === e.boss.defId);
				(n ? (14 + 5 * n.counter.melee) / 6 - qn(t) : 0) >= t.hp && (l = -2);
			}
			n.push({
				action: {
					type: "attack",
					targetUid: o.uid,
					weaponIdx: a
				},
				score: l
			});
		}
	}), n;
}
function Fn(e, t, n) {
	let r = k.find((e) => e.id === n);
	if (!r || t.focus < r.cost) return null;
	let i = r.effect;
	if (i.k === "restAura") return null;
	let a = t.focus;
	if (e.act === 2 && e.boss) {
		let t = O.find((t) => t.id === e.boss.defId)?.counter.spell;
		typeof t == "object" && (a -= t.focusBeforeCast);
	}
	if (a < r.cost) return null;
	let o = Z(t, r.check.skill, a - r.cost);
	if (o < r.check.n - .6) return null;
	let s = Math.min(.95, Math.max(.3, .55 + (o - r.check.n) * .15)), c = Q(e), l = (n, r) => {
		let i = X(e.grid, t.pos, n.pos);
		return i >= 0 && i <= r;
	}, u = (e) => e.kind === "boss" ? 100 : e.kind === "minion" ? 50 - e.hp : 10, d, f, p;
	switch (i.k) {
		case "damage": {
			let e = c.filter((e) => l(e, i.range)).sort((e, t) => u(t) - u(e)).slice(0, i.targets);
			if (e.length === 0) return null;
			d = e.reduce((e, t) => e + (t.kind === "boss" ? i.dmg * 1.7 : t.kind === "minion" ? Math.min(i.dmg, t.hp) + (i.dmg >= t.hp ? 9 : 0) : 3), 0), f = e.map((e) => e.uid);
			break;
		}
		case "aoeDamage": {
			let e = c.filter((e) => l(e, i.range));
			if (e.length === 0) return null;
			d = e.reduce((e, t) => e + (t.kind === "boss" ? i.dmg * 1.7 : t.kind === "minion" ? Math.min(i.dmg, t.hp) + (i.dmg >= t.hp ? 9 : 0) : 3), 0);
			break;
		}
		case "tempestArrows": {
			let e = c.filter((e) => e.pos === t.pos), n = c.filter((e) => e.pos !== t.pos && l(e, 2)).sort((e, t) => u(t) - u(e))[0];
			if (e.length === 0 && !n) return null;
			d = e.reduce((e, t) => e + (t.kind === "minion" ? 1 + (t.hp <= 1 ? 9 : 0) : 3), 0) + (n ? 2 * (n.kind === "boss" ? 1.7 : 1) : 0), n && (f = [n.uid]);
			break;
		}
		case "eaglesSwiftness": {
			let n = R({
				defId: t.defId,
				loot: t.loot
			}).find((e) => e.weapon.type === "missile");
			if (!n) return null;
			let r = c.filter((r) => Tn(e.grid, t.pos, r.pos, n.weapon.range ?? 1)).sort((e, t) => u(t) - u(e))[0];
			if (!r) return null;
			d = (3 + n.weapon.mod) * (r.kind === "boss" ? 1.7 : 1) + (r.kind === "boss" ? 0 : 3), f = [r.uid];
			break;
		}
		case "healAllMax": {
			if (e.goblinSlots >= 3) return null;
			let t = e.heroes.filter((e) => l({
				uid: e.uid,
				kind: "goblin",
				pos: e.pos,
				defense: 0,
				hp: 0
			}, i.range)).reduce((e, t) => e + (t.maxHp - t.hp), 0);
			if (t < 6) return null;
			d = t * 1.2;
			break;
		}
		case "holyAbundance":
			d = e.heroes.filter((e) => l({
				uid: e.uid,
				kind: "goblin",
				pos: e.pos,
				defense: 0,
				hp: 0
			}, 4)).reduce((e, t) => e + Math.min(3, t.maxHp - t.hp) + 1.2, 0) + 2.5;
			break;
		case "extraAction":
			d = 4.5;
			break;
		case "dungeonScry":
			if (e.act === 2 || !Object.values(e.grid).some((e) => !e.faceUp)) return null;
			d = 4.5;
			break;
		case "giantsStrength": {
			let e = null, t = 0, n = new Set(c.filter((e) => !J(e.pos)).map((e) => e.pos));
			for (let r of n) {
				let n = c.filter((e) => e.pos === r).length;
				n > t && (t = n, e = r);
			}
			if (!e || t * 2 < 3) return null;
			d = t * 2 + 1, p = e;
			break;
		}
		case "invisibility": {
			let n = An(e);
			if (e.lairOpen && n && t.pos !== n && !J(t.pos)) p = n, d = 5;
			else if (e.act === 2 && $(e)) {
				let n = Mn(e)[0];
				if (!n || t.pos === n) return null;
				p = n, d = 5;
			} else return null;
			break;
		}
		default: return null;
	}
	return r.fail === "torchDown" && (d -= 1.5), r.fail === "goblinSelf" && (d -= 2.5), {
		action: {
			type: "cast",
			spellId: n,
			targetUids: f,
			coord: p
		},
		score: d * s
	};
}
function In(e, t) {
	let n = [], r = bn(t.defId), i = Q(e);
	return r.abilities.forEach((r, a) => {
		if (!t.abilityUsed.includes(a)) {
			if (r.k === "seekingBolt") {
				if (Z(t, "int", t.focus) < 4.4) return;
				let r = null, o = 0;
				for (let n of i) {
					let i = X(e.grid, t.pos, n.pos);
					if (i < 0 || i > 4) continue;
					let a = n.kind === "goblin" ? 3.5 + (Kn(e) === "enemy" ? 3 : 0) : n.kind === "minion" ? n.hp <= 1 ? 10 : 4.5 : $(e) ? 0 : 1.7;
					a > o && (o = a, r = n);
				}
				r && o >= 3 && n.push({
					action: {
						type: "ability",
						idx: a,
						targetUid: r.uid
					},
					score: o * .75
				});
				return;
			}
			if (r.k === "divineMight") {
				if (Z(t, "int", t.focus) < 3.4) return;
				let r = i.filter((e) => e.pos === t.pos).sort((t, n) => Ln(e, n) - Ln(e, t))[0];
				if (!r) return;
				let o = r.kind === "boss" ? $(e) ? 0 : 3.4 : r.kind === "minion" ? Math.min(2, r.hp) + (r.hp <= 2 ? 9 : 0) : 3.5;
				o >= 3 && n.push({
					action: {
						type: "ability",
						idx: a,
						targetUid: r.uid
					},
					score: o * .8
				});
				return;
			}
		}
	}), n;
}
function Ln(e, t) {
	return t.kind === "boss" ? 100 : t.kind === "minion" ? 50 - t.hp : 10 + e.goblinSlots;
}
function Rn(e, t) {
	if (t.onlyMove) return null;
	let n = bn(t.defId), r = Q(e);
	for (let i = 0; i < n.abilities.length; i += 1) {
		if (t.abilityUsed.includes(i)) continue;
		let a = n.abilities[i];
		if (a.k === "shieldBash" && t.focus >= 5 && e.goblinSlots >= 2 && r.some((e) => e.kind === "goblin" && e.pos === t.pos) || a.k === "lockpick" && t.focus >= 2 && t.trapped) return {
			type: "ability",
			idx: i
		};
		if (a.k === "healingHands" && t.focus >= 3) {
			let n = e.heroes.filter((n) => {
				let r = X(e.grid, t.pos, n.pos);
				return r >= 0 && r <= 1 && n.maxHp - n.hp >= 2;
			}).sort((e, t) => t.maxHp - t.hp - (e.maxHp - e.hp))[0];
			if (n) return {
				type: "ability",
				idx: i,
				targetUid: n.uid
			};
		}
		if (a.k === "research" && t.focus >= 6 && t.spellCount < 2) return {
			type: "ability",
			idx: i
		};
	}
	return null;
}
function zn(e, t) {
	if (t.roomActionUsed || t.onlyMove) return null;
	let n = e.grid[t.pos], r = n?.roomId ? A.find((e) => e.id === n.roomId)?.effect : null;
	if (!r) return null;
	let i = (e.act === 1 ? 22 : 21) - 1 - e.torch;
	switch (r.k) {
		case "well": return t.maxHp - t.hp >= 3 && i > 4 ? { type: "roomAction" } : null;
		case "feasthall": return t.focus >= 3 && t.maxHp - t.hp >= 3 && t.hp > 2 && Z(t, "int", t.focus - 3) >= 3.4 ? { type: "roomAction" } : null;
		case "library": return t.focus >= 5 && t.spellCount < 2 && En(t, "int") >= 2 ? { type: "roomAction" } : null;
		case "pulley": return t.focus >= 4 && e.goblins.length > 0 && e.goblinSlots >= 2 ? { type: "roomAction" } : null;
		case "teleport": {
			if (t.focus < 2) return null;
			let n = An(e);
			if (e.lairOpen && n && t.pos !== n && !J(t.pos)) {
				let r = X(e.grid, t.pos, n);
				if (r < 0 || r > t.speedLeft + 1) return {
					type: "roomAction",
					coord: n
				};
			}
			if (e.act === 2 && $(e)) {
				let n = Mn(e)[0];
				if (n && t.pos !== n) {
					let r = X(e.grid, t.pos, n);
					if (r < 0 || r > t.speedLeft + 1) return {
						type: "roomAction",
						coord: n
					};
				}
			}
			return null;
		}
		default: return null;
	}
}
function Bn(e, t) {
	for (let n of t.loot) {
		let r = xn(n);
		if (r) for (let i of r.effects) {
			if (i.k === "pantherVolley" && t.focus >= 3 && Q(e).filter((n) => {
				let r = X(e.grid, t.pos, n.pos);
				return r >= 0 && r <= 1;
			}).length >= 2) return {
				type: "useLoot",
				lootId: n
			};
			if (i.k === "freeTeleport" && t.focus >= 2) {
				let r = An(e);
				if (e.act === 2 && $(e)) {
					let r = Mn(e)[0];
					if (r && t.pos !== r && t.focus >= 4) {
						let i = X(e.grid, t.pos, r);
						if (i < 0 || i > t.speedLeft + 1) return {
							type: "useLoot",
							lootId: n,
							coord: r
						};
					}
				} else if (e.act === 1 && e.lairOpen && r && t.pos !== r && !J(t.pos)) {
					let i = X(e.grid, t.pos, r);
					if (i < 0 || i > t.speedLeft + 1) return {
						type: "useLoot",
						lootId: n,
						coord: r
					};
				}
			}
		}
	}
	return null;
}
function Vn(e, t, n, r = !1) {
	return Y(e.grid, t.pos, n, Nn(e, t.pos), !r) ?? Y(e.grid, t.pos, n);
}
function Hn(e, t) {
	let n = R({
		defId: t.defId,
		loot: t.loot
	}).find((e) => e.weapon.type === "missile");
	if (!n) return null;
	let r = n.weapon.range ?? 1, i = Q(e).filter((e) => !J(e.pos));
	if (i.length === 0 || i.some((n) => Tn(e.grid, t.pos, n.pos, r))) return null;
	let a = Kn(e) === "enemy", o = (t) => t.kind === "goblin" ? (a ? 50 : 10) + e.goblinSlots : t.kind === "minion" ? (a ? 20 : 40) - t.hp : 5, s = [...i].sort((e, t) => o(t) - o(e)), c = s[0], l = s.filter((e) => o(e) >= o(c) - 10), u = Y(e.grid, t.pos, (t) => !i.some((e) => e.pos === t) && l.some((n) => Tn(e.grid, t, n.pos, r)), Nn(e, t.pos), !0);
	return u && u.length > 0 ? {
		path: u,
		goal: "shoot"
	} : null;
}
function Un(e, t, n) {
	return R({
		defId: t.defId,
		loot: t.loot
	}).some((r) => (r.weapon.type === "melee" ? n.pos === t.pos : Tn(e.grid, t.pos, n.pos, r.weapon.range ?? 1)) ? Z(t, r.weapon.skill, t.focus) + r.weapon.mod + On(t, r.weapon.type) - n.defense >= n.hp : !1);
}
function Wn(e, t) {
	if (J(t.pos)) return null;
	let n = new Set(Q(e).map((e) => e.pos)), r = Y(e.grid, t.pos, (e) => e !== t.pos && !n.has(e) && !J(e), void 0, !0);
	return r && r.length > 0 ? {
		path: r,
		goal: "flee"
	} : null;
}
function Gn(e, t) {
	return e.goblinSlots >= 2 || e.goblinSlots >= 1 && Kn(e) === "enemy" || e.goblinSlots >= 1 && t.hp >= 4;
}
function Kn(e) {
	return (e.act === 1 ? le : ue)[e.torch + 1] ?? null;
}
function qn(e) {
	let t = bn(e.defId).defense;
	for (let n of e.loot) for (let e of xn(n)?.effects ?? []) e.k === "stat" && e.def && (t += e.def), e.k === "onMeleeDef" && (t += 1);
	return t;
}
function Jn(e, t) {
	let n = R({
		defId: t.defId,
		loot: t.loot
	}).reduce((e, n) => Math.max(e, Z(t, n.weapon.skill, t.focus) + n.weapon.mod + On(t, n.weapon.type)), 0);
	return (r) => {
		let i = e.goblins.filter((e) => e.pos === r);
		return i.length === 0 || t.hp <= i.length ? !1 : i.some((e) => {
			let t = E.find((t) => t.id === e.defId);
			return t !== void 0 && n - t.defense >= 1;
		});
	};
}
function Yn(e) {
	let t = e.minions;
	if (t.length === 0) return null;
	let n = t.filter((t) => t.hp < t.maxHp || e.heroes.some((e) => e.pos === t.pos)), r = n.length > 0 ? n : t, i = r[0], a = Infinity;
	for (let t of r) {
		let n = e.heroes.reduce((n, r) => {
			let i = J(r.pos) ? -1 : X(e.grid, r.pos, t.pos);
			return n + (i < 0 ? 99 : i);
		}, 0);
		(n < a || n === a && t.uid < i.uid) && (a = n, i = t);
	}
	return i;
}
function Xn(e, t) {
	if (t.onlyMove || t.actionsLeft <= 0) return !1;
	let n = Yn(e);
	if (!n) return !1;
	let r = D.find((e) => e.id === n.defId);
	if (!r) return !0;
	let i = R({
		defId: t.defId,
		loot: t.loot
	}).reduce((e, n) => Math.max(e, Z(t, n.weapon.skill, t.focus) + n.weapon.mod + On(t, n.weapon.type)), 0);
	return i - r.defense >= n.hp ? !0 : i - r.defense < 1 ? !1 : n.hp < n.maxHp || e.heroes.some((e) => e.uid !== t.uid && e.pos === n.pos) ? t.hp > 3.5 + r.counterMelee.add - qn(t) : t.hp > 3.5 + r.counterMelee.add - qn(t) + 1;
}
function Zn(e, t, n, r = !1) {
	let i = /* @__PURE__ */ new Map([[t.pos, null]]), a = [t.pos], o = [];
	for (; a.length;) {
		let t = a.shift();
		for (let n of vn) {
			let r = `${q(t)[0] + K[n][0]},${q(t)[1] + K[n][1]}`;
			if (!i.has(r) && e.grid[r] && Cn(e.grid, t, r)) {
				if (i.set(r, t), !e.grid[r].faceUp) {
					o.push(r);
					continue;
				}
				a.push(r);
			}
		}
	}
	if (o.length === 0) return null;
	let s = o[0];
	if (n) {
		let [e, t] = q(n), r = Infinity;
		for (let n of o) {
			let [i, a] = q(n), o = Math.abs(i - e) + Math.abs(a - t);
			o < r && (r = o, s = n);
		}
	} else if (r) {
		let n = o.filter((n) => {
			let r = X(e.grid, t.pos, n);
			return e.heroes.every((i) => {
				if (i.uid === t.uid || i.knocked || J(i.pos)) return !0;
				let a = X(e.grid, i.pos, n);
				return a < 0 || r <= a;
			});
		});
		n.length > 0 && (s = n[0]);
	}
	let c = [s], l = i.get(s);
	for (; l !== t.pos;) c.unshift(l), l = i.get(l);
	return c;
}
function Qn(e, t) {
	if (Kn(e) !== "enemy" || e.goblins.length === 0 || J(t.pos)) return null;
	let n = (e) => {
		let t = E.find((t) => t.id === e.defId);
		if (!t) return 0;
		let n = t.action;
		return n.k === "moveThen" ? n.range + n.move : n.range;
	}, r = (e, t) => {
		let [r, i] = q(e.pos), [a, o] = q(t);
		return Math.abs(r - a) + Math.abs(i - o) <= n(e);
	};
	if (e.goblins.filter((e) => r(e, t.pos)).length * (e.goblinSlots + 1) < t.hp) return null;
	let i = Y(e.grid, t.pos, (n) => n !== t.pos && !e.goblins.some((e) => r(e, n)), Nn(e, t.pos), !0);
	return i && i.length > 0 ? {
		path: i,
		goal: "flee"
	} : null;
}
function $n(e, t, n) {
	let r = X(e.grid, t.pos, n);
	return r < 0 ? !1 : !e.heroes.some((i) => {
		if (i.uid === t.uid || i.knocked || J(i.pos)) return !1;
		let a = X(e.grid, i.pos, n);
		return a >= 0 && a < r;
	});
}
function er(e, t) {
	if (t.speedLeft <= 0) return null;
	let n = An(e);
	if (J(t.pos)) return nr(e, t);
	let r = Qn(e, t);
	if (r) return r;
	if (e.act === 2) {
		if ($(e)) {
			let n = Mn(e);
			if (n.includes(t.pos)) return null;
			if (n.length > 0) {
				let r = Vn(e, t, (e) => n.includes(e));
				if (r && r.length > 0) return {
					path: r,
					goal: "altar"
				};
			}
			return null;
		}
		if (jn(e)) {
			let n = Mn(e);
			if (n.length > 0 && !e.heroes.some((e) => !e.knocked && n.includes(e.pos))) {
				let r = Vn(e, t, (e) => n.includes(e));
				if (r && r.length > 0 && $n(e, t, r[r.length - 1])) return {
					path: r,
					goal: "altar"
				};
			}
		}
		if (Gn(e, t)) {
			let n = Vn(e, t, Jn(e, t), !0);
			if (n && n.length > 0 && n.length <= t.speedLeft + 1) return {
				path: n,
				goal: "goblin"
			};
		}
		if (e.boss?.pos && !J(e.boss.pos)) {
			let n = Vn(e, t, (t) => t === e.boss.pos, !0);
			if (n && n.length > 0) return {
				path: n,
				goal: "boss"
			};
		}
		if (n && t.pos !== n) {
			let r = Vn(e, t, (e) => e === n);
			if (r && r.length > 0) return {
				path: r,
				goal: "door"
			};
		}
		return null;
	}
	if (e.lairOpen && n) {
		if (t.pos === n) return null;
		let r = Vn(e, t, (e) => e === n);
		return r && r.length > 0 ? {
			path: r,
			goal: "door"
		} : null;
	}
	let i = Hn(e, t);
	if (i) return i;
	let a = Yn(e);
	if (a && a.pos !== t.pos && Xn(e, t)) {
		let n = Vn(e, t, (e) => e === a.pos, !0);
		if (n && n.length > 0) return {
			path: n,
			goal: "minion"
		};
		let r = Zn(e, t, a.pos);
		if (r && r.length > 0) return {
			path: r,
			goal: "dark"
		};
	}
	if (Gn(e, t)) {
		let n = Vn(e, t, Jn(e, t), !0);
		if (n && n.length > 0 && n.length <= t.speedLeft + 1 && (Kn(e) === "enemy" || $n(e, t, n[n.length - 1]))) return {
			path: n,
			goal: "goblin"
		};
	}
	if (e.heroes.length >= 3 && e.minions.length > 0) {
		let n = Yn(e);
		if (n && n.pos !== t.pos) {
			let r = Vn(e, t, (e) => e === n.pos, !0);
			if (r && r.length > 0) return {
				path: r,
				goal: "minion"
			};
		}
		return null;
	}
	if (e.goblinSlots >= 3) {
		let n = Vn(e, t, Jn(e, t), !0);
		return n && n.length > 0 && $n(e, t, n[n.length - 1]) ? {
			path: n,
			goal: "goblin"
		} : null;
	}
	let o = Zn(e, t, null, e.heroes.length > 1 && e.goblinSlots <= 1);
	return o && o.length > 0 ? {
		path: o,
		goal: "dark"
	} : null;
}
function tr(e, t, n) {
	let r = e.boss, i = O.find((e) => e.id === r.defId), a = i ? i.spaces.findIndex((e) => e.entrance) : 0, o = a >= 0 ? a : 0, s = [], c = Number(t.pos.slice(1));
	for (; c !== o;) c += Math.sign(o - c), s.push(`L${c}`);
	let l = An(e);
	if (l) {
		s.push(l);
		let t = Y(e.grid, l, n, Nn(e, l)) ?? Y(e.grid, l, n);
		t && s.push(...t);
	}
	return s;
}
function nr(e, t) {
	let n = e.boss;
	if (!n) return null;
	let r = O.find((e) => e.id === n.defId);
	if (!r) return null;
	let i = Number(t.pos.slice(1));
	if ($(e)) {
		let n = Mn(e);
		return {
			path: tr(e, t, (e) => n.includes(e)),
			goal: "altar"
		};
	}
	if (!n.pos || !J(n.pos)) return n.pos ? {
		path: tr(e, t, (e) => e === n.pos),
		goal: "boss"
	} : null;
	let a = Number(n.pos.slice(1)), o = R({
		defId: t.defId,
		loot: t.loot
	}), s = o.reduce((e, t) => Math.max(e, t.weapon.type === "missile" ? t.weapon.range ?? 1 : 0), 0), c = o.some((e) => e.weapon.type === "melee"), l = (e) => c && e === a || s > 0 && Math.abs(e - a) > 0 && Math.abs(e - a) <= s;
	if (l(i)) return null;
	let u = null, d = -Infinity;
	for (let e = 0; e < 6; e += 1) {
		if (e === i) continue;
		let n = Math.abs(e - i);
		if (n > t.speedLeft) continue;
		let o = l(e) ? 10 : -Math.abs(e - a), s = r.spaces[e]?.fx, c = 0;
		s && (s.k === "checkAdd" ? c = s.n * 1.2 : s.k === "focus" ? c = s.n * .7 : s.k === "hp" ? c = s.n < 0 ? s.n * 2.5 : s.n * .5 : s.k === "fullRestore" ? c = (t.maxHp - t.hp) * .6 : s.k === "goblinEntrance" || s.k === "lessDie" ? c = -2.5 : s.k === "moveAgain" && (c = 1));
		let f = o + c - n * .1;
		f > d && (d = f, u = e);
	}
	if (u === null) return null;
	let f = [], p = i;
	for (; p !== u;) p += Math.sign(u - p), f.push(`L${p}`);
	return {
		path: f,
		goal: "mat"
	};
}
function rr(e) {
	let t = e.pendingRoll, n = e.heroes.find((e) => e.uid === t.forUid)?.focus ?? 0, r = t.label === "games.ted.rollAttack", i = t.dice.map((e) => e === 1 ? 1 : e === 2 ? 2 : 0), a = 0, o = -Infinity;
	t.dice.forEach((e, s) => {
		let c = i.reduce((e, t, n) => n === s ? e : e + t, 0), l = Math.min(6 - e, Math.floor(n / 2)), u = r ? e + c + l : e + c + l >= t.need ? 100 + e : e;
		u > o && (o = u, a = s);
	});
	let s = [], c = t.dice[a], l = n, u = i.reduce((e, t, n) => n === a ? e : e + t, 0), d = r ? 6 : Math.min(6, Math.max(c, t.need - u));
	for (; c < d && l >= 2;) s.push({
		die: a,
		dir: 1
	}), c += 1, l -= 2;
	return {
		type: "resolveRoll",
		dieIdx: a,
		nudges: s
	};
}
function ir(e, t) {
	let n = e.pendingRoll, r = bn(t.defId), i = n.label === "games.ted.rollAttack", a = n.label === "games.ted.rollCast", o = e.act === 2 && $(e) && !J(t.pos) ? 2 : 0, s = Math.max(0, t.focus - o), c = Dn(t, "any"), l = n.dice.map((e) => fe[e - 1].add), u = 0, d = -Infinity;
	n.dice.forEach((e, t) => {
		let r = l.reduce((e, n, r) => r === t ? e : e + n, 0), a = Math.min(6 - e, Math.floor(s / 2)), o = e + r + (i ? 0 : c) + a, f = i ? e + r + a : o >= n.need ? 100 + e : e;
		f > d && (d = f, u = t);
	});
	let f = l.reduce((e, t, n) => n === u ? e : e + t, 0), p = [], m = n.dice[u], h;
	for (h = i ? 6 : Math.min(6, Math.max(m, n.need - f - c)); m < h && p.length * 2 + 2 <= s;) p.push({
		die: u,
		dir: 1
	}), m += 1;
	let g = [], _ = p.length * 2, v = R({
		defId: t.defId,
		loot: t.loot
	}).every((e) => e.weapon.type === "melee"), y = (e) => r.abilities.some((t) => t.k === e), b = (e) => t.loot.some((t) => xn(t)?.effects.some((t) => t.k === e)), x = m + f + (i ? 0 : c), S = n.need - x, C = !1;
	if (i && v && b("meleeReroll") && n.dice[u] <= 2 && (g.push(`reroll${u}`), C = !0), i && !C && S > 0 && S <= 2 && y("battleRage") && s >= _ + 3 && (g.push("battleRage"), _ += 3), i && !C && S > 0 && v && b("lionSwordPump")) {
		let e = S;
		for (; e > 0 && s >= _ + 2;) g.push("lionPump"), _ += 2, --e;
	}
	if (i && v && y("stoneStance") && n.enemyDie !== null && t.hp <= 4 && s >= _ + 2) {
		let e = pe[n.enemyDie - 1];
		(e.k === "num" && e.n >= 4 || e.k === "shield") && (g.push("stoneStance"), _ += 2);
	}
	return a && y("clericHeal") && t.maxHp - t.hp >= 4 && s >= _ + 2 && g.push("clericHeal"), {
		type: "resolveRoll",
		dieIdx: u,
		nudges: C ? [] : p,
		boosts: g.length > 0 ? g : void 0
	};
}
function ar(e, t) {
	let n = xn(e);
	if (!n) return 0;
	let r = bn(t.defId), i = 0;
	for (let e of n.effects) switch (e.k) {
		case "weapon": {
			let t = e.weapon.skill === "str" ? r.str : e.weapon.skill === "agi" ? r.agi : r.int;
			i += 4 + e.weapon.mod + (t >= 2 ? 1 : -1);
			break;
		}
		case "stat":
			i += (e.def ?? 0) * 3 + (e.spd ?? 0) * 2;
			break;
		case "checkDie":
			i += (e.skill === "int" ? r.int : e.skill === "agi" ? r.agi : r.str) >= 2 ? 4 : 2;
			break;
		case "checkAdd":
			i += 2.5;
			break;
		case "onMeleeFocus":
		case "onMissileFocus":
		case "onMeleeDef":
		case "onMissileOrCastDef":
			i += 2;
			break;
		case "meleeReroll":
		case "lionSwordPump":
			i += 3;
			break;
		case "spellDamageUp":
			i += r.int >= 3 ? 3 : .5;
			break;
		default: i += 2.5;
	}
	if (n.set) {
		let e = t.loot.filter((e) => xn(e)?.set === n.set).length;
		i += e * 1.5;
	}
	return i;
}
function or(e, t, n) {
	let r = k.find((t) => t.id === e);
	if (!r) return 0;
	let i = bn(t.defId);
	if (!(r.check.skill === "any" || En(t, "int") >= 2 || i.int >= 2)) return .5;
	let a = r.effect, o = n !== void 0 && n >= 5;
	return a.k === "damage" ? (o ? 8 : 4) + a.dmg * .5 : a.k === "aoeDamage" || a.k === "tempestArrows" ? o ? 7 : 4.5 : a.k === "healAllMax" || a.k === "holyAbundance" ? 4 : a.k === "restAura" ? 3 : 2.5;
}
function sr(e, t) {
	let n = e.choice, r = n.options;
	switch (n.kind) {
		case "goblinReward": {
			let e = r.find((e) => e.startsWith("hp:"));
			if (e && t.maxHp - t.hp >= Number(e.slice(3))) return e;
			let n = r.find((e) => e.startsWith("focus:"));
			return n && t.focus <= 2 ? n : r.includes("loot") ? "loot" : r.includes("spell") && (En(t, "int") >= 2 || bn(t.defId).int >= 2) && t.spellCount < 2 ? "spell" : e || n || r[0];
		}
		case "minionReward": return r.includes("spell") && t.spellCount === 0 && (En(t, "int") >= 2 || bn(t.defId).int >= 2) ? "spell" : "loot";
		case "discover": {
			let n = r.includes("deck"), i = e.boss ? O.find((t) => t.id === e.boss.defId)?.defense : void 0, a = n ? "deck" : r[0], o = n ? 5 : -1;
			for (let e of r) {
				if (!e.startsWith("discard:")) continue;
				let n = e.slice(8), r = Math.max(ar(n, t), or(n, t, i));
				r > o && (o = r, a = e);
			}
			return a;
		}
		case "pharaohTorch": {
			if (t.focus <= 1) return "focus3";
			let e = null, n = 2.5;
			for (let i of r) {
				if (!i.startsWith("discard:")) continue;
				let r = or(i.slice(8), t);
				r < n && (n = r, e = i);
			}
			return e ?? "focus3";
		}
		case "oozeDiscard": {
			let e = r[0], n = Infinity;
			for (let i of r) {
				let r = ar(i, t);
				r < n && (n = r, e = i);
			}
			return e;
		}
		case "pulleyKill": {
			let t = r[0], n = -1;
			for (let i of r) {
				let r = e.goblins.find((e) => e.uid === i), a = E.find((e) => e.id === r?.defId);
				if (!a) continue;
				let o = ("range" in a.action ? a.action.range : 0) * 2 + a.speed + (a.action.dmg === "n1" ? e.goblinSlots : 1);
				o > n && (n = o, t = i);
			}
			return t;
		}
		default: return r.includes("skip") ? "skip" : r[0];
	}
}
var cr = [
	"grokull",
	"wyn",
	"ethairna",
	"uliessa",
	"lannon",
	"thordin",
	"gerrund",
	"moonblade"
], lr = [
	"grokull",
	"lannon",
	"uliessa",
	"ethairna",
	"wyn",
	"gerrund",
	"thordin",
	"moonblade"
];
function ur(e, t, n) {
	let r = e.heroes.filter((e) => e.rid === n.rid).length === 1;
	if (n.knocked) return n.actionsLeft > 0 ? { type: "rest" } : { type: "endTurn" };
	let i = Rn(e, n);
	if (i) return i;
	let a = zn(e, n);
	if (a) return a;
	let o = Bn(e, n);
	if (o) return o;
	let s = e.heroes.length <= 3 ? 2 : 3, c = dr(e, n.pos);
	if (!n.explored && !n.onlyMove && e.act === 1 && Kn(e) !== "skull" && e.goblinSlots <= 2 && c >= s) return { type: "explore" };
	let l = Q(e).find((e) => e.pos === n.pos), u = (() => {
		if (!l) return 4;
		if (l.kind === "goblin") return 2 + e.goblinSlots;
		if (l.kind === "minion") {
			let t = D.find((t) => t.id === (e.minions.find((e) => e.uid === l.uid)?.defId ?? ""));
			return t ? Math.max(2, Math.ceil(3.5 + t.counterMelee.add - qn(n)) + 1) : 4;
		}
		return 4;
	})();
	if (l && (n.onlyMove || n.hp <= u) && n.speedLeft > 0 && !(n.actionsLeft > 0 && !n.onlyMove && Un(e, n, l)) && !(e.act === 2 && $(e))) {
		let t = Wn(e, n);
		if (t) {
			let e = fr(t, n.speedLeft);
			if (e.length > 0) return {
				type: "move",
				path: e
			};
		}
	}
	let d = An(e);
	if (d && n.pos === d && n.speedLeft >= 1 && e.lairOpen && !$(e)) return { type: "enterLair" };
	if (e.act === 1 && e.lairOpen && e.torch <= 16 && (n.hp <= n.maxHp - 3 || n.focus <= 1) && n.actionsLeft > 0 && !n.onlyMove && !l) return { type: "rest" };
	if (d && n.pos === d && n.speedLeft >= 1 && e.lairOpen) return { type: "enterLair" };
	let f = [];
	if (n.actionsLeft > 0 && !n.onlyMove) {
		if (f = Pn(e, n), r) for (let r of t.spells) {
			let t = Fn(e, n, r);
			t && f.push(t);
		}
		f.push(...In(e, n));
		let i = e.grid[n.pos], a = i?.roomId ? A.find((e) => e.id === i.roomId)?.effect : null;
		if (i && !i.used && a) {
			if (a.k === "search") {
				let e = Math.min(.95, Math.max(.3, .55 + (Z(n, a.check.skill, n.focus) - a.check.n) * .15));
				f.push({
					action: { type: "search" },
					score: 4 * e
				});
			} else if (a.k === "graveyard") {
				let e = Math.min(.95, Math.max(.3, .55 + (Z(n, "any", n.focus) - 7) * .15));
				f.push({
					action: { type: "search" },
					score: 5 * e
				});
			} else if (a.k === "arcaneAltar") {
				let t = Math.min(.95, Math.max(.3, .55 + (Z(n, "int", n.focus) - 5) * .15)), r = e.torch > 6 ? 1 : .4;
				f.push({
					action: { type: "search" },
					score: 6 * t * r
				});
			} else if (a.k === "cauldron") {
				let e = Math.min(.95, Math.max(.3, .55 + (Z(n, "int", n.focus) - 5) * .15));
				f.push({
					action: { type: "search" },
					score: 3.5 * e
				});
			}
		}
		let o = n.maxHp - n.hp, s = (n.hp <= 2 ? 5 : e.act === 2 && o >= 4 ? 3 : 0) + (n.focus === 0 && o >= 2 ? 1.5 : 0) + (e.act === 2 && n.focus <= 1 ? 1.5 : 0) + (e.minions.length > 0 && !Xn(e, n) && o >= 3 ? 3 : 0);
		s > 0 && f.push({
			action: { type: "rest" },
			score: s
		}), n.trapped && f.push({
			action: { type: "disarm" },
			score: 1.5
		});
	}
	let p = f.length > 0 ? f.reduce((e, t) => t.score > e.score ? t : e) : null, m = er(e, n), h = m !== null && m.path.length > 0 && m.path.length <= n.speedLeft && [
		"minion",
		"goblin",
		"boss",
		"mat",
		"door",
		"altar",
		"shoot"
	].includes(m.goal);
	if (p && (!h || p.score >= 6) && p.score >= 2.5) return p.action;
	if (m && m.path.length > 0 && n.speedLeft > 0) {
		let t = bn(n.defId);
		if (m.path.length > n.speedLeft && !n.onlyMove) {
			let e = t.abilities.findIndex((e) => e.k === "sprint");
			if (e >= 0 && !n.abilityUsed.includes(e) && n.focus >= 1 && m.path.length === n.speedLeft + 1) return {
				type: "ability",
				idx: e
			};
			let r = t.abilities.findIndex((e) => e.k === "shadowWalk");
			if (r >= 0 && !n.abilityUsed.includes(r) && n.actionsLeft > 0 && Z(n, "agi", n.focus) >= 5.4) return {
				type: "ability",
				idx: r
			};
		}
		let r = t.abilities.findIndex((e) => e.k === "stealth");
		if (!n.onlyMove && r >= 0 && !n.abilityUsed.includes(r) && n.focus >= 2) {
			let t = m.path[0];
			if (t && Q(e).some((e) => e.pos === t)) return {
				type: "ability",
				idx: r
			};
		}
		let i = fr(m, n.speedLeft), a = i;
		if (m.goal !== "goblin" && m.goal !== "minion" && m.goal !== "boss") {
			let t = Q(e), n = i.findIndex((e) => t.some((t) => t.pos === e));
			n >= 0 && (a = i.slice(0, n));
		}
		if (a.length > 0) return {
			type: "move",
			path: a
		};
	}
	if (p && p.score >= 2.5) return p.action;
	if (J(n.pos) && e.act === 2 && e.boss?.pos && J(e.boss.pos) && !$(e) && n.focus >= 2 && Number(n.pos.slice(1)) !== Number(e.boss.pos.slice(1)) || !J(n.pos) && e.act === 2 && $(e) && n.focus >= 2 && Mn(e).includes(n.pos)) return { type: "taunt" };
	let g = e.heroes.length <= 3 ? 1 : 99;
	return !n.explored && !n.onlyMove && e.act === 1 && Kn(e) !== "skull" && e.goblinSlots <= 3 && dr(e, n.pos) >= g ? { type: "explore" } : { type: "endTurn" };
}
function dr(e, t) {
	let n = 0;
	for (let r of vn) {
		let i = `${q(t)[0] + K[r][0]},${q(t)[1] + K[r][1]}`;
		e.grid[i] && !e.grid[i].faceUp && (n += 1);
	}
	return n;
}
function fr(e, t) {
	let n = Math.min(e.path.length, t);
	return e.goal === "door" && e.path.length === n && n === t && --n, e.path.slice(0, Math.max(0, n));
}
function pr(e, t, n) {
	let r = t.myTurnUid;
	if (!r) return null;
	let i = e.heroes.find((e) => e.uid === r);
	if (!i) return null;
	let a = T.find((e) => e.id === i.defId), o = n.memory;
	(!o || o.uid !== r || o.seq !== e.turnSeq) && (o = {
		uid: r,
		seq: e.turnSeq,
		failed: []
	});
	let s = (e) => o.failed.includes(e), c = (e, t) => ({
		action: t,
		memory: {
			...o,
			failed: [...o.failed, e]
		}
	}), l = i.actionsLeft > 0 && !i.onlyMove, u = s("attack") || s("search") || s("disarm") || s("rest");
	if (i.knocked) return l && !u ? c("rest", { type: "rest" }) : {
		action: { type: "endTurn" },
		memory: o
	};
	let d = (a?.abilities ?? []).flatMap((e) => e.k === "weapon" ? [e.weapon] : []).map((e, t) => ({
		idx: t,
		w: e
	}));
	if (l && !s("attack") && d.length > 0) {
		let t = d.find((e) => e.w.type === "melee") ?? d[0], n = [...e.minions, ...e.goblins], r = n.find((e) => e.pos === i.pos);
		if (r) return c("attack", {
			type: "attack",
			targetUid: r.uid,
			weaponIdx: t.idx
		});
		if (e.act === 2 && e.boss?.pos === i.pos) return c("attack", {
			type: "attack",
			targetUid: "boss",
			weaponIdx: t.idx
		});
		let a = d.find((e) => e.w.type === "missile");
		if (a && !J(i.pos)) {
			let [e, t] = q(i.pos), r = n.find((n) => {
				if (J(n.pos)) return !1;
				let [r, i] = q(n.pos), o = Math.abs(r - e) + Math.abs(i - t);
				return o > 0 && (r === e || i === t) && o <= (a.w.range ?? 0);
			});
			if (r) return c("attack", {
				type: "attack",
				targetUid: r.uid,
				weaponIdx: a.idx
			});
		}
	}
	let f = i.speedLeft;
	if (J(i.pos)) {
		let t = Number(e.boss?.pos?.slice(1) ?? -1), n = Number(i.pos.slice(1));
		return t >= 0 && t !== n && !s("move") && f > 0 ? c("move", {
			type: "move",
			path: [`L${n + Math.sign(t - n)}`]
		}) : !s("taunt") && i.focus >= 2 ? c("taunt", { type: "taunt" }) : {
			action: { type: "endTurn" },
			memory: o
		};
	}
	if (i.trapped && l && !s("disarm")) return c("disarm", { type: "disarm" });
	let p = An(e);
	if (p) {
		if (e.lairOpen) {
			if (i.pos === p && f > 0 && !s("enterLair")) return c("enterLair", { type: "enterLair" });
			let t = !s("move") && f > 0 ? Y(e.grid, i.pos, (e) => e === p) : null;
			if (t && t.length > 0) return c("move", {
				type: "move",
				path: t.slice(0, f)
			});
		} else if (!s("move") && f > 0) {
			let t = Y(e.grid, i.pos, (t) => e.minions.some((e) => e.pos === t));
			if (t && t.length > 0) return c("move", {
				type: "move",
				path: t.slice(0, f)
			});
		}
	}
	let m = !s("move") && f > 0 ? Y(e.grid, i.pos, (t) => !e.grid[t].faceUp) : null;
	if (m && m.length > 0) return c("move", {
		type: "move",
		path: m.slice(0, f)
	});
	if (e.goblins.length >= 2 && !s("move") && f > 0) {
		let t = Y(e.grid, i.pos, (t) => e.goblins.some((e) => e.pos === t));
		if (t && t.length > 0) return c("move", {
			type: "move",
			path: t.slice(0, f)
		});
	}
	if (!i.explored && !s("explore") && e.act === 1) {
		let [t, n] = q(i.pos);
		if (vn.some((r) => {
			let i = `${t + K[r][0]},${n + K[r][1]}`;
			return e.grid[i] && !e.grid[i].faceUp;
		})) return c("explore", { type: "explore" });
	}
	let h = (e.grid[i.pos]?.roomId ? A.find((t) => t.id === e.grid[i.pos].roomId) : null)?.effect.k;
	return (h === "armory" || h === "library" || h === "pulley" && e.goblins.length > 0 || (h === "well" || h === "feasthall") && i.hp * 2 <= i.maxHp) && !i.roomActionUsed && !s("room") ? c("room", { type: "roomAction" }) : l && (h === "search" || h === "graveyard" || h === "arcaneAltar" || h === "cauldron") && !e.grid[i.pos].used && !s("search") ? c("search", { type: "search" }) : l && i.hp * 2 <= i.maxHp && !u ? c("rest", { type: "rest" }) : {
		action: { type: "endTurn" },
		memory: o
	};
}
var mr = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = t.difficulty === "weak";
	if (n.phase === "pick") {
		if (n.pickRid !== t.rid) return null;
		if (i) {
			let e = T.find((e) => !n.picked.includes(e.id));
			return e ? { action: {
				type: "pickHero",
				heroId: e.id
			} } : null;
		}
		let e = n.boss ? O.find((e) => e.id === n.boss.defId) : void 0, r = (e && e.defense >= 5 ? lr : cr).find((e) => !n.picked.includes(e));
		return r ? { action: {
			type: "pickHero",
			heroId: r
		} } : null;
	}
	if (n.choice) {
		let e = n.choice, r = n.heroes.find((t) => t.uid === e.forUid);
		return !r || r.rid !== t.rid ? null : i ? { action: {
			type: "choose",
			option: e.kind === "warhorn" && e.options.includes("skip") ? "skip" : e.options[0]
		} } : { action: {
			type: "choose",
			option: sr(n, r)
		} };
	}
	if (n.phase === "roll") {
		let e = n.pendingRoll;
		if (!e) return null;
		let r = n.heroes.find((t) => t.uid === e.forUid);
		return !r || r.rid !== t.rid ? null : { action: i ? rr(n) : ir(n, r) };
	}
	if (n.phase !== "play" || !r.myTurnUid) return null;
	if (i) return pr(n, r, t);
	let a = n.heroes.find((e) => e.uid === r.myTurnUid);
	return a ? { action: ur(n, r, a) } : null;
}, hr = {
	reveal(e, t) {
		let n = e.data, r = n?.coord ? t.anchor(`room:${n.coord}`) : null;
		return r ? {
			ms: 600,
			node: /* @__PURE__ */ v(x, {
				at: r,
				ms: 600
			})
		} : null;
	},
	move(e, t) {
		let n = e.data, r = n?.path?.[n.path.length - 1], i = (r ? t.anchor(`room:${r}`) : null) ?? (n?.uid ? t.anchor(`hero:${n.uid}`) : null);
		return i ? {
			ms: 350,
			node: /* @__PURE__ */ v(x, {
				at: i,
				ms: 350
			})
		} : null;
	},
	roll(e, t) {
		let n = e.data, r = n?.forUid ? t.anchor(`hero:${n.forUid}`) : null;
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ v(x, {
				at: r,
				ms: 700
			})
		} : null;
	},
	hit(e, t) {
		let n = e.data, r = n?.uid ? t.anchor(`enemy:${n.uid}`) : null;
		return r ? {
			ms: 600,
			node: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(x, {
				at: r,
				ms: 500
			}), /* @__PURE__ */ v(b, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ y("span", {
					className: "font-mono text-lg font-extrabold tabular-nums text-rose-600",
					children: ["-", n?.n ?? 0]
				})
			})] })
		} : null;
	},
	kill(e, t) {
		let n = e.data, r = n?.uid ? t.anchor(`enemy:${n.uid}`) : null;
		return r ? {
			ms: 800,
			node: /* @__PURE__ */ v(b, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ v("span", {
					className: "text-xl",
					children: "💥"
				})
			})
		} : null;
	},
	spawn(e, t) {
		let n = e.data, r = n?.uid ? t.anchor(`enemy:${n.uid}`) : null;
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ v(x, {
				at: r,
				ms: 700
			})
		} : null;
	},
	enemyAct(e, t) {
		let n = e.data, r = n?.uid ? t.anchor(`enemy:${n.uid}`) : null;
		return r ? {
			ms: De.enemyAct,
			node: /* @__PURE__ */ v(x, {
				at: r,
				ms: 500
			})
		} : {
			ms: De.enemyAct,
			node: null
		};
	},
	torch(e, t) {
		let n = t.anchor("torch");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ v(x, {
				at: n,
				ms: 500
			})
		} : null;
	},
	bossHit(e, t) {
		let n = e.data, r = t.anchor("bossmat") ?? t.anchor("enemy:boss");
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ v(b, {
				at: r,
				ms: 900,
				children: /* @__PURE__ */ y("span", {
					className: "font-mono text-lg font-extrabold tabular-nums text-rose-600",
					children: ["-", n?.n ?? 0]
				})
			})
		} : null;
	},
	bossMove(e, t) {
		let n = t.anchor("enemy:boss") ?? t.anchor("bossmat");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ v(x, {
				at: n,
				ms: 500
			})
		} : null;
	},
	phase(e, t) {
		let n = e.data, r = t.anchor("torch") ?? (e.rid ? t.anchor(`seat:${e.rid}`) : null);
		if (!r) return null;
		let i = n?.phase === "won" ? "🏆" : n?.phase === "act2" ? "😈" : "🔥";
		return {
			ms: 1200,
			node: /* @__PURE__ */ v(b, {
				at: r,
				ms: 1100,
				children: /* @__PURE__ */ v("span", {
					className: "text-2xl",
					children: i
				})
			})
		};
	},
	turn() {
		return {
			ms: 400,
			node: null
		};
	},
	pick() {
		return {
			ms: 300,
			node: null
		};
	},
	resolve() {
		return {
			ms: 400,
			node: null
		};
	},
	disarm(e, t) {
		let n = e.data, r = n?.coord ? t.anchor(`room:${n.coord}`) : null;
		return r ? {
			ms: 500,
			node: /* @__PURE__ */ v(x, {
				at: r,
				ms: 500
			})
		} : null;
	},
	altar() {
		return {
			ms: 500,
			node: null
		};
	},
	gain() {
		return {
			ms: 300,
			node: null
		};
	},
	cast() {
		return {
			ms: 400,
			node: null
		};
	},
	rest() {
		return {
			ms: 300,
			node: null
		};
	},
	damage() {
		return {
			ms: 300,
			node: null
		};
	},
	heal() {
		return {
			ms: 300,
			node: null
		};
	},
	focus() {
		return {
			ms: 200,
			node: null
		};
	},
	knocked(e, t) {
		let n = e.data, r = n?.uid ? t.anchor(`hero:${n.uid}`) : null;
		return r ? {
			ms: 900,
			node: /* @__PURE__ */ v(b, {
				at: r,
				ms: 900,
				children: /* @__PURE__ */ v("span", {
					className: "text-xl",
					children: "💫"
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/ted/endgame-review.tsx
function gr({ board: e, renderResult: t, ...n }) {
	let s = d(), [c, l] = o(!0), [u, f] = o(null), p = a(null), m = a(null), h = a(null);
	r(() => {
		if (!u) return;
		h.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [u]);
	let g = (e) => {
		f(null), l(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, _ = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), b = {
		...n,
		..._
	};
	return /* @__PURE__ */ y("div", {
		className: "ted-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ v("div", {
				className: "ted-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ v("div", {
				className: "ted-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ y("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), g(!1));
					},
					className: "ted-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ y("header", {
							className: "ted-endgame-heading",
							children: [/* @__PURE__ */ y("div", {
								className: "ted-endgame-brand",
								children: [/* @__PURE__ */ v("span", {
									"aria-hidden": "true",
									children: he.icon
								}), s(he.nameKey)]
							}), /* @__PURE__ */ v("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": s("games.ted.reviewHide"),
								title: s("games.ted.reviewHide"),
								onClick: () => g(!1),
								children: /* @__PURE__ */ v(w, { size: 19 })
							})]
						}),
						/* @__PURE__ */ v("div", {
							className: "ted-endgame-result",
							inert: u !== null,
							children: t(b)
						}),
						u && /* @__PURE__ */ y("div", {
							className: "ted-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ v("button", {
								type: "button",
								ref: h,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = u.run;
									f(null), e();
								},
								children: s(u.label === "again" ? "games.ted.reviewConfirmAgain" : "games.ted.reviewConfirmLobby")
							}), /* @__PURE__ */ v("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: s("games.ted.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ v("div", {
				className: "ted-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ y("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => g(!0),
					children: [
						/* @__PURE__ */ v(ee, { size: 18 }),
						s("games.ted.reviewShow"),
						/* @__PURE__ */ v(S, { size: 18 })
					]
				})
			})
		]
	});
}
function _r({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: c, renderRowExtra: l, summary: f, navigation: p, content: m, afterRanking: h, scoreUnit: b, rankOf: x }) {
	let S = d(), ee = u((e) => e.locale), [ne, re] = o({}), T = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? g(n, ee) : e;
	}, E = (t, n) => x?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), D = e.ranking.some((t) => e.scores?.[t] !== void 0), O = (t, n) => /* @__PURE__ */ y("div", {
		className: "ted-score-identity",
		children: [
			/* @__PURE__ */ y("span", {
				className: "ted-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ v("span", {
					"aria-label": S("games.ted.reviewWinner"),
					children: "♛ "
				}), D && E(t, n)]
			}),
			/* @__PURE__ */ y("span", {
				className: "ted-score-name",
				children: [T(t), t === r && /* @__PURE__ */ v("small", { children: S("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ y("small", {
				className: "ted-score-autopilot",
				children: [
					/* @__PURE__ */ v(C, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), ie = (t) => e.ranking.map((n) => /* @__PURE__ */ v("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ y("div", {
		className: "ted-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ v(te, {}),
			p,
			/* @__PURE__ */ y("div", {
				className: "ted-score-body",
				children: [
					f && /* @__PURE__ */ v("div", {
						className: "ted-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ v("p", {
						className: "ted-score-hints",
						children: S("session.hint.usedCount", { n: i })
					}),
					m ?? (c?.length ? /* @__PURE__ */ v("div", {
						className: "ted-score-table-scroll",
						children: /* @__PURE__ */ y("table", {
							className: "ted-score-table",
							"aria-label": S(he.nameKey),
							children: [
								/* @__PURE__ */ v("thead", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", { scope: "col" }), /* @__PURE__ */ v(_, { children: e.ranking.map((t, n) => /* @__PURE__ */ v("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: O(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ v("tbody", { children: c.map((e, t) => /* @__PURE__ */ y(n, { children: [/* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ y("button", {
										type: "button",
										"aria-expanded": !!ne[t],
										onClick: () => re((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ v(w, { size: 15 }), e.label]
									}) : e.label
								}), ie(e)] }), ne[t] && e.details?.map((e, t) => /* @__PURE__ */ y("tr", {
									className: "ted-score-sub",
									children: [/* @__PURE__ */ v("th", {
										scope: "row",
										children: e.label
									}), ie(e)]
								}, t))] }, t)) }),
								D && /* @__PURE__ */ v("tfoot", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", {
									scope: "row",
									children: S("games.ted.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ v("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ v("ol", {
						className: "ted-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ y("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ y("div", {
								className: "ted-score-rankline",
								children: [O(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ y("strong", {
									className: "ted-score-points",
									children: [e.scores[t], b && /* @__PURE__ */ v("small", { children: b })]
								})]
							}), l?.(t)]
						}, t))
					})),
					h,
					!!c?.length && l && /* @__PURE__ */ v("div", {
						className: "ted-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ y("details", { children: [/* @__PURE__ */ v("summary", { children: T(e) }), l(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ y("footer", {
				className: "ted-score-actions",
				children: [
					s && /* @__PURE__ */ v("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: S("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ v("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: S("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ v("p", { children: S("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/ted/game-over.tsx
function vr(e) {
	let t = d(), n = e.public, r = e.result.winner.length > 0, i = {
		torch: "games.ted.lostTorch",
		goblins: "games.ted.lostGoblins",
		deadend: "games.ted.lostDeadend"
	};
	return /* @__PURE__ */ v(_r, {
		...e,
		content: /* @__PURE__ */ y("div", {
			className: "ted-result-outcome",
			children: [
				/* @__PURE__ */ v("span", {
					"aria-hidden": "true",
					children: r ? "🏆" : "💀"
				}),
				/* @__PURE__ */ v("h2", { children: t(r ? "games.ted.won" : "games.ted.lost") }),
				!r && n.lostReason && /* @__PURE__ */ v("p", { children: t(i[n.lostReason]) })
			]
		})
	});
}
function yr(e) {
	return /* @__PURE__ */ v(gr, {
		...e,
		board: /* @__PURE__ */ v(Qt, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ v(vr, { ...e })
	});
}
//#endregion
//#region src/games/ted/options.tsx
function br({ value: e, onChange: t }) {
	let n = d(), r = ve.safeParse(e), i = r.success ? r.data : ve.parse(void 0);
	return /* @__PURE__ */ v(re, {
		title: n("games.ted.optBoss"),
		children: ["random", ...O.map((e) => e.id)].map((e) => {
			let r = O.find((t) => t.id === e);
			return /* @__PURE__ */ v(ne, {
				name: "ted-boss",
				value: e,
				checked: i.boss === e,
				label: r ? r.name : n("games.ted.optBossRandom"),
				accent: he.accent,
				onChange: () => t({ boss: e })
			}, e);
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/ted/entry.tsx
var xr = {
	definition: It,
	View: Qt,
	bot: mr,
	fx: hr,
	OverView: yr,
	Options: br,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "小小史诗地城",
			desc: "合作地城探险:点亮房间、清剿哥布林与随从,赶在火炬燃尽前讨伐 Boss",
			rules: "目标：在火炬燃尽之前击败首领。\n回合:\n· 英雄轮流行动:先按速度值移动,踏入背面的房间会将其翻开。\n· 然后执行 1 次英雄行动(攻击 / 搜索 / 解除陷阱 / 施法 / 房间行动 / 休整)。\n· 花费专注的免费行动不限次数。\n检定:\n· 掷等同于属性值数量的骰子,选 1 颗作为结果,其余骰子的 + 值全部累加。\n· 每 2 点专注可将结果调高或调低 1。\n火炬:\n· 回合结束时，火炬前进 1 格。到达图标格时，会生成哥布林或唤醒敌人。\n· 场上出现第 5 只哥布林就败北。\n· 击杀随从可使火炬回退 6 格。\nBoss:\n· 翻开巢穴之门后，进入第二幕。占领祭坛格可以解锁首领的生命标记；清除全部生命标记后，获得胜利。\n败北(任一触发):\n发生以下任一情况时，冒险失败：\n· 火炬燃尽。\n· 第5只哥布林进入地城。\n· 没有可以继续探索的地城牌。",
			bannerPick: "挑选你的英雄",
			bannerYou: "轮到你行动",
			bannerWait: "等待队友行动…",
			bannerEnemy: "敌人行动中…",
			rollNeed: "需要 {{n}}",
			rollConfirm: "确认结果",
			rollAttack: "攻击检定",
			rollSearch: "搜索检定",
			rollDisarm: "解除陷阱",
			rollTrap: "触发陷阱!",
			rollBunks: "哥布林窝!",
			rollCast: "施法检定",
			rollAbility: "能力检定",
			rollArmory: "军械库",
			rollFeast: "宴会厅",
			boostRage: "狂暴 +2(−3⚡)",
			boostStance: "石肤 防御+2(−2⚡)",
			boostPump: "狮剑蓄力 +1(−2⚡)",
			boostReroll: "重掷 {{n}} 颗",
			boostCleric: "圣疗 −2⚡ 自愈 4❤",
			choiceGoblinReward: "哥布林战利品:选一项",
			choiceDiscover: "发现:从牌堆顶拿 1 张牌,或从弃牌堆回收 1 张",
			choiceMinionReward: "随从讨伐奖励",
			choicePharaoh: "法老的抉择",
			choiceOoze: "软泥怪缠身:弃一件物品",
			choicePulley: "绞盘:选择目标哥布林",
			choiceWarhorn: "战吼号角:点格子推移敌人",
			choiceWait: "等待队友抉择…",
			optDeck: "牌堆顶",
			optLoot: "物品牌堆",
			optSpell: "法术牌堆",
			optReveal: "翻一间房",
			optFocus3: "3 ⚡",
			optSkip: "跳过",
			optHp: "{{n}} ❤",
			optFocus: "{{n}} ⚡",
			pickTarget: "选择目标",
			cancel: "取消",
			actSearch: "搜索",
			actDisarm: "解除陷阱",
			actRoom: "房间行动",
			actLair: "进入巢穴",
			actTaunt: "嘲弄",
			actExplore: "探索",
			actRest: "休整",
			endTurn: "结束回合",
			abilityResearch: "钻研",
			abilityHealingHands: "治愈之手",
			abilityShieldBash: "盾击",
			abilitySprint: "疾跑",
			abilityLockpick: "开锁",
			abilityStealth: "潜行",
			abilitySeekingBolt: "追踪箭",
			abilityDivineMight: "神威",
			abilityShadowWalk: "影行",
			bossSpace: "Boss 位 {{n}}",
			optBoss: "本局 Boss",
			optBossRandom: "随机",
			won: "Boss 讨伐成功!",
			lost: "冒险失败…",
			lostTorch: "火炬燃尽,地城陷入黑暗",
			lostGoblins: "哥布林泛滥成灾",
			lostDeadend: "地城已无出路",
			errNotYourTurn: "还没轮到你",
			errBadPick: "这位英雄已被选走",
			errNoSpeed: "移动力不足",
			errBlocked: "此路不通",
			errNoAction: "本回合的英雄行动已用完",
			errBadTarget: "目标不可达",
			errNoFocus: "专注不足",
			errBadNudge: "微调不合法",
			errBadChoice: "无效的选择",
			errKnocked: "昏迷中,只能休整",
			errLairLocked: "巢穴之门尚未开启",
			logAria: "对局日志",
			rollAria: "掷骰检定",
			choiceAria: "抉择",
			logPick: "{{name}} 加入了冒险",
			logReveal: "{{room}} 被点亮",
			logSpawnGoblin: "{{name}} 现身!",
			logSpawnMinion: "随从{{name}} 现身!",
			logRollOk: "{{name}}{{label}}:{{total}} ≥ {{need}},成功",
			logRollFail: "{{name}}{{label}}:{{total}} < {{need}},失败",
			logHit: "{{name}} 命中{{enemy}},造成 {{dmg}} 伤",
			logKill: "{{name}} 击杀了{{enemy}}",
			logCounter: "{{enemy}} 反击,{{name}} 受 {{dmg}} 伤",
			logCounterBlocked: "{{name}} 挡下了{{enemy}} 的反击",
			logEnemyHit: "{{enemy}} 击中{{name}},造成 {{dmg}} 伤",
			logKnocked: "{{name}} 昏迷倒地!",
			logRest: "{{name}} 休整恢复",
			logGain: "{{name}} 获得了{{item}}",
			logEnterLair: "{{name}} 闯入 Boss 巢穴!",
			logAct2: "第二幕开始:讨伐 Boss!",
			logBossHit: "Boss 受 {{dmg}} 伤",
			logWon: "Boss 讨伐成功!"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Tiny Epic Dungeons",
			desc: "Co-op dungeon crawl: light up rooms, clear goblins and minions, slay the Boss before the torch burns out",
			rules: "Goal: defeat the Boss before the torch burns out.\nTurn:\n· Heroes act one at a time: move up to your Speed first; stepping onto a face-down room reveals it.\n· Then take 1 hero action (attack / search / disarm / cast / room action / rest).\n· Free actions that cost Focus are unlimited.\nChecks:\n· Roll dice equal to the stat, keep 1 die as the result, and add all + values from the rest.\n· Every 2 Focus lets you raise or lower the result by 1.\nTorch:\n· The torch advances 1 space when a turn ends; landing on icons spawns goblins or wakes enemies.\n· A 5th goblin on the board means defeat.\n· Slaying a minion pushes the torch back 6 spaces.\nBoss:\n· Revealing the Lair Door starts Act 2: claim altar spaces to unlock the Boss health markers; clear them all to win.\nDefeat (any one):\nAll players lose if any of the following occurs:\n· The torch burns out.\n· A fifth goblin enters the dungeon.\n· There are no rooms left to explore.",
			bannerPick: "Pick your hero",
			bannerYou: "Your turn",
			bannerWait: "Waiting for your teammate…",
			bannerEnemy: "Enemies acting…",
			rollNeed: "Need {{n}}",
			rollConfirm: "Confirm",
			rollAttack: "Attack roll",
			rollSearch: "Search roll",
			rollDisarm: "Disarm trap",
			rollTrap: "Trap triggered!",
			rollBunks: "Goblin bunks!",
			rollCast: "Casting roll",
			rollAbility: "Ability roll",
			rollArmory: "Armory",
			rollFeast: "Feast hall",
			boostRage: "Rage +2(−3⚡)",
			boostStance: "Stoneskin Def+2(−2⚡)",
			boostPump: "Lion pump +1(−2⚡)",
			boostReroll: "Reroll {{n}}",
			boostCleric: "Heal −2⚡ +4❤",
			choiceGoblinReward: "Goblin loot: pick one",
			choiceDiscover: "Discovery: take 1 card from the deck, or reclaim 1 from the discard pile",
			choiceMinionReward: "Minion slain: rewards",
			choicePharaoh: "Pharaoh's choice",
			choiceOoze: "Ooze clings on: discard an item",
			choicePulley: "Pulley: pick a goblin",
			choiceWarhorn: "War horn: tap a space to push enemies",
			choiceWait: "Waiting for a teammate…",
			optDeck: "Top of deck",
			optLoot: "Loot deck",
			optSpell: "Spell deck",
			optReveal: "Reveal a room",
			optFocus3: "3 ⚡",
			optSkip: "Skip",
			optHp: "{{n}} ❤",
			optFocus: "{{n}} ⚡",
			pickTarget: "Pick a target",
			cancel: "Cancel",
			actSearch: "Search",
			actDisarm: "Disarm",
			actRoom: "Room action",
			actLair: "Enter lair",
			actTaunt: "Taunt",
			actExplore: "Explore",
			actRest: "Rest",
			endTurn: "End turn",
			abilityResearch: "Research",
			abilityHealingHands: "Healing hands",
			abilityShieldBash: "Shield bash",
			abilitySprint: "Sprint",
			abilityLockpick: "Lockpick",
			abilityStealth: "Stealth",
			abilitySeekingBolt: "Seeking bolt",
			abilityDivineMight: "Divine might",
			abilityShadowWalk: "Shadow walk",
			bossSpace: "Boss space {{n}}",
			optBoss: "Boss this game",
			optBossRandom: "Random",
			won: "Boss slain!",
			lost: "The quest failed…",
			lostTorch: "The torch burned out",
			lostGoblins: "Overrun by goblins",
			lostDeadend: "No way forward",
			errNotYourTurn: "Not your turn",
			errBadPick: "That hero is taken",
			errNoSpeed: "Not enough movement",
			errBlocked: "Blocked",
			errNoAction: "Hero action already used",
			errBadTarget: "Target out of reach",
			errNoFocus: "Not enough Focus",
			errBadNudge: "Invalid nudge",
			errBadChoice: "Invalid choice",
			errKnocked: "Knocked out: rest only",
			errLairLocked: "The lair door is not open yet",
			logAria: "Game log",
			rollAria: "Dice check",
			choiceAria: "Make a choice",
			logPick: "{{name}} joins the adventure",
			logReveal: "{{room}} revealed",
			logSpawnGoblin: "{{name}} appears!",
			logSpawnMinion: "Minion {{name}} appears!",
			logRollOk: "{{name}} {{label}}: {{total}} ≥ {{need}} — success",
			logRollFail: "{{name}} {{label}}: {{total}} < {{need}} — fail",
			logHit: "{{name}} hits {{enemy}} for {{dmg}}",
			logKill: "{{name}} slays {{enemy}}",
			logCounter: "{{enemy}} counterattacks: {{name}} takes {{dmg}}",
			logCounterBlocked: "{{name}} blocks {{enemy}}'s counterattack",
			logEnemyHit: "{{enemy}} hits {{name}} for {{dmg}}",
			logKnocked: "{{name}} is knocked out!",
			logRest: "{{name}} rests and recovers",
			logGain: "{{name}} gains {{item}}",
			logEnterLair: "{{name}} enters the Boss lair!",
			logAct2: "Act II begins: slay the Boss!",
			logBossHit: "Boss takes {{dmg}} damage",
			logWon: "Boss defeated!"
		}
	}
};
//#endregion
export { xr as default };
